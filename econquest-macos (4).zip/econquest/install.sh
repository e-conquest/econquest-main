#!/usr/bin/env bash
# EconQuest one-command installer for macOS (also works on Linux).
#
#   Double-click install.command, or in Terminal:   bash install.sh
#
# What it does:
#   1. finds Python (python3 on PATH, Homebrew, python.org or Anaconda), preferring a version that
#      requirements-lock.txt covers (its "# python:" line, today 3.12-3.14);
#   2. copies this folder to ~/econquest (unless it already lives there). On a
#      reinstall (~/econquest/data exists) it first backs up data/ and outputs/ to
#      ~/econquest-backups/<UTC time>/, updates the program files, and only adds
#      data files that are missing: your data/ and outputs/ are never overwritten, except the
#      released model configuration (assumptions, limits, scenarios, rulebook, playbook and their
#      approval log), which is updated unless this Mac has approved changes of its own;
#   3. creates a private virtual environment at ~/econquest/.venv and installs every dependency
#      (numpy, pandas, scipy, scikit-learn, imf-reader, weo, wbgapi, fastapi, uvicorn, pytest)
#      from requirements-lock.txt with `pip install --require-hashes`: exact versions, and every file is
#      checked against its SHA-256 before anything is installed (EQ-C-0066, SEC-C-007 O2). A mismatch
#      stops the install. The program itself is then installed with --no-deps --no-build-isolation;
#   4. writes an `econquest` command into ~/.local/bin and adds that folder to
#      your PATH (zsh and bash), so `econquest fetch --apply` works from any folder.
#
# Nothing is installed system-wide; `bash install.sh --uninstall` removes it all.
#
# Environment: ECONQUEST_HOME (install folder), ECONQUEST_BACKUP_DIR (default ~/econquest-backups),
# ECONQUEST_NO_PROFILE=1 (do not touch ~/.zshrc or ~/.bash_profile; add ~/.local/bin to PATH yourself),
# ECONQUEST_INSTALL_SKIP_VENV=1 (copy files only: no venv, pip, launcher or smoke test; used by tests).
set -euo pipefail

TARGET="${ECONQUEST_HOME:-$HOME/econquest}"
BIN_DIR="$HOME/.local/bin"
SRC="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

say()  { printf '\033[1;34m==>\033[0m %s\n' "$*"; }
fail() { printf '\033[1;31mError:\033[0m %s\n' "$*" >&2; exit 1; }

# Options (EQ-C-0048): --help prints this and stops; an unknown option stops before anything is copied, so a typo never
# runs a full install or upgrade.
case "${1:-}" in
  ""|--uninstall) ;;
  -h|--help)
    cat <<EOF
Usage: bash install.sh             install, or upgrade an existing install in $TARGET
       bash install.sh --uninstall remove $TARGET/.venv and $BIN_DIR/econquest (data/ and outputs/ stay)
       bash install.sh --help      this message

Upgrade: unzip the new release and run its install.sh (or double-click install.command). data/ and outputs/ are
backed up to \${ECONQUEST_BACKUP_DIR:-~/econquest-backups}/<UTC time>/ first and never overwritten; only the released
model configuration (assumptions, limits, scenarios, rulebook, playbook, compliance) is updated, unless this Mac
has approved changes of its own.
EOF
    exit 0 ;;
  *) fail "unknown option '$1' (nothing was changed). Run: bash install.sh --help" ;;
esac

if [[ "${1:-}" == "--uninstall" ]]; then
  say "Removing $TARGET/.venv and $BIN_DIR/econquest (your data/ and outputs/ stay in $TARGET)"
  rm -rf "$TARGET/.venv" "$BIN_DIR/econquest"
  say "Done. Delete $TARGET yourself if you no longer want the data."
  exit 0
fi

# 1. Python ---------------------------------------------------------------
# The first Python 3.10+ whose version requirements-lock.txt has wheels for wins; else the first 3.10+ found (enough
# for ECONQUEST_INSTALL_SKIP_VENV; step 3 refuses it with a clear message).
LOCK_NAME="requirements-lock.txt"
lock_pythons() { [[ -f "$1" ]] || return 0; sed -n 's/^# python: *//p' "$1" | head -1; }
py_mm() { "$1" -c 'import sys; print("%d.%d" % sys.version_info[:2])' 2>/dev/null; }
LOCK_PYS="$(lock_pythons "$SRC/$LOCK_NAME")"
PY=""; PY_ANY=""
for cand in python3 /opt/homebrew/bin/python3 /usr/local/bin/python3 \
            /Library/Frameworks/Python.framework/Versions/Current/bin/python3 \
            "$HOME/opt/anaconda3/bin/python3" /opt/anaconda3/bin/python3 "$HOME/anaconda3/bin/python3"; do
  if command -v "$cand" >/dev/null 2>&1 || [[ -x "$cand" ]]; then
    if "$cand" -c 'import sys; sys.exit(0 if sys.version_info >= (3, 10) else 1)' 2>/dev/null; then
      p="$(command -v "$cand" 2>/dev/null || echo "$cand")"
      [[ -n "$PY_ANY" ]] || PY_ANY="$p"
      if [[ -n "$LOCK_PYS" && " $LOCK_PYS " == *" $(py_mm "$p") "* ]]; then PY="$p"; break; fi
    fi
  fi
done
PY="${PY:-$PY_ANY}"
[[ -n "$PY" ]] || fail "Python 3.10 or newer was not found. Install it with 'brew install python' or from python.org, then run this again."
say "Using Python: $PY ($("$PY" -c 'import platform; print(platform.python_version())'))"

# 2. Copy the program folder -----------------------------------------------
# A reinstall must never replace the user's data/ or outputs/ (HO-20261023-A-C-004): back them up, copy the
# program without them, then add only the data files the new version brings that the install lacks.
have_rsync() { command -v rsync >/dev/null 2>&1 && [[ -z "${ECONQUEST_INSTALL_NO_RSYNC:-}" ]]; }
count_files() { [[ -d "$1" ]] && find "$1" -type f | wc -l | tr -d ' ' || echo 0; }

# Model configuration is released with the code: assumptions, limits, scenarios, rulebook and playbook change only
# through `econquest change` / change control, so on upgrade the zip's copies replace the installed ones together
# with the approval log that records them (EQ-C-0032). If the installed approval log has entries the zip's log
# lacks (a change made on this Mac), nothing is replaced and the installer says so.
# compliance.json (EQ-C-0040): governed by `econquest change` like assumptions/limits, so it follows the same rule
MANAGED_DATA=(assumptions.json limits.json scenarios.json rulebook.csv playbook.csv compliance.json)
update_managed() {  # update_managed <src data> <dst data>
  local src="$1" dst="$2" f n=0 sl dl
  sl="$src/approvals/log.jsonl"; dl="$dst/approvals/log.jsonl"
  if [[ -s "$dl" ]] && { [[ ! -f "$sl" ]] || ! cmp -s -n "$(wc -c < "$dl" | tr -d ' ')" "$dl" "$sl"; }; then
    say "WARNING: $dl has approved changes that are not in this release; model configuration left as installed (merge by hand: see the backup)"
    return 0
  fi
  for f in "${MANAGED_DATA[@]}"; do
    if [[ -f "$src/$f" ]] && ! cmp -s "$src/$f" "$dst/$f"; then cp -p "$src/$f" "$dst/$f"; n=$((n + 1)); say "data/$f: updated to the released version"; fi
  done
  if [[ -d "$src/approvals" ]]; then
    mkdir -p "$dst/approvals"; cp -Rp "$src/approvals/." "$dst/approvals/"
  fi
  say "model configuration: $n file(s) updated from the release (previous copies are in the backup)"
}

copy_missing() {  # copy_missing <src dir> <dst dir> <label>: add files absent from dst, report what was kept
  local src="$1" dst="$2" label="$3" before after total
  [[ -d "$src" ]] || return 0
  mkdir -p "$dst"
  total=$(count_files "$src"); before=$(count_files "$dst")
  if have_rsync; then
    rsync -a --ignore-existing --exclude '__pycache__' --exclude '*.pyc' --exclude '.DS_Store' "$src/" "$dst/"
  else
    cp -Rn "$src/." "$dst/" 2>/dev/null || true
  fi
  after=$(count_files "$dst")
  say "$label: added $((after - before)) new file(s), kept $((total - (after - before))) existing file(s) unchanged"
}

if [[ "$SRC" != "$TARGET" ]]; then
  mkdir -p "$TARGET"
  if [[ -d "$TARGET/data" ]]; then
    BACKUP="${ECONQUEST_BACKUP_DIR:-$HOME/econquest-backups}/$(date -u +%Y%m%dT%H%M%SZ)"
    [[ -e "$BACKUP" ]] && BACKUP="$BACKUP-$$"
    say "Existing install found: backing up data/ and outputs/ to $BACKUP"
    mkdir -p "$BACKUP"
    cp -RpL "$TARGET/data" "$BACKUP/data"                  # -L: back up the files, not a symlink to them
    [[ -d "$TARGET/outputs" ]] && cp -RpL "$TARGET/outputs" "$BACKUP/outputs"
    [[ -d "$BACKUP/data" && ! -L "$BACKUP/data" ]] || fail "backup to $BACKUP failed; nothing was changed in $TARGET"
    [[ "$(find -L "$TARGET/data" -type f | wc -l | tr -d ' ')" == "$(count_files "$BACKUP/data")" ]] \
      || fail "backup of data/ in $BACKUP is incomplete; nothing was changed in $TARGET"
    say "Updating program files in $TARGET (data/ and outputs/ left as they are)"
    if have_rsync; then
      rsync -a --exclude '.venv' --exclude '__pycache__' --exclude '*.pyc' --exclude '.git' \
            --exclude '/data' --exclude '/outputs' "$SRC/" "$TARGET/"
    else
      (cd "$SRC" && tar cf - --exclude './.venv' --exclude './.git' --exclude '__pycache__' --exclude '*.pyc' \
            --exclude './data' --exclude './outputs' .) | (cd "$TARGET" && tar xf -)
    fi
    update_managed "$SRC/data" "$TARGET/data"
    copy_missing "$SRC/data" "$TARGET/data" "data/"
    copy_missing "$SRC/outputs" "$TARGET/outputs" "outputs/"
  else
    say "Copying program to $TARGET"
    if have_rsync; then
      rsync -a --exclude '.venv' --exclude '__pycache__' --exclude '*.pyc' --exclude '.git' "$SRC/" "$TARGET/"
    else
      cp -R "$SRC/." "$TARGET/"
    fi
  fi
fi
[[ -f "$TARGET/pyproject.toml" && -d "$TARGET/data" ]] || fail "$TARGET does not contain pyproject.toml and data/; run install.sh from the downloaded econquest folder."

if [[ -n "${ECONQUEST_INSTALL_SKIP_VENV:-}" ]]; then
  say "ECONQUEST_INSTALL_SKIP_VENV set: files copied to $TARGET; skipping venv, pip, launcher and smoke test"
  exit 0
fi

# 3. Virtual environment + install ----------------------------------------
# Dependencies come only from the hash-pinned lock (EQ-C-0066, SEC-C-007 O2); pip and setuptools are in it too, so
# nothing is fetched unpinned. Optional extras (api, ml, ...) are not installed here: see README "Dependencies".
LOCK="$TARGET/$LOCK_NAME"
[[ -f "$LOCK" ]] || fail "$LOCK is missing. The installer only installs hash-checked packages from it; unzip the full release again and rerun."
LOCK_PYS="$(lock_pythons "$LOCK")"
PY_MM="$(py_mm "$PY")"
[[ -n "$LOCK_PYS" && " $LOCK_PYS " == *" $PY_MM "* ]] \
  || fail "Python $PY_MM ($PY) is not covered by $LOCK_NAME (it has packages for Python ${LOCK_PYS:-?}). Install one of those, for example 'brew install python@3.13', then run this again."
say "Creating virtual environment at $TARGET/.venv"
"$PY" -m venv "$TARGET/.venv"
VPY="$TARGET/.venv/bin/python"
say "Installing the pinned dependencies from $LOCK_NAME, each checked against its SHA-256 (a few minutes the first time)"
set +o pipefail
"$VPY" -m pip install --progress-bar off --disable-pip-version-check --require-hashes -r "$LOCK" 2>&1 \
  | tee "$TARGET/.install.log" | { grep -E "Downloading|Installing collected|Successfully|ERROR|HASHES|hash" || true; }
rc=${PIPESTATUS[0]}
set -o pipefail
if [[ $rc -ne 0 ]]; then
  tail -20 "$TARGET/.install.log"
  if grep -qiE "do not match the hashes|hashes are required|hash mismatch" "$TARGET/.install.log"; then
    fail "a downloaded package did not match the SHA-256 recorded in $LOCK_NAME, so nothing was installed. This means a corrupted or altered download (a proxy, a mirror or a tampered package). Do not work around it with a plain 'pip install'; retry on another network and, if it repeats, report it to Team C with $TARGET/.install.log."
  fi
  fail "pip install from $LOCK_NAME failed (full log: $TARGET/.install.log)"
fi
say "Installing econquest itself (no further downloads)"
set +o pipefail
"$VPY" -m pip install --progress-bar off --disable-pip-version-check --no-deps --no-build-isolation -e "$TARGET" 2>&1 \
  | tee -a "$TARGET/.install.log" | { grep -E "Successfully|ERROR" || true; }
rc=${PIPESTATUS[0]}
set -o pipefail
[[ $rc -eq 0 ]] || { tail -20 "$TARGET/.install.log"; fail "pip install of econquest failed (full log: $TARGET/.install.log)"; }

# 4. Command on PATH --------------------------------------------------------
mkdir -p "$BIN_DIR"
cat > "$BIN_DIR/econquest" <<EOF
#!/usr/bin/env bash
# Launcher written by EconQuest install.sh
export ECONQUEST_HOME="$TARGET"
exec "$VPY" -m econquest "\$@"
EOF
chmod +x "$BIN_DIR/econquest"

if [[ -n "${ECONQUEST_NO_PROFILE:-}" ]]; then
  say "ECONQUEST_NO_PROFILE set: shell profiles left alone; add $BIN_DIR to your PATH yourself"
else
  for rc in "$HOME/.zshrc" "$HOME/.bash_profile"; do
    if [[ -f "$rc" || "$rc" == "$HOME/.zshrc" ]]; then
      if ! grep -qs 'local/bin' "$rc" 2>/dev/null; then
        printf '\n# added by EconQuest installer\nexport PATH="$HOME/.local/bin:$PATH"\n' >> "$rc"
        say "Added ~/.local/bin to PATH in $rc (skip with ECONQUEST_NO_PROFILE=1)"
      fi
    fi
  done
fi
export PATH="$BIN_DIR:$PATH"

# 5. Smoke test ----------------------------------------------------------------
say "Checking the install"
"$BIN_DIR/econquest" --help >/dev/null || fail "econquest --help failed"
"$VPY" -c 'import numpy, pandas, scipy, sklearn, imf_reader, wbgapi, weo' || fail "a dependency did not import"

cat <<EOF

EconQuest is installed.
  Program and data:  $TARGET
  Command:           econquest   (open a new Terminal window first, or run: source ~/.zshrc)

Try:
  econquest gui                  # point-and-click app with charts (opens in your browser)
  econquest --help
  econquest run --stress --backtest   # the daily model run; its last line is VaR99, ES99 and EL in \$mm
  econquest fetch --apply        # pull IMF, World Bank, BIS and ECB data into data/live and apply it
  econquest review list --pending     # cells the quality gate held, waiting for your decision
  econquest publish --dry-run    # save the workbook plan only (nothing sent to Sheets)
  econquest publish --write      # write results to the Google Sheet (token from the Keychain item econquest-sheets)

Upgrading later: unzip the new release and run its install.sh; your data/ and outputs/ are backed up and kept.

Outputs land in $TARGET/outputs. To remove: bash $TARGET/install.sh --uninstall
EOF
