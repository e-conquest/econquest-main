---
id: {id}
ticket: {ticket}
author: {author}
created: {created}
status: open
---
# {title}

## Workload
Exact command, path count, data vintage, machine (cores, RAM, Python version).

## Baseline
| Metric | Value | How measured |
|---|---|---|
| wall time | | `time python -m econquest run ...` (median of 3) |
| peak RSS | | `/usr/bin/time -v` |

## Profile
Top 10 functions by cumulative time (`python -m cProfile -s cumtime`).

## Change and result
| Metric | Before | After | Delta |
|---|---|---|---|

## Numerical equivalence
Seeded run before vs after: VaR99, ES99, EL and top-5 PDs must match to the tolerance stated here,
or the change is a model change and goes through change-control.
