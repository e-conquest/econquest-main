# Team {team} sprint {sprint}

Dates: {start} to {end}
Sprint goal:

## Committed tickets
| Ticket | Summary | Points | Agent |
|---|---|---|---|

## Daily status
(paste `python team/teamctl.py status --team {team}` output under a date heading)

## Review
Done tickets with evidence.

## Retro
Keep:
Change:
