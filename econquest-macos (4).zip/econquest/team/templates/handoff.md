---
id: {id}
from: {from_}
to: {to}
ticket: {ticket}
type: {type}
priority: {priority}
status: open
created: {created}
due: {due}
branch: {branch}
accepted_by:
---
## Context
{title}

## Ask


## Artifacts
- 

## Acceptance


## Response
