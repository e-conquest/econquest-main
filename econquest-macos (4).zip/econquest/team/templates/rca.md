---
id: {id}
ticket: {ticket}
author: {author}
created: {created}
severity: {severity}
status: draft
---
# {title}

## Symptom
What was observed, where, since when. Exact command, output and run_id.

## Reproduction
Smallest command or test that shows it. Must fail before the fix.

## Timeline
- first bad run / data vintage / commit

## Root cause
The defect in one paragraph, with file:line. Why the existing tests did not catch it.

## Fix
What changed. Regression test name.

## Blast radius
Which runs, published numbers, or vintages were affected. Whether any reported VaR/ES/PD moved
(if yes: GOV issue id and change-control classification).

## Prevention
Check, alert, test, or pipeline rule that stops a recurrence. Owner and ticket.
