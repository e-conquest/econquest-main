---
id: {id}
ticket: {ticket}
author: {author}
created: {created}
severity: {severity}   # critical | high | medium | low | info
status: open           # open | fixed | accepted-risk (needs EXC- id) | false-positive
cwe:
---
# {title}

## Finding
What, where (file:line or dependency@version), how it was found (bandit, pip-audit, gitleaks, review).

## Exploit scenario
Who could trigger it and what they gain. For a local desktop tool, say so plainly; do not inflate.

## Fix
Required change and the test or pipeline rule that verifies it.

## Verification
Command and output after the fix.
