---
id: {id}
ticket: {ticket}
author: {author}
created: {created}
status: proposed      # proposed | accepted | superseded by ADR-x-nnn | rejected
contracts: []         # C-numbers from team/contracts.md this touches
---
# {title}

## Context
The forces at play: what is wrong or missing today, constraints, the model-risk tier if a model
is affected.

## Decision
What we will do, stated as a rule.

## Options considered
| Option | For | Against |
|---|---|---|

## Consequences
What becomes easier, what becomes harder, what other teams must change (with handoff ids).

## Rollout
Steps, order, and the test that proves each step.
