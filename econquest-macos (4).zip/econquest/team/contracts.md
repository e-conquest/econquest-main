# Cross-team contracts

These are the seams where one team's code is read by another team's code. Changing anything listed
here needs a `contract-change` handoff to every consuming team, accepted before merge
(`handoff-protocol.md` rule 4). AGENT-05 of the owning team keeps this file current; AGENT-02
re-checks it against the code each sprint with `teamctl catalog` (cross-package imports section).

| # | Contract | Owner | Consumers | What is frozen |
|---|---|---|---|---|
| C1 | `econquest.ingestion.load_universe()` -> `Universe` | A | B, C | Function signature; `Universe` attribute names and DataFrame column names |
| C2 | `data/indicators.csv`, `data/countries.csv` schema | A | B | Column names, units, country codes (ISO3) |
| C3 | `data/live/vintages/<date>/` layout and `provenance.csv` columns | A | B (record, audit), C (Audit Trail tab) | Folder naming, file names, column names |
| C4 | `econquest.persistence.Store` (`save_run`, `runs`, `latest`, `load`, `series`) | A | B, C | Method names, return shapes, run_id format |
| C5 | `econquest.engine.run_pipeline(u, settings, label, paths)` -> `RunResult` and `RunResult.to_dict()` / `outputs/run_latest.json` keys | B | C (publish, GUI, report, API) | Top-level keys and the metric names `var99_mm`, `es99_mm`, `expected_loss_mm`, per-country PD fields |
| C6 | `econquest.engine.signals` (`compute_signals`, `trade_activation`, `dashboard_table`, `SIGNAL_NAMES`) | B | C | Names and table columns |
| C7 | `econquest.engine.stress` (`load_scenarios`, `compare`, `reverse_stress`, `single_factor_reverse`, `SINGLE_FACTORS`, `summarise_shocks`) | B | C | Signatures and returned keys |
| C8 | `econquest.validation` (`backtest_history`, `record.record_for_backtest`, `alerts.detect_alerts`, `alert_settings`, `backtest_status`, `SEVERITY_RANK`) | B | C | Signatures, alert record fields |
| C9 | `econquest.config.Settings` (`load`, `get`, `copy_with`), `PILLARS`, `REGIMES` | C | A, B | Method names; constants are changed only with a Team B ADR |
| C10 | CLI subcommands and flags (`econquest --help`) | C | Sam, scheduled tasks (daily record 6:20pm NY), docs | Existing subcommand names and flags; removal needs a deprecation release |
| C11 | Google Sheets tab names and anchor cells (`data/workbook_reference.json`, `layout_version` 2 and its `layout` section, A2 run date, Risk Engine R31-R33; ADR-C-001) | C | Sam, workbook formulas | Tab names and anchor cells; country blocks E:col(4+N) and the ranges that grow with N per ADR-C-001 |
| C12 | `econquest.engine.dsa.scorecard_feeds(table, retrieved, keys)` -> DataFrame and `outputs/dsa_scorecard_feeds.csv` | B | A (ingestion gate) | Column names `table,key,country,value,source,series,retrieved,iso,year0,dsa_column` (first seven = provenance.csv columns); key ids 1.1, 1.2, 2.1 |

When a contract changes: owner writes an ADR (`team/adr/`), sends one `contract-change` handoff per
consuming team, keeps the old shape working for one release where practical, and updates this table
in the same PR.
