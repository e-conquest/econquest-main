# EconQuest agent team: start here

Three teams of eleven agents build econquest in parallel, in one Claude account, through one shared
folder. This page is how to start them. The rules are in:

| File | What it decides |
|---|---|
| `team/operating-model.md` | Teams, roles, RACI, routing, Definitions of Ready and Done, cadence, escalation |
| `team/handoff-protocol.md` | How work passes between agents and teams; handoff and log formats |
| `team/contracts.md` | The code seams between teams (C1 to C11); changing one needs a handoff |
| `team/ownership.csv` | Which team owns which path |
| `.claude/agents/agent-01..11-*.md` | The eleven role definitions (charter, inputs, outputs, done-criteria) |
| `CLAUDE.md` | Rules every session loads |
| `team/teamctl.py` | The tool that enforces the mechanics (stdlib only, tested in `tests/test_teamctl.py`) |

## The three teams

| Team | Owns | Starts with (Ready on its board) |
|---|---|---|
| A, Data | ingestion, persistence, live data, vintages, panel | Layering fixes EQ-A-0001/0002, full-panel fetch runbook (GOV-006), event-feed spike (GOV-014) |
| B, Models | engine, scorecard, validation, assumptions, governance docs | As-of date for determinism (GOV-012), layering fix, Monte Carlo characterisation tests |
| C, Platform | presentation, CLI, config, packaging, CI, team tooling | Sheets token out of the command line, presentation tests, lint gate; two inbound handoffs |

Team C's AGENT-08 is program lead, and Team C's AGENT-11 is Release Train Engineer.

## Starting a team session

**In this Claude project (cloud threads).** Ask the coordinator for one thread per team with this
brief, changing the letter:

> You are Team A (Data) of the econquest agent team. Act as AGENT-08, the team lead. Read
> `/mnt/project-files/econquest/CLAUDE.md`, `team/README.md`, `team/operating-model.md` and
> `.claude/agents/agent-08-tech-lead-orchestrator.md`, then run
> `python team/teamctl.py status --team A` from `/mnt/project-files/econquest/` and work the Ready
> tickets. To delegate to AGENT-01..11, start a subagent whose prompt is the body of that agent's file
> in `.claude/agents/` followed by your brief.

Cloud threads do not start inside the econquest folder, so the agent files are not registered as
named subagents there. Pasting the file body into the subagent prompt gives the same result.

**On your Mac (Claude Code CLI)**, from the econquest folder, one terminal per team:

```
cd ~/econquest
ECONQUEST_TEAM=A claude --agent agent-08-tech-lead-orchestrator
ECONQUEST_TEAM=B claude --agent agent-08-tech-lead-orchestrator
ECONQUEST_TEAM=C claude --agent agent-08-tech-lead-orchestrator
```

Here the eleven files are native subagents, and AGENT-08 calls them by name.

## Daily mechanics (any agent)

```
python team/teamctl.py status --team A                  # board, inbound handoffs, last activity
python team/teamctl.py ticket new --team A --summary "..." --agent AGENT-06 --points 3 --gov GOV-006
python team/teamctl.py ticket move EQ-A-0003 --team A --status "In Progress"
python team/teamctl.py checkpoint econquest/ingestion/feeds.py --ticket EQ-A-0003   # before editing
python team/teamctl.py diff --ticket EQ-A-0003                                        # review
python team/teamctl.py revert --ticket EQ-A-0003                                      # undo
python team/teamctl.py check --ticket EQ-A-0003                                       # gate before Done
python team/teamctl.py handoff new --from A/AGENT-06 --to B/AGENT-05 --ticket EQ-A-0003 --type contract-change --title "..."
python team/teamctl.py handoff accept HO-20261023-A-B-001 --by B/AGENT-05
python team/teamctl.py handoff done HO-20261023-A-B-001 --by B/AGENT-05 --response "..."
python team/teamctl.py log progress "parser handles NGDPD rename" --team A --agent AGENT-03 --ticket EQ-A-0003
python team/teamctl.py catalog                          # AGENT-02: regenerate team/catalog/modules.md
python team/teamctl.py jira-export                      # AGENT-11: team/board/jira-import.csv
```

## Jira and Confluence

The board CSVs in `team/board/` are the source of truth because all three sessions can write them.
`jira-export` produces a file that Jira's CSV importer (System > External System Import > CSV) maps
directly. No Jira or Confluence connector is attached to this project, so syncing is a manual import
for now.

## Without git

econquest is not under version control. A checkpoint (saved before an edit) is the only undo, and
`check --ticket` is the only ownership gate. `.github/workflows/ci.yml` (tests on 3.10 and 3.13,
smoke run, ruff, bandit, pip-audit, gitleaks, team gate) is ready but stays dormant until econquest is
on GitHub (EQ-C-0001, optional).
