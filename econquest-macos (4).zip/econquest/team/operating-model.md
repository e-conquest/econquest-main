# EconQuest engineering team: operating model

Written 2026-10-23. This file defines who does what, how work moves, and what "done" means for the
33-agent team (3 teams x 11 roles) that builds and runs econquest. The agent definitions in
`.claude/agents/` implement it; `team/teamctl.py` enforces the mechanical parts (ids, handoffs, logs,
ownership, Jira export). Where this file and `docs/governance/change-control.md` both cover a step
(releases, model changes), change-control wins: the team operates inside the model-risk policy, not
beside it.

## 1. Structure

Three teams, one release train. Every team has all eleven roles, so each team can take a ticket from
backlog to merged on its own. Teams are split by **what they own in the codebase**, not by
role, so two teams never edit the same file in the same sprint.

| Team | Name | Owns (see `team/ownership.csv`) | Typical work |
|---|---|---|---|
| A | Data | `econquest/ingestion/`, `econquest/persistence/`, `data/live/`, `data/indicators.csv`, `data/countries.csv`, `data/panel/`, `data/market_history/` | Feeds, quality gate, vintages, audit trail, roadmap Track 1 |
| B | Models | `econquest/engine/`, `econquest/scorecard/`, `econquest/validation/`, `data/assumptions.json`, `scenarios.json`, `limits.json`, `docs/validation/`, `docs/governance/` | Layers 1-6, GARCH, stress, backtests, governance issues (GOV-nnn), roadmap Track 2 |
| C | Platform | `econquest/presentation/`, `cli.py`, `config.py`, `versioning.py`, packaging, `.github/`, `.claude/`, `team/` | GUI, Sheets publish, reports, CLI, CI/CD, releases, roadmap Tracks 3-4 |

Team C's AGENT-08 is the **program lead** (integration, release go/no-go, cross-team arbitration) and
Team C's AGENT-11 is the **Release Train Engineer** (program board, PI planning, cross-team
dependencies). Team A and B's AGENT-08 and AGENT-11 lead their own teams.

## 2. Roles

| Agent | Role | Owns the decision on | Primary artifacts |
|---|---|---|---|
| AGENT-01 | Senior Full-Stack Product Engineer | How a feature is built end to end | Code, tests, feature handoff |
| AGENT-02 | Codebase Audit and Reverse Engineering | What the code actually does today | `team/catalog/`, audit reports |
| AGENT-03 | Production Debugging and RCA | Root cause of a defect | `team/rca/RCA-*.md`, regression test |
| AGENT-04 | Performance and Scalability | Whether a change is fast enough | `team/perf/PERF-*.md`, benchmarks |
| AGENT-05 | Software Architect and Refactoring | Module boundaries, contracts, refactors | `team/adr/ADR-*.md`, `team/contracts.md` |
| AGENT-06 | Backend Systems and Infrastructure | Data flow, storage, config, external services | Ingestion/persistence design, runbooks |
| AGENT-07 | Frontend and UI/UX | GUI, Sheets layout, report presentation | UI specs, screenshots, accessibility notes |
| AGENT-08 | Chief Technical Lead / Orchestrator | Sequencing, routing, merge readiness | Sprint plan, routing decisions, review sign-off |
| AGENT-09 | AppSec and DevSecOps | Whether a change is safe to ship | `team/security/SEC-*.md`, threat models |
| AGENT-10 | DevOps, CI/CD and Deployment | Pipeline, packaging, release mechanics | `.github/workflows/`, release zip, install checks |
| AGENT-11 | Scrum Master / SAFe / Jira-Confluence | Board state, ceremonies, Jira/Confluence sync | `team/board/`, sprint reports, Jira CSV |

### RACI for the main activities

R = does it, A = signs it off, C = consulted, I = told. One A per row.

| Activity | 01 | 02 | 03 | 04 | 05 | 06 | 07 | 08 | 09 | 10 | 11 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| Backlog refinement and estimates | C | C | C | C | C | C | C | A | C | C | R |
| Codebase catalog and audit | I | R | C | C | C | C | C | A | C | I | I |
| Feature build | R | C | I | C | C | C | C | A | C | I | I |
| Defect RCA and fix | C | C | R | C | I | C | C | A | I | I | I |
| Performance work | C | C | C | R | C | C | I | A | I | I | I |
| Architecture decision / refactor | C | C | I | C | R | C | C | A | C | I | I |
| Data and infrastructure change | C | C | I | C | C | R | I | A | C | C | I |
| UI / workbook layout change | C | I | I | I | C | I | R | A | I | I | I |
| Security review | I | C | I | I | C | C | C | C | R/A | C | I |
| CI/CD and release | I | I | I | I | I | C | I | A | C | R | I |
| Sprint ceremonies, board, Jira sync | I | I | I | I | I | I | I | C | I | I | R/A |

AGENT-09 holds a **veto** on any change: a Critical or High security finding blocks merge until fixed
or accepted as an exception (`EXC-` in `docs/governance/issues-log.md`, signed by Sam).

## 3. How work moves

### Ids

| Thing | Format | Example | Created by |
|---|---|---|---|
| Ticket | `EQ-<team>-<4 digits>` | `EQ-B-0007` | AGENT-11 via `teamctl ticket new` |
| Handoff | `HO-<yyyymmdd>-<from>-<to>-<3 digits>` | `HO-20261023-A-B-001` | Sending agent via `teamctl handoff new` |
| RCA, ADR, SEC, PERF | `<KIND>-<team>-<3 digits>` | `RCA-A-002` | Owning agent via `teamctl doc new` |
| Model issue | `GOV-<3 digits>` (existing) | `GOV-012` | Team B, in `docs/governance/issues-log.md` |

Team letters in every id mean three teams can create ids in parallel without collision.

### Ticket lifecycle

`Backlog -> Ready -> In Progress -> In Review -> Done` (plus `Blocked`). A ticket enters **Ready** only
when it meets the Definition of Ready; it enters **Done** only when it meets the Definition of Done.
AGENT-11 moves tickets; any agent may set `Blocked` with a reason.

**Definition of Ready**: summary and acceptance criteria written; owning team confirmed from
`ownership.csv`; estimate in points (1, 2, 3, 5, 8; 13 means split it); dependencies named as handoffs
or tickets; for model changes, the Tier (1/2/3) from `model-risk-policy.md`.

**Definition of Done**:
1. Acceptance criteria met and demonstrated (command output, screenshot, or test).
2. `python -m pytest -q tests` passes; the count is recorded on the ticket; a regression test exists
   for every defect fix.
3. Peer review by a second agent of the same team (AGENT-05 for structural changes, AGENT-07 for UI).
4. AGENT-09 security check recorded (`sec: pass` or a SEC id) for any change that touches ingestion,
   the API, publish/credentials, dependencies, or CI.
5. AGENT-04 sign-off if the change touches the Monte Carlo path, GARCH, or anything on the daily
   record run.
6. Docs updated: the validation document for any changed model number, README section for any changed
   command.
7. Activity logged in `team/logs/<team>.jsonl`; handoffs it created are closed or re-assigned;
   `python team/teamctl.py check --ticket <id>` passes and `teamctl diff --ticket <id>` was reviewed.
8. For model and limit changes: the change-control release steps are done or a release ticket exists.

### Routing (AGENT-08's default)

| Work type | Path through the team |
|---|---|
| New feature | 11 refine -> 05 design check (ADR if a contract changes) -> 01 (or 06/07 by layer) build -> 09 review -> 04 if hot path -> 08 merge -> 10 release |
| Defect | 03 reproduce + RCA -> owner fix (03 or 01) -> regression test -> 09 if input-handling -> 08 merge |
| Performance | 04 profile + baseline -> 05 if structural -> 04/01 change -> 04 re-measure -> 08 merge |
| Refactor | 02 catalog + call graph -> 05 ADR -> 05/01 change behind green tests -> 04 no-regression -> 08 merge |
| Security finding | 09 triage + SEC doc -> owner fix -> 09 verify -> 10 pipeline rule if it can recur |
| Release | 10 runs change-control steps 1-9 -> 09 dependency + secret scan -> 08 go/no-go -> Sam signs step 10 |
| Unknown code area | 02 first, always: no build or fix starts in code nobody has catalogued |

## 4. Cadence

Two-week sprints, Monday to Friday-week-2. Five sprints plus one innovation/planning sprint make a
Program Increment (PI). Ceremonies are files, so they work across accounts:

| Ceremony | Owner | Output |
|---|---|---|
| PI planning (every 12 weeks) | Team C AGENT-11 + all AGENT-08s | `team/board/program.csv` features with team and target sprint; dependency handoffs opened |
| Sprint planning | Each AGENT-11 | Tickets moved to Ready with points; sprint goal in `team/board/sprints/<team>-<sprint>.md` |
| Daily sync | Each AGENT-11 | `teamctl status --team X` pasted into the sprint file; blockers escalated to AGENT-08 |
| Scrum of scrums (twice a week) | Team C AGENT-11 | `teamctl handoff list --status open` reviewed; overdue handoffs escalated |
| Review / demo | Each AGENT-08 | Done tickets with evidence links |
| Retro | Each AGENT-11 | Three keep / three change items appended to the sprint file |

## 5. Escalation

1. Agent cannot proceed -> sets ticket `Blocked`, logs the reason, tells its AGENT-08.
2. AGENT-08 cannot resolve inside the team (needs another team's code or a decision) -> opens a
   handoff to the other team's AGENT-08 with `priority: high`.
3. Two AGENT-08s disagree, or a handoff is open past its `due` date -> program lead (Team C AGENT-08)
   decides and records an ADR.
4. Anything that needs data, money, a licence, credentials, a production publish, or a model sign-off
   -> Sam. Agents never invent credentials, never publish to the live workbook, and never apply a
   Tier 1 model change without Sam's sign-off.
