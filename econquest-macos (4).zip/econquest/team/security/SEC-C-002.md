---
id: SEC-C-002
ticket: EQ-C-0007
author: C/AGENT-09
created: 2026-10-23
severity: low   # critical | high | medium | low | info
status: open           # open | fixed | accepted-risk (needs EXC- id) | false-positive
cwe: CWE-939 (improper authorization in handler for custom URL scheme), CWE-89 (bandit B608, false positive here)
---
# bandit -ll triage: 6 B310/B608/B103 findings in Team A and B files, 1 fixed in Team C

## Finding
`bandit -q -r econquest -ll` on 2026-10-23 reported 8 medium findings. One is in a Team C file and is fixed
here. The other 7 are in Team A and Team B files and are left for the owning teams. They are 7 because
`ingestion/replay.py:143 B103` appeared after the brief was written (EQ-A-0007). AGENT-09 did not edit any of them.

How to write a nosec: bandit reads every word after `nosec` as a test id and warns about the rest. Put the
justification in a comment on the line above the call, and end the call line with `# nosec <id>` only.

| # | Where | Test | Verdict | Owner | Ask |
|---|-------|------|---------|-------|-----|
| 1 | econquest/presentation/sheets_publish.py:253 (now ~263) | B310 | Real, Low: URL constant, but the id was unvalidated and the token was forwarded on redirect | C | **Fixed** (SEC-C-001 L1): `SHEETS_API` constant, `SHEET_ID_RE` check, `add_unredirected_header`, `# nosec B310` |
| 2 | econquest/ingestion/feeds.py:170 (`BisFeed._get`) | B310 | False positive in use: `base` defaults to `https://stats.bis.org/api/v1/data` and the only caller (feeds.py:397) uses the default. It is still a constructor parameter. | A | Fix (2 lines), then nosec |
| 3 | econquest/ingestion/sources.py:50 (`_http_json`) | B310 | Partly real, Low: bases are https constants, but `slug`/`ticker` from data/prediction_markets.csv are spliced in unquoted (`?slug={slug}`, `/{ticker}`), allowing extra query params or `../` on the same host | A | Fix, then nosec |
| 4 | econquest/ingestion/sources.py:127 (`GoogleSheetsSource.fetch`) | B310 | Real, Low (same as #1): fixed https host, but `spreadsheet_id` is unvalidated and the bearer token is a normal header, so urllib forwards it on redirect. No caller today. | A | Fix, then nosec |
| 5 | econquest/persistence/store.py:60 | B608 | False positive: `{t}` iterates the module constant `CHILD_TABLES`; `run_id` is a bound `?` parameter | A | nosec only |
| 6 | econquest/persistence/store.py:90 | B608 | False positive: query built only from literal fragments; `label` is a bound `?` parameter | A | nosec only |
| 7 | econquest/ingestion/replay.py:143 | B103 | False positive: 0o755 is on the snapshot *directory* (owner rwx, others r-x); the files inside are 0o444 | A | nosec only (optional hardening below) |
| 8 | econquest/validation/alerts.py:273 (`post_webhook`) | B310 | Real, Low: URL comes from `$ECONQUEST_ALERT_WEBHOOK` with no scheme check. A Slack/Teams webhook URL is itself a secret, so `http://` sends it in clear, and `file:`/`ftp:` are accepted. The operator sets it (not remote input), so the risk is low. | B | Fix, then nosec |

## Exploit scenario
This is a desktop tool for one desk, and none of these is remotely exploitable on its own. #3: a tampered or
hand-edited prediction_markets.csv can add query parameters or path segments to a Polymarket or Kalshi request
on the same host. It cannot reach another host. #4 and #1: a redirect would leak the OAuth token. #8: a mistyped
`http://` webhook leaks the webhook secret on the wire. The B608 and B103 findings are not exploitable.

## Fix (per owning team; exact text to paste)

**Team A, econquest/ingestion/feeds.py:170 (BisFeed._get)**: add a scheme check, then nosec:
```python
        url = f"{self.base}/{flow}/{key}/all?format=csv"
        if not url.startswith("https://"):
            raise ValueError(f"BIS base must be https: {self.base!r}")
        req = urllib.request.Request(url, headers={"User-Agent": "econquest/0.2", "Accept": "text/csv"})
        # B310: scheme checked to be https on the line above; host is the BIS SDMX API (EQ-A ticket, SEC-C-002)
        with urllib.request.urlopen(req, timeout=self.timeout) as r:  # nosec B310
```

**Team A, econquest/ingestion/sources.py:50 (_http_json)**: check the scheme here. Quote the CSV-sourced parts
at the two call sites: line 71 `?slug={urllib.parse.quote(str(slug), safe='')}` and line 99
`/{urllib.parse.quote(str(ticker), safe='')}`.
```python
def _http_json(url: str, timeout: float = 10.0) -> Optional[dict | list]:
    if urllib.parse.urlsplit(url).scheme != "https":
        return None
    try:
        # B310: scheme checked to be https above; bases are the Polymarket/Kalshi https constants (SEC-C-002)
        with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "econquest/0.1"}), timeout=timeout) as r:  # nosec B310
```

**Team A, econquest/ingestion/sources.py:127 (GoogleSheetsSource.fetch)**: validate the id and do not forward
the token on redirect (add `import re` at the top):
```python
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", str(self.spreadsheet_id)):
            raise ValueError("spreadsheet id must be letters, digits, '-' or '_'")
        url = f"https://sheets.googleapis.com/v4/spreadsheets/{self.spreadsheet_id}/values/{urllib.parse.quote(self.range_a1)}"
        req = urllib.request.Request(url)
        req.add_unredirected_header("Authorization", f"Bearer {self.token}")
        # B310: fixed https://sheets.googleapis.com URL, id validated above (SEC-C-002)
        with urllib.request.urlopen(req, timeout=20) as r:  # nosec B310
```

**Team A, econquest/persistence/store.py:60**: nosec only.
```python
            for t in CHILD_TABLES:
                # B608: t is one of the module constant CHILD_TABLES, never input; run_id is a bound parameter
                c.execute(f"DELETE FROM {t} WHERE run_id=?", (run_id,))  # nosec B608
```

**Team A, econquest/persistence/store.py:90**: nosec only.
```python
            # B608: built from literal fragments only; label is a bound parameter
            q = "SELECT run_id FROM runs" + (" WHERE label=?" if label else "") + " ORDER BY created_at DESC LIMIT 1"  # nosec B608
```

**Team A, econquest/ingestion/replay.py:143**: nosec only.
```python
        # B103: 0o755 is the snapshot directory (owner rwx, others r-x); every file in it is 0o444
        os.chmod(tmp, 0o755)  # nosec B103
```
Optional hardening, for the integrity of the vintages: after the `os.rename(tmp, snap)`, `os.chmod(snap, 0o555)`
so files cannot be added to a frozen snapshot by accident. If you do this, the cleanup path must chmod back to
0o755 before `rmtree`.

**Team B, econquest/validation/alerts.py:273 (post_webhook)**: https only, with plain http allowed for loopback
so that tests/test_report_alerts.py:85 (`http://127.0.0.1:9/hook`) still runs:
```python
def post_webhook(url: str, payload: dict, timeout: float = 10.0) -> str:
    import urllib.parse
    import urllib.request
    u = urllib.parse.urlsplit(url)
    if not (u.scheme == "https" or (u.scheme == "http" and u.hostname in ("127.0.0.1", "localhost", "::1"))):
        raise ValueError("ECONQUEST_ALERT_WEBHOOK must be an https:// URL")      # never echo the URL: it is a secret
    req = urllib.request.Request(url, data=json.dumps(payload).encode(), headers={"Content-Type": "application/json"}, method="POST")
    # B310: scheme restricted to https (or loopback http) above (SEC-C-002)
    with urllib.request.urlopen(req, timeout=timeout) as resp:  # nosec B310
```
Add a regression test: `post_webhook("file:///etc/passwd", {})` and `post_webhook("http://hooks.slack.com/x", {})`
both raise ValueError.

## Verification
After each team's change: `bandit -q -r econquest -ll` reports no findings in that file, and `python -m pytest -q
tests` passes. Team C part: `bandit -q -r econquest -ll` no longer lists sheets_publish.py. Close this SEC when
bandit -ll is clean, so that the ci_local.sh bandit gate (blocking) goes green.
