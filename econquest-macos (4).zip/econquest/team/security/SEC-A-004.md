---
id: SEC-A-004
ticket: EQ-A-0035
author: A/AGENT-09
created: 2026-10-23
severity: low   # critical | high | medium | low | info
status: fixed          # open | fixed | accepted-risk (needs EXC- id) | false-positive
cwe: CWE-354 (improper validation of integrity check value), CWE-345 (insufficient verification of data authenticity)
---
# Offline vintage re-apply: last-row index trust, silent rollback, decisions written before refusal

Scope: EQ-A-0035, which adds `load_vintage`, `vintage_review`, `record_vintage_decisions` and `apply_vintage` to the end
of `econquest/ingestion/feeds.py`. Reviewed against `ledger._bound`, `ledger.effective_holds`,
`ledger.record_decision` and `ledger._standing_objection`, and against SEC-A-001 (L1 binding, L3 colleague objection).

Result: **no Critical, High or Medium finding.** Nothing blocks Done. There are three Lows and some Info notes.

## Method
- Code review of the four functions, plus the ledger helpers they depend on.
- Probe script (not committed):
  `/tmp/claude-0/-home-claude-econquest-main/4d046af0-0329-5499-894e-87a0bbd3789c/scratchpad/sec3/probe35.py`. It reuses
  the synthetic vintages from `tests/test_apply_vintage.py` in temporary dirs and makes no network calls.
- `bandit -q -ll econquest/ingestion/feeds.py`: clean.
- `pytest tests/test_apply_vintage.py tests/test_market_*.py`: 140 passed.

## What is right (verified by probe)
- **Four-eyes on held cells.** `record_vintage_decisions` checks the whole batch first and writes nothing on refusal.
  Each row then goes through `ledger.record_decision`, which applies the same rules again.
  - An apply on a gate-held cell is refused when there is no approver, when the approver is the author, or when the
    approver is the author disguised as ` SAM​` or Cyrillic `Ѕam` (V1: 0 ledger rows written).
  - When a colleague's reject stands on a gate-ok cell, a single-author apply is also refused (V2). This keeps the
    SEC-A-001 L3 rule.
  - A flagged self-approval (`self_approved=True`, stored as `yes`) is the accepted single-operator mode (SEC-A-001 L5).
- **Binding.** Every decision row carries the resolved full vintage id, plus the live value and gate status from that
  vintage's `review.csv`. `_bound` binds by live value whenever both sides have one (SEC-A-001 L1). So an approval of
  31.25 releases 31.25 in a later vintage, by design, and leaves a vintage with 77.0 held (V3). The decision columns
  written at fetch time are dropped, so decisions come only from the ledger. `apply_vintage` never forces.
- **vintage_id paths.** `vintage_path` accepts only names returned by `list_vintages`, or the `<date>T` prefix of one.
  `../../etc`, `..`, `/etc/passwd`, `2026`, `2026-10-23T` and `*` are all refused (V4). The id is resolved once, at
  the top of `apply_vintage`, and reused, so the decisions and the apply always refer to the same vintage.
- **Integrity.** `load_vintage` reads the files once and compares their hash with `verify_vintage` and with the
  index. A tampered folder alone is refused (V5, first half). A vintage without `review.csv` is refused, so the gate
  is never re-run or guessed.

## Findings

### L1 (Low): `verify_vintage` trusts the last `index.csv` row for an id, so tampering plus one appended index row passes
**Where.** `feeds.py:1369` (`want = rows[-1]`). `load_vintage` (`feeds.py:1565`) relies on it.

**What.** Probe V5:
1. Edit `live_inputs.csv` in a saved vintage (41.0 -> 4100.0): `VintageIntegrityError`, as intended.
2. Then append one row to `vintages/index.csv` with the new hash: `load_vintage` accepts it, and `apply_vintage` writes
   4100.0 to `indicators.csv`.

`index.csv` is append-only by design, so the first row for an id is the one written at save time. Taking the last
row lets a later append override it.

**Exploit.** This needs local write access to `data/live`. It is a desk tool, so the realistic case is a sloppy manual
"fix" or a tool that re-indexes, not an outside attacker. It defeats the audit claim that the vintage applied is the
vintage pulled.

**Fix.** Require every index row for the id to carry the same hash and file count, and raise when they differ. Or use
the first row and treat later rows for the same id as an integrity error. Also compare the folder's hash8 suffix with
the recomputed hash, which `save_vintage` already guarantees for new ids.

**Test.** Tamper with a vintage, append a matching index row, and check that `load_vintage` raises
`VintageIntegrityError`.

### L2 (Low): `apply_vintage` on an older vintage silently rolls back newer values
**Where.** `feeds.py:1706-1740`.

**What.** Probe V6: after the newer vintage is applied, `apply_vintage(d, older_id)` re-applies the older vintage's
gate-ok cells over the newer values. It neither refuses nor warns. It only returns `latest_vintage` next to
`vintage_id`, and the docstring admits the behaviour. Older-vintage approvals bound by value also stay valid.

**Impact.** Integrity of numbers: a wrong `--vintage` (or a date id that resolves to an earlier pull) silently
reverts indicators. The pre-apply snapshot makes this recoverable, so it is Low.

**Fix.** When `vid != latest_vintage(d)`, raise unless the caller passes `allow_older=True`. Record the rollback in
the result and in the inputs snapshot, and have any future CLI wiring print it.

**Test.** `apply_vintage(d, older)` raises without `allow_older`, and applies with it.

### L3 (Low): `apply_vintage(cells=...)` writes approved apply decisions before its remaining refusals
**Where.** `feeds.py:1728` records the decisions. `feeds.py:1732` (no feed succeeded) and the second `load_vintage`
run only after it.

**What.** Probe V7, a vintage whose `feeds.json` shows no successful feed: `apply_vintage(..., cells=[FX])` raises
`VintageContentError` ("nothing applied"), but one approved apply row is already in the ledger. The docstring says
"raises before anything is written".

The ledger is append-only, and `_bound` binds by live value. So that approval can later release the same value in
another vintage, even though the operator saw the operation fail. This vintage can only be produced by hand or by a
legacy folder, because `save_vintage` refuses no-feed reports (EQ-A-0037). Hence Low.

**Fix.** In `apply_vintage`, run `load_vintage` and the no-feed check before `record_vintage_decisions`, then record,
then re-verify and apply.

**Test.** The V7 scenario writes 0 ledger rows.

## Info
- **I1. Value binding.** An approval binds by value across vintages (V3), which follows the SEC-A-001 L1 decision.
  Sam should know that approving a held value once also releases that same value in later pulls, until the value
  changes or someone holds or rejects the cell.
- **I2. Symlinked vintage folders.** `_is_vintage_dir` (`feeds.py:1312`) follows symlinks, so a symlinked folder under
  `vintages/` is listed and read. It still needs a matching index row. Optional fix: skip symlinked folders, as
  SEC-A-001 R1 does for replay snapshots.
- **I3. No cross-check between files.** `load_vintage` does not check that `review.csv`'s `live` equals the value in
  `live_inputs.csv` and `live_profile.csv`. Both files are in the same hash, so this matters only together with L1.
  Optional fix: refuse a vintage where a held cell's review `live` differs from the value `apply_report` would write.
  This also enforces that an approval binds to the exact number applied.
- **I4. No CLI yet.** `apply_vintage` is not wired to the CLI. When it is, the CLI should print `released`,
  `still_held` and any rollback (L2).

## Exploit scenario
No remote path, no credential handling and no four-eyes bypass were found. The residual risk is local integrity
(L1, L2) and a ledger approval that outlives a refused operation (L3).

## Fix
Owner: the Team A ingestion feeds.py owner (EQ-A-0035).

## Verification
```
python -m pytest -q tests/test_apply_vintage.py -p no:cacheprovider
python /tmp/claude-0/-home-claude-econquest-main/4d046af0-0329-5499-894e-87a0bbd3789c/scratchpad/sec3/probe35.py
```

Expected probe output after the fixes:
- V5: `tamper + index row refused`.
- V6: refused without `allow_older`.
- V7: `ledger rows written: 0`.
- V1 to V4 unchanged.

## Re-verification (2026-10-24, AGENT-09, EQ-A-0043)
Status: **fixed**. Fixed by EQ-A-0039. The CLI wiring of `allow_older` is from HO-20261024-A-C-003.
- **L1, fixed.**
  - V5: tamper plus an appended index row is refused: "2 rows in index.csv disagree on hash or file count".
  - `verify_vintage` (`feeds.py:1891-1924`) uses the first row, and requires all rows for the id to agree and the
    hash8 suffix to match the content.
- **L2, fixed.**
  - V6: `apply_vintage(d, older)` raises OlderVintageError.
  - With `allow_older=True` it applies, returns `rollback`, and writes `rollback.json` into the pre-apply snapshot.
- **L3, fixed.**
  - V7 (`feeds.json` with an `error:` feed) raises VintageContentError with 0 ledger rows written.
  - Residual edge: `{"feeds": {}}` or no `feeds` key skips the check (1 row written, then applied). It needs a
    hand-built vintage and is tracked as SEC-A-006 L5.
- **Tests and probe.**
  - `tests/test_apply_vintage.py`: passes.
  - Probe: `/tmp/claude-0/-home-claude-econquest-main/4d046af0-0329-5499-894e-87a0bbd3789c/scratchpad/sec43/probe39.py`.
