---
id: SEC-C-006
ticket: EQ-C-0053
author: C/AGENT-09
created: 2026-10-23
severity: low   # critical | high | medium | low | info
status: fixed          # L1 (EQ-C-0048) and L2 (EQ-C-0053) fixed; R1 to R6 are open recommendations
cwe: CWE-79 (stored XSS, defence in depth), CWE-755 (unhandled exception), CWE-1236 (formula injection, checked: none)
---
# PI-4 second review (EQ-C-0046/0048/0051/0053/0054/0055): raw pretrade field in GUI, market OSError traceback

## Finding
Found by reviewing `teamctl diff` for EQ-C-0046, 0048, 0051, 0053, 0054 and 0055, and by probing with concrete inputs in
throwaway temp dirs (fake SMTP, fake Popen, a copy of data/, no network, no sends, no live writes). `bandit -q -ll` on
every changed econquest file found nothing. Without `-ll` the only result is B105 at mc_band.py:99 (`"pass"` is a
verdict string): a false positive. There is no High or Critical finding, so nothing blocks a merge.

**L1 (EQ-C-0048). One pretrade.json field reached innerHTML raw (static/gui.html, `pretradeResult`).** The EQ-C-0048 fix
escaped the verdict, the proposal and the reasons. `${pt.paths}` was still interpolated raw into `#pt-verdict`. The
CLI writes an int there. A hand-edited or planted `outputs/pretrade.json` with `"paths": "<img src=x onerror=...>"` would
run script in the GUI origin, and that script can read the session token from the page's meta tag.

**L2 (EQ-C-0053). A folder given as the CSV or as `--dest` crashed `market import` and `market cds-quotes` with a
traceback (IsADirectoryError).** It failed closed: data/cds_quotes.csv was unchanged, the temp file was removed and the
action log row said `error`. The `except` in `cmd_market` caught FileExistsError but no other OSError.

**Recommendations (open, not fixed here):**
- **R1 (EQ-C-0051, Info). The confirm-once gate is evidence and a speed bump. It does not stop someone who can write
  both data/ and outputs/.** That person can add an address and also append a forged `confirm` row: the chain is
  unkeyed (SEC-C-005). `--confirm-new all-listed` confirms every new address in one go. It prints each one and records
  `note: --confirm-new all-listed`, but the runbook should tell the operator to name addresses, not use all-listed, when
  more than one is new. Optionally, refuse `all-listed` when more than N addresses are new.
- **R2 (EQ-C-0046 and every note, Low, pre-existing in `report.md_text`).** `md_text` escapes `< > & |` and folds
  newlines, but it lets Markdown link and emphasis syntax through. Probe: `rv_read = "[x](javascript:alert(1))"` in
  outputs/bond_rv.csv comes out as a live link in the country-note Markdown. Most renderers drop `javascript:` links.
  Backslash-escape `[ ] ( ) * _ `` ` `` in md_text (one shared helper, so every note and report gains it), with a test.
- **R3 (EQ-C-0053, Info).**
  - `market cds-quotes --dest` accepts any path. A symlink is replaced, not followed (probed: the target was intact),
    and the path is recorded in the action log.
  - The temp file is not fsynced before `os.replace`. Add `f.flush(); os.fsync(f.fileno())` so a power cut cannot leave
    an empty data/cds_quotes.csv.
- **R4 (EQ-C-0053, Info, Team A).** `market import --map` and `market enter` read the CSV with no size cap.
  `import_vendor_csv` caps the vendor file itself. Both paths are operator-given on a local CLI. Consider the same
  `max_bytes` for the map and for the enter file (handoff to A/AGENT-06 if wanted).
- **R5 (EQ-C-0048, Info).** install.sh reads only `$1`, so `bash install.sh --uninstall --bogus` uninstalls and
  ignores the typo. Refuse a second argument.
- **R6 (EQ-C-0053, Info).** `market import --init-map` writes data/live/market/ticker_map.csv when it is missing, but
  it is not in the action log. It never overwrites, so this is low value. Log it for completeness.

**Reviewed, no finding:**
- **EQ-C-0051 (`--confirm-new`):**
  - On `--send`, a new address is withheld until it is named. The confirm row (actor, recipient, config_sha256, ts) is
    chained and written under the send lock, and only on a real send. The dry run lists the addresses and writes
    nothing.
  - Probes refused each of these: `a@x,` (trailing comma), `,`, `all-listed,a@x`, `ALL-LISTED`, U+2028, CRLF+Bcc, a
    display name, and an address not in the subscriber list.
  - `a@x, b@x` confirms both.
  - Confirmation needs `--actor`.
  - The chain verifies after confirm and deliver rows.
  - Health alerts go to ECONQUEST_SMTP_TO, not to subscribers, so they are outside this gate by design.
- **EQ-C-0048:**
  - "Save publish plan (no write)" carries no `data-token`. Probe with ECONQUEST_SHEETS_TOKEN set in the server's
    environment: the job argv was `publish --dry-run --mc-rows 2000` and the child env had no token. An injected
    `--wr --token-f /x` was dropped. On the CLI side, `--dry-run` skips `resolve_token`, so neither the env var nor the
    Keychain is read.
  - `review list --pending` only reads data/live/review.csv.
  - install.sh: `--help`/`-h` exits 0, and `--bogus`/`--instal` exits 1. With a temp HOME and ECONQUEST_HOME, neither
    created anything (probed).
  - `dashboard.run_headline` and the `mcb` KPI band print numbers only.
- **EQ-C-0046 (RV views):**
  - Hostile probe of bond_rv.csv and cds_curves.csv: `<img onerror>` in country, as_of, snapshot_id and flags;
    `=IMPORTXML`, `-2+3`, `@A1`, ` +SUM`, `\t=1` in text and number columns; `1e400`, `-inf`, `nan`.
    - Country-note HTML: every value escaped by `_e`.
    - Markdown: no raw HTML, and a newline cannot start a heading (see R2 for links).
    - The 'Weekly RV' plan: every text cell went through `_block`/`safe_cell`, no formula lead survived, and
      non-finite numbers became blank.
  - GUI Relative value tab:
    - Every string goes through `esc()` or `table()`.
    - `emptyMsg` is pre-escaped.
    - The Plotly y labels, text, names and customdata are escaped.
    - The colour in `style=` comes from a fixed status map.
  - GET /api/rv sits behind the shared `_guard` and is GET-only. Its errors name the file, never a local path.
  - No runtime module loads tests/fixtures. The only grep hit is a docstring in engine/cds_curves.py.
- **EQ-C-0053 (market):**
  - `market` is not in ALLOWED_CMDS: `Jobs.start("market")` gives ValueError.
  - With market force-allowed, IDENTITY_CMDS strips these: `--au Sam`, `--se`, `--appro Bob`, `--author=`,
    `--approver=` and `--self-approved`.
  - Four-eyes on `enter` is `ledger.check_approval`. It refuses `alice`/`ALICE` and `alice`/` alice\t`, and refuses a
    missing approver unless `--self-approved` is given, which is recorded as `self_approved=yes`.
  - The licence is refused when it has:
    - a formula lead, including after leading whitespace;
    - a newline or an ESC control character;
    - placeholder text;
    - more than 128 characters.
  - The licence never reaches data/cds_quotes.csv. Its `source` column is `<source> <snapshot_id> [<vendor_ticker>]`.
  - In `enter`, vendor_ticker and doc_clause values with a formula lead or a newline are refused, as are an iso of
    `../x` and an asof of `../../etc`.
  - Atomic write: mkstemp in the same folder, then os.replace, with mode 0644. An empty result is refused. A failure
    leaves no temp file. A symlink `--dest` is replaced, not followed.
  - The action log records import, enter and cds-quotes, refused attempts included. JSON escapes control characters,
    and the gate and dry runs are not logged.
- **EQ-C-0054 (replicate):** a pass-through with an argument list (no shell). `--out` maps to `rep_out`, so the global
  `--out` is not shadowed. It is not a GUI command. Probe on a copy of data/: `--quick --only backtest,release` gave
  PASS 43, exit 0, and wrote only replication.csv and replication.md. The data/ sha256 manifest was identical before
  and after.
- **EQ-C-0055 (as_of, MC band):**
  - `garch --as-of` goes through `_as_of_arg`, and `_vintage_date` parses only `YYYY-MM-DD`.
  - mc_band formats floats only: `_num` rejects strings and non-finite values. Labels and statuses come from fixed
    sets, and `limits_html` takes the caller's escape.
  - The report, monitor and dashboard band cells are `band_text` output, which is numeric. The Markdown limits table has
    no file text.

## Exploit scenario
This is a local desktop tool with one operator.
- L1: someone who can write outputs/ plants a pretrade.json, and the next GUI visit runs their script with the
  session token. This is the same trust level as editing outputs/ directly, so the severity is Low.
- L2: no attacker gain. The operator gets a traceback instead of a message.

## Fix
- L1: static/gui.html `${esc(pt.paths)}`. Test:
  `tests/test_usability_fixes.py::test_gui_pretrade_verdict_escaped_and_labelled_as_saved` now asserts that no
  `${pt....}` other than the escaped reasons `.map()` is interpolated raw.
- L2: `cmd_market` catches OSError, which includes FileExistsError, and exits with `market <cmd>: <reason>`. Test:
  `tests/test_cli_market.py::test_directory_as_file_or_dest_is_a_clean_refusal`.

## Verification
```
python -m pytest -q -p no:cacheprovider tests/test_cli_market.py tests/test_usability_fixes.py tests/test_distribute.py \
  tests/test_rv_view.py tests/test_mc_band.py tests/test_cli_replicate.py tests/test_cli_as_of_passthrough.py \
  tests/test_gui_*.py tests/test_country_note.py tests/test_sheets_publish.py tests/test_report*.py \
  tests/test_risk_monitor.py tests/test_dashboard.py                       # 227 passed
bandit -q -ll econquest/ops/distribute.py econquest/cli.py econquest/presentation/{gui,rv_view,country_note,sheets_publish,mc_band,report,risk_monitor,dashboard,api}.py   # no findings
ruff check econquest/cli.py tests/test_cli_market.py tests/test_usability_fixes.py      # clean
python team/teamctl.py check                                                            # 0 problem(s)
```
