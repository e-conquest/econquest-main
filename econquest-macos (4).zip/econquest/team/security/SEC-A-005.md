---
id: SEC-A-005
ticket: EQ-A-0033
author: A/AGENT-09
created: 2026-10-23
severity: low   # critical | high | medium | low | info
status: fixed          # open | fixed | accepted-risk (needs EXC- id) | false-positive
cwe: CWE-532 (sensitive information in log/error output), CWE-209 (error message information exposure)
---
# Licensed vendor adapters: exact-match redaction, licence id can carry a pasted credential, partial licence-file secret check

Scope: EQ-A-0033, `econquest/ingestion/market/vendors/` (`base.py`, `bloomberg.py`, `lseg.py`, `pipeline.py`),
`tests/test_market_vendors.py` and `docs/runbooks/A-licensed-vendors.md`. It is a paid roadmap feature and is off by
default. New secrets:
- LSEG app key, platform user name and platform password (`ECONQUEST_LSEG_*`, or the keychain via lazy `keyring`);
- the B-PIPE application identity (`ECONQUEST_BPIPE_APP_NAME`);
- licence entitlements (`ECONQUEST_VENDOR_LICENCE_<VENDOR>` or `data/vendor_licences.json`).

Result: **no Critical, High or Medium finding.** Nothing blocks Done. There are three Lows and some Info notes.

## Method
- Code review of the four modules and the runbook.
- Probe script (not committed):
  `/tmp/claude-0/-home-claude-econquest-main/4d046af0-0329-5499-894e-87a0bbd3789c/scratchpad/sec3/probe33.py`. It reuses
  the in-memory blpapi and lseg.data fakes from `tests/test_market_vendors.py` and makes no network calls.
- `bandit -q -ll -r econquest/ingestion/market/vendors`: clean. The `# nosec B105` on `ENV_PASSWORD` is a genuine
  false positive: it holds the variable name.
- `pytest tests/test_market_*.py`: 160 passed.
- pip-audit is not applicable: blpapi and lseg-data are not in `pyproject.toml` yet (the extras were handed to Team C).
  Audit them when the extras land, and pin blpapi to Bloomberg's index.

## Verified OK
- **Secret sourcing.**
  - Credentials come only from the environment, else the OS keychain. `keyring` is imported lazily, and any keychain
    failure returns "no credential" with no detail.
  - Nothing comes from argv or a file.
  - The licence file refuses entries with credential-like keys, and malformed entitlements are refused without
    echoing their values.
  - `repr(adapter)` shows neither the key nor the password.
  - LSEG library exceptions are re-raised outside the `except` block, so `__context__` and `__cause__` are `None`,
    and the plain and `repr` forms of each credential are redacted.
  - Bloomberg errors carry only the exception type name and host:port, and the B-PIPE environment values are
    validated but never echoed.
  - Probe S9: after `pull_to_store`, no secret appears in the manifest, `quotes.csv`, `index.csv` or
    `cds_snapshots.csv`. The provenance holds licence_id, holder, scope, expiry, origin (an env variable name or the
    file path), the request and vendor error strings.
- **Licence gate.** `require()` runs in `snapshot`, `history`, `connect` and `pull_to_store` before any session or
  request. Probe S6 refuses all of these:
  - no licence;
  - an expired licence (`today > expiry`, UTC);
  - an empty environment variable (which falls back to the file, and there is no file);
  - an unknown scope.

  Nothing outside `vendors/` catches `VendorNotLicensed` (grep), so there is no silent fallback to free data. Every
  row carries `source` = the vendor slug and `licence` = `<slug>:<licence_id> (<scope>)`.
- **Ticker map.**
  - `plan()` refuses unmapped identifiers and rows not marked `verified` before any session opens (S7: the `verify`
    row is refused; the template ships every row as `verify`).
  - An answer for an identifier or field that was not requested raises (S8: `=EVIL()` is refused).
- **Formula injection.**
  - Requested tickers and vendor fields go through `text_problem`, including a leading-whitespace lead (S7: `=HYPERLINK(1)`
    and ` =1` are refused).
  - `vendor_ticker` is always the requested, validated identifier, never the vendor's echo.
  - Vendor values pass through `float()` only: string values such as `=cmd|...` and non-finite values are skipped as
    missing (S8), and the rows go through `validate_market`.
- **Write path.** Adapters never write. `pull_to_store` runs `save_market_snapshot`, then
  `cds_export.market_gate_review` (seeded only from rows that passed, the SEC-A-003 L5 fix), then
  `export_gated_cds_snapshots` for the new snapshot. With `dry_run=True` nothing is saved.

## Findings

### L1 (Low): credential redaction matches exact strings only
**Where.** `lseg.py:90` and `lseg.py:106` use `base.redact` (exact `str.replace`).

**What.** Probe S1 and S2. A library error that quotes a credential in another form passes through to the
`VendorConnectionError` message, and from there to stderr or a log:
- percent-encoded or `quote_plus` form: `password=p%40ss+w0rd%2F%26%3D%2B`;
- case-changed form of the app key.

The tests only cover the verbatim form.

**Exploit.** This is opportunistic. An HTTP or auth library error from the LSEG platform session that echoes the
form-encoded grant body or a lower-cased header would print the password or app key to the terminal and any captured
log on Sam's Mac. The library has not been tested against the real vendor, so its error texts are unknown. Low.

**Fix.** Choose one:
- Preferred: do not include the library's message text at all. Report `type(e).__name__` plus an allow-listed HTTP
  status if one can be extracted, as `bloomberg.py` already does.
- Or redact every encoded form too: `quote`, `quote_plus`, the case-folded form, and base64 of `user:pw`.

**Test.** An `open_error` and a `get_data` error that quote the URL-encoded password and the lower-cased key must not
contain them.

### L2 (Low): a mis-pasted credential is accepted as `licence_id` and written into every row
**Where.** `base.py:65` (`LICENCE_ID_RE`) and `base.py:133-168` (`parse_entitlement`).

**What.** Probe S4: `licence_id=<the LSEG app key>` is accepted (usable=True). The tag `lseg:<app key> (desk-internal)`
then goes into:
- the `licence` column of every row;
- the snapshot manifest and `index.csv`;
- `cds_snapshots.csv`;
- the `vendor status` output.

The module docstring says the licence id is the one value that is echoed, so a paste into the wrong field leaks the
key everywhere, durably, in append-only files.

**Fix.** Refuse a `licence_id` that equals or contains any credential this adapter can read (the `ECONQUEST_LSEG_*`
values from the environment or keychain, and `ECONQUEST_BPIPE_APP_NAME`). Optionally also refuse a long separator-free
high-entropy id (for example 24 or more alphanumerics with no `.`, `-`, `/` or `:`), and give a hint that licence ids
are contract references.

**Test.** An entitlement whose licence_id equals `ECONQUEST_LSEG_APP_KEY` is refused with a message that does not
contain the value.

### L3 (Low): the licence-file credential check covers only the top-level keys of the vendor's own entry
**Where.** `base.py:142`.

**What.** Probe S5: the file below loads without complaint, and both secrets stay in `data/vendor_licences.json`,
a file the runbook tells users to create and which is likely to be shared or committed.

```json
{"lseg": {..., "extra": {"password": "hunter2"}}, "lseg_app_key": "<key>"}
```

**Fix.** Walk the whole document recursively and refuse any credential-like key at any depth, in any vendor entry.
Also refuse unknown keys in an entry, accepting only `ENTITLEMENT_KEYS` and `id`.

**Test.** Nested and sibling credential keys are refused, and the error names the key, not the value.

## Info
- **I1. Secrets in memory.** After `connect()`, `vars(adapter)` holds `_secrets` (key, user, password) and `_env`
  (the whole environment), probe S3. This is only a risk if someone logs `vars()` or `__dict__`, or pickles the
  adapter. Optional: drop `_secrets` once the session is open, keep only a redaction helper, and do not keep a
  reference to `os.environ`.
- **I2. B-PIPE has no TLS.** `bloomberg._open` sets host, port and app identity but no TLS options. For a B-PIPE host
  that is not on a private link, ask the B-PIPE owner whether TLS (`blpapi.TlsOptions`) is required, and refuse a
  non-local host without TLS unless explicitly allowed.
- **I3. The licence gate is self-asserted.** Anyone who can set `ECONQUEST_VENDOR_LICENCE_<VENDOR>` enables the
  adapter. This is a contract record, not access control, and the vendor's own entitlement (Terminal or Workspace
  login, B-PIPE app) is the real control. The `desk-internal` and `redistribution` scope is recorded but not
  enforced on exports such as Sheets or outputs: a policy decision for Sam.
- **I4. Vendor error text in the manifest.** Strings from `securityError` and `fieldExceptions` go into the manifest
  `vendor_errors`, truncated. That is JSON, never a spreadsheet, so there is no injection risk. Keep it out of any
  Sheets export.
- **I5. Date stamping (correctness, not security).** `snapshot(as_of=None)` stamps the UTC pull date. A reference
  value read before the market closes, or across midnight UTC, may be the previous day's close. The runbook already
  advises `as_of=` or `history()` for dated closes.
- **I6. Re-audit before live use.** The wire formats have not been tested against a terminal. Re-run this review on
  first use against real blpapi and lseg-data, including those libraries' own logging configuration (log files in
  the working directory).

## Exploit scenario
No remote path and no licence-gate bypass were found, and nothing falls back to free data. The residual risk is a
credential reaching terminal or log output through an encoded echo (L1), or reaching durable files through a
mis-paste (L2, L3). All of these need a vendor licence to be configured first, and none applies while the feature
stays off.

## Fix
Owner: the Team A market vendors owner (EQ-A-0033). Fix L1 to L3 before the feature is enabled on a licensed
machine. They do not block merging the framework while it is off.

## Verification
```
python -m pytest -q tests/test_market_vendors.py -p no:cacheprovider
python /tmp/claude-0/-home-claude-econquest-main/4d046af0-0329-5499-894e-87a0bbd3789c/scratchpad/sec3/probe33.py
```

Expected probe output after the fixes:
- S1 and S2: `leaked=False` for every form.
- S4: refused.
- S5: refused.
- S6 to S9: unchanged.

## Re-verification (2026-10-24, AGENT-09, EQ-A-0043)
Status: **fixed** (EQ-A-0033 follow-up by AGENT-06). Probe:
`/tmp/claude-0/-home-claude-econquest-main/4d046af0-0329-5499-894e-87a0bbd3789c/scratchpad/sec43/probe33b.py`.
- **L1, fixed.** S1 and S2 report `leaked=False` for the URL-encoded, repr, lower-case and plain forms. LSEG errors
  now carry only the exception type (`LSEG platform session failed to open: RuntimeError`).
- **L2, fixed.**
  - S4: a licence_id carrying the app key is refused (usable False).
  - The key is not in the status or in the message ("24 or more letters and digits in a row and looks like a
    pasted key").
- **L3, fixed.**
  - S5: nested `lseg.extra.password` and sibling `lseg_app_key` are refused.
  - The keys are named, and no value is echoed.
- **I1, fixed.** S3: `vars(adapter)` holds neither the key nor the password after `connect()`.
- **S6-S9 unchanged.** The licence gate refuses all four cases, formula and unverified tickers are refused, and no
  secret appears in any written file.
- **Tests.** `tests/test_market_vendors.py` passes.

I2 (B-PIPE TLS) and I3 (a self-asserted licence) remain Info and do not block.
