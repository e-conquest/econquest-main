---
id: SEC-A-003
ticket: EQ-A-0029
author: A/AGENT-09
created: 2026-10-23
severity: medium   # critical | high | medium | low | info
status: fixed           # open | fixed | accepted-risk (needs EXC- id) | false-positive
cwe: CWE-345 (insufficient verification of data authenticity), CWE-1236 (CSV formula injection), CWE-354 (integrity check)
---
# PI-4 market data: gate and attestation bypass on the CDS snapshot export, plus lows

Covers EQ-A-0029 (schema, store, importers, ticker map template), EQ-A-0030 (public.py, forwards.py),
EQ-A-0031 (gate.py), EQ-A-0032 (manual.py and ledger.attest_rows/attested_content) and EQ-A-0034
(schema.to_cds_snapshots, store.append_cds_snapshots/export_cds_snapshots, universe.py tier validator).
Note: the brief swapped two ticket numbers. In the code and the diffs, gate.py is EQ-A-0031 and manual.py is EQ-A-0032.

Result: **no Critical or High finding.** Nothing blocks Done. There is one Medium (M1), to fix before Team B wires
`engine/cds_curves.py` to `data/market/cds_snapshots.csv`. There are four Lows and some Info notes.

## Method
- Manual review of every file in `econquest/ingestion/market/`, of `ticker_map_template.csv`, of the ledger
  additions and of the `teamctl diff` for each of the five tickets.
- Probe script (not committed):
  `/tmp/claude-0/-home-claude-econquest-main/4d046af0-0329-5499-894e-87a0bbd3789c/scratchpad/sec3/probe.py`. It runs
  against a temporary data dir and makes no network calls.
- `bandit -q -ll -r econquest/ingestion/market`: clean.
- `pip-audit` runs against the cloud environment, not a lock file. It reports nothing for the project's runtime
  dependencies, apart from certifi 2026.10.18 (PYSEC-2026-4320, fixed in 2026.10.19), which comes from the environment.
  The market package adds no new dependency: it uses only the stdlib, pandas and numpy.
- `pytest tests/test_market_*.py`: 110 passed.

## What is already right (verified)
- **FRED key.** It comes only from `$FRED_API_KEY` and must fullmatch `[a-z0-9]{32}`, so it cannot inject query
  parameters. It goes through `events.base.http_fetch` (https only, no-redirect opener, unredirected headers,
  final-URL check, 50 MiB cap), so the SEC-A-002 redirect leak does not recur. `_fetch` and `fetch_fred` redact
  query strings and the key from every message. Probe P5: the key does not appear in the message of a fetcher
  exception, in a FRED `error_message` that echoes the key, in the formatted traceback, in `attrs['provenance']` or in
  the rows.
- **Text cells.** `validate_market` refuses cells that start with `= + - @ TAB CR`, contain control characters or
  exceed 128 characters, in every text column. The importers refuse formula-like cells in the whole vendor file before
  parsing. Dates are parsed with explicit formats only. There is a byte cap and a row cap. No pickle, no eval, no
  subprocess.
- **Snapshot ids and paths.** Folder names come from the clock and a content hash. `read_market_snapshot` and
  `list_market_snapshots` fullmatch `SNAPSHOT_ID_RE`. Folders use `mkdir(exist_ok=False)` and files are 0444.
  The index is appended under `flock`. There is no path traversal.
- **Licences.** Placeholder licences are refused. `n/a (hand-entered)` is accepted only with source `manual`. Manual
  rows cannot carry a vendor source or licence (`_complete`), and the importers fix the source to the profile.
- **Ticker map.** All 186 template rows are `status=verify`, so an import refuses every identifier until a human
  marks the row verified. `ensure_ticker_map` never overwrites an existing map.
- **cds_snapshots.csv.** Writes are append-only under a lock. A changed row with the same key raises instead of
  overwriting.
- **universe.py tier validator.** The tier is checked against the ENUMS and must match the proposal. No new input path.

## Findings

### M1 (Medium): every saved CDS quote reaches Team B's `data/market/cds_snapshots.csv`, bypassing both the market gate and the manual-quote attestation
**Where.** `store.py:99-100` (`save_market_snapshot` always calls `append_cds_snapshots`), `store.py:118-148` and
`151-162` (`export_cds_snapshots`), `schema.py:265-318` (`to_cds_snapshots`).

**What.**
- The gate is enforced on one consumer path only. `cli.py:699-701` (`market cds-quotes`) drops held series before
  writing `data/cds_quotes.csv`.
- The second engine-facing output, `cds_snapshots.csv`, is written at save time, before any gate runs. It takes
  every CDS spread or upfront row, including rows the gate would hold for range, curve, jump or basis.
- It also takes manual rows whose attestation was withdrawn by a later hold or reject in the ledger, and
  `source=manual` rows saved through `save_market_snapshot` directly (by `save_public`, `save_forwards`, a script or a
  notebook) that were never attested. `to_cds_snapshots` has no notion of either check.
- The file is append-only, so a bad row cannot be withdrawn. It can only be superseded by a later capture.

Probe P2 and P3:

```
manual 5y BRA 150 -> 45000 (self-approved fat finger): gate -> hold "jump: 150 -> 45000 (+29900%)"
cds_snapshots.csv row ...T180008Z-d2ac096c:BRA:2026-10-22:manual:USD:CR14  value 45000   (written anyway)
ledger reject on that cell -> unattested_manual() lists it; latest_market and to_cds_quotes still serve 45000
save_market_snapshot(source=manual, value 999, no attestation) -> cds_snapshots.csv grows, latest = 999
```

**Exploit scenario.** No attacker is needed. This is a desk tool, and the realistic trigger is a typo or a bad
`scale` in the ticker map: 2500 bp typed for 250, or pips mapped as points. The gate catches it, and `cds-quotes`
excludes it. But once `engine/cds_curves.py` reads `cds_snapshots.csv` (HO-20261023-B-A-009), the hazard curve and
the spreads priced from it use the held value, with a licence and an attestation trail that look clean. Today no
production code reads the file, so the impact is latent. That is why this is Medium and not High.

**Fix.** Owner: Team A market (store.py, schema.py), coordinating with Team B on HO-B-A-009. Choose one of these:
- (a) Preferred: stop appending inside `save_market_snapshot`. Make the export an explicit gated step, through
  `export_cds_snapshots` or a new `market cds-snapshots` CLI. It runs `market_gate` (the same `previous` as
  `cli._market_gate`), drops held series, and drops `source=manual` rows that are not in
  `ledger.attested_content(data_dir, "market_manual")` for their current content. List the dropped rows in the output.
- (b) Keep the append at save time, but add a `gate_status` and an `attested` column (Team B contract change), so
  `cds_curves.validate_snapshots` refuses held or unattested rows.

With either option, `export_cds_snapshots` must apply the same filter. Otherwise a backfill re-imports everything.

**Tests.**
- A jump-held CDS row saved through `enter_quotes` or `save_market_snapshot` does not appear in `cds_snapshots.csv`,
  or appears with a hold marker.
- A manual row with a later `reject` in the ledger is excluded.
- A `source=manual` row saved without `enter_quotes` is excluded.
- A clean vendor row still flows through.

### L1 (Low): author and approver are written unneutralised to `manual_quotes.csv` (CSV formula injection)
**Where.** `manual.py:93` takes `author` and `approver` from `ledger.check_approval`, which only normalises them.
`manual.py:102-107` writes them raw.

**What.** Probe P1: the authors `=HYPERLINK("http://x","a")`, `@SUM(1)` and `+1+cmd` are accepted and stored
verbatim. The ledger neutralises the same values (SEC-A-001 L4), but this new append-only file does not. `note` is
checked with `text_problem`. Author and approver are not.

**Exploit.** This needs a local user, or a CSV passed to `econquest market enter --author ...`. It fires when
`manual_quotes.csv` is opened in Excel or pasted into Sheets. The impact is low for a one-desk tool.

**Fix.** In `enter_quotes`, refuse `author` or `approver` when `text_problem()` is non-empty, the same rule as `note`
and the schema ("refused, not escaped"). Test: `enter_quotes(..., author="=1+1")` raises `MarketDataError`, and
nothing is appended to `manual_quotes.csv` or the ledger.

### L2 (Low): the licence column is not stripped, so a leading-whitespace formula passes the guard
**Where.** `schema.py:141`: every text column is stripped before `text_problem` except `licence`.

**What.** Probe P4: `licence_problem(' =HYPERLINK("http://x")', "bloomberg")` returns `''`, so the value is
accepted and stored with its leading space.
- Most spreadsheet apps treat a leading space as text.
- Some CSV import paths, and code that later calls `.strip()` before pushing to Sheets with USER_ENTERED, turn it
  back into a formula.
- The licence is a free `--licence` argument on `market import`, so the trigger is a user typing it.

**Fix.** In `text_problem`, test `v.lstrip()` (and ` `) against `FORMULA_LEAD`, or refuse leading or trailing
whitespace in the licence. Test: `licence_problem(" =1+1", "bloomberg")` is non-empty.

### L3 (Low): CIP-derived forwards drop the input licence restrictions (licence-tag laundering)
**Where.** `forwards.py:155-157` builds the derived row licence as
`derived (CIP) from yahoo+fred+fred; input licences apply`. It falls back to a text with no source names when longer
than 128 characters. The licence is `forwards.py:57`, `YAHOO_LICENCE`:
`... personal non-commercial use (unverified)`.

**What.** A forward built from Yahoo spot carries a licence that no longer says "non-commercial". Downstream, the row
looks like a freely usable derived quote. The provenance holds the inputs, but only in the manifest, not in the row.
Separately: Yahoo's terms are very likely incompatible with use on a desk. Sam should confirm this, and record an
EXC- entry if he accepts it.

**Fix.** Build the derived licence from the input rows' licence strings. If any input licence contains
`non-commercial` or `unverified`, keep that marker, for example
`derived (CIP); inputs: yahoo [non-commercial, unverified] + fred + fred`. Alternatively, refuse `--spot yahoo` unless
a flag records that Sam accepts the risk. Test: a forward from `YAHOO_LICENCE` spot has `non-commercial` in its
licence.

### L4 (Low): snapshot integrity check is self-referential
**Where.** `store.py:181-184`.

**What.** `read_market_snapshot` checks `quotes.csv` only against the `manifest.json` in the same folder. Probe P6:
after `chmod u+w`, someone can edit a quote (150 -> 15) and the manifest sha256, and the snapshot is then read as
valid. Three independent anchors exist but are never checked: the `hash8` in the snapshot id (the content hash with a
blank snapshot_id), `manifest.content_hash`, and the `sha256` column of the append-only `index.csv`. 0444 does not
stop the owner. This needs local write access, so it is Low: it matters for audit and for accidental edits in Excel.

**Fix.** In `read_market_snapshot(verify=True)`:
1. Recompute the content hash with `snapshot_id` blanked, and require that it starts with the id's hash8 and equals
   `manifest.content_hash`.
2. Require that the body sha256 equals the `index.csv` row for that id.

Test: tamper with both `quotes.csv` and `manifest.json`. The read must raise `MarketDataError`.

## Info (no action required; noted for owners)
- **I1. Exception context.** `public._fetch` raises `... from None`. That suppresses the context when printed, but
  `e.__context__` still holds the original fetcher exception, and its text may include the full URL with `api_key`
  (probe P5: key in `__context__` True, in the formatted traceback False). This is only a risk if someone serialises
  `__context__` (Sentry-style). Optional: set `e.__context__ = None` before raising, or raise outside the `except`
  block.
- **I2. Unvalidated vintage dates.** `public.parse_fred_json` validates `date`, but not `realtime_start` or
  `realtime_end`. Those values feed the ALFRED vintage filter (string comparison) and `vendor_ticker`. Validate them
  as ISO dates, allowing `9999-12-31`.
- **I3. Not point-in-time.** `forwards.main` (`forwards.py:228`) uses `market_history(d)` with no as-of, so a
  historical `--asof` run uses later corrections. This affects correctness, not security.
- **I4. Holds do not stop a save.** `public.main` and `forwards.main` save snapshots even when the gate holds rows.
  That is acceptable by design: the store keeps everything and the consumers gate, which is why M1 matters.
- **I5. Cosmetic.** The FRED error label reads `api.stlouisfed.org//fred/...` with a double slash
  (`"/".join(urlsplit(base)[1:3])`).

## Exploit scenario
See each finding. Summary: no remote attacker path, no credential exposure, and no code execution from untrusted
files. The material risk is integrity: wrong CDS numbers reaching the curve engine through the ungated
`cds_snapshots.csv` path (M1).

## Fix
Owners:
- M1, L4: the store/schema owner on Team A, with Team B for the HO-B-A-009 contract.
- L1: the manual.py owner.
- L2: the schema owner.
- L3: the forwards.py owner, plus a licence decision by Sam.

## Verification
After the fixes:

```
python -m pytest -q tests/test_market_schema.py tests/test_market_manual.py tests/test_market_forwards.py tests/test_market_gate.py -p no:cacheprovider
bandit -q -ll -r econquest/ingestion/market
python -I /tmp/claude-0/-home-claude-econquest-main/4d046af0-0329-5499-894e-87a0bbd3789c/scratchpad/sec3/probe.py
```

The probe must show:
- P1: the formula authors are refused.
- P2 and P3: the 45000 and 999 rows are absent from `cds_snapshots.csv`.
- P4: a non-empty licence problem.
- P6: `read after tamper` raises.

## Fixes (re-verified by A/AGENT-09, 2026-10-23, EQ-A-0038)
Re-checked independently with `teamctl diff --ticket EQ-A-0038`, the fixer's probe
(`.../scratchpad/eqa38/probe_eq_a_0038.py`) and a separate probe of my own
(`/tmp/claude-0/-home-claude-econquest-main/4d046af0-0329-5499-894e-87a0bbd3789c/scratchpad/sec3/probe38b.py`).
`pytest tests/test_market_*.py tests/test_apply_vintage.py`: 140 passed. `bandit -ll` on the market package: clean.

### Fixed
- **M1: fixed.**
  - `save_market_snapshot` no longer writes `cds_snapshots.csv`. The only writer is `cds_export.export_gated_cds_snapshots`,
    reached directly or through `store.export_cds_snapshots`. No other caller of `_append_cds_snapshots` exists in
    `econquest/`.
  - The gate hold of the 45000 fat finger is dropped. A manual row whose attestation was rejected is dropped. An
    unattested in-range `source=manual` row (COL 151) is dropped by the attestation check (probe Q2).
  - Rows exported before a later reject are reported as `already_in_file`. The file stays append-only.
- **L1: fixed.** `=HYPERLINK(...)`, `@SUM(1)` and `+1+cmd` as author are refused before anything is written
  (`manual.py`, after `check_approval`).
- **L2: fixed.** `text_problem` also checks `v.lstrip()`, which covers ` =`, `\u00a0=` and `\u3000=`. A zero-width
  space lead (`\u200b=1`) still passes. It is not a formula in Excel or Sheets, so this is informational.
- **L3: fixed.** `derived_licence` carries every input licence verbatim, or the restrictive markers. Yahoo inputs give
  `input restrictions: non-commercial, personal, unverified`. A forward whose markers cannot fit is refused. Sam's
  decision on desk use of Yahoo is still open, as a governance item, not a code item.
- **L4: fixed.** A tamper of `quotes.csv` plus the manifest sha256 now raises (content hash, id hash8 and `index.csv`
  sha256).
- **I1 and I5: fixed.** The key is in neither `__context__` nor `__cause__`, and the label has no double slash.

### Still open
- **I2 and I3: open.** They are informational and were not required.

### New residual: L5 (Low, open), found while verifying M1. A repeated save launders a gate-held value through the gated export.
**Where.** `cds_export._gate_holds` (the `prev` built from every earlier snapshot). `cli._market_gate` has the same
semantics for `market cds-quotes`.

**What.** The jump check seeds from the previous value of the series, and that includes values the gate held.

Probe Q1, vendor rows:
1. Save 150, then 45000. The 45000 row is held and dropped.
2. Save 45000 again, for example when the analyst re-runs `market import` on the same file. The seed is now the held
   45000, so there is no jump, and the row is exported: `cds_snapshots.csv` = `[150, 45000]`.

Manual rows are still caught by the attestation check, but only when the re-entry is not attested.

**Impact.** No attacker is needed, only a plausible re-run. The first export's dropped-row report does show the hold.
That is why this is Low.

**Fix.** Seed `previous` only from rows that passed the gate (or from the last exported value per series), in
`cds_export` and in `cli._market_gate`, so that a held value can never become its own seed.

**Test.** Save 150, 45000, 45000, then export: the second 45000 is still dropped with a jump hold.

### L5 re-verified as fixed (A/AGENT-09, 2026-10-23, during the EQ-A-0033 review)
`cds_export.gated_history` and `market_gate_review` now seed the gate only from rows that passed it, and
`cli._market_gate` (cli.py:627-633) calls `market_gate_review`. Re-running probe Q1 (save 150, then 45000, then 45000):
both 45000 rows are held, and `cds_snapshots.csv` = `[150]`. `pytest tests/test_market_*.py`: 160 passed.

All SEC-A-003 findings are fixed, so the status is now **fixed**. The severity field records the highest severity
found (M1). I2 and I3 remain as information only.
