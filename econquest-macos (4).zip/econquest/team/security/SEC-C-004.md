---
id: SEC-C-004
ticket: EQ-C-0034
author: C/AGENT-09
created: 2026-10-23
severity: medium   # critical | high | medium | low | info
status: fixed          # open | fixed | accepted-risk (needs EXC- id) | false-positive; R1 and R2 are open recommendations
cwe: CWE-807 (security decision on client input), CWE-636 (not failing securely), CWE-15 (external control of configuration), CWE-116
---
# PI-3 review (EQ-C-0033..0038): GUI could pass --allow-unattested past the Sheets-write block; override not fail-closed on logging; compliance.json ungoverned; feed text raw in Markdown

## Finding
Found by manual review of `teamctl diff` for EQ-C-0033 to EQ-C-0038, plus probes. No High or Critical.

**M1 (EQ-C-0034). The GUI passed `--allow-unattested` through to jobs (presentation/gui.py `Jobs.start`).** The default
policy blocks every Sheets write (`sheets_write: block`) while hand-entered cells are unattested. A GUI request
`{"cmd": "publish", "args": ["--allow-unattested"], "sheets_token": ...}` got `--write` from the server and kept the
override, so the write went through. GUI jobs carry no identity. In the action log, the override was attributed to
`$USER` ("os"), not to a person who chose it. argparse prefixes (`--allow`, `--a`) did the same.

**L1 (EQ-C-0035). The run-gate override did not fail closed when it could not be logged (cli.py `_record_action`).** The
override's only control is "recorded in the action log". A logging failure (disk full, unwritable store/, a broken
`$ECONQUEST_ACTION_LOG` path) was a stderr warning, and the blocked write then went through with no record.

**L2 (EQ-C-0035). SMTP password and webhook URL were not in the action log's mask list.** Option names matching
token/password/secret/webhook are dropped, and the Sheets token value is masked anywhere. But
`$ECONQUEST_SMTP_PASSWORD` and `$ECONQUEST_ALERT_WEBHOOK` (the URL is the secret) would have been logged verbatim if
an error message carried them.

**L3 (EQ-C-0037/0038). Feed-derived text went raw into the Markdown products (report.sources_md,
events_view.monitor_events_md).** HTML was escaped everywhere: fuzzed with `<script>` in event_type, source and
retrieved, and the GUI Events tab passes every string through esc()/table(). In Markdown, however, a provenance or
event-feed `source` with a newline could start a fake `## Sources` section, which the compliance `sources` check
reads. It could also carry raw HTML into any viewer that renders Markdown, and a `|` broke the table.

**Recommendations (open, not fixed here, outside a 20-line change):**
- **R1 (EQ-C-0036, Medium). compliance.json is not governed.** `outputs/editorial/compliance.json` sets who may sign
  off and whether self-sign is allowed. Anyone who can write outputs/ can edit it with no review: add themselves to
  `approvers`, or flip `allow_self_sign` back to true after Sam turns it off. The sign-off row records the config's
  sha256, which is evidence after the fact, not a gate. The default is already the weakest setting (self-sign
  allowed, anyone approves), so today an edit cannot weaken the gate below the default. It can only undo a tightening.
  - Recommended: move the file to `data/compliance.json` and add it to `ops/approvals.FILES` (change propose,
    approve, apply with four-eyes, plus drift detection).
  - Until then: at publish, refuse when the config's sha256 differs from the one recorded at sign-off, and have
    `editorial verify` / health report a config whose sha256 matches no `change` apply.
- **R2 (EQ-C-0036, Low).** A self-sign is recorded as an exception text, but unlike `change approve --self-approved` it
  needs no `EXC-nnn` id from docs/governance/issues-log.md. Require one for consistency with model-risk-policy s.4.
- **R3 (EQ-C-0034, Info).** Policy overrides through `ops.json` or `$ECONQUEST_RUN_GATE` (for example `off`) are not
  recorded. Recommend adding the effective policy to the action-log row when it differs from RUN_GATE_DEFAULT.

**Reviewed, no finding:**
- EQ-C-0034:
  - The write decision comes from the parsed flags (`--write`, `--token-file`, legacy `--token`; argparse prefixes
    resolve first), never `--dry-run`, and the gate runs before any token lookup.
  - Fail-closed: an unreadable ledger blocks when the mode is block, unreadable or invalid ops.json / env values exit,
    and any other exception aborts the command.
  - `--allow-unattested` is recorded with the counts and policy.
- EQ-C-0035:
  - The log lives in `<out>/store/actions.jsonl`, which is backed up and never replaced by install.sh.
  - Chain, head and flock are the approvals helpers.
  - Token, token_file and the resolved Keychain token are masked (key and value). A broken chain is reported by
    `log verify`, not refused (correct: the action already happened).
- EQ-C-0036:
  - The four-eyes sign-off uses person_key, and a configured approver list restricts who may sign.
  - Sign-off is refused until items 1 to 4 pass.
  - Void-on-later-row: any later conflicts or acknowledge row voids the sign-off, and a review cannot recur (draft only).
  - Publish reruns the automatic checks and refuses changed files. No bypass found.
- EQ-C-0037: the `econquest:sources` stamp JSON escapes `<`, `>` and `--` (as `<`, `>`, `--`), so no
  `-->` / `--!>` can close the comment, and it round-trips through `_STAMP` + json.
- EQ-C-0038: GET /api/events sits behind the same `_guard` as the other GETs. The response holds file names only
  (checked: no absolute path in the summary). gui.html escapes every inserted string, Plotly labels included.
- EQ-C-0033: every plan is still escaped centrally. `save_plan` and `apply_plan` run `sanitize_plan` on every block
  whatever builds it (layout_v2, garch, econ), and no other write path exists (grep for urlopen/batchUpdate).
  republish_preview keeps the EQ-C-0027 CSV escaping.

## Exploit scenario
Local desktop tool, GUI on 127.0.0.1 with a session token and an Origin check.
- M1: a GUI user, or a bug in the page, publishes to the live workbook despite unattested hand-entered CDS or
  prediction-market cells. The action log blames `$USER`, not a named operator.
- L1: the same bypass from the CLI with no trace, when the log cannot be written.
- L2: a webhook URL or SMTP password ends up in a file that is backed up nightly.
- L3: a crafted feed string makes a Markdown product look compliant, or renders HTML in a Markdown viewer.
- R1: one person loosens the compliance approver rule and signs their own product.

## Fix
- M1: `gui.Jobs.start` drops any argument that is a prefix (3 or more characters) of `--allow-unattested`, for every
  command. Test: `tests/test_run_gate.py::test_gui_strips_allow_unattested` (`--allow-unattested`, `--allow-u`,
  `--allow`, `--a`).
- L1: `cli._record_action(..., strict=True)` for the override. If the row cannot be appended, the invocation exits
  `RUN_GATE_EXIT` before the command runs. Test: `test_override_that_cannot_be_logged_is_refused`.
- L2: `cli.main` adds `$ECONQUEST_SMTP_PASSWORD` and `$ECONQUEST_ALERT_WEBHOOK` to the masked secrets. Test:
  `test_smtp_password_and_webhook_masked_in_action_log`.
- L3: `report.md_text` puts the text on one line and escapes `& < > |`. It is applied to the source names in
  `sources_md` and to the message, rows and source note in `events_view.monitor_events_md`. Test:
  `tests/test_events_view.py::test_feed_strings_are_neutralised_in_markdown`.

## Verification
```
python -m pytest -q -p no:cacheprovider tests      # full suite
bandit -q -r econquest -ll                          # no findings
```
