---
id: SEC-C-005
ticket: EQ-C-0045
author: C/AGENT-09
created: 2026-10-23
severity: low   # critical | high | medium | low | info
status: fixed          # L1 and L2 fixed under EQ-C-0045; R1 to R5 are open recommendations
cwe: CWE-522 (credentials in a mailed link), CWE-754 (unchecked log row type), CWE-93 (CRLF injection, defence in depth), CWE-284
---
# PI-4 review (EQ-C-0040/0041/0045/0047): archive_base_url credentials, delivery-log non-object rows, compliance config reset by deletion

## Finding
Found by reviewing `teamctl diff` for EQ-C-0040, 0041, 0045 and 0047, plus concrete probes in throwaway temp dirs
(fake SMTP, nothing sent, no network). bandit -ll found nothing in the changed files. There is no High or Critical
finding, so nothing blocks a merge.

**L1 (EQ-C-0045). `archive_base_url` accepted credentials, a query and a fragment (ops/distribute.py `load_config`).**
It is checked with `check_webhook_url`, which needs https (or http to loopback) but allowed
`https://user:pw@archive.example.com/`. That URL is copied into every subscriber's email. A `?x=` or `#top` base
also swallowed the item path, so every recipient got the same, wrong link.

**L2 (EQ-C-0045). A non-object JSON line in `outputs/store/deliveries.jsonl` crashed `verify`, `plan`, `status` and
`send` with AttributeError.** Examples are `[]`, `1`, `"x"` and `null`. It failed closed, because nothing was sent, but
`distribute verify` gave a traceback instead of reporting the broken chain.

**L2b (EQ-C-0045, defence in depth).** `header_safe` refused CR, LF, NUL, U+2028/9 and NEL. VT, FF and FS/GS/RS
(`\x0b \x0c \x1c-\x1e`) got through config validation. No header injection happened: the email package refused at
send time, and every recipient got an `error:` row. They are now refused when the config loads.

**Recommendations (open, not fixed here):**
- **R1 (EQ-C-0040, Low). The compliance config falls back to the weakest default when it is deleted along with
  `data/approvals/`.** After Sam tightens `allow_self_sign` to false through change, deleting both
  `data/approvals/` and `data/compliance.json` makes `load_config` return status `default` again, with self-sign
  allowed and anyone approving. Probe confirmed. An empty log with no head verifies as ok. The sign-off row does
  record `config_status: default`, and the deletion also drops assumptions/limits to `no_baseline`. Recommended fix:
  refuse a `default` config when the editorial ledger has an earlier sign-off with `config_status: ok`, which anchors
  it in the ledger. Also have `econquest health` alert when `data/approvals/log.jsonl` is missing or empty, since the
  release ships a non-empty one.
- **R2 (EQ-C-0040, Info). The first `change baseline compliance.json` needs only an actor.** That is the general
  baseline rule, so a never-governed file can be baselined by one person with any valid content (for example
  `approvers: ["Mallory"]`). This cannot weaken the gate: the shipped default is already the weakest setting, and
  once a change was applied, a re-baseline needs four-eyes. The `legacy_problem` message for a missing data file
  advises exactly this single-actor baseline. Consider requiring `--approver` (or `--self-approved --exc`) for any
  non-default first baseline of compliance.json.
- **R3 (EQ-C-0041, Low). The EXC id is checked for shape only.** An id missing from `docs/governance/issues-log.md` is
  only noted (`[EXC-nnn not yet in issues-log.md]`), as with `change approve`. The README example uses
  `--exc EXC-001`, which is the existing data-quality-gate exception, so it invites reuse of an unrelated exception.
  Sam should log a dedicated EXC for compliance self-sign, and the README example should use a placeholder
  (`EXC-nnn`). Optionally, refuse an id that is absent from the issues log when the log is present.
- **R4 (EQ-C-0045, Low). `data/distribution.json` is not under change control.** Anyone who can write `data/` can add
  an external address, and the next `--send` mails archive links and file hashes there. The delivery row records
  `config_sha256`, and the dry run lists every recipient, which is evidence, not a gate. Consider adding it to
  `approvals.FILES` (optional file), or have `distribute send --send` print and require confirmation of recipients
  added since the last send.
- **R5 (EQ-C-0045, Info).**
  - With no `archive_base_url`, the link is a `file:///Users/<name>/econquest/outputs/published/...` path. It
    discloses the local user name and directory layout, and it is useless to any other machine. Prefer refusing
    `--send` to non-local recipients without a base URL, or say so in the runbook.
  - `http://localhost` is accepted as a base URL. The mailed link then points at the recipient's own loopback.
  - The address regex accepts some invalid addr-specs, such as `.a..b@example.com`. The SMTP server rejects them;
    there is no security impact.
  - If a crash happens between a successful SMTP send and the delivery-log append, the next `--send` repeats that
    message. That is acceptable at-least-once delivery.

**Reviewed, no finding:**
- EQ-C-0040:
  - Sign-off is refused on drift, on a deletion after apply, on non-default content that was never baselined, on a
    broken approvals chain, and on a legacy `outputs/editorial/compliance.json` that differs or is invalid. All five
    were probed.
  - An equivalent legacy file is ignored, and the file is never migrated.
  - `change propose` validates content with `validate_config`.
  - Publish reloads the config.
  - install.sh puts compliance.json in MANAGED_DATA under the approvals-log-prefix rule. distribution.json is not in
    that list, so it is kept on reinstall.
- EQ-C-0041: `check_exc` is shared with `change approve`. `None`, `""`, `EXC-1`, `exc-001`, `EXC-001x` and `GOV-001`
  are refused (tested). The id is stored in the sign-off row and the exception text.
- EQ-C-0045:
  - Header injection: CR, LF and the other line-break characters are refused in addresses, the subject prefix,
    as_of, kind, item id, actor and From. The email package (policy.default) refuses them again at send time.
  - Addresses are plain addr-spec, ASCII only (a Cyrillic homoglyph is refused), with no display name, comma,
    brackets or IP literal.
  - Only published items are sent, and only when their archive copy verifies: withdrawn and tampered items are
    skipped (tested).
  - The dry run is the default. It never constructs smtplib.SMTP (`NoNetwork` test) and never calls the Keychain
    (probe).
  - STARTTLS fails closed: a server without STARTTLS gives an `error: ConnectionError` row, with no login and no
    plaintext send (probe). Port 465 uses SMTP_SSL with a verifying context.
  - The password is masked in delivery rows, stdout and the action log, for both env and Keychain sources. Probe: a
    server reply echoing user and password was logged as `***`.
  - The hash chain detects edited, deleted and moved rows, a missing head and a stale head. A broken chain refuses
    queue and send. Like the approvals log, the chain is unkeyed, so someone rewriting the log and the head together
    can forge it (documented in approvals.py).
  - Messages go one per recipient. The `To` header is only that recipient, with no Cc or Bcc. A user-set
    `ECONQUEST_SMTP_TO` list is overridden (probe).
  - `.ops.env`: the job loader refuses a file that group or others can read. `build_release.is_secret(".ops.env")`
    is True (`*.env` in SECRET_GLOBS), so it is excluded from the release zip. install.sh never copies over it.
    The runbook advises `chmod 600`, and the Keychain for the password.
  - The publish hook only queues, and a queue failure does not undo the publish.
  - health.py's alert-latency logging cannot fail a health check.
- EQ-C-0047:
  - GET /api/ideas sits behind the shared `_guard`. A foreign Host gets 403 (tested). POST is refused.
  - gui.html passes every inserted string through `esc()`, `table()` (which escapes) or `textContent`, Plotly
    labels included.
  - `ideas_plan` text goes through `_block`/`safe_cell`. Probe: `=HYPERLINK`, `-2+3` and `=IMPORTXML` were written
    as text, and NaN was written blank. `sanitize_plan` still runs centrally at save/apply.
  - The escaped `idea_report.csv` is never read.

## Exploit scenario
This is a local desktop tool with one operator.
- L1: a base URL with an embedded basic-auth credential would be mailed to every subscriber.
- L2: a corrupted or tampered delivery log stops `distribute verify` with a traceback instead of a report.
- R1: someone with write access to `data/` undoes Sam's tightening of the compliance self-sign rule by deleting two
  paths. This leaves evidence but is not refused.
- R4: the same person adds an outside address to the subscriber list.

## Fix
- L1: `distribute.load_config` refuses an `archive_base_url` with a user name, password, `@` in the netloc, a query
  or a fragment. Test: `tests/test_distribute.py::test_archive_base_url_refuses_credentials_query_and_fragment`.
- L2: `read_log` maps a non-object line to an empty (broken) row, and `verify` reports `line N: not a JSON object`,
  so send refuses as for any broken chain. Test: `test_non_object_log_line_is_reported_not_a_crash`.
- L2b: `_CRLF` covers every `str.splitlines` boundary (`\x0b \x0c \x1c-\x1e` added). Test:
  `test_every_line_boundary_is_refused_in_headers`.

## Verification
```
python -m pytest -q -p no:cacheprovider tests/test_distribute.py        # 33 passed
python -m pytest -q -p no:cacheprovider tests/test_distribute.py tests/test_ideas_view.py tests/test_compliance.py \
  tests/test_compliance_config.py tests/test_ops_approvals.py tests/test_cli_editorial.py tests/test_cli_ideas.py \
  tests/test_compliance_products.py                                     # 132 passed
bandit -q -r econquest/ops/distribute.py econquest/presentation/ideas_view.py econquest/presentation/compliance.py \
  econquest/ops/approvals.py -ll                                        # no findings
ruff check econquest/ops/distribute.py tests/test_distribute.py         # clean
```
