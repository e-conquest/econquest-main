---
id: SEC-A-002
ticket: EQ-A-0022
author: A/AGENT-09
created: 2026-10-23
severity: medium   # critical | high | medium | low | info
status: fixed           # open | fixed | accepted-risk (needs EXC- id) | false-positive
cwe: CWE-200 (credential exposure), CWE-319 (cleartext transmission)
---
# Event feeds: API credentials forwarded on HTTP redirect (cross-host and https->http)

Also affects EQ-A-0024 (ACLED bearer token) and, for integrity only, EQ-A-0023 (GDELT fetcher).

## Finding
Found by manual review of the EQ-A-0022..0024 diffs plus a probe script
(/tmp/claude-0/-home-claude-econquest-main/4d046af0-0329-5499-894e-87a0bbd3789c/scratchpad/r3/probe_events.py,
not committed). bandit -ll is clean. The 64 tests pass, but they use injected fetchers and never exercise urllib
redirects.

**M1. `base.http_fetch` sends secrets as ordinary request headers through the default urllib opener
(econquest/ingestion/events/base.py:129-137).**
The function checks that the *initial* URL is https. It then calls `urllib.request.urlopen`, whose default
`HTTPRedirectHandler` follows 301/302/303/307/308 to **any host and to plain http**, and copies every
non-content header to the new request. Headers passed through `Request(headers=...)` are not unredirected
headers, so they are forwarded. Probe on Python 3.13.17:

```
https://ucdpapi.pcr.uu.se/... -302-> http://evil.example/x  headers {'X-ucdp-access-token': 'SECRET'}
https://acleddata.com/...     -302-> http://evil.example/x  headers {'Authorization': 'Bearer SECRET'}
```

The UCDP token (ucdp.py:248) and the ACLED bearer token (acled.py:190) both go through this path. The host
allow-lists at ucdp.py:246 and acled.py:152-154 check only the URL *before* the request and never see the
redirect target. The https-only guard is bypassed in the same way.

Not affected: the ACLED password grant (POST body). urllib turns a 301/302/303 POST into a GET without a body and
refuses to follow 307/308 for POST (both confirmed by the probe), so the password is not forwarded. The bearer
token obtained from the grant is forwarded.

**Related (integrity only, no credentials): `gdelt.make_url_fetcher` (gdelt.py:190-218)** uses the same default
opener, so a redirect from data.gdeltproject.org is followed to any host or to http. `check_url` validates only
the first URL. The md5/size from masterfilelist protect the zips in masterfilelist mode. They do not protect
masterfilelist.txt itself or `--index constructed` (no md5).

## Exploit scenario
Real-world exploitability is moderate for a desktop tool run by one desk on Sam's Mac. Any of the following leaks the token:
an open redirect or compromise on ucdpapi.pcr.uu.se or acleddata.com, a CDN or load-balancer misconfiguration that
redirects to http:// (the token then crosses the network in cleartext, readable on office or hotel Wi-Fi), or the
vendor moving the API behind a 301 to a new host. A leaked UCDP token can burn the 5,000/day quota. A leaked
ACLED token gives up to 24 h of access under Sam's account and licence. No user action is needed beyond running
the normal pull.

## Fix
Owner: Team A ingestion (base.py, gdelt.py).
1. In `http_fetch`, use an opener whose redirect handler refuses redirects. The vendor APIs do not need them.
   `class _NoRedirect(urllib.request.HTTPRedirectHandler): redirect_request = lambda self, *a, **k: None`,
   then `urllib.request.build_opener(_NoRedirect).open(req, timeout=...)`. A 3xx then surfaces as HTTPError and
   should raise `RuntimeError(f"HTTP {code} redirect from {safe}; not followed")`. If redirects must be followed,
   allow only https to the same host, and drop credential headers otherwise.
2. Set secrets with `req.add_unredirected_header(name, value)` instead of `headers=` (defence in depth).
3. After opening, assert that `urlsplit(resp.geturl())` is https and that its hostname equals the requested host.
4. Do the same in `gdelt.make_url_fetcher`: use the no-redirect opener, or run `check_url(resp.geturl())`.
5. Test: unit-test the opener or handler. A 302 to http://other-host must raise, and no request may carry
   `x-ucdp-access-token` or `Authorization` to the second host. A local `http.server` pair with a test-only
   http hook also works.

## Verification
After the fix, re-run the probe's P1 section against the opener used by `http_fetch`. It must show no
redirected request, or no credential header on one. Then run
`python -m pytest -q tests/test_events_ucdp.py tests/test_events_acled.py tests/test_events_gdelt.py -p no:cacheprovider`,
which must pass with the new redirect test included.

## Fixes
Fixed by A/AGENT-03 on 2026-10-23 (EQ-A-0022 base.py/ucdp.py, EQ-A-0023 gdelt.py, EQ-A-0024 acled.py).

**M1 (redirect credential forwarding).**
- `base.NoRedirectHandler` returns None from `redirect_request`, and `base.build_no_redirect_opener()` builds the opener
  that `http_fetch` uses. A 3xx raises `base.FetchError("HTTP <code> redirect from <host><path>; not followed")`.
  The message holds no query string and no header value. `FetchError` subclasses RuntimeError, and other 4xx errors
  now raise it too.
- `base.build_request` sets every caller header with `add_unredirected_header` (defence in depth).
- `base.check_final_url`: after opening, `resp.geturl()` must be https on the requested host, otherwise FetchError.
- `gdelt.make_url_fetcher` uses the same opener, request builder and final-URL check, with the scheme it requested
  (http only under `--allow-http`). A 3xx raises GdeltError naming host and path.
- Probe P1 re-run against `NoRedirectHandler`: `redirect_request` returns None for 301/302/303/307/308. Even the default
  handler copies no headers from a `build_request` request (`{}`).

**Lows.**
- Config secret check: `SECRET_KEY_RE = token|secret|passw|bearer|authori|api_?key` (substring, any case), plus the
  exact names key/apikey/credentials/creds. It recurses through dicts and lists. Keys ending `_env` are exempt, but
  their value must match `ENV_NAME_RE = (UCDP|ACLED)_[A-Z0-9_]+` (fullmatch).
- Credential variable names: UCDP `token_env` must start `UCDP_`. ACLED `token_env`, `username_env` and `password_env`
  must start `ACLED_`. A constructor argument is checked the same way as the config (`base.check_env_name`).
- `enabled` counts only when it `is True` (`base.is_enabled`), for UCDP, the ACLED adapter, `acled_ready` (also the
  `indicators` gate) and the GDELT CLI. Strings such as "false" or "true" do not enable a feed.
- ACLED licence: it must be a non-empty string that is not none, pending, null or no (case-insensitive), and it must
  pass `licence_problem`. Expected form, documented in the acled.py docstring:
  `"ACLED corporate licence <agreement ref>, signed <YYYY-MM-DD>"`.
- GDELT: `stage()` builds two default fetchers, one for the index (`MAX_INDEX_BYTES`, 1 GiB) and one for zips
  (`MAX_ZIP_BYTES`, 20 MiB), so each zip download stops while streaming at 20 MiB.
- ACLED `RequestBudget` is now persisted at `data/live/events/acled/request_budget.json`, as UCDP's is.
- `validate_events` uses `fullmatch` for iso, metric and period (`"NGA\n"` is refused). It checks `retrieved_utc`
  as `YYYY-MM-DDTHH:MM:SSZ` or blank (blank is filled at save). Licences that start with `= + - @ TAB CR` or contain
  control characters are rejected, not escaped. The other `re.match` checks in the event package also became fullmatch
  (vintage ids, source names, extra file names, UCDP versions and override ISO codes).
- GDELT unmapped-code counts: keys are kept only if they fullmatch `[A-Z0-9]{0,2}`; every other key is counted
  under `"other"`.

**Regression tests.**
- tests/test_events_ucdp.py:
  - Stubbed-wire redirects: 301/302/303/307/308 to http://evil.example, to https://evil.example and to http on the
    same host, with the UCDP header and with an Authorization header.
  - Local `http.server` pair on 127.0.0.1: server B gets no request.
  - Unredirected headers, final-URL check, and UCDP end to end.
  - Config secret keys at any depth, env-name rules, `enabled` strings, and validate_events fullmatch, licence and
    retrieved_utc checks.
- tests/test_events_gdelt.py: redirect refused (https and allow_http), final-URL check, streaming cap, per-kind caps in
  `stage()`, and unmapped-key grouping.
- tests/test_events_acled.py: `enabled` strings, licence placeholders, non-strings and formulas, env names, budget
  persisted across restarts, and the bearer token end to end with a 302 to http://evil.example through
  `http_fetch`.
- A mutation check confirmed the redirect tests fail when `NoRedirectHandler` follows redirects.
- Event tests: 189 passed. ruff is clean, and `bandit -q -ll -r econquest/ingestion/events` is clean.
