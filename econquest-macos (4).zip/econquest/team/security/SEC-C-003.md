---
id: SEC-C-003
ticket: EQ-C-0026
author: C/AGENT-09
created: 2026-10-23
severity: medium   # critical | high | medium | low | info
status: fixed          # open | fixed | accepted-risk (needs EXC- id) | false-positive
cwe: CWE-22/CWE-59 (file outside the intended folder, via symlink), CWE-78 (OS command injection), CWE-1236 (CSV injection), CWE-20
---
# PI-2 review (EQ-C-0021..0027): editorial draft could publish any file, record-job shell injection via ops.json, backup retention outside its own folders, CSV range text

## Finding
Found by manual review of `teamctl diff` for EQ-C-0021 to EQ-C-0027, plus probes: an XSS fuzz of the notes and
briefs, edge cases for JSON pointers and four-eyes names, and a run of the retention logic. No High or Critical.
One Medium and four Lows were found, all fixed here (each under 20 lines, checkpointed under the owning ticket, with a
regression test).

**M1 (EQ-C-0026). An editorial draft accepted any file on disk (presentation/editorial.py `_hash_files`).** A draft
pinned the hashes of whatever paths `--file` named, and `publish` only checked that at least one HTML/MD/TXT file carried
the disclaimer. So `editorial draft --file outputs/reports/x.html --file ~/.ssh/id_rsa` passed review if the reviewer
missed the second name. Publish then copied the key read-only into `outputs/published/<kind>/...`, which is the folder
that gets shared. A symlink under outputs/ pointing anywhere did the same thing. A file named `manifest.json` was
silently replaced by the publish manifest.
**Decision: draft files must resolve (after symlinks) under outputs/, outside outputs/published/ and
outputs/editorial/.** `manifest.json` is a reserved name.

**L1 (EQ-C-0021). Shell injection through ops.json `spreadsheet_id` (ops/schedule.py `resolve_steps`).** The id is
pasted into the record job's `bash -c` script inside a double-quoted URL. An ops.json value like `x"; cmd; "`
ran `cmd` at 18:20 every weekday. ops.json is Sam's own file, so this is Low.

**L2 (EQ-C-0022). Retention could delete folders the backup did not create (ops/backup.py `prune_backups`).** Any
`YYYY-MM-DD` folder directly under the destination counted. If `ECONQUEST_BACKUP_DEST` pointed at the wrong place, for
example `data/live/vintages`, whose legacy vintage ids are dates, every date folder past the 14+8 window was removed. A
symlinked day folder made `rmtree` raise. A destination inside `data/` or `outputs/store` would also back itself up.

**L3 (EQ-C-0027). Range text went into the preview CSVs raw (presentation/republish_preview.py).** Cell values were
escaped, but the `range` and `cell` columns were not. Sheet titles come from the baseline JSON, so a title starting
with `=`/`@` would evaluate in Excel or Sheets when the CSV is opened.

**L4 (EQ-C-0023). A non-ASCII digit as an array index crashed `change propose` (ops/approvals.py `apply_patch`).**
`"²".isdigit()` is True and `int("²")` raises a bare ValueError: a traceback instead of a refusal. It did not
bypass anything.

**Reviewed, no finding (info):**
- EQ-C-0021: plists hold absolute paths only and no token. The record job reads the token from env or the Keychain at
  run time and pipes it to curl on stdin (`-H @-`, printf is a bash builtin, so it is not in any argv). There is no
  `-L`, so redirects are not followed.
  - launchctl is run only with `--load` on macOS, as an argument list.
  - `.ops.env` is refused when group/other bits are set, and it is parsed as KEY=VALUE with no shell expansion. It
    can set any variable (PATH, PYTHONPATH...), but it is the owner's 0600 file, so this is acceptable. An allow-list
    (`ECONQUEST_ALERT_*`, `ECONQUEST_SMTP_*`) would be tighter.
  - The release zip already excludes it (`*.env` in SECRET_GLOBS).
  - The lock has a small check-then-write race. launchd does not double-start a job, so it is acceptable.
  - Alert de-duplication keeps failed deliveries for a retry.
  - Webhook errors do not echo the URL.
- EQ-C-0022:
  - Creation follows symlinks by design (`os.walk(followlinks=True)`) and has no loop guard. A symlink loop under
    data/ would recurse until the path is too long. Device files and FIFOs are skipped (`is_file`).
  - The sqlite backup API runs on a read-only URI. A path containing `?`/`#` would break the URI; quoting would fix it.
  - Extraction accepts regular files only. Names are checked for absolute paths, `..`, backslashes and drive letters,
    and must start with `data/` or `outputs/store/`. Every write is resolve-checked against the target, and no links
    or devices are ever created.
  - Archives are written with the umask (normally 0644). They hold the whole desk's data, so 0700 on the
    destination is recommended.
- EQ-C-0023:
  - Four-eyes uses Team A's `person_key`. Probe: `sam`, `SAM `, `S​am`, full-width `Ｓａｍ`, `'Sam`, `Sam ` and
    `S am` are all refused as the same person as `Sam`.
  - A self-approval needs an `EXC-nnn` id.
  - A change id must match `CHG-...` (no path traversal), and the file must be one of the two governed names.
  - JSON pointers follow RFC 6901 (`~1` is decoded before `~0`). An explicit tier can only raise the inferred one, never lower it.
  - apply writes exactly the approved bytes, atomically, and only on the base sha256.
  - Chain forgery: anyone who rewrites log + head + proposals together can forge the chain (documented). Keep
    `head.json` outside the folder as an anchor.
  - The first `baseline` of a file needs no second person (bootstrap). Run it once now, under review, so that later
    hand edits show as drift.
  - The GUI can run `fit-hazard --apply`, but that now only proposes.
- EQ-C-0024/0025: every data-derived string goes through `report._e` (`html.escape`, quotes too). Fuzz: injected
  `<x-xss a='1">` into every text field of the data and the run archive. It appeared 50 times in the notes and briefs,
  always escaped, never raw.
  - Chrome runs as a fixed argument list with no shell, a throwaway `--user-data-dir`, `--disable-extensions` and a
    resolved `file://` URI. It has a 60 s timeout with a process-group kill, and `--no-sandbox` is added only as root.
  - Notes and briefs write no CSV.
- GUI allow-list: `editorial`, `change`, `schedule`, `backup`, `restore-drill`, `notes`, `briefs` and `publish-preview`
  are not in `gui.ALLOWED_CMDS` (checked).

## Exploit scenario
This is a local, single-desk tool, and every case needs local access.
- M1: a careless or malicious draft attaches a private key or a credentials file to a report. A hurried reviewer
  signs it, and the published folder, which gets shared, carries a read-only copy.
- L1: a tampered ops.json runs arbitrary commands under Sam's account from launchd.
- L2: a misconfigured destination silently deletes old data vintages.
- L3: opening the preview CSV runs a formula.
- L4: a crash; no bypass.

## Fix
- M1: `editorial._hash_files(files, outputs_dir)` resolves every path and requires it under `outputs_dir`, not under
  `published/` or `editorial/`, and refuses `manifest.json`. Test: `tests/test_editorial.py::test_draft_refuses_files_outside_outputs`
  (outside file, symlink out of outputs/, reserved name, an already-published copy). `tests/test_cli_editorial.py` now
  drafts a file under `out/notes/`.
  Also: `_rmtree_ro` uses 0o700/0o600, which clears bandit B103.
- L1: `schedule.resolve_steps` validates `spreadsheet_id` against `[A-Za-z0-9_-]{1,128}`. Test:
  `tests/test_ops_schedule.py::test_spreadsheet_id_cannot_inject_into_record_script`.
- L2: `prune_backups` deletes only non-symlink `YYYY-MM-DD` folders that contain an `econquest-*.manifest.json`.
  `create_backup` refuses a destination inside `data/` or `outputs/store`. Tests:
  `test_prune_never_deletes_foreign_or_linked_date_folders` and `test_backup_refuses_dest_inside_a_source`. The
  retention tests now create the manifest a real backup leaves.
- L3: `_csv_cell` is applied to `range` and `cell` in both preview CSVs. Test: `test_csv_escapes_range_text_from_the_baseline`.
- L4: an array index must be ASCII digits. Test: `test_array_index_must_be_ascii_digits_in_range`.

## Verification
```
python -m pytest -q -p no:cacheprovider tests          # full suite
bandit -q -r econquest -ll                              # no findings
```
