---
id: SEC-C-008
ticket: EQ-C-0060
author: C/AGENT-09
created: 2026-10-24
severity: low   # critical | high | medium | low | info
status: fixed          # L1 to L4 and D1 fixed under EQ-C-0060, L5 and the checkpoint bug under EQ-C-0066; R1 to R11 open
cwe: CWE-200 (exposure to an external party), CWE-359 (personal data), CWE-88/CWE-74 (URI injection into sqlite3.connect), CWE-354 (integrity check downgrade)
---
# PI-5 review of EQ-C-0060 evidence bundle (+0061 targets) and EQ-C-0063 U22 GUI ideas: credential values and addresses outside chains, non-read-only store on '#' paths, verify downgrade

## Finding
I reviewed `teamctl diff --ticket EQ-C-0060` (econquest/ops/evidence.py, the scripts/build_release.py refactor to
`write_zip`/`default_mode`, econquest/ops/commands.py), the EQ-C-0061 targets section, and the EQ-C-0063 GUI and
run-gate changes. I also built a real bundle on a temp copy of the install: 36 stored runs for 2026-10-23,
`--quick --tests-from <the 1775-test junit>`, 2.0 MB, 146 files, 35 s. Before the build I planted canaries:
- a token in the environment (`ECONQUEST_SHEETS_TOKEN`) and an SMTP password in `<home>/.ops.env`;
- `docs/governance/api_token.json`, `docs/governance/smtp-password.txt`, and a `contacts.md` holding two addresses;
- a reply-to address, a cc list and a signed `archive_base_url` in distribution.json;
- an action-log row with a `--confirm-new` address, a `token` arg and the env token in a note (a row from before
  masking).

Then I grepped the unzipped bundle for `CANARY`, `@`, `token`, `password`, `secret`, `bearer` and `api_key`, and
probed `verify` with 12 tampered archives. bandit `-ll` found nothing. Nothing is High or Critical, so nothing
blocks a merge.

**L1 (Low). Credentials that sit in a file reached the archive.** The only control was the SECRET_GLOBS file-name
check (`add()`), so these shipped:
- `docs/governance/api_token.json` and `smtp-password.txt` (the names are not in the globs);
- the env token in an old action-log row (`chains/outputs/store/actions.jsonl`);
- the `?sig=` of a signed `archive_base_url` in `chains/distribution.redacted.json`.

The `.ops.env` file itself was not packed: `*.env` matches it, and it lies outside docs/. The token-named run args
were already `***` (actionlog.SECRET_KEY_RE). Run JSON, inputs, targets and the test files held no credential.

**L2 (Low). Address redaction covered only the chain .json/.jsonl files and `subscribers`.** The bundle still held:
- `reply_to` and nested `products.*.cc` addresses in distribution.redacted.json;
- both addresses in `docs/governance/contacts.md`;
- five addresses in `tests/junit.xml` (failure text).

The delivery recipients, the action-log `--confirm-new` address and the subscribers were redacted correctly,
case-insensitively and numbered. Today's real distribution.json has only the three keys, and the real docs hold no
address, so the shipped data was not exposed. The gap is for the next config key or note someone adds.

**L3 (Low). `stored_runs` was not read-only and could write outside `--out` when the path held `#` or `?`.** The URI
was built as `f"file:{db.resolve()}?mode=ro"` without encoding. Probe with `--out ".../desk#2"`:
- SQLite cut the path at `#`, so `?mode=ro` was lost;
- it opened `.../desk` in the default `rwc` mode and created an empty database file there;
- the build then died with a `no such table: runs` traceback.

A macOS folder name such as "Desk #2" is enough to trigger this. A path ending in `?mode=rwc&...` would select its
own mode.

**L4 (Info). The manifest could downgrade the offline chain check.** Editing an approvals row and rewriting the
manifest's file hash is caught by the full recompute (the existing test). Two manifest edits got past it, and verify
said ok:
- setting `chains.approvals.offline_check` to `"linkage"`;
- deleting `chains.approvals` from the manifest.

The trust anchor is still the zip's SHA-256 sent by another route, as the README says. Someone who can rewrite the
manifest can also recompute an unkeyed chain, so this is defence in depth.

**D1 (defence in depth) in verify:**
- A duplicate entry name was not refused. Here it failed only because the copies differed. Zip readers differ on
  which copy they show, so a validator could see a different copy from the one verify hashed.
- A file and a folder with the same path raised an uncaught `FileExistsError` traceback.
- Modes from the archive were applied with their setuid/setgid/sticky bits.

**Reviewed, no finding:**
- **Zip-slip and symlinks.** `../`, absolute names and backslashes are refused (`_safe_name`), and only `chains/` is
  extracted, into a fresh `mkdtemp`. Probe: `chains/../../../evil.txt` was refused and nothing was written outside.
  A symlink entry is refused and would be written as a regular file anyway. The temp folder is removed on every path,
  including the traceback above (0 left over).
- **Tamper detection.** Verify fails on each of these:
  - a file edited without a manifest change;
  - a manifest hash edit;
  - an approvals row edit with the manifest rewritten (full recompute);
  - a `tests/summary.json` count edit;
  - an extra file;
  - a sidecar mismatch.

  An edit to a redacted chain's row content, with the manifest rewritten, passes offline as documented: linkage only,
  so the zip SHA-256 is the control (R2).
- **Writes outside --out.** I compared the temp tree before and after the build: only the zip and its `.sha256`
  appeared, under `--out`. `.part` is a sibling and is moved into place. pytest and the replication run in
  `TemporaryDirectory`. The build is not logged to the action log (R4).
- **build_release refactor.** `write_zip` and `default_mode` behave as before (test_release determinism tests pass).
  `default_mode` gives 0755 only to *.sh/*.command read from disk, never to a bytes entry.
- **EQ-C-0061 targets.** `target_scorecard` only reads; `write_scorecard` is not called from the bundle. The real
  targets.csv/md hold no address or credential. The error branch put `str(e)` (an absolute path) in the manifest.
  It now records the exception type only, and both files now pass `add()`.
- **EQ-C-0063 U22 (`gui.ALLOWED_CMDS` + `GUI_SUBCMDS`).** I tried 21 argument lists with a mocked Popen:
  - `ideas report`, `log` and `log --run-id r1` run;
  - `mark`, an empty list, `--as-of D mark`, `Report`, `rep`, `l`, `-h`, `mark report` and `--author x report` are
    refused;
  - stripping happens before the subcommand check: `--token T1 mark` is refused, while `--token T1 report`,
    `--token=T2 log`, `--wr report`, `--token-f PATH log`, `--token-fi=PATH log` and `--allow log` run without the
    stripped flag;
  - `ideas` is not in WRITER_CMDS, so a request's `sheets_token` is dropped, and `$ECONQUEST_SHEETS_TOKEN` was
    absent from the child env in every case (it was set in the parent);
  - `log mark` and `report -- mark` reach argparse, which exits 2 ("unrecognized arguments");
  - `--run-id ../x` gets "not a run id" (exit 1);
  - gui.html sends only `data-args="report"` and `"log"`.
- **EQ-C-0063 `_gate_warning`.** Only the `warn` print changed. The block path still prints the full `_gate_text`:
  per-file counts, the `attest` commands, the policy key, `--allow-unattested`, and "Nothing was sent to Sheets."
  It also still raises RunGateBlocked. The fail-closed branch when attestations cannot be read is unchanged.
  `test_block_message_keeps_the_full_fix` covers it. The sheets_publish.py note starts with `[`, so there is no
  formula lead.

## Exploit scenario
The evidence bundle is built to leave the desk: it goes to an independent validator.
- L1: an operator once pasted the Sheets token or the SMTP password into a governance note, or a row predates
  masking. The bundle then hands that credential to an outside party, and the README says "Credentials of any kind"
  are left out. With a Sheets token, someone could write to the live workbook. No attacker is needed, only an
  ordinary mistake, which is why it is fixed now. The severity is Low because it needs the secret to be on disk in
  the packed folders already.
- L2: subscriber and staff addresses (personal data) leave the desk against the module's stated rule.
- L3: a folder name with `#` creates a stray empty database next to `--out`, opened writable. No data is lost: the
  real store is not opened in that case.
- L4/D1: a forger who can already replace the archive and its manifest. Not exploitable when the SHA-256 arrives by
  another route.

## Fix
All fixes are under EQ-C-0060, checkpointed: econquest/ops/evidence.py, scripts/build_release.py,
tests/test_evidence.py and tests/test_release.py.
- **L1:**
  - `evidence.secret_values()` collects the values (6 characters or more) of `ECONQUEST_*` variables whose names
    match actionlog.SECRET_KEY_RE, plus the vendor keys, from the environment and from `<root>/.ops.env` and
    `<home>/.ops.env`.
  - Every entry now passes `add()`, including tests, replication and targets. A file holding a value is left out
    and listed as `<path> (contains the value of $VAR)`, naming the variable only. A chain file has the value masked
    as `[redacted:secret]` and becomes linkage-checked. An `inputs/data/` file stops the build with a clear error,
    because data_hash covers it.
  - SECRET_GLOBS gained `*password*`, `*passwd*`, `*api_token*`, `*apikey*`, `*api_key*`, `id_ecdsa*`, `id_dsa*`,
    `.git-credentials`, `.pypirc`, `.npmrc` and `.htpasswd`. No file in the current tree matches them, so the
    release contents do not change.
- **L2:**
  - The Redactor runs on every UTF-8 file outside `inputs/data/` (docs, runs, data room, tests, replication,
    targets). The per-file counts are in `redactions["e-mail addresses in other files"]`.
  - distribution.redacted.json is redacted as a whole document. `_scrub_urls` drops `user:pw@` and any
    query/fragment, keeping scheme, host and path.
- **L3:** `sqlite3.connect(db.resolve().as_uri() + "?mode=ro", uri=True)`, which percent-encodes the path. A
  `sqlite3.Error` becomes an EvidenceError.
- **L4:** verify checks every chain whose log is in the archive. A chain left out of the manifest fails ("the
  manifest's chains omit it"). The linkage check is used only when the manifest says so and the log really holds
  `[redacted:`. Otherwise it is the full recompute.
- **D1:** duplicate entry names are refused. An extraction OSError becomes "cannot be extracted", not a traceback.
  Modes are masked to 0o777.
- **Tests** (all four fail on the pre-fix code and pass now):
  - `test_credential_values_and_names_never_ship`;
  - `test_every_address_is_redacted_docs_config_and_tests`;
  - `test_store_path_with_hash_is_opened_read_only`;
  - `test_verify_refuses_duplicates_downgrades_and_undeclared_chains`;
  - 7 new `test_credentials_are_never_packed` cases in test_release.py.

**Recommendations (open, not fixed here):**
- **R1 (Low).** The content check knows only the env and .ops.env values. The Sheets token that lives in the macOS
  Keychain (`econquest-sheets`) is not compared, because reading it could prompt. Consider reading it when it is
  available without a prompt, or run gitleaks on the staged bundle folder in the release checklist (EQ-C-0064).
- **R2 (Info).** A redacted chain is linkage-only offline. Options:
  - a keyed commitment per row, an HMAC with a key Sam gives the validator separately;
  - a way to rebuild the chain unredacted for a validator under NDA, so the row content of `actions` and
    `deliveries` is rechecked.
- **R3 (Info).** Absolute paths (`/mnt/...`, and `/Users/<name>/...` on a Mac) are in the action-log args and docs.
  `tests/junit.xml` carries `hostname=` and a timestamp. Consider replacing the home prefix with `~` in the copied
  chains, which makes them linkage-only, or accept and note it in the README.
- **R4 (Info).** `econquest evidence` writes no action-log row. A package that leaves the desk should record who
  built it, the as_of date and the SHA-256.
- **R5 (Info).** An existing archive is replaced without `--force`, unlike build_release. A `--out` under docs/
  would pack the previous bundle into the next one.
- **R6 (Info, Team A).** Redacting an address inside Team A's data room export changes those bytes against its own
  MANIFEST.json, so their verifier on the unzipped copy would report "changed". The counts are in our manifest.
  Better: the export should redact at source (EQ-A-0041 owner).
- **R7 (Info).** Addresses in `inputs/data/` are not redacted, because that would break the data_hash recheck. No
  input holds one today.

**EQ-C-0066 (installer, pinned and hash-checked).** It moved to In Review after the first pass, so the review is in
the addendum below.

## Verification
```
python -m pytest -q -p no:cacheprovider tests/test_evidence.py tests/test_evidence_monitor.py tests/test_release.py \
  tests/test_actionlog.py tests/test_distribute.py tests/test_targets.py tests/test_run_gate.py \
  tests/test_usability_fixes.py tests/test_gui_*.py                                               # 233 passed
python -m pytest -q tests/test_evidence.py   # on the pre-fix copy: 4 failed (the new tests), 10 passed
ruff check econquest/ops/evidence.py scripts/build_release.py tests/test_evidence.py tests/test_release.py   # clean
bandit -q -ll econquest/ops/evidence.py scripts/build_release.py econquest/presentation/gui.py               # no findings
# real bundle on the canary copy, fixed code:
python -m econquest --data COPY/data --out COPY/outputs evidence --as-of 2026-10-23 --quick \
  --tests-from junit-full.xml --root COPY --out OUT/      # 144 files, 2.0 MB, 35 s
grep -rhoE 'CANARY[A-Z0-9]+' unzipped/   # nothing
grep -rnoE '<address regex>' unzipped/   # nothing
# excluded_secret_like: docs/governance/api_token.json, docs/governance/smtp-password.txt
# e-mail addresses in other files: contacts.md 2, junit.xml 5
python -m econquest evidence verify OUT/evidence-2026-10-23.zip
# ok (143 files); actions linkage, approvals/deliveries/editorial full
```

## Addendum: EQ-C-0066 (hash-pinned install), reviewed once it was In Review
**Result: pass, with one finding (L5, Low, fixed).** I reviewed `teamctl diff --ticket EQ-C-0066`:
- requirements-lock.txt and scripts/make_hash_lock.py;
- install.sh, pyproject.toml extras, scripts/ci_local.sh, ci.yml and tests/test_install.py.

I ran install.sh for real in a sandbox (HOME, ECONQUEST_HOME and the source folder all under the scratchpad) against
six crafted locks.

- **Fails closed.** Each case exits 1 before a launcher is written:
  - a wrong hash gives the "did not match the SHA-256" message;
  - a pin without a hash makes pip say "Hashes are required" and the install fails;
  - a lock with no `# python:` line fails, as does a Python the lock does not cover (`# python: 3.9`);
  - a missing lock fails before a venv is made.

  A requirement with a hash but no `==` (`six --hash=...`) still installs only the file with that hash. That is
  pip's semantics and stays tamper-safe; `make_hash_lock.py --check` covers pinning.
- **No unpinned pip call is left.** install.sh makes exactly two pip calls:
  - `--require-hashes -r requirements-lock.txt`;
  - `--no-deps --no-build-isolation -e "$TARGET"`.

  There is no `pip install --upgrade pip`. pip 26.2.2 and setuptools 84.2.1 come from the lock, with hashes, and the
  venv starts from ensurepip's bundled wheel (offline). install.command only calls install.sh. The other `pip install`
  strings in ci_local.sh are help text.
- **`--no-deps --no-build-isolation -e` is safe.**
  - The source is the local release folder.
  - The build backend is the hash-checked setuptools already in the venv (`[build-system] requires =
    ["setuptools>=68"]`). Without isolation nothing is fetched, and a missing backend fails (probe: traceback, exit 1).
  - `--no-deps` resolves nothing.
  - A user's pip.conf or `PIP_INDEX_URL` can redirect downloads, but every file is still hash-checked.
- **Lock integrity.**
  - I checked all 220 hashes for the 70 packages against PyPI's JSON API through the proxy. Each one is a published
    file of that exact version, all are wheels (no sdist, so no isolated build with unhashed build dependencies), and
    none is yanked.
  - `pip download` of requests 2.34.2, six 1.17.0, pip 26.2.2, defusedxml 0.7.1 and numpy 2.5.4 (cp313 manylinux):
    every SHA-256 is in the lock.
  - `make_hash_lock.py --check`: ok. `pip-audit -r requirements-lock.txt --require-hashes`: no known vulnerabilities.
- **blpapi.** `https://pypi.org/simple/blpapi/` is 404 today, so the note in pyproject.toml is accurate:
  - always use `--index-url` to Bloomberg's index, never `--extra-index-url`;
  - `econquest[bloomberg]` against PyPI fails, and anyone who registered the name would win.

  lseg-data is on PyPI (200) and pinned to `>=2.1,<3`. Both extras are still range-pinned without hashes and outside
  the lock (R9).

**L5 (Low). The pip-audit gate audited a different package set from the one install.sh installs.** ci_local.sh and
ci.yml audited only `scripts/requirements-lock.txt`, a version-only lock of the dev environment. Compared with
requirements-lock.txt:
- 18 packages that install.sh installs were never audited, among them yfinance, fastapi, starlette, pydantic,
  pydantic-core, lxml, protobuf, curl-cffi, websockets and setuptools;
- 6 others were audited at another version: numpy 2.5.3 against 2.5.4, pip 24.0 against 26.2.2, certifi,
  charset-normalizer, python-dateutil and soupsieve.

A CVE in one of those packages would have passed the gate while install.sh shipped it.

Fix: ci_local.sh now audits both locks, `-r requirements-lock.txt --require-hashes --disable-pip` and the old one
(`--no-deps`). The two cannot be mixed in one pip-audit call because of the hashes. Either failing fails the gate.
Test: `tests/test_release.py::test_ci_local_audits_the_install_lock_too`.

**Teamctl checkpoint bug (reported by AGENT-10), fixed under EQ-C-0066.** `cmd_checkpoint` checked ownership path by
path. A refused path exited after earlier paths were already copied to `files/`, but before manifest.json was
written. The rerun after editing then copied the edited file over the saved original, which broke `revert`.
- Now ownership of every path is checked first. A refusal saves nothing and says "(nothing was checkpointed)".
- A copy in `files/` without a manifest entry, left over from the old behaviour, is kept rather than overwritten.
- Test: `tests/test_teamctl.py::test_checkpoint_refusal_saves_nothing_and_a_rerun_keeps_the_original`.

**Recommendations:**
- **R9 (Info).** The extras outside the lock (api, ml, test, ci, bloomberg, lseg) install unpinned and unhashed on
  request. For lseg, add a hashed `requirements-vendor-lock.txt` once a version is chosen. For blpapi, keep the
  runbook's `--index-url`.
- **R10 (Info).** install.sh's hash-failure branch also catches "hashes are required" (a lock entry with no hash) and
  reports it as a tampered download. It still fails closed, but the message misleads. Say "the lock is incomplete;
  regenerate it" for that case.
- **R11 (Info).** ci.yml's pip-audit step should mirror ci_local.sh. It still names only scripts/requirements-lock.txt
  (AGENT-10).

Verification:
```
python -I probes/lockcheck.py requirements-lock.txt
# packages 70 hashes 220; unknown hashes 0 sdists 0
pip download --no-deps --only-binary :all: requests==2.34.2 six==1.17.0 pip==26.2.2 defusedxml==0.7.1 numpy==2.5.4
# 5/5 MATCH
install.sh run against six crafted locks   # all exit 1 with the messages above
python scripts/make_hash_lock.py --check   # lock ok: 70 packages
pip-audit -r requirements-lock.txt --require-hashes --disable-pip   # No known vulnerabilities found
python -m pytest -q tests/test_teamctl.py tests/test_install.py tests/test_release.py   # 49 passed, 4 skipped
ruff check team/teamctl.py tests/test_teamctl.py tests/test_release.py   # clean
bash -n scripts/ci_local.sh   # ok
teamctl check                 # 0 problems
```
