---
id: SEC-C-007
ticket: EQ-C-0059
author: C/AGENT-09
created: 2026-10-24
severity: low   # critical | high | medium | low | info
status: fixed          # L1, L2 and D1 fixed under EQ-C-0059; R1 to R6 are open recommendations
cwe: CWE-284 (governance control bypass), CWE-755 (unhandled exception), CWE-1236 (formula injection, checked: none)
---
# PI-5 catch-up review (EQ-C-0050/0052/0056/0057): compliance anchor bypass via default content, review.csv traceback

## Finding
These four tickets had only a lead review in 0.1.5. I reviewed `teamctl diff` for EQ-C-0050, 0052, 0056 and 0057 and
probed them with concrete inputs in throwaway temp dirs. The probes used seed-data copies, synthetic vintages and
synthetic market snapshots, with no network and no live writes. `bandit -q -ll` on compliance.py, cli.py, gui.py and
health.py found nothing. There is no High or Critical finding, so nothing blocks a merge.

**L1 (EQ-C-0050, Low). The EQ-C-0050 anchor checked only status `default`, so overwriting compliance.json with the
default content bypassed it.** The anchor is compliance.load_config refusing the default after a governed sign-off. In
the shipped layout, `data/compliance.json` exists (it holds the default content) and is baselined. The R1 attack there
does not delete the file. It deletes `data/approvals/` and writes the default content back into `data/compliance.json`.
`file_status` then reports `no_baseline`, and content equal to the default was accepted. Probe: Sam baselined TIGHT
(`approvers: ["Jane Roe"]`, `allow_self_sign: false`), and Jane signed one item (config_status `ok`). After that,
`rm -r data/approvals` plus the default content let Alice self-sign her own item with `--self-signed --exc EXC-001`.
The EQ-C-0050 test deleted the file, so it did not cover this path.

**L2 (EQ-C-0052/0056, Info). A malformed `data/live/review.csv` crashed `review list --pending` and
`review decide --all-pending|--cell` with a traceback.** Malformed means empty, or missing the table, key or country
column. The errors were KeyError and EmptyDataError. It failed closed: nothing was written. The bug is pre-existing in
`_review_pending`, and the new batch path inherits it.

**D1 (EQ-C-0056, defence in depth).** The brief mentions GUI identity-flag stripping for `review`, but the ticket never
added it. `review` is not in `gui.ALLOWED_CMDS`, so a GUI client cannot start it (`Jobs.start("review")` gives
ValueError). It was not in `IDENTITY_CMDS` either. If someone ever allowlists it, a GUI job could pass
`--author`/`--approver`/`--self-approved` and claim a four-eyes approval. `market` already has this guard (EQ-C-0053).

**Recommendations (open, not fixed here):**
- **R1 (EQ-C-0050, Low; this is SEC-C-005 R2, now with a concrete bypass).** Someone can delete `data/approvals/`, put
  any content in compliance.json (for example `approvers: ["Mallory"]`) and run
  `change baseline compliance.json --actor Mallory`. The config then loads with status `ok`, and the L1 anchor does not
  fire: the first baseline needs only one actor, and status `ok` counts as governed. Probe confirmed. Evidence remains:
  - the health `approvals_log` alert fires while the log is missing;
  - the baseline row names Mallory;
  - the sign-off rows' `config_sha256` changes.

  Fix options:
  - make the first baseline of compliance.json four-eyes (`--approver`, or `--self-approved --exc`);
  - or have load_config refuse an `ok` status whose approvals log has no event for the `config_change_id` of the last
    governed sign-off in the ledger.

  Owner: AGENT-10 (ops/approvals.py) with AGENT-07.
- **R2 (EQ-C-0050, Info). The anchor lives in `outputs/editorial/ledger.jsonl`.** Deleting that ledger along with the
  other two paths brings the default back (probe), but it also deletes every editorial item, which is loud. Consider a
  health alert when the editorial ledger is missing or its head file disagrees, as the approvals log now has.
- **R3 (EQ-C-0056, Low). `review apply --vintage OLD` re-applies the older vintage's ok cells over newer values.** It
  warns on stderr only after it has written. The pre-apply snapshot and the action-log row make this recoverable, so
  the overwrite is not silent. Still, it is a numbers-integrity action taken with one keystroke. Require `--allow-older`
  (or a typed confirmation) when the vintage is not the latest, and print the warning before writing. This is the CLI
  side of SEC-A-004 L2, which is Team A's open Low on `apply_vintage`. Fixing it in either place closes both.
- **R4 (EQ-C-0056, Info). `review apply` takes no `--author`, so its action-log actor is `$USER`.** The approval that
  matters is the four-eyes ledger decision, so this is evidence quality only. Consider an optional `--author` that is
  recorded.
- **R5 (EQ-C-0052, Info). The batch `review decide --all-pending --decision apply` records an apply for a held cell
  whose review.csv `live` is blank or NaN.** Such a row never binds, because `_bound` compares live values and a NaN
  never matches, so nothing wrong is applied. `review approve` refuses this case ("no live value"). Do the same in the
  batch precheck for consistency.
- **R6 (EQ-C-0052, Info). Some batch refusals are not in the action log.** These are refusals raised while `_decide_cells`
  parses its arguments: an unknown or not-held `--cell`, or `--live`/`--key` given with a batch. Four-eyes refusals
  are logged. This has low value but would be consistent with `market`.

**Reviewed, no finding:**
- **EQ-C-0050:**
  - `governed_signoff` skips unparseable and non-object lines; the chain check reports them.
  - Both call sites of `C.load_config` pass `outputs_dir`: editorial.py:439 at sign-off and :506 at publish. The
    anchor is therefore applied wherever a sign-off or publish reads the config.
  - Health `approvals_log`:
    - `missing`, `empty` (whitespace only) and `unreadable` each give one warning with a stable dedupe key;
    - an OSError cannot crash `health`;
    - it is unconditional, which is correct because the release ships a non-empty log.
- **EQ-C-0052 (`review decide --all-pending|--cell`, `_review_batch`, messages):**
  - Four-eyes runs per cell before any write. The approver values `sam`, ` SAM\t`, `S​am` (zero-width), Cyrillic
    `Ѕam`, `'Sam` and full-width `Ｓａｍ` were all refused against author Sam, with no ledger row (ledger.person_key).
    A refusal writes one action-log `error` row and says "nothing recorded for the N cell(s)".
  - `--cell` must name a held row of review.csv. An ok-status cell and an unknown cell were refused.
  - `--live`, `--gate-status` and `--key` with a batch were refused, so the live value cannot be hand-overridden in a
    batch.
  - One action-log row per cell (`batch: i/N`). The chain verifies after a batch (`actionlog.verify` ok).
  - A secret in `--note` (the value of ECONQUEST_SHEETS_TOKEN) is masked in actions.jsonl. The probe found the token
    absent from the raw file. The note is still stored verbatim in review_ledger.csv, as the operator typed it.
  - Formula leads are neutralised in review_ledger.csv. `--author "=cmd|'/c calc'!A1"` and `--note =HYPERLINK(...)`
    were written as `'=...` (ledger safe_cell).
  - The message changes in editorial and compliance only change wording: no paths, names or secrets are added.
    `editorial review` by the author (`Alice`, ` alice `, `ALICE`) says `--self-reviewed` and "a reviewer".
- **EQ-C-0056 (`review list --pending --vintage`, `review approve`, `review apply [--dry-run]`):**
  - Vintage ids: `../../etc`, `..`, `/etc`, `2026-10-23/../x` and `*` were refused. `feeds.vintage_path` accepts only
    an id from `list_vintages` or a `YYYY-MM-DD` day prefix, so there is no path traversal. An empty `--vintage ""`
    means the latest vintage.
  - A tampered `live_profile.csv` or `review.csv` inside the vintage is refused by both `approve` and `apply`, because
    the hash differs from the one in vintages/index.csv. A held cell cannot be turned into an ok one by editing it.
  - `approve` checks every triple before writing any row: an unknown cell means nothing is recorded. A triple count that
    is not a multiple of 3, and a table outside Inputs and "Country Profile", are refused.
  - Each row is bound to the vintage id and to that vintage's live value. An apply needs a live value.
  - `apply` never forces. It takes a pre-apply snapshot, and an action-log row is written unless it is a dry run.
  - `--dry-run` writes nothing (countries.csv unchanged, no action row).
  - The offline fixture refused every socket and urlopen call, and none was attempted.
  - GUI: `review` is not in ALLOWED_CMDS. Identity stripping was added as D1.
- **EQ-C-0057 (`_market_gate` -> `cds_export.market_gate_review`, `market cds-snapshots`):**
  - The gate is seeded only from earlier rows that passed it and the attestation check. A re-saved held quote stays held
    (`test_resaved_held_quote_stays_held_in_gate_and_cds_quotes`).
  - `--snapshot ../../etc`, `x` and `'; rm` were refused ("unknown snapshot ids"). Ids come only from
    `list_market_snapshots` (SNAPSHOT_ID_RE).
  - A tampered `quotes.csv` was refused by `cds-snapshots`, `gate` and `cds-quotes`, because its sha256 no longer
    matches the manifest.
  - MarketDataError, ValueError and OSError give `market <cmd>: <reason>` with exit 1. Every non-dry-run call writes an
    action-log row, refusals included, and the dry run writes none.

## Exploit scenario
This is a local desktop tool with one operator.
- L1: someone who can write `data/` undoes Sam's tightening of the compliance approver rule. They delete
  `data/approvals/` and overwrite `data/compliance.json` with the shipped default, then self-sign compliance on their
  own note. The health alert and the sign-off row's `config_status: no_baseline` are evidence of this, but before the
  fix the sign-off was not refused. The trust level is the same as SEC-C-005 R1, so the severity is Low.
- L2: no attacker gain. The operator gets a traceback instead of a message.
- D1: not reachable today.

## Fix
- L1: in `compliance.load_config`, the governed-sign-off anchor now runs for every status in
  `UNGOVERNED = ("default", "no_baseline")`, meaning every case where data/approvals/ has no record of the file.
  `governed_signoff` counts only sign-offs whose status is outside UNGOVERNED, so sign-offs made under an unbaselined
  default file do not block it. Tests in `tests/test_compliance_config.py`:
  - `test_default_content_without_approvals_record_after_a_governed_signoff_is_refused`;
  - `test_signoffs_under_an_unbaselined_default_file_do_not_block_it`.
- L2: `cli._read_review_csv` refuses an empty, unparseable or column-less review.csv with `review: ...`. Test:
  `tests/test_cli_review.py::test_malformed_review_csv_is_a_clean_refusal` (9 cases).
- D1: `gui.IDENTITY_CMDS` now includes `review`. Test:
  `tests/test_cli_review.py::test_gui_would_strip_review_identity_flags`. It checks that `--author`, the `--self-appr`
  prefix, `--approver=Bob` and the `--appro Ana` prefix are dropped.

## Verification
```
python -m pytest -q -p no:cacheprovider tests/test_compliance_config.py tests/test_compliance.py tests/test_cli_editorial.py \
  tests/test_compliance_products.py tests/test_ops_approvals.py tests/test_ops_health.py           # 93 passed
python -m pytest -q -p no:cacheprovider tests/test_cli_review.py tests/test_usability_fixes.py tests/test_cli_market.py \
  tests/test_gui_*.py                                                                              # 97 passed
bandit -q -ll econquest/presentation/compliance.py econquest/cli.py econquest/presentation/gui.py econquest/ops/health.py  # no findings
ruff check econquest/cli.py econquest/presentation/compliance.py econquest/presentation/gui.py tests/test_cli_review.py \
  tests/test_compliance_config.py                                                                  # clean
python team/teamctl.py diff --ticket EQ-C-0059                                                     # the three fixes and tests
```

## Addendum: EQ-C-0058 (`econquest vendor status|test|pull`), reviewed once it was In Review
**Result: pass, with no finding.** I reviewed `teamctl diff --ticket EQ-C-0058` (cli.py `cmd_vendor`, the parser,
`action_label`, the pyproject extras and tests/test_cli_vendor.py). I also probed it with the in-memory blpapi and
lseg.data fakes and canary credentials, offline.
- **No credential in argv.** The parser has no credential option. `--password`, `--app-key`, `--token` and `--key=`
  are refused by argparse with exit 2. The LSEG app key and a canary password come only from the environment.
  - After a pull, neither appears in stdout, stderr or any file under the temp tree: snapshot, manifest, index,
    cds_snapshots.csv or actions.jsonl.
  - The vendor is absent from schedule.py, run_job.py and gui.html.
- **VendorNotLicensed gives exit 2** for `test` and `pull` on both vendors. The roadmap message says nothing was
  requested and no free source was used. VendorRequestError, VendorConnectionError, MarketDataError and OSError also
  exit 2, and so do the date-argument refusals.
- **Action log.** `vendor pull` writes one row per call, with outcome ok or error and exit code 0 or 2. `status` and
  `test` write nothing and are not logged, which is consistent with their being read-only.
- **GUI.** `vendor` is not in `ALLOWED_CMDS`, and `Jobs.start("vendor", ...)` raises ValueError.

**Recommendations (Info):**
- **R7.** A `vendor pull` error row has an empty `error` field. The reason goes to stderr only, because cmd_vendor
  prints it and raises `SystemExit(2)`. The row therefore lacks the reason (for example not licensed, unmapped or
  session failed). If the message is passed into the row, add the vendor secret variables to the action-log mask list
  in cli.py, next to TOKEN_ENV and the SMTP and webhook variables. Those variables are `ECONQUEST_LSEG_APP_KEY`,
  `_PASSWORD`, `_USERNAME` and `ECONQUEST_BPIPE_APP_NAME`. Mask them because the adapter's redaction matches exact
  strings only (SEC-A-005 L1). Probe: a forced VendorRequestError that carried the app key printed it on stderr.
- **R8.** The pyproject extras `bloomberg = ["blpapi"]` and `lseg = ["lseg-data"]` are unpinned. blpapi is meant to
  come from Bloomberg's index. Whether a same-named package exists on PyPI was not checked (no network). A plain
  `pip install econquest[bloomberg]` resolves from PyPI, which is a dependency-confusion exposure. Pin both versions in
  the lock. In the runbook, keep `--index-url` (never `--extra-index-url`) for blpapi, as SEC-A-005 already asks.
