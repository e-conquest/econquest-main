---
id: SEC-C-009
ticket: EQ-C-0069
author: C/AGENT-09
created: 2026-10-24
severity: low   # critical | high | medium | low | info
status: fixed          # L1 (EQ-C-0069), L2 (EQ-C-0068), I1 (EQ-C-0067) fixed with regression tests; R12 to R17 open
cwe: CWE-94/CWE-494 (code shipped in the bundle that the validator is told to run), CWE-20 (as_of validation), CWE-755 (exceptions as tracebacks)
---
# PI-5 review of EQ-C-0067 (Yahoo removal, review apply, replicate-archive), EQ-C-0068 (evidence clock) and EQ-C-0069 (data room in the evidence bundle)

## Finding
I reviewed `teamctl diff --ticket` for the three tickets now In Review and probed each change with concrete inputs in
temp folders under the scratchpad. Nothing is High or Critical, so nothing blocks a merge.

| Ticket | Result | Finding |
|---|---|---|
| EQ-C-0067 | pass | I1 (Info, fixed): replicate-archive pass-through |
| EQ-C-0068 | pass after fix | L2 (Low, fixed): `as_of` accepted a date it then answered for a different day |
| EQ-C-0069 | pass after fix | L1 (Low, fixed): `evidence verify` passed a re-signed room whose `verify.py` the README tells the validator to run |

### EQ-C-0067

**Lock regenerated 70 to 61 packages: claim verified.** I parsed both locks and compared them package by package
against `team/checkpoints/EQ-C-0067/files/requirements-lock.txt`:
- old: 70 packages, 220 hashes; new: 61 packages, 162 hashes;
- removed: cffi, curl-cffi, lxml, multitasking, peewee, protobuf, pycparser, websockets, yfinance (58 hashes);
- added: none. For the 61 packages kept, both the version and the hash set are identical;
- the only other change is the two header comment lines (the count and the `research (yfinance)` note).

No kept package needs a removed one. I checked the installed metadata of every locked package; the only misses
are behind `python_version < "3.11"` or `win32` markers. `pip install --dry-run --require-hashes --only-binary :all:
-r requirements-lock.txt` resolves all 61 packages with no missing dependency. `make_hash_lock.py --check` says ok.

**Yahoo removal.**
- `--only yahoo`, `weo,yahoo` and `YFinance` exit with one line before any request (socket and urlopen patched to
  fail the test), and nothing under `data/` changes.
- yfinance is only in the `[research]` extra, outside the lock.
- The install.sh smoke import no longer names yfinance. A hash-pinned install would otherwise fail its own smoke
  test now that the lock omits it.
- `_FEED_LABELS` keeps the Yahoo labels only so historical provenance is still named.

**review apply (allow_older, rollback).** The CLI pre-check on the raw `--vintage` string is gone. `apply_vintage`
now checks the resolved id itself, before any write. It checks again after reloading the vintage, which covers a
fetch that finishes in between. Probes with two vintages:
- the ids `../../etc`, `/etc`, `<id>/..` and `2026-10-2` give "no vintage" (vintage_path only matches listed ids),
  and nothing is written;
- the older id without `--allow-older` gives one line, and data and snapshots are unchanged;
- with `--allow-older` it applies and writes `rollback.json` (mode 0444) into the pre-apply snapshot. The CLI
  prints the rollback line and the stderr warning. The action-log row records `allow_older: true`;
- a date id of the latest vintage applies without a rollback.

The rollback's `author` is empty from the CLI (R12).

**run_pipeline market_dir.** It is `args.data` on every CLI call over a data folder, plus the report fallback. That
is the same folder the inputs already come from, so it adds no new trust. Callers that still omit it: cli.py:211 (reverse-stress base), `limits` pretrade, `stress.reverse_stress`, the API
workbench, `validation.record` and `validation.replicate`.
That is a consistency gap only, while the feature is off by default (R13).

**I1 (Info). replicate-archive pass-through.** The output paths are right: the default is `<out>/replication-archive`,
and `--out` inside the archive is refused by Team B's module. But the pass-through had three gaps:
- a refusal surfaced as a traceback. Examples: `--out` inside the archive (ValueError), a non-zip `--zip`
  (BadZipFile), an unreadable path (OSError);
- an explicit `--zip` that does not exist was silently treated as `none`. Every zip row came out NOT_RUN, and the
  report recorded the zip as "none". That is visible, but easy to miss after a typo;
- a value starting with `-` (`--out=-o`) was passed as two tokens, and Team B's parser then failed with "expected
  one argument".

The rerun only runs the zip's engine after `verify_zip`, which checks the SHA-256 against the package note, in
`python -I`. Bomb caps apply before `extractall`.

### EQ-C-0068

**CLI `evidence-clock`.** It is read-only, and `--write` writes only `<out>/evidence_monitor.csv/.md`.

**GET /api/evidence-clock.**
- It sits behind `_guard(write=False)`. A foreign Host gets 403 (DNS rebinding). The API sends no
  Access-Control-Allow-Origin header, so no other web page can read the answer.
- POST, PUT and DELETE are not routed.
- No path leaks. I checked the real-data response, a garbage `forecast_record.csv` and a folder where the file
  should be. Every answer holds file names only (`data/forecast_record.csv`, relative), and an error gives the
  exception type only.

**GUI card.** Every `${}` in the card goes through `esc()`. The status class is whitelisted to the three statuses,
the bar width is clamped to 0-100 and then escaped, and the colour is one of two constants. The existing test also
renders EVIL strings. Pass.

**L2 (Low). `as_of` validation answered for a different day.** The route checked `len(q) == 10` and then parsed
with `pd.Timestamp(q).strftime(...)`. Probes:
- `0001-01-01` gave a 200 for **2001-01-01**: strftime writes year 1 as `1-01-01`, which resolve_as_of then reads
  as 2001;
- `１２３４-10-24` (full-width digits) gave a 200 for 1234-10-24, and `2026/10/24` was accepted;
- `9999-12-31` and `2262-04-12` gave a 200 "invalid" card (OutOfBoundsDatetime) rather than a 400.

The CLI's shared `_as_of_arg` has the same year-before-1000 shift: `--as-of 0001-01-01` ran as 2001-01-01.
`2026-13-01`, `2026-02-30`, `<script>`, `../../../e` and NUL bytes were already a 400.

### EQ-C-0069

**Temp build location.** The room is built only when neither `--data-room` nor `<out>/dataroom/<as_of>/` exists,
into `mkdtemp` (TMPDIR). Probes with TMPDIR set to `--data`, `--out`, a subfolder of `--data`, and a symlink to
`--data` are all refused ("set TMPDIR elsewhere"). A snapshot of data/ and outputs/ before and after is identical:
the empty mkdtemp folder is removed in `finally`, and no zip is written.

On the real data, `build_data_room` raises a TypeError in Team A's `limitations.build_register`
(`int(li.loc[k]...)`, a duplicate index). The temp folder is still removed (TMPDIR checked empty afterwards), but
the build stops with a traceback, because `_data_room` catches only ValueError, FileExistsError and
FileNotFoundError (R15).

**Refusals, each probed:**
- a symlinked file or folder in the room;
- a secret-looking name (`data/api_token.json`), even with the room's MANIFEST re-signed to list it;
- an extra file (Team A's verify fails);
- the schema forged to `econquest.dataroom/2` and re-signed;
- `as_of` forged and re-signed;
- a credential value (the existing test).

**Does `evidence verify` run archive code? No.**
- `_verify_room_bytes` imports `econquest.ingestion.dataroom.verify_data_room`, which is this installation's
  `dataroom_verify.verify_room`. It writes the bytes to a fresh mkdtemp, never changes directory, never imports
  from the room and never starts a subprocess.
- Probe: a fully re-signed archive with a payload in `verify.py` and planted `dataroom_verify.py`, `json.py`,
  `hashlib.py`, `csv.py`, `__init__.py` and `sitecustomize.py`, verified with the room's folder as cwd. The canary
  file was never created.
- `python -I verify.py` (README step 3) also does not put the script's folder on sys.path (`-I` implies `-P`), so a
  planted module is not picked up there either.

**L1 (Low). The same forged archive passed `evidence verify` (data room ok, verify.py with a payload).** Team A's
`verify_room` does not compare `verify.py` with anything. Our check compares the room's manifest_sha256 and
content_sha256 with EVIDENCE-MANIFEST, which the forger rewrites too, since the chain is unkeyed (SEC-C-008 L4/R2).
The bundle README then tells the validator to run `python3 -I dataroom/team-a/verify.py`. That runs code taken from
the archive on the validator's machine.

**Zip-slip on the room extract: none.** Probes:
- `dataroom/team-a/../../../../<abs>`, `../../x.txt` and `a\..\..\y.txt` are refused as unsafe entry names;
- `team-a//<abs>`, `./z.txt` and `q//w.txt` pass the entry check, but `safe_rel` refuses them before any write;
- a file/folder clash (`data/live` as a file) gives "cannot be extracted (FileExistsError)";
- nothing was written outside the temp folder, and no `econquest-evidence-room-*` folder is left over.

A room MANIFEST.json that is a JSON array, a string, or not UTF-8 raised an uncaught AttributeError or
UnicodeDecodeError in `_verify_packed_room`. That is fixed with L1.

The real room for 2026-10-23, built with `limitations=False` to get past R15: 24 files, 14 MB, `verify.py` VERIFIED.
It holds no address, no absolute path and no credential.

## Exploit scenario
- **L1:** someone who can swap the bundle in transit, and re-sign both the room and EVIDENCE-MANIFEST, gets code run
  on the validator's machine. The validator only has to follow README step 3. The zip SHA-256 sent by another route
  is still the trust anchor, so this is defence in depth. It is Low, not Info, because the README tells the
  validator to execute the file.
- **L2:** someone on the desk opens `?as_of=0001-01-01`, by a typo or a test, or runs `evidence-clock --as-of
  0001-01-01`, and gets 2001-01-01's evidence clock labelled as the date they did not ask for. No attacker gains
  anything; the integrity of the date shown is the point.
- **I1:** a validator mistypes `--zip` and gets a replication report with every zip row NOT_RUN, recorded as "none".
  A misleading traceback is the other effect.

## Fix
Checkpointed under each ticket; cli.py edited with exact-string replacements.
- **L1 (EQ-C-0069):** `econquest/ops/evidence.py` `_verify_packed_room` (line 838).
  - It compares the room's `verify.py` with this installation's `econquest/ingestion/dataroom_verify.py`
    (`VERIFY_SOURCE`). The build copies that file byte for byte.
  - A difference is an error when EVIDENCE-MANIFEST's `code_version` equals the installed version. Otherwise it is
    a warning that names both versions, since verify.py can legitimately change between releases. The CLI prints
    `warning: data room: ...`.
  - The result gains `verify_py_matches_installed` and `warnings`.
  - A room MANIFEST that is not a JSON object, or not UTF-8, is now an error, not a traceback.
  - Tests in tests/test_evidence.py:
    - `test_verify_never_runs_room_code_and_flags_a_foreign_verify_py`: forged, re-signed, modes kept; the canary is
      never created;
    - `test_room_manifest_that_is_not_an_object_is_an_error_not_a_traceback` (3 cases).
- **L2 (EQ-C-0068):** a new `evidence_view.as_of_param` (line 23).
  - It requires exactly `[0-9]{4}-[0-9]{2}-[0-9]{2}` in ASCII, a real calendar date (`date.fromisoformat`), and a
    year inside pandas' Timestamp range. gui.py:212 uses it, and anything else is a 400.
  - `cli._as_of_arg` (line 109) refuses a normalised result that is not 4-digit-year YYYY-MM-DD, so the
    year-before-1000 shift is gone for every `--as-of`.
  - Tests in tests/test_cli_evidence_clock.py:
    - `test_route_refuses_any_as_of_that_is_not_a_plain_date` (9 cases);
    - `test_route_answers_for_exactly_the_date_asked`;
    - `test_cli_as_of_refuses_years_before_1000` (2).
- **I1 (EQ-C-0067):** `cli.cmd_replicate_archive` (line 1025).
  - An explicit `--zip` that is not a file gets a one-line refusal before the module runs.
  - ValueError, OSError and BadZipFile from the module become one-line exits.
  - A value starting with `-` is passed as `--flag=value`.
  - Tests in tests/test_cli_replicate_archive.py:
    - `test_missing_zip_is_refused_not_silently_skipped`;
    - `test_dash_value_stays_the_flags_value`;
    - `test_dash_value_parses_in_the_real_module`;
    - `test_module_errors_are_one_line_exits` (3).
  - `test_flags_pass_through` now creates the zip it names.

**Recommendations (open):**
- **R12 (Info, EQ-C-0067).** `review apply --allow-older` records `author: ""` in rollback.json. Add `--author`,
  required with `--allow-older`, or record the action-log actor in the rollback.
- **R13 (Info).** Pass `market_dir` in the remaining run_pipeline callers: reverse-stress, pretrade, the API
  workbench, record and replicate. Otherwise a run with market RV on and one without can differ silently once the
  feature is enabled.
- **R14 (Info, Team B).** `replicate_archive.main` skips a missing `--zip` itself. The CLI now refuses it, but
  `python -m econquest.validation.replicate_archive` does not. Its `--archive`/`--db` defaults are checkout-relative,
  not `--out`-relative.
- **R15 (Low, functional, Team A/AGENT-10).** On today's real data `econquest evidence --as-of 2026-10-23` stops
  with a TypeError traceback when no room exists for the date, coming from `limitations.build_register` (EQ-A-0044,
  in flight). It is safe: the temp folder is removed and no zip is written. But the EQ-C-0069 acceptance on real
  data cannot pass until it is fixed. `_data_room` should also turn any build exception into an EvidenceError.
- **R16 (Info).** README step 3 should say: run `econquest evidence verify` first, and run `verify.py` only when it
  reports no data-room warning. Better, publish the SHA-256 of dataroom_verify.py per release, with the zip SHA-256.
- **R17 (Info).** The room's credential check matches raw UTF-8 bytes only. A value inside a compressed or UTF-16
  file in the room would pass. No such file is in a room today.

## Verification
```
python3 -I lockdiff.py team/checkpoints/EQ-C-0067/files/requirements-lock.txt requirements-lock.txt
# old 70 220 new 61 162; removed [cffi curl-cffi lxml multitasking peewee protobuf pycparser websockets yfinance]; added []; CHANGED none
pip install --dry-run --ignore-installed --require-hashes --only-binary :all: -r requirements-lock.txt --report rep.json   # 61 to install
python scripts/make_hash_lock.py --check                    # lock ok: 61 packages
probe_review.py   # traversal ids refused, older refused without flag, rollback.json 0444 with flag, action log allow_older true
probe_clock.py    # pre-fix: 0001-01-01 -> 200 as_of 2001-01-01; full-width -> 200; 9999-12-31 -> 200 invalid; rebind 403; no path in any body
probes/test_probe69.py   # 13 passed: TMPDIR x4 refused + data/out unchanged; symlink file/dir, secret name, extra, schema, as_of refused;
                         # forged verify.py + planted modules: canary absent (pre-fix: data_room ok True); zip-slip x6 nothing written
replicate-archive --out outputs/store/archive/x / --zip bad.zip / --zip=-x   # pre-fix: traceback / traceback / "expected one argument"
python -m pytest -q tests/test_cli_replicate_archive.py tests/test_cli_evidence_clock.py tests/test_evidence.py   # 59 passed
python -m pytest -q tests/test_cli_review.py tests/test_cli_fetch.py tests/test_cli_run_asof.py tests/test_install.py \
  tests/test_release.py tests/test_dataroom*.py tests/test_gui_*.py tests/test_evidence_monitor.py tests/test_replicate_archive.py   # 166 passed, 4 skipped
ruff check (7 changed files)   # All checks passed
bandit -q -ll evidence_view.py evidence.py gui.py   # no findings
python -m pytest -q -x tests   # 1944 passed, 5 skipped (11 min), exit 0
```
