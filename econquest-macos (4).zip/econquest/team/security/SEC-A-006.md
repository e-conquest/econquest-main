---
id: SEC-A-006
ticket: EQ-A-0043
author: A/AGENT-09
created: 2026-10-24
severity: medium   # critical | high | medium | low | info
status: open           # open | fixed | accepted-risk (needs EXC- id) | false-positive
cwe: CWE-200 (exposure to an unauthorised actor; licence), CWE-601/CWE-400 (redirect followed, unbounded read), CWE-59 (link following), CWE-345
---
# PI-5 data security review: Yahoo-derived values in desk numbers and the data room, official FX fetch without redirect refusal or size cap, verify.py on hostile rooms

Scope (EQ-A-0043, PI-5 independent validation). Team A ingestion changes in PI-5, from `teamctl diff`:
- EQ-A-0041 and EQ-A-0044: the data room (`econquest/ingestion/dataroom.py`, `dataroom_verify.py`, `limitations.py`).
- EQ-A-0040: official FX (`feeds.py` BisFeed.fetch_xru / EcbExrFeed, `market/forwards.py`, `market/gate.py`).
- EQ-A-0039: SEC-A-004 L1-L3.
- EQ-A-0044: BIS staleness in `quality_gate` and `ledger.import_legacy_review`.

Plus a sweep of `econquest/ingestion/` and `econquest/ingestion/events/`.

Result: **no Critical or High finding, so nothing blocks Done.**
- 2 Medium: both are licence findings, and Sam decides on them.
- 7 Low.
- 4 Info.

SEC-A-004 and SEC-A-005 are re-verified as fixed (their files are updated). SEC-A-001..003 were already fixed.

## Method
- Code review of the diffs of EQ-A-0039/0040/0041/0044, and of the functions they call.
- Probes, not committed, under `/tmp/claude-0/-home-claude-econquest-main/4d046af0-0329-5499-894e-87a0bbd3789c/scratchpad/`:
  - `probes/probe_build.py`: a hostile data_dir for `build_data_room`.
  - `probes/probe_verify.py`: hostile rooms for `verify.py`.
  - `sec43/probe39.py`: SEC-A-004 V6/V7 and empty-feeds variants.
  - `sec43/probe33b.py`: SEC-A-005 S1-S9.
- A data room built from a scratch copy of `data/` (as of 2026-10-23). The source tree was sha256-compared before and after the build: unchanged.
- `bandit -q -r econquest/ingestion` (bandit 1.9.4): 7 Low, 0 Medium, 0 High. Triage is below.
- pip-audit 2.x is installed but was **not run**. It queries the PyPI/OSV vulnerability service over the network, and
  this review runs with no network. Run `pip-audit -r requirements-lock.txt` on the Mac or in CI (T5).
- Secret grep over `data/` and `docs/` (141 files):
  - private keys, AKIA, gh*_ / github_pat_, xox*, sk-, AIza, JWT;
  - `password|api_key|app_key|client_secret|access_token|auth_token|bearer = <8+ chars>`;
  - e-mail addresses;
  - credential-named files.

  No hits. The only matches are keychain lookups (`$(security ...)`) and placeholders (`password=...`) in runbooks.
- Tests:
  - `pytest tests/test_dataroom.py test_apply_vintage.py test_feeds_official_fx.py test_market_gate.py test_market_forwards.py test_bis_staleness.py test_ledger.py test_limitations.py test_ops_backup.py test_market_vendors.py`: 161 passed.

## Verified OK
- **Data room secret exclusion (build).** The following are excluded and never reach the room:
  - `.env` and other hidden files;
  - `vendor_licences.json` and credential-named files;
  - JSON with credential keys at any depth (`a.b[0].Access_Token`);
  - AKIA keys in text;
  - non-commercial licence CSVs (withheld and hashed).

  `sam.m.carus@gmail.com`-style addresses are redacted.
- **Symlinks and path traversal (build).**
  - A leaf symlink to a file outside data_dir is skipped.
  - A symlinked vintage folder is skipped, and its content (`OUTSIDE-DIR-LEAK`) is not in the room.
  - `index.csv` and `feeds.json` symlinks are not read.
  - out_dir inside data_dir is refused (resolved paths).
- **Point in time (build).**
  - A ledger row dated after the cutoff is dropped, and so is an undated ledger row.
  - A vintage folder dated after the cutoff is left out.
  - include_current is refused when any dated record is after the cutoff.
- **data/ never written.** The build only reads data_dir. The room goes to a temp sibling of out_dir, then is renamed.
  The sha256 of every file under data_dir is identical before and after the build: checked on the real-data copy
  (59 files) and on the probe tree.
- **verify.py (hostile room).**
  - It uses the standard library only (`csv, hashlib, json, sys, pathlib`) and makes no writes.
  - Manifest paths `../../../../etc/passwd` and `/etc/passwd` are refused as unsafe.
  - A tampered file fails. A withheld list emptied without re-hashing fails (manifest_sha256 mismatch).
  - A planted `csv.py` next to verify.py does not run under `python -I` (the documented command).
- **Tamper detection.**
  - `withheld`, `redactions` and `altered_anchors` are inside manifest_sha256.
  - Live-vintage anchors require every index row for an id to agree.
  - A withheld file that is present, or also listed as a file, is reported unsafe.
- **Official FX.**
  - BIS and ECB bases must be https (`feeds.py:568`, `:837`).
  - A proxy refusal or DNS failure raises FeedUnreachable and ends the feed (fail-fast, EQ-A-0037).
  - The ECB series key must be `D.<CCY>.EUR.SP00.A`, else FeedError.
  - `fetch_all(only=["yahoo"|"yfinance"])` raises before any request, and no FEED_ALIASES entry reaches Yahoo.
  - `forwards --spot yahoo` is refused without `ECONQUEST_ALLOW_YAHOO=1`. With it, the rows carry YAHOO_LICENCE and
    the market gate holds them (probe).
  - Market-gate holds have no ledger release: `gated_history` drops held rows from the CDS export, so the licence
    hold cannot be approved away.
- **BIS staleness (EQ-A-0044).**
  - The CLI passes no as_of, so the reference date is the pull date from provenance and cannot be back-dated from
    the command line.
  - A stale cell is `hold`, released only by a four-eyes ledger decision (the SEC-A-001 rules).
  - All 25,031 real raw_bis periods parse (D/M/Q).
- **import_legacy_review (EQ-A-0044).** A review.csv row hand-edited to `ok` while it still carries a gate reason is
  imported as `gate_status=hold`. The change only tightens. It runs only when no ledger exists, and never writes a
  release.

## Findings

### M1 (Medium): 17 Yahoo-derived `fx3m` cells are still in the desk inputs
**Where.** The 17 cells sit in:
- `data/countries.csv`, column `fx3m`;
- `data/audit_trail.csv`: 17 rows with `source = yfinance (Yahoo Finance)`, `origin = live feed`, `gate_status = ok`.

They were applied on 2026-10-23, before EQ-A-0040. The engine reads them:
- `engine/layer2_bayesian.py:81` (`prof["fx3m"]`);
- `engine/layer3_regime.py:27`.

**What.** Sam decided on 2026-10-23 that Yahoo (personal, non-commercial terms) must not feed desk numbers. EQ-A-0040
removes Yahoo from the fetch path, but the values it applied earlier stay in place until the next official FX pull on
the Mac is applied. Nothing marks them, holds them or refuses them in a run or a publish:
- the market gate covers market snapshots, not `countries.csv`;
- `docs/runbooks/A-official-fx.md` only compares the new values against them.

Values checked against the audit trail: Vietnam -1.771, Philippines 2.866, China -1.481, Malaysia -0.07832 are the
Yahoo values.

**Exploit scenario.** No attacker is involved: this is licence compliance. A run or publish before the Mac pull uses,
and shows on the Risk Desk Sheet, numbers derived from Yahoo data.

**Fix.** Owner: AGENT-06. Sam decides the interim.
1. Run `econquest fetch --only fx --apply` on the Mac (runbook A-official-fx) as the first PI-5 Mac task. Then
   confirm that `audit_trail.csv` has no `yfinance` source.
2. Until then, do one of:
   - (a) revert the 17 cells to their seed values (pre-apply snapshot, runbook A-restore step A), leaving the rest
     of that apply;
   - (b) Sam records an EXC- entry accepting them until the pull.
3. Add a check (health or `teamctl`-style, Team A) that fails while any applied cell's audit source is yfinance/Yahoo.

**Test.** After the pull, `grep -ci yfinance data/audit_trail.csv` returns 0, and the new check passes.

### M2 (Medium): the data room passes Yahoo-derived values to the external validator
**Where.**
- `dataroom.py:245-275` (`restricted_reason`): the only triggers are the file name `raw_yahoo.csv` and a CSV
  `licence` column.
- `dataroom.py:518-526`: current-pull and audit files are copied whole.

**What.** In the room built from the real data (as of 2026-10-23), `raw_yahoo.csv` is withheld. These are still
exported:
- `data/live/provenance.csv`: 27 rows `source = yfinance (Yahoo Finance)`, with values (fx3m, `equity_vol` e.g.
  Vietnam 21.18);
- the same 27 rows in `data/live/vintages/2026-10-23/provenance.csv`;
- `data/audit_trail.csv`: 17 rows;
- the Yahoo-derived numbers in `live_profile.csv` (current pull and vintage), which carry no source label.

None of these files has a `licence` column, so the licence rule never sees them. EQ-A-0044 states the intent:
"Yahoo's terms ... do not allow passing the data to an external validator". That covers the raw prices only.

**Exploit scenario.** No attacker: licence compliance. Values computed from Yahoo data leave the desk in the
validator's room.

**Fix.** Owner: AGENT-06. Sam confirms the policy.
- Preferred: in the room copies of `provenance.csv`, `audit_trail.csv` and the vintage `live_profile.csv` /
  `live_inputs.csv`, blank the value of every row whose `source` matches `yfinance|yahoo` (or which a provenance row
  maps to Yahoo). Record each changed file under the hashed `redactions` list with its original sha256, as the
  e-mail redaction does, so verify.py reports the vintage as `altered`.
- Or Sam records that derived figures may be passed on (EXC- entry), and the README says so.

**Test.** A fixture with a Yahoo provenance row gives a room with no Yahoo value, and verify.py returns VERIFIED with
the vintage `altered`.

### L1 (Low): BIS and ECB fetches follow redirects (also to http) and read the body without a size cap
**Where.**
- `feeds.py:565-574` (`BisFeed._get`);
- `feeds.py:834-842` (`EcbExrFeed._get`).

Both use plain `urllib.request.urlopen` and `r.read()`. Pre-existing for BisFeed (EQ-A-0012), new for EcbExrFeed.

**What.** The https check runs on the first URL only. The default `HTTPRedirectHandler` follows 301/302/303/307/308
to any host and to plain http, and the body is read whole. `events/base.http_fetch` already provides https-only,
no-redirect and a size cap (SEC-A-002), but the official FX path does not use it.

**Exploit scenario.** The upstream server, a CDN or a captive portal answers with a redirect. A network attacker on the
http leg could then feed FX rates. Three things limit this:
- no credential is sent;
- the BIS-vs-ECB cross-check (`fx_cross_checks`) holds fx3m when the sources disagree;
- the fx3m change/range gate applies.

An oversized answer exhausts memory on the Mac.

**Fix.** In both `_get` methods, fetch through `events.base.http_fetch(url, headers=..., timeout=..., max_bytes=...)`
or `build_no_redirect_opener()`. Use a cap of about 50 MB for BIS and 20 MB for ECB, and raise on a 3xx. Apply the same
change to `sources._http_json` (`sources.py:64-73`) and `GoogleSheetsSource` (`sources.py:150`), which are older code
with the same pattern.

**Test.** A fake opener returning 302 to `http://` makes the feed fail with "redirect ... not followed". A body over
the cap raises.

### L2 (Low): verify.py follows symlinks inside a hostile room
**Where.**
- `dataroom_verify.py:330-338`: `p.is_file()`, then `sha256_file(p)`;
- `:341` (`present`);
- `:134-136` (`folder_content_hash`: `is_file()`, `read_bytes()`);
- `:196` (`folders`: `is_dir()`).

**What.** In probe_verify.py, `data/live/src.csv` was replaced by a symlink to a file outside the room. When the
target has the same bytes, or when the manifest is re-hashed to point at `/etc/passwd`, verify.py reads outside the
room and prints VERIFIED. A symlinked directory under `data/live/vintages` is content-hashed from outside the room.
The build never emits symlinks, so any symlink in a room is tampering.

**Exploit scenario.** Someone hands a validator a crafted room. Nothing is written or leaked, because only hashes are
computed. But "VERIFIED" no longer means "these bytes are in this folder", and the validator's machine reads arbitrary
paths.

**Fix.** In `verify_room`, report any path in the room that is a symlink, or has a symlinked parent, as `unsafe`
(`os.lstat` / `Path.is_symlink()` on each part). In `folder_content_hash` and `folders`, skip or fail symlinks.

**Test.** A room with one leaf symlink and one directory symlink fails with `unsafe`.

### L3 (Low): verify.py is not bounded or robust against malformed input
**Where.**
- `dataroom_verify.py:136`: whole-file `read_bytes()` for vintage hashing;
- `:315`: whole MANIFEST.json loaded, catching only OSError/ValueError;
- `:274-275`: replay manifest `files` assumed to be a dict;
- `:353-355`: withheld paths not checked with `safe_rel`.

**What.** Probe results:
- a 200k-deep JSON MANIFEST.json crashes with an uncaught `RecursionError`;
- a replay `manifest.json` with `"files": [...]` crashes with `AttributeError`;
- a withheld entry `../../../etc/passwd` is accepted (it only triggers a `stat` outside the room) and the room
  VERIFIES.

Every crash exits non-zero, so the tool fails closed, but with a traceback instead of a report. A multi-GB file in a
vintage folder is read whole into memory.

**Fix.**
- Catch `RecursionError` and `TypeError`/`AttributeError` around the manifest parse and the anchor checks, and report
  them as `error`/`failed`.
- Type-check `files` (a dict of str to str).
- Apply `safe_rel` to `withheld` and `redactions` paths.
- Hash vintage files in chunks, as `sha256_file` does.
- Refuse a MANIFEST.json over a cap (e.g. 64 MB).

**Test.** Each hostile room above gives a FAILED report with no traceback.

### L4 (Low): data-room secret and redaction patterns have gaps
**Where.**
- `dataroom.py:132-133` (`SECRET_KEY_RE`, used with fullmatch);
- `:134-138` (`SECRET_TEXT_RE`);
- `:250` (`RESTRICTED_FILES` lookup is case-sensitive);
- `:278-285` (`redact_emails`, UTF-8 only).

**What.** probe_build.py exported each of these:
- `{"user": "sam", "pass": "hunter2hunter2"}`: `pass` is not a key in the list;
- `Authorization: Bearer eyJ...`: there is no bearer/JWT text pattern;
- a file named `RAW_YAHOO.csv`;
- `sam%40example.com` (URL-encoded);
- an e-mail in a UTF-16 file.

No such content exists in `data/` today (grep above).

**Exploit scenario.** Only through a future file or a mis-saved export. Defence in depth.

**Fix.**
- Add `pass`, `pw` and `auth` to the key list.
- Add `\bBearer\s+[A-Za-z0-9._~+/-]{16,}` and a JWT pattern `eyJ[\w-]{8,}\.[\w-]{8,}\.` to `SECRET_TEXT_RE`.
- Compare RESTRICTED_FILES case-insensitively and also match `*yahoo*` names.
- Decode `%40` before matching e-mails, and try UTF-16 when there is a BOM.

**Test.** Extend `tests/test_dataroom.py` with each probe case.

### L5 (Low): apply_vintage skips the no-feed refusal when feeds.json lists no feeds
**Where.** `feeds.py:2300`: `if rep.feeds and not any(...)`.

**What.** probe39.py V7b/V7c built a vintage by hand, correctly indexed, whose `feeds.json` is `{"feeds": {}}` or has no
`feeds` key. `apply_vintage(..., cells=[FX])` records an approved decision (1 ledger row) and applies it. With an
`error:` feed it refuses and writes 0 rows (SEC-A-004 L3 fixed). `save_vintage` never writes such a folder, so this
needs a hand-built vintage plus an index row.

**Fix.** Use `if not any(str(v).startswith("ok") for v in (rep.feeds or {}).values()):`.

**Test.** V7b and V7c raise VintageContentError and write 0 ledger rows.

### L6 (Low): the market gate's Yahoo hold keys only on the licence text
**Where.**
- `market/gate.py:130-134`;
- `market/forwards.py:289-290`: `spot_from_yahoo_raw(..., licence=YAHOO_LICENCE)` lets the caller choose the licence.

**What.** In the probe, rows from `spot_from_yahoo_raw(raw, ccy, licence="free official")` keep `source = yahoo` but
pass the gate (`ok`). The CLI never does this: the opt-in path passes YAHOO_LICENCE. A script or a future caller can.
A manual or vendor import labelled `source=yahoo` with a clean licence would also pass.

**Fix.**
- In `market_gate`, hold any row whose `source` (case-folded) is `yahoo` or `yfinance`, whatever its licence.
- Remove the `licence` parameter from `spot_from_yahoo_raw`.

**Test.** A Yahoo-source row with a clean licence is held.

### L7 (Low, Team C code): a restore makes vintage and snapshot files writable again
**Where.**
- `ops/backup.py:126`: every tar member is stored with `ti.mode = 0o644`;
- `ops/backup.py:291`: restore writes with default modes.

**What.** Restore drill evidence (`docs/runbooks/A-restore.md`): source vintage and replay-snapshot files are `0444`,
and the restored copies are `0644`. The T4 control "vintage and snapshot files are written mode 0444" therefore does
not survive a restore. Runbook step C (`cp -p <kept_at>/data/<file> data/`) carries 0644 back. Content is unaffected:
hashes and verify_vintage pass.

**Fix.** Owner: Team C (AGENT-10), handoff from EQ-A-0043.
- Record each member's mode in the manifest and re-apply 0444/0555 for `data/live/vintages/**`,
  `data/live/snapshots/**`, `data/panel/vintages/**` and market snapshots on restore.
- Team A updates runbook step C to `chmod a-w` after copying a vintage back.

**Test.** After `restore-drill --keep`, the vintage files under kept_at are 0444.

## Info
- **I1. Tamper detection needs an out-of-band hash.** Anyone who edits a room and re-computes `manifest_sha256` gets
  VERIFIED. This includes moving a tampered file under `redactions`, which turns a vintage anchor failure into an
  `altered` warning (probe: a consistent tamper VERIFIED). This is by design: README tells the validator to compare
  `manifest_sha256` with the value in the evidence bundle.
  - verify.py itself sits in the room, so a hostile room can ship its own verify.py. Add one README line: obtain
    verify.py, or its sha256, from the evidence bundle and not from the room, and run it with `python -I`. Without
    `-I`, a planted `csv.py` in the room runs (probe).
- **I2. BIS staleness fails open on unreadable periods.** `feeds.py:1716` returns '' when no period parses (e.g. a
  future `2026-W27` or a datetime period). All real periods parse today. Optional: return a `stale: unreadable
  periods` hold instead.
- **I3. The limitations register in the room is partly post-cutoff.** It reads indicators.csv, countries.csv,
  rulebook.csv as working copies, and its narrative is hand-written. This is documented in RULES and the README as
  the one exception to the cutoff.
- **I4. Trust on first use of the legacy vintage.** `data/live/vintages/index.csv` does not exist yet in `data/`, so
  `2026-10-23` is unanchored: verify_vintage raises "no row" on both the source and the restored copy. The first
  `save_vintage` on the Mac hashes the legacy folder as it is at that time. Before that first Mac fetch, compare the
  folder with the 2026-10-23 backup, so that the anchor is set on known-good bytes.

## Bandit triage (`bandit -q -r econquest/ingestion`, 7 Low)
| # | Location | Test | Triage |
|---|---|---|---|
| 1 | events/acled.py (OAuth token URL constant) | B105 | False positive: a URL, not a secret |
| 2 | events/base.py:59 `"token_env": "UCDP_API_TOKEN"` | B105 | False positive: an env variable name |
| 3 | events/ucdp.py:41 `TOKEN_HEADER = "x-ucdp-access-token"` | B105 | False positive: a header name |
| 4 | feeds.py:303 try/except/continue (WEO code missing in a vintage) | B112 | Accepted: deliberate skip, the missing series surfaces as an unserved/missing cell |
| 5 | feeds.py:1216 try/except/pass in the log-capture handler | B110 | Accepted: a bad log record must not break a fetch |
| 6 | sources.py:98 try/except/pass (Polymarket price parse) | B110 | Accepted, Low: a bad market is counted as not live (`live=n/m` in attrs). Narrow to `(ValueError, TypeError, KeyError, IndexError)` when touched |
| 7 | sources.py:125 try/except/pass (Kalshi) | B110 | As 6 |

There are 8 `# nosec` suppressions, each with a stated reason. `feeds.py:572` and `:841` (B310) are correct only for
the https scheme: see L1 for the redirect and the size cap.

## Earlier findings (SEC-A-001..005)
| ID | Status | Re-checked |
|---|---|---|
| SEC-A-001 | fixed | earlier (EQ-A-0006) |
| SEC-A-002 | fixed | earlier (EQ-A-0022) |
| SEC-A-003 | fixed | 2026-10-23 (EQ-A-0038) |
| SEC-A-004 | **fixed** (was open) | 2026-10-24 here: L1 V5 refused; L2 V6 refused without allow_older, rollback.json written with it; L3 V7 0 ledger rows. New edge L5 above |
| SEC-A-005 | **fixed** (was open) | 2026-10-24 here: S1/S2 no leak (type name only); S3 no secret in vars(); S4 key-like licence_id refused, not echoed; S5 nested and sibling keys refused, not echoed; S6-S9 unchanged |

None is still open.

## Exploit scenario
No remote code execution, credential leak or four-eyes bypass was found.
- The two Mediums are licence compliance (Yahoo terms) and need Sam's decision.
- The Lows are defence in depth for:
  - the network path of the official FX feeds;
  - verify.py on a crafted room;
  - pattern gaps in the room's secret filter;
  - one hand-built-vintage edge.

## Fix
| Finding | Owner |
|---|---|
| M1, M2, L1, L3, L4, L5, L6 | Team A (AGENT-06), assign via AGENT-08 |
| L2 | Team A (AGENT-06), in `dataroom_verify.py` |
| L7 | Team C (AGENT-10), by handoff |
| Threat-model rows | Team C (AGENT-11, file owner), by handoff |
| M1 interim and M2 policy | Sam |

## Verification
After the fixes:
```
python -m pytest -q tests/test_dataroom.py tests/test_apply_vintage.py tests/test_feeds_official_fx.py tests/test_market_gate.py
python <scratchpad>/probes/probe_build.py <scratchpad>   # pass/pw/bearer/RAW_YAHOO/%40 not in room
python <scratchpad>/probes/probe_verify.py <scratchpad>  # symlink rooms FAILED (unsafe); no traceback
python <scratchpad>/sec43/probe39.py                      # V7b/V7c raise, 0 ledger rows
grep -ci yfinance data/audit_trail.csv                    # 0 after the Mac FX pull (M1)
```

## Re-verification of EQ-A-0045 (2026-10-24, AGENT-09)
Status: **open, for M1 only.** M1 is mitigated and is awaiting the official FX pull on the Mac, plus
HO-20261024-A-C-007. M2 and L1-L6 are **fixed**. L7 stays with Team C (HO-20261024-A-C-006). I1-I4 are unchanged
Info. Every check below was run independently against the EQ-A-0045 code.

| Finding | Result | Evidence |
|---|---|---|
| M1 | **Mitigated, not cleared.** Awaiting the Mac pull (`econquest fetch --only fx --apply`) and HO-20261024-A-C-007 (Team C, C/AGENT-01, open: warn on run, block publish) | `python -m econquest.ingestion.audit restricted --data data`: "17 restricted-source cells", Country Profile fx3m 17, exit 1 (read-only). `apply_vintage` on a scratch copy prints the stderr banner "WARNING (SEC-A-006 M1): 16 applied cell(s)..." (16 because the fixture replaced Brazil with a non-Yahoo value) and returns `restricted_source_cells`. Until HO-A-C-007 lands, a run or publish is not blocked. |
| M2 | Fixed | A room built from a copy of the real `data/` (as of 2026-10-23) VERIFIES, with 8 files redacted and 2 withheld. The Yahoo values 21.18129166258072, -1.7709204225887447, -1.771 and 26345.0 are absent. The 27 provenance rows keep their source label with the value blank. (`2.866` hits only `raw_weo.csv`, NGA NGDPDPC 2112.866754, which is unrelated.) |
| L1 | Fixed | BisFeed, EcbExrFeed and `sources.py` all go through `sources.https_get`, and no `urlopen` call is left. Loopback test: a 302 gives RedirectRefused (an HTTPError, final); a 5000-byte body over a 1000-byte cap gives ResponseTooLarge; an http URL gives ValueError. |
| L2 | Fixed | `probes45/probe_verify_mail.py`: a leaf symlink (same bytes, or `/etc/passwd` with the manifest re-hashed) gives FAILED, and so does a directory symlink under `vintages/`. |
| L3 | Fixed | A 200k-deep manifest, a 64 MB+ manifest, replay `files` as a list, wrong-type `files` entries, `withheld` as a string, and `withheld`/`redactions` traversal paths all give FAILED with no traceback. |
| L4 | Fixed | `probe_build.py`: `pass`, Bearer/JWT, `RAW_YAHOO.csv`, `%40` and UTF-16 e-mails are not in the room. A Yahoo-source CSV with no value column is withheld. Source tree unchanged. |
| L5 | Fixed | `probe39.py` V7b `{"feeds": {}}` and V7c (no `feeds` key) raise VintageContentError with 0 ledger rows. V7 is unchanged. |
| L6 | Fixed | `spot_from_yahoo_raw` no longer takes a licence. A `source=yahoo` row with a clean licence is `hold`. A mixed-case source is refused by the schema. `bis_xru` is ok. |

I1 still holds: a consistently re-hashed room VERIFIES, and a planted `csv.py` runs only without `-I`. Both are by
design, and the README must keep directing validators to the out-of-band hash, a verify.py from the evidence bundle,
and `python -I`.

Tests: 180 passed (test_dataroom, apply_vintage, feeds_official_fx, market_gate, market_forwards, audit_restricted,
sources_security, feeds_offline, feeds_scale, feeds_cbs_history). bandit on ingestion: the same 7 triaged Lows,
nothing new.

To close M1:
- `python -m econquest.ingestion.audit restricted --data data` exits 0 after the Mac pull;
- HO-20261024-A-C-007 is done.
