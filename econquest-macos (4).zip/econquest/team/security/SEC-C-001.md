---
id: SEC-C-001
ticket: EQ-C-0002
author: C/AGENT-09
created: 2026-10-23
severity: medium   # critical | high | medium | low | info
status: fixed          # open | fixed | accepted-risk (needs EXC- id) | false-positive
cwe: CWE-807 (security decision on untrusted input), CWE-200 (token exposure), CWE-538 (secrets in shipped files), CWE-1068
---
# Security review of EQ-C-0002/0007/0010/0001/0008: GUI --write bypass via argparse prefixes, token on redirect, secrets in release zip, pip-audit gate skip

## Finding
Found by manual review of `teamctl diff` for EQ-C-0002, EQ-C-0007, EQ-C-0010, EQ-C-0001 and EQ-C-0008, plus a probe
script (scratchpad, not committed). No High or Critical finding. One Medium and three Lows, all fixed in this pass
(each fix is under 20 lines, checkpointed under the owning ticket, with a regression test).

**M1 (EQ-C-0002). The GUI's `--write` / `--token-file` strip was bypassed by argparse prefix matching
(econquest/presentation/gui.py, Jobs.start).** `Jobs.start` dropped only the exact strings `--write`, `--token-file`
and `--token-file=...`. argparse accepts any unique prefix (allow_abbrev is on), so a client-sent `--wr` became
`--write` and `--token-f PATH` / `--token-fi=PATH` became `--token-file PATH`. Probe: `jobs.start("garch", ["--wr"])`
gave a child argv ending in `--wr`, and `cli.main(["garch", "--wr"])` took the `--write` branch (env, then Keychain).
`--token-f /etc/hostname` made the CLI read that file as the bearer token. This breaks the design rule that a job
without a token in the request never writes and never consults the Keychain.

**L1 (EQ-C-0007). The bearer token was forwarded on HTTP redirects (presentation/sheets_publish.py, apply_plan).**
The Authorization header was set as a normal `Request` header. urllib's `HTTPRedirectHandler.redirect_request`
copies normal headers to the redirect target, whatever its host. The spreadsheet id was also spliced into the URL
path unvalidated (`/`, `?`, `#`, `..` allowed), so `--spreadsheet-id` could aim the token at another Sheets/Google API
path. The host is a constant, so this is not SSRF.

**L2 (EQ-C-0001). The release zip would ship credential files (scripts/build_release.py).** Before the fix, the
exclusions covered outputs/, caches, venvs, checkpoints and team/local.team, but nothing credential-shaped. A
`.env`, `sheets.token`, `token.json`, `client_secret*.json`, `*.pem`/`*.key`, a Keychain export (`*.keychain-db`) or
`.claude/settings.local.json` placed anywhere in the folder would be zipped and listed in the manifest. None exists
in the tree today (checked with `find -maxdepth 3`). Symlinks are already skipped, and entry names come from
`os.walk` relative paths, so neither zip-slip nor symlink following is possible.

**L3 (EQ-C-0001). pip-audit findings could be read as "offline" and skipped (scripts/ci_local.sh, gate 6).** When
pip-audit exited non-zero, the gate grepped its log case-insensitively for `connection|resolve|...|SSL` and, on a
match, recorded `skip` instead of `FAIL`. A real report that names `pyopenssl` (or any text matching those words)
therefore passed the blocking gate. On a CI runner a network failure also skipped the gate silently.

**Reviewed, no finding (or info only):**
- EQ-C-0002 CLI: `resolve_token` order (token-file > --token > --write: env > Keychain) matches the design. Without
  `--write` the env var and Keychain are never read (tested). `security` is called with an argument list, a timeout
  and captured output; failures return None. The `--token` deprecation warning does not echo the value. The token
  file error message carries the path and strerror, not the content. GUI: the token travels in the JSON body, and
  `TOKEN_ENV` is popped from the inherited environment before it is set for writer jobs only. argv, the job's
  `argv` string and every log line are redacted. Non-writer jobs never get the token.
  Info: (a) a writer child inherits the token in its environment, and so does any subprocess it spawns. Same user
  only; acceptable. (b) `shutil.which("security")` trusts PATH; `/usr/bin/security` would be stricter (same-user
  attacker only). (c) `secrets` from the request body were not coerced to str, so a non-str entry raised a
  TypeError in `_redact`. Coerced in the same edit as M1.
- EQ-C-0007 escaping: every plan path goes through `_block`/`safe_cell`, `save_plan` or `apply_plan` (`sanitize_plan`),
  and record_plan is covered. Non-str values pass through unchanged: numbers cannot be formulas, numpy `str_`
  subclasses `str`, and bytes or other objects fail `json.dumps`. On leading whitespace and full-width `＝`: Google
  Sheets is not known to evaluate either, but a quote costs only an apostrophe that Sheets strips, and a third-party
  client that applies a saved plan, or that trims input, might evaluate them. Hardened as defence in depth: quote
  when the first non-blank character is `= + - @` or the full-width forms U+FF1D/FF0B/FF0D/FF20.
  Info: numeric-looking text that starts with a sign (for example "-1.2%") is now stored as text, not a number. No
  current plan writer emits such strings (grep of the publishers).
- EQ-C-0010: a pure move. `common_format` imports nothing from presentation or ingestion (test enforces it), and
  the re-export keeps old imports working.
- EQ-C-0008: `data_hash` now covers cds_quotes, dsa_inputs, panel/*.csv and live/*.csv|json, and excludes vintages and
  engine-written files. Hashing is read-only, and globs are one level deep. Info: hashes are truncated to 64 bits and
  `code_hash` feeds path+bytes without a length prefix. Both are fine against accidental change on a one-desk tool,
  but they are not collision-resistant against a deliberate forger.
- EQ-C-0001 ci_local.sh: all expansions are quoted, there is no `eval`, and `have()` interpolates only literal module
  names. Info: on macOS's stock bash 3.2, `"${target[@]}"` with an empty array under `set -u` raises "unbound
  variable". It is reachable only when scripts/requirements-lock.txt is absent. make_lock.py: offline and
  read-only, with no finding. The lock pins versions only, so a hash-pinned lock is still needed for the release
  (already noted in the README).

## Exploit scenario
This is a local desktop tool. The GUI binds to 127.0.0.1 and requires the session token and same-origin (see
tests/test_gui_security.py).
- M1: anyone or anything that can call `/api/job` with the session token, such as a bug or a compromised page in
  the GUI itself, could start a live workbook write using the Keychain token without the user pasting one. They
  could also make the CLI read an arbitrary local file and send its contents as a bearer token to
  sheets.googleapis.com. This is a real bypass of an explicit control, but it needs an authenticated local GUI
  session: Medium, not High.
- L1: a redirect from sheets.googleapis.com (not expected) would hand the OAuth token to the redirect host. A
  mistyped or crafted `--spreadsheet-id` could direct writes at a different API path on the same host.
- L2: Sam drops a token file or `.env` into ~/econquest, builds the release and shares the zip. The token leaks
  with the release, and its SHA is pinned in the manifest.
- L3: a vulnerable dependency (for example pyOpenSSL) passes the security gate unnoticed.

## Fix
- M1: `gui.py` `Jobs.start` drops any argument whose flag part (before `=`) is a prefix of `--write` or
  `--token-file` and longer than `--`. It also consumes the value of a bare `--token-file` prefix, and coerces
  `secrets` to str. Test: `tests/test_token_handling.py::test_gui_job_strips_argparse_abbreviations_of_write_and_token_file`
  (parametrised `--wr`, `--writ`, `--token-f PATH`, `--token-fi=PATH`, `--w`). It parses the child's argv with the
  real CLI parser and asserts `write=False, token_file=None, token=None`.
  Alternative, not done: `allow_abbrev=False` on the writer subparsers would change CLI ergonomics for every user.
- L1: `sheets_publish.apply_plan` sets Authorization via `add_unredirected_header`. It validates the id against
  `[A-Za-z0-9_-]{1,128}` (`SHEET_ID_RE`), and the URL is built from the `SHEETS_API` constant with `# nosec B310` (see
  SEC-C-002). Tests: `test_apply_plan_token_not_forwarded_on_redirect`, `test_apply_plan_rejects_unsafe_spreadsheet_id`.
- EQ-C-0007 hardening: `common_format.escape_formula` also quotes text whose first non-blank character is a formula
  prefix or its full-width form. Test: `test_leading_blank_and_fullwidth_prefixes_are_quoted`.
- L2: `build_release.py` adds `SECRET_GLOBS`, matched case-insensitively against each file name, and excludes
  `.claude/settings.local.json`. Test: `tests/test_release.py::test_credentials_are_never_packed`, which checks 12 cases
  and also asserts that `test_token_handling.py` still ships.
  Recommended for AGENT-10: run `gitleaks detect --no-git --source <unzipped release>` as the last release step.
- L3: `ci_local.sh` treats a log that says "known vulnerabilit..." as a failure, never as offline. When `CI` or
  `GITHUB_ACTIONS` is set, an unreachable service fails the gate. Tests:
  `tests/test_release.py::test_ci_local_vulnerability_report_is_not_mistaken_for_offline`,
  `test_ci_local_offline_skips_locally_but_fails_on_ci`.

## Verification
```
python -m pytest -q -p no:cacheprovider tests/test_token_handling.py tests/test_sheets_publish.py \
    tests/test_gui_security.py tests/test_release.py tests/test_versioning.py
bandit -q -r econquest -ll      # sheets_publish.py:253 B310 no longer reported
```
Results are recorded in the Team C log (sec_pass entries for EQ-C-0002, EQ-C-0007, EQ-C-0010, EQ-C-0001, EQ-C-0008).
