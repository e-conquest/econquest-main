---
id: SEC-A-001
ticket: EQ-A-0006
author: A/AGENT-09
created: 2026-10-23
severity: medium   # critical | high | medium | low | info
status: fixed          # open | fixed | accepted-risk (needs EXC- id) | false-positive
cwe: CWE-613 (stale authorisation), CWE-778 (insufficient logging)
---
# Review ledger: stale approvals clear new holds; --force bypasses four-eyes with no ledger record

## Finding
Found by manual review of the EQ-A-0005 / EQ-A-0006 diffs plus a probe script (scratchpad, not committed).

**M1. A four-eyes approval never expires (econquest/ingestion/ledger.py:144-163, used by feeds.py:704-707).**
`effective_holds` keys decisions on (table, key, country) only. `record_decision` stores `vintage_id` and `live`,
but `effective_holds` ignores them. Once a held cell has been approved (decision apply, approver different from
author), every later gate hold on that cell is cleared automatically. That includes a hold on a different vintage
and on a completely different live value. Probe: approve `Inputs/1.3/X` at live=5.0 in vintage v1. A later review
row holds the same cell at live=500.0, and `effective_holds` returns `set()`, so `apply_report` writes 500.0
without review.

**M2. `force=True` overrides every hold, including four-eyes and explicit reject decisions, and leaves no durable
record (feeds.py:712-714, 726-727, 738-739, 744-747; cli.py:461).**
`--force` empties `held` and needs no author or approver. The forced cells are returned only in
`ApplyResult.meta["forced_cells"]`, which the CLI prints to stdout. Nothing is appended to review_ledger.csv or
to the snapshot folder. `ApplyResult` also hides `forced_cells` from `items()`, `dict(r)`, `json.dumps(r)` and
`r.copy()` (probe: `json.dumps(r) == '{"indicator_cells": 1}'`). Any caller that logs the result as JSON
therefore loses the only trace of the override.

## Exploit scenario
Local desktop tool, one desk. No remote attacker is involved, so this is about the integrity of the numbers.
- M1: an analyst approves a borderline WEO revision once. A later bad pull, for example a unit or scaling error
  in the vendor feed, is held by the gate, and the hold is then cleared by the old approval. The value reaches
  indicators.csv and the Risk Desk sheet with no second reviewer. The ledger shows an approval for a value that
  was never approved.
- M2: one person can run `econquest fetch --apply --force` and push cells that a colleague rejected. No author
  is recorded, and nothing survives except the terminal scrollback. Both the four-eyes rule (roadmap 4.4) and
  the "a silent overwrite is a finding" rule are defeated.

## Fix
- M1: bind an approval to what was approved. In `effective_holds`, accept an `apply` decision for a gate-held
  cell only when its `vintage_id` matches the review's vintage, or when its `live` equals the review's `live`
  within a tolerance such as 1e-9 relative. Either way, carry `vintage_id`/`live` through `load_decisions` and
  `decisions_from_review`. hold/reject decisions can stay sticky, because that is the safe direction.
  Regression test: approve at live=5.0, then review with status hold at live=500.0. The cell must stay held.
- M2: make `force` take `author` and `approver` (distinct after normalisation, same rule as `record_decision`),
  and append one ledger row per forced cell (decision `apply`, note `forced`). Also write
  `forced_cells.csv` next to the pre-apply snapshot. Add `--author/--approver` to `fetch --force` in cli.py
  (Team C, through a handoff). Replace `ApplyResult(dict)` with a dataclass, or a plain dict that contains all
  keys, so that serialisation cannot drop `snapshot`/`forced_cells`. Regression test: `apply_report(...,
  force=True, author="a", approver="b")` appends N ledger rows. `force=True` without an approver raises.

## Verification
`python -m pytest -q tests/test_ledger.py tests/test_vintages.py` must include the two regression tests above
and pass. Then re-run the probe: the stale approval must give `{('Inputs','1.3','X')}`.


## Re-verification 2026-10-23 (A/AGENT-09)
Status proposed: **fixed** (M1, M2). Residual Lows below; none blocks merge.

Evidence: `python -m pytest -q tests/test_ledger.py tests/test_vintages.py tests/test_feeds.py tests/test_record.py tests/test_replay.py -p no:cacheprovider` gives 32 passed. Probes (scratchpad r2/probe6.py, r2/probe7.py, not committed):
- M1: approve at live=5.0 in v1, review hold at live=500.0 gives `{('Inputs','1.3','X')}` (held). **Fixed.**
- M2: `apply_report(force=True)` with no author, author only, approver `sam​` or ` SAM ` is refused before any write. `self_approved=True` writes a ledger row (decision apply, note forced, self_approved yes, live) and a 0444 forced_cells.csv in the pre-apply snapshot. The result is a plain dict, so `json.dumps` keeps `snapshot`/`forced_cells`. **Fixed.**
- Approver normalisation: zero-width, fullwidth, case and surrounding whitespace are all refused as same-person. A flagged self-approval needs `self_approved=True`. Writing apply with approver=author and gate_status '' (gate_status set wrongly) still leaves the cell held.
- Stale approval with the same live value in a different vintage is released. **Accepted**: the approver signed off on that exact number, and the gate re-checks it.

Residual (Low):
- L1 feeds.py:725-726, 771-776: `vintage_id` is used for approval binding before it is validated. `freeze_inputs` resolves it only after `_atomic_csv` has written. Probe: approval {vintage v-old, live 1.0}, review hold at live 36.5, `apply_report(vintage_id="v-old")` releases the hold, writes indicators.csv, then raises FileNotFoundError. Fix: resolve `vintage_path(d, vintage_id)` at the top of apply_report, before effective_holds. In `_bound` (ledger.py:250-258), when the decision has a live value, require the live value to match; use vintage only when decision.live is empty.
- L2 ledger.py:60-66: names are self-asserted, so `'alice`, `a lice` or Cyrillic `аlice` all count as a different approver from `alice`. Four-eyes is honour-based without authentication. Optional fix: collapse inner whitespace, strip every leading apostrophe, and add a confusables skeleton.
- L3 ledger.py:120-146, 140: a single-author `apply` (no approver) on a gate-ok cell supersedes a colleague's `reject`/`hold`, because effective_holds only looks at the latest row. Fix: an apply that follows a hold/reject by someone else needs check_approval.
- L4 ledger.py:69-71: `_neutralise` covers author/approver/note only. It misses leading TAB/CR (note `\t=HYPERLINK(...)` is stored raw) and the vintage_id/table/key/country columns (vintage_id `=1+1` is stored raw). Fix: neutralise every text column and add `\t` `\r` to the prefix set.
- L5 governance: Sam's single-operator self-approval has no `EXC-` entry in docs/governance/issues-log.md. AGENT-08 should log it.

Follow-up (AGENT-08, 2026-10-23): L1 fixed in EQ-A-0006 (apply_report resolves vintage_path before matching; a decision naming a live value binds to that value). L2-L4 and R1-R4 tracked in EQ-A-0011; L3 also HO-20261023-C-A-004. L5 EXC- entry requested from Team B (HO-20261023-A-B-005).

## Fix of residual Lows, EQ-A-0011 (A/AGENT-03, 2026-10-23)
- L2 fixed: `clean_person` collapses inner whitespace; `person_key` strips every leading apostrophe, removes all whitespace and maps a small Cyrillic/Greek homoglyph set to Latin. `'alice`, `a lice`, `аlice` (Cyrillic) now equal `alice`. Still self-asserted names (no authentication). Note: `person_key` is also used by ops/approvals.py and presentation/editorial.py; the change only makes their four-eyes checks stricter.
- L3 fixed (also HO-20261023-C-A-004): an `apply` that follows a standing hold/reject by another person needs `_approved` (distinct approver or flagged self-approval), gate ok or not. `record_decision` refuses it; `load_decisions` adds `objection_by` and `effective_holds` keeps the cell held if such a row reaches the ledger by hand (also when given the full ledger).
- L4 fixed: every text column (vintage_id, table, key, country, gate_status, decision, author, approver, note, self_approved, and non-numeric `live`) is neutralised; TAB and CR added to the prefixes; plain numbers such as `-1.5` are left alone. `read_ledger` drops the guard apostrophe from identifier columns so matching still works.
- R1 fixed: snapshot names from index.csv must be a plain folder name whose resolved parent is the snapshots root (symlink out refused); the manifest's vintage_id must equal the requested vintage. R2: out_dir inside data_dir refused. R3: materialize builds in a temp sibling and renames into place. R4: index.csv append under `ledger.locked_append`.
- Regression tests: tests/test_ledger_security.py (28). Verification: `python -m pytest -q tests/test_ledger_security.py tests/test_ledger.py tests/test_replay.py`.
