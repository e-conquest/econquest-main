"""teamctl: board, handoffs, activity log, ownership and codebase catalog for the econquest agent team.

Standard library only, so it runs in any account before the package is installed.
Run from the folder that holds team/ and econquest/:

    python team/teamctl.py status --team A
    python team/teamctl.py ticket new --team A --summary "..." --agent AGENT-06 --points 3
    python team/teamctl.py handoff new --from A/AGENT-06 --to B/AGENT-05 --ticket EQ-A-0001 --title "..."
    python team/teamctl.py check --changed econquest/engine/garch.py --team A

The team defaults to $ECONQUEST_TEAM, then the first line of team/local.team.
See team/operating-model.md and team/handoff-protocol.md for the rules this enforces.
"""
from __future__ import annotations

import argparse
import ast
import csv
import datetime as dt
import fnmatch
import json
import os
import re
import subprocess
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
TEAM_DIR = ROOT / "team"
TEAMS = ("A", "B", "C")
AGENTS = tuple(f"AGENT-{i:02d}" for i in range(1, 12))
STATUSES = ("Backlog", "Ready", "In Progress", "In Review", "Blocked", "Done")
TYPES = ("Story", "Bug", "Task", "Spike", "Epic")
PRIORITIES = ("Highest", "High", "Medium", "Low")
POINTS = ("", "1", "2", "3", "5", "8", "13")
HO_TYPES = ("work", "review", "question", "contract-change", "defect", "release", "info")
HO_PRIORITIES = ("low", "normal", "high", "blocker")
HO_STATUSES = ("open", "accepted", "done", "rejected")
HO_FIELDS = ("id", "from", "to", "ticket", "type", "priority", "status", "created", "due", "branch", "accepted_by")
DOC_KINDS = {"rca": ("RCA", "rca", "rca.md"), "adr": ("ADR", "adr", "adr.md"),
             "sec": ("SEC", "security", "security.md"), "perf": ("PERF", "perf", "perf.md")}
BOARD_FIELDS = ("key", "summary", "type", "status", "priority", "points", "agent", "epic", "labels",
                "sprint", "gov", "created", "updated", "description")
LOG_ACTIONS = ("started", "progress", "blocked", "unblocked", "handoff_sent", "handoff_accepted",
               "handoff_done", "review_pass", "review_changes", "sec_pass", "sec_finding", "perf_pass",
               "perf_regression", "rca_done", "adr_proposed", "adr_accepted", "merged", "released", "done")
TICKET_RE = re.compile(r"^EQ-[ABC]-\d{4}$")
HO_RE = re.compile(r"^HO-\d{8}-[ABC]-[ABC]-\d{3}$")
PARTY_RE = re.compile(r"^([ABC])/(AGENT-(0[1-9]|1[01]))$")


def today() -> str:
    return dt.date.today().isoformat()


def now() -> str:
    return dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def default_team() -> str | None:
    team = os.environ.get("ECONQUEST_TEAM")
    local = TEAM_DIR / "local.team"
    if not team and local.exists():
        team = local.read_text().strip().splitlines()[0] if local.read_text().strip() else None
    return team.upper() if team else None


def need_team(value: str | None) -> str:
    team = (value or default_team() or "").upper()
    if team not in TEAMS:
        sys.exit("team required: pass --team A|B|C, set ECONQUEST_TEAM, or write the letter to team/local.team")
    return team


# ---------- board ----------

def board_path(team: str) -> Path:
    return TEAM_DIR / "board" / f"{team}.csv"


def read_board(team: str) -> list[dict]:
    path = board_path(team)
    if not path.exists():
        return []
    with path.open(newline="") as f:
        return list(csv.DictReader(f))


def write_board(team: str, rows: list[dict]) -> None:
    path = board_path(team)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=BOARD_FIELDS)
        w.writeheader()
        for r in rows:
            w.writerow({k: r.get(k, "") for k in BOARD_FIELDS})


def all_tickets() -> dict[str, dict]:
    return {r["key"]: r for t in TEAMS for r in read_board(t)}


def next_seq(existing: list[str], prefix: str, width: int) -> str:
    nums = [int(k[len(prefix):]) for k in existing if k.startswith(prefix) and k[len(prefix):].isdigit()]
    return f"{prefix}{(max(nums) + 1 if nums else 1):0{width}d}"


def cmd_ticket(a) -> None:
    team = need_team(a.team)
    rows = read_board(team)
    if a.action == "new":
        key = next_seq([r["key"] for r in rows], f"EQ-{team}-", 4)
        row = {"key": key, "summary": a.summary, "type": a.type, "status": "Backlog", "priority": a.priority,
               "points": a.points or "", "agent": a.agent or "", "epic": a.epic or "", "labels": a.labels or "",
               "sprint": a.sprint or "", "gov": a.gov or "", "created": today(), "updated": today(),
               "description": a.description or ""}
        rows.append(row)
        write_board(team, rows)
        print(key)
    elif a.action == "move":
        for r in rows:
            if r["key"] == a.key:
                if a.status == "Ready" and (not r["points"] or not r["agent"]):
                    sys.exit(f"{a.key} not Ready: needs points and agent (Definition of Ready)")
                r["status"], r["updated"] = a.status, today()
                if a.agent:
                    r["agent"] = a.agent
                write_board(team, rows)
                print(f"{a.key} -> {a.status}")
                return
        sys.exit(f"{a.key} not on board {team}")
    else:
        for r in rows:
            if a.status and r["status"] != a.status:
                continue
            print(f"{r['key']}  {r['status']:<11} {r['points']:>2}  {r['agent']:<8}  {r['summary']}")


# ---------- handoffs ----------

def ho_dir() -> Path:
    return TEAM_DIR / "handoffs"


def parse_front(text: str) -> tuple[dict, str]:
    if not text.startswith("---\n"):
        return {}, text
    end = text.find("\n---", 4)
    if end < 0:
        return {}, text
    meta = {}
    for line in text[4:end].splitlines():
        if ":" in line and not line.lstrip().startswith("#"):
            k, v = line.split(":", 1)
            meta[k.strip()] = v.split("#", 1)[0].strip()
    return meta, text[end + 4:].lstrip("\n")


def render_front(meta: dict, body: str, fields) -> str:
    keys = list(fields) + [k for k in meta if k not in fields]
    head = "\n".join(f"{k}: {meta.get(k, '')}".rstrip() for k in keys)
    return f"---\n{head}\n---\n{body}"


def load_handoffs() -> list[tuple[Path, dict, str]]:
    out = []
    for p in sorted(ho_dir().glob("HO-*.md")):
        meta, body = parse_front(p.read_text())
        out.append((p, meta, body))
    return out


def response_text(body: str) -> str:
    m = re.search(r"^## Response\s*\n(.*)", body, re.S | re.M)
    return m.group(1).strip() if m else ""


def cmd_handoff(a) -> None:
    if a.action == "new":
        m_from, m_to = PARTY_RE.match(a.from_ or ""), PARTY_RE.match(a.to or "")
        if not (m_from and m_to):
            sys.exit("--from and --to must look like A/AGENT-06")
        stamp = dt.date.today().strftime("%Y%m%d")
        prefix = f"HO-{stamp}-{m_from.group(1)}-{m_to.group(1)}-"
        hid = next_seq([p.stem for p, _, _ in load_handoffs()], prefix, 3)
        due = a.due or (dt.date.today() + dt.timedelta(days=3)).isoformat()
        tpl = (TEAM_DIR / "templates" / "handoff.md").read_text()
        text = tpl.format(id=hid, from_=a.from_, to=a.to, ticket=a.ticket, type=a.type, priority=a.priority,
                          created=today(), due=due, branch=a.branch or "", title=a.title)
        ho_dir().mkdir(parents=True, exist_ok=True)
        (ho_dir() / f"{hid}.md").write_text(text)
        append_log(m_from.group(1), m_from.group(2), a.ticket, "handoff_sent", f"{hid} to {a.to}: {a.title}",
                   [f"team/handoffs/{hid}.md"])
        print(f"team/handoffs/{hid}.md")
    elif a.action in ("accept", "done", "reject"):
        path = ho_dir() / f"{a.id}.md"
        if not path.exists():
            sys.exit(f"{a.id} not found")
        meta, body = parse_front(path.read_text())
        to_team, to_agent = meta["to"].split("/")
        if a.action == "accept":
            meta["status"], meta["accepted_by"] = "accepted", a.by or meta["to"]
            action = "handoff_accepted"
        else:
            if a.response:
                body = re.sub(r"(^## Response\s*\n).*", lambda m: m.group(1) + a.response.strip() + "\n",
                              body, flags=re.S | re.M)
            if not response_text(body):
                sys.exit("write a Response (pass --response) before closing a handoff")
            meta["status"] = "done" if a.action == "done" else "rejected"
            action = "handoff_done"
        path.write_text(render_front(meta, body, HO_FIELDS))
        append_log(to_team, (a.by or meta["to"]).split("/")[-1], meta.get("ticket", ""), action, a.id,
                   [f"team/handoffs/{a.id}.md"])
        print(f"{a.id} -> {meta['status']}")
    else:
        for p, meta, _ in load_handoffs():
            if a.to and not meta.get("to", "").startswith(a.to.upper()):
                continue
            if a.from_ and not meta.get("from", "").startswith(a.from_.upper()):
                continue
            if a.status and meta.get("status") != a.status:
                continue
            late = " LATE" if meta.get("status") in ("open", "accepted") and meta.get("due", "9") < today() else ""
            print(f"{p.stem}  {meta.get('status', ''):<8} {meta.get('priority', ''):<7} "
                  f"{meta.get('from', '')} -> {meta.get('to', '')}  {meta.get('ticket', '')}  due {meta.get('due', '')}{late}")


# ---------- docs ----------

def cmd_doc(a) -> None:
    team = need_team(a.team)
    prefix, folder, tpl = DOC_KINDS[a.kind]
    d = TEAM_DIR / folder
    d.mkdir(parents=True, exist_ok=True)
    did = next_seq([p.stem for p in d.glob(f"{prefix}-{team}-*.md")], f"{prefix}-{team}-", 3)
    text = (TEAM_DIR / "templates" / tpl).read_text().format(
        id=did, ticket=a.ticket, author=f"{team}/{a.agent}", created=today(), severity=a.severity, title=a.title)
    (d / f"{did}.md").write_text(text)
    print(f"team/{folder}/{did}.md")


# ---------- log ----------

def append_log(team: str, agent: str, ticket: str, action: str, msg: str, refs=None) -> dict:
    rec = {"ts": now(), "team": team, "agent": agent, "ticket": ticket or "", "action": action, "msg": msg,
           "refs": list(refs or [])}
    path = TEAM_DIR / "logs" / f"{team}.jsonl"
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("a") as f:
        f.write(json.dumps(rec) + "\n")
    return rec


def read_log(team: str) -> list[dict]:
    path = TEAM_DIR / "logs" / f"{team}.jsonl"
    if not path.exists():
        return []
    return [json.loads(line) for line in path.read_text().splitlines() if line.strip()]


def cmd_log(a) -> None:
    team = need_team(a.team)
    if a.action not in LOG_ACTIONS:
        sys.exit(f"unknown action {a.action}; one of: {', '.join(LOG_ACTIONS)}")
    append_log(team, a.agent, a.ticket, a.action, a.msg, a.ref)


def cmd_tail(a) -> None:
    team = need_team(a.team)
    for r in read_log(team)[-a.n:]:
        print(f"{r['ts']}  {r['agent']}  {r['ticket']:<10} {r['action']:<16} {r['msg']}")


# ---------- ownership ----------

def load_ownership() -> list[dict]:
    with (TEAM_DIR / "ownership.csv").open(newline="") as f:
        return list(csv.DictReader(f))


def owner_of(path: str, rules: list[dict] | None = None) -> dict | None:
    rules = rules if rules is not None else load_ownership()
    path = path.replace("\\", "/").removeprefix("./")
    hits = [r for r in rules if fnmatch.fnmatch(path, r["pattern"])]
    return max(hits, key=lambda r: len(r["pattern"].rstrip("*"))) if hits else None


def cmd_owner(a) -> None:
    for p in a.paths:
        r = owner_of(p)
        print(f"{p}: " + (f"team {r['team']} ({r['lead_agent']}) {r['notes']}".rstrip() if r else "UNOWNED"))


# ---------- check ----------

def changed_from_git(base: str) -> list[str]:
    out = subprocess.run(["git", "diff", "--name-only", f"{base}...HEAD"], cwd=ROOT, capture_output=True, text=True)
    if out.returncode:
        sys.exit(out.stderr.strip() or "git diff failed")
    return [l for l in out.stdout.splitlines() if l]


# ---------- checkpoints (rollback without git) ----------

def cp_dir(ticket: str) -> Path:
    return TEAM_DIR / "checkpoints" / ticket


def read_manifest(ticket: str) -> dict:
    m = cp_dir(ticket) / "manifest.json"
    return json.loads(m.read_text()) if m.exists() else {}


def rel_path(p: str) -> str:
    path = Path(p)
    path = path.resolve().relative_to(ROOT) if path.is_absolute() else path
    return path.as_posix().removeprefix("./")


def cmd_checkpoint(a) -> None:
    if not TICKET_RE.match(a.ticket):
        sys.exit("--ticket must look like EQ-A-0001")
    manifest = read_manifest(a.ticket)
    rules = load_ownership()
    team = a.ticket.split("-")[1]
    # Ownership of every path is checked before anything is saved (SEC-C-008, EQ-C-0066): a refusal used to exit
    # after earlier files were copied but before the manifest was written, so a rerun copied them again and replaced
    # the saved originals with already-edited files.
    rels = [rel_path(p) for p in a.paths]
    for rel in rels:
        r = owner_of(rel, rules)
        if r is None or r["team"] not in (team, "ALL"):
            sys.exit(f"{rel}: owned by team {r['team'] if r else 'nobody'}; send a handoff instead of editing "
                     f"(nothing was checkpointed)")
    for rel in rels:
        if rel in manifest:
            continue  # first checkpoint wins: it is the state before the ticket touched the file
        src = ROOT / rel
        dst = cp_dir(a.ticket) / "files" / rel
        if dst.exists():
            manifest[rel] = "existing"  # a copy saved by an earlier run whose manifest was never written: keep it
        elif src.exists():
            dst.parent.mkdir(parents=True, exist_ok=True)
            dst.write_bytes(src.read_bytes())
            manifest[rel] = "existing"
        else:
            manifest[rel] = "new"
        print(f"checkpoint {rel} ({manifest[rel]})")
    cp_dir(a.ticket).mkdir(parents=True, exist_ok=True)
    (cp_dir(a.ticket) / "manifest.json").write_text(json.dumps(manifest, indent=1, sort_keys=True) + "\n")


def cmd_revert(a) -> None:
    manifest = read_manifest(a.ticket)
    if not manifest:
        sys.exit(f"no checkpoint for {a.ticket}")
    targets = [rel_path(p) for p in a.paths] if a.paths else list(manifest)
    for rel in targets:
        state = manifest.get(rel)
        if state == "existing":
            (ROOT / rel).write_bytes((cp_dir(a.ticket) / "files" / rel).read_bytes())
        elif state == "new":
            (ROOT / rel).unlink(missing_ok=True)
        else:
            sys.exit(f"{rel} was not checkpointed under {a.ticket}")
        print(f"reverted {rel}")


def cmd_diff(a) -> None:
    import difflib
    for rel, state in read_manifest(a.ticket).items():
        before = (cp_dir(a.ticket) / "files" / rel).read_text(errors="ignore").splitlines(True) if state == "existing" else []
        cur = ROOT / rel
        after = cur.read_text(errors="ignore").splitlines(True) if cur.exists() else []
        sys.stdout.writelines(difflib.unified_diff(before, after, f"a/{rel}", f"b/{rel}"))


def run_checks(team: str | None, changed: list[str]) -> list[str]:
    problems: list[str] = []
    tickets = all_tickets()
    for t in TEAMS:
        for r in read_board(t):
            k = r.get("key", "")
            if not TICKET_RE.match(k) or not k.startswith(f"EQ-{t}-"):
                problems.append(f"board {t}: bad key {k!r}")
            if r.get("status") not in STATUSES:
                problems.append(f"{k}: bad status {r.get('status')!r}")
            if r.get("points", "") not in POINTS:
                problems.append(f"{k}: points must be one of 1,2,3,5,8,13")
            if r.get("agent") and r["agent"] not in AGENTS:
                problems.append(f"{k}: unknown agent {r['agent']!r}")
            if r.get("status") in ("Ready", "In Progress", "In Review", "Done") and not (r.get("points") and r.get("agent")):
                problems.append(f"{k}: {r['status']} without points and agent")
    for p, meta, body in load_handoffs():
        name = p.stem
        missing = [f for f in HO_FIELDS if f not in meta]
        if missing:
            problems.append(f"{name}: missing fields {missing}")
            continue
        if not HO_RE.match(meta["id"]) or meta["id"] != name:
            problems.append(f"{name}: id {meta['id']!r} does not match file name")
        for side in ("from", "to"):
            if not PARTY_RE.match(meta[side]):
                problems.append(f"{name}: bad {side} {meta[side]!r}")
        if meta["type"] not in HO_TYPES:
            problems.append(f"{name}: bad type {meta['type']!r}")
        if meta["priority"] not in HO_PRIORITIES:
            problems.append(f"{name}: bad priority {meta['priority']!r}")
        if meta["status"] not in HO_STATUSES:
            problems.append(f"{name}: bad status {meta['status']!r}")
        if meta["ticket"] and meta["ticket"] not in tickets:
            problems.append(f"{name}: ticket {meta['ticket']} not on any board")
        if meta["status"] in ("done", "rejected") and not response_text(body):
            problems.append(f"{name}: {meta['status']} with empty Response")
        if meta["status"] in ("accepted", "done") and not meta["accepted_by"]:
            problems.append(f"{name}: {meta['status']} without accepted_by")
    for t in TEAMS:
        for i, line in enumerate((TEAM_DIR / "logs" / f"{t}.jsonl").read_text().splitlines()
                                 if (TEAM_DIR / "logs" / f"{t}.jsonl").exists() else [], 1):
            try:
                rec = json.loads(line)
            except json.JSONDecodeError:
                problems.append(f"log {t}:{i}: not JSON")
                continue
            if rec.get("team") != t or rec.get("action") not in LOG_ACTIONS:
                problems.append(f"log {t}:{i}: wrong team or unknown action")
    if team and changed:
        rules = load_ownership()
        own_files = {f"team/board/{team}.csv", f"team/logs/{team}.jsonl"}
        for path in changed:
            if path in own_files:
                continue
            if path.startswith("team/board/") or path.startswith("team/logs/"):
                problems.append(f"{path}: team {team} may write only its own board and log")
                continue
            if path.startswith("team/handoffs/"):
                continue  # sender creates, receiver updates status; reviewed in the PR
            r = owner_of(path, rules)
            if r is None:
                problems.append(f"{path}: not in team/ownership.csv (add a row before changing it)")
            elif r["team"] not in (team, "ALL"):
                problems.append(f"{path}: owned by team {r['team']}; send a handoff instead of editing")
    return problems


def cmd_check(a) -> None:
    team = (a.team or default_team() or "").upper() or None
    changed = list(a.changed or [])
    if a.ticket:
        team = team or a.ticket.split("-")[1]
        changed += list(read_manifest(a.ticket))
    if a.git_base:
        changed += changed_from_git(a.git_base)
    problems = run_checks(team, changed)
    for p in problems:
        print(f"FAIL {p}")
    print(f"{len(problems)} problem(s)")
    sys.exit(1 if problems else 0)


# ---------- status ----------

def cmd_status(a) -> None:
    team = need_team(a.team)
    rows = read_board(team)
    print(f"Team {team} board")
    for s in STATUSES:
        sel = [r for r in rows if r["status"] == s]
        pts = sum(int(r["points"]) for r in sel if r["points"].isdigit())
        print(f"  {s:<11} {len(sel):>3} tickets  {pts:>3} pts")
    blocked = [r for r in rows if r["status"] == "Blocked"]
    for r in blocked:
        print(f"  BLOCKED {r['key']} {r['agent']} {r['summary']}")
    inbound = [m for _, m, _ in load_handoffs() if m.get("to", "").startswith(team) and m.get("status") in ("open", "accepted")]
    outbound = [m for _, m, _ in load_handoffs() if m.get("from", "").startswith(team) and m.get("status") in ("open", "accepted")]
    print(f"Handoffs in: {len(inbound)} open/accepted  out: {len(outbound)} awaiting")
    for m in inbound:
        late = " LATE" if m.get("due", "9") < today() else ""
        print(f"  <- {m['id']} {m['status']} {m['priority']} from {m['from']} due {m['due']}{late}")
    print("Last activity")
    for r in read_log(team)[-5:]:
        print(f"  {r['ts']} {r['agent']} {r['action']} {r['msg']}")


# ---------- catalog ----------

def module_name(path: Path) -> str:
    rel = path.relative_to(ROOT).with_suffix("")
    parts = list(rel.parts)
    if parts[-1] == "__init__":
        parts = parts[:-1]
    return ".".join(parts)


def resolve_import(mod: str, node: ast.ImportFrom, is_pkg: bool) -> str:
    if node.level == 0:
        return node.module or ""
    base = mod.split(".")
    base = base[: len(base) - node.level + (1 if is_pkg else 0)]
    return ".".join(base + ([node.module] if node.module else []))


def build_catalog() -> list[dict]:
    rules = load_ownership()
    tests = {p.name: p.read_text(errors="ignore") for p in (ROOT / "tests").glob("test_*.py")}
    rows = []
    for path in sorted((ROOT / "econquest").rglob("*.py")):
        if "__pycache__" in path.parts:
            continue
        src = path.read_text(errors="ignore")
        tree = ast.parse(src)
        mod = module_name(path)
        is_pkg = path.name == "__init__.py"
        funcs = [n.name for n in tree.body if isinstance(n, (ast.FunctionDef, ast.AsyncFunctionDef))]
        classes = [n.name for n in tree.body if isinstance(n, ast.ClassDef)]
        imports = set()
        for n in ast.walk(tree):
            if isinstance(n, ast.ImportFrom):
                target = resolve_import(mod, n, is_pkg)
                if target.startswith("econquest"):
                    imports.add(target)
            elif isinstance(n, ast.Import):
                imports.update(a.name for a in n.names if a.name.startswith("econquest"))
        short = mod.split(".")[-1]
        names = [short] + [f for f in funcs if not f.startswith("_")] + classes
        covering = sorted(t for t, body in tests.items() if mod in body or any(
            re.search(rf"\b{re.escape(n)}\b", body) for n in names))
        rel = str(path.relative_to(ROOT))
        r = owner_of(rel, rules)
        rows.append({"module": mod, "path": rel, "team": r["team"] if r else "?", "lines": src.count("\n") + 1,
                     "public_functions": [f for f in funcs if not f.startswith("_")],
                     "private_functions": len([f for f in funcs if f.startswith("_")]),
                     "classes": classes, "imports": sorted(imports), "tests": covering,
                     "doc": (ast.get_docstring(tree) or "").strip().splitlines()[0] if ast.get_docstring(tree) else ""})
    return rows


def package_of(mod: str) -> str:
    parts = mod.split(".")
    return ".".join(parts[:2]) if len(parts) > 1 else parts[0]


def cmd_catalog(a) -> None:
    rows = build_catalog()
    out_dir = TEAM_DIR / "catalog"
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "modules.json").write_text(json.dumps(rows, indent=1) + "\n")
    by_mod = {r["module"]: r for r in rows}
    lines = ["# Codebase catalog", "", f"Generated {today()} by `python team/teamctl.py catalog` (AGENT-02). "
             "Do not hand-edit; regenerate.", "",
             "| Module | Team | Lines | Public functions | Classes | Tests |", "|---|---|---|---|---|---|"]
    for r in rows:
        pub = ", ".join(r["public_functions"][:8]) + (" ..." if len(r["public_functions"]) > 8 else "")
        lines.append(f"| `{r['module']}` | {r['team']} | {r['lines']} | {pub} | {', '.join(r['classes'])} | "
                     f"{', '.join(r['tests']) or '**none**'} |")
    cross = []
    for r in rows:
        for imp in r["imports"]:
            tgt = by_mod.get(imp) or next((by_mod[m] for m in by_mod if imp.startswith(m + ".")), None)
            if tgt and tgt["team"] not in (r["team"], "ALL") and package_of(imp) != package_of(r["module"]):
                cross.append((r["team"], r["module"], tgt["team"], imp))
    lines += ["", "## Cross-team imports (each must map to a contract in `team/contracts.md`)", "",
              "| From team | Module | Imports from team | Target |", "|---|---|---|---|"]
    lines += [f"| {a_} | `{m}` | {b} | `{t}` |" for a_, m, b, t in sorted(set(cross))]
    untested = [r["module"] for r in rows if not r["tests"] and r["lines"] > 30]
    lines += ["", "## Modules over 30 lines with no test file referencing them", ""]
    lines += [f"- `{m}`" for m in untested] or ["- none"]
    (out_dir / "modules.md").write_text("\n".join(lines) + "\n")
    print(f"team/catalog/modules.md ({len(rows)} modules, {len(set(cross))} cross-team imports, {len(untested)} untested)")


# ---------- jira ----------

JIRA_STATUS = {"Backlog": "To Do", "Ready": "To Do", "In Progress": "In Progress", "In Review": "In Review",
               "Blocked": "In Progress", "Done": "Done"}


def cmd_jira(a) -> None:
    out = Path(a.out) if a.out else TEAM_DIR / "board" / "jira-import.csv"
    teams = [need_team(a.team)] if a.team else list(TEAMS)
    cols = ["Issue Id", "Summary", "Issue Type", "Status", "Priority", "Story Points", "Assignee", "Epic Link",
            "Labels", "Sprint", "Description", "Created"]
    with out.open("w", newline="") as f:
        w = csv.writer(f)
        w.writerow(cols)
        for t in teams:
            for r in read_board(t):
                labels = " ".join(x for x in [f"team-{t}", r["agent"].lower(), *r["labels"].split(),
                                              r["gov"].lower()] if x)
                desc = r["description"] + (f"\n\nModel issue: {r['gov']}" if r["gov"] else "")
                w.writerow([r["key"], r["summary"], r["type"], JIRA_STATUS[r["status"]], r["priority"], r["points"],
                            "", r["epic"], labels, r["sprint"], desc, r["created"]])
    print(f"{out.relative_to(ROOT) if out.is_relative_to(ROOT) else out}")


# ---------- main ----------

def main(argv=None) -> None:
    p = argparse.ArgumentParser(prog="teamctl", description=__doc__.splitlines()[0])
    sub = p.add_subparsers(dest="cmd", required=True)

    t = sub.add_parser("ticket", help="create, move or list tickets")
    t.add_argument("action", choices=("new", "move", "list"))
    t.add_argument("key", nargs="?")
    t.add_argument("--team")
    t.add_argument("--summary")
    t.add_argument("--type", default="Story", choices=TYPES)
    t.add_argument("--priority", default="Medium", choices=PRIORITIES)
    t.add_argument("--points", choices=POINTS[1:])
    t.add_argument("--agent", choices=AGENTS)
    t.add_argument("--epic")
    t.add_argument("--labels")
    t.add_argument("--sprint")
    t.add_argument("--gov")
    t.add_argument("--description")
    t.add_argument("--status", choices=STATUSES)
    t.set_defaults(fn=cmd_ticket)

    h = sub.add_parser("handoff", help="create, accept, close or list handoffs")
    h.add_argument("action", choices=("new", "accept", "done", "reject", "list"))
    h.add_argument("id", nargs="?")
    h.add_argument("--from", dest="from_")
    h.add_argument("--to")
    h.add_argument("--ticket", default="")
    h.add_argument("--type", default="work", choices=HO_TYPES)
    h.add_argument("--priority", default="normal", choices=HO_PRIORITIES)
    h.add_argument("--title", default="")
    h.add_argument("--due")
    h.add_argument("--branch")
    h.add_argument("--by")
    h.add_argument("--response")
    h.add_argument("--status", choices=HO_STATUSES)
    h.set_defaults(fn=cmd_handoff)

    d = sub.add_parser("doc", help="new RCA, ADR, security finding or perf report from template")
    d.add_argument("kind", choices=tuple(DOC_KINDS))
    d.add_argument("--team")
    d.add_argument("--agent", required=True, choices=AGENTS)
    d.add_argument("--ticket", default="")
    d.add_argument("--title", required=True)
    d.add_argument("--severity", default="medium")
    d.set_defaults(fn=cmd_doc)

    lg = sub.add_parser("log", help="append to the team activity log")
    lg.add_argument("action")
    lg.add_argument("msg")
    lg.add_argument("--team")
    lg.add_argument("--agent", required=True, choices=AGENTS)
    lg.add_argument("--ticket", default="")
    lg.add_argument("--ref", action="append")
    lg.set_defaults(fn=cmd_log)

    tl = sub.add_parser("tail", help="show the last entries of a team log")
    tl.add_argument("--team")
    tl.add_argument("-n", type=int, default=30)
    tl.set_defaults(fn=cmd_tail)

    o = sub.add_parser("owner", help="which team owns a path")
    o.add_argument("paths", nargs="+")
    o.set_defaults(fn=cmd_owner)

    c = sub.add_parser("check", help="validate boards, handoffs, logs and ownership of changed files")
    c.add_argument("--team")
    c.add_argument("--changed", nargs="*")
    c.add_argument("--git-base", help="compare HEAD with this ref, e.g. origin/main")
    c.add_argument("--ticket", help="check the files checkpointed under this ticket")
    c.set_defaults(fn=cmd_check)

    cp = sub.add_parser("checkpoint", help="save files before editing them, so the ticket can be reverted")
    cp.add_argument("paths", nargs="+")
    cp.add_argument("--ticket", required=True)
    cp.set_defaults(fn=cmd_checkpoint)

    rv = sub.add_parser("revert", help="restore files to their checkpoint (all files of the ticket by default)")
    rv.add_argument("paths", nargs="*")
    rv.add_argument("--ticket", required=True)
    rv.set_defaults(fn=cmd_revert)

    df = sub.add_parser("diff", help="unified diff of a ticket's files against their checkpoints")
    df.add_argument("--ticket", required=True)
    df.set_defaults(fn=cmd_diff)

    s = sub.add_parser("status", help="board, handoffs and recent activity for a team")
    s.add_argument("--team")
    s.set_defaults(fn=cmd_status)

    cat = sub.add_parser("catalog", help="regenerate team/catalog/modules.md from the code")
    cat.set_defaults(fn=cmd_catalog)

    j = sub.add_parser("jira-export", help="write a Jira CSV import file from the boards")
    j.add_argument("--team")
    j.add_argument("--out")
    j.set_defaults(fn=cmd_jira)

    a = p.parse_args(argv)
    if a.cmd == "ticket" and a.action == "new" and not a.summary:
        p.error("ticket new needs --summary")
    if a.cmd == "ticket" and a.action == "move" and not (a.key and a.status):
        p.error("ticket move needs KEY and --status")
    if a.cmd == "handoff" and a.action in ("accept", "done", "reject") and not a.id:
        p.error(f"handoff {a.action} needs the handoff id")
    a.fn(a)


if __name__ == "__main__":
    main()
