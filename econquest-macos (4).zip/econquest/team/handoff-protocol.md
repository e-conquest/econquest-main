# Handoff protocol

A handoff is how one agent passes work, a question, or a finished piece to another agent, in the same
team or another one. Because each team runs in its own session, a handoff is **a file in the shared folder**, never a chat
message: one session's chat is invisible to the other two.

## Where handoffs live

```
team/handoffs/HO-20261023-A-B-001.md     one file per handoff, never renamed
team/logs/A.jsonl                         Team A's append-only activity log
team/board/A.csv                          Team A's board (Jira-importable)
team/board/program.csv                    program board (Team C AGENT-11 only)
```

Each team writes **only** its own log and board files and the handoffs it sends. The receiving team
edits only the `status`, `accepted_by` and `response` parts of a handoff addressed to it. That rule
is what keeps three accounts from producing merge conflicts on shared files.

## How handoffs travel

| Setup | Transport |
|---|---|
| **One account, three parallel sessions (current)** | The shared project folder `/mnt/project-files/econquest/`. A handoff is visible to the other sessions the moment it is written. Each session re-reads `team/handoffs/` at the start of every task. Leave `branch:` empty. |
| Later, if econquest moves to GitHub | The sender commits the handoff on its working branch; `branch:` names it. Blocking handoffs go on a small PR of their own so they merge within the day. |

The receiver checks for work at the start of every session with
`python team/teamctl.py handoff list --to <team> --status open`.

## File format

```markdown
---
id: HO-20261023-A-B-001
from: A/AGENT-06
to: B/AGENT-05
ticket: EQ-A-0012
type: contract-change      # work | review | question | contract-change | defect | release | info
priority: normal           # low | normal | high | blocker
status: open              # open | accepted | done | rejected
created: 2026-10-23
due: 2026-10-27
branch: team-a/EQ-A-0012-imports-series
accepted_by:
---
## Context
What happened, why the receiver needs to act. Two to five sentences.

## Ask
Exactly what the receiver must do or decide.

## Artifacts
- Paths, commits, test names, output files. Anything mentioned must exist on `branch`.

## Acceptance
How the sender will know it is done.

## Response
(receiver writes here)
```

`teamctl handoff new` writes this skeleton; `teamctl check` rejects a handoff with a missing field,
an unknown ticket, an unknown agent, or a `done` status with an empty Response.

## Rules

1. **One ask per handoff.** Two asks are two handoffs.
2. **Self-contained.** The receiver may be in another account with no memory of the sender's session.
   Name files and commits; never write "as discussed".
3. **Acknowledge within one working session.** The receiver sets `status: accepted` and `accepted_by`
   (or `rejected` with a reason in Response) the first time it sees the handoff.
4. **Contract changes go first.** If a change alters something another team reads (a CSV column,
   `run_latest.json` key, a function in `team/contracts.md`, a CLI flag), the owning team sends a
   `contract-change` handoff and waits for `accepted` before merging. AGENT-05 of each affected team
   reviews it.
5. **Never edit another team's files to save a handoff.** If Team C needs a new engine output, it
   asks Team B; it does not write into `econquest/engine/`. `teamctl check --changed` flags this.
6. **Log both ends.** Sender logs `handoff_sent`, receiver logs `handoff_accepted` and
   `handoff_done` in their own team log.

## Activity log format

`team/logs/<team>.jsonl`, one JSON object per line, append only, written by
`teamctl log`:

```json
{"ts": "2026-10-23T14:02:11Z", "team": "A", "agent": "AGENT-03", "ticket": "EQ-A-0004",
 "action": "rca_done", "msg": "WEO 2026 vintage renamed NGDPD; mapping fixed", "refs": ["team/rca/RCA-A-001.md"]}
```

Actions in use: `started`, `progress`, `blocked`, `unblocked`, `handoff_sent`, `handoff_accepted`,
`handoff_done`, `review_pass`, `review_changes`, `sec_pass`, `sec_finding`, `perf_pass`,
`perf_regression`, `rca_done`, `adr_proposed`, `adr_accepted`, `merged`, `released`, `done`.
The log is the team's memory between sessions and accounts; every agent reads the last 30 lines of
its team log before starting.
