# Runbook: distribute published research products by email (`econquest distribute`)

Ticket EQ-C-0045. Owner: Team C, AGENT-06. Operator: **Sam only, on the Mac**. Cloud sessions and agents never pass
`--send` (nothing is sent from the cloud environment, as for live fetches in CLAUDE.md rule 7); they may run
the dry run.

## What it does

`econquest editorial publish <id>` queues the published item (a `queue` row in `outputs/store/deliveries.jsonl`).
`econquest distribute send` builds one message per subscriber of that product kind and, **only with `--send`**,
sends it over SMTP. The message carries the archive link and the manifest's file names and sha256; nothing is
attached. Only items in state `published` whose published copy verifies (`editorial verify`) are sent; withdrawn,
corrected or tampered items are skipped and listed.

## One-time setup

1. Subscribers: add plain addresses (`name@domain`, no display names) to `data/distribution.json` under
   `subscribers.<kind>` (`daily_report`, `weekly_monitor`, `country_note`, `scenario_brief`). Optional:
   `archive_base_url` (https) when the published archive is served somewhere; otherwise the link is a `file://` path.
2. SMTP settings (the alert settings, reused): `ECONQUEST_SMTP_HOST`, `ECONQUEST_SMTP_PORT` (587 STARTTLS or 465
   SMTPS; plaintext is refused), `ECONQUEST_SMTP_USER`, `ECONQUEST_SMTP_FROM` in `~/econquest/.ops.env`, then
   `chmod 600 ~/econquest/.ops.env`.
3. Password: `security add-generic-password -s econquest-smtp -a "$USER" -w` (prompts; never on the command line).
   `$ECONQUEST_SMTP_PASSWORD` wins when set. It is masked in the delivery log, the action log and error messages.

## Each time

```
set -a; . ~/econquest/.ops.env; set +a
econquest distribute status                 # queue, pending, failures, latency p50/p95
econquest distribute send                   # DRY RUN: prints recipients and subjects, connects nowhere
econquest distribute send --send --actor Sam  # new addresses are withheld and printed
econquest distribute send --send --actor Sam --confirm-new new@example.com   # or all-listed
econquest distribute status                 # pending 0; failed attempts are retried by the next --send
```

**Confirm once (EQ-C-0051, SEC-C-005 R4).** An address that has never had a delivery (`sent` row) or a
confirmation in `deliveries.jsonl` is new: `--send` withholds its messages and prints it, and the other recipients
still get theirs. Check the address against the subscriber request, then send again with `--confirm-new ADDR[,ADDR]`
(or `--confirm-new all-listed`, which confirms and prints every new listed address) and `--actor Sam`. Each
confirmation is a chained `confirm` row (who, address, config sha256, time), written only on a real `--send`. The
dry run lists the addresses that would need confirmation. An address not in `data/distribution.json`, or with a line
break or display name, is refused.

`--item <id>` limits a send to one queued item. A recipient who has a `sent` row for an item is never sent it again.
`econquest distribute queue <id>` queues an item published before EQ-C-0045, or one whose automatic queue failed.

## Checks and failure handling

- `econquest distribute verify`: hash chain and head of `deliveries.jsonl`; exit 1 on a break. A broken chain
  refuses every send (the "already sent" state cannot be trusted): restore `outputs/store` from the nightly backup.
- A failed recipient (`error: ...` row) does not stop the others; fix the cause and run `--send` again.
- Latency: products from `published_utc` to the sent row; health alerts from the missed deadline or job time to the
  delivery (logged by `econquest health`). Report p95 from `distribute status` in the weekly ops note.
