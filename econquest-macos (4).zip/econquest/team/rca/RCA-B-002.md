---
id: RCA-B-002
ticket: EQ-B-0013
author: B/AGENT-03
created: 2026-10-23
severity: medium
status: done
---
# Layer 1 fitted mode scored on year-t WEO values against a lag-1 model; gap used as level (GOV-046)

## Symptom
EQ-B-0006 moved the panel fit to `predictor_lag` 1, so row t uses year t-1 values. `layer1_hazard.build_features`
still read the WEO primary balance for the calendar year of `as_of`, and took the other fitted predictors from
the indicator table (current-year values). In fitted mode a lag-1 model was therefore scored on year-t inputs.
Separately (GOV-046), when WEO history was not loaded, `primary_deficit` fell back to minus indicator 1.6. That
indicator is a primary-balance gap, not the deficit level the model was trained on.

## Reproduction
`tests/test_layer1_hazard.py::test_fitted_mode_uses_as_of_year_minus_predictor_lag` uses a synthetic WEO table
whose value encodes the year. Before the fix, the as_of 2026 run read 2026 values, and debt, current account and
growth came from the indicator table. The test then fails on `predictor_year == 2025`.
`test_fitted_mode_without_weo_history_refuses_the_gap_fallback` fails before the fix: the mode stays "fitted" and
the gap goes in as the level.

## Timeline
- EQ-B-0006 (2026-10-23, PI-1): the panel lag became 1. Fitted-mode alignment was deferred to EQ-B-0013 by review.
- GOV-046 had been open since the 2026-10-23 gap assessment.

## Root cause
`econquest/engine/layer1_hazard.py` `build_features` (old lines 37-41) used `as_of.year` for GGXONLB_NGDP, and
nothing passed the training lag from `layer1_fitted` to the run-time feature builder. Line 50 fell back to
`-ind["1.6"]`. Nothing in `from_settings` or `run_layer1` checked the units or the year of the fitted inputs.
The tests missed both: `test_engine_fitted_mode_uses_panel_features` checked only that the probabilities were
bounded and that the mode was "fitted", not which year or series fed the model.

## Fix
- `resolve_predictor_lag` reads `layer1_fitted.predictor_lag`; a missing key is read as 1 and flagged "assumed".
- `build_features(..., predictor_lag, weo_aligned)` takes the WEO-sourced fitted features for year
  `as_of.year - lag`, with the panel transforms and no substitute series.
- `run_layer1` refuses the fitted model when any input is missing. It runs `paper_standardized` and records
  `fitted_fallback` with a RuntimeWarning.
- Tests: `tests/test_layer1_hazard.py` (8 tests), and `test_engine_fitted_mode_uses_panel_features` made
  vintage-agnostic.

## Blast radius
None published. `layer1.mode` is `paper_standardized` in every run, and that mode does not use
`primary_deficit`. In the paper path `primary_deficit` now shows year as_of-1, and `pd_model` is unchanged
(checked: Venezuela 0.3768, Zimbabwe 0.0956, the same as before). The existing `layer1_fitted` block was fitted at
lag 0 and has no `predictor_lag` key. Run-time alignment reads it as lag 1, so it must be refit before any use.
No GOV id is needed for published numbers. GOV-046 can close after review.

## Prevention
- `fitted_block()` always writes `predictor_lag`, and the gate run (`refit_from_files`) records it in the JSON.
- Open: WB-sourced features (`stfx_debt_reserves`, `reserves_months_imports`, `pitf_instability`) have
  different run-time definitions from the panel. Before any fitted switch, either restrict the fitted block to
  WEO features or add WB history to the Universe (needs Team A, raw_worldbank.csv). Owner B/AGENT-03, follow-up
  ticket to be opened by AGENT-08.
- Suggest that governance `inventory_status` also report `layer1_fitted.predictor_lag` and flag a missing key.
