---
id: RCA-B-001
ticket: EQ-B-0008
author: B/AGENT-03
created: 2026-10-23
severity: medium
status: done
---
# Signal 19 saturates at a 2x PD gap; hedges sized against the risk budget; rule2 fallthrough

## Symptom
Base run on the shipped data (2026-10-23, `run_pipeline(u, s, paths=2000)`; signals do not depend on the
path count): Colombia signal 19 = 100.0 and dashboard `notional_mm` = 10.0, the full `signals.risk_budget_mm`,
with best trade T17 "Sell protection or buy bonds where spreads overprice risk" at conviction 100.
Colombia `pd_default` 0.01544, `pd_market` 0.03667, ratio 0.421. Nigeria (7.5) and Zimbabwe (4.5) were sized
off hedges (T13 commodity hedge at 100, T11 political risk insurance at 90).

## Reproduction
`tests/test_signals.py::test_complacency_signal_does_not_saturate_and_scales_with_gap` (ratios 0.1, 0.25,
0.42, 0.5 all gave signal 19 = 100 before), `::test_hedges_are_not_sized_against_the_risk_budget` (notional
9.0 from a Hedge at 90 before; 6.5 after), `::test_rule2_unknown_operator_raises` ("=>", "==", "" etc. were
silently treated as ">=" before), `::test_colombia_sizing_on_shipped_data`.

## Timeline
- Present since the workbook port of the Signals / Dashboard formulas (no earlier commit history: folder is not under git).

## Root cause
`econquest/engine/signals.py:37` (pre-fix) defined signal 15 as `max(0, min(100, 50 + 50*log2(ratio)))`;
the clip is reached at ratio 0.5 (and 2.0), so every country with market PD at least twice model PD got signal
15 = 0 and signal 19 = 100 - signal 15 = 100 (`:41`), whatever the size of the gap. `dashboard_table` (`:84`)
sized notional as budget x max(activated value) / 100 over all firing trades, including stance "Hedge" trades
(T05, T11-T14) that are insurance, not risk-budget positions. `trade_activation` (`:63`) compared
`rule2 == "<"` and otherwise used `>=`, so a typo in `playbook.csv` would change trade logic silently.
No test covered `signals.py` at all (the validation doc noted it), so neither the clip nor the fallthrough was
exercised.

## Fix
Signal 15 = 50 + 50 tanh(log2(ratio) / `signals.complacency_scale_log2`), scale 0.944 = 0.4/atanh(0.4), which
keeps the 70/30 crossings at a 1.32x gap (T16/T17 activation unchanged) and is continuous, strictly monotone and
inside (0, 100). Sizing uses the strongest firing trade whose stance is not in `signals.unsized_stances`
(["Hedge"]). `rule2` must be one of `<`, `<=`, `>`, `>=`; anything else raises `ValueError` naming the trade
before activation. New tests: `tests/test_signals.py` (17 tests).

## Blast radius
Tier 2 (signals and trade activation, `docs/governance/model-risk-policy.md` section 2). No Tier 1 number moves:
dashboard `notional_mm` is not read by the Monte Carlo, limits or portfolio (`data/portfolio.csv`). Signals at
or above 60: 117 before and after; trades firing: 72 before and after. Signal 15/19 values move for every
country with `pd_market >= min_market_pd` (e.g. Colombia 19: 100 -> 93.4, Brazil 87.1 -> 82.8, Belize 80.0 ->
78.1). Dashboard sizes: Colombia 10.0 -> 9.3, Nigeria 7.5 -> 6.45, Belize 6.0 -> 5.85, Zimbabwe 4.5 -> 3.75;
others unchanged. Two new parameters in `data/assumptions.json` (`data_hash`/settings change): owner +
approver sign-off per section 4. The workbook's own Signals/Dashboard formulas still have the old form
(open item 8 in `docs/validation/signals-trades.md`).

## Prevention
`tests/test_signals.py` pins continuity, the 70 crossing, operator validation, hedge exclusion and that
`playbook.csv` uses only valid operators. Follow-up: EQ-B-0004 (persist signals per run) would let a stability
check flag any signal stuck at 0 or 100 across many countries; suggest adding that check there (owner AGENT-01).
