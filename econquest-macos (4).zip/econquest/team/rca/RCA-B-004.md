---
id: RCA-B-004
ticket: EQ-B-0053
author: B/AGENT-03
created: 2026-10-24
severity: Low
status: done
---
# EL falls under a Stressed global state with no PD change

**Verdict: not a code defect.** Every layer 6 component behaves as specified. The fall is a property of the
specification: the long-loss cap truncates only the loss tail of a symmetric market move, so the capped mean falls
when copula nu falls. No published number moved. A diagnostic was added (two new metric keys, existing metrics
bit-identical) and the open specification question goes to Sam as a Tier 1 follow-up.

## Symptom
EQ-B-0042 evidence: with `monte_carlo.global_stress_share` 0.4 the global state turns Stressed, PDs do not change, and
EL goes from 0.463 to 0.426 at 32,768 paths. Re-run on 2026-10-24 (as_of 2026-10-23, current data and code):

| run (paths=20,000 -> 32,768 Sobol, seed 7) | global | nu | EL | EL uncapped | cap relief | VaR99 | ES99 |
|---|---|---|---|---|---|---|---|
| default | Calm | 5 | 0.4713 | 1.5231 | 1.0519 | 73.00 | 95.68 |
| global_stress_share 0.4 | Stressed | 4 | 0.4283 | 1.5050 | 1.0767 | 84.21 | 111.94 |

(The 0.463 in the ticket came from an earlier code and data state. The direction and size are the same.)

## Reproduction
`run_pipeline(u, s, paths=20000, as_of="2026-10-23")` vs
`run_pipeline(u, s.copy_with(**{"monte_carlo.global_stress_share": 0.4}), paths=20000, as_of="2026-10-23")`.
The decomposition re-ran `simulate`'s loop on the captured inputs with the same draws and split each position's mean
loss into market move, jump (default / T&C / expropriation severities), carry and cap.

At seed 7, the change from default to Stressed is -0.0430. It splits as:

| part | default | Stressed | change | over 20 seeds (default -> Stressed) |
|---|---|---|---|---|
| market move (zero mean) | 0.0009 | 0.0015 | +0.0006 | 0.0009 -> 0.0015 (noise) |
| jump | 8.5772 | 8.5585 | -0.0187 | 8.5731 -> 8.5726 (sd 0.009: noise) |
| carry | -7.0550 | -7.0550 | 0 | identical |
| long-loss cap | -1.0519 | -1.0767 | -0.0248 | -1.0572 -> -1.0867 (sd 0.004: systematic) |
| **EL** | 0.4713 | 0.4283 | -0.0430 | 0.4617 -> 0.4324 (SE 0.002 each) |

- PDs: positions `pd_default/pd_tc/pd_ex/pd_pv` max abs difference 0.0. Market vols are identical. The simulated hit
  frequency equals the model p within 0.0013 under both states.
- nu vs loadings, isolated: Calm with `df_calm` 4 gives a cap of -1.0817 (the same as Stressed). Stressed with
  `df_stressed` 5 gives a cap of -1.0519, bit-identical to default. **Only nu moves the cap term. The loadings move EL
  only through sampling noise in the jump term** (-0.019 at seed 7, about 0 on average over seeds).

## Timeline
- The long-loss cap has been in layer 6 since the first release, and `df_stressed` < `df_calm` since the first
  assumptions file. EQ-B-0042 made the global state easy to switch and exposed the effect.

## Root cause
EL (`expected_loss_mm`) is the mean path P&L loss including carry and market gains, not a credit EL. In
`econquest/engine/layer6_montecarlo.py`:
- the market move is `L = -zz * vol` (line 218), a zero-mean multiple of the standardised latent t;
- the event thresholds are `t_nu.ppf(p)` (line 179), so the event probabilities are exact under any nu;
- a long position's loss is capped at notional (line 240, `np.minimum(L, nn)`).

The cap removes the loss mass above 100% of notional. The matching gain tail is left in place. So E[min(L, n)] < E[L],
and the gap ("cap relief", 1.05mm of an uncapped 1.52mm at default) grows as nu falls. A lower nu means heavier tails
and more paths beyond notional. The Stressed global state sets nu = `df_stressed` 4 instead of `df_calm` 5
(layer3_regime.py:163, layer5_copula.py:265). The loadings change (layer5_copula.py:229-246) keeps g + r + idio = 1,
so each country's latent marginal stays t_nu, and EL, being a sum of marginal means, does not see it.

Where the cap binds at default (relief by asset class): Eurobond 0.736 (P14, P20, P17: high PD, and the spread move on
the default path adds to the LGD), Equity 0.226 (GPD expropriation + equity vol), Local bond 0.088 (default LGD +
T&C depreciation + market).

Why the tests did not catch it: there was no test of EL across nu or global states. Each layer passes on its own, and the
interaction is the specification.

## Fix
No change to any reported number. Diagnostic only, new keys in `MCResult.metrics`:
`expected_loss_uncapped_mm` (mean path loss before the long-loss cap) and `long_cap_relief_mm` (uncapped minus EL).
The layer 6 docstring documents the mechanism. Regression tests in `tests/test_layer6_montecarlo.py`:
- `test_cap_diagnostics_are_new_keys_only`: the existing pins hold at rtol 1e-9, and relief = uncapped - EL > 0;
- `test_el_falls_with_nu_only_through_the_long_cap`: paired over 8 seeds, nu 5 -> 4 on the frozen fixture. Cap
  relief +0.017 (SE 0.002) > 4 SE, EL falls, and the uncapped EL change (-0.002, SE 0.008) is within 3 SE;
- `test_loadings_do_not_enter_el_beyond_sampling_noise`: global loading x1.5 moves EL and cap relief within 3 SE.

## Blast radius
None. Every existing metric is bit-identical (layer 6 pins at rtol 1e-9). No published VaR, ES, EL or PD moved. The
open question below would be Tier 1 if acted on.

## Prevention / follow-ups
- Specification question for Sam (Tier 1, through AGENT-08): should EL be (a) reported as is, with the cap relief
  beside it; (b) a credit EL (jump term, p x LGD), reported alongside; or (c) based on a mean-preserving market move
  (re-centre the capped P&L, or use a bounded-below return)? Today the cap gives a "limited-liability" credit of
  about 1.05mm that rises with tail heaviness.
- Related observation: on a default path the Eurobond's spread move is added on top of its LGD, and the cap partly
  absorbs that double count (P17, PD 0.99, vol at the 60% cap). This is worth a layer 4/6 validation note.
- Proposed GOV row (issues log, Team B): "EL includes a long-loss-cap credit (1.05mm at 2026-10-23) that grows as
  copula nu falls; EL falls 0.03mm when the global state turns Stressed. Diagnostic keys added (EQ-B-0053,
  RCA-B-004). Decision on the EL definition pending (Tier 1)."
