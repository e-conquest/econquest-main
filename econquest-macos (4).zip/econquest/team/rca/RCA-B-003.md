---
id: RCA-B-003
ticket: EQ-B-0029
author: B/AGENT-03
created: 2026-10-23
severity: medium
status: draft
---
# Fitted layer 1 scored World Bank-sourced features on run-time substitutes

## Symptom
In `layer1.mode = fitted`, a `layer1_fitted` block whose `features` include `stfx_debt_reserves`,
`reserves_months_imports` or `pitf_instability` ran as "fitted" with no warning, on run-time values whose
definitions differ from the panel the coefficients were estimated on (hazard-layer1.md open item 7). Latent:
fitted mode is off and the shipped block is WEO-only, so no run was affected.

## Reproduction
`tests/test_layer1_hazard.py::test_fitted_mode_refuses_unaligned_features` (4 cases). Before the fix a block of the
WEO features plus `pitf_instability`, with complete WEO history, returned `mode = fitted`, no `fitted_fallback`, no
warning, and `pitf_instability` = pillar 4 aggregate / 25 (Vietnam 0.52, Philippines 1.92).

## Timeline
- EQ-B-0013 (2026-10-23) aligned only WEO-sourced features; non-WEO features were left on indicator-table definitions.

## Root cause
`run_layer1` (econquest/engine/layer1_hazard.py, fitted branch) passed only the WEO features to `weo_aligned`
(`aligned = [f for f in fb["features"] if f in wf]`) and let every other feature through to `build_features`, which
builds stfx_debt_reserves from indicator 2.9, reserves_months_imports from reserves / exports x 12 and
pitf_instability from pillar 4 / 25, while hazard_panel.PANEL_FEATURES uses WDI DT.DOD.DSTC.IR.ZS, FI.RES.TOTL.MO and
WGI PV.EST rescaled. The Universe has no World Bank history (loaders read only raw_weo.csv; raw_worldbank.csv has
none of the three series), so alignment is not possible today. The tests missed it because every fitted-mode test
used a WEO-only block.

## Fix
`unaligned_fitted_features(features)` lists each fitted feature without a run-time source aligned with the panel
definition (every non-WEO panel feature, and any non-panel feature) with the reason. `run_layer1` refuses such a
block for the whole run like GOV-046: paper_standardized, RuntimeWarning naming EQ-B-0029,
`attrs["model"]["fitted_fallback"]` and `["fitted_unaligned"]`. Paper mode never consults it. Tests:
`test_fitted_mode_refuses_unaligned_features`, `test_unaligned_fitted_features_names_the_panel_series`,
`test_wb_refusal_leaves_weo_only_fitted_and_paper_mode_unchanged`.

## Blast radius
None. Fitted mode is off; the shipped block is WEO-only (verified in the test). No VaR/ES/PD moved: the 18-country
base run is bit-identical.

## Prevention
- The refusal itself is the guard: any future fit that adds a WB feature is refused at run time until it is aligned.
- HO-20261023-B-A-006 (Team A): load WDI/WGI history into the Universe (`wb_raw`). Then a Team B follow-up sources
  the three features at `as_of.year - predictor_lag` with the panel transforms and lifts the refusal for them.
- Suggested: `fit-hazard --apply` (Team C, cli.py) should warn when the proposed block contains a feature that
  `unaligned_fitted_features` reports, so it is caught at proposal time, not at run time.
