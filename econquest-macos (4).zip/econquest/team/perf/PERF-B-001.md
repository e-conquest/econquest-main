---
id: PERF-B-001
ticket: EQ-B-0034
author: B/AGENT-04
created: 2026-10-23
status: open
---
# N-country scaling: engine and scorecard at 70 and 88 countries

## Workload
`run_pipeline(u, s, paths=100000, as_of="2026-10-23")` (131,072 Sobol paths) on `data/` (2026-10-23 live vintage),
in-process, timings from `RunResult.timings`, median of 3. N > 18 uses the SYNTHETIC universe of
`tests/test_scale_n_countries.py::synthetic_universe` (perturbed copies of the 18, ISO XAA..., never real data);
"seed book" = 24 positions on the 18, "replicated book" = positions and prediction-market contracts copied to the clones.
Machine: cloud container, 4 cores, Python 3.13.17, numpy 2.5.3, pandas 3.0.5, scipy 1.18.1. Other Team B workers
were running on the same box, so stage times carry about +-30% noise (layer 6 at 18 countries measured 4.1 to 6.0 s).
Harness: scratchpad `perf/scale.py`, `perf/hitonly.py`, `perf/ref18.py`.

## Baseline (before EQ-B-0034)
| N | book (positions) | scorecard* | layer 6 | total | peak RSS |
|---|---|---|---|---|---|
| 18 | seed (24) | 0.38 s | 4.40 s | 4.94 s | 458 MB |
| 70 | seed (24) | 0.88 s | 7.55 s | 8.87 s | 1,051 MB |
| 70 | replicated (94) | 0.88 s | 16.25 s | 17.45 s | 1,259 MB |
| 88 | seed (24) | n/m | 7.04 s | 7.63 s | 1,255 MB |
| 88 | replicated (118) | n/m | 20.09 s | 20.84 s | 1,530 MB |
*cumulative timer, includes GPR. 88-country rows were measured after the scorecard change.

AGENT-04 budget (team/perf/baseline.md): full pipeline 5.12 s at 18 countries. 18 countries is within it; 70 and 88
countries are not (1.7x and 1.5x with the seed book, 3.4x and 4.1x with a replicated book).

## Profile (70 countries, replicated book, cProfile tottime)
1. `scipy beta._ppf` 12.2 s of 26.3 s: `layer4_severity.sample_haircut` called from `layer6_montecarlo.simulate`
   (line 189) on all 131,072 paths for every beta-severity position, although only default paths (`hit`) use it.
2. `scipy.stats.qmc.Sobol._random` 2.5 s: dims = 1 + R + 1 + N + 2P grows with countries and positions.
3. `norm.ppf` over the n x dims uniforms 0.5 s; array copies (`ravel`) 1.0 s.
4. Scorecard `score_indicators` 1.5 s (2 calls, per-cell `.at` loop) -> fixed here.
Everything else (layers 1-5, arbitrage, signals) is under 0.3 s each at 70 countries and grows linearly.

## Change and result
In my files: `score_indicators` vectorised across countries and the pillar loop reads a numpy array.
| Metric | Before | After | Delta |
|---|---|---|---|
| scorecard, 18 countries | 0.38 s | 0.15-0.25 s | -35 to -60% |
| scorecard, 70 countries | 0.88 s | 0.28 s | -68% |

Proposed (layer 6 owner, not applied; measured with a patched copy of `simulate`): evaluate the beta / GPD
severity only on `hit` paths (`sev = np.zeros(n); sev[hit] = ... uu[hit]`).
| Case | layer 6 / total before | after | losses |
|---|---|---|---|
| 18, seed book | 4.13 / 4.61 s | 0.78 / 1.24 s | bit-identical |
| 70, seed book | 7.01 / 8.49 s | 3.95 / 5.60 s | bit-identical |
| 70, replicated book | 19.68 / 21.22 s | 5.44 / 6.79 s | bit-identical |
With it, 70 countries on the seed book is at about the 5.1 s budget; the remainder is Sobol generation and the
n x dims arrays. Memory: RSS grows 458 MB -> 1.05-1.5 GB because `simulate` holds U (n x dims), eps, latent and z
(n x N each) and pos_loss (n x P) at once; dropping `z` (compute per column) and releasing U after slicing would cut
about 0.3-0.5 GB at 88 countries.

## Numerical equivalence
18 countries, seed 7, 131,072 paths, as_of 2026-10-23: country table (shared columns), losses vector, metrics,
composite, pillar_final, signals, activation, dashboard and arbitrage bit-identical before vs after (tolerance 0).
VaR99 63.9769, ES99 83.0212, EL 0.5289. Top-5 PDs unchanged (same country table).

## Scaling finding (Tier 1, not a perf item)
Layer 1's rating-prior calibration is fitted across the run's countries, so adding countries moves every PD: at 70
synthetic countries the 18 desk countries' pd_default moved up to 144 bp (Zimbabwe), EL on the same book 0.53 -> 0.45
mm. New opt-in key `layer1.calibration_universe` (default absent = today) pins the set. See hazard-layer1.md.
