# Performance baseline

Workload: `python -m econquest run --stress --backtest` (100,000 requested, 131,072 Sobol paths simulated since 0.1.1, EQ-B-0007).

| Stage | Before 0.1.1 (100,000 paths) | 0.1.1 (131,072 Sobol paths) |
|---|---|---|
| Layer 6 Monte Carlo | 3.49 s | 4.61 s |
| Full pipeline | 4.00 s | 5.12 s |
| Peak RSS | 398 MB | 453 MB |

Source: Team B measurement reported in HO-20261023-B-C-006 (2026-10-23). Re-measured 2026-10-23 by Team B AGENT-04: full pipeline 4.58-4.94 s, 458-461 MB (PERF-B-001).

## N-country scaling (EQ-B-0034)

Source: team/perf/PERF-B-001.md "Baseline". `run_pipeline` in-process, 131,072 Sobol paths, median of 3, 4-core container, +-30% noise, synthetic universe from tests/test_scale_n_countries.py.

| Countries / positions | Full pipeline | Peak RSS |
|---|---|---|
| 18 / 24 | 4.58 s | 461 MB |
| 70 / 24 | 8.28 s | 1,051 MB |
| 70 / 94 | 18.33 s | 1,254 MB |
| 88 / 24 | 7.63 s | 1,255 MB |
| 88 / 118 | 20.84 s | 1,530 MB |
