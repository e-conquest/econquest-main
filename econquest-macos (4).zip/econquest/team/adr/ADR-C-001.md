---
id: ADR-C-001
ticket: EQ-C-0033
author: C/AGENT-07
created: 2026-10-23
status: proposed      # proposed | accepted | superseded by ADR-x-nnn | rejected
contracts: [C11]      # C-numbers from team/contracts.md this touches
---
# Workbook layout v2 (C11)

## Context
The publish plans (`sheets_publish.build_plan`, `garch_publish.garch_plan`, `econ_publish.econ_plan`) hard-coded the
18-country layout: `COUNTRY_COLS = "E:V"`, fixed ranges such as `E5:V87`, `A50:M67`, `MC!Z7:BD`, and column letters
from `chr(65+k)` that break past Z (GARCH DCC matrices) or past AZ (Econometrics). GARCH Table A was fixed at 30 series
(`A5:Z34`). Team A is proposing a 70+ country universe (EQ-A-0025), so a run with N > 18 countries would write
malformed or overlapping blocks. C11 (tab names and anchor cells, consumed by Sam's workbook formulas) must not
silently move. No model-risk tier applies: presentation only, no model change.

## Decision
Every publish plan sizes itself from the run: `sheets_publish.layout_v2(N, ...)` is the single source of every
run-dependent range; column letters come from `sheets_publish.col_letter` / `col_number` (A..Z, AA.., ZZZ, error past
the Sheets limit of 18,278 columns); `plan_problems(plan)` checks fit, column limit and overlaps per tab.
Country-by-column blocks start at E and are N wide (E:col(4+N)). Fixed C11 anchors (tab names, A2 notes, Risk Engine
A12:D12 and R31-R33 labels A35:D37) do not move: they are in columns A-D and no growing block reaches them. The one
anchor that would sit inside a growing block, the Portfolio VaR asset-class table (B70:F74), moves to B(52+N):F(56+N)
and Python writes its header and labels when N > 18. At N = 18 the plan is byte-identical to v1.
`data/workbook_reference.json` carries `layout_version: 2` and a `layout` section with every block's rule and its exact
range at N = 18 and N = 70.

## Options considered
| Option | For | Against |
|---|---|---|
| Grow blocks in place from the run (chosen) | Byte-identical at 18; one rule per block; no new tabs | Sam must widen tabs and move anything right of V / below row blocks |
| Fixed maximum width (e.g. E:CZ for 100 countries) | Workbook prepared once | Empty columns, still breaks past the maximum; changes every v1 range now |
| One row per country (transpose country tabs) | Never hits column limits | Rewrites every Sam formula; breaks C11 at 18 countries |
| Separate v2 tabs | v1 untouched | Two layouts to maintain; formulas duplicated |

## Consequences
Easier: any country or series count publishes without code changes; layout checked by tests at 1-200 countries.
Harder: the live workbook must be widened before the first N > 18 publish.

### What Sam must change in the workbook
> Workbook layout v2 (C11, EQ-C-0033). At 18 countries nothing changes. When a run has N > 18 countries, the publish plan writes these ranges. col(k) = k-th column letter: E=5, V=22, BV=74.
> 1. Country-by-column tabs (Inputs, Stress Inputs, Base Scores, Stress Scores, Indicator Scores, Adjustments, Pillar Scores, Risk Engine, Signals, Trade Activation, GPR): every block goes from E:V to E:col(4+N), and rows are unchanged. At N=70 that is E:BV. Before the first publish, insert columns so each of these tabs reaches col(4+N). A tab with only A:Z fails with "exceeds grid limits". Anything you keep to the right of column V on these tabs (formulas, notes, charts) must move right of col(4+N). Formulas that reference E:V or `$V` need widening, for example to E:BV or open-ended ranges.
> 2. Portfolio VaR: holdings by country grows from A50:M67 to A50:M(49+N). The asset-class table moves from B70:F74 to B(52+N):F(56+N). Python writes its header row at A(51+N):F(51+N) and the labels at A(52+N):A(56+N). At N=70: holdings A50:M119, header A121:F121, labels A122:A126, data B122:F126. Move your static labels and anything at rows 68 and below down by N-18 rows, and repoint formulas that read B70:F74.
> 3. Prediction Markets: the country block grows from A38:M55 to A38:M(37+N). Move anything below row 55.
> 4. Dashboard: country rows grow from A6:V23 to A6:V(5+N). Move anything below row 23.
> 5. MC: with R copula regions (3 today), the latent block G2:X5 / A7:X becomes col(4+R)2:col(3+R+N)5 / A7:col(3+R+N). The loss block Z:BD moves to col(5+R+N):col(35+R+N). At N=70: G2:BX5, A7:BX, BZ:DD. Widen the MC tab to at least col(35+R+N) (DD at 70) and repoint formulas that read Z:BD. If the region count changes, the latent block start moves too.
> 6. GARCH: with more than 30 series (S), Table A grows past row 34 to A5:Z(4+S), and Tables B-F move down by S-30 rows. DCC matrices get k+1 columns (BS for 70 labels), so widen the tab to match.
> 7. Trade Ideas (new tab, EQ-C-0047, any N): before the first `econquest publish --ideas`, create a tab named exactly `Trade Ideas`. Python writes notes to A1:A3 and the quarterly table to A5:G(6+Q): header on row 5, one row per quarter, "All quarters" total on the last row (A5:G6 when there are no ideas). The table grows down one row per quarter, so keep A:G below row 6 free for it (put your own notes or formulas right of G). No existing tab or anchor changes, and `publish` without `--ideas` does not write this tab.
> 8. Weekly RV (new tab, EQ-C-0046, any N): before the first `econquest publish --rv`, create a tab named exactly `Weekly RV` and widen it to at least 40 columns (A:AN; a new tab has only A:Z, and a narrower tab fails with "exceeds grid limits"). Python writes notes to A1:A4, the bond relative-value table to A6:R(6+C) (header on row 6, one row per country in outputs/bond_rv.csv; A6:R7 with a status message when there are no rows) and the CDS curve table to T6:AN(6+K) (header on row 6, one row per curve point in outputs/cds_curves.csv; T6:AN7 reading "No CDS curves: ..." while that file is empty). Both tables grow down only, so keep A:R and T:AN below row 6 free (column S is a gap; put your own notes or formulas right of AN). Spreads and gaps are in bp (gap = market - fair, + = cheap vs model), PD, LGD, survival, cumulative PD and recovery are fractions: format those columns as %. z is blank for distressed names. Market source and the curve rows carry the "(SYNTHETIC)" / synthetic marker when the quotes are test data: never read those as market levels. Diagnostic only (Team B has not wired bond RV into the run yet). No existing tab or anchor changes, and `publish` without `--rv` does not write this tab.
> Everything is in data/workbook_reference.json → "layout", with exact ranges at N=18 and N=70.

Other code that reads plan ranges: `country_note.py` hard-codes `'Pillar Scores'!E29:V35` / `E46:V47` and falls back to
recomputing at N > 18; it should use `layout_v2(len(names))["pillar_final" / "pillar_composite"]` (follow-up for the
AGENT-07 owning it). `republish_preview.py` now uses the shared column helpers (tested past Z).

### Open items
- Weekly RV (item 8, EQ-C-0046) is a snapshot of the latest outputs/bond_rv.csv and cds_curves.csv; the tab keeps no week-on-week
  history (Sam can copy it, or a later ticket can append weekly rows).
- Portfolio VaR positions stay fixed at 30 rows (`H5:Y34`, `AB5:AB34`) and the MC loss block at 30 position columns; a
  book with more than 30 positions builds a malformed plan.
- Prediction Markets contracts stay fixed at 30 rows (`I5:X34`).
- Header text of the moved asset-class table is Python's own; confirm against the live workbook.
- Contract-change handoff to Sam (routed by AGENT-08).

## Rollout
1. Code and JSON (EQ-C-0033): `tests/test_workbook_v2.py` (golden v1 range list at 18, synthetic 70-country run with
   no overflow/overlap and anchors unchanged, GARCH at 140 series, Econometrics past 52 columns),
   `tests/test_republish_preview.py::test_columns_past_z_workbook_v2`.
2. Sam widens the workbook per the list above before the first N > 18 publish; preview with
   `republish_preview` against a batchGet of the live sheet.
3. First N > 18 publish only after Team A's universe (EQ-A-0025) is approved.
