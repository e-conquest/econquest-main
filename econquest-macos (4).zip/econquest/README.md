# EconQuest engine

A Python program that implements the paper *Panoptix: Sovereign Tail-Risk and Geopolitical Information Asymmetry: A Quantitative VaR Framework for Macroeconomic Arbitrage*, following its six-layer pipeline (section 3) and its software architecture (Appendix B). It runs on a snapshot of the Geopolitical-Macro Risk Desk workbook (18 countries, 83 indicators, 24 positions, 18 prediction-market contracts) and reproduces the workbook's scorecard exactly before layering the paper's probability, severity, dependence and simulation machinery on top.

## Quick start

**One-command install (macOS, also Linux).** Unzip the download, then either double-click `install.command` or run:

```bash
bash econquest/install.sh
```

It finds Python (Homebrew, python.org or Anaconda; 3.12, 3.13 or 3.14, the versions `requirements-lock.txt` covers), copies the program to `~/econquest`, installs every dependency into a private virtual environment at `~/econquest/.venv` from the hash-pinned `requirements-lock.txt` (`pip install --require-hashes`: exact versions, each download checked against its SHA-256, and a mismatch stops the install with nothing installed), and puts an `econquest` command on your PATH. Open a new Terminal window and run `econquest gui` for the point-and-click app, or `econquest fetch --apply`, `econquest garch`, `econquest econ`, `econquest publish --write`. Data and outputs live in `~/econquest`. Remove it with `bash ~/econquest/install.sh --uninstall`. Nothing is installed system-wide and no admin password is needed. **Upgrade:** unzip the new release and run its `install.sh` (or double-click its `install.command`) the same way: `data/` and `outputs/` are backed up to `~/econquest-backups/<UTC time>/` and kept, and only the released model configuration is updated unless this Mac has approved changes of its own. `bash install.sh --help` shows the options; an unknown option stops without changing anything.

**Manual install.** From the folder that holds `data/` and `pyproject.toml`: `pip install --require-hashes -r requirements-lock.txt && pip install --no-deps --no-build-isolation -e .` (what `install.sh` runs; plain `pip install -e ".[all]"` also works but resolves unpinned from PyPI), then `econquest ...` (or `python3 -m econquest ...` without installing).

```bash
cd econquest
python3 -m econquest gui                 # local browser app: charts, tables, analyst workbench, buttons for every command
python3 -m pytest -q tests                 # about a minute: tests/test_panoptix.py (pipeline, workbook regression, stress, backtests) plus test_severity.py, test_garch.py, test_econometrics.py, test_feeds.py, test_record.py, test_hazard_panel.py, test_cds.py, test_benchmarks.py, test_report_alerts.py, test_limits.py, test_scenarios.py, test_governance.py
python3 -m econquest run --stress --backtest   # full run: 100,000 requested, 131,072 Sobol paths simulated, scenarios A-C, backtests, dashboard
python3 -m econquest arbitrage             # prediction-market monitor
python3 -m econquest stress --scenario A   # one scenario with the full comparison
python3 -m econquest hmm                   # 3-state Gaussian HMM demo (or --series your.csv)
python3 -m econquest backtest --history data/backtest_history.csv
python3 -m econquest serve --port 8080     # JSON API + SSE + dashboard at http://127.0.0.1:8080/
python3 -m econquest publish --write              # recalculate and write every model tab of the workbook as values
python3 -m econquest fetch                 # pull live inputs from IMF WEO, World Bank and BIS, FX from BIS WS_XRU and the ECB reference rates, into data/live
python3 -m econquest audit                 # build data/audit_trail.csv (source, vintage, transform, gate decision per input cell); --write writes the Audit Trail tab
python3 -m econquest fit-hazard --build-panel --fetch --apply   # recalibrate the hazard model on a real sovereign default panel (needs api.imf.org)
python3 -m econquest cds                   # CDS-implied PDs and model-fair spreads from data/cds_quotes.csv
python3 -m econquest stress                # run the scenario library (data/scenarios.json: paper A, B, C plus 1997, 2008, 2013, 2020, 2022, downgrade cycle); --scale 0.5 halves every shock
python3 -m econquest reverse-stress        # smallest severity of each scenario and single factor that breaches a book limit in data/limits.json
python3 -m econquest scenarios --shocks    # list the scenario library
python3 -m econquest governance            # rebuild docs/governance/change-log.md from the run archive and print the model inventory status
python3 -m econquest report                # daily risk report: outputs/reports/risk-report-<date>.html and latest.html, plus outputs/alerts.json
python3 -m econquest alerts --webhook --email   # regime flips, PD/VaR moves, signal crossings, backtest failures, data issues since the previous run
python3 -m econquest limits --propose "Argentina,Eurobond,Long,10,6"   # pre-trade check against data/limits.json (omit --propose for the limits table)
python3 -m econquest benchmark             # append today's PD snapshot (model, hazard, rating, spread, CDS, prediction market) to data/benchmarks.csv; --write writes the PD Benchmarks tab
python3 -m econquest fetch --apply         # ...and overwrite the seed values in data/indicators.csv and data/countries.csv
python3 -m econquest fetch --apply --force --author Sam --self-approved   # also apply gate-held cells (four-eyes: --approver OTHER instead of --self-approved)
python3 -m econquest review list           # latest analyst decision per gate-held cell (data/live/review_ledger.csv)
python3 -m econquest review approve "Country Profile" fx3m Brazil --author Sam --self-approved   # decide a held cell against the saved vintage
python3 -m econquest review apply          # apply that vintage offline (no refetch); --dry-run to preview
python3 -m econquest run --as-of 2026-10-20 --vintage 2026-10-20   # replay a past run: fixed model date, inputs frozen with that fetch vintage
python3 -m econquest dsa                   # debt sustainability fans and reserve adequacy; writes outputs/dsa_scorecard_feeds.csv for the ingestion gate
python3 -m econquest publish --dry-run     # any workbook writer: save the plan only, never look up a token or call Sheets
python3 -m econquest garch                 # GARCH(1,1)-t and DCC-GARCH volatility layer from data/market_history; builds the GARCH tab plan
python3 -m econquest econ                  # econometrics toolkit (ten tables) from data/market_history; builds the Econometrics tab plan
python3 -m econquest ideas log             # trade-idea log, illustrative, Tier 3 (GOV-032): log|mark [--as-of]|report; outputs/idea_log.csv, idea_report.md; run (base) and record update it
```

Dependencies (installed by `pip install -e .`): numpy, pandas, scipy, scikit-learn, and the feed clients `imf-reader`, `weo`, `wbgapi` (BIS and ECB are read with the standard library). The `[all]` extra adds `fastapi`/`uvicorn` for `serve` and `pytest`; `[ml]` adds `lightgbm`, `hmmlearn`, `statsmodels`; `[research]` adds `yfinance` for `feeds.YahooFeed`, which is research only: Yahoo Finance is not a desk feed (its terms are personal, non-commercial; EQ-A-0040), no desk command uses it, and `[research]` is not in the lock.
`requirements-lock.txt` (EQ-C-0066) pins these, plus `[all]`, setuptools and pip, to one version each with the SHA-256 of every PyPI wheel for macOS arm64 and x86_64 (and Linux x86_64/aarch64) on Python 3.12-3.14; `install.sh` installs only from it. **The other extras are not in the lock**: `[api]`, `[ml]`, `[test]`, `[ci]`, `[research]`, `[bloomberg]` and `[lseg]` are resolved by pip unpinned and without hash checks when you install them. `[bloomberg]` (`blpapi>=3.23,<4`) comes from Bloomberg's own package index, never PyPI (PyPI has no `blpapi` project, so a same-named upload there would be someone else's): `pip install blpapi --index-url=https://blpapi.bloomberg.com/repository/releases/python/simple/`, with `--index-url`, never `--extra-index-url`. `[lseg]` is `lseg-data>=2.1,<3` from PyPI. Regenerate the lock after changing a dependency: `python scripts/make_hash_lock.py` (needs network); `bash scripts/ci_local.sh` fails its `install lock` gate when a pyproject dependency is missing from the lock or pinned outside its range.

Outputs land in `outputs/`: `dashboard.html` (open in a browser), `country_risk.csv`, `positions.csv`, `contributions.csv`, `arbitrage.csv`, `latent_correlation.csv`, `stress.json`, `backtest.json`, `run_latest.json`, and `store/` (SQLite database plus the archive of every run and its simulation paths).

## Development: local CI and release build

`scripts/ci_local.sh` runs the same gates as `.github/workflows/ci.yml`: the team gate (`teamctl check`), the full
test suite, a 2,000-path smoke run (written to a temp folder, never to `outputs/`), ruff (advisory), bandit and
pip-audit against `scripts/requirements-lock.txt`. It exits non-zero if a blocking gate fails. Install the tools with
`pip install -e ".[ci]"`.

```bash
ECONQUEST_TEAM=C bash scripts/ci_local.sh               # every gate
CI_TICKET=EQ-C-0001 bash scripts/ci_local.sh            # team gate on one ticket's checkpointed files
CI_OFFLINE=1 bash scripts/ci_local.sh                   # skip pip-audit (it needs PyPI/OSV; it also skips itself when offline)
CI_SKIP="tests smoke" bash scripts/ci_local.sh          # skip gates by name: gate tests smoke lint bandit audit
RUFF_BLOCKING=1 bash scripts/ci_local.sh                # make repo-wide ruff blocking too (Team C paths always block)
python scripts/build_release.py /tmp/rel/econquest-macos.zip   # reproducible zip + .sha256 + .manifest.txt
python scripts/make_lock.py --check                     # installed packages still match the lock?
```

Other settings: `CI_SMOKE_PATHS` (default 2000), `PIP_AUDIT_BLOCKING=0` (report findings without failing), `PYTHON`.
`scripts/requirements-lock.txt` (pip-audit's input, all extras) pins versions only; the hash-pinned lock that `install.sh` uses is
`requirements-lock.txt` at the top level, written by `python scripts/make_hash_lock.py` and checked offline with `--check`.

## How the paper maps to the code

| Paper | Code | What it does here |
|---|---|---|
| Appendix B.3 Ingestion and ETL | `econquest/ingestion/` | `Source` adapters (CSV snapshot, Google Sheets REST, Polymarket Gamma, Kalshi v2) and `load_universe`, which validates weights, ids and positions before anything runs. Live market adapters fall back to the snapshot offline and record provenance. |
| Appendix A, 7-pillar scorecard | `econquest/scorecard/scoring.py` | 83 indicators scored by threshold interpolation (level indicators 0-4), the eight stress-path indicators scored on the combined shock and the worse score kept, worst-indicator blend, capped triggers, analyst adjustments, override floors from the flags, small-state weights, composite and grade. Matches the workbook to 0.1 points. |
| 3.1 Layer 1 hazard | `engine/layer1_hazard.py` | Logistic hazard with the paper's six predictors; `fit_firth` is a Firth penalized estimator for when an event panel exists. A monotone challenger (rating-implied PD, standing in for LightGBM) is reconciled in log-odds space. |
| 3.2 Layer 2 Bayesian update, 3.2.1 prediction markets | `engine/layer2_bayesian.py` | logit(p_post) = logit(p_model) + w_s (S - S_bar) + w_cds z_cds + w_fx z_fx + w_tsi z_tsi; precision-weighted blend with the default-contract prior (tau_market scales with open interest); arbitrage scan with fractional Kelly sizing. |
| 3.3 Layer 3 regimes | `engine/layer3_regime.py` | Rule-based regime (spread, depreciation, reserve loss), the 12-month transition matrix, expected PD and LGD multipliers, and a 3-state Gaussian HMM (EM, Viterbi) in numpy. |
| 3.4 Layer 4 severity | `engine/layer4_severity.py` | Beta haircuts (Cruces-Trebesch mean by asset class, regime-scaled), Merton distance-to-distress from a sovereign balance-sheet proxy, GPD tails for expropriation and political-violence losses, sector and location multipliers. |
| 3.5 Layer 5 dependence, 6.3 L-VaR | `engine/layer5_copula.py` | Global, regional and idiosyncratic factor loadings; Student-t copula with nu = 5 (calm) or 4 (stressed global regime); tail dependence (Theorem 6.1); liquidity-adjusted VaR. |
| 3.6 Layer 6 Monte Carlo, 10 FRTB | `engine/layer6_montecarlo.py` | 100,000 requested paths rounded up to a power of two (131,072 scrambled-Sobol points, balanced), latent t variable per country driving market moves and events, VaR/ES at 95 and 99, ES 97.5 (FRTB), L-VaR, position and country contributions. |
| 9 Stress scenarios | `engine/stress.py` | Scenario A (Fed +200 bps), B (30% commodity collapse), C (Strait of Malacca blockade) as parameter and data patches, compared against the base run. |
| 7.3 and B.6 governance | `validation/backtests.py` | Kupiec, Christoffersen independence and conditional coverage, Acerbi-Szekely Z2, Brier score, Basel zone. Same results as the workbook's Backtesting tab on the sample history. |
| Appendix B.4 persistence | `persistence/store.py` | SQLite tables for runs, country and portfolio metrics as time series, position contributions, arbitrage and indicator definitions (the PostgreSQL / TimescaleDB roles); JSON and `.npz` archive of each run and its paths (the S3 role). |
| Appendix B.5 presentation and API | `presentation/` | REST endpoints, Server-Sent Events, the Interactive Pillar Adjustment Workbench (`POST /api/workbench` reruns with analyst adjustments and pushes the summary to subscribers), and a self-contained dashboard page. |
| B.6 CI | `tests/` | Pure-Python tests; wire `python -m pytest tests` into any CI runner (`python tests/test_panoptix.py` runs the main file without pytest). |

Everything numeric sits in `data/assumptions.json`, exported from the workbook's Assumptions tab so the two share one parameter set. `data/workbook_reference.json` holds the workbook's outputs for the regression tests.

## Results on the October 2026 snapshot

Base run, 100,000 paths, calm global regime (8 of 18 countries not calm, below the 50% switch), Student-t with 5 degrees of freedom:

| Metric | Program | Workbook |
|---|---|---|
| VaR 99% ($mm) | 65.9 | 59.3 |
| ES 99% ($mm) | 85.2 | 76.9 |
| ES 97.5% FRTB ($mm) | 67.7 | n/a |
| Liquidity cost at 99% ($mm) | 5.28 | 5.28 |
| L-VaR 99% ($mm) | 71.1 | 64.6 |

The program's tail is about 10% heavier than the workbook's because severities are stochastic (Beta haircuts and GPD tails instead of fixed percentages) and because Layer 1 replaces the pure rating prior. Default PDs on the October 2026 seed snapshot (`tests/seed_data/`, the data the workbook reference was computed from): Venezuela 99%, Zimbabwe 88%, Senegal 18% (the workbook has 34% after a 52% prediction-market prior; the program weights that thin contract at tau 0.09), Pakistan 14%, Argentina 14%. On the live data now in `data/` the same run gives Zimbabwe 78.4% and Senegal 23.9%.

Stress scenarios (change in ES 99%): A +86% with 5 of 18 countries moving to Crisis and liquidity cost +81%; B +5% with the expected hard-currency haircut up 27 points; C +24% with liquidity cost +68%. The paper quotes +18.4% for A and +24.6% liquidation cost for C; the scenario sizes are parameters in `engine/stress.py`.

Backtests on the 120-month sample history: 4 exceedances against 1.2 expected, Kupiec p = 0.043 (fail), Christoffersen conditional coverage p = 0.112, Z2 = -2.66 (fail), Basel zone Yellow. Identical to the workbook's Backtesting tab.

## The workbook is a view; Python is the calculator

Since October 20, 2026 the Geopolitical-Macro Risk Desk workbook holds inputs and published values only. `econquest publish` runs the full pipeline and writes 101 ranges (about 22,000 cells with `--mc-rows 100`) into the existing tabs: Stress Inputs, Base/Stress/Indicator Scores, Adjustments, Pillar Scores, Risk Engine (now with rows R31-R33: hazard PD, rating PD, Merton distance to distress), Signals, Trade Activation, Portfolio VaR (position columns, results, holdings and asset-class tables), MC (parameters and a sample of paths), Prediction Markets, GPR, Dashboard and the Backtesting results. Each model tab carries a note in cell A2 with the run date. The ported sheet logic lives in `engine/gpr.py` (GPR uplift and signals), `engine/signals.py` (25 signals, trade activation, dashboard) and `presentation/sheets_publish.py` (the cell map).

To recalculate after changing inputs: edit the workbook's input tabs and mirror the change in `data/` (or edit `data/` directly), then run `publish`. Without `--write` the plan is saved to `outputs/publish_plan.json` for any Sheets client to apply (`values:batchUpdate`, `USER_ENTERED`); with `--write` and a bearer token holding the spreadsheets scope it is applied directly (see Sheets token below). `--mc-rows` sets how many Monte Carlo paths the MC tab shows (2,000 by default; the October 20 publish used 100 because it went through the Sheets connector cell by cell). The all-formula version of the workbook is kept in Drive as "Geopolitical-Macro Risk Desk (formula backup 2026-10-20)".

Differences from the old formulas: the default PD follows the paper (layer 1 hazard prior and layer 2 update) instead of the rating-based prior, so signals 15 and 19 (market complacency and overpricing) and the Risk Engine PD rows differ from the formula version; the scorecard, GPR, trade activation and dashboard logic reproduce the formulas exactly. Labels, inputs and the remaining helper formulas (header links, Rulebook direction, Assumptions weights, Market Feeds GOOGLEFINANCE quotes) were left in place.

### Sheets token

The commands that can write the workbook (`publish`, `garch`, `econ`, `audit`, `record`, `dsa`, `benchmark`) write only when you ask: pass `--write`, or give an explicit `--token-file PATH`. Without either they save the plan JSON and never look for a token, so a token in your environment or Keychain cannot trigger a live write by itself.

- `--write` takes the token from `$ECONQUEST_SHEETS_TOKEN`, then from the macOS Keychain item `econquest-sheets` (looked up with `security find-generic-password -s econquest-sheets -w`, only where `security` exists); if neither has one the command stops with an error.
- `--token-file PATH` reads the token from a file and wins over the environment variable and the Keychain.
- `--token VALUE` still works but is deprecated and prints a warning: the token shows in the process list and shell history.
- `--dry-run` saves the plan JSON and stops there: no token is looked up and Sheets is never called, even with `--write` or `--token-file`. Use it to preview a publish.

Store the token in the Keychain once (you are prompted for it, so it stays out of shell history):

```
security add-generic-password -s econquest-sheets -a "$USER" -w
```

The GUI hands the token you paste to the job in `ECONQUEST_SHEETS_TOKEN` and adds `--write`; it never puts the token on a command line or in the job log, and a job started without a token never gets `--write`.

## Where the program departs from the paper, and why

1. **Layer 1 coefficients.** The paper's table 7.1 coefficients in raw units do not reproduce its own case study (Debt/GDP 84.2%, ST FX debt/reserves 132.5%, reserves 1.8 months give a linear index of about +3.3, a 96% hazard, not 8.4%). The program therefore applies them to standardized predictors, keeping their signs and relative sizes, and fits a location and scale to the rating-implied PDs. `fit_firth` and `econquest fit-hazard --panel` replace this once a country-year event panel is available.
2. **LightGBM challenger.** Not installed here; the rating-implied PD is the monotone challenger. Dropping in a LightGBM model only changes `RatingChallenger`.
3. **HMM.** Implemented in numpy and fitted on request (`econquest hmm --series`). The live run uses the rule-based regime because the snapshot holds no monthly history; the transition matrix in `assumptions.json` is the paper's starting point.
4. **High-frequency signals.** The Text Stress Index is read from the Country Profile (zero in the snapshot) and the FX-vol skew is proxied by 3-month depreciation. Both are inputs the ingestion tier can fill.
5. **Reserves in months of imports** uses exports as the import proxy because imports are not in the snapshot.
6. **Stack.** The paper names C++/Rust, Kafka, TimescaleDB, PostgreSQL, Redis, FastAPI and Next.js. This program keeps the tier boundaries (ingestion, compute, persistence, presentation) so each can be swapped, but runs in one Python process with SQLite and the standard-library HTTP server. Layer 6 takes about 4 seconds for 100,000 paths.

## Data

`data/` is a snapshot of the workbook tabs Inputs, Rulebook, Adjustments, Country Profile (with the stress-depreciation helper), Portfolio VaR (book columns), Prediction Markets (contracts), Assumptions and Backtesting (sample history). Prediction-market prices are illustrative placeholders; `--live-markets` fetches Polymarket and Kalshi prices when the contracts carry a `slug` or `ticker` column and the network allows it.

## GUI (`python -m econquest gui`)

A local web app served from the standard library at http://127.0.0.1:8765 (nothing leaves your machine; the chart library is bundled). Tabs: Overview (VaR/ES tiles, loss distribution, PD by country, tail contributions, latent correlation, score-vs-PD bubble chart), Countries (probability components and scenario probabilities per country, sortable risk table), Portfolio (position tail contributions, EL vs tail scatter), Stress & backtests, Volatility (GARCH conditional-vol history, current vs forecast vs realised vol, DCC heatmaps, VaR table, options, GPR vol), Econometrics (forecast R², predictor importance, SVAR impulse responses, Kalman betas, all ten tables), Prediction markets (model vs market, edge), Events (event heat by country from the UCDP / GDELT feeds), Trade ideas (hit rate and P&L by quarter from `outputs/idea_log.csv`, illustrative, Tier 3; screenshot `docs/gui-trade-ideas.png`), Analyst workbench (pillar sliders and re-run of the Monte Carlo), Data & jobs (buttons that run fetch / run / garch / econ / publish with a live log, a data-freshness table, and "Save publish plan (no write)" for a dry-run publish without a token; `docs/gui-data-jobs.png`). `--port` and `--no-browser` are available.

## Live feeds (`python -m econquest fetch`)

`econquest/ingestion/feeds.py` replaces seed inputs with published data wherever the API Map marks an indicator as scripted. Each feed returns one tidy long table (`iso, series, period, value, source`); the transforms turn those into Inputs rows and Country Profile fields.

| Feed | Package / endpoint | Inputs rows | Country Profile |
|---|---|---|---|
| IMF World Economic Outlook | `imf-reader` (IMF SDMX 3.0 API), falling back to the `weo` package's spreadsheet download | 1.3 gross debt, 1.6 primary-balance gap, 1.7 five-year debt change, 2.8 current account, 5.5 inflation, 5.6 next-year growth, 5.12 growth volatility (15y, ex 2020-21), 5.14 GDP per head | |
| World Bank WDI, IDS, WGI | `wbgapi` (databases 2, 6, 3; most recent non-empty value) | 2.9 short-term debt / reserves, 2.10 external debt / exports, 3.4 and 3.5 governance (mean of rule of law, control of corruption, regulatory quality percentiles, and its 3-year change), 5.10 NPLs, 6.2 homicides, 6.6 youth unemployment | population, exports % GDP, reserves % GDP |
| BIS statistics | BIS SDMX REST (`stats.bis.org/api/v1/data`), flows WS_EER, WS_CREDIT_GAP, WS_CBPOL | 2.12 real effective exchange rate vs 10-year mean, 5.9 credit-to-GDP gap, 5.13 real policy rate (policy minus WEO inflation) | policy rate |
| BIS reference rates (`bis_xru`) | BIS SDMX REST, flow WS_XRU (daily USD exchange rates) | | fx 3-month change |
| ECB euro reference rates (`ecb_exr`) | ECB Data Portal SDMX REST, flow EXR (`data-api.ecb.europa.eu`), for currencies BIS has no series for; cross-checked against WS_XRU | | fx 3-month change (fallback) |
| no official free source | Yahoo Finance is not a desk feed (personal, non-commercial terms; EQ-A-0040), so nothing fills this field | | equity_vol (ETF realized volatility): left unserved |

The `bis-fetcher` package on PyPI scrapes BIS speeches, not statistics, so BIS series come straight from the BIS SDMX API with the standard library.

`fetch` writes `data/live/` (`live_inputs.csv`, `live_profile.csv`, `provenance.csv`, `diff_vs_seed.csv`, `raw_<feed>.csv`, `feeds.json`) and prints each feed's status and the largest moves against the seed. A feed that cannot be reached is reported as failed and the others still run. `--apply` copies the live values into `data/indicators.csv` and `data/countries.csv`; the indicators that stay Manual or File on the API Map are untouched. After `fetch --apply`, run `publish` so the workbook picks the new inputs up. Options: `--only weo,worldbank,bis,fx` (`fx` = `bis_xru` and `ecb_exr`; `bis` also pulls `bis_xru`; single feeds `bis_xru`, `ecb_exr`, `bis_cbs`, `worldbank_history`), `--year 2026`, `--weo-version October,2026`. `--only yahoo` is refused with one line before any request.

The feeds need outbound access to `api.imf.org`, `www.imf.org`, `api.worldbank.org`, `stats.bis.org` and `data-api.ecb.europa.eu`.

## Forecast record, quality gate and versioned runs

Three institutional-roadmap items landed on 2026-10-23 (`docs/institutional-roadmap.md`, items 1.5, 2.2 and 2.5).

**Daily forecast record (`python -m econquest record`).** Marks the FX, local-bond and equity book against the Market History prices for the last complete trading day, fits GARCH-DCC for the next day's one-day 99% VaR/ES, optionally runs the 12-month Monte Carlo (`--no-mc` to skip), and appends one row to `data/forecast_record.csv`. Each row carries the realised loss, the forecast that was made for that day on the previous trading day, the next-day forecast, regime, the number and notional of positions marked, and the code and data hashes. `--backfill 250 --step 21` builds the record backwards with GARCH-DCC refitted every 21 trading days on data to that date only (no look-ahead); rows already present are kept. `backtest` accepts the record file once it has 20 rows; the Basel traffic light is meaningful from 250. `publish` (or `record --write`) writes the record to the workbook's Forecast Record tab, newest first. `python -m econquest prices --sheet-json FILE` merges a saved `values.get` export of the Market History tab into `data/market_history/prices.csv` without rewriting any stored price (point in time). Eurobond and CDS positions have no daily price in the workbook and are not marked.

**Quality gate on live pulls.** `fetch` now runs every live cell through `quality_gate` before `--apply`: range (outside the rulebook thresholds by more than two spans, or outside the profile ranges), change (more than `--max-change` of the seed and more than a quarter of the threshold span), stale (World Bank series whose latest period is more than three years old) and a missing-country report. Held cells are written to `data/live/review.csv`, joined with the latest decision for each cell from the append-only ledger `data/live/review_ledger.csv` (columns decision, author, approver, self_approved, decided_utc), so rerunning `fetch` never loses a decision. `fetch --apply` skips a held cell until an `apply` decision for that vintage or live value is approved by a second person, and always skips cells decided `hold` or `reject`. Record decisions from the command line:

```
python3 -m econquest review decide --table Inputs --key 1.3 --country Argentina --decision reject --author Sam --note "bad print"
python3 -m econquest review decide --table Inputs --key 1.3 --country Argentina --decision apply --gate-status hold --live 5.2 --author Sam --approver Ana
python3 -m econquest review list [--country Argentina] [--table Inputs]
python3 -m econquest review list --pending   # cells the last fetch held that have no decision yet (start here after fetch)
python3 -m econquest review list --pending --vintage <id>   # the held cells of a saved vintage and their effective status
python3 -m econquest review approve "Country Profile" fx3m Brazil "Country Profile" fx3m Colombia --author Sam --approver Ana [--vintage <id>] [--note TEXT]
python3 -m econquest review apply [--vintage <id>] [--dry-run]
```

**Release held cells without refetching (`review approve`, `review apply`; HO-20261023-A-C-016).** A second `fetch --apply` pulls again, so a decision bound to the old vintage or live value no longer binds. Instead, `review approve TABLE KEY COUNTRY [TABLE KEY COUNTRY ...]` records one ledger row per cell against a saved vintage (default: the latest under `data/live/vintages/`), taking the vintage id, the live value and the gate status from that vintage, and `review apply` re-applies the same vintage to `indicators.csv` and `countries.csv` offline: its ok cells plus the held cells with an approved apply bound to it, never forced. Every cell is checked before any row is written (vintage hash against `vintages/index.csv`, each cell in the vintage's review, four-eyes over all of them), so a refusal records nothing. Applying a held cell needs `--approver OTHER` or `--self-approved`; `--decision hold|reject` keeps cells on seed and needs no approver. `review list --pending --vintage <id>` shows each held cell of that vintage with its `effective` status (`released` or `held`). `review apply` prints `Applied:` with the result, then the `released` and `still_held` cells, and warns when the vintage is not the latest (an older vintage also re-applies its ok cells over newer values); `--dry-run` prints the effective counts and writes nothing. Both are in the action log (one `review approve` row per cell).

Applying a held cell needs `--approver` (a different person) or `--self-approved` (single-operator mode, stored as self_approved=yes). `fetch --apply --force` applies held cells too, but only with `--author NAME` plus `--approver OTHER` or `--self-approved`; without them it stops before fetching anything. Each forced cell gets a ledger row (note `forced`). Every pull is also saved as a read-only vintage under `data/live/vintages/<id>/`; `fetch --apply` also freezes the full input set it produced to `data/live/snapshots/<id>-inputs/` so the run can be replayed.

**Replay a run (`run --vintage`, `run --as-of`).** `python -m econquest run --vintage <id or date>` loads the inputs frozen with that vintage (verified against their SHA-256 manifest; a tampered snapshot stops the run) instead of the current `data/` files. It cannot be combined with `--live-markets`. Settings files that are not frozen with the vintage (`assumptions.json`, `scenarios.json`, `limits.json`) are read as they are now; if any changed since the freeze the run prints a warning naming them, because it is then not an exact replay. `--as-of YYYY-MM-DD` fixes the model date (default: `as_of` in the settings, else today), so a rerun with the same inputs gives the same numbers on any calendar day; stress runs started with `--stress` use the same date.

**Debt sustainability (`python -m econquest dsa`).** Writes `outputs/dsa.csv`, `dsa_fan.csv`, `dsa_plan.json` and, on every run, `outputs/dsa_scorecard_feeds.csv`: the proposed values for indicators 1.1, 1.2 and 2.1 (`--keys` to choose), in the provenance.csv column layout. The DSA no longer changes anything under `data/`; the ingestion quality gate applies those feeds. `--apply` and `--force` are kept but only print that pointer. `--as-of YYYY-MM-DD` sets the base year and retrieved date (default today; `--year` overrides the base year); `--write` writes the Debt Sustainability tab.

**Robustness rules in the WEO transforms.** Two rules in `weo_transforms` guard against implausible year-t values in a WEO vintage: a *jump rule* (for the 2.8 current account and the nominal-GDP growth used in the 1.6 gap, a year-t value whose change from t-1 exceeds 3 standard deviations of the previous 15 annual changes, with at least 8 changes available, falls back to the t-1 value) and an *r-g cap* (`RG_CAP = 0.10`: the real-rate-minus-growth term in the 1.6 primary-balance gap is clamped to +/-10 points, so an inflation-driven nominal growth figure cannot turn the gap into a 20-point artefact). Every application is written to `data/live/transform_log.csv` (iso, series, year, value, fallback, rule), and the audit trail shows it in the `robustness_rule` column.

**Audit trail (`python -m econquest audit`).** `ingestion/audit.py` joins `indicators.csv`, `countries.csv`, the live tables, `provenance.csv`, `review.csv`, `transform_log.csv` and the API Map into one row per input cell (1,584 rows): table, key, indicator, country, value, origin (live feed; seed kept because the gate held the live value; seed because the feed returned nothing; seed estimate for manual indicators), source, series, transform, retrieved date, gate status and reason, review decision, seed and live values, robustness rule. It writes `data/audit_trail.csv` and `outputs/audit_plan.json`; with `--write` it also writes the Audit Trail tab of the workbook. The GUI's Data & jobs page shows the same table with a filter and has a "Write Audit Trail tab" button.

**Attesting hand-entered cells (`python -m econquest attest`).** `data/adjustments.csv`, `data/cds_quotes.csv` and `data/prediction_markets.csv` are typed in by hand, so the audit trail marks each of their cells attested or UNATTESTED, and `audit` prints how many are unattested. `econquest attest --file prediction_markets --author Ana --approver Sam [--note ...]` records in the review ledger that one person entered and a second checked the current content of every cell not yet attested (`--all` re-attests every cell; `--self-approved` instead of `--approver` is the single-operator mode, stored as self_approved=yes). An approver equal to the author is refused and nothing is written. Editing a cell makes it unattested again. `econquest attest --list [--file F]` prints the unattested cells (table, key, country, value). Loading never blocks on unattested cells.

**Versioned runs.** `econquest/versioning.py` stamps each run with the package version, a SHA-256 over the package's code, a hash of every data file and the library versions; `RunResult.summary["versions"]` and the SQLite run table carry them, and `python -m econquest runs` lists past runs with their hashes, plus the replayed vintage id and inputs hash (`vintage`, `inputs` columns) for runs that carry them. Two runs with the same code and data hashes saw the same inputs.

## Hazard recalibration on a real default panel (`python -m econquest fit-hazard`)

`validation/hazard_panel.py` replaces the paper's illustrative hazard coefficients with ones estimated on actual sovereign defaults. The default episodes come from `data/panel/sovereign_defaults.csv` (108 spells, 76 countries, 1980-2025, compiled from the Bank of Canada-Bank of England database and Reinhart-Rogoff; `--defaults <file>` also takes the CRAG workbook or the Valet DEBT_2026 CSV (2026 long layout), which `hazard_panel.load_events` converts through Team A's `import_crag`; an unmapped country name stops the build and lists every such name). Predictors are WEO history (debt/GDP, primary deficit, current account, real growth, log inflation) and, when World Bank history is present, short-term debt to reserves, reserves in months of imports and WGI political stability rescaled to the PITF range. A country-year is at risk when the country is not in default; the label is 1 when a default spell starts the following year. `fit_and_validate` runs a Firth logit on standardized predictors, then a rolling-origin out-of-sample test (fit on years before T, score year T) reporting AUC, Brier and log loss against the base rate and a calibration table by decile. `write_report` renders `docs/validation/hazard-fit-report.md`; `--apply --author NAME` proposes the coefficients under `layer1_fitted` in `assumptions.json` as an `econquest change` (Tier 1: it lands only after approve and apply), and adds the switch of `layer1.mode` to `fitted` only when `hazard_panel.gate_check` clears: out-of-sample AUC at least `--min-auc` (0.75), at least `--min-events` (30) default starts, and a Brier score strictly below the trailing base rate. The report and the console show each gate check with its figure. `--end` (the last row year) defaults to the last episode year minus 1, so the newest row is never labelled by default starts that cannot be observed yet. `--build-panel` uses the 18-country live vintage already in `data/live`; `--fetch` pulls every economy's history through `ingestion/panel_history.py` (run on a machine that reaches the APIs; the GUI has a button for it): every WEO release (point in time, `vintage` column) and each World Bank series as staged units with retries and a manifest under `data/panel/staging/<run id>/`. If a unit is still missing after the retries the command lists the missing units, exits 1 and leaves `weo_history.csv` and `worldbank_history.csv` untouched; `fit-hazard --build-panel --fetch --resume <run id>` then refetches only the missing units. `--weo-vintages 2007-10:2026-10` limits the releases. The run id, panel vintage and file hashes are recorded as the panel source in the report. The pilot on the 18-country vintage (9 events) is reported but did not clear the gate, so the engine still runs in paper mode until the full panel is fitted.

## CDS-implied PDs and relative value (`python -m econquest cds`)

`engine/cds.py` is a reduced-form CDS pricer: piecewise-constant hazard rates bootstrapped from par spreads (quarterly premiums, mid-period default, recovery R), survival and cumulative PD by horizon, the fair spread of any maturity off the curve, and `model_fair_spread`, which turns the engine's own 12-month PD into the spread it implies. `cds_table` reads `data/cds_quotes.csv` (country, date, tenor_y, spread_bp, recovery, source; latest date per tenor wins), gives each sovereign its CDS-implied 12-month and 5-year PD, the model-fair 5-year spread and a rich/cheap read; `eurobond_relative_value` applies it to Eurobond and CDS positions in the book. Outputs: `outputs/cds_implied.csv`, `outputs/cds_relative_value.csv`. The quotes file is analyst-maintained (for example read off worldgovernmentbonds.com or a broker run) until a licensed feed exists; settings in `assumptions.json` under `cds`.

## Market data snapshots (`python -m econquest market`)

Team A's `econquest/ingestion/market/` keeps point-in-time market snapshots (CDS, curves, EMBI, FX) under `data/live/market/`; the runbook is `docs/runbooks/A-market-data.md`. No vendor API is called.

```
python3 -m econquest market import --init-map                      # once: data/live/market/ticker_map.csv from the template; verify each row
python3 -m econquest market import --profile bloomberg --licence "<exact licence>" ~/Downloads/cds.csv   # or --profile lseg; --map PATH
python3 -m econquest market enter --author NAME --approver OTHER quotes.csv   # hand-typed quotes, four-eyes; or --author NAME --self-approved
python3 -m econquest market gate [--as-of YYYY-MM-DD] [--strict]   # stale/range/curve/CIP/jump/basis vs the previous snapshot; outputs/market_gate.csv; --strict exits 1 on holds
python3 -m econquest market cds-quotes [--as-of YYYY-MM-DD] [--dry-run]   # data/cds_quotes.csv (atomic) from the latest CDS quotes, held series left out
```

`enter` takes a CSV with `asof, instrument, iso, currency, tenor_y, field, value` (optional `unit, doc_clause, vendor_ticker`); every row is attested in the review ledger and saved as a snapshot. `--self-approved` follows `fetch --self-approved` and `attest`: it is recorded as `self_approved=yes` and needs no `EXC-nnn` (that is required only for `change approve` and the compliance self-sign). `cds-quotes` refuses to write a file with no rows. `import`, `enter` and `cds-quotes` are recorded in the operator action log; the GUI does not offer `market`.

Licensed vendor APIs (`python -m econquest vendor status|test|pull`, Bloomberg BLPAPI / LSEG Data Library) are a **paid roadmap feature, off by default**: `status` shows why each adapter is not usable (package `econquest[bloomberg]` / `econquest[lseg]`, licence entitlement, expiry) without opening a session; `test <bloomberg|lseg> --ticker T [--as-of D]` is a dry run that saves nothing; `pull <bloomberg|lseg> --ticker T [--field F] [--as-of D | --start D --end D] [--no-export]` saves a snapshot, gates it and appends passing CDS rows to `data/market/cds_snapshots.csv`. Without a licence, or on any request or session error, `test` and `pull` exit 2 with the reason. Credentials come only from the environment or the OS keychain, never from arguments; `pull` is recorded in the action log; the GUI does not offer `vendor`. Runbook: `docs/runbooks/A-licensed-vendors.md`.

## Model governance (`docs/governance/`, `python -m econquest governance`)

The governance pack is what a model-risk reviewer asks for first: `model-inventory.md` (16 components with purpose, inputs, outputs, code, owner, tier, calibration status, last validation document, known limitations and validation frequency), `model-risk-policy.md` (tiering, roles, what counts as a model change, approval path, use restrictions in force, for example nothing quoted externally while layer 1 is in paper mode and 110 inputs are seed estimates), `change-control.md` (release procedure and sign-off checklist), `revalidation-routine.md` (quarterly and event-driven revalidation with the thresholds that trigger recalibration: out-of-sample AUC below 0.70, Brier worse than the base rate, Basel yellow or red, benchmark Brier worse than the rating-implied PD), `issues-log.md` (GOV-001 onwards, seeded from every validation document's limitations) and `change-log.md`, generated by `validation/governance.py` from the run archive: one row per run with code hash, data hash, headline metrics and flags for code, data and settings changes with a short diff of the settings keys that moved. `data/limits.json` and `data/scenarios.json` are part of the data hash, so a limit or scenario edit shows as a data change.

Replication (EQ-B-0051): `python -m econquest replicate [--quick] [--only release,docs,backtest,hazard,scorecard,garch] [--out DIR]` recomputes every number in the release note and the key validation-document numbers from the stored inputs in `--data` and writes `replication.csv` and `replication.md` to `<out>/replication` (default `outputs/replication`); it exits 1 on any FAIL. It is a pass-through to `python -m econquest.validation.replicate`.

Archive replication (EQ-B-0058, HO-20261024-B-C-003): `python -m econquest replicate-archive [--out DIR] [--archive DIR] [--db PATH|none] [--zip PATH|none] [--rerun]` checks every number in the release notes 0.1.1-0.1.5 against the archived runs (read-only), the kept release zip and, with `--rerun`, a rerun of the 0.1.5 zip's engine, and writes `archive-replication.csv` and `archive-replication.md` to `<out>/replication-archive`; it exits 1 on a mismatch without a findings-register row, or a cited run missing. It is a pass-through to `python -m econquest.validation.replicate_archive`.

Target-state scorecard (EQ-C-0061): `python -m econquest targets [--tests PYTEST_OUTPUT] [--dest DIR]` re-scores the plan's target-state table and gate criteria (coverage, data, models, track record, research, controls) from evidence: the live-cell share (`missing_cell_report`), the data-quality, market and hazard gates, the forecast-record length and Basel zone, the idea log, published editorial items, open security and validation findings, the replication result and the test-suite result (a saved pytest output, else the latest release note). Each row gives target, current, met (`yes`, `no`, `waiting on Sam` for licence-dependent rows, `no evidence` when the file is missing) and the evidence path; it writes `targets.md` and `targets.csv` to `<out>/targets`. Nothing is scored by hand, and nothing in `data/` is written. `econquest.presentation.targets.target_scorecard()` is the same scorecard as a function.

Evidence clock (EQ-C-0068): `python -m econquest evidence-clock [--as-of YYYY-MM-DD] [--write]` prints Team B's calendar-gated evidence monitor: for the 250-day VaR forecast record, 12-month benchmark scoring and four quarters of trade-idea marks, the progress against the requirement, the earliest date the test can run, the days to go and the status (accumulating, testable or overdue). Only data stored on or before `--as-of` counts (default: the settings as_of, else today); `--write` also saves `<out>/evidence_monitor.csv` and `.md`. It is read-only and shown on the GUI's Stress & backtests tab as the Evidence clock card ([screenshot](docs/gui-evidence-clock.png)). It is not `econquest evidence`, which builds the validator's evidence bundle.

## Scenario library and reverse stress (`python -m econquest stress`, `reverse-stress`)

Scenarios live in `data/scenarios.json` as lists of shocks (add, multiply, set or notch a countries column; shift an indicator row; add a trigger add-on; set a portfolio column; patch a dotted settings key with `*` wildcards and caps), each with an optional `where` filter on any countries.csv column, so an analyst adds or edits a scenario without touching code. The paper's A, B and C are in the file and reproduce the old code exactly (tested); ASIA97, GFC08, TAPER13, COVID20 and FED22 are approximate reconstructions of those episodes' market moves, and DOWNGRADE cuts every rating. Every scenario takes a severity scale. `engine/stress.py::reverse_stress` bisects that scale, with the same seed and path count on every run, to the point where a book limit in `data/limits.json` breaks; `single_factor_reverse` does the same for spreads, EM currencies, hard-currency LGD, the PD multiplier, the global copula loading and rating notches. On the sample book the VaR99 limit of 95 $mm breaks at 16 percent of the 2008 moves, 25 percent of 1997-98, +375 bp of spreads or 16 percent EM depreciation; LGD, downgrades and the commodity scenario cannot breach it alone. Outputs: `outputs/scenario_library.csv`, `outputs/reverse_stress.json` and `.csv`; see docs/validation/stress-scenarios.md.

## Daily risk report and alerts (`python -m econquest report`, `alerts`)

`presentation/report.py` builds a self-contained HTML report (inline CSS and SVG, no external assets, prints cleanly) and a Markdown twin from the latest archived run: headline VaR 95/99, ES 95/97.5/99, liquidity-adjusted VaR and ES and expected loss, each against the previous run; the loss distribution with VaR99 and ES99 marked; regime, signal and trade-activation changes; the country table sorted by default PD; positions with the top five tail contributors; backtest status from the forecast record (Kupiec, Christoffersen, Acerbi-Szekely, Basel zone); data issues (feed status, quality-gate holds, stale inputs from the audit trail); and the alerts table. Output goes to `outputs/reports/risk-report-<date>.html`, `.md` and `latest.html`. `validation/alerts.py` detects regime flips (country and global), default-PD moves above `alerts.pd_change_pp`, PD level crossings at `alerts.pd_level`, signal crossings at `signals.threshold`, trades starting or stopping, VaR99 or ES99 moves above `alerts.var_change_pct`, backtest failures and Basel yellow or red zones, quality-gate holds, missing and failed feeds; severities info, warning, critical. `deliver_alerts` writes `outputs/alerts.json`, prints the digest and, when configured, posts to `ECONQUEST_ALERT_WEBHOOK` (Slack or Teams incoming webhook) and emails over SMTP (`ECONQUEST_SMTP_HOST`, `_PORT`, `_USER`, `_PASSWORD`, `_FROM`, `_TO`), the report HTML as the mail body. `econquest run && econquest report && econquest benchmark` is the whole morning job; the GUI has buttons for report and alerts. Monte Carlo error (EQ-C-0055): the report, the weekly monitor, the dashboard and the last line of `run` show the 95% Monte Carlo band (batch means, engine VF-004) next to VaR99, ES99 and L-VaR99, and a Book limits table (data/limits.json, point-estimate verdicts as `econquest limits`) that marks a verdict *within MC error* when the band contains the warning level or the limit (on 2026-10-23: L-VaR99 79.63, band 78.82-80.45, warning 80). `garch --as-of DATE` fits no price after DATE (`--vintage` defaults it to the vintage date), and `run --backtest` dates its synthetic history by the run's as-of.

## Research products (`notes`, `briefs`, `monitor`) and editorial review (`editorial`)

`python -m econquest notes [--country Argentina ...] [--pdf]` writes one self-contained HTML country note per country to `outputs/notes/` (pillars, PD against benchmarks, DSA fan, stress impact, regime, signals and trade view, that country's input caveats, run stamps and the disclaimer). `python -m econquest briefs [--scenario ...] [--pdf]` writes one brief per stress scenario to `outputs/briefs/` (narrative and channels, book impact against base, top contributors, reverse-stress distance, candidate hedges). `--pdf` prints through headless Chrome or Chromium when one is found (`--chrome PATH` or `$ECONQUEST_CHROME`); without one, the HTML is still written. `python -m econquest monitor` is the weekly risk monitor.

Every product goes from draft to reviewed to published, recorded in `outputs/editorial/ledger.jsonl`, a hash-chained log whose rows are never rewritten:
```
econquest notes --country Argentina                                                       # writes outputs/notes/country-note-argentina-<as_of>.html
econquest editorial draft --kind country_note --file outputs/notes/country-note-argentina-2026-10-23.html --author "Sam"
econquest editorial review ed-20261023-0001 --reviewer "Alex" --note "numbers checked"   # single operator: --reviewer Sam --self-reviewed
econquest editorial checklist ed-20261023-0001 --show                                     # compliance checklist; exit 1 if incomplete
econquest editorial publish ed-20261023-0001 --publisher "Sam"
econquest editorial list --state published
econquest editorial verify
```
- **draft** records each file's SHA-256 and the run stamps (run_id, as_of, data hash, run hash) of the latest archived run, or of `--run-id`.
- **review** needs a reviewer other than the author. A single operator can review their own work only with `--self-reviewed`, which is recorded.
- **publish** works only on a reviewed item whose files have not changed since review, and every HTML/Markdown file must carry the standard disclaimer. It copies the files read-only to `outputs/published/<kind>/<date>-<id>/` with a `manifest.json`. An item publishes once; `correct <id>` registers a fixed version as a new draft, and `withdraw <id>` records a withdrawal without deleting anything.
- **verify** checks the ledger chain and every published file against its manifest, and exits 1 on any problem.
- **checklist** (EQ-C-0036): publish refuses until the compliance checklist is complete. The automatic items (disclaimer, a `## Sources` section naming a source and `As of <run as_of>`, an input-caveats block for the current `--data`) are rerun at review and publish; the manual ones are recorded with `checklist`: the author's `--conflicts "no conflicts"` (or the text), the reviewer's `--acknowledge 6.2` for each flagged use restriction (repeat it for every restriction `checklist <id> --show` lists; a seed-data country note usually flags 6.1, 6.2 and 6.3, and a call that leaves one out records nothing), and `--compliance-approve` by someone other than the author. Single-operator flow: `econquest editorial review <id> --reviewer Sam --self-reviewed`, then `econquest editorial checklist <id> --by Sam --conflicts "no conflicts" --acknowledge 6.2 --compliance-approve --self-signed --exc EXC-nnn` (EXC-nnn is a placeholder: the self-sign needs its own exception id from `docs/governance/issues-log.md`, as `change approve --self-approved`, and is recorded with it as an exception; EQ-C-0041), then `publish`. Who may sign off is `data/compliance.json` (`role`, `approvers`, `allow_self_sign`; EQ-C-0040), changed only through `econquest change propose compliance.json --set /allow_self_sign=false ...`, approve, apply: sign-off is refused after a hand edit (drift). The old `outputs/editorial/compliance.json` is no longer read; while it exists with a different content sign-off is refused and the message says how to move it with `econquest change`.
- **distribute** (EQ-C-0045): `editorial publish` queues the item (nothing is sent). `econquest distribute send` is a dry run that prints who would get what; `econquest distribute send --send` emails each subscriber of that product kind (`data/distribution.json`: `subscribers` per kind, `archive_base_url`, `subject_prefix`) one message with a link into `outputs/published/` and the file sha256s, never an attachment. Only published, verified items go out; withdrawn or tampered ones are skipped; addresses or header text with a line break are refused. Every attempt is a row of the hash-chained `outputs/store/deliveries.jsonl`; `econquest distribute status` shows queue, failures and delivery latency p50/p95 (products from publish time, health alerts from the missed deadline or job time), `distribute verify` checks the chain. **Turning sending on (Sam, on the Mac only):** put `ECONQUEST_SMTP_HOST`, `_PORT`, `_USER`, `_FROM` in `~/econquest/.ops.env` (`chmod 600`; scheduled jobs read it, in a terminal load it with `set -a; . ~/econquest/.ops.env; set +a`), store the password with `security add-generic-password -s econquest-smtp -a "$USER" -w` (or `$ECONQUEST_SMTP_PASSWORD`), add the subscriber addresses to `data/distribution.json`, check `econquest distribute send` (dry run), then run `econquest distribute send --send --actor Sam`. `--send` withholds (and prints) messages to any address never delivered to before until it is confirmed once: check it against the subscriber request, then send again with `--confirm-new ADDR[,ADDR]` (or `--confirm-new all-listed`, which confirms and prints every new listed address; EQ-C-0051). Runbook: `team/runbooks/C-distribute.md`.

## Changing assumptions and limits (`python -m econquest change`)

`data/assumptions.json` and `data/limits.json` change only through `econquest change`, never by hand (procedure: `docs/governance/change-control.md`).
1. Once per file, record the current file as the starting point: `econquest change baseline limits.json --actor Sam --reason "adopt change approvals"` (same for `assumptions.json`).
2. `econquest change propose limits.json --set /book/var99_mm=90 --author Sam --reason "..."` records the change in `data/approvals/` without touching the file. The tier (limit, Tier 1 or 2, run setting) is inferred. Values are JSON, so quote strings: `--set '/layer1/mode="fitted"'`.
3. `econquest change approve <id> --approver Alice`. In single-operator mode: `--self-approved --exc EXC-nnn`, the exception entry in `docs/governance/issues-log.md`.
4. `econquest change apply <id>` writes the approved file atomically, and refuses if the file changed since the proposal.
5. `econquest change list | show <id> | reject <id> --by NAME`. `econquest change verify` checks the hash-chained log (`data/approvals/log.jsonl`) and reports hand edits ("drift"); it exits 1 on drift or a broken chain.

`fit-hazard --apply` now proposes its coefficients (and the switch to `layer1.mode = "fitted"`) as a change and needs `--author`; nothing lands until the change is approved and applied.

## Run gate for unattested hand-entered cells (EQ-C-0034)

Hand-entered files (`adjustments.csv`, `cds_quotes.csv`, `prediction_markets.csv`) are attested with `econquest attest`. Before a command runs, the run gate counts the cells whose current content is not attested:
- **warn** (default for `run`, `stress`, `record`, `report`, `monitor`, `notes`, `briefs`, `cds`, `arbitrage`, and the writer commands when they only save a plan): prints one line on stderr (`warning: N hand-entered cell(s) not attested; run continues (run gate 'warn'). List and fix: econquest attest --list`), then runs.
- **block** (default for every Sheets write: `publish --write` and `benchmark`, `record`, `audit`, `garch`, `econ`, `dsa` with `--write` or `--token-file`): exits 3 before any token lookup or Sheets call, and prints the count per file, the `attest` commands and the policy key. `--dry-run` never blocks.
- `--allow-unattested` proceeds once; the override is recorded in the action log with the counts.

Fix: `econquest attest --list`, then `econquest attest --file adjustments --author NAME --approver OTHER` (or `--self-approved`). The defaults are `RUN_GATE_DEFAULT` in `econquest/cli.py` (recommended; Sam has not chosen yet). Change them in `<home>/ops.json` (`"run_gate": "warn"`, or `{"publish:write": "warn", "run": "block"}`) or `$ECONQUEST_RUN_GATE` (`off`, `warn`, `block`, or `run=block,sheets_write=warn`); the environment wins. Values: `warn`, `block`, `off`; `sheets_write` covers every write and `<cmd>:write` overrides it for one command.

## Operator action log (`python -m econquest log`, EQ-C-0035)

Operator actions are appended to `outputs/store/actions.jsonl`, hash-chained like the change log (`seq`, `prev_hash`, `row_hash`, plus `actions.head.json`), and included in the nightly backup of `outputs/store`: `review decide`, `review approve` (one row per cell), `review apply`, `attest`, `change propose|approve|reject|apply|baseline`, every `editorial` command, every Sheets write (`publish --write` and the other writers), `fetch --apply/--force`, `fit-hazard --apply`, `schedule install|uninstall` and run-gate overrides. Each row has the UTC time, the command, its options (the token and any secret-named option are never written), the actor (from `--author/--reviewer/--publisher/--by/--approver/--actor`, else `$USER`), the outcome and exit code (failures too), and the code version. `econquest log verify` checks the chain (exit 1 on an edit, deletion or truncation); `econquest log tail [-n 20] [--json]` prints the last rows. The log sits under `--out`, or beside `--data` when only that is given; `$ECONQUEST_ACTION_LOG` sets another file.

## Republish preview (`python -m econquest publish-preview`)

Before `publish --write`, compare the saved plan with what the workbook holds now. `econquest publish-preview --urls` prints the `values:batchGet` URLs for the plan's ranges; fetch them with your token and save the JSON, then `econquest publish-preview --baseline live.json` writes `outputs/preview/` (HTML and CSV): changed cells largest first, sign flips and cleared cells highlighted, ranges added or removed. A previous `publish_plan.json` also works as the baseline.

## Scheduled jobs, health checks and backups (macOS)

`econquest schedule install` writes launchd jobs to `~/Library/LaunchAgents/com.econquest.<job>.plist`: record (weekdays 18:20), morning run and report (weekdays 07:00), weekly monitor (Mondays 07:45), nightly backup (23:30) and a health check every 15 minutes. Times are New York time; if the Mac is on another zone they are converted, and you should reinstall after DST changes. Change times with `--record-time 18:20` etc. or `~/econquest/ops.json`. The command prints the `launchctl bootstrap gui/$UID ...` lines (or add `--load`). `econquest schedule show` lists jobs with their last exit code; `econquest schedule uninstall` removes them. Keep the Mac awake at those times (for example `sudo pmset repeat wakeorpoweron MTWRF 06:55:00`). Job logs: `~/econquest/outputs/logs/`.

`econquest health` flags a missed run (no result 15 minutes after its deadline, business days), live inputs older than 7 days (`--stale-days`), a failed feed and a failed or hung job, writes `outputs/health.json` and sends each new alert once to the webhook or email. For scheduled jobs put `ECONQUEST_ALERT_WEBHOOK` / `ECONQUEST_SMTP_*` in `~/econquest/.ops.env` and `chmod 600` it.

`econquest backup --verify` writes `data/` (vintages, snapshots, review ledger, forecast record) and the run store to `$ECONQUEST_BACKUP_DEST` (default `~/econquest-backups/nightly/<UTC date>/`) as a tar.gz with a SHA-256 manifest, keeping 14 daily and 8 weekly copies. Set `ECONQUEST_BACKUP_DEST` to an iCloud Drive, Dropbox or external-drive folder before `schedule install` for an off-machine copy. `econquest backup --verify-only <file>` checks a backup; `econquest restore-drill` restores the latest one into a temp folder, checks every hash, loads the data and the run store, and reports the time (`outputs/restore_drill.json`). Restoring into the live folder stays a manual step (`docs/runbooks/A-restore.md`).

## Limits and pre-trade check (`python -m econquest limits`)

`engine/limits.py` grades the book against `data/limits.json`: book VaR99, ES99, liquidity-adjusted VaR99 and expected loss; country gross notional (default plus per-name overrides, for example Venezuela 10 and Zimbabwe 5 $mm) and share of the 99 percent tail; asset-class and issuer (country by asset class) notional; largest-position concentration; and the share of notional in Crisis-regime countries. Each row carries value, limit, utilisation and a status of pass, warning (above `warning_level`, 0.8) or breach. `pretrade_check` appends a proposed position (`"country,asset_class,direction,notional_mm[,duration_yrs]"`) to the book without touching the data on disk, reruns the pipeline before and after at the same seed and path count, and reports marginal VaR99 and ES99 on common random numbers (the after run's paths with the new position removed, so Sobol reshuffling does not leak into the marginal), the standalone tail contribution and a verdict: refuse when any limit is breached after the trade, flag when any is at warning, accept otherwise, with the reasons listed. Outputs: `outputs/limits.csv` and `outputs/pretrade.json`; the GUI's Pre-trade check card runs it and shows the verdict and the limits table. On the sample book all 71 rows pass; a 10 $mm six-year Argentina Eurobond is flagged (ES99 and L-VaR99 at 80 percent of limit, Eurobond class at 80 percent), a 100 $mm one is refused.

## PD benchmarks (`python -m econquest benchmark`)

`validation/benchmarks.py` keeps a standing comparison of the engine's 12-month PD against the other probabilities the desk can see for the same sovereign: the layer-1 hazard alone, the rating-implied PD, the spread-implied PD, the CDS-implied PD from `engine/cds.py` when quotes exist, and the prediction-market probability when a contract is mapped. Each run appends a dated snapshot per country to `data/benchmarks.csv` (a second run on the same day replaces that day's rows). `outcomes` labels every snapshot at least 12 months old with whether a default spell started within the following year, using `data/panel/sovereign_defaults.csv`, and `score_sources` reports Brier score, log loss and AUC per source against the base rate, so after a year of daily records the table says which source predicted best. `disagreement_table` ranks today's countries by the largest gap between model and rating, spread or market and gives each a one-line read. The PD Benchmarks tab of the workbook carries the current snapshot and the scoring block; `--write` writes it. Scoring stays empty until the first snapshot turns 12 months old.

**Scoring as of the snapshot date.** Each `benchmark` run also writes `outputs/benchmark_scores.csv` (one row per horizon and source: Brier, log loss, base-rate Brier, Brier skill, AUC and a paired comparison with the model) and `outputs/benchmark_calibration.csv`, scored only on snapshots that have matured by the run's `--as-of` date (default today), never by the wall clock, so a rerun with the same `--as-of` gives the same scores. The console prints one status line per horizon, for example `12m not yet scorable, first maturity 2027-10-23`. `--horizons 12m,6m,3m` adds sub-annual horizons; they report "not scorable" until the default-episode table has a `start_date` column.

## GARCH volatility layer (`python -m econquest garch`)

`econquest/engine/garch.py` adds the econometric volatility layer the desk needs for market risk, sizing and option checks. It is self-contained (numpy and scipy only).

| Piece | What it does | Where it shows |
|---|---|---|
| GARCH(1,1) with Student-t innovations | Maximum likelihood with variance targeting (omega = sample variance x (1 - alpha - beta)), persistence bounded below 0.9995, several starts. Gives conditional variance, multi-step variance forecasts, half-life, long-run vol, and Student-t VaR/ES at 99% for 1 and 10 days | GARCH tab, Table A (one row per FX pair and country ETF) |
| Diagnostics | Engle ARCH-LM on returns (is GARCH warranted) and on standardized residuals, Ljung-Box on squared standardized residuals (is the fit adequate) | Table A columns R-T |
| DCC(1,1) (Engle 2002) | Correlation targeting, two-stage likelihood on the standardized residuals; one block across the FX pairs and one across the ETFs; one-step-ahead correlation forecast | Tables B and C |
| GARCH-DCC portfolio VaR | Book exposures (FX and unhedged local bonds carry the currency; equity uses the ETF proxy) x forecast vols x DCC correlation; 1-day and 10-day VaR99 with the median fitted df, undiversified comparison | Table D, Dashboard A4 |
| Vol targeting | Scalar = target vol (assumptions.json `garch.target_vol`, 10%) / 21-day forecast vol, capped at `scalar_cap` (2x): the position multiplier that holds constant volatility | Table A column Z |
| Options | Black-Scholes fair value of an ATM 63-day put per ETF at the GARCH forecast vol and at 60-day realized vol; market quotes (CSV via `--quotes`, or typed into GARCH column K and exported) give implied vol and the GARCH-minus-implied spread | Table E |
| Macro volatility | GARCH(1,1) on monthly log changes of the GPR index and its country series: conditional vs long-run volatility of geopolitical news flow | Table F |

Price data: the workbook's Market History tab holds three years of daily Google Finance prices (`GOOGLEFINANCE()` for 17 `USDxxx` pairs and 12 country ETFs plus EEM). Export it to `data/market_history/prices.csv` (date index, one column per ticker; extra CSVs in that folder are merged). One-day quote reversals beyond 12 robust standard deviations are removed before fitting (`clean_bad_ticks`), and pegged pairs with mostly unchanged quotes have the zero-return days dropped. Outputs land in `outputs/garch/` (series, dcc_fx, dcc_eq, options, macro CSVs and `garch_plan.json`); `publish` appends the GARCH tab to its plan when price history exists (`--no-garch` to skip).

## Econometrics toolkit (`python -m econquest econ`)

`econquest/engine/econometrics.py` runs on the same Market History prices (and the GPR series) and writes the Econometrics tab. Every series follows one workflow: stationarity tests (ADF with BIC lag choice, KPSS), an AR mean chosen by BIC plus a GARCH(1,1)-t variance baseline, residual checks (Ljung-Box, ARCH-LM on the AR residuals and on the standardized GARCH residuals), an out-of-sample race of one-day-ahead variance forecasts over the last 250 days (GARCH refit every 50 days, EWMA 0.94, rolling 60-day, constant; QLIKE and MSE; Diebold-Mariano with HAC variance), Newey-West standard errors in every regression, and Benjamini-Hochberg false-discovery control across the series (Bonferroni shown alongside).

| Question | Tools | Table |
|---|---|---|
| Long-run relationship for pairs trading | Engle-Granger (ADF on the cointegrating residual, EG critical values), Johansen trace test (constant case, Osterwald-Lenum critical values), VECM adjustment speeds, spread half-life and z-score. Only pairs whose two log prices are unit-root processes are tested | 2 |
| How a shock propagates | VAR with BIC lag choice, Cholesky-identified structural shocks (EEM first), impulse responses and forecast-error variance decomposition | 3 |
| Time-varying beta or hedge ratio | Kalman filter with a random-walk beta; signal-to-noise ratio by maximum likelihood on a grid capped at 0.01 | 4 |
| Regime shifts | Two-state Gaussian Markov-switching model (EM, filtered probability of the turbulent state), threshold AR(1) on the lagged absolute return with a Sup-F statistic | 5 |
| Risk premia | Fama-MacBeth two-pass on weekly ETF excess returns (EM market and USD/EM FX factors plus the Randori composite as a characteristic; HAC t-stats) and a two-step GMM estimate with the Hansen J test | 6a, 6b |
| Extreme-loss sizing | Generalized Pareto peaks over the 90th percentile of the GARCH-standardized losses: shape, tail index, EVT vs Student-t VaR at 99% and 99.9%, EVT expected shortfall | 7 |
| Joint tail risk | Student-t copula (Kendall-tau rho, df by profile likelihood) and Clayton copula (MLE) on pseudo-observations of standardized losses; lower-tail dependence, empirical tail dependence, AIC comparison | 8 |
| Forecasting with many predictors | Panel of all series predicting log realized vol over the next 21 days from 12 predictors: naive, GARCH-only, OLS, ridge (CV), lasso (CV), PCA factor regression, random forest; in-sample vs out-of-sample R-squared, lasso coefficients and forest importances | 9, 9b |
| Event impact | Event study of each country ETF around one-day currency depreciations beyond three robust SDs: market-model abnormal returns on EEM, CAR over days 0, 0-1, 0-5, 0-20 with t-statistics | 10 |

P-values for ADF, KPSS, Engle-Granger and Johansen are interpolated from asymptotic tables and are approximate. Outputs land in `outputs/econometrics/` (one CSV per table plus `econ_plan.json`); `publish` appends the tab when price history exists (`--no-econ` to skip). The run takes a few minutes because of the rolling GARCH refits and the random forest.
