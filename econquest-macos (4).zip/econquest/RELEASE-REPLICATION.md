# Independent replication (EQ-B-0051)

- Mode: full (stated path counts)
- as_of 2026-10-23; data `/tmp/claude-0/-home-claude-econquest-main/29ffefee-27c5-5e47-887f-7de2dfc27f67/scratchpad/rel020/src/data`; groups release, docs, backtest, hazard, scorecard, garch; runtime 146 s
- Environment: python 3.13.17, numpy 2.5.3, pandas 2.3.3
- Recomputed from public functions and stored inputs; no archived run or output file is read.
- Status counts: INFO 2, PASS 121
- STALE checks: none

| id | status | quantity | reported | recomputed | tol | source | note |
|---|---|---|---|---|---|---|---|
| R01 | PASS | base var99_mm ($mm), 100,000 requested, as_of 2026-10-23 | 74.35 | 74.3513 | 0.07435 | docs/governance/releases/0.1.4-2026-10-23.md Effect table, 0.1.4 base |  |
| R02 | PASS | base es99_mm ($mm), 100,000 requested, as_of 2026-10-23 | 96.48 | 96.4797 | 0.09648 | docs/governance/releases/0.1.4-2026-10-23.md Effect table, 0.1.4 base |  |
| R03 | PASS | base expected_loss_mm ($mm), 100,000 requested, as_of 2026-10-23 | 0.45 | 0.453153 | 0.005 | docs/governance/releases/0.1.4-2026-10-23.md Effect table, 0.1.4 base |  |
| R04 | PASS | base lvar99_mm ($mm), 100,000 requested, as_of 2026-10-23 | 79.63 | 79.6328 | 0.07963 | docs/governance/releases/0.1.4-2026-10-23.md Effect table, 0.1.4 base |  |
| R05 | PASS | Sobol paths simulated for 100,000 requested | 131072 | 131072 | 0.5 | docs/governance/releases/0.1.4-2026-10-23.md Effect |  |
| R06 | PASS | book es99_mm as percent of data/limits.json limit | 84 | 83.8954 | 0.5 | docs/governance/releases/0.1.4-2026-10-23.md Limits |  |
| R07 | PASS | book var99_mm as percent of data/limits.json limit | 78 | 78.2645 | 0.5 | docs/governance/releases/0.1.4-2026-10-23.md Limits |  |
| R08 | PASS | book lvar99_mm as percent of data/limits.json limit | 80 | 79.6328 | 0.5 | docs/governance/releases/0.1.4-2026-10-23.md Limits |  |
| R09 | PASS | stress A ES99 ($mm) | 155.5 | 155.484 | 0.1555 | docs/governance/releases/0.1.4-2026-10-23.md Stress runs |  |
| R10 | PASS | stress A ES99 change vs base (%) | 61.2 | 61.1573 | 0.0612 | docs/governance/releases/0.1.4-2026-10-23.md Stress runs |  |
| R11 | PASS | stress B ES99 ($mm) | 102.9 | 102.905 | 0.1029 | docs/governance/releases/0.1.4-2026-10-23.md Stress runs |  |
| R12 | PASS | stress B ES99 change vs base (%) | 6.7 | 6.6594 | 0.05 | docs/governance/releases/0.1.4-2026-10-23.md Stress runs |  |
| R13 | PASS | stress C ES99 ($mm) | 114.9 | 114.864 | 0.1149 | docs/governance/releases/0.1.4-2026-10-23.md Stress runs |  |
| R14 | PASS | stress C ES99 change vs base (%) | 19.1 | 19.0555 | 0.05 | docs/governance/releases/0.1.4-2026-10-23.md Stress runs |  |
| R15 | PASS | stress DOWNGRADE ES99 ($mm) | 101.7 | 101.721 | 0.1017 | docs/governance/releases/0.1.4-2026-10-23.md Stress runs |  |
| R16 | PASS | stress DOWNGRADE ES99 change vs base (%) | 5.4 | 5.4324 | 0.05 | docs/governance/releases/0.1.4-2026-10-23.md Stress runs |  |
| R17 | PASS | stress TAIWAN ES99 ($mm) | 165.1 | 165.106 | 0.1651 | docs/governance/releases/0.1.4-2026-10-23.md Stress runs |  |
| R18 | PASS | stress TAIWAN ES99 change vs base (%) | 71.1 | 71.13 | 0.0711 | docs/governance/releases/0.1.4-2026-10-23.md Stress runs |  |
| R19 | PASS | stress HORMUZ ES99 ($mm) | 167.1 | 167.073 | 0.1671 | docs/governance/releases/0.1.4-2026-10-23.md Stress runs |  |
| R20 | PASS | stress HORMUZ ES99 change vs base (%) | 73.2 | 73.1689 | 0.0732 | docs/governance/releases/0.1.4-2026-10-23.md Stress runs |  |
| R21 | PASS | stress TARIFF ES99 ($mm) | 154.8 | 154.839 | 0.1548 | docs/governance/releases/0.1.4-2026-10-23.md Stress runs |  |
| R22 | PASS | stress TARIFF ES99 change vs base (%) | 60.5 | 60.4884 | 0.0605 | docs/governance/releases/0.1.4-2026-10-23.md Stress runs |  |
| R23 | PASS | stress CHINA_HL ES99 ($mm) | 165.2 | 165.214 | 0.1652 | docs/governance/releases/0.1.4-2026-10-23.md Stress runs |  |
| R24 | PASS | stress CHINA_HL ES99 change vs base (%) | 71.2 | 71.242 | 0.0712 | docs/governance/releases/0.1.4-2026-10-23.md Stress runs |  |
| R25 | PASS | estimated Calm global loading Singapore | 0.81 | 0.812154 | 0.005 | docs/governance/releases/0.1.4-2026-10-23.md How the new values work |  |
| R26 | PASS | estimated Calm global loading South Korea | 0.51 | 0.513958 | 0.005 | docs/governance/releases/0.1.4-2026-10-23.md How the new values work |  |
| R27 | PASS | estimated Calm global loading Malaysia | 0.51 | 0.506996 | 0.005 | docs/governance/releases/0.1.4-2026-10-23.md How the new values work |  |
| R28 | PASS | EWY 12-month GARCH vol in the Monte Carlo (%) | 42.8 | 42.781 | 0.05 | docs/validation/garch-dcc.md Monte Carlo marginals (P07) |  |
| R29 | PASS | largest PD move from the 0.1.4 change (pp) | 0 | 0 | 1e-09 | docs/governance/releases/0.1.4-2026-10-23.md Effect |  |
| R30 | INFO | code_hash | aa838e7b3c2afa89 | fab3c67ca4c4143f |  | docs/governance/releases/0.1.4-2026-10-23.md Base run hashes | differs: the files moved since the release (no frozen copy; hash is not evidence of a different model number) |
| R31 | INFO | data_hash | d26e6518631437a3 | af758691c6b94f89 |  | docs/governance/releases/0.1.4-2026-10-23.md Base run hashes | differs: the files moved since the release (no frozen copy; hash is not evidence of a different model number) |
| D01.1 | PASS | var99_mm at 100,000 requested, patches {'monte_carlo.vol_source': 'regime', 'copula.source': 'judgement'} | 63.98 | 63.9769 | 0.06398 | docs/validation/copula-montecarlo-layers5-6.md EQ-B-0035/0036 tables; releases/0.1.4 (0.1.3 base) |  |
| D01.2 | PASS | es99_mm at 100,000 requested, patches {'monte_carlo.vol_source': 'regime', 'copula.source': 'judgement'} | 83.02 | 83.0212 | 0.08302 | docs/validation/copula-montecarlo-layers5-6.md EQ-B-0035/0036 tables; releases/0.1.4 (0.1.3 base) |  |
| D01.3 | PASS | expected_loss_mm at 100,000 requested, patches {'monte_carlo.vol_source': 'regime', 'copula.source': 'judgement'} | 0.529 | 0.528916 | 0.000529 | docs/validation/copula-montecarlo-layers5-6.md EQ-B-0035/0036 tables; releases/0.1.4 (0.1.3 base) |  |
| D01.4 | PASS | lvar99_mm at 100,000 requested, patches {'monte_carlo.vol_source': 'regime', 'copula.source': 'judgement'} | 69.26 | 69.2585 | 0.06926 | docs/validation/copula-montecarlo-layers5-6.md EQ-B-0035/0036 tables; releases/0.1.4 (0.1.3 base) |  |
| D01.5 | PASS | mean_corr at 100,000 requested, patches {'monte_carlo.vol_source': 'regime', 'copula.source': 'judgement'} | 0.239 | 0.238519 | 0.0005 | docs/validation/copula-montecarlo-layers5-6.md EQ-B-0035/0036 tables; releases/0.1.4 (0.1.3 base) |  |
| D02.1 | PASS | var99_mm at 100,000 requested, patches {'monte_carlo.vol_source': 'garch', 'copula.source': 'judgement'} | 63.79 | 63.7932 | 0.06379 | docs/validation/copula-montecarlo-layers5-6.md EQ-B-0035 (GARCH) |  |
| D02.2 | PASS | es99_mm at 100,000 requested, patches {'monte_carlo.vol_source': 'garch', 'copula.source': 'judgement'} | 81.96 | 81.9576 | 0.08196 | docs/validation/copula-montecarlo-layers5-6.md EQ-B-0035 (GARCH) |  |
| D02.3 | PASS | expected_loss_mm at 100,000 requested, patches {'monte_carlo.vol_source': 'garch', 'copula.source': 'judgement'} | 0.457 | 0.457435 | 0.0005 | docs/validation/copula-montecarlo-layers5-6.md EQ-B-0035 (GARCH) |  |
| D02.4 | PASS | lvar99_mm at 100,000 requested, patches {'monte_carlo.vol_source': 'garch', 'copula.source': 'judgement'} | 69.08 | 69.0747 | 0.06908 | docs/validation/copula-montecarlo-layers5-6.md EQ-B-0035 (GARCH) |  |
| D03.1 | PASS | var99_mm at 100,000 requested, patches {'monte_carlo.vol_source': 'regime', 'copula.source': 'estimated', 'copula.nu_source': 'judgement'} | 74.70 | 74.6966 | 0.0747 | docs/validation/copula-montecarlo-layers5-6.md EQ-B-0036 (estimated loadings, nu 5) |  |
| D03.2 | PASS | es99_mm at 100,000 requested, patches {'monte_carlo.vol_source': 'regime', 'copula.source': 'estimated', 'copula.nu_source': 'judgement'} | 98.34 | 98.3401 | 0.09834 | docs/validation/copula-montecarlo-layers5-6.md EQ-B-0036 (estimated loadings, nu 5) |  |
| D03.3 | PASS | expected_loss_mm at 100,000 requested, patches {'monte_carlo.vol_source': 'regime', 'copula.source': 'estimated', 'copula.nu_source': 'judgement'} | 0.525 | 0.525422 | 0.000525 | docs/validation/copula-montecarlo-layers5-6.md EQ-B-0036 (estimated loadings, nu 5) |  |
| D03.4 | PASS | mean_corr at 100,000 requested, patches {'monte_carlo.vol_source': 'regime', 'copula.source': 'estimated', 'copula.nu_source': 'judgement'} | 0.335 | 0.334576 | 0.0005 | docs/validation/copula-montecarlo-layers5-6.md EQ-B-0036 (estimated loadings, nu 5) |  |
| D04.1 | PASS | var99_mm at 100,000 requested, patches {'monte_carlo.vol_source': 'regime', 'copula.source': 'estimated', 'copula.nu_source': 'estimated'} | 68.59 | 68.5853 | 0.06859 | docs/validation/copula-montecarlo-layers5-6.md EQ-B-0036 (loadings and nu) |  |
| D04.2 | PASS | es99_mm at 100,000 requested, patches {'monte_carlo.vol_source': 'regime', 'copula.source': 'estimated', 'copula.nu_source': 'estimated'} | 84.87 | 84.8672 | 0.08487 | docs/validation/copula-montecarlo-layers5-6.md EQ-B-0036 (loadings and nu) |  |
| D04.3 | PASS | expected_loss_mm at 100,000 requested, patches {'monte_carlo.vol_source': 'regime', 'copula.source': 'estimated', 'copula.nu_source': 'estimated'} | 0.605 | 0.604946 | 0.000605 | docs/validation/copula-montecarlo-layers5-6.md EQ-B-0036 (loadings and nu) |  |
| D05.1 | PASS | var99_mm at 20,000 requested, patches {'monte_carlo.vol_source': 'regime', 'copula.source': 'judgement'} | 64.2337 | 64.2337 | 0.0642337 | docs/governance/releases/0.1.4 Evidence (default-is-identical proof); scorecard.md; stress-scenarios.md |  |
| D05.2 | PASS | es99_mm at 20,000 requested, patches {'monte_carlo.vol_source': 'regime', 'copula.source': 'judgement'} | 83.6673 | 83.6673 | 0.0836673 | docs/governance/releases/0.1.4 Evidence (default-is-identical proof); scorecard.md; stress-scenarios.md |  |
| D05.3 | PASS | expected_loss_mm at 20,000 requested, patches {'monte_carlo.vol_source': 'regime', 'copula.source': 'judgement'} | 0.53438 | 0.534381 | 0.00053438 | docs/governance/releases/0.1.4 Evidence (default-is-identical proof); scorecard.md; stress-scenarios.md |  |
| D06.1 | PASS | var99_mm at 100,000 requested, patches {'monte_carlo.vol_source': 'regime', 'copula.source': 'judgement', 'regime.method': 'hmm'} | 80.98 | 80.9783 | 0.08098 | docs/validation/regime-layer3.md EQ-B-0036 (hmm) |  |
| D06.2 | PASS | es99_mm at 100,000 requested, patches {'monte_carlo.vol_source': 'regime', 'copula.source': 'judgement', 'regime.method': 'hmm'} | 105.19 | 105.194 | 0.10519 | docs/validation/regime-layer3.md EQ-B-0036 (hmm) |  |
| D06.3 | PASS | expected_loss_mm at 100,000 requested, patches {'monte_carlo.vol_source': 'regime', 'copula.source': 'judgement', 'regime.method': 'hmm'} | 0.622 | 0.621862 | 0.000622 | docs/validation/regime-layer3.md EQ-B-0036 (hmm) |  |
| D07.1 | PASS | var99_mm at 100,000 requested, patches {'monte_carlo.vol_source': 'regime', 'copula.source': 'judgement', 'monte_carlo.global_stress_share': 0.4} | 73.23 | 73.2329 | 0.07323 | docs/validation/regime-layer3.md EQ-B-0036 (cliff reference, GOV-018) |  |
| D07.2 | PASS | es99_mm at 100,000 requested, patches {'monte_carlo.vol_source': 'regime', 'copula.source': 'judgement', 'monte_carlo.global_stress_share': 0.4} | 96.21 | 96.2058 | 0.09621 | docs/validation/regime-layer3.md EQ-B-0036 (cliff reference, GOV-018) |  |
| D07.3 | PASS | expected_loss_mm at 100,000 requested, patches {'monte_carlo.vol_source': 'regime', 'copula.source': 'judgement', 'monte_carlo.global_stress_share': 0.4} | 0.508 | 0.507787 | 0.000508 | docs/validation/regime-layer3.md EQ-B-0036 (cliff reference, GOV-018) |  |
| D08.1 | PASS | var99_mm at 20,000 requested, patches {'monte_carlo.vol_source': 'regime', 'copula.source': 'judgement', 'probability.risk_premium_ratio': 1.0, 'probability.w_fx_regime_scale': {'Float': 1.0, 'Managed': 1.0, 'Peg': 1.0, 'Dollarized': 1.0, 'default': 1.0}} | 68.54 | 68.5407 | 0.06854 | docs/validation/bayesian-layer2.md EQ-B-0021 table (pre-0.1.3 base) |  |
| D08.2 | PASS | es99_mm at 20,000 requested, patches {'monte_carlo.vol_source': 'regime', 'copula.source': 'judgement', 'probability.risk_premium_ratio': 1.0, 'probability.w_fx_regime_scale': {'Float': 1.0, 'Managed': 1.0, 'Peg': 1.0, 'Dollarized': 1.0, 'default': 1.0}} | 87.42 | 87.4211 | 0.08742 | docs/validation/bayesian-layer2.md EQ-B-0021 table (pre-0.1.3 base) |  |
| D08.3 | PASS | expected_loss_mm at 20,000 requested, patches {'monte_carlo.vol_source': 'regime', 'copula.source': 'judgement', 'probability.risk_premium_ratio': 1.0, 'probability.w_fx_regime_scale': {'Float': 1.0, 'Managed': 1.0, 'Peg': 1.0, 'Dollarized': 1.0, 'default': 1.0}} | 1.855 | 1.85488 | 0.001855 | docs/validation/bayesian-layer2.md EQ-B-0021 table (pre-0.1.3 base) |  |
| D09.1 | PASS | var99_mm at 20,000 requested, patches {'monte_carlo.vol_source': 'regime', 'copula.source': 'judgement', 'probability.w_m': 0.35} | 63.13 | 63.1252 | 0.06313 | docs/validation/bayesian-layer2.md EQ-B-0021 table (w_m 0.35 + ratio 2 + Peg 0) |  |
| D09.2 | PASS | es99_mm at 20,000 requested, patches {'monte_carlo.vol_source': 'regime', 'copula.source': 'judgement', 'probability.w_m': 0.35} | 82.71 | 82.705 | 0.08271 | docs/validation/bayesian-layer2.md EQ-B-0021 table (w_m 0.35 + ratio 2 + Peg 0) |  |
| D09.3 | PASS | expected_loss_mm at 20,000 requested, patches {'monte_carlo.vol_source': 'regime', 'copula.source': 'judgement', 'probability.w_m': 0.35} | 0.236 | 0.235683 | 0.0005 | docs/validation/bayesian-layer2.md EQ-B-0021 table (w_m 0.35 + ratio 2 + Peg 0) |  |
| D10.1 | PASS | var99_mm at 100,000 requested, patches none (current assumptions) | 74.35 | 74.3513 | 0.07435 | docs/validation/README.md review checklist step 2 |  |
| D10.2 | PASS | es99_mm at 100,000 requested, patches none (current assumptions) | 96.48 | 96.4797 | 0.09648 | docs/validation/README.md review checklist step 2 |  |
| D10.3 | PASS | lvar99_mm at 100,000 requested, patches none (current assumptions) | 79.63 | 79.6328 | 0.07963 | docs/validation/README.md review checklist step 2 |  |
| D11.1 | PASS | var99_mm at 100,000 requested, patches none (current assumptions) | 74.35 | 74.3513 | 0.07435 | docs/governance/model-inventory.md components 6-8 (0.1.4 base) |  |
| D11.2 | PASS | es99_mm at 100,000 requested, patches none (current assumptions) | 96.48 | 96.4797 | 0.09648 | docs/governance/model-inventory.md components 6-8 (0.1.4 base) |  |
| D11.3 | PASS | expected_loss_mm at 100,000 requested, patches none (current assumptions) | 0.45 | 0.453153 | 0.005 | docs/governance/model-inventory.md components 6-8 (0.1.4 base) |  |
| D12.1 | PASS | var99_mm at 20,000 requested, patches {'monte_carlo.df_calm': 30} | 69.16 | 69.1582 | 0.06916 | docs/validation/README.md review checklist step 4 (df_calm 30, 0.1.4) |  |
| D13.1 | PASS | var99_mm at 20,000 requested, patches {'regime.Calm.global_loading': 0.3} | 81.26 | 81.2587 | 0.08126 | docs/validation/README.md review checklist step 4 (Calm loading 0.30, 0.1.4) |  |
| D15.1 | PASS | var99_mm at 20,000 requested, patches {'monte_carlo.vol_source': 'regime', 'copula.source': 'judgement', 'monte_carlo.df_calm': 30} | 58.52 | 58.5212 | 0.05852 | docs/validation/README.md review checklist step 4 (df_calm 30, 0.1.3 settings) |  |
| D16.1 | PASS | var99_mm at 20,000 requested, patches {'monte_carlo.vol_source': 'regime', 'copula.source': 'judgement', 'regime.Calm.global_loading': 0.3} | 72.69 | 72.6923 | 0.07269 | docs/validation/README.md review checklist step 4 (Calm loading 0.30, 0.1.3 settings) |  |
| D14 | PASS | scenario A ES99 change (%) | 61.2 | 61.1573 | 0.5 | docs/governance/model-risk-policy.md 6.6 |  |
| B01 | PASS | 120-month history: exceedances | 4 | 4 | 0.5 | docs/validation/backtests-and-forecast-record.md Outputs | history is synthetic (GOV-028): tests the arithmetic, not the model |
| B02 | PASS | 120-month history: Kupiec LR_uc | 4.098 | 4.0983 | 0.004098 | docs/validation/backtests-and-forecast-record.md Outputs | history is synthetic (GOV-028): tests the arithmetic, not the model |
| B03 | PASS | 120-month history: Kupiec p | 0.043 | 0.0429263 | 0.0005 | docs/validation/backtests-and-forecast-record.md Outputs | history is synthetic (GOV-028): tests the arithmetic, not the model |
| B04 | PASS | 120-month history: Christoffersen LR_ind | 0.278 | 0.278317 | 0.0005 | docs/validation/backtests-and-forecast-record.md Outputs | history is synthetic (GOV-028): tests the arithmetic, not the model |
| B05 | PASS | 120-month history: Christoffersen p_cc | 0.112 | 0.112106 | 0.0005 | docs/validation/backtests-and-forecast-record.md Outputs | history is synthetic (GOV-028): tests the arithmetic, not the model |
| B06 | PASS | 120-month history: Acerbi-Szekely Z2 | -2.659 | -2.65933 | 0.002659 | docs/validation/backtests-and-forecast-record.md Outputs | history is synthetic (GOV-028): tests the arithmetic, not the model |
| B07 | PASS | 120-month history: Basel zone | Yellow | Yellow |  | docs/validation/backtests-and-forecast-record.md Outputs | history is synthetic (GOV-028): tests the arithmetic, not the model |
| B08 | PASS | 120-month history: verdict | Fail | Fail |  | docs/validation/backtests-and-forecast-record.md Outputs | history is synthetic (GOV-028): tests the arithmetic, not the model |
| B09 | PASS | forecast record: exceedances | 1 | 1 | 0.5 | docs/validation/backtests-and-forecast-record.md Outputs | underpowered (GOV-029, restriction 6.4) |
| B10 | PASS | forecast record: Kupiec LR_uc | 0.224 | 0.224351 | 0.0005 | docs/validation/backtests-and-forecast-record.md Outputs | underpowered (GOV-029, restriction 6.4) |
| B11 | PASS | forecast record: Kupiec p | 0.636 | 0.635745 | 0.000636 | docs/validation/backtests-and-forecast-record.md Outputs | underpowered (GOV-029, restriction 6.4) |
| B12 | PASS | forecast record: Christoffersen p_cc | 0.879 | 0.878607 | 0.000879 | docs/validation/backtests-and-forecast-record.md Outputs | underpowered (GOV-029, restriction 6.4) |
| B13 | PASS | forecast record: Z2 | -0.269 | -0.268656 | 0.0005 | docs/validation/backtests-and-forecast-record.md Outputs | underpowered (GOV-029, restriction 6.4) |
| B14 | PASS | forecast record: Basel zone | Green | Green |  | docs/validation/backtests-and-forecast-record.md Outputs | underpowered (GOV-029, restriction 6.4) |
| B15 | PASS | forecast record: verdict | Pass | Pass |  | docs/validation/backtests-and-forecast-record.md Outputs | underpowered (GOV-029, restriction 6.4) |
| H01 | PASS | refit on stored panel data/panel/hazard_panel.csv: in_sample.auc | 0.882 | 0.881607 | 0.000882 | docs/validation/hazard-fit-report.md (generated 2026-10-23 10:10, EQ-B-0054 update) |  |
| H02 | PASS | refit on stored panel data/panel/hazard_panel.csv: in_sample.brier | 0.0207 | 0.0207037 | 5e-05 | docs/validation/hazard-fit-report.md (generated 2026-10-23 10:10, EQ-B-0054 update) |  |
| H03 | PASS | refit on stored panel data/panel/hazard_panel.csv: in_sample.brier_base_rate | 0.0209 | 0.0209207 | 5e-05 | docs/validation/hazard-fit-report.md (generated 2026-10-23 10:10, EQ-B-0054 update) |  |
| H04 | PASS | refit on stored panel data/panel/hazard_panel.csv: in_sample.log_loss | 0.0849 | 0.0849295 | 8.49e-05 | docs/validation/hazard-fit-report.md (generated 2026-10-23 10:10, EQ-B-0054 update) |  |
| H05 | PASS | refit on stored panel data/panel/hazard_panel.csv: in_sample.log_loss_base_rate | 0.1034 | 0.103353 | 0.0001034 | docs/validation/hazard-fit-report.md (generated 2026-10-23 10:10, EQ-B-0054 update) |  |
| H06 | PASS | refit on stored panel data/panel/hazard_panel.csv: out_of_sample.auc | 0.780 | 0.780488 | 0.00078 | docs/validation/hazard-fit-report.md (generated 2026-10-23 10:10, EQ-B-0054 update) |  |
| H07 | PASS | refit on stored panel data/panel/hazard_panel.csv: out_of_sample.brier | 0.0320 | 0.0319952 | 5e-05 | docs/validation/hazard-fit-report.md (generated 2026-10-23 10:10, EQ-B-0054 update) |  |
| H08 | PASS | refit on stored panel data/panel/hazard_panel.csv: out_of_sample.brier_base_rate | 0.0234 | 0.0234104 | 5e-05 | docs/validation/hazard-fit-report.md (generated 2026-10-23 10:10, EQ-B-0054 update) |  |
| H09 | PASS | refit on stored panel data/panel/hazard_panel.csv: out_of_sample.log_loss | 0.1242 | 0.124174 | 0.0001242 | docs/validation/hazard-fit-report.md (generated 2026-10-23 10:10, EQ-B-0054 update) |  |
| H10 | PASS | refit on stored panel data/panel/hazard_panel.csv: out_of_sample.log_loss_base_rate | 0.1166 | 0.116603 | 0.0001166 | docs/validation/hazard-fit-report.md (generated 2026-10-23 10:10, EQ-B-0054 update) |  |
| H11 | PASS | refit on stored panel data/panel/hazard_panel.csv: out_of_sample.n | 168 | 168 | 0.5 | docs/validation/hazard-fit-report.md (generated 2026-10-23 10:10, EQ-B-0054 update) |  |
| H12 | PASS | refit on stored panel data/panel/hazard_panel.csv: out_of_sample.events | 4 | 4 | 0.5 | docs/validation/hazard-fit-report.md (generated 2026-10-23 10:10, EQ-B-0054 update) |  |
| H13 | PASS | refit on stored panel data/panel/hazard_panel.csv: events | 9 | 9 | 0.5 | docs/validation/hazard-fit-report.md (generated 2026-10-23 10:10, EQ-B-0054 update) |  |
| H14 | PASS | refit on stored panel data/panel/hazard_panel.csv: rows | 421 | 421 | 0.5 | docs/validation/hazard-fit-report.md (generated 2026-10-23 10:10, EQ-B-0054 update) |  |
| H15 | PASS | refit on stored panel data/panel/hazard_panel.csv: intercept | -4.501 | -4.50125 | 0.004501 | docs/validation/hazard-fit-report.md (generated 2026-10-23 10:10, EQ-B-0054 update) |  |
| H16 | PASS | refit on stored panel data/panel/hazard_panel.csv: coef.debt_gdp | 0.057 | 0.0573677 | 0.0005 | docs/validation/hazard-fit-report.md (generated 2026-10-23 10:10, EQ-B-0054 update) |  |
| H17 | PASS | refit on stored panel data/panel/hazard_panel.csv: coef.primary_deficit | -0.483 | -0.482719 | 0.0005 | docs/validation/hazard-fit-report.md (generated 2026-10-23 10:10, EQ-B-0054 update) |  |
| H18 | PASS | refit on stored panel data/panel/hazard_panel.csv: coef.current_account | -0.975 | -0.974781 | 0.000975 | docs/validation/hazard-fit-report.md (generated 2026-10-23 10:10, EQ-B-0054 update) |  |
| H19 | PASS | refit on stored panel data/panel/hazard_panel.csv: coef.real_growth | -1.050 | -1.04972 | 0.00105 | docs/validation/hazard-fit-report.md (generated 2026-10-23 10:10, EQ-B-0054 update) |  |
| H20 | PASS | refit on stored panel data/panel/hazard_panel.csv: coef.inflation_log | 0.085 | 0.0849595 | 0.0005 | docs/validation/hazard-fit-report.md (generated 2026-10-23 10:10, EQ-B-0054 update) |  |
| H21 | PASS | rebuilt panel (raw_weo.csv + sovereign_defaults.csv): rows | 391 | 391 | 0.5 | docs/validation/hazard-fit-report.md (generated 2026-10-23 10:10, EQ-B-0054 update) Rebuilt panel |  |
| H22 | PASS | rebuilt panel (raw_weo.csv + sovereign_defaults.csv): events | 9 | 9 | 0.5 | docs/validation/hazard-fit-report.md (generated 2026-10-23 10:10, EQ-B-0054 update) Rebuilt panel |  |
| H23 | PASS | rebuilt panel (raw_weo.csv + sovereign_defaults.csv): out_of_sample.auc | 0.789 | 0.788851 | 0.000789 | docs/validation/hazard-fit-report.md (generated 2026-10-23 10:10, EQ-B-0054 update) Rebuilt panel |  |
| H24 | PASS | rebuilt panel (raw_weo.csv + sovereign_defaults.csv): out_of_sample.brier | 0.0361 | 0.0361337 | 5e-05 | docs/validation/hazard-fit-report.md (generated 2026-10-23 10:10, EQ-B-0054 update) Rebuilt panel |  |
| H25 | PASS | rebuilt panel (raw_weo.csv + sovereign_defaults.csv): out_of_sample.n | 152 | 152 | 0.5 | docs/validation/hazard-fit-report.md (generated 2026-10-23 10:10, EQ-B-0054 update) Rebuilt panel |  |
| S01 | PASS | max /composite - workbook/ (points), tolerance 0.15 | 0 | 0.0790155 | 0.15 | docs/validation/scorecard.md Benchmarks (workbook reference, seed snapshot) |  |
| S02 | PASS | max /pillar - workbook/ over 7 pillars (points), tolerance 0.1 | 0 | 0.05 | 0.1 | docs/validation/scorecard.md Benchmarks (workbook reference, seed snapshot) |  |
| S03 | PASS | grades equal to workbook (count of 18) | 18 | 18 | 0 | docs/validation/scorecard.md Benchmarks (workbook reference, seed snapshot) |  |
| S04 | PASS | regimes equal to workbook (count of 18) | 18 | 18 | 0 | docs/validation/regime-layer3.md Benchmarks (workbook regimes, seed snapshot) |  |
| G01 | PASS | persistence median | 0.909 | 0.908792 | 0.000909 | docs/validation/garch-dcc.md Outputs (run 2026-10-22) |  |
| G02 | PASS | Student-t nu median | 4.20 | 4.19599 | 0.005 | docs/validation/garch-dcc.md Outputs (run 2026-10-22) |  |
| G03 | PASS | number of series fitted | 27 | 27 | 0.5 | docs/validation/garch-dcc.md Outputs (run 2026-10-22) |  |
| G04 | PASS | fits converged (count) | 27 | 27 | 0.5 | docs/validation/garch-dcc.md Outputs (run 2026-10-22) |  |
| G05 | PASS | DCC FX average one-step correlation | 0.089 | 0.08865 | 0.0005 | docs/validation/garch-dcc.md Outputs (run 2026-10-22) |  |
| G06 | PASS | DCC equity average correlation | 0.364 | 0.363643 | 0.0005 | docs/validation/garch-dcc.md Outputs (run 2026-10-22) |  |
