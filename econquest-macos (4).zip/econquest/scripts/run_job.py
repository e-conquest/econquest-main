#!/usr/bin/env python3
"""Run one econquest job by hand through the same wrapper the launchd plists use (EQ-C-0021), so start, end and exit
code land in outputs/logs/jobs/ and the health check sees them.

    python scripts/run_job.py record            # the steps `econquest schedule install` would schedule for "record"
    python scripts/run_job.py --job x -- cmd args   # any command, recorded as job x

Uses ECONQUEST_HOME (default: this checkout) and the default launcher ~/.local/bin/econquest.
"""
from __future__ import annotations
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))

from econquest.ops import jobs, schedule  # noqa: E402


def main(argv: list[str]) -> int:
    home = Path(os.environ.get("ECONQUEST_HOME", ROOT))
    if "--" in argv and argv[:1] == ["--job"]:
        i = argv.index("--")
        return jobs.run_job(argv[1], [argv[i + 1:]], home)
    if len(argv) != 1 or argv[0] not in schedule.DEFAULT_JOBS:
        print(__doc__, file=sys.stderr)
        return 2
    cfg = schedule.load_config(home)
    p = schedule.paths(home, python=sys.executable if not (home / ".venv" / "bin" / "python").exists() else None)
    return jobs.run_job(argv[0], schedule.resolve_steps(cfg["jobs"][argv[0]], p, cfg), home)


if __name__ == "__main__":
    sys.exit(main(sys.argv[1:]))
