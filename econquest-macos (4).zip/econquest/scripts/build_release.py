"""Reproducible release zip for econquest (EQ-C-0001).

    python scripts/build_release.py /tmp/rel/econquest-macos.zip            # build, print SHA-256
    python scripts/build_release.py OUT.zip --source /path/to/econquest     # another checkout
    SOURCE_DATE_EPOCH=1761177600 python scripts/build_release.py OUT.zip    # pin entry timestamps to a date

The same source tree always gives the same bytes: entries are sorted, every entry carries one fixed timestamp
(SOURCE_DATE_EPOCH, else 1980-01-01 00:00), fixed permissions (0644 files, 0755 for *.sh / *.command and
directories), fixed compression (deflate level 9) and no extra fields. The layout matches the shipped
econquest-macos.zip: one top-level folder `econquest/` with directory entries.

Excluded: outputs/, __pycache__/, .pytest_cache/, .venv/, *.egg-info/, team/checkpoints/, team/local.team, *.pyc,
.DS_Store, .claude/settings.local.json, credential files (SECRET_GLOBS: .env, *.token, *.pem, *.key, Keychain exports,
client_secret*.json ...), and the output zip itself if it lies inside the source tree.

Written next to OUT.zip: OUT.zip.sha256 (`shasum -a 256 -c` format) and OUT.zip.manifest.txt (sha256 and size of
every file). The same manifest is stored inside the zip as econquest/RELEASE-MANIFEST.txt.
An existing OUT.zip is not replaced without --force (the real release is the lead's step).
"""
from __future__ import annotations

import argparse
import fnmatch
import hashlib
import os
import sys
import time
import zipfile
from pathlib import Path

TOP = "econquest"
EXCLUDE_DIRS = {"outputs", "__pycache__", ".pytest_cache", ".venv", ".mypy_cache", ".ruff_cache", ".git"}
EXCLUDE_PATHS = {"team/checkpoints", "team/local.team", ".claude/settings.local.json"}
EXCLUDE_SUFFIXES = (".pyc", ".pyo")
EXCLUDE_NAMES = {".DS_Store"}
# Credentials never ship (AGENT-09 review): a Sheets token file, .env, key material or a Keychain export anywhere in
# the tree is left out. Matched case-insensitively against the file name (fnmatch).
SECRET_GLOBS = (".env", ".env.*", "*.env", ".netrc", "*.token", "token.json", "token.txt", "*sheets*token*", "*.secret",
                "secrets.*", "credentials*.json", "client_secret*.json", "service-account*.json", "*.pem", "*.key", "*.p12",
                "*.pfx", "*.keychain", "*.keychain-db", "id_rsa*", "id_ed25519*",
                # SEC-C-008: names the list above missed (api_token.json, smtp-password.txt were packed by evidence)
                "id_ecdsa*", "id_dsa*", "*password*", "*passwd*", "*api_token*", "*apikey*", "*api_key*",
                ".git-credentials", ".pypirc", ".npmrc", ".htpasswd")


def is_secret(name: str) -> bool:
    n = name.lower()
    return any(fnmatch.fnmatchcase(n, g) for g in SECRET_GLOBS)
EXEC_SUFFIXES = (".sh", ".command")
MANIFEST_NAME = "RELEASE-MANIFEST.txt"
EPOCH_1980 = (1980, 1, 1, 0, 0, 0)


def fixed_date_time() -> tuple[int, int, int, int, int, int]:
    sde = os.environ.get("SOURCE_DATE_EPOCH")
    if not sde:
        return EPOCH_1980
    t = time.gmtime(max(int(sde), 315532800))            # zip cannot store dates before 1980
    return (t.tm_year, t.tm_mon, t.tm_mday, t.tm_hour, t.tm_min, t.tm_sec - t.tm_sec % 2)


def excluded(rel: str, is_dir: bool) -> bool:
    parts = rel.split("/")
    if any(p in EXCLUDE_DIRS or p.endswith(".egg-info") for p in parts):
        return True
    if any("/".join(parts[:i + 1]) in EXCLUDE_PATHS for i in range(len(parts))):
        return True
    return not is_dir and (parts[-1] in EXCLUDE_NAMES or rel.endswith(EXCLUDE_SUFFIXES) or is_secret(parts[-1]))


def collect(source: Path, skip: set[Path]) -> tuple[list[str], list[str]]:
    """Sorted relative directory and file paths under source, after exclusions."""
    dirs, files = [], []
    for root, dnames, fnames in os.walk(source):
        rroot = Path(root).relative_to(source).as_posix()
        rroot = "" if rroot == "." else rroot
        keep = []
        for d in dnames:
            rel = f"{rroot}/{d}" if rroot else d
            if not excluded(rel, True) and not (Path(root) / d).is_symlink():
                keep.append(d); dirs.append(rel)
        dnames[:] = keep
        for f in fnames:
            rel = f"{rroot}/{f}" if rroot else f
            p = Path(root) / f
            if excluded(rel, False) or p.is_symlink() or p.resolve() in skip:
                continue
            files.append(rel)
    return sorted(dirs), sorted(files)


def sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as fh:
        for chunk in iter(lambda: fh.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _info(name: str, mode: int, dt: tuple) -> zipfile.ZipInfo:
    zi = zipfile.ZipInfo(name, date_time=dt)
    zi.create_system = 3                                  # unix, so external_attr carries the mode
    zi.external_attr = (mode & 0xFFFF) << 16
    if name.endswith("/"):
        zi.external_attr |= 0x10                          # MS-DOS directory flag
        zi.compress_type = zipfile.ZIP_STORED
    else:
        zi.compress_type = zipfile.ZIP_DEFLATED
    return zi


def default_mode(name: str, src) -> int:
    """Entry mode: 0755 for directories (src None) and *.sh / *.command, 0644 otherwise."""
    if src is None:
        return 0o40755
    return 0o100755 if name.endswith(EXEC_SUFFIXES) and not isinstance(src, bytes) else 0o100644


def write_zip(out: Path, entries, dt: tuple | None = None, mode=default_mode) -> str:
    """The deterministic zip writer (also used by `econquest evidence`, EQ-C-0060). `entries` are (name, src): src None
    is a directory entry (name ends in "/"), bytes are stored as given, a Path is read. Entries are written sorted by
    name with one timestamp `dt` (default fixed_date_time()), the mode from `mode(name, src)`, deflate level 9 and no
    extra fields; the file is written to OUT.part and moved into place. Returns the zip's SHA-256."""
    out = Path(out)
    dt = dt or fixed_date_time()
    tmp = out.with_name(out.name + ".part")
    with zipfile.ZipFile(tmp, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for name, src in sorted(entries, key=lambda e: e[0]):
            if src is None:
                z.writestr(_info(name, mode(name, src), dt), b"")
            elif isinstance(src, bytes):
                z.writestr(_info(name, mode(name, src), dt), src, compresslevel=9)
            else:
                z.writestr(_info(name, mode(name, src), dt), Path(src).read_bytes(), compresslevel=9)
    os.replace(tmp, out)
    return sha256_file(out)


def build(source: Path, out: Path) -> dict:
    source, out = source.resolve(), out.resolve()
    dt = fixed_date_time()
    out.parent.mkdir(parents=True, exist_ok=True)         # before collecting, so an output folder inside the tree is stable
    dirs, files = collect(source, {out.with_name(out.name + x) for x in ("", ".part", ".sha256", ".manifest.txt")})
    rows = []
    for rel in files:
        p = source / rel
        rows.append((sha256_file(p), p.stat().st_size, rel))
    manifest = "".join(f"{h}  {size:>10}  {TOP}/{rel}\n" for h, size, rel in rows)
    entries = [(f"{TOP}/", None)] + [(f"{TOP}/{d}/", None) for d in dirs] + [(f"{TOP}/{f}", source / f) for f in files] \
        + [(f"{TOP}/{MANIFEST_NAME}", manifest.encode())]
    digest = write_zip(out, entries, dt)
    out.with_name(out.name + ".sha256").write_text(f"{digest}  {out.name}\n")
    out.with_name(out.name + ".manifest.txt").write_text(f"# {out.name} sha256 {digest}\n# {len(files)} files, sha256  size  path\n" + manifest)
    return {"zip": str(out), "sha256": digest, "files": len(files), "dirs": len(dirs) + 1}


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description="Build the reproducible econquest release zip.")
    ap.add_argument("out", help="output zip path")
    ap.add_argument("--source", default=str(Path(__file__).resolve().parent.parent), help="econquest folder (default: this checkout)")
    ap.add_argument("--force", action="store_true", help="replace an existing output zip")
    a = ap.parse_args(argv)
    out = Path(a.out)
    if out.exists() and not a.force:
        print(f"{out} exists; pass --force to replace it", file=sys.stderr)
        return 2
    r = build(Path(a.source), out)
    print(f"{r['sha256']}  {r['zip']}  ({r['files']} files)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
