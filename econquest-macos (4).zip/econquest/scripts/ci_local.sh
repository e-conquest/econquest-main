#!/usr/bin/env bash
# Local CI for econquest (EQ-C-0001): the same gates as .github/workflows/ci.yml, run in this folder.
#
#   bash scripts/ci_local.sh                     # all gates
#   CI_TICKET=EQ-C-0001 bash scripts/ci_local.sh # team gate on one ticket's checkpointed files
#
# Environment:
#   ECONQUEST_TEAM / CI_TEAM  team letter for the team gate (default: whatever teamctl resolves)
#   CI_TICKET            run `teamctl check --ticket` instead of the whole-tree check
#   CI_SMOKE_PATHS       Monte Carlo paths for the smoke run (default 2000)
#   CI_SKIP              space-separated gates to skip: gate lock tests smoke lint bandit audit
#   RUFF_BLOCKING=1      make repo-wide ruff blocking too (Team C paths always block, EQ-C-0004)
#   CI_OFFLINE=1         skip pip-audit (it needs PyPI/OSV); it also skips itself when the network is unreachable
#   PIP_AUDIT_BLOCKING=0 report pip-audit findings without failing
#   PYTHON               interpreter (default: python3, else python)
#
# Exits non-zero if any blocking gate fails; prints a summary table either way.
set -uo pipefail

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd -P)" || exit 2
cd "$ROOT" || exit 2
export PYTHONPATH="$ROOT${PYTHONPATH:+:$PYTHONPATH}"     # import this checkout even if the cwd handle goes stale
PY="${PYTHON:-$(command -v python3 || command -v python)}"
SKIP=" ${CI_SKIP:-} "
TEAM="${CI_TEAM:-${ECONQUEST_TEAM:-}}"
SMOKE_OUT="$(mktemp -d "${TMPDIR:-/tmp}/econquest-smoke.XXXXXX")"
trap 'rm -rf "$SMOKE_OUT"' EXIT

declare -a NAMES RESULTS
FAILED=0

say() { printf '\n\033[1;34m==> %s\033[0m\n' "$*"; }
record() {  # name result(pass|FAIL|warn|skip) blocking(1|0)
  NAMES+=("$1"); RESULTS+=("$2")
  if [[ "$2" == "FAIL" && "$3" == "1" ]]; then FAILED=1; fi
}
skipped() { cd "$ROOT" || exit 2; [[ "$SKIP" == *" $1 "* ]]; }   # re-enter ROOT before every gate (network mounts)
have() { "$PY" -c "import importlib.util,sys; sys.exit(0 if importlib.util.find_spec('$1') else 1)" 2>/dev/null; }

# 1. Team gate: ownership, board, handoffs, logs ----------------------------------------------
if skipped gate; then record "team gate" skip 1; else
  say "team gate (teamctl check)"
  args=(check); [[ -n "$TEAM" ]] && args+=(--team "$TEAM"); [[ -n "${CI_TICKET:-}" ]] && args+=(--ticket "$CI_TICKET")
  if "$PY" team/teamctl.py "${args[@]}"; then record "team gate" pass 1; else record "team gate" FAIL 1; fi
fi

# 1b. Install lock (EQ-C-0066): requirements-lock.txt pins, with hashes, every package install.sh installs ---------
if skipped lock; then record "install lock" skip 1; else
  say "install lock (scripts/make_hash_lock.py --check, offline)"
  if "$PY" scripts/make_hash_lock.py --check; then record "install lock" pass 1; else record "install lock" FAIL 1; fi
fi

# 2. Tests ---------------------------------------------------------------------------------------
if skipped tests; then record "pytest" skip 1; else
  say "pytest"
  if "$PY" -m pytest -q -p no:cacheprovider tests; then record "pytest" pass 1; else record "pytest" FAIL 1; fi
fi

# 3. Smoke run (writes to a temp --out, never to the shared outputs/) ---------------------------
if skipped smoke; then record "smoke run" skip 1; else
  say "smoke run (--paths ${CI_SMOKE_PATHS:-2000}, --out $SMOKE_OUT)"
  if "$PY" -m econquest --out "$SMOKE_OUT" run --paths "${CI_SMOKE_PATHS:-2000}" --no-paths >/dev/null \
     && "$PY" - "$SMOKE_OUT/run_latest.json" <<'EOF'
import json, sys
flat = json.dumps(json.load(open(sys.argv[1])))
missing = [k for k in ("var99_mm", "es99_mm", "expected_loss_mm") if k not in flat]
sys.exit(f"missing from run_latest.json: {missing}" if missing else print("smoke ok") or 0)
EOF
  then record "smoke run" pass 1; else record "smoke run" FAIL 1; fi
fi

# 4. Lint: Team C paths block (EQ-C-0004); the rest of the repo is advisory until Teams A and B clear it --
RUFF_C_PATHS=(econquest/presentation econquest/cli.py econquest/config.py econquest/versioning.py econquest/common_format.py
              econquest/__init__.py econquest/__main__.py scripts team/teamctl.py)
if skipped lint; then record "ruff (team C)" skip 1; record "ruff (repo)" skip 0; else
  blocking="${RUFF_BLOCKING:-0}"
  if command -v ruff >/dev/null 2>&1; then RUFF=(ruff); elif have ruff; then RUFF=("$PY" -m ruff); else RUFF=(); fi
  if [[ ${#RUFF[@]} -eq 0 ]]; then
    echo "ruff not installed (pip install -e '.[ci]')"; record "ruff (team C)" FAIL 1; record "ruff (repo)" skip "$blocking"
  else
    say "ruff check (team C paths, blocking)"
    if "${RUFF[@]}" check "${RUFF_C_PATHS[@]}"; then record "ruff (team C)" pass 1; else record "ruff (team C)" FAIL 1; fi
    say "ruff check econquest tests team scripts (advisory unless RUFF_BLOCKING=1)"
    if "${RUFF[@]}" check econquest tests team scripts --statistics; then record "ruff (repo)" pass "$blocking"
    else record "ruff (repo)" "$([[ $blocking == 1 ]] && echo FAIL || echo warn)" "$blocking"; fi
  fi
fi

# 5. Static security analysis (medium and high) --------------------------------------------------
if skipped bandit; then record "bandit" skip 1; else
  say "bandit -q -r econquest -ll"
  if command -v bandit >/dev/null 2>&1; then BANDIT=(bandit); elif have bandit; then BANDIT=("$PY" -m bandit); else BANDIT=(); fi
  if [[ ${#BANDIT[@]} -eq 0 ]]; then echo "bandit not installed (pip install -e '.[ci]')"; record "bandit" FAIL 1
  elif "${BANDIT[@]}" -q -r econquest -ll; then record "bandit" pass 1; else record "bandit" FAIL 1; fi
fi

# 6. Dependency vulnerabilities (needs network; skips gracefully offline) ------------------------
if skipped audit || [[ "${CI_OFFLINE:-0}" == "1" ]]; then record "pip-audit" skip 1; else
  say "pip-audit"
  blocking="${PIP_AUDIT_BLOCKING:-1}"
  if command -v pip-audit >/dev/null 2>&1; then AUDIT=(pip-audit); elif have pip_audit; then AUDIT=("$PY" -m pip_audit); else AUDIT=(); fi
  if [[ ${#AUDIT[@]} -eq 0 ]]; then echo "pip-audit not installed (pip install -e '.[ci]'); skipped"; record "pip-audit" skip "$blocking"
  else
    # Audit the pinned locks when present (no resolver run), else the current environment. requirements-lock.txt is
    # what install.sh actually installs (hash mode; 18 of its packages are not in scripts/requirements-lock.txt and 6
    # differ in version), so both are audited and either one failing fails the gate (SEC-C-008, EQ-C-0066).
    targets=()
    [[ -f requirements-lock.txt ]] && targets+=("-r requirements-lock.txt --require-hashes --disable-pip")
    [[ -f scripts/requirements-lock.txt ]] && targets+=("-r scripts/requirements-lock.txt --no-deps --disable-pip")
    [[ ${#targets[@]} -gt 0 ]] || targets=("")
    log="$SMOKE_OUT/pip-audit.log"; : >"$log"; audit_rc=0
    for t in "${targets[@]}"; do
      # shellcheck disable=SC2086  # $t is a fixed option string with relative, space-free paths
      "${AUDIT[@]}" $t >>"$log" 2>&1 || audit_rc=1
    done
    if [[ $audit_rc -eq 0 ]]; then cat "$log"; record "pip-audit" pass "$blocking"
    # A vulnerability report is never read as "offline" (a package name like pyopenssl matches SSL), and on a CI
    # runner (CI/GITHUB_ACTIONS set) an unreachable service fails the gate instead of skipping it (AGENT-09 review).
    elif ! grep -qiE "known vulnerabilit" "$log" && [[ -z "${CI:-}${GITHUB_ACTIONS:-}" ]] \
         && grep -qiE "connection|resolve|timed? ?out|network|proxy|max retries|temporary failure|SSL" "$log"; then
      tail -5 "$log"; echo "pip-audit could not reach the vulnerability service: skipped (rerun online)"; record "pip-audit" skip "$blocking"
    else cat "$log"; record "pip-audit" "$([[ $blocking == 1 ]] && echo FAIL || echo warn)" "$blocking"; fi
  fi
fi

# Summary ------------------------------------------------------------------------------------------
printf '\n%-12s %s\n' "gate" "result"
for i in "${!NAMES[@]}"; do printf '%-12s %s\n' "${NAMES[$i]}" "${RESULTS[$i]}"; done
if [[ $FAILED -ne 0 ]]; then printf '\nci_local: FAILED (%s)\n' "$ROOT"; exit 1; fi
printf '\nci_local: all blocking gates passed\n'
