"""Write or check requirements-lock.txt, the hash-pinned lock that install.sh installs from (EQ-C-0066, SEC-C-007 O2).

    python scripts/make_hash_lock.py            # resolve on PyPI and rewrite requirements-lock.txt (needs network)
    python scripts/make_hash_lock.py --check    # offline: the lock pins and hashes every package install.sh needs

The lock covers what install.sh installs by default: [project].dependencies, the [all] extra (fastapi, uvicorn,
pytest), setuptools from [build-system].requires (the editable install is built without build isolation, so the
build backend is hash-checked too) and pip itself. It is resolved once per target with `pip install --dry-run
--report --only-binary=:all: --platform ... --python-version ...`; every target must resolve to the same versions.
The SHA-256 of every wheel of the pinned version that fits a target is then read from PyPI's JSON API, so
`pip install --require-hashes -r requirements-lock.txt` works whichever of those wheels pip picks on the machine
(an sdist hash is added only for a package that has no wheel for some target).

Not in this lock (installed unpinned on request): the extras api, ml, test, ci, research (yfinance, not a desk
dependency since EQ-A-0040), and the licensed vendor extras
bloomberg (blpapi, from Bloomberg's own index, never PyPI) and lseg.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import re
import ssl
import subprocess
import sys
import tempfile
import urllib.request
from pathlib import Path

try:
    import tomllib
except ImportError:                                      # Python 3.10
    import tomli as tomllib

try:
    from packaging import tags
    from packaging.requirements import Requirement
    from packaging.utils import canonicalize_name, parse_wheel_filename
except ImportError:                                      # pip always vendors packaging
    from pip._vendor.packaging import tags
    from pip._vendor.packaging.requirements import Requirement
    from pip._vendor.packaging.utils import canonicalize_name, parse_wheel_filename

ROOT = Path(__file__).resolve().parent.parent
LOCK = ROOT / "requirements-lock.txt"
INSTALL_EXTRAS = ("all",)                                # install.sh installs econquest[all]
# imf-reader~=2.2.0 needs Python 3.12+, and 3.15 has no pandas wheel yet: 3.12-3.14 is what can be installed today
PYTHONS = ("3.12", "3.13", "3.14")
MACOS_MAX = (26, 0)                                      # include every macOS wheel up to this release
GLIBC = range(17, 40)                                    # manylinux_2_17 .. manylinux_2_39
PLATFORMS = ("macos-arm64", "macos-x86_64", "linux-x86_64", "linux-aarch64")


def _platform_tags(target: str) -> list[str]:
    os_name, arch = target.split("-")
    if os_name == "macos":
        return list(tags.mac_platforms(MACOS_MAX, arch))
    legacy = {"x86_64": ["manylinux2014_x86_64", "manylinux2010_x86_64", "manylinux1_x86_64"],
              "aarch64": ["manylinux2014_aarch64"]}[arch]
    return [f"manylinux_2_{g}_{arch}" for g in reversed(GLIBC)] + legacy


def _target_tags(py: str, target: str) -> set:
    ver = tuple(int(x) for x in py.split("."))
    cp = f"cp{ver[0]}{ver[1]}"
    plats = _platform_tags(target)
    return set(tags.cpython_tags(ver, [cp, "abi3", "none"], plats)) | set(tags.compatible_tags(ver, cp, plats))


def declared(pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    """The requirement strings install.sh installs: runtime deps, the [all] extra, the build backend and pip."""
    doc = tomllib.loads(pyproject.read_text())
    proj = doc["project"]
    reqs = list(proj.get("dependencies", []))
    for extra in INSTALL_EXTRAS:
        reqs += proj.get("optional-dependencies", {}).get(extra, [])
    reqs += doc.get("build-system", {}).get("requires", [])
    return reqs + ["pip"]


def parse_lock(text: str) -> tuple[dict, dict]:
    """(pins {canonical name: (version, [sha256 ...])}, header {key: value}) from a hash-pinned lock."""
    header: dict[str, str] = {}
    for line in text.splitlines():
        m = re.match(r"#\s*(python|platforms):\s*(.*)$", line)
        if m:
            header[m.group(1)] = m.group(2).strip()
    pins: dict[str, tuple[str, list[str]]] = {}
    body = re.sub(r"\\\n", " ", "\n".join(ln for ln in text.splitlines() if not ln.lstrip().startswith("#")))
    for line in body.splitlines():
        if not line.strip():
            continue
        m = re.match(r"\s*([A-Za-z0-9][A-Za-z0-9._-]*)==([^\s;]+)(.*)$", line)
        if not m:
            pins[f"<unparsed: {line.strip()[:60]}>"] = ("", [])
            continue
        pins[canonicalize_name(m.group(1))] = (m.group(2), re.findall(r"--hash=sha256:([0-9a-f]{64})", m.group(3)))
    return pins, header


def check(lock: Path = LOCK, pyproject: Path = ROOT / "pyproject.toml") -> list[str]:
    """Problems that would make install.sh fail or leave a declared package unpinned; empty when the lock is good."""
    if not lock.is_file():
        return [f"{lock.name} is missing"]
    pins, header = parse_lock(lock.read_text())
    problems = [f"{name}: no sha256 hash" for name, (_, hashes) in pins.items() if not hashes]
    for req_s in declared(pyproject):
        req = Requirement(req_s)
        name = canonicalize_name(req.name)
        if name not in pins:
            problems.append(f"{req_s}: declared in pyproject.toml but not in {lock.name}")
        elif not req.specifier.contains(pins[name][0], prereleases=True):
            problems.append(f"{req_s}: {lock.name} pins {pins[name][0]}, outside the declared range")
    if not header.get("python"):
        problems.append(f"{lock.name}: no '# python:' header line (install.sh reads it)")
    return problems


def _resolve(reqs: list[str], py: str, target: str) -> dict[str, str]:
    abi = "cp" + py.replace(".", "")
    plat_args = [a for p in _platform_tags(target) for a in ("--platform", p)]
    with tempfile.TemporaryDirectory() as tmp:
        rin, rep = Path(tmp) / "in.txt", Path(tmp) / "report.json"
        rin.write_text("\n".join(reqs) + "\n")
        cmd = [sys.executable, "-m", "pip", "install", "--quiet", "--dry-run", "--ignore-installed",
               "--only-binary=:all:", "--python-version", py, "--implementation", "cp",
               "--abi", abi, "--abi", "abi3", "--abi", "none", *plat_args, "--report", str(rep), "-r", str(rin)]
        r = subprocess.run(cmd, capture_output=True, text=True)
        if r.returncode != 0:
            raise SystemExit(f"resolution failed for Python {py} {target}:\n{r.stderr[-2000:]}")
        report = json.loads(rep.read_text())
    return {canonicalize_name(i["metadata"]["name"]): i["metadata"]["version"] for i in report["install"]}


def _pypi_files(name: str, version: str) -> list[dict]:
    cafile = os.environ.get("PIP_CERT") or os.environ.get("REQUESTS_CA_BUNDLE") or os.environ.get("SSL_CERT_FILE")
    ctx = ssl.create_default_context(cafile=cafile)
    with urllib.request.urlopen(f"https://pypi.org/pypi/{name}/{version}/json", context=ctx, timeout=60) as resp:
        return [f for f in json.load(resp)["urls"] if not f.get("yanked")]


def generate() -> str:
    reqs = declared()
    targets = [(py, t) for py in PYTHONS for t in PLATFORMS]
    resolved = {tg: _resolve(reqs, *tg) for tg in targets}
    first = resolved[targets[0]]
    for tg, pins in resolved.items():
        if pins != first:
            diff = sorted(set(pins.items()) ^ set(first.items()))
            raise SystemExit(f"Python {tg[0]} {tg[1]} resolves differently from {targets[0]}: {diff}")
    tagsets = {tg: _target_tags(*tg) for tg in targets}
    out, n_files = [], 0
    for name in sorted(first):
        version = first[name]
        files = _pypi_files(name, version)
        wheels = {}
        for f in files:
            if f["packagetype"] == "bdist_wheel":
                ftags = parse_wheel_filename(f["filename"])[3]
                hit = {tg for tg, ts in tagsets.items() if ftags & ts}
                if hit:
                    wheels[f["digests"]["sha256"]] = hit
        covered = set().union(*wheels.values()) if wheels else set()
        hashes = set(wheels)
        if covered != set(targets):
            sdists = [f["digests"]["sha256"] for f in files if f["packagetype"] == "sdist"]
            if not sdists:
                missing = sorted(set(targets) - covered)
                raise SystemExit(f"{name}=={version}: no wheel or sdist for {missing}")
            hashes |= set(sdists)
        n_files += len(hashes)
        out.append(f"{name}=={version} \\\n" + " \\\n".join(f"    --hash=sha256:{h}" for h in sorted(hashes)))
    head = [
        "# econquest install lock (EQ-C-0066, SEC-C-007 O2): every package install.sh installs, pinned to one version",
        "# with the SHA-256 of each wheel PyPI publishes for the platforms below. Do not edit by hand; regenerate with",
        "#   python scripts/make_hash_lock.py          (needs network; check with --check offline)",
        f"# generated {dt.date.today().isoformat()}: {len(first)} packages, {n_files} hashes",
        "# covers: [project].dependencies, the [all] extra (fastapi, uvicorn, pytest), setuptools (build backend), pip",
        "# not covered, installed unpinned on request: extras api, ml, test, ci, research (yfinance); bloomberg (blpapi:",
        "#   Bloomberg's index only, never PyPI) and lseg",
        "# install: pip install --require-hashes -r requirements-lock.txt && pip install --no-deps --no-build-isolation -e .",
        f"# python: {' '.join(PYTHONS)}",
        f"# platforms: {' '.join(PLATFORMS)}",
        "",
    ]
    return "\n".join(head + out) + "\n"


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--check", action="store_true", help="offline: exit 1 if the lock misses or mis-pins a dependency")
    ap.add_argument("--out", type=Path, default=LOCK)
    a = ap.parse_args(argv)
    if a.check:
        problems = check(a.out)
        for p in problems:
            print(f"lock: {p}")
        if not problems:
            pins, header = parse_lock(a.out.read_text())
            print(f"lock ok: {len(pins)} packages hash-pinned, every install dependency in pyproject.toml covered "
                  f"(python {header['python']}; {header.get('platforms', '?')})")
        return 1 if problems else 0
    a.out.write_text(generate())
    problems = check(a.out)
    print(f"wrote {a.out}" + ("" if not problems else "\n" + "\n".join(problems)))
    return 1 if problems else 0


if __name__ == "__main__":
    sys.exit(main())
