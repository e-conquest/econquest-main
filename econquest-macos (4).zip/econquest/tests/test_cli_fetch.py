"""econquest fetch: review ledger, four-eyes flags and replayable vintages (EQ-C-0012; HO-20261023-A-C-002/-006/-007).
No network: fetch_all is replaced by a fixed report; the data folder is a temp copy."""
import shutil
from pathlib import Path

import pandas as pd
import pytest

from econquest import cli
from econquest.ingestion import feeds, load_universe, load_decisions, record_decision
from econquest.ingestion.feeds import FetchReport

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"


def copy_data(dst: Path) -> Path:
    shutil.copytree(DATA, dst, ignore=shutil.ignore_patterns("vintages", "snapshots", "review_ledger.csv", "panel", "*.lock"))
    return dst


@pytest.fixture
def env(tmp_path, monkeypatch):
    d = copy_data(tmp_path / "data")
    u = load_universe(d); names = u.names
    ind = pd.DataFrame(index=u.indicators["id"].astype(str), columns=names, dtype=float)
    ind.at["1.3", names[0]] = 9999.0                                             # range hold
    ind.at["5.5", names[1]] = float(pd.to_numeric(u.indicators.set_index("id").at["5.5", names[1]])) + 0.1   # ok
    prof = pd.DataFrame(index=names, columns=["pop", "exports", "reserves", "fx3m", "policy", "equity_vol"], dtype=float)
    calls = []

    def fake_fetch_all(u_, **kw):
        calls.append(kw)
        return FetchReport(ind.copy(), prof.copy(), pd.DataFrame(), {"weo": "ok (1 rows)"}, {})
    monkeypatch.setattr(feeds, "fetch_all", fake_fetch_all)
    return d, tmp_path / "out", names, calls


def fetch(d, out, *extra):
    cli.main(["--data", str(d), "--out", str(out), "fetch", *extra])


@pytest.mark.parametrize("extra", [[], ["--author", "Sam"], ["--author", "Sam", "--approver", " sam "]])
def test_force_without_approval_fails_clearly_before_fetching(env, extra):
    d, out, _, calls = env
    before = (d / "indicators.csv").read_bytes()
    with pytest.raises(SystemExit) as e:
        fetch(d, out, "--apply", "--force", *extra)
    msg = str(e.value)
    assert "--author" in msg and "--self-approved" in msg
    assert calls == [] and (d / "indicators.csv").read_bytes() == before


def test_force_self_approved_applies_and_ledgers(env, capsys):
    d, out, names, _ = env
    fetch(d, out, "--apply", "--force", "--author", "Sam", "--self-approved")
    assert "Applied:" in capsys.readouterr().out
    ind = pd.read_csv(d / "indicators.csv", dtype={"id": str}).set_index("id")
    assert float(ind.at["1.3", names[0]]) == 9999.0                              # the held cell was forced in
    led = load_decisions(d)
    forced = led[led["note"] == "forced"]
    assert len(forced) >= 1 and set(forced["self_approved"]) == {"yes"} and set(forced["author"]) == {"Sam"}
    vid = forced["vintage_id"].iloc[0]
    assert vid and (d / "live" / "snapshots" / f"{vid}-inputs").is_dir()           # vintage_id reached apply_report


def test_four_eyes_force_with_approver(env):
    d, out, _, _ = env
    fetch(d, out, "--apply", "--force", "--author", "Ana", "--approver", "Sam")
    led = load_decisions(d)
    assert set(led.loc[led["note"] == "forced", "approver"]) == {"Sam"}


def test_second_fetch_keeps_decisions_in_review_csv(env):
    d, out, names, _ = env
    fetch(d, out)
    record_decision(d, "Inputs", "1.3", names[0], "reject", "Sam", note="bad print")
    fetch(d, out)                                                                 # gate rerun rewrites review.csv
    rev = pd.read_csv(d / "live" / "review.csv", dtype=str)
    row = rev[(rev["table"] == "Inputs") & (rev["key"] == "1.3") & (rev["country"] == names[0])].iloc[0]
    assert row["decision"] == "reject" and row["author"] == "Sam"


def test_apply_without_force_needs_no_author(env, capsys):
    d, out, names, _ = env
    fetch(d, out, "--apply")
    o = capsys.readouterr().out
    assert "Applied:" in o and "held cells were not applied" in o
    ind = pd.read_csv(d / "indicators.csv", dtype={"id": str}).set_index("id")
    assert float(ind.at["1.3", names[0]]) != 9999.0


def test_gate_gets_data_dir_and_flags_vintage_jumps(tmp_path, monkeypatch):
    """HO-20261023-A-C-009: the gate runs with data_dir, so a jump against the previous vintage is held as 'vintage: ...'."""
    d = copy_data(tmp_path / "data")
    u = load_universe(d); names = u.names
    seed = float(pd.to_numeric(u.indicators.set_index("id").at["5.5", names[1]]))
    prof = pd.DataFrame(index=names, columns=["pop", "exports", "reserves", "fx3m", "policy", "equity_vol"], dtype=float)
    vals = iter([seed + 0.1, seed * 5 + 50])

    def fake_fetch_all(u_, **kw):
        ind = pd.DataFrame(index=u.indicators["id"].astype(str), columns=names, dtype=float)
        ind.at["5.5", names[1]] = next(vals)
        return FetchReport(ind, prof.copy(), pd.DataFrame(), {"weo": "ok (1 rows)"}, {})
    monkeypatch.setattr(feeds, "fetch_all", fake_fetch_all)
    seen = []
    real_gate = feeds.quality_gate
    monkeypatch.setattr(feeds, "quality_gate", lambda *a, **k: seen.append(k.get("data_dir")) or real_gate(*a, **k))
    fetch(d, tmp_path / "out")
    fetch(d, tmp_path / "out")                    # earlier vintage now present
    assert seen == [d, d]
    rev = pd.read_csv(d / "live" / "review.csv", dtype=str)
    row = rev[(rev["table"] == "Inputs") & (rev["key"] == "5.5") & (rev["country"] == names[1])].iloc[0]
    assert row["status"] == "hold" and "vintage" in row["reason"]


# ---------------------------------------------------------------- missing-cell report on every pull (EQ-C-0044, HO-20261023-A-C-014)
def test_fetch_prints_missing_cell_report_and_writes_csv(env, capsys):
    d, out, names, _ = env
    fetch(d, out)
    o = capsys.readouterr().out
    assert "Missing cells: {" in o and '"n_countries": 18' in o and "Countries below the 60% live target: 18 of 18" in o
    cells = pd.read_csv(d / "live" / "missing_cells.csv", dtype=str)
    assert list(cells.columns) == ["key", "country", "source_class", "reason", "seed_present"]
    assert set(cells["country"]) == set(names)
    held = cells[(cells["key"] == "1.3") & (cells["country"] == names[0])]
    assert list(held["reason"]) == ["held by quality gate"]
    assert cells[(cells["key"] == "5.5") & (cells["country"] == names[1])].empty            # the live cell is not missing


def test_fetch_carries_on_when_the_report_fails(env, monkeypatch, capsys):
    from econquest.ingestion import universe

    def boom(data_dir, target=0.6):
        raise FileNotFoundError("no live_inputs.csv")
    monkeypatch.setattr(universe, "missing_cell_report", boom)
    d, out, _, _ = env
    fetch(d, out, "--apply")
    o, e = capsys.readouterr()
    assert "warning: missing-cell report not written: FileNotFoundError: no live_inputs.csv" in e
    assert "Applied:" in o and not (d / "live" / "missing_cells.csv").exists()


def test_fetch_on_staged_88_country_folder(tmp_path, monkeypatch, capsys):
    """Offline pull on the staged universe (as tests/test_universe.py::test_stage_fetch_and_missing_report): the report
    covers all 88 countries and lists their missing cells."""
    from econquest.ingestion.universe import stage_data_dir
    staging = DATA / "panel" / "universe_staging"
    if not (staging / "countries.csv").exists():
        pytest.skip("data/panel/universe_staging not built")
    d = stage_data_dir(staging, tmp_path / "st88", copy_data(tmp_path / "data"))

    def weo(self, isos, codes=feeds.WEO_CODES):
        rows = [{"iso": i, "series": s, "period": y, "value": 50.0 + (y % 3)} for i in isos for s in codes for y in range(2005, 2029)]
        return feeds._long(rows, "fake weo")
    monkeypatch.setattr(feeds.WeoFeed, "fetch", weo)
    fetch(d, tmp_path / "out", "--only", "weo", "--year", "2026")
    o = capsys.readouterr().out
    assert '"n_countries": 88' in o and " of 88" in o and "Turkey" in o
    cells = pd.read_csv(d / "live" / "missing_cells.csv", dtype=str)
    assert cells["country"].nunique() == 88 and len(load_universe(d).names) == 88
    assert {"manual", "planned_api"} <= set(cells["reason"])


# ---------------------------------------------------------------- HO-20261024-A-C-002 (EQ-A-0040): Yahoo is not a desk feed
@pytest.mark.parametrize("only", ["yahoo", "weo,yahoo", "YFinance"])
def test_only_yahoo_is_a_one_line_exit_before_any_request(tmp_path, monkeypatch, only):
    """The real fetch_all refuses Yahoo before any request; the CLI shows it as one line, not a traceback."""
    import socket
    import urllib.request
    monkeypatch.setattr(socket, "create_connection", lambda *a, **k: pytest.fail("network call"))
    monkeypatch.setattr(urllib.request, "urlopen", lambda *a, **k: pytest.fail("network call"))
    d = copy_data(tmp_path / "data")
    before = {f: f.stat().st_mtime_ns for f in d.rglob("*")}
    with pytest.raises(SystemExit) as e:
        fetch(d, tmp_path / "out", "--only", only)
    msg = str(e.value.code)
    assert msg.startswith("fetch: feed ") and "Yahoo Finance is not a desk feed" in msg and "\n" not in msg
    assert {f: f.stat().st_mtime_ns for f in d.rglob("*")} == before                # nothing saved, no vintage


def test_fetch_help_offers_no_yahoo_feed(capsys):
    with pytest.raises(SystemExit):
        cli.main(["fetch", "--help"])
    h = " ".join(capsys.readouterr().out.split())
    assert "weo,worldbank,bis,fx" in h and "bis,yahoo" not in h and "ECB" in h and "WS_XRU" in h
