"""Run versioning: data_hash covers every input (EQ-C-0008); as_of and run_hash (EQ-C-0011)."""
import datetime as dt
import shutil
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest import versioning as V

DATA = ROOT / "data"


@pytest.fixture()
def data_copy(tmp_path):
    """A small data folder: a few fixed files, a panel, a live pull, a vintage archive and the outputs the engine writes."""
    d = tmp_path / "data"
    (d / "panel").mkdir(parents=True); (d / "live" / "vintages" / "2026-10-23").mkdir(parents=True)
    for f in ("indicators.csv", "countries.csv"):
        shutil.copy(DATA / f, d / f)
    (d / "cds_quotes.csv").write_text("country,date,tenor_y,spread_bp,recovery,source\n")
    (d / "dsa_inputs.csv").write_text("country,st_debt\nX,1\n")
    (d / "panel" / "sovereign_defaults.csv").write_text("iso,start\nARG,2001\n")
    (d / "panel" / "hazard_panel.csv").write_text("iso,year,event\nARG,2000,0\n")
    (d / "panel" / "README.md").write_text("notes\n")
    (d / "live" / "live_inputs.csv").write_text("id,X\n1,2\n")
    (d / "live" / "raw_weo.csv").write_text("iso,series,period,value\n")
    (d / "live" / "feeds.json").write_text('{"feeds": []}')
    (d / "live" / "diff_vs_seed.csv").write_text("table,key\n")
    (d / "live" / "vintages" / "2026-10-23" / "live_inputs.csv").write_text("id,X\n1,2\n")
    (d / "forecast_record.csv").write_text("date\n"); (d / "benchmarks.csv").write_text("date\n"); (d / "audit_trail.csv").write_text("x\n")
    return d


def test_data_files_covers_inputs_and_skips_archives_and_outputs(data_copy):
    files = V.data_files(data_copy)
    for rel in ("indicators.csv", "countries.csv", "cds_quotes.csv", "dsa_inputs.csv", "panel/sovereign_defaults.csv",
                "panel/hazard_panel.csv", "live/live_inputs.csv", "live/raw_weo.csv", "live/feeds.json"):
        assert rel in files, rel
    assert not any(f.startswith("live/vintages/") for f in files)
    for rel in ("live/diff_vs_seed.csv", "forecast_record.csv", "benchmarks.csv", "audit_trail.csv", "panel/README.md"):
        assert rel not in files, rel
    assert files == sorted(files)


@pytest.mark.parametrize("rel", ["cds_quotes.csv", "dsa_inputs.csv", "panel/sovereign_defaults.csv", "panel/hazard_panel.csv",
                                 "live/live_inputs.csv", "live/feeds.json"])
def test_changing_an_input_changes_data_hash(data_copy, rel):
    h0 = V.data_hash(data_copy)
    p = data_copy / rel
    p.write_text(p.read_text() + "\n")
    assert V.data_hash(data_copy) != h0


def test_new_panel_file_is_discovered(data_copy):
    h0 = V.data_hash(data_copy)
    (data_copy / "panel" / "weo_history.csv").write_text("iso,series\n")
    assert "panel/weo_history.csv" in V.data_files(data_copy) and V.data_hash(data_copy) != h0


def test_archives_and_outputs_do_not_change_data_hash(data_copy):
    h0 = V.data_hash(data_copy)
    (data_copy / "live" / "vintages" / "2026-10-23" / "live_inputs.csv").write_text("changed\n")
    (data_copy / "live" / "vintages" / "2026-10-24").mkdir()
    (data_copy / "live" / "vintages" / "2026-10-24" / "raw_bis.csv").write_text("new\n")
    (data_copy / "live" / "diff_vs_seed.csv").write_text("changed\n")
    (data_copy / "forecast_record.csv").write_text("date\n2026-10-23\n")
    assert V.data_hash(data_copy) == h0


def test_repo_data_includes_new_inputs():
    files = V.data_files(DATA)
    assert "cds_quotes.csv" in files and "dsa_inputs.csv" in files and any(f.startswith("panel/") for f in files)


def test_stamp_without_as_of_is_backward_compatible(data_copy):
    s = V.stamp(data_copy)
    for k in ("code_version", "code_hash", "data_hash", "data_files", "python", "numpy", "pandas", "scipy", "platform"):
        assert k in s
    assert s["data_hash"] == V.data_hash(data_copy) and s["as_of"] is None
    assert s["run_hash"] == V.run_hash(s["code_hash"], s["data_hash"], None) and len(s["run_hash"]) == 16


def test_as_of_changes_run_hash_not_data_hash(data_copy):
    a, b = V.stamp(data_copy, as_of="2026-10-23"), V.stamp(data_copy, as_of="2026-09-30")
    assert a["as_of"] == "2026-10-23" and b["as_of"] == "2026-09-30"
    assert a["data_hash"] == b["data_hash"] and a["code_hash"] == b["code_hash"]
    assert a["run_hash"] != b["run_hash"] and a["run_hash"] != V.stamp(data_copy)["run_hash"]
    assert V.stamp(data_copy, as_of=dt.date(2026, 10, 23))["run_hash"] == a["run_hash"]   # date objects normalise to ISO


def test_run_hash_moves_with_data(data_copy):
    a = V.stamp(data_copy, as_of="2026-10-23")
    (data_copy / "cds_quotes.csv").write_text("country,date\nX,2026-10-23\n")
    assert V.stamp(data_copy, as_of="2026-10-23")["run_hash"] != a["run_hash"]


def test_with_as_of_restamps_a_load_time_stamp(data_copy):
    s = V.stamp(data_copy)
    t = V.with_as_of(s, "2026-10-23")
    assert t == V.stamp(data_copy, as_of="2026-10-23") and s["as_of"] is None   # copy, not mutation


# ---- EQ-C-0015 (HO-20261023-A-C-006 items 3-4): replay fields --------------------------------------------------
import hashlib  # noqa: E402

REPLAY = {"vintage_id": "2026-10-23T1820", "inputs_hash": "abc123", "snapshot": "live/snapshots/x", "drift": []}


def test_non_replay_run_hash_is_the_pre_replay_payload(data_copy):
    s = V.stamp(data_copy, as_of="2026-10-23")
    old = hashlib.sha256(f"code={s['code_hash']};data={s['data_hash']};as_of=2026-10-23;".encode()).hexdigest()[:16]
    assert s["run_hash"] == old and s["vintage_id"] is None and s["inputs_hash"] is None
    assert V.with_replay(s, None)["run_hash"] == V.with_replay(s, {})["run_hash"] == old


def test_replay_fields_recorded_and_hashed(data_copy):
    base = V.stamp(data_copy, as_of="2026-10-23")
    r = V.stamp(data_copy, as_of="2026-10-23", replay=REPLAY)
    assert r["vintage_id"] == "2026-10-23T1820" and r["inputs_hash"] == "abc123"
    assert r["data_hash"] == base["data_hash"] and r["run_hash"] != base["run_hash"]
    assert V.with_replay(base, REPLAY) == r                                       # restamp == stamp
    assert V.with_as_of(V.with_replay(V.stamp(data_copy), REPLAY), "2026-10-23") == r   # order does not matter
    assert V.with_replay(base, {**REPLAY, "inputs_hash": "def456"})["run_hash"] != r["run_hash"]
    assert "snapshot" not in r and "drift" not in r


def test_snapshots_vintages_and_replay_manifest_stay_out_of_data_hash(data_copy):
    h0 = V.data_hash(data_copy)
    snap = data_copy / "live" / "snapshots" / "2026-10-23T1820-inputs"
    snap.mkdir(parents=True)
    (snap / "manifest.json").write_text("{}"); (snap / "indicators.csv").write_text("frozen\n")
    (data_copy / "live" / "snapshots" / "index.csv").write_text("vintage_id\n")
    (data_copy / "replay_manifest.json").write_text('{"vintage_id": "x"}')
    (data_copy / "live" / "vintages" / "2026-10-23" / "raw_bis.csv").write_text("x\n")
    assert V.data_hash(data_copy) == h0
    assert not any(f.startswith(("live/snapshots/", "live/vintages/")) or f == "replay_manifest.json" for f in V.data_files(data_copy))
