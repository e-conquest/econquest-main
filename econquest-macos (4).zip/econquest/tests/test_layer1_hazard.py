"""Layer 1 fitted mode: run-time predictors aligned with training (EQ-B-0013) and no wrong-unit fallback (GOV-046)."""
import dataclasses
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.config import Settings  # noqa: E402
from econquest.engine import layer1_hazard as L1  # noqa: E402
from econquest.engine.common import expit  # noqa: E402
from econquest.ingestion import load_universe  # noqa: E402
from econquest.scorecard import score_universe  # noqa: E402
from econquest.validation import hazard_panel as hp  # noqa: E402

FEATS = ["debt_gdp", "primary_deficit", "current_account", "real_growth"]


@pytest.fixture(scope="module")
def base():
    u = load_universe(ROOT / "data")
    s = Settings.load(ROOT / "data" / "assumptions.json").copy_with(as_of="2026-10-23")
    p4 = score_universe(u, s).pillar_aggregated.loc[4]
    return u, s, p4


def _identity_weo(u, years=range(2020, 2028)):
    """WEO history whose value encodes (country index, year): value = k + (year - 2000), so the year used is visible."""
    rows = []
    for k, iso in enumerate(u.countries["iso"]):
        for y in years:
            for code in hp.WEO_CODES:
                rows.append({"iso": iso, "series": code, "period": y, "value": float(k + (y - 2000)), "source": "test"})
    return pd.DataFrame(rows)


def _block(lag="absent"):
    b = {"features": FEATS, "coef": {"debt_gdp": 0.4, "primary_deficit": 0.3, "current_account": -0.2, "real_growth": -0.1},
         "intercept": -4.0, "scale": {f: [20.0, 5.0] for f in FEATS}, "fitted_on": "test"}
    if lag != "absent":
        b["predictor_lag"] = lag
    return b


def _fitted(s, block):
    return s.copy_with(**{"layer1.mode": "fitted", "layer1_fitted": block})


def test_resolve_predictor_lag():
    assert L1.resolve_predictor_lag({"predictor_lag": 0}) == (0, "layer1_fitted.predictor_lag")
    assert L1.resolve_predictor_lag({"predictor_lag": 2})[0] == 2
    lag, src = L1.resolve_predictor_lag({"coef": {}})          # block written before EQ-B-0006
    assert lag == 1 and "assumed" in src
    assert L1.resolve_predictor_lag(None)[0] == 1
    with pytest.raises(ValueError):
        L1.resolve_predictor_lag({"predictor_lag": -1})


@pytest.mark.parametrize("lag", [1, 0, "absent"])
def test_fitted_mode_uses_as_of_year_minus_predictor_lag(base, lag):
    """Regression for EQ-B-0013: the fitted model trained with lag 1 (row t <- year t-1) was scored on year-t WEO values."""
    u, s, p4 = base
    u2 = dataclasses.replace(u, weo_raw=_identity_weo(u))
    with warnings.catch_warnings():
        warnings.simplefilter("error")                        # complete history: no fallback warning
        out = L1.run_layer1(u2, _fitted(s, _block(lag)), p4)
    eff = 1 if lag == "absent" else lag
    year = 2026 - eff
    m = out.attrs["model"]
    assert m["mode"] == "fitted" and "fitted_fallback" not in m
    assert m["predictor_year"] == year and m["predictor_lag"] == eff
    assert m["weo_aligned"]["debt_gdp"] == f"WEO GGXWDG_NGDP year {year}"
    iso_k = {iso: k for k, iso in enumerate(u.countries["iso"])}
    prof = u.countries.set_index("country")
    for c in u.names:
        enc = iso_k[prof.at[c, "iso"]] + (year - 2000)
        assert out.at[c, "debt_gdp"] == enc and out.at[c, "current_account"] == enc and out.at[c, "real_growth"] == enc
        assert out.at[c, "primary_deficit"] == -enc        # panel transform: negate the primary balance
    # the score is the block applied to those values, exactly as FitResult.predict would on the training panel
    b = _block(lag)
    z = np.column_stack([(out[f].to_numpy(dtype=float) - 20.0) / 5.0 for f in FEATS])
    np.testing.assert_allclose(out["pd_hazard"].to_numpy(), expit(b["intercept"] + z @ np.array([b["coef"][f] for f in FEATS])))


def test_fitted_block_round_trip_from_panel_fit(base):
    """A block written by fit_and_validate on a lag-1 panel is read back with lag 1 at run time."""
    u, s, p4 = base
    weo = _identity_weo(u, years=range(1990, 2028))
    isos = list(u.countries["iso"])
    ev = pd.DataFrame({"iso": isos[:6], "start": [2000, 2003, 2006, 2009, 2012, 2015], "end": [2001, 2004, 2007, 2010, 2013, 2016]})
    panel = hp.panel_from_long(weo, None, ev, features=["debt_gdp", "real_growth"], start=1992, end=2024, forecast_cutoff=2024)
    res = hp.fit_and_validate(panel, features=["debt_gdp", "real_growth"], oos_start=2010, min_train_events=1)
    block = res.fitted_block()
    assert block["predictor_lag"] == 1
    out = L1.run_layer1(dataclasses.replace(u, weo_raw=weo), _fitted(s, block), p4)
    assert out.attrs["model"]["predictor_year"] == 2025 and out.attrs["model"]["predictor_lag_source"] == "layer1_fitted.predictor_lag"
    np.testing.assert_allclose(out["pd_hazard"].to_numpy(), res.predict(out))


def test_fitted_mode_without_weo_history_refuses_the_gap_fallback(base):
    """GOV-046: without WEO history the old code fed minus indicator 1.6 (a gap) as primary_deficit (a level)."""
    u, s, p4 = base
    u0 = dataclasses.replace(u, weo_raw=None)
    with pytest.warns(RuntimeWarning, match="GOV-046"):
        out = L1.run_layer1(u0, _fitted(s, _block(1)), p4)
    m = out.attrs["model"]
    assert m["mode"] == "paper_standardized" and "refused" in m["fitted_fallback"]
    paper = L1.run_layer1(u0, s, p4)
    np.testing.assert_allclose(out["pd_model"].to_numpy(), paper["pd_model"].to_numpy())
    # the fitted inputs are never silently the indicator gap
    X = L1.build_features(u0, p4, as_of="2026-10-23", predictor_lag=1, weo_aligned=["primary_deficit"])
    assert X["primary_deficit"].isna().all() and "GOV-046" in X.attrs["primary_deficit_source"]


def test_fitted_mode_refuses_when_one_country_lacks_the_lagged_year(base):
    u, s, p4 = base
    weo = _identity_weo(u)
    iso0 = u.countries["iso"].iloc[0]
    weo = weo[~((weo["iso"] == iso0) & (weo["series"] == "GGXONLB_NGDP") & (weo["period"] == 2025))]
    with pytest.warns(RuntimeWarning, match="primary_deficit"):
        out = L1.run_layer1(dataclasses.replace(u, weo_raw=weo), _fitted(s, _block(1)), p4)
    assert out.attrs["model"]["mode"] == "paper_standardized"
    assert u.countries["country"].iloc[0] in out.attrs["model"]["fitted_fallback"]


def test_paper_mode_features_do_not_depend_on_the_lag(base):
    u, s, p4 = base
    if u.weo_raw is None:
        pytest.skip("no data/live/raw_weo.csv")
    x0 = L1.build_features(u, p4, as_of="2026-10-23", predictor_lag=0)
    x1 = L1.build_features(u, p4, as_of="2026-10-23", predictor_lag=1)
    pd.testing.assert_frame_equal(x0[L1.FEATURES], x1[L1.FEATURES])
    assert x0.attrs["predictor_year"] == 2026 and x1.attrs["predictor_year"] == 2025
    with pytest.raises(ValueError):
        L1.build_features(u, p4, as_of="2026-10-23", weo_aligned=["pitf_instability"])   # not a WEO series


# ---------------------------------------------------------------- EQ-B-0029: World Bank-sourced features are not aligned

def _block_with(extra: dict, lag=1):
    b = _block(lag)
    b["features"] = FEATS + list(extra)
    b["coef"] = {**b["coef"], **{f: 0.5 for f in extra}}
    b["scale"] = {**b["scale"], **extra}
    return b


@pytest.mark.parametrize("feature,scale", [("stfx_debt_reserves", [50.0, 30.0]), ("reserves_months_imports", [6.0, 4.0]),
                                           ("pitf_instability", [1.5, 1.0]), ("commodity_export_shock", [0.0, 2.0])])
def test_fitted_mode_refuses_unaligned_features(base, feature, scale):
    """Regression for EQ-B-0029: a fitted block using a World Bank-sourced panel feature (or a non-panel feature) was
    scored on the indicator-table definitions (2.9, reserves / exports x 12, pillar 4 / 25) without a word."""
    u, s, p4 = base
    u2 = dataclasses.replace(u, weo_raw=_identity_weo(u))          # WEO inputs complete: only the WB feature is wrong
    with pytest.warns(RuntimeWarning, match="EQ-B-0029"):
        out = L1.run_layer1(u2, _fitted(s, _block_with({feature: scale})), p4)
    m = out.attrs["model"]
    assert m["mode"] == "paper_standardized" and "refused" in m["fitted_fallback"] and feature in m["fitted_fallback"]
    assert set(m["fitted_unaligned"]) == {feature}
    paper = L1.run_layer1(u2, s, p4)
    pd.testing.assert_series_equal(out["pd_model"], paper["pd_model"], check_exact=True)


def test_unaligned_fitted_features_names_the_panel_series():
    un = L1.unaligned_fitted_features(["debt_gdp", "primary_deficit", "stfx_debt_reserves", "reserves_months_imports", "pitf_instability"])
    assert set(un) == {"stfx_debt_reserves", "reserves_months_imports", "pitf_instability"}
    assert "DT.DOD.DSTC.IR.ZS" in un["stfx_debt_reserves"] and "FI.RES.TOTL.MO" in un["reserves_months_imports"]
    assert "PV.EST" in un["pitf_instability"] and "pillar 4 aggregate / 25" in un["pitf_instability"]
    assert L1.unaligned_fitted_features(hp.DEFAULT_FEATURES) == {}           # the WEO-only default feature set passes
    for f, (tab, _code, _how) in hp.PANEL_FEATURES.items():                  # every non-WEO panel feature is caught
        assert (f in L1.unaligned_fitted_features([f])) == (tab != "weo")


def test_wb_refusal_leaves_weo_only_fitted_and_paper_mode_unchanged(base):
    """The shipped WEO-only fitted block still runs fitted; paper mode never consults the check."""
    u, s, p4 = base
    u2 = dataclasses.replace(u, weo_raw=_identity_weo(u))
    with warnings.catch_warnings():
        warnings.simplefilter("error", RuntimeWarning)
        out = L1.run_layer1(u2, _fitted(s, _block(1)), p4)
        paper = L1.run_layer1(u2, s, p4)
    assert out.attrs["model"]["mode"] == "fitted" and "fitted_unaligned" not in out.attrs["model"]
    assert paper.attrs["model"]["mode"] == "paper_standardized" and "fitted_fallback" not in paper.attrs["model"]
    shipped = s.get("layer1_fitted")
    if shipped:
        assert L1.unaligned_fitted_features(shipped["features"]) == {}
