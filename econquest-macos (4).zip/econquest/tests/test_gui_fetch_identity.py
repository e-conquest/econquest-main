"""GUI fetch jobs carry no operator identity, so they cannot force an apply or claim a four-eyes approval (EQ-C-0019)."""
import pytest

from econquest import cli
from econquest.presentation import gui


class FakePopen:
    last = None

    def __init__(self, argv, **kw):
        FakePopen.last = self
        self.argv = argv
        self.stdout = iter(())
        self.returncode = 0

    def poll(self):
        return 0

    def wait(self):
        return 0


@pytest.fixture
def jobs(monkeypatch, tmp_path):
    monkeypatch.setenv("ECONQUEST_ACTION_LOG", str(tmp_path / "actions.jsonl"))   # fetch --apply is logged (EQ-C-0035)
    monkeypatch.setattr(gui.subprocess, "Popen", FakePopen)
    return gui.Jobs(str(tmp_path), str(tmp_path))


@pytest.mark.parametrize("args", [
    ["--apply", "--force", "--author", "Sam", "--self-approved"],
    ["--apply", "--forc", "--auth=Sam", "--approver", "Bob"],
    ["--apply", "--self", "--appr", "Bob"],
])
def test_gui_fetch_strips_identity_and_force_flags(jobs, monkeypatch, args):
    jobs.start("fetch", args)
    tail = FakePopen.last.argv[FakePopen.last.argv.index("fetch") + 1:]
    assert tail == ["--apply"]
    seen = []
    monkeypatch.setattr(cli, "cmd_fetch", lambda a: seen.append((a.apply, a.force, a.author, a.approver, a.self_approved)))
    cli.main(["fetch", *tail])
    assert seen == [(True, False, None, None, False)]


def test_identity_flags_are_kept_for_other_commands(jobs):
    jobs.start("garch", ["--quotes", "q.csv"])
    assert FakePopen.last.argv[-2:] == ["--quotes", "q.csv"]
