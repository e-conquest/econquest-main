"""Second-line replication from the run archive (EQ-B-0058): fixture archive, read-only, statuses, hash checks,
number scan, zip facts, the isolated rerun worker, and a smoke run on the real archive."""
import json
import os
import sqlite3
import zipfile
from pathlib import Path
from types import SimpleNamespace

import pandas as pd
import pytest

from econquest import versioning as V
from econquest.validation import _rerun_worker as W
from econquest.validation import replicate_archive as R

ROOT = Path(__file__).resolve().parents[1]


def _versions(code="c0de000000000001", files=None, as_of="2026-10-23", version="0.1.0"):
    files = files or {"assumptions.json": "aaaaaaaaaaaaaaaa", "limits.json": "bbbbbbbbbbbbbbbb"}
    dh = V._combine(files)
    return {"code_version": version, "code_hash": code, "data_hash": dh, "data_files": files, "as_of": as_of,
            "vintage_id": None, "inputs_hash": None, "run_hash": V.run_hash(code, dh, as_of)}


def _run(run_id, metrics, versions, country=None):
    v = dict(versions)
    return {"summary": {"run_id": run_id, "metrics": metrics, "versions": {k: x for k, x in v.items() if k != "data_files"}},
            "settings": {"probability": {"w_m": 0.5}}, "provenance": {"versions": v},
            "country": country or [{"country": "Aland", "pd_default": 0.2356}, {"country": "Bora", "pd_default": 0.05}]}


@pytest.fixture
def arch(tmp_path):
    a = tmp_path / "archive"; a.mkdir()
    v = _versions()
    runs = {"20261023T100000-base": _run("20261023T100000-base", {"var99_mm": 67.9022, "es99_mm": 86.8484}, v),
            "20261023T100005-stress-A": _run("20261023T100005-stress-A", {"var99_mm": 120.0, "es99_mm": 152.3522}, v),
            "20261023T110000-base": _run("20261023T110000-base", {"var99_mm": 63.9769, "es99_mm": 83.0212},
                                         _versions(code="c0de000000000002", version="0.1.2"),
                                         [{"country": "Aland", "pd_default": 0.1592}, {"country": "Bora", "pd_default": 0.05}])}
    for rid, d in runs.items():
        (a / f"{rid}.json").write_text(json.dumps(d))
    (a / "20261023T100000-base_paths.npz").write_bytes(b"not json")
    db = tmp_path / "store.sqlite"
    con = sqlite3.connect(db)
    con.execute("create table runs (run_id TEXT PRIMARY KEY, created_at TEXT, label TEXT, settings TEXT, provenance TEXT, summary TEXT)")
    for rid, d in runs.items():
        con.execute("insert into runs values (?,?,?,?,?,?)", (rid, "", "", "{}", "{}", json.dumps(d["summary"])))
    con.commit(); con.close()
    rel = tmp_path / "releases"; rel.mkdir()
    (rel / "note.md").write_text("# Release 9.9.9\n\nBase run `20261023T100000-base`: VaR99 67.90, ES99 86.85 $mm, "
                                 "ES99 under A 152.4 (+75.9%). Tier 1. Kupiec p=0.043. Paths 4,096.\n")
    return SimpleNamespace(dir=a, db=db, rel=rel, tmp=tmp_path)


B, S, B2 = "20261023T100000-base", "20261023T100005-stress-A", "20261023T110000-base"


def _claims():
    C = R.Claim
    return [C("T-01", "9.9.9", "note.md", "base VaR99", "67.90", ev=lambda c: c.metric(B, "var99_mm")),
            C("T-02", "9.9.9", "note.md", "base ES99", "86.85", ev=lambda c: c.metric(B, "es99_mm")),
            C("T-03", "9.9.9", "note.md", "stress A ES99", "152.4", ev=R._stress_es(B, "A")),
            C("T-04", "9.9.9", "note.md", "stress A change", "+75.9%", ev=R._stress_chg(B, "A")),
            C("T-05", "9.9.9", "note.md", "backtest Kupiec", "0.043", why="not archived"),
            C("T-06", "9.9.9", "note.md", "missing run", "1.0", ev=lambda c: c.metric("20261023T999999-base", "var99_mm")),
            C("T-07", "9.9.9", "note.md", "code hash", "c0de000000000001", ev=lambda c: c.version(B, "code_hash"), kind="hash"),
            C("T-08", "9.9.9", "note.md", "rerun figure", "1.0", ev=lambda c: c.rerun("job", "var99_mm")),
            C("T-09", "9.9.9", "note.md", "PD move (pp), from rounded levels", "-7.7", ev=R._pd_move(B, B2, "Aland"))]


def _go(arch, out, **kw):
    return R.replicate_archive(out, archive=arch.dir, db=arch.db, releases=arch.rel, claims=_claims(), labels={"note.md": "1 4,096"},
                               findings={}, log=lambda *_: None, **kw)


def test_statuses_and_outputs(arch):
    res = _go(arch, arch.tmp / "out")
    st = res["rows"].set_index("id")["status"].to_dict()
    assert st == {"T-01": "MATCH", "T-02": "MATCH", "T-03": "MATCH", "T-04": "MISMATCH", "T-05": "UNARCHIVED",
                  "T-06": "MISSING_ARCHIVE", "T-07": "MATCH", "T-08": "NOT_RUN", "T-09": "MISMATCH"}
    rows = res["rows"].set_index("id")
    assert rows.loc["T-03", "run_id"] == S and rows.loc["T-01", "source"] == "archive"
    assert rows.loc["T-09", "value"] == "-7.64"                       # double rounding: 23.6 - 15.9 = 7.7, exact 7.64
    df = pd.read_csv(res["csv"])
    assert list(df.columns) == R.COLUMNS and len(df) == 9
    md = Path(res["md"]).read_text()
    assert "| 9.9.9 | 4 | 2 | 1 | 1 | 1 |" in md and "T-04" in md.split("## Mismatches")[1]
    assert res["unexplained"] == 3                                     # 2 mismatches + 1 missing run, none with a finding


def test_known_finding_explains_a_mismatch(arch):
    res = R.replicate_archive(arch.tmp / "o", archive=arch.dir, db=arch.db, releases=arch.rel, claims=_claims()[3:4],
                              findings={"T-04": "VF-999"}, log=lambda *_: None)
    assert res["rows"].iloc[0]["finding"] == "VF-999" and res["unexplained"] == 0


def test_hash_check_reports_stamp_and_integrity(arch):
    res = _go(arch, arch.tmp / "out")
    hc = res["rows"].set_index("id").loc["T-01", "hash_check"]
    assert "integrity ok" in hc and "stamped 0.1.0 (pre-bump for 9.9.9)" in hc
    d = json.loads((arch.dir / f"{B}.json").read_text())                # tamper: run_hash no longer recomputes
    d["provenance"]["versions"]["run_hash"] = "0" * 16
    (arch.dir / f"{B}.json").write_text(json.dumps(d))
    hc = _go(arch, arch.tmp / "out2")["rows"].set_index("id").loc["T-01", "hash_check"]
    assert "INTEGRITY run_hash recomputes to" in hc


def test_sqlite_disagreement_is_a_problem(arch):
    con = sqlite3.connect(arch.db)
    con.execute("update runs set summary = ? where run_id = ?", (json.dumps({"metrics": {"var99_mm": 1.0}}), B))
    con.commit(); con.close()
    assert "SQLite metrics differ" in R.Archive(arch.dir, arch.db).integrity(B)["problems"][0]


def test_archive_is_never_written(arch):
    before = {p.name: (p.read_bytes(), os.stat(p).st_mtime_ns) for p in arch.dir.iterdir()}
    db_before = arch.db.read_bytes()
    _go(arch, arch.tmp / "out")
    assert {p.name: (p.read_bytes(), os.stat(p).st_mtime_ns) for p in arch.dir.iterdir()} == before
    assert arch.db.read_bytes() == db_before
    with pytest.raises(ValueError, match="read-only"):
        _go(arch, arch.dir / "sub")


def test_number_scan_flags_uncatalogued_numbers(arch):
    res = _go(arch, arch.tmp / "out")
    left = [t for _, t in res["scan"]["note.md"]]
    assert left == []                                                  # Kupiec is a claim (T-05); run id and version stripped
    assert R.uncatalogued("VaR99 67.90 and 12.5 (EQ-B-0007, HO-20261023-B-C-006, AGENT-08, 0.1.4, 2026-10-23, 14:21Z)", [], "") == [(1, "67.90"), (1, "12.5")]


def test_compare_rules():
    assert R.decimals("+0.12%") == 2 and R.decimals("131,072") == 0
    assert R.parse_number("+84.7%") == 84.7 and R.parse_number("8.8 $mm") == 8.8 and R.parse_number("-7.7") == -7.7
    assert R.parse_number("131,072") == 131072 and R.parse_number("c8ddae65…1748") is None
    assert R._prev("0.1.5") == "0.1.4" and R._prev("0.1.0") == ""


def _mini_zip(tmp_path, version="0.1.5"):
    src = tmp_path / "src" / "econquest"
    (src / "econquest").mkdir(parents=True); (src / "data").mkdir()
    (src / "econquest" / "__init__.py").write_text(f'__version__ = "{version}"\n')
    (src / "econquest" / "m.py").write_text("X = 1\n")
    (src / "data" / "assumptions.json").write_text("{}")
    (src / "RELEASE-MANIFEST.txt").write_text("abc 1 econquest/econquest/__init__.py\nabd 1 econquest/econquest/m.py\n")
    (src / "RELEASE-HASHES.json").write_text(json.dumps({"version": version}))
    (src / "RELEASE-REPLICATION.md").write_text("- Status counts: INFO 2, PASS 121\n")
    z = tmp_path / "rel.zip"
    with zipfile.ZipFile(z, "w") as zf:
        for p in sorted(src.rglob("*")):
            if p.is_file():
                zf.write(p, p.relative_to(src.parent).as_posix())
    return z, src


def test_open_zip_facts_and_version_revert(tmp_path):
    z, src = _mini_zip(tmp_path)
    zf = R.open_zip(z, tmp_path / "x")
    assert zf.version == "0.1.5" and zf.manifest_files == 2 and zf.entries == 6
    assert zf.code_hash == R.tree_code_hash(src / "econquest")
    (src / "econquest" / "__init__.py").write_text('__version__ = "0.1.4"\n')
    assert R.tree_code_hash(zf.root / "econquest", version_as="0.1.4") == R.tree_code_hash(src / "econquest")
    ctx = R.Ctx(R.Archive(tmp_path / "none"), zip=zf)
    assert R._rep_counts(ctx, "PASS").value == 121 and R._rep_counts(ctx, "FAIL").value == 0
    with pytest.raises(R.Missing):
        ctx.need_zip("0.1.4")


def test_rerun_worker_uses_only_the_frozen_engine(tmp_path):
    root = tmp_path / "frozen"
    pkg = root / "econquest"; (pkg / "engine").mkdir(parents=True); (root / "data").mkdir()
    (pkg / "__init__.py").write_text('__version__ = "9.9"\n')
    (pkg / "engine" / "__init__.py").write_text("")
    (pkg / "engine" / "pipeline.py").write_text("run_pipeline = None\n")
    (pkg / "engine" / "stress.py").write_text("class Scenario: pass\n\ndef load_scenarios(p):\n    return {'A': 1, 'B': 2, 'C': 3}\n")
    assert Path(W.__file__).resolve() == R.WORKER                      # the subprocess runs this file with python -I
    out = R.run_worker(SimpleNamespace(root=root), [{"id": "n", "count_scenarios": True}], tmp_path, timeout=120)
    assert out["_engine"]["version"] == "9.9" and Path(out["_engine"]["file"]).resolve().parent == pkg.resolve()
    assert out["n"] == {"loadable_scenarios": 3.0}


def test_catalogue_ids_unique_and_reported_values_are_in_the_notes():
    cat = R.catalogue()
    assert len({c.id for c in cat}) == len(cat)
    derived = {"N011-27", "N013-29", "N013-51", "N014-26", "N014-60", "N015-68", "N013-48", "N014-52", "N015-01", "N015-02",
               "N015-39", "N015-33"}                                   # counts and statements the note gives in words
    for c in cat:
        text = (R.RELEASES / c.doc).read_text()
        if c.id not in derived:
            core = c.reported.lstrip("+").replace(" $mm", "").replace(" pp", "").replace(" s", "").replace("%", "")
            assert core in text, (c.id, c.reported)


@pytest.mark.skipif(not R.ARCHIVE.is_dir(), reason="no run archive in this checkout")
def test_real_archive_matches_the_notes_without_reruns(tmp_path):
    res = R.replicate_archive(tmp_path, zip_path=None, rerun=False, log=lambda *_: None)
    rows = res["rows"].set_index("id")
    assert (rows.status == "MISSING_ARCHIVE").sum() == 0 and res["unexplained"] == 0 and res["uncatalogued"] == 0
    for cid in ("N011-23", "N013-15", "N014-17", "N015-21", "N015-42", "P015-12"):
        assert rows.loc[cid, "status"] == "MATCH", (cid, rows.loc[cid].to_dict())
    assert rows.loc["N013-29", "finding"] == "VF-015"


def test_zip_engine_refused_when_sha_differs_from_the_note(tmp_path, arch):
    z, _ = _mini_zip(tmp_path)
    zf = R.open_zip(z, tmp_path / "y")
    with pytest.raises(ValueError, match="refusing to run its engine"):
        R.verify_zip(zf)                                               # catalogued 0.1.5 SHA is f738efe0..., not this zip's
    ok = [R.Claim("Z", "0.1.5", "note.md", "zip SHA-256", zf.sha256, kind="package")]
    R.verify_zip(zf, ok)                                               # matches: no exception
    calls = []
    orig = R.run_worker
    R.run_worker = lambda *a, **k: calls.append(a) or {}
    try:
        with pytest.raises(ValueError, match="refusing"):
            R.replicate_archive(tmp_path / "o", archive=arch.dir, db=arch.db, zip_path=z, rerun=True, releases=arch.rel,
                                claims=_claims(), labels={}, findings={}, log=lambda *_: None)
    finally:
        R.run_worker = orig
    assert calls == []                                                 # the engine never ran


def test_zip_caps_refuse_before_extracting(tmp_path):
    z, _ = _mini_zip(tmp_path)
    with pytest.raises(ValueError, match="entries"):
        R.open_zip(z, tmp_path / "a", max_entries=3)
    with pytest.raises(ValueError, match="bytes uncompressed"):
        R.open_zip(z, tmp_path / "b", max_bytes=10)
    assert not (tmp_path / "a").exists() and not (tmp_path / "b").exists()


def test_csv_cells_cannot_start_a_formula(arch):
    res = _go(arch, arch.tmp / "out")
    df = pd.read_csv(res["csv"], dtype=str, keep_default_na=False)
    assert df.set_index("id").loc["T-04", "reported"] == "'+75.9%" and df.set_index("id").loc["T-09", "reported"] == "'-7.7"
    for col in df.columns:
        assert not df[col].str.match(r"^[=+\-@]").any(), col
