"""Presentation at the approved 88-country universe (EQ-C-0044, HO-20261023-A-C-014 parts 1-2): a publish plan, the
dashboard and the country notes built on the staged data folder (`python -m econquest.ingestion.universe stage`).

The staged folder carries no values yet for the 70 new countries (they arrive with the first full pull), so the
readiness check (EQ-B-0045) refuses to score it as staged. The fixture, in a temp copy only, gives each new country
the indicator and profile values of a seed country where blank, and zero analyst adjustments.
Layout is what is tested here, not numbers."""
import html
from pathlib import Path

import pandas as pd
import pytest

from econquest.config import Settings
from econquest.engine import run_pipeline
from econquest.ingestion import load_universe
from econquest.ingestion.universe import stage_data_dir
from econquest.presentation import country_note as N
from econquest.presentation import render_dashboard
from econquest.presentation import sheets_publish as SP

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
STAGING = DATA / "panel" / "universe_staging"
AS_OF = "2026-10-23"


@pytest.fixture(scope="module")
def run88(tmp_path_factory):
    if not (STAGING / "countries.csv").exists():
        pytest.skip("data/panel/universe_staging not built (python -m econquest.ingestion.universe expand)")
    d = stage_data_dir(STAGING, tmp_path_factory.mktemp("st88") / "data", DATA)
    seed = list(pd.read_csv(DATA / "countries.csv")["country"])
    ind = pd.read_csv(d / "indicators.csv", dtype={"id": str})
    new = [c for c in ind.columns if c not in ("id", "pillar", "indicator", "unit") and c not in seed]
    adj = pd.read_csv(d / "adjustments.csv")
    for k, c in enumerate(new):
        ind[c] = ind[c].where(ind[c].notna(), ind[seed[k % len(seed)]])
        adj[c] = 0.0
    ind.to_csv(d / "indicators.csv", index=False); adj.to_csv(d / "adjustments.csv", index=False)
    cty = pd.read_csv(d / "countries.csv", keep_default_na=False, na_values=[""])   # 'NA' is Namibia's iso2
    rows = cty.set_index("country")
    for k, c in enumerate(new):                                         # profile blanks from the same seed country
        rows.loc[c] = rows.loc[c].where(rows.loc[c].notna(), rows.loc[seed[k % len(seed)]])
    rows.reset_index().to_csv(d / "countries.csv", index=False)
    u = load_universe(d); s = Settings.load(d / "assumptions.json")
    res = run_pipeline(u, s, paths=2000, as_of=AS_OF)
    plan = SP.build_plan(res, u, s, history=pd.read_csv(d / "backtest_history.csv"), stamp=AS_OF, mc_rows=50)
    return d, u, res, plan


def test_88_country_plan_has_no_column_v_country_block(run88):
    d, u, res, plan = run88
    assert len(u.names) == 88 and SP.country_cols(88) == "E:CN"
    assert SP.plan_problems(plan) == []
    for b in plan:                                                      # no country block stops at the 18-country column V
        tab, r1, c1, r2, c2 = SP.parse_a1(b["range"])
        assert not (c1 == 5 and c2 == 22), b["range"]
    blocks = {b["range"]: b["values"] for b in plan}
    for r in ("'Stress Inputs'!E5:CN87", "'Risk Engine'!E5:CN37", "Signals!E5:CN29"):
        assert r in blocks and all(len(row) == 88 for row in blocks[r]), r
    assert "Dashboard!A6:V93" in blocks and len(blocks["Dashboard!A6:V93"]) == 88   # 22 columns, one row per country


def test_88_country_notes_and_dashboard(run88, tmp_path):
    d, u, res, plan = run88
    run = res.to_dict()
    r = N.build_country_notes(tmp_path / "outputs", d, tmp_path / "notes", run=run, recompute_pillars=False, log=lambda *a: None)
    assert len(r["items"]) == 88 and {i["country"] for i in r["items"]} == set(u.names)
    assert (tmp_path / "notes" / "index.html").read_text(encoding="utf-8").count("<tr data-region=") == 88
    page = render_dashboard(run, None, None)
    assert all(html.escape(n) in page or n in page for n in u.names)
