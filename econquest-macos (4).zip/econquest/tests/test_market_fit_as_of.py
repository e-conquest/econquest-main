"""GARCH vols and the estimated copula fit only on prices dated on or before as_of (EQ-B-0035/0036 review)."""
import pandas as pd

from econquest.config import Settings
from econquest.engine import garch as G
from econquest.engine import layer5_copula as L5
from econquest.ingestion import load_universe

DATA = "data"


def _setup():
    u = load_universe(DATA)
    s = Settings.load(f"{DATA}/assumptions.json")
    return u, s



def test_prices_as_of_drops_later_rows():
    px = pd.DataFrame({"date": ["2025-01-02", "2025-06-30", "2025-07-01"], "X": [1.0, 2.0, 3.0]})
    assert list(G.prices_as_of(px, "2025-06-30")["X"]) == [1.0, 2.0]
    assert G.prices_as_of(px, None) is px


def test_garch_and_copula_ignore_prices_after_as_of():
    u, _ = _setup()
    px = u.prices
    dates = pd.to_datetime(px["date"] if "date" in px.columns else px.index)
    cut = dates.max() - pd.Timedelta(days=180)
    early = G.prices_as_of(px, cut)
    later = pd.Timestamp(cut) + pd.Timedelta(days=1)
    # a replay at `cut` gives the same fit as if the later prices did not exist
    u_cut = type(u).__new__(type(u)); u_cut.__dict__.update(u.__dict__); u_cut.prices = early
    assert L5.estimated_copula(u, cut).end == L5.estimated_copula(u_cut).end
    assert pd.Timestamp(L5.estimated_copula(u, cut).end) < later
    fit_all = L5.estimated_copula(u)
    assert pd.Timestamp(fit_all.end) > pd.Timestamp(cut)
    needed = [(c, "Equity") for c in u.countries["country"] if isinstance(u.countries.set_index("country").at[c, "etf"], str)][:3]
    a = G.mc_vols(G.prices_as_of(px, cut), u.countries, needed)
    b = G.mc_vols(early, u.countries, needed)
    pd.testing.assert_frame_equal(a, b)
    assert (a["obs"] < G.mc_vols(px, u.countries, needed)["obs"]).all()


def _regimes(u, name):
    return pd.Series(name, index=list(u.names))


def test_estimated_loadings_keep_a_scenario_calm_shock():
    # review fix: scenario C raises regime.Calm.global_loading 0.15 -> 0.30; the step must be measured from the
    # judgement anchor, so the shock adds to the fit instead of cancelling it or making a loading negative (NaN ES)
    u, s = _setup()
    base = L5.factor_loadings(u, s, _regimes(u, "Stressed"), "Calm")
    shocked = L5.factor_loadings(u, s.copy_with(**{"regime.Calm.global_loading": 0.30}), _regimes(u, "Stressed"), "Calm")
    assert (shocked["global"] >= 0).all() and (base["global"] >= 0).all()
    assert (shocked["global"] >= base["global"] - 1e-12).all()


def test_estimated_copula_falls_back_to_judgement_without_prices():
    import warnings
    u, s = _setup()
    u0 = type(u).__new__(type(u)); u0.__dict__.update(u.__dict__); u0.prices = u.prices.iloc[0:0]
    judge = s.copy_with(**{"copula.source": "judgement"})
    with warnings.catch_warnings(record=True) as w:
        warnings.simplefilter("always")
        est = L5.factor_loadings(u0, s, _regimes(u0, "Calm"), "Calm")
    assert any("judgement copula" in str(x.message) for x in w)
    pd.testing.assert_frame_equal(est, L5.factor_loadings(u0, judge, _regimes(u0, "Calm"), "Calm"))
