"""EQ-A-0014 / GOV-030: per-run signals and trade activations in the SQLite run store (contract C4, additive).

Acceptance from HO-20261023-B-A-001: seed data at as_of 2026-10-23 gives 25 x 18 signal rows and 26 x 18
activation rows per run_id, values equal to the run's tables, sum(fired) equal to the run's firings, and an
idempotent re-save. The engine is imported here only to build a run; persistence itself does not import it."""
import sqlite3
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.config import Settings  # noqa: E402
from econquest.ingestion import load_universe  # noqa: E402
from econquest.engine import run_pipeline  # noqa: E402
from econquest.engine.signals import SIGNAL_NAMES  # noqa: E402
from econquest.persistence.store import Store  # noqa: E402

SEED = ROOT / "tests" / "seed_data"
AS_OF = "2026-10-23"


@pytest.fixture(scope="module")
def run():
    u = load_universe(SEED); s = Settings.load(SEED / "assumptions.json")
    return u, run_pipeline(u, s, paths=500, as_of=AS_OF)


def _count(store, table, run_id):
    with sqlite3.connect(store.db) as c:
        return c.execute(f"SELECT COUNT(*) FROM {table} WHERE run_id=?", (run_id,)).fetchone()[0]  # nosec B608


def test_signals_and_activation_stored_per_run(run, tmp_path):
    u, r = run
    store = Store(tmp_path / "store")
    rid = store.save_run(r, keep_paths=False, signal_names=SIGNAL_NAMES)
    n_sig, n_trade, n_ctry = len(r.signals), len(r.activation), len(u.names)
    assert (n_sig, n_trade, n_ctry) == (25, 26, 18)
    assert _count(store, "signals", rid) == n_sig * n_ctry == 450
    assert _count(store, "activation", rid) == n_trade * n_ctry == 468

    sig = store.signals()
    assert set(sig["run_id"]) == {rid} and set(sig["as_of"]) == {AS_OF}
    wide = sig.pivot(index="signal_key", columns="country", values="value").loc[list(r.signals.index), list(r.signals.columns)]
    np.testing.assert_allclose(wide.to_numpy(dtype=float), r.signals.to_numpy(dtype=float))
    assert dict(zip(sig["signal_key"], sig["signal_name"])) == dict(SIGNAL_NAMES)

    act = store.activations()
    fired = int(r.activation.notna().sum().sum())
    assert int(act["fired"].sum()) == fired and fired > 0
    assert act.loc[act["fired"] == 0, "value"].isna().all() and act.loc[act["fired"] == 1, "value"].notna().all()
    wide = act.pivot(index="trade_id", columns="country", values="value").loc[list(r.activation.index), list(r.activation.columns)]
    pd.testing.assert_frame_equal(wide.astype(float), r.activation.astype(float), check_names=False)

    store.save_run(r, keep_paths=False, signal_names=SIGNAL_NAMES)          # idempotent re-save
    assert _count(store, "signals", rid) == 450 and _count(store, "activation", rid) == 468


def test_query_filters_and_names_from_run_dict(run, tmp_path):
    u, r = run
    store = Store(tmp_path / "store")
    rid = store.save_run(r, keep_paths=False)                                # no names passed: taken from the run dict (EQ-B-0030)
    sig = store.signals(country=u.names[0], signal_key=25)
    assert len(sig) == 1 and (sig["signal_name"] == SIGNAL_NAMES[25]).all()
    assert sig["value"].iloc[0] == pytest.approx(float(r.signals.at[25, u.names[0]]))
    assert len(store.signals(signal_key=1)) == 18 and len(store.signals(country=u.names[0])) == 25
    assert len(store.activations(trade_id="T26")) == 18
    assert len(store.activations(country=u.names[0], trade_id="T01")) == 1
    assert store.signals(since="2999-01-01").empty and len(store.activations(since="1970-01-01")) == 468
    # a dict loaded back from the JSON archive (NaN -> null) stores the same rows
    store.save_run(store.load(rid), keep_paths=False)
    assert int(store.activations()["fired"].sum()) == int(r.activation.notna().sum().sum())


def test_run_without_signals_writes_no_rows(run, tmp_path):
    _, r = run
    d = r.to_dict(); d["signals"] = d["activation"] = None
    store = Store(tmp_path / "store")
    store.save_run(d, keep_paths=False)
    assert store.signals().empty and store.activations().empty
