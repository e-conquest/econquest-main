"""`econquest market import|enter|gate|cds-quotes` over Team A's econquest/ingestion/market/ (HO-20261023-A-C-015, EQ-C-0053).
Every export, mapping and quote here is SYNTHETIC (tests/fixtures/market); nothing touches the network or the repo's data/."""
import json
import shutil
from pathlib import Path

import pandas as pd
import pytest

from econquest import cli
from econquest.engine import cds
from econquest.ingestion.market import list_market_snapshots
from econquest.ingestion.market.manual import read_manual
from econquest.presentation import gui

ROOT = Path(__file__).resolve().parent.parent
FIX = Path(__file__).parent / "fixtures" / "market"
LIC = "Bloomberg Terminal licence (SYNTHETIC test)"


@pytest.fixture
def data(tmp_path, monkeypatch):
    monkeypatch.setenv("ECONQUEST_ACTION_LOG", str(tmp_path / "actions.jsonl"))
    d = tmp_path / "data"; d.mkdir()
    shutil.copy(ROOT / "data" / "countries.csv", d / "countries.csv")
    (d / "cds_quotes.csv").write_text("country,date,tenor_y,spread_bp,recovery,source\n")
    return d


def market(d, *a):
    cli.main(["--data", str(d), "--out", str(d.parent / "outputs"), "market", *a])


def entry_csv(tmp_path, rows, name="entry.csv"):
    p = tmp_path / name
    pd.DataFrame(rows).to_csv(p, index=False)
    return p


def cds_row(iso, tenor, value, asof="2026-10-20"):
    return {"asof": asof, "instrument": "cds", "iso": iso, "currency": "USD", "tenor_y": tenor, "field": "spread_bp",
            "value": value, "doc_clause": "CR14"}


def actions(d):
    p = d.parent / "actions.jsonl"
    return [json.loads(x)["command"] for x in p.read_text().splitlines()] if p.exists() else []


@pytest.mark.parametrize("sub", [[], ["import"], ["enter"], ["gate"], ["cds-quotes"]])
def test_help(sub, capsys):
    with pytest.raises(SystemExit) as e:
        cli.main(["market", *sub, "--help"])
    assert e.value.code == 0 and "usage: econquest market" in capsys.readouterr().out


def test_import_gate_cds_quotes_engine_reads_it(data, capsys):
    market(data, "import", "--profile", "bloomberg", "--licence", LIC, "--map", str(FIX / "ticker_map_test.csv"),
           str(FIX / "bloomberg_long.csv"))
    out = capsys.readouterr().out
    assert "Saved snapshot" in out and "1 missing values skipped" in out
    ix = list_market_snapshots(data)
    assert len(ix) == 1 and ix["sources"].iloc[0] == "bloomberg"

    market(data, "gate", "--strict")
    out = capsys.readouterr().out
    assert "Market gate: " in out and " 0 held" in out
    assert (data.parent / "outputs" / "market_gate.csv").exists()

    market(data, "cds-quotes")
    assert "Wrote " in capsys.readouterr().out
    q = pd.read_csv(data / "cds_quotes.csv")
    assert list(q.columns) == ["country", "date", "tenor_y", "spread_bp", "recovery", "source"]
    assert set(q["country"]) == {"Brazil"} and q.loc[q["tenor_y"] == 5, "spread_bp"].item() == 200
    assert q["source"].str.startswith("bloomberg " + ix["snapshot_id"].iloc[0]).all()
    t = cds.cds_table(q, pd.Series({"Brazil": 0.02}))           # engine/cds.py reads the file unchanged
    assert t["country"].tolist() == ["Brazil"] and 0 < t["cds_pd_12m"].iloc[0] < 1
    assert not list(data.glob(".cds_quotes.csv.*"))              # atomic write leaves no temp file
    assert actions(data) == ["market import", "market cds-quotes"]


def test_import_refusals(data):
    with pytest.raises(SystemExit) as e:
        market(data, "import", str(FIX / "bloomberg_long.csv"))
    assert "--profile" in str(e.value)
    with pytest.raises(SystemExit) as e:                         # no ticker map yet: Team A's error, not a traceback
        market(data, "import", "--profile", "bloomberg", "--licence", LIC, str(FIX / "bloomberg_long.csv"))
    assert "ticker map" in str(e.value)
    with pytest.raises(SystemExit) as e:
        market(data, "import", "--profile", "bloomberg", "--licence", "pending", "--map", str(FIX / "ticker_map_test.csv"),
               str(FIX / "bloomberg_long.csv"))
    assert "licence" in str(e.value) and list_market_snapshots(data).empty


def test_init_map_creates_template_once(data, capsys):
    market(data, "import", "--init-map")
    p = data / "live" / "market" / "ticker_map.csv"
    assert p.exists() and "Ticker map:" in capsys.readouterr().out
    p.write_text(p.read_text() + "# edited\n")
    market(data, "import", "--init-map")
    assert p.read_text().endswith("# edited\n") and actions(data) == []


def test_enter_four_eyes(data, tmp_path, capsys):
    f = entry_csv(tmp_path, [cds_row("BRA", 5, 210)])
    with pytest.raises(SystemExit) as e:
        market(data, "enter", "--author", "alice", "--approver", "Alice ", str(f))
    assert "four-eyes" in str(e.value) and read_manual(data).empty and list_market_snapshots(data).empty
    with pytest.raises(SystemExit):
        market(data, "enter", "--author", "alice", str(f))
    market(data, "enter", "--author", "alice", "--approver", "bob", str(f))
    assert "approver bob" in capsys.readouterr().out
    market(data, "enter", "--author", "sam", "--self-approved", "--note", "dealer run", str(entry_csv(tmp_path, [cds_row("BRA", 5, 211)])))
    assert "self-approved" in capsys.readouterr().out                # no EXC id needed, as fetch --self-approved
    m = read_manual(data)
    assert m["approver"].tolist() == ["bob", "sam"] and m["self_approved"].tolist() == ["", "yes"]
    assert len(list_market_snapshots(data)) == 2
    assert actions(data).count("market enter") == 4                  # refused attempts are logged too


def test_enter_bad_rows_refused(data, tmp_path):
    f = entry_csv(tmp_path, [{**cds_row("BRA", 5, 210), "value": "=1+1"}])
    with pytest.raises(SystemExit) as e:
        market(data, "enter", "--author", "alice", "--approver", "bob", str(f))
    assert str(e.value).startswith("market enter:") and read_manual(data).empty


def test_cds_quotes_excludes_held_series_and_gate_strict(data, tmp_path, capsys):
    rows = [cds_row("BRA", 1, 100), cds_row("BRA", 5, 200),
            cds_row("COL", 1, 100), cds_row("COL", 3, 300), cds_row("COL", 5, 150)]   # COL curve non-monotone: held
    market(data, "enter", "--author", "alice", "--approver", "bob", str(entry_csv(tmp_path, rows)))
    capsys.readouterr()
    market(data, "gate")                                              # not strict: holds printed, exit 0
    out = capsys.readouterr().out
    assert "3 held" in out and "curve" in out
    with pytest.raises(SystemExit) as e:
        market(data, "gate", "--strict")
    assert e.value.code == 1
    market(data, "cds-quotes", "--dry-run")
    assert "Dry run" in capsys.readouterr().out and pd.read_csv(data / "cds_quotes.csv").empty
    market(data, "cds-quotes")
    assert "3 held cds series excluded" in capsys.readouterr().out
    q = pd.read_csv(data / "cds_quotes.csv")
    assert set(q["country"]) == {"Brazil"} and sorted(q["tenor_y"]) == [1, 5]


def test_cds_quotes_never_writes_an_empty_file(data, tmp_path):
    rows = [cds_row("COL", 1, 100), cds_row("COL", 3, 300), cds_row("COL", 5, 150)]
    market(data, "enter", "--author", "alice", "--approver", "bob", str(entry_csv(tmp_path, rows)))
    before = (data / "cds_quotes.csv").read_bytes()
    with pytest.raises(SystemExit) as e:
        market(data, "cds-quotes")
    assert "not changed" in str(e.value) and (data / "cds_quotes.csv").read_bytes() == before


def test_jump_against_previous_snapshot_is_held(data, tmp_path, capsys):
    market(data, "enter", "--author", "alice", "--approver", "bob", str(entry_csv(tmp_path, [cds_row("BRA", 5, 200)], "a.csv")))
    market(data, "enter", "--author", "alice", "--approver", "bob",
           str(entry_csv(tmp_path, [cds_row("BRA", 5, 400, asof="2026-10-21")], "b.csv")))
    capsys.readouterr()
    market(data, "gate")
    out = capsys.readouterr().out
    assert "1 held" in out and "jump" in out


def test_point_in_time_as_of_before_any_snapshot(data, tmp_path):
    market(data, "enter", "--author", "alice", "--approver", "bob", str(entry_csv(tmp_path, [cds_row("BRA", 5, 200)])))
    with pytest.raises(SystemExit) as e:
        market(data, "cds-quotes", "--asof", "2020-01-01")
    assert "no market snapshot" in str(e.value)


def test_directory_as_file_or_dest_is_a_clean_refusal(data, tmp_path):
    """AGENT-09 (SEC-C-006 L2): a folder given as the CSV or as --dest is refused with a message, not a traceback, and
    neither data/cds_quotes.csv nor a temp file is left changed."""
    with pytest.raises(SystemExit) as e:
        market(data, "import", "--profile", "bloomberg", "--licence", LIC, "--map", str(FIX / "ticker_map_test.csv"), str(tmp_path))
    assert str(e.value).startswith("market import:")
    market(data, "enter", "--author", "alice", "--approver", "bob", str(entry_csv(tmp_path, [cds_row("BRA", 1, 100), cds_row("BRA", 5, 200)])))
    before = (data / "cds_quotes.csv").read_bytes()
    dest = tmp_path / "a_folder"; dest.mkdir()
    with pytest.raises(SystemExit) as e:
        market(data, "cds-quotes", "--dest", str(dest))
    assert str(e.value).startswith("market cds-quotes:") and (data / "cds_quotes.csv").read_bytes() == before
    assert not [p for p in tmp_path.iterdir() if p.name.endswith(".tmp")] and list(dest.iterdir()) == []


def test_gui_would_strip_market_identity_flags(tmp_path, monkeypatch):
    assert "market" not in gui.ALLOWED_CMDS                           # not a GUI command (EQ-C-0053)
    seen = {}

    class FakePopen:
        def __init__(self, argv, **kw):
            seen["argv"] = argv
            self.stdout = iter(()); self.returncode = 0

        def poll(self):
            return 0

        def wait(self):
            return 0
    monkeypatch.setattr(gui.subprocess, "Popen", FakePopen)
    monkeypatch.setattr(gui, "ALLOWED_CMDS", gui.ALLOWED_CMDS | {"market"})
    gui.Jobs(str(tmp_path), str(tmp_path)).start("market", ["enter", "--author", "Sam", "--self-approved", "--appr=Bob", "q.csv"])
    assert seen["argv"][seen["argv"].index("market") + 1:] == ["enter", "q.csv"]


def test_pyproject_ships_ticker_map_template():
    assert "ingestion/market/ticker_map_template.csv" in (ROOT / "pyproject.toml").read_text()


# ---------------------------------------------------------------- HO-20261023-A-C-019 / A-C-017 (EQ-C-0057)
def _save(d, rows, seconds):
    import datetime as dt
    from econquest.ingestion.market.schema import MARKET_COLUMNS
    from econquest.ingestion.market.store import save_market_snapshot
    full = [{"asof": "2026-10-22", "instrument": "cds", "iso": iso, "currency": "USD", "tenor_y": 5.0, "field": "spread_bp",
             "value": v, "unit": "bp", "doc_clause": "CR14", "source": "bloomberg", "vendor_ticker": "",
             "licence": "SYNTHETIC test licence", "derived": False, "snapshot_id": "", "retrieved_utc": ""} for iso, v in rows]
    save_market_snapshot(d, pd.DataFrame(full, columns=MARKET_COLUMNS),
                         now=dt.datetime(2026, 10, 22, 12, 0, tzinfo=dt.timezone.utc) + dt.timedelta(seconds=seconds))


def test_resaved_held_quote_stays_held_in_gate_and_cds_quotes(data, capsys):
    for i, v in enumerate([150.0, 45000.0, 45000.0]):                # 150 -> jump (held) -> the same file imported again
        _save(data, [("XBB", v), ("BRA", 200.0)], i * 5)
    market(data, "gate")
    g = pd.read_csv(data.parent / "outputs" / "market_gate.csv")
    row = g[g["country"] == "XBB"].iloc[0]
    assert row["status"] == "hold" and float(row["seed"]) == 150.0
    capsys.readouterr()
    market(data, "cds-quotes")
    q = pd.read_csv(data / "cds_quotes.csv")
    assert 45000.0 not in q["spread_bp"].tolist() and len(q) == 1
    assert "1 held cds series excluded" in capsys.readouterr().out


def test_cds_snapshots_appends_clean_reports_held_dry_run_writes_nothing(data, capsys):
    from econquest.ingestion.market.store import cds_snapshots_path
    _save(data, [("XBB", 150.0), ("XCC", 200.0)], 0)
    _save(data, [("XBB", 45000.0), ("XCC", 205.0)], 5)
    market(data, "cds-snapshots", "--dry-run")
    out = capsys.readouterr().out
    assert "would append" in out and "45000" in out and not cds_snapshots_path(data).exists()
    assert "market cds-snapshots" not in actions(data)
    market(data, "cds-snapshots")
    out = capsys.readouterr().out
    assert "appended 3 rows" in out and "gate" in out
    assert sorted(pd.read_csv(cds_snapshots_path(data))["value"].tolist()) == [150.0, 200.0, 205.0]
    assert "market cds-snapshots" in actions(data)
