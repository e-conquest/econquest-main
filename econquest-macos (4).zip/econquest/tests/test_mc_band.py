"""Monte Carlo error band next to VaR99 / ES99 / L-VaR99 and the book-limit verdicts, with the "within MC error" flag, in
the risk report, the weekly monitor, the dashboard and the `run` headline (HO-20261023-B-C-016 item 4, EQ-C-0055)."""
import copy
from pathlib import Path

import pytest

from econquest.config import Settings
from econquest.engine import run_pipeline
from econquest.ingestion import load_universe
from econquest.presentation import mc_band as B
from econquest.presentation.dashboard import render_dashboard, run_headline
from econquest.presentation.report import build_report
from econquest.presentation.risk_monitor import build_monitor

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
# the handoff's case: L-VaR99 79.63, band 78.82-80.45, warning level 0.8 x 100 = 80
HANDOFF = {"var99_mm": 74.35, "var99_ci95_lo_mm": 73.60, "var99_ci95_hi_mm": 75.10, "var99_se_mm": 0.38,
           "es99_mm": 96.48, "es99_ci95_lo_mm": 95.20, "es99_ci95_hi_mm": 97.76, "es99_se_mm": 0.65,
           "lvar99_mm": 79.63, "lvar99_ci95_lo_mm": 78.82, "lvar99_ci95_hi_mm": 80.45, "lvar99_se_mm": 0.41,
           "expected_loss_mm": 0.46}
LIMITS = {"warning_level": 0.8, "book": {"var99_mm": 95.0, "es99_mm": 115.0, "lvar99_mm": 100.0, "expected_loss_mm": 5.0}}


@pytest.fixture(scope="module")
def run_dict():
    res = run_pipeline(load_universe(DATA), Settings.load(DATA / "assumptions.json"), paths=2000, as_of="2026-10-23")
    d = res.to_dict()
    d["summary"]["metrics"].update(HANDOFF)
    return d


def test_band_text_and_missing_band():
    assert B.band_text(HANDOFF, "lvar99_mm") == "78.82-80.45"
    assert B.band({"lvar99_mm": 79.6}, "lvar99_mm") is None and B.band_text({}, "var99_mm") == ""
    assert B.band({"var99_ci95_lo_mm": float("nan"), "var99_ci95_hi_mm": 1.0}, "var99_mm") is None
    assert B.headline_band(HANDOFF, "var99_mm") == " (95% MC band 73.60-75.10)" and B.headline_band({}, "var99_mm") == ""


def test_lvar_verdict_within_mc_error_of_warning_level():
    rows = {r["measure"]: r for r in B.book_limit_verdicts(HANDOFF, LIMITS)}
    lv = rows["lvar99_mm"]
    assert lv["status"] == "pass" and lv["warning_mm"] == pytest.approx(80.0) and lv["within_mc_error"]
    assert lv["mc_note"] == "within MC error of the warning level 80.00 (95% band 78.82-80.45)"
    assert not rows["var99_mm"]["within_mc_error"] and not rows["es99_mm"]["within_mc_error"]
    assert rows["es99_mm"]["status"] == "warning"                       # 96.48 >= 92: point-estimate verdict as check_book
    assert rows["expected_loss_mm"]["band_lo"] is None and not rows["expected_loss_mm"]["within_mc_error"]


def test_band_containing_the_limit_and_status_rules():
    m = {"var99_mm": 93.0, "var99_ci95_lo_mm": 90.0, "var99_ci95_hi_mm": 96.0}
    r = B.book_limit_verdicts(m, LIMITS)[0]
    assert r["status"] == "warning" and r["within_mc_error"]
    assert r["mc_note"] == "within MC error of the limit 95.00 (95% band 90.00-96.00)"
    r = B.book_limit_verdicts({"var99_mm": 95.0, "var99_ci95_lo_mm": 94.0, "var99_ci95_hi_mm": 96.0}, LIMITS)[0]
    assert r["status"] == "breach" and "limit 95.00" in r["mc_note"]
    assert B.book_limit_verdicts(HANDOFF, None) == [] and B.book_limit_verdicts({"lvar99_mm": 79.63}, LIMITS)[0]["within_mc_error"] is False


def test_book_limit_rows_match_engine_check_book_status():
    """Status from the point estimate uses the same rule as engine/limits.check_book."""
    from econquest.engine import limits as LM
    lim = LM.load_limits(DATA / "limits.json")
    for v in (10.0, 79.99, 80.0, 99.99, 100.0, 140.0):
        _, st = LM._status(v, lim["book"]["lvar99_mm"], lim["warning_level"])
        assert B.book_limit_verdicts({"lvar99_mm": v}, lim)[0]["status"] == st


def test_md_and_html_tables():
    rows = B.book_limit_verdicts(HANDOFF, LIMITS)
    md = "\n".join(B.limits_md(rows))
    assert "| L-VaR 99% | 79.63 | 78.82-80.45 | 80.00 | 100.00 | 79.6% | pass | **within MC error of the warning level 80.00" in md
    html = B.limits_html(rows, lambda x: str(x))
    assert "95% MC band $mm" in html and html.count("within MC error of the") == 1
    assert "No book limits" in B.limits_html([], str) and B.limits_md([]) == ["No book limits (data/limits.json) to compare against."]


def test_risk_report_shows_band_and_flags_lvar(run_dict, tmp_path):
    r = build_report(DATA, tmp_path, run=copy.deepcopy(run_dict), alerts=[], log=lambda *a: None)
    html, md = Path(r["html"]).read_text(), Path(r["md"]).read_text()
    for t in ("95% MC band 73.60-75.10", "95% MC band 95.20-97.76", "95% MC band 78.82-80.45"):
        assert t in html
    assert "within MC error of the warning level 80.00 (95% band 78.82-80.45)" in html
    assert "| VaR 99% | 74.3 | 73.60-75.10 |" in md or "| VaR 99% | 74.4 | 73.60-75.10 |" in md
    assert "### Book limits" in md and "**within MC error of the warning level 80.00" in md


def test_monitor_shows_band_and_flag(run_dict, tmp_path):
    r = build_monitor(tmp_path, DATA, tmp_path / "reports", run=copy.deepcopy(run_dict), log=lambda *a: None)
    html, md = Path(r["html"]).read_text(), Path(r["md"]).read_text()
    assert "78.82-80.45" in html and "within MC error of the warning level 80.00" in html
    assert "| 95% MC band |" in md and "within MC error of the warning level 80.00" in md


def test_dashboard_band_and_limits(run_dict):
    page = render_dashboard(copy.deepcopy(run_dict), limits=LIMITS)
    assert "95% MC band 78.82-80.45" in page and "Book limits" in page and "within MC error of the warning level 80.00" in page
    assert "Book limits" not in render_dashboard(copy.deepcopy(run_dict))            # without limits: no table (api.py)


def test_run_headline_band_and_flag():
    s = {"run_id": "r1", "as_of": "2026-10-23", "global_regime": "Stressed", "metrics": {**HANDOFF, "paths": 131072}}
    h = run_headline(s, limits=LIMITS)
    assert "VaR99 74.35 $mm (95% MC band 73.60-75.10)" in h and "L-VaR99 79.63 $mm (95% MC band 78.82-80.45)" in h
    assert h.endswith("131,072 paths. Within MC error: L-VaR 99% pass vs warning level 80.00.")
    assert "within MC error" not in run_headline(s)


def test_real_run_carries_band_keys(run_dict):
    """Team B's engine stores the band on every run (VF-004); a fresh small run has it."""
    res = run_pipeline(load_universe(DATA), Settings.load(DATA / "assumptions.json"), paths=1000, as_of="2026-10-23")
    for k in ("var99_mm", "es99_mm", "lvar99_mm"):
        lo, hi = B.band(res.metrics, k)
        assert lo <= res.metrics[k] <= hi
