"""`econquest review decide|list` over the review ledger, and --dry-run on every workbook writer (EQ-C-0014,
HO-20261023-A-C-005)."""
import shutil
from pathlib import Path

import pytest

from econquest import cli
from econquest.ingestion import read_ledger
from econquest.presentation import sheets_publish as sp

ROOT = Path(__file__).resolve().parent.parent


def review(d, *a):
    cli.main(["--data", str(d), "review", *a])


def test_decide_appends_one_row_and_list_shows_it(tmp_path, capsys):
    review(tmp_path, "decide", "--table", "Inputs", "--key", "1.3", "--country", "Argentina", "--decision", "reject",
           "--author", "Sam", "--note", "bad print")
    led = read_ledger(tmp_path)
    assert len(led) == 1 and led.iloc[0][["key", "country", "decision", "author", "note"]].tolist() == ["1.3", "Argentina", "reject", "Sam", "bad print"]
    review(tmp_path, "list")
    o = capsys.readouterr().out
    assert "Recorded:" in o and "Argentina" in o and "reject" in o


def test_decide_four_eyes_on_held_cell(tmp_path):
    base = ["decide", "--table", "Inputs", "--key", "1.3", "--country", "Argentina", "--decision", "apply", "--gate-status", "hold", "--live", "5"]
    with pytest.raises(SystemExit, match="approver"):
        review(tmp_path, *base, "--author", "Sam")
    assert len(read_ledger(tmp_path)) == 0
    review(tmp_path, *base, "--author", "Sam", "--approver", "Ana")
    review(tmp_path, *base, "--author", "Sam", "--self-approved")
    led = read_ledger(tmp_path)
    assert led["approver"].tolist() == ["Ana", "Sam"] and led["self_approved"].tolist() == ["", "yes"]


def test_list_empty(tmp_path, capsys):
    review(tmp_path, "list")
    assert "No review decisions recorded." in capsys.readouterr().out


WRITERS = {"publish": "cmd_publish", "garch": "cmd_garch", "econ": "cmd_econ", "audit": "cmd_audit", "record": "cmd_record",
           "dsa": "cmd_dsa", "benchmark": "cmd_benchmark"}


@pytest.mark.parametrize("cmd", list(WRITERS))
def test_dry_run_never_resolves_a_token(monkeypatch, tmp_path, cmd):
    f = tmp_path / "tok"; f.write_text("secret")
    monkeypatch.setenv(cli.TOKEN_ENV, "secret")
    monkeypatch.setattr(cli, "resolve_token", lambda args: pytest.fail("token looked up in a dry run"))
    monkeypatch.setattr(cli, "_keychain_token", lambda: pytest.fail("Keychain called in a dry run"))
    seen = []
    monkeypatch.setattr(cli, WRITERS[cmd], lambda args: seen.append(args.token))
    cli.main([cmd, "--dry-run", "--write", "--token-file", str(f)])
    assert seen == [None]


def test_audit_dry_run_makes_no_network_call(monkeypatch, tmp_path, capsys):
    d = tmp_path / "data"
    shutil.copytree(ROOT / "data", d, ignore=shutil.ignore_patterns("vintages", "snapshots", "panel", "market_history"))
    monkeypatch.setenv(cli.TOKEN_ENV, "secret")
    monkeypatch.setattr(sp.urllib.request, "urlopen", lambda *a, **k: pytest.fail("Sheets called in a dry run"))
    monkeypatch.setattr(sp, "apply_plan", lambda *a, **k: pytest.fail("apply_plan called in a dry run"))
    cli.main(["--data", str(d), "--out", str(tmp_path / "out"), "audit", "--dry-run", "--write"])
    assert (tmp_path / "out" / "audit_plan.json").exists()
    assert "Dry run" in capsys.readouterr().err


# ---------------------------------------------------------------- review against a saved vintage (HO-20261023-A-C-016)
# `review list --pending --vintage`, `review approve`, `review apply` over feeds.vintage_review / record_vintage_decisions /
# apply_vintage (EQ-A-0035). The vintage is synthetic, built like tests/test_apply_vintage.py `_vintage` (SYNTHETIC values,
# not real data); every test blocks the network.
import datetime as dt  # noqa: E402
import socket  # noqa: E402
import urllib.request  # noqa: E402

import numpy as np  # noqa: E402
import pandas as pd  # noqa: E402

from econquest.ingestion.feeds import FetchReport, save_vintage  # noqa: E402

SEED = ROOT / "tests" / "seed_data"
CLOCK = dt.datetime(2026, 10, 23, 21, 30, 0, tzinfo=dt.timezone.utc)


@pytest.fixture
def offline(monkeypatch):
    def refuse(*a, **k):
        pytest.fail("network call")
    monkeypatch.setattr(socket.socket, "connect", refuse)
    monkeypatch.setattr(socket, "create_connection", refuse)
    monkeypatch.setattr(urllib.request, "urlopen", refuse)


def _vintage(d: Path, fx: float = 31.25, now=CLOCK) -> str:
    ind = pd.DataFrame({"Vietnam": [36.5, 41.0]}, index=["1.3", "2.10"])
    prof = pd.DataFrame(np.nan, index=["Vietnam", "Brazil"], columns=["pop", "exports", "reserves", "fx3m", "policy", "equity_vol"])
    prof.at["Brazil", "fx3m"] = fx
    prov = pd.DataFrame([{"table": "Country Profile", "key": "fx3m", "country": "Brazil", "value": fx, "source": "test",
                          "series": "BRL=X", "retrieved": "2026-10-23"}])
    raw = {"yahoo": pd.DataFrame([{"iso": "BRA", "series": "BRL=X", "period": "2026-10-23", "value": 5.6, "source": "test"}])}
    rep = FetchReport(ind, prof, prov, {"yahoo": "ok (1 rows)", "weo": "ok (2 rows)"}, raw)
    rev = pd.DataFrame([
        {"table": "Inputs", "key": "1.3", "country": "Vietnam", "seed": 33.0, "live": 36.5, "status": "ok", "reason": ""},
        {"table": "Inputs", "key": "2.10", "country": "Vietnam", "seed": 40.0, "live": 41.0, "status": "ok", "reason": ""},
        {"table": "Country Profile", "key": "fx3m", "country": "Brazil", "seed": 0.0, "live": fx, "status": "hold",
         "reason": f"change: 0 -> {fx:.4g}"},
    ]).assign(decision="", author="", approver="", self_approved="", decided_utc="")
    return save_vintage(d, rep, rev, now=now).name


def _setup(tmp_path):
    d = tmp_path / "data"
    shutil.copytree(ROOT / "tests" / "seed_data", d)
    return d, _vintage(d)


def rv(tmp_path, *a):
    cli.main(["--data", str(tmp_path / "data"), "--out", str(tmp_path / "out"), "review", *a])


def _fx(d):
    return pd.read_csv(d / "countries.csv", dtype=str).set_index("country").at["Brazil", "fx3m"]


def _actions(tmp_path, command):
    from econquest.ops import actionlog as AL
    return [r for r in AL.read(tmp_path / "out") if r["command"] == command]


def _effective(out: str) -> str:
    line = next(x for x in out.splitlines() if "fx3m" in x and "Brazil" in x and not x.startswith(("Decide", "Then")))
    return line.split()[-1]


def test_vintage_acceptance_list_approve_apply_offline(tmp_path, capsys, offline):
    d, vid = _setup(tmp_path)
    fx_before = _fx(d)
    # 1. the held cell of the vintage shows effective `held`
    rv(tmp_path, "list", "--pending", "--vintage", vid)
    o = capsys.readouterr().out
    assert f"vintage {vid} (latest): 1 held cell(s), 1 with no approved apply" in o
    assert _effective(o) == "held" and "1.3" not in o                    # ok cells are not listed
    assert "Decide one: econquest review approve TABLE KEY COUNTRY [TABLE KEY COUNTRY ...] --author NAME" in o and f"--vintage {vid}" in o
    # 2. four-eyes: --author alone exits non-zero and writes no ledger row
    with pytest.raises(SystemExit) as e:
        rv(tmp_path, "approve", "Country Profile", "fx3m", "Brazil", "--author", "Sam")
    assert e.value.code not in (0, None) and str(e.value.code).startswith("review approve: ")
    assert "four-eyes" in str(e.value.code) and "--self-approved" in str(e.value.code) and "nothing recorded" in str(e.value.code)
    assert len(read_ledger(d)) == 0
    assert [r["outcome"] for r in _actions(tmp_path, "review approve")] == ["error"]
    # 3. --self-approved writes one row with the vintage id and the vintage's live value
    rv(tmp_path, "approve", "Country Profile", "fx3m", "Brazil", "--author", "Sam", "--self-approved", "--note", "real 3m FX move")
    o = capsys.readouterr().out
    led = read_ledger(d)
    assert len(led) == 1
    r = led.iloc[0]
    assert (r["table"], r["key"], r["country"], r["decision"], r["vintage_id"], r["gate_status"], r["self_approved"]) == \
        ("Country Profile", "fx3m", "Brazil", "apply", vid, "hold", "yes")
    assert float(r["live"]) == 31.25
    assert f"Recorded: Country Profile fx3m Brazil  decision=apply vintage_id={vid} live=31.25 approver=Sam self_approved=yes" in o
    assert "1 decision(s) recorded." in o and f"econquest review apply --vintage {vid}" in o
    ok = [x for x in _actions(tmp_path, "review approve") if x["outcome"] == "ok"]
    assert len(ok) == 1 and ok[0]["actor"] == "Sam" and ok[0]["args"]["batch"] == "1/1" and ok[0]["args"]["country"] == "Brazil"
    rv(tmp_path, "list", "--pending", "--vintage", vid)
    assert _effective(capsys.readouterr().out) == "released"
    # 4. dry run writes nothing
    rv(tmp_path, "apply", "--dry-run")
    o = capsys.readouterr().out
    assert f"Dry run: vintage {vid} (latest): 2 apply, 1 released; nothing written" in o
    assert _fx(d) == fx_before and _actions(tmp_path, "review apply") == []
    # 5. apply writes countries.csv with the live fx3m and prints the cell under `released`
    rv(tmp_path, "apply")
    o = capsys.readouterr().out
    assert float(_fx(d)) == 31.25
    assert "Applied: {" in o and f"'vintage_id': '{vid}'" in o
    lines = o.splitlines()
    i = lines.index("released (1):")
    assert lines[i + 1].strip() == "Country Profile fx3m Brazil  live=31.25" and "still_held (0):" in lines
    assert [x["outcome"] for x in _actions(tmp_path, "review apply")] == ["ok"]


def test_approve_several_cells_checked_before_any_is_written(tmp_path, capsys, offline):
    d, vid = _setup(tmp_path)
    with pytest.raises(SystemExit, match="review approve: not in the review of vintage"):
        rv(tmp_path, "approve", "Country Profile", "fx3m", "Brazil", "Inputs", "1.1", "Nowhere", "--author", "Sam", "--self-approved")
    assert len(read_ledger(d)) == 0
    rv(tmp_path, "approve", "Country Profile", "fx3m", "Brazil", "Inputs", "1.3", "Vietnam", "--author", "Sam", "--approver", "Ana",
       "--vintage", vid)
    led = read_ledger(d)
    assert led[["key", "country", "gate_status", "approver", "vintage_id"]].values.tolist() == [
        ["fx3m", "Brazil", "hold", "Ana", vid], ["1.3", "Vietnam", "ok", "Ana", vid]]
    assert [x["outcome"] for x in _actions(tmp_path, "review approve")] == ["error", "ok", "ok"]
    assert [x["args"]["batch"] for x in _actions(tmp_path, "review approve")[1:]] == ["1/2", "2/2"]
    assert "2 decision(s) recorded." in capsys.readouterr().out


def test_approve_hold_needs_no_approver_and_keeps_cell_on_seed(tmp_path, capsys, offline):
    d, vid = _setup(tmp_path)
    fx_before = _fx(d)
    rv(tmp_path, "approve", "Country Profile", "fx3m", "Brazil", "--author", "Sam", "--decision", "hold")
    assert read_ledger(d)["decision"].tolist() == ["hold"]
    assert "review apply" not in capsys.readouterr().out
    rv(tmp_path, "apply")
    o = capsys.readouterr().out
    assert _fx(d) == fx_before and "released (0):" in o and "still_held (1):" in o


def test_approve_argument_errors(tmp_path, offline):
    d, vid = _setup(tmp_path)
    with pytest.raises(SystemExit, match="review approve: give cells as TABLE KEY COUNTRY triples.*got 2 value"):
        rv(tmp_path, "approve", "Country Profile", "fx3m", "--author", "Sam", "--self-approved")
    with pytest.raises(SystemExit, match='review approve: the table of a cell is Inputs or "Country Profile", got Profile fx3m Brazil'):
        rv(tmp_path, "approve", "Profile", "fx3m", "Brazil", "--author", "Sam", "--self-approved")
    with pytest.raises(SystemExit, match="review approve: .*no-such-vintage"):
        rv(tmp_path, "approve", "Country Profile", "fx3m", "Brazil", "--author", "Sam", "--self-approved", "--vintage", "no-such-vintage")
    assert len(read_ledger(d)) == 0


def test_list_and_apply_refusals(tmp_path, capsys, offline):
    (tmp_path / "data").mkdir()
    with pytest.raises(SystemExit, match="review apply: no vintage"):
        rv(tmp_path, "apply")
    with pytest.raises(SystemExit, match="review list: --vintage needs --pending"):
        rv(tmp_path, "list", "--vintage", "x")
    d, vid = _setup(tmp_path / "b")
    with pytest.raises(SystemExit, match="review list: "):
        rv(tmp_path / "b", "list", "--pending", "--vintage", "no-such-vintage")
    rv(tmp_path / "b", "list", "--pending")                     # without --vintage: unchanged (data/live/review.csv)
    assert "No held cells waiting for a decision." in capsys.readouterr().out


def test_apply_older_vintage_warns(tmp_path, capsys, offline):
    d, old = _setup(tmp_path)
    new = _vintage(d, fx=32.0, now=CLOCK + dt.timedelta(hours=1))
    assert old != new
    fx_before = _fx(d)
    with pytest.raises(SystemExit) as ei:                  # SEC-A-004 L2: apply_vintage refuses before any write
        rv(tmp_path, "apply", "--vintage", old)
    msg = str(ei.value.code)
    assert msg.startswith("review apply: vintage ") and old in msg and new in msg and "--allow-older" in msg and "\n" not in msg
    assert _fx(d) == fx_before and not list(d.rglob("rollback.json"))
    capsys.readouterr()
    rv(tmp_path, "apply", "--vintage", old, "--dry-run")   # --dry-run on an older vintage still works without the flag
    assert "not the latest" in capsys.readouterr().out
    rv(tmp_path, "apply", "--vintage", old, "--allow-older")
    c = capsys.readouterr()
    assert f"'vintage_id': '{old}'" in c.out
    assert f"rollback: {old} re-applied over latest {new} at " in c.out and "rollback.json" in c.out
    assert len(list(d.rglob("rollback.json"))) == 1
    assert f"warning: {old} is not the latest vintage ({new}): re-applying an older vintage also re-applies its ok cells" in c.err
    rv(tmp_path, "apply", "--vintage", new, "--dry-run")
    assert "warning" not in capsys.readouterr().err


def test_apply_date_id_of_latest_vintage_is_not_refused(tmp_path, capsys, offline):
    """HO-20261024-A-C-003: the CLI pre-check compared the raw --vintage string with latest_vintage, so a date id that
    resolves to the latest vintage was refused as 'not the latest'. apply_vintage now checks the resolved id."""
    d, vid = _setup(tmp_path)
    rv(tmp_path, "apply", "--vintage", vid[:10])
    o = capsys.readouterr()
    assert f"'vintage_id': '{vid}'" in o.out and "rollback:" not in o.out and "warning" not in o.err


def test_review_vintage_commands_action_labels():
    ns = type("A", (), {})
    a = ns(); a.cmd, a.review_cmd, a.dry_run = "review", "apply", False
    assert cli.action_label(a, False) == "review apply"
    a.dry_run = True
    assert cli.action_label(a, False) is None
    b = ns(); b.cmd, b.review_cmd, b.cell, b.all_pending = "review", "approve", None, False
    assert cli.action_label(b, False) is None                  # approve logs one row per cell itself
    assert "author" in cli.ACTOR_FLAGS and "approver" in cli.ACTOR_FLAGS


# ---------------------------------------------------------------- AGENT-09 SEC-C-007 (EQ-C-0059)
@pytest.mark.parametrize("body", ["", "table,key\nInputs,1.3\n", "status\nhold\n"])
@pytest.mark.parametrize("cmd", [["list", "--pending"], ["decide", "--all-pending", "--decision", "apply", "--author", "Sam"],
                                 ["decide", "--cell", "Inputs", "1.3", "X", "--decision", "hold", "--author", "Sam"]])
def test_malformed_review_csv_is_a_clean_refusal(tmp_path, offline, body, cmd):
    """L2: an empty review.csv or one without the table/key/country columns gave a KeyError/EmptyDataError traceback."""
    d = tmp_path / "data"; (d / "live").mkdir(parents=True)
    (d / "live" / "review.csv").write_text(body)
    with pytest.raises(SystemExit, match=r"review: (cannot read|.*lacks the column)"):
        rv(tmp_path, *cmd)
    assert len(read_ledger(d)) == 0


def test_gui_would_strip_review_identity_flags(tmp_path, monkeypatch):
    from econquest.presentation import gui
    assert "review" not in gui.ALLOWED_CMDS and "review" in gui.IDENTITY_CMDS      # not a GUI command; stripped if ever allowed
    seen = {}

    class FakePopen:
        def __init__(self, argv, **kw):
            seen["argv"] = argv
            self.stdout = iter(()); self.returncode = 0

        def poll(self):
            return 0

        def wait(self):
            return 0
    monkeypatch.setattr(gui.subprocess, "Popen", FakePopen)
    monkeypatch.setattr(gui, "ALLOWED_CMDS", gui.ALLOWED_CMDS | {"review"})
    gui.Jobs(str(tmp_path), str(tmp_path)).start("review", ["approve", "Inputs", "1.3", "Vietnam", "--author", "Sam", "--self-appr",
                                                             "--approver=Bob", "--appro", "Ana"])
    assert seen["argv"][seen["argv"].index("review") + 1:] == ["approve", "Inputs", "1.3", "Vietnam"]


@pytest.mark.parametrize("host,ok", [("127.0.0.1", True), ("localhost", True), ("::1", True), ("127.0.0.2", True),
                                     ("0.0.0.0", False), ("192.168.1.5", False), ("example.com", False), ("::", False)])
def test_gui_and_serve_bind_loopback_only(host, ok):
    from econquest import cli as C
    if ok:
        assert C._loopback_host(host, "gui")
    else:
        with pytest.raises(SystemExit, match="not a loopback"):
            C._loopback_host(host, "gui")
