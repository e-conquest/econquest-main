"""Run gate for unattested hand-entered cells (EQ-C-0034): warn carries on, block exits before any Sheets call,
--dry-run never blocks, --allow-unattested is recorded, policy overrides from ops.json and $ECONQUEST_RUN_GATE."""
import json

import pytest

from econquest import cli
from econquest.ingestion.ledger import attest_cells
from econquest.ops import actionlog as AL
from econquest.presentation import sheets_publish as sp

SECRET = "ya29.gate-test-secret-token"


@pytest.fixture
def env(tmp_path, monkeypatch):
    for v in (cli.RUN_GATE_ENV, AL.LOG_ENV, cli.TOKEN_ENV):
        monkeypatch.delenv(v, raising=False)
    d = tmp_path / "data"; d.mkdir()
    (d / "prediction_markets.csv").write_text("id,country,contract,yes_price\nPM1,Argentina,Default by 2027,0.12\nPM2,Ghana,Default,0.3\n")
    (d / "cds_quotes.csv").write_text("country,date,tenor_y,spread_bp,recovery,source\nArgentina,2026-10-20,5,900,0.4,desk\n")
    out = tmp_path / "outputs"
    monkeypatch.setattr(sp, "apply_plan", lambda *a, **k: pytest.fail("Sheets called"))
    monkeypatch.setattr(sp.urllib.request, "urlopen", lambda *a, **k: pytest.fail("network called"))
    return d, out


def call(env, *argv):
    d, out = env
    return cli.main(["--data", str(d), "--out", str(out), *argv])


def stub(monkeypatch, name):
    seen = []
    monkeypatch.setattr(cli, name, lambda args: seen.append(args))
    return seen


def test_warn_path_prints_counts_and_fix_and_continues(env, monkeypatch, capsys):
    seen = stub(monkeypatch, "cmd_run")
    call(env, "run")
    err = capsys.readouterr().err
    assert len(seen) == 1
    # usability U02 (EQ-C-0063): a warning is one short line with the count and the hint; the policy is unchanged
    assert err.strip() == "warning: 3 hand-entered cell(s) not attested; run continues (run gate 'warn'). List and fix: econquest attest --list"


def test_block_message_keeps_the_full_fix(env, monkeypatch, capsys):
    monkeypatch.setenv(cli.TOKEN_ENV, SECRET)
    with pytest.raises(SystemExit):
        call(env, "publish", "--write")
    err = capsys.readouterr().err
    assert "3 hand-entered cell(s) are not attested" in err
    assert "cds_quotes.csv 1" in err and "prediction_markets.csv 2" in err
    assert "econquest attest --list" in err and "econquest attest --file" in err and "--allow-unattested" in err


@pytest.mark.parametrize("cmd", ["run", "stress", "record", "report", "monitor", "notes", "briefs"])
def test_default_is_warn_for_local_commands(env, monkeypatch, capsys, cmd):
    seen = stub(monkeypatch, f"cmd_{cmd}")
    call(env, cmd)
    assert len(seen) == 1 and "not attested" in capsys.readouterr().err


@pytest.mark.parametrize("cmd", list(cli.WRITER_COMMANDS))
def test_block_path_exits_before_token_and_sheets(env, monkeypatch, capsys, cmd):
    monkeypatch.setenv(cli.TOKEN_ENV, SECRET)
    monkeypatch.setattr(cli, "resolve_token", lambda args: pytest.fail("token looked up although the gate blocks"))
    monkeypatch.setattr(cli, f"cmd_{cmd}", lambda args: pytest.fail("command ran although the gate blocks"))
    with pytest.raises(SystemExit) as e:
        call(env, cmd, "--write")
    assert e.value.code == cli.RUN_GATE_EXIT
    err = capsys.readouterr().err
    assert "blocked" in err and "Nothing was sent to Sheets" in err


def test_token_file_counts_as_a_write(env, monkeypatch, tmp_path):
    f = tmp_path / "tok"; f.write_text(SECRET)
    monkeypatch.setattr(cli, "cmd_publish", lambda args: pytest.fail("ran"))
    with pytest.raises(SystemExit) as e:
        call(env, "publish", "--token-file", str(f))
    assert e.value.code == cli.RUN_GATE_EXIT


@pytest.mark.parametrize("cmd", list(cli.WRITER_COMMANDS))
def test_dry_run_never_blocks(env, monkeypatch, cmd):
    monkeypatch.setenv(cli.TOKEN_ENV, SECRET)
    seen = stub(monkeypatch, f"cmd_{cmd}")
    call(env, cmd, "--write", "--dry-run")
    assert len(seen) == 1 and seen[0].token is None


def test_override_proceeds_and_is_recorded(env, monkeypatch, capsys):
    monkeypatch.setenv(cli.TOKEN_ENV, SECRET)
    seen = stub(monkeypatch, "cmd_publish")
    call(env, "publish", "--write", "--allow-unattested")
    assert [a.token for a in seen] == [SECRET]
    assert "--allow-unattested: proceeding with 3" in capsys.readouterr().err
    rows = AL.read(env[1])
    assert [r["command"] for r in rows] == ["run-gate override", "publish --write"]
    ov = rows[0]["args"]
    assert ov["command"] == "publish --write" and ov["policy"] == "block" and ov["policy_key"] == "sheets_write"
    assert ov["unattested"] == {"cds_quotes": 1, "prediction_markets": 2} and ov["total"] == 3
    assert rows[1]["args"]["allow_unattested"] is True and rows[1]["outcome"] == "ok"
    assert SECRET not in AL.log_path(env[1]).read_text()
    assert AL.verify(env[1])["ok"]


def test_blocked_write_is_logged_with_exit_code(env, monkeypatch):
    monkeypatch.setenv(cli.TOKEN_ENV, SECRET)
    with pytest.raises(SystemExit):
        call(env, "publish", "--write")
    (r,) = AL.read(env[1])
    assert r["command"] == "publish --write" and r["outcome"] == "error" and r["exit_code"] == cli.RUN_GATE_EXIT
    assert "run gate" in r["error"]


def test_attested_cells_pass_silently(env, monkeypatch, capsys):
    d, _ = env
    attest_cells(d, "prediction_markets", "Sam", self_approved=True)
    attest_cells(d, "cds_quotes", "Sam", approver="Ana")
    monkeypatch.setenv(cli.TOKEN_ENV, SECRET)
    seen = stub(monkeypatch, "cmd_publish")
    call(env, "publish", "--write")
    assert len(seen) == 1 and "attested" not in capsys.readouterr().err


def test_env_override_blocks_run(env, monkeypatch):
    monkeypatch.setenv(cli.RUN_GATE_ENV, "run=block")
    monkeypatch.setattr(cli, "cmd_run", lambda args: pytest.fail("ran"))
    with pytest.raises(SystemExit) as e:
        call(env, "run")
    assert e.value.code == cli.RUN_GATE_EXIT


def test_env_off_disables_everything(env, monkeypatch, capsys):
    monkeypatch.setenv(cli.RUN_GATE_ENV, "off")
    monkeypatch.setenv(cli.TOKEN_ENV, SECRET)
    seen = stub(monkeypatch, "cmd_publish")
    call(env, "publish", "--write")
    assert len(seen) == 1 and "attested" not in capsys.readouterr().err


def test_ops_json_per_writer_key_beats_sheets_write(env, monkeypatch, capsys):
    d, out = env
    (out.parent / "ops.json").write_text(json.dumps({"run_gate": {"garch:write": "warn"}}))
    monkeypatch.setenv(cli.TOKEN_ENV, SECRET)
    seen = stub(monkeypatch, "cmd_garch")
    call(env, "garch", "--write")
    assert len(seen) == 1 and "run gate 'warn'" in capsys.readouterr().err
    monkeypatch.setattr(cli, "cmd_publish", lambda args: pytest.fail("ran"))
    with pytest.raises(SystemExit):
        call(env, "publish", "--write")                                       # still blocked by sheets_write


def test_env_wins_over_ops_json(env, monkeypatch):
    d, out = env
    (out.parent / "ops.json").write_text(json.dumps({"run_gate": "warn"}))
    monkeypatch.setenv(cli.RUN_GATE_ENV, "block")
    monkeypatch.setattr(cli, "cmd_run", lambda args: pytest.fail("ran"))
    with pytest.raises(SystemExit):
        call(env, "run")


def test_bad_policy_value_is_an_error(env, monkeypatch):
    monkeypatch.setenv(cli.RUN_GATE_ENV, "run=maybe")
    stub(monkeypatch, "cmd_run")
    with pytest.raises(SystemExit, match="must be one of"):
        call(env, "run")


def test_ungated_commands_have_no_flag_and_no_check(env, monkeypatch):
    monkeypatch.setattr(cli, "_unattested_counts", lambda d: pytest.fail("checked"))
    seen = stub(monkeypatch, "cmd_scenarios")
    call(env, "scenarios")
    assert not hasattr(seen[0], "allow_unattested")


def test_audit_plan_only_is_not_gated(env, monkeypatch):
    monkeypatch.setattr(cli, "_unattested_counts", lambda d: pytest.fail("checked"))
    seen = stub(monkeypatch, "cmd_audit")
    call(env, "audit")
    assert len(seen) == 1


def test_unreadable_ledger_fails_closed_on_block(env, monkeypatch):
    def boom(d):
        raise ValueError("ledger unreadable")
    monkeypatch.setattr(cli, "_unattested_counts", boom)
    monkeypatch.setenv(cli.TOKEN_ENV, SECRET)
    monkeypatch.setattr(cli, "cmd_publish", lambda args: pytest.fail("ran"))
    with pytest.raises(SystemExit) as e:
        call(env, "publish", "--write")
    assert e.value.code == cli.RUN_GATE_EXIT
    seen = stub(monkeypatch, "cmd_run")
    call(env, "run")                                                          # warn: carries on
    assert len(seen) == 1


@pytest.mark.parametrize("flag", ["--allow-unattested", "--allow-u", "--allow", "--a"])
def test_gui_strips_allow_unattested(monkeypatch, tmp_path, flag):
    # regression (AGENT-09 review of EQ-C-0034, SEC-C-004): a GUI publish with a token and --allow-unattested passed the
    # sheets_write block; GUI jobs carry no identity, so the override is CLI-only
    import io
    from econquest.presentation import gui

    class FakePopen:
        def __init__(self, argv, **kw):
            FakePopen.argv = argv; self.stdout = io.StringIO(""); self.returncode = 0
        def poll(self): return 0
        def wait(self): return 0
    monkeypatch.setattr(gui.subprocess, "Popen", FakePopen)
    gui.Jobs(str(tmp_path), str(tmp_path)).start("publish", ["--mc-rows", "100", flag], sheets_token="tok")
    tail = FakePopen.argv[FakePopen.argv.index("publish") + 1:]
    assert tail == ["--mc-rows", "100", "--write"]


def test_override_that_cannot_be_logged_is_refused(env, monkeypatch):
    # regression (AGENT-09 review of EQ-C-0035, SEC-C-004): a logging failure was only a warning, so --allow-unattested
    # passed the sheets_write block with no record of who overrode it
    monkeypatch.setenv(cli.TOKEN_ENV, SECRET)
    seen = stub(monkeypatch, "cmd_publish")
    monkeypatch.setattr(AL, "append", lambda *a, **k: (_ for _ in ()).throw(OSError("disk full")))
    with pytest.raises(SystemExit) as e:
        call(env, "publish", "--write", "--allow-unattested")
    assert e.value.code == cli.RUN_GATE_EXIT and seen == []


def test_smtp_password_and_webhook_masked_in_action_log(env, monkeypatch):
    monkeypatch.setenv("ECONQUEST_SMTP_PASSWORD", "hunter2-smtp-pw")
    monkeypatch.setenv("ECONQUEST_ALERT_WEBHOOK", "https://hooks.example/T000/B000/XXXXsecret")
    def boom(args):
        raise RuntimeError("smtp login hunter2-smtp-pw failed; webhook https://hooks.example/T000/B000/XXXXsecret")
    monkeypatch.setattr(cli, "cmd_publish", boom)
    with pytest.raises(RuntimeError):
        call(env, "publish", "--write", "--allow-unattested", "--token-file", __file__)
    text = AL.log_path(env[1]).read_text()
    assert "hunter2-smtp-pw" not in text and "XXXXsecret" not in text and "***" in text
