"""GUI/API request guard: other web pages must not drive or read the local server (EQ-C-0005)."""
import http.client
import json
import threading
from http.server import ThreadingHTTPServer
from pathlib import Path

import pytest

from econquest.presentation import api
from econquest.presentation.gui import make_gui_handler


class StubApp:
    token = "test-token-123"
    latest = {"summary": {"run_id": "r1"}}


class StubJobs:
    def __init__(self):
        self.started = []
        self.jobs = []

    def start(self, cmd, args, secrets=None):
        self.started.append((cmd, args))
        return {"id": 1, "cmd": cmd}

    def running(self):
        return False

    def list(self):
        return []


@pytest.fixture
def server(tmp_path):
    jobs = StubJobs()
    srv = ThreadingHTTPServer(("127.0.0.1", 0), make_gui_handler(StubApp(), jobs, tmp_path, tmp_path))
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    yield srv.server_address[1], jobs
    srv.shutdown()


def request(port, method, path, body=None, headers=None):
    conn = http.client.HTTPConnection("127.0.0.1", port, timeout=5)
    h = {"Host": f"127.0.0.1:{port}"}
    h.update(headers or {})
    conn.request(method, path, body=body, headers=h)
    r = conn.getresponse()
    return r.status, dict(r.getheaders()), r.read().decode()


JOB = json.dumps({"cmd": "publish", "args": ["--token", "x"]})


def good(port, **extra):
    return {"Content-Type": "application/json", api.TOKEN_HEADER: StubApp.token,
            "Origin": f"http://127.0.0.1:{port}", **extra}


def test_page_carries_token_and_no_cors_header(server):
    port, _ = server
    status, headers, page = request(port, "GET", "/")
    assert status == 200
    assert 'content="test-token-123"' in page and "__ECONQUEST_TOKEN__" not in page
    assert "Access-Control-Allow-Origin" not in headers
    assert headers.get("X-Frame-Options") == "DENY"


def test_same_origin_job_with_token_runs(server):
    port, jobs = server
    status, _, _ = request(port, "POST", "/api/job", JOB, good(port))
    assert status == 200 and jobs.started == [("publish", ["--token", "x"])]


@pytest.mark.parametrize("change", [
    {api.TOKEN_HEADER: ""},                                   # no token
    {api.TOKEN_HEADER: "guess"},                              # wrong token
    {"Origin": "https://evil.example"},                       # cross-origin page
    {"Content-Type": "text/plain"},                           # simple CORS request, no preflight
])
def test_cross_site_job_requests_are_refused(server, change):
    port, jobs = server
    status, _, body = request(port, "POST", "/api/job", JOB, good(port, **change))
    assert status == 403 and "error" in json.loads(body)
    assert jobs.started == []


def test_dns_rebinding_host_is_refused(server):
    port, jobs = server
    status, _, _ = request(port, "GET", "/api/jobs", headers={"Host": f"evil.example:{port}"})
    assert status == 403
    status, _, _ = request(port, "POST", "/api/job", JOB, good(port, Host=f"evil.example:{port}"))
    assert status == 403 and jobs.started == []


def test_gui_page_escapes_inserted_strings():
    page = (Path(api.__file__).parent / "static" / "gui.html").read_text()
    for raw in ("<td>${j.argv}</td>", '12px">${full.argv}</span>', "${pt.proposal.country}", '"color:var(--red)">${t}</p>'):
        assert raw not in page
    assert 'method: "POST", headers: { "Content-Type": "application/json" }' not in page  # every POST goes through post()


@pytest.mark.parametrize("body", ["{not json", "[1, 2]"])
def test_malformed_job_body_is_a_400_not_a_crash(server, body):
    # regression (EQ-C-0003): json.loads on POST /api/job was unguarded and dropped the connection
    port, jobs = server
    status, _, out = request(port, "POST", "/api/job", body, good(port))
    assert status == 400 and "error" in json.loads(out)
    assert jobs.started == []
