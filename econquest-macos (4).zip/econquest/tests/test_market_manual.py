"""EQ-A-0032: attested manual entry of hand-typed market quotes. Values are SYNTHETIC."""
import datetime as dt
import shutil
from pathlib import Path

import pandas as pd
import pytest

from econquest.ingestion import ledger
from econquest.ingestion.market.manual import (MANUAL_COLUMNS, TABLE, cds_quotes_migration, enter_quotes,
                                               manual_path, read_manual, unattested_manual)
from econquest.ingestion.market.schema import MarketDataError, to_cds_quotes
from econquest.ingestion.market.store import latest_market, list_market_snapshots

SEED = Path(__file__).parent / "seed_data"
NOW = dt.datetime(2026, 10, 21, 9, 0, tzinfo=dt.timezone.utc)
ROWS = [{"asof": "2026-10-20", "instrument": "cds", "iso": "BRA", "currency": "USD", "tenor_y": 5,
         "field": "spread_bp", "value": 200, "doc_clause": "CR14"},
        {"asof": "2026-10-20", "instrument": "cds", "iso": "BRA", "currency": "USD", "tenor_y": 0,
         "field": "recovery", "value": 0.4, "doc_clause": "CR14"},
        {"asof": "2026-10-20", "instrument": "embi_spread", "iso": "BRA", "currency": "USD", "tenor_y": 0,
         "field": "spread_bp", "value": 210}]


def test_four_eyes_entry_writes_csv_ledger_snapshot(tmp_path):
    res = enter_quotes(tmp_path, ROWS, "Ana Analyst", "Sam", note="typed from dealer run (SYNTHETIC)", now=NOW)
    m = read_manual(tmp_path)
    assert list(m.columns) == MANUAL_COLUMNS and len(m) == 3
    assert set(m["source"]) == {"manual"} and set(m["licence"]) == {"n/a (hand-entered)"}
    assert set(m["author"]) == {"Ana Analyst"} and set(m["approver"]) == {"Sam"} and set(m["self_approved"]) == {""}
    assert set(m["unit"]) == {"bp", "fraction"}
    led = ledger.read_ledger(tmp_path)
    led = led[led["table"] == TABLE]
    assert len(led) == 3 and set(led["decision"]) == {"apply"} and set(led["country"]) == {"BRA"}
    assert set(led["content_sha256"]) == set(m["content_sha256"])
    assert list_market_snapshots(tmp_path)["snapshot_id"].tolist() == [res["snapshot"].name]
    assert unattested_manual(tmp_path) == []
    q = to_cds_quotes(latest_market(tmp_path, "cds"), country_names={"BRA": "Brazil"})
    assert q[["country", "spread_bp", "recovery"]].values.tolist() == [["Brazil", 200.0, 0.4]]
    assert q["source"].iloc[0].startswith("manual ")


def test_approval_rules_nothing_written_on_refusal(tmp_path):
    for appr in (None, "", "ana analyst", " Ana  Analyst "):
        with pytest.raises(ValueError, match="four-eyes"):
            enter_quotes(tmp_path, ROWS, "Ana Analyst", appr, now=NOW)
    assert not manual_path(tmp_path).exists() and ledger.read_ledger(tmp_path).empty
    res = enter_quotes(tmp_path, ROWS, "Sam", self_approved=True, now=NOW)            # single-operator, flagged
    assert set(res["rows"]["self_approved"]) == {"yes"} and set(res["rows"]["approver"]) == {"Sam"}
    assert unattested_manual(tmp_path) == []
    with pytest.raises(ValueError, match="author"):
        enter_quotes(tmp_path, ROWS, "", "Sam", now=NOW)


def test_schema_violations_refused_before_write(tmp_path):
    bad = [dict(ROWS[0], iso="BR")]
    with pytest.raises(MarketDataError, match="iso"):
        enter_quotes(tmp_path, bad, "Ana", "Sam", now=NOW)
    with pytest.raises(MarketDataError, match="source"):
        enter_quotes(tmp_path, [dict(ROWS[0], source="bloomberg")], "Ana", "Sam", now=NOW)
    with pytest.raises(MarketDataError, match="unexpected columns"):
        enter_quotes(tmp_path, [dict(ROWS[0], comment="x")], "Ana", "Sam", now=NOW)
    with pytest.raises(MarketDataError, match="future"):
        enter_quotes(tmp_path, [dict(ROWS[0], asof="2026-10-22")], "Ana", "Sam", now=NOW)
    with pytest.raises(MarketDataError, match="duplicate"):
        enter_quotes(tmp_path, [ROWS[0], ROWS[0]], "Ana", "Sam", now=NOW)
    with pytest.raises(MarketDataError, match="note"):
        enter_quotes(tmp_path, ROWS, "Ana", "Sam", note="=HYPERLINK(1)", now=NOW)
    with pytest.raises(MarketDataError, match="no rows"):
        enter_quotes(tmp_path, [], "Ana", "Sam", now=NOW)
    assert not manual_path(tmp_path).exists() and ledger.read_ledger(tmp_path).empty


def test_correction_is_appended_and_wins(tmp_path):
    enter_quotes(tmp_path, ROWS[:1], "Ana", "Sam", now=NOW)
    enter_quotes(tmp_path, [dict(ROWS[0], value=205)], "Ana", "Sam", note="typo fix",
                 now=NOW + dt.timedelta(minutes=5))
    assert read_manual(tmp_path)["value"].tolist() == ["200", "205"]
    assert latest_market(tmp_path, "cds")["value"].tolist() == [205]
    assert latest_market(tmp_path, "cds", asof=NOW + dt.timedelta(minutes=1))["value"].tolist() == [200]


def test_unattested_detects_edit_and_withdrawal(tmp_path):
    enter_quotes(tmp_path, ROWS, "Ana", "Sam", now=NOW)
    p = manual_path(tmp_path)
    df = pd.read_csv(p, dtype=str, keep_default_na=False)
    df.loc[(df["field"] == "spread_bp") & (df["instrument"] == "cds"), "value"] = "250"   # hand edit after entry
    df.to_csv(p, index=False)
    un = unattested_manual(tmp_path)
    assert len(un) == 1 and "edited" in un[0]["reason"]
    assert un[0]["key"] == "2026-10-20|cds|USD|5|spread_bp|CR14"
    ledger.record_decision(tmp_path, TABLE, "2026-10-20|cds|USD|0|recovery|CR14", "BRA", "hold", "Sam",
                           note="dealer level doubtful")
    reasons = [u["reason"] for u in unattested_manual(tmp_path)]
    assert len(reasons) == 2 and any("withdrawn" in r for r in reasons)


def test_attest_rows_guards(tmp_path):
    with pytest.raises(ValueError, match="bad attestation table"):
        ledger.attest_rows(tmp_path, "cds_quotes", [], "a", "b")
    with pytest.raises(ValueError, match="content_sha256"):
        ledger.attest_rows(tmp_path, TABLE, [{"key": "k", "country": "BRA", "value": 1}], "a", "b")


def test_cds_quotes_migration_read_only(tmp_path):
    d = tmp_path / "data"; shutil.copytree(SEED, d)
    (d / "cds_quotes.csv").write_text("country,date,tenor_y,spread_bp,recovery,source\n")
    assert cds_quotes_migration(d)[1] == 0
    (d / "cds_quotes.csv").write_text("country,date,tenor_y,spread_bp,recovery,source\n"
                                      "Argentina,2026-10-20,5,1450,0.25,desk\nBrazil,2026-10-20,5,180,,desk\n")
    before = (d / "cds_quotes.csv").read_bytes()
    rows, n = cds_quotes_migration(d)
    assert n == 2 and len(rows) == 3 and (d / "cds_quotes.csv").read_bytes() == before
    assert "assumed USD" in rows.attrs["note"] and not (d / "live" / "market").exists()
    res = enter_quotes(d, rows, "Ana", "Sam", now=NOW)
    assert len(res["rows"]) == 3
    (d / "cds_quotes.csv").write_text("country,date,tenor_y,spread_bp,recovery,source\nAtlantis,2026-10-20,5,1,,x\n")
    with pytest.raises(MarketDataError, match="Atlantis"):
        cds_quotes_migration(d)


def test_live_data_dir_migration_count():
    rows, n = cds_quotes_migration(Path(__file__).parents[1] / "data")
    assert n == len(rows[rows["field"] == "spread_bp"])


@pytest.mark.parametrize("who", ['=HYPERLINK("http://x","a")', "@SUM(1)", "+1+cmd", " -2+3"])
def test_formula_author_or_approver_refused_nothing_written(tmp_path, who):
    """SEC-A-003 L1 (probe P1): refused, not escaped, before manual_quotes.csv or the ledger is touched."""
    with pytest.raises(MarketDataError, match="author refused"):
        enter_quotes(tmp_path, ROWS, who, self_approved=True, now=NOW)
    with pytest.raises(MarketDataError, match="approver refused"):
        enter_quotes(tmp_path, ROWS, "Ana", who, now=NOW)
    assert not manual_path(tmp_path).exists() and ledger.read_ledger(tmp_path).empty
    assert list_market_snapshots(tmp_path).empty
