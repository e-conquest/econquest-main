"""Evidence clock (EQ-C-0068, HO-20261024-B-C-001): `econquest evidence-clock [--as-of D] [--write]` over Team B's
calendar-gated evidence monitor, and the GUI card (GET /api/evidence-clock, read-only, Host guard, every string escaped,
status in words plus colour, progress bar). Named evidence-clock because `econquest evidence` is the EQ-C-0060 bundle.
The acceptance runs on the repo's data and outputs (read only); everything written goes to tmp dirs."""
import http.client
import json
import re
import shutil
import subprocess
import sys
import threading
from http.server import ThreadingHTTPServer
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from econquest import cli  # noqa: E402
from econquest.presentation import api  # noqa: E402
from econquest.presentation import evidence_view as EV  # noqa: E402
from econquest.presentation.gui import make_gui_handler  # noqa: E402
from econquest.validation import evidence_monitor as EM  # noqa: E402
from test_gui_security import StubApp, StubJobs, good  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
DATA, OUT = ROOT / "data", ROOT / "outputs"
PAGE = (Path(api.__file__).parent / "static" / "gui.html").read_text()
EVIL = '<img src=x onerror=alert(1)>"\'&'


def rows_of(text: str) -> dict:
    """{evidence: [cells]} from the printed markdown table."""
    out = {}
    for line in text.splitlines():
        cells = [c.strip() for c in line.strip().strip("|").split("|")]
        if line.startswith("| ") and cells[0] in ("var_record_250d", "benchmark_12m", "idea_quarters_4q"):
            out[cells[0]] = cells
    return out


# ---------------------------------------------------------------- CLI
def test_name_does_not_clash_with_the_evidence_bundle():
    ap_help = subprocess.run([sys.executable, "-m", "econquest", "--help"], capture_output=True, text=True, cwd=ROOT).stdout
    assert "evidence-clock" in ap_help and re.search(r"\bevidence\b", ap_help)


@pytest.mark.skipif(not (DATA / "forecast_record.csv").exists(), reason="no forecast record in this checkout")
def test_acceptance_on_current_data(capsys, tmp_path):
    """HO-20261024-B-C-001 acceptance: 3 rows as of 2026-10-24 with the listed values."""
    cli.main(["--data", str(DATA), "--out", str(OUT), "evidence-clock", "--as-of", "2026-10-24"])
    text = capsys.readouterr().out
    assert "## Calendar-gated evidence, as of 2026-10-24" in text
    r = rows_of(text)
    assert set(r) == {"var_record_250d", "benchmark_12m", "idea_quarters_4q"}
    assert r["var_record_250d"][1].startswith("60 / 250 tested days")
    assert r["var_record_250d"][4] == "2027-07-14" and r["var_record_250d"][6] == "accumulating"
    assert r["benchmark_12m"][4] == "2027-10-23" and r["benchmark_12m"][6] == "accumulating"
    # outputs/ is not shipped in the release zip: with no idea log the clock starts on as-of
    idea_start = "2027-10-23" if (OUT / "idea_log.csv").exists() else "2027-10-24"
    assert r["idea_quarters_4q"][4] == idea_start and r["idea_quarters_4q"][6] == "accumulating"
    assert not (tmp_path / "evidence_monitor.csv").exists()


@pytest.mark.skipif(not (DATA / "forecast_record.csv").exists(), reason="no forecast record in this checkout")
def test_before_any_evidence_progress_is_zero(capsys):
    cli.main(["--data", str(DATA), "--out", str(OUT), "evidence-clock", "--as-of", "2026-09-01"])
    r = rows_of(capsys.readouterr().out)
    assert len(r) == 3 and all(c[1].startswith("0 / ") and c[1].endswith("(0.0%)") for c in r.values())


def test_write_saves_csv_and_md(tmp_path, capsys):
    data, out = tmp_path / "data", tmp_path / "outputs"
    data.mkdir()
    if (DATA / "forecast_record.csv").exists():
        shutil.copy(DATA / "forecast_record.csv", data / "forecast_record.csv")
    cli.main(["--data", str(data), "--out", str(out), "evidence-clock", "--as-of", "2026-10-24", "--write"])
    printed = capsys.readouterr().out
    csv, md = out / "evidence_monitor.csv", out / "evidence_monitor.md"
    assert csv.exists() and md.exists() and "Evidence clock written" in printed
    assert csv.read_text().splitlines()[0].split(",") == EM.COLUMNS
    assert md.read_text() in printed and len(csv.read_text().splitlines()) == 4
    assert sorted(p.name for p in data.rglob("*")) == (["forecast_record.csv"] if (DATA / "forecast_record.csv").exists() else [])


def test_as_of_defaults_like_the_other_commands(tmp_path, monkeypatch):
    (tmp_path / "assumptions.json").write_text("{not json")
    assert EV.default_as_of(tmp_path, "2026-10-24") == "2026-10-24"
    import pandas as pd
    assert EV.default_as_of(tmp_path) == pd.Timestamp.today().strftime("%Y-%m-%d")       # no settings as_of: today
    from econquest.config import Settings

    class S:
        def get(self, k, d=None):
            return "2026-03-31" if k == "as_of" else d
    monkeypatch.setattr(Settings, "load", classmethod(lambda cls, *a, **k: S()))
    assert EV.default_as_of(tmp_path) == "2026-03-31"                                     # settings as_of wins
    with pytest.raises(SystemExit):
        cli.main(["--data", str(tmp_path), "--out", str(tmp_path), "evidence-clock", "--as-of", "not-a-date"])


def test_existing_evidence_bundle_parsing_unchanged():
    import argparse
    from econquest.ops import evidence
    p = argparse.ArgumentParser(); evidence.add_arguments(p)
    a = p.parse_args(["--as-of", "2026-10-24"])
    assert a.action == "build" and a.evidence_as_of == "2026-10-24"
    assert p.parse_args(["verify", "x.zip"]).archive == "x.zip"


# ---------------------------------------------------------------- GUI: /api/evidence-clock
@pytest.fixture
def serve(tmp_path):
    srvs = []

    def start(data=None, out=None):
        d = data or (tmp_path / "data"); o = out or (tmp_path / "outputs")
        d.mkdir(parents=True, exist_ok=True); o.mkdir(parents=True, exist_ok=True)
        srv = ThreadingHTTPServer(("127.0.0.1", 0), make_gui_handler(StubApp(), StubJobs(), o, d))
        threading.Thread(target=srv.serve_forever, daemon=True).start(); srvs.append(srv)
        return srv.server_address[1]
    yield start
    for s in srvs:
        s.shutdown()


def get(port, path, headers=None):
    conn = http.client.HTTPConnection("127.0.0.1", port, timeout=20)
    conn.request("GET", path, headers={"Host": f"127.0.0.1:{port}", **(headers or {})})
    r = conn.getresponse()
    return r.status, r.read().decode()


def test_route_returns_the_monitor_rows(serve):
    port = serve(DATA, OUT)
    st, body = get(port, "/api/evidence-clock?as_of=2026-10-24")
    d = json.loads(body)
    assert st == 200 and d["status"] == "ok" and d["as_of"] == "2026-10-24" and d["statuses"] == list(EM.STATUSES)
    assert [r["evidence"] for r in d["rows"]] == ["var_record_250d", "benchmark_12m", "idea_quarters_4q"]
    assert all(set(r) == set(EM.COLUMNS) for r in d["rows"])
    assert all("/" not in f.replace("panel/", "") for f in d["files"]) and str(ROOT) not in body    # names, no paths


def test_route_empty_data_and_bad_as_of(serve):
    port = serve()
    d = json.loads(get(port, "/api/evidence-clock?as_of=2026-09-01")[1])
    assert d["status"] == "ok" and len(d["rows"]) == 3 and all(r["progress"] == 0 for r in d["rows"])
    assert get(port, "/api/evidence-clock?as_of=2026-13-45")[0] == 400
    assert get(port, "/api/evidence-clock?as_of=%3Cscript%3E")[0] == 400


def test_route_is_get_only_behind_the_host_guard(serve):
    port = serve()
    for method in ("POST", "PUT", "DELETE"):
        conn = http.client.HTTPConnection("127.0.0.1", port, timeout=5)
        conn.request(method, "/api/evidence-clock", body="{}", headers={"Host": f"127.0.0.1:{port}", **good(port)})
        assert conn.getresponse().status in (404, 405, 501), method
    assert get(port, "/api/evidence-clock", headers={"Host": "evil.example:80"})[0] == 403     # DNS rebinding guard


def test_unreadable_inputs_give_the_error_type_only(serve, tmp_path):
    data = tmp_path / "bad" / "data"; data.mkdir(parents=True)
    (data / "forecast_record.csv").write_bytes(b"\x00\xff garbage,\n\"unterminated")
    d = json.loads(get(serve(data, tmp_path / "bad" / "outputs"), "/api/evidence-clock?as_of=2026-10-24")[1])
    if d["status"] == "invalid":
        assert str(tmp_path) not in d["message"] and d["rows"] == []


# ---------------------------------------------------------------- GUI: the card
def card_js() -> str:
    """fmt, esc, EV_TEXT and evidenceClockHTML from the page, runnable in node."""
    i = PAGE.index("const fmt = {"); fmt = PAGE[i:PAGE.index("};\n", i) + 3]
    esc = re.search(r"^const esc = .*$", PAGE, re.M).group(0)
    j = PAGE.index("const EV_TEXT"); block = PAGE[j:PAGE.index("async function evidenceClock()")]
    return f"{fmt}\n{esc}\n{block}"


def three_status_payload() -> dict:
    base = {c: None for c in EM.COLUMNS}
    rows = [base | {"evidence": "var_record_250d", "source": "data/forecast_record.csv", "unit": "tested days", "progress": 60,
                    "required": 250, "progress_pct": 24.0, "earliest_test_date": "2027-07-14", "days_to_test": 263,
                    "status": "accumulating", "note": EVIL},
            base | {"evidence": "benchmark_12m", "source": "data/benchmarks.csv", "unit": "days", "progress": 400,
                    "required": 365, "progress_pct": 100.0, "earliest_test_date": "2026-01-01", "days_to_test": -10,
                    "status": "testable", "note": "matured"},
            base | {"evidence": EVIL, "source": "outputs/idea_log.csv", "unit": "days", "progress": 100,
                    "required": 365, "progress_pct": 27.4, "earliest_test_date": "2026-10-01", "days_to_test": -23,
                    "status": "overdue", "note": "marks stopped"}]
    return {"status": "ok", "as_of": "2026-10-24", "message": f"3 tests {EVIL}", "rows": rows}


@pytest.mark.skipif(shutil.which("node") is None, reason="node not installed")
def test_card_renders_all_three_statuses_escaped():
    js = card_js() + "\nconst h = evidenceClockHTML(JSON.parse(process.argv[1]));\nconsole.log(JSON.stringify(h));"
    res = subprocess.run(["node", "-e", js, json.dumps(three_status_payload())], capture_output=True, text=True, timeout=30)
    assert res.returncode == 0, res.stderr
    h = json.loads(res.stdout)
    html = h["status"] + h["table"]
    for cls, word in (("accumulating", "Accumulating"), ("testable", "Testable"), ("overdue", "Overdue")):
        assert re.search(rf'<span class="ev-status {cls}">[^<]*{word}</span>', html), cls       # words, not colour only
        assert f'class="ev-bar {cls}" role="progressbar"' in html                                # coloured bar per status
    assert 'aria-valuenow="24.0"' in html and 'style="width:24.0%"' in html and 'style="width:100.0%"' in html
    assert "<img" not in html and "&lt;img src=x onerror=alert(1)&gt;&quot;&#39;&amp;" in html
    assert "AS OF 2026-10-24" in h["status"]
    empty = json.loads(subprocess.run(["node", "-e", card_js() + "\nconsole.log(JSON.stringify(evidenceClockHTML(null)));"],
                                      capture_output=True, text=True, timeout=30).stdout)
    assert "unavailable" in empty["status"]


def test_card_is_on_the_stress_tab_and_every_insert_is_escaped():
    sec = PAGE[PAGE.index('<section id="stress">'):PAGE.index('<section id="vol">')]
    assert "Evidence clock: calendar-gated validation tests" in sec and 'id="t-evidence-clock"' in sec
    css = PAGE[:PAGE.index("</style>")]
    assert ".ev-status.accumulating" in css and ".ev-status.testable" in css and ".ev-status.overdue" in css
    assert "#1e6b3f" in css.split(".ev-status.testable")[1][:60] and "#922b21" in css.split(".ev-status.overdue")[1][:60]
    j = PAGE.index("// ---------- evidence clock (EQ-C-0068)"); block = PAGE[j:PAGE.index("// ---------- GARCH ----------")]
    for expr in re.findall(r"\$\{([^{}]*(?:\{[^{}]*\}[^{}]*)*)\}", block):
        e = expr.strip()
        assert e.startswith(("esc(", "col", "st}", "body", "head.map")) or e in ("st", "status", "body", "col"), e
    assert "evidenceClock();" in PAGE[PAGE.index("async function stress()"):][:80]


# ---------------------------------------------------------------- SEC-C-009 (EQ-C-0068 review): strict as_of
@pytest.mark.parametrize("q", ["0001-01-01", "0999-12-31", "%EF%BC%91%EF%BC%92%EF%BC%93%EF%BC%94-10-24", "2026/10/24",
                               "9999-12-31", "2026-02-30", "2026-10-24T0", "+2026-10-2", "2026-1-024"])
def test_route_refuses_any_as_of_that_is_not_a_plain_date(serve, q):
    """0001-01-01 was answered as 2001-01-01 (strftime '1-01-01'), full-width digits and 2026/10/24 were parsed, and
    9999-12-31 gave a 200 'invalid' card."""
    st, body = get(serve(), "/api/evidence-clock?as_of=" + q)
    assert st == 400 and json.loads(body) == {"error": "as_of must be YYYY-MM-DD"}


def test_route_answers_for_exactly_the_date_asked(serve):
    port = serve()
    for q in ("2026-10-24", "1990-01-01", "2200-12-31"):
        st, body = get(port, "/api/evidence-clock?as_of=" + q)
        assert st == 200 and json.loads(body)["as_of"] == q


@pytest.mark.parametrize("q", ["0001-01-01", "999-01-01"])
def test_cli_as_of_refuses_years_before_1000(q):
    import argparse
    with pytest.raises(argparse.ArgumentTypeError):
        cli._as_of_arg(q)
    assert cli._as_of_arg("2026-10-24") == "2026-10-24" and cli._as_of_arg("2026/10/24") == "2026-10-24"
