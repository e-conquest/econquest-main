"""Compliance checklist in the editorial flow (EQ-C-0036): disclaimer, sources, conflicts, caveat flags with reviewer
acknowledgement, compliance sign-off (four-eyes or flagged self-sign); publish refused until complete; manifest carries
the checklist; items published before the checklist still verify."""
import json
import os
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.ops import approvals as ap  # noqa: E402
from econquest.presentation import compliance as C  # noqa: E402
from econquest.presentation import editorial as E  # noqa: E402
from econquest.presentation.report import DISCLAIMER, caveats_html, caveats_md, input_caveats  # noqa: E402

META = {"run_id": "run-20261022-abc", "as_of": "2026-10-22", "data_hash": "d" * 12, "run_hash": "r" * 16}
SOURCES_HTML = "<h2>Sources</h2><ul><li>IMF WEO</li><li>World Bank WDI</li></ul><p>As of 2026-10-22. Vintage 2026-10-21.</p>"
SOURCES_MD = "## Sources\n\n- IMF WEO\n- BIS\n\nAs of 2026-10-22.\n"
STAMP = '<!-- econquest:sources {"as_of": "2026-10-22", "vintage": "2026-10-21", "sources": ["IMF WEO", "Yahoo Finance"]} -->'


@pytest.fixture
def out(tmp_path):
    o = tmp_path / "outputs"
    (o / "reports").mkdir(parents=True)
    (tmp_path / "data").mkdir()
    yield o
    for root, _dirs, files in os.walk(o):
        os.chmod(root, 0o755)
        for f in files:
            os.chmod(os.path.join(root, f), 0o644)


def flag_placeholders(out):
    """Data with placeholder prediction-market prices (GOV-016, 6.2) and a synthetic backtest (GOV-028, 6.3)."""
    d = out.parent / "data"
    (d / "prediction_markets.csv").write_text("country,contract,price\nARG,default,0.3\n")
    (d / "backtest_history.csv").write_text("date,pnl,source\n2020-01-31,1.0,synthetic\n")


def write(out, name="note", html=True, sources=True, caveats=True, disclaimer=True, stamp=False, cav=None):
    cav = input_caveats(out.parent / "data") if cav is None else cav
    p = out / "reports" / (f"{name}.html" if html else f"{name}.md")
    if html:
        body = "<html><h1>Note</h1><p>PD table</p>"
        body += f"<h2>Input caveats</h2>{caveats_html(cav)}" if caveats else ""
        body += SOURCES_HTML if sources else ""
        body += STAMP if stamp else ""
        body += f"<div class='disclaimer'>{DISCLAIMER}</div>" if disclaimer else ""
        p.write_text(body + "</html>", encoding="utf-8")
    else:
        body = "# Note\n\nPD table\n\n"
        body += ("## Input caveats\n\n" + "\n".join(caveats_md(cav)) + "\n\n") if caveats else ""
        body += SOURCES_MD if sources else ""
        body += (STAMP + "\n") if stamp else ""
        body += f"\n> **Disclaimer.** {DISCLAIMER}\n" if disclaimer else ""
        p.write_text(body, encoding="utf-8")
    return p


def reviewed(out, files=None, author="Alice", reviewer="Bob", kind="country_note"):
    it = E.register_draft(out, kind, files or [write(out), write(out, html=False)], META, author)
    return E.review(out, it["item_id"], reviewer, "ok", self_reviewed=(author == reviewer))["item_id"]


# ---------------------------------------------------------------- 1. disclaimer
def test_disclaimer_item(out):
    iid = reviewed(out, [write(out, disclaimer=False)])
    st = E.checklist_status(out, iid)
    assert not st["items"]["disclaimer"]["ok"] and "DISCLAIMER missing" in st["items"]["disclaimer"]["problems"][0]
    E.checklist(out, iid, "Alice", conflicts="no conflicts")
    with pytest.raises(E.EditorialError, match="sign-off refused.*disclaimer"):
        E.checklist(out, iid, "Dave", compliance_approve=True)
    with pytest.raises(E.EditorialError, match="disclaimer"):
        E.publish(out, iid, "Carol")


# ---------------------------------------------------------------- 2. sources
@pytest.mark.parametrize("html", [True, False])
def test_sources_section_or_stamp(out, html):
    def probs(name, as_of="2026-10-22", **kw):
        p = write(out, name, html=html, **kw)
        return C.sources_problems(p.read_text(), p.name, as_of)
    assert probs("a") == []
    assert probs("b", sources=False, stamp=True) == []
    no = probs("c", sources=False)
    assert no and "no Sources section" in no[0]
    wrong = probs("d", "2026-10-23", sources=False, stamp=True)
    assert wrong and "run is as of 2026-10-23" in wrong[0]


def test_sources_section_content_rules():
    assert "states no as-of date" in C.sources_problems("## Sources\n\n- IMF WEO\n", "x.md", "2026-10-22")[0]
    assert "names no data source" in C.sources_problems("## Sources\n\nAs of 2026-10-22.\n", "x.md", "2026-10-22")[0]
    assert "run is as of" in C.sources_problems("<h2>Sources</h2><ul><li>BIS</li></ul><p>As of 2026-10-01</p>", "x.html", "2026-10-22")[0]
    assert C.sources_problems("<h2>Sources</h2><ul><li>BIS</li></ul><p>Vintage 2026-10-01</p><h2>Next</h2>", "x.html", "2026-10-22") == []
    assert "lists no sources" in C.sources_problems('<!-- econquest:sources {"as_of": "2026-10-22", "sources": []} -->', "x.html", None)[0]
    assert "not valid JSON" in C.sources_problems("<!-- econquest:sources {bad} -->", "x.html", None)[0]


def test_publish_refused_without_sources(out):
    iid = reviewed(out, [write(out, sources=False)])
    E.checklist(out, iid, "Alice", conflicts="no conflicts")
    with pytest.raises(E.EditorialError, match="sign-off refused.*sources: note.html: no Sources section"):
        E.checklist(out, iid, "Dave", compliance_approve=True)
    with pytest.raises(E.EditorialError, match="compliance checklist incomplete.*sources"):
        E.publish(out, iid, "Carol")


# ---------------------------------------------------------------- 3. conflicts
def test_conflicts_declared_by_author(out):
    iid = reviewed(out)
    with pytest.raises(E.EditorialError, match="compliance checklist incomplete.*conflicts of interest not declared"):
        E.publish(out, iid, "Carol")
    with pytest.raises(E.EditorialError, match="declared by the author"):
        E.checklist(out, iid, "Bob", conflicts="no conflicts")
    with pytest.raises(E.EditorialError, match="no conflicts"):
        E.checklist(out, iid, "Alice", conflicts="   ")
    with pytest.raises(E.EditorialError, match="nothing to record"):
        E.checklist(out, iid, "Alice")
    it = E.checklist(out, iid, " alice ", conflicts="Holds ARG Eurobonds personally.")
    assert it["checklist"]["conflicts"]["has_conflicts"] is True
    it = E.checklist(out, iid, "Alice", conflicts="No conflicts.")
    assert it["checklist"]["conflicts"]["has_conflicts"] is False and it["checklist"]["conflicts"]["text"] == "No conflicts."
    E.checklist(out, iid, "Dave", compliance_approve=True)
    man = json.loads((out / E.publish(out, iid, "Carol")["published_dir"] / "manifest.json").read_text())
    assert man["compliance"]["items"]["conflicts"]["text"] == "No conflicts." and man["compliance"]["items"]["conflicts"]["by"] == "Alice"


# ---------------------------------------------------------------- 4. placeholder / limitation flags
def test_flags_need_block_and_reviewer_ack(out):
    flag_placeholders(out)
    f = C.flagged_restrictions(out.parent / "data")
    assert set(f["ack"]) == {"6.2", "6.3"} and f["ack"]["6.2"]["refs"] == "GOV-016" and "6.4" in f["shown"]
    iid = reviewed(out)
    E.checklist(out, iid, "Alice", conflicts="no conflicts")
    with pytest.raises(E.EditorialError, match="acknowledged by the reviewer"):
        E.checklist(out, iid, "Dave", acknowledge=["6.2"])
    with pytest.raises(E.EditorialError, match="not flagged"):
        E.checklist(out, iid, "Bob", acknowledge=["6.9"])
    with pytest.raises(E.EditorialError, match="not a restriction code"):
        E.checklist(out, iid, "Bob", acknowledge=["GOV-016"])
    E.checklist(out, iid, "Bob", acknowledge=["restriction 6.2"])
    with pytest.raises(E.EditorialError, match=r"not acknowledged restriction 6\.3 \(GOV-028\)"):
        E.checklist(out, iid, "Dave", compliance_approve=True)
    it = E.checklist(out, iid, "Bob", acknowledge="6.3")
    assert set(it["checklist"]["acknowledged"]) == {"6.2", "6.3"}
    E.checklist(out, iid, "Dave", compliance_approve="checked caveats")
    man = json.loads((out / E.publish(out, iid, "Carol")["published_dir"] / "manifest.json").read_text())
    cav = man["compliance"]["items"]["caveats"]
    assert cav["ok"] and cav["acknowledge_required"] == ["6.2", "6.3"] and cav["acknowledged"]["6.3"]["by"] == "Bob"
    assert man["compliance"]["complete"] and E.verify_published(out)["ok"]


def test_flags_ack_before_review_refused(out):
    flag_placeholders(out)
    it = E.register_draft(out, "scenario_brief", [write(out)], META, "Alice")
    with pytest.raises(E.EditorialError, match="after review"):
        E.checklist(out, it["item_id"], "Bob", acknowledge=["6.2"])


def test_caveats_block_missing_or_stale(out):
    iid = reviewed(out, [write(out, "a", caveats=False)])
    st = E.checklist_status(out, iid)
    assert "no Input caveats block" in st["items"]["caveats"]["problems"][0]
    stale = write(out, "b")                      # built before the placeholder data appeared: no 6.2 / 6.3 markers
    flag_placeholders(out)
    iid2 = reviewed(out, [stale])
    probs = E.checklist_status(out, iid2)["items"]["caveats"]["problems"]
    assert any("does not show restriction 6.1" in p or "does not show restriction 6.2" in p for p in probs)


def test_missing_data_dir_fails_loudly(out, tmp_path):
    iid = reviewed(out)
    E.checklist(out, iid, "Alice", conflicts="no conflicts")
    E.checklist(out, iid, "Dave", compliance_approve=True)
    with pytest.raises(E.EditorialError, match="data folder .* not found"):
        E.publish(out, iid, "Carol", data_dir=tmp_path / "nope")


# ---------------------------------------------------------------- 5. compliance sign-off
@pytest.mark.parametrize("who", ["Alice", "ALICE ", "Ali​ce"])
def test_signoff_four_eyes(out, who):
    iid = reviewed(out)
    E.checklist(out, iid, "Alice", conflicts="no conflicts")
    with pytest.raises(E.EditorialError, match="other than the author"):
        E.checklist(out, iid, who, compliance_approve=True)
    with pytest.raises(E.EditorialError, match="no compliance sign-off"):
        E.publish(out, iid, "Carol")


def test_self_sign_flagged_exception(out):
    iid = reviewed(out, author="Sam", reviewer="Sam")
    it = E.checklist(out, iid, "Sam", conflicts="no conflicts", compliance_approve=True, self_signed=True, exc_id="EXC-001")
    so = it["checklist"]["signoff"]
    assert so["approver"] == "Sam" and so["self_signed"] == "yes" and "single-operator self-sign under EXC-001" in so["exception"]
    assert so["exc_id"] == "EXC-001"
    assert so["config_source"] == "default" and it["checklist_status"]["complete"]
    man = json.loads((out / E.publish(out, iid, "Sam")["published_dir"] / "manifest.json").read_text())
    ms = man["compliance"]["items"]["compliance_signoff"]
    assert ms["self_signed"] == "yes" and ms["exception"] and man["self_reviewed"] == "yes" and ms["exc_id"] == "EXC-001"


@pytest.mark.parametrize("exc", [None, "", "EXC-1", "exc-001", "EXC-001x", "GOV-001"])
def test_self_sign_needs_an_exc_id(out, exc):
    # EQ-C-0041 (SEC-C-004 R2): the same rule and validator (approvals.check_exc) as `change approve --self-approved`
    iid = reviewed(out, author="Sam", reviewer="Sam")
    E.checklist(out, iid, "Sam", conflicts="no conflicts")
    with pytest.raises(E.EditorialError, match="needs an exception id EXC-nnn"):
        E.checklist(out, iid, "Sam", compliance_approve=True, self_signed=True, exc_id=exc)
    assert not E.get_item(out, iid)["checklist"].get("signoff")


def test_exc_id_shape_checked_for_a_distinct_approver_and_issues_log_noted(out):
    iid = reviewed(out)
    E.checklist(out, iid, "Alice", conflicts="no conflicts")
    with pytest.raises(E.EditorialError, match="must look like EXC-nnn"):
        E.checklist(out, iid, "Dave", compliance_approve=True, exc_id="EXC-x")
    gov = out.parent / "docs" / "governance"; gov.mkdir(parents=True)
    (gov / "issues-log.md").write_text("| id | date |\n|---|---|\n| EXC-001 | 2026-10-23 |\n")
    iid2 = reviewed(out, author="Sam", reviewer="Sam")
    E.checklist(out, iid2, "Sam", conflicts="no conflicts")
    so = E.checklist(out, iid2, "Sam", compliance_approve=True, self_signed=True, exc_id="EXC-777")["checklist"]["signoff"]
    assert so["exc_id"] == "EXC-777" and "[EXC-777 not yet in issues-log.md]" in so["exception"]


def test_distinct_approver_with_flag_is_ordinary(out):
    iid = reviewed(out)
    it = E.checklist(out, iid, "Alice", conflicts="no conflicts")
    it = E.checklist(out, iid, "Dave", compliance_approve=True, self_signed=True)
    assert it["checklist"]["signoff"]["self_signed"] == "" and it["checklist"]["signoff"]["exception"] == ""


def test_configurable_approver_role(out):
    cfgp = C.config_path(out.parent / "data")
    cfgp.write_text(json.dumps({"role": "compliance officer", "approvers": ["Jane Roe"], "allow_self_sign": False}))
    ap.baseline(out.parent / "data", "compliance.json", "Sam", "first use")         # governed by econquest change
    iid = reviewed(out)
    E.checklist(out, iid, "Alice", conflicts="no conflicts")
    with pytest.raises(E.EditorialError, match="not a configured compliance officer"):
        E.checklist(out, iid, "Dave", compliance_approve=True)
    with pytest.raises(E.EditorialError, match="self-sign is disabled"):
        E.checklist(out, iid, "Alice", compliance_approve=True, self_signed=True)
    so = E.checklist(out, iid, "jane roe", compliance_approve=True)["checklist"]["signoff"]
    assert so["role"] == "compliance officer" and so["config_sha256"] == C.load_config(out.parent / "data")["sha256"]
    assert so["config_status"] == "ok" and so["config_source"].endswith("data/compliance.json")
    with pytest.raises(C.ComplianceError, match="list of names"):
        C.validate_config({"approvers": "Jane"})


def test_signoff_needs_review_and_later_row_voids_it(out):
    it = E.register_draft(out, "daily_report", [write(out)], META, "Alice")
    E.checklist(out, it["item_id"], "Alice", conflicts="no conflicts")          # allowed on a draft
    with pytest.raises(E.EditorialError, match="after review"):
        E.checklist(out, it["item_id"], "Dave", compliance_approve=True)
    E.review(out, it["item_id"], "Bob")
    E.checklist(out, it["item_id"], "Dave", compliance_approve=True)
    E.checklist(out, it["item_id"], "Alice", conflicts="Advises the ARG debt office.")
    with pytest.raises(E.EditorialError, match="voided by checklist row"):
        E.publish(out, it["item_id"], "Carol")
    E.checklist(out, it["item_id"], "Dave", compliance_approve=True)
    pub = E.publish(out, it["item_id"], "Carol")
    with pytest.raises(E.EditorialError, match="before publish only"):
        E.checklist(out, it["item_id"], "Alice", conflicts="no conflicts")
    assert E.verify_published(out) == {"ok": True, "checked": 1, "problems": []} and pub["compliance_version"] == 1


def test_publish_refused_when_approver_config_changed_after_signoff(out):
    iid = reviewed(out)
    E.checklist(out, iid, "Alice", conflicts="no conflicts")
    E.checklist(out, iid, "Dave", compliance_approve=True)                     # signed under the default config
    d = out.parent / "data"
    C.config_path(d).write_text(json.dumps(C.DEFAULT_CONFIG))
    ap.baseline(d, "compliance.json", "Sam", "first use")
    p = ap.propose(d, "compliance.json", {"/approvers": ["Dave"], "/allow_self_sign": False}, "Sam", "name Dave",
                   allow_type_change=True)
    ap.approve(d, p["id"], approver="Alice"); ap.apply(d, p["id"], actor="Sam")
    with pytest.raises(E.EditorialError, match="changed since the sign-off"):
        E.publish(out, iid, "Carol")
    E.checklist(out, iid, "Dave", compliance_approve=True)                     # re-signed under the current config
    assert E.publish(out, iid, "Carol")["state"] == "published"


def test_review_records_automatic_checks(out):
    iid = reviewed(out, [write(out, sources=False)])
    row = [r for r in E.read_ledger(out) if r["event"] == "review"][0]
    assert row["compliance_checks"]["disclaimer"]["ok"] and not row["compliance_checks"]["sources"]["ok"]
    assert E.get_item(out, iid)["review_checks"]["caveats"]["ok"]


# ---------------------------------------------------------------- verify / backward compatibility
def _rechain(out, rows):
    prev = E.GENESIS
    for i, r in enumerate(rows, 1):
        r["seq"], r["prev_hash"] = i, prev
        r["row_hash"] = E._row_hash(r); prev = r["row_hash"]
    E.ledger_path(out).write_text("".join(E._canon(r) + "\n" for r in rows))


def _publish_full(out):
    iid = reviewed(out)
    E.checklist(out, iid, "Alice", conflicts="no conflicts")
    E.checklist(out, iid, "Dave", compliance_approve=True)
    return E.publish(out, iid, "Carol")


def _rewrite_manifest(out, pub, fn):
    d = out / pub["published_dir"]; mp = d / "manifest.json"
    os.chmod(d, 0o755); os.chmod(mp, 0o644)
    man = json.loads(mp.read_text()); fn(man)
    mp.write_text(json.dumps(man, indent=2, sort_keys=True) + "\n"); os.chmod(mp, 0o444); os.chmod(d, 0o555)
    return E.sha256_file(mp)


def test_pre_checklist_publish_still_verifies(out):
    pub = _publish_full(out)
    sha = _rewrite_manifest(out, pub, lambda m: m.pop("compliance"))       # a PI-2 item: no checklist anywhere
    rows = [r for r in E.read_ledger(out) if r["event"] != "checklist"]
    for r in rows:
        r.pop("compliance_checks", None)
        if r["event"] == "publish":
            r.pop("compliance_version"); r.pop("compliance_signoff_row_hash"); r["manifest_sha256"] = sha
    _rechain(out, rows)
    assert E.verify_published(out) == {"ok": True, "checked": 1, "problems": []}


def test_checklist_stripped_from_new_manifest_detected(out):
    pub = _publish_full(out)
    sha = _rewrite_manifest(out, pub, lambda m: m.pop("compliance"))
    rows = E.read_ledger(out)
    rows[-1]["manifest_sha256"] = sha
    _rechain(out, rows)
    assert any("compliance checklist missing" in p for p in E.verify_published(out)["problems"])
