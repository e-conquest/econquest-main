"""Operator action log (EQ-C-0035): rows for every logged command type, secrets never written, the hash chain catches
edits, deletions and truncation, failures are logged with their exit code, `econquest log verify|tail`."""
import json

import pytest

from econquest import cli
from econquest.ops import actionlog as AL
from econquest.ops import schedule

SECRET = "ya29.action-log-secret-token"


@pytest.fixture
def env(tmp_path, monkeypatch):
    for v in (AL.LOG_ENV, cli.TOKEN_ENV):
        monkeypatch.delenv(v, raising=False)
    monkeypatch.setenv(cli.RUN_GATE_ENV, "off")          # the gate has its own tests (test_run_gate.py)
    d = tmp_path / "data"; d.mkdir()
    return d, tmp_path / "outputs"


def call(env, *argv):
    d, out = env
    return cli.main(["--data", str(d), "--out", str(out), *argv])


def ok(*a, **k):
    return None


# ---------------------------------------------------------------- module

def test_append_chain_and_verify(tmp_path):
    for i in range(3):
        AL.append(tmp_path, f"cmd{i}", {"i": i}, actor="Sam")
    rows = AL.read(tmp_path)
    assert [r["seq"] for r in rows] == [1, 2, 3]
    assert rows[0]["prev_hash"] == "0" * 64 and rows[1]["prev_hash"] == rows[0]["row_hash"]
    assert AL.verify(tmp_path)["ok"]
    assert json.loads((tmp_path / "store" / "actions.head.json").read_text())["seq"] == 3


def _lines(tmp_path):
    p = AL.log_path(tmp_path)
    return p, p.read_text().splitlines()


def test_edited_row_is_detected(tmp_path):
    for i in range(3):
        AL.append(tmp_path, "change approve", {"id": i}, actor="Sam")
    p, lines = _lines(tmp_path)
    r = json.loads(lines[1]); r["actor"] = "Mallory"; lines[1] = json.dumps(r)
    p.write_text("\n".join(lines) + "\n")
    v = AL.verify(tmp_path)
    assert not v["ok"] and any("row edited" in e for e in v["errors"])


def test_deleted_row_is_detected(tmp_path):
    for i in range(3):
        AL.append(tmp_path, "x", {"id": i})
    p, lines = _lines(tmp_path)
    p.write_text("\n".join([lines[0], lines[2]]) + "\n")
    v = AL.verify(tmp_path)
    assert not v["ok"] and any("deleted" in e for e in v["errors"])


def test_truncated_end_is_detected_by_head(tmp_path):
    for i in range(3):
        AL.append(tmp_path, "x", {"id": i})
    p, lines = _lines(tmp_path)
    p.write_text("\n".join(lines[:2]) + "\n")
    v = AL.verify(tmp_path)
    assert not v["ok"] and any("head.json" in e for e in v["errors"])


def test_append_after_break_still_records(tmp_path):
    AL.append(tmp_path, "x", {})
    p = AL.log_path(tmp_path); p.write_text(p.read_text() + "not json\n")
    AL.append(tmp_path, "y", {})
    assert [r["command"] for r in AL.read(tmp_path)] == ["x", "y"]
    assert not AL.verify(tmp_path)["ok"]


def test_redaction_masks_secret_keys_and_values():
    a = AL.redact_args({"token": SECRET, "token_file": "/tmp/t", "note": f"pasted {SECRET} here", "write": True,
                        "fn": print, "webhook": "https://hooks/x"}, [SECRET])
    assert a == {"token": "***", "token_file": "***", "note": "pasted *** here", "write": True, "webhook": "***"}
    assert SECRET not in json.dumps(a)


def test_env_path_override(tmp_path, monkeypatch):
    target = tmp_path / "elsewhere" / "acts.jsonl"
    monkeypatch.setenv(AL.LOG_ENV, str(target))
    AL.append(tmp_path / "out", "x", {})
    assert target.exists() and (target.parent / "actions.head.json").exists()


# ---------------------------------------------------------------- CLI wiring

CASES = [
    (["review", "decide", "--table", "Inputs", "--key", "1.1", "--country", "Ghana", "--decision", "hold", "--author", "Sam"],
     "cmd_review", "review decide", "Sam"),
    (["attest", "--file", "adjustments", "--author", "Sam", "--self-approved"], "cmd_attest", "attest", "Sam"),
    (["change", "propose", "limits.json", "--set", "/a=1", "--author", "Ana", "--reason", "r"], "cmd_change", "change propose", "Ana"),
    (["change", "approve", "CHG-1", "--approver", "Bob"], "cmd_change", "change approve", "Bob"),
    (["change", "reject", "CHG-1", "--by", "Bob"], "cmd_change", "change reject", "Bob"),
    (["change", "apply", "CHG-1", "--actor", "Sam"], "cmd_change", "change apply", "Sam"),
    (["change", "baseline", "limits.json", "--actor", "Sam", "--reason", "r", "--self-approved", "--exc", "EXC-001"],
     "cmd_change", "change baseline", "Sam"),
    (["editorial", "draft", "--kind", "country_note", "--file", "x.md", "--author", "Sam"], "cmd_editorial", "editorial draft", "Sam"),
    (["editorial", "review", "ED-1", "--reviewer", "Ana"], "cmd_editorial", "editorial review", "Ana"),
    (["editorial", "publish", "ED-1", "--publisher", "Ana"], "cmd_editorial", "editorial publish", "Ana"),
    (["editorial", "withdraw", "ED-1", "--by", "Ana", "--reason", "r"], "cmd_editorial", "editorial withdraw", "Ana"),
    (["editorial", "verify"], "cmd_editorial", "editorial verify", None),
    (["fetch", "--apply", "--author", "Sam"], "cmd_fetch", "fetch --apply", "Sam"),
    (["fetch", "--apply", "--force", "--author", "Sam", "--self-approved"], "cmd_fetch", "fetch --apply", "Sam"),
    (["fit-hazard", "--apply", "--author", "Sam"], "cmd_fit_hazard", "fit-hazard --apply", "Sam"),
    (["publish", "--write"], "cmd_publish", "publish --write", None),
    (["garch", "--write"], "cmd_garch", "garch --write", None),
    (["record", "--write"], "cmd_record", "record --write", None),
]


@pytest.mark.parametrize("argv,fn,label,actor", CASES, ids=[c[2] + "/" + str(i) for i, c in enumerate(CASES)])
def test_each_operator_action_is_logged(env, monkeypatch, argv, fn, label, actor):
    monkeypatch.setenv(cli.TOKEN_ENV, SECRET)
    monkeypatch.setenv("USER", "osuser")
    monkeypatch.setattr(cli, fn, ok)
    call(env, *argv)
    (r,) = AL.read(env[1])
    assert r["command"] == label and r["outcome"] == "ok" and r["exit_code"] == 0
    assert r["actor"] == (actor or "osuser") and r["actor_source"] == ("flag" if actor else "os")
    assert r["versions"]["code_version"] and r["ts_utc"].endswith("Z")
    assert SECRET not in AL.log_path(env[1]).read_text()


@pytest.mark.parametrize("action", ["install", "uninstall"])
def test_schedule_install_uninstall_logged(env, monkeypatch, action):
    monkeypatch.setattr(schedule, "run_from_args", lambda a, home, log=print: {"ok": True})
    call(env, "schedule", action)
    (r,) = AL.read(env[1])
    assert r["command"] == f"schedule {action}" and r["outcome"] == "ok"


@pytest.mark.parametrize("argv,fn", [
    (["review", "list"], "cmd_review"), (["attest", "--list"], "cmd_attest"), (["change", "list"], "cmd_change"),
    (["change", "verify"], "cmd_change"), (["fetch"], "cmd_fetch"), (["publish"], "cmd_publish"),
    (["publish", "--write", "--dry-run"], "cmd_publish"), (["run"], "cmd_run"), (["fit-hazard"], "cmd_fit_hazard"),
])
def test_read_only_commands_not_logged(env, monkeypatch, argv, fn):
    monkeypatch.setattr(cli, fn, ok)
    call(env, *argv)
    assert AL.read(env[1]) == []


def test_token_never_written_from_any_source(env, monkeypatch, tmp_path):
    f = tmp_path / "tok"; f.write_text(SECRET + "\n")
    monkeypatch.setattr(cli, "cmd_publish", ok)
    call(env, "publish", "--token-file", str(f))
    call(env, "publish", "--token", SECRET)                                   # deprecated flag
    monkeypatch.setenv(cli.TOKEN_ENV, SECRET)
    monkeypatch.setattr(cli, "cmd_editorial", lambda a: (_ for _ in ()).throw(SystemExit(f"bad {SECRET}")))
    with pytest.raises(SystemExit):
        call(env, "editorial", "withdraw", "ED-1", "--by", "Sam", "--reason", f"leaked {SECRET}")
    text = AL.log_path(env[1]).read_text()
    assert len(AL.read(env[1])) == 3 and SECRET not in text and "***" in text


def test_failure_logged_with_message_and_code(env, monkeypatch):
    def fail(args):
        raise SystemExit("change approve: approver must differ from the author")
    monkeypatch.setattr(cli, "cmd_change", fail)
    with pytest.raises(SystemExit):
        call(env, "change", "approve", "CHG-1", "--approver", "Sam")
    (r,) = AL.read(env[1])
    assert r["outcome"] == "error" and r["exit_code"] == 1 and "approver must differ" in r["error"]


def test_numeric_exit_and_exception_logged(env, monkeypatch):
    monkeypatch.setattr(cli, "cmd_editorial", lambda a: (_ for _ in ()).throw(SystemExit(1)))
    with pytest.raises(SystemExit):
        call(env, "editorial", "verify")
    monkeypatch.setattr(cli, "cmd_fetch", lambda a: (_ for _ in ()).throw(RuntimeError("feed down")))
    with pytest.raises(RuntimeError):
        call(env, "fetch", "--apply", "--author", "Sam")
    monkeypatch.setattr(schedule, "run_from_args", lambda a, home, log=print: (_ for _ in ()).throw(SystemExit(4)))
    with pytest.raises(SystemExit):
        call(env, "schedule", "install")
    rows = AL.read(env[1])
    assert [(r["exit_code"], r["outcome"]) for r in rows] == [(1, "error"), (1, "error"), (4, "error")]
    assert rows[1]["error"] == "RuntimeError: feed down"
    assert AL.verify(env[1])["ok"]


def test_missing_token_on_write_is_logged(env, monkeypatch):
    monkeypatch.setattr(cli, "_keychain_token", lambda: None)
    monkeypatch.setattr(cli, "cmd_publish", lambda a: pytest.fail("ran without a token"))
    with pytest.raises(SystemExit):
        call(env, "publish", "--write")
    (r,) = AL.read(env[1])
    assert r["command"] == "publish --write" and r["exit_code"] == 1 and "needs a Sheets token" in r["error"]


def test_log_write_failure_does_not_change_outcome(env, monkeypatch, capsys):
    monkeypatch.setattr(AL, "append", lambda *a, **k: (_ for _ in ()).throw(OSError("disk full")))
    monkeypatch.setattr(cli, "cmd_change", ok)
    call(env, "change", "apply", "CHG-1")
    assert "could not write the action log" in capsys.readouterr().err


def test_log_verify_and_tail_cli(env, monkeypatch, capsys):
    monkeypatch.setattr(cli, "cmd_change", ok)
    call(env, "change", "approve", "CHG-1", "--approver", "Bob")
    call(env, "change", "apply", "CHG-1", "--actor", "Sam")
    capsys.readouterr()
    call(env, "log", "verify")
    assert "ok (2 rows)" in capsys.readouterr().out
    call(env, "log", "tail", "-n", "1")
    o = capsys.readouterr().out
    assert "change apply" in o and "change approve" not in o and "Sam" in o
    call(env, "log", "tail", "--json")
    assert [json.loads(x)["seq"] for x in capsys.readouterr().out.splitlines()] == [1, 2]
    p = AL.log_path(env[1]); lines = p.read_text().splitlines()
    r = json.loads(lines[0]); r["args"]["approver"] = "Eve"; lines[0] = json.dumps(r)
    p.write_text("\n".join(lines) + "\n")
    with pytest.raises(SystemExit) as e:
        call(env, "log", "verify")
    assert e.value.code == 1 and "BROKEN" in capsys.readouterr().out
    assert len(AL.read(env[1])) == 2                                          # log verify/tail are not themselves logged


def test_log_tail_empty(env, capsys):
    call(env, "log", "tail")
    assert "No operator actions logged" in capsys.readouterr().out
