"""EQ-B-0034: the engine and scorecard scale to N countries (no 18-country desk-universe assumption).

`synthetic_universe` builds a SYNTHETIC N-country Universe from the seed countries for scale tests only:
each extra country is a perturbed copy of a seed country with a unique name ("Synthetic 02 Brazil"), a
user-assigned ISO 3166 code (ISO3 XAA, XAB, ...; ISO2 X0..XZ then Q0..QZ, codes never given to a real
country) and, from the second replica on, a synthetic region label, so layers 5 and 6 see more than three
regions. Numeric indicators and spreads are scaled by a small deterministic factor so the clones are not
exact copies. None of it is real data: Team A's 70+ sovereign master list (EQ-A-0025) replaces it once
approved.
"""
import sys
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.config import Settings
from econquest.ingestion import load_universe
from econquest.engine import run_pipeline
from econquest.engine import layer1_hazard as L1
from econquest.scorecard import score_universe

DATA = ROOT / "data"
AS_OF = "2026-10-23"
N_TARGET = 70
PATHS = 2000
_AZ = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
_ALNUM = "0123456789" + _AZ
SYNTH_REGIONS = {2: "Synthetic region East", 3: "Synthetic region West"}


def _iso3(k: int) -> str:
    return "X" + _AZ[k // 26] + _AZ[k % 26]


def _iso2(k: int) -> str:
    return ("X", "Q")[k // 36] + _ALNUM[k % 36]


def synthetic_universe(u, n: int, positions: str = "seed"):
    """N-country synthetic Universe built from `u` (see the module docstring).

    positions="seed" keeps the book on the seed countries (only the country count grows);
    "replicate" also copies each seed country's positions and prediction-market contracts onto its clones,
    so the book grows with the universe."""
    import dataclasses
    seed = u.countries.reset_index(drop=True)
    S = len(seed)
    if n < S:
        raise ValueError(f"n={n} is below the {S} seed countries")
    if n - S > 72:
        raise ValueError("synthetic ISO2 codes run out above 72 clones")
    rb = u.rulebook.set_index("id")
    numeric = [i for i in rb.index if not str(rb.at[i, "type"]).lower().startswith("level")]
    ind = u.indicators.set_index("id")
    adj = u.adjustments.copy()
    rows, new_ind, new_adj, clones = [], {}, {}, {}
    for k in range(n - S):
        src = seed.iloc[k % S]
        rep = k // S + 1
        name = f"Synthetic {rep:02d} {src['country']}"
        f = 1.0 + 0.02 * rep * (1 if k % 2 == 0 else -1)
        r = src.copy()
        r["country"], r["iso"], r["iso2"] = name, _iso3(k), _iso2(k)
        r["region"] = SYNTH_REGIONS.get(rep, src["region"])
        r["spread"] = float(src["spread"]) * f
        rows.append(r)
        col = ind[src["country"]].copy()
        for i in numeric:
            v = pd.to_numeric(col.at[i], errors="coerce")
            if pd.notna(v):
                col.at[i] = float(v) * f
        new_ind[name] = col
        new_adj[name] = adj[src["country"]]
        clones[name] = (src["country"], src["iso"], _iso3(k))
    countries = pd.concat([seed, pd.DataFrame(rows)], ignore_index=True)
    indicators = pd.concat([ind, pd.DataFrame(new_ind, index=ind.index)], axis=1).reset_index()
    adjustments = pd.concat([adj, pd.DataFrame(new_adj, index=adj.index)], axis=1)
    weo = u.weo_raw
    if weo is not None and len(weo):
        extra = []
        for _name, (_src, src_iso, iso) in clones.items():
            w = weo[weo["iso"] == src_iso].copy()
            w["iso"] = iso
            extra.append(w)
        weo = pd.concat([weo, *extra], ignore_index=True)
    portfolio, markets = u.portfolio, u.markets
    if positions == "replicate":
        port_rows, mk_rows = [], []
        for j, (name, (src, _a, _b)) in enumerate(clones.items()):
            p = u.portfolio[u.portfolio["country"] == src].copy()
            p["id"] = [f"S{j:02d}{i}" for i in range(len(p))]
            p["country"] = name
            port_rows.append(p)
            m = u.markets[u.markets["country"] == src].copy()
            m["id"] = [f"SM{j:02d}{i}" for i in range(len(m))]
            m["country"] = name
            m["contract"] = m["contract"].astype(str).str.replace(src, name, regex=False)
            mk_rows.append(m)
        portfolio = pd.concat([u.portfolio, *port_rows], ignore_index=True)
        markets = pd.concat([u.markets, *mk_rows], ignore_index=True)
    elif positions != "seed":
        raise ValueError("positions must be 'seed' or 'replicate'")
    out = dataclasses.replace(u, countries=countries, indicators=indicators, adjustments=adjustments, weo_raw=weo,
                              portfolio=portfolio, markets=markets, provenance={**u.provenance, "synthetic_universe": f"{n} countries (EQ-B-0034 test fixture)"})
    problems = out.validate()
    if problems:
        raise ValueError("synthetic universe failed validation: " + "; ".join(problems))
    return out


@pytest.fixture(scope="module")
def base():
    return load_universe(DATA), Settings.load(DATA / "assumptions.json")


@pytest.fixture(scope="module")
def u70(base):
    return synthetic_universe(base[0], N_TARGET, positions="replicate")


def test_fixture_is_synthetic_and_unique(base, u70):
    u, _ = base
    assert len(u70.names) == N_TARGET and len(set(u70.names)) == N_TARGET
    c = u70.countries
    assert c["iso"].is_unique and c["iso2"].is_unique
    clones = c.iloc[len(u.names):]
    assert clones["iso"].str.match(r"^X[A-Z]{2}$").all()            # user-assigned ISO 3166 range, never a real country
    assert clones["country"].str.startswith("Synthetic ").all()
    assert c["region"].nunique() > u.countries["region"].nunique()


def test_scorecard_and_layer1_at_70(base, u70):
    _, s = base
    sc = score_universe(u70, s.copy_with(as_of=AS_OF))
    assert list(sc.composite.index) == u70.names
    assert sc.composite.notna().all() and sc.grade.between(1, 10).all()
    u18_sc = score_universe(base[0], s.copy_with(as_of=AS_OF))
    pd.testing.assert_series_equal(sc.composite.loc[base[0].names], u18_sc.composite, check_exact=True)
    l1 = L1.run_layer1(u70, s.copy_with(as_of=AS_OF), sc.pillar_aggregated.loc[4], as_of=AS_OF)
    assert list(l1.index) == u70.names and l1["pd_model"].between(0, 1).all()


@pytest.mark.parametrize("positions", ["seed", "replicate"])
def test_run_pipeline_end_to_end_at_70(base, positions):
    u, s = base
    u70 = synthetic_universe(u, N_TARGET, positions=positions)
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        r = run_pipeline(u70, s, paths=PATHS, as_of=AS_OF)
    assert list(r.country.index) == u70.names
    assert r.country[["pd_default", "pd_any", "composite", "el_default"]].notna().all().all()
    assert r.correlation.shape == (N_TARGET, N_TARGET)
    assert len(r.mc.region_order) == u70.countries["region"].nunique()
    m = r.metrics
    for k in ("var99_mm", "es99_mm", "expected_loss_mm"):
        assert np.isfinite(m[k])
    assert m["es99_mm"] >= m["var99_mm"]
    assert len(r.positions) == len(u70.portfolio)
    if r.signals is not None:
        assert list(r.signals.columns) == u70.names
        assert list(r.dashboard.index) == u70.names
        assert r.dashboard["column"].tolist() == list(range(1, N_TARGET + 1))
    assert set(r.to_dict()["pillars"]) == set(u70.names)


def test_seed_countries_unchanged_when_universe_grows(base):
    """With the layer 1 calibration pinned to the seed countries, adding countries does not move the seed countries'
    scorecard, layer 1 and layer 2 outputs. Portfolio numbers are not compared: the Sobol dimensions, the regional
    factors and the global regime share change with N."""
    u, s = base
    u70 = synthetic_universe(u, N_TARGET, positions="seed")
    pinned = s.copy_with(**{"layer1.calibration_universe": list(u.names)})
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        r18 = run_pipeline(u, s, paths=PATHS, as_of=AS_OF)
        r70 = run_pipeline(u70, pinned, paths=PATHS, as_of=AS_OF)
    cols = ["composite", "grade", "pd_hazard_l1", "pd_rating", "pd_model_l1", "pd_post", "pd_market"]
    pd.testing.assert_frame_equal(r70.country.loc[u.names, cols], r18.country[cols], check_exact=True)
    assert r70.layer1_model["calibration_universe"] == "layer1.calibration_universe (18 countries)"
    assert "calibration_universe" not in r18.layer1_model


def test_layer1_calibration_depends_on_universe_by_default(base):
    """Documents the cross-sectional calibration (EQ-B-0034 finding): with the shipped default the rating-prior
    location-scale fit uses every country in the run, so the seed countries' hazard PDs move when countries are added."""
    u, s = base
    s = s.copy_with(as_of=AS_OF)
    u70 = synthetic_universe(u, N_TARGET)
    p18 = L1.run_layer1(u, s, score_universe(u, s).pillar_aggregated.loc[4], as_of=AS_OF)["pd_hazard"]
    p70 = L1.run_layer1(u70, s, score_universe(u70, s).pillar_aggregated.loc[4], as_of=AS_OF)["pd_hazard"].loc[u.names]
    assert not np.allclose(p18.to_numpy(dtype=float), p70.to_numpy(dtype=float))


def test_calibration_universe_default_is_exact_noop_and_validates(base):
    u, s = base
    s = s.copy_with(as_of=AS_OF)
    p4 = score_universe(u, s).pillar_aggregated.loc[4]
    a = L1.run_layer1(u, s, p4, as_of=AS_OF)
    b = L1.run_layer1(u, s.copy_with(**{"layer1.calibration_universe": list(u.countries["iso"])}), p4, as_of=AS_OF)
    pd.testing.assert_frame_equal(a, b, check_exact=True)        # all 18 by ISO3 = the default set
    assert L1.calibration_mask(u, s) == (None, "all countries in the run")
    with pytest.raises(ValueError, match="not in the universe"):
        L1.calibration_mask(u, s.copy_with(**{"layer1.calibration_universe": ["Atlantis"]}))
    with pytest.raises(ValueError, match="at least 2 countries"):
        L1.run_layer1(u, s.copy_with(**{"layer1.calibration_universe": [u.names[0]]}), p4, as_of=AS_OF)


def _score_indicators_per_cell(u, indicators=None):
    """The pre-EQ-B-0034 per-cell implementation, kept as the reference for the vectorised one."""
    from econquest.scorecard.scoring import interp_score
    rb = u.rulebook.set_index("id")
    ind = (indicators if indicators is not None else u.indicators).set_index("id")
    out = pd.DataFrame(index=ind.index, columns=u.names, dtype=float)
    for iid, row in rb.iterrows():
        hi = row[["t0", "t25", "t50", "t75", "t100"]].to_numpy(dtype=float)
        lo = row[["low0", "low25", "low50", "low75", "low100"]].to_numpy(dtype=float)
        two_sided = not np.any(np.isnan(lo))
        is_level = str(row["type"]).lower().startswith("level")
        for c in u.names:
            x = ind.at[iid, c]
            if x == "" or pd.isna(x):
                out.at[iid, c] = np.nan
                continue
            x = float(x)
            if is_level:
                out.at[iid, c] = float(np.clip(x, 0, 4)) * 25.0
            else:
                sc = interp_score(x, hi)
                if two_sided:
                    sc = max(sc, interp_score(x, lo))
                out.at[iid, c] = sc
    return out


def test_vectorised_score_indicators_matches_per_cell(base, u70):
    from econquest.scorecard.scoring import score_indicators, stress_inputs
    u, s = base
    ind = u70.indicators.astype(object).copy()
    names = u70.names
    rb = u.rulebook.set_index("id")
    two = [i for i in rb.index if rb.loc[i, ["low0", "low25", "low50", "low75", "low100"]].notna().all()]
    ind.loc[ind["id"] == ind["id"].iloc[0], names[0]] = ""            # blank cell
    ind.loc[ind["id"] == ind["id"].iloc[1], names[1]] = np.nan        # missing cell
    ind.loc[ind["id"] == ind["id"].iloc[2], names[2]] = "12.5"        # number stored as text
    if two:
        ind.loc[ind["id"] == two[0], names[3]] = -1e6                 # far below the low side
        ind.loc[ind["id"] == two[0], names[4]] = 1e6
    for frame in (None, ind, stress_inputs(u70, s)):
        pd.testing.assert_frame_equal(score_indicators(u70, frame), _score_indicators_per_cell(u70, frame), check_exact=True)
    bad = ind.copy()
    bad.loc[bad["id"] == bad["id"].iloc[0], names[0]] = "n/a"
    with pytest.raises(ValueError):
        score_indicators(u70, bad)


def test_gpr_blank_analyst_410_takes_indicator_not_worst_level(base):
    """Regression (EQ-B-0034): a country row with no gpr_analyst_410 (a newly onboarded country) used to get
    final_410 = min(4.0, nan) = 4.0, the worst level. It now takes the indicator table's 4.10 value, and is
    missing (NaN), never 4, when that is blank too."""
    import dataclasses
    from econquest.engine.gpr import run_gpr
    u, s = base
    u70 = synthetic_universe(u, N_TARGET)
    c = u70.countries.copy()
    blank = [u70.names[20], u70.names[21]]
    c.loc[c["country"].isin(blank), "gpr_analyst_410"] = np.nan
    ind = u70.indicators.set_index("id")
    ind.loc["4.10", blank[1]] = np.nan
    u2 = dataclasses.replace(u70, countries=c, indicators=ind.reset_index())
    g, _ = run_gpr(u2, s, u2.gpr)
    ref, _ = run_gpr(u70, s, u70.gpr)
    assert g.at[blank[0], "analyst_410"] == float(ind.at["4.10", blank[0]])
    assert g.at[blank[0], "final_410"] == ref.at[blank[0], "final_410"]
    assert np.isnan(g.at[blank[1], "final_410"])
    others = [n for n in u70.names if n not in blank]
    pd.testing.assert_frame_equal(g.loc[others], ref.loc[others])


def test_scorecard_names_countries_with_an_empty_pillar(base, u70):
    """A country onboarded before its inputs are filled (Team A staging rows are blank until EQ-A-0026) gets a clear
    error naming it, not numpy's zero-size max error."""
    import dataclasses
    _, s = base
    ind = u70.indicators.set_index("id")
    victim = u70.names[-1]
    ind[victim] = np.nan
    # since EQ-B-0045 the readiness check stops first and names the country in one consolidated list
    with pytest.raises(ValueError, match=rf"{victim}: .*pillars 1-7 have no scored indicator"):
        score_universe(dataclasses.replace(u70, indicators=ind.reset_index()), s.copy_with(as_of=AS_OF))
