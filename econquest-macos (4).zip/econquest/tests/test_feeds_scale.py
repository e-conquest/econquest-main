"""EQ-A-0027: live feeds at the scale of the approved 88-country universe. All offline: wbgapi, yfinance and the BIS
HTTP endpoint are replaced by fakes at the library boundary, WEO by a synthetic long table.

Regression tests, one block per defect:
  1. Yahoo FX keyed by currency: countries sharing EUR/XOF/XAF overwrote each other.
  2. BIS: one HTTP call per country and flow (264 for 88), no retries.
  3. World Bank 2.9, 3.4, 3.5 dead for every country (wrong database for 2.9; one bad WGI code emptied database 3).
  4. Namibia's ISO2 'NA' read as missing.
  5. fetch_all end to end on a staged 88-country data folder; no hard-coded 18.
"""
import ast
import io
import re
import sys
import types
import urllib.error
import urllib.parse
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.ingestion import feeds, load_universe  # noqa: E402
from econquest.ingestion.feeds import (  # noqa: E402
    NO_FX_QUOTE, WB_SERIES, BisFeed, FeedError, WorldBankFeed, YahooFeed, _long, fetch_all, fx_tickers,
    official_fx_plan, wb_transforms)
from econquest.ingestion.sources import CsvSource, read_csv_keep_na_code  # noqa: E402
from econquest.ingestion.universe import DEFAULT_PROPOSAL, load_universe_proposal, missing_cell_report, stage_data_dir  # noqa: E402

DATA = ROOT / "data"
STAGING = DATA / "panel" / "universe_staging"
YEAR = 2026


# ---------------------------------------------------------------------------------------------------- fakes
def _fake_yfinance(calls: list):
    """yf.download stand-in: MultiIndex (ticker, field) frame, one distinct price path per ticker."""
    mod = types.ModuleType("yfinance")
    days = pd.bdate_range("2025-10-01", "2026-10-20")

    def download(tickers, **kw):
        calls.append(list(tickers))
        cols = {}
        for k, t in enumerate(tickers):
            base = 1.0 + k
            path = base * (1 + 0.1 * (days >= pd.Timestamp("2026-08-01")))   # +10% in the last ~3 months
            cols[(t, "Close")] = pd.Series(path, index=days)
        return pd.DataFrame(cols)

    mod.download = download
    return mod


WB_CATALOG = {
    2: {"SP.POP.TOTL", "NE.EXP.GNFS.ZS", "FI.RES.TOTL.CD", "NY.GDP.MKTP.CD", "FB.AST.NPER.ZS", "VC.IHR.PSRC.P5",
        "SL.UEM.1524.ZS", "NY.GDP.MKTP.KD.ZG", "FP.CPI.TOTL.ZG", "BN.CAB.XOKA.GD.ZS", "DT.DOD.DSTC.IR.ZS", "FI.RES.TOTL.MO"},
    6: {"DT.DOD.DECT.EX.ZS", "DT.TDS.DPPG.CD"},
    3: {"GOV_WGI_RL.SC", "GOV_WGI_CC.SC", "GOV_WGI_RQ.SC", "PV.EST"},     # the legacy *.PER.RNK codes are refused here
}


def _all_economies() -> list[str]:
    """Economies the fake answers economy='all' with: every real ISO3 the tests use plus fictional codes 'Q00'..'Q99'
    (synthetic, not countries) so the WGI cross-section is >= WGI_XS_MIN; 'WLD' is an aggregate (flagged)."""
    isos = {"PHL", "NAM", "KEN"}
    for f in (DATA / "countries.csv", STAGING / "countries.csv"):
        if f.exists():
            isos |= set(read_csv_keep_na_code(f, dtype=str)["iso"].dropna())
    return sorted(isos) + [f"Q{k:02d}" for k in range(100)] + ["WLD"]


def _fake_wbgapi(calls: list, catalog=WB_CATALOG, all_economies=None):
    """wbgapi stand-in that, like the API, refuses a whole request when one series is not in the database.
    economy='all' answers every economy of `all_economies` (default _all_economies()) with synthetic, distinct values,
    marking 'WLD' as an aggregate (dropped when skipAggs=True)."""
    mod = types.ModuleType("wbgapi")

    def fetch(series, economies, mrnev=None, db=None, skipBlanks=True, skipAggs=False):
        series = list(series)
        calls.append((db, tuple(series)) if economies != "all" else (db, tuple(series), "all"))
        bad = [s for s in series if s not in catalog.get(db, set())]
        if bad:
            raise RuntimeError(f"APIError: invalid series {bad} for source {db}")
        every = economies == "all"
        economies = (all_economies or _all_economies()) if every else economies
        out = []
        for s in series:
            for k, e in enumerate(economies):
                if every and skipAggs and e == "WLD":
                    continue
                for y in range(2018, 2025):
                    v = {"SP.POP.TOTL": 5e6, "FI.RES.TOTL.CD": 1e10, "NY.GDP.MKTP.CD": 5e10}.get(s, 40.0 + (y - 2018))
                    if every:
                        v = 5.0 + (k * 37) % 90 + (y - 2018) * 0.1
                    out.append({"economy": e, "series": s, "time": f"YR{y}", "value": v, "aggregate": e == "WLD"})
        return iter(out)

    def frame(series, economies, db=None, time=None, labels=False, skipAggs=True, numericTimeKeys=True):
        """wb.data.DataFrame for one series (panel_history.worldbank_series_fetcher): economies x years, wide."""
        db = db or 2
        calls.append((db, (series,)))
        if series not in catalog.get(db, set()):
            raise RuntimeError(f"APIError: invalid series {series} for source {db}")
        years = list(time or range(2018, 2025))
        df = pd.DataFrame({y: [1.0 + (y - 1996) / 10 + k for k in range(len(economies))] for y in years}, index=list(economies))
        df.index.name = "economy"
        return df

    mod.data = types.SimpleNamespace(fetch=fetch, DataFrame=frame)
    return mod


BIS_AREA = {"WS_EER": "REF_AREA", "WS_CBPOL": "REF_AREA", "WS_CREDIT_GAP": "BORROWERS_CTY"}
# EQ-A-0040: synthetic WS_XRU answers. The fake returns the full cross product of the requested areas and currencies
# (as the SDMX OR operator would), so the feed's own filtering of unrequested pairs is exercised.
XRU_DAYS = pd.bdate_range("2025-10-01", "2026-10-20")
XRU_SHARED_AREAS = {"XM", "SN", "CM"}


def _xru_csv(dims, known, url):
    areas = [a for a in dims[1].split("+") if a in known or a in XRU_SHARED_AREAS]
    ccys = [c for c in dims[2].split("+") if c]
    if not areas or not ccys:
        raise urllib.error.HTTPError(url, 404, "NoResultsFound", {}, None)
    rows = []
    for k, (a, c) in enumerate((a, c) for a in areas for c in ccys):
        base = 1.0 + k                                   # distinct per pair, +10% over the last ~3 months
        for d, mult in zip(XRU_DAYS, 1 + 0.1 * (XRU_DAYS >= pd.Timestamp("2026-08-01"))):
            rows.append({"FREQ": "D", "REF_AREA": a, "CURRENCY": c, "COLLECTION": dims[3],
                         "TIME_PERIOD": d.strftime("%Y-%m-%d"), "OBS_VALUE": base * mult})
    return pd.DataFrame(rows).to_csv(index=False)


def _fake_ecb_exr(calls: list, per_eur=None, days=None):
    """EcbExrFeed._get stand-in: SDMX-CSV of D.<CCY>.EUR.SP00.A for the requested currencies. SYNTHETIC."""
    per_eur = dict(per_eur or {})
    days = days if days is not None else XRU_DAYS

    def get(self, key, params=None):
        calls.append(key)
        ccys = key.split(".")[1].split("+")
        rows = []
        for k, c in enumerate(ccys):
            base = per_eur.get(c, 1.0 + k)
            for d, mult in zip(days, 1 + 0.1 * (days >= pd.Timestamp("2026-08-01"))):
                rows.append({"KEY": f"EXR.D.{c}.EUR.SP00.A", "TIME_PERIOD": d.strftime("%Y-%m-%d"),
                             "OBS_VALUE": base * (1.0 if c == "USD" else mult)})
        return pd.DataFrame(rows).to_csv(index=False)

    return get


def _fake_bis_urlopen(calls: list, known: set, fail_first: dict | None = None):
    """urlopen stand-in for stats.bis.org: answers an OR key (BR+CL+...) with rows for the known codes only and
    404 when none is known. fail_first maps a flow to a number of 503s returned before it answers."""
    fail_first = dict(fail_first or {})

    def urlopen(req, timeout=None):
        url = req.full_url if hasattr(req, "full_url") else str(req)
        assert url.startswith("https://stats.bis.org/")
        parts = urllib.parse.urlsplit(url).path.split("/")
        flow, key = parts[-3], parts[-2]
        calls.append((flow, key))
        if fail_first.get(flow, 0) > 0:
            fail_first[flow] -= 1
            raise urllib.error.HTTPError(url, 503, "busy", {}, None)
        dims = key.split(".")
        if flow == "WS_CBS_PUB":                     # Q.S.<reporters>.<bank type>.<basis>.C.A.A.TO1.A.<debtors>
            return io.BytesIO(_cbs_csv(dims, known, url).encode())
        if flow == "WS_XRU":                         # D.<areas>.<currencies>.A (EQ-A-0040)
            return io.BytesIO(_xru_csv(dims, known, url).encode())
        pos = 3 if flow == "WS_EER" else 1
        codes = [c for c in dims[pos].split("+") if c in known]
        if not codes:
            raise urllib.error.HTTPError(url, 404, "NoResultsFound", {}, None)
        rows = []
        for c in codes:
            if flow == "WS_EER":
                periods = [f"{2016 + i // 12}-{i % 12 + 1:02d}" for i in range(120)]
            elif flow == "WS_CBPOL":
                periods = [f"2026-10-{d:02d}" for d in range(1, 11)]
            else:
                periods = ["2025-Q3", "2025-Q4", "2026-Q1", "2026-Q2"]
            for p in periods:
                rows.append({"FREQ": dims[0], BIS_AREA[flow]: c, "TIME_PERIOD": p, "OBS_VALUE": 100.0 if flow == "WS_EER" else 5.0})
        return io.BytesIO(pd.DataFrame(rows).to_csv(index=False).encode())

    return urlopen


CBS_REPORTERS = {"US": 3.0, "GB": 2.0, "JP": 1.0, "5A": 6.0, "5J": 5.0}     # 5A/5J: BIS aggregates, must be dropped


def _cbs_csv(dims, known, url):
    debtors = [c for c in dims[10].split("+") if c in known]
    if not debtors:
        raise urllib.error.HTTPError(url, 404, "NoResultsFound", {}, None)
    periods = [f"{y}-Q{q}" for y in (2024, 2025, 2026) for q in (1, 2, 3, 4)][:10]     # 2024-Q1 .. 2026-Q2
    rows = []
    for c in debtors:
        for rep, w in CBS_REPORTERS.items():
            if rep == "JP" and c == "CL":
                continue
            for k, p in enumerate(periods):
                if c == "AR" and p == periods[-1]:
                    continue                                         # AR: not reported in the latest quarter
                rows.append({"FREQ": "Q", "L_MEASURE": "S", "L_REP_CTY": rep, "CBS_BANK_TYPE": dims[3], "CBS_BASIS": dims[4],
                             "L_POSITION": "C", "L_CP_COUNTRY": c, "TIME_PERIOD": p, "OBS_VALUE": w * 1000 + k})
    return pd.DataFrame(rows).to_csv(index=False)


def _weo_long(isos):
    rows = []
    for iso in isos:
        for y in range(2010, 2028):
            rows += [{"iso": iso, "series": "GGXWDG_NGDP", "period": y, "value": 30 + (y - 2010)},
                     {"iso": iso, "series": "NGDP", "period": y, "value": 1000 * 1.08 ** (y - 2010)},
                     {"iso": iso, "series": "NGDP_RPCH", "period": y, "value": 3.0 + (0.5 if y % 2 else -0.5)},
                     {"iso": iso, "series": "PCPIPCH", "period": y, "value": 3.0},
                     {"iso": iso, "series": "BCA_NGDPD", "period": y, "value": -2.0},
                     {"iso": iso, "series": "NGDPDPC", "period": y, "value": 4000.0},
                     {"iso": iso, "series": "GGXONLB_NGDP", "period": y, "value": -1.0},
                     {"iso": iso, "series": "GGXCNL_NGDP", "period": y, "value": -3.0}]
    return _long(rows, "fake WEO")


@pytest.fixture(scope="module")
def staged_dir(tmp_path_factory):
    """A complete 88-country data folder built the way the runbook does it (stage_data_dir on the staged files)."""
    if not (STAGING / "countries.csv").exists():
        pytest.skip("data/panel/universe_staging not built (run `python -m econquest.ingestion.universe expand`)")
    return stage_data_dir(STAGING, tmp_path_factory.mktemp("stage") / "data", DATA)


@pytest.fixture(scope="module")
def prop():
    return load_universe_proposal(DEFAULT_PROPOSAL)


# ---------------------------------------------------------------------------------------------------- 1. Yahoo FX
def test_fx_tickers_keyed_by_country_for_shared_currencies(prop):
    cty = prop.rename(columns={"iso3": "iso"})[["iso", "currency"]]
    tick, why = fx_tickers(cty)
    for iso in ("DEU", "FRA", "ITA", "MNE"):
        assert tick[iso] == "EUR=X"
    for iso in ("SEN", "CIV", "BEN"):
        assert tick[iso] == "XOF=X"
    for iso in ("CMR", "GAB", "COG"):
        assert tick[iso] == "XAF=X"
    for iso in ("USA", "PAN", "ECU", "SLV"):                   # dollarised: no ticker, explicit reason
        assert iso not in tick and why[iso] == NO_FX_QUOTE["USD"]
    assert "ZWE" not in tick and "ZiG" in why["ZWE"]
    assert set(tick) | set(why) == set(prop["iso3"])
    # the proposal's own yahoo_fx column agrees with the derived tickers
    tick2, why2 = fx_tickers(prop.rename(columns={"iso3": "iso"}))
    assert tick2 == tick and set(why2) == set(why)


def test_yahoo_fetches_each_ticker_once_and_fans_out(monkeypatch):
    calls = []
    monkeypatch.setitem(sys.modules, "yfinance", _fake_yfinance(calls))
    fx = {"SEN": "XOF=X", "CIV": "XOF=X", "BEN": "XOF", "DEU": "EUR=X", "FRA": "EUR=X", "PAN": "USD"}
    long = YahooFeed().fetch(fx, {"DEU": "EWG", "FRA": "EWQ"})
    assert len(calls) == 1 and sorted(calls[0]) == sorted(set(calls[0])) == ["EUR=X", "EWG", "EWQ", "XOF=X"]
    fxrows = long[long["series"] == "FX_USD"]
    assert set(fxrows["iso"]) == {"SEN", "CIV", "BEN", "DEU", "FRA"}               # every sharer has rows, PAN none
    a = fxrows[fxrows["iso"] == "SEN"]["value"].to_numpy()
    b = fxrows[fxrows["iso"] == "CIV"]["value"].to_numpy()
    assert len(a) > 200 and np.array_equal(a, b)
    out = feeds.yahoo_transforms(long, "BEN")
    assert abs(out["fx3m"] - 10.0) < 1e-9


def test_yahoo_single_ticker_flat_frame(monkeypatch):
    days = pd.bdate_range("2026-01-01", periods=5)
    mod = types.ModuleType("yfinance")
    mod.download = lambda tickers, **kw: pd.DataFrame({"Close": np.arange(5.0) + 1}, index=days)
    monkeypatch.setitem(sys.modules, "yfinance", mod)
    long = YahooFeed().fetch({"SEN": "XOF=X", "CIV": "XOF=X"}, {})
    assert long.groupby("iso").size().to_dict() == {"CIV": 5, "SEN": 5}


# ---------------------------------------------------------------------------------------------------- 2. BIS
def test_bis_batches_countries_with_sdmx_or(monkeypatch):
    calls = []
    iso2s = {f"C{i:02d}": f"{chr(65 + i // 26)}{chr(65 + i % 26)}" for i in range(88)}      # 88 distinct two-letter codes
    known = set(list(iso2s.values())[::2])
    monkeypatch.setattr("econquest.ingestion.sources.open_url_no_redirect", _fake_bis_urlopen(calls, known))
    long = BisFeed(batch=25, sleep=lambda s: None).fetch(iso2s)
    assert len(calls) == 3 * 4                                  # 3 flows x ceil(88 / 25), not 3 x 88
    assert all("+" in k for _, k in calls)
    to3 = {v: k for k, v in iso2s.items()}
    for series in ("EER_REAL_BROAD", "CREDIT_GAP", "POLICY_RATE"):
        got = set(long.loc[long["series"] == series, "iso"])
        assert got == {to3[c] for c in known}, series          # attributed through REF_AREA / BORROWERS_CTY


def test_bis_retries_transient_then_falls_back_per_country(monkeypatch):
    calls, slept = [], []
    known = {"BR", "CL"}
    monkeypatch.setattr("econquest.ingestion.sources.open_url_no_redirect", _fake_bis_urlopen(calls, known, fail_first={"WS_CBPOL": 2}))
    long = BisFeed(sleep=slept.append, backoff=1.0).fetch({"BRA": "BR", "CHL": "CL", "XXX": "QQ"})
    assert slept == [1.0, 2.0]                                   # two 503s, exponential backoff, then success
    assert set(long.loc[long["series"] == "POLICY_RATE", "iso"]) == {"BRA", "CHL"}
    # a batch where no code is known (404) is not retried with backoff, then tried one country at a time
    calls.clear(); slept.clear()
    with pytest.raises(FeedError):
        BisFeed(sleep=slept.append).fetch({"AAA": "QQ", "BBB": "QR"})
    assert slept == [] and len(calls) == 3 * 3                  # per flow: 1 batch + 2 single-country calls


def test_bis_keeps_https_check():
    with pytest.raises(ValueError):
        BisFeed(base="http://stats.bis.org/api/v1/data")._get("WS_CBPOL", "D.BR")
    src = Path(feeds.__file__).read_text()
    assert "nosec B310" in src and 'url.startswith("https://")' in src


def test_bis_area_column_keeps_namibia_code(monkeypatch):
    calls = []
    monkeypatch.setattr("econquest.ingestion.sources.open_url_no_redirect", _fake_bis_urlopen(calls, {"NA", "ZA"}))
    long = BisFeed(sleep=lambda s: None).fetch({"NAM": "NA", "ZAF": "ZA"})
    assert set(long.loc[long["series"] == "POLICY_RATE", "iso"]) == {"NAM", "ZAF"}


# ---------------------------------------------------------------------------------------------------- 3. World Bank
def test_wb_series_match_rulebook_api_map():
    rb = pd.read_csv(DATA / "rulebook.csv", dtype={"id": str}).set_index("id")
    assert "DT.DOD.DSTC.IR.ZS" in rb.at["2.9", "api"] and WB_SERIES["DT.DOD.DSTC.IR.ZS"][0] == 2
    for i in ("3.4", "3.5"):
        m = re.search(r"GOV_WGI_([A-Z/]+)\.SC", rb.at[i, "api"])
        assert m, rb.at[i, "api"]
        for x in m.group(1).split("/"):
            assert WB_SERIES[f"GOV_WGI_{x}.SC"][0] == 3


def test_wb_one_bad_code_no_longer_empties_a_database(monkeypatch):
    calls = []
    monkeypatch.setitem(sys.modules, "wbgapi", _fake_wbgapi(calls))
    long = WorldBankFeed().fetch(["PHL", "NAM"])
    got = set(long["series"])
    assert {"GOV_WGI_RL.SC", "GOV_WGI_CC.SC", "GOV_WGI_RQ.SC", "DT.DOD.DSTC.IR.ZS", "DT.DOD.DECT.EX.ZS"} <= got
    assert any("no rows for" in f and "RL.PER.RNK" in f for f in long.attrs["failures"])
    ind, _ = wb_transforms(long, "NAM")
    assert {"2.9", "3.4", "3.5"} <= set(ind)
    # 2.9 falls back to IDS (source 6) when WDI has no row
    cat = {k: set(v) for k, v in WB_CATALOG.items()}
    cat[2].discard("DT.DOD.DSTC.IR.ZS"); cat[6].add("DT.DOD.DSTC.IR.ZS")
    monkeypatch.setitem(sys.modules, "wbgapi", _fake_wbgapi([], cat))
    assert "DT.DOD.DSTC.IR.ZS" in set(WorldBankFeed().fetch(["PHL"])["series"])


def _wgi_xs(scores: dict, years=range(2020, 2024), drift=0.0) -> list[dict]:
    """Synthetic WGI cross-section rows (fictional economies unless a real ISO3 is passed): one score per economy,
    the same for RL/CC/RQ, shifted by `drift` x (year - 2020)."""
    return [{"iso": e, "series": s, "period": y, "value": v + drift * (y - 2020)}
            for e, v in scores.items() for s in feeds.WGI_SCORE_FAMILY for y in years]


def test_wgi_families_are_never_mixed():
    # legacy family incomplete -> the score family is used, ranked among the cross-section, never the raw score
    xs = _wgi_xs({"KEN": 50.0, "QAA": 10.0, "QBB": 30.0, "QCC": 70.0, "QDD": 90.0})
    legacy = [{"iso": "KEN", "series": s, "period": y, "value": 30.0} for s in ("RL.PER.RNK", "CC.PER.RNK") for y in range(2020, 2024)]
    long = pd.concat([_long(legacy, "t"), _long(xs, feeds.WGI_XS_SOURCE)], ignore_index=True)
    used = {}
    ind, _ = wb_transforms(long, "KEN", used=used, min_n=5)
    assert ind["3.5"] == 50.0 and ind["3.4"] == 0.0 and used["3.5"].startswith("GOV_WGI_RL.SC")
    assert "percentile rank among 5-5 economies in 2023" in used["3.5"]
    rq = [{"iso": "KEN", "series": "RQ.PER.RNK", "period": y, "value": 30.0} for y in range(2020, 2024)]
    used = {}
    ind, _ = wb_transforms(pd.concat([long, _long(rq, "t")], ignore_index=True), "KEN", used=used, min_n=5)
    assert used["3.5"].startswith("RL.PER.RNK") and ind["3.5"] == 30.0         # percentile ranks first when complete


def test_wgi_score_to_percentile_rank():
    """EQ-A-0036: GOV_WGI_*.SC 0-100 scores -> share of economies ranking below, 100 x below / (n - 1), per year."""
    # synthetic cross-section of 6 fictional economies (Q..) plus KEN; an aggregate code must not enter the ranking
    scores = {"QAA": 5.0, "QBB": 20.0, "KEN": 40.0, "QCC": 40.0, "QDD": 60.0, "QEE": 80.0, "QFF": 95.0}
    xs = _wgi_xs(scores) + _wgi_xs({"WLD": 50.0, "SSA": 1.0})
    # KEN climbs past QCC and QDD between 2020 and 2023: 40 -> 70 (others fixed)
    xs = [dict(r, value=r["value"] + (10.0 * (r["period"] - 2020) if r["iso"] == "KEN" else 0.0)) for r in xs]
    long = _long(xs, feeds.WGI_XS_SOURCE)
    r, n = feeds.wgi_percentile_rank(long, "GOV_WGI_RL.SC", "KEN", 2020, min_n=7)
    assert n == 7 and abs(r - 2 / 6 * 100) < 1e-9          # 2 below (QAA, QBB); tie with QCC shares the lower rank
    assert feeds.wgi_percentile_rank(long, "GOV_WGI_RL.SC", "QFF", 2020, min_n=7)[0] == 100.0
    assert feeds.wgi_percentile_rank(long, "GOV_WGI_RL.SC", "QAA", 2020, min_n=7)[0] == 0.0
    used, why = {}, {}
    ind, _ = wb_transforms(long, "KEN", used=used, why=why, min_n=7)
    assert abs(ind["3.5"] - 4 / 6 * 100) < 1e-9             # 2023: 70 beats QAA, QBB, QCC, QDD
    assert abs(ind["3.4"] - 2 / 6 * 100) < 1e-9             # 66.7 - 33.3 percentile points
    assert not why and "percentile rank" in used["3.5"] and "2023 minus 2020" in used["3.4"]


def test_wgi_scores_without_cross_section_stay_empty():
    """Scores with no all-economy cross-section (offline fixture, raw file from before EQ-A-0036) never become 3.5."""
    rows = [{"iso": "KEN", "series": s, "period": y, "value": 63.0} for s in feeds.WGI_SCORE_FAMILY for y in range(2020, 2024)]
    why = {}
    ind, _ = wb_transforms(_long(rows, "wbgapi World Bank API v2"), "KEN", why=why)
    assert "3.5" not in ind and "3.4" not in ind
    assert "not percentile ranks" in why["3.5"] and why["3.4"] == why["3.5"]
    # a cross-section that is too small (here 3 economies, default minimum WGI_XS_MIN) is no cross-section
    small = _long(_wgi_xs({"KEN": 63.0, "QAA": 10.0, "QBB": 90.0}), feeds.WGI_XS_SOURCE)
    ind, _ = wb_transforms(small, "KEN", why=(why := {}))
    assert "3.5" not in ind and "need >= 100" in why["3.5"]
    # 3.5 ranked but no cross-section 3 years earlier -> 3.4 empty with a reason, not a score difference
    one_year = _long(_wgi_xs({"KEN": 50.0, "QAA": 10.0, "QBB": 90.0}, years=(2023,)), feeds.WGI_XS_SOURCE)
    late = pd.concat([one_year, _long([{"iso": "KEN", "series": s, "period": 2020, "value": 50.0} for s in feeds.WGI_SCORE_FAMILY], "x")])
    ind, _ = wb_transforms(late, "KEN", why=(why := {}), min_n=3)
    assert ind["3.5"] == 50.0 and "3.4" not in ind and "2020" in why["3.4"]


def test_wb_fetch_pulls_wgi_cross_section_for_all_economies(monkeypatch):
    calls = []
    monkeypatch.setitem(sys.modules, "wbgapi", _fake_wbgapi(calls))
    long = WorldBankFeed().fetch(["PHL", "NAM"])
    assert (3, tuple(feeds.WGI_SCORE_FAMILY), "all") in calls
    xs = long[long["source"] == feeds.WGI_XS_SOURCE]
    assert set(xs["series"]) == set(feeds.WGI_SCORE_FAMILY) and "WLD" not in set(xs["iso"]) and xs["iso"].nunique() >= feeds.WGI_XS_MIN
    assert not len(long[(long["source"] != feeds.WGI_XS_SOURCE) & long["series"].isin(feeds.WGI_SCORE_FAMILY)])
    # the all-economy call fails -> scores for the universe only, recorded, and 3.5 empty rather than a raw score
    def boom(series, economies, **kw):
        if economies == "all":
            raise RuntimeError("timeout")
        return orig(series, economies, **kw)
    mod = _fake_wbgapi([]); orig = mod.data.fetch; mod.data.fetch = boom
    monkeypatch.setitem(sys.modules, "wbgapi", mod)
    long = WorldBankFeed().fetch(["PHL", "NAM"])
    assert set(feeds.WGI_SCORE_FAMILY) <= set(long["series"]) and not (long["source"] == feeds.WGI_XS_SOURCE).any()
    assert any("all economies" in f for f in long.attrs["failures"])
    ind, _ = wb_transforms(long, "NAM")
    assert "3.5" not in ind and "3.4" not in ind


# ---------------------------------------------------------------------------------------------------- 4. Namibia 'NA'
def test_csv_reads_keep_namibia_iso2(staged_dir, tmp_path):
    cty = CsvSource(staged_dir / "countries.csv").fetch().set_index("country")
    assert cty.at["Namibia", "iso2"] == "NA"
    assert pd.isna(cty.at["Namibia", "pop"])                                    # blanks are still missing
    u = load_universe(staged_dir)
    assert u.countries.set_index("country").at["Namibia", "iso2"] == "NA"
    # apply_report writes countries.csv back with 'NA', not a blank
    d = tmp_path
    for f in ("countries.csv", "indicators.csv"):
        (d / f).write_bytes((staged_dir / f).read_bytes())
    prof = pd.DataFrame(index=u.names, columns=["pop", "exports", "reserves", "fx3m", "policy", "equity_vol"], dtype=float)
    prof.at["Namibia", "pop"] = 3.0
    ind = pd.DataFrame(index=list(u.indicators["id"]), columns=u.names, dtype=float)
    feeds.apply_report(feeds.FetchReport(ind, prof, pd.DataFrame(), {}, {}), d)
    back = read_csv_keep_na_code(d / "countries.csv", dtype=str).set_index("country")
    assert back.at["Namibia", "iso2"] == "NA" and float(back.at["Namibia", "pop"]) == 3.0


# ---------------------------------------------------------------------------------------------------- 5. end to end
def test_fetch_all_on_staged_88_country_folder(staged_dir, monkeypatch):
    u = load_universe(staged_dir)
    n = len(u.names)
    assert n == len(pd.read_csv(staged_dir / "countries.csv")) and n > 70
    ecb_calls, wb_calls, bis_calls = [], [], []
    monkeypatch.setattr(feeds.EcbExrFeed, "_get", _fake_ecb_exr(ecb_calls))
    monkeypatch.setitem(sys.modules, "wbgapi", _fake_wbgapi(wb_calls))
    bis_known = set(u.countries["iso2"].dropna())
    monkeypatch.setattr("econquest.ingestion.sources.open_url_no_redirect", _fake_bis_urlopen(bis_calls, bis_known))
    monkeypatch.setattr(feeds.WeoFeed, "fetch", lambda self, isos, codes=feeds.WEO_CODES: _weo_long(list(isos)))
    rep = fetch_all(u, year=YEAR, log=lambda m: None)
    assert all(str(v).startswith("ok") for v in rep.feeds.values()), rep.feeds
    assert list(rep.indicators.columns) == u.names and list(rep.profile.index) == u.names
    # every country gets WEO, World Bank (incl. the formerly dead 2.9, 3.4, 3.5) and BIS cells
    for key in ("1.3", "2.9", "3.4", "3.5", "2.12", "5.9", "5.13"):
        assert rep.indicators.loc[key].notna().all(), key
    wgi = rep.provenance[rep.provenance["key"] == "3.5"]                  # EQ-A-0036: ranked, and the transform is recorded
    assert len(wgi) == n and wgi["series"].str.contains("-> percentile rank among").all()
    assert rep.indicators.loc["3.5"].between(0, 100).all()
    assert len(bis_calls) <= 5 * int(np.ceil(n / BisFeed().batch))     # 3 flows + WS_CBS_PUB + WS_XRU, batched
    # EQ-A-0028: BIS CBS claims and World Bank history for every country
    assert set(rep.raw["bis_cbs"]["debtor_iso3"]) == set(u.countries.loc[u.countries["iso2"].isin(bis_known), "iso"])
    assert set(rep.raw["worldbank_history"]["iso"]) == set(u.countries["iso"])
    # EQ-A-0040: official FX, one BIS series per currency, shared by every country using it; no Yahoo anywhere
    iso = dict(zip(u.names, u.countries["iso"]))
    fxplan = official_fx_plan(u.countries)
    has_fx = rep.profile["fx3m"].notna()
    assert {c for c in u.names if has_fx[c]} == {c for c in u.names if iso[c] in fxplan.currency}
    for c in ("Germany", "France", "Italy", "Senegal", "Cote d'Ivoire", "Benin", "Cameroon", "Gabon"):
        assert has_fx[c], c
    assert rep.profile.loc["Germany", "fx3m"] == pytest.approx(rep.profile.loc["France", "fx3m"])
    assert rep.profile.loc["Senegal", "fx3m"] == pytest.approx(rep.profile.loc["Benin", "fx3m"])
    prov_fx = rep.provenance[rep.provenance["key"] == "fx3m"]
    assert prov_fx["source"].str.contains("WS_XRU").all() and not prov_fx["source"].str.contains("ahoo").any()
    uns = rep.unserved[rep.unserved["key"] == "fx3m"].set_index("country")
    assert set(uns.index) == {c for c in u.names if iso[c] in fxplan.why}
    assert "ZiG" in uns.at["Zimbabwe", "reason"] and uns.at["Panama", "reason"] == NO_FX_QUOTE["USD"]
    # equity_vol: no official free source, every country unserved with the reason, no live value
    eq = rep.unserved[rep.unserved["key"] == "equity_vol"]
    assert len(eq) == n and eq["reason"].str.startswith(feeds.NO_OFFICIAL_SOURCE).all()
    assert rep.profile["equity_vol"].isna().all()
    # gate, save and the missing-cell report work at this size
    diff = feeds.diff_against_seed(u, rep)
    review = feeds.quality_gate(u, rep, diff, year=YEAR)
    pan = review[(review["key"] == "fx3m") & (review["country"] == "Panama")]
    assert len(pan) == 1 and pan["status"].iloc[0] == "missing" and "not served" in pan["reason"].iloc[0]
    ev = review[(review["key"] == "equity_vol") & (review["country"] == "Brazil")]
    assert len(ev) == 1 and ev["status"].iloc[0] == "missing" and feeds.NO_OFFICIAL_SOURCE in ev["reason"].iloc[0]
    live = feeds.save_report(rep, staged_dir, diff)
    review.to_csv(live / "review.csv", index=False)
    assert (live / "unserved.csv").exists() and (live / "feed_failures.csv").exists()
    assert list(pd.read_csv(live / "raw_bis_cbs.csv").columns) == feeds.CBS_COLUMNS
    assert list(pd.read_csv(live / "raw_bis_xru.csv").columns) == [*feeds.LONG_COLUMNS, "sdmx_key"]
    assert list(pd.read_csv(live / "raw_ecb_exr.csv").columns) == [*feeds.LONG_COLUMNS, "sdmx_key"]
    assert list(pd.read_csv(live / "raw_worldbank_history.csv").columns) == feeds.LONG_COLUMNS
    mc = missing_cell_report(staged_dir)
    assert mc.summary["n_countries"] == n and (mc.countries["live"] > 0).all()


def test_no_hard_coded_18_in_team_a_feed_code():
    """The country count comes from countries.csv; no integer literal 18 in the scaled modules."""
    for f in ("feeds.py", "loaders.py", "sources.py", "universe.py"):
        tree = ast.parse((ROOT / "econquest" / "ingestion" / f).read_text())
        lits = [n.lineno for n in ast.walk(tree) if isinstance(n, ast.Constant) and type(n.value) is int and n.value == 18]
        assert not lits, f"{f}: literal 18 at lines {lits}"


def test_fetch_all_reports_wgi_unranked_as_unserved(staged_dir, monkeypatch):
    """EQ-A-0036: without the all-economy WGI cross-section, 3.4/3.5 are empty and unserved.csv says why, so the gate
    reports them missing (with that reason) rather than wrong."""
    mod = _fake_wbgapi([]); orig = mod.data.fetch
    mod.data.fetch = lambda series, economies, **kw: (_ for _ in ()).throw(RuntimeError("timeout")) if economies == "all" else orig(series, economies, **kw)
    monkeypatch.setitem(sys.modules, "wbgapi", mod)
    monkeypatch.setattr(feeds, "WorldBankHistoryFeed", lambda: types.SimpleNamespace(fetch=lambda isos: _long([], "x")))
    u = load_universe(staged_dir)
    rep = fetch_all(u, only=["worldbank"], year=YEAR, log=lambda m: None)
    assert rep.indicators.loc[["3.4", "3.5"]].isna().all().all()
    uns = rep.unserved[(rep.unserved["feed"] == "worldbank")]
    assert set(uns["key"]) == {"3.4", "3.5"} and len(uns) == 2 * len(u.names)
    assert uns["reason"].str.contains("not percentile ranks").all()
