"""EQ-A-0005: vintages are append-only (timestamp + content-hash ids, read-only files, index.csv) and apply_report
keeps a pre-apply snapshot of indicators.csv and countries.csv and writes them atomically."""
import datetime as dt
import json
import os
import stat
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.ingestion.feeds import FetchReport, save_vintage, list_vintages, vintage_path, apply_report  # noqa: E402

DATA = ROOT / "data"
CLOCK = dt.datetime(2026, 10, 24, 18, 20, 5, tzinfo=dt.timezone.utc)


def _report():
    ind = pd.DataFrame({"Vietnam": [36.5, np.nan]}, index=["1.3", "5.5"])
    prof = pd.DataFrame(np.nan, index=["Vietnam"], columns=["pop", "exports", "reserves", "fx3m", "policy", "equity_vol"])
    prof.at["Vietnam", "pop"] = 101.3
    prov = pd.DataFrame([{"table": "Inputs", "key": "1.3", "country": "Vietnam", "value": 36.5, "source": "test", "series": "x", "retrieved": "2026-10-24"}])
    raw = {"weo": pd.DataFrame([{"iso": "VNM", "series": "GGXWDG_NGDP", "period": 2026, "value": 36.5, "source": "test"}])}
    return FetchReport(ind, prof, prov, {"weo": "ok (1 rows)"}, raw)


def _legacy(data_dir: Path) -> Path:
    """A date-only vintage folder like data/live/vintages/2026-10-23/."""
    v = data_dir / "live" / "vintages" / "2026-10-23"; v.mkdir(parents=True)
    (v / "feeds.json").write_text(json.dumps({"feeds": {"weo": "ok"}, "retrieved": "2026-10-23"}))
    (v / "live_inputs.csv").write_text(",Vietnam\n1.3,33.0\n")
    return v


def _bytes(folder: Path) -> dict:
    return {p.name: p.read_bytes() for p in sorted(folder.iterdir())}


def test_second_save_same_clock_raises_and_first_is_untouched(tmp_path):
    rev = pd.DataFrame([{"table": "Inputs", "key": "1.3", "country": "Vietnam", "seed": 33.0, "live": 36.5, "status": "ok", "reason": ""}])
    v = save_vintage(tmp_path, _report(), rev, now=CLOCK)
    assert v.name.startswith("2026-10-24T182005Z-") and len(v.name.split("-")[-1]) == 8
    before = _bytes(v)
    assert set(before) == {"live_inputs.csv", "live_profile.csv", "provenance.csv", "raw_weo.csv", "review.csv", "feeds.json"}
    assert json.loads(before["feeds.json"])["retrieved"] == "2026-10-24T18:20:05Z"
    with pytest.raises(FileExistsError):
        save_vintage(tmp_path, _report(), rev, now=CLOCK)
    assert _bytes(v) == before
    for p in v.iterdir():                                       # read-only
        assert stat.S_IMODE(p.stat().st_mode) == 0o444
    # a later pull the same day is a new folder; the date id resolves to the latest
    v2 = save_vintage(tmp_path, _report(), rev, now=CLOCK + dt.timedelta(hours=1))
    assert v2 != v and list_vintages(tmp_path) == [v.name, v2.name]
    assert vintage_path(tmp_path, "2026-10-24") == v2 and vintage_path(tmp_path, v.name) == v
    idx = pd.read_csv(tmp_path / "live" / "vintages" / "index.csv")
    assert list(idx["vintage_id"]) == [v.name, v2.name] and list(idx["n_files"]) == [6, 6]
    assert idx["hash"].iloc[0].startswith(v.name.split("-")[-1])


def test_hash_is_deterministic(tmp_path):
    a = save_vintage(tmp_path / "a", _report(), now=CLOCK)
    b = save_vintage(tmp_path / "b", _report(), now=CLOCK)
    assert a.name == b.name


def test_legacy_date_vintage_resolves_and_is_indexed_untouched(tmp_path):
    leg = _legacy(tmp_path); before = _bytes(leg)
    assert vintage_path(tmp_path, "2026-10-23") == leg
    v = save_vintage(tmp_path, _report(), now=CLOCK)
    idx = pd.read_csv(tmp_path / "live" / "vintages" / "index.csv")
    assert list(idx["vintage_id"]) == ["2026-10-23", v.name]
    assert idx["retrieved_utc"].iloc[0] == "2026-10-23" and idx["n_files"].iloc[0] == 2
    assert _bytes(leg) == before
    assert list_vintages(tmp_path) == ["2026-10-23", v.name]
    assert vintage_path(tmp_path, "2026-10-23") == leg      # legacy is the only vintage that day
    with pytest.raises(FileNotFoundError):
        vintage_path(tmp_path, "2026-10-22")
    # the legacy row is added only when index.csv is created
    save_vintage(tmp_path, _report(), now=CLOCK + dt.timedelta(seconds=1))
    assert (pd.read_csv(tmp_path / "live" / "vintages" / "index.csv")["vintage_id"] == "2026-10-23").sum() == 1


def test_repo_legacy_vintage_resolves():
    assert "2026-10-23" in list_vintages(DATA)
    assert (vintage_path(DATA, "2026-10-23") / "feeds.json").exists()


def test_apply_snapshots_old_files_and_writes_atomically(tmp_path):
    for f in ("indicators.csv", "countries.csv"):
        (tmp_path / f).write_bytes((DATA / f).read_bytes())
    old = {f: (tmp_path / f).read_bytes() for f in ("indicators.csv", "countries.csv")}
    out = apply_report(_report(), tmp_path, now=CLOCK)
    snap = Path(out["snapshot"])
    assert snap.parent == tmp_path / "live" / "snapshots" and snap.name == "2026-10-24T182005Z-pre-apply"
    assert {f: (snap / f).read_bytes() for f in old} == old
    assert all(stat.S_IMODE((snap / f).stat().st_mode) == 0o444 for f in old)
    assert float(pd.read_csv(tmp_path / "indicators.csv", dtype={"id": str}).set_index("id").at["1.3", "Vietnam"]) == 36.5
    assert {k: out[k] for k in ("indicator_cells", "profile_cells", "held_for_review")} == {"indicator_cells": 1, "profile_cells": 1, "held_for_review": 0}
    assert not [p for p in os.listdir(tmp_path) if p.endswith(".tmp")]
    # a second apply with the same clock never overwrites the first snapshot
    out2 = apply_report(_report(), tmp_path, now=CLOCK)
    assert Path(out2["snapshot"]) != snap and {f: (snap / f).read_bytes() for f in old} == old
