"""Distribution of published products (EQ-C-0045): subscribers per kind, dry run by default, --send only through a fake
SMTP server (smtplib monkeypatched: nothing connects anywhere), published items only, archive link and no attachments,
header injection refused, hash-chained delivery log, latency p95 for products and health alerts."""
import datetime as dt
import json
import os
import smtplib
from pathlib import Path

import pytest

from econquest import cli
from econquest.ops import distribute as D
from econquest.ops import health
from econquest.presentation import editorial as E
from test_compliance import reviewed, write  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
SUBS = {"country_note": ["alice@example.com", "bob@example.com"], "daily_report": ["carol@example.com"]}
ENV = {"ECONQUEST_SMTP_HOST": "smtp.example.com", "ECONQUEST_SMTP_PORT": "587", "ECONQUEST_SMTP_USER": "desk@example.com",
       "ECONQUEST_SMTP_PASSWORD": "s3cret-pw-123", "ECONQUEST_SMTP_FROM": "desk@example.com"}


class FakeSMTP:
    """Stands in for smtplib.SMTP: records messages, never opens a socket."""
    sent: list = []
    fail_for: set = set()

    def __init__(self, host, port, timeout=None, **kw):
        self.host = host

    def ehlo(self):
        return 250, b"ok"

    def has_extn(self, name):
        return name == "starttls"

    def starttls(self, context=None):
        return 220, b"ok"

    def login(self, user, pw):
        self.user = user

    def send_message(self, msg):
        to = msg["To"]
        if to in FakeSMTP.fail_for:
            raise smtplib.SMTPRecipientsRefused({to: (550, b"refused for pw s3cret-pw-123")})
        FakeSMTP.sent.append(msg)

    def close(self):
        pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


class NoNetwork:
    def __init__(self, *a, **kw):
        raise AssertionError("a dry run must never connect")


@pytest.fixture
def out(tmp_path, monkeypatch):
    FakeSMTP.sent, FakeSMTP.fail_for = [], set()
    monkeypatch.setattr(smtplib, "SMTP", NoNetwork); monkeypatch.setattr(smtplib, "SMTP_SSL", NoNetwork)
    o = tmp_path / "outputs"
    (o / "reports").mkdir(parents=True)
    d = tmp_path / "data"; d.mkdir()
    (d / "distribution.json").write_text(json.dumps({"archive_base_url": "", "subject_prefix": "EconQuest", "subscribers": SUBS}))
    yield o
    for root, _dirs, files in os.walk(o):
        os.chmod(root, 0o755)
        for f in files:
            os.chmod(os.path.join(root, f), 0o644)


def data_of(out):
    return out.parent / "data"


def published(out, name="note", kind="country_note"):
    iid = reviewed(out, [write(out, name)], kind=kind)
    E.checklist(out, iid, "Alice", conflicts="no conflicts")
    E.checklist(out, iid, "Dave", compliance_approve=True)
    return E.publish(out, iid, "Carol")["item_id"]


def real_send(out, monkeypatch, **kw):
    monkeypatch.setattr(smtplib, "SMTP", FakeSMTP)
    kw.setdefault("confirm_new", "all-listed"); kw.setdefault("log", lambda m: None)
    return D.send(out, data_of(out), really_send=True, actor=kw.pop("actor", "Sam"), env=dict(ENV), keychain=lambda s: None, **kw)


# ---------------------------------------------------------------- config
def test_shipped_config_has_no_addresses_and_loads():
    raw = (ROOT / "data" / "distribution.json").read_text()
    assert "@" not in raw
    cfg = D.load_config(ROOT / "data")
    assert set(cfg["subscribers"]) == set(E.KINDS) and not any(cfg["subscribers"].values())


@pytest.mark.parametrize("bad, match", [
    ({"subscribers": {"country_note": ["a@example.com\r\nBcc: x@example.com"]}}, "line break"),
    ({"subscribers": {"country_note": ["Alice <a@example.com>"]}}, "plain email address"),
    ({"subscribers": {"country_note": ["a@example.com, b@example.com"]}}, "plain email address"),
    ({"subscribers": {"podcast": ["a@example.com"]}}, "product kinds"),
    ({"subject_prefix": "EQ\nBcc: x@example.com"}, "line break"),
    ({"archive_base_url": "http://archive.example.com/"}, "https"),
    ({"archive_base_url": "file:///etc/"}, "https"),
    ({"extra": 1}, "expected an object"),
])
def test_config_refuses_injection_and_bad_values(tmp_path, bad, match):
    (tmp_path / "distribution.json").write_text(json.dumps(bad))
    with pytest.raises(D.DistributionError, match=match):
        D.load_config(tmp_path)


def test_header_values_with_line_breaks_are_refused(out):
    iid = published(out)
    it = dict(E.get_item(out, iid)); it["meta"] = {**it["meta"], "as_of": "2026-10-22\r\nBcc: x@example.com"}
    with pytest.raises(D.DistributionError, match="header injection"):
        D.compose(out, it, D.load_config(data_of(out)))
    for s in ("a\nb", "a\rb", "a b", "a\x00b"):
        with pytest.raises(D.DistributionError):
            D.header_safe(s, "x")


# ---------------------------------------------------------------- published only
def test_only_published_items_are_queued(out):
    iid = reviewed(out, [write(out, "draft-only")])
    with pytest.raises(D.DistributionError, match="only a published item"):
        D.queue(out, iid)
    pid = published(out, "pub")
    assert D.queue(out, pid, actor="Carol")["queued"] and not D.queue(out, pid)["queued"]   # twice is a no-op
    assert [r["event"] for r in D.read_log(out)] == ["queue"]


def test_withdrawn_or_tampered_items_are_skipped(out, monkeypatch):
    a, b = published(out, "a"), published(out, "b")
    D.queue(out, a); D.queue(out, b)
    E.withdraw(out, a, "Carol", "error in table 2")
    d = out / E.get_item(out, b)["published_dir"]
    f = next(p for p in d.iterdir() if p.name != "manifest.json")
    os.chmod(d, 0o755); os.chmod(f, 0o644); f.write_text(f.read_text() + "tampered"); os.chmod(f, 0o444); os.chmod(d, 0o555)
    p = D.plan(out, data_of(out))
    assert p["messages"] == []
    reasons = {s["item_id"]: s["reason"] for s in p["skipped"]}
    assert "withdrawn" in reasons[a] and "does not verify" in reasons[b]


# ---------------------------------------------------------------- dry run / send
def test_dry_run_is_the_default_and_connects_nowhere(out, capsys):
    iid = published(out)
    D.queue(out, iid)
    rows = len(D.read_log(out))
    cli.main(["--data", str(data_of(out)), "--out", str(out), "distribute", "send"])
    o = capsys.readouterr().out
    assert o.count("DRY RUN would send") == 2 and "nothing sent (pass --send)" in o
    cli.main(["--data", str(data_of(out)), "--out", str(out), "distribute", "send", "--dry-run"])
    assert len(D.read_log(out)) == rows                                   # a dry run writes nothing


def test_send_needs_smtp_host(out):
    D.queue(out, published(out))
    with pytest.raises(D.DistributionError, match="ECONQUEST_SMTP_HOST"):
        D.send(out, data_of(out), really_send=True, env={}, log=lambda m: None)


def test_send_one_message_per_subscriber_with_archive_link_and_no_attachment(out, monkeypatch):
    cfgp = data_of(out) / "distribution.json"
    cfgp.write_text(json.dumps({"archive_base_url": "https://archive.example.com/eq", "subscribers": SUBS}))
    iid = published(out)
    D.queue(out, iid)
    r = real_send(out, monkeypatch)
    assert r["sent"] == 2 and r["failed"] == 0
    assert sorted(m["To"] for m in FakeSMTP.sent) == SUBS["country_note"]
    m = FakeSMTP.sent[0]
    rel = "/".join(Path(E.get_item(out, iid)["published_dir"]).parts[1:])
    body = m.get_content()
    assert f"https://archive.example.com/eq/{rel}/" in body and iid in m["Subject"]
    assert not m.is_multipart() and not list(m.iter_attachments())
    rows = [x for x in D.read_log(out) if x["event"] == "deliver"]
    assert {x["result"] for x in rows} == {"sent"} and all(isinstance(x["latency_s"], float) for x in rows)
    assert all(x["actor"] == "Sam" and x["config_sha256"] for x in rows)
    assert real_send(out, monkeypatch)["sent"] == 0                       # never sent twice
    assert D.verify(out)["ok"]


def test_failure_is_logged_masked_and_retried(out, monkeypatch):
    D.queue(out, published(out))
    FakeSMTP.fail_for = {"bob@example.com"}
    r = real_send(out, monkeypatch)
    assert r["sent"] == 1 and r["failed"] == 1
    bad = [x for x in D.read_log(out) if x["event"] == "deliver" and x["result"] != "sent"][0]
    assert bad["result"].startswith("error: SMTPRecipientsRefused") and "s3cret-pw-123" not in bad["result"]
    assert "***" in bad["result"]
    FakeSMTP.fail_for = set()
    assert real_send(out, monkeypatch)["sent"] == 1                       # only bob, again
    assert D.status(out, data_of(out))["pending"] == 0


def test_password_from_keychain_when_env_has_none(out, monkeypatch):
    env = {k: v for k, v in ENV.items() if k != "ECONQUEST_SMTP_PASSWORD"}
    assert D.smtp_password(env, keychain=lambda s: "kc-pw" if s == "econquest-smtp" else None) == "kc-pw"
    assert D.smtp_password(ENV, keychain=lambda s: "kc-pw") == ENV["ECONQUEST_SMTP_PASSWORD"]


def test_broken_chain_refuses_send(out, monkeypatch):
    D.queue(out, published(out))
    p = D.log_path(out)
    row = json.loads(p.read_text().splitlines()[0]); row["actor"] = "Mallory"         # edited row
    p.write_text(json.dumps(row) + "\n")
    assert not D.verify(out)["ok"]
    with pytest.raises(D.DistributionError, match="failed verification"):
        real_send(out, monkeypatch)
    D.head_path(out).write_text(json.dumps({"seq": 9, "row_hash": "0" * 64}))
    assert any("names seq 9" in e for e in D.verify(out)["errors"])


# ---------------------------------------------------------------- latency
def test_status_reports_product_and_alert_latency_p95(out, monkeypatch):
    D.queue(out, published(out))
    real_send(out, monkeypatch)
    t0 = dt.datetime(2026, 10, 23, 22, 0, tzinfo=dt.timezone.utc)
    for i, mins in enumerate([1, 2, 3, 4, 5, 6, 7, 8, 9, 30]):           # p95 (nearest rank, n=10) = 30 min
        al = {"kind": "missed_run", "threshold": t0.isoformat(), "key": f"missed_run:record:{i}"}
        D.log_alert_delivery(out, [al], {"webhook": "ok 200", "email": "not configured"}, now=t0 + dt.timedelta(minutes=mins))
    D.log_alert_delivery(out, [{"kind": "stale_feed", "key": "stale_feed:none"}], {"webhook": "ok"}, now=t0)
    D.log_alert_delivery(out, [{"kind": "job_failed", "key": "job_failed:x:2026-10-23T21:00:00+00:00"}],
                         {"webhook": "error: 500"}, now=t0)
    st = D.status(out, data_of(out))
    assert st["latency"]["alerts"] == {"n": 10, "p50_s": 300.0, "p95_s": 1800.0, "max_s": 1800.0}
    assert st["latency"]["products"]["n"] == 2 and st["sent"] == 2 and st["chain"]["ok"]
    text = "\n".join(D.format_status(st))
    assert "alerts delivery latency: n=10 p50 5.0 min p95 30.0 min" in text


def test_health_logs_alert_deliveries(out):
    now = dt.datetime(2026, 10, 23, 23, 30, tzinfo=dt.timezone.utc)
    last = {"record": {"status": "failed", "exit_code": 1, "ended_at": "2026-10-23T23:00:00+00:00"}}
    jd = out.parent / "outputs" / "logs" / "jobs"; jd.mkdir(parents=True)
    (jd / "record.last.json").write_text(json.dumps(last["record"]))
    health.run_health(data_of(out), out, now=now, log=lambda m: None,
                      deliver_fn=lambda alerts, s, env, **kw: {"webhook": "ok 200", "email": "skipped"})
    rows = [r for r in D.read_log(out) if r["event"] == "alert" and r["kind"] == "job_failed"]
    assert rows and rows[0]["latency_s"] == 1800.0 and rows[0]["recipient"] == "webhook"


# ---------------------------------------------------------------- CLI hook and action log
def test_editorial_publish_queues_and_send_is_logged_only_with_send(out, monkeypatch, capsys):
    iid = reviewed(out, [write(out)])
    E.checklist(out, iid, "Alice", conflicts="no conflicts"); E.checklist(out, iid, "Dave", compliance_approve=True)
    base = ["--data", str(data_of(out)), "--out", str(out)]
    cli.main([*base, "editorial", "publish", iid, "--publisher", "Carol"])
    assert "queued for distribution" in capsys.readouterr().out
    assert D.read_log(out)[0]["item_id"] == iid and D.read_log(out)[0]["actor"] == "Carol"
    from econquest.ops import actionlog as AL
    cli.main([*base, "distribute", "send"])
    assert "distribute send --send" not in [r["command"] for r in AL.read(out)]
    monkeypatch.setattr(smtplib, "SMTP", FakeSMTP)
    for k, v in ENV.items():
        monkeypatch.setenv(k, v)
    cli.main([*base, "distribute", "send", "--send", "--actor", "Sam", "--confirm-new", "all-listed"])
    assert len(FakeSMTP.sent) == 2
    row = AL.read(out)[-1]
    assert row["command"] == "distribute send --send" and row["actor"] == "Sam"
    assert "s3cret-pw-123" not in json.dumps(AL.read(out))
    cli.main([*base, "distribute", "status"])
    assert "sent: 2" in capsys.readouterr().out


# ---------------------------------------------------------------- SEC-C-005 (AGENT-09 review of EQ-C-0045)
@pytest.mark.parametrize("url", ["https://user:pw@archive.example.com/", "https://archive.example.com/eq?x=",
                                 "https://archive.example.com/eq#top"])
def test_archive_base_url_refuses_credentials_query_and_fragment(tmp_path, url):
    # the base URL is mailed to every subscriber: no user:password@, and no ?/# that would swallow the item path
    (tmp_path / "distribution.json").write_text(json.dumps({"archive_base_url": url}))
    with pytest.raises(D.DistributionError, match="plain https://host/path"):
        D.load_config(tmp_path)


@pytest.mark.parametrize("ch", ["\x0b", "\x0c", "\x1c", "\x1d", "\x1e"])
def test_every_line_boundary_is_refused_in_headers(tmp_path, ch):
    (tmp_path / "distribution.json").write_text(json.dumps({"subject_prefix": f"EQ{ch}Bcc: x@example.com"}))
    with pytest.raises(D.DistributionError, match="line break"):
        D.load_config(tmp_path)


@pytest.mark.parametrize("line", ["[]", "1", '"x"', "null"])
def test_non_object_log_line_is_reported_not_a_crash(out, monkeypatch, line):
    D.queue(out, published(out))
    p = D.log_path(out); p.write_text(p.read_text() + line + "\n")
    v = D.verify(out)
    assert not v["ok"] and any("not a JSON object" in e for e in v["errors"])
    assert not D.status(out, data_of(out))["chain"]["ok"]
    with pytest.raises(D.DistributionError, match="failed verification"):
        real_send(out, monkeypatch)


# ---------------------------------------------------------------- confirm once (EQ-C-0051, SEC-C-005 R4)
def test_new_addresses_are_withheld_until_confirmed_once(out, monkeypatch):
    D.queue(out, published(out))
    msgs = []
    r = real_send(out, monkeypatch, confirm_new="alice@example.com", log=msgs.append)
    assert r["sent"] == 1 and r["withheld"] == ["bob@example.com"] and r["confirmed"] == ["alice@example.com"]
    assert [m["To"] for m in FakeSMTP.sent] == ["alice@example.com"]
    assert any("WITHHELD new address bob@example.com" in m for m in msgs)
    conf = [x for x in D.read_log(out) if x["event"] == "confirm"]
    assert len(conf) == 1 and conf[0]["recipient"] == "alice@example.com" and conf[0]["actor"] == "Sam"
    assert conf[0]["config_sha256"] and conf[0]["ts_utc"] and D.verify(out)["ok"]
    r = real_send(out, monkeypatch, confirm_new=None)                     # still withheld without confirmation
    assert r["sent"] == 0 and r["withheld"] == ["bob@example.com"]
    r = real_send(out, monkeypatch, confirm_new="BOB@example.com")
    assert r["sent"] == 1 and r["confirmed"] == ["bob@example.com"]
    D.queue(out, published(out, "second"))                               # known addresses need no confirmation again
    r = real_send(out, monkeypatch, confirm_new=None)
    assert r["sent"] == 2 and r["withheld"] == [] and len([x for x in D.read_log(out) if x["event"] == "confirm"]) == 2


def test_dry_run_lists_addresses_needing_confirmation_and_records_nothing(out):
    D.queue(out, published(out))
    msgs = []
    r = D.send(out, data_of(out), log=msgs.append, confirm_new="alice@example.com")
    assert r["needs_confirmation"] == ["bob@example.com"]
    assert any("new address, --send would withhold it" in m and "bob@example.com" in m for m in msgs)
    assert not [x for x in D.read_log(out) if x["event"] == "confirm"]


@pytest.mark.parametrize("arg, match", [
    ("alice@example.com\r\nBcc: x@example.com", "line break"),
    ("Alice <alice@example.com>", "plain email address"),
    ("mallory@example.org", "not a subscriber"),
])
def test_confirm_argument_is_validated(out, monkeypatch, arg, match):
    D.queue(out, published(out))
    with pytest.raises(D.DistributionError, match=match):
        real_send(out, monkeypatch, confirm_new=arg)
    assert FakeSMTP.sent == [] and not [x for x in D.read_log(out) if x["event"] in ("confirm", "deliver")]


def test_confirmation_needs_an_actor(out, monkeypatch):
    D.queue(out, published(out))
    with pytest.raises(D.DistributionError, match="needs --actor"):
        real_send(out, monkeypatch, actor="", confirm_new="all-listed")
    assert FakeSMTP.sent == []


def test_cli_send_without_confirmation_withholds(out, monkeypatch, capsys):
    D.queue(out, published(out))
    monkeypatch.setattr(smtplib, "SMTP", FakeSMTP)
    for k, v in ENV.items():
        monkeypatch.setenv(k, v)
    base = ["--data", str(data_of(out)), "--out", str(out), "distribute", "send"]
    cli.main([*base])
    assert "would withhold it without --confirm-new: alice@example.com" in capsys.readouterr().out
    cli.main([*base, "--send", "--actor", "Sam"])
    o = capsys.readouterr().out
    assert FakeSMTP.sent == [] and "WITHHELD new address alice@example.com" in o and "2 new address(es) withheld" in o
    cli.main([*base, "--send", "--actor", "Sam", "--confirm-new", "alice@example.com,bob@example.com"])
    assert len(FakeSMTP.sent) == 2
