"""Debt sustainability and reserve adequacy (roadmap 3.1, 3.2)."""
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from econquest.config import Settings
from econquest.ingestion import load_universe
from econquest.engine import dsa as D

ROOT = Path(__file__).resolve().parents[1]; DATA = ROOT / "data"


def _synthetic_weo(iso="XXX", years=range(2000, 2032), d0=60.0, pb=-1.0, i=0.05, g=0.06):
    rows = []; d = d0
    for y in years:
        rows += [{"iso": iso, "series": "GGXONLB_NGDP", "period": y, "value": pb}, {"iso": iso, "series": "GGXCNL_NGDP", "period": y, "value": pb - i * d},
                 {"iso": iso, "series": "NGDP", "period": y, "value": 100 * (1 + g) ** (y - 2000)}, {"iso": iso, "series": "NGDP_RPCH", "period": y, "value": 3.0},
                 {"iso": iso, "series": "GGR_NGDP", "period": y, "value": 25.0}, {"iso": iso, "series": "NGDPD", "period": y, "value": 500.0}, {"iso": iso, "series": "PCPIPCH", "period": y, "value": 3.0}]
        d = d * (1 + i) / (1 + g) - pb + (0.5 if y % 3 == 0 else -0.5)
        rows.append({"iso": iso, "series": "GGXWDG_NGDP", "period": y, "value": d})
    return pd.DataFrame(rows)


def test_debt_history_recovers_dynamics():
    h = D.debt_history(_synthetic_weo(), "XXX")
    assert abs(h.loc[2010, "i_eff"] - 0.05) < 1e-6 and abs(h.loc[2010, "g_nom"] - 0.06) < 1e-9
    assert abs(abs(h.loc[2010, "sfa"]) - 0.5) < 1e-6


def test_fan_is_centred_on_weo_baseline_and_widens():
    h = D.debt_history(_synthetic_weo(), "XXX")
    r = D.stochastic_dsa(h, 2025, paths=4000, fx_share=0.3, fx_vol_pct=10)
    fan = r["fan"]
    assert np.allclose(fan["baseline_model"], fan["baseline_weo"], atol=1e-6)      # baseline sfa aligns the model to WEO
    assert (abs(fan["p50"] - fan["baseline_weo"]) < 3.0).all()
    assert (fan["p90"] - fan["p10"]).is_monotonic_increasing and 0 <= r["p_rising"] <= 1
    r2 = D.stochastic_dsa(h, 2025, paths=4000, fx_share=0.3, fx_vol_pct=10)
    pd.testing.assert_frame_equal(fan, r2["fan"])                                   # seeded


def test_reserve_adequacy_weights():
    inputs = pd.DataFrame([{"country": "X", "avg_maturity_yrs": 7, "st_external_debt_usd_bn": 10, "broad_money_pct_gdp": 50, "other_liabilities_usd_bn": 20, "usable_reserves_share": 0.5, "ara_applicable": "yes"}]).set_index("country")
    prof = pd.Series({"fxregime": "Float", "exports": 20.0})
    r = D.reserve_adequacy("X", prof, inputs, gdp_usd_bn=100.0, reserves_usd_bn=20.0)
    ara = 0.3 * 10 + 0.15 * 20 + 0.05 * 50 + 0.05 * 20
    assert abs(r["ara_metric_usd_bn"] - ara) < 1e-9 and abs(r["reserves_pct_ara"] - 10 / ara * 100) < 1e-9
    fixed = D.reserve_adequacy("X", pd.Series({"fxregime": "Peg", "exports": 20.0}), inputs, 100.0, 20.0)["ara_metric_usd_bn"]
    assert abs(fixed - (3 + 4 + 5 + 2)) < 1e-9
    assert np.isnan(D.reserve_adequacy("Y", prof, inputs, 100.0, 20.0)["reserves_pct_ara"])


def test_dsa_table_on_live_vintage_and_feeds(tmp_path):
    u = load_universe(DATA); s = Settings.load(DATA / "assumptions.json")
    weo = pd.read_csv(DATA / "live" / "raw_weo.csv"); wb = pd.read_csv(DATA / "live" / "raw_worldbank.csv")
    t, fans, diag = D.dsa_table(u, s, weo, wb, D.load_dsa_inputs(DATA / "dsa_inputs.csv"), year0=2025, paths=1000)
    assert len(t) >= 15 and set(D.DSA_COLUMNS) <= set(t.columns)
    assert t["p_debt_rising"].between(0, 1).all() and (t["debt_median_5y"] >= 0).all()
    assert t.set_index("country").loc["Japan", "reserves_pct_ara"] != t.set_index("country").loc["Japan", "reserves_pct_ara"]   # NaN: not applicable
    assert 30 < t.set_index("country").loc["Argentina", "reserves_pct_ara"] < 60
    # the derived scorecard inputs are emitted as proposed cells in the provenance.csv column layout
    f = D.scorecard_feeds(t, retrieved="2026-10-23")
    assert list(f.columns) == D.FEED_COLUMNS and list(f.columns[:7]) == ["table", "key", "country", "value", "source", "series", "retrieved"]
    assert len(f) > 0 and set(f["key"]) <= set(D.SCORECARD_FEEDS) and (f["retrieved"] == "2026-10-23").all() and (f["year0"] == 2025).all()
    assert not f.duplicated(["table", "key", "country"]).any() and np.isfinite(f["value"]).all()
    tt = t.set_index("country"); r0 = f.iloc[0]
    assert abs(tt.loc[r0["country"], D.SCORECARD_FEEDS[r0["key"]][0]] - r0["value"]) < 1e-3
    assert set(D.scorecard_feeds(t, retrieved="2026-10-23", keys=("2.1",))["key"]) == {"2.1"}
    with pytest.raises(ValueError):
        D.scorecard_feeds(t, retrieved="2026-10-23", keys=("9.9",))
    path = D.write_scorecard_feeds(f, tmp_path / "outputs")
    assert path == tmp_path / "outputs" / "dsa_scorecard_feeds.csv"
    back = pd.read_csv(path, dtype={"key": str})
    assert len(back) == len(f) and list(back.columns) == D.FEED_COLUMNS
    plan = D.dsa_plan(t, fans, "2026-10-23")
    assert plan[1]["range"].endswith("A4:Y4") and len(plan[2]["values"]) == len(t)


def test_dsa_does_not_write_team_a_files(tmp_path):
    """Regression (EQ-B-0010): apply_to_inputs used to rewrite indicators.csv, live/provenance.csv and live/review.csv."""
    import shutil, hashlib
    d = tmp_path / "data"; (d / "live").mkdir(parents=True)
    shutil.copy(DATA / "indicators.csv", d / "indicators.csv")
    (d / "live" / "provenance.csv").write_text("table,key,country,value,source,series,retrieved\n")
    before = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in d.rglob("*.csv")}
    t = pd.DataFrame([{"country": "Japan", "iso": "JPN", "year0": 2025, "debt_service_pct_revenue": 12.0,
                       "fx_debt_service_24m_pct_reserves": np.nan, "reserves_pct_ara": np.nan}])
    with pytest.raises(RuntimeError, match="scorecard_feeds"):
        D.apply_to_inputs(t, d, retrieved="2026-10-23")
    after = {p.name: hashlib.sha256(p.read_bytes()).hexdigest() for p in d.rglob("*.csv")}
    assert before == after and not (d / "live" / "review.csv").exists()
    f = D.scorecard_feeds(t, retrieved="2026-10-23")
    assert len(f) == 1 and f.iloc[0]["key"] == "1.1" and f.iloc[0]["value"] == 12.0


def test_year0_comes_from_explicit_inputs_not_the_clock():
    s = Settings.load(DATA / "assumptions.json")
    assert D.resolve_year0(s, year0=2023) == 2023
    assert D.resolve_year0(s, as_of="2031-03-01") == 2030
    s2 = s.copy_with(as_of="2029-12-31")
    assert D.resolve_year0(s2) == 2028                                   # the run's as-of date in settings
    assert D.resolve_year0(s2, as_of="2028-06-30") == 2027               # an explicit as_of wins over settings
