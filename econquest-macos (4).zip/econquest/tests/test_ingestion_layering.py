"""EQ-A-0001: ingestion and persistence are lower layers; they must not import presentation, engine or cli."""
import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "econquest"
FORBIDDEN = ("presentation", "engine", "cli")


def _imports(path: Path):
    for node in ast.walk(ast.parse(path.read_text())):
        if isinstance(node, ast.ImportFrom):
            yield (node.module or "")
        elif isinstance(node, ast.Import):
            yield from (a.name for a in node.names)


def test_lower_layers_do_not_import_upper_layers():
    bad = [f"{p.relative_to(ROOT.parent)}: {m}" for pkg in ("ingestion", "persistence") for p in sorted((ROOT / pkg).glob("*.py"))
           for m in _imports(p) if any(part in FORBIDDEN for part in m.split("."))]
    assert not bad, bad


def test_audit_plan_uses_neutral_cell_helper():
    import pandas as pd
    from econquest.ingestion.audit import audit_plan
    df = pd.DataFrame([{"table": "Inputs", "key": "1.1", "indicator": "x", "country": "A", "value": float("nan"), "origin": "live",
                        "source": "s", "series": "x", "transform": "", "retrieved": "", "gate_status": "ok", "gate_reason": "",
                        "decision": "", "seed_value": 1.0, "live_value": float("nan"), "robustness_rule": ""}])
    plan = audit_plan(df)
    assert any("" in row for blk in plan for row in blk["values"])   # NaN cleared to '' by common_format._v
