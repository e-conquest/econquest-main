"""EQ-A-0024: ACLED adapter, disabled by default and licence-gated. SYNTHETIC fixtures, mock fetcher, no network."""
import datetime as dt
import json
import urllib.parse
from pathlib import Path

import pytest

from econquest.ingestion.events.acled import (
    REDISTRIBUTION_NOTE, AcledAdapter, AcledDisabledError, UnmappedAcledCountryError, aggregate_monthly,
    save_acled_vintage,
)
from econquest.ingestion.events.base import EVENT_COLUMNS, RequestBudget, latest_events

FIX = Path(__file__).parent / "fixtures" / "events" / "acled"
NOW = dt.datetime(2026, 10, 23, 12, 0, 0, tzinfo=dt.timezone.utc)
ON = {"enabled": True, "licence": "ACLED corporate licence (SYNTHETIC test value)"}


class FakeAcled:
    def __init__(self):
        self.calls = []

    def __call__(self, url, headers, data=None):
        self.calls.append((url, dict(headers), data))
        parts = urllib.parse.urlsplit(url)
        assert parts.scheme == "https" and parts.hostname == "acleddata.com"
        if parts.path == "/oauth/token":
            assert data is not None and b"grant_type=password" in data
            return (FIX / "oauth_token.json").read_bytes()
        assert headers["Authorization"] == "Bearer synthetic-acled-token"
        q = dict(urllib.parse.parse_qsl(parts.query))
        return (FIX / f"read_page{q['page']}.json").read_bytes()


def _ad(config=ON, **kw):
    return AcledAdapter(config=config, limit=3, budget=RequestBudget(50), sleep=lambda s: None, now=NOW, **kw)


@pytest.fixture
def creds(monkeypatch):
    monkeypatch.delenv("ACLED_ACCESS_TOKEN", raising=False)
    monkeypatch.setenv("ACLED_USERNAME", "synthetic@example.org")
    monkeypatch.setenv("ACLED_PASSWORD", "synthetic-password")


def test_default_is_disabled_and_makes_no_network_call(tmp_path, creds):
    f = FakeAcled()
    with pytest.raises(AcledDisabledError, match="disabled"):
        AcledAdapter(data_dir=tmp_path).fetch(["NGA"], "2026-01-01", "2026-03-31", fetcher=f)
    with pytest.raises(AcledDisabledError, match="disabled"):
        AcledAdapter().fetch(["NGA"], "2026-01-01", "2026-03-31", fetcher=f)
    assert f.calls == []


@pytest.mark.parametrize("lic", ["none", "", None, "None"])
def test_enabled_without_licence_refuses(lic, creds):
    f = FakeAcled()
    with pytest.raises(AcledDisabledError, match="licence"):
        _ad({"enabled": True, "licence": lic}).fetch(["NGA"], "2026-01-01", "2026-03-31", fetcher=f)
    assert f.calls == []


def test_config_file_enables(tmp_path, creds):
    p = tmp_path / "live" / "events"
    p.mkdir(parents=True)
    (p / "feeds.json").write_text(json.dumps({"acled": ON}))
    ad = AcledAdapter(data_dir=tmp_path, limit=3, sleep=lambda s: None, now=NOW)
    assert ad.enabled and ad.licence == ON["licence"]


def test_fetch_oauth_pagination_and_metrics(creds):
    f = FakeAcled()
    ad = _ad()
    df = ad.fetch(["NGA"], "2026-01-01", "2026-03-31", fetcher=f)
    assert [urllib.parse.urlsplit(u).path for u, _, _ in f.calls] == ["/oauth/token", "/api/acled/read", "/api/acled/read"]
    assert list(df.columns) == EVENT_COLUMNS
    assert (df["licence"] == ON["licence"]).all() and (df["source"] == "acled").all()
    v = df.set_index(["period", "metric"])["value"]
    assert v["2026-01-01", "events_protest"] == 1 and v["2026-01-01", "events_riot"] == 1
    assert v["2026-01-01", "fatalities"] == 2 and v["2026-01-01", "events_total"] == 2
    assert v["2026-02-01", "events_total"] == 0                       # zero-filled month
    assert v["2026-03-01", "events_violence_civilians"] == 1 and v["2026-03-01", "events_abductions"] == 1
    assert v["2026-03-01", "events_battles"] == 1 and v["2026-03-01", "fatalities"] == 5
    assert len(ad.raw_rows) == 4
    assert ad.provenance()["licence"] == ON["licence"]


def test_ready_token_skips_oauth(monkeypatch):
    monkeypatch.setenv("ACLED_ACCESS_TOKEN", "synthetic-acled-token")
    f = FakeAcled()
    _ad().fetch(["NGA"], "2026-01-01", "2026-03-31", fetcher=f)
    assert all("/oauth/" not in u for u, _, _ in f.calls)


def test_missing_credentials_error(monkeypatch):
    for k in ("ACLED_ACCESS_TOKEN", "ACLED_USERNAME", "ACLED_PASSWORD"):
        monkeypatch.delenv(k, raising=False)
    f = FakeAcled()
    with pytest.raises(RuntimeError, match="credentials missing"):
        _ad().fetch(["NGA"], "2026-01-01", "2026-03-31", fetcher=f)
    assert f.calls == []


def test_save_writes_aggregates_only_by_default(tmp_path, creds):
    ad = _ad()
    df = ad.fetch(["NGA"], "2026-01-01", "2026-03-31", fetcher=FakeAcled())
    v = save_acled_vintage(tmp_path, df, ad, now=NOW)
    assert v.parent == tmp_path / "live" / "events" / "acled" / "vintages"
    assert sorted(p.name for p in v.iterdir()) == ["events.csv", "manifest.json"]
    man = json.loads((v / "manifest.json").read_text())
    assert man["licence"] == ON["licence"] and man["provenance"]["raw_included"] is False
    assert man["provenance"]["redistribution"] == REDISTRIBUTION_NOTE
    text = (v / "manifest.json").read_text() + (v / "events.csv").read_text()
    assert "SYN0001" not in text and "synthetic-password" not in text and "synthetic-acled-token" not in text
    assert len(latest_events(tmp_path, "acled")) == len(df)


def test_save_raw_only_with_flag_and_inside_acled_folder(tmp_path, creds):
    ad = _ad()
    df = ad.fetch(["NGA"], "2026-01-01", "2026-03-31", fetcher=FakeAcled())
    v = save_acled_vintage(tmp_path, df, ad, include_raw=True, now=NOW)
    assert (v / "raw_acled.csv").exists() and "SYN0001" in (v / "raw_acled.csv").read_text()
    written = [p for p in tmp_path.rglob("*") if p.is_file()]
    assert all((tmp_path / "live" / "events" / "acled") in p.parents for p in written)


def test_unmapped_numeric_iso_is_an_error():
    rows = [{"event_date": "2026-01-01", "event_type": "Protests", "iso": "999", "country": "Atlantis", "fatalities": "0"}]
    with pytest.raises(UnmappedAcledCountryError, match="Atlantis"):
        aggregate_monthly(rows, ["NGA"], dt.date(2026, 1, 1), dt.date(2026, 1, 31), "t", "lic")


def test_country_without_events_is_not_zero_filled():
    df = aggregate_monthly([], ["SGP"], dt.date(2026, 1, 1), dt.date(2026, 3, 31), "t", "lic")
    assert df.empty and list(df.columns) == EVENT_COLUMNS


# ------------------------------------------------------------------------------------------- SEC-A-002 regressions

import email  # noqa: E402
import io  # noqa: E402
import urllib.request  # noqa: E402
import urllib.response  # noqa: E402

from econquest.ingestion.events import base as _base  # noqa: E402
from econquest.ingestion.events.acled import acled_ready  # noqa: E402


@pytest.mark.parametrize("val", ["false", "true", "False", 1, "yes", None])
def test_enabled_must_be_json_true(val, creds):
    f = FakeAcled()
    ad = _ad({"enabled": val, "licence": ON["licence"]})
    assert ad.enabled is False
    with pytest.raises(AcledDisabledError, match="disabled"):
        ad.fetch(["NGA"], "2026-01-01", "2026-03-31", fetcher=f)
    assert f.calls == []
    assert acled_ready({"enabled": val, "licence": ON["licence"]})[0] is False


@pytest.mark.parametrize("lic", ["pending", "PENDING", " none ", True, 1, ["x"], "=HYPERLINK(\"x\")", "@x", "+x", "-x",
                                 "\tx", "ACLED\nlicence"])
def test_licence_must_be_a_plain_non_placeholder_string(lic, creds):
    f = FakeAcled()
    with pytest.raises(AcledDisabledError, match="licence"):
        _ad({"enabled": True, "licence": lic}).fetch(["NGA"], "2026-01-01", "2026-03-31", fetcher=f)
    assert f.calls == []


@pytest.mark.parametrize("key", ["token_env", "username_env", "password_env"])
@pytest.mark.parametrize("bad", ["AWS_SECRET_ACCESS_KEY", "UCDP_API_TOKEN", "acled_token", "HOME"])
def test_credential_env_names_must_be_acled_variables(key, bad):
    with pytest.raises(ValueError, match="not allowed"):
        _ad({**ON, key: bad})


def test_request_budget_is_persisted_across_restarts(tmp_path, creds):
    p = tmp_path / "live" / "events"
    p.mkdir(parents=True)
    (p / "feeds.json").write_text(json.dumps({"acled": {**ON, "daily_request_limit": 4}}))
    ad = AcledAdapter(data_dir=tmp_path, limit=3, sleep=lambda s: None, now=NOW)
    assert ad.budget.state_path == tmp_path / "live" / "events" / "acled" / "request_budget.json"
    ad.fetch(["NGA"], "2026-01-01", "2026-03-31", fetcher=FakeAcled())          # 3 requests
    again = AcledAdapter(data_dir=tmp_path, limit=3, sleep=lambda s: None, now=NOW)
    assert again.budget.used() == 3 and again.budget.remaining() == 1


def test_bearer_token_not_sent_on_redirect_through_default_fetcher(monkeypatch):
    """End to end through base.http_fetch: the read URL answers 302 to http://evil.example."""
    monkeypatch.setenv("ACLED_ACCESS_TOKEN", "SECRET-ACLED-TOKEN")
    seen = []

    def respond(req):
        seen.append((req.full_url, {k.lower(): v for k, v in req.header_items()}))
        if urllib.parse.urlsplit(req.full_url).hostname == "acleddata.com":
            code, hdrs = 302, "Location: http://evil.example/steal\n"
        else:
            code, hdrs = 200, ""
        resp = urllib.response.addinfourl(io.BytesIO(b'{"data": []}'), email.message_from_string(hdrs),
                                          req.full_url, code)
        resp.msg = "stub"
        return resp

    class Https(urllib.request.HTTPSHandler):
        def https_open(self, req):
            return respond(req)

    class Http(urllib.request.HTTPHandler):
        def http_open(self, req):
            return respond(req)

    orig = _base.build_no_redirect_opener
    monkeypatch.setattr(_base, "build_no_redirect_opener", lambda *h: orig(Https, Http))
    with pytest.raises(_base.FetchError, match="redirect from acleddata.com/api/acled/read; not followed"):
        _ad(retries=0).fetch(["NGA"], "2026-01-01", "2026-03-31")
    assert {urllib.parse.urlsplit(u).hostname for u, _ in seen} == {"acleddata.com"}
    assert not any("SECRET" in v for u, h in seen if "evil" in u for v in h.values())
