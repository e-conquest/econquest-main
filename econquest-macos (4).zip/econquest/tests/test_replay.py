"""EQ-A-0007: point-in-time replay. apply_report(vintage_id=...) freezes the full Team A input set; materialize_vintage
rebuilds a data directory from it (verified hashes); load_universe(vintage=...) loads the frozen values."""
import json
import os
import shutil
import stat
import sys
from pathlib import Path

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(Path(__file__).resolve().parent))
from econquest.ingestion import load_universe  # noqa: E402
from econquest.ingestion.feeds import apply_report, save_vintage  # noqa: E402
from econquest.ingestion.replay import (VintageIntegrityError, freeze_inputs, materialize_vintage,  # noqa: E402
                                        snapshot_path, verify_snapshot)
from econquest.versioning import data_hash  # noqa: E402
from test_vintages import CLOCK, _report  # noqa: E402

SEED = ROOT / "tests" / "seed_data"


def _data(tmp_path: Path) -> Path:
    d = tmp_path / "data"
    shutil.copytree(SEED, d)
    (d / "market_history").mkdir(); (d / "market_history" / "prices.csv").write_text("date,VND\n2026-10-22,25300\n2026-10-23,25310\n")
    (d / "panel").mkdir(); (d / "panel" / "hazard_panel.csv").write_text("iso,year,default\nVNM,2020,0\n")
    (d / "live").mkdir(); (d / "live" / "live_inputs.csv").write_text(",Vietnam\n1.3,36.5\n")
    return d


def _vn(u) -> float:
    return float(u.indicators.set_index("id").at["1.3", "Vietnam"])


def _applied(tmp_path):
    d = _data(tmp_path)
    v = save_vintage(d, _report(), now=CLOCK)
    out = apply_report(_report(), d, now=CLOCK, vintage_id=v.name)
    return d, v.name, out


def test_apply_freezes_inputs_and_replay_returns_frozen_values(tmp_path):
    d, vid, out = _applied(tmp_path)
    snap = Path(out["inputs_snapshot"])
    assert snap == d / "live" / "snapshots" / f"{vid}-inputs" == snapshot_path(d, vid)
    m = json.loads((snap / "manifest.json").read_text())
    assert set(m["files"]) == {"indicators.csv", "countries.csv", "market_history/prices.csv", "panel/hazard_panel.csv", "live/live_inputs.csv"}
    assert "assumptions.json" in m["not_frozen_by_team_a"] and "rulebook.csv" in m["not_frozen_by_team_a"]
    assert all(stat.S_IMODE(p.stat().st_mode) == 0o444 for p in snap.rglob("*") if p.is_file())
    h0 = data_hash(d); assert m["data_hash"] == h0
    assert _vn(load_universe(d)) == 36.5
    # mutate the live inputs after the run
    ind = pd.read_csv(d / "indicators.csv", dtype={"id": str}); ind.loc[ind["id"] == "1.3", "Vietnam"] = 99.0; ind.to_csv(d / "indicators.csv", index=False)
    with open(d / "market_history" / "prices.csv", "a") as f:
        f.write("2026-10-24,25400\n")
    (d / "live" / "raw_new.csv").write_text("iso,series\nVNM,x\n")
    assert _vn(load_universe(d)) == 99.0 and data_hash(d) != h0
    for vin in (vid, "2026-10-24"):                             # full id, or the day's latest
        u = load_universe(d, vintage=vin)
        assert _vn(u) == 36.5 and len(u.prices) == 2
        assert u.provenance["versions"]["data_hash"] == h0     # the replay reproduces the frozen data hash
        assert u.provenance["replay"]["vintage_id"] == vid and u.provenance["replay"]["drift"] == []
        v = u.provenance["versions"]                            # EQ-A-0013: run stamp carries the replay (versioning.with_replay)
        assert v["vintage_id"] == vid and v["inputs_hash"] == u.provenance["replay"]["inputs_hash"] and v.get("run_hash")


def test_materialize_twice_is_identical(tmp_path):
    d, vid, _ = _applied(tmp_path)
    (d / "indicators.csv").write_text((d / "indicators.csv").read_text().replace("36.5", "40.0"))
    a = materialize_vintage(d, vid, tmp_path / "a"); b = materialize_vintage(d, vid, tmp_path / "b")
    assert a["files"] == b["files"] and a == b
    assert data_hash(tmp_path / "a") == data_hash(tmp_path / "b") == a["frozen_data_hash"]
    assert not (tmp_path / "a" / "live" / "vintages").exists() and not (tmp_path / "a" / "live" / "snapshots").exists()
    assert (tmp_path / "a" / "assumptions.json").read_bytes() == (d / "assumptions.json").read_bytes()
    with pytest.raises(FileExistsError):                        # never writes into a non-empty folder
        materialize_vintage(d, vid, tmp_path / "a")


def test_tampered_snapshot_fails_verification(tmp_path):
    d, vid, out = _applied(tmp_path)
    snap = Path(out["inputs_snapshot"])
    f = snap / "indicators.csv"; os.chmod(f, 0o644); f.write_text(f.read_text().replace("36.5", "36.6"))
    with pytest.raises(VintageIntegrityError, match="hash mismatch indicators.csv"):
        materialize_vintage(d, vid, tmp_path / "out")
    with pytest.raises(VintageIntegrityError):
        load_universe(d, vintage=vid)
    # rewriting the manifest to match is caught by the snapshots index
    m = json.loads((snap / "manifest.json").read_text())
    import hashlib
    m["files"]["indicators.csv"] = hashlib.sha256(f.read_bytes()).hexdigest()
    from econquest.ingestion.replay import _inputs_hash
    m["inputs_hash"] = _inputs_hash(m["files"])
    os.chmod(snap / "manifest.json", 0o644); (snap / "manifest.json").write_text(json.dumps(m))
    verify_snapshot(snap)                                       # self-consistent on its own ...
    with pytest.raises(VintageIntegrityError, match="index"):
        verify_snapshot(snap, d)                                # ... but not against the index


def test_unfrozen_vintage_fails_loudly_and_refreeze_is_append_only(tmp_path):
    d = _data(tmp_path)
    v = save_vintage(d, _report(), now=CLOCK)
    with pytest.raises(FileNotFoundError, match="no frozen input snapshot"):
        load_universe(d, vintage=v.name)
    with pytest.raises(FileNotFoundError):
        freeze_inputs(d, "2026-01-01")
    s1 = freeze_inputs(d, v.name, now=CLOCK)
    assert freeze_inputs(d, v.name, now=CLOCK) == s1           # same files: reused
    (d / "panel" / "hazard_panel.csv").write_text("iso,year,default\nVNM,2021,0\n")
    s2 = freeze_inputs(d, v.name, now=CLOCK)
    assert s2.name == f"{v.name}-inputs-1" and snapshot_path(d, v.name) == s2
    assert json.loads((s1 / "manifest.json").read_text())["files"] != json.loads((s2 / "manifest.json").read_text())["files"]


def test_other_team_drift_is_reported(tmp_path):
    d, vid, _ = _applied(tmp_path)
    a = json.loads((d / "assumptions.json").read_text()); a["_replay_test"] = 1; (d / "assumptions.json").write_text(json.dumps(a))
    rm = materialize_vintage(d, vid, tmp_path / "out")
    assert rm["drift"] == ["assumptions.json"] and rm["drift_in_data_hash"] == ["assumptions.json"]
    assert data_hash(tmp_path / "out") != rm["frozen_data_hash"]


def test_wb_history_and_events_long_are_frozen_and_replayed(tmp_path):
    """EQ-A-0028: Universe.wb_raw (live/raw_worldbank_history.csv) and Universe.events (live/events/events_long.csv)
    come back from the freeze, not from the files as they are now."""
    from econquest.ingestion.events.export import LONG_COLUMNS, LONG_PATH
    from econquest.ingestion.replay import TEAM_A_RUN_INPUTS, is_team_a_input
    assert all(is_team_a_input(r) for r in TEAM_A_RUN_INPUTS)
    d = _data(tmp_path)
    wb = d / "live" / "raw_worldbank_history.csv"
    wb.write_text("iso,series,period,value,source\nVNM,PV.EST,2024,0.1,fake\n")
    ev = d / LONG_PATH; ev.parent.mkdir(parents=True)
    pd.DataFrame([["VNM", "ucdp_ged", "events", "M", "2026-08-01", 3, "2026-10-23", "t"]], columns=LONG_COLUMNS).to_csv(ev, index=False)
    v = save_vintage(d, _report(), now=CLOCK)
    out = apply_report(_report(), d, now=CLOCK, vintage_id=v.name)
    m = json.loads((Path(out["inputs_snapshot"]) / "manifest.json").read_text())
    assert {"live/raw_worldbank_history.csv", "live/events/events_long.csv"} <= set(m["files"])
    wb.write_text("iso,series,period,value,source\nVNM,PV.EST,2024,-2.0,fake\n")
    ev.write_text(ev.read_text().replace(",3,", ",30,"))
    now = load_universe(d)
    assert float(now.wb_raw["value"].iloc[0]) == -2.0 and float(now.events["value"].iloc[0]) == 30
    u = load_universe(d, vintage=v.name)
    assert float(u.wb_raw["value"].iloc[0]) == 0.1 and float(u.events["value"].iloc[0]) == 3
    assert u.provenance["wb_raw"] == "csv:live/raw_worldbank_history.csv" and u.provenance["events"]
