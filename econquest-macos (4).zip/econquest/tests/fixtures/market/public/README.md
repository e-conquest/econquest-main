# SYNTHETIC fixtures (EQ-A-0030)

Every number in this folder is invented for tests. The files only copy the response *shapes* of the FRED API
(`fred_dgs.json`, one response per series id), ALFRED vintages (`alfred_dgs10.json`) and the ECB Data Portal
SDMX-CSV for the YC dataflow (`ecb_yc.csv`, extra NOTE column). They are not market data and must never be
saved to `data/`.
