"""SYNTHETIC event-data fixture for EQ-B-0033 (event stress index). NOT UCDP or GDELT data.

Generates tables in the input contract of HO-20261023-B-A-004 (iso, source, series, freq, period, value,
vintage, provenance) from a seeded random generator, with planted stress episodes. Every row carries
provenance PROVENANCE so it cannot be mistaken for a real pull. Also generates synthetic default starts and
spread paths for the backtest harness. Numbers here are made up to exercise the code; they are evidence of
nothing about the real world.
"""
from __future__ import annotations
import numpy as np
import pandas as pd

PROVENANCE = "SYNTHETIC fixture EQ-B-0033 - not UCDP/GDELT data"


def _shock_profile(days: pd.DatetimeIndex, shocks, iso: str) -> np.ndarray:
    m = np.zeros(len(days))
    for s_iso, start, months, intensity, *_ in shocks:
        if s_iso != iso:
            continue
        a = pd.Timestamp(start); b = a + pd.DateOffset(months=int(months))
        m[(days >= a) & (days < b)] += float(intensity)
    return m


def synthetic_events(isos, start="2015-01-01", end="2026-10-23", shocks=(), seed=0) -> pd.DataFrame:
    """Daily GDELT-like rows and monthly UCDP-like rows (candidate every month, final GED once the year is
    'released' the following 15 June). `shocks` = [(iso, start, months, intensity)]: intensity 1 raises event
    and fatality rates and lowers Goldstein and tone by about one to two trailing standard deviations."""
    rng = np.random.default_rng(seed)
    days = pd.date_range(start, end, freq="D")
    months = pd.date_range(pd.Timestamp(start).replace(day=1), end, freq="MS")
    months = months[(months + pd.offsets.MonthEnd(0)) <= pd.Timestamp(end)]
    out = []
    for iso in isos:
        lam_gd = rng.uniform(20, 200); g_mu = rng.uniform(-2.0, 1.0); t_mu = rng.uniform(-4.0, -1.0)
        lam_uc = rng.uniform(0.5, 15.0)
        md = _shock_profile(days, shocks, iso)
        ev = rng.poisson(lam_gd * (1 + 0.6 * md))
        gs = g_mu - 1.0 * md + rng.normal(0, 0.4, len(days))
        tn = t_mu - 1.0 * md + rng.normal(0, 0.5, len(days))
        vint = days + pd.Timedelta(days=1)
        for series, val in (("events", ev.astype(float)), ("goldstein_mean", gs), ("tone_mean", tn)):
            out.append(pd.DataFrame({"iso": iso, "source": "gdelt", "series": series, "freq": "D", "period": days,
                                     "value": val, "vintage": vint}))
        mm = _shock_profile(months, shocks, iso)
        ue = rng.poisson(lam_uc * (1 + 1.5 * mm)).astype(float)
        uf = rng.poisson(np.maximum(ue, 0) * 2.5 * (1 + 0.8 * mm)).astype(float)
        cand_v = months + pd.offsets.MonthEnd(0) + pd.Timedelta(days=25)
        ged_v = pd.to_datetime([f"{y + 1}-06-15" for y in months.year])
        for series, val in (("events", ue), ("fatalities", uf)):
            noise = rng.integers(-1, 2, len(months)).astype(float)    # candidate revised slightly in the final GED
            out.append(pd.DataFrame({"iso": iso, "source": "ucdp_candidate", "series": series, "freq": "M",
                                     "period": months, "value": np.maximum(val + noise, 0), "vintage": cand_v}))
            keep = ged_v <= pd.Timestamp(end)
            out.append(pd.DataFrame({"iso": iso, "source": "ucdp_ged", "series": series, "freq": "M",
                                     "period": months[keep], "value": val[keep], "vintage": ged_v[keep]}))
    df = pd.concat(out, ignore_index=True)
    df["provenance"] = PROVENANCE
    df["period"] = df["period"].dt.strftime("%Y-%m-%d"); df["vintage"] = pd.to_datetime(df["vintage"]).dt.strftime("%Y-%m-%d")
    return df


def synthetic_defaults(shocks, lead_months=6, extra=()) -> pd.DataFrame:
    """Default starts `lead_months` after each shock whose 5th field is True, plus `extra` [(iso, date)]
    starts with no preceding shock. Columns iso, start, start_date, end (sovereign_defaults.csv shape)."""
    rows = []
    for sh in shocks:
        if len(sh) > 4 and sh[4]:
            d = pd.Timestamp(sh[1]) + pd.DateOffset(months=lead_months)
            rows.append({"iso": sh[0], "start": d.year, "start_date": d.strftime("%Y-%m-%d"), "end": d.year})
    for iso, d in extra:
        d = pd.Timestamp(d)
        rows.append({"iso": iso, "start": d.year, "start_date": d.strftime("%Y-%m-%d"), "end": d.year})
    return pd.DataFrame(rows, columns=["iso", "start", "start_date", "end"])


def synthetic_spreads(isos, shocks, start="2015-01-01", end="2026-10-23", lag_days=60, jump_bps=150.0, seed=1) -> pd.DataFrame:
    """Weekly spread levels (bps): a random walk plus a persistent `jump_bps` widening, ramped over a month
    starting `lag_days` after each shock start."""
    rng = np.random.default_rng(seed)
    dates = pd.date_range(start, end, freq="W-FRI")
    out = []
    for iso in isos:
        lvl = rng.uniform(100, 600) + np.cumsum(rng.normal(0, 8, len(dates)))
        for s_iso, s0, _months, intensity, *_ in shocks:
            if s_iso == iso:
                a = pd.Timestamp(s0) + pd.Timedelta(days=lag_days)
                ramp = np.clip((dates - a).days / 30.0, 0, 1)        # the widening persists (no reversion)
                lvl = lvl + jump_bps * float(intensity) * ramp
        out.append(pd.DataFrame({"iso": iso, "date": dates, "value": lvl}))
    return pd.concat(out, ignore_index=True)
