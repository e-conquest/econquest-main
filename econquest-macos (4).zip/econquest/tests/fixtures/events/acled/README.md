# SYNTHETIC ACLED fixtures (EQ-A-0024) - not ACLED data

Invented rows in the shape of ACLED's `/api/acled/read` reply (`data` list) and OAuth token reply, used only by
`tests/test_events_acled.py` with a mock fetcher (page size 3: page 1 is full, page 2 is short). Event ids start
`SYN`; the token is not a real credential. Field names follow ACLED's documentation as read for the spike
*(verify against the first licensed pull)*. ACLED licence terms forbid redistributing real ACLED rows, so never
replace these with real data.
