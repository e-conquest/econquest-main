# SYNTHETIC UCDP fixtures (EQ-A-0022) - not UCDP data

Every file here is invented for tests. Event ids 9000xx/9001xx, counts and dates are made up. Never use them for
analysis or treat them as UCDP output. Rows carry `vintage_id = SYNTHETIC-FIXTURE` and
`licence = SYNTHETIC TEST DATA - not UCDP`.

| File | What it is |
|---|---|
| `ged_page1.json`, `ged_page2.json` | Two pages of the UCDP API response shape (`TotalCount`, `TotalPages`, `NextPageUrl`, `Result`) for GED version 26.1: 5 events, Nigeria (GW 475) and Colombia (GW 100), 2025. Field names follow the GED codebook as read for the spike *(verify against the first live pull)*. |
| `candidate_page1.json` | One page of the Candidate (26.0.9) shape: 2 events in February 2026. |
| `events.csv` | The normalised `EVENT_COLUMNS` table that `ucdp.events_from_api_pages` produces from the three pages above for NGA and COL, coverage 2025-01..2025-12 (GED) and 2026-01..2026-02 (Candidate), zero-filled. |
| `events_monthly_2019_2026_synthetic.csv` | A longer deterministic series for indicator work (6.9 needs 12 months plus a 5-year base): NGA, COL and SGP, monthly 2019-01..2026-02, all eight UCDP metrics. Month index i from 0 at 2019-01: state-based = base + i mod 3 (base NGA 10, COL 4), plus 20 for NGA from 2025-03 (a synthetic escalation); non-state = i mod 2; one-sided = 1 + (i mod 4 == 0); fatalities 3x/2x/4x those counts. SGP is all zero. |

Contract: `econquest/ingestion/events/base.py` (`EVENT_COLUMNS`, `validate_events`).
