# SYNTHETIC GDELT fixtures (EQ-A-0023)

Every row here is hand-written test data, not GDELT data. Actor names start with `SYNTHETIC`, source URLs
point at `example.invalid`, and the masterfilelist md5/sizes describe these fixture zips only.

- `<ts>.export.CSV` / `<ts>.export.CSV.zip`: the real GDELT 2.0 event export layout (61 tab-separated
  columns, no header); only the columns `econquest/ingestion/events/gdelt.py` uses are filled meaningfully.
  Cases: a protest and a material-conflict event in Nigeria (FIPS `NI`), a non-root event, Niger (`NG`,
  unmapped), a blank ActionGeo code, a duplicate GlobalEventID across two files, Singapore (`SN`), Senegal
  (`SG`), the US (`US`, unmapped) and a late-reported Philippines (`RP`) event whose SQLDATE is 2026-10-01.
- `masterfilelist.txt`: index lines for the three zips (plus mentions lines that must be ignored).
- `fips_iso3_override.csv`: an override map example (`NG` -> `NER`).
- `events.csv`: the normalised output (EVENT_COLUMNS) for 2026-10-20..21, all 18 desk countries, root
  events, file-date basis, `retrieved_utc` fixed at 2026-10-23T06:00:00Z. Team B can build on its shape;
  the numbers mean nothing.
