"""EQ-A-0022: UCDP adapter and the shared event contract. All inputs are SYNTHETIC fixtures (tests/fixtures/events/ucdp);
no network is used."""
import datetime as dt
import json
import os
import stat
import urllib.parse
from pathlib import Path

import pandas as pd
import pytest

from econquest.ingestion.events import base
from econquest.ingestion.events.base import (
    EVENT_COLUMNS, BudgetExceededError, EventDataError, RequestBudget, TransientFetchError, latest_events,
    list_event_vintages, load_event_config, save_event_vintage, validate_events,
)
from econquest.ingestion.events.ucdp import (
    TOKEN_HEADER, UcdpAdapter, UnmappedCountryError, events_from_api_pages, load_country_map, map_countries,
)

FIX = Path(__file__).parent / "fixtures" / "events" / "ucdp"
NOW = dt.datetime(2026, 10, 23, 12, 0, 0, tzinfo=dt.timezone.utc)


def _page(name):
    return (FIX / name).read_bytes()


class FakeUcdp:
    """Routes UCDP URLs to the synthetic pages and records every call."""

    def __init__(self, pagesize_pages=None, fail_first=0):
        self.calls, self.fail_first = [], fail_first

    def __call__(self, url, headers, data=None):
        self.calls.append((url, dict(headers)))
        if self.fail_first:
            self.fail_first -= 1
            raise TransientFetchError("HTTP 503 from synthetic")
        parts = urllib.parse.urlsplit(url)
        q = dict(urllib.parse.parse_qsl(parts.query))
        assert parts.scheme == "https" and parts.hostname == "ucdpapi.pcr.uu.se"
        if parts.path.endswith("/26.1"):
            return _page(f"ged_page{int(q['page']) + 1}.json")
        if parts.path.endswith("/26.0.9"):
            return _page("candidate_page1.json")
        raise AssertionError(url)


@pytest.fixture
def token(monkeypatch):
    monkeypatch.setenv("UCDP_API_TOKEN", "synthetic-token")


def _adapter(tmp_path, **kw):
    kw.setdefault("budget", RequestBudget(100))
    return UcdpAdapter(data_dir=tmp_path, sleep=lambda s: None, now=NOW, **kw)


def test_fetch_paginates_and_matches_normalised_fixture(tmp_path, token):
    f = FakeUcdp()
    df = _adapter(tmp_path).fetch(["NGA", "COL"], "2025-01-01", "2026-03-31", fetcher=f)
    pages = [dict(urllib.parse.parse_qsl(urllib.parse.urlsplit(u).query))["page"] for u, _ in f.calls]
    assert pages == ["0", "1", "0"]                                   # GED 2 pages, then Candidate 1 page
    assert all(h[TOKEN_HEADER] == "synthetic-token" for _, h in f.calls)
    assert list(df.columns) == EVENT_COLUMNS
    exp = pd.read_csv(FIX / "events.csv", dtype=str, keep_default_na=False)
    got = df.astype({"value": str}).copy()
    key = ["iso", "period", "metric"]
    m = got.merge(exp, on=key, suffixes=("", "_x"))
    assert len(m) == len(exp) == len(df)
    assert (m["value"].astype(float) == m["value_x"].astype(float)).all()
    # Candidate coverage ends at the latest event month (Feb 2026): March is not zero-filled
    assert df["period"].max() == "2026-02-01"


def test_aggregation_by_type_of_violence(tmp_path, token):
    df = _adapter(tmp_path).fetch(["NGA", "COL"], "2025-01-01", "2026-03-31", fetcher=FakeUcdp())
    v = df.set_index(["iso", "period", "metric"])["value"]
    assert v["NGA", "2025-01-01", "events_state_based"] == 1
    assert v["NGA", "2025-01-01", "events_one_sided"] == 1
    assert v["NGA", "2025-01-01", "events_total"] == 2
    assert v["NGA", "2025-01-01", "fatalities_best"] == 16
    assert v["NGA", "2025-01-01", "fatalities_state_based"] == 12
    assert v["COL", "2025-03-01", "events_non_state"] == 1
    assert v["COL", "2025-03-01", "events_state_based"] == 1
    assert v["COL", "2025-03-01", "fatalities_best"] == 5
    assert v["NGA", "2025-11-01", "events_state_based"] == 1          # event spanning Nov-Dec counts in its start month
    assert v["NGA", "2025-12-01", "events_total"] == 0                # zero-filled inside coverage
    assert v["NGA", "2026-02-01", "fatalities_one_sided"] == 5


def test_missing_token_refuses_before_any_request(tmp_path, monkeypatch):
    monkeypatch.delenv("UCDP_API_TOKEN", raising=False)
    f = FakeUcdp()
    with pytest.raises(RuntimeError, match="UCDP_API_TOKEN"):
        _adapter(tmp_path).fetch(["NGA"], "2025-01-01", "2025-12-31", fetcher=f)
    assert f.calls == []


def test_unmapped_country_in_response_is_an_error(tmp_path, token):
    def fetcher(url, headers, data=None):
        doc = json.loads(_page("candidate_page1.json"))
        doc["Result"].append({"id": 999, "type_of_violence": 1, "country": "Atlantis", "country_id": 9999,
                              "date_start": "2026-02-01", "best": 1})
        doc["TotalCount"] = 3
        return json.dumps(doc).encode()
    with pytest.raises(UnmappedCountryError, match="Atlantis"):
        _adapter(tmp_path).fetch(["NGA"], "2026-01-01", "2026-03-31", fetcher=fetcher)


def test_unmapped_requested_iso_fails_before_fetch(tmp_path, token):
    f = FakeUcdp()
    with pytest.raises(UnmappedCountryError, match="FRA"):
        _adapter(tmp_path).fetch(["NGA", "FRA"], "2025-01-01", "2025-12-31", fetcher=f)
    assert f.calls == []


def test_id_name_conflict_is_an_error():
    by_id, by_name = load_country_map()
    with pytest.raises(UnmappedCountryError, match="different ISO3"):
        map_countries([{"country_id": 475, "country": "Colombia"}], by_id, by_name)


def test_override_csv_extends_map(tmp_path, token):
    p = tmp_path / "live" / "events" / "ucdp"
    p.mkdir(parents=True)
    (p / "country_map.csv").write_text("ucdp_id,ucdp_name,iso\n9999,Atlantis,ATL\n")
    by_id, by_name = load_country_map(p / "country_map.csv")
    assert by_id[9999] == "ATL" and by_name["atlantis"] == "ATL"
    (p / "country_map.csv").write_text("ucdp_id,ucdp_name,iso\n9999,Atlantis,atlantis\n")
    with pytest.raises(ValueError, match="ISO3"):
        load_country_map(p / "country_map.csv")


def test_retries_then_succeeds_and_budget_counts_errors(tmp_path, token):
    b = RequestBudget(100)
    f = FakeUcdp(fail_first=2)
    UcdpAdapter(data_dir=tmp_path, budget=b, sleep=lambda s: None, now=NOW).fetch(
        ["NGA", "COL"], "2025-01-01", "2025-12-31", fetcher=f)
    assert len(f.calls) == 4 and b.used() == 4                       # 2 failures + 2 pages


def test_budget_guard_stops_before_sending(tmp_path, token):
    f = FakeUcdp()
    with pytest.raises(BudgetExceededError):
        UcdpAdapter(data_dir=tmp_path, budget=RequestBudget(1), sleep=lambda s: None, now=NOW).fetch(
            ["NGA", "COL"], "2025-01-01", "2025-12-31", fetcher=f)
    assert len(f.calls) == 1


def test_budget_persists_per_utc_day(tmp_path):
    day = [dt.date(2026, 10, 23)]
    p = tmp_path / "b.json"
    RequestBudget(5, p, today=lambda: day[0]).spend(3)
    assert RequestBudget(5, p, today=lambda: day[0]).used() == 3
    day[0] = dt.date(2026, 10, 24)
    assert RequestBudget(5, p, today=lambda: day[0]).remaining() == 5


def test_totalcount_mismatch_is_an_error(tmp_path, token):
    def fetcher(url, headers, data=None):
        doc = json.loads(_page("candidate_page1.json"))
        doc["TotalCount"] = 7
        return json.dumps(doc).encode()
    with pytest.raises(EventDataError, match="TotalCount"):
        _adapter(tmp_path).fetch(["NGA"], "2026-01-01", "2026-03-31", fetcher=fetcher)


def test_http_fetch_refuses_plain_http():
    with pytest.raises(ValueError, match="non-https"):
        base.http_fetch("http://ucdpapi.pcr.uu.se/api/gedevents/26.1")


def test_validate_rejects_contract_breaks():
    good = pd.read_csv(FIX / "events.csv", dtype=str, keep_default_na=False)
    assert len(validate_events(good)) == len(good)
    for col, val, msg in [("iso", "NG", "ISO3"), ("freq", "W", "freq"), ("source", "foo", "source"),
                          ("metric", "Bad-Metric", "snake_case"), ("value", "inf", "non-finite"),
                          ("period", "2025-01-15", "start of"), ("period", "2025/01/01", "YYYY-MM-DD")]:
        bad = good.copy()
        bad.loc[0, col] = val
        with pytest.raises(EventDataError, match=msg):
            validate_events(bad)
    with pytest.raises(EventDataError, match="duplicate"):
        validate_events(pd.concat([good, good.head(1)]))
    with pytest.raises(EventDataError, match="missing columns"):
        validate_events(good.drop(columns=["licence"]))


def test_vintage_append_only_read_only_and_latest(tmp_path, token):
    ad = _adapter(tmp_path)
    df = ad.fetch(["NGA", "COL"], "2025-01-01", "2026-03-31", fetcher=FakeUcdp())
    v = save_event_vintage(tmp_path, df, "ucdp", now=NOW, provenance=ad.provenance())
    assert v.parent == tmp_path / "live" / "events" / "ucdp" / "vintages"
    for name in ("events.csv", "manifest.json"):
        assert stat.S_IMODE(os.stat(v / name).st_mode) == 0o444
    man = json.loads((v / "manifest.json").read_text())
    assert man["licence"] == "CC BY 4.0" and man["rows"] == len(df)
    assert {d["version"] for d in man["provenance"]["datasets"]} == {"26.1", "26.0.9"}
    assert "synthetic-token" not in (v / "manifest.json").read_text()
    with pytest.raises(FileExistsError):                              # same content, same second: never overwritten
        save_event_vintage(tmp_path, df, "ucdp", now=NOW)
    later = save_event_vintage(tmp_path, df[df["iso"] == "NGA"], "ucdp", now=NOW + dt.timedelta(seconds=5))
    assert list_event_vintages(tmp_path, "ucdp") == [v.name, later.name]
    lat = latest_events(tmp_path, "ucdp")
    assert set(lat["iso"]) == {"NGA"} and (lat["vintage_id"] == later.name).all()
    idx = pd.read_csv(v.parent / "index.csv")
    assert list(idx["vintage_id"]) == [v.name, later.name]


def test_latest_events_without_vintage_fails_loudly(tmp_path):
    with pytest.raises(FileNotFoundError, match="no ucdp event vintage"):
        latest_events(tmp_path, "ucdp")


def test_tampered_vintage_detected(tmp_path):
    df = pd.read_csv(FIX / "events.csv", dtype=str, keep_default_na=False)
    df["licence"] = "CC BY 4.0"
    v = save_event_vintage(tmp_path, df, "ucdp", now=NOW)
    os.chmod(v / "events.csv", 0o644)
    (v / "events.csv").write_text((v / "events.csv").read_text().replace(",12.0,", ",13.0,", 1))
    with pytest.raises(EventDataError, match="sha256"):
        latest_events(tmp_path, "ucdp")


def test_config_defaults_and_refuses_secrets(tmp_path):
    cfg = load_event_config(tmp_path)
    assert cfg["ucdp"] == {"enabled": True, "token_env": "UCDP_API_TOKEN"}
    assert cfg["acled"]["enabled"] is False and cfg["acled"]["licence"] == "none"
    p = tmp_path / "live" / "events"
    p.mkdir(parents=True)
    (p / "feeds.json").write_text(json.dumps({"ucdp": {"ged_version": "25.1"}}))
    cfg = load_event_config(tmp_path)
    assert cfg["ucdp"]["ged_version"] == "25.1" and cfg["ucdp"]["token_env"] == "UCDP_API_TOKEN"
    (p / "feeds.json").write_text(json.dumps({"ucdp": {"token": "abc"}}))
    with pytest.raises(ValueError, match="secret"):
        load_event_config(tmp_path)


def test_disabled_ucdp_refuses(tmp_path, token):
    p = tmp_path / "live" / "events"
    p.mkdir(parents=True)
    (p / "feeds.json").write_text(json.dumps({"ucdp": {"enabled": False}}))
    f = FakeUcdp()
    with pytest.raises(RuntimeError, match="disabled"):
        _adapter(tmp_path).fetch(["NGA"], "2025-01-01", "2025-12-31", fetcher=f)
    assert f.calls == []


def test_long_synthetic_fixture_is_contract_valid():
    df = pd.read_csv(FIX / "events_monthly_2019_2026_synthetic.csv", dtype=str, keep_default_na=False)
    out = validate_events(df, source="ucdp")
    assert set(out["iso"]) == {"NGA", "COL", "SGP"}
    assert (out["vintage_id"] == "SYNTHETIC-FIXTURE").all()


def test_offline_helper_equals_fixture():
    pages = [json.loads(_page(n)) for n in ("ged_page1.json", "ged_page2.json", "candidate_page1.json")]
    df = events_from_api_pages(pages, ["NGA", "COL"], [("2025-01-01", "2025-12-31"), ("2026-01-01", "2026-02-28")],
                               "2026-10-23T00:00:00Z")
    assert len(df) == len(pd.read_csv(FIX / "events.csv"))


# ------------------------------------------------------------------------------------------- SEC-A-002 regressions
# No external network: urllib handlers are stubbed (StubWire) or two local http.server instances on 127.0.0.1 are used.

import email  # noqa: E402
import http.server  # noqa: E402
import io  # noqa: E402
import threading  # noqa: E402
import urllib.error  # noqa: E402
import urllib.request  # noqa: E402
import urllib.response  # noqa: E402

from econquest.ingestion.events.base import FetchError, http_fetch  # noqa: E402


class StubWire:
    """Stands in for the network inside a urllib opener. routes: url -> (code, extra headers, body[, final url]).
    Records every request that reaches the 'wire' with the headers urllib would send."""

    def __init__(self, routes):
        self.routes, self.seen = routes, []
        wire = self

        class Https(urllib.request.HTTPSHandler):
            def https_open(self, req):
                return wire.respond(req)

        class Http(urllib.request.HTTPHandler):
            def http_open(self, req):
                return wire.respond(req)

        self.handlers = (Https, Http)

    def respond(self, req):
        self.seen.append((req.full_url, {k.lower(): v for k, v in req.header_items()}))
        code, hdrs, body, *final = self.routes.get(req.full_url, (404, {}, b""))
        msg = email.message_from_string("".join(f"{k}: {v}\n" for k, v in hdrs.items()))
        resp = urllib.response.addinfourl(io.BytesIO(body), msg, final[0] if final else req.full_url, code)
        resp.msg = "stub"
        return resp

    def hosts(self):
        return [urllib.parse.urlsplit(u).hostname for u, _ in self.seen]


def wire(monkeypatch, routes):
    w = StubWire(routes)
    orig = base.build_no_redirect_opener
    monkeypatch.setattr(base, "build_no_redirect_opener", lambda *h: orig(*w.handlers))
    return w


UCDP_URL = "https://ucdpapi.pcr.uu.se/api/gedevents/26.1?page=0&pagesize=1000"


@pytest.mark.parametrize("code", [301, 302, 303, 307, 308])
@pytest.mark.parametrize("hdr", [{TOKEN_HEADER: "SECRET-TOKEN"}, {"Authorization": "Bearer SECRET-TOKEN"}])
@pytest.mark.parametrize("target", ["http://evil.example/x", "https://evil.example/x", "http://ucdpapi.pcr.uu.se/x"])
def test_http_fetch_refuses_redirect_and_never_sends_token_on(monkeypatch, code, hdr, target):
    w = wire(monkeypatch, {UCDP_URL: (code, {"Location": target}, b"")})
    with pytest.raises(FetchError, match=rf"HTTP {code} redirect from ucdpapi.pcr.uu.se/api/gedevents/26.1; not followed") as e:
        http_fetch(UCDP_URL, hdr)
    assert "SECRET" not in str(e.value) and "page=" not in str(e.value)
    assert [u for u, _ in w.seen] == [UCDP_URL]                       # nothing reached the redirect target
    assert all("SECRET" not in v for u, h in w.seen[1:] for v in h.values())


def test_http_fetch_sends_headers_unredirected_and_returns_body(monkeypatch):
    w = wire(monkeypatch, {UCDP_URL: (200, {}, b'{"ok": 1}')})
    seen_req = []
    orig = base.build_request
    monkeypatch.setattr(base, "build_request", lambda *a: seen_req.append(orig(*a)) or seen_req[-1])
    assert http_fetch(UCDP_URL, {TOKEN_HEADER: "SECRET-TOKEN"}) == b'{"ok": 1}'
    req = seen_req[0]
    assert req.unredirected_hdrs.get("X-ucdp-access-token") == "SECRET-TOKEN" and not req.headers
    assert w.seen[0][1]["x-ucdp-access-token"] == "SECRET-TOKEN"


@pytest.mark.parametrize("final", ["http://ucdpapi.pcr.uu.se/api/x", "https://evil.example/api/x"])
def test_http_fetch_refuses_response_from_another_url(monkeypatch, final):
    wire(monkeypatch, {UCDP_URL: (200, {}, b"{}", final)})
    with pytest.raises(FetchError, match="refused"):
        http_fetch(UCDP_URL, {TOKEN_HEADER: "SECRET-TOKEN"})


def test_ucdp_fetch_through_http_fetch_refuses_redirect(monkeypatch, tmp_path, token):
    w = StubWire({})
    w.routes = _AnyUrl(302, {"Location": "http://evil.example/steal"})
    orig = base.build_no_redirect_opener
    monkeypatch.setattr(base, "build_no_redirect_opener", lambda *h: orig(*w.handlers))
    with pytest.raises(FetchError, match="redirect"):
        _adapter(tmp_path, retries=0).fetch(["NGA"], "2025-01-01", "2025-12-31")
    assert set(w.hosts()) == {"ucdpapi.pcr.uu.se"}


class _AnyUrl(dict):
    def __init__(self, code, hdrs):
        super().__init__()
        self.v = (code, hdrs, b"")

    def get(self, k, default=None):
        return self.v


def test_no_redirect_opener_against_local_servers():
    """Real sockets on 127.0.0.1: server A answers 302 to server B; B must never be contacted."""
    hits = {"a": [], "b": []}

    def handler(name, location=None):
        class H(http.server.BaseHTTPRequestHandler):
            def do_GET(self):
                hits[name].append(dict(self.headers))
                self.send_response(302 if location else 200)
                if location:
                    self.send_header("Location", location)
                self.send_header("Content-Length", "0")
                self.end_headers()

            def log_message(self, *a):
                pass
        return H

    b = http.server.HTTPServer(("127.0.0.1", 0), handler("b"))
    a = http.server.HTTPServer(("127.0.0.1", 0), handler("a", f"http://127.0.0.1:{b.server_port}/steal"))
    threads = [threading.Thread(target=s.serve_forever, daemon=True) for s in (a, b)]
    for t in threads:
        t.start()
    try:
        req = base.build_request(f"http://127.0.0.1:{a.server_port}/api", {TOKEN_HEADER: "SECRET-TOKEN"})
        opener = base.build_no_redirect_opener(urllib.request.ProxyHandler({}))
        with pytest.raises(urllib.error.HTTPError) as e:
            opener.open(req, timeout=5)
        e.value.close()
        assert e.value.code == 302
        assert len(hits["a"]) == 1 and hits["a"][0].get("X-Ucdp-Access-Token") == "SECRET-TOKEN"
        assert hits["b"] == []
    finally:
        for s in (a, b):
            s.shutdown()
            s.server_close()


@pytest.mark.parametrize("cfg", [
    {"ucdp": {"api_token": "x"}}, {"ucdp": {"ucdp_token": "x"}}, {"acled": {"Authorization": "Bearer x"}},
    {"acled": {"creds": [{"password": "x"}]}}, {"acled": {"bearer": "x"}}, {"acled": {"ApiKey": "x"}},
    {"acled": {"api_key": "x"}}, {"acled": {"extra": [[{"client_secret": "x"}]]}}, {"ucdp": {"Passwd": "x"}},
])
def test_config_secret_keys_refused_at_any_depth(tmp_path, cfg):
    p = tmp_path / "live" / "events"
    p.mkdir(parents=True)
    (p / "feeds.json").write_text(json.dumps(cfg))
    with pytest.raises(ValueError, match="secret"):
        load_event_config(tmp_path)


def test_config_env_keys_allowed_only_for_feed_variables(tmp_path):
    p = tmp_path / "live" / "events"
    p.mkdir(parents=True)
    ok = {"ucdp": {"token_env": "UCDP_TOKEN_2"},
          "acled": {"token_env": "ACLED_T", "username_env": "ACLED_U", "password_env": "ACLED_P"}}
    (p / "feeds.json").write_text(json.dumps(ok))
    assert load_event_config(tmp_path)["acled"]["password_env"] == "ACLED_P"
    for bad in ("AWS_SECRET_ACCESS_KEY", "HOME", "ucdp_token", "UCDP_", "UCDP_X\n", 5, None):
        (p / "feeds.json").write_text(json.dumps({"ucdp": {"token_env": bad}}))
        with pytest.raises(ValueError, match="not allowed"):
            load_event_config(tmp_path)


def test_ucdp_token_env_must_be_a_ucdp_variable(tmp_path, monkeypatch):
    monkeypatch.setenv("AWS_SECRET_ACCESS_KEY", "aws-secret")
    for bad in ("AWS_SECRET_ACCESS_KEY", "ACLED_ACCESS_TOKEN"):
        with pytest.raises(ValueError, match="not allowed"):
            UcdpAdapter(token_env=bad)
    assert UcdpAdapter(token_env="UCDP_OTHER").token_env == "UCDP_OTHER"


@pytest.mark.parametrize("val", ["false", "true", "False", 1, "yes", None])
def test_ucdp_enabled_must_be_json_true(tmp_path, token, val):
    p = tmp_path / "live" / "events"
    p.mkdir(parents=True)
    (p / "feeds.json").write_text(json.dumps({"ucdp": {"enabled": val}}))
    f = FakeUcdp()
    with pytest.raises(RuntimeError, match="disabled"):
        _adapter(tmp_path).fetch(["NGA"], "2025-01-01", "2025-12-31", fetcher=f)
    assert f.calls == []


def _one(**over):
    row = {"iso": "NGA", "period": "2024-01-01", "freq": "M", "source": "ucdp", "metric": "events_total", "value": 1.0,
           "vintage_id": "", "retrieved_utc": "2026-10-23T12:00:00Z", "licence": "CC BY 4.0"}
    row.update(over)
    return pd.DataFrame([row])


@pytest.mark.parametrize("over", [
    {"iso": "NGA\n"}, {"period": "2024-01-01\n"}, {"metric": "events_total\n"},
    {"licence": '=HYPERLINK("http://evil.example")'}, {"licence": "+1"}, {"licence": "-x"}, {"licence": "@SUM(A1)"},
    {"licence": "\tCC"}, {"licence": "\rCC"}, {"licence": "CC BY\n=1"},
    {"retrieved_utc": "2026-10-23"}, {"retrieved_utc": "2026-10-23T12:00:00Z\n"}, {"retrieved_utc": "now"},
])
def test_validate_events_fullmatch_licence_and_retrieved(over):
    validate_events(_one())                                            # the base row is valid
    validate_events(_one(retrieved_utc=""))                            # blank before save is allowed
    with pytest.raises(EventDataError):
        validate_events(_one(**over))
