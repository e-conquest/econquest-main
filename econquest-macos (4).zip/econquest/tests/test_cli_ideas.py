"""econquest ideas log|mark|report and the run/record hooks (EQ-C-0043, HO-20261023-B-C-010). Real data/ (read only),
temp --out; no network."""
import re
from pathlib import Path

import pandas as pd
import pytest

from econquest import cli
from econquest.engine import garch
from econquest.validation import idea_log, record

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
AS_OF = "2026-10-23"
LINE = re.compile(r"^\[ideas\] 2026-10-23: (\d+) ideas \(\d+ open, \d+ closed\), \d+ marked, \d+% unmarked; P&L -?\d+\.\d{3} \$mm$", re.M)


def main(out, *argv):
    cli.main(["--data", str(DATA), "--out", str(out), *argv])


@pytest.fixture(scope="module")
def ran(tmp_path_factory):
    """One base run plus one stress scenario into a temp --out."""
    out = tmp_path_factory.mktemp("ideas") / "outputs"
    main(out, "run", "--paths", "2000", "--as-of", AS_OF, "--no-paths", "--stress", "--scenario", "A", "--stress-paths", "500")
    return out


def log_rows(out):
    return pd.read_csv(out / "idea_log.csv")


def test_run_logs_base_ideas_only(ran):
    lg = log_rows(ran)
    assert len(lg) > 0 and lg["idea_id"].is_unique
    assert lg["run_id"].str.endswith("-base").all()                     # the stress run wrote nothing to the log
    assert (ran / "idea_report.md").exists() and (ran / "idea_report.csv").exists()


def test_ideas_log_is_idempotent_and_prints_the_line(ran, capsys):
    n = len(log_rows(ran))
    main(ran, "ideas", "log")
    m = LINE.search(capsys.readouterr().out)
    assert m and int(m.group(1)) == n
    main(ran, "ideas", "log")
    assert len(log_rows(ran)) == n


def test_same_day_rerun_adds_no_duplicates(ran, tmp_path):
    out = tmp_path / "outputs"
    main(out, "run", "--paths", "2000", "--as-of", AS_OF, "--no-paths")
    n = len(log_rows(out))
    main(out, "run", "--paths", "2000", "--as-of", AS_OF, "--no-paths")
    lg = log_rows(out)
    assert len(lg) == n and lg["idea_id"].is_unique and lg["run_id"].nunique() == 1   # re-fires never duplicate


def test_ideas_log_refuses_stress_and_bad_ids(ran):
    stress = next(p.stem for p in (ran / "store" / "archive").glob("*-stress-A.json"))
    with pytest.raises(SystemExit, match="stress run"):
        main(ran, "ideas", "log", "--run-id", stress)
    for bad in ("../x", "/etc/passwd", ".hidden"):
        with pytest.raises(SystemExit, match="not a run id"):
            main(ran, "ideas", "log", "--run-id", bad)
    with pytest.raises(SystemExit, match="not archived"):
        main(ran, "ideas", "log", "--run-id", "20000101T000000-base")


def test_ideas_log_without_runs(tmp_path):
    with pytest.raises(SystemExit, match="No base run archived"):
        main(tmp_path / "outputs", "ideas", "log")


def test_ideas_mark_as_of_and_default_day(ran, monkeypatch, capsys):
    main(ran, "ideas", "mark", "--as-of", AS_OF)
    assert f"marked to {AS_OF}" in capsys.readouterr().out
    seen = []
    real = idea_log.mark_log
    monkeypatch.setattr(idea_log, "mark_log", lambda out, px, as_of, s: seen.append(as_of) or real(out, px, as_of, s, log=lambda *_: None))
    main(ran, "ideas", "mark")
    px = garch.load_prices(DATA)
    assert seen == [record.complete_date(record._weekdays(px))]           # the trading day the forecast record uses


def test_ideas_mark_without_prices(ran, monkeypatch):
    monkeypatch.setattr(garch, "load_prices", lambda d: None)
    with pytest.raises(SystemExit, match="No price history"):
        main(ran, "ideas", "mark")


def test_ideas_report(ran, tmp_path, capsys):
    main(ran, "ideas", "report")
    assert capsys.readouterr().out.startswith("# Trade-idea log report")
    with pytest.raises(SystemExit, match="ideas log"):
        main(tmp_path / "none", "ideas", "report")


def test_run_survives_an_idea_log_failure(tmp_path, monkeypatch, capsys):
    def boom(*a, **k):
        raise ValueError("bad log")
    monkeypatch.setattr(idea_log, "log_run", boom)
    out = tmp_path / "outputs"
    main(out, "run", "--paths", "2000", "--as-of", AS_OF, "--no-paths")
    assert "trade-idea log not updated by run: ValueError: bad log" in capsys.readouterr().err
    assert (out / "run_latest.json").exists()


@pytest.fixture
def fake_record(monkeypatch):
    marks = []
    day = pd.Timestamp("2026-10-21")
    monkeypatch.setattr(record, "take_record", lambda u, s, px, d, run_mc=True: {"date": day})
    monkeypatch.setattr(record, "backfill_record", lambda *a, **k: None)
    monkeypatch.setattr(idea_log, "mark_log", lambda out, px, as_of, s: marks.append((Path(out), as_of)))
    return marks, day


def test_record_marks_the_log_to_the_record_date(fake_record, tmp_path):
    marks, day = fake_record
    main(tmp_path / "outputs", "record", "--no-mc")
    assert marks == [(tmp_path / "outputs", day)]


def test_record_backfill_does_not_mark(fake_record, tmp_path):
    marks, _ = fake_record
    main(tmp_path / "outputs", "record", "--backfill", "5")
    assert marks == []
