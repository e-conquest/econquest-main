"""EQ-B-0004 / GOV-030: signals and trade activations are carried by every run and kept per run_id.

Regression pins are on the October 2026 seed snapshot at as_of 2026-10-23 (signal 25 depends on the
contract horizons, so the date is fixed; see EQ-B-0001). Signals 15 and 19 and the trades keyed on
them (T16, T17) are not pinned while EQ-B-0008 (signal 19 saturation) is in progress.

docs/validation/signals-trades.md ("Outputs and how they are used") lists firing counts that no longer
reproduce on either dataset and covers only 64 of the trade firings (T01, T04, T09, T16, T19, T23 are
not listed; the run has 75 on seed data). Where the doc and the seed run disagree the pin follows the run
and the doc value is noted in the comment; the doc needs regenerating from a recorded run."""
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.config import Settings
from econquest.ingestion import load_universe
from econquest.engine import run_pipeline
from econquest.engine.signals import SIGNAL_NAMES, compute_signals, trade_activation
from econquest.persistence.store import Store

SEED = ROOT / "tests" / "seed_data"
AS_OF = "2026-10-23"

# countries with signal >= 60 (threshold), seed data, as_of 2026-10-23
SIGNAL_COUNTS = {1: 10, 2: 7,   # doc 6
                 3: 5, 4: 3, 5: 5, 6: 8,   # doc 6
                 7: 0, 8: 3, 9: 1, 10: 7, 11: 3, 12: 3, 13: 3, 14: 6, 16: 4, 17: 0, 18: 5, 20: 2,
                 21: 7,   # doc 8
                 22: 6, 23: 18, 24: 0, 25: 9}
# countries where each trade fires
TRADE_COUNTS = {"T01": 3, "T02": 3, "T03": 4, "T04": 1, "T05": 0,
                "T06": 5,   # doc 6
                "T07": 4,   # doc 3
                "T08": 0, "T09": 1, "T10": 0, "T11": 7, "T12": 3, "T13": 3, "T14": 3, "T15": 6, "T18": 3, "T19": 4,
                "T20": 6,   # doc 7
                "T21": 0, "T22": 4, "T23": 1, "T24": 0, "T25": 0, "T26": 9}


@pytest.fixture(scope="module")
def run():
    u = load_universe(SEED); s = Settings.load(SEED / "assumptions.json")
    return u, s, run_pipeline(u, s, paths=1000, as_of=AS_OF)


def test_run_result_carries_signals_and_activation(run):
    u, _, r = run
    assert r.signals is not None and r.activation is not None
    assert list(r.signals.index) == list(SIGNAL_NAMES) and list(r.signals.columns) == u.names
    assert list(r.activation.index) == list(u.playbook["id"]) and list(r.activation.columns) == u.names
    assert r.signals.notna().all().all() and ((r.signals >= 0) & (r.signals <= 100)).all().all()
    fired = r.activation.stack().dropna()
    assert len(fired) and ((fired >= 0) & (fired <= 100)).all()


def test_signals_match_direct_compute(run):
    """The run's tables are exactly what compute_signals / trade_activation return on the run's own inputs."""
    u, s, r = run
    sig = compute_signals(u, s, r.scorecard, r.country, r.gpr_country, r.gpr_global, r.arbitrage)
    pd.testing.assert_frame_equal(sig, r.signals)
    pd.testing.assert_frame_equal(trade_activation(u, u.playbook, sig), r.activation)


def test_signal_and_trade_counts_pinned(run):
    _, s, r = run
    thr = s["signals"]["threshold"]
    counts = (r.signals >= thr).sum(axis=1).to_dict()
    assert {k: counts[k] for k in SIGNAL_COUNTS} == SIGNAL_COUNTS
    fires = r.activation.notna().sum(axis=1).to_dict()
    assert {k: fires[k] for k in TRADE_COUNTS} == TRADE_COUNTS
    assert r.activation["Pakistan"].notna().sum() == 10     # doc: Pakistan 10


def test_signals_serialised_and_archived_per_run(run, tmp_path):
    u, _, r = run
    d = r.to_dict()
    assert len(d["signals"]) == len(SIGNAL_NAMES) and set(d["signals"][0]) == {"key", *u.names}
    assert len(d["activation"]) == len(u.playbook) and set(d["activation"][0]) == {"trade", *u.names}
    store = Store(tmp_path / "store"); rid = store.save_run(r, keep_paths=False)
    back = store.load(rid)
    sig = pd.DataFrame(back["signals"]).set_index("key")
    np.testing.assert_allclose(sig.loc[list(SIGNAL_NAMES), u.names].to_numpy(dtype=float), r.signals.to_numpy(dtype=float))
    act = pd.DataFrame(back["activation"]).set_index("trade")[u.names].astype(float)
    assert (act.notna().to_numpy() == r.activation.notna().to_numpy()).all()
    assert back["settings"]["as_of"] == AS_OF


def test_no_signals_without_playbook(run):
    u, s, _ = run
    import dataclasses
    r = run_pipeline(dataclasses.replace(u, playbook=None), s, paths=500, as_of=AS_OF)
    assert r.signals is None and r.activation is None and r.to_dict()["signals"] is None


def test_run_dict_names_signals_and_carries_pillars(run, tmp_path):
    # EQ-B-0030 (HO-20261023-A-B-006, HO-20261023-C-B-007): the store gets signal names without importing the engine,
    # and country notes read pillar scores from the run
    run = run[2]
    d = run.to_dict()
    assert d["signal_names"] == {int(k): SIGNAL_NAMES[int(k)] for k in run.signals.index}
    assert set(d["pillars"]) == set(run.country.index)
    first = next(iter(d["pillars"].values()))
    assert set(first) == set(run.scorecard.pillar_final.index)
    store = Store(tmp_path / "store"); store.save_run(run, keep_paths=False)
    s = store.signals()
    assert len(s) == run.signals.size and s["signal_name"].notna().all()
    assert (s["signal_name"] == s["signal_key"].astype(int).map(SIGNAL_NAMES)).all()
