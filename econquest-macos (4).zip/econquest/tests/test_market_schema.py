"""EQ-A-0029: market data contract, point-in-time snapshot store and the engine adapter (to_cds_quotes).
All quotes here are SYNTHETIC (tests/fixtures/market/quotes_sample.csv)."""
import datetime as dt
import os
from pathlib import Path

import pandas as pd
import pytest

from econquest.engine import cds
from econquest.ingestion.market.schema import (CDS_QUOTES_COLUMNS, KEY, MARKET_COLUMNS, MarketDataError,
                                               to_cds_quotes, validate_market)
from econquest.ingestion.market.store import (latest_market, list_market_snapshots, market_history,
                                              read_market_snapshot, save_market_snapshot, snapshot_root)

FIX = Path(__file__).parent / "fixtures" / "market" / "quotes_sample.csv"
NOW = dt.datetime(2026, 10, 21, 8, 0, tzinfo=dt.timezone.utc)
NAMES = {"BRA": "Brazil", "ARG": "Argentina", "USA": "United States"}


def sample():
    return pd.read_csv(FIX, dtype=str, keep_default_na=False)


def test_fixture_is_valid_and_labelled_synthetic():
    m = validate_market(sample())
    assert list(m.columns) == MARKET_COLUMNS
    assert set(m["source"]) == {"synthetic"} and m["licence"].str.contains("synthetic").all()
    assert m["tenor_y"].dtype == float and m["derived"].dtype == bool


@pytest.mark.parametrize("col,val,msg", [
    ("instrument", "bond", "instrument not in"),
    ("field", "px_last", "field not in"),
    ("iso", "BR", "iso not ISO3"),
    ("iso", "bra", "iso not ISO3"),
    ("iso", "BRAZ", "iso not ISO3"),
    ("currency", "usd", "currency not ISO 4217"),
    ("asof", "2026-13-01", "asof not a YYYY-MM-DD"),
    ("asof", "20/10/2026", "asof not a YYYY-MM-DD"),
    ("tenor_y", "5y", "tenor_y not a number"),
    ("tenor_y", "-1", "tenor_y not a number"),
    ("value", "inf", "non-finite"),
    ("value", "", "non-finite"),
    ("unit", "pct", "unit does not match"),
    ("doc_clause", "CR2014", "doc_clause"),
    ("source", "Bloomberg", "source not a lowercase slug"),
    ("licence", "pending", "licence"),
    ("licence", "none", "licence"),
    ("licence", "", "licence"),
    ("licence", "n/a (hand-entered)", "licence"),
    ("derived", "maybe", "derived not a boolean"),
    ("vendor_ticker", "=HYPERLINK(\"x\")", "unsafe text"),
    ("vendor_ticker", "@SUM(A1)", "unsafe text"),
    ("snapshot_id", "x", "snapshot_id malformed"),
    ("retrieved_utc", "2026-10-20 22:00", "retrieved_utc not"),
])
def test_validate_rejects(col, val, msg):
    df = sample()
    df.loc[0, col] = val
    with pytest.raises(MarketDataError, match=msg):
        validate_market(df)


def test_validate_rules_across_columns():
    df = sample()
    df.loc[0, "iso"] = ""                                      # cds needs an iso
    with pytest.raises(MarketDataError, match="iso required"):
        validate_market(df)
    df = sample(); df.loc[df["instrument"] == "fx_spot", "tenor_y"] = "1"
    with pytest.raises(MarketDataError, match="tenor_y must be 0"):
        validate_market(df)
    df = sample(); df.loc[0, "tenor_y"] = "0"
    with pytest.raises(MarketDataError, match="must be > 0"):
        validate_market(df)
    df = sample(); df.loc[df["instrument"] == "ois", "doc_clause"] = "CR14"
    with pytest.raises(MarketDataError, match="only on cds"):
        validate_market(df)
    df = sample(); df.loc[0, "field"] = "outright"
    with pytest.raises(MarketDataError, match="not allowed for instrument"):
        validate_market(df)
    df = sample(); df.loc[df["field"] == "recovery", "value"] = "40"
    with pytest.raises(MarketDataError, match="recovery must be a fraction"):
        validate_market(df)
    df = sample(); df.loc[0, "asof"] = "2026-10-21"            # after retrieved 2026-10-20
    with pytest.raises(MarketDataError, match="from the future"):
        validate_market(df)
    df = pd.concat([sample(), sample().iloc[[0]]])
    with pytest.raises(MarketDataError, match="duplicate key"):
        validate_market(df)
    with pytest.raises(MarketDataError, match="missing columns"):
        validate_market(sample().drop(columns=["licence"]))


def test_manual_licence_only_for_manual_source():
    df = sample(); df["source"] = "manual"; df["licence"] = "n/a (hand-entered)"
    assert len(validate_market(df)) == len(df)


def test_snapshot_append_only_read_only(tmp_path):
    folder = save_market_snapshot(tmp_path, sample(), now=NOW)
    assert folder.parent == snapshot_root(tmp_path)
    assert (folder / "quotes.csv").exists() and (folder / "manifest.json").exists()
    assert not os.access(folder / "quotes.csv", os.W_OK) or os.geteuid() == 0
    assert oct((folder / "quotes.csv").stat().st_mode & 0o777) == "0o444"
    with pytest.raises(FileExistsError):
        save_market_snapshot(tmp_path, sample(), now=NOW)       # same second, same content
    ix = list_market_snapshots(tmp_path)
    assert ix["snapshot_id"].tolist() == [folder.name] and ix["rows"].tolist() == [str(len(sample()))]
    back = read_market_snapshot(tmp_path, folder.name)
    assert (back["snapshot_id"] == folder.name).all()
    pd.testing.assert_frame_equal(back.drop(columns="snapshot_id"),
                                  validate_market(sample()).drop(columns="snapshot_id"), check_dtype=False)


def test_snapshot_tamper_detected(tmp_path):
    folder = save_market_snapshot(tmp_path, sample(), now=NOW)
    p = folder / "quotes.csv"
    os.chmod(p, 0o644); p.write_text(p.read_text().replace(",200,", ",201,")); os.chmod(p, 0o444)
    with pytest.raises(MarketDataError, match="manifest"):
        read_market_snapshot(tmp_path, folder.name)


def _rewrite(path, data: bytes):
    os.chmod(path, 0o644); path.write_bytes(data); os.chmod(path, 0o444)


def test_snapshot_tamper_with_manifest_sha_updated_still_detected(tmp_path):
    """SEC-A-003 L4 (probe P6): editing quotes.csv AND the manifest sha256 is caught by the content hash in the id,
    manifest content_hash and the index.csv sha256."""
    import hashlib
    import json
    from econquest.ingestion.market import store
    folder = save_market_snapshot(tmp_path, sample(), now=NOW)
    q, m = folder / "quotes.csv", folder / "manifest.json"
    body = q.read_bytes().replace(b",200,", b",20,")
    man = json.loads(m.read_text()); man["sha256"] = hashlib.sha256(body).hexdigest()
    _rewrite(q, body); _rewrite(m, json.dumps(man).encode())
    with pytest.raises(MarketDataError, match="content hash"):
        read_market_snapshot(tmp_path, folder.name)
    man["content_hash"] = store._content_hash(body)                     # forge the manifest's content hash too
    _rewrite(m, json.dumps(man).encode())
    with pytest.raises(MarketDataError, match="hash8 in the snapshot id"):
        read_market_snapshot(tmp_path, folder.name)


def test_snapshot_index_sha_mismatch_detected(tmp_path):
    folder = save_market_snapshot(tmp_path, sample(), now=NOW)
    idx = snapshot_root(tmp_path) / "index.csv"
    ix = pd.read_csv(idx, dtype=str, keep_default_na=False)
    ix["sha256"] = "0" * 64
    ix.to_csv(idx, index=False)
    with pytest.raises(MarketDataError, match="index.csv"):
        read_market_snapshot(tmp_path, folder.name)
    assert len(read_market_snapshot(tmp_path, folder.name, verify=False)) == len(sample())


def test_leading_whitespace_formula_refused():
    """SEC-A-003 L2 (probe P4)."""
    from econquest.ingestion.market.schema import licence_problem, text_problem
    assert licence_problem(" =1+1", "bloomberg") and licence_problem(' =HYPERLINK("http://x")', "bloomberg")
    assert text_problem("\u00a0@SUM(1)") and text_problem("  +1") and not text_problem("SYNTHETIC test licence")
    df = sample(); df["licence"] = " =1+1"
    with pytest.raises(MarketDataError, match="licence"):
        validate_market(df)


def test_retrieved_filled_and_empty_refused(tmp_path):
    df = sample(); df["retrieved_utc"] = ""
    f = save_market_snapshot(tmp_path, df, now=NOW)
    assert set(read_market_snapshot(tmp_path, f.name)["retrieved_utc"]) == {"2026-10-21T08:00:00Z"}
    with pytest.raises(MarketDataError, match="empty"):
        save_market_snapshot(tmp_path, sample().iloc[0:0], now=NOW)


def test_point_in_time_reads(tmp_path):
    with pytest.raises(FileNotFoundError):
        latest_market(tmp_path)
    save_market_snapshot(tmp_path, sample(), now=dt.datetime(2026, 10, 20, 22, 5, tzinfo=dt.timezone.utc))
    later = sample()
    later["asof"] = "2026-10-21"; later["retrieved_utc"] = "2026-10-21T22:00:00Z"
    later.loc[later["tenor_y"] == "5", "value"] = "999"
    save_market_snapshot(tmp_path, later, now=dt.datetime(2026, 10, 21, 22, 30, tzinfo=dt.timezone.utc))
    fix = sample().iloc[[2]].copy(); fix["value"] = "205"; fix["retrieved_utc"] = "2026-10-22T09:00:00Z"
    save_market_snapshot(tmp_path, fix, now=dt.datetime(2026, 10, 22, 9, 0, tzinfo=dt.timezone.utc))   # correction

    def bra5(df):
        return df[(df["iso"] == "BRA") & (df["instrument"] == "cds") & (df["tenor_y"] == 5)].iloc[0]

    as20 = latest_market(tmp_path, "cds", asof="2026-10-20")
    assert bra5(as20)["value"] == 200 and bra5(as20)["asof"] == "2026-10-20"
    as21 = latest_market(tmp_path, "cds", asof="2026-10-21")
    assert bra5(as21)["value"] == 999 and bra5(as21)["asof"] == "2026-10-21"
    # 10-21 noon: the 22:30 snapshot did not exist yet
    noon = latest_market(tmp_path, "cds", asof=dt.datetime(2026, 10, 21, 12, 0, tzinfo=dt.timezone.utc))
    assert bra5(noon)["value"] == 200
    hist = market_history(tmp_path, "cds")
    old = hist[(hist["iso"] == "BRA") & (hist["tenor_y"] == 5) & (hist["asof"] == "2026-10-20")]
    assert old["value"].tolist() == [205]                       # later snapshot corrects the same key
    assert set(latest_market(tmp_path)["instrument"]) > {"cds"}
    with pytest.raises(FileNotFoundError):
        latest_market(tmp_path, asof="2026-10-19")
    with pytest.raises(FileNotFoundError):                      # saved 22:05, so unknown at 22:00
        latest_market(tmp_path, asof=dt.datetime(2026, 10, 20, 22, 0, tzinfo=dt.timezone.utc))
    assert not hist.duplicated(KEY).any()


def test_to_cds_quotes_matches_engine_contract(tmp_path):
    save_market_snapshot(tmp_path, sample(), now=NOW)
    q = to_cds_quotes(latest_market(tmp_path, "cds"), country_names=NAMES)
    assert list(q.columns) == CDS_QUOTES_COLUMNS
    bra = q[q["country"] == "Brazil"].sort_values("tenor_y")
    assert bra["tenor_y"].tolist() == [1, 3, 5, 10] and bra["spread_bp"].tolist() == [100, 150, 200, 250]
    assert set(bra["recovery"]) == {0.4} and bra["source"].str.startswith("synthetic 2026-10-21T080000Z-").all()
    assert set(q.loc[q["country"] == "Argentina", "recovery"]) == {0.25}
    p = tmp_path / "cds_quotes.csv"; q.to_csv(p, index=False)
    table = cds.cds_table(pd.read_csv(p), pd.Series({"Brazil": 0.02, "Argentina": 0.1}))
    assert set(table["country"]) == {"Brazil", "Argentina"}
    assert table.set_index("country").loc["Brazil", "spread_5y_bp"] == 200


def test_to_cds_quotes_preferences_and_unknown_iso():
    df = sample()
    man = df[df["instrument"] == "cds"].copy(); man["source"] = "manual"; man["licence"] = "n/a (hand-entered)"
    man["value"] = man["value"].where(man["field"] == "recovery", "1")
    mr = df[(df["instrument"] == "cds") & (df["iso"] == "BRA")].copy(); mr["doc_clause"] = "MR14"; mr["value"] = mr["value"].where(mr["field"] == "recovery", "2")
    q = to_cds_quotes(pd.concat([man, df, mr]), country_names=NAMES)
    assert q["spread_bp"].min() >= 100                          # CR14 synthetic preferred over manual (1) and MR14 (2)
    q2 = to_cds_quotes(pd.concat([man, df]), country_names=NAMES, source_order=("manual",))
    assert set(q2["spread_bp"]) == {1.0}
    with pytest.raises(MarketDataError, match="no country name"):
        to_cds_quotes(df, country_names={"BRA": "Brazil"})
    assert to_cds_quotes(df[df["instrument"] != "cds"], country_names=NAMES).empty


def test_to_cds_quotes_default_names_from_universe():
    q = to_cds_quotes(sample())
    assert {"Brazil", "Argentina"} <= set(q["country"])


# ---------------------------------------------------------------- EQ-A-0034 / HO-20261023-B-A-009: Team B CDS snapshots

def synthetic_fictional():
    """The SYNTHETIC sample with fictional reference entities (XAA, XBB) instead of real ISO3 codes."""
    return sample().replace({"iso": {"BRA": "XAA", "ARG": "XBB"}})


def test_cds_snapshot_columns_pinned_to_engine():
    from econquest.engine import cds_curves as cc
    from econquest.ingestion.market.schema import CDS_SNAPSHOT_COLUMNS
    assert CDS_SNAPSHOT_COLUMNS == list(cc.SNAPSHOT_COLUMNS)


def test_store_writes_cds_snapshots_that_cds_curves_reads_cleanly(tmp_path):
    from econquest.engine import cds_curves as cc
    from econquest.ingestion.market.schema import CDS_SNAPSHOT_COLUMNS
    from econquest.ingestion.market.store import cds_snapshots_path
    from econquest.ingestion.market.store import export_cds_snapshots
    folder = save_market_snapshot(tmp_path, synthetic_fictional(), now=NOW)
    path = cds_snapshots_path(tmp_path)
    assert path == tmp_path / "market" / "cds_snapshots.csv"
    assert not path.exists()                                    # SEC-A-003 M1: saving no longer appends
    rep = export_cds_snapshots(tmp_path)                        # the explicit gated step
    assert rep.appended == 6 and rep.dropped.empty and rep.snapshots == [folder.name]
    snap = pd.read_csv(path, keep_default_na=False)
    assert list(snap.columns) == CDS_SNAPSHOT_COLUMNS and len(snap) == 6           # XAA 4 tenors + XBB 2 tenors
    assert set(snap["iso3"]) == {"XAA", "XBB"} and set(snap["instrument"]) == {"CDS"}
    assert set(snap["quote_type"]) == {"par_spread"} and (snap["running_bp"] == "").all()
    assert snap["snapshot_id"].str.startswith(folder.name + ":").all() and snap["licence"].str.contains("synthetic").all()
    assert set(snap["vintage"]) == {"2026-10-20"} and set(snap["as_of"]) == {"2026-10-20"}
    curve, summ, issues = cc.curves(pd.read_csv(path), as_of="2026-10-21")
    assert issues == []
    s = summ.set_index("iso3")
    assert s.at["XBB", "recovery"] == 0.25 and s.at["XBB", "recovery_source"] == "quote" and s["synthetic"].all()
    assert abs(curve["reprice_error_bp"]).max() < 1e-6


def test_cds_snapshots_append_only_and_dedupe(tmp_path):
    from econquest.ingestion.market.store import _append_cds_snapshots, cds_snapshots_path, export_cds_snapshots
    save_market_snapshot(tmp_path, synthetic_fictional(), now=NOW)
    path = cds_snapshots_path(tmp_path)
    assert export_cds_snapshots(tmp_path).appended == 6
    before = path.read_bytes()
    assert export_cds_snapshots(tmp_path).appended == 0 and path.read_bytes() == before   # rerun: identical rows skipped
    later = synthetic_fictional()
    later["value"] = later["value"].where(~((later["iso"] == "XAA") & (later["field"] == "spread_bp")),
                                          (pd.to_numeric(later["value"]) * 1.1).astype(str))   # inside the jump limit
    later["asof"], later["retrieved_utc"] = "2026-10-21", "2026-10-21T22:00:00Z"
    save_market_snapshot(tmp_path, later, now=NOW + dt.timedelta(days=1))
    assert path.read_bytes() == before                                              # save alone writes nothing
    rep = export_cds_snapshots(tmp_path)
    assert rep.appended == 6 and rep.dropped.empty, rep.dropped
    after = path.read_bytes()
    assert after.startswith(before) and len(pd.read_csv(path)) == 12                  # appended, never rewritten
    tampered = read_market_snapshot(tmp_path, list_market_snapshots(tmp_path)["snapshot_id"].iloc[0])
    tampered.loc[tampered["field"] == "spread_bp", "value"] += 1.0
    with pytest.raises(MarketDataError, match="never rewritten"):
        _append_cds_snapshots(tmp_path, tampered)
    assert path.read_bytes() == after
    from econquest.engine import cds_curves as cc
    # point-in-time: the first capture (saved 2026-10-21 08:00; the second is saved 10-22). EQ-B-0056 review: cds_curves
    # no longer reads a capture saved after the end of as_of, so as_of moved from 2026-10-20 to the first save date.
    _, summ, issues = cc.curves(pd.read_csv(path), as_of="2026-10-21")
    assert issues == [] and set(summ["as_of"]) == {"2026-10-20"}


def test_to_cds_snapshots_mapping_and_blank_fields():
    from econquest.ingestion.market.schema import to_cds_snapshots
    m = synthetic_fictional()
    with pytest.raises(MarketDataError, match="save_market_snapshot"):
        to_cds_snapshots(m)                                                        # not saved: no snapshot_id
    m["snapshot_id"] = "2026-10-21T080000Z-0123abcd"
    up = m[(m["iso"] == "XBB") & (m["tenor_y"] == "5")].copy()
    up["field"], up["unit"], up["value"], up["source"] = "upfront_pct", "pct", "12.5", "synthetic"
    up2 = up.copy(); up2["tenor_y"] = "3"
    vend = m[(m["iso"] == "XAA") & (m["field"] == "spread_bp")].copy()
    vend["source"], vend["value"] = "bloomberg", "999"
    out = to_cds_snapshots(pd.concat([m, up, up2, vend], ignore_index=True))
    xbb = out[out["iso3"] == "XBB"].set_index("tenor_y")
    assert xbb.at[5.0, "quote_type"] == "par_spread"                                 # par kept over upfront, same tenor
    assert xbb.at[3.0, "quote_type"] == "upfront" and xbb.at[3.0, "value"] == 12.5 and pd.isna(xbb.at[3.0, "running_bp"])
    assert (xbb["recovery"] == 0.25).all()
    xaa = out[out["iso3"] == "XAA"]
    assert set(xaa["source"]) == {"bloomberg"} and (xaa["value"] == 999).all()      # whole capture from the preferred source
    assert xaa["recovery"].isna().all()                                            # no bloomberg recovery row: blank
    assert to_cds_snapshots(m, currency="EUR").empty
