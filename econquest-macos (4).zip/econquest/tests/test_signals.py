"""Signals, trade activation and dashboard sizing (EQ-B-0008)."""
import sys
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import pandas as pd
import pytest
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from econquest.config import Settings
from econquest.engine import signals as S

ROOT = Path(__file__).resolve().parents[1]; DATA = ROOT / "data"
INST = ["CDS", "Eurobond", "FX", "FX options", "Local rates", "Equity"]


def _universe(names=("A", "B")):
    countries = pd.DataFrame([{"country": c, **{k: True for k in INST}} for c in names])
    return SimpleNamespace(countries=countries, names=list(names))


def _playbook(rows):
    base = {"key2": np.nan, "rule2": np.nan, "threshold2": np.nan, "instrument": "Any", "stance": "Risk-off", "strategy": "s"}
    return pd.DataFrame([{**base, **r} for r in rows])


def _signals(values, names=("A", "B")):
    sig = pd.DataFrame(0.0, index=list(S.SIGNAL_NAMES), columns=list(names))
    for (k, c), v in values.items():
        sig.at[k, c] = v
    return sig


# --- signal 15 / 19 saturation -------------------------------------------------------------------------------

def test_complacency_signal_does_not_saturate_and_scales_with_gap():
    """Regression: the old 50 + 50 log2(ratio) clipped to [0, 100] put signal 19 at 100 for every ratio <= 0.5."""
    ratios = [0.1, 0.25, 0.42, 0.5]
    s19 = [100 - S.complacency_signal(r) for r in ratios]
    assert all(v < 100 for v in s19)
    assert all(a > b for a, b in zip(s19, s19[1:]))                    # larger gap (smaller ratio) -> stronger signal 19
    s15 = [S.complacency_signal(r) for r in (2.0, 4.0, 10.0)]
    assert all(v < 100 for v in s15) and s15[0] < s15[1] < s15[2]


def test_complacency_signal_is_continuous_symmetric_and_keeps_the_70_crossing():
    assert S.complacency_signal(1.0) == pytest.approx(50.0)
    assert S.complacency_signal(2.0) + S.complacency_signal(0.5) == pytest.approx(100.0)
    x = 2 ** 0.4                                                        # T16/T17 min_strength 70 boundary is unchanged
    assert S.complacency_signal(x) == pytest.approx(70.0, abs=0.01) and S.complacency_signal(1 / x) == pytest.approx(30.0, abs=0.01)
    grid = np.exp(np.linspace(np.log(0.05), np.log(20), 2001))
    vals = np.array([S.complacency_signal(r) for r in grid])
    assert (np.diff(vals) > 0).all() and np.abs(np.diff(vals)).max() < 0.5
    assert S.complacency_signal(0.42) == pytest.approx(6.6, abs=0.1)    # Colombia: signal 19 = 93.4, not 100
    with pytest.raises(ValueError):
        S.complacency_signal(0.5, 0.0)


def test_complacency_scale_is_read_from_assumptions():
    s = Settings.load(DATA / "assumptions.json")
    assert s.get("signals", "complacency_scale_log2") == pytest.approx(S.DEFAULT_COMPLACENCY_SCALE_LOG2, abs=1e-3)
    assert "Hedge" in s.get("signals", "unsized_stances")


# --- rule2 operator validation -------------------------------------------------------------------------------

@pytest.mark.parametrize("op,thr,fires", [("<", 45, ["A"]), ("<=", 40, ["A"]), (">", 45, ["B"]), (">=", 50, ["B"]), (" >= ", 40, ["A", "B"])])
def test_rule2_operators_are_applied(op, thr, fires):
    u = _universe()
    sig = _signals({(1, "A"): 80, (1, "B"): 80, (2, "A"): 40, (2, "B"): 50})
    pb = _playbook([{"id": "T1", "key": 1, "min_strength": 60, "key2": 2, "rule2": op, "threshold2": thr}])
    act = S.trade_activation(u, pb, sig)
    assert [c for c in u.names if pd.notna(act.at["T1", c])] == fires


@pytest.mark.parametrize("bad", ["=>", "==", "gt", "", " ", "nan"])
def test_rule2_unknown_operator_raises(bad):
    """Regression: anything other than '<' was silently treated as '>='."""
    pb = _playbook([{"id": "T9", "key": 1, "min_strength": 60, "key2": 2, "rule2": bad, "threshold2": 50}])
    with pytest.raises(ValueError, match="T9"):
        S.trade_activation(_universe(), pb, _signals({}))


def test_playbook_rule2_values_are_all_valid():
    pb = pd.read_csv(DATA / "playbook.csv")
    used = pb.loc[pb["key2"].notna(), "rule2"].astype(str).str.strip()
    assert set(used) <= set(S.RULE2_OPS)


# --- sizing excludes hedges ----------------------------------------------------------------------------------

def _dash(playbook, sig, regime="Calm"):
    u = _universe(("A",))
    s = Settings.load(DATA / "assumptions.json")
    act = S.trade_activation(u, playbook, sig)
    country = pd.DataFrame([{"country": "A", "composite": 40.0, "regime": regime, "region": "R", "grade": 3, "rating": "BB",
                             "pd_default": 0.02, "pd_market": 0.02, "pd_any": 0.03}]).set_index("country")
    gpr = pd.DataFrame([{"country": "A", "covered": False, "signal": 0.0}]).set_index("country")
    return S.dashboard_table(u, s, country, sig, act, playbook, gpr, pd.DataFrame()).loc["A"]


def test_hedges_are_not_sized_against_the_risk_budget():
    """Regression: a political risk insurance hedge (T11, stance Hedge) at 90 set the country's notional to 9 $mm."""
    pb = _playbook([{"id": "T11", "key": 10, "min_strength": 60, "stance": "Hedge"},
                    {"id": "T01", "key": 2, "min_strength": 60, "instrument": "CDS", "stance": "Risk-off"}])
    d = _dash(pb, _signals({(10, "A"): 90, (2, "A"): 65}))
    assert d["trades_firing"] == 2 and d["conviction"] == 90 and d["best_trade"] == "s"
    assert d["notional_mm"] == pytest.approx(6.5)                       # 10 x 65 / 100 x Calm 1.0, not 9.0
    only_hedge = _dash(pb, _signals({(10, "A"): 90}), regime="Stressed")
    assert only_hedge["trades_firing"] == 1 and only_hedge["notional_mm"] == 0.0


# --- end to end on the shipped data --------------------------------------------------------------------------

def test_colombia_sizing_on_shipped_data():
    from econquest.ingestion import load_universe
    from econquest.engine import run_pipeline
    u = load_universe(DATA); s = Settings.load(DATA / "assumptions.json")
    r = run_pipeline(u, s, "test", paths=2000)
    sig, dash = r.signals, r.dashboard
    assert (sig.loc[[15, 19]] < 100).all().all() and (sig.loc[[15, 19]] > 0).all().all()
    col = dash.loc["Colombia"]
    ratio = col["pd_default"] / col["pd_market"]
    assert sig.at[19, "Colombia"] == pytest.approx(100 - S.complacency_signal(ratio, s.get("signals", "complacency_scale_log2")))
    assert col["notional_mm"] < 10.0                                    # was the full 10 $mm budget at signal 19 = 100
    hedge_ids = set(u.playbook.loc[u.playbook["stance"] == "Hedge", "id"])
    for c, row in dash.iterrows():
        a = r.activation[c].dropna()
        sized = a[~a.index.isin(hedge_ids)]
        exp = s["signals"]["risk_budget_mm"] * (sized.max() if len(sized) else 0.0) / 100 * s["signals"]["regime_scalar"][row["regime"]]
        assert row["notional_mm"] == pytest.approx(round(exp, 2))
