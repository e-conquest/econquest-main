"""Fitted HMM regimes (engine/regime_hmm.py): features, pooled fit, fallback and override, pipeline wiring."""
import sys
from pathlib import Path
import numpy as np
import pandas as pd
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.config import Settings
from econquest.ingestion import load_universe
from econquest.engine import run_pipeline
from econquest.engine import regime_hmm as RH
from econquest.engine.layer3_regime import rule_regime, regime_multipliers

DATA = ROOT / "data"


def _synthetic_prices(n_days=800, seed=1):
    """Three currencies and two ETFs: AAA calm, BBB calm then a sharp depreciation in the last 120 days, CCC turbulent throughout."""
    rng = np.random.default_rng(seed)
    idx = pd.bdate_range("2023-01-02", periods=n_days)
    aaa = 100 * np.exp(np.cumsum(rng.normal(0, 0.002, n_days)))
    drift = np.where(np.arange(n_days) >= n_days - 120, 0.006, 0.0)
    bbb = 100 * np.exp(np.cumsum(rng.normal(0, 0.002, n_days) + drift))
    ccc = 100 * np.exp(np.cumsum(rng.normal(0.001, 0.02, n_days)))
    eaa = 50 * np.exp(np.cumsum(rng.normal(0, 0.01, n_days)))
    ebb = 50 * np.exp(np.cumsum(rng.normal(0, 0.01, n_days)))
    return pd.DataFrame({"USDAAA": aaa, "USDBBB": bbb, "USDCCC": ccc, "EAA": eaa, "EBB": ebb}, index=idx).rename_axis("date")


def _countries():
    return pd.DataFrame({"country": ["Alpha", "Beta", "Gamma", "Delta"], "currency": ["AAA", "BBB", "CCC", "ZZZ"], "etf": ["EAA", "EBB", "", ""]})


def test_weekly_features_shape_and_sign():
    feats = RH.weekly_features(_synthetic_prices(), _countries())
    assert set(feats) == {"Alpha", "Beta", "Gamma"}            # Delta has no FX series and no ETF
    f = feats["Beta"]
    assert list(f.columns) == list(RH.FEATURES)
    assert (f.index.dayofweek == 4).all()                       # Fridays
    assert f["dep_4w"].iloc[-1] > 5                             # positive = weaker local currency after the devaluation
    assert feats["Alpha"]["dep_4w"].abs().iloc[-1] < 5
    assert feats["Gamma"]["etf_4w"].isna().all()                # no ETF -> NaN ETF columns
    assert feats["Gamma"]["fxvol_4w"].mean() > 3 * feats["Alpha"]["fxvol_4w"].mean()


def test_pooled_fit_orders_states_by_turbulence():
    feats = RH.weekly_features(_synthetic_prices(), _countries())
    fit = RH.fit_pooled_hmm(feats, seed=7)
    turb = fit.state_means["dep_4w"] / fit.sds[0] + fit.state_means["fxvol_4w"] / fit.sds[1]
    assert list(turb.index) == ["Calm", "Stressed", "Crisis"]
    assert turb.is_monotonic_increasing
    assert np.allclose(fit.transition_weekly.sum(axis=1), 1) and np.allclose(fit.transition_12m.sum(axis=1), 1)
    assert fit.n_obs == sum(len(f) for f in feats.values())
    dec = RH.decode_regimes(fit, feats)
    assert dec.loc["Alpha", "regime_hmm"] == "Calm"
    assert dec.loc["Gamma", "regime_hmm"] in ("Stressed", "Crisis")
    assert np.allclose(dec[["p_calm", "p_stressed", "p_crisis"]].sum(axis=1), 1)


def test_hmm_regimes_fallback_and_override():
    u = load_universe(DATA); s = Settings.load(DATA / "assumptions.json")
    reg, info = RH.hmm_regimes(u, s, method="hmm")
    assert info["fitted"] and info["fallback"] == ["Zimbabwe"]   # no USDZWL series and no ETF
    rule = rule_regime(u, s)
    assert reg["Zimbabwe"] == rule["Zimbabwe"]
    assert 0 <= info["agreement_rate"] <= 1 and info["n_country_weeks"] > 1000
    assert np.allclose(np.array(info["transition_12m"]).sum(axis=1), 1)
    # blend is never milder than the rule regime
    blend, _ = RH.hmm_regimes(u, s, method="blend")
    rank = {"Calm": 0, "Stressed": 1, "Crisis": 2}
    assert all(rank[blend[c]] >= rank[rule[c]] for c in u.names)
    # scenario override is applied after the method choice
    s2 = s.copy_with(); s2.scenario_override = "All crisis"
    reg2, _ = RH.hmm_regimes(u, s2, method="hmm")
    assert (reg2 == "Crisis").all()
    s3 = s.copy_with(); s3.scenario_override = "All stressed"
    reg3, _ = RH.hmm_regimes(u, s3, method="hmm")
    assert set(reg3) <= {"Stressed", "Crisis"} and (reg3 == "Crisis").sum() == (reg == "Crisis").sum()
    # rules method ignores the prices and reproduces rule_regime
    reg4, info4 = RH.hmm_regimes(u, s, method="rules")
    assert list(reg4) == list(rule) and not info4["fitted"]
    # optional fitted matrix in the multipliers
    m = regime_multipliers(reg, s, P=np.array(info["transition_12m"]))
    assert abs(m.loc["Vietnam", "p_crisis_12m"] - info["transition_12m"][rank[reg["Vietnam"]]][2]) < 1e-12


def test_pipeline_hmm_method_runs_and_rules_unchanged():
    u = load_universe(DATA); s = Settings.load(DATA / "assumptions.json")
    assert s.get("regime", "method") == "rules" and s.get("transition_matrix", "source") == "assumptions"
    base = run_pipeline(u, s, paths=2000)
    assert list(base.country["regime"]) == list(rule_regime(u, s))
    assert base.country["regime_hmm"].isna().all() and base.country["p_crisis_hmm"].isna().all()
    assert base.diagnostics["regime_hmm"]["method"] == "rules"
    s_h = s.copy_with(**{"regime.method": "hmm", "transition_matrix.source": "hmm"})
    res = run_pipeline(u, s_h, paths=2000)
    c = res.country
    for col in ("regime_rule", "regime_hmm", "p_crisis_hmm"):
        assert col in c.columns
    assert list(c["regime_rule"]) == list(rule_regime(u, s))
    assert c["regime_hmm"].notna().sum() == len(u.names) - 1 and c.loc["Zimbabwe", "regime"] == "Crisis"
    d = res.diagnostics["regime_hmm"]
    assert d["method"] == "hmm" and d["fitted"] and d["transition_source"] == "hmm" and d["fallback"] == ["Zimbabwe"]
    P = np.array(d["transition_12m"])
    assert abs(c.loc["Vietnam", "p_crisis_12m"] - P[["Calm", "Stressed", "Crisis"].index(c.loc["Vietnam", "regime"]), 2]) < 1e-12
    assert res.metrics["var99_mm"] > 0
