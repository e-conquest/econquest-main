"""EQ-A-0008: importer for the official BoC-BoE (CRAG) sovereign default database."""
from pathlib import Path

import pandas as pd
import pytest
from openpyxl import Workbook

from econquest.ingestion import default_panel as dp
from econquest.validation.hazard_panel import load_default_events

REPO = Path(__file__).resolve().parents[1]
PANEL = REPO / "data" / "panel" / "sovereign_defaults.csv"
YEARS = list(range(1995, 2011))


def _long_workbook(path: Path) -> Path:
    """CRAG-shaped long sheet like the 2026 edition (Valet DEBT_2026 columns): a notes sheet, a title block, then
    COUNTRY, COUNTRY_GROUP, YEAR and one column per creditor category with the _2026 suffix."""
    amounts = {  # (country, year) -> {category: amount}
        **{("Argentina", y): {"FC_BONDS_2026": 80000.0} for y in range(2001, 2006)},
        **{("Ecuador", y): {"FC_BANK_LOANS_2026": 500.0, "FC_BONDS_2026": 6000.0} for y in (1999, 2000)},
        **{("Ecuador", y): {"FC_BONDS_2026": 3000.0} for y in (2008, 2009)},
        ("Russia", 1998): {"LC_DEBT_2026": 40000.0},
        ("Russia", 1999): {"LC_DEBT_2026": 20000.0, "FC_BANK_LOANS_2026": 30000.0},
        # official-only arrears: must not create a spell
        **{("Zimbabwe", y): {"IMF_2026": 100.0, "PARIS_CLUB_2026": 900.0, "FISCAL_ARREARS_2026": 50.0} for y in range(2000, 2011)},
        ("Freedonia", 2003): {"FC_BONDS_2026": 10.0},  # name nobody can map
        # still in default at the last data year
        **{("Venezuela", y): {"FC_BONDS_2026": 30000.0} for y in (2009, 2010)},
    }
    cats = ["TOTAL_2026", "IMF_2026", "PARIS_CLUB_2026", "PRIVATE_CREDITORS_2026", "FC_BANK_LOANS_2026", "FC_BONDS_2026",
            "LC_DEBT_2026", "FISCAL_ARREARS_2026", "DEFRATE_FC_BONDS_2026"]
    wb = Workbook()
    notes = wb.active; notes.title = "Notes"
    notes.append(["BoC-BoE Sovereign Default Database"]); notes.append(["Synthetic test file"])
    ws = wb.create_sheet("Data")
    ws.append(["Debt in default by creditor, USD millions"]); ws.append([])
    ws.append(["COUNTRY", "COUNTRY_GROUP", "YEAR", *cats])
    for c in ("Argentina", "Ecuador", "Russia", "Zimbabwe", "Venezuela", "Freedonia", "World"):
        for y in YEARS:
            a = amounts.get((c, y), {})
            priv = sum(v for k, v in a.items() if k in ("FC_BANK_LOANS_2026", "FC_BONDS_2026"))
            row = {k: a.get(k, 0.0) for k in cats}
            row["PRIVATE_CREDITORS_2026"] = priv
            row["TOTAL_2026"] = sum(a.values()) + 1.0  # aggregate column must never be summed
            row["DEFRATE_FC_BONDS_2026"] = 99.0          # ratio column must never be summed
            ws.append([c, "EME", y, *[row[k] for k in cats]])
    wb.save(path)
    return path


ISO = {"Argentina": "ARG", "Ecuador": "ECU", "Russia": "RUS", "Zimbabwe": "ZWE", "Venezuela": "VEN", "Freedonia": "XFD"}


@pytest.fixture
def imported(tmp_path):
    xlsx = _long_workbook(tmp_path / "BoC-BoE-Database-test.xlsx")
    out = tmp_path / "sovereign_defaults_crag.csv"
    summary = dp.import_crag(xlsx, out, "BoC-BoE Sovereign Default Database (synthetic)", "2026-test", iso_map=ISO)
    return xlsx, out, summary


def test_import_produces_schema_and_spells(imported):
    xlsx, out, summary = imported
    df = pd.read_csv(out)
    assert list(df.columns) == dp.SCHEMA + dp.PROVENANCE
    spells = {(r.iso, r.start, r.end) for r in df.itertuples()}
    assert spells == {("ARG", 2001, 2005), ("ECU", 1999, 2000), ("ECU", 2008, 2009), ("RUS", 1998, 1999), ("VEN", 2009, 2010), ("XFD", 2003, 2003)}
    assert "ZWE" not in set(df["iso"])  # official creditors and fiscal arrears are out of scope
    assert summary["layout"] == "long" and summary["sheet"] == "Data" and summary["years"] == (1995, 2010)
    assert summary["input_sha256"] == dp.checksum(xlsx)
    ecu = df[(df.iso == "ECU") & (df.start == 1999)].iloc[0]
    assert ecu["creditors"] == "bank loans; bonds"
    assert df[df.iso == "RUS"].iloc[0]["creditors"] == "bank loans; LC debt"
    assert "ongoing" in df[df.iso == "VEN"].iloc[0]["note"]
    assert "ongoing" not in df[df.iso == "ARG"].iloc[0]["note"]


def test_every_row_has_source_and_loader_accepts_extra_columns(imported):
    xlsx, out, _ = imported
    df = pd.read_csv(out)
    assert df["source"].notna().all() and (df["source"].str.len() > 0).all()
    assert df["source"].str.contains("sha256:" + dp.checksum(xlsx)[:16]).all()
    assert (df["source_vintage"].astype(str) == "2026-test").all()
    ev = load_default_events(out)
    assert {"source", "source_vintage"} <= set(ev.columns) and len(ev) == len(df)


def test_unmapped_country_names_fail_loudly_with_template(tmp_path):
    xlsx = _long_workbook(tmp_path / "crag.xlsx")
    out = tmp_path / "out.csv"
    with pytest.raises(ValueError, match="no ISO3 code"):
        dp.import_crag(xlsx, out, "synthetic", "v1", iso_map={"Argentina": "ARG"}, iso_map_csv=tmp_path / "none.csv")
    tpl = pd.read_csv(tmp_path / "out_unmapped.csv")
    assert not out.exists()
    # names already in the repo's episode list (Ecuador, Russia, ...) resolve; countries without a spell (Zimbabwe) need none
    assert "Freedonia" in set(tpl["country"]) and "Zimbabwe" not in set(tpl["country"])
    assert set(tpl["country"]) <= {"Ecuador", "Russia", "Venezuela", "Freedonia"}
    res = dp.import_crag(xlsx, out, "synthetic", "v1", iso_map={"Argentina": "ARG"}, iso_map_csv=tmp_path / "none.csv", on_unmapped="skip")
    assert res["unmapped_skipped"] == sorted(tpl["country"])


def test_wide_layout_and_iso_column(tmp_path):
    wb = Workbook(); ws = wb.active
    ws.append(["Country", "ISO3", "Creditor category", *YEARS])
    ws.append(["Ghana", "GHA", "Bonds", *[5.0 if y >= 2008 else 0 for y in YEARS]])
    ws.append(["Ghana", "GHA", "Paris Club", *[7.0] * len(YEARS)])
    ws.append(["Peru", "PER", "Bank loans", *[3.0 if y <= 1997 else 0 for y in YEARS]])
    p = tmp_path / "wide.xlsx"; wb.save(p)
    out = tmp_path / "wide.csv"
    s = dp.import_crag(p, out, "wide synthetic", "v0")
    df = pd.read_csv(out)
    assert s["layout"] == "wide"
    assert {(r.iso, r.start, r.end, r.creditors) for r in df.itertuples()} == {("GHA", 2008, 2010, "bonds"), ("PER", 1995, 1997, "bank loans")}


def test_bad_layout_raises(tmp_path):
    wb = Workbook(); wb.active.append(["nothing", "here"]); p = tmp_path / "bad.xlsx"; wb.save(p)
    with pytest.raises(ValueError, match="no CRAG table"):
        dp.import_crag(p, tmp_path / "o.csv", "x", "y")
    with pytest.raises(ValueError, match="provenance"):
        dp.import_crag(_long_workbook(tmp_path / "ok.xlsx"), tmp_path / "o.csv", "", "y", iso_map=ISO)


def test_compare_detects_added_removed_changed(tmp_path, imported):
    _, new, _ = imported
    old = tmp_path / "old.csv"
    pd.DataFrame([
        {"iso": "ARG", "country": "Argentina", "start": 2001, "end": 2005, "creditors": "bonds", "note": ""},     # unchanged
        {"iso": "ECU", "country": "Ecuador", "start": 1999, "end": 2000, "creditors": "bonds", "note": ""},      # unchanged
        {"iso": "ECU", "country": "Ecuador", "start": 2008, "end": 2008, "creditors": "bonds", "note": ""},      # end moves
        {"iso": "RUS", "country": "Russia", "start": 1998, "end": 2000, "creditors": "LC bonds", "note": ""},    # end moves
        {"iso": "MEX", "country": "Mexico", "start": 1982, "end": 1990, "creditors": "bank loans", "note": ""},  # removed
    ]).to_csv(old, index=False)
    r = dp.compare_panels(old, new)
    assert r["unchanged"] == 2
    assert {(x.iso, x.start) for x in r["removed"].itertuples()} == {("MEX", 1982)}
    assert {(x.iso, x.start, x.end) for x in r["added"].itertuples()} == {("VEN", 2009, 2010), ("XFD", 2003, 2003)}
    ch = {(x.iso, x.old_end, x.new_end) for x in r["changed"].itertuples()}
    assert ch == {("ECU", 2008, 2009), ("RUS", 2000, 1999)}
    assert r["summary"]["added"] == 2 and r["summary"]["removed"] == 1 and r["summary"]["changed"] == 2
    t = dp.comparison_table(r)
    assert list(t["status"].value_counts().sort_index().items()) == [("added", 2), ("changed", 2), ("removed", 1)]


def test_existing_panel_untouched(tmp_path, imported):
    """The importer never writes to data/panel/sovereign_defaults.csv unless asked to."""
    before = dp.checksum(PANEL)
    _long_workbook(tmp_path / "again.xlsx")
    dp.import_crag(tmp_path / "again.xlsx", tmp_path / "x.csv", "s", "v", iso_map=ISO)
    dp.compare_panels(PANEL, tmp_path / "x.csv")
    assert dp.checksum(PANEL) == before
    assert list(pd.read_csv(PANEL, nrows=0).columns) == dp.SCHEMA


def test_valet_csv_export(tmp_path):
    """The Valet group CSV (bankofcanada.ca/valet/observations/group/DEBT_2026/csv) has a metadata preamble and DEBT_ prefixes."""
    p = tmp_path / "DEBT_2026.csv"
    p.write_text('"TERMS AND CONDITIONS"\n\n"SERIES"\n"id","label","description"\n"DEBT_COUNTRY","COUNTRY","COUNTRY"\n\n'
                 '"OBSERVATIONS"\n"date","DEBT_COUNTRY","DEBT_COUNTRY_GROUP","DEBT_YEAR","DEBT_IMF_2026","DEBT_FC_BONDS_2026"\n'
                 '"2001-01-01","Argentina","EME","2001","0","5"\n"2002-01-01","Argentina","EME","2002","0","5"\n'
                 '"2002-01-01","Ghana","EME","2002","9","0"\n')
    out = tmp_path / "o.csv"
    s = dp.import_crag(p, out, "Valet DEBT_2026", "2026-10", iso_map={"Argentina": "ARG", "Ghana": "GHA"})
    df = pd.read_csv(out)
    assert s["layout"] == "long"
    assert [(r.iso, r.start, r.end) for r in df.itertuples()] == [("ARG", 2001, 2002)]


# ---------------------------------------------------------------- EQ-A-0016: full universe, from 1980, panel vintage

def _universe_workbook(path: Path) -> Path:
    """Long CRAG-shaped sheet, 1970-2010, with defaulters and never-defaulted economies named the World Bank way."""
    spells = {"Argentina": [(1982, 1993), (2001, 2005)], "Congo, Dem. Rep.": [(1975, 1985)], "Peru": [(1970, 1975)],
              "Côte d'Ivoire": [(2000, 2004)], "Türkiye": [(1978, 1982)], "Gambia, The": [(1986, 1988)]}
    clean = ["Switzerland", "Norway", "Korea, Rep.", "Botswana", "Chile"]
    wb = Workbook(); ws = wb.active; ws.title = "Data"
    ws.append(["COUNTRY", "YEAR", "FC_BONDS_2026", "IMF_2026"])
    for c in [*spells, *clean]:
        for y in range(1970, 2011):
            ws.append([c, y, 100.0 if any(a <= y <= b for a, b in spells.get(c, [])) else 0.0, 5.0])
    wb.save(path)
    return path


def test_full_universe_from_1980_saved_as_panel_vintage(tmp_path):
    import stat
    xlsx = _universe_workbook(tmp_path / "crag.xlsx")
    out = tmp_path / "panel" / "sovereign_defaults_crag.csv"
    s = dp.import_crag(xlsx, out, "BoC-BoE synthetic", "2026-10", iso_map_csv=tmp_path / "none.csv",
                       now=pd.Timestamp("2026-10-23T12:00:00Z").to_pydatetime())
    df = pd.read_csv(out)
    got = {(r.iso, r.start, r.end) for r in df.itertuples()}
    # built-in names resolve without a map; a spell ending before 1980 is dropped; one spanning 1980 keeps its start
    assert got == {("ARG", 1982, 1993), ("ARG", 2001, 2005), ("COD", 1975, 1985), ("CIV", 2000, 2004),
                   ("TUR", 1978, 1982), ("GMB", 1986, 1988)}
    assert df["source"].str.contains("sha256:").all() and (df["source_vintage"].astype(str) == "2026-10").all()
    uni = pd.read_csv(s["universe"])
    assert len(uni) == 11 and s["universe_countries"] == 11 and s["universe_unmapped"] == []
    assert set(uni.loc[~uni["has_spell"], "iso"]) == {"CHE", "NOR", "KOR", "BWA", "CHL", "PER"}
    v = Path(s["panel_vintage"])
    assert v.parent == tmp_path / "panel" / "vintages"
    assert sorted(p.name for p in v.iterdir()) == ["crag_import.json", "sovereign_defaults_crag.csv", "sovereign_defaults_crag_universe.csv"]
    assert all(stat.S_IMODE(p.stat().st_mode) == 0o444 for p in v.iterdir())
    assert (v / out.name).read_bytes() == out.read_bytes()
    idx = pd.read_csv(v.parent / "index.csv", dtype=str)
    assert list(idx["vintage_id"]) == [v.name] and "BoC-BoE synthetic" in idx["label"].iloc[0]
    # re-import of the same file: same content, no duplicate vintage
    s2 = dp.import_crag(xlsx, out, "BoC-BoE synthetic", "2026-10", iso_map_csv=tmp_path / "none.csv")
    assert s2["panel_vintage"] == s["panel_vintage"]
    assert len(pd.read_csv(v.parent / "index.csv")) == 1
    # opting out writes no vintage
    dp.import_crag(xlsx, tmp_path / "x" / "o.csv", "s", "v", save_vintage=False)
    assert not (tmp_path / "x" / "vintages").exists()


def test_builtin_iso_names():
    look = dp.default_iso_lookup(map_csv=None)
    for name, iso in [("Congo, Dem. Rep.", "COD"), ("Congo, Rep.", "COG"), ("Cote d'Ivoire", "CIV"), ("Türkiye", "TUR"),
                      ("Venezuela, RB", "VEN"), ("Yemen, Rep.", "YEM"), ("St. Kitts and Nevis", "KNA"), ("Lao PDR", "LAO")]:
        assert look[dp._name_key(name)] == iso
    assert dp._name_key("Soviet Union") not in look   # successor-state choices are left to an explicit map


def test_panel_coverage(tmp_path):
    xlsx = _universe_workbook(tmp_path / "crag.xlsx")
    out = tmp_path / "d.csv"
    s = dp.import_crag(xlsx, out, "BoC-BoE synthetic", "2026-10", save_vintage=False)
    hist = tmp_path / "weo_history.csv"
    isos = ["ARG", "COD", "CIV", "TUR", "GMB", "CHE", "NOR", "KOR", "BWA", "CHL", "PER", "FRA", "WLD", "G20"]
    pd.DataFrame({"iso": isos, "series": "GGXWDG_NGDP", "period": 2000, "value": 1.0, "source": "x", "vintage": "2001-04"}).to_csv(hist, index=False)
    r = dp.panel_coverage(out, hist, universe_csv=s["universe"])
    assert r["n_countries"] == 12                     # WLD (aggregate) and G20 (not ISO3) are ignored
    assert r["n_ever_defaulted"] == 5 and r["ever_defaulted_share"] == round(5 / 12, 4)
    assert r["history_missing_from_defaults"] == ["BWA", "CHE", "CHL", "FRA", "KOR", "NOR", "PER"]
    assert r["zeros_not_covered_by_crag"] == ["FRA"] and "PER" in r["zeros_covered_by_crag"]
    assert r["defaults_missing_from_history"] == [] and r["defaults_without_source"] == 0
    assert r["checks"] == {"at_least_100_countries": False, "share_below_55pct": True, "every_episode_sourced": True,
                           "all_zeros_covered_by_crag": False}
    # the memory-compiled file has no provenance columns: every episode is flagged
    r2 = dp.panel_coverage(PANEL, hist)
    assert r2["defaults_without_source"] == r2["defaults_episodes"] and r2["zeros_covered_by_crag"] is None


# ---------------------------------------------------------------- EQ-A-0020: SEC review S5 (formula escaping, ISO3 map)

def _formula_csv(tmp_path):
    p = tmp_path / "crag.csv"
    rows = ["COUNTRY,YEAR,FC_BONDS_2026"]
    for c, amt in (("Argentina", 5), ("=HYPERLINK(\"http://x\")", 7), ("@SUM(A1)", 3), ("+Clean", 0)):
        rows += [f"\"{c.replace(chr(34), chr(34) * 2)}\",{y},{amt if y in (2001, 2002) else 0}" for y in (2000, 2001, 2002, 2003)]
    p.write_text("\n".join(rows) + "\n")
    return p


def test_country_names_are_formula_escaped_in_csvs(tmp_path):
    src = _formula_csv(tmp_path)
    out = tmp_path / "o.csv"
    with pytest.raises(ValueError, match="no ISO3 code"):
        dp.import_crag(src, out, "synthetic", "v1", iso_map={"Argentina": "ARG", "=HYPERLINK(\"http://x\")": "XHY"},
                       iso_map_csv=tmp_path / "none.csv", save_vintage=False)
    assert list(pd.read_csv(tmp_path / "o_unmapped.csv")["country"]) == ["'@SUM(A1)"]
    s = dp.import_crag(src, out, "synthetic", "v1", iso_map={"Argentina": "ARG", "=HYPERLINK(\"http://x\")": "XHY"},
                       iso_map_csv=tmp_path / "none.csv", on_unmapped="skip", save_vintage=False)
    ep = pd.read_csv(out, dtype=str)
    assert dict(zip(ep["iso"], ep["country"])) == {"ARG": "Argentina", "XHY": "'=HYPERLINK(\"http://x\")"}
    uni = pd.read_csv(s["universe"], dtype=str)
    assert set(uni["country"]) == {"Argentina", "'=HYPERLINK(\"http://x\")", "'@SUM(A1)", "'+Clean"}
    # the escaped episode file still loads and compares
    t = dp.comparison_table(dp.compare_panels(out, out))
    assert t.empty


def test_comparison_table_escapes_country():
    added = pd.DataFrame([{"iso": "XAA", "country": "-1+2", "start": 2000, "end": 2001}])
    empty = pd.DataFrame(columns=["iso", "country", "start", "end"])
    t = dp.comparison_table({"added": added, "removed": empty, "changed": pd.DataFrame(columns=["iso", "country"])})
    assert list(t["country"]) == ["'-1+2"]


@pytest.mark.parametrize("code", ["AR", "AR1", "=1+1", "ARGE"])
def test_iso_map_csv_requires_iso3(tmp_path, code):
    m = tmp_path / "map.csv"
    pd.DataFrame({"country": ["Argentina", "Freedonia"], "iso": ["ARG", code]}).to_csv(m, index=False)
    with pytest.raises(ValueError, match="three letters"):
        dp.default_iso_lookup(map_csv=m)
    pd.DataFrame({"country": ["Argentina", "Freedonia"], "iso": ["arg", ""]}).to_csv(m, index=False)
    assert dp.default_iso_lookup(map_csv=m)["argentina"] == "ARG"
