"""`econquest run --as-of` passes the model date to run_pipeline, stress runs included (EQ-C-0011, CLI part)."""
from types import SimpleNamespace

import pytest

from econquest import cli


class _Calls(list):
    markets: list


@pytest.fixture
def captured(monkeypatch):
    calls = _Calls(); markets = []

    def fake_pipeline(u, s, label="base", paths=None, as_of=None, market_dir=None):
        calls.append((label, as_of))
        markets.append(market_dir)
        raise StopIteration                    # stop cmd_run before it writes any output
    monkeypatch.setattr(cli, "_load", lambda args: (SimpleNamespace(), SimpleNamespace()))
    monkeypatch.setattr(cli, "run_pipeline", fake_pipeline)
    calls.markets = markets
    return calls


def test_as_of_reaches_run_pipeline(captured):
    with pytest.raises(StopIteration):
        cli.main(["run", "--as-of", "2026-10-20"])
    assert captured == [("base", "2026-10-20")]


def test_as_of_is_normalised(captured):
    with pytest.raises(StopIteration):
        cli.main(["run", "--as-of", "2026-10-20T15:30"])
    assert captured[0][1] == "2026-10-20"


def test_without_as_of_pipeline_decides(captured):
    with pytest.raises(StopIteration):
        cli.main(["run"])
    assert captured == [("base", None)]


def test_bad_date_is_a_usage_error(captured, capsys):
    with pytest.raises(SystemExit) as e:
        cli.main(["run", "--as-of", "next tuesday"])
    assert e.value.code == 2 and "not a date" in capsys.readouterr().err and captured == []


def test_as_of_with_real_pipeline_records_date(tmp_path):
    """Small real run: the archived summary carries the requested as_of."""
    import json
    out = tmp_path / "out"
    cli.main(["--out", str(out), "run", "--paths", "500", "--as-of", "2026-10-20", "--no-paths"])
    assert json.loads((out / "run_latest.json").read_text())["summary"]["as_of"] == "2026-10-20"


@pytest.mark.parametrize("cmd", ["run", "stress"])
def test_market_dir_is_the_data_folder(captured, tmp_path, cmd, monkeypatch):
    """HO-20261024-B-C-002: run and stress pass market_dir=--data, so bond RV (when enabled) reads that market store."""
    monkeypatch.setattr(cli, "load_scenarios", lambda p: {})
    with pytest.raises(StopIteration):
        cli.main(["--data", str(tmp_path), cmd])
    assert captured.markets == [str(tmp_path)]
