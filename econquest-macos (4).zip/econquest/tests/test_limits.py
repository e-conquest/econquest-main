"""Roadmap 4.1: limits and the pre-trade check. Pipeline runs use 4,000 paths to stay quick."""
import sys
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import pandas as pd
import pytest
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.config import Settings
from econquest.ingestion import load_universe
from econquest.engine import run_pipeline
from econquest.engine import limits as LM

DATA = ROOT / "data"
PATHS = 4000


@pytest.fixture(scope="module")
def world():
    u = load_universe(DATA)
    s = Settings.load(DATA / "assumptions.json")
    lim = LM.load_limits(DATA / "limits.json")
    return u, s, lim


@pytest.fixture(scope="module")
def base(world):
    u, s, _ = world
    return run_pipeline(u, s, paths=PATHS)


def test_sample_book_passes(world, base):
    u, _, lim = world
    t = LM.check_book(base, u, lim)
    assert list(t.columns) == LM.COLUMNS
    assert set(t["status"]) <= {"pass", "warning", "breach"}
    assert not (t["status"] == "breach").any(), t[t["status"] == "breach"]
    # since 0.1.4 (GARCH vols + estimated loadings, CHG-20261023T190523Z-b96d25) book ES99 is about 84-86% of its
    # 115 limit, inside the warning band; everything else at book level passes
    book = t[t["scope"] == "book"].set_index("measure")["status"]
    assert book.drop("es99_mm").eq("pass").all() and book["es99_mm"] in ("pass", "warning")
    # every scope is represented and the book rows are the four shipped measures
    assert set(t["scope"]) == {"book", "country", "asset_class", "issuer", "concentration", "liquidity"}
    assert set(t.loc[t["scope"] == "book", "measure"]) == set(LM.BOOK_MEASURES)
    # the deterministic near-warning items: Brazil / Local bond issuer, Brazil and Singapore gross notional
    near = t[(t["utilisation"] >= 0.75) & (t["utilisation"] < 0.8)]
    names = set(near["name"])
    assert {"Brazil / Local bond", "Brazil", "Singapore"} <= names
    # utilisation is value / limit everywhere
    assert np.allclose(t["utilisation"], t["value"] / t["limit"])


def test_huge_argentina_eurobond_refused(world):
    u, s, lim = world
    res = LM.pretrade_check(u, s, lim, "Argentina,Eurobond,Long,100,6", paths=PATHS)
    assert res["verdict"] == "refuse"
    assert res["paths"] == PATHS and res["before"]["gross_notional_mm"] + 100 == res["after"]["gross_notional_mm"]
    assert res["marginal_var99_mm"] > 20 and res["marginal_es99_mm"] > 20
    reasons = "\n".join(res["breaches"])
    assert "country Argentina gross_notional_mm" in reasons
    assert "breach: book var99_mm" in reasons and "book book" not in reasons      # U21 (HO-20261023-C-B-010)
    assert "issuer Argentina / Eurobond" in reasons
    tab = res["limits_after"]
    assert tab.loc[(tab["scope"] == "country") & (tab["name"] == "Argentina") & (tab["measure"] == "gross_notional_mm"), "status"].item() == "breach"
    assert tab.loc[(tab["scope"] == "book") & (tab["measure"] == "var99_mm"), "status"].item() == "breach"


def test_tiny_argentina_eurobond_accepted(world):
    u, s, lim = world
    res = LM.pretrade_check(u, s, lim, {"country": "Argentina", "asset_class": "Eurobond", "direction": "Long", "notional_mm": 0.5}, paths=PATHS)
    # accepted, or flagged only for warnings that were already there before the trade (book ES99 since 0.1.4)
    assert res["verdict"] in ("accept", "flag") and all("already warning before the trade" in r for r in res["reasons"])
    assert res["position_id"] == "PT1" and res["proposal"]["duration_yrs"] == 5.0
    assert not (res["limits_after"]["status"] == "breach").any()
    # on common paths a 0.5mm position moves the 99% VaR and ES by a fraction of a $mm at most
    assert abs(res["marginal_var99_mm"]) <= 2.0 and abs(res["marginal_es99_mm"]) <= 2.0
    d = LM.pretrade_to_dict(res)
    assert isinstance(d["limits_after"], list) and d["limits_after"][0]["scope"] == "book"


def test_proposal_parsing():
    p = LM.parse_proposal("Brazil, fx, short, 12")
    assert p == {"country": "Brazil", "asset_class": "FX", "direction": "Short", "notional_mm": 12.0, "duration_yrs": p["duration_yrs"], "sector": p["sector"], "location": p["location"]}
    assert np.isnan(p["duration_yrs"])
    with pytest.raises(ValueError):
        LM.parse_proposal("Brazil,Bond,Long,5")
    with pytest.raises(ValueError):
        LM.parse_proposal("Brazil,FX,Sideways,5")
    with pytest.raises(ValueError):
        LM.parse_proposal("Brazil,FX,Long,-5")
    with pytest.raises(ValueError):
        LM.parse_proposal("Brazil,FX")


def test_utilisation_arithmetic_handmade():
    """A two-position book with known numbers: every utilisation and status checked by hand."""
    positions = pd.DataFrame({"country": ["Brazil", "Senegal"], "asset_class": ["Local bond", "Eurobond"], "notional_mm": [30.0, 10.0]},
                             index=pd.Index(["A", "B"], name="id"))
    contrib = positions.copy()
    contrib["tail_contribution_99_mm"] = [6.0, 4.0]          # Brazil 60% of the tail, Senegal 40%
    contrib["liquidity_cost_99_mm"] = [0.1, 0.2]
    country = pd.DataFrame({"regime": ["Calm", "Crisis"]}, index=["Brazil", "Senegal"])
    run = SimpleNamespace(metrics={"var99_mm": 40.0, "es99_mm": 90.0, "lvar99_mm": 45.0, "expected_loss_mm": 1.0},
                          positions=positions, mc=SimpleNamespace(contributions=contrib), country=country)
    lim = {"warning_level": 0.8,
           "book": {"var99_mm": 50.0, "es99_mm": 100.0, "lvar99_mm": 100.0, "expected_loss_mm": 2.0},
           "country": {"gross_notional_mm": {"default": 100.0, "Senegal": 8.0}, "tail_share_99": {"default": 0.5}},
           "asset_class": {"notional_mm": {"Local bond": 60.0}},
           "issuer": {"notional_mm": {"default": 40.0, "Senegal / Eurobond": 20.0}},
           "concentration": {"largest_position_share": 0.8},
           "liquidity": {"crisis_regime_share": 0.5}}
    t = LM.check_book(run, None, lim).set_index(["scope", "name", "measure"])
    row = lambda *k: t.loc[k]
    assert row("book", "book", "var99_mm")["utilisation"] == pytest.approx(0.8) and row("book", "book", "var99_mm")["status"] == "warning"
    assert row("book", "book", "es99_mm")["utilisation"] == pytest.approx(0.9) and row("book", "book", "es99_mm")["status"] == "warning"
    assert row("book", "book", "lvar99_mm")["utilisation"] == pytest.approx(0.45) and row("book", "book", "lvar99_mm")["status"] == "pass"
    assert row("book", "book", "expected_loss_mm")["status"] == "pass"
    assert row("country", "Brazil", "gross_notional_mm")["utilisation"] == pytest.approx(0.3)
    assert row("country", "Senegal", "gross_notional_mm")["utilisation"] == pytest.approx(1.25) and row("country", "Senegal", "gross_notional_mm")["status"] == "breach"
    assert row("country", "Brazil", "tail_share_99")["value"] == pytest.approx(0.6) and row("country", "Brazil", "tail_share_99")["status"] == "breach"
    assert row("country", "Senegal", "tail_share_99")["utilisation"] == pytest.approx(0.8) and row("country", "Senegal", "tail_share_99")["status"] == "warning"
    assert row("asset_class", "Local bond", "notional_mm")["utilisation"] == pytest.approx(0.5)
    assert ("asset_class", "Eurobond", "notional_mm") not in t.index          # no limit set for Eurobond: no row
    assert row("issuer", "Brazil / Local bond", "notional_mm")["utilisation"] == pytest.approx(0.75) and row("issuer", "Brazil / Local bond", "notional_mm")["status"] == "pass"
    assert row("issuer", "Senegal / Eurobond", "notional_mm")["utilisation"] == pytest.approx(0.5)
    assert row("concentration", "largest position (A)", "largest_position_share")["value"] == pytest.approx(0.75)
    assert row("concentration", "largest position (A)", "largest_position_share")["utilisation"] == pytest.approx(0.9375)
    assert row("liquidity", "Crisis-regime countries", "crisis_regime_share")["value"] == pytest.approx(0.25)
    assert row("liquidity", "Crisis-regime countries", "crisis_regime_share")["utilisation"] == pytest.approx(0.5)
    assert len(t) == 13


def test_reason_text_names_book_once_and_keeps_before_tag():
    """U21 (HO-20261023-C-B-010): book-level reasons read "book es99_mm", not "book book es99_mm"; other scopes keep
    their name and the "already ... before the trade" tag is unchanged."""
    cols = ["scope", "name", "measure", "value", "limit", "utilisation", "status"]
    after = pd.DataFrame([["book", "book", "es99_mm", 100.0, 115.0, 100 / 115, "warning"],
                          ["country", "Argentina", "gross_notional_mm", 60.0, 50.0, 1.2, "breach"]], columns=cols)
    before = after.assign(status=["warning", "pass"])
    breaches, warnings = LM._reasons(after, before)
    assert warnings == ["warning: book es99_mm 100.000 vs limit 115.000 (87%) (already warning before the trade)"]
    assert breaches == ["breach: country Argentina gross_notional_mm 60.000 vs limit 50.000 (120%)"]
