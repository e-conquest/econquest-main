"""EQ-A-0037 (HO-20261023-C-A-008, usability U04): fetch fails fast offline.

Every network call is mocked: the probe (feeds.probe_host, or urllib's opener under it), urllib.request.urlopen for
BIS, and stand-in wbgapi / yfinance modules. Nothing here opens a socket."""
import logging
import shutil
import socket
import ssl
import sys
import time
import types
import urllib.error
from pathlib import Path

import pandas as pd
import pytest

from econquest import cli
from econquest.ingestion import feeds, load_universe
from econquest.ingestion.feeds import (FEED_HOSTS, BisFeed, FeedError, FeedUnreachable, NoFeedSucceeded, WorldBankFeed,
                                       WorldBankHistoryFeed, EcbExrFeed, YahooFeed, _is_transient, _long,
                                       _with_retries, fetch_all)

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
TUNNEL = "Tunnel connection failed: 403 Forbidden"


def tunnel_error() -> urllib.error.URLError:
    """What urllib raises here when the proxy refuses CONNECT (seen in this cloud for stats.bis.org)."""
    return urllib.error.URLError(OSError(TUNNEL))


class ProxyError(OSError):
    """Shape of requests.exceptions.ProxyError (wbgapi, yfinance): name ProxyError, the socket error nested in args."""


def requests_proxy_error() -> ProxyError:
    inner = OSError(TUNNEL)
    return ProxyError(f"HTTPSConnectionPool(host='api.worldbank.org', port=443): Max retries exceeded "
                      f"(Caused by ProxyError('Unable to connect to proxy', {inner!r}))", inner)


def all_down(calls: list):
    def probe(host):
        calls.append(host)
        return f"proxy refused CONNECT to {host}"
    return probe


# ---------------------------------------------------------------- classification and retries
@pytest.mark.parametrize("err", [tunnel_error(), requests_proxy_error(),
                                 urllib.error.HTTPError("https://x", 407, "Proxy Authentication Required", {}, None),
                                 RuntimeError("curl: (56) CONNECT tunnel failed, response 403")])
def test_proxy_and_tunnel_errors_are_not_transient(err):
    assert _is_transient(err) is False


@pytest.mark.parametrize("err", [urllib.error.HTTPError("https://x", 503, "Service Unavailable", {}, None),
                                 urllib.error.HTTPError("https://x", 429, "Too Many Requests", {}, None),
                                 urllib.error.URLError(socket.timeout("timed out")), TimeoutError(), ConnectionResetError()])
def test_429_5xx_timeouts_and_resets_stay_transient(err):
    assert _is_transient(err) is True


def test_proxy_refusal_is_tried_once_without_sleeping():
    calls, sleeps = [], []

    def fn():
        calls.append(1)
        raise tunnel_error()
    with pytest.raises(urllib.error.URLError):
        _with_retries(fn, retries=3, backoff=2.0, sleep=sleeps.append)
    assert len(calls) == 1 and sleeps == []


def test_5xx_is_still_retried_with_backoff():
    calls, sleeps = [], []

    def fn():
        calls.append(1)
        if len(calls) < 3:
            raise urllib.error.HTTPError("https://x", 503, "busy", {}, None)
        return "ok"
    assert _with_retries(fn, retries=3, backoff=2.0, sleep=sleeps.append) == "ok"
    assert len(calls) == 3 and sleeps == [2.0, 4.0]


# ---------------------------------------------------------------- the probe
class _Opener:
    def __init__(self, exc):
        self.exc, self.urls = exc, []

    def open(self, req, timeout=None):
        self.urls.append((req.full_url, req.get_method(), timeout))
        raise self.exc


@pytest.mark.parametrize("exc, want", [
    (tunnel_error(), "proxy refused CONNECT to stats.bis.org"),
    (urllib.error.URLError(socket.gaierror(-2, "Name or service not known")), "DNS lookup failed for stats.bis.org"),
    (urllib.error.URLError(socket.timeout("timed out")), "no answer from stats.bis.org within 4 s"),
    (urllib.error.URLError(ConnectionRefusedError(111, "Connection refused")), "connection to stats.bis.org refused"),
    (urllib.error.HTTPError("https://stats.bis.org/", 404, "Not Found", {}, None), None),     # any HTTP answer = reachable
    (urllib.error.HTTPError("https://stats.bis.org/", 407, "Proxy Authentication Required", {}, None), "proxy refused CONNECT to stats.bis.org"),
    (urllib.error.URLError(ssl.SSLCertVerificationError("certificate verify failed")), None),  # tunnel opened
])
def test_probe_host_classifies(monkeypatch, exc, want):
    monkeypatch.undo()                                  # the real probe_host, not conftest's stub
    op = _Opener(exc)
    monkeypatch.setattr(feeds.urllib.request, "build_opener", lambda *h: op)
    assert feeds.probe_host("stats.bis.org") == want
    assert op.urls == [("https://stats.bis.org/", "HEAD", feeds.PROBE_TIMEOUT)]


def test_probe_host_takes_only_a_bare_host(monkeypatch):
    monkeypatch.undo()
    with pytest.raises(ValueError):
        feeds.probe_host("https://evil.example/x")


def test_feed_hosts_match_the_code():
    assert FEED_HOSTS["bis"] == FEED_HOSTS["bis_cbs"] == (BisFeed().base.split("/")[2],)
    assert FEED_HOSTS["worldbank"] == FEED_HOSTS["worldbank_history"] == (feeds.WB_HOST,)
    assert set(FEED_HOSTS) == {f for v in feeds.FEED_ALIASES.values() for f in v}


# ---------------------------------------------------------------- inside a feed: stop at the first refusal
def test_bis_stops_at_first_proxy_refusal(monkeypatch):
    calls, sleeps = [], []

    def urlopen(req, timeout=None):
        calls.append(req.full_url)
        raise tunnel_error()
    monkeypatch.setattr("econquest.ingestion.sources.open_url_no_redirect", urlopen)
    iso2 = {f"C{i:02d}": f"Q{i:02d}" for i in range(60)}           # 3 batches x 3 flows, 60 one-by-one fallbacks before
    with pytest.raises(FeedUnreachable) as e:
        BisFeed(sleep=sleeps.append).fetch(iso2)
    assert e.value.reason == "proxy refused CONNECT to stats.bis.org"
    assert len(calls) == 1 and sleeps == []
    calls.clear()
    with pytest.raises(FeedUnreachable):
        BisFeed(sleep=sleeps.append).fetch_cbs(iso2)
    assert len(calls) == 1 and sleeps == []


def test_bis_unknown_country_fallback_unchanged_online(monkeypatch):
    """A 404 on a batch (not a connectivity error) still falls back to one call per country."""
    calls = []

    def urlopen(req, timeout=None):
        calls.append(req.full_url)
        if "+" in req.full_url:
            raise urllib.error.HTTPError(req.full_url, 404, "No data", {}, None)
        raise urllib.error.HTTPError(req.full_url, 404, "No data", {}, None)
    monkeypatch.setattr("econquest.ingestion.sources.open_url_no_redirect", urlopen)
    with pytest.raises(FeedError) as e:
        BisFeed(sleep=lambda s: None).fetch({"AAA": "AA", "BBB": "BB"})
    assert not isinstance(e.value, FeedUnreachable)
    assert len(calls) == 3 * (1 + 2)                     # each flow: the batch, then both countries


def _wbgapi(calls, exc):
    def fetch(series, economies, **kw):
        calls.append((tuple(series), kw.get("db")))
        raise exc

    def frame(*a, **kw):
        calls.append(a[:1])
        raise exc
    return types.SimpleNamespace(data=types.SimpleNamespace(fetch=fetch, DataFrame=frame))


def test_worldbank_stops_at_first_proxy_refusal(monkeypatch):
    calls = []
    monkeypatch.setitem(sys.modules, "wbgapi", _wbgapi(calls, requests_proxy_error()))
    with pytest.raises(FeedUnreachable) as e:
        WorldBankFeed().fetch(["ARG", "BRA"])
    assert e.value.reason == "proxy refused CONNECT to api.worldbank.org"
    assert len(calls) == 1                               # was: one call per database, then one per series (~20)


def test_worldbank_history_stops_at_first_proxy_refusal():
    calls = []

    def fetcher(code, start, end, isos):
        calls.append(code)
        raise requests_proxy_error()
    with pytest.raises(FeedUnreachable):
        WorldBankHistoryFeed(fetcher=fetcher, alt_fetcher=fetcher).fetch(["ARG"])
    assert calls == ["DT.DOD.DSTC.IR.ZS"]


def test_worldbank_bad_code_still_retried_series_by_series(monkeypatch):
    calls = []

    def fetch(series, economies, **kw):
        calls.append(tuple(series))
        if len(series) > 1 or series[0] == "BAD.CODE":
            raise RuntimeError("APIError: 120 invalid value")
        return [{"economy": "ARG", "series": series[0], "time": "YR2024", "value": 1.0}]
    monkeypatch.setitem(sys.modules, "wbgapi", types.SimpleNamespace(data=types.SimpleNamespace(fetch=fetch)))
    out = WorldBankFeed(series={"SP.POP.TOTL": (2, "x"), "BAD.CODE": (2, "y")}, alt_db={}).fetch(["ARG"])
    assert list(out["series"]) == ["SP.POP.TOTL"] and len(calls) == 3


def test_yahoo_noise_is_captured_and_reported_once(monkeypatch, capsys):
    def download(tickers, **kw):
        lg = logging.getLogger("yfinance")
        for t in tickers:
            lg.error(f"${t}: possibly delisted; {TUNNEL}")
        print("\n3 Failed downloads:")
        return pd.DataFrame()
    monkeypatch.setitem(sys.modules, "yfinance", types.SimpleNamespace(download=download))
    with pytest.raises(FeedUnreachable) as e:
        YahooFeed().fetch({"ARG": "ARS=X", "BRA": "BRL=X"}, {"BRA": "EWZ"})
    assert e.value.reason == "proxy refused CONNECT to query2.finance.yahoo.com"
    out, err = capsys.readouterr()
    assert out == "" and err == ""
    lg = logging.getLogger("yfinance")
    assert lg.propagate is True and not any(type(h).__name__ == "_Keep" for h in lg.handlers)     # restored


def test_yahoo_partial_failures_go_to_failures_not_the_terminal(monkeypatch, capsys):
    idx = pd.to_datetime(["2026-10-21", "2026-10-22"])

    def download(tickers, **kw):
        logging.getLogger("yfinance").error("['ZZZ=X']: possibly delisted; no price data found")
        return pd.concat({"ARS=X": pd.DataFrame({"Close": [1.0, 2.0]}, index=idx),
                          "ZZZ=X": pd.DataFrame({"Close": [float("nan")] * 2}, index=idx)}, axis=1)
    monkeypatch.setitem(sys.modules, "yfinance", types.SimpleNamespace(download=download))
    out = YahooFeed().fetch({"ARG": "ARS=X", "ZZZ": "ZZZ=X"}, {})
    assert len(out) == 2 and out.attrs["failures"] == ["yfinance: ['ZZZ=X']: possibly delisted; no price data found"]
    assert capsys.readouterr() == ("", "")


# ---------------------------------------------------------------- fetch_all
def _no_feed_may_run(monkeypatch):
    def boom(*a, **k):
        raise AssertionError("a feed ran although its hosts are unreachable")
    for cls in (feeds.WeoFeed, WorldBankFeed, WorldBankHistoryFeed, BisFeed, EcbExrFeed, YahooFeed):
        monkeypatch.setattr(cls, "fetch", boom)
    monkeypatch.setattr(BisFeed, "fetch_cbs", boom); monkeypatch.setattr(BisFeed, "fetch_xru", boom)
    monkeypatch.setattr(feeds.WeoFeed, "cache_file", lambda self: Path("/nonexistent/weo_cache.csv"))


def test_all_hosts_down_probes_each_host_once_and_skips_every_feed(monkeypatch):
    _no_feed_may_run(monkeypatch)
    probed, lines = [], []
    u = load_universe(DATA)
    t0 = time.monotonic()
    rep = fetch_all(u, year=2026, log=lines.append, probe=all_down(probed))
    assert time.monotonic() - t0 < 3.0
    assert sorted(probed) == sorted({h for hs in FEED_HOSTS.values() for h in hs})      # once per host
    assert lines == [f"[fetch] {n}: unreachable ({'; '.join(f'proxy refused CONNECT to {h}' for h in FEED_HOSTS[n])}): skipped"
                     for n in ("weo", "worldbank", "worldbank_history", "bis", "bis_cbs", "bis_xru", "ecb_exr")]
    assert "[fetch] bis: unreachable (proxy refused CONNECT to stats.bis.org): skipped" in lines
    assert not any(v.startswith("ok") for v in rep.feeds.values()) and rep.raw == {}


def test_all_hosts_down_with_real_feeds_is_fast(monkeypatch):
    """No feed method mocked: the probe alone keeps an offline pull to well under a few seconds."""
    monkeypatch.setattr(feeds.WeoFeed, "cache_file", lambda self: Path("/nonexistent/weo_cache.csv"))
    monkeypatch.setattr(feeds, "probe_host", lambda host, timeout=feeds.PROBE_TIMEOUT: f"proxy refused CONNECT to {host}")
    t0 = time.monotonic()
    rep = fetch_all(load_universe(DATA), year=2026, log=lambda m: None)
    assert time.monotonic() - t0 < 3.0
    assert all(v.startswith("unreachable (") and v.endswith("): skipped") for v in rep.feeds.values())


def test_one_host_down_other_feeds_still_run(monkeypatch):
    u = load_universe(DATA)
    isos = list(u.countries["iso"])
    ran = []

    def ok(name, rows):
        def f(self, *a, **k):
            ran.append(name)
            return _long(rows, f"fake {name}")
        return f
    monkeypatch.setattr(feeds.WeoFeed, "fetch", ok("weo", [{"iso": i, "series": "PCPIPCH", "period": 2026, "value": 3.0} for i in isos]))
    monkeypatch.setattr(WorldBankFeed, "fetch", ok("worldbank", [{"iso": isos[0], "series": "SP.POP.TOTL", "period": 2024, "value": 1e6}]))
    monkeypatch.setattr(WorldBankHistoryFeed, "fetch", ok("worldbank_history", [{"iso": isos[0], "series": "PV.EST", "period": 2020, "value": 0.1}]))
    monkeypatch.setattr(EcbExrFeed, "fetch", ok("ecb_exr", [{"iso": "", "series": "USD_PER_EUR", "period": "2026-10-22", "value": 1.08}]))

    def bis_must_not_run(*a, **k):
        raise AssertionError("BIS ran although stats.bis.org is unreachable")
    monkeypatch.setattr(BisFeed, "fetch", bis_must_not_run); monkeypatch.setattr(BisFeed, "fetch_cbs", bis_must_not_run)
    monkeypatch.setattr(BisFeed, "fetch_xru", bis_must_not_run)
    probed, lines = [], []

    def probe(host):
        probed.append(host)
        return "proxy refused CONNECT to stats.bis.org" if host == "stats.bis.org" else None
    rep = fetch_all(u, year=2026, log=lines.append, probe=probe)
    assert ran == ["weo", "worldbank", "worldbank_history", "ecb_exr"]
    assert rep.feeds["bis"] == rep.feeds["bis_cbs"] == "unreachable (proxy refused CONNECT to stats.bis.org): skipped"
    assert all(rep.feeds[n].startswith("ok (") for n in ("weo", "worldbank", "worldbank_history", "ecb_exr"))
    assert rep.feeds["bis_xru"] == "unreachable (proxy refused CONNECT to stats.bis.org): skipped"
    assert probed.count("stats.bis.org") == 1 and probed.count("api.worldbank.org") == 1
    assert not any("yahoo" in h for h in probed) and "www.imf.org" not in probed       # first host answered
    assert len(lines) == 7 and rep.indicators.notna().sum().sum() > 0


def test_feed_refused_midway_prints_one_line(monkeypatch):
    def refused(self, *a, **k):
        raise FeedUnreachable("proxy refused CONNECT to api.worldbank.org")
    monkeypatch.setattr(WorldBankFeed, "fetch", refused)
    monkeypatch.setattr(WorldBankHistoryFeed, "fetch", lambda self, isos: _long([{"iso": "ARG", "series": "PV.EST", "period": 2020, "value": 0.1}], "x"))
    lines = []
    rep = fetch_all(load_universe(DATA), only=["worldbank"], year=2026, log=lines.append, probe=lambda h: None)
    assert rep.feeds["worldbank"] == "unreachable (proxy refused CONNECT to api.worldbank.org): stopped at the first refused request"
    assert [ln.split(":")[0] for ln in lines] == ["[fetch] worldbank", "[fetch] worldbank_history"]


def test_missing_package_is_a_failed_feed_not_a_traceback(monkeypatch):
    monkeypatch.setitem(sys.modules, "wbgapi", None)          # import wbgapi -> ImportError
    rep = fetch_all(load_universe(DATA), only=["worldbank"], year=2026, log=lambda m: None, probe=lambda h: None)
    assert rep.feeds["worldbank"].startswith("failed: package") and "not installed" in rep.feeds["worldbank"]


def test_weo_reads_its_cache_when_imf_hosts_are_down(monkeypatch, tmp_path):
    cache = tmp_path / "weo_2026_Oct.csv"; cache.write_text("x")
    monkeypatch.setattr(feeds.WeoFeed, "cache_file", lambda self: cache)
    seen = []

    def pkg(self, isos, codes):
        seen.append("cache")
        return _long([{"iso": "ARG", "series": "PCPIPCH", "period": 2026, "value": 3.0}], "weo package WEO Oct 2026")

    def reader(self, isos, codes):
        raise AssertionError("imf-reader must not be called offline")
    monkeypatch.setattr(feeds.WeoFeed, "_weo_package", pkg); monkeypatch.setattr(feeds.WeoFeed, "_imf_reader", reader)
    rep = fetch_all(load_universe(DATA), only=["weo"], year=2026, log=lambda m: None, probe=all_down([]))
    assert seen == ["cache"] and rep.feeds["weo"].startswith("ok (1 rows) from the cached download (proxy refused")


# ---------------------------------------------------------------- nothing written when nothing succeeded
def test_save_report_and_vintage_refuse_when_no_feed_succeeded(tmp_path):
    rep = feeds.FetchReport(pd.DataFrame(), pd.DataFrame(), pd.DataFrame(),
                            {"weo": "unreachable (x): skipped", "bis": "failed: y", "ecb_exr": "skipped"}, {})
    with pytest.raises(NoFeedSucceeded) as e:
        feeds.save_report(rep, tmp_path)
    assert str(e.value.code).startswith("Nothing applied: no feed succeeded (weo, bis).")
    with pytest.raises(NoFeedSucceeded):
        feeds.save_vintage(tmp_path, rep)
    assert list(tmp_path.iterdir()) == []


def _tree(d: Path) -> dict:
    return {str(p.relative_to(d)): (p.stat().st_size, p.stat().st_mtime_ns) for p in d.rglob("*")} if d.exists() else {}


@pytest.mark.parametrize("extra", [[], ["--apply"]])
def test_cli_fetch_offline_writes_nothing_and_says_so_once(tmp_path, monkeypatch, capsys, extra):
    d = tmp_path / "data"
    shutil.copytree(DATA, d, ignore=shutil.ignore_patterns("panel", "*.lock"))
    monkeypatch.setattr(feeds.WeoFeed, "cache_file", lambda self: tmp_path / "no_cache.csv")
    probed = []
    monkeypatch.setattr(feeds, "probe_host", lambda host, timeout=feeds.PROBE_TIMEOUT: all_down(probed)(host))
    live_before, seed_before = _tree(d / "live"), (d / "indicators.csv").read_bytes()
    t0 = time.monotonic()
    with pytest.raises(SystemExit) as e:
        cli.main(["--data", str(d), "--out", str(tmp_path / "out"), "fetch", *extra])
    assert time.monotonic() - t0 < 5.0
    assert "Nothing applied: no feed succeeded" in str(e.value.code)
    assert _tree(d / "live") == live_before and (d / "indicators.csv").read_bytes() == seed_before
    out = capsys.readouterr().out
    # one line per feed; stats.bis.org serves bis, bis_cbs and bis_xru (EQ-A-0040)
    assert out.count("[fetch] ") == 7 and out.count("stats.bis.org") == 3
    assert len(probed) == len(set(probed))
