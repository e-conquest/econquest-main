"""Run with: python -m pytest tests  (or python tests/test_econquest.py when pytest is absent)."""
import json, sys
from pathlib import Path
import numpy as np
import pandas as pd
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.config import Settings
from econquest.ingestion import load_universe
from econquest.scorecard import score_universe
from econquest.engine import run_pipeline
from econquest.engine.layer1_hazard import fit_firth
from econquest.engine.layer3_regime import GaussianHMM, transition_matrix
from econquest.engine.layer5_copula import tail_dependence
from econquest.engine.stress import SCENARIOS, compare
from econquest.validation import kupiec, backtest_history
from econquest.engine.common import expit

DATA = ROOT / "data"
SEED = ROOT / "tests" / "seed_data"   # the October 2026 seed snapshot the workbook reference was computed from (data/ now holds live values)
REF = json.loads((DATA / "workbook_reference.json").read_text())


def _run(paths=4000):
    u = load_universe(DATA); s = Settings.load(DATA / "assumptions.json")
    return u, s, run_pipeline(u, s, paths=paths)


def test_scorecard_matches_workbook():
    u = load_universe(SEED); s = Settings.load(SEED / "assumptions.json")
    sc = score_universe(u, s)
    assert np.max(np.abs(sc.composite.to_numpy() - np.array(REF["composite"]))) < 0.15
    for p in range(1, 8):
        assert np.max(np.abs(sc.pillar_final.loc[p].to_numpy() - np.array(REF["final_pillars"][str(p)]))) < 0.1
    assert list(sc.grade) == [int(g) for g in REF["grade"]]


def test_regimes_match_workbook():
    _, _, r = _run(2000)
    assert list(r.country["regime"]) == REF["regime"]


def test_probabilities_are_bounded_and_ordered():
    _, _, r = _run(2000)
    c = r.country
    assert ((c["pd_default"] > 0) & (c["pd_default"] <= 0.99)).all()
    assert c["pd_default"]["Venezuela"] > c["pd_default"]["Argentina"] > c["pd_default"]["Brazil"] > c["pd_default"]["Singapore"]
    assert (c["pd_any"] >= c["pd_default"]).all()


def test_market_prior_blend_direction():
    _, _, r = _run(2000)
    c = r.country
    priced = c["pm_default"].notna()
    # the blended PD lies between the model posterior and the market-implied default probability
    lo = np.minimum(c.loc[priced, "pd_post"], c.loc[priced, "pm_default"]); hi = np.maximum(c.loc[priced, "pd_post"], c.loc[priced, "pm_default"])
    assert ((c.loc[priced, "pd_final"] >= lo - 1e-9) & (c.loc[priced, "pd_final"] <= hi + 1e-9)).all()


def test_transition_weighted_multipliers():
    s = Settings.load(DATA / "assumptions.json")
    P = transition_matrix(s)
    assert np.allclose(P.sum(axis=1), 1)
    _, _, r = _run(2000)
    assert abs(r.country.loc["Vietnam", "pd_mult"] - (0.85 * 1 + 0.12 * 1.25 + 0.03 * 1.6)) < 1e-9


def test_monte_carlo_metrics_consistent():
    _, _, r = _run(8000)
    m = r.metrics
    assert m["var95_mm"] < m["var99_mm"] < m["es99_mm"]
    assert m["es975_frtb_mm"] > m["var975_mm"] if "var975_mm" in m else True
    assert m["lvar99_mm"] == m["var99_mm"] + m["liquidity_cost99_mm"]
    assert abs(m["liquidity_cost99_mm"] - REF["portfolio"]["liq_cost99"]) < 0.05
    assert 0.6 * REF["portfolio"]["var99"] < m["var99_mm"] < 1.6 * REF["portfolio"]["var99"]
    assert r.mc.position_losses.shape == (8192, len(r.positions)) and m["paths_requested"] == 8000   # Sobol rounds up to 2^13 (EQ-B-0007)


def test_sobol_is_reproducible():
    u = load_universe(DATA); s = Settings.load(DATA / "assumptions.json")
    a = run_pipeline(u, s, paths=2000).metrics["var99_mm"]; b = run_pipeline(u, s, paths=2000).metrics["var99_mm"]
    assert a == b


def test_tail_dependence_positive_and_gaussian_limit():
    assert tail_dependence(0.3, 4) > 0.05
    assert tail_dependence(0.3, 1e6) < 1e-6


def test_firth_recovers_signs():
    rng = np.random.default_rng(0)
    X = rng.normal(size=(2000, 3)); beta = np.array([1.0, -0.8, 0.0])
    y = (rng.random(2000) < expit(-2.5 + X @ beta)).astype(float)
    b, info = fit_firth(X, y)
    assert b[1] > 0.5 and b[2] < -0.4 and abs(b[3]) < 0.3


def test_hmm_recovers_three_regimes():
    rng = np.random.default_rng(1)
    states = [0]; P = np.array([[0.95, 0.04, 0.01], [0.10, 0.85, 0.05], [0.05, 0.20, 0.75]])
    for _ in range(599):
        states.append(rng.choice(3, p=P[states[-1]]))
    mu = np.array([[150, 0.5, 0.5], [500, 4, -3], [1500, 15, -10]]); sd = np.array([[60, 1.5, 2], [150, 3, 4], [500, 8, 6]])
    X = np.array([rng.normal(mu[s_], sd[s_]) for s_ in states])
    m = GaussianHMM().fit(X); dec = m.decode(X)
    assert np.mean(dec == np.array(states)) > 0.85
    assert m.A[0, 0] > 0.8


def test_backtests_match_workbook_sample():
    hist = pd.read_csv(DATA / "backtest_history.csv")
    bt = backtest_history(hist, 0.99)
    assert bt["kupiec"]["exceedances"] == 4 and abs(bt["kupiec"]["LR_uc"] - 4.098) < 0.01
    assert abs(bt["christoffersen"]["LR_ind"] - 0.278) < 0.01 and abs(bt["christoffersen"]["LR_cc"] - 4.377) < 0.01
    assert abs(bt["acerbi_szekely"]["Z2"] - (-2.659)) < 0.01
    assert bt["verdict"] == "Fail"


def test_stress_scenarios_raise_tail_risk():
    u, s, base = _run(6000)
    for k, sc in SCENARIOS.items():
        u2, s2 = sc.apply(u, s)
        r2 = run_pipeline(u2, s2, paths=6000)
        c = compare(base, r2)
        assert c["es99_mm"]["stress"] > c["es99_mm"]["base"], k
    uc, sc_ = SCENARIOS["C"].apply(u, s)
    assert compare(base, run_pipeline(uc, sc_, paths=2000))["liquidity_cost99_mm"]["change_pct"] > 50


def test_arbitrage_sizing_rules():
    u, s, r = _run(2000)
    a = r.arbitrage; pm = s["prediction_markets"]
    assert (a.loc[a["net_edge_pp"] < pm["min_net_edge_pp"], "stake_k"] == 0).all()
    assert (a["stake_k"] <= pm["max_share_oi"] * a["open_interest_k"] + 1e-9).all()
    assert set(a["side"]) <= {"Buy Yes", "Buy No"}


if __name__ == "__main__":
    import traceback
    fails = 0
    for name, fn in list(globals().items()):
        if name.startswith("test_") and callable(fn):
            try:
                fn(); print("PASS", name)
            except Exception:
                fails += 1; print("FAIL", name); traceback.print_exc()
    sys.exit(1 if fails else 0)


def test_kupiec_log_form_large_n():
    # EQ-B-0012: raw powers underflowed to log(0) for long histories; the log form stays finite
    import numpy as np
    exceed = np.zeros(5000, dtype=bool); exceed[:60] = True
    k = kupiec(exceed, 0.99)
    assert np.isfinite(k["LR_uc"]) and k["LR_uc"] > 0
    lr = -2 * ((5000 - 60) * np.log(0.99) + 60 * np.log(0.01) - (5000 - 60) * np.log(1 - 0.012) - 60 * np.log(0.012))
    assert abs(k["LR_uc"] - lr) < 1e-9
    assert abs(kupiec(np.zeros(250, dtype=bool), 0.99)["LR_uc"] + 2 * 250 * np.log(0.99)) < 1e-9
    assert abs(kupiec(np.ones(10, dtype=bool), 0.99)["LR_uc"] + 2 * 10 * np.log(0.01)) < 1e-9
