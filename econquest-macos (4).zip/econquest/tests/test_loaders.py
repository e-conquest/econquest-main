"""EQ-A-0028: loader contract additions. blank Yes/No cells recorded before they read as "No" (HO-20261023-B-A-007),
Universe.wb_raw from live/raw_worldbank_history.csv (HO-20261023-B-A-006) and Universe.events from
live/events/events_long.csv (HO-20261023-B-A-004). Offline: the seed data folder copied to tmp."""
import dataclasses
import shutil
import sys
from pathlib import Path

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.ingestion import Universe, load_universe  # noqa: E402
from econquest.ingestion.loaders import YES_NO, _blank_yes_no  # noqa: E402
from econquest.ingestion.sources import read_csv_keep_na_code  # noqa: E402

SEED = ROOT / "tests" / "seed_data"
DATA = ROOT / "data"


@pytest.fixture
def d(tmp_path):
    out = tmp_path / "data"
    shutil.copytree(SEED, out)
    return out


def _wb_history(isos=("VNM", "BRA")) -> pd.DataFrame:
    rows = [{"iso": i, "series": s, "period": y, "value": 10.0 + y - 2000, "source": "fake wbgapi"}
            for i in isos for s in ("DT.DOD.DSTC.IR.ZS", "FI.RES.TOTL.MO", "PV.EST") for y in range(1996, 2026)]
    return pd.DataFrame(rows)


def test_shipped_universe_has_no_blank_flags_and_new_fields_default_none():
    u = load_universe(DATA)
    assert u.provenance["blank_yes_no"] == {}
    for c in ("default", "coup", "CDS"):
        assert u.countries[c].dtype == bool


def test_blank_yes_no_recorded_before_they_read_as_no(d):
    cty = read_csv_keep_na_code(d / "countries.csv", dtype=str)
    a, b = cty["country"].iloc[0], cty["country"].iloc[1]
    cty.loc[0, "default"] = ""
    cty.loc[0, "coup"] = "  "
    cty.loc[1, "CDS"] = ""
    cty.to_csv(d / "countries.csv", index=False)
    u = load_universe(d)
    blank = u.provenance["blank_yes_no"]
    assert blank == {a: ["default", "coup"], b: ["CDS"]}
    assert not bool(u.countries.set_index("country").at[a, "default"])       # still False after loading, now visible
    # the readiness check reads the key: blank override flags block, instrument flags do not
    from econquest.scorecard import check_readiness
    fr = check_readiness(u).to_frame()
    blk = set(fr.loc[fr["blocking"] & (fr["country"] == a), "field"])
    assert {"flag default", "flag coup"} <= blk
    assert not any("CDS" in f for f in fr.loc[fr["country"] == b, "field"])


def test_blank_yes_no_helper_handles_nan_and_text():
    df = pd.DataFrame({"country": ["X", "Y", "Z"], "default": ["Yes", float("nan"), "No"], "Equity": ["", "No", " "]})
    assert _blank_yes_no(df) == {"X": ["Equity"], "Y": ["default"], "Z": ["Equity"]}
    assert set(YES_NO) >= {"default", "Equity"}


def test_wb_raw_none_without_file_and_loaded_with_it(d):
    u = load_universe(d)
    assert u.wb_raw is None and "wb_raw" not in u.provenance
    (d / "live").mkdir(exist_ok=True)
    _wb_history().to_csv(d / "live" / "raw_worldbank_history.csv", index=False)
    u = load_universe(d)
    assert list(u.wb_raw.columns[:4]) == ["iso", "series", "period", "value"]
    assert set(u.wb_raw["series"]) == {"DT.DOD.DSTC.IR.ZS", "FI.RES.TOTL.MO", "PV.EST"}
    assert pd.api.types.is_numeric_dtype(u.wb_raw["period"]) and pd.api.types.is_numeric_dtype(u.wb_raw["value"])
    assert u.wb_raw["iso"].map(type).eq(str).all() and u.wb_raw["period"].min() == 1996
    assert u.provenance["wb_raw"] == "csv:live/raw_worldbank_history.csv"


def test_universe_positional_and_keyword_construction_still_valid():
    u = load_universe(DATA)
    base = (u.countries, u.indicators, u.rulebook, u.adjustments, u.portfolio, u.markets)
    for v in (Universe(*base), Universe(*base, {}, None, None, None, None),
              Universe(countries=u.countries, indicators=u.indicators, rulebook=u.rulebook, adjustments=u.adjustments,
                       portfolio=u.portfolio, markets=u.markets)):
        assert v.wb_raw is None and v.events is None and v.validate() == []
    names = [f.name for f in dataclasses.fields(Universe)]
    assert names.index("wb_raw") > names.index("prices") and names[-2:] == ["wb_raw", "events"]


def test_events_long_loaded_when_present(d):
    from econquest.ingestion.events.export import LONG_COLUMNS, LONG_PATH
    assert load_universe(d).events is None
    p = d / LONG_PATH; p.parent.mkdir(parents=True)
    pd.DataFrame([{"iso": "VNM", "source": "ucdp_ged", "series": "events", "freq": "M", "period": "2026-08-01", "value": 3,
                   "vintage": "2026-10-23", "provenance": "test"}], columns=LONG_COLUMNS).to_csv(p, index=False)
    u = load_universe(d)
    assert len(u.events) == 1 and u.provenance["events"] == "csv:live/events/events_long.csv"
    assert pd.api.types.is_datetime64_any_dtype(u.events["period"])
