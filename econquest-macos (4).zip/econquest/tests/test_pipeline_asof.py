"""EQ-B-0001 / GOV-012: the run's as-of date is recorded in settings and is the only date the model reads.

Two runs with the same inputs and as_of must give identical numbers on any calendar day; a different
as_of must move the prediction-market horizons (layer 2 prior and arbitrage scan) and the WEO year
used by layer 1."""
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.config import Settings
from econquest.ingestion import load_universe
from econquest.engine import run_pipeline
from econquest.engine import layer1_hazard as L1, layer2_bayesian as L2
from econquest.scorecard import score_universe

DATA = ROOT / "data"
PATHS = 2000


def _freeze_today(mp, when: str):
    """Make pandas' wall clock return `when` (simulates running the program on another calendar day)."""
    fake = pd.Timestamp(when)
    mp.setattr(pd.Timestamp, "today", classmethod(lambda cls, tz=None: fake))
    mp.setattr(pd.Timestamp, "now", classmethod(lambda cls, tz=None: fake))


def _forbid_clock(mp):
    def boom(cls, tz=None):
        raise AssertionError("model code read the wall clock")
    mp.setattr(pd.Timestamp, "today", classmethod(boom))
    mp.setattr(pd.Timestamp, "now", classmethod(boom))


@pytest.fixture(scope="module")
def inputs():
    return load_universe(DATA), Settings.load(DATA / "assumptions.json")


@pytest.fixture(scope="module")
def runs(inputs):
    u, s = inputs
    out = {}
    with pytest.MonkeyPatch.context() as mp:
        _freeze_today(mp, "2026-10-23 09:15")
        out["d1"] = run_pipeline(u, s, paths=PATHS, as_of="2026-10-23")
        _freeze_today(mp, "2027-02-14 23:59")
        out["d2"] = run_pipeline(u, s, paths=PATHS, as_of="2026-10-23")
        out["later"] = run_pipeline(u, s, paths=PATHS, as_of="2027-03-01")
        out["default"] = run_pipeline(u, s, paths=PATHS)          # no as_of: today, resolved once
    return out


def test_same_as_of_identical_on_different_days(runs):
    a, b = runs["d1"], runs["d2"]
    assert a.settings["as_of"] == b.settings["as_of"] == "2026-10-23"
    pd.testing.assert_frame_equal(a.country, b.country)
    pd.testing.assert_frame_equal(a.arbitrage, b.arbitrage)
    for k in ("pd_post", "pm_default", "pd_final", "pd_default"):
        np.testing.assert_array_equal(a.country[k].to_numpy(), b.country[k].to_numpy())
    assert a.metrics == b.metrics


def test_different_as_of_moves_prediction_market_horizon(runs):
    a, c = runs["d1"], runs["later"]
    da = (pd.Timestamp("2027-03-01") - pd.Timestamp("2026-10-23")).days / 30.4375
    # every contract still more than half a month out shortens by the as-of gap
    m = a.arbitrage["months"].to_numpy(); mc = c.arbitrage["months"].to_numpy()
    live = (m - da) > 0.6
    assert live.any() and np.allclose(m[live] - mc[live], da, atol=0.11)   # months are rounded to 0.1
    # layer 2 market prior (12-month equivalent of the default contracts) changes with the horizon
    pa, pc = a.country["pm_default"].dropna(), c.country["pm_default"].dropna()
    assert len(pa) and not np.allclose(pa.to_numpy(), pc.reindex(pa.index).to_numpy())


def test_as_of_recorded_in_run_and_caller_settings_untouched(inputs, runs):
    _, s = inputs
    r = runs["default"]
    assert r.settings["as_of"] == "2027-02-14"            # the frozen 'today' at that moment
    assert r.summary()["as_of"] == "2027-02-14" and r.to_dict()["settings"]["as_of"] == "2027-02-14"
    assert "as_of" not in s.raw                            # run_pipeline does not mutate the caller's Settings


def test_settings_as_of_used_and_no_wall_clock_read(inputs, monkeypatch):
    """settings['as_of'] is honoured without an argument, the explicit argument wins, and with an as-of
    date the whole pipeline runs with pandas' clock disabled."""
    u, s = inputs
    _forbid_clock(monkeypatch)
    r = run_pipeline(u, s.copy_with(as_of="2026-10-23"), paths=500)
    assert r.settings["as_of"] == "2026-10-23"
    r2 = run_pipeline(u, s.copy_with(as_of="2026-10-23"), paths=500, as_of="2027-03-01")
    assert r2.settings["as_of"] == "2027-03-01"


def test_layer_functions_take_as_of_explicitly(inputs, monkeypatch):
    u, s = inputs
    _forbid_clock(monkeypatch)
    p1 = L2.default_contract_prior(u, s, as_of="2026-10-23")
    p2 = L2.default_contract_prior(u, s.copy_with(as_of="2026-10-23"))
    pd.testing.assert_frame_equal(p1, p2)
    with pytest.raises(ValueError):
        L2.default_contract_prior(u, s)                    # no as-of anywhere: refuse rather than read the clock


def test_layer1_weo_year_follows_as_of(inputs, monkeypatch):
    u, s = inputs
    if u.weo_raw is None:
        pytest.skip("no data/live/raw_weo.csv")
    _forbid_clock(monkeypatch)
    sc = score_universe(u, s)
    p4 = sc.pillar_aggregated.loc[4]
    x26 = L1.build_features(u, p4, as_of="2026-10-23")
    x27 = L1.build_features(u, p4, as_of="2027-01-02")
    assert x26.attrs["primary_deficit_source"].endswith("2026") and x27.attrs["primary_deficit_source"].endswith("2027")
    assert not np.allclose(x26["primary_deficit"].to_numpy(), x27["primary_deficit"].to_numpy())
    pd.testing.assert_frame_equal(x26[L1.FEATURES], x27[L1.FEATURES])   # the paper-mode features carry no date
    with pytest.raises(ValueError):
        L1.build_features(u, p4)


def test_run_versions_carry_as_of_and_run_hash(inputs):
    # EQ-B-0017 (HO-20261023-C-B-002): versions get the resolved as_of and a run_hash that depends on it;
    # u.provenance (shared by stress runs) is not mutated
    u, s = inputs
    before = dict(u.provenance.get("versions") or {})
    a = run_pipeline(u, s, paths=PATHS, as_of="2026-10-23").provenance["versions"]
    b = run_pipeline(u, s, paths=PATHS, as_of="2026-11-23").provenance["versions"]
    assert a["as_of"] == "2026-10-23" and b["as_of"] == "2026-11-23"
    assert a["run_hash"] and a["run_hash"] != b["run_hash"]
    assert a["code_hash"] == b["code_hash"] and a["data_hash"] == b["data_hash"]
    assert (u.provenance.get("versions") or {}) == before
