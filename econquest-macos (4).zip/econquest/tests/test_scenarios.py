"""Scenario library (data/scenarios.json), shock engine and reverse stress (roadmap 3.4)."""
import sys
from pathlib import Path
import pandas as pd
import pytest
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from econquest.config import Settings
from econquest.ingestion import load_universe
from econquest.engine import run_pipeline
from econquest.engine import stress as ST
from econquest.engine.limits import load_limits

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"


def _load():
    return load_universe(DATA), Settings.load(DATA / "assumptions.json")


def test_library_reproduces_legacy_paper_scenarios():
    u, s = _load(); scen = ST.load_scenarios(DATA / "scenarios.json")
    for k in "ABC":
        u1, s1 = ST.LEGACY[k].apply(u, s); u2, s2 = scen[k].apply(u, s)
        for name in ("countries", "indicators", "adjustments", "portfolio"):
            pd.testing.assert_frame_equal(getattr(u1, name).reset_index(drop=True), getattr(u2, name).reset_index(drop=True), check_dtype=False, check_like=True)
        assert s1.raw == s2.raw, k


def test_every_scenario_applies_and_scales():
    u, s = _load(); scen = ST.load_scenarios(DATA / "scenarios.json")
    assert len(scen) >= 9 and {"ASIA97", "GFC08", "TAPER13", "COVID20", "FED22", "DOWNGRADE"} <= set(scen)
    for sc in scen.values():
        u2, s2 = sc.apply(u, s)
        assert len(u2.countries) == len(u.countries) and u.countries["spread"].equals(load_universe(DATA).countries["spread"])  # inputs untouched
        u0, s0 = sc.apply(u, s, scale=0.0)
        pd.testing.assert_frame_equal(u0.countries, u.countries); assert s0.raw == s.raw
        uh, _ = sc.apply(u, s, scale=0.5)
        dh = (pd.to_numeric(uh.countries["spread"]) - pd.to_numeric(u.countries["spread"])).abs().sum()
        d1 = (pd.to_numeric(u2.countries["spread"]) - pd.to_numeric(u.countries["spread"])).abs().sum()
        assert dh <= d1 + 1e-9, sc.key


def test_where_clauses_and_ops():
    u, s = _load(); c = u.countries
    m = ST.select(c, {"region_in": ["Asia"], "spread_gte": 60, "rating_not_in": ["A+"]})
    assert set(c.loc[m, "country"]) == {"Vietnam", "Philippines", "India", "Pakistan"}
    with pytest.raises(ValueError):
        ST.select(c, {"region": ["Asia"]})
    u2, s2 = ST.apply_shocks(u, s, [{"target": "countries", "column": "rating", "op": "notch", "value": -2, "where": {"country_in": ["Brazil"]}},
                                    {"target": "settings", "key": "regime.*.global_loading", "op": "add", "value": 0.5, "max": 0.9},
                                    {"target": "settings", "key": "market.lgd_hard", "op": "add", "value": 50, "max": 95},
                                    {"target": "trigger", "pillar": 3, "value": 10, "where": {"region_in": ["LatAm"]}}])
    assert u2.countries.set_index("country").loc["Brazil", "rating"] == "B+"            # BB -> BB- -> B+
    assert s2["regime"]["Crisis"]["global_loading"] == 0.85 and s2["regime"]["regional_loading"] == s["regime"]["regional_loading"]
    assert s2["market"]["lgd_hard"] == 95
    row = u2.adjustments.iloc[-1]; assert row["pillar"] == 3 and row["Brazil"] == 10 and row["China"] == 0


def test_historical_scenarios_raise_tail_risk():
    u, s = _load(); scen = ST.load_scenarios(DATA / "scenarios.json")
    base = run_pipeline(u, s, paths=4000)
    for k in ("GFC08", "COVID20"):
        u2, s2 = scen[k].apply(u, s)
        r = run_pipeline(u2, s2, paths=4000)
        assert r.metrics["es99_mm"] > base.metrics["es99_mm"] * 1.3, k


def test_reverse_stress_finds_spread_breach():
    u, s = _load(); lim = load_limits(DATA / "limits.json")
    base = run_pipeline(u, s, paths=3000)
    r = ST.single_factor_reverse(u, s, lim, "spread_bp", "var99_mm", paths=3000, base=base)
    assert r["status"] == "breach found" and 100 < r["breach_size"] < 2000
    assert r["value_at_breach"] >= r["limit"] and r["path"][0]["scale"] == 0.0
    low = dict(lim); low["book"] = dict(lim["book"], var99_mm=base.metrics["var99_mm"] - 1)
    r2 = ST.reverse_stress(u, s, ST.load_scenarios(DATA / "scenarios.json")["A"], low, "var99_mm", paths=3000, base=base)
    assert r2["status"] == "already breached" and r2["breach_scale"] == 0.0
    big = dict(lim); big["book"] = dict(lim["book"], var99_mm=1e6)
    r3 = ST.reverse_stress(u, s, ST.load_scenarios(DATA / "scenarios.json")["A"], big, "var99_mm", paths=3000, scale_max=1.0, base=base)
    assert r3["breach_scale"] is None and "no breach" in r3["status"]


# ---------------------------------------------------------------- EQ-B-0043: tier filters (DM anchors, Hormuz Middle East)

STAGING = DATA / "panel" / "universe_staging" / "countries.csv"


def _staging_countries():
    if not STAGING.is_file():
        pytest.skip("88-country staging Country Profile not present")
    return pd.read_csv(STAGING, keep_default_na=False)


def _drop_tier_clauses(shocks):
    out = []
    for sh in shocks:
        sh = dict(sh)
        if sh.get("where"):
            sh["where"] = {k: v for k, v in sh["where"].items() if not k.startswith("tier_")}
        out.append(sh)
    return out


def test_tier_falls_back_to_universe_proposal_and_column_wins():
    u, _ = _load(); c = u.countries
    assert set(ST.country_tiers(c)) == {"desk_current"}                       # the 18 desk countries
    if "tier" in c.columns:                                                  # HO-20261023-B-A-008: profile column is the source
        assert ST.country_tiers(c).equals(c["tier"].astype(object))
        c = c.drop(columns="tier")                                           # below: the proposal fallback path
    c2 = c.copy(); c2["tier"] = ["EM"] + [""] * (len(c) - 1)                  # a Country Profile tier column wins where filled
    t = ST.country_tiers(c2)
    assert t.iloc[0] == "EM" and set(t.iloc[1:]) == {"desk_current"}
    c3 = c.copy(); c3.loc[0, "iso"] = "XXX"                                  # not in the proposal -> unknown
    assert ST.country_tiers(c3).iloc[0] == "unknown"
    assert not ST.select(c3, {"tier_in": ["desk_current"]}).iloc[0] and ST.select(c3, {"tier_not_in": ["DM_anchor"]}).iloc[0]
    with pytest.raises(ValueError, match="unknown tier"):
        ST.select(c, {"tier_in": ["DM"]})


def test_dm_anchors_left_out_of_em_shocks_in_88_universe():
    c = _staging_countries().copy(); scen = ST.load_scenarios(DATA / "scenarios.json", include_unavailable=True)
    if "tier" in c.columns:                                                  # HO-20261023-B-A-008: staged profile tier column
        assert set(c["tier"]) <= {"desk_current", "EM", "frontier", "DM_anchor"} and ST.country_tiers(c).equals(c["tier"].astype(object))
    c["spread"] = pd.to_numeric(c["spread"], errors="coerce").fillna(50.0)   # test value: staging spreads are still blank
    tiers = ST.country_tiers(c); dm = set(c.loc[tiers == "DM_anchor", "country"])
    assert dm == {"United States", "Germany", "United Kingdom", "France", "Italy", "Canada", "Australia"}
    picked = lambda w: set(c.loc[ST.select(c, w), "country"])
    a_spread = scen["A"].shocks[1]["where"]; assert "region_not_in" in a_spread
    assert not (picked(a_spread) & dm) and picked(_drop_tier_clauses([scen["A"].shocks[1]])[0]["where"]) & dm   # the bug: DM anchors were picked
    asia_fx = scen["ASIA97"].shocks[0]["where"]
    assert "Australia" not in picked(asia_fx) and "Japan" in picked(asia_fx)  # Japan is a desk country, unchanged
    for k, sc in scen.items():                                               # no regional or EM-currency shock reaches a DM anchor
        for sh in sc.shocks:
            w = sh.get("where") or {}
            if sh["target"] == "countries" and sh.get("column") in ("spread", "fx3m") and any(q.startswith("region_") for q in w):
                assert not (picked(w) & dm), (k, sh)


def test_hormuz_middle_east_exporters_get_no_windfall():
    c = _staging_countries().copy(); sc = ST.load_scenarios(DATA / "scenarios.json")["HORMUZ"]
    gulf = c["region"] == "Middle East"; c.loc[gulf, "exptype"] = "Commodity"          # exptype is still blank in staging
    picked = lambda sh: set(c.loc[ST.select(c, sh.get("where")), "country"])
    me = set(c.loc[gulf, "country"])
    windfall = [sh for sh in sc.shocks if sh.get("column") == "commgap"][0]
    assert not (picked(windfall) & me) and "Nigeria" in picked(windfall)
    me_spread = [sh for sh in sc.shocks if sh.get("column") == "spread" and (sh.get("where") or {}).get("region_in") == ["Middle East"]]
    assert len(me_spread) == 1 and me_spread[0]["value"] == 150 and picked(me_spread[0]) == me


def test_tier_clauses_do_not_change_the_18_country_scenarios():
    """Characterisation: on the desk universe every tier clause is a no-op (EQ-B-0043)."""
    u, s = _load(); scen = ST.load_scenarios(DATA / "scenarios.json")
    for k, sc in scen.items():
        u1, s1 = sc.apply(u, s)
        u2, s2 = ST.apply_shocks(u, s, _drop_tier_clauses(sc.shocks), base_dir=sc.base_dir)
        for name in ("countries", "indicators", "adjustments", "portfolio"):
            pd.testing.assert_frame_equal(getattr(u1, name), getattr(u2, name), obj=f"{k}.{name}")
        assert s1.raw == s2.raw, k


def test_unknown_tier_warns():
    # PI-4 review (Low): tier "unknown" passes every tier_not_in clause, so it is announced
    import warnings as _w
    import pandas as _pd
    from econquest.engine import stress as _S
    t = _pd.DataFrame({"country": ["Nowhere"], "iso": ["XQZ"]})
    with _w.catch_warnings(record=True) as rec:
        _w.simplefilter("always")
        assert _S.country_tiers(t).tolist() == ["unknown"]
    assert any("tier unknown for Nowhere" in str(r.message) for r in rec)


def test_fed22_and_taper13_carry_sams_rate_shocks():
    # Sam's decision card 2026-10-23 22:52Z: FED22 +200 bp, TAPER13 +100 bp on local and hard-currency yields
    import json as _json
    from pathlib import Path as _P
    d = _json.loads((_P(__file__).resolve().parents[1] / "data" / "scenarios.json").read_text())
    got = {s["key"]: sorted((x["leg"], x["value"]) for x in s["shocks"] if x.get("target") == "rates") for s in d["scenarios"]}
    assert got["FED22"] == [("hard", 200), ("local", 200)] and got["TAPER13"] == [("hard", 100), ("local", 100)]
    assert all(not v for k, v in got.items() if k not in ("FED22", "TAPER13"))
