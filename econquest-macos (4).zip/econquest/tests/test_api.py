"""Local JSON API and GUI helpers (EQ-C-0003): read endpoints, workbench rerun, SSE hub, bad bodies, GUI table/status
routes and the job runner's command allow-list. No browser and no network: servers bind 127.0.0.1 on a free port."""
import http.client
import json
import sys
import threading
from http.server import ThreadingHTTPServer
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.config import Settings  # noqa: E402
from econquest.ingestion import load_universe  # noqa: E402
from econquest.engine import run_pipeline  # noqa: E402
from econquest.persistence import Store  # noqa: E402
from econquest.presentation import api  # noqa: E402
from econquest.presentation import gui  # noqa: E402

DATA = ROOT / "data"


@pytest.fixture(scope="module")
def result():
    u = load_universe(DATA); s = Settings.load(DATA / "assumptions.json")
    try:
        return run_pipeline(u, s, paths=2000, as_of="2026-10-23")
    except TypeError:
        return run_pipeline(u, s, paths=2000)


@pytest.fixture(scope="module")
def app(result, tmp_path_factory):
    store_dir = tmp_path_factory.mktemp("store")
    Store(store_dir).save_run(result, keep_paths=False)
    return api.App(str(DATA), str(store_dir))                 # latest run exists, so no 100k-path rerun at start


def _serve(handler):
    srv = ThreadingHTTPServer(("127.0.0.1", 0), handler)
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    return srv


@pytest.fixture
def api_server(app):
    srv = _serve(api.make_handler(app))
    yield srv.server_address[1]
    srv.shutdown(); srv.server_close()


def req(port, method, path, body=None, headers=None, read=True):
    conn = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
    h = {"Host": f"127.0.0.1:{port}"}; h.update(headers or {})
    conn.request(method, path, body=body, headers=h)
    r = conn.getresponse()
    return (r.status, dict(r.getheaders()), r.read().decode()) if read else (r.status, dict(r.getheaders()), r)


def post_headers(app, port):
    return {"Content-Type": "application/json", api.TOKEN_HEADER: app.token, "Origin": f"http://127.0.0.1:{port}"}


def test_app_loads_latest_without_rerun(app, result):
    assert app.latest["summary"]["run_id"] == result.run_id and len(app.token) >= 32


def test_read_endpoints(api_server, app, result):
    port = api_server
    st, h, body = req(port, "GET", "/")
    assert st == 200 and h["Content-Type"].startswith("text/html") and result.run_id in body
    st, _, body = req(port, "GET", "/api/runs")
    assert st == 200 and [r["run_id"] for r in json.loads(body)] == [result.run_id]
    st, _, body = req(port, "GET", "/api/run/latest")
    assert st == 200 and json.loads(body)["summary"]["run_id"] == result.run_id
    st, _, body = req(port, "GET", "/api/countries")
    rows = json.loads(body)
    assert st == 200 and len(rows) == 18 and all(0 <= r["pd_default"] <= 1 for r in rows)
    st, _, body = req(port, "GET", "/api/portfolio")
    p = json.loads(body)
    assert st == 200 and set(p) == {"metrics", "contributions", "by_country", "loss_quantiles"} and p["metrics"]["var99_mm"] == pytest.approx(result.metrics["var99_mm"])
    st, _, body = req(port, "GET", "/api/arbitrage")
    assert st == 200 and isinstance(json.loads(body), list)
    st, _, body = req(port, "GET", "/api/series?metric=var99_mm")
    assert st == 200 and isinstance(json.loads(body), list)
    st, _, body = req(port, "GET", "/nope")
    assert st == 404 and json.loads(body)["error"] == "not found"


def test_get_refused_for_foreign_host(api_server):
    st, _, body = req(api_server, "GET", "/api/runs", headers={"Host": "evil.example:80"})
    assert st == 403 and "host" in json.loads(body)["error"]


def test_post_bad_bodies_get_400(api_server, app):
    """Regression: a POST whose body was not JSON raised inside the handler and dropped the connection."""
    port = api_server
    st, _, body = req(port, "POST", "/api/workbench", body="{not json", headers=post_headers(app, port))
    assert st == 400 and "JSON" in json.loads(body)["error"]
    st, _, body = req(port, "POST", "/api/workbench", body="[1, 2]", headers=post_headers(app, port))
    assert st == 400
    st, _, _ = req(port, "POST", "/api/other", body="{}", headers=post_headers(app, port))
    assert st == 404


def test_workbench_post_reruns_and_publishes(api_server, app, monkeypatch):
    calls = []

    def fake_rerun(body):
        calls.append(body)
        return {"summary": {"run_id": "wb-1", "label": "workbench"}}
    monkeypatch.setattr(app, "rerun", fake_rerun)
    port = api_server
    st, _, body = req(port, "POST", "/api/workbench", body=json.dumps({"analyst": {"Argentina": {"4": 5}}, "paths": 2000}), headers=post_headers(app, port))
    assert st == 200 and json.loads(body)["run_id"] == "wb-1" and calls == [{"analyst": {"Argentina": {"4": 5}}, "paths": 2000}]


def test_rerun_keeps_every_universe_field(app, monkeypatch):
    """Regression: App.rerun rebuilt the Universe positionally and dropped weo_raw and prices, so a workbench run lost
    the hazard history and the HMM price input that base runs have. Only the adjustments may change."""
    seen = {}

    class FakeRes:
        def to_dict(self):
            return {"summary": {"run_id": "wb-2", "label": "workbench"}}

    def fake_pipeline(u2, s, label="base", paths=None, **kw):
        seen.update(u=u2, label=label, paths=paths, settings=s)
        return FakeRes()
    monkeypatch.setattr(api, "run_pipeline", fake_pipeline)
    monkeypatch.setattr(app.store, "save_run", lambda res, keep_paths=False: None)
    q = app.hub.subscribe()
    before = app.latest
    try:
        out = app.rerun({"analyst": {"Argentina": {"4": 5}}, "paths": 3000, "scenario": "All stressed"})
    finally:
        app.latest = before
    u, u2 = app.universe, seen["u"]
    for f in ("countries", "indicators", "rulebook", "portfolio", "markets", "provenance", "gpr", "playbook", "weo_raw", "prices"):
        assert getattr(u2, f) is getattr(u, f), f
    adj = u2.adjustments; mask = (adj["block"] == "Analyst adjustment") & (adj["pillar"].astype(int) == 4)
    assert (adj.loc[mask, "Argentina"] == 5.0).all() and not u.adjustments.equals(adj)     # caller's universe untouched
    assert seen["label"] == "workbench" and seen["paths"] == 3000 and seen["settings"].scenario_override == "All stressed"
    assert out["summary"]["run_id"] == "wb-2" and q.get_nowait() == ("run", {"run_id": "wb-2", "label": "workbench"})


def test_hub_fans_out_to_every_subscriber():
    hub = api.Hub(); a, b = hub.subscribe(), hub.subscribe()
    hub.publish("run", {"x": 1})
    assert a.get_nowait() == ("run", {"x": 1}) and b.get_nowait() == ("run", {"x": 1})


def test_sse_frame_is_one_data_line():
    """Regression: the SSE payload was indented JSON over many lines, so an EventSource client got only "{"."""
    frame = api.sse_frame("run", {"run_id": "r1", "nested": {"a": [1, 2]}, "text": "line1\nline2"}).decode()
    lines = frame.split("\n")
    assert lines[0] == "event: run" and lines[1].startswith("data: ") and lines[2:] == ["", ""]
    assert json.loads(lines[1][6:]) == {"run_id": "r1", "nested": {"a": [1, 2]}, "text": "line1\nline2"}


def test_sse_sends_summary_on_connect(api_server, result):
    st, h, r = req(api_server, "GET", "/events", read=False)
    assert st == 200 and h["Content-Type"] == "text/event-stream"
    assert r.readline().decode().strip() == "event: run"
    data = r.readline().decode()
    assert data.startswith("data: ") and json.loads(data[6:])["run_id"] == result.run_id
    r.close()


# ---------------------------------------------------------------- GUI helpers (gui.py is read, not changed, here)
def test_records_helper_turns_inf_into_null():
    out = json.loads(gui._records(pd.DataFrame({"a": [1.0, np.inf, -np.inf, np.nan], "d": pd.to_datetime(["2026-10-23"] * 4)})))
    assert [r["a"] for r in out] == [1.0, None, None, None] and out[0]["d"].startswith("2026-10-23")


def test_jobs_refuse_unknown_command_and_list_empty(tmp_path):
    jobs = gui.Jobs(str(DATA), str(tmp_path))
    with pytest.raises(ValueError):
        jobs.start("rm", ["-rf", "/"])
    assert jobs.list() == [] and not jobs.running()
    assert {"run", "publish", "report"} <= gui.ALLOWED_CMDS


def test_jobs_view_masks_secrets_and_tails_log(tmp_path):
    jobs = gui.Jobs(str(DATA), str(tmp_path))
    job = {"id": 1, "cmd": "run", "argv": "x", "status": "done", "log": [str(i) for i in range(10)], "returncode": 0, "finished": "t", "started": "t"}
    jobs.jobs.append(job)
    v = jobs.view(job, tail=3)
    assert v["log"] == ["7", "8", "9"] and v["id"] == 1 and jobs.list()[0]["log"][-1] == "9"


@pytest.fixture
def gui_server(app, tmp_path):
    out = tmp_path / "outputs"; (out / "garch").mkdir(parents=True)
    pd.DataFrame({"country": ["Brazil"], "pd": [0.01]}).to_csv(out / "country_risk.csv", index=False)
    pd.DataFrame({"ticker": ["EWZ"], "vol": [np.inf]}).to_csv(out / "garch" / "series.csv", index=False)
    (out / "stress.json").write_text(json.dumps({"A": {"name": "x"}}))
    data = tmp_path / "data"; data.mkdir()
    pd.DataFrame({"country": ["Brazil"]}).to_csv(data / "countries.csv", index=False)
    srv = _serve(gui.make_gui_handler(app, gui.Jobs(str(data), str(out)), out, data))
    yield srv.server_address[1]
    srv.shutdown(); srv.server_close()


def test_gui_table_json_and_data_routes(gui_server):
    port = gui_server
    st, _, body = req(port, "GET", "/api/table/country_risk")
    assert st == 200 and isinstance(json.loads(body), list)
    st, _, body = req(port, "GET", "/api/table/garch/series")
    assert st == 200 and json.loads(body)[0]["vol"] is None
    st, _, body = req(port, "GET", "/api/json/stress")
    assert st == 200 and json.loads(body)["A"]["name"] == "x"
    st, _, body = req(port, "GET", "/api/data/countries")
    assert st == 200 and json.loads(body) == [{"country": "Brazil"}]
    for path in ("/api/table/missing", "/api/table/../secret", "/api/data/..%2Fassumptions", "/api/json/nope", "/static/../gui.py", "/api/job/99"):
        assert req(port, "GET", path)[0] == 404, path


def test_gui_status_and_jobs(gui_server, app):
    port = gui_server
    st, _, body = req(port, "GET", "/api/status")
    s = json.loads(body)
    assert st == 200 and s["run_id"] == app.latest["summary"]["run_id"] and s["stress"]["exists"] and not s["backtest"]["exists"]
    st, _, body = req(port, "GET", "/api/jobs")
    assert st == 200 and json.loads(body) == {"running": False, "jobs": []}
    st, _, body = req(port, "POST", "/api/job", body=json.dumps({"cmd": "bogus"}), headers=post_headers(app, port))
    assert st == 400 and "unknown command" in json.loads(body)["error"]
