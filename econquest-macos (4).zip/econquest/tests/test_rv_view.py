"""Relative-value views (EQ-C-0046, contract HO-20261023-B-C-014): outputs/bond_rv.csv, bond_rv_positions.csv and
cds_curves.csv read by column name into the GUI Relative value tab (GET /api/rv), the country-note RV section (HTML and
Markdown, escaped) and the opt-in workbook 'Weekly RV' tab (ranges valid, C11 unchanged, text formula-escaped).
Both Team B fixtures render; the SYNTHETIC marker and curve flags show; missing / empty files are clean states and never
fall back to fixture data. Fixtures are copied into tmp dirs; no network, no live Sheets write (publish runs dry)."""
import http.client
import json
import re
import shutil
import sys
import threading
from http.server import ThreadingHTTPServer
from pathlib import Path

import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from econquest import cli  # noqa: E402
from econquest.config import Settings  # noqa: E402
from econquest.engine import run_pipeline  # noqa: E402
from econquest.ingestion import load_universe  # noqa: E402
from econquest.presentation import api  # noqa: E402
from econquest.presentation import country_note as N  # noqa: E402
from econquest.presentation import rv_view as R  # noqa: E402
from econquest.presentation import sheets_publish as SP  # noqa: E402
from econquest.presentation.gui import make_gui_handler  # noqa: E402
from test_gui_security import StubJobs, good  # noqa: E402
from test_workbook_v2 import V1_RANGES  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
FIX = ROOT / "tests" / "fixtures" / "cds"
AS_OF = "2026-10-23"
PAGE = (Path(api.__file__).parent / "static" / "gui.html").read_text()
EVIL = '=HYPERLINK("http://evil.example","x")<img src=x onerror=alert(1)>|x\n## Fake heading'
SYN_SOURCE = "CDS curve SYN-XAA-1 as of 2026-10-20 (SYNTHETIC)"


def outputs(tmp_path: Path, rv=True, curves=True, positions=False) -> Path:
    out = tmp_path / "outputs"; out.mkdir(parents=True, exist_ok=True)
    if rv:
        shutil.copy(FIX / "bond_rv_fixture.csv", out / "bond_rv.csv")
    if curves:
        shutil.copy(FIX / "cds_curves_fixture.csv", out / "cds_curves.csv")
    if positions:
        df = pd.read_csv(FIX / "bond_rv_fixture.csv").head(3)
        df.insert(0, "duration_yrs", 5.0); df.insert(0, "notional_mm", 10.0); df.insert(0, "direction", "Long")
        df.insert(0, "asset_class", "Eurobond"); df.insert(0, "id", [f"P{i}" for i in range(len(df))])
        df["z_xs"] = None; df["for_position"] = "favourable"
        df.to_csv(out / "bond_rv_positions.csv", index=False)
    return out


# ---------------------------------------------------------------- the view
def test_both_fixtures_render(tmp_path):
    s = R.rv_summary(outputs(tmp_path, positions=True))
    assert s["rv"]["status"] == "ok" and len(s["rv"]["rows"]) == 18 and s["as_of"] == AS_OF
    assert s["positions"]["status"] == "ok" and len(s["positions"]["rows"]) == 3
    assert s["reads"] == {"cheap vs model": 8, "in line": 5, "rich vs model": 3, "distressed": 2}
    ven = next(r for r in s["rv"]["rows"] if r["iso3"] == "VEN")
    assert ven["distressed"] is True and ven["z"] is None and ven["gap_bp"] == 60 and ven["fair_bp"] == 5940
    vnm = next(r for r in s["rv"]["rows"] if r["iso3"] == "VNM")
    assert vnm["z"] == pytest.approx(1.41483) and vnm["pd_12m"] == pytest.approx(0.00361724) and vnm["synthetic"] is False
    c = {g["iso3"]: g for g in s["curves"]["curves"]}
    assert s["curves"]["status"] == "ok" and list(c) == ["XAA", "XBB", "XCC", "XDD"]
    assert [p["tenor_y"] for p in c["XAA"]["points"]] == [1, 2, 3, 5, 7, 10]
    assert c["XCC"]["flags"] == ["negative_forward_hazard_3y", "negative_forward_hazard_5y", "negative_forward_hazard_7y", "inverted_curve"]
    assert c["XDD"]["flags"] == ["upfront_converted"] and c["XAA"]["flags"] == []
    assert all(g["synthetic"] for g in c.values()) and s["synthetic"] and "not market data" in s["synthetic_note"]
    assert {f["iso3"] for f in s["flagged"]} == {"XCC", "XDD"}
    json.dumps(s, allow_nan=False)                                        # NaN / blanks are None


def test_read_by_column_name_extra_and_reordered_columns(tmp_path):
    out = outputs(tmp_path)
    df = pd.read_csv(out / "bond_rv.csv")
    df = df[list(reversed(df.columns))]; df["new_col_from_b"] = 1          # column additions are additive
    df.to_csv(out / "bond_rv.csv", index=False)
    a = R.rv_summary(out)["rv"]["rows"]
    b = R.rv_summary(outputs(tmp_path / "ref"))["rv"]["rows"]
    assert a == b and "new_col_from_b" not in a[0]


def test_distressed_z_blank_even_if_file_has_one(tmp_path):
    out = outputs(tmp_path, curves=False)
    df = pd.read_csv(out / "bond_rv.csv"); df.loc[df["distressed"], "z"] = 9.9; df.to_csv(out / "bond_rv.csv", index=False)
    rows = R.rv_summary(out)["rv"]["rows"]
    assert all(r["z"] is None for r in rows if r["distressed"]) and sum(r["z"] is not None for r in rows) == 16


def test_synthetic_market_source_is_marked(tmp_path):
    out = outputs(tmp_path, curves=False)
    df = pd.read_csv(out / "bond_rv.csv"); df.loc[0, "market_source"] = SYN_SOURCE; df.to_csv(out / "bond_rv.csv", index=False)
    s = R.rv_summary(out)
    assert s["rv"]["rows"][0]["synthetic"] is True and s["rv"]["rows"][0]["market_source"] == SYN_SOURCE
    assert sum(r["synthetic"] for r in s["rv"]["rows"]) == 1 and s["synthetic"] and s["synthetic_note"] == R.SYN_NOTE


@pytest.mark.parametrize("kind", ["missing", "zero_bytes", "header_only"])
def test_empty_or_missing_curves_is_no_cds_curves(tmp_path, kind):
    out = outputs(tmp_path, curves=False)
    if kind == "zero_bytes":
        (out / "cds_curves.csv").write_text("")
    elif kind == "header_only":
        (out / "cds_curves.csv").write_text(",".join(R.CURVE_COLS) + "\n")
    s = R.rv_summary(out)
    assert s["curves"]["status"] == ("missing" if kind == "missing" else "empty")
    assert s["curves"]["message"].startswith("No CDS curves") and s["curves"]["curves"] == [] and s["flagged"] == []
    blob = json.dumps(s)
    assert "XAA" not in blob and "SYN-" not in blob and not s["synthetic"]      # never the fixture
    plan = SP.rv_plan(s, stamp=AS_OF)
    assert plan[2]["range"] == "'Weekly RV'!T6:AN7" and plan[2]["values"][1][0].startswith("No CDS curves")
    assert "No CDS curves" in R.country_rv_html(s, "Vietnam", "VNM") and any("No CDS curves" in x for x in R.country_rv_md(s, "Vietnam", "VNM"))


def test_nothing_written_and_unreadable_files(tmp_path):
    s = R.rv_summary(tmp_path / "none")
    assert [s[k]["status"] for k in ("rv", "positions", "curves")] == ["missing"] * 3 and s["as_of"] is None
    bad = tmp_path / "bad"; bad.mkdir()
    (bad / "bond_rv.csv").write_text("country,market_bp\nX,100\n")              # fair_bp, gap_bp absent
    b = R.rv_summary(bad)
    assert b["rv"]["status"] == "invalid" and "fair_bp" in b["rv"]["message"] and str(bad) not in json.dumps(b)
    (bad / "cds_curves.csv").write_bytes(b"\xff\xfe\x00bad")
    assert R.rv_summary(bad)["curves"]["status"] == "invalid"


def test_views_never_load_fixtures():
    for mod in (R, N, SP):
        src = Path(mod.__file__).read_text()
        assert "fixtures" not in src and "_fixture.csv" not in src, mod.__name__
    gui_src = (Path(api.__file__).parent / "gui.py").read_text()
    assert "fixture" not in gui_src and "fixture" not in PAGE


# ---------------------------------------------------------------- country notes: HTML and Markdown escaped
def test_country_section_html_and_md(tmp_path):
    s = R.rv_summary(outputs(tmp_path))
    h = R.country_rv_html(s, "Venezuela", "VEN")
    assert "DISTRESSED" in h and "5,940" in h and "+60" in h and "z is left blank" in h and "No CDS curves for this country" in h
    md = "\n".join(R.country_rv_md(s, "Venezuela", "VEN"))
    assert md.startswith("## Relative value") and "| 5,940 | 6,000 | +60 |  |" in md
    # a fixture curve under a fictional iso3: shown with SYNTHETIC and flags
    h = R.country_rv_html(s, "Fictional", "XCC")
    assert "SYNTHETIC" in h and "negative_forward_hazard_3y" in h and "FLAGS" in h
    assert "**SYNTHETIC**" in "\n".join(R.country_rv_md(s, "Fictional", "XCC"))


def test_country_section_escapes_text(tmp_path):
    out = outputs(tmp_path)
    df = pd.read_csv(out / "bond_rv.csv"); df.loc[0, "rv_read"] = EVIL; df.loc[0, "market_source"] = EVIL + " (SYNTHETIC)"
    df.to_csv(out / "bond_rv.csv", index=False)
    cv = pd.read_csv(out / "cds_curves.csv"); cv.loc[cv["iso3"] == "XAA", "flags"] = "<b>x</b>,inverted_curve"
    cv.loc[cv["iso3"] == "XAA", "source"] = "<script>alert(1)</script>"; cv.to_csv(out / "cds_curves.csv", index=False)
    s = R.rv_summary(out)
    h = R.country_rv_html(s, "Vietnam", "VNM") + R.country_rv_html(s, "x", "XAA")
    assert "<img" not in h and "<script>" not in h and "<b>x</b>" not in h and "&lt;img src=x" in h and "SYNTHETIC" in h
    md = R.country_rv_md(s, "Vietnam", "VNM") + R.country_rv_md(s, "x", "XAA")
    assert not any(line.startswith("## Fake") for line in md) and not any("<img" in x or "<script" in x for x in md)
    row = next(x for x in md if "HYPERLINK" in x)
    assert row.count(" | ") == 7 and "\\|x" in row                         # the pipe cannot break the table


def test_country_note_has_rv_section(tmp_path):
    from test_country_note import make_world
    d, out, base = make_world(tmp_path)
    pd.DataFrame([{"as_of": "2026-10-20", "country": "B", "iso3": "BBB", "rating": "B", "tenor_y": 5, "pd_12m": 0.04, "lgd": 0.6,
                   "risk_premium_ratio": 2, "el_bp": 240, "risk_premium_bp": 240, "fair_bp": 480, "market_bp": 600,
                   "market_source": SYN_SOURCE, "gap_bp": 120, "z": 0.5, "z_xs": 0.1, "distressed": False, "rv_read": "<i>cheap</i> vs model"}]
                 ).to_csv(out / "bond_rv.csv", index=False)
    (out / "cds_curves.csv").write_text("")
    res = N.build_country_notes(out, d, tmp_path / "notes", recompute_pillars=False, log=lambda *a: None)
    html = {i["country"]: Path(i["html"]).read_text() for i in res["items"]}
    b = html["B"]
    assert "<section id='rv'>" in b and "Relative value: bond vs model and CDS curve" in b and "+120" in b
    assert "SYNTHETIC" in b and "&lt;i&gt;cheap&lt;/i&gt;" in b and "<i>cheap</i>" not in b and "No CDS curves" in b
    assert "No bond RV row for A" in html["A"]


# ---------------------------------------------------------------- workbook: additive Weekly RV tab
def test_rv_plan_ranges_and_values(tmp_path):
    s = R.rv_summary(outputs(tmp_path))
    plan = SP.rv_plan(s, stamp=AS_OF)
    assert [b["range"] for b in plan] == ["'Weekly RV'!A1:A4", "'Weekly RV'!A6:R24", "'Weekly RV'!T6:AN26"] == list(SP.rv_layout(18, 20).values())
    assert SP.plan_problems(plan) == []
    notes, table, curves = (b["values"] for b in plan)
    assert notes[1][0].startswith("[OK]") and AS_OF in notes[1][0] and "SYNTHETIC" in notes[2][0] and "XCC negative_forward_hazard_3y" in notes[2][0]
    assert table[0] == R.RV_SHEET_HEADER and len(table) == 19 and curves[0] == R.CURVE_SHEET_HEADER and len(curves) == 21
    ven = next(r for r in table[1:] if r[2] == "VEN")
    col = {c: i for i, c in enumerate(R.RV_SHEET_COLS)}
    assert ven[col["z"]] == "" and ven[col["distressed"]] is True and ven[col["gap_bp"]] == 60 and ven[col["pd_12m"]] == 0.99
    ccol = {c: i for i, c in enumerate(R.CURVE_SHEET_COLS)}
    xcc = [r for r in curves[1:] if r[0] == "XCC"]
    assert all(r[ccol["synthetic"]] is True and "inverted_curve" in r[ccol["flags"]] for r in xcc)
    json.dumps(plan, allow_nan=False)


def test_rv_plan_empty_states():
    plan = SP.rv_plan(R.rv_summary(Path("/nonexistent-eq-c-0046")), stamp=AS_OF)
    assert [b["range"] for b in plan] == ["'Weekly RV'!A1:A4", "'Weekly RV'!A6:R7", "'Weekly RV'!T6:AN7"] and SP.plan_problems(plan) == []
    assert plan[0]["values"][1][0].startswith("[MISSING]") and plan[1]["values"][1][0].startswith("No bond RV yet")
    assert len(plan[1]["values"][1]) == 18 and len(plan[2]["values"][1]) == 21


def test_rv_plan_formula_escapes_text(tmp_path):
    out = outputs(tmp_path)
    df = pd.read_csv(out / "bond_rv.csv"); df.loc[0, "rv_read"] = "=1+1"; df.loc[0, "market_source"] = "+cmd|' /C calc'!A0"
    df.loc[1, "country"] = "@SUM(1)"; df.to_csv(out / "bond_rv.csv", index=False)
    cv = pd.read_csv(out / "cds_curves.csv"); cv.loc[0, "flags"] = "-2+3"; cv.loc[0, "source"] = EVIL; cv.to_csv(out / "cds_curves.csv", index=False)
    plan = SP.rv_plan(R.rv_summary(out), stamp=AS_OF)
    col, ccol = {c: i for i, c in enumerate(R.RV_SHEET_COLS)}, {c: i for i, c in enumerate(R.CURVE_SHEET_COLS)}
    t, c = plan[1]["values"], plan[2]["values"]
    assert t[1][col["rv_read"]] == "'=1+1" and t[1][col["market_source"]] == "'+cmd|' /C calc'!A0" and t[2][col["country"]] == "'@SUM(1)"
    assert c[1][ccol["flags"]] == "'-2+3" and c[1][ccol["source"]] == "'" + EVIL
    assert t[1][col["gap_bp"]] == pytest.approx(56.5931)                   # numbers stay numbers
    assert all(not (isinstance(x, str) and x[:1] and x[:1] in "=+-@") for b in SP.sanitize_plan(plan) for r in b["values"] for x in r)


def test_weekly_rv_tab_is_new_and_documented():
    tabs = {SP.parse_a1(r.format(e=20))[0] for r in V1_RANGES} | {SP.parse_a1(r)[0] for r in SP.layout_v2(70).values()}
    assert "Weekly RV" not in tabs and "Trade Ideas" not in tabs
    for c, k in ((0, 0), (1, 1), (70, 600)):
        L = SP.rv_layout(c, k)
        assert SP.parse_a1(L["rv_table"])[3:] == (6 + max(1, c), 18) and SP.parse_a1(L["rv_curves"])[2:] == (20, 6 + max(1, k), 40)
        assert SP.plan_problems([{"range": r, "values": [[0]]} for r in L.values()]) == []
    ref = json.loads((DATA / "workbook_reference.json").read_text())["layout"]["additive_tabs"]["'Weekly RV'"]
    L0 = SP.rv_layout(0, 0)
    assert ref["notes"] == L0["rv_notes"] and ref["table_c0"] == L0["rv_table"] and ref["curves_k0"] == L0["rv_curves"]
    assert ref["table"] == "'Weekly RV'!A6:R(6+C)" and ref["curves"] == "'Weekly RV'!T6:AN(6+K)"
    letters = [SP.col_letter(i + 1) for i in range(18)] + [SP.col_letter(20 + i) for i in range(21)]
    names = list(R.RV_SHEET_COLS) + list(R.CURVE_SHEET_COLS)
    doc = ref["columns"] + ", " + ref["curve_columns"]
    for letter, name in zip(letters, names):
        assert re.search(rf"(^|, ){letter} {name}\b", doc), (letter, name)    # documented letters match the plan
    adr = (ROOT / "team" / "adr" / "ADR-C-001.md").read_text()
    assert "> 8. Weekly RV" in adr and "`Weekly RV`" in adr and "A:AN" in adr


@pytest.fixture(scope="module")
def run18():
    u = load_universe(DATA); s = Settings.load(DATA / "assumptions.json")
    return u, s, run_pipeline(u, s, paths=2000, as_of=AS_OF)


def test_build_plan_with_rv_keeps_c11_ranges(run18, tmp_path):
    from econquest.presentation.ideas_view import ideas_summary
    u, s, res = run18
    history = pd.read_csv(DATA / "backtest_history.csv")
    base = SP.build_plan(res, u, s, history=history, stamp=AS_OF, mc_rows=50)
    rv = R.rv_summary(outputs(tmp_path))
    plan = SP.build_plan(res, u, s, history=history, stamp=AS_OF, mc_rows=50, rv=rv)
    both = SP.build_plan(res, u, s, history=history, stamp=AS_OF, mc_rows=50, ideas=ideas_summary(tmp_path / "outputs"), rv=rv)
    v1 = [r.format(e=16 + len(history)) for r in V1_RANGES]
    rv_ranges = ["'Weekly RV'!A1:A4", "'Weekly RV'!A6:R24", "'Weekly RV'!T6:AN26"]
    assert [b["range"] for b in base] == v1 and plan[:len(base)] == base
    assert [b["range"] for b in plan] == v1 + rv_ranges and SP.plan_problems(plan) == []
    assert [b["range"] for b in both] == v1 + ["'Trade Ideas'!A1:A3", "'Trade Ideas'!A5:G6"] + rv_ranges and SP.plan_problems(both) == []
    labels = next(b for b in plan if b["range"] == "'Risk Engine'!A35:D37")["values"]
    assert [r[0] for r in labels] == ["R31", "R32", "R33"]


def test_publish_rv_flag_dry_run(tmp_path):
    out = outputs(tmp_path, curves=False)
    (out / "cds_curves.csv").write_text("")
    cli.main(["--data", str(DATA), "--out", str(out), "publish", "--paths", "2000", "--mc-rows", "20", "--no-garch", "--rv"])
    plan = json.loads((out / "publish_plan.json").read_text())
    ranges = [b["range"] for b in plan]
    assert ranges[-3:] == ["'Weekly RV'!A1:A4", "'Weekly RV'!A6:R24", "'Weekly RV'!T6:AN7"] and SP.plan_problems(plan) == []
    assert plan[-1]["values"][1][0].startswith("No CDS curves") and "Weekly RV" not in " ".join(ranges[:-3])
    cli.main(["--data", str(DATA), "--out", str(out), "publish", "--paths", "2000", "--mc-rows", "20", "--no-garch"])
    assert not any("Weekly RV" in b["range"] for b in json.loads((out / "publish_plan.json").read_text()))   # opt-in only


# ---------------------------------------------------------------- GUI: /api/rv and the Relative value tab
class RvApp:
    token = "test-token-123"
    latest = {"summary": {"run_id": "r-rv"}, "settings": {"as_of": AS_OF}, "country": []}


@pytest.fixture
def serve(tmp_path):
    srvs = []

    def start(kind: str):
        base = tmp_path / kind
        if kind == "ok":
            out = outputs(base, positions=True)
        else:
            out = base / "outputs"; out.mkdir(parents=True)
            if kind == "empty_curves":
                shutil.copy(FIX / "bond_rv_fixture.csv", out / "bond_rv.csv"); (out / "cds_curves.csv").write_text("")
        srv = ThreadingHTTPServer(("127.0.0.1", 0), make_gui_handler(RvApp(), StubJobs(), out, tmp_path / "data"))
        threading.Thread(target=srv.serve_forever, daemon=True).start(); srvs.append(srv)
        return srv.server_address[1]
    yield start
    for s in srvs:
        s.shutdown()


def get(port, path, headers=None):
    conn = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
    conn.request("GET", path, headers={"Host": f"127.0.0.1:{port}", **(headers or {})})
    r = conn.getresponse()
    return r.status, r.read().decode()


@pytest.mark.parametrize("kind,rv,curves,n", [("ok", "ok", "ok", 4), ("empty_curves", "ok", "empty", 0), ("missing", "missing", "missing", 0)])
def test_rv_route(serve, kind, rv, curves, n):
    port = serve(kind)
    st, body = get(port, "/api/rv")
    s = json.loads(body)
    assert st == 200 and s["rv"]["status"] == rv and s["curves"]["status"] == curves and len(s["curves"]["curves"]) == n
    assert {s[k]["file"] for k in ("rv", "positions", "curves")} == {"bond_rv.csv", "bond_rv_positions.csv", "cds_curves.csv"}
    assert "/tmp" not in body and str(Path.home()) not in body                   # file names only
    if curves != "ok":
        assert s["curves"]["message"].startswith("No CDS curves") and "XAA" not in body


def test_rv_route_is_read_only_and_guarded(serve):
    port = serve("ok")
    for method in ("POST", "PUT", "DELETE"):
        conn = http.client.HTTPConnection("127.0.0.1", port, timeout=5)
        conn.request(method, "/api/rv", body="{}", headers={"Host": f"127.0.0.1:{port}", **good(port)})
        assert conn.getresponse().status in (404, 405, 501), method
    assert get(port, "/api/rv", headers={"Host": "evil.example:80"})[0] == 403   # DNS rebinding guard
    assert get(port, "/api/rv", headers={"Host": f"rebind.example:{port}"})[0] == 403


def test_gui_has_rv_tab_and_escapes():
    assert '<a data-tab="rv">Relative value</a>' in PAGE and '<section id="rv">' in PAGE
    assert re.search(r"const renderers = \{[^}]*\brv\b", PAGE) and 'rv: "Relative value: bonds vs model and CDS curves (diagnostic)"' in PAGE
    block = PAGE[PAGE.index("// ---------- relative value (EQ-C-0046)"):PAGE.index("// ---------- trade ideas (EQ-C-0047)")]
    allowed = ("esc(", "fmt.", "rvCol(", "SYN_BADGE", 'c.synthetic ? " · <b>SYNTHETIC</b>"', 'c.flags.length ? "warn"', "c.flags.length ? esc(",
               "rvSyn ?", "RV.as_of ?", "(RV.as_of_dates || []).length > 1 ?", "curves.some(")
    bare = re.sub(r"esc\(`[^`]*`\)", "esc(...)", block)                     # a template passed whole to esc() is escaped
    for expr in re.findall(r"\$\{([^{}]*)\}", bare):
        assert expr.strip().startswith(allowed), expr
    assert "${esc(part.message)}" in block and "${esc(RV.synthetic_note)}" in block and '$("#rv-label").textContent' in block
    for msg in re.findall(r"emptyMsg: ([^}]+?)[ }]", block):
        assert msg.startswith("esc("), msg                                    # table() inserts emptyMsg as HTML
    assert "y: g.map(r => esc(" in block and "name: nm(c)" in block and "const nm = c => esc(" in block   # Plotly labels escaped
    assert "SYNTHETIC" in block and "flags" in block and "z: r.distressed ? null : r.z" in block


def test_md_text_neutralises_link_and_code_syntax():
    from econquest.presentation.report import md_text
    out = md_text("[x](javascript:alert(1)) `code`")
    assert "[x](" not in out and "\\[x\\]" in out and "\\`code\\`" in out
