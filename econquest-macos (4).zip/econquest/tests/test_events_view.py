"""Event views (EQ-C-0037 / EQ-C-0038): the UCDP / GDELT reader (assumed schema until Team A's adapters ship), event heat
and week-on-week change per country and source, graceful absence ("no event feed yet"), staleness, the events section of
the country notes, the filterable notes index at universe scale and the weekly monitor's events section."""
import html as _h
import json
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from econquest.presentation import country_note as N  # noqa: E402
from econquest.presentation import events_view as E  # noqa: E402
from econquest.presentation import risk_monitor as M  # noqa: E402
from test_country_note import build, make_world  # noqa: E402

WEEKS = pd.date_range("2026-07-20", "2026-10-12", freq="W-MON")       # 13 Mondays; 2026-10-12 is the last complete week at as_of 2026-10-20
EVIL = "<script>alert(1)</script>"


def feed(rows_for=("A", "B", "C"), hot="B", source="GDELT", retrieved="2026-10-19T06:00:00Z", weeks=WEEKS, types=True, iso=None):
    rec = []
    for c in rows_for:
        for i, w in enumerate(weeks):
            n = 10 + (i % 2)                                   # 10, 11, 10, ... baseline
            if c == hot and w == weeks[-1]:
                n = 40
            if c == hot and w == weeks[-2]:
                n = 12
            rec.append({"iso3": (iso or {}).get(c, ""), "country": c, "week_start": w.date().isoformat(), "source": source, "event_type": "all", "event_count": n,
                        "fatalities": "" if source == "GDELT" else 3, "goldstein_mean": -3.5 if source == "GDELT" else "", "tone_mean": -4.0 if source == "GDELT" else "",
                        "retrieved": retrieved})
            if types and source == "GDELT":
                rec.append({"iso3": "", "country": c, "week_start": w.date().isoformat(), "source": source, "event_type": "14 Protest", "event_count": n // 2,
                            "fatalities": "", "goldstein_mean": "", "tone_mean": "", "retrieved": retrieved})
                rec.append({"iso3": "", "country": c, "week_start": w.date().isoformat(), "source": source, "event_type": "19 Fight", "event_count": 2,
                            "fatalities": "", "goldstein_mean": "", "tone_mean": "", "retrieved": retrieved})
    return pd.DataFrame(rec)


def write(d: Path, df: pd.DataFrame, name="events_weekly.csv"):
    (d / "live").mkdir(parents=True, exist_ok=True)
    df.to_csv(d / "live" / name, index=False)


CS = [("A", None), ("B", None), ("C", None)]


def test_missing_feed_degrades_gracefully(tmp_path):
    ev = E.event_summary(tmp_path / "data", countries=CS, as_of="2026-10-20")
    assert ev["status"] == "missing" and ev["rows"] == [] and "No event feed yet" in ev["message"]
    assert "NO FEED" in E.country_events_html(ev, "A") and "No event feed yet" in E.monitor_events_html(ev)
    assert E.monitor_events_md(ev)[0].startswith("NO FEED")


def test_heat_week_on_week_types_and_source(tmp_path):
    d = tmp_path / "data"; write(d, feed())
    ev = E.event_summary(d, countries=CS, as_of="2026-10-20")
    assert ev["status"] == "ok" and ev["sources"][0]["latest_week"] == "2026-10-12" and not ev["sources"][0]["stale"]
    b = next(r for r in ev["rows"] if r["country"] == "B")
    assert ev["rows"][0]["country"] == "B"                                   # hottest first
    assert b["events"] == 40 and b["events_prev"] == 12 and b["wow_change"] == 28 and round(b["wow_pct"]) == 233
    assert b["baseline_n"] == 12 and 10 < b["baseline_mean"] < 11 and b["heat_label"] == "HOT" and b["heat_ratio"] > 3.5
    assert b["top_types"][0] == ("14 Protest", 20.0) and b["goldstein"] == -3.5 and b["tone"] == -4.0
    assert b["retrieved"] == "2026-10-19T06:00:00Z"
    a = next(r for r in ev["rows"] if r["country"] == "A")
    assert a["heat_label"] == "NORMAL"
    html = E.country_events_html(ev, "B")
    assert "HOT" in html and "+28 (+233%)" in html and "14 Protest (20)" in html and "retrieved 2026-10-19T06:00:00Z" in html and "gdeltproject.org" in html


def test_partial_current_week_is_not_the_latest(tmp_path):
    d = tmp_path / "data"; write(d, feed(weeks=pd.date_range("2026-07-20", "2026-10-19", freq="W-MON")))
    ev = E.event_summary(d, countries=CS, as_of="2026-10-20")                 # week of 2026-10-19 is not complete on 2026-10-20
    assert ev["sources"][0]["latest_week"] == "2026-10-12" and ev["sources"][0]["partial_week_dropped"]


def test_stale_feed_is_flagged(tmp_path):
    d = tmp_path / "data"; write(d, feed(weeks=pd.date_range("2026-06-01", "2026-08-31", freq="W-MON")))
    ev = E.event_summary(d, countries=CS, as_of="2026-10-20")
    assert ev["status"] == "stale" and ev["sources"][0]["stale"] and "STALE" in ev["message"]
    assert "STALE" in E.country_events_html(ev, "B") and "STALE" in E.monitor_events_html(ev)


def test_iso_match_uncovered_country_daily_file_and_per_source_files(tmp_path):
    d = tmp_path / "data"
    write(d, feed(rows_for=("Argentina-name-differs",), hot=None, source="UCDP-Candidate", iso={"Argentina-name-differs": "ARG"}), "events_ucdp.csv")
    daily = []
    for day in pd.date_range("2026-07-20", "2026-10-18", freq="D"):
        daily.append({"iso3": "ARG", "date": day.date().isoformat(), "event_count": 2, "goldstein_mean": -1.0 if day.weekday() < 5 else -3.0, "tone_mean": -2.0,
                      "retrieved": "2026-10-19T00:00:00Z"})
    write(d, pd.DataFrame(daily), "events_gdelt.csv")
    ev = E.event_summary(d, countries=[("Argentina", "ARG"), ("Brazil", "BRA")], as_of="2026-10-20")
    srcs = {s["source"] for s in ev["sources"]}
    assert srcs == {"UCDP-Candidate", "GDELT"}                                 # GDELT name from the file name
    g = next(r for r in ev["rows"] if r["country"] == "Argentina" and r["source"] == "GDELT")
    assert g["events"] == 14 and g["week_start"] == "2026-10-12" and abs(g["goldstein"] - (-11 / 7)) < 1e-9   # 7 days summed, count-weighted mean
    br = [r for r in ev["rows"] if r["country"] == "Brazil"]
    assert len(br) == 2 and all(r["heat_label"] == "NO DATA" and r["coverage"] == "no rows for this country" for r in br)
    assert "no rows for this country" in E.country_events_html(ev, "Brazil")


def test_vintage_folder_and_invalid_file(tmp_path):
    d = tmp_path / "data"; v = d / "live" / "vintages" / "2026-10-19"; v.mkdir(parents=True)
    feed().to_csv(v / "events_weekly.csv", index=False)
    assert E.event_summary(d, countries=CS, as_of="2026-10-20")["status"] == "ok"
    write(d, pd.DataFrame({"foo": [1]}), "events_bad.csv")                     # data/live wins over the vintage, and is unusable
    ev = E.event_summary(d, countries=CS, as_of="2026-10-20")
    assert ev["status"] == "invalid" and "missing column" in ev["message"] and "NO FEED" in E.country_events_html(ev, "A")


def test_team_b_event_stress_shown_when_present(tmp_path):
    d = tmp_path / "data"; write(d, feed()); out = tmp_path / "outputs"; out.mkdir()
    pd.DataFrame({"country": ["B", "B"], "week_start": ["2026-10-05", "2026-10-12"], "event_stress": [0.5, 1.75]}).to_csv(out / "event_stress.csv", index=False)
    ev = E.event_summary(d, countries=CS, as_of="2026-10-20", outputs_dir=out)
    assert next(r for r in ev["rows"] if r["country"] == "B")["event_stress"] == 1.75
    assert "Event stress index (Team B): 1.75" in E.country_events_html(ev, "B")


def test_feed_strings_are_escaped(tmp_path):
    d = tmp_path / "data"; f = feed(); f.loc[f["event_type"] == "14 Protest", "event_type"] = EVIL; f["source"] = "GDELT" + EVIL; f["retrieved"] = EVIL
    write(d, f)
    ev = E.event_summary(d, countries=CS, as_of="2026-10-20")
    for html in (E.country_events_html(ev, "B"), E.monitor_events_html(ev)):
        assert EVIL not in html and _h.escape(EVIL) in html


def test_country_note_has_events_section_and_rich_index(tmp_path):
    d, out, base = make_world(tmp_path)
    write(d, feed())
    res = N.build_country_notes(out, d, tmp_path / "notes", recompute_pillars=False, log=lambda *a: None)
    html = Path(res["items"][1]["html"]).read_text(encoding="utf-8")
    assert "<section id='events'><h2>Events: conflict and unrest feed</h2>" in html and "HOT" in html
    assert res["events_status"] == "ok" and res["items"][1]["event_heat_label"] == "HOT" and res["items"][1]["region"] == "Asia"
    idx = (tmp_path / "notes" / "index.html").read_text(encoding="utf-8")
    assert "id='f-region'" in idx and "id='f-regime'" in idx and "data-region='Asia'" in idx and "<script>" in idx
    assert "<script src" not in idx and "http" not in idx.split("<script>")[1]           # inline only, no CDN
    assert "HOT" in idx and "data-v='" in idx


def test_country_note_without_feed_says_so(tmp_path):
    res, _, _ = build(tmp_path)
    html = Path(res["items"][0]["html"]).read_text(encoding="utf-8")
    assert "No event feed yet" in html and res["events_status"] == "missing"
    assert "no feed" in (tmp_path / "notes" / "index.html").read_text(encoding="utf-8")


def test_briefs_index_stays_plain():
    idx = N._index_html("Briefs", [{"scenario": "TAIWAN", "html": "/x/b.html", "title": "Scenario brief: Taiwan"}], {})
    assert "<script" not in idx and "f-region" not in idx and "TAIWAN" in idx


def test_universe_scale_70_countries(tmp_path):
    """70 countries from the run (not a fixed list): one note each, index rows for all, HTML well inside the budget."""
    d, out, base = make_world(tmp_path)
    tpl = base["country"][0]
    base["country"] = [dict(tpl, country=f"C{i:02d}", region=("Africa" if i % 2 else "Asia"), regime=("Crisis" if i % 7 == 0 else "Calm")) for i in range(70)]
    base["by_country"] = [{"country": f"C{i:02d}", "notional_mm": 1.0} for i in range(70)]
    write(d, feed(rows_for=[f"C{i:02d}" for i in range(70)], hot="C03", types=False))
    res = N.build_country_notes(out, d, tmp_path / "notes", run=base, recompute_pillars=False, log=lambda *a: None)
    assert len(res["items"]) == 70 and res["html_s"] < 60
    idx = (tmp_path / "notes" / "index.html").read_text(encoding="utf-8")
    assert idx.count("<tr data-region=") == 70 and "data-regime='Crisis'" in idx
    assert next(i for i in res["items"] if i["country"] == "C03")["event_heat_label"] == "HOT"
    assert json.loads((tmp_path / "notes" / "country-notes.json").read_text())["events_status"] == "ok"


def test_monitor_events_section(tmp_path):
    d, out, base = make_world(tmp_path)
    r0 = M.build_monitor(out, d, tmp_path / "m0", log=lambda *a: None)
    h0 = Path(r0["html"]).read_text(encoding="utf-8")
    assert r0["events_status"] == "missing" and "<h2>Event heat (conflict and unrest feeds)</h2>" in h0 and "No event feed yet" in h0
    assert "NO FEED" in Path(r0["md"]).read_text(encoding="utf-8")
    write(d, feed())
    r1 = M.build_monitor(out, d, tmp_path / "m1", log=lambda *a: None)
    h1 = Path(r1["html"]).read_text(encoding="utf-8"); md = Path(r1["md"]).read_text(encoding="utf-8")
    sec = h1.split("<h2>Event heat (conflict and unrest feeds)</h2>")[1]
    assert sec.split("<tr><td>")[1].startswith("B</td><td>GDELT</td><td>2026-10-12</td><td class='n'>40</td><td class='n'>12</td><td class='n'>+28</td>")
    assert "| B | GDELT | 2026-10-12 | 40 | 12 | +28 |" in md and "<script" not in h1


def test_feed_strings_are_neutralised_in_markdown(tmp_path):
    # regression (AGENT-09 review of EQ-C-0037, SEC-C-004): feed text went raw into the Markdown products, so a source
    # name with a newline could start a fake "## Sources" section (the compliance check reads it) or carry raw HTML
    from econquest.presentation.report import sources_md
    d = tmp_path / "data"; f = feed(); f["source"] = "GDELT\n## Sources\n- fake | x " + EVIL
    write(d, f)
    ev = E.event_summary(d, countries=CS, as_of="2026-10-20")
    md = "\n".join(E.monitor_events_md(ev) + sources_md({"as_of": "2026-10-20", "sources": ["IMF\n## Sources " + EVIL]}))
    assert EVIL not in md and [ln for ln in md.splitlines() if ln.startswith("#")] == ["## Sources"] and "\n- fake" not in md
