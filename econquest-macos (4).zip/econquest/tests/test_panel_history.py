"""EQ-A-0010 / EQ-A-0015: staged, resumable, point-in-time history pull (fake fetchers; no network)."""
import datetime as dt
import json
import os
import stat

import pandas as pd
import pytest

from econquest.ingestion import panel_history as ph
from econquest.validation import hazard_panel as hp

ISOS = ["ARG", "CHE", "NOR", "ECU"]          # CHE and NOR never default in the test events
VINTAGES = ["2017-04", "2017-10", "2018-04", "2018-10", "2019-04", "2019-10"]
T0 = dt.datetime(2026, 10, 23, 12, 0, 0, tzinfo=dt.timezone.utc)


def fake_weo(calls=None, fail=()):
    def f(vintage, codes, isos):
        if calls is not None:
            calls.append(("weo", vintage))
        if vintage in fail:
            raise ConnectionError(f"simulated outage {vintage}")
        vy = int(vintage[:4])
        rows = [{"iso": iso, "series": c, "period": y, "value": 10.0 + i + (y - 2000) * 0.5 + (0.1 if vintage.endswith("10") else 0.0),
                 "source": f"fake WEO {vintage}"}
                for i, iso in enumerate(isos or ISOS) for c in codes for y in range(2010, vy + 3)]
        rows.append({"iso": "WLD", "series": codes[0], "period": 2015, "value": 1.0, "source": "fake"})  # aggregate kept
        return pd.DataFrame(rows)
    return f


def fake_wb(calls=None, fail=()):
    def f(code, start, end, isos):
        if calls is not None:
            calls.append(("worldbank", code))
        if code in fail:
            raise TimeoutError(f"simulated timeout {code}")
        return pd.DataFrame([{"iso": iso, "series": code, "period": y, "value": 1.0 + i, "source": "fake wbgapi"}
                             for i, iso in enumerate(isos or ISOS) for y in range(2010, 2020)])
    return f


def run(tmp_path, fetchers, **kw):
    kw.setdefault("weo_vintages", VINTAGES)
    kw.setdefault("now", T0)
    return ph.fetch_history(tmp_path, retries=kw.pop("retries", 1), backoff=0.0, fetchers=fetchers, sleep=lambda s: None,
                            log=lambda m: None, **kw)


def test_resume_refetches_only_failed_units(tmp_path):
    calls = []
    with pytest.raises(ph.IncompleteFetchError) as ei:
        run(tmp_path, {"weo": fake_weo(calls, fail={"2018-04"}), "worldbank": fake_wb(calls, fail={"FI.RES.TOTL.MO"})})
    err = ei.value
    assert sorted(err.missing) == ["weo/2018-04", "worldbank/FI.RES.TOTL.MO"]
    assert calls.count(("weo", "2018-04")) == 2                       # first try + 1 retry
    assert not (tmp_path / "weo_history.csv").exists() and not (tmp_path / "worldbank_history.csv").exists()
    assert not (tmp_path / "vintages").exists()
    run_id = err.manifest["run_id"]
    m = json.loads((tmp_path / "staging" / run_id / "manifest.json").read_text())
    assert m["status"] == "incomplete"
    assert m["units"]["weo/2017-04"]["status"] == "ok" and len(m["units"]["weo/2017-04"]["sha256"]) == 64
    assert "simulated outage" in m["units"]["weo/2018-04"]["error"]

    calls2 = []
    m2 = run(tmp_path, {"weo": fake_weo(calls2), "worldbank": fake_wb(calls2)}, run_id=run_id, now=T0 + dt.timedelta(minutes=5))
    assert sorted(calls2) == [("weo", "2018-04"), ("worldbank", "FI.RES.TOTL.MO")]
    assert m2["status"] == "complete" and all(u["status"] == "ok" for u in m2["units"].values())
    assert (tmp_path / "weo_history.csv").exists() and (tmp_path / "worldbank_history.csv").exists()


def test_resume_refetches_unit_whose_staged_file_changed(tmp_path):
    with pytest.raises(ph.IncompleteFetchError) as ei:
        run(tmp_path, {"weo": fake_weo(), "worldbank": fake_wb(fail={"PV.EST"})})
    stage = tmp_path / "staging" / ei.value.manifest["run_id"]
    (stage / "weo" / "2017-10.csv").write_text("tampered\n")
    calls = []
    run(tmp_path, {"weo": fake_weo(calls), "worldbank": fake_wb(calls)}, run_id=ei.value.manifest["run_id"])
    assert sorted(calls) == [("weo", "2017-10"), ("worldbank", "PV.EST")]


def test_missing_unit_fails_and_final_files_untouched(tmp_path):
    (tmp_path / "weo_history.csv").write_text("old,file\n")
    (tmp_path / "worldbank_history.csv").write_text("old,wb\n")
    with pytest.raises(ph.IncompleteFetchError, match="Final files not written"):
        run(tmp_path, {"weo": fake_weo(), "worldbank": fake_wb(fail={"PV.EST"})}, retries=2)
    assert (tmp_path / "weo_history.csv").read_text() == "old,file\n"
    assert (tmp_path / "worldbank_history.csv").read_text() == "old,wb\n"
    assert not [p for p in tmp_path.iterdir() if p.name.endswith(".tmp")]


def test_empty_or_malformed_unit_is_a_failure(tmp_path):
    with pytest.raises(ph.IncompleteFetchError) as ei:
        run(tmp_path, {"weo": lambda v, c, i: pd.DataFrame(columns=["iso", "series", "period", "value", "source"]),
                       "worldbank": lambda c, s, e, i: pd.DataFrame({"iso": ["ARG"], "value": [1.0]})})
    errs = {u: r["error"] for u, r in ei.value.manifest["units"].items()}
    assert "no rows" in errs["weo/2017-04"] and "missing columns" in errs["worldbank/PV.EST"]


def test_retries_with_exponential_backoff(tmp_path):
    n = {"k": 0}
    ok = fake_wb()

    def flaky(code, s, e, i):
        n["k"] += 1
        if n["k"] <= 2:
            raise ConnectionError("blip")
        return ok(code, s, e, i)
    sleeps = []
    ph.fetch_history(tmp_path, sources=["worldbank"], wb_codes=["PV.EST"], retries=3, backoff=2.0,
                     fetchers={"worldbank": flaky}, sleep=sleeps.append, log=lambda m: None, now=T0)
    assert sleeps == [2.0, 4.0]


def test_output_is_point_in_time_for_panel_from_long(tmp_path):
    m = run(tmp_path, {"weo": fake_weo(), "worldbank": fake_wb()})
    weo = pd.read_csv(tmp_path / "weo_history.csv", dtype={"iso": str, "series": str})
    wbh = pd.read_csv(tmp_path / "worldbank_history.csv", dtype={"iso": str, "series": str})
    assert list(weo.columns) == ["iso", "series", "period", "value", "source", "vintage"]
    assert list(wbh.columns) == ["iso", "series", "period", "value", "source"]
    assert set(weo["vintage"]) == set(VINTAGES) and set(weo["series"]) == set(hp.WEO_CODES)
    assert set(wbh["series"]) == set(hp.WB_CODES)
    assert {"CHE", "NOR"} <= set(weo["iso"])                          # never-defaulted economies are in the universe
    events = pd.DataFrame({"iso": ["ARG", "ECU"], "start": [2019, 2020], "end": [2020, 2021]})
    panel = hp.panel_from_long(weo, wbh, events, start=2017, end=2019, forecast_cutoff=2020)
    assert panel.attrs["point_in_time"] == "all features"
    assert set(panel["iso"]) == set(ISOS)
    assert not panel.loc[panel["iso"].isin(["CHE", "NOR"]), "ever_defaulted"].any()
    # row 2018 uses the latest release published by end-2018 (October 2018, +0.1), not 2019's revision
    r = panel[(panel.iso == "CHE") & (panel.year == 2018)].iloc[0]
    assert r["debt_gdp"] == pytest.approx(11.0 + 17 * 0.5 + 0.1)
    assert m["final"]["weo_history.csv"]["sha256"] == ph.sha256_file(tmp_path / "weo_history.csv")


def test_panel_vintage_is_read_only_and_append_only(tmp_path):
    m1 = run(tmp_path, {"weo": fake_weo(), "worldbank": fake_wb()})
    root = tmp_path / "vintages"
    v1 = root / m1["panel_vintage"]
    assert sorted(p.name for p in v1.iterdir()) == ["manifest.json", "weo_history.csv", "worldbank_history.csv"]
    assert all(stat.S_IMODE(p.stat().st_mode) == 0o444 for p in v1.iterdir())
    assert stat.S_IMODE(v1.stat().st_mode) == 0o555
    assert (v1 / "weo_history.csv").read_bytes() == (tmp_path / "weo_history.csv").read_bytes()
    before = {p.name: p.read_bytes() for p in v1.iterdir()}
    # a later run with different data makes a second folder; the first is unchanged
    m2 = run(tmp_path, {"weo": fake_weo(), "worldbank": fake_wb()}, weo_vintages=VINTAGES[:-1], now=T0 + dt.timedelta(hours=1))
    assert m2["panel_vintage"] != m1["panel_vintage"]
    assert {p.name: p.read_bytes() for p in v1.iterdir()} == before
    idx = pd.read_csv(root / "index.csv", dtype=str)
    assert list(idx["vintage_id"]) == [m1["panel_vintage"], m2["panel_vintage"]]
    assert ph.list_panel_vintages(tmp_path) == sorted(idx["vintage_id"])
    # identical content is not duplicated; a colliding folder name is never overwritten
    again = ph.save_panel_vintage(tmp_path, {"a.csv": b"x\n"}, now=T0 + dt.timedelta(hours=2))
    assert ph.save_panel_vintage(tmp_path, {"a.csv": b"x\n"}, now=T0 + dt.timedelta(hours=3)) == again
    os.chmod(again, 0o700)
    (again.parent / "index.csv").write_text((again.parent / "index.csv").read_text().replace(again.name, "gone"))
    with pytest.raises(FileExistsError):
        ph.save_panel_vintage(tmp_path, {"a.csv": b"x\n"}, now=T0 + dt.timedelta(hours=2))
    with pytest.raises(ValueError):
        ph.save_panel_vintage(tmp_path, {"../evil.csv": b"x"})


def test_main_exit_codes(tmp_path, monkeypatch, capsys):
    monkeypatch.setattr(ph, "WeoVintageFetcher", lambda cache: fake_weo())
    monkeypatch.setattr(ph, "worldbank_series_fetcher", fake_wb(fail={"PV.EST"}))
    monkeypatch.setattr(ph.time, "sleep", lambda s: None)
    args = ["--out", str(tmp_path), "--weo-vintages", "2018-04:2019-10", "--retries", "0"]
    assert ph.main(args) == 1
    assert "worldbank/PV.EST" in capsys.readouterr().err
    run_id = next((tmp_path / "staging").iterdir()).name
    monkeypatch.setattr(ph, "worldbank_series_fetcher", fake_wb())
    assert ph.main(["--out", str(tmp_path), "--resume", run_id]) == 0
    weo = pd.read_csv(tmp_path / "weo_history.csv")
    assert sorted(set(weo["vintage"])) == ["2018-04", "2018-10", "2019-04", "2019-10"]
    assert ph.main(["--out", str(tmp_path), "--resume", "nope"]) == 2
    assert ph.main(["--out", str(tmp_path), "--weo-vintages", "garbage"]) == 2


def test_vintage_labels_and_defaults():
    assert ph.normalise_vintage("Apr 2019") == "2019-04"
    assert ph.normalise_vintage(("October", 2011)) == "2011-09"
    assert ph.normalise_vintage("2020-10") == "2020-10"
    with pytest.raises(ValueError):
        ph.normalise_vintage("spring")
    d = ph.default_weo_vintages(dt.date(2026, 10, 23))
    assert d[0] == "2007-10" and d[-1] == "2026-10" and "2011-09" in d and len(d) == 39
    assert ph.default_weo_vintages(dt.date(2026, 10, 1))[-1] == "2026-04"
    assert ph._parse_vintage_arg("2007-10:2008-10,1999-09") == ["1999-09", "2007-10", "2008-04", "2008-10"]


def _weo_tab(path, encoding):
    cols = ["WEO Country Code", "ISO", "WEO Subject Code", "Country", "Subject Descriptor", "Units", "2015", "2016", "Estimates Start After"]
    rows = [["213", "ARG", "GGXWDG_NGDP", "Argentina", "General government gross debt", "Percent of GDP", "52.6", "1,053.2", "2015"],
            ["213", "ARG", "NGDP", "Argentina", "GDP", "National currency", "5", "6", "2015"],
            ["146", "CHE", "GGXWDG_NGDP", "Switzerland", "General government gross debt", "Percent of GDP", "n/a", "--", "2015"]]
    text = "\n".join("\t".join(r) for r in [cols, *rows]) + "\n\nInternational Monetary Fund, World Economic Outlook Database, April 2017\n"
    path.write_bytes(text.encode(encoding))
    return path


@pytest.mark.parametrize("enc", ["utf-16", "iso-8859-1"])
def test_parse_weo_tab(tmp_path, enc):
    d = ph.parse_weo_tab(_weo_tab(tmp_path / "w.xls", enc), ["GGXWDG_NGDP"])
    assert sorted(zip(d.iso, d.period, d.value)) == [("ARG", 2015, 52.6), ("ARG", 2016, 1053.2)]


def test_weo_fetcher_routes(tmp_path):
    imf_calls, dl_calls = [], []

    def imf(version):
        imf_calls.append(version)
        return pd.DataFrame({"CONCEPT_CODE": ["GGXWDG_NGDP", "NGDP"], "REF_AREA_CODE": ["ARG", "ARG"],
                             "TIME_PERIOD": [2018, 2018], "OBS_VALUE": [86.0, 1.0]})

    def dl(year, release, filename, directory):
        dl_calls.append((year, release))
        _weo_tab(tmp_path / filename, "utf-16")
        return str(tmp_path / filename), f"https://example.invalid/WEO{release}{year}all.xls"
    fx = ph.WeoVintageFetcher(tmp_path, imf_reader_fetch=imf, weo_download=dl)
    a = fx("2019-04", ["GGXWDG_NGDP"])
    assert imf_calls == [("April", 2019)] and list(a["value"]) == [86.0] and "imf-reader" in a["source"].iloc[0]
    b = fx("2021-04", ["GGXWDG_NGDP"])                  # corrupt in the SDMX archive: weo package only
    assert dl_calls == [(2021, "Apr")] and len(b) == 2 and (tmp_path / "weo_2021-04.xls").exists()
    fx("2021-04", ["GGXWDG_NGDP"])                       # cached file: no second download
    assert dl_calls == [(2021, "Apr")]
    with pytest.raises(ph.FetchUnitError, match="weo_2001-04.xls"):
        fx("2001-04", ["GGXWDG_NGDP"])
    _weo_tab(tmp_path / "weo_2001-04.xls", "iso-8859-1")  # manual drop-in for a pre-2007 release
    c = fx("2001-04", ["GGXWDG_NGDP"])
    assert "local file" in c["source"].iloc[0] and len(c) == 2

    def bad_dl(year, release, filename, directory):
        (tmp_path / filename).write_text("<html>bot check</html>")
        return str(tmp_path / filename), "u"
    fx2 = ph.WeoVintageFetcher(tmp_path / "c2", imf_reader_fetch=imf, weo_download=bad_dl)
    (tmp_path / "c2").mkdir()
    with pytest.raises(ph.FetchUnitError):
        fx2("2010-04", ["GGXWDG_NGDP"])
    assert not list((tmp_path / "c2").iterdir())          # a bad download is never cached


def test_resume_rejects_path_like_run_id(tmp_path):
    """SEC review S1: --resume values must be run ids, never paths."""
    import pytest
    from econquest.ingestion.panel_history import fetch_history
    for bad in ("../..", "/etc", "20261023T120000Z/../x", ""):
        if bad:
            with pytest.raises(ValueError):
                fetch_history(tmp_path, run_id=bad)


def test_oversized_weo_file_is_refused(tmp_path, monkeypatch):
    """SEC review S2: a WEO file above the size cap is a failed unit, not parsed."""
    import pytest
    from econquest.ingestion import panel_history as ph
    f = tmp_path / "weo.xls"; f.write_bytes(b"x" * 2048)
    monkeypatch.setattr(ph, "MAX_WEO_BYTES", 1024)
    with pytest.raises(ph.FetchUnitError):
        ph.parse_weo_tab(f, ["NGDPD"])


# ---------------------------------------------------------------- EQ-A-0020: SEC review S1 (manifest), S3 (cleanup), S5 (label)

def _incomplete(tmp_path):
    with pytest.raises(ph.IncompleteFetchError) as ei:
        run(tmp_path, {"weo": fake_weo(), "worldbank": fake_wb(fail={"PV.EST"})})
    run_id = ei.value.manifest["run_id"]
    return run_id, tmp_path / "staging" / run_id


def _edit_manifest(stage, fn):
    m = json.loads((stage / "manifest.json").read_text())
    fn(m)
    (stage / "manifest.json").write_text(json.dumps(m))


@pytest.mark.parametrize("unit", ["worldbank/../../../etc/x", "weo/../../evil", "worldbank/pv.est", "other/2019-04", "weo/2019-4"])
def test_resume_rejects_bad_unit_key(tmp_path, unit):
    run_id, stage = _incomplete(tmp_path)
    _edit_manifest(stage, lambda m: m["units"].update({unit: {"status": "pending", "sha256": "", "attempts": 0}}))
    with pytest.raises(ValueError, match="bad unit key"):
        run(tmp_path, {"weo": fake_weo(), "worldbank": fake_wb()}, run_id=run_id)


def test_resume_rejects_units_that_do_not_match_params(tmp_path):
    run_id, stage = _incomplete(tmp_path)
    _edit_manifest(stage, lambda m: m["units"].pop("weo/2017-04"))
    with pytest.raises(ValueError, match="do not match its params"):
        run(tmp_path, {"weo": fake_weo(), "worldbank": fake_wb()}, run_id=run_id)
    _edit_manifest(stage, lambda m: m["units"].update({"weo/2017-04": {"status": "pending"}, "weo/2030-04": {"status": "pending"}}))
    with pytest.raises(ValueError, match="extra \\['weo/2030-04'\\]"):
        run(tmp_path, {"weo": fake_weo(), "worldbank": fake_wb()}, run_id=run_id)


def test_staged_file_must_resolve_inside_stage(tmp_path):
    (tmp_path / "panel").mkdir()
    run_id, stage = _incomplete(tmp_path / "panel")
    outside = tmp_path / "elsewhere"
    (stage / "weo").rename(outside)
    (stage / "weo").symlink_to(outside, target_is_directory=True)
    with pytest.raises(ValueError, match="resolves outside"):
        run(tmp_path / "panel", {"weo": fake_weo(), "worldbank": fake_wb()}, run_id=run_id)


def test_panel_vintage_label_is_formula_escaped(tmp_path):
    ph.save_panel_vintage(tmp_path, {"a.csv": b"x\n"}, label="=HYPERLINK(\"http://x\")", now=T0)
    ph.save_panel_vintage(tmp_path, {"b.csv": b"y\n"}, label="history run 20261023T120000Z", now=T0)
    idx = pd.read_csv(tmp_path / "vintages" / "index.csv", dtype=str)
    assert list(idx["label"]) == ["'=HYPERLINK(\"http://x\")", "history run 20261023T120000Z"]


def test_remove_panel_vintage_helper(tmp_path):
    v = ph.save_panel_vintage(tmp_path, {"a.csv": b"x\n", "b.csv": b"y\n"}, now=T0)
    assert stat.S_IMODE(v.stat().st_mode) == 0o555
    with pytest.raises(ValueError, match="not a panel vintage"):
        ph.remove_panel_vintage(tmp_path / "vintages")                 # the parent, not a vintage
    (tmp_path / "x").mkdir()
    with pytest.raises(ValueError, match="not a panel vintage"):
        ph.remove_panel_vintage(tmp_path / "x")
    ph.remove_panel_vintage(v)
    assert not v.exists() and ph.list_panel_vintages(tmp_path) == []
    # the index row stays (append-only) and saving the same content again makes a fresh folder
    v2 = ph.save_panel_vintage(tmp_path, {"a.csv": b"x\n", "b.csv": b"y\n"}, now=T0 + dt.timedelta(hours=1))
    assert v2.is_dir() and v2 != v


@pytest.mark.skipif(not hasattr(os, "geteuid") or os.geteuid() == 0, reason="root ignores directory permissions")
def test_panel_vintage_cannot_be_deleted_without_helper(tmp_path):
    import shutil
    v = ph.save_panel_vintage(tmp_path, {"a.csv": b"x\n"}, now=T0)
    with pytest.raises(PermissionError):
        shutil.rmtree(v)
    assert (v / "a.csv").exists()
    ph.remove_panel_vintage(v)
    assert not v.exists()
