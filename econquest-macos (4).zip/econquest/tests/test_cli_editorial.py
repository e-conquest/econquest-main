"""`econquest editorial` CLI wiring (EQ-C-0026): lifecycle through the command line, clean errors."""
import pytest

from econquest import cli
from econquest.presentation import report
from econquest.presentation.report import DISCLAIMER


RUN = {"summary": {"run_id": "r-test", "as_of": "2026-10-23", "versions": {"data_hash": "d" * 16, "run_hash": "h" * 16}}}


def _product(out, data):
    """A note that passes the automatic checks: disclaimer, input caveats block for `data`, Sources with the run's as-of."""
    f = out / "notes" / "note.md"; f.parent.mkdir(parents=True)                # drafts live under outputs/
    cav = "\n".join(report.caveats_md(report.input_caveats(data)))
    f.write_text(f"# Note\n\n## Input caveats\n\n{cav}\n\n## Sources\n\n- IMF WEO\n\nAs of 2026-10-23.\n\n"
                 f"> **Disclaimer.** {DISCLAIMER}\n")
    return f


def test_editorial_lifecycle_via_cli(tmp_path, monkeypatch, capsys):
    """Single-operator flow (EQ-C-0036): draft, self-review, checklist (conflicts, acknowledge, self-signed sign-off), publish."""
    monkeypatch.setattr(report, "latest_run", lambda store, label="base": RUN)
    out, data = tmp_path / "out", tmp_path / "data"
    data.mkdir()
    (data / "prediction_markets.csv").write_text("country,contract,price\nARG,default,0.3\n")            # flags restriction 6.2
    f = _product(out, data)
    base = ["--data", str(data), "--out", str(out), "editorial"]
    cli.main([*base, "draft", "--kind", "country_note", "--file", str(f), "--author", "Sam"])
    item = capsys.readouterr().out.split()[0]
    with pytest.raises(SystemExit, match="editorial review"):
        cli.main([*base, "review", item, "--reviewer", " sam "])                   # same person, no flag
    cli.main([*base, "review", item, "--reviewer", "Sam", "--self-reviewed"])
    with pytest.raises(SystemExit, match="editorial publish"):
        cli.main([*base, "publish", item, "--publisher", "Sam"])                  # checklist incomplete
    with pytest.raises(SystemExit) as e:
        cli.main([*base, "checklist", item, "--show"])
    assert e.value.code == 1 and "INCOMPLETE" in capsys.readouterr().out
    sign = [*base, "checklist", item, "--by", "Sam", "--conflicts", "no conflicts", "--acknowledge", "6.2",
            "--compliance-approve", "--self-signed"]
    with pytest.raises(SystemExit, match="needs an exception id EXC-nnn"):            # EQ-C-0041: as change approve
        cli.main(sign)
    cli.main([*sign, "--exc", "EXC-001"])
    o = capsys.readouterr().out
    assert "checklist complete" in o and "SELF-SIGNED exception EXC-001" in o
    cli.main([*base, "publish", item, "--publisher", "Sam"])
    assert "published" in capsys.readouterr().out
    cli.main([*base, "verify"])
    assert "0 problem(s)" in capsys.readouterr().out
    from econquest.ops import actionlog as AL
    cmds = [r["command"] for r in AL.read(out)]
    assert "editorial checklist" in cmds and cmds[-2:] == ["editorial publish", "editorial verify"]
    assert AL.verify(out)["ok"]


def test_editorial_empty_list(tmp_path, capsys):
    cli.main(["--out", str(tmp_path), "editorial", "list"])
    assert "No editorial items." in capsys.readouterr().out
