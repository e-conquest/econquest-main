"""EQ-A-0044: econquest.ingestion.limitations (the GOV-010 data limitations register, moved from the EQ-A-0042 staging
script). Offline, on a synthetic data folder: every value here is SYNTHETIC, not real data."""
import hashlib
import json
import sys
from pathlib import Path

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.ingestion import limitations as L  # noqa: E402

NAMES = ["Atlantis", "Borduria"]


def _tree_hash(d: Path) -> str:
    h = hashlib.sha256()
    for p in sorted(d.rglob("*")):
        if p.is_file():
            h.update(p.relative_to(d).as_posix().encode() + b"\0" + p.read_bytes())
    return h.hexdigest()


def _live(folder: Path, retrieved: str | None = "2026-10-23", yahoo: bool = False, flagged_ok: bool = True) -> None:
    folder.mkdir(parents=True, exist_ok=True)
    pd.DataFrame({"Atlantis": [1.0, 2.0], "Borduria": [None, 3.0]}, index=["1.3", "5.13"]).to_csv(folder / "live_inputs.csv")
    pd.DataFrame({"pop": [1.0, 2.0], "policy": [5.0, None], "fx3m": [1.5, 2.5], "equity_vol": [None, None]},
                 index=NAMES).to_csv(folder / "live_profile.csv")
    pd.DataFrame([{"table": "Inputs", "key": "1.3", "country": "Atlantis", "seed": 1, "live": 1, "status": "ok", "reason": ""},
                  {"table": "Inputs", "key": "5.13", "country": "Atlantis", "seed": 1, "live": 2,
                   "status": "ok" if flagged_ok else "hold", "reason": "stale: BIS POLICY_RATE last observation 2025-07-10"},
                  {"table": "Inputs", "key": "5.13", "country": "Borduria", "seed": 1, "live": 3, "status": "hold",
                   "reason": "change: 1 -> 3"}]).assign(decision="").to_csv(folder / "review.csv", index=False)
    pd.DataFrame([{"iso": "ATL", "series": "SP.POP.TOTL", "period": "2024", "value": 1e6, "source": "t"}]).to_csv(
        folder / "raw_worldbank.csv", index=False)
    pd.DataFrame([{"iso": "ATL", "series": "POLICY_RATE", "period": "2025-07-10", "value": 5.0, "source": "t"}]).to_csv(
        folder / "raw_bis.csv", index=False)
    pd.DataFrame([{"iso": "ATL", "series": "ATL_PER_USD", "period": "2026-10-20", "value": 10.0, "source": "t"}]).to_csv(
        folder / "raw_bis_xru.csv", index=False)
    if yahoo:
        pd.DataFrame([{"iso": "ATL", "series": "FX_USD", "period": "2026-10-22", "value": 10.0, "source": "t"},
                      {"iso": "ATL", "series": "ETF", "period": "2026-10-21", "value": 30.0, "source": "t"}]).to_csv(
            folder / "raw_yahoo.csv", index=False)
    if retrieved:
        (folder / "feeds.json").write_text(json.dumps({"feeds": {"bis": "ok"}, "retrieved": retrieved}))


def _data(tmp_path: Path, **kw) -> Path:
    d = tmp_path / "data"; d.mkdir()
    pd.DataFrame([{"id": "1.3", "indicator": "Debt", "unit": "% of GDP"}, {"id": "5.13", "indicator": "Real policy rate", "unit": "%"},
                  {"id": "7.13", "indicator": "Recovery speed", "unit": "years"}]).to_csv(d / "indicators.csv", index=False)
    pd.DataFrame([{"id": "1.3", "api": "IMF WEO"}, {"id": "5.13", "api": "BIS"}, {"id": "7.13", "api": "Manual: analyst"}]).to_csv(
        d / "rulebook.csv", index=False)
    pd.DataFrame({"country": NAMES, "iso": ["ATL", "BRD"], "pop": [1, 2], "fx3m": [0, 0], "policy": [5, 6], "rating": ["B", "C"]}).to_csv(
        d / "countries.csv", index=False)
    pd.DataFrame([{"table": "Inputs", "key": "1.3", "country": "Atlantis", "origin": "live feed", "retrieved": "2026-10-23"},
                  {"table": "Inputs", "key": "1.3", "country": "Borduria", "origin": "seed estimate", "retrieved": ""},
                  {"table": "Inputs", "key": "5.13", "country": "Atlantis", "origin": "live feed", "retrieved": "2026-10-25"},
                  {"table": "Country Profile", "key": "pop", "country": "Atlantis", "origin": "live feed", "retrieved": "2026-10-23"}]
                 ).to_csv(d / "audit_trail.csv", index=False)
    _live(d / "live", **kw)
    return d


def _row(md: str, key: str, section: str) -> list[str]:
    part = md.split(f"## Register: {section}")[1].split("\n\n## ")[0]
    for line in part.splitlines():
        cells = [c.strip() for c in line.strip("|").split("|")]
        if cells and cells[0] == key:
            return cells
    raise AssertionError(f"no row {key} in {section}")


def test_register_format_without_yahoo_and_read_only(tmp_path):
    d = _data(tmp_path)
    before = _tree_hash(d)
    out = tmp_path / "out" / "data-limitations.md"
    stats = L.build_register(d, out)
    assert _tree_hash(d) == before                                     # read-only
    md = out.read_text()
    assert md.startswith(L.HEADER) and md.endswith(L.FOOTER + "\n")      # hand-written narrative kept verbatim
    assert "<!-- generated tables: econquest.ingestion.limitations.build_register (source: data/live) -->" in md
    assert "## Register: Inputs indicators (data/indicators.csv, 3 rows)" in md
    assert "## Register: Country Profile fields (data/countries.csv, 5 columns, plus equity_vol)" in md
    assert "| " + " | ".join(L.HDR) + " |" in md
    r = _row(md, "5.13", "Inputs")
    assert r[4] == "BIS SDMX: WS_CBPOL minus WEO PCPIPCH" and r[7] == "1 hold (1 open); 1 flagged then accepted"
    assert r[8] == "BIS 2025-07-10 to 2025-07-10 (1 countries)"
    assert _row(md, "7.13", "Inputs")[4] == "manual: Manual: analyst"
    fx = _row(md, "fx3m", "Country Profile")
    assert fx[4].startswith("BIS/ECB: BIS WS_XRU") and fx[8] == "BIS XRU to 2026-10-20"
    ev = _row(md, "equity_vol", "Country Profile")
    assert ev[4].startswith("unserved: no official free source") and ev[8] == "not served (EQ-A-0040)"
    assert stats["raw_yahoo"] is False and stats["flagged_ok"] == 1 and stats["open_holds"] == 1 and stats["rows"] == 3 + 6


def test_yahoo_input_still_read_when_present(tmp_path):
    d = _data(tmp_path, yahoo=True)
    out = tmp_path / "r.md"
    L.build_register(d, out)
    md = out.read_text()
    assert _row(md, "fx3m", "Country Profile")[8] == "Yahoo to 2026-10-22"
    assert _row(md, "equity_vol", "Country Profile")[4].startswith("Yahoo: yfinance country ETF")


def test_deterministic(tmp_path):
    d = _data(tmp_path)
    L.build_register(d, tmp_path / "a.md"); L.build_register(d, tmp_path / "b.md")
    assert (tmp_path / "a.md").read_bytes() == (tmp_path / "b.md").read_bytes()


def test_as_of_uses_newest_pull_at_or_before_the_cutoff(tmp_path):
    d = _data(tmp_path, retrieved="2026-10-25")                        # data/live is after the cutoff
    v = d / "live" / "vintages" / "2026-10-23T090000Z-0000abcd"
    _live(v, flagged_ok=False)                                         # what the gate held at the time
    _live(d / "live" / "vintages" / "2026-10-24T090000Z-0000ef01")      # after a 2026-10-23 cutoff: ignored
    out = tmp_path / "r.md"
    stats = L.build_register(d, out, as_of="2026-10-23")
    md = out.read_text()
    assert "(source: data/live/vintages/2026-10-23T090000Z-0000abcd; as of 2026-10-23)" in md
    assert stats["flagged_ok"] == 0 and _row(md, "5.13", "Inputs")[7] == "2 hold (2 open)"
    assert stats["inputs_live"] == 1                                   # audit row retrieved 2026-10-25 dropped
    with pytest.raises(ValueError, match="no pull at or before 2026-10-22"):
        L.build_register(d, tmp_path / "x.md", as_of="2026-10-22")
    stats = L.build_register(d, out, as_of="2026-10-25")                # data/live is now in range
    assert stats["live_source"] == "data/live"


def test_cli_entry_point(tmp_path, capsys):
    d = _data(tmp_path)
    assert L.main(["--data", str(d), "--out", str(tmp_path / "r.md")]) == 0
    assert "re-check them by hand" in capsys.readouterr().out and (tmp_path / "r.md").is_file()
    assert L.main(["--data", str(d), "--out", str(tmp_path / "r.md"), "--as-of", "2026-01-01"]) == 2


def test_maps_match_their_sources():
    from econquest.ingestion import feeds
    from econquest.scorecard import readiness as r
    assert L.WEO == feeds.WEO_SOURCE_SERIES and L.WB == feeds.WB_SOURCE_SERIES
    assert L.WB_RAW == feeds.WB_STALE_SERIES and L.BIS_RAW == feeds.BIS_STALE_SERIES
    assert L.REQ_IND == set(r.REQUIRED_INDICATORS) and L.REQ_PROF == set(r.REQUIRED_PROFILE)
    assert L.REQ_FLAGS == set(r.REQUIRED_FLAGS) and L.ADV_PROF == set(r.ADVISORY_PROFILE)
    assert L.POS_PROF == set(r.POSITION_PROFILE)


def test_x10_ids_stay_distinct_from_x1(tmp_path):
    """HO-20261024-C-A-002: live_inputs ids 2.1 and 2.10 must not collapse (pandas parses them as floats)."""
    d = _data(tmp_path)
    ind = pd.read_csv(d / "indicators.csv", dtype=str)
    ind = pd.concat([ind, pd.DataFrame([{"id": "2.1", "indicator": "Ten", "unit": "%"},
                                        {"id": "2.10", "indicator": "Ten-ten", "unit": "%"}])])
    ind.to_csv(d / "indicators.csv", index=False)
    rb = pd.read_csv(d / "rulebook.csv", dtype=str)
    pd.concat([rb, pd.DataFrame([{"id": "2.1", "api": "Manual: analyst"}, {"id": "2.10", "api": "Manual: analyst"}])]).to_csv(
        d / "rulebook.csv", index=False)
    li = pd.DataFrame({"Atlantis": [1.0, 2.0, 7.0, None], "Borduria": [None, 3.0, 8.0, 9.0]}, index=["1.3", "5.13", "2.1", "2.10"])
    li.to_csv(d / "live" / "live_inputs.csv")
    out = tmp_path / "r.md"
    L.build_register(d, out)
    md = out.read_text()
    assert _row(md, "2.1", "Inputs")[5].startswith("2/") and _row(md, "2.10", "Inputs")[5].startswith("1/")
