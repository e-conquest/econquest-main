"""Event indicators 6.9 / 4.1 / 6.4 (EQ-A-0022..0024). Inputs are SYNTHETIC: the long UCDP fixture plus small frames
built here; nothing is real data."""
import datetime as dt
from pathlib import Path

import pandas as pd
import pytest

from econquest.ingestion.events.base import EVENT_COLUMNS, save_event_vintage
from econquest.ingestion.events.indicators import OUT_COLUMNS, band, event_indicators, stored_events

FIX = Path(__file__).parent / "fixtures" / "events" / "ucdp" / "events_monthly_2019_2026_synthetic.csv"


def _ucdp():
    return pd.read_csv(FIX, dtype=str, keep_default_na=False)


def _synthetic(source, iso, metric_values, start="2019-01", end="2026-02", freq="M"):
    """metric_values: metric -> function(period) -> value. All rows labelled SYNTHETIC."""
    rows = []
    for p in pd.period_range(start, end, freq="M"):
        for m, f in metric_values.items():
            rows.append({"iso": iso, "period": p.start_time.date().isoformat(), "freq": freq, "source": source,
                         "metric": m, "value": float(f(p)), "vintage_id": f"SYNTHETIC-{source}",
                         "retrieved_utc": "2026-10-23T00:00:00Z", "licence": "SYNTHETIC"})
    return pd.DataFrame(rows, columns=EVENT_COLUMNS)


def _expected_ratio(df, iso, rec, base):
    s = df[(df.iso == iso) & (df.metric == "events_total")].copy()
    s["m"] = pd.to_datetime(s.period).dt.to_period("M")
    s = s.set_index("m")["value"].astype(float)
    return s[rec].sum() / max(s[base].sum() / 5, 1.0)


def test_69_ucdp_proxy_ratio_and_band():
    ev = _ucdp()
    out = event_indicators(ev, dt.date(2026, 2, 28), ["NGA", "COL", "SGP"])
    assert list(out.columns) == OUT_COLUMNS
    r = out[out.indicator == "6.9"].set_index("iso")
    rec = pd.period_range("2025-03", "2026-02", freq="M")
    base = pd.period_range("2020-03", "2025-02", freq="M")
    assert r.loc["NGA", "value"] == pytest.approx(_expected_ratio(ev, "NGA", rec, base))
    assert r.loc["NGA", "value"] > 2.0 and r.loc["NGA", "suggested_level"] == band(r.loc["NGA", "value"])
    assert 0.9 < r.loc["COL", "value"] < 1.1
    assert r.loc["SGP", "value"] == 0.0 and r.loc["SGP", "suggested_level"] == 0
    assert "floored" in r.loc["SGP", "basis"]
    assert r.loc["NGA", "sources"] == "ucdp (proxy)" and "PROXY" in r.loc["NGA", "basis"]
    assert r.loc["NGA", "vintage_ids"] == "SYNTHETIC-FIXTURE"


def test_point_in_time_ignores_later_periods():
    ev = _ucdp()
    a = event_indicators(ev, dt.date(2025, 6, 30), ["NGA"])
    future = _synthetic("ucdp", "NGA", {"events_total": lambda p: 999}, "2025-07", "2026-02")
    ev2 = pd.concat([ev[~((ev.iso == "NGA") & (ev.metric == "events_total") & (ev.period >= "2025-07-01"))], future])
    b = event_indicators(ev2, dt.date(2025, 6, 30), ["NGA"])
    pd.testing.assert_series_equal(a["value"], b["value"])
    assert a.set_index("indicator").loc["6.9", "value"] == pytest.approx(1.5228758, rel=1e-6)


def test_mid_month_as_of_uses_last_complete_month():
    out = event_indicators(_ucdp(), dt.date(2026, 2, 15), ["NGA"])
    assert "2025-02..2026-01" in out.set_index("indicator").loc["6.9", "basis"]


def test_insufficient_history_gives_no_value():
    r = event_indicators(_ucdp(), dt.date(2023, 12, 31), ["NGA"]).set_index("indicator").loc["6.9"]
    assert pd.isna(r["value"]) and pd.isna(r["suggested_level"]) and "insufficient coverage" in r["basis"]


def test_as_of_retrieval_drops_later_vintages():
    ev = _ucdp()
    out = event_indicators(ev, dt.date(2026, 2, 28), ["NGA"], as_of_retrieval=True)
    assert out["value"].isna().all()                                   # fixture retrieved 2026-10-23, after as_of


def test_acled_preferred_for_69_with_ucdp_cross_check():
    pv = {m: (lambda p: 2) for m in ("events_battles", "events_explosions_remote", "events_violence_civilians")}
    ev = pd.concat([_ucdp(), _synthetic("acled", "NGA", pv)])
    r = event_indicators(ev, dt.date(2026, 2, 28), ["NGA"]).set_index("indicator").loc["6.9"]
    assert r["value"] == pytest.approx(1.0) and r["sources"] == "acled+ucdp"
    assert "UCDP cross-check" in r["basis"] and "SYNTHETIC-acled" in r["vintage_ids"]


def test_41_gdelt_share_ratio_and_suggestion():
    g = _synthetic("gdelt", "NGA", {"events_total": lambda p: 100,
                                    "events_protest": lambda p: 10 if p >= pd.Period("2025-12", "M") else 5}, freq="D")
    out = event_indicators(g, dt.date(2026, 2, 28), ["NGA"], adjustment={"NGA": 2.0})
    r = out.set_index("indicator").loc["4.1"]
    assert r["value"] == pytest.approx(2.0) and r["suggested_level"] == 2 and r["sources"] == "gdelt (proxy)"
    assert event_indicators(g, dt.date(2026, 2, 28), ["NGA"], adjustment={"NGA": 1.0}).set_index(
        "indicator").loc["4.1", "suggested_level"] == 1
    assert pd.isna(event_indicators(g, dt.date(2026, 2, 28), ["NGA"]).set_index("indicator").loc["4.1", "suggested_level"])


def test_41_acled_protest_ratio_preferred():
    a = _synthetic("acled", "NGA", {"events_protest": lambda p: 3, "events_riot": lambda p: 1})
    r = event_indicators(a, dt.date(2026, 2, 28), ["NGA"], adjustment={"NGA": 0.5}).set_index("indicator").loc["4.1"]
    assert r["value"] == pytest.approx(1.0) and r["suggested_level"] == 0 and r["sources"] == "acled"


def test_64_needs_acled():
    r = event_indicators(_ucdp(), dt.date(2026, 2, 28), ["NGA"]).set_index("indicator").loc["6.4"]
    assert pd.isna(r["value"]) and "ACLED" in r["basis"] and pd.isna(r["suggested_level"])
    a = _synthetic("acled", "NGA", {"events_abductions": lambda p: 1, "events_looting_property": lambda p: 2})
    r = event_indicators(a, dt.date(2026, 2, 28), ["NGA"]).set_index("indicator").loc["6.4"]
    assert r["value"] == 36 and pd.isna(r["suggested_level"]) and "analyst sets the level" in r["basis"]


def test_no_data_rows_for_every_indicator():
    out = event_indicators(pd.DataFrame(columns=EVENT_COLUMNS), dt.date(2026, 2, 28), ["BRA"])
    assert sorted(out["indicator"]) == ["4.1", "6.4", "6.9"] and out["value"].isna().all()


def test_stored_events_skips_disabled_acled(tmp_path):
    save_event_vintage(tmp_path, _ucdp().assign(licence="CC BY 4.0"), "ucdp", now=dt.datetime(2026, 10, 23))
    a = _synthetic("acled", "NGA", {"events_protest": lambda p: 1})
    save_event_vintage(tmp_path, a, "acled", now=dt.datetime(2026, 10, 23))
    got = stored_events(tmp_path)
    assert set(got["source"]) == {"ucdp"}
