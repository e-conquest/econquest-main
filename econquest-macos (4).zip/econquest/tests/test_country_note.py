"""Country notes (EQ-C-0024): one self-contained HTML note per country with pillars, PD against benchmarks, DSA fan,
stress impact, regime, signals and trade view, stamped with run_id / as_of / hashes, the country's input caveats and
the disclaimer; PDF through a local headless Chrome only when one is found."""
import html as _h
import json
import sys
from pathlib import Path

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from econquest.presentation import country_note as N  # noqa: E402
from econquest.presentation.report import DISCLAIMER  # noqa: E402
from test_report import make_run, make_data  # noqa: E402
from test_risk_monitor import archive  # noqa: E402

COUNTRIES = ("A", "B", "C")


def enrich(run, pd_scale=1.0, regime_b=None):
    for r in run["country"]:
        r["pd_default"] = r["pd_default"] * pd_scale
        r.update({"region": "Asia", "iso": "AAA", "regime_rule": r["regime"], "p_crisis_12m": 0.03, "pd_mult": 1.0, "lgd_mult": 1.0, "spread_bps": 300.0,
                  "pd_rating": 0.02, "pd_hazard_l1": 0.01})
        if regime_b and r["country"] == "B":
            r["regime"] = regime_b
    run["by_country"] = [{"country": c, "notional_mm": 10.0, "expected_loss_mm": 0.1, "tail_contribution_99_mm": 2.0 * pd_scale * (i + 1)} for i, c in enumerate(COUNTRIES)]
    for p, c in zip(run["positions"], COUNTRIES):
        p.update({"country": c, "asset_class": "Eurobond", "notional_mm": 10.0})
    run["dashboard"] = [{"country": c, "best_trade": "Buy sovereign CDS protection", "conviction": 70.0, "top_signals": "Debt payment wall", "gpr_read": "aligned",
                         "pm_read": "No contract"} for c in COUNTRIES]
    return run


def make_world(tmp_path, plan_composite_ok=True, stress_after=True):
    d = make_data(tmp_path / "data")
    pd.DataFrame({"id": ["1.1", "1.2"], "pillar": [1, 1], "indicator": ["Debt service", "Reserves"], "unit": ["%", "%"],
                  "A": [10.0, 20.0], "B": [30.0, 40.0], "C": [5.0, 6.0]}).to_csv(d / "indicators.csv", index=False)
    pd.DataFrame([{"id": "T01", "strategy": "Buy sovereign CDS protection", "key": 1, "stance": "Risk-off", "instrument": "CDS", "expression": "Buy 5Y <protection>",
                   "entry": "x", "exit": "y", "horizon": "6-12 months", "risks": "carry"}]).to_csv(d / "playbook.csv", index=False)
    pd.DataFrame([{"date": "2026-10-19", "country": "B", "pd_model": 0.04, "pd_hazard": 0.01, "pd_rating": 0.03, "pd_spread": 0.05, "pd_cds": None, "pd_pm": None,
                   "model_vs_rating_pp": 1.0, "model_vs_spread_pp": -1.0, "data_hash": "da7a"},
                  {"date": "2026-10-20", "country": "B", "pd_model": 0.05, "pd_hazard": 0.01, "pd_rating": 0.03, "pd_spread": 0.06, "pd_cds": None, "pd_pm": None,
                   "model_vs_rating_pp": 2.0, "model_vs_spread_pp": -1.0, "data_hash": "da7a"}]).to_csv(d / "benchmarks.csv", index=False)
    out = tmp_path / "outputs"; out.mkdir()
    pd.DataFrame([{"country": "B", "year": y, "baseline_weo": 60 + y - 2026, "baseline_model": 60, "p10": 50, "p25": 55, "p50": 60 + y - 2026, "p75": 66, "p90": 72}
                  for y in range(2026, 2031)]).to_csv(out / "dsa_fan.csv", index=False)
    base = enrich(make_run(run_id="r-base", created="2026-10-20T09:00:00+00:00", as_of="2026-10-20", sig_b=75.0))
    stressed = enrich(make_run(run_id="r-stress-A", created=("2026-10-20T09:05:00+00:00" if stress_after else "2026-10-19T09:05:00+00:00"), as_of="2026-10-20"), pd_scale=2.0, regime_b="Crisis")
    stressed["summary"]["label"] = "stress-A"
    archive(out, base, stressed)
    (out / "run_latest.json").write_text(json.dumps(base))
    (out / "stress.json").write_text(json.dumps({"A": {"name": "Hawkish Fed", "description": "rates up", "comparison": {}}}))
    comp = [r["composite"] + (0 if plan_composite_ok else 5) for r in base["country"]]
    plan = [{"range": N.PILLAR_FINAL_RANGE, "values": [[10.0 * p + i for i in range(3)] for p in range(1, 8)]},
            {"range": N.COMPOSITE_RANGE, "values": [comp, [3, 3, 3]]}]
    (out / "publish_plan.json").write_text(json.dumps(plan))
    return d, out, base


def build(tmp_path, **kw):
    d, out, base = make_world(tmp_path, **{k: kw.pop(k) for k in ("plan_composite_ok", "stress_after") if k in kw})
    return N.build_country_notes(out, d, tmp_path / "notes", recompute_pillars=False, log=lambda *a: None, **kw), d, out


def test_one_note_per_country_with_stamps_and_disclaimer(tmp_path):
    res, _, _ = build(tmp_path)
    assert res["kind"] == "country_notes" and [i["country"] for i in res["items"]] == list(COUNTRIES)
    for k, v in (("run_id", "r-base"), ("as_of", "2026-10-20"), ("data_hash", "da7a"), ("run_hash", "ru11"), ("code_hash", "c0de")):
        assert res[k] == v and all(i[k] == v for i in res["items"])
    assert len(res["paths"]) == 4 and res["paths"][-1].endswith("index.html")       # 3 notes + index (no PDF asked)
    for p in res["paths"]:
        t = Path(p).read_text(encoding="utf-8")
        assert DISCLAIMER in t or _h.escape(DISCLAIMER) in t, p
    html = Path(res["items"][1]["html"]).read_text(encoding="utf-8")
    assert Path(res["items"][1]["html"]).name == "country-note-b-2026-10-20.html"
    for s in ("<b>Run</b> r-base", "<b>As of</b> 2026-10-20", "<b>Data hash</b> da7a", "<b>Run hash</b> ru11"):
        assert s in html, s
    for h in ("Scorecard pillars", "Default PD against benchmarks", "Debt sustainability fan", "Stress scenarios: impact on this country", "Regime", "Signals",
              "Trade view (playbook)", "Input caveats for this country"):
        assert f"<h2>{h}</h2>" in html, h
    assert "http://" not in html and "https://" not in html and "<script" not in html                # self-contained, no CDN
    assert "@media print" in html and "<svg" in html
    manifest = json.loads((tmp_path / "notes" / "country-notes.json").read_text())
    assert manifest["run_id"] == "r-base" and len(manifest["items"]) == 3


def test_note_content_for_country(tmp_path):
    res, _, _ = build(tmp_path, countries=["b"])                                         # case-insensitive
    assert [i["country"] for i in res["items"]] == ["B"]
    html = Path(res["items"][0]["html"]).read_text(encoding="utf-8")
    assert "Spread-implied" in html and "6.00%" in html                                  # latest benchmarks.csv row (2026-10-20)
    assert "CDS-implied PD n/a" in html
    assert "aria-label=\"Debt sustainability fan chart" in html
    stress_row = html.split("<td>Hawkish Fed</td>")[1].split("</tr>")[0]
    assert "10.00%" in stress_row and "+5.00 pp" in stress_row and "Crisis" in stress_row  # 5% -> 10%, regime to Crisis
    assert "FIRING" in html and "Debt payment wall" in html                               # sig_b 75 >= threshold 60
    assert "T01" in html and "Buy 5Y &lt;protection&gt;" in html                         # playbook text escaped
    assert "use restriction 6.5" in html
    assert "<span class='tag seed'>SEED</span> This country" in html                     # per-country caveat cells


def test_unknown_country_and_no_run(tmp_path):
    d, out, _ = make_world(tmp_path)
    with pytest.raises(ValueError, match="not in the run"):
        N.build_country_notes(out, d, tmp_path / "n", countries=["Atlantis"], recompute_pillars=False, log=lambda *a: None)
    with pytest.raises(FileNotFoundError):
        N.build_country_notes(tmp_path / "empty", d, tmp_path / "n", log=lambda *a: None)


def test_pillars_from_plan_when_consistent(tmp_path):
    res, _, _ = build(tmp_path)
    assert res["pillar_source"].startswith("outputs/publish_plan.json") and "matches" in res["pillar_source"]
    html = Path(res["items"][0]["html"]).read_text(encoding="utf-8")
    assert "7 Climate and disaster" in html and "(highest)" in html and "NOT THIS RUN" not in html


def test_pillars_flagged_when_plan_is_from_other_inputs(tmp_path):
    res, _, _ = build(tmp_path, plan_composite_ok=False)
    assert "DIFFERS" in res["pillar_source"]
    assert "NOT THIS RUN" in Path(res["items"][0]["html"]).read_text(encoding="utf-8")


def test_stale_stress_run_is_flagged(tmp_path):
    res, _, _ = build(tmp_path, stress_after=False)
    assert "STALE: no stress run archived after the base run for A" in Path(res["items"][0]["html"]).read_text(encoding="utf-8")


def test_pdf_skipped_without_browser(tmp_path, monkeypatch):
    monkeypatch.setattr(N, "find_chrome", lambda explicit=None: None)
    res, _, _ = build(tmp_path, pdf=True)
    assert all(i["pdf"] is None and i["pdf_status"].startswith("skipped") for i in res["items"])
    assert not any(p.endswith(".pdf") for p in res["paths"])


def test_find_chrome_explicit_missing(tmp_path):
    assert N.find_chrome(str(tmp_path / "no-chrome")) is None
    pdf, status = N.html_to_pdf(tmp_path / "x.html", chrome=str(tmp_path / "no-chrome"))
    assert pdf is None and status.startswith("skipped")


@pytest.mark.skipif(N.find_chrome() is None, reason="no Chrome/Chromium on this machine")
def test_pdf_with_local_chrome(tmp_path):
    res, _, _ = build(tmp_path, pdf=True, countries=["A"])
    it = res["items"][0]
    assert it["pdf"] and Path(it["pdf"]).read_bytes()[:4] == b"%PDF", it["pdf_status"]
    assert it["pdf"] in res["paths"]


def test_pillars_from_a_v2_plan_wider_than_18_countries(tmp_path):
    """Workbook v2 (EQ-C-0033): at N > 18 the Pillar Scores blocks widen right; the note reads them at layout_v2(N)."""
    from econquest.presentation.sheets_publish import layout_v2
    d, out, base = make_world(tmp_path)
    names = [f"K{i:02d}" for i in range(25)]
    pd.DataFrame({"id": ["1.1"], "pillar": [1], "indicator": ["x"], "unit": ["%"], **{c: [1.0] for c in names}}).to_csv(d / "indicators.csv", index=False)
    base["country"] = [dict(base["country"][0], country=c, composite=40.0 + i) for i, c in enumerate(names)]
    base.pop("pillars", None)
    lay = layout_v2(25)
    assert lay["pillar_final"] != N.PILLAR_FINAL_RANGE and lay["pillar_final"].endswith(":AC35")
    plan = [{"range": lay["pillar_final"], "values": [[10.0 * p + i for i in range(25)] for p in range(1, 8)]},
            {"range": lay["pillar_composite"], "values": [[40.0 + i for i in range(25)], [3] * 25]},
            {"range": N.PILLAR_FINAL_RANGE, "values": [[0.0] * 18 for _ in range(7)]}]        # a stale v1 block must not be used
    (out / "publish_plan.json").write_text(json.dumps(plan))
    df, src, ok = N.load_pillars(base, out, d, recompute=False, log=lambda *a: None)
    assert ok and "composite matches" in src and list(df.columns) == names and df.at[3, "K24"] == 54.0
