"""Target-state scorecard (EQ-C-0061): every row is scored from an evidence file. The worlds here are SYNTHETIC
(fictional sovereigns C000..C059, fictional findings and release notes); nothing touches the repo's data/ or outputs/."""
import json
import sys

import numpy as np
import pandas as pd
import pytest

from econquest import cli
from econquest.presentation import targets as T

N = 60


def write(p, text):
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text, encoding="utf-8")
    return p


@pytest.fixture
def world(tmp_path, monkeypatch):
    """A world that meets every target the code can meet without Sam (licence, market data) and an editorial ledger."""
    for k in ("ECONQUEST_VENDOR_LICENCE_BLOOMBERG", "ECONQUEST_VENDOR_LICENCE_LSEG"):
        monkeypatch.delenv(k, raising=False)
    for mod in ("blpapi", "lseg", "lseg.data"):
        monkeypatch.setitem(sys.modules, mod, None)
    root, d, out = tmp_path / "repo", tmp_path / "data", tmp_path / "outputs"
    names = [f"C{i:03d}" for i in range(N)]
    pd.DataFrame({"country": names, "iso": [f"X{i:02d}" for i in range(N)]}).to_csv(write(d / "countries.csv", ""), index=False)
    ind = pd.DataFrame([{"id": "1.1", "pillar": 1, "indicator": "Debt service", "unit": "%", **{n: 1.0 for n in names}},
                        {"id": "1.3", "pillar": 1, "indicator": "Debt", "unit": "%", **{n: 2.0 for n in names}}])
    ind.to_csv(d / "indicators.csv", index=False)
    pd.DataFrame({"id": ["1.1", "1.3"], "pillar": [1, 1], "indicator": ["Debt service", "Debt"],
                  "api": ["IMF WEO", "IMF WEO"]}).to_csv(d / "rulebook.csv", index=False)
    live = ind.drop(columns=["pillar", "indicator", "unit"]).set_index("id")
    live.to_csv(write(d / "live" / "live_inputs.csv", ""))
    pd.DataFrame([{"table": "Inputs", "key": "1.1", "country": n, "seed": 1, "live": 1, "status": "ok", "reason": "",
                   "decision": ""} for n in names]).to_csv(d / "live" / "review.csv", index=False)
    pd.DataFrame({"origin": ["live feed"] * 4, "key": ["1.1"] * 4}).to_csv(d / "audit_trail.csv", index=False)
    days = pd.bdate_range("2025-09-01", periods=260)
    pd.DataFrame({"date": days.strftime("%Y-%m-%d"), "loss": 0.5, "var": 2.0, "es": 2.5}).to_csv(d / "forecast_record.csv", index=False)
    write(out / "hazard_fit.json", json.dumps({"panel": {"events": 80}, "out_of_sample": {
        "auc": 0.81, "events": 31, "first_year": 2005, "last_year": 2025}}))
    pd.DataFrame({"id": ["R01", "R02"], "status": ["PASS", "PASS"]}).to_csv(write(out / "replication" / "replication.csv", ""),
                                                                          index=False)
    pd.DataFrame([{"idea_id": "I1", "as_of": "2025-01-02", "status": "closed", "pnl_mm": "1.5", "mark_date": "",
                   "close_date": "2025-11-01"},
                  {"idea_id": "I2", "as_of": "2025-03-02", "status": "open", "pnl_mm": "", "mark_date": "2025-11-02",
                   "close_date": ""}]).to_csv(out / "idea_log.csv", index=False)
    write(root / "team" / "security" / "SEC-X-001.md", "---\nid: SEC-X-001\nstatus: fixed   # comment\n---\nbody\n")
    write(root / "team" / "security" / "SEC-X-002.md", "---\nstatus: false-positive\n---\n")
    pd.DataFrame({"id": ["GOV-1"], "severity": ["High"], "status": ["Resolved 2025-01-01"]}).to_csv(
        write(root / "docs" / "validation" / "dossier" / "findings-register.csv", ""), index=False)
    write(root / "docs" / "governance" / "releases" / "0.1.9-2025-01-01.md", "- Tests: 1,000 passed, 2 skipped.\n")
    write(root / "docs" / "governance" / "releases" / "0.1.10-2025-02-01-package.md", "- Full suite: 1,200 passed, 3 skipped.\n")
    return root, d, out


def score(world, **kw):
    root, d, out = world
    return T.target_scorecard(d, out, root=root, **kw).set_index("id")


def test_every_row_scored_from_evidence(world):
    s = score(world)
    assert list(s.reset_index().columns) == T.COLUMNS and s.index.is_unique
    assert set(s["met"]) <= set(T.MET)
    assert {i.split("-")[0] for i in s.index} == {"COV", "DAT", "MOD", "TRK", "RES", "CTL"}   # all six dimensions
    for rid in ("COV-1", "COV-2", "DAT-1", "DAT-2", "DAT-3", "MOD-1", "MOD-2", "MOD-3", "TRK-1", "TRK-2", "CTL-1",
                "CTL-2", "CTL-3"):
        assert s.at[rid, "met"] == "yes", (rid, s.at[rid, "current"])
    assert s.at["COV-1", "current"] == "60 sovereigns" and s.at["COV-1", "evidence"].endswith("countries.csv")
    assert s.at["DAT-1", "current"].startswith("100.0% live") and s.at["COV-2", "current"].startswith("0.0%")
    assert "260 testable days" in s.at["TRK-1", "current"] and "Basel Green" in s.at["TRK-1", "current"]
    assert "hit rate 100%" in s.at["TRK-2", "current"]
    # the newest release note by version (0.1.10 > 0.1.9), not by name
    assert s.at["CTL-3", "current"] == "1200 passed, 0 failed, 3 skipped"
    assert s.at["CTL-3", "evidence"] == "docs/governance/releases/0.1.10-2025-02-01-package.md"


def test_sam_dependent_rows_wait_on_sam_and_research_without_ledger(world):
    s = score(world)
    assert s.at["DAT-4", "met"] == "waiting on Sam" and "no market snapshot" in s.at["DAT-4", "current"]
    assert s.at["DAT-5", "met"] == "waiting on Sam" and "none" in s.at["DAT-5", "current"]
    assert s.at["RES-1", "met"] == "no" and "0 published" in s.at["RES-1", "current"]


def test_failing_evidence_scores_no(world, tmp_path):
    root, d, out = world
    write(root / "team" / "security" / "SEC-X-003.md", "---\nstatus: open\n---\n")
    pd.DataFrame({"id": ["GOV-1", "GOV-2", "GOV-3"], "severity": ["High", "Low", "Low"],
                  "status": ["Open", "In progress", "Open (EQ-B-1)"]}).to_csv(
        root / "docs" / "validation" / "dossier" / "findings-register.csv", index=False)
    write(out / "hazard_fit.json", json.dumps({"out_of_sample": {"auc": 0.72, "events": 31}}))
    pd.DataFrame({"id": ["R01", "R02"], "status": ["PASS", "FAIL"]}).to_csv(out / "replication" / "replication.csv", index=False)
    rec = pd.read_csv(d / "forecast_record.csv").head(100)
    rec.to_csv(d / "forecast_record.csv", index=False)
    pd.DataFrame({"origin": ["seed estimate", "live feed"]}).to_csv(d / "audit_trail.csv", index=False)
    live = pd.read_csv(d / "live" / "live_inputs.csv", index_col=0)
    live.iloc[:, : N // 2] = np.nan                       # half the countries have no live value
    live.to_csv(d / "live" / "live_inputs.csv")
    tests = write(tmp_path / "pytest.txt", "....F\n===== 3 failed, 10 passed, 1 skipped in 2.0s =====\n")
    s = score(world, tests_file=tests)
    assert s.at["CTL-1", "met"] == "no" and "SEC-X-003" in s.at["CTL-1", "current"]
    assert s.at["CTL-2", "met"] == "no" and s.at["CTL-2", "current"].startswith("3 open of 3")
    assert (s.at["MOD-1", "met"], s.at["MOD-2", "met"]) == ("yes", "no")      # 0.70 target met, 0.75 gate not
    assert s.at["MOD-3", "met"] == "no" and "1 FAIL" in s.at["MOD-3", "current"]
    assert s.at["TRK-1", "met"] == "no" and "100 testable days" in s.at["TRK-1", "current"]
    assert s.at["DAT-2", "met"] == "no" and s.at["DAT-2", "current"].startswith("1 of 2")
    assert (s.at["DAT-1", "met"], s.at["COV-2", "met"]) == ("no", "no") and s.at["DAT-1", "current"].startswith("50.0%")
    assert s.at["CTL-3", "met"] == "no" and s.at["CTL-3", "current"] == "10 passed, 3 failed, 1 skipped"
    assert s.at["CTL-3", "evidence"].endswith("pytest.txt")


def test_basel_red_record_is_not_met(world):
    root, d, out = world
    rec = pd.read_csv(d / "forecast_record.csv")
    rec.loc[: 20, "loss"] = 5.0                           # 21 exceedances in 260 days
    rec.to_csv(d / "forecast_record.csv", index=False)
    s = score(world)
    assert s.at["TRK-1", "met"] == "no" and "Basel Red" in s.at["TRK-1", "current"]


def test_missing_or_broken_evidence_is_no_evidence_never_yes(world):
    root, d, out = world
    (out / "hazard_fit.json").unlink()
    (d / "live" / "live_inputs.csv").unlink()
    write(out / "replication" / "replication.csv", "garbage\x00,\n\"unterminated")
    for p in (root / "docs" / "governance" / "releases").glob("*.md"):
        p.unlink()
    s = score(world)
    assert len(s) == 16                                   # the scorecard always returns every row
    for rid in ("MOD-1", "MOD-2", "COV-2", "DAT-1", "MOD-3", "CTL-3"):
        assert s.at[rid, "met"] == "no evidence", rid
    assert "missing" in s.at["MOD-1", "current"] and "unreadable" in s.at["MOD-3", "current"]


def test_write_scorecard_markdown_and_csv(world, tmp_path):
    df = score(world).reset_index()
    df.loc[0, "current"] = "a | b"
    md, csv = T.write_scorecard(df, tmp_path / "out", now=pd.Timestamp("2026-10-24T01:00Z").to_pydatetime())
    text = md.read_text()
    assert text.startswith("# Target-state scorecard (2026-10-24 01:00Z)")
    assert "plan to an institutional-grade desk" in text and "a \\| b" in text
    assert "| id | dimension | target | current | met | evidence |" in text and text.count("\n| ") == len(df) + 1
    back = pd.read_csv(csv, keep_default_na=False)
    assert list(back.columns) == T.COLUMNS and len(back) == len(df)


def test_cli_targets(world, tmp_path, capsys, monkeypatch):
    root, d, out = world
    monkeypatch.setattr(T, "ROOT", root)
    monkeypatch.setenv("ECONQUEST_ACTION_LOG", str(tmp_path / "actions.jsonl"))
    cli.main(["--data", str(d), "--out", str(out), "targets"])
    o = capsys.readouterr().out
    assert "Target-state scorecard: 13 yes" in o and (out / "targets" / "targets.md").exists()
    assert len(pd.read_csv(out / "targets" / "targets.csv")) == 16
    tests = write(tmp_path / "pytest.txt", "== 1 failed, 5 passed in 1s ==\n")
    cli.main(["--data", str(d), "--out", str(out), "targets", "--tests", str(tests), "--dest", str(tmp_path / "t")])
    assert "12 yes" in capsys.readouterr().out
    assert pd.read_csv(tmp_path / "t" / "targets.csv").set_index("id").at["CTL-3", "met"] == "no"
    assert not (tmp_path / "actions.jsonl").exists()      # read-only report: not an operator action
    with pytest.raises(SystemExit) as e:
        cli.main(["targets", "--help"])
    assert e.value.code == 0 and "usage: econquest targets" in capsys.readouterr().out


def test_junit_report_and_bundled_replication_are_scored(world, tmp_path):
    """The evidence bundle passes pytest's junit XML and its own replication table (0.2.0 build)."""
    junit = write(tmp_path / "junit.xml", '<?xml version="1.0"?><testsuites><testsuite tests="14" failures="1" '
                                          'errors="1" skipped="2"></testsuite></testsuites>')
    s = score(world, tests_file=junit)
    assert s.at["CTL-3", "met"] == "no" and s.at["CTL-3", "current"] == "10 passed, 2 failed, 2 skipped"
    ok = write(tmp_path / "ok.xml", '<testsuite tests="5" failures="0" errors="0" skipped="1"/>')
    assert score(world, tests_file=ok).at["CTL-3", "current"] == "4 passed, 0 failed, 1 skipped"
    bad = write(tmp_path / "bad.xml", "<testsuites><oops></testsuites>")
    assert score(world, tests_file=bad).at["CTL-3", "met"] == "no evidence"
    rep = pd.DataFrame({"id": ["R01", "R02"], "status": ["PASS", "FAIL"]})
    s = score(world, replication_table=rep)
    assert s.at["MOD-3", "met"] == "no" and s.at["MOD-3", "current"].startswith("1 PASS, 1 FAIL of 2")
