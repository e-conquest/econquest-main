"""EQ-B-0045: country readiness before scoring (econquest/scorecard/readiness.py).

A country with blank Country Profile or indicator cells used to either stop deep in the scorecard with a partial
message or, worse, run: a blank spread read as a Calm regime, a blank rating gave a NaN PD that dropped out of
sums, a blank fxregime took the peg shock. `score_universe` now stops first with one list of every missing
required field per country. Fixtures blank cells of the shipped 18-country data or use Team A's staged 88-country
folder; no values here are real data.
"""
import dataclasses
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.config import Settings
from econquest.ingestion import load_universe
from econquest.engine import run_pipeline
from econquest.scorecard import score_universe, check_readiness, require_ready, UniverseNotReady
from econquest.scorecard import readiness as R

DATA = ROOT / "data"
AS_OF = "2026-10-23"


@pytest.fixture(scope="module")
def base():
    return load_universe(DATA), Settings.load(DATA / "assumptions.json").copy_with(as_of=AS_OF)


def _with_profile(u, country, **cells):
    c = u.countries.copy()
    for k, v in cells.items():
        c.loc[c["country"] == country, k] = v
    return dataclasses.replace(u, countries=c)


def _with_indicator(u, country, iid, value):
    ind = u.indicators.set_index("id").copy()
    ind[country] = ind[country].astype(object)
    ind.at[iid, country] = value
    return dataclasses.replace(u, indicators=ind.reset_index())


def test_shipped_18_countries_are_ready(base):
    u, s = base
    r = require_ready(u, s)
    assert r.ok and r.missing == {} and r.fallbacks == {}
    assert set(r.coverage.columns) == set(u.names) and (r.coverage.to_numpy() > 0).all()


@pytest.mark.parametrize("field", sorted(R.REQUIRED_PROFILE))
def test_each_blank_required_profile_field_blocks(base, field):
    u, s = base
    r = check_readiness(_with_profile(u, "Brazil", **{field: np.nan}), s)
    assert list(r.missing) == ["Brazil"] and r.missing["Brazil"] == [field]


@pytest.mark.parametrize("iid", sorted(R.REQUIRED_INDICATORS))
def test_each_blank_required_indicator_blocks(base, iid):
    u, s = base
    r = check_readiness(_with_indicator(u, "Colombia", iid, ""), s)
    assert r.missing == {"Colombia": [f"indicator {iid}"]}


def test_advisory_indicator_blank_does_not_block(base):
    u, s = base
    r = check_readiness(_with_indicator(u, "Colombia", "5.10", np.nan), s)
    assert r.ok and "indicator 5.10" in r.advisory["Colombia"] and "pillar 5 coverage" in " ".join(r.advisory["Colombia"])


def test_one_consolidated_error_lists_every_country_and_field(base):
    u, s = base
    u2 = _with_profile(_with_profile(u, "Brazil", rating=np.nan, spread=np.nan), "Japan", fxregime="")
    with pytest.raises(UniverseNotReady) as e:
        score_universe(u2, s)
    msg = str(e.value)
    assert "2 of 18 countries" in msg
    assert "  Brazil: rating, spread" in msg and "  Japan: fxregime" in msg
    assert isinstance(e.value, ValueError) and set(e.value.readiness.missing) == {"Brazil", "Japan"}


def test_pipeline_stops_instead_of_silent_calm_regime_and_nan_pd(base):
    """Before EQ-B-0045 a blank spread ran: regime Calm (NaN comparisons are False) and pd_default NaN."""
    u, s = base
    with pytest.raises(UniverseNotReady, match="Senegal: spread"):
        run_pipeline(_with_profile(u, "Senegal", spread=np.nan), s, paths=512, as_of=AS_OF)


def test_unknown_rating_and_fx_regime_block(base):
    u, s = base
    r = check_readiness(_with_profile(u, "India", rating="Baa2", fxregime="Crawl"), s)
    assert r.missing == {"India": ["fxregime (unknown 'Crawl')", "rating (unknown 'Baa2')"]}


def test_stress_depreciation_required_only_with_positions(base):
    u, s = base
    held = u.portfolio["country"].iloc[0]
    assert check_readiness(_with_profile(u, held, stress_depreciation=np.nan), s).missing == {held: ["stress_depreciation"]}
    u2 = _with_profile(u, held, stress_depreciation=np.nan)
    u2 = dataclasses.replace(u2, portfolio=u2.portfolio[u2.portfolio["country"] != held])
    assert check_readiness(u2, s).ok


def test_blank_yes_no_flags_block_when_the_loader_reports_them(base):
    u, s = base
    u2 = dataclasses.replace(u, provenance={**u.provenance, "blank_yes_no": {"Zambia": ["default", "coup", "CDS"]}})
    assert check_readiness(u2, s).missing == {"Zambia": ["flag default", "flag coup"]}   # instrument flags are not required


def test_empty_country_reported_compactly(base):
    u, s = base
    ind = u.indicators.set_index("id").copy()
    ind["Belize"] = np.nan
    with pytest.raises(UniverseNotReady, match=r"Belize: no indicator values \(pillars 1-7 have no scored indicator; 16 required"):
        require_ready(dataclasses.replace(u, indicators=ind.reset_index()), s)
    r = check_readiness(dataclasses.replace(u, indicators=ind.reset_index()), s)
    f = r.to_frame()
    assert (f[f.blocking & (f.kind == "pillar")]["country"] == "Belize").sum() == 7
    assert list(f.columns) == ["country", "field", "kind", "blocking"]


def test_missing_adjustments_column_falls_back_to_zero(base):
    """Documented fallback: no adjustments.csv column means no analyst adjustment and no trigger input."""
    u, s = base
    a = u.adjustments.copy()
    a["Brazil"] = 0.0
    zero = score_universe(dataclasses.replace(u, adjustments=a), s)
    dropped_u = dataclasses.replace(u, adjustments=a.drop(columns=["Brazil"]))
    dropped = score_universe(dropped_u, s)
    pd.testing.assert_series_equal(zero.composite, dropped.composite)
    assert "adjustments.csv column" in check_readiness(dropped_u, s).fallbacks["Brazil"][0]


def test_staged_88_country_folder_stops_with_the_70_new_countries(tmp_path, base):
    """Team A's staged universe (HO-20261023-A-B-008): the 70 new sovereigns are listed, the 18 desk countries not."""
    staging = DATA / "panel" / "universe_staging"
    if not (staging / "countries.csv").exists():
        pytest.skip("no Team A staging folder")
    from econquest.ingestion.universe import stage_data_dir
    dest = stage_data_dir(staging, tmp_path / "eq88", DATA)
    u88 = load_universe(dest)
    _, s = base
    with pytest.raises(UniverseNotReady) as e:
        score_universe(u88, s)
    missing = e.value.readiness.missing
    new = [c for c in u88.names if c not in base[0].names]
    assert set(missing) == set(new) and len(new) >= 60
    assert all("rating" in missing[c] and "spread" in missing[c] for c in new)
