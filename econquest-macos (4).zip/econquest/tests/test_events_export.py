"""Consumer exports of stored event vintages (EQ-A-0028): Team B events_long.csv (HO-20261023-B-A-004) and Team C
events_weekly.csv (HO-20261023-C-A-007). Synthetic fixtures only (tests/fixtures/events/ucdp, gdelt)."""
from __future__ import annotations

import datetime as dt
import os
import stat
from pathlib import Path

import pandas as pd
import pytest

from econquest.engine import event_index as B
from econquest.ingestion.events import export as X
from econquest.ingestion.events import ucdp as U
from econquest.ingestion.events.base import EVENT_COLUMNS, save_event_vintage
from econquest.presentation import events_view as C

FIX = Path(__file__).parent / "fixtures" / "events"
T1 = dt.datetime(2026, 10, 23, 7, 0, tzinfo=dt.timezone.utc)
T2 = dt.datetime(2026, 11, 5, 7, 0, tzinfo=dt.timezone.utc)
UCDP_PROV = {"datasets": [
    {"dataset": "GED", "version": "26.1", "start": "2025-01-01", "end": "2025-12-31"},
    {"dataset": "Candidate", "version": "26.0.9", "start": "2026-01-01", "end": "2026-02-28"}]}
GDELT_PROV = {"root_only": True, "date_basis": "file"}


def _fixture(source: str, fresh: bool = False) -> pd.DataFrame:
    df = pd.read_csv(FIX / source / "events.csv", dtype={c: str for c in EVENT_COLUMNS if c != "value"},
                     keep_default_na=False)
    df["vintage_id"] = ""
    if fresh:
        df["retrieved_utc"] = ""                       # save_event_vintage stamps the save time
    return df


def _save_both(d: Path, now=T1, fresh=False, ucdp=None, gdelt=None):
    save_event_vintage(d, ucdp if ucdp is not None else _fixture("ucdp", fresh), "ucdp", now=now, provenance=UCDP_PROV)
    save_event_vintage(d, gdelt if gdelt is not None else _fixture("gdelt", fresh), "gdelt", now=now,
                       provenance=GDELT_PROV)


def test_long_schema_mapping_and_team_b_reader(tmp_path):
    _save_both(tmp_path)
    df = X.build_events_long(tmp_path)
    assert list(df.columns) == ["iso", "source", "series", "freq", "period", "value", "vintage", "provenance"]
    assert set(df["source"]) == {"ucdp_ged", "ucdp_candidate", "gdelt"}
    assert set(df.loc[df["source"] != "gdelt", "series"]) == {"events", "fatalities"}
    assert set(df.loc[df["source"] == "gdelt", "series"]) == {"events", "goldstein_mean", "tone_mean"}
    ged = df[df["source"] == "ucdp_ged"]
    cand = df[df["source"] == "ucdp_candidate"]
    assert ged["period"].str[:4].eq("2025").all() and cand["period"].str[:4].eq("2026").all()
    assert set(df.loc[df["source"] != "gdelt", "freq"]) == {"M"} and set(df.loc[df["source"] == "gdelt", "freq"]) == {"D"}
    assert df["vintage"].eq("2026-10-23").all()            # retrieved date of the snapshot, not the event date
    assert ged["provenance"].str.startswith("UCDP GED 26.1").all()
    g = df[df["source"] == "gdelt"]
    assert g["provenance"].str.contains("QuadClass 4").all() and g["provenance"].str.contains("root events").all()
    # GDELT events = material conflict count: NGA 2026-10-20 has 2 root events, 1 of them QuadClass 4
    nga = g[(g["iso"] == "NGA") & (g["period"] == "2026-10-20")].set_index("series")["value"]
    assert nga["events"] == 1.0 and nga["goldstein_mean"] == -8.25
    norm = B.normalize_events(df)                          # Team B's acceptance check raises nothing
    assert len(norm) == len(df)
    assert not df.duplicated(["iso", "source", "series", "freq", "period", "vintage"]).any()


def test_long_keeps_explicit_zeros_and_omits_empty_means(tmp_path):
    _save_both(tmp_path)
    df = X.build_events_long(tmp_path)
    # UCDP: every requested country-month in coverage has events and fatalities, zeros included (2 isos x 14 months)
    u = df[df["source"].str.startswith("ucdp")]
    assert len(u) == 2 * 14 * 2 and (u["value"] == 0).any()
    # GDELT: ARG has no events on either day -> explicit 0 events rows, no goldstein/tone rows
    arg = df[(df["source"] == "gdelt") & (df["iso"] == "ARG")]
    assert sorted(arg["series"]) == ["events", "events"] and (arg["value"] == 0).all()
    assert df["source"].eq("gdelt").sum() > 0 and df.loc[df["series"] == "events", "iso"].nunique() >= 18


def test_vintages_preserved_across_two_saves(tmp_path):
    _save_both(tmp_path, now=T1, fresh=True)
    u2 = _fixture("ucdp", fresh=True)
    m = (u2["iso"] == "NGA") & (u2["period"] == "2026-02-01") & (u2["metric"] == "events_total")
    old = float(u2.loc[m, "value"].iloc[0])
    u2.loc[m, "value"] = old + 5                           # a Candidate revision in the second pull
    save_event_vintage(tmp_path, u2, "ucdp", now=T2, provenance=UCDP_PROV)
    df = X.build_events_long(tmp_path)
    k = df[(df["iso"] == "NGA") & (df["source"] == "ucdp_candidate") & (df["series"] == "events")
           & (df["period"] == "2026-02-01")]
    assert list(k["vintage"]) == ["2026-10-23", "2026-11-05"] and list(k["value"]) == [old, old + 5]
    # unchanged rows are not repeated for the second vintage
    assert (df["vintage"] == "2026-11-05").sum() == 1
    e = B.normalize_events(df)
    before = B.point_in_time(e, "2026-10-30")
    after = B.point_in_time(e, "2026-11-30")
    sel = lambda t: t[(t["iso"] == "NGA") & (t["series"] == "events") & (t["period"] == "2026-02-01")]["value"].item()  # noqa: E731
    assert sel(before) == old and sel(after) == old + 5


def test_rows_outside_manifest_windows_are_dropped_not_guessed(tmp_path):
    save_event_vintage(tmp_path, _fixture("ucdp"), "ucdp", now=T1,
                       provenance={"datasets": [UCDP_PROV["datasets"][0]]})
    df, problems, _ = X._build_long(tmp_path)
    assert set(df["source"]) == {"ucdp_ged"} and problems and "dropped" in problems[0]


def test_ged_release_date_used_as_vintage_when_recorded(tmp_path):
    prov = {"datasets": [dict(UCDP_PROV["datasets"][0], release_date="2026-06-15"), UCDP_PROV["datasets"][1]]}
    save_event_vintage(tmp_path, _fixture("ucdp"), "ucdp", now=T1, provenance=prov)
    df = X.build_events_long(tmp_path)
    assert set(df.loc[df["source"] == "ucdp_ged", "vintage"]) == {"2026-06-15"}
    assert set(df.loc[df["source"] == "ucdp_candidate", "vintage"]) == {"2026-10-23"}


def test_weekly_schema_monday_buckets_and_weighted_means(tmp_path):
    (tmp_path / "countries.csv").write_text("country,iso\nNigeria,NGA\nSingapore,SGP\n")
    _save_both(tmp_path)
    w = X.build_events_weekly(tmp_path)
    assert list(w.columns) == list(C.EVENT_SCHEMA)
    ws = pd.to_datetime(w["week_start"], format="%Y-%m-%d")
    assert (ws.dt.weekday == 0).all() and set(w["week_start"]) == {"2026-10-19"}
    assert set(w["source"]) == {"GDELT"}
    tot = w[(w["iso3"] == "NGA") & (w["event_type"] == "")].iloc[0]
    assert tot["event_count"] == 3 and tot["country"] == "Nigeria"
    assert tot["goldstein_mean"] == pytest.approx((-8.25 * 2 - 6.5) / 3)
    assert tot["tone_mean"] == pytest.approx((-6.5 * 2 - 4.5) / 3)
    br = w[(w["iso3"] == "NGA") & (w["event_type"] != "")].set_index("event_type")["event_count"]
    assert br.to_dict() == {"material_conflict": 1, "verbal_conflict": 2, "protest": 2}
    arg = w[(w["iso3"] == "ARG") & (w["event_type"] == "")].iloc[0]
    assert arg["event_count"] == 0 and pd.isna(arg["goldstein_mean"])   # explicit zero, no mean
    assert w["fatalities"].isna().all()


def test_weekly_uses_newest_vintage_per_day(tmp_path):
    g1 = _fixture("gdelt")
    save_event_vintage(tmp_path, g1, "gdelt", now=T1, provenance=GDELT_PROV)
    g2 = g1[g1["period"] == "2026-10-21"].copy()            # second pull re-stages one day with one more event
    m = (g2["iso"] == "NGA") & (g2["metric"] == "events_total")
    g2.loc[m, "value"] = 2.0
    save_event_vintage(tmp_path, g2, "gdelt", now=T2, provenance=GDELT_PROV)
    w = X.build_events_weekly(tmp_path)
    assert w[(w["iso3"] == "NGA") & (w["event_type"] == "")]["event_count"].item() == 4   # 2 (day 1, v1) + 2 (day 2, v2)


def test_write_exports_atomic_archive_and_team_c_reader(tmp_path):
    with pytest.raises(FileNotFoundError):
        X.write_event_exports(tmp_path)
    assert X.load_events_long(tmp_path) is None
    _save_both(tmp_path)
    out = X.write_event_exports(tmp_path, now=T1)
    assert out["long"] == tmp_path / "live" / "events" / "events_long.csv"
    assert out["weekly"] == tmp_path / "live" / "events_weekly.csv"
    arch = out["archive"]
    assert arch.parent == tmp_path / "live" / "events" / "exports"
    for name in ("events_long.csv", "events_weekly.csv", "manifest.json"):
        assert not os.stat(arch / name).st_mode & (stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH)
    assert (arch / "events_long.csv").read_bytes() == out["long"].read_bytes()
    assert not list(out["long"].parent.glob(".*.tmp"))
    # unchanged: no second archive
    again = X.write_event_exports(tmp_path, now=T2)
    assert again["archive"] == arch and len(list((tmp_path / "live" / "events" / "exports").iterdir())) == 2
    # Team B: reads the file as written
    raw = pd.read_csv(out["long"])
    B.normalize_events(raw)
    ev = X.load_events_long(tmp_path)
    assert list(ev.columns) == X.LONG_COLUMNS
    assert pd.api.types.is_datetime64_any_dtype(ev["period"]) and pd.api.types.is_datetime64_any_dtype(ev["vintage"])
    assert ev["iso"].map(type).eq(str).all() and ev["value"].dtype == float
    # Team C: its reader finds and accepts the weekly file
    assert C.find_event_files(tmp_path) == [out["weekly"]]
    df, files, problems = C.load_events(tmp_path)
    assert problems == [] and df is not None and len(df) > 0
    s = C.event_summary(tmp_path, countries=[("Nigeria", "NGA")], as_of="2026-10-27")
    assert s["status"] in ("ok", "stale") and any(r["country"] == "Nigeria" and r["events"] == 3 for r in s["rows"])


def test_ucdp_cli_writes_exports(tmp_path, monkeypatch):
    def fake_pull(data_dir, start, end, isos=None, fetcher=None, now=None):
        return save_event_vintage(data_dir, _fixture("ucdp"), "ucdp", now=T1, provenance=UCDP_PROV)
    monkeypatch.setattr(U, "pull_and_save", fake_pull)
    assert U.main(["--data-dir", str(tmp_path), "--start", "2025-01-01", "--end", "2026-02-28"]) == 0
    assert (tmp_path / "live" / "events" / "events_long.csv").exists()
    assert (tmp_path / "live" / "events_weekly.csv").read_text().strip() == ",".join(C.EVENT_SCHEMA)  # no GDELT yet
