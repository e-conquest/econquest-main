"""EQ-B-0033 (GOV-014): event stress index from UCDP and GDELT for the layer-2 text term.

All event data here is SYNTHETIC (tests/fixtures/event_fixture.py, tests/fixtures/events_sample.csv): it tests
the mechanism, the point-in-time rule and the backtest harness, and says nothing about real-world lead times.
The shipped default (probability.text_index absent -> source 'none') must leave layer 2 bit-identical."""
import functools
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(ROOT / "tests" / "fixtures"))
from econquest.config import Settings
from econquest.ingestion import load_universe
from econquest.engine import event_index as EI, layer1_hazard as L1, layer2_bayesian as L2
from econquest.scorecard import score_universe
from event_fixture import PROVENANCE, synthetic_events, synthetic_defaults, synthetic_spreads

DATA = ROOT / "data"
AS_OF = "2026-10-23"
ISOS = ["XAA", "XBB", "XCC", "XDD"]
SHOCKS = [("XAA", "2026-07-15", 6, 1.0), ("XBB", "2026-04-01", 2, 1.0)]


@pytest.fixture(scope="module")
def ev():
    return EI.normalize_events(synthetic_events(ISOS, start="2019-01-01", shocks=SHOCKS, seed=3))


@pytest.fixture(scope="module")
def inputs():
    u = load_universe(DATA)
    s = Settings.load(DATA / "assumptions.json").copy_with(as_of=AS_OF)
    sc = score_universe(u, s)
    l1 = L1.run_layer1(u, s, sc.pillar_aggregated.loc[4])
    return u, s, sc, l1


# ---------------------------------------------------------------- contract

def test_sample_fixture_meets_contract_and_is_labelled_synthetic():
    raw = pd.read_csv(ROOT / "tests" / "fixtures" / "events_sample.csv")
    e = EI.normalize_events(raw)
    assert list(raw.columns[:7]) == EI.EVENT_COLUMNS
    assert (raw["provenance"] == PROVENANCE).all() and "SYNTHETIC" in PROVENANCE
    assert set(e["freq"]) == {"D", "M", "A"}


def test_contract_rejects_missing_column_and_unknown_codes():
    raw = pd.read_csv(ROOT / "tests" / "fixtures" / "events_sample.csv")
    with pytest.raises(ValueError, match="lacks columns"):
        EI.normalize_events(raw.drop(columns="vintage"))
    bad = raw.copy(); bad.loc[0, "source"] = "acled"
    with pytest.raises(ValueError, match="unknown source"):
        EI.normalize_events(bad)
    bad = raw.copy(); bad.loc[0, "freq"] = "W"
    with pytest.raises(ValueError, match="unknown freq"):
        EI.normalize_events(bad)


def test_settings_defaults_off_and_validation():
    assert EI.index_settings(None)["source"] == "none"
    s = Settings.load(DATA / "assumptions.json")
    assert s.get("probability", "text_index", "source") == "none"     # recorded off (CHG-20261023T190523Z-b96d25)
    assert EI.index_settings(s)["source"] == "none"
    with pytest.raises(ValueError, match="source"):
        EI.index_settings(s.copy_with(**{"probability.text_index.source": "gdelt"}))
    with pytest.raises(ValueError, match="unknown components"):
        EI.index_settings(s.copy_with(**{"probability.text_index.weights": {"protests": 1.0}}))
    assert abs(sum(EI.DEFAULTS["weights"].values()) - 1.0) < 1e-12


# ---------------------------------------------------------------- index behaviour

def test_shocked_country_scores_high_calm_near_zero_missing_flagged(ev):
    r = EI.event_stress_index(ev, AS_OF, isos=ISOS + ["XZZ"], normalized=True)
    assert r.at["XAA", "event_index"] > 1.5 and r.at["XAA", "flag"] == "ok"
    assert abs(r.at["XCC", "event_index"]) < 1.0 and abs(r.at["XDD", "event_index"]) < 1.0
    assert r.at["XZZ", "event_index"] == 0.0 and r.at["XZZ", "flag"] == "missing"
    # signs: lower Goldstein and more negative tone are stress (positive z)
    assert r.at["XAA", "z_goldstein"] > 1 and r.at["XAA", "z_tone"] > 1 and r.at["XAA", "z_fatalities"] > 0
    assert (r["event_index"].abs() <= EI.DEFAULTS["clip"]).all()


def test_point_in_time_future_rows_and_vintages_ignored(ev):
    base = EI.event_stress_index(ev, "2026-06-30", isos=ISOS, normalized=True)
    later = ev[(ev["vintage"] > "2026-06-30")].copy()
    later["value"] = later["value"] * 50 + 1000            # anything published after as_of
    poisoned = pd.concat([ev[ev["vintage"] <= "2026-06-30"], later], ignore_index=True)
    again = EI.event_stress_index(poisoned, "2026-06-30", isos=ISOS, normalized=True)
    pd.testing.assert_frame_equal(base, again)
    # a revision of an old period published after as_of is invisible at as_of
    rev = ev[(ev["source"] == "gdelt") & (ev["series"] == "tone_mean") & (ev["period"] == "2026-06-01")].copy()
    rev["value"] = -50.0; rev["vintage"] = pd.Timestamp("2026-07-15")
    with_rev = pd.concat([ev, rev], ignore_index=True)
    pd.testing.assert_frame_equal(base, EI.event_stress_index(with_rev, "2026-06-30", isos=ISOS, normalized=True))
    pit = EI.point_in_time(with_rev, "2026-07-20")
    hit = pit[(pit["source"] == "gdelt") & (pit["series"] == "tone_mean") & (pit["iso"] == "XAA")
              & (pit["period"] == pd.Timestamp("2026-06-01"))]
    assert hit["value"].tolist() == [-50.0]                # once published, the latest vintage wins


def test_final_ged_takes_precedence_over_candidate():
    rows = pd.DataFrame({"iso": "XAA", "source": ["ucdp_candidate", "ucdp_ged"], "series": "fatalities", "freq": "M",
                         "period": "2025-03-01", "value": [5.0, 7.0], "vintage": ["2025-04-25", "2026-06-15"]})
    u = EI._to_units(EI.point_in_time(EI.normalize_events(rows), AS_OF))
    assert EI._component_frame(u, "fatalities")["value"].tolist() == [7.0]
    u0 = EI._to_units(EI.point_in_time(EI.normalize_events(rows), "2025-12-31"))
    assert EI._component_frame(u0, "fatalities")["value"].tolist() == [5.0]


def test_mixed_daily_and_monthly_rows_rejected_or_ranked():
    # EQ-B-0047 (review Low): the old dedupe on (iso, period) dropped only the day-1 daily row, so a source's daily
    # rows and its monthly row for the same month were both counted
    days = pd.date_range("2025-03-01", "2025-03-31").strftime("%Y-%m-%d")
    daily = pd.DataFrame({"iso": "XAA", "source": "ucdp_candidate", "series": "fatalities", "freq": "D", "period": days,
                          "value": 1.0, "vintage": "2025-04-25"})
    monthly = pd.DataFrame({"iso": "XAA", "source": ["ucdp_candidate"], "series": "fatalities", "freq": "M",
                            "period": "2025-03-01", "value": [31.0], "vintage": "2025-04-25"})
    u = EI._to_units(EI.point_in_time(EI.normalize_events(pd.concat([daily, monthly])), AS_OF))
    with pytest.raises(ValueError, match="daily and monthly rows for the same country-month"):
        EI._component_frame(u, "fatalities")
    # across sources, the preferred source's month wins whole: final GED monthly drops the candidate's daily rows
    ged = monthly.assign(source="ucdp_ged", value=40.0, vintage="2026-06-15")
    u = EI._to_units(EI.point_in_time(EI.normalize_events(pd.concat([daily, ged])), AS_OF))
    f = EI._component_frame(u, "fatalities")
    assert f["value"].tolist() == [40.0] and f["freq"].tolist() == ["M"]
    # daily and monthly rows of one source in different months are fine
    feb = monthly.assign(period="2025-02-01")
    u = EI._to_units(EI.point_in_time(EI.normalize_events(pd.concat([daily, feb])), AS_OF))
    assert len(EI._component_frame(u, "fatalities")) == 32


def test_annual_rows_split_into_months():
    rows = pd.DataFrame({"iso": "XAA", "source": "ucdp_ged", "series": ["events", "fatalities"], "freq": "A",
                         "period": "2024-01-01", "value": [24.0, 120.0], "vintage": "2025-06-15"})
    u = EI._to_units(EI.normalize_events(rows))
    assert len(u) == 24 and u.groupby("series")["value"].sum().to_dict() == {"events": 24.0, "fatalities": 120.0}
    assert u["period"].min() == pd.Timestamp("2024-01-01") and u["period"].max() == pd.Timestamp("2024-12-01")


def test_partial_and_insufficient_coverage(ev):
    gd_only = ev[ev["source"] == "gdelt"]
    r = EI.event_stress_index(gd_only, AS_OF, isos=ISOS, normalized=True)
    assert (r["flag"] == "partial").all() and np.allclose(r["coverage"], 0.5)
    tone_only = ev[(ev["source"] == "gdelt") & (ev["series"] == "tone_mean")]
    r = EI.event_stress_index(tone_only, AS_OF, isos=ISOS, normalized=True)
    assert (r["flag"] == "insufficient").all() and (r["event_index"] == 0.0).all()


def test_stale_component_and_short_history_not_scored(ev):
    ucdp = ev[ev["source"] != "gdelt"]
    r = EI.event_stress_index(ucdp[ucdp["period"] <= "2026-03-01"], AS_OF, isos=ISOS, normalized=True)
    assert r["z_fatalities"].isna().all() and (r["event_index"] == 0.0).all()
    short = ev[ev["period"] >= "2026-01-01"]                 # under min_history trailing windows
    r = EI.event_stress_index(short, AS_OF, isos=ISOS, normalized=True)
    assert (r["flag"] == "insufficient").all()


def test_explicit_zero_is_calm_not_missing():
    months = pd.date_range("2019-01-01", "2026-08-01", freq="MS")
    rows = pd.concat([pd.DataFrame({"iso": "XAA", "source": "ucdp_candidate", "series": s, "freq": "M", "period": months,
                                    "value": 0.0, "vintage": months + pd.offsets.MonthEnd(0) + pd.Timedelta(days=25)})
                      for s in ("events", "fatalities")])
    r = EI.event_stress_index(rows, AS_OF, isos=["XAA"])
    assert r.at["XAA", "flag"] == "partial" and r.at["XAA", "event_index"] == 0.0 and r.at["XAA", "z_fatalities"] == 0.0


def test_deterministic(ev):
    a = EI.event_stress_index(ev, AS_OF, isos=ISOS, normalized=True)
    b = EI.event_stress_index(ev.sample(frac=1.0, random_state=1), AS_OF, isos=ISOS, normalized=True)
    pd.testing.assert_frame_equal(a, b)


# ---------------------------------------------------------------- layer 2 wiring

def test_layer2_default_is_bit_identical_even_with_events(inputs, ev, monkeypatch):
    u, s, sc, l1 = inputs
    before = L2.posterior(u, s, l1["pd_model"], sc.composite)
    prof = u.countries.set_index("country").loc[u.names]
    assert np.array_equal(before["z_tsi"].to_numpy(), prof["textz"].to_numpy(dtype=float))
    assert (before["event_flag"] == "off").all() and (before["z_event"] == 0.0).all()
    monkeypatch.setattr(u, "events", ev, raising=False)    # data present, source still 'none'
    after = L2.posterior(u, s, l1["pd_model"], sc.composite)
    assert np.array_equal(before["logodds_post"].to_numpy(), after["logodds_post"].to_numpy())


def test_layer2_events_without_data_is_zero_and_flagged(inputs):
    u, s, sc, l1 = inputs
    on = s.copy_with(**{"probability.text_index.source": "events"})
    a = L2.posterior(u, s, l1["pd_model"], sc.composite)
    b = L2.posterior(u, on, l1["pd_model"], sc.composite)
    assert (b["event_flag"] == "missing").all()
    assert np.array_equal(a["logodds_post"].to_numpy(), b["logodds_post"].to_numpy())


def test_layer2_events_on_moves_logodds_by_w_t_times_index(inputs, monkeypatch):
    u, s, sc, l1 = inputs
    isos = list(u.countries["iso"])
    ev = synthetic_events(isos, start="2019-01-01", shocks=[(isos[0], "2026-07-15", 6, 1.0)], seed=5)
    monkeypatch.setattr(u, "events", ev, raising=False)
    on = s.copy_with(**{"probability.text_index.source": "events"})
    a = L2.posterior(u, s, l1["pd_model"], sc.composite)
    b = L2.posterior(u, on, l1["pd_model"], sc.composite)
    idx = EI.event_stress_index(ev, AS_OF, isos=isos)["event_index"].reindex(isos).to_numpy()
    assert np.allclose(b["z_event"].to_numpy(), idx)
    assert np.allclose(b["logodds_post"] - a["logodds_post"], s["probability"]["w_t"] * idx)
    assert b["z_event"].iloc[0] > 1.0 and b["pd_post"].iloc[0] > a["pd_post"].iloc[0]
    # scenario shocks to textz still add on top
    assert np.allclose(b["z_tsi"].to_numpy(), u.countries.set_index("country").loc[u.names, "textz"].to_numpy() + idx)


# ---------------------------------------------------------------- backtest harness

@functools.lru_cache(maxsize=2)
def _backtest(planted: bool):
    isos = [f"X{a}{b}" for a in "ABCDEF" for b in "AB"]
    rng = np.random.default_rng(11)
    shocks = []
    for i, iso in enumerate(isos):
        start = pd.Timestamp("2020-01-01") + pd.Timedelta(days=int(rng.integers(0, 4 * 365)))
        shocks.append((iso, start.strftime("%Y-%m-%d"), 5, 1.0, i % 2 == 0))
    ev = synthetic_events(isos, start="2015-01-01", end="2025-12-31", shocks=shocks, seed=7)
    if planted:
        defaults = synthetic_defaults(shocks, lead_months=6)
    else:   # null: default dates drawn independently of the shocks
        defaults = pd.DataFrame([{"iso": iso, "start": 0, "start_date": (pd.Timestamp("2020-01-01") + pd.Timedelta(days=int(rng.integers(0, 5 * 365)))).strftime("%Y-%m-%d"), "end": 0}
                                 for iso in isos[::2]])
        defaults["start"] = pd.to_datetime(defaults["start_date"]).dt.year; defaults["end"] = defaults["start"]
    dates = pd.date_range("2020-01-31", "2024-12-31", freq="QE")
    hist = EI.index_history(ev, dates, isos=isos)
    return hist, defaults, shocks, isos


def test_backtest_recovers_planted_lead_and_null_is_uninformative():
    hist, defaults, _, _ = _backtest(planted=True)
    res = EI.default_lead_auc(hist, defaults).set_index("window")
    # planted: shocks start 6 months before half the defaults and last 5 months, so the index leads at 0-6m
    assert res.at["+0..+6m", "events"] >= 6 and res.at["+0..+6m", "auc"] > 0.85
    assert res.at["+0..+6m", "auc"] > res.at["-12..0m (lagging)", "auc"] + 0.3
    hist0, defaults0, _, _ = _backtest(planted=False)
    res0 = EI.default_lead_auc(hist0, defaults0).set_index("window")
    assert 0.25 < res0.at["+0..+6m", "auc"] < 0.75 and 0.25 < res0.at["+0..+12m", "auc"] < 0.75


def test_spread_lead_lag_on_fixture():
    hist, _, shocks, isos = _backtest(planted=True)
    spreads = synthetic_spreads(isos, shocks, end="2025-12-31")
    ll = EI.spread_lead_lag(hist, spreads).set_index("horizon_days")
    # the fixture widens spreads 60 days after a shock starts: the index flags widening over the next 30-91 days
    assert ll.at[30, "auc_widen"] > 0.8 and ll.at[91, "auc_widen"] > 0.65 and ll.at[91, "n"] > 100


def test_default_starts_from_panel_and_episode_table():
    panel = pd.DataFrame({"iso": ["ARG", "ARG"], "year": [2019, 2020], "event": [0, 1]})
    sp = EI.default_starts(panel)
    assert sp["start_date"].tolist() == [pd.Timestamp("2020-07-01")]
    episodes = pd.read_csv(DATA / "panel" / "sovereign_defaults.csv")
    sp = EI.default_starts(episodes)
    assert len(sp) == len(episodes) and (sp["start_date"].dt.month == 7).all()
