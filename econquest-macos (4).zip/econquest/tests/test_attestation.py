"""EQ-A-0018: author and approver on every hand-entered cell (adjustments, cds_quotes, prediction_markets) through the
review ledger; unattested cells are reported in the audit trail, never blocked."""
import shutil
from pathlib import Path

import pandas as pd
import pytest

from econquest.ingestion import load_universe
from econquest.ingestion.audit import ATTESTATION_COLUMNS, HAND_ATTESTED, HAND_UNATTESTED, build_audit_trail
from econquest.ingestion.ledger import (HAND_ENTERED, attest_cells, attestation_status, effective_holds,
                                        hand_entered_cells, load_decisions, read_ledger, record_decision,
                                        unattested_cells)

SEED = Path(__file__).resolve().parent / "seed_data"


@pytest.fixture
def d(tmp_path):
    d = tmp_path / "data"; shutil.copytree(SEED, d)
    (d / "cds_quotes.csv").write_text("country,date,tenor_y,spread_bp,recovery,source\n"
                                      "Argentina,2026-10-20,5,1450,0.25,desk\nBrazil,2026-10-20,5,180,0.4,desk\n")
    return d


def _pm(d, pm, col, val):
    p = d / "prediction_markets.csv"
    df = pd.read_csv(p, dtype=str, keep_default_na=False); df.loc[df["id"] == pm, col] = val; df.to_csv(p, index=False)


def test_cells_per_file(d):
    pm = hand_entered_cells(d, "prediction_markets.csv")
    adj = hand_entered_cells(d, "adjustments")
    cds = hand_entered_cells(d, "cds_quotes")
    assert len(pm) == 18 and pm[0]["key"] == "PM01" and pm[0]["country"] == "Argentina" and pm[0]["value"] == "0.18"
    assert len(adj) == 21 * 18 and adj[0]["key"] == "Trigger add-ons (capped)|1" and adj[0]["country"] == "Vietnam"
    assert [(c["key"], c["country"], c["value"]) for c in cds] == [("2026-10-20|5", "Argentina", "1450"), ("2026-10-20|5", "Brazil", "180")]
    assert len({c["content_sha256"] for c in adj}) == len(adj)


def test_everything_unattested_until_attested(d):
    assert len(unattested_cells(d)) == 18 + 378 + 2
    rows = attest_cells(d, "prediction_markets", "alice", approver="bob", note="desk check")
    assert len(rows) == 18
    r = rows[0]
    assert (r["table"], r["key"], r["country"], r["decision"], r["live"], r["author"], r["approver"], r["self_approved"]) == \
        ("prediction_markets", "PM01", "Argentina", "apply", 0.18, "alice", "bob", "")
    led = read_ledger(d)
    assert len(led) == 18 and led["content_sha256"].str.len().eq(64).all()
    assert len(unattested_cells(d, ["prediction_markets"])) == 0
    assert attest_cells(d, "prediction_markets", "alice", approver="bob") == []          # nothing new to attest
    assert len(attest_cells(d, "prediction_markets", "alice", approver="bob", all_cells=True)) == 18


def test_four_eyes_and_self_approval(d):
    for bad in (None, "", "Alice", " a lice ", "аlice"):
        with pytest.raises(ValueError, match="four-eyes"):
            attest_cells(d, "cds_quotes", "alice", approver=bad)
    assert read_ledger(d).empty                                                         # refused before any write
    rows = attest_cells(d, "cds_quotes", "sam", self_approved=True)
    assert len(rows) == 2 and all(r["self_approved"] == "yes" and r["approver"] == "sam" for r in rows)
    st = {(c["key"], c["country"]): c for c in attestation_status(d, ["cds_quotes"])}
    assert st[("2026-10-20|5", "Brazil")]["attested"] == "yes" and st[("2026-10-20|5", "Brazil")]["self_approved"] == "yes"


def test_edit_after_attestation_is_unattested(d):
    attest_cells(d, "prediction_markets", "alice", approver="bob")
    _pm(d, "PM02", "yes_price", "0.95")                     # value changed
    _pm(d, "PM03", "contract", "something else")            # description changed: same value, different content
    un = unattested_cells(d, ["prediction_markets"])
    assert sorted(c["key"] for c in un) == ["PM02", "PM03"]
    rows = attest_cells(d, "prediction_markets", "carol", approver="dave")
    assert sorted(r["key"] for r in rows) == ["PM02", "PM03"]
    assert unattested_cells(d, ["prediction_markets"]) == []
    _pm(d, "PM02", "yes_price", "0.22")                     # back to the attested content: attested again by alice/bob
    st = {c["key"]: c for c in attestation_status(d, ["prediction_markets"])}
    assert st["PM02"]["attested"] == "yes" and st["PM02"]["author"] == "alice"


def test_later_reject_withdraws_attestation_and_hand_rows_need_approval(d):
    attest_cells(d, "prediction_markets", "alice", approver="bob")
    record_decision(d, "prediction_markets", "PM01", "Argentina", "reject", "carol", note="stale price")
    assert [c["key"] for c in unattested_cells(d, ["prediction_markets"])] == ["PM01"]
    # an unapproved hand-appended apply row with the right hash does not count
    from econquest.ingestion import ledger
    sha = hand_entered_cells(d, "adjustments")[0]["content_sha256"]
    ledger._append(d, [{"ts_utc": "t", "table": "adjustments", "key": "Trigger add-ons (capped)|1", "country": "Vietnam",
                        "decision": "apply", "author": "eve", "approver": "", "content_sha256": sha}])
    assert ("Trigger add-ons (capped)|1", "Vietnam") in {(c["key"], c["country"]) for c in unattested_cells(d, ["adjustments"])}
    # attestations never create holds on gate cells
    assert effective_holds(None, load_decisions(d)) == {("prediction_markets", "PM01", "Argentina")}


def test_bad_file_names_refused(d):
    for bad in ("../adjustments.csv", "data/adjustments.csv", "indicators.csv", "portfolio"):
        with pytest.raises(ValueError, match="hand-entered"):
            attest_cells(d, bad, "alice", approver="bob")
    assert set(HAND_ENTERED) == {"adjustments.csv", "cds_quotes.csv", "prediction_markets.csv"}


def test_audit_trail_shows_attestation_and_does_not_block_loading(d):
    attest_cells(d, "prediction_markets", "alice", approver="bob")
    attest_cells(d, "cds_quotes", "sam", self_approved=True)
    load_universe(d)                                                                     # unattested adjustments: no error
    df = build_audit_trail(d)
    assert list(df.columns[-4:]) == ATTESTATION_COLUMNS and list(df.columns[:16]) == [
        "table", "key", "indicator", "country", "value", "origin", "source", "series", "transform", "retrieved",
        "gate_status", "gate_reason", "decision", "seed_value", "live_value", "robustness_rule"]
    pm = df[df["table"] == "prediction_markets"]
    assert len(pm) == 18 and (pm["origin"] == HAND_ATTESTED).all() and (pm["author"] == "alice").all() and (pm["approver"] == "bob").all()
    cds = df[df["table"] == "cds_quotes"]
    assert (cds["self_approved"] == "yes").all() and cds["value"].tolist() == [1450.0, 180.0]
    adj = df[df["table"] == "adjustments"]
    assert len(adj) == 378 and (adj["origin"] == HAND_UNATTESTED).all() and (adj["attested"] == "no").all()
    inputs = df[df["table"] == "Inputs"]
    assert len(inputs) > 0 and (inputs["attested"] == "").all()
    assert len(build_audit_trail(d, hand_entered=False)) == len(df) - 18 - 2 - 378
