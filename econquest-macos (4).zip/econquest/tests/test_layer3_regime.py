"""Layer 3 global state (EQ-B-0042, GOV-018): `regime.global_set`, the logistic `regime.global_switch` and the
blended layer-5 inputs. Regime labels for the 88-country names are synthetic fixtures, not observed regimes."""
import sys
import types
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.config import Settings
from econquest.ingestion import load_universe
from econquest.ingestion.universe import load_universe_proposal
from econquest.engine import run_pipeline, pipeline as PL
from econquest.engine import layer3_regime as L3, layer5_copula as L5

DATA = ROOT / "data"


@pytest.fixture(scope="module")
def s():
    return Settings.load(DATA / "assumptions.json")


@pytest.fixture(scope="module")
def u():
    return load_universe(DATA)


def _old_global_regime(regime, settings):
    """The pre-EQ-B-0042 rule, kept here as the reference."""
    share = float((regime != "Calm").mean())
    return "Stressed" if share >= settings["monte_carlo"]["global_stress_share"] else "Calm"


def _regimes88():
    """Synthetic fixture: the 7 DM anchors Calm, half of the other 81 proposal countries Stressed or Crisis."""
    p = load_universe_proposal()
    lab = []
    for i, t in enumerate(p["tier"]):
        lab.append("Calm" if t == "DM_anchor" else ("Stressed" if i % 2 == 0 else ("Crisis" if i % 5 == 0 else "Calm")))
    return pd.Series(lab, index=p["name"].tolist())


def test_default_all_matches_the_old_rule(s, u):
    regime = L3.rule_regime(u, s)
    assert L3.global_set(regime, s) == list(regime.index)
    assert L3.global_share(regime, s) == float((regime != "Calm").mean())
    for thr in np.arange(0.2, 0.8, 0.025):
        st = s.copy_with(**{"monte_carlo.global_stress_share": float(thr)})
        assert L3.global_regime(regime, st) == _old_global_regime(regime, st)
        assert L3.global_stress_weight(regime, st) == (1.0 if _old_global_regime(regime, st) == "Stressed" else 0.0)


def test_global_set_list_by_name_and_iso(s, u):
    regime = L3.rule_regime(u, s)
    by_name = s.copy_with(**{"regime.global_set": ["Argentina", "Zimbabwe", "Japan", "Germany"]})   # Germany not in the run: skipped
    assert L3.global_set(regime, by_name) == ["Japan", "Argentina", "Zimbabwe"]
    by_iso = s.copy_with(**{"regime.global_set": ["ARG", "ZWE", "JPN"]})
    assert L3.global_set(regime, by_iso) == L3.global_set(regime, by_name)
    assert L3.global_share(regime, by_iso) == float((regime[["Japan", "Argentina", "Zimbabwe"]] != "Calm").mean())


def test_exclude_dm_anchors_lifts_the_share_over_88():
    regime = _regimes88()
    base = Settings(raw={"monte_carlo": {"global_stress_share": 0.5}, "regime": {}})
    ex = base.copy_with(**{"regime.global_set": {"exclude_tiers": ["DM_anchor"]}})
    em = base.copy_with(**{"regime.global_set": {"tiers": ["EM", "frontier", "desk_current"]}})
    assert len(L3.global_set(regime, base)) == 88 and len(L3.global_set(regime, ex)) == 81
    assert L3.global_set(regime, ex) == L3.global_set(regime, em)
    assert not set(L3.global_set(regime, ex)) & {"United States", "Germany", "United Kingdom", "France", "Italy", "Canada", "Australia"}
    sh_all, sh_ex = L3.global_share(regime, base), L3.global_share(regime, ex)
    n_bad = int((regime != "Calm").sum())
    assert sh_all == pytest.approx(n_bad / 88) and sh_ex == pytest.approx(n_bad / 81) and sh_ex > sh_all
    thr = (sh_all + sh_ex) / 2          # the anchors alone decide the global state at this threshold
    assert L3.global_regime(regime, base.copy_with(**{"monte_carlo.global_stress_share": thr})) == "Calm"
    assert L3.global_regime(regime, ex.copy_with(**{"monte_carlo.global_stress_share": thr})) == "Stressed"


@pytest.mark.parametrize("spec, msg", [(["Atlantis"], "unknown countries"), ({"tiers": ["G7"]}, "unknown tiers"),
                                       ({"tiers": ["DM_anchor"]}, "selects no country"), (42, "must be 'all'"), ({}, "must be 'all'")])
def test_bad_global_set_raises(s, u, spec, msg):
    regime = L3.rule_regime(u, s)
    with pytest.raises(ValueError, match=msg):
        L3.global_share(regime, s.copy_with(**{"regime.global_set": spec}))


def test_bad_switch_or_width_raises(s, u):
    regime = L3.rule_regime(u, s)
    with pytest.raises(ValueError, match="global_switch"):
        L3.global_stress_weight(regime, s.copy_with(**{"regime.global_switch": "sigmoid"}))
    with pytest.raises(ValueError, match="width"):
        L3.global_stress_weight(regime, s.copy_with(**{"regime.global_switch": "logistic", "regime.global_switch_width": 0}))


def test_logistic_weight_is_smooth_and_keeps_the_label(s, u):
    regime = L3.rule_regime(u, s)
    share = L3.global_share(regime, s)
    lg = s.copy_with(**{"regime.global_switch": "logistic"})
    at = L3.global_stress_weight(regime, lg.copy_with(**{"monte_carlo.global_stress_share": share}))
    assert at == pytest.approx(0.5)
    thr = np.arange(0.2, 0.8, 0.01)
    w = [L3.global_stress_weight(regime, lg.copy_with(**{"monte_carlo.global_stress_share": float(t)})) for t in thr]
    assert np.all(np.diff(w) < 0) and 0 < min(w) and max(w) < 1
    assert np.max(np.abs(np.diff(w))) < 0.06          # no cliff: at most 0.05 per 0.01 of threshold with width 0.05
    for t in thr:                                     # the label is the step rule's label
        st = s.copy_with(**{"monte_carlo.global_stress_share": float(t)})
        assert L3.global_regime(regime, lg.copy_with(**{"monte_carlo.global_stress_share": float(t)})) == _old_global_regime(regime, st)


def test_blended_layer5_inputs(s, u):
    regime = L3.rule_regime(u, s)
    calm, st = L5.factor_loadings(u, s, regime, "Calm"), L5.factor_loadings(u, s, regime, "Stressed")
    assert L3.blended_factor_loadings(u, s, regime, 0.0).equals(calm)
    assert L3.blended_factor_loadings(u, s, regime, 1.0).equals(st)
    mid = L3.blended_factor_loadings(u, s, regime, 0.25)
    assert np.allclose(mid.to_numpy(float), 0.75 * calm.to_numpy(float) + 0.25 * st.to_numpy(float))
    assert np.allclose(mid.sum(axis=1).astype(float), 1.0) and (mid["idio"] >= 0.05 - 1e-12).all()
    mc = s["monte_carlo"]
    assert L3.blended_degrees_of_freedom(s, 0.0, u) == L5.degrees_of_freedom(s, "Calm", u) == mc["df_calm"]
    assert L3.blended_degrees_of_freedom(s, 1.0, u) == L5.degrees_of_freedom(s, "Stressed", u) == mc["df_stressed"]
    assert L3.blended_degrees_of_freedom(s, 0.25, u) == pytest.approx(0.75 * mc["df_calm"] + 0.25 * mc["df_stressed"])


def _proposed_pipeline(monkeypatch):
    """Applies the pipeline.py edit proposed in EQ-B-0042 by proxy: layer 5 inputs from the stress weight."""
    state = {}

    def gr(regime, settings):
        state["w"] = L3.global_stress_weight(regime, settings)
        return L3.global_regime(regime, settings)
    p3 = types.SimpleNamespace(**{k: getattr(L3, k) for k in dir(L3) if not k.startswith("__")}); p3.global_regime = gr
    p5 = types.SimpleNamespace(**{k: getattr(L5, k) for k in dir(L5) if not k.startswith("__")})
    p5.degrees_of_freedom = lambda st, g, uu=None: L3.blended_degrees_of_freedom(st, state["w"], uu)
    p5.factor_loadings = lambda uu, st, r, g: L3.blended_factor_loadings(uu, st, r, state["w"])
    monkeypatch.setattr(PL, "L3", p3); monkeypatch.setattr(PL, "L5", p5)
    return state


def test_proposed_pipeline_edit_is_bit_identical_by_default_and_smooth_when_on(s, u, monkeypatch):
    kw = dict(paths=2000, as_of="2026-10-23")
    ref = run_pipeline(u, s, **kw)
    ref_st = run_pipeline(u, s.copy_with(**{"monte_carlo.global_stress_share": 0.4}), **kw)
    state = _proposed_pipeline(monkeypatch)
    new = run_pipeline(u, s, **kw)
    assert state["w"] == 0.0 and np.array_equal(ref.mc.losses, new.mc.losses)
    assert new.diagnostics["global_regime"] == ref.diagnostics["global_regime"] == "Calm"
    sm = run_pipeline(u, s.copy_with(**{"regime.global_switch": "logistic"}), **kw)
    assert 0 < state["w"] < 0.5 and ref.mc.metrics["df"] > sm.mc.metrics["df"] > ref_st.mc.metrics["df"]
    assert ref.mc.metrics["var99_mm"] < sm.mc.metrics["var99_mm"] < ref_st.mc.metrics["var99_mm"]
    assert sm.country["pd_default"].equals(ref.country["pd_default"])     # the switch never moves a PD
