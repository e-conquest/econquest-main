"""validation.backtests (EQ-B-0054, VF-006): the synthetic history is dated from the model as_of, not the clock."""
import numpy as np
import pandas as pd

from econquest.validation.backtests import synthetic_history


def test_synthetic_history_dates_end_at_as_of():
    losses = np.random.default_rng(0).normal(size=1000)
    a = synthetic_history(losses, 50.0, 60.0, as_of="2026-10-23")
    b = synthetic_history(losses, 50.0, 60.0, as_of="2026-10-23")
    pd.testing.assert_frame_equal(a, b)
    assert a["date"].iloc[-1] == pd.Timestamp("2026-10-01") and len(a) == 120
    assert synthetic_history(losses, 50.0, 60.0, as_of="2020-03-15")["date"].iloc[-1] == pd.Timestamp("2020-03-01")
    assert (a["loss"].to_numpy() == synthetic_history(losses, 50.0, 60.0)["loss"].to_numpy()).all()   # draws unchanged
