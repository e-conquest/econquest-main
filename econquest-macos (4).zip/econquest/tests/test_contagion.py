"""BIS common-creditor contagion shock in the scenario library (GOV-027, EQ-B-0037).

Exposures come from tests/fixtures/bis_cbs_synthetic.csv, a SYNTHETIC extract with made-up creditor
systems XA-XF; data/live/raw_bis.csv has no banking statistics yet (handoff to Team A)."""
import json
import shutil
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from econquest.config import Settings
from econquest.ingestion import load_universe
from econquest.engine import run_pipeline
from econquest.engine import stress as ST

DATA = ROOT / "data"
FIX = ROOT / "tests" / "fixtures" / "bis_cbs_synthetic.csv"


def _load():
    return load_universe(DATA), Settings.load(DATA / "assumptions.json")


@pytest.fixture
def live_dir(tmp_path):
    (tmp_path / "live").mkdir(); shutil.copy(FIX, tmp_path / "live" / "raw_bis_cbs.csv")
    return tmp_path


def test_common_lender_weights_by_hand():
    mat = pd.DataFrame({"AAA": [80.0, 20.0, 0.0], "BBB": [50.0, 50.0, 0.0], "CCC": [0.0, 0.0, 10.0]}, index=["K1", "K2", "K3"])
    w = ST.common_lender_weights(mat, "AAA", normalise="none")
    assert w["BBB"] == pytest.approx(0.8 * 0.5 + 0.2 * 0.5) and w["CCC"] == 0.0 and "AAA" not in w
    wm = ST.common_lender_weights(mat, "AAA")
    assert wm.max() == 1.0 and wm["BBB"] == 1.0
    with pytest.raises(ValueError):
        ST.common_lender_weights(mat, "DDD")
    with pytest.raises(ValueError):
        ST.common_lender_weights(mat, "AAA", normalise="sum")


def test_exposure_loader(tmp_path):
    u, _ = _load()
    mat = ST.load_bilateral_exposures(FIX, u.countries)
    assert mat.attrs["period"] == "2026-Q1" and mat.attrs["synthetic"]
    assert "5A" not in mat.index and set(mat.index) == {"XA", "XB", "XC", "XD", "XE", "XF"}
    assert set(mat.columns) == set(u.countries["iso"])                     # ISO2 debtors mapped to ISO3
    old = ST.load_bilateral_exposures(FIX, u.countries, period="2025-Q4")
    assert old.attrs["period"] == "2025-Q4" and not np.allclose(old.to_numpy(), mat.to_numpy())
    with pytest.raises(FileNotFoundError, match="consolidated banking"):
        ST.load_bilateral_exposures(tmp_path / "none.csv")
    norm = tmp_path / "norm.csv"
    pd.DataFrame({"creditor_iso2": ["XA", "XB", "XA"], "debtor_iso3": ["BRA", "BRA", "ARG"], "period": "2026-Q1", "claims_usd_mn": [3, 1, 2]}).to_csv(norm, index=False)
    m2 = ST.load_bilateral_exposures(norm)
    assert m2.at["XA", "BRA"] == 3 and m2.at["XB", "ARG"] == 0


def test_contagion_shock_scales_with_weights(live_dir):
    u, s = _load()
    sh = {"target": "contagion", "origin": "Brazil", "column": "spread", "op": "add", "value": 400, "exposures": "live/raw_bis_cbs.csv"}
    w = ST.contagion_weights(u.countries, sh, live_dir)
    u1, s1 = ST.apply_shocks(u, s, [sh], base_dir=live_dir)
    uh, _ = ST.apply_shocks(u, s, [sh], scale=0.5, base_dir=live_dir)
    c0 = u.countries.set_index("country")["spread"]; c1 = u1.countries.set_index("country")["spread"]; ch = uh.countries.set_index("country")["spread"]
    assert c1["Brazil"] == c0["Brazil"] and s1.raw == s.raw
    d = (c1 - c0).drop("Brazil")
    assert np.allclose(d, 400 * w.reindex(d.index)) and d.max() == pytest.approx(400)
    assert np.allclose((ch - c0).drop("Brazil"), d / 2)
    # where filter and mul op
    shm = dict(sh, op="mul", value=1.5, where={"region_in": ["LatAm"]})
    um, _ = ST.apply_shocks(u, s, [shm], base_dir=live_dir)
    cm = um.countries.set_index("country"); reg = u.countries.set_index("country")["region"]
    assert (cm.loc[reg != "LatAm", "spread"] == c0[reg != "LatAm"]).all()
    for n in ("Argentina", "Colombia"):
        assert cm.at[n, "spread"] == pytest.approx(c0[n] * (1 + 0.5 * w[n]))
    with pytest.raises(ValueError):
        ST.apply_shocks(u, s, [dict(sh, origin="Atlantis")], base_dir=live_dir)


def test_scenario_left_out_until_exposure_file_exists(tmp_path, live_dir):
    lib = tmp_path / "lib"; lib.mkdir(); shutil.copy(DATA / "scenarios.json", lib / "scenarios.json")
    scen = ST.load_scenarios(lib / "scenarios.json")
    assert "EMDEF_BRA" not in scen and "raw_bis_cbs.csv" in ST.UNAVAILABLE["EMDEF_BRA"]
    assert {"A", "B", "C"} <= set(scen)
    assert "EMDEF_BRA" in ST.load_scenarios(lib / "scenarios.json", include_unavailable=True)
    shutil.copy(DATA / "scenarios.json", live_dir / "scenarios.json")
    scen2 = ST.load_scenarios(live_dir / "scenarios.json")
    assert "EMDEF_BRA" in scen2 and not ST.UNAVAILABLE
    assert any("BIS common creditors of Brazil" in line for line in ST.summarise_shocks(scen2["EMDEF_BRA"].shocks))


def test_emdef_scenario_raises_tail_risk(live_dir):
    u, s = _load()
    shutil.copy(DATA / "scenarios.json", live_dir / "scenarios.json")
    sc = ST.load_scenarios(live_dir / "scenarios.json")["EMDEF_BRA"]
    u2, s2 = sc.apply(u, s)
    c = u2.countries.set_index("country")
    assert bool(c.at["Brazil", "default"]) and c.at["Brazil", "rating"] == "SD"
    assert u2.countries["fx3m"].sub(u.countries["fx3m"]).loc[u.countries["fxregime"].isin(["Peg"]).to_numpy()].eq(0).all()
    base = run_pipeline(u, s, paths=4000); r = run_pipeline(u2, s2, paths=4000)
    assert r.metrics["es99_mm"] > base.metrics["es99_mm"]
    assert r.country.at["Brazil", "pd_default"] > base.country.at["Brazil", "pd_default"]


def test_scenarios_json_is_valid_and_keys_unique():
    spec = json.loads((DATA / "scenarios.json").read_text())
    keys = [sc["key"] for sc in spec["scenarios"]]
    assert len(keys) == len(set(keys)) and "EMDEF_BRA" in keys


def test_exposures_path_confined_to_data_dir_and_header_not_echoed(tmp_path, live_dir):
    # EQ-B-0047 (AGENT-09 Low): scenarios.json may only name a file inside its own folder
    u, s = _load()
    sh = {"target": "contagion", "origin": "Brazil", "column": "spread", "op": "add", "value": 400}
    for bad in (str(FIX), "../outside.csv", "live/../../outside.csv"):
        with pytest.raises(ValueError, match="relative to the data folder|leaves the data folder"):
            ST.apply_shocks(u, s, [dict(sh, exposures=bad)], base_dir=live_dir)
    assert ST._exposure_path(dict(sh, exposures="live/raw_bis_cbs.csv"), live_dir) == (live_dir / "live" / "raw_bis_cbs.csv").resolve()
    secret = tmp_path / "live" / "secret.csv"
    secret.write_text("password_column,token_xyz\n1,2\n")
    with pytest.raises(ValueError) as err:
        ST.apply_shocks(u, s, [dict(sh, exposures="live/secret.csv")], base_dir=live_dir)
    assert "password_column" not in str(err.value) and "token_xyz" not in str(err.value) and "2 other columns" in str(err.value)

