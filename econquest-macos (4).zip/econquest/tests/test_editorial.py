"""Editorial states (EQ-C-0026): draft -> reviewed -> published, withdrawn and corrected; hash-chained ledger; four-eyes
review via ledger.person_key; read-only published copies with a manifest; verify_published detects tampering."""
import json
import os
import stat
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.presentation import editorial as E  # noqa: E402
from econquest.presentation.report import DISCLAIMER, caveats_html, caveats_md, input_caveats  # noqa: E402

META = {"run_id": "run-20261022-abc", "as_of": "2026-10-22", "data_hash": "d" * 12, "run_hash": "r" * 16}


@pytest.fixture
def out(tmp_path):
    o = tmp_path / "outputs"
    (o / "reports").mkdir(parents=True)
    (tmp_path / "data").mkdir()                  # sibling data/ (input caveats: empty, so only restriction 6.4 shows)
    yield o
    for root, _dirs, files in os.walk(o):        # let pytest clean up the 0555 / 0444 copies
        os.chmod(root, 0o755)
        for f in files:
            os.chmod(os.path.join(root, f), 0o644)


def product(out, name="risk-report-2026-10-22", body="VaR table"):
    h = out / "reports" / f"{name}.html"; m = out / "reports" / f"{name}.md"
    cav = input_caveats(out.parent / "data")
    h.write_text(f"<html><p>{body}</p><h2>Input caveats</h2>{caveats_html(cav)}<h2>Sources</h2><ul><li>IMF WEO</li>"
                 f"<li>seed estimates (data/indicators.csv)</li></ul><p>As of 2026-10-22.</p>"
                 f"<div class='disclaimer'>{DISCLAIMER}</div></html>", encoding="utf-8")
    m.write_text(f"# Report\n\n{body}\n\n## Input caveats\n\n" + "\n".join(caveats_md(cav))
                 + f"\n\n## Sources\n\n- IMF WEO\n- World Bank WDI\n\nAs of 2026-10-22.\n\n> **Disclaimer.** {DISCLAIMER}\n",
                 encoding="utf-8")
    return [h, m]


def complete(out, item, author="Alice", approver="Dave"):
    """Conflicts by the author, then the compliance sign-off (no restriction needs an acknowledgement with empty data/)."""
    E.checklist(out, item, author, conflicts="no conflicts")
    return E.checklist(out, item, approver, compliance_approve=True)


def published(out, item="daily_report"):
    it = E.register_draft(out, item, product(out), META, "Alice")
    E.review(out, it["item_id"], "Bob", "checked numbers")
    complete(out, it["item_id"])
    return E.publish(out, it["item_id"], "Carol")


def test_full_lifecycle(out):
    files = product(out)
    it = E.register_draft(out, "daily_report", files, META, " Alice ")
    assert it["state"] == "draft" and it["author"] == "Alice" and it["meta"] == META
    assert [f["sha256"] for f in it["files"]] == [E.sha256_file(f) for f in files]
    it = E.review(out, it["item_id"], "Bob", "ok")
    assert it["state"] == "reviewed" and it["reviewer"] == "Bob" and it["self_reviewed"] == ""
    complete(out, it["item_id"])
    it = E.publish(out, it["item_id"], "Carol")
    assert it["state"] == "published"
    d = out / it["published_dir"]
    assert d.parent == out / "published" / "daily_report" and d.name == f"2026-10-22-{it['item_id']}"
    assert stat.S_IMODE(d.stat().st_mode) == 0o555
    assert all(stat.S_IMODE(p.stat().st_mode) == 0o444 for p in d.iterdir())
    man = json.loads((d / "manifest.json").read_text())
    assert (man["author"], man["reviewer"], man["publisher"]) == ("Alice", "Bob", "Carol")
    assert man["run_id"] == META["run_id"] and man["run_hash"] == META["run_hash"] and man["disclaimer"] == DISCLAIMER
    assert all(f["disclaimer_present"] for f in man["files"])
    assert {f["name"]: f["sha256"] for f in man["files"]} == {f.name: E.sha256_file(f) for f in files}
    assert E.verify_published(out) == {"ok": True, "checked": 1, "problems": []}
    assert [i["item_id"] for i in E.list_items(out, state="published", kind="daily_report")] == [it["item_id"]]
    assert E.list_items(out, kind="weekly_monitor") == []
    w = E.withdraw(out, it["item_id"], "Bob", "wrong vintage")
    assert w["state"] == "withdrawn" and (d / "manifest.json").exists()       # never deleted
    reg = [json.loads(x) for x in E.withdrawn_path(out).read_text().splitlines()]
    assert reg[0]["item_id"] == it["item_id"] and reg[0]["reason"] == "wrong vintage"
    assert E.verify_published(out)["ok"]
    with pytest.raises(E.EditorialError, match="withdrawn"):
        E.withdraw(out, it["item_id"], "Bob", "again")


@pytest.mark.parametrize("reviewer", ["Alice", "alice", "  ALICE ", "Ali​ce", "Ａlice"])
def test_same_person_review_refused(out, reviewer):
    it = E.register_draft(out, "weekly_monitor", product(out), META, "Alice")
    with pytest.raises(E.EditorialError, match="reviewer other than the author"):
        E.review(out, it["item_id"], reviewer)
    assert E.get_item(out, it["item_id"])["state"] == "draft"


def test_self_review_flagged(out):
    it = E.register_draft(out, "daily_report", product(out), META, "Sam")
    it = E.review(out, it["item_id"], "sam ", "single operator", self_reviewed=True)
    assert it["reviewer"] == "Sam" and it["self_reviewed"] == "yes"
    complete(out, it["item_id"], "Sam", "Bob")
    man = json.loads((out / E.publish(out, it["item_id"], "Sam")["published_dir"] / "manifest.json").read_text())
    assert man["self_reviewed"] == "yes"


def test_edit_after_review_blocks_publish(out):
    files = product(out)
    it = E.register_draft(out, "daily_report", files, META, "Alice")
    E.review(out, it["item_id"], "Bob")
    files[0].write_text(files[0].read_text() + "<!-- edit -->")
    with pytest.raises(E.EditorialError, match="changed since review"):
        E.publish(out, it["item_id"], "Carol")
    assert not (out / "published" / "daily_report").exists() or not any((out / "published" / "daily_report").iterdir())


def test_edit_before_review_blocks_review(out):
    files = product(out)
    it = E.register_draft(out, "daily_report", files, META, "Alice")
    files[1].unlink()
    with pytest.raises(E.EditorialError, match="missing"):
        E.review(out, it["item_id"], "Bob")


def test_draft_must_be_reviewed_and_carry_disclaimer(out):
    it = E.register_draft(out, "country_note", product(out), META, "Alice")
    with pytest.raises(E.EditorialError, match="only a reviewed item"):
        E.publish(out, it["item_id"], "Carol")
    p = out / "reports" / "note.md"; p.write_text("no disclaimer here")
    it2 = E.register_draft(out, "country_note", [p], META, "Alice")
    E.review(out, it2["item_id"], "Bob")
    with pytest.raises(E.EditorialError, match="disclaimer"):
        E.publish(out, it2["item_id"], "Carol")
    with pytest.raises(E.EditorialError, match="kind"):
        E.register_draft(out, "blog_post", product(out), META, "Alice")
    with pytest.raises(E.EditorialError, match="run_id"):
        E.register_draft(out, "daily_report", product(out), {"as_of": "2026-10-22"}, "Alice")


def test_republish_refused(out):
    it = published(out)
    with pytest.raises(E.EditorialError, match="already published"):
        E.publish(out, it["item_id"], "Carol")
    assert E.verify_published(out)["checked"] == 1


def test_tamper_of_published_file_detected(out):
    it = published(out)
    d = out / it["published_dir"]
    os.chmod(d, 0o755); f = d / "risk-report-2026-10-22.html"; os.chmod(f, 0o644)
    f.write_text(f.read_text().replace("VaR table", "VaR table (edited)"))
    os.chmod(f, 0o444); os.chmod(d, 0o555)
    res = E.verify_published(out)
    assert not res["ok"] and any("tampered" in p for p in res["problems"])


def test_extra_file_and_orphan_dir_detected(out):
    it = published(out)
    d = out / it["published_dir"]
    os.chmod(d, 0o755); (d / "extra.txt").write_text("x"); os.chmod(d, 0o555)
    (out / "published" / "daily_report" / "2026-10-22-ed-forged").mkdir()
    probs = E.verify_published(out)["problems"]
    assert any("unexpected file extra.txt" in p for p in probs) and any("no publish row" in p for p in probs)


def test_chain_tamper_detected(out):
    it = published(out)
    lp = E.ledger_path(out)
    rows = [json.loads(x) for x in lp.read_text().splitlines()]
    rows[1]["reviewer"] = "Mallory"                     # rewrite who reviewed, keep the old row_hash
    lp.write_text("".join(json.dumps(r) + "\n" for r in rows))
    res = E.verify_published(out)
    assert not res["ok"] and any("row_hash" in p for p in res["problems"])
    rows[1]["row_hash"] = E._row_hash(rows[1])           # recompute it: the next row's prev_hash then breaks
    lp.write_text("".join(json.dumps(r) + "\n" for r in rows))
    assert any("prev_hash" in p for p in E.verify_chain(out))
    with pytest.raises(E.EditorialError, match="chain is broken"):
        E.register_draft(out, "daily_report", product(out, "x"), META, "Alice")
    del rows[1]                                          # deleting a row is caught too
    for i, r in enumerate(rows, 1):
        r["seq"] = i
    lp.write_text("".join(json.dumps(r) + "\n" for r in rows))
    assert E.verify_chain(out)
    assert it["item_id"]


def test_correction_link(out):
    orig = published(out)
    with pytest.raises(E.EditorialError, match="only a published item"):
        E.correct(out, E.register_draft(out, "daily_report", product(out, "d2"), META, "Alice")["item_id"],
                  product(out, "d3"), "Alice", "typo")
    new = E.correct(out, orig["item_id"], product(out, "risk-report-2026-10-22-v2", "VaR table fixed"), "Alice", "ES99 typo")
    assert new["state"] == "draft" and new["correction_of"] == orig["item_id"] and new["kind"] == "daily_report"
    assert new["meta"] == META and new["item_id"] != orig["item_id"]
    assert E.get_item(out, orig["item_id"])["corrected_by"] == new["item_id"]
    assert E.get_item(out, orig["item_id"])["state"] == "published"
    E.review(out, new["item_id"], "Bob"); complete(out, new["item_id"]); pub = E.publish(out, new["item_id"], "Carol")
    assert E.get_item(out, orig["item_id"])["state"] == "corrected"
    man = json.loads((out / pub["published_dir"] / "manifest.json").read_text())
    assert man["correction_of"] == orig["item_id"] and man["correction_reason"] == "ES99 typo"
    assert (out / orig["published_dir"] / "manifest.json").exists()
    assert E.verify_published(out) == {"ok": True, "checked": 2, "problems": []}
    with pytest.raises(E.EditorialError, match="reason"):
        E.correct(out, orig["item_id"], product(out, "v3"), "Alice", " ")


def test_withdrawn_registry_mismatch_detected(out):
    it = published(out)
    E.withdraw(out, it["item_id"], "Bob", "bad input")
    E.withdrawn_path(out).write_text("")
    assert any("missing from WITHDRAWN" in p for p in E.verify_published(out)["problems"])


def test_helpers_from_generator_result():
    res = {"html": "/o/reports/risk-report-2026-10-22.html", "md": "/o/reports/risk-report-2026-10-22.md",
           "latest": "/o/reports/latest.html", "run_id": "r1", "as_of": "2026-10-22"}
    assert E.files_from_result(res) == [res["html"], res["md"]]
    assert E.files_from_result({"paths": {"html": "/a/n.html", "latest": "/a/latest-note.html"}}) == ["/a/n.html"]
    run = {"summary": {"run_id": "r1", "versions": {"data_hash": "dh", "run_hash": "rh", "as_of": "2026-10-22"}}}
    assert E.meta_from_result(res, run) == {"run_id": "r1", "as_of": "2026-10-22", "data_hash": "dh", "run_hash": "rh"}


def test_draft_refuses_files_outside_outputs(out, tmp_path):
    # regression (AGENT-09 review of EQ-C-0026, SEC-C-003): a draft could pull in any file (e.g. ~/.ssh/id_rsa) next to
    # a report carrying the disclaimer, and publish a read-only copy of it under outputs/published/
    secret = tmp_path / "id_rsa"; secret.write_text("-----BEGIN OPENSSH PRIVATE KEY-----\n")
    with pytest.raises(E.EditorialError, match="only files under"):
        E.register_draft(out, "daily_report", product(out) + [secret], META, "Alice")
    link = out / "reports" / "innocent.txt"; link.symlink_to(secret)
    with pytest.raises(E.EditorialError, match="only files under"):
        E.register_draft(out, "daily_report", product(out) + [link], META, "Alice")
    (out / "reports" / "manifest.json").write_text("{}")
    with pytest.raises(E.EditorialError, match="reserved"):
        E.register_draft(out, "daily_report", product(out) + [out / "reports" / "manifest.json"], META, "Alice")
    pub = published(out)
    copy = out / pub["published_dir"] / "risk-report-2026-10-22.html"
    with pytest.raises(E.EditorialError, match="only files under"):
        E.register_draft(out, "daily_report", [copy], META, "Alice")
