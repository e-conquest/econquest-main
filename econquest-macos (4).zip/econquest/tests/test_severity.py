"""Layer 4 severity: GPD mean preservation, Merton LGD uplift reaching the simulation, sector/location multipliers, scenario B LGD."""
import sys
from pathlib import Path
import numpy as np
import pytest
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.config import Settings
from econquest.ingestion import load_universe
from econquest.engine import run_pipeline
from econquest.engine.layer4_severity import gpd_severity, gpd_clipped_mean, gpd_scale, haircut_distribution, expected_lgd, LGD_BOUNDS
from econquest.engine.stress import SCENARIOS

DATA = ROOT / "data"


@pytest.mark.parametrize("target", [0.25, 0.5, 0.7, 0.9])
@pytest.mark.parametrize("xi", [0.1, 0.25, 0.5])
def test_gpd_clipped_mean_hits_target(target, xi):
    s = Settings({"layer4": {"gpd_xi": xi}})
    u = np.random.default_rng(11).random(200_000)
    y = gpd_severity(target, u, s)
    assert y.min() >= 0 and y.max() <= 1
    assert abs(y.mean() - target) < 0.01, (target, xi, y.mean())
    assert abs(gpd_clipped_mean(gpd_scale(target, xi), xi) - target) < 1e-9


def test_lgd_uplift_bounded_and_in_beta_mean():
    assert expected_lgd(0.6, 1.25, 0.73) == LGD_BOUNDS[1]
    assert expected_lgd(0.02, 1.0, 0.0) == LGD_BOUNDS[0]
    s = Settings({"layer4": {"lgd_sd": 0.15}})
    a0, b0 = haircut_distribution(0.6, 1.0925, s)
    a1, b1 = haircut_distribution(0.6, 1.0925, s, 0.3)
    assert abs(a0 / (a0 + b0) - 0.6 * 1.0925) < 1e-9
    assert abs(a1 / (a1 + b1) - expected_lgd(0.6, 1.0925, 0.3)) < 1e-9


def test_merton_uplift_reaches_simulation():
    u = load_universe(DATA); s = Settings.load(DATA / "assumptions.json")
    assert s["layer4"]["merton"]["apply_uplift"] is True
    on = run_pipeline(u, s, paths=4000)
    off = run_pipeline(u, s.copy_with(**{"layer4.merton.apply_uplift": False}), paths=4000)
    hard = on.positions["asset_class"].isin(["Eurobond", "CDS protection"])
    assert (on.positions.loc[hard, "lgd_uplift"] == on.country.loc[on.positions.loc[hard, "country"], "lgd_uplift"].to_numpy()).all()
    assert (on.positions.loc[~hard, "lgd_uplift"] == 0).all()
    assert (off.positions["lgd_uplift"] == 0).all()
    assert on.positions.loc[hard, "lgd_uplift"].gt(0).any()
    assert (on.country["lgd_hard_expected"] >= off.country["lgd_hard_expected"] - 1e-12).all()
    assert on.country["lgd_hard_expected"].between(*LGD_BOUNDS).all()
    # Eurobonds of sovereigns with a positive uplift lose more on the same paths; the CDS hedge gains more
    el_on = on.mc.contributions["expected_loss_mm"]; el_off = off.mc.contributions["expected_loss_mm"]
    lifted = on.positions.index[hard & (on.positions["lgd_uplift"] > 0)]
    for pid in lifted:
        if on.positions.at[pid, "asset_class"] == "Eurobond":
            assert el_on[pid] > el_off[pid], pid
        else:
            assert el_on[pid] < el_off[pid], pid
    assert on.metrics["es99_mm"] > off.metrics["es99_mm"]


def test_sector_and_location_multipliers_change_equity_perils():
    u = load_universe(DATA); s = Settings.load(DATA / "assumptions.json")
    base = run_pipeline(u, s, paths=4000)
    u2 = load_universe(DATA)
    eq = u2.portfolio["asset_class"] == "Equity"
    u2.portfolio.loc[eq, "sector"] = "Mining, oil and gas"; u2.portfolio.loc[eq, "location"] = "Active warzone"
    r2 = run_pipeline(u2, s, paths=4000)
    for pid in base.positions.index[base.positions["asset_class"] == "Equity"]:
        c = base.positions.at[pid, "country"]
        assert abs(r2.positions.at[pid, "pd_ex"] - min(0.99, base.country.at[c, "pd_ex"] * 1.5)) < 1e-12
        assert abs(r2.positions.at[pid, "pd_pv"] - min(0.99, base.country.at[c, "pd_pv"] * 2.0)) < 1e-12
        assert r2.positions.at[pid, "thrA"] > base.positions.at[pid, "thrA"] and r2.positions.at[pid, "thrB"] > base.positions.at[pid, "thrB"]
        # >= per position: a loss is capped at the notional, so on a path where the market move already takes the
        # whole notional (GARCH vols, EQ-B-0035) a new jump adds nothing; the book of equity perils must still lose more
        assert r2.mc.contributions.at[pid, "expected_loss_mm"] >= base.mc.contributions.at[pid, "expected_loss_mm"]
    eq_ids = base.positions.index[base.positions["asset_class"] == "Equity"]
    assert r2.mc.contributions.loc[eq_ids, "expected_loss_mm"].sum() > base.mc.contributions.loc[eq_ids, "expected_loss_mm"].sum()
    non_eq = base.positions.index[base.positions["asset_class"] != "Equity"]
    assert np.allclose(r2.mc.position_losses[:, base.positions.index.get_indexer(non_eq)], base.mc.position_losses[:, base.positions.index.get_indexer(non_eq)])


def test_sample_book_has_sector_and_location_for_equities():
    u = load_universe(DATA)
    eq = u.portfolio[u.portfolio["asset_class"] == "Equity"]
    assert eq["sector"].notna().all() and eq["location"].notna().all()
    s = Settings.load(DATA / "assumptions.json")
    assert set(eq["sector"]) <= set(s["sector_multipliers"]) and set(eq["location"]) <= set(s["location_multipliers"])


def test_scenario_b_adds_18pp_to_lgd():
    u = load_universe(DATA); s = Settings.load(DATA / "assumptions.json")
    _, s2 = SCENARIOS["B"].apply(u, s)
    assert s2["market"]["lgd_hard"] == min(95.0, s["market"]["lgd_hard"] + 18.0)
    assert s2["layer4"]["merton"]["apply_uplift"] is True
    _, s3 = SCENARIOS["B"].apply(u, s.copy_with(**{"market.lgd_hard": 90.0}))
    assert s3["market"]["lgd_hard"] == 95.0
