"""EQ-A-0040: official FX feeds replace Yahoo for desk numbers (Sam 2026-10-23, "Replace with free official").

Everything here is offline and every number is SYNTHETIC: the BIS WS_XRU and ECB EXR responses are fixtures written
by hand, not recorded from stats.bis.org or data-api.ecb.europa.eu (this cloud cannot reach either). The series keys
they use are the ones feeds.py marks UNVERIFIED; these tests prove the parsing, the fx3m definition, the sharing of
one series by several countries and the fail-fast behaviour, not that the keys are the ones BIS and the ECB publish.
"""
import datetime as dt
import sys
import urllib.error
import urllib.parse
import urllib.request
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(Path(__file__).resolve().parent))
from econquest.ingestion import feeds  # noqa: E402
from econquest.ingestion.feeds import (EXR_FLOW, EXR_KEY, NO_FX_QUOTE, NO_OFFICIAL_SOURCE, XRU_FLOW,  # noqa: E402
                                       BisFeed, EcbExrFeed, FeedError, FeedUnreachable, YAHOO_REFUSED, ecb_per_usd,
                                       fetch_all, fx3m, fx_usd_series, official_fx_plan, official_fx_transforms,
                                       yahoo_transforms, _long)
from econquest.ingestion.loaders import load_universe  # noqa: E402

DATA = ROOT / "data"
DAYS = pd.bdate_range("2025-11-03", "2026-10-22")       # ~255 business days: enough for fx3m (> 70, 91 days back)
JUMP = pd.Timestamp("2026-08-01")                       # +10% from here (after last day minus 91 days): fx3m = 10.0


def _path_values(base: float) -> list[float]:
    """SYNTHETIC price path: `base`, stepping up 10% at JUMP so fx3m is exactly 10%."""
    return [base * (1.1 if d >= JUMP else 1.0) for d in DAYS]


def xru_csv(pairs, dims_collection="A") -> str:
    """SYNTHETIC BIS WS_XRU SDMX-CSV for (reference area, currency) pairs, units of the currency per USD."""
    rows = []
    for k, (area, ccy) in enumerate(pairs):
        for d, v in zip(DAYS, _path_values(1.0 + k)):
            rows.append({"FREQ": "D", "REF_AREA": area, "CURRENCY": ccy, "COLLECTION": dims_collection,
                         "TIME_PERIOD": d.strftime("%Y-%m-%d"), "OBS_VALUE": v})
    return pd.DataFrame(rows).to_csv(index=False)


def exr_csv(per_eur: dict, days=None, usd_per_eur: float = 1.25) -> str:
    """SYNTHETIC ECB EXR SDMX-CSV: D.<CCY>.EUR.SP00.A, units of the currency per euro, plus the USD leg."""
    days = DAYS if days is None else days
    rows = []
    for ccy, base in {**per_eur, "USD": usd_per_eur}.items():
        for d, v in zip(days, _path_values(base) if ccy != "USD" else [base] * len(days)):
            rows.append({"KEY": f"EXR.D.{ccy}.EUR.SP00.A", "TIME_PERIOD": d.strftime("%Y-%m-%d"), "OBS_VALUE": v})
    return pd.DataFrame(rows).to_csv(index=False)


def bis_urlopen(answers: dict, calls: list | None = None):
    """urlopen stand-in for stats.bis.org: `answers` maps a flow to CSV text, or to an exception to raise."""
    import io

    def urlopen(req, timeout=None):
        url = req.full_url if hasattr(req, "full_url") else str(req)
        assert url.startswith("https://stats.bis.org/")
        parts = urllib.parse.urlsplit(url).path.split("/")
        flow, key = parts[-3], parts[-2]
        if calls is not None:
            calls.append((flow, key, urllib.parse.urlsplit(url).query))
        got = answers.get(flow)
        if isinstance(got, BaseException):
            raise got
        if got is None:
            raise urllib.error.HTTPError(url, 404, "NoResultsFound", {}, None)
        return io.BytesIO(got.encode())

    return urlopen


# ---------------------------------------------------------------------------------------------- BIS WS_XRU parsing
def test_bis_xru_parses_batches_and_keeps_only_requested_pairs(monkeypatch):
    calls = []
    answer = xru_csv([("BR", "BRL"), ("CL", "CLP"), ("BR", "CLP")])      # the third pair was never asked for
    monkeypatch.setattr("econquest.ingestion.sources.open_url_no_redirect", bis_urlopen({XRU_FLOW: answer}, calls))
    out = BisFeed(sleep=lambda s: None).fetch_xru({"BRL": "BR", "CLP": "CL"}, today=dt.date(2026, 10, 23))
    assert len(calls) == 1
    flow, key, query = calls[0]
    assert flow == XRU_FLOW and key == "D.BR+CL.BRL+CLP.A" and "startPeriod=2025-09-18" in query
    assert list(out.columns) == [*feeds.LONG_COLUMNS, "sdmx_key"]
    assert set(out["series"]) == {"BRL_PER_USD", "CLP_PER_USD"}          # the BR/CLP cross product is dropped
    assert set(out["iso"]) == {"BR", "CL"} and out["source"].str.contains("WS_XRU").all()
    assert out.loc[out["series"] == "BRL_PER_USD", "sdmx_key"].iloc[0] == "WS_XRU D.BR.BRL.A"
    assert out.attrs["missing"] == []


def test_bis_xru_reports_a_currency_it_does_not_serve(monkeypatch):
    monkeypatch.setattr("econquest.ingestion.sources.open_url_no_redirect", bis_urlopen({XRU_FLOW: xru_csv([("BR", "BRL")])}))
    out = BisFeed(sleep=lambda s: None, batch=5).fetch_xru({"BRL": "BR", "XOF": "SN"}, today=dt.date(2026, 10, 23))
    assert out.attrs["missing"] == ["XOF"] and any("XOF" in f for f in out.attrs["failures"])
    assert fx_usd_series(out, "XOF").empty           # no rate is invented for it


def test_bis_xru_empty_answer_is_a_loud_failure(monkeypatch):
    monkeypatch.setattr("econquest.ingestion.sources.open_url_no_redirect", bis_urlopen({}))
    with pytest.raises(FeedError, match="returned no exchange rate"):
        BisFeed(sleep=lambda s: None).fetch_xru({"BRL": "BR"}, today=dt.date(2026, 10, 23))


# ---------------------------------------------------------------------------------------------- ECB EXR parsing
def test_ecb_exr_parses_and_always_asks_for_usd(monkeypatch):
    calls = []

    def get(self, key, params=None):
        calls.append((key, params))
        return exr_csv({"BRL": 6.0})

    monkeypatch.setattr(EcbExrFeed, "_get", get)
    out = EcbExrFeed().fetch(["BRL", "EUR"], today=dt.date(2026, 10, 23))
    assert calls[0][0] == EXR_KEY.format(ccy="BRL+USD") and calls[0][1]["startPeriod"] == "2025-09-18"
    assert set(out["series"]) == {"BRL_PER_EUR", "USD_PER_EUR"} and (out["iso"] == "").all()
    assert out["sdmx_key"].str.startswith(EXR_FLOW).all()


def test_ecb_exr_refuses_a_series_key_that_is_not_the_reference_rate(monkeypatch):
    bad = pd.DataFrame({"KEY": ["EXR.M.BRL.EUR.SP00.A"], "TIME_PERIOD": ["2026-10-22"], "OBS_VALUE": [6.0]}).to_csv(index=False)
    monkeypatch.setattr(EcbExrFeed, "_get", lambda self, key, params=None: bad)
    with pytest.raises(FeedError, match="returned no reference rate"):
        EcbExrFeed().fetch(["BRL"], today=dt.date(2026, 10, 23))


def test_ecb_per_usd_crosses_through_the_same_days_eur_usd():
    raw = pd.DataFrame({"iso": "", "series": ["BRL_PER_EUR", "USD_PER_EUR", "BRL_PER_EUR"],
                        "period": ["2026-10-22", "2026-10-22", "2026-10-21"], "value": [6.0, 1.25, 5.0],
                        "source": "test", "sdmx_key": "x"})
    out = ecb_per_usd(raw)
    got = {(r.series, r.period): r.value for r in out.itertuples(index=False)}
    assert got[("BRL_PER_USD", "2026-10-22")] == pytest.approx(6.0 / 1.25)
    assert got[("EUR_PER_USD", "2026-10-22")] == pytest.approx(1 / 1.25)
    # 2026-10-21 has no EUR/USD rate: no row is produced, and no rate is carried over from another date
    assert ("BRL_PER_USD", "2026-10-21") not in got


# ---------------------------------------------------------------------------------------------- fx3m definition
def test_fx3m_matches_the_yahoo_era_definition_on_a_synthetic_series():
    """The definition and sign convention are unchanged (EQ-A-0027 -> EQ-A-0040): the same daily path gives the same
    number whether it arrives as a Yahoo FX_USD table or as an official '<CCY>_PER_USD' table."""
    values = _path_values(5.0)
    yahoo_long = _long([{"iso": "BRA", "series": "FX_USD", "period": d.strftime("%Y-%m-%d"), "value": v}
                        for d, v in zip(DAYS, values)], "yfinance (Yahoo Finance)")
    official = _long([{"iso": "BR", "series": "BRL_PER_USD", "period": d.strftime("%Y-%m-%d"), "value": v}
                      for d, v in zip(DAYS, values)], "BIS")
    y = yahoo_transforms(yahoo_long, "BRA")["fx3m"]
    o = fx3m(fx_usd_series(official, "BRL"))
    assert y == pytest.approx(o) and o == pytest.approx(10.0)        # positive = local currency weaker


def test_fx3m_is_nan_on_a_short_series_rather_than_a_guess():
    short = pd.Series(_path_values(5.0)[:40], index=[d.strftime("%Y-%m-%d") for d in DAYS[:40]])
    assert np.isnan(fx3m(short)) and np.isnan(fx3m(pd.Series(dtype=float)))


# ---------------------------------------------------------------------------------------------- the plan
def test_shared_currencies_get_the_shared_series_and_dollarised_countries_a_reason():
    cty = pd.DataFrame([{"iso": "DEU", "iso2": "DE", "currency": "EUR"}, {"iso": "FRA", "iso2": "FR", "currency": "EUR"},
                        {"iso": "SEN", "iso2": "SN", "currency": "XOF"}, {"iso": "BEN", "iso2": "BJ", "currency": "XOF"},
                        {"iso": "CMR", "iso2": "CM", "currency": "XAF"}, {"iso": "BRA", "iso2": "BR", "currency": "BRL"},
                        {"iso": "PAN", "iso2": "PA", "currency": "USD"}, {"iso": "ZWE", "iso2": "ZW", "currency": "ZWL"}])
    plan = official_fx_plan(cty)
    assert plan.currency == {"DEU": "EUR", "FRA": "EUR", "SEN": "XOF", "BEN": "XOF", "CMR": "XAF", "BRA": "BRL"}
    assert plan.bis_area == {"EUR": feeds.EURO_AREA_BIS, "XOF": "SN", "XAF": "CM", "BRL": "BR"}
    assert plan.ecb == ("EUR", "XOF", "XAF", "BRL")                  # every currency is cross-checked at the ECB
    assert plan.why["PAN"] == NO_FX_QUOTE["USD"] and "ZiG" in plan.why["ZWE"]
    assert set(plan.currency) | set(plan.why) == set(cty["iso"])

    raw = {"bis_xru": _long([{"iso": "SN", "series": "XOF_PER_USD", "period": d.strftime("%Y-%m-%d"), "value": v}
                             for d, v in zip(DAYS, _path_values(600.0))], "BIS")}
    a, src_a, key_a = official_fx_transforms(raw, "SEN", plan)
    b, src_b, key_b = official_fx_transforms(raw, "BEN", plan)
    assert a == b and a["fx3m"] == pytest.approx(10.0) and key_a == key_b == f"{XRU_FLOW} D.SN.XOF.A"
    assert "WS_XRU" in src_a
    assert official_fx_transforms(raw, "PAN", plan) == ({}, "", "")   # dollarised: nothing, never another country's


def test_ecb_serves_a_currency_bis_has_no_series_for():
    plan = official_fx_plan(pd.DataFrame([{"iso": "BRA", "iso2": "BR", "currency": "BRL"}]))
    raw = {"bis_xru": _long([{"iso": "CL", "series": "CLP_PER_USD", "period": "2026-10-22", "value": 900.0}], "BIS"),
           "ecb_exr": pd.read_csv(__import__("io").StringIO(
               pd.DataFrame([{"iso": "", "series": s, "period": d.strftime("%Y-%m-%d"), "value": v, "source": "ECB",
                              "sdmx_key": "x"}
                             for s, vals in (("BRL_PER_EUR", _path_values(6.0)), ("USD_PER_EUR", [1.25] * len(DAYS)))
                             for d, v in zip(DAYS, vals)]).to_csv(index=False)))}
    vals, src, key = official_fx_transforms(raw, "BRA", plan)
    assert vals["fx3m"] == pytest.approx(10.0) and EXR_FLOW in key and "EUR/USD" in src


# ---------------------------------------------------------------------------------------------- fetch_all
def _universe():
    return load_universe(DATA)


def test_yahoo_is_not_called_by_default(monkeypatch):
    """No feed in the default plan touches yfinance or a Yahoo host, and naming it is refused before any request."""
    def boom(*a, **k):
        raise AssertionError("yfinance was imported although Yahoo is not a desk feed")
    monkeypatch.setitem(sys.modules, "yfinance", property(boom))
    monkeypatch.setattr(feeds.YahooFeed, "fetch", boom)
    monkeypatch.setattr(feeds.WeoFeed, "cache_file", lambda self: Path("/nonexistent/weo_cache.csv"))
    probed = []
    rep = fetch_all(_universe(), year=2026, log=lambda m: None,
                    probe=lambda h: (probed.append(h), "proxy refused CONNECT to " + h)[1])
    assert "yahoo" not in rep.feeds and "yahoo" not in rep.raw
    assert not any("yahoo" in h for h in probed)
    assert {"bis_xru", "ecb_exr"} <= set(rep.feeds)
    with pytest.raises(ValueError, match="not a desk feed"):
        fetch_all(_universe(), only=["yahoo"], year=2026, log=lambda m: None, probe=lambda h: None)
    assert YAHOO_REFUSED.startswith("Yahoo Finance is not a desk feed")


def test_fetch_all_fills_fx3m_from_bis_and_holds_a_disagreement_with_the_ecb(monkeypatch, tmp_path):
    u = _universe()
    plan = official_fx_plan(u.countries)
    pairs = [(plan.bis_area[c], c) for c in sorted(plan.bis_area)]
    monkeypatch.setattr("econquest.ingestion.sources.open_url_no_redirect", bis_urlopen({XRU_FLOW: xru_csv(pairs)}))
    # the ECB agrees with BIS on every currency except the one we move by 5%
    bis = {c: v for (_, c), v in zip(pairs, [1.0 + k for k in range(len(pairs))])}
    per_eur = {c: v * 1.25 * (1.05 if c == "BRL" else 1.0) for c, v in bis.items() if c != "EUR"}
    monkeypatch.setattr(EcbExrFeed, "_get", lambda self, key, params=None: exr_csv(per_eur))
    rep = fetch_all(u, only=["fx"], year=2026, log=lambda m: None, probe=lambda h: None)
    assert rep.feeds["bis_xru"].startswith("ok") and rep.feeds["ecb_exr"].startswith("ok")
    assert rep.profile.loc["Brazil", "fx3m"] == pytest.approx(10.0)
    prov = rep.provenance.set_index(["key", "country"])
    assert XRU_FLOW in prov.at[("fx3m", "Brazil"), "source"]
    assert prov.at[("fx3m", "Brazil"), "series"] == f"{XRU_FLOW} D.BR.BRL.A"
    diff = feeds.diff_against_seed(u, rep)
    review = feeds.quality_gate(u, rep, diff, year=2026)
    bra = review[(review["key"] == "fx3m") & (review["country"] == "Brazil")].iloc[0]
    assert bra["status"] == "hold" and "fx cross" in bra["reason"] and "BIS" in bra["reason"]
    vnm = review[(review["key"] == "fx3m") & (review["country"] == "Vietnam")].iloc[0]
    assert "fx cross" not in vnm["reason"]
    # equity_vol: no official free source, reported as missing with the reason, never filled
    ev = review[review["key"] == "equity_vol"]
    assert len(ev) == len(u.names) and (ev["status"] == "missing").all()
    assert ev["reason"].str.contains(NO_OFFICIAL_SOURCE, regex=False).all()
    live = feeds.save_report(rep, tmp_path, diff)
    assert (live / "raw_bis_xru.csv").exists() and (live / "raw_ecb_exr.csv").exists()
    assert not (live / "raw_yahoo.csv").exists()


def test_fx_feeds_fail_fast_when_the_host_is_down(monkeypatch):
    """A proxy refusal ends each FX feed at the first request (EQ-A-0037), and nothing falls back to Yahoo."""
    refused = urllib.error.URLError(OSError("Tunnel connection failed: 403 Forbidden"))
    monkeypatch.setattr("econquest.ingestion.sources.open_url_no_redirect", bis_urlopen({XRU_FLOW: refused}))
    with pytest.raises(FeedUnreachable, match="proxy refused CONNECT to stats.bis.org"):
        BisFeed(sleep=lambda s: None).fetch_xru({"BRL": "BR"}, today=dt.date(2026, 10, 23))

    def get(self, key, params=None):
        raise urllib.error.URLError(OSError("Tunnel connection failed: 403 Forbidden"))

    monkeypatch.setattr(EcbExrFeed, "_get", get)
    with pytest.raises(FeedUnreachable, match="proxy refused CONNECT to data-api.ecb.europa.eu"):
        EcbExrFeed(sleep=lambda s: None).fetch(["BRL"], today=dt.date(2026, 10, 23))

    monkeypatch.setattr(feeds.WeoFeed, "cache_file", lambda self: Path("/nonexistent/weo_cache.csv"))
    rep = fetch_all(_universe(), only=["fx"], year=2026, log=lambda m: None,
                    probe=lambda h: f"proxy refused CONNECT to {h}")
    assert all(v.startswith("unreachable") or v == "skipped" for v in rep.feeds.values())
    assert rep.raw == {} and rep.profile["fx3m"].isna().all()


def test_audit_trail_names_the_official_source(tmp_path):
    """EQ-A-0040: the audit trail shows where fx3m came from, and says equity_vol has no source."""
    import shutil

    from econquest.ingestion.audit import SERIES, TRANSFORMS, build_audit_trail
    assert "WS_XRU" in SERIES["fx3m"] and EXR_KEY.format(ccy="<CCY>") in SERIES["fx3m"]
    assert SERIES["equity_vol"] == f"none: {NO_OFFICIAL_SOURCE}"
    assert "91 days" in TRANSFORMS["fx3m"]

    d = tmp_path / "data"
    shutil.copytree(DATA, d, ignore=shutil.ignore_patterns("panel", "*.lock", "vintages"))
    live = d / "live"
    pd.DataFrame([{"table": "Country Profile", "key": "fx3m", "country": "Brazil", "value": 10.0,
                   "source": "BIS SDMX REST WS_XRU (stats.bis.org)", "series": "WS_XRU D.BR.BRL.A",
                   "retrieved": "2026-10-24"}]).to_csv(live / "provenance.csv", index=False)
    pd.DataFrame([{"table": "Country Profile", "key": "equity_vol", "country": "Brazil", "seed": np.nan,
                   "live": np.nan, "status": "missing", "reason": f"none: not served - {NO_OFFICIAL_SOURCE}"}]
                 ).to_csv(live / "review.csv", index=False)
    trail = build_audit_trail(d).set_index(["key", "country"])
    assert "WS_XRU" in trail.at[("fx3m", "Brazil"), "source"]
    assert "ahoo" not in str(trail.at[("fx3m", "Brazil"), "source"])
    # equity_vol has no countries.csv cell (it never had one), so it has no audit row: it is reported as a
    # 'missing' gate row with the reason instead, and no cell is invented for it here either
    assert "equity_vol" not in set(trail.index.get_level_values("key"))


# ---------------------------------------------------------------------------------------------- SEC-A-006 L1
class _StubHttps:
    """An https handler for urllib's real opener chain that answers every request with `code`, a Location header
    and `body`, so the real redirect handling and byte cap in sources.https_get run without a network."""
    handler_order = 100                                  # before urllib's own HTTPSHandler

    def __init__(self, code=200, location="", body=b""):
        self.code, self.location, self.body, self.urls = code, location, body, []

    def add_parent(self, parent):
        self.parent = parent

    def close(self):
        pass

    def __lt__(self, other):
        return self.handler_order < getattr(other, "handler_order", 500)

    def https_open(self, req):
        import email.message
        import io
        import urllib.response
        self.urls.append(req.full_url)
        h = email.message.Message()
        if self.location:
            h["Location"] = self.location
        r = urllib.response.addinfourl(io.BytesIO(self.body), h, req.full_url, self.code)
        r.msg = "stub"
        return r

    def http_open(self, req):                            # a followed redirect to http would land here
        self.urls.append(req.full_url)
        raise AssertionError(f"redirect followed to {req.full_url}")


def _stub_opener(monkeypatch, stub):
    from econquest.ingestion import sources
    real = urllib.request.build_opener
    monkeypatch.setattr(sources.urllib.request, "build_opener", lambda *h: real(*h, stub))


@pytest.mark.parametrize("code", [301, 302, 303, 307, 308])
def test_bis_refuses_redirect_to_http_and_stops(monkeypatch, code):
    stub = _StubHttps(code, "http://evil.example/rates.csv")
    _stub_opener(monkeypatch, stub)
    with pytest.raises(FeedUnreachable, match=f"HTTP {code} redirect from stats.bis.org.*not followed"):
        BisFeed(sleep=lambda s: pytest.fail("a redirect is not retried")).fetch_xru(
            {"BRL": "BR", "CLP": "CL"}, today=dt.date(2026, 10, 23))
    assert len(stub.urls) == 1 and all(u.startswith("https://stats.bis.org/") for u in stub.urls)


def test_ecb_refuses_redirect_and_stops(monkeypatch):
    stub = _StubHttps(302, "http://data-api.ecb.europa.eu/x")
    _stub_opener(monkeypatch, stub)
    with pytest.raises(FeedUnreachable, match="redirect from data-api.ecb.europa.eu.*not followed") as e:
        EcbExrFeed(sleep=lambda s: pytest.fail("a redirect is not retried")).fetch(["BRL"], today=dt.date(2026, 10, 23))
    assert len(stub.urls) == 1 and "?" not in str(e.value) and "startPeriod" not in str(e.value)   # no query string


def test_bis_and_ecb_cap_the_body(monkeypatch):
    from econquest.ingestion.sources import ResponseTooLarge
    stub = _StubHttps(200, body=b"x" * 2048)
    _stub_opener(monkeypatch, stub)
    with pytest.raises(ResponseTooLarge, match="exceeds the 1024-byte cap"):
        BisFeed(max_bytes=1024)._get(XRU_FLOW, "D.BR.BRL.A")
    with pytest.raises(ResponseTooLarge, match="exceeds the 1024-byte cap"):
        EcbExrFeed(max_bytes=1024)._get("D.BRL.EUR.SP00.A")
    assert feeds.BIS_MAX_BYTES == 50 * 1024 * 1024 and feeds.EXR_MAX_BYTES == 20 * 1024 * 1024
    stub.body = b"a,b\n1,2\n"                             # under the cap: read as before
    assert EcbExrFeed(max_bytes=1024)._get("D.BRL.EUR.SP00.A") == "a,b\n1,2\n"


def test_bis_transient_errors_still_retried_through_https_get(monkeypatch):
    stub = _StubHttps(503)
    _stub_opener(monkeypatch, stub)
    slept = []
    with pytest.raises(urllib.error.HTTPError):
        BisFeed(sleep=slept.append, retries=2)._get_retry(XRU_FLOW, "D.BR.BRL.A")
    assert len(stub.urls) == 3 and len(slept) == 2
