"""EQ-A-0029: Bloomberg / LSEG CSV importers. Every export and mapping here is SYNTHETIC and vendor-shaped only
(tests/fixtures/market); real ticker formats are unverified until Sam exports from a licensed terminal."""
import datetime as dt
from pathlib import Path

import pandas as pd
import pytest

from econquest.ingestion.market.importers import (MAP_COLUMNS, TEMPLATE, ensure_ticker_map, import_and_save,
                                                  import_vendor_csv, load_ticker_map)
from econquest.ingestion.market.schema import MARKET_COLUMNS, MarketDataError
from econquest.ingestion.market.store import latest_market, read_market_snapshot

FIX = Path(__file__).parent / "fixtures" / "market"
MAP = FIX / "ticker_map_test.csv"
NOW = dt.datetime(2026, 10, 21, 7, 0, tzinfo=dt.timezone.utc)
LIC = "Bloomberg Terminal licence (SYNTHETIC test)"


def imp(name, profile="bloomberg", **kw):
    return import_vendor_csv(FIX / name, profile, kw.pop("licence", LIC), NOW, mapping=kw.pop("mapping", MAP), **kw)


def val(df, instrument, tenor, asof):
    r = df[(df["instrument"] == instrument) & (df["tenor_y"] == tenor) & (df["asof"] == asof)]
    assert len(r) == 1, r
    return r.iloc[0]


def test_bloomberg_long_with_title_line_and_na():
    df = imp("bloomberg_long.csv")
    assert list(df.columns) == MARKET_COLUMNS and len(df) == 4 and df.attrs["skipped"] == 1
    r = val(df, "cds", 5.0, "2026-10-19")
    assert r["value"] == 201.5 and r["iso"] == "BRA" and r["doc_clause"] == "CR14" and r["source"] == "bloomberg"
    assert r["vendor_ticker"] == "BRAZIL CDS USD SR 5Y D14 Corp" and r["licence"] == LIC
    assert r["retrieved_utc"] == "2026-10-21T07:00:00Z" and r["snapshot_id"] == ""
    assert val(df, "fx_spot", 0.0, "2026-10-20")["unit"] == "BRL/USD"


def test_bloomberg_bdh_pairs_and_scale():
    df = imp("bloomberg_bdh.csv")
    assert len(df) == 4
    assert val(df, "cds", 5.0, "2026-10-20")["value"] == 200
    assert val(df, "fx_forward", 1.0, "2026-10-20")["value"] == pytest.approx(0.41)    # 4,100 pips x 0.0001


def test_lseg_long_ignores_other_columns_and_wide_skips_blank():
    df = imp("lseg_long.csv", "lseg", licence="LSEG Workspace licence (SYNTHETIC test)")
    assert len(df) == 3 and set(df["source"]) == {"lseg"}
    assert val(df, "cds", 1.0, "2026-10-20")["value"] == 100                          # 20-Oct-2026 format
    w = imp("lseg_wide.csv", "lseg", licence="LSEG Workspace licence (SYNTHETIC test)")
    assert len(w) == 3 and w.attrs["skipped"] == 1


def test_unmapped_and_unverified_are_listed_never_guessed(tmp_path):
    p = tmp_path / "x.csv"
    p.write_text("Ticker,Date,PX_LAST\nCOLOM CDS USD SR 5Y D14 Corp,10/20/2026,150\n"
                 "ARGENT CDS USD SR 5Y D14 Corp,10/20/2026,900\nBRAZIL CDS USD SR 5Y D14 Corp,10/20/2026,200\n")
    with pytest.raises(MarketDataError) as e:
        import_vendor_csv(p, "bloomberg", LIC, NOW, mapping=MAP)
    msg = str(e.value)
    assert "unmapped" in msg and "COLOM CDS USD SR 5Y D14 Corp" in msg
    assert "not verified" in msg and "ARGENT" in msg


@pytest.mark.parametrize("lic", ["", "none", "None", "pending", "PENDING licence", "TBD", "=cmd|' /C calc'!A0",
                                 "n/a (hand-entered)"])
def test_licence_required(lic):
    with pytest.raises(MarketDataError, match="licence"):
        imp("bloomberg_long.csv", licence=lic)


def test_formula_cells_refused(tmp_path):
    for bad in ('=HYPERLINK("http://x")', "@SUM(A1)", "+1+cmd", "-2+3"):
        p = tmp_path / "f.csv"
        p.write_text(f"Ticker,Date,PX_LAST\nBRAZIL CDS USD SR 5Y D14 Corp,10/20/2026,200\n{bad},10/20/2026,1\n")
        with pytest.raises(MarketDataError, match="formula"):
            import_vendor_csv(p, "bloomberg", LIC, NOW, mapping=MAP)
    p.write_text("Ticker,Date,PX_LAST\nBRAZIL CDS USD SR 5Y D14 Corp,10/20/2026,-2.5\n")
    assert import_vendor_csv(p, "bloomberg", LIC, NOW, mapping=MAP)["value"].tolist() == [-2.5]   # negative number ok


def test_size_cap_and_bad_inputs(tmp_path):
    with pytest.raises(MarketDataError, match="exceeds the cap"):
        imp("bloomberg_long.csv", max_bytes=50)
    with pytest.raises(MarketDataError, match="profile"):
        import_vendor_csv(FIX / "bloomberg_long.csv", "markit", LIC, NOW, mapping=MAP)
    p = tmp_path / "d.csv"
    p.write_text("Ticker,Date,PX_LAST\nBRAZIL CDS USD SR 5Y D14 Corp,20/10/2026,200\n")        # dd/mm: not guessed
    with pytest.raises(MarketDataError, match="dates not in"):
        import_vendor_csv(p, "bloomberg", LIC, NOW, mapping=MAP)
    p.write_text("Ticker,Date,PX_LAST\nBRAZIL CDS USD SR 5Y D14 Corp,10/20/2026,abc\n")
    with pytest.raises(MarketDataError, match="not a number"):
        import_vendor_csv(p, "bloomberg", LIC, NOW, mapping=MAP)
    p.write_text("foo,bar\n1,2\n")
    with pytest.raises(MarketDataError, match="no recognisable"):
        import_vendor_csv(p, "bloomberg", LIC, NOW, mapping=MAP)
    p.write_text("Ticker,Date,PX_LAST\nBRAZIL CDS USD SR 5Y D14 Corp,10/22/2026,200\n")         # after `now`
    with pytest.raises(MarketDataError, match="future"):
        import_vendor_csv(p, "bloomberg", LIC, NOW, mapping=MAP)


def test_mapping_required_and_template(tmp_path):
    with pytest.raises(MarketDataError, match="ticker map"):
        import_vendor_csv(FIX / "bloomberg_long.csv", "bloomberg", LIC, NOW, data_dir=tmp_path)
    p = ensure_ticker_map(tmp_path)
    assert p.read_bytes() == TEMPLATE.read_bytes()
    p.write_text("x\n"); ensure_ticker_map(tmp_path)
    assert p.read_text() == "x\n"                                                       # never overwritten
    t = load_ticker_map(TEMPLATE)
    assert list(t.columns) == MAP_COLUMNS and set(t["status"]) == {"verify"}
    desk = set(pd.read_csv(Path(__file__).parents[1] / "data" / "countries.csv")["iso"])
    assert desk <= set(t.loc[t["instrument"] == "cds", "iso"])
    dup = pd.concat([load_ticker_map(MAP), load_ticker_map(MAP).iloc[[0]]])
    with pytest.raises(MarketDataError, match="duplicate"):
        load_ticker_map(dup)


def test_import_and_save_snapshot(tmp_path):
    folder = import_and_save(tmp_path, FIX / "bloomberg_long.csv", "bloomberg", LIC, NOW, mapping=MAP)
    snap = read_market_snapshot(tmp_path, folder.name)
    assert len(snap) == 4 and (snap["snapshot_id"] == folder.name).all()
    assert '"importer": "bloomberg csv"' in (folder / "manifest.json").read_text()
    assert latest_market(tmp_path, "cds", asof="2026-10-21")["value"].tolist() == [100, 200]
