"""EQ-B-0009: SMTP alert delivery must fail closed when STARTTLS is unavailable or fails."""
import smtplib
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from econquest.validation.alerts import send_email, deliver_alerts  # noqa: E402

ENV = {"ECONQUEST_SMTP_HOST": "smtp.example.test", "ECONQUEST_SMTP_PORT": "587", "ECONQUEST_SMTP_USER": "u",
       "ECONQUEST_SMTP_PASSWORD": "secret", "ECONQUEST_SMTP_FROM": "a@example.test", "ECONQUEST_SMTP_TO": "b@example.test"}


class FakeSMTP:
    instances: list = []
    offer_starttls = True
    starttls_error: Exception | None = None

    def __init__(self, host, port, timeout=None):
        self.calls = []; self.closed = False; self.tls = False
        FakeSMTP.instances.append(self)

    def ehlo(self): self.calls.append("ehlo")
    def has_extn(self, name): return name.lower() == "starttls" and self.offer_starttls

    def starttls(self, context=None):
        self.calls.append("starttls")
        if self.starttls_error is not None:
            raise self.starttls_error
        assert context is not None and context.verify_mode != 0      # certificate verification on
        self.tls = True

    def login(self, user, pw): self.calls.append(("login", self.tls))
    def send_message(self, msg): self.calls.append(("send", self.tls))
    def close(self): self.closed = True
    def __enter__(self): return self
    def __exit__(self, *a): self.close()


@pytest.fixture
def fake_smtp(monkeypatch):
    FakeSMTP.instances = []; FakeSMTP.offer_starttls = True; FakeSMTP.starttls_error = None
    monkeypatch.setattr(smtplib, "SMTP", FakeSMTP)
    return FakeSMTP


def _sent(server):
    return [c for c in server.calls if isinstance(c, tuple)]


def test_sends_only_after_starttls(fake_smtp):
    assert send_email(ENV, "s", "body").startswith("sent to")
    assert _sent(fake_smtp.instances[0]) == [("login", True), ("send", True)]


@pytest.mark.parametrize("err", [smtplib.SMTPResponseException(454, b"TLS not available"), OSError("reset"),
                                 smtplib.SMTPNotSupportedError("no")])
def test_starttls_failure_refuses_plaintext(fake_smtp, err):
    fake_smtp.starttls_error = err
    with pytest.raises(ConnectionError, match="refusing to send over plaintext"):
        send_email(ENV, "s", "body")
    srv = fake_smtp.instances[0]
    assert _sent(srv) == [] and srv.closed


def test_starttls_not_offered_refuses_plaintext(fake_smtp):
    fake_smtp.offer_starttls = False
    with pytest.raises(ConnectionError):
        send_email(ENV, "s", "body")
    srv = fake_smtp.instances[0]
    assert "starttls" not in srv.calls and _sent(srv) == [] and srv.closed


def test_deliver_alerts_reports_error_without_raising(fake_smtp):
    fake_smtp.starttls_error = smtplib.SMTPException("boom")
    st = deliver_alerts([], None, env=ENV, webhook=False, email=True, log=lambda *_: None)
    assert st["email"].startswith("error:") and "plaintext" in st["email"]
    assert _sent(fake_smtp.instances[0]) == []


def test_webhook_url_scheme_checked_and_never_echoed(monkeypatch, tmp_path):
    # EQ-B-0018 / SEC-C-002 #8: only https (or loopback http) is posted to; errors never repeat the secret URL
    import urllib.request
    from econquest.validation import alerts as A
    calls = []
    monkeypatch.setattr(urllib.request, "urlopen", lambda *a, **k: calls.append(a) or (_ for _ in ()).throw(AssertionError("posted")))
    for bad in ("http://hooks.example.com/T0/SECRET", "file:///etc/passwd", "ftp://x/SECRET", "hooks.example.com/SECRET"):
        with pytest.raises(ValueError) as e:
            A.post_webhook(bad, {"text": "x"})
        assert "SECRET" not in str(e.value) and "passwd" not in str(e.value)
    assert calls == []
    A.check_webhook_url("https://hooks.slack.com/services/T0/B0/x")
    A.check_webhook_url("http://127.0.0.1:8080/hook")
    status = A.deliver_alerts([], None, env={"ECONQUEST_ALERT_WEBHOOK": "http://evil.example/SECRET"}, out_dir=tmp_path, email=False, log=lambda *_: None)
    assert status["webhook"].startswith("error:") and "SECRET" not in status["webhook"]


def test_webhook_http_error_hides_url(monkeypatch):
    import urllib.error
    import urllib.request
    from econquest.validation import alerts as A
    def boom(req, timeout):
        raise urllib.error.HTTPError(req.full_url, 403, "Forbidden", {}, None)
    monkeypatch.setattr(urllib.request, "urlopen", boom)
    with pytest.raises(RuntimeError) as e:
        A.post_webhook("https://hooks.example.com/SECRET", {"text": "x"})
    assert str(e.value) == "HTTP 403"


def test_webhook_malformed_url_never_echoed(monkeypatch):
    # review of EQ-B-0018: a token with a space or control character made http.client raise InvalidURL quoting the path
    from econquest.validation import alerts as A
    for bad in ("https://hooks.slack.com/services/T0/B0/SECRETTOKEN x", "https://hooks.slack.com/services/SECRET\r\nX: y"):
        with pytest.raises(ValueError) as e:
            A.post_webhook(bad, {"text": "x"})
        assert "SECRET" not in str(e.value)
    import urllib.request
    import http.client
    def invalid(req, timeout):
        raise http.client.InvalidURL(f"bad {req.full_url}")
    monkeypatch.setattr(urllib.request, "urlopen", invalid)
    with pytest.raises(RuntimeError) as e:
        A.post_webhook("https://hooks.example.com/SECRET", {"text": "x"})
    assert "SECRET" not in str(e.value) and "InvalidURL" in str(e.value)
