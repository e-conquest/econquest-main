"""`econquest benchmark` scores as of the snapshot date, not the wall clock (HO-20261023-B-C-007)."""
import shutil
from pathlib import Path

import pandas as pd
import pytest

from econquest import cli

ROOT = Path(__file__).resolve().parent.parent


@pytest.fixture(scope="module")
def run(tmp_path_factory):
    tmp = tmp_path_factory.mktemp("bmk")
    d = tmp / "data"
    shutil.copytree(ROOT / "data", d, ignore=shutil.ignore_patterns("vintages", "snapshots", "market_history"))

    def go(*extra):
        out = tmp / ("out" + "_".join(extra).replace(",", "-"))
        cli.main(["--data", str(d), "--out", str(out), "benchmark", "--as-of", "2026-10-23", "--paths", "2000", *extra])
        return out
    return go


def test_scores_written_as_of_snapshot(run, capsys):
    out = run()
    o = capsys.readouterr().out
    assert "benchmark scoring as of 2026-10-23: 12m not yet scorable, first maturity 2027-10-23" in o
    sc = pd.read_csv(out / "benchmark_scores.csv")
    assert len(sc) == 6 and set(sc["status"]) == {"not yet scorable, first maturity 2027-10-23"}
    cal = pd.read_csv(out / "benchmark_calibration.csv")
    assert len(cal) == 0 and len(cal.columns)
    assert (out / "benchmarks_scores.csv").exists() and (out / "benchmarks_snapshot.csv").exists()   # existing outputs kept


def test_horizons_flag(run, capsys):
    out = run("--horizons", "12m,6m")
    o = capsys.readouterr().out
    assert "12m " in o and "6m " in o
    assert set(pd.read_csv(out / "benchmark_scores.csv")["horizon"]) == {"12m", "6m"}


def test_bad_horizons(run):
    with pytest.raises(SystemExit, match="--horizons"):
        run("--horizons", "twelve")
