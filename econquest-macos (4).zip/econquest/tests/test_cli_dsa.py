"""econquest dsa writes its scorecard feeds as an output and never changes data/ (EQ-C-0013, HO-20261023-B-C-004)."""
import hashlib
import shutil
from pathlib import Path

import pandas as pd
import pytest

from econquest import cli
from econquest.engine import dsa as D

ROOT = Path(__file__).resolve().parent.parent


def tree_hash(d: Path) -> dict:
    return {str(p.relative_to(d)): hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(d.rglob("*")) if p.is_file()}


@pytest.fixture
def data(tmp_path):
    d = tmp_path / "data"
    shutil.copytree(ROOT / "data", d, ignore=shutil.ignore_patterns("vintages", "snapshots", "panel", "market_history"))
    return d


@pytest.mark.parametrize("extra", [[], ["--apply"], ["--apply", "--force"]])
def test_dsa_writes_feeds_and_leaves_data_untouched(data, tmp_path, monkeypatch, capsys, extra):
    monkeypatch.setattr(D, "apply_to_inputs", lambda *a, **k: pytest.fail("apply_to_inputs must not be called"))
    out = tmp_path / "out"; before = tree_hash(data)
    cli.main(["--data", str(data), "--out", str(out), "dsa", "--paths", "200", "--as-of", "2026-10-23", *extra])
    feeds = pd.read_csv(out / "dsa_scorecard_feeds.csv", dtype=str)
    assert list(feeds.columns) == D.FEED_COLUMNS and len(feeds)
    assert set(feeds["key"]) <= {"1.1", "1.2", "2.1"} and set(feeds["retrieved"]) == {"2026-10-23"}
    assert tree_hash(data) == before
    o = capsys.readouterr().out
    assert "apply through the ingestion gate" in o
    assert ("Nothing under data/ was changed" in o) == bool(extra)
