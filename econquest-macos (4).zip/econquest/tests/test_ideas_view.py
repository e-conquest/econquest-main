"""Trade-idea ledger view (EQ-C-0047, GOV-032): hit rate and P&L by quarter from Team B's idea log, in the GUI
(GET /api/ideas, Trade ideas tab, every inserted string escaped) and in the workbook (additive 'Trade Ideas' tab: ranges
valid, no overlap, text formula-escaped, the C11 v1/v2 ranges unchanged). Empty, missing and unreadable logs render
cleanly. Synthetic logs in tmp dirs; no network, no live Sheets write (publish runs dry)."""
import http.client
import json
import re
import sys
import threading
from http.server import ThreadingHTTPServer
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from econquest import cli  # noqa: E402
from econquest.config import Settings  # noqa: E402
from econquest.engine import run_pipeline  # noqa: E402
from econquest.ingestion import load_universe  # noqa: E402
from econquest.presentation import api  # noqa: E402
from econquest.presentation import sheets_publish as SP  # noqa: E402
from econquest.presentation.gui import make_gui_handler  # noqa: E402
from econquest.presentation.ideas_view import HEADER, LABEL, ideas_summary, quarterly  # noqa: E402
from econquest.validation import idea_log  # noqa: E402
from test_gui_security import StubJobs, good  # noqa: E402
from test_workbook_v2 import V1_RANGES  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
AS_OF = "2026-10-23"
PAGE = (Path(api.__file__).parent / "static" / "gui.html").read_text()
EVIL = '=HYPERLINK("http://evil.example","x")<img src=x onerror=alert(1)>'


def idea(i, as_of, *, status="open", markable=True, ret=np.nan, pnl=np.nan, close=None, reason="", mark=None, strategy="Long USD"):
    return {"idea_id": f"T{i:02d}-AAA-{as_of.replace('-', '')}", "run_id": f"{as_of.replace('-', '')}T120000-base", "as_of": as_of,
            "trade_id": f"T{i:02d}", "strategy": strategy, "country": "A", "iso": "AAA", "stance": "Risk-off",
            "instrument": "FX" if markable else "CDS", "signal_value": 70.0, "regime": "Calm", "notional_mm": 10.0, "country_notional_mm": 10.0,
            "ticker": "USDAAA" if markable else "", "direction": 1 if markable else 0, "markable": markable,
            "unmarked_reason": "" if markable else "no price series for instrument CDS", "entry_date": as_of if markable else None,
            "entry_price": 100.0 if markable else np.nan, "vol_3m": 0.05, "stop": 90.0, "target": 110.0, "max_exit_date": "2027-12-31",
            "status": status, "rearm": False, "last_fired_as_of": as_of, "mark_date": mark or (as_of if markable else None),
            "mark_price": 100.0, "return_pct": ret, "pnl_mm": pnl, "close_date": close, "close_price": np.nan if close is None else 100.0,
            "close_reason": reason, "close_run_id": ""}


def sample_log() -> pd.DataFrame:
    """Q3: two opened, one closed on target (+0.20 $mm). Q4: idea 2 closed on stop (-0.10), two opened and still open."""
    return pd.DataFrame([
        idea(1, "2026-07-10", status="closed", ret=2.0, pnl=0.2, close="2026-08-03", reason="target", mark="2026-08-03"),
        idea(2, "2026-07-15", status="closed", ret=-1.0, pnl=-0.1, close="2026-10-05", reason="stop", mark="2026-10-05"),
        idea(3, "2026-10-02", ret=0.5, pnl=0.05, mark="2026-10-20"),
        idea(4, "2026-10-02", markable=False, strategy=EVIL)])[idea_log.COLUMNS]


def write_log(out: Path, log: pd.DataFrame | None = None) -> Path:
    out.mkdir(parents=True, exist_ok=True)
    idea_log.save_log(sample_log() if log is None else log, out / "idea_log.csv")
    return out


# ---------------------------------------------------------------- the view (formatting of Team B's report)
def test_quarterly_table_from_team_b_report(tmp_path):
    s = ideas_summary(write_log(tmp_path))
    assert s["status"] == "ok" and s["label"] == LABEL and "Tier 3" in s["label"] and s["as_of"] == "2026-10-20"
    q = {r["quarter"]: r for r in s["quarters"]}
    assert list(q) == ["2026Q3", "2026Q4"]
    assert (q["2026Q3"]["opened"], q["2026Q3"]["closed"], q["2026Q3"]["hit_rate"], q["2026Q3"]["open_end"]) == (2, 1, 1.0, 1)
    assert (q["2026Q4"]["opened"], q["2026Q4"]["closed"], q["2026Q4"]["hit_rate"], q["2026Q4"]["open_end"]) == (2, 1, 0.0, 2)
    assert q["2026Q3"]["pnl_mm"] == pytest.approx(0.2) and q["2026Q4"]["pnl_mm"] == pytest.approx(-0.1)
    # the total row is Team B's "all" row; quarters add up to it
    a = idea_log.idea_report(idea_log.load_log(tmp_path / "idea_log.csv")).iloc[0]
    t = s["total"]
    assert (t["opened"], t["closed"], t["open_end"], t["hit_rate"]) == (a["ideas"], a["closed"], a["open"], a["hit_rate"]) == (4, 2, 2, 0.5)
    assert t["pnl_mm"] == pytest.approx(a["pnl_realised_mm"]) == pytest.approx(sum(r["pnl_mm"] for r in s["quarters"]))
    assert s["pnl_open_mm"] == pytest.approx(0.05) and s["pnl_total_mm"] == pytest.approx(0.15) and s["unmarked"] == 1
    json.dumps(s, allow_nan=False)                                       # NaN hit rates are None, not NaN


def test_quarter_with_no_closed_idea_has_no_hit_rate(tmp_path):
    write_log(tmp_path, pd.DataFrame([idea(3, "2026-10-02", ret=0.5, pnl=0.05)])[idea_log.COLUMNS])
    rows = quarterly(idea_log.load_log(tmp_path / "idea_log.csv"))
    assert rows == [{"quarter": "2026Q4", "opened": 1, "closed": 0, "closed_marked": 0, "hit_rate": None, "pnl_mm": 0.0, "open_end": 1}]


def test_missing_empty_and_unreadable_logs(tmp_path):
    m = ideas_summary(tmp_path / "none")
    assert m["status"] == "missing" and m["quarters"] == [] and m["total"] is None and "econquest ideas log" in m["message"]
    e = ideas_summary(write_log(tmp_path / "empty", idea_log.empty_log()))
    assert e["status"] == "empty" and e["quarters"] == [] and "no ideas" in e["message"]
    bad = tmp_path / "bad"; bad.mkdir()
    (bad / "idea_log.csv").write_text("idea_id,as_of,status\nx,not-a-date,open\n")
    b = ideas_summary(bad)
    assert b["status"] == "invalid" and b["quarters"] == [] and str(bad) not in b["message"]    # no local path
    for s in (m, e, b):
        assert s["label"] == LABEL
        json.dumps(s, allow_nan=False)


def test_view_does_not_read_the_escaped_report_csv(tmp_path):
    out = write_log(tmp_path)
    (out / "idea_report.csv").write_text("garbage that would break a reader\n")
    assert ideas_summary(out)["status"] == "ok"


# ---------------------------------------------------------------- workbook: additive Trade Ideas tab
def test_ideas_plan_ranges_fit_and_label(tmp_path):
    s = ideas_summary(write_log(tmp_path))
    plan = SP.ideas_plan(s, stamp=AS_OF)
    assert [b["range"] for b in plan] == ["'Trade Ideas'!A1:A3", "'Trade Ideas'!A5:G8"] == list(SP.ideas_layout(2).values())
    assert SP.plan_problems(plan) == []
    notes, table = plan[0]["values"], plan[1]["values"]
    assert "Illustrative, Tier 3" in notes[0][0] and notes[1][0].startswith("[OK] 4 ideas") and AS_OF in notes[2][0]
    assert "0.05 $mm" in notes[2][0] and "0.15 $mm" in notes[2][0]
    assert table[0] == HEADER and [r[0] for r in table[1:]] == ["2026Q3", "2026Q4", "All quarters"]
    assert table[-1][1:] == [4, 2, 2, 0.5, pytest.approx(0.1), 2]
    json.dumps(plan, allow_nan=False)


@pytest.mark.parametrize("status", ["missing", "empty", "invalid"])
def test_ideas_plan_empty_states(tmp_path, status):
    if status == "missing":
        s = ideas_summary(tmp_path)
    elif status == "empty":
        s = ideas_summary(write_log(tmp_path, idea_log.empty_log()))
    else:
        (tmp_path / "idea_log.csv").write_text("idea_id,as_of\nx,not-a-date\n"); s = ideas_summary(tmp_path)
    plan = SP.ideas_plan(s, stamp=AS_OF)
    assert [b["range"] for b in plan] == ["'Trade Ideas'!A1:A3", "'Trade Ideas'!A5:G6"] and SP.plan_problems(plan) == []
    assert plan[0]["values"][1][0].startswith(f"[{status.upper()}]") and plan[1]["values"][0] == HEADER
    assert plan[1]["values"][1][0] == s["message"] and len(plan[1]["values"][1]) == 7


def test_ideas_plan_formula_escapes_text():
    s = {"status": "missing", "message": EVIL, "label": "+cmd|' /C calc'!A0", "run_id": "@SUM(1)", "quarters": []}
    plan = SP.ideas_plan(s, stamp=AS_OF)
    assert plan[1]["values"][1][0] == "'" + EVIL                          # cell that would be a formula is text
    qs = {"status": "ok", "message": "m", "quarters": [{"quarter": "=1+1", "opened": 1}], "total": {"quarter": "-2"}}
    body = SP.ideas_plan(qs, stamp=AS_OF)[1]["values"]
    assert body[1][0] == "'=1+1" and body[2][0] == "'-2" and body[1][1] == 1
    assert all(not (isinstance(x, str) and x[:1] and x[:1] in "=+-@") for b in SP.sanitize_plan(plan) for r in b["values"] for x in r)


def test_trade_ideas_tab_is_new_and_documented():
    tabs = {SP.parse_a1(r.format(e=20))[0] for r in V1_RANGES} | {SP.parse_a1(r)[0] for r in SP.layout_v2(70).values()}
    assert "Trade Ideas" not in tabs                                      # additive: no existing tab is written
    for q in (0, 1, 40):
        L = SP.ideas_layout(q)
        assert SP.parse_a1(L["ideas_table"])[4] == 7 and SP.parse_a1(L["ideas_table"])[3] == 6 + q   # A:G, inside A:Z
        assert SP.plan_problems([{"range": r, "values": [[0]]} for r in L.values()]) == []
    ref = json.loads((DATA / "workbook_reference.json").read_text())["layout"]["additive_tabs"]["'Trade Ideas'"]
    assert ref["notes"] == SP.ideas_layout(0)["ideas_notes"] and ref["table_q0"] == SP.ideas_layout(0)["ideas_table"]
    assert ref["table"] == "'Trade Ideas'!A5:G(6+Q)" and "Tier 3" in ref["tier"]


@pytest.fixture(scope="module")
def run18():
    u = load_universe(DATA); s = Settings.load(DATA / "assumptions.json")
    return u, s, run_pipeline(u, s, paths=2000, as_of=AS_OF)


def test_build_plan_with_ideas_keeps_c11_ranges(run18, tmp_path):
    u, s, res = run18
    history = pd.read_csv(DATA / "backtest_history.csv")
    base = SP.build_plan(res, u, s, history=history, stamp=AS_OF, mc_rows=50)
    plan = SP.build_plan(res, u, s, history=history, stamp=AS_OF, mc_rows=50, ideas=ideas_summary(write_log(tmp_path)))
    v1 = [r.format(e=16 + len(history)) for r in V1_RANGES]
    assert [b["range"] for b in base] == v1                               # without ideas: unchanged
    assert [b["range"] for b in plan] == v1 + ["'Trade Ideas'!A1:A3", "'Trade Ideas'!A5:G8"]
    assert plan[:len(base)] == base and SP.plan_problems(plan) == []
    labels = next(b for b in plan if b["range"] == "'Risk Engine'!A35:D37")["values"]
    assert [r[0] for r in labels] == ["R31", "R32", "R33"]


def test_publish_ideas_flag_dry_run(tmp_path):
    out = write_log(tmp_path / "outputs")
    cli.main(["--data", str(DATA), "--out", str(out), "publish", "--paths", "2000", "--mc-rows", "20", "--no-garch", "--ideas"])
    plan = json.loads((out / "publish_plan.json").read_text())
    ranges = [b["range"] for b in plan]
    assert ranges[-2:] == ["'Trade Ideas'!A1:A3", "'Trade Ideas'!A5:G8"] and SP.plan_problems(plan) == []
    assert "Trade Ideas" not in " ".join(ranges[:-2])
    cli.main(["--data", str(DATA), "--out", str(out), "publish", "--paths", "2000", "--mc-rows", "20", "--no-garch"])
    assert not any("Trade Ideas" in b["range"] for b in json.loads((out / "publish_plan.json").read_text()))   # opt-in only


# ---------------------------------------------------------------- GUI: /api/ideas and the Trade ideas tab
class IdApp:
    token = "test-token-123"
    latest = {"summary": {"run_id": "r-id"}, "settings": {"as_of": AS_OF}, "country": []}


@pytest.fixture
def serve(tmp_path):
    srvs = []

    def start(kind: str):
        out = tmp_path / kind / "outputs"; out.mkdir(parents=True)
        if kind == "ok":
            write_log(out)
        elif kind == "empty":
            write_log(out, idea_log.empty_log())
        srv = ThreadingHTTPServer(("127.0.0.1", 0), make_gui_handler(IdApp(), StubJobs(), out, tmp_path / "data"))
        threading.Thread(target=srv.serve_forever, daemon=True).start(); srvs.append(srv)
        return srv.server_address[1]
    yield start
    for s in srvs:
        s.shutdown()


def get(port, path, headers=None):
    conn = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
    conn.request("GET", path, headers={"Host": f"127.0.0.1:{port}", **(headers or {})})
    r = conn.getresponse()
    return r.status, r.read().decode()


@pytest.mark.parametrize("kind,status,n", [("ok", "ok", 2), ("empty", "empty", 0), ("missing", "missing", 0)])
def test_ideas_route(serve, kind, status, n):
    port = serve(kind)
    st, body = get(port, "/api/ideas")
    s = json.loads(body)
    assert st == 200 and s["status"] == status and len(s["quarters"]) == n and "Tier 3" in s["label"]
    assert s["file"] == "idea_log.csv" and "/" not in s["file"]            # file name only, no local paths


def test_ideas_route_is_read_only(serve):
    port = serve("ok")
    conn = http.client.HTTPConnection("127.0.0.1", port, timeout=5)
    conn.request("POST", "/api/ideas", body="{}", headers={"Host": f"127.0.0.1:{port}", **good(port)})
    assert conn.getresponse().status in (404, 405)
    assert get(port, "/api/ideas", headers={"Host": "evil.example:80"})[0] == 403    # DNS rebinding guard still applies


def test_gui_has_ideas_tab_and_escapes():
    assert '<a data-tab="ideas">Trade ideas</a>' in PAGE and '<section id="ideas">' in PAGE
    assert re.search(r"const renderers = \{[^}]*\bideas\b", PAGE) and 'ideas: "Trade-idea ledger (illustrative, Tier 3)"' in PAGE
    assert "ILLUSTRATIVE · TIER 3" in PAGE[PAGE.index('<section id="ideas">'):]
    block = PAGE[PAGE.index("// ---------- trade ideas (EQ-C-0047)"):PAGE.index("// ---------- events (EQ-C-0038)")]
    # every ${...} in the block goes through esc() or fmt.* (numbers), or is a fixed colour / count
    for expr in re.findall(r"\$\{([^{}]*)\}", block):
        e = expr.strip()
        assert e.startswith(("esc(", "fmt.", "col", "IDEAS.run_id ?", "r.hit_rate == null")) or e in ("IDEAS.unmarked", "IDEAS.ideas"), e
    assert "${esc(IDEAS.message)}" in block and "${esc(IDEAS.run_id)}" in block
    assert '$("#i-label").textContent' in block and '$("#i-open-note").textContent' in block    # text, not HTML
    assert "x: qs.map(r => esc(r.quarter))" in block                           # Plotly labels escaped
    assert re.search(r'emptyMsg: IDEAS\.status === "missing" \? "[^"$`]*" : IDEAS\.status === "invalid" \? "[^"$`]*" : "[^"$`]*"', block)
