"""EQ-A-0017 Gate v2: cross-source (WEO vs World Bank) and vintage-to-vintage checks, and their merge into the review
frame. Offline; the real-data smoke test only reads data/live (never writes a vintage)."""
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.ingestion.crosscheck import (CHECK_COLUMNS, CROSS_PAIRS, cross_source_checks, merge_into_review,  # noqa: E402
                                            vintage_checks)
from econquest.ingestion.feeds import FetchReport  # noqa: E402

DATA = ROOT / "data"
PROF_COLS = ["pop", "exports", "reserves", "fx3m", "policy", "equity_vol"]


def _universe():
    countries = pd.DataFrame({"country": ["Vietnam", "Brazil"], "iso": ["VNM", "BRA"]})
    rulebook = pd.DataFrame({"id": ["5.14", "2.10", "2.1"], "t0": [500, 50, 0], "t25": [2000, 100, 1], "t50": [5000, 150, 2],
                             "t75": [8000, 200, 3], "t100": [10000, 300, 4]})
    return SimpleNamespace(names=["Vietnam", "Brazil"], countries=countries, rulebook=rulebook)


def _raw(vnm_weo_gdp=480.0, bra_weo_gdp=2200.0):
    """WEO and WB long tables for 2024-2025 (WEO also projects 2026, which WB cannot have)."""
    weo, wb = [], []
    for y in (2024, 2025, 2026):
        weo += [{"iso": "VNM", "series": "NGDPD", "period": y, "value": vnm_weo_gdp},
                {"iso": "VNM", "series": "NGDPDPC", "period": y, "value": vnm_weo_gdp * 1e9 / 101e6},
                {"iso": "BRA", "series": "NGDPD", "period": y, "value": bra_weo_gdp},
                {"iso": "BRA", "series": "NGDPDPC", "period": y, "value": bra_weo_gdp * 1e9 / 212e6}]
    for y in (2024, 2025):
        wb += [{"iso": "VNM", "series": "NY.GDP.MKTP.CD", "period": y, "value": 480e9},
               {"iso": "VNM", "series": "SP.POP.TOTL", "period": y, "value": 101e6},
               {"iso": "BRA", "series": "NY.GDP.MKTP.CD", "period": y, "value": 2200e9},
               {"iso": "BRA", "series": "SP.POP.TOTL", "period": y, "value": 212e6}]
    src = lambda rows, s: pd.DataFrame(rows).assign(source=s)  # noqa: E731
    return {"weo": src(weo, "test WEO"), "worldbank": src(wb, "test WB")}


def _report(raw=None, inputs=None, profile=None):
    u = _universe()
    ind = pd.DataFrame(np.nan, index=["2.1", "2.10", "5.14"], columns=u.names)
    for (k, c), v in (inputs or {("5.14", "Vietnam"): 4752.0, ("5.14", "Brazil"): 10377.0}).items():
        ind.at[k, c] = v
    prof = pd.DataFrame(np.nan, index=u.names, columns=PROF_COLS)
    for (c, k), v in (profile or {("Vietnam", "pop"): 101.0, ("Vietnam", "reserves"): 18.0, ("Brazil", "pop"): 212.0}).items():
        prof.at[c, k] = v
    return FetchReport(ind, prof, pd.DataFrame(), {"weo": "ok", "worldbank": "ok"}, raw if raw is not None else _raw())


def _review(rows):
    return pd.DataFrame(rows, columns=["table", "key", "country", "seed", "live", "status", "reason"])


def _vintage(data_dir: Path, vid: str, inputs_csv: str, profile_csv: str) -> Path:
    v = data_dir / "live" / "vintages" / vid
    v.mkdir(parents=True)
    (v / "live_inputs.csv").write_text(inputs_csv)
    (v / "live_profile.csv").write_text(profile_csv)
    return v


# ---------------------------------------------------------------------------------------------- cross-source
def test_pairs_are_documented():
    for p in CROSS_PAIRS:
        assert p.concept and p.weo_series and p.wb_series and p.transform and p.keys
        assert len(p.tolerance) == 2 and min(p.tolerance) >= 0 and max(p.tolerance) > 0
    assert len({k for p in CROSS_PAIRS for k in p.keys}) == sum(len(p.keys) for p in CROSS_PAIRS)  # one pair per cell


def test_cross_source_agree_is_ok():
    out = cross_source_checks(_report(), _universe(), 2026)
    assert list(out.columns) == CHECK_COLUMNS and len(out)
    assert set(out["status"]) == {"ok"} and set(out["check"]) == {"cross_source"}
    assert out["reason"].str.contains("2025").all()              # latest common period: WEO 2026 has no WB counterpart
    # only cells with a live value get rows when a FetchReport is given (Brazil reserves is empty)
    cells = set(zip(out["key"], out["country"]))
    assert ("reserves", "Brazil") not in cells and ("reserves", "Vietnam") in cells and ("5.14", "Brazil") in cells


def test_cross_source_disagree_is_hold():
    out = cross_source_checks(_report(_raw(vnm_weo_gdp=560.0)), _universe(), 2026)   # WEO GDP 16.7% above WB
    vnm = out[out["country"] == "Vietnam"].set_index("key")
    assert vnm.at["reserves", "status"] == "hold" and "gdp_usd 2025" in vnm.at["reserves", "reason"]
    assert vnm.at["5.14", "status"] == "hold"                  # per capita moves with GDP
    assert vnm.at["pop", "status"] == "ok"                     # implied population unchanged
    assert set(out[out["country"] == "Brazil"]["status"]) == {"ok"}


def test_cross_source_raw_dict_and_missing_feed():
    u = _universe()
    out = cross_source_checks(_raw(), u, 2026)                  # plain dict: every pair key for every country
    assert ("reserves", "Brazil") in set(zip(out["key"], out["country"]))
    assert cross_source_checks({"weo": _raw()["weo"]}, u, 2026).empty
    assert cross_source_checks(_raw(), u, 2031, max_lag=5).empty  # 2025 is older than 2031 - 5


# ---------------------------------------------------------------------------------------------- vintage
INPUTS_PREV = ",Vietnam,Brazil\n2.1,1.0,2.0\n2.10,100.0,\n5.14,4700.0,10000.0\n"
PROFILE_PREV = ",pop,exports,reserves,fx3m,policy,equity_vol\nVietnam,100.0,,18.0,,,\nBrazil,210.0,,,,,\n"


def test_no_previous_vintage_gives_no_rows(tmp_path):
    out = vintage_checks(tmp_path, _report(), u=_universe())
    assert out.empty and list(out.columns) == CHECK_COLUMNS


def test_previous_vintage_jump_is_hold(tmp_path):
    _vintage(tmp_path, "2026-10-23", INPUTS_PREV, PROFILE_PREV)
    rep = _report(inputs={("5.14", "Vietnam"): 9000.0, ("5.14", "Brazil"): 10377.0, ("2.10", "Brazil"): 120.0, ("2.1", "Vietnam"): 1.1},
                  profile={("Vietnam", "pop"): 101.0, ("Brazil", "pop"): 212.0})
    out = vintage_checks(tmp_path, rep, u=_universe()).set_index(["key", "country"])
    assert out.at[("5.14", "Vietnam"), "status"] == "hold"          # +91% and 4300 > 0.25 x span 9500
    assert "2026-10-23: 4700 -> 9000" in out.at[("5.14", "Vietnam"), "reason"]
    assert out.at[("5.14", "Brazil"), "status"] == "ok"
    assert out.at[("2.1", "Vietnam"), "status"] == "ok"              # 2.1 and 2.10 are distinct ids
    assert out.at[("2.10", "Brazil"), "status"] == "hold" and "reappeared" in out.at[("2.10", "Brazil"), "reason"]
    assert out.at[("2.10", "Vietnam"), "status"] == "hold" and "disappeared" in out.at[("2.10", "Vietnam"), "reason"]
    assert out.at[("reserves", "Vietnam"), "status"] == "hold"       # disappeared from the profile
    assert out.at[("pop", "Vietnam"), "status"] == "ok"
    assert set(out["basis"]) == {"2026-10-23"}


def test_new_series_is_listed_not_held(tmp_path):
    """EQ-A-0036: a key no country had in the previous vintage (an older install never fetched it) is new coverage:
    'ok' with 'new series', not a 'reappeared' hold. A key other countries had keeps the reappeared hold."""
    prev = ",Vietnam,Brazil\n2.1,,\n2.10,100.0,\n5.14,4700.0,10000.0\n"          # 2.1 empty for every country
    prof = ",pop,exports,reserves,fx3m,policy,equity_vol\nVietnam,100.0,,18.0,,,\nBrazil,210.0,,,,,\n"
    _vintage(tmp_path, "2026-10-22", prev, prof)
    rep = _report(inputs={("2.1", "Vietnam"): 1.5, ("2.1", "Brazil"): 3.0, ("2.10", "Vietnam"): 100.0, ("2.10", "Brazil"): 120.0,
                          ("5.14", "Vietnam"): 4700.0, ("5.14", "Brazil"): 10000.0},
                  profile={("Vietnam", "pop"): 100.0, ("Brazil", "pop"): 210.0, ("Vietnam", "exports"): 90.0, ("Vietnam", "reserves"): 18.0})
    out = vintage_checks(tmp_path, rep, u=_universe()).set_index(["key", "country"])
    for c in ("Vietnam", "Brazil"):
        assert out.at[("2.1", c), "status"] == "ok" and out.at[("2.1", c), "reason"].startswith("new series: not in 2026-10-22")
    assert out.at[("exports", "Vietnam"), "status"] == "ok" and "new series" in out.at[("exports", "Vietnam"), "reason"]
    assert out.at[("2.10", "Brazil"), "status"] == "hold" and "reappeared" in out.at[("2.10", "Brazil"), "reason"]
    # the new-series rows do not hold anything in the review; the reappeared one does
    review = _review([("Inputs", "2.1", "Vietnam", 1.0, 1.5, "ok", ""), ("Inputs", "2.10", "Brazil", 110.0, 120.0, "ok", "")])
    merged = merge_into_review(review, vintage_checks(tmp_path, rep, u=_universe())).set_index(["key", "country"])
    assert merged.at[("2.1", "Vietnam"), "status"] == "ok" and merged.at[("2.10", "Brazil"), "status"] == "hold"


def test_vintage_absolute_floor_and_current_id(tmp_path):
    _vintage(tmp_path, "2026-10-23", INPUTS_PREV, PROFILE_PREV)
    # 2.1 doubles (+100%) but the change 1.0 is below 0.25 x span 4 = 1.0 -> ok, like quality_gate's change rule
    rep = _report(inputs={("2.1", "Vietnam"): 2.0})
    out = vintage_checks(tmp_path, rep, u=_universe()).set_index(["key", "country"])
    assert out.at[("2.1", "Vietnam"), "status"] == "ok"
    # the only vintage is the current one -> nothing to compare with
    assert vintage_checks(tmp_path, rep, u=_universe(), current_vintage_id="2026-10-23").empty
    # explicit previous id that does not exist fails loudly
    with pytest.raises(FileNotFoundError):
        vintage_checks(tmp_path, rep, previous_vintage_id="2020-01-01")


# ---------------------------------------------------------------------------------------------- merge
def test_merge_never_downgrades_and_appends_reasons():
    review = _review([
        {"table": "Inputs", "key": "5.14", "country": "Vietnam", "seed": 4000.0, "live": 9000.0, "status": "hold", "reason": "change: 4000 -> 9000 (+125%)"},
        {"table": "Inputs", "key": "5.14", "country": "Brazil", "seed": 10000.0, "live": 10377.0, "status": "ok", "reason": ""},
        {"table": "Country Profile", "key": "pop", "country": "Brazil", "seed": 210.0, "live": 212.0, "status": "ok", "reason": ""},
        {"table": "Inputs", "key": "2.10", "country": "Vietnam", "seed": np.nan, "live": np.nan, "status": "missing", "reason": "worldbank returned no value"},
    ])
    extra = pd.DataFrame([
        {"table": "Inputs", "key": "5.14", "country": "Vietnam", "check": "vintage", "status": "ok", "reason": "fine", "live": 9000.0, "basis": "v"},
        {"table": "Inputs", "key": "5.14", "country": "Brazil", "check": "cross_source", "status": "hold", "reason": "gdp_per_capita_usd off", "live": 10377.0, "basis": "x"},
        {"table": "Inputs", "key": "2.10", "country": "Vietnam", "check": "vintage", "status": "hold", "reason": "disappeared", "live": np.nan, "basis": "v"},
        {"table": "Country Profile", "key": "reserves", "country": "Brazil", "check": "vintage", "status": "hold", "reason": "disappeared", "live": np.nan, "basis": "v"},
    ], columns=CHECK_COLUMNS)
    out = merge_into_review(review, extra)
    assert list(out.columns) == list(review.columns)
    s = out.set_index(["key", "country"])
    assert s.at[("5.14", "Vietnam"), "status"] == "hold" and s.at[("5.14", "Vietnam"), "reason"] == "change: 4000 -> 9000 (+125%)"
    assert s.at[("5.14", "Brazil"), "status"] == "hold" and s.at[("5.14", "Brazil"), "reason"] == "cross: gdp_per_capita_usd off"
    assert s.at[("pop", "Brazil"), "status"] == "ok"
    assert s.at[("2.10", "Vietnam"), "status"] == "missing" and s.at[("2.10", "Vietnam"), "reason"].endswith("; vintage: disappeared")
    assert s.at[("reserves", "Brazil"), "status"] == "missing"       # added: held cell absent from review, no live value
    assert len(out) == len(review) + 1
    # merging a hold onto an existing hold, or merging nothing, never turns a hold into ok
    again = merge_into_review(out, extra.assign(status="ok"))
    assert (again["status"] == out["status"]).all()
    assert merge_into_review(out, None).equals(out)
    # idempotent: the same reason is not appended twice
    twice = merge_into_review(out, extra)
    assert twice.set_index(["key", "country"]).at[("5.14", "Brazil"), "reason"] == "cross: gdp_per_capita_usd off"


def test_end_to_end_cross_and_vintage_into_review(tmp_path):
    _vintage(tmp_path, "2026-10-23", INPUTS_PREV, PROFILE_PREV)
    rep = _report(_raw(vnm_weo_gdp=560.0))
    review = _review([{"table": "Country Profile", "key": "reserves", "country": "Vietnam", "seed": 17.0, "live": 18.0, "status": "ok", "reason": ""}])
    extra = pd.concat([cross_source_checks(rep, _universe(), 2026), vintage_checks(tmp_path, rep, u=_universe())], ignore_index=True)
    out = merge_into_review(review, extra).set_index(["key", "country"])
    assert out.at[("reserves", "Vietnam"), "status"] == "hold" and out.at[("reserves", "Vietnam"), "reason"].startswith("cross: gdp_usd 2025")


# ---------------------------------------------------------------------------------------------- real data (read-only)
def _real_report(vdir: Path) -> FetchReport:
    def table(name):
        df = pd.read_csv(vdir / name, dtype=str, keep_default_na=False)
        df = df.set_index(df.columns[0])
        return df.apply(lambda c: pd.to_numeric(c.replace("", np.nan), errors="coerce"))
    raw = {f: pd.read_csv(vdir / f"raw_{f}.csv") for f in ("weo", "worldbank") if (vdir / f"raw_{f}.csv").exists()}
    return FetchReport(table("live_inputs.csv"), table("live_profile.csv"), pd.DataFrame(), {}, raw)


@pytest.mark.skipif(not (DATA / "live" / "vintages" / "2026-10-23" / "raw_weo.csv").exists(), reason="no real vintage")
def test_smoke_real_vintage_2026_10_23():
    from econquest.ingestion import load_universe
    u = load_universe(DATA)
    vdir = DATA / "live" / "vintages" / "2026-10-23"
    rep = _real_report(vdir)
    cross = cross_source_checks(rep, u, 2026)
    pair_of = {k: p.concept for p in CROSS_PAIRS for _, k in p.keys}
    cross["concept"] = cross["key"].map(pair_of)
    counts = cross.groupby("concept")["status"].value_counts().unstack(fill_value=0)
    print("\ncross-source checks, vintage 2026-10-23 (WEO vs WB, latest common period <= 2026):\n" + counts.to_string())
    print(cross[cross["status"] == "hold"][["key", "country", "reason"]].to_string(index=False))
    assert len(cross) and set(cross["status"]) <= {"ok", "hold"}
    # the same vintage against itself: every cell compared, no jumps
    vin = vintage_checks(DATA, rep, previous_vintage_id="2026-10-23", u=u)
    print(f"vintage self-check: {len(vin)} cells compared, {int((vin['status'] == 'hold').sum())} held")
    assert len(vin) and (vin["status"] == "ok").all()
    # the current data/live tables against the vintage
    live = DATA / "live"
    if (live / "live_inputs.csv").exists() and (live / "live_profile.csv").exists():
        cur = _real_report(live)
        v2 = vintage_checks(DATA, cur, previous_vintage_id="2026-10-23", u=u)
        print(f"data/live vs 2026-10-23: {len(v2)} cells compared, {int((v2['status'] == 'hold').sum())} held")


@pytest.mark.skipif(not (DATA / "live" / "vintages" / "2026-10-23" / "raw_weo.csv").exists(), reason="no real vintage")
def test_quality_gate_runs_gate_v2(tmp_path):
    """EQ-A-0017 wiring: feeds.quality_gate merges the cross-source holds (and vintage holds when data_dir is given)."""
    from econquest.ingestion import load_universe
    from econquest.ingestion.feeds import diff_against_seed, quality_gate
    u = load_universe(DATA)
    rep = _real_report(DATA / "live" / "vintages" / "2026-10-23")
    review = quality_gate(u, rep, diff_against_seed(u, rep), year=2026)
    assert list(review.columns) == ["table", "key", "country", "seed", "live", "status", "reason"]
    zim = review[(review["country"] == "Zimbabwe") & (review["key"] == "reserves")]
    assert (zim["status"] == "hold").all() and zim["reason"].str.contains("cross: gdp_usd").all()
    assert len(vintage_checks(tmp_path, rep, u=u)) == 0                     # no previous vintage in an empty dir
    assert quality_gate(u, rep, diff_against_seed(u, rep), year=2026, data_dir=tmp_path).equals(review)
