"""Cache-key hashes in Team B code are marked non-security (bandit B324, SEC-C-004, EQ-B-0046)."""
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1] / "econquest"


def test_sha1_md5_calls_marked_usedforsecurity_false():
    bad = []
    for sub in ("engine", "validation", "scorecard"):
        for f in (ROOT / sub).glob("*.py"):
            for i, line in enumerate(f.read_text().splitlines(), 1):
                if re.search(r"hashlib\.(sha1|md5)\(", line) and "usedforsecurity=False" not in line:
                    bad.append(f"{f.name}:{i}")
    assert not bad, bad
