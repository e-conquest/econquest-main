"""`econquest attest` for hand-entered cells (HO-20261023-A-C-010 items 1-2)."""
import shutil
from pathlib import Path

import pytest

from econquest import cli
from econquest.ingestion import ledger_path, read_ledger
from econquest.ingestion.ledger import unattested_cells

ROOT = Path(__file__).resolve().parent.parent


@pytest.fixture
def data(tmp_path):
    d = tmp_path / "data"; d.mkdir()
    for f in ("adjustments.csv", "cds_quotes.csv", "prediction_markets.csv"):
        shutil.copy(ROOT / "data" / f, d / f)
    return d


def attest(d, *a):
    cli.main(["--data", str(d), "attest", *a])


def test_attest_four_eyes_then_list_shows_none(data, capsys):
    assert unattested_cells(data, ["prediction_markets"])
    attest(data, "--file", "prediction_markets", "--author", "alice", "--approver", "bob")
    assert "Attested" in capsys.readouterr().out
    assert unattested_cells(data, ["prediction_markets"]) == []
    attest(data, "--list", "--file", "prediction_markets")
    assert "All cells of prediction_markets are attested." in capsys.readouterr().out
    attest(data, "--list")                                  # other files still listed
    o = capsys.readouterr().out
    assert "unattested hand-entered cells" in o and "prediction_markets" not in o


def test_self_approval_without_flag_refused_and_writes_nothing(data):
    with pytest.raises(SystemExit) as e:
        attest(data, "--file", "prediction_markets", "--author", "alice", "--approver", "alice")
    assert e.value.code not in (0, None) and "four-eyes" in str(e.value)
    assert not ledger_path(data).exists() or len(read_ledger(data)) == 0


def test_self_approved_flag_and_rerun_writes_nothing_new(data, capsys):  # adjustments has rows; cds_quotes may be empty
    attest(data, "--file", "adjustments", "--author", "sam", "--self-approved")
    n = len(read_ledger(data))
    led = read_ledger(data)
    assert n and set(led["self_approved"]) == {"yes"}
    attest(data, "--file", "adjustments", "--author", "sam", "--self-approved")
    assert len(read_ledger(data)) == n and "Attested 0 cells" in capsys.readouterr().out.splitlines()[-1]


def test_missing_args_and_bad_file(data):
    with pytest.raises(SystemExit, match="--file and --author"):
        attest(data, "--file", "adjustments")
    with pytest.raises(SystemExit):
        attest(data, "--file", "countries", "--author", "a", "--approver", "b")     # argparse choices
