"""Independent replication script (EQ-B-0051): tolerance rules, quick-mode run, outputs and independence."""
from pathlib import Path

import pandas as pd
import pytest

from econquest.validation import replicate as R

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"


def test_decimals_and_tolerance_follow_reported_precision():
    assert R.decimals(74.35) == 2 and R.decimals("74.70") == 2 and R.decimals("0.0320") == 4 and R.decimals(131072) == 0
    assert R.full_tolerance(131072) == 0.5                       # counts compare exactly
    assert R.full_tolerance("0.0320") == pytest.approx(5e-5)
    assert R.full_tolerance(155.5) == pytest.approx(0.1555)      # 0.1 percent platform allowance beats half a unit


def test_compare_statuses():
    assert R.compare(R.Check("x", "g", "s", "q", 74.35), 74.351).status == "PASS"
    assert R.compare(R.Check("x", "g", "s", "q", 74.35), 75.0).status == "FAIL"
    c = R.compare(R.Check("x", "g", "s", "q", 66.07), 63.98, None, "predates GOV-001", 63.98)
    assert c.status == "STALE" and "predates GOV-001" in c.note and "drift band" in c.note
    assert R.compare(R.Check("x", "g", "s", "q", "Yellow"), "Yellow").status == "PASS"
    assert R.compare(R.Check("x", "g", "s", "q", "Fail"), "Pass").status == "FAIL"
    assert R.compare(R.Check("x", "g", "s", "q", 1.0), float("nan")).status == "FAIL"


def test_quick_tolerance_only_below_stated_paths():
    quick = R.Ctx(data=DATA, quick=True)
    full = R.Ctx(data=DATA, quick=False)
    assert R.mc_tol(full, "var99_mm", 74.35, 100_000) is None
    assert R.mc_tol(quick, "var99_mm", 74.35, 20_000) is None    # stated at the quick count: exact
    assert R.mc_tol(quick, "var99_mm", 74.35, 100_000) == pytest.approx(0.03 * 74.35)
    assert R.mc_tol(quick, "expected_loss_mm", 0.45, 100_000) == pytest.approx(0.15)


def test_unknown_group_refused(tmp_path):
    with pytest.raises(ValueError):
        R.replicate(DATA, tmp_path, quick=True, groups=["nope"])


def test_quick_replication_reproduces_release_and_validation_numbers(tmp_path):
    res = R.replicate(DATA, tmp_path / "rep", quick=True, groups=["release", "backtest", "hazard", "scorecard"], log=lambda *_: None)
    by_id = {c.id: c for c in res["checks"]}
    for cid in ("R01", "R02", "R03", "R04", "R09", "R11", "R25", "R29", "B03", "B11", "H06", "S01", "S04"):
        assert by_id[cid].status == "PASS", (cid, by_id[cid])
    assert res["counts"].get("FAIL", 0) == 0, [c for c in res["checks"] if c.status == "FAIL"]
    df = pd.read_csv(res["csv"])
    assert list(df.columns) == ["id", "group", "status", "quantity", "reported", "recomputed", "tolerance", "source", "note"]
    assert df["id"].is_unique and len(df) == len(res["checks"])
    md = Path(res["md"]).read_text()
    assert "Mode: quick" in md and "| R01 | PASS |" in md


def test_cli_writes_table_and_returns_zero(tmp_path, capsys):
    rc = R.main(["--data", str(DATA), "--out", str(tmp_path), "--quick", "--only", "backtest"])
    assert rc == 0
    assert (tmp_path / "replication.csv").exists() and (tmp_path / "replication.md").exists()
    assert "PASS 15" in capsys.readouterr().out


def test_replication_reads_no_archived_results():
    """Independence: the script recomputes; it must not open the run archive or result files."""
    src = Path(R.__file__).read_text()
    for forbidden in ("run_latest", "stress.json", "outputs/store", "econquest.sqlite", "Store(", "_paths.npz", "backtest.json"):
        assert forbidden not in src, forbidden


def test_stale_check_fails_outside_its_drift_band():
    """EQ-B-0054 (PI-4 review Low): a STALE item that regresses is a FAIL, and a stale reason needs a band."""
    assert R.compare(R.Check("x", "g", "s", "q", 66.07), 64.00, None, "old", 63.98).status == "STALE"   # within 0.064
    c = R.compare(R.Check("x", "g", "s", "q", 66.07), 65.00, None, "old", 63.98)
    assert c.status == "FAIL" and "beyond drift band" in c.note
    assert R.compare(R.Check("x", "g", "s", "q", 66.07), 63.98, None, "old").status == "FAIL"           # no band given
    assert R.compare(R.Check("x", "g", "s", "q", 66.07), 66.07, None, "old", 63.98).status == "PASS"


def test_summary_line_lists_stale_ids(tmp_path):
    checks = [R.compare(R.Check("D10.1", "docs", "s", "q", 66.07), 63.98, None, "old", 63.98),
              R.compare(R.Check("R01", "release", "s", "q", 74.35), 74.351)]
    res = R.write_outputs(checks, tmp_path, {"quick": True, "data": "data", "groups": ["docs"], "seconds": 0.0, "python": "3"})
    assert res["stale"] == ["D10.1"]
    line = R.summary_line(res)
    assert "STALE D10.1" in line and "PASS 1" in line
    assert "- STALE checks: D10.1" in res["md"].read_text()


def test_no_doc_check_is_left_stale_without_a_band():
    """VF-002 (EQ-B-0054): the refreshed doc checks reproduce; any stale entry must carry current values."""
    for cid, _paths, _patches, metrics, _src, stale in R.DOC_RUNS:
        if stale:
            reason, current = stale
            assert reason and set(metrics) <= set(current), cid



def test_replication_runs_on_the_frozen_release_prices():
    # prices.csv grows and is backfilled daily (INDA, 2026-10-23 22:24Z); replication must use the release's inputs
    from econquest.validation import replicate as R
    assert R.FROZEN_PRICES.is_file()
    ctx = R.Ctx(data=ROOT / "data" if "ROOT" in globals() else R.Path("data"), quick=True, log=lambda *_: None, prices=R.FROZEN_PRICES)
    u, _ = ctx.universe()
    assert u.prices.index.max() <= R.pd.Timestamp(R.PRICES_THROUGH)
    assert u.prices["INDA"].isna().sum() > 1000          # the release had no INDA history in prices.csv
