"""EQ-A-0012 / SEC-C-002 rows 2-4: no network. urlopen is monkeypatched and records each request."""
import io
import json

import pandas as pd
import pytest

from econquest.ingestion import feeds, sources


class _Resp(io.BytesIO):
    def __enter__(self):
        return self

    def __exit__(self, *a):
        return False


@pytest.fixture
def seen(monkeypatch):
    calls = []

    def fake_urlopen(req, timeout=None):
        calls.append(req)
        url = req.full_url
        if "sheets.googleapis.com" in url:
            body = {"values": [["a", "b"], ["1", "2"]]}
        elif "kalshi" in url:
            body = {"market": {"last_price": 40, "open_interest": 2000}}
        else:
            body = [{"outcomePrices": "[\"0.3\"]", "liquidity": 5000}]
        return _Resp(json.dumps(body).encode())

    # SEC-A-006 L1: every live request goes through sources.open_url_no_redirect (redirects refused, body capped)
    monkeypatch.setattr(sources, "open_url_no_redirect", fake_urlopen)
    monkeypatch.setattr(sources.urllib.request, "urlopen", lambda *a, **k: pytest.fail("plain urlopen used"))
    return calls


def test_polymarket_slug_is_quoted(seen):
    snap = pd.DataFrame({"slug": ["x&limit=999&slug=other"], "yes_price": [0.0], "open_interest_k": [0.0]})
    out = sources.PolymarketSource(snapshot=snap).fetch()
    assert len(seen) == 1
    url = seen[0].full_url
    assert url == "https://gamma-api.polymarket.com/markets?slug=x%26limit%3D999%26slug%3Dother"
    assert out.loc[0, "yes_price"] == pytest.approx(0.3)


def test_kalshi_ticker_cannot_traverse(seen):
    snap = pd.DataFrame({"ticker": ["../../admin?x=1"], "yes_price": [0.0], "open_interest_k": [0.0]})
    sources.KalshiSource(snapshot=snap).fetch()
    url = seen[0].full_url
    assert url == "https://api.elections.kalshi.com/trade-api/v2/markets/..%2F..%2Fadmin%3Fx%3D1"
    assert "/../" not in url and "?" not in url


def test_http_json_refuses_non_https(seen):
    assert sources._http_json("file:///etc/passwd") is None
    assert sources._http_json("http://gamma-api.polymarket.com/markets") is None
    assert seen == []
    snap = pd.DataFrame({"slug": ["s"], "yes_price": [0.1], "open_interest_k": [0.0]})
    out = sources.PolymarketSource(snapshot=snap, base="file:///etc/passwd").fetch()
    assert seen == [] and out.loc[0, "yes_price"] == 0.1          # falls back to the snapshot


@pytest.mark.parametrize("bad", ["../x", "abc/def", "id?key=1", "a b", "", "x" * 129, "abc#frag"])
def test_sheets_id_validated(seen, bad):
    with pytest.raises(ValueError):
        sources.GoogleSheetsSource(spreadsheet_id=bad, range_a1="Inputs!A1:B2", token="t").fetch()
    assert seen == []


def test_sheets_token_not_forwarded_on_redirect(seen):
    df = sources.GoogleSheetsSource(spreadsheet_id="AbC_1-2", range_a1="Inputs!A1:B2", token="secret").fetch()
    assert list(df.columns) == ["a", "b"]
    req = seen[0]
    assert req.full_url.startswith("https://sheets.googleapis.com/v4/spreadsheets/AbC_1-2/values/")
    assert "/" not in req.full_url.split("/values/", 1)[1]                # range is fully quoted
    assert req.unredirected_hdrs.get("Authorization") == "Bearer secret"
    assert "Authorization" not in req.headers                              # urllib copies only these on redirect


def test_bis_base_must_be_https(seen):
    with pytest.raises(ValueError):
        feeds.BisFeed(base="file:///etc")._get("WS_CBPOL", "D.US")
    assert seen == []


def test_sheets_and_http_json_refuse_redirects_and_cap(monkeypatch):
    """SEC-A-006 L1: sources' live requests never follow a redirect and read at most JSON_MAX_BYTES."""
    import email.message
    import urllib.request
    import urllib.response

    class Stub(urllib.request.BaseHandler):
        handler_order = 100

        def __init__(self, code, body=b"{}"):
            self.code, self.body, self.urls = code, body, []

        def https_open(self, req):
            self.urls.append(req.full_url)
            h = email.message.Message()
            h["Location"] = "http://evil.example/"
            r = urllib.response.addinfourl(io.BytesIO(self.body), h, req.full_url, self.code)
            r.msg = "stub"
            return r

    real = urllib.request.build_opener
    stub = Stub(302)
    monkeypatch.setattr(sources.urllib.request, "build_opener", lambda *h: real(*h, stub))
    with pytest.raises(sources.RedirectRefused, match="redirect from sheets.googleapis.com"):
        sources.GoogleSheetsSource(spreadsheet_id="AbC", range_a1="A1:B2", token="secret").fetch()
    assert sources._http_json("https://gamma-api.polymarket.com/markets") is None
    assert len(stub.urls) == 2
    stub.code, stub.body = 200, b"[" + b"1," * (sources.JSON_MAX_BYTES // 2) + b"1]"
    with pytest.raises(sources.ResponseTooLarge):
        sources.GoogleSheetsSource(spreadsheet_id="AbC", range_a1="A1:B2", token="secret").fetch()
    assert sources._http_json("https://gamma-api.polymarket.com/markets") is None
