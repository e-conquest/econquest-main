"""EQ-A-0041: validator data room (econquest.ingestion.dataroom and the standalone verify.py)."""
import ast
import csv
import datetime as dt
import hashlib
import json
import os
import subprocess
import sys
from pathlib import Path

import pytest

from econquest.ingestion import dataroom as dr
from econquest.ingestion.dataroom_verify import GENESIS, folder_content_hash

AS_OF = "2026-10-15"
BUILT = dt.datetime(2026, 11, 1, 8, 0, tzinfo=dt.timezone.utc)
SECRET = "hunter2-SuperSecretValue"
# Everything dated after the cutoff carries a 2026-10-2x date and nothing at or before it does, so a byte scan for
# b"2026-10-2" in the room is a generic point-in-time check.
LATE = b"2026-10-2"


def _w(p: Path, text: str) -> Path:
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(text)
    return p


def _csv(p: Path, header, rows) -> Path:
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "w", newline="") as f:
        w = csv.writer(f)
        w.writerow(header)
        w.writerows(rows)
    return p


def _sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def _vintage(root: Path, vid: str, files: dict) -> list:
    v = root / vid
    for name, text in files.items():
        _w(v / name, text)
    digest, n = folder_content_hash(v)
    return [vid, vid[:10] + "T00:00:00Z" if "T" not in vid else f"{vid[:10]}T{vid[11:13]}:{vid[13:15]}:{vid[15:17]}Z",
            digest, n]


def _chain(rows):
    out, prev = [], GENESIS
    for i, r in enumerate(rows, 1):
        r = {**r, "seq": i, "prev_hash": prev}
        body = json.dumps(r, sort_keys=True, separators=(",", ":"), ensure_ascii=False)
        r["row_hash"] = hashlib.sha256((prev + body).encode()).hexdigest()
        prev = r["row_hash"]
        out.append(json.dumps(r, sort_keys=True))
    return "\n".join(out) + "\n", prev


@pytest.fixture()
def data(tmp_path):
    d = tmp_path / "data"
    # live vintages: legacy date id, one before and one after the cutoff
    root = d / "live" / "vintages"
    rows = [_vintage(root, "2026-10-01", {"live_inputs.csv": "key,v\n1.1,3\n", "feeds.json": '{"retrieved": "2026-10-01"}'}),
            _vintage(root, "2026-10-10T120000Z-aaaaaaaa", {"live_inputs.csv": "key,v\n1.1,4\n", "raw_weo.csv": "iso,v\nVNM,1\n"}),
            _vintage(root, "2026-10-20T090000Z-bbbbbbbb", {"live_inputs.csv": "key,v\n1.1,5\n", "raw_weo.csv": "iso,v\nVNM,2\n"})]
    rows[0][1] = "2026-10-01"
    _csv(root / "index.csv", ["vintage_id", "retrieved_utc", "hash", "n_files"], rows)
    # applied working files + frozen replay inputs (replay.freeze_inputs) before and after the cutoff
    _w(d / "indicators.csv", "key,VNM\n1.1,4\n")
    _w(d / "countries.csv", "name,iso\nVietnam,VNM\n")
    from econquest.ingestion import replay
    replay.freeze_inputs(d, "2026-10-10T120000Z-aaaaaaaa", now=dt.datetime(2026, 10, 10, 13, tzinfo=dt.timezone.utc))
    _w(d / "indicators.csv", "key,VNM\n1.1,5\n")
    replay.freeze_inputs(d, "2026-10-20T090000Z-bbbbbbbb", now=dt.datetime(2026, 10, 20, 10, tzinfo=dt.timezone.utc))
    # panel vintages
    proot = d / "panel" / "vintages"
    prow = [_vintage(proot, "2026-10-05T000000Z-cccccccc", {"weo_history.csv": "iso,series,period,value,source,vintage\nVNM,x,2020,1,weo,2019-04\n"}),
            _vintage(proot, "2026-10-22T000000Z-dddddddd", {"weo_history.csv": "iso,series,period,value,source,vintage\nVNM,x,2020,2,weo,2026-10\n"})]
    _csv(proot / "index.csv", ["vintage_id", "created_utc", "hash", "n_files", "label", "files"],
         [r[:1] + [r[1]] + r[2:] + ["", "weo_history.csv"] for r in prow])
    _w(d / "panel" / "hazard_panel.csv", "iso,year,y\nVNM,2020,0\n")
    # market snapshots (licence tag must survive) and cds_snapshots rows
    mroot = d / "live" / "market" / "snapshots"
    mrows = []
    for sid, day, v in (("2026-10-11T080000Z-eeeeeeee", "2026-10-11", "120"), ("2026-10-21T080000Z-ffffffff", "2026-10-21", "130")):
        q = f"asof,instrument,iso,value,licence,snapshot_id\n{day},cds,VNM,{v},vendor-x-desk-licence,{sid}\n"
        _w(mroot / sid / "quotes.csv", q)
        _w(mroot / sid / "manifest.json", json.dumps({"snapshot_id": sid, "sha256": _sha(q.encode()), "licences": ["vendor-x-desk-licence"]}))
        mrows.append([sid, f"{day}T08:00:00Z", _sha(q.encode())])
    _csv(mroot / "index.csv", ["snapshot_id", "saved_utc", "sha256"], mrows)
    _csv(d / "market" / "cds_snapshots.csv", ["snapshot_id", "as_of", "iso3", "value", "licence"],
         [["2026-10-11T080000Z-eeeeeeee", "2026-10-11", "VNM", "120", "vendor-x-desk-licence"],
          ["2026-10-21T080000Z-ffffffff", "2026-10-21", "VNM", "130", "vendor-x-desk-licence"]])
    _csv(d / "live" / "market" / "manual_quotes.csv", ["asof", "value", "author", "approver", "self_approved", "entered_utc"],
         [["2026-10-12", "1", "alice", "bob", "no", "2026-10-12T10:00:00Z"],
          ["2026-10-23", "2", "alice", "alice", "yes", "2026-10-23T10:00:00Z"]])
    # event vintages and export archives
    eroot = d / "live" / "events" / "gdelt" / "vintages"
    erows = []
    for vid, day in (("2026-10-09T060000Z-11111111", "2026-10-09"), ("2026-10-24T060000Z-22222222", "2026-10-24")):
        body = f"iso,period,metric,value,retrieved_utc,vintage_id\nVNM,{day},events_total,3,{day}T06:00:00Z,{vid}\n"
        _w(eroot / vid / "events.csv", body)
        _w(eroot / vid / "manifest.json", json.dumps({"vintage_id": vid, "sha256": _sha(body.encode()), "files": {"events.csv": _sha(body.encode())}}))
        erows.append([vid, f"{day}T06:00:00Z", _sha(body.encode()), 1, "CC-BY"])
    _csv(eroot / "index.csv", ["vintage_id", "retrieved_utc", "sha256", "rows", "licence"], erows)
    xroot = d / "live" / "events" / "exports"
    xrows = []
    for eid, day in (("2026-10-09T070000Z-33333333", "2026-10-09"), ("2026-10-24T070000Z-44444444", "2026-10-24")):
        lb, wb = f"iso,vintage\nVNM,{day}\n", f"iso3,week_start\nVNM,{day}\n"
        _w(xroot / eid / "events_long.csv", lb); _w(xroot / eid / "events_weekly.csv", wb)
        _w(xroot / eid / "manifest.json", json.dumps({"export_id": eid, "files": {"events_long.csv": {"sha256": _sha(lb.encode())},
                                                                                   "events_weekly.csv": {"sha256": _sha(wb.encode())}}}))
        xrows.append([eid, f"{day}T07:00:00Z", 1, _sha(lb.encode()), 1, _sha(wb.encode())])
    _csv(xroot / "index.csv", ["export_id", "created_utc", "long_rows", "long_sha256", "weekly_rows", "weekly_sha256"], xrows)
    _w(d / "live" / "events" / "events_long.csv", "iso,vintage\nVNM,2026-10-24\n")
    _w(d / "live" / "events_weekly.csv", "iso3,week_start\nVNM,2026-10-24\n")
    _w(d / "live" / "snapshots" / "2026-10-10T125900Z-pre-apply" / "indicators.csv", "key,VNM\n1.1,3\n")
    _w(d / "live" / "snapshots" / "2026-10-20T085900Z-pre-apply" / "forced_cells.csv", "table,key\nInputs,1.1\n")
    # review ledger: four-eyes, self-approved, attestation, and a later row
    _csv(d / "live" / "review_ledger.csv",
         ["ts_utc", "vintage_id", "table", "key", "country", "gate_status", "live", "decision", "author", "approver", "note",
          "self_approved", "content_sha256"],
         [["2026-10-10T12:30:00.000000Z", "2026-10-10T120000Z-aaaaaaaa", "Inputs", "1.1", "Vietnam", "held", "4", "apply", "alice", "bob", "", "", ""],
          ["2026-10-11T09:00:00.000000Z", "", "adjustments", "b|p", "Vietnam", "", "1", "apply", "alice", "alice", "attested hand-entered cell", "yes", "ab" * 32],
          ["2026-10-12T09:00:00.000000Z", "", "Inputs", "1.2", "Vietnam", "held", "2", "hold", "carol", "", "", "", ""],
          ["2026-10-20T09:30:00.000000Z", "2026-10-20T090000Z-bbbbbbbb", "Inputs", "1.1", "Vietnam", "held", "5", "apply", "alice", "bob", "", "", ""]])
    # change approvals: hash chain, head, proposals
    log, head = _chain([{"ts_utc": "2026-10-12T16:32:09.708657Z", "event": "propose", "id": "CHG-20261012T163209Z-aaaaaa"},
                        {"ts_utc": "2026-10-13T16:32:09.708657Z", "event": "approve", "id": "CHG-20261012T163209Z-aaaaaa"},
                        {"ts_utc": "2026-10-21T16:32:09.708657Z", "event": "propose", "id": "CHG-20261021T163209Z-bbbbbb"}])
    _w(d / "approvals" / "log.jsonl", log)
    _w(d / "approvals" / "head.json", json.dumps({"seq": 3, "row_hash": head}))
    _w(d / "approvals" / ".lock", "")
    _w(d / "approvals" / "proposals" / "CHG-20261012T163209Z-aaaaaa.json", '{"id": "CHG-20261012T163209Z-aaaaaa"}')
    _w(d / "approvals" / "proposals" / "CHG-20261021T163209Z-bbbbbb.json", '{"id": "CHG-20261021T163209Z-bbbbbb"}')
    # audit trail: dated before, dated after, undated seed row
    _csv(d / "audit_trail.csv", ["table", "key", "country", "value", "origin", "retrieved"],
         [["Inputs", "1.1", "Vietnam", "4", "live feed", "2026-10-10"],
          ["Inputs", "1.1", "Vietnam", "5", "live feed", "2026-10-21"],
          ["Inputs", "1.9", "Vietnam", "7", "seed estimate", ""]])
    # current pull, dated by feeds.json
    _w(d / "live" / "feeds.json", json.dumps({"feeds": {"weo": "ok"}, "retrieved": "2026-10-10"}))
    _csv(d / "live" / "transform_log.csv", ["iso", "series", "rule"], [["VNM", "x", "used 2025"]])
    _csv(d / "live" / "unserved.csv", ["table", "key", "feed", "reason"], [["Inputs", "1.1", "bis", "not reported"]])
    _csv(d / "live" / "feed_failures.csv", ["feed", "failure"], [["yahoo", "timeout"]])
    # secrets that must never leave data_dir
    _w(d / "vendor_licences.json", json.dumps({"bloomberg": {"licence_id": "BBG-1", "holder": "desk"}}))
    _w(d / "live" / "market" / "vendor_creds.json", json.dumps({"lseg": {"app_key": SECRET}}))
    _w(d / "live" / "api_token.txt", SECRET)
    _w(d / "live" / "notes.csv", f"note\npassword={SECRET}\n")
    _w(d / "live" / ".env", f"LSEG_APP_KEY={SECRET}\n")
    _w(d / "server.pem", "-----BEGIN RSA PRIVATE KEY-----\nabc\n")
    return d


def _build(data, tmp_path, name="room", as_of=AS_OF, **kw):
    out = tmp_path / name
    m = dr.build_data_room(data, as_of, out, now=kw.pop("now", BUILT), **kw)
    return out, m


def _room_files(out: Path) -> dict:
    return {p.relative_to(out).as_posix(): p.read_bytes() for p in out.rglob("*") if p.is_file()}


def _tree_state(d: Path) -> dict:
    return {p.relative_to(d).as_posix(): (p.read_bytes(), p.stat().st_mtime_ns, p.stat().st_mode)
            for p in d.rglob("*") if p.is_file()}


def test_point_in_time_cutoff(data, tmp_path):
    out, m = _build(data, tmp_path)
    files = _room_files(out)
    # nothing dated after the cutoff anywhere in the room, except the build section of MANIFEST.json
    for rel, body in files.items():
        if rel != "MANIFEST.json":
            assert LATE not in body, rel
    hashed = {k: v for k, v in m.items() if k != "build"}
    assert LATE not in json.dumps(hashed).encode()
    paths = set(files)
    assert "data/live/vintages/2026-10-01/live_inputs.csv" in paths                  # legacy date id
    assert "data/live/vintages/2026-10-10T120000Z-aaaaaaaa/raw_weo.csv" in paths
    assert "data/panel/vintages/2026-10-05T000000Z-cccccccc/weo_history.csv" in paths
    assert "data/live/market/snapshots/2026-10-11T080000Z-eeeeeeee/quotes.csv" in paths
    assert "data/live/events/gdelt/vintages/2026-10-09T060000Z-11111111/events.csv" in paths
    assert "data/live/events/exports/2026-10-09T070000Z-33333333/events_long.csv" in paths
    assert "data/live/snapshots/2026-10-10T120000Z-aaaaaaaa-inputs/indicators.csv" in paths
    assert "data/live/snapshots/2026-10-10T125900Z-pre-apply/indicators.csv" in paths
    assert "data/approvals/proposals/CHG-20261012T163209Z-aaaaaa.json" in paths
    assert {"data/live/transform_log.csv", "data/live/unserved.csv", "data/live/feed_failures.csv"} <= paths
    # row files: only rows at or before the cutoff; audit trail keeps the undated seed row
    ledger = list(csv.DictReader(open(out / "data/live/review_ledger.csv", newline="")))
    assert [r["ts_utc"][:10] for r in ledger] == ["2026-10-10", "2026-10-11", "2026-10-12"]
    audit = list(csv.DictReader(open(out / "data/audit_trail.csv", newline="")))
    assert [r["retrieved"] for r in audit] == ["2026-10-10", ""]
    idx = list(csv.DictReader(open(out / "data/live/vintages/index.csv", newline="")))
    assert [r["vintage_id"] for r in idx] == ["2026-10-01", "2026-10-10T120000Z-aaaaaaaa"]
    assert len(open(out / "data/approvals/log.jsonl").read().splitlines()) == 2
    assert not (out / "data/approvals/head.json").exists()
    # undated working copies stay out by default; the frozen copy is the point-in-time one
    assert "data/indicators.csv" not in paths
    assert (out / "data/live/snapshots/2026-10-10T120000Z-aaaaaaaa-inputs/indicators.csv").read_text() == "key,VNM\n1.1,4\n"
    # every entry names its as-of rule; integrity anchors all hold
    assert all(f["as_of_rule"] == dr.RULES[f["kind"]] for f in m["files"])
    assert not [c for c in m["checks"] if c["status"] == "failed"], m["checks"]
    assert {c["kind"] for c in m["checks"] if c["status"] == "ok"} >= {
        "live_vintage", "panel_vintage", "market_snapshot", "event_vintage", "event_export", "replay_snapshot", "approvals_chain"}
    assert dr.verify_data_room(out)["ok"]


def test_cutoff_with_a_time_and_dates():
    assert dr.cutoff_of("2026-10-15")[1] == dt.datetime(2026, 10, 15, 23, 59, 59, 999999, tzinfo=dt.timezone.utc)
    assert dr.id_ts("2026-10-10") == dt.datetime(2026, 10, 10, 23, 59, 59, 999999, tzinfo=dt.timezone.utc)
    assert dr.id_ts("2026-10-10T120000Z-aaaaaaaa-inputs-1") == dt.datetime(2026, 10, 10, 12, tzinfo=dt.timezone.utc)
    assert dr.id_ts("CHG-20261012T163209Z-aaaaaa") == dt.datetime(2026, 10, 12, 16, 32, 9, tzinfo=dt.timezone.utc)
    assert dr.parse_ts("2026-10-15T23:59:59.5Z") > dr.cutoff_of("2026-10-15T23:59:59Z")[1]
    assert dr.parse_ts("") is None and dr.parse_ts("garbage") is None
    with pytest.raises(ValueError):
        dr.cutoff_of("not a date")


def test_cutoff_inside_a_day(data, tmp_path):
    out, m = _build(data, tmp_path, as_of="2026-10-10T12:15:00Z")
    paths = set(_room_files(out))
    assert "data/live/vintages/2026-10-10T120000Z-aaaaaaaa/raw_weo.csv" in paths
    assert "data/live/vintages/2026-10-01/live_inputs.csv" in paths             # legacy id: end of 2026-10-01
    assert [p for p in paths if p.startswith("data/live/snapshots/")] == ["data/live/snapshots/index.csv"]
    assert len((out / "data/live/snapshots/index.csv").read_text().splitlines()) == 1   # frozen 13:00, pre-apply 12:59
    ledger = list(csv.DictReader(open(out / "data/live/review_ledger.csv", newline="")))
    assert ledger == []                                                          # first decision at 12:30
    assert "data/live/transform_log.csv" not in paths                           # feeds.json date = end of 2026-10-10
    assert m["as_of"] == "2026-10-10T12:15:00Z"


def test_secrets_excluded_and_licence_tags_kept(data, tmp_path):
    out, m = _build(data, tmp_path)
    for rel, body in _room_files(out).items():
        assert SECRET.encode() not in body, rel
        assert b"PRIVATE KEY" not in body, rel
    paths = set(_room_files(out))
    for s in ("vendor_licences.json", "live/market/vendor_creds.json", "live/api_token.txt", "live/notes.csv",
              "live/.env", "server.pem"):
        assert f"data/{s}" not in paths
    reasons = {e["source"]: e["reason"] for e in m["build"]["excluded"]}
    assert reasons["vendor_licences.json"].startswith("secret")
    assert reasons["live/market/vendor_creds.json"].startswith("secret")
    assert reasons["live/notes.csv"].startswith("secret")
    assert reasons["server.pem"].startswith("secret")
    q = (out / "data/live/market/snapshots/2026-10-11T080000Z-eeeeeeee/quotes.csv").read_text()
    assert "vendor-x-desk-licence" in q
    assert "vendor-x-desk-licence" in (out / "data/market/cds_snapshots.csv").read_text()


def test_secret_reason_unit():
    assert dr.secret_reason("vendor_licences.json", b"{}")
    assert dr.secret_reason("x/client_secret.json", b"{}")
    assert dr.secret_reason("a.json", b'{"a": [{"api_key": "x"}]}')
    assert dr.secret_reason("a.csv", b"token: ghp_" + b"a" * 36)
    assert dr.secret_reason("raw_bis.csv", b"iso,value,licence\nVNM,1,BIS terms\n") is None
    assert dr.secret_reason("manifest.json", b'{"author": "alice", "licences": ["x"], "content_hash": "ab"}') is None


def test_source_never_modified(data, tmp_path):
    before = _tree_state(data)
    _build(data, tmp_path)
    assert _tree_state(data) == before


def test_room_files_read_only(data, tmp_path):
    out, _ = _build(data, tmp_path)
    for p in out.rglob("*"):
        if p.is_file():
            assert not (p.stat().st_mode & 0o222), p


def test_verify_catches_tamper_missing_extra(data, tmp_path):
    out, m = _build(data, tmp_path)
    assert dr.verify_data_room(out)["ok"]
    t = out / "data/live/vintages/2026-10-10T120000Z-aaaaaaaa/raw_weo.csv"
    os.chmod(t, 0o644); t.write_text("iso,v\nVNM,999\n")
    rep = dr.verify_data_room(out)
    assert not rep["ok"]
    assert [c["path"] for c in rep["changed"]] == ["data/live/vintages/2026-10-10T120000Z-aaaaaaaa/raw_weo.csv"]
    assert any(a["status"] == "failed" and a["kind"] == "live_vintage" for a in rep["anchors"])
    (out / "data/audit_trail.csv").unlink()
    _w(out / "data/live/smuggled.csv", "x\n1\n")
    rep = dr.verify_data_room(out)
    assert rep["missing"] == ["data/audit_trail.csv"]
    assert rep["extra"] == ["data/live/smuggled.csv"]


def test_verify_catches_manifest_edits(data, tmp_path):
    out, m = _build(data, tmp_path)
    mp = out / "MANIFEST.json"
    os.chmod(mp, 0o644)
    doc = json.loads(mp.read_text())
    doc["as_of"] = "2026-10-30"                                    # claim a later as-of without re-hashing
    mp.write_text(json.dumps(doc))
    rep = dr.verify_data_room(out)
    assert not rep["ok"] and not rep["manifest_hash_ok"]
    doc["as_of"] = m["as_of"]
    doc["build"]["built_utc"] = "2030-01-01T00:00:00Z"            # build is outside the hash
    mp.write_text(json.dumps(doc))
    assert dr.verify_data_room(out)["ok"]
    doc["files"][0]["path"] = "../escape.csv"
    mp.write_text(json.dumps(doc))
    rep = dr.verify_data_room(out)
    assert not rep["ok"] and rep["unsafe"] == ["../escape.csv"]


def test_standalone_verify_py_isolated(data, tmp_path):
    out, _ = _build(data, tmp_path)
    src = (out / "verify.py").read_text()
    mods = set()
    for node in ast.walk(ast.parse(src)):
        if isinstance(node, ast.Import):
            mods |= {a.name.split(".")[0] for a in node.names}
        elif isinstance(node, ast.ImportFrom) and node.module:
            mods.add(node.module.split(".")[0])
    assert mods - {"__future__"} <= set(sys.stdlib_module_names), mods
    run = subprocess.run([sys.executable, "-I", "verify.py"], cwd=out, capture_output=True, text=True, timeout=120)
    assert run.returncode == 0, run.stdout + run.stderr
    assert "RESULT: VERIFIED" in run.stdout
    run = subprocess.run([sys.executable, "-I", str(out / "verify.py"), str(out), "--json"], cwd=tmp_path,
                         capture_output=True, text=True, timeout=120)
    assert run.returncode == 0 and json.loads(run.stdout)["ok"]
    t = out / "data/live/review_ledger.csv"
    os.chmod(t, 0o644); t.write_text(t.read_text().replace("bob", "bib"))
    run = subprocess.run([sys.executable, "-I", "verify.py"], cwd=out, capture_output=True, text=True, timeout=120)
    assert run.returncode == 1 and "RESULT: FAILED" in run.stdout and "data/live/review_ledger.csv" in run.stdout


def test_deterministic_and_stable_under_later_data(data, tmp_path):
    out1, m1 = _build(data, tmp_path, "r1")
    out2, m2 = _build(data, tmp_path, "r2", now=BUILT + dt.timedelta(hours=5))
    assert m1["manifest_sha256"] == m2["manifest_sha256"]
    assert m1["content_sha256"] == m2["content_sha256"]
    assert m1["build"]["built_utc"] != m2["build"]["built_utc"]
    f1, f2 = _room_files(out1), _room_files(out2)
    assert {k: v for k, v in f1.items() if k != "MANIFEST.json"} == {k: v for k, v in f2.items() if k != "MANIFEST.json"}
    # a new append-only record after the cutoff does not move the as-of room
    with open(data / "live" / "review_ledger.csv", "a", newline="") as f:
        csv.writer(f).writerow(["2026-10-25T09:00:00.000000Z", "", "Inputs", "1.3", "Vietnam", "", "1", "apply", "dan", "eve", "", "", ""])
    _, m3 = _build(data, tmp_path, "r3")
    assert m3["manifest_sha256"] == m1["manifest_sha256"]


def test_four_eyes_flags(data, tmp_path):
    out, _ = _build(data, tmp_path)
    rows = list(csv.DictReader(open(out / dr.DERIVED_FOUR_EYES, newline="")))
    assert [(r["author"], r["four_eyes"], r["attestation"]) for r in rows] == [
        ("alice", "yes", "no"), ("alice", "self-approved", "yes"), ("carol", "no approver", "no")]


def test_include_current_guard(data, tmp_path):
    with pytest.raises(ValueError, match="include_current refused"):
        _build(data, tmp_path, "c1", include_current=True)
    out, m = _build(data, tmp_path, "c2", as_of="2026-10-31", include_current=True)
    paths = set(_room_files(out))
    assert "data/indicators.csv" in paths and m["options"]["include_current"]
    assert {f["kind"] for f in m["files"] if f["path"] == "data/indicators.csv"} == {"current_working_copy"}
    assert "data/vendor_licences.json" not in paths


def test_refuses_bad_out_dir(data, tmp_path):
    with pytest.raises(ValueError, match="inside data_dir"):
        dr.build_data_room(data, AS_OF, data / "room")
    busy = tmp_path / "busy"; _w(busy / "x.txt", "x")
    with pytest.raises(FileExistsError):
        dr.build_data_room(data, AS_OF, busy)
    assert not (data / "room").exists()


def test_cli_build_and_verify(data, tmp_path, capsys):
    out = tmp_path / "cli-room"
    assert dr.main(["build", "--data", str(data), "--as-of", AS_OF, "--out", str(out), "--json"]) == 0
    s = json.loads(capsys.readouterr().out)
    assert s["files"] == json.loads((out / "MANIFEST.json").read_text())["totals"]["files"]
    assert dr.main(["verify", str(out)]) == 0
    assert "RESULT: VERIFIED" in capsys.readouterr().out
    assert dr.main(["build", "--data", str(data), "--as-of", AS_OF, "--out", str(out)]) == 2


def test_default_out_is_outputs_dataroom_as_of(data, tmp_path, monkeypatch, capsys):
    """HO-20261024-A-C-001 / EQ-C-0060: `build` without --out writes <ECONQUEST_HOME>/outputs/dataroom/<as_of>/."""
    home = tmp_path / "home"
    monkeypatch.setenv("ECONQUEST_HOME", str(home))
    assert dr.default_room_dir(AS_OF) == home / "outputs" / "dataroom" / AS_OF
    assert dr.default_room_dir("2026-10-15T12:00:00Z", tmp_path / "o") == tmp_path / "o" / "dataroom" / "2026-10-15T120000Z"
    assert dr.main(["build", "--data", str(data), "--as-of", AS_OF]) == 0
    room = home / "outputs" / "dataroom" / AS_OF
    assert (room / "MANIFEST.json").is_file() and dr.verify_data_room(room)["ok"]
    assert dr.main(["build", "--data", str(data), "--as-of", AS_OF, "--outputs", str(tmp_path / "o2")]) == 0
    assert (tmp_path / "o2" / "dataroom" / AS_OF / "MANIFEST.json").is_file()


# ---------------------------------------------------------------------------------------------------------- EQ-A-0044
YAHOO_VID = "2026-10-10T120000Z-aaaaaaaa"


def _add_yahoo(data: Path) -> None:
    """raw_yahoo.csv in a vintage (re-indexed so the source verifies, as the frozen 2026-10-23 vintage) and in the pull."""
    root = data / "live" / "vintages"
    _w(root / YAHOO_VID / "raw_yahoo.csv", "iso,series,period,value,source\nVNM,FX_USD,2026-10-09,25000,yfinance\n")
    digest, n = folder_content_hash(root / YAHOO_VID)
    rows = list(csv.reader(open(root / "index.csv", newline="")))
    rows = [r if r[0] != YAHOO_VID else [r[0], r[1], digest, str(n)] for r in rows]
    _csv(root / "index.csv", rows[0], rows[1:])
    _w(data / "live" / "raw_yahoo.csv", "iso,series,period,value,source\nVNM,FX_USD,2026-10-09,25000,yfinance\n")


def _anchor(rep_or_m, path):
    checks = rep_or_m["anchors"] if "anchors" in rep_or_m else rep_or_m["checks"]
    return next(c for c in checks if c["path"] == path)


def test_yahoo_withheld_from_vintage_and_pull_and_room_verifies(data, tmp_path):
    _add_yahoo(data)
    before = _tree_state(data)
    out, m = _build(data, tmp_path)
    assert _tree_state(data) == before
    paths = set(_room_files(out))
    assert not [p for p in paths if p.endswith("raw_yahoo.csv")]
    assert f"data/live/vintages/{YAHOO_VID}/raw_weo.csv" in paths
    reasons = {e["source"]: e["reason"] for e in m["build"]["excluded"]}
    for src in (f"live/vintages/{YAHOO_VID}/raw_yahoo.csv", "live/raw_yahoo.csv"):
        assert reasons[src].startswith("licence: Yahoo Finance data")
    body = (data / "live" / "vintages" / YAHOO_VID / "raw_yahoo.csv").read_bytes()
    w = {x["path"]: x for x in m["withheld"]}
    assert w[f"data/live/vintages/{YAHOO_VID}/raw_yahoo.csv"]["sha256"] == _sha(body)
    assert "data/live/raw_yahoo.csv" in w                                    # current pull dated 2026-10-10
    # the vintage hash covers raw_yahoo.csv: the room reports the folder as altered, verified on the source at build
    a = _anchor(m, f"data/live/vintages/{YAHOO_VID}")
    assert a["status"] == "altered" and "raw_yahoo.csv (withheld)" in a["detail"]
    assert m["altered_anchors"][f"data/live/vintages/{YAHOO_VID}"]["verified_at_build"] == "ok"
    rep = dr.verify_data_room(out)
    assert rep["ok"] and rep["missing"] == [] and rep["withheld"] == sorted(w) and rep["anchor_warnings"] >= 1
    run = subprocess.run([sys.executable, "-I", "verify.py"], cwd=out, capture_output=True, text=True, timeout=120)
    assert run.returncode == 0 and "RESULT: VERIFIED" in run.stdout and "altered" in run.stdout
    assert "withheld because their licence" in (out / "README.md").read_text()
    # putting the withheld file back into the room is caught
    p = out / f"data/live/vintages/{YAHOO_VID}/raw_yahoo.csv"
    os.chmod(p.parent, 0o755); p.write_bytes(body)
    rep = dr.verify_data_room(out)
    assert not rep["ok"] and f"data/live/vintages/{YAHOO_VID}/raw_yahoo.csv" in rep["extra"]


def test_include_restricted_keeps_yahoo_and_full_anchor(data, tmp_path):
    _add_yahoo(data)
    out, m = _build(data, tmp_path, include_restricted=True)
    assert (out / f"data/live/vintages/{YAHOO_VID}/raw_yahoo.csv").is_file() and m["withheld"] == []
    assert m["options"]["include_restricted"] is True
    assert _anchor(m, f"data/live/vintages/{YAHOO_VID}")["status"] == "ok" and dr.verify_data_room(out)["ok"]


def test_altered_vintage_fails_when_source_did_not_verify(data, tmp_path):
    _add_yahoo(data)
    t = data / "live" / "vintages" / YAHOO_VID / "raw_yahoo.csv"
    t.write_text(t.read_text() + "VNM,FX_USD,2026-10-10,1,yfinance\n")      # source no longer matches its index row
    out, m = _build(data, tmp_path)
    assert m["altered_anchors"][f"data/live/vintages/{YAHOO_VID}"]["verified_at_build"].startswith("failed")
    assert _anchor(m, f"data/live/vintages/{YAHOO_VID}")["status"] == "failed"
    assert not dr.verify_data_room(out)["ok"]


def test_noncommercial_licence_csv_withheld_and_market_anchor_holds(data, tmp_path):
    sid = "2026-10-11T080000Z-eeeeeeee"
    q = data / "live" / "market" / "snapshots" / sid / "quotes.csv"
    body = f"asof,instrument,iso,value,licence,snapshot_id\n2026-10-11,fx,VNM,1,Yahoo personal non-commercial use,{sid}\n"
    _w(q, body)
    _w(q.parent / "manifest.json", json.dumps({"snapshot_id": sid, "sha256": _sha(body.encode()), "licences": ["x"]}))
    idx = q.parent.parent / "index.csv"
    rows = list(csv.reader(open(idx, newline="")))
    _csv(idx, rows[0], [r if r[0] != sid else [r[0], r[1], _sha(body.encode())] for r in rows[1:]])
    assert dr.restricted_reason("x/quotes.csv", body.encode()).startswith("licence: rows licensed 'non-commercial' (1)")
    assert dr.restricted_reason("x/quotes.csv", b"iso,licence\nVNM,BIS terms\n") is None
    assert dr.restricted_reason("x/index.csv", body.encode()) is None
    out, m = _build(data, tmp_path)
    assert not (out / f"data/live/market/snapshots/{sid}/quotes.csv").exists()
    assert {x["path"] for x in m["withheld"]} == {f"data/live/market/snapshots/{sid}/quotes.csv"}
    assert _anchor(m, f"data/live/market/snapshots/{sid}")["status"] == "ok"     # original sha256 against both anchors
    assert dr.verify_data_room(out)["ok"]


def test_email_addresses_redacted_at_source(data, tmp_path):
    """Coordinator for SEC-C-008 R6: addresses are replaced in the copies before hashing; the source is unchanged."""
    with open(data / "live" / "review_ledger.csv", "a", newline="") as f:
        csv.writer(f).writerow(["2026-10-12T10:00:00.000000Z", "", "Inputs", "1.3", "Vietnam", "", "1", "hold",
                                "sam.m.example@example.com", "", "ask ana.b@example.org or sam.m.example@example.com", "", ""])
    v = data / "live" / "vintages" / "2026-10-01"
    _w(v / "provenance.csv", "source,contact\nweo,data.desk@example.net\n")
    digest, n = folder_content_hash(v)
    idx = data / "live" / "vintages" / "index.csv"
    rows = list(csv.reader(open(idx, newline="")))
    _csv(idx, rows[0], [r if r[0] != "2026-10-01" else [r[0], r[1], digest, str(n)] for r in rows[1:]])
    before = _tree_state(data)
    src_prov = (v / "provenance.csv").read_bytes()
    out, m = _build(data, tmp_path)
    assert _tree_state(data) == before                                         # source untouched
    files = _room_files(out)
    for rel, body in files.items():
        assert not dr.EMAIL_RE.search(body.decode("utf-8", errors="ignore")), rel
    red = {r["path"]: r for r in m["redactions"]}
    assert red["data/live/review_ledger.csv"]["replacements"] == 3
    assert red[dr.DERIVED_FOUR_EYES]["replacements"] == 3                      # author column and two in the note
    prov = red["data/live/vintages/2026-10-01/provenance.csv"]
    assert prov["replacements"] == 1 and prov["original_sha256"] == _sha(src_prov) and prov["original_size"] == len(src_prov)
    assert files["data/live/vintages/2026-10-01/provenance.csv"] == b"source,contact\nweo,[redacted-email]\n"
    assert _anchor(m, "data/live/vintages/2026-10-01")["status"] == "altered"
    rep = dr.verify_data_room(out)
    assert rep["ok"] and set(rep["redacted"]) == set(red)
    run = subprocess.run([sys.executable, "-I", "verify.py"], cwd=out, capture_output=True, text=True, timeout=120)
    assert run.returncode == 0 and "RESULT: VERIFIED" in run.stdout
    assert "[redacted-email]" in (out / "README.md").read_text()
    # deterministic: a second build gives the same top hash
    _, m2 = _build(data, tmp_path, "room2")
    assert m2["manifest_sha256"] == m["manifest_sha256"]


def test_email_pattern_matches_the_evidence_bundle():
    """Same regex as Team C's evidence bundle, so the bundle finds nothing left to redact in the room."""
    from econquest.ops import evidence
    assert dr.EMAIL_RE.pattern == evidence.EMAIL_RE.pattern
    body, n = dr.redact_emails("a,b\nx@y.io,'z.w+q@sub.example.co.uk'\n".encode())
    # the local part allows an apostrophe (RFC 5322 atext), so the opening quote goes with the address, as in the bundle
    assert n == 2 and body == b"a,b\n[redacted-email],[redacted-email]'\n" and not evidence.EMAIL_RE.search(body.decode())
    assert dr.redact_emails(b"\xff\xfe@x.io") == (b"\xff\xfe@x.io", 0)


def test_limitations_register_generated_into_room(tmp_path):
    sys.path.insert(0, str(Path(__file__).resolve().parent))
    from test_limitations import _data as lim_data
    d = lim_data(tmp_path)
    out = tmp_path / "room"
    m = dr.build_data_room(d, "2026-10-23", out, now=BUILT)
    reg = (out / dr.LIMITATIONS_PATH).read_text()
    assert reg.startswith("# Data limitations register (GOV-010)")
    assert "(source: data/live; as of 2026-10-23)" in reg
    assert m["limitations"]["generated"] and m["limitations"]["live_source"] == "data/live"
    assert {f["kind"] for f in m["files"] if f["path"] == dr.LIMITATIONS_PATH} == {"limitations"}
    assert dr.verify_data_room(out)["ok"]
    m2 = dr.build_data_room(d, "2026-10-22", tmp_path / "room2", now=BUILT)       # no pull at or before: recorded
    assert not m2["limitations"]["generated"] and "no pull at or before 2026-10-22" in m2["limitations"]["reason"]
    assert str(tmp_path) not in json.dumps({k: v for k, v in m2.items() if k != "build"})
    m3 = dr.build_data_room(d, "2026-10-23", tmp_path / "room3", now=BUILT, limitations=False)
    assert not (tmp_path / "room3" / dr.LIMITATIONS_PATH).exists() and not m3["limitations"]["generated"]


def test_manifest_carries_no_absolute_path(data, tmp_path):
    """Coordinator for Team C: MANIFEST.json ships in the evidence bundle, so build.source_data_dir is the basename."""
    out, m = _build(data, tmp_path)
    text = (out / "MANIFEST.json").read_text()
    assert str(tmp_path) not in text and str(data.resolve()) not in text
    assert m["build"]["source_data_dir"] == "data"


# ------------------------------------------------------------------------------------------------ SEC-A-006 (EQ-A-0045)
YAHOO_FX = "-1.7709204225887447"            # SYNTHETIC stand-ins for Yahoo-derived values (fx3m, equity_vol)
YAHOO_VOL = "21.18129166258072"
OFFICIAL = "28.277471"


def _add_yahoo_derived(data: Path) -> None:
    """Yahoo-derived values in the YAHOO_VID vintage (re-indexed so the source verifies) and in the current pull:
    provenance.csv with a yfinance source, live_profile.csv and review.csv without one, audit_trail.csv rows."""
    prov = ("table,key,country,value,source,series,retrieved\n"
            f"Inputs,1.3,Vietnam,{OFFICIAL},imf-reader WEO latest,GGXWDG_NGDP,2026-10-10\n"
            f"Country Profile,fx3m,Vietnam,{YAHOO_FX},yfinance (Yahoo Finance),VND=X,2026-10-10\n"
            f"Country Profile,equity_vol,Vietnam,{YAHOO_VOL},yfinance (Yahoo Finance),VNM,2026-10-10\n")
    profile = f",pop,fx3m,equity_vol\nVietnam,101.598527,{YAHOO_FX},{YAHOO_VOL}\n"
    review = ("table,key,country,seed,live,status,reason,decision\n"
              f"Country Profile,fx3m,Vietnam,0.5,{YAHOO_FX},hold,change: 0.5 -> -1.771 (-454%),\n"
              f"Inputs,1.3,Vietnam,33.0,{OFFICIAL},ok,,\n")
    root = data / "live" / "vintages"
    for name, text in (("provenance.csv", prov), ("live_profile.csv", profile), ("review.csv", review)):
        _w(root / YAHOO_VID / name, text)
        _w(data / "live" / name, text)
    digest, n = folder_content_hash(root / YAHOO_VID)
    rows = list(csv.reader(open(root / "index.csv", newline="")))
    rows = [r if r[0] != YAHOO_VID else [r[0], r[1], digest, str(n)] for r in rows]
    _csv(root / "index.csv", rows[0], rows[1:])
    _csv(data / "audit_trail.csv", ["table", "key", "country", "value", "origin", "source", "retrieved", "gate_reason",
                                     "seed_value", "live_value"],
         [["Country Profile", "fx3m", "Vietnam", "-1.771", "live feed", "yfinance (Yahoo Finance)", "2026-10-10",
           "change: 0.5 -> -1.771 (-454%)", "0.5", YAHOO_FX],
          ["Inputs", "1.3", "Vietnam", OFFICIAL, "live feed", "imf-reader WEO latest", "2026-10-10", "", "33.0",
           OFFICIAL]])


def test_m2_yahoo_derived_values_blanked_and_room_verifies(data, tmp_path):
    _add_yahoo(data)
    _add_yahoo_derived(data)
    before = _tree_state(data)
    out, m = _build(data, tmp_path)
    assert _tree_state(data) == before                                      # data_dir never written
    blob = b"".join(_room_files(out).values())
    for v in (YAHOO_FX, YAHOO_VOL, "-1.771", "21.18"):
        assert v.encode() not in blob, v
    assert OFFICIAL.encode() in blob and b"yfinance (Yahoo Finance)" in blob    # official values and labels kept
    red = {r["path"]: r for r in m["redactions"]}
    for p in ("data/live/provenance.csv", "data/live/live_profile.csv", "data/live/review.csv", "data/audit_trail.csv",
              f"data/live/vintages/{YAHOO_VID}/provenance.csv", f"data/live/vintages/{YAHOO_VID}/live_profile.csv",
              f"data/live/vintages/{YAHOO_VID}/review.csv"):
        assert red[p]["restricted_cells"] >= 1 and red[p]["original_sha256"] == _sha((data / p[5:]).read_bytes()), p
    assert red["data/live/vintages/" + YAHOO_VID + "/provenance.csv"]["restricted_rows"] == 2
    assert red["data/live/live_profile.csv"]["restricted_cells"] == 2
    assert red["data/audit_trail.csv"]["restricted_cells"] == 3                 # value, gate_reason, live_value
    prov = list(csv.DictReader(open(out / "data/live/provenance.csv", newline="")))
    assert [r["value"] for r in prov] == [OFFICIAL, "", ""]
    a = _anchor(m, f"data/live/vintages/{YAHOO_VID}")
    assert a["status"] == "altered" and "provenance.csv (redacted)" in a["detail"]
    rep = dr.verify_data_room(out)
    assert rep["ok"] and "data/live/provenance.csv" in rep["redacted"]
    run = subprocess.run([sys.executable, "-I", "verify.py"], cwd=out, capture_output=True, text=True, timeout=120)
    assert run.returncode == 0 and "RESULT: VERIFIED" in run.stdout and "altered" in run.stdout
    assert "derived from Yahoo Finance data" in (out / "README.md").read_text()
    # include_restricted keeps the values (Sam's override) and the vintage verifies in full
    out2, m2 = _build(data, tmp_path, "room2", include_restricted=True)
    assert YAHOO_FX.encode() in b"".join(_room_files(out2).values()) and m2["redactions"] == []
    assert _anchor(m2, f"data/live/vintages/{YAHOO_VID}")["status"] == "ok"


def test_m2_restricted_rows_without_value_columns_withheld(data, tmp_path):
    _w(data / "live" / "odd.csv", "x,source\n1,yfinance (Yahoo Finance)\n")
    _w(data / "live" / "fine.csv", "x,source\n1,BIS\n")
    out, m = _build(data, tmp_path)
    w = {x["path"]: x["reason"] for x in m["withheld"]}
    assert w["data/live/odd.csv"].startswith("licence: rows from a restricted source")
    assert (out / "data/live/fine.csv").is_file() and dr.verify_data_room(out)["ok"]


def test_l4_secret_and_licence_patterns(data, tmp_path):
    _w(data / "live" / "pw.json", json.dumps({"user": "sam", "pass": "hunter2hunter2"}))
    _w(data / "live" / "pw2.json", json.dumps({"a": [{"PW": "x"}]}))
    _w(data / "live" / "bearer.csv", "k,v\nhdr,Authorization: Bearer abcdefghijklmnop1234\n")
    _w(data / "live" / "jwt.csv", "k,v\nt,eyJhbGciOiJIUzI1NiJ9.eyJzdWIiOiIxMjM0NTY3ODkwIn0.sig\n")
    _w(data / "live" / "RAW_YAHOO.csv", "iso,value\nVNM,1\n")
    _w(data / "live" / "yahoo_prices.csv", "iso,value\nVNM,1\n")
    _w(data / "live" / "mail.csv", "who\nsam%40example.com\nSAM%40Example.COM\n")
    (data / "live" / "mail16.csv").write_bytes("who\nalice@example.com\n".encode("utf-16"))
    (data / "live" / "nobom16.csv").write_bytes("who\nbob@example.com\n".encode("utf-16-le"))
    (data / "live" / "blob.csv").write_bytes(b"\x89PNG\r\n\x1a\n\xff\xfe\xfd")
    out, m = _build(data, tmp_path)
    reasons = {e["source"]: e["reason"] for e in m["build"]["excluded"]}
    for f in ("pw.json", "pw2.json", "bearer.csv", "jwt.csv"):
        assert reasons[f"live/{f}"].startswith("secret:"), f
    for f in ("RAW_YAHOO.csv", "yahoo_prices.csv"):
        assert reasons[f"live/{f}"].startswith("licence: Yahoo Finance data"), f
    for f in ("nobom16.csv", "blob.csv"):
        assert reasons[f"live/{f}"].startswith("unscannable:"), f
    w = {x["path"] for x in m["withheld"]}
    assert {"data/live/RAW_YAHOO.csv", "data/live/nobom16.csv", "data/live/blob.csv"} <= w
    room = _room_files(out)
    assert room["data/live/mail.csv"] == b"who\n[redacted-email]\n[redacted-email]\n"
    assert room["data/live/mail16.csv"].decode("utf-16") == "who\n[redacted-email]\n"
    assert room["data/live/mail16.csv"][:2] in (b"\xff\xfe", b"\xfe\xff")
    blob = b"".join(room.values())
    for needle in (b"hunter2", b"eyJhbGci", b"abcdefghijklmnop1234", b"%40example", b"%40Example"):
        assert needle not in blob
    assert "alice@example.com".encode("utf-16-le") not in blob
    assert dr.verify_data_room(out)["ok"]
    # plain text keeps Team C's EMAIL_RE behaviour
    assert dr.redact_emails(b"x@y.io") == (b"[redacted-email]", 1)


def _plain_room(data, tmp_path, name):
    out, _ = _build(data, tmp_path, name)
    for p in [out, *out.rglob("*")]:
        os.chmod(p, 0o755 if p.is_dir() else 0o644)
    return out


def _remanifest(out: Path, fn) -> None:
    from econquest.ingestion.dataroom_verify import content_hash, manifest_hash
    m = json.loads((out / "MANIFEST.json").read_text())
    fn(m)
    m["content_sha256"] = content_hash([e for e in m["files"] if isinstance(e, dict) and isinstance(e.get("path"), str)])
    m["manifest_sha256"] = manifest_hash(m)
    (out / "MANIFEST.json").write_text(json.dumps(m))


def test_l2_symlinks_in_room_are_unsafe_and_not_followed(data, tmp_path):
    out = _plain_room(data, tmp_path, "leaf")
    target = out / "data/live/feeds.json"
    outside = tmp_path / "outside.json"
    outside.write_bytes(target.read_bytes())                                 # same bytes: hashes would match
    target.unlink(); os.symlink(outside, target)
    rep = dr.verify_data_room(out)
    assert not rep["ok"] and "data/live/feeds.json (symlink, not followed)" in rep["unsafe"]
    assert rep["changed"] == [] and rep["missing"] == []
    out = _plain_room(data, tmp_path, "dirlink")
    (tmp_path / "outdir").mkdir(); _w(tmp_path / "outdir" / "x.csv", "OUTSIDE\n")
    os.symlink(tmp_path / "outdir", out / "data/live/vintages/2026-10-05T000000Z-deadbeef")
    rep = dr.verify_data_room(out)
    assert not rep["ok"] and "data/live/vintages/2026-10-05T000000Z-deadbeef (symlink, not followed)" in rep["unsafe"]
    assert not [a for a in rep["anchors"] if "deadbeef" in a["path"]]          # not content-hashed through the link
    run = subprocess.run([sys.executable, "-I", str(out / "verify.py")], capture_output=True, text=True, timeout=120)
    assert run.returncode == 1 and "RESULT: FAILED" in run.stdout and run.stderr == ""


def test_l3_hostile_manifests_fail_without_traceback(data, tmp_path, monkeypatch):
    from econquest.ingestion import dataroom_verify as dv
    cases = {
        "deep": lambda o: (o / "MANIFEST.json").write_text("[" * 200000 + "]" * 200000),
        "files-entry-types": lambda o: _remanifest(o, lambda m: m["files"].append({"path": "data/x", "size": "1",
                                                                                   "sha256": None})),
        "withheld-traversal": lambda o: _remanifest(o, lambda m: m["withheld"].append(
            {"path": "../../../etc/passwd", "size": 1, "sha256": "x", "reason": "r"})),
        "redactions-absolute": lambda o: _remanifest(o, lambda m: m["redactions"].append(
            {"path": "/etc/passwd", "original_sha256": "x"})),
        "withheld-not-list": lambda o: _remanifest(o, lambda m: m.__setitem__("withheld", "oops")),
        "anchors-not-dicts": lambda o: _remanifest(o, lambda m: m.__setitem__("altered_anchors", {"x": "y"})),
    }
    for name, tamper in cases.items():
        out = _plain_room(data, tmp_path, name)
        tamper(out)
        rep = dr.verify_data_room(out)
        run = subprocess.run([sys.executable, "-I", str(out / "verify.py")], capture_output=True, text=True, timeout=120)
        assert run.stderr == "", (name, run.stderr[-300:])                  # a report, never a traceback
        if name == "anchors-not-dicts":                                     # unused entry: harmless, still verifies
            assert rep["ok"] and run.returncode == 0
            continue
        assert not rep["ok"], name
        assert run.returncode == 1 and "RESULT: FAILED" in run.stdout, name
    # a replay snapshot manifest whose files is a list: a failed anchor, not an AttributeError
    out = _plain_room(data, tmp_path, "replay-list")
    s = out / "data/live/snapshots/2026-10-05-inputs"; s.mkdir(parents=True)
    _w(s / "manifest.json", json.dumps({"files": ["a", "b"]}))
    rep = dr.verify_data_room(out)
    a = next(x for x in rep["anchors"] if x["path"] == "data/live/snapshots/2026-10-05-inputs")
    assert a["status"] == "failed" and "malformed manifest.json" in a["detail"] and not rep["ok"]
    # MANIFEST.json over the cap is refused before it is read
    out = _plain_room(data, tmp_path, "big")
    monkeypatch.setattr(dv, "MAX_MANIFEST_BYTES", 100)
    rep = dr.verify_data_room(out)
    assert not rep["ok"] and "over the 100-byte cap" in rep["error"]


def test_l3_folder_hash_streams_and_matches_whole_file_hash(tmp_path):
    v = tmp_path / "v"
    _w(v / "a.csv", "x\n" * 300000); _w(v / "b.csv", "y\n")
    h = hashlib.sha256()
    for name in ("a.csv", "b.csv"):
        h.update(name.encode() + b"\0" + (v / name).read_bytes() + b"\0")
    assert folder_content_hash(v) == (h.hexdigest(), 2)
    from econquest.ingestion.feeds import _content_hash
    assert _content_hash({n: (v / n).read_bytes() for n in ("a.csv", "b.csv")}) == h.hexdigest()
