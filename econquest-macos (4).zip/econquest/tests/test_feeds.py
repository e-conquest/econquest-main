"""Offline tests for the live-feed transforms (no network). Run: python tests/test_feeds.py"""
import sys, tempfile
from pathlib import Path
import numpy as np
import pandas as pd
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.ingestion import load_universe
from econquest.ingestion.feeds import (_long, weo_transforms, _robust_latest, RG_CAP, wb_transforms, bis_transforms, yahoo_transforms,
                                      FetchReport, diff_against_seed, save_report, apply_report)

DATA = ROOT / "data"


def _weo_long():
    rows = []
    for y in range(2010, 2028):
        rows += [{"iso": "VNM", "series": "GGXWDG_NGDP", "period": y, "value": 30 + (y - 2010)},
                 {"iso": "VNM", "series": "NGDP", "period": y, "value": 1000 * 1.08 ** (y - 2010)},
                 {"iso": "VNM", "series": "NGDP_RPCH", "period": y, "value": 6.0 + (0.5 if y % 2 else -0.5) + (-3 if y == 2020 else 0)},
                 {"iso": "VNM", "series": "PCPIPCH", "period": y, "value": 3.0},
                 {"iso": "VNM", "series": "BCA_NGDPD", "period": y, "value": 2.0},
                 {"iso": "VNM", "series": "NGDPDPC", "period": y, "value": 4000.0},
                 {"iso": "VNM", "series": "GGXONLB_NGDP", "period": y, "value": -1.0},
                 {"iso": "VNM", "series": "GGXCNL_NGDP", "period": y, "value": -3.0}]
    return _long(rows, "test")


def test_weo_transforms():
    out = weo_transforms(_weo_long(), "VNM", 2026)
    assert out["1.3"] == 46.0 and out["1.7"] == 5.0 and out["2.8"] == 2.0 and out["5.5"] == 3.0
    assert out["5.6"] == 6.5                                   # next-year growth (2027 is odd -> +0.5)
    # 5.12: SD of growth over 15y excluding 2020-21 -> alternating +-0.5 -> about 0.5
    assert abs(out["5.12"] - 0.5) < 0.05
    # 1.6: pb=-1, interest=2, d(t-1)=45 -> r=0.0444; g=0.08; pb*=(0.0444-0.08)/1.08*45=-1.48 -> gap=0.48
    assert abs(out["1.6"] - 0.4815) < 0.01
    assert weo_transforms(_weo_long(), "PHL", 2026) == {}


def test_robust_latest_falls_back_on_implausible_jump():
    rows = [{"iso": "KOR", "series": "BCA_NGDPD", "period": y, "value": 4.0 + 0.5 * ((-1) ** y)} for y in range(2010, 2026)]
    rows.append({"iso": "KOR", "series": "BCA_NGDPD", "period": 2026, "value": 18.8})
    log = []
    assert _robust_latest(_long(rows, "t"), "KOR", "BCA_NGDPD", 2026, log=log) == rows[-2]["value"]
    assert len(log) == 1 and log[0]["rule"].startswith("|change| > 3 SD")
    # a normal move is kept, and a short history is never overridden
    rows[-1]["value"] = 5.0
    assert _robust_latest(_long(rows, "t"), "KOR", "BCA_NGDPD", 2026) == 5.0
    assert _robust_latest(_long(rows[-4:], "t"), "KOR", "BCA_NGDPD", 2026) == 5.0


def test_primary_balance_gap_caps_r_minus_g():
    # Argentina-like: nominal GDP +40% a year, interest 1.2% of GDP, debt 70% -> r - g = -0.38, capped at -0.10
    rows = []
    for y in range(2010, 2028):
        rows += [{"iso": "ARG", "series": "GGXWDG_NGDP", "period": y, "value": 70.0},
                 {"iso": "ARG", "series": "NGDP", "period": y, "value": 1000 * 1.4 ** (y - 2010)},
                 {"iso": "ARG", "series": "GGXONLB_NGDP", "period": y, "value": 1.6},
                 {"iso": "ARG", "series": "GGXCNL_NGDP", "period": y, "value": 0.4}]
    log = []
    out = weo_transforms(_long(rows, "t"), "ARG", 2026, log=log)
    gn = 0.4
    expected = 1.6 - (-RG_CAP) / (1 + gn) * 70.0
    assert abs(out["1.6"] - expected) < 1e-9
    assert any("capped" in e["rule"] for e in log)


def test_wb_transforms():
    rows = [{"iso": "PHL", "series": "SP.POP.TOTL", "period": 2023, "value": 117e6},
            {"iso": "PHL", "series": "NE.EXP.GNFS.ZS", "period": 2023, "value": 26.5},
            {"iso": "PHL", "series": "FI.RES.TOTL.CD", "period": 2023, "value": 100e9},
            {"iso": "PHL", "series": "NY.GDP.MKTP.CD", "period": 2023, "value": 400e9},
            {"iso": "PHL", "series": "DT.DOD.DSTC.IR.ZS", "period": 2022, "value": 15.0},
            {"iso": "PHL", "series": "DT.DOD.DSTC.IR.ZS", "period": 2021, "value": 99.0}]
    for s, a, b in (("RL.PER.RNK", 30, 35), ("CC.PER.RNK", 30, 32), ("RQ.PER.RNK", 50, 50)):
        rows += [{"iso": "PHL", "series": s, "period": 2020, "value": a}, {"iso": "PHL", "series": s, "period": 2023, "value": b}]
    ind, prof = wb_transforms(_long(rows, "test"), "PHL")
    assert ind["2.9"] == 15.0 and "2.10" not in ind
    assert abs(ind["3.5"] - 39.0) < 1e-9 and abs(ind["3.4"] - 2.333333) < 1e-5
    assert abs(prof["pop"] - 117.0) < 1e-9 and prof["exports"] == 26.5 and abs(prof["reserves"] - 25.0) < 1e-9


def test_bis_and_yahoo_transforms():
    rows = [{"iso": "BRA", "series": "EER_REAL_BROAD", "period": f"{2016 + i // 12}-{i % 12 + 1:02d}", "value": 100.0} for i in range(120)]
    rows[-1]["value"] = 110.0
    rows += [{"iso": "BRA", "series": "CREDIT_GAP", "period": "2026-Q2", "value": -4.2},
             {"iso": "BRA", "series": "POLICY_RATE", "period": "2026-10-20", "value": 15.0}]
    ind, prof = bis_transforms(_long(rows, "test"), "BRA", cpi=4.5)
    assert abs(ind["2.12"] - (110 / ((119 * 100 + 110) / 120) * 100 - 100)) < 1e-9
    assert ind["5.9"] == -4.2 and ind["5.13"] == 10.5 and prof["policy"] == 15.0

    days = pd.bdate_range("2025-10-01", "2026-10-20")
    fx = [{"iso": "BRA", "series": "FX_USD", "period": d.strftime("%Y-%m-%d"), "value": 5.0 + 0.5 * (d >= pd.Timestamp("2026-08-01"))} for d in days]
    rng = np.random.default_rng(0)
    etf = [{"iso": "BRA", "series": "ETF", "period": d.strftime("%Y-%m-%d"), "value": v} for d, v in zip(days, 30 * np.exp(np.cumsum(rng.normal(0, 0.01, len(days)))))]
    out = yahoo_transforms(_long(fx + etf, "test"), "BRA")
    assert abs(out["fx3m"] - 10.0) < 1e-9                       # BRL weakened 10% vs USD
    assert 10 < out["equity_vol"] < 22                          # 1% daily -> ~16% annualized


def test_diff_save_apply_roundtrip():
    u = load_universe(DATA)
    ind = pd.DataFrame(index=list(u.indicators["id"].astype(str)), columns=u.names, dtype=float)
    prof = pd.DataFrame(index=u.names, columns=["pop", "exports", "reserves", "fx3m", "policy", "equity_vol"], dtype=float)
    ind.at["1.3", "Vietnam"] = 36.5; prof.at["Vietnam", "pop"] = 101.3
    rep = FetchReport(indicators=ind, profile=prof, provenance=pd.DataFrame(columns=["table", "key", "country", "value", "source", "series", "retrieved"]),
                      feeds={"weo": "ok (1 rows)"}, raw={})
    diff = diff_against_seed(u, rep)
    assert len(diff) == 2 and set(diff["table"]) == {"Inputs", "Country Profile"}
    with tempfile.TemporaryDirectory() as td:
        d = Path(td); (d / "indicators.csv").write_bytes((DATA / "indicators.csv").read_bytes()); (d / "countries.csv").write_bytes((DATA / "countries.csv").read_bytes())
        save_report(rep, d, diff)
        assert (d / "live" / "live_inputs.csv").exists() and (d / "live" / "feeds.json").exists()
        counts = apply_report(rep, d)
        new = pd.read_csv(d / "indicators.csv", dtype={"id": str}).set_index("id")
        assert float(new.at["1.3", "Vietnam"]) == 36.5
        assert float(pd.read_csv(d / "countries.csv").set_index("country").at["Vietnam", "pop"]) == 101.3
        assert counts["indicator_cells"] + counts["profile_cells"] >= 2


def test_verify_vintage_and_writable_apply():
    """SEC-A-001 lows: verify_vintage recomputes the vintage hash against index.csv; _atomic_csv writes 0o644 even when
    the old file was read-only."""
    import os, stat
    import pytest
    from econquest.ingestion.feeds import save_vintage, verify_vintage
    from econquest.ingestion.replay import VintageIntegrityError
    ind = pd.DataFrame({"Vietnam": [36.5]}, index=["1.3"]); prof = pd.DataFrame({"pop": [101.3]}, index=["Vietnam"])
    prof = prof.reindex(columns=["pop", "exports", "reserves", "fx3m", "policy", "equity_vol"])
    rep = FetchReport(ind, prof, pd.DataFrame(), {"weo": "ok (1 rows)"}, {})
    with tempfile.TemporaryDirectory() as td:
        d = Path(td)
        v = save_vintage(d, rep)
        assert verify_vintage(d, v.name)["n_files"] == len(list(v.iterdir()))
        assert (d / "live" / "vintages" / "index.csv").read_text().count("vintage_id,") == 1
        f = v / "live_inputs.csv"; os.chmod(f, 0o644); f.write_text("tampered\n")
        with pytest.raises(VintageIntegrityError):
            verify_vintage(d, v.name)
        for n in ("indicators.csv", "countries.csv"):
            (d / n).write_bytes((DATA / n).read_bytes()); os.chmod(d / n, 0o444)
        apply_report(rep, d)
        assert stat.S_IMODE((d / "indicators.csv").stat().st_mode) == 0o644


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn(); print("ok", name)
