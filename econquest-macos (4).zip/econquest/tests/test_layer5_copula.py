"""Layer 5 copula: judgement default unchanged, t-copula likelihood, MLE recovery, `copula.source` (EQ-B-0036)."""
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest
from scipy import stats

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.config import Settings
from econquest.engine import layer5_copula as L5

DATA = ROOT / "data"


def _sim_tcopula(T=800, nu=5.0, seed=3):
    """Six countries in two regions with the layer-5 factor structure, t-distributed via a shared chi-square."""
    rng = np.random.default_rng(seed)
    g = np.array([0.10, 0.30, 0.50, 0.20, 0.40, 0.05]); r = np.array([0.15, 0.15, 0.15, 0.25, 0.25, 0.25])
    reg = np.array([0, 0, 0, 1, 1, 1])
    Zg = rng.standard_normal(T); Zr = rng.standard_normal((T, 2)); eps = rng.standard_normal((T, 6)); W = rng.chisquare(nu, T)
    X = (np.sqrt(g) * Zg[:, None] + np.sqrt(r) * Zr[:, reg] + np.sqrt(1 - g - r) * eps) / np.sqrt(W / nu)[:, None]
    names = [f"C{i}" for i in range(6)]
    idx = pd.date_range("2010-01-01", periods=T, freq="W-FRI")
    return pd.DataFrame(X, index=idx, columns=names), {n: ("R0" if k == 0 else "R1") for n, k in zip(names, reg)}, g, r


def test_t_copula_loglik_matches_scipy_density():
    X, regions, g, r = _sim_tcopula(T=50)
    U = L5.pseudo_obs(X.to_numpy())
    same = (np.array(list(regions.values()))[:, None] == np.array(list(regions.values()))[None, :]).astype(float)
    R = L5._structured_R(g, r, same)
    nu = 6.0
    x = stats.t.ppf(U, nu)
    ref = stats.multivariate_t(loc=np.zeros(6), shape=R, df=nu).logpdf(x).sum() - stats.t.logpdf(x, nu).sum()
    assert L5.t_copula_loglik(U, R, nu) == pytest.approx(ref, rel=1e-10)


def test_fit_t_copula_recovers_structure_and_nu():
    X, regions, g, r = _sim_tcopula()
    f = L5.fit_t_copula(X, regions)
    assert f.converged
    assert 3.0 < f.nu < 9.0, f.nu
    assert np.max(np.abs(f.global_loading.to_numpy() - g)) < 0.12, f.global_loading
    assert abs(f.regional_loading["R0"] - 0.15) < 0.12 and abs(f.regional_loading["R1"] - 0.25) < 0.12
    # profile likelihood prefers a fat tail over near-Gaussian on t data
    assert f.nu_profile[5.0] > f.nu_profile[60.0]


def test_judgement_default_is_unchanged_and_source_validated():
    shipped = Settings.load(DATA / "assumptions.json")
    # Sam approved estimated loadings with judgement nu (CHG-20261023T190523Z-b96d25); without the key the code
    # default is still judgement
    assert L5.copula_source(shipped) == "estimated" and L5.nu_source(shipped) == "judgement"
    s = shipped.copy_with(copula={})
    assert L5.copula_source(s) == "judgement"
    names = ["A", "B", "C"]
    u = SimpleNamespace(names=names, countries=pd.DataFrame({"country": names, "region": ["Asia", "Asia", "LatAm"]}), prices=None)
    regime = pd.Series(["Calm", "Stressed", "Crisis"], index=names)
    for gstate in ("Calm", "Stressed"):
        a = L5.factor_loadings(u, s, regime, gstate)
        b = L5.factor_loadings(u, s.copy_with(**{"copula.source": "judgement"}), regime, gstate)
        assert a.equals(b)
        assert L5.degrees_of_freedom(s, gstate) == (s["monte_carlo"]["df_stressed"] if gstate == "Stressed" else s["monte_carlo"]["df_calm"])
    assert a.loc["A", "global"] == s["regime"]["Calm"]["global_loading"] * s["monte_carlo"]["global_loading_mult"]
    with pytest.raises(ValueError, match="copula.source"):
        L5.copula_source(s.copy_with(**{"copula.source": "fitted"}))
    est = s.copy_with(**{"copula.source": "estimated", "copula.nu_source": "estimated"})
    with pytest.raises(ValueError, match="copula.nu_source"):
        L5.nu_source(s.copy_with(**{"copula.nu_source": "fitted"}))
    with pytest.raises(ValueError, match="needs the universe"):
        L5.degrees_of_freedom(est, "Calm")
    with pytest.raises(ValueError, match="market_history"):
        L5.estimated_copula(u)
    # a run without price history falls back to the judgement copula with a warning (fresh install, fixtures)
    with pytest.warns(RuntimeWarning, match="judgement copula"):
        assert L5.factor_loadings(u, est, regime, "Calm").equals(L5.factor_loadings(u, s, regime, "Calm"))


def test_estimated_source_on_market_history():
    from econquest.ingestion import load_universe
    u = load_universe(DATA)
    s = Settings.load(DATA / "assumptions.json").copy_with(**{"copula.source": "estimated"})
    fit = L5.estimated_copula(u)
    # GOV-034: countries with only an administered or pegged quote, or no series, keep the judgement loadings
    assert set(fit.left_out) == {"Pakistan", "Belize", "Venezuela", "Nigeria", "Senegal", "Zimbabwe"}
    assert "Africa" not in fit.regional_loading                   # only Zambia: not identified, judgement 0.1 kept
    assert fit.n_weeks >= L5.MIN_WEEKS and L5.NU_BOUNDS[0] <= fit.nu <= L5.NU_BOUNDS[1]
    regime = pd.Series("Calm", index=u.names); regime["Argentina"] = "Stressed"
    lo = L5.factor_loadings(u, s, regime, "Calm")
    assert lo.loc["Singapore", "global"] == pytest.approx(min(fit.global_loading["Singapore"], 1 - fit.regional_loading["Asia"] - 0.05))
    assert lo.loc["Argentina", "global"] == pytest.approx(fit.global_loading["Argentina"] + 0.10)       # judgement step-up kept
    assert lo.loc["Nigeria", "global"] == s["regime"]["Calm"]["global_loading"] and lo.loc["Nigeria", "regional"] == 0.1
    assert np.allclose(lo.sum(axis=1), 1.0) and (lo["idio"] >= 0.05 - 1e-12).all()
    # nu_source defaults to judgement: estimated loadings with the judgement nu
    assert L5.degrees_of_freedom(s, "Calm", u) == s["monte_carlo"]["df_calm"]
    assert L5.degrees_of_freedom(s, "Stressed") == s["monte_carlo"]["df_stressed"]
    s_nu = s.copy_with(**{"copula.nu_source": "estimated"})
    assert L5.degrees_of_freedom(s_nu, "Calm", u) == fit.nu
    assert L5.degrees_of_freedom(s_nu, "Stressed", u) == max(3.0, fit.nu - 1.0)
    assert L5.estimated_copula(u) is fit                          # cached: stress runs reuse the fit
