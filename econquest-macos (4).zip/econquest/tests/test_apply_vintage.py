"""EQ-A-0035: re-apply a saved vintage offline. A held cell is released only by an approved ledger decision bound to
that vintage (or its live value); the vintage is verified against vintages/index.csv first. No network: every vintage
here is built from a synthetic FetchReport (SYNTHETIC values, not real data)."""
import datetime as dt
import os
import shutil
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.ingestion.feeds import (FetchReport, VintageContentError, apply_vintage, load_vintage,  # noqa: E402
                                       record_vintage_decisions, save_vintage, vintage_review)
from econquest.ingestion.ledger import read_ledger, record_decision  # noqa: E402
from econquest.ingestion.replay import VintageIntegrityError  # noqa: E402

SEED = ROOT / "tests" / "seed_data"
CLOCK = dt.datetime(2026, 10, 23, 21, 30, 0, tzinfo=dt.timezone.utc)
FX = ("Country Profile", "fx3m", "Brazil")
OK = ("Inputs", "1.3", "Vietnam")


def _data(tmp_path: Path) -> Path:
    d = tmp_path / "data"
    shutil.copytree(SEED, d)
    return d


def _report(fx: float = 31.25) -> FetchReport:
    ind = pd.DataFrame({"Vietnam": [36.5, 41.0]}, index=["1.3", "2.10"])
    prof = pd.DataFrame(np.nan, index=["Vietnam", "Brazil"], columns=["pop", "exports", "reserves", "fx3m", "policy", "equity_vol"])
    prof.at["Brazil", "fx3m"] = fx
    prov = pd.DataFrame([{"table": "Country Profile", "key": "fx3m", "country": "Brazil", "value": fx, "source": "test",
                          "series": "BRL=X", "retrieved": "2026-10-23"}])
    raw = {"yahoo": pd.DataFrame([{"iso": "BRA", "series": "BRL=X", "period": "2026-10-23", "value": 5.6, "source": "test"}])}
    return FetchReport(ind, prof, prov, {"yahoo": "ok (1 rows)", "weo": "ok (2 rows)"}, raw)


def _review(fx: float = 31.25) -> pd.DataFrame:
    return pd.DataFrame([
        {"table": "Inputs", "key": "1.3", "country": "Vietnam", "seed": 33.0, "live": 36.5, "status": "ok", "reason": ""},
        {"table": "Inputs", "key": "2.10", "country": "Vietnam", "seed": 40.0, "live": 41.0, "status": "ok", "reason": ""},
        {"table": "Country Profile", "key": "fx3m", "country": "Brazil", "seed": 0.0, "live": fx, "status": "hold",
         "reason": f"change: 0 -> {fx:.4g}"},
        # write_review adds these at fetch time; load_vintage must ignore them (decisions come from the ledger)
    ]).assign(decision="", author="", approver="", self_approved="", decided_utc="")


def _vintage(d: Path, fx: float = 31.25, now=CLOCK) -> str:
    return save_vintage(d, _report(fx), _review(fx), now=now).name


def _fx(d: Path) -> str:
    return pd.read_csv(d / "countries.csv", dtype=str).set_index("country").at["Brazil", "fx3m"]


def _ind(d: Path, key: str) -> float:
    return float(pd.read_csv(d / "indicators.csv", dtype={"id": str}).set_index("id").at[key, "Vietnam"])


def _bytes(folder: Path) -> dict:
    return {p.name: p.read_bytes() for p in sorted(folder.iterdir())}


def test_load_vintage_roundtrips_string_ids_and_drops_stale_decisions(tmp_path):
    d = _data(tmp_path); vid = _vintage(d)
    got, rep, rev = load_vintage(d)
    assert got == vid
    assert list(rep.indicators.index) == ["1.3", "2.10"] and rep.indicators.at["2.10", "Vietnam"] == 41.0
    assert rep.profile.at["Brazil", "fx3m"] == 31.25 and rep.feeds["yahoo"].startswith("ok")
    assert "decision" not in rev.columns and rev["live"].dtype == float


def test_without_decision_held_cell_stays_on_seed(tmp_path):
    d = _data(tmp_path); vid = _vintage(d)
    v = d / "live" / "vintages" / vid; before = _bytes(v)
    out = apply_vintage(d)
    assert _fx(d) == "0.0" and _ind(d, "1.3") == 36.5 and _ind(d, "2.10") == 41.0
    assert out["vintage_id"] == vid == out["latest_vintage"]
    assert out["still_held"] == [FX] and out["released"] == [] and out["held_for_review"] == 1
    assert Path(out["snapshot"]).is_dir() and Path(out["inputs_snapshot"]).is_dir()
    assert _bytes(v) == before                                     # the vintage is only read


def test_self_approved_decision_bound_to_vintage_applies(tmp_path):
    d = _data(tmp_path); vid = _vintage(d)
    rows = record_vintage_decisions(d, [FX], author="Sam", self_approved=True, note="BRL moved; checked")
    assert len(rows) == 1
    led = read_ledger(d).iloc[-1]
    assert (led["vintage_id"], led["live"], led["gate_status"], led["decision"], led["approver"], led["self_approved"]) == \
        (vid, "31.25", "hold", "apply", "Sam", "yes")
    assert vintage_review(d).set_index(["table", "key", "country"]).at[FX, "effective"] == "released"
    out = apply_vintage(d)
    assert _fx(d) == "31.25" and out["released"] == [FX] and out["still_held"] == [] and out["held_for_review"] == 0


def test_four_eyes_enforced_before_anything_is_written(tmp_path):
    d = _data(tmp_path); _vintage(d)
    with pytest.raises(ValueError, match="four-eyes"):
        record_vintage_decisions(d, [OK, FX], author="Sam")
    with pytest.raises(ValueError, match="four-eyes"):
        record_vintage_decisions(d, [FX], author="Sam", approver=" sam ")
    assert read_ledger(d).empty
    record_vintage_decisions(d, [FX], author="Sam", approver="Ana")          # four-eyes approval
    led = read_ledger(d).iloc[-1]
    assert (led["approver"], led["self_approved"]) == ("Ana", "")
    apply_vintage(d)
    assert _fx(d) == "31.25"


def test_decision_bound_to_other_vintage_or_value_does_not_release(tmp_path):
    d = _data(tmp_path); vid = _vintage(d)
    record_decision(d, *FX, "apply", "Sam", self_approved=True, gate_status="hold", vintage_id="2026-10-01T000000Z-deadbeef")
    out = apply_vintage(d)
    assert _fx(d) == "0.0" and out["still_held"] == [FX]
    # this vintage's id, but a different live value: the value wins, so it does not bind (SEC-A-001 L1)
    record_decision(d, *FX, "apply", "Sam", self_approved=True, gate_status="hold", vintage_id=vid, live=30.0)
    apply_vintage(d)
    assert _fx(d) == "0.0"
    assert vintage_review(d).set_index(["table", "key", "country"]).at[FX, "effective"] == "held"


def test_refetch_scenario_decision_on_first_vintage_applies_that_vintage_only(tmp_path):
    """Sam's case: approve on vintage V1, a rerun saved V2 with a slightly different FX value."""
    d = _data(tmp_path)
    v1 = _vintage(d, 31.25)
    record_vintage_decisions(d, [FX], author="Sam", self_approved=True, vintage_id=v1)
    v2 = _vintage(d, 31.31, now=CLOCK + dt.timedelta(minutes=5))
    out = apply_vintage(d)                                     # latest = V2: the V1 decision does not bind
    assert out["vintage_id"] == v2 and _fx(d) == "0.0"
    out = apply_vintage(d, vintage_id=v1, allow_older=True)    # re-apply exactly what was approved (a rollback)
    assert out["vintage_id"] == v1 and out["latest_vintage"] == v2 and _fx(d) == "31.25"
    assert out["rollback"]["vintage_id"] == v1 and out["rollback"]["latest_vintage"] == v2


def test_apply_vintage_with_cells_records_and_applies_in_one_call(tmp_path):
    d = _data(tmp_path); vid = _vintage(d)
    with pytest.raises(ValueError, match="author"):
        apply_vintage(d, cells=[FX])
    out = apply_vintage(d, cells=[{"table": "Country Profile", "key": "fx3m", "country": "Brazil"}], author="Sam",
                        self_approved=True, note="one step")
    assert out["decisions_recorded"] == 1 and _fx(d) == "31.25"
    assert read_ledger(d).iloc[-1]["vintage_id"] == vid


def test_hold_decision_keeps_ok_cell_off(tmp_path):
    d = _data(tmp_path); _vintage(d)
    record_vintage_decisions(d, [OK], author="Sam", decision="hold", note="suspicious")
    apply_vintage(d)
    assert _ind(d, "1.3") == 33.0 and _ind(d, "2.10") == 41.0
    assert vintage_review(d).set_index(["table", "key", "country"]).at[OK, "effective"] == "held (decision)"


def test_unknown_cell_or_missing_vintage_records_nothing(tmp_path):
    d = _data(tmp_path)
    with pytest.raises(FileNotFoundError):
        apply_vintage(d)
    _vintage(d)
    with pytest.raises(VintageContentError):
        record_vintage_decisions(d, [FX, ("Country Profile", "fx3m", "Atlantis")], author="Sam", self_approved=True)
    with pytest.raises(FileNotFoundError):
        record_vintage_decisions(d, [FX], author="Sam", self_approved=True, vintage_id="2020-01-01")
    assert read_ledger(d).empty


def test_tampered_vintage_is_refused_and_nothing_written(tmp_path):
    d = _data(tmp_path); vid = _vintage(d)
    record_vintage_decisions(d, [FX], author="Sam", self_approved=True)
    f = d / "live" / "vintages" / vid / "live_profile.csv"
    os.chmod(f, 0o644); f.write_text(f.read_text().replace("31.25", "99.0")); os.chmod(f, 0o444)
    before = (d / "countries.csv").read_bytes()
    with pytest.raises(VintageIntegrityError):
        apply_vintage(d)
    with pytest.raises(VintageIntegrityError):
        record_vintage_decisions(d, [FX], author="Sam", self_approved=True)
    assert (d / "countries.csv").read_bytes() == before and not (d / "live" / "snapshots").exists()


def test_vintage_without_review_is_refused(tmp_path):
    d = _data(tmp_path)
    save_vintage(d, _report(), None, now=CLOCK)
    with pytest.raises(VintageContentError, match="review.csv"):
        apply_vintage(d)


# ---------------------------------------------------------------------------------------------- SEC-A-004 (EQ-A-0039)
def _index(d: Path) -> Path:
    return d / "live" / "vintages" / "index.csv"


def test_l1_tamper_plus_appended_index_row_is_refused(tmp_path):
    """SEC-A-004 L1 / probe V5: editing a vintage and appending an index row with the new hash must not pass."""
    from econquest.ingestion.feeds import _content_hash
    d = _data(tmp_path); vid = _vintage(d)
    v = d / "live" / "vintages" / vid
    f = v / "live_inputs.csv"
    os.chmod(f, 0o644); f.write_text(f.read_text().replace("41.0", "4100.0")); os.chmod(f, 0o444)
    with pytest.raises(VintageIntegrityError):
        load_vintage(d)
    files = {p.name: p.read_bytes() for p in v.iterdir() if p.is_file()}
    with open(_index(d), "a") as fh:
        fh.write(f"{vid},2026-10-23T21:30:00Z,{_content_hash(files)},{len(files)}\n")
    with pytest.raises(VintageIntegrityError, match="disagree"):
        load_vintage(d)
    before = (d / "indicators.csv").read_bytes()
    with pytest.raises(VintageIntegrityError):
        apply_vintage(d)
    assert (d / "indicators.csv").read_bytes() == before and read_ledger(d).empty


def test_l1_folder_hash8_must_match_content_even_with_rewritten_index(tmp_path):
    """The hash8 suffix of a new-style id is checked against the content, so rewriting the whole index is caught too."""
    from econquest.ingestion.feeds import _content_hash
    d = _data(tmp_path); vid = _vintage(d)
    v = d / "live" / "vintages" / vid
    f = v / "live_profile.csv"
    os.chmod(f, 0o644); f.write_text(f.read_text().replace("31.25", "99.0")); os.chmod(f, 0o444)
    files = {p.name: p.read_bytes() for p in v.iterdir() if p.is_file()}
    _index(d).write_text(f"vintage_id,retrieved_utc,hash,n_files\n{vid},2026-10-23T21:30:00Z,{_content_hash(files)},{len(files)}\n")
    with pytest.raises(VintageIntegrityError, match="hash8"):
        load_vintage(d)


def test_l1_duplicate_identical_index_rows_still_verify(tmp_path):
    d = _data(tmp_path); vid = _vintage(d)
    rows = _index(d).read_text().splitlines()
    with open(_index(d), "a") as fh:
        fh.write(rows[-1] + "\n")                                   # same hash, same count: consistent
    assert load_vintage(d)[0] == vid


def test_l2_older_vintage_refused_without_allow_older(tmp_path):
    """SEC-A-004 L2 / probe V6: applying an older vintage is refused before anything is written, and recorded when allowed."""
    from econquest.ingestion.feeds import OlderVintageError
    d = _data(tmp_path)
    v1 = _vintage(d, 31.25)
    v2 = _vintage(d, 31.31, now=CLOCK + dt.timedelta(minutes=5))
    apply_vintage(d)                                           # latest: fine, no rollback
    before = ((d / "indicators.csv").read_bytes(), (d / "countries.csv").read_bytes())
    snaps = sorted((d / "live" / "snapshots").iterdir())
    with pytest.raises(OlderVintageError, match="allow_older"):
        apply_vintage(d, vintage_id=v1)
    with pytest.raises(OlderVintageError):                      # also before a decision is recorded
        apply_vintage(d, vintage_id=v1, cells=[FX], author="Sam", self_approved=True)
    assert ((d / "indicators.csv").read_bytes(), (d / "countries.csv").read_bytes()) == before
    assert sorted((d / "live" / "snapshots").iterdir()) == snaps and read_ledger(d).empty
    out = apply_vintage(d, vintage_id=v1, allow_older=True, author="Sam", note="restore V1 on purpose")
    rb = out["rollback"]
    assert (rb["vintage_id"], rb["latest_vintage"], rb["allow_older"], rb["author"]) == (v1, v2, True, "Sam")
    rec = Path(rb["record"])
    assert rec.parent == Path(out["snapshot"]) and rec.name == "rollback.json"
    import json
    assert json.loads(rec.read_text())["vintage_id"] == v1
    assert apply_vintage(d, vintage_id=v2)["rollback"] is None  # the latest by full id: no rollback


def _no_feed_vintage(d: Path, feeds_doc: dict | None = None) -> str:
    """A vintage whose feeds.json shows no successful feed, built by hand (save_vintage refuses one, EQ-A-0037)."""
    import json
    from econquest.ingestion.feeds import _append_index, _content_hash
    rep, rev = _report(), _review()
    if feeds_doc is None:
        feeds_doc = {"feeds": {"weo": "error: timeout"}, "retrieved": "2026-10-23T21:30:00Z"}
    files = {"live_inputs.csv": rep.indicators.to_csv().encode(), "live_profile.csv": rep.profile.to_csv().encode(),
             "provenance.csv": rep.provenance.to_csv(index=False).encode(), "review.csv": rev.to_csv(index=False).encode(),
             "feeds.json": json.dumps(feeds_doc).encode()}
    digest = _content_hash(files)
    root = d / "live" / "vintages"; root.mkdir(parents=True, exist_ok=True)
    v = root / f"2026-10-23T213000Z-{digest[:8]}"; v.mkdir()
    for n, b in files.items():
        (v / n).write_bytes(b)
    _append_index(root, {"vintage_id": v.name, "retrieved_utc": "2026-10-23T21:30:00Z", "hash": digest, "n_files": len(files)})
    return v.name


def test_l3_no_feed_vintage_with_cells_records_nothing(tmp_path):
    """SEC-A-004 L3 / probe V7: every refusal runs before the first ledger row."""
    d = _data(tmp_path); _no_feed_vintage(d)
    with pytest.raises(VintageContentError, match="no feed succeeded"):
        apply_vintage(d, cells=[FX], author="Sam", self_approved=True)
    assert read_ledger(d).empty and not (d / "live" / "snapshots").exists()


@pytest.mark.parametrize("feeds_doc", [{"feeds": {}, "retrieved": "2026-10-23T21:30:00Z"},
                                       {"retrieved": "2026-10-23T21:30:00Z"}, {},
                                       {"feeds": [], "retrieved": "2026-10-23T21:30:00Z"}],
                         ids=["V7b-empty-feeds", "V7c-no-feeds-key", "empty-json", "feeds-not-a-dict"])
def test_l5_empty_feeds_json_counts_as_no_feed(tmp_path, feeds_doc):
    """SEC-A-006 L5 / probe V7b, V7c: a feeds.json listing no feed is refused like an all-error one, before any
    ledger row or snapshot."""
    d = _data(tmp_path); _no_feed_vintage(d, feeds_doc)
    with pytest.raises(VintageContentError, match="no feed succeeded"):
        apply_vintage(d, cells=[FX], author="sam", approver="ann")
    with pytest.raises(VintageContentError, match="no feed succeeded"):
        apply_vintage(d)
    assert read_ledger(d).empty and not (d / "live" / "snapshots").exists()
