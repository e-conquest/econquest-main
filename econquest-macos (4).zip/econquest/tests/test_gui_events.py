"""GUI event monitor (EQ-C-0038): read-only GET /api/events (event heat by country and source, week-on-week change),
"missing" when there is no feed, the Events tab in gui.html with every inserted string escaped (as EQ-C-0006)."""
import http.client
import json
import re
import sys
import threading
from http.server import ThreadingHTTPServer
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from econquest.presentation import api  # noqa: E402
from econquest.presentation.gui import make_gui_handler  # noqa: E402
from test_events_view import EVIL, feed, write  # noqa: E402
from test_gui_security import StubJobs, good  # noqa: E402

PAGE = (Path(api.__file__).parent / "static" / "gui.html").read_text()


class EvApp:
    token = "test-token-123"
    latest = {"summary": {"run_id": "r-ev"}, "settings": {"as_of": "2026-10-20"},
              "country": [{"country": "A", "iso": None}, {"country": "B", "iso": None}, {"country": "C", "iso": None}]}


@pytest.fixture
def serve(tmp_path):
    srvs = []

    def start(with_feed: bool, evil: bool = False):
        d = tmp_path / "data"; out = tmp_path / "outputs"; out.mkdir(exist_ok=True)
        if with_feed:
            f = feed()
            if evil:
                f["source"] = "GDELT" + EVIL
            write(d, f)
        srv = ThreadingHTTPServer(("127.0.0.1", 0), make_gui_handler(EvApp(), StubJobs(), out, d))
        threading.Thread(target=srv.serve_forever, daemon=True).start(); srvs.append(srv)
        return srv.server_address[1]
    yield start
    for s in srvs:
        s.shutdown()


def get(port, path, headers=None):
    conn = http.client.HTTPConnection("127.0.0.1", port, timeout=10)
    conn.request("GET", path, headers={"Host": f"127.0.0.1:{port}", **(headers or {})})
    r = conn.getresponse()
    return r.status, r.read().decode()


def test_events_route_with_feed(serve):
    port = serve(True)
    st, body = get(port, "/api/events")
    ev = json.loads(body)
    assert st == 200 and ev["status"] == "ok" and ev["run_id"] == "r-ev" and ev["reference_date"] == "2026-10-20"
    assert ev["files"] == ["events_weekly.csv"]                               # file names only, no local paths
    b = ev["rows"][0]
    assert b["country"] == "B" and b["events"] == 40 and b["wow_change"] == 28 and b["heat_label"] == "HOT"
    assert b["top_types"].startswith("14 Protest (20)")


def test_events_route_without_feed(serve):
    port = serve(False)
    st, body = get(port, "/api/events")
    ev = json.loads(body)
    assert st == 200 and ev["status"] == "missing" and ev["rows"] == [] and "No event feed yet" in ev["message"]


def test_events_route_is_read_only(serve):
    port = serve(True)
    conn = http.client.HTTPConnection("127.0.0.1", port, timeout=5)
    conn.request("POST", "/api/events", body="{}", headers={"Host": f"127.0.0.1:{port}", **good(port)})
    assert conn.getresponse().status in (404, 405)
    st, _ = get(port, "/api/events", headers={"Host": "evil.example:80"})       # DNS rebinding guard still applies
    assert st == 403


def test_events_route_returns_feed_text_as_data(serve):
    port = serve(True, evil=True)
    ev = json.loads(get(port, "/api/events")[1])
    assert any(EVIL in r["source"] for r in ev["rows"])                        # raw in JSON; the page escapes it


def test_gui_has_events_tab_and_escapes():
    assert '<a data-tab="events">Events</a>' in PAGE and '<section id="events">' in PAGE
    assert re.search(r"const renderers = \{[^}]*\bevents\b", PAGE)
    block = PAGE[PAGE.index("// ---------- events (EQ-C-0038)"):PAGE.index("// ---------- navigation ----------")]
    # every ${...} that lands in innerHTML inside the events block goes through esc() (or is a fixed colour / literal)
    for expr in re.findall(r"\$\{([^{}]*)\}", block):
        e = expr.strip()
        # the bare ones only build the filter string or sit inside an esc(`...`) template (Plotly labels)
        assert e.startswith(("esc(", "col", "s.stale ?")) or e in ("r.country", "r.source", "r.heat_label", "fmt.n(r.heat_ratio, 2)"), e
    assert "${esc(EVENTS.message)}" in block and "${esc(s.source)}" in block
    assert 'textContent = (EVENTS.files' in block                            # file list set as text, not HTML
    assert "esc(`${r.country} · ${r.source}`)" in block                       # Plotly labels escaped
