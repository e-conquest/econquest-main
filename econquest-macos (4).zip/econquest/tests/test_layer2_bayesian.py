"""EQ-B-0021: Layer 2 recalibration regression tests.

(a) GOV-013 risk-premium adjustment: the market term uses physical PD = (spread / LGD) / risk_premium_ratio,
    with SD/D-rated names exempt; the risk-neutral `pd_market` column is unchanged (benchmarks read it).
(b) GOV-015 FX term per regime: w_fx is multiplied by probability.w_fx_regime_scale[fxregime].
Neutral settings (ratio 1.0, every regime scale 1.0) must reproduce the pre-EQ-B-0021 formula exactly. Since
CHG-20261023T163209Z-b3f8bd (Sam, 2026-10-23) the shipped file carries ratio 2.0 and Peg/Dollarized 0.0; the
tests below start from the neutral values so they keep testing the mechanism, not the chosen numbers."""
import dataclasses
import sys
from pathlib import Path
import numpy as np
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.config import Settings
from econquest.ingestion import load_universe
from econquest.engine import layer1_hazard as L1, layer2_bayesian as L2
from econquest.engine.common import logit, expit
from econquest.scorecard import score_universe

DATA = ROOT / "data"
AS_OF = "2026-10-23"
NEW_KEYS = ("risk_premium_ratio", "risk_premium_exempt_ratings", "w_fx_regime_scale")
NEUTRAL = {"probability.risk_premium_ratio": 1.0, "probability.w_fx_regime_scale.Peg": 1.0,
           "probability.w_fx_regime_scale.Dollarized": 1.0}


@pytest.fixture(scope="module")
def inputs():
    u = load_universe(DATA)
    s = Settings.load(DATA / "assumptions.json").copy_with(**NEUTRAL, as_of=AS_OF)
    sc = score_universe(u, s)
    l1 = L1.run_layer1(u, s, sc.pillar_aggregated.loc[4])
    return u, s, sc, l1


def _post(inputs, **patch):
    u, s, sc, l1 = inputs
    return L2.posterior(u, s.copy_with(**patch) if patch else s, l1["pd_model"], sc.composite)


def _legacy_logodds(inputs):
    """The Layer 2 posterior as written before EQ-B-0021 (characterisation of the old formula)."""
    u, s, sc, l1 = inputs
    pr = s["probability"]
    prof = u.countries.set_index("country").loc[u.names]
    lm = logit(l1["pd_model"].loc[u.names].to_numpy())
    pdm = np.clip(prof["spread"].to_numpy(dtype=float) / 1e4 / pr["lgd_market_implied"], 1e-4, 0.95)
    return (lm + pr["w_s"] * (sc.composite.loc[u.names].to_numpy() - pr["score_centre"]) + pr["w_m"] * (logit(pdm) - lm)
            + pr["w_fx"] * (prof["fx3m"].to_numpy(dtype=float) / 5.0) + pr["w_t"] * prof["textz"].to_numpy(dtype=float))


def test_shipped_values_are_the_approved_ones():
    """CHG-20261023T163209Z-b3f8bd: ratio 2, pegged and dollarised FX weight 0, w_m unchanged at 0.5."""
    pr = Settings.load(DATA / "assumptions.json")["probability"]
    assert pr["risk_premium_ratio"] == 2.0 and pr["w_m"] == 0.5
    assert pr["w_fx_regime_scale"]["Peg"] == 0.0 and pr["w_fx_regime_scale"]["Dollarized"] == 0.0
    assert pr["w_fx_regime_scale"]["Float"] == 1.0 and pr["w_fx_regime_scale"]["Managed"] == 1.0


def test_neutral_settings_are_a_no_op(inputs):
    """Ratio 1.0 and all regime scales 1.0 reproduce the old posterior bit for bit, and so does a settings file
    without the new keys at all."""
    _, s, _, _ = inputs
    pr = s["probability"]
    assert pr["risk_premium_ratio"] == 1.0 and set(pr["w_fx_regime_scale"].values()) == {1.0}
    assert pr["w_m"] == 0.5          # EQ-B-0021 must not change w_m (Sam's decision)
    post = _post(inputs)
    np.testing.assert_array_equal(post["logodds_post"].to_numpy(), _legacy_logodds(inputs))
    np.testing.assert_array_equal(post["pd_market_phys"].to_numpy(), post["pd_market"].to_numpy())
    u, s, sc, l1 = inputs
    raw = {**s.raw, "probability": {k: v for k, v in pr.items() if k not in NEW_KEYS}}
    bare = L2.posterior(u, dataclasses.replace(s, raw=raw), l1["pd_model"], sc.composite)
    np.testing.assert_array_equal(bare["logodds_post"].to_numpy(), post["logodds_post"].to_numpy())


def test_physical_pd_divides_uncapped_intensity():
    spread = np.array([60.0, 1200.0, 6000.0])
    rn = L2.market_implied_pd(spread, 0.6)
    np.testing.assert_allclose(L2.physical_pd(spread, 0.6, 1.0), rn)
    ph = L2.physical_pd(spread, 0.6, 2.0)
    np.testing.assert_allclose(ph[:2], rn[:2] / 2)
    assert ph[2] == pytest.approx(0.5)      # 6000/1e4/0.6 = 1.0 uncapped, halved; not cap 0.95 halved
    ex = L2.physical_pd(spread, 0.6, 2.0, exempt=np.array([False, True, False]))
    assert ex[1] == pytest.approx(rn[1])
    with pytest.raises(ValueError):
        L2.physical_pd(spread, 0.6, 0.8)


def test_risk_premium_lowers_market_term_except_defaulted(inputs):
    base = _post(inputs)
    adj = _post(inputs, **{"probability.risk_premium_ratio": 2.0})
    u = inputs[0]
    rating = u.countries.set_index("country").loc[u.names, "rating"]
    sd = rating.isin(["SD", "D"])
    # the risk-neutral column the benchmarks read is unchanged
    np.testing.assert_array_equal(adj["pd_market"].to_numpy(), base["pd_market"].to_numpy())
    # SD names (Venezuela, Zimbabwe) are exempt: posterior unchanged
    np.testing.assert_array_equal(adj.loc[sd, "logodds_post"].to_numpy(), base.loc[sd, "logodds_post"].to_numpy())
    # every other name: physical PD halved and posterior lower by exactly w_m * (logit change of the market PD)
    nd = ~sd
    np.testing.assert_allclose(adj.loc[nd, "pd_market_phys"], base.loc[nd, "pd_market"] / 2)
    w_m = inputs[1]["probability"]["w_m"]
    np.testing.assert_allclose(adj.loc[nd, "logodds_post"] - base.loc[nd, "logodds_post"],
                               w_m * (logit(adj.loc[nd, "pd_market_phys"]) - logit(base.loc[nd, "pd_market"])))
    assert (adj.loc[nd, "pd_post"] < base.loc[nd, "pd_post"]).all()


def test_fx_term_is_regime_aware(inputs):
    u = inputs[0]
    reg = u.countries.set_index("country").loc[u.names, "fxregime"]
    base = _post(inputs)
    pegs0 = _post(inputs, **{"probability.w_fx_regime_scale.Peg": 0.0, "probability.w_fx_regime_scale.Dollarized": 0.0})
    w_fx = inputs[1]["probability"]["w_fx"]
    is_peg = reg.isin(["Peg", "Dollarized"])
    assert is_peg.sum() >= 2              # Belize and Senegal in the snapshot
    diff = pegs0["logodds_post"] - base["logodds_post"]
    np.testing.assert_allclose(diff[is_peg], -w_fx * base.loc[is_peg, "z_fx"])
    np.testing.assert_array_equal(diff[~is_peg].to_numpy(), 0.0)
    np.testing.assert_array_equal(pegs0.loc[is_peg, "fx_weight"].to_numpy(), 0.0)
    # Senegal: XOF move against USD (the euro's move) no longer raises the PD
    assert pegs0.at["Senegal", "pd_post"] < base.at["Senegal", "pd_post"]


def test_fx_regime_weight_default_and_unknown():
    assert list(L2.fx_regime_weight(["Float", "Peg", "Crawl", " Peg "], {"Peg": 0.0, "default": 0.5})) == [0.5, 0.0, 0.5, 0.0]
    assert list(L2.fx_regime_weight(["Float", "Peg"], None)) == [1.0, 1.0]


def test_pd_post_is_expit_of_logodds(inputs):
    post = _post(inputs, **{"probability.risk_premium_ratio": 3.0, "probability.w_fx_regime_scale.Peg": 0.0})
    np.testing.assert_allclose(post["pd_post"], expit(post["logodds_post"]))
