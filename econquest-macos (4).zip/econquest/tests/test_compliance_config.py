"""Compliance approver config under `econquest change` (EQ-C-0040, SEC-C-004 R1): data/compliance.json is governed by
ops/approvals (four-eyes, drift detection); the pre-EQ-C-0040 outputs/editorial/compliance.json is never read or
migrated, and sign-off is refused while it says something else."""
import json
import os
import shutil
from pathlib import Path

import pytest

from econquest import cli
from econquest.ops import approvals as ap
from econquest.presentation import compliance as C
from econquest.presentation import editorial as E
from test_compliance import META, write  # noqa: E402

ROOT = Path(__file__).resolve().parent.parent
TIGHT = {"role": "compliance officer", "approvers": ["Jane Roe"], "allow_self_sign": False}


@pytest.fixture
def out(tmp_path):
    o = tmp_path / "outputs"
    (o / "reports").mkdir(parents=True)
    (tmp_path / "data").mkdir()
    yield o
    for root, _dirs, files in os.walk(o):
        os.chmod(root, 0o755)
        for f in files:
            os.chmod(os.path.join(root, f), 0o644)


def data_of(out) -> Path:
    return out.parent / "data"


def ready(out):
    """A reviewed item with the author's declaration: only the sign-off is missing."""
    it = E.register_draft(out, "country_note", [write(out)], META, "Alice")
    E.review(out, it["item_id"], "Bob")
    E.checklist(out, it["item_id"], "Alice", conflicts="no conflicts")
    return it["item_id"]


def legacy(out, cfg):
    p = C.legacy_config_path(out); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(cfg))
    return p


def test_shipped_file_is_the_default_and_governed():
    raw = json.loads((ROOT / "data" / "compliance.json").read_text())
    assert C.validate_config(raw) == C.validate_config(C.DEFAULT_CONFIG)
    assert "compliance.json" in ap.FILES
    assert "compliance.json" in (ROOT / "install.sh").read_text().split("MANAGED_DATA=(")[1].split(")")[0]


def test_absent_file_is_the_default_and_not_drift(out):
    d = data_of(out)
    cfg = C.load_config(d, out)
    assert cfg["source"] == "default" and cfg["status"] == "default" and cfg["sha256"] is None
    st = {f["file"]: f["status"] for f in ap.detect_unapproved(d)["files"]}
    assert st["compliance.json"] == "default"


def test_unbaselined_default_file_is_accepted_other_content_is_not(out):
    d = data_of(out)
    shutil.copy(ROOT / "data" / "compliance.json", d / "compliance.json")
    assert C.load_config(d)["status"] == "no_baseline"
    (d / "compliance.json").write_text(json.dumps(TIGHT))
    with pytest.raises(C.ComplianceError, match="never recorded by `econquest change`"):
        C.load_config(d)
    ap.baseline(d, "compliance.json", "Sam", "first use")
    cfg = C.load_config(d)
    assert cfg["status"] == "ok" and cfg["approvers"] == ["Jane Roe"] and cfg["source"] == str(d / "compliance.json")


def test_hand_edit_after_apply_refuses_signoff(out):
    d = data_of(out)
    (d / "compliance.json").write_text(json.dumps(TIGHT))
    ap.baseline(d, "compliance.json", "Sam", "first use")
    iid = ready(out)
    # the R1 attack: loosen the gate by hand, then self-sign
    (d / "compliance.json").write_text(json.dumps(C.DEFAULT_CONFIG))
    with pytest.raises(E.EditorialError, match="edited outside `econquest change`"):
        E.checklist(out, iid, "Alice", compliance_approve=True, self_signed=True)
    os.remove(d / "compliance.json")                                   # deleting it does not restore the default
    with pytest.raises(E.EditorialError, match="now missing"):
        E.checklist(out, iid, "Alice", compliance_approve=True, self_signed=True)
    (d / "compliance.json").write_text(json.dumps(TIGHT))              # put back exactly what was applied
    assert E.checklist(out, iid, "Jane Roe", compliance_approve=True)["checklist"]["signoff"]["config_status"] == "ok"


def test_change_through_the_tool_needs_four_eyes_and_records_the_change(out):
    d = data_of(out)
    shutil.copy(ROOT / "data" / "compliance.json", d / "compliance.json")
    p = ap.propose(d, "compliance.json", {"/allow_self_sign": False}, "Sam", "Jane named as approver")
    assert p["tier"] == "2"
    with pytest.raises(ap.ApprovalError, match="four-eyes"):
        ap.approve(d, p["id"], approver="sam")
    ap.approve(d, p["id"], approver="Alice"); ap.apply(d, p["id"], actor="Sam")
    iid = ready(out)
    with pytest.raises(E.EditorialError, match="self-sign is disabled"):
        E.checklist(out, iid, "Alice", compliance_approve=True, self_signed=True)
    so = E.checklist(out, iid, "Dave", compliance_approve=True)["checklist"]["signoff"]
    assert so["config_change_id"] == p["id"] and so["config_sha256"] == ap.file_sha256(d / "compliance.json")


def test_propose_refuses_an_invalid_config(out):
    d = data_of(out)
    shutil.copy(ROOT / "data" / "compliance.json", d / "compliance.json")
    with pytest.raises(ap.ApprovalError, match="allow_self_sign must be true or false"):
        ap.propose(d, "compliance.json", {"/allow_self_sign": "no"}, "Sam", "x", allow_type_change=True)
    with pytest.raises(ap.ApprovalError, match="expected an object with keys"):
        ap.propose(d, "compliance.json", {"/extra": 1}, "Sam", "x", allow_new_keys=True)


def test_broken_approvals_chain_refuses_signoff(out):
    d = data_of(out)
    (d / "compliance.json").write_text(json.dumps(TIGHT))
    ap.baseline(d, "compliance.json", "Sam", "first use")
    log = ap.log_path(d); log.write_text(log.read_text().replace("first use", "first-use"))
    with pytest.raises(C.ComplianceError, match="failed verification"):
        C.load_config(d)


def test_legacy_file_alone_refuses_signoff_with_move_instructions(out):
    legacy(out, TIGHT)
    iid = ready(out)
    with pytest.raises(E.EditorialError, match="no longer read") as e:
        E.checklist(out, iid, "Dave", compliance_approve=True)
    assert "econquest change baseline compliance.json" in str(e.value)
    assert not (data_of(out) / "compliance.json").exists()               # never migrated automatically


def test_legacy_file_differing_from_data_refuses_with_propose_instructions(out):
    shutil.copy(ROOT / "data" / "compliance.json", data_of(out) / "compliance.json")
    old = legacy(out, TIGHT)
    with pytest.raises(C.ComplianceError, match="econquest change propose compliance.json --replace-file") as e:
        C.load_config(data_of(out), out)
    assert str(old) in str(e.value)
    legacy(out, {"approvers": "x"})                                      # an invalid legacy file is refused too
    with pytest.raises(C.ComplianceError, match="It is invalid"):
        C.load_config(data_of(out), out)


def test_legacy_file_equal_to_data_is_tolerated(out):
    d = data_of(out)
    (d / "compliance.json").write_text(json.dumps(TIGHT))
    ap.baseline(d, "compliance.json", "Sam", "moved")
    legacy(out, {**TIGHT, "approvers": ["JANE ROE "]})                  # same people (person_key)
    iid = ready(out)
    assert E.checklist(out, iid, "Jane Roe", compliance_approve=True)["checklist"]["signoff"]["approver"] == "Jane Roe"
    assert E.publish(out, iid, "Carol")["state"] == "published"


def test_cli_change_accepts_compliance_json(out, capsys):
    d = data_of(out)
    for f in ap.FILES:
        shutil.copy(ROOT / "data" / f, d / f)
    base = ["--data", str(d), "--out", str(out), "change"]
    cli.main([*base, "propose", "compliance.json", "--set", "/allow_self_sign=false", "--author", "Sam", "--reason", "t"])
    cid = capsys.readouterr().out.split()[1]
    cli.main([*base, "approve", cid, "--self-approved", "--exc", "EXC-001"])
    cli.main([*base, "apply", cid])
    assert json.loads((d / "compliance.json").read_text())["allow_self_sign"] is False
    cli.main([*base, "verify"])
    assert "compliance.json: ok" in capsys.readouterr().out


# ---------------------------------------------------------------- EQ-C-0050 (SEC-C-005 R1)
def test_deleting_config_and_approvals_after_a_governed_signoff_is_refused(out):
    d = data_of(out)
    (d / "compliance.json").write_text(json.dumps(TIGHT))
    ap.baseline(d, "compliance.json", "Sam", "first use")
    iid = ready(out)
    assert E.checklist(out, iid, "Jane Roe", compliance_approve=True)["checklist"]["signoff"]["config_status"] == "ok"
    iid2 = ready(out)
    # the R1 probe: delete both paths so the weakest default (self-sign allowed) would come back
    os.remove(d / "compliance.json"); shutil.rmtree(ap.approvals_dir(d))
    assert C.load_config(d)["status"] == "default"                      # without the ledger there is nothing to anchor to
    with pytest.raises(C.ComplianceError, match="sign-off made under a governed config") as e:
        C.load_config(d, out)
    assert iid in str(e.value) and "restore data/compliance.json and data/approvals/" in str(e.value)
    with pytest.raises(E.EditorialError, match="governed config"):
        E.checklist(out, iid2, "Alice", compliance_approve=True, self_signed=True, exc_id="EXC-001")
    assert not E.get_item(out, iid2)["checklist"].get("signoff")


def test_signoffs_under_the_default_do_not_block_the_default(out):
    iid = ready(out)
    assert E.checklist(out, iid, "Dave", compliance_approve=True)["checklist"]["signoff"]["config_status"] == "default"
    assert C.governed_signoff(out) is None and C.load_config(data_of(out), out)["status"] == "default"


def test_default_content_without_approvals_record_after_a_governed_signoff_is_refused(out):
    """SEC-C-007 L1: the EQ-C-0050 anchor also holds when data/compliance.json is still there but was overwritten with
    the default content after data/approvals/ was deleted (status no_baseline), the shipped layout's version of R1."""
    d = data_of(out)
    (d / "compliance.json").write_text(json.dumps(TIGHT))
    ap.baseline(d, "compliance.json", "Sam", "first use")
    iid = ready(out)
    E.checklist(out, iid, "Jane Roe", compliance_approve=True)
    iid2 = ready(out)
    shutil.rmtree(ap.approvals_dir(d)); (d / "compliance.json").write_text(json.dumps(C.DEFAULT_CONFIG))
    assert C.load_config(d)["status"] == "no_baseline"
    with pytest.raises(C.ComplianceError, match="is present but data/approvals/ has no record of it.*governed config"):
        C.load_config(d, out)
    with pytest.raises(E.EditorialError, match="governed config"):
        E.checklist(out, iid2, "Alice", compliance_approve=True, self_signed=True, exc_id="EXC-001")
    assert not E.get_item(out, iid2)["checklist"].get("signoff")


def test_signoffs_under_an_unbaselined_default_file_do_not_block_it(out):
    d = data_of(out)
    (d / "compliance.json").write_text(json.dumps(C.DEFAULT_CONFIG))
    iid = ready(out)
    assert E.checklist(out, iid, "Dave", compliance_approve=True)["checklist"]["signoff"]["config_status"] == "no_baseline"
    assert C.governed_signoff(out) is None and C.load_config(d, out)["status"] == "no_baseline"
