"""Sheets OAuth token never travels on a command line (EQ-C-0002)."""
import http.client
import io
import json
import subprocess
import threading
from http.server import ThreadingHTTPServer
from types import SimpleNamespace

import pytest

from econquest import cli
from econquest.presentation import api, gui

SECRET = "ya29.SECRET-token-value"


@pytest.fixture(autouse=True)
def clean_env(monkeypatch, tmp_path):
    monkeypatch.delenv(cli.TOKEN_ENV, raising=False)
    monkeypatch.setattr(cli, "_keychain_token", lambda: None)
    monkeypatch.setenv("ECONQUEST_RUN_GATE", "off")                       # token handling only; the gate: test_run_gate.py
    monkeypatch.setenv("ECONQUEST_ACTION_LOG", str(tmp_path / "actions.jsonl"))   # never the checkout's outputs/store


def ns(**kw):
    return SimpleNamespace(**{"token": None, "token_file": None, "write": False, **kw})


def test_token_from_env_with_write(monkeypatch):
    monkeypatch.setenv("ECONQUEST_SHEETS_TOKEN", SECRET)
    assert cli.resolve_token(ns(write=True)) == SECRET


def test_ambient_token_without_write_is_ignored_and_keychain_not_called(monkeypatch):
    calls = []
    monkeypatch.setenv(cli.TOKEN_ENV, SECRET)
    monkeypatch.setattr(cli, "_keychain_token", lambda: calls.append(1) or "from-keychain")
    assert cli.resolve_token(ns()) is None
    assert calls == []


def test_write_without_any_token_exits():
    with pytest.raises(SystemExit, match="--write needs a Sheets token"):
        cli.resolve_token(ns(write=True))


def test_precedence(monkeypatch, tmp_path, capsys):
    f = tmp_path / "tok.txt"; f.write_text("from-file\n")
    monkeypatch.setenv(cli.TOKEN_ENV, "from-env")
    monkeypatch.setattr(cli, "_keychain_token", lambda: "from-keychain")
    # explicit beats ambient: --token-file, then deprecated --token, win over env and Keychain even with --write
    assert cli.resolve_token(ns(write=True, token="from-flag", token_file=str(f))) == "from-file"
    assert cli.resolve_token(ns(write=True, token="from-flag")) == "from-flag"
    assert cli.resolve_token(ns(token_file=str(f))) == "from-file"          # explicit token = intent to write
    # --write: env, then Keychain
    assert cli.resolve_token(ns(write=True)) == "from-env"
    monkeypatch.delenv(cli.TOKEN_ENV)
    assert cli.resolve_token(ns(write=True)) == "from-keychain"
    err = capsys.readouterr().err
    assert "--token is deprecated" in err and "from-flag" not in err


def test_token_file_without_flag_no_warning(tmp_path, capsys):
    f = tmp_path / "tok"; f.write_text("  abc \n")
    assert cli.resolve_token(ns(token_file=str(f))) == "abc"
    assert capsys.readouterr().err == ""


def test_missing_token_file_exits(tmp_path):
    with pytest.raises(SystemExit):
        cli.resolve_token(ns(token_file=str(tmp_path / "nope")))


def test_keychain_lookup(monkeypatch):
    monkeypatch.undo()                                   # use the real _keychain_token
    monkeypatch.setattr("shutil.which", lambda name: None)
    assert cli._keychain_token() is None                 # no `security` binary: no token, no call
    monkeypatch.setattr("shutil.which", lambda name: "/usr/bin/security")
    calls = []

    def fake_run(argv, **kw):
        calls.append(argv)
        return SimpleNamespace(returncode=0, stdout="kc-token\n")
    monkeypatch.setattr(subprocess, "run", fake_run)
    assert cli._keychain_token() == "kc-token"
    assert calls[0] == ["/usr/bin/security", "find-generic-password", "-s", "econquest-sheets", "-w"]
    monkeypatch.setattr(subprocess, "run", lambda argv, **kw: SimpleNamespace(returncode=44, stdout=""))
    assert cli._keychain_token() is None                 # item not found
    def boom(argv, **kw):
        raise subprocess.TimeoutExpired(argv, 10)
    monkeypatch.setattr(subprocess, "run", boom)
    assert cli._keychain_token() is None


WRITERS = {"publish": "cmd_publish", "garch": "cmd_garch", "econ": "cmd_econ", "audit": "cmd_audit", "record": "cmd_record",
           "dsa": "cmd_dsa", "benchmark": "cmd_benchmark"}


@pytest.mark.parametrize("cmd", list(WRITERS))
def test_every_writer_needs_write_for_env_token(monkeypatch, capsys, cmd):
    seen = []
    monkeypatch.setattr(cli, WRITERS[cmd], lambda args: seen.append(args.token))
    # the default data/ still holds the 17 Yahoo fx3m cells, which refuse every write (EQ-C-0070,
    # tests/test_cli_restricted_gate.py); this test is about the token, so the restricted-source check finds none
    monkeypatch.setattr(cli, "_restricted_cells", lambda d: __import__("pandas").DataFrame())
    monkeypatch.setenv(cli.TOKEN_ENV, SECRET)
    cli.main([cmd])
    cli.main([cmd, "--write"])
    assert seen == [None, SECRET]
    out = capsys.readouterr()
    assert cmd == "publish" or "--write" in out.err                       # the no-write run prints the hint (publish: its own)


def test_non_writer_commands_unaffected(monkeypatch):
    seen = {}
    monkeypatch.setattr(cli, "cmd_scenarios", lambda args: seen.setdefault("args", args))
    cli.main(["scenarios"])
    assert not hasattr(seen["args"], "token")


# --- GUI: token goes to the child via the environment, never argv or the job log ---

class FakePopen:
    last = None

    def __init__(self, argv, **kw):
        FakePopen.last = self
        self.argv, self.env = argv, kw["env"]
        self.stdout = io.StringIO(f"starting\nAuthorization: Bearer {SECRET}\n")
        self.returncode = 0

    def poll(self):
        return 0

    def wait(self):
        return 0


@pytest.fixture
def jobs(monkeypatch, tmp_path):
    monkeypatch.setattr(gui.subprocess, "Popen", FakePopen)
    monkeypatch.setenv(cli.TOKEN_ENV, "inherited-from-parent")
    return gui.Jobs(str(tmp_path), str(tmp_path))


def _finish(jobs):
    import time
    deadline = time.time() + 5
    while jobs.jobs[-1]["status"] == "running" and time.time() < deadline:
        time.sleep(0.01)


@pytest.mark.parametrize("call", [
    dict(args=["--mc-rows", "2000"], sheets_token=SECRET),
    dict(args=["--mc-rows", "2000", "--token", SECRET]),          # legacy client
    dict(args=["--mc-rows", "2000", f"--token={SECRET}"]),
])
def test_gui_job_argv_never_contains_token(jobs, call):
    jobs.start("publish", **call)
    _finish(jobs)
    p = FakePopen.last
    assert not any(SECRET in a for a in p.argv) and "--token" not in " ".join(p.argv)
    assert p.argv[-3:] == ["--mc-rows", "2000", "--write"]
    assert p.env["ECONQUEST_SHEETS_TOKEN"] == SECRET
    job = jobs.jobs[-1]
    assert SECRET not in job["argv"]
    assert job["log"] and all(SECRET not in line for line in job["log"])
    assert SECRET not in json.dumps(jobs.list())


def test_gui_job_without_token_does_not_inherit_one(jobs):
    jobs.start("garch", [])
    assert "ECONQUEST_SHEETS_TOKEN" not in FakePopen.last.env and "--write" not in FakePopen.last.argv


@pytest.mark.parametrize("args", [["--write"], ["--quotes", "q.csv", "--write"], ["--token-file", "/etc/x", "--write"], ["--token-file=/etc/x"]])
def test_gui_job_without_token_strips_client_write(jobs, args):
    jobs.start("garch", args)
    argv = FakePopen.last.argv
    assert "--write" not in argv and not any(a.startswith("--token-file") for a in argv)
    assert "ECONQUEST_SHEETS_TOKEN" not in FakePopen.last.env


@pytest.mark.parametrize("args", [["--wr"], ["--writ"], ["--token-f", "/etc/x"], ["--token-fi=/etc/x"], ["--quotes", "q.csv", "--w"]])
def test_gui_job_strips_argparse_abbreviations_of_write_and_token_file(jobs, monkeypatch, args):
    # regression (AGENT-09 review of EQ-C-0002): argparse expands unique prefixes, so --wr meant --write (Keychain lookup)
    # and --token-f PATH meant --token-file PATH, both without a token from this request
    jobs.start("garch", args)
    tail = FakePopen.last.argv[FakePopen.last.argv.index("garch") + 1:]
    seen = []
    monkeypatch.setattr(cli, "cmd_garch", lambda a: seen.append((a.write, a.token_file, a.token)))
    cli.main(["garch", *tail])
    assert seen == [(False, None, None)]
    assert ("q.csv" in tail) == ("q.csv" in args)


def test_gui_non_writer_job_never_gets_write_or_token(jobs):
    jobs.start("run", ["--paths", "1000"], sheets_token=SECRET)
    assert "--write" not in FakePopen.last.argv and "ECONQUEST_SHEETS_TOKEN" not in FakePopen.last.env


def test_gui_http_job_passes_token_in_env(jobs):
    class StubApp:
        token = "session-tok"
        latest = {"summary": {"run_id": "r1"}}
    srv = ThreadingHTTPServer(("127.0.0.1", 0), gui.make_gui_handler(StubApp(), jobs, jobs.out_dir, jobs.data_dir))
    threading.Thread(target=srv.serve_forever, daemon=True).start()
    try:
        port = srv.server_address[1]
        conn = http.client.HTTPConnection("127.0.0.1", port, timeout=5)
        conn.request("POST", "/api/job", body=json.dumps({"cmd": "publish", "args": ["--mc-rows", "2000"], "sheets_token": SECRET}),
                     headers={"Host": f"127.0.0.1:{port}", "Content-Type": "application/json", api.TOKEN_HEADER: StubApp.token,
                              "Origin": f"http://127.0.0.1:{port}"})
        r = conn.getresponse(); body = r.read().decode()
        assert r.status == 200 and SECRET not in body
        assert FakePopen.last.env["ECONQUEST_SHEETS_TOKEN"] == SECRET
        assert not any(SECRET in a for a in FakePopen.last.argv) and FakePopen.last.argv[-1] == "--write"
    finally:
        srv.shutdown()


def test_gui_page_sends_token_in_body_not_args():
    html = (gui.STATIC / "gui.html").read_text(encoding="utf-8")
    assert 'args.push("--token"' not in html and "body.sheets_token = t" in html
