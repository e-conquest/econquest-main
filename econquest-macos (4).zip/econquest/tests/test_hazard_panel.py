"""Hazard recalibration pipeline (roadmap 2.3): panel construction, fit, out-of-sample test, fitted-mode engine."""
import sys
from pathlib import Path
import numpy as np
import pytest
import pandas as pd
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.validation import hazard_panel as hp
from econquest.engine.common import expit
from econquest.engine.layer1_hazard import FEATURES, PANEL_EXTRA
from econquest.config import Settings
from econquest.ingestion import load_universe


def _synthetic(n_countries=60, years=range(1980, 2024), seed=0):
    rng = np.random.default_rng(seed)
    rows, spells = [], []
    isos = [f"C{i:02d}" for i in range(n_countries)]
    for iso in isos:
        debt = 40 + 30 * rng.random(); ca = rng.normal(-2, 3)
        in_default_until = -1
        for y in years:
            debt = max(5, debt + rng.normal(0, 5)); ca = 0.7 * ca + rng.normal(0, 2)
            growth = rng.normal(3, 3); infl = max(-2, rng.gamma(2, 3)); pb = rng.normal(-1, 2)
            rows += [{"iso": iso, "series": "GGXWDG_NGDP", "period": y, "value": debt},
                     {"iso": iso, "series": "GGXONLB_NGDP", "period": y, "value": pb},
                     {"iso": iso, "series": "BCA_NGDPD", "period": y, "value": ca},
                     {"iso": iso, "series": "NGDP_RPCH", "period": y, "value": growth},
                     {"iso": iso, "series": "PCPIPCH", "period": y, "value": infl}]
            if y > in_default_until:
                p = expit(-5.5 + 0.03 * (debt - 60) - 0.25 * ca - 0.2 * growth)
                if rng.random() < p:
                    spells.append({"iso": iso, "start": y + 1, "end": y + 3}); in_default_until = y + 3
    weo = pd.DataFrame(rows); weo["source"] = "synthetic"
    return weo, pd.DataFrame(spells)


def test_panel_labels_and_at_risk_filter():
    weo, ev = _synthetic()
    panel = hp.panel_from_long(weo, None, ev, start=1980, end=2023, forecast_cutoff=2023)
    assert set(hp.DEFAULT_FEATURES).issubset(panel.columns)
    # a row is labelled 1 exactly when a spell starts the following year, and spell years are absent
    for r in ev.itertuples():
        assert ((panel["iso"] == r.iso) & (panel["year"] == r.start - 1) & (panel["event"] == 1)).any() or r.start - 1 < 1980
        assert not ((panel["iso"] == r.iso) & (panel["year"].between(r.start, r.end))).any()
    assert panel["event"].sum() >= len(ev) - 3


def test_fit_recovers_signs_and_discriminates_out_of_sample():
    weo, ev = _synthetic()
    panel = hp.panel_from_long(weo, None, ev, start=1980, end=2023, forecast_cutoff=2023)
    res = hp.fit_and_validate(panel, oos_start=2005)
    assert res.coef["debt_gdp"] > 0 and res.coef["current_account"] < 0 and res.coef["real_growth"] < 0
    assert res.in_sample["auc"] > 0.7 and res.out_of_sample["auc"] > 0.65
    assert res.out_of_sample["brier"] <= res.out_of_sample["brier_base_rate"] * 1.05
    block = res.fitted_block()
    assert set(block) >= {"features", "coef", "intercept", "scale", "out_of_sample"}
    p = res.predict(panel)
    assert p.shape == (len(panel),) and np.all((p > 0) & (p < 1))


def test_crag_style_workbook_parses(tmp_path):
    """Older wide layout (years as columns) still reads, now through import_crag (EQ-B-0015)."""
    years = list(range(1990, 2001))
    rows = [["Country", "Creditor"] + years,
            ["Atlantis", "Foreign currency bonds"] + [0, 0, 0, 10, 20, 0, 0, 0, 5, 5, 0],
            ["Atlantis", "Paris Club"] + [3] * 11,
            ["Lemuria", "Foreign currency bank loans"] + [0] * 11]
    csv = tmp_path / "crag.csv"
    pd.DataFrame(rows).to_csv(csv, index=False, header=False)
    ev = hp.load_crag_workbook(csv, iso_map={"Atlantis": "ATL"})
    assert list(ev[["iso", "start", "end"]].itertuples(index=False, name=None)) == [("ATL", 1993, 1994), ("ATL", 1998, 1999)]


# ---------------------------------------------------------------- EQ-B-0015: CRAG 2026 long format via import_crag

def _crag_2026_long(years=range(2010, 2026)):
    """Small synthetic frame in the Valet DEBT_2026 long layout: one row per country-year, category columns."""
    cats = ["TOTAL_2026", "IMF_2026", "PARIS_CLUB_2026", "PRIVATE_CREDITORS_2026", "FC_BANK_LOANS_2026", "FC_BONDS_2026",
            "LC_DEBT_2026", "FISCAL_ARREARS_2026"]
    rows = []
    for c in ("Zambia", "Niger", "Grenada", "Atlantis"):
        for y in years:
            r = {"COUNTRY": c, "COUNTRY_GROUP": "test", "YEAR": y, **{k: 0.0 for k in cats}}
            if c == "Zambia" and 2020 <= y <= 2024:
                r["FC_BONDS_2026"] = 3000.0
            if c == "Zambia" and y == 2012:
                r["IMF_2026"] = 50.0                       # official arrears alone are out of scope
            if c == "Niger" and y in (2014, 2015):
                r["LC_DEBT_2026"] = 10.0
            if c == "Grenada" and 2013 <= y <= 2015:
                r["FC_BANK_LOANS_2026"] = 5.0; r["FC_BONDS_2026"] = 190.0
            if c == "Atlantis" and y == 2025:
                r["FC_BONDS_2026"] = 1.0                   # ongoing at the last data year
            r["PRIVATE_CREDITORS_2026"] = r["FC_BANK_LOANS_2026"] + r["FC_BONDS_2026"]
            r["TOTAL_2026"] = sum(v for k, v in r.items() if k in cats[1:4] + cats[6:])
            rows.append(r)
    return pd.DataFrame(rows)


def _spell_tuples(ev):
    return sorted(ev[["iso", "start", "end"]].itertuples(index=False, name=None))


def test_load_crag_reads_2026_long_format_with_proper_iso(tmp_path):
    f = tmp_path / "debt_2026.csv"
    with open(f, "w") as fh:                                   # Valet-style preamble above the table
        fh.write('"TERMS AND CONDITIONS"\n"https://www.bankofcanada.ca/terms/"\n\n"OBSERVATIONS"\n')
        _crag_2026_long().to_csv(fh, index=False)
    ev = hp.load_crag(f, iso_map={"Atlantis": "ATL"}, source_label="synthetic DEBT_2026", vintage="2026-10")
    # proper ISO3 (ZMB, NER, GRD), not name[:3] (ZAM, NIG, GRE); official-only arrears (Zambia 2012) are not a spell
    assert _spell_tuples(ev) == [("ATL", 2025, 2025), ("GRD", 2013, 2015), ("NER", 2014, 2015), ("ZMB", 2020, 2024)]
    assert ev["source"].str.startswith("synthetic DEBT_2026 sha256:").all() and (ev["source_vintage"] == "2026-10").all()
    assert "ongoing" in ev.set_index("iso").at["ATL", "note"]


def test_load_crag_accepts_dataframes_and_import_crag_output(tmp_path):
    raw = _crag_2026_long()
    ev_df = hp.load_crag(raw, iso_map={"Atlantis": "ATL"}, out_csv=tmp_path / "episodes.csv")
    assert (tmp_path / "episodes.csv").exists()
    again = hp.load_crag(tmp_path / "episodes.csv")            # an import_crag CSV is read as is
    assert _spell_tuples(again) == _spell_tuples(ev_df)
    assert _spell_tuples(hp.load_crag(pd.read_csv(tmp_path / "episodes.csv"))) == _spell_tuples(ev_df)
    assert _spell_tuples(hp.load_events(tmp_path / "episodes.csv")) == _spell_tuples(ev_df)
    raw.to_csv(tmp_path / "raw.csv", index=False)
    assert _spell_tuples(hp.load_events(tmp_path / "raw.csv", iso_map={"Atlantis": "ATL"})) == _spell_tuples(ev_df)


def test_load_crag_refuses_unmapped_names_instead_of_guessing():
    with pytest.raises(ValueError, match="Atlantis"):
        hp.load_crag(_crag_2026_long())                         # no ISO for Atlantis: no name[:3] guess
    with pytest.raises(ValueError, match="ISO3"):
        hp.load_crag(pd.DataFrame({"iso": ["Atlantis"], "start": [2001], "end": [2002]}))


def test_crag_long_events_feed_the_panel(tmp_path):
    ev = hp.load_crag(_crag_2026_long(), iso_map={"Atlantis": "ATL"})
    weo = pd.DataFrame([{"iso": i, "series": "GGXWDG_NGDP", "period": y, "value": 50.0 + y - 2000}
                        for i in ("ZMB", "NER", "GRD") for y in range(2008, 2026)])
    panel = hp.panel_from_long(weo, None, ev, features=["debt_gdp"], start=2010, end=2024, forecast_cutoff=2024)
    got = sorted(map(tuple, panel.loc[panel["event"] == 1, ["iso", "year"]].to_numpy().tolist()))
    assert got == [("GRD", 2012), ("NER", 2013), ("ZMB", 2019)]


def test_write_report(tmp_path):
    weo, ev = _synthetic(n_countries=30)
    panel = hp.panel_from_long(weo, None, ev, start=1980, end=2023, forecast_cutoff=2023)
    res = hp.fit_and_validate(panel, oos_start=2005)
    out = hp.write_report(res, tmp_path / "r.md", panel=panel, notes=["test"])
    txt = out.read_text()
    assert "Coefficients" in txt and "Out-of-sample" in txt and "Calibration" in txt


def test_engine_fitted_mode_uses_panel_features():
    u = load_universe(ROOT / "data"); s = Settings.load(ROOT / "data" / "assumptions.json").copy_with(as_of="2026-10-23")
    from econquest.scorecard import score_universe
    from econquest.engine.layer1_hazard import build_features, run_layer1
    sc = score_universe(u, s)
    X = build_features(u, sc.pillar_aggregated.loc[4], as_of="2026-10-23")
    assert list(X.columns) == FEATURES + PANEL_EXTRA and X.notna().all().all()
    fitted = {"features": hp.DEFAULT_FEATURES, "coef": {"debt_gdp": 0.8, "primary_deficit": 0.3, "current_account": -0.5, "real_growth": -0.4, "inflation_log": 0.2},
              "intercept": -4.0, "scale": {"debt_gdp": [60.0, 30.0], "primary_deficit": [1.0, 3.0], "current_account": [-2.0, 4.0], "real_growth": [3.0, 3.0], "inflation_log": [5.0, 5.0]}, "fitted_on": "test"}
    s2 = s.copy_with(layer1={**s["layer1"], "mode": "fitted"}, layer1_fitted=fitted)
    import warnings
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        out = run_layer1(u, s2, sc.pillar_aggregated.loc[4])
    m = out.attrs["model"]
    # EQ-B-0013 / GOV-046: the live vintage may lack a country's as_of-minus-lag WEO value; then the fitted model is
    # refused (flagged) rather than scored on substitutes. Either way the outcome is explicit.
    if "fitted_fallback" in m:
        assert m["mode"] == "paper_standardized" and "refused" in m["fitted_fallback"]
    else:
        assert m["mode"] == "fitted" and m["features"] == hp.DEFAULT_FEATURES and m["predictor_year"] == 2025
    assert np.all((out["pd_hazard"] > 0) & (out["pd_hazard"] < 1))
    base = run_layer1(u, s, sc.pillar_aggregated.loc[4])
    assert base.attrs["model"]["mode"] == "paper_standardized"


# ---------------------------------------------------------------- EQ-B-0006 / GOV-006: no look-ahead in the backtest

def _weo_identity(isos=("AAA", "BBB"), years=range(1990, 2001)):
    """Each series value encodes its period, so the panel shows which year a predictor came from."""
    rows = [{"iso": i, "series": code, "period": y, "value": float(y - 1900)} for i in isos for y in years for code in hp.WEO_CODES]
    return pd.DataFrame(rows)


def test_predictors_are_lagged_one_year_by_default():
    ev = pd.DataFrame({"iso": ["AAA"], "start": [1996], "end": [1997]})
    panel = hp.panel_from_long(_weo_identity(), None, ev, features=["debt_gdp"], start=1991, end=2000, forecast_cutoff=2000)
    assert panel.attrs["predictor_lag"] == 1
    assert (panel["debt_gdp"] == panel["year"] - 1 - 1900).all()            # row t carries year t-1 data
    row = panel[(panel["iso"] == "AAA") & (panel["event"] == 1)]
    assert list(row["year"]) == [1995] and float(row["debt_gdp"].iloc[0]) == 94.0
    old = hp.panel_from_long(_weo_identity(), None, ev, features=["debt_gdp"], start=1991, end=2000, forecast_cutoff=2000, lag=0)
    assert (old["debt_gdp"] == old["year"] - 1900).all()


def test_point_in_time_vintage_ignores_later_revisions():
    weo = pd.DataFrame([
        {"iso": "AAA", "series": "GGXWDG_NGDP", "period": 1999, "value": 10.0, "vintage": 2000},      # first print
        {"iso": "AAA", "series": "GGXWDG_NGDP", "period": 1999, "value": 99.0, "vintage": "2005-04-15"},  # revised later
        {"iso": "AAA", "series": "GGXWDG_NGDP", "period": 2000, "value": 20.0, "vintage": 2002},      # not out by end-2001? (published 2002)
    ])
    ev = pd.DataFrame(columns=["iso", "start", "end"])
    panel = hp.panel_from_long(weo, None, ev, features=["debt_gdp"], start=2000, end=2001, forecast_cutoff=2001)
    assert panel.set_index("year")["debt_gdp"].to_dict() == {2000: 10.0}       # 2001 row dropped: its data was published in 2002
    assert panel.attrs["point_in_time"] == "all features"


def _iid_shock_world(n_countries=150, years=range(1980, 2024), seed=3):
    """Default start in t+1 is driven only by an i.i.d. year-t growth shock: unforecastable from year t-1 data."""
    rng = np.random.default_rng(seed)
    rows, spells = [], []
    for k in range(n_countries):
        iso = f"Q{k:03d}"; until = -1
        for y in years:
            g = rng.normal(3, 3)
            rows.append({"iso": iso, "series": "NGDP_RPCH", "period": y, "value": g})
            if y > until and rng.random() < expit(-3.0 - 1.2 * (g - 3)):
                spells.append({"iso": iso, "start": y + 1, "end": y + 1}); until = y + 1
    return pd.DataFrame(rows), pd.DataFrame(spells)


def test_contemporaneous_predictor_leak_is_removed():
    """With lag=0 the backtest scores year-t data that is only published after the window opens and looks skilful;
    with the default one-year lag the same unforecastable world scores at chance."""
    weo, ev = _iid_shock_world()
    leaky = hp.fit_and_validate(hp.panel_from_long(weo, None, ev, features=["real_growth"], start=1981, end=2022, forecast_cutoff=2022, lag=0),
                                features=["real_growth"], oos_start=2000)
    honest = hp.fit_and_validate(hp.panel_from_long(weo, None, ev, features=["real_growth"], start=1981, end=2022, forecast_cutoff=2022),
                                 features=["real_growth"], oos_start=2000)
    assert leaky.out_of_sample["auc"] > 0.75
    assert abs(honest.out_of_sample["auc"] - 0.5) < 0.08
    assert honest.out_of_sample["predictor_lag"] == 1 and honest.fitted_block()["predictor_lag"] == 1


def test_oos_base_rate_comes_from_training_window_not_test_sample():
    rng = np.random.default_rng(7)
    rows = []
    for y in range(1990, 2011):
        rate = 0.05 if y < 2005 else 0.40                         # the test years default far more often
        for k in range(40):
            rows.append({"iso": f"K{k:02d}", "year": y, "debt_gdp": rng.normal(60, 10), "event": int(rng.random() < rate)})
    panel = pd.DataFrame(rows)
    res = hp.fit_and_validate(panel, features=["debt_gdp"], oos_start=2005, min_train_events=1)
    expected_base = np.concatenate([np.full((panel["year"] == T).sum(), panel.loc[panel["year"] < T, "event"].mean()) for T in range(2005, 2011)])
    yo = np.concatenate([panel.loc[panel["year"] == T, "event"].to_numpy(dtype=float) for T in range(2005, 2011)])
    assert np.isclose(res.out_of_sample["brier_base_rate"], hp.brier(yo, expected_base))
    assert not np.isclose(res.out_of_sample["brier_base_rate"], hp.brier(yo, np.full_like(yo, yo.mean())))
    assert res.oos_by_year["base_p"].between(0.04, 0.2).all()


def test_calibration_table_names_its_bins_honestly(tmp_path):
    weo, ev = _synthetic(n_countries=30)
    panel = hp.panel_from_long(weo, None, ev, start=1980, end=2023, forecast_cutoff=2023)
    res = hp.fit_and_validate(panel, oos_start=2018)                     # few test rows -> fewer than 10 bins
    nb = res.calibration.attrs["n_bins"]
    assert "bin" in res.calibration.columns and "decile" not in res.calibration.columns and len(res.calibration) == nb
    txt = hp.write_report(res, tmp_path / "r.md", panel=panel).read_text()
    if nb != 10:
        assert "decile" not in txt.lower() and f"{nb} equal-count bins" in txt
    assert "training-window event rate" in txt


# ---------------------------------------------------------------- EQ-B-0020: refit path end to end through the gate

def test_gate_thresholds_match_ticket():
    assert hp.GATE_MIN_AUC == 0.75 and hp.GATE_MIN_EVENTS == 30


def _fake_result(auc_v, events, brier_v, brier_base):
    weo, ev = _synthetic(n_countries=20)
    res = hp.fit_and_validate(hp.panel_from_long(weo, None, ev, start=1980, end=2023, forecast_cutoff=2023), oos_start=2005)
    res.events = events
    res.out_of_sample = {**res.out_of_sample, "auc": auc_v, "brier": brier_v, "brier_base_rate": brier_base}
    return res


def test_gate_check_each_rule():
    assert hp.gate_check(_fake_result(0.80, 40, 0.020, 0.025))["cleared"]
    g = hp.gate_check(_fake_result(0.74, 40, 0.020, 0.025))            # 0.74 cleared the old 0.70 gate
    assert not g["cleared"] and not g["checks"]["oos_auc"]["pass"]
    assert not hp.gate_check(_fake_result(0.80, 29, 0.020, 0.025))["cleared"]
    assert not hp.gate_check(_fake_result(0.80, 40, 0.025, 0.025))["cleared"]   # Brier must be strictly below
    assert not hp.gate_check(_fake_result(float("nan"), 40, 0.020, 0.025))["cleared"]
    assert "NOT CLEARED" in hp.gate_summary(g) and "FAIL" in hp.gate_summary(g)


def test_refit_from_files_end_to_end_writes_only_to_out_dir(tmp_path):
    weo, ev = _synthetic(n_countries=60)
    data = tmp_path / "data"; (data / "panel").mkdir(parents=True); (data / "live").mkdir()
    weo.to_csv(data / "live" / "raw_weo.csv", index=False)
    ev.assign(country=ev["iso"]).to_csv(data / "panel" / "sovereign_defaults.csv", index=False)
    before = {p: p.stat().st_mtime for p in data.rglob("*") if p.is_file()}
    r = hp.refit_from_files(data, tmp_path / "out", oos_start=2005, as_of="2026-10-23")
    assert {p: p.stat().st_mtime for p in data.rglob("*") if p.is_file()} == before          # inputs untouched
    for k in ("report", "fitted_block", "panel"):
        assert Path(r[k]).parent == tmp_path / "out" and Path(r[k]).exists()
    import json
    block = json.loads(Path(r["fitted_block"]).read_text())
    assert block["predictor_lag"] == 1 and block["gate"]["checks"]["oos_auc"]["threshold"] == 0.75
    assert r["out_of_sample"]["base_rate"] == "training-window event rate per origin"
    # last label year: episodes cover through max(start, end); the last row year is one less (its t+1 must be observed)
    assert r["years"][1] <= int(max(ev["end"].max(), ev["start"].max())) - 1
    txt = Path(r["report"]).read_text()
    assert "Fitted-mode gate" in txt and "refit_from_files" in txt and "predictors from year t-1" in txt
    assert r["gate"]["cleared"] == (r["out_of_sample"]["auc"] >= 0.75 and r["events"] >= 30
                                    and r["out_of_sample"]["brier"] < r["out_of_sample"]["brier_base_rate"])


def test_refit_on_repo_panel_reports_gate_honestly(tmp_path):
    """The 15-country pilot panel goes through the same path; it must not clear the event-count rule."""
    if not (ROOT / "data" / "live" / "raw_weo.csv").exists():
        pytest.skip("no live WEO vintage")
    r = hp.refit_from_files(ROOT / "data", tmp_path, as_of="2026-10-23")
    assert r["out_of_sample"]["predictor_lag"] == 1
    assert r["events"] < 30 and not r["gate"]["cleared"]


def test_fitted_block_omits_unknown_predictor_lag():
    # review of EQ-B-0020: a fit from a prebuilt panel (lag unknown) must not write predictor_lag: null
    import dataclasses
    from econquest.validation import hazard_panel as hp
    fields = {f.name for f in dataclasses.fields(hp.FitResult)}
    assert "predictor_lag" in fields
    res = hp.FitResult.__new__(hp.FitResult)
    for f in dataclasses.fields(hp.FitResult):
        object.__setattr__(res, f.name, f.default if f.default is not dataclasses.MISSING else None)
    res.features, res.coef, res.scale, res.panel_source, res.years = [], {}, {}, {}, []
    assert "predictor_lag" not in res.fitted_block()
    res.predictor_lag = 1
    assert res.fitted_block()["predictor_lag"] == 1


def _vintaged_weo(n_iso=60, years=range(1995, 2021)):
    import numpy as np
    rng = np.random.default_rng(11)
    rows = []
    for k in range(n_iso):
        iso = f"Q{k:02d}"
        for y in years:
            for vin in ("2010-04", "2010-10", "2015-04", "2015-10"):
                if int(vin[:4]) < y:
                    continue                                   # a release cannot carry later outturns
                rows.append({"iso": iso, "series": "GGXWDG_NGDP", "period": y, "value": float(rng.normal(60, 5)) + (0.5 if vin.endswith("10") else 0.0),
                             "vintage": vin})
    df = pd.DataFrame(rows)
    return df.sample(frac=1.0, random_state=3).reset_index(drop=True)    # unsorted on purpose


def test_october_release_beats_april_deterministically():
    # EQ-B-0031 (HO-20261023-A-B-007): same-year releases are ordered by full date with a stable sort
    from econquest.validation import hazard_panel as hp
    weo = _vintaged_weo()
    assert len(weo) > 1000
    ev = pd.DataFrame({"iso": ["Q00"], "start": [2018], "end": [2019]})
    p = hp.panel_from_long(weo, None, ev, features=["debt_gdp"], start=2011, end=2019)
    s = weo[(weo["period"] == 2014)]
    for iso in ("Q01", "Q05", "Q33"):
        oct15 = s[(s["iso"] == iso) & (s["vintage"] == "2015-10")]["value"].iloc[0]
        row = p[(p["iso"] == iso) & (p["year"] == 2015)]
        assert len(row) == 1 and abs(float(row["debt_gdp"].iloc[0]) - oct15) < 1e-12     # lag 1: year-2015 row uses 2014 values
    assert p.attrs["pit_from"] == 2010 and p.attrs["point_in_time"] == "all features"


def test_rows_before_first_release_use_earliest_or_drop():
    from econquest.validation import hazard_panel as hp
    weo = _vintaged_weo(n_iso=5)
    ev = pd.DataFrame({"iso": ["Q00"], "start": [2018], "end": [2019]})
    early = hp.panel_from_long(weo, None, ev, features=["debt_gdp"], start=1996, end=2019)
    assert early["year"].min() == 1996                         # kept, from the earliest (2010-04) release
    v = weo[(weo["iso"] == "Q02") & (weo["period"] == 1999) & (weo["vintage"] == "2010-04")]["value"].iloc[0]
    assert abs(float(early[(early["iso"] == "Q02") & (early["year"] == 2000)]["debt_gdp"].iloc[0]) - v) < 1e-12
    dropped = hp.panel_from_long(weo, None, ev, features=["debt_gdp"], start=1996, end=2019, pre_first_release="drop")
    assert dropped["year"].min() == 2010 and dropped.attrs["pit_from"] is None
    with pytest.raises(ValueError):
        hp.panel_from_long(weo, None, ev, features=["debt_gdp"], start=1996, end=2019, pre_first_release="guess")


def test_panel_end_defaults_to_as_of_year_not_the_clock():
    """VF-006 (EQ-B-0054): without `end`, the last labelled row is year(as_of) - 1."""
    weo, ev = _synthetic(n_countries=20)
    p = hp.panel_from_long(weo, None, ev, start=1980, as_of="2011-06-30")
    q = hp.panel_from_long(weo, None, ev, start=1980, end=2010)
    assert int(p["year"].max()) == 2010
    pd.testing.assert_frame_equal(p.reset_index(drop=True), q.reset_index(drop=True))
    assert hp._as_of_year("2011-06-30") == 2011
