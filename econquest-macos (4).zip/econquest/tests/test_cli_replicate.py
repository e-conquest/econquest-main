"""`econquest replicate` passes its flags through to econquest.validation.replicate.main and returns its exit code
(HO-20261023-B-C-015 part 1, EQ-C-0054). The replication itself is Team B's (tests/test_replicate.py)."""
from pathlib import Path

import pytest

from econquest import cli
from econquest.validation import replicate as R


class Calls(list):
    code = 0


@pytest.fixture
def calls(monkeypatch):
    seen = Calls()

    def fake_main(argv=None):
        seen.append(argv)
        return seen.code
    monkeypatch.setattr(R, "main", fake_main)
    return seen


def test_defaults_use_global_data_and_out(calls, tmp_path):
    cli.main(["--data", str(tmp_path / "d"), "--out", str(tmp_path / "o"), "replicate"])
    assert calls == [["--data", str(tmp_path / "d"), "--out", str(tmp_path / "o" / "replication")]]


def test_default_out_is_outputs_replication(calls):
    cli.main(["replicate"])
    assert calls[0] == ["--data", str(cli.DEFAULT_DATA), "--out", str(Path(cli.DEFAULT_OUT) / "replication")]


def test_flags_pass_through(calls, tmp_path):
    cli.main(["replicate", "--quick", "--only", "backtest,hazard", "--out", str(tmp_path / "x")])
    assert calls == [["--data", str(cli.DEFAULT_DATA), "--out", str(tmp_path / "x"), "--quick", "--only", "backtest,hazard"]]


def test_exit_code_on_fail(calls):
    calls.code = 1
    with pytest.raises(SystemExit) as e:
        cli.main(["replicate", "--quick"])
    assert e.value.code == 1


def test_help_lists_team_b_groups(capsys):
    with pytest.raises(SystemExit) as e:
        cli.main(["replicate", "--help"])
    out = " ".join(capsys.readouterr().out.split())
    assert e.value.code == 0 and ",".join(R.GROUPS) in out


def test_real_quick_backtest_group(tmp_path):
    """End to end on the real module and data/ (backtest group only: no Monte Carlo, a few seconds)."""
    out = tmp_path / "rep"
    cli.main(["replicate", "--quick", "--only", "backtest", "--out", str(out)])
    assert (out / "replication.csv").exists() and (out / "replication.md").exists()
