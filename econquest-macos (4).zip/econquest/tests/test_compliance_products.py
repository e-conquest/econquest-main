"""Every research product passes the compliance checklist's automatic checks (EQ-C-0036 items 1, 2, 4; EQ-C-0037):
the disclaimer, a visible Sources section with "As of" equal to the run's as-of date plus the econquest:sources stamp,
and the Input caveats block with its [restriction 6.x] markers, for the daily report, weekly monitor, country notes and
scenario briefs (every HTML/Markdown file each one writes, index pages included)."""
import json
import re
import sys
from pathlib import Path

import pytest

sys.path.insert(0, str(Path(__file__).resolve().parent))
from econquest.presentation import compliance as C  # noqa: E402
from econquest.presentation import country_note as N  # noqa: E402
from econquest.presentation import report as R  # noqa: E402
from econquest.presentation import risk_monitor as M  # noqa: E402
from econquest.presentation import scenario_brief as S  # noqa: E402
from test_country_note import make_world  # noqa: E402
from test_events_view import feed, write  # noqa: E402
from test_report import make_data, make_run  # noqa: E402
from test_scenario_brief import world as brief_world  # noqa: E402


def files_of(paths):
    return [{"name": Path(p).name, "path": str(p)} for p in paths if Path(p).suffix.lower() in C.TEXT_SUFFIXES]


def assert_passes(paths, data_dir, run, as_of):
    files = files_of(paths)
    assert files
    auto = C.automatic_checks(files, {"as_of": as_of}, data_dir, run)
    for k in ("disclaimer", "sources", "caveats"):
        assert auto[k]["ok"], (k, auto[k]["problems"])
    for f in files:
        t = Path(f["path"]).read_text(encoding="utf-8")
        assert re.search(r"<h2>Sources</h2>|^## Sources$", t, re.M), f["name"]       # visible section, not only the stamp
        st = json.loads(re.search(r"<!--\s*econquest:sources\s+(\{.*?\})\s*-->", t, re.S).group(1))
        assert st["as_of"] == as_of and st["sources"], f["name"]
        assert C.sources_problems(re.sub(r"<!--\s*econquest:sources.*?-->", "", t, flags=re.S), f["name"], as_of) == []   # the section alone passes too


@pytest.mark.parametrize("with_events", [False, True])
def test_country_notes_pass(tmp_path, with_events):
    d, out, base = make_world(tmp_path)
    if with_events:
        write(d, feed())
    res = N.build_country_notes(out, d, tmp_path / "notes", recompute_pillars=False, log=lambda *a: None)
    assert_passes(res["paths"], d, base, "2026-10-20")
    t = Path(res["items"][0]["html"]).read_text(encoding="utf-8")
    assert "IMF WEO" in t and "Seed estimates in data/indicators.csv" in t
    assert ("Event feed GDELT: latest complete week 2026-10-12" in t) if with_events else ("no event feed yet" in t)


def test_scenario_briefs_pass(tmp_path):
    d, out = brief_world(tmp_path)
    res = S.build_scenario_briefs(out, d, tmp_path / "briefs", log=lambda *a: None)
    base = json.loads((out / "run_latest.json").read_text())
    assert_passes(res["paths"], d, base, "2026-10-20")


def test_weekly_monitor_passes(tmp_path):
    d, out, base = make_world(tmp_path)
    r = M.build_monitor(out, d, tmp_path / "monitor", log=lambda *a: None)
    assert_passes([r["html"], r["md"], r["latest"]], d, base, "2026-10-20")


def test_daily_report_passes(tmp_path):
    d = make_data(tmp_path / "data")
    run = make_run()
    r = R.build_report(d, tmp_path / "out", run=run, alerts=[], log=lambda *a: None)
    assert_passes([r["html"], r["md"], r["latest"]], d, run, "2026-10-20")


def test_sources_without_provenance_or_as_of(tmp_path):
    src = R.product_sources(tmp_path, run=None)
    assert src["as_of"] is None and src["vintage"] is None and "No live feed pull recorded" in src["sources"][0]
    assert "As of: not recorded on the run." in R.sources_html(src)


def test_stamp_cannot_close_the_comment_early(tmp_path):
    st = R.sources_stamp({"as_of": "2026-10-20", "sources": ["x --> <script>alert(1)</script>"]})
    assert st.count("-->") == 1 and "<script" not in st
    assert json.loads(re.search(r"econquest:sources\s+(\{.*?\})\s*-->", st, re.S).group(1))["sources"][0].startswith("x --> <script>")
