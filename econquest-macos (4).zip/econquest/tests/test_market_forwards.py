"""EQ-A-0030: FX forwards derived by covered interest parity. Every number is SYNTHETIC."""
import datetime as dt
import math

import pandas as pd
import pytest

from econquest.ingestion.market import forwards as fw
from econquest.ingestion.market.forwards import (cip_forward, derive_cip_forwards, spot_from_yahoo_raw,
                                                 to_continuous)
from econquest.ingestion.market.gate import market_gate
from econquest.ingestion.market.schema import MARKET_COLUMNS, MarketDataError
from econquest.ingestion.market.store import latest_market, save_market_snapshot

D = "2026-10-22"
LIC = "SYNTHETIC test licence"


def q(instrument, ccy, tenor, value, source, iso="", ticker="", unit="pct", field="yield_pct", asof=D):
    return {"asof": asof, "instrument": instrument, "iso": iso, "currency": ccy, "tenor_y": tenor, "field": field,
            "value": value, "unit": unit, "doc_clause": "", "source": source, "vendor_ticker": ticker,
            "licence": LIC, "derived": False, "snapshot_id": "", "retrieved_utc": ""}


def frame(rows):
    return pd.DataFrame(rows, columns=MARKET_COLUMNS)


SPOT = frame([q("fx_spot", "EUR", 0, 0.92, "yahoo", ticker="EUR=X", unit="EUR/USD", field="outright")])
RATES = frame([
    q("govt_yield", "USD", 1 / 12, 4.13, "fred", "USA", "DGS1MO"),
    q("govt_yield", "USD", 0.25, 5.00, "fred", "USA", "DGS3MO"),
    q("govt_yield", "USD", 0.5, 3.93, "fred", "USA", "DGS6MO"),
    q("govt_yield", "USD", 1.0, 3.83, "fred", "USA", "DGS1"),
    q("govt_yield", "EUR", 0.25, 3.00, "ecb_yc_aaa", "EMU", "YC.B.U2.EUR.4F.G_N_A.SV_C_YM.SR_3M"),
    q("govt_yield", "EUR", 0.25, 3.40, "ecb_yc_all", "EMU", "YC.B.U2.EUR.4F.G_N_C.SV_C_YM.SR_3M"),
    q("govt_yield", "EUR", 0.5, 2.04, "ecb_yc_aaa", "EMU", "YC.B.U2.EUR.4F.G_N_A.SV_C_YM.SR_6M"),
    q("govt_yield", "EUR", 1.0, 2.05, "ecb_yc_aaa", "EMU", "YC.B.U2.EUR.4F.G_N_A.SV_C_YM.SR_1Y"),
])


def test_cip_hand_computed_example():
    # S = 0.92 EUR per USD; EUR 3M = 3.00% continuous (ECB SV_C_YM); USD 3M = 5.00% bond-equivalent semiannual.
    # z_usd = 2 ln(1.025) = 0.049385225; z_eur - z_usd = -0.019385225; x 0.25 = -0.004846306
    # exp(-0.004846306) = 0.995165418; F = 0.92 x 0.995165418 = 0.915552185; points = F - S = -0.004447815
    out = derive_cip_forwards(SPOT, RATES, ("3M",))
    o = out.set_index("field")["value"]
    assert o["outright"] == pytest.approx(0.915552185, abs=1e-9)
    assert o["points"] == pytest.approx(-0.004447815, abs=1e-9)


def test_conversions():
    assert to_continuous(5, "annual", 1) == pytest.approx(math.log(1.05))
    assert to_continuous(5, "semiannual", 1) == pytest.approx(2 * math.log(1.025))
    assert to_continuous(4, "simple", 0.5) == pytest.approx(math.log(1.02) / 0.5)
    assert to_continuous(3, "continuous", 7) == 0.03
    assert cip_forward(1.0, 0.0, 0.0, 1.0) == 1.0
    with pytest.raises(ValueError):
        to_continuous(5, "monthly", 1)


def test_rows_are_flagged_derived_and_name_inputs():
    out = derive_cip_forwards(SPOT, RATES)
    assert out["derived"].all() and set(out["source"]) == {"derived_cip"} and set(out["instrument"]) == {"fx_forward"}
    assert set(out["unit"]) == {"EUR/USD"} and set(out["iso"]) == {""}
    r3 = out[(out["tenor_y"] == 0.25) & (out["field"] == "outright")].iloc[0]
    assert "derived (CIP)" in r3["vendor_ticker"] and "DGS3MO" in r3["vendor_ticker"]
    assert "G_N_A" in r3["vendor_ticker"]                          # AAA preferred over all-issuers
    assert r3["licence"].startswith("derived (CIP) from yahoo+ecb_yc_aaa+fred")
    p = [f for f in out.attrs["provenance"]["forwards"] if f["tenor"] == "3M"][0]
    assert p["rate_ccy"]["vendor_ticker"].endswith("SR_3M") and p["rate_ccy"]["compounding"] == "continuous"
    assert p["rate_usd"]["vendor_ticker"] == "DGS3MO" and p["rate_usd"]["compounding"] == "semiannual"
    assert p["spot"]["value"] == 0.92 and "exp" in out.attrs["provenance"]["formula"]


def test_refuses_when_a_rate_is_missing():
    out = derive_cip_forwards(SPOT, RATES)                       # ECB has no 1M rate in this frame
    assert sorted(out["tenor_y"].unique()) == [0.25, 0.5, 1.0]
    (ccy, asof, tenor, why), = out.attrs["refused"]
    assert (ccy, asof, tenor) == ("EUR", D, "1M") and "no EUR" in why
    with pytest.raises(MarketDataError, match="refused: EUR 2026-10-22 1M"):
        derive_cip_forwards(SPOT, RATES, strict=True)
    no_usd = RATES[RATES["currency"] != "USD"]
    with pytest.raises(MarketDataError, match="no CIP forward could be derived.*no USD"):
        derive_cip_forwards(SPOT, no_usd)


def test_rates_from_another_date_or_issuer_are_not_used():
    other_day = RATES.assign(asof="2026-10-21")
    with pytest.raises(MarketDataError, match="no CIP forward"):
        derive_cip_forwards(SPOT, other_day)
    bra = frame([q("govt_yield", "USD", 0.25, 9.0, "fred", "BRA", "X")]) # a USD bond of another sovereign
    eur = RATES[RATES["currency"] == "EUR"]
    with pytest.raises(MarketDataError, match="no USD"):
        derive_cip_forwards(SPOT, pd.concat([eur, bra]), ("3M",))


def test_unknown_compounding_refused_unless_given():
    ois = frame([q("ois", "USD", 0.25, 5.0, "lseg", ticker="USDOIS3M"),
                 q("ois", "EUR", 0.25, 3.0, "lseg", ticker="EUROIS3M")])
    with pytest.raises(MarketDataError, match="compounding unknown"):
        derive_cip_forwards(SPOT, ois, ("3M",))
    out = derive_cip_forwards(SPOT, ois, ("3M",), compounding={"lseg": "annual"})
    f = out.set_index("field")["value"]["outright"]
    assert f == pytest.approx(0.92 * (1.03 / 1.05) ** 0.25)      # annual: same as the gate's CIP formula


def test_gate_runs_clean_on_output_including_cip_check():
    spot = SPOT.assign(source="bis")         # a source=yahoo spot is held whatever its licence (SEC-A-006 L6)
    ois = frame([q("ois", "USD", 0.25, 5.0, "lseg"), q("ois", "EUR", 0.25, 3.0, "lseg")])
    out = derive_cip_forwards(spot, ois, ("3M",), compounding={"lseg": "annual"})
    review = market_gate(pd.concat([spot, ois, out], ignore_index=True))
    assert (review["status"] == "ok").all(), review
    out2 = derive_cip_forwards(spot, RATES)
    review = market_gate(pd.concat([spot, RATES, out2], ignore_index=True))
    assert (review["status"] == "ok").all(), review


def test_spot_from_yahoo_raw_licence_is_not_caller_set():
    """SEC-A-006 L6: no licence parameter; every row carries YAHOO_LICENCE and the gate holds it."""
    import inspect
    from econquest.ingestion.market import forwards as fw
    assert "licence" not in inspect.signature(spot_from_yahoo_raw).parameters
    raw = pd.DataFrame({"iso": ["PHL"], "series": ["FX_USD"], "period": [D], "value": ["58.1"], "source": "yfinance"})
    with pytest.raises(TypeError):
        spot_from_yahoo_raw(raw, {"PHL": "PHP"}, licence="free official")
    s = spot_from_yahoo_raw(raw, {"PHL": "PHP"})
    assert set(s["licence"]) == {fw.YAHOO_LICENCE}
    assert (market_gate(s)["status"] == "hold").all()


def test_spot_from_yahoo_raw_collapses_shared_currency():
    raw = pd.DataFrame({"iso": ["DEU", "FRA", "PHL", "PHL"], "series": ["FX_USD", "FX_USD", "FX_USD", "ETF"],
                        "period": [D] * 4, "value": ["0.92", "0.92", "58.1", "30"], "source": "yfinance"})
    cur = {"DEU": "EUR", "FRA": "EUR", "PHL": "PHP"}
    s = spot_from_yahoo_raw(raw, cur)
    assert sorted(s["currency"]) == ["EUR", "PHP"] and set(s["unit"]) == {"EUR/USD", "PHP/USD"}
    raw.loc[1, "value"] = "0.93"
    with pytest.raises(MarketDataError, match="disagrees"):
        spot_from_yahoo_raw(raw, cur)


def test_cli_derives_from_snapshots_and_saves(tmp_path, capsys):
    now = dt.datetime(2026, 10, 23, 12, tzinfo=dt.timezone.utc)
    save_market_snapshot(tmp_path, pd.concat([SPOT, RATES], ignore_index=True), now=now)
    assert fw.main(["--data-dir", str(tmp_path), "--asof", D, "--spot", "snapshot"]) == 0
    assert "3 forwards derived" in capsys.readouterr().out
    f = latest_market(tmp_path, "fx_forward")
    assert len(f) == 6 and f["derived"].all()


def _yahoo_live(tmp_path):
    save_market_snapshot(tmp_path, RATES, now=dt.datetime(2026, 10, 23, 12, tzinfo=dt.timezone.utc))
    (tmp_path / "live").mkdir(exist_ok=True)
    pd.DataFrame({"iso": ["DEU"], "series": ["FX_USD"], "period": [D], "value": ["0.92"],
                  "source": ["yfinance (Yahoo Finance)"]}).to_csv(tmp_path / "live" / "raw_yahoo.csv", index=False)
    pd.DataFrame({"iso": ["DEU"], "currency": ["EUR"]}).to_csv(tmp_path / "countries.csv", index=False)


def test_cli_refuses_yahoo_spot_without_the_opt_in(tmp_path, capsys, monkeypatch):
    """EQ-A-0040 (Sam 2026-10-23): Yahoo is refused for desk numbers; nothing is written."""
    monkeypatch.delenv(fw.YAHOO_OPT_IN_ENV, raising=False)
    _yahoo_live(tmp_path)
    assert fw.main(["--data-dir", str(tmp_path), "--asof", D, "--spot", "yahoo", "--tenors", "3M"]) == 2
    assert "refused" in capsys.readouterr().err
    assert latest_market(tmp_path, "fx_forward").empty


def test_cli_yahoo_spot_only_with_the_explicit_opt_in(tmp_path, capsys, monkeypatch):
    """With ECONQUEST_ALLOW_YAHOO=1 the rows are produced for research and keep the non-commercial licence."""
    monkeypatch.setenv(fw.YAHOO_OPT_IN_ENV, "1")
    _yahoo_live(tmp_path)
    assert fw.main(["--data-dir", str(tmp_path), "--asof", D, "--spot", "yahoo", "--tenors", "3M"]) == 0
    s = latest_market(tmp_path, "fx_spot")
    assert s["source"].tolist() == ["yahoo"] and s["licence"].iloc[0] == fw.YAHOO_LICENCE
    f = latest_market(tmp_path, "fx_forward").set_index("field")["value"]
    assert f["outright"] == pytest.approx(0.915552185, abs=1e-9)
    assert "non-commercial" in latest_market(tmp_path, "fx_forward")["licence"].iloc[0]


def test_cli_bis_spot_is_the_default(tmp_path, capsys):
    """EQ-A-0040: the default spot is the official BIS WS_XRU pull; the spot rows are saved with the forwards."""
    save_market_snapshot(tmp_path, RATES, now=dt.datetime(2026, 10, 23, 12, tzinfo=dt.timezone.utc))
    (tmp_path / "live").mkdir(exist_ok=True)
    pd.DataFrame({"iso": ["XM"], "series": ["EUR_PER_USD"], "period": [D], "value": ["0.92"],
                  "source": ["BIS SDMX REST WS_XRU (stats.bis.org)"],
                  "sdmx_key": ["WS_XRU D.XM.EUR.A"]}).to_csv(tmp_path / "live" / "raw_bis_xru.csv", index=False)
    assert fw.main(["--data-dir", str(tmp_path), "--asof", D, "--tenors", "3M"]) == 0
    s = latest_market(tmp_path, "fx_spot")
    assert s["source"].tolist() == ["bis_xru"] and s["currency"].tolist() == ["EUR"]
    assert s["licence"].iloc[0] == fw.BIS_SPOT_LICENCE and s["vendor_ticker"].iloc[0] == "WS_XRU D.XM.EUR.A"
    f = latest_market(tmp_path, "fx_forward").set_index("field")["value"]
    assert f["outright"] == pytest.approx(0.915552185, abs=1e-9)
    assert "yahoo" not in latest_market(tmp_path, "fx_forward")["licence"].iloc[0]


def test_cli_ecb_spot_converts_through_eur_usd(tmp_path):
    """--spot ecb: the per-EUR reference rates become per-USD through the same date's EUR/USD, never another date's."""
    save_market_snapshot(tmp_path, RATES, now=dt.datetime(2026, 10, 23, 12, tzinfo=dt.timezone.utc))
    (tmp_path / "live").mkdir(exist_ok=True)
    pd.DataFrame({"iso": ["", "", ""], "series": ["USD_PER_EUR", "BRL_PER_EUR", "BRL_PER_EUR"],
                  "period": [D, D, "2026-10-21"], "value": ["1.0870", "6.0", "5.0"],
                  "source": ["ECB"] * 3, "sdmx_key": ["EXR D.USD.EUR.SP00.A", "EXR D.BRL.EUR.SP00.A",
                                                      "EXR D.BRL.EUR.SP00.A"]}).to_csv(
        tmp_path / "live" / "raw_ecb_exr.csv", index=False)
    assert fw.main(["--data-dir", str(tmp_path), "--asof", D, "--spot", "ecb", "--tenors", "3M"]) == 0
    s = latest_market(tmp_path, "fx_spot").set_index("currency")["value"]
    assert s["EUR"] == pytest.approx(1 / 1.0870, abs=1e-9) and s["BRL"] == pytest.approx(6.0 / 1.0870, abs=1e-9)
    # 2026-10-21 has no EUR/USD rate of its own, so it produces no spot row
    assert set(latest_market(tmp_path, "fx_spot")["asof"]) == {D}


def test_derived_licence_carries_input_restrictions():
    """SEC-A-003 L3: a forward from Yahoo spot keeps 'non-commercial' (and the other markers) in its own licence."""
    from econquest.ingestion.market.public import ECB_LICENCE, FRED_LICENCE
    spot = SPOT.assign(licence=fw.YAHOO_LICENCE)
    rates = RATES.assign(licence=[FRED_LICENCE if c == "USD" else ECB_LICENCE for c in RATES["currency"]])
    out = derive_cip_forwards(spot, rates, ("3M",))
    lic = set(out["licence"])
    assert len(lic) == 1
    lic = lic.pop()
    assert len(lic) <= 128 and lic.startswith("derived (CIP) from yahoo+ecb_yc_aaa+fred")
    for marker in ("non-commercial", "personal", "unverified"):
        assert marker in lic
    p = out.attrs["provenance"]["forwards"][0]
    assert p["spot"]["licence"] == fw.YAHOO_LICENCE and p["rate_usd"]["licence"] == FRED_LICENCE


def test_derived_licence_lists_short_input_licences_verbatim():
    out = derive_cip_forwards(SPOT, RATES, ("3M",))
    assert set(out["licence"]) == {"derived (CIP) from yahoo+ecb_yc_aaa+fred; inputs: SYNTHETIC test licence"}
    lic, why = fw.derived_licence([{"source": "a", "licence": "SYNTHETIC x"}, {"source": "b", "licence": "free"},
                                   {"source": "a", "licence": "SYNTHETIC x"}])
    assert lic == "derived (CIP) from a+b+a; inputs: SYNTHETIC x | free" and why == ""
