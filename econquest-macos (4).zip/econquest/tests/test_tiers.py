"""EQ-B-0055: one universe-tier reader (engine/tiers.py) behind Layer 3's regime.global_set lookup (by name) and the
stress tier clauses (stress.country_tiers, by ISO3). Proposal files written here are SYNTHETIC (fictional XAA..)."""
import os
import sys
import warnings
from pathlib import Path

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.config import Settings  # noqa: E402
from econquest.engine import layer3_regime as L3  # noqa: E402
from econquest.engine import stress as ST  # noqa: E402
from econquest.engine import tiers as T  # noqa: E402
from econquest.ingestion.universe import DEFAULT_PROPOSAL, load_universe_proposal  # noqa: E402


def _write(path, text):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(text)
    return path


def test_name_and_iso_lookups_agree_on_the_shipped_proposal():
    prop = load_universe_proposal(DEFAULT_PROPOSAL)
    by_name = L3._proposal_lookup(Settings(raw={}))
    pd.testing.assert_frame_equal(by_name, prop.set_index("name")[["iso3", "tier"]])     # the pre-EQ-B-0055 read
    c = prop.rename(columns={"iso3": "iso", "name": "country"})[["iso", "country"]]
    assert ST.country_tiers(c).tolist() == by_name.loc[c["country"], "tier"].tolist()   # same tier either way


def test_stripping_blanks_and_missing_columns(tmp_path):
    p = _write(tmp_path / "panel" / "universe_proposal.csv",
               "iso3,iso2,name,tier\n XAA ,NA, Alpha , EM \nXBB,XB,Beta,\n,XC,Gamma,frontier\n")
    assert T.tier_by_iso(p) == {"XAA": "EM"}                         # blank iso3 or tier rows are left out
    by_name = T.tier_by_name(p)
    assert by_name.loc["Alpha"].tolist() == ["XAA", "EM"] and by_name.loc["Beta", "tier"] == ""
    c = pd.DataFrame({"iso": ["XAA", "XBB"], "country": ["Alpha", "Beta"]})
    with pytest.warns(RuntimeWarning, match="tier unknown for Beta"):
        assert ST.country_tiers(c, base_dir=tmp_path).tolist() == ["EM", "unknown"]
    q = _write(tmp_path / "noname" / "p.csv", "iso3,tier\nXAA,EM\n")   # stress needs only iso3 + tier
    assert T.tier_by_iso(q) == {"XAA": "EM"}
    with pytest.raises(KeyError):
        T.tier_by_name(q)


def test_missing_file_layer3_raises_stress_falls_back(tmp_path):
    assert T.tier_by_iso(tmp_path / "none.csv") == {}
    with pytest.raises(FileNotFoundError):
        T.tier_by_name(tmp_path / "none.csv")
    s = Settings(raw={"regime": {"global_set": ["XAA"], "global_set_proposal": str(tmp_path / "none.csv")}})
    with pytest.raises(FileNotFoundError):
        L3.global_set(pd.Series("Calm", index=["Alpha"]), s)


def test_cache_rereads_a_changed_file(tmp_path):
    p = _write(tmp_path / "p.csv", "iso3,name,tier\nXAA,Alpha,EM\n")
    assert T.tier_by_iso(p) == {"XAA": "EM"}
    p.write_text("iso3,name,tier\nXAA,Alpha,frontier\n")
    st = p.stat()
    os.utime(p, ns=(st.st_atime_ns, st.st_mtime_ns + 10**9))          # a new modification time
    assert T.tier_by_iso(p) == {"XAA": "frontier"}
    assert T.tier_by_name(p).loc["Alpha", "tier"] == "frontier"


def test_global_set_tiers_via_helper(tmp_path):
    p = _write(tmp_path / "p.csv", "iso3,name,tier\nXAA,Alpha,EM\nXBB,Beta,DM_anchor\nXCC,Gamma,frontier\n")
    reg = pd.Series(["Stressed", "Calm", "Calm", "Calm"], index=["Alpha", "Beta", "Gamma", "Delta"])
    s = Settings(raw={"regime": {"global_set": {"exclude_tiers": ["DM_anchor"]}, "global_set_proposal": str(p)}})
    assert L3.global_set(reg, s) == ["Alpha", "Gamma", "Delta"]        # Delta has no row: no tier, stays in
    s = Settings(raw={"regime": {"global_set": ["XBB", "Gamma"], "global_set_proposal": str(p)}})
    assert L3.global_set(reg, s) == ["Beta", "Gamma"]
    with warnings.catch_warnings():
        warnings.simplefilter("error")
        assert ST.country_tiers(pd.DataFrame({"iso": ["XBB"], "tier": ["EM"]})).tolist() == ["EM"]   # column wins
