"""Governance pack support: change log from the run archive and the inventory status (roadmap 2.5, 4.4)."""
import json
import sqlite3
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.persistence import Store  # noqa: E402
from econquest.validation.governance import change_log, write_change_log, settings_diff, inventory_status, LOG_COLUMNS  # noqa: E402

SEED = ROOT / "tests" / "seed_data"


def _insert(store, run_id, created, label, settings, versions, var99, es99, el=0.3, paths=2000):
    summary = {"run_id": run_id, "label": label, "created_at": created, "metrics": {"paths": paths, "var99_mm": var99, "es99_mm": es99, "expected_loss_mm": el},
               "global_regime": "Calm", "versions": versions}
    with sqlite3.connect(store.db) as c:
        c.execute("INSERT OR REPLACE INTO runs VALUES (?,?,?,?,?,?)", (run_id, created, label, json.dumps(settings), "{}", json.dumps(summary)))


def test_change_log_flags_and_diff(tmp_path):
    store = Store(tmp_path / "store")
    s1 = {"probability": {"w_m": 0.5, "w_s": 0.04}, "market": {"lgd_hard": 60.0}, "monte_carlo": {"paths": 100000}}
    s2 = {"probability": {"w_m": 0.4, "w_s": 0.04}, "market": {"lgd_hard": 60.0, "vol_cap": 60.0}, "monte_carlo": {"paths": 100000}}
    v1 = {"code_version": "0.1.0", "code_hash": "aaaa", "data_hash": "dddd"}
    v2 = {"code_version": "0.1.0", "code_hash": "bbbb", "data_hash": "dddd"}
    _insert(store, "r1-base", "2026-10-23T01:00:00+00:00", "base", s1, v1, 66.0, 85.0)
    _insert(store, "r1-stress-A", "2026-10-23T01:00:05+00:00", "stress-A", s1, v1, 124.0, 158.0)
    _insert(store, "r2-base", "2026-10-23T02:00:00+00:00", "base", s2, v2, 68.0, 87.0)
    df = change_log(store)
    assert list(df.columns) == LOG_COLUMNS and len(df) == 3
    assert list(df["run_id"]) == ["r2-base", "r1-stress-A", "r1-base"]          # newest first
    first = df.set_index("run_id").loc["r1-base"]
    assert not first["code_changed"] and not first["settings_changed"] and first["settings_diff"] == "first run with this label"
    second = df.set_index("run_id").loc["r2-base"]
    assert bool(second["code_changed"]) and not bool(second["data_changed"]) and bool(second["settings_changed"])
    assert "probability.w_m: 0.5 -> 0.4" in second["settings_diff"] and "market.vol_cap: absent -> 60.0" in second["settings_diff"]
    assert float(second["var99_mm"]) == 68.0 and second["code_hash"] == "bbbb"
    # the stress run is compared with the previous stress run of the same label, not with base: none, so first
    assert df.set_index("run_id").loc["r1-stress-A", "settings_diff"] == "first run with this label"
    out = write_change_log(df, tmp_path / "docs" / "change-log.md")
    text = out.read_text()
    assert text.startswith("# Change log of archived runs") and "| r2-base |" in text and sum(1 for ln in text.splitlines() if ln.startswith("| r") and not ln.startswith("| run_id")) == 3 and "code_changed" in text


def test_settings_diff_truncates():
    old = {"k%d" % i: i for i in range(60)}
    new = {"k%d" % i: i + 1 for i in range(60)}
    s = settings_diff(old, new, max_len=200)
    assert len(s) <= 215 and s.endswith("(60 keys)")
    assert settings_diff({"a": {"b": 1}}, {"a": {"b": 1}}) == ""


def test_real_run_and_inventory_status(tmp_path):
    from econquest.config import Settings
    from econquest.ingestion import load_universe
    from econquest.engine import run_pipeline
    u = load_universe(SEED); s = Settings.load(SEED / "assumptions.json", paths=2000)
    store = Store(tmp_path / "store")
    r1 = run_pipeline(u, s, label="base"); store.save_run(r1, keep_paths=False)
    r2 = run_pipeline(u, s.copy_with(**{"monte_carlo.df_calm": 30}), label="base")
    r2.run_id = r1.run_id + "-2"
    store.save_run(r2, keep_paths=False)      # same-second runs would share a run_id; give the second one its own
    df = change_log(store)
    assert len(df) == 2 and len(df["code_hash"].iloc[0]) == 16 and len(df["data_hash"].iloc[0]) == 16
    newest = df.iloc[0]
    assert not bool(newest["code_changed"]) and not bool(newest["data_changed"]) and bool(newest["settings_changed"])
    assert newest["settings_diff"] == "monte_carlo.df_calm: 5.0 -> 30"
    st = inventory_status(SEED, tmp_path)
    assert st["layer1"]["mode"] in ("paper_standardized", "fitted") and st["store"]["runs"] == 2
    assert st["store"]["latest_run_id"] == newest["run_id"] and st["store"]["code_hash_matches_latest_run"] is True
    assert isinstance(st["evidence"]["validation_docs"], int) and st["prediction_markets_live_mapped"] is False


def test_change_log_ignores_as_of_only_change(tmp_path):
    # EQ-B-0011: daily runs differ in settings.as_of only; that is not a settings change
    store = Store(tmp_path / "store")
    s = {"probability": {"w_m": 0.5}, "monte_carlo": {"paths": 100000}}
    v = {"code_version": "0.1.0", "code_hash": "aaaa", "data_hash": "dddd"}
    _insert(store, "d1-base", "2026-10-23T01:00:00+00:00", "base", {**s, "as_of": "2026-10-23"}, v, 66.0, 85.0)
    _insert(store, "d2-base", "2026-10-24T01:00:00+00:00", "base", {**s, "as_of": "2026-10-24"}, v, 66.0, 85.0)
    _insert(store, "d3-base", "2026-10-25T01:00:00+00:00", "base", {"probability": {"w_m": 0.4}, "monte_carlo": {"paths": 100000}, "as_of": "2026-10-25"}, v, 66.0, 85.0)
    df = change_log(store).set_index("run_id")
    assert not bool(df.loc["d2-base", "settings_changed"]) and df.loc["d2-base", "settings_diff"] == ""
    assert bool(df.loc["d3-base", "settings_changed"]) and "as_of" not in df.loc["d3-base", "settings_diff"]
    assert df.loc["d2-base", "as_of"] == "2026-10-24"          # EQ-B-0017: as_of column, from settings when versions lack it


def test_inventory_gate_uses_fit_hazard_constants():
    # EQ-B-0028: the inventory's gate figures come from hazard_panel, not a stale 0.70 literal
    from econquest.validation import governance as G
    from econquest.validation.hazard_panel import GATE_MIN_AUC, GATE_MIN_EVENTS
    assert GATE_MIN_AUC == 0.75 and GATE_MIN_EVENTS == 30
    assert G.GATE_MIN_AUC is GATE_MIN_AUC and "0.70" not in Path(G.__file__).read_text()


def test_inventory_status_reports_approvals_drift(tmp_path):
    # EQ-B-0032 (HO-20261023-C-B-006): governance status carries the econquest change drift check
    from econquest.validation.governance import inventory_status
    st = inventory_status(ROOT / "data", tmp_path)
    assert "approvals" in st and set(st["approvals"]) >= {"ok"}
    if st["approvals"].get("ok") is not None:
        assert "chain_ok" in st["approvals"] and isinstance(st["approvals"]["files"], dict)
