"""Trade-idea log (EQ-B-0038, GOV-032): entry, sizing, de-duplication, daily point-in-time marks, stop / target /
max-holding / stopped-firing exits and the hit-rate and P&L report, on a synthetic price fixture with hand-checkable
P&L and on the seed run with the real Market History prices."""
import math
import sys
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from econquest.validation import idea_log as IL  # noqa: E402

SEED = ROOT / "tests" / "seed_data"; PRICES = ROOT / "data" / "market_history" / "prices.csv"


class _S(dict):
    """Minimal Settings: [] and get(*keys, default) over a nested dict."""
    def get(self, *keys, default=None):
        node = self
        for k in keys:
            if not isinstance(node, dict) or k not in node:
                return default
            node = node[k]
        return node


S = _S({"signals": {"risk_budget_mm": 10, "unsized_stances": ["Hedge"], "regime_scalar": {"Calm": 1.0, "Stressed": 0.75, "Crisis": 0.5}}})

PLAYBOOK = pd.DataFrame([
    {"id": "TEQ", "strategy": "Overweight equities", "instrument": "Equity", "stance": "Risk-on", "horizon": "6-12 months"},
    {"id": "TFX", "strategy": "Long USD vs local", "instrument": "FX", "stance": "Risk-off", "horizon": "Event to 1 month"},
    {"id": "TCDS", "strategy": "Buy CDS protection", "instrument": "CDS", "stance": "Risk-off", "horizon": "Open-ended"},
    {"id": "THG", "strategy": "Political risk insurance", "instrument": "Any", "stance": "Hedge", "horizon": "12+ months"},
])
COUNTRIES = pd.DataFrame([{"country": "Aland", "iso": "ALA", "currency": "AAA", "etf": "EQA"},
                          {"country": "Bland", "iso": "BLA", "currency": "BBB", "etf": np.nan}])
U = SimpleNamespace(playbook=PLAYBOOK, countries=COUNTRIES)
D0 = pd.Timestamp("2026-04-01")                                                # first as_of (a Wednesday)


def _prices():
    """70 weekdays of history to D0 alternating 100 / 101 (EQA) and 4.00 / 4.04 (USDAAA), ending on 100 and 4.00,
    then a hand-set path after D0. USDBBB has no history before D0 + 1 (unmarked at entry on D0)."""
    hist = pd.bdate_range(end=D0, periods=70)
    eq = [100.0 if (len(hist) - 1 - i) % 2 == 0 else 101.0 for i in range(len(hist))]
    fx = [4.0 if (len(hist) - 1 - i) % 2 == 0 else 4.04 for i in range(len(hist))]
    px = pd.DataFrame({"EQA": eq, "USDAAA": fx, "USDBBB": np.nan}, index=hist)
    fut = pd.bdate_range(D0 + pd.Timedelta(days=1), periods=40)
    path_eq = [105.0, 110.0, 108.0] + [110.0] * 37
    path_fx = [4.4, 5.0, 5.0] + [5.0] * 37
    px = pd.concat([px, pd.DataFrame({"EQA": path_eq, "USDAAA": path_fx, "USDBBB": 7.0}, index=fut)])
    return px


def _run(as_of, firing, run_id=None, regime="Calm"):
    """A run dict in the RunResult.to_dict() shape: firing = {(trade, country): activated value}."""
    trades, ctry = list(PLAYBOOK["id"]), list(COUNTRIES["country"])
    act = [{"trade": t, **{c: firing.get((t, c)) for c in ctry}} for t in trades]
    dash = [{"country": c, "regime": regime, "notional_mm": 0.0} for c in ctry]
    return {"summary": {"run_id": run_id or f"run-{as_of}", "created_at": f"{as_of}T00:00:00", "as_of": as_of},
            "settings": {"as_of": as_of}, "activation": act, "dashboard": dash}


def _row(log, idea_prefix):
    m = log[log["idea_id"].str.startswith(idea_prefix)]
    assert len(m) == 1, m
    return m.iloc[0]


ALL = {("TEQ", "Aland"): 80.0, ("TFX", "Aland"): 60.0, ("TCDS", "Aland"): 70.0, ("THG", "Bland"): 90.0}


def test_horizon_and_instrument_rules():
    assert IL.max_hold_months("3-12 months", 12) == 12 and IL.max_hold_months("12+ months", 6) == 12
    assert IL.max_hold_months("Event to 1 month", 12) == 1 and IL.max_hold_months("Open-ended", 9) == 9
    assert IL.max_hold_months(np.nan, 9) == 9
    assert IL.instrument_ticker("FX", "Risk-off", "BRL", None)[:2] == ("USDBRL", 1)
    assert IL.instrument_ticker("FX", "Risk-on", "BRL", None)[:2] == ("USDBRL", -1)
    assert IL.instrument_ticker("Equity", "Risk-off", "BRL", "EWZ")[:2] == ("EWZ", -1)
    assert IL.instrument_ticker("Equity", "Risk-on", "BRL", np.nan)[0] == ""
    assert IL.instrument_ticker("CDS", "Risk-off", "BRL", "EWZ") == ("", 0, "no price series for instrument CDS")


def test_entry_is_point_in_time_with_dashboard_sizing_and_vol_stops():
    log = IL.update_log(IL.empty_log(), _run("2026-04-01", ALL), U, S, _prices())
    assert len(log) == 4 and (log["status"] == "open").all() and set(log["run_id"]) == {"run-2026-04-01"}
    eq, fx, cds, hg = (_row(log, p) for p in ("TEQ-ALA", "TFX-ALA", "TCDS-ALA", "THG-BLA"))
    assert eq["idea_id"] == "TEQ-ALA-20260401" and eq["stance"] == "Risk-on" and eq["instrument"] == "Equity"
    # entry on as_of, never the later 105 / 4.4
    assert eq["entry_date"] == D0 and eq["entry_price"] == 100.0 and fx["entry_price"] == 4.0
    # notional = 10 x value / 100 x regime scalar; hedges unsized
    assert eq["notional_mm"] == 8.0 and fx["notional_mm"] == 6.0 and cds["notional_mm"] == 7.0 and hg["notional_mm"] == 0.0
    # vol over 63 alternating returns of +-log(1.01), x sqrt(63); stop / target at 2x
    r = np.log(1.01) * np.array([1 if i % 2 else -1 for i in range(63)])
    vol = r.std(ddof=1) * math.sqrt(63)
    assert eq["vol_3m"] == pytest.approx(vol, rel=1e-9)
    assert eq["stop"] == pytest.approx(100 * math.exp(-2 * vol)) and eq["target"] == pytest.approx(100 * math.exp(2 * vol))
    assert eq["direction"] == 1 and fx["direction"] == 1 and eq["markable"] and fx["markable"]
    assert eq["max_exit_date"] == pd.Timestamp("2027-04-01") and fx["max_exit_date"] == pd.Timestamp("2026-05-01")
    assert not cds["markable"] and cds["unmarked_reason"] == "no price series for instrument CDS" and pd.isna(cds["pnl_mm"])
    assert hg["unmarked_reason"] == "no price series for instrument Any"


def test_regime_scalar_and_missing_price_series():
    run = _run("2026-04-01", {("TFX", "Bland"): 80.0}, regime="Crisis")
    log = IL.update_log(IL.empty_log(), run, U, S, _prices())
    r = log.iloc[0]
    assert r["notional_mm"] == 4.0                                              # 10 x 0.8 x 0.5
    assert not r["markable"] and r["unmarked_reason"].startswith("no USDBBB price")   # USDBBB starts after as_of
    log = IL.update_log(IL.empty_log(), run, U, S, _prices().drop(columns="USDBBB"))
    assert log.iloc[0]["unmarked_reason"] == "ticker USDBBB not in market history"


def test_daily_marks_are_point_in_time_and_hand_checkable():
    px = _prices()
    log = IL.update_log(IL.empty_log(), _run("2026-04-01", {("TEQ", "Aland"): 80.0}), U, S, px)
    marked, marks = IL.mark(log, px, "2026-04-03")                              # Thu 105, Fri 110; later prices unseen
    r = marked.iloc[0]
    assert list(marks["price"]) == [105.0, 110.0] and marks["date"].max() == pd.Timestamp("2026-04-03")
    assert r["mark_date"] == pd.Timestamp("2026-04-03") and r["mark_price"] == 110.0
    assert r["pnl_mm"] == pytest.approx(8.0 * 0.10) and r["return_pct"] == pytest.approx(10.0)
    assert list(marks["pnl_mm"]) == pytest.approx([0.4, 0.8])
    # changing every price after as_of does not change the mark
    px2 = px.copy(); px2.loc[px2.index > pd.Timestamp("2026-04-03"), "EQA"] = 1.0
    assert IL.mark(log, px2, "2026-04-03")[0].iloc[0]["pnl_mm"] == r["pnl_mm"]


def test_refire_does_not_duplicate_and_stopping_closes_at_that_days_price():
    px = _prices()
    log = IL.update_log(IL.empty_log(), _run("2026-04-01", {("TEQ", "Aland"): 80.0}), U, S, px)
    log = IL.update_log(log, _run("2026-04-02", {("TEQ", "Aland"): 85.0}), U, S, px)
    assert len(log) == 1 and log.iloc[0]["status"] == "open" and log.iloc[0]["notional_mm"] == 8.0   # sized at entry
    assert log.iloc[0]["last_fired_as_of"] == pd.Timestamp("2026-04-02")
    log = IL.update_log(log, _run("2026-04-06", {}), U, S, px)                 # Mon: stops firing, EQA 108
    r = log.iloc[0]
    assert r["status"] == "closed" and r["close_reason"] == "stopped_firing" and r["close_run_id"] == "run-2026-04-06"
    assert r["close_price"] == 108.0 and r["pnl_mm"] == pytest.approx(8.0 * 0.08)
    # firing again after it stopped opens a new idea
    log = IL.update_log(log, _run("2026-04-07", {("TEQ", "Aland"): 70.0}), U, S, px)
    assert len(log) == 2 and _row(log, "TEQ-ALA-20260407")["entry_price"] == 110.0


def test_fx_pnl_target_exit_and_no_reentry_until_it_stops_firing():
    px = _prices()
    run = {("TFX", "Aland"): 60.0}
    log = IL.update_log(IL.empty_log(), _run("2026-04-01", run), U, S, px)
    fx = log.iloc[0]
    assert fx["target"] == pytest.approx(4.0 * math.exp(2 * fx["vol_3m"]))     # about 4.69
    log = IL.update_log(log, _run("2026-04-03", run), U, S, px)                # 4.4 on Thu (open), 5.0 on Fri: target
    r = log.iloc[0]
    assert r["status"] == "closed" and r["close_reason"] == "target" and r["close_date"] == pd.Timestamp("2026-04-03")
    assert r["close_price"] == 5.0 and r["pnl_mm"] == pytest.approx(6.0 * (1 - 4.0 / 5.0))   # long USD: 1.2 $mm
    assert not r["rearm"] and len(log) == 1                                     # still firing: no re-entry
    log = IL.update_log(log, _run("2026-04-06", run), U, S, px)
    assert len(log) == 1
    log = IL.update_log(log, _run("2026-04-07", {}), U, S, px)                 # stops firing: re-armed
    assert bool(log.iloc[0]["rearm"]) and log.iloc[0]["close_reason"] == "target"
    log = IL.update_log(log, _run("2026-04-08", run), U, S, px)
    assert len(log) == 2 and (log["status"] == "open").sum() == 1


def test_stop_exit_short_side():
    px = _prices()
    pb = PLAYBOOK.copy(); pb.loc[pb["id"] == "TEQ", "stance"] = "Risk-off"     # short EQA
    u = SimpleNamespace(playbook=pb, countries=COUNTRIES)
    px.loc[pd.Timestamp("2026-04-03"), "EQA"] = 120.0                           # through the stop at about 117.2
    log = IL.update_log(IL.empty_log(), _run("2026-04-01", {("TEQ", "Aland"): 80.0}), u, S, px)
    log, _ = IL.mark(log, px, "2026-04-10")
    r = log.iloc[0]
    assert r["direction"] == -1 and r["close_reason"] == "stop" and r["close_price"] == 120.0
    assert r["pnl_mm"] == pytest.approx(-8.0 * 0.20) and r["return_pct"] == pytest.approx(-20.0)


def test_max_holding_period_closes_marked_and_unmarked_ideas():
    px = _prices()
    run = {("TFX", "Aland"): 60.0, ("TCDS", "Aland"): 70.0}
    s = _S({**S, "ideas": {"target_vol_mult": 100.0, "stop_vol_mult": 100.0, "default_max_hold_months": 1}})
    log = IL.update_log(IL.empty_log(), _run("2026-04-01", run), U, s, px)
    log, _ = IL.mark(log, px, "2026-04-30")
    assert (log["status"] == "open").all()
    log, _ = IL.mark(log, px, "2026-05-04")                                     # first weekday at or after 2026-05-01
    fx, cds = _row(log, "TFX"), _row(log, "TCDS")
    assert fx["close_reason"] == "max_holding" and fx["close_date"] == pd.Timestamp("2026-05-01") and fx["close_price"] == 5.0
    assert cds["close_reason"] == "max_holding" and pd.isna(cds["close_price"])


def test_report_hit_rate_pnl_by_id_and_stance_and_unmarked_share(tmp_path):
    px = _prices()
    log = IL.update_log(IL.empty_log(), _run("2026-04-01", ALL), U, S, px)
    log = IL.update_log(log, _run("2026-04-06", {("TEQ", "Aland"): 80.0, ("TCDS", "Aland"): 70.0, ("THG", "Bland"): 90.0}), U, S, px)
    # TFX hit its target on Fri 2026-04-03 (+1.2); TEQ open at 108 (+0.64); TCDS / THG unmarked
    rep = IL.write_report(log, tmp_path, "2026-04-06")
    a = rep.iloc[0]
    assert (a["ideas"], a["open"], a["closed"], a["marked"], a["unmarked"]) == (4, 3, 1, 2, 2)
    assert a["unmarked_share"] == 0.5 and a["hit_rate"] == 1.0 and a["closed_marked"] == 1
    assert a["pnl_realised_mm"] == pytest.approx(1.2) and a["pnl_open_mm"] == pytest.approx(0.64)
    assert a["pnl_total_mm"] == pytest.approx(1.84) and a["n_target"] == 1
    by_id = rep[rep["group"] == "playbook_id"].set_index("key")
    assert by_id.at["TFX", "hit_rate"] == 1.0 and np.isnan(by_id.at["TEQ", "hit_rate"]) and by_id.at["TEQ", "hit_rate_incl_open"] == 1.0
    assert by_id.at["TCDS", "unmarked_share"] == 1.0 and by_id.at["TEQ", "label"] == "Overweight equities"
    by_stance = rep[rep["group"] == "stance"].set_index("key")
    assert by_stance.at["Risk-off", "ideas"] == 2 and by_stance.at["Risk-off", "pnl_total_mm"] == pytest.approx(1.2)
    assert by_stance.at["Risk-off", "unmarked_share"] == 0.5 and by_stance.at["Hedge", "unmarked"] == 1
    md = (tmp_path / "idea_report.md").read_text()
    assert "Illustrative" in md and "50% unmarked" in md and "| TFX Long USD vs local |" in md
    assert (tmp_path / "idea_report.csv").exists()


def test_log_roundtrips_through_csv_and_log_run_is_idempotent(tmp_path):
    px = _prices()
    run = _run("2026-04-01", ALL)
    lg1 = IL.log_run(run, U, S, px, tmp_path, log=lambda *_: None)
    loaded = IL.load_log(tmp_path / "idea_log.csv")
    assert len(loaded) == 4 and loaded["markable"].sum() == 2 and loaded["entry_date"].dtype.kind == "M"
    lg2 = IL.log_run(run, U, S, px, tmp_path, log=lambda *_: None)            # same run again: no duplicates
    assert len(lg2) == 4 and list(lg2["idea_id"]) == list(lg1["idea_id"])
    lg3 = IL.log_run(_run("2026-04-03", ALL), U, S, px, tmp_path, log=lambda *_: None)
    assert len(lg3) == 4 and _row(lg3, "TFX")["close_reason"] == "target"


def test_run_without_dashboard_is_refused():
    run = _run("2026-04-01", ALL); run["dashboard"] = None
    with pytest.raises(ValueError, match="no dashboard"):
        IL.run_ideas(run, U, S)


@pytest.mark.skipif(not PRICES.exists(), reason="market history not present")
def test_seed_run_with_real_prices(tmp_path):
    from econquest.config import Settings
    from econquest.ingestion import load_universe
    from econquest.engine import run_pipeline
    u = load_universe(SEED); s = Settings.load(SEED / "assumptions.json")
    r = run_pipeline(u, s, paths=500, as_of="2026-10-23")
    px = pd.read_csv(PRICES, parse_dates=["date"], index_col="date")
    log = IL.update_log(IL.empty_log(), r, u, s, px)
    assert len(log) == int(r.activation.notna().sum().sum()) and log["idea_id"].is_unique
    # the country's dashboard notional is the largest of its ideas' notionals
    mx = log.groupby("country")["notional_mm"].max()
    np.testing.assert_allclose(mx.to_numpy(), r.dashboard.loc[mx.index, "notional_mm"].to_numpy(), atol=0.011)
    m = log[log["markable"]]
    assert set(m["instrument"]) <= {"FX", "Equity"} and (m["entry_date"] <= pd.Timestamp("2026-10-23")).all()
    assert m["stop"].notna().all() and m["target"].notna().all()
    assert set(log.loc[~log["markable"], "instrument"]) <= {"CDS", "Eurobond", "Local rates", "FX options", "Any"}
    # same run again: no duplicates; the share markable is what the report states
    log2 = IL.update_log(log, r, u, s, px)
    assert len(log2) == len(log)
    rep = IL.write_report(log2, tmp_path, "2026-10-23")
    assert rep.iloc[0]["unmarked_share"] == pytest.approx(1 - len(m) / len(log))
    assert 0 < len(m) < len(log)


def test_mark_log_advances_the_saved_log(tmp_path):
    px = _prices()
    IL.log_run(_run("2026-04-01", {("TEQ", "Aland"): 80.0}), U, S, px, tmp_path, log=lambda *_: None)
    a = IL.write_report(IL.load_log(tmp_path / "idea_log.csv"), tmp_path).iloc[0]
    assert np.isnan(a["hit_rate_incl_open"])                                    # not marked after entry yet
    lg = IL.mark_log(tmp_path, px, "2026-04-02", log=lambda *_: None)
    assert lg.iloc[0]["mark_price"] == 105.0 and IL.load_log(tmp_path / "idea_log.csv").iloc[0]["pnl_mm"] == pytest.approx(0.4)
    assert "P&L 0.40 $mm" in (tmp_path / "idea_report.md").read_text()


def test_mark_to_an_earlier_day_keeps_the_report_date_and_report_is_formula_safe(tmp_path):
    # Team C (EQ-C-0043): `ideas mark` without --as-of marks to the last complete price day, which can be before the
    # latest run's as_of; the report's As of must not move back. AGENT-09: text cells are escaped for spreadsheets.
    px = _prices()
    IL.log_run(_run("2026-04-01", {("TEQ", "Aland"): 80.0}), U, S, px, tmp_path, log=lambda *_: None)
    msgs = []
    IL.mark_log(tmp_path, px, "2026-03-31", log=msgs.append)
    assert "2026-04-01" in msgs[0] and "2026-03-31" not in (tmp_path / "idea_report.md").read_text()
    t = pd.DataFrame({"label": ["=HYPERLINK(1)", "+1", "-x", "@a", "ok"], "n": [1, 2, 3, 4, 5]})
    assert list(IL._csv_safe(t)["label"]) == ["'=HYPERLINK(1)", "'+1", "'-x", "'@a", "ok"]
