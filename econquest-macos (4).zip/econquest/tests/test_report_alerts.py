"""Daily risk report (roadmap 4.2) and alerts (4.3)."""
import copy
import json
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.config import Settings  # noqa: E402
from econquest.ingestion import load_universe  # noqa: E402
from econquest.engine import run_pipeline  # noqa: E402
from econquest.validation.alerts import detect_alerts, deliver_alerts, alert_settings, DEFAULTS  # noqa: E402
from econquest.presentation.report import build_report  # noqa: E402

DATA = ROOT / "data"


def _run_dict(regime_b="Calm", pd_b=0.05, var99=60.0, es99=80.0, sig_b=50.0, global_regime="Calm", run_id="r1"):
    return {"summary": {"run_id": run_id, "label": "base", "created_at": "2026-10-23T09:00:00+00:00", "global_regime": global_regime,
                        "metrics": {"var99_mm": var99, "es99_mm": es99, "var95_mm": 30.0, "es95_mm": 45.0}},
            "country": [{"country": "A", "regime": "Calm", "pd_default": 0.01}, {"country": "B", "regime": regime_b, "pd_default": pd_b}],
            "signals": [{"key": 1, "A": 10.0, "B": sig_b}],
            "activation": [{"trade": "T01", "A": None, "B": 70.0 if sig_b >= 60 else None}]}


def _failing_record(n=60):
    dates = pd.bdate_range("2026-01-05", periods=n)
    loss = np.full(n, 0.5); loss[::5] = 3.0                   # 12 exceedances of a 1.0 VaR in 60 days: Kupiec fails, zone red
    return pd.DataFrame({"date": dates, "loss": loss, "var": 1.0, "es": 1.3, "var_next": 1.0, "es_next": 1.3})


def _passing_record(n=60):
    dates = pd.bdate_range("2026-01-05", periods=n)
    return pd.DataFrame({"date": dates, "loss": np.full(n, 0.2), "var": 1.0, "es": 1.3, "var_next": 1.0, "es_next": 1.3})


def test_alert_defaults_from_assumptions():
    s = Settings.load(DATA / "assumptions.json")
    cfg = alert_settings(s)
    assert cfg["pd_change_pp"] == 2.0 and cfg["var_change_pct"] == 10.0 and cfg["signal_threshold"] == s["signals"]["threshold"]
    assert alert_settings(None)["pd_change_pp"] == DEFAULTS["pd_change_pp"]
    seed = json.loads((ROOT / "tests" / "seed_data" / "assumptions.json").read_text())
    assert seed["alerts"]["pd_change_pp"] == 2.0


def test_alerts_detected_on_synthetic_pair():
    prev = _run_dict()
    cur = _run_dict(regime_b="Crisis", pd_b=0.30, var99=70.0, es99=81.0, sig_b=75.0, global_regime="Stressed", run_id="r2")
    settings = {"signals": {"threshold": 60}, "alerts": {"pd_change_pp": 2.0, "var_change_pct": 10.0}}
    alerts = detect_alerts(cur, prev, _failing_record(), settings,
                           review=pd.DataFrame([{"table": "Inputs", "key": "1.3", "country": "B", "seed": 1.0, "live": 9.0, "status": "hold", "reason": "change", "decision": ""}]),
                           feeds={"feeds": {"weo": "ok (10 rows)", "bis": "error: timeout"}, "retrieved": "2026-10-23"})
    kinds = {a["kind"] for a in alerts}
    assert {"regime_flip", "pd_change", "pd_level", "signal_cross", "trade_activation", "var_change", "backtest_fail", "basel_zone", "quality_hold", "feed_failure"} <= kinds
    flips = [a for a in alerts if a["kind"] == "regime_flip"]
    assert {a["scope"] for a in flips} == {"global", "B"} and all(a["country"] in (None, "B") for a in flips)
    b_flip = next(a for a in flips if a["scope"] == "B"); assert b_flip["severity"] == "critical" and b_flip["value"] == "Crisis"
    pdc = next(a for a in alerts if a["kind"] == "pd_change"); assert pdc["country"] == "B" and pdc["value"] == pytest.approx(25.0) and pdc["threshold"] == 2.0 and pdc["severity"] == "critical"
    var = [a for a in alerts if a["kind"] == "var_change"]
    assert len(var) == 1 and "VaR99" in var[0]["message"] and var[0]["value"] == pytest.approx(100 / 6) and var[0]["threshold"] == 10.0   # ES99 moved 1.25%: no alert
    bt = [a for a in alerts if a["kind"] == "backtest_fail"]; assert any("Kupiec" in a["message"] for a in bt) and all(a["severity"] == "critical" for a in bt)
    zone = next(a for a in alerts if a["kind"] == "basel_zone"); assert zone["threshold"] == "Red" and zone["severity"] == "critical"
    sig = next(a for a in alerts if a["kind"] == "signal_cross"); assert sig["country"] == "B" and sig["threshold"] == 60.0 and "Debt payment wall" in sig["message"]
    assert all(set(a) >= {"severity", "kind", "scope", "country", "message", "value", "threshold"} for a in alerts)
    assert all(a["severity"] in ("info", "warning", "critical") for a in alerts)
    ranks = [{"critical": 0, "warning": 1, "info": 2}[a["severity"]] for a in alerts]; assert ranks == sorted(ranks)
    assert all(a["run_id"] == "r2" and a["previous_run_id"] == "r1" for a in alerts)


def test_no_alerts_when_nothing_changed():
    prev = _run_dict(); cur = copy.deepcopy(prev); cur["summary"]["run_id"] = "r2"
    assert detect_alerts(cur, prev, _passing_record(), {"signals": {"threshold": 60}}, review=pd.DataFrame(columns=["status"]), feeds={"feeds": {"weo": "ok"}}) == []
    # a bare summary pair (what Store.runs lists) also works and stays quiet
    assert detect_alerts(cur["summary"], prev["summary"], None, None) == []
    # too short a record: no backtest alert
    assert detect_alerts(cur, prev, _failing_record(10), None) == []


def test_deliver_alerts_writes_json_and_survives_failed_webhook(tmp_path, capsys):
    alerts = detect_alerts(_run_dict(var99=69.0, run_id="r2"), _run_dict(), None, None)      # +15%: warning
    assert len(alerts) == 1
    st = deliver_alerts(alerts, None, env={"ECONQUEST_ALERT_WEBHOOK": "http://127.0.0.1:9/hook"}, out_dir=tmp_path, run_id="r2")
    out = json.loads((tmp_path / "alerts.json").read_text())
    assert out["alerts"][0]["kind"] == "var_change" and out["counts"]["warning"] == 1 and out["run_id"] == "r2"
    assert st["webhook"].startswith("error") and st["email"].startswith("not configured")
    text = capsys.readouterr().out
    assert "1 warning" in text and "VaR99" in text and "webhook delivery failed" in text
    st2 = deliver_alerts([], None, env={}, out_dir=tmp_path, webhook=False, email=False)
    assert st2["webhook"] == "skipped" and json.loads((tmp_path / "alerts.json").read_text())["alerts"] == []


@pytest.fixture(scope="module")
def real_run():
    u = load_universe(DATA); s = Settings.load(DATA / "assumptions.json")
    return run_pipeline(u, s, paths=4000)


def test_report_written_with_headline_numbers_and_alerts(tmp_path, real_run):
    res = real_run; m = res.metrics
    r = build_report(DATA, tmp_path, run=res, log=lambda *a: None)
    html_path, md_path, latest = Path(r["html"]), Path(r["md"]), Path(r["latest"])
    assert html_path.exists() and md_path.exists() and latest.exists()
    assert html_path.name == f"risk-report-{res.created_at[:10]}.html" and html_path.parent == tmp_path / "reports"
    html = html_path.read_text(encoding="utf-8")
    assert html == latest.read_text(encoding="utf-8")
    assert html.startswith("<!doctype html>") and "<link" not in html and "<script" not in html and "<style>" in html   # self-contained
    for key in ("var95_mm", "var99_mm", "es95_mm", "es99_mm", "es975_frtb_mm", "lvar99_mm", "expected_loss_mm"):
        assert f"{m[key]:,.1f}" in html
    assert res.diagnostics["global_regime"] in html and "Global regime" in html
    v = res.provenance["versions"]
    assert v["code_hash"] in html and v["data_hash"] in html and v["code_version"] in html
    for section in ("<h2>Headline</h2>", "<h2>Changes since the previous run</h2>", "<h2>Country risk</h2>", "<h2>Positions</h2>", "<h2>Backtest status", "<h2>Data issues</h2>", "<h2>Alerts</h2>"):
        assert section in html
    assert "Top five contributors" in html and "<svg" in html
    for c in res.country.index:
        assert c in html
    top = res.mc.contributions.sort_values("tail_contribution_99_mm", ascending=False).head(5)
    for pid in top.index:
        assert f"<td>{pid}</td>" in html
    # no previous run in an empty store: the changes section says so and the alerts section is still present
    assert r["previous_run_id"] is None and "No previous archived run" in html
    assert isinstance(r["alerts"], list) and all(a["severity"] in ("info", "warning", "critical") for a in r["alerts"])
    if r["alerts"]:
        assert all(a["message"][:40] in html or a["message"][:40].replace("&", "&amp;") in html for a in r["alerts"])
    else:
        assert "No alerts" in html
    # data issues from data/live/review.csv and feeds.json are reported when present
    if (DATA / "live" / "feeds.json").exists():
        assert "Feeds (last pull" in html
    md = md_path.read_text(encoding="utf-8")
    assert md.startswith("# EconQuest daily risk report") and f"{m['var99_mm']:,.1f}" in md and "## Alerts" in md and "## Country risk" in md


def test_report_from_archived_run_and_alerts_passed_in(tmp_path, real_run):
    from econquest.persistence import Store
    store = Store(tmp_path / "store"); store.save_run(real_run, keep_paths=False)
    custom = [{"severity": "critical", "kind": "regime_flip", "scope": "global", "country": None, "message": "Global regime moved from Calm to Crisis", "value": "Crisis", "threshold": "Calm"}]
    r = build_report(DATA, tmp_path, run=None, alerts=custom, log=lambda *a: None)
    assert r["run_id"] == real_run.run_id and not r["fresh_run"]
    html = Path(r["html"]).read_text(encoding="utf-8")
    assert "Global regime moved from Calm to Crisis" in html and "1 critical" in html
