"""EQ-A-0025 / EQ-A-0026: universe proposal validation, coverage report, offline staging and missing-cell report.
All offline: feeds are replaced by synthetic long tables."""
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.ingestion import load_universe, feeds  # noqa: E402
from econquest.ingestion.universe import (  # noqa: E402
    DEFAULT_PROPOSAL, ESTIMATE_TAG, coverage_report, expand_countries, indicator_sources, load_universe_proposal,
    main, missing_cell_report, stage_data_dir, validate_profile_tiers, validate_universe)

DATA = ROOT / "data"


@pytest.fixture(scope="module")
def prop():
    return load_universe_proposal(DEFAULT_PROPOSAL)


def test_proposal_is_valid_and_covers_desk(prop):
    assert validate_universe(prop, data_dir=DATA) == []
    desk = pd.read_csv(DATA / "countries.csv")
    assert set(desk["iso"]) <= set(prop["iso3"])
    assert 70 <= len(prop) <= 90
    assert (prop.loc[prop["tier"] != "desk_current", "basis"].str.contains(ESTIMATE_TAG, regex=False)).all()
    assert {"USA", "DEU", "JPN", "GBR"} <= set(prop["iso3"])


def test_namibia_iso2_not_parsed_as_missing(prop):
    assert prop.set_index("iso3").at["NAM", "iso2"] == "NA"


@pytest.mark.parametrize("mutate,needle", [
    (lambda d: d.drop(d.index[d["iso3"] == "VNM"]), "Vietnam (VNM) missing"),
    (lambda d: d.assign(iso2=d["iso2"].where(d["iso3"] != "MEX", "BR")), "duplicate iso2"),
    (lambda d: d.assign(iso3=d["iso3"].where(d["iso3"] != "MEX", "MX1")), "bad iso3 format"),
    (lambda d: d.assign(rating_bucket=d["rating_bucket"].where(d["iso3"] != "MEX", "BBB")), "rating_bucket not in"),
    (lambda d: d.assign(fx_regime=d["fx_regime"].where(d["iso3"] != "MEX", "crawl")), "fx_regime not in"),
    (lambda d: d.assign(yahoo_fx=d["yahoo_fx"].where(d["iso3"] != "MEX", "MXN")), "bad yahoo_fx format"),
    (lambda d: d.assign(notes=d["notes"].where(d["iso3"] != "MEX", "=HYPERLINK(1)")), "formula character"),
    (lambda d: d.assign(basis=d["basis"].where(d["iso3"] != "MEX", "memory")), "basis lacks"),
    (lambda d: d.assign(tier=d["tier"].where(d["iso3"] != "VNM", "EM")), "VNM is a desk country"),
    (lambda d: d.assign(name=d["name"].where(d["iso3"] != "KOR", "Korea")), "KOR name"),
    (lambda d: d.assign(bis_iso2=d["bis_iso2"].where(d["iso3"] != "MEX", "XX")), "bis_iso2 differs"),
    (lambda d: d.head(40), "40 rows"),
])
def test_validate_catches(prop, mutate, needle):
    problems = validate_universe(mutate(prop.copy()), data_dir=DATA)
    assert any(needle in p for p in problems), problems


def test_indicator_sources_classify_every_rulebook_id():
    src = indicator_sources(DATA)
    rb = pd.read_csv(DATA / "rulebook.csv", dtype={"id": str})
    assert set(src["id"]) == set(rb["id"])
    assert set(src["source_class"]) <= {"weo", "worldbank", "bis", "manual", "planned_api"}
    assert set(src.loc[src["source_class"] == "bis", "id"]) == {"2.12", "5.9", "5.13"}
    assert src.set_index("id").at["1.1", "source_class"] == "manual"


def test_coverage_report_rules(prop):
    rep = coverage_report(prop, DATA)
    c = rep.countries.set_index("iso3")
    n = rep.summary["n_indicators"]
    assert len(c) == len(prop) and n == 83
    # BIS confirmed only where raw_bis returned the series today
    assert c.at["BRA", "bis"] == "confirmed" and c.at["LKA", "bis"] == "N"
    # high income loses the IDS id(s); upper bound >= expected
    assert c.at["USA", "upper_bound_live"] < c.at["MEX", "upper_bound_live"]
    assert (c["upper_bound_live"] >= c["expected_live"]).all()
    assert (c["expected_live"] <= len(rep.summary["feed_backed_ids"])).all()
    # shared Yahoo tickers are listed, and since EQ-A-0027 (FX keyed by country) every sharer is served
    assert c.at["CIV", "yahoo_fx"] == "Y" and c.at["SEN", "yahoo_fx"] == "Y" and "XOF=X" in rep.summary["shared_yahoo_tickers"]
    assert c.at["PAN", "yahoo_fx"] == "N"
    assert 0 < rep.summary["pct_expected_overall"] <= rep.summary["pct_upper_overall"] < 1
    assert rep.summary["cells_per_country_for_target"] == int(np.ceil(0.6 * n))


def test_coverage_dead_ids_from_provenance(prop, tmp_path):
    (tmp_path / "live").mkdir()
    (tmp_path / "rulebook.csv").write_bytes((DATA / "rulebook.csv").read_bytes())
    pd.DataFrame([{"table": "Inputs", "key": "1.3", "country": "Vietnam", "value": 1.0}]).to_csv(tmp_path / "live" / "provenance.csv", index=False)
    rep = coverage_report(prop, tmp_path)
    assert "1.3" not in rep.summary["dead_feed_ids"] and "5.5" in rep.summary["dead_feed_ids"]
    assert (rep.countries["bis"] != "confirmed").all()          # no raw_bis.csv -> nothing confirmed


@pytest.fixture(scope="module")
def staged(tmp_path_factory, prop):
    root = tmp_path_factory.mktemp("universe")
    res = expand_countries(DEFAULT_PROPOSAL, DATA, root / "staging")
    return root, res


def test_expand_writes_only_staging(staged, prop):
    root, res = staged
    st = Path(res["out_dir"])
    assert res["n_total"] == len(prop) and res["n_desk"] == len(pd.read_csv(DATA / "countries.csv"))
    cty = pd.read_csv(st / "countries.csv", dtype=str, keep_default_na=False)
    desk = pd.read_csv(DATA / "countries.csv", dtype=str, keep_default_na=False)
    assert list(cty.columns) == list(desk.columns)
    pd.testing.assert_frame_equal(cty.head(len(desk)), desk)                # desk rows unchanged
    ind = pd.read_csv(st / "indicators.csv", dtype={"id": str})
    new = [n for n in prop["name"] if n not in set(desk["country"])]
    assert set(new) <= set(ind.columns) and ind[new].isna().all().all()     # seeds blank, filled by the fetch
    tur = cty.set_index("iso").loc["TUR"]
    assert tur["fxregime"] == "" and cty.set_index("iso").at["SAU", "fxregime"] == "Peg"
    cells = pd.read_csv(st / "cells_to_fill.csv", dtype={"key": str})
    one = cells[(cells["country"] == "Mexico") & (cells["table"] == "Inputs")]
    assert len(one) == 83 and one.set_index("key").at["1.1", "status"] == "manual"
    assert one.set_index("key").at["1.3", "status"] == "awaiting_fetch"
    m = json.loads((st / "manifest.json").read_text())
    assert m["n_new"] == len(new) and "candidate" in m["status"]


TIERS = {"desk_current", "EM", "frontier", "DM_anchor"}


def test_profile_tier_column_staged_and_live(staged, prop):
    """HO-20261023-B-A-008: the staged and live Country Profile carry `tier` = proposal tier per ISO3; desk rows
    (Japan included) desk_current; Namibia's iso2 'NA' survives; load_universe keeps the column."""
    root, res = staged
    cty = pd.read_csv(Path(res["out_dir"]) / "countries.csv", dtype=str, keep_default_na=False)
    assert set(cty["tier"]) == TIERS and validate_profile_tiers(cty, prop) == []
    t = cty.set_index("iso")
    assert t.at["JPN", "tier"] == "desk_current" and t.at["USA", "tier"] == "DM_anchor" and t.at["NAM", "iso2"] == "NA"
    assert (cty.head(res["n_desk"])["tier"] == "desk_current").all()
    desk = pd.read_csv(DATA / "countries.csv", dtype=str, keep_default_na=False)
    assert (desk["tier"] == "desk_current").all() and validate_profile_tiers(desk, prop) == []
    assert (load_universe(DATA).countries["tier"] == "desk_current").all()
    cells = pd.read_csv(Path(res["out_dir"]) / "cells_to_fill.csv", dtype={"key": str})
    assert not ((cells["table"] == "Country Profile") & (cells["key"] == "tier")).any()   # filled from the proposal


def test_profile_tier_validator_flags_mismatch(prop):
    desk = pd.read_csv(DATA / "countries.csv", dtype=str, keep_default_na=False)
    bad = desk.copy(); bad.loc[bad["iso"] == "JPN", "tier"] = "DM_anchor"; bad.loc[bad["iso"] == "VNM", "tier"] = ""
    probs = validate_profile_tiers(bad, prop)
    assert any("JPN profile tier DM_anchor differs from proposal tier desk_current" in p for p in probs)
    assert any("VNM profile tier ''" in p for p in probs)
    assert any("JPN" in p for p in validate_universe(prop, desk=bad))
    assert validate_profile_tiers(desk.drop(columns="tier"), prop) == ["Country Profile has no 'tier' column"]
    assert validate_universe(prop, desk=desk.drop(columns="tier")) == []      # a profile without the column is still valid


def test_expand_refuses_live_folder(tmp_path):
    with pytest.raises(ValueError, match="live data folder"):
        expand_countries(DEFAULT_PROPOSAL, DATA, DATA)
    bad = load_universe_proposal(DEFAULT_PROPOSAL).head(10)
    with pytest.raises(ValueError, match="failed validation"):
        expand_countries(bad, DATA, tmp_path / "s")


def _fake_long(isos, series, period, value):
    return feeds._long([{"iso": i, "series": s, "period": period, "value": value} for i in isos for s in series], "fake")


def test_stage_fetch_and_missing_report(staged, monkeypatch):
    """Offline end to end: staged universe loads, fetch_all fills WEO cells for every country, the gate runs, and
    the missing-cell report counts live cells per country against the 60% target."""
    root, res = staged
    dest = stage_data_dir(res["out_dir"], root / "data", DATA)
    with pytest.raises(FileExistsError):
        stage_data_dir(res["out_dir"], dest, DATA)
    with pytest.raises(ValueError):
        stage_data_dir(res["out_dir"], DATA / "sub", DATA)
    u = load_universe(dest)
    assert len(u.names) == res["n_total"]

    def weo(self, isos, codes=feeds.WEO_CODES):
        rows = [{"iso": i, "series": s, "period": y, "value": 50.0 + (y % 3)} for i in isos for s in codes for y in range(2005, 2029)]
        return feeds._long(rows, "fake weo")
    monkeypatch.setattr(feeds.WeoFeed, "fetch", weo)
    rep = feeds.fetch_all(u, only=["weo"], year=2026, log=lambda *_: None)
    diff = feeds.diff_against_seed(u, rep)
    review = feeds.quality_gate(u, rep, diff, year=2026)
    feeds.save_report(rep, dest, diff)
    review.to_csv(dest / "live" / "review.csv", index=False)
    assert (DATA / "countries.csv").read_bytes() != (dest / "countries.csv").read_bytes()
    mr = missing_cell_report(dest)
    c = mr.countries.set_index("country")
    assert len(c) == res["n_total"]
    assert c.at["Turkey", "live"] >= 5 and not c.at["Turkey", "meets_target"]
    reasons = set(mr.cells.loc[mr.cells["country"] == "Turkey", "reason"])
    assert {"manual", "planned_api", "worldbank returned no value"} <= reasons
    assert (mr.cells.loc[mr.cells["country"] == "Turkey", "seed_present"] == "N").all()
    assert 0 < mr.summary["pct_live_overall"] < 0.6


def test_missing_report_needs_a_fetch(tmp_path):
    with pytest.raises(FileNotFoundError, match="fetch"):
        missing_cell_report(tmp_path)


def test_cli_validate(capsys):
    assert main(["validate", "--proposal", str(DEFAULT_PROPOSAL), "--data", str(DATA)]) == 0
    assert "valid" in capsys.readouterr().out


# ---------------------------------------------------------------------------------------------------- EQ-A-0028 (HO-20261023-B-A-007)
def test_mark_blocking_maps_readiness_fields_to_cells():
    from econquest.ingestion.universe import mark_blocking
    cells = pd.DataFrame([
        {"table": "Inputs", "key": "1.3", "country": "Ghana", "iso3": "GHA", "source_class": "weo", "status": "awaiting_fetch", "note": ""},
        {"table": "Inputs", "key": "1.1", "country": "Ghana", "iso3": "GHA", "source_class": "manual", "status": "manual", "note": ""},
        {"table": "Country Profile", "key": "default", "country": "Ghana", "iso3": "GHA", "source_class": "hand-entered", "status": "manual", "note": ""},
        {"table": "Country Profile", "key": "rating", "country": "Ghana", "iso3": "GHA", "source_class": "hand-entered", "status": "manual", "note": ""},
        {"table": "Country Profile", "key": "elmonths", "country": "Ghana", "iso3": "GHA", "source_class": "hand-entered", "status": "manual", "note": ""}])
    rd = pd.DataFrame([("Ghana", "indicator 1.3", "indicator", True), ("Ghana", "flag default", "flag", True),
                       ("Ghana", "rating (unknown 'Z')", "profile", True), ("Ghana", "pillar 2 (no scored indicator)", "pillar", True),
                       ("Ghana", "elmonths", "profile", False), ("Ghana", "indicator 1.1", "indicator", False)],
                      columns=["country", "field", "kind", "blocking"])
    out = mark_blocking(cells, rd)
    b = dict(zip(zip(out["table"], out["key"]), out["blocking"]))
    assert b[("Inputs", "1.3")] and b[("Country Profile", "default")] and b[("Country Profile", "rating")]
    assert not b[("Inputs", "1.1")] and not b[("Country Profile", "elmonths")]
    extra = out[out["table"] == "Readiness"]
    assert list(extra["key"]) == ["pillar 2 (no scored indicator)"] and extra["blocking"].all() and extra["iso3"].iloc[0] == "GHA"
    assert int(out["blocking"].sum()) == int(rd["blocking"].sum())        # one row per blocking field


def test_staged_cells_to_fill_blocking_matches_readiness():
    from econquest.ingestion.universe import staged_readiness
    if not ((DATA / "panel" / "universe_staging") / "cells_to_fill.csv").exists():
        pytest.skip("staging not built")
    cells = pd.read_csv((DATA / "panel" / "universe_staging") / "cells_to_fill.csv", dtype={"key": str})
    assert "blocking" in cells.columns
    rd = staged_readiness((DATA / "panel" / "universe_staging"))
    assert int(cells["blocking"].sum()) == int(rd["blocking"].sum())
    blk = rd[rd["blocking"]]
    new = set(cells["country"])
    assert set(blk["country"]) <= new                                    # the 18 desk countries do not block
    flags = blk[blk["field"].str.startswith("flag ")]
    assert flags.groupby("country").size().eq(8).all() and flags["country"].nunique() == len(new)
    adj = pd.read_csv((DATA / "panel" / "universe_staging") / "adjustments.csv")
    assert new <= set(adj.columns) and (adj[sorted(new)] == 0).all().all()


def test_stage_data_dir_copies_staged_adjustments_and_blank_flags_reach_provenance(tmp_path):
    from econquest.ingestion import load_universe
    from econquest.ingestion.universe import stage_data_dir
    if not ((DATA / "panel" / "universe_staging") / "adjustments.csv").exists():
        pytest.skip("staging not built")
    dst = stage_data_dir((DATA / "panel" / "universe_staging"), tmp_path / "stage")
    assert (dst / "adjustments.csv").read_bytes() == ((DATA / "panel" / "universe_staging") / "adjustments.csv").read_bytes()
    u = load_universe(dst)
    blank = u.provenance["blank_yes_no"]
    new = set(pd.read_csv((DATA / "panel" / "universe_staging") / "cells_to_fill.csv")["country"])
    assert set(blank) == new and all({"default", "coup", "disaster"} <= set(v) for v in blank.values())
    assert load_universe(DATA).provenance["blank_yes_no"] == {}
