"""`econquest change` CLI and fit-hazard --apply routed through it (EQ-C-0023)."""
import json
import shutil
from pathlib import Path

import pytest

from econquest import cli

ROOT = Path(__file__).resolve().parent.parent


@pytest.fixture
def data(tmp_path):
    d = tmp_path / "data"; d.mkdir()
    for f in ("assumptions.json", "limits.json"):
        shutil.copy(ROOT / "data" / f, d / f)
    return d


def test_change_propose_approve_apply(data, tmp_path, capsys):
    base = ["--data", str(data), "--out", str(tmp_path / "out"), "change"]
    before = json.loads((data / "limits.json").read_text())
    key = next(k for k, v in before.items() if isinstance(v, dict))
    sub = next(k for k, v in before[key].items() if isinstance(v, (int, float)) and not isinstance(v, bool))
    cli.main([*base, "propose", "limits.json", "--set", f"/{key}/{sub}={before[key][sub] + 1}", "--author", "Sam", "--reason", "test"])
    cid = capsys.readouterr().out.split()[1]
    with pytest.raises(SystemExit, match="change approve"):
        cli.main([*base, "approve", cid, "--approver", "SAM"])
    cli.main([*base, "approve", cid, "--self-approved", "--exc", "EXC-001"])
    cli.main([*base, "apply", cid])
    assert json.loads((data / "limits.json").read_text())[key][sub] == before[key][sub] + 1
    cli.main([*base, "verify"])
    assert "Chain: ok" in capsys.readouterr().out


def test_fit_hazard_apply_needs_author(data, tmp_path):
    with pytest.raises(SystemExit, match="--author"):
        cli.main(["--data", str(data), "--out", str(tmp_path), "fit-hazard", "--panel", "x.csv", "--apply"])


def test_fit_hazard_apply_proposes_instead_of_writing(data, tmp_path, capsys):
    before = (data / "assumptions.json").read_bytes()
    cli.main(["--data", str(data), "--out", str(tmp_path / "out"), "fit-hazard", "--panel", str(ROOT / "data" / "panel" / "hazard_panel.csv"),
              "--report", str(tmp_path / "fit.md"), "--apply", "--author", "Sam"])
    out = capsys.readouterr().out
    assert "proposed CHG-" in out
    assert (data / "assumptions.json").read_bytes() == before             # nothing lands until approve + apply
