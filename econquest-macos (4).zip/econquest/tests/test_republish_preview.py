"""Republish preview (EQ-C-0027): cell-by-cell diff of a new publish plan against a saved values:batchGet response or
a previous plan, with tolerance, large-move flags, new and uncovered ranges, HTML + CSV output and the disclaimer."""
import csv
import html as _h
import json
import sys
from pathlib import Path
from urllib.parse import unquote

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.presentation import republish_preview as P  # noqa: E402
from econquest.presentation.report import DISCLAIMER  # noqa: E402

NOTE = "Values written by the EconQuest Python engine on 2026-10-20 (run 20261020T090000-publish). Model formulas were replaced."
PLAN = [
    {"range": "'Risk Engine'!E5:G6", "values": [[10.0, 20.0, 30.0], [0.05, -1.0, ""]]},
    {"range": "Dashboard!A2", "values": [[NOTE]]},
    {"range": "Signals!E5:F5", "values": [[1.0, 2.0]]},                 # new: not in the baseline
    {"range": "Notes!A1", "values": [["'=not a formula"]]},             # escaped text in the saved plan
]
LIVE = {"spreadsheetId": "x", "valueRanges": [
    {"range": "'Risk Engine'!E5:G6", "majorDimension": "ROWS", "values": [["10", "1,999.0%", "-30"], ["0.05000001", "1", "7"]]},
    {"range": "Dashboard!A2", "majorDimension": "ROWS", "values": [["old note"]]},
    {"range": "Notes!A1", "majorDimension": "ROWS", "values": [["=not a formula"]]},
    {"range": "Backtesting!B9:B10", "majorDimension": "ROWS", "values": [["3"], ["4"]]},   # not in the new plan
]}


def files(tmp_path, plan=PLAN, live=LIVE):
    pp, lp = tmp_path / "publish_plan.json", tmp_path / "live.json"
    pp.write_text(json.dumps(plan)); lp.write_text(json.dumps(live))
    return pp, lp


def test_parse_range():
    assert P.parse_range("'Pillar Scores'!E29:V35") == ("Pillar Scores", 29, 5, 35, 22)
    assert P.parse_range("Inputs!A2") == ("Inputs", 2, 1, 2, 1)
    assert P.parse_range("'It''s'!AA10:AB11") == ("It's", 10, 27, 11, 28)
    assert P.parse_range("Sheet1!A:B") == ("Sheet1", 1, 1, None, 2)
    with pytest.raises(ValueError):
        P.parse_range("Sheet!E5:?")


def test_as_number():
    assert P.as_number("1,234.5") == 1234.5 and P.as_number("12%") == pytest.approx(0.12) and P.as_number("(3)") == -3.0
    assert P.as_number("$3.0") == 3.0 and P.as_number(4) == 4.0
    assert P.as_number("abc") is None and P.as_number("") is None and P.as_number(True) is None


def test_preview_against_batchget(tmp_path):
    pp, lp = files(tmp_path)
    s = P.preview(pp, lp, tmp_path / "out", tolerance=1e-6, large=0.25, log=lambda *a: None)
    t = s["totals"]
    assert t["ranges"] == 4 and t["ranges_new"] == 1 and t["ranges_not_in_plan"] == 1 and t["ranges_unchanged"] == 1   # Notes!A1 unescaped: equal
    by = {c["cell"] + "@" + c["sheet"]: c for c in s["changes"]}
    assert "E5@Risk Engine" not in by                                     # "10" == 10.0
    assert "E6@Risk Engine" not in by                                     # 0.05000001 -> 0.05: within tolerance
    assert by["F5@Risk Engine"]["rel_change"] == pytest.approx(20.0 / 19.99 - 1) and not by["F5@Risk Engine"]["large"]   # "1,999.0%" = 19.99
    assert by["G5@Risk Engine"]["large"]                                  # sign flip -30 -> 30
    assert by["F6@Risk Engine"]["large"]                                  # 1 -> -1
    assert by["G6@Risk Engine"]["kind"] == "cleared" and by["G6@Risk Engine"]["large"]
    assert by["A2@Dashboard"]["kind"] == "text"
    assert by["E5@Signals"]["kind"] == "new range"
    assert s["changes"][0]["large"]                                       # large moves first
    assert s["run_id"] == "20261020T090000-publish" and s["as_of"] == "2026-10-20"
    html = Path(s["html"]).read_text(encoding="utf-8")
    assert DISCLAIMER in html or _h.escape(DISCLAIMER) in html
    assert "LARGE" in html and "Backtesting!B9:B10" in html and "<b>NEW</b>" in html
    assert set(s["paths"]) == {s["html"], s["cells_csv"], s["ranges_csv"]}
    rows = list(csv.DictReader(open(s["cells_csv"], encoding="utf-8")))
    assert len(rows) == t["cells_changed"] and {r["cell"] for r in rows} >= {"G5", "G6", "A2", "E5"}
    rr = {r["range"]: r for r in csv.DictReader(open(s["ranges_csv"], encoding="utf-8"))}
    assert rr["Backtesting!B9:B10"]["status"] == "not in new plan" and rr["Signals!E5:F5"]["status"] == "new"


def test_tolerance_absorbs_display_rounding(tmp_path):
    plan = [{"range": "A!A1:B1", "values": [[0.118649, 1234.5678]]}]
    live = {"valueRanges": [{"range": "A!A1:B1", "values": [["0.1186", "1,234.57"]]}]}
    pp, lp = files(tmp_path, plan, live)
    assert P.preview(pp, lp, tmp_path / "o1", tolerance=1e-6, log=lambda *a: None)["totals"]["cells_changed"] == 2
    assert P.preview(pp, lp, tmp_path / "o2", tolerance=1e-3, log=lambda *a: None)["totals"]["cells_changed"] == 0


def test_trimmed_trailing_cells_and_columns_major(tmp_path):
    plan = [{"range": "A!A1:C2", "values": [[1, "", ""], [2, 3, ""]]}]
    live = {"valueRanges": [{"range": "A!A1:C2", "majorDimension": "COLUMNS", "values": [[1, 2], ["", 3]]}]}   # batchGet trims empties
    pp, lp = files(tmp_path, plan, live)
    s = P.preview(pp, lp, tmp_path / "o", log=lambda *a: None)
    assert s["totals"]["cells_changed"] == 0 and s["totals"]["ranges_unchanged"] == 1


def test_previous_plan_as_baseline_and_several_files(tmp_path):
    old = [{"range": "'Risk Engine'!E5:G6", "values": [[10.0, 20.0, 30.0], [0.05, -1.0, ""]]}]
    pp, _ = files(tmp_path)
    op = tmp_path / "old_plan.json"; op.write_text(json.dumps(old))
    s = P.preview(pp, op, tmp_path / "o", log=lambda *a: None)
    assert s["baseline_kind"] == "plan" and s["totals"]["ranges_unchanged"] == 1 and s["totals"]["ranges_new"] == 3
    l2 = tmp_path / "live2.json"; l2.write_text(json.dumps({"valueRanges": [{"range": "Signals!E5:F5", "values": [[1, 2]]}]}))
    s2 = P.preview(pp, [op, l2], tmp_path / "o2", log=lambda *a: None)
    assert s2["totals"]["ranges_new"] == 2 and "plan + sheets values:batchGet" == s2["baseline_kind"]


def test_unrecognised_baseline(tmp_path):
    pp, _ = files(tmp_path)
    bad = tmp_path / "bad.json"; bad.write_text(json.dumps({"hello": 1}))
    with pytest.raises(ValueError, match="unrecognised"):
        P.preview(pp, bad, tmp_path / "o", log=lambda *a: None)


def test_batchget_urls_cover_plan(tmp_path):
    plan = [{"range": f"'Sheet {i}'!E5:V{5 + i}", "values": [[1]]} for i in range(60)] + [{"range": "Dashboard!A2", "values": [["x"]]}]
    urls = P.batchget_urls(plan, "SHEET", max_len=600)
    assert len(urls) > 1 and all(len(u) <= 650 for u in urls)
    got = [unquote(part) for u in urls for part in u.split("&ranges=")[1:]]
    assert got[0] == "'Sheet 0'!E5:V5" and got[-1] == "Dashboard!A2" and len(got) == 61
    assert all("valueRenderOption=UNFORMATTED_VALUE" in u and "/SHEET/values:batchGet" in u for u in urls)


def test_csv_escapes_text_keeps_numbers(tmp_path):
    plan = [{"range": "A!A1:B1", "values": [["=SUM(1)", -5.0]]}]
    live = {"valueRanges": [{"range": "A!A1:B1", "values": [["x", "5"]]}]}
    pp, lp = files(tmp_path, plan, live)
    s = P.preview(pp, lp, tmp_path / "o", log=lambda *a: None)
    rows = {r["cell"]: r for r in csv.DictReader(open(s["cells_csv"], encoding="utf-8"))}
    assert rows["A1"]["new"] == "'=SUM(1)" and rows["B1"]["new"] == "-5.0"


def test_csv_escapes_range_text_from_the_baseline(tmp_path):
    # regression (AGENT-09 review of EQ-C-0027): range names come from the plan and the baseline JSON and went into both
    # CSVs raw; a sheet title starting with = or @ would be evaluated by a spreadsheet opening the CSV
    plan = [{"range": "=X!A1", "values": [[1.0]]}]
    live = {"valueRanges": [{"range": "=X!A1", "values": [[2.0]]}, {"range": "@evil!A1", "values": [["x"]]}]}
    pp, lp = files(tmp_path, plan, live)
    s = P.preview(pp, lp, tmp_path / "o", log=lambda *a: None)
    for path in (s["cells_csv"], s["ranges_csv"]):
        for row in csv.reader(open(path, encoding="utf-8")):
            assert not any(c.startswith(("=", "@", "+", "-")) for c in row[:3] if c not in ("", "-")), (path, row)


def test_columns_past_z_workbook_v2():
    """EQ-C-0033: column letters come from sheets_publish (A..Z, AA.., ZZZ); 70-country ranges (E:BV) diff cell by cell."""
    from econquest.presentation.sheets_publish import col_letter, col_number
    for n in (1, 26, 27, 52, 53, 74, 108, 702, 703, 18278):
        assert P.col_letters(n) == col_letter(n) and P._col_num(col_letter(n)) == n == col_number(col_letter(n))
    assert P._col_num("bv") == 74
    assert P.parse_range("'Risk Engine'!E5:BV37") == ("Risk Engine", 5, 5, 37, 74)
    assert P.parse_range("MC!BZ7:DD56") == ("MC", 7, 78, 56, 108)
    old = [{"range": "'Risk Engine'!E5:BV5", "values": [[0.01] * 70]}]
    new = [{"range": "'Risk Engine'!E5:BV5", "values": [[0.01] * 69 + [0.05]]}]
    res = P.diff(new, old)
    assert res["totals"]["cells"] == 70 and [c["cell"] for c in res["changes"]] == ["BV5"]
    url = P.batchget_urls(new, "SHEET")[0]
    assert "E5%3ABV5" in url
