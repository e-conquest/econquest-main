"""The CLI passes as_of to Team B's run_garch, synthetic_history and benchmarks.outcomes (HO-20261023-B-C-016 items 1-3,
EQ-C-0055; findings VF-006 / VF-007)."""
import json
import shutil
from pathlib import Path
from types import SimpleNamespace

import pandas as pd
import pytest

from econquest import cli
from econquest.engine import garch as G
from econquest.validation import benchmarks as bm

ROOT = Path(__file__).resolve().parent.parent


class _Calls(list):
    prov: dict


@pytest.fixture
def garch_calls(monkeypatch, tmp_path):
    monkeypatch.setenv("ECONQUEST_ACTION_LOG", str(tmp_path / "actions.jsonl"))
    monkeypatch.setenv("ECONQUEST_RUN_GATE", "off")
    calls = _Calls()
    prov = {}

    def fake_run_garch(u, px, s=None, gpr=None, quotes=None, as_of=None):
        calls.append(as_of)
        raise StopIteration                        # stop before any output is written
    monkeypatch.setattr(G, "run_garch", fake_run_garch)
    monkeypatch.setattr(G, "load_prices", lambda d: pd.DataFrame({"x": [1.0]}))
    monkeypatch.setattr(cli, "_load", lambda args: (SimpleNamespace(gpr=None, provenance=prov), SimpleNamespace()))
    calls.prov = prov
    return calls


def _garch(*a):
    with pytest.raises(StopIteration):
        cli.main(["garch", "--dry-run", *a])


def test_garch_as_of_reaches_run_garch(garch_calls):
    _garch("--as-of", "2026-09-30T12:00")
    assert garch_calls == ["2026-09-30"]


def test_garch_without_flag_leaves_it_to_settings(garch_calls):
    _garch()
    assert garch_calls == [None]                   # run_garch then uses settings["as_of"], else every row


def test_garch_vintage_defaults_as_of_to_vintage_date(garch_calls):
    garch_calls.prov["replay"] = {"vintage_id": "2026-10-20T080000Z-ab12cd34"}
    _garch("--vintage", "2026-10-20")
    _garch("--vintage", "2026-10-20", "--as-of", "2026-10-01")      # an explicit --as-of wins
    garch_calls.prov["replay"] = {"vintage_id": "legacy"}
    _garch("--vintage", "legacy")                                    # no date recorded: unchanged behaviour
    assert garch_calls == ["2026-10-20", "2026-10-01", None]


def test_garch_bad_as_of_is_usage_error(garch_calls, capsys):
    with pytest.raises(SystemExit) as e:
        cli.main(["garch", "--as-of", "soon"])
    assert e.value.code == 2 and garch_calls == []


def test_benchmark_outcomes_get_as_of(monkeypatch, tmp_path):
    monkeypatch.setenv("ECONQUEST_RUN_GATE", "off")
    seen = {}
    run = SimpleNamespace(country=pd.DataFrame({"pd_default": [0.1]}, index=["Brazil"]), summary=lambda: {"versions": {}})
    monkeypatch.setattr(cli, "_load", lambda args: (SimpleNamespace(provenance={}), SimpleNamespace(paths=1000, get=lambda *a, **k: {})))
    monkeypatch.setattr(cli, "run_pipeline", lambda *a, **k: run)
    monkeypatch.setattr(bm, "benchmark_snapshot", lambda *a, **k: pd.DataFrame({"date": ["2026-10-20"]}))
    monkeypatch.setattr(bm, "append_history", lambda path, snap: snap)

    def fake_outcomes(hist, events, horizon_days=365, today=None, as_of=None):
        seen.update(today=today, as_of=as_of)
        raise StopIteration
    monkeypatch.setattr(bm, "outcomes", fake_outcomes)
    with pytest.raises(StopIteration):
        cli.main(["--data", str(tmp_path), "--out", str(tmp_path / "out"), "benchmark", "--dry-run", "--as-of", "2026-10-20"])
    assert seen == {"today": None, "as_of": "2026-10-20"}


def test_run_backtest_synthetic_history_dated_by_as_of(monkeypatch, tmp_path):
    """No backtest_history.csv: the synthetic history ends at the run's as_of month, not the wall clock (VF-006)."""
    monkeypatch.setenv("ECONQUEST_ACTION_LOG", str(tmp_path / "actions.jsonl"))
    monkeypatch.setenv("ECONQUEST_RUN_GATE", "off")
    data = tmp_path / "data"
    shutil.copytree(ROOT / "data", data, ignore=shutil.ignore_patterns("live", "backtest_history.csv", "approvals"))
    frames = []
    real = cli.synthetic_history

    def spy(*a, **k):
        frames.append((k.get("as_of"), real(*a, **k)))
        return frames[-1][1]
    monkeypatch.setattr(cli, "synthetic_history", spy)
    for _ in range(2):
        cli.main(["--data", str(data), "--out", str(tmp_path / "out"), "run", "--paths", "500", "--no-paths", "--backtest", "--as-of", "2025-03-15"])
    assert [a for a, _ in frames] == ["2025-03-15", "2025-03-15"]
    d0, d1 = (f["date"] for _, f in frames)
    assert d0.max() == pd.Timestamp("2025-03-01") and d0.equals(d1)
    assert json.loads((tmp_path / "out" / "backtest.json").read_text())
