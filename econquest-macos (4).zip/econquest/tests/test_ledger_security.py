"""EQ-A-0011: SEC-A-001 residual lows L2-L4 (ledger) and replay lows R1-R4 (AGENT-09, EQ-A-0007 sec_pass)."""
import csv
import json
import shutil
import sys
from pathlib import Path

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tests"))

from econquest.ingestion import ledger, replay  # noqa: E402
from econquest.ingestion.ledger import (effective_holds, ledger_path, load_decisions, person_key, read_ledger,  # noqa: E402
                                        record_decision)
from econquest.ingestion.replay import VintageIntegrityError, materialize_vintage, snapshot_path  # noqa: E402
from test_replay import _applied  # noqa: E402


# ---- L2: person_key ------------------------------------------------------------------------------------------------
@pytest.mark.parametrize("alias", ["alice", "'alice", "''alice", "a lice", "a\tlice", " ALICE ", "аlice",   # Cyrillic а
                                   "ΑLICE", "alicе", "al​ice"])                                       # Greek Α, Cyrillic е
def test_person_key_aliases_are_the_same_person(alias):
    assert person_key(alias) == person_key("alice")


def test_person_key_distinct_people_stay_distinct():
    assert person_key("alice") != person_key("alicia") and person_key("bob") != person_key("rob")
    assert ledger.clean_person("  Jo   Smith ") == "Jo Smith"


def test_aliased_approver_is_not_four_eyes(tmp_path):
    for alias in ("'alice", "a lice", "аlice"):
        with pytest.raises(ValueError, match="four-eyes"):
            record_decision(tmp_path, "Inputs", "1.3", "X", "apply", "alice", approver=alias, gate_status="hold", live=1.0)


# ---- L3: an apply that overrides a colleague's hold/reject needs approval -------------------------------------------
def _ok(key="5.5", live=1.0):
    return pd.DataFrame([{"table": "Inputs", "key": key, "country": "X", "status": "ok", "live": live}])


@pytest.mark.parametrize("first", ["reject", "hold"])
def test_unapproved_apply_cannot_override_colleague(tmp_path, first):
    record_decision(tmp_path, "Inputs", "5.5", "X", first, "alice")
    with pytest.raises(ValueError, match="alice put on hold or rejected"):
        record_decision(tmp_path, "Inputs", "5.5", "X", "apply", "bob")
    with pytest.raises(ValueError):
        record_decision(tmp_path, "Inputs", "5.5", "X", "apply", "bob", approver="b ob")
    assert effective_holds(_ok(), load_decisions(tmp_path)) == {("Inputs", "5.5", "X")}
    record_decision(tmp_path, "Inputs", "5.5", "X", "apply", "bob", approver="carol")        # four-eyes: released
    assert effective_holds(_ok(), load_decisions(tmp_path)) == set()


def test_flagged_self_approval_and_own_hold(tmp_path):
    record_decision(tmp_path, "Inputs", "5.5", "X", "reject", "alice")
    row = record_decision(tmp_path, "Inputs", "5.5", "X", "apply", "bob", self_approved=True)
    assert row["self_approved"] == "yes" and row["approver"] == "bob"
    assert effective_holds(_ok(), load_decisions(tmp_path)) == set()
    record_decision(tmp_path, "Inputs", "5.6", "X", "hold", "alice")
    record_decision(tmp_path, "Inputs", "5.6", "X", "apply", "Alice")                          # own hold: no approver
    assert effective_holds(_ok("5.6"), load_decisions(tmp_path)) == set()


def test_hand_appended_override_stays_held_in_effective_holds(tmp_path):
    record_decision(tmp_path, "Inputs", "5.5", "X", "reject", "alice")
    ledger._append(tmp_path, [{"ts_utc": "t", "table": "Inputs", "key": "5.5", "country": "X", "decision": "apply",
                               "author": "bob", "approver": ""}])                               # bypasses record_decision
    dec = load_decisions(tmp_path)
    assert dec.iloc[-1]["objection_by"] == "alice"
    assert effective_holds(_ok(), dec) == {("Inputs", "5.5", "X")}
    assert effective_holds(_ok(), read_ledger(tmp_path)) == {("Inputs", "5.5", "X")}          # full history, same answer


# ---- L4: formula guard on every text column --------------------------------------------------------------------------
def test_every_text_column_is_neutralised(tmp_path):
    record_decision(tmp_path, "=T()", "+1+cmd", "@SUM(A1)", "hold", "\t=evil", note="\r=HYPERLINK(\"x\")",
                    vintage_id="=1+1", live="=2+2", gate_status="-x+1")
    with open(ledger_path(tmp_path), newline="") as f:
        raw = list(csv.DictReader(f))[0]
    for c in ("vintage_id", "table", "key", "country", "author", "note", "live", "gate_status"):
        assert raw[c].startswith("'"), (c, raw[c])
    rec = read_ledger(tmp_path).iloc[0]                                  # identifiers round-trip for matching
    assert (rec["table"], rec["key"], rec["country"], rec["vintage_id"]) == ("=T()", "+1+cmd", "@SUM(A1)", "=1+1")


def test_numbers_are_not_neutralised(tmp_path):
    record_decision(tmp_path, "Inputs", "-1", "X", "hold", "alice", live=-2.5)
    record_decision(tmp_path, "Inputs", "1.3", "X", "hold", "alice", live="-3.5")
    with open(ledger_path(tmp_path), newline="") as f:
        raw = list(csv.DictReader(f))
    assert raw[0]["key"] == "-1" and raw[0]["live"] == "-2.5" and raw[1]["live"] == "-3.5"


# ---- R1-R4: replay ---------------------------------------------------------------------------------------------------
def _index(d):
    return d / "live" / "snapshots" / "index.csv"


def _rewrite_index(d, fn):
    rows = list(csv.DictReader(open(_index(d), newline="")))
    rows = [fn(r) for r in rows]
    with open(_index(d), "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=replay.SNAPSHOT_INDEX_COLUMNS); w.writeheader(); w.writerows(rows)


@pytest.mark.parametrize("name", ["../../../../evil", "..", "a/b", "x..y", ""])
def test_r1_index_snapshot_name_confined(tmp_path, name):
    d, vid, _ = _applied(tmp_path)
    _rewrite_index(d, lambda r: {**r, "snapshot": name})
    with pytest.raises(VintageIntegrityError):
        snapshot_path(d, vid)


def test_r1_symlinked_snapshot_outside_root_refused(tmp_path):
    d, vid, out = _applied(tmp_path)
    elsewhere = tmp_path / "evil"; shutil.copytree(out["inputs_snapshot"], elsewhere)
    link = d / "live" / "snapshots" / "linked"; link.symlink_to(elsewhere, target_is_directory=True)
    _rewrite_index(d, lambda r: {**r, "snapshot": "linked"})
    with pytest.raises(VintageIntegrityError, match="outside"):
        snapshot_path(d, vid)


def test_r1_manifest_vintage_must_match(tmp_path):
    d, vid, out = _applied(tmp_path)
    # point this vintage's index row at a valid snapshot of a different vintage id
    snap = Path(out["inputs_snapshot"])
    m = json.loads((snap / "manifest.json").read_text()); m["vintage_id"] = "other-vintage"
    (snap / "manifest.json").chmod(0o644); (snap / "manifest.json").write_text(json.dumps(m))
    with pytest.raises(VintageIntegrityError, match="not the requested"):
        materialize_vintage(d, vid, tmp_path / "out")


def test_r2_out_dir_inside_data_dir_refused(tmp_path):
    d, vid, _ = _applied(tmp_path)
    for bad in (d, d / "panel" / "replay", d / "x"):
        with pytest.raises(ValueError, match="inside data_dir"):
            materialize_vintage(d, vid, bad)
    assert not (d / "panel" / "replay").exists() and not (d / "x").exists()


def test_r3_failure_leaves_no_partial_out_dir(tmp_path, monkeypatch):
    d, vid, _ = _applied(tmp_path)
    real = replay._sha256
    def flaky(p):                                                        # fail mid-build, after files were written
        if Path(p).parent.name.startswith(".out.replay.") and Path(p).name == "indicators.csv":
            raise OSError("disk full")
        return real(p)
    monkeypatch.setattr(replay, "_sha256", flaky)
    with pytest.raises(OSError):
        materialize_vintage(d, vid, tmp_path / "out")
    assert not (tmp_path / "out").exists()
    assert [p for p in tmp_path.iterdir() if p.name.startswith(".out.replay.")] == []
    monkeypatch.setattr(replay, "_sha256", real)
    (tmp_path / "empty").mkdir()
    rm = materialize_vintage(d, vid, tmp_path / "empty")                 # an existing empty folder is still accepted
    assert (tmp_path / "empty" / replay.REPLAY_MANIFEST).exists() and rm["vintage_id"] == vid


def test_r4_index_append_uses_locked_append(tmp_path, monkeypatch):
    seen = []
    real = ledger.locked_append

    def spy(path, fields):
        seen.append(Path(path).name)
        return real(path, fields)
    monkeypatch.setattr(ledger, "locked_append", spy)
    d, vid, _ = _applied(tmp_path)
    assert "index.csv" in seen
    rows = list(csv.DictReader(open(_index(d), newline="")))
    assert len(rows) == 1 and rows[0]["vintage_id"] == vid
