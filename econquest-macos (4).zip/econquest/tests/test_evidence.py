"""Evidence bundle for the validator (EQ-C-0060): `econquest evidence --as-of` builds one deterministic zip with a sha256
manifest; `evidence verify` rechecks every hash and the hash chains offline; tampering fails; no secret-looking file
or subscriber address is shipped; --tests-from replaces the long pytest run. Temp data/ and outputs/ only."""
import hashlib
import json
import os
import smtplib
import tempfile
import zipfile

import pytest

from econquest import cli
from econquest import versioning as V
from econquest.ops import actionlog, approvals
from econquest.ops import distribute as D
from econquest.ops import evidence as EV
from econquest.persistence import Store
from test_distribute import FakeSMTP, published, real_send  # noqa: E402

AS_OF = "2026-10-23"
JUNIT = ('<?xml version="1.0" encoding="utf-8"?><testsuites><testsuite name="pytest" errors="0" failures="1" skipped="2" '
         'tests="10" time="1.0"><testcase classname="t" name="a"/></testsuite></testsuites>')


def _fake_replication(data_dir, out, quick, log=print):
    out.mkdir(parents=True, exist_ok=True)
    (out / "replication.csv").write_text("id,group,status\nR01,release,PASS\nR02,release,PASS\nR03,docs,INFO\n")
    (out / "replication.md").write_text("# Independent replication\n")
    return {"counts": {"PASS": 2, "INFO": 1}, "stale": [], "prices": "frozen release prices"}


def _no_pytest(*a, **k):
    raise AssertionError("--tests-from must skip the pytest run")


@pytest.fixture
def env(tmp_path, monkeypatch):
    monkeypatch.delenv("ECONQUEST_ACTION_LOG", raising=False)
    monkeypatch.delenv("SOURCE_DATE_EPOCH", raising=False)
    monkeypatch.setattr(EV, "run_replication", _fake_replication)
    monkeypatch.setattr(EV, "run_pytest", _no_pytest)
    monkeypatch.setattr(smtplib, "SMTP", FakeSMTP); FakeSMTP.sent, FakeSMTP.fail_for = [], set()
    root, data, out = tmp_path / "root", tmp_path / "data", tmp_path / "outputs"
    for rel, body in {"docs/governance/model-inventory.md": "# Inventory\n", "docs/governance/releases/0.1.5.md": "# 0.1.5\n",
                      "docs/validation/README.md": "# Validation\n", "docs/validation/dossier/README.md": "# Dossier\n",
                      "docs/validation/dossier/findings-register.csv": "id,status\nGOV-001,Resolved 2026-10-23\nVF-001,Open\n",
                      "docs/institutional-roadmap.md": "# Roadmap\n",
                      # secret-looking files that must never ship
                      "docs/governance/.env": "SHEETS=abc\n", "docs/validation/client_secret_x.json": "{}",
                      "docs/governance/sheets.token": "tok"}.items():
        p = root / rel; p.parent.mkdir(parents=True, exist_ok=True); p.write_text(body)
    data.mkdir(); (out / "reports").mkdir(parents=True)
    (data / "assumptions.json").write_text('{"monte_carlo": {"paths": 1000}}\n')
    (data / "countries.csv").write_text("country\nBrazil\n")
    (data / "distribution.json").write_text(json.dumps({"archive_base_url": "", "subject_prefix": "EconQuest",
                                                        "subscribers": {"country_note": ["alice@example.com", "bob@example.com"]}}))
    # hash chains: an approval event, an action naming an address, a published item, deliveries to two addresses
    with approvals._locked(data):
        approvals._append_event(data, "baseline", file="assumptions.json", actor="Sam", note="first use")
    actionlog.append(out, "distribute send --send", {"confirm_new": "alice@example.com"}, actor="Sam", actor_source="flag")
    D.queue(out, published(out), actor="Carol", data_dir=data)
    real_send(out, monkeypatch)
    # stored runs: a base run for AS_OF and one for another day
    stamp = V.stamp(data, AS_OF)
    for rid, as_of in (("20261023T225023-base", AS_OF), ("20261022T120000-base", "2026-10-22")):
        st = dict(stamp, as_of=as_of); st = V.with_as_of(st, as_of)
        Store(out / "store").save_run({"summary": {"run_id": rid, "created_at": rid, "label": "base", "as_of": as_of,
                                                   "metrics": {"var99_mm": 73.11}, "versions": {k: v for k, v in st.items() if k != "data_files"}},
                                       "settings": {"as_of": as_of}, "provenance": {"versions": st}})
    tests = tmp_path / "junit.xml"; tests.write_text(JUNIT)
    yield {"root": root, "data": data, "out": out, "tests": tests, "tmp": tmp_path}
    for r, _dirs, files in os.walk(tmp_path):
        os.chmod(r, 0o755)
        for f in files:
            os.chmod(os.path.join(r, f), 0o644)


def _build(e, dest, **kw):
    kw.setdefault("tests_from", e["tests"])
    return EV.build(AS_OF, e["data"], e["out"], root=e["root"], dest=dest, log=lambda *a: None, **kw)


def _members(path):
    with zipfile.ZipFile(path) as z:
        return {i.filename: z.read(i) for i in z.infolist()}


def _rewrite(src, dst, change):
    """Copy a zip, passing each (name, bytes) through change()."""
    with zipfile.ZipFile(src) as zi, zipfile.ZipFile(dst, "w", zipfile.ZIP_DEFLATED) as zo:
        for i in zi.infolist():
            zo.writestr(i, change(i.filename, zi.read(i)))


def test_build_is_deterministic(env):
    a = _build(env, env["tmp"] / "a" / "ev.zip")
    os.utime(env["root"] / "docs/governance/model-inventory.md", (1_700_000_000, 1_700_000_000))   # mtimes do not matter
    b = _build(env, env["tmp"] / "b" / "ev.zip")
    assert a["sha256"] == b["sha256"] == hashlib.sha256((env["tmp"] / "a" / "ev.zip").read_bytes()).hexdigest()
    assert (env["tmp"] / "a" / "ev.zip.sha256").read_text() == f"{a['sha256']}  ev.zip\n"
    names = list(_members(env["tmp"] / "a" / "ev.zip"))
    assert names == sorted(names) and all(n.startswith(f"evidence-{AS_OF}/") for n in names)
    (env["root"] / "docs/validation/README.md").write_text("# Validation v2\n")
    assert _build(env, env["tmp"] / "c" / "ev.zip")["sha256"] != a["sha256"]


def test_layout_manifest_and_content(env):
    r = _build(env, env["tmp"] / "ev.zip")
    m = _members(env["tmp"] / "ev.zip"); top = f"evidence-{AS_OF}/"
    man = json.loads(m[top + "EVIDENCE-MANIFEST.json"])
    files = {f["path"]: f for f in man["files"]}
    assert set(files) == {n[len(top):] for n, b in m.items() if not n.endswith("/")} - {"EVIDENCE-MANIFEST.json"}
    assert all(hashlib.sha256(m[top + p]).hexdigest() == f["sha256"] for p, f in files.items())
    for p in ("README.md", "docs/governance/model-inventory.md", "docs/validation/dossier/findings-register.csv",
              "docs/institutional-roadmap.md", "runs/index.json", "runs/20261023T225023-base.json", "inputs/data/assumptions.json",
              "hashes/current-stamp.json", "tests/junit.xml", "tests/summary.json", "replication/replication.csv",
              "replication/summary.json", "chains/data/approvals/log.jsonl", "chains/outputs/store/actions.jsonl",
              "chains/outputs/editorial/ledger.jsonl", "chains/outputs/store/deliveries.jsonl", "chains/verify.json",
              "chains/distribution.redacted.json", "dataroom/dossier-manifest.json"):
        assert p in files, p
    assert "runs/20261022T120000-base.json" not in files            # other as-of dates are not packed
    idx = json.loads(m[top + "runs/index.json"])["runs"]
    assert [i["run_id"] for i in idx] == ["20261023T225023-base"]
    assert idx[0]["versions"]["data_files"] and idx[0]["checks"]["run_hash_recomputes"] and idx[0]["checks"]["data_hash_recomputes"]
    s = man["sections"]
    assert s["tests"] == {"status": "fail", "tests": 10, "passed": 7, "failed": 1, "errors": 0, "skipped": 2, "source": "--tests-from junit.xml"}
    assert s["replication"]["counts"] == {"PASS": 2, "INFO": 1} and s["replication"]["status"] == "pass"
    assert s["dataroom"]["dossier_files"] == 2 and s["dataroom"]["findings_by_status"] == {"Resolved": 1, "Open": 1}
    assert {k: (v["ok"], v["offline_check"]) for k, v in man["chains"].items()} == {
        "approvals": (True, "full"), "actions": (True, "linkage"), "editorial": (True, "full"), "deliveries": (True, "linkage")}
    assert man["chains"]["editorial"]["rows"] >= 4 and man["chains"]["deliveries"]["rows"] >= 2
    pub = [n for n in m if "/chains/outputs/published/" in n and not n.endswith("/") and n.endswith(".html")]
    with zipfile.ZipFile(env["tmp"] / "ev.zip") as z:                # published copies keep their read-only modes
        assert pub and all((z.getinfo(n).external_attr >> 16) & 0o777 == 0o444 for n in pub)
    assert r["files"] == len(files) + 1


def test_verify_passes(env, capsys):
    _build(env, env["tmp"] / "ev.zip")
    v = EV.verify(env["tmp"] / "ev.zip")
    assert v["ok"] and v["integrity_ok"] and v["chains_ok"], v["errors"]
    assert v["chains"]["editorial"]["check"] == "full" and v["chains"]["deliveries"]["check"].startswith("linkage")
    cli.main(["--data", str(env["data"]), "--out", str(env["out"]), "evidence", "verify", str(env["tmp"] / "ev.zip")])  # exit 0
    assert "ok" in capsys.readouterr().out


def test_tampered_file_fails_verify(env):
    good = env["tmp"] / "ev.zip"
    _build(env, good)
    bad = env["tmp"] / "bad.zip"
    _rewrite(good, bad, lambda n, b: b.replace(b"Inventory", b"Inventorz") if n.endswith("model-inventory.md") else b)
    v = EV.verify(bad)
    assert not v["ok"] and any("model-inventory.md: sha256 differs" in e for e in v["errors"])
    # an extra file is refused too
    extra = env["tmp"] / "extra.zip"
    with zipfile.ZipFile(good) as zi, zipfile.ZipFile(extra, "w") as zo:
        for i in zi.infolist():
            zo.writestr(i, zi.read(i))
        zo.writestr(f"evidence-{AS_OF}/docs/added.md", "x")
    assert any("not in the manifest" in e for e in EV.verify(extra)["errors"])
    # a sidecar that does not match the archive fails
    (env["tmp"] / "bad.zip.sha256").write_text("0" * 64 + "  bad.zip\n")
    assert any("bad.zip.sha256 does not match" in e for e in EV.verify(bad)["errors"])


def test_chain_edit_with_rewritten_manifest_fails_the_chain_check(env):
    """Editing an approval row and fixing up the manifest hash passes the file check but not the chain recompute."""
    good = env["tmp"] / "ev.zip"
    _build(env, good)
    top = f"evidence-{AS_OF}/"
    m = _members(good)
    log = m[top + "chains/data/approvals/log.jsonl"].replace(b"first use", b"first usE")
    man = json.loads(m[top + "EVIDENCE-MANIFEST.json"])
    for f in man["files"]:
        if f["path"] == "chains/data/approvals/log.jsonl":
            f["sha256"], f["size"] = hashlib.sha256(log).hexdigest(), len(log)
    bad = env["tmp"] / "forged.zip"
    _rewrite(good, bad, lambda n, b: log if n.endswith("/chains/data/approvals/log.jsonl") else
             (json.dumps(man).encode() if n.endswith("EVIDENCE-MANIFEST.json") else b))
    v = EV.verify(bad)
    assert v["integrity_ok"] and not v["chains_ok"] and not v["ok"]
    assert any("row_hash does not recompute" in e for e in v["chains"]["approvals"]["errors"])


def test_no_secret_or_subscriber_address_is_included(env):
    _build(env, env["tmp"] / "ev.zip")
    m = _members(env["tmp"] / "ev.zip")
    br = EV.build_release()
    assert not [n for n in m if br.is_secret(n.rstrip("/").rsplit("/", 1)[-1])]
    assert not any(n.endswith(("/.env", "client_secret_x.json", "sheets.token")) for n in m)
    blob = b"".join(m.values())
    assert b"SHEETS=abc" not in blob
    assert b"@example.com" not in blob                             # deliveries, action-log args and distribution.json
    top = f"evidence-{AS_OF}/"
    dist = json.loads(m[top + "chains/distribution.redacted.json"])
    assert dist["subscribers"]["country_note"] == ["[redacted:recipient-1]", "[redacted:recipient-2]"]
    assert "[redacted:recipient-1]" in m[top + "chains/outputs/store/deliveries.jsonl"].decode()
    man = json.loads(m[top + "EVIDENCE-MANIFEST.json"])
    assert {"docs/governance/.env", "docs/governance/sheets.token", "docs/validation/client_secret_x.json"} <= set(man["excluded_secret_like"])


def test_tests_from_and_cli(env, monkeypatch, capsys):
    dest = env["tmp"] / "cli"
    argv = ["--data", str(env["data"]), "--out", str(env["out"]), "evidence", "--as-of", AS_OF, "--quick",
            "--tests-from", str(env["tests"]), "--root", str(env["root"]), "--out", str(dest)]
    cli.main(argv)                                                 # returns normally: exit 0
    zp = dest / f"evidence-{AS_OF}.zip"
    assert zp.is_file() and "7 passed, 1 failed" in capsys.readouterr().out
    # a plain pytest summary line is accepted too
    txt = env["tmp"] / "pytest.txt"; txt.write_text("....\n1637 passed, 5 skipped in 91.2s\n")
    r = _build(env, env["tmp"] / "t.zip", tests_from=txt)
    assert r["manifest"]["sections"]["tests"]["passed"] == 1637 and r["manifest"]["sections"]["tests"]["status"] == "pass"
    assert "tests/pytest-summary.txt" in {f["path"] for f in r["manifest"]["files"]} and EV.verify(env["tmp"] / "t.zip")["ok"]
    # without --tests-from the suite runs (stubbed here) and its junit report is packed
    def fake_pytest(root, junit, log=print):
        junit.write_text(JUNIT.replace('failures="1"', 'failures="0"')); return 0
    monkeypatch.setattr(EV, "run_pytest", fake_pytest); (env["root"] / "tests").mkdir()
    r = _build(env, env["tmp"] / "p.zip", tests_from=None)
    assert r["manifest"]["sections"]["tests"]["status"] == "pass" and r["manifest"]["sections"]["tests"]["source"] == "pytest run during the build"


def test_errors(env, capsys):
    with pytest.raises(EV.EvidenceError, match="no stored run"):
        EV.build("2026-01-01", env["data"], env["out"], root=env["root"], dest=env["tmp"] / "x.zip", tests_from=env["tests"])
    with pytest.raises(EV.EvidenceError, match="YYYY-MM-DD"):
        EV.check_as_of("23/10/2026")
    bad = env["tmp"] / "bad.xml"; bad.write_text("no results here")
    with pytest.raises(EV.EvidenceError, match="junit"):
        _build(env, env["tmp"] / "y.zip", tests_from=bad)
    with pytest.raises(SystemExit) as ex:
        cli.main(["--data", str(env["data"]), "--out", str(env["out"]), "evidence"])
    assert ex.value.code == 2 and "--as-of" in capsys.readouterr().err
    assert not EV.verify(env["tmp"] / "missing.zip")["ok"]


LEDGER_HEAD = "ts_utc,vintage_id,table,key,country,gate_status,live,decision,author,approver,note,self_approved,content_sha256\n"


def _room_data(env, note="checked"):
    """A review ledger with one row before the cutoff (its author an address) and one after, so the room has content."""
    p = env["data"] / "live" / "review_ledger.csv"; p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(LEDGER_HEAD + f"2026-10-20T09:00:00.000000Z,,Inputs,1.1,Brazil,held,4,apply,ann@example.org,bob,{note},,\n"
                 "2026-10-24T09:00:00.000000Z,,Inputs,1.2,Brazil,held,5,apply,carol,bob,later,,\n")


def _room(env, dest=None):
    from econquest.ingestion import dataroom as DR
    dest = dest or DR.default_room_dir(AS_OF, env["out"])
    DR.build_data_room(env["data"], AS_OF, dest)
    return dest


def _files(folder):
    return {q.relative_to(folder).as_posix(): q.read_bytes() for q in sorted(folder.rglob("*")) if q.is_file()}


def _extract_room(zpath, dest):
    top = f"evidence-{AS_OF}/dataroom/team-a/"
    with zipfile.ZipFile(zpath) as z:
        for i in z.infolist():
            if i.filename.startswith(top) and not i.is_dir():
                t = dest / i.filename[len(top):]; t.parent.mkdir(parents=True, exist_ok=True); t.write_bytes(z.read(i))
    return dest


def test_team_a_data_room_is_packed_unchanged_and_verified(env):
    """EQ-C-0069: an existing <outputs>/dataroom/<as_of>/ is copied byte for byte (its address is not redacted), its
    hashes and verify result are in EVIDENCE-MANIFEST.json, and evidence verify reruns Team A's verify."""
    import subprocess
    import sys
    from econquest.ingestion.dataroom import verify_data_room
    _room_data(env)
    room = _room(env)
    src = _files(room)
    r = _build(env, env["tmp"] / "ev.zip")
    m = _members(env["tmp"] / "ev.zip"); top = f"evidence-{AS_OF}/dataroom/team-a/"
    assert {n[len(top):]: b for n, b in m.items() if n.startswith(top) and not n.endswith("/")} == src
    rman = json.loads(src["MANIFEST.json"])
    d = r["manifest"]["data_room"]
    assert d["source"] == "existing <outputs>/dataroom/<as_of>" and d["contract"] == "econquest.dataroom/1"
    assert (d["manifest_sha256"], d["content_sha256"], d["totals"]) == (rman["manifest_sha256"], rman["content_sha256"], rman["totals"])
    assert d["verify"]["ok"] and d["verify"]["anchor_failures"] == 0 and isinstance(d["verify"]["anchors"], list)
    # Team A redacts at source (EQ-A-0044); whatever is left is counted, never rewritten by us
    seen = {k: len(EV.EMAIL_RE.findall(b.decode("utf-8", "replace"))) for k, b in src.items()}
    assert d["addresses_seen_not_redacted"] == {k: n for k, n in seen.items() if n}
    assert not any(k.startswith("dataroom/team-a/") for k in r["manifest"]["redactions"]["e-mail addresses in other files"])
    v = EV.verify(env["tmp"] / "ev.zip")
    assert v["ok"] and v["data_room"]["ok"] and v["data_room"]["manifest_sha256"] == rman["manifest_sha256"], v["errors"]
    out = _extract_room(env["tmp"] / "ev.zip", env["tmp"] / "x")
    assert verify_data_room(out)["ok"]
    run = subprocess.run([sys.executable, "-I", str(out / "verify.py")], capture_output=True, text=True, cwd=env["tmp"])
    assert run.returncode == 0 and "RESULT: VERIFIED" in run.stdout


def test_data_room_is_built_in_a_temp_folder_never_into_the_outputs(env, monkeypatch):
    """No room for the date: one is built for this bundle in a temp folder (outside --data and --out) and removed; no
    room appears under <outputs>/dataroom, $ECONQUEST_HOME/outputs or the checkout's outputs/. --data-room also works."""
    from econquest.ingestion import dataroom as DR
    _room_data(env)
    real = EV.PACKAGE_PARENT / "outputs" / "dataroom"
    before = sorted(p.as_posix() for p in real.rglob("*")) if real.exists() else None
    home, tmpd = env["tmp"] / "home", env["tmp"] / "tmpdir"
    tmpd.mkdir(); monkeypatch.setenv("ECONQUEST_HOME", str(home)); monkeypatch.setattr(tempfile, "tempdir", str(tmpd))
    r = _build(env, env["tmp"] / "a" / "ev.zip")
    assert r["manifest"]["data_room"]["source"] == "built for this bundle (temporary, not kept)" and r["manifest"]["data_room"]["verify"]["ok"]
    assert not (env["out"] / "dataroom").exists() and not home.exists() and not list(tmpd.iterdir())
    assert (sorted(p.as_posix() for p in real.rglob("*")) if real.exists() else None) == before
    assert _build(env, env["tmp"] / "b" / "ev.zip")["sha256"] == r["sha256"]          # the temp build is deterministic
    assert EV.verify(env["tmp"] / "a" / "ev.zip")["ok"]
    elsewhere = _room(env, env["tmp"] / "rooms" / "r1")
    r2 = _build(env, env["tmp"] / "c" / "ev.zip", data_room=elsewhere)
    assert r2["manifest"]["data_room"]["source"] == "--data-room"
    assert r2["manifest"]["data_room"]["manifest_sha256"] == r["manifest"]["data_room"]["manifest_sha256"]
    other = env["tmp"] / "rooms" / "r2"; DR.build_data_room(env["data"], "2026-10-22", other)
    with pytest.raises(EV.EvidenceError, match="not 2026-10-23"):
        _build(env, env["tmp"] / "d" / "ev.zip", data_room=other)
    with pytest.raises(EV.EvidenceError, match="not a data room"):
        _build(env, env["tmp"] / "e" / "ev.zip", data_room=env["data"])


def test_tampered_data_room_fails_both_verifies(env):
    from econquest.ingestion.dataroom import verify_data_room
    _room_data(env)
    room = _room(env)
    good = env["tmp"] / "ev.zip"
    _build(env, good)
    top = f"evidence-{AS_OF}/"
    m = _members(good)
    led = top + "dataroom/team-a/data/live/review_ledger.csv"
    edited = m[led].replace(b",4,apply,", b",9,apply,")
    # a. the edit alone: our sha256 check and Team A's verify both fail
    bad = env["tmp"] / "bad.zip"
    _rewrite(good, bad, lambda n, b: edited if n == led else b)
    v = EV.verify(bad)
    assert not v["ok"] and not v["integrity_ok"] and not v["data_room"]["ok"]
    assert any("changed data/live/review_ledger.csv" in e for e in v["data_room"]["errors"])
    assert not verify_data_room(_extract_room(bad, env["tmp"] / "xa"))["ok"]
    # b. with our manifest rewritten to match, Team A's verify still catches it
    man = json.loads(m[top + "EVIDENCE-MANIFEST.json"])
    for f in man["files"]:
        if f["path"] == led[len(top):]:
            f["sha256"], f["size"] = hashlib.sha256(edited).hexdigest(), len(edited)
    forged = env["tmp"] / "forged.zip"
    _rewrite(good, forged, lambda n, b: edited if n == led else (json.dumps(man).encode() if n.endswith("EVIDENCE-MANIFEST.json") else b))
    v = EV.verify(forged)
    assert v["integrity_ok"] and not v["ok"] and not v["data_room"]["ok"]
    assert any(e.startswith("data room: changed data/live/review_ledger.csv") for e in v["errors"])
    rep = verify_data_room(_extract_room(forged, env["tmp"] / "xb"))
    assert not rep["ok"] and [c["path"] for c in rep["changed"]] == ["data/live/review_ledger.csv"]
    # c. a room tampered on disk is refused at build time
    p = room / "data" / "live" / "review_ledger.csv"; p.chmod(0o644); p.write_bytes(edited)
    with pytest.raises(EV.EvidenceError, match="fails Team A's verify: changed data/live/review_ledger.csv"):
        _build(env, env["tmp"] / "ev2.zip")


def test_secret_value_in_data_room_refuses_the_build(env, monkeypatch):
    """The room cannot be masked without breaking its verify, so a credential value in it stops the build."""
    _room_data(env, note="pasted CANARYROOM0007 by mistake")
    _room(env)                                          # the room keeps the value after the source is cleaned up
    _room_data(env)
    monkeypatch.setenv("ECONQUEST_SHEETS_TOKEN", "CANARYROOM0007")
    with pytest.raises(EV.EvidenceError, match=r"data room file .*review_ledger.csv contains the value of \$ECONQUEST_SHEETS_TOKEN") as ex:
        _build(env, env["tmp"] / "ev.zip")
    assert "CANARYROOM0007" not in str(ex.value) and not (env["tmp"] / "ev.zip").exists()


def test_bundle_carries_target_scorecard(env):
    _build(env, env["tmp"] / "t" / "ev.zip")
    m = _members(env["tmp"] / "t" / "ev.zip")
    assert f"evidence-{AS_OF}/targets/targets.csv" in m and f"evidence-{AS_OF}/targets/targets.md" in m


# ---- SEC-C-008 (AGENT-09 review of EQ-C-0060) regressions
def test_credential_values_and_names_never_ship(env, monkeypatch):
    monkeypatch.setenv("ECONQUEST_SHEETS_TOKEN", "CANARYENVTOK0005")
    (env["tmp"] / ".ops.env").write_text("export ECONQUEST_SMTP_PASSWORD='CANARYSMTP0001'\n")
    for rel, body in {"docs/governance/api_token.json": "CANARYDOC0002", "docs/governance/smtp-password.txt": "CANARYPASS0003",
                      "docs/governance/notes.md": "the token was CANARYENVTOK0005", "docs/validation/ops.md": "pw CANARYSMTP0001"}.items():
        (env["root"] / rel).write_text(body)
    actionlog.append(env["out"], "report", {"note": "old row: CANARYENVTOK0005"}, actor="Sam", actor_source="flag")  # pre-masking row
    _build(env, env["tmp"] / "ev.zip")
    blob = b"".join(_members(env["tmp"] / "ev.zip").values())
    for c in (b"CANARYENVTOK0005", b"CANARYSMTP0001", b"CANARYDOC0002", b"CANARYPASS0003"):
        assert c not in blob, c
    man = json.loads(_members(env["tmp"] / "ev.zip")[f"evidence-{AS_OF}/EVIDENCE-MANIFEST.json"])
    ex = " ".join(man["excluded_secret_like"])
    assert "docs/governance/api_token.json" in ex and "docs/governance/notes.md (contains the value of $ECONQUEST_SHEETS_TOKEN)" in ex
    assert "docs/validation/ops.md (contains the value of $ECONQUEST_SMTP_PASSWORD)" in ex
    assert b"[redacted:secret]" in _members(env["tmp"] / "ev.zip")[f"evidence-{AS_OF}/chains/outputs/store/actions.jsonl"]
    assert EV.verify(env["tmp"] / "ev.zip")["ok"]
    (env["data"] / "countries.csv").write_text("country\nCANARYENVTOK0005\n")   # an input holding one stops the build
    with pytest.raises(EV.EvidenceError, match="countries.csv contains the value of"):
        _build(env, env["tmp"] / "ev2.zip")


def test_every_address_is_redacted_docs_config_and_tests(env):
    cfg = json.loads((env["data"] / "distribution.json").read_text())
    cfg.update(reply_to="desk.lead@example.net", products={"daily": {"cc": ["cc.one@example.net"]}},
               archive_base_url="https://user:pw@files.example/arch?sig=CANARYSIG")
    (env["data"] / "distribution.json").write_text(json.dumps(cfg))
    (env["root"] / "docs/governance/contacts.md").write_text("escalate to head.desk@example.net\n")
    (env["tmp"] / "junit.xml").write_text(JUNIT.replace('name="a"/>', 'name="a"><system-out>to x.y@example.net</system-out></testcase>'))
    r = _build(env, env["tmp"] / "ev.zip")
    m = _members(env["tmp"] / "ev.zip")
    blob = b"".join(m.values())
    assert b"@example.net" not in blob and b"@example.com" not in blob and b"CANARYSIG" not in blob and b"user:pw" not in blob
    dist = json.loads(m[f"evidence-{AS_OF}/chains/distribution.redacted.json"])
    assert dist["archive_base_url"] == "https://files.example/arch" and dist["reply_to"].startswith("[redacted:recipient-")
    red = r["manifest"]["redactions"]["e-mail addresses in other files"]
    assert red["docs/governance/contacts.md"] == 1 and red["tests/junit.xml"] == 1
    assert EV.verify(env["tmp"] / "ev.zip")["ok"]


def test_store_path_with_hash_is_opened_read_only(env, tmp_path):
    import shutil
    out = tmp_path / "Desk #2" / "outputs"
    shutil.copytree(env["out"] / "store", out / "store")
    before = sorted(p.name for p in tmp_path.iterdir())
    assert [r["run_id"] for r in EV.stored_runs(out, AS_OF)] == ["20261023T225023-base"]
    assert sorted(p.name for p in tmp_path.iterdir()) == before          # no stray database created at "Desk "


def test_verify_refuses_duplicates_downgrades_and_undeclared_chains(env):
    good = env["tmp"] / "ev.zip"
    _build(env, good)
    top = f"evidence-{AS_OF}/"
    m = _members(good)
    man = json.loads(m[top + "EVIDENCE-MANIFEST.json"])
    log = m[top + "chains/data/approvals/log.jsonl"].replace(b"first use", b"first usE")
    for f in man["files"]:
        if f["path"] == "chains/data/approvals/log.jsonl":
            f["sha256"], f["size"] = hashlib.sha256(log).hexdigest(), len(log)

    def forged(name, change):
        man2 = json.loads(json.dumps(man)); change(man2)
        p = env["tmp"] / name
        _rewrite(good, p, lambda n, b: log if n.endswith("/chains/data/approvals/log.jsonl") else
                 (json.dumps(man2).encode() if n.endswith("EVIDENCE-MANIFEST.json") else b))
        return EV.verify(p)
    v = forged("downgrade.zip", lambda x: x["chains"]["approvals"].update(offline_check="linkage"))
    assert not v["ok"] and any("row_hash does not recompute" in e for e in v["chains"]["approvals"]["errors"])
    v = forged("undeclared.zip", lambda x: x["chains"].pop("approvals"))
    assert not v["ok"] and not v["chains"]["approvals"]["ok"]
    # a duplicate entry name, and a file that is also a folder, are refusals, not tracebacks
    dup = env["tmp"] / "dup.zip"
    with zipfile.ZipFile(good) as zi, zipfile.ZipFile(dup, "w") as zo:
        for i in zi.infolist():
            zo.writestr(i, zi.read(i))
        import warnings
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            zo.writestr(top + "chains/outputs/store/actions.jsonl", m[top + "chains/outputs/store/actions.jsonl"])
        zo.writestr(top + "chains/outputs/store/deliveries.jsonl/x", "x")
    v = EV.verify(dup)
    assert not v["ok"] and any("duplicate entry name" in e for e in v["errors"]) and any("cannot be extracted" in e for e in v["errors"])


# ---------------------------------------------------------------- SEC-C-009 (EQ-C-0069 review)
def _resigned(env, good, change_room, name):
    """A forger's archive: the room changed by change_room({rel: bytes}), its MANIFEST.json re-signed with Team A's own
    hash functions, and our EVIDENCE-MANIFEST rewritten to match (modes kept)."""
    from econquest.ingestion import dataroom_verify as DV
    top = f"evidence-{AS_OF}/"; pre = top + "dataroom/team-a/"
    m = _members(good)
    room = change_room({n[len(pre):]: b for n, b in m.items() if n.startswith(pre) and not n.endswith("/")})
    rm = json.loads(room["MANIFEST.json"])
    rm["files"] = [{"path": k, "sha256": hashlib.sha256(v).hexdigest(), "size": len(v)} for k, v in sorted(room.items()) if k != "MANIFEST.json"]
    rm["content_sha256"] = DV.content_hash(rm["files"]); rm["manifest_sha256"] = DV.manifest_hash(rm)
    room["MANIFEST.json"] = json.dumps(rm).encode()
    man = json.loads(m[top + "EVIDENCE-MANIFEST.json"])
    man["files"] = sorted([f for f in man["files"] if not f["path"].startswith("dataroom/team-a/")]
                          + [{"path": "dataroom/team-a/" + k, "sha256": hashlib.sha256(v).hexdigest(), "size": len(v)} for k, v in room.items()],
                          key=lambda f: f["path"])
    man["data_room"].update(manifest_sha256=rm["manifest_sha256"], content_sha256=rm["content_sha256"])
    out = env["tmp"] / name
    with zipfile.ZipFile(good) as zi, zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as zo:
        for i in zi.infolist():
            if i.filename.startswith(pre) and not i.is_dir():
                continue
            zo.writestr(i, json.dumps(man).encode() if i.filename.endswith("EVIDENCE-MANIFEST.json") else zi.read(i))
        mode = next(i.external_attr for i in zi.infolist() if i.filename == pre + "verify.py")
        for k, v in room.items():
            zi_ = zipfile.ZipInfo(pre + k, date_time=(1980, 1, 1, 0, 0, 0)); zi_.external_attr = mode
            zo.writestr(zi_, v)
    return out


def test_verify_never_runs_room_code_and_flags_a_foreign_verify_py(env, tmp_path, monkeypatch):
    """A fully re-signed room carrying code (a changed verify.py, planted modules) passed `evidence verify`, and the
    README tells the validator to run verify.py. verify must not execute any of it, and must fail on a verify.py that
    is not this installation's dataroom_verify.py when the bundle was built with this version."""
    _room_data(env); _room(env)
    good = env["tmp"] / "ev.zip"; _build(env, good)
    canary = tmp_path / "CANARY_EXECUTED"
    payload = f"open({str(canary)!r}, 'w').write('x')\n".encode()

    def evil(room):
        room["verify.py"] = payload + room["verify.py"]
        for n in ("dataroom_verify.py", "json.py", "hashlib.py", "csv.py", "__init__.py", "sitecustomize.py"):
            room[n] = payload
        return room
    bad = _resigned(env, good, evil, "evil.zip")
    monkeypatch.chdir(tmp_path)
    v = EV.verify(bad)
    assert not canary.exists()
    assert v["integrity_ok"] and not v["ok"] and v["data_room"]["verify_py_matches_installed"] is False
    assert any("verify.py is not this installation's" in e for e in v["errors"])
    ok = EV.verify(good)
    assert ok["ok"] and ok["data_room"]["verify_py_matches_installed"] is True and ok["data_room"]["warnings"] == []
    # built with another version: reported as a warning, not a failure (verify.py legitimately differs across releases)
    m = _members(bad); top = f"evidence-{AS_OF}/"
    man = json.loads(m[top + "EVIDENCE-MANIFEST.json"]); man["code_version"] = "0.0.0-other"
    other = env["tmp"] / "other.zip"
    _rewrite(bad, other, lambda n, b: json.dumps(man).encode() if n.endswith("EVIDENCE-MANIFEST.json") else b)
    w = EV.verify(other)
    assert not canary.exists() and not any("verify.py" in e for e in w["errors"])
    assert any("bundle built with econquest 0.0.0-other" in x for x in w["data_room"]["warnings"])


@pytest.mark.parametrize("body", [b"[]", b"\xff\xfe not utf-8", b'"text"'])
def test_room_manifest_that_is_not_an_object_is_an_error_not_a_traceback(env, body):
    _room_data(env); _room(env)
    good = env["tmp"] / "ev.zip"; _build(env, good)
    pre = f"evidence-{AS_OF}/dataroom/team-a/MANIFEST.json"
    bad = env["tmp"] / "bad.zip"
    _rewrite(good, bad, lambda n, b: body if n == pre else b)
    v = EV.verify(bad)
    assert not v["ok"] and not v["data_room"]["ok"] and v["data_room"]["errors"]
