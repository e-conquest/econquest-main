"""Shared pytest fixtures.

EQ-A-0037: feeds.fetch_all probes each feed's hosts before pulling (feeds.probe_host, one HEAD request). Tests never
touch the network, so the probe answers "reachable" by default and the feed mocks each test installs decide what
happens. Tests of the probe itself (tests/test_feeds_offline.py) replace this stub with their own."""
import pytest


@pytest.fixture(autouse=True)
def _no_network_probe(monkeypatch):
    from econquest.ingestion import feeds
    monkeypatch.setattr(feeds, "probe_host", lambda host, timeout=feeds.PROBE_TIMEOUT: None)
