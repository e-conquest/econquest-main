"""EQ-A-0044: staleness rule for BIS series in feeds.quality_gate (the World Bank rule is WB_STALE_SERIES). A BIS value
is held when its last observation is older than BIS_STALE_DAYS for its frequency (daily 30, monthly 92, quarterly 275)
at the gate's reference date. Offline; every number here is SYNTHETIC, shaped like raw_bis.csv (Argentina's policy rate
ending 2025-07-10 is the case the limitations register found)."""
import datetime as dt
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.ingestion.feeds import (BIS_STALE_DAYS, FetchReport, _period_end, bis_staleness,  # noqa: E402
                                       quality_gate)

REF = dt.date(2026, 10, 23)


def _raw():
    rows = []
    for d in pd.bdate_range("2025-06-02", "2025-07-10"):                 # ARG: stops 2025-07-10
        rows.append({"iso": "ARG", "series": "POLICY_RATE", "period": d.strftime("%Y-%m-%d"), "value": 29.0, "source": "test"})
    for d in pd.bdate_range("2026-09-01", "2026-10-20"):                 # BRA: current
        rows.append({"iso": "BRA", "series": "POLICY_RATE", "period": d.strftime("%Y-%m-%d"), "value": 15.0, "source": "test"})
    rows += [{"iso": "BRA", "series": "CREDIT_GAP", "period": "2026-Q1", "value": 2.0, "source": "test"},
             {"iso": "ARG", "series": "CREDIT_GAP", "period": "2025-Q3", "value": -3.0, "source": "test"},
             {"iso": "BRA", "series": "EER_REAL_BROAD", "period": "2026-09", "value": 101.0, "source": "test"},
             {"iso": "ARG", "series": "EER_REAL_BROAD", "period": "2026-06", "value": 90.0, "source": "test"}]
    return pd.DataFrame(rows)


def _gate(as_of=REF, retrieved="2026-10-23"):
    countries = pd.DataFrame({"country": ["Argentina", "Brazil"], "iso": ["ARG", "BRA"], "iso2": ["AR", "BR"],
                              "currency": ["ARS", "BRL"]})
    rulebook = pd.DataFrame({"id": ["5.13", "5.9", "2.12"], "t0": [-10, -20, -30], "t25": [-5, -10, -15], "t50": [0, 0, 0],
                             "t75": [5, 10, 15], "t100": [10, 20, 30]})
    u = SimpleNamespace(names=["Argentina", "Brazil"], countries=countries, rulebook=rulebook)
    ind = pd.DataFrame({"Argentina": [2.0, -3.0, -1.0], "Brazil": [9.0, 2.0, 1.0]}, index=["5.13", "5.9", "2.12"])
    prof = pd.DataFrame(np.nan, index=u.names, columns=["pop", "exports", "reserves", "fx3m", "policy", "equity_vol"])
    prof["policy"] = [29.0, 15.0]
    prov = pd.DataFrame([{"table": "Inputs", "key": "5.13", "country": "Brazil", "value": 9.0, "source": "test",
                          "series": "WS_CBPOL", "retrieved": retrieved}])
    rep = FetchReport(ind, prof, prov, {"bis": "ok (synthetic)"}, {"bis": _raw()})
    diff = pd.DataFrame([{"table": "Inputs", "key": k, "country": c, "seed": ind.at[k, c], "live": ind.at[k, c]}
                         for k in ind.index for c in u.names]
                        + [{"table": "Country Profile", "key": "policy", "country": c, "seed": prof.at[c, "policy"],
                            "live": prof.at[c, "policy"]} for c in u.names])
    return quality_gate(u, rep, diff, year=2026, as_of=as_of).set_index(["table", "key", "country"])


def test_period_end_per_frequency():
    assert _period_end("2025-07-10") == (dt.date(2025, 7, 10), "D")
    assert _period_end("2026-09") == (dt.date(2026, 9, 30), "M")
    assert _period_end("2026-12") == (dt.date(2026, 12, 31), "M")
    assert _period_end("2026-Q1") == (dt.date(2026, 3, 31), "Q")
    assert _period_end("2025-Q4") == (dt.date(2025, 12, 31), "Q")
    assert _period_end("2026") is None and _period_end("garbage") is None
    assert BIS_STALE_DAYS == {"D": 30, "M": 92, "Q": 275}


def test_argentina_policy_rate_ending_2025_07_10_is_held():
    r = _gate()
    for key, table in (("5.13", "Inputs"), ("policy", "Country Profile")):
        row = r.loc[(table, key, "Argentina")]
        assert row["status"] == "hold"
        assert "stale: BIS POLICY_RATE last observation 2025-07-10, 470 days before 2026-10-23 (limit 30 days, daily)" in row["reason"]
        assert r.loc[(table, key, "Brazil"), "status"] == "ok"                  # 3 days old


def test_monthly_and_quarterly_limits():
    r = _gate()
    # ARG REER 2026-06 ends 06-30: 115 days > 92 -> stale; BRA 2026-09 ends 09-30: 23 days -> fresh
    assert "stale: BIS EER_REAL_BROAD last observation 2026-06-30, 115 days" in r.loc[("Inputs", "2.12", "Argentina"), "reason"]
    assert r.loc[("Inputs", "2.12", "Brazil"), "status"] == "ok"
    # ARG credit gap 2025-Q3 ends 09-30: 388 days > 275 -> stale; BRA 2026-Q1 ends 03-31: 206 days -> fresh
    assert "stale: BIS CREDIT_GAP last observation 2025-09-30, 388 days" in r.loc[("Inputs", "5.9", "Argentina"), "reason"]
    assert r.loc[("Inputs", "5.9", "Brazil"), "status"] == "ok"


@pytest.mark.parametrize("ref,held", [(dt.date(2025, 8, 9), False), (dt.date(2025, 8, 10), True)])
def test_daily_limit_boundary(ref, held):
    """30 days after 2025-07-10 is 2025-08-09 (still fresh); one day later it is stale."""
    assert bool(bis_staleness(_raw(), "ARG", "POLICY_RATE", ref)) is held


def test_reference_date_defaults_to_pull_date():
    """Without as_of the reference is the pull date (provenance 'retrieved'), so a replay of an old pull is judged as
    of that pull, not as of today."""
    r = _gate(as_of=None, retrieved="2025-07-20")
    assert r.loc[("Inputs", "5.13", "Argentina"), "status"] == "ok"            # 10 days old on 2025-07-20
    assert r.loc[("Inputs", "5.9", "Argentina"), "status"] == "ok"             # 2025-Q3 not even over yet


def test_no_rows_for_country_is_not_reported_as_stale():
    assert bis_staleness(_raw(), "VNM", "POLICY_RATE", REF) == ""
    assert bis_staleness(None, "ARG", "POLICY_RATE", REF) == ""
