"""`econquest run --vintage` and vintage columns in `econquest runs` (EQ-C-0015, HO-20261023-A-C-006 items 2-3)."""
from types import SimpleNamespace

import pytest

from econquest import cli


def test_vintage_refused_with_live_markets(monkeypatch):
    monkeypatch.setattr(cli, "load_universe", lambda *a, **k: pytest.fail("must refuse before loading"))
    with pytest.raises(SystemExit, match="--live-markets"):
        cli._load(SimpleNamespace(data="data", vintage="20261023T000000Z", live_markets=True))


@pytest.mark.parametrize("drift,warned", [([], False), (["assumptions.json"], True)])
def test_vintage_passed_to_loader_and_drift_warned(monkeypatch, capsys, drift, warned):
    seen = {}

    def fake_load(data, live_markets=False, vintage=None):
        seen.update(data=data, live_markets=live_markets, vintage=vintage)
        return SimpleNamespace(provenance={"replay": {"vintage_id": "V1", "inputs_hash": "abc123", "drift": drift}})
    monkeypatch.setattr(cli, "load_universe", fake_load)
    cli._load(SimpleNamespace(data="data", vintage="V1", live_markets=False))
    assert seen == {"data": "data", "live_markets": False, "vintage": "V1"}
    err = capsys.readouterr()
    assert "Replaying vintage V1" in err.out and ("not an exact replay" in err.err) == warned
    if warned:
        assert "assumptions.json" in err.err


def test_no_vintage_unchanged(monkeypatch):
    seen = {}
    monkeypatch.setattr(cli, "load_universe", lambda data, live_markets=False, **k: seen.update(k=k, lm=live_markets) or SimpleNamespace(provenance={}))
    cli._load(SimpleNamespace(data="data", live_markets=True))
    assert seen == {"k": {}, "lm": True}


def test_run_parser_accepts_vintage(monkeypatch):
    got = {}
    monkeypatch.setattr(cli, "cmd_run", lambda args: got.setdefault("v", args.vintage))
    cli.main(["run", "--vintage", "2026-10-23"])
    assert got["v"] == "2026-10-23"


def test_runs_shows_vintage_and_inputs_hash(monkeypatch, capsys):
    class FakeStore:
        def __init__(self, path): pass

        def runs(self, limit=20):
            mk = lambda rid, v: {"run_id": rid, "label": "base", "created_at": "2026-10-23T10:00:00",
                                 "summary": {"metrics": {"var99_mm": 1.0, "es99_mm": 2.0}, "global_regime": "Normal", "versions": v}}
            return [mk("r2", {"code_hash": "c", "data_hash": "d", "vintage_id": "20261023T090000Z", "inputs_hash": "ih42"}),
                    mk("r1", {"code_hash": "c", "data_hash": "d"})]                 # older run: no vintage fields
    monkeypatch.setattr(cli, "Store", FakeStore)
    cli.main(["runs"])
    o = capsys.readouterr().out
    assert "vintage" in o and "inputs" in o and "20261023T090000Z" in o and "ih42" in o and "r1" in o
