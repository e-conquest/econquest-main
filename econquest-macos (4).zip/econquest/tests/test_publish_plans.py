"""Publish-plan builders (EQ-C-0003): sheets_publish.build_plan, record_plan, garch_plan, econ_plan.

These test the plan shape (every block is a {"range", "values"} pair whose values fit inside its A1 range, JSON-safe
cells, the contract C11 anchors) and not the wording of notes, which other tickets may change (formula escaping of
text cells is owned by the sheets_publish work)."""
import json
import re
import sys
import types
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.config import Settings  # noqa: E402
from econquest.ingestion import load_universe  # noqa: E402
from econquest.engine import run_pipeline  # noqa: E402
from econquest.presentation import sheets_publish as SP  # noqa: E402
from econquest.presentation.record_publish import record_plan, COLS as REC_COLS, HEAD as REC_HEAD  # noqa: E402
from econquest.presentation.garch_publish import garch_plan, garch_tables, _r  # noqa: E402
from econquest.presentation.econ_publish import econ_plan  # noqa: E402

DATA = ROOT / "data"
AS_OF = "2026-10-23"
A1 = re.compile(r"^(?:'(?P<qt>[^']+)'|(?P<t>[A-Za-z][A-Za-z0-9 _&-]*))!(?P<c1>[A-Z]{1,3})(?P<r1>\d+)(?::(?P<c2>[A-Z]{1,3})(?P<r2>\d+))?$")


def col_num(c: str) -> int:
    n = 0
    for ch in c:
        n = n * 26 + ord(ch) - 64
    return n


def parse_range(rng: str) -> tuple[str, int, int, int, int]:
    m = A1.match(rng)
    assert m, f"not an A1 range: {rng!r}"
    tab = m["qt"] or m["t"]
    c1, r1 = col_num(m["c1"]), int(m["r1"])
    c2, r2 = (col_num(m["c2"]), int(m["r2"])) if m["c2"] else (c1, r1)
    assert c2 >= c1 and r2 >= r1, rng
    return tab, r1, c1, r2 - r1 + 1, c2 - c1 + 1


def assert_plan_shape(plan: list[dict]) -> dict[str, dict]:
    """Every block is well formed, fits its range and is JSON-safe (no NaN/inf). Returns blocks by range."""
    assert isinstance(plan, list) and plan
    out = {}
    for b in plan:
        assert set(b) >= {"range", "values"}
        _, _, _, nrows, ncols = parse_range(b["range"])
        vals = b["values"]
        assert isinstance(vals, list) and vals and all(isinstance(r, list) for r in vals), b["range"]
        assert len(vals) <= nrows, f"{b['range']}: {len(vals)} rows for a {nrows}-row range"
        assert max(len(r) for r in vals) <= ncols, f"{b['range']}: {max(len(r) for r in vals)} columns for a {ncols}-column range"
        json.dumps(vals, allow_nan=False)                     # raises on NaN / inf / numpy scalars
        out[b["range"]] = b
    return out


@pytest.fixture(scope="module")
def engine_run():
    u = load_universe(DATA); s = Settings.load(DATA / "assumptions.json")
    try:
        res = run_pipeline(u, s, paths=2000, as_of=AS_OF)
    except TypeError:                                         # pipeline without the as_of keyword (before EQ-B-0001)
        res = run_pipeline(u, s, paths=2000)
    return u, s, res


# ---------------------------------------------------------------- sheets_publish helpers
def test_cell_value_helper():
    assert SP._v(None) == "" and SP._v(float("nan")) == "" and SP._v(np.inf) == "" and SP._v(-np.inf) == ""
    assert SP._v(np.int64(3)) == 3 and type(SP._v(np.int64(3))) is int
    assert SP._v(np.float32(1.5)) == 1.5 and type(SP._v(np.float64(2.0))) is float
    assert SP._v(np.bool_(True)) is True and SP._v(False) is False
    assert SP._v(pd.Timestamp("2026-10-23 15:00")) == "2026-10-23"
    assert SP._v("text") == "text"
    b = SP._block("Tab!A1:B2", [[1, np.nan], [np.int64(2), None]])
    assert b == {"range": "Tab!A1:B2", "values": [[1, ""], [2, ""]]}
    df = pd.DataFrame({"a": [1.0, np.nan], "b": ["x", "y"]})
    assert SP._rows(df) == [[1.0, "x"], ["", "y"]]


def test_range_parser_self_check():
    assert parse_range("'Risk Engine'!E5:V37") == ("Risk Engine", 5, 5, 33, 18)
    assert parse_range("MC!Z7:BD2006")[3:] == (2000, 31)
    assert parse_range("Signals!A2") == ("Signals", 2, 1, 1, 1)


# ---------------------------------------------------------------- build_plan
def test_build_plan_shape_and_c11_anchors(engine_run):
    u, s, res = engine_run
    history = pd.read_csv(DATA / "backtest_history.csv") if (DATA / "backtest_history.csv").exists() else None
    plan = SP.build_plan(res, u, s, history=history, stamp=AS_OF, mc_rows=50)
    blocks = assert_plan_shape(plan)
    n = len(u.names)
    assert n == 18
    # Risk Engine rows 5-37, one column per country; R31-R33 labels (contract C11)
    re_block = blocks["'Risk Engine'!E5:V37"]["values"]
    assert len(re_block) == 33 and all(len(r) == n for r in re_block)
    labels = blocks["'Risk Engine'!A35:D37"]["values"]
    assert [r[0] for r in labels] == ["R31", "R32", "R33"]
    # default PD row (row 19 = index 14) equals the engine's pd_default per country, in workbook order
    assert re_block[14] == pytest.approx([float(res.country.at[c, "pd_default"]) for c in u.names])
    # every country probability on the Risk Engine is in [0, 1] (rows R14-R15 pd_final/pd_default, R21-R25 perils)
    for i in (13, 14, 20, 21, 22, 23, 24):
        assert all(v == "" or 0.0 <= v <= 1.0 for v in re_block[i]), i
    # A2 run-date notes carry the stamp and run id (contract C11: A2 run date)
    a2 = [b for r, b in blocks.items() if r.endswith("!A2")]
    assert len(a2) >= 8 and all(AS_OF in str(b["values"][0][0]) and res.run_id in str(b["values"][0][0]) for b in a2)
    # Portfolio VaR headline column: VaR99 <= ES99, paths last
    pv = [r[0] for r in blocks["'Portfolio VaR'!E37:E46"]["values"]]
    m = res.metrics
    assert pv[5] == pytest.approx(m["var99_mm"]) and pv[7] == pytest.approx(m["es99_mm"]) and pv[5] <= pv[7] and pv[9] == m["paths"]
    # positions block always padded to 30 rows x 18 columns
    pos = blocks["'Portfolio VaR'!H5:Y34"]["values"]
    assert len(pos) == 30 and all(len(r) == 18 for r in pos)
    # MC tab honours mc_rows
    assert "MC!A7:X56" in blocks and len(blocks["MC!A7:X56"]["values"]) == 50
    # backtesting block present when a history is passed
    if history is not None:
        assert "Backtesting!G5:I12" in blocks
        k = len(history)
        assert f"Backtesting!F17:K{16 + k}" in blocks and len(blocks[f"Backtesting!F17:K{16 + k}"]["values"]) == k


def test_build_plan_without_history_skips_backtesting(engine_run):
    u, s, res = engine_run
    plan = SP.build_plan(res, u, s, history=None, stamp=AS_OF, mc_rows=10)
    assert_plan_shape(plan)
    assert not any(b["range"].startswith("Backtesting!") for b in plan)


def test_save_plan_roundtrip(tmp_path, engine_run):
    u, s, res = engine_run
    plan = SP.build_plan(res, u, s, stamp=AS_OF, mc_rows=5)
    p = tmp_path / "publish_plan.json"
    SP.save_plan(plan, p)
    assert json.loads(p.read_text()) == plan


def test_apply_plan_builds_batch_update_without_network(monkeypatch):
    seen = {}

    class Resp:
        def __enter__(self):
            return self

        def __exit__(self, *a):
            return False

        def read(self):
            return b'{"totalUpdatedCells": 3}'

    def fake_urlopen(req, timeout=None):
        seen["url"], seen["method"], seen["body"], seen["headers"], seen["timeout"] = req.full_url, req.get_method(), json.loads(req.data), {**req.headers, **req.unredirected_hdrs}, timeout
        return Resp()

    monkeypatch.setattr(SP.urllib.request, "urlopen", fake_urlopen)
    plan = [{"range": "Tab!A1:B1", "values": [[1, 2]]}, {"range": "'Risk Engine'!A2", "values": [["note"]]}]
    out = SP.apply_plan(plan, "SHEET123", "tok")
    assert out == {"totalUpdatedCells": 3}
    assert seen["url"] == "https://sheets.googleapis.com/v4/spreadsheets/SHEET123/values:batchUpdate" and seen["method"] == "POST"
    assert seen["body"]["valueInputOption"] == "USER_ENTERED" and [d["range"] for d in seen["body"]["data"]] == ["Tab!A1:B1", "'Risk Engine'!A2"]
    assert seen["headers"].get("Authorization") == "Bearer tok"


# ---------------------------------------------------------------- record_plan
def _record(n: int) -> pd.DataFrame:
    dates = pd.bdate_range("2026-06-01", periods=n)
    rng = np.random.default_rng(1)
    df = pd.DataFrame({"date": dates, "loss": rng.normal(0, 0.4, n), "var": 1.0, "es": 1.3, "var_next": 1.0, "es_next": 1.3,
                       "var99_12m": 68.0, "es99_12m": 87.0, "regime": "Calm", "marked_positions": 13, "marked_notional_mm": 150.0,
                       "code_hash": "c", "data_hash": "d", "recorded_at": "2026-10-23T09:00:00"})
    df.loc[0, "loss"] = np.nan
    return df


def test_record_plan_shape_newest_first_and_header():
    rec = _record(30)
    plan = record_plan(rec)
    blocks = assert_plan_shape([{**b, "values": [[("" if v is None else v) for v in r] for r in b["values"]]} for b in plan])
    body_rng = f"'Forecast Record'!A4:N{4 + len(rec)}"
    assert set(blocks) == {"'Forecast Record'!A1:A2", body_rng}
    body = next(b for b in plan if b["range"] == body_rng)["values"]
    assert body[0] == REC_HEAD and len(REC_HEAD) == len(REC_COLS) == 14
    dates = [r[0] for r in body[1:]]
    assert dates == sorted(dates, reverse=True) and dates[0] == rec["date"].max().date().isoformat()
    assert body[-1][1] is None                                 # the NaN loss of the oldest day becomes an empty cell
    head = next(b for b in plan if b["range"].endswith("A1:A2"))["values"]
    assert "30" in head[1][0] and "Kupiec" in head[1][0]       # >= 20 testable rows: backtest summary line


def test_record_plan_short_record_and_custom_sheet():
    plan = record_plan(_record(5), sheet="FR test")
    assert plan[0]["range"] == "'FR test'!A1:A2" and plan[1]["range"] == "'FR test'!A4:N9"
    assert "20 rows" in plan[0]["values"][1][0]                # explains why there is no backtest yet


# ---------------------------------------------------------------- garch_plan
def test_round_helper():
    assert _r(None) == "" and _r(float("nan")) == "" and _r(np.inf) == ">1000" and _r(np.bool_(True)) is True
    assert _r(1.23456, 2) == 1.23 and _r("x") == "x"


@pytest.fixture(scope="module")
def garch_result():
    from econquest.engine.garch import run_garch, load_prices
    px = load_prices(DATA)
    if px is None:
        pytest.skip("no data/market_history/prices.csv")
    u = load_universe(DATA); s = Settings.load(DATA / "assumptions.json")
    sub = px[[c for c in ("USDBRL", "USDJPY", "EWZ", "EWJ") if c in px.columns]]
    if sub.shape[1] < 2:
        pytest.skip("snapshot lacks the test tickers")
    return u, run_garch(u, sub, s, None)


def test_garch_plan_shape(garch_result):
    u, g = garch_result
    plan = garch_plan(g, u, stamp=AS_OF)
    blocks = assert_plan_shape(plan)
    assert "GARCH!A4:Z4" in blocks and len(blocks["GARCH!A4:Z4"]["values"][0]) == 26
    table_a = blocks["GARCH!A5:Z34"]["values"]
    assert len(table_a) == 30 and sum(1 for r in table_a if r[0] != "") == len(g.series)
    assert AS_OF in blocks["GARCH!A1:A2"]["values"][0][0]
    # blocks do not overlap on the tab: each starts below the previous one
    starts = [parse_range(b["range"])[1] for b in plan if parse_range(b["range"])[2] == 1]
    assert starts == sorted(starts) and len(set(starts)) == len(starts)
    tables = garch_tables(g)
    assert {"series", "options", "macro"} <= set(tables)


# ---------------------------------------------------------------- econ_plan (fake result: plan layout only)
def _fake_econ():
    df = lambda **cols: pd.DataFrame(cols)  # noqa: E731
    return types.SimpleNamespace(
        as_of="2026-10-22",
        workflow=df(country=["Brazil", "Japan"], kind=["FX", "Equity"], ticker=["USDBRL", "EWJ"], obs=[750, 750], adf_return_bh_reject=[True, False], adf_price_p=[0.4, np.nan]),
        cointegration=df(group=["LatAm"], y=["EWZ"], x=["EWW"], eg_p=[0.03], eg_bh_reject=[True]),
        svar=df(shock=["EEM"], variable=["USDBRL"], h0=[0.1]), svar_meta={"lags": 2, "obs": 700, "order": ["EEM", "USDBRL"], "shock_sd_pct": [1.0, 0.5]},
        kalman=df(country=["Brazil"], beta_now=[1.1]), regimes=df(country=["Brazil"], ms_p_turbulent_now=[0.2]),
        premia_fm=pd.DataFrame({"premium_per_period": [0.001]}, index=["EM market"]), premia_gmm=pd.DataFrame({"premium_per_period": [0.002]}, index=["EM market"]),
        premia_meta={"N": 12, "T": 150, "J": 3.2, "J_p": 0.5, "r2_cross_section": 0.1},
        evt=df(country=["Brazil"], gpd_xi=[0.2]), copulas=df(pair=["EWZ/EWW"], kendall_tau=[0.4]),
        forecasts=df(model=["OLS"], r2_out_of_sample=[0.3]), forecast_importance=pd.DataFrame({"lasso_coef": [0.1]}, index=["vol_21d"]),
        events=df(country=["Brazil"], n_events=[4]), notes={"forecast_split": "2025-06-30"})


def test_econ_plan_layout():
    plan, titles = econ_plan(_fake_econ(), stamp=AS_OF)
    blocks = assert_plan_shape(plan)
    assert len(titles) == 12 and titles == sorted(titles) and titles[0] == 4
    assert all(f"Econometrics!A{t}" in blocks for t in titles)                    # each table starts with its title cell
    wf = next(b for b in plan if b["range"].startswith("Econometrics!A6:"))      # Table 1: title row 4, note row 5, header row 6
    assert parse_range(wf["range"])[4] == 28 and wf["range"].split(":")[1].startswith("AB")
    assert wf["values"][1][9] == "yes" and wf["values"][2][9] == "no"            # booleans become yes / no
    assert wf["values"][2][5] == ""                                              # NaN becomes an empty cell
    rows = [parse_range(b["range"]) for b in plan]
    for (_, r1, _, n1, _), (_, r2, _, _, _) in zip(rows, rows[1:]):
        assert r2 >= r1 + n1, "blocks overlap"                                   # tables are stacked top to bottom
    assert AS_OF in blocks["Econometrics!A1:A2"]["values"][0][0] and "2026-10-22" in blocks["Econometrics!A1:A2"]["values"][0][0]
