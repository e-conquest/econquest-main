"""`econquest replicate-archive` passes its flags through to econquest.validation.replicate_archive.main and returns
its exit code (HO-20261024-B-C-003 part 1, EQ-C-0067). The replication itself is Team B's (tests/test_replicate_archive.py)."""
from pathlib import Path

import pytest

from econquest import cli
from econquest.validation import replicate_archive as RA


class Calls(list):
    code = 0


@pytest.fixture
def calls(monkeypatch):
    seen = Calls()

    def fake_main(argv=None):
        seen.append(argv)
        return seen.code
    monkeypatch.setattr(RA, "main", fake_main)
    return seen


def test_default_out_is_under_global_out(calls, tmp_path):
    cli.main(["--out", str(tmp_path / "o"), "replicate-archive"])
    assert calls == [["--out", str(tmp_path / "o" / "replication-archive")]]   # --archive/--db/--zip: the module's defaults


def test_default_out_is_outputs_replication_archive(calls):
    cli.main(["replicate-archive"])
    assert calls == [["--out", str(Path(cli.DEFAULT_OUT) / "replication-archive")]]


def test_flags_pass_through(calls, tmp_path):
    z = tmp_path / "rel.zip"; z.write_bytes(b"")           # an explicit --zip must exist (SEC-C-009)
    cli.main(["replicate-archive", "--out", str(tmp_path / "ra"), "--archive", "arch", "--db", "none", "--zip", str(z), "--rerun"])
    assert calls == [["--out", str(tmp_path / "ra"), "--archive", "arch", "--db", "none", "--zip", str(z), "--rerun"]]


def test_rerun_and_zip_alone(calls):
    cli.main(["replicate-archive", "--zip", "none", "--rerun"])
    assert calls[0][2:] == ["--zip", "none", "--rerun"]


def test_exit_code_passed_through(calls):
    calls.code = 1
    with pytest.raises(SystemExit) as e:
        cli.main(["replicate-archive"])
    assert e.value.code == 1


def test_exit_zero_returns_normally(calls):
    assert cli.main(["replicate-archive"]) in (None, 0)


def test_help_names_flags(capsys):
    with pytest.raises(SystemExit) as e:
        cli.main(["replicate-archive", "--help"])
    h = "".join(capsys.readouterr().out.split())        # argparse wraps at spaces and hyphens
    assert e.value.code == 0
    for flag in ("--out", "--archive", "--db", "--zip", "--rerun"):
        assert flag in h
    assert "releasenotes0.1.1-0.1.5" in h and "findings-register" in h and "--rerun]" in h


def test_real_module_argv_is_accepted(monkeypatch, tmp_path):
    """The argv the CLI builds parses in the real replicate_archive.main (flags kept in step with Team B's parser)."""
    seen = {}
    monkeypatch.setattr(RA, "replicate_archive", lambda *a: seen.setdefault("a", a) and {"counts": {}, "uncatalogued": 0, "md": "x", "unexplained": 0})
    cli.main(["replicate-archive", "--out", str(tmp_path), "--archive", "A", "--db", "none", "--zip", "none", "--rerun"])
    assert seen["a"] == (str(tmp_path), "A", None, None, True)


# ---------------------------------------------------------------- SEC-C-009 (EQ-C-0067 review)
def test_missing_zip_is_refused_not_silently_skipped(calls, tmp_path):
    """An explicit --zip that is not a file used to run with no zip (every zip row NOT_RUN, meta zip 'none')."""
    with pytest.raises(SystemExit) as e:
        cli.main(["replicate-archive", "--out", str(tmp_path / "o"), "--zip", str(tmp_path / "typo.zip")])
    assert str(e.value.code).startswith("replicate-archive: --zip ") and "is not a file" in str(e.value.code)
    assert calls == [] and not (tmp_path / "o").exists()


def test_dash_value_stays_the_flags_value(calls, tmp_path):
    z = tmp_path / "-x.zip"; z.write_bytes(b"")
    cli.main(["replicate-archive", "--out=-o", "--archive=-a", "--zip", str(z)])
    assert calls == [["--out=-o", "--archive=-a", "--zip", str(z)]]


def test_dash_value_parses_in_the_real_module(monkeypatch, tmp_path):
    seen = {}
    monkeypatch.setattr(RA, "replicate_archive", lambda *a: seen.setdefault("a", a) and {"counts": {}, "uncatalogued": 0, "md": "x", "unexplained": 0})
    cli.main(["replicate-archive", "--out=-o", "--archive=-a", "--db", "none", "--zip", "none"])
    assert seen["a"] == ("-o", "-a", None, None, False)     # was: "error: argument --out: expected one argument"


@pytest.mark.parametrize("exc", [ValueError("--out /x/archive/o is inside the archive folder /x/archive;\n the archive is read-only"),
                                 OSError("[Errno 2] No such file"), __import__("zipfile").BadZipFile("File is not a zip file")])
def test_module_errors_are_one_line_exits(monkeypatch, exc):
    def boom(argv=None):
        raise exc
    monkeypatch.setattr(RA, "main", boom)
    with pytest.raises(SystemExit) as e:
        cli.main(["replicate-archive", "--zip", "none"])
    assert str(e.value.code).startswith("replicate-archive: ") and "\n" not in str(e.value.code)
