"""`econquest vendor status|test|pull` over Team A's econquest/ingestion/market/vendors/ (HO-20261023-A-C-021, EQ-C-0058).
ROADMAP: PAID FEATURE, OFF BY DEFAULT. Everything here is SYNTHETIC: the blpapi and lseg.data modules are the in-memory
fakes from tests/test_market_vendors.py, put in sys.modules; fictional tickers, sovereigns and licence ids. No network."""
import json
import sys

import pandas as pd
import pytest

from econquest import cli
from econquest.ingestion.market.store import cds_snapshots_path, list_market_snapshots, market_root
from econquest.presentation import gui
from test_market_vendors import APP_KEY, BBG5, BBG10, BBGX, MAPPING, RIC5, RIC10, fake_blpapi, fake_ld, lseg_history  # noqa: E402

BBG_LIC = "licence_id=FAKE-BBG-0001;holder=Synthetic Desk;scope=desk-internal;expiry=2099-12-31"
LSEG_LIC = "licence_id=FAKE-LSEG-0001;holder=Synthetic Desk;scope=desk-internal;expiry=2099-12-31"
VENDOR_ENV = ("ECONQUEST_VENDOR_LICENCE_BLOOMBERG", "ECONQUEST_VENDOR_LICENCE_LSEG", "ECONQUEST_LSEG_APP_KEY",
              "ECONQUEST_LSEG_SESSION", "ECONQUEST_LSEG_USERNAME", "ECONQUEST_LSEG_PASSWORD", "ECONQUEST_BPIPE_HOST",
              "ECONQUEST_BPIPE_PORT", "ECONQUEST_BPIPE_APP_NAME")


@pytest.fixture
def data(tmp_path, monkeypatch):
    """A data folder with the synthetic ticker map, no vendor package importable and no licence configured."""
    monkeypatch.setenv("ECONQUEST_ACTION_LOG", str(tmp_path / "actions.jsonl"))
    for k in VENDOR_ENV:
        monkeypatch.delenv(k, raising=False)
    for mod in ("blpapi", "lseg", "lseg.data"):          # None in sys.modules: not importable, as on a machine without them
        monkeypatch.setitem(sys.modules, mod, None)
    d = tmp_path / "data"
    market_root(d).mkdir(parents=True)
    MAPPING.to_csv(market_root(d) / "ticker_map.csv", index=False)
    return d


def vendor(d, *a):
    cli.main(["--data", str(d), "--out", str(d.parent / "outputs"), "vendor", *a])


def vendor_exit(d, *a) -> int:
    with pytest.raises(SystemExit) as e:
        vendor(d, *a)
    return e.value.code


def actions(d):
    p = d.parent / "actions.jsonl"
    return [json.loads(x) for x in p.read_text().splitlines()] if p.exists() else []


def licensed_bloomberg(monkeypatch, **kw):
    m = fake_blpapi(**kw)
    monkeypatch.setitem(sys.modules, "blpapi", m)
    monkeypatch.setenv("ECONQUEST_VENDOR_LICENCE_BLOOMBERG", BBG_LIC)
    return m


def licensed_lseg(monkeypatch, **kw):
    ld = fake_ld(**kw)
    monkeypatch.setitem(sys.modules, "lseg.data", ld)
    monkeypatch.setenv("ECONQUEST_VENDOR_LICENCE_LSEG", LSEG_LIC)
    monkeypatch.setenv("ECONQUEST_LSEG_APP_KEY", APP_KEY)
    return ld


@pytest.mark.parametrize("sub", [[], ["status"], ["test"], ["pull"]])
def test_help(sub, capsys):
    with pytest.raises(SystemExit) as e:
        cli.main(["vendor", *sub, "--help"])
    out = capsys.readouterr().out
    assert e.value.code == 0 and "usage: econquest vendor" in out


def test_no_credential_arguments_and_not_in_gui(data, capsys):
    for sub in ("status", "test", "pull"):
        with pytest.raises(SystemExit):
            cli.main(["vendor", sub, "--help"])
        out = capsys.readouterr().out
        for flag in ("--key", "--password", "--licence", "--token", "--app-key", "--secret"):
            assert flag not in out
    for flag in ("--key", "--password", "--licence"):
        assert vendor_exit(data, "pull", "bloomberg", "--ticker", BBG5, flag, "x") == 2
        assert "unrecognized arguments" in capsys.readouterr().err
    assert "vendor" not in gui.ALLOWED_CMDS


def test_status_without_packages_or_licence(data, capsys):
    vendor(data, "status")                                  # exit 0: returns normally
    out = capsys.readouterr().out
    assert "paid roadmap feature, off by default" in out
    lines = out.splitlines()
    head = next(i for i, x in enumerate(lines) if x.split()[:1] == ["vendor"])
    assert lines[head].split() == ["vendor", "package_ok", "licence", "licence_id", "scope", "expiry", "usable"]
    rows = {x.split()[0]: x for x in lines[head + 1:head + 3]}
    assert set(rows) == {"bloomberg", "lseg"}
    for r in rows.values():
        assert r.split()[1] == "False" and "not configured" in r and r.split()[-1] == "False"
    assert "bloomberg: package 'blpapi' not importable" in out and "econquest[bloomberg]" in out
    assert "lseg: package 'lseg.data' not importable" in out and "econquest[lseg]" in out
    assert "no licence entitlement: set ECONQUEST_VENDOR_LICENCE_BLOOMBERG" in out
    assert "ECONQUEST_VENDOR_LICENCE_LSEG" in out
    assert actions(data) == []                              # status is not logged


def test_status_licensed_and_data_after_subcommand(data, monkeypatch, capsys):
    licensed_bloomberg(monkeypatch)
    cli.main(["--out", str(data.parent / "outputs"), "vendor", "status", "--data", str(data)])
    out = capsys.readouterr().out
    row = next(x for x in out.splitlines() if x.startswith("bloomberg "))
    assert row.split() == ["bloomberg", "True", "ok", "FAKE-BBG-0001", "desk-internal", "2099-12-31", "True"]
    assert "lseg: package 'lseg.data' not importable" in out and "bloomberg:" not in out


@pytest.mark.parametrize("name,ticker", [("bloomberg", BBG5), ("lseg", RIC5)])
@pytest.mark.parametrize("sub", ["test", "pull"])
def test_test_and_pull_without_licence_exit_2_with_roadmap_message(data, capsys, name, ticker, sub):
    assert vendor_exit(data, sub, name, "--ticker", ticker) == 2
    err = capsys.readouterr().err
    assert f"vendor {sub}: " in err and "paid roadmap feature, not enabled" in err and "no free source" in err
    assert f"ECONQUEST_VENDOR_LICENCE_{name.upper()}" in err and "docs/runbooks/A-licensed-vendors.md" in err
    assert list_market_snapshots(data).empty
    assert [(a["command"], a["exit_code"]) for a in actions(data)] == ([("vendor pull", 2)] if sub == "pull" else [])


def test_licence_without_package_exit_2(data, monkeypatch, capsys):
    monkeypatch.setenv("ECONQUEST_VENDOR_LICENCE_BLOOMBERG", BBG_LIC)
    assert vendor_exit(data, "test", "bloomberg", "--ticker", BBG5) == 2
    assert "not importable" in capsys.readouterr().err


def test_licensed_test_is_a_dry_run(data, monkeypatch, capsys):
    m = licensed_bloomberg(monkeypatch, reference={BBG5: {"PX_LAST": 101.5}, BBG10: {"PX_LAST": 140.25}})
    vendor(data, "test", "bloomberg", "--ticker", BBG5, "--ticker", BBG10)
    out = capsys.readouterr().out
    assert "bloomberg: 2 quotes" in out and "dry run: nothing saved" in out
    assert BBG5 in out and "101.5" in out and "140.25" in out and "FAKE-BBG-0001" in out
    assert "status" in out and "ok" in out                  # the gate review rows
    assert len(m.log["requests"]) == 1 and m.log["sessions"][0].stopped
    assert list_market_snapshots(data).empty and not cds_snapshots_path(data).exists()
    assert actions(data) == []                              # test is not logged


def test_licensed_test_as_of_uses_the_daily_close(data, monkeypatch, capsys):
    m = licensed_bloomberg(monkeypatch, history={BBG5: [("2026-10-21", {"PX_LAST": 99.0})]})
    vendor(data, "test", "bloomberg", "--ticker", BBG5, "--as-of", "2026-10-21")
    assert m.log["requests"][0].params["startDate"] == "20261021"
    assert "2026-10-21" in capsys.readouterr().out and list_market_snapshots(data).empty


def test_licensed_pull_saves_a_snapshot_and_exports(data, monkeypatch, capsys):
    ref = {BBG5: {"PX_LAST": 101.5}}
    m = licensed_bloomberg(monkeypatch, reference=ref)
    vendor(data, "pull", "bloomberg", "--ticker", BBG5)
    out = capsys.readouterr().out
    ix = list_market_snapshots(data)
    assert len(ix) == 1 and ix["sources"].iloc[0] == "bloomberg"
    assert f"snapshot {ix['snapshot_id'].iloc[0]}" in out and "bloomberg: 1 quotes" in out
    assert pd.read_csv(cds_snapshots_path(data))["value"].tolist() == [101.5]
    # a second pull in the same process works: each invocation builds a fresh adapter (an adapter connects only once)
    ref[BBG5]["PX_LAST"] = 102.0                            # a new value, so the snapshot id differs within the second
    vendor(data, "pull", "bloomberg", "--ticker", BBG5, "--no-export")
    assert len(list_market_snapshots(data)) == 2 and len(m.log["sessions"]) == 2
    assert len(pd.read_csv(cds_snapshots_path(data))) == 1   # --no-export: nothing appended
    log = actions(data)
    assert [(a["command"], a["exit_code"], a["outcome"]) for a in log] == [("vendor pull", 0, "ok")] * 2


def test_licensed_lseg_history_pull_no_credential_on_disk_or_screen(data, monkeypatch, capsys):
    ld = licensed_lseg(monkeypatch, get_history=lseg_history)
    vendor(data, "pull", "lseg", "--ticker", RIC5, "--ticker", RIC10, "--start", "2026-10-21", "--end", "2026-10-22")
    cap = capsys.readouterr()
    assert "lseg: 3 quotes" in cap.out and ld.log["calls"][0][0] == "get_history"
    assert ld.log["calls"][0][3:] == ("2026-10-21", "2026-10-22", "daily")
    assert len(list_market_snapshots(data)) == 1
    assert APP_KEY not in cap.out + cap.err
    for p in data.parent.rglob("*"):
        if p.is_file():
            assert APP_KEY.encode() not in p.read_bytes(), p


def test_request_and_connection_errors_exit_2(data, monkeypatch, capsys):
    licensed_bloomberg(monkeypatch, reference={BBGX: {"PX_LAST": 1.0}})
    assert vendor_exit(data, "test", "bloomberg", "--ticker", BBGX) == 2
    assert "not verified" in capsys.readouterr().err
    assert vendor_exit(data, "pull", "bloomberg", "--ticker", "NOPE Corp") == 2
    assert "unmapped bloomberg identifiers" in capsys.readouterr().err
    licensed_bloomberg(monkeypatch, start_ok=False)
    assert vendor_exit(data, "pull", "bloomberg", "--ticker", BBG5) == 2
    assert "did not start" in capsys.readouterr().err
    assert list_market_snapshots(data).empty
    assert [(a["command"], a["exit_code"]) for a in actions(data)] == [("vendor pull", 2)] * 2


def test_pull_date_arguments(data, monkeypatch, capsys):
    licensed_bloomberg(monkeypatch)
    assert vendor_exit(data, "pull", "bloomberg", "--ticker", BBG5, "--as-of", "2026-10-21", "--start", "2026-10-20",
                       "--end", "2026-10-21") == 2
    assert "cannot be combined" in capsys.readouterr().err
    assert vendor_exit(data, "pull", "bloomberg", "--ticker", BBG5, "--start", "2026-10-20") == 2
    assert "go together" in capsys.readouterr().err
    assert vendor_exit(data, "test", "bloomberg", "--ticker", BBG5, "--as-of", "not-a-date") == 2   # argparse
    assert vendor_exit(data, "test", "freedata", "--ticker", BBG5) == 2                            # not a choice


def test_store_os_error_exit_2(data, monkeypatch, capsys):
    from econquest.ingestion.market.vendors import pipeline

    def exists(*a, **k):
        raise FileExistsError("snapshot folder exists")
    licensed_bloomberg(monkeypatch, reference={BBG5: {"PX_LAST": 101.5}})
    monkeypatch.setattr(pipeline, "save_market_snapshot", exists)
    assert vendor_exit(data, "pull", "bloomberg", "--ticker", BBG5) == 2
    assert "vendor pull: snapshot folder exists" in capsys.readouterr().err
