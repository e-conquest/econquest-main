"""Reproducible release zip (EQ-C-0001): same tree -> same bytes, exclusions, layout, manifest."""
import hashlib
import importlib.util
import os
import zipfile
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
_spec = importlib.util.spec_from_file_location("build_release", ROOT / "scripts" / "build_release.py")
BR = importlib.util.module_from_spec(_spec); _spec.loader.exec_module(BR)


@pytest.fixture()
def tree(tmp_path):
    s = tmp_path / "src"
    for rel, body in {"README.md": "hi\n", "install.sh": "#!/bin/sh\n", "install.command": "#!/bin/sh\n",
                      "econquest/__init__.py": "__version__='0'\n", "econquest/engine/a.py": "x=1\n",
                      "data/live/vintages/2026-10-23/x.csv": "a\n", "team/logs/C.jsonl": "{}\n",
                      # excluded
                      "outputs/run_latest.json": "{}", "econquest/__pycache__/a.cpython-313.pyc": "b", "econquest/b.pyc": "b",
                      ".pytest_cache/v": "x", "team/checkpoints/EQ-C-0001/x": "x", "team/local.team": "C", "data/.DS_Store": "x",
                      ".venv/bin/python": "x", "econquest.egg-info/PKG-INFO": "x"}.items():
        p = s / rel; p.parent.mkdir(parents=True, exist_ok=True); p.write_text(body)
    return s


def _sha(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()


def test_two_builds_are_byte_identical(tree, tmp_path, monkeypatch):
    monkeypatch.delenv("SOURCE_DATE_EPOCH", raising=False)
    a = BR.build(tree, tmp_path / "a" / "econquest-macos.zip")
    os.utime(tree / "README.md", (1_700_000_000, 1_700_000_000))      # mtimes must not matter
    (tree / "econquest" / "engine" / "a.py").chmod(0o600)              # nor source permissions
    b = BR.build(tree, tmp_path / "b" / "econquest-macos.zip")
    assert a["sha256"] == b["sha256"] == _sha(tmp_path / "a" / "econquest-macos.zip")
    assert (tmp_path / "a" / "econquest-macos.zip.sha256").read_text() == f"{a['sha256']}  econquest-macos.zip\n"


def test_content_change_changes_hash(tree, tmp_path):
    a = BR.build(tree, tmp_path / "a.zip")
    (tree / "econquest" / "engine" / "a.py").write_text("x=2\n")
    assert BR.build(tree, tmp_path / "b.zip")["sha256"] != a["sha256"]


def test_layout_exclusions_modes_and_manifest(tree, tmp_path, monkeypatch):
    monkeypatch.delenv("SOURCE_DATE_EPOCH", raising=False)
    out = tmp_path / "r.zip"
    BR.build(tree, out)
    with zipfile.ZipFile(out) as z:
        infos = z.infolist(); names = [i.filename for i in infos]
        assert names == sorted(names) and names[0] == "econquest/"
        assert all(n.startswith("econquest/") for n in names)
        for keep in ("econquest/README.md", "econquest/econquest/engine/a.py", "econquest/data/live/vintages/2026-10-23/x.csv",
                     "econquest/team/logs/C.jsonl", "econquest/econquest/engine/", "econquest/RELEASE-MANIFEST.txt"):
            assert keep in names, keep
        for bad in ("outputs", "__pycache__", ".pyc", ".pytest_cache", "checkpoints", "local.team", ".DS_Store", ".venv", "egg-info"):
            assert not any(bad in n for n in names), bad
        assert all(i.date_time == (1980, 1, 1, 0, 0, 0) for i in infos)
        modes = {i.filename: (i.external_attr >> 16) & 0o777 for i in infos}
        assert modes["econquest/install.sh"] == modes["econquest/install.command"] == 0o755
        assert modes["econquest/README.md"] == 0o644 and modes["econquest/econquest/"] == 0o755
        manifest = z.read("econquest/RELEASE-MANIFEST.txt").decode()
    line = next(ln for ln in manifest.splitlines() if ln.endswith("econquest/README.md"))
    assert line.split()[0] == hashlib.sha256(b"hi\n").hexdigest()
    assert (tmp_path / "r.zip.manifest.txt").read_text().endswith(manifest)


def test_source_date_epoch_pins_timestamps(tree, tmp_path, monkeypatch):
    monkeypatch.setenv("SOURCE_DATE_EPOCH", "1761177600")              # 2025-10-23 00:00 UTC
    BR.build(tree, tmp_path / "r.zip")
    with zipfile.ZipFile(tmp_path / "r.zip") as z:
        assert {i.date_time for i in z.infolist()} == {(2025, 10, 23, 0, 0, 0)}


def test_refuses_to_overwrite_without_force(tree, tmp_path, capsys):
    out = tmp_path / "r.zip"; out.write_bytes(b"old")
    assert BR.main([str(out), "--source", str(tree)]) == 2 and out.read_bytes() == b"old"
    assert BR.main([str(out), "--source", str(tree), "--force"]) == 0 and zipfile.is_zipfile(out)


def test_output_inside_source_is_not_packed(tree):
    out = tree / "dist" / "r.zip"
    BR.build(tree, out)
    first = _sha(out)
    BR.build(tree, out)                                                  # second build sees the first zip in the tree
    assert _sha(out) == first
    with zipfile.ZipFile(out) as z:
        assert not any(n.endswith((".zip", ".sha256", ".manifest.txt")) for n in z.namelist())


@pytest.mark.parametrize("rel", [".env", "config/.env.local", "sheets.token", "econquest-sheets-token.txt", "token.json",
                                 "data/client_secret_123.json", "Credentials.json", "keys/id_rsa", "login.keychain-db",
                                 ".claude/settings.local.json", ".netrc", "certs/server.PEM",
                                 # SEC-C-008: names the first list missed
                                 "docs/api_token.json", "docs/smtp-password.txt", "keys/id_ecdsa", ".git-credentials", ".pypirc",
                                 ".npmrc", "vendor_apikey.txt"])
def test_credentials_are_never_packed(tree, tmp_path, rel):
    # regression (AGENT-09 review of EQ-C-0001): a Sheets token file or .env dropped in the folder must not ship
    p = tree / rel; p.parent.mkdir(parents=True, exist_ok=True); p.write_text("ya29.secret\n")
    out = tmp_path / "r.zip"
    BR.build(tree, out)
    with zipfile.ZipFile(out) as z:
        assert f"econquest/{rel}" not in z.namelist()
        assert all(b"ya29.secret" not in z.read(n) for n in z.namelist() if not n.endswith("/"))
    assert "test_token_handling.py" not in rel and not BR.is_secret("test_token_handling.py")   # code about tokens still ships


def _run_audit_gate(tmp_path, report, env_extra=None):
    """scripts/ci_local.sh with only the pip-audit gate and a fake pip-audit that prints `report` and exits 1."""
    import shutil
    import subprocess
    if not shutil.which("bash"):
        pytest.skip("bash not available")
    bindir = tmp_path / "bin"; bindir.mkdir(exist_ok=True)
    fake = bindir / "pip-audit"; fake.write_text(f"#!/bin/sh\ncat <<'X'\n{report}\nX\nexit 1\n"); fake.chmod(0o755)
    env = {k: v for k, v in os.environ.items() if k not in ("CI", "GITHUB_ACTIONS")}
    env.update(PATH=f"{bindir}{os.pathsep}{env.get('PATH', '')}", CI_SKIP="gate tests smoke lint bandit", TMPDIR=str(tmp_path),
               **(env_extra or {}))
    r = subprocess.run(["bash", str(ROOT / "scripts" / "ci_local.sh")], capture_output=True, text=True, env=env, timeout=120)
    return r.returncode, r.stdout + r.stderr


def test_ci_local_vulnerability_report_is_not_mistaken_for_offline(tmp_path):
    # regression (AGENT-09 review of EQ-C-0001): "pyopenssl" matched the SSL offline pattern and the gate was skipped
    rc, out = _run_audit_gate(tmp_path, "Found 1 known vulnerability in 1 package\nName      Version ID\npyopenssl 23.0.0  PYSEC-0000-1")
    assert rc == 1 and "pip-audit    FAIL" in out


def test_ci_local_offline_skips_locally_but_fails_on_ci(tmp_path):
    offline = "ConnectionError: Max retries exceeded with url: /pypi (Caused by NewConnectionError)"
    rc, out = _run_audit_gate(tmp_path, offline)
    assert rc == 0 and "pip-audit    skip" in out
    rc, out = _run_audit_gate(tmp_path, offline, {"CI": "true"})
    assert rc == 1 and "pip-audit    FAIL" in out


def test_ci_local_audits_the_install_lock_too(tmp_path):
    # regression (SEC-C-008, EQ-C-0066): pip-audit read only scripts/requirements-lock.txt, which lacks 18 packages that
    # install.sh installs from requirements-lock.txt; a vulnerability only in the install lock must fail the gate
    import shutil
    import subprocess
    if not shutil.which("bash"):
        pytest.skip("bash not available")
    bindir = tmp_path / "bin"; bindir.mkdir()
    calls = tmp_path / "calls.txt"
    fake = bindir / "pip-audit"
    fake.write_text(f'#!/bin/sh\necho "$*" >> "{calls}"\ncase "$*" in *--require-hashes*) '
                    'echo "Found 1 known vulnerability in 1 package"; exit 1;; esac\necho "No known vulnerabilities found"\n')
    fake.chmod(0o755)
    env = {k: v for k, v in os.environ.items() if k not in ("CI", "GITHUB_ACTIONS")}
    env.update(PATH=f"{bindir}{os.pathsep}{env.get('PATH', '')}", CI_SKIP="gate lock tests smoke lint bandit", TMPDIR=str(tmp_path))
    r = subprocess.run(["bash", str(ROOT / "scripts" / "ci_local.sh")], capture_output=True, text=True, env=env, timeout=120)
    seen = calls.read_text().splitlines()
    assert "-r requirements-lock.txt --require-hashes --disable-pip" in seen
    assert "-r scripts/requirements-lock.txt --no-deps --disable-pip" in seen
    assert r.returncode == 1 and "pip-audit    FAIL" in r.stdout + r.stderr
