"""install.sh reinstall keeps the user's data/ and outputs/ (EQ-C-0016, HO-20261023-A-C-004).

Runs the real installer into a temp HOME with ECONQUEST_INSTALL_SKIP_VENV=1 (file copy only). The rsync path is
tested when rsync is installed (Sam's Mac); the tar/cp fallback is always tested."""
import importlib.util
import os
import re
import shutil
import subprocess
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
BASH = shutil.which("bash")
pytestmark = pytest.mark.skipif(BASH is None, reason="bash not available")

MODES = [pytest.param("rsync", marks=pytest.mark.skipif(shutil.which("rsync") is None, reason="rsync not installed")),
         "fallback"]


def _source(tmp: Path) -> Path:
    """A minimal release folder: the real install.sh plus a tiny program and data set."""
    src = tmp / "zip" / "econquest"
    (src / "data" / "live").mkdir(parents=True)
    shutil.copy(ROOT / "install.sh", src / "install.sh")
    (src / "pyproject.toml").write_text("[project]\nname='econquest'\nversion='1'\n")
    (src / "econquest").mkdir(); (src / "econquest" / "__init__.py").write_text("__version__ = '1'\n")
    (src / "data" / "indicators.csv").write_text("id,X\n1,1\n")
    (src / "data" / "countries.csv").write_text("country\nX\n")
    return src


def _install(src: Path, home: Path, mode: str) -> subprocess.CompletedProcess:
    env = {"HOME": str(home), "PATH": os.environ.get("PATH", "/usr/bin:/bin"), "ECONQUEST_INSTALL_SKIP_VENV": "1",
           "ECONQUEST_NO_PROFILE": "1"}
    if mode == "fallback":
        env["ECONQUEST_INSTALL_NO_RSYNC"] = "1"
    r = subprocess.run([BASH, str(src / "install.sh")], env=env, capture_output=True, text=True, timeout=120)
    assert r.returncode == 0, r.stdout + r.stderr
    return r


@pytest.mark.parametrize("mode", MODES)
def test_reinstall_keeps_user_data_and_adds_new_files(tmp_path, mode):
    home = tmp_path / "home"; home.mkdir()
    src = _source(tmp_path)
    _install(src, home, mode)                                         # fresh install
    target = home / "econquest"
    assert (target / "data" / "indicators.csv").read_text() == "id,X\n1,1\n"
    assert not (home / "econquest-backups").exists()                  # nothing to back up on a fresh install

    # Sam's live data diverges from the zip; he also has outputs and a file the zip does not have
    (target / "data" / "indicators.csv").write_text("id,X\n1,42\n")
    (target / "data" / "forecast_record.csv").write_text("date\n2026-10-23\n")
    (target / "outputs").mkdir(); (target / "outputs" / "run_latest.json").write_text('{"mine": 1}')

    # the next zip: new code, changed seed data, a new data file and an outputs file of its own
    (src / "econquest" / "__init__.py").write_text("__version__ = '2'\n")
    (src / "data" / "indicators.csv").write_text("id,X\n1,7\n")
    (src / "data" / "live" / "review_ledger.csv").write_text("key\n")
    (src / "outputs").mkdir(); (src / "outputs" / "run_latest.json").write_text('{"zip": 1}')
    r = _install(src, home, mode)

    assert (target / "data" / "indicators.csv").read_text() == "id,X\n1,42\n"          # not overwritten
    assert (target / "data" / "forecast_record.csv").read_text() == "date\n2026-10-23\n"
    assert (target / "outputs" / "run_latest.json").read_text() == '{"mine": 1}'
    assert (target / "data" / "live" / "review_ledger.csv").exists()                   # new file from the zip added
    assert (target / "econquest" / "__init__.py").read_text() == "__version__ = '2'\n"  # code updated
    backups = list((home / "econquest-backups").iterdir())
    assert len(backups) == 1
    assert (backups[0] / "data" / "indicators.csv").read_text() == "id,X\n1,42\n"
    assert (backups[0] / "outputs" / "run_latest.json").read_text() == '{"mine": 1}'
    assert "data/: added 1 new file(s), kept 2 existing file(s) unchanged" in r.stdout
    assert not (home / ".zshrc").exists()                                              # ECONQUEST_NO_PROFILE honoured


@pytest.mark.parametrize("mode", MODES)
def test_backup_follows_a_symlinked_data_dir(tmp_path, mode):
    # regression (AGENT-09, EQ-C-0019): cp -Rp copied only the link, so the backup held no data
    home = tmp_path / "home"; home.mkdir()
    src = _source(tmp_path)
    _install(src, home, mode)
    target = home / "econquest"
    real = tmp_path / "elsewhere" / "data"; real.parent.mkdir()
    (target / "data").rename(real); (target / "data").symlink_to(real)
    _install(src, home, mode)
    backup = next((home / "econquest-backups").iterdir()) / "data"
    assert backup.is_dir() and not backup.is_symlink()
    assert (backup / "indicators.csv").read_text() == "id,X\n1,1\n"


@pytest.mark.parametrize("mode", MODES)
def test_reinstall_updates_released_model_config_with_its_approval_log(tmp_path, mode):
    # regression (EQ-C-0032): 0.1.3 changed assumptions.json through `econquest change`; keeping the installed copy
    # would have left the old model running and made `change verify` report drift
    home = tmp_path / "home"; home.mkdir()
    src = _source(tmp_path)
    (src / "data" / "assumptions.json").write_text('{"v": 1}')
    _install(src, home, mode)
    target = home / "econquest"
    (src / "data" / "assumptions.json").write_text('{"v": 2}')
    (src / "data" / "approvals").mkdir(); (src / "data" / "approvals" / "log.jsonl").write_text('{"seq": 1}\n')
    r = _install(src, home, mode)
    assert (target / "data" / "assumptions.json").read_text() == '{"v": 2}'
    assert (target / "data" / "approvals" / "log.jsonl").read_text() == '{"seq": 1}\n'
    assert "data/assumptions.json: updated to the released version" in r.stdout


@pytest.mark.parametrize("mode", MODES)
def test_local_approved_change_is_never_overwritten(tmp_path, mode):
    home = tmp_path / "home"; home.mkdir()
    src = _source(tmp_path)
    (src / "data" / "assumptions.json").write_text('{"v": 1}')
    (src / "data" / "approvals").mkdir(); (src / "data" / "approvals" / "log.jsonl").write_text('{"seq": 1}\n')
    _install(src, home, mode)
    target = home / "econquest"
    (target / "data" / "assumptions.json").write_text('{"v": "local"}')                 # changed on the Mac ...
    (target / "data" / "approvals" / "log.jsonl").write_text('{"seq": 1}\n{"seq": 2}\n')  # ... through econquest change
    (src / "data" / "assumptions.json").write_text('{"v": 2}')
    r = _install(src, home, mode)
    assert (target / "data" / "assumptions.json").read_text() == '{"v": "local"}'
    assert "WARNING" in r.stdout and "left as installed" in r.stdout


# EQ-C-0066 (SEC-C-007 O2): dependencies come only from the hash-pinned requirements-lock.txt ----------------------
# The full install path (venv, pip, launcher, smoke check) runs against a stand-in python3 whose venv python records
# every call and never touches the network.
FAKE_VENV_PY = r'''#!/usr/bin/env bash
printf '%s\n' "$*" >> "$FAKE_PIP_LOG"
if [[ "${1:-} ${2:-}" == "-m pip" && " $* " == *" --require-hashes "* && -n "${FAKE_HASH_FAIL:-}" ]]; then
  echo "ERROR: THESE PACKAGES DO NOT MATCH THE HASHES FROM THE REQUIREMENTS FILE. If you have updated the package"
  echo "    numpy==2.5.4 from https://files.pythonhosted.org/numpy.whl:"
  echo "        Expected sha256 0000; Got 1111"
  exit 1
fi
exit 0
'''
FAKE_PY = r'''#!/usr/bin/env bash
if [[ "${1:-}" == "-m" && "${2:-}" == "venv" ]]; then
  mkdir -p "$3/bin"; cp "$FAKE_VENV_PY" "$3/bin/python"; chmod +x "$3/bin/python"; exit 0
fi
exec "$REAL_PY" "$@"
'''
HERE_PY = f"{sys.version_info[0]}.{sys.version_info[1]}"


def _lock_module():
    spec = importlib.util.spec_from_file_location("make_hash_lock", ROOT / "scripts" / "make_hash_lock.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    return mod


def _source_with_lock(tmp: Path, pythons: str = HERE_PY) -> Path:
    """_source plus the real lock, its "# python:" line set to `pythons` (the interpreter running the test)."""
    src = _source(tmp)
    text = (ROOT / "requirements-lock.txt").read_text()
    (src / "requirements-lock.txt").write_text(re.sub(r"(?m)^# python: .*$", f"# python: {pythons}", text))
    return src


def _full_install(src: Path, home: Path, tmp: Path, **extra) -> tuple[subprocess.CompletedProcess, list[str]]:
    fake = tmp / "fakebin"; fake.mkdir(exist_ok=True)
    (fake / "python3").write_text(FAKE_PY); (fake / "python3").chmod(0o755)
    (tmp / "venv_python").write_text(FAKE_VENV_PY)
    log = tmp / "pip_calls.log"
    env = {"HOME": str(home), "PATH": f"{fake}:{os.environ.get('PATH', '/usr/bin:/bin')}", "ECONQUEST_NO_PROFILE": "1",
           "ECONQUEST_INSTALL_NO_RSYNC": "1", "REAL_PY": sys.executable, "FAKE_VENV_PY": str(tmp / "venv_python"),
           "FAKE_PIP_LOG": str(log), **extra}
    r = subprocess.run([BASH, str(src / "install.sh")], env=env, capture_output=True, text=True, timeout=120)
    return r, (log.read_text().splitlines() if log.exists() else [])


def test_install_takes_every_dependency_from_the_hash_pinned_lock(tmp_path):
    home = tmp_path / "home"; home.mkdir()
    r, calls = _full_install(_source_with_lock(tmp_path), home, tmp_path)
    assert r.returncode == 0, r.stdout + r.stderr
    target = home / "econquest"
    pip = [c for c in calls if c.startswith("-m pip")]
    assert len(pip) == 2, calls
    assert "install" in pip[0] and f"--require-hashes -r {target}/requirements-lock.txt" in pip[0]
    assert "--no-deps --no-build-isolation -e " + str(target) in pip[1]
    assert not any("--upgrade" in c for c in pip)                     # no unpinned pip self-upgrade any more
    assert all("--require-hashes" in c or "--no-deps" in c for c in pip)   # nothing resolved from PyPI unpinned
    assert (home / ".local" / "bin" / "econquest").exists()           # launcher and smoke check still run
    assert "each checked against its SHA-256" in r.stdout


def test_hash_mismatch_stops_the_install_with_a_clear_message(tmp_path):
    home = tmp_path / "home"; home.mkdir()
    r, calls = _full_install(_source_with_lock(tmp_path), home, tmp_path, FAKE_HASH_FAIL="1")
    assert r.returncode != 0
    assert "did not match the SHA-256 recorded in requirements-lock.txt" in r.stderr
    assert "Do not work around it" in r.stderr
    assert not any("--no-deps" in c for c in calls)                   # econquest itself is not installed
    assert not (home / ".local" / "bin" / "econquest").exists()


def test_missing_lock_fails_closed_before_a_venv_is_made(tmp_path):
    home = tmp_path / "home"; home.mkdir()
    src = _source_with_lock(tmp_path); (src / "requirements-lock.txt").unlink()
    r, calls = _full_install(src, home, tmp_path)
    assert r.returncode != 0 and "requirements-lock.txt is missing" in r.stderr
    assert calls == [] and not (home / "econquest" / ".venv").exists()


def test_python_the_lock_does_not_cover_is_refused(tmp_path):
    home = tmp_path / "home"; home.mkdir()
    r, calls = _full_install(_source_with_lock(tmp_path, pythons="3.99"), home, tmp_path)
    assert r.returncode != 0
    assert f"Python {HERE_PY}" in r.stderr and "is not covered by requirements-lock.txt" in r.stderr
    assert "3.99" in r.stderr and calls == []


def test_skip_venv_needs_no_lock(tmp_path):
    # ECONQUEST_INSTALL_SKIP_VENV keeps its meaning: copy files only, even from a folder without the lock
    home = tmp_path / "home"; home.mkdir()
    r = _install(_source(tmp_path), home, "fallback")
    assert "skipping venv, pip, launcher and smoke test" in r.stdout
    assert not (home / "econquest" / ".venv").exists()


def test_lock_covers_every_runtime_dependency_for_both_macos_architectures():
    mod = _lock_module()
    assert mod.check() == []
    pins, header = mod.parse_lock((ROOT / "requirements-lock.txt").read_text())
    assert header["python"].split() == list(mod.PYTHONS)
    assert {"macos-arm64", "macos-x86_64"} <= set(header["platforms"].split())
    for name in ("numpy", "pandas", "scipy", "scikit-learn", "imf-reader", "weo", "wbgapi", "openpyxl",
                 "defusedxml", "setuptools", "pip"):
        assert pins[name][1], name                                    # pinned with at least one sha256
    # yfinance is the [research] extra, not a desk dependency (EQ-A-0040, HO-20261024-A-C-002): not installed by install.sh
    assert "yfinance" not in pins and "yfinance" not in " ".join(mod.declared())
    assert all(len(h) == 64 for _, hashes in pins.values() for h in hashes)
    # compiled packages carry one wheel per Python and architecture, not just the one this machine would pick
    assert len(pins["numpy"][1]) >= 2 * len(mod.PYTHONS)


def test_lock_check_reports_missing_unhashed_and_out_of_range_pins(tmp_path):
    mod = _lock_module()
    (tmp_path / "pyproject.toml").write_text(
        '[project]\nname = "x"\nversion = "1"\ndependencies = ["numpy>=1.24", "pandas>=3", "weo~=0.8.4"]\n'
        '[project.optional-dependencies]\nall = ["pytest"]\n[build-system]\nrequires = ["setuptools>=68"]\n')
    h = "--hash=sha256:" + "a" * 64
    (tmp_path / "lock.txt").write_text(f"# python: 3.13\nnumpy==2.5.4 \\\n    {h}\npandas==2.3.3 \\\n    {h}\n"
                                       f"weo==0.8.4\npytest==9.1.1 {h}\npip==26.2.2 {h}\n")
    problems = "\n".join(mod.check(tmp_path / "lock.txt", tmp_path / "pyproject.toml"))
    assert "pandas>=3: lock.txt pins 2.3.3, outside the declared range" in problems
    assert "weo: no sha256 hash" in problems
    assert "setuptools>=68: declared in pyproject.toml but not in lock.txt" in problems
    assert "numpy" not in problems and "pytest" not in problems
