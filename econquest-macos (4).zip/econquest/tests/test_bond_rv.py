"""EQ-B-0049: Eurobond relative value against the model (engine/bond_rv.py). CDS quotes used here are SYNTHETIC."""
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.config import Settings  # noqa: E402
from econquest.engine import bond_rv as br  # noqa: E402
from econquest.engine import cds_curves as cc  # noqa: E402
from econquest.engine.layer2_bayesian import physical_pd  # noqa: E402

FIX = ROOT / "tests" / "fixtures" / "cds"
RAW = json.loads((ROOT / "data" / "assumptions.json").read_text())
S = Settings(raw={**RAW, "as_of": "2026-10-23"})


def _country():
    return pd.DataFrame({"iso": ["XAA", "XBB", "XSD", "XHI"], "rating": ["BB", "B", "SD", "CCC"],
                         "spread_bps": [250.0, 400.0, 3000.0, 2500.0], "pd_default": [0.01, 0.05, 0.80, 0.6],
                         "lgd_hard_expected": [0.6, 0.6, 0.7, 0.9]}, index=["Alpha", "Beta", "Gamma", "Delta"])


def test_fair_spread_hand_number():
    h, el, fair = br.fair_spread_bp(0.05, 0.6, 2.0, 5.0)
    assert float(el) == pytest.approx(300.0) and float(fair) == pytest.approx(600.0)      # 1e4 * p * LGD * k
    assert float(h) == pytest.approx(-np.log(0.95), rel=1e-12)                            # reported, not used
    _, _, f3 = br.fair_spread_bp(0.05, 0.6, 2.0, 3.0)
    assert float(f3) == pytest.approx(float(fair), rel=1e-12)            # constant hazard: duration-invariant
    # review case (AGENT-08): p 0.20, LGD 0.6, k 2 -> 2400 bp (the old intensity form gave 2678)
    assert float(br.fair_spread_bp(0.20, 0.6, 2.0)[2]) == pytest.approx(2400.0)
    assert float(br.fair_spread_bp(0.20, 0.6, 2.0, form="intensity")[2]) == pytest.approx(1e4 * -np.log(0.8) * 1.2)
    with pytest.raises(ValueError):
        br.fair_spread_bp(0.2, 0.6, 2.0, form="other")


@pytest.mark.parametrize("p,k", [(0.0005, 2.0), (0.02, 2.0), (0.08, 2.0), (0.20, 2.0), (0.45, 1.0), (0.9, 1.0)])
def test_inverse_of_layer2_physical_pd(p, k):
    """Regression (EQ-B-0049 review): fair_bp fed back through Layer 2's physical_pd returns the PD p itself."""
    lgd = RAW["probability"]["lgd_market_implied"]
    _, _, fair = br.fair_spread_bp(p, lgd, k)
    assert float(physical_pd(np.array([float(fair)]), lgd, k)[0]) == pytest.approx(p, rel=1e-12)


def test_country_rv_inverts_layer2_by_default():
    rv = br.country_rv(_country(), S)
    lgd = RAW["probability"]["lgd_market_implied"]
    assert (rv["lgd"] == lgd).all()
    back = physical_pd(rv["fair_bp"].to_numpy(), lgd, 2.0, exempt=(rv["risk_premium_ratio"] == 1.0).to_numpy())
    assert np.allclose(back, rv["pd_12m"].to_numpy(), rtol=1e-12)


def test_layer4_lgd_and_intensity_options():
    c = _country()
    l4 = br.country_rv(c, S.copy_with(**{"bond_rv.lgd_source": "layer4"}))
    assert l4["lgd"].tolist() == c["lgd_hard_expected"].tolist()
    it = br.country_rv(c, S.copy_with(**{"bond_rv.fair_form": "intensity"}))
    assert it.loc["Beta", "fair_bp"] == pytest.approx(1e4 * -np.log(0.95) * 0.6 * 2.0)
    with pytest.raises(ValueError):
        br.country_rv(c, S.copy_with(**{"bond_rv.lgd_source": "x"}))


def test_country_rv_reads_and_z():
    rv = br.country_rv(_country(), S)
    a, b, g, d = (rv.loc[n] for n in ["Alpha", "Beta", "Gamma", "Delta"])
    assert a["risk_premium_ratio"] == RAW["probability"]["risk_premium_ratio"] and g["risk_premium_ratio"] == 1.0   # SD exempt
    assert a["fair_bp"] == pytest.approx(1e4 * 0.01 * 0.6 * 2.0)
    assert a["gap_bp"] > 0 and a["rv_read"] == "cheap vs model"
    assert a["z"] == pytest.approx(a["gap_bp"] / (RAW["market"]["spread_vol_rel"] / 100 * 250.0))
    assert b["gap_bp"] < 0 and b["rv_read"] == "rich vs model"
    assert g["distressed"] and np.isnan(g["z"]) and g["rv_read"].startswith("distressed")
    assert d["distressed"]                                                # pd >= bond_rv.distress_pd 0.5
    assert list(rv.columns) == br.RV_COLUMNS and (rv["market_source"] == "profile spread").all()


def test_cds_curve_replaces_profile_spread_when_present():
    ct, _, _ = cc.curves(pd.read_csv(FIX / "cds_snapshots_synthetic.csv"), settings=S)
    rv = br.country_rv(_country(), S, curve_table=ct)
    assert rv.loc["Alpha", "market_bp"] == pytest.approx(300.0, abs=1e-6)          # XAA synthetic flat 300 at 5y
    assert "SYNTHETIC" in rv.loc["Alpha", "market_source"] and "SYN-XAA-1" in rv.loc["Alpha", "market_source"]
    assert rv.loc["Beta", "market_bp"] == pytest.approx(200.0, abs=1e-6)           # XBB 5y quote
    assert rv.loc["Gamma", "market_source"] == "profile spread"                     # no curve for XSD
    off = br.country_rv(_country(), S.copy_with(**{"bond_rv.use_cds_curves": False}), curve_table=ct)
    assert (off["market_source"] == "profile spread").all()


def test_position_rv_favourability():
    port = pd.DataFrame({"id": ["E1", "E2", "C1", "F1", "E3"], "country": ["Alpha", "Beta", "Beta", "Alpha", "Gamma"],
                         "asset_class": ["Eurobond", "Eurobond", "CDS protection", "FX", "Eurobond"],
                         "direction": ["Long", "Long", "Long", "Long", "Long"], "notional_mm": [10, 5, 5, 3, 2],
                         "duration_yrs": [5.0, 3.0, 5.0, np.nan, 8.0]})
    pr = br.position_rv(port, _country(), S).set_index("id")
    assert list(pr.index) == ["E1", "E2", "C1", "E3"]                  # FX excluded
    assert pr.loc["E1", "for_position"] == "favourable" and pr.loc["E2", "for_position"] == "unfavourable"
    assert pr.loc["C1", "for_position"] == "favourable"                  # rich spread = cheap protection
    assert pr.loc["E3", "for_position"] == "n/a (distressed)" and pr.loc["E2", "tenor_y"] == 3.0


def test_rv_signal_off_by_default_and_scaled_when_on():
    rv = br.country_rv(_country(), S)
    assert "bond_rv" not in RAW and br.rv_signal(rv, S).empty
    on = S.copy_with(**{"bond_rv.enabled": True})
    sig = br.rv_signal(rv.assign(z=[1.0, -1.0, np.nan, 0.0]), on)
    assert sig["s26_bond_cheap"].tolist() == pytest.approx([70.0, 30.0, 50.0, 50.0])
    assert (sig["s26_bond_cheap"] + sig["s27_bond_rich"] == 100).all()


def test_rv_fixture_contract_is_current():
    """tests/fixtures/cds/bond_rv_fixture.csv (shape handed to Team C for EQ-C-0046) has the current columns."""
    fx = pd.read_csv(FIX / "bond_rv_fixture.csv")
    assert list(fx.columns) == ["as_of"] + br.RV_COLUMNS and len(fx) == 18


def test_today_universe_rv_table():
    from econquest.engine.pipeline import run_pipeline
    from econquest.ingestion import load_universe
    u = load_universe(ROOT / "data")
    s = Settings.load(ROOT / "data" / "assumptions.json")
    r = run_pipeline(u, s, paths=2000, as_of="2026-10-23")
    rv = br.country_rv(r.country, s)
    assert len(rv) == 18 and rv["fair_bp"].notna().all()
    assert sorted(rv.index[rv["distressed"]]) == ["Venezuela", "Zimbabwe"]
    assert rv["z"].notna().sum() == 16


def test_country_rv_pit_reads_market_store_and_defaults_unchanged(tmp_path):
    """HO-20261023-A-B-010: CDS curves from Team A's market store at the run's as-of (SYNTHETIC fixture, fictional
    XAA/XBB); without a data dir the table is exactly today's country_rv; no store -> FileNotFoundError."""
    import datetime as dt
    from econquest.ingestion.market.store import save_market_snapshot
    m = pd.read_csv(ROOT / "tests" / "fixtures" / "market" / "quotes_sample.csv", dtype=str, keep_default_na=False)
    m = m.replace({"iso": {"BRA": "XAA", "ARG": "XBB"}})
    d = m[(m["iso"] == "XBB") & (m["field"] == "spread_bp") & (m["instrument"] == "cds")].assign(
        value="5", derived="true", source="derived_cip")                         # indicative: must not move market_bp
    folder = save_market_snapshot(tmp_path, pd.concat([m, d], ignore_index=True),
                                  now=dt.datetime(2026, 10, 20, 22, 30, tzinfo=dt.timezone.utc))
    pd.testing.assert_frame_equal(br.country_rv_pit(_country(), S), br.country_rv(_country(), S))
    rv = br.country_rv_pit(_country(), S, data_dir=tmp_path)
    assert rv.loc["Alpha", "market_bp"] == pytest.approx(200.0, abs=1e-6)           # XAA synthetic 5y
    assert folder.name in rv.loc["Alpha", "market_source"] and "SYNTHETIC" in rv.loc["Alpha", "market_source"]
    assert rv.loc["Beta", "market_bp"] == pytest.approx(900.0, abs=1e-6)            # XBB 5y, derived row ignored
    assert any("derived" in i for i in rv.attrs["issues"])
    assert rv.loc["Gamma", "market_source"] == "profile spread"
    off = br.country_rv_pit(_country(), S.copy_with(**{"bond_rv.use_cds_curves": False}), data_dir=tmp_path)
    assert (off["market_source"] == "profile spread").all()
    with pytest.raises(FileNotFoundError):
        br.country_rv_pit(_country(), S, data_dir=tmp_path / "none")
