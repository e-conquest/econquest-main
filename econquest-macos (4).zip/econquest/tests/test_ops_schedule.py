"""EQ-C-0021: launchd plists and the job wrapper. Nothing here runs launchctl."""
import datetime as dt
import json
import os
import plistlib
from types import SimpleNamespace
from zoneinfo import ZoneInfo

import pytest

from econquest.ops import jobs, schedule

NY = ZoneInfo("America/New_York")
NOW = dt.datetime(2026, 10, 23, 15, 0, tzinfo=dt.timezone.utc)


@pytest.fixture
def env(tmp_path, monkeypatch):
    home = tmp_path / "econquest"; (home / "data").mkdir(parents=True)
    la = tmp_path / "LaunchAgents"; launcher = tmp_path / "bin" / "econquest"
    launcher.parent.mkdir(); launcher.write_text("#!/bin/sh\n"); launcher.chmod(0o755)

    def no_launchctl(*a, **k):
        raise AssertionError("launchctl must not run in tests")
    monkeypatch.setattr(schedule.subprocess, "run", no_launchctl)
    monkeypatch.delenv("ECONQUEST_BACKUP_DEST", raising=False)
    kw = {"launch_agents": la, "launcher": launcher, "python": home / ".venv" / "bin" / "python"}
    return SimpleNamespace(home=home, la=la, launcher=launcher, kw=kw)


def _load(env, name):
    return plistlib.loads((env.la / f"com.econquest.{name}.plist").read_bytes())


def test_install_writes_all_plists_with_absolute_paths(env):
    out = []
    r = schedule.install(env.home, now=NOW, local_tz=NY, log=out.append, **env.kw)
    assert sorted(os.listdir(env.la)) == sorted(f"com.econquest.{j}.plist" for j in ("record", "morning", "monitor", "backup", "health"))
    rec = _load(env, "record")
    assert rec["Label"] == "com.econquest.record"
    assert rec["StartCalendarInterval"] == [{"Weekday": d, "Hour": 18, "Minute": 20} for d in range(1, 6)]
    args = rec["ProgramArguments"]
    assert args[:3] == [str(env.kw["python"]), "-m", "econquest.ops.jobs"] and all(os.path.isabs(a) for a in (args[0], args[4]))
    steps = [json.loads(args[i + 1]) for i, a in enumerate(args) if a == "--step"]
    assert steps[1] == [str(env.launcher), "prices", "--sheet-json", f"{env.home.resolve()}/outputs/market_history.json"]
    assert steps[2] == [str(env.launcher), "record"]
    script = steps[0][2]
    assert steps[0][:2] == ["/bin/bash", "-c"] and "| curl -sf -H @- " in script        # token reaches curl on stdin only
    assert "Bearer $TOKEN" not in script and schedule.SPREADSHEET_ID in script and "{spreadsheet_id}" not in script
    assert rec["StandardOutPath"] == str(env.home.resolve() / "outputs" / "logs" / "record.out.log")
    assert rec["EnvironmentVariables"]["ECONQUEST_HOME"] == str(env.home.resolve())
    assert _load(env, "health")["StartInterval"] == 900
    assert _load(env, "backup")["StartCalendarInterval"] == {"Hour": 23, "Minute": 30}
    assert _load(env, "monitor")["StartCalendarInterval"] == [{"Weekday": 1, "Hour": 7, "Minute": 45}]
    morning = [json.loads(a) for a in _load(env, "morning")["ProgramArguments"] if a.startswith("[")]
    assert morning == [[str(env.launcher), "run"], [str(env.launcher), "report"]]
    assert any(c.startswith("launchctl bootstrap gui/$UID ") for c in r["commands"])
    sch = json.loads((env.home / "outputs" / "logs" / "schedule.json").read_text())
    assert sch["status"] == "installed" and sch["tz"] == "America/New_York" and "steps" not in sch["jobs"]["record"]
    assert not r["warnings"]


def test_configurable_time_and_ops_json(env):
    (env.home / "ops.json").write_text(json.dumps({"jobs": {"morning": {"hour": 6, "minute": 30}}}))
    cfg = schedule.load_config(env.home, {"jobs": {"record": {"hour": 18, "minute": 45}}})
    schedule.install(env.home, cfg, jobs=["record", "morning"], now=NOW, local_tz=NY, log=lambda *_: None, **env.kw)
    assert _load(env, "record")["StartCalendarInterval"][0] == {"Weekday": 1, "Hour": 18, "Minute": 45}
    assert _load(env, "morning")["StartCalendarInterval"][0]["Hour"] == 6
    assert sorted(os.listdir(env.la)) == ["com.econquest.morning.plist", "com.econquest.record.plist"]


def test_cli_args_set_times(env):
    ap = schedule.argparse.ArgumentParser(); schedule.add_arguments(ap)
    a = ap.parse_args(["install", "--record-time", "18:25", "--job", "record", "--launch-agents", str(env.la),
                       "--launcher", str(env.launcher), "--python", "/x/python"])
    schedule.run_from_args(a, env.home, log=lambda *_: None)
    sch = json.loads((env.home / "outputs" / "logs" / "schedule.json").read_text())
    assert (sch["jobs"]["record"]["hour"], sch["jobs"]["record"]["minute"]) == (18, 25)   # plist itself is in Mac local time
    with pytest.raises(SystemExit):
        ap.parse_args(["install", "--record-time", "25:00"])


def test_local_time_conversion_and_weekday_shift():
    london = ZoneInfo("Europe/London")
    assert schedule.to_local(18, 20, [1, 2, 3, 4, 5], "America/New_York", london, dt.date(2026, 10, 23)) == (23, 20, [1, 2, 3, 4, 5], True)
    assert schedule.to_local(23, 30, [1, 2, 3, 4, 5], "America/New_York", london, dt.date(2026, 10, 23)) == (4, 30, [2, 3, 4, 5, 6], True)
    assert schedule.to_local(18, 20, [1], "America/New_York", NY, dt.date(2026, 10, 23))[3] is False


def test_install_warns_when_mac_not_on_ny_time(env):
    out = []
    r = schedule.install(env.home, jobs=["record"], now=NOW, local_tz=ZoneInfo("Europe/London"), log=out.append, **env.kw)
    assert _load(env, "record")["StartCalendarInterval"][0]["Hour"] == 23
    assert r["warnings"] and any("WARNING" in o and "DST" in o for o in out)


def test_existing_plist_backed_up_and_uninstall(env):
    env.la.mkdir()
    old = env.la / "com.econquest.record.plist"; old.write_bytes(b"hand-made plist")
    schedule.install(env.home, now=NOW, local_tz=NY, log=lambda *_: None, **env.kw)
    baks = [f for f in os.listdir(env.la) if ".bak-" in f]
    assert len(baks) == 1 and (env.la / baks[0]).read_bytes() == b"hand-made plist"
    r = schedule.uninstall(env.home, now=NOW, log=lambda *_: None, **env.kw)
    assert len(r["removed"]) == 5 and all(c.startswith("launchctl bootout gui/$UID/com.econquest.") for c in r["commands"])
    assert json.loads((env.home / "outputs" / "logs" / "schedule.json").read_text())["status"] == "uninstalled"


def test_load_flag_is_macos_only(env, monkeypatch):
    monkeypatch.setattr(schedule.sys, "platform", "linux")
    out = []
    schedule.install(env.home, jobs=["health"], load=True, now=NOW, local_tz=NY, log=out.append, **env.kw)
    assert any("macOS only" in o for o in out)


def test_load_flag_on_macos_runs_launchctl(env, monkeypatch):
    calls = []
    monkeypatch.setattr(schedule.sys, "platform", "darwin")
    monkeypatch.setattr(schedule.subprocess, "run", lambda argv, **k: calls.append(argv) or SimpleNamespace(returncode=0, stderr=""))
    schedule.install(env.home, jobs=["health"], load=True, now=NOW, local_tz=NY, log=lambda *_: None, **env.kw)
    assert calls[0][:2] == ["launchctl", "bootout"] and calls[1][:3] == ["launchctl", "bootstrap", f"gui/{os.getuid()}"]


def test_show_lists_jobs(env):
    rows = schedule.show(env.home, log=lambda *_: None, **env.kw)
    assert rows["record"]["when"].startswith("18:20 America/New_York on M,T,W,T,F") and rows["record"]["installed"] is False


# --- job wrapper -----------------------------------------------------------------------------------------------

def _clock(*ts):
    it = iter(ts)
    return lambda: next(it)


def test_run_job_records_ok_and_failure(tmp_path):
    seen = []

    def runner(argv, cwd, env):
        seen.append(argv)
        return SimpleNamespace(returncode={"good": 0, "bad": 3}[argv[0]])
    t = dt.datetime(2026, 10, 23, 22, 20, tzinfo=dt.timezone.utc)
    assert jobs.run_job("record", [["good"], ["good"]], tmp_path, runner=runner, clock=_clock(t, t + dt.timedelta(minutes=2)), env={}, log=lambda *_: None) == 0
    last = json.loads((tmp_path / "outputs/logs/jobs/record.last.json").read_text())
    assert last["status"] == "ok" and last["exit_code"] == 0 and last["ended_at"] == "2026-10-23T22:22:00+00:00" and len(last["steps"]) == 2
    seen.clear()
    assert jobs.run_job("record", [["bad"], ["good"]], tmp_path, runner=runner, clock=_clock(t, t), env={}, log=lambda *_: None) == 3
    assert seen == [["bad"]]                                       # stops at the first failure
    last = jobs.last_runs(tmp_path)["record"]
    assert last["status"] == "failed" and last["exit_code"] == 3
    hist = [json.loads(line) for line in (tmp_path / "outputs/logs/jobs/history.jsonl").read_text().splitlines()]
    assert [h["event"] for h in hist] == ["start", "end", "start", "end"] and not (tmp_path / "outputs/logs/jobs/record.lock").exists()


def test_run_job_missing_program_is_failure(tmp_path):
    def runner(argv, cwd, env):
        raise FileNotFoundError(argv[0])
    assert jobs.run_job("x", [["/nope"]], tmp_path, runner=runner, env={}, log=lambda *_: None) == 127


def test_run_job_skips_when_previous_still_running(tmp_path):
    d = jobs.jobs_dir(tmp_path); d.mkdir(parents=True)
    (d / "morning.lock").write_text(str(os.getppid()))             # a live process that is not us
    called = []
    rc = jobs.run_job("morning", [["x"]], tmp_path, runner=lambda *a, **k: called.append(a), env={}, log=lambda *_: None)
    assert rc == jobs.EXIT_OVERLAP and not called


def test_env_file_loaded_only_when_private(tmp_path):
    f = tmp_path / ".ops.env"; f.write_text("# alerts\nexport ECONQUEST_ALERT_WEBHOOK='https://hooks.example/x'\nBAD\n")
    f.chmod(0o644)
    assert jobs.load_env_file(f, log=lambda *_: None) == {}
    f.chmod(0o600)
    assert jobs.load_env_file(f) == {"ECONQUEST_ALERT_WEBHOOK": "https://hooks.example/x"}
    got = {}
    jobs.run_job("h", [["x"]], tmp_path, runner=lambda argv, cwd, env: got.update(env) or SimpleNamespace(returncode=0), env={}, log=lambda *_: None)
    assert got["ECONQUEST_ALERT_WEBHOOK"] == "https://hooks.example/x" and got["ECONQUEST_HOME"] == str(tmp_path)


def test_jobs_main_runs_real_subprocess(tmp_path):
    import sys
    rc = jobs.main(["--home", str(tmp_path), "--job", "t", "--step", json.dumps([sys.executable, "-c", "raise SystemExit(4)"])])
    assert rc == 4 and jobs.last_runs(tmp_path)["t"]["exit_code"] == 4


def test_spreadsheet_id_cannot_inject_into_record_script(env):
    # regression (AGENT-09 review of EQ-C-0021): ops.json spreadsheet_id is spliced into the record job's `bash -c`
    # script inside double quotes, so `x"; touch /tmp/pwned; "` ran a command at 18:20 every weekday
    (env.home / "ops.json").write_text(json.dumps({"spreadsheet_id": 'x"; touch /tmp/pwned; "'}))
    with pytest.raises(ValueError, match="spreadsheet_id"):
        schedule.install(env.home, None, jobs=["record"], now=NOW, local_tz=NY, log=lambda *_: None, **env.kw)
    assert not (env.la / "com.econquest.record.plist").exists()
    (env.home / "ops.json").write_text(json.dumps({"spreadsheet_id": "1w4OLCkv4EvDFgaO6MBOipAuY2fjAlCQJ-OjtmHJshQY"}))
    schedule.install(env.home, None, jobs=["record"], now=NOW, local_tz=NY, log=lambda *_: None, **env.kw)
    script = _load(env, "record")["ProgramArguments"]
    assert any("1w4OLCkv4EvDFgaO6MBOipAuY2fjAlCQJ-OjtmHJshQY" in a for a in script)
    assert not any("ya29" in a or "Bearer ya" in a for a in script)              # no token in the plist
