"""EQ-A-0033: licensed vendor adapter framework (Bloomberg BLPAPI, LSEG Data Library) behind a licence gate.

Everything here is SYNTHETIC: fictional sovereigns XAA / XBB, fictional identifiers ('ZZFAKE ... Corp',
'ZZFAKE5Y=FAKE'), fictional licence ids. The blpapi and lseg.data modules are in-memory fakes built from the
adapters' own reading of the vendor docs: these tests show the request building, parsing, licence gate and write path
are consistent with that reading, NOT that the vendor wire formats are right (untested against a terminal)."""
import datetime as dt
import json
import os
import subprocess
import sys
import types
from pathlib import Path

import pandas as pd
import pytest

from econquest.ingestion.market.cds_export import export_gated_cds_snapshots
from econquest.ingestion.market.importers import MAP_COLUMNS
from econquest.ingestion.market.schema import MARKET_COLUMNS, MarketDataError
from econquest.ingestion.market.store import cds_snapshots_path, list_market_snapshots, read_market_snapshot
from econquest.ingestion.market.vendors import (VendorNotLicensed, VendorRequestError, adapter_names, get_adapter,
                                                load_entitlement, register, vendor_status)
from econquest.ingestion.market.vendors.base import VendorConnectionError, VendorAdapter
from econquest.ingestion.market.vendors.bloomberg import BloombergAdapter, parse_historical, parse_reference
from econquest.ingestion.market.vendors.lseg import LsegAdapter, parse_history
from econquest.ingestion.market.vendors.pipeline import pull_to_store

ROOT = Path(__file__).resolve().parents[1]
T0 = dt.datetime(2026, 10, 22, 18, 0, tzinfo=dt.timezone.utc)
TODAY = T0.date()
D = "2026-10-22"
BBG_LIC = "licence_id=FAKE-BBG-0001;holder=Synthetic Desk;scope=desk-internal;expiry=2027-06-30"
LSEG_LIC = "licence_id=FAKE-LSEG-0001;holder=Synthetic Desk;scope=desk-internal;expiry=2027-06-30"
APP_KEY = "FAKEAPPKEY0123456789abcdefSECRET"
BBG5, BBG10, BBGX = "ZZFAKE CDS USD SR 5Y D14 Corp", "ZZFAKE CDS USD SR 10Y D14 Corp", "ZZFAKEB CDS USD SR 5Y D14 Corp"
RIC5, RIC10 = "ZZFAKE5Y=FAKE", "ZZFAKE10Y=FAKE"


def map_row(source, ticker, vf, iso="XAA", tenor=5, status="verified", field="spread_bp", unit="bp", scale="1"):
    return {"source": source, "vendor_ticker": ticker, "vendor_field": vf, "instrument": "cds", "iso": iso,
            "currency": "USD", "tenor_y": str(tenor), "field": field, "unit": unit, "doc_clause": "CR14",
            "scale": scale, "status": status, "note": "SYNTHETIC"}


MAPPING = pd.DataFrame([
    map_row("bloomberg", BBG5, "PX_LAST"), map_row("bloomberg", BBG10, "PX_LAST", tenor=10),
    map_row("bloomberg", BBGX, "PX_LAST", iso="XBB", status="verify"),
    map_row("lseg", RIC5, "FAKE_CLOSE"), map_row("lseg", RIC10, "FAKE_CLOSE", tenor=10),
    map_row("lseg", "ZZFAKENOFIELD=FAKE", ""),
], columns=MAP_COLUMNS)


# ------------------------------------------------------------------------------------------------- fake blpapi

def fake_blpapi(reference=None, history=None, start_ok=True):
    """In-memory stand-in for the blpapi module, shaped after the adapter's reading of the vendor docs."""
    m = types.ModuleType("blpapi")
    log = {"sessions": [], "requests": []}
    m.log = log

    class Event:
        REQUEST_STATUS, RESPONSE, PARTIAL_RESPONSE, TIMEOUT = 4, 5, 6, 10

    class Msg:
        def __init__(self, d, kind="X"):
            self.d, self.kind = d, kind

        def toPy(self):
            return self.d

        def messageType(self):
            return self.kind

    class Ev:
        def __init__(self, t, msgs):
            self.t, self.msgs = t, msgs

        def eventType(self):
            return self.t

        def __iter__(self):
            return iter(self.msgs)

    class Element:
        def __init__(self):
            self.values = []

        def appendValue(self, v):
            self.values.append(v)

    class Request:
        def __init__(self, kind):
            self.kind, self.elements, self.params = kind, {"securities": Element(), "fields": Element()}, {}

        def getElement(self, name):
            return self.elements[name]

        def set(self, k, v):
            self.params[k] = v

    class Service:
        def createRequest(self, kind):
            return Request(kind)

    class SessionOptions:
        def __init__(self):
            self.host = self.port = self.identity = None

        def setServerHost(self, h):
            self.host = h

        def setServerPort(self, p):
            self.port = p

        def setSessionIdentityOptions(self, a):
            self.identity = a

    class AuthOptions:
        @staticmethod
        def createWithApp(app):
            return ("app", app)

    class Session:
        def __init__(self, opts):
            self.opts, self.queue, self.stopped = opts, [], False
            log["sessions"].append(self)

        def start(self):
            return start_ok

        def openService(self, name):
            return name == "//blp/refdata"

        def getService(self, name):
            return Service()

        def stop(self):
            self.stopped = True

        def sendRequest(self, req):
            log["requests"].append(req)
            secs, flds = req.elements["securities"].values, req.elements["fields"].values
            if req.kind == "ReferenceDataRequest":
                sd = []
                for s in secs:
                    if s not in (reference or {}):
                        sd.append({"security": s, "securityError": {"message": "Unknown/Invalid security"}})
                        continue
                    sd.append({"security": s, "fieldData": {f: reference[s][f] for f in flds if f in reference[s]},
                               "fieldExceptions": []})
                self.queue = [Ev(Event.RESPONSE, [Msg({"ReferenceDataResponse": {"securityData": sd}})])]
            else:
                evs = []
                for k, s in enumerate(secs):
                    pts = [{"date": dt.date.fromisoformat(d), **v} for d, v in (history or {}).get(s, [])]
                    body = {"securityData": {"security": s, "fieldData": pts, "fieldExceptions": []}}
                    evs.append(Ev(Event.RESPONSE if k == len(secs) - 1 else Event.PARTIAL_RESPONSE, [Msg(body)]))
                self.queue = evs

        def nextEvent(self, timeout_ms):
            return self.queue.pop(0) if self.queue else Ev(Event.TIMEOUT, [])

    m.Event, m.SessionOptions, m.AuthOptions, m.Session = Event, SessionOptions, AuthOptions, Session
    return m


# ------------------------------------------------------------------------------------------------- fake lseg.data

def fake_ld(get_data=None, get_history=None, open_error=None):
    ld = types.ModuleType("lseg.data")
    log = {"defs": [], "calls": [], "opened": 0, "closed": 0}
    ld.log = log

    class Sess:
        def open(self):
            if open_error:
                raise RuntimeError(open_error)
            log["opened"] += 1

        def close(self):
            log["closed"] += 1

    def definition(kind):
        class Definition:
            def __init__(self, **kw):
                log["defs"].append((kind, kw))

            def get_session(self):
                return Sess()
        return Definition

    def grant(username, password):
        return ("grant", username, password)

    ld.session = types.SimpleNamespace(desktop=types.SimpleNamespace(Definition=definition("desktop")),
                                       platform=types.SimpleNamespace(Definition=definition("platform"),
                                                                      GrantPassword=grant),
                                       set_default=lambda s: None)

    def gd(universe, fields):
        log["calls"].append(("get_data", list(universe), list(fields)))
        return get_data(universe, fields)

    def gh(universe, fields, start, end, interval):
        log["calls"].append(("get_history", list(universe), list(fields), start, end, interval))
        return get_history(universe, fields)

    gd.__name__, gh.__name__ = "get_data", "get_history"
    ld.get_data, ld.get_history = gd, gh
    return ld


def bbg(tmp_path, env=None, **kw):
    e = {"ECONQUEST_VENDOR_LICENCE_BLOOMBERG": BBG_LIC} if env is None else env
    return BloombergAdapter(tmp_path, env=e, mapping=MAPPING, today=TODAY, now=T0, **kw)


def lsg(tmp_path, env=None, **kw):
    e = {"ECONQUEST_VENDOR_LICENCE_LSEG": LSEG_LIC, "ECONQUEST_LSEG_APP_KEY": APP_KEY} if env is None else env
    return LsegAdapter(tmp_path, env=e, mapping=MAPPING, today=TODAY, now=T0, **kw)


# ------------------------------------------------------------------------------------------------- packaging

def test_vendor_package_imports_without_blpapi_or_lseg():
    code = ("import sys; import econquest.ingestion.market.vendors as v; "
            "from econquest.ingestion.market.vendors import bloomberg, lseg, pipeline; "
            "st = v.vendor_status('nowhere', env={}); "
            "assert not st['usable'].any(), st; "
            "assert 'blpapi' not in sys.modules and 'lseg' not in sys.modules and 'lseg.data' not in sys.modules; "
            "print('ok')")
    env = {k: v for k, v in os.environ.items() if not k.startswith("ECONQUEST_VENDOR_LICENCE_")}
    out = subprocess.run([sys.executable, "-c", code], cwd=ROOT, env=env, capture_output=True, text=True, timeout=120)
    assert out.returncode == 0, out.stderr[-2000:]
    assert out.stdout.strip() == "ok"


def test_registry():
    assert adapter_names() == ["bloomberg", "lseg"]
    assert isinstance(get_adapter("bloomberg", data_dir="x", env={}), BloombergAdapter)
    assert isinstance(get_adapter("lseg", data_dir="x", env={}), LsegAdapter)
    with pytest.raises(KeyError, match="unknown vendor adapter"):
        get_adapter("freedata")
    with pytest.raises(ValueError):
        register("Bad Name", BloombergAdapter)


# ------------------------------------------------------------------------------------------------- licence gate

def test_not_licensed_by_default_and_never_falls_back(tmp_path):
    m = fake_blpapi(reference={BBG5: {"PX_LAST": 100.0}})
    a = bbg(tmp_path, env={}, module=m)
    assert not a.available()
    with pytest.raises(VendorNotLicensed) as e:
        a.snapshot([BBG5])
    msg = str(e.value)
    assert "paid roadmap feature" in msg and "ECONQUEST_VENDOR_LICENCE_BLOOMBERG" in msg
    assert "vendor_licences.json" in msg and "no free source" in msg
    assert m.log["sessions"] == [] and m.log["requests"] == []
    with pytest.raises(VendorNotLicensed):
        pull_to_store(a, tmp_path, [BBG5], now=T0)
    assert list_market_snapshots(tmp_path).empty


def test_package_missing_is_not_licensed(tmp_path):
    a = BloombergAdapter(tmp_path, env={"ECONQUEST_VENDOR_LICENCE_BLOOMBERG": BBG_LIC}, mapping=MAPPING, today=TODAY)
    st = a.licence_state()
    assert st.licence == "ok" and not st.package_ok and not st.usable
    with pytest.raises(VendorNotLicensed, match="econquest\\[bloomberg\\].*Bloomberg's own package index"):
        a.require()


def test_licence_from_env_and_file_env_wins(tmp_path):
    (tmp_path / "vendor_licences.json").write_text(json.dumps({"lseg": {
        "licence_id": "FAKE-FILE-7", "holder": "Synthetic Desk", "scope": "redistribution", "expiry": "2027-01-31"}}))
    ent = load_entitlement("lseg", tmp_path, env={})
    assert (ent.licence_id, ent.scope, ent.expiry) == ("FAKE-FILE-7", "redistribution", dt.date(2027, 1, 31))
    assert ent.tag == "lseg:FAKE-FILE-7 (redistribution)" and ent.origin.endswith("vendor_licences.json")
    ent = load_entitlement("lseg", tmp_path, env={"ECONQUEST_VENDOR_LICENCE_LSEG": LSEG_LIC})
    assert ent.licence_id == "FAKE-LSEG-0001" and ent.origin == "env ECONQUEST_VENDOR_LICENCE_LSEG"
    js = json.dumps({"id": "FAKE-J", "holder": "H", "scope": "desk-internal", "expiry": "2027-01-01"})
    assert load_entitlement("lseg", None, env={"ECONQUEST_VENDOR_LICENCE_LSEG": js}).licence_id == "FAKE-J"
    assert load_entitlement("bloomberg", tmp_path, env={}) is None


@pytest.mark.parametrize("raw,why", [
    ("licence_id=FAKE;holder=H;scope=everyone;expiry=2027-01-01", "scope must be one of"),
    ("licence_id=FAKE;holder=H;scope=desk-internal", "missing \\['expiry'\\]"),
    ("licence_id==1+1;holder=H;scope=desk-internal;expiry=2027-01-01", "licence_id must be"),
    ("licence_id=FAKE;holder=H;scope=desk-internal;expiry=31/12/2027", "expiry must be a YYYY-MM-DD"),
    ("licence_id=FAKE;holder=H;scope=desk-internal;expiry=2027-01-01;app_key=" + APP_KEY, "look like credentials"),
])
def test_malformed_entitlement_refused_without_echoing_values(tmp_path, raw, why):
    a = bbg(tmp_path, env={"ECONQUEST_VENDOR_LICENCE_BLOOMBERG": raw}, module=fake_blpapi())
    with pytest.raises(VendorNotLicensed, match=why) as e:
        a.require()
    assert APP_KEY not in str(e.value) and "everyone" not in str(e.value)


def test_expiry(tmp_path):
    lic = "licence_id=FAKE-OLD;holder=H;scope=desk-internal;expiry=2026-10-22"
    a = bbg(tmp_path, env={"ECONQUEST_VENDOR_LICENCE_BLOOMBERG": lic}, module=fake_blpapi())
    assert a.available()                                             # the expiry day itself is still valid
    late = BloombergAdapter(tmp_path, env={"ECONQUEST_VENDOR_LICENCE_BLOOMBERG": lic}, mapping=MAPPING,
                            module=fake_blpapi(), today=dt.date(2026, 10, 23))
    assert late.licence_state().licence == "expired"
    with pytest.raises(VendorNotLicensed, match="FAKE-OLD expired on 2026-10-22"):
        late.history([BBG5], None, D, D)
    st = vendor_status(tmp_path, env={"ECONQUEST_VENDOR_LICENCE_BLOOMBERG": lic}, today=dt.date(2026, 10, 23))
    row = st.set_index("vendor").loc["bloomberg"]
    assert row["licence"] == "expired" and not row["usable"] and row["licence_id"] == "FAKE-OLD"


# ------------------------------------------------------------------------------------------------- ticker map

def test_unverified_and_unmapped_tickers_refused_before_any_session(tmp_path):
    m = fake_blpapi(reference={BBGX: {"PX_LAST": 1.0}})
    a = bbg(tmp_path, module=m)
    with pytest.raises(VendorRequestError, match="not verified.*ZZFAKEB CDS USD SR 5Y D14 Corp \\(status verify\\)"):
        a.snapshot([BBG5, BBGX])
    with pytest.raises(VendorRequestError, match="unmapped bloomberg identifiers.*NOPE Corp"):
        a.snapshot(["NOPE Corp"])
    with pytest.raises(VendorRequestError, match="unsafe identifiers"):
        a.snapshot(["=HYPERLINK(1)"])
    assert m.log["sessions"] == []


def test_template_rows_are_all_refused(tmp_path):
    from econquest.ingestion.market.importers import TEMPLATE
    tmpl = pd.read_csv(TEMPLATE, dtype=str, keep_default_na=False)
    for name, mod in (("bloomberg", fake_blpapi()), ("lseg", fake_ld())):
        env = {f"ECONQUEST_VENDOR_LICENCE_{name.upper()}": BBG_LIC if name == "bloomberg" else LSEG_LIC}
        a = get_adapter(name, data_dir=tmp_path, env=env, module=mod, mapping=TEMPLATE, today=TODAY)
        tickers = tmpl.loc[tmpl["source"] == name, "vendor_ticker"].head(3).tolist()
        with pytest.raises(VendorRequestError, match="not verified"):
            a.plan(tickers)


def test_lseg_blank_vendor_field_needs_explicit_field(tmp_path):
    a = lsg(tmp_path, module=fake_ld())
    with pytest.raises(VendorRequestError, match="no vendor field for \\['ZZFAKENOFIELD=FAKE'\\]"):
        a.plan(["ZZFAKENOFIELD=FAKE"])
    assert [(i.ticker, i.vendor_field) for i in a.plan(["ZZFAKENOFIELD=FAKE"], fields=["FAKE_CLOSE"])] == \
        [("ZZFAKENOFIELD=FAKE", "FAKE_CLOSE")]


# ------------------------------------------------------------------------------------------------- bloomberg

def test_bloomberg_snapshot_desktop(tmp_path):
    m = fake_blpapi(reference={BBG5: {"PX_LAST": 101.5}, BBG10: {"PX_LAST": 140.25}})
    a = bbg(tmp_path, module=m)
    assert a.licence_tag == "bloomberg:FAKE-BBG-0001 (desk-internal)"
    df = a.snapshot([BBG5, BBG10, BBG5])
    s = m.log["sessions"][0]
    assert (s.opts.host, s.opts.port, s.opts.identity) == ("localhost", 8194, None)
    (req,) = m.log["requests"]
    assert req.kind == "ReferenceDataRequest"
    assert req.elements["securities"].values == [BBG5, BBG10] and req.elements["fields"].values == ["PX_LAST"]
    assert list(df.columns) == MARKET_COLUMNS
    assert df[["asof", "iso", "tenor_y", "value", "source", "vendor_ticker"]].values.tolist() == [
        [D, "XAA", 5.0, 101.5, "bloomberg", BBG5], [D, "XAA", 10.0, 140.25, "bloomberg", BBG10]]
    assert set(df["licence"]) == {"bloomberg:FAKE-BBG-0001 (desk-internal)"}
    assert set(df["retrieved_utc"]) == {"2026-10-22T18:00:00Z"}
    a.close()
    assert s.stopped


def test_bloomberg_history_and_errors(tmp_path):
    hist = {BBG5: [("2026-10-20", {"PX_LAST": 100.0}), ("2026-10-21", {"PX_LAST": float("nan")}),
                   ("2026-10-22", {"PX_LAST": 102.0})],
            BBG10: [("2026-10-22", {"PX_LAST": 150.0})]}
    m = fake_blpapi(history=hist)
    with bbg(tmp_path, module=m) as a:
        df = a.history([BBG5, BBG10], ["PX_LAST"], "2026-10-20", D)
    (req,) = m.log["requests"]
    assert req.kind == "HistoricalDataRequest"
    assert req.params == {"startDate": "20261020", "endDate": "20261022", "periodicitySelection": "DAILY"}
    assert df[["asof", "tenor_y", "value"]].values.tolist() == [["2026-10-20", 5.0, 100.0], [D, 5.0, 102.0],
                                                               [D, 10.0, 150.0]]
    assert df.attrs["skipped"] == 1 and "untested" in df.attrs["wire_format"]
    with pytest.raises(VendorRequestError, match="after today"):
        bbg(tmp_path, module=fake_blpapi()).history([BBG5], None, D, "2026-10-23")


def test_bloomberg_snapshot_as_of_uses_one_day_history(tmp_path):
    m = fake_blpapi(history={BBG5: [("2026-10-21", {"PX_LAST": 99.0})]})
    df = bbg(tmp_path, module=m).snapshot([BBG5], as_of="2026-10-21")
    assert m.log["requests"][0].params["startDate"] == m.log["requests"][0].params["endDate"] == "20261021"
    assert df["asof"].tolist() == ["2026-10-21"] and df.attrs["request"]["as_of"] == "2026-10-21"


def test_bloomberg_parsers():
    raw, err = parse_reference({"securityData": [
        {"security": "A", "fieldData": {"PX_LAST": 1.0}, "fieldExceptions": [
            {"fieldId": "PX_BID", "errorInfo": {"message": "Field not applicable"}}]},
        {"security": "B", "securityError": {"message": "Unknown/Invalid security"}}]}, ["PX_LAST", "PX_BID"])
    assert raw == [("A", "PX_LAST", None, 1.0)]
    assert err == ["A [PX_BID]: fieldException Field not applicable", "B: securityError Unknown/Invalid security"]
    raw, err = parse_historical({"securityData": {"security": "A", "fieldData": [
        {"date": "2026-10-20", "PX_LAST": 1.0}, {"date": "garbage", "PX_LAST": 2.0}]}}, ["PX_LAST"])
    assert raw == [("A", "PX_LAST", "2026-10-20", 1.0)] and len(err) == 1
    with pytest.raises(VendorConnectionError, match="responseError"):
        parse_reference({"responseError": {"message": "not entitled"}}, ["PX_LAST"])


def test_bloomberg_unexpected_answer_refused(tmp_path):
    m = fake_blpapi(reference={BBG5: {"PX_LAST": 1.0}})
    a = bbg(tmp_path, module=m)
    a.connect()
    a._fetch_snapshot = lambda items: ([("SOMETHING ELSE Corp", "PX_LAST", None, 1.0)], [])
    with pytest.raises(VendorRequestError, match="not requested"):
        a.snapshot([BBG5])


def test_bloomberg_bpipe_from_env_and_bad_config(tmp_path):
    env = {"ECONQUEST_VENDOR_LICENCE_BLOOMBERG": BBG_LIC, "ECONQUEST_BPIPE_HOST": "bpipe.example.invalid",
           "ECONQUEST_BPIPE_PORT": "8196", "ECONQUEST_BPIPE_APP_NAME": "synthetic:app"}
    m = fake_blpapi(reference={BBG5: {"PX_LAST": 1.0}})
    bbg(tmp_path, env=env, module=m).snapshot([BBG5])
    o = m.log["sessions"][0].opts
    assert (o.host, o.port, o.identity) == ("bpipe.example.invalid", 8196, ("app", "synthetic:app"))
    for k, v, why in (("ECONQUEST_BPIPE_PORT", "99999", "port number"), ("ECONQUEST_BPIPE_APP_NAME", "", "needs"),
                      ("ECONQUEST_BPIPE_HOST", "evil host;", "not a host")):
        with pytest.raises(VendorConnectionError, match=why):
            bbg(tmp_path, env={**env, k: v}, module=fake_blpapi()).connect()
    with pytest.raises(VendorConnectionError, match="did not start"):
        bbg(tmp_path, module=fake_blpapi(start_ok=False)).connect()


def test_bad_values_fail_market_validation(tmp_path):
    m = fake_blpapi(reference={BBG5: {"PX_LAST": float("inf")}, BBG10: {"PX_LAST": "n/a"}})
    df = bbg(tmp_path, module=m).snapshot([BBG5, BBG10])
    assert df.empty and df.attrs["skipped"] == 2
    rec = MAPPING.copy()
    rec.loc[0, ["field", "unit"]] = ["recovery", "fraction"]
    a = BloombergAdapter(tmp_path, env={"ECONQUEST_VENDOR_LICENCE_BLOOMBERG": BBG_LIC}, mapping=rec, today=TODAY,
                         now=T0, module=fake_blpapi(reference={BBG5: {"PX_LAST": 40.0}}))
    with pytest.raises(MarketDataError, match="recovery must be a fraction"):
        a.snapshot([BBG5])


# ------------------------------------------------------------------------------------------------- lseg

def lseg_history(universe, fields):
    idx = pd.to_datetime(["2026-10-21", "2026-10-22"])
    cols = pd.MultiIndex.from_tuples([(r, f) for r in universe for f in fields])
    data = {(RIC5, "FAKE_CLOSE"): [120.0, 121.0], (RIC10, "FAKE_CLOSE"): [float("nan"), 160.0]}
    return pd.DataFrame({c: data[c] for c in cols}, index=idx)


def test_lseg_desktop_snapshot_and_history(tmp_path):
    ld = fake_ld(get_data=lambda u, f: pd.DataFrame({"Instrument": [RIC5, RIC10], "FAKE_CLOSE": [120.5, None]}),
                 get_history=lseg_history)
    with lsg(tmp_path, module=ld) as a:
        snap = a.snapshot([RIC5, RIC10])
        hist = a.history([RIC5, RIC10], None, "2026-10-21", D)
    assert ld.log["defs"] == [("desktop", {"app_key": APP_KEY})] and ld.log["closed"] == 1
    assert ld.log["calls"][0] == ("get_data", [RIC5, RIC10], ["FAKE_CLOSE"])
    assert ld.log["calls"][1] == ("get_history", [RIC5, RIC10], ["FAKE_CLOSE"], "2026-10-21", D, "daily")
    assert snap[["asof", "tenor_y", "value", "source"]].values.tolist() == [[D, 5.0, 120.5, "lseg"]]
    assert snap.attrs["skipped"] == 1
    assert hist[["asof", "tenor_y", "value"]].values.tolist() == [["2026-10-21", 5.0, 120.0], [D, 5.0, 121.0],
                                                                 [D, 10.0, 160.0]]
    assert set(hist["licence"]) == {"lseg:FAKE-LSEG-0001 (desk-internal)"}


def test_lseg_history_single_level_shapes():
    one = pd.DataFrame({"FAKE_CLOSE": [1.0]}, index=pd.to_datetime([D]))
    assert parse_history(one, ["R"], ["FAKE_CLOSE"])[0] == [("R", "FAKE_CLOSE", D, 1.0)]
    wide = pd.DataFrame({"R1": [1.0], "R2": [2.0]}, index=pd.to_datetime([D]))
    assert parse_history(wide, ["R1", "R2"], ["F"])[0] == [("R1", "F", D, 1.0), ("R2", "F", D, 2.0)]
    with pytest.raises(VendorRequestError, match="shape not recognised"):
        parse_history(wide, ["R1", "R2"], ["F", "G"])


def test_lseg_platform_session_and_secret_hygiene(tmp_path):
    env = {"ECONQUEST_VENDOR_LICENCE_LSEG": LSEG_LIC, "ECONQUEST_LSEG_APP_KEY": APP_KEY,
           "ECONQUEST_LSEG_SESSION": "platform"}
    with pytest.raises(VendorConnectionError, match="needs ECONQUEST_LSEG_USERNAME and ECONQUEST_LSEG_PASSWORD"):
        lsg(tmp_path, env=env, module=fake_ld()).connect()
    env.update({"ECONQUEST_LSEG_USERNAME": "synthetic.user", "ECONQUEST_LSEG_PASSWORD": "FAKE-PASSWORD-xyz"})
    ld = fake_ld()
    a = lsg(tmp_path, env=env, module=ld)
    a.connect()
    kind, kw = ld.log["defs"][0]
    assert kind == "platform" and kw["grant"] == ("grant", "synthetic.user", "FAKE-PASSWORD-xyz")
    assert APP_KEY not in repr(a) and "FAKE-PASSWORD" not in repr(a)
    # a library error that quotes the credentials: only the exception type reaches the message (SEC-A-005 L1)
    bad = lsg(tmp_path, env=env, module=fake_ld(open_error=f"401 for key {APP_KEY} pw FAKE-PASSWORD-xyz"))
    with pytest.raises(VendorConnectionError) as e:
        bad.connect()
    assert str(e.value) == "LSEG platform session failed to open: RuntimeError"
    assert e.value.__cause__ is None and e.value.__context__ is None          # original exception not chained
    with pytest.raises(VendorConnectionError, match="app key missing"):
        lsg(tmp_path, env={"ECONQUEST_VENDOR_LICENCE_LSEG": LSEG_LIC}, module=fake_ld()).connect()


def test_lseg_app_key_from_keychain(tmp_path, monkeypatch):
    kr = types.ModuleType("keyring")
    kr.get_password = lambda service, user: APP_KEY if (service, user) == ("econquest-lseg", "ECONQUEST_LSEG_APP_KEY") \
        else None
    monkeypatch.setitem(sys.modules, "keyring", kr)
    ld = fake_ld()
    lsg(tmp_path, env={"ECONQUEST_VENDOR_LICENCE_LSEG": LSEG_LIC}, module=ld).connect()
    assert ld.log["defs"] == [("desktop", {"app_key": APP_KEY})]


# ------------------------------------------------------------------------------------------------- write path

def test_pull_to_store_save_gate_export(tmp_path):
    ld = fake_ld(get_history=lseg_history)
    res = pull_to_store(lsg(tmp_path, module=ld), tmp_path, [RIC5, RIC10], start="2026-10-21", end=D, now=T0)
    assert res.snapshot is not None and len(res.rows) == 3
    snap = read_market_snapshot(tmp_path, res.snapshot.name)
    assert set(snap["source"]) == {"lseg"} and set(snap["licence"]) == {"lseg:FAKE-LSEG-0001 (desk-internal)"}
    man = json.loads((res.snapshot / "manifest.json").read_text())
    assert man["provenance"]["licence_id"] == "FAKE-LSEG-0001" and man["provenance"]["scope"] == "desk-internal"
    assert "untested" in man["provenance"]["wire_format"]
    assert (res.review["status"] == "ok").all() and len(res.review) == 2
    assert res.cds_export.appended == 3                               # every quote date of the new snapshot
    out = pd.read_csv(cds_snapshots_path(tmp_path), keep_default_na=False)
    assert set(out["source"]) == {"lseg"}
    # secret hygiene: the app key is nowhere on disk
    for p in tmp_path.rglob("*"):
        if p.is_file():
            assert APP_KEY.encode() not in p.read_bytes(), p


def test_pull_to_store_held_jump_not_exported_and_dry_run_saves_nothing(tmp_path):
    a1 = bbg(tmp_path, module=fake_blpapi(reference={BBG5: {"PX_LAST": 300.0}}))
    r1 = pull_to_store(a1, tmp_path, [BBG5], now=T0)
    assert r1.cds_export.appended == 1
    t1 = T0 + dt.timedelta(minutes=5)
    a2 = BloombergAdapter(tmp_path, env={"ECONQUEST_VENDOR_LICENCE_BLOOMBERG": BBG_LIC}, mapping=MAPPING, today=TODAY,
                          now=t1, module=fake_blpapi(reference={BBG5: {"PX_LAST": 3000.0}}))
    dry = pull_to_store(a2, tmp_path, [BBG5], now=t1, dry_run=True)
    assert dry.snapshot is None and dry.dry_run and len(list_market_snapshots(tmp_path)) == 1
    assert dry.review["status"].tolist() == ["hold"] and "jump" in dry.review["reason"].iloc[0]
    with pytest.raises(VendorConnectionError, match="create a new one"):    # credentials released after a session
        a2.connect()
    a2 = BloombergAdapter(tmp_path, env={"ECONQUEST_VENDOR_LICENCE_BLOOMBERG": BBG_LIC}, mapping=MAPPING, today=TODAY,
                          now=t1, module=fake_blpapi(reference={BBG5: {"PX_LAST": 3000.0}}))
    r2 = pull_to_store(a2, tmp_path, [BBG5], now=t1)
    assert r2.review["status"].tolist() == ["hold"]
    assert r2.cds_export.appended == 0 and r2.cds_export.dropped["check"].tolist() == ["gate"]
    assert pd.read_csv(cds_snapshots_path(tmp_path))["value"].tolist() == [300.0]
    assert "held" in r2.summary()
    assert export_gated_cds_snapshots(tmp_path).appended == 0


def test_adapter_contract_is_abstract():
    with pytest.raises(TypeError):
        VendorAdapter("x")


# ------------------------------------------------------------------------------------------------- SEC-A-005

class HttpishError(Exception):
    def __init__(self, msg, status_code):
        super().__init__(msg)
        self.status_code = status_code


PW = "p@ss w0rd/&=+"


@pytest.mark.parametrize("where", ["open", "get_data"])
def test_l1_encoded_or_case_changed_credentials_never_reach_errors(tmp_path, where):
    import base64
    import urllib.parse
    forms = [urllib.parse.quote(PW, safe=""), urllib.parse.quote_plus(PW), APP_KEY.lower(), APP_KEY.upper(),
             base64.b64encode(f"synthetic.user:{PW}".encode()).decode(), PW, APP_KEY]
    text = "token request failed: " + " ".join(f"password={f}" for f in forms)
    env = {"ECONQUEST_VENDOR_LICENCE_LSEG": LSEG_LIC, "ECONQUEST_LSEG_APP_KEY": APP_KEY,
           "ECONQUEST_LSEG_SESSION": "platform", "ECONQUEST_LSEG_USERNAME": "synthetic.user",
           "ECONQUEST_LSEG_PASSWORD": PW}
    if where == "open":
        ld = fake_ld()
        ld.session.set_default = lambda s: (_ for _ in ()).throw(HttpishError(text, 401))
    else:
        def boom(u, f):
            raise HttpishError(text, 999)                # status not on the allow-list: not reported
        ld = fake_ld(get_data=boom)
    a = lsg(tmp_path, env=env, module=ld)
    with pytest.raises(VendorConnectionError) as e:
        a.snapshot([RIC5])
    msg = str(e.value)
    for f in forms:
        assert f not in msg and f.casefold() not in msg.casefold()
    assert msg.endswith("HttpishError (HTTP 401)" if where == "open" else "get_data failed: HttpishError")
    assert e.value.__context__ is None and e.value.__cause__ is None


def test_safe_error_status_allow_list():
    from econquest.ingestion.market.vendors.base import safe_error
    resp = types.SimpleNamespace(status_code=429)
    err = RuntimeError("x")
    err.response = resp
    assert safe_error(err) == "RuntimeError (HTTP 429)"
    assert safe_error(HttpishError("x", 418)) == "HttpishError"
    assert safe_error(HttpishError("x", True)) == "HttpishError"


@pytest.mark.parametrize("name,env_extra,lic_id", [
    ("lseg", {}, APP_KEY),                                              # equals the app key (also: pasted-key shape)
    ("lseg", {"ECONQUEST_LSEG_PASSWORD": "Desk-Pw-77"}, "desk-pw-77"),  # the password, case changed
    ("lseg", {"ECONQUEST_LSEG_USERNAME": "desk.user7"}, "ACCT-desk.user7"),
    ("bloomberg", {"ECONQUEST_BPIPE_APP_NAME": "synthetic:app"}, "BBG/synthetic:app"),
])
def test_l2_licence_id_carrying_a_credential_is_refused(tmp_path, name, env_extra, lic_id):
    lic = f"licence_id={lic_id};holder=Synthetic Desk;scope=desk-internal;expiry=2027-06-30"
    env = {f"ECONQUEST_VENDOR_LICENCE_{name.upper()}": lic, "ECONQUEST_LSEG_APP_KEY": APP_KEY, **env_extra}
    mod = fake_ld() if name == "lseg" else fake_blpapi()
    a = get_adapter(name, data_dir=tmp_path, env=env, module=mod, mapping=MAPPING, today=TODAY)
    st = a.licence_state()
    assert not st.usable and st.entitlement is None
    with pytest.raises(VendorNotLicensed) as e:
        a.require()
    assert lic_id not in str(e.value)
    assert (APP_KEY not in str(e.value)) and ("credential" in str(e.value) or "pasted key" in str(e.value))
    row = vendor_status(tmp_path, env=env, today=TODAY).set_index("vendor").loc[name]
    assert row["licence_id"] == "" and lic_id not in row["problems"]


def test_l2_long_unseparated_id_refused_and_normal_ids_kept(tmp_path):
    with pytest.raises(VendorNotLicensed, match="looks like a pasted key"):
        load_entitlement("lseg", None, env={"ECONQUEST_VENDOR_LICENCE_LSEG":
                                            "licence_id=Ab3dEf6hIj9kLm2nOp5qRs8t;holder=H;scope=desk-internal;"
                                            "expiry=2027-01-01"})
    a = lsg(tmp_path, module=fake_ld())
    assert a.available() and a.licence_tag == "lseg:FAKE-LSEG-0001 (desk-internal)"


def test_l3_credential_keys_at_any_depth_and_unknown_keys_refused(tmp_path):
    good = {"licence_id": "FAKE-FILE-7", "holder": "Synthetic Desk", "scope": "desk-internal", "expiry": "2027-01-31"}
    cases = [
        ({"lseg": {**good, "extra": {"password": "hunter2"}}}, "lseg.extra.password"),
        ({"lseg": good, "lseg_app_key": "hunter2"}, "lseg_app_key"),
        ({"bloomberg": {**good, "notes": [{"api_key": "hunter2"}]}, "lseg": good}, "bloomberg.notes[0].api_key"),
    ]
    for doc, path in cases:
        (tmp_path / "vendor_licences.json").write_text(json.dumps(doc))
        with pytest.raises(VendorNotLicensed) as e:
            load_entitlement("lseg", tmp_path, env={})
        assert path in str(e.value) and "hunter2" not in str(e.value)
    (tmp_path / "vendor_licences.json").write_text(json.dumps({"lseg": {**good, "comment": "hunter2"}}))
    with pytest.raises(VendorNotLicensed, match="unknown keys \\['comment'\\]") as e:
        load_entitlement("lseg", tmp_path, env={})
    assert "hunter2" not in str(e.value)
    nested_env = json.dumps({**good, "holder": {"token": "hunter2"}})
    with pytest.raises(VendorNotLicensed, match="holder.token") as e:
        load_entitlement("lseg", None, env={"ECONQUEST_VENDOR_LICENCE_LSEG": nested_env})
    assert "hunter2" not in str(e.value)


def test_i1_no_environment_or_credentials_kept_after_connect(tmp_path):
    env = {"ECONQUEST_VENDOR_LICENCE_LSEG": LSEG_LIC, "ECONQUEST_LSEG_APP_KEY": APP_KEY,
           "ECONQUEST_LSEG_SESSION": "platform", "ECONQUEST_LSEG_USERNAME": "synthetic.user",
           "ECONQUEST_LSEG_PASSWORD": "FAKE-PASSWORD-xyz", "UNRELATED": "x"}
    ld = fake_ld(get_data=lambda u, f: pd.DataFrame({"Instrument": [RIC5], "FAKE_CLOSE": [1.0]}))
    a = lsg(tmp_path, env=env, module=ld)
    a.connect()
    assert a._env == {"ECONQUEST_VENDOR_LICENCE_LSEG": LSEG_LIC, "ECONQUEST_LSEG_SESSION": "platform"}
    assert a._env is not env
    blob = repr(vars(a))
    assert APP_KEY not in blob and "FAKE-PASSWORD-xyz" not in blob and "synthetic.user" not in blob
    assert len(a.snapshot([RIC5])) == 1                               # still licensed and usable while connected
    b = bbg(tmp_path, module=fake_blpapi())
    b.connect()
    assert b._env is not os.environ and set(b._env) == {"ECONQUEST_VENDOR_LICENCE_BLOOMBERG"}
