"""Change approvals for assumptions.json and limits.json (EQ-C-0023). Every test works on a temp copy of data/."""
import json
import shutil
from pathlib import Path

import pytest

from econquest.ops import approvals as ap
from econquest.ops.approvals import ApprovalError

DATA = Path(__file__).resolve().parents[1] / "data"


@pytest.fixture
def data(tmp_path):
    d = tmp_path / "data"; d.mkdir()
    for f in ap.FILES:
        shutil.copy2(DATA / f, d / f)
    return d


def _read(d, f="assumptions.json"):
    return json.loads((d / f).read_text())


def test_propose_approve_apply_happy_path(data):
    before = (data / "assumptions.json").read_bytes()
    old = _read(data)["layer4"]["lgd_sd"]
    p = ap.propose(data, "assumptions.json", {"/layer4/lgd_sd": old + 0.01}, "Sam", "widen LGD dispersion")
    assert p["tier"] == "1" and p["base_sha256"] == ap.sha256_bytes(before)
    assert p["diff"] == [{"path": "/layer4/lgd_sd", "op": "change", "old": old, "new": old + 0.01}]
    assert (data / "assumptions.json").read_bytes() == before          # propose never writes the file
    assert ap.list_changes(data)[0]["status"] == "proposed"
    ap.approve(data, p["id"], approver="Alice")
    row = ap.apply(data, p["id"], actor="Sam")
    assert _read(data)["layer4"]["lgd_sd"] == old + 0.01
    assert row["file_sha256"] == ap.file_sha256(data / "assumptions.json") == p["new_sha256"]
    assert ap.show(data, p["id"])["status"] == "applied"
    assert [e["event"] for e in ap.show(data, p["id"])["events"]] == ["propose", "approve", "apply"]
    assert ap.verify_chain(data)["ok"]
    assert {f["file"]: f["status"] for f in ap.detect_unapproved(data)["files"]}["assumptions.json"] == "ok"
    with pytest.raises(ApprovalError, match="only an approved"):
        ap.apply(data, p["id"])                                         # not twice
    assert not list(data.glob(".assumptions.json.*.tmp"))


def test_tier_inference_and_explicit_tier(data):
    assert ap.propose(data, "limits.json", {"/book/var99_mm": 100.0}, "Sam", "raise")["tier"] == "limit"
    assert ap.propose(data, "assumptions.json", {"/alerts/var_change_pct": 12}, "Sam", "x")["tier"] == "2"
    seed = _read(data)["monte_carlo"]["seed"]
    assert ap.propose(data, "assumptions.json", {"/monte_carlo/seed": seed + 1}, "Sam", "x")["tier"] == "run"
    assert ap.propose(data, "assumptions.json", {"/monte_carlo/seed": seed + 2}, "Sam", "x", tier="1")["tier"] == "1"
    with pytest.raises(ApprovalError, match="can only be raised"):
        ap.propose(data, "assumptions.json", {"/layer4/lgd_sd": 0.3}, "Sam", "x", tier="3")
    assert ap.propose(data, "assumptions.json", {"/layer1/mode": "fitted"}, "Sam", "x")["needs_validator"]


def test_propose_validation(data):
    with pytest.raises(ApprovalError, match="key does not exist"):
        ap.propose(data, "assumptions.json", {"/layer4/no_such": 1}, "Sam", "x")
    p = ap.propose(data, "assumptions.json", {"/layer4/new_key": 1}, "Sam", "x", allow_new_keys=True)
    assert p["diff"][0]["op"] == "add"
    with pytest.raises(ApprovalError, match="JSON type"):
        ap.propose(data, "limits.json", {"/book/var99_mm": "lots"}, "Sam", "x")
    with pytest.raises(ApprovalError, match="not valid JSON"):
        ap.propose(data, "limits.json", {"/book/var99_mm": float("nan")}, "Sam", "x")
    with pytest.raises(ApprovalError, match="unchanged"):
        ap.propose(data, "limits.json", {"/warning_level": _read(data, "limits.json")["warning_level"]}, "Sam", "x")
    with pytest.raises(ApprovalError, match="only"):
        ap.propose(data, "../countries.csv", {"/a": 1}, "Sam", "x")
    with pytest.raises(ApprovalError, match="reason"):
        ap.propose(data, "limits.json", {"/warning_level": 0.7}, "Sam", " ")
    whole = _read(data, "limits.json"); del whole["issuer"]
    with pytest.raises(ApprovalError, match="adds or removes"):
        ap.propose(data, "limits.json", whole, "Sam", "x", replace=True)
    whole = _read(data, "limits.json"); whole["warning_level"] = 0.75
    assert ap.propose(data, "limits.json", json.dumps(whole), "Sam", "x", replace=True)["diff"][0]["path"] == "/warning_level"


@pytest.mark.parametrize("same", ["Sam", "sam", "  SAM ", "S​am", "﻿sam‍", "Ｓam"])
def test_same_person_approve_refused(data, same):
    p = ap.propose(data, "limits.json", {"/warning_level": 0.75}, "Sam", "tighten")
    with pytest.raises(ApprovalError, match="four-eyes"):
        ap.approve(data, p["id"], approver=same)
    assert ap.show(data, p["id"])["status"] == "proposed"


def test_self_approve_needs_exc(data):
    p = ap.propose(data, "limits.json", {"/warning_level": 0.75}, "Sam", "tighten")
    with pytest.raises(ApprovalError, match="EXC-nnn"):
        ap.approve(data, p["id"], approver="Sam", self_approved=True)
    with pytest.raises(ApprovalError, match="EXC-nnn"):
        ap.approve(data, p["id"], self_approved=True, exc_id="EXC-1")
    with pytest.raises(ApprovalError, match="EXC-nnn"):
        ap.approve(data, p["id"], self_approved=True, exc_id="GOV-042")
    q = ap.propose(data, "assumptions.json", {"/layer4/lgd_sd": 0.3}, "Sam", "Tier 1")
    with pytest.raises(ApprovalError):
        ap.approve(data, q["id"], approver=None)
    row = ap.approve(data, p["id"], self_approved=True, exc_id="EXC-001")
    assert row["approver"] == "Sam" and row["self_approved"] == "yes" and row["exc_id"] == "EXC-001"
    ap.apply(data, p["id"])
    assert _read(data, "limits.json")["warning_level"] == 0.75


def test_exc_logged_lookup(data):
    gov = data.parent / "docs" / "governance"; gov.mkdir(parents=True)
    (gov / "issues-log.md").write_text("| Id | Date |\n|---|---|\n| EXC-001 | 2026-10-23 |\n")
    assert ap.exc_logged(data, "EXC-001") is True and ap.exc_logged(data, "EXC-002") is False
    p = ap.propose(data, "limits.json", {"/warning_level": 0.75}, "Sam", "x")
    assert "not yet in issues-log" in ap.approve(data, p["id"], self_approved=True, exc_id="EXC-002")["note"]


def test_stale_base_refused(data):
    p = ap.propose(data, "limits.json", {"/warning_level": 0.75}, "Sam", "x")
    q = ap.propose(data, "limits.json", {"/book/es99_mm": 120.0}, "Sam", "y")
    ap.approve(data, p["id"], approver="Alice"); ap.approve(data, q["id"], approver="Alice")
    ap.apply(data, p["id"])
    with pytest.raises(ApprovalError, match="stale"):
        ap.apply(data, q["id"])
    assert _read(data, "limits.json")["book"]["es99_mm"] == 115.0
    r = ap.propose(data, "assumptions.json", {"/alerts/var_change_pct": 11}, "Sam", "z")
    ap.approve(data, r["id"], approver="Alice")
    (data / "assumptions.json").write_text((data / "assumptions.json").read_text() + " ")      # hand edit
    with pytest.raises(ApprovalError, match="stale"):
        ap.apply(data, r["id"])


def test_not_approved_and_rejected_refused(data):
    p = ap.propose(data, "limits.json", {"/warning_level": 0.75}, "Sam", "x")
    with pytest.raises(ApprovalError, match="only an approved"):
        ap.apply(data, p["id"])
    ap.reject(data, p["id"], "Alice", "no")
    with pytest.raises(ApprovalError, match="rejected"):
        ap.approve(data, p["id"], approver="Alice")
    with pytest.raises(ApprovalError, match="only an approved"):
        ap.apply(data, p["id"])
    with pytest.raises(ApprovalError, match="not a change id"):
        ap.show(data, "../../etc/passwd")


def _chain(data, n=3):
    for i in range(n):
        p = ap.propose(data, "limits.json", {"/warning_level": 0.70 + i / 100}, "Sam", f"r{i}")
    ap.approve(data, p["id"], approver="Alice")
    assert ap.verify_chain(data)["ok"]
    return ap.log_path(data).read_text().splitlines()


def _write(data, lines):
    ap.log_path(data).write_text("\n".join(lines) + "\n")


def test_chain_edit_detected(data):
    lines = _chain(data)
    r = json.loads(lines[1]); r["actor"] = "Mallory"; lines[1] = json.dumps(r)
    _write(data, lines)
    v = ap.verify_chain(data)
    assert not v["ok"] and any("edited" in e for e in v["errors"])
    with pytest.raises(ApprovalError, match="verification"):
        ap.propose(data, "limits.json", {"/warning_level": 0.9}, "Sam", "x")


def test_chain_delete_reorder_truncate_detected(data):
    lines = _chain(data)
    _write(data, lines[:1] + lines[2:])
    assert not ap.verify_chain(data)["ok"]
    _write(data, [lines[0], lines[2], lines[1], lines[3]])
    assert not ap.verify_chain(data)["ok"]
    _write(data, lines[:-1])                                            # tail dropped: head.json catches it
    v = ap.verify_chain(data)
    assert not v["ok"] and any("head.json" in e for e in v["errors"])
    _write(data, lines)
    assert ap.verify_chain(data)["ok"]


def test_proposal_file_tamper_detected(data):
    p = ap.propose(data, "limits.json", {"/warning_level": 0.75}, "Sam", "x")
    ap.approve(data, p["id"], approver="Alice")
    pp = ap.proposal_path(data, p["id"]); doc = json.loads(pp.read_text())
    doc["new_text"] = doc["new_text"].replace("0.75", "0.95"); pp.write_text(json.dumps(doc))
    assert not ap.verify_chain(data)["ok"]
    with pytest.raises(ApprovalError, match="verification"):
        ap.apply(data, p["id"])


def test_formula_prefixes_neutralised(data):
    p = ap.propose(data, "limits.json", {"/warning_level": 0.75}, "=HYPERLINK(\"x\")", "+cmd|' /C calc'!A0")
    row = ap.read_log(data)[-1]
    assert row["actor"].startswith("'=") and row["note"].startswith("'+") and p["author"].startswith("'=")
    with pytest.raises(ApprovalError, match="four-eyes"):                # guard apostrophe does not dodge four-eyes
        ap.approve(data, p["id"], approver="=hyperlink(\"x\")")
    assert ap.verify_chain(data)["ok"]


def test_drift_detected(data):
    st = {f["file"]: f["status"] for f in ap.detect_unapproved(data)["files"]}
    assert st == {"assumptions.json": "no_baseline", "limits.json": "no_baseline", "compliance.json": "no_baseline"}
    ap.baseline(data, "limits.json", "Sam", "adopt tool")
    ap.baseline(data, "assumptions.json", "Sam", "adopt tool")
    assert ap.detect_unapproved(data)["ok"]
    lim = _read(data, "limits.json"); lim["book"]["var99_mm"] = 500.0
    (data / "limits.json").write_text(json.dumps(lim, indent=2))        # hand edit outside the tool
    rep = ap.detect_unapproved(data)
    assert not rep["ok"] and {f["file"]: f["status"] for f in rep["files"]}["limits.json"] == "drift"
    with pytest.raises(ApprovalError, match="four-eyes"):                # accepting drift is a sign-off
        ap.baseline(data, "limits.json", "Sam", "accept")
    ap.baseline(data, "limits.json", "Sam", "accept", approver="Alice")
    assert ap.detect_unapproved(data)["ok"]


@pytest.mark.parametrize("seg", ["²", "١", "-1", "2", "x"])
def test_array_index_must_be_ascii_digits_in_range(seg):
    # regression (AGENT-09 review of EQ-C-0023): "²".isdigit() is True and int("²") raised a bare ValueError (a traceback
    # in `econquest change propose` instead of a refusal)
    with pytest.raises(ApprovalError, match="no such array index"):
        ap.apply_patch({"arr": [1, 2]}, {f"/arr/{seg}": 5})
    assert ap.apply_patch({"a/b": {"~x": 1}}, {"/a~1b/~0x": 2}) == {"a/b": {"~x": 2}}      # RFC 6901 ~1 and ~0
