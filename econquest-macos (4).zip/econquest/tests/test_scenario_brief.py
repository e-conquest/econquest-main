"""Scenario briefs (EQ-C-0025): narrative and channels from scenarios.json, book impact against base, top contributors
from the archived stress run, reverse-stress distance, playbook hedges, caveats, disclaimer and stamps."""
import html as _h
import json
import sys
from pathlib import Path

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from econquest.presentation import scenario_brief as S  # noqa: E402
from econquest.presentation.report import DISCLAIMER  # noqa: E402
from test_country_note import make_world  # noqa: E402

SCEN = {"scenarios": [
    {"key": "A", "name": "Hawkish Fed", "kind": "hypothetical", "source": "Paper 9.1", "description": "Fed +200 bp: spreads wider, EM FX weaker.",
     "shocks": [{"target": "countries", "column": "spread", "op": "add", "value": 280}, {"target": "countries", "column": "fx3m", "op": "add", "value": 12},
                {"target": "settings", "key": "regime.*.global_loading", "op": "add", "value": 0.25}, {"target": "trigger", "pillar": 5, "value": 10.0}]},
    {"key": "GFC08", "name": "Global financial crisis", "kind": "historical", "source": "approx.", "description": "2008.", "shocks": []}]}


def world(tmp_path, reverse=True):
    d, out, base = make_world(tmp_path)
    (d / "scenarios.json").write_text(json.dumps(SCEN))
    cmp_ = {"var99_mm": {"base": 60.0, "stress": 90.0, "change_pct": 50.0}, "es99_mm": {"base": 78.0, "stress": 117.0, "change_pct": 50.0},
            "es975_frtb_mm": {"base": 66.0, "stress": 80.0, "change_pct": 21.2}, "lvar99_mm": {"base": 63.0, "stress": 95.0, "change_pct": 50.8},
            "liquidity_cost99_mm": {"base": 3.0, "stress": 4.0, "change_pct": 33.3}, "expected_loss_mm": {"base": 1.5, "stress": 3.0, "change_pct": 100.0},
            "regimes": {"base": {"Calm": 2, "Stressed": 1}, "stress": {"Stressed": 2, "Crisis": 1}}, "share_to_crisis": 1 / 3, "mean_pd_default_change_pp": 4.0, "mean_lgd_change_pp": 2.0}
    (out / "stress.json").write_text(json.dumps({"A": {"name": "Hawkish Fed", "description": "Fed +200 bp", "comparison": cmp_}}))
    # stressed run activates T01 for C (not active in base) and B (already active in base)
    st_path = next((out / "store" / "archive").glob("r-stress-A.json"))
    sr = json.loads(st_path.read_text()); sr["activation"] = [{"trade": "T01", "A": None, "B": 80.0, "C": 65.0}]
    st_path.write_text(json.dumps(sr))
    if reverse:
        (out / "reverse_stress.json").write_text(json.dumps({"measure": "var99_mm", "limit": 80.0, "paths": 2000, "base": 60.0, "scenarios": [
            {"scenario": "A", "measure": "var99_mm", "limit": 80.0, "breach_scale": 0.5, "value_at_breach": 81.0, "status": "breach found",
             "path": [{"scale": 0.0, "value": 60.0}, {"scale": 0.5, "value": 81.0}, {"scale": 1.0, "value": 90.0}],
             "shocks_at_breach": ["spread +140"], "other_breaches": [{"scope": "book", "name": "book", "measure": "var99_mm", "value": 81.0, "limit": 80.0, "utilisation": 1.0125}]}]}))
    return d, out


def build(tmp_path, **kw):
    d, out = world(tmp_path, reverse=kw.pop("reverse", True))
    return S.build_scenario_briefs(out, d, tmp_path / "briefs", log=lambda *a: None, **kw)


def test_brief_per_scenario_with_results(tmp_path):
    res = build(tmp_path)
    assert res["kind"] == "scenario_briefs" and [i["scenario"] for i in res["items"]] == ["A"]      # GFC08 has no results: not written by default
    it = res["items"][0]
    assert it["stress_run_id"] == "r-stress-A" and it["run_id"] == "r-base" and res["run_hash"] == "ru11" and res["data_hash"] == "da7a"
    for p in res["paths"]:
        t = Path(p).read_text(encoding="utf-8")
        assert DISCLAIMER in t or _h.escape(DISCLAIMER) in t, p
    html = Path(it["html"]).read_text(encoding="utf-8")
    for s in ("<b>Run</b> r-base", "<b>Stress run</b> r-stress-A", "<b>As of</b> 2026-10-20"):
        assert s in html, s
    assert "Stress run hash" not in html                                  # same run_hash as the base run: not repeated
    assert "<script" not in html and "https://" not in html


def test_narrative_channels_and_book_impact(tmp_path):
    html = Path(build(tmp_path)["items"][0]["html"]).read_text(encoding="utf-8")
    assert "Fed +200 bp: spreads wider" in html and "Paper 9.1" in html
    for ch in ("Sovereign spreads", "Currencies (3-month move)", "Contagion and regime loadings", "Scorecard pillar triggers"):
        assert f"<td>{ch}</td>" in html, ch
    var_row = html.split("<td>VaR 99%</td>")[1].split("</tr>")[0]
    assert "60.0" in var_row and "90.0" in var_row and "+30.0" in var_row and "+50.0%" in var_row
    assert "Moved to Crisis: 33% of countries" in html


def test_contributors_reverse_and_hedges(tmp_path):
    html = Path(build(tmp_path)["items"][0]["html"]).read_text(encoding="utf-8")
    top = html.split("Top countries by stressed 99% tail contribution")[1].split("</table>")[0]
    assert top.index("<td>C</td>") < top.index("<td>B</td>") < top.index("<td>A</td>")   # sorted by stressed contribution
    assert "+6.00" in top                                                                  # C: 6 -> 12
    assert "<b>0.50x</b>" in html and "absorbs 50% of the scenario" in html and "book var99_mm" in html
    hedges = html.split("<section id='hedges'>")[1]
    assert "T01" in hedges and "C (65) NEW" in hedges and "B (80)" in hedges and "B (80) NEW" not in hedges
    assert "use restriction 6.5" in hedges


def test_missing_reverse_and_named_scenario_without_results(tmp_path):
    res = build(tmp_path, reverse=False, scenarios=["a", "GFC08"])
    assert [i["scenario"] for i in res["items"]] == ["A", "GFC08"] and res["items"][1]["has_results"] is False
    assert "No reverse-stress result" in Path(res["items"][0]["html"]).read_text(encoding="utf-8")
    g = Path(res["items"][1]["html"]).read_text(encoding="utf-8")
    assert "Global financial crisis" in g and "No book impact" in g and "--scenario GFC08" in g


def test_unknown_scenario(tmp_path):
    d, out = world(tmp_path)
    with pytest.raises(ValueError, match="unknown scenario"):
        S.build_scenario_briefs(out, d, tmp_path / "b", scenarios=["NOPE"], log=lambda *a: None)


def test_scenario_library_fallback(tmp_path):
    d, out = world(tmp_path)
    (out / "stress.json").unlink()
    pd.DataFrame([{"scenario": "GFC08", "name": "Global financial crisis", "kind": "historical", "scale": 1.0, "var99_mm": 120.0, "es99_mm": 150.0,
                   "lvar99_mm": 125.0, "expected_loss_mm": 4.0, "var99_mm_pct": 100.0, "es99_mm_pct": 92.3, "to_crisis": 0.5, "mean_pd_pp": 6.0}]).to_csv(out / "scenario_library.csv", index=False)
    res = S.build_scenario_briefs(out, d, tmp_path / "b", log=lambda *a: None)
    assert [i["scenario"] for i in res["items"]] == ["GFC08"]
    html = Path(res["items"][0]["html"]).read_text(encoding="utf-8")
    row = html.split("<td>VaR 99%</td>")[1].split("</tr>")[0]
    assert "60.0" in row and "120.0" in row and "outputs/scenario_library.csv" in html


def test_channel_of():
    assert S.channel_of({"target": "settings", "key": "liquidity.by_asset.*.spread_mean"}) == "Market liquidity"
    assert S.channel_of({"target": "indicators", "id": "1.3"}) == "Scorecard indicators"
    assert S.channel_of({"target": "countries", "column": "weird"}) == "Country profile: weird"
