"""EQ-A-0031: market data quality gate. All quotes SYNTHETIC (tests/fixtures/market/quotes_sample.csv)."""
from pathlib import Path

import pandas as pd
import pytest

from econquest.ingestion.market.gate import REVIEW_COLUMNS, GateParams, market_gate

FIX = Path(__file__).parent / "fixtures" / "market" / "quotes_sample.csv"


def sample():
    return pd.read_csv(FIX, dtype=str, keep_default_na=False)


def row(review, key_start, iso=None):
    r = review[review["key"].str.startswith(key_start)]
    if iso is not None:
        r = r[r["country"] == iso]
    assert len(r) == 1, (key_start, iso, review)
    return r.iloc[0]


def setv(df, mask, value):
    df.loc[mask, "value"] = str(value)
    return df


def is_(df, inst, iso=None, tenor=None, field=None):
    m = df["instrument"] == inst
    if iso is not None:
        m &= df["iso"] == iso
    if tenor is not None:
        m &= df["tenor_y"] == str(tenor)
    if field is not None:
        m &= df["field"] == field
    return m


def test_clean_fixture_passes_and_columns_match_feeds():
    rv = market_gate(sample())
    assert list(rv.columns) == REVIEW_COLUMNS == ["table", "key", "country", "seed", "live", "status", "reason"]
    assert set(rv["table"]) == {"market"} and len(rv) == len(sample())
    held = rv[rv["status"] == "hold"]
    assert held.empty, held
    # ARG curve 1000 -> 900 is inverted by 100bp: flagged, not held
    arg = row(rv, "cds|USD|5|spread_bp", "ARG")
    assert arg["status"] == "ok" and arg["reason"].startswith("flag: curve inverted by 100bp")


def test_stale():
    df = sample()
    df.loc[is_(df, "cds", "BRA", 10), "asof"] = "2026-10-14"                 # 4 business days before 10-20
    df.loc[is_(df, "policy_rate"), "asof"] = "2026-09-01"                    # within 45 bd
    rv = market_gate(df)
    assert row(rv, "cds|USD|10|spread_bp", "BRA")["status"] == "hold"
    assert "stale" in row(rv, "cds|USD|10|spread_bp", "BRA")["reason"]
    assert row(rv, "policy_rate", "BRA")["status"] == "ok"
    rv = market_gate(sample(), asof="2026-10-27")                             # 5 bd later: everything but policy
    assert set(rv.loc[rv["status"] == "hold", "key"].str.split("|").str[0]) == {
        "cds", "embi_spread", "govt_yield", "fx_spot", "fx_forward", "ois"}
    rv = market_gate(sample(), asof="2026-10-27", params=GateParams(stale_bdays={"cds": 10}))
    assert (rv.loc[rv["key"].str.startswith("cds"), "status"] == "ok").all()


def test_curve_non_monotone_held():
    df = sample()
    df = setv(df, is_(df, "cds", "BRA", 3, "spread_bp"), 300)                 # 100, 300, 200, 250
    rv = market_gate(df)
    bra = rv[rv["key"].str.startswith("cds|USD") & rv["key"].str.contains("spread_bp") & (rv["country"] == "BRA")]
    assert len(bra) == 4 and (bra["status"] == "hold").all() and bra["reason"].str.contains("non-monotone").all()
    df = setv(sample(), is_(sample(), "cds", "BRA", 3, "spread_bp"), 203)      # within 5bp of the 5y: noise
    assert market_gate(df).query("country == 'BRA'")["status"].eq("ok").all()


def test_range_negative_and_absurd():
    df = sample()
    df = setv(df, is_(df, "cds", "BRA", 1, "spread_bp"), -5)
    df = setv(df, is_(df, "govt_yield", "BRA", 2), 900)
    rv = market_gate(df)
    assert "range" in row(rv, "cds|USD|1|spread_bp", "BRA")["reason"]
    assert row(rv, "govt_yield|BRL|2", "BRA")["status"] == "hold"


def test_arbitrage_fx_forward_vs_cip():
    df = setv(sample(), is_(sample(), "fx_forward"), 6.0)                     # implied ~5.385
    rv = market_gate(df)
    r = row(rv, "fx_forward", "BRA")
    assert r["status"] == "hold" and "arbitrage" in r["reason"]
    pts = sample()
    pts.loc[is_(pts, "fx_forward"), ["field", "value"]] = ["points", "0.385"]
    assert row(market_gate(pts), "fx_forward", "BRA")["status"] == "ok"
    pts.loc[is_(pts, "fx_forward"), "value"] = "1.5"
    assert row(market_gate(pts), "fx_forward", "BRA")["status"] == "hold"
    norate = df[~is_(df, "ois", tenor=None)]                                  # no rates: check skipped
    assert row(market_gate(norate), "fx_forward", "BRA")["status"] == "ok"


def test_jump_vs_previous():
    prev = sample()
    cur = sample()
    cur["asof"] = "2026-10-21"; cur["retrieved_utc"] = "2026-10-21T22:00:00Z"
    cur = setv(cur, is_(cur, "cds", "BRA", 5, "spread_bp"), 300)              # +50%, +100bp: hold
    cur = setv(cur, is_(cur, "cds", "BRA", 10, "spread_bp"), 350)             # keeps the curve monotone
    cur = setv(cur, is_(cur, "cds", "BRA", 1, "spread_bp"), 125)              # +25%, +25bp: under both
    cur = setv(cur, is_(cur, "fx_spot"), 5.5)                                 # +10%
    cur = setv(cur, is_(cur, "fx_forward"), 5.9)                              # keep CIP consistent
    rv = market_gate(cur, previous=prev)
    r5 = row(rv, "cds|USD|5|spread_bp", "BRA")
    assert r5["status"] == "hold" and r5["seed"] == 200 and r5["live"] == 300 and "jump" in r5["reason"]
    assert row(rv, "cds|USD|1|spread_bp", "BRA")["status"] == "ok"
    assert "jump" in row(rv, "fx_spot", "BRA")["reason"]
    assert pd.isna(row(market_gate(cur), "fx_spot", "BRA")["seed"])


@pytest.mark.parametrize("what", ["embi", "bond"])
def test_bond_cds_basis(what):
    df = sample()
    if what == "embi":
        df = setv(df, is_(df, "embi_spread", "BRA"), 500)                    # vs CDS 200: 300bp > 150
        other = "embi_spread"
    else:
        df = setv(df, is_(df, "govt_yield", "BRA", 5), 9)                     # 9% - 4% = 500bp
        other = "govt_yield|USD|5"
    rv = market_gate(df)
    c = row(rv, "cds|USD|5|spread_bp", "BRA")
    assert c["status"] == "hold" and "basis" in c["reason"]
    assert row(rv, other, "BRA")["status"] == "hold"
    loose = GateParams(basis_abs_bp=400)
    assert row(market_gate(df, params=loose), "cds|USD|5|spread_bp", "BRA")["status"] == "ok"


def test_gate_uses_latest_quote_per_series_and_empty():
    hist = pd.concat([sample(), sample().assign(asof="2026-10-19")])
    rv = market_gate(hist)
    assert len(rv) == len(sample()) and rv["key"].str.endswith("2026-10-20").all()
    assert market_gate(sample().iloc[0:0]).empty


def test_non_commercial_licence_is_held(monkeypatch):
    """EQ-A-0040 (Sam 2026-10-23): a row that may only be used personally / non-commercially never passes the gate,
    so the Yahoo spot behind the research opt-in cannot reach a desk number or a publish."""
    from econquest.ingestion.market.forwards import YAHOO_LICENCE
    df = sample()
    m = is_(df, "fx_spot")
    assert m.any()
    df.loc[m, "licence"] = YAHOO_LICENCE
    df.loc[m, "source"] = "yahoo"
    rv = market_gate(df)
    held = rv[rv["status"] == "hold"]
    assert len(held) == int(m.sum())
    assert held["reason"].str.contains("licence: non-commercial, personal use only").all()
    # the same rows with an official licence pass
    df.loc[m, "licence"] = "BIS statistics: free reuse with attribution to the BIS per bis.org terms of use (unverified)"
    df.loc[m, "source"] = "bis_xru"
    assert market_gate(df)[market_gate(df)["status"] == "hold"].empty


@pytest.mark.parametrize("source", ["yahoo", "yfinance"])   # the schema allows lowercase slugs only
def test_yahoo_source_is_held_whatever_the_licence(source):
    """SEC-A-006 L6: a row whose source is Yahoo is held even when its licence text looks clean (a relabelled import
    or a caller-set licence)."""
    df = sample()
    m = is_(df, "fx_spot")
    df.loc[m, "licence"] = "free official"
    df.loc[m, "source"] = source
    rv = market_gate(df)
    held = rv[rv["status"] == "hold"]
    assert len(held) == int(m.sum())
    assert held["reason"].str.contains("personal, non-commercial").all()
