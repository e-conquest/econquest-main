"""Econometrics toolkit tests on simulated data. Run: python tests/test_econometrics.py"""
import sys
from pathlib import Path
import numpy as np
import pandas as pd
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.engine.econometrics import (adf_test, kpss_test, benjamini_hochberg, ols_hac, ar_fit_bic, engle_granger, johansen, var_fit, svar_irf,
                                          kalman_beta, markov_switching, threshold_ar, gpd_tail, t_copula_fit, clayton_fit, diebold_mariano, event_study)

rng = np.random.default_rng(11)


def test_unit_root_tests():
    rw = np.cumsum(rng.standard_normal(800)); wn = rng.standard_normal(800)
    assert adf_test(rw)["p"] > 0.10 and adf_test(wn)["p"] < 0.01
    assert kpss_test(rw)["p"] < 0.05 and kpss_test(wn)["p"] > 0.05
    p = np.array([0.001, 0.01, 0.04, 0.2, 0.5]); d = benjamini_hochberg(p, 0.05)
    assert d.tolist() == [True, True, False, False, False] or d.tolist() == [True, True, True, False, False]


def test_hac_and_ar():
    x = rng.standard_normal(600); e = np.zeros(600)
    for t in range(1, 600):
        e[t] = 0.6 * e[t - 1] + rng.standard_normal()
    y = 1 + 2 * x + e
    res = ols_hac(y, np.column_stack([np.ones(600), x]))
    naive_se = np.sqrt(np.diag(np.linalg.inv(np.column_stack([np.ones(600), x]).T @ np.column_stack([np.ones(600), x])) * res["resid"].var()))
    assert abs(res["b"][1] - 2) < 0.2 and res["se"][0] > naive_se[0]        # HAC widens the intercept SE under autocorrelated errors
    ar = ar_fit_bic(e)
    assert ar["p"] >= 1 and abs(ar["coef"][1] - 0.6) < 0.1


def test_cointegration_and_var():
    x = np.cumsum(rng.standard_normal(1000)); y = 0.8 * x + rng.standard_normal(1000) * 0.5
    eg = engle_granger(y, x); jo = johansen(np.column_stack([y, x]))
    assert eg["p"] < 0.01 and abs(eg["beta"] - 0.8) < 0.05 and jo["rank"] >= 1
    z = np.cumsum(rng.standard_normal(1000)); eg2 = engle_granger(z, x); jo2 = johansen(np.column_stack([z, x]))
    assert eg2["p"] > 0.05 and jo2["rank"] == 0
    # VAR(1) with a known shock chain: shock to variable 0 moves variable 1 next period
    Y = np.zeros((1500, 2)); u = rng.standard_normal((1500, 2))
    for t in range(1, 1500):
        Y[t, 0] = 0.3 * Y[t - 1, 0] + u[t, 0]; Y[t, 1] = 0.5 * Y[t - 1, 0] + 0.2 * Y[t - 1, 1] + u[t, 1]
    f = var_fit(Y, 1); irf, fevd = svar_irf(f, 10)
    assert abs(f["A"][0][1, 0] - 0.5) < 0.1 and irf[1, 1, 0] > 0.3 and fevd[1, 0] > 0.15


def test_kalman_regimes_tails_copulas():
    x = rng.standard_normal(800); beta = np.linspace(0.5, 1.5, 800); y = beta * x + 0.3 * rng.standard_normal(800)
    kb = kalman_beta(y, x)
    assert kb["beta_now"] > 1.2 and kb["beta_1y_ago"] < kb["beta_now"]
    r = np.concatenate([rng.standard_normal(500) * 0.005, rng.standard_normal(200) * 0.02, rng.standard_normal(300) * 0.005])
    ms = markov_switching(r)
    assert ms["vol_turbulent"] > 2 * ms["vol_calm"] and ms["p_turbulent_now"] < 0.5
    tar = threshold_ar(r); assert np.isfinite(tar["sup_f"])
    z = rng.standard_t(4, 5000); g = gpd_tail(z)
    assert 0.05 < g["xi"] < 0.6 and g["q999"] > g["q99"] > 0
    # Student-t copula sample with rho 0.6, df 4 -> positive tail dependence; Clayton theta recovers lower-tail clustering
    L = np.linalg.cholesky([[1, 0.6], [0.6, 1]]); W = rng.chisquare(4, 3000) / 4
    Z = (rng.standard_normal((3000, 2)) @ L.T) / np.sqrt(W)[:, None]
    from scipy import stats
    u = stats.rankdata(Z[:, 0]) / 3001; v = stats.rankdata(Z[:, 1]) / 3001
    tc = t_copula_fit(u, v); cl = clayton_fit(u, v)
    assert abs(tc["rho"] - 0.6) < 0.08 and tc["nu"] <= 10 and tc["lambda_lower"] > 0.1 and cl["theta"] > 0.3 and tc["aic"] < cl["aic"]
    assert np.isfinite(diebold_mariano(rng.standard_normal(300), rng.standard_normal(300) + 0.5)[0])


def test_event_study_detects_injected_drop():
    idx = pd.bdate_range("2023-01-02", periods=900)
    mkt = pd.Series(rng.standard_normal(900) * 0.01, index=idx)
    fx = pd.Series(rng.standard_normal(900) * 0.004, index=idx)
    etf = 0.8 * mkt + pd.Series(rng.standard_normal(900) * 0.008, index=idx)
    for i in (400, 500, 600, 700):
        fx.iloc[i] = 0.03; etf.iloc[i] -= 0.04
    out = event_study(etf, fx, mkt)
    assert out["n_events"] == 4 and out["car_0_0_pct"] < -2 and out["t_0_0"] < -2


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn(); print("ok", name)
