"""Dashboard page (EQ-C-0003): renders from a real run dict, escapes data text, shows run id, as-of and disclaimer."""
import copy
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.config import Settings  # noqa: E402
from econquest.ingestion import load_universe  # noqa: E402
from econquest.engine import run_pipeline  # noqa: E402
from econquest.presentation.dashboard import render_dashboard, _heat, _svg_hist  # noqa: E402
from econquest.presentation.report import DISCLAIMER  # noqa: E402
import html as _h  # noqa: E402

DATA = ROOT / "data"


@pytest.fixture(scope="module")
def run_dict():
    u = load_universe(DATA); s = Settings.load(DATA / "assumptions.json")
    try:
        res = run_pipeline(u, s, paths=2000, as_of="2026-10-23")
    except TypeError:
        res = run_pipeline(u, s, paths=2000)
    return res.to_dict()


def test_heat_and_hist_helpers():
    assert _heat(0, 0, 1) == "background:rgb(240,240,240)" and _heat(5, 0, 1) == "background:rgb(255,120,100)"
    assert _heat(1, 1, 1) == "background:rgb(240,240,240)"                     # degenerate range does not divide by zero
    assert _svg_hist({"counts": [0, 0], "edges": [0, 1, 2]}, 1, 2) == ""
    svg = _svg_hist({"counts": [1, 3, 2], "edges": [0, 10, 20, 30]}, 15.0, 25.0)
    assert svg.startswith("<svg") and svg.count("<rect") == 3 and "VaR99 15.0" in svg and "ES99 25.0" in svg


def test_dashboard_renders_headline_tables_and_stamp(run_dict):
    page = render_dashboard(run_dict)
    s = run_dict["summary"]; m = s["metrics"]
    assert page.startswith("<!doctype html>") and page.rstrip().endswith("</html>")
    assert s["run_id"] in page and f"{m['var99_mm']:.1f}" in page and f"{m['es99_mm']:.1f}" in page
    for r in run_dict["country"]:
        assert f"<td>{_h.escape(r['country'])}</td>" in page
    assert page.count("<tr><td>") >= len(run_dict["country"]) + len(run_dict["contributions"])
    assert _h.escape(DISCLAIMER) in page                                      # EQ-C-0009 disclaimer
    as_of = (run_dict.get("settings") or {}).get("as_of")
    assert (f"as of {as_of}" in page) if as_of else ("as of not recorded" in page)   # EQ-C-0011
    assert "Counterfactual stress" not in page and "Backtests (paper 7.3)" not in page


def test_dashboard_as_of_absent_falls_back(run_dict):
    r = copy.deepcopy(run_dict)
    r.get("settings", {}).pop("as_of", None); r["summary"].pop("as_of", None)
    for v in (r["summary"].get("versions") or {}, (r.get("provenance") or {}).get("versions") or {}):
        v.pop("as_of", None)
    assert "as of not recorded" in render_dashboard(r)


def test_dashboard_escapes_data_text(run_dict):
    """Regression: rating, regime, platform, side, ids and asset class were written into the page unescaped."""
    r = copy.deepcopy(run_dict)
    evil = "<script>alert(1)</script>"
    r["country"][0]["rating"] = evil
    if r["arbitrage"]:
        r["arbitrage"][0]["platform"] = evil; r["arbitrage"][0]["side"] = evil
    r["contributions"][0]["asset_class"] = evil
    page = render_dashboard(r)
    assert "<script>" not in page and "&lt;script&gt;alert(1)&lt;/script&gt;" in page


def test_dashboard_with_stress_and_backtest(run_dict):
    stress = {"A": {"name": "EM <sell-off>", "comparison": {
        "var99_mm": {"stress": 90.0}, "es99_mm": {"stress": 120.0, "change_pct": 40.0}, "lvar99_mm": {"stress": 95.0},
        "liquidity_cost99_mm": {"change_pct": 100.0}, "share_to_crisis": 0.25, "mean_pd_default_change_pp": 1.5}}}
    bt = {"kupiec": {"LR_uc": 4.1, "exceedances": 3, "expected": 1.2, "p_value": 0.043}, "christoffersen": {"LR_ind": 0.2, "p_value_ind": 0.6, "LR_cc": 4.3, "p_value_cc": 0.11},
          "acerbi_szekely": {"Z2": -2.66, "critical": -1.8, "pass": False}, "basel_zone": "Yellow", "verdict": "Fail"}
    page = render_dashboard(run_dict, stress=stress, backtest=bt)
    assert "Counterfactual stress" in page and "EM &lt;sell-off&gt;" in page and "+40.0%" in page and "25%" in page
    assert "Backtests (paper 7.3)" in page and "Yellow" in page and "fail" in page and "0.043" in page
