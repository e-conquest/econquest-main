"""Calendar-gated evidence monitor (EQ-B-0061): progress, earliest test date and status of the 250-day forecast record,
12-month benchmark scoring and trade-idea quarters, point in time, on synthetic fixtures."""
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.validation import evidence_monitor as EM  # noqa: E402
from econquest.validation.benchmarks import COLUMNS as BM_COLUMNS  # noqa: E402
from econquest.validation.idea_log import COLUMNS as IDEA_COLUMNS, load_log, save_log  # noqa: E402
from econquest.validation.record import COLUMNS as REC_COLUMNS  # noqa: E402


def _record(start="2026-07-30", n=60, recorded_at="backfill 2026-10-23T04:27:13+00:00", untested=0):
    dates = pd.bdate_range(start, periods=n)
    rec = pd.DataFrame({c: np.nan for c in REC_COLUMNS}, index=range(n))
    rec["date"] = dates; rec["loss"] = 0.1; rec["var"] = 1.0; rec["es"] = 1.3; rec["recorded_at"] = recorded_at
    if untested:
        rec.loc[: untested - 1, "var"] = np.nan          # no forecast for the first rows: not tested
    return rec


def _history(dates=("2026-10-23",), isos=("ARG", "BRA", "TUR"), in_default=False):
    rows = [{c: np.nan for c in BM_COLUMNS} | {"date": d, "iso": i, "country": i, "rating": "B", "in_default": in_default,
                                              "pd_model": 0.05} for d in dates for i in isos]
    return pd.DataFrame(rows, columns=BM_COLUMNS)


EVENTS = pd.DataFrame({"iso": ["ARG"], "country": ["Argentina"], "start": [2001], "end": [2005]})


def _ideas(first="2026-10-23", mark="2026-10-23", n=3, closed=0, as_of=None):
    rows = []
    for k in range(n):
        r = {c: np.nan for c in IDEA_COLUMNS}
        r.update({"idea_id": f"T{k:02d}-X-{first.replace('-', '')}", "as_of": as_of or first, "markable": k == 0,
                  "status": "closed" if k < closed else "open", "mark_date": mark if k == 0 else np.nan,
                  "close_date": mark if k < closed else np.nan})
        rows.append(r)
    return pd.DataFrame(rows, columns=IDEA_COLUMNS)


# --- forecast record ---------------------------------------------------------------------------------------------
def test_record_accumulating_projects_by_weekdays():
    r = EM.record_progress(_record(n=60), "2026-10-24")
    assert (r["progress"], r["required"], r["status"]) == (60, 250, "accumulating")
    assert r["first_obs"] == "2026-07-30" and r["last_obs"] == "2026-10-21"
    assert r["earliest_test_date"] == "2027-07-14"              # 2026-10-21 + 190 weekdays
    assert r["progress_pct"] == 24.0 and r["lag_days"] == 3


def test_record_testable_on_the_250th_tested_day():
    rec = _record(start="2026-01-01", n=260, recorded_at="2026-12-31T00:00:00+00:00", untested=1)
    r = EM.record_progress(rec, "2027-01-15")
    assert r["status"] == "testable" and r["progress"] == 259
    assert r["earliest_test_date"] == pd.bdate_range("2026-01-01", periods=260)[250].strftime("%Y-%m-%d")


def test_record_overdue_when_it_stops():
    r = EM.record_progress(_record(start="2026-01-01", n=100, recorded_at="2026-05-20T00:00:00+00:00"), "2027-06-01")
    assert r["status"] == "overdue" and r["days_to_test"] < 0


def test_record_is_point_in_time():
    rec = _record(n=60)                                         # backfilled on 2026-10-23
    assert EM.record_progress(rec, "2026-10-22")["progress"] == 0     # not yet recorded on 2026-10-22
    daily = _record(n=60, recorded_at="")                       # no recorded_at: dated rows only
    assert EM.record_progress(daily, "2026-08-12")["progress"] == len(pd.bdate_range("2026-07-30", "2026-08-12"))


# --- benchmarks --------------------------------------------------------------------------------------------------
def test_benchmark_first_maturity_gates_status():
    h = _history()
    a = EM.benchmark_progress(h, EVENTS, "2027-10-22")
    b = EM.benchmark_progress(h, EVENTS, "2027-10-23")
    assert a["status"] == "accumulating" and a["earliest_test_date"] == "2027-10-23" and a["days_to_test"] == 1
    assert b["status"] == "testable" and b["progress"] == b["required"] == 365
    assert "3 matured" in b["note"]


def test_benchmark_rows_in_default_are_not_eligible():
    r = EM.benchmark_progress(_history(in_default=True), EVENTS, "2028-01-01")
    assert r["status"] == "accumulating" and r["progress"] == 0 and "default spell" in r["note"]
    later = _history(dates=("2026-10-23", "2026-12-01"))
    assert EM.benchmark_progress(later, EVENTS, "2026-11-01")["note"].startswith("3 snapshot rows on 1 date")


def test_benchmark_without_history():
    r = EM.benchmark_progress(None, None, "2026-10-24")
    assert r["status"] == "accumulating" and r["earliest_test_date"] == "2027-10-24" and r["first_obs"] == ""


# --- trade ideas -------------------------------------------------------------------------------------------------
def test_ideas_need_four_quarters_of_marks():
    a = EM.idea_progress(_ideas(mark="2027-04-23"), "2027-04-23")
    assert a["status"] == "accumulating" and a["earliest_test_date"] == "2027-10-23" and "2 of 4 quarters" in a["note"]
    b = EM.idea_progress(_ideas(mark="2027-10-25", closed=1), "2027-10-25")
    assert b["status"] == "testable" and "1 closed and marked" in b["note"]


def test_ideas_overdue_when_marks_stop_and_point_in_time():
    assert EM.idea_progress(_ideas(mark="2027-03-01"), "2027-11-01")["status"] == "overdue"
    future = EM.idea_progress(_ideas(mark="2027-12-31"), "2027-01-23")          # a mark dated after as_of is ignored
    assert future["last_obs"] == "" and future["progress"] == 0 and future["status"] == "accumulating"
    replay = EM.idea_progress(_ideas(mark="2027-12-31"), "2027-11-01")          # replay: no mark by as_of -> overdue,
    assert replay["status"] == "overdue" and replay["last_obs"] == ""         # not hidden by the later mark
    later = EM.idea_progress(_ideas(first="2026-11-02"), "2026-10-24")          # ideas opened after as_of are ignored
    assert later["progress"] == 0 and later["first_obs"] == "" and "no idea logged" in later["note"]


# --- table, markdown, files --------------------------------------------------------------------------------------
def test_table_shape_markdown_and_determinism():
    args = (_record(), _history(), EVENTS, _ideas())
    t = EM.evidence_table(*args, as_of="2026-10-24")
    assert list(t.columns) == EM.COLUMNS and len(t) == 3 and set(t["status"]) <= set(EM.STATUSES)
    assert list(t["evidence"]) == ["var_record_250d", "benchmark_12m", "idea_quarters_4q"]
    pd.testing.assert_frame_equal(t, EM.evidence_table(*args, as_of="2026-10-24"))
    md = EM.monitor_markdown(t)
    assert md.startswith("## Calendar-gated evidence, as of 2026-10-24") and md.count("\n| ") == 4
    with pytest.raises(ValueError, match="as_of is required"):
        EM.evidence_table(*args, as_of=None)


def test_evidence_monitor_reads_stored_files(tmp_path):
    data, out = tmp_path / "data", tmp_path / "outputs"
    (data / "panel").mkdir(parents=True); out.mkdir()
    rec = _record(); rec["date"] = rec["date"].dt.strftime("%Y-%m-%d"); rec.to_csv(data / "forecast_record.csv", index=False)
    _history().to_csv(data / "benchmarks.csv", index=False)
    EVENTS.to_csv(data / "panel" / "sovereign_defaults.csv", index=False)
    save_log(_ideas(), out / "idea_log.csv")
    t = EM.evidence_monitor("2026-10-24", data, out)
    ref = EM.evidence_table(_record(), _history(), EVENTS, load_log(out / "idea_log.csv"), "2026-10-24")
    pd.testing.assert_frame_equal(t.reset_index(drop=True), ref.reset_index(drop=True), check_dtype=False)
    csv, md = EM.write_monitor(t, out)
    assert pd.read_csv(csv).shape == (3, len(EM.COLUMNS)) and "var_record_250d" in md.read_text()
    empty = EM.evidence_monitor("2026-10-24", tmp_path / "none", tmp_path / "none")
    assert (empty["progress"] == 0).all() and (empty["status"] == "accumulating").all()
