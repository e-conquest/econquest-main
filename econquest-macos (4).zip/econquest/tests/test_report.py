"""Daily report: input caveats, disclaimer and as-of stamping (EQ-C-0009, EQ-C-0011), on synthetic runs and small
synthetic data folders so the expectations do not depend on the live data vintage."""
import html as _h
import json
import shutil
import sys
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.presentation import report as R  # noqa: E402

SEED = ROOT / "tests" / "seed_data"


def make_run(run_id="20261020T090000-base", created="2026-10-20T09:00:00+00:00", as_of="2026-10-20", pd_b=0.05, regime_b="Calm",
             sig_b=50.0, var99=60.0, markets="csv:prediction_markets.csv", l1mode="paper_standardized"):
    m = {"paths": 2000, "var95_mm": 30.0, "var99_mm": var99, "es95_mm": 45.0, "es99_mm": var99 * 1.3, "es975_frtb_mm": var99 * 1.1, "lvar99_mm": var99 + 3,
         "les99_mm": var99 * 1.3 + 3, "expected_loss_mm": 1.5, "gross_notional_mm": 300.0, "net_notional_mm": 200.0, "liquidity_cost99_mm": 3.0,
         "es99_share_of_gross": 0.26, "p_loss_above_10pct_gross": 0.08}
    versions = {"code_version": "0.1.0", "code_hash": "c0de", "data_hash": "da7a"}
    settings = {"layer1": {"mode": l1mode}, "signals": {"threshold": 60}}
    if as_of:
        settings["as_of"] = as_of
        versions = {**versions, "as_of": as_of, "run_hash": "ru11"}
    country = [{"country": c, "rating": "B", "composite": 50.0 + i, "grade": 3, "regime": rg, "pd_default": p, "pd_market": p, "pd_tc": 0.01, "pd_ex": 0.01,
                "pd_pv": 0.01, "pd_sa": 0.0, "pd_any": p + 0.03, "DD": 2.0}
               for i, (c, rg, p) in enumerate((("A", "Calm", 0.01), ("B", regime_b, pd_b), ("C", "Stressed", 0.08)))]
    contrib = [{"id": f"P{i}", "country": c, "asset_class": "Eurobond", "notional_mm": 10.0, "expected_loss_mm": 0.1 * i, "tail_contribution_99_mm": 5.0 - i,
                "share_of_es99": 0.1, "liquidity_cost_99_mm": 0.2} for i, c in enumerate("ABC")]
    return {"summary": {"run_id": run_id, "label": "base", "created_at": created, "metrics": m, "global_regime": "Calm",
                        "regimes": {"Calm": 1 + (regime_b == "Calm"), "Stressed": 1 + (regime_b == "Stressed"), "Crisis": int(regime_b == "Crisis")}, "versions": versions},
            "settings": settings, "provenance": {"markets": markets, "versions": versions},
            "country": country, "contributions": contrib,
            "positions": [{"id": f"P{i}", "direction": "Long", "regime": "Calm", "pd_default": 0.01, "duration_yrs": 5} for i in range(3)],
            "loss_histogram": {"counts": [5, 3, 1], "edges": [0, 20, 40, 60]}, "diagnostics": {"degrees_of_freedom": 5, "global_regime": "Calm"},
            "signals": [{"key": 1, "A": 10.0, "B": sig_b, "C": 0.0}],
            "activation": [{"trade": "T01", "A": None, "B": 70.0 if sig_b >= 60 else None, "C": None}]}


def make_data(d: Path, audit=True, provenance=True, pm_cols=("id", "country", "yes_price"), backtest_source=None, record_rows=10, cds_rows=0,
              retrieved="2026-10-01", indicator_name="Debt service"):
    d.mkdir(parents=True, exist_ok=True)
    shutil.copy(SEED / "assumptions.json", d / "assumptions.json")
    pd.DataFrame({"id": ["1.1", "1.2"], "pillar": [1, 1], "indicator": [indicator_name, "Reserves"], "unit": ["%", "%"], "A": [10.0, 20.0], "B": [30.0, 40.0]}).to_csv(d / "indicators.csv", index=False)
    pd.DataFrame({"country": ["A", "B"], "rating": ["B", "CCC"], "spread": [400, 900], "pop": [1, 2]}).to_csv(d / "countries.csv", index=False)
    if audit:
        pd.DataFrame([
            {"table": "Inputs", "key": "1.1", "country": "A", "value": 10.0, "origin": "live feed", "source": "imf", "retrieved": retrieved},
            {"table": "Inputs", "key": "1.1", "country": "B", "value": 30.0, "origin": "seed estimate", "source": "seed", "retrieved": None},
            {"table": "Inputs", "key": "1.2", "country": "A", "value": 19.0, "origin": "live feed", "source": "imf", "retrieved": retrieved},   # value changed since
        ]).to_csv(d / "audit_trail.csv", index=False)                                                                                       # (1.2, B) absent
    if provenance:
        (d / "live").mkdir(exist_ok=True)
        pd.DataFrame([{"table": "Inputs", "key": "1.1", "country": "A", "value": 10.0, "source": "imf", "series": "x", "retrieved": retrieved},
                      {"table": "Inputs", "key": "1.1", "country": "B", "value": 30.0, "source": "imf", "series": "x", "retrieved": retrieved},
                      {"table": "Inputs", "key": "1.2", "country": "A", "value": 99.0, "source": "imf", "series": "x", "retrieved": retrieved}]).to_csv(d / "live" / "provenance.csv", index=False)
        pd.DataFrame([{"table": "Inputs", "key": "1.1", "country": "A", "seed": 9.0, "live": 10.0, "status": "ok", "reason": "", "decision": ""},
                      {"table": "Inputs", "key": "1.1", "country": "B", "seed": 30.0, "live": 31.0, "status": "hold", "reason": "jump", "decision": ""},
                      {"table": "Inputs", "key": "1.2", "country": "B", "seed": 40.0, "live": None, "status": "missing", "reason": "", "decision": ""}]).to_csv(d / "live" / "review.csv", index=False)
    pm = {"id": ["PM01", "PM02"], "country": ["A", "B"], "yes_price": [0.2, 0.3], "slug": ["a", "b"], "ticker": ["x", "y"]}
    pd.DataFrame({k: v for k, v in pm.items() if k in pm_cols}).to_csv(d / "prediction_markets.csv", index=False)
    bh = pd.DataFrame({"period": [1, 2, 3], "date": ["2026-01-01", "2026-02-01", "2026-03-01"], "loss": [1.0, 2.0, 0.5], "var": 3.0, "es": 4.0})
    if backtest_source:
        bh["source"] = backtest_source
    bh.to_csv(d / "backtest_history.csv", index=False)
    if record_rows:
        dates = pd.bdate_range("2026-01-05", periods=record_rows)
        pd.DataFrame({"date": dates, "loss": 0.2, "var": 1.0, "es": 1.3, "var_next": 1.0, "es_next": 1.3}).to_csv(d / "forecast_record.csv", index=False)
    pd.DataFrame({"country": ["A"] * cds_rows, "tenor": [5] * cds_rows, "spread_bps": [300] * cds_rows}).to_csv(d / "cds_quotes.csv", index=False)
    return d


def keys(cav):
    return [i["key"] for i in cav["items"]]


# ---------------------------------------------------------------- input_caveats
def test_caveats_from_audit_trail(tmp_path):
    cav = R.input_caveats(make_data(tmp_path / "d"), make_run())
    assert cav["cells"] == {"live": 1, "seed": 1, "unverified": 2, "total": 4}
    assert "audit_trail" in cav["source"]
    bc = {r["country"]: r for r in cav["by_country"]}
    assert bc["A"] == {"country": "A", "seed": 0, "unverified": 1, "live": 1, "total": 2} and bc["B"]["seed"] == 1 and bc["B"]["unverified"] == 1
    assert cav["by_country"][0]["country"] == "B"                                  # most not-live first
    bi = {r["id"]: r for r in cav["by_indicator"]}
    assert bi["1.1"]["countries"] == ["B"] and not bi["1.1"]["all"] and bi["1.2"]["all"] and bi["1.2"]["n_not_live"] == 2
    k = keys(cav)
    for want in ("seed_inputs", "hand_entered_profile", "quality_holds", "feed_missing", "paper_mode", "pm_placeholders", "synthetic_backtest", "record_underpowered", "no_cds_quotes"):
        assert want in k, want
    restr = {i["key"]: i["restriction"] for i in cav["items"]}
    assert restr["paper_mode"] == "6.1" and restr["pm_placeholders"] == "6.2" and restr["synthetic_backtest"] == "6.3" and restr["record_underpowered"] == "6.4"
    seed_text = next(i["text"] for i in cav["items"] if i["key"] == "seed_inputs")
    assert "3 of 4" in seed_text and "unverified" in seed_text
    assert "rating, spread" in next(i["text"] for i in cav["items"] if i["key"] == "hand_entered_profile")


def test_caveats_fallback_to_provenance_and_review(tmp_path):
    cav = R.input_caveats(make_data(tmp_path / "d", audit=False), make_run())
    # (1.1, A) live and applied; (1.1, B) held by the gate -> seed; (1.2, A) provenance value not applied -> seed
    assert cav["cells"] == {"live": 1, "seed": 3, "unverified": 0, "total": 4} and "provenance" in cav["source"]


def test_caveats_without_any_live_pull(tmp_path):
    cav = R.input_caveats(make_data(tmp_path / "d", audit=False, provenance=False), None)
    assert cav["cells"]["seed"] == 4 and cav["cells"]["live"] == 0 and "indicators.csv only" in cav["source"]
    assert "quality_holds" not in keys(cav) and "paper_mode" in keys(cav)             # mode read from assumptions.json when no run


def test_caveats_clear_when_inputs_are_marked_real(tmp_path):
    d = make_data(tmp_path / "d", pm_cols=("id", "country", "yes_price", "slug", "ticker"), backtest_source="desk P&L", record_rows=260, cds_rows=2)
    k = keys(R.input_caveats(d, make_run(l1mode="fitted")))
    for gone in ("pm_placeholders", "synthetic_backtest", "record_underpowered", "no_cds_quotes", "paper_mode"):
        assert gone not in k, gone
    # live markets in the run's provenance also clear the placeholder caveat even without slug/ticker columns
    d2 = make_data(tmp_path / "d2")
    assert "pm_placeholders" not in keys(R.input_caveats(d2, make_run(markets="polymarket gamma api; kalshi api")))
    # a source column that still says synthetic keeps the backtest caveat
    d3 = make_data(tmp_path / "d3", backtest_source="synthetic draw")
    assert "synthetic_backtest" in keys(R.input_caveats(d3, make_run()))


def test_caveat_blocks_escape_and_mark_seed(tmp_path):
    cav = R.input_caveats(make_data(tmp_path / "d", indicator_name="<b>Debt</b> & service"), make_run())
    html = R.caveats_html(cav)
    assert "<b>Debt</b>" not in html and "&lt;b&gt;Debt&lt;/b&gt; &amp; service" in html
    assert "SEED for every country" in html and "[restriction 6.2]" in html           # text markers, not colour only
    md = "\n".join(R.caveats_md(cav))
    assert "| Country | Seed | Unverified | Live |" in md and "1.2 Reserves" in md
    assert "No seed" in R.caveats_html({"items": []}) and R.caveats_md(None)[0].startswith("No seed")


# ---------------------------------------------------------------- as_of
def test_run_as_of_sources_and_fallback():
    assert R.run_as_of(make_run(as_of="2026-10-20")) == "2026-10-20"
    r = make_run(as_of=None)
    assert R.run_as_of(r) is None and R.run_hash_of(r) is None                     # never today()
    r["summary"]["as_of"] = "2026-10-19"; assert R.run_as_of(r) == "2026-10-19"
    r2 = make_run(as_of=None); r2["provenance"]["versions"] = {"as_of": "2026-10-18T00:00:00", "run_hash": "h"}
    assert R.run_as_of(r2) == "2026-10-18" and R.run_hash_of(r2) == "h"
    r3 = make_run(as_of="2026-10-20"); r3["summary"]["versions"]["as_of"] = "1999-01-01"
    assert R.run_as_of(r3) == "2026-10-20"                                         # settings.as_of wins
    assert R.run_as_of(None) is None and R.run_as_of(r3["summary"]) == "1999-01-01"


# ---------------------------------------------------------------- build_report
def test_report_shows_as_of_caveats_and_disclaimer(tmp_path):
    d = make_data(tmp_path / "d")
    r = R.build_report(d, tmp_path / "out", run=make_run(), alerts=[], log=lambda *a: None)
    html = Path(r["html"]).read_text(encoding="utf-8"); md = Path(r["md"]).read_text(encoding="utf-8")
    assert r["as_of"] == "2026-10-20"
    assert "<span><b>Run</b> 20261020T090000-base</span><span><b>As of</b> 2026-10-20</span>" in html   # as_of next to run_id
    assert "<b>Run hash</b> ru11" in html
    assert html.count(_h.escape(R.DISCLAIMER)) == 2 and R.DISCLAIMER.startswith("Internal research, not investment advice")
    assert "<h2>Input caveats</h2>" in html and html.index("<h2>Input caveats</h2>") < html.index("<h2>Changes since the previous run</h2>")
    assert "generation timestamp, not a model date" in html
    assert "## Input caveats" in md and md.count(R.DISCLAIMER) == 2 and "as of 2026-10-20" in md
    assert "<script" not in html and "<link" not in html


def test_report_without_as_of_says_not_recorded(tmp_path):
    d = make_data(tmp_path / "d")
    r = R.build_report(d, tmp_path / "out", run=make_run(as_of=None), alerts=[], log=lambda *a: None)
    html = Path(r["html"]).read_text(encoding="utf-8")
    assert r["as_of"] is None and "<b>As of</b> not recorded" in html and "Run hash" not in html
    assert "as of not recorded" in Path(r["md"]).read_text(encoding="utf-8")


def test_stale_inputs_judged_at_as_of_not_wall_clock(tmp_path):
    """Live cells retrieved 2026-10-01: stale (> 45 days) for a run created 2026-12-31 without an as-of date, fresh for a
    run whose as-of date is 2026-10-20 even though it was created on 2026-12-31."""
    d = make_data(tmp_path / "d", retrieved="2026-10-01")
    late = "2026-12-31T09:00:00+00:00"
    fresh = Path(R.build_report(d, tmp_path / "o1", run=make_run(created=late, as_of="2026-10-20"), alerts=[], log=lambda *a: None)["html"]).read_text()
    stale = Path(R.build_report(d, tmp_path / "o2", run=make_run(created=late, as_of=None), alerts=[], log=lambda *a: None)["html"]).read_text()
    assert "No stale live input." in fresh
    assert "live cells are stale" in stale


def test_report_detects_alerts_against_previous_archived_run(tmp_path):
    from econquest.persistence import Store
    d = make_data(tmp_path / "d"); out = tmp_path / "out"
    store = Store(out / "store")
    prev = make_run(run_id="r-prev", created="2026-10-13T09:00:00+00:00", as_of="2026-10-13")
    with store._conn() as c:                                                    # archive a synthetic run the way save_run does
        c.execute("INSERT INTO runs VALUES (?,?,?,?,?,?)", (prev["summary"]["run_id"], prev["summary"]["created_at"], "base", "{}", "{}", json.dumps(prev["summary"])))
    (store.archive / "r-prev.json").write_text(json.dumps(prev))
    cur = make_run(regime_b="Crisis", pd_b=0.30, sig_b=75.0)
    r = R.build_report(d, out, run=cur, log=lambda *a: None)
    assert r["previous_run_id"] == "r-prev"
    kinds = {a["kind"] for a in r["alerts"]}
    assert {"regime_flip", "pd_change", "signal_cross", "trade_activation"} <= kinds
    html = Path(r["html"]).read_text()
    assert "B: regime Calm -&gt; Crisis" in html and "Compared with run r-prev" in html


def test_formatting_helpers():
    assert R._f(1234.567) == "1,234.6" and R._f(None) == "" and R._f(float("nan")) == "" and R._f("x") == ""
    assert R._pct(0.12345) == "12.35%" and R._pct(float("inf")) == "" and R._pct(None) == ""
    assert R._e("<a & b>") == "&lt;a &amp; b&gt;" and R._e(None) == ""
    assert R._svg_hist({}, 1, 2) == "" and R._svg_bars([]) == "" and "<svg" in R._svg_bars([("x", 1.0), ("y", -2.0)])
