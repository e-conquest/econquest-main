"""Layer 6 Monte Carlo: characterisation pins and properties (EQ-B-0003, EQ-B-0007).

The simulation is run on frozen inputs (`tests/fixtures/layer6_inputs.json`: positions, factor loadings,
degrees of freedom and regimes captured from the pipeline on `tests/seed_data` with the seed assumptions on
2026-10-23), so the pins characterise layer 6 alone and do not move when layers 1 to 5 change.
Regenerate the fixture only on purpose, and record the old and new pins in
`docs/validation/copula-montecarlo-layers5-6.md`.
"""
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.config import Settings
from econquest.engine import layer6_montecarlo as L6
from scipy.stats import qmc

FIXTURE = ROOT / "tests" / "fixtures" / "layer6_inputs.json"
SEED = ROOT / "tests" / "seed_data"
KEYS = ("var95_mm", "var99_mm", "es95_mm", "es99_mm", "es975_frtb_mm", "expected_loss_mm", "lvar99_mm")
RTOL = 1e-9   # same code, same seed, same numpy/scipy: only float summation order can differ


@pytest.fixture(scope="module")
def inputs():
    fx = json.loads(FIXTURE.read_text())
    names = fx["names"]
    u = SimpleNamespace(names=names, countries=pd.DataFrame({"country": names, "region": fx["regions"]}))
    country = pd.DataFrame({"regime": pd.Series(fx["regime"])}).reindex(names)
    loadings = pd.DataFrame(fx["loadings"]).set_index("index").reindex(names)
    positions = pd.DataFrame(fx["positions"]).set_index("id")
    settings = Settings.load(SEED / "assumptions.json")
    return SimpleNamespace(u=u, country=country, positions=positions, loadings=loadings, df=fx["df"], settings=settings)


def _run(inp, paths=None, seed=None, settings=None):
    return L6.simulate(inp.u, inp.country, inp.positions, inp.loadings, settings or inp.settings, inp.df, paths=paths, seed=seed)


# Pinned on 2026-10-23. History (see the validation document for the full before/after table):
# 2026-10-23 EQ-B-0003, before EQ-B-0007 (2^m Sobol draw truncated to the first n points):
PINS_TRUNCATED = {
    20_000: {"paths": 20_000, "var95_mm": 39.94135320694226, "var99_mm": 68.12362133514404, "es95_mm": 57.94477105866816,
             "es99_mm": 88.58971291133173, "es975_frtb_mm": 70.82953544845444, "expected_loss_mm": 2.0399791430166827,
             "lvar99_mm": 73.40512716185638},
    None: {"paths": 100_000, "var95_mm": 40.27955945334553, "var99_mm": 67.7788042189635, "es95_mm": 57.61589688939622,
           "es99_mm": 86.9665017850584, "es975_frtb_mm": 69.84646208127316, "expected_loss_mm": 2.0285187141556342,
           "lvar99_mm": 73.06031004567585},
}
# 2026-10-23 EQ-B-0007, after: the Sobol branch rounds the request up to 2^m and keeps every point
# (20,000 -> 32,768; 100,000 -> 131,072). Moves at 100k/seed 7: VaR99 +0.12%, ES99 -0.14%, EL +0.08%, all inside
# the seed-to-seed error (VaR99 sd 0.53% over ten seeds).
PINS_BALANCED = {
    20_000: {"paths": 32_768, "var95_mm": 40.203321277568605, "var99_mm": 67.9180492640979, "es95_mm": 57.69894823490072,
             "es99_mm": 87.52470211533998, "es975_frtb_mm": 70.22318862794653, "expected_loss_mm": 2.0358789258717898,
             "lvar99_mm": 73.19955509081025},
    None: {"paths": 131_072, "var95_mm": 40.33244681623905, "var99_mm": 67.86119230435622, "es95_mm": 57.649286009655754,
           "es99_mm": 86.84366588613571, "es975_frtb_mm": 69.86105112281088, "expected_loss_mm": 2.0301354185338076,
           "lvar99_mm": 73.14269813106857},
}
PINS = PINS_BALANCED


@pytest.mark.parametrize("paths", list(PINS))
def test_characterisation_pins(inputs, paths):
    m = _run(inputs, paths=paths).metrics
    pin = PINS[paths]
    for k in KEYS:
        assert m[k] == pytest.approx(pin[k], rel=RTOL), (paths, k, m[k], pin[k])
    assert m["paths"] == pin["paths"]
    assert m["paths_requested"] == (paths or inputs.settings.paths)


def test_default_settings_are_the_production_ones(inputs):
    assert inputs.settings.paths == 100_000 and inputs.settings.seed == 7 and inputs.settings.use_sobol is True


@pytest.mark.parametrize("seed", [7, 11])
def test_risk_measure_ordering(inputs, seed):
    r = _run(inputs, paths=4096, seed=seed)
    m = r.metrics
    assert m["expected_loss_mm"] >= 0
    assert m["var95_mm"] <= m["var99_mm"]
    assert m["es95_mm"] >= m["var95_mm"] and m["es99_mm"] >= m["var99_mm"] and m["es975_frtb_mm"] >= m["var95_mm"]
    assert m["es99_mm"] >= m["es975_frtb_mm"] >= m["es95_mm"]
    assert m["lvar99_mm"] >= m["var99_mm"] and m["les99_mm"] >= m["es99_mm"]
    assert np.isclose(r.losses.mean(), m["expected_loss_mm"])
    assert np.allclose(r.position_losses.sum(axis=1), r.losses)
    assert np.isclose(r.contributions["share_of_es99"].sum(), 1.0)
    assert r.losses.shape == (m["paths"],) and r.position_losses.shape == (m["paths"], len(inputs.positions))
    # long positions cannot lose more than their notional
    longs = (inputs.positions["sign"] > 0).to_numpy()
    assert np.all(r.position_losses[:, longs] <= inputs.positions["notional_mm"].to_numpy()[longs] + 1e-12)


def test_determinism_same_seed(inputs):
    a, b = _run(inputs, paths=4096, seed=7), _run(inputs, paths=4096, seed=7)
    assert np.array_equal(a.losses, b.losses)
    assert a.metrics == b.metrics
    c = _run(inputs, paths=4096, seed=8)
    assert not np.array_equal(a.losses, c.losses)


def test_pseudo_random_branch_is_seeded(inputs):
    s = inputs.settings.copy_with()
    s.use_sobol = False
    a, b = _run(inputs, paths=4096, seed=3, settings=s), _run(inputs, paths=4096, seed=3, settings=s)
    assert np.array_equal(a.losses, b.losses)
    assert a.metrics["paths"] == 4096 and a.metrics["paths_requested"] == 4096
    assert a.metrics["es99_mm"] >= a.metrics["var99_mm"]


@pytest.mark.parametrize("n, expected", [(1, 2), (2, 2), (3, 4), (4096, 4096), (4097, 8192), (20_000, 32_768), (100_000, 131_072), (131_072, 131_072)])
def test_sobol_path_count(n, expected):
    assert L6.sobol_path_count(n) == expected


def test_sobol_draw_is_a_full_balanced_block():
    """Regression for EQ-B-0007: the old code drew 2^17 points and kept the first 100,000, losing the balance of
    a scrambled Sobol block. Every draw must now be a whole 2^m block: each of the 2^k equal bins of every
    one-dimensional margin (k <= m) holds exactly 2^(m-k) points."""
    U = L6._draw_uniforms(4096, 71, 7, True)
    assert U.shape == (4096, 71)
    for k in (1, 6, 12):
        counts = np.apply_along_axis(lambda c, k=k: np.bincount((c * 2 ** k).astype(int), minlength=2 ** k), 0, U)
        assert np.all(counts == 4096 // 2 ** k), k
    assert np.array_equal(U, qmc.Sobol(d=71, scramble=True, seed=7).random_base2(12))
    with pytest.raises(ValueError):
        L6._draw_uniforms(100_000, 71, 7, True)


def test_simulate_reports_rounded_paths(inputs):
    r = _run(inputs, paths=3000, seed=7)
    assert r.paths == r.metrics["paths"] == 4096 and r.metrics["paths_requested"] == 3000 and r.losses.shape == (4096,)
    s = inputs.settings.copy_with(); s.use_sobol = False
    r = _run(inputs, paths=3000, seed=7, settings=s)
    assert r.metrics["paths"] == r.metrics["paths_requested"] == 3000


# --- EQ-B-0035: monte_carlo.vol_source ("regime" default, "garch" opt-in) -----------------------------------------
def _pipeline(patch=None, paths=2000):
    from econquest.engine.pipeline import run_pipeline
    from econquest.ingestion import load_universe
    u = load_universe(ROOT / "data")
    s = Settings.load(ROOT / "data" / "assumptions.json")
    return u, s, run_pipeline(u, s.copy_with(**(patch or {})), paths=paths, as_of="2026-10-23")


def test_vol_source_default_is_regime_and_bit_identical():
    # shipped "garch" since CHG-20261023T190523Z-b96d25; the code default without the key is still "regime"
    shipped = Settings.load(ROOT / "data" / "assumptions.json")
    assert shipped.get("monte_carlo", "vol_source") == "garch"
    u, s, base = _pipeline({"monte_carlo": {k: v for k, v in shipped["monte_carlo"].items() if k != "vol_source"}})
    assert L6.vol_source(s.copy_with(**{"monte_carlo": {k: v for k, v in shipped["monte_carlo"].items() if k != "vol_source"}})) == "regime"
    _, _, explicit = _pipeline({"monte_carlo.vol_source": "regime"})
    assert np.array_equal(base.mc.losses, explicit.mc.losses)
    assert "vol_from" not in base.positions.columns and "garch_vols" not in base.positions.attrs
    with pytest.raises(ValueError, match="vol_source"):
        _pipeline({"monte_carlo.vol_source": "Garch-ish"})


def test_vol_source_garch_replaces_fx_and_equity_vols_only():
    from econquest.engine import garch as G
    u, s, base = _pipeline()
    _, _, g = _pipeline({"monte_carlo.vol_source": "garch"})
    tab = pd.DataFrame(g.positions.attrs["garch_vols"]).set_index(["country", "kind"])
    P, B = g.positions, base.positions
    mk = s["market"]
    for pid, p in P.iterrows():
        ac, c = p["asset_class"], p["country"]
        if ac in ("Eurobond", "CDS protection"):
            assert p["market_vol_pct"] == B.at[pid, "market_vol_pct"] and p["vol_from"] == "regime"
            continue
        row = tab.loc[(c, "Equity" if ac == "Equity" else "FX")]
        if not np.isfinite(row["vol_pct"]):
            assert p["market_vol_pct"] == B.at[pid, "market_vol_pct"] and p["vol_from"].startswith("regime (")
        elif ac == "FX":
            assert p["market_vol_pct"] == pytest.approx(min(row["vol_pct"], mk["vol_cap"]), rel=1e-12)
        elif ac == "Local bond":
            assert p["market_vol_pct"] == pytest.approx(min(p["duration_yrs"] * mk["local_rate_vol"] + row["vol_pct"], mk["vol_cap"]), rel=1e-12)
        else:
            assert p["market_vol_pct"] == pytest.approx(min(row["vol_pct"], mk["vol_cap"]), rel=1e-12)
    # GOV-034: administered quotes and near-unit persistence keep the regime vol
    assert P.loc[P["country"] == "Nigeria", "vol_from"].eq("regime").sum() == 1                 # the Eurobond
    assert "administered" in P.loc["P19", "vol_from"]
    assert all(r >= G.MC_PERSISTENCE_MAX for r in tab.loc[tab["reason"].str.startswith("persistence"), "persistence"])
    # PDs do not move: the setting changes the market move only
    assert np.array_equal(g.country["pd_default"].to_numpy(), base.country["pd_default"].to_numpy())


def test_vol_source_garch_keeps_stress_shocks_as_ratios():
    # a stress scenario's patch to the market vols scales the GARCH vol by stressed / unstressed value; the scenario
    # records the unstressed values as the anchor (EQ-B-0047; before, the anchor was hard-coded)
    from econquest.engine import stress as ST
    from econquest.engine.pipeline import run_pipeline
    u, s, g = _pipeline({"monte_carlo.vol_source": "garch"})
    sg = s.copy_with(**{"monte_carlo.vol_source": "garch"})
    u2, s2 = ST.apply_shocks(u, sg, [{"target": "settings", "key": "market.fx_vol.Float", "op": "mul", "value": 2.0},
                                     {"target": "settings", "key": "market.equity_vol", "op": "set", "value": 50.0}])
    assert s2["monte_carlo"]["garch_vol"]["anchor"] == {"fx_vol": sg["market"]["fx_vol"], "equity_vol": sg["market"]["equity_vol"]}
    g2 = run_pipeline(u2, s2, paths=2000, as_of="2026-10-23")
    for pid in ("P02", "P13"):                                   # floating FX, GARCH-sourced
        assert g.positions.at[pid, "vol_from"].startswith("garch:")
        assert g2.positions.at[pid, "market_vol_pct"] == pytest.approx(2 * g.positions.at[pid, "market_vol_pct"], rel=1e-12)
    assert g2.positions.at["P07", "market_vol_pct"] == pytest.approx(min(60.0, 50.0 / sg["market"]["equity_vol"] * g.positions.at["P07", "market_vol_pct"]), rel=1e-12)


def test_garch_anchor_follows_governed_market_vols():
    # EQ-B-0047 regression: a governed (non-scenario) change to market.fx_vol / equity_vol must not rescale the
    # GARCH vols; with the old hard-coded anchor (Float 12, equity 25) this run's vols were scaled by 15/12 and 30/25
    _, _, g = _pipeline({"monte_carlo.vol_source": "garch"})
    _, s3, g3 = _pipeline({"monte_carlo.vol_source": "garch", "market.fx_vol.Float": 15.0, "market.equity_vol": 30.0})
    assert L6.garch_anchor(s3.copy_with(**{"market.fx_vol.Float": 15.0}))["fx_vol"]["Float"] == 15.0
    for pid in ("P02", "P13", "P07"):
        assert g.positions.at[pid, "vol_from"].startswith("garch:")
        assert g3.positions.at[pid, "market_vol_pct"] == g.positions.at[pid, "market_vol_pct"], pid
    # a scenario applied on top of the governed change scales relative to it, and an anchor in the settings still wins
    from econquest.engine import stress as ST
    from econquest.ingestion import load_universe
    u = load_universe(ROOT / "data")
    s_gov = s3.copy_with(**{"monte_carlo.vol_source": "garch", "market.fx_vol.Float": 15.0})
    _, s5 = ST.apply_shocks(u, s_gov, [{"target": "settings", "key": "market.fx_vol.Float", "op": "mul", "value": 2.0}])
    assert s5["monte_carlo"]["garch_vol"]["anchor"]["fx_vol"]["Float"] == 15.0 and s5["market"]["fx_vol"]["Float"] == 30.0
    _, s_none = ST.apply_shocks(u, s_gov, [{"target": "settings", "key": "market.lgd_hard", "op": "add", "value": 1.0}])
    assert s_none.get("monte_carlo", "garch_vol", "anchor", default=None) is None     # no vol patch, no anchor recorded
    fixed = s_gov.copy_with(**{"monte_carlo.garch_vol.anchor": {"fx_vol": {"Float": 10.0}, "equity_vol": 20.0}})
    _, s6 = ST.apply_shocks(u, fixed, [{"target": "settings", "key": "market.equity_vol", "op": "set", "value": 40.0}])
    assert s6["monte_carlo"]["garch_vol"]["anchor"] == {"fx_vol": {"Float": 10.0}, "equity_vol": 20.0}


def test_severity_sampled_only_on_hit_paths(inputs, monkeypatch):
    # EQ-B-0041: the Beta/GPD inverse CDFs run on the default paths only (they were about half the run time);
    # the characterisation pins above prove the numbers are unchanged
    sizes = []
    real_beta, real_gpd = L6.sample_haircut, L6.gpd_severity
    monkeypatch.setattr(L6, "sample_haircut", lambda a, b, u: sizes.append(len(u)) or real_beta(a, b, u))
    monkeypatch.setattr(L6, "gpd_severity", lambda m, u, s: sizes.append(len(u)) or real_gpd(m, u, s))
    res = _run(inputs, paths=4096)
    assert sizes and max(sizes) < len(res.losses) and sum(sizes) < len(res.losses) * len(sizes) / 4


def test_haircut_draw_gets_the_position_asset_class(inputs, monkeypatch):
    # EQ-B-0037 review: under fitted LGD the dispersion is chosen by instrument class; passing the class avoids
    # guessing it from the mean, which picks the wrong class when a scenario makes lgd_local equal lgd_hard
    seen = []
    real = L6.haircut_distribution
    monkeypatch.setattr(L6, "haircut_distribution", lambda *a, **k: seen.append(k.get("asset_class")) or real(*a, **k))
    _run(inputs, paths=1024)
    assert seen and all(c is not None for c in seen)


# --- EQ-B-0044 (GOV-027): rate level shock, duration mark-to-market on local bonds and Eurobonds -------------------
def test_rate_shock_absent_adds_nothing(inputs):
    # base runs have no rate_shock_bp column, so the positions table and losses are untouched (pins above hold)
    assert "rate_mtm_pct" not in inputs.positions.columns
    _, _, base = _pipeline(paths=1024)
    assert "rate_shock_bp" not in base.positions.columns and "rate_mtm_pct" not in base.positions.columns


def test_rate_shock_is_duration_times_dy_on_every_path(inputs):
    pos = inputs.positions.copy()
    dy = 150.0
    pos["rate_mtm_pct"] = np.where(pos["asset_class"].isin(L6.RATE_SHOCK_CLASSES), pos["duration_yrs"].fillna(0.0) * dy / 100, 0.0)
    base, shocked = _run(inputs, paths=4096), L6.simulate(inputs.u, inputs.country, pos, inputs.loadings, inputs.settings, inputs.df, paths=4096)
    for j, (pid, p) in enumerate(pos.iterrows()):
        d = shocked.position_losses[:, j] - base.position_losses[:, j]
        if p["rate_mtm_pct"] == 0:
            assert np.array_equal(shocked.position_losses[:, j], base.position_losses[:, j]), pid
            continue
        expect = p["notional_mm"] * p["sign"] * p["duration_yrs"] * dy / 1e4
        uncapped = base.position_losses[:, j] + expect < p["notional_mm"] - 1e-9
        assert np.allclose(d[uncapped], expect, rtol=0, atol=1e-12), pid      # long loses duration * dy where not at the cap
        assert np.all(shocked.position_losses[:, j] <= p["notional_mm"] + 1e-12)


def test_rates_scenario_shock_reaches_layer6_by_leg():
    from econquest.engine import stress as ST
    from econquest.engine.pipeline import run_pipeline
    u, s, base = _pipeline(paths=1024)
    u2, s2 = ST.apply_shocks(u, s, [{"target": "rates", "leg": "local", "value": 100, "where": {"country_in": ["Brazil", "India"]}},
                                    {"target": "rates", "leg": "hard", "value": 50},
                                    {"target": "rates", "leg": "hard", "value": 50, "where": {"country_in": ["Argentina"]}}], scale=2.0)
    assert "rate_shock_bp" not in u.portfolio.columns                         # input universe untouched
    r = run_pipeline(u2, s2, paths=1024, as_of="2026-10-23")
    P = r.positions
    assert P.loc[(P["country"] == "Brazil") & (P["asset_class"] == "Local bond"), "rate_shock_bp"].eq(200).all()
    assert P.loc[(P["country"] == "China") & (P["asset_class"] == "Local bond"), "rate_shock_bp"].eq(0).all()
    assert P.loc[P["asset_class"] == "Eurobond"].apply(lambda p: p["rate_shock_bp"] == (200 if p["country"] == "Argentina" else 100), axis=1).all()
    assert P.loc[P["asset_class"].isin(["FX", "Equity", "CDS protection"]), "rate_mtm_pct"].eq(0).all()
    assert (P["rate_mtm_pct"] == P["duration_yrs"] * P["rate_shock_bp"] / 100).all()
    det = float((P["rate_mtm_pct"] / 100 * P["notional_mm"] * P["sign"]).sum())
    assert r.metrics["expected_loss_mm"] - base.metrics["expected_loss_mm"] == pytest.approx(det, rel=0.05)
    assert np.array_equal(r.country["pd_default"].to_numpy(), base.country["pd_default"].to_numpy())   # a market move, not a PD move
    with pytest.raises(ValueError, match="leg"):
        ST.apply_shocks(u, s, [{"target": "rates", "leg": "ust", "value": 10}])
    with pytest.raises(ValueError, match="op must be add"):
        ST.apply_shocks(u, s, [{"target": "rates", "leg": "local", "op": "mul", "value": 2}])
    assert ST.summarise_shocks([{"target": "rates", "leg": "hard", "op": "add", "value": 100}], 0.5) == ["hard bond yields (duration mark-to-market) +50 bp"]


# --- EQ-B-0054 (VF-004): Monte Carlo error by batch means -------------------------------------------------------
MC_ERROR_KEYS = ("var99_se_mm", "es99_se_mm", "lvar99_se_mm", "var99_ci95_lo_mm", "var99_ci95_hi_mm", "es99_ci95_lo_mm",
                 "es99_ci95_hi_mm", "lvar99_ci95_lo_mm", "lvar99_ci95_hi_mm", "mc_error_batches", "mc_error_batch_paths")


def test_mc_error_adds_new_keys_only_and_leaves_metrics_unchanged(inputs):
    r = _run(inputs, paths=20_000)
    m = r.metrics
    assert all(k in m for k in MC_ERROR_KEYS)
    for k, v in PINS[20_000].items():                                 # existing keys keep their pinned values
        assert m[k] == pytest.approx(v, rel=RTOL)
    assert m["var99_mm"] == float(np.quantile(r.losses, 0.99))       # computed from the untouched loss vector
    assert m["mc_error_batches"] == 32 and m["mc_error_batch_paths"] == 1024
    assert 0 < m["var99_se_mm"] < 0.05 * m["var99_mm"] and 0 < m["es99_se_mm"] < 0.05 * m["es99_mm"]
    assert m["lvar99_se_mm"] == m["var99_se_mm"]
    assert m["var99_ci95_lo_mm"] < m["var99_mm"] < m["var99_ci95_hi_mm"]
    assert m["es99_ci95_lo_mm"] < m["es99_mm"] < m["es99_ci95_hi_mm"]
    assert m["lvar99_ci95_lo_mm"] < m["lvar99_mm"] < m["lvar99_ci95_hi_mm"]
    assert all(isinstance(m[k], float) for k in MC_ERROR_KEYS)       # store.py writes float(v) for every metric


def test_mc_error_is_batch_means_by_hand():
    from scipy import stats
    x = np.random.default_rng(5).standard_t(4, 8192)
    e = L6.mc_error(x, liq_mm=2.0, batches=16)
    blocks = x.reshape(16, 512)
    v = np.quantile(blocks, 0.99, axis=1)
    es = np.array([b[b >= q].mean() for b, q in zip(blocks, v)])
    assert e["var99_se_mm"] == pytest.approx(np.std(v, ddof=1) / 4)
    assert e["es99_se_mm"] == pytest.approx(np.std(es, ddof=1) / 4)
    t = stats.t.ppf(0.975, 15)
    assert e["var99_ci95_hi_mm"] - e["var99_ci95_lo_mm"] == pytest.approx(2 * t * e["var99_se_mm"])
    assert e["lvar99_ci95_lo_mm"] == pytest.approx(e["var99_ci95_lo_mm"] + 2.0)
    before = x.copy(); L6.mc_error(x); assert np.array_equal(x, before)   # read-only


def test_mc_error_halves_batches_for_small_runs():
    e = L6.mc_error(np.random.default_rng(1).normal(size=2048))
    assert e["mc_error_batches"] == 4 and e["mc_error_batch_paths"] == 512     # power-of-two blocks of >= 512 paths
    e = L6.mc_error(np.random.default_rng(1).normal(size=300))
    assert e["mc_error_batches"] == 2 and np.isfinite(e["var99_se_mm"])


def test_mc_error_tracks_seed_to_seed_spread(inputs):
    """The batch SE is a conservative guide: same order as, and not smaller than about half, the seed sd."""
    runs = [_run(inputs, paths=20_000, seed=s).metrics for s in range(1, 9)]
    seed_sd = float(np.std([m["var99_mm"] for m in runs], ddof=1))
    se = float(np.mean([m["var99_se_mm"] for m in runs]))
    assert 0.5 * seed_sd < se < 4 * seed_sd


# --- EQ-B-0053 (RCA-B-004): EL falls under a Stressed global state through the long-loss cap ------------------
def _with_df(inp, df):
    """The fixture positions with thresholds re-derived for copula nu `df` (what build_positions does), so the
    marginal event probabilities pA / pB are unchanged and only the tail shape moves."""
    from scipy import stats
    pos = inp.positions.copy()
    for k in ("A", "B"):
        p = pos[f"p{k}"].astype(float)
        pos[f"thr{k}"] = np.where(p > 0, stats.t.ppf(p.clip(lower=1e-300), df), -np.inf)
    return pos


def test_cap_diagnostics_are_new_keys_only(inputs):
    r = _run(inputs, paths=20_000)
    m = r.metrics
    for k, v in PINS[20_000].items():                                 # existing keys keep their pinned values
        assert m[k] == pytest.approx(v, rel=RTOL)
    assert m["long_cap_relief_mm"] == pytest.approx(m["expected_loss_uncapped_mm"] - m["expected_loss_mm"], abs=1e-12)
    assert m["long_cap_relief_mm"] > 0                                # the cap only ever lowers a long's loss
    assert isinstance(m["expected_loss_uncapped_mm"], float) and isinstance(m["long_cap_relief_mm"], float)


def test_el_falls_with_nu_only_through_the_long_cap(inputs):
    """RCA-B-004: a lower nu (the Stressed global state) leaves each event probability and the zero-mean market move
    unchanged, so the uncapped EL holds within Monte Carlo error; the cap relief grows, and EL falls by that amount.
    Paired over seeds (same draws, nu 5 vs 4) so the check is on the mechanism, not one draw. On the fixture:
    EL -0.019 (SE 0.007), uncapped EL -0.002 (SE 0.008), cap relief +0.017 (SE 0.002) over 8 seeds x 8,192 paths."""
    d = []
    for seed in range(1, 9):
        row = []
        for df in (5.0, 4.0):
            m = L6.simulate(inputs.u, inputs.country, _with_df(inputs, df), inputs.loadings, inputs.settings, df,
                            paths=8192, seed=seed).metrics
            row.append((m["expected_loss_mm"], m["expected_loss_uncapped_mm"], m["long_cap_relief_mm"]))
        d.append(np.subtract(row[1], row[0]))
    d = np.array(d)
    mean, se = d.mean(axis=0), d.std(axis=0, ddof=1) / np.sqrt(len(d))
    assert mean[2] > 4 * se[2]                                        # heavier tails: more loss mass above notional
    assert mean[0] < 0                                                # so EL falls ...
    assert abs(mean[1]) < 3 * se[1]                                   # ... while the uncapped EL does not move


def test_loadings_do_not_enter_el_beyond_sampling_noise(inputs):
    """EL is a sum of per-position means, and each latent marginal is t_nu whatever the loadings, so raising the global
    loading (the other half of the Stressed state) moves EL only by sampling noise."""
    lo = inputs.loadings.copy()
    hi = lo.copy()
    hi["global"] = np.minimum(lo["global"] * 1.5, 1 - lo["regional"] - 0.05); hi["idio"] = 1 - hi["global"] - hi["regional"]
    d = []
    for seed in range(1, 9):
        a = L6.simulate(inputs.u, inputs.country, inputs.positions, lo, inputs.settings, inputs.df, paths=8192, seed=seed).metrics
        b = L6.simulate(inputs.u, inputs.country, inputs.positions, hi, inputs.settings, inputs.df, paths=8192, seed=seed).metrics
        d.append((b["expected_loss_mm"] - a["expected_loss_mm"], b["long_cap_relief_mm"] - a["long_cap_relief_mm"]))
    d = np.array(d)
    assert abs(d[:, 0].mean()) < 3 * d[:, 0].std(ddof=1) / np.sqrt(len(d)) + 1e-3
    assert abs(d[:, 1].mean()) < 3 * d[:, 1].std(ddof=1) / np.sqrt(len(d)) + 1e-3


# --- EQ-B-0063 (GOV-047): bounded market move and the Eurobond default / spread-move overlap ---------------------
LOGN = {"monte_carlo.market_move": "lognormal"}
LGD_ONLY = {"monte_carlo.default_spread_overlap": "lgd_only"}
BOTH = {**LOGN, **LGD_ONLY}


def test_market_move_and_overlap_defaults_are_bit_identical(inputs):
    a = _run(inputs, paths=4096)
    b = _run(inputs, paths=4096, settings=inputs.settings.copy_with(**{"monte_carlo.market_move": "linear",
                                                                       "monte_carlo.default_spread_overlap": "additive"}))
    assert np.array_equal(a.losses, b.losses) and a.metrics == b.metrics
    assert L6.market_move(inputs.settings) == "linear" and L6.default_spread_overlap(inputs.settings) == "additive"


@pytest.mark.parametrize("key,value", [("monte_carlo.market_move", "log"), ("monte_carlo.default_spread_overlap", "drop")])
def test_market_move_and_overlap_reject_unknown_values(inputs, key, value):
    with pytest.raises(ValueError):
        _run(inputs, paths=1024, settings=inputs.settings.copy_with(**{key: value}))


def test_normal_score_is_finite_monotone_and_symmetric():
    x = np.array([-1e3, -40.0, -3.0, -0.5, 0.0, 0.5, 3.0, 40.0, 1e3])
    zn = L6.normal_score(x, 4.0)
    assert np.all(np.isfinite(zn)) and np.all(np.diff(zn) > 0)
    assert np.allclose(zn, -L6.normal_score(-x, 4.0)) and zn[4] == 0.0
    assert np.allclose(L6.normal_score(np.array([-1.0, 1.5]), 1e7), [-1.0, 1.5], atol=1e-5)   # nu -> inf: identity


@pytest.mark.parametrize("vol", [2.0, 25.0, 60.0, -13.0])
def test_lognormal_market_loss_is_mean_zero_and_below_notional(vol):
    zn = stats_norm_ppf_sobol(2 ** 16)
    m = L6.lognormal_market_loss(zn, vol)
    assert np.all(m < 1.0)                                            # a long never loses more than 100% from the move
    assert abs(m.mean()) < 2e-3 * max(1.0, abs(vol) / 10)             # mean-preserving (E[exp(sZ - s^2/2)] = 1)


def stats_norm_ppf_sobol(n):
    from scipy import stats
    return stats.norm.ppf(qmc.Sobol(d=1, scramble=True, seed=3).random_base2(int(np.log2(n)))[:, 0])


@pytest.mark.parametrize("mm", ["linear", "lognormal"])
@pytest.mark.parametrize("p,vol", [(0.14, 15.6), (0.99, 60.0), (0.14, -13.0), (0.005, 2.0)])
def test_default_path_move_closed_form(mm, p, vol):
    """E[m 1{latent < thr}] in closed form against numerical integration over the t_nu latent."""
    from scipy import stats, integrate
    df = 5.0
    thr = stats.t.ppf(p, df)
    sig = vol / 100
    if mm == "linear":
        f = lambda x: -sig * x / np.sqrt(df / (df - 2)) * stats.t.pdf(x, df)
    else:
        f = lambda x: -np.expm1(sig * L6.normal_score(np.array([x]), df)[0] - sig * sig / 2) * stats.t.pdf(x, df)
    num = integrate.quad(f, -np.inf, thr, limit=200)[0]
    assert L6.default_path_move(p, thr, vol, df, mm) == pytest.approx(num, rel=1e-6, abs=1e-10)
    fc = lambda x: min(f(x) / stats.t.pdf(x, df), 1.0) * stats.t.pdf(x, df)    # E[min(m, 1) 1{hit}] (compound)
    pts = [-np.sqrt(df / (df - 2)) / sig] if mm == "linear" and sig > 0 and -np.sqrt(df / (df - 2)) / sig < thr else None
    numc = sum(integrate.quad(fc, lo, hi, limit=200)[0] for lo, hi in
               zip([-np.inf] + (pts or []), (pts or []) + [thr]))
    assert L6.default_path_move(p, thr, vol, df, mm, clip=True) == pytest.approx(numc, rel=1e-6, abs=1e-10)


def _paired(inputs, over, seeds=range(1, 9), paths=8192, positions=None, df=None):
    out = []
    for seed in seeds:
        row = []
        for s in (inputs.settings, inputs.settings.copy_with(**over)):
            m = L6.simulate(inputs.u, inputs.country, inputs.positions if positions is None else positions, inputs.loadings, s,
                            inputs.df if df is None else df, paths=paths, seed=seed).metrics
            row.append((m["expected_loss_mm"], m["expected_loss_uncapped_mm"], m["long_cap_relief_mm"]))
        out.append(np.subtract(row[1], row[0]))
    d = np.array(out)
    return d.mean(axis=0), d.std(axis=0, ddof=1) / np.sqrt(len(d))


@pytest.mark.parametrize("over", [LOGN, LGD_ONLY, BOTH, {"monte_carlo.default_spread_overlap": "compound", **LOGN},
                                  {"monte_carlo.default_spread_overlap": "compound"}])
def test_options_keep_the_uncapped_mean_and_cut_the_cap_relief(inputs, over):
    """GOV-047: each option leaves the mean path loss before the cap where it was (the market move stays zero-mean,
    the default-path removal is re-centred on the survivors) and removes part of the long-cap EL credit."""
    mean, se = _paired(inputs, over)
    assert abs(mean[1]) < 3 * se[1] + 0.01                            # uncapped EL: unchanged within MC error
    assert mean[2] < -0.1 and mean[2] < -4 * se[2]                    # cap relief falls ...
    assert mean[0] > 0                                                # ... so EL rises by about that amount


def test_lgd_only_settles_eurobond_and_cds_at_lgd_on_default_paths(inputs):
    pos = inputs.positions.loc[["P14", "P15", "P17", "P20"]]
    base = L6.simulate(inputs.u, inputs.country, pos, inputs.loadings, inputs.settings, inputs.df, paths=8192, seed=5)
    new = L6.simulate(inputs.u, inputs.country, pos, inputs.loadings, inputs.settings.copy_with(**LGD_ONLY), inputs.df,
                      paths=8192, seed=5)
    names = list(inputs.u.names)
    for j, (pid, p) in enumerate(pos.iterrows()):
        hit = base.latent[:, names.index(p["country"])] < p["thrA"]
        frac = (new.position_losses[hit, j] - p["carry_mm"]) / p["notional_mm"]
        if p["asset_class"] == "Eurobond":
            assert np.all((frac >= 0) & (frac <= 1))                  # LGD only: no spread move on top
        else:
            assert np.all((frac <= 0) & (frac >= -1))                 # protection pays LGD only
        shift = new.position_losses[~hit, j] - base.position_losses[~hit, j]
        if p["asset_class"] == "Eurobond" and pid != "P17":
            assert np.allclose(shift, shift[0])                       # survivors: one constant re-centring shift
    eb = (pos["asset_class"] == "Eurobond").to_numpy()
    assert np.all(new.position_losses[:, eb] < pos["notional_mm"].to_numpy()[eb])   # the cap never binds


def test_compound_is_mark_down_then_lgd_on_the_rest(inputs):
    pos = inputs.positions.loc[["P20"]]
    s_add = inputs.settings
    s_cmp = inputs.settings.copy_with(**{"monte_carlo.default_spread_overlap": "compound"})
    a = L6.simulate(inputs.u, inputs.country, pos, inputs.loadings, s_add, inputs.df, paths=4096, seed=9)
    c = L6.simulate(inputs.u, inputs.country, pos, inputs.loadings, s_cmp, inputs.df, paths=4096, seed=9)
    p = pos.iloc[0]; nn = p["notional_mm"]
    z = a.latent[:, list(inputs.u.names).index(p["country"])]
    hit = z < p["thrA"]
    m = -(z / np.sqrt(inputs.df / (inputs.df - 2)))[hit] * p["market_vol_pct"] / 100
    lgd = np.minimum((a.position_losses[hit, 0] - p["carry_mm"]) / nn, 1.0)   # additive: m + LGD (cap may bind)
    unc = (a.position_losses[hit, 0] - p["carry_mm"]) / nn < 1.0
    sev = lgd[unc] - m[unc]
    got = (c.position_losses[hit, 0][unc] - p["carry_mm"]) / nn
    assert np.allclose(got, m[unc] + (1 - np.minimum(m[unc], 1)) * sev)


def test_both_options_shrink_the_el_fall_under_a_lower_nu(inputs):
    """The RCA-B-004 symptom: nu 5 -> 4 lowers EL through the cap. With both options most of the cap relief is gone,
    so the fall is much smaller (what is left is equity and local-bond jumps on top of a bad market move)."""
    def fall(settings):
        d = []
        for seed in range(1, 9):
            e = [L6.simulate(inputs.u, inputs.country, _with_df(inputs, df), inputs.loadings, settings, df, paths=8192,
                             seed=seed).metrics["long_cap_relief_mm"] for df in (5.0, 4.0)]
            d.append(e[1] - e[0])
        return float(np.mean(d))
    today, both = fall(inputs.settings), fall(inputs.settings.copy_with(**BOTH))
    assert today > 0 and both < 0.5 * today
