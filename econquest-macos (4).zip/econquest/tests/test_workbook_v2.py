"""Workbook v2 (EQ-C-0033, contract C11): publish plans size themselves from the run's country and series count.

At 18 countries every range is the v1 range (golden list below); at 70 countries (synthetic run: the 18 seed
countries cloned under new names) no block overflows its range, no two blocks share a cell, the Sheets column
limit holds and the C11 anchors (A2 notes, Risk Engine R31-R33 labels) stay where they were."""
import copy
import json
import shutil
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.config import Settings  # noqa: E402
from econquest.ingestion import load_universe  # noqa: E402
from econquest.engine import run_pipeline  # noqa: E402
from econquest.presentation import sheets_publish as SP  # noqa: E402
from econquest.presentation.sheets_publish import col_letter, col_number, country_cols, country_range, layout_v2, parse_a1, plan_problems  # noqa: E402
from econquest.presentation.garch_publish import garch_plan  # noqa: E402
from econquest.presentation.econ_publish import _table  # noqa: E402

DATA = ROOT / "data"
AS_OF = "2026-10-23"

# v1 (hard-coded 18-country) build_plan ranges, in plan order, with the seed backtest history (T periods)
V1_RANGES = [
    "Inputs!E45:V45", "'Stress Inputs'!E5:V87", "'Stress Inputs'!E90:V92", "'Stress Inputs'!A2", "'Base Scores'!E5:V87",
    "'Stress Scores'!E5:V87", "'Indicator Scores'!E5:V87", "'Base Scores'!A2", "'Stress Scores'!A2", "'Indicator Scores'!A2",
    "Adjustments!E5:V11", "Adjustments!E21:V27", "'Pillar Scores'!E5:V11", "'Pillar Scores'!E13:V19", "'Pillar Scores'!E21:V27",
    "'Pillar Scores'!E29:V35", "'Pillar Scores'!E37:V44", "'Pillar Scores'!E46:V47", "'Pillar Scores'!A2", "'Risk Engine'!E5:V37",
    "'Risk Engine'!A12:D12", "'Risk Engine'!A35:D37", "'Risk Engine'!A2", "Signals!E5:V29", "Signals!A2", "'Trade Activation'!A5:D30",
    "'Trade Activation'!E5:V30", "'Trade Activation'!A2", "'Portfolio VaR'!H5:Y34", "'Portfolio VaR'!AB5:AB34", "'Portfolio VaR'!E37:E46",
    "'Portfolio VaR'!I37:I40", "'Portfolio VaR'!C47:E47", "'Portfolio VaR'!A50:M67", "'Portfolio VaR'!B70:F74", "'Portfolio VaR'!A2",
    "MC!G2:X5", "MC!A7:X56", "MC!Z7:BD56", "MC!A1:A2", "'Prediction Markets'!I5:X34", "'Prediction Markets'!A38:M55",
    "'Prediction Markets'!A2", "GPR!E5:V13", "GPR!E15:V22", "GPR!E25:V35", "GPR!A2", "Dashboard!A2:A3", "Dashboard!A6:V23",
    "Backtesting!G5:I12", "Backtesting!F17:K{e}", "Backtesting!A17:A{e}", "Backtesting!B12", "Backtesting!B9:B10"]
A2_TABS = ["'Stress Inputs'", "'Base Scores'", "'Stress Scores'", "'Indicator Scores'", "'Pillar Scores'", "'Risk Engine'", "Signals",
           "'Trade Activation'", "'Portfolio VaR'", "GPR"]


# ---------------------------------------------------------------- helpers
@pytest.mark.parametrize("n,letters", [(1, "A"), (5, "E"), (22, "V"), (26, "Z"), (27, "AA"), (52, "AZ"), (53, "BA"), (74, "BV"),
                                       (702, "ZZ"), (703, "AAA"), (18278, "ZZZ")])
def test_col_letter_and_inverse(n, letters):
    assert col_letter(n) == letters and col_number(letters) == n


def test_col_letter_round_trip_and_limits():
    assert all(col_number(col_letter(k)) == k for k in range(1, 2000))
    for bad in (0, -1, SP.SHEETS_MAX_COLS + 1):
        with pytest.raises(ValueError):
            col_letter(bad)
    with pytest.raises(ValueError):
        col_number("AAAA")


def test_country_ranges():
    assert country_cols(18) == "E:V" == SP.COUNTRY_COLS and country_cols(70) == "E:BV" and country_cols(23) == "E:AA"
    assert country_range("'Risk Engine'", 5, 37, 18) == "'Risk Engine'!E5:V37"
    assert country_range("'Risk Engine'", 5, 37, 70) == "'Risk Engine'!E5:BV37"
    assert parse_a1("'Risk Engine'!E5:BV37") == ("Risk Engine", 5, 5, 37, 74)
    with pytest.raises(ValueError):
        country_range("X", 1, 1, 0)


def test_plan_problems_catches_overflow_overlap_and_limit():
    assert plan_problems([{"range": "T!A1:B2", "values": [[1, 2], [3, 4]]}, {"range": "T!C1", "values": [[5]]}]) == []
    assert any("do not fit" in p for p in plan_problems([{"range": "T!A1:B1", "values": [[1, 2, 3]]}]))
    assert any("overlaps" in p for p in plan_problems([{"range": "T!A1:B2", "values": [[1]]}, {"range": "T!B2:C3", "values": [[1]]}]))
    assert plan_problems([{"range": "T!A1:B2", "values": [[1]]}, {"range": "'U'!B2:C3", "values": [[1]]}]) == []   # other tab
    assert any("limit" in p for p in plan_problems([{"range": "T!A1:Z1", "values": [[1]]}], max_cols=20))


def test_layout_v2_at_18_is_v1():
    L = layout_v2(18, mc_rows=50)
    assert set(L.values()) <= {r for r in V1_RANGES}
    assert "pv_asset_class_head" not in L and L["pv_asset_class"] == "'Portfolio VaR'!B70:F74"
    assert plan_problems([{"range": r, "values": [[0]]} for r in L.values()]) == []


@pytest.mark.parametrize("n", [1, 19, 26, 70, 200])
def test_layout_v2_has_no_overlap_at_any_size(n):
    L = layout_v2(n)
    assert plan_problems([{"range": r, "values": [[0]]} for r in L.values()]) == []
    assert parse_a1(L["risk_engine"])[4] == 4 + n and parse_a1(L["pv_holdings"])[3] == 49 + n


def test_workbook_reference_describes_v2():
    ref = json.loads((DATA / "workbook_reference.json").read_text())
    lay = ref["layout"]
    assert ref["layout_version"] == 2 == lay["version"] == SP.LAYOUT_VERSION and lay["contract"] == "C11"
    L18, L70 = layout_v2(18), layout_v2(70)
    assert set(lay["blocks"]) == set(L18) | set(L70)
    for k, b in lay["blocks"].items():
        assert b["n18"] == L18.get(k) and b["n70"] == L70[k], k
        assert b["moves_at_n_gt_18"] == (L18.get(k) != L70[k]), k
    assert lay["country_columns"]["n18"] == country_cols(18) and lay["country_columns"]["n70"] == country_cols(70)
    assert set(lay["fixed_anchors"]["run_note_A2"]) == set(A2_TABS)
    assert "'Risk Engine'!A35:D37" in lay["fixed_anchors"]["risk_engine_labels"]
    for k in ("countries", "composite", "grade", "final_pillars", "regime", "portfolio"):   # numeric reference kept
        assert k in ref


# ---------------------------------------------------------------- 18 countries: v1 ranges, in order
@pytest.fixture(scope="module")
def run18():
    u = load_universe(DATA); s = Settings.load(DATA / "assumptions.json")
    return u, s, run_pipeline(u, s, paths=2000, as_of=AS_OF)


def test_18_country_plan_keeps_every_v1_range(run18):
    u, s, res = run18
    assert len(u.names) == 18
    history = pd.read_csv(DATA / "backtest_history.csv")
    plan = SP.build_plan(res, u, s, history=history, stamp=AS_OF, mc_rows=50)
    assert [b["range"] for b in plan] == [r.format(e=16 + len(history)) for r in V1_RANGES]
    assert plan_problems(plan) == []
    mc_note = next(b for b in plan if b["range"] == "MC!A1:A2")["values"][1][0]
    assert "Columns G:X hold" in mc_note and "Z:BC the loss" in mc_note and "BD the portfolio loss" in mc_note


# ---------------------------------------------------------------- 70 countries: synthetic run
def synthetic_data(dst: Path, n: int) -> Path:
    """Copy the seed inputs (top-level files only) and clone the 18 countries to n under synthetic names."""
    dst.mkdir(parents=True, exist_ok=True)
    for f in DATA.iterdir():
        if f.is_file():
            shutil.copy(f, dst / f.name)
    cty = pd.read_csv(DATA / "countries.csv")
    base = list(cty["country"]); extra = []
    for k in range(len(base) + 1, n + 1):
        b = base[(k - 1) % len(base)]
        r = cty[cty["country"] == b].iloc[0].copy()
        r["country"] = f"Synthland {k:02d}"; r["iso"] = f"X{k:02d}"; r["iso2"] = ("Q" if k < 45 else "X") + chr(65 + k % 26)
        extra.append((r["country"], b, r))
    pd.concat([cty, pd.DataFrame([r for _, _, r in extra])]).to_csv(dst / "countries.csv", index=False)
    for f in ("indicators.csv", "adjustments.csv"):
        df = pd.read_csv(DATA / f, dtype={"id": str} if f == "indicators.csv" else None)
        for name, b, _ in extra:
            df[name] = df[b]
        df.to_csv(dst / f, index=False)
    return dst


@pytest.fixture(scope="module")
def run70(tmp_path_factory):
    d = synthetic_data(tmp_path_factory.mktemp("synth70") / "data", 70)
    a = json.loads((d / "assumptions.json").read_text())             # layout test: synthetic countries have no price
    a["copula"] = {**a.get("copula", {}), "source": "judgement", "nu_source": "judgement"}   # history to estimate from
    (d / "assumptions.json").write_text(json.dumps(a, indent=2))
    u = load_universe(d); s = Settings.load(d / "assumptions.json")
    res = run_pipeline(u, s, paths=2000, as_of=AS_OF)
    history = pd.read_csv(d / "backtest_history.csv")
    return u, s, res, SP.build_plan(res, u, s, history=history, stamp=AS_OF, mc_rows=50)


def test_70_country_plan_fits_without_overlap(run70):
    u, s, res, plan = run70
    n = len(u.names)
    assert n == 70 and len(set(u.names)) == 70
    assert plan_problems(plan) == []
    json.dumps(plan, allow_nan=False)
    assert max(parse_a1(b["range"])[4] for b in plan) <= SP.SHEETS_MAX_COLS
    blocks = {b["range"]: b["values"] for b in plan}
    L = layout_v2(n, mc_rows=50, n_regions=len(res.mc.region_order or []))
    for k in ("stress_inputs", "base_scores", "indicator_scores", "pillar_final", "risk_engine", "signals", "trade_activation", "gpr_levels"):
        assert L[k] in blocks and parse_a1(L[k])[2] == 5 and parse_a1(L[k])[4] == 74, k        # E:BV
        assert all(len(r) == n for r in blocks[L[k]]), k
    # country order: the Risk Engine default-PD row (R15, row 19) matches the engine country by country
    assert blocks["'Risk Engine'!E5:BV37"][14] == pytest.approx([float(res.country.at[c, "pd_default"]) for c in u.names])


def test_70_country_c11_anchors_unchanged(run70):
    u, s, res, plan = run70
    ranges = [b["range"] for b in plan]
    for tab in A2_TABS:
        assert f"{tab}!A2" in ranges, tab
    labels = next(b for b in plan if b["range"] == "'Risk Engine'!A35:D37")["values"]
    assert [r[0] for r in labels] == ["R31", "R32", "R33"]
    assert "'Risk Engine'!A12:D12" in ranges and "MC!A1:A2" in ranges and "Dashboard!A2:A3" in ranges
    for fixed in ("'Portfolio VaR'!H5:Y34", "'Portfolio VaR'!E37:E46", "'Portfolio VaR'!C47:E47", "'Prediction Markets'!I5:X34"):
        assert fixed in ranges, fixed


def test_70_country_row_blocks_move_down(run70):
    u, s, res, plan = run70
    blocks = {b["range"]: b["values"] for b in plan}
    hold = blocks["'Portfolio VaR'!A50:M119"]
    assert [r[0] for r in hold] == u.names
    assert blocks["'Portfolio VaR'!A121:F121"][0][0] == "Asset class"
    assert [r[0] for r in blocks["'Portfolio VaR'!A122:A126"]] == SP.ASSET_CLASSES and len(blocks["'Portfolio VaR'!B122:F126"]) == 5
    assert "'Portfolio VaR'!B70:F74" not in blocks                        # would sit inside the holdings block
    assert [r[0] for r in blocks["'Prediction Markets'!A38:M107"]] == u.names
    assert [r[0] for r in blocks["Dashboard!A6:V75"]] == u.names
    mc = [b for b in plan if b["range"].startswith("MC!")]
    reg = len(res.mc.region_order or [])
    lat1 = 3 + reg + 70
    factors = next(b for b in mc if b["range"].startswith("MC!A7:"))
    assert parse_a1(factors["range"])[4] == lat1 and all(len(r) == lat1 for r in factors["values"])
    losses = next(b for b in mc if parse_a1(b["range"])[1] == 7 and b is not factors)
    assert parse_a1(losses["range"])[2] == lat1 + 2
    note = next(b for b in mc if b["range"] == "MC!A1:A2")["values"][1][0]
    assert f"Columns {col_letter(4 + reg)}:{col_letter(lat1)} hold" in note and f"{col_letter(lat1 + 32)} the portfolio loss" in note


# ---------------------------------------------------------------- GARCH past 30 series, DCC past 25 labels
class _DCC:
    def __init__(self, labels):
        k = len(labels)
        self.labels, self.a, self.b, self.n = labels, 0.02, 0.95, 500
        self.R_next = np.full((k, k), 0.3) + 0.7 * np.eye(k); self.R_uncond = self.R_next.copy()

    @staticmethod
    def avg_corr(R):
        k = R.shape[0]
        return float((R.sum() - k) / (k * k - k))


@pytest.fixture(scope="module")
def garch_base():
    from econquest.engine.garch import run_garch, load_prices
    px = load_prices(DATA)
    if px is None:
        pytest.skip("no data/market_history/prices.csv")
    u = load_universe(DATA); s = Settings.load(DATA / "assumptions.json")
    sub = px[[c for c in ("USDBRL", "USDJPY", "EWZ", "EWJ") if c in px.columns]]
    if sub.shape[1] < 2:
        pytest.skip("snapshot lacks the test tickers")
    return u, run_garch(u, sub, s, None)


def test_garch_plan_grows_past_30_series(garch_base):
    u, g0 = garch_base
    g = copy.copy(g0)
    g.series = pd.concat([g0.series] * (140 // len(g0.series) + 1), ignore_index=True).head(140)
    g.dcc_fx = _DCC([f"FX{i:02d}" for i in range(70)]); g.dcc_eq = _DCC([f"EQ{i:02d}" for i in range(30)])
    plan = garch_plan(g, u, stamp=AS_OF)
    assert plan_problems(plan) == []
    blocks = {b["range"]: b["values"] for b in plan}
    assert "GARCH!A4:Z4" in blocks and len(blocks["GARCH!A5:Z144"]) == 140
    assert "GARCH!A146:A146" in blocks                                   # Table B title right below Table A (36 + 110)
    assert "GARCH!A147:BS217" in blocks                                   # 70 labels + label column = 71 columns (BS)
    starts = [parse_a1(b["range"])[1] for b in plan if parse_a1(b["range"])[2] == 1]
    assert starts == sorted(starts) and len(set(starts)) == len(starts)


def test_garch_plan_up_to_30_series_keeps_v1_rows(garch_base):
    u, g = garch_base
    ranges = [b["range"] for b in garch_plan(g, u, stamp=AS_OF)]
    assert "GARCH!A5:Z34" in ranges and "GARCH!A36:A36" in ranges


def test_econ_table_past_52_columns():
    P = []
    cols = [(f"c{i}", f"H{i}", 2) for i in range(60)]
    df = pd.DataFrame([{f"c{i}": float(i) for i in range(60)}])
    _table(P, 4, "T", df, cols)
    assert P[-1]["range"] == "Econometrics!A5:BH6" and plan_problems(P) == []
    P = []
    _table(P, 4, "T", df, cols[:28])
    assert P[-1]["range"] == "Econometrics!A5:AB6"                        # v1 range for 28 columns
