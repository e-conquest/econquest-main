"""EQ-A-0030: free public market sources (FRED/ALFRED, ECB YC, BIS policy rates). No network: fetchers are mocked
and every number comes from SYNTHETIC fixtures in tests/fixtures/market/public/."""
import datetime as dt
import email
import io
import json
import urllib.parse
import urllib.request
import urllib.response
from pathlib import Path

import pandas as pd
import pytest

from econquest.ingestion.events import base
from econquest.ingestion.market import public
from econquest.ingestion.market.gate import market_gate
from econquest.ingestion.market.public import (ECB_LICENCE, EURO_AREA_ISO, FRED_LICENCE, PublicSourceError,
                                               bis_policy_rows, ecb_maturity_years, fetch_ecb, fetch_fred,
                                               parse_ecb_csv, parse_fred_json, save_public)
from econquest.ingestion.market.schema import MARKET_COLUMNS, MarketDataError
from econquest.ingestion.market.store import latest_market

FIX = Path(__file__).parent / "fixtures" / "market" / "public"
KEY = "abcdefghij0123456789abcdefghij01"          # fake, FRED-shaped
NOW = dt.datetime(2026, 10, 23, 12, 0, tzinfo=dt.timezone.utc)
FRED = json.loads((FIX / "fred_dgs.json").read_text())


def fred_fetcher(seen=None):
    def f(url, headers, data=None):
        q = urllib.parse.parse_qs(urllib.parse.urlsplit(url).query)
        if seen is not None:
            seen.append(q)
        return json.dumps(FRED[q["series_id"][0]]).encode()
    return f


SERIES = ["DGS1MO", "DGS3MO", "DGS6MO", "DGS1", "DGS10"]


# ------------------------------------------------------------------------------------------------ FRED parsing

def test_parse_fred_skips_dot_missing_values_and_counts_them():
    obs = parse_fred_json(json.dumps(FRED["DGS10"]).encode(), "DGS10")
    assert obs["date"].tolist() == ["2026-10-19", "2026-10-21", "2026-10-22"]     # 2026-10-20 is '.'
    assert obs["value"].tolist() == [4.20, 4.22, 4.23]
    assert obs.attrs["missing"] == 1


def test_fetch_fred_rows_tenors_licence_and_key_from_env(monkeypatch):
    monkeypatch.setenv("FRED_API_KEY", KEY)
    seen = []
    df = fetch_fred("2026-10-19", "2026-10-22", SERIES, fetcher=fred_fetcher(seen), now=NOW, sleep=lambda s: None)
    assert list(df.columns) == MARKET_COLUMNS
    assert set(df["instrument"]) == {"govt_yield"} and set(df["iso"]) == {"USA"} and set(df["currency"]) == {"USD"}
    assert set(df["source"]) == {"fred"} and set(df["licence"]) == {FRED_LICENCE} and not df["derived"].any()
    t = df.groupby("vendor_ticker")["tenor_y"].first().to_dict()
    assert t["DGS1MO"] == pytest.approx(1 / 12) and t["DGS3MO"] == 0.25 and t["DGS1"] == 1.0 and t["DGS10"] == 10.0
    assert len(df) == 4 * 5 - 2                                            # two '.' cells skipped, never filled
    assert all(q["api_key"] == [KEY] and q["file_type"] == ["json"] and "realtime_end" not in q for q in seen)
    prov = df.attrs["provenance"]
    assert prov["missing_dot_values"] == {"DGS1MO": 0, "DGS3MO": 1, "DGS6MO": 0, "DGS1": 0, "DGS10": 1}
    assert KEY not in json.dumps(prov)


def test_fred_key_missing_or_malformed_is_refused_without_echo(monkeypatch):
    monkeypatch.delenv("FRED_API_KEY", raising=False)
    with pytest.raises(PublicSourceError, match="FRED_API_KEY"):
        fetch_fred("2026-10-19", "2026-10-22", fetcher=fred_fetcher())
    monkeypatch.setenv("FRED_API_KEY", "Not-A-Key-SECRET")
    with pytest.raises(PublicSourceError) as e:
        fetch_fred("2026-10-19", "2026-10-22", fetcher=fred_fetcher())
    assert "SECRET" not in str(e.value)


def test_fred_errors_never_echo_query_or_key():
    def boom(url, headers, data=None):
        raise RuntimeError(f"failed GET {url}")             # a careless custom fetcher
    with pytest.raises(PublicSourceError) as e:
        fetch_fred("2026-10-19", "2026-10-22", ["DGS10"], api_key=KEY, fetcher=boom)
    assert KEY not in str(e.value) and "api_key" not in str(e.value) and "series_id=" not in str(e.value)

    def api_error(url, headers, data=None):
        return json.dumps({"error_code": 400, "error_message": f"Bad Request. api_key {KEY} is not registered"}).encode()
    with pytest.raises(PublicSourceError, match="API error 400") as e:
        fetch_fred("2026-10-19", "2026-10-22", ["DGS10"], api_key=KEY, fetcher=api_error)
    assert KEY not in str(e.value)


# ------------------------------------------------------------------------------------------------ ALFRED

ALFRED = (FIX / "alfred_dgs10.json").read_bytes()


def test_alfred_vintage_selection():
    a21 = parse_fred_json(ALFRED, "DGS10", asof="2026-10-21")
    assert dict(zip(a21["date"], a21["value"])) == {"2026-10-19": 3.98, "2026-10-20": 4.00}
    assert a21.attrs["missing"] == 1          # 2026-10-21 was '.' in the vintage valid that day: no older fallback
    a22 = parse_fred_json(ALFRED, "DGS10", asof="2026-10-22")
    assert dict(zip(a22["date"], a22["value"])) == {"2026-10-19": 3.98, "2026-10-20": 4.05, "2026-10-21": 4.10,
                                                    "2026-10-22": 4.12}
    latest = parse_fred_json(ALFRED, "DGS10")                      # no asof: newest vintage per date
    assert dict(zip(latest["date"], latest["value"]))["2026-10-20"] == 4.05


def test_fetch_fred_asof_uses_alfred_realtime_and_records_vintage():
    seen = []

    def f(url, headers, data=None):
        seen.append(urllib.parse.parse_qs(urllib.parse.urlsplit(url).query))
        return ALFRED
    df = fetch_fred("2026-10-19", "2026-10-31", ["DGS10"], api_key=KEY, asof="2026-10-21", fetcher=f, now=NOW)
    assert seen[0]["realtime_end"] == ["2026-10-21"] and seen[0]["observation_end"] == ["2026-10-21"]
    assert set(df["source"]) == {"alfred"}
    assert dict(zip(df["asof"], df["vendor_ticker"])) == {"2026-10-19": "DGS10@2026-10-19",
                                                         "2026-10-20": "DGS10@2026-10-20"}
    assert df.attrs["provenance"]["realtime_asof"] == "2026-10-21"


# ------------------------------------------------------------------------------------------------ ECB

ECB = (FIX / "ecb_yc.csv").read_bytes()


def test_parse_ecb_sdmx_csv():
    df = parse_ecb_csv(ECB, retrieved_utc="2026-10-23T12:00:00Z")
    assert df.attrs["missing"] == 2                                       # one blank, one NaN
    assert set(df["iso"]) == {EURO_AREA_ISO} and set(df["currency"]) == {"EUR"}
    assert set(df["source"]) == {"ecb_yc_aaa", "ecb_yc_all"} and set(df["licence"]) == {ECB_LICENCE}
    aaa = df[(df["source"] == "ecb_yc_aaa") & (df["asof"] == "2026-10-22")].set_index("tenor_y")["value"].to_dict()
    assert aaa == {0.25: 2.02, 0.5: 2.04, 10.0: 2.61}                    # 1Y blank on 10-22
    assert df.loc[df["source"] == "ecb_yc_all", "vendor_ticker"].iloc[0].startswith("YC.B.U2.EUR.4F.G_N_C.SV_C_YM.")


def test_parse_ecb_without_key_column_uses_dimensions_and_refuses_other_series():
    raw = pd.read_csv(io.BytesIO(ECB), dtype=str, keep_default_na=False).drop(columns="KEY")
    df = parse_ecb_csv(raw.to_csv(index=False).encode())
    assert len(df) == 10
    raw.loc[0, "PROVIDER_FM_ID"] = "NS_C_YM"                              # a different model: refused, not mixed in
    with pytest.raises(MarketDataError, match="unexpected series keys"):
        parse_ecb_csv(raw.to_csv(index=False).encode())


@pytest.mark.parametrize("code,years", [("SR_3M", 0.25), ("SR_1Y", 1.0), ("SR_10Y", 10.0), ("SR_1Y6M", 1.5)])
def test_ecb_maturity_codes(code, years):
    assert ecb_maturity_years(code) == pytest.approx(years)


def test_ecb_maturity_bad_code():
    with pytest.raises(MarketDataError):
        ecb_maturity_years("PY_10Y")


def test_fetch_ecb_batches_series_and_chunks_by_year():
    urls = []

    def f(url, headers, data=None):
        urls.append(url)
        return ECB
    df = fetch_ecb("2025-12-30", "2026-10-22", fetcher=f, now=NOW)
    assert len(urls) == 2
    p = urllib.parse.urlsplit(urls[0])
    assert p.scheme == "https" and p.hostname == "data-api.ecb.europa.eu"
    assert p.path.startswith("/service/data/YC/B.U2.EUR.4F.G_N_A+G_N_C.SV_C_YM.SR_3M+SR_6M+")
    q = urllib.parse.parse_qs(p.query)
    assert q["format"] == ["csvdata"] and q["detail"] == ["dataonly"] and q["startPeriod"] == ["2025-12-30"]
    assert len(df) == 10 and "YC.B.U2.EUR.4F.G_N_A.SV_C_YM.SR_10Y" in df.attrs["provenance"]["series_keys"]


# ------------------------------------------------------------------------------------------------ http_fetch path

class StubWire:
    def __init__(self, respond):
        self.seen, wire = [], self
        self._respond = respond

        class Https(urllib.request.HTTPSHandler):
            def https_open(self, req):
                return wire.respond(req)

        class Http(urllib.request.HTTPHandler):
            def http_open(self, req):
                return wire.respond(req)
        self.handlers = (Https, Http)

    def respond(self, req):
        self.seen.append(req.full_url)
        code, hdrs, body = self._respond(req.full_url)
        msg = email.message_from_string("".join(f"{k}: {v}\n" for k, v in hdrs.items()))
        r = urllib.response.addinfourl(io.BytesIO(body), msg, req.full_url, code)
        r.msg = "stub"
        return r


def wire(monkeypatch, respond):
    w = StubWire(respond)
    orig = base.build_no_redirect_opener
    monkeypatch.setattr(base, "build_no_redirect_opener", lambda *h: orig(*w.handlers))
    return w


@pytest.mark.parametrize("code", [301, 302, 307])
def test_fred_through_http_fetch_refuses_redirect_and_hides_key(monkeypatch, code):
    w = wire(monkeypatch, lambda url: (code, {"Location": "https://evil.example/steal"}, b""))
    with pytest.raises(PublicSourceError, match="redirect") as e:
        fetch_fred("2026-10-19", "2026-10-22", ["DGS10"], api_key=KEY, retries=0)
    assert KEY not in str(e.value) and "?" not in str(e.value).replace("?<redacted>", "")
    assert {urllib.parse.urlsplit(u).hostname for u in w.seen} == {"api.stlouisfed.org"}


def test_ecb_through_http_fetch_enforces_size_cap(monkeypatch):
    wire(monkeypatch, lambda url: (200, {}, ECB))
    with pytest.raises(PublicSourceError, match="exceeds the 100-byte cap"):
        fetch_ecb("2026-10-21", "2026-10-22", retries=0, max_bytes=100)
    assert len(fetch_ecb("2026-10-21", "2026-10-22", retries=0, now=NOW)) == 10    # default cap: fine


def test_http_base_refused_before_anything_is_sent(monkeypatch):
    w = wire(monkeypatch, lambda url: (200, {}, b"{}"))
    with pytest.raises(PublicSourceError, match="non-https") as e:
        fetch_fred("2026-10-19", "2026-10-22", ["DGS10"], api_key=KEY, retries=0,
                   base="http://api.stlouisfed.org/fred/series/observations")
    assert w.seen == [] and KEY not in str(e.value)


def test_transient_errors_are_retried(monkeypatch):
    calls = []

    def respond(url):
        calls.append(url)
        return (503, {}, b"") if len(calls) < 3 else (200, {}, ECB)
    wire(monkeypatch, respond)
    assert len(fetch_ecb("2026-10-21", "2026-10-22", retries=3, sleep=lambda s: None, now=NOW)) == 10
    assert len(calls) == 3


# ------------------------------------------------------------------------------------------------ BIS

def test_bis_policy_rows_from_raw_bis():
    raw = pd.DataFrame({"iso": ["PHL", "PHL", "VNM", "PHL"], "series": ["POLICY_RATE"] * 3 + ["EER_REAL_BROAD"],
                        "period": ["2026-10-20", "2026-10-21", "2026-10-21", "2026-10"], "value": ["5.5", "5.5", "4.5", "99"],
                        "source": "BIS SDMX REST (stats.bis.org)"})      # SYNTHETIC values
    df = bis_policy_rows(raw, {"PHL": "PHP", "VNM": "VND"}, start="2026-10-21")
    assert len(df) == 2 and set(df["instrument"]) == {"policy_rate"} and set(df["tenor_y"]) == {0.0}
    assert dict(zip(df["iso"], df["currency"])) == {"PHL": "PHP", "VNM": "VND"} and set(df["source"]) == {"bis"}
    with pytest.raises(MarketDataError, match="no currency"):
        bis_policy_rows(raw, {"PHL": "PHP"})


# ------------------------------------------------------------------------------------------------ store + gate + CLI

def test_snapshot_round_trip_and_gate_clean(tmp_path, monkeypatch):
    fred = fetch_fred("2026-10-19", "2026-10-22", SERIES, api_key=KEY, fetcher=fred_fetcher(), now=NOW)
    ecb = fetch_ecb("2026-10-21", "2026-10-22", fetcher=lambda u, h, d=None: ECB, now=NOW)
    f1 = save_public(tmp_path, fred, now=NOW)
    save_public(tmp_path, ecb, now=NOW + dt.timedelta(seconds=1))
    man = json.loads((f1 / "manifest.json").read_text())
    assert man["provenance"]["source"] == "fred" and man["licences"] == [FRED_LICENCE]
    assert KEY not in (f1 / "manifest.json").read_text() and KEY not in (f1 / "quotes.csv").read_text()
    q = latest_market(tmp_path, "govt_yield", asof="2026-10-23")
    review = market_gate(q, asof="2026-10-22")
    assert len(review) and (review["status"] == "ok").all(), review[review["status"] != "ok"]


def test_cli_fred_saves_snapshot(tmp_path, monkeypatch, capsys):
    monkeypatch.setenv("FRED_API_KEY", KEY)
    monkeypatch.setattr(public, "http_fetch", lambda url, headers=None, data=None, **kw: fred_fetcher()(url, headers))
    rc = public.main(["--source", "fred", "--start", "2026-10-19", "--end", "2026-10-22", "--data-dir", str(tmp_path),
                      "--series", "DGS3MO,DGS10"])
    out = capsys.readouterr()
    assert rc == 0 and "gate holds: 0" in out.out and KEY not in out.out + out.err
    assert len(latest_market(tmp_path, "govt_yield")) == 2


def test_cli_dry_run_saves_nothing_and_bad_key_exits_2(tmp_path, monkeypatch, capsys):
    monkeypatch.setattr(public, "http_fetch", lambda url, headers=None, data=None, **kw: ECB)
    assert public.main(["--source", "ecb", "--start", "2026-10-21", "--end", "2026-10-22", "--data-dir", str(tmp_path),
                        "--dry-run"]) == 0
    assert not (tmp_path / "live").exists()
    monkeypatch.setenv("FRED_API_KEY", "x")
    assert public.main(["--source", "fred", "--start", "2026-10-19", "--end", "2026-10-22",
                        "--data-dir", str(tmp_path)]) == 2
    assert "not a FRED API key" in capsys.readouterr().err


def test_cli_bis_reads_raw_bis(tmp_path):
    (tmp_path / "live").mkdir()
    pd.DataFrame({"iso": ["PHL"], "series": ["POLICY_RATE"], "period": ["2026-10-21"], "value": ["5.5"],
                  "source": ["BIS SDMX REST (stats.bis.org)"]}).to_csv(tmp_path / "live" / "raw_bis.csv", index=False)
    pd.DataFrame({"iso": ["PHL"], "currency": ["PHP"]}).to_csv(tmp_path / "countries.csv", index=False)
    assert public.main(["--source", "bis", "--start", "2026-10-01", "--end", "2026-10-22",
                        "--data-dir", str(tmp_path)]) == 0
    q = latest_market(tmp_path, "policy_rate")
    assert q["value"].tolist() == [5.5] and q["licence"].iloc[0] == public.BIS_LICENCE


def _chain_text(e) -> str:
    """Everything reachable through the exception chain, as repr and str (what a Sentry-style serialiser sees)."""
    out, seen = [], set()
    while e is not None and id(e) not in seen:
        seen.add(id(e))
        out += [repr(e), str(e), repr(getattr(e, "doc", ""))]
        e = e.__cause__ or e.__context__
    return " ".join(out)


def test_fred_errors_drop_the_exception_chain_holding_the_key():
    """SEC-A-003 I1 (probe P5): no __context__ / __cause__ keeps the URL with the key."""
    def boom(url, headers, data=None):
        raise RuntimeError(f"failed GET {url} key={KEY}")
    with pytest.raises(PublicSourceError) as e:
        fetch_fred("2026-10-19", "2026-10-22", ["DGS10"], api_key=KEY, fetcher=boom, retries=0)
    assert e.value.__context__ is None and e.value.__cause__ is None
    assert KEY not in repr(e.value.__context__) and KEY not in repr(e.value.__cause__)
    assert KEY not in _chain_text(e.value)

    def api_error(url, headers, data=None):
        return json.dumps({"error_code": 400, "error_message": f"Bad Request. api_key {KEY} is not registered"}).encode()
    with pytest.raises(PublicSourceError) as e:
        fetch_fred("2026-10-19", "2026-10-22", ["DGS10"], api_key=KEY, fetcher=api_error, retries=0)
    assert e.value.__context__ is None and KEY not in _chain_text(e.value)

    def not_json(url, headers, data=None):
        return f"<html>bad key {KEY}</html>".encode()
    with pytest.raises(PublicSourceError, match="not JSON") as e:
        fetch_fred("2026-10-19", "2026-10-22", ["DGS10"], api_key=KEY, fetcher=not_json, retries=0)
    assert e.value.__context__ is None and KEY not in _chain_text(e.value)


def test_error_labels_have_no_double_slash():
    """SEC-A-003 I5."""
    def boom(url, headers, data=None):
        raise RuntimeError("down")
    with pytest.raises(PublicSourceError) as e:
        fetch_fred("2026-10-19", "2026-10-22", ["DGS10"], api_key=KEY, fetcher=boom, retries=0)
    assert "(api.stlouisfed.org/fred/series/observations)" in str(e.value) and "//" not in str(e.value)
    with pytest.raises(PublicSourceError) as e:
        public.fetch_ecb("2026-10-19", "2026-10-22", fetcher=boom, retries=0)
    assert "data-api.ecb.europa.eu/service/data/" in str(e.value) and "//" not in str(e.value)
