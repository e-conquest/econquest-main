"""Weekly risk monitor (EQ-C-0009): built from the latest archived run (or run_latest.json), compared with the run a
week earlier; stamped with run_id, as_of and data_hash; carries the input caveats and the disclaimer."""
import html as _h
import json
import sys
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
sys.path.insert(0, str(Path(__file__).resolve().parent))
from econquest.persistence import Store  # noqa: E402
from econquest.presentation import risk_monitor as M  # noqa: E402
from econquest.presentation.report import DISCLAIMER  # noqa: E402
from test_report import make_run, make_data  # noqa: E402


def archive(out: Path, *runs):
    store = Store(out / "store")
    with store._conn() as c:
        for r in runs:
            s = r["summary"]
            c.execute("INSERT INTO runs VALUES (?,?,?,?,?,?)", (s["run_id"], s["created_at"], s["label"], "{}", "{}", json.dumps(s)))
    for r in runs:
        (store.archive / f"{r['summary']['run_id']}.json").write_text(json.dumps(r))
    return store


@pytest.fixture
def week(tmp_path):
    d = make_data(tmp_path / "data")
    out = tmp_path / "outputs"
    old = make_run(run_id="r-1013", created="2026-10-13T09:00:00+00:00", as_of="2026-10-13")
    mid = make_run(run_id="r-1018", created="2026-10-18T09:00:00+00:00", as_of="2026-10-18", pd_b=0.06)
    cur = make_run(run_id="r-1020", created="2026-10-20T09:00:00+00:00", as_of="2026-10-20", regime_b="Crisis", pd_b=0.30, sig_b=75.0, var99=70.0)
    stress = make_run(run_id="r-1020-stress", created="2026-10-20T09:05:00+00:00", as_of="2026-10-20", var99=200.0)
    stress["summary"]["label"] = "stress-A"
    archive(out, old, mid, cur, stress)
    return d, out


def test_build_monitor_weekly_comparison(week, tmp_path):
    d, out = week
    res = M.build_monitor(out, d, tmp_path / "monitor", log=lambda *a: None)
    assert set(res) >= {"html", "md", "latest", "run_id", "as_of", "reference_run_id"}
    assert res["run_id"] == "r-1020" and res["as_of"] == "2026-10-20"                 # latest base run, not the later stress run
    assert res["reference_run_id"] == "r-1013"                                        # >= 7 days earlier, not the 2-day-old run
    html = Path(res["html"]).read_text(encoding="utf-8"); md = Path(res["md"]).read_text(encoding="utf-8")
    assert Path(res["html"]).name == "risk-monitor-2026-10-20.html" and Path(res["latest"]).read_text(encoding="utf-8") == html
    # stamps
    for s in ("<b>Run</b> r-1020", "<b>As of</b> 2026-10-20", "<b>Data hash</b> da7a", "<b>Code hash</b> c0de", "<b>Run hash</b> ru11"):
        assert s in html, s
    assert "7 days earlier" in html
    # sections
    for h in ("<h2>Headline ($mm)</h2>", "Top movers in 12-month default PD", "<h2>Regimes</h2>", "<h2>Signals and trade activations</h2>", "<h2>Input caveats</h2>"):
        assert h in html, h
    # top mover is B (+25 pp), with its regime change and the signal / trade activation
    first_row = html.split("Composite change</th></tr>")[1]
    assert first_row.startswith("<tr><td>B</td>") and "+25.00 pp" in first_row.split("</tr>")[0]
    assert "B: regime Calm -&gt; Crisis" in html and "crossed above 60" in html and "playbook trade T01 activated" in html
    assert "70.0" in html and "+10.0" in html                                         # VaR99 70 vs 60
    assert html.count(_h.escape(DISCLAIMER)) == 2 and md.count(DISCLAIMER) == 2
    assert "[restriction 6.2]" in html and "SEED for every country" in html
    assert "generation timestamp, not a model date" in html
    assert "<script" not in html and "<link" not in html
    assert md.startswith("# EconQuest weekly risk monitor 2026-10-20") and "**As of** 2026-10-20" in md and "## Input caveats" in md
    assert "| B | 30.00% | 5.00% | +25.00 pp | Crisis | Calm |" in md


def test_reference_falls_back_to_oldest_earlier_run(tmp_path):
    d = make_data(tmp_path / "data"); out = tmp_path / "outputs"
    archive(out, make_run(run_id="a", created="2026-10-18T09:00:00+00:00", as_of="2026-10-18"),
            make_run(run_id="b", created="2026-10-19T09:00:00+00:00", as_of="2026-10-19"),
            make_run(run_id="c", created="2026-10-20T09:00:00+00:00", as_of="2026-10-20"))
    res = M.build_monitor(out, d, tmp_path / "m", log=lambda *a: None)
    assert res["reference_run_id"] == "a"
    assert "No archived run is 7 or more days older" in Path(res["html"]).read_text()


def test_monitor_from_run_latest_without_store_and_without_as_of(tmp_path):
    d = make_data(tmp_path / "data"); out = tmp_path / "outputs"; out.mkdir()
    (out / "run_latest.json").write_text(json.dumps(make_run(run_id="only", as_of=None)))
    res = M.build_monitor(out, d, tmp_path / "m", log=lambda *a: None)
    html = Path(res["html"]).read_text()
    assert res["run_id"] == "only" and res["as_of"] is None and res["reference_run_id"] is None
    assert "<b>As of</b> not recorded" in html and "Run hash" not in html
    assert "Highest 12-month default PD" in html and "No run archive" in html
    assert Path(res["html"]).name == "risk-monitor-2026-10-20.html"                  # named by the run's creation date, not today
    assert not (out / "store").exists()                                              # reading does not create a store


def test_monitor_without_any_run_raises(tmp_path):
    with pytest.raises(FileNotFoundError):
        M.build_monitor(tmp_path / "empty", make_data(tmp_path / "data"), tmp_path / "m", log=lambda *a: None)


def test_monitor_escapes_run_text(tmp_path):
    d = make_data(tmp_path / "data"); out = tmp_path / "outputs"; out.mkdir()
    r = make_run(run_id="<img src=x>", as_of="2026-10-20")
    r["country"][0]["country"] = "<b>A</b>"
    (out / "run_latest.json").write_text(json.dumps(r))
    html = Path(M.build_monitor(out, d, tmp_path / "m", log=lambda *a: None)["html"]).read_text()
    assert "<img src=x>" not in html and "<b>A</b>" not in html and "&lt;b&gt;A&lt;/b&gt;" in html


def test_change_helper():
    assert M._chg(60, 70) == "+10.0" and M._chg(60, 70, pct=True) == "+16.7%"
    assert M._chg(None, 1) == "" and M._chg(0, 5, pct=True) == "" and M._chg(float("nan"), 1) == ""
