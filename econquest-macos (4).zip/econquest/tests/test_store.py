"""Run store (contract C4): round trip, idempotent re-save (gap F8), layering (EQ-A-0002)."""
import ast
import json
import math
import sqlite3
import sys
from datetime import datetime, timezone
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.persistence import Store  # noqa: E402
from econquest.persistence.jsonio import dumps  # noqa: E402

CHILD_TABLES = ("country_metrics", "country_text", "portfolio_metrics", "position_metrics", "arbitrage")


def _run(run_id="20261023T010000-base", created="2026-10-23T01:00:00+00:00", label="base", var99=66.0):
    """Smallest dict in the RunResult.to_dict() shape that save_run reads."""
    return {
        "summary": {"run_id": run_id, "label": label, "created_at": created,
                    "metrics": {"paths": 2000, "var99_mm": var99, "es99_mm": var99 * 1.3, "expected_loss_mm": 0.3},
                    "global_regime": "Calm", "versions": {"code_hash": "aaaa", "data_hash": "dddd"}},
        "settings": {"monte_carlo": {"paths": 2000}},
        "provenance": {"versions": {"code_hash": "aaaa"}},
        "country": [{"country": "Argentina", "iso": "ARG", "regime": "Stress", "pd_default": 0.12, "composite": 41.0},
                    {"country": "Brazil", "iso": "BRA", "regime": "Calm", "pd_default": 0.03, "composite": float("nan")}],
        "contributions": [{"id": "P1", "country": "Argentina", "asset_class": "hard", "notional_mm": 10.0, "expected_loss_mm": 0.5,
                           "tail_contribution_99_mm": 3.0, "liquidity_cost_99_mm": 0.1, "share_of_es99": 0.6}],
        "arbitrage": [{"id": "K1", "country": "Argentina", "platform": "poly", "side": "YES", "net_edge_pp": 4.0, "stake_k": 1.0,
                       "model_p_res": 0.2, "yes_price": 0.16, "divergence_flag": True, "read": "model above market"}],
    }


def _counts(store):
    with sqlite3.connect(store.db) as c:
        return {t: c.execute(f"SELECT COUNT(*) FROM {t}").fetchone()[0] for t in ("runs",) + CHILD_TABLES}


def test_round_trip_save_load_latest_runs_series(tmp_path):
    store = Store(tmp_path / "store")
    r1 = _run(); r2 = _run("20261023T020000-base", "2026-10-23T02:00:00+00:00", var99=70.0)
    assert store.save_run(r1) == r1["summary"]["run_id"]
    store.save_run(r2, keep_paths=True)                                   # plain dict: no paths, no error
    assert not list(store.archive.glob("*.npz"))
    runs = store.runs()
    assert [r["run_id"] for r in runs] == [r2["summary"]["run_id"], r1["summary"]["run_id"]]
    assert set(runs[0]) == {"run_id", "created_at", "label", "summary"} and runs[0]["summary"]["metrics"]["var99_mm"] == 70.0
    assert store.load(r1["summary"]["run_id"]) == json.loads(dumps(r1))
    assert store.latest()["summary"]["run_id"] == r2["summary"]["run_id"]
    assert store.latest("stress-A") is None
    s = store.series("var99_mm")
    assert list(s.columns) == ["created_at", "value"] and list(s["value"]) == [66.0, 70.0]
    c = store.series("pd_default", country="Argentina")
    assert list(c["value"]) == [0.12, 0.12]
    assert store.series("composite", country="Brazil").empty               # NaN metric is not stored
    with sqlite3.connect(store.db) as con:
        assert con.execute("SELECT position_id, value FROM position_metrics WHERE metric='share_of_es99' LIMIT 1").fetchone() == ("P1", 0.6)
        assert con.execute("SELECT flag FROM arbitrage LIMIT 1").fetchone() == (1,)


def test_save_accepts_object_with_to_dict(tmp_path):
    class Result:
        def to_dict(self):
            return _run()
    store = Store(tmp_path / "store")
    assert store.save_run(Result(), keep_paths=True) == "20261023T010000-base"
    assert _counts(store)["portfolio_metrics"] == 4


def test_resave_same_run_is_idempotent(tmp_path):
    """Regression for F8: runs used INSERT OR REPLACE but metric tables plain INSERT, so a re-save duplicated metrics."""
    store = Store(tmp_path / "store")
    store.save_run(_run())
    first = _counts(store)
    assert all(first[t] > 0 for t in first)
    store.save_run(_run())
    assert _counts(store) == first
    assert list(store.series("var99_mm")["value"]) == [66.0]
    store.save_run(_run(var99=80.0))                                      # re-save with new values replaces, not appends
    assert _counts(store) == first and list(store.series("var99_mm")["value"]) == [80.0]


def test_dumps_matches_engine_encoder_byte_for_byte():
    from econquest.engine.pipeline import dumps as engine_dumps
    obj = {"f": 1.5, "nan": float("nan"), "inf": float("inf"), "npf": np.float64(2.25), "npnan": np.float32("nan"), "npi": np.int64(7),
           "arr": np.array([1, 2]), "ts": pd.Timestamp("2026-10-23"), "dt": datetime(2026, 10, 23, tzinfo=timezone.utc),
           "nested": [{"a": (1, np.nan)}, None, True], "obj": Path("x/y"), "bool": np.bool_(True)}
    assert dumps(obj) == engine_dumps(obj)
    assert dumps(_run()) == engine_dumps(_run())
    assert json.loads(dumps(obj))["nan"] is None and not math.isnan(json.loads(dumps(obj))["npf"])


def test_persistence_does_not_import_engine_or_presentation():
    pkg = ROOT / "econquest" / "persistence"
    bad = []
    for f in pkg.glob("*.py"):
        for node in ast.walk(ast.parse(f.read_text())):
            names = []
            if isinstance(node, ast.Import):
                names = [a.name for a in node.names]
            elif isinstance(node, ast.ImportFrom):
                names = [("." * node.level) + (node.module or "")] + [a.name for a in node.names]
            bad += [f"{f.name}: {n}" for n in names if any(p in n.split(".") for p in ("engine", "presentation", "cli"))]
    assert not bad, bad
