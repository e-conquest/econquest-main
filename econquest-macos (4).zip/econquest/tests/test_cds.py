import sys
from pathlib import Path
import numpy as np
import pandas as pd
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.engine import cds


def test_bootstrap_reprices_quotes():
    tenors = [1, 3, 5, 10]; spreads = [120, 180, 250, 300]
    lams = cds.bootstrap_hazard(tenors, spreads, recovery=0.4, rate=0.04)
    assert np.all(lams > 0)
    for T, s in zip(tenors, spreads):
        assert abs(cds.fair_spread(T, tenors, lams, 0.4, 0.04) - s) < 0.05


def test_flat_hazard_matches_credit_triangle():
    lam = cds.bootstrap_hazard([5], [300], recovery=0.4, rate=0.04)[0]
    assert abs(lam - 0.03 / 0.6) / (0.03 / 0.6) < 0.03           # lambda ~ s / (1 - R)
    assert abs(cds.pd_12m([5], [lam]) - (1 - np.exp(-lam))) < 1e-9
    fair = cds.model_fair_spread(1 - np.exp(-lam), 5, 0.4, 0.04)
    assert abs(fair - 300) < 0.5


def test_table_and_relative_value():
    q = pd.DataFrame({"country": ["Argentina"] * 3 + ["Brazil"] * 2, "date": ["2026-10-20"] * 5, "tenor_y": [1, 5, 10, 1, 5],
                      "spread_bp": [900, 1200, 1300, 90, 160], "recovery": [0.3, 0.3, 0.3, 0.4, 0.4], "source": ["manual"] * 5})
    model = pd.Series({"Argentina": 0.10, "Brazil": 0.03})
    t = cds.cds_table(q, model)
    assert set(t["country"]) == {"Argentina", "Brazil"} and t["cds_pd_12m"].between(0, 1).all()
    arg = t.set_index("country").loc["Argentina"]
    assert arg["cds_pd_12m"] > 0.1 and arg["gap_bp"] > 0 and "cheap" in arg["read"]
    port = pd.DataFrame({"id": ["P1", "P2", "P3"], "country": ["Argentina", "Brazil", "Vietnam"], "asset_class": ["Eurobond", "CDS", "Eurobond"],
                         "direction": ["Long", "Long", "Long"], "notional_mm": [10, 5, 7]})
    rv = cds.eurobond_relative_value(port, t)
    assert list(rv["id"]) == ["P1", "P2"] and "favourable for long credit" in rv.iloc[0]["read"]
