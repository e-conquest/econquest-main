"""EQ-A-0038 / SEC-A-003 M1: data/market/cds_snapshots.csv is written only by the gated export. Held series and
manual quotes without a live attestation never reach it. Every number and reference entity here is SYNTHETIC
(fictional iso3 XAA, XBB). Scenarios follow the SEC-A-003 probe (P2, P3)."""
import datetime as dt

import pandas as pd
import pytest

from econquest.ingestion import ledger
from econquest.ingestion.market import cds_export
from econquest.ingestion.market.cds_export import export_gated_cds_snapshots
from econquest.ingestion.market.manual import TABLE, cell_key, enter_quotes, read_manual
from econquest.ingestion.market.schema import MARKET_COLUMNS
from econquest.ingestion.market.store import (cds_snapshots_path, export_cds_snapshots, latest_market,
                                              save_market_snapshot)

T0 = dt.datetime(2026, 10, 22, 18, 0, tzinfo=dt.timezone.utc)
D = "2026-10-22"
ROW = {"asof": D, "instrument": "cds", "iso": "XAA", "currency": "USD", "tenor_y": 5, "field": "spread_bp",
       "value": 150, "doc_clause": "CR14"}


def vendor(iso="XBB", value=300.0, tenor=5.0, source="bloomberg"):
    return {"asof": D, "instrument": "cds", "iso": iso, "currency": "USD", "tenor_y": tenor, "field": "spread_bp",
            "value": value, "unit": "bp", "doc_clause": "CR14", "source": source, "vendor_ticker": "",
            "licence": "SYNTHETIC test licence", "derived": False, "snapshot_id": "", "retrieved_utc": ""}


def snapshots_csv(d) -> pd.DataFrame:
    p = cds_snapshots_path(d)
    return pd.read_csv(p, keep_default_na=False) if p.exists() else pd.DataFrame(columns=["iso3", "value", "source"])


def test_save_alone_never_writes_cds_snapshots(tmp_path):
    enter_quotes(tmp_path, [ROW], "sam", self_approved=True, now=T0)
    save_market_snapshot(tmp_path, pd.DataFrame([vendor()], columns=MARKET_COLUMNS), now=T0 + dt.timedelta(seconds=1))
    assert not cds_snapshots_path(tmp_path).exists()
    rep = export_cds_snapshots(tmp_path)
    assert rep.appended == 2 and rep.dropped.empty and len(rep.snapshots) == 2
    assert sorted(snapshots_csv(tmp_path)["iso3"]) == ["XAA", "XBB"]


def test_held_fat_finger_is_excluded_clean_vendor_row_still_flows(tmp_path):
    enter_quotes(tmp_path, [ROW], "sam", self_approved=True, now=T0)
    assert export_gated_cds_snapshots(tmp_path).appended == 1
    # P2: self-approved fat finger 150 -> 45000 (inside the range check, caught as a jump), saved next to a clean
    # vendor quote in a later snapshot
    enter_quotes(tmp_path, [dict(ROW, value=45000)], "sam", self_approved=True, now=T0 + dt.timedelta(seconds=5))
    save_market_snapshot(tmp_path, pd.DataFrame([vendor()], columns=MARKET_COLUMNS), now=T0 + dt.timedelta(seconds=9))
    assert latest_market(tmp_path, "cds").set_index("iso")["value"]["XAA"] == 45000     # the store keeps everything
    rep = export_gated_cds_snapshots(tmp_path)
    assert rep.appended == 1                                                        # XBB vendor row only
    assert rep.dropped[["iso", "value", "check"]].values.tolist() == [["XAA", 45000.0, "gate"]]
    assert "jump: 150 -> 45000" in rep.dropped["reason"].iloc[0]
    snap = snapshots_csv(tmp_path)
    assert 45000 not in snap["value"].tolist()
    assert snap[["iso3", "value", "source"]].values.tolist() == [["XAA", 150.0, "manual"], ["XBB", 300.0, "bloomberg"]]
    assert "1 dropped (gate hold 1, attestation 0)" in rep.summary()


def test_manual_row_rejected_in_ledger_is_excluded(tmp_path):
    enter_quotes(tmp_path, [ROW], "ana", "sam", now=T0)
    ledger.record_decision(tmp_path, TABLE, cell_key(read_manual(tmp_path).iloc[-1]), "XAA", "reject", "bob",
                           approver="carol", note="wrong level (SYNTHETIC)")
    rep = export_gated_cds_snapshots(tmp_path)
    assert rep.appended == 0 and not cds_snapshots_path(tmp_path).exists()
    assert rep.dropped["check"].tolist() == ["attestation"] and "withdrawn" in rep.dropped["reason"].iloc[0]
    assert not rep.dropped["already_in_file"].any() and "WARNING" not in rep.summary()


def test_reject_after_export_is_reported_as_already_in_file(tmp_path):
    enter_quotes(tmp_path, [ROW], "ana", "sam", now=T0)
    assert export_gated_cds_snapshots(tmp_path).appended == 1
    ledger.record_decision(tmp_path, TABLE, cell_key(read_manual(tmp_path).iloc[-1]), "XAA", "reject", "bob",
                           approver="carol", note="wrong level (SYNTHETIC)")
    rep = export_gated_cds_snapshots(tmp_path)
    assert rep.appended == 0 and rep.dropped["already_in_file"].tolist() == [True]
    assert "WARNING 1 dropped rows were already in the file" in rep.summary()
    assert snapshots_csv(tmp_path)["value"].tolist() == [150.0]                    # append-only: never rewritten


def test_unattested_manual_row_is_excluded(tmp_path):
    # P3: source=manual saved straight through save_market_snapshot, never attested
    m = pd.DataFrame([vendor(iso="XAA", value=999.0, source="manual")], columns=MARKET_COLUMNS)
    m["licence"] = "n/a (hand-entered)"
    save_market_snapshot(tmp_path, m, now=T0)
    rep = export_gated_cds_snapshots(tmp_path)
    assert rep.appended == 0 and not cds_snapshots_path(tmp_path).exists()
    assert rep.dropped[["value", "check"]].values.tolist() == [[999.0, "attestation"]]
    assert "no approved market_manual attestation" in rep.dropped["reason"].iloc[0]


def test_attested_content_must_match_not_just_the_cell(tmp_path):
    enter_quotes(tmp_path, [ROW], "sam", self_approved=True, now=T0)                # 150 attested for this cell
    m = latest_market(tmp_path, "cds").assign(value=160.0, snapshot_id="", retrieved_utc="")
    save_market_snapshot(tmp_path, m, now=T0 + dt.timedelta(minutes=5))           # 160, gate-clean, not attested
    rep = export_gated_cds_snapshots(tmp_path)
    assert snapshots_csv(tmp_path)["value"].tolist() == [150.0]
    assert rep.dropped[["value", "check"]].values.tolist() == [[160.0, "attestation"]]


def test_dry_run_snapshot_filter_and_cli(tmp_path, capsys):
    enter_quotes(tmp_path, [ROW], "sam", self_approved=True, now=T0)
    s2 = save_market_snapshot(tmp_path, pd.DataFrame([vendor()], columns=MARKET_COLUMNS), now=T0 + dt.timedelta(seconds=3))
    rep = export_gated_cds_snapshots(tmp_path, dry_run=True)
    assert rep.appended == 2 and not cds_snapshots_path(tmp_path).exists()
    rep = export_gated_cds_snapshots(tmp_path, [s2.name])
    assert rep.snapshots == [s2.name] and snapshots_csv(tmp_path)["iso3"].tolist() == ["XBB"]
    with pytest.raises(ValueError, match="unknown snapshot"):
        export_gated_cds_snapshots(tmp_path, ["2026-01-01T000000Z-00000000"])
    assert cds_export.main(["--data", str(tmp_path)]) == 0
    assert "appended 1 rows" in capsys.readouterr().out
    assert snapshots_csv(tmp_path)["iso3"].tolist() == ["XBB", "XAA"]


def test_no_snapshot_raises(tmp_path):
    with pytest.raises(FileNotFoundError):
        export_gated_cds_snapshots(tmp_path)
    assert cds_export.main(["--data", str(tmp_path)]) == 2


def _save_vendor(d, value, seconds):
    return save_market_snapshot(d, pd.DataFrame([vendor(value=value)], columns=MARKET_COLUMNS),
                                now=T0 + dt.timedelta(seconds=seconds))


def test_resaved_held_value_is_not_its_own_seed(tmp_path):
    """SEC-A-003 L5 (probe Q1): 150 -> 45000 (held) -> 45000 again (a re-run import). The second 45000 is still a
    jump from the last value that passed (150), so it is dropped too."""
    _save_vendor(tmp_path, 150.0, 0)
    _save_vendor(tmp_path, 45000.0, 5)
    _save_vendor(tmp_path, 45000.0, 9)
    rep = export_gated_cds_snapshots(tmp_path)
    assert snapshots_csv(tmp_path)["value"].tolist() == [150.0]
    assert rep.dropped[["value", "check"]].values.tolist() == [[45000.0, "gate"], [45000.0, "gate"]]
    assert all("jump: 150 -> 45000" in r for r in rep.dropped["reason"])
    _save_vendor(tmp_path, 160.0, 12)                                               # a sane level flows again
    assert export_gated_cds_snapshots(tmp_path).appended == 1
    assert snapshots_csv(tmp_path)["value"].tolist() == [150.0, 160.0]


def test_resaved_held_value_dropped_even_when_only_that_snapshot_is_exported(tmp_path):
    _save_vendor(tmp_path, 150.0, 0)
    _save_vendor(tmp_path, 45000.0, 5)
    s3 = _save_vendor(tmp_path, 45000.0, 9)
    rep = export_gated_cds_snapshots(tmp_path, [s3.name])
    assert rep.appended == 0 and rep.dropped["check"].tolist() == ["gate"]


def test_market_gate_review_seeds_only_from_passed_rows(tmp_path):
    """The helper offered to cli._market_gate (handoff to Team C): same seed rule for the latest-market review."""
    _save_vendor(tmp_path, 150.0, 0)
    _save_vendor(tmp_path, 45000.0, 5)
    _save_vendor(tmp_path, 45000.0, 9)
    review, cur = cds_export.market_gate_review(tmp_path)
    assert cur["value"].tolist() == [45000.0]
    assert review["status"].tolist() == ["hold"] and review["seed"].tolist() == [150.0]
    review, _ = cds_export.market_gate_review(tmp_path, as_of=D)
    assert review["status"].tolist() == ["hold"]
