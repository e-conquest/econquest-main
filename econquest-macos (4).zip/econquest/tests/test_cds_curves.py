"""EQ-B-0048: CDS term structure bootstrap from point-in-time snapshots (engine/cds_curves.py).

All quotes here are SYNTHETIC (tests/fixtures/cds/cds_snapshots_synthetic.csv, fictional iso3 codes XAA-XDD)."""
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.config import Settings  # noqa: E402
from econquest.engine import cds as cds_mod  # noqa: E402
from econquest.engine import cds_curves as cc  # noqa: E402

FIX = ROOT / "tests" / "fixtures" / "cds"
AS_OF = "2026-10-23"


def _snap():
    return pd.read_csv(FIX / "cds_snapshots_synthetic.csv")


def _rows(iso, tenors, values, qt="par_spread", recovery=0.4, running=None, as_of="2026-10-20", sid="S1"):
    return pd.DataFrame({"snapshot_id": sid, "as_of": as_of, "iso3": iso, "instrument": "CDS", "tenor_y": tenors,
                         "quote_type": qt, "value": values, "running_bp": running, "recovery": recovery,
                         "source": "SYNTHETIC unit test", "licence": "synthetic-test-only"})


@pytest.mark.parametrize("s,R", [(100, 0.4), (300, 0.4), (500, 0.25), (1000, 0.4)])
def test_flat_spread_matches_credit_triangle(s, R):
    ct, sm, _ = cc.curves(_rows("XAA", [1, 2, 3, 5, 7, 10], [s] * 6, recovery=R), as_of=AS_OF)
    lam = ct["hazard_fwd"].to_numpy()
    assert np.allclose(lam, lam[0], rtol=1e-6)                       # flat spreads -> flat hazard
    assert abs(lam[0] - s / 1e4 / (1 - R)) / (s / 1e4 / (1 - R)) < 0.02
    row = sm.iloc[0]
    assert row["pd_1y_rn"] == pytest.approx(1 - np.exp(-lam[0]), rel=1e-9)
    assert row["pd_5y_cum_rn"] == pytest.approx(1 - np.exp(-5 * lam[0]), rel=1e-9)
    assert row["flags"] == "" and ct["reprice_error_bp"].abs().max() < 1e-6


def test_hand_number_300bp_r40():
    """Documented hand check: 300 bp flat, R 0.40, r 4%, quarterly -> hazard 0.04975 (s/(1-R) = 0.05)."""
    ct, sm, _ = cc.curves(_snap(), as_of=AS_OF)
    xaa = sm.set_index("iso3").loc["XAA"]
    assert xaa["hazard_1y"] == pytest.approx(0.049753, abs=2e-6)
    assert xaa["pd_1y_rn"] == pytest.approx(0.048535, abs=2e-6)
    assert xaa["pd_5y_cum_rn"] == pytest.approx(0.220236, abs=2e-6)


def test_upward_curve_reprices_every_tenor():
    ct, sm, _ = cc.curves(_snap(), as_of=AS_OF)
    g = ct[ct["iso3"] == "XBB"]
    assert (g["reprice_error_bp"].abs() < 1e-6).all()
    assert np.allclose(g["par_spread_bp"], [100, 130, 160, 200, 230, 250], atol=1e-6)
    assert (np.diff(g["cum_pd"]) > 0).all() and (g["hazard_fwd"] > 0).all()
    assert sm.set_index("iso3").loc["XBB", "recovery_source"] == "cds.recovery"   # blank recovery -> settings default


def test_point_in_time_never_reads_later_snapshots():
    snap = _snap()
    ct, sm, _ = cc.curves(snap, as_of=AS_OF)
    xaa = sm.set_index("iso3").loc["XAA"]
    assert xaa["snapshot_id"] == "SYN-XAA-1" and xaa["spread_5y_bp"] == pytest.approx(300, abs=1e-6)   # -2 dated after, -3 captured after
    ct2, sm2, _ = cc.curves(snap, as_of="2026-10-31")
    assert sm2.set_index("iso3").loc["XAA", "snapshot_id"] == "SYN-XAA-2"
    ct0, sm0, _ = cc.curves(snap, as_of="2026-01-01")
    assert ct0.empty and sm0.empty


def test_snapshot_with_mixed_vintages_keeps_every_tenor():
    """Regression (EQ-B-0048 review): rows of one snapshot loaded at different vintages are all kept."""
    q = _rows("XAA", [1, 2, 3, 5, 7, 10], [300] * 6)
    q["vintage"] = ["2026-10-20", "2026-10-20", "2026-10-21", "2026-10-21", "2026-10-22", "2026-10-22"]
    ct, sm, issues = cc.curves(q, as_of=AS_OF)
    assert ct["tenor_y"].tolist() == [1, 2, 3, 5, 7, 10] and issues == []


def test_later_vintage_supersedes_same_tenor_and_late_tenor_is_reported():
    q = _rows("XAA", [1, 5, 10], [300, 300, 300])
    q["vintage"] = "2026-10-20"
    fix = _rows("XAA", [5], [400]).assign(vintage="2026-10-22")      # correction of the 5y row, known by as_of
    late = _rows("XAA", [7], [350]).assign(vintage="2026-10-25")     # loaded after as_of: must not be read
    ct, sm, issues = cc.curves(pd.concat([q, fix, late], ignore_index=True), as_of=AS_OF)
    assert ct["tenor_y"].tolist() == [1, 5, 10]
    assert ct.set_index("tenor_y").loc[5.0, "par_spread_bp"] == pytest.approx(400, abs=1e-6)
    assert any("superseded 1 row" in i and "XAA S1 5y" in i for i in issues)
    assert any("vintage after as_of" in i and "XAA S1 7y" in i for i in issues)


def test_duplicate_tenor_keeps_last_row_in_input_order():
    q = _rows("XAA", [5, 1, 5], [300, 200, 450])
    fit = cc.bootstrap_curve(q, 0.4, 0.04, 4)
    assert "duplicate_tenor" in fit["flags"] and fit["par_fit_bp"][-1] == pytest.approx(450, abs=1e-6)


def test_as_of_comes_from_settings_not_the_clock():
    s = Settings(raw={"as_of": AS_OF})
    _, sm, _ = cc.curves(_snap(), settings=s)
    assert sm.set_index("iso3").loc["XAA", "snapshot_id"] == "SYN-XAA-1"
    with pytest.raises(ValueError):
        cc.curves(_snap())


def test_negative_forward_hazard_is_flagged_not_raised():
    ct, sm, _ = cc.curves(_snap(), as_of=AS_OF)
    g = ct[ct["iso3"] == "XCC"]
    flags = sm.set_index("iso3").loc["XCC", "flags"]
    assert "negative_forward_hazard_3y" in flags and "inverted_curve" in flags
    assert (g["hazard_fwd_raw"] < 0).any() and (g["hazard_fwd"] >= 0).all()
    assert (np.diff(g["survival"]) <= 1e-12).all()                   # used curve stays arbitrage-free
    assert sm.set_index("iso3").loc["XCC", "max_abs_reprice_error_bp"] > 1.0   # the floor's cost is reported
    assert g["recovery"].iloc[0] == 0.25


def test_upfront_quote_round_trips_to_par():
    s, R, c, r, f = 500.0, 0.4, 100.0, 0.04, 4
    lam = cds_mod.bootstrap_hazard([5], [s], R, r, f)
    prem, prot = cds_mod._legs(c, 5, [5], lam, R, r, f)
    upfront_pts = (prot - prem) * 100.0                            # points the buyer pays for a 100 bp coupon
    ct, sm, _ = cc.curves(_rows("XDD", [5], [upfront_pts], qt="upfront", recovery=R, running=c), as_of=AS_OF)
    assert ct["hazard_fwd"].iloc[0] == pytest.approx(lam[0], rel=1e-8)
    assert sm["spread_5y_bp"].iloc[0] == pytest.approx(s, abs=1e-6)
    assert "upfront_converted" in sm["flags"].iloc[0]


def test_supplied_discount_curve():
    q = _rows("XAA", [1, 5, 10], [200, 300, 350])
    _, flat, _ = cc.curves(q, as_of=AS_OF)
    _, same, _ = cc.curves(q, as_of=AS_OF, discount_curve={0.5: 0.04, 10: 0.04})
    assert same["hazard_1y"].iloc[0] == pytest.approx(flat["hazard_1y"].iloc[0], rel=1e-10)
    _, steep, _ = cc.curves(q, as_of=AS_OF, discount_curve=lambda t: 0.01 + 0.005 * np.asarray(t))
    assert steep["pd_5y_cum_rn"].iloc[0] != pytest.approx(flat["pd_5y_cum_rn"].iloc[0], rel=1e-6)


def test_schema_validation():
    with pytest.raises(ValueError, match="missing required"):
        cc.curves(_snap().drop(columns=["quote_type"]), as_of=AS_OF)
    bad = pd.concat([_rows("XAA", [5], [300]), _rows("XEE", [5], ["n/a"]), _rows("XFF", [5], [10.0], qt="upfront")])
    ct, sm, issues = cc.curves(bad, as_of=AS_OF)
    assert list(sm["iso3"]) == ["XAA"]
    assert any("value missing" in i for i in issues) and any("upfront without running_bp" in i for i in issues)


def test_synthetic_source_is_marked():
    _, sm, _ = cc.curves(_snap(), as_of=AS_OF)
    assert sm["synthetic"].all()


def test_defaults_match_assumptions_and_cli():
    raw = json.loads((ROOT / "data" / "assumptions.json").read_text())["cds"]
    p = cc.cds_params(Settings(raw={"cds": raw}))
    assert p["recovery"] == raw["recovery"] and p["risk_free"] == raw["risk_free"] and p["frequency"] == raw["frequency"]
    assert cc.cds_params(None) == {"recovery": 0.4, "risk_free": 0.04, "frequency": 4, "reference_tenor_y": 5.0}


def test_curve_fixture_contract_is_current():
    """tests/fixtures/cds/cds_curves_fixture.csv is the shape handed to Team C (EQ-C-0046); regenerate on purpose."""
    ct, _, _ = cc.curves(_snap(), as_of=AS_OF)
    fx = pd.read_csv(FIX / "cds_curves_fixture.csv", keep_default_na=False)
    assert list(fx.columns) == list(ct.columns)
    assert np.allclose(fx["hazard_fwd"].astype(float), ct["hazard_fwd"], atol=1e-9)


# ------------------------------------------------ HO-20261023-A-B-010/011/012: Team A market store (MARKET_COLUMNS)
# tests/fixtures/market/quotes_sample.csv is SYNTHETIC (source `synthetic`, licence "synthetic test fixture - not
# market data"); its BRA/ARG codes are replaced by the fictional XAA/XBB so no real entity carries made-up spreads.
import datetime as dt  # noqa: E402

from econquest.ingestion.market.store import save_market_snapshot  # noqa: E402

MARKET_FIX = ROOT / "tests" / "fixtures" / "market" / "quotes_sample.csv"
SAVED = dt.datetime(2026, 10, 20, 22, 30, tzinfo=dt.timezone.utc)


def _market():
    m = pd.read_csv(MARKET_FIX, dtype=str, keep_default_na=False)
    return m.replace({"iso": {"BRA": "XAA", "ARG": "XBB"}})


def test_curves_from_market_store_point_in_time(tmp_path):
    folder = save_market_snapshot(tmp_path, _market(), now=SAVED)
    ct, sm, issues = cc.curves_from_market(tmp_path, as_of=AS_OF)
    assert issues == [] and set(sm["iso3"]) == {"XAA", "XBB"} and sm["synthetic"].all()
    s = sm.set_index("iso3")
    assert s["snapshot_id"].str.startswith(folder.name + ":").all()                # snapshot id reaches the audit column
    assert s.at["XBB", "recovery"] == 0.25 and s.at["XBB", "recovery_source"] == "quote"
    assert ct[ct["iso3"] == "XAA"]["tenor_y"].tolist() == [1, 3, 5, 10]
    assert ct["reprice_error_bp"].abs().max() < 1e-6
    assert cc.par_spread_at(ct, "XAA", 5.0) == pytest.approx(200.0, abs=1e-6)
    with pytest.raises(FileNotFoundError):                                            # saved after 2026-10-19: no fallback
        cc.curves_from_market(tmp_path, as_of="2026-10-19")
    with pytest.raises(FileNotFoundError):
        cc.curves_from_market(tmp_path / "empty", as_of=AS_OF)


def test_market_store_newest_snapshot_per_iso_and_date_is_authoritative(tmp_path):
    """HO-20261023-A-B-012: a later capture of the same (iso3, as_of) wins whole, even when the older one carries a
    later vintage; the older capture is reported. A capture saved after as_of is never read."""
    save_market_snapshot(tmp_path, _market(), now=SAVED)
    fix = _market()
    fix = fix[(fix["iso"] == "XAA") & (fix["instrument"] == "cds") & (fix["field"] == "spread_bp") & (fix["tenor_y"] == "5")]
    fix = fix.assign(value="260", source="manual", licence="n/a (hand-entered)", retrieved_utc="2026-10-20T21:00:00Z")
    second = save_market_snapshot(tmp_path, fix, now=SAVED + dt.timedelta(days=1))   # saved 2026-10-21
    ct, sm, issues = cc.curves_from_market(tmp_path, as_of=AS_OF)
    xaa = sm.set_index("iso3").loc["XAA"]
    assert xaa["snapshot_id"].startswith(second.name + ":") and xaa["tenors"] == "5"
    assert cc.par_spread_at(ct, "XAA", 5.0) == pytest.approx(260.0, abs=1e-6)
    assert any("older capture" in i and "XAA" in i for i in issues)
    _, sm0, _ = cc.curves_from_market(tmp_path, as_of="2026-10-20")                  # second saved after: first wins
    assert sm0.set_index("iso3").at["XAA", "spread_5y_bp"] == pytest.approx(200.0, abs=1e-6)


def test_frame_ranks_store_ids_by_save_time():
    """Same rule on a SNAPSHOT_COLUMNS frame (data/market/cds_snapshots.csv): the newest store id per (iso3, as_of)
    wins over an older one with a later vintage; a row whose vintage is after as_of is not read."""
    old = _rows("XAA", [1, 5], [100, 200], sid="2026-10-20T220000Z-aaaaaaaa:XAA:2026-10-20:bloomberg:USD:CR14").assign(vintage="2026-10-22")
    new = _rows("XAA", [1, 5], [110, 210], sid="2026-10-21T090000Z-bbbbbbbb:XAA:2026-10-20:manual:USD:CR14").assign(vintage="2026-10-20")
    late = _rows("XAA", [1, 5], [500, 600], sid="2026-10-24T090000Z-cccccccc:XAA:2026-10-20:lseg:USD:CR14").assign(vintage="2026-10-24")
    ct, sm, issues = cc.curves(pd.concat([old, new, late], ignore_index=True), as_of=AS_OF)
    assert sm.iloc[0]["snapshot_id"].startswith("2026-10-21T090000Z-bbbbbbbb")
    assert ct["par_spread_bp"].tolist() == pytest.approx([110, 210], abs=1e-6)
    assert any("older capture" in i and "aaaaaaaa" in i for i in issues)
    assert not any("cccccccc" in i for i in issues if "older capture" in i)


def test_derived_cds_rows_never_reach_a_curve(tmp_path):
    """HO-20261023-A-B-011: rows with derived=True are indicative; they are excluded and reported, never used."""
    m = _market()
    d = m[(m["iso"] == "XAA") & (m["field"] == "spread_bp") & (m["instrument"] == "cds")].copy()
    d = d.assign(value="9999", derived="true", source="derived_cip")
    save_market_snapshot(tmp_path, pd.concat([m, d], ignore_index=True), now=SAVED)
    ct, sm, issues = cc.curves_from_market(tmp_path, as_of=AS_OF)
    assert cc.par_spread_at(ct, "XAA", 5.0) == pytest.approx(200.0, abs=1e-6)
    assert "derived_cip" not in ";".join(sm["source"]) and any("excluded 4 derived" in i for i in issues)


def test_frame_never_reads_a_capture_saved_after_as_of():
    """Regression (EQ-B-0056 review, AGENT-08): ids saved 2026-10-20 and 2026-10-24, both vintage 2026-10-20, as_of
    2026-10-23: the 10-24 save must not win (look-ahead); with only the 10-24 save there is no curve at all."""
    early = _rows("XAA", [1, 5], [100, 200], sid="2026-10-20T220000Z-aaaaaaaa:XAA:2026-10-20:bloomberg:USD:CR14").assign(vintage="2026-10-20")
    late = _rows("XAA", [1, 5], [500, 600], sid="2026-10-24T090000Z-cccccccc:XAA:2026-10-20:lseg:USD:CR14").assign(vintage="2026-10-20")
    ct, sm, issues = cc.curves(pd.concat([early, late], ignore_index=True), as_of=AS_OF)
    assert sm.iloc[0]["snapshot_id"].startswith("2026-10-20T220000Z-aaaaaaaa")
    assert ct["par_spread_bp"].tolist() == pytest.approx([100, 200], abs=1e-6) and not any("cccccccc" in i for i in issues)
    ct2, sm2, _ = cc.curves(late, as_of=AS_OF)
    assert ct2.empty and sm2.empty
    _, sm3, _ = cc.curves(late, as_of="2026-10-24")                    # saved on D itself: read
    assert sm3.iloc[0]["snapshot_id"].startswith("2026-10-24T090000Z-cccccccc")
