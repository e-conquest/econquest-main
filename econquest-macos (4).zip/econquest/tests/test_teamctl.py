"""teamctl: ids, handoff lifecycle, ownership guard, catalog and Jira export."""
import csv
import importlib.util
import json
import shutil
from pathlib import Path

import pytest

REPO = Path(__file__).resolve().parent.parent


def load_teamctl(tmp_path):
    spec = importlib.util.spec_from_file_location("teamctl", REPO / "team" / "teamctl.py")
    mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(mod)
    team = tmp_path / "team"
    team.mkdir()
    shutil.copytree(REPO / "team" / "templates", team / "templates")
    shutil.copy(REPO / "team" / "ownership.csv", team / "ownership.csv")
    mod.ROOT, mod.TEAM_DIR = tmp_path, team
    return mod


@pytest.fixture
def tc(tmp_path, monkeypatch):
    monkeypatch.delenv("ECONQUEST_TEAM", raising=False)
    return load_teamctl(tmp_path)


def test_ticket_ids_are_per_team_and_sequential(tc, capsys):
    tc.main(["ticket", "new", "--team", "A", "--summary", "one"])
    tc.main(["ticket", "new", "--team", "A", "--summary", "two"])
    tc.main(["ticket", "new", "--team", "B", "--summary", "three"])
    assert capsys.readouterr().out.split() == ["EQ-A-0001", "EQ-A-0002", "EQ-B-0001"]


def test_ready_needs_points_and_agent(tc):
    tc.main(["ticket", "new", "--team", "A", "--summary", "x"])
    with pytest.raises(SystemExit):
        tc.main(["ticket", "move", "EQ-A-0001", "--team", "A", "--status", "Ready"])
    tc.main(["ticket", "new", "--team", "A", "--summary", "y", "--points", "3", "--agent", "AGENT-06"])
    tc.main(["ticket", "move", "EQ-A-0002", "--team", "A", "--status", "Ready"])
    assert tc.read_board("A")[1]["status"] == "Ready"


def test_handoff_lifecycle_logs_both_sides_and_passes_check(tc, capsys):
    tc.main(["ticket", "new", "--team", "A", "--summary", "imports series", "--points", "3", "--agent", "AGENT-06"])
    tc.main(["handoff", "new", "--from", "A/AGENT-06", "--to", "B/AGENT-05", "--ticket", "EQ-A-0001",
             "--type", "contract-change", "--title", "Add imports column to indicators.csv"])
    hid = Path(capsys.readouterr().out.split()[-1]).stem
    assert tc.HO_RE.match(hid)
    with pytest.raises(SystemExit):  # cannot close without a response
        tc.main(["handoff", "done", hid, "--by", "B/AGENT-05"])
    tc.main(["handoff", "accept", hid, "--by", "B/AGENT-05"])
    tc.main(["handoff", "done", hid, "--by", "B/AGENT-05", "--response", "Scorecard reads it from EQ-B-0003."])
    meta, body = tc.parse_front((tc.TEAM_DIR / "handoffs" / f"{hid}.md").read_text())
    assert meta["status"] == "done" and meta["accepted_by"] == "B/AGENT-05"
    assert "EQ-B-0003" in tc.response_text(body)
    assert [r["action"] for r in tc.read_log("A")] == ["handoff_sent"]
    assert [r["action"] for r in tc.read_log("B")] == ["handoff_accepted", "handoff_done"]
    assert tc.run_checks(None, []) == []


def test_check_flags_bad_handoff(tc):
    (tc.TEAM_DIR / "handoffs").mkdir()
    (tc.TEAM_DIR / "handoffs" / "HO-20261023-A-B-001.md").write_text(
        "---\nid: HO-20261023-A-B-001\nfrom: A/AGENT-06\nto: B/AGENT-99\nticket: EQ-A-0042\ntype: work\n"
        "priority: normal\nstatus: done\ncreated: 2026-10-23\ndue: 2026-10-24\nbranch:\naccepted_by:\n---\n"
        "## Response\n")
    problems = " | ".join(tc.run_checks(None, []))
    assert "bad to" in problems and "not on any board" in problems and "empty Response" in problems


def test_ownership_most_specific_rule_wins(tc):
    assert tc.owner_of("econquest/engine/garch.py")["team"] == "B"
    assert tc.owner_of("econquest/ingestion/feeds.py")["team"] == "A"
    assert tc.owner_of("docs/validation/data-pipeline.md")["team"] == "A"
    assert tc.owner_of("docs/validation/garch-dcc.md")["team"] == "B"
    assert tc.owner_of("econquest/cli.py")["team"] == "C"
    assert tc.owner_of("nowhere/else.py") is None


def test_ownership_keeps_leading_dot_dirs(tc):
    # regression: lstrip("./") turned .github/... into github/... (UNOWNED)
    assert tc.owner_of(".github/workflows/ci.yml")["team"] == "C"
    assert tc.owner_of("./.claude/agents/x.md")["team"] == "C"
    assert tc.owner_of("./econquest/cli.py")["team"] == "C"


def test_check_blocks_cross_team_edits(tc):
    problems = tc.run_checks("A", ["econquest/ingestion/feeds.py", "econquest/engine/garch.py",
                                   "tests/test_feeds.py", "team/logs/B.jsonl", "team/board/A.csv"])
    assert len(problems) == 2
    assert any("garch.py: owned by team B" in p for p in problems)
    assert any("team/logs/B.jsonl" in p for p in problems)


def test_catalog_and_jira_export(tc, tmp_path):
    shutil.copytree(REPO / "econquest", tmp_path / "econquest", ignore=shutil.ignore_patterns("__pycache__"))
    shutil.copytree(REPO / "tests", tmp_path / "tests", ignore=shutil.ignore_patterns("__pycache__", "seed_data"))
    tc.main(["catalog"])
    rows = json.loads((tc.TEAM_DIR / "catalog" / "modules.json").read_text())
    pipeline = next(r for r in rows if r["module"] == "econquest.engine.pipeline")
    assert pipeline["team"] == "B" and "run_pipeline" in pipeline["public_functions"]
    assert "Cross-team imports" in (tc.TEAM_DIR / "catalog" / "modules.md").read_text()
    tc.main(["ticket", "new", "--team", "B", "--summary", "as-of date", "--gov", "GOV-012", "--points", "2",
             "--agent", "AGENT-03"])
    tc.main(["jira-export"])
    with (tc.TEAM_DIR / "board" / "jira-import.csv").open() as f:
        rec = list(csv.DictReader(f))[0]
    assert rec["Issue Id"] == "EQ-B-0001" and "gov-012" in rec["Labels"] and rec["Status"] == "To Do"


def test_checkpoint_diff_revert_without_git(tc, tmp_path, capsys):
    (tmp_path / "econquest" / "ingestion").mkdir(parents=True)
    feeds = tmp_path / "econquest" / "ingestion" / "feeds.py"
    feeds.write_text("A = 1\n")
    tc.main(["checkpoint", "econquest/ingestion/feeds.py", "econquest/ingestion/new.py", "--ticket", "EQ-A-0001"])
    with pytest.raises(SystemExit):  # another team's file cannot be checkpointed by team A
        tc.main(["checkpoint", "econquest/engine/garch.py", "--ticket", "EQ-A-0001"])
    feeds.write_text("A = 2\n")
    (tmp_path / "econquest" / "ingestion" / "new.py").write_text("B = 1\n")
    capsys.readouterr()
    tc.main(["diff", "--ticket", "EQ-A-0001"])
    out = capsys.readouterr().out
    assert "-A = 1" in out and "+A = 2" in out and "+B = 1" in out
    tc.main(["revert", "--ticket", "EQ-A-0001"])
    assert feeds.read_text() == "A = 1\n"
    assert not (tmp_path / "econquest" / "ingestion" / "new.py").exists()


def test_checkpoint_refusal_saves_nothing_and_a_rerun_keeps_the_original(tc, tmp_path):
    # regression (SEC-C-008, EQ-C-0066, reported by AGENT-10): a refused path exited after earlier files were copied
    # but before manifest.json was written, so the rerun after editing replaced the saved original
    (tmp_path / "econquest" / "ingestion").mkdir(parents=True)
    feeds = tmp_path / "econquest" / "ingestion" / "feeds.py"
    feeds.write_text("A = 1\n")
    with pytest.raises(SystemExit, match="nothing was checkpointed"):
        tc.main(["checkpoint", "econquest/ingestion/feeds.py", "econquest/engine/garch.py", "--ticket", "EQ-A-0001"])
    assert not (tc.cp_dir("EQ-A-0001") / "files" / "econquest/ingestion/feeds.py").exists()
    # a copy left by the old behaviour (no manifest entry) is kept, not replaced by the edited file
    saved = tc.cp_dir("EQ-A-0001") / "files" / "econquest/ingestion/feeds.py"
    saved.parent.mkdir(parents=True); saved.write_text("A = 1\n")
    feeds.write_text("A = 2\n")
    tc.main(["checkpoint", "econquest/ingestion/feeds.py", "--ticket", "EQ-A-0001"])
    assert saved.read_text() == "A = 1\n"
    tc.main(["revert", "--ticket", "EQ-A-0001"])
    assert feeds.read_text() == "A = 1\n"
