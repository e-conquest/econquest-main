"""Layer 4 haircut fit (GOV-024, EQ-B-0037): Cruces-Trebesch style loader, Beta fits by moments and
MLE, and the `layer4.lgd_source` switch ("judgement" default, bit-identical; "fitted" off by default).

Every fit here runs on tests/fixtures/haircuts_synthetic.csv, a SYNTHETIC table drawn from known
Betas; the real fit waits on Sam's download of the Cruces-Trebesch dataset."""
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
from scipy import stats
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.config import Settings
from econquest.ingestion import load_universe
from econquest.engine import run_pipeline
from econquest.engine import layer4_severity as L4
from econquest.engine.stress import SCENARIOS

DATA = ROOT / "data"
FIX = ROOT / "tests" / "fixtures" / "haircuts_synthetic.csv"


def _settings():
    return Settings.load(DATA / "assumptions.json")


def _fitted(s, method="mle"):
    fit = L4.fit_haircuts(L4.load_haircuts(FIX))
    block = L4.fitted_lgd_block(fit, s, method=method, source="synthetic fixture")
    return s.copy_with(**{"layer4.lgd_source": "fitted", "layer4.fitted_lgd": block}), block


def test_loader_reads_fixture_and_normalises():
    df = L4.load_haircuts(FIX)
    assert len(df) == 180 and df.attrs["synthetic"]
    assert {"country", "year", "haircut_sz", "haircut_market", "debt_restructured_mm", "instrument_class", "regime"} <= set(df.columns)
    assert df["haircut_sz"].between(0, 1).all() and df["haircut_sz"].max() > 0.5     # percent -> share
    assert set(df["instrument_class"]) == {"hard", "local"}
    assert df.loc[df["instrument_class"] == "local", "regime"].isna().all()


def test_loader_refuses_missing_file_with_download_hint(tmp_path):
    with pytest.raises(FileNotFoundError, match="Cruces-Trebesch"):
        L4.load_haircuts(tmp_path / "haircuts.csv")


def test_loader_refuses_missing_columns_and_accepts_aliases(tmp_path):
    p = tmp_path / "bad.csv"; pd.DataFrame({"Country": ["X"], "Year": [2000]}).to_csv(p, index=False)
    with pytest.raises(ValueError, match="haircut_sz"):
        L4.load_haircuts(p)
    q = tmp_path / "alias.csv"
    pd.DataFrame({"Debtor": ["X", "Y"], "Date of exchange": ["2001-05-01", "2005-02-28"], "Preferred haircut": [0.4, 0.7]}).to_csv(q, index=False)
    df = L4.load_haircuts(q)
    assert list(df["year"]) == [2001, 2005] and list(df["haircut_sz"]) == [0.4, 0.7] and (df["instrument_class"] == "hard").all()


@pytest.mark.parametrize("a,b", [(2.0, 3.0), (1.2, 0.9), (6.0, 2.5)])
def test_beta_fits_recover_known_parameters(a, b):
    x = stats.beta.rvs(a, b, size=20000, random_state=np.random.default_rng(5))
    mom, mle = L4.fit_beta_mom(x), L4.fit_beta_mle(x)
    for f in (mom, mle):
        assert abs(f["mean"] - a / (a + b)) < 0.01 and abs(f["a"] - a) / a < 0.06 and abs(f["b"] - b) / b < 0.06, f
    assert mle["loglik"] >= stats.beta.logpdf(np.clip(x, 1e-4, 1 - 1e-4), mom["a"], mom["b"]).sum() - 1e-6


def test_fit_by_class_and_regime_on_fixture():
    fit = L4.fit_haircuts(L4.load_haircuts(FIX))
    assert set(fit["method"]) == {"mom", "mle"}
    groups = set(zip(fit["instrument_class"], fit["regime"]))
    assert groups == {("hard", "all"), ("local", "all"), ("hard", "Calm"), ("hard", "Stressed"), ("hard", "Crisis")}
    mle = fit[fit["method"] == "mle"].set_index(["instrument_class", "regime"])
    assert mle.at[("hard", "Calm"), "mean"] < mle.at[("hard", "Stressed"), "mean"] < mle.at[("hard", "Crisis"), "mean"]
    assert mle.at[("hard", "all"), "n"] == 150 and mle.at[("local", "all"), "n"] == 30
    # min_n: a regime group under the threshold falls back to the pooled class fit only
    few = L4.fit_haircuts(L4.load_haircuts(FIX), min_n=60)
    assert set(few["regime"]) == {"all"}


def test_judgement_default_is_bit_identical():
    s = _settings()
    assert s.get("layer4", "lgd_source") in (None, "judgement") and L4.lgd_source(s) == "judgement"
    assert L4.effective_severity(s) is s
    s2 = s.copy_with(**{"layer4.lgd_source": "judgement"})
    for base, mult, up in ((0.6, 1.0925, 0.0), (0.35, 1.0195, 0.0), (0.6, 1.18, 0.3)):
        assert L4.haircut_distribution(base, mult, s, up) == L4.haircut_distribution(base, mult, s2, up, asset_class="Eurobond") \
            == L4.beta_params(L4.expected_lgd(base, mult, up), s["layer4"]["lgd_sd"])


def test_fitted_source_replaces_baseline_and_keeps_scenario_shocks():
    s = _settings(); sf, block = _fitted(s)
    hard = block["classes"]["hard"]; local = block["classes"]["local"]
    assert hard["judgement_mean"] == s["market"]["lgd_hard"] and set(hard["implied_lgd_mult"]) == {"Calm", "Stressed", "Crisis"}
    e = L4.effective_severity(sf)
    assert e["market"]["lgd_hard"] == pytest.approx(100 * hard["mean"]) and e["market"]["lgd_local"] == pytest.approx(100 * local["mean"])
    assert L4.effective_severity(e) is e                                       # idempotent
    assert L4.lgd_sd_for(e, e["market"]["lgd_hard"] / 100) == hard["sd"]       # class found from the mean
    assert L4.lgd_sd_for(e, None, "Local bond") == local["sd"] and L4.lgd_sd_for(e, 0.7, "Equity") == s["layer4"]["lgd_sd"]
    _, sb = SCENARIOS["B"].apply(load_universe(DATA), sf)                       # +18 pp on the judgement LGD ...
    assert L4.effective_severity(sb)["market"]["lgd_hard"] == pytest.approx(100 * hard["mean"] + 18)   # ... survives the fit
    # a class without a fit keeps its judgement mean and dispersion
    only_hard = sf.copy_with(**{"layer4.fitted_lgd": {"classes": {"hard": hard}}})
    eh = L4.effective_severity(only_hard)
    assert eh["market"]["lgd_local"] == s["market"]["lgd_local"] and L4.lgd_sd_for(eh, None, "Local bond") == s["layer4"]["lgd_sd"]


def test_fitted_source_refuses_bad_config():
    s = _settings()
    with pytest.raises(ValueError, match="lgd_source"):
        L4.effective_severity(s.copy_with(**{"layer4.lgd_source": "cruces"}))
    with pytest.raises(ValueError, match="fitted_lgd"):
        L4.effective_severity(s.copy_with(**{"layer4.lgd_source": "fitted"}))


def test_fitted_lgd_reaches_simulation():
    u = load_universe(DATA); s = _settings(); sf, block = _fitted(s)
    base = run_pipeline(u, s, paths=2048)
    fit = run_pipeline(u, L4.effective_severity(sf), paths=2048)
    hard = block["classes"]["hard"]
    exp = np.clip(hard["mean"] * base.country["lgd_mult"] + base.country["lgd_uplift"], *L4.LGD_BOUNDS)
    assert np.allclose(fit.country["lgd_hard_expected"], exp)
    a, b = L4.haircut_distribution(hard["mean"], 1.0, L4.effective_severity(sf), 0.0, asset_class="Eurobond")
    assert a / (a + b) == pytest.approx(hard["mean"]) and np.sqrt(a * b / ((a + b) ** 2 * (a + b + 1))) == pytest.approx(hard["sd"])
    assert fit.metrics["expected_loss_mm"] != base.metrics["expected_loss_mm"]
