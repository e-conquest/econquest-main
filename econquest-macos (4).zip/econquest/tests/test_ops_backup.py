"""EQ-C-0022: backup, verify, tamper detection, restore round trip, retention and the restore drill."""
import datetime as dt
import io
import json
import os
import shutil
import sqlite3
import tarfile
from pathlib import Path

import pytest

from econquest.ops import backup
from econquest.persistence import Store

SEED = Path(__file__).parent / "seed_data"
NOW = dt.datetime(2026, 10, 23, 3, 30, tzinfo=dt.timezone.utc)
quiet = dict(log=lambda *_: None)


@pytest.fixture
def home(tmp_path):
    h = tmp_path / "econquest"
    shutil.copytree(SEED, h / "data")
    v = h / "data/live/vintages/2026-10-23T101500Z-abcd1234"; v.mkdir(parents=True)
    (v / "live_inputs.csv").write_text("country,key,value\nBrazil,1.1,3.2\n")
    (h / "data/live/snapshots/20261023T101500Z-pre-apply").mkdir(parents=True)
    (h / "data/live/snapshots/20261023T101500Z-pre-apply/indicators.csv").write_text("id\n1.1\n")
    (h / "data/live/review_ledger.csv").write_text("cell,decision\nBrazil/1.1,apply\n")
    (h / "data/__pycache__").mkdir(); (h / "data/__pycache__/x.pyc").write_bytes(b"junk")
    s = Store(h / "outputs/store")
    s.save_run({"summary": {"run_id": "r1", "created_at": "2026-10-22T11:00:00+00:00", "label": "base", "metrics": {"var99_mm": 1.5}}})
    (h / "outputs/run_latest.json").write_text("{}")                     # not part of the backup
    return h


def _files(root: Path, sub=("data", "outputs/store")):
    out = {}
    for s in sub:
        for p in sorted((root / s).rglob("*")):
            if p.is_file() and "__pycache__" not in p.parts:
                out[p.relative_to(root).as_posix()] = p
    return out


def test_backup_layout_manifest_and_verify(home, tmp_path):
    r = backup.create_backup(home, tmp_path / "dest", now=NOW, verify_after=True, **quiet)
    arch = Path(r["archive"])
    assert arch.parent == tmp_path / "dest" / "2026-10-23" and arch.name == "econquest-20261023T033000Z.tar.gz"
    side = json.loads(Path(r["manifest"]).read_text())
    names = set(side["files"])
    assert {"data/live/review_ledger.csv", "data/live/vintages/2026-10-23T101500Z-abcd1234/live_inputs.csv",
            "data/live/snapshots/20261023T101500Z-pre-apply/indicators.csv", "data/forecast_record.csv",
            "outputs/store/econquest.sqlite", "outputs/store/archive/r1.json"} <= names
    assert not any("__pycache__" in n or n.startswith("outputs/run_latest") for n in names)
    assert side["file_count"] == len(names) and len(side["archive_sha256"]) == 64 and side["data_hash"]
    assert r["verify"]["ok"] and backup.verify(tmp_path / "dest" / "2026-10-23", **quiet)["ok"]


def test_env_dest(home, tmp_path, monkeypatch):
    monkeypatch.setenv("ECONQUEST_BACKUP_DEST", str(tmp_path / "icloud"))
    r = backup.create_backup(home, now=NOW, **quiet)
    assert Path(r["archive"]).parent.parent == tmp_path / "icloud"
    assert backup.list_backups() == [Path(r["archive"])]


def test_tampered_archive_fails_verify(home, tmp_path):
    r = backup.create_backup(home, tmp_path / "dest", now=NOW, **quiet)
    arch = Path(r["archive"])
    b = bytearray(arch.read_bytes()); b[len(b) // 2] ^= 0xFF; arch.write_bytes(bytes(b))
    v = backup.verify(arch, **quiet)
    assert not v["ok"] and any("archive sha256" in e for e in v["errors"])


def test_tampered_member_fails_verify_even_with_fixed_archive_hash(home, tmp_path):
    r = backup.create_backup(home, tmp_path / "dest", now=NOW, **quiet)
    arch, mpath = Path(r["archive"]), Path(r["manifest"])
    members = []
    with tarfile.open(arch, "r:gz") as t:
        for ti in t:
            data = t.extractfile(ti).read()
            if ti.name == "data/indicators.csv":
                data = data.replace(b"1", b"9", 1)
            members.append((ti.name, data))
    with tarfile.open(arch, "w:gz") as t:
        for n, data in members:
            ti = tarfile.TarInfo(n); ti.size = len(data); t.addfile(ti, io.BytesIO(data))
    side = json.loads(mpath.read_text()); side["archive_sha256"] = backup._sha256_file(arch); mpath.write_text(json.dumps(side))
    v = backup.verify(arch, **quiet)
    assert not v["ok"] and v["errors"] == ["data/indicators.csv: sha256 mismatch"]
    assert backup.restore(arch, tmp_path / "t", **quiet)["ok"] is False and not (tmp_path / "t").exists()


def test_missing_member_and_manifest_edit_detected(home, tmp_path):
    r = backup.create_backup(home, tmp_path / "dest", now=NOW, **quiet)
    mpath = Path(r["manifest"])
    side = json.loads(mpath.read_text()); side["files"]["data/ghost.csv"] = {"sha256": "0" * 64, "size": 1}; mpath.write_text(json.dumps(side))
    errs = backup.verify(r["archive"], **quiet)["errors"]
    assert "data/ghost.csv: missing from the archive" in errs and any("differs from the sidecar" in e for e in errs)


def test_restore_round_trip_identical(home, tmp_path):
    r = backup.create_backup(home, tmp_path / "dest", now=NOW, **quiet)
    res = backup.restore(r["archive"], tmp_path / "restored", **quiet)
    assert res["ok"] and not res["errors"]
    src, dst = _files(home), _files(tmp_path / "restored")
    assert set(src) == set(dst)
    for rel, p in src.items():
        if rel.endswith(".sqlite"):
            q = "SELECT run_id, created_at, label, summary FROM runs ORDER BY run_id"
            with sqlite3.connect(p) as a, sqlite3.connect(dst[rel]) as b:
                assert a.execute(q).fetchall() == b.execute(q).fetchall()
        else:
            assert p.read_bytes() == dst[rel].read_bytes(), rel
    assert Store(tmp_path / "restored/outputs/store").load("r1")["summary"]["metrics"]["var99_mm"] == 1.5


def test_restore_refuses_non_empty_target(home, tmp_path):
    r = backup.create_backup(home, tmp_path / "dest", now=NOW, **quiet)
    t = tmp_path / "live"; t.mkdir(); (t / "keep.txt").write_text("x")
    with pytest.raises(backup.BackupError, match="not empty"):
        backup.restore(r["archive"], t, **quiet)


def test_unsafe_member_refused(tmp_path):
    d = tmp_path / "dest/2026-10-23"; d.mkdir(parents=True)
    arch = d / "econquest-20261023T000000Z.tar.gz"
    evil = b"pwned"
    with tarfile.open(arch, "w:gz") as t:
        ti = tarfile.TarInfo("data/../../evil.txt"); ti.size = len(evil); t.addfile(ti, io.BytesIO(evil))
        ln = tarfile.TarInfo("data/link"); ln.type = tarfile.SYMTYPE; ln.linkname = "/etc/passwd"; t.addfile(ln)
        m = json.dumps({"files": {}}).encode(); ti = tarfile.TarInfo("MANIFEST.json"); ti.size = len(m); t.addfile(ti, io.BytesIO(m))
    (d / "econquest-20261023T000000Z.manifest.json").write_text(json.dumps({"files": {}, "archive_sha256": backup._sha256_file(arch)}))
    res = backup.restore(arch, tmp_path / "t", **quiet)
    assert not res["ok"] and any("unsafe" in e for e in res["errors"]) and any("not a regular file" in e for e in res["errors"])
    assert not (tmp_path / "evil.txt").exists() and not (tmp_path / "t").exists()


def test_symlinked_data_backed_up_as_files(home, tmp_path):
    real = tmp_path / "elsewhere"; shutil.move(str(home / "data"), real); (home / "data").symlink_to(real)
    r = backup.create_backup(home, tmp_path / "dest", now=NOW, **quiet)
    assert r["files"] > 10 and backup.restore(r["archive"], tmp_path / "t", **quiet)["ok"]
    assert (tmp_path / "t/data/indicators.csv").is_file() and not (tmp_path / "t/data").is_symlink()


def test_sqlite_snapshot_is_consistent(home, tmp_path):
    r = backup.create_backup(home, tmp_path / "dest", now=NOW, **quiet)
    backup.restore(r["archive"], tmp_path / "t", **quiet)
    with sqlite3.connect(tmp_path / "t/outputs/store/econquest.sqlite") as c:
        assert c.execute("PRAGMA integrity_check").fetchone()[0] == "ok"


# --- retention -------------------------------------------------------------------------------------------------------

def test_select_retained_14_daily_8_weekly():
    days = [dt.date(2026, 10, 23) - dt.timedelta(days=i) for i in range(120)]
    keep = backup.select_retained(days)
    daily = set(days[:14])
    assert daily <= keep and len(keep) == 22
    weekly = sorted(keep - daily, reverse=True)
    assert all(d.isoweekday() == 7 for d in weekly)                       # newest day of each older ISO week (Sunday)
    assert len({d.isocalendar()[:2] for d in weekly}) == 8
    assert not ({d.isocalendar()[:2] for d in weekly} & {d.isocalendar()[:2] for d in daily})
    assert backup.select_retained(days[:5]) == set(days[:5])


def _day(dest, d):
    p = dest / d.isoformat(); p.mkdir(parents=True)
    (p / f"econquest-{d:%Y%m%d}T233000Z.manifest.json").write_text("{}")    # what create_backup leaves in a day folder
    return p


def test_prune_never_deletes_foreign_or_linked_date_folders(home, tmp_path):
    # regression (AGENT-09 review of EQ-C-0022): a dest pointed at the wrong folder (data/live/vintages holds legacy
    # date-named vintages) lost every date folder beyond the retention window, and a symlinked day folder crashed rmtree
    dest = tmp_path / "dest"
    for i in range(40):
        (dest / (dt.date(2026, 10, 23) - dt.timedelta(days=i)).isoformat()).mkdir(parents=True)   # no manifest: not ours
    other = _day(tmp_path / "elsewhere", dt.date(2025, 1, 1))
    (dest / "2025-01-01").symlink_to(other, target_is_directory=True)
    for i in range(30):
        _day(dest, dt.date(2026, 6, 1) - dt.timedelta(days=i))
    backup.prune_backups(dest, **quiet)
    assert len([p for p in dest.iterdir() if not any(p.glob("econquest-*.manifest.json"))]) == 40
    assert (dest / "2025-01-01").is_symlink() and other.exists()


def test_backup_refuses_dest_inside_a_source(home):
    for sub in ("data/live/vintages", "data", "outputs/store/x"):
        with pytest.raises(backup.BackupError, match="inside"):
            backup.create_backup(home, home / sub, now=NOW, **quiet)


def test_prune_only_touches_date_folders(tmp_path):
    dest = tmp_path / "dest"
    for i in range(40):
        _day(dest, dt.date(2026, 10, 23) - dt.timedelta(days=i))
    (dest / "manual-copy").mkdir(); (dest / "2026-13-99").mkdir()
    removed = backup.prune_backups(dest, **quiet)
    left = sorted(p.name for p in dest.iterdir())
    # daily: Oct 10-23; the week of Oct 5-11 is covered by Oct 10/11, so weekly copies: Oct 4, Sep 27, Sep 20
    assert len(removed) == 40 - 14 - 3 and "manual-copy" in left and "2026-13-99" in left
    assert {"2026-10-23", "2026-10-10", "2026-10-04", "2026-09-27", "2026-09-20"} <= set(left) and "2026-10-09" not in left


def test_backup_prunes_by_default(home, tmp_path):
    dest = tmp_path / "dest"
    for i in range(1, 30):
        _day(dest, NOW.date() - dt.timedelta(days=i))
    r = backup.create_backup(home, dest, now=NOW, **quiet)
    assert r["pruned"] and (dest / "2026-10-23").exists() and len([p for p in dest.iterdir()]) == len(backup.select_retained(
        [dt.date.fromisoformat(p.name) for p in dest.iterdir()]))


# --- drill and CLI entry points --------------------------------------------------------------------------------------

def test_restore_drill_passes_and_writes_report(home, tmp_path):
    backup.create_backup(home, tmp_path / "dest", now=NOW, **quiet)
    rep = backup.restore_drill(home, dest=tmp_path / "dest", now=NOW, **quiet)
    assert rep["ok"] and rep["restore_ok"] and rep["smoke"]["ok"] and rep["within_target"]
    assert rep["smoke"]["countries"] == 18 and rep["smoke"]["runs_in_store"] == 1 and rep["smoke"]["latest_run"] == "r1"
    assert rep["smoke"]["data_hash"] and rep["duration_seconds"] < 4 * 3600
    saved = json.loads((home / "outputs/logs/restore-drill-20261023T033000Z.json").read_text())
    assert saved["ok"] and json.loads((home / "outputs/restore_drill.json").read_text())["backup"] == rep["backup"]
    assert not list(Path(rep["backup"]).parent.glob("*.partial"))


def test_restore_drill_fails_on_tamper_and_slow(home, tmp_path, monkeypatch):
    r = backup.create_backup(home, tmp_path / "dest", now=NOW, **quiet)
    assert not backup.restore_drill(home, dest=tmp_path / "dest", target_hours=0, now=NOW, **quiet)["ok"]   # over target
    arch = Path(r["archive"]); b = bytearray(arch.read_bytes()); b[100] ^= 1; arch.write_bytes(bytes(b))
    rep = backup.restore_drill(home, backup=arch, now=NOW, **quiet)
    assert not rep["ok"] and not rep["restore_ok"]


def test_drill_with_no_backup(home, tmp_path):
    with pytest.raises(backup.BackupError):
        backup.restore_drill(home, dest=tmp_path / "none", **quiet)


def test_main_entry_points(home, tmp_path):
    dest = str(tmp_path / "dest")
    assert backup.main(["--home", str(home), "--dest", dest, "--verify"]) == 0
    a = backup.list_backups(dest)[-1]
    assert backup.main(["--home", str(home), "--verify-only", str(a)]) == 0
    assert backup.main(["drill", "--home", str(home), "--dest", dest]) == 0
    a.write_bytes(b"broken")
    assert backup.main(["--home", str(home), "--verify-only", str(a)]) == 1
    assert backup.main(["--home", str(tmp_path / "nohome"), "--dest", dest]) == 2


# --- file modes (HO-20261024-A-C-006, SEC-A-006 L7, EQ-C-0070) -------------------------------------------------------

VINTAGE = "data/live/vintages/2026-10-23T101500Z-abcd1234"
SNAP = "data/live/snapshots/20261023T101500Z-pre-apply"


def _mode(p: Path) -> int:
    return p.stat().st_mode & 0o777


def _make_read_only(home):
    for rel in (f"{VINTAGE}/live_inputs.csv", f"{SNAP}/indicators.csv"):
        (home / rel).chmod(0o444)
    (home / "data/indicators.csv").chmod(0o640)


def test_manifest_records_modes(home, tmp_path):
    _make_read_only(home)
    r = backup.create_backup(home, tmp_path / "dest", now=NOW, **quiet)
    side = json.loads(Path(r["manifest"]).read_text())
    assert side["format"] == 2
    assert side["files"][f"{VINTAGE}/live_inputs.csv"]["mode"] == "0444"
    assert side["files"]["data/indicators.csv"]["mode"] == "0640"
    with tarfile.open(r["archive"], "r:gz") as t:
        assert t.getmember(f"{VINTAGE}/live_inputs.csv").mode == 0o444
        assert json.loads(t.extractfile("MANIFEST.json").read())["files"] == side["files"]


def test_read_only_vintage_file_stays_read_only_after_restore(home, tmp_path):
    _make_read_only(home)
    r = backup.create_backup(home, tmp_path / "dest", now=NOW, **quiet)
    t = tmp_path / "restored"
    assert backup.restore(r["archive"], t, **quiet)["ok"]
    assert _mode(t / VINTAGE / "live_inputs.csv") == 0o444 and _mode(t / SNAP / "indicators.csv") == 0o444
    assert _mode(t / VINTAGE) == 0o555 and _mode(t / SNAP) == 0o555
    assert _mode(t / "data/live/vintages") & 0o200                    # the vintages root stays writable (append-only)
    assert _mode(t / "data/indicators.csv") == 0o640                  # other files keep their recorded mode
    if os.geteuid() != 0:                                             # root ignores the mode bits
        with pytest.raises(PermissionError):
            (t / VINTAGE / "live_inputs.csv").write_text("overwritten")


def test_vintage_written_writable_is_restored_read_only(home, tmp_path):
    (home / VINTAGE / "live_inputs.csv").chmod(0o644)                 # T4: a vintage is never restored writable
    r = backup.create_backup(home, tmp_path / "dest", now=NOW, **quiet)
    assert backup.restore(r["archive"], tmp_path / "t", **quiet)["ok"]
    assert _mode(tmp_path / "t" / VINTAGE / "live_inputs.csv") == 0o444


def _format1(home, tmp_path) -> Path:
    """A backup as create_backup wrote it before EQ-C-0070: format 1, every member 0644, no modes in the manifest."""
    d = tmp_path / "old/2026-10-20"; d.mkdir(parents=True)
    arch = d / "econquest-20261020T233000Z.tar.gz"
    files = {}
    with tarfile.open(arch, "w:gz") as t:
        for rel, p in _files(home).items():
            data = p.read_bytes()
            ti = tarfile.TarInfo(rel); ti.size = len(data); ti.mode = 0o644; t.addfile(ti, io.BytesIO(data))
            files[rel] = {"sha256": backup.hashlib.sha256(data).hexdigest(), "size": len(data)}
        man = {"format": 1, "sources": list(backup.SOURCES), "file_count": len(files), "files": files, "data_hash": None}
        mb = json.dumps(man).encode(); ti = tarfile.TarInfo("MANIFEST.json"); ti.size = len(mb); t.addfile(ti, io.BytesIO(mb))
    (d / "econquest-20261020T233000Z.manifest.json").write_text(json.dumps({**man, "archive_sha256": backup._sha256_file(arch)}))
    return arch


def test_old_format_backup_restores_read_only(home, tmp_path):
    (home / "data/panel/vintages/2026-10-01").mkdir(parents=True)
    (home / "data/panel/vintages/2026-10-01/panel.csv").write_text("a\n1\n")
    (home / "data/live/market/snapshots/s1/sub").mkdir(parents=True)
    (home / "data/live/market/snapshots/s1/sub/q.csv").write_text("a\n1\n")
    arch = _format1(home, tmp_path)
    t = tmp_path / "restored"
    res = backup.restore(arch, t, **quiet)
    assert res["ok"], res["errors"]
    for rel in (f"{VINTAGE}/live_inputs.csv", f"{SNAP}/indicators.csv", "data/panel/vintages/2026-10-01/panel.csv",
                "data/live/market/snapshots/s1/sub/q.csv"):
        assert _mode(t / rel) == 0o444, rel
    for rel in (VINTAGE, SNAP, "data/panel/vintages/2026-10-01", "data/live/market/snapshots/s1",
                "data/live/market/snapshots/s1/sub"):
        assert _mode(t / rel) == 0o555, rel
    assert _mode(t / "data/indicators.csv") & 0o200                   # outside those trees: default, writable


def test_restore_drill_keep_leaves_vintages_read_only(home, tmp_path):
    _make_read_only(home)
    backup.create_backup(home, tmp_path / "dest", now=NOW, **quiet)
    rep = backup.restore_drill(home, dest=tmp_path / "dest", keep=True, now=NOW, **quiet)
    assert rep["ok"]
    kept = Path(rep["kept_at"])
    try:
        assert _mode(kept / VINTAGE / "live_inputs.csv") == 0o444 and _mode(kept / SNAP / "indicators.csv") == 0o444
        assert _mode(kept / VINTAGE) == 0o555
    finally:
        backup._rmtree(kept.parent)
    assert not kept.parent.exists()


def test_restore_drill_without_keep_removes_the_read_only_tree(home, tmp_path, monkeypatch):
    _make_read_only(home)
    backup.create_backup(home, tmp_path / "dest", now=NOW, **quiet)
    made = []
    real = backup.tempfile.mkdtemp
    monkeypatch.setattr(backup.tempfile, "mkdtemp", lambda **k: made.append(real(dir=tmp_path, **k)) or made[-1])
    assert backup.restore_drill(home, dest=tmp_path / "dest", now=NOW, **quiet)["ok"]
    assert made and not Path(made[0]).exists()
