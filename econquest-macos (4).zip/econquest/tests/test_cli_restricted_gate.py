"""Restricted-source gate (HO-20261024-A-C-007, SEC-A-006 M1, EQ-C-0070): `run`, `publish` without a write and
`publish-preview` warn with audit.restricted_warning and carry on; every workbook write (publish --write first) is
refused before the token lookup, so nothing reaches Sheets; a check that raises fails closed; there is no override.
Scheduled jobs (ops/jobs.py) and GUI publish jobs go through cli.main and hit the same refusal.

Fixtures are copies of the real data/ files, as in tests/test_audit_restricted.py (17 Yahoo fx3m cells today); the
"official pull" is that file's SYNTHETIC _official_pull."""
import subprocess
import sys
import time
from pathlib import Path

import pytest

from econquest import cli
from econquest.ops import actionlog as AL
from econquest.ops import jobs
from econquest.presentation import sheets_publish as sp

sys.path.insert(0, str(Path(__file__).parent))
from test_audit_restricted import _copy, _official_pull  # noqa: E402

SECRET = "ya29.restricted-gate-test-token"


@pytest.fixture
def env(tmp_path, monkeypatch):
    for v in (cli.RUN_GATE_ENV, AL.LOG_ENV, cli.TOKEN_ENV):
        monkeypatch.delenv(v, raising=False)
    d = _copy(tmp_path)
    out = tmp_path / "outputs"
    sheets = []
    monkeypatch.setattr(sp, "apply_plan", lambda *a, **k: sheets.append(a) or pytest.fail("Sheets called"))
    monkeypatch.setattr(sp.urllib.request, "urlopen", lambda *a, **k: sheets.append(a) or pytest.fail("network called"))
    return d, out, sheets


def call(env, *argv):
    d, out, _ = env
    return cli.main(["--data", str(d), "--out", str(out), *argv])


def stub(monkeypatch, name):
    seen = []
    monkeypatch.setattr(cli, name, lambda args: seen.append(args))
    return seen


def _no_token(monkeypatch):
    monkeypatch.setattr(cli, "resolve_token", lambda args: pytest.fail("token looked up although the gate refuses"))


def test_run_warns_with_the_17_cells_and_continues(env, monkeypatch, capsys):
    seen = stub(monkeypatch, "cmd_run")
    call(env, "run")
    err = capsys.readouterr().err
    assert len(seen) == 1
    assert "WARNING (SEC-A-006 M1): 17 applied cell(s)" in err and "Country Profile fx3m: 17" in err
    assert "econquest fetch --only fx --apply" in err and "blocked" not in err


@pytest.mark.parametrize("argv", [["publish"], ["publish", "--dry-run"], ["publish", "--write", "--dry-run"]])
def test_publish_without_a_write_warns_and_continues(env, monkeypatch, capsys, argv):
    monkeypatch.setenv(cli.TOKEN_ENV, SECRET)
    seen = stub(monkeypatch, "cmd_publish")
    call(env, *argv)
    assert len(seen) == 1 and seen[0].token is None
    assert "17 applied cell(s)" in capsys.readouterr().err


def test_publish_preview_warns_and_continues(env, monkeypatch, capsys):
    seen = stub(monkeypatch, "cmd_publish_preview")
    call(env, "publish-preview", "--urls")
    assert len(seen) == 1 and "17 applied cell(s)" in capsys.readouterr().err


def test_publish_write_is_refused_and_sheets_never_called(env, monkeypatch, capsys):
    monkeypatch.setenv(cli.TOKEN_ENV, SECRET)
    _no_token(monkeypatch)
    monkeypatch.setattr(cli, "cmd_publish", lambda args: pytest.fail("publish ran although the gate refuses"))
    with pytest.raises(SystemExit) as e:
        call(env, "publish", "--write")
    assert e.value.code == cli.RUN_GATE_EXIT != 0
    err = capsys.readouterr().err
    assert "17 applied cell(s)" in err and "restricted-source gate: blocked publish --write" in err
    assert "Nothing was sent to Sheets" in err and "no override" in err
    assert env[2] == []
    (r,) = AL.read(env[1])
    assert r["command"] == "publish --write" and r["outcome"] == "error" and r["exit_code"] == cli.RUN_GATE_EXIT
    assert "restricted-source gate" in r["error"] and SECRET not in AL.log_path(env[1]).read_text()


def test_publish_write_refused_through_the_real_publish_path(env, monkeypatch, capsys):
    """No stub of cmd_publish: the real command would build a plan and call apply_plan; the gate stops it first."""
    monkeypatch.setenv(cli.TOKEN_ENV, SECRET)
    with pytest.raises(SystemExit) as e:
        call(env, "publish", "--write")
    assert e.value.code == cli.RUN_GATE_EXIT and env[2] == []
    assert not (env[1] / "publish_plan.json").exists()


def test_token_file_counts_as_a_write(env, monkeypatch, tmp_path):
    f = tmp_path / "tok"; f.write_text(SECRET)
    monkeypatch.setattr(cli, "cmd_publish", lambda args: pytest.fail("ran"))
    with pytest.raises(SystemExit) as e:
        call(env, "publish", "--token-file", str(f))
    assert e.value.code == cli.RUN_GATE_EXIT


@pytest.mark.parametrize("cmd", list(cli.WRITER_COMMANDS))
def test_every_workbook_write_is_refused(env, monkeypatch, capsys, cmd):
    monkeypatch.setenv(cli.TOKEN_ENV, SECRET)
    _no_token(monkeypatch)
    monkeypatch.setattr(cli, f"cmd_{cmd}", lambda args: pytest.fail("command ran although the gate refuses"))
    with pytest.raises(SystemExit) as e:
        call(env, cmd, "--write")
    assert e.value.code == cli.RUN_GATE_EXIT
    assert f"restricted-source gate: blocked {cmd} --write" in capsys.readouterr().err


def test_run_gate_off_and_allow_unattested_do_not_bypass(env, monkeypatch):
    monkeypatch.setenv(cli.TOKEN_ENV, SECRET)
    monkeypatch.setenv(cli.RUN_GATE_ENV, "off")
    monkeypatch.setattr(cli, "cmd_publish", lambda args: pytest.fail("ran"))
    with pytest.raises(SystemExit) as e:
        call(env, "publish", "--write", "--allow-unattested")
    assert e.value.code == cli.RUN_GATE_EXIT
    assert [r["command"] for r in AL.read(env[1])] == ["publish --write"]   # no run-gate override was recorded


def test_there_is_no_override_flag(env, monkeypatch, capsys):
    monkeypatch.setenv(cli.TOKEN_ENV, SECRET)
    monkeypatch.setattr(cli, "cmd_publish", lambda args: pytest.fail("ran"))
    for flag in ("--allow-restricted-source", "--allow-restricted"):
        with pytest.raises(SystemExit) as e:
            call(env, "publish", "--write", flag)
        assert e.value.code == 2                                           # argparse: unrecognized argument
    assert "unrecognized arguments" in capsys.readouterr().err


def test_check_that_raises_fails_closed_on_a_write(env, monkeypatch, capsys):
    d = env[0]
    (d / "countries.csv").unlink()                                       # Yahoo records, no applied values: raises
    monkeypatch.setenv(cli.TOKEN_ENV, SECRET)
    _no_token(monkeypatch)
    monkeypatch.setattr(cli, "cmd_publish", lambda args: pytest.fail("ran"))
    with pytest.raises(SystemExit) as e:
        call(env, "publish", "--write")
    assert e.value.code == cli.RUN_GATE_EXIT
    assert "cannot check" in capsys.readouterr().err and env[2] == []
    seen = stub(monkeypatch, "cmd_run")
    call(env, "run")                                                     # a warning-only command carries on
    assert len(seen) == 1 and "could not check" in capsys.readouterr().err


@pytest.mark.parametrize("exc", [OSError("unreadable"), ValueError("bad csv"), KeyError("country"), RuntimeError("bug")])
def test_any_check_error_fails_closed(env, monkeypatch, exc):
    def boom(d):
        raise exc
    monkeypatch.setattr(cli, "_restricted_cells", boom)
    monkeypatch.setenv(cli.TOKEN_ENV, SECRET)
    monkeypatch.setattr(cli, "cmd_publish", lambda args: pytest.fail("ran"))
    with pytest.raises(SystemExit) as e:
        call(env, "publish", "--write")
    assert e.value.code == cli.RUN_GATE_EXIT


def test_after_the_official_pull_run_and_publish_are_silent(env, monkeypatch, capsys):
    _official_pull(env[0])
    monkeypatch.setenv(cli.TOKEN_ENV, SECRET)
    run = stub(monkeypatch, "cmd_run")
    pub = stub(monkeypatch, "cmd_publish")
    call(env, "run")
    call(env, "publish", "--write")
    assert len(run) == 1 and [a.token for a in pub] == [SECRET]
    err = capsys.readouterr().err
    assert "restricted" not in err.lower() and "SEC-A-006" not in err


def test_ungated_commands_are_not_checked(env, monkeypatch):
    monkeypatch.setattr(cli, "_restricted_cells", lambda d: pytest.fail("checked"))
    seen = stub(monkeypatch, "cmd_scenarios")
    call(env, "scenarios")
    assert len(seen) == 1


def test_scheduled_job_that_publishes_is_refused(env, monkeypatch):
    """A job in <home>/ops.json with a `publish --write` step runs it through cli.main (the launcher): the job fails
    with the gate's exit code and nothing reaches Sheets."""
    d, out, sheets = env
    home = out.parent
    monkeypatch.setenv(cli.TOKEN_ENV, SECRET)

    class Done:
        def __init__(self, rc): self.returncode = rc

    def runner(argv, cwd=None, env=None):                # the launcher, in-process so the Sheets stub applies
        try:
            cli.main(argv[1:])
            return Done(0)
        except SystemExit as e:
            return Done(cli._exit_code(e)[0])
    step = ["econquest", "--data", str(d), "--out", str(out), "publish", "--write"]
    rc = jobs.run_job("publish", [step, ["econquest", "--data", str(d), "--out", str(out), "run"]], home,
                      runner=runner, log=lambda *_: None)
    assert rc == cli.RUN_GATE_EXIT and sheets == []
    last = jobs.last_runs(home)["publish"]
    assert last["status"] == "failed" and len(last["steps"]) == 1          # stopped at the refused step


def test_gui_publish_button_is_refused(env, monkeypatch):
    """The GUI's publish with a token runs `python -m econquest ... publish --write` in a child process: same gate."""
    from econquest.presentation import gui
    d, out, _ = env
    j = gui.Jobs(str(d), str(out))
    job = j.start("publish", ["--mc-rows", "10"], sheets_token=SECRET)
    j.proc.wait(timeout=300)
    for _ in range(200):
        if j.jobs[-1]["returncode"] is not None:
            break
        time.sleep(0.05)
    v = j.view(j.jobs[-1])
    log = "\n".join(v["log"])
    assert job["argv"].endswith("publish --mc-rows 10 --write")
    assert v["returncode"] == cli.RUN_GATE_EXIT, log
    assert "restricted-source gate: blocked publish --write" in log and "Nothing was sent to Sheets" in log
    assert SECRET not in log
    assert not (out / "publish_plan.json").exists()


def test_cli_exit_code_seen_by_a_shell(env):
    """`econquest publish --write` as Sam's Mac runs it: a non-zero exit."""
    d, out, _ = env
    r = subprocess.run([sys.executable, "-m", "econquest", "--data", str(d), "--out", str(out), "publish", "--write"],
                       capture_output=True, text=True, timeout=300,
                       env={"PATH": "/usr/bin:/bin", "HOME": str(out.parent), "ECONQUEST_SHEETS_TOKEN": SECRET,
                            "PYTHONPATH": str(Path(cli.__file__).resolve().parents[1])})
    assert r.returncode == cli.RUN_GATE_EXIT and "restricted-source gate: blocked" in r.stderr
