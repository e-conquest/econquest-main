"""Forecast record, quality gate, market-history parser and run versioning."""
import sys
from pathlib import Path
import numpy as np
import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.ingestion import load_universe  # noqa: E402
from econquest.ingestion.feeds import FetchReport, diff_against_seed, quality_gate, apply_report  # noqa: E402
from econquest.ingestion.market_history import parse_sheet_values, merge_prices  # noqa: E402
from econquest.validation.record import record_line, book_weights, realised_loss, append_record, load_record, record_for_backtest  # noqa: E402
from econquest.versioning import stamp, data_hash  # noqa: E402

DATA = ROOT / "data"


@pytest.fixture(scope="module")
def u():
    return load_universe(DATA)


def test_book_loss_sign_conventions(u):
    cty = u.countries.set_index("country")
    tickers = {f"USD{cty.at[n, 'currency']}" for n in u.names} | {str(cty.at[n, "etf"]) for n in u.names if pd.notna(cty.at[n, "etf"])}
    dates = pd.to_datetime(["2026-01-05", "2026-01-06"])
    px = pd.DataFrame({t: [100.0, 100.0] for t in tickers}, index=dates)
    w = book_weights(u, px)
    assert len(w) > 0 and set(w["asset_class"]) <= {"FX", "Local bond", "Equity"}
    # a long local-currency position loses when USD/local rises by 1%
    fx_long = w[(w["asset_class"] == "FX") & (w["w"] > 0)].iloc[0]
    px2 = px.copy(); px2.loc[dates[1], fx_long["ticker"]] = 101.0
    only = u.portfolio[u.portfolio["id"] == fx_long["id"]]
    u2 = type(u)(u.countries, u.indicators, u.rulebook, u.adjustments, only, u.markets, u.provenance, u.gpr, u.playbook)
    r = realised_loss(u2, px2)
    assert r["marked_positions"] == 1 and r["loss"] == pytest.approx(fx_long["notional_mm"] * np.log(1.01))
    # a long equity position gains when the ETF rises
    eq = w[(w["asset_class"] == "Equity") & (w["w"] < 0)].iloc[0]
    px3 = px.copy(); px3.loc[dates[1], eq["ticker"]] = 102.0
    only = u.portfolio[u.portfolio["id"] == eq["id"]]
    u3 = type(u)(u.countries, u.indicators, u.rulebook, u.adjustments, only, u.markets, u.provenance, u.gpr, u.playbook)
    assert realised_loss(u3, px3)["loss"] < 0


def test_record_carries_forecast_forward(tmp_path):
    p = tmp_path / "rec.csv"
    base = {"var99_12m": np.nan, "es99_12m": np.nan, "regime": "Calm", "marked_positions": 3, "marked_notional_mm": 10.0, "code_hash": "c", "data_hash": "d", "recorded_at": "t"}
    append_record(p, {"date": "2026-01-05", "loss": 0.1, "var": np.nan, "es": np.nan, "var_next": 1.0, "es_next": 1.3, **base})
    append_record(p, {"date": "2026-01-06", "loss": 1.5, "var": np.nan, "es": np.nan, "var_next": 1.1, "es_next": 1.4, **base})
    rec = load_record(p)
    assert len(rec) == 2 and rec.iloc[1]["var"] == 1.0 and rec.iloc[1]["es"] == 1.3
    append_record(p, {"date": "2026-01-06", "loss": 0.2, "var": np.nan, "es": np.nan, "var_next": 1.2, "es_next": 1.5, **base})  # same day again replaces
    rec = load_record(p)
    assert len(rec) == 2 and rec.iloc[1]["loss"] == 0.2
    bt = record_for_backtest(rec)
    assert list(bt.columns) == ["period", "date", "loss", "var", "es"] and len(bt) == 1


def test_quality_gate_holds_outliers_and_applies_the_rest(u, tmp_path):
    names = u.names
    ind = pd.DataFrame(index=u.indicators["id"].astype(str), columns=names, dtype=float)
    ind.at["1.3", names[0]] = 9999.0            # debt/GDP far outside the thresholds -> range hold
    ind.at["5.5", names[1]] = float(pd.to_numeric(u.indicators.set_index("id").at["5.5", names[1]])) + 0.1   # tiny change -> ok
    prof = pd.DataFrame(index=names, columns=["pop", "exports", "reserves", "fx3m", "policy", "equity_vol"], dtype=float)
    prof.at[names[2], "reserves"] = 5000.0      # impossible -> range hold
    rep = FetchReport(ind, prof, pd.DataFrame(), {"weo": "ok (1 rows)"}, {})
    diff = diff_against_seed(u, rep)
    rev = quality_gate(u, rep, diff)
    held = rev[rev["status"] == "hold"]
    assert set(zip(held["key"], held["country"])) == {("1.3", names[0]), ("reserves", names[2])}
    assert (rev["status"] == "missing").sum() > 0            # WEO feed succeeded but filled almost nothing
    # apply into a scratch copy of the data folder: held cells are skipped
    for f in ("indicators.csv", "countries.csv"):
        (tmp_path / f).write_bytes((DATA / f).read_bytes())
    out = apply_report(rep, tmp_path, review=rev)
    assert {k: out[k] for k in ("indicator_cells", "profile_cells", "held_for_review")} == {"indicator_cells": 1, "profile_cells": 0, "held_for_review": 2}
    after = pd.read_csv(tmp_path / "indicators.csv", dtype={"id": str}).set_index("id")
    assert after.at["1.3", names[0]] == pd.to_numeric(u.indicators.set_index("id").at["1.3", names[0]])
    assert apply_report(rep, tmp_path, review=rev, force=True, author="alice", approver="sam")["held_for_review"] == 0


def test_parse_market_history_values():
    values = [["Vietnam USDVND", "", "EM benchmark EEM", ""],
              ["Date", "Close", "Date", "Close"],
              ["2026-01-05 16:00:00", "24,500", "2026-01-05 16:00:00", "41.2"],
              ["2026-01-06 16:00:00", "24,510", "", ""],
              ["", "", "2026-01-07 16:00:00", "41.9"]]
    df = parse_sheet_values(values)
    assert list(df.columns) == ["USDVND", "EEM"] and len(df) == 3
    assert df.at[pd.Timestamp("2026-01-05"), "USDVND"] == 24500 and np.isnan(df.at[pd.Timestamp("2026-01-07"), "USDVND"])
    old = df.iloc[:2].copy(); old.at[pd.Timestamp("2026-01-05"), "EEM"] = 40.0     # a stored price is not rewritten
    merged = merge_prices(old, df)
    assert merged.at[pd.Timestamp("2026-01-05"), "EEM"] == 40.0 and len(merged) == 3


def test_versions_change_with_data(tmp_path):
    s = stamp(DATA)
    assert len(s["code_hash"]) == 16 and "indicators.csv" in s["data_files"] and s["code_version"]
    for f in ("indicators.csv", "countries.csv"):
        (tmp_path / f).write_bytes((DATA / f).read_bytes())
    h1 = data_hash(tmp_path)
    (tmp_path / "indicators.csv").write_text((DATA / "indicators.csv").read_text() + "\n")
    assert data_hash(tmp_path) != h1
    u = load_universe(DATA)
    assert u.provenance["versions"]["data_hash"] == s["data_hash"]


def test_record_line_says_last_complete_trading_day():
    """U03 (HO-20261023-C-B-010): the [record] line explains why its date can differ from the run day."""
    row = {"date": pd.Timestamp("2026-10-21"), "loss": 0.1234, "marked_positions": 7, "var_next": 1.5, "es_next": 2.0}
    line = record_line(row, pd.Timestamp("2026-10-20"), 12, 10)
    assert line.startswith("[record] 2026-10-21 (last complete trading day in Market History): loss 0.123 $mm on 7 positions")
    assert "(prev 2026-10-20)" in line and "record has 12 rows, 10 with a forecast to test" in line
    assert "(prev n/a)" in record_line(row, None, 1, 0)
