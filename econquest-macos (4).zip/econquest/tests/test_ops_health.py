"""EQ-C-0021: health check with a fake clock and temp folders."""
import datetime as dt
import json
from types import SimpleNamespace
from zoneinfo import ZoneInfo

import pytest

from econquest.ops import health, schedule
from econquest.persistence import Store

NY = ZoneInfo("America/New_York")


def ny(y, m, d, hh, mm):
    return dt.datetime(y, m, d, hh, mm, tzinfo=NY).astimezone(dt.timezone.utc)


@pytest.fixture
def home(tmp_path):
    h = tmp_path / "econquest"
    (h / "data" / "live").mkdir(parents=True); (h / "outputs" / "logs").mkdir(parents=True)
    jobs = {n: {k: v for k, v in j.items() if k != "steps"} for n, j in schedule.DEFAULT_JOBS.items()}
    (h / "outputs/logs/schedule.json").write_text(json.dumps({"status": "installed", "installed_at": "2026-10-01T00:00:00+00:00",
                                                             "tz": "America/New_York", "grace_minutes": 15, "stale_feed_days": 7,
                                                             "holidays": [], "jobs": jobs}))
    (h / "data/live/feeds.json").write_text(json.dumps({"feeds": {"weo": "ok (1 rows)"}, "retrieved": "2026-10-20"}))
    (h / "data/approvals").mkdir(); (h / "data/approvals/log.jsonl").write_text('{"seq": 1}\n')   # as the release ships
    return h


class Deliver:
    def __init__(self):
        self.calls = []

    def __call__(self, alerts, settings, env, out_dir=None, run_id=None, log=print, **k):
        self.calls.append(SimpleNamespace(alerts=alerts, out_dir=out_dir, run_id=run_id))
        return {"alerts": len(alerts), "webhook": "skipped", "email": "skipped"}


def write_record(h, *recorded):
    rows = ["date,loss,recorded_at"] + [f"{t.astimezone(NY).date()},0.1,{t.isoformat()}" for t in recorded]
    (h / "data/forecast_record.csv").write_text("\n".join(rows) + "\n")


def save_run(h, created, label="base"):
    Store(h / "outputs/store").save_run({"summary": {"run_id": created.strftime("%Y%m%dT%H%M%S") + label, "created_at": created.isoformat(),
                                                     "label": label, "metrics": {}}})


def write_job(h, name, status, code, ended):
    d = h / "outputs/logs/jobs"; d.mkdir(parents=True, exist_ok=True)
    (d / f"{name}.last.json").write_text(json.dumps({"job": name, "status": status, "exit_code": code,
                                                    "started_at": ended.isoformat(), "ended_at": ended.isoformat()}))


def run(h, now, deliver=None):
    return health.run_health(h / "data", h / "outputs", now=now, deliver_fn=deliver or Deliver(), log=lambda *_: None)


def missed(r):
    return {a["scope"] for a in r["alerts"] if a["kind"] == "missed_run"}


def all_evidence(h, day_ny):
    """Evidence for record, morning, monitor and backup on the given NY date."""
    write_record(h, ny(day_ny.year, day_ny.month, day_ny.day, 18, 25))
    save_run(h, ny(day_ny.year, day_ny.month, day_ny.day, 7, 10))
    for j in ("monitor", "backup"):
        write_job(h, j, "ok", 0, ny(day_ny.year, day_ny.month, day_ny.day, 23, 50))


# --- business days ----------------------------------------------------------------------------------------------

def test_business_days_skip_weekend_and_holidays():
    wk = schedule.WEEKDAYS
    assert health.is_run_day(dt.date(2026, 10, 23), wk, set())           # Friday
    assert not health.is_run_day(dt.date(2026, 10, 24), wk, set())       # Saturday
    assert not health.is_run_day(dt.date(2026, 10, 25), wk, set())       # Sunday
    assert not health.is_run_day(dt.date(2026, 11, 26), wk, {dt.date(2026, 11, 26)})   # listed holiday
    assert health.is_run_day(dt.date(2026, 10, 24), schedule.ALL_DAYS, {dt.date(2026, 10, 24)})   # daily jobs ignore holidays
    assert health.is_run_day(dt.date(2026, 10, 26), [1], set()) and not health.is_run_day(dt.date(2026, 10, 27), [1], set())


def test_monday_morning_checks_friday_record_slot():
    job = schedule.DEFAULT_JOBS["record"]
    slot, deadline = health.latest_due_slot(job, ny(2026, 10, 26, 10, 0), "America/New_York", 15, set())
    assert slot == ny(2026, 10, 23, 18, 20) and deadline == ny(2026, 10, 23, 18, 50)


def test_deadline_not_yet_reached_no_alert(home):
    all_evidence(home, dt.date(2026, 10, 20))                              # Tuesday done; Wednesday's record not yet written
    save_run(home, ny(2026, 10, 21, 7, 5))
    r = run(home, ny(2026, 10, 21, 19, 4))                                 # Wed 19:04 < 18:20 + 30 min + 15 min grace
    rec = [c for c in r["checks"] if c.get("job") == "record"][0]
    assert rec["status"] == "ok" and rec["slot"] == ny(2026, 10, 20, 18, 20).isoformat()
    assert "record" not in missed(r)


def test_missed_record_after_deadline_and_grace(home):
    all_evidence(home, dt.date(2026, 10, 20))
    save_run(home, ny(2026, 10, 21, 7, 5))
    d = Deliver()
    r = run(home, ny(2026, 10, 21, 19, 6), d)                              # 19:06 > 19:05
    assert missed(r) == {"record"}
    a = [a for a in r["alerts"] if a["scope"] == "record"][0]
    assert a["severity"] == "critical" and "2026-10-21 18:20" in a["message"]
    assert r["status"] == "critical" and len(d.calls) == 1 and d.calls[0].out_dir is None   # never overwrites outputs/alerts.json
    assert "key" not in d.calls[0].alerts[0]
    write_record(home, ny(2026, 10, 20, 18, 25), ny(2026, 10, 21, 19, 10))   # late run arrives
    assert "record" not in missed(run(home, ny(2026, 10, 21, 19, 15)))


def test_weekend_has_no_new_weekday_slots(home):
    all_evidence(home, dt.date(2026, 10, 23))                              # Friday done
    write_job(home, "backup", "ok", 0, ny(2026, 10, 24, 23, 45))           # Saturday's nightly backup done
    r = run(home, ny(2026, 10, 25, 9, 0))                                  # Sunday morning
    assert not missed(r)
    slots = {c["job"]: c["slot"] for c in r["checks"] if c.get("check") == "missed_run" and "slot" in c}
    assert slots["record"] == ny(2026, 10, 23, 18, 20).isoformat() and slots["backup"] == ny(2026, 10, 24, 23, 30).isoformat()


def test_missed_morning_run_uses_run_store(home):
    all_evidence(home, dt.date(2026, 10, 22))
    save_run(home, ny(2026, 10, 23, 7, 3), label="stress-X")              # a stress run does not count
    r = run(home, ny(2026, 10, 23, 9, 0))                                  # 07:00 + 90 + 15 = 08:45
    assert "morning" in missed(r)
    save_run(home, ny(2026, 10, 23, 7, 40))
    assert "morning" not in missed(run(home, ny(2026, 10, 23, 9, 5)))


def test_slots_before_install_are_not_checked(home):
    sp = home / "outputs/logs/schedule.json"
    s = json.loads(sp.read_text()); s["installed_at"] = ny(2026, 10, 23, 12, 0).isoformat(); sp.write_text(json.dumps(s))
    assert not missed(run(home, ny(2026, 10, 23, 13, 0)))                  # nothing scheduled since install yet


def test_no_schedule_installed_skips_missed_runs(home):
    (home / "outputs/logs/schedule.json").unlink()
    r = run(home, ny(2026, 10, 23, 20, 0))
    assert not missed(r) and r["schedule"] == "not installed"
    assert any(c["check"] == "missed_run" and c["status"] == "skipped" for c in r["checks"])


# --- feeds --------------------------------------------------------------------------------------------------------

def test_stale_and_failed_feeds(home):
    all_evidence(home, dt.date(2026, 10, 22))
    r = run(home, ny(2026, 10, 23, 6, 0))                                  # pull 2026-10-20: 3 days old
    assert not [a for a in r["alerts"] if a["kind"] in ("stale_feed", "feed_failure")]
    (home / "data/live/feeds.json").write_text(json.dumps({"feeds": {"weo": "ok", "bis": "error: timeout"}, "retrieved": "2026-10-10"}))
    r = run(home, ny(2026, 10, 23, 6, 0))
    kinds = {a["kind"]: a for a in r["alerts"]}
    assert kinds["stale_feed"]["value"] == 13 and kinds["stale_feed"]["threshold"] == 7 and "bis" in kinds["feed_failure"]["message"]
    (home / "data/live/vintages/2026-10-22T101500Z-abcd1234").mkdir(parents=True)   # a newer vintage counts as a pull
    r = health.run_health(home / "data", home / "outputs", now=ny(2026, 10, 23, 6, 0), deliver_fn=Deliver(), stale_days=7, log=lambda *_: None)
    assert "stale_feed" not in {a["kind"] for a in r["alerts"]}
    r = health.run_health(home / "data", home / "outputs", now=ny(2026, 10, 23, 6, 0), deliver_fn=Deliver(), stale_days=0, log=lambda *_: None)
    assert "stale_feed" in {a["kind"] for a in r["alerts"]}                # configurable threshold


def test_no_live_pull_is_flagged(home):
    (home / "data/live/feeds.json").unlink()
    assert any(a["kind"] == "stale_feed" for a in run(home, ny(2026, 10, 23, 6, 0))["alerts"])


# --- failed jobs, dedupe, output -----------------------------------------------------------------------------------

def test_failed_job_alert_and_dedupe(home):
    all_evidence(home, dt.date(2026, 10, 22))
    write_job(home, "backup", "failed", 1, ny(2026, 10, 22, 23, 50))
    d = Deliver()
    r = run(home, ny(2026, 10, 23, 6, 0), d)
    fail = [a for a in r["alerts"] if a["kind"] == "job_failed"]
    assert len(fail) == 1 and fail[0]["scope"] == "backup" and fail[0]["severity"] == "critical" and r["new_alerts"] == 1
    r2 = run(home, ny(2026, 10, 23, 6, 15), d)
    assert r2["new_alerts"] == 0 and len(d.calls) == 1                     # not re-sent every 15 minutes
    write_job(home, "backup", "ok", 0, ny(2026, 10, 23, 6, 20))
    r3 = run(home, ny(2026, 10, 23, 6, 30), d)
    assert not r3["alerts"] and r3["status"] == "ok" and not r3["alerted"] and len(d.calls) == 1
    hj = json.loads((home / "outputs/health.json").read_text())
    assert hj["status"] == "ok" and hj["generated_at"] == ny(2026, 10, 23, 6, 30).isoformat(timespec="seconds")


def test_failed_delivery_is_retried(home):
    all_evidence(home, dt.date(2026, 10, 22))
    write_job(home, "monitor", "failed", 2, ny(2026, 10, 22, 23, 0))
    calls = []

    def bad(alerts, settings, env, out_dir=None, run_id=None, log=print):
        calls.append(alerts); return {"webhook": "error: 500", "email": "skipped"}
    health.run_health(home / "data", home / "outputs", now=ny(2026, 10, 23, 6, 0), deliver_fn=bad, log=lambda *_: None)
    health.run_health(home / "data", home / "outputs", now=ny(2026, 10, 23, 6, 15), deliver_fn=bad, log=lambda *_: None)
    assert len(calls) == 2


def test_hung_job(home):
    all_evidence(home, dt.date(2026, 10, 22))
    d = home / "outputs/logs/jobs"
    (d / "morning.last.json").write_text(json.dumps({"job": "morning", "status": "running", "started_at": ny(2026, 10, 23, 7, 0).isoformat()}))
    save_run(home, ny(2026, 10, 23, 7, 0))
    kinds = {a["kind"] for a in run(home, ny(2026, 10, 23, 8, 0))["alerts"]}
    assert "job_hung" not in kinds
    assert "job_hung" in {a["kind"] for a in run(home, ny(2026, 10, 23, 10, 5))["alerts"]}   # > 2 x 90 min


def test_real_deliver_alerts_without_config(home):
    write_job(home, "record", "failed", 1, ny(2026, 10, 22, 22, 30))
    out = []
    r = health.run_health(home / "data", home / "outputs", now=ny(2026, 10, 23, 6, 0), env={}, log=out.append)
    assert r["delivery"]["webhook"].startswith("not configured") and not (home / "outputs/alerts.json").exists()
    assert any("EconQuest alerts for run health" in o for o in out)
    rec = [c for c in r["checks"] if c.get("check") == "missed_run" and c.get("job") == "record"][0]
    assert rec["status"] == "failed" and "missed_run" not in {a["kind"] for a in r["alerts"] if a["scope"] == "record"}


def test_cli_register_adds_ops_subcommands(home, tmp_path):
    import argparse
    from econquest.ops.commands import register
    ap = argparse.ArgumentParser(); ap.add_argument("--data"); ap.add_argument("--out")
    sub = ap.add_subparsers(dest="cmd", required=True)
    register(sub, home)
    for cmd in (["schedule", "show"], ["health", "--no-deliver"], ["backup", "--list"], ["restore-drill", "--keep"]):
        assert ap.parse_args(["--data", str(home / "data"), "--out", str(home / "outputs")] + cmd).cmd == cmd[0]
    a = ap.parse_args(["--data", str(home / "data"), "--out", str(home / "outputs"), "health", "--no-deliver"])
    a.fn(a)
    assert json.loads((home / "outputs/health.json").read_text())["schedule"] == "installed"
    a = ap.parse_args(["--data", str(home / "data"), "--out", str(home / "outputs"), "backup", "--dest", str(tmp_path / "b"), "--verify"])
    a.fn(a)
    assert len(list((tmp_path / "b").rglob("*.tar.gz"))) == 1
    a = ap.parse_args(["--out", str(home / "outputs"), "restore-drill", "--dest", str(tmp_path / "empty")])
    with pytest.raises(SystemExit) as e:
        a.fn(a)
    assert e.value.code == 2


# --- approvals log (EQ-C-0050, SEC-C-005 R1) --------------------------------------------------------------------------

@pytest.mark.parametrize("state", ["missing", "empty"])
def test_missing_or_empty_approvals_log_alerts(home, state):
    log = home / "data/approvals/log.jsonl"
    log.unlink() if state == "missing" else log.write_text("\n")
    r = run(home, ny(2026, 10, 23, 6, 0))
    a = [x for x in r["alerts"] if x["kind"] == "approvals_log"]
    assert len(a) == 1 and a[0]["severity"] == "warning" and a[0]["key"] == f"approvals_log:{state}" and state in a[0]["message"]
    assert {"check": "approvals_log", "status": state, "detail": str(log)} in r["checks"]


def test_present_approvals_log_is_ok(home):
    r = run(home, ny(2026, 10, 23, 6, 0))
    assert not [x for x in r["alerts"] if x["kind"] == "approvals_log"]
    assert {"check": "approvals_log", "status": "ok"} in r["checks"]
