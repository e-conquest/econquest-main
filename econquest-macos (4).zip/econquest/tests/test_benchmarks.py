import sys, math, datetime as dt
from pathlib import Path
import numpy as np
import pandas as pd
import pytest
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.validation import benchmarks as bm


def _country():
    idx = ["Argentina", "Japan", "Zambia"]
    return pd.DataFrame({"iso": ["ARG", "JPN", "ZMB"], "rating": ["CCC", "A+", "CCC-"], "regime": ["Stressed", "Calm", "Crisis"], "composite": [56.2, 20.0, 60.0],
                         "pd_default": [0.12, 0.001, 0.30], "pd_hazard_l1": [0.10, 0.001, 0.25], "pd_rating": [0.20, 0.0005, 0.27],
                         "pd_market": [0.13, 0.0008, 0.20], "pm_default": [0.15, np.nan, np.nan], "spread_bps": [780, 50, 1200]}, index=idx)


def test_snapshot_and_history(tmp_path):
    snap = bm.benchmark_snapshot(_country(), as_of="2026-10-23")
    assert list(snap["country"]) == ["Argentina", "Japan", "Zambia"] and abs(snap.loc[0, "model_vs_rating_pp"] - (-8.0)) < 1e-9
    h = bm.append_history(tmp_path / "b.csv", snap)
    h = bm.append_history(tmp_path / "b.csv", snap)          # same day replaces, no duplicates
    assert len(h) == 3
    h2 = bm.append_history(tmp_path / "b.csv", bm.benchmark_snapshot(_country(), as_of="2026-10-24"))
    assert len(h2) == 6


def test_outcomes_and_scores():
    hist = pd.concat([bm.benchmark_snapshot(_country(), as_of="2024-10-01"), bm.benchmark_snapshot(_country(), as_of="2026-10-23")], ignore_index=True)
    events = pd.DataFrame({"iso": ["ZMB"], "start": [2025], "end": [2025]})
    sc = bm.outcomes(hist, events, today=dt.date(2026, 10, 23))
    old = sc[sc["date"] == "2024-10-01"].set_index("country")["outcome"]
    assert old["Zambia"] == 1.0 and old["Argentina"] == 0.0 and sc[sc["date"] == "2026-10-23"]["outcome"].isna().all()
    scores = bm.score_sources(sc)
    row = scores.set_index("source").loc["model (final)"]
    assert row["rows"] == 3 and row["events"] == 1 and 0 <= row["brier"] <= 1 and row["auc"] == 1.0
    plan = bm.benchmarks_plan(hist[hist["date"] == "2026-10-23"], scores, len(hist))
    assert plan[0]["range"].startswith("'PD Benchmarks'") and len(plan[2]["values"]) == 3


def _defaulted():
    """Venezuela and Zimbabwe as in data/countries.csv: rated SD, default=Yes, model PD high."""
    idx = ["Venezuela", "Zimbabwe", "Japan"]
    return pd.DataFrame({"iso": ["VEN", "ZWE", "JPN"], "rating": ["SD", "SD", "A+"], "regime": ["Crisis", "Crisis", "Calm"], "composite": [80.0, 75.0, 20.0],
                         "pd_default": [0.88, 0.78, 0.001], "pd_hazard_l1": [0.8, 0.7, 0.001], "pd_rating": [0.9, 0.9, 0.0005],
                         "pd_market": [0.9, 0.8, 0.0008], "pm_default": [np.nan] * 3, "spread_bps": [6000, 3000, 50]}, index=idx)


def test_rows_already_in_default_are_not_scored_as_false_alarms():
    """EQ-B-0005 regression: before the fix VEN and ZWE scored outcome 0 (no new spell start) at PD ~0.8."""
    snap = bm.benchmark_snapshot(_defaulted(), as_of="2024-10-01")
    assert snap.set_index("country")["in_default"].to_dict() == {"Venezuela": True, "Zimbabwe": True, "Japan": False}
    events = pd.DataFrame({"iso": ["VEN", "ZWE"], "start": [2017, 2000], "end": [2025, 2025]})
    sc = bm.outcomes(snap, events, today=dt.date(2026, 10, 23)).set_index("country")
    assert sc.loc["Venezuela", "in_spell"] and sc.loc["Zimbabwe", "in_spell"] and not sc.loc["Japan", "in_spell"]
    assert sc[["outcome"]].loc[["Venezuela", "Zimbabwe"]].isna().all().all() and sc.loc["Japan", "outcome"] == 0.0
    row = bm.score_sources(sc.reset_index()).set_index("source").loc["model (final)"]
    assert row["rows"] == 1 and row["brier"] < 1e-5


def test_in_spell_from_events_or_default_status_without_sd_rating():
    """A spell in the events file covers the snapshot even when the rating column does not say SD, and an explicit
    default_status (countries.csv `default`) is honoured; a spell starting after the snapshot is still a hit."""
    c = _defaulted().assign(rating=["CCC", "CCC", "A+"])
    snap = bm.benchmark_snapshot(c, as_of="2024-10-01", default_status=pd.Series({"Venezuela": "No", "Zimbabwe": "Yes", "Japan": "No"}))
    assert snap.set_index("country")["in_default"].to_dict() == {"Venezuela": False, "Zimbabwe": True, "Japan": False}
    events = pd.DataFrame({"iso": ["VEN", "JPN"], "start": [2017, 2025], "end": [np.nan, 2025]})   # VEN ongoing (no end)
    sc = bm.outcomes(snap, events, today=dt.date(2026, 10, 23)).set_index("country")
    assert sc["in_spell"].to_dict() == {"Venezuela": True, "Zimbabwe": True, "Japan": False}
    assert sc.loc["Japan", "outcome"] == 1.0


def test_history_written_before_in_default_column_still_excludes_sd_rows(tmp_path):
    old = bm.benchmark_snapshot(_defaulted(), as_of="2024-10-01").drop(columns=["in_default"])
    old.to_csv(tmp_path / "b.csv", index=False)
    h = bm.load_history(tmp_path / "b.csv")
    sc = bm.outcomes(h, pd.DataFrame(columns=["iso", "start", "end"]), today=dt.date(2026, 10, 23)).set_index("country")
    assert sc.loc[["Venezuela", "Zimbabwe"], "outcome"].isna().all() and sc.loc["Japan", "outcome"] == 0.0


def test_benchmarks_does_not_import_presentation():
    """EQ-B-0002: validation must not depend on presentation (layering)."""
    import subprocess
    code = ("import sys; import econquest.validation.benchmarks as b; "
            "b.benchmarks_plan(b.benchmark_snapshot(__import__('test_benchmarks')._country(), as_of='2026-10-23'), "
            "b.score_sources(b.outcomes(b.load_history('nonexistent.csv'), __import__('pandas').DataFrame(columns=['iso','start','end']))), 3); "
            "bad = [m for m in sys.modules if m.startswith('econquest.presentation')]; assert not bad, bad")
    env = {**__import__("os").environ, "PYTHONPATH": f"{ROOT}{__import__('os').pathsep}{ROOT / 'tests'}"}
    r = subprocess.run([sys.executable, "-c", code], cwd=ROOT, env=env, capture_output=True, text=True)
    assert r.returncode == 0, r.stderr


def test_no_validation_module_imports_presentation():
    import ast
    for f in (ROOT / "econquest" / "validation").glob("*.py"):
        for node in ast.walk(ast.parse(f.read_text())):
            if isinstance(node, (ast.Import, ast.ImportFrom)):
                names = [a.name for a in node.names] + [getattr(node, "module", None) or ""]
                assert not any("presentation" in n for n in names), f"{f.name} imports presentation"


def test_benchmarks_plan_escapes_formula_text():
    c = _country().rename(index={"Japan": "=HYPERLINK(\"x\")"})
    plan = bm.benchmarks_plan(bm.benchmark_snapshot(c, as_of="2026-10-23"), bm.score_sources(bm.outcomes(bm.benchmark_snapshot(c, as_of="2026-10-23"), pd.DataFrame(columns=["iso", "start", "end"]))), 3)
    names = [row[0] for row in plan[2]["values"]]
    assert "'=HYPERLINK(\"x\")" in names


# ---- EQ-B-0022: scoring by source and horizon -------------------------------------------------------------------
def _hist4(date="2024-01-15", pd_model=(0.5, 0.1, 0.2, 0.0), pd_rating=(0.25, 0.25, 0.25, 0.25)):
    """Four countries, one snapshot; with _events4 only AAA defaults inside the 12-month window."""
    iso = ["AAA", "BBB", "CCC", "DDD"]
    return pd.DataFrame({"date": date, "country": iso, "iso": iso, "rating": "B", "regime": "Calm", "composite": 50.0, "in_default": False,
                         "pd_model": list(pd_model), "pd_hazard": np.nan, "pd_rating": list(pd_rating), "pd_spread": np.nan, "pd_cds": np.nan,
                         "pd_pm": np.nan})


_events4 = pd.DataFrame({"iso": ["AAA", "BBB"], "start": [2024, 2026], "end": [2024, 2026]})   # BBB's start is after the window


def test_score_requires_explicit_as_of():
    with pytest.raises(ValueError, match="as_of"):
        bm.score_benchmarks(_hist4(), _events4, as_of=None)


def test_real_history_not_yet_scorable_but_well_formed(tmp_path):
    """data/benchmarks.csv today: nothing has matured; one row per source with the first maturity date, in-default rows excluded."""
    h = bm.load_history(ROOT / "data" / "benchmarks.csv")
    events = pd.read_csv(ROOT / "data" / "panel" / "sovereign_defaults.csv", comment="#")
    as_of = str(h["date"].max())
    r = bm.score_benchmarks(h, events, as_of=as_of)
    first = (pd.Timestamp(h["date"].min()) + pd.DateOffset(months=12)).strftime("%Y-%m-%d")
    if pd.Timestamp(first) <= pd.Timestamp(as_of):
        pytest.skip("history now has a matured snapshot")
    assert r.status["12m"] == f"not yet scorable, first maturity {first}" and not r.scorable
    assert list(r.scores.columns) == bm.SCORE_COLUMNS and list(r.scores["source"]) == list(bm.SOURCES)
    assert (r.scores["n"] == 0).all() and r.scores["brier"].isna().all() and (r.scores["first_maturity"] == first).all()
    sd = int(h["rating"].astype(str).str.upper().isin(bm.DEFAULT_RATINGS).sum())
    assert (r.scores["n_excluded_in_spell"] >= sd).all() and (r.scores["n_pending"] + r.scores["n_excluded_in_spell"] == len(h)).all()
    paths = bm.write_benchmark_scores(r, tmp_path)
    back = pd.read_csv(paths["scores"])
    assert list(back.columns) == bm.SCORE_COLUMNS and len(back) == len(bm.SOURCES)
    assert list(pd.read_csv(paths["calibration"]).columns) == bm.CALIBRATION_COLUMNS


def test_matured_rule_is_inclusive_on_as_of():
    """Matured = snapshot date + 12 calendar months <= as_of: 2024-01-15 matures on 2025-01-15, not the day before."""
    before = bm.score_benchmarks(_hist4(), _events4, as_of="2025-01-14")
    assert before.status["12m"] == "not yet scorable, first maturity 2025-01-15" and not before.scorable
    on = bm.score_benchmarks(_hist4(), _events4, as_of="2025-01-15")
    assert on.status["12m"].startswith("scored: 4 matured rows") and on.scorable


def test_hand_checked_brier_logloss_skill():
    """y = (1, 0, 0, 0). Model p = (0.5, 0.1, 0.2, 0.0):
    Brier = (0.25 + 0.01 + 0.04 + 0) / 4 = 0.075; base rate 0.25, base Brier = (0.5625 + 3 * 0.0625) / 4 = 0.1875;
    skill = 1 - 0.075 / 0.1875 = 0.6; log loss = -(ln .5 + ln .9 + ln .8 + ln(1 - 1e-6)) / 4 (p = 0 clipped)."""
    r = bm.score_benchmarks(_hist4(), _events4, as_of="2026-10-23")
    s = r.scores.set_index("source")
    m = s.loc["pd_model"]
    assert m["status"] == "scored" and m["n"] == 4 and m["events"] == 1
    assert m["brier"] == pytest.approx(0.075) and m["brier_base_rate"] == pytest.approx(0.1875) and m["brier_skill"] == pytest.approx(0.6)
    assert m["log_loss"] == pytest.approx(-(math.log(0.5) + math.log(0.9) + math.log(0.8) + math.log(1 - 1e-6)) / 4)
    assert m["auc"] == 1.0 and m["base_rate"] == 0.25
    rt = s.loc["pd_rating"]                                  # the constant 0.25 forecast equals the base rate: skill 0
    assert rt["brier"] == pytest.approx(0.1875) and rt["brier_skill"] == pytest.approx(0.0)
    assert rt["n_paired"] == 4 and rt["brier_diff_vs_model"] == pytest.approx(0.1875 - 0.075)
    assert math.isnan(rt["dm_stat"]) and rt["comparison_note"].startswith("not tested: 4 paired rows in 4 countries")
    assert s.loc["pd_cds", "status"] == "no forecasts from this source on the matured rows" and s.loc["pd_cds", "n"] == 0


def test_log_loss_clipping_caps_a_certain_miss():
    r = bm.score_benchmarks(_hist4(pd_model=(0.0, 1.0, 0.0, 0.0)), _events4, as_of="2026-10-23")
    m = r.scores.set_index("source").loc["pd_model"]
    assert m["log_loss"] == pytest.approx((-math.log(1e-6) * 2 - 2 * math.log(1 - 1e-6)) / 4)


def test_in_spell_rows_excluded_from_new_framework():
    h = _hist4().assign(rating=["B", "SD", "B", "B"])
    r = bm.score_benchmarks(h, _events4, as_of="2026-10-23").scores.set_index("source").loc["pd_model"]
    assert r["n"] == 3 and r["n_excluded_in_spell"] == 1


def test_calibration_equal_count_bins_with_honest_labels():
    iso = [f"C{i:02d}" for i in range(10)]
    h = pd.DataFrame({"date": "2024-01-15", "country": iso, "iso": iso, "rating": "B", "in_default": False,
                      "pd_model": np.linspace(0.05, 0.95, 10), **{c: np.nan for c in ["pd_hazard", "pd_rating", "pd_spread", "pd_cds", "pd_pm"]}})
    ev = pd.DataFrame({"iso": ["C07", "C08", "C09"], "start": [2024] * 3, "end": [2024] * 3})
    cal = bm.score_benchmarks(h, ev, as_of="2026-10-23").calibration
    cal = cal[cal["source"] == "pd_model"]
    assert list(cal["n"]) == [2] * 5 and list(cal["events"]) == [0, 0, 0, 1, 2] and cal["events"].sum() == 3
    assert cal.iloc[0]["bin_label"] == "bin 1 of 5 (equal-count): p 0.0500 to 0.1500"
    assert cal.iloc[4]["observed_rate"] == 1.0 and cal.iloc[4]["mean_pred"] == pytest.approx(0.9)


def test_paired_comparison_detects_better_model():
    """40 countries, two snapshots a year apart: model tracks outcomes, rating is flat 0.1; DM t (rating minus model) is
    positive and significant; hand check of the cluster-robust t on the formula."""
    rng = np.random.default_rng(3)
    iso = [f"K{i:02d}" for i in range(40)]
    y1 = rng.random(40) < 0.3; y2 = rng.random(40) < 0.3
    frames = []
    for date, y in (("2023-01-15", y1), ("2024-01-15", y2)):
        frames.append(pd.DataFrame({"date": date, "country": iso, "iso": iso, "rating": "B", "in_default": False,
                                    "pd_model": np.where(y, 0.8, 0.05), "pd_rating": 0.1,
                                    **{c: np.nan for c in ["pd_hazard", "pd_spread", "pd_cds", "pd_pm"]}}))
    h = pd.concat(frames, ignore_index=True)
    ev = pd.DataFrame({"iso": [iso[i] for i in np.flatnonzero(y1)] + [iso[i] for i in np.flatnonzero(y2)],
                       "start": [2023] * int(y1.sum()) + [2024] * int(y2.sum())}).assign(end=lambda d: d["start"])
    r = bm.score_benchmarks(h, ev, as_of="2026-10-23").scores.set_index("source").loc["pd_rating"]
    assert r["n_paired"] == 80 and r["dm_clusters"] == 40 and r["brier_diff_vs_model"] > 0 and r["dm_p_value"] < 0.01
    y = np.concatenate([y1, y2]).astype(float); pm = np.where(y == 1, 0.8, 0.05)
    d = (0.1 - y) ** 2 - (pm - y) ** 2
    s = pd.Series(d - d.mean()).groupby(np.array(iso * 2)).sum().to_numpy()
    assert r["dm_stat"] == pytest.approx(d.mean() / (np.sqrt(40 / 39 * np.sum(s ** 2)) / 80))


def test_sub_annual_horizon_needs_day_resolution_events():
    r = bm.score_benchmarks(_hist4(), _events4, as_of="2026-10-23", horizons={"12m": 12, "6m": 6})
    assert r.status["6m"].startswith("not scorable: default events have yearly resolution")
    assert (r.scores[r.scores["horizon"] == "6m"]["n"] == 0).all()
    ev = _events4.assign(start_date=["2024-03-01", "2026-03-01"])           # AAA defaults 1.5 months after the snapshot
    r6 = bm.score_benchmarks(_hist4(), ev, as_of="2026-10-23", horizons={"6m": 6}).scores.set_index("source").loc["pd_model"]
    p6 = 1 - (1 - np.array([0.5, 0.1, 0.2, 0.0])) ** 0.5                   # constant-hazard scaling of the 12-month PD
    assert r6["n"] == 4 and r6["events"] == 1 and r6["brier"] == pytest.approx(np.mean((p6 - [1, 0, 0, 0]) ** 2))
    late = _events4.assign(start_date=["2024-09-01", "2026-03-01"])         # 7.5 months after: outside 6m, inside 12m
    r_late = bm.score_benchmarks(_hist4(), late, as_of="2026-10-23", horizons={"6m": 6, "12m": 12}).scores
    assert list(r_late[r_late["source"] == "pd_model"]["events"]) == [0, 1]


def test_in_spell_uses_start_date_when_events_have_it():
    # review of EQ-B-0022: in_spell dated every spell at 1 July while the hit rule used start_date
    hist = pd.DataFrame({"date": ["2024-08-01", "2024-04-01"], "country": ["A", "B"], "iso": ["AAA", "BBB"],
                         "rating": ["B", "B"], "in_default": [False, False]})
    ev = pd.DataFrame({"iso": ["AAA", "BBB"], "start": [2024, 2024], "end": [np.nan, np.nan],
                       "start_date": ["2024-09-01", "2024-03-01"]})
    got = bm.in_spell(hist, ev)
    assert list(got) == [False, True]          # A defaults after its snapshot (scorable); B was already in default
    ev_years = ev.drop(columns="start_date")
    assert list(bm.in_spell(hist, ev_years)) == [True, False]   # year-only events keep the 1 July convention


def test_outcomes_take_as_of():
    """VF-006 (EQ-B-0054): outcomes(as_of=...) scores at the model date, same as today=."""
    hist = pd.concat([bm.benchmark_snapshot(_country(), as_of="2024-10-01"), bm.benchmark_snapshot(_country(), as_of="2026-10-23")], ignore_index=True)
    events = pd.DataFrame({"iso": ["ZMB"], "start": [2025], "end": [2025]})
    a = bm.outcomes(hist, events, as_of="2026-10-23")
    b = bm.outcomes(hist, events, today=dt.date(2026, 10, 23))
    pd.testing.assert_frame_equal(a, b)
    assert bm.outcomes(hist, events, as_of="2025-06-30")["outcome"].isna().all()     # horizon not elapsed yet
