"""GARCH layer tests: simulated GARCH(1,1) recovery, DCC, VaR quantiles, Black-Scholes. Run: python tests/test_garch.py"""
import sys
from pathlib import Path
import numpy as np
import pandas as pd
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.engine.garch import (garch11_fit, dcc_fit, arch_lm_test, ljung_box, t_quantile, t_es, black_scholes, implied_vol,
                                   vol_target_scalar, clean_bad_ticks, run_garch, load_prices)
from econquest.ingestion import load_universe
from econquest.config import Settings

DATA = ROOT / "data"


def _simulate(n=3000, omega=2e-6, alpha=0.08, beta=0.90, nu=5.0, seed=1):
    rng = np.random.default_rng(seed)
    z = rng.standard_t(nu, n) * np.sqrt((nu - 2) / nu)
    s2 = np.empty(n); r = np.empty(n); s2[0] = omega / (1 - alpha - beta)
    for t in range(n):
        if t:
            s2[t] = omega + alpha * r[t - 1] ** 2 + beta * s2[t - 1]
        r[t] = np.sqrt(s2[t]) * z[t]
    return r, s2


def test_garch_recovers_parameters():
    r, s2 = _simulate()
    f = garch11_fit(r)
    assert abs(f.alpha - 0.08) < 0.04 and abs(f.beta - 0.90) < 0.05, (f.alpha, f.beta)
    assert 3 < f.nu < 9, f.nu
    assert np.corrcoef(f.sigma2, s2)[0, 1] > 0.9
    assert arch_lm_test(r)[1] < 0.01                       # clustering present in returns
    assert arch_lm_test(f.std_resid)[1] > 0.05             # absorbed by the fit
    assert ljung_box(f.std_resid ** 2)[1] > 0.01
    fc = f.forecast_var(10)
    assert fc.shape == (10,) and np.all(fc > 0)
    assert abs(f.cumulative_var(10) - fc.sum()) < 1e-15


def test_quantiles_and_options():
    assert abs(t_quantile(0.99, np.inf) - 2.3263) < 1e-3
    assert t_quantile(0.99, 4) > t_quantile(0.99, np.inf)          # fat tails widen VaR
    assert t_es(0.99, 5) > t_quantile(0.99, 5)
    bs = black_scholes(100, 100, 0.25, 0.04, 0.2, "put")
    assert abs(bs["price"] - 3.5) < 0.2 and bs["vega"] > 0 and -1 < bs["delta"] < 0
    assert abs(implied_vol(bs["price"], 100, 100, 0.25, 0.04) - 0.2) < 1e-4
    assert vol_target_scalar(0.10, 0.20) == 0.5 and vol_target_scalar(0.10, 0.01, cap=2.0) == 2.0


def test_dcc_tracks_correlation_regimes():
    rng = np.random.default_rng(3); n = 1500
    rho = np.where(np.arange(n) < n // 2, 0.1, 0.7)
    z1 = rng.standard_normal(n); z2 = rho * z1 + np.sqrt(1 - rho ** 2) * rng.standard_normal(n)
    d = dcc_fit(pd.DataFrame({"a": z1, "b": z2}))
    assert 0 < d.a < 0.3 and d.a + d.b < 1
    assert d.R_last[0, 1] > 0.5 and d.R_last[0, 1] > d.R_uncond[0, 1]   # ends in the high-correlation regime


def test_bad_tick_cleaning():
    idx = pd.bdate_range("2024-01-01", periods=300)
    p = pd.Series(100 * np.exp(np.cumsum(np.random.default_rng(0).normal(0, 0.005, 300))), index=idx)
    p.iloc[150] *= 3.0                                      # one-day spike that reverses
    out, removed = clean_bad_ticks(pd.DataFrame({"X": p}))
    assert removed == {"X": 1} and abs(out["X"].iloc[150] - p.iloc[149]) < 1e-9


def test_run_garch_on_snapshot():
    px = load_prices(DATA)
    if px is None:
        return
    u = load_universe(DATA); s = Settings.load(DATA / "assumptions.json")
    sub = px[[c for c in ("USDBRL", "USDJPY", "EWZ", "EWJ") if c in px.columns]]
    g = run_garch(u, sub, s, None)
    assert set(g.series["ticker"]) == set(sub.columns)
    assert (g.series["persistence"] < 1).all() and (g.series["var99_1d_pct"] > 0).all()
    assert g.portfolio["FX"]["positions"] == 2 and g.portfolio["total_var99_1d_mm"] > 0
    assert len(g.options) == 2 and (g.options["put_fair_garch"] > 0).all()


if __name__ == "__main__":
    for name, fn in list(globals().items()):
        if name.startswith("test_") and callable(fn):
            fn(); print("ok", name)


# --- EQ-B-0035: 12-month GARCH vols for the Monte Carlo (garch.mc_vols) -----------------------------------------
def _mc_prices(n=900):
    from econquest.engine.garch import _business_daily
    r1, _ = _simulate(n=n, omega=4e-6, alpha=0.08, beta=0.90, seed=3)          # persistence 0.98
    r2, _ = _simulate(n=n, omega=1e-6, alpha=0.05, beta=0.949, seed=4)         # persistence 0.999 (near unit)
    idx = _business_daily(pd.DataFrame(index=pd.date_range("2022-01-03", periods=int(n * 1.5), freq="D"))).index[:n]
    px = pd.DataFrame({"USDAAA": 10 * np.exp(np.cumsum(r1)), "USDBBB": 5 * np.exp(np.cumsum(r2)), "USDVES": 3 * np.exp(np.cumsum(r1[::-1])),
                       "EAA": 40 * np.exp(np.cumsum(r1 * 3)), "USDSHORT": np.r_[np.full(n - 200, np.nan), 2 * np.exp(np.cumsum(r1[:200]))]}, index=idx)
    cty = pd.DataFrame({"country": ["A", "B", "V", "S", "Z"], "currency": ["AAA", "BBB", "VES", "SHORT", "ZZZ"], "etf": ["EAA", "", "", "", ""]})
    return px, cty


def test_mc_vols_is_the_12_month_garch_forecast_with_documented_fallbacks():
    from econquest.engine import garch as G
    px, cty = _mc_prices()
    needed = [("A", "FX"), ("A", "Equity"), ("B", "FX"), ("V", "FX"), ("S", "FX"), ("Z", "FX"), ("B", "Equity")]
    tab = G.mc_vols(px, cty, needed, horizon_days=252, persistence_max=0.995).set_index(["country", "kind"])
    # the number is sqrt(sum of the 252 daily variance forecasts) of the same fit run_garch would make
    r = G._returns(G._mc_returns(px)["USDAAA"])
    f = G.garch11_fit(r)
    assert tab.loc[("A", "FX"), "vol_pct"] == np.sqrt(f.cumulative_var(252)) * 100
    assert tab.loc[("A", "FX"), "ticker"] == "USDAAA" and tab.loc[("A", "Equity"), "ticker"] == "EAA"
    assert 2.5 < tab.loc[("A", "Equity"), "vol_pct"] / tab.loc[("A", "FX"), "vol_pct"] < 3.5      # ETF simulated at 3x the FX returns
    # fallbacks (vol NaN -> the MC keeps its regime parameter), each with its reason
    assert np.isnan(tab.loc[("B", "FX"), "vol_pct"]) and tab.loc[("B", "FX"), "reason"].startswith("persistence")
    assert tab.loc[("B", "FX"), "persistence"] >= 0.995
    assert np.isnan(tab.loc[("V", "FX"), "vol_pct"]) and "administered" in tab.loc[("V", "FX"), "reason"]
    assert np.isnan(tab.loc[("S", "FX"), "vol_pct"]) and "fewer than 250" in tab.loc[("S", "FX"), "reason"]
    assert tab.loc[("Z", "FX"), "reason"] == "no series" and tab.loc[("B", "Equity"), "reason"] == "no series"
    # a higher persistence cap admits B; no prices at all -> every row falls back
    tab2 = G.mc_vols(px, cty, [("B", "FX")], persistence_max=0.99999).set_index(["country", "kind"])
    assert np.isfinite(tab2.loc[("B", "FX"), "vol_pct"])
    assert G.mc_vols(None, cty, [("A", "FX")])["reason"].tolist() == ["no series"]


def test_mc_vols_horizon_and_cache():
    from econquest.engine import garch as G
    px, cty = _mc_prices()
    G._MC_FIT_CACHE.clear()
    v21 = G.mc_vols(px, cty, [("A", "FX")], horizon_days=21)["vol_pct"].iloc[0]
    n_fits = len(G._MC_FIT_CACHE)
    v252 = G.mc_vols(px, cty, [("A", "FX")], horizon_days=252)["vol_pct"].iloc[0]
    assert len(G._MC_FIT_CACHE) == n_fits == 1                 # second call reuses the fit
    assert v252 > v21 * np.sqrt(252 / 21) * 0.8                 # 12-month vol scales roughly with sqrt(time)


def test_run_garch_as_of_cuts_later_prices():
    """VF-007 (EQ-B-0054): run_garch fits only on prices up to as_of (argument, else settings["as_of"])."""
    px = load_prices(DATA)
    if px is None:
        return
    u = load_universe(DATA); s = Settings.load(DATA / "assumptions.json")
    sub = px[[c for c in ("USDBRL", "EWZ") if c in px.columns]]
    d = pd.to_datetime(sub.index)
    cut_day = d[-60]
    full = run_garch(u, sub, s, None)
    cut = run_garch(u, sub, s, None, as_of=cut_day.strftime("%Y-%m-%d"))
    ref = run_garch(u, sub[np.asarray(d <= cut_day)], s, None)
    assert (pd.to_datetime(cut.series["last_date"]) <= cut_day).all()
    assert (pd.to_datetime(full.series["last_date"]) > cut_day).all()
    pd.testing.assert_frame_equal(cut.series.reset_index(drop=True), ref.series.reset_index(drop=True))
    via_settings = run_garch(u, sub, s.copy_with(as_of=cut_day.strftime("%Y-%m-%d")), None)
    assert list(via_settings.series["persistence"]) == list(cut.series["persistence"])
