"""EQ-A-0028: BIS consolidated banking statistics (HO-20261023-B-A-005) and World Bank history (HO-20261023-B-A-006).
Offline: the BIS endpoint and wbgapi are the fakes of test_feeds_scale; the stress loader (Team B, read only) reads the
file we write."""
import datetime as dt
import sys
import urllib.parse
from pathlib import Path

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT)); sys.path.insert(0, str(Path(__file__).resolve().parent))
from econquest.engine import stress as S  # noqa: E402
from econquest.ingestion import feeds, load_universe  # noqa: E402
from econquest.ingestion.feeds import (CBS_COLUMNS, BisFeed, FeedError, FetchReport, WorldBankHistoryFeed,  # noqa: E402
                                       save_report, save_vintage)
from test_feeds_scale import _fake_bis_urlopen, _fake_wbgapi  # noqa: E402

TODAY = dt.date(2026, 10, 23)
ISO2 = {"BRA": "BR", "CHL": "CL", "ARG": "AR", "XXX": "QQ", "NOC": None}


def _cbs(monkeypatch, calls, known=("BR", "CL", "AR"), **kw):
    monkeypatch.setattr("econquest.ingestion.sources.open_url_no_redirect", _fake_bis_urlopen(calls, set(known)))
    return BisFeed(sleep=lambda s: None, **kw).fetch_cbs(ISO2, today=TODAY)


def test_cbs_batches_debtors_drops_aggregates_and_lists_unreported(monkeypatch):
    calls = []
    out = _cbs(monkeypatch, calls)
    assert len(calls) == 1
    flow, key = calls[0]
    dims = key.split(".")
    assert flow == "WS_CBS_PUB" and len(dims) == 11
    assert dims[:2] == ["Q", "S"] and dims[2] == "" and dims[5] == "C"            # reporters open, claims
    assert dims[4] == feeds.CBS_BASIS_ULTIMATE_RISK and dims[10] == "BR+CL+AR+QQ"
    assert list(out.columns) == CBS_COLUMNS
    assert set(out["creditor_iso2"]) == {"US", "GB", "JP"}                        # 5A / 5J aggregates dropped
    assert not out.duplicated(["creditor_iso2", "debtor_iso3", "period"]).any()
    assert out["period"].nunique() == feeds.CBS_QUARTERS and out["period"].max() == "2026-Q2"
    assert (out["basis"] == "U").all() and out["source"].str.contains("WS_CBS_PUB").all()
    assert out.attrs["latest_period"] == "2026-Q2"
    assert out.attrs["not_reported"] == ["ARG", "NOC", "XXX"]                     # AR silent in 2026-Q2; no ISO2; unknown code
    assert any("no claims on 3 debtors" in f for f in out.attrs["failures"])


def test_cbs_start_period_and_failure_fallback(monkeypatch):
    seen = []
    real = _fake_bis_urlopen([], {"BR", "CL"}, fail_first={"WS_CBS_PUB": 99})

    def urlopen(req, timeout=None):
        seen.append(urllib.parse.urlsplit(req.full_url).query)
        if len(seen) <= 4:                                                         # the batch fails for good (503 x 4)
            return real(req, timeout)
        return _fake_bis_urlopen([], {"BR", "CL"})(req, timeout)

    monkeypatch.setattr("econquest.ingestion.sources.open_url_no_redirect", urlopen)
    out = BisFeed(sleep=lambda s: None).fetch_cbs({"BRA": "BR", "CHL": "CL"}, today=TODAY)
    assert "startPeriod=2023-Q1" in seen[0] and "format=csv" in seen[0]
    assert set(out["debtor_iso3"]) == {"BRA", "CHL"}
    assert any("batch of 2" in f and "retrying one by one" in f for f in out.attrs["failures"])


def test_cbs_never_mixes_in_another_basis(monkeypatch):
    calls = []
    real = _fake_bis_urlopen(calls, {"BR"})

    def other_basis(req, timeout=None):
        body = real(req, timeout).read().decode().replace(",U,", ",F,")           # server answers immediate counterparty
        import io
        return io.BytesIO(body.encode())

    monkeypatch.setattr("econquest.ingestion.sources.open_url_no_redirect", other_basis)
    with pytest.raises(FeedError, match="no claims on basis U"):
        BisFeed(sleep=lambda s: None).fetch_cbs({"BRA": "BR"}, today=TODAY)


def test_stress_loader_reads_our_cbs_file(monkeypatch, tmp_path):
    out = _cbs(monkeypatch, [])
    rep = FetchReport(pd.DataFrame(), pd.DataFrame(), pd.DataFrame(), {"bis_cbs": "ok"}, {"bis_cbs": out})
    live = save_report(rep, tmp_path)
    p = live / "raw_bis_cbs.csv"
    assert list(pd.read_csv(p).columns) == CBS_COLUMNS
    countries = pd.DataFrame({"country": ["Brazil", "Chile", "Argentina"], "iso": ["BRA", "CHL", "ARG"], "iso2": ["BR", "CL", "AR"]})
    mat = S.load_bilateral_exposures(p, countries)
    assert mat.attrs["period"] == "2026-Q2" and set(mat.columns) == {"BRA", "CHL"} and set(mat.index) == {"US", "GB", "JP"}
    assert mat.at["JP", "CHL"] == 0.0 and mat.at["US", "BRA"] == 3000 + 9
    w = S.common_lender_weights(mat, "BRA")
    assert list(w.index) == ["CHL"] and w["CHL"] == pytest.approx(1.0)
    # HO-005 acceptance: with the file in place EMDEF_BRA loads and nothing is unavailable
    (tmp_path / "scenarios.json").write_bytes((ROOT / "data" / "scenarios.json").read_bytes())
    assert "EMDEF_BRA" in S.load_scenarios(tmp_path / "scenarios.json") and S.UNAVAILABLE == {}
    v = save_vintage(tmp_path, rep, now=dt.datetime(2026, 10, 23, 12, tzinfo=dt.timezone.utc))
    assert (v / "raw_bis_cbs.csv").read_bytes() == p.read_bytes()


def test_fetch_all_bis_includes_cbs_with_provenance_and_unserved(monkeypatch):
    u = load_universe(ROOT / "data")
    calls = []
    known = set(u.countries["iso2"].dropna()) - {"AR"}
    monkeypatch.setattr("econquest.ingestion.sources.open_url_no_redirect", _fake_bis_urlopen(calls, known))
    rep = feeds.fetch_all(u, only=["bis"], year=2026, log=lambda m: None)
    # EQ-A-0040: 'bis' now also pulls the daily exchange rates (WS_XRU)
    assert set(rep.raw) == {"bis", "bis_cbs", "bis_xru"} and rep.feeds["bis_cbs"].startswith("ok")
    pv = rep.provenance[rep.provenance["table"] == "BIS CBS"]
    assert len(pv) == len(u.names) - 1 and pv["retrieved"].notna().all() and pv["source"].str.contains("WS_CBS_PUB").all()
    un = rep.unserved[rep.unserved["feed"] == "bis_cbs"]
    assert list(un["country"]) == ["Argentina"]
    assert {"weo", "worldbank", "worldbank_history", "ecb_exr"} <= {k for k, v in rep.feeds.items() if v == "skipped"}
    assert "yahoo" not in rep.feeds                                  # EQ-A-0040: not a feed any more


# ---------------------------------------------------------------------------------------------------- World Bank history
def test_wb_history_reuses_panel_fetcher_from_1996(monkeypatch):
    calls = []
    monkeypatch.setitem(sys.modules, "wbgapi", _fake_wbgapi(calls))
    out = WorldBankHistoryFeed(end=2025).fetch(["VNM", "BRA"])
    assert list(out.columns) == feeds.LONG_COLUMNS
    assert set(out["series"]) == {"DT.DOD.DSTC.IR.ZS", "FI.RES.TOTL.MO", "PV.EST"}
    assert out["period"].min() == 1996 and out["period"].max() == 2025 and set(out["iso"]) == {"VNM", "BRA"}
    assert (out.groupby(["iso", "series"]).size() == 30).all()
    assert (3, ("PV.EST",)) in calls                                       # PV.EST retried on WGI by panel_history
    assert out["source"].str.contains("not point in time").all()


def test_wb_history_short_term_debt_falls_back_to_ids(monkeypatch):
    def fetch_one(code, start, end, isos):
        if code == "DT.DOD.DSTC.IR.ZS":
            return pd.DataFrame(columns=["iso", "series", "period", "value", "source"])     # WDI empty
        return pd.DataFrame({"iso": isos, "series": code, "period": start, "value": 1.0, "source": "x"})

    used = []

    def alt(code, start, end, isos, db):
        used.append((code, db))
        return pd.DataFrame({"iso": isos, "series": code, "period": end, "value": 2.0})

    out = WorldBankHistoryFeed(end=2025, fetcher=fetch_one, alt_fetcher=alt).fetch(["PAK"])
    assert used == [("DT.DOD.DSTC.IR.ZS", 6)]
    assert set(out["series"]) == set(feeds.WB_HISTORY_SERIES)
    with pytest.raises(FeedError):
        WorldBankHistoryFeed(fetcher=lambda *a: (_ for _ in ()).throw(RuntimeError("down")), alt_fetcher=lambda *a: pd.DataFrame()).fetch(["PAK"])
