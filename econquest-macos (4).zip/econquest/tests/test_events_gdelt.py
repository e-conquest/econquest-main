"""GDELT adapter tests (EQ-A-0023). All inputs are SYNTHETIC fixtures (tests/fixtures/events/gdelt/README.md)."""
import datetime as dt
import io
import zipfile
from pathlib import Path

import pandas as pd
import pytest

from econquest.ingestion.events import gdelt as g
from econquest.ingestion.events.base import EVENT_COLUMNS, validate_events

FX = Path(__file__).parent / "fixtures" / "events" / "gdelt"
DESK = pd.read_csv(Path(__file__).parents[1] / "data" / "countries.csv")["iso"].tolist()
NOW = dt.datetime(2026, 10, 23, 6, 0, 0, tzinfo=dt.timezone.utc)


class FixtureFetcher:
    """Serves fixture files by URL basename and records every URL asked for."""

    def __init__(self, overrides=None):
        self.urls, self.overrides = [], overrides or {}

    def __call__(self, url, headers=None, data=None):
        self.urls.append(url)
        name = url.rsplit("/", 1)[1]
        if name in self.overrides:
            v = self.overrides[name]
            if isinstance(v, Exception):
                raise v
            return v
        p = FX / name
        if not p.is_file():
            raise g.GdeltNotFound(url)
        return p.read_bytes()

    def zips(self):
        return [u for u in self.urls if u.endswith(".zip")]


def adapter(tmp_path, **kw):
    kw.setdefault("now", lambda: NOW)
    kw.setdefault("sleep", lambda s: None)
    return g.GdeltAdapter(tmp_path / "stage", **kw)


def test_parse_plain_and_zip_same_rows():
    plain = g.parse_export((FX / "20261020000000.export.CSV").read_bytes(), "20261020000000")
    z = g.parse_export(g.unzip_export((FX / "20261020000000.export.CSV.zip").read_bytes()), "20261020000000")
    pd.testing.assert_frame_equal(plain, z)
    assert len(plain) == 6
    r = plain.set_index("global_event_id").loc["1001"]
    assert (r.sqldate, r.is_root, r.event_root_code, r.quad_class, r.goldstein, r.num_mentions, r.avg_tone, r.fips,
            r.dateadded) == ("20261019", 1, 14, 3, -6.5, 10, -5.0, "NI", "20261020000000")


def test_parse_rejects_wrong_column_count():
    with pytest.raises(g.GdeltFormatError, match="60 fields"):
        g.parse_export(("\t".join(["x"] * 60) + "\n").encode())


def test_fips_mapping_desk_traps_and_unmapped_counts():
    assert g.FIPS_TO_ISO3["NI"] == "NGA" and "NG" not in g.FIPS_TO_ISO3          # Niger is NG in FIPS
    assert g.FIPS_TO_ISO3["SN"] == "SGP" and g.FIPS_TO_ISO3["SG"] == "SEN"
    assert g.FIPS_TO_ISO3["ZA"] == "ZMB" and g.FIPS_TO_ISO3["ZI"] == "ZWE"
    assert sorted(g.FIPS_TO_ISO3.values()) == sorted(DESK)
    df = pd.concat([g.parse_export((FX / f"{ts}.export.CSV").read_bytes(), ts)
                    for ts in ("20261020000000", "20261020001500")])
    mapped, unmapped = g.map_countries(df, g.FIPS_TO_ISO3)
    assert unmapped == {"": 1, "NG": 1, "US": 1}
    assert len(mapped) == 7 and set(mapped["iso"]) == {"NGA", "BRA", "SGP", "SEN"}


def test_fips_override_csv(tmp_path):
    m = g.load_fips_map(FX / "fips_iso3_override.csv")
    assert m["NG"] == "NER" and m["NI"] == "NGA"
    bad = tmp_path / "bad.csv"
    bad.write_text("fips,iso\nNG,Niger\n")
    with pytest.raises(g.GdeltFormatError):
        g.load_fips_map(bad)
    drop = tmp_path / "drop.csv"
    drop.write_text("fips,iso\nNI,\n")
    assert "NI" not in g.load_fips_map(drop)


def test_dedupe_keeps_first_file():
    df = pd.concat([g.parse_export((FX / f"{ts}.export.CSV").read_bytes(), ts)
                    for ts in ("20261020001500", "20261020000000")])
    out, n = g.dedupe(df)
    assert n == 1 and out["global_event_id"].is_unique
    assert out.set_index("global_event_id").loc["1002", "file_ts"] == "20261020000000"


def test_fetch_matches_normalised_fixture(tmp_path):
    ad = adapter(tmp_path)
    df = ad.fetch(DESK, "2026-10-20", "2026-10-21", FixtureFetcher())
    assert list(df.columns) == EVENT_COLUMNS
    validate_events(df, source="gdelt")
    expected = pd.read_csv(FX / "events.csv", dtype={"vintage_id": str}, keep_default_na=False)
    pd.testing.assert_frame_equal(df.reset_index(drop=True), expected, check_dtype=False)
    v = df.set_index(["iso", "period", "metric"])["value"]
    assert v[("NGA", "2026-10-20", "events_total")] == 2          # 1001 + 1002; non-root 1003 and duplicate dropped
    assert v[("NGA", "2026-10-20", "events_protest")] == 1
    assert v[("NGA", "2026-10-20", "events_material_conflict")] == 1
    assert v[("NGA", "2026-10-20", "events_verbal_conflict")] == 1
    assert v[("NGA", "2026-10-20", "goldstein_mean")] == pytest.approx(-8.25)
    assert v[("NGA", "2026-10-20", "tone_mean")] == pytest.approx(-6.5)
    assert v[("NGA", "2026-10-20", "mentions_total")] == 14
    assert v[("PHL", "2026-10-21", "events_total")] == 1          # late report counted on its file date
    assert v[("JPN", "2026-10-20", "events_total")] == 0          # zero counts on staged days
    assert ("JPN", "2026-10-20", "tone_mean") not in v.index      # no mean without events
    assert ad.report["unmapped"] == {"": 1, "NG": 1, "US": 1} and ad.report["unmapped_total"] == 3
    assert ad.report["duplicates_dropped"] == 1


def test_include_non_root_and_event_date_basis(tmp_path):
    df = adapter(tmp_path, root_only=False).fetch(["NGA"], "2026-10-20", "2026-10-21", FixtureFetcher())
    v = df.set_index(["iso", "period", "metric"])["value"]
    assert v[("NGA", "2026-10-20", "events_total")] == 3
    ad = adapter(tmp_path / "e", date_basis="event")
    v = ad.fetch(["NGA", "PHL"], "2026-10-20", "2026-10-21", FixtureFetcher()).set_index(["iso", "period", "metric"])["value"]
    assert v[("NGA", "2026-10-20", "events_total")] == 1          # 1001 has SQLDATE 2026-10-19 (not staged)
    assert v[("PHL", "2026-10-21", "events_total")] == 0          # its SQLDATE 2026-10-01 is outside


def test_resume_skips_staged_days_and_restages_changed(tmp_path):
    f1 = FixtureFetcher()
    adapter(tmp_path).fetch(DESK, "2026-10-20", "2026-10-21", f1)
    assert len(f1.zips()) == 3
    f2 = FixtureFetcher()
    ad = adapter(tmp_path)
    ad.fetch(DESK, "2026-10-20", "2026-10-21", f2)
    assert f2.zips() == [] and ad.report["skipped"] == ["20261020", "20261021"]
    (tmp_path / "stage" / "days" / "20261021.csv").write_text("tampered\n")   # sha mismatch -> restaged
    f3 = FixtureFetcher()
    ad = adapter(tmp_path)
    ad.fetch(DESK, "2026-10-20", "2026-10-21", f3)
    assert [u.rsplit("/", 1)[1] for u in f3.zips()] == ["20261021000000.export.CSV.zip"]
    assert ad.report["staged"] == ["20261021"]
    f4 = FixtureFetcher()                                                   # a changed FIPS map restages everything
    adapter(tmp_path, fips_map_csv=FX / "fips_iso3_override.csv").fetch(DESK, "2026-10-20", "2026-10-21", f4)
    assert len(f4.zips()) == 3


def test_failed_day_is_reported_and_resumable(tmp_path):
    bad = FixtureFetcher({"20261021000000.export.CSV.zip": ConnectionError("reset")})
    ad = adapter(tmp_path, retries=2)
    with pytest.raises(g.IncompleteFetchError) as e:
        ad.fetch(DESK, "2026-10-20", "2026-10-21", bad)
    assert list(e.value.report["failed"]) == ["20261021"] and e.value.report["staged"] == ["20261020"]
    assert bad.zips().count("https://data.gdeltproject.org/gdeltv2/20261021000000.export.CSV.zip") == 3
    good = FixtureFetcher()
    ad = adapter(tmp_path)
    ad.fetch(DESK, "2026-10-20", "2026-10-21", good)
    assert ad.report["skipped"] == ["20261020"] and ad.report["staged"] == ["20261021"]


def test_md5_mismatch_fails(tmp_path):
    other = (FX / "20261020001500.export.CSV.zip").read_bytes()
    f = FixtureFetcher({"20261020000000.export.CSV.zip": other})
    with pytest.raises(g.IncompleteFetchError) as e:
        adapter(tmp_path, retries=0).fetch(DESK, "2026-10-20", "2026-10-20", f)
    assert "bytes, index says" in e.value.report["failed"]["20261020"]["20261020000000"] or \
        "md5" in e.value.report["failed"]["20261020"]["20261020000000"]


def test_zip_size_cap(tmp_path):
    with pytest.raises(g.IncompleteFetchError) as e:
        adapter(tmp_path, max_zip_bytes=100, retries=0).fetch(DESK, "2026-10-20", "2026-10-20", FixtureFetcher())
    assert "over cap 100" in e.value.report["failed"]["20261020"]["20261020000000"]


def test_decompressed_size_cap():
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("x.export.CSV", b"\0" * 10_000)
    with pytest.raises(g.GdeltError, match="over cap"):
        g.unzip_export(buf.getvalue(), max_csv_bytes=1000)
    with pytest.raises(g.GdeltFormatError):
        buf2 = io.BytesIO()
        with zipfile.ZipFile(buf2, "w") as z:
            z.writestr("a.CSV", b"")
            z.writestr("b.CSV", b"")
        g.unzip_export(buf2.getvalue())


def test_https_enforced():
    assert g.check_url("http://data.gdeltproject.org/gdeltv2/x.zip") == "https://data.gdeltproject.org/gdeltv2/x.zip"
    assert g.check_url("http://data.gdeltproject.org/gdeltv2/x.zip", allow_http=True).startswith("http://")
    for bad in ("https://evil.example/gdeltv2/x.zip", "ftp://data.gdeltproject.org/x", "file:///etc/passwd",
                "https://user:pw@data.gdeltproject.org/x", "https://data.gdeltproject.org.evil.example/x"):
        with pytest.raises(g.GdeltError):
            g.check_url(bad)


def test_index_urls_fetched_over_https(tmp_path):
    f = FixtureFetcher()
    adapter(tmp_path).fetch(DESK, "2026-10-20", "2026-10-21", f)
    assert f.urls and all(u.startswith("https://data.gdeltproject.org/gdeltv2/") for u in f.urls)


def test_masterfilelist_parse_filters_exports_and_range():
    idx = g.parse_masterfilelist((FX / "masterfilelist.txt").read_text() + "garbage line\n",
                                 dt.date(2026, 10, 20), dt.date(2026, 10, 20))
    assert list(idx) == ["20261020"] and [e["ts"] for e in idx["20261020"]] == ["20261020000000", "20261020001500"]


def test_constructed_index_allows_missing_slots(tmp_path):
    ad = adapter(tmp_path, index="constructed")
    df = ad.fetch(["NGA"], "2026-10-21", "2026-10-21", FixtureFetcher())
    v = df.set_index(["iso", "period", "metric"])["value"]
    assert v[("NGA", "2026-10-21", "events_total")] == 1
    assert len(ad._load_manifest()["days"]["20261021"]["absent"]) == 95


def test_provenance_and_vintage_save(tmp_path):
    from econquest.ingestion.events.base import read_event_vintage, save_event_vintage
    ad = adapter(tmp_path)
    df = ad.fetch(DESK, "2026-10-20", "2026-10-21", FixtureFetcher())
    prov = ad.provenance()
    assert prov["unmapped"] == {"": 1, "NG": 1, "US": 1} and set(prov["days"]) == {"20261020", "20261021"}
    v = save_event_vintage(tmp_path / "data", df, "gdelt", NOW, provenance=prov)
    back = read_event_vintage(tmp_path / "data", "gdelt", v.name)
    assert len(back) == len(df) and (back["vintage_id"] == v.name).all()


def test_rejects_non_iso3(tmp_path):
    with pytest.raises(ValueError):
        adapter(tmp_path).fetch(["NI"], "2026-10-20", "2026-10-20", FixtureFetcher())


def test_default_fetcher_refuses_other_hosts_without_network():
    f = g.make_url_fetcher()
    with pytest.raises(g.GdeltError):
        f("https://example.invalid/x.zip")
    with pytest.raises(g.GdeltError):
        f("https://data.gdeltproject.org/gdeltv2/x.zip", {}, b"post body")


def test_cli_respects_disabled_config(tmp_path, capsys):
    cfg = tmp_path / "live" / "events"
    cfg.mkdir(parents=True)
    (cfg / "feeds.json").write_text('{"gdelt": {"enabled": false}}')
    assert g.main(["--start", "2026-10-20", "--end", "2026-10-20", "--data-dir", str(tmp_path)]) == 2


# ------------------------------------------------------------------------------------------- SEC-A-002 regressions
# urllib is stubbed below the opener (no external network).

import email  # noqa: E402
import urllib.request  # noqa: E402
import urllib.response  # noqa: E402

from econquest.ingestion.events import base as _base  # noqa: E402


class StubWire:
    """routes: url -> (code, headers, body[, final url]); records every URL that reaches the 'wire'."""

    def __init__(self, routes):
        self.routes, self.seen = routes, []
        w = self

        class Https(urllib.request.HTTPSHandler):
            def https_open(self, req):
                return w.respond(req)

        class Http(urllib.request.HTTPHandler):
            def http_open(self, req):
                return w.respond(req)

        self.handlers = (Https, Http)

    def respond(self, req):
        self.seen.append(req.full_url)
        code, hdrs, body, *final = self.routes.get(req.full_url, (404, {}, b""))
        msg = email.message_from_string("".join(f"{k}: {v}\n" for k, v in hdrs.items()))
        resp = urllib.response.addinfourl(io.BytesIO(body), msg, final[0] if final else req.full_url, code)
        resp.msg = "stub"
        return resp


def _wire(monkeypatch, routes):
    w = StubWire(routes)
    orig = _base.build_no_redirect_opener
    monkeypatch.setattr(_base, "build_no_redirect_opener", lambda *h: orig(*w.handlers))
    return w


ML = "https://data.gdeltproject.org/gdeltv2/masterfilelist.txt"
ML_HTTP = "http://data.gdeltproject.org/gdeltv2/masterfilelist.txt"


@pytest.mark.parametrize("code", [301, 302, 303, 307, 308])
@pytest.mark.parametrize("allow_http", [False, True])
def test_default_fetcher_refuses_redirects_off_allow_list(monkeypatch, code, allow_http):
    url = ML_HTTP if allow_http else ML
    w = _wire(monkeypatch, {url: (code, {"Location": "http://evil.example/masterfilelist.txt"}, b"")})
    with pytest.raises(g.GdeltError, match=rf"HTTP {code} redirect from data.gdeltproject.org/gdeltv2/masterfilelist.txt"):
        g.make_url_fetcher(allow_http=allow_http)(url)
    assert w.seen == [url]


@pytest.mark.parametrize("final", ["https://evil.example/gdeltv2/masterfilelist.txt",
                                   "http://data.gdeltproject.org/gdeltv2/masterfilelist.txt"])
def test_default_fetcher_refuses_response_from_another_url(monkeypatch, final):
    _wire(monkeypatch, {ML: (200, {}, b"x", final)})
    with pytest.raises(g.GdeltError, match="refused"):
        g.make_url_fetcher()(ML)


def test_default_fetcher_streams_with_its_cap(monkeypatch):
    _wire(monkeypatch, {ML: (200, {}, b"x" * 100)})
    assert g.make_url_fetcher(max_bytes=100)(ML) == b"x" * 100
    with pytest.raises(g.GdeltError, match="more than 99 bytes"):
        g.make_url_fetcher(max_bytes=99)(ML)


def test_stage_uses_zip_cap_for_zips_and_index_cap_for_the_index(tmp_path, monkeypatch):
    made = []
    fx = FixtureFetcher()

    def fake_make(max_bytes=g.MAX_INDEX_BYTES, timeout=g.TIMEOUT, allow_http=False):
        def f(url, headers=None, data=None):
            made_for = "index" if url.endswith("masterfilelist.txt") else "zip"
            assert max_bytes == (g.MAX_INDEX_BYTES if made_for == "index" else g.MAX_ZIP_BYTES), (url, max_bytes)
            made.append((made_for, max_bytes))
            return fx(url, headers, data)
        return f

    monkeypatch.setattr(g, "make_url_fetcher", fake_make)
    adapter(tmp_path).fetch(DESK, "2026-10-20", "2026-10-21")
    assert ("index", g.MAX_INDEX_BYTES) in made and ("zip", g.MAX_ZIP_BYTES) in made
    assert g.MAX_ZIP_BYTES == 20 * 2**20 and g.MAX_INDEX_BYTES == 2**30


def test_unmapped_codes_are_capped_or_grouped_as_other():
    df = pd.DataFrame({"fips": ["NI", "US", "", "A1", "=cmd()", "TOOLONG", "x\ny", None]})
    _, um = g.map_countries(df, g.FIPS_TO_ISO3)
    assert um == {"US": 1, "": 2, "A1": 1, "other": 3}
