"""Usability pass fixes (EQ-C-0048, docs/usability/usability-pass-PI4.md): the run headline, `review list --pending`,
publish-preview help, a single dry-run message, install.sh --help / unknown options, and the GUI (dry-run publish
button, escaped pre-trade verdict, token hint). Offline: temp folders only, no Sheets call, no network."""
import os
import re
import shutil
import subprocess
from pathlib import Path

import pandas as pd
import pytest

from econquest import cli
from econquest.presentation import api
from econquest.presentation.dashboard import run_headline

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / "data"
PAGE = (Path(api.__file__).parent / "static" / "gui.html").read_text()
BASH = shutil.which("bash")


# ---------------------------------------------------------------- run headline
def test_run_headline_leads_with_decision_numbers_and_units():
    s = {"run_id": "r1", "as_of": "2026-10-23", "global_regime": "Calm",
         "metrics": {"var99_mm": 74.6730178889, "es99_mm": 95.5000215, "expected_loss_mm": 0.46400275, "lvar99_mm": 79.9545, "paths": 131072}}
    assert run_headline(s) == ("Run r1 as of 2026-10-23: VaR99 74.67 $mm, ES99 95.50 $mm, expected loss 0.46 $mm, "
                               "L-VaR99 79.95 $mm; global regime Calm; 131,072 paths.")
    h = run_headline({"run_id": "r2", "metrics": {"var99_mm": float("nan")}})
    assert "as of not recorded" in h and "VaR99 n/a" in h and "ES99 n/a" in h and h.endswith("global regime n/a.")


def test_run_prints_headline_last(tmp_path, capsys):
    cli.main(["--data", str(DATA), "--out", str(tmp_path / "out"), "run", "--paths", "2000", "--no-paths", "--as-of", "2026-10-23"])
    last = capsys.readouterr().out.strip().splitlines()[-1]
    band = r"(?: \(95% MC band [\d,.]+-[\d,.]+\))?"                 # EQ-C-0055: MC band, and verdicts within MC error
    assert re.fullmatch(rf"Run \S+-base as of 2026-10-23: VaR99 [\d,.]+ \$mm{band}, ES99 [\d,.]+ \$mm{band}, expected loss [\d,.]+ \$mm, "
                        rf"L-VaR99 [\d,.]+ \$mm{band}; global regime \w+; [\d,]+ paths\.(?: Within MC error: .+\.)?", last), last


# ---------------------------------------------------------------- review list --pending
def _held(d: Path):
    (d / "live").mkdir(parents=True)
    pd.DataFrame([["Inputs", "1.1", "Zambia", 40.0, 65.0, "hold", "change: 40 -> 65 (+62%)", ""],
                  ["Inputs", "1.2", "Zambia", 40.0, 148.0, "hold", "change: 40 -> 148 (+269%)", ""],
                  ["Inputs", "1.3", "Vietnam", 33.0, 28.3, "ok", "", ""]],
                 columns=["table", "key", "country", "seed", "live", "status", "reason", "decision"]).to_csv(d / "live" / "review.csv", index=False)


def review(d, *a):
    cli.main(["--data", str(d), "review", *a])


def test_review_list_points_at_held_cells_without_decision(tmp_path, capsys):
    _held(tmp_path)
    review(tmp_path, "list")
    o = capsys.readouterr().out
    assert "No review decisions recorded." in o and "2 cell(s) held by the quality gate have no decision yet" in o
    assert "econquest review list --pending" in o
    review(tmp_path, "list", "--pending")
    o = capsys.readouterr().out
    assert "1.1" in o and "1.2" in o and "Vietnam" not in o and "Decide one: econquest review approve" in o
    review(tmp_path, "decide", "--table", "Inputs", "--key", "1.2", "--country", "Zambia", "--decision", "reject", "--author", "Sam")
    capsys.readouterr()
    review(tmp_path, "list", "--pending")
    o = capsys.readouterr().out
    assert "1.1" in o and "148" not in o                                   # the decided cell is no longer pending
    review(tmp_path, "list", "--pending", "--country", "Nowhere")
    assert "No held cells waiting for a decision." in capsys.readouterr().out


def test_review_list_without_review_file_is_unchanged(tmp_path, capsys):
    review(tmp_path, "list")
    assert capsys.readouterr().out.strip() == "No review decisions recorded."
    review(tmp_path, "list", "--pending")
    assert "No held cells waiting for a decision." in capsys.readouterr().out


# ---------------------------------------------------------------- help text and messages
def test_publish_preview_options_have_help(capsys):
    with pytest.raises(SystemExit):
        cli.main(["publish-preview", "--help"])
    o = capsys.readouterr().out
    flat = " ".join(o.split())
    for opt, words in (("--baseline FILE", "what the workbook holds now"), ("--plan FILE", "the new plan to check"),
                       ("--tolerance TOLERANCE", "count as unchanged"), ("--large LARGE", "flagged as large (default 0.25 = 25%)"),
                       ("--dest DIR", "folder for the HTML and CSV report"), ("--urls", "batchGet URLs"),
                       ("--spreadsheet-id SPREADSHEET_ID", "workbook the --urls point at")):
        assert re.search(re.escape(opt) + r" [^-]*?" + re.escape(words), flat), opt


def test_version_flag_and_folder_help(capsys):
    from econquest import __version__
    with pytest.raises(SystemExit) as e:
        cli.main(["--version"])
    assert e.value.code == 0 and capsys.readouterr().out.strip() == f"econquest {__version__}"
    with pytest.raises(SystemExit):
        cli.main(["--help"])
    o = " ".join(capsys.readouterr().out.split())
    assert "--data DATA input folder (default:" in o and "--out OUT outputs folder (default:" in o


def test_review_list_help_mentions_pending(capsys):
    with pytest.raises(SystemExit):
        cli.main(["review", "list", "--help"])
    assert "--pending" in capsys.readouterr().out


def test_publish_dry_run_says_dry_run_once(tmp_path, capsys):
    cli.main(["--data", str(DATA), "--out", str(tmp_path / "out"), "publish", "--dry-run", "--paths", "2000", "--mc-rows", "20", "--no-garch"])
    cap = capsys.readouterr()
    both = cap.out + cap.err
    assert both.count("Dry run") == 1 and "Plan saved. Apply it with any Sheets client" in cap.out
    assert "publish-preview" in cap.out and (tmp_path / "out" / "publish_plan.json").exists()


# ---------------------------------------------------------------- install.sh options
def _sh(home: Path, *args) -> subprocess.CompletedProcess:
    env = {"HOME": str(home), "PATH": os.environ.get("PATH", "/usr/bin:/bin"), "ECONQUEST_INSTALL_SKIP_VENV": "1", "ECONQUEST_NO_PROFILE": "1"}
    return subprocess.run([BASH, str(ROOT / "install.sh"), *args], env=env, capture_output=True, text=True, timeout=60)


@pytest.mark.skipif(BASH is None, reason="bash not available")
def test_install_help_and_unknown_option_change_nothing(tmp_path):
    for a in ("--help", "-h"):
        r = _sh(tmp_path, a)
        assert r.returncode == 0 and "Usage: bash install.sh" in r.stdout and "Upgrade:" in r.stdout and "--uninstall" in r.stdout
    r = _sh(tmp_path, "--upgrade")
    assert r.returncode == 1 and "unknown option '--upgrade'" in r.stderr and "nothing was changed" in r.stderr
    assert not (tmp_path / "econquest").exists() and not (tmp_path / "econquest-backups").exists()


def test_install_next_steps_do_not_suggest_the_deprecated_token_flag():
    text = (ROOT / "install.sh").read_text()
    tail = text[text.index("EconQuest is installed."):]
    assert "--token" not in tail and "publish --dry-run" in tail and "publish --write" in tail and "review list --pending" in tail
    assert "Upgrading later" in tail


# ---------------------------------------------------------------- GUI
def test_gui_has_dry_run_publish_button_without_token():
    btn = re.search(r'<button data-job="publish" data-args="--dry-run[^"]*"[^>]*>Save publish plan \(no write\)</button>', PAGE)
    assert btn and "data-token" not in btn.group(0)
    assert 'data-args="--mc-rows 2000" data-token="1">Publish to workbook' in PAGE            # the write button is unchanged
    assert "use Save publish plan (no write)" in PAGE                                         # token hint names the way out


def test_gui_pretrade_verdict_escaped_and_labelled_as_saved():
    fn = PAGE[PAGE.index("async function pretradeResult()"):PAGE.index("async function startJob(b)")]
    assert "${esc(String(pt.verdict).toUpperCase())}" in fn and "<li>${esc(r)}</li>" in fn
    assert "${pt.verdict.toUpperCase()}" not in fn and "<li>${r}</li>" not in fn
    assert "Last saved check (outputs/pretrade.json)" in fn
    # AGENT-09 (SEC-C-006 L1): no field of the saved pretrade.json reaches innerHTML raw (pt.paths was); only the
    # reasons list's .map() may start with ${pt., and it escapes each item (asserted above)
    raw = [m for m in re.findall(r"\$\{pt\.[^}]*\}?", fn) if ".map(" not in m]
    assert raw == [] and "${esc(pt.paths)} paths" in fn


def test_gui_ideas_run_label_is_not_confused_with_the_run_chip():
    assert "Newest ideas opened by run ${esc(IDEAS.run_id)}" in PAGE and "Latest run ${esc(IDEAS.run_id)}" not in PAGE


# ---------------------------------------------------------------- review decide on several cells (EQ-C-0052, U06)
def _batch(tmp_path, *a):
    d = tmp_path / "data"
    cli.main(["--data", str(d), "--out", str(tmp_path / "out"), "review", "decide", *a])


def _decide_log(tmp_path):
    from econquest.ops import actionlog as AL
    return [r for r in AL.read(tmp_path / "out") if r["command"] == "review decide"]


def test_decide_all_pending_four_eyes_per_cell_and_one_log_row_per_cell(tmp_path, capsys):
    from econquest.ingestion import read_ledger
    d = tmp_path / "data"; _held(d)
    with pytest.raises(SystemExit, match="four-eyes.*--self-approved.*nothing recorded for the 2 cell"):
        _batch(tmp_path, "--all-pending", "--decision", "apply", "--author", "Sam")
    assert len(read_ledger(d)) == 0
    assert [r["outcome"] for r in _decide_log(tmp_path)] == ["error"]
    _batch(tmp_path, "--all-pending", "--decision", "apply", "--author", "Sam", "--approver", "Ana", "--vintage", "2026-10-23")
    led = read_ledger(d)
    assert led[["key", "country", "gate_status", "decision", "approver", "vintage_id"]].values.tolist() == [
        ["1.1", "Zambia", "hold", "apply", "Ana", "2026-10-23"], ["1.2", "Zambia", "hold", "apply", "Ana", "2026-10-23"]]
    assert led["live"].astype(float).tolist() == [65.0, 148.0]          # taken from review.csv, not copied by hand
    rows = _decide_log(tmp_path)[1:]
    assert [(r["outcome"], r["args"]["key"], r["args"]["batch"]) for r in rows] == [("ok", "1.1", "1/2"), ("ok", "1.2", "2/2")]
    assert "2 decision(s) recorded." in capsys.readouterr().out
    _batch(tmp_path, "--all-pending", "--decision", "apply", "--author", "Sam", "--self-approved")
    assert "No held cells waiting for a decision." in capsys.readouterr().out and len(read_ledger(d)) == 2


def test_decide_named_cells_and_refusals(tmp_path):
    from econquest.ingestion import read_ledger
    d = tmp_path / "data"; _held(d)
    with pytest.raises(SystemExit, match="not a held cell in data/live/review.csv: Inputs 1.3 Vietnam"):
        _batch(tmp_path, "--cell", "Inputs", "1.3", "Vietnam", "--decision", "hold", "--author", "Sam")
    with pytest.raises(SystemExit, match="come from data/live/review.csv"):
        _batch(tmp_path, "--cell", "Inputs", "1.1", "Zambia", "--live", "5", "--decision", "hold", "--author", "Sam")
    with pytest.raises(SystemExit, match="not both"):
        _batch(tmp_path, "--cell", "Inputs", "1.1", "Zambia", "--all-pending", "--decision", "hold", "--author", "Sam")
    with pytest.raises(SystemExit, match="give --table, --key and --country for one cell"):
        _batch(tmp_path, "--table", "Inputs", "--decision", "hold", "--author", "Sam")
    assert len(read_ledger(d)) == 0
    _batch(tmp_path, "--cell", "Inputs", "1.2", "Zambia", "--decision", "apply", "--author", "Sam", "--self-approved")
    led = read_ledger(d)
    assert led[["key", "self_approved", "approver"]].values.tolist() == [["1.2", "yes", "Sam"]]
    assert [r["args"]["key"] for r in _decide_log(tmp_path) if r["outcome"] == "ok"] == ["1.2"]


def test_single_decide_still_logs_one_row(tmp_path):
    _batch(tmp_path, "--table", "Inputs", "--key", "1.3", "--country", "Argentina", "--decision", "reject", "--author", "Sam")
    assert [r["outcome"] for r in _decide_log(tmp_path)] == ["ok"]


# ---------------------------------------------------------------- editorial messages name the CLI flags (EQ-C-0052, U12)
def test_editorial_messages_name_cli_flags(tmp_path):
    from econquest.presentation import editorial as E
    from test_compliance import META, write
    out = tmp_path / "outputs"; (out / "reports").mkdir(parents=True); (tmp_path / "data").mkdir()
    it = E.register_draft(out, "country_note", [write(out)], META, "Alice")
    with pytest.raises(E.EditorialError) as e:
        E.review(out, it["item_id"], "alice")
    assert "a reviewer other than the author" in str(e.value) and "--self-reviewed" in str(e.value)
    assert "an reviewer" not in str(e.value) and "self_reviewed=True" not in str(e.value)
    with pytest.raises(E.EditorialError, match="--conflicts, --acknowledge or --compliance-approve"):
        E.checklist(out, it["item_id"], "Alice")
    E.review(out, it["item_id"], "Bob")
    st = E.checklist_status(out, it["item_id"], data_dir=tmp_path / "data")
    text = " ".join(st["problems"])
    assert "--conflicts" in text and "--compliance-approve" in text and "--self-signed --exc EXC-nnn" in text
    assert "checklist(" not in text and "self_signed=True" not in text
    with pytest.raises(E.EditorialError, match=r"--self-signed with --exc EXC-nnn"):
        E.checklist(out, it["item_id"], "Alice", conflicts="no conflicts", compliance_approve=True)
    with pytest.raises(E.EditorialError, match=r"\(--exc EXC-nnn\)"):
        E.checklist(out, it["item_id"], "Alice", compliance_approve=True, self_signed=True)


# ---------------------------------------------------------------- PI-5 (EQ-C-0063): U22 GUI ideas jobs, workbook note
class _FakePopen:
    last = None

    def __init__(self, argv, **kw):
        _FakePopen.last = self
        self.argv, self.env, self.stdout, self.returncode = argv, kw.get("env") or {}, iter(()), 0

    def poll(self):
        return 0

    def wait(self):
        return 0


@pytest.fixture
def gui_jobs(monkeypatch, tmp_path):
    from econquest.presentation import gui
    monkeypatch.setattr(gui.subprocess, "Popen", _FakePopen)
    return gui.Jobs(str(tmp_path), str(tmp_path))


@pytest.mark.parametrize("args, tail", [
    (["report"], ["report"]),
    (["log"], ["log"]),
    (["log", "--run-id", "20261023T163707-base"], ["log", "--run-id", "20261023T163707-base"]),
    (["report", "--write", "--token-file", "/tmp/t", "--allow-unattested"], ["report"]),      # GUI flag-stripping applies
    (["log", "--wr", "--allow"], ["log"]),
])
def test_gui_ideas_job_runs_read_only_subcommands_with_flags_stripped(gui_jobs, args, tail):
    _FakePopen.last = None
    gui_jobs.start("ideas", args, sheets_token="ya29.secret")
    argv = _FakePopen.last.argv
    assert argv[argv.index("ideas") + 1:] == tail
    assert "ECONQUEST_SHEETS_TOKEN" not in _FakePopen.last.env                 # not a writer: the token never reaches it


@pytest.mark.parametrize("args", [[], ["mark"], ["mark", "--as-of", "2026-10-21"], ["--run-id", "x", "log"], ["Report"],
                                  ["--allow-unattested", "mark"], ["--write", "mark"]])
def test_gui_ideas_job_refuses_mark_and_anything_but_report_or_log(gui_jobs, args):
    _FakePopen.last = None
    with pytest.raises(ValueError, match="the GUI runs only ideas report or ideas log"):
        gui_jobs.start("ideas", args)
    assert _FakePopen.last is None and gui_jobs.jobs == []                    # nothing started, nothing listed


def test_gui_has_ideas_buttons_for_report_and_log_only():
    from econquest.presentation import gui
    btns = re.findall(r'<button data-job="ideas" data-args="([^"]*)"([^>]*)>([^<]*)</button>', PAGE)
    assert [a for a, _, _ in btns] == ["report", "log"] == list(gui.GUI_SUBCMDS["ideas"])
    assert all("data-token" not in attrs for _, attrs, _ in btns)
    assert "Trade-idea report (read only)" in PAGE and "Update trade-idea log from the latest run" in PAGE
    assert "econquest ideas mark" in PAGE                                      # the ideas tab says where marking lives


def test_workbook_ideas_note_says_newest_ideas_not_latest_run():
    from econquest.presentation import sheets_publish as SP
    plan = SP.ideas_plan({"status": "ok", "message": "3 ideas.", "run_id": "20261023T163707-base", "quarters": []}, stamp="2026-10-24")
    note = plan[0]["values"][1][0]
    assert note == "[OK] 3 ideas. Newest ideas opened by run 20261023T163707-base (the latest model run can be newer)."
    assert "Latest run" not in note
    assert SP.ideas_plan({"status": "missing", "message": "No log."}, stamp="2026-10-24")[0]["values"][1][0] == "[MISSING] No log."
