"""EQ-A-0006: append-only review ledger, four-eyes rule, review.csv regenerated without losing decisions, and
apply_report honouring ledger decisions."""
import datetime as dt
import sys
from pathlib import Path

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.ingestion import (load_universe, record_decision, load_decisions, write_review, effective_holds,  # noqa: E402
                                 ledger_path)
from econquest.ingestion.feeds import FetchReport, diff_against_seed, quality_gate, apply_report  # noqa: E402
from econquest.ingestion.ledger import LEGACY_AUTHOR  # noqa: E402

DATA = ROOT / "data"
T0 = dt.datetime(2026, 10, 24, 9, 0, tzinfo=dt.timezone.utc)
COUNTS = ("indicator_cells", "profile_cells", "held_for_review")


@pytest.fixture(scope="module")
def u():
    return load_universe(DATA)


def _gate_case(u):
    """One ok Inputs cell (tiny change to 5.5), one range-held Inputs cell (1.3 = 9999) and one held profile cell."""
    names = u.names
    ind = pd.DataFrame(index=u.indicators["id"].astype(str), columns=names, dtype=float)
    ind.at["1.3", names[0]] = 9999.0
    ind.at["5.5", names[1]] = float(pd.to_numeric(u.indicators.set_index("id").at["5.5", names[1]])) + 0.1
    prof = pd.DataFrame(index=names, columns=["pop", "exports", "reserves", "fx3m", "policy", "equity_vol"], dtype=float)
    prof.at[names[2], "reserves"] = 5000.0
    rep = FetchReport(ind, prof, pd.DataFrame(), {"weo": "ok (1 rows)"}, {})
    return rep, quality_gate(u, rep, diff_against_seed(u, rep))


def _data(tmp_path):
    tmp_path.mkdir(parents=True, exist_ok=True)
    for f in ("indicators.csv", "countries.csv"):
        (tmp_path / f).write_bytes((DATA / f).read_bytes())
    return tmp_path


def test_ledger_is_append_only(tmp_path):
    record_decision(tmp_path, "Inputs", "1.3", "Vietnam", "hold", "alice", note="check source", now=T0)
    first = ledger_path(tmp_path).read_bytes()
    record_decision(tmp_path, "Inputs", "1.3", "Vietnam", "reject", "bob", now=T0 + dt.timedelta(minutes=1))
    after = ledger_path(tmp_path).read_bytes()
    assert after.startswith(first) and len(after) > len(first)
    assert len(pd.read_csv(ledger_path(tmp_path))) == 2
    latest = load_decisions(tmp_path)
    assert len(latest) == 1 and latest.iloc[0]["decision"] == "reject" and latest.iloc[0]["author"] == "bob"


def test_decision_validation_and_four_eyes(tmp_path):
    with pytest.raises(ValueError):
        record_decision(tmp_path, "Inputs", "1.3", "Vietnam", "accept", "alice")
    with pytest.raises(ValueError):
        record_decision(tmp_path, "Inputs", "1.3", "Vietnam", "hold", "")
    with pytest.raises(ValueError):                              # held cell, no approver
        record_decision(tmp_path, "Inputs", "1.3", "Vietnam", "apply", "alice", gate_status="hold")
    with pytest.raises(ValueError):                              # approver is the author
        record_decision(tmp_path, "Inputs", "1.3", "Vietnam", "apply", "alice", approver="Alice", gate_status="hold")
    assert not ledger_path(tmp_path).exists()
    record_decision(tmp_path, "Inputs", "1.3", "Vietnam", "apply", "alice", approver="sam", gate_status="hold")
    record_decision(tmp_path, "Inputs", "5.5", "Vietnam", "apply", "alice", gate_status="ok")   # ok cell needs no approver
    assert len(load_decisions(tmp_path)) == 2


def test_write_review_keeps_decisions_across_gate_runs(u, tmp_path):
    rep, rev = _gate_case(u)
    n0 = u.names[0]
    record_decision(tmp_path, "Inputs", "1.3", n0, "apply", "alice", approver="sam", gate_status="hold", note="confirmed with IMF desk", now=T0)
    out1 = write_review(tmp_path, rev)
    out2 = write_review(tmp_path, rev.copy())                   # next fetch: fresh gate output, no decision column
    on_disk = pd.read_csv(tmp_path / "live" / "review.csv", dtype={"key": str}, keep_default_na=False)
    for df in (out1, out2, on_disk):
        row = df[(df["key"] == "1.3") & (df["country"] == n0)].iloc[0]
        assert (row["decision"], row["author"], row["approver"]) == ("apply", "alice", "sam") and row["decided_utc"].startswith("2026-10-24T09:00")
    assert len(out2) == len(rev) and len(pd.read_csv(ledger_path(tmp_path))) == 1


def test_write_review_imports_legacy_free_text_once(tmp_path):
    live = tmp_path / "live"; live.mkdir()
    pd.DataFrame([{"table": "Inputs", "key": "1.3", "country": "Vietnam", "seed": 1, "live": 2, "status": "ok", "reason": "", "decision": "applied 2026-10-23: accepted"},
                  {"table": "Country Profile", "key": "reserves", "country": "Venezuela", "seed": 4, "live": 9.8, "status": "hold", "reason": "", "decision": "kept on hold: keep seed"}]
                 ).to_csv(live / "review.csv", index=False)
    gate = pd.DataFrame([{"table": "Country Profile", "key": "reserves", "country": "Venezuela", "seed": 4, "live": 9.8, "status": "hold", "reason": "stale"}])
    out = write_review(tmp_path, gate)
    led = pd.read_csv(ledger_path(tmp_path), dtype=str, keep_default_na=False)
    assert list(led["decision"]) == ["apply", "hold"] and set(led["author"]) == {LEGACY_AUTHOR}
    assert out.iloc[0]["decision"] == "hold"
    write_review(tmp_path, gate)
    assert len(pd.read_csv(ledger_path(tmp_path))) == 2           # imported only once


def test_legacy_import_restores_gate_hold_for_hand_edited_ok_rows(tmp_path):
    """EQ-A-0044: the 2026-10-23 review.csv has 72 rows with status ok and a gate reason (e.g. 6.2 'stale: latest period
    2011'). The gate never writes that; it is a hold hand-edited to ok on review. The import keeps the gate's verdict,
    and the legacy apply (no approver) does not release the hold the next gate run makes."""
    from econquest.ingestion.ledger import effective_holds, load_decisions
    live = tmp_path / "live"; live.mkdir()
    pd.DataFrame([{"table": "Inputs", "key": "6.2", "country": "Vietnam", "seed": 1, "live": 1.5, "status": "ok",
                   "reason": "stale: latest period 2011", "decision": "applied 2026-10-23: accepted on review"},
                  {"table": "Inputs", "key": "1.3", "country": "Vietnam", "seed": 1, "live": 2, "status": "ok", "reason": "",
                   "decision": "applied 2026-10-23: accepted"}]).to_csv(live / "review.csv", index=False)
    gate = pd.DataFrame([{"table": "Inputs", "key": "6.2", "country": "Vietnam", "seed": 1, "live": 1.5, "status": "hold",
                          "reason": "stale: latest period 2011"}])
    write_review(tmp_path, gate)
    led = pd.read_csv(ledger_path(tmp_path), dtype=str, keep_default_na=False).set_index("key")
    assert led.at["6.2", "gate_status"] == "hold" and led.at["6.2", "note"].startswith("[gate held it (stale: latest period 2011)")
    assert led.at["1.3", "gate_status"] == "ok" and led.at["1.3", "note"] == "applied 2026-10-23: accepted"
    assert ("Inputs", "6.2", "Vietnam") in effective_holds(gate, load_decisions(tmp_path))


def test_effective_holds_rules():
    rev = pd.DataFrame([{"table": "Inputs", "key": "1.3", "country": "A", "status": "hold", "live": 5.0},
                        {"table": "Inputs", "key": "1.3", "country": "B", "status": "hold", "live": 5.0},
                        {"table": "Inputs", "key": "5.5", "country": "A", "status": "ok"},
                        {"table": "Inputs", "key": "5.5", "country": "B", "status": "ok"}])
    dec = pd.DataFrame([{"table": "Inputs", "key": "1.3", "country": "A", "decision": "apply", "author": "alice", "approver": "sam", "live": "5.0"},
                        {"table": "Inputs", "key": "1.3", "country": "B", "decision": "apply", "author": "alice", "approver": "", "live": "5.0"},
                        {"table": "Inputs", "key": "5.5", "country": "A", "decision": "reject", "author": "alice", "approver": ""}])
    assert effective_holds(rev, dec) == {("Inputs", "1.3", "B"), ("Inputs", "5.5", "A")}
    assert effective_holds(rev, None) == {("Inputs", "1.3", "A"), ("Inputs", "1.3", "B")}


def test_apply_honours_reject_on_ok_cell_and_approved_apply_on_hold(u, tmp_path):
    rep, rev = _gate_case(u)
    d = _data(tmp_path); names = u.names
    seed = pd.read_csv(d / "indicators.csv", dtype={"id": str}).set_index("id")
    record_decision(d, "Inputs", "5.5", names[1], "reject", "alice", gate_status="ok", note="WEO revision pending")
    record_decision(d, "Inputs", "1.3", names[0], "apply", "alice", approver="sam", gate_status="hold", live=9999.0)
    merged = write_review(d, rev)
    out = apply_report(rep, d, review=merged)
    after = pd.read_csv(d / "indicators.csv", dtype={"id": str}).set_index("id")
    assert float(after.at["1.3", names[0]]) == 9999.0                           # approved apply on a gate hold
    assert after.at["5.5", names[1]] == seed.at["5.5", names[1]]                # reject on an ok cell
    assert {k: out[k] for k in COUNTS} == {"indicator_cells": 1, "profile_cells": 0, "held_for_review": 2}   # 5.5 rejected + reserves gate hold
    # ledger alone (review without decision column) gives the same holds
    d2 = _data(tmp_path / "b"); (d2 / "live").mkdir()
    ledger_path(d2).write_bytes(ledger_path(d).read_bytes())
    out2 = apply_report(rep, d2, review=rev)
    assert {k: out2[k] for k in COUNTS} == {k: out[k] for k in COUNTS}
    # force applies everything and reports the cells it overrode
    forced = apply_report(rep, d, review=merged, force=True, author="alice", approver="sam")
    assert forced["held_for_review"] == 0
    assert set(forced["forced_cells"]) == {("Inputs", "5.5", names[1]), ("Country Profile", "reserves", names[2])}


def test_stale_approval_does_not_clear_new_hold(tmp_path):
    """SEC-A-001 M1: an approval at live=5.0 must not release a later hold of the same cell at live=500.0."""
    record_decision(tmp_path, "Inputs", "1.3", "X", "apply", "alice", approver="sam", gate_status="hold", live=5.0, vintage_id="v1")
    dec = load_decisions(tmp_path)
    rev = lambda live: pd.DataFrame([{"table": "Inputs", "key": "1.3", "country": "X", "live": live, "status": "hold"}])
    assert effective_holds(rev(500.0), dec) == {("Inputs", "1.3", "X")}
    assert effective_holds(rev(500.0), dec, vintage_id="v2") == {("Inputs", "1.3", "X")}
    assert effective_holds(rev(500.0), dec, vintage_id="v1") == {("Inputs", "1.3", "X")}  # L1: a named value binds even in the same vintage
    record_decision(tmp_path, "Inputs", "1.4", "X", "apply", "alice", approver="sam", gate_status="hold", vintage_id="v1")  # no value: vintage binds
    rev4 = pd.DataFrame([{"table": "Inputs", "key": "1.4", "country": "X", "live": 7.0, "status": "hold"}])
    assert effective_holds(rev4, load_decisions(tmp_path), vintage_id="v1") == set()
    assert effective_holds(rev4, load_decisions(tmp_path), vintage_id="v2") == {("Inputs", "1.4", "X")}
    assert effective_holds(rev(5.0 * (1 + 1e-8)), dec, vintage_id="v2") == set()  # same value within tolerance
    # hold / reject persist across vintages and values
    record_decision(tmp_path, "Inputs", "5.5", "X", "reject", "alice", live=1.0, vintage_id="v1")
    ok = pd.DataFrame([{"table": "Inputs", "key": "5.5", "country": "X", "live": 2.0, "status": "ok"}])
    assert effective_holds(ok, load_decisions(tmp_path), vintage_id="v2") == {("Inputs", "5.5", "X")}


def test_force_needs_author_and_is_ledgered(u, tmp_path):
    """SEC-A-001 M2: force requires author + approver, appends one ledger row per forced cell, writes forced_cells.csv,
    and the result is a plain dict that serialises completely."""
    import json
    rep, rev = _gate_case(u)
    d = _data(tmp_path); names = u.names
    before = {f: (d / f).read_bytes() for f in ("indicators.csv", "countries.csv")}
    with pytest.raises(ValueError):
        apply_report(rep, d, review=rev, force=True)
    with pytest.raises(ValueError):
        apply_report(rep, d, review=rev, force=True, author="alice")
    with pytest.raises(ValueError):                            # same person after NFKC + format-char stripping
        apply_report(rep, d, review=rev, force=True, author="alice", approver=" ALICE\u200b")
    assert {f: (d / f).read_bytes() for f in before} == before and not ledger_path(d).exists()
    out = apply_report(rep, d, review=rev, force=True, author="alice", approver="sam", vintage_id=None)
    assert type(out) is dict and set(json.loads(json.dumps(out))) >= {"snapshot", "forced_cells", "held_for_review"}
    want = {("Inputs", "1.3", names[0]), ("Country Profile", "reserves", names[2])}
    assert set(out["forced_cells"]) == want
    led = load_decisions(d)
    assert len(led) == 2 and set(led["note"]) == {"forced"} and set(led["decision"]) == {"apply"}
    assert set(led["author"]) == {"alice"} and set(led["approver"]) == {"sam"}
    fc = pd.read_csv(Path(out["snapshot"]) / "forced_cells.csv", dtype=str)
    assert set(zip(fc["table"], fc["key"], fc["country"])) == want
    # non-force path is unchanged and needs no author
    assert apply_report(rep, _data(tmp_path / "c"), review=rev)["held_for_review"] == 2


def test_single_operator_self_approval(u, tmp_path):
    """Sam 2026-10-23: a flagged self-approval releases a hold, is stored with approver=author and self_approved=yes,
    and is visible in write_review; without the flag four-eyes still applies."""
    with pytest.raises(ValueError):
        record_decision(tmp_path, "Inputs", "1.3", "X", "apply", "alice", approver="alice", gate_status="hold", live=5.0)
    row = record_decision(tmp_path, "Inputs", "1.3", "X", "apply", "alice", gate_status="hold", live=5.0, self_approved=True)
    assert (row["approver"], row["self_approved"]) == ("alice", "yes")
    rev = pd.DataFrame([{"table": "Inputs", "key": "1.3", "country": "X", "seed": 4.0, "live": 5.0, "status": "hold", "reason": "range"}])
    assert effective_holds(rev, load_decisions(tmp_path)) == set()
    out = write_review(tmp_path, rev)
    assert out.iloc[0]["self_approved"] == "yes" and out.iloc[0]["approver"] == "alice"
    # force in single-operator mode
    rep, grev = _gate_case(u)
    d = _data(tmp_path / "f")
    res = apply_report(rep, d, review=grev, force=True, author="sam", self_approved=True)
    led = load_decisions(d)
    assert len(res["forced_cells"]) == 2 and set(led["self_approved"]) == {"yes"} and set(led["approver"]) == {"sam"}


def test_old_ledger_without_self_approved_column(tmp_path):
    """A ledger written before the self_approved column keeps its header; new rows are still read correctly."""
    p = ledger_path(tmp_path); p.parent.mkdir(parents=True)
    p.write_text("ts_utc,vintage_id,table,key,country,gate_status,live,decision,author,approver,note\n"
                 "2026-10-23T00:00:00.000000Z,,Inputs,1.3,X,hold,5.0,apply,alice,sam,old\n")
    record_decision(tmp_path, "Inputs", "1.3", "Y", "apply", "bob", gate_status="hold", live=1.0, self_approved=True)
    led = load_decisions(tmp_path)
    assert list(led["self_approved"]) == ["", "yes"] and list(led["note"]) == ["old", ""]
    assert p.read_text().startswith("ts_utc,vintage_id,table,key,country,gate_status,live,decision,author,approver,note\n2026")


def test_unknown_vintage_fails_before_any_write(u, tmp_path):
    """SEC-A-001 L1: apply_report(vintage_id=<unknown>) raises before matching approvals or writing inputs."""
    rep, rev = _gate_case(u)
    d = _data(tmp_path)
    before = {f: (d / f).read_bytes() for f in ("indicators.csv", "countries.csv")}
    with pytest.raises(FileNotFoundError):
        apply_report(rep, d, review=rev, vintage_id="v-old")
    assert {f: (d / f).read_bytes() for f in before} == before
