"""`econquest fit-hazard`: panel_history fetch with resume (HO-20261023-A-C-011) and the Team B gate, events loader and
end default (HO-20261023-B-C-008). No network: the panel_history fetchers are faked."""
import shutil
from pathlib import Path
from types import SimpleNamespace

import pandas as pd
import pytest

from econquest import cli
from econquest.ingestion import panel_history as ph
from econquest.ops import approvals as ap
from econquest.validation import hazard_panel as hp

ROOT = Path(__file__).resolve().parent.parent
ISOS = ["ARG", "ECU"]


class Stop(Exception):
    pass


def fake_weo(calls):
    def f(vintage, codes, isos):
        calls.append(("weo", vintage))
        return pd.DataFrame([{"iso": i, "series": c, "period": y, "value": 1.0, "source": "fake"}
                             for i in ISOS for c in codes for y in range(2010, 2019)])
    return f


def fake_wb(calls, fail=()):
    def f(code, start, end, isos):
        calls.append(("worldbank", code))
        if code in fail:
            raise TimeoutError(f"simulated timeout {code}")
        return pd.DataFrame([{"iso": i, "series": code, "period": y, "value": 1.0, "source": "fake"} for i in ISOS for y in range(2010, 2019)])
    return f


@pytest.fixture
def data(tmp_path):
    d = tmp_path / "data"; (d / "panel").mkdir(parents=True)
    shutil.copy(ROOT / "data" / "panel" / "sovereign_defaults.csv", d / "panel" / "sovereign_defaults.csv")
    (d / "panel" / "weo_history.csv").write_text("iso,series,period,value,source\nARG,GGXWDG_NGDP,2010,40,old\n")
    return d


def fh(d, *a):
    cli.main(["--data", str(d), "--out", str(d.parent / "out"), "fit-hazard", *a])


def test_min_auc_default_and_end_default(monkeypatch):
    seen = {}
    monkeypatch.setattr(cli, "cmd_fit_hazard", lambda args: seen.update(vars(args)))
    cli.main(["fit-hazard"])
    assert seen["min_auc"] == 0.75 and seen["end"] is None and seen["resume"] is None


def test_incomplete_fetch_exits_1_and_resume_refetches_only_failed_unit(data, monkeypatch, capsys):
    calls = []
    monkeypatch.setattr(ph, "WeoVintageFetcher", lambda cache: fake_weo(calls))
    monkeypatch.setattr(ph, "worldbank_series_fetcher", fake_wb(calls, fail={"PV.EST"}))
    monkeypatch.setattr(ph.time, "sleep", lambda s: None)
    monkeypatch.setattr(hp, "panel_from_long", lambda *a, **k: (_ for _ in ()).throw(Stop()))
    before = (data / "panel" / "weo_history.csv").read_bytes()
    with pytest.raises(SystemExit) as e:
        fh(data, "--build-panel", "--fetch", "--weo-vintages", "2018-04:2018-10")
    assert e.value.code == 1
    assert "worldbank/PV.EST" in capsys.readouterr().err
    assert (data / "panel" / "weo_history.csv").read_bytes() == before          # untouched on failure
    run_id = next((data / "panel" / "staging").glob("2*")).name
    calls.clear()
    monkeypatch.setattr(ph, "worldbank_series_fetcher", fake_wb(calls))
    with pytest.raises(Stop):                                                    # fetch completes, then the build starts
        fh(data, "--build-panel", "--fetch", "--resume", run_id)
    assert calls == [("worldbank", "PV.EST")]
    weo = pd.read_csv(data / "panel" / "weo_history.csv", dtype={"vintage": str})
    assert sorted(set(weo["vintage"])) == ["2018-04", "2018-10"]


def test_resume_needs_fetch(data):
    with pytest.raises(SystemExit, match="--fetch"):
        fh(data, "--build-panel", "--resume", "20261023T000000Z")


def test_events_via_load_events_and_end_from_episodes(data, monkeypatch):
    got = {}
    ev = pd.DataFrame({"iso": ["ARG", "ECU"], "start": [2001, 2020], "end": [2005, 2024]})
    monkeypatch.setattr(hp, "load_events", lambda p, **k: got.setdefault("path", Path(p)) and ev)

    def fake_panel(weo, wbh, events, features=None, start=1980, end=None, forecast_cutoff=None, **k):
        got.update(end=end, cutoff=forecast_cutoff)
        raise Stop()
    monkeypatch.setattr(hp, "panel_from_long", fake_panel)
    valet = data / "DEBT_2026.csv"; valet.write_text("x\n")
    with pytest.raises(Stop):
        fh(data, "--build-panel", "--defaults", str(valet))
    assert got == {"path": valet, "end": 2023, "cutoff": 2023}
    with pytest.raises(Stop):
        fh(data, "--build-panel", "--end", "2019")
    assert (got["end"], got["cutoff"]) == (2019, 2019)


@pytest.mark.parametrize("cleared", [True, False])
def test_apply_proposes_mode_switch_only_when_gate_clears(data, monkeypatch, capsys, cleared):
    panel = data / "p.csv"; pd.DataFrame({"iso": ["ARG"], "year": [2010], "event": [0]}).to_csv(panel, index=False)
    res = SimpleNamespace(coef={"x": 0.1}, intercept=-3.0, in_sample={"auc": 0.8}, out_of_sample={"auc": 0.8}, events=40,
                          fitted_block=lambda: {"coef": {"x": 0.1}})
    monkeypatch.setattr(hp, "fit_and_validate", lambda *a, **k: res)
    gates = []
    monkeypatch.setattr(hp, "gate_check", lambda r, a, e: gates.append((a, e)) or {"cleared": cleared, "checks": {}})
    monkeypatch.setattr(hp, "write_report", lambda *a, **k: gates.append(k.get("gate")) or data / "r.md")
    props = []
    monkeypatch.setattr(ap, "propose", lambda d, f, patch, author, msg, **k: props.append(patch) or {"id": "CH-1", "tier": 1})
    fh(data, "--panel", str(panel), "--apply", "--author", "sam")
    assert gates[0] == (0.75, 30) and gates[1] == {"cleared": cleared, "checks": {}}   # gate computed before the report
    assert ("/layer1/mode" in props[0]) == cleared and "/layer1_fitted" in props[0]
    assert ("NOT proposing" in capsys.readouterr().out) == (not cleared)
