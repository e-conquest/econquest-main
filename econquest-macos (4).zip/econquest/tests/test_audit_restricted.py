"""SEC-A-006 M1 (EQ-A-0045): applied cells whose value came from Yahoo or a non-commercial / personal licence.

Uses copies of the real data/ files (countries.csv, indicators.csv, audit_trail.csv, live/provenance.csv and the
2026-10-23 vintage's provenance.csv); the "official pull" values below are SYNTHETIC."""
import shutil
import sys
from pathlib import Path

import pandas as pd
import pytest

ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT))
from econquest.ingestion import audit, feeds  # noqa: E402
from econquest.ingestion.audit import restricted_source_cells  # noqa: E402

DATA = ROOT / "data"
FILES = ["countries.csv", "indicators.csv", "audit_trail.csv", "live/provenance.csv",
         "live/vintages/2026-10-23/provenance.csv"]


def _copy(tmp_path) -> Path:
    d = tmp_path / "data"
    for f in FILES:
        (d / f).parent.mkdir(parents=True, exist_ok=True)
        shutil.copy(DATA / f, d / f)
    return d


def _official_pull(d: Path, skip=()):
    """SYNTHETIC official FX pull: provenance.csv fx3m rows become BIS rows with new values, applied to countries.csv
    (except the countries in `skip`, which the pull did not serve)."""
    prov = pd.read_csv(d / "live" / "provenance.csv", dtype={"key": str})
    yahoo = prov["source"].str.contains("yfinance", case=False)
    prov = prov[~yahoo | (prov["key"] != "equity_vol")].copy()   # equity_vol has no official source (EQ-A-0040)
    fx = prov["key"] == "fx3m"
    prov = prov[~(fx & prov["country"].isin(skip))].copy()
    fx = prov["key"] == "fx3m"
    prov.loc[fx, "source"] = feeds.XRU_SOURCE
    prov.loc[fx, "value"] = prov.loc[fx, "value"] + 0.5
    prov.to_csv(d / "live" / "provenance.csv", index=False)
    cty = pd.read_csv(d / "countries.csv", dtype=str, keep_default_na=False)
    new = dict(zip(prov.loc[fx, "country"], prov.loc[fx, "value"]))
    cty["fx3m"] = [f"{new[c]:.4g}" if c in new else v for c, v in zip(cty["country"], cty["fx3m"])]
    cty.to_csv(d / "countries.csv", index=False)


def test_real_data_lists_the_17_yahoo_fx3m_cells(tmp_path):
    d = _copy(tmp_path)
    cells = restricted_source_cells(d)
    assert len(cells) == 17 and set(cells["key"]) == {"fx3m"} and set(cells["table"]) == {"Country Profile"}
    v = cells.set_index("country")["value"]
    assert v["Vietnam"] == pytest.approx(-1.771) and v["Philippines"] == pytest.approx(2.866)
    assert v["China"] == pytest.approx(-1.481) and v["Malaysia"] == pytest.approx(-0.07832)
    assert cells["source"].str.contains("yfinance").all()
    assert cells["evidence"].str.contains("live/vintages/2026-10-23/provenance.csv").all()


def test_empty_after_the_official_pull(tmp_path):
    d = _copy(tmp_path)
    _official_pull(d)
    assert restricted_source_cells(d).empty


def test_a_country_the_official_pull_missed_is_still_listed(tmp_path):
    """provenance.csv no longer names Yahoo for Vietnam, but countries.csv still holds the Yahoo value: the vintage
    and the audit trail tie it to Yahoo."""
    d = _copy(tmp_path)
    _official_pull(d, skip={"Vietnam"})
    cells = restricted_source_cells(d)
    assert list(cells["country"]) == ["Vietnam"]
    assert "live/provenance.csv" not in cells["evidence"].iloc[0].split("; ")


def test_non_commercial_licence_column_is_restricted(tmp_path):
    d = _copy(tmp_path)
    _official_pull(d)
    prov = pd.read_csv(d / "live" / "provenance.csv", dtype={"key": str})
    prov["licence"] = ""
    m = (prov["key"] == "1.3") & (prov["country"] == "Vietnam")
    assert m.sum() == 1
    prov.loc[m, "source"] = "some vendor"
    prov.loc[m, "licence"] = "Vendor terms: Non-Commercial use only"
    prov.to_csv(d / "live" / "provenance.csv", index=False)
    cells = restricted_source_cells(d)
    assert len(cells) == 1 and cells["key"].iloc[0] == "1.3" and cells["reason"].iloc[0].startswith("licence:")


def test_fetch_apply_warns_loudly_and_cli_exit_codes(tmp_path, capsys):
    d = _copy(tmp_path)
    assert feeds._warn_restricted_cells(d) == 17
    err = capsys.readouterr().err
    assert "WARNING (SEC-A-006 M1): 17 applied cell(s)" in err and "econquest fetch --only fx --apply" in err
    assert audit.main(["restricted", "--data", str(d)]) == 1
    assert "17 restricted-source cells" in capsys.readouterr().out
    _official_pull(d)
    assert feeds._warn_restricted_cells(d) == 0 and capsys.readouterr().err == ""
    assert audit.main(["restricted", "--data", str(d)]) == 0
    assert "0 restricted-source cells" in capsys.readouterr().out


def test_unreadable_data_warns_and_returns_none(tmp_path, capsys):
    assert feeds._warn_restricted_cells(tmp_path / "nothing") == 0        # no record names a restricted source
    d = _copy(tmp_path)
    (d / "countries.csv").unlink()                                       # Yahoo records, but no applied values
    assert feeds._warn_restricted_cells(d) is None
    assert "could not check" in capsys.readouterr().err


def test_restricted_check_never_writes(tmp_path):
    d = _copy(tmp_path)
    before = {p: p.read_bytes() for p in d.rglob("*") if p.is_file()}
    restricted_source_cells(d)
    assert {p: p.read_bytes() for p in d.rglob("*") if p.is_file()} == before
