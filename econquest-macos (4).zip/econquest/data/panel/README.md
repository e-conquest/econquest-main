# Sovereign default episodes, 1980-2025, compiled by Claude on 2026-10-23 from memory of the Bank of Canada-Bank of England sovereign default database (CRAG) and Reinhart-Rogoff. Start/end years can be off by one; replace with the CRAG workbook via 'econquest fit-hazard --defaults <xlsx>'. Private creditors (bank loans, bonds) and local-currency bonds only; arrears to official creditors alone are not counted.

## Replacing the panel with CRAG

`sovereign_defaults.csv` above is a memory-compiled list. The official source is the Bank of Canada-Bank of England
Sovereign Default Database (CRAG), 2026 edition (data to 2025), published with Staff Analytical Paper 2026-48:

- page: https://www.bankofcanada.ca/2026/10/staff-analytical-paper-2026-48/
- workbook: https://www.bankofcanada.ca/wp-content/uploads/2026/10/BoC-BoE-Database-2026.xlsx
- same data as CSV (Valet group DEBT_2026): https://www.bankofcanada.ca/valet/observations/group/DEBT_2026/csv
- methodology: Technical Report 124, https://www.bankofcanada.ca/2023/07/technical-report-124/

`econquest/ingestion/default_panel.py` converts it (xlsx, or the Valet CSV) into this file's schema plus two
trailing columns, `source` (label + the input file's sha256) and `source_vintage`. Scope rule kept: a country is in
default in a year when foreign-currency bank loans + foreign-currency bonds + local-currency debt in default is
positive; official creditors (IMF, IBRD, IDA, IADB, Paris Club, China, other official), fiscal/domestic arrears,
other private (supplier) credit and the TOTAL / PRIVATE_CREDITORS aggregates are not counted. A spell is a run of
consecutive such years.

Steps on Sam's Mac (download the workbook first; it is not kept in the repo):

1. Import to a NEW file next to the old one (the old file is not touched). Every economy in CRAG is covered (not
   only the desk), spells ending in or after 1980 are kept with their true start year, and every row carries
   `source` + `source_vintage`:

   ```
   .venv/bin/python -c "from econquest.ingestion.default_panel import import_crag; print(import_crag('$HOME/Downloads/BoC-BoE-Database-2026.xlsx', 'data/panel/sovereign_defaults_crag.csv', 'BoC-BoE Sovereign Default Database 2026 (BoC-BoE-Database-2026.xlsx)', '2026-10', iso_map_csv='data/panel/crag_iso_map.csv'))"
   ```

   Country names resolve through an ISO column if the file has one, else `crag_iso_map.csv` (optional), the repo's
   tables and the built-in `ISO3_NAMES` reference list (World Bank / IMF name variants). If it stops with "country
   names have no ISO3 code", it has written `data/panel/sovereign_defaults_crag_unmapped.csv` (country, iso). Fill
   the iso column, save it as `data/panel/crag_iso_map.csv` and rerun. Historical states (Soviet Union, Yugoslavia,
   Serbia and Montenegro) are deliberately not in the built-in list: which successor (if any) carries their spells
   is Team B's call, recorded in `crag_iso_map.csv`. If it cannot find the table (a new edition renamed sheets or
   columns), pass `sheet=`, `country_col=`, `year_col=` or
   `category_map={'<column>': 'FC_BONDS' | 'FC_BANK_LOANS' | 'LC_DEBT'}`. Note the printed `input_sha256`.

   It also writes `data/panel/sovereign_defaults_crag_universe.csv` (iso, country, first_year, last_year,
   has_spell: every country CRAG covers, including never-defaulted ones) and saves the episode file, the universe
   file and `crag_import.json` (hashes, years, counts) as a read-only panel vintage under `data/panel/vintages/`
   (printed as `panel_vintage`; `save_vintage=False` skips it). Countries in the universe with an empty iso column
   have no spell and no ISO code; add them to `crag_iso_map.csv` if they appear in the history.

2. Review the change before anything is refit:

   ```
   .venv/bin/python -c "from econquest.ingestion.default_panel import compare_panels, comparison_table; r = compare_panels('data/panel/sovereign_defaults.csv', 'data/panel/sovereign_defaults_crag.csv'); print(r['summary']); comparison_table(r).to_csv('data/panel/crag_comparison.csv', index=False)"
   ```

   `crag_comparison.csv` lists every added, removed and changed spell (spells are paired when their years overlap
   or are within one year). Sam and Team B review it. Expect more, shorter spells than the hand list: CRAG records
   small arrears too (`min_amount=` sets a floor, in the workbook's units, if Team B wants one).

3. Only after that review, Team A swaps the file (keep the old one as `sovereign_defaults_memory.csv`) under
   EQ-A-0008 part 2. The refit (`econquest fit-hazard --defaults data/panel/sovereign_defaults_crag.csv`) is Team B's
   and is a Tier-1 model change under `docs/governance/change-control.md`: it needs Sam's approval. Pass the CSV,
   not the xlsx: `fit-hazard --defaults <xlsx>` uses `hazard_panel.load_crag_workbook`, which expects the older wide
   layout (years as columns) and is not known to read the 2026 edition.

4. Coverage check against the predictor history (after the history pull below):

   ```
   .venv/bin/python -c "import json; from econquest.ingestion.default_panel import panel_coverage; print(json.dumps(panel_coverage('data/panel/sovereign_defaults_crag.csv', 'data/panel/weo_history.csv', universe_csv='data/panel/sovereign_defaults_crag_universe.csv'), indent=1))" | tee outputs/panel-coverage-$(date +%Y%m%d).json
   ```

   It reports `n_countries` (history economies, aggregates excluded), `n_ever_defaulted`, `ever_defaulted_share`,
   `history_missing_from_defaults` (these enter the panel as zeros), `zeros_not_covered_by_crag` (zeros that are an
   assumption, because CRAG does not list the country), `defaults_missing_from_history` (spells that drop out) and
   `checks` against HO-20261023-B-A-002 (at least 100 countries, ever-defaulted share well below 55%, every
   episode sourced).

## Predictor history: `weo_history.csv` and `worldbank_history.csv` (EQ-A-0010, EQ-A-0015)

Written by `python -m econquest.ingestion.panel_history --out data/panel` on Sam's Mac (commands in
`docs/runbooks/A-full-panel-fetch.md`). Not yet produced: the cloud sessions cannot reach the IMF or the World Bank,
and no history file in this folder has been generated by that tool so far.

| File | Columns | Source |
|---|---|---|
| `weo_history.csv` | iso, series, period, value, source, vintage | IMF World Economic Outlook database, one block per release. `vintage` = release as `YYYY-MM` (`2019-04`, `2019-10`; autumn 2011 is `2011-09`). Series: `hazard_panel.WEO_CODES` (GGXWDG_NGDP, GGXONLB_NGDP, BCA_NGDPD, NGDP_RPCH, PCPIPCH). `source` names the route (imf-reader, weo package with URL, or a local file with its sha256) |
| `worldbank_history.csv` | iso, series, period, value, source | World Bank API through wbgapi, current database only (DT.DOD.DSTC.IR.ZS, FI.RES.TOTL.MO, PV.EST), 1980 to the current year, every economy, aggregates skipped |

Universe: every economy the sources return; nothing is filtered to the desk countries.

Point in time: `hazard_panel.panel_from_long` uses, for row year t, only WEO releases published by the end of year t,
so the WEO features are point in time (`attrs['point_in_time'] == 'all features'` when only WEO features are used).
The World Bank file has no `vintage` column on purpose: wbgapi serves only the current database (later revisions are
in it), so a panel that uses the World Bank features reports `partial`.

WEO release coverage (documentation reading, 2026-10-23; not tested against the live sites):

| Releases | Route | Confidence |
|---|---|---|
| 2019-04 to 2025-04 | `imf-reader` bulk SDMX archive (`imf_reader.weo.fetch_data(("April", 2019))`) | high: listed in imf-reader 2.2.0 `SDMX_RELEASES` |
| 2021-04, 2023-10 | corrupt in the IMF's SDMX archive (imf-reader `KNOWN_CORRUPT_RELEASES`); taken from the weo package's tab file instead | medium |
| 2025-10 onwards | `imf-reader` through the IMF SDMX 3.0 API (WEO and WEO_YYYY_MON_VINTAGE dataflows); the IMF stopped bulk files after April 2025 | medium: depends on which vintage flows the IMF keeps live |
| 2007-10 to 2018-10 (and fallback to 2025-04) | `weo` package 0.8.4 `weo.download(year, 'Apr'/'Oct')`, imf.org media URLs; its README says "latest confirmed April 2024" | medium: URL scheme is in the package; imf.org now puts some pages behind bot checks |
| 1999 to 2007-04 | no package route. IMF WEO database archive pages exist but their file URLs were not verified. Download by hand and save as `data/panel/staging/weo_cache/weo_<YYYY-MM>.xls`; the tool reads it before trying the network | low |
| before 1999 | not known to exist as a downloadable WEO database edition | low |

Series availability by release is recorded per release in the run manifest (`codes_missing`). General government
debt and primary balance (GGXWDG_NGDP, GGXONLB_NGDP) are believed to be absent from the earliest releases (not
verified); rows without them drop out of the panel.

## Panel vintages (`data/panel/vintages/`)

Append-only copies, like `data/live/vintages/`: `<YYYY-MM-DDTHHMMSSZ>-<hash8>/` with files mode 0444 and the folder
0555, one row each in `vintages/index.csv` (vintage_id, created_utc, hash, n_files, label, files). A successful history
pull stores `weo_history.csv`, `worldbank_history.csv` and its `manifest.json`; a CRAG import stores the episode file,
its universe file and `crag_import.json`. Identical content is not stored twice. Never edit or delete a vintage folder.
