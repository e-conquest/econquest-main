# Proposed sovereign universe (EQ-A-0025, epic A6): draft for Sam's approval

Status: **proposal, not approved**. `data/countries.csv` and `data/indicators.csv` are unchanged. Written
2026-10-23 by AGENT-06 (Team A) without network access. Companion file: `universe_proposal.csv` (88 rows).

## Read this first: what is reliable here and what is not

- **Reliable:** ISO 3166 alpha-3 and alpha-2 codes and ISO 4217 currency codes. For the 18 desk countries:
  name, ISO codes, currency, region, ETF and BIS code are copied from `data/countries.csv`, and the
  rating bucket is taken from the desk's own `rating` column.
- **From memory, needs checking:** everything else. Each of these rows says
  `analyst estimate (Claude, Oct 2026 knowledge), verify` in `basis`. That covers the World Bank income
  group, EMBI membership, frontier index tag, rating bucket, IMF AREAER FX regime, Yahoo and ETF tickers and
  BIS coverage. Ratings, FX regimes and index membership change often, so any of them may be out of date.
  Where I was not confident I wrote `unknown`, not a guess. That gives 53 `frontier_index`, 19 `fx_regime`,
  9 `embi_member` and 3 `income_group` values of `unknown`.

## Selection criteria

1. **All 18 current desk countries** (`tier = desk_current`). These are required, and the validator fails
   without them.
2. **Sovereigns with traded hard-currency external debt** of the kind in the JPMorgan EMBI Global Diversified:
   the main EM issuers in every region (`tier = EM`).
3. **Frontier issuers**: small or distressed Eurobond issuers of the NEXGEM type, plus frontier sovereigns
   that matter for the desk's Africa, Caucasus, Central Asia and Caribbean coverage (`tier = frontier`).
4. **A few DM anchors for calibration** (`tier = DM_anchor`): US, Germany, UK, France, Italy, Canada and
   Australia. Japan is already on the desk and also serves as an anchor. They give the scorecards and the
   hazard model a low-risk reference point, and France and Italy add high-debt DM cases.
5. **Target size: 70 to 90 rows** (A6 acceptance: `countries.csv` has 70 or more). Proposed: 88.
6. **Left out on purpose, for Sam to decide:** Russia and Belarus (sanctioned, out of the indices), Venezuela-style
   cases beyond the desk's own, Bangladesh, Tanzania and Uganda (little or no hard-currency Eurobond debt),
   euro-area periphery other than Italy, and China's offshore credit. Any of these can be added as a row.

## Column definitions

| Column | Meaning / allowed values |
|---|---|
| iso3, iso2 | ISO 3166-1. iso2 `NA` (Namibia) is a real code: read the CSV with `keep_default_na=False` |
| name | Display name. For desk countries it must equal the `country` column in countries.csv, because it is the column header in indicators.csv |
| currency | ISO 4217. Not in the original column list, but feeds.py builds the Yahoo ticker from `currency` |
| region | Asia, LatAm, Africa, Europe, Middle East, North America. Europe includes the CIS, Caucasus and Central Asia (CEEMEA convention). North Africa is in Africa. **Sam decides** (the copula gives each region its own factor; see Risks) |
| income_group | World Bank FY26 classification: high, upper-middle, lower-middle, low, unknown. Check against FY27 (published July 2026) |
| tier | desk_current, EM, frontier, DM_anchor |
| embi_member | Y, N or unknown: is the country in EMBI GD (quasi-sovereigns count) |
| frontier_index | NEXGEM / MSCI FM tag, none (clearly not frontier), or unknown |
| rating_bucket | IG (BBB- or better), HY (BB+ to B-), distressed (CCC+ or lower, SD or default), NR. Uses the middle of the three agencies' FC ratings, or the lower of two. Gives buckets, **not notches** |
| fx_regime | IMF AREAER broad class: hard peg, soft peg, floating, free floating, other, unknown |
| yahoo_fx | `CCY=X` (units of CCY per USD); blank for USD and dollarized economies |
| etf | US-listed single-country ETF, blank if none or not known |
| bis_iso2 | Blank means BIS series are not expected. Set for desk countries (as today) and for new countries thought to be in the BIS broad EER basket |
| weo_available | Y when the country is in the IMF WEO database |
| notes, basis | Notes and where each value came from |

## Counts

| region | DM_anchor | EM | desk_current | frontier | total |
|---|---|---|---|---|---|
| Africa | 0 | 3 | 4 | 13 | 20 |
| Asia | 1 | 2 | 9 | 4 | 16 |
| Europe | 4 | 7 | 0 | 8 | 19 |
| LatAm | 0 | 10 | 5 | 6 | 21 |
| Middle East | 0 | 7 | 0 | 3 | 10 |
| North America | 2 | 0 | 0 | 0 | 2 |
| **total** | 7 | 29 | 18 | 34 | **88** |

Rating buckets: 32 IG, 41 HY, 15 distressed.

## Coverage with today's feeds (`python -m econquest.ingestion.universe coverage`)

The feeds fill 18 of the 83 Inputs indicators: 8 from WEO, 7 from the World Bank and 3 from BIS. In the
2026-10-23 pull, three of the World Bank ids came back empty for all 18 desk countries: 2.9 (IDS short-term
debt), 3.4 and 3.5 (WGI). That leaves 15 that work. The other 65 ids are either `manual` (36) or
`planned_api` (29: the rulebook names an API but no feed has been built).

- **Expected live share of Inputs cells: 14.5% overall** (11 to 15 of 83 per country). Even with every
  current mapping working (BIS for every country with a code, the dead ids fixed), the ceiling is 19.1%.
- **No country reaches the 60% A6 target.** 60% means 50 live cells per country. The full feed set, if it
  worked for everyone, would give 18. Building all 29 `planned_api` feeds would give 47 of 83 (57%), still
  short. Reaching 60% needs most of the planned APIs plus some ids now marked manual (for example AREAER
  2.5, IMF MONA 2.6, FATF 2.7, IFES elections 4.5), or a different definition of the target, such as
  counting only feed-eligible cells. **Sam decides.**
- Yahoo serves only Country Profile fields (fx3m, equity_vol). Its tickers are keyed by currency, so when
  several countries share one (EUR=X, XOF=X, XAF=X) only one of them gets FX rows. This needs a feeds.py
  fix before the expansion (see the runbook).

## What Sam must decide

1. Approve, remove or add rows. Check every tier and the 18 desk names.
2. The region vocabulary and where to put Central Asia, North Africa, Israel and Australia.
3. What the 60% target means, or which planned and manual sources to fund (see above).
4. Whether rating notches and spreads (the engine needs both; this file gives only buckets) come from a
   licensed source (A7) or are entered by hand for about 70 new countries.
5. Which `unknown` values to fill now and which to leave for the first live pull.
