#!/usr/bin/env bash
# Double-clickable macOS launcher: runs install.sh in Terminal and keeps the window open.
cd "$(dirname "$0")"
bash ./install.sh
status=$?
echo
if [[ $status -eq 0 ]]; then echo "Finished. You can close this window."; else echo "The installer stopped with an error (see above)."; fi
read -r -p "Press Return to close." _
