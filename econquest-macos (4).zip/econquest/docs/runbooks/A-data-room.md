# Runbook: validator data room (data side)

Ticket EQ-A-0041 (PI-5 independent validation). Owner: Team A, AGENT-06. Operator: Sam on the Mac, or an agent
working on the project copy. Code: `econquest/ingestion/dataroom.py` and the standalone verifier
`econquest/ingestion/dataroom_verify.py`. Tests: `tests/test_dataroom.py`.

## Purpose

Give an external validator one folder per as-of date with every data record econquest held at that date, so they
can reproduce and verify each data input without econquest installed: vintages, snapshots, provenance, audit trail,
review ledger and attestations, change approvals, event feed exports and frozen replay inputs. Each file has a
sha256 in `MANIFEST.json`, a top hash covers the manifest, and `verify.py` (standard library only) checks it all.

The Team C evidence bundle (`econquest evidence --as-of`, EQ-C-0060) includes this room's `MANIFEST.json`; see
handoff HO-20261024-A-C-001 for the contract.

## Build

```bash
cd ~/econquest
python -m econquest.ingestion.dataroom build --as-of 2026-10-23        # -> outputs/dataroom/2026-10-23/
python -m econquest.ingestion.dataroom verify outputs/dataroom/2026-10-23
```

- Default location: `<outputs>/dataroom/<as_of>/`, where `econquest evidence --as-of` (EQ-C-0060) picks it up.
  `<outputs>` is `$ECONQUEST_HOME/outputs`, else the checkout's `outputs/` (as the rest of econquest); `--outputs DIR`
  or `--out DIR` override it. `--data` defaults to `<home>/data`. The manifest is always `MANIFEST.json` at the root.

- `--as-of YYYY-MM-DD` means the end of that UTC day; an ISO date-time (`2026-10-23T18:20:00Z`) cuts at that instant.
- `--out` must not exist or must be empty, and must not be inside `data/`. The room is built in a temporary sibling
  folder and renamed into place, so a failed build leaves nothing behind. Files in the room are read-only (0444).
- Nothing in `data/` is written or touched.
- `--json` prints a summary (files, bytes, manifest_sha256, counts per kind, excluded, anchor results).
- `--include-current` also copies undated working copies (indicators.csv, countries.csv, market_history, panel CSVs,
  hand-entered CSVs, other teams' config). It is refused when any dated record in `data/` is after the cutoff, since
  the working copies may then already hold later data. Use it only for an as-of date at or after the latest record.

Python: `build_data_room(data_dir, as_of, out_dir, *, include_current=False, now=None, include_restricted=False,
limitations=True) -> dict` (the manifest),
`default_room_dir(as_of, outputs_dir=None) -> Path` and
`verify_data_room(path) -> dict` (the report; `ok` is the verdict).

## What goes in, and the as-of rule for each

The cutoff is inclusive. A legacy date-only id (the `2026-10-23/` vintage) counts as the end of that UTC day.

| Room path | Source | Rule |
|---|---|---|
| `data/live/vintages/<id>/`, `index.csv` | live pulls | folder id time <= cutoff; index rows of selected vintages with retrieved_utc <= cutoff |
| `data/panel/vintages/<id>/`, `index.csv` | panel vintages | folder id time <= cutoff; rows by created_utc |
| `data/live/market/snapshots/<id>/`, `index.csv` | market snapshots | snapshot id time (save time) <= cutoff; rows by saved_utc |
| `data/market/cds_snapshots.csv` | gated CDS export | rows with snapshot_id time and as_of <= cutoff |
| `data/live/market/manual_quotes.csv` | hand-typed quotes | rows with entered_utc <= cutoff |
| `data/live/events/<source>/vintages/<id>/`, `index.csv` | event vintages | folder id time <= cutoff |
| `data/live/events/exports/<id>/`, `index.csv` | event export archives (events_long, events_weekly as consumed) | export id time <= cutoff |
| `data/live/snapshots/<vintage>-inputs/`, `index.csv` | `replay.freeze_inputs` (TEAM_A_RUN_INPUTS) | index row frozen_utc <= cutoff and its vintage selected |
| `data/live/snapshots/<ts>-pre-apply/` | pre-apply backups, forced_cells.csv | folder id time <= cutoff |
| `data/live/review_ledger.csv` | review ledger incl. attestations | rows with ts_utc <= cutoff |
| `derived/four_eyes.csv` | from the kept ledger rows | four_eyes = yes / self-approved / no approver, attestation yes/no |
| `data/approvals/log.jsonl`, `proposals/` | change approvals (Team C store, read only) | rows by ts_utc (a prefix of the hash chain); proposals by change-id time |
| `data/audit_trail.csv` | per-cell provenance | rows with retrieved > cutoff dropped; undated seed / hand-entered rows kept |
| `data/live/*.csv`, `*.json` | current pull (transform_log, unserved, feed_failures, provenance, review, raw_*) | whole files when `live/feeds.json` retrieved <= cutoff |

Never exported: `data/vendor_licences.json`, credential-named files (`.env`, `*.pem`, `*.key`, `*secret*`,
`*token*`, `*credential*`, `*password*`, `id_rsa` ...), JSON files with credential keys (`password`, `app_key`,
`api_key`, `token`, `secret` ...) at any depth, files whose text matches a credential pattern (private key blocks,
AWS / GitHub / Slack / `sk-` keys, `password=...`), hidden, lock and temp files, symlinks. Licence tags inside the
data (licence columns, manifest `licences`) are kept. Everything left out is listed with its reason under
`build.excluded` in `MANIFEST.json`.

**Licence-restricted files are withheld by default (EQ-A-0044).** Sam replaced Yahoo on 2026-10-23 (EQ-A-0040),
and Yahoo's terms (personal, non-commercial use) do not allow passing its data to an external validator. So
`raw_yahoo.csv` is left out wherever it is, including the frozen `2026-10-23/` vintage. Any CSV whose licence
column says non-commercial or personal (`market.gate.DESK_BARRED_LICENCE_TERMS`) is left out too. `index.csv`
files are exempt, because they only list licences. Each such file is listed under `build.excluded` with its reason,
and under the hashed `withheld` list with its path, size and sha256, so verify.py does not report it missing.
`--include-restricted` (`include_restricted=True`) keeps these files. Use it only when Sam confirms the licence
allows it. Any file named `*yahoo*` (any case, e.g. `RAW_YAHOO.csv`) counts as Yahoo data (SEC-A-006 L4).

**Yahoo-derived values are blanked in the room copies (SEC-A-006 M2, EQ-A-0045).** Values computed from Yahoo
data fall under the same terms as the prices. Without `--include-restricted`, the copies (never `data/`) are
changed as follows, in the current pull, the vintages and the snapshots:
- a row whose own `source` is Yahoo / yfinance, or whose licence column says non-commercial or personal, keeps its
  labels but has its value columns blanked (`value`, `live`, `live_value`, `change`, `gate_reason`, `reason` ...):
  `provenance.csv`, `audit_trail.csv`, market quotes. A CSV with such rows but none of those columns is withheld;
- `review.csv`, `diff_vs_seed.csv` and the ledger (no source column) have those columns blanked on rows whose value
  is one a provenance record or the audit trail attributes to Yahoo for that cell;
- `live_profile.csv`, `live_inputs.csv`, `countries.csv` and `indicators.csv` have each such cell blanked.
Each changed file is in the hashed `redactions` list with `restricted_rows`, `restricted_cells` and its original
sha256 and size, so a vintage holding one is reported `altered`, as for a withheld file. On the 2026-10-23 data:
8 files, the 27 Yahoo provenance rows (17 `fx3m`, 10 `equity_vol`) in the pull and the vintage, and the 17 audit
trail rows; none of the 27 Yahoo values is left in the room.

**Files that cannot be scanned are withheld (SEC-A-006 L4).** Secrets and e-mail addresses are looked for in UTF-8
text and in UTF-16/32 text with a byte-order mark. A file that is neither (binary, or BOM-less UTF-16) is withheld
with the reason `unscannable: ...` rather than exported unscanned. The secret patterns also cover `pass` / `pw` /
`auth` keys, `Bearer <token>` and JWTs, and `%40`-encoded e-mail addresses are redacted too.

**E-mail addresses are redacted at source (EQ-A-0044, SEC-C-008 R6).** In every text file copied into the
room (vintage files, the ledger and `derived/four_eyes.csv` included), each address is replaced by
`[redacted-email]` before the file is hashed. The pattern is Team C's evidence `EMAIL_RE`, so the bundle finds
nothing left to change. The hashed `redactions` list gives each file with its replacement count and the original
sha256 and size. `data/` is never changed.

**What this does to the vintage hash.** A live or panel vintage's content hash covers the original bytes of every
file in its folder, so a vintage with a withheld or redacted file cannot be re-hashed from the room. At build time,
the builder verifies the source folder against `vintages/index.csv` and records the result in `altered_anchors`.
verify.py then reports the folder as `altered` (a warning) when the room's index row matches that hash and the
present plus withheld files add up to its `n_files`, and as `failed` otherwise. The frozen `2026-10-23/` vintage has
no index row in the project copy, so it stays `unanchored`, and the note says raw_yahoo.csv is withheld. Its source
content hash is in `altered_anchors`, so it can be compared with the Mac's index. Anchors that compare a sha256
(market and event manifests and index rows, replay manifests) use the recorded original sha256 and still check
fully.

**Limitations register in the room.** `limitations/data-limitations.md` is generated for the as-of by
`econquest.ingestion.limitations.build_register` from the newest pull at or before the cutoff. Its two tables are
computed; its narrative is hand-written (EQ-A-0042) and may postdate the cutoff. The manifest's `limitations` entry
says whether it was generated and from which pull, or why not. `limitations=False` skips it.

## MANIFEST.json

`schema` (`econquest.dataroom/1`), `as_of`, `cutoff_utc`, `code` (`version`, `code_hash`), `options`
(`include_current`, `include_restricted`, `limitations`), `rules` (kind -> rule), `counts` (kind -> files, bytes), `totals`, `files` (one entry per file:
`path`, `size`, `sha256`, `source` (path relative to the data folder, or the package file for verify.py, null for
README.md), `kind`, `as_of_rule`, and `filter.rows_kept` for row-filtered files), `checks` (the integrity anchors run
at build time), `withheld`, `redactions`, `altered_anchors` and `limitations` (EQ-A-0044, above), `content_sha256` (SHA-256 of `path=sha256;` over all files in path order), `manifest_sha256`
(SHA-256 of the canonical JSON, sort_keys and `,` `:` separators, ASCII, of the manifest without `manifest_sha256`
and `build`), and `build` (built_utc, source_data_dir as the folder's basename only, python, excluded, filtered row counts;
outside both hashes).

Determinism: the same data and code give the same `manifest_sha256`, whatever the build time. A room rebuilt later for
the same as-of date keeps its hash while the append-only stores are unchanged, because only records dated at or
before the cutoff are selected. The current-pull files and `audit_trail.csv` are working copies, so a later pull or
run can change them (the README in the room says so).

## Verify (validator)

```bash
cd <room>
python -I verify.py            # exit 0 and "RESULT: VERIFIED", or exit 1 with the problems
python -I verify.py --json
```

It reports missing, extra and changed files and unsafe manifest paths, recomputes both hashes and re-runs the
integrity anchors: live and panel vintage content hash against `index.csv`, market snapshot, event vintage and event
export manifests against their `index.csv`, frozen replay inputs against `snapshots/index.csv`, and the
approvals log hash chain from genesis. `unanchored` (a folder with no index row, e.g. the legacy `2026-10-23/`
vintage made before `index.csv` existed) and `altered` (a folder with a withheld or redacted file, checked against
what the build verified) are warnings; `failed` fails the room. A live vintage whose `index.csv` rows disagree fails
(SEC-A-004 L1). On a hostile room (SEC-A-006 L2/L3) verify.py never follows a symlink (any link in the room is
`unsafe`), refuses a MANIFEST.json over 64 MB, checks the types in the manifest and the withheld / redaction paths,
and reports a malformed or deeply nested manifest as FAILED, never with a traceback.

## Hand it over

1. Build the room for the agreed as-of date and run `verify` (expect VERIFIED).
2. Send the room (zip it as it is) and, separately, its `manifest_sha256` (email or the evidence bundle), so the
   validator can confirm the room they received is the one exported.
3. Point the validator at `README.md` and `limitations/data-limitations.md` in the room.
4. Licences: Yahoo data and files licensed non-commercial or personal are withheld by default. Other vendor data
   goes in under the licence tag recorded with it. Before sending, check that each licence lets you pass that data to
   the validator. Escalate to Sam: an agent never decides a licence question.

## Known gaps (2026-10-24)

- The project copy of `data/` has no frozen replay snapshot (`data/live/snapshots/` does not exist) and no
  `data/live/vintages/index.csv`, so a room today holds the legacy `2026-10-23/` vintage (unanchored), the current pull,
  the audit trail and the approvals log, but not indicators.csv / countries.csv as of the date. The first
  `fetch --apply` on the Mac after EQ-A-0007 freezes them; until then use `--include-current` for an as-of date at or
  after the latest record.
- No review ledger, market snapshot, event vintage or panel vintage exists in the project copy yet; the rules are
  covered by the tests with synthetic stores.
