# Runbook: licensed vendor market data (Bloomberg BLPAPI, LSEG Data Library)

**Status: Roadmap: paid feature, not enabled.**

Ticket EQ-A-0033. Owner: Team A, AGENT-06. Date: 2026-10-23. Decision: Sam, 2026-10-23 23:19Z ("build the
necessary framework and architecture for the bloomberg/LSEG but keep that as a roadmap integrated feature (paid)").
Code: `econquest/ingestion/market/vendors/` (`base.py`, `bloomberg.py`, `lseg.py`, `pipeline.py`). Tests:
`tests/test_market_vendors.py`. Related: `docs/runbooks/A-market-data.md` (schema, store, gate, CDS export).

> **Untested against a terminal.** The Bloomberg and LSEG request and response handling is written from vendor
> docs, untested against a terminal. The tests run only against in-memory fakes built from the same reading of the
> docs, so they show the framework is consistent, not that the wire format is right. The first run on a licensed
> machine is the dry-run in section 5, with someone watching.

Nothing in this framework runs today. An adapter refuses with `VendorNotLicensed` unless all three of these hold:

1. the vendor package imports (`blpapi` or `lseg.data`);
2. a licence entitlement is configured for that vendor;
3. today (UTC) is on or before the entitlement's expiry.

When an adapter refuses, it sends no request, and econquest never substitutes free data. The CSV export path
(`A-market-data.md` section 3) and the hand-typed path (section 2) keep working as before.

## 1. Prerequisites (bought by Sam, not by an agent)

| Vendor | You need | Session used by econquest |
|---|---|---|
| Bloomberg | A Bloomberg Terminal (Anywhere/Professional) logged in on the same machine, **or** a B-PIPE contract with an application registered by Bloomberg | Desktop API at `localhost:8194`, or B-PIPE at `ECONQUEST_BPIPE_HOST:ECONQUEST_BPIPE_PORT` with application `ECONQUEST_BPIPE_APP_NAME` |
| LSEG | LSEG Workspace signed in on the same machine, **or** an LSEG Data Platform (RDP) account | `lseg.data` desktop session (default) or platform session (`ECONQUEST_LSEG_SESSION=platform`) |

Either way you also need:

- **The package.**
  - Bloomberg: `pip install blpapi --index-url=https://blpapi.bloomberg.com/repository/releases/python/simple/`. blpapi installs from Bloomberg's own index, not PyPI; check that URL against Bloomberg's current API library page before using it.
  - LSEG: `pip install lseg-data`.
  - Or install through the extras: `pip install 'econquest[bloomberg]'` (blpapi still needs Bloomberg's index, as above) or `pip install 'econquest[lseg]'`.
- **The vendor's data entitlement for every field you pull.** CDS pricing (CBIN/CMAN/CBGN on Bloomberg, LSEG CDS
  RICs) is often a separately priced entitlement.
- **Credentials, kept in the environment or the OS keychain only.** Never put them on the command line, in a file, or in `vendor_licences.json`.
  - Bloomberg Desktop API: none. The Terminal login is the entitlement.
  - B-PIPE: the application name in `ECONQUEST_BPIPE_APP_NAME`, plus whatever Bloomberg's onboarding sets up on the host.
  - LSEG: app key in `ECONQUEST_LSEG_APP_KEY`. For the platform session, also `ECONQUEST_LSEG_USERNAME` and `ECONQUEST_LSEG_PASSWORD`. Each one is read from the environment first and otherwise from the macOS keychain through the optional `keyring` package (service `econquest-lseg`, account = the variable name):

    ```bash
    pip install keyring
    python -c "import keyring, getpass; keyring.set_password('econquest-lseg', 'ECONQUEST_LSEG_APP_KEY', getpass.getpass('LSEG app key: '))"
    ```

## 2. Configure the licence entitlement

The entitlement is a contract record. It says which licence covers the data and what you may do with it. It is
not a credential. Configure it in one of two ways (the environment wins when both are set):

**Environment** (one variable per vendor):

```bash
export ECONQUEST_VENDOR_LICENCE_BLOOMBERG='licence_id=<contract or account number>;holder=<legal entity / desk>;scope=desk-internal;expiry=YYYY-MM-DD'
export ECONQUEST_VENDOR_LICENCE_LSEG='licence_id=<...>;holder=<...>;scope=desk-internal;expiry=YYYY-MM-DD'
```

**File** `data/vendor_licences.json`:

```json
{
  "bloomberg": {"licence_id": "<contract or account number>", "holder": "<legal entity / desk>",
                "scope": "desk-internal", "expiry": "YYYY-MM-DD"},
  "lseg":      {"licence_id": "<...>", "holder": "<...>", "scope": "desk-internal", "expiry": "YYYY-MM-DD"}
}
```

Rules enforced by `base.parse_entitlement`:

- `licence_id`: 1 to 64 characters, letters, digits and `. _ / : -`.
- `scope`: `desk-internal` or `redistribution`.
- `expiry`: the last valid day, `YYYY-MM-DD`.
- An entry with a key that looks like a credential (`password`, `app_key`, `secret`, `token`, ...) is refused, at
  any depth and anywhere in `vendor_licences.json`, including sibling keys outside the vendor entries (SEC-A-005 L3).
- Keys other than `licence_id` (or `id`), `holder`, `scope` and `expiry` are refused.
- A `licence_id` that equals or contains a credential the adapter reads (LSEG app key, user name or password;
  B-PIPE application name) is refused, and so is one with 24 or more letters and digits in a row: that looks like a
  pasted key (SEC-A-005 L2). The licence id is written into every row, so it must be a contract reference.

Every row pulled carries `licence = "<vendor>:<licence_id> (<scope>)"`, for example
`bloomberg:<licence_id> (desk-internal)`. The snapshot manifest's provenance records the licence id, holder,
scope, expiry and where the entitlement came from. It never records a credential.

On the expiry day the adapter still works. From the next day it refuses with "licence ... expired on ...". Renew
the contract, then update the expiry. Do not move the date forward without a renewed contract.

Check the state without opening a session:

```python
from econquest.ingestion.market.vendors import vendor_status
print(vendor_status("data").to_string())     # vendor, package_ok, licence (ok / expired / not configured), usable, problems
```

Or from the command line: `econquest vendor status [--data DIR]`.

## 3. Verify the ticker map

Adapters resolve identifiers through the same ticker map as the CSV importers,
`data/live/market/ticker_map.csv`. It is created from `econquest/ingestion/market/ticker_map_template.csv` by
`importers.ensure_ticker_map("data")`.

- Only rows whose `source` is the vendor slug (`bloomberg` or `lseg`) are used.
- A ticker with no row, or with a row whose `status` is not `verified`, is refused before any session opens. Every
  template row ships as `verify` with the note "TEMPLATE GUESS". **None of the template tickers or RICs has been
  checked.**

To verify a row:

1. On the licensed terminal, look the identifier up: Bloomberg `<ticker> <Corp> DES`, or the RIC's quote page in
   Workspace.
2. Confirm that the reference entity, currency, tenor, seniority and documentation clause match the row's `iso`,
   `currency`, `tenor_y` and `doc_clause`.
3. Confirm the field and its unit: spread in bp, upfront in percent, and points scale for FX (`scale`).
4. Set `vendor_field`:
   - Bloomberg rows carry `PX_LAST`. Change it if the desk uses a different field.
   - The LSEG template rows leave it blank, and the adapter does not assume a default. Fill it with the field you
     checked, or pass `fields=` on each call.
5. Set `status` to `verified` and write in `note` who checked the row and when.

## 4. What lands where

| Step | Code | Output |
|---|---|---|
| Pull | `adapter.snapshot(...)` / `adapter.history(...)` | Rows in memory only, validated `MARKET_COLUMNS` |
| Save | `store.save_market_snapshot` (through `pipeline.pull_to_store`) | `data/live/market/snapshots/<ts>-<hash8>/quotes.csv` + `manifest.json` (provenance: adapter, licence id, scope, expiry, request, vendor errors, "untested" marker), one row in `snapshots/index.csv` |
| Gate | `cds_export.market_gate_review` -> `gate.market_gate` | Review rows for this vendor's series in the result (`res.review`); nothing is written |
| Export | `cds_export.export_gated_cds_snapshots(data_dir, [snapshot])` | Only the CDS rows that pass the gate are appended to `data/market/cds_snapshots.csv`. Held rows are listed in `res.cds_export.dropped` |

Adapters never write consumer files (`cds_quotes.csv`, `cds_snapshots.csv`, the workbook) directly. Reads stay
point-in-time (`latest_market(asof=D)`).

- `snapshot(as_of=None)` stamps `asof` with the UTC date of the pull, because the value is the vendor's current
  value.
- For a dated close, use `snapshot(as_of=D)` (a one-day history request) or `history(start, end)`.

## 5. Dry run (first use on a licensed machine)

```python
from econquest.ingestion.market.vendors import get_adapter
from econquest.ingestion.market.vendors.pipeline import pull_to_store

a = get_adapter("bloomberg", data_dir="data")          # or "lseg"
print(a.licence_state().row())                         # must say usable=True
print(a.plan(["<one verified ticker>"]))               # ticker-map resolution only: no session
res = pull_to_store(a, "data", ["<one verified ticker>"], as_of="<last business day>", dry_run=True)
print(res.summary()); print(res.rows.to_string()); print(res.review.to_string()); print(res.vendor_errors)
```

A dry run opens the session and pulls, then gates in memory. It saves nothing.

The same steps from the command line (keep `a.plan()` in Python for the ticker check):

```
econquest vendor test <vendor> --ticker T [--ticker T2 ...] --as-of D          # dry run; no --field
econquest vendor pull <vendor> --ticker T [--field F] [--as-of D | --start D --end D] [--no-export]
```

Both exit 2 on any refusal (licence, unverified ticker, vendor error). `pull` is recorded in the action log. The CLI
prints `res.summary()` but not the `vendor_errors` list; use the Python call above to see those. The GUI does not
offer vendor pulls.

Compare every value with the terminal screen (`HP` on Bloomberg, the quote page in Workspace) for that date.

- If a value, date or unit differs, stop. Record what the vendor actually returned and open a defect on EQ-A-0033.
  The parsers (`bloomberg.parse_reference` / `parse_historical`, `lseg.parse_get_data` / `parse_history`) were
  written from docs, so a mismatch there is expected and is no reason to bypass the gate.
- If they match, run the same call with `dry_run=False`, then read `res.summary()`.

## 6. Cost and licence-scope warnings

- **Cost.**
  - Terminal, B-PIPE, Workspace and RDP are paid per user or per application, often with per-field or per-security charges. CDS pricing is frequently an add-on.
  - Large history pulls (`history` over many tickers and years) can count against daily data limits (Bloomberg Desktop API) or be billed.
  - Pull only the verified tickers you need.
- **Desk-internal is the default.**
  - A Terminal or Workspace licence normally covers display and internal use by the licensed user. It does not cover passing data to other people.
  - Use `scope=desk-internal` unless a contract says otherwise.
- **Redistribution needs a separate licence.**
  - Sending vendor values, or anything derived from them, to clients or outside the desk needs a separate redistribution or enterprise licence: B-PIPE with redistribution rights, or the LSEG equivalent. This covers the Risk Desk Google Sheet if it is shared outside the licence holder, PDFs, and the API.
  - Set `scope=redistribution` only when that contract exists, and record its id.
  - The licence tag on each row is there so a publish step can refuse desk-internal rows. That check is not built yet: until it is, keep vendor rows out of client deliverables by hand.
- **Desktop API is single-user.** It runs under the logged-in Terminal user's entitlement. It is not a server feed
  and must not be shared over the network.
- **Licence decisions belong to Sam.** Configuring an entitlement, choosing its scope or extending an expiry is a
  licence decision (CLAUDE.md rule 5). Agents never set these values themselves.

## 7. Known gaps

- The vendor wire formats are untested against a terminal (see the warning at the top).
- `blpapi` responses are read with `Message.toPy()`. The minimum blpapi version that provides it has not been confirmed.
- The B-PIPE identity is set with `AuthOptions.createWithApp` and `setSessionIdentityOptions`. This is unconfirmed for this desk's B-PIPE setup.
- LSEG `get_data` may return TR.* fields under their display titles. In that case, map the field by its title.
- Library errors are reported as the exception type plus an allow-listed HTTP status only, never their message
  text (SEC-A-005 L1). To debug a failing session, read the vendor library's own log on the licensed machine.
- After `connect()` an adapter keeps no reference to the environment or the credentials (SEC-A-005 I1). An adapter
  connects once: after `close()`, create a new one with `get_adapter()`.
- There is no scope check at publish yet: keep desk-internal vendor rows out of client deliverables by hand.
