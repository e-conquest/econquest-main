# Runbook: daily forecast record (`econquest record`), weekdays 6:20pm New York

Ticket EQ-A-0009. Owner: Team A, AGENT-06. Operator: Sam (or the scheduled job on the Mac). Written
2026-10-23 from `econquest/cli.py` (`cmd_record`, `cmd_prices`) and `econquest/validation/record.py`.

## Purpose

Append one row per trading day to `data/forecast_record.csv`. Each row holds the book's realised loss for
the day, the one-day VaR/ES forecast made the previous day, the GARCH-DCC forecast for the next day, the
12-month MC VaR/ES and regime, and the code and data hashes. After 250 rows the Basel traffic-light test
means something. A missed day cannot be recorded later as a true forecast.

## When

Weekdays at 18:20 America/New_York, after Google Finance has the day's closes in the Market History tab.

## Prerequisites

- econquest at `/Users/smc/econquest`, with `data/market_history/prices.csv` present.
- Read access to the workbook (spreadsheet `1w4OLCkv4EvDFgaO6MBOipAuY2fjAlCQJ-OjtmHJshQY`), needed to
  export the Market History tab. A Sheets OAuth token goes in the Keychain (service `econquest-sheets`) or in
  `$ECONQUEST_SHEETS_TOKEN`. Never use `--token`. See `A-publish.md` for token handling.
- Know how `record` handles prices: it marks the book against the **last complete date in `prices.csv`**.
  If prices were not refreshed, it re-records the previous day.

## Steps

```bash
cd ~/econquest
TOKEN="${ECONQUEST_SHEETS_TOKEN:-$(security find-generic-password -s econquest-sheets -w)}"
# 1. Export the Market History tab (Sheets API values.get, range 'Market History'!A2:BF)
curl -sf -H "Authorization: Bearer $TOKEN" \
  "https://sheets.googleapis.com/v4/spreadsheets/1w4OLCkv4EvDFgaO6MBOipAuY2fjAlCQJ-OjtmHJshQY/values/%27Market%20History%27%21A2%3ABF" \
  -o outputs/market_history.json
# 2. Merge into prices.csv (point in time: stored prices are never rewritten)
econquest prices --sheet-json outputs/market_history.json
# 3. Record (with a token present it also writes the Forecast Record tab)
econquest record 2>&1 | tee -a outputs/record.log
```

Add `--no-mc` to step 3 to skip the 12-month Monte Carlo when time is short. The row then has no
`var99_12m`, `es99_12m` or regime.

**Scheduling.** Use `econquest schedule` (EQ-C-0022), not a hand-made plist. It writes launchd jobs that run
the three steps above through the job wrapper (start, end and exit code are logged, and the token goes to curl
on stdin, never into the plist):

```bash
econquest schedule show                      # what would be installed: record weekdays 18:20 New York, plus
                                             # morning 07:00, monitor Mon 07:45, backup 23:30, health every 15 min
econquest schedule install --load            # writes ~/Library/LaunchAgents/com.econquest.*.plist and loads them;
                                             # an old com.econquest.record.plist is backed up first
econquest schedule install --job record --load --record-time 18:20   # only the record job
econquest schedule uninstall --load          # remove the jobs
```

Times are New York (`--tz America/New_York` is the default) and are converted to the Mac's clock when the
plists are written, so rerun `econquest schedule install --load` after a DST change if the Mac is not on New
York time. The Mac must be awake: `pmset repeat wakeorpoweron MTWRF 18:15:00`.

## Verification

- Step 2 prints `.../prices.csv: {'series': ..., 'dates': ..., 'first': ..., 'last': '<today>', 'new_dates': 1}`.
  If `last` is not today, Google Finance has not filled the day yet.
- Step 3 prints `[record] <date>: loss ... on N positions (prev <date>)`. `<date>` must be **today**
  (or the last trading day if today was a holiday), and N should match the markable positions (13 on the
  2026-10-23 book).
- `Record: R rows`. R went up by 1, or stayed level if this was a rerun on the same day.
- `tail -1 data/forecast_record.csv` has today's date, a non-empty `var` (yesterday's forecast) and
  `var_next`.

## Failure handling

| Symptom | Action |
|---|---|
| curl fails (401) or no Sheets access | Token expired or missing. Refresh the token and rerun steps 1-3 before midnight New York. If you cannot get access today, run `econquest record` anyway only if `prices.csv` already holds today (for example from a manual export); otherwise skip and note the gap |
| `[record]` date is yesterday's | Prices were stale. Fix step 1 and rerun. Reruns are safe: `append_record` replaces the row for that date |
| `No price history: ...` | `data/market_history/prices.csv` is missing. Restore it (`A-restore.md`) |
| Day missed entirely | `econquest record --backfill 5` adds the missing weekdays without touching existing rows. Backfilled rows are marked `backfill` in `recorded_at` and use the backfill GARCH refits. Say so in the backtest notes |
| Forecast Record tab not written | The row is still in the CSV. The tab is rewritten in full the next time `record` or `publish` runs with a token |

## Owner

Runbook: Team A, AGENT-06. Job: Sam. Team C owns the scheduler work for moving this to a server (roadmap
4.6, epic A8).
