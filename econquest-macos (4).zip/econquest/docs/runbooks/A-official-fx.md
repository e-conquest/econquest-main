# Runbook: official FX feeds, and the series Yahoo leaves behind

Ticket EQ-A-0040. Owner: Team A, AGENT-06. Operator: Sam. Written 2026-10-24 from
`econquest/ingestion/feeds.py` and `econquest/ingestion/market/forwards.py`. **This runbook was written
offline: the cloud cannot reach `stats.bis.org` or `data-api.ecb.europa.eu`, so every series key below is
marked UNVERIFIED until the first pull on the Mac confirms it.**

## Sam's decision (2026-10-23 23:16Z)

Asked "Allow Yahoo Finance prices in desk numbers?", Sam chose **Replace with free official**: Yahoo's
terms allow personal, non-commercial use only, so Team A swapped FX to BIS / ECB reference rates and
accepted the loss of some daily price history.

## What changed

| Before (Yahoo) | Now |
|---|---|
| `fetch` feed `yahoo` (yfinance): daily FX closes and country ETF closes | Feeds `bis_xru` (BIS daily exchange rates) and `ecb_exr` (ECB euro reference rates) |
| Country Profile `fx3m` from `<CCY>=X` closes | Same definition and sign convention, from the official daily series |
| Country Profile `equity_vol` from country ETFs | **Unserved**: "no official free source (Yahoo removed, Sam 2026-10-23)" |
| `forwards.py --spot yahoo` | `--spot bis` (default), `--spot ecb`, `--spot snapshot`; `--spot yahoo` refused |
| `fetch --only yahoo` | Refused with an error before any request (`feeds.YAHOO_REFUSED`) |

`fetch --only fx` pulls just the two FX feeds; `--only bis` pulls `bis`, `bis_cbs` and `bis_xru`.

## The series (UNVERIFIED until the first Mac pull)

**BIS daily exchange rates**, dataflow `WS_XRU`, key `D.<REF_AREA>.<CURRENCY>.A`
(`feeds.XRU_FLOW`, `XRU_KEY`), values in units of the currency per US dollar, pulled for the last
`XRU_DAYS` (400) calendar days and written to `data/live/raw_bis_xru.csv` before any transform.
Unverified: the frequency code `D`, the collection code `A`, the per-USD unit, and the euro-area
reference area `XM` (`feeds.EURO_AREA_BIS`). The reference area of a currency only one country uses is
that country's `bis_iso2` (else `iso2`); the shared currencies are in `feeds.SHARED_FX_AREA`
(EUR → `XM`, XOF → `SN`, XAF → `CM`, the last two also unverified).

**ECB euro foreign exchange reference rates**, dataflow `EXR`, key `D.<CCY>.EUR.SP00.A`
(`feeds.EXR_FLOW`, `EXR_KEY`), units of the currency per euro, written to `data/live/raw_ecb_exr.csv`
as delivered. Unverified: the type code `SP00`, the suffix `A`, and the per-EUR unit. Per-USD rates are
derived with the **same date's** EUR/USD reference rate (`feeds.ecb_per_usd`):

```
CCY per USD = (CCY per EUR) / (USD per EUR)          EUR per USD = 1 / (USD per EUR)
```

A date with no EUR/USD rate produces no row: no rate is ever carried over from another date.

**Which source serves a country.** BIS first; the ECB when BIS has no series for that currency. The two
are never mixed in one number, and the provenance row names the one actually used. Countries sharing a
currency (EUR, XOF, XAF) all get the same series, as they did under Yahoo.

**Cross-check.** `quality_gate` compares, per currency, the BIS rate with the ECB rate converted through
EUR/USD on the latest date both quote (`feeds.fx_cross_checks`, tolerance `FX_CROSS_TOL` = 1%). Above the
tolerance every `fx3m` cell of that currency is held with the reason `fx cross: ...`.

**No fx3m at all** (unserved, with the reason, in `data/live/unserved.csv` and as a `missing` row in
`review.csv`): dollarised countries, ZWL/ZWG (`feeds.NO_FX_QUOTE`), and any currency neither source
quotes.

## First pull on the Mac: what to check

```bash
cd ~/econquest
econquest fetch --only fx                 # no --apply on the first run
```

1. `Feeds: ... bis_xru: ok (...); ecb_exr: ok (...)`. If `bis_xru` says
   `BIS WS_XRU returned no exchange rate`, the key is wrong: open
   `https://stats.bis.org/api/v1/data/WS_XRU/D.BR.BRL.A/all?format=csv&lastNObservations=1` in a browser,
   note the dimension names and codes of the daily US-dollar series, and send them to Team A
   (`feeds.XRU_KEY`, `XRU_COLLECTION`, `EURO_AREA_BIS`, `SHARED_FX_AREA`). Do not edit the file by hand.
2. `data/live/raw_bis_xru.csv` and `data/live/raw_ecb_exr.csv` exist, with a `sdmx_key` column naming the
   series each row came from, and are copied into the new vintage folder.
3. `data/live/feed_failures.csv` lists every currency neither source served
   (`WS_XRU: no series for ...`).
4. Spot-check one rate against the central bank's own page (for example BRL/USD) before applying: the
   number should be the same to within a rounding step. If BIS and the ECB disagree by more than 1%, the
   gate already held the cell; send Team A the two numbers.
5. `fx3m` in `data/live/live_profile.csv` should be close to the last Yahoo-era value in
   `data/live/vintages/2026-10-23*/live_profile.csv` for the same country (reference rates and retail
   quotes differ by a fraction of a percent, not by points).

## Yahoo values still applied: the first official pull must clear them (SEC-A-006 M1, EQ-A-0045)

The `fetch --apply` of 2026-10-23 (before EQ-A-0040) wrote **17 Yahoo-derived `fx3m` cells** into
`data/countries.csv` (Vietnam, Philippines, China, Malaysia, Singapore, Japan, South Korea, India, Pakistan,
Belize, Brazil, Argentina, Colombia, Venezuela, Nigeria, Senegal, Zambia). The engine reads them
(layer 2 and layer 3). They are **not** edited by hand in the cloud copy: Sam's Mac data is authoritative,
and the replacement is the official pull below.

Check which applied cells still come from Yahoo or from a non-commercial / personal licence:

```bash
python -m econquest.ingestion.audit restricted        # "0 restricted-source cells" and exit 0 when clean
```

It lists every cell in `indicators.csv` / `countries.csv` whose value matches a value that the current
`data/live/provenance.csv`, any `data/live/vintages/*/provenance.csv` or `data/audit_trail.csv` attributes
to Yahoo / yfinance or a non-commercial licence (`audit.restricted_source_cells`), so a value is still
found after the next pull replaced `provenance.csv`. Today, on the 2026-10-23 data, it lists the 17 cells
above and exits 1.

**First PI-5 Mac task**, after the first-pull checks above:

```bash
econquest fetch --only fx --apply
python -m econquest.ingestion.audit restricted        # must print 0 restricted-source cells
econquest audit                                       # rewrites data/audit_trail.csv
grep -ci yfinance data/audit_trail.csv                # 0 once the audit trail is rewritten
```

While any restricted cell is left, `fetch --apply` (and `review apply`) prints a block of `!` lines
with `WARNING (SEC-A-006 M1): N applied cell(s) still hold values from a restricted source`, the cells,
and the commands above; the apply's result also carries `restricted_source_cells: N`. A cell can stay
because the official pull did not serve its currency, or because the gate held the new value (the
change from the Yahoo value was too large): review and apply it (`A-daily-record.md`), or send the list
to Team A. `econquest run` and `publish` warning on these cells, and `publish --write` refusing them,
are Team C's part (HO to C/AGENT-01 under EQ-A-0045, the same pattern as the attestation gate).

The validator data room never carries these values: it blanks every Yahoo-derived value in its copies
(`A-data-room.md`, SEC-A-006 M2).

## Series with no official free substitute

**Country Profile `equity_vol`** (annualised SD of country-ETF daily log returns, 60 trading days) was
the only Yahoo-only series in the desk pull. It is now left unserved for every country with the reason
`no official free source (Yahoo removed, Sam 2026-10-23)` and appears as a `missing` row in the gate
review and in the audit trail. It is **not** estimated, substituted or carried over.

**What loses an input.** Nothing in the engine. `equity_vol` was never written into `data/countries.csv`
(the file has no such column) and no engine reads the Country Profile `equity_vol`: the Monte Carlo's
`market.equity_vol` is the governed assumption in `data/assumptions.json` (Team B, EQ-B-0047), a
different number. The live `equity_vol` was a reported figure only — the dashboard Country Profile and
the audit trail. From this pull on, that figure is blank with a reason instead of being filled.

**`data/market_history/prices.csv` is not affected.** Checked under EQ-A-0040: that file comes from the
workbook's **Market History tab, which uses `GOOGLEFINANCE()`**, exported with
`econquest prices --sheet-json ...` (`ingestion/market_history.py`, README "Price data"), not from
Yahoo. The GARCH/DCC fit, the econometrics tab, the copula (layer 5) and the HMM regimes (layer 3) read
only that file, so they keep every series they had. Google's terms for `GOOGLEFINANCE` are a separate
question for Sam and are not covered by the 2026-10-23 decision.

### Options for `equity_vol`, for Sam to choose

1. **The GOOGLEFINANCE workbook route** (cheapest, no new licence question beyond the one above). Add the
   country ETFs' 60-day realised volatility to the Market History tab, export it with
   `econquest prices`, and compute `equity_vol` from `prices.csv` the way the GARCH module already does
   (`engine/garch.py` `market_vol`, kind `Equity`). Team A estimate: small, one ticket. It keeps the
   number inside the same source the models already use, and it removes the last reason to call Yahoo.
2. **Central-bank or exchange equity indices.** Several central banks and statistics offices publish a
   national equity index (and the ECB publishes euro-area indices) under the same free-reuse terms as the
   rates feeds. Coverage is partial, the index is not the ETF the desk holds, and currency exposure
   differs; it would be a different series, not a drop-in replacement. Medium effort, per-country mapping.
3. **A vendor licence.** Bloomberg or LSEG through the EQ-A-0033 adapter framework (off by default,
   behind the licence gate). Full coverage and dealable prices; paid, and needs Sam's licence decision.

Until Sam picks one, the cell stays blank with its reason. Nothing substitutes for it.

## Yahoo after EQ-A-0040

`feeds.YahooFeed`, `fx_tickers` and `yahoo_transforms` stay in the code for research that is not
published and not part of a run; nothing in the pipeline calls them. `fetch` refuses `--only yahoo`.
`forwards.py --spot yahoo` is refused unless `ECONQUEST_ALLOW_YAHOO=1` is set in the environment, and the
rows it then produces carry `YAHOO_LICENCE` ("personal non-commercial use"), which the market gate now
holds (`gate.DESK_BARRED_LICENCE_TERMS`), so they cannot reach a desk number or a publish.
