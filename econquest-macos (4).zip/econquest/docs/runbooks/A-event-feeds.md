# Runbook: event feeds (UCDP, GDELT, ACLED) on Sam's Mac

Tickets EQ-A-0022 (UCDP), EQ-A-0023 (GDELT), EQ-A-0024 (ACLED). Owner: Team A, AGENT-06. Date: 2026-10-23.
Background, licences and the indicator mapping: `docs/runbooks/A-spike-event-feeds.md`.

The cloud environment cannot reach UCDP, GDELT or ACLED. Every pull below runs on the Mac, from the econquest folder.
Code: `econquest/ingestion/events/` (`base.py` contract, `ucdp.py`, `gdelt.py`, `acled.py`, `indicators.py`).

## Where outputs land

| What | Path |
|---|---|
| Config (no secrets) | `data/live/events/feeds.json`. Defaults when absent: `{"ucdp": {"enabled": true, "token_env": "UCDP_API_TOKEN"}, "gdelt": {"enabled": true}, "acled": {"enabled": false, "licence": "none"}}`. Optional keys: `ucdp.ged_version` (default 26.1), `ucdp.candidate_version` (26.0.9), `ucdp.daily_request_limit` (4500). A key named token/password/key/secret is refused. |
| Vintages (append-only, files 0444) | `data/live/events/<source>/vintages/<YYYY-MM-DDTHHMMSSZ>-<hash8>/events.csv` + `manifest.json` (rows, sha256, licence, endpoints, dataset versions, coverage) |
| Vintage index | `data/live/events/<source>/vintages/index.csv` (`vintage_id, retrieved_utc, sha256, rows, licence`) |
| UCDP request counter | `data/live/events/ucdp/request_budget.json` (requests used today, UTC) |
| UCDP country map override | `data/live/events/ucdp/country_map.csv` (`ucdp_id, ucdp_name, iso`), optional |
| GDELT staging (resumable) | `data/live/events/gdelt/staging/` (`days/<YYYYMMDD>.csv`, `manifest.json`) |
| Team B long table (derived, EQ-A-0028) | `data/live/events/events_long.csv` (`iso, source, series, freq, period, value, vintage, provenance`; all vintages) |
| Team C weekly table (derived, EQ-A-0028) | `data/live/events_weekly.csv` (`events_view.EVENT_SCHEMA`; GDELT, ISO weeks from Monday) |
| Export archive (0444) | `data/live/events/exports/<YYYY-MM-DDTHHMMSSZ>-<hash8>/` (both files + `manifest.json`) and `exports/index.csv` |
| ACLED raw rows (only with `--include-raw`) | `data/live/events/acled/vintages/<id>/raw_acled.csv`. Never upload, publish, share or copy elsewhere (ACLED EULA). |

Table format (`EVENT_COLUMNS`): `iso, period, freq, source, metric, value, vintage_id, retrieved_utc, licence`.

## 1. UCDP (free, CC BY 4.0; cite UCDP)

Once: Sam requests the API token from UCDP by email (3-5 working days) and stores it in the Keychain:
`security add-generic-password -s econquest-ucdp -a "$USER" -w` (prompts for the token; AGENT-09 to review).

Each pull (5,000 requests a day including errors; a full desk pull is a few dozen requests):

```
export UCDP_API_TOKEN="$(security find-generic-password -s econquest-ucdp -w)"
python -m econquest.ingestion.events.ucdp --start 2019-01-01 --end "$(date -u +%F)"
unset UCDP_API_TOKEN
```

This pulls GED 26.1 for 2019-2025 and Candidate 26.0.9 for 2026, maps Gleditsch-Ward ids to ISO3 for the 18 desk
countries, aggregates to monthly counts and saves one vintage. Never pass the token as an argument.

If it stops with `UnmappedCountryError`, add the listed ids/names to `data/live/events/ucdp/country_map.csv` (never
guess; check the GED codebook) and rerun. If UCDP has released a newer version, set `ucdp.ged_version` /
`ucdp.candidate_version` in `feeds.json` (old version URLs keep returning the same data).

First live pull, verify (marked *(verify)* in `ucdp.py`): the response keys `TotalCount`, `TotalPages`, `Result`;
the filters `Country`, `StartDate`, `EndDate`; the field names `country_id`, `type_of_violence`, `best`,
`date_start`; that GED 26.1 ends at 2025-12-31; and that the Candidate coverage end (the latest event month seen,
recorded in the manifest as `candidate_coverage_end`) is sensible. Report anything different to AGENT-06.

## 2. GDELT (free; cite and link the GDELT Project)

Module `econquest/ingestion/events/gdelt.py` (EQ-A-0023, written alongside this one; see its docstring for options).
Raw 15-minute export files, no account. Staging is resumable: rerun the same command after an interruption.

```
python -m econquest.ingestion.events.gdelt --start 2019-01-01 --end "$(date -u +%F)" --save
```

Exit code 1 with `INCOMPLETE` means some days were not staged; rerun. A year is about 35,000 files, so a 5-year
backfill takes hours: start it overnight. Metrics are daily (`freq D`): `events_total`, `events_protest`
(root 14), `events_material_conflict`, `events_verbal_conflict`, `goldstein_mean`, `tone_mean`, `mentions_total`.

## 3. ACLED (only after Sam buys a corporate licence)

Disabled by default: the adapter refuses (`AcledDisabledError`, no request sent) unless `feeds.json` has
`"acled": {"enabled": true, "licence": "<licence name, tier and reference>"}`. The free/research tier does not
cover the desk (EULA §1.2): do not register one.

```
# store once: security add-generic-password -s econquest-acled -a "<account email>" -w
export ACLED_USERNAME="<account email>"
export ACLED_PASSWORD="$(security find-generic-password -s econquest-acled -w)"
python -m econquest.ingestion.events.acled --start 2019-01-01 --end "$(date -u +%F)"
unset ACLED_PASSWORD
```

Only monthly aggregates are saved. `--include-raw` adds `raw_acled.csv` inside the ACLED vintage folder only; it
must stay on the Mac. Unverified until the first licensed pull: the OAuth reply key `access_token`, the `iso`
filter, page numbering from 1 and the `data` key (see `acled.py`).

## 4. Consumer exports (rebuilt automatically)

`python -m econquest.ingestion.events.ucdp ...` and `python -m econquest.ingestion.events.gdelt ... --save` end by
calling `econquest.ingestion.events.export.write_event_exports`, which rebuilds both consumer tables from every
stored vintage and writes them atomically. To rebuild by hand (no network needed):

```
python -c "from pathlib import Path; from econquest.ingestion.events.export import write_event_exports as w; print(w(Path('data')))"
```

Mapping (Team B `series`): UCDP `events_total` -> `events`, `fatalities_best` -> `fatalities`; source `ucdp_ged` or
`ucdp_candidate` from the dataset windows in each vintage manifest (rows outside them are dropped and reported);
GDELT `events_material_conflict` -> `events` (filter: root events, QuadClass 4 material conflict, file-date basis),
`goldstein_mean` and `tone_mean` (means over all root events of the day; not conflict-only). `vintage` = date of
`retrieved_utc`, or `release_date` when a dataset entry in the manifest records one. A row is written again for a
later vintage only when its value changed. The weekly table is GDELT only (UCDP is stored monthly).
Archive: a changed export is copied read-only to `data/live/events/exports/<ts>-<hash8>/`; vintage folders are
never written to. If the export step fails after a vintage saved, the vintage stands: fix the cause and rebuild.

## 5. Verify

```
python - <<'EOF'
import datetime as dt
from pathlib import Path
from econquest.ingestion.events.base import list_event_vintages, latest_events
from econquest.ingestion.events.indicators import event_indicators, stored_events
d = Path("data")
for s in ("ucdp", "gdelt", "acled"):
    print(s, list_event_vintages(d, s)[-1:])
ev = stored_events(d)                      # latest vintage per source; sha256 checked against the manifest
print(ev.groupby(["source", "metric"]).size())
isos = sorted(ev["iso"].unique())
print(event_indicators(ev, dt.date.today(), isos).to_string())
EOF
```

Checks: every desk country appears for UCDP and GDELT; UCDP months run to the coverage end in the manifest;
`events.csv` in each vintage is read-only; 6.9 rows say `ucdp (proxy)` until ACLED is licensed; 4.1 and 6.4 rows
are evidence only (levels stay analyst-set; nothing writes `indicators.csv`).

Send the vintage ids and the indicator table to AGENT-08. Do not change an indicator's source definition in the
scorecard without model-risk change control (spike, "What Sam must decide" 4).
