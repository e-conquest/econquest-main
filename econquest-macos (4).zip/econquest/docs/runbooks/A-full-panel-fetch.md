# Runbook: full-panel hazard fetch (`fit-hazard --fetch`) on Sam's Mac

Tickets EQ-A-0003, EQ-A-0010, EQ-A-0015, EQ-A-0016 (GOV-006, GOV-044, roadmap 2.3). Owner: Team A, AGENT-06.
Operator: Sam. Written 2026-10-23; revised 2026-10-23 for the staged, resumable history pull
(`econquest/ingestion/panel_history.py`) and the full-universe CRAG import (`econquest/ingestion/default_panel.py`).

## Purpose

Pull every economy's IMF WEO and World Bank history, build the country-year default panel and fit the
layer-1 hazard model on it. The 18-country pilot (15 countries, 9 events) did not clear the gate. The full
panel is the only route to `layer1.mode = fitted`.

## When

One-off now, then after each WEO release (April and October) or when the default-episode file changes
(for example the CRAG importer from EQ-A-0008).

## Prerequisites

- econquest installed at `/Users/smc/econquest` from a zip built after 2026-10-23, so it includes
  `fit-hazard`. Check with `econquest fit-hazard --help`.
- Network access to imf.org and api.imf.org (through `imf-reader` and the `weo` package) and `api.worldbank.org`
  (through `wbgapi`). The cloud sessions cannot reach them, so this must run on the Mac. Check the packages:
  `.venv/bin/python -c "import imf_reader, weo, wbgapi; print('ok')"` (all three are econquest dependencies).
- The CRAG workbook downloaded to `~/Downloads/BoC-BoE-Database-2026.xlsx` (links in `data/panel/README.md`).
- About 2 GB of free disk (estimate: WEO release files are cached) and a power cable. Run under `caffeinate` so the Mac does not sleep.
- Do not pass `--apply` on this run. Switching `layer1.mode` to `fitted` is a Tier 1 model change: it needs
  owner, approver and validator sign-off (`docs/governance/model-risk-policy.md`). Also,
  `data/panel/sovereign_defaults.csv` is still compiled from memory (GOV-044) until EQ-A-0008 replaces it.

## Expected duration and size (estimates, not measured)

| Item | Estimate |
|---|---|
| WEO, 39 releases (2007-10 to 2026-10) | each release is one download of the whole database (10-40 MB). 1-5 min each, 30-120 min in total. Cached in `data/panel/staging/weo_cache/` (0.5-1.5 GB) |
| World Bank, 3 series | 20-30k rows, 1-5 min |
| `weo_history.csv` | about 5 series x 195 economies x 50 years x 39 releases = up to 2 million rows, 60-150 MB (zips to about a tenth) |
| CRAG import and coverage check | under 1 min |
| Fit | under 2 min |

## Steps

```bash
cd ~/econquest
mkdir -p outputs
# 0. Keep the current files (the history pull replaces weo_history.csv / worldbank_history.csv only on full success).
mkdir -p ~/econquest-backup/panel-$(date +%Y%m%d-%H%M)
cp -p data/panel/*.csv docs/validation/hazard-fit-report.md ~/econquest-backup/panel-$(date +%Y%m%d-%H%M)/ 2>/dev/null

# 1. See which WEO releases will be pulled and by which route (no network).
.venv/bin/python -m econquest.ingestion.panel_history --out data/panel --list-vintages

# 2. Staged history pull: every economy, every WEO release, 3 World Bank series. Keep the log.
caffeinate -i .venv/bin/python -m econquest.ingestion.panel_history --out data/panel 2>&1 | tee outputs/panel-history-$(date +%Y%m%d-%H%M).log
echo "exit code: ${PIPESTATUS[0]}"     # 0 = complete, 1 = units missing (resume), 2 = usage error

# 2b. Only if step 2 ended with INCOMPLETE: resume (run id is printed as "new run <id>" and in the INCOMPLETE line).
caffeinate -i .venv/bin/python -m econquest.ingestion.panel_history --out data/panel --resume <run_id> 2>&1 | tee -a outputs/panel-history-resume-$(date +%Y%m%d-%H%M).log

# 3. CRAG import for every economy, 1980 onwards, saved as a panel vintage (does not touch sovereign_defaults.csv).
.venv/bin/python -c "from econquest.ingestion.default_panel import import_crag; print(import_crag('$HOME/Downloads/BoC-BoE-Database-2026.xlsx', 'data/panel/sovereign_defaults_crag.csv', 'BoC-BoE Sovereign Default Database 2026 (BoC-BoE-Database-2026.xlsx)', '2026-10', iso_map_csv='data/panel/crag_iso_map.csv'))" 2>&1 | tee outputs/crag-import-$(date +%Y%m%d-%H%M).log

# 4. Review file for the episode change, and the coverage check.
.venv/bin/python -c "from econquest.ingestion.default_panel import compare_panels, comparison_table; r = compare_panels('data/panel/sovereign_defaults.csv', 'data/panel/sovereign_defaults_crag.csv'); print(r['summary']); comparison_table(r).to_csv('data/panel/crag_comparison.csv', index=False)"
.venv/bin/python -c "import json; from econquest.ingestion.default_panel import panel_coverage; print(json.dumps(panel_coverage('data/panel/sovereign_defaults_crag.csv', 'data/panel/weo_history.csv', universe_csv='data/panel/sovereign_defaults_crag_universe.csv'), indent=1))" | tee outputs/panel-coverage-$(date +%Y%m%d).json

# 5. Build and fit from the saved files (no --fetch, no --apply). Team B owns the interpretation.
caffeinate -i econquest fit-hazard --build-panel --defaults data/panel/sovereign_defaults_crag.csv 2>&1 | tee outputs/fit-hazard-$(date +%Y%m%d-%H%M).log
```

Step 3 may stop with "country names have no ISO3 code": fill `data/panel/sovereign_defaults_crag_unmapped.csv`,
save it as `data/panel/crag_iso_map.csv` and rerun step 3 (details in `data/panel/README.md`). For WEO releases
before October 2007, download the release's tab-delimited "all countries" file by hand, save it as
`data/panel/staging/weo_cache/weo_<YYYY-MM>.xls`, and add `--weo-vintages 1999-09,2000-05,...,2026-10` (or a range
`2000-04:2026-10`) to step 2; releases with no file and no route fail as a unit (exit 1) and are listed.

Do not use `econquest fit-hazard --fetch`: it still calls the old one-shot fetch (latest WEO only, World Bank
series silently skipped on error) until Team C wires it to `panel_history` (HO-20261023-A-C-011).

## Outputs

| Path (under `~/econquest`) | Content |
|---|---|
| `data/panel/staging/<run_id>/manifest.json` | Per unit (`weo/<YYYY-MM>`, `worldbank/<code>`): status, rows, sha256, attempts, error, source, economies, missing series |
| `data/panel/staging/<run_id>/{weo,worldbank}/*.csv` | Staged units |
| `data/panel/staging/weo_cache/weo_<YYYY-MM>.xls` | Downloaded WEO release files (weo-package route) and manual drop-ins |
| `data/panel/weo_history.csv` | iso, series, period, value, source, vintage (written only when every unit is ok) |
| `data/panel/worldbank_history.csv` | iso, series, period, value, source (same rule) |
| `data/panel/sovereign_defaults_crag.csv`, `..._universe.csv` | CRAG episodes (every economy, from 1980, sourced) and the countries CRAG covers |
| `data/panel/vintages/<ts>-<hash8>/`, `vintages/index.csv` | Read-only copies of each successful history pull and each CRAG import |
| `data/panel/crag_comparison.csv`, `outputs/panel-coverage-<date>.json` | Review inputs for Team B |
| `data/panel/hazard_panel.csv`, `docs/validation/hazard-fit-report.md`, `outputs/hazard_fit.json` | Step 5 (overwritten; never edit the report by hand) |

## Verification

1. Step 2 ends with `complete: run <id>, N units, panel vintage <id>` and exit code 0. Every unit line says `ok`.
2. Releases and series present:
   ```bash
   .venv/bin/python -c "import pandas as pd; w=pd.read_csv('data/panel/weo_history.csv'); print(w.groupby('vintage')['iso'].nunique().to_string()); print(w.groupby('series').size()); b=pd.read_csv('data/panel/worldbank_history.csv'); print(b.groupby('series')['iso'].nunique())"
   ```
   Expect one line per release with about 190 economies or more (estimate) and all 5 WEO and 3 World Bank series.
   Releases that lack a series are listed under `codes_missing` in the manifest.
3. The coverage JSON from step 4: `checks.at_least_100_countries` true and `checks.share_below_55pct` true (the
   acceptance of HO-20261023-B-A-002); `every_episode_sourced` true. Note `zeros_not_covered_by_crag` and
   `defaults_missing_from_history` for Team B.
4. Point in time:
   ```bash
   .venv/bin/python -c "import pandas as pd; from econquest.validation import hazard_panel as hp; w=pd.read_csv('data/panel/weo_history.csv', dtype={'iso': str, 'series': str, 'vintage': str}); e=hp.load_default_events('data/panel/sovereign_defaults_crag.csv'); p=hp.panel_from_long(w, None, e); print(p.attrs, len(p), p['iso'].nunique(), int(p['event'].sum()), p['year'].min())"
   ```
   Expect `'point_in_time': 'all features'` (HO-20261023-B-A-003). Note the first year: with releases from
   October 2007 the point-in-time panel starts in 2007 (see Risks).
5. `ls -l data/panel/vintages/` shows the new folders read-only (`dr-xr-xr-x`), and `vintages/index.csv` has a row each.

## Failure handling and resume

- **Any unit fails** (network, IMF or World Bank outage, empty answer, unexpected columns): it is retried 3 times
  with backoff (2, 4, 8 s; `--retries`, `--backoff`). If it still fails the run ends with `INCOMPLETE`, lists each
  missing unit and its error, exits 1, and leaves `weo_history.csv` and `worldbank_history.csv` exactly as they were.
  Rerun with `--resume <run_id>`: only failed or changed units are fetched again (a unit is skipped when its manifest
  status is ok and its staged file still has the recorded sha256). Resume reuses the parameters stored in the
  manifest; to change releases or series start a new run.
- **Interrupted** (sleep, Ctrl-C, power): the manifest is rewritten after every unit; resume as above.
- **One WEO release keeps failing**: check `--list-vintages`. For a release with no route, or a download that is a
  bot-check page (the tool refuses to cache it), download the file in a browser and save it as
  `data/panel/staging/weo_cache/weo_<YYYY-MM>.xls`, then resume. If a release cannot be had at all, start a new run
  without it (`--weo-vintages` list) and tell Team B which release is missing.
- **CRAG import fails**: see `data/panel/README.md` (unmapped names, renamed sheets).
- **Panel too small or fit error**: keep the logs and upload them as below. Restore files from
  `~/econquest-backup/panel-<ts>/` if needed; every successful pull is also in `data/panel/vintages/`.
- **Resume refused with `bad unit key` or `manifest units do not match its params`**: the run's `manifest.json`
  was edited or damaged. Do not repair it by hand; start a new run (EQ-A-0020).

## Cleanup

Panel vintages are written read-only (files 0444, folders 0555), so `rm -r` on one fails with "Permission denied"
for a normal user. Delete a vintage only when Team A agrees it is not referenced (a fit, a review CSV or a handoff
may name it), and use the helper, which restores the owner's write bit and refuses anything that is not a vintage
folder:

```bash
.venv/bin/python -c "from econquest.ingestion.panel_history import remove_panel_vintage as r; r('data/panel/vintages/<YYYY-MM-DDTHHMMSSZ-hash8>')"
# by hand, equivalent:  chmod -R u+w data/panel/vintages/<id> && rm -r data/panel/vintages/<id>
```

The row in `vintages/index.csv` is kept (the index is append-only). Old staging runs
(`data/panel/staging/<run_id>/`) are ordinary folders and can be removed with `rm -r` once their run is complete.

## Upload

```bash
cd ~/econquest && zip -r ~/Desktop/econquest-panel-$(date +%Y%m%d).zip data/panel -x 'data/panel/staging/weo_cache/*' && zip -j ~/Desktop/econquest-panel-$(date +%Y%m%d).zip docs/validation/hazard-fit-report.md outputs/hazard_fit.json outputs/panel-history-*.log outputs/crag-import-*.log outputs/panel-coverage-*.json outputs/fit-hazard-*.log
```

Upload the zip to the Claude project's files, next to `econquest/` (as for the 2026-10-23 `data/live` upload). The
WEO cache is left out (large, re-downloadable). Team B then reviews coverage and the fit and prepares the Tier 1
change. Nothing goes to the workbook at this step.

## Resumable fetch: status (EQ-A-0010)

Implemented in `econquest/ingestion/panel_history.py` (tests: `tests/test_panel_history.py`):

1. Staged units with a manifest: done, as `data/panel/staging/<run_id>/<source>/<unit>.csv` (one unit per WEO
   release and per World Bank series) and one `manifest.json` per run (status, rows, sha256, attempts, error,
   source, fetched UTC), written atomically.
2. Skip complete units: done (`--resume <run_id>`; sha256 must match). A forced refetch is a new run.
3. Retries with backoff: done (3 retries, 2 s doubling). World Bank is chunked per series, not per decade.
   Timeouts are those of imf-reader, httpx (weo package) and wbgapi; no extra timeout wrapper.
4. Fail loudly: done for the new tool (exit 1, final files untouched). `hazard_panel.fetch_worldbank_history` (Team B)
   still skips failed series silently; `fit-hazard --fetch` still uses it until HO-20261023-A-C-011 is done.
5. Assemble from complete stages and save append-only panel vintages: done (`data/panel/vintages/`). Recording the
   release and hashes in `hazard_fit.json` needs Team B/C (the manifest is in the vintage).
6. Tests: done (fail 2 units, resume refetches only those; missing unit leaves final files untouched; exit codes).

## Risks

- The point-in-time panel can only start when the first release does: with releases from October 2007, rows before
  2007 have no release published by their year and drop out of `panel_from_long`, which removes most of the 1980s and
  1990s defaults. Pre-2007 releases (manual files) or a Team B rule for earlier years is needed (HO-20261023-A-B-007).
- April and October releases of the same year have the same vintage year; `panel_from_long` sorts by year only, so
  which of the two it keeps is not guaranteed (HO-20261023-A-B-007).
- World Bank features are not point in time (no vintages through wbgapi); a fit that uses them reports `partial`.
