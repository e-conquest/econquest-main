# Model inventory

Date: 2026-10-23. Static facts below; live facts (mode, uplift switch, archived runs, hashes, evidence sizes) come
from `python -m econquest governance` (`inventory_status()` in `econquest/validation/governance.py`). Tiers follow
`model-risk-policy.md` section 2: Tier 1 sets a number that is reported or limit-tested (PD, VaR, ES, L-VaR,
expected loss, limit verdict); Tier 2 conditions a Tier 1 number or produces a decision input (regime, stress,
signal, alert, benchmark, GARCH VaR in the forecast record); Tier 3 is research or illustration that no reported
number depends on. "Paper-mode" means parameters are the paper's or the workbook's judgement values; "fitted" means
estimated on data in this repository. Owner is Sam for every component (model owner and, until roadmap 4.5 is
filled, acting approver); "desk" marks the components whose inputs are analyst-maintained files.

## Summary table

| # | Component | Code | Tier | Calibration | Last validation document | Frequency |
|---|---|---|---|---|---|---|
| 1 | Scorecard (7 pillars, 83 indicators) | `econquest/scorecard/scoring.py` | 1 | Paper-mode (workbook thresholds and weights); ~85% of indicator values seed estimates | `docs/validation/scorecard.md` | Quarterly; on any `rulebook.csv` or `assumptions.json` `scorecard` change |
| 2 | Layer 1 hazard | `econquest/engine/layer1_hazard.py`, `econquest/validation/hazard_panel.py` | 1 | Paper-mode (`layer1.mode` = `paper_standardized`); pilot fit stored under `layer1_fitted`, gate not cleared | `hazard-layer1.md`, `hazard-fit-report.md` | Quarterly `fit-hazard`; on new default episode or WEO vintage |
| 3 | Layer 2 Bayesian update and prediction-market prior | `econquest/engine/layer2_bayesian.py` (`posterior`, `default_contract_prior`, `blend_with_market`) | 1 | Paper-mode (`w_s 0.04`, `w_m 0.5`, `w_t 0.25`, `w_fx 0.1`, `tau_model 1`, `reference_oi_k 500`); since 0.1.3 `risk_premium_ratio 2.0` and Peg/Dollarized FX weight 0 (Sam, CHG-20261023T163209Z-b3f8bd); market prior on placeholder prices | `bayesian-layer2.md` | Quarterly; on benchmark scoring once available |
| 4 | Layer 3 regimes (rules, transition matrix, multipliers, HMM) | `econquest/engine/layer3_regime.py` | 2 | Paper-mode (rules 400/1000 bps, 5/15% FX, -10% reserves; matrix from the paper); HMM implemented, not fitted on real data | `regime-layer3.md` | Quarterly; on any `regime_rules`, `regime` or `transition_matrix` change |
| 5 | Layer 4 severity (Beta haircuts, Merton DD, GPD tails, multipliers) | `econquest/engine/layer4_severity.py`, `build_positions` in `layer6_montecarlo.py` | 1 | Paper-mode (`lgd_hard 60`, `lgd_local 35`, `lgd_sd 0.15`, `gpd_xi 0.25`, Merton `apply_uplift true`); nothing fitted to restructuring data | `severity-layer4.md` | Quarterly; on any `market` or `layer4` key change |
| 6 | Layer 5 Student-t copula and liquidity cost | `econquest/engine/layer5_copula.py` | 1 | Estimated loadings since 0.1.4 (`copula.source` estimated: Calm global and regional loadings fitted from weekly returns, judgement regime steps over the 0.15 anchor; countries without a series keep 0.15/0.25/0.35, regional 0.10); df 5 calm / 4 stressed judgement; liquidity spreads by asset class) | `copula-montecarlo-layers5-6.md` | Quarterly; on any `regime.*.global_loading`, `monte_carlo.df_*` or `liquidity` change |
| 7 | Layer 6 Monte Carlo (VaR/ES, L-VaR, contributions) | `econquest/engine/layer6_montecarlo.py` | 1 | GARCH 12-month FX and equity vols since 0.1.4 (`monte_carlo.vol_source` garch; regime `fx_vol` 12/7/2/0 and `equity_vol 25` as fallbacks and for pegs; `local_rate_vol 1.5`); 100,000 scrambled-Sobol paths, seed 7 | `copula-montecarlo-layers5-6.md` | Every release (seed-stability check); quarterly sensitivities |
| 8 | Liquidity-adjusted VaR | `liquidity_cost` in `layer5_copula.py`, applied in `layer6_montecarlo.py` | 1 | Paper-mode (`liquidity.by_asset` spreads, `regime_mult` 1/2/4, `T0_days 1`) | `copula-montecarlo-layers5-6.md` section 6.3 | Quarterly |
| 9 | Stress scenario library and reverse stress | `econquest/engine/stress.py`, `data/scenarios.json` | 2 | Data-driven since 2026-10-23: paper A, B, C plus ASIA97, GFC08, TAPER13, COVID20, FED22, TAIWAN, HORMUZ, TARIFF, CHINA_HL, DOWNGRADE (historical ones are stylised reconstructions); reverse stress bisects the severity to the limit breach | `stress-scenarios.md` | Every release (`run --stress`, `reverse-stress`); scenario library review yearly |
| 10 | GARCH(1,1)-t and DCC(1,1) volatility layer | `econquest/engine/garch.py` | 2 | Fitted (maximum likelihood on 786 daily prices, 17 FX pairs + 13 ETFs; persistence median ~0.91, df median ~4.2) | `garch-dcc.md` | Daily refit inside `record`; quarterly half-sample check |
| 11 | Econometrics toolkit (ten tables) | `econquest/engine/econometrics.py` | 3 | Fitted on the same prices; interpolated p-values; feeds no risk number | `econometrics-toolkit.md` | Yearly, or when the Market History tab changes source |
| 12 | CDS pricer and relative value | `econquest/engine/cds.py` | 2 | Fitted per quote when quotes exist; `data/cds_quotes.csv` has 0 rows today, so the component is dormant | `README.md` section "CDS-implied PDs" (no validation document yet) | On first quotes: write validation doc; then quarterly |
| 13 | PD benchmarks | `econquest/validation/benchmarks.py` | 2 | Not a model: a scoring harness (Brier, log loss, AUC per source); one snapshot of 18 rows, scoring from 2027-10-23 | `README.md` section "PD benchmarks"; `tests/test_benchmarks.py` | Daily snapshot; quarterly review of `score_sources` |
| 14 | Limits and pre-trade check | `econquest/engine/limits.py`, `data/limits.json` | 1 | Judgement limits (book VaR99 95, ES99 115, L-VaR99 100, EL 5 $mm; country default 45, Venezuela 10, Zimbabwe 5; warning level 0.8) | `README.md` section "Limits"; `tests/test_limits.py` (5 tests) | On any `limits.json` change (approver sign-off); yearly limit review |
| 15 | Alerts | `econquest/validation/alerts.py` | 2 | Thresholds in `assumptions.json` `alerts` (`pd_change_pp 2`, `pd_level 0.25`, `var_change_pct 10`, `stale_days 45`; signal threshold 60) | `README.md` section "Daily risk report and alerts"; `tests/test_report_alerts.py` | Yearly threshold review; on every false-negative found |
| 16 | Signals, trade activation, dashboard, GPR uplift, Kelly stakes | `econquest/engine/signals.py`, `econquest/engine/gpr.py`, `arbitrage_scan` in `layer2_bayesian.py` | 2 (signals, GPR) / 3 (Kelly stakes) | Paper-mode port of workbook formulas; never backtested; stakes on placeholder prices | `signals-trades.md`, `gpr-and-prediction-markets.md` | Quarterly once signal values are archived per run (GOV-030) |

Backtests (`econquest/validation/backtests.py`) and the forecast record (`validation/record.py`) are control
tools rather than models and are listed in `revalidation-routine.md`; the data pipeline (`ingestion/`,
`versioning.py`) is covered by `data-pipeline.md` and the issues log.

## Component detail

### 1. Scorecard

- Purpose: 83 indicators scored 0 to 100 by threshold interpolation into seven pillars, a composite and a grade;
  the composite feeds layer 2 (`w_s` per point above `score_centre 45.8`) and pillar 4 feeds layer 1 as the PITF
  instability proxy.
- Inputs: `data/rulebook.csv`, `data/indicators.csv` (1,494 cells, 224 live), `data/countries.csv`,
  `data/adjustments.csv`; `assumptions.json` keys `scorecard`, `floors`, `boom_trigger`, `stress_path`.
- Outputs: pillar and composite scores, grade, drivers; workbook tabs Base/Stress/Indicator Scores, Pillar Scores.
- Known limitations (from `scorecard.md`): inputs mostly seed estimates; thresholds not calibrated to outcomes;
  worst-indicator blend discontinuous in weights; one fixed stress path for all countries; floors can dominate
  (Venezuela 84.3 with four floors); momentum signal dead (`prior` empty); blanks silently dropped; exports used as
  the import proxy.
- Evidence: `tests/test_panoptix.py::test_scorecard_matches_workbook` (0.1 point tolerance against
  `workbook_reference.json`).

### 2. Layer 1 hazard

- Purpose: 12-month default hazard from six predictors; reconciled with the rating-implied challenger in log-odds
  at `hazard_weight 0.5`.
- Inputs: Country Profile fields (debt/GDP, ST FX debt/reserves, reserves, primary-balance gap, pillar 4, commodity
  gap), `ratings_pd` table; `layer1_paper_coefficients`, `layer1.feature_scale`.
- Outputs: `pd_hazard_l1`, `pd_rating`, `pd_model`; Risk Engine rows R31-R33.
- Calibration: paper coefficients on standardised predictors with location and scale fitted to the rating PDs.
  Pilot Firth fit on 421 country-years, 9 events: in-sample AUC 0.882, OOS AUC 0.780, OOS Brier 0.0320 vs base
  0.0232. Gate for `--apply`: AUC >= 0.75 (`hazard_panel.GATE_MIN_AUC`), events >= 30, Brier strictly below the trailing base rate; not cleared.
- Known limitations (`hazard-layer1.md`): cannot disagree with ratings in level; location-scale dominated by the
  two SD sovereigns; rating table has no vintage; Zimbabwe hazard 0.7% vs rating 60%; commodity feature pushes
  Senegal and Zimbabwe down by 2.3 log-odds; no OOS test in the live pipeline.

### 3. Layer 2 Bayesian update

- Purpose: logit(p_post) = logit(p_model) + w_s (S - 45.8) + w_m z_cds + w_fx z_fx + w_t z_tsi, then a
  precision-weighted blend with the default-contract prior.
- Inputs: spreads (hand-entered, Country Profile), FX 3-month change, text stress index (zero everywhere),
  `data/prediction_markets.csv` (18 contracts, illustrative prices, no `slug`/`ticker`).
- Outputs: `pd_default` (final PD), `pm_default`, `tau_market`.
- Known limitations (`bayesian-layer2.md`): market term dominates (z_cds 0.80 to 3.45 for every country; since
  0.1.3 a single literature-based risk-premium ratio of 2, not estimated); contract horizon now follows the run's
  `as_of` (GOV-012 resolved); text term inert; `w_fx` on realised depreciation, applied to pegs too; `tau` values are not
  measured precisions; `pd_market` cap 0.95 binds for Venezuela.

### 4. Layer 3 regimes

- Purpose: Calm/Stressed/Crisis per country from spread, 3-month depreciation and reserve loss; 12-month
  transition-weighted PD and LGD multipliers (Calm 1.0/1.0, Stressed 1.25/1.1, Crisis 1.6/1.25); global regime
  when >= 50% of countries are not Calm (today 8 of 18, below the switch).
- Known limitations (`regime-layer3.md`): three threshold inputs, two hand-entered; global switch is a cliff
  (VaR99 66.0 to 74.8 $mm when `global_stress_share` is 0.4); transition matrix not estimated and not rescaled to
  horizon; no regime switching inside paths; reserves rule absent from Crisis; HMM tested on synthetic data only;
  `scenario_override` changes multipliers but not inputs.

### 5. Layer 4 severity

- Purpose: stochastic LGD and haircuts (Beta around `lgd_hard`/`lgd_local`, regime-scaled), Merton distance to
  distress adding an LGD uplift for Eurobond and CDS positions, GPD tails for expropriation and political-violence
  losses, sector and location multipliers for equities.
- Status after 2026-10-23 fixes: uplift reaches the simulation (`expected_lgd`, clipped 0.05 to 0.95); GPD scale
  root-found so the clipped mean equals target; `beta_params` rescales a and b jointly near the cap. Effect at
  20,000 paths: VaR99 65.98 to 68.75 $mm, ES99 87.05 to 88.75, expected loss 0.24 to 1.91 $mm (Venezuela LGD 0.71 to
  0.95).
- Known limitations (`severity-layer4.md`): multipliers reach only the two equity positions (18 $mm); `lgd_sd 0.15`
  common to all classes; FX transfer loss deterministic (15% for the pegs Belize and Senegal); `lgd_hard` capped
  at 0.95 (binds in scenario B); Merton proxy sensitive to the barrier floor.

### 6 to 8. Layers 5 and 6, liquidity

- Purpose: one-factor-per-block Student-t copula (global, regional, idiosyncratic), 100,000 scrambled-Sobol paths,
  VaR/ES at 95 and 99, ES 97.5, L-VaR, position and country contributions.
- Outputs on the 0.1.4 base (as_of 2026-10-23, 100,000 requested = 131,072 Sobol paths, seed 7; release note
  `releases/0.1.4-2026-10-23.md`, reproduced by `python -m econquest.validation.replicate` R01-R04, D11): VaR99
  74.35 (Monte Carlo SE 0.40), ES99 96.48 (SE 0.45), EL 0.45, liquidity cost 5.28, L-VaR99 79.63 $mm (SE 0.40;
  95% band 78.82-80.45, which contains the 80 $mm warning level); `outputs/run_latest.json`, `country_risk.csv`,
  `positions.csv`, `contributions.csv`, `latent_correlation.csv`. The superseded pre-0.1.3 figures (run
  `20261023T111315-base`: 68.02 / 86.92 / 1.87) predate GOV-001..005 and the 0.1.3 and 0.1.4 changes.
- Known limitations (`copula-montecarlo-layers5-6.md`): the tail is a market-volatility tail (default risk under
  20% of ES99); since 0.1.4 FX and equity vols are GARCH 12-month forecasts (EWY 42.8%) with regime fallbacks for
  pegs and missing series, and Calm loadings are estimated, regime step-ups and df judgement; one latent variable
  per country for market and events; liquidity cost deterministic and additive; 71 Sobol dimensions; CDS leg
  simplified; positions static for 12 months; the batch-means Monte Carlo SE is conservative for scrambled Sobol
  (16-seed sd 0.27 VaR99, 0.25 ES99 at the production count).
- Evidence: `test_monte_carlo_metrics_consistent`, `test_sobol_is_reproducible`,
  `test_tail_dependence_positive_and_gaussian_limit`, `test_mc_error_*` (EQ-B-0054); Monte Carlo SE carried in
  every run's metrics (`var99_se_mm`, `es99_se_mm`, `lvar99_se_mm` and 95% bands).

### 9. Stress scenarios

- Outputs on 0.1.4 (as_of 2026-10-23, 100,000 requested each; release note, replicate R09-R14): A VaR99 121.80 /
  ES99 155.48 (+61.2% on ES), B 80.91 / 102.90 (+6.7%), C 88.18 / 114.86 (+19.1%).
- Known limitations (`stress-scenarios.md`): A is a regime and dependence shock (paper reports +18.4%); B is an LGD
  statement; C reaches equities only through location; response step-like at regime cliffs; sizes are data in
  `scenarios.json` but judgement; rate level and contagion channels built, partly (GOV-027).

### 10. GARCH and DCC

- Purpose: conditional volatility and correlation for the FX and ETF legs; one-day 99% VaR/ES for the forecast
  record; vol-target scalar (`target_vol 0.1`, cap 2); Black-Scholes check.
- Known limitations (`garch-dcc.md`): three years of data, no standard errors; administered rates (USDVES, USDNGN,
  USDARS, USDPKR, USDBZD) give near-unit persistence; FX and equity blocks combined at zero correlation; 9 of 24
  positions marked, local bonds as currency only; not connected to the Monte Carlo volatilities.

### 11. Econometrics toolkit

- Purpose: ten research tables (stationarity and variance race, cointegration, SVAR, Kalman betas, regimes, risk
  premia, EVT, copulas, forecast panel, event study); the Student-t copula preferred over Clayton in 13 of 13 pairs
  is the only data-based support for the layer 5 choice.
- Known limitations (`econometrics-toolkit.md`): three years and one macro cycle; interpolated p-values; no credit
  series; administered currencies not excluded; forecast R-squared dominated by between-series levels; Markov
  switching from one start and one seed; code constants not in `assumptions.json`.

### 12. CDS pricer

- Purpose: bootstrapped piecewise-constant hazards from par spreads, CDS-implied 12-month and 5-year PD,
  model-fair spread, rich/cheap read. Settings `cds` (`recovery 0.4`, `risk_free 0.04`, quarterly).
- Status: `data/cds_quotes.csv` is empty; nothing downstream (benchmarks `pd_cds`, relative value) is populated.
  No validation document exists; `tests/test_cds.py` covers the arithmetic. A validation document is required
  before the first quotes are used (GOV-040).

### 13. PD benchmarks

- Purpose: standing comparison of the model PD with hazard-only, rating-implied, spread-implied, CDS-implied and
  prediction-market probabilities; `outcomes` and `score_sources` give Brier, log loss and AUC per source once
  snapshots are 12 months old; `disagreement_table` ranks today's gaps.
- Status: 18 rows dated 2026-10-23 in `data/benchmarks.csv`; scoring block empty until 2027-10-23; outcome
  labels depend on `data/panel/sovereign_defaults.csv`, compiled from memory with a stated +/-1 year uncertainty.

### 14. Limits

- Purpose: grade the book against `data/limits.json` (book, country, asset class, issuer, concentration, Crisis
  share); `pretrade_check` reruns the pipeline with and without a proposed position on common random numbers and
  returns accept/flag/refuse.
- Status: 71 rows, all pass. A 10 $mm six-year Argentina Eurobond is flagged (ES99, L-VaR99 and the Eurobond
  class at 80% of limit); 100 $mm is refused. The limits are judgement values set by the owner; no approver other
  than the owner has signed them (GOV-041).

### 15. Alerts

- Purpose: regime flips, PD moves >= 2 pp (critical at 4 pp), PD level crossings at 25%, signal crossings at 60,
  trades starting or stopping, VaR99/ES99 moves >= 10%, backtest failures and Basel Yellow/Red, quality-gate
  holds, missing and failed feeds. Delivery to webhook and SMTP.
- Status on `20261023T111315-base`: 0 critical, 2 warning (quality holds: Nigeria exports latest period 1960,
  Venezuela reserves 2017), 1 info (110 input cells on seed).

### 16. Signals, trades, GPR, Kelly

- Purpose: 25 signals, 26 playbook trades with conviction and sizing (`risk_budget_mm 10`, regime scalar), dashboard
  reads; GPR uplift on indicator 4.10 (percentile 90/97, z 1.5/2.5); Kelly stakes at 25% fraction on a 500k
  bankroll.
- Known limitations (`signals-trades.md`, `gpr-and-prediction-markets.md`): no signal tested against outcomes;
  conviction reflects signal construction (binary 100s); signals 15 and 19 report `w_m`; signal 25 and all stakes
  rest on placeholder prices and the run date; GPR covers 11 of 18 countries; the non-default contract curve is
  uncalibrated; Kelly has no uncertainty on p.

## Calibration status at a glance

| Status | Components |
|---|---|
| Fitted on real data | GARCH/DCC (10), econometrics (11) |
| Fitted but not in use (gate not cleared) | Layer 1 `layer1_fitted` (2) |
| Paper-mode, in production | Scorecard (1), layer 1 live path (2), layer 2 (3), layer 3 (4), layer 4 (5), layer 5 (6), layer 6 (7), liquidity (8), stress (9), signals (16) |
| Judgement thresholds | Limits (14), alerts (15) |
| Dormant for lack of data | CDS pricer (12), benchmark scoring (13), text stress index term in layer 2 |
