# Revalidation routine

Date: 2026-10-23. Two cycles: a quarterly revalidation (first one due 2027-01-23) and an event-driven one. Each
cycle produces a short report filed at `docs/governance/revalidation/<date>.md` with the command outputs, the
threshold table filled in, the new or closed GOV issues and the signatures. Commands assume the folder holding
`data/` and `pyproject.toml`; with the installer they are `econquest <cmd>`.

## 1. Quarterly revalidation

### 1.1 Environment and reproduction (owner, 15 minutes)

```bash
python -m pytest -q tests                                   # record the passed count
python -m econquest runs --limit 5                          # latest hashes
python -m econquest run --stress --backtest                 # 100,000 paths; new base and A/B/C runs
python -m econquest governance                              # change-log.md, inventory status
```

Compare the new base run with the last signed base run (today `20261023T111315-base`, VaR99 68.02, ES99 86.92,
EL 1.87 $mm). With unchanged `code_hash` and `data_hash` the difference must be within Monte Carlo error (about 1
$mm on ES99 at 100,000 paths, from the seed sensitivities in `copula-montecarlo-layers5-6.md`); anything larger
with equal hashes is a run-date effect (GOV-012) or a defect and is a finding.

### 1.2 Hazard recalibration (owner, then validator)

```bash
python -m econquest fit-hazard --build-panel --fetch        # on the Mac: full WEO and World Bank history
python -m econquest fit-hazard --build-panel                # offline: the 18-country vintage already in data/live
```

Reads `docs/validation/hazard-fit-report.md` (regenerated) and `outputs/hazard_fit.json`. Record OOS AUC, OOS
Brier against base rate, events, and the calibration-by-decile table. `--apply` only when the gate clears (table
below); a switch of `layer1.mode` is a Tier 1 change through `change-control.md`.

### 1.3 Backtests on the forecast record

```bash
python -m econquest backtest --history data/forecast_record.csv --alpha 0.99
```

Record n, exceedances, Kupiec p, Christoffersen conditional-coverage p, Acerbi-Szekely Z2, Basel zone, verdict.
Also confirm the record is being taken daily (rows with `recorded_at` not prefixed `backfill` since the last
cycle) and that `marked_positions` reflects the book of each day, not the backfill's 13. Today: n 60, 1 exceedance,
Kupiec p 0.636, CC p 0.879, Z2 -0.27 (pass), Green, verdict Pass, all 60 rows backfilled on 2026-10-23.

### 1.4 Benchmark scoring

```bash
python -m econquest benchmark                               # today's snapshot; outputs/benchmarks_scores.csv, benchmarks_snapshot.csv
```

`score_sources` fills once snapshots are 12 months old (first possible on 2027-10-23). Until then review
`disagreement_table` (`outputs/benchmarks_snapshot.csv`): the largest model-versus-rating and model-versus-spread
gaps in pp, and whether the one-line reads are still right. Confirm `data/panel/sovereign_defaults.csv` has been
updated with any default start in the quarter (the outcome labels depend on it).

### 1.5 Stress and limits

Read `outputs/stress.json`: change in ES99 for A, B, C against the base (today +80%, +7%, +24%), countries moving
to Crisis, liquidity cost change. Then `python -m econquest limits` and compare `outputs/limits.csv` utilisations
with the previous quarter; any row that moved from pass to warning without a book change is a finding about the
model, not the book.

### 1.6 Volatility layer and data

```bash
python -m econquest garch                                   # about a minute
python -m econquest fetch                                   # dry run: feed status, gate holds, diff vs seed
python -m econquest audit
```

GARCH: persistence median (reference 0.91), Student-t df median (4.2), DCC convergence, and the half-sample VaR99
change in `garch-dcc.md` (reference 5 to 11 percent). Data: every feed `ok` in `data/live/feeds.json`, number of
`hold` and `missing` rows in `review.csv` (today 2 and 110), World Bank series with a latest period more than three
years old, and the audit trail row count (1,584). A fall in live coverage below the previous quarter's 224 cells is
a finding.

### 1.7 Documents and sign-off

The validator works through the 11-step review checklist in `docs/validation/README.md`, marks each open item in
every validation document accepted / rejected / done, updates `issues-log.md`, and signs. The owner signs that the
inventory reflects the live `inventory_status()` output. The approver signs the threshold table.

## 2. Thresholds that trigger recalibration or a model change

| Area | Test | Threshold | Action when breached | Reference today |
|---|---|---|---|---|
| Layer 1 fit (`fit-hazard`) | Rolling-origin OOS AUC | < 0.70 | Do not apply; keep or revert to paper mode; open GOV issue; review predictors and panel | OOS AUC 0.780 (pilot, 9 events) |
| Layer 1 fit | OOS Brier vs base-rate Brier | Brier >= base rate | Do not apply (the fit is no better than the unconditional rate) | 0.0320 vs 0.0232: breached, so the fit is not applied |
| Layer 1 fit | Default starts in panel | < 30 (`--min-events`) | Do not apply; extend panel with `--fetch` | 9: breached |
| Layer 1 live | Mean 12-month PD change vs previous quarter at unchanged inputs | > 2 pp mean or > 5 pp any country | Investigate rating table or calibration; owner + approver | Mean PD 0.139 (seed snapshot) |
| Forecast record | Kupiec unconditional coverage | p < 0.05 | Recalibrate GARCH volatilities (refit window, df) and review `market.fx_vol`; Tier 2 change | p 0.636 |
| Forecast record | Christoffersen conditional coverage | p < 0.05 | Review clustering: DCC specification, regime scalar | p 0.879 |
| Forecast record | Acerbi-Szekely Z2 | Z2 < -0.7 | ES understated: review Student-t df and ES formula | Z2 -0.27 |
| Forecast record | Basel zone (n >= 250) | Yellow (5 to 9 exceedances) | Multiplier note in the report; investigate within the quarter | Green (n 60, underpowered) |
| Forecast record | Basel zone | Red (>= 10) | Stop quoting the one-day VaR internally until recalibrated; Tier 1 emergency change | Green |
| Benchmarks | Model Brier vs rating-implied Brier (12-month outcomes) | Model worse than rating-implied | Review `hazard_weight 0.5` and `w_m`; a model that loses to the rating table should weight it more | Not scorable before 2027-10-23 |
| Benchmarks | Model Brier vs base rate | Worse than base rate | Tier 1 finding; suspend the PD blend parameters pending review | Not scorable |
| Benchmarks | Model AUC | < 0.70 | Same as above | Not scorable |
| Benchmarks | Disagreement | Model vs rating or spread gap > 20 pp for a country two quarters running | Country-level review of inputs (spread, rating, floors) | Largest gaps in `outputs/benchmarks_snapshot.csv` |
| Monte Carlo | Base VaR99 change at equal hashes | > 1.5 $mm (1.5 x Monte Carlo error) | Defect or run-date effect; finding | 68.02 $mm |
| Monte Carlo | Seed sensitivity at 20,000 paths | VaR99 > 2% or ES99 > 5% across seeds | Raise path count or review Sobol dimension count | 1% / 4% |
| Stress | Scenario A ES99 change | Outside 60 to 100 percent of base without a documented reason | Review regime cliffs and loading patch | +80% |
| Limits | Any book-level limit at warning (>= 0.8) without a book change | One occurrence | Model-driven utilisation move: finding | All pass |
| GARCH | Persistence median | > 0.98 | Review administered currencies excluded from the fit | 0.91 |
| GARCH | Half-sample VaR99 change | > 15 percent | Add standard errors; review window | 5 to 11% |
| Data | Live cells with gate `hold` | > 10 in a pull | Review `--max-change 0.5` and the range rules before applying | 2 |
| Data | Feeds failed | Any | Rerun; if two cycles fail, the indicator reverts to Manual on the API Map and the audit trail says so | 4 of 4 ok |
| Data | Cells with no live value | Rising quarter on quarter | Finding against roadmap items 1.3 and 1.4 | 110 |
| Alerts | Critical alert not explained in the next report | Any | Finding; alert thresholds reviewed | 0 critical |
| Tests | Passed count | Below the previous release | No release; finding | Recorded in `change-control.md` |

## 3. Event-driven revalidation

| Event | Within | Rerun | Who signs |
|---|---|---|---|
| A sovereign in the universe defaults, restructures or misses a payment | 5 working days | Add the episode to `data/panel/sovereign_defaults.csv`; `fit-hazard`; `benchmark` (the snapshot before the event becomes scorable at 12 months); compare the model's PD path for that country in `outputs/store` (`Store.series("pd_default", country)`) with the rating and spread paths; stress the book | Owner, validator |
| Global regime flips (alert `regime_flip` scope `global`) or >= 3 country regime flips in a week | Same week | `run --stress`; limits; check whether the flip is a cliff artefact (`regime-layer3.md`) or an input change | Owner, approver |
| VaR99 or ES99 moves >= 20 percent between consecutive base runs (twice the alert threshold) | Same day | Explain from `settings_diff`, `data_hash` and the country table; if unexplained, treat as a defect | Owner |
| Basel zone turns Yellow or Red on the forecast record | Same week | Section 1.3; GARCH refit review; report the multiplier | Owner, approver |
| A feed changes definition or vintage (new WEO release in April and October, World Bank WGI update) | Next pull | `fetch` dry run; review `diff_vs_seed.csv` and `transform_log.csv` (jump rule and r-g cap applications); `audit` | Owner |
| `assumptions.json`, `limits.json` or `rulebook.csv` change | Before release | `change-control.md` in full; sensitivities for the keys listed in policy section 4 | Owner, approver (validator for Tier 1) |
| Code change in `engine/` or `scorecard/` | Before release | Full test suite; base and stress run; workbook regression | Owner, approver |
| New position type, country or indicator | Before first use | `Universe.validate` passes; scorecard regression re-based with reason; limits file extended; inventory updated | Owner, approver |
| Independent validator appointed (roadmap 4.5) | First quarter after | Full quarterly cycle plus the 11-step review checklist; all "independent review pending" sign-offs revisited | Validator |
| Licensed market data arrives (roadmap 1.3) | Before use | CDS pricer validation document written; `pd_market` source changed from hand-entered spreads; layer 2 `w_m` revisited | Owner, approver, validator |

## 4. Signatures

| Cycle | Owner (Sam) | Approver | Validator | Date |
|---|---|---|---|---|
| Baseline at pack creation | Signed by writing this pack | Acting (Sam) | Open (roadmap 4.5) | 2026-10-23 |
| Q1 (due 2027-01-23) | | | | |
| Q2 (due 2027-04-23) | | | | |
| Q3 (due 2027-07-23) | | | | |
| Q4 (due 2027-10-23; first benchmark scoring) | | | | |
