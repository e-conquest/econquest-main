# Model risk policy

Date: 2026-10-23. Applies to every component in `model-inventory.md` and to the data, parameters and limits they
read: the `econquest` package, `data/assumptions.json`, `data/limits.json`, the CSV inputs under `data/`, the
Google Sheets workbook "Geopolitical-Macro Risk Desk" (a view of published values since 2026-10-20) and the run
archive under `outputs/store/`. Written against roadmap items 4.4 (access control and sign-off) and 4.5
(independent review).

## 1. Principles

1. The Python program is the calculator and the workbook is a view. A number in the workbook that cannot be
   reproduced by `python -m econquest publish` from the files in `data/` is not a model output.
2. Every reported number must be traceable to a run id in `outputs/store/econquest.sqlite` whose `code_hash`,
   `data_hash` and settings JSON are stamped (`econquest/versioning.py`), and every input cell to a row of
   `data/audit_trail.csv` (`econquest audit`, 1,584 rows).
3. A model is only as validated as its inputs. The validation documents accept the methods; the inputs
   (seed estimates, placeholder prices, synthetic history) are what restrict use today (section 6).
4. The owner cannot approve his own change. Until a second person exists (roadmap 4.5) this principle is
   violated by construction; every sign-off made under that condition is marked "owner-approved, independent
   review pending" in `change-control.md`, and the issues log carries GOV-042 open.

## 2. Tiering

| Tier | Definition | Components today | Consequence |
|---|---|---|---|
| 1 | Sets a number that is reported, limit-tested or sized against: 12-month PD, VaR, ES, L-VaR, expected loss, limit verdicts | Scorecard, layer 1, layer 2, layer 4, layer 5, layer 6, liquidity, limits | Full validation document, regression tests, quarterly revalidation, two signatures on every change (owner + approver), independent validation before any external use |
| 2 | Conditions a Tier 1 number or produces an input to a decision: regime, stress result, GARCH VaR in the forecast record, signal, alert, benchmark, CDS-implied PD | Layer 3, stress, GARCH/DCC, CDS pricer, benchmarks, alerts, signals and trade activation, GPR uplift | Validation document, tests, quarterly revalidation, owner + approver on parameter changes; code changes may go with the release checklist alone |
| 3 | Research or illustration no reported number depends on | Econometrics toolkit, Kelly stakes on prediction markets, HMM demo | Documented limitations, tests where practical, yearly review; outputs carry an "illustrative" label on the dashboard and in the workbook |

A component moves up a tier when its output starts feeding a Tier 1 or 2 number (for example the GARCH layer
would become Tier 1 if its volatilities replaced `market.fx_vol` in the Monte Carlo, GOV-020), and may move down
only by an approver's decision recorded in the issues log.

## 3. Roles

| Role | Who today | Duties |
|---|---|---|
| Model owner | Sam | Maintains code, `assumptions.json`, `limits.json`, data vintages and the validation documents; runs the release procedure; keeps the inventory and issues log current; answers reviewer challenges in writing |
| Validator (independent review) | Open (roadmap 4.5) | Reads the validation documents, reruns the review checklist in `docs/validation/README.md` (11 steps) and the revalidation routine, logs findings as GOV issues, signs the quarterly revalidation; must not have written the code under review |
| Approver | Sam, acting (should be a head of risk or the validator once in place) | Signs off model changes, limit changes and exceptions; decides tier moves; owns the use restrictions in section 6 |
| Desk users | Analysts who edit the input tabs or `data/*.csv`, type prediction-market prices, CDS quotes and rating overrides | Record a source and date for every hand-entered value (seed notes in `indicators.csv`, `cds_quotes.csv` `source` column); do not change `assumptions.json` or `limits.json` |

Four-eyes on analyst overrides (`data/adjustments.csv`, maximum `max_analyst_adj 10` points) is required by
roadmap 4.4 and is not yet enforced by the code; until it is, the owner reviews the adjustments file at each
release and the review is a checklist line in `change-control.md`.

## 4. What counts as a model change

Any of the following, each detectable from the run archive (`change-log.md`) or from the file system:

| Change | How it shows | Class | Sign-off |
|---|---|---|---|
| Code change: any `.py`, `.html` or `.js` under `econquest/` | `code_hash` differs between consecutive runs of the same label (`code_changed` yes) | Model change if it touches `engine/`, `scorecard/`, `validation/backtests.py`, `validation/alerts.py` or `ingestion/feeds.py` transforms; maintenance change otherwise (CLI, GUI, docs generation, report rendering) | Model change: owner + approver, tests pass, affected validation document updated. Maintenance: owner, tests pass |
| `data/assumptions.json` change | `settings_changed` yes with the moved keys in `settings_diff`; `data_hash` also moves because the file is in `versioning.DATA_FILES` | Model change (parameter). Changing `monte_carlo.paths` or `seed` alone is a run setting, not a model change | Owner + approver, through `econquest change propose` / `approve` / `apply` (hash-chained `data/approvals/log.jsonl`); `econquest change show <id>` is the sign-off evidence; the validation document that quotes the key is updated; sensitivities rerun if the key is one of `probability.w_m`, `regime.*.global_loading`, `monte_carlo.df_*`, `market.lgd_hard`, `market.*_vol`, `layer1.*` |
| `data/limits.json` change | `data_hash` moves (in `DATA_FILES` since GOV-043); the change goes through `econquest change`, so the proposal records old and new values | Limit change, not a model change, but requires the approver alone to sign; the owner cannot raise a limit on himself | Approver, via `econquest change approve`; `econquest limits` rerun and `outputs/limits.csv` attached |
| Data vintage change: `fetch --apply`, edits to `indicators.csv`, `countries.csv`, `portfolio.csv`, `prediction_markets.csv`, `rulebook.csv`, `adjustments.csv`, `playbook.csv`, `gpr_monthly.csv`, `backtest_history.csv`, `market_history/prices.csv` | `data_hash` differs (`data_changed` yes); vintage folder `data/live/vintages/<date>/`; `review.csv` decisions | Input change. Routine when through the quality gate with no `hold` rows; a model change when a held cell is force-applied (`fetch --force`) or a rulebook threshold or weight moves | Routine: owner. Force-apply or rulebook: owner + approver, with the `review.csv` decision text |
| Switching `layer1.mode` from `paper_standardized` to `fitted` | `settings_diff` shows `layer1.mode`; `hazard-fit-report.md` regenerated | Tier 1 model change, and the lifting of use restriction 6.1 | Owner + approver + validator; gate figures (OOS AUC >= 0.75, >= 30 events, Brier strictly below the trailing base rate; `hazard_panel.gate_check`) quoted in the release note; `fit-hazard --apply` only proposes the switch through `econquest change` |
| Scenario definition change in `engine/stress.py` | `code_hash` moves; stress runs' `settings_diff` changes (for example `market.lgd_hard: 60.0 -> 78.0`) | Tier 2 model change | Owner + approver; `stress-scenarios.md` updated |
| Package version bump (`econquest/__init__.py` `__version__`) | `code_version` column | Required for every model change released; maintenance changes may share a version | Part of the release checklist |

Two runs with the same `code_hash`, `data_hash` and settings JSON (which carries `as_of`) are the same model.
Since EQ-B-0001 (GOV-012) the model reads no wall clock: the run's `as_of` is fixed once, stored in the settings
and in `versions` (`run_hash` covers it), and must be quoted with the run id.

Every change to `data/assumptions.json` or `data/limits.json` goes through `econquest change` (propose, approve,
apply, verify). A hand edit shows as drift in `econquest change verify` and in the governance status
(`approvals`), and is treated as an unapproved change until it is re-baselined with the approver's sign-off.
The first `apply` rewrites the JSON canonically (indent 2), which moves `data_hash` once without a parameter change.

## 5. Approval path

1. Owner prepares the change on a copy, runs `python -m pytest -q tests` (all files; count recorded), reruns
   `python -m econquest run --stress --backtest` and compares VaR99/ES99/EL with the previous base run in
   `change-log.md`. A move above the alert threshold (`var_change_pct 10`) needs an explanation in the release note.
2. Owner updates the validation document(s) and the inventory row, adds or closes issues in `issues-log.md`, and
   fills the checklist in `change-control.md`.
3. Approver reads the release note and the `settings_diff`, checks the test count and the checklist, and signs:
   for parameter and limit changes with `econquest change approve <id> --approver NAME` (single-operator mode:
   `--self-approved --exc EXC-001`, see the issues log), then `econquest change apply <id>`. The output of
   `econquest change show <id>` is filed with the release note as the sign-off evidence.
   For Tier 1 parameter changes the approver also checks that the sensitivity table in the validation document
   was recomputed (20,000 paths, `settings.copy_with`), not inferred.
4. Validator (when in place) countersigns Tier 1 changes and any change that lifts a use restriction. Without a
   validator the release goes ahead marked "independent review pending" and the item stays open in the issues log.
5. Release: `publish` to the workbook, zip rebuilt, `python -m econquest governance` regenerates `change-log.md`,
   release note filed.

Emergency changes (a bug that produces a wrong reported number, a feed failure that blocks the morning job) may
be released by the owner alone with the approver informed the same day; the normal path is completed within five
working days and the emergency is logged as an exception (section 7).

## 6. Use restrictions in force

| # | Restriction | Reason | Lifted when |
|---|---|---|---|
| 6.1 | No default PD, VaR, ES or L-VaR figure is quoted to a client, counterparty, investor or regulator as a model output. Internal use is allowed with the words "paper-mode parameters, seed inputs" attached | `layer1.mode` is `paper_standardized` (coefficients are the paper's illustrations); 110 Inputs cells have no live value and 1,270 of 1,494 are not live (`data-pipeline.md`: 15% live coverage); layers 2 to 6 parameters are judgement | Layer 1 fitted on the full panel and `fit-hazard --apply` clears its gate; live coverage of the indicators that drive the PDs (spreads, reserves, FX, pillar 4 levels); independent validation signed |
| 6.2 | No prediction-market stake, edge or divergence flag is acted on or shown as live | `data/prediction_markets.csv` prices are illustrative placeholders (no `slug`/`ticker`, README section "Data"); outputs change with the run date | Live prices through `--live-markets` with contract mapping, and GOV-012 closed |
| 6.3 | The 120-month backtest (Kupiec p 0.043, Z2 -2.66, Basel Yellow, verdict Fail) is not cited as evidence for or against the model | `data/backtest_history.csv` is synthetic, drawn from the model itself | Real P&L history (roadmap 2.1) or the forecast record reaching 250 trading days |
| 6.4 | The forecast record verdict (Pass, 1 exceedance in 60 days, Basel Green) is reported with its sample size and marked "underpowered" | 60 backfilled rows with the current book; Kupiec cannot reject at n = 60 below 3 exceedances; 13 of 24 positions marked, Eurobonds and CDS not marked | 250 daily rows taken with the book of the day |
| 6.5 | Signals, conviction and trade sizes are decision support, not instructions; no position is opened on a signal alone | No signal has been tested against outcomes; conviction reflects signal construction; signal 17 dead, signal 25 on placeholders | Signal values archived per run and hit rates computed over at least four quarters |
| 6.6 | Stress scenario A is reported with the note that it is about three times the paper's figure | ES99 +61.2% vs paper +18.4% on 0.1.4 (release note 0.1.4-2026-10-23; replicate R10, D14; +80% before 0.1.4); most of the effect is the global regime flip | Scenario sizes become parameters and the scenario library (roadmap 3.4) is validated |
| 6.7 | CDS-implied PDs, model-fair spreads and relative-value reads are not produced | `data/cds_quotes.csv` has 0 rows; no validation document | Licensed or analyst-maintained quotes with a `source` per row and a validation document |
| 6.8 | Limit verdicts from `econquest limits --propose` are advisory; a refused trade may still be done with the approver's written exception | Limits are owner-set judgement values with no approver signature; the pre-trade check runs at 20,000 paths | Limits signed by an approver other than the owner (GOV-041) |
| 6.9 | GARCH-DCC one-day VaR covers FX and equity legs only and is labelled as such in the forecast record and report | Eurobonds, CDS and local-rate duration are not marked | Daily prices for the credit instruments (roadmap 1.3) |

## 7. Exception handling

- An exception is any use of a model output against a restriction in section 6, any release that skipped a
  checklist line, any force-applied held cell, any trade done against a limit verdict, and any emergency release.
- Exceptions are recorded in `issues-log.md` with id prefix `EXC-`, the date, who approved, what was done and the
  compensating control (for example "position capped at the warning level of 80 percent until the next run").
- An exception expires after one quarter unless renewed at the quarterly revalidation.
- Three exceptions of the same kind in a quarter are a finding: the restriction, the limit or the procedure is
  reviewed and either changed through the normal path or enforced in code (for example the GUI refusing a
  `--force` without a decision text).
- Quality-gate holds (`data/live/review.csv`, status `hold`) are not exceptions while the seed value is kept; they
  become one when applied with `fetch --force` and no decision text. Today two cells are held (Nigeria exports,
  Venezuela reserves) with decisions recorded.

## 8. Records

| Record | Where | Retention |
|---|---|---|
| Run archive (settings, provenance, summary, country and position tables, paths for base runs) | `outputs/store/econquest.sqlite`, `outputs/store/archive/<run_id>.json`, `<run_id>_paths.npz` | Indefinite; backed up with the vintages (roadmap 4.6) |
| Data vintages | `data/live/vintages/<date>/` | Indefinite |
| Audit trail | `data/audit_trail.csv`, Audit Trail tab | Regenerated each release; vintages hold history |
| Forecast record, benchmarks | `data/forecast_record.csv`, `data/benchmarks.csv` | Indefinite; append-only (same-day rows replaced) |
| Reports and alerts | `outputs/reports/risk-report-<date>.html`, `outputs/alerts.json` | One year |
| Release notes and signed checklists | `docs/governance/releases/<version>-<date>.md` (to be created at the first release under this policy) | Indefinite |
| Workbook formula backup | Drive: "Geopolitical-Macro Risk Desk (formula backup 2026-10-20)" | Indefinite |

## 9. Review of this policy

Yearly by the approver and validator, or when a tier definition, a role or a use restriction changes. The policy
version is this file's date line; changes are listed at the end of the file.

Changes: 2026-10-23 first version.
