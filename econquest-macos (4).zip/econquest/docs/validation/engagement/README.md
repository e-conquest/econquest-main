# Validator engagement pack

Date: 2026-10-24. Ticket EQ-B-0060 (GOV-042, roadmap 4.5). Prepared by Team B for the model owner to send to
candidate independent validators. The pack names no firm and quotes no fees; the owner chooses the firm.

| File | Purpose | Send to candidates? |
|---|---|---|
| [scope.md](scope.md) | What the model is and how it is used; inventory by tier; what is in and out of scope; the validation standard; deliverables; available evidence and its quality (synthetic, placeholder, judgement) | Yes, with the RFP |
| [questions.md](questions.md) | 25 questions from the open GOV and VF findings and use restrictions 6.1 to 6.9, each with the file to start from | Yes, with the RFP |
| [timeline.md](timeline.md) | Two-stage plan with phase durations, dependencies, calendar-gated tests (2027) and what the owner must provide | Yes, with the RFP |
| [rfp.md](rfp.md) | Request-for-proposal text with placeholders `[DATE]`, `[NAME/EMAIL]`, `[ORGANISATION]`, `[PERIOD]`, `[WEIGHT]` | Yes: it is the cover document |

**Before sending, the owner should:**

1. Fill in the placeholders in `rfp.md`, including the evaluation weights and the cooling-off period.
2. Confirm that the third-party data in the snapshot may be shared under NDA. This was not checked for this pack.
3. Decide whether the validator will also act as approver of record (policy section 3).

**The validator's starting point after the NDA:**

- `docs/validation/dossier/README.md`;
- `docs/validation/README.md`, which holds the 11-step review checklist;
- `python -m econquest.validation.replicate --data data --out <dir>`.

**Freshness.** Figures are as of releases 0.1.1 to 0.1.5 (2026-10-23). If a release is made before the data room
opens, refresh `scope.md` section 1, and the findings register status of VF-009 and VF-010.
