# Request for proposal: independent validation of a sovereign risk model

Ready-to-send text. Before sending, replace each bracketed placeholder ([NAME/EMAIL], [DATE], [ORGANISATION]).
Attach `scope.md`, `questions.md` and `timeline.md` from this folder. Do not send any model files before an NDA
is signed.

---

**From:** [ORGANISATION], [NAME/EMAIL]
**Date issued:** [DATE]
**Clarification questions by:** [DATE]
**Proposals due:** [DATE]

## 1. Background

[ORGANISATION] runs an in-house sovereign tail-risk model, "econquest". The model is written in Python. It
produces 12-month sovereign default probabilities and, for a book of sovereign exposures, VaR, expected
shortfall, liquidity-adjusted VaR, stress results and limit verdicts. These exposures are Eurobonds, local bonds,
CDS, FX and equity ETFs across 18 countries.

The model is documented to an SR 11-7 style standard:

- a model inventory with three tiers;
- a model risk policy with nine use restrictions in force;
- one validation document per component;
- an issues log;
- a validation dossier with a findings register;
- a replication script that recomputes the published figures from the code and stored inputs.

The model has not been reviewed by anyone independent of its author. We are seeking that review.

## 2. Scope

The scope is set out in the attached `scope.md`:

- **Full validation** of the eight Tier 1 components and three Tier 2 components: regimes, stress, and GARCH/DCC.
- **Design and monitoring review** of the remaining Tier 2 components.
- **Review of the controls:** versioning, change control, the data quality gate and the revalidation routine.

The work should cover conceptual soundness, ongoing monitoring and outcomes analysis. Some outcomes tests
cannot be performed before Q4 2027. We ask for a two-stage proposal: Stage 1 now, and a Stage 2 follow-up in
Q4 2027 (see the attached `timeline.md`). The specific questions we want answered are in `questions.md`.

## 3. Deliverables

1. A validation report covering each in-scope component.
2. Findings graded by severity, with evidence and recommended remediation. These should include a disposition
   (accepted, rejected or re-graded) for each row of our findings register.
3. An opinion on each of our nine use restrictions: whether it can be lifted or narrowed, or must stay.
4. A short opinion on tier assignments.
5. A scope and plan for the Stage 2 follow-up.

## 4. Independence and conflicts

The proposer must confirm in writing that:

- no person on the engagement has developed, advised on or been paid for any part of this model, its data or its
  parameters;
- the firm, or the individual, has no commercial interest in the outcome. For example, it does not sell a
  competing model or data product to [ORGANISATION] that the findings could favour. If such an interest exists,
  it must be disclosed with the proposed safeguard;
- any current or past relationship with [ORGANISATION] is disclosed;
- the proposer will not take on remediation or model-development work on the same model during the engagement,
  or for [PERIOD] after it, without written agreement.

## 5. Data handling and confidentiality

- Model files are shared only after a mutual NDA is signed.
- Access is a read-only snapshot with a hash manifest. The proposer runs the code in its own environment and
  states where that environment is and who can access it.
- The portfolio file and run archive are confidential. Third-party data in the snapshot is shared only to the
  extent its licence allows, and may not be reused outside the engagement.
- At the end of the engagement, all copies are returned or destroyed and destruction is confirmed in writing.
  Working papers may be retained for professional record-keeping as stated in the proposal.
- No model output may be cited outside the engagement. Our use restriction 6.1 applies to the validator as well.

## 6. Proposal format

Please keep the proposal to 10 pages or fewer, excluding CVs. It should contain:

1. Understanding of the scope, and any proposed changes to it.
2. Approach and the validation standard to be applied, with how severity is graded.
3. Team: names, roles, relevant sovereign credit, market risk and model validation experience, and time
   allocation.
4. Work plan with phases and durations for Stage 1, and an outline for Stage 2.
5. What the proposer needs from us, beyond `timeline.md`.
6. Independence and conflict confirmations (section 4).
7. Data security arrangements (section 5).
8. Fees: fixed or capped for Stage 1, an estimate for Stage 2, expenses policy and payment terms.
9. Two references from comparable engagements, if the clients consent.

## 7. Evaluation criteria

| Criterion | Weight |
|---|---|
| Relevant expertise: sovereign credit risk, Monte Carlo market risk, model validation | [WEIGHT] |
| Quality and realism of approach and work plan | [WEIGHT] |
| Independence and conflict position | [WEIGHT] |
| Data security arrangements | [WEIGHT] |
| Fees and value | [WEIGHT] |

[ORGANISATION] may ask shortlisted proposers to present. It is not obliged to accept any proposal.

## 8. Questions and contact

Send clarification questions in writing to [NAME/EMAIL] by [DATE]. Answers to questions of general interest will
be shared with all proposers without naming who asked.
