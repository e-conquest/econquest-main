# Independent validation of econquest: scope

Date: 2026-10-24. Ticket EQ-B-0060 (GOV-042, roadmap 4.5). Prepared by Team B (model team) for the model owner
to share with candidate validators. Facts are taken from the repository on this date. Anything not checked for
this pack is marked **[unverified]**.

## 1. The model and its use

econquest is a sovereign tail-risk and geopolitical risk engine written in Python (about 31,000 lines in the
`econquest` package). It scores 18 countries and simulates a 24-position, 309 $mm notional book of sovereign
exposures: Eurobonds, local bonds, CDS, FX and equity ETFs. The main outputs are:

- a 12-month default probability (PD) per country;
- portfolio VaR, ES and liquidity-adjusted VaR (L-VaR) at 95/99 percent, expected loss, and contributions;
- stress and reverse-stress results;
- limit verdicts and a pre-trade check;
- regimes, signals and trade ideas, and alerts.

Results are published to a Google Sheets workbook, which is a view only. Every reported number must reproduce
from a run id, with code, data and settings hashes stamped in the run archive (`model-risk-policy.md` section 1).

**Use today.** The model is used internally by a one-person desk. The model owner (Sam) is also the acting
approver. Use restrictions 6.1 to 6.9 in `docs/governance/model-risk-policy.md` are in force. In particular, no
PD, VaR, ES or L-VaR is quoted externally (6.1). The validation is wanted so that the owner can decide which
restrictions can be lifted, and so that sign-offs no longer read "owner-approved, independent review pending"
(policy principle 4, GOV-042).

**Releases in scope.** All five releases are dated 2026-10-23. The release notes are in
`docs/governance/releases/`.

| Release | Main change | Tests at release |
|---|---|---|
| 0.1.1 | Sobol path block 2^17, `as_of` fixed per run, signal 15/19 formula | 322 passed |
| 0.1.2 | Package and platform batch (see `0.1.2-…-package.md`; no model note) | 659 passed, 2 skipped |
| 0.1.3 | Layer 2 risk-premium ratio 2.0, no FX term for pegs (Tier 1, `CHG-20261023T163209Z-b3f8bd`) | 660 passed, 2 skipped |
| 0.1.4 | GARCH 12-month vols in the Monte Carlo, estimated copula loadings (Tier 1, `CHG-20261023T190523Z-b96d25`) | 1,184 passed, 5 skipped |
| 0.1.5 | Rate shocks in FED22/TAPER13 (Tier 2); off-by-default options; validation pack part 1 | 1,637 passed, 5 skipped |

The 0.1.5 base run (`20261023T225023-base`, as_of 2026-10-23, 131,072 Sobol paths) gives these figures: VaR99
73.11, ES99 95.41, EL 0.46 and L-VaR99 78.39 $mm. The Monte Carlo SE is 0.31 for VaR99 and 0.36 for ES99. The
figures are internal and synthetic-input-dependent; see section 5.

## 2. Model inventory by tier

The tiers are defined in `model-risk-policy.md` section 2. The component rows are in
`docs/governance/model-inventory.md`.

| Tier | Components | In scope |
|---|---|---|
| **1**: sets a reported or limit-tested number | 1 Scorecard; 2 Layer 1 hazard; 3 Layer 2 Bayesian update and market prior; 5 Layer 4 severity; 6 Layer 5 copula; 7 Layer 6 Monte Carlo; 8 L-VaR; 14 Limits and pre-trade check | **Full**: conceptual soundness, implementation, outcomes analysis where data allow, use-restriction opinion |
| **2**: conditions a Tier 1 number or a decision | 4 Layer 3 regimes; 9 Stress and reverse stress; 10 GARCH/DCC; 12 CDS pricer; 13 PD benchmarks; 15 Alerts; 16 Signals, trade activation, GPR uplift | **Full** for 4, 9 and 10. 10 should be assessed as Tier 1: since 0.1.4 it sets the Monte Carlo vols (VF-001, tier decision pending). **Design and monitoring only** for 13, 15 and 16. **Design review only** for 12, which is dormant because `data/cds_quotes.csv` has 0 rows |
| **3**: research or illustration | 11 Econometrics toolkit; Kelly stakes; HMM demo | Out of scope, except toolkit Table 8 (copula family choice), which is the data support for layer 5 |

**Also in scope:**

- **Controls:** the run archive and versioning (`econquest/versioning.py`); change control (`econquest change`, `docs/governance/change-control.md`); the data quality gate; the revalidation routine (`docs/governance/revalidation-routine.md`).
- **The two backtest tools** (`econquest/validation/backtests.py`, `validation/record.py`): implementation only (see section 5).

**Out of scope:**

- the Google Sheets workbook formulas (a view);
- the GUI and report rendering;
- installer and operations scripts;
- data-feed connectivity. The cloud build cannot reach IMF, World Bank, BIS or ECB; live fetches run on the owner's machine.

**Off by default.** Options that are built but switched off are in scope as design only, unless the owner asks
for an opinion on adopting one:

- fitted layer 1 (`layer1.mode` fitted);
- HMM regimes;
- the logistic global switch;
- fitted LGD;
- BIS contagion;
- the event stress index;
- bond RV;
- CDS curves.

## 3. Validation standard

The standard is US SR 11-7 / OCC 2011-12 or an equivalent the validator proposes, such as UK PRA SS1/23
principles. The validator should state which standard applies. The three elements are:

1. **Conceptual soundness.** Is the model form fit for purpose? Are the assumptions and judgement values
   reasonable? Are the data adequate? Are the limitations disclosed?
2. **Ongoing monitoring.** Do the revalidation routine, thresholds, alerts, change control and versioning
   detect a model that has stopped working? Process verification includes reproducing the reported numbers from
   the code.
3. **Outcomes analysis.** Backtests, benchmarking against rating-, spread- and market-implied PDs, and the
   forecast record. Some of this cannot be performed before 2027 (`timeline.md`). The validator should say what
   can be concluded now and what must wait.

## 4. Deliverables requested

1. **A validation report** covering each in-scope component, with the validator's assessment under each of the
   three elements.
2. **Findings by severity,** with evidence and a recommended remediation for each. A finding is either:
   - one of the 56 rows in `docs/validation/dossier/findings-register.csv`, marked accepted, rejected or
     re-graded; or
   - a new finding.

   The model team's own scale is High, Medium or Low, as defined in `docs/governance/issues-log.md`. The
   validator may use its own scale if it maps it to that one.
3. **A use-restriction opinion.** For each of restrictions 6.1 to 6.9, the validator should say whether it can
   be lifted, narrowed or must stay, and on what conditions.
4. **A tiering opinion,** which can be short: whether the tier assignments in the inventory are right (in
   particular VF-001).
5. **Re-validation scope** for the calendar-gated outcomes tests in 2027.

## 5. Evidence available, and its quality

| Evidence | Where | Note |
|---|---|---|
| Validation documents (one per component, common ten-heading template, 11-step review checklist) | `docs/validation/*.md`, `docs/validation/README.md` | Written by the model team |
| Validation dossier part 1 (one file per layer, with "independent validator should re-perform" steps) | `docs/validation/dossier/` | Written by the model team (EQ-B-0051). It describes the 0.1.4 state; 0.1.5 changed two stress scenarios and added off-by-default options |
| Findings register: 56 rows (GOV issues bearing on a layer, plus VF-001 to VF-010) | `docs/validation/dossier/findings-register.csv` | Some VF status cells predate 0.1.5. For example, VF-009 and VF-010 read Open, but the 0.1.5 note says EQ-B-0047 addressed both. To be confirmed **[unverified]** |
| Issues log and exceptions (GOV-001 to GOV-046, EXC-001) | `docs/governance/issues-log.md` | |
| Replication script: recomputes every number in the 0.1.4 note and the key numbers in the validation documents from public functions and stored inputs, without reading archived runs | `econquest/validation/replicate.py`; `python -m econquest.validation.replicate --data data --out <dir>` | 121 checks. The 0.1.5 note reports 121 PASS, 0 STALE, 0 FAIL and 2 INFO (hashes, VF-003). Not rerun for this pack **[unverified today]** |
| Test suite | `tests/` (121 files) | 1,637 passed and 5 skipped at 0.1.5; 1,699 tests collected on 2026-10-24 |
| Run archive, change records, approvals chain | `outputs/store/`, `data/approvals/log.jsonl`, `docs/governance/change-log.md` | |
| Frozen release inputs | `docs/governance/releases/inputs/0.1.4/` | No per-release code snapshot (VF-003) |

**Synthetic, placeholder or judgement inputs.** The validator should not treat these as evidence:

- **Synthetic:**
  - the 120-month backtest history `data/backtest_history.csv` is drawn from the model itself (GOV-028, restriction 6.3);
  - the HMM recovery test is synthetic (GOV-019);
  - the CDS curve fixtures are synthetic (EQ-B-0048).
- **Placeholder:** all 18 prediction-market prices (GOV-016, restriction 6.2).
- **Seed estimates:**
  - about 85 percent of indicator cells: 224 of 1,494 input cells are live (GOV-010, GOV-036);
  - spreads, ratings and several regime inputs are hand-entered.
- **Compiled from memory:** the sovereign default list `data/panel/sovereign_defaults.csv` (±1 year, GOV-044). It labels both the hazard panel and the benchmark outcomes.
- **Judgement:**
  - layer 1 coefficients (paper-mode; the pilot fit did not clear its gate, GOV-006);
  - the layer 2 weights and the risk-premium ratio 2.0 (GOV-013);
  - the regime rules and transition matrix (GOV-018, GOV-019);
  - the LGD means and dispersion (GOV-024);
  - the copula tail df and regime steps (GOV-021);
  - the stress sizes (GOV-026);
  - the limits (GOV-041).
- **Underpowered:** the forecast record has 60 backfilled rows (GOV-029, restriction 6.4).
- **Fitted on real data:** only GARCH/DCC, the econometrics toolkit and, since 0.1.4, the Calm copula loadings. All of these use three years of daily prices.
