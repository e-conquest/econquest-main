# Questions for the validator

Date: 2026-10-24. Ticket EQ-B-0060. These are the questions the model team most wants an independent answer to.
They are drawn from the open GOV issues (`docs/governance/issues-log.md`), the VF findings
(`docs/validation/dossier/findings-register.csv`) and the use restrictions in `docs/governance/model-risk-policy.md`
section 6. Each question names a file to start from. Paths are relative to the repository root.

## A. Use restrictions (the opinion the owner needs most)

| # | Question | Links | Start from |
|---|---|---|---|
| A1 | What would have to be true for any PD, VaR, ES or L-VaR to be quoted outside the desk? Is the lifting condition in 6.1 the right one, and is it sufficient? | 6.1, GOV-006, GOV-010, GOV-036 | `docs/governance/model-risk-policy.md` §6 |
| A2 | Can 6.4 (forecast record "underpowered") and 6.9 (GARCH VaR covers FX and equity only) be reworded so that the record is usable as monitoring evidence before 250 rows exist? | 6.4, 6.9, GOV-029 | `docs/validation/backtests-and-forecast-record.md` |
| A3 | Is the advisory status of limit verdicts (6.8) adequate while limits carry only the owner's signature? What minimum approver arrangement would the validator accept? | 6.8, GOV-041, EXC-001 | `data/limits.json`, `docs/governance/change-control.md` |
| A4 | Are restrictions 6.2, 6.3, 6.5, 6.6 and 6.7 correctly scoped? Is any missing, for example a restriction on stress results in general rather than scenario A alone? | 6.2-6.7 | `model-risk-policy.md` §6 |

## B. PD chain (Tier 1)

| # | Question | Links | Start from |
|---|---|---|---|
| B1 | Is a hazard model on paper coefficients with location and scale fitted to rating PDs a defensible interim PD? Is the `fit-hazard --apply` gate the right bar for switching to fitted mode? The gate is OOS AUC >= 0.75, >= 30 events, and Brier below the base rate. The code (`hazard_panel.GATE_MIN_AUC`) and the policy both use 0.75, but `model-inventory.md` row 2 still says 0.70, which is a documentation inconsistency | GOV-006, VF-005 | `docs/validation/dossier/layer1-hazard.md`, `docs/validation/hazard-fit-report.md` |
| B2 | Is the 50/50 log-odds blend of hazard and rating-implied PD (`hazard_weight 0.5`) supported? The rating table has no vintage, and SD/D at 0.60 is judgement | GOV-007 | `docs/validation/hazard-layer1.md`, `data/assumptions.json` |
| B3 | Check the commodity-gap inputs for Senegal and Zimbabwe (`commgap 60`, -2.3 log-odds) | GOV-008 | `docs/validation/dossier/layer1-hazard.md` step 4 |
| B4 | Layer 2: is the market term (`w_m 0.5`) with a single literature-based risk-premium ratio of 2.0 reasonable, given hand-entered spreads? How should it be calibrated once benchmark scoring is possible? | GOV-013, GOV-015 | `docs/validation/dossier/layer2-bayesian.md`, release note 0.1.3 |
| B5 | Scorecard: with about 85 percent seed inputs and thresholds not calibrated to outcomes, what weight should the composite carry in the PD (`w_s 0.04` per point)? | GOV-010, GOV-011, GOV-036 | `docs/validation/dossier/scorecard.md`, `docs/validation/data-pipeline.md` |
| B6 | Is the default-episode list fit to label both the hazard panel and the benchmark outcomes until it is replaced with the CRAG workbook? | GOV-044 | `data/panel/README.md`, `data/panel/sovereign_defaults.csv` |

## C. Loss distribution (Tier 1)

| # | Question | Links | Start from |
|---|---|---|---|
| C1 | Default risk is under 20 percent of ES99, so the tail is mainly market volatility. Is that a fair representation of a sovereign credit book, or a model artefact? | GOV-020, GOV-023 | `docs/validation/dossier/layer6-montecarlo.md` |
| C2 | Copula: the Calm loadings are estimated from weekly returns, and the tail df and regime steps are judgement. Is the family choice (Student-t, supported by toolkit Table 8) and its parameterisation adequate? Do loadings fitted on dollar and equity co-movement stand in acceptably for credit links? | GOV-021 | `docs/validation/dossier/layer5-copula.md`, `docs/validation/econometrics-toolkit.md` |
| C3 | Severity: are the fixed LGD means, `lgd_sd 0.15` for every class and the 0.95 cap acceptable before a fit to restructuring haircut data? | GOV-024, GOV-025 | `docs/validation/dossier/layer4-severity.md` |
| C4 | Is a deterministic, additive liquidity cost acceptable for L-VaR? | GOV-022 | `docs/validation/copula-montecarlo-layers5-6.md` §6.3 |
| C5 | Monte Carlo error: are batch-means SEs on scrambled Sobol (conservative versus the 16-seed sd) adequate, and should limit verdicts take the SE into account? | VF-004 (resolved), GOV-041 | `docs/validation/copula-montecarlo-layers5-6.md` |
| C6 | Should GARCH/DCC move to Tier 1 now that its vols drive the Monte Carlo? Are three years of data with no parameter standard errors sufficient for that role? | VF-001, GOV-034 | `docs/validation/garch-dcc.md`, `docs/governance/model-inventory.md` row 10 |

## D. Regimes and stress (Tier 2)

| # | Question | Links | Start from |
|---|---|---|---|
| D1 | The global regime switch is a cliff (VaR99 moves about 13 percent at `global_stress_share 0.4` with no PD change). Should the built logistic option be adopted? | GOV-018 | `docs/validation/dossier/layer3-regimes.md` |
| D2 | Is the paper transition matrix, not estimated and not rescaled to horizon, acceptable? What data would an HMM fit need to be credible? | GOV-019 | `docs/validation/regime-layer3.md` |
| D3 | Scenario A is about three times the paper's figure, and the FED22 and TAPER13 rate shocks are first-order in duration only. Are the scenario library and its sizes plausible, and is reverse stress adequate? | GOV-026, GOV-027, 6.6 | `docs/validation/dossier/stress.md`, `data/scenarios.json`, release note 0.1.5 |

## E. Controls, data and reproducibility

| # | Question | Links | Start from |
|---|---|---|---|
| E1 | Is reproducibility adequate with no version control and no per-release code snapshot? Does the release hash manifest close the gap? | VF-003, GOV-038 | `econquest/validation/replicate.py`, `econquest/versioning.py` |
| E2 | Is the data quality gate (live compared with seed, not with the previous vintage) and single-operator self-approval (EXC-001) an acceptable control? | GOV-037, GOV-039, EXC-001 | `docs/validation/data-pipeline.md`, `docs/governance/issues-log.md` |
| E3 | Do the revalidation routine's thresholds and frequencies amount to adequate ongoing monitoring for a one-person desk? | — | `docs/governance/revalidation-routine.md` |
| E4 | Is test coverage adequate for layer 3, which has no module-named test file? | VF-008 | `tests/test_panoptix.py`, `tests/test_regime_hmm.py` |
| E5 | Before CDS quotes are used, what should the validation document for the CDS pricer contain? | GOV-040, 6.7 | `econquest/engine/cds.py`, `tests/test_cds.py` |

## F. Signals (Tier 2, design only)

| # | Question | Links | Start from |
|---|---|---|---|
| F1 | What monitoring is needed before signals and conviction can be cited as more than decision support? This covers hit rates over four quarters, the dead signal 17, and GPR coverage of 11 of 18 countries | GOV-031, GOV-033, 6.5 | `docs/validation/dossier/signals.md` |
