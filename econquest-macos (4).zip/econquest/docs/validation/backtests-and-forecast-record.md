# Model validation: backtests and the daily forecast record

Date: 2026-10-23. Code: `econquest/validation/backtests.py` (`kupiec`, `christoffersen`,
`acerbi_szekely_z2`, `brier_score`, `basel_zone`, `backtest_history`, `synthetic_history`) and
`econquest/validation/record.py` (`book_weights`, `realised_loss`, `append_record`, `take_record`,
`backfill_record`, `_portfolio_var`, `record_for_backtest`). Data: `data/backtest_history.csv` (120
monthly rows), `data/forecast_record.csv` (60 daily rows). Status: the tests are standard and
verified against the workbook; the 120-month history is synthetic; the 60-day record is real marks
against Google Finance prices but far too short to conclude anything.

## Purpose

To check whether the risk forecasts are right often enough: the VaR exceedance frequency (Kupiec
unconditional coverage), the clustering of exceedances (Christoffersen independence and conditional
coverage), the size of losses beyond VaR relative to ES (Acerbi-Szekely Z2), the Basel traffic-light
zone, and a Brier score for probability forecasts. The forecast record is the mechanism that
accumulates the forecast-versus-outcome history the tests need.

## Where it sits in the pipeline

`econquest run --backtest` reads `backtest_history.csv` if present, otherwise draws a
`synthetic_history` from the current simulation, and runs `backtest_history(hist, alpha=0.99)`;
results go to `outputs/backtest.json`, the dashboard and the workbook's Backtesting tab. `econquest
backtest --history FILE` runs the tests on any file with `loss, var, es` columns, including the
forecast record once it has 20 rows. `econquest record` marks the book for the last complete trading
day, fits GARCH-DCC for the next day's VaR/ES, optionally runs the 12-month Monte Carlo, and appends
a row; `--backfill N --step 21` builds the record backwards with GARCH-DCC refitted every 21 trading
days on data to that date only.

## Assumptions

1. Kupiec: exceedance indicator `loss > var`, likelihood ratio `LR_uc = -2 [ln((1-p)^(n-x) p^x) -
   ln((1-x/n)^(n-x) (x/n)^x)]` with `p = 1 - alpha`, chi-square with one degree of freedom; the x =
   0 and x = n limits are handled.
2. Christoffersen: first-order Markov transition counts `n00, n01, n10, n11`; `LR_ind` compares the
   two-state transition likelihood to the independent one, chi-square(1); `LR_cc = LR_uc + LR_ind`,
   chi-square(2).
3. Acerbi-Szekely Z2 = `1 - sum(loss_t 1[loss_t > var_t] / es_t) / (n (1 - alpha))`; critical value
   -0.7 (the test's approximate 5 percent level for alpha 0.99 with Student-t P&L); pass if Z2 above
   -0.7.
4. Basel zone: cumulative binomial probability of the observed exceedance count at `1 - alpha`;
   Green below 0.95, Yellow below 0.9999, Red otherwise. This reproduces the 250-day Basel table
   (Green up to 4, Yellow 5 to 9, Red from 10) and scales it to other sample sizes.
5. Verdict: Pass if Kupiec p at least 0.05, conditional coverage p at least 0.05 and Z2 passes.
6. Brier score: mean squared difference between probabilities and 0/1 outcomes; implemented but not
   called anywhere in the pipeline.
7. Forecast record: loss on day T = sum over markable positions of `w x log(P_T / P_{T-1})`, with `w
   = notional x direction sign x loss sign` (FX and local bonds via `USD<ccy>`: long local loses
   when the quote rises; equity via the ETF: long loses when the price falls). Eurobonds and CDS are
   not marked. `var` and `es` for day T are the `var_next`, `es_next` recorded on the previous
   trading day. The last complete date is the last day on which at least 60 percent of series have a
   price.
8. Synthetic history: monthly losses drawn with replacement from the simulated 12-month loss
   distribution and scaled by `sqrt(1/12)`, with a constant VaR and ES scaled the same way (`seed
   11`).

## Data

- `backtest_history.csv`: 120 monthly rows from 2016-11 to 2026-10, constant `var 17.12` and `es
  22.19` (the 12-month VaR99 59.3 and ES99 76.9 of the workbook scaled by `sqrt(1/12)`), losses
  drawn from the simulation. It is the workbook's sample history and it is synthetic; the README
  says so ("sample history") and the roadmap item 2.1 says `backtest_history.csv` must become real.
- `forecast_record.csv`: 60 rows, 2026-07-30 to 2026-10-21, all written by `--backfill` on
  2026-10-23 (recorded_at prefixed "backfill"); 13 positions marked, 210 $mm; `var99_12m`,
  `es99_12m` and `regime` empty because the backfill does not run the Monte Carlo; code hash
  `e0b04d4556d4071b` and data hash `f0fb8c56f52e64f3` on every row.
- Prices: `data/market_history/prices.csv`, Google Finance daily closes to 2026-10-22.

## Estimation or calibration

The tests have no parameters beyond `alpha` and the Z2 critical value. The forecast record's VaR
comes from the GARCH-DCC layer (`garch-dcc.md`). The backfill refits every 21 days on data up to the
fit date and filters the variance forward through later returns, so there is no look-ahead in the
variance path; the DCC correlation is `R_next` from the fit date and is held fixed for the following
21 days (a simplification of the DCC recursion).

## Outputs and how they are used

Sample history (120 months, alpha 0.99), computed in this validation and identical to
`outputs/backtest.json` and the workbook's Backtesting tab: 4 exceedances against 1.2 expected;
Kupiec `LR_uc 4.098`, p 0.043 (fail); Christoffersen `n00 111, n01 4, n10 4, n11 0`, `LR_ind 0.278`,
p 0.598, `LR_cc 4.377`, p 0.112 (pass); Z2 -2.659 (fail; the average exceedance was 1.10 times ES);
Basel Yellow; verdict Fail.

Forecast record (60 days, alpha 0.99), computed in this validation: 1 exceedance against 0.6
expected (2026-07-31 is the first testable day); Kupiec `LR_uc 0.224`, p 0.636; Christoffersen
`LR_cc 0.259`, p 0.879; Z2 -0.269 (pass; the exceedance was 0.76 times ES); Basel Green; verdict
Pass. Mean one-day VaR99 1.72 $mm against a mean absolute daily loss of 0.56 $mm and a largest loss
of 1.56 $mm.

Uses: the dashboard's backtest panel, the Backtesting and Forecast Record tabs, and the governance
verdict in `outputs/backtest.json`.

## Limitations and known gaps

- The 120-month history is drawn from the model being tested. It tests the arithmetic of the tests,
  not the model: the four exceedances say that the 12-month loss distribution, resampled monthly and
  scaled by `sqrt(1/12)`, is heavier than a constant monthly VaR built from the same numbers would
  admit. The "Fail" verdict in the README should not be read as evidence about real losses.
- Sixty daily observations have almost no power. With n = 60 the Kupiec test cannot reject at 5
  percent unless there are 3 or more exceedances (p for 2 exceedances is 0.15), and the Basel
  scaling puts 2 exceedances in Yellow. At n = 250, 5 exceedances are Yellow and 10 are Red; the
  roadmap's "meaningful from 250 days" is right.
- The record marks 13 of 24 positions (FX and local bonds as currency only, one equity). Eleven
  Eurobonds and the CDS, which carry the sovereign credit risk the first four layers model, are not
  marked, so the record tests the GARCH FX and equity VaR and nothing about default risk.
- Local bonds are marked as pure currency exposure; duration and local rates are ignored in both the
  loss and the forecast.
- All 60 rows are a backfill made on one day with the current book. The record therefore assumes the
  positions were held unchanged since July; a real record must be taken daily with the book of the
  day (roadmap 4.6: scheduled runs).
- The one-day VaR tested is at the 99 percent level with a Student-t quantile; ES is tested with Z2
  whose -0.7 critical value is approximate and depends on the distribution of P&L.
- The 12-month Monte Carlo VaR (`var99_12m`) is recorded but cannot be backtested at a daily
  frequency; a 12-month horizon needs years of non-overlapping observations.
- `brier_score` exists but no probability forecasts are recorded, so no PD backtest is possible
  (roadmap 2.6).
- The Christoffersen test with 4 exceedances in 120 periods has almost no power to detect clustering
  (`n11` is 0).

## Sensitivity

Test power at alpha 0.99, computed with `kupiec` and `basel_zone`:

| Sample n | Exceedances x | Kupiec p | Basel zone |
|---|---|---|---|
| 60 | 1 | 0.636 | Green |
| 60 | 2 | 0.152 | Yellow |
| 120 | 1 | 0.850 | Green |
| 120 | 2 | 0.503 | Green |
| 120 | 3 | 0.165 | Yellow |
| 120 | 4 | 0.043 | Yellow |
| 250 | 2 | 0.742 | Green |
| 250 | 4 | 0.380 | Green |
| 250 | 5 | 0.162 | Yellow |
| 250 | 10 | 0.0003 | Red |

Reading: the sample history's verdict turns on a single exceedance (3 would pass Kupiec at p 0.165,
4 fail at 0.043). The forecast record will not be able to reject anything until it has about 250
days, and even then only a doubling of the exceedance rate.

Sensitivity of the recorded VaR to the GARCH choices is in `garch-dcc.md`: the Student-t quantile is
14 percent above the Gaussian for the FX book, correlation choice (DCC, unconditional or zero) moves
the one-day VaR99 between 0.81 and 1.00 $mm, so a Gaussian zero-correlation VaR would have been
about 0.71 $mm and the 60-day record would then show more exceedances (the record was not recomputed
under those variants; this is inferred from the VaR ratio and the recorded losses, of which the
largest is 1.56 $mm and the second largest below 1.0 $mm).

## Benchmarks and evidence

- `test_backtests_match_workbook_sample` checks the sample-history statistics against the workbook
  (`LR_uc 4.098`, `LR_ind 0.278`, `LR_cc 4.377`, Z2 -2.659, verdict Fail); passes.
  `test_record_carries_forecast_forward`, `test_book_loss_sign_conventions` and
  `test_versions_change_with_data` cover the record mechanics.
- The 60-day record is the first real forecast-versus-outcome evidence in the program: one
  exceedance in 60 days of a 99 percent VaR, Z2 inside the acceptance region. It is consistent with
  the GARCH-DCC VaR being adequate for the currency and equity legs over a calm quarter, and with
  nothing else.
- Industry reference points: Basel's 250-day traffic light (Green 0 to 4, Yellow 5 to 9, Red 10 or
  more) is reproduced by `basel_zone`; the Acerbi-Szekely Z2 critical value of -0.7 is the value the
  authors report for their Z2 at 97.5 and 99 percent under Student-t assumptions; both are standard.
- No benchmark of the 12-month Monte Carlo VaR against realised 12-month losses exists and cannot
  exist for years.

## Open items for review

1. Replace `backtest_history.csv` with real P&L (roadmap 2.1) or stop publishing its verdict as if
   it were evidence; the dashboard and README present the Fail without stating that the history is
   synthetic.
2. Run `econquest record` daily on a server with the book of the day (roadmap 4.6), and keep
   `--backfill` for gap-filling only.
3. Mark Eurobonds and CDS (needs prices, roadmap 1.3) so the record covers the credit legs; until
   then label the record as "FX and equity legs only".
4. Add duration to the local-bond marks and to the GARCH book VaR.
5. Record probability forecasts (model PD, rating PD, market-implied PD, prediction-market PD)
   alongside the VaR rows so `brier_score` can be used (roadmap 2.6).
6. Store the DCC recursion state through the 21-day refit window instead of holding `R_next` fixed.
7. Report the Christoffersen test only once there are at least 10 exceedances; with fewer it adds
   nothing.
