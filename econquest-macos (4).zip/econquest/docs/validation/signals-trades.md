# Model validation: signals, trade activation and dashboard reads

Date: 2026-10-23. Code: `econquest/engine/signals.py` (`compute_signals`, `trade_activation`,
`dashboard_table`). Inputs: `data/playbook.csv` (26 strategies), scorecard, country table, GPR
block, arbitrage table. Parameters: `data/assumptions.json` key `signals`, plus
`probability.min_market_pd`, `probability.distress_pd` and `prediction_markets.min_net_edge_pp`. The
`signals` block holds `gpr_divergence_threshold 20`, `complacency_scale_log2 0.944` and
`unsized_stances ["Hedge"]` (the last two added by EQ-B-0008). Status: a port of the workbook's
Signals, Trade Activation and Dashboard formulas, except signals 15/19 and the sizing rule, which
EQ-B-0008 changed (see "Change record"); rule-based, no estimation; never backtested. Tier 2.

## Purpose

The signal layer converts scores and probabilities into 25 named signals on a 0 to 100 scale per
country, activates the Playbook's 26 trades when their signal rules are met and the instrument is
tradable in that country, and summarises each country for the Dashboard: top three risk signals,
trades firing, best trade and conviction, position size, GPR read and prediction-market read.

## Where it sits in the pipeline

After the Monte Carlo and the arbitrage scan: `signals = compute_signals(u, settings, sc, country,
gpr_country, gpr_global, arb)`, `activation = trade_activation(u, u.playbook, signals)`, `dash =
dashboard_table(...)`. Requires the GPR file and the playbook to be present. Outputs go to the
workbook's Signals, Trade Activation and Dashboard tabs, the GUI and `run_latest.json`.

## Assumptions

Signal definitions (`compute_signals`), with `s` indicator scores, `pf` final pillars, `threshold
60`:

| Key | Signal | Definition |
|---|---|---|
| 1 | Debt payment wall | max(s 1.1, s 1.2) |
| 2 | Fiscal stress | pillar 1 |
| 3 | External funding stress | pillar 2 |
| 4 | Devaluation pressure | mean(s 2.1, s 2.5, s 2.12) |
| 5 | Inflation pressure | s 5.5 |
| 6 | Growth slowdown | s 5.6 |
| 7 | Banking stress | mean(s 5.1, s 5.3, s 5.10) |
| 8 | Election event | max(60, s 4.5) if the election is within `election_window_months 12`, else s 4.5 / 2 |
| 9 | Political instability | pillar 4 |
| 10 | Expropriation and contract risk | pillar 3 |
| 11 | Security and violence | pillar 6 |
| 12 | Commodity dependence | s 2.11 for commodity exporters, else 0 |
| 13 | Climate and disaster | pillar 7 |
| 14 | Sanctions and geopolitics | max(s 2.7, s 4.10) |
| 15 | Market complacency | 50 + 50 tanh(log2(pd_default / pd_market) / `complacency_scale_log2 0.944`); 50 if pd_market below `min_market_pd 0.02` |
| 16 | Distress and restructuring | 100 if in default or rating PD at least `distress_pd 0.12`, else 0 |
| 17 | Deteriorating momentum | 50 + `momentum_scale 10` x (composite - prior composite); 0 if no prior |
| 18 | Official backstop stress | s 2.6 |
| 19 | Market overpricing risk | 100 - signal 15 |
| 20 | Benign carry | 100 - composite if Calm and real policy rate (5.13) at least `min_carry_real_rate 1.5`, else 0 |
| 21 | Low-risk calm market | 100 - composite if Calm, else 0 |
| 22 | Geopolitical risk spike (GPR) | country GPR signal (see `gpr-and-prediction-markets.md`) |
| 23 | Global geopolitical risk-off (GPR) | global GPR signal |
| 24 | GPR headline spike in a low-exposure calm market | signal 22 if Calm and signal 14 below 50, else 0 |
| 25 | Prediction market gap | 50 + best net edge x 10 / `min_net_edge_pp 10`, clipped; 0 if no contract |

Signal 15 is continuous and strictly increasing in the PD gap and stays inside (0, 100), so signal 19
= 100 - signal 15 never saturates. `complacency_scale_log2` = 0.4 / atanh(0.4) keeps the 70 and 30
crossings at a gap of 2^0.4 = 1.32x, exactly where the old linear-and-clipped form had them, so T16
and T17 (min_strength 70) activate at the same ratios. Reference points (signal 19 for market PD /
model PD): 1.32x 70, 2x 89.3, 2.4x 93.4, 4x 98.5, 10x 99.9. The old form reached 100 at 2x.

Trade activation (`trade_activation`): a trade fires in a country when its primary signal is at
least `min_strength`, its optional second condition holds (`key2`, `rule2` one of `<`, `<=`, `>`,
`>=`, `threshold2`; any other operator raises `ValueError` naming the trade before anything is
activated), and the instrument is tradable there (Country Profile columns CDS, Eurobond, FX, FX
options, Local rates, Equity; `Any` always tradable). The activated value is the primary signal
rounded.

Dashboard (`dashboard_table`): top three among signals 1 to 18 and 22 at or above 60; conviction is
the highest activated value over all firing trades; notional = `risk_budget_mm 10` x (highest
activated value among firing trades whose `stance` is not in `unsized_stances`, i.e. not a Hedge) /
100 x `regime_scalar` (Calm 1.0, Stressed 0.75, Crisis 0.5), and 0 when only hedges fire. Hedges
(T05, T11 to T14: option tail hedges, political risk insurance, violence and cat cover) are insurance
bought against the exposure, not positions sized against the risk budget, so a country's
`conviction` can exceed its sized value (Zimbabwe: conviction 90 from T11, notional 3.75 from a
sized trade at 75 x 0.5); GPR read compares the country GPR signal to the composite
with a 20-point divergence threshold; prediction-market read uses the best net edge against
`min_net_edge_pp`.

## Data

Scorecard and country table (see the earlier documents), the GPR monthly file (12 of 18 countries
covered), the playbook (26 strategies with their keys, thresholds, instruments and narrative
fields), the arbitrage table built from 18 placeholder contracts, and the tradability flags and
election timing in `countries.csv`. The `prior` column (previous composite) is empty, so signal 17
is 0 for every country.

## Estimation or calibration

None. Every threshold and scale was carried over from the workbook, and the README states that the
signals, trade activation and dashboard reproduce the workbook formulas exactly (with the exception
that signals 15 and 19 use the program's PDs).

## Outputs and how they are used

Base run, 2026-10-23, recounted from `compute_signals` / `trade_activation` / `dashboard_table` on the
shipped data after EQ-B-0008 (counts are independent of the Monte Carlo paths). Signals at or above
60, count of countries (117 in all): global GPR risk-off 18 (the global signal is 68 for all), debt
payment wall 10, prediction market gap 9, fiscal stress 7, expropriation and contract risk 7,
low-risk calm market 7, growth slowdown 6, country GPR spike 6, sanctions and geopolitics 6, external
funding stress 5, official backstop stress 5, inflation 4, distress 4, market overpricing (19) 4,
devaluation 3, election 3, security 3, commodity 3, climate 3, market complacency (15) 3, political
instability 1; banking stress, momentum, benign carry and the low-exposure GPR fade: 0.

Trades firing, number of countries (72 in all): T26 prediction-market gap 9, T11 political risk
insurance 7, T06 pay short rates 6, T15 sanctions screen 6, T20 overweight calm equities 6, T03
underweight Eurobonds 4, T22 IMF program event 4, T01, T02, T07, T12, T13, T14, T17 and T18 3 each,
T19 FX carry 2, T04, T09, T16 and T23 1 each; T05, T08, T10, T21, T24, T25 fire nowhere. Total trades
firing by country: Pakistan 10, Brazil 8, Venezuela 7, Argentina 6, Nigeria 6, Colombia 5, Senegal 5,
Zambia 4, Japan 3, Belize 3, Zimbabwe 3, Philippines, China, Singapore, South Korea and India 2 each,
Vietnam and Malaysia 1 each. (The earlier version of this section listed counts summing to 64
against 76 in the sensitivity table; both were stale against the current data.)

Dashboard sizes (notional $mm), after EQ-B-0008 with the pre-fix value in brackets where it moved:
Colombia 9.3 [10.0] (T17 at 93.4, Calm), Japan 9.2, Brazil 8.7, Philippines 8.2, South Korea 8.0,
Singapore 7.9, China 7.9, Pakistan 7.5, Zambia 7.5, India 7.5, Argentina 7.2, Vietnam 7.1, Malaysia
7.0, Nigeria 6.45 [7.5] (T13 commodity hedge at 100 no longer sized), Belize 5.85 [6.0], Venezuela
5.0, Senegal 5.0, Zimbabwe 3.75 [4.5] (T11 PRI at 90 no longer sized). GPR read: "GPR hotter than
Randori" for Vietnam, Philippines, China, Malaysia, Japan, South Korea, India (gap 26 to 44 points);
"Broadly aligned" for Brazil, Argentina, Colombia, Venezuela; "Not in GPR dataset" for 7.

## Limitations and known gaps

- No signal has been tested against outcomes. The trade-idea log (EQ-B-0038) now records each activated idea
  with a daily mark, but it starts on 2026-10-23 and only FX and equity ideas can be marked, so there is no hit
  rate or P&L attribution yet. The forecast record (roadmap 2.2) stores VaR and
  realised loss, not signals.
- The "best trade" is the trade with the highest activated signal, which is often a 100 because
  signal 16 (distress) is binary at 100 and several pillar signals reach 100. Pakistan's best trade
  is the CDS flattener with conviction 100. Until EQ-B-0008 Colombia's was "sell protection where
  spreads overprice risk" at 100 because signal 19 was 100 whenever `pd_default / pd_market` was at
  most 0.5 (Colombia 0.42); it is now 93.4 and grows with the gap. Conviction still reflects the
  construction of the binary signals more than the strength of the case.
- Signals 15 and 19 depend on hand-entered spreads and the Layer 2 weights (`bayesian-layer2.md`):
  with `w_m 0.5` the posterior sits between model and market in log-odds, so signal 15 is above 50
  exactly when the scorecard and FX terms push the PD above the market, and below 50 otherwise.
  Signal 19 for Colombia (93) and Brazil (83) is a statement about `w_m`, not about the market.
- Signal 25 and the prediction-market read depend on 18 placeholder contract prices and on the run
  date (contract horizons are computed from today).
- Signal 17 (momentum) is dead because `prior` is empty; signal 7 (banking stress) is below 60
  everywhere; signals 24 and 25 interact with the GPR coverage (6 countries are not covered and get
  0).
- Position sizing is linear in conviction with a 10 $mm budget per country and a regime scalar; it
  does not use the Monte Carlo risk measures or any limit (roadmap 4.1).
- The playbook's `risks` and `exit` fields are narrative and not evaluated.
- Instrument tradability is a hand-entered flag set; for example Belize has only Eurobond, so 7 of
  its signals above threshold produce 3 trades.

## Sensitivity

The signals are deterministic functions of upstream outputs, so their sensitivity is inherited.
Counting trades firing across the 18 countries in two upstream variants (20,000 paths; firing counts
are independent of the paths):

| Upstream variant | Signals at or above 60 (total over countries and keys) | Trades firing (total) | Notes |
|---|---|---|---|
| Base | 117 | 72 | Signal 23 contributes 18 (global GPR signal 68); unchanged by EQ-B-0008 |
| `probability.w_m 0` | signals 15 and 19 move for most countries | | with no market term `pd_default < pd_market` almost everywhere, so signal 19 rises and signal 15 falls |
| `scorecard.worst_blend 0` | pillar-based signals fall by 1 to 6 points | | T20 and T21 (100 minus composite) rise |

The counts in the second and third rows were not recomputed in this validation and are inferred from
the signal definitions; the first row is computed. A proper sensitivity would track each signal's
distribution over the parameter sweep, which requires storing `signals` per run (see open items).

Threshold sensitivity (from the definitions): raising `signals.threshold` from 60 to 70 removes
every signal between 60 and 70 from the dashboard's top three but does not change trade activation,
which uses each trade's own `min_strength` (50 to 100). Lowering `min_net_edge_pp` from 10 to 5
raises signal 25 for every country with a contract (the `pm_kelly` sweep in
`gpr-and-prediction-markets.md` shows the number of staked contracts going from 11 to 14).

## Benchmarks and evidence

- The README states the signals, trade activation and dashboard match the workbook formulas; there
  is no automated test of this claim against the workbook. `tests/test_signals.py` (EQ-B-0008)
  covers signal 15/19 continuity, monotonicity and the 70 crossing, `rule2` operator validation,
  hedge exclusion from sizing and the Colombia sizing on the shipped data. Signals 15/19 and the
  sizing rule now deliberately differ from the workbook formulas.
- No external benchmark exists: no comparison to a published early-warning indicator set (for
  example the IMF's or the ECB's sovereign vulnerability indicators), no signal-to-outcome study.
- The signal set covers the standard sovereign early-warning content (debt service, reserves,
  inflation, growth, banking, politics, security, climate, market mispricing). What is missing is
  evidence that the thresholds separate events from non-events.

## Trade-idea log (EQ-B-0038, GOV-032)

Code: `econquest/validation/idea_log.py`; tests `tests/test_idea_log.py`; outputs `outputs/idea_log.csv`,
`outputs/idea_report.md`, `outputs/idea_report.csv`. Tier 3 (illustrative): no reported, limit-tested or sized number
reads the log, and the report says so. It changes no model number.

Entry. Every (trade, country) a run activates becomes one idea, logged once with `run_id`, `as_of`, trade id,
country (name and ISO3), stance, instrument and the activated value. Notional is the dashboard rule applied per idea:
`risk_budget_mm 10` x value / 100 x `regime_scalar[regime]`, 0 for an unsized stance (Hedge); the dashboard's
country `notional_mm` is the largest of its ideas' notionals (checked on the seed and the base run). The entry level is
the last Market History close (`data/market_history/prices.csv`, read only) on or before `as_of`, at most 7 days old;
never a later price.

Instrument mapping (the documented rule). Only two playbook instruments have a daily price series:

| Instrument | Series | Direction |
|---|---|---|
| FX | `USD<currency>` (local per USD) | Risk-off long USD (+1), Risk-on long local / carry (-1) |
| Equity | country ETF (`countries.csv` `etf`) | Risk-off short / underweight (-1), Risk-on long (+1) |
| CDS, Eurobond, Local rates, FX options, Any | none | logged "unmarked" with the reason |

P&L on notional N: equity `d x N x (P / P0 - 1)`; FX `d x N x (1 - P0 / P)` (USD value of a long-USD position
funded in local currency). Carry, financing and costs are left out, so T19 (FX carry) understates and T04 (long USD)
overstates the P&L of the real trade by the rate differential.

Stop, target and holding period. `vol_3m` = standard deviation of the last 63 daily log returns to entry x sqrt(63);
stop and target at entry x exp(-/+ 2 x `vol_3m`) on the adverse and favourable side (at least 20 returns needed, else
no stop or target). The maximum holding period is the upper end of the playbook `horizon` in months (`3-12 months`
-> 12, `12+ months` -> 12, `Event to 1 month` -> 1), 12 months when the horizon has no month count (open-ended,
seasonal, to contract resolution). The playbook `exit` text is narrative and is not parsed.

Lifecycle. `update_log(log, run, u, settings, prices)` first marks open ideas to the run's `as_of`, then closes open
ideas the run no longer fires (`stopped_firing`, at that day's close), then opens ideas for new firings. A re-fire of an
open idea adds nothing (sizing and entry stay as at entry). After a stop, target or max-holding exit the idea re-arms
only once it has stopped firing, so one signal episode gives one idea. `mark(log, prices, as_of)` walks each open
idea's closes from entry to `as_of` (prices after `as_of` are never read): it closes on the first close at or through
the stop or target (exit at that close, not at the level) or on the first close on or after the max exit date;
unmarked ideas close on stopping firing or at the max exit date with no P&L. The log moves forward: marking to an
earlier date does not reopen a closed idea.

Report. Per playbook id, per stance and per instrument: ideas, open, closed, marked, unmarked and the unmarked share;
hit rate = share of closed, marked ideas with a positive return; hit rate including open ideas at their latest mark;
realised, open and total P&L in $mm; counts by exit reason.

Evidence, 2026-10-23. Synthetic fixture (hand-checked): equity long 8 $mm from 100 marked at 110 gives +0.80 $mm,
closed on stopping firing at 108 gives +0.64; long USD 6 $mm from 4.00 crossing its target (4.69) at 5.00 gives
6 x (1 - 4/5) = +1.20; a short equity stopped at 120 gives -1.60; re-fires do not duplicate; changing every price
after `as_of` leaves the marks unchanged. Seed run (`tests/seed_data`, as_of 2026-10-23) with the real `prices.csv`:
75 ideas, 11 markable (14.7%: 5 FX, 6 equity), 85.3% unmarked. Base run `20261023T163707-base` (`data/`, release 0.1.3):
72 ideas, 9 markable (12.5%: FX T04 Argentina, T19 Brazil and Colombia; equity T20 for Vietnam, Malaysia, Singapore,
Japan, South Korea, India), 87.5% unmarked (Any 31, Eurobond 15, Local rates 9, CDS 6, FX options 2). Entry levels
are from 2026-10-21 (FX; the 2026-10-22 FX row is empty) and 2026-10-22 (ETFs). No idea has closed yet, so there is
no hit rate; one needs about four quarters of daily marks (gap assessment E7).

Limitations. Seven of every eight ideas cannot be marked until Team A supplies CDS, Eurobond and local-rates marks;
the stance-to-direction rule treats every Risk-off FX idea as long USD and every Risk-off equity idea as short; the vol
rule gives very wide bands where an ETF has trended (South Korea `vol_3m` 0.27, stop 86 and target 257 from 149) and
would give tight ones on a peg; hedges are logged at 0 notional, so they add hit-rate evidence but no P&L. Sizing
still follows GOV-032's linear conviction rule; the log measures it, it does not change it.

Proposed `assumptions.json` keys (not added; the code defaults are used): `ideas.vol_window_days 63`,
`ideas.min_vol_obs 20`, `ideas.stop_vol_mult 2.0`, `ideas.target_vol_mult 2.0`, `ideas.default_max_hold_months 12`,
`ideas.max_stale_days 7`.

## Open items for review

1. Store the full signal and activation tables with each run (SQLite store) so hit rates and signal
   stability can be measured once outcomes accumulate. Ideas are now logged and marked (EQ-B-0038, section
   "Trade-idea log"); hit rates need closed ideas, and most ideas need Team A's credit and rates marks.
2. Add a regression test that the signal and activation tables match the workbook on the seed
   snapshot, as there is for the scorecard.
3. Decide whether conviction should be the signal value or a measure that uses the Monte Carlo
   output (tail contribution, PD gap).
4. Done: `gpr_divergence_threshold` is in `assumptions.json` `signals` (20).
5. Fill `prior` composites from the run archive so signal 17 works, or remove it from the dashboard.
6. Review signals 15 and 19 jointly with the Layer 2 weights; today they report the construction of
   the posterior rather than an independent market view.
7. Replace placeholder prediction-market prices before signal 25 and the prediction-market read are
   shown to a user as live.
8. Port the signal 15 tanh form and the hedge exclusion from sizing into the workbook's Signals and
   Dashboard formulas, or mark those cells as Python-published views (EQ-B-0008).

## Change record

2026-10-23, EQ-B-0008 (Tier 2: signals and trade activation, `model-risk-policy.md` section 2; owner +
approver on the two new parameters). Signal 15 changed from 50 + 50 log2(ratio) clipped to [0, 100]
to the tanh form above, removing the saturation of signal 19 at a 2x gap; `rule2` validated (unknown
operators raise); notional sizing excludes trades with stance Hedge. No Tier 1 number moves:
`notional_mm` on the dashboard is not read by the portfolio, Monte Carlo or limits (those use
`data/portfolio.csv`). Signal and trade-firing counts are unchanged (117 and 72); sizes moved for
Colombia 10.0 -> 9.3, Nigeria 7.5 -> 6.45, Belize 6.0 -> 5.85, Zimbabwe 4.5 -> 3.75.
