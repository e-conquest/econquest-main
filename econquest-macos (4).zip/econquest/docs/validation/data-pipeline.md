# Model validation: data pipeline, quality gate, vintages, audit trail and versioned runs

Date: 2026-10-23. Code: `econquest/ingestion/feeds.py` (feeds, transforms, robustness rules,
`quality_gate`, `save_vintage`, `apply_report`), `econquest/ingestion/audit.py`
(`build_audit_trail`, `audit_plan`), `econquest/ingestion/loaders.py` (`load_universe`,
`Universe.validate`), `econquest/ingestion/market_history.py`, `econquest/versioning.py`. Data:
`data/*.csv`, `data/live/`, `data/live/vintages/<date>/`, `data/audit_trail.csv`. Status: one live
pull applied on 2026-10-23 (298 cells); the gate, vintages, audit trail and versioning exist and
were exercised once; most Inputs cells remain seed estimates.

## Purpose

The pipeline is not a model but it decides what every model sees. This document records how inputs
reach the program, which transforms and robustness rules change them, how implausible values are
held, how each pull is kept as a vintage, how each input cell is traced to its origin, and how each
run is stamped with code and data hashes so that a number in a report can be reproduced.

## Where it sits in the pipeline

`load_universe(data_dir)` reads the six CSV tables plus the GPR file and the playbook, converts
yes/no flags, parses contract prices and dates, stamps provenance and versions (`versioning.stamp`),
and validates (unique country names, indicator columns for every country, rulebook and indicator ids
equal, positions on known countries, pillar weights summing to 1). `econquest fetch` runs the feeds
and transforms into `data/live/`, runs `quality_gate`, writes `review.csv`, saves a vintage and,
with `--apply`, overwrites seed values in `indicators.csv` and `countries.csv` for cells that
passed. `econquest audit` joins everything into one row per input cell.

## Assumptions

Feeds (`fetch_all`), each returning a long table `iso, series, period, value, source`:

- IMF WEO via `imf-reader` (SDMX 3.0), fallback to the `weo` package's spreadsheet; codes
  GGXWDG_NGDP, GGXONLB_NGDP, GGXCNL_NGDP, NGDP, NGDP_RPCH, PCPIPCH, BCA_NGDPD, NGDPDPC, NGDPD,
  GGR_NGDP.
- World Bank via `wbgapi`: WDI (population, exports, reserves, GDP, NPLs, homicides, youth
  unemployment, and since EQ-A-0027 short-term debt to reserves `DT.DOD.DSTC.IR.ZS`, with IDS as the
  fallback database), IDS (external debt to exports, PPG debt service), WGI (rule of law, control of
  corruption, regulatory quality: the legacy percentile ranks `*.PER.RNK` and the rulebook's
  `GOV_WGI_*.SC` codes; one family per country, percentile ranks first, the family used is written to
  provenance); most recent 6 non-empty values. EQ-A-0036: the 2024+ WGI database reports `GOV_WGI_*.SC`
  as a 0-100 score (a rescaled estimate), not a percentile rank, while 3.5 and its thresholds are
  percentile ranks. The three `.SC` series are therefore pulled for all economies (`economy='all'`,
  `skipAggs=True`, records flagged `aggregate` and the codes in `feeds.WB_AGGREGATE_CODES` dropped) and
  kept in `raw_worldbank.csv` with source "wbgapi World Bank API v2, all economies (WGI cross-section
  ...)", so the vintage reproduces the ranking offline. `wb_transforms` ranks each series per year the
  way the WB `*.PER.RNK` series do (share of the other economies ranking strictly below,
  100 x below / (n - 1); ties share the lower rank), averages RL/CC/RQ for 3.5 and differences the
  averages over three years for 3.4; provenance `series` reads "GOV_WGI_RL/CC/RQ.SC (WGI 0-100 score)
  -> percentile rank among n economies in <year>". With scores but no cross-section of at least
  `WGI_XS_MIN` (100) economies (all-economy call failed, offline fixture, raw file from before EQ-A-0036),
  3.4/3.5 stay empty and `unserved.csv` gives the reason, so the gate reports them missing rather
  than wrong; the raw score is never used. Not written to `transform_log.csv`, which lists only the
  robustness rules that changed a value (and audit.py maps its rows to 1.6/2.8). One call per database; if it fails, the series are
  retried one at a time and every failure is written to `live/feed_failures.csv`.
- BIS SDMX REST: real broad effective exchange rate (monthly), credit-to-GDP gap (quarterly), policy
  rate (daily). Since EQ-A-0027 the countries are batched into one key per flow with the SDMX OR
  operator (`M.R.B.BR+CL+...`, 25 per call, so 12 calls for 88 countries instead of 264), with 3
  retries and exponential backoff on timeouts, connection errors, 429 and 5xx. Rows are attributed by
  the response's country column (`REF_AREA`, `BORROWERS_CTY`); a batch that fails for good or cannot be
  attributed is retried one country per call. A `bis_iso2` column in countries.csv overrides `iso2`.
- Official FX (EQ-A-0040, Sam 2026-10-23 "Replace with free official"; replaces the Yahoo feed, whose
  terms are personal and non-commercial): BIS daily exchange rates (dataflow `WS_XRU`, key
  `D.<area>.<CCY>.A`, units of the currency per USD, 400 days, same SDMX client, batching and
  fail-fast as the other BIS flows) with the ECB euro reference rates (`EXR`, `D.<CCY>.EUR.SP00.A`)
  as cross-check and as the fallback for currencies BIS does not carry, converted to per-USD through
  the **same date's** EUR/USD. Both raw tables are written before any transform
  (`live/raw_bis_xru.csv`, `live/raw_ecb_exr.csv`, each with the `sdmx_key` of the series). One series
  per currency, shared by every country using it, so all EUR, XOF and XAF countries get fx3m. The two
  sources are compared per currency on the latest common date (`fx_cross_checks`, 1 percent): beyond
  that the cell is held with "fx cross: ...". Dollarised countries (currency USD), Zimbabwe (ZWL
  replaced by ZiG) and any currency neither source quotes get no value: fx3m stays empty, the reason
  is in `live/unserved.csv` and in the gate's `missing` row. **The series keys above were written from
  the BIS and ECB documentation, not verified against a live response from this cloud**
  (`docs/runbooks/A-official-fx.md` lists what the first Mac pull must confirm).
- `equity_vol` (Country Profile) has **no official free source** since the Yahoo removal. Every
  country gets an unserved row with the reason "no official free source (Yahoo removed, Sam
  2026-10-23)" and a `missing` gate row; nothing is substituted. It was never written into
  `countries.csv` and no engine reads it (the Monte Carlo's `market.equity_vol` is the governed
  assumption in `assumptions.json`), so no engine output loses an input. Sam's options are in
  `docs/runbooks/A-official-fx.md`.
- CSV reads of countries tables (`CsvSource`, `apply_report`, the universe tools, BIS responses) keep
  the text `NA`, Namibia's ISO2, instead of turning it into a missing value
  (`sources.read_csv_keep_na_code`); blank cells are still missing.

Transforms (`weo_transforms`, `wb_transforms`, `bis_transforms`, `official_fx_transforms`) produce Inputs
rows 1.3, 1.6, 1.7, 2.8, 5.5, 5.6, 5.12, 5.14 (WEO), 2.9, 2.10, 3.4, 3.5, 5.10, 6.2, 6.6 (World
Bank), 2.12, 5.9, 5.13 (BIS) and Country Profile fields pop, exports, reserves, policy, fx3m,
equity_vol (unserved since EQ-A-0040). The audit module's `TRANSFORMS` dictionary gives the formula per cell, for example 1.6
"primary balance minus debt-stabilising balance: pb - (r-g)/(1+g) x d(t-1)", 2.12 "latest real broad
EER / mean of last 120 months x 100 - 100", 5.12 "SD of NGDP_RPCH over 15y excluding 2020-21", fx3m
"percent change over about 91 days (positive = weaker)" - the definition and sign convention are
unchanged by EQ-A-0040: `feeds.fx3m` computes it for both the official series and the old Yahoo one.

Robustness rules in the WEO transforms:

1. Jump rule (`_robust_value`): for the current account 2.8 (BCA_NGDPD) and the nominal GDP growth
   used in the 1.6 gap, a year-t value whose change from t-1 exceeds `nsd 3` standard deviations of
   the previous 15 annual changes (at least `min_hist 8` changes) falls back to the t-1 value, with
   a row in `transform_log.csv`.
2. r-g cap (`RG_CAP 0.10`): the real-rate-minus-growth term in the 1.6 gap is clamped to plus or
   minus 10 points so an inflation-driven nominal growth figure cannot produce a 20-point artefact;
   logged.

Quality gate (`quality_gate`), one row per live cell, status ok, hold or missing:

3. Range: an Inputs value outside the rulebook thresholds by more than `span_mult 2` spans, or a
   profile value outside `PROFILE_RANGES` (pop 0.1 to 2000 million, exports 0 to 250, reserves 0 to
   200 percent of GDP, fx3m -80 to 400, policy -5 to 200, equity_vol 0 to 300).
4. Change: `|live - seed| > max_rel_change 0.5 x |seed|` and, for Inputs, also more than a quarter
   of the threshold span (`--max-change` on the command line).
5. Stale: a World Bank series whose latest period is more than `stale_years 3` before the pull year.
   BIS series (EQ-A-0044, `BIS_STALE_SERIES`: 2.12 REER, 5.9 credit gap, 5.13 and `policy` from the
   policy rate) are held when the last observation, dated at the end of its period, is older than
   `BIS_STALE_DAYS` at the gate's reference date. The limits are 30 days for daily series
   (`YYYY-MM-DD`, WS_CBPOL), 92 days for monthly series (`YYYY-MM`, WS_EER) and 275 days for quarterly
   series (`YYYY-Qn`, WS_CREDIT_GAP). Each is about one publication cycle plus the usual BIS release
   lag. A policy rate that has gone a month without an observation has stopped: BIS carries the rate
   on every business day. The reference date is `quality_gate(..., as_of=)`, else the pull date
   (latest provenance `retrieved`), else today in UTC, so replaying an old pull judges it as of that
   pull. Example: Argentina's policy rate ends 2025-07-10, so on the 2026-10-23 pull 5.13 and `policy`
   are held with "stale: BIS POLICY_RATE last observation 2025-07-10, 470 days before 2026-10-23
   (limit 30 days, daily)". On that pull no other BIS series is past its limit.
6. Missing: every indicator a successful feed left empty for a country.

Staleness is held, not just reported, by design. A stale cell gets status `hold` and stays on seed
until a reviewer records an approved apply bound to that vintage or live value (ledger rules below).
The gate never writes status `ok` with a non-empty reason, because any reason makes the cell `hold`,
and `crosscheck.merge_into_review` can only turn ok into hold. The 72 `data/live/review.csv` rows
with status `ok` and a gate reason, which the limitations register (EQ-A-0042, X11) counted, are not
a gate defect. In the vintage `data/live/vintages/2026-10-23/review.csv`, all 72 are `hold` and have
the same reasons; 4 reasons differ because the transforms were fixed that day. Among them are the
eight stale 6.2 homicide rates (Vietnam 2011, Senegal and Zambia 2015, China 2020, India, Belize,
Venezuela and Zimbabwe 2022). On 2026-10-23, before the review ledger existed, they were accepted on
review by hand-editing `review.csv`: status changed to `ok` and a free-text decision added, such as
"applied 2026-10-23: seed was a rough estimate, live value from an official source accepted on
review". That workflow is retired. `write_review` now regenerates `review.csv` from the gate (status
is always the gate's), and decisions live only in the ledger. Since EQ-A-0044, `import_legacy_review`
imports such a row with `gate_status` `hold` and a note saying the status was hand-edited, so the
ledger keeps the gate's verdict. A legacy apply has no approver, so it does not release the hold on
the next gate run. The values already applied on 2026-10-23 remain in `indicators.csv` until the next
reviewed apply. The audit trail and the register show them as accepted on review.

Held cells are skipped by `--apply`; `--force` applies them too but needs a named author and
approver and is recorded (below). Until EQ-A-0006 `apply_report` did not read the `decision` column
at all (earlier versions of this note said it did): it skipped every gate 'hold' and nothing else. It
now applies the review ledger rules below, reading decisions from `data/live/review_ledger.csv`
only (a `decision` column in the review frame is ignored since SEC-A-001). Versioning: `stamp` records package
version, SHA-256 over the package's `.py`, `.html` and `.js` files (`code_hash`), a hash of each
data file and one `data_hash` over them, Python and library versions and the platform;
`RunResult.summary["versions"]`, the SQLite run table and each forecast-record row carry them.

Vintages, snapshots and the review ledger (EQ-A-0005, EQ-A-0006):

- Vintage ids. `save_vintage(data_dir, report, review=None, now=None)` writes the live tables,
  provenance, raw feeds, review and `feeds.json` (with a UTC `retrieved` timestamp) to
  `data/live/vintages/<YYYY-MM-DD>T<HHMMSS>Z-<hash8>/`, where `hash8` is the first 8 hex digits of a
  SHA-256 over the files in name order. The folder is created with `exist_ok=False` (an existing
  vintage raises `FileExistsError`, never overwritten) and its files are made read-only. Each save
  appends a row (`vintage_id, retrieved_utc, hash, n_files`) to `data/live/vintages/index.csv`; when
  the index is first created, the legacy date-only folder `2026-10-23/` is indexed (hash over its
  files) and left untouched. `list_vintages` lists ids; `vintage_path` resolves a full id, a legacy
  date id, or a date meaning the latest vintage that day.
- Snapshots. `apply_report` copies the current `indicators.csv` and `countries.csv` to
  `data/live/snapshots/<UTC ts>-pre-apply/` (read-only, never overwritten) before writing, then
  replaces both files atomically (temp file in the same folder, `os.replace`). The result carries
  the folder as `result["snapshot"]`; restoring a seed is a copy back from that folder.
- Review ledger. `data/live/review_ledger.csv` (`ts_utc, vintage_id, table, key, country,
  gate_status, live, decision, author, approver, note, self_approved`) is append-only:
  `record_decision(data_dir, table, key, country, decision, author, approver=None, note="",
  vintage_id="", live=None, gate_status="", now=None, self_approved=False)` adds one row (decision
  apply, hold or reject; author required; applying a gate 'hold' cell needs an approver other than
  the author). Names are compared after NFKC normalisation, removal of Unicode format characters
  (zero-width spaces and the like), stripping and casefolding. Appends take an exclusive `flock` on
  POSIX so concurrent writers never duplicate the header; author, approver and note starting with
  `= + - @` are stored with a leading apostrophe. A ledger written before the `self_approved` column
  keeps its header and is read correctly. `write_review` regenerates `review.csv` as the fresh gate
  output joined with the latest decision per cell (`decision, author, approver, self_approved,
  decided_utc`), so a new pull no longer loses decisions; on its first run it imports the free-text
  decisions of the hand-edited `review.csv` with author "unknown (imported from hand-edited
  review.csv)" and no approver.
- Approvals are tied to what was approved (SEC-A-001 M1). `effective_holds(review, decisions,
  vintage_id=None)` decides what `apply_report` skips: a gate hold, unless the latest decision is an
  approved apply whose `vintage_id` equals the review's vintage (when both are known) or whose `live`
  equals the review's live value (relative tolerance 1e-6, absolute 1e-9); and any cell whose latest
  decision is hold or reject, even when the gate passed it. Hold and reject stay in force across
  vintages; an approval of 5.0 does not release a later hold at 500.0. Record approvals with
  `live=` (and `vintage_id=` when known), otherwise they release nothing.
- Single-operator mode (Sam, 2026-10-23). Four-eyes stays the default. A self-approval is allowed
  only when flagged: `record_decision(..., self_approved=True)` with the approver empty or equal to
  the author stores approver = author and `self_approved = yes`. Such a row releases a hold like a
  four-eyes approval, and the flag shows in `load_decisions`, `review.csv` and the audit trail as a
  governance exception. Without the flag, an approver equal to the author is refused.
- Force (SEC-A-001 M2). `apply_report(report, data_dir, review=None, force=False, now=None,
  vintage_id=None, author=None, approver=None, self_approved=False)`: with `force=True`, `author` is
  required and `approver` must differ from it unless `self_approved=True`; otherwise `ValueError` is
  raised before anything is written. Each forced cell gets a ledger row (decision `apply`, note
  `forced`, with the author, approver, live value and vintage) and is listed in `forced_cells.csv` in
  the pre-apply snapshot folder. The result is a plain dict: `indicator_cells`, `profile_cells`,
  `held_for_review`, `snapshot`, `inputs_snapshot` (with `vintage_id`) and `forced_cells` (with
  force), so `json.dumps` keeps every key. `fetch --apply --force` needs `--author`/`--approver` (or
  a self-approval flag) from Team C's CLI.
- Hardening (EQ-A-0011, SEC-A-001 L2-L4 and replay R1-R4). Name comparison also strips every leading
  apostrophe, removes all whitespace and maps a small set of Cyrillic and Greek look-alike letters to
  Latin, so `'alice`, `a lice` and Cyrillic `аlice` count as `alice` (names stay self-asserted). An
  `apply` that follows another person's standing hold or reject needs an approver other than its
  author (or a flagged self-approval), whatever the gate says; `record_decision` refuses it and
  `effective_holds` keeps the cell held if such a row is appended by hand (`load_decisions` carries
  `objection_by`). Every text column (vintage_id, table, key, country, author, approver, note and
  the rest) starting with `= + - @`, TAB or CR is stored with a leading apostrophe; plain numbers such
  as `-1.5` are not. Replay: a snapshot name in `snapshots/index.csv` must be a plain folder directly
  under `snapshots/`, the manifest must name the requested vintage, `out_dir` may not lie inside
  `data_dir`, and `materialize_vintage` builds in a temporary sibling folder and renames it into place.
- Hand-entered cells (EQ-A-0018). `data/adjustments.csv` (one cell per row and country column, key
  `block|pillar`), `data/cds_quotes.csv` (key `date|tenor_y`, value `spread_bp`) and
  `data/prediction_markets.csv` (key `id`, value `yes_price`) are typed by analysts.
  `ledger.attest_cells(data_dir, file, author, approver=None, self_approved=False, note="")` appends
  one ledger row per cell not yet attested (table = file stem, decision `apply`, live = value, and a
  new trailing column `content_sha256` over the row's defining fields), under the four-eyes rule
  above. `unattested_cells(data_dir)` lists cells whose current content has no approved attestation
  (never attested, edited since, or a later hold/reject). `econquest audit` adds one row per
  hand-entered cell with origin `hand-entered (attested)` or `hand-entered (UNATTESTED ...)`, and new
  trailing columns `author, approver, self_approved, attested` (also filled for Inputs and Country
  Profile cells from `review.csv`). Loading does not block on unattested cells; whether it should is
  a policy decision for Sam. There is no CLI command for `attest_cells` yet (Team C).
- Vintage integrity. `verify_vintage(data_dir, vintage_id)` recomputes a vintage's content hash and
  compares hash and file count with its row in `vintages/index.csv`; it raises
  `VintageIntegrityError` on a mismatch. The index is appended under the same lock as the ledger.
  SEC-A-004 L1 (EQ-A-0039): every index row for the id must carry the same hash and file count, so a
  row appended later cannot override the one written at save time. For a `<ts>-<hash8>` id, the
  `hash8` must also equal the recomputed content hash.
- Offline re-apply (EQ-A-0035, SEC-A-004 L2 and L3). `apply_vintage(data_dir, vintage_id=None, ...,
  allow_older=False)` refuses a vintage that is not the latest with `OlderVintageError`, unless
  `allow_older=True`. With the flag, the rollback is recorded as `rollback.json` in the pre-apply
  snapshot folder before the data files change, and returned as `result["rollback"]`. Every refusal
  is checked before the first ledger row is written: older vintage, verification, missing
  `review.csv`, no successful feed, missing author.
  `apply_report` writes `indicators.csv` and `countries.csv` with mode 0644 even if a restore left
  them read-only.
version, SHA-256 over the package's `.py`, `.html` and `.js` files (`code_hash`), a hash of each
data file and one `data_hash` over them, Python and library versions and the platform;
`RunResult.summary["versions"]`, the SQLite run table and each forecast-record row carry them.

## Data

State after the 2026-10-23 pull (from `data/live/feeds.json`, `review.csv`, `transform_log.csv`,
`audit_trail.csv`):

- Feeds: WEO ok (7,976 rows), World Bank ok (4,605), BIS ok (96,416), Yahoo ok (6,930) - the last pull before
  EQ-A-0040 replaced the Yahoo feed with `bis_xru` / `ecb_exr`; the next Mac pull is the first with the official
  FX sources. Provenance:
  312 cells written with source and retrieval date 2026-10-23.
- Quality gate: 310 ok, 2 held, 110 missing. Held: Venezuela reserves (seed 4.0, live 9.8 percent of
  GDP, +146 percent and World Bank latest period 2017; decision "kept on hold, keep seed") and
  Nigeria exports (latest period 1960; decision keep seed). The 110 missing rows are indicators the
  feeds do not carry for some countries (IDS series for high-income countries, NPLs, WGI for some
  years, BIS series for countries not in the BIS set).
- Transform log, four applications: South Korea BCA 2026 (18.8 percent of GDP after 6.5 in 2025,
  change 12.2 against a 1.7 standard deviation of annual changes; used 2025), South Korea nominal
  GDP growth 2026 (21.7 percent after 4.4; used 2025), Argentina r-g (-0.32 capped at -0.10),
  Nigeria r-g (-0.14 capped at -0.10).
- Audit trail (1,584 rows): Inputs 224 live feed, 1,170 seed estimate, 100 seed estimate where the
  feed returned no value; Country Profile 76 live feed, 10 seed estimate, 2 seed where the feed
  returned nothing, 2 seed kept because the gate held the live value. The seed source note reads
  "seed estimate (analyst/Claude, Oct 2026); not yet replaced by a feed".
- Vintages: one, `data/live/vintages/2026-10-23/`.
- Prices: `data/market_history/prices.csv`, 1,097 rows from 2023-10-18 to 2026-10-22, merged point
  in time by `update_prices_from_sheet_json` (never rewrites a stored price).
- Versions on the archived base run: code `05778bfaeef9287e`, data `6f8778fd15d02d8b`, Python
  3.13.16, numpy 2.5.4, pandas 2.3.3, scipy 1.18.1. The forecast record rows carry code
  `e0b04d4556d4071b` and data `f0fb8c56f52e64f3`, a different pair, because the code and data
  changed between the backfill and the later run.

### Raw tables added under EQ-A-0028 (no Inputs cell; consumers read them directly)

- `data/live/raw_bis_cbs.csv` (HO-20261023-B-A-005, Team B stress contagion `EMDEF_BRA`): BIS consolidated
  banking statistics, dataflow `WS_CBS_PUB`, key `Q.S..4R.U.C.A.A.TO1.A.<debtor ISO2, '+' batched>`: amounts
  outstanding, claims, all instruments, maturities, currencies and counterparty sectors, every individual
  reporting banking system (the reporter dimension is left open and BIS aggregates such as 5A/5J, codes that are
  not two letters, are dropped), last 8 quarters. Columns `creditor_iso2, debtor_iso3, period, claims_usd_mn,
  basis, source`, one row per (creditor, debtor, period), USD mn. **Unverified codes**: `CBS_BASIS=U` (ultimate
  risk; F = immediate counterparty, R = guarantor basis) and `CBS_BANK_TYPE=4R` are written from the BIS CBS
  documentation as remembered; this cloud cannot reach stats.bis.org. The fetch keeps only rows whose `CBS_BASIS`
  equals the requested code, so a wrong code fails loudly (no rows, `FeedError`) rather than mixing bases.
  Debtors with no claim in the latest quarter are listed in `feed_failures.csv` and `unserved.csv`
  (table `BIS CBS`); `provenance.csv` gets one row per reported debtor (table `BIS CBS`, total over reporters,
  source and pull date). `engine.stress.load_bilateral_exposures` reads the file as written
  (`tests/test_feeds_cbs_history.py::test_stress_loader_reads_our_cbs_file`).
- `data/live/raw_worldbank_history.csv` (HO-20261023-B-A-006, fitted layer 1): `DT.DOD.DSTC.IR.ZS`
  (WDI, IDS fallback), `FI.RES.TOTL.MO` and `PV.EST` (WGI) from 1996 for every universe economy, long layout
  `iso, series, period, value, source`, fetched with `panel_history.worldbank_series_fetcher` (the hazard
  panel's fetcher). wbgapi serves only the current database: these are **current-database values, not
  point-in-time vintages**. Loaded as `Universe.wb_raw` (`prov["wb_raw"]`).
- Both are written by `save_report` and copied into every vintage by `save_vintage` (with `unserved.csv`
  when it has rows); `replay.freeze_inputs` freezes them with the other `live/*.csv` files, and
  `live/events/events_long.csv` (`Universe.events`, `prov["events"]`) by name (`replay.TEAM_A_RUN_INPUTS`).
- `fetch --only bis` also pulls `bis_cbs`, `--only worldbank` also `worldbank_history`; each can be named alone.

### Loader provenance for blank Yes/No cells (HO-20261023-B-A-007)

`load_universe` records the blank cells of the Yes/No columns before they are read as "No":
`provenance["blank_yes_no"] = {country: [column, ...]}` (empty for the shipped 18). `scorecard.check_readiness`
treats blank `default`, `extarrears`, `exprop`, `coup`, `nopay`, `bankcrisis`, `emergency`, `disaster` as blocking.
`data/panel/universe_staging/cells_to_fill.csv` has a `blocking` column from `check_readiness(...).to_frame()` on
the staged universe (rows with table `Readiness` for blocking fields that are not a single cell, such as an empty
pillar), and the staged `adjustments.csv` has an explicit 0 column for each new country.

### Market data: schema, snapshots, attested manual entry and gate (EQ-A-0029, EQ-A-0031, EQ-A-0032)

`econquest/ingestion/market/` holds market quotes as one long table (`MARKET_COLUMNS`: asof, instrument, iso,
currency, tenor_y, field, value, unit, doc_clause, source, vendor_ticker, licence, derived, snapshot_id,
retrieved_utc). Its unique key is (asof, instrument, iso, currency, tenor_y, field, doc_clause, source).
`validate_market` checks the following and refuses any text that starts with = + - @ TAB CR:
- types and enumerations, and the fields each instrument allows;
- ISO3 and ISO 4217 codes, matched in full;
- that values are finite and recovery lies in [0, 1];
- that a quote is not dated after its `retrieved_utc`;
- that the licence is given and is not a placeholder.

Snapshots are stored under `data/live/market/snapshots/<ts>-<hash8>/`. They are read-only, append-only and
verified against sha256. `latest_market(asof=D)` and `market_history(asof=D)` use only snapshots saved on or
before D. `to_cds_quotes` writes the engine's existing `cds_quotes.csv` columns (HO-20261023-A-B-010). There are
two ways in:
- `importers.import_vendor_csv` reads Bloomberg/LSEG CSV exports through a verified ticker map;
- `manual.enter_quotes` takes hand-typed quotes with a four-eyes or flagged self-approved ledger attestation per
  row (table `market_manual`, content sha256).
- Licensed API adapters (EQ-A-0033, `market/vendors/`: Bloomberg BLPAPI, LSEG Data Library) are a paid roadmap feature, off unless the package, a licence entitlement and an unexpired expiry are all present; wire formats are written from vendor docs and tested only against fakes (`tests/test_market_vendors.py`; runbook `docs/runbooks/A-licensed-vendors.md`).

`gate.market_gate` returns review rows with the `quality_gate` columns. It holds stale quotes, implausible
values, non-monotone CDS curves, FX forwards that break covered parity, jumps against the previous snapshot,
and bond-CDS basis outliers. It flags inverted CDS curves without holding them. Tolerances are in `GateParams`;
the runbook is `docs/runbooks/A-market-data.md`. Tests: `tests/test_market_schema.py`, `test_market_importers.py`,
`test_market_manual.py` and `test_market_gate.py`, all on synthetic fixtures.

Limits:
- Vendor ticker and RIC formats are unverified until Sam exports from a licensed terminal; every template row
  is `verify`.
- The gate is not yet run automatically on import. It must be called before `cds_quotes.csv` is written.
- `data/cds_quotes.csv` had 0 rows on 2026-10-23, so nothing was migrated.

## Estimation or calibration

Not applicable. The thresholds of the robustness rules (3 standard deviations, 8 changes, 10-point
cap) and of the gate (2 spans, 50 percent change, quarter span, 3 years) are judgement. The 3-SD
rule was motivated by the WEO October 2026 Korea current account projection, the r-g cap by
Argentina 2026 (both recorded in the code comments and the transform log).

## Outputs and how they are used

`data/live/` (live tables, provenance, diff, review, transform log, raw feeds), the vintage folder,
updated `indicators.csv` and `countries.csv`, `data/audit_trail.csv`, `outputs/audit_plan.json`, the
Audit Trail tab, the GUI Data and jobs table, and the version stamp in every run, the SQLite store
(`econquest runs`) and the forecast record.

Event feed exports (EQ-A-0028, `econquest/ingestion/events/export.py`): two derived tables rebuilt from the
stored UCDP and GDELT event vintages (never from a live pull) after every save, for other teams.
`data/live/events/events_long.csv` (Team B, HO-20261023-B-A-004; read by `engine/event_index.py` and, once the
lead wires it, `Universe.events` through `load_events_long`) holds every vintage: a row is repeated for a later
vintage only when its value changed, so the latest vintage on or before a date reproduces that day's snapshot.
`vintage` is the snapshot's retrieval date (or a recorded GED release date), never the event date. Mapping:
UCDP `events_total` -> `events`, `fatalities_best` -> `fatalities`, split into `ucdp_ged` / `ucdp_candidate` by
the dataset windows in the vintage manifest; GDELT `events_material_conflict` (QuadClass 4, root events) ->
`events`, `goldstein_mean` / `tone_mean` unchanged (means over all root events of the day). Zero counts are
explicit rows. `data/live/events_weekly.csv` (Team C, HO-20261023-C-A-007, `events_view.EVENT_SCHEMA`) is GDELT
only, ISO weeks from Monday, newest vintage per country-day, event-weighted means. Each changed export is
also archived read-only in `data/live/events/exports/<ts>-<hash8>/` with a manifest naming the source vintages;
vintage folders themselves stay untouched. Limits: UCDP is monthly so it is absent from the weekly table; the
GDELT means are not restricted to conflict events (the adapter stores only all-event means).

## Replay a run

A vintage folder keeps only what a pull returned, so it cannot by itself reproduce a run. Since
EQ-A-0007, `apply_report(..., vintage_id=<id>)` also freezes every Team A run input
(`indicators.csv`, `countries.csv`, `market_history/*`, `panel/*`, `live/*.csv`, `live/*.json`) to
`data/live/snapshots/<vintage_id>-inputs/`: files read-only, `manifest.json` with a sha256 per file,
an `inputs_hash` over them, the `data_hash` at freeze time and the sha256 of every other team's file
("not frozen by Team A"). A row in `data/live/snapshots/index.csv` anchors the `inputs_hash`. A
re-apply with different files adds `-inputs-1`, `-inputs-2` ...; the latest is used.

```
from econquest.ingestion import load_universe, materialize_vintage
u = load_universe("data", vintage="2026-10-24T182005Z-1a2b3c4d")   # or a date: that day's latest vintage
materialize_vintage("data", "2026-10-24", "/tmp/replay-data")        # a full data dir to point a run at
```

Both verify every hash first and raise `VintageIntegrityError` on a tampered or incomplete snapshot,
or `FileNotFoundError` when the vintage was never frozen; neither falls back to the current files.
Other teams' files (`assumptions.json`, `rulebook.csv`, ...) are copied as they are now; any that
changed since the freeze are listed in `replay_manifest.json` (`drift`, and `drift_in_data_hash`
for those the data hash covers), and in `u.provenance["replay"]`. With no drift, the replay's
`data_hash` equals the frozen run's. For an identical run hash the run also needs the same code and
the same as-of date (EQ-B-0001, EQ-C-0011). The `econquest run --vintage` flag and passing
`vintage_id` from `fetch --apply` are Team C's (HO-20261023-A-C-006). Vintages applied before
EQ-A-0007 (including the legacy `2026-10-23`) have no frozen inputs and cannot be replayed.

## Limitations and known gaps

- Coverage: 224 of 1,494 Inputs cells (15 percent) are live. The 37 level indicators and most of
  pillars 3, 4, 6 and 7 have no feed; the roadmap's event data (ACLED, GDELT, UCDP; item 1.4) and
  licensed market data (item 1.3) are the gating items.
- Spreads, 3-month reserve changes, text index, ratings, flags, commodity gaps and the stress
  depreciation in the Country Profile are hand-entered and outside the gate, yet they decide
  regimes, half of each PD and the transfer-loss sizes.
- The seed note names no individual author or date beyond "analyst/Claude, Oct 2026"; the roadmap's
  four-eyes control (4.4) exists only for applying gate-held cells through the review ledger
  (EQ-A-0006); `fetch` uses it once Team C routes `cli.py` through `write_review` (EQ-C-0012).
- The gate compares live values to seed values, so the first pull holds anything the analyst
  mis-estimated by more than 50 percent, and the second pull will compare to the applied live value;
  there is no check against the previous vintage's live value yet (the vintage exists, the
  comparison does not).
- The jump rule can hide a real break: Korea's 2026 current account projection of 18.8 percent of
  GDP is implausible, but a genuine 12-point swing after a terms-of-trade shock would be replaced by
  the t-1 value as well. Every application is logged; none is flagged to the user except in the
  audit trail column.
- The r-g cap at 10 points interacts with the debt level: for Argentina the capped gap understates
  the debt-stabilising balance by `(0.32 - 0.10) / (1 + g) x d(t-1)`, which is several points of
  GDP.
- `data_hash` covers the listed data files but not `data/live/` or the vintages, and `code_hash`
  covers `.py`, `.html` and `.js` but not `assumptions.json` separately (it is inside the data
  hash). Two runs with equal hashes still differ if the run date differs (contract horizons, see
  `bayesian-layer2.md`).
- `Universe.validate` checks structure, not content: a spread of 60,000 bps or a negative population
  would load.
- `data/market_history/prices.csv` is a Google Finance (GOOGLEFINANCE) export of the workbook's Market
  History tab, not a Yahoo pull (checked under EQ-A-0040): weekend FX rows, partial last days and quote
  errors are handled heuristically (`complete_date` at 60 percent of series, `clean_bad_ticks` at 12
  robust SDs). It is a retail quote source, and Google's terms for it are still Sam's to confirm.
- The official FX rates (BIS WS_XRU, ECB EXR) are once-a-day reference rates, not traded quotes: fx3m
  from them differs from a retail close by a fraction of a percent, and there is no intraday or
  weekend observation at all. The series keys are unverified until the first Mac pull.
- The BIS feed batches countries (EQ-A-0027) but has no caching, and the daily policy-rate flow is
  requested over its full history; a partial failure is reported per flow but the partially filled
  table is still used. That BIS answers an OR key in which some codes are unknown with the known
  countries' series (rather than a 404 for the whole key) is assumed, not checked against the live API;
  the one-country fallback covers either behaviour at the cost of extra calls.
- 2.9, 3.4 and 3.5 came back empty for every country in the 2026-10-23 pull. The fix (2.9 from WDI
  with IDS fallback; WGI codes from the rulebook API Map alongside the legacy codes; per-series retry)
  is based on that pull and on documentation knowledge, not on a live call; the next Mac pull's
  `feed_failures.csv` shows which codes the API accepted. The `GOV_WGI_*.SC` series turned out to be
  a 0-100 score, not a percentile rank: Sam's 0.1.4 pull (2026-10-23 21:42Z) gave 3.5 values compressed
  toward the middle (Singapore 87.6 against a seed percentile of 98, Venezuela 20.2 against 2), which
  matches (estimate + 2.5) / 5 x 100. Since EQ-A-0036 the scores are ranked among all economies (above).
- Gate v2 vintage check (EQ-A-0036): a key with no finite value for any country in the previous vintage
  (e.g. 2.9/3.4/3.5 when the previous vintage came from an install that never fetched them) is new
  coverage: its cells are listed 'ok' with "new series: not in <vid>" and are not held; they still
  face the seed-based range/change checks. A key other countries had keeps the 'reappeared' hold.
- The README says there are 1,584 audit rows; the trail today has 1,584 rows for 18 countries x (83
  indicators + 5 profile fields). Any new indicator or country changes the count, which is fine, but
  the README's statement that `fetch --apply` applied "298 cells" cannot be reconciled from the
  current files (provenance has 312 rows, 310 passed the gate).

## Sensitivity

The pipeline has no risk output of its own, so its sensitivity is the model's sensitivity to the
input choices it makes. Two cases computed in this validation (20,000 Sobol paths; base VaR99 65.98,
ES99 87.05 $mm, mean PD 0.1387):

| Input choice | Effect |
|---|---|
| Seed vs live snapshot | `tests/seed_data` (seed values) vs `data/` (live values applied): the composite moves by up to 0.5 points (Zimbabwe 75.0 to 74.5, Vietnam 29.1 to 28.8, Pakistan 66.9 to 66.5); regimes unchanged; the README's PDs (Zimbabwe 88 percent, Senegal 18 percent on the seed data) become 78.4 and 23.9 percent on the live data. Not rerun on the seed folder in this validation; the seed figures are the README's and the workbook reference's. |
| Robustness rules | Not isolated at run time (the rules act inside `fetch`, not in `run_pipeline`). The logged cases change 2.8 for Korea by 12 points of GDP and 1.6 for Argentina and Nigeria by several points; the scorecard's sensitivity to those indicators is through their pillar weights (0.05 each) and the stress path, so the composite effect is at most about 1 point. Inferred from the weights, not computed. |
| Quality-gate holds | Venezuela reserves 4.0 (seed, kept) vs 9.8 (live, held): reserves enter the Layer 1 `reserves_months_imports`, the Merton `V_A` and the stress path for pegs. Not recomputed; the Layer 1 coefficient on reserves (-0.534 per 4 months) implies a change of about `(9.8 - 4.0) / 14.9 x 12 / 4 x 0.534 = 0.6` log-odds on Venezuela's hazard, which is at the 99 percent PD cap anyway. |

The data-side sensitivity that matters most for the book is the hand-entered spread column (regime
and `pd_market`), covered in `regime-layer3.md` and `bayesian-layer2.md`.

## Benchmarks and evidence

- Tests: `test_weo_transforms`, `test_robust_latest_falls_back_on_implausible_jump`,
  `test_primary_balance_gap_caps_r_minus_g`, `test_wb_transforms`, `test_bis_and_yahoo_transforms`,
  `tests/test_feeds_official_fx.py` (EQ-A-0040: BIS XRU and ECB EXR parsing on synthetic fixtures, the
  EUR cross, fx3m equal to the Yahoo-era definition on the same path, shared currencies, Yahoo not
  called by default, fail-fast with the host down),
  `test_diff_save_apply_roundtrip`, `test_quality_gate_holds_outliers_and_applies_the_rest`,
  `test_parse_market_history_values`, `test_versions_change_with_data`.
- Scale (EQ-A-0027, `tests/test_feeds_scale.py`, offline with fakes for wbgapi, the BIS endpoint and the
  ECB client): FX keyed by country for shared currencies, BIS OR-key batching, retries and per-country
  fallback, World Bank per-series retry and WGI family selection, Namibia's `NA`, and `fetch_all` plus
  gate, save and missing-cell report on the staged 88-country data folder.
- The first live pull is evidence that the feeds, transforms and gate work end to end: four feeds
  succeeded, two implausible values were held with a written decision, four robustness-rule
  applications were logged, and the audit trail reconciles 1,584 cells to an origin.
- Reproducibility: two runs with the same `code_hash` and `data_hash` see the same inputs;
  `test_sobol_is_reproducible` shows the simulation is deterministic given the seed. The remaining
  non-determinism is the run date in the prediction-market horizons.
- No comparison of live values against a second source (for example IMF WEO vs World Bank for debt
  or reserves) has been made; the gate checks plausibility, not agreement between sources.

## Open items for review

1. Extend the gate to compare each pull with the previous vintage's live value, not only with the
   seed.
2. Bring the hand-entered Country Profile columns (spread, res3m, textz, rating, flags, commgap,
   stress_depreciation) under the gate and the audit trail with an author and date per cell (roadmap
   4.4).
3. Add an as-of date to the run stamp and use it for every date-dependent computation.
4. Include `data/live/` and the vintage folder in the data hash, or record the vintage date in the
   stamp.
5. Flag robustness-rule applications and gate holds in the run diagnostics and on the dashboard, not
   only in the audit trail.
6. Cross-check overlapping series between sources (WEO vs WDI reserves and GDP) as a second gate.
7. Reconcile the README's "298 cells applied" with the provenance (312 written, 310 passed) and
   state the count the files support.
8. Schedule the pull and the record on a server (roadmap 4.6) so vintages accumulate without manual
   steps.
