# Model validation: PD benchmark scoring

Date: 2026-10-23. Code: `econquest/validation/benchmarks.py` (`score_benchmarks`, `matured_outcomes`,
`calibration_table`, `write_benchmark_scores`). Tests: `tests/test_benchmarks.py`. Ticket EQ-B-0022,
governance item GOV-011 (scorecard thresholds not calibrated to outcomes). Status: framework built and
tested on synthetic histories; nothing in `data/benchmarks.csv` has matured yet, so no real score exists.

## Purpose

Score each PD source in the benchmark snapshot history against realised default starts, so that the
model's 12-month PD can be compared with the alternatives on outcomes instead of on disagreement.
This is the first outcome-based evidence for GOV-011.

## Inputs

- History: `data/benchmarks.csv`, one row per snapshot date and country, written by
  `python -m econquest benchmark`. Sources scored (all 12-month probabilities):

  | Column | Source |
  |---|---|
  | `pd_model` | model final PD (after regime multiplier and prediction-market blend) |
  | `pd_hazard` | hazard layer (Layer 1) alone |
  | `pd_rating` | rating-implied |
  | `pd_spread` | spread-implied from the Country Profile spread |
  | `pd_cds` | CDS-implied (empty today: `data/cds_quotes.csv` has 0 rows, GOV-040) |
  | `pd_pm` | prediction-market implied, where a default contract is priced (placeholders today, GOV-016) |

- Outcomes: `data/panel/sovereign_defaults.csv` (iso, start year, end year). Its start/end years may be
  off by one (GOV-044); every score inherits that.

## Matured rule

A snapshot row taken on date `d` is **matured** for horizon `h` months when

    d + h calendar months <= as_of      (inclusive: 2024-01-15 matures for 12m on 2025-01-15)

and the sovereign was not already in default on `d` (`in_spell`, EQ-B-0005: SD/D rating, the
`in_default` flag, or an events spell that started by `d` and had not ended). `as_of` is a required
argument; the scoring code never reads the wall clock. Rows not yet matured are counted in `n_pending`;
in-default rows in `n_excluded_in_spell`.

**Outcome** `y = 1` when a default spell starts inside `[d, d + h]` (both ends inclusive), else 0. With
the current yearly events table a start year `y` is dated 1 July `y` (the mid-year convention used by
`outcomes` and the hazard panel). If the events table carries a `start_date` column (day resolution),
that date is used instead.

**Horizons.** Default `{"12m": 12}`. A shorter horizon (`{"6m": 6}`, `{"3m": 3}`) is accepted but is
reported as *not scorable* unless the events table has day-resolution `start_date`: with only a start
year, a 3- or 6-month window either contains 1 July or not, which says nothing about when the default
happened. For sub-annual horizons the 12-month PDs are converted under a constant hazard,
`p_h = 1 - (1 - p_12)^(h/12)`.

## Formulas

On the matured rows where the source has a forecast (`n` rows, `events = sum y`):

- Brier: `B = mean((p - y)^2)`, probabilities clipped to [0, 1].
- Base rate: `ybar = mean(y)` over the same rows (in-sample climatology; it uses hindsight, so it is a
  slightly flattering reference for the base rate).
- Base-rate Brier: `B_ref = mean((ybar - y)^2) = ybar(1 - ybar)`.
- Brier skill score: `BSS = 1 - B / B_ref`; undefined (NaN) when there are no events or no non-events.
  BSS > 0 beats the base rate, 0 equals it, < 0 is worse.
- Log loss: `LL = -mean(y ln p + (1 - y) ln(1 - p))` with `p` clipped to `[1e-6, 1 - 1e-6]`
  (`LOGLOSS_EPS`), so one confident miss costs at most `-ln(1e-6) = 13.8` before averaging. Venezuela's
  0.99 cap and placeholder market prices make the clip matter; read log loss together with Brier.
  `log_loss_base_rate` is the same formula at `p = ybar`.
- AUC: Mann-Whitney (ties half), only when both classes are present.

**Calibration table** (`outputs/benchmark_calibration.csv`): forecasts sorted ascending and cut into
`min(5, n)` equal-count bins (`CALIBRATION_BINS`). Each bin reports n, the actual forecast range
(`p_min`, `p_max`, also in the label, for example `bin 1 of 5 (equal-count): p 0.0050 to 0.0150`), mean
forecast, observed rate and events. Bins are named by count and range, not as deciles or fixed PD
buckets; tied forecasts on a boundary can fall in two adjacent bins and the labels then overlap.

**Paired comparison against the model.** For each non-model source, on rows where both it and
`pd_model` have a forecast: per-row loss difference `d_i = (p_src,i - y_i)^2 - (p_model,i - y_i)^2`
(positive means the model did better). `brier_diff_vs_model = mean(d)` and `log_loss_diff_vs_model`
the same on log loss. The Diebold-Mariano-style statistic is `t = mean(d) / se`, with standard errors
clustered by country because overlapping snapshots of one country are not independent:

    se = sqrt( G/(G-1) * sum_c (sum_{i in c} (d_i - mean d))^2 ) / n,    p = 2 * P(T_{G-1} > |t|)

with G countries. It is computed only when there are at least 30 paired rows (`MIN_ROWS_COMPARE`) and
5 countries (`MIN_CLUSTERS_COMPARE`); otherwise `comparison_note` says why it was not tested. Clustering
by country does not correct for common shocks across countries in the same year; with 18 countries and
few default events the test will have low power for years.

## Outputs

`score_benchmarks(history, events, as_of, horizons=None)` returns `BenchmarkScores` with:

- `scores`: one row per horizon and source, always (an empty history still gives 6 rows per horizon),
  columns `SCORE_COLUMNS`: `as_of, horizon, horizon_months, source, label, status, n, events,
  base_rate, brier, brier_base_rate, brier_skill, log_loss, log_loss_base_rate, auc, n_snapshot_rows,
  n_excluded_in_spell, n_pending, first_maturity, next_maturity, n_paired, brier_diff_vs_model,
  dm_stat, dm_p_value, dm_clusters, log_loss_diff_vs_model, comparison_note`.
- `calibration`: `CALIBRATION_COLUMNS`, header only when nothing is scored.
- `status`: per horizon, one of `scored: N matured rows[, next maturity D]`,
  `not yet scorable, first maturity D`, `not yet scorable: no snapshots in the history`,
  `not yet scorable: every snapshot row is already in default`, or the sub-annual resolution message.
  A source with no forecast on the matured rows (today `pd_cds`) has status
  `no forecasts from this source on the matured rows`.

`write_benchmark_scores(result, out_dir)` writes `outputs/benchmark_scores.csv` and
`outputs/benchmark_calibration.csv`. (The older `outputs/benchmarks_scores.csv`, written by
`econquest benchmark` from `score_sources`, is the Sheets summary; the CLI wiring of the new writer is
with Team C.)

## Current state (2026-10-23)

`data/benchmarks.csv` holds one snapshot (2026-10-23, 18 rows). Scored as of 2026-10-23:
`not yet scorable, first maturity 2027-10-23`; 16 rows pending, 2 excluded as already in default
(Venezuela, Zimbabwe). GOV-011's target date of 2027-10-23 is the first possible scoring date, and one
snapshot of 16 countries will not support any comparison test (the DM test needs 30 paired rows): useful
evidence needs regular snapshots (for example monthly) for several years.

## Limitations

- Outcome labels are from a hand-compiled events table (GOV-044); yearly resolution forces the
  mid-year convention and rules out sub-annual horizons.
- Overlapping 12-month windows from frequent snapshots repeat the same outcome; counts `n` overstate
  the information and only the clustered test accounts for it.
- `pd_cds` is empty (GOV-040) and `pd_pm` is placeholder prices (GOV-016); their scores, when they
  appear, are not evidence about markets until those items close.
- The in-sample base rate is a hindsight reference.
