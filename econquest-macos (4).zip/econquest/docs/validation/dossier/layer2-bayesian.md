# Dossier: layer 2 Bayesian log-odds update and market prior

Tier 1. Code: `econquest/engine/layer2_bayesian.py` (`posterior`, `market_implied_pd`, `default_contract_prior`,
`blend_with_market`, `arbitrage_scan`). Parameters: `probability`, `prediction_markets`. Source:
`bayesian-layer2.md`. Evidence class: judgement weights; market prior on placeholder prices.

## Purpose and use
logit(p_post) = logit(p_model) + w_s (S - 45.8) + w_m z_cds + w_fx z_fx + w_t z_tsi, then a precision-weighted
blend with the prediction-market default-contract prior. Output `pd_final`, times the regime multiplier, is the
reported `pd_default` that drives defaults in the Monte Carlo.

## Conceptual soundness
The additive log-odds form is a reasonable naive-Bayes update. The weights are not estimated (`w_s 0.04`,
`w_m 0.5`, `w_fx 0.1`, `w_t 0.25`). The market term dominates: `z_cds` is positive for every country, so `w_m`
raises every PD (GOV-013); since 0.1.3 the spread-implied PD is divided by a judgement risk-premium ratio of 2
(SD/D exempt). `w_fx` uses realised depreciation, not the implied-vol skew the paper specifies; pegs carry no FX
term since 0.1.3 (GOV-015). `tau` values in the blend are not measured precisions.

## Data
Spreads hand-entered in `countries.csv` (GOV-036); text index zero (event index built, `text_index.source none`,
GOV-014); `prediction_markets.csv` 18 illustrative prices with no slug/ticker (GOV-016, restriction 6.2).

## Implementation
As-of fixed once per run since EQ-B-0001 (GOV-012 resolved). Tests: `tests/test_layer2_bayesian.py` (7),
`test_pipeline_asof.py`, `test_event_index.py`.

## Outcomes analysis
None against outcomes (benchmark scoring starts 2027-10-23). Replication D08 and D09 reproduce the EQ-B-0021
sensitivity table at 20,000 paths (pre-0.1.3 base 68.54 / 87.42 / 1.855; `w_m 0.35` 63.13 / 82.71 / 0.236):
the documented effect of `w_m` and the ratio is real, but the choice between them is not evidenced.

## Limitations
Half of each PD rests on hand-entered spreads and a judgement ratio; market prior is illustration; `pd_market`
cap 0.95 binds for Venezuela; text term inert.

## Sensitivity (release 0.1.5, recomputed)
Recomputed for EQ-B-0057 on release 0.1.5 settings and the data in `data/` on 2026-10-24 (as_of 2026-10-23, 20,000 requested = 32,768 Sobol paths, seed 7). Base: VaR99 73.00 ±0.69, ES99 95.68 ±0.82, EL 0.471 $mm (± is the batch-means SE, `var99_se_mm` / `es99_se_mm`). n.s. = within 2 SE of base. Full table: [sensitivity-tables.md](sensitivity-tables.md#layer-2-bayesian-and-scorecard-weight).

| Change | VaR99 | ES99 | EL | Largest PD moves (pp) |
|---|---|---|---|---|
| `risk_premium_ratio` 1.5 (base 2) | +1.7% n.s. | +1.8% n.s. | +0.44 | SEN +2.2, PAK +1.1, ARG +0.9 |
| `risk_premium_ratio` 3.0 | **-3.8%** | **-2.2%** | -0.52 | SEN -2.7, PAK -1.3, ARG -1.2 |
| `w_m` 0.35 (base 0.5) | **-2.1%** | -0.9% n.s. | -0.30 | ZWE -12.1, SEN -1.8, ARG -0.8 |
| `w_m` 0.65 | +1.2% n.s. | +1.0% n.s. | +0.33 | ZWE +11.7, SEN +2.0, ARG +0.9 |
| `w_s` 0.03 (base 0.04; scorecard weight) | -0.8% n.s. | -0.1% n.s. | -0.26 | ZWE -10.3, PAK -1.3, SEN -1.3 |
| `w_s` 0.05 | +0.8% n.s. | +0.2% n.s. | +0.30 | ZWE +10.0, PAK +1.5, SEN +1.4 |
| `use_market_prior` false | -1.1% n.s. | -0.6% n.s. | -0.35 | ARG -2.9, SEN -2.6, PAK -0.6 |

Layer 2 judgement weights move PDs a lot (Zimbabwe ±10 to 12 pp) and EL by 50 to 110%, but VaR99 and ES99 by at
most 4%: the book tail is a market tail. The risk-premium ratio is the only layer 2 key with a significant VaR and
ES effect. The placeholder prediction-market prices move reported PDs (Argentina 2.9 pp, Senegal 2.6 pp) through
the default-contract prior (VF-013).

## Use-restriction status
**6.1 in force (keep).** **6.2 conditional:** the placeholder prices also feed reported PDs, a channel 6.2 does
not name (VF-013). See [use-restrictions-review.md](use-restrictions-review.md).

## Open findings
GOV-013 (High, mitigated), GOV-014, GOV-015 (mitigated), GOV-016 (High), GOV-017; VF-009 resolved (EQ-B-0047);
VF-013 (new: placeholder market prices reach reported PDs).

## Independent validator should re-perform
1. Recompute `pd_post` for three countries by hand from the country table columns (`pd_model_l1`, `score_dev`,
   `z_cds`, `z_fx`) and the weights.
2. Source five spreads in `countries.csv` from a dated market source; rerun and report the PD moves.
3. Rerun with `prediction_markets.use_market_prior false` and report the PD and VaR effect of the placeholder prior.
4. When benchmark snapshots mature: Brier of `pd_default` against `pd_rating`, `pd_market_phys` and hazard-only.
