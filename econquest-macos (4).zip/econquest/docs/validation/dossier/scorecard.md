# Dossier: scorecard (83 indicators, 7 pillars)

Tier 1. Code: `econquest/scorecard/scoring.py` (`score_universe`), `scorecard/readiness.py`. Parameters:
`assumptions.json` `scorecard`, `floors`, `boom_trigger`, `stress_path`; `data/rulebook.csv`. Source document:
`docs/validation/scorecard.md`. Evidence class: method replicated; inputs mostly judgement (seed estimates).

## Purpose and use
Scores 83 raw indicators per country 0 to 100 by threshold interpolation, aggregates to seven pillars, a
composite and a 1 to 10 grade. Feeds layer 2 (`w_s` x (composite - 45.8)), layer 1 (pillar 4 as the PITF
instability proxy), the peril PDs (pillar drivers) and the signals. Reported on the dashboard and the workbook.

## Conceptual soundness
The workbook's Appendix A rulebook, ported. Thresholds and weights are expert judgement, not calibrated to
default outcomes (GOV-011). The worst-indicator blend (0.2) and floors make the composite discontinuous in its
inputs and let floors dominate (Venezuela). Reasonable as a structured expert score; not a probability model.

## Data
`indicators.csv` 1,494 cells; 224 live (15%), the rest seed estimates from "analyst/Claude, Oct 2026" with no
individual author (GOV-010, GOV-036, GOV-039). Reserves cover uses exports as the import proxy (GOV-009).
Since EQ-B-0045 a readiness gate stops a run with missing required fields (88-country work).

## Implementation
Vectorised in EQ-B-0034, regression-tested against the workbook (`tests/test_panoptix.py`,
`test_scorecard_matches_workbook`: composite within 0.15, pillars within 0.1, grades exact). Readiness has its
own tests. Blank cells are dropped from pillar averages (scorecard.md open item 2).

## Outcomes analysis
None against outcomes: no default panel links composite to default frequency. The replication reproduces the
workbook on the seed snapshot (checks S01 to S03: composite max gap 0.079, pillar max gap 0.05, 18/18 grades).
That proves the port, not the model.

## Limitations
Seed inputs; uncalibrated thresholds; discontinuity from the worst-indicator blend; one fixed stress path for all
countries; momentum signal dead because the `prior` composite is empty (GOV-031).

## Sensitivity (release 0.1.5, recomputed)
Recomputed for EQ-B-0057 on release 0.1.5 settings and the data in `data/` on 2026-10-24 (as_of 2026-10-23, 20,000 requested = 32,768 Sobol paths, seed 7). Base: VaR99 73.00 ±0.69, ES99 95.68 ±0.82, EL 0.471 $mm (± is the batch-means SE, `var99_se_mm` / `es99_se_mm`). n.s. = within 2 SE of base. Full table: [sensitivity-tables.md](sensitivity-tables.md).

The scorecard has no parameter read through `Settings.copy_with` that changes VaR. Its weight in the PDs is
`probability.w_s` (layer 2 table): ±0.01 moves Zimbabwe's PD ±10 pp and EL ±0.3 $mm, VaR99 and ES99 n.s. The
validator step 3 below (perturb `worst_blend`) remains the scorecard's own sensitivity test.

## Use-restriction status
Covered by 6.1 (seed inputs, 15% live coverage).

## Open findings
GOV-009, GOV-010 (High), GOV-011, GOV-036 (High), GOV-039. No new finding.

## Independent validator should re-perform
1. Recompute 10 indicator scores by hand from `rulebook.csv` thresholds for two countries (one floor-bound, one
   not) and compare with `Scorecard.indicator_scores`.
2. Sample 20 live cells against the vintage folder `data/live/vintages/<date>/` and the source API, and 20 seed
   cells against any public source; record the error rate.
3. Perturb `scorecard.worst_blend` and the eligibility weight by +/-50% and report composite rank changes.
4. Once a panel exists: composite at t against default in t+1 (AUC, calibration).
