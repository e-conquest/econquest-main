# Dossier: layer 1 discrete-time hazard

Tier 1. Code: `econquest/engine/layer1_hazard.py` (`run_layer1`, `build_features`),
`econquest/validation/hazard_panel.py` (panel, Firth fit, gate). Parameters: `layer1`, `layer1_paper_coefficients`,
`layer1_fitted`, `ratings_pd`. Sources: `hazard-layer1.md`, `hazard-fit-report.md`. Evidence class: judgement
(paper coefficients); the pilot fit is real data but thin.

## Purpose and use
Base 12-month default PD per country (`pd_model`) from six macro-fiscal and political predictors, reconciled in
log-odds with the rating-implied PD at `hazard_weight 0.5`. It is the prior for layer 2, so it reaches every
reported PD, VaR and ES.

## Conceptual soundness
A logistic hazard is standard (Manasse-Roubini, Savona-Vezzoli). Here the coefficients are the paper's
illustrations on standardised predictors, and location and scale are fitted to the rating PDs, so the hazard
cannot disagree with ratings in level (GOV-006). The fit is dominated by the two SD sovereigns at a judgement
0.60 rating PD (GOV-007). The commodity-gap feature pushes Senegal and Zimbabwe down 2.3 log-odds (GOV-008).

## Data
Live run: Country Profile fields (hand-entered and live mix). Pilot fit: `data/panel/hazard_panel.csv`
(421 country-years, 9 default starts, 15 countries, 1980 to 2025) built from `live/raw_weo.csv` and
`panel/sovereign_defaults.csv`, which was compiled from memory with +/-1 year uncertainty (GOV-044). Selection on
outcome (18 desk countries) is noted in HO-20261023-B-A-002.

## Implementation
`layer1.mode` paper_standardized; fitted mode refuses missing or unaligned inputs (GOV-046, EQ-B-0029).
`calibration_universe` option (EQ-B-0034) pins the cross-sectional fit; off. Tests: `tests/test_layer1_hazard.py`
(9), `test_hazard_panel.py`, `test_cli_fit_hazard.py`.

## Outcomes analysis
Replication (H01 to H20): refitting on the stored panel reproduces the report's coefficients, in-sample AUC 0.882
and OOS AUC 0.780 / Brier 0.0320 exactly. The OOS benchmark does not: it is now the training-window event rate
(EQ-B-0006, after the report), giving base Brier 0.0234 and log loss 0.1166, not 0.0232 and 0.1125. Rebuilding
the panel from raw files with today's builder gives 391 rows, 152 OOS rows, OOS AUC 0.789, Brier 0.0361 (H21
to H25). Either way the model's Brier and log loss are worse than the base rate and the gate (30 events) is not
met: the fit ranks but is not calibrated, and is too thin to adopt.

## Limitations
Paper coefficients; rating-anchored level; no live out-of-sample test of the production PDs; panel thin and
memory-compiled; WEO latest-vintage values (revision look-ahead, `point_in_time none`).

## Sensitivity (release 0.1.5, recomputed)
Recomputed for EQ-B-0057 on release 0.1.5 settings and the data in `data/` on 2026-10-24 (as_of 2026-10-23, 20,000 requested = 32,768 Sobol paths, seed 7). Base: VaR99 73.00 ±0.69, ES99 95.68 ±0.82, EL 0.471 $mm (± is the batch-means SE, `var99_se_mm` / `es99_se_mm`). n.s. = within 2 SE of base. Full table: [sensitivity-tables.md](sensitivity-tables.md#layer-1-hazard).

| Change | VaR99 | ES99 | EL | Largest PD moves (pp) |
|---|---|---|---|---|
| `layer1.hazard_weight` 0.25 | +0.9% n.s. | +0.5% n.s. | +0.69 | ZWE +20.6, SEN +4.3, ZMB +2.8 |
| `layer1.hazard_weight` 0.75 | -1.7% n.s. | 0.0% n.s. | -0.53 | ZWE -23.5, SEN -3.5, ZMB -1.8 |
| `layer1.mode` fitted | no effect: refused, ran paper mode | | | none |

The hazard-versus-rating weight moves the distressed names' PDs by up to 23 pp (Zimbabwe: hazard 0.7% against
rating 60%) and EL by more than its own level, but not the book tail. Fitted mode could not be measured: at
as_of 2026-10-23 with `predictor_lag 0` it needs 2026 WEO values that Venezuela, Senegal and Singapore lack, so the
whole run falls back to paper mode (VF-012).

## Use-restriction status
**6.1 in force (keep).** The gate is not cleared and fitted mode cannot run on today's data (VF-012). See
[use-restrictions-review.md](use-restrictions-review.md).

## Open findings
GOV-006 (High), GOV-007, GOV-008, GOV-009, GOV-044; VF-005 (report not reproducible from raw inputs; GOV-006 text
quotes the superseded 0.0232 base; resolved in EQ-B-0054); VF-012 (new: fitted mode refused at a current-year as_of).

## Independent validator should re-perform
1. Regenerate `hazard-fit-report.md` with `econquest fit-hazard --build-panel` and compare with H-checks.
2. Score `pd_hazard_l1` and `pd_rating` separately on the panel (Brier, AUC) to test `hazard_weight 0.5`.
3. Recheck the 9 event dates in `sovereign_defaults.csv` against CRAG / S&P default studies.
4. Verify Senegal and Zimbabwe `commgap 60` from source data; rerun with the corrected values.
