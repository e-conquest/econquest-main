# Dossier: layer 6 Monte Carlo (VaR, ES, L-VaR, contributions)

Tier 1. Code: `econquest/engine/layer6_montecarlo.py` (`build_positions`, `simulate`, `sobol_path_count`,
`loss_histogram`), `econquest/engine/garch.py::mc_vols` for the marginals. Parameters: `monte_carlo`, `market`,
`liquidity`. Source: `copula-montecarlo-layers5-6.md`, `garch-dcc.md`. Evidence class: simulation verified for
internal consistency and reproducibility; FX and equity vols fitted (GARCH, since 0.1.4); other vols, carry and
position treatment judgement. State: release 0.1.5: Monte Carlo SE published as `var99_se_mm` / `es99_se_mm` /
`lvar99_se_mm` (VF-004 resolved), scenario rate shocks marked at duration x dy (EQ-B-0044).

## Purpose and use
Simulates the 24-position, 309 $mm book over 12 months on 131,072 scrambled-Sobol paths (100,000 requested,
seed 7): VaR and ES at 95/99, ES97.5, liquidity cost, L-VaR, position and country contributions. These are the
reported and limit-tested numbers (limits: VaR99 95, ES99 115, L-VaR99 100, EL 5 $mm).

## Conceptual soundness
One latent variable per country drives both market move and events, so a default always coincides with a bad
market draw (GOV-023). The tail is mainly a market-volatility tail; default is a small share of ES99 (GOV-020).
Positions static for 12 months; CDS leg simplified; long losses capped at notional. GARCH 12-month vols replace
regime vols for FX and equity with documented fallbacks (pegs, administered quotes, persistence >= 0.995).

## Data
Portfolio `data/portfolio.csv`; country table from layers 1 to 4; prices up to as_of for the GARCH fits.

## Implementation
Whole Sobol blocks (EQ-B-0007); severity drawn on default paths only (EQ-B-0041, same losses, 2 s per run);
deterministic given seed. Tests: `tests/test_layer6_montecarlo.py` (16, with characterisation pins),
`test_market_fit_as_of.py`.

## Outcomes analysis
Replication R01 to R05 reproduce the 0.1.4 base to 4 significant figures (74.351 / 96.480 / 0.453 / 79.633);
D05 reproduces the 20,000-path default-is-identical proof exactly. Monte Carlo error at the production count:
seed sd 0.53% on VaR99, 0.36% on ES99 (ten seeds); since 0.1.5 the batch-means SE is in the metrics (VF-004
resolved): 0.31 / 0.36 $mm on the 0.1.5 base (73.11 / 95.41). Backtests: the
120-month history is synthetic (GOV-028, restriction 6.3); the 60-day forecast record covers FX and equity legs
only and is underpowered (GOV-029, restriction 6.4). B01 to B15 reproduce both.

## Limitations
Single latent per country; static book; rate shocks only in scenarios and first order in duration (GOV-027);
liquidity additive; Sobol advantage small at 71 dimensions; EL is net of carry and changes sign under plausible
parameter moves (VF-011). On 0.1.5 L-VaR99 is 78.39, about 5 SE below the 80% warning band; ES99 is at 83% of its
limit, inside the warning band.

## Sensitivity (release 0.1.5, recomputed)
Recomputed for EQ-B-0057 on release 0.1.5 settings and the data in `data/` on 2026-10-24 (as_of 2026-10-23, 20,000 requested = 32,768 Sobol paths, seed 7). Base: VaR99 73.00 ±0.69, ES99 95.68 ±0.82, EL 0.471 $mm (± is the batch-means SE, `var99_se_mm` / `es99_se_mm`). n.s. = within 2 SE of base. Full table: [sensitivity-tables.md](sensitivity-tables.md#layer-6-monte-carlo).

| Change | VaR99 | ES99 | EL |
|---|---|---|---|
| `vol_source` regime (base garch) | 0.0% n.s. | **+2.0%** | +0.07 |
| `market.spread_vol_rel` 30 / 50 (base 40) | -0.5% / +0.0% n.s. | -0.3% / +0.1% n.s. | +0.22 / -0.24 |
| paths 10,000 / 50,000 / 100,000 requested | +0.9% / 0.0% / +0.1% n.s. | +0.7% / -0.1% / -0.3% n.s. | ≤ 0.015 |
| seed 11 / 13 | +1.3% / +1.0% n.s. | -0.6% / -0.3% n.s. | ≤ 0.01 |

SE by path count: VaR99 1.10 / 0.69 / 0.54 / 0.31 and ES99 1.42 / 0.82 / 0.55 / 0.36 $mm at 16,384 / 32,768 /
65,536 / 131,072 Sobol paths. The 100,000-path row (73.11 / 95.41) reproduces the 0.1.5 release base exactly.
Seed changes stay inside 2 SE, so the batch-means SE is consistent with seed dispersion. GARCH versus regime vols is
immaterial for VaR99 and lowers ES99 by 2%. The pre-trade check runs at 20,000 paths, where 2 SE is about 1.4 $mm
VaR99 and 1.6 $mm ES99 (restriction 6.8).

## Use-restriction status
**6.3 keep** (backtest still synthetic), **6.4 keep** (60 backfilled rows). See
[use-restrictions-review.md](use-restrictions-review.md).

## Open findings
GOV-020 (mitigated), GOV-022, GOV-023, GOV-028 (High), GOV-029, GOV-041; VF-001, VF-003, VF-004 (resolved 0.1.5); VF-011 (new: EL net of carry).

## Independent validator should re-perform
1. Run `replicate.py` in full mode; then reprice one Eurobond and one FX position path by path for 10 paths
   from the exported uniforms.
2. Seeds 1 to 10 at 131,072 paths: report sd of VaR99, ES99, L-VaR99 and the probability that L-VaR99 crosses
   the 80% band.
3. Rerun with `use_sobol false` at 262,144 paths and confirm the 0.1.4 numbers within MC error.
4. Decompose ES99 into market and event losses on tail paths to test the "market tail" statement.
