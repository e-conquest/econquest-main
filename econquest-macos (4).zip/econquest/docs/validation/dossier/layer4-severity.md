# Dossier: layer 4 loss severity

Tier 1. Code: `econquest/engine/layer4_severity.py` (`beta_params`, `haircut_distribution`, `sample_haircut`,
`gpd_scale`, `merton_distance_to_distress`, `position_multipliers`, `effective_severity`), position builder in
`layer6_montecarlo.py::build_positions`. Parameters: `market` (LGDs, haircuts), `layer4`, sector and location
multipliers, regime LGD multipliers. Source: `severity-layer4.md`. Evidence class: judgement means; the
Cruces-Trebesch fit code exists and has only been run on a synthetic fixture.

## Purpose and use
Loss given event per position: Beta haircuts on default around `lgd_hard 60` / `lgd_local 35` (sd 0.15, regime
scaled), a Merton distance-to-distress LGD uplift on Eurobond and CDS positions, GPD tails for expropriation and
political violence, fixed transfer losses, sector and location multipliers on equities.

## Conceptual soundness
Beta haircuts with literature-style means are reasonable. A common sd 0.15 for every class and regime is narrow
against Cruces-Trebesch haircuts from under 10% to over 90% (GOV-024). The Merton proxy (exports as liquid assets,
half of FX debt as barrier) is a heuristic sensitive to the barrier floor.

## Data
No restructuring data in the repository. `portfolio.csv` sector and location columns empty, so multipliers reach
only the two equity positions (GOV-025).

## Implementation
Three defects found and fixed on 2026-10-23: Merton uplift not reaching the simulation (GOV-001), GPD clipped
mean below target (GOV-002), Beta floor biasing means near the cap (GOV-005). Since EQ-B-0037 layer 6 passes the
position's asset class. Tests: `tests/test_severity.py` (6), `test_severity_fit.py`, layer 6 pins.

## Outcomes analysis
None: no realised recovery data. The fitted-LGD effect in `severity-layer4.md` (61.77 / 80.88) is on synthetic
haircuts and says only that the switch works.

## Limitations
Judgement means and dispersion; multipliers mostly inert; deterministic transfer loss (15% for the pegs);
`lgd_hard` cap 0.95 binds in scenario B; LGD parameters do not move VaR99/ES99 beyond MC noise on today's book,
so their validation weight is on EL and scenario B.

## Sensitivity (release 0.1.5, recomputed)
Recomputed for EQ-B-0057 on release 0.1.5 settings and the data in `data/` on 2026-10-24 (as_of 2026-10-23, 20,000 requested = 32,768 Sobol paths, seed 7). Base: VaR99 73.00 ±0.69, ES99 95.68 ±0.82, EL 0.471 $mm (± is the batch-means SE, `var99_se_mm` / `es99_se_mm`). n.s. = within 2 SE of base. Full table: [sensitivity-tables.md](sensitivity-tables.md#layer-4-severity).

| Change | VaR99 | ES99 | EL |
|---|---|---|---|
| `layer4.lgd_sd` 0.10 / 0.20 (base 0.15) | +0.4% / -0.4% n.s. | +0.2% / -0.4% n.s. | +0.01 / -0.02 |
| `market.lgd_hard` 50 / 70 (base 60) | -1.6% / +1.1% n.s. | -1.7% / +1.3% n.s. | -0.22 / +0.11 |
| `market.lgd_local` 25 / 45 (base 35) | -1.2% / +0.6% n.s. | -1.0% / +0.7% n.s. | -0.03 / +0.02 |
| `merton.apply_uplift` false | -1.6% n.s. | -0.8% n.s. | **-1.40** |

No layer 4 parameter moves VaR99 or ES99 beyond Monte Carlo noise at ±10 LGD points or ±0.05 sd. The base-run tail
is a market tail, and defaults are a small share of ES99. GOV-024 (unfitted LGDs) therefore matters for EL, for
scenario B (an LGD scenario) and for any book with more defaultable hard-currency exposure, not for today's
headline VaR and ES. The Merton uplift is the largest EL driver in the model: 1.4 $mm, three times the base EL.

## Use-restriction status
Covered by 6.1. No layer 4 specific restriction; nothing to lift.

## Open findings
GOV-024 (part 2: no VaR/ES effect on today's book, EL effect only), GOV-025; VF-002 (resolved EQ-B-0054).

## Independent validator should re-perform
1. Draw 200,000 haircuts for one Eurobond and confirm the clipped mean and sd match `expected_lgd` and `lgd_sd`.
2. Compare the 60/35 means and sd 0.15 with the Cruces-Trebesch distribution by region and decade once Sam's file
   is loaded (`layer4.lgd_source fitted`), and report VaR/ES/EL before and after.
3. Recompute Venezuela's Merton DD and uplift by hand from the country inputs.
