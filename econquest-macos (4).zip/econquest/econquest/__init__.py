"""EconQuest: sovereign tail-risk and geopolitical information-asymmetry engine.

A program that follows the architecture in the paper "Panoptix: Sovereign Tail-Risk and
Geopolitical Information Asymmetry: A Quantitative VaR Framework for Macroeconomic Arbitrage".

Package layout mirrors Appendix B of the paper:

    ingestion/     Data Ingestion Tier (sources, ETL loaders, prediction-market feeds)
    scorecard/     7-pillar, 83-indicator scorecard (Appendix A rulebook)
    engine/        Quantitative Compute Engine: layers 1-6, stress scenarios, pipeline
    validation/    Model governance: Kupiec, Christoffersen, Acerbi-Szekely, Brier
    persistence/   Persistence Layer (SQLite relational + time-series tables, path archive)
    presentation/  Presentation and API tier (JSON REST + SSE, dashboard page)
    cli.py         Command line entry point
"""
__version__ = "0.2.0"
