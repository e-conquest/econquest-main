"""Layer 2: Bayesian log-odds update, scorecard prior and prediction-market integration (paper 3.2).

logit(p_post) = logit(p_model) + w_s (S - S_bar) + sum_k w_k z_k
   z_cds : market log-odds gap, logit(physical PD from the CDS or EMBI spread) - logit(p_model); the
           spread-implied (risk-neutral) PD is divided by probability.risk_premium_ratio first (GOV-013)
   z_fx  : 3-month depreciation in 5-point units (stand-in for the FX implied-vol skew), weighted
           per FX regime by probability.w_fx_regime_scale (GOV-015)
   z_tsi : Text Stress Index z-score: the Country Profile `textz` (0 today; scenarios shock it), plus the
           UCDP/GDELT event stress index when probability.text_index.source is "events" (EQ-B-0033, GOV-014;
           default "none" keeps z_tsi = textz exactly). See engine/event_index.py.
logit(p_final) = (tau_model logit(p_post) + tau_market logit(p_market)) / (tau_model + tau_market)
   tau_market scales with the default contract's open interest up to a reference size.
The arbitrage engine then prices every contract against the model and sizes with fractional Kelly.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from .common import logit, expit, to_horizon, to_12m, logistic_curve, as_of_timestamp
from .event_index import layer2_text_term
from ..config import Settings
from ..ingestion import Universe

DRIVER_MAP = {   # prediction-market driver -> (kind, key)
    "Sovereign default": ("pd", "pd_model"),
    "Sanctions": ("pd", "pd_sa"),
    "Sanctions and geopolitics": ("indicator", "4.10"),
    "Political instability": ("pillar", 4), "Security and violence": ("pillar", 6),
    "Devaluation pressure": ("pillar", 2),
    "Geopolitical risk spike (GPR)": ("indicator", "4.10"),
    "Official backstop stress": ("indicator", "2.6"),
    "Inflation pressure": ("indicator", "5.5"),
    "Growth slowdown": ("indicator", "5.6"),
    "Climate and disaster": ("pillar", 7),
}


PD_FLOOR, PD_CAP = 1e-4, 0.95


def market_implied_pd(spread_bps: np.ndarray, lgd: float) -> np.ndarray:
    """Hazard-rate approximation: PD_12m = spread / LGD, floored and capped. This is a risk-neutral PD."""
    return np.clip(np.asarray(spread_bps, dtype=float) / 1e4 / lgd, PD_FLOOR, PD_CAP)


def physical_pd(spread_bps: np.ndarray, lgd: float, ratio: float, exempt: np.ndarray | None = None) -> np.ndarray:
    """Risk-premium adjustment (GOV-013): physical PD = (spread / LGD) / ratio, floored and capped.

    `ratio` is the risk-neutral-to-physical default-intensity ratio (>= 1; 1 is no adjustment). The ratio
    divides the uncapped spread/LGD so a cap-bound name is not halved twice. Rows where `exempt` is True
    (rated SD/D: the spread prices recovery on a default that has happened) keep ratio 1."""
    if not np.isfinite(ratio) or ratio < 1.0:
        raise ValueError(f"probability.risk_premium_ratio must be >= 1, got {ratio}")
    rn = np.asarray(spread_bps, dtype=float) / 1e4 / lgd
    r = np.full(rn.shape, float(ratio))
    if exempt is not None:
        r = np.where(np.asarray(exempt, dtype=bool), 1.0, r)
    return np.clip(rn / r, PD_FLOOR, PD_CAP)


def fx_regime_weight(fxregime, scale: dict | None) -> np.ndarray:
    """Per-country multiplier on w_fx from the Country Profile `fxregime` (GOV-015).

    `scale` maps regime -> multiplier (e.g. {"Peg": 0.0, "Dollarized": 0.0}); a regime not listed, or a
    missing scale, gets `scale.get("default", 1.0)`."""
    scale = scale or {}
    dflt = float(scale.get("default", 1.0))
    return np.array([float(scale.get(str(g).strip(), dflt)) for g in fxregime], dtype=float)


def posterior(u: Universe, settings: Settings, p_model: pd.Series, composite: pd.Series) -> pd.DataFrame:
    pr = settings["probability"]
    prof = u.countries.set_index("country").loc[u.names]
    lm = logit(p_model.loc[u.names].to_numpy())
    spread = prof["spread"].to_numpy(dtype=float)
    pd_market = market_implied_pd(spread, pr["lgd_market_implied"])          # risk-neutral, kept for benchmarks
    exempt_ratings = {str(x).strip().upper() for x in pr.get("risk_premium_exempt_ratings", ["SD", "D"])}
    exempt = prof["rating"].astype(str).str.strip().str.upper().isin(exempt_ratings).to_numpy()
    pd_market_phys = physical_pd(spread, pr["lgd_market_implied"], float(pr.get("risk_premium_ratio", 1.0)), exempt)
    z_cds = logit(pd_market_phys) - lm
    fx_w = fx_regime_weight(prof["fxregime"] if "fxregime" in prof else [""] * len(prof), pr.get("w_fx_regime_scale"))
    z_fx = prof["fx3m"].to_numpy(dtype=float) / 5.0
    z_tsi, z_event, event_flag = layer2_text_term(prof["textz"].to_numpy(dtype=float), list(prof["iso"] if "iso" in prof else prof.index),
                                                  getattr(u, "events", None), settings)
    dev = composite.loc[u.names].to_numpy() - pr["score_centre"]
    lp = lm + pr["w_s"] * dev + pr["w_m"] * z_cds + pr.get("w_fx", 0.0) * fx_w * z_fx + pr["w_t"] * z_tsi
    return pd.DataFrame({"pd_model": p_model.loc[u.names].to_numpy(), "pd_market": pd_market,
                         "pd_market_phys": pd_market_phys, "score_dev": dev, "z_cds": z_cds, "z_fx": z_fx,
                         "fx_weight": fx_w, "z_tsi": z_tsi, "z_event": z_event, "event_flag": event_flag,
                         "logodds_post": lp, "pd_post": expit(lp)},
                        index=u.names)


def default_contract_prior(u: Universe, settings: Settings, as_of=None) -> pd.DataFrame:
    """12-month-equivalent default probability and tau_market from priced sovereign-default contracts.

    Contract horizons run from the run's as-of date (settings["as_of"]), never the wall clock (GOV-012)."""
    pm = settings["prediction_markets"]
    today = as_of_timestamp(settings, as_of)
    m = u.markets
    m = m[(m["driver"] == "Sovereign default") & m["yes_price"].notna()].copy()
    months = ((m["resolution_date"] - today).dt.days / 30.4375).clip(lower=0.5)
    m["p12"] = to_12m(m["yes_price"].clip(0.01, 0.99), months)
    m["tau"] = pm["tau_market_max"] * np.minimum(1.0, m["open_interest_k"] / pm["reference_oi_k"])
    out = pd.DataFrame({"pm_default": np.nan, "tau_market": 0.0, "pm_oi_k": 0.0}, index=u.names)
    for c, g in m.groupby("country"):
        w = g["open_interest_k"].to_numpy(dtype=float)
        out.at[c, "pm_default"] = float(np.average(g["p12"], weights=w) if w.sum() > 0 else g["p12"].mean())
        out.at[c, "pm_oi_k"] = float(w.sum())
        out.at[c, "tau_market"] = float(pm["tau_market_max"] * min(1.0, w.sum() / pm["reference_oi_k"]))
    return out


def blend_with_market(post: pd.DataFrame, prior: pd.DataFrame, settings: Settings) -> pd.Series:
    pm = settings["prediction_markets"]
    lp = post["logodds_post"].to_numpy()
    if not pm.get("use_market_prior", True):
        return pd.Series(expit(lp), index=post.index)
    tau_mkt = prior["tau_market"].fillna(0).to_numpy()
    lk = np.where(prior["pm_default"].notna(), logit(prior["pm_default"].fillna(0.5)), 0.0)
    lf = (pm["tau_model"] * lp + tau_mkt * lk) / (pm["tau_model"] + tau_mkt)
    return pd.Series(expit(lf), index=post.index)


def arbitrage_scan(u: Universe, settings: Settings, country: pd.DataFrame, scorecard, as_of=None) -> pd.DataFrame:
    """Price every contract against the model and size positions (paper 3.2.1 arbitrage engine).
    Horizons run from the run's as-of date (settings["as_of"])."""
    pm = settings["prediction_markets"]
    rows = []
    today = as_of_timestamp(settings, as_of)
    for _, r in u.markets.iterrows():
        c = r["country"]
        months = max(0.5, (r["resolution_date"] - today).days / 30.4375) if pd.notna(r["resolution_date"]) else 12.0
        kind, key = DRIVER_MAP.get(r["driver"], ("pd", "pd_any"))
        if kind == "pd":
            p12 = float(country.at[c, key])
        elif kind == "indicator":
            p12 = float(logistic_curve(scorecard.indicator_scores.at[key, c], pm["signal_base_prob"], pm["signal_slope"]))
        else:
            p12 = float(logistic_curve(scorecard.pillar_final.at[key, c], pm["signal_base_prob"], pm["signal_slope"]))
        p_res = float(to_horizon(p12, months))
        price = float(r["yes_price"])
        oi = float(r["open_interest_k"]) if pd.notna(r["open_interest_k"]) else 0.0
        side = "Buy Yes" if p_res > price else "Buy No"
        gross_edge = abs(p_res - price) * 100
        net_edge = gross_edge - pm["round_trip_cost_pp"]
        if side == "Buy Yes":
            cost, win_prob = price, p_res
        else:
            cost, win_prob = 1 - price, 1 - p_res
        b = (1 - cost) / cost if cost > 0 else 0.0   # net odds per $1 staked
        kelly = max(0.0, (win_prob * b - (1 - win_prob)) / b) if b > 0 else 0.0
        ev = win_prob * b - (1 - win_prob) - pm["round_trip_cost_pp"] / 100 / cost if cost > 0 else 0.0
        stake = 0.0
        if net_edge >= pm["min_net_edge_pp"] and oi >= pm["min_oi_k"]:
            stake = round(min(kelly * pm["kelly_fraction"] * pm["bankroll_k"], pm["max_share_oi"] * oi), 0)
        if net_edge < 0:
            read = "No edge after costs"
        elif p_res > price:
            read = "Model sees more risk than the market: buy Yes and pair with the related trade"
        else:
            read = "Market sees more risk than the model: buy No, or ask what the market knows"
        rows.append({"id": r["id"], "platform": r["platform"], "country": c, "driver": r["driver"], "contract": r["contract"],
                     "months": round(months, 1), "yes_price": price, "open_interest_k": oi, "model_p12": p12, "model_p_res": p_res,
                     "side": side, "net_edge_pp": net_edge, "ev_per_dollar": ev, "kelly": kelly, "stake_k": stake,
                     "expected_profit_k": stake * ev, "model_minus_market_pp": (p_res - price) * 100,
                     "divergence_flag": abs(p_res - price) * 100 >= pm["divergence_flag_pp"], "read": read,
                     "related_trade": r.get("related_trade", "")})
    return pd.DataFrame(rows)
