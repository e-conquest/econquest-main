"""Risk limits and the pre-trade check (roadmap 4.1).

`load_limits` reads data/limits.json; `check_book` grades a finished run against it, one row per
limit (book VaR/ES/L-VaR/expected loss, per-country gross notional and share of the 99% tail,
per-asset-class notional, per-issuer notional, concentration, Crisis-regime liquidity share);
`pretrade_check` appends a proposed position to the book, reruns the pipeline with the same seed
and path count as the base run, and returns before/after metrics, the marginal VaR and ES, the
limits table after the trade and a verdict: accept, flag (a warning level crossed) or refuse (a
breach). Nothing here changes the data on disk.
"""
from __future__ import annotations
import json
from dataclasses import replace
from pathlib import Path
import numpy as np
import pandas as pd
from ..config import Settings, ASSET_CLASSES
from ..ingestion import Universe
from .pipeline import RunResult, run_pipeline

COLUMNS = ["scope", "name", "measure", "value", "limit", "utilisation", "status"]
BOOK_MEASURES = ("var99_mm", "es99_mm", "lvar99_mm", "expected_loss_mm")


def load_limits(path: str | Path) -> dict:
    """Read the limit set and fill in defaults so every section exists."""
    lim = json.loads(Path(path).read_text())
    lim.setdefault("warning_level", 0.8)
    for sec in ("book", "country", "asset_class", "issuer", "concentration", "liquidity"):
        lim.setdefault(sec, {})
    return lim


def _named_limit(section, name: str) -> float | None:
    """A per-name limit from either a plain number or a {"default": x, "<name>": y} mapping."""
    if section is None:
        return None
    if isinstance(section, (int, float)):
        return float(section)
    if name in section:
        return float(section[name])
    if "default" in section:
        return float(section["default"])
    return None


def _status(value: float, limit: float, warning_level: float) -> tuple[float, str]:
    if limit <= 0:
        util = np.inf if value > 0 else 0.0
    else:
        util = float(value) / float(limit)
    if util >= 1.0:
        return util, "breach"
    if util >= warning_level:
        return util, "warning"
    return util, "pass"


def _row(rows: list, scope: str, name: str, measure: str, value: float, limit: float | None, wl: float):
    if limit is None or not np.isfinite(value):
        return
    util, st = _status(value, limit, wl)
    rows.append({"scope": scope, "name": name, "measure": measure, "value": float(value), "limit": float(limit),
                 "utilisation": float(util), "status": st})


def check_book(run_result: RunResult, universe: Universe, limits: dict) -> pd.DataFrame:
    """One row per limit: scope, name, measure, value, limit, utilisation, status (pass / warning / breach)."""
    wl = float(limits.get("warning_level", 0.8))
    rows: list[dict] = []
    m = run_result.metrics
    pos = run_result.positions
    contrib = run_result.mc.contributions
    gross = float(pos["notional_mm"].sum())
    # Book level
    for k in BOOK_MEASURES:
        _row(rows, "book", "book", k, m.get(k, np.nan), limits["book"].get(k), wl)
    # Country: gross notional and share of the 99% tail
    byc = contrib.groupby("country")[["notional_mm", "tail_contribution_99_mm"]].sum()
    tail_total = float(byc["tail_contribution_99_mm"].sum())
    for c, r in byc.iterrows():
        _row(rows, "country", c, "gross_notional_mm", r["notional_mm"], _named_limit(limits["country"].get("gross_notional_mm"), c), wl)
        share = r["tail_contribution_99_mm"] / tail_total if tail_total > 0 else np.nan
        _row(rows, "country", c, "tail_share_99", share, _named_limit(limits["country"].get("tail_share_99"), c), wl)
    # Asset class
    bya = pos.groupby("asset_class")["notional_mm"].sum()
    for ac, n in bya.items():
        _row(rows, "asset_class", ac, "notional_mm", n, _named_limit(limits["asset_class"].get("notional_mm"), ac), wl)
    # Issuer (country + asset class)
    byi = pos.groupby(["country", "asset_class"])["notional_mm"].sum()
    for (c, ac), n in byi.items():
        name = f"{c} / {ac}"
        _row(rows, "issuer", name, "notional_mm", n, _named_limit(limits["issuer"].get("notional_mm"), name), wl)
    # Concentration: largest single position as a share of gross notional
    if gross > 0 and "largest_position_share" in limits["concentration"]:
        j = pos["notional_mm"].idxmax()
        _row(rows, "concentration", f"largest position ({j})", "largest_position_share", float(pos["notional_mm"].max()) / gross,
             limits["concentration"]["largest_position_share"], wl)
    # Liquidity: notional in countries whose regime is Crisis, as a share of gross notional
    if gross > 0 and "crisis_regime_share" in limits["liquidity"]:
        regime = run_result.country["regime"].reindex(pos["country"]).to_numpy()
        crisis = float(pos["notional_mm"].to_numpy()[regime == "Crisis"].sum()) / gross
        _row(rows, "liquidity", "Crisis-regime countries", "crisis_regime_share", crisis, limits["liquidity"]["crisis_regime_share"], wl)
    return pd.DataFrame(rows, columns=COLUMNS)


def parse_proposal(proposal: dict | str) -> dict:
    """Accept a dict or "country,asset_class,direction,notional_mm[,duration_yrs]"; return a clean position dict."""
    if isinstance(proposal, str):
        parts = [p.strip() for p in proposal.split(",")]
        if len(parts) not in (4, 5):
            raise ValueError("proposal must be 'country,asset_class,direction,notional_mm[,duration_yrs]'")
        proposal = {"country": parts[0], "asset_class": parts[1], "direction": parts[2], "notional_mm": parts[3]}
        if len(parts) == 5 and parts[4] != "":
            proposal["duration_yrs"] = parts[4]
    p = dict(proposal)
    out = {"country": str(p["country"]).strip(), "asset_class": str(p["asset_class"]).strip(),
           "direction": str(p.get("direction", "Long")).strip().capitalize(), "notional_mm": float(p["notional_mm"])}
    ac_map = {a.lower(): a for a in ASSET_CLASSES}
    if out["asset_class"].lower() not in ac_map:
        raise ValueError(f"unknown asset class {out['asset_class']!r}; one of {list(ASSET_CLASSES)}")
    out["asset_class"] = ac_map[out["asset_class"].lower()]
    if out["direction"] not in ("Long", "Short"):
        raise ValueError("direction must be Long or Short")
    if not np.isfinite(out["notional_mm"]) or out["notional_mm"] <= 0:
        raise ValueError("notional_mm must be a positive number")
    dur = p.get("duration_yrs")
    if dur is None or (isinstance(dur, float) and np.isnan(dur)) or str(dur).strip() == "":
        dur = {"Eurobond": 5.0, "Local bond": 5.0, "CDS protection": 5.0}.get(out["asset_class"], np.nan)
    out["duration_yrs"] = float(dur)
    out["sector"] = p.get("sector", np.nan)
    out["location"] = p.get("location", np.nan)
    return out


def _with_position(universe: Universe, prop: dict) -> tuple[Universe, str]:
    port = universe.portfolio.copy()
    pid = "PT1"
    k = 1
    while pid in set(port["id"].astype(str)):
        k += 1; pid = f"PT{k}"
    row = {c: np.nan for c in port.columns}
    row.update({"id": pid, "country": prop["country"], "asset_class": prop["asset_class"], "direction": prop["direction"],
                "notional_mm": prop["notional_mm"], "duration_yrs": prop["duration_yrs"], "sector": prop["sector"], "location": prop["location"]})
    port = pd.concat([port, pd.DataFrame([row])[port.columns]], ignore_index=True)
    return replace(universe, portfolio=port), pid


def _reasons(table: pd.DataFrame, before: pd.DataFrame) -> tuple[list[str], list[str]]:
    prev = before.set_index(["scope", "name", "measure"])["status"] if len(before) else pd.Series(dtype=object)
    breaches, warnings = [], []
    for _, r in table.iterrows():
        if r["status"] == "pass":
            continue
        was = prev.get((r["scope"], r["name"], r["measure"]), "pass")
        tag = "" if was == "pass" else f" (already {was} before the trade)"
        where = r["scope"] if r["name"] == r["scope"] else f"{r['scope']} {r['name']}"   # U21: "book var99_mm", not "book book"
        text = f"{r['status']}: {where} {r['measure']} {r['value']:.3f} vs limit {r['limit']:.3f} ({r['utilisation'] * 100:.0f}%){tag}"
        (breaches if r["status"] == "breach" else warnings).append(text)
    return breaches, warnings


def pretrade_check(universe: Universe, settings: Settings, limits: dict, proposal: dict | str, paths: int = 20000) -> dict:
    """Append the proposed position, rerun the pipeline (same seed and path count before and after) and grade the result."""
    prop = parse_proposal(proposal)
    if prop["country"] not in universe.names:
        raise ValueError(f"unknown country {prop['country']!r}")
    paths = int(paths)
    base = run_pipeline(universe, settings, label="pretrade-before", paths=paths)
    u2, pid = _with_position(universe, prop)
    after = run_pipeline(u2, settings, label="pretrade-after", paths=paths)
    before_tab = check_book(base, universe, limits)
    after_tab = check_book(after, u2, limits)
    breaches, warnings = _reasons(after_tab, before_tab)
    verdict = "refuse" if breaches else "flag" if warnings else "accept"
    keys = ("gross_notional_mm", "net_notional_mm", "expected_loss_mm", "var95_mm", "var99_mm", "es95_mm", "es99_mm",
            "es975_frtb_mm", "liquidity_cost99_mm", "lvar99_mm", "les99_mm")
    mb = {k: float(base.metrics[k]) for k in keys}
    ma = {k: float(after.metrics[k]) for k in keys}
    own = after.mc.contributions.loc[pid]
    # Marginal risk on common random numbers: the after run's paths with the new position's loss column removed.
    # (A separate base run reshuffles the Sobol dimensions, so its difference would carry simulation noise.)
    j = list(after.positions.index).index(pid)
    without = after.mc.losses - after.mc.position_losses[:, j]
    liq_without = ma["liquidity_cost99_mm"] - float(own["liquidity_cost_99_mm"])
    common = _tail_metrics(without, liq_without)
    return {"proposal": {k: (None if isinstance(v, float) and np.isnan(v) else v) for k, v in prop.items()}, "position_id": pid,
            "paths": paths, "seed": int(settings.seed),
            "before": mb, "after": ma, "change": {k: ma[k] - mb[k] for k in keys},
            "before_common_paths": common,
            "marginal_var99_mm": ma["var99_mm"] - common["var99_mm"], "marginal_es99_mm": ma["es99_mm"] - common["es99_mm"],
            "marginal_lvar99_mm": ma["lvar99_mm"] - common["lvar99_mm"],
            "standalone_tail_contribution_99_mm": float(own["tail_contribution_99_mm"]),
            "standalone_expected_loss_mm": float(own["expected_loss_mm"]),
            "verdict": verdict, "reasons": breaches + warnings, "breaches": breaches, "warnings": warnings,
            "limits_after": after_tab, "limits_before": before_tab}


def _tail_metrics(losses: np.ndarray, liq_total: float) -> dict:
    q = lambda a: float(np.quantile(losses, a))
    es = lambda v: float(losses[losses >= v].mean()) if np.any(losses >= v) else v
    var99 = q(0.99)
    return {"expected_loss_mm": float(losses.mean()), "var95_mm": q(0.95), "var99_mm": var99, "es95_mm": es(q(0.95)),
            "es99_mm": es(var99), "liquidity_cost99_mm": float(liq_total), "lvar99_mm": var99 + float(liq_total)}


def pretrade_to_dict(result: dict) -> dict:
    """JSON-ready copy of a pretrade_check result (tables become record lists)."""
    out = dict(result)
    for k in ("limits_after", "limits_before"):
        if isinstance(out.get(k), pd.DataFrame):
            out[k] = out[k].to_dict(orient="records")
    return out
