"""Stress scenarios (paper section 9) and reverse stress (roadmap 3.4).

Scenarios live in data/scenarios.json as lists of shocks, so an analyst can add or edit one without
touching code. A shock is one of:

  {"target": "countries",  "column": "spread", "op": "add"|"mul"|"set", "value": 280, "where": {...}}
  {"target": "countries",  "column": "rating", "op": "notch", "value": -2, "where": {...}}   (rating ladder)
  {"target": "indicators", "id": "2.1", "op": "mul", "value": 0.8, "where": {...}}
  {"target": "indicators", "id": "1.3", "op": "mul_by_indicator", "ref": "1.5", "coef": 0.004}  (factor 1 + coef*ref)
  {"target": "trigger",    "pillar": 2, "value": 18, "where": {...}}          (adds a trigger add-on row)
  {"target": "portfolio",  "column": "location", "op": "set", "value": "Active warzone", "where": {...}}
  {"target": "settings",   "key": "market.lgd_hard", "op": "add"|"mul"|"set", "value": 18, "min": .., "max": ..}
  {"target": "settings",   "key": "liquidity.by_asset.*.spread_mean", "op": "mul", "value": 2}  (* = every child)
  {"target": "settings",   "key": "regime.*.global_loading", "op": "add", "value": 0.25, "max": 0.9}

  {"target": "rates",      "leg": "local"|"hard", "value": 200, "where": {...}}  (yield level shock in bp, EQ-B-0044)

  {"target": "contagion",  "origin": "Brazil", "column": "spread", "op": "add", "value": 400,
   "exposures": "live/raw_bis_cbs.csv", "normalise": "max", "where": {...}}               (BIS common-creditor channel)

A rates shock moves the yield level of the book's bonds by `value` bp (add only; value*scale): leg "local"
reaches Local bond positions, leg "hard" Eurobond positions (the US Treasury curve under a USD Eurobond),
restricted to the countries in `where`. It is written to the position as `rate_shock_bp` and Layer 6 books a
deterministic mark-to-market loss of duration_yrs * dy / 1e4 of notional on every path (first-order, no
convexity, no carry change; long positions lose when yields rise). Several rates shocks on one position add.

A contagion shock spreads a credit shock in the origin country to every other country in proportion
to how much they share its foreign bank creditors (BIS consolidated banking statistics, claims of
creditor banking system k on country x, C[k, x]). With s[k|x] = C[k, x] / sum_k C[k, x] the share of
x's reported foreign bank claims held by creditor k, the receiver weight is the common-lender index
w_i = sum_k s[k|o] * s[k|i] (0 to 1; 1 only if both owe everything to one creditor). With
"normalise": "max" (default) weights are divided by the largest receiver weight, so the most exposed
peer takes the full `value` and the rest pro rata; "none" uses w_i as is. The receiver gets
value * scale * weight on `column` (op add) or 1 + (value - 1) * scale * weight (op mul); the origin
itself is not touched (shock it with ordinary country shocks). Countries absent from the exposure
file get weight 0. `exposures` is a path relative to the scenarios.json folder and must stay inside it;
`period` picks a reporting period (default: the latest in the file). A scenario whose exposure file
is missing is left out of `load_scenarios` (listed in `UNAVAILABLE` with the reason) unless
include_unavailable=True, so the stress commands keep running until the BIS data is in.

`where` selects countries (for indicators and trigger shocks too) with AND-ed clauses on any
countries.csv column: {"region_in": ["Asia"], "spread_gte": 300, "rating_in": [...], "exptype_eq":
"Commodity", "country_not_in": [...]} (suffixes _in, _not_in, _eq, _gte, _gt, _lte, _lt). `tier`
(desk_current, EM, frontier, DM_anchor) also works when countries.csv has no tier column: it is then
read from data/panel/universe_proposal.csv by ISO3 (`country_tiers`, EQ-B-0043), e.g.
{"region_not_in": ["Asia"], "tier_not_in": ["DM_anchor"]} keeps the seven DM anchors out of an EM shock.

Every scenario takes a severity `scale`: add shocks become value*scale, mul shocks 1+(value-1)*scale,
set and notch shocks apply unchanged when scale > 0 (notch rounds value*scale). `reverse_stress`
searches the scale at which a book limit breaks; `single_factor_reverse` does the same for one
factor at a time (spread, FX, LGD, PD multiplier, copula loading).
"""
from __future__ import annotations
import warnings
import json
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable
import numpy as np
import pandas as pd
from ..config import Settings
from ..ingestion import Universe
from .tiers import TIERS, tier_by_iso      # the shared tier reader (EQ-B-0055)

RATING_LADDER = ["AAA", "AA+", "AA", "AA-", "A+", "A", "A-", "BBB+", "BBB", "BBB-", "BB+", "BB", "BB-", "B+", "B", "B-", "CCC+", "CCC", "CCC-", "CC", "SD"]


def _clone(u: Universe) -> Universe:
    return Universe(u.countries.copy(), u.indicators.copy(), u.rulebook.copy(), u.adjustments.copy(), u.portfolio.copy(), u.markets.copy(), dict(u.provenance), u.gpr, u.playbook, u.weo_raw, u.prices)


def _proposal_path(base_dir=None) -> Path:
    for d in (base_dir, DATA_DIR):
        if d is not None and (Path(d) / "panel" / "universe_proposal.csv").is_file():
            return Path(d) / "panel" / "universe_proposal.csv"
    return DATA_DIR / "panel" / "universe_proposal.csv"


def country_tiers(countries: pd.DataFrame, base_dir=None) -> pd.Series:
    """Universe tier per country (desk_current, EM, frontier, DM_anchor), aligned to `countries`.

    Source, in order (EQ-B-0043): a `tier` column on the countries table (Country Profile) when it is
    there and non-blank; else the `tier` bucket of data/panel/universe_proposal.csv matched on ISO3
    (`iso` -> `iso3`); else "unknown". The Country Profile has no tier column today (handoff to Team A
    under EQ-B-0043), so the proposal file is the working source. A country with tier "unknown" fails
    every `tier_in` clause and passes every `tier_not_in` clause."""
    out = pd.Series("unknown", index=countries.index, dtype=object)
    if "tier" in countries.columns:
        own = countries["tier"].astype(object).where(countries["tier"].notna(), "").astype(str).str.strip()
        out = out.where(own == "", own)
    todo = out == "unknown"
    if todo.any() and "iso" in countries.columns:
        mapped = countries.loc[todo, "iso"].map(tier_by_iso(_proposal_path(base_dir)))
        out.loc[todo] = mapped.where(mapped.notna(), "unknown")
    unknown = out == "unknown"
    if unknown.any():
        # fail-open for tier_not_in: say so, so a DM name missing from the proposal is not silently given EM shocks
        names = countries.loc[unknown, "country"] if "country" in countries.columns else countries.index[unknown]
        warnings.warn(f"tier unknown for {', '.join(map(str, list(names)[:10]))}{' ...' if unknown.sum() > 10 else ''}: "
                      "they pass every tier_not_in clause", RuntimeWarning, stacklevel=2)
    return out


def select(countries: pd.DataFrame, where: dict | None, base_dir=None) -> pd.Series:
    """Boolean mask over the countries table from AND-ed `where` clauses. `tier` clauses use
    `country_tiers` when the table has no tier column (`base_dir` locates panel/universe_proposal.csv)."""
    mask = pd.Series(True, index=countries.index)
    for key, val in (where or {}).items():
        for suf in ("_not_in", "_in", "_eq", "_gte", "_gt", "_lte", "_lt"):
            if key.endswith(suf):
                col = key[: -len(suf)]; break
        else:
            raise ValueError(f"where clause {key!r} needs a suffix _in/_not_in/_eq/_gte/_gt/_lte/_lt")
        if col == "tier":
            bad = [t for t in ([val] if isinstance(val, str) else list(val)) if t not in TIERS]
            if bad:
                raise ValueError(f"where clause {key!r}: unknown tier {bad}; tiers are {list(TIERS)}")
            s = country_tiers(countries, base_dir)
        elif col not in countries.columns:
            raise ValueError(f"where clause on unknown column {col!r}")
        else:
            s = countries[col]
        if suf == "_in": m = s.isin(val)
        elif suf == "_not_in": m = ~s.isin(val)
        elif suf == "_eq": m = s == val
        else:
            x = pd.to_numeric(s, errors="coerce")
            m = {"_gte": x >= val, "_gt": x > val, "_lte": x <= val, "_lt": x < val}[suf]
        mask &= m.fillna(False)
    return mask


def _scaled(op: str, value, scale: float):
    if op == "add": return value * scale
    if op == "mul": return 1.0 + (value - 1.0) * scale
    if op == "notch": return int(round(value * scale))
    return value


def _apply_num(series: pd.Series, op: str, v):
    x = pd.to_numeric(series, errors="coerce")
    if op == "add": return x + v
    if op == "mul": return x * v
    if op == "set": return pd.Series(v, index=series.index)
    raise ValueError(f"unknown op {op!r}")


def _notch(rating: str, n: int) -> str:
    if rating not in RATING_LADDER: return rating
    return RATING_LADDER[int(np.clip(RATING_LADDER.index(rating) + (-n), 0, len(RATING_LADDER) - 1))]


def _settings_keys(raw: dict, dotted: str) -> list[str]:
    """Expand a dotted key with `*` wildcards against the settings tree."""
    parts = dotted.split("."); out = [[]]
    node_for = lambda path: _walk(raw, path)
    for p in parts:
        nxt = []
        for path in out:
            node = node_for(path)
            if p == "*":
                if isinstance(node, dict): nxt += [path + [k] for k in node]
            else:
                nxt.append(path + [p])
        out = nxt
    if "*" in dotted:            # a wildcard only expands to children that exist
        out = [p for p in out if _walk(raw, p) is not None]
    return [".".join(p) for p in out]


def _walk(raw, path):
    node = raw
    for p in path:
        if not isinstance(node, dict) or p not in node: return None
        node = node[p]
    return node


DATA_DIR = Path(__file__).resolve().parents[2] / "data"
BIS_CBS_COLUMNS = {"creditor": ("creditor_iso2", "creditor", "L_REP_CTY"), "debtor": ("debtor_iso3", "debtor_iso2", "debtor", "L_CP_COUNTRY"),
                   "period": ("period", "TIME_PERIOD"), "claims": ("claims_usd_mn", "claims", "OBS_VALUE")}


def _exposure_path(sh: dict, base_dir) -> Path:
    """The contagion exposure file: a path relative to the scenarios folder (the data dir), and it must stay
    inside it. Absolute paths and paths that leave the folder (`..`, symlinks out) are refused (EQ-B-0047)."""
    root = Path(base_dir or DATA_DIR).resolve()
    p = Path(str(sh["exposures"]))
    if p.is_absolute():
        raise ValueError(f"contagion exposures must be a path relative to the data folder, got an absolute path ({p.name})")
    full = (root / p).resolve()
    if not full.is_relative_to(root):
        raise ValueError(f"contagion exposures path leaves the data folder: {sh['exposures']!r}")
    return full


def load_bilateral_exposures(path: str | Path, countries: pd.DataFrame | None = None, period: str | None = None) -> pd.DataFrame:
    """Creditor x debtor matrix of foreign bank claims (USD mn) from a BIS consolidated banking
    statistics extract, one period.

    Accepts the normalised long form proposed for Team A (`creditor_iso2, debtor_iso3, period,
    claims_usd_mn[, basis, source]`) or the raw BIS SDMX CSV (`L_REP_CTY, L_CP_COUNTRY,
    TIME_PERIOD, OBS_VALUE`, filtered to L_POSITION C and L_MEASURE S when those columns exist).
    BIS aggregate reporters (codes starting with a digit, e.g. 5A all reporting countries) are
    dropped. Debtor ISO2 codes are mapped to ISO3 through `countries` (iso2 -> iso). Rows = creditor,
    columns = debtor ISO3. Refuses a missing file with a message naming what is needed."""
    p = Path(path)
    if not p.is_file():
        raise FileNotFoundError(f"BIS bilateral exposure file not found: {p}. It needs BIS consolidated banking statistics "
                                "(WS_CBS_PUB, foreign claims by reporting banking system on each sovereign in data/countries.csv); "
                                "data/live/raw_bis.csv holds only EER, credit gap and policy rates (handoff to Team A, EQ-B-0037).")
    raw = pd.read_csv(p, comment="#", dtype=str)
    cols = {}
    for key, aliases in BIS_CBS_COLUMNS.items():
        hit = [a for a in aliases if a in raw.columns]
        if not hit:
            raise ValueError(f"exposure file {p.name} lacks a {key} column (one of {aliases}); it has {len(raw.columns)} other columns")
        cols[key] = hit[0]
    if "L_POSITION" in raw: raw = raw[raw["L_POSITION"] == "C"]
    if "L_MEASURE" in raw: raw = raw[raw["L_MEASURE"] == "S"]
    df = pd.DataFrame({k: raw[c] for k, c in cols.items()})
    df["claims"] = pd.to_numeric(df["claims"], errors="coerce")
    df = df[df["claims"].notna() & ~df["creditor"].str[0].str.isdigit()]
    per = period or df["period"].max()
    df = df[df["period"] == per]
    if df.empty:
        raise ValueError(f"exposure file {p.name} has no rows for period {per!r}")
    if countries is not None:
        iso2 = dict(zip(countries["iso2"], countries["iso"]))
        df = df.assign(debtor=df["debtor"].map(lambda d: iso2.get(d, d)))
    mat = df.pivot_table(index="creditor", columns="debtor", values="claims", aggfunc="sum").fillna(0.0)
    mat.attrs.update(period=per, source_file=str(p), synthetic="synthetic" in p.name.lower())
    return mat


def common_lender_weights(mat: pd.DataFrame, origin_iso: str, normalise: str = "max") -> pd.Series:
    """w_i = sum_k s[k|origin] s[k|i] with s[k|x] = C[k, x] / sum_k C[k, x], creditor k's share of
    x's reported foreign bank claims (BIS foreign claims exclude a banking system's claims on its own
    country). Returned per debtor ISO3, origin excluded."""
    if origin_iso not in mat.columns:
        raise ValueError(f"origin {origin_iso} has no bilateral claims in the exposure file")
    tot = mat.sum(axis=0)
    share = mat.div(tot.where(tot > 0), axis=1).fillna(0.0)
    w = share.mul(share[origin_iso], axis=0).sum(axis=0).drop(origin_iso)
    if normalise == "max":
        w = w / w.max() if w.max() > 0 else w
    elif normalise != "none":
        raise ValueError(f"normalise must be 'max' or 'none', got {normalise!r}")
    return w


def contagion_weights(countries: pd.DataFrame, sh: dict, base_dir=None) -> pd.Series:
    """Receiver weights keyed by country name for one contagion shock."""
    mat = load_bilateral_exposures(_exposure_path(sh, base_dir), countries, sh.get("period"))
    iso = dict(zip(countries["country"], countries["iso"]))
    if sh["origin"] not in iso:
        raise ValueError(f"contagion origin {sh['origin']!r} is not in countries.csv")
    w = common_lender_weights(mat, iso[sh["origin"]], sh.get("normalise", "max"))
    by_iso = {v: k for k, v in iso.items()}
    return pd.Series({by_iso[i]: float(v) for i, v in w.items() if i in by_iso}, dtype=float)


RATE_LEGS = {"local": ("Local bond",), "hard": ("Eurobond",)}    # rates shock leg -> asset classes it reprices (EQ-B-0044)


def apply_shocks(u: Universe, s: Settings, shocks: list[dict], scale: float = 1.0, base_dir: str | Path | None = None) -> tuple[Universe, Settings]:
    """Apply a scenario's shock list at the given severity scale; returns new Universe and Settings.
    `base_dir` resolves relative data paths in contagion shocks (default: the repository data folder)."""
    u2 = _clone(u); c = u2.countries
    patches: dict = {}
    trigger_rows = []
    if scale <= 0:
        return u2, s.copy_with()
    for sh in shocks:
        t = sh["target"]; op = sh.get("op", "add" if t != "trigger" else "set")
        if t == "countries":
            m = select(c, sh.get("where"), base_dir); col = sh["column"]
            if op == "notch":
                n = _scaled(op, sh["value"], scale)
                c.loc[m, col] = c.loc[m, col].map(lambda r, n=n: _notch(r, n))
            elif op == "set" and (isinstance(sh["value"], (str, bool)) or c[col].dtype == object):
                c.loc[m, col] = sh["value"]
            else:
                c.loc[m, col] = _apply_num(c.loc[m, col], op, _scaled(op, sh["value"], scale))
        elif t == "indicators":
            m = select(c, sh.get("where"), base_dir); names = list(c.loc[m, "country"])
            ind = u2.indicators.set_index("id")
            if op == "mul_by_indicator":
                ref = pd.to_numeric(ind.loc[sh["ref"], names], errors="coerce")
                factor = 1.0 + sh["coef"] * scale * ref
                ind.loc[sh["id"], names] = pd.to_numeric(ind.loc[sh["id"], names], errors="coerce") * factor
            else:
                ind.loc[sh["id"], names] = _apply_num(ind.loc[sh["id"], names], op, _scaled(op, sh["value"], scale)).values
            u2.indicators = ind.reset_index()
        elif t == "trigger":
            m = select(c, sh.get("where"), base_dir); names = set(c.loc[m, "country"])
            row = {"block": "Trigger inputs (before cap)", "pillar": int(sh["pillar"]), "item": sh.get("item", f"Scenario trigger pillar {sh['pillar']}"), "rule": sh.get("rule", "scenario")}
            for n in c["country"]:
                row[n] = sh["value"] * scale if n in names else 0.0
            trigger_rows.append(row)
        elif t == "portfolio":
            p = u2.portfolio; col = sh["column"]
            m = p["country"].isin(set(c.loc[select(c, sh.get("where"), base_dir), "country"])) if sh.get("where") else pd.Series(True, index=p.index)
            if op == "set": p.loc[m, col] = sh["value"]
            else: p.loc[m, col] = _apply_num(p.loc[m, col], op, _scaled(op, sh["value"], scale))
        elif t == "rates":
            leg = sh.get("leg", "local")
            if leg not in RATE_LEGS:
                raise ValueError(f"rates leg must be one of {sorted(RATE_LEGS)}, got {leg!r}")
            if op != "add":
                raise ValueError(f"rates op must be add (a yield change in bp), got {op!r}")
            p = u2.portfolio
            if "rate_shock_bp" not in p.columns:
                p["rate_shock_bp"] = 0.0
            m = p["asset_class"].isin(RATE_LEGS[leg])
            if sh.get("where"):
                m &= p["country"].isin(set(c.loc[select(c, sh.get("where"), base_dir), "country"]))
            p.loc[m, "rate_shock_bp"] = pd.to_numeric(p.loc[m, "rate_shock_bp"], errors="coerce").fillna(0.0) + float(sh["value"]) * scale
        elif t == "contagion":
            w = contagion_weights(c, sh, base_dir)
            m = select(c, sh.get("where"), base_dir) & (c["country"] != sh["origin"])
            col = sh["column"]; wv = w.reindex(c["country"]).fillna(0.0).to_numpy()
            x = pd.to_numeric(c.loc[m, col], errors="coerce")
            if op == "add":
                c.loc[m, col] = x + sh["value"] * scale * wv[m.to_numpy()]
            elif op == "mul":
                c.loc[m, col] = x * (1.0 + (sh["value"] - 1.0) * scale * wv[m.to_numpy()])
            else:
                raise ValueError(f"contagion op must be add or mul, got {op!r}")
        elif t == "settings":
            for key in _settings_keys(s.raw, sh["key"]):
                cur = s.get(*key.split("."))
                if cur is None and op != "set":
                    raise ValueError(f"settings key {key!r} not found")
                v = _scaled(op, sh["value"], scale)
                new = cur + v if op == "add" else cur * v if op == "mul" else v
                if "min" in sh: new = max(sh["min"], new)
                if "max" in sh: new = min(sh["max"], new)
                patches[key] = new
        else:
            raise ValueError(f"unknown shock target {t!r}")
    if trigger_rows:
        u2.adjustments = pd.concat([u2.adjustments, pd.DataFrame(trigger_rows)], ignore_index=True)
    if any(k == "market.equity_vol" or k.startswith("market.fx_vol") for k in patches) \
            and not s.get("monte_carlo", "garch_vol", "anchor", default=None):
        # GARCH vols scale by stressed / unstressed market vol: record the governed values before the patch (EQ-B-0047)
        patches["monte_carlo.garch_vol.anchor"] = {"fx_vol": dict(s["market"]["fx_vol"]), "equity_vol": s["market"]["equity_vol"]}
    return u2, s.copy_with(**patches)


@dataclass
class Scenario:
    key: str
    name: str
    description: str
    shocks: list[dict] = field(default_factory=list)
    source: str = ""
    kind: str = "hypothetical"      # hypothetical | historical | reverse
    fn: Callable | None = None      # legacy code scenario (tests only)
    base_dir: str | None = None     # folder that relative data paths in shocks resolve against

    def apply(self, u: Universe, s: Settings, scale: float = 1.0) -> tuple[Universe, Settings]:
        if self.fn is not None:
            return self.fn(u, s)
        return apply_shocks(u, s, self.shocks, scale, base_dir=self.base_dir)

    def missing_data(self) -> list[str]:
        """Data files the scenario's shocks need that are not on disk."""
        need = [str(_exposure_path(sh, self.base_dir)) for sh in self.shocks if sh.get("target") == "contagion"]
        return [f for f in dict.fromkeys(need) if not Path(f).is_file()]

    def to_dict(self) -> dict:
        return {"key": self.key, "name": self.name, "description": self.description, "kind": self.kind, "source": self.source, "shocks": self.shocks}


UNAVAILABLE: dict[str, str] = {}     # scenarios left out by the last load_scenarios call, with the reason


def load_scenarios(path: str | Path, include_unavailable: bool = False) -> dict[str, Scenario]:
    """Read data/scenarios.json into {key: Scenario}, in file order. Scenarios whose data files are
    missing (a contagion shock without its BIS exposure file) are left out and recorded in
    `UNAVAILABLE`, unless include_unavailable=True."""
    spec = json.loads(Path(path).read_text())
    base_dir = str(Path(path).resolve().parent)
    out = {}; UNAVAILABLE.clear()
    for sc in spec["scenarios"]:
        obj = Scenario(sc["key"], sc["name"], sc.get("description", ""), sc["shocks"], sc.get("source", ""), sc.get("kind", "hypothetical"), base_dir=base_dir)
        missing = obj.missing_data()
        if missing and not include_unavailable:
            UNAVAILABLE[obj.key] = "missing " + ", ".join(missing)
            continue
        out[sc["key"]] = obj
    return out


def default_scenarios() -> dict[str, Scenario]:
    return load_scenarios(Path(__file__).resolve().parents[2] / "data" / "scenarios.json")


def summarise_shocks(shocks: list[dict], scale: float = 1.0) -> list[str]:
    """Human-readable shock lines at a given scale (for the reverse stress report)."""
    out = []
    for sh in shocks:
        t = sh["target"]; op = sh.get("op", "set"); v = sh.get("value")
        where = ", ".join(f"{k}={val}" for k, val in (sh.get("where") or {}).items())
        tgt = {"countries": sh.get("column"), "indicators": f"indicator {sh.get('id')}", "trigger": f"pillar {sh.get('pillar')} trigger", "portfolio": sh.get("column"), "settings": sh.get("key"),
               "contagion": f"{sh.get('column')} via BIS common creditors of {sh.get('origin')}",
               "rates": f"{sh.get('leg', 'local')} bond yields (duration mark-to-market)"}[t]
        if t == "trigger": txt = f"{tgt} +{v*scale:.3g} points"
        elif t == "contagion": txt = f"{tgt}, up to {v*scale:+.3g}" if op == "add" else f"{tgt}, up to x{1+(v-1)*scale:.3g}"
        elif t == "rates": txt = f"{tgt} {v*scale:+.3g} bp"
        elif op == "add": txt = f"{tgt} {v*scale:+.3g}"
        elif op == "mul": txt = f"{tgt} x{1+(v-1)*scale:.3g}"
        elif op == "notch": txt = f"{tgt} {int(round(v*scale)):+d} notches"
        elif op == "mul_by_indicator": txt = f"{tgt} x(1 + {sh['coef']*scale:.3g} * indicator {sh['ref']})"
        else: txt = f"{tgt} = {v}"
        out.append(txt + (f" [{where}]" if where else ""))
    return out


def compare(base, stressed) -> dict:
    bm, sm = base.metrics, stressed.metrics
    keys = ("var99_mm", "es99_mm", "es975_frtb_mm", "lvar99_mm", "liquidity_cost99_mm", "expected_loss_mm")
    out = {k: {"base": bm[k], "stress": sm[k], "change_pct": (sm[k] / bm[k] - 1) * 100 if bm[k] else None} for k in keys}
    out["regimes"] = {"base": base.country["regime"].value_counts().to_dict(), "stress": stressed.country["regime"].value_counts().to_dict()}
    out["share_to_crisis"] = float(((base.country["regime"] != "Crisis") & (stressed.country["regime"] == "Crisis")).mean())
    out["mean_pd_default_change_pp"] = float((stressed.country["pd_default"] - base.country["pd_default"]).mean() * 100)
    out["mean_lgd_change_pp"] = float((stressed.country["lgd_hard_expected"] - base.country["lgd_hard_expected"]).mean() * 100)
    return out


# ---------------------------------------------------------------- reverse stress

SINGLE_FACTORS = {
    "spread_bp":   {"label": "sovereign spreads", "unit": "bp", "max": 3000, "shocks": [{"target": "countries", "column": "spread", "op": "add", "value": 1.0}]},
    "fx_pct":      {"label": "EM currencies (3-month move, floats and managed)", "unit": "% depreciation", "max": 80, "shocks": [{"target": "countries", "column": "fx3m", "op": "add", "value": 1.0, "where": {"fxregime_in": ["Float", "Managed"]}}]},
    "lgd_pp":      {"label": "hard-currency LGD", "unit": "pp", "max": 35, "shocks": [{"target": "settings", "key": "market.lgd_hard", "op": "add", "value": 1.0, "max": 95}]},
    "pd_mult":     {"label": "default PD multiplier (all regimes)", "unit": "x", "max": 6.0, "shocks": [{"target": "settings", "key": "regime.*.pd_mult", "op": "mul", "value": 2.0}]},
    "loading":     {"label": "global copula loading", "unit": "added", "max": 0.75, "shocks": [{"target": "settings", "key": "regime.*.global_loading", "op": "add", "value": 1.0, "max": 0.95}]},
    "downgrade":   {"label": "rating notches (every sovereign)", "unit": "notches", "max": 6, "shocks": [{"target": "countries", "column": "rating", "op": "notch", "value": 1}]},
}


def _book_limit(limits: dict, measure: str) -> float:
    lim = (limits.get("book") or {}).get(measure)
    if lim is None:
        raise ValueError(f"no book limit for {measure!r} in limits.json")
    return float(lim)


def reverse_stress(u: Universe, s: Settings, scenario: Scenario, limits: dict, measure: str = "var99_mm", paths: int = 20000,
                   scale_max: float = 4.0, tol: float = 0.05, max_iter: int = 10, base=None, log=None) -> dict:
    """Smallest severity scale of `scenario` at which the book `measure` breaches its limit.

    Bisection on the scale in [0, scale_max] with the same seed and path count for every run (common
    random numbers make the metric close to monotone in the scale). Returns the breaching scale, the
    metric path, the implied shock sizes at that scale and which other book limits are also breached.
    """
    from .pipeline import run_pipeline
    limit = _book_limit(limits, measure)
    base = base or run_pipeline(u, s, label="rs-base", paths=paths)
    hist = [{"scale": 0.0, "value": float(base.metrics[measure])}]
    def metric_at(k):
        u2, s2 = scenario.apply(u, s, scale=k)
        r = run_pipeline(u2, s2, label=f"rs-{scenario.key}", paths=paths)
        hist.append({"scale": k, "value": float(r.metrics[measure])})
        if log: log(f"  scale {k:.3f}: {measure} {r.metrics[measure]:.2f} (limit {limit:.2f})")
        return r
    if hist[0]["value"] >= limit:
        return {"scenario": scenario.key, "scenario_name": scenario.name, "measure": measure, "limit": limit, "base": hist[0]["value"], "breach_scale": 0.0, "status": "already breached", "path": hist, "shocks_at_breach": [], "paths": paths}
    r_hi = metric_at(scale_max)
    if r_hi.metrics[measure] < limit:
        return {"scenario": scenario.key, "scenario_name": scenario.name, "measure": measure, "limit": limit, "base": hist[0]["value"], "breach_scale": None, "status": f"no breach up to scale {scale_max}", "path": hist,
                "shocks_at_breach": summarise_shocks(scenario.shocks, scale_max), "paths": paths, "value_at_max": float(r_hi.metrics[measure])}
    lo, hi, r_at = 0.0, scale_max, r_hi
    for _ in range(max_iter):
        if hi - lo <= tol: break
        mid = (lo + hi) / 2; r = metric_at(mid)
        if r.metrics[measure] >= limit: hi, r_at = mid, r
        else: lo = mid
    from .limits import check_book
    table = check_book(r_at, u, limits)
    other = table[(table["status"] == "breach")][["scope", "name", "measure", "value", "limit", "utilisation"]].to_dict("records")
    return {"scenario": scenario.key, "scenario_name": scenario.name, "measure": measure, "limit": limit, "base": hist[0]["value"], "breach_scale": hi, "scale_bracket": [lo, hi],
            "value_at_breach": float(r_at.metrics[measure]), "status": "breach found", "path": sorted(hist, key=lambda x: x["scale"]),
            "shocks_at_breach": summarise_shocks(scenario.shocks, hi), "other_breaches": other, "regimes_at_breach": r_at.country["regime"].value_counts().to_dict(), "paths": paths}


def single_factor_reverse(u: Universe, s: Settings, limits: dict, factor: str, measure: str = "var99_mm", paths: int = 20000, base=None, log=None) -> dict:
    """Reverse stress on one factor: the smallest move (in the factor's own unit) that breaches the limit."""
    f = SINGLE_FACTORS[factor]
    sc = Scenario(factor, f["label"], f"single factor: {f['label']}", f["shocks"], kind="reverse")
    res = reverse_stress(u, s, sc, limits, measure, paths, scale_max=f["max"], tol=f["max"] / 64, base=base, log=log)
    res.update({"factor": factor, "label": f["label"], "unit": f["unit"]})
    if res["breach_scale"] is not None:
        res["breach_size"] = res["breach_scale"] if f["shocks"][0]["op"] != "mul" else 1 + (f["shocks"][0]["value"] - 1) * res["breach_scale"]
    return res


# ---------------------------------------------------------------- legacy code scenarios (kept for the regression test against data/scenarios.json)

def _legacy_a(u: Universe, s: Settings):
    """+200 bps Fed shock: HY spreads +280 bps, EM currencies -12 to -18%, FX-vol skew up, R +0.25, frontier Stressed -> Crisis."""
    u2 = _clone(u); c = u2.countries
    hy = c["spread"] >= 300
    em = country_tiers(c) != "DM_anchor"            # DM anchors take no EM spread or currency shock (EQ-B-0043)
    c.loc[hy, "spread"] = c.loc[hy, "spread"] + 280
    c.loc[~hy & (c["region"] != "Asia") & em, "spread"] = c.loc[~hy & (c["region"] != "Asia") & em, "spread"] * 1.5
    c.loc[em, "fx3m"] = c.loc[em, "fx3m"] + c.loc[em, "rating"].map(lambda r: 18.0 if r in ("B", "B-", "CCC+", "CCC", "SD") else 12.0)
    c["textz"] = c["textz"] + 1.0
    ind = u2.indicators.set_index("id"); names = list(c["country"])
    fxshare = ind.loc["1.5", names].astype(float)
    ind.loc["1.3", names] = ind.loc["1.3", names].astype(float) * (1 + 0.4 * fxshare / 100)   # debt-ratio weights shift +1.4x for FX-heavy sovereigns
    u2.indicators = ind.reset_index()
    s2 = s.copy_with(**{"regime.Calm.global_loading": min(0.9, s["regime"]["Calm"]["global_loading"] + 0.25),
                        "regime.Stressed.global_loading": min(0.9, s["regime"]["Stressed"]["global_loading"] + 0.25),
                        "regime.Crisis.global_loading": min(0.9, s["regime"]["Crisis"]["global_loading"] + 0.25),
                        "regime.regional_loading": 0.05})
    return u2, s2


def _legacy_b(u: Universe, s: Settings):
    """30% commodity price collapse: pillars 2 and 5 +18 for mono-exporters, DD -1.8 sigma with the Merton uplift on, hard-currency LGD +18 percentage points (the paper's 40% -> 58%, applied to the base LGD and capped at 95%), deficits widen."""
    u2 = _clone(u); c = u2.countries
    comm = c["exptype"] == "Commodity"
    c.loc[comm, "commgap"] = c.loc[comm, "commgap"] - 30
    names_c = list(c.loc[comm, "country"])
    ind = u2.indicators.set_index("id")
    ind.loc["1.6", names_c] = ind.loc["1.6", names_c].astype(float) - 4.0          # primary balance gap -3.5 to -5 pp of GDP
    ind.loc["2.1", names_c] = ind.loc["2.1", names_c].astype(float) * 0.8          # reserves erode
    ind.loc["2.8", names_c] = ind.loc["2.8", names_c].astype(float) - 4.0
    u2.indicators = ind.reset_index()
    adj = u2.adjustments
    for pillar in (2, 5):
        row = {"block": "Trigger inputs (before cap)", "pillar": pillar, "item": f"Scenario B commodity shock pillar {pillar}", "rule": "paper 9.2"}
        for n in c["country"]:
            row[n] = 18.0 if n in names_c else 0.0
        adj = pd.concat([adj, pd.DataFrame([row])], ignore_index=True)
    u2.adjustments = adj
    s2 = s.copy_with(**{"scorecard.trigger_cap": 18, "layer4.merton.dd_reference": s["layer4"]["merton"]["dd_reference"] + 1.8,
                        "layer4.merton.apply_uplift": True, "market.lgd_hard": min(95.0, s["market"]["lgd_hard"] + 18.0)})
    return u2, s2


def _legacy_c(u: Universe, s: Settings):
    """Strait of Malacca blockade: location multipliers at 2.0x, TSI > +3.5 sigma, L-VaR spreads doubled."""
    u2 = _clone(u); c = u2.countries
    asia = c["region"] == "Asia"
    c.loc[asia, "textz"] = c.loc[asia, "textz"] + 3.5
    c.loc[~asia, "textz"] = c.loc[~asia, "textz"] + 1.0
    c["spread"] = c["spread"] * 1.3
    u2.portfolio["location"] = "Active warzone"
    patches = {"regime.Calm.global_loading": min(0.9, s["regime"]["Calm"]["global_loading"] + 0.15)}
    for k, v in s["liquidity"]["by_asset"].items():
        patches[f"liquidity.by_asset.{k}.spread_mean"] = v["spread_mean"] * 2.0
        patches[f"liquidity.by_asset.{k}.spread_sd"] = v["spread_sd"] * 1.5
    return u2, s.copy_with(**patches)



LEGACY = {"A": Scenario("A", "Hawkish Fed +200 bps", _legacy_a.__doc__, fn=_legacy_a), "B": Scenario("B", "30% commodity collapse", _legacy_b.__doc__, fn=_legacy_b), "C": Scenario("C", "Strait of Malacca blockade", _legacy_c.__doc__, fn=_legacy_c)}

try:
    SCENARIOS = default_scenarios()
except Exception:          # pragma: no cover - data folder missing in an unusual install
    SCENARIOS = LEGACY
