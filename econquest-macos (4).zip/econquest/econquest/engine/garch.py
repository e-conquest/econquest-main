"""GARCH econometrics for the desk (volatility layer).

Univariate GARCH(1,1) with Student-t innovations, fitted by maximum likelihood, gives each FX pair
and country ETF a conditional volatility path, multi-step variance forecasts, and parametric VaR/ES
that adapt when volatility spikes. A DCC(1,1) (Engle 2002) layer on the standardized residuals gives
time-varying cross-asset correlations; combined with the GARCH forecasts it yields a dynamic
covariance for the book's FX and equity exposures (portfolio GARCH-VaR and vol-scaled sizes).
Black-Scholes fair values with the GARCH forecast volatility support an options check, and the
same GARCH(1,1) fit on the monthly GPR series measures the changing variance of geopolitical risk.

Everything here is numpy + scipy; no `arch` dependency.
"""
from __future__ import annotations

import math
from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from scipy import optimize, special, stats

TRADING_DAYS = 252


# ----------------------------------------------------------------------------------------------
# Univariate GARCH(1,1)-t
# ----------------------------------------------------------------------------------------------
@dataclass
class GarchFit:
    mu: float
    omega: float
    alpha: float
    beta: float
    nu: float                      # Student-t degrees of freedom (inf = Gaussian)
    loglik: float
    sigma2: np.ndarray             # conditional variance, same length as returns
    resid: np.ndarray              # returns - mu
    std_resid: np.ndarray          # resid / sigma
    n: int
    converged: bool
    index: pd.Index | None = None

    @property
    def persistence(self) -> float:
        return self.alpha + self.beta

    @property
    def half_life(self) -> float:
        p = self.persistence
        return float("inf") if p >= 1 else math.log(0.5) / math.log(p)

    @property
    def long_run_var(self) -> float:
        p = self.persistence
        return self.omega / (1 - p) if p < 1 else float("nan")

    def forecast_var(self, horizon: int) -> np.ndarray:
        """Per-step conditional variance forecasts for t+1 ... t+h (recursion on the last observation)."""
        out = np.empty(horizon)
        s2 = self.omega + self.alpha * self.resid[-1] ** 2 + self.beta * self.sigma2[-1]
        lr = self.long_run_var
        for h in range(horizon):
            out[h] = s2
            s2 = lr + self.persistence * (s2 - lr) if np.isfinite(lr) else self.omega + self.persistence * s2
        return out

    def cumulative_var(self, horizon: int) -> float:
        return float(self.forecast_var(horizon).sum())


def _t_scale(nu: float) -> float:
    """Scale that gives a Student-t(nu) unit variance."""
    return math.sqrt((nu - 2) / nu) if np.isfinite(nu) else 1.0


def _garch_filter(r: np.ndarray, mu: float, omega: float, alpha: float, beta: float) -> tuple[np.ndarray, np.ndarray]:
    e = r - mu
    n = len(r)
    s2 = np.empty(n)
    s2[0] = max(np.var(e), 1e-12)
    for t in range(1, n):
        s2[t] = omega + alpha * e[t - 1] ** 2 + beta * s2[t - 1]
    return e, np.maximum(s2, 1e-14)


def _sigmoid(x: float) -> float:
    return 1 / (1 + math.exp(-x))


def _unpack(theta: np.ndarray, v: float, dist: str) -> tuple[float, float, float, float, float]:
    """theta = (mu, logit persistence, logit alpha share, log(nu - 2.05)); omega by variance targeting."""
    mu, ls, lp, lnu = theta
    pers = 0.9995 * _sigmoid(ls); share = _sigmoid(lp)
    alpha, beta = pers * share, pers * (1 - share)
    omega = v * (1 - pers)
    nu = 2.05 + math.exp(lnu) if dist == "t" else float("inf")
    return mu, omega, alpha, beta, nu


def _negloglik(theta: np.ndarray, r: np.ndarray, v: float, dist: str) -> float:
    mu, omega, alpha, beta, nu = _unpack(theta, v, dist)
    e, s2 = _garch_filter(r, mu, omega, alpha, beta)
    if dist == "t":
        c = _t_scale(nu)
        z = e / (np.sqrt(s2) * c)
        ll = (special.gammaln((nu + 1) / 2) - special.gammaln(nu / 2) - 0.5 * math.log(math.pi * nu)
              - 0.5 * np.log(s2) - math.log(c) - (nu + 1) / 2 * np.log1p(z ** 2 / nu))
    else:
        ll = -0.5 * (math.log(2 * math.pi) + np.log(s2) + e ** 2 / s2)
    out = -float(ll.sum())
    return out if np.isfinite(out) else 1e10


def garch11_fit(returns: pd.Series | np.ndarray, dist: str = "t") -> GarchFit:
    """Maximum-likelihood GARCH(1,1) with constant mean and variance targeting (omega = var x (1 - alpha - beta)),
    persistence bounded below 0.9995; dist 't' (default) or 'normal'. Several starts, Nelder-Mead."""
    idx = returns.index if isinstance(returns, pd.Series) else None
    r = np.asarray(returns, dtype=float)
    r = r[np.isfinite(r)]
    v = max(np.var(r), 1e-14)
    best = None
    for pers, share in ((0.95, 0.08), (0.85, 0.15), (0.98, 0.04), (0.60, 0.30)):
        theta0 = np.array([np.median(r), math.log(pers / (1 - pers)), math.log(share / (1 - share)), math.log(6.0)])
        res = optimize.minimize(_negloglik, theta0, args=(r, v, dist), method="Nelder-Mead",
                                options={"maxiter": 4000, "xatol": 1e-7, "fatol": 1e-9})
        if best is None or res.fun < best.fun:
            best = res
    mu, omega, alpha, beta, nu = _unpack(best.x, v, dist)
    e, s2 = _garch_filter(r, mu, omega, alpha, beta)
    return GarchFit(mu, omega, alpha, beta, nu, -best.fun, s2, e, e / np.sqrt(s2), len(r), bool(best.success), idx)


def arch_lm_test(x: np.ndarray, lags: int = 5) -> tuple[float, float]:
    """Engle's ARCH-LM test: regress x^2 on its lags; statistic n*R^2 ~ chi2(lags). Returns (stat, p)."""
    x = np.asarray(x, dtype=float); x = x[np.isfinite(x)]
    x2 = x ** 2 - np.mean(x ** 2)
    n = len(x2) - lags
    if n < lags + 5:
        return float("nan"), float("nan")
    y = x2[lags:]
    X = np.column_stack([np.ones(n)] + [x2[lags - k - 1:len(x2) - k - 1] for k in range(lags)])
    b, *_ = np.linalg.lstsq(X, y, rcond=None)
    resid = y - X @ b
    r2 = 1 - resid.var() / y.var() if y.var() > 0 else 0.0
    stat = n * r2
    return float(stat), float(1 - stats.chi2.cdf(stat, lags))


def ljung_box(x: np.ndarray, lags: int = 10) -> tuple[float, float]:
    """Ljung-Box Q on x (use squared standardized residuals to check remaining ARCH)."""
    x = np.asarray(x, dtype=float); x = x[np.isfinite(x)]; x = x - x.mean()
    n = len(x)
    denom = np.sum(x ** 2)
    q = 0.0
    for k in range(1, lags + 1):
        rho = np.sum(x[k:] * x[:-k]) / denom
        q += rho ** 2 / (n - k)
    q *= n * (n + 2)
    return float(q), float(1 - stats.chi2.cdf(q, lags))


def t_quantile(p: float, nu: float) -> float:
    """Quantile of a unit-variance Student-t (Gaussian if nu is inf)."""
    return stats.norm.ppf(p) if not np.isfinite(nu) else stats.t.ppf(p, nu) * _t_scale(nu)


def t_es(p: float, nu: float) -> float:
    """Expected shortfall of a unit-variance Student-t beyond the p quantile (positive number)."""
    if not np.isfinite(nu):
        return stats.norm.pdf(stats.norm.ppf(p)) / (1 - p)
    q = stats.t.ppf(p, nu)
    es = (stats.t.pdf(q, nu) * (nu + q ** 2) / (nu - 1)) / (1 - p)
    return float(es * _t_scale(nu))


# ----------------------------------------------------------------------------------------------
# DCC(1,1)
# ----------------------------------------------------------------------------------------------
@dataclass
class DccFit:
    a: float
    b: float
    qbar: np.ndarray
    R_last: np.ndarray             # conditional correlation at T
    R_next: np.ndarray             # one-step-ahead forecast
    R_uncond: np.ndarray           # sample correlation of standardized residuals
    loglik: float
    labels: list[str] = field(default_factory=list)
    n: int = 0

    def avg_corr(self, R: np.ndarray | None = None) -> float:
        R = self.R_last if R is None else R
        k = R.shape[0]
        return float((R.sum() - k) / (k * (k - 1))) if k > 1 else float("nan")


def _dcc_recursion(Z: np.ndarray, a: float, b: float, qbar: np.ndarray):
    n, k = Z.shape
    Q = qbar.copy()
    ll = 0.0
    R = np.eye(k)
    for t in range(n):
        d = 1 / np.sqrt(np.diag(Q))
        R = Q * np.outer(d, d)
        z = Z[t]
        try:
            Rinv = np.linalg.inv(R); logdet = np.linalg.slogdet(R)[1]
        except np.linalg.LinAlgError:
            return 1e10, R, Q
        ll += -0.5 * (logdet + z @ Rinv @ z - z @ z)
        Q = (1 - a - b) * qbar + a * np.outer(z, z) + b * Q
    return -ll, R, Q


def dcc_fit(std_resid: pd.DataFrame) -> DccFit:
    """Engle's DCC(1,1) second stage on a T x k frame of standardized residuals (correlation targeting)."""
    Z = np.asarray(std_resid.dropna(), dtype=float)
    Z = Z / Z.std(axis=0, ddof=1)
    qbar = np.corrcoef(Z, rowvar=False)
    k = Z.shape[1]
    if k < 2:
        raise ValueError("DCC needs at least two series")

    def nll(theta):
        a, b = 1 / (1 + math.exp(-theta[0])), 1 / (1 + math.exp(-theta[1]))
        if a + b >= 0.999:
            return 1e10
        return _dcc_recursion(Z, a, b, qbar)[0]

    best = None
    for a0, b0 in ((0.03, 0.95), (0.08, 0.85), (0.01, 0.98)):
        x0 = np.array([math.log(a0 / (1 - a0)), math.log(b0 / (1 - b0))])
        res = optimize.minimize(nll, x0, method="Nelder-Mead", options={"maxiter": 600, "xatol": 1e-5, "fatol": 1e-7})
        if best is None or res.fun < best.fun:
            best = res
    a, b = 1 / (1 + math.exp(-best.x[0])), 1 / (1 + math.exp(-best.x[1]))
    nl, R_last, Q_next = _dcc_recursion(Z, a, b, qbar)
    d = 1 / np.sqrt(np.diag(Q_next)); R_next = Q_next * np.outer(d, d)
    return DccFit(a, b, qbar, R_last, R_next, qbar, -nl, list(std_resid.columns), Z.shape[0])


# ----------------------------------------------------------------------------------------------
# Options (Black-Scholes) and vol targeting
# ----------------------------------------------------------------------------------------------
def black_scholes(S: float, K: float, T: float, r: float, sigma: float, kind: str = "put") -> dict:
    if T <= 0 or sigma <= 0:
        return {"price": max(0.0, (K - S) if kind == "put" else (S - K)), "vega": 0.0, "delta": 0.0}
    d1 = (math.log(S / K) + (r + 0.5 * sigma ** 2) * T) / (sigma * math.sqrt(T)); d2 = d1 - sigma * math.sqrt(T)
    if kind == "put":
        price = K * math.exp(-r * T) * stats.norm.cdf(-d2) - S * stats.norm.cdf(-d1); delta = stats.norm.cdf(d1) - 1
    else:
        price = S * stats.norm.cdf(d1) - K * math.exp(-r * T) * stats.norm.cdf(d2); delta = stats.norm.cdf(d1)
    return {"price": float(price), "vega": float(S * stats.norm.pdf(d1) * math.sqrt(T)), "delta": float(delta)}


def implied_vol(price: float, S: float, K: float, T: float, r: float, kind: str = "put") -> float:
    f = lambda s: black_scholes(S, K, T, r, s, kind)["price"] - price  # noqa: E731
    try:
        return float(optimize.brentq(f, 1e-4, 5.0))
    except ValueError:
        return float("nan")


def vol_target_scalar(target_vol: float, forecast_vol: float, cap: float = 2.0, floor: float = 0.1) -> float:
    if not np.isfinite(forecast_vol) or forecast_vol <= 0:
        return float("nan")
    return float(min(cap, max(floor, target_vol / forecast_vol)))


# ----------------------------------------------------------------------------------------------
# Desk-level run
# ----------------------------------------------------------------------------------------------
@dataclass
class GarchResult:
    series: pd.DataFrame            # one row per FX pair / ETF
    dcc_fx: DccFit | None
    dcc_eq: DccFit | None
    portfolio: dict                 # GARCH-DCC portfolio VaR
    options: pd.DataFrame           # Black-Scholes check per ETF
    macro: pd.DataFrame             # GARCH on monthly GPR series
    as_of: str
    notes: dict = field(default_factory=dict)
    vol_history: pd.DataFrame | None = None   # annualized conditional volatility (%) per ticker, by date
    fits: dict = field(default_factory=dict)  # ticker -> GarchFit


def _returns(prices: pd.Series) -> pd.Series:
    p = prices.dropna()
    p = p[p > 0]
    r = np.log(p).diff().dropna()
    return r[r != 0] if (r == 0).mean() > 0.5 else r      # drop runs of unchanged quotes on pegged pairs


def clean_bad_ticks(prices: pd.DataFrame, k: float = 12.0) -> tuple[pd.DataFrame, dict]:
    """Remove one-day quote errors: a log return beyond k robust SDs that reverses the next day.
    The offending price is dropped and forward-filled; the count per series is returned."""
    out = prices.copy(); removed = {}
    for c in out.columns:
        p = out[c].dropna(); p = p[p > 0]
        if len(p) < 50:
            continue
        r = np.log(p).diff()
        scale = 1.4826 * np.nanmedian(np.abs(r - np.nanmedian(r))) or r.std()
        bad = []
        vals = r.to_numpy(); idx = r.index
        for i in range(1, len(vals) - 1):
            if abs(vals[i]) > k * scale and abs(vals[i] + vals[i + 1]) < 0.3 * abs(vals[i]):
                bad.append(idx[i])
        if bad:
            out.loc[bad, c] = np.nan
            removed[c] = len(bad)
    return out.ffill(), removed


def _business_daily(prices: pd.DataFrame) -> pd.DataFrame:
    bd = prices.asfreq("D").ffill()
    return bd[bd.index.dayofweek < 5]


def run_garch(u, prices: pd.DataFrame, settings=None, gpr: pd.DataFrame | None = None, quotes: dict[str, float] | None = None,
              as_of=None) -> GarchResult:
    """quotes: optional {ticker: market price of the ATM 63-day put} for the implied-vol comparison.

    as_of (VF-007): fit only on prices dated on or before it (`prices_as_of`), so a replay never sees later
    prices; when omitted, settings["as_of"] is used if set, else every row (unchanged behaviour)."""
    cfg = (settings.raw.get("garch", {}) if settings is not None else {}) if settings is not None else {}
    target_vol = float(cfg.get("target_vol", 0.10)); cap = float(cfg.get("scalar_cap", 2.0)); rf = float(cfg.get("risk_free", 0.04))
    alphas = cfg.get("confidence", [0.99])
    a99 = float(alphas[0])
    if as_of is None and settings is not None:
        as_of = settings.get("as_of")
    prices = prices_as_of(prices, as_of)
    prices = prices.copy(); prices.index = pd.to_datetime(prices.index)
    prices, removed = clean_bad_ticks(prices.sort_index())
    prices = _business_daily(prices)
    cty = u.countries.set_index("country")
    book = u.portfolio.copy()
    book["sign"] = np.where(book["direction"].astype(str).str.lower().str.startswith("long"), 1.0, -1.0)
    fx_exp = book[book["asset_class"].isin(["FX", "Local bond"])].groupby("country").apply(lambda g: float((g["sign"] * g["notional_mm"]).sum()), include_groups=False)
    eq_exp = book[book["asset_class"] == "Equity"].groupby("country").apply(lambda g: float((g["sign"] * g["notional_mm"]).sum()), include_groups=False)

    rows, fits, std = [], {}, {}
    for country in u.names:
        ccy = str(cty.at[country, "currency"]) if "currency" in cty.columns else ""
        etf = str(cty.at[country, "etf"]) if "etf" in cty.columns and pd.notna(cty.at[country, "etf"]) else ""
        for kind, ticker in (("FX", f"USD{ccy}"), ("Equity", etf)):
            if not ticker or ticker not in prices.columns:
                continue
            r = _returns(prices[ticker])
            if len(r) < 250:
                continue
            fit = garch11_fit(r)
            fits[ticker] = fit; std[ticker] = pd.Series(fit.std_resid, index=r.index)
            ann = math.sqrt(TRADING_DAYS)
            f1 = fit.forecast_var(1)[0]; f10 = fit.cumulative_var(10); f21 = fit.cumulative_var(21); f63 = fit.cumulative_var(63)
            q = t_quantile(a99, fit.nu); es = t_es(a99, fit.nu)
            realized = float(r.iloc[-60:].std(ddof=1) * ann)
            lm_r = arch_lm_test(r.to_numpy()); lm_z = arch_lm_test(fit.std_resid); lb_z = ljung_box(fit.std_resid ** 2)
            exposure = float(fx_exp.get(country, 0.0)) if kind == "FX" else float(eq_exp.get(country, 0.0))
            # FX quote is local per USD: a long local-currency position loses when the quote rises
            loss_sign = 1.0 if kind == "FX" else -1.0
            var1 = q * math.sqrt(f1) * 100; var10 = q * math.sqrt(f10) * 100
            fcst_ann = math.sqrt(f21 / 21) * ann
            scalar = vol_target_scalar(target_vol, fcst_ann, cap)
            rows.append({
                "country": country, "kind": kind, "ticker": ticker, "obs": fit.n, "last_date": r.index[-1].date().isoformat(),
                "mu_ann_pct": fit.mu * TRADING_DAYS * 100 * (-loss_sign if kind == "FX" else 1),
                "alpha": fit.alpha, "beta": fit.beta, "persistence": fit.persistence, "half_life_days": fit.half_life, "nu": fit.nu,
                "long_run_vol_pct": math.sqrt(fit.long_run_var) * ann * 100 if np.isfinite(fit.long_run_var) else np.nan,
                "cond_vol_pct": math.sqrt(fit.sigma2[-1]) * ann * 100, "fcst_1d_vol_pct": math.sqrt(f1) * ann * 100,
                "fcst_10d_vol_pct": math.sqrt(f10 / 10) * ann * 100, "fcst_21d_vol_pct": fcst_ann * 100, "fcst_63d_vol_pct": math.sqrt(f63 / 63) * ann * 100,
                "realized_60d_vol_pct": realized * 100, "vol_ratio": (math.sqrt(f1) * ann * 100) / (realized * 100) if realized > 0 else np.nan,
                "arch_lm_p_returns": lm_r[1], "arch_lm_p_std_resid": lm_z[1], "ljung_box_p_sq_std_resid": lb_z[1],
                "var99_1d_pct": var1, "es99_1d_pct": es * math.sqrt(f1) * 100, "var99_10d_pct": var10,
                "exposure_mm": exposure, "var99_10d_mm": abs(exposure) * var10 / 100,
                "vol_target_scalar": scalar, "scaled_notional_mm": exposure * scalar if np.isfinite(scalar) else np.nan,
                "loss_sign": loss_sign, "loglik": fit.loglik, "converged": fit.converged,
            })
    series = pd.DataFrame(rows)

    def _dcc(kind):
        cols = [t for t in series.loc[series["kind"] == kind, "ticker"]]
        if len(cols) < 2:
            return None
        Z = pd.DataFrame({c: std[c] for c in cols}).dropna()
        return dcc_fit(Z) if len(Z) > 100 else None
    dcc_fx = _dcc("FX"); dcc_eq = _dcc("Equity")

    # Portfolio GARCH-DCC VaR on FX and equity exposures (1-day and 10-day)
    port = {}
    for kind, dcc in (("FX", dcc_fx), ("Equity", dcc_eq)):
        sub = series[(series["kind"] == kind) & (series["exposure_mm"] != 0)]
        if dcc is None or sub.empty:
            port[kind] = {"gross_mm": 0.0, "var99_1d_mm": 0.0, "var99_10d_mm": 0.0, "undiversified_var99_1d_mm": 0.0, "avg_corr": np.nan, "avg_corr_uncond": np.nan}
            continue
        idx = [dcc.labels.index(t) for t in sub["ticker"]]
        R = dcc.R_next[np.ix_(idx, idx)]
        w = (sub["exposure_mm"] * sub["loss_sign"]).to_numpy()
        s1 = np.array([math.sqrt(fits[t].forecast_var(1)[0]) for t in sub["ticker"]])
        s10 = np.array([math.sqrt(fits[t].cumulative_var(10)) for t in sub["ticker"]])
        nu = float(np.median([fits[t].nu for t in sub["ticker"]])); q = t_quantile(a99, nu); es_q = t_es(a99, nu)
        v1 = math.sqrt(w @ (np.outer(s1, s1) * R) @ w); v10 = math.sqrt(w @ (np.outer(s10, s10) * R) @ w)
        port[kind] = {"gross_mm": float(np.abs(w).sum()), "var99_1d_mm": q * v1, "var99_10d_mm": q * v10, "es99_1d_mm": es_q * v1, "es99_10d_mm": es_q * v10,
                      "undiversified_var99_1d_mm": float(q * np.sum(np.abs(w) * s1)), "avg_corr": dcc.avg_corr(R),
                      "avg_corr_uncond": dcc.avg_corr(dcc.R_uncond[np.ix_(idx, idx)]), "nu": nu, "positions": int(len(sub))}
    port["total_var99_1d_mm"] = math.sqrt(sum(p.get("var99_1d_mm", 0.0) ** 2 for p in port.values() if isinstance(p, dict)))
    port["total_var99_10d_mm"] = math.sqrt(sum(p.get("var99_10d_mm", 0.0) ** 2 for p in port.values() if isinstance(p, dict)))
    port["total_es99_1d_mm"] = math.sqrt(sum(p.get("es99_1d_mm", 0.0) ** 2 for p in port.values() if isinstance(p, dict)))
    port["total_es99_10d_mm"] = math.sqrt(sum(p.get("es99_10d_mm", 0.0) ** 2 for p in port.values() if isinstance(p, dict)))

    # Options: ATM 3-month put on each ETF, GARCH forecast vol vs 60-day realized
    opt_rows = []
    for _, s in series[series["kind"] == "Equity"].iterrows():
        S = float(prices[s["ticker"]].dropna().iloc[-1]); T = 63 / TRADING_DAYS
        g = black_scholes(S, S, T, rf, s["fcst_63d_vol_pct"] / 100); h = black_scholes(S, S, T, rf, s["realized_60d_vol_pct"] / 100)
        opt_rows.append({"country": s["country"], "ticker": s["ticker"], "spot": S, "strike": S, "tenor_days": 63,
                         "garch_vol_pct": s["fcst_63d_vol_pct"], "realized_vol_pct": s["realized_60d_vol_pct"],
                         "put_fair_garch": g["price"], "put_fair_realized": h["price"], "put_diff_pct": (g["price"] / h["price"] - 1) * 100 if h["price"] > 0 else np.nan,
                         "vega_per_vol_pt": g["vega"] / 100, "delta": g["delta"], "market_quote": np.nan, "implied_vol_pct": np.nan, "garch_minus_implied": np.nan})
        if quotes and s["ticker"] in quotes and np.isfinite(quotes[s["ticker"]]) and quotes[s["ticker"]] > 0:
            iv = implied_vol(float(quotes[s["ticker"]]), S, S, T, rf)
            opt_rows[-1].update({"market_quote": float(quotes[s["ticker"]]), "implied_vol_pct": iv * 100, "garch_minus_implied": s["fcst_63d_vol_pct"] - iv * 100})
    options = pd.DataFrame(opt_rows)

    # Macro: GARCH(1,1) on monthly log changes of the GPR series
    macro_rows = []
    if gpr is not None and len(gpr) > 60:
        g = gpr.copy()
        g.index = pd.PeriodIndex(g["month"], freq="M").to_timestamp() if "month" in g.columns else pd.to_datetime(g.index)
        for col in [c for c in g.columns if c != "month"]:
            x = pd.to_numeric(g[col], errors="coerce").dropna()
            x = x[x > 0]
            if len(x) < 60:
                continue
            r = np.log(x).diff().dropna()
            fit = garch11_fit(r)
            lm = arch_lm_test(r.to_numpy(), lags=3)
            lr = math.sqrt(fit.long_run_var) if np.isfinite(fit.long_run_var) else np.nan
            macro_rows.append({"series": col, "obs": fit.n, "last_month": r.index[-1].strftime("%Y-%m"), "alpha": fit.alpha, "beta": fit.beta,
                               "persistence": fit.persistence, "nu": fit.nu, "long_run_vol_pct": lr * 100, "cond_vol_pct": math.sqrt(fit.sigma2[-1]) * 100,
                               "fcst_3m_vol_pct": math.sqrt(fit.cumulative_var(3) / 3) * 100, "vol_ratio": math.sqrt(fit.sigma2[-1]) / lr if lr and lr > 0 else np.nan,
                               "arch_lm_p": lm[1], "last_std_resid": float(fit.std_resid[-1])})
    macro = pd.DataFrame(macro_rows)
    as_of = prices.index.max().date().isoformat()
    vol_hist = pd.DataFrame({t: pd.Series(np.sqrt(f.sigma2) * math.sqrt(TRADING_DAYS) * 100, index=std[t].index) for t, f in fits.items()}).sort_index() if fits else None
    return GarchResult(series, dcc_fx, dcc_eq, port, options, macro, as_of,
                       notes={"target_vol": target_vol, "scalar_cap": cap, "risk_free": rf, "confidence": a99, "bad_ticks_removed": removed},
                       vol_history=vol_hist, fits=fits)


def load_prices(data_dir) -> pd.DataFrame | None:
    from pathlib import Path
    d = Path(data_dir) / "market_history"
    f = d / "prices.csv"
    if not f.exists():
        return None
    px = pd.read_csv(f, index_col=0, parse_dates=True)
    for extra in sorted(d.glob("*.csv")):
        if extra.name == "prices.csv":
            continue
        e = pd.read_csv(extra, index_col=0, parse_dates=True)
        for c in e.columns:
            px[c] = e[c].reindex(px.index.union(e.index)).reindex(px.index) if c in px.columns else e[c]
        px = px.combine_first(e)
    return px.sort_index()


# ----------------------------------------------------------------------------------------------
# Monte Carlo marginals (EQ-B-0035, GOV-020): 12-month volatilities from the GARCH forecast
# ----------------------------------------------------------------------------------------------
# Administered or quasi-pegged quotes whose GARCH fit is not a market volatility (GOV-034, garch-dcc.md).
ADMINISTERED = ("USDVES", "USDNGN", "USDARS", "USDPKR", "USDBZD")
MC_PERSISTENCE_MAX = 0.995      # alpha + beta at or above this (half-life > 138 trading days): long-run variance ill-identified
MC_MIN_RETURNS = 250
_MC_FIT_CACHE: dict = {}        # (ticker, n, returns digest) -> GarchFit; fits are deterministic, so stress runs reuse them


def _mc_returns(prices: pd.DataFrame) -> pd.DataFrame:
    """The same preprocessing as `run_garch`: bad-tick cleaning, business-day calendar."""
    px = prices.copy()
    if "date" in px.columns:
        px = px.set_index("date")
    px.index = pd.to_datetime(px.index)
    px = px.sort_index().apply(pd.to_numeric, errors="coerce")
    px, _ = clean_bad_ticks(px)
    return _business_daily(px)


def prices_as_of(prices: pd.DataFrame | None, as_of) -> pd.DataFrame | None:
    """Rows of the price history dated on or before `as_of` (all rows when `as_of` is None), so a replay or backtest
    never fits on later prices (EQ-B-0035/0036 review)."""
    if prices is None or as_of is None or len(prices) == 0:
        return prices
    d = pd.to_datetime(prices["date"] if "date" in prices.columns else prices.index)
    return prices[np.asarray(d <= pd.Timestamp(as_of))]


def _cached_fit(ticker: str, r: pd.Series) -> GarchFit:
    import hashlib
    key = (ticker, len(r), hashlib.sha1(np.ascontiguousarray(r.to_numpy(dtype=float)).tobytes(), usedforsecurity=False).hexdigest())
    if key not in _MC_FIT_CACHE:
        _MC_FIT_CACHE[key] = garch11_fit(r)
    return _MC_FIT_CACHE[key]


def mc_vols(prices: pd.DataFrame | None, countries: pd.DataFrame, needed: list[tuple[str, str]], horizon_days: int = 252,
            persistence_max: float = MC_PERSISTENCE_MAX, administered=ADMINISTERED) -> pd.DataFrame:
    """12-month market volatility (percent) per (country, kind) with kind 'FX' (USD<ccy>) or 'Equity' (country ETF).

    vol = sqrt(sum of the GARCH(1,1)-t variance forecasts for days t+1 ... t+horizon_days) x 100: the forecast starts at
    today's conditional variance and reverts to the long-run variance at rate alpha + beta. `vol_pct` is NaN (the
    caller keeps its regime parameter) when there is no series, fewer than 250 returns, the quote is administered
    (GOV-034 list) or persistence >= persistence_max; `reason` says which."""
    cty = countries.set_index("country")
    rets = _mc_returns(prices) if prices is not None and len(prices) else None
    rows = []
    for country, kind in needed:
        if kind == "FX":
            ticker = f"USD{cty.at[country, 'currency']}" if "currency" in cty.columns and pd.notna(cty.at[country, "currency"]) else ""
        else:
            etf = cty.at[country, "etf"] if "etf" in cty.columns else None
            ticker = str(etf) if isinstance(etf, str) and etf.strip() else ""
        row = {"country": country, "kind": kind, "ticker": ticker, "vol_pct": np.nan, "reason": "", "obs": 0,
               "persistence": np.nan, "half_life_days": np.nan, "nu": np.nan, "cond_vol_pct": np.nan, "long_run_vol_pct": np.nan}
        if rets is None or not ticker or ticker not in rets.columns:
            row["reason"] = "no series"; rows.append(row); continue
        if ticker in administered:
            row["reason"] = "administered quote (GOV-034)"; rows.append(row); continue
        r = _returns(rets[ticker])
        row["obs"] = int(len(r))
        if len(r) < MC_MIN_RETURNS:
            row["reason"] = f"fewer than {MC_MIN_RETURNS} returns"; rows.append(row); continue
        fit = _cached_fit(ticker, r)
        ann = math.sqrt(TRADING_DAYS)
        row.update({"persistence": fit.persistence, "half_life_days": fit.half_life, "nu": fit.nu,
                    "cond_vol_pct": math.sqrt(fit.sigma2[-1]) * ann * 100,
                    "long_run_vol_pct": math.sqrt(fit.long_run_var) * ann * 100 if np.isfinite(fit.long_run_var) else np.nan})
        if fit.persistence >= persistence_max:
            row["reason"] = f"persistence {fit.persistence:.4f} >= {persistence_max}"; rows.append(row); continue
        row["vol_pct"] = math.sqrt(fit.cumulative_var(int(horizon_days))) * 100
        rows.append(row)
    return pd.DataFrame(rows)
