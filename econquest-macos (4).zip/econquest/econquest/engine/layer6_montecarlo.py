"""Layer 6: Monte Carlo loss engine (paper 3.6, 5.1).

Each path draws a global factor, one factor per region, a chi-square mixing variable and one
idiosyncratic shock per country; the latent t variable drives both the market move and the discrete
sovereign events. Severities come from Layer 4 (Beta haircuts, GPD tails). Quasi-Monte Carlo uses a
scrambled Sobol sequence (scipy); the requested path count is rounded up to a power of two (100,000 ->
131,072) because Sobol points are balanced only in blocks of 2^m.
Outputs: loss distribution, VaR and ES at 95 / 99, ES 97.5 (FRTB), L-VaR, contributions by position
and by country.

Market volatilities (EQ-B-0035, GOV-020): `monte_carlo.vol_source` "regime" (default) takes the 12-month vols
from `market` (fx_vol by FX regime, equity_vol); "garch" takes the FX and equity vols from the GARCH(1,1)-t
12-month forecast on data/market_history (`garch.mc_vols`), keeps the regime parameter where there is no usable
series, and scales the GARCH vol by `market` value / anchor so that stress shocks to `market.fx_vol` and
`market.equity_vol` still apply. Eurobond and CDS vols (spread-based) are unchanged under both sources.

Monte Carlo error (VF-004): `mc_error` adds var99_se_mm, es99_se_mm, lvar99_se_mm and 95% bands (*_ci95_lo_mm /
*_ci95_hi_mm) by batch means over contiguous Sobol blocks; new keys only, every other metric is unchanged.

Rate level shock (EQ-B-0044, GOV-027): when the portfolio carries `rate_shock_bp` (written only by a stress
scenario's "rates" shock, engine/stress.py), Local bond and Eurobond positions get a deterministic
mark-to-market loss `rate_mtm_pct = duration_yrs * rate_shock_bp / 100` percent of notional, added on every path
before the direction sign and the long-loss cap. Without the column (every base run) nothing is added.

Long-loss cap (EQ-B-0053, RCA-B-004): a long position's path loss is capped at its notional. The market move is a
symmetric (zero-mean) multiple of the latent t variable, so the cap truncates the loss tail only and the gain tail is
untouched: the capped mean is below the uncapped one, and the gap grows as the copula nu falls (heavier tails). This
is why expected_loss_mm falls when the global state turns Stressed (df_stressed < df_calm) with no PD change; the
factor loadings do not enter EL (each latent marginal is t_nu whatever the loadings). `expected_loss_uncapped_mm`
and `long_cap_relief_mm` (= uncapped - capped mean) report the gap; new keys only, every other metric is unchanged.

Market move shape (EQ-B-0063, GOV-047; Tier 1 if switched on): `monte_carlo.market_move` "linear" (default, today)
takes the long's market loss as -z * vol, z the standardised latent t. "lognormal" takes the price return
R = exp(sigma * zn - sigma^2 / 2) - 1, sigma = signed vol / 100, zn = Phi^-1(F_t,nu(latent)) the normal score of the
same latent (same ranks, so the copula dependence and the joint law with the event thresholds are unchanged). E[R] = 0
exactly and R > -100%, so a long's market loss alone never reaches the cap. The normal score is needed because
E[exp(sigma * t)] is infinite for a Student t; the cost is that the market-move marginal is lognormal, not scaled t.
Jumps (default, T&C, expropriation, PV) are still added to the market loss, so a long can still exceed notional when
a jump and a bad market move coincide; the cap then still binds (see the validation document for what is left).

Default / spread overlap (EQ-B-0063, GOV-047): `monte_carlo.default_spread_overlap` "additive" (default, today) adds
the Layer 4 LGD to the market move on a default path. "lgd_only" (recovery of face): on a default path a Eurobond
loses its LGD draw and nothing else (the spread and any scenario rate mark-to-market are dropped), and CDS
protection gains its LGD draw only. "compound" (recovery of market value): a Eurobond loses m + (1 - m) * LGD, m the
pre-default market loss (spread + rate), i.e. the mark-down before default and LGD on what is left; CDS settles on
face, so it is "lgd_only". Default paths are the bad-z paths, so removing (part of) their market loss would leave the
survivors with a positive mean gain, a new EL credit; under both values the survivors' market move is shifted by the
closed-form amount (`default_path_move`) that keeps the zero-mean market move zero-mean (for "lgd_only": the survivor
move is net of its conditional mean; for "compound": E[LGD] x E[min(m, 1) 1{default}], since the clip at 100% is what
the default path removes). A scenario rate mark (`rate_mtm_pct`, rm) is deterministic, not zero-mean, and is not
re-centred: a defaulted bond is a par claim, so dropping it on default paths is economics, and it lowers the mean
loss by about p x rm (lgd_only) or p x E[LGD] x rm (compound) under a rates stress. Other asset classes are unchanged
under every value.
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
import pandas as pd
from scipy import stats
from scipy.stats import qmc
from ..config import Settings
from ..ingestion import Universe
from .layer4_severity import haircut_distribution, sample_haircut, gpd_severity
from .layer5_copula import liquidity_cost


@dataclass
class MCResult:
    losses: np.ndarray                 # portfolio loss per path ($mm, + = loss)
    position_losses: np.ndarray        # paths x positions
    latent: np.ndarray                 # paths x countries
    metrics: dict
    contributions: pd.DataFrame
    by_country: pd.DataFrame
    paths: int
    df: float
    sample: dict | None = None        # first rows of the factor draws, for the workbook's MC tab
    region_order: list | None = None


def sobol_path_count(n: int) -> int:
    """Smallest power of two >= n (at least 2). A scrambled Sobol sequence keeps its balance properties only
    for 2^m points, so the Sobol branch simulates this many paths instead of truncating a 2^m draw (EQ-B-0007)."""
    return 1 << max(1, (int(n) - 1).bit_length())


def _draw_uniforms(n: int, dims: int, seed: int, use_sobol: bool) -> np.ndarray:
    if use_sobol:
        m = int(n).bit_length() - 1
        if n < 2 or (1 << m) != n:
            raise ValueError(f"Sobol draws need a power-of-two path count, got {n}; use sobol_path_count")
        return qmc.Sobol(d=dims, scramble=True, seed=seed).random_base2(m)
    return np.random.default_rng(seed).random((n, dims))


VOL_SOURCES = ("regime", "garch")
# Under vol_source "garch" the GARCH vol is scaled by market value / anchor, so a stress shock to market.fx_vol or
# market.equity_vol still applies as a ratio. The anchor is the unstressed governed value (EQ-B-0047): a scenario
# records the pre-patch `market` vols in `monte_carlo.garch_vol.anchor` (engine/stress.py::apply_shocks); a run
# without that key (every base run) anchors to its own `market` values, so the ratio is exactly 1. An anchor set in
# assumptions.json still wins. GARCH_ANCHOR (the hard-coded 2026-10-23 values) is no longer read; deprecated,
# kept one release for importers (contract rule 5), remove in 0.1.6.
GARCH_ANCHOR = {"fx_vol": {"Float": 12.0, "Managed": 7.0, "Peg": 2.0, "Dollarized": 0.0}, "equity_vol": 25.0}


def garch_anchor(settings: Settings) -> dict:
    """The market vols GARCH vols are anchored to: monte_carlo.garch_vol.anchor if set (a stress scenario's base
    values, or a governed override), else this run's own market.fx_vol / market.equity_vol."""
    a = settings.get("monte_carlo", "garch_vol", "anchor", default=None)
    if a:
        return a
    mk = settings["market"]
    return {"fx_vol": dict(mk["fx_vol"]), "equity_vol": mk["equity_vol"]}
RATE_SHOCK_CLASSES = ("Local bond", "Eurobond")   # positions a scenario rate level shock reprices (EQ-B-0044)
GARCH_KEEP_FXREGIMES = ("Peg", "Dollarized")    # the MC's peg logic (2 / 0 percent plus the T&C jump) is kept


MARKET_MOVES = ("linear", "lognormal")                              # EQ-B-0063
DEFAULT_OVERLAPS = ("additive", "lgd_only", "compound")             # EQ-B-0063
OVERLAP_CLASSES = ("Eurobond", "CDS protection")                    # hard-currency spread legs settled on default


def market_move(settings: Settings) -> str:
    """monte_carlo.market_move: "linear" (default, today) or "lognormal" (bounded, mean-preserving)."""
    mm = str(settings.get("monte_carlo", "market_move", default="linear")).lower()
    if mm not in MARKET_MOVES:
        raise ValueError(f"monte_carlo.market_move must be one of {MARKET_MOVES}, got {mm!r}")
    return mm


def default_spread_overlap(settings: Settings) -> str:
    """monte_carlo.default_spread_overlap: "additive" (default, today), "lgd_only" or "compound"."""
    ov = str(settings.get("monte_carlo", "default_spread_overlap", default="additive")).lower()
    if ov not in DEFAULT_OVERLAPS:
        raise ValueError(f"monte_carlo.default_spread_overlap must be one of {DEFAULT_OVERLAPS}, got {ov!r}")
    return ov


def normal_score(x: np.ndarray, df: float) -> np.ndarray:
    """Phi^-1(F_t,nu(x)) with the upper half taken from the survival function, so large latents stay finite."""
    x = np.asarray(x, dtype=float)
    lo = x < 0
    out = np.empty_like(x)
    out[lo] = stats.norm.ppf(stats.t.cdf(x[lo], df))
    out[~lo] = -stats.norm.ppf(stats.t.sf(x[~lo], df))
    return out


def lognormal_market_loss(zn: np.ndarray, vol_pct: float) -> np.ndarray:
    """A long's market loss as a fraction of notional, -(exp(sigma * zn - sigma^2 / 2) - 1), sigma = vol_pct / 100.
    Mean zero for standard normal zn, and below 1 (a long never loses more than 100% from the market move)."""
    sig = vol_pct / 100
    return -np.expm1(sig * zn - 0.5 * sig * sig)


def default_path_move(p: float, thr: float, vol_pct: float, df: float, mm: str, clip: bool = False) -> float:
    """E[m 1{latent < thr}] (clip: E[min(m, 1) 1{latent < thr}]): the mean market loss (fraction of notional, long)
    the default paths carry, closed form.
    linear m = -sigma T / k, k = sqrt(nu / (nu - 2)): G(c) = E[T 1{T < c}] = -(nu + c^2) / (nu - 1) f_nu(c); with clip
    and sigma > 0, m >= 1 on T < b = -k / sigma, so the clipped mean is F(min(b, c)) - sigma / k (G(c) - G(min(b, c))).
    lognormal m = 1 - exp(sigma Z - sigma^2 / 2) < 1, Z < Phi^-1(p): p - Phi(Phi^-1(p) - sigma) (clip changes nothing)."""
    sig = vol_pct / 100
    if mm == "lognormal":
        return float(p - stats.norm.cdf(stats.norm.ppf(p) - sig))
    k = np.sqrt(df / (df - 2))
    G = lambda x: -(df + x * x) / (df - 1) * stats.t.pdf(x, df)
    if clip and sig > 0:
        b = min(-k / sig, thr)
        return float(stats.t.cdf(b, df) - sig / k * (G(thr) - G(b)))
    return float(sig / k * (df + thr * thr) / (df - 1) * stats.t.pdf(thr, df))   # = -sig / k * G(thr)


def vol_source(settings: Settings) -> str:
    src = str(settings.get("monte_carlo", "vol_source", default="regime")).lower()
    if src not in VOL_SOURCES:
        raise ValueError(f"monte_carlo.vol_source must be one of {VOL_SOURCES}, got {src!r}")
    return src


def garch_vol_table(u: Universe, settings: Settings) -> pd.DataFrame:
    """GARCH 12-month vols for every (country, FX | Equity) leg the book holds, with the reason for any fallback."""
    from . import garch as G
    cfg = settings.get("monte_carlo", "garch_vol", default={}) or {}
    prof = u.countries.set_index("country")
    needed = []
    for _, p in u.portfolio.iterrows():
        kind = "Equity" if p["asset_class"] == "Equity" else ("FX" if p["asset_class"] in ("FX", "Local bond") else None)
        if kind and (p["country"], kind) not in needed:
            needed.append((p["country"], kind))
    keep = [k for k in needed if k[1] == "FX" and prof.at[k[0], "fxregime"] in GARCH_KEEP_FXREGIMES]
    tab = G.mc_vols(G.prices_as_of(getattr(u, "prices", None), settings.get("as_of")), u.countries, [k for k in needed if k not in keep],
                    horizon_days=int(cfg.get("horizon_days", 21 * int(settings.horizon_months))),
                    persistence_max=float(cfg.get("persistence_max", G.MC_PERSISTENCE_MAX)),
                    administered=tuple(cfg.get("administered", G.ADMINISTERED)))
    if keep:
        tab = pd.concat([tab, pd.DataFrame([{"country": c, "kind": k, "ticker": "", "vol_pct": np.nan,
                                             "reason": f"fxregime {prof.at[c, 'fxregime']}"} for c, k in keep])], ignore_index=True)
    return tab


def build_positions(u: Universe, country: pd.DataFrame, settings: Settings, mults: pd.DataFrame, df: float) -> pd.DataFrame:
    """Per-position parameters: PDs, thresholds in latent-t space, market vol, jump losses, carry."""
    mk = settings["market"]
    prof = u.countries.set_index("country")
    apply_uplift = bool(settings.get("layer4", "merton", "apply_uplift", default=False))
    rate_shocked = "rate_shock_bp" in u.portfolio.columns
    gv = None
    if vol_source(settings) == "garch":
        gtab = garch_vol_table(u, settings)
        gv = {(r["country"], r["kind"]): r for r in gtab.to_dict(orient="records")}
        anchor = garch_anchor(settings)
    rows = []
    for _, p in u.portfolio.iterrows():
        c = p["country"]; ac = p["asset_class"]; n = float(p["notional_mm"]); dur = float(p["duration_yrs"]) if pd.notna(p["duration_yrs"]) else 0.0
        sign = 1.0 if str(p["direction"]).lower().startswith("long") else -1.0
        cr = country.loc[c]
        spread = float(prof.at[c, "spread"]); fxreg = prof.at[c, "fxregime"]
        fxvol = mk["fx_vol"].get(fxreg, mk["fx_vol"]["Managed"])
        pd_ex = min(0.99, cr["pd_ex"] * (mults.at[p["id"], "sector_mult"] if ac == "Equity" else 1.0))
        pd_pv = min(0.99, cr["pd_pv"] * mults.at[p["id"], "location_mult"])
        stress_dep = float(prof.at[c, "stress_depreciation"])
        # Merton uplift (Layer 4) raises the hard-currency LGD of this sovereign's Eurobonds and CDS when switched on
        uplift = float(cr["lgd_uplift"]) if apply_uplift and ac in ("Eurobond", "CDS protection") and "lgd_uplift" in cr else 0.0
        vol_from = "regime"
        if gv is not None:
            fxvol_regime, eqvol = fxvol, mk["equity_vol"]
            g = gv.get((c, "Equity" if ac == "Equity" else "FX")) if ac in ("FX", "Local bond", "Equity") else None
            if g is not None and np.isfinite(g["vol_pct"]):
                if ac == "Equity":
                    a0 = float(anchor["equity_vol"]); eqvol = g["vol_pct"] * (eqvol / a0 if a0 > 0 else 1.0)
                else:
                    a0 = float(anchor["fx_vol"].get(fxreg, 0.0)); fxvol = g["vol_pct"] * (fxvol_regime / a0 if a0 > 0 else 1.0)
                vol_from = f"garch:{g['ticker']}"
            elif g is not None:
                vol_from = f"regime ({g['reason']})"
        if ac == "FX":
            vol = fxvol; pA, lossA, kindA = cr["pd_tc"], stress_dep + mk["convertibility_haircut"], "fixed"; pB, lossB, kindB = 0.0, 0.0, "none"
        elif ac == "Local bond":
            vol = dur * mk["local_rate_vol"] + fxvol; pA, lossA, kindA = cr["pd_default"], mk["lgd_local"], "beta"; pB, lossB, kindB = cr["pd_tc"], stress_dep, "fixed"
        elif ac == "Eurobond":
            vol = dur * spread * mk["spread_vol_rel"] / 1e4; pA, lossA, kindA = cr["pd_default"], mk["lgd_hard"], "beta"; pB, lossB, kindB = 0.0, 0.0, "none"
        elif ac == "Equity":
            vol = mk["equity_vol"] if gv is None else eqvol; pA, lossA, kindA = pd_ex, mk["equity_exprop_haircut"], "gpd"; pB, lossB, kindB = pd_pv, mk["equity_pv_haircut"], "gpd"
        elif ac == "CDS protection":
            vol = -dur * spread * mk["spread_vol_rel"] / 1e4; pA, lossA, kindA = cr["pd_default"], -mk["lgd_hard"], "beta"; pB, lossB, kindB = 0.0, 0.0, "none"
        else:
            raise ValueError(f"unknown asset class {ac}")
        vol = float(np.sign(vol) * min(abs(vol), mk["vol_cap"]))
        if ac == "CDS protection":
            carry = n * spread / 1e4
        elif ac in ("Eurobond", "Local bond"):
            carry = -sign * n * spread / 1e4
        else:
            carry = 0.0
        rows.append({"id": p["id"], "country": c, "asset_class": ac, "direction": p["direction"], "sign": sign, "notional_mm": n,
                     "duration_yrs": dur, "regime": cr["regime"], "pd_default": cr["pd_default"], "pd_tc": cr["pd_tc"], "pd_ex": pd_ex, "pd_pv": pd_pv,
                     "market_vol_pct": vol, "pA": pA, "thrA": stats.t.ppf(pA, df) if pA > 0 else -np.inf, "lossA_pct": lossA, "kindA": kindA,
                     "pB": pB, "thrB": stats.t.ppf(pB, df) if pB > 0 else -np.inf, "lossB_pct": lossB, "kindB": kindB,
                     "carry_mm": carry, "lgd_mult": cr["lgd_mult"], "lgd_uplift": uplift})
        if gv is not None:
            rows[-1]["vol_from"] = vol_from
        if rate_shocked:
            dy = pd.to_numeric(p["rate_shock_bp"], errors="coerce")
            dy = float(dy) if pd.notna(dy) else 0.0
            rows[-1]["rate_shock_bp"] = dy if ac in RATE_SHOCK_CLASSES else 0.0
            rows[-1]["rate_mtm_pct"] = dur * dy / 100.0 if ac in RATE_SHOCK_CLASSES else 0.0
    out = pd.DataFrame(rows).set_index("id")
    if gv is not None:
        out.attrs["garch_vols"] = gtab.to_dict(orient="records")
    return out


def simulate(u: Universe, country: pd.DataFrame, positions: pd.DataFrame, loadings: pd.DataFrame, settings: Settings,
             df: float, paths: int | None = None, seed: int | None = None) -> MCResult:
    n_requested = int(paths or settings.paths); seed = int(settings.seed if seed is None else seed)
    n = sobol_path_count(n_requested) if settings.use_sobol else n_requested   # 100,000 requested -> 131,072 Sobol paths
    names = u.names; N = len(names); P = len(positions)
    prof = u.countries.set_index("country").loc[names]
    regions = list(prof["region"])
    region_ids = {r: i for i, r in enumerate(sorted(set(regions)))}
    R = len(region_ids)
    dims = 1 + R + 1 + N + 2 * P
    U = _draw_uniforms(n, dims, seed, settings.use_sobol)
    Zg = stats.norm.ppf(U[:, 0]); Zr = stats.norm.ppf(U[:, 1:1 + R]); W = stats.chi2.ppf(np.clip(U[:, 1 + R], 1e-9, 1 - 1e-9), df)
    eps = stats.norm.ppf(U[:, 2 + R:2 + R + N]); Ua = U[:, 2 + R + N:2 + R + N + P]; Ub = U[:, 2 + R + N + P:]
    g = np.sqrt(loadings["global"].to_numpy()); r = np.sqrt(loadings["regional"].to_numpy()); e = np.sqrt(loadings["idio"].to_numpy())
    reg_idx = np.array([region_ids[x] for x in regions])
    latent = (g * Zg[:, None] + r * Zr[:, reg_idx] + e * eps) / np.sqrt(W / df)[:, None]
    z = latent / np.sqrt(df / (df - 2))
    col = {c: i for i, c in enumerate(names)}
    pos_loss = np.zeros((n, P))
    uncapped = np.zeros(n)                              # path loss before the long-loss cap (EQ-B-0053)
    mm = market_move(settings); ov = default_spread_overlap(settings)   # EQ-B-0063; defaults are today's code path
    zn_cache: dict = {}
    for j, (_pid, p) in enumerate(positions.iterrows()):
        x = latent[:, col[p["country"]]]; zz = z[:, col[p["country"]]]
        nn, s = p["notional_mm"], p["sign"]
        if mm == "linear":
            L = -zz * p["market_vol_pct"] / 100
        else:
            if p["country"] not in zn_cache:
                zn_cache[p["country"]] = normal_score(x, df)
            L = lognormal_market_loss(zn_cache[p["country"]], float(p["market_vol_pct"]))
        rm = float(p.get("rate_mtm_pct", 0.0) or 0.0)
        if rm != 0.0:                                   # scenario yield shock: -duration * dy, same on every path
            L = L + rm / 100
        settle = ov != "additive" and p["asset_class"] in OVERLAP_CLASSES
        for kind, thr, loss, uu in ((p["kindA"], p["thrA"], p["lossA_pct"], Ua[:, j]), (p["kindB"], p["thrB"], p["lossB_pct"], Ub[:, j])):
            if kind == "none" or not np.isfinite(thr):
                continue
            hit = x < thr
            # severity only on the paths that hit the threshold: the inverse CDFs are elementwise, so this is
            # bit-identical to adding hit * sev over all paths, and skips about half of the run time (EQ-B-0041)
            if kind == "beta":
                a, b = haircut_distribution(abs(loss) / 100, p["lgd_mult"], settings, p.get("lgd_uplift", 0.0),
                                            asset_class=p["asset_class"])
                sev = np.sign(loss) * sample_haircut(a, b, uu[hit])
            elif kind == "gpd":
                sev = gpd_severity(min(0.95, loss / 100 * p["lgd_mult"]), uu[hit], settings)
            else:
                sev = loss / 100
            if settle and kind == "beta":               # default leg of a Eurobond / CDS (EQ-B-0063)
                if ov == "compound" and p["asset_class"] == "Eurobond":
                    L[hit] = L[hit] + (1.0 - np.minimum(L[hit], 1.0)) * sev   # recovery of market value: LGD on the marked-down price
                    w, clip = a / (a + b), True                # removed on default paths: E[LGD] x E[min(m, 1) 1{hit}]
                else:
                    L[hit] = sev                              # recovery of face: the settlement replaces the mark
                    w, clip = 1.0, False
                # survivors: remove the conditional gain the default paths leave behind, so the zero-mean market move
                # stays zero-mean (otherwise dropping the move on bad-z default paths is a survivor credit)
                pa = float(p["pA"])
                if 0.0 < pa < 1.0:
                    L[~hit] = L[~hit] + w * default_path_move(pa, thr, float(p["market_vol_pct"]), df, mm, clip) / (1.0 - pa)
            else:
                L[hit] = L[hit] + sev
        L = nn * s * L + p["carry_mm"]
        uncapped += L
        if s > 0:
            L = np.minimum(L, nn)
        pos_loss[:, j] = L
    losses = pos_loss.sum(axis=1)
    q = lambda a: float(np.quantile(losses, a))
    var95, var99, var975 = q(0.95), q(0.99), q(0.975)
    es = lambda v: float(losses[losses >= v].mean()) if np.any(losses >= v) else v
    liq = liquidity_cost(positions.reset_index(), country["regime"], settings, 0.99)
    liq_total = float(liq.sum())
    tail = losses >= var99
    contrib = pd.DataFrame({"country": positions["country"], "asset_class": positions["asset_class"], "notional_mm": positions["notional_mm"],
                            "expected_loss_mm": pos_loss.mean(axis=0), "tail_contribution_99_mm": pos_loss[tail].mean(axis=0),
                            "liquidity_cost_99_mm": liq.reindex(positions.index).to_numpy()}, index=positions.index)
    contrib["share_of_es99"] = contrib["tail_contribution_99_mm"] / contrib["tail_contribution_99_mm"].sum()
    byc = contrib.groupby("country")[["notional_mm", "expected_loss_mm", "tail_contribution_99_mm"]].sum()
    metrics = {"paths": n, "paths_requested": n_requested, "df": df, "gross_notional_mm": float(positions["notional_mm"].sum()),
               "net_notional_mm": float((positions["notional_mm"] * positions["sign"]).sum()),
               "expected_loss_mm": float(losses.mean()), "var95_mm": var95, "var99_mm": var99, "es95_mm": es(var95), "es99_mm": es(var99),
               "es975_frtb_mm": es(var975), "liquidity_cost99_mm": liq_total, "lvar99_mm": var99 + liq_total, "les99_mm": es(var99) + liq_total,
               "es99_share_of_gross": es(var99) / float(positions["notional_mm"].sum()),
               "p_loss_above_10pct_gross": float(np.mean(losses > 0.1 * positions["notional_mm"].sum()))}
    el_uncapped = float(uncapped.mean())
    metrics.update({"expected_loss_uncapped_mm": el_uncapped, "long_cap_relief_mm": el_uncapped - metrics["expected_loss_mm"]})
    metrics.update(mc_error(losses, liq_total, batches=int(settings.get("monte_carlo", "mc_error_batches", default=MC_ERROR_BATCHES))))
    k = min(n, 2000)
    sample = {"global": Zg[:k], "regional": Zr[:k], "chi2": W[:k]}
    return MCResult(losses, pos_loss, latent, metrics, contrib, byc, n, df, sample, sorted(region_ids, key=region_ids.get))


MC_ERROR_BATCHES = 32        # batches for the Monte Carlo error of VaR99 / ES99 (VF-004); code default, no assumptions key needed
MC_ERROR_MIN_BATCH = 512     # smallest batch kept (the 99% tail of a batch then has at least 5 points)


def mc_error(losses: np.ndarray, liq_mm: float = 0.0, batches: int = MC_ERROR_BATCHES, alpha: float = 0.99) -> dict:
    """Monte Carlo standard error and 95% band of VaR99 and ES99 by batch means (VF-004).

    The loss vector, in simulation order, is cut into K contiguous batches of equal size (K = `batches`, halved
    until a batch holds at least MC_ERROR_MIN_BATCH paths; K and the batch size stay powers of two when the path
    count is one, so every batch of a scrambled Sobol run is itself a balanced 2^m block). VaR99 and ES99 are
    estimated in each batch; SE = sd(batch estimates, ddof 1) / sqrt(K), and the band is the full-sample estimate
    +/- t(0.975, K-1) x SE. L-VaR99 adds a deterministic liquidity cost, so its SE equals the VaR99 SE.

    Limitation: the batches of one scrambled Sobol sequence share a single scramble, so they are not independent
    replicates, and each batch estimate carries the small-sample bias of a quantile on n/K paths. The batch-means SE
    is the error of a plain Monte Carlo estimator of the same size; the full Sobol set is usually more accurate
    than that, so the SE is a conservative (upper) guide. The rigorous figure needs R independently scrambled
    reruns (randomised QMC: sd over seeds / sqrt(R)), which costs R full simulations; the seed table in
    docs/validation/copula-montecarlo-layers5-6.md is that check. Read-only on `losses`: metrics are unchanged."""
    x = np.asarray(losses, dtype=float)
    n = len(x)
    k = max(2, int(batches))
    k = 1 << (k.bit_length() - 1)                       # power of two
    while k > 2 and n // k < MC_ERROR_MIN_BATCH:
        k //= 2
    b = n // k
    blocks = x[:k * b].reshape(k, b)
    v = np.quantile(blocks, alpha, axis=1)
    e = np.array([blk[blk >= q].mean() for blk, q in zip(blocks, v)])
    full_v = float(np.quantile(x, alpha))
    tail = x >= full_v
    full_e = float(x[tail].mean()) if tail.any() else full_v
    se_v = float(np.std(v, ddof=1) / np.sqrt(k)); se_e = float(np.std(e, ddof=1) / np.sqrt(k))
    t = float(stats.t.ppf(0.975, k - 1))
    return {"var99_se_mm": se_v, "es99_se_mm": se_e, "lvar99_se_mm": se_v,
            "var99_ci95_lo_mm": full_v - t * se_v, "var99_ci95_hi_mm": full_v + t * se_v,
            "es99_ci95_lo_mm": full_e - t * se_e, "es99_ci95_hi_mm": full_e + t * se_e,
            "lvar99_ci95_lo_mm": full_v + liq_mm - t * se_v, "lvar99_ci95_hi_mm": full_v + liq_mm + t * se_v,
            "mc_error_batches": float(k), "mc_error_batch_paths": float(b)}


def loss_histogram(losses: np.ndarray, bins: int = 60) -> dict:
    h, edges = np.histogram(losses, bins=bins)
    return {"counts": h.tolist(), "edges": edges.tolist()}
