"""Debt sustainability analysis and reserve adequacy (roadmap 3.1, 3.2).

`debt_history` rebuilds each country's debt dynamics from the WEO history and projections in
data/live/raw_weo.csv: d_t = d_{t-1} (1+i)/(1+g) - pb_t + sfa_t, with the effective nominal interest
rate i = interest / d_{t-1} (interest = primary minus overall balance), nominal growth g, the primary
balance pb and the stock-flow adjustment sfa as the residual. `stochastic_dsa` runs a fan chart
around the WEO baseline: AR(1) shocks to growth, the primary balance and the interest rate drawn from
the country's own history (winsorised covariance), an iid stock-flow shock, and a currency channel
that revalues the foreign-currency share of the debt (indicator 1.5) with the regime's FX volatility.
`reserve_adequacy` is the IMF ARA metric (fixed: 30% short-term debt + 20% other liabilities + 10%
broad money + 10% exports; floating: 30/15/5/5; managed regimes take the average) from
data/dsa_inputs.csv plus live reserves, GDP and exports. `dsa_table` joins both into one row per
country with the derived scorecard inputs: 1.1 debt service % revenue, 1.2 PPG external debt service
over the next 24 months % reserves (World Bank IDS projections), 2.1 reserves % ARA.
"""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
from ..config import Settings
from ..ingestion import Universe
from .common import as_of_timestamp

HORIZON = 5
US_INFLATION = 0.025
ARA_WEIGHTS = {"fixed": (0.30, 0.20, 0.10, 0.10), "floating": (0.30, 0.15, 0.05, 0.05)}
DSA_COLUMNS = ["country", "iso", "year0", "debt_now", "pb_now", "i_eff_now", "g_nom_now", "r_minus_g", "pb_stabilising", "pb_gap",
               "debt_baseline_5y", "debt_median_5y", "debt_p10_5y", "debt_p25_5y", "debt_p75_5y", "debt_p90_5y", "p_debt_rising", "p_debt_above_80",
               "gfn_pct_gdp", "debt_service_pct_revenue", "fx_debt_service_24m_pct_reserves", "fx_debt_service_years", "reserves_usd_bn", "usable_reserves_usd_bn",
               "ara_metric_usd_bn", "reserves_pct_ara", "ara_weights", "read"]


def _weo(long: pd.DataFrame, iso: str, series: str) -> pd.Series:
    s = long[(long["iso"] == iso) & (long["series"] == series)].set_index("period")["value"].astype(float).sort_index()
    return s[~s.index.duplicated(keep="last")]


def debt_history(weo: pd.DataFrame, iso: str) -> pd.DataFrame:
    """Annual table: debt, primary balance, overall balance, interest, effective rate, nominal growth, real growth, sfa."""
    d = _weo(weo, iso, "GGXWDG_NGDP"); pb = _weo(weo, iso, "GGXONLB_NGDP"); ob = _weo(weo, iso, "GGXCNL_NGDP")
    ngdp = _weo(weo, iso, "NGDP"); gr = _weo(weo, iso, "NGDP_RPCH"); rev = _weo(weo, iso, "GGR_NGDP"); usd = _weo(weo, iso, "NGDPD")
    cpi = _weo(weo, iso, "PCPIPCH")
    df = pd.DataFrame({"debt": d, "pb": pb, "ob": ob, "ngdp": ngdp, "g_real": gr, "revenue": rev, "gdp_usd_bn": usd, "inflation": cpi})
    df["interest"] = df["pb"] - df["ob"]
    df["g_nom"] = df["ngdp"].pct_change()
    df["i_eff"] = df["interest"] / df["debt"].shift(1)
    df["sfa"] = df["debt"] - (df["debt"].shift(1) * (1 + df["i_eff"]) / (1 + df["g_nom"]) - df["pb"])
    return df


def _last(series: pd.Series, default: float) -> float:
    s = series.dropna()
    return float(s.iloc[-1]) if len(s) else float(default)


def _shock_params(hist: pd.DataFrame, year0: int, lookback: int = 25) -> dict:
    """Covariance of annual innovations in (g_nom, pb, i_eff) and the sfa distribution from the realised history."""
    h = hist.loc[(hist.index <= year0) & (hist.index > year0 - lookback), ["g_nom", "pb", "i_eff", "sfa"]].dropna()
    if len(h) < 8:
        return {"cov": np.diag([0.04**2, 1.5**2, 0.01**2]), "sfa_sd": 2.0, "n": len(h), "note": "too little history: default volatilities"}
    inn = h[["g_nom", "pb", "i_eff"]].diff().dropna()
    inn = inn.clip(inn.quantile(0.025), inn.quantile(0.975), axis=1)
    cov = np.atleast_2d(np.cov(inn.values.T)) + np.diag([1e-6, 1e-4, 1e-8])
    caps = np.array([0.15, 4.0, 0.03])                       # growth 15 pp, primary balance 4 pp of GDP, effective rate 3 pp
    sd = np.sqrt(np.diag(cov)); scale = np.minimum(1.0, caps / sd)
    cov = cov * np.outer(scale, scale)
    sfa = h["sfa"].clip(h["sfa"].quantile(0.025), h["sfa"].quantile(0.975))
    return {"cov": cov, "sfa_sd": float(min(sfa.std(ddof=1), 6.0)), "n": len(h), "note": ""}


def stochastic_dsa(hist: pd.DataFrame, year0: int, horizon: int = HORIZON, paths: int = 10000, seed: int = 7, fx_share: float = 0.0,
                   fx_vol_pct: float = 0.0, rho=(0.5, 0.5, 0.3), i_default: float = 0.04) -> dict:
    """Fan chart of debt/GDP around the WEO baseline for year0+1 .. year0+horizon."""
    rng = np.random.default_rng(seed)
    years = list(range(year0 + 1, year0 + horizon + 1))
    base = hist.reindex(years)
    # baseline components: WEO projections where present, else carry the last value forward
    def fill(col, fallback):
        s = base[col].copy()
        last = hist[col].dropna()
        s = s.fillna(last.iloc[-1] if len(last) else fallback).fillna(fallback)
        return s.values.astype(float)
    g_b = fill("g_nom", 0.05); pb_b = fill("pb", 0.0); i_b = fill("i_eff", i_default); infl_b = fill("inflation", 3.0)
    exp_dep = np.maximum(infl_b / 100.0 - US_INFLATION, 0.0)              # expected depreciation of the local currency: inflation differential
    d0 = float(hist.loc[year0, "debt"]) if year0 in hist.index and np.isfinite(hist.loc[year0, "debt"]) else _last(hist["debt"], 50.0)
    # baseline stock-flow adjustment: the residual that makes the model baseline follow the WEO debt projection where one exists
    weo_d = base["debt"].values.astype(float); sfa_b = np.zeros(horizon); prev = d0
    for t in range(horizon):
        model_t = prev * (1 + i_b[t]) / (1 + g_b[t]) * (1 + fx_share * exp_dep[t]) - pb_b[t]
        if np.isfinite(weo_d[t]):
            sfa_b[t] = weo_d[t] - model_t; prev = weo_d[t]
        else:
            prev = model_t
    prm = _shock_params(hist, year0)
    L = np.linalg.cholesky(prm["cov"])
    d = np.full(paths, d0); out = np.empty((horizon, paths)); eps = np.zeros((paths, 3)); rho = np.asarray(rho)
    for t in range(horizon):
        z = rng.standard_normal((paths, 3)) @ L.T
        eps = rho * eps + np.sqrt(1 - rho**2) * z
        g = g_b[t] + eps[:, 0]; pb = pb_b[t] + eps[:, 1]; i = np.maximum(i_b[t] + eps[:, 2], 0.0)
        sfa = rng.normal(0.0, prm["sfa_sd"], paths)
        dep = exp_dep[t] + (rng.normal(0.0, fx_vol_pct / 100.0, paths) if fx_share > 0 and fx_vol_pct > 0 else 0.0)
        d = d * (1 + i) / (1 + g) * (1 + fx_share * dep) - pb + sfa + sfa_b[t]
        d = np.clip(d, 0.0, 400.0)
        out[t] = d
    # deterministic baseline
    db = d0; base_path = []
    for t in range(horizon):
        db = db * (1 + i_b[t]) / (1 + g_b[t]) * (1 + fx_share * exp_dep[t]) - pb_b[t] + sfa_b[t]; base_path.append(db)
    q = np.percentile(out, [10, 25, 50, 75, 90], axis=1)
    fan = pd.DataFrame({"year": years, "baseline_weo": base["debt"].values, "baseline_model": base_path, "p10": q[0], "p25": q[1], "p50": q[2], "p75": q[3], "p90": q[4]})
    return {"debt_now": d0, "fan": fan, "p_rising": float((out[-1] > d0).mean()), "p_above_80": float((out[-1] > 80).mean()),
            "paths": paths, "baseline_sfa": sfa_b.tolist(), "shock_params": {"sd_g": float(np.sqrt(prm["cov"][0, 0])), "sd_pb": float(np.sqrt(prm["cov"][1, 1])), "sd_i": float(np.sqrt(prm["cov"][2, 2])), "sfa_sd": prm["sfa_sd"], "n_hist": prm["n"], "note": prm["note"]}}


def load_dsa_inputs(path: str | Path) -> pd.DataFrame:
    return pd.read_csv(path).set_index("country")


def reserve_adequacy(country: str, prof: pd.Series, inputs: pd.DataFrame, gdp_usd_bn: float, reserves_usd_bn: float) -> dict:
    """IMF ARA metric in US$ bn and reserves as a percentage of it."""
    row = inputs.loc[country] if country in inputs.index else None
    if row is None or str(row.get("ara_applicable", "yes")).lower() != "yes" or not np.isfinite(gdp_usd_bn):
        return {"ara_metric_usd_bn": np.nan, "reserves_pct_ara": np.nan, "usable_reserves_usd_bn": reserves_usd_bn, "ara_weights": "n/a"}
    regime = str(prof["fxregime"])
    exports = float(prof["exports"]) / 100 * gdp_usd_bn
    bm = float(row["broad_money_pct_gdp"]) / 100 * gdp_usd_bn
    std, oth = float(row["st_external_debt_usd_bn"]), float(row["other_liabilities_usd_bn"])
    def metric(w): return w[0] * std + w[1] * oth + w[2] * bm + w[3] * exports
    if regime == "Peg": ara, wname = metric(ARA_WEIGHTS["fixed"]), "fixed"
    elif regime == "Float": ara, wname = metric(ARA_WEIGHTS["floating"]), "floating"
    else: ara, wname = 0.5 * (metric(ARA_WEIGHTS["fixed"]) + metric(ARA_WEIGHTS["floating"])), "average of fixed and floating (managed)"
    usable = reserves_usd_bn * float(row.get("usable_reserves_share", 1.0))
    return {"ara_metric_usd_bn": ara, "reserves_pct_ara": usable / ara * 100 if ara > 0 else np.nan, "usable_reserves_usd_bn": usable, "ara_weights": wname}


def _wb_latest(wb: pd.DataFrame | None, iso: str, series: str, max_period: int | None = None):
    if wb is None: return np.nan, None
    s = wb[(wb["iso"] == iso) & (wb["series"] == series)].dropna(subset=["value"])
    if max_period is not None: s = s[s["period"] <= max_period]
    if not len(s): return np.nan, None
    r = s.sort_values("period").iloc[-1]
    return float(r["value"]), int(r["period"])


def ppg_debt_service_24m(wb: pd.DataFrame | None, iso: str, year0: int) -> tuple[float, str]:
    """PPG external debt service (US$) over the next two complete projection years in the World Bank IDS pull.

    The IDS series arrives by creditor; a year's aggregate is the 'all creditors' row when present (the max,
    when it is at least 60% of the sum) else the sum. Years whose aggregate is under 30% of the largest of the
    next four years are incomplete pulls and are skipped. Returns the two-year total and the years used.
    """
    if wb is None:
        return np.nan, ""
    x = wb[(wb["iso"] == iso) & (wb["series"] == "DT.TDS.DPPG.CD") & (wb["period"] > year0) & (wb["period"] <= year0 + 4)].dropna(subset=["value"])
    if x.empty:
        return np.nan, ""
    g = x.groupby("period")["value"].agg(["max", "sum"])
    agg = np.where(g["max"] >= 0.6 * g["sum"], g["max"], g["sum"])
    agg = pd.Series(agg, index=g.index).sort_index()
    ok = agg[agg >= 0.3 * agg.max()]
    if len(ok) < 2:
        return np.nan, ""
    use = ok.iloc[:2]
    return float(use.sum()), f"{int(use.index[0])}-{int(use.index[1])}"


def _read(r: pd.Series) -> str:
    bits = []
    if np.isfinite(r["p_debt_rising"]):
        bits.append("debt likely rising" if r["p_debt_rising"] >= 0.6 else "debt likely falling" if r["p_debt_rising"] <= 0.4 else "debt path balanced")
    if np.isfinite(r["reserves_pct_ara"]):
        bits.append("reserves below ARA floor" if r["reserves_pct_ara"] < 100 else "reserves adequate" if r["reserves_pct_ara"] <= 150 else "reserves ample")
    if np.isfinite(r["debt_service_pct_revenue"]) and r["debt_service_pct_revenue"] >= 30:
        bits.append("debt service heavy")
    return "; ".join(bits)


def resolve_year0(settings: Settings | None = None, year0: int | None = None, as_of=None) -> int:
    """The DSA base year: explicit `year0`, else the year before the as-of date (`as_of`, else settings["as_of"]).

    Only when neither is given does it fall back to the calendar (kept for backward compatibility; callers should
    pass `year0` or `as_of` so a rerun of the same inputs gives the same table)."""
    if year0:
        return int(year0)
    try:
        ts = as_of_timestamp(settings, as_of)
    except ValueError:
        ts = pd.Timestamp.today()                                     # legacy fallback: prefer an explicit year0 / as_of
    return int(ts.year) - 1


def dsa_table(u: Universe, settings: Settings, weo: pd.DataFrame, wb: pd.DataFrame | None, inputs: pd.DataFrame, year0: int | None = None,
              paths: int = 10000, seed: int = 7, as_of=None) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    """One row per country plus the stacked fan-chart table and per-country shock diagnostics."""
    prof = u.countries.set_index("country"); ind = u.indicators.set_index("id")
    fxv = settings["market"]["fx_vol"]
    year0 = resolve_year0(settings, year0, as_of)
    rows, fans, diag = [], [], {}
    for c in u.names:
        iso = prof.loc[c, "iso"]
        hist = debt_history(weo, iso)
        if hist["debt"].dropna().empty:
            continue
        y0 = year0 if year0 in hist.index and np.isfinite(hist.loc[year0, "debt"]) else int(hist["debt"].dropna().index.max())
        fx_share = float(ind.loc["1.5", c]) / 100 if "1.5" in ind.index else 0.0
        i_default = 0.04 + float(prof.loc[c, "spread"]) / 10000          # risk-free plus the sovereign spread when WEO has no interest data
        res = stochastic_dsa(hist, y0, paths=paths, seed=seed, fx_share=fx_share, fx_vol_pct=float(fxv.get(str(prof.loc[c, "fxregime"]), 7.0)), i_default=i_default)
        fan = res["fan"].copy(); fan.insert(0, "country", c); fans.append(fan)
        h0 = hist.loc[y0]; h1 = hist.loc[y0 + 1] if (y0 + 1) in hist.index else h0
        i_eff = float(h0["i_eff"]) if np.isfinite(h0["i_eff"]) else _last(hist["i_eff"], i_default)
        g_nom = float(h0["g_nom"]) if np.isfinite(h0["g_nom"]) else _last(hist["g_nom"], 0.05)
        pb_star = res["debt_now"] * (i_eff - g_nom) / (1 + g_nom)
        maturity = float(inputs.loc[c, "avg_maturity_yrs"]) if c in inputs.index else 7.0
        amort = res["debt_now"] / maturity
        gfn = -float(h1["ob"]) + amort if np.isfinite(h1["ob"]) else np.nan
        revenue = float(h1["revenue"]) if np.isfinite(h1["revenue"]) else _last(hist["revenue"], np.nan)
        interest = float(h1["interest"]) if np.isfinite(h1["interest"]) else _last(hist["interest"], i_eff * res["debt_now"])
        dsr = (interest + amort) / revenue * 100 if np.isfinite(revenue) and revenue > 0 else np.nan
        gdp_usd = float(h0["gdp_usd_bn"]) if np.isfinite(h0["gdp_usd_bn"]) else np.nan
        res_usd, _ = _wb_latest(wb, iso, "FI.RES.TOTL.CD")
        res_usd = res_usd / 1e9 if np.isfinite(res_usd) else float(prof.loc[c, "reserves"]) / 100 * gdp_usd
        ds24, ds_years = ppg_debt_service_24m(wb, iso, y0)
        fxds = ds24 / 1e9 / res_usd * 100 if np.isfinite(ds24) and res_usd > 0 else np.nan
        ara = reserve_adequacy(c, prof.loc[c], inputs, gdp_usd, res_usd)
        f5 = res["fan"].iloc[-1]
        pb_now = float(h0["pb"]) if np.isfinite(h0["pb"]) else _last(hist["pb"], np.nan)
        row = {"country": c, "iso": iso, "year0": y0, "debt_now": res["debt_now"], "pb_now": pb_now, "i_eff_now": i_eff * 100, "g_nom_now": g_nom * 100,
               "r_minus_g": (i_eff - g_nom) * 100, "pb_stabilising": pb_star, "pb_gap": pb_now - pb_star,
               "debt_baseline_5y": float(f5["baseline_weo"]) if np.isfinite(f5["baseline_weo"]) else float(f5["baseline_model"]), "debt_median_5y": float(f5["p50"]),
               "debt_p10_5y": float(f5["p10"]), "debt_p25_5y": float(f5["p25"]), "debt_p75_5y": float(f5["p75"]), "debt_p90_5y": float(f5["p90"]),
               "p_debt_rising": res["p_rising"], "p_debt_above_80": res["p_above_80"], "gfn_pct_gdp": gfn, "debt_service_pct_revenue": dsr,
               "fx_debt_service_24m_pct_reserves": fxds, "fx_debt_service_years": ds_years, "reserves_usd_bn": res_usd, **ara}
        row["read"] = _read(pd.Series(row))
        rows.append(row); diag[c] = res["shock_params"]
    table = pd.DataFrame(rows)[DSA_COLUMNS] if rows else pd.DataFrame(columns=DSA_COLUMNS)
    return table, pd.concat(fans, ignore_index=True) if fans else pd.DataFrame(), diag


SCORECARD_FEEDS = {"1.1": ("debt_service_pct_revenue", "WEO interest (GGXONLB-GGXCNL) + debt/avg maturity, % of GGR_NGDP, year t+1"),
                   "1.2": ("fx_debt_service_24m_pct_reserves", "World Bank IDS DT.TDS.DPPG.CD, next two complete projection years / FI.RES.TOTL.CD"),
                   "2.1": ("reserves_pct_ara", "usable reserves / IMF ARA metric (ST debt, other liabilities, broad money, exports; dsa_inputs.csv)")}


FEED_COLUMNS = ["table", "key", "country", "value", "source", "series", "retrieved", "iso", "year0", "dsa_column"]
FEEDS_FILE = "dsa_scorecard_feeds.csv"


def scorecard_feeds(table: pd.DataFrame, retrieved: str | None = None, keys=tuple(SCORECARD_FEEDS)) -> pd.DataFrame:
    """The derived scorecard inputs as proposed cells, one row per (key, country) with a finite value.

    Pure: reads nothing and writes nothing. The first seven columns are the `data/live/provenance.csv` columns
    (table, key, country, value, source, series, retrieved), so Team A's ingestion gate can compare `value`
    with the seed in indicators.csv, hold or apply it, and append the row to provenance.csv / review.csv inside a
    vintage. `iso`, `year0` (the DSA base year) and `dsa_column` (the dsa.csv column the value came from) are
    extra context. `retrieved` is the as-of date of the DSA run (YYYY-MM-DD); pass it explicitly."""
    unknown = [k for k in keys if k not in SCORECARD_FEEDS]
    if unknown:
        raise ValueError(f"unknown DSA scorecard keys {unknown}; known: {sorted(SCORECARD_FEEDS)}")
    retrieved = retrieved or pd.Timestamp.today().strftime("%Y-%m-%d")    # legacy fallback: prefer an explicit date
    rows = []
    for _, r in table.iterrows():
        for key in keys:
            col, series = SCORECARD_FEEDS[key]
            v = r[col]
            if v is None or not np.isfinite(float(v)):
                continue
            rows.append({"table": "Inputs", "key": str(key), "country": r["country"], "value": round(float(v), 4), "source": "econquest dsa",
                         "series": series, "retrieved": retrieved, "iso": r.get("iso", ""), "year0": int(r["year0"]) if "year0" in r else None,
                         "dsa_column": col})
    return pd.DataFrame(rows, columns=FEED_COLUMNS)


def write_scorecard_feeds(feeds: pd.DataFrame, out_dir: str | Path) -> Path:
    """Write the proposed cells to `<out_dir>/dsa_scorecard_feeds.csv` (an engine output; never into data/)."""
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    path = out / FEEDS_FILE
    feeds[FEED_COLUMNS].to_csv(path, index=False)
    return path


def apply_to_inputs(table: pd.DataFrame, data_dir: str | Path, retrieved: str | None = None, keys=tuple(SCORECARD_FEEDS), max_rel_change: float = 0.5, force: bool = False) -> dict:
    """Removed (EQ-B-0010, HO-20261023-A-B-001): the engine no longer writes indicators.csv, provenance.csv or review.csv.

    Use `scorecard_feeds(table, retrieved=as_of)` and `write_scorecard_feeds(feeds, outputs_dir)`; Team A's ingestion
    applies `outputs/dsa_scorecard_feeds.csv` through its quality gate inside a vintage."""
    raise RuntimeError("econquest.engine.dsa.apply_to_inputs no longer writes data/indicators.csv or data/live/*: call "
                       "dsa.scorecard_feeds(table, retrieved=as_of) and dsa.write_scorecard_feeds(feeds, out_dir), then apply "
                       "outputs/dsa_scorecard_feeds.csv through the ingestion gate (EQ-B-0010, HO-20261023-A-B-001)")


def dsa_plan(table: pd.DataFrame, fans: pd.DataFrame, as_of: str, sheet: str = "Debt Sustainability") -> list[dict]:
    """Workbook ranges for the Debt Sustainability tab."""
    def v(x):
        if isinstance(x, (float, np.floating)):
            return "" if not np.isfinite(x) else round(float(x), 4)
        return x
    head = ["Country", "Debt/GDP now", "Primary balance", "Effective rate %", "Nominal growth %", "r-g (pp)", "Debt-stabilising PB", "PB gap", "WEO baseline 5y", "Median 5y", "P10", "P25", "P75", "P90",
            "P(debt rising)", "P(debt > 80)", "GFN % GDP", "Debt service % revenue (1.1)", "FX debt service 24m % reserves (1.2)", "Reserves $bn", "Usable reserves $bn", "ARA metric $bn", "Reserves % ARA (2.1)", "ARA weights", "Read"]
    cols = ["country", "debt_now", "pb_now", "i_eff_now", "g_nom_now", "r_minus_g", "pb_stabilising", "pb_gap", "debt_baseline_5y", "debt_median_5y", "debt_p10_5y", "debt_p25_5y", "debt_p75_5y", "debt_p90_5y",
            "p_debt_rising", "p_debt_above_80", "gfn_pct_gdp", "debt_service_pct_revenue", "fx_debt_service_24m_pct_reserves", "reserves_usd_bn", "usable_reserves_usd_bn", "ara_metric_usd_bn", "reserves_pct_ara", "ara_weights", "read"]
    body = [[v(r[c]) for c in cols] for _, r in table.iterrows()]
    n = len(body)
    plan = [{"range": f"'{sheet}'!A1:A2", "values": [["Debt sustainability and reserve adequacy: stochastic DSA fan charts around the IMF WEO baseline and the IMF ARA reserve metric"],
             [f"Written by `python -m econquest dsa` on {as_of}. Debt dynamics d(t) = d(t-1)(1+i)/(1+g) - pb + sfa with AR(1) shocks to growth, primary balance and the effective rate from each country's own history, a stock-flow shock and a currency revaluation of the FX share of debt; 10,000 paths, five years. ARA: 30% short-term debt + 20%/15% other liabilities + 10%/5% broad money + 10%/5% exports (fixed/floating; managed takes the average); inputs in data/dsa_inputs.csv are analyst estimates until live pulls exist. Columns marked (1.1), (1.2), (2.1) are written to outputs/dsa_scorecard_feeds.csv and feed the scorecard through the ingestion quality gate."]]},
            {"range": f"'{sheet}'!A4:Y4", "values": [head]}]
    if n:
        plan.append({"range": f"'{sheet}'!A5:Y{4 + n}", "values": body})
    r0 = 7 + n
    plan.append({"range": f"'{sheet}'!A{r0}:H{r0}", "values": [["Fan chart (debt/GDP by year)", "Year", "WEO baseline", "Model baseline", "P10", "P25", "P50", "P75"]]})
    fan_rows = [[r["country"], int(r["year"]), v(r["baseline_weo"]), v(r["baseline_model"]), v(r["p10"]), v(r["p25"]), v(r["p50"]), v(r["p75"])] for _, r in fans.iterrows()]
    if fan_rows:
        plan.append({"range": f"'{sheet}'!A{r0 + 1}:H{r0 + len(fan_rows)}", "values": fan_rows})
    return plan
