"""Caldara-Iacoviello Geopolitical Risk index: country uplift on indicator 4.10 and the GPR signals
(workbook GPR tab). Inputs: monthly GPR table (month, GPR, GPRT, GPRA, GPRC_xxx columns)."""
from __future__ import annotations
import numpy as np
import pandas as pd
from ..config import Settings
from ..ingestion import Universe


def _stats(series: np.ndarray, window: int) -> dict:
    s = np.asarray(series, dtype=float)
    recent = s[-window:].mean()
    last60 = s[-60:]; last120 = s[-120:]
    sd = last60.std(ddof=1)
    z = (recent - last60.mean()) / sd if sd > 0 else 0.0
    pct = float(np.mean(last120 <= recent) * 100)
    prev12 = s[-12 - window:-window].mean()
    return {"recent": float(recent), "mean5y": float(last60.mean()), "sd5y": float(sd), "z": float(z), "percentile": pct,
            "momentum": float(recent / prev12) if prev12 else np.nan}


def run_gpr(u: Universe, settings: Settings, gpr: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    g = settings["gpr"]; w = g["signal_weight_percentile"]; n = int(g["window_months"])
    prof = u.countries.set_index("country").loc[u.names]
    ind = u.indicators.set_index("id")
    rows = {}
    for c in u.names:
        series = prof.at[c, "gpr_series"]
        analyst = pd.to_numeric(prof.at[c, "gpr_analyst_410"], errors="coerce")
        if pd.isna(analyst) and "4.10" in ind.index and c in ind.columns:
            # a profile row without the analyst 4.10 level (a newly added country, EQ-B-0034) takes the indicator
            # table's 4.10; min(4.0, nan) would otherwise have returned 4.0, the worst level, without a word
            analyst = pd.to_numeric(ind.at["4.10", c], errors="coerce")
        analyst = float(analyst)
        covered = isinstance(series, str) and series in gpr.columns
        if covered:
            st = _stats(gpr[series].to_numpy(dtype=float), n)
            uplift = 0
            if g["use_uplift"]:
                if st["percentile"] >= g["uplift2_percentile"] and st["z"] >= g["uplift2_z"]:
                    uplift = 2
                elif st["percentile"] >= g["uplift1_percentile"] or st["z"] >= g["uplift1_z"]:
                    uplift = 1
            signal = round(w * st["percentile"] + (1 - w) * max(0.0, min(100.0, 50 + 25 * st["z"])), 0)
        else:
            st = {k: np.nan for k in ("recent", "mean5y", "sd5y", "z", "percentile", "momentum")}
            uplift, signal = 0, 0.0
        rows[c] = {"series": series if covered else "", "covered": covered, **st, "analyst_410": analyst, "uplift": uplift,
                   "final_410": min(4.0, analyst + uplift) if np.isfinite(analyst) else np.nan, "signal": float(signal)}
    glob = _stats(gpr["GPR"].to_numpy(dtype=float), n)
    threats = gpr["GPRT"].to_numpy(dtype=float)[-n:].mean() / gpr["GPRA"].to_numpy(dtype=float)[-n:].mean()
    glob_signal = round(w * glob["percentile"] + (1 - w) * max(0.0, min(100.0, 50 + 25 * glob["z"])), 0)
    global_block = {**glob, "threats_acts_ratio": float(threats), "signal": float(glob_signal), "latest_month": str(gpr["month"].iloc[-1])}
    return pd.DataFrame(rows).T, global_block
