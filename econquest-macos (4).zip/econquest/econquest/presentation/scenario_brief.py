"""Scenario briefs (EQ-C-0025): one self-contained HTML brief (and optional PDF, as for the country notes) per named
stress scenario of data/scenarios.json that has results.

Each brief: the narrative (description, source and the shock channels from scenarios.json), the book impact (VaR, ES,
L-VaR, EL and liquidity cost against base, from outputs/stress.json, else outputs/scenario_library.csv), the countries
and positions that contribute most to the stressed tail (the archived stress-<key> run against the base run), the
reverse-stress distance (outputs/reverse_stress.json: the share of the scenario's severity at which a book limit is
first breached), the playbook trades that activate under the scenario as candidate hedges (decision support only),
the book-wide input caveats and the disclaimer, stamped with base and stress run ids and hashes.
Formatting only: every number comes from the outputs above.

    from econquest.presentation.scenario_brief import build_scenario_briefs
    res = build_scenario_briefs("outputs", "data", "outputs/briefs", scenarios=["TAIWAN"], pdf=False)
    # -> {"kind": "scenario_briefs", "paths": [...], "items": [...], "run_id", "as_of", "data_hash", "run_hash", ...}
"""
from __future__ import annotations
import datetime as dt
import json
import time
from pathlib import Path

import pandas as pd

from .country_note import (NOTE_CSS, _by, _fnum, _index_html, _read, _read_json, default_pdf_workers, load_stress_runs, render_pdfs, result_bundle,
                           run_stamps, slug, stamp_html, svg_hbars)
from .report import DISCLAIMER, _e, _f, _pct, caveats_html, input_caveats, product_sources, sources_html
from .risk_monitor import load_latest

BOOK_MEASURES = (("var99_mm", "VaR 99%"), ("es99_mm", "ES 99%"), ("es975_frtb_mm", "ES 97.5% (FRTB)"), ("lvar99_mm", "Liquidity-adjusted VaR 99%"),
                 ("expected_loss_mm", "Expected loss"), ("liquidity_cost99_mm", "Liquidity cost 99%"))
HEDGE_STANCES = ("Risk-off", "Hedge", "Event", "Relative value")
TOP_N = 8
SHORT = {"var99_mm": "VaR 99%", "es99_mm": "ES 99%", "es975_frtb_mm": "ES 97.5%", "lvar99_mm": "L-VaR 99%"}

COUNTRY_CHANNELS = {"spread": "Sovereign spreads", "fx3m": "Currencies (3-month move)", "textz": "News and text sentiment", "rating": "Credit ratings",
                    "commgap": "Commodity prices", "res3m": "Reserves", "emergency": "Political and security flags", "coup": "Political and security flags",
                    "location": "Political and security flags", "disaster": "Climate and disaster"}


def channel_of(shock: dict) -> str:
    """The transmission channel a scenarios.json shock acts through (a label for the brief; no model meaning)."""
    t = shock.get("target")
    if t == "countries":
        return COUNTRY_CHANNELS.get(str(shock.get("column")), f"Country profile: {shock.get('column')}")
    if t == "indicators":
        return "Scorecard indicators"
    if t == "trigger":
        return "Scorecard pillar triggers"
    if t == "portfolio":
        return "Positions"
    if t == "settings":
        k = str(shock.get("key", ""))
        if k.startswith("regime."):
            return "Contagion and regime loadings"
        if k.startswith("liquidity."):
            return "Market liquidity"
        if k.startswith("market."):
            return "Market parameters (LGD, volatility)"
        return f"Settings: {k.split('.')[0]}"
    return str(t)


def channels(shocks: list[dict]) -> list[tuple[str, list[str]]]:
    from ..engine.stress import summarise_shocks
    out: dict[str, list[str]] = {}
    for sh in shocks or []:
        try:
            line = summarise_shocks([sh])[0]
        except (KeyError, TypeError, ValueError):
            line = json.dumps(sh)[:160]
        out.setdefault(channel_of(sh), []).append(line)
    return list(out.items())


def svg_path(path: list[dict], limit: float | None, breach: float | None, unit: str = "$mm", width: int = 520, height: int = 200) -> str:
    """Reverse-stress search path: the measure against scenario scale, with the limit line and the breach scale."""
    pts = [(float(p["scale"]), float(p["value"])) for p in path or [] if _fnum(p.get("scale")) is not None and _fnum(p.get("value")) is not None]
    if len(pts) < 2:
        return ""
    pts.sort()
    xs = [x for x, _ in pts]; ys = [y for _, y in pts] + ([limit] if limit is not None else [])
    lo, hi = min(ys) * 0.95, max(ys) * 1.05
    x0, x1, y0, y1 = 46, width - 14, 10, height - 30
    X = lambda v: x0 + (v - xs[0]) / ((xs[-1] - xs[0]) or 1) * (x1 - x0)
    Y = lambda v: y1 - (v - lo) / ((hi - lo) or 1) * (y1 - y0)
    line = " ".join(f"{X(x):.1f},{Y(y):.1f}" for x, y in pts)
    g = f'<polyline points="{line}" fill="none" stroke="#1f4e79" stroke-width="2"/>' + "".join(f'<circle cx="{X(x):.1f}" cy="{Y(y):.1f}" r="2.5" fill="#1f4e79"/>' for x, y in pts)
    if limit is not None:
        g += f'<line x1="{x0}" x2="{x1}" y1="{Y(limit):.1f}" y2="{Y(limit):.1f}" stroke="#a93226" stroke-dasharray="5 4"/><text x="{x1 - 4}" y="{Y(limit) - 4:.1f}" font-size="10" fill="#a93226" text-anchor="end">limit {limit:,.1f} {unit}</text>'
    if breach is not None:
        g += f'<line x1="{X(breach):.1f}" x2="{X(breach):.1f}" y1="{y0}" y2="{y1}" stroke="#a93226"/><text x="{X(breach) + 4:.1f}" y="{y0 + 10}" font-size="10" fill="#a93226">breach at {breach:.2f}x</text>'
    ticks = "".join(f'<text x="{X(x):.1f}" y="{y1 + 14}" font-size="10" fill="#666" text-anchor="middle">{x:g}</text>' for x in xs if x in (xs[0], xs[-1]) or x in (0.5, 1.0, 2.0))
    ticks += f'<text x="{x0 - 5}" y="{Y(lo) :.1f}" font-size="10" fill="#666" text-anchor="end">{lo:.0f}</text><text x="{x0 - 5}" y="{Y(hi) + 8:.1f}" font-size="10" fill="#666" text-anchor="end">{hi:.0f}</text>'
    ticks += f'<text x="{(x0 + x1) / 2:.0f}" y="{height - 4}" font-size="10" fill="#333" text-anchor="middle">scenario severity (x scenario as defined)</text>'
    return f'<svg class="chart" viewBox="0 0 {width} {height}" width="100%" style="max-width:{width}px" role="img" aria-label="Reverse stress search path">{g}{ticks}</svg>'


def _book_impact(key: str, stress: dict, library: pd.DataFrame | None) -> tuple[list[dict], dict, str]:
    """[{measure, label, base, stress, delta, pct}], extras, source note."""
    v = (stress or {}).get(key)
    if v and isinstance(v.get("comparison"), dict):
        c = v["comparison"]; rows = []
        for k, lbl in BOOK_MEASURES:
            m = c.get(k) or {}
            b, s = _fnum(m.get("base")), _fnum(m.get("stress"))
            rows.append({"measure": k, "label": lbl, "base": b, "stress": s, "delta": None if b is None or s is None else s - b, "pct": _fnum(m.get("change_pct"))})
        extra = {"regimes": c.get("regimes") or {}, "share_to_crisis": _fnum(c.get("share_to_crisis")),
                 "mean_pd_pp": _fnum(c.get("mean_pd_default_change_pp")), "mean_lgd_pp": _fnum(c.get("mean_lgd_change_pp"))}
        return rows, extra, "outputs/stress.json (written by `econquest run --stress` against this base run)"
    if library is not None and "scenario" in library.columns and key in set(library["scenario"].astype(str)):
        r = library[library["scenario"].astype(str) == key].iloc[-1]; rows = []
        for k, lbl in BOOK_MEASURES:
            s = _fnum(r.get(k)); pct = _fnum(r.get(k + "_pct"))
            b = s / (1 + pct / 100) if s is not None and pct is not None and pct != -100 else None
            rows.append({"measure": k, "label": lbl, "base": b, "stress": s, "delta": None if b is None or s is None else s - b, "pct": pct})
        extra = {"regimes": {}, "share_to_crisis": _fnum(r.get("to_crisis")), "mean_pd_pp": _fnum(r.get("mean_pd_pp")), "mean_lgd_pp": None,
                 "scale": _fnum(r.get("scale"))}
        return rows, extra, (f"outputs/scenario_library.csv (`econquest stress`, scale {_f(r.get('scale'), 2)}; its own base run, which may differ from the base run stamped here; "
                             "base values derived from the stressed value and the % change)")
    return [], {}, "no results: run `econquest run --stress --scenario " + key + "` (or `econquest stress`)"


def _contributors(base: dict, sr: dict | None) -> tuple[list[dict], list[dict]]:
    if not sr:
        return [], []
    bb, sb = _by(base.get("by_country")), _by(sr.get("by_country"))
    bc, sc = _by(base.get("country")), _by(sr.get("country"))
    rows = []
    for c, r in sb.items():
        b = _fnum((bb.get(c) or {}).get("tail_contribution_99_mm")); s = _fnum(r.get("tail_contribution_99_mm"))
        rows.append({"country": c, "base": b, "stress": s, "delta": None if b is None or s is None else s - b,
                     "pd_base": _fnum((bc.get(c) or {}).get("pd_default")), "pd_stress": _fnum((sc.get(c) or {}).get("pd_default")),
                     "regime_base": (bc.get(c) or {}).get("regime"), "regime_stress": (sc.get(c) or {}).get("regime")})
    rows.sort(key=lambda r: -(r["stress"] if r["stress"] is not None else float("-inf")))
    bp, sp = _by(base.get("contributions"), "id"), _by(sr.get("contributions"), "id")
    pos = []
    for pid, r in sp.items():
        b = _fnum((bp.get(pid) or {}).get("tail_contribution_99_mm")); s = _fnum(r.get("tail_contribution_99_mm"))
        pos.append({"id": pid, "country": r.get("country"), "asset_class": r.get("asset_class"), "notional_mm": _fnum(r.get("notional_mm")),
                    "base": b, "stress": s, "delta": None if b is None or s is None else s - b, "share": _fnum(r.get("share_of_es99"))})
    pos.sort(key=lambda r: -(r["stress"] if r["stress"] is not None else float("-inf")))
    return rows[:TOP_N], pos[:5]


def _hedges(base: dict, sr: dict | None, countries: list[str], playbook: pd.DataFrame | None) -> list[dict]:
    """Playbook trades with a hedging stance that are active in the stressed run for the top-contributing countries."""
    if not sr or playbook is None:
        return []
    ba = _by(base.get("activation"), "trade")
    out = []
    for a in sr.get("activation") or []:
        t = a.get("trade")
        if t not in playbook.index or str(playbook.at[t, "stance"]) not in HEDGE_STANCES:
            continue
        hits = [(c, _fnum(a.get(c))) for c in countries if _fnum(a.get(c)) is not None]
        if not hits:
            continue
        new = [c for c, _ in hits if _fnum((ba.get(t) or {}).get(c)) is None]
        out.append({"trade": t, "strategy": playbook.at[t, "strategy"], "stance": playbook.at[t, "stance"], "instrument": playbook.at[t, "instrument"],
                    "expression": playbook.at[t, "expression"], "risks": playbook.at[t, "risks"], "countries": hits, "new_under_stress": new,
                    "score": sum(v for _, v in hits)})
    out.sort(key=lambda h: -h["score"])
    return out[:TOP_N]


def render_brief(key: str, sc, base: dict, sr: dict | None, ctx: dict) -> str:
    st = ctx["stamps"]; sst = run_stamps(sr) if sr else {}
    rows, extra, src = _book_impact(key, ctx["stress"], ctx["library"])
    name = sc.name if sc else (ctx["stress"].get(key) or {}).get("name", key)
    title = f"Scenario brief: {name}"
    # narrative
    ch = channels(sc.shocks) if sc else []
    narr = (f"<p>{_e(sc.description if sc else (ctx['stress'].get(key) or {}).get('description', ''))}</p>"
            f"<p class='note'>Kind: {_e(sc.kind if sc else 'n/a')}. Source: {_e((sc.source if sc else '') or 'n/a')}. Key {_e(key)} in data/scenarios.json.</p>")
    if ch:
        narr += ("<h3>Channels (shocks as defined, scale 1)</h3><table class='compact'><tr><th>Channel</th><th>Shocks</th></tr>"
                 + "".join(f"<tr><td>{_e(c)}</td><td>{'<br>'.join(_e(x) for x in lines)}</td></tr>" for c, lines in ch) + "</table>")
    # book impact
    if rows:
        tbl = "".join(f"<tr><td>{_e(r['label'])}</td><td class='n'>{_f(r['base'])}</td><td class='n'>{_f(r['stress'])}</td>"
                      f"<td class='n'>{'' if r['delta'] is None else format(r['delta'], '+,.1f')}</td><td class='n'>{'' if r['pct'] is None else format(r['pct'], '+.1f') + '%'}</td></tr>" for r in rows)
        chart = svg_hbars(sum(([(f"{SHORT.get(r['measure'], r['label'])} base", r["base"]), (f"{SHORT.get(r['measure'], r['label'])} stressed", r["stress"])] for r in rows[:4]), []),
                          unit=" $mm", fmt=lambda v: f"{v:,.1f}", width=560, label_w=210, aria="Book risk, base against stressed, $mm")
        reg = extra.get("regimes") or {}
        regtxt = (f"Regimes: {_e(', '.join(f'{k} {n}' for k, n in (reg.get('base') or {}).items()))} &rarr; {_e(', '.join(f'{k} {n}' for k, n in (reg.get('stress') or {}).items()))}. " if reg else "")
        book = (f"<table><tr><th>Measure ($mm)</th><th class='n'>Base</th><th class='n'>Stressed</th><th class='n'>Change $mm</th><th class='n'>Change %</th></tr>{tbl}</table>{chart}"
                f"<p class='note'>{regtxt}Moved to Crisis: {_pct(extra.get('share_to_crisis'), 0)} of countries; mean default PD change {_f(extra.get('mean_pd_pp'), 2)} pp"
                + (f"; mean LGD change {_f(extra.get('mean_lgd_pp'), 2)} pp" if extra.get("mean_lgd_pp") is not None else "") + f". Source: {_e(src)}.</p>")
    else:
        book = f"<p class='empty'>No book impact: {_e(src)}.</p>"
    # contributors
    crs, pos = _contributors(base, sr)
    if crs:
        contrib = ("<h3>Top countries by stressed 99% tail contribution</h3><table class='compact'><tr><th>Country</th><th class='n'>Base $mm</th><th class='n'>Stressed $mm</th><th class='n'>Change $mm</th>"
                   "<th class='n'>Default PD base</th><th class='n'>Stressed</th><th>Regime</th></tr>" + "".join(
                       f"<tr><td>{_e(r['country'])}</td><td class='n'>{_f(r['base'], 2)}</td><td class='n'>{_f(r['stress'], 2)}</td><td class='n'>{'' if r['delta'] is None else format(r['delta'], '+.2f')}</td>"
                       f"<td class='n'>{_pct(r['pd_base'])}</td><td class='n'>{_pct(r['pd_stress'])}</td><td>{_e(r['regime_base'])} &rarr; {_e(r['regime_stress'])}</td></tr>" for r in crs) + "</table>"
                   + "<h3>Top positions</h3><table class='compact'><tr><th>ID</th><th>Country</th><th>Asset</th><th class='n'>Notional $mm</th><th class='n'>Base $mm</th><th class='n'>Stressed $mm</th><th class='n'>Share of stressed ES99</th></tr>" + "".join(
                       f"<tr><td>{_e(p['id'])}</td><td>{_e(p['country'])}</td><td>{_e(p['asset_class'])}</td><td class='n'>{_f(p['notional_mm'], 1)}</td><td class='n'>{_f(p['base'], 2)}</td><td class='n'>{_f(p['stress'], 2)}</td><td class='n'>{_pct(p['share'], 1)}</td></tr>" for p in pos) + "</table>"
                   + f"<p class='note'>Stress run {_e(sst.get('run_id'))} against base run {_e(st.get('run_id'))}. {_e(ctx['stress_note'])}</p>")
    else:
        contrib = "<p class='empty'>No archived stress-" + _e(key) + " run (outputs/store): per-country contributions need `econquest run --stress`.</p>"
    # reverse stress
    rs = next((r for r in (ctx["reverse"] or {}).get("scenarios") or [] if r.get("scenario") == key), None)
    if rs:
        bs = _fnum(rs.get("breach_scale")); lim = _fnum(rs.get("limit"))
        dist = (f"The book first breaches its {_e(rs.get('measure'))} limit of {_f(lim)} $mm at <b>{bs:.2f}x</b> this scenario's severity "
                + (f"(the book absorbs {bs:.0%} of the scenario before breaching; the full scenario is {1 / bs:.1f}x the breach severity)" if bs and bs > 0 else "") + f", with {_e(rs.get('measure'))} {_f(rs.get('value_at_breach'))} $mm at the breach."
                if bs is not None else f"Status: {_e(rs.get('status'))}: no breach found up to the largest scale searched.")
        ob = rs.get("other_breaches") or []
        rev = (f"<p>{dist}</p>" + svg_path(rs.get("path"), lim, bs)
               + ("<table class='compact'><tr><th>Limit breached at the breach scale</th><th class='n'>Value $mm</th><th class='n'>Limit $mm</th><th class='n'>Utilisation</th></tr>" + "".join(
                   f"<tr><td>{_e(' '.join(dict.fromkeys(str(x) for x in (o.get('scope'), o.get('name'), o.get('measure')) if x)))}</td><td class='n'>{_f(o.get('value'))}</td><td class='n'>{_f(o.get('limit'))}</td><td class='n'>{_pct(o.get('utilisation'), 0)}</td></tr>" for o in ob) + "</table>" if ob else "")
               + ("<p class='note'>Shocks at the breach: " + "; ".join(_e(x) for x in rs.get("shocks_at_breach") or []) + ".</p>" if rs.get("shocks_at_breach") else "")
               + f"<p class='note'>Source: outputs/reverse_stress.json ({_e(rs.get('paths') or (ctx['reverse'] or {}).get('paths'))} paths per run, base {_f((ctx['reverse'] or {}).get('base'))} $mm; its own base run).</p>")
    else:
        rev = "<p class='empty'>No reverse-stress result for this scenario (outputs/reverse_stress.json: run `econquest reverse-stress`).</p>"
    # hedges
    hd = _hedges(base, sr, [r["country"] for r in crs], ctx["playbook"])
    if hd:
        hedges = ("<table class='compact'><tr><th>Trade</th><th>Strategy</th><th>Stance</th><th>Expression</th><th>Countries (stressed strength)</th><th>Risks</th></tr>" + "".join(
            f"<tr><td>{_e(h['trade'])}</td><td>{_e(h['strategy'])}</td><td>{_e(h['stance'])}</td><td>{_e(h['expression'])}</td>"
            f"<td>{_e(', '.join(f'{c} ({v:.0f})' + (' NEW' if c in h['new_under_stress'] else '') for c, v in h['countries']))}</td><td>{_e(h['risks'])}</td></tr>" for h in hd) + "</table>"
            "<p class='note'>Playbook trades (data/playbook.csv) with a Risk-off, Hedge, Event or Relative value stance that are active in the stressed run for the top-contributing countries; NEW = not active in the base run.</p>")
    else:
        hedges = "<p class='empty'>No hedging trade from the playbook activates under this scenario for the top-contributing countries (or no stress run archived).</p>"
    hedges = "<p class='note'>Decision support, not instructions: no position is opened on a signal alone (use restriction 6.5); sizing and execution are the desk's.</p>" + hedges
    cav = ctx["caveats"]
    sections = (("narrative", "Narrative and channels", narr), ("book", "Book impact", book), ("contributors", "Where the loss comes from", contrib),
                ("reverse", "Reverse-stress distance", rev), ("hedges", "Candidate hedges (playbook)", hedges),
                ("caveats", "Input caveats", caveats_html({"items": cav.get("items"), "source": cav.get("source")})),
                ("sources", "Sources", sources_html(ctx["sources"], heading=False) if ctx.get("sources") else "<p class='empty'>Sources not collected.</p>"))
    toc = " | ".join(f"<a href='#{k}'>{_e(t)}</a>" for k, t, _ in sections)
    body = "".join(f"<section id='{k}'><h2>{_e(t)}</h2>{h}</section>" for k, t, h in sections)
    # run_hash is code + data + as-of (+ vintage): a stress run made with the base run shares it, so it is shown only when it differs
    extra_stamp = ((("Stress run", sst.get("run_id")),) if sst.get("run_id") else ()) + ((("Stress run hash", sst.get("run_hash")),) if sst.get("run_hash") and sst.get("run_hash") != st.get("run_hash") else ())
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{_e(title)} {_e(st.get('as_of') or '')}</title>
<style>{NOTE_CSS}</style></head><body>
<h1>{_e(name)}</h1>
<div class="sub">Scenario brief ({_e(key)}). Base run {_e(st.get('run_id'))}, as of {_e(st.get('as_of') or 'not recorded')}.</div>
<div class="meta">{stamp_html(st, extra_stamp)}</div>
<div class="disclaimer" role="note"><b>Disclaimer.</b> {_e(DISCLAIMER)}</div>
<p class="toc">{toc}</p>
{body}
<p class="note">Brief generated {_e(ctx['generated'])} UTC (generation timestamp, not a model date).</p>
<div class="disclaimer" role="note"><b>Disclaimer.</b> {_e(DISCLAIMER)}</div>
</body></html>"""


def build_scenario_briefs(outputs_dir: str | Path, data_dir: str | Path, out_dir: str | Path, scenarios: list[str] | None = None, pdf: bool = False,
                          run: dict | None = None, chrome: str | None = None, pdf_workers: int | None = None, log=print) -> dict:
    """Write one brief per scenario to `out_dir` (default: every scenario with results in stress.json or
    scenario_library.csv; named `scenarios` are written even without results, saying so), plus index.html and
    scenario-briefs.json. Returns result_bundle() ("paths", "items", stamps). Raises FileNotFoundError without a base
    run, ValueError for a key that is neither in scenarios.json nor in the results."""
    t0 = time.perf_counter()
    outputs_dir, data_dir, out_dir = Path(outputs_dir), Path(data_dir), Path(out_dir)
    if run is None:
        run = load_latest(outputs_dir)
        if run is None:
            raise FileNotFoundError(f"no archived run in {outputs_dir / 'store'} and no {outputs_dir / 'run_latest.json'}: run `econquest run --stress` first")
    if hasattr(run, "to_dict"):
        run = run.to_dict()
    from ..engine.stress import load_scenarios
    lib = load_scenarios(data_dir / "scenarios.json") if (data_dir / "scenarios.json").exists() else {}
    stress = _read_json(outputs_dir / "stress.json") or {}
    library = _read(outputs_dir / "scenario_library.csv")
    with_results = list(stress) + [k for k in (library["scenario"].astype(str) if library is not None and "scenario" in library.columns else []) if k not in stress]
    if scenarios:
        known = {k.upper(): k for k in list(lib) + with_results}
        bad = [k for k in scenarios if k.upper() not in known]
        if bad:
            raise ValueError(f"unknown scenario: {', '.join(bad)} (known: {', '.join(known.values())})")
        keys = [known[k.upper()] for k in scenarios]
    else:
        keys = with_results
    stress_runs, stress_note = load_stress_runs(outputs_dir, run)
    pb = _read(data_dir / "playbook.csv")
    ctx = {"stamps": run_stamps(run), "stress": stress, "library": library, "reverse": _read_json(outputs_dir / "reverse_stress.json"),
           "playbook": None if pb is None or "id" not in pb.columns else pb.set_index("id"), "caveats": input_caveats(data_dir, run),
           "stress_note": stress_note, "sources": product_sources(data_dir, run), "generated": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M")}
    st = ctx["stamps"]
    out_dir.mkdir(parents=True, exist_ok=True)
    tag = st.get("as_of") or (st.get("created_at") or "")[:10] or "undated"
    items, htmls = [], []
    for k in keys:
        sc = lib.get(k); sr = stress_runs.get(k)
        p = out_dir / f"scenario-brief-{slug(k)}-{tag}.html"
        p.write_text(render_brief(k, sc, run, sr, ctx), encoding="utf-8")
        htmls.append(p)
        sst = run_stamps(sr) if sr else {}
        items.append({"kind": "scenario_brief", "scenario": k, "title": f"Scenario brief: {sc.name if sc else (stress.get(k) or {}).get('name', k)}", "html": str(p),
                      "pdf": None, "pdf_status": "not requested", **{x: st.get(x) for x in ("run_id", "as_of", "data_hash", "code_hash", "run_hash", "code_version")},
                      "stress_run_id": sst.get("run_id"), "stress_run_hash": sst.get("run_hash"), "has_results": k in with_results, "generated": ctx["generated"]})
    if pdf:
        for it, (pp, status) in zip(items, render_pdfs(htmls, chrome=chrome, workers=pdf_workers or default_pdf_workers())):
            it["pdf"], it["pdf_status"] = pp, status
    index = out_dir / "index-briefs.html"
    index.write_text(_index_html("EconQuest scenario briefs", items, st, ctx["sources"], ctx["caveats"]), encoding="utf-8")
    manifest = out_dir / "scenario-briefs.json"
    res = result_bundle("scenario_briefs", items, st, out_dir, [index], manifest=str(manifest), elapsed_s=round(time.perf_counter() - t0, 2))
    manifest.write_text(json.dumps(res, indent=1), encoding="utf-8")
    log(f"[briefs] {len(items)} briefs in {res['elapsed_s']:.1f}s -> {out_dir}")
    return res
