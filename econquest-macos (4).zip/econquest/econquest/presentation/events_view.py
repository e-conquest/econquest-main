"""Event views (EQ-C-0037, EQ-C-0038): event heat by country and week from the Team A event feeds (UCDP, GDELT) for the
country notes, the weekly risk monitor and the GUI Events tab. Formatting only: counts, fatalities, Goldstein and tone
come from the feed files as Team A wrote them; the heat ratio is a descriptive comparison of the latest complete week
with the country's own trailing weeks, not a model input. When no feed file exists the views say "no event feed yet";
when the newest week is old they say the feed is stale.

Reader interface (assumed until Team A's adapters, EQ-A-0022 / EQ-A-0023, ship; see EVENT_SCHEMA):

    data/live/events_weekly.csv            one combined file, or
    data/live/events_<source>.csv          one file per source (events_ucdp.csv, events_gdelt.csv), same columns;
    else the newest data/live/vintages/<YYYY-MM-DD>/ folder holding such files.

Columns (one row per country, week, source and optionally event type):
    iso3            ISO 3166-1 alpha-3 (as data/countries.csv `iso`); `country` (name) is used when iso3 is blank
    country         country name as in data/countries.csv
    week_start      Monday of the ISO week, YYYY-MM-DD (UTC). A daily file may give `date` instead: it is summed to weeks
    source          e.g. UCDP-GED, UCDP-Candidate, GDELT (defaults to the file-name part after events_)
    event_type      blank or "all" for the country-week total; any other value is a breakdown row (CAMEO root, UCDP
                    type_of_violence label). Without a total row the breakdown rows are summed
    event_count     number of events (integer)
    fatalities      best estimate of deaths (UCDP; blank for GDELT)
    goldstein_mean  mean Goldstein scale, -10..+10 (GDELT; blank for UCDP)
    tone_mean       mean article tone (GDELT; blank for UCDP)
    retrieved       ISO-8601 UTC time the rows were fetched
Optional Team B file outputs/event_stress.csv (EQ-B-0033): iso3 or country, week_start (optional), event_stress.

    from econquest.presentation.events_view import event_summary
    ev = event_summary("data", countries=[("Argentina", "ARG")], as_of="2026-10-20")
    # -> {"status": "ok" | "stale" | "missing" | "invalid", "message", "files", "sources": [...], "rows": [...], ...}
"""
from __future__ import annotations
import math
import re
from pathlib import Path

import numpy as np
import pandas as pd

from .report import _e, _f, md_text

EVENT_SCHEMA = ("iso3", "country", "week_start", "source", "event_type", "event_count", "fatalities", "goldstein_mean", "tone_mean", "retrieved")
REQUIRED = ("week_start", "source", "event_count")
BASELINE_WEEKS = 12          # trailing weeks the latest week is compared with
MIN_BASELINE_WEEKS = 4       # fewer trailing weeks: heat n/a
STALE_DAYS = 14              # latest complete week ended more than this many days before the reference date: stale
HOT, ELEVATED = 2.0, 1.25    # heat ratio labels (display only)
TOTAL_TYPES = {"", "all", "total", "nan", "none"}
NO_FEED = "No event feed yet: Team A's UCDP / GDELT adapters (EQ-A-0022, EQ-A-0023) have not written data/live/events_*.csv."


def find_event_files(data_dir: str | Path) -> list[Path]:
    """Event feed files: data/live/events_*.csv, else those of the newest data/live/vintages/<date>/ folder."""
    live = Path(data_dir) / "live"
    files = sorted(live.glob("events_*.csv")) if live.is_dir() else []
    if files:
        return files
    vint = live / "vintages"
    if vint.is_dir():
        for d in sorted((p for p in vint.iterdir() if p.is_dir() and re.fullmatch(r"\d{4}-\d{2}-\d{2}", p.name)), reverse=True):
            files = sorted(d.glob("events_*.csv"))
            if files:
                return files
    return []


def _num(s: pd.Series) -> pd.Series:
    return pd.to_numeric(s, errors="coerce")


def load_events(data_dir: str | Path) -> tuple[pd.DataFrame | None, list[str], list[str]]:
    """The feed files normalised to weekly rows with EVENT_SCHEMA columns. Returns (frame or None, files read, problems)."""
    frames, used, problems = [], [], []
    for f in find_event_files(data_dir):
        try:
            t = pd.read_csv(f, dtype=str, keep_default_na=False)
        except (pd.errors.EmptyDataError, pd.errors.ParserError, OSError, UnicodeDecodeError) as e:
            problems.append(f"{f.name}: unreadable ({type(e).__name__})"); continue
        t.columns = [str(c).strip().lower() for c in t.columns]
        if "week_start" not in t.columns and "date" in t.columns:
            d = pd.to_datetime(t["date"], errors="coerce")
            t["week_start"] = (d - pd.to_timedelta(d.dt.weekday, unit="D")).dt.strftime("%Y-%m-%d")
        if "source" not in t.columns or (t["source"] == "").all():
            t["source"] = f.stem[len("events_"):].upper() or "UNKNOWN"
        miss = [c for c in REQUIRED if c not in t.columns]
        if miss or not ({"iso3", "country"} & set(t.columns)):
            problems.append(f"{f.name}: missing column(s) {', '.join(miss or ['iso3 or country'])}"); continue
        for c in EVENT_SCHEMA:
            if c not in t.columns:
                t[c] = ""
        t = t[list(EVENT_SCHEMA)].copy()
        t["week_start"] = pd.to_datetime(t["week_start"], errors="coerce")
        bad = int(t["week_start"].isna().sum())
        if bad:
            problems.append(f"{f.name}: {bad} row(s) without a valid week_start/date dropped")
        t = t.dropna(subset=["week_start"])
        t["week_start"] = t["week_start"] - pd.to_timedelta(t["week_start"].dt.weekday, unit="D")   # align to Monday
        for c in ("event_count", "fatalities", "goldstein_mean", "tone_mean"):
            t[c] = _num(t[c])
        t["iso3"] = t["iso3"].str.strip().str.upper(); t["country"] = t["country"].str.strip()
        t["event_type"] = t["event_type"].str.strip()
        frames.append(t); used.append(str(f))
    if not frames:
        return None, used, problems
    df = pd.concat(frames, ignore_index=True)
    df["is_total"] = df["event_type"].str.lower().isin(TOTAL_TYPES)
    df["_w"] = df["event_count"].fillna(0)
    df["_gw"] = df["goldstein_mean"] * df["_w"]; df["_tw"] = df["tone_mean"] * df["_w"]
    df["_gn"] = df["_w"].where(df["goldstein_mean"].notna(), 0); df["_tn"] = df["_w"].where(df["tone_mean"].notna(), 0)
    keys = ["iso3", "country", "source", "event_type", "is_total", "week_start"]
    g = df.groupby(keys, dropna=False, as_index=False).agg(event_count=("event_count", lambda s: s.sum(min_count=1)), fatalities=("fatalities", lambda s: s.sum(min_count=1)),
                                                             _gw=("_gw", "sum"), _gn=("_gn", "sum"), _tw=("_tw", "sum"), _tn=("_tn", "sum"),
                                                             goldstein_any=("goldstein_mean", "mean"), tone_any=("tone_mean", "mean"), retrieved=("retrieved", "max"))
    # count-weighted mean when counts exist, else the plain mean (a daily file summed to a week)
    g["goldstein_mean"] = (g["_gw"] / g["_gn"]).where(g["_gn"] > 0, g["goldstein_any"])
    g["tone_mean"] = (g["_tw"] / g["_tn"]).where(g["_tn"] > 0, g["tone_any"])
    return g.drop(columns=["_gw", "_gn", "_tw", "_tn", "goldstein_any", "tone_any"]), used, problems


def _ts(v) -> pd.Timestamp | None:
    try:
        t = pd.Timestamp(str(v)[:10]) if v else None
    except (ValueError, TypeError):
        return None
    return None if t is None or pd.isna(t) else t


def _clean(v):
    if v is None:
        return None
    try:
        x = float(v)
    except (TypeError, ValueError):
        return v
    return x if math.isfinite(x) else None


def heat_label(ratio: float | None, events: float | None) -> str:
    if events is None:
        return "NO DATA"
    if ratio is None:
        return "NEW" if events and events > 0 else "n/a"
    return "HOT" if ratio >= HOT else "ELEVATED" if ratio >= ELEVATED else "NORMAL"


def _match(df: pd.DataFrame, countries: list[tuple[str, str | None]] | None) -> pd.DataFrame:
    """Map feed rows to the run's country names (iso3 first, then the name, case-insensitive). Without `countries` the
    feed's own names are kept."""
    df = df.copy()
    if not countries:
        df["name"] = df["country"].where(df["country"] != "", df["iso3"]); return df
    by_iso = {str(i).upper(): n for n, i in countries if i}
    by_name = {str(n).lower(): n for n, _ in countries}
    df["name"] = [by_iso.get(i) or by_name.get(str(c).lower()) for i, c in zip(df["iso3"], df["country"])]
    return df[df["name"].notna()]


def event_summary(data_dir: str | Path, countries: list[tuple[str, str | None]] | None = None, as_of: str | None = None,
                  outputs_dir: str | Path | None = None, stale_days: int = STALE_DAYS, baseline_weeks: int = BASELINE_WEEKS) -> dict:
    """Per country and source: the latest complete week's event count, the week before, week-on-week change, the trailing
    `baseline_weeks` mean, heat ratio and label, fatalities, Goldstein, tone, top event types, retrieved time and a stale
    flag. `countries` is [(name, iso3)] from the run (rows for every one of them, "NO DATA" when the feed has none);
    `as_of` (the run's model date) is the reference for completeness and staleness, else the newest retrieved date."""
    df, files, problems = load_events(data_dir)
    out = {"status": "missing", "message": NO_FEED, "files": files, "problems": problems, "sources": [], "rows": [], "as_of": as_of,
           "baseline_weeks": baseline_weeks, "stale_days": stale_days, "schema": list(EVENT_SCHEMA), "stress_source": None}
    if df is None or df.empty:
        if problems:
            out.update(status="invalid", message="Event feed present but unusable: " + "; ".join(problems))
        return out
    df = _match(df, countries)
    ref = _ts(as_of)
    if ref is None:
        rt = pd.to_datetime(df["retrieved"].replace("", None), errors="coerce", utc=True).dropna()
        ref = rt.max().tz_localize(None).normalize() if len(rt) else df["week_start"].max() + np.timedelta64(7, "D")
    stress = _event_stress(outputs_dir, countries)
    out["stress_source"] = stress[1] if stress else None
    rows, sources = [], []
    names = [n for n, _ in countries] if countries else sorted(df["name"].unique())
    for src, s in df.groupby("source"):
        done = s[s["week_start"] + np.timedelta64(7, "D") <= ref + np.timedelta64(1, "D")]
        partial = s["week_start"].max() > (done["week_start"].max() if len(done) else pd.Timestamp.min)
        weeks = sorted(done["week_start"].unique())
        if not weeks:
            sources.append({"source": src, "latest_week": None, "retrieved": s["retrieved"].max() or None, "stale": True,
                            "note": "no complete week on or before the reference date"}); continue
        cur, prev = weeks[-1], (weeks[-2] if len(weeks) > 1 else None)
        base_w = [w for w in weeks[:-1]][-baseline_weeks:]
        lag = (ref - (pd.Timestamp(cur) + np.timedelta64(7, "D"))).days
        retrieved = s["retrieved"].max() or None
        stale = lag > stale_days
        sources.append({"source": src, "latest_week": pd.Timestamp(cur).date().isoformat(), "retrieved": retrieved, "stale": stale, "lag_days": int(lag),
                        "partial_week_dropped": bool(partial), "countries": int(s["name"].nunique())})
        tot = s[s["is_total"]]; typ = s[~s["is_total"]]
        has_tot = set(zip(tot["name"], tot["week_start"]))
        typ_sum = typ[[(n, w) not in has_tot for n, w in zip(typ["name"], typ["week_start"])]]
        weekly = (pd.concat([x for x in (tot, typ_sum) if len(x)]) if len(typ_sum) else tot).groupby(["name", "week_start"]).agg(event_count=("event_count", lambda x: x.sum(min_count=1)),
                                                                               fatalities=("fatalities", lambda x: x.sum(min_count=1)),
                                                                               goldstein_mean=("goldstein_mean", "mean"), tone_mean=("tone_mean", "mean"),
                                                                               retrieved=("retrieved", "max"))
        covered = set(s["name"])
        for n in names:
            if n not in covered:
                rows.append({"country": n, "source": src, "week_start": pd.Timestamp(cur).date().isoformat(), "events": None, "coverage": "no rows for this country",
                             "heat_label": "NO DATA", "stale": stale, "retrieved": retrieved}); continue

            def at(w, col, n=n, weekly=weekly):
                if w is None or (n, w) not in weekly.index:
                    return 0.0 if col in ("event_count",) and w is not None else None
                return _clean(weekly.at[(n, w), col])
            ev, ev0 = at(cur, "event_count"), at(prev, "event_count")
            base = [at(w, "event_count") for w in base_w]
            base = [b for b in base if b is not None]
            bmean = sum(base) / len(base) if len(base) >= MIN_BASELINE_WEEKS else None
            ratio = (ev / bmean) if bmean and ev is not None else None
            tt = typ[(typ["name"] == n) & (typ["week_start"] == cur)].sort_values("event_count", ascending=False)
            rows.append({"country": n, "source": src, "week_start": pd.Timestamp(cur).date().isoformat(), "events": ev, "events_prev": ev0,
                         "wow_change": None if ev is None or ev0 is None else ev - ev0,
                         "wow_pct": None if ev is None or not ev0 else (ev / ev0 - 1) * 100,
                         "baseline_mean": bmean, "baseline_n": len(base), "heat_ratio": ratio, "heat_label": heat_label(ratio, ev),
                         "fatalities": at(cur, "fatalities"), "fatalities_prev": at(prev, "fatalities"),
                         "goldstein": at(cur, "goldstein_mean"), "tone": at(cur, "tone_mean"),
                         "top_types": [(str(r.event_type), _clean(r.event_count)) for r in tt.head(3).itertuples()],
                         "coverage": "ok", "stale": stale, "retrieved": at(cur, "retrieved") or retrieved,
                         "event_stress": (stress[0].get(n) if stress else None)})
    rows.sort(key=lambda r: (-(r.get("heat_ratio") or -1), r["country"], r["source"]))
    any_stale = any(s["stale"] for s in sources)
    out.update(rows=rows, sources=sources, status="stale" if any_stale else "ok",
               reference_date=ref.date().isoformat(),
               message=("Event feed STALE: " + "; ".join(f"{s['source']} latest complete week {s['latest_week'] or 'none'}" + (f" ({s['lag_days']} days before {ref.date()})" if s.get("lag_days") is not None else "")
                                                       for s in sources if s["stale"]) + f" (stale after {stale_days} days).")
               if any_stale else f"Event feed: {', '.join(s['source'] for s in sources)}.")
    if problems:
        out["message"] += " Problems: " + "; ".join(problems)
    return out


def _event_stress(outputs_dir, countries) -> tuple[dict, str] | None:
    """Team B's event stress index (EQ-B-0033), latest value per country, when outputs/event_stress.csv exists."""
    if outputs_dir is None:
        return None
    p = Path(outputs_dir) / "event_stress.csv"
    try:
        t = pd.read_csv(p, dtype=str, keep_default_na=False) if p.exists() else None
    except (pd.errors.EmptyDataError, pd.errors.ParserError, OSError):
        return None
    if t is None or "event_stress" not in t.columns or not ({"iso3", "country"} & set(t.columns)):
        return None
    for c in ("iso3", "country"):
        if c not in t.columns:
            t[c] = ""
    t["iso3"] = t["iso3"].str.upper()
    if "week_start" in t.columns:
        t = t.sort_values("week_start")
    m = _match(t, countries)
    m["event_stress"] = _num(m["event_stress"])
    return {n: _clean(v) for n, v in m.groupby("name")["event_stress"].last().items()}, "outputs/event_stress.csv (Team B, EQ-B-0033)"


# ---------------------------------------------------------------- formatting
def _n(v, d=0) -> str:
    return "" if v is None else _f(v, d)


def _signed(v, d=0, suffix="") -> str:
    return "" if v is None else f"{v:+,.{d}f}{suffix}"


def heat_tag(label: str) -> str:
    cls = {"HOT": "fire", "ELEVATED": "seed", "NORMAL": "ok"}.get(label, "")
    return f"<span class='tag {cls}'>{_e(label)}</span>"


def source_note(ev: dict) -> str:
    srcs = "; ".join(f"{s['source']}: latest complete week {s['latest_week'] or 'none'}, retrieved {s.get('retrieved') or 'not recorded'}"
                     + (" STALE" if s["stale"] else "") for s in ev.get("sources") or [])
    return (f"Source: {srcs or 'none'} ({'; '.join(Path(f).name for f in ev.get('files') or []) or 'no file'}). Heat = latest complete week's events against the mean of up to "
            f"{ev.get('baseline_weeks', BASELINE_WEEKS)} earlier weeks (HOT at {HOT:g}x or more, ELEVATED at {ELEVATED:g}x); descriptive only, not a scorecard input. "
            "GDELT counts follow media attention; UCDP counts fatal organised violence only. GDELT: cite the GDELT Project (gdeltproject.org); UCDP data CC BY 4.0.")


def _caveat(ev: dict) -> str:
    if ev["status"] in ("missing", "invalid"):
        return f"<p class='empty'><span class='tag stale'>NO FEED</span> {_e(ev['message'])}</p>"
    if ev["status"] == "stale":
        return f"<p><span class='tag stale'>STALE</span> {_e(ev['message'])}</p>"
    return ""


def country_events_html(ev: dict, country: str) -> str:
    """The events section of a country note."""
    if ev["status"] in ("missing", "invalid"):
        return _caveat(ev)
    rows = [r for r in ev["rows"] if r["country"] == country]
    if not rows:
        return _caveat(ev) + f"<p class='empty'>No event rows for {_e(country)} in the feed.</p><p class='note'>{_e(source_note(ev))}</p>"
    body = ""
    for r in rows:
        if r["events"] is None:
            body += f"<tr><td>{_e(r['source'])}</td><td colspan='8' class='empty'>{_e(r['coverage'])}</td></tr>"; continue
        types = ", ".join(f"{t} ({_n(c)})" for t, c in r.get("top_types") or [])
        body += (f"<tr><td>{_e(r['source'])}</td><td>{_e(r['week_start'])}</td><td class='n'><b>{_n(r['events'])}</b></td><td class='n'>{_signed(r['wow_change'])}"
                 f"{' (' + _signed(r['wow_pct'], 0, '%') + ')' if r.get('wow_pct') is not None else ''}</td><td class='n'>{_n(r['baseline_mean'], 1)}</td>"
                 f"<td class='n'>{_n(r['heat_ratio'], 2)}{'x' if r.get('heat_ratio') is not None else ''} {heat_tag(r['heat_label'])}</td><td class='n'>{_n(r['fatalities'])}</td>"
                 f"<td class='n'>{_n(r['goldstein'], 2)}{' / ' + _n(r['tone'], 2) if r.get('tone') is not None else ''}</td><td>{_e(types or 'n/a')}</td></tr>")
    es = next((r.get("event_stress") for r in rows if r.get("event_stress") is not None), None)
    return (_caveat(ev) + "<table class='compact'><tr><th>Source</th><th>Week of</th><th class='n'>Events</th><th class='n'>Week-on-week</th><th class='n'>Trailing mean</th>"
            f"<th class='n'>Heat</th><th class='n'>Fatalities</th><th class='n'>Goldstein / tone</th><th>Top event types</th></tr>{body}</table>"
            + (f"<p class='note'>Event stress index (Team B): {_f(es, 2)} ({_e(ev.get('stress_source'))}).</p>" if es is not None else "")
            + f"<p class='note'>{_e(source_note(ev))}</p>")


def monitor_events_html(ev: dict, top: int = 15) -> str:
    """The event-heat table of the weekly monitor: the hottest country-source rows, with the week-on-week change."""
    if ev["status"] in ("missing", "invalid"):
        return _caveat(ev)
    rows = [r for r in ev["rows"] if r.get("events") is not None][:top]
    if not rows:
        return _caveat(ev) + "<p class='empty'>The feed has no rows for the run's countries.</p>"
    body = "".join(f"<tr><td>{_e(r['country'])}</td><td>{_e(r['source'])}</td><td>{_e(r['week_start'])}</td><td class='n'>{_n(r['events'])}</td><td class='n'>{_n(r['events_prev'])}</td>"
                   f"<td class='n'>{_signed(r['wow_change'])}</td><td class='n'>{_n(r['heat_ratio'], 2)}</td><td>{heat_tag(r['heat_label'])}</td><td class='n'>{_n(r['fatalities'])}</td></tr>" for r in rows)
    return (_caveat(ev) + "<table><tr><th>Country</th><th>Source</th><th>Week of</th><th class='n'>Events</th><th class='n'>Week before</th><th class='n'>Change</th>"
            f"<th class='n'>Heat (x trailing mean)</th><th>Heat</th><th class='n'>Fatalities</th></tr>{body}</table><p class='note'>{_e(source_note(ev))}</p>")


def monitor_events_md(ev: dict, top: int = 15) -> list[str]:
    if ev["status"] in ("missing", "invalid"):
        return [f"NO FEED: {md_text(ev['message'])}"]
    L = ([f"STALE: {md_text(ev['message'])}", ""] if ev["status"] == "stale" else [])
    rows = [r for r in ev["rows"] if r.get("events") is not None][:top]
    if not rows:
        return L + ["The feed has no rows for the run's countries."]
    L += ["| Country | Source | Week of | Events | Week before | Change | Heat | Fatalities |", "|---|---|---|---:|---:|---:|---|---:|"]
    L += [f"| {md_text(r['country'])} | {md_text(r['source'])} | {md_text(r['week_start'])} | {_n(r['events'])} | {_n(r['events_prev'])} | {_signed(r['wow_change'])} | "
          f"{_n(r['heat_ratio'], 2)} {md_text(r['heat_label'])} | {_n(r['fatalities'])} |" for r in rows]
    return L + ["", md_text(source_note(ev))]


def index_heat(ev: dict) -> dict[str, tuple[float | None, str]]:
    """{country: (highest heat ratio across sources, its label)} for the notes index."""
    out: dict[str, tuple[float | None, str]] = {}
    for r in ev.get("rows") or []:
        cur = out.get(r["country"])
        if cur is None or (r.get("heat_ratio") or -1) > (cur[0] or -1):
            out[r["country"]] = (r.get("heat_ratio"), r["heat_label"])
    return out
