"""Weekly risk monitor (EQ-C-0009): one self-contained HTML page and a Markdown twin built from the latest run outputs
(the archived runs in outputs/store, else outputs/run_latest.json), compared with the run about a week earlier.

Sections: headline measures with the weekly change, top movers in sovereign risk, regimes, signal crossings and playbook
trade activations, event heat by country with the week-on-week change (events_view.py; "no event feed yet" or STALE
when the UCDP / GDELT feed is missing or old; EQ-C-0038), the Input caveats block and the standard disclaimer (report.DISCLAIMER). Every view is stamped with
run_id, as-of date, data_hash and code_hash. Formatting only: every number comes from the archived runs.

    from econquest.presentation.risk_monitor import build_monitor
    build_monitor("outputs", "data", "outputs/reports")   # -> {"html": ..., "md": ..., "latest": ...}
"""
from __future__ import annotations
import datetime as dt
import json
import math
from pathlib import Path
import pandas as pd

from ..validation.alerts import alert_settings, normalise_run, regime_alerts, signal_alerts, SEVERITY_RANK
from .events_view import NO_FEED, monitor_events_html, monitor_events_md
from .mc_band import BAND_MEASURES, band_text, book_limit_verdicts, limits_html, limits_md, load_book_limits
from .report import (CSS, DISCLAIMER, KPIS, _e, _f, _pct, caveats_html, caveats_md, input_caveats, latest_run, product_sources, run_as_of,
                     run_hash_of, sources_html, sources_md)

TOP_MOVERS = 10
MONITOR_KPIS = tuple(k for k in KPIS if k[0] in ("var99_mm", "es99_mm", "es975_frtb_mm", "lvar99_mm", "expected_loss_mm"))


def _model_date(run: dict) -> pd.Timestamp | None:
    """As-of date when the run has one, else its creation date (both are stamped on the run; neither is today)."""
    v = run_as_of(run) or (run.get("summary") or {}).get("created_at")
    try:
        return pd.Timestamp(str(v)[:10]) if v else None
    except (ValueError, TypeError):
        return None


def load_latest(outputs_dir: str | Path, label: str = "base") -> dict | None:
    """Newest archived run with the label from outputs/store, else outputs/run_latest.json. Never creates a store."""
    out = Path(outputs_dir)
    if (out / "store" / "econquest.sqlite").exists():
        from ..persistence import Store
        r = latest_run(Store(out / "store"), label)
        if r:
            return r
    p = out / "run_latest.json"
    return json.loads(p.read_text()) if p.exists() else None


def reference_run(outputs_dir: str | Path, current: dict, days: int = 7) -> tuple[dict | None, str]:
    """The archived run with the same label nearest to `days` before `current` (newest run at least `days` older; if
    none is that old, the oldest earlier run). Returns (run or None, note)."""
    out = Path(outputs_dir)
    if not (out / "store" / "econquest.sqlite").exists():
        return None, "No run archive (outputs/store): weekly changes cannot be computed."
    from ..persistence import Store
    store = Store(out / "store")
    cs = current.get("summary", current)
    rid, lab, created = cs.get("run_id"), cs.get("label", "base"), cs.get("created_at", "")
    d_cur = _model_date(current)
    earlier = [r for r in store.runs(limit=1000) if r["run_id"] != rid and r["label"] == lab and r["created_at"] < created]
    if not earlier:
        return None, f"No earlier archived '{lab}' run: weekly changes cannot be computed."

    def d_of(r):
        return _model_date({"summary": r["summary"]}) or pd.Timestamp(r["created_at"][:10])
    old_enough = [r for r in earlier if d_cur is None or (d_cur - d_of(r)).days >= days]
    pick = old_enough[0] if old_enough else earlier[-1]          # runs() is newest first
    try:
        ref = store.load(pick["run_id"])
    except FileNotFoundError:
        return None, f"Run {pick['run_id']} is listed but its archive file is missing."
    gap = (d_cur - d_of(pick)).days if d_cur is not None else None
    note = f"Compared with run {pick['run_id']} ({'as of ' + run_as_of(ref) if run_as_of(ref) else 'created ' + pick['created_at'][:10]}"
    note += f", {gap} days earlier)." if gap is not None else ")."
    if not old_enough:
        note += f" No archived run is {days} or more days older; this is the oldest earlier run."
    return ref, note


def _collect(run: dict, ref: dict | None, ref_note: str, data_dir: Path) -> dict:
    s = run.get("summary", {}); v = {**{k: x for k, x in ((run.get("provenance") or {}).get("versions") or {}).items() if k != "data_files"}, **(s.get("versions") or {})}
    cur, prev = normalise_run(run), normalise_run(ref)
    cfg = alert_settings(run.get("settings") if isinstance(run.get("settings"), dict) else None)
    movers = []
    for c, r in cur["country"].items():
        p1 = r.get("pd_default"); p0 = (prev["country"].get(c) or {}).get("pd_default") if ref else None
        mv = (float(p1) - float(p0)) * 100 if p1 is not None and p0 is not None and math.isfinite(float(p1)) and math.isfinite(float(p0)) else None
        c0 = (prev["country"].get(c) or {}).get("composite") if ref else None
        movers.append({"country": c, "pd_now": p1, "pd_prev": p0, "move_pp": mv, "regime_now": r.get("regime"),
                       "regime_prev": (prev["country"].get(c) or {}).get("regime") if ref else None, "composite_now": r.get("composite"),
                       "composite_move": (float(r["composite"]) - float(c0)) if r.get("composite") is not None and c0 is not None else None})
    if ref:
        movers.sort(key=lambda m: (-(abs(m["move_pp"]) if m["move_pp"] is not None else -1), m["country"]))
    else:
        movers.sort(key=lambda m: (-(m["pd_now"] or 0), m["country"]))
    regime_changes = regime_alerts(cur, prev) if ref else []
    sig = sorted(signal_alerts(cur, prev, cfg), key=lambda a: (SEVERITY_RANK.get(a["severity"], 9), a["scope"])) if ref else []
    names = {}
    pb = data_dir / "playbook.csv"
    if pb.exists():
        try:
            t = pd.read_csv(pb, dtype={"id": str})
            names = dict(zip(t["id"].astype(str), t["strategy"].astype(str))) if {"id", "strategy"} <= set(t.columns) else {}
        except (pd.errors.ParserError, pd.errors.EmptyDataError):
            names = {}
    active = []
    for trade, row in cur["activation"].items():
        on = sorted(((c, float(x)) for c, x in row.items() if x is not None and math.isfinite(float(x))), key=lambda t: -t[1])
        if on:
            active.append({"trade": trade, "strategy": names.get(trade, ""), "countries": on})
    counts_now = s.get("regimes") or {}
    counts_prev = (ref or {}).get("summary", {}).get("regimes") or {}
    return {"run": run, "summary": s, "metrics": s.get("metrics") or {}, "prev_metrics": prev["metrics"], "versions": v,
            "run_id": s.get("run_id"), "as_of": run_as_of(run), "run_hash": run_hash_of(run), "created": (s.get("created_at") or "")[:19],
            "ref_id": prev.get("run_id"), "ref_as_of": run_as_of(ref), "ref_note": ref_note,
            "movers": movers[:TOP_MOVERS], "regime_changes": regime_changes, "signal_changes": sig, "active": active,
            "global_regime": cur["global_regime"], "global_prev": prev["global_regime"] if ref else None,
            "regimes_now": counts_now, "regimes_prev": counts_prev, "cfg": cfg, "caveats": input_caveats(data_dir, run),
            "limits": book_limit_verdicts(s.get("metrics") or {}, load_book_limits(data_dir)),    # EQ-C-0055
            "generated": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M"),
            "date": run_as_of(run) or (s.get("created_at") or "undated")[:10]}


def _chg(a, b, pct=False) -> str:
    try:
        a, b = float(a), float(b)
    except (TypeError, ValueError):
        return ""
    if not (math.isfinite(a) and math.isfinite(b)):
        return ""
    if pct:
        return "" if a == 0 else f"{(b / a - 1) * 100:+.1f}%"
    return f"{b - a:+,.1f}"


def _stamp(ctx: dict) -> list[tuple[str, str]]:
    v = ctx["versions"]
    out = [("Run", ctx["run_id"]), ("As of", ctx["as_of"] or "not recorded"), ("Data hash", v.get("data_hash")), ("Code hash", v.get("code_hash")),
           ("Code version", v.get("code_version"))]
    if ctx.get("run_hash"):
        out.append(("Run hash", ctx["run_hash"]))
    out.append(("Compared with", ctx["ref_id"] or "none"))
    return out


def _events(ctx: dict) -> dict:
    return ctx.get("events") or {"status": "missing", "message": NO_FEED, "rows": [], "sources": [], "files": []}


def render_monitor_html(ctx: dict) -> str:
    m, pm = ctx["metrics"], ctx["prev_metrics"]
    meta = "".join(f"<span><b>{_e(k)}</b> {_e(val)}</span>" for k, val in _stamp(ctx))
    head = "".join(f"<tr><td>{lbl}</td><td class='n'>{_f(m.get(k))}</td><td class='n'>{band_text(m, k) if k in BAND_MEASURES else ''}</td><td class='n'>{_f(pm.get(k))}</td><td class='n'>{_chg(pm.get(k), m.get(k))}</td><td class='n'>{_chg(pm.get(k), m.get(k), pct=True)}</td></tr>" for k, lbl in MONITOR_KPIS)
    has_ref = bool(ctx["ref_id"])
    def mrow(r):
        mvp = "" if r["move_pp"] is None else f"{r['move_pp']:+.2f} pp"
        cmv = "" if r["composite_move"] is None else f"{r['composite_move']:+.1f}"
        return (f"<tr><td>{_e(r['country'])}</td><td class='n'><b>{_pct(r['pd_now'])}</b></td><td class='n'>{_pct(r['pd_prev'])}</td><td class='n'>{mvp}</td>"
                f"<td class='regime-{_e(r['regime_now'])}'>{_e(r['regime_now'])}</td><td>{_e(r['regime_prev'] or '')}</td>"
                f"<td class='n'>{_f(r['composite_now'])}</td><td class='n'>{cmv}</td></tr>")
    mv = "".join(mrow(r) for r in ctx["movers"])
    movers_title = "Top movers in 12-month default PD (largest absolute change)" if has_ref else "Highest 12-month default PD (no earlier run to compare)"

    def alerts_table(items, empty):
        if not items:
            return f"<p class='empty'>{_e(empty)}</p>"
        return "<table><tr><th>Severity</th><th>Scope</th><th>Change</th></tr>" + "".join(
            f"<tr><td><span class='sev {_e(a['severity'])}'>{_e(a['severity'])}</span></td><td>{_e(a['scope'])}</td><td>{_e(a['message'])}</td></tr>" for a in items) + "</table>"
    reg_counts = " ".join(f"{_e(k)} {_e(n)}" + (f" (was {_e(ctx['regimes_prev'].get(k, 0))})" if has_ref else "") + ";" for k, n in ctx["regimes_now"].items())
    glob = f"Global regime <b class='regime-{_e(ctx['global_regime'])}'>{_e(ctx['global_regime'])}</b>" + (f" (was {_e(ctx['global_prev'])})" if has_ref and ctx["global_prev"] else "")
    act = ("<table><tr><th>Trade</th><th>Strategy</th><th>Countries active (strength)</th></tr>" + "".join(
        f"<tr><td>{_e(a['trade'])}</td><td>{_e(a['strategy'])}</td><td>{_e(', '.join(f'{c} ({x:.0f})' for c, x in a['countries']))}</td></tr>" for a in ctx["active"]) + "</table>"
        if ctx["active"] else "<p class='empty'>No playbook trade active in this run.</p>")
    na = "n/a: no earlier run to compare."
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>EconQuest weekly risk monitor {_e(ctx['date'])}</title>
<style>{CSS}</style></head><body>
<h1>EconQuest weekly risk monitor</h1>
<div class="sub">Run {_e(ctx['run_id'])}, as of {_e(ctx['as_of'] or 'not recorded')}; run created {_e(ctx['created'])} UTC. {_e(ctx['ref_note'])}</div>
<div class="meta">{meta}</div>
<div class="disclaimer" role="note"><b>Disclaimer.</b> {_e(DISCLAIMER)}</div>
<h2>Headline ($mm)</h2>
<table><tr><th>Measure</th><th class="n">This run</th><th class="n">95% MC band</th><th class="n">Reference run</th><th class="n">Change $mm</th><th class="n">Change %</th></tr>{head}</table>
<h3>Book limits</h3>{limits_html(ctx.get('limits') or [], _e)}
<h2>{movers_title}</h2>
<table><tr><th>Country</th><th class="n">Default PD 12m</th><th class="n">Reference</th><th class="n">Change</th><th>Regime</th><th>Reference regime</th><th class="n">Composite</th><th class="n">Composite change</th></tr>{mv}</table>
<h2>Regimes</h2><p>{glob}. Countries by regime: {reg_counts}</p>
{alerts_table(ctx['regime_changes'], 'No country or global regime changed.' if has_ref else na)}
<h2>Signals and trade activations</h2>
<p class="note">Signals and trade activations are decision support, not instructions; no position is opened on a signal alone (use restriction 6.5). Threshold {ctx['cfg']['signal_threshold']:.0f}.</p>
<h3>Changes against the reference run</h3>{alerts_table(ctx['signal_changes'], f"No signal crossed {ctx['cfg']['signal_threshold']:.0f} and no trade changed state." if has_ref else na)}
<h3>Playbook trades active now</h3>{act}
<h2>Event heat (conflict and unrest feeds)</h2>{monitor_events_html(_events(ctx))}
<h2>Input caveats</h2>{caveats_html(ctx['caveats'])}
{sources_html(ctx['sources']) if ctx.get('sources') else ''}
<p class="note">Stamped: {_e(' | '.join(f'{k} {v}' for k, v in _stamp(ctx)))}. Monitor generated {_e(ctx['generated'])} UTC (generation timestamp, not a model date).</p>
<div class="disclaimer" role="note"><b>Disclaimer.</b> {_e(DISCLAIMER)}</div>
</body></html>"""


def render_monitor_md(ctx: dict) -> str:
    m, pm = ctx["metrics"], ctx["prev_metrics"]
    has_ref = bool(ctx["ref_id"])
    L = [f"# EconQuest weekly risk monitor {ctx['date']}", "", " | ".join(f"**{k}** {v}" for k, v in _stamp(ctx)), "", ctx["ref_note"], "",
         f"> **Disclaimer.** {DISCLAIMER}", "", "## Headline ($mm)", "", "| Measure | This run | 95% MC band | Reference | Change $mm | Change % |", "|---|---:|---:|---:|---:|---:|"]
    L += [f"| {lbl} | {_f(m.get(k))} | {band_text(m, k) if k in BAND_MEASURES else ''} | {_f(pm.get(k))} | {_chg(pm.get(k), m.get(k))} | {_chg(pm.get(k), m.get(k), pct=True)} |" for k, lbl in MONITOR_KPIS]
    L += ["", "### Book limits", ""] + limits_md(ctx.get("limits") or [])
    L += ["", "## " + ("Top movers in 12-month default PD" if has_ref else "Highest 12-month default PD (no earlier run)"), "",
          "| Country | Default PD | Reference | Change | Regime | Reference regime | Composite | Composite change |", "|---|---:|---:|---:|---|---|---:|---:|"]
    for r in ctx["movers"]:
        L.append(f"| {r['country']} | {_pct(r['pd_now'])} | {_pct(r['pd_prev'])} | {'' if r['move_pp'] is None else format(r['move_pp'], '+.2f') + ' pp'} | {r['regime_now']} | {r['regime_prev'] or ''} | "
                 f"{_f(r['composite_now'])} | {'' if r['composite_move'] is None else format(r['composite_move'], '+.1f')} |")
    L += ["", "## Regimes", "", f"Global regime {ctx['global_regime']}" + (f" (was {ctx['global_prev']})" if has_ref and ctx["global_prev"] else "") + ". "
          + "; ".join(f"{k} {n}" + (f" (was {ctx['regimes_prev'].get(k, 0)})" if has_ref else "") for k, n in ctx["regimes_now"].items()), ""]
    L += [f"- [{a['severity']}] {a['message']}" for a in ctx["regime_changes"]] or (["No country or global regime changed."] if has_ref else ["n/a: no earlier run."])
    L += ["", "## Signals and trade activations", "", "Decision support, not instructions (use restriction 6.5).", ""]
    L += [f"- [{a['severity']}] {a['message']}" for a in ctx["signal_changes"]] or (["No signal crossing or trade state change."] if has_ref else ["n/a: no earlier run."])
    L += ["", "Active now:", ""] + ([f"- {a['trade']} {a['strategy']}: " + ", ".join(f"{c} ({x:.0f})" for c, x in a["countries"]) for a in ctx["active"]] or ["- none"])
    L += ["", "## Event heat (conflict and unrest feeds)", ""] + monitor_events_md(_events(ctx))
    L += ["", "## Input caveats", ""] + caveats_md(ctx["caveats"])
    if ctx.get("sources"):
        L += [""] + sources_md(ctx["sources"])
    L += ["", f"Monitor generated {ctx['generated']} UTC (generation timestamp, not a model date).", "", f"> **Disclaimer.** {DISCLAIMER}"]
    return "\n".join(L) + "\n"


def build_monitor(outputs_dir: str | Path, data_dir: str | Path, out_dir: str | Path, run: dict | None = None, days: int = 7, log=print) -> dict:
    """Build the weekly risk monitor from the latest run in `outputs_dir` (or `run`, an archived run dict or RunResult).
    Writes <out_dir>/risk-monitor-<as_of>.html and .md plus <out_dir>/latest-monitor.html; returns their paths with
    run_id, as_of and the reference run id. Raises FileNotFoundError when there is no run to report."""
    outputs_dir, data_dir, out_dir = Path(outputs_dir), Path(data_dir), Path(out_dir)
    if run is None:
        run = load_latest(outputs_dir)
        if run is None:
            raise FileNotFoundError(f"no archived run in {outputs_dir / 'store'} and no {outputs_dir / 'run_latest.json'}: run `econquest run` first")
    if hasattr(run, "to_dict"):
        run = run.to_dict()
    ref, note = reference_run(outputs_dir, run, days=days)
    ctx = _collect(run, ref, note, data_dir)
    from .events_view import event_summary
    ctx["events"] = event_summary(data_dir, countries=[(r.get("country"), r.get("iso")) for r in run.get("country") or [] if r.get("country")],
                                  as_of=ctx["as_of"], outputs_dir=outputs_dir)
    ctx["sources"] = product_sources(data_dir, run, events=ctx["events"])
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = f"risk-monitor-{ctx['date']}"
    html_path, md_path, latest = out_dir / f"{stem}.html", out_dir / f"{stem}.md", out_dir / "latest-monitor.html"
    html_text = render_monitor_html(ctx)
    html_path.write_text(html_text, encoding="utf-8"); latest.write_text(html_text, encoding="utf-8")
    md_path.write_text(render_monitor_md(ctx), encoding="utf-8")
    log(f"[monitor] {html_path}; markdown {md_path}; latest {latest} (run {ctx['run_id']}, reference {ctx['ref_id'] or 'none'})")
    return {"html": str(html_path), "md": str(md_path), "latest": str(latest), "run_id": ctx["run_id"], "as_of": ctx["as_of"],
            "reference_run_id": ctx["ref_id"], "caveats": len(ctx["caveats"]["items"]), "events_status": ctx["events"]["status"]}
