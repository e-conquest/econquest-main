"""Self-contained HTML dashboard: heat table of posterior risk, loss distribution, arbitrage monitor."""
from __future__ import annotations
import html
import numpy as np

from .mc_band import BAND_MEASURES, band_text, book_limit_verdicts, headline_band, limits_html
from .report import DISCLAIMER, run_as_of


def _x(v) -> str:
    """HTML-escape any cell value (data CSVs are user-edited; the dashboard is served by the local API)."""
    return html.escape("" if v is None else str(v))


def _svg_hist(hist: dict, var99: float, es99: float, width=720, height=220) -> str:
    counts = np.array(hist["counts"], dtype=float); edges = np.array(hist["edges"])
    if counts.sum() == 0:
        return ""
    lo, hi = edges[0], edges[-1]; mx = counts.max()
    x = lambda v: 40 + (v - lo) / (hi - lo) * (width - 60)
    bars = "".join(f'<rect x="{x(edges[i]):.1f}" y="{height - 30 - counts[i] / mx * (height - 50):.1f}" width="{max(1, x(edges[i+1]) - x(edges[i]) - 0.5):.1f}" height="{counts[i] / mx * (height - 50):.1f}" fill="#4a7ab5" opacity="0.85"/>' for i in range(len(counts)))
    lines = f'<line x1="{x(var99):.1f}" x2="{x(var99):.1f}" y1="10" y2="{height-30}" stroke="#c0392b" stroke-dasharray="4 3"/><text x="{x(var99)+4:.1f}" y="22" font-size="11" fill="#c0392b">VaR99 {var99:.1f}</text>'
    lines += f'<line x1="{x(es99):.1f}" x2="{x(es99):.1f}" y1="10" y2="{height-30}" stroke="#8e44ad" stroke-dasharray="4 3"/><text x="{x(es99)+4:.1f}" y="36" font-size="11" fill="#8e44ad">ES99 {es99:.1f}</text>'
    axis = f'<line x1="40" x2="{width-20}" y1="{height-30}" y2="{height-30}" stroke="#888"/><text x="40" y="{height-12}" font-size="11" fill="#666">{lo:.0f}</text><text x="{width-60}" y="{height-12}" font-size="11" fill="#666">{hi:.0f} $mm loss</text>'
    return f'<svg viewBox="0 0 {width} {height}" width="100%" style="max-width:{width}px">{bars}{lines}{axis}</svg>'


def _heat(v: float, lo: float, hi: float) -> str:
    t = 0.0 if hi <= lo else min(1.0, max(0.0, (v - lo) / (hi - lo)))
    r = int(255 * t + 240 * (1 - t)); g = int(120 * t + 240 * (1 - t)); b = int(100 * t + 240 * (1 - t))
    return f"background:rgb({r},{g},{b})"


def render_dashboard(run: dict, stress: dict | None = None, backtest: dict | None = None, limits: dict | None = None) -> str:
    """`limits`: data/limits.json (mc_band.load_book_limits); when given, the book-limit verdicts are shown with the 95% Monte
    Carlo band and the within-MC-error flag (EQ-C-0055)."""
    s = run["summary"]; m = s["metrics"]
    rows = sorted(run["country"], key=lambda r: -r["pd_default"])
    def pct(v): return "" if v is None or (isinstance(v, float) and np.isnan(v)) else f"{v*100:.2f}%"
    tr = "".join(
        f"<tr><td>{_x(r['country'])}</td><td>{_x(r['rating'])}</td><td style='text-align:right'>{r['composite']:.1f}</td><td>{_x(r['regime'])}</td>"
        f"<td style='text-align:right;{_heat(r['pd_hazard_l1'],0,0.3)}'>{pct(r['pd_hazard_l1'])}</td><td style='text-align:right'>{pct(r['pd_rating'])}</td>"
        f"<td style='text-align:right'>{pct(r['pd_market'])}</td><td style='text-align:right'>{pct(r['pd_post'])}</td><td style='text-align:right'>{pct(r.get('pm_default'))}</td>"
        f"<td style='text-align:right;{_heat(r['pd_default'],0,0.4)}'><b>{pct(r['pd_default'])}</b></td><td style='text-align:right'>{pct(r['pd_tc'])}</td><td style='text-align:right'>{pct(r['pd_ex'])}</td>"
        f"<td style='text-align:right'>{pct(r['pd_pv'])}</td><td style='text-align:right'>{pct(r['pd_sa'])}</td><td style='text-align:right'>{r['DD']:.1f}</td></tr>" for r in rows)
    arb = sorted(run["arbitrage"], key=lambda a: -a["net_edge_pp"])
    ar = "".join(f"<tr><td>{_x(a['id'])}</td><td>{_x(a['platform'])}</td><td>{_x(a['country'])}</td><td>{_x(str(a['contract'])[:80])}</td><td style='text-align:right'>{a['yes_price']:.2f}</td>"
                 f"<td style='text-align:right'>{a['model_p_res']*100:.1f}%</td><td>{_x(a['side'])}</td><td style='text-align:right;{_heat(a['net_edge_pp'],0,40)}'>{a['net_edge_pp']:.1f}</td><td style='text-align:right'>{a['stake_k']:.0f}</td><td>{'FLAG' if a['divergence_flag'] else ''}</td></tr>" for a in arb)
    con = sorted(run["contributions"], key=lambda c: -c["tail_contribution_99_mm"])
    cr = "".join(f"<tr><td>{_x(c['id'])}</td><td>{_x(c['country'])}</td><td>{_x(c['asset_class'])}</td><td style='text-align:right'>{c['notional_mm']:.0f}</td><td style='text-align:right'>{c['expected_loss_mm']:.2f}</td>"
                 f"<td style='text-align:right'>{c['tail_contribution_99_mm']:.2f}</td><td style='text-align:right'>{c['share_of_es99']*100:.1f}%</td><td style='text-align:right'>{c['liquidity_cost_99_mm']:.2f}</td></tr>" for c in con)
    def mcb(k):                                         # EQ-C-0055: 95% Monte Carlo band under VaR99 / ES99 / L-VaR99
        b = band_text(m, k) if k in BAND_MEASURES else ""
        return f"<div class='d'>95% MC band {_x(b)}</div>" if b else ""
    kpi = "".join(f"<div class='kpi'><div class='v'>{m[k]:.1f}</div><div class='l'>{lbl}</div>{mcb(k)}</div>" for k, lbl in
                  (("var99_mm", "VaR 99% ($mm)"), ("es99_mm", "ES 99% ($mm)"), ("es975_frtb_mm", "ES 97.5% FRTB ($mm)"), ("lvar99_mm", "L-VaR 99% ($mm)"), ("les99_mm", "L-ES 99% ($mm)"), ("expected_loss_mm", "Expected loss ($mm)")))
    st = ""
    if stress:
        st = "<h2>Counterfactual stress scenarios (paper section 9)</h2><table><tr><th>Scenario</th><th>VaR99</th><th>ES99</th><th>ES99 change</th><th>L-VaR99</th><th>Liquidity cost change</th><th>Share moved to Crisis</th><th>Mean PD change (pp)</th></tr>"
        for k, v in stress.items():
            c = v["comparison"]
            st += f"<tr><td><b>{_x(k)}</b> {_x(v['name'])}</td><td style='text-align:right'>{c['var99_mm']['stress']:.1f}</td><td style='text-align:right'>{c['es99_mm']['stress']:.1f}</td><td style='text-align:right'>{c['es99_mm']['change_pct']:+.1f}%</td><td style='text-align:right'>{c['lvar99_mm']['stress']:.1f}</td><td style='text-align:right'>{c['liquidity_cost99_mm']['change_pct']:+.1f}%</td><td style='text-align:right'>{c['share_to_crisis']*100:.0f}%</td><td style='text-align:right'>{c['mean_pd_default_change_pp']:+.2f}</td></tr>"
        st += "</table>"
    bt = ""
    if backtest:
        k, c, z = backtest["kupiec"], backtest["christoffersen"], backtest["acerbi_szekely"]
        bt = f"<h2>Backtests (paper 7.3)</h2><table><tr><th>Test</th><th>Statistic</th><th>p-value / bound</th><th>Result</th></tr>" \
             f"<tr><td>Kupiec unconditional coverage</td><td>LR_uc {k['LR_uc']:.3f} ({k['exceedances']} exceedances vs {k['expected']:.1f} expected)</td><td>{k['p_value']:.3f}</td><td>{'pass' if k['p_value']>=0.05 else 'fail'}</td></tr>" \
             f"<tr><td>Christoffersen independence</td><td>LR_ind {c['LR_ind']:.3f}</td><td>{c['p_value_ind']:.3f}</td><td>{'pass' if c['p_value_ind']>=0.05 else 'fail'}</td></tr>" \
             f"<tr><td>Christoffersen conditional coverage</td><td>LR_cc {c['LR_cc']:.3f}</td><td>{c['p_value_cc']:.3f}</td><td>{'pass' if c['p_value_cc']>=0.05 else 'fail'}</td></tr>" \
             f"<tr><td>Acerbi-Szekely Z2</td><td>{z['Z2']:.3f}</td><td>critical {z['critical']}</td><td>{'pass' if z['pass'] else 'fail'}</td></tr>" \
             f"<tr><td>Basel zone</td><td colspan=2>{_x(backtest['basel_zone'])}</td><td>{_x(backtest['verdict'])}</td></tr></table>"
    dg = run["diagnostics"]
    as_of = run_as_of(run)
    return f"""<!doctype html><html><head><meta charset="utf-8"><title>EconQuest Risk Desk</title>
<style>body{{font-family:-apple-system,Segoe UI,Helvetica,Arial,sans-serif;margin:24px;color:#222;background:#fafafa}}h1{{margin-bottom:0}}.sub{{color:#666;margin-top:4px}}
.kpis{{display:flex;gap:12px;flex-wrap:wrap;margin:16px 0}}.kpi{{background:#fff;border:1px solid #ddd;border-radius:8px;padding:12px 16px;min-width:150px}}.kpi .v{{font-size:22px;font-weight:600}}.kpi .l{{font-size:12px;color:#666}}.kpi .d{{font-size:11px;color:#888}}
table{{border-collapse:collapse;background:#fff;font-size:13px;margin-bottom:24px}}th,td{{border:1px solid #e3e3e3;padding:4px 8px}}th{{background:#f0f0f0;text-align:left}}
.grid{{display:grid;grid-template-columns:1fr 1fr;gap:24px}}@media(max-width:1000px){{.grid{{grid-template-columns:1fr}}}}</style></head><body>
<h1>EconQuest Geopolitical Risk VaR</h1><div class="sub">Run {_x(s['run_id'])}, as of {_x(as_of or 'not recorded')}; run created {_x(s['created_at'][:19])} UTC. Data hash {_x((s.get('versions') or {}).get('data_hash', ''))}. {m['paths']:,} Sobol paths, Student-t copula with {dg['degrees_of_freedom']:.0f} degrees of freedom, global regime {_x(dg['global_regime'])}.</div>
<div class="kpis">{kpi}</div>
{'<h2>Book limits</h2>' + limits_html(book_limit_verdicts(m, limits), _x) if limits else ''}
<div class="grid"><div><h2>12-month loss distribution</h2>{_svg_hist(run['loss_histogram'], m['var99_mm'], m['es99_mm'])}
<p>Gross notional {m['gross_notional_mm']:.0f} $mm, net {m['net_notional_mm']:.0f} $mm. Liquidity cost at 99% {m['liquidity_cost99_mm']:.2f} $mm. Mean latent correlation {dg['mean_latent_correlation']:.2f}, lower tail dependence {dg['tail_dependence_at_mean_corr']:.3f}.</p></div>
<div>{bt}</div></div>
<h2>Posterior sovereign risk (Layers 1-4)</h2>
<table><tr><th>Country</th><th>Rating</th><th>Score</th><th>Regime</th><th>L1 hazard</th><th>Rating prior</th><th>Market PD</th><th>L2 posterior</th><th>Prediction mkt</th><th>Default PD 12m</th><th>T&amp;C</th><th>Exprop.</th><th>Pol. violence</th><th>Sanctions</th><th>Merton DD</th></tr>{tr}</table>
{st}
<h2>Arbitrage alpha monitor (Layer 2.1)</h2>
<table><tr><th>ID</th><th>Platform</th><th>Country</th><th>Contract</th><th>Yes price</th><th>Model to resolution</th><th>Side</th><th>Net edge (pp)</th><th>Stake ($k)</th><th></th></tr>{ar}</table>
<h2>Position contributions (Layer 6)</h2>
<table><tr><th>ID</th><th>Country</th><th>Asset</th><th>Notional</th><th>Expected loss</th><th>99% tail contribution</th><th>Share of ES99</th><th>Liquidity cost</th></tr>{cr}</table>
<p style="color:#666;font-size:12px">Illustrative snapshot data from the Geopolitical-Macro Risk Desk workbook; prediction-market prices are placeholders unless the run was made with --live-markets.</p>
<p style="color:#4d3800;background:#fdf6e3;border:1px solid #b9770e;padding:8px;font-size:12px"><b>Disclaimer.</b> {_x(DISCLAIMER)}</p>
</body></html>"""


def run_headline(summary: dict, limits: dict | None = None) -> str:
    """One terminal line that leads with the decision numbers, with units (EQ-C-0048): printed last by `econquest run`
    so the result is visible without scrolling through the JSON summary above it. VaR99, ES99 and L-VaR99 carry their
    95% Monte Carlo band when the run has one; with `limits` (data/limits.json) a book-limit verdict within MC error
    is named (EQ-C-0055)."""
    m = summary.get("metrics") or {}

    def mm(k):
        v = m.get(k)
        return f"{v:,.2f} $mm{headline_band(m, k)}" if isinstance(v, (int, float)) and np.isfinite(v) else "n/a"
    paths = m.get("paths")
    tail = f"; {paths:,} paths" if isinstance(paths, int) else ""
    near = [f"{r['label']} {r['status']} vs {r['mc_levels']}" for r in book_limit_verdicts(m, limits) if r["within_mc_error"]]
    return (f"Run {summary.get('run_id', 'n/a')} as of {summary.get('as_of') or 'not recorded'}: VaR99 {mm('var99_mm')}, "
            f"ES99 {mm('es99_mm')}, expected loss {mm('expected_loss_mm')}, L-VaR99 {mm('lvar99_mm')}; "
            f"global regime {summary.get('global_regime', 'n/a')}{tail}." + (f" Within MC error: {'; '.join(near)}." if near else ""))
