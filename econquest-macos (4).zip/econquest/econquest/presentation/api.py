"""JSON REST + SSE server on the standard library (FastAPI is used automatically when installed).

Endpoints
  GET  /                       dashboard page for the latest run
  GET  /api/runs               run history
  GET  /api/run/latest         full latest run (country table, positions, arbitrage, loss histogram)
  GET  /api/countries          posterior risk table
  GET  /api/portfolio          portfolio metrics and contributions
  GET  /api/arbitrage          arbitrage monitor
  GET  /api/series?metric=var99_mm[&country=Argentina]   time series across runs
  POST /api/workbench          {"analyst": {"Argentina": {"4": 5}}, "paths": 20000, "scenario": "Model"} -> rerun with
                               pillar adjustments (Interactive Pillar Adjustment Workbench) and publish to subscribers
  GET  /events                 Server-Sent Events: a summary on connect and after every workbench run
"""
from __future__ import annotations
import dataclasses
import hmac
import json
import queue
import secrets
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs
from ..config import Settings
from ..ingestion import load_universe, Universe
from ..engine import run_pipeline
from ..engine.pipeline import dumps
from ..persistence import Store
from .dashboard import render_dashboard
from .mc_band import load_book_limits


class Hub:
    def __init__(self):
        self.subs: list[queue.Queue] = []; self.lock = threading.Lock()

    def subscribe(self) -> queue.Queue:
        q = queue.Queue()
        with self.lock:
            self.subs.append(q)
        return q

    def publish(self, event: str, data: dict):
        with self.lock:
            for q in list(self.subs):
                q.put((event, data))


class App:
    def __init__(self, data_dir: str, store_dir: str):
        self.data_dir = data_dir; self.store = Store(store_dir); self.hub = Hub()
        self.token = secrets.token_urlsafe(32)   # per-process; a write request must echo it (see Handler._guard)
        self.settings = Settings.load(Path(data_dir) / "assumptions.json")
        self.universe: Universe = load_universe(data_dir)
        self.latest = self.store.latest("base") or self.store.latest()
        if self.latest is None:
            self.rerun({})

    def rerun(self, body: dict) -> dict:
        u = self.universe
        adj = u.adjustments.copy()
        for country, pillars in (body.get("analyst") or {}).items():
            for pillar, pts in pillars.items():
                mask = (adj["block"] == "Analyst adjustment") & (adj["pillar"].astype(int) == int(pillar))
                adj.loc[mask, country] = float(pts)
        # replace only the adjustments: every other Universe field (weo_raw, prices, ...) must reach the rerun unchanged
        u2 = dataclasses.replace(u, adjustments=adj)
        s = self.settings
        if body.get("scenario"):
            s = s.copy_with(); s.scenario_override = body["scenario"]
        res = run_pipeline(u2, s, label=body.get("label", "workbench" if body else "base"), paths=int(body.get("paths", 20000)) if body else None)
        self.store.save_run(res, keep_paths=False)
        self.latest = res.to_dict()
        self.hub.publish("run", self.latest["summary"])
        return self.latest


def sse_frame(event: str, data) -> bytes:
    """One Server-Sent Events frame. The payload must sit on a single `data:` line: `dumps` indents its JSON, and a
    multi-line payload would reach an EventSource client as just its first line. Raw newlines cannot occur inside a
    JSON string (they are escaped), so joining the lines keeps the document intact."""
    return f"event: {event}\ndata: {''.join(dumps(data).splitlines())}\n\n".encode()


LOCAL_HOSTS = ("127.0.0.1", "localhost", "[::1]")
TOKEN_HEADER = "X-EconQuest-Token"


def make_handler(app: App):
    class H(BaseHTTPRequestHandler):
        def _send(self, code: int, body: str, ctype="application/json"):
            # No Access-Control-Allow-Origin: other web pages must not read or drive this local server.
            data = body.encode()
            self.send_response(code); self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(data)))
            self.send_header("X-Content-Type-Options", "nosniff"); self.send_header("X-Frame-Options", "DENY")
            self.send_header("Cache-Control", "no-store"); self.end_headers(); self.wfile.write(data)

        def _guard(self, write: bool) -> bool:
            """Refuse requests that did not come from this app's own page. Every request must name a loopback Host
            (blocks DNS rebinding). A write must also carry a JSON content type (forces a CORS preflight, which this
            server never approves), a same-origin Origin when the browser sends one, and the per-process token that only
            the served page knows. Returns False after sending 403."""
            port = self.server.server_address[1]
            allowed = {f"{h}:{port}" for h in LOCAL_HOSTS}
            reason = None
            if self.headers.get("Host", "") not in allowed:
                reason = "host not allowed"
            elif write:
                origin = self.headers.get("Origin")
                if origin is not None and origin.removeprefix("http://") not in allowed:
                    reason = "cross-origin request refused"
                elif not self.headers.get("Content-Type", "").startswith("application/json"):
                    reason = "content type must be application/json"
                elif not hmac.compare_digest(self.headers.get(TOKEN_HEADER, ""), app.token):
                    reason = "missing or wrong session token"
            if reason:
                self._send(403, dumps({"error": reason}))
                return False
            return True

        def do_GET(self):
            if not self._guard(write=False):
                return
            p = urlparse(self.path); qs = parse_qs(p.query); L = app.latest
            if p.path == "/":
                return self._send(200, render_dashboard(L, limits=load_book_limits(app.data_dir)), "text/html; charset=utf-8")   # EQ-C-0055
            if p.path == "/api/runs":
                return self._send(200, dumps(app.store.runs()))
            if p.path == "/api/run/latest":
                return self._send(200, dumps(L))
            if p.path == "/api/countries":
                return self._send(200, dumps(L["country"]))
            if p.path == "/api/portfolio":
                return self._send(200, dumps({"metrics": L["summary"]["metrics"], "contributions": L["contributions"], "by_country": L["by_country"], "loss_quantiles": L["loss_quantiles"]}))
            if p.path == "/api/arbitrage":
                return self._send(200, dumps(L["arbitrage"]))
            if p.path == "/api/series":
                df = app.store.series(qs.get("metric", ["var99_mm"])[0], qs.get("country", [None])[0])
                return self._send(200, df.to_json(orient="records"))
            if p.path == "/events":
                self.send_response(200); self.send_header("Content-Type", "text/event-stream"); self.send_header("Cache-Control", "no-cache"); self.end_headers()
                q = app.hub.subscribe()
                self.wfile.write(sse_frame("run", L["summary"])); self.wfile.flush()
                try:
                    while True:
                        try:
                            ev, data = q.get(timeout=15)
                            self.wfile.write(sse_frame(ev, data))
                        except queue.Empty:
                            self.wfile.write(b": keepalive\n\n")
                        self.wfile.flush()
                except (BrokenPipeError, ConnectionResetError):
                    return
            self._send(404, dumps({"error": "not found"}))

        def do_POST(self):
            if not self._guard(write=True):
                return
            p = urlparse(self.path)
            n = int(self.headers.get("Content-Length", 0))
            try:
                body = json.loads(self.rfile.read(n) or b"{}")
            except ValueError:
                return self._send(400, dumps({"error": "body is not valid JSON"}))
            if not isinstance(body, dict):
                return self._send(400, dumps({"error": "body must be a JSON object"}))
            if p.path == "/api/workbench":
                res = app.rerun(body)
                return self._send(200, dumps(res["summary"]))
            self._send(404, dumps({"error": "not found"}))

        def log_message(self, *a):  # quiet
            pass
    return H


def serve(data_dir: str, store_dir: str, host: str = "127.0.0.1", port: int = 8080):
    app = App(data_dir, store_dir)
    try:
        import fastapi  # noqa: F401
        print("FastAPI is installed; the standard-library server is used here, swap in fastapi_app(app) for ASGI deployment.")
    except ImportError:
        pass
    srv = ThreadingHTTPServer((host, port), make_handler(app))
    print(f"EconQuest API on http://{host}:{port}  (dashboard at /, SSE at /events)")
    print(f"POST requests must send header {TOKEN_HEADER}: {app.token}")
    srv.serve_forever()
