"""Daily risk report (roadmap item 4.2): one self-contained HTML page (inline CSS, no external assets, prints to PDF
from any browser) and a Markdown twin, built from the latest archived run, the previous run, the forecast record
and the data-quality files. Written to outputs/reports/risk-report-<date>.html / .md and outputs/reports/latest.html."""
from __future__ import annotations
import datetime as dt
import html as _h
import json
import math
from pathlib import Path
import numpy as np
import pandas as pd

from ..validation.alerts import detect_alerts, alert_settings, backtest_status, load_data_issues, normalise_run
from .mc_band import BAND_MEASURES, band_text, book_limit_verdicts, limits_html, limits_md, load_book_limits

PERIL_COLS = (("pd_tc", "T&C"), ("pd_ex", "Exprop."), ("pd_pv", "Pol. viol."), ("pd_sa", "Sanctions"))
KPIS = (("var95_mm", "VaR 95%"), ("var99_mm", "VaR 99%"), ("es95_mm", "ES 95%"), ("es975_frtb_mm", "ES 97.5% (FRTB)"), ("es99_mm", "ES 99%"),
        ("lvar99_mm", "Liquidity-adjusted VaR 99%"), ("les99_mm", "Liquidity-adjusted ES 99%"), ("expected_loss_mm", "Expected loss"))


def _f(v, d=1, suffix="") -> str:
    try:
        x = float(v)
    except (TypeError, ValueError):
        return ""
    return "" if not math.isfinite(x) else f"{x:,.{d}f}{suffix}"


def _pct(v, d=2) -> str:
    try:
        x = float(v)
    except (TypeError, ValueError):
        return ""
    return "" if not math.isfinite(x) else f"{x*100:.{d}f}%"


def _e(v) -> str:
    return _h.escape("" if v is None else str(v))


def latest_run(store, label: str | None = "base") -> dict | None:
    """Newest archived run with the label (falls back to any label)."""
    for lab in ((label, None) if label else (None,)):
        try:
            r = store.latest(lab)
        except FileNotFoundError:
            r = None
        if r:
            return r
    return None


def previous_run(store, current: dict) -> dict | None:
    """The archived run before `current` with the same label (so stress runs are not compared with base runs)."""
    cs = current.get("summary", current)
    rid, lab, created = cs.get("run_id"), cs.get("label", "base"), cs.get("created_at", "")
    for r in store.runs(limit=200):
        if r["run_id"] != rid and (r["label"] == lab or lab is None) and r["created_at"] < created:
            try:
                return store.load(r["run_id"])
            except FileNotFoundError:
                continue
    return None


def stale_inputs(data_dir: Path, stale_days: int, today: dt.date | None = None) -> pd.DataFrame | None:
    """Live-feed cells in data/audit_trail.csv whose retrieval date is older than stale_days."""
    p = Path(data_dir) / "audit_trail.csv"
    if not p.exists():
        return None
    a = pd.read_csv(p)
    if "retrieved" not in a.columns:
        return None
    today = today or dt.date.today()
    live = a[a["origin"].astype(str).str.startswith("live")].copy() if "origin" in a.columns else a.copy()
    live["retrieved_dt"] = pd.to_datetime(live["retrieved"], errors="coerce")
    live["age_days"] = (pd.Timestamp(today) - live["retrieved_dt"]).dt.days
    stale = live[live["age_days"] > stale_days]
    return stale[["table", "key", "country", "source", "retrieved", "age_days"]] if len(stale) else stale.iloc[0:0][["table", "key", "country", "source", "retrieved", "age_days"]]


# ---------------------------------------------------------------- run dates and input caveats (EQ-C-0009, EQ-C-0011)
# One constant, shown on every report and monitor. Worded for internal use; change it here only (audience not yet decided).
DISCLAIMER = ("Internal research, not investment advice. These are model outputs for internal discussion only: the engine runs on "
              "paper-mode parameters and partly on seed, synthetic or placeholder inputs (see Input caveats), so no PD, VaR, ES or "
              "prediction-market figure is to be quoted outside the desk as a model output (use restriction 6.1, "
              "docs/governance/model-risk-policy.md). Nothing here is an offer, a recommendation or an instruction to trade.")
FORECAST_RECORD_MIN_ROWS = 250        # use restriction 6.4: Basel zone meaningful from 250 daily rows


def run_as_of(run) -> str | None:
    """The model as-of date stamped on a run (settings.as_of, else versions.as_of), or None for runs made before
    EQ-C-0011. Never falls back to today: a missing as-of date is shown as missing."""
    if run is None:
        return None
    if hasattr(run, "to_dict"):
        run = run.to_dict()
    if not isinstance(run, dict):
        return None
    s = run.get("summary", run)
    settings = run.get("settings") if isinstance(run.get("settings"), dict) else {}
    cands = [settings.get("as_of"), s.get("as_of"), (s.get("versions") or {}).get("as_of"), ((run.get("provenance") or {}).get("versions") or {}).get("as_of")]
    for v in cands:
        if v not in (None, ""):
            return str(v)[:10]
    return None


def run_hash_of(run) -> str | None:
    if run is None:
        return None
    if hasattr(run, "to_dict"):
        run = run.to_dict()
    s = run.get("summary", run)
    return (s.get("versions") or {}).get("run_hash") or ((run.get("provenance") or {}).get("versions") or {}).get("run_hash")


def _read_csv(p: Path, **kw) -> pd.DataFrame | None:
    try:
        return pd.read_csv(p, **kw) if p.exists() else None
    except (pd.errors.EmptyDataError, pd.errors.ParserError, OSError):
        return None


def _num(v) -> float:
    x = pd.to_numeric(v, errors="coerce")
    return float(x) if pd.notna(x) else float("nan")


def _same(a, b) -> bool:
    x, y = _num(a), _num(b)
    if math.isnan(x) and math.isnan(y):
        return True
    return bool(np.isclose(x, y, rtol=1e-6, atol=1e-9))


HAND_ENTERED_PROFILE = ("rating", "spread", "res3m", "textz", "commgap", "stress_depreciation", "default", "extarrears", "parallel", "exprop", "coup", "nopay", "bankcrisis")


def input_caveats(data_dir: str | Path, run=None) -> dict:
    """Which inputs of this run are seed estimates, synthetic or illustrative placeholders, from the data files that mark
    them: data/audit_trail.csv (origin per Inputs cell, checked against indicators.csv), else data/live/provenance.csv and
    review.csv; prediction_markets.csv (GOV-016), backtest_history.csv (GOV-028), forecast_record.csv, cds_quotes.csv and
    the run's layer1.mode. Returns {"items": [{"key", "restriction", "ref", "text"}], "by_country": [...], "by_indicator": [...],
    "source": str, "cells": {"live", "seed", "unverified", "total"}}. Formatting only: no model numbers are changed."""
    d = Path(data_dir)
    if run is not None and hasattr(run, "to_dict"):
        run = run.to_dict()
    run = run or {}
    items: list[dict] = []
    by_country: list[dict] = []; by_indicator: list[dict] = []; source = ""; cells = {"live": 0, "seed": 0, "unverified": 0, "total": 0}
    ind = _read_csv(d / "indicators.csv", dtype={"id": str})
    if ind is not None and "id" in ind.columns:
        meta = [c for c in ("id", "pillar", "indicator", "unit") if c in ind.columns]
        countries = [c for c in ind.columns if c not in meta]
        ind = ind.set_index("id")
        status = pd.DataFrame("seed", index=ind.index, columns=countries)
        audit = _read_csv(d / "audit_trail.csv", dtype={"key": str})
        if audit is not None and {"table", "key", "country", "origin"} <= set(audit.columns):
            source = "data/audit_trail.csv (origin per cell; cells whose value changed since it was built are 'unverified')"
            ai = audit[audit["table"].astype(str) == "Inputs"]
            seen = set()
            for _, r in ai.iterrows():
                k, c = str(r["key"]), str(r["country"])
                if k not in status.index or c not in status.columns:
                    continue
                seen.add((k, c))
                if not _same(r.get("value"), ind.at[k, c]):
                    status.at[k, c] = "unverified"
                elif str(r["origin"]).lower().startswith("live"):
                    status.at[k, c] = "live"
            for k in status.index:                                   # cells the audit trail does not know about
                for c in countries:
                    if (k, c) not in seen:
                        status.at[k, c] = "unverified"
        else:
            prov = _read_csv(d / "live" / "provenance.csv", dtype={"key": str})
            rev = _read_csv(d / "live" / "review.csv", dtype={"key": str})
            held = set()
            if rev is not None and {"key", "country", "status"} <= set(rev.columns):
                tab = rev["table"].astype(str) if "table" in rev.columns else pd.Series("Inputs", index=rev.index)
                rr = rev[(tab == "Inputs") & (rev["status"].astype(str).str.lower() == "hold")]
                held = set(zip(rr["key"].astype(str), rr["country"].astype(str)))
            if prov is not None and {"key", "country", "value"} <= set(prov.columns):
                source = "data/live/provenance.csv and review.csv (no audit trail: run `econquest audit`)"
                pi = prov[prov["table"].astype(str) == "Inputs"] if "table" in prov.columns else prov
                for _, r in pi.iterrows():
                    k, c = str(r["key"]), str(r["country"])
                    if k in status.index and c in status.columns and (k, c) not in held and _same(r["value"], ind.at[k, c]):
                        status.at[k, c] = "live"
            else:
                source = "data/indicators.csv only (no live pull recorded): every cell is a seed estimate"
        vals = status.to_numpy()
        cells = {"live": int((vals == "live").sum()), "seed": int((vals == "seed").sum()), "unverified": int((vals == "unverified").sum()), "total": int(vals.size)}
        for c in countries:
            col = status[c]
            by_country.append({"country": c, "seed": int((col == "seed").sum()), "unverified": int((col == "unverified").sum()),
                               "live": int((col == "live").sum()), "total": int(len(col))})
        by_country.sort(key=lambda r: (-(r["seed"] + r["unverified"]), r["country"]))
        for k in status.index:
            row = status.loc[k]
            not_live = [c for c in countries if row[c] != "live"]
            if not_live:
                by_indicator.append({"id": k, "indicator": str(ind.at[k, "indicator"]) if "indicator" in ind.columns else "",
                                     "n_not_live": len(not_live), "n_total": len(countries), "countries": not_live,
                                     "all": len(not_live) == len(countries)})
        if cells["total"]:
            nl = cells["seed"] + cells["unverified"]
            items.append({"key": "seed_inputs", "restriction": "6.1", "ref": "GOV-010, GOV-036",
                          "text": f"{nl:,} of {cells['total']:,} scorecard input cells ({nl / cells['total']:.0%}) are not live: {cells['seed']:,} seed estimates"
                                  + (f" and {cells['unverified']:,} whose origin is unverified (changed since the audit trail was built)" if cells["unverified"] else "")
                                  + f". {sum(1 for r in by_indicator if r['all'])} of {len(status.index)} indicators are on seed values for every country."})
    prof = _read_csv(d / "countries.csv")
    if prof is not None:
        hand = [c for c in HAND_ENTERED_PROFILE if c in prof.columns]
        if hand:
            items.append({"key": "hand_entered_profile", "restriction": "6.1", "ref": "GOV-036",
                          "text": "Country profile fields " + ", ".join(hand) + " are hand-entered for every country (no feed, outside the quality gate); spreads and ratings drive regimes and the market term of every PD."})
    rev = _read_csv(d / "live" / "review.csv")
    if rev is not None and "status" in rev.columns:
        st = rev["status"].astype(str).str.lower()
        if int((st == "hold").sum()):
            items.append({"key": "quality_holds", "restriction": "", "ref": "data/live/review.csv",
                          "text": f"{int((st == 'hold').sum())} live values held by the quality gate; the seed value is kept until a decision is recorded."})
        if int((st == "missing").sum()):
            items.append({"key": "feed_missing", "restriction": "", "ref": "GOV-010",
                          "text": f"{int((st == 'missing').sum())} cells had no live value on the last pull and stay on seed estimates."})
    l1mode = ((run.get("settings") or {}).get("layer1") or {}).get("mode") if isinstance(run.get("settings"), dict) else None
    if l1mode is None and (d / "assumptions.json").exists():
        try:
            l1mode = (json.loads((d / "assumptions.json").read_text()).get("layer1") or {}).get("mode")
        except (ValueError, OSError):
            l1mode = None
    if l1mode == "paper_standardized":
        items.append({"key": "paper_mode", "restriction": "6.1", "ref": "GOV-010",
                      "text": "Layer 1 runs in paper mode (layer1.mode = paper_standardized): the hazard coefficients are the paper's illustrations, not fitted. Quote internally only with the words \"paper-mode parameters, seed inputs\"."})
    pm = _read_csv(d / "prediction_markets.csv")
    markets_src = str((run.get("provenance") or {}).get("markets") or "csv:")
    if pm is not None and len(pm) and markets_src.startswith("csv:") and not ({"slug", "ticker"} & set(pm.columns)):
        cs = sorted(pm["country"].astype(str).unique()) if "country" in pm.columns else []
        items.append({"key": "pm_placeholders", "restriction": "6.2", "ref": "GOV-016",
                      "text": f"All {len(pm)} prediction-market prices are illustrative placeholders (no slug/ticker, run not made with --live-markets): "
                              f"pm_default, edges, stakes and divergence flags for {', '.join(cs)} are not live."})
    bh = _read_csv(d / "backtest_history.csv")
    if bh is not None and len(bh):
        real = "source" in bh.columns and not bh["source"].astype(str).str.contains("synthetic", case=False).any()
        if not real:
            items.append({"key": "synthetic_backtest", "restriction": "6.3", "ref": "GOV-028",
                          "text": f"The {len(bh)}-period data/backtest_history.csv is synthetic (drawn from the model): its Kupiec, Christoffersen, Acerbi-Szekely and Basel results are not evidence for or against the model."})
    rec = _read_csv(d / "forecast_record.csv")
    n_rec = 0 if rec is None else int(len(rec))
    if n_rec < FORECAST_RECORD_MIN_ROWS:
        items.append({"key": "record_underpowered", "restriction": "6.4", "ref": "GOV-029",
                      "text": f"Forecast record has {n_rec} rows (Basel zone meaningful from {FORECAST_RECORD_MIN_ROWS}): any backtest verdict on it is underpowered."})
    cds = _read_csv(d / "cds_quotes.csv")
    if cds is not None and len(cds) == 0:
        items.append({"key": "no_cds_quotes", "restriction": "6.7", "ref": "GOV-040",
                      "text": "data/cds_quotes.csv has no quotes: CDS-implied PDs and fair spreads are not produced; spreads in the PD are hand-entered."})
    return {"items": items, "by_country": by_country, "by_indicator": by_indicator, "source": source, "cells": cells}


def caveats_html(cav: dict, max_partial: int = 40) -> str:
    """The Input caveats block (HTML). Text markers ('SEED', '[restriction 6.x]') so colour is never the only signal."""
    if not cav or not cav.get("items"):
        return "<div class='caveats'><p class='empty'>No seed, synthetic or placeholder input found in the data files.</p></div>"
    li = "".join(f"<li><b>[{_e(('restriction ' + i['restriction']) if i['restriction'] else 'data')}]</b> {_e(i['text'])} <span class='note'>({_e(i['ref'])})</span></li>" for i in cav["items"])
    out = f"<div class='caveats' role='note' aria-label='Input caveats'><ul>{li}</ul>"
    bc = cav.get("by_country") or []
    if bc:
        out += ("<h3>Scorecard inputs by country (cells)</h3><table><tr><th>Country</th><th class='n'>Seed</th><th class='n'>Unverified</th><th class='n'>Live</th><th class='n'>Share not live</th></tr>"
                + "".join(f"<tr><td>{_e(r['country'])}</td><td class='n'>{r['seed']}</td><td class='n'>{r['unverified']}</td><td class='n'>{r['live']}</td>"
                          f"<td class='n'>{_pct((r['seed'] + r['unverified']) / r['total'] if r['total'] else 0, 0)}</td></tr>" for r in bc) + "</table>")
    bi = cav.get("by_indicator") or []
    if bi:
        full = [r for r in bi if r["all"]]; part = [r for r in bi if not r["all"]]
        if full:
            out += f"<p><b>SEED for every country</b> ({len(full)} indicators): " + "; ".join(f"{_e(r['id'])} {_e(r['indicator'])}" for r in full) + ".</p>"
        if part:
            out += ("<h3>Indicators partly live: countries on seed or unverified values</h3><table><tr><th>Indicator</th><th class='n'>Not live</th><th>Countries</th></tr>"
                    + "".join(f"<tr><td>{_e(r['id'])} {_e(r['indicator'])}</td><td class='n'>{r['n_not_live']} of {r['n_total']}</td><td>{_e(', '.join(r['countries']))}</td></tr>" for r in part[:max_partial])
                    + "</table>" + (f"<p class='note'>{len(part) - max_partial} more indicators in the Markdown report.</p>" if len(part) > max_partial else ""))
    if cav.get("source"):
        out += f"<p class='note'>Source: {_e(cav['source'])}.</p>"
    return out + "</div>"


def caveats_md(cav: dict) -> list[str]:
    if not cav or not cav.get("items"):
        return ["No seed, synthetic or placeholder input found in the data files."]
    L = [f"- **[{('restriction ' + i['restriction']) if i['restriction'] else 'data'}]** {i['text']} ({i['ref']})" for i in cav["items"]]
    bc = cav.get("by_country") or []
    if bc:
        L += ["", "| Country | Seed | Unverified | Live | Share not live |", "|---|---:|---:|---:|---:|"]
        L += [f"| {r['country']} | {r['seed']} | {r['unverified']} | {r['live']} | {_pct((r['seed'] + r['unverified']) / r['total'] if r['total'] else 0, 0)} |" for r in bc]
    bi = cav.get("by_indicator") or []
    full = [r for r in bi if r["all"]]; part = [r for r in bi if not r["all"]]
    if full:
        L += ["", f"SEED for every country ({len(full)} indicators): " + "; ".join(f"{r['id']} {r['indicator']}" for r in full) + "."]
    if part:
        L += ["", "| Indicator | Not live | Countries |", "|---|---:|---|"] + [f"| {r['id']} {r['indicator']} | {r['n_not_live']} of {r['n_total']} | {', '.join(r['countries'])} |" for r in part]
    if cav.get("source"):
        L += ["", f"Source: {cav['source']}."]
    return L


# ---------------------------------------------------------------- SVG helpers (no matplotlib)
def _svg_hist(hist: dict, var99: float, es99: float, width=720, height=200) -> str:
    counts = np.array(hist.get("counts", []), dtype=float); edges = np.array(hist.get("edges", []), dtype=float)
    if counts.size == 0 or counts.sum() == 0 or edges.size < 2:
        return ""
    lo, hi = edges[0], edges[-1]; mx = counts.max()
    x = lambda v: 40 + (v - lo) / (hi - lo) * (width - 60)
    bars = "".join(f'<rect x="{x(edges[i]):.1f}" y="{height - 30 - counts[i] / mx * (height - 50):.1f}" width="{max(1.0, x(edges[i+1]) - x(edges[i]) - 0.5):.1f}" '
                   f'height="{counts[i] / mx * (height - 50):.1f}" fill="#4a7ab5"/>' for i in range(len(counts)))
    marks = ""
    for v, col, lbl, yy in ((var99, "#c0392b", "VaR99", 22), (es99, "#8e44ad", "ES99", 36)):
        if v is not None and math.isfinite(float(v)):
            marks += f'<line x1="{x(v):.1f}" x2="{x(v):.1f}" y1="10" y2="{height-30}" stroke="{col}" stroke-dasharray="4 3"/><text x="{x(v)+4:.1f}" y="{yy}" font-size="11" fill="{col}">{lbl} {float(v):.1f}</text>'
    axis = f'<line x1="40" x2="{width-20}" y1="{height-30}" y2="{height-30}" stroke="#888"/><text x="40" y="{height-12}" font-size="11" fill="#666">{lo:.0f}</text><text x="{width-70}" y="{height-12}" font-size="11" fill="#666">{hi:.0f} $mm loss</text>'
    return f'<svg viewBox="0 0 {width} {height}" width="100%" style="max-width:{width}px" role="img" aria-label="12-month loss distribution">{bars}{marks}{axis}</svg>'


def _svg_bars(items: list[tuple[str, float]], width=720, row_h=22, unit="$mm") -> str:
    """Horizontal bar chart of (label, value) pairs."""
    items = [(l, float(v)) for l, v in items if v is not None and math.isfinite(float(v))]
    if not items:
        return ""
    mx = max(abs(v) for _, v in items) or 1.0
    height = row_h * len(items) + 10; x0 = 230; span = width - x0 - 70
    rows = ""
    for i, (lbl, v) in enumerate(items):
        y = 5 + i * row_h; w = abs(v) / mx * span
        rows += (f'<text x="{x0-8}" y="{y+row_h*0.68:.1f}" font-size="12" fill="#333" text-anchor="end">{_e(lbl[:38])}</text>'
                 f'<rect x="{x0}" y="{y+3}" width="{w:.1f}" height="{row_h-6}" fill="{"#c0392b" if v >= 0 else "#2e86c1"}" opacity="0.85"/>'
                 f'<text x="{x0 + w + 6:.1f}" y="{y+row_h*0.68:.1f}" font-size="12" fill="#333">{v:,.2f} {unit}</text>')
    return f'<svg viewBox="0 0 {width} {height}" width="100%" style="max-width:{width}px" role="img">{rows}</svg>'


# ---------------------------------------------------------------- content assembly
def _collect(run: dict, prev: dict | None, data_dir: Path, settings, alerts: list[dict] | None) -> dict:
    s = run["summary"]; m = s["metrics"]; cfg = alert_settings(settings)
    from ..validation.record import load_record
    rec_path = Path(data_dir) / "forecast_record.csv"
    record = load_record(rec_path) if rec_path.exists() else None
    review, feeds = load_data_issues(data_dir)
    if alerts is None:
        alerts = detect_alerts(run, prev, record, settings, review=review, feeds=feeds)
    bt = backtest_status(record)
    created = pd.Timestamp(s.get("created_at") or dt.datetime.now(dt.timezone.utc))
    country = sorted(run.get("country") or [], key=lambda r: -(r.get("pd_default") or 0))
    contrib = sorted(run.get("contributions") or [], key=lambda c: -(c.get("tail_contribution_99_mm") or 0))
    pos_by_id = {p["id"]: p for p in run.get("positions") or []}
    positions = []
    for c in contrib:
        p = pos_by_id.get(c["id"], {})
        positions.append({**c, "direction": p.get("direction", ""), "regime": p.get("regime", ""), "pd_default": p.get("pd_default"), "duration_yrs": p.get("duration_yrs")})
    prev_norm = normalise_run(prev); cur_norm = normalise_run(run)
    regime_changes = [a for a in alerts if a["kind"] == "regime_flip"]
    signal_changes = [a for a in alerts if a["kind"] in ("signal_cross", "trade_activation")]
    held = review[review["status"].astype(str).str.lower() == "hold"] if review is not None and "status" in review.columns else None
    missing = review[review["status"].astype(str).str.lower() == "missing"] if review is not None and "status" in review.columns else None
    feed_status = (feeds or {}).get("feeds", {}) if isinstance(feeds, dict) else {}
    as_of = run_as_of(run)
    # staleness is judged at the model as-of date when the run has one, else at the run's creation date (never today)
    stale = stale_inputs(data_dir, int(cfg["stale_days"]), today=(pd.Timestamp(as_of).date() if as_of else created.date()))
    versions = s.get("versions") or {}
    prov_v = (run.get("provenance") or {}).get("versions") or {}
    versions = {**{k: v for k, v in prov_v.items() if k != "data_files"}, **versions}
    dg = run.get("diagnostics") or {}
    return {"run": run, "summary": s, "metrics": m, "created": created, "date": created.strftime("%Y-%m-%d"), "versions": versions, "diagnostics": dg,
            "country": country, "positions": positions, "top5": positions[:5], "alerts": alerts, "regime_changes": regime_changes, "signal_changes": signal_changes,
            "backtest": bt, "record_rows": 0 if record is None else int(len(record)), "held": held, "missing_n": 0 if missing is None else int(len(missing)),
            "feeds": feed_status, "feeds_retrieved": (feeds or {}).get("retrieved") if isinstance(feeds, dict) else None, "stale": stale,
            "prev_id": prev_norm.get("run_id"), "prev_created": prev_norm.get("created_at"), "prev_metrics": prev_norm.get("metrics") or {},
            "cfg": cfg, "run_id": cur_norm.get("run_id"), "loss_hist": run.get("loss_histogram") or {},
            "as_of": as_of, "run_hash": run_hash_of(run), "caveats": input_caveats(data_dir, run),
            "limits": book_limit_verdicts(m, load_book_limits(data_dir)),          # EQ-C-0055: verdicts with the MC band
            "generated": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M")}


CSS = """
body{font-family:-apple-system,Segoe UI,Helvetica,Arial,sans-serif;margin:28px auto;max-width:1100px;padding:0 16px;color:#222;background:#fff;font-size:13px;line-height:1.4}
h1{margin:0 0 4px;font-size:24px}h2{font-size:17px;margin:28px 0 8px;border-bottom:2px solid #e3e3e3;padding-bottom:4px}h3{font-size:14px;margin:16px 0 6px}
.sub{color:#666;margin-bottom:12px}.meta{display:flex;flex-wrap:wrap;gap:6px 18px;color:#555;font-size:12px;margin:8px 0 16px}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin:12px 0}
.kpi{border:1px solid #ddd;border-radius:8px;padding:10px 12px;background:#fafafa}.kpi .v{font-size:21px;font-weight:600}.kpi .l{font-size:11px;color:#666}.kpi .d{font-size:11px;color:#888}
table{border-collapse:collapse;width:100%;font-size:12px;margin:6px 0 14px;page-break-inside:auto}th,td{border:1px solid #e3e3e3;padding:4px 7px;vertical-align:top}
th{background:#f0f0f0;text-align:left}td.n,th.n{text-align:right;white-space:nowrap}tr{page-break-inside:avoid}
.sev{display:inline-block;padding:1px 7px;border-radius:10px;font-size:11px;font-weight:600;color:#fff}.critical{background:#c0392b}.warning{background:#e67e22}.info{background:#2e86c1}
.regime-Calm{color:#1e8449}.regime-Stressed{color:#b9770e;font-weight:600}.regime-Crisis{color:#c0392b;font-weight:700}
.pass{color:#1e8449;font-weight:600}.fail{color:#c0392b;font-weight:700}.zone-Green{color:#1e8449}.zone-Yellow{color:#b9770e}.zone-Red{color:#c0392b}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:20px}.note{color:#666;font-size:11px}.empty{color:#777;font-style:italic}
.disclaimer{border:1px solid #b9770e;background:#fdf6e3;color:#4d3800;padding:8px 12px;border-radius:6px;margin:10px 0;font-size:12px}
.caveats{border-left:4px solid #b9770e;padding:2px 0 2px 12px}.caveats li{margin:3px 0}
@media(max-width:900px){.grid{grid-template-columns:1fr}}
@media print{body{margin:0;max-width:none;font-size:11px}h2{page-break-after:avoid}.kpi{break-inside:avoid}a{color:inherit;text-decoration:none}}
"""


def render_report_html(ctx: dict) -> str:
    s, m, v = ctx["summary"], ctx["metrics"], ctx["versions"]
    pm = ctx["prev_metrics"]

    def delta(key):
        a, b = pm.get(key), m.get(key)
        if a is None or b is None or not math.isfinite(float(a)) or not math.isfinite(float(b)) or float(a) == 0:
            return ""
        return f"<div class='d'>prev {_f(a)} ({(float(b)/float(a)-1)*100:+.1f}%)</div>"
    def mcb(key):                                       # EQ-C-0055: 95% Monte Carlo band (engine VF-004)
        b = band_text(m, key) if key in BAND_MEASURES else ""
        return f"<div class='d'>95% MC band {b}</div>" if b else ""
    kpis = "".join(f"<div class='kpi'><div class='v'>{_f(m.get(k))}</div><div class='l'>{lbl} ($mm)</div>{mcb(k)}{delta(k)}</div>" for k, lbl in KPIS)
    kpis += f"<div class='kpi'><div class='v regime-{_e(s.get('global_regime'))}'>{_e(s.get('global_regime'))}</div><div class='l'>Global regime</div>" \
            f"<div class='d'>{', '.join(f'{k} {n}' for k, n in (s.get('regimes') or {}).items())}</div></div>"
    meta = "".join(f"<span><b>{_e(k)}</b> {_e(val)}</span>" for k, val in (("Run", s.get("run_id")), ("As of", ctx.get("as_of") or "not recorded"), ("Label", s.get("label")), ("Paths", f"{int(m.get('paths', 0)):,}"),
                   ("Code version", v.get("code_version")), ("Code hash", v.get("code_hash")), ("Data hash", v.get("data_hash")),
                   ("Python", v.get("python")), ("numpy", v.get("numpy")), ("pandas", v.get("pandas")), ("scipy", v.get("scipy")),
                   ("Previous run", ctx["prev_id"] or "none archived")) + ((("Run hash", ctx["run_hash"]),) if ctx.get("run_hash") else ()))
    cav = ctx.get("caveats") or {}
    # alerts
    al = ctx["alerts"]
    if al:
        alerts_html = "<table><tr><th>Severity</th><th>Kind</th><th>Scope</th><th>Message</th><th class='n'>Value</th><th class='n'>Threshold</th></tr>" + "".join(
            f"<tr><td><span class='sev {a['severity']}'>{a['severity']}</span></td><td>{_e(a['kind'])}</td><td>{_e(a['scope'])}</td><td>{_e(a['message'])}</td>"
            f"<td class='n'>{_e(a['value'] if not isinstance(a['value'], float) else round(a['value'], 4))}</td><td class='n'>{_e(a['threshold'] if not isinstance(a['threshold'], float) else round(a['threshold'], 4))}</td></tr>" for a in al) + "</table>"
    else:
        alerts_html = "<p class='empty'>No alerts: no regime flip, PD or VaR move, signal crossing, backtest failure or data issue against the previous run.</p>"
    counts = {k: sum(1 for a in al if a["severity"] == k) for k in ("critical", "warning", "info")}
    # country table
    ct = "".join(
        f"<tr><td>{_e(r['country'])}</td><td>{_e(r.get('rating'))}</td><td class='n'>{_f(r.get('composite'))}</td><td class='n'>{_e(r.get('grade'))}</td>"
        f"<td class='regime-{_e(r.get('regime'))}'>{_e(r.get('regime'))}</td><td class='n'><b>{_pct(r.get('pd_default'))}</b></td><td class='n'>{_pct(r.get('pd_market'))}</td>"
        + "".join(f"<td class='n'>{_pct(r.get(k))}</td>" for k, _ in PERIL_COLS) +
        f"<td class='n'>{_pct(r.get('pd_any'))}</td><td class='n'>{_f(r.get('DD'))}</td></tr>" for r in ctx["country"])
    # positions
    def prow(p):
        return (f"<tr><td>{_e(p['id'])}</td><td>{_e(p['country'])}</td><td>{_e(p['asset_class'])}</td><td>{_e(p.get('direction'))}</td><td class='n'>{_f(p.get('notional_mm'), 1)}</td>"
                f"<td class='regime-{_e(p.get('regime'))}'>{_e(p.get('regime'))}</td><td class='n'>{_pct(p.get('pd_default'))}</td><td class='n'>{_f(p.get('expected_loss_mm'), 2)}</td>"
                f"<td class='n'>{_f(p.get('tail_contribution_99_mm'), 2)}</td><td class='n'>{_pct(p.get('share_of_es99'), 1)}</td><td class='n'>{_f(p.get('liquidity_cost_99_mm'), 2)}</td></tr>")
    phead = "<tr><th>ID</th><th>Country</th><th>Asset</th><th>Side</th><th class='n'>Notional $mm</th><th>Regime</th><th class='n'>Default PD</th><th class='n'>Expected loss</th><th class='n'>99% tail contribution</th><th class='n'>Share of ES99</th><th class='n'>Liquidity cost 99%</th></tr>"
    top5 = "".join(prow(p) for p in ctx["top5"]); allpos = "".join(prow(p) for p in ctx["positions"])
    top5_chart = _svg_bars([(f"{p['id']} {p['country']} {p['asset_class']}", p.get("tail_contribution_99_mm")) for p in ctx["top5"]])
    # changes
    def change_rows(items, empty):
        if not items:
            return f"<p class='empty'>{empty}</p>"
        return "<table><tr><th>Severity</th><th>Scope</th><th>Change</th></tr>" + "".join(
            f"<tr><td><span class='sev {a['severity']}'>{a['severity']}</span></td><td>{_e(a['scope'])}</td><td>{_e(a['message'])}</td></tr>" for a in items) + "</table>"
    sig_empty = f"No signal crossed the {ctx['cfg']['signal_threshold']:.0f} threshold and no trade changed state."
    prev_note = f"Compared with run {_e(ctx['prev_id'])} ({_e((ctx['prev_created'] or '')[:19])} UTC)." if ctx["prev_id"] else "No previous archived run with the same label: changes cannot be computed."
    changes = f"<p class='note'>{prev_note}</p><h3>Regime changes</h3>{change_rows(ctx['regime_changes'], 'No country or global regime changed.' if ctx['prev_id'] else 'n/a')}" \
              f"<h3>Signal threshold crossings and playbook activation</h3>{change_rows(ctx['signal_changes'], sig_empty if ctx['prev_id'] else 'n/a')}"
    # backtest
    bt = ctx["backtest"]
    if bt:
        k, c, z = bt["kupiec"], bt["christoffersen"], bt["acerbi_szekely"]
        pf = lambda ok: f"<td class='{'pass' if ok else 'fail'}'>{'pass' if ok else 'FAIL'}</td>"
        bt_html = (f"<p class='note'>Forecast record: {ctx['record_rows']} rows, {bt['periods']} days with a one-day 99% forecast to test ({_e(bt.get('first_date'))} to {_e(bt.get('last_date'))}). "
                   f"The Basel zone is scaled from the 250-day table; it is meaningful from 250 days.</p>"
                   f"<table><tr><th>Test</th><th>Statistic</th><th class='n'>p-value / bound</th><th>Result</th></tr>"
                   f"<tr><td>Kupiec unconditional coverage</td><td>{k['exceedances']} exceedances vs {k['expected']:.1f} expected (LR_uc {k['LR_uc']:.3f})</td><td class='n'>{k['p_value']:.3f}</td>{pf(k['p_value'] >= 0.05)}</tr>"
                   f"<tr><td>Christoffersen independence</td><td>LR_ind {c['LR_ind']:.3f}</td><td class='n'>{c['p_value_ind']:.3f}</td>{pf(c['p_value_ind'] >= 0.05)}</tr>"
                   f"<tr><td>Christoffersen conditional coverage</td><td>LR_cc {c['LR_cc']:.3f}</td><td class='n'>{c['p_value_cc']:.3f}</td>{pf(c['p_value_cc'] >= 0.05)}</tr>"
                   f"<tr><td>Acerbi-Szekely Z2 (ES)</td><td>Z2 {z['Z2']:.3f}</td><td class='n'>critical {z['critical']}</td>{pf(z['pass'])}</tr>"
                   f"<tr><td>Basel traffic light</td><td class='zone-{bt['basel_zone']}'><b>{bt['basel_zone']}</b></td><td class='n'></td><td class='{'pass' if bt['verdict'] == 'Pass' else 'fail'}'>{bt['verdict']}</td></tr></table>")
    else:
        bt_html = f"<p class='empty'>Forecast record has {ctx['record_rows']} rows and fewer than 20 with a forecast to test; the backtests start at 20 rows (Basel zone meaningful from 250).</p>"
    # data issues
    held = ctx["held"]
    di = f"<h3>Feeds (last pull {_e(ctx['feeds_retrieved'] or 'unknown')})</h3>"
    if ctx["feeds"]:
        di += "<table><tr><th>Feed</th><th>Status</th></tr>" + "".join(f"<tr><td>{_e(k)}</td><td class='{'pass' if str(st).lower().startswith('ok') else 'fail'}'>{_e(st)}</td></tr>" for k, st in ctx["feeds"].items()) + "</table>"
    else:
        di += "<p class='empty'>No data/live/feeds.json: no live pull recorded.</p>"
    di += "<h3>Quality-gate holds</h3>"
    if held is not None and len(held):
        di += "<table><tr><th>Table</th><th>Key</th><th>Country</th><th class='n'>Seed</th><th class='n'>Live</th><th>Reason</th><th>Decision</th></tr>" + "".join(
            f"<tr><td>{_e(r.get('table'))}</td><td>{_e(r.get('key'))}</td><td>{_e(r.get('country'))}</td><td class='n'>{_e(r.get('seed'))}</td><td class='n'>{_e(r.get('live'))}</td><td>{_e(r.get('reason'))}</td><td>{_e('' if pd.isna(r.get('decision')) else r.get('decision'))}</td></tr>"
            for _, r in held.iterrows()) + "</table>"
    elif held is not None:
        di += "<p class='empty'>No cell held by the quality gate.</p>"
    else:
        di += "<p class='empty'>No data/live/review.csv.</p>"
    di += f"<h3>Missing feed values</h3><p>{ctx['missing_n']} input cells had no live value on the last pull and stay on seed estimates.</p>" if ctx["missing_n"] else ""
    st = ctx["stale"]
    di += f"<h3>Stale inputs (older than {ctx['cfg']['stale_days']:.0f} days)</h3>"
    if st is None:
        di += "<p class='empty'>No data/audit_trail.csv (run `econquest audit`).</p>"
    elif len(st) == 0:
        di += "<p class='empty'>No stale live input.</p>"
    else:
        di += f"<p>{len(st)} live cells are stale.</p><table><tr><th>Table</th><th>Key</th><th>Country</th><th>Source</th><th>Retrieved</th><th class='n'>Age (days)</th></tr>" + "".join(
            f"<tr><td>{_e(r['table'])}</td><td>{_e(r['key'])}</td><td>{_e(r['country'])}</td><td>{_e(str(r['source'])[:60])}</td><td>{_e(r['retrieved'])}</td><td class='n'>{int(r['age_days'])}</td></tr>" for _, r in st.head(40).iterrows()) + "</table>"
    dg = ctx["diagnostics"]
    vld = dg.get("validation") or []
    if vld:
        di += "<h3>Universe validation warnings</h3><ul>" + "".join(f"<li>{_e(x)}</li>" for x in vld) + "</ul>"
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>EconQuest risk report {ctx['date']}</title>
<style>{CSS}</style></head><body>
<h1>EconQuest daily risk report</h1>
<div class="sub">Run {_e(s.get('run_id'))}, as of {_e(ctx.get('as_of') or 'not recorded')}; run created {ctx['created'].strftime('%A %d %B %Y, %H:%M')} UTC. Sovereign tail-risk engine, 12-month horizon, {int(m.get('paths', 0)):,} {'Sobol' if dg.get('sobol', True) else 'pseudo-random'} paths, Student-t copula with {_f(dg.get('degrees_of_freedom'), 0)} degrees of freedom.</div>
<div class="meta">{meta}</div>
<div class="disclaimer" role="note"><b>Disclaimer.</b> {_e(DISCLAIMER)} <b>{len(cav.get('items') or [])} input caveats</b> are listed under Input caveats.</div>
<h2>Headline</h2>
<div class="kpis">{kpis}</div>
<h3>Book limits</h3>{limits_html(ctx.get('limits') or [], _e)}
<div class="grid"><div>{_svg_hist(ctx['loss_hist'], m.get('var99_mm'), m.get('es99_mm'))}
<p class="note">Gross notional {_f(m.get('gross_notional_mm'), 0)} $mm, net {_f(m.get('net_notional_mm'), 0)} $mm. Liquidity cost at 99% {_f(m.get('liquidity_cost99_mm'), 2)} $mm. ES99 is {_pct(m.get('es99_share_of_gross'), 1)} of gross notional; P(loss above 10% of gross) {_pct(m.get('p_loss_above_10pct_gross'), 1)}. Mean latent correlation {_f(dg.get('mean_latent_correlation'), 2)}, lower tail dependence {_f(dg.get('tail_dependence_at_mean_corr'), 3)}.</p></div>
<div><h3>Alerts: {counts['critical']} critical, {counts['warning']} warning, {counts['info']} info</h3><p class="note">Full list in the Alerts section at the end.</p>
<h3>Top five tail contributors (99% contribution, $mm)</h3>{top5_chart}</div></div>
<h2>Input caveats</h2>{caveats_html(cav)}
<h2>Changes since the previous run</h2>{changes}
<h2>Country risk</h2>
<table><tr><th>Country</th><th>Rating</th><th class="n">Composite</th><th class="n">Grade</th><th>Regime</th><th class="n">Default PD 12m</th><th class="n">Market PD</th>{''.join(f'<th class="n">{lbl}</th>' for _, lbl in PERIL_COLS)}<th class="n">Any peril</th><th class="n">Merton DD</th></tr>{ct}</table>
<h2>Positions</h2>
<h3>Top five contributors to the 99% tail</h3><table>{phead}{top5}</table>
<h3>All positions</h3><table>{phead}{allpos}</table>
<h2>Backtest status (forecast record)</h2>{bt_html}
<h2>Data issues</h2>{di}
<h2>Alerts</h2>{alerts_html}
{sources_html(ctx['sources']) if ctx.get('sources') else ''}
<p class="note">Thresholds (assumptions.json, alerts): default PD move {ctx['cfg']['pd_change_pp']:.1f} pp, PD level {ctx['cfg']['pd_level']*100:.0f}%, VaR99/ES99 change {ctx['cfg']['var_change_pct']:.0f}%, signal activation {ctx['cfg']['signal_threshold']:.0f}, stale after {ctx['cfg']['stale_days']:.0f} days. Generated by econquest {_e(v.get('code_version'))} (code {_e(v.get('code_hash'))}, data {_e(v.get('data_hash'))}). Report generated {_e(ctx.get('generated'))} UTC (generation timestamp, not a model date).</p>
<div class="disclaimer" role="note"><b>Disclaimer.</b> {_e(DISCLAIMER)}</div>
</body></html>"""


def render_report_md(ctx: dict) -> str:
    s, m, v = ctx["summary"], ctx["metrics"], ctx["versions"]
    L = [f"# EconQuest daily risk report {ctx['date']}", "",
         f"Run {s.get('run_id')} ({s.get('label')}), as of {ctx.get('as_of') or 'not recorded'}; run created {ctx['created'].strftime('%A %d %B %Y, %H:%M')} UTC. {int(m.get('paths', 0)):,} paths. "
         f"Code {v.get('code_version')} / {v.get('code_hash')}, data {v.get('data_hash')}. Previous run: {ctx['prev_id'] or 'none archived'}." + (f" Run hash {ctx['run_hash']}." if ctx.get("run_hash") else ""), "",
         f"> **Disclaimer.** {DISCLAIMER}", "",
         "## Headline", "", "| Measure | $mm | 95% MC band | Previous |", "|---|---:|---:|---:|"]
    for k, lbl in KPIS:
        L.append(f"| {lbl} | {_f(m.get(k))} | {band_text(m, k) if k in BAND_MEASURES else ''} | {_f(ctx['prev_metrics'].get(k))} |")
    L += [f"| Global regime | {s.get('global_regime')} | | {', '.join(f'{k} {n}' for k, n in (s.get('regimes') or {}).items())} |", ""]
    L += ["### Book limits", ""] + limits_md(ctx.get("limits") or []) + [""]
    al = ctx["alerts"]
    counts = {k: sum(1 for a in al if a["severity"] == k) for k in ("critical", "warning", "info")}
    L += [f"Alerts: {counts['critical']} critical, {counts['warning']} warning, {counts['info']} info.", "", "## Input caveats", ""] + caveats_md(ctx.get("caveats")) + ["", "## Changes since the previous run", ""]
    if ctx["regime_changes"] or ctx["signal_changes"]:
        L += [f"- [{a['severity']}] {a['message']}" for a in ctx["regime_changes"] + ctx["signal_changes"]]
    else:
        L.append("No regime change or signal crossing." if ctx["prev_id"] else "No previous archived run with the same label.")
    L += ["", "## Country risk", "", "| Country | Rating | Composite | Grade | Regime | Default PD | Market PD | " + " | ".join(lbl for _, lbl in PERIL_COLS) + " | Any peril | DD |",
          "|---|---|---:|---:|---|---:|---:|" + "---:|" * len(PERIL_COLS) + "---:|---:|"]
    for r in ctx["country"]:
        L.append(f"| {r['country']} | {r.get('rating')} | {_f(r.get('composite'))} | {r.get('grade')} | {r.get('regime')} | {_pct(r.get('pd_default'))} | {_pct(r.get('pd_market'))} | "
                 + " | ".join(_pct(r.get(k)) for k, _ in PERIL_COLS) + f" | {_pct(r.get('pd_any'))} | {_f(r.get('DD'))} |")
    L += ["", "## Positions", "", "| ID | Country | Asset | Side | Notional | Regime | Default PD | Expected loss | Tail contribution 99% | Share of ES99 | Liquidity cost |", "|---|---|---|---|---:|---|---:|---:|---:|---:|---:|"]
    for p in ctx["positions"]:
        L.append(f"| {p['id']} | {p['country']} | {p['asset_class']} | {p.get('direction')} | {_f(p.get('notional_mm'))} | {p.get('regime')} | {_pct(p.get('pd_default'))} | {_f(p.get('expected_loss_mm'), 2)} | "
                 f"{_f(p.get('tail_contribution_99_mm'), 2)} | {_pct(p.get('share_of_es99'), 1)} | {_f(p.get('liquidity_cost_99_mm'), 2)} |")
    L += ["", "Top five contributors: " + ", ".join(f"{p['id']} {p['country']} ({_f(p.get('tail_contribution_99_mm'), 2)} $mm)" for p in ctx["top5"]), "", "## Backtest status", ""]
    bt = ctx["backtest"]
    if bt:
        k, c, z = bt["kupiec"], bt["christoffersen"], bt["acerbi_szekely"]
        L += [f"{bt['periods']} days tested ({bt.get('first_date')} to {bt.get('last_date')}).", "", "| Test | Statistic | p-value / bound | Result |", "|---|---|---:|---|",
              f"| Kupiec | {k['exceedances']} exceedances vs {k['expected']:.1f} expected | {k['p_value']:.3f} | {'pass' if k['p_value'] >= 0.05 else 'FAIL'} |",
              f"| Christoffersen independence | LR_ind {c['LR_ind']:.3f} | {c['p_value_ind']:.3f} | {'pass' if c['p_value_ind'] >= 0.05 else 'FAIL'} |",
              f"| Christoffersen conditional coverage | LR_cc {c['LR_cc']:.3f} | {c['p_value_cc']:.3f} | {'pass' if c['p_value_cc'] >= 0.05 else 'FAIL'} |",
              f"| Acerbi-Szekely Z2 | {z['Z2']:.3f} | critical {z['critical']} | {'pass' if z['pass'] else 'FAIL'} |",
              f"| Basel zone | {bt['basel_zone']} | | {bt['verdict']} |"]
    else:
        L.append(f"Forecast record has {ctx['record_rows']} rows and fewer than 20 with a forecast to test.")
    L += ["", "## Data issues", ""]
    L += [f"- Feed {k}: {st}" for k, st in ctx["feeds"].items()] or ["- No live pull recorded."]
    held = ctx["held"]
    if held is not None and len(held):
        L += [f"- Quality gate held {r.get('table')} {r.get('key')} {r.get('country')}: {r.get('reason')}" for _, r in held.iterrows()]
    if ctx["missing_n"]:
        L.append(f"- {ctx['missing_n']} input cells had no live value and stay on seed estimates.")
    st = ctx["stale"]
    L.append(f"- Stale live inputs (older than {ctx['cfg']['stale_days']:.0f} days): {'no audit trail' if st is None else len(st)}")
    L += ["", "## Alerts", ""]
    L += [f"- [{a['severity']}] {a['kind']} {a['scope']}: {a['message']}" for a in al] or ["No alerts."]
    if ctx.get("sources"):
        L += [""] + sources_md(ctx["sources"])
    L += ["", f"Report generated {ctx.get('generated')} UTC (generation timestamp, not a model date).", "", f"> **Disclaimer.** {DISCLAIMER}"]
    return "\n".join(L) + "\n"


def build_report(data_dir: str | Path, out_dir: str | Path, run=None, alerts: list[dict] | None = None, paths: int | None = None, log=print) -> dict:
    """Build the daily risk report. `run` is an archived run dict, a RunResult, or None (latest archived base run, else a
    fresh pipeline run at the configured paths). `alerts` None means detect them against the previous archived run.
    Returns paths of the files written plus the alerts and backtest used."""
    from ..config import Settings
    from ..persistence import Store
    data_dir, out_dir = Path(data_dir), Path(out_dir)
    settings = Settings.load(data_dir / "assumptions.json", paths=paths)
    store = Store(out_dir / "store")
    fresh = False
    if run is None:
        run = latest_run(store)
        if run is None:
            from ..ingestion import load_universe
            from ..engine import run_pipeline
            log("[report] no archived run: running the pipeline")
            run = run_pipeline(load_universe(data_dir), settings, label="base", paths=paths, market_dir=data_dir); fresh = True   # HO-20261024-B-C-002
    if hasattr(run, "to_dict"):
        run = run.to_dict()
    prev = previous_run(store, run)
    ctx = _collect(run, prev, data_dir, settings, alerts)
    ctx["sources"] = product_sources(data_dir, run)
    rep_dir = out_dir / "reports"; rep_dir.mkdir(parents=True, exist_ok=True)
    html_path = rep_dir / f"risk-report-{ctx['date']}.html"; md_path = rep_dir / f"risk-report-{ctx['date']}.md"; latest = rep_dir / "latest.html"
    html_text = render_report_html(ctx)
    html_path.write_text(html_text, encoding="utf-8"); latest.write_text(html_text, encoding="utf-8")
    md_path.write_text(render_report_md(ctx), encoding="utf-8")
    log(f"[report] {html_path} ({len(ctx['alerts'])} alerts); markdown {md_path}; latest {latest}")
    return {"html": str(html_path), "md": str(md_path), "latest": str(latest), "date": ctx["date"], "run_id": ctx["run_id"], "as_of": ctx["as_of"], "previous_run_id": ctx["prev_id"],
            "fresh_run": fresh, "alerts": ctx["alerts"], "backtest": ctx["backtest"], "html_text": html_text}


# ---------------------------------------------------------------- Sources section and stamp (EQ-C-0036 checklist item 2, EQ-C-0037)
# First match wins (substring of the lower-cased provenance source), so the FX reference-rate labels come before the
# generic "bis" (HO-20261024-A-C-002, EQ-A-0040): feeds.XRU_SOURCE names "WS_XRU", feeds.EXR_SOURCE "ECB ... EXR".
# The Yahoo labels stay only so a historical vintage's provenance (before 2026-10-23) is still named; no desk feed uses it.
_FEED_LABELS = (("bis_xru", "BIS reference rates"), ("ws_xru", "BIS reference rates"), ("ecb_exr", "ECB reference rates"),
                ("ecb", "ECB reference rates"),
                ("weo", "IMF WEO"), ("imf", "IMF WEO"), ("world bank", "World Bank WDI"), ("wbgapi", "World Bank WDI"), ("bis", "BIS"),
                ("yahoo", "Yahoo Finance"), ("yfinance", "Yahoo Finance"),
                ("dsa", "econquest DSA (derived from the feeds above)"))
_FILE_SOURCES = (("indicators.csv", "Seed estimates in data/indicators.csv (scorecard cells without a live value)"),
                 ("countries.csv", "Hand-entered country profile data/countries.csv (ratings, spreads, flags)"),
                 ("prediction_markets.csv", "Prediction-market prices data/prediction_markets.csv (placeholders unless refreshed)"),
                 ("cds_quotes.csv", "CDS quotes data/cds_quotes.csv (hand-entered)"),
                 ("gpr_monthly.csv", "Geopolitical risk index data/gpr_monthly.csv (Caldara-Iacoviello GPR)"),
                 ("portfolio.csv", "Book positions data/portfolio.csv"),
                 ("adjustments.csv", "Analyst adjustments data/adjustments.csv"))


def product_sources(data_dir: str | Path, run=None, events: dict | None = None) -> dict:
    """{"as_of", "vintage", "sources": [names]} for a product's Sources section and econquest:sources stamp. Live feeds
    come from data/live/provenance.csv (cells per source), the vintage from the newest data/live/vintages/<date>/
    folder (else the newest retrieved date in provenance.csv); file-based inputs are listed when the file exists; the
    event feeds from `events` (events_view.event_summary) or the files present. Never invents a date."""
    d = Path(data_dir)
    srcs: list[str] = []
    prov = _read_csv(d / "live" / "provenance.csv")
    vintage = None
    if prov is not None and "source" in prov.columns:
        for raw, n in prov["source"].dropna().astype(str).value_counts().items():
            lbl = next((v for k, v in _FEED_LABELS if k in raw.lower()), None)
            srcs.append(f"{lbl + ' (' + raw + ')' if lbl else raw}: {int(n)} input cells")
        if "retrieved" in prov.columns:
            r = prov["retrieved"].dropna().astype(str).str[:10]
            r = r[r.str.fullmatch(r"\d{4}-\d{2}-\d{2}")]
            vintage = r.max() if len(r) else None
    vdir = d / "live" / "vintages"
    if vdir.is_dir():
        names = sorted(p.name for p in vdir.iterdir() if p.is_dir() and len(p.name) == 10 and p.name[4] == "-" and p.name[7] == "-")
        vintage = names[-1] if names else vintage
    if not srcs:
        srcs.append("No live feed pull recorded (data/live/provenance.csv missing): every scorecard input is a seed estimate")
    srcs += [lbl for f, lbl in _FILE_SOURCES if (d / f).exists()]
    if events is None:
        from .events_view import find_event_files
        files = find_event_files(d)
        srcs.append(("Event feeds (UCDP / GDELT): " + ", ".join(p.name for p in files)) if files else "Event feeds (UCDP / GDELT): no event feed yet")
    elif events.get("status") in ("ok", "stale"):
        srcs += [f"Event feed {s['source']}: latest complete week {s.get('latest_week') or 'none'}, retrieved {s.get('retrieved') or 'not recorded'}"
                 + (" (STALE)" if s.get("stale") else "") for s in events.get("sources") or []]
    else:
        srcs.append("Event feeds (UCDP / GDELT): no event feed yet")
    as_of = run_as_of(run) if run is not None else None
    return {"as_of": (str(as_of)[:10] if as_of else None), "vintage": vintage, "sources": srcs}


def sources_stamp(src: dict) -> str:
    body = json.dumps({k: src.get(k) for k in ("as_of", "vintage", "sources") if src.get(k)}, ensure_ascii=True)
    return "<!-- econquest:sources " + body.replace("<", "\\u003c").replace(">", "\\u003e").replace("--", "-\\u002d") + " -->"


def _dates_line(src: dict) -> str:
    return " ".join(x for x in (f"As of {src['as_of']}." if src.get("as_of") else "As of: not recorded on the run.",
                                f"Vintage {src['vintage']}." if src.get("vintage") else "") if x)


def sources_html(src: dict, heading: bool = True) -> str:
    """Visible Sources section (<h2>Sources</h2>, one <li> per source, "As of" / "Vintage" line) plus the stamp."""
    li = "".join(f"<li>{_e(s)}</li>" for s in src.get("sources") or [])
    return ((("<h2>Sources</h2>") if heading else "") + f"<ul class='sources'>{li}</ul><p class='note'>{_e(_dates_line(src))}</p>" + sources_stamp(src))


def md_text(v) -> str:
    """Feed-derived text for a Markdown line or table cell: one line, no raw HTML, no table break (AGENT-09, SEC-C-004).
    A newline in a provenance or event-feed string could otherwise start a fake heading (e.g. a second "## Sources")."""
    return (" ".join(str("" if v is None else v).split()).replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("|", "\\|")
            .replace("[", "\\[").replace("]", "\\]").replace("`", "\\`"))   # no live links or code spans (SEC-C-006 R2)


def sources_md(src: dict) -> list[str]:
    return ["## Sources", ""] + [f"- {md_text(s)}" for s in src.get("sources") or []] + ["", _dates_line(src), "", sources_stamp(src)]
