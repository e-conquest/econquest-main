"""Value blocks for the Econometrics tab (same plan format as sheets_publish)."""
from __future__ import annotations

from datetime import date

import numpy as np
import pandas as pd

from .sheets_publish import _block, col_letter
from .garch_publish import _r


def _table(P, row, title, df: pd.DataFrame, cols: list[tuple[str, str, int]], note: str | None = None) -> int:
    """Write title, optional note, header and rows starting at `row`; return the next free row (one blank line after)."""
    P.append(_block(f"Econometrics!A{row}", [[title]])); row += 1
    if note:
        P.append(_block(f"Econometrics!A{row}", [[note]])); row += 1
    head = [h for _, h, _ in cols]
    body = []
    for _, s in df.iterrows():
        body.append([(_r(s.get(c), nd) if not isinstance(s.get(c), str) and not isinstance(s.get(c), (bool, np.bool_)) else (("yes" if s.get(c) else "no") if isinstance(s.get(c), (bool, np.bool_)) else s.get(c))) for c, _, nd in cols])
    end_col = col_letter(len(cols))      # was chr()-based and wrong past 52 columns (EQ-C-0033)
    P.append(_block(f"Econometrics!A{row}:{end_col}{row + len(body)}", [head] + body))
    return row + len(body) + 2


def econ_plan(e, stamp: str | None = None) -> tuple[list[dict], list[int]]:
    stamp = stamp or date.today().isoformat()
    P = []; titles = []
    P.append(_block("Econometrics!A1:A2", [
        [f"Econometrics toolkit: computed by the Python program (python -m econquest econ) on {stamp} from Market History prices to {e.as_of} and the GPR series. Daily log returns; FX as local currency per USD (a rise is a depreciation)."],
        ["Workflow followed for every series: (1) stationarity tests, (2) AR mean + GARCH(1,1)-t variance baseline, (3) residual autocorrelation and ARCH checks, (4) out-of-sample comparison of variance forecasts, (5) HAC (Newey-West) standard errors and Benjamini-Hochberg false-discovery control across series."]]))
    row = 4
    titles.append(row)
    row = _table(P, row, "Table 1. Workflow: stationarity, AR + GARCH baseline, residual checks, out-of-sample variance race", e.workflow, [
        ("country", "Country", 0), ("kind", "Series", 0), ("ticker", "Ticker", 0), ("obs", "Obs", 0),
        ("adf_price_stat", "ADF stat, log price", 2), ("adf_price_p", "ADF p, log price", 3), ("kpss_price_p", "KPSS p, log price", 3),
        ("adf_return_p", "ADF p, returns", 3), ("kpss_return_p", "KPSS p, returns", 3), ("adf_return_bh_reject", "Returns stationary (FDR 5%)", 0),
        ("ar_order", "AR order (BIC)", 0), ("ar1_coef", "AR(1) coef", 3), ("ar1_t_hac", "AR(1) t (HAC)", 2),
        ("lb_resid_p", "Ljung-Box p, AR resid", 3), ("arch_lm_resid_p", "ARCH-LM p, AR resid", 3), ("arch_bh_reject", "ARCH present (FDR 5%)", 0), ("bonferroni_arch_p", "ARCH p, Bonferroni", 3),
        ("garch_persistence", "GARCH alpha+beta", 3), ("garch_nu", "GARCH t df", 1), ("lb_sq_std_resid_p", "Ljung-Box p, sq std resid", 3), ("arch_lm_std_resid_p", "ARCH-LM p, std resid", 3),
        ("oos_qlike_garch", "OOS QLIKE GARCH", 3), ("oos_qlike_ewma", "OOS QLIKE EWMA", 3), ("oos_qlike_rolling", "OOS QLIKE rolling 60d", 3), ("oos_qlike_constant", "OOS QLIKE constant", 3),
        ("oos_best", "Best out of sample", 0), ("dm_garch_vs_ewma_t", "Diebold-Mariano t, GARCH vs EWMA", 2), ("dm_p", "DM p", 3)],
        note="Prices are unit-root (ADF fails to reject, KPSS rejects) and returns are stationary, so models run on returns. Out-of-sample: one-day-ahead variance forecasts over the last 250 days, GARCH refit every 50 days; QLIKE lower is better; a negative Diebold-Mariano t favours GARCH over EWMA(0.94).")
    titles.append(row)
    row = _table(P, row, "Table 2. Long-run relationships for pairs trading: Engle-Granger, Johansen trace, VECM adjustment", e.cointegration.head(30), [
        ("group", "Group", 0), ("y", "y", 0), ("x", "x", 0), ("obs", "Obs", 0), ("hedge_ratio", "Hedge ratio (log y on log x)", 3), ("eg_adf_stat", "Engle-Granger ADF", 2), ("eg_p", "EG p", 3), ("eg_bh_reject", "EG significant (FDR 5%)", 0),
        ("johansen_trace_r0", "Johansen trace (r=0)", 2), ("johansen_crit95_r0", "95% critical", 2), ("johansen_rank", "Johansen rank", 0),
        ("vecm_alpha_y", "VECM adjustment y", 3), ("vecm_alpha_x", "VECM adjustment x", 3), ("spread_half_life_days", "Spread half-life (days)", 1), ("spread_z_now", "Spread z-score now", 2), ("corr_returns", "Return correlation", 3), ("read", "Read", 0)],
        note=f"Only pairs whose two log prices are both unit-root processes are tested ({len(e.cointegration)} pairs within region and across all ETFs); the 30 strongest are shown. A pair is a candidate when both tests agree after false-discovery control; trade the spread z-score toward zero with the VECM half-life as the holding horizon.")
    titles.append(row)
    sm = e.svar_meta
    row = _table(P, row, "Table 3. SVAR: how a shock propagates (Cholesky identification, one-SD structural shocks, daily returns in %)", e.svar, [
        ("shock", "Shock to", 0), ("variable", "Response of", 0), ("h0", "Day 0", 3), ("h1", "Day 1", 3), ("h2", "Day 2", 3), ("cum_h5", "Cumulative to day 5", 3), ("cum_h10", "Cumulative to day 10", 3), ("fevd_share_h10_pct", "Share of 10-day variance explained %", 1)],
        note=f"VAR({sm['lags']}) on {sm['obs']} days, ordering {' > '.join(sm['order'])} (EEM first: the global EM shock is allowed to move everything the same day; the yen shock cannot move EEM contemporaneously). FX responses are depreciations in %; a one-SD EEM shock is {sm['shock_sd_pct'][0]:.2f}%.")
    titles.append(row)
    row = _table(P, row, "Table 4. Kalman filter: time-varying beta and hedge ratio (random-walk beta, signal-to-noise by maximum likelihood)", e.kalman, [
        ("country", "Country", 0), ("kind", "Series", 0), ("ticker", "Ticker", 0), ("factor", "Factor", 0), ("beta_ols", "Static OLS beta", 3), ("beta_ols_t_hac", "t (HAC)", 2),
        ("beta_now", "Kalman beta now", 3), ("beta_1y_ago", "Beta one year ago", 3), ("beta_min", "Min", 3), ("beta_max", "Max", 3), ("signal_to_noise_q", "Signal-to-noise q", 4), ("hedge_ratio_now", "Hedge ratio now (units of factor per unit)", 3)],
        note="ETFs against EEM (EM equity benchmark); currencies against an equal-weight basket of the eight liquid USD/EM pairs. q near zero means the beta is effectively constant; q large means the beta drifts.")
    titles.append(row)
    row = _table(P, row, "Table 5. Regime shifts: two-state Markov-switching (calm / turbulent) and a threshold autoregression", e.regimes, [
        ("country", "Country", 0), ("kind", "Series", 0), ("ticker", "Ticker", 0), ("ms_vol_calm", "Calm vol % ann", 1), ("ms_vol_turbulent", "Turbulent vol % ann", 1), ("ms_p_stay_calm", "P(stay calm)", 3), ("ms_p_stay_turbulent", "P(stay turbulent)", 3),
        ("ms_expected_turbulent_days", "Expected turbulent spell (days)", 1), ("ms_p_turbulent_now", "P(turbulent now)", 3), ("ms_share_turbulent", "Share of days turbulent", 3),
        ("tar_threshold_abs_ret_pct", "TAR threshold |return| %", 3), ("tar_phi_calm", "AR(1) below threshold", 3), ("tar_phi_turbulent", "AR(1) above threshold", 3), ("tar_ssr_reduction_pct", "SSR reduction vs linear %", 2), ("tar_sup_f", "Sup-F", 2), ("zero_return_share", "Zero-return share", 3)],
        note="Markov-switching: Gaussian mixture with a two-state Markov chain fitted by EM; the filtered probability of the turbulent state today is the regime signal. Threshold AR: the lagged absolute return splits the sample; a Sup-F above about 12 points to a real threshold effect (Hansen's bootstrap critical values are not computed). Blank TAR cells are pegged or stale quotes.")
    titles.append(row)
    pm = e.premia_meta
    fm = e.premia_fm.reset_index().rename(columns={"index": "factor"}); gm = e.premia_gmm.reset_index().rename(columns={"index": "factor"})
    row = _table(P, row, "Table 6a. Risk premia: Fama-MacBeth two-pass on weekly excess returns of the country ETFs (HAC standard errors)", fm, [
        ("factor", "Factor or characteristic", 0), ("premium_per_period", "Premium per week", 5), ("se_hac", "SE (HAC)", 5), ("t", "t", 2), ("factor_mean", "Factor mean per week", 5)],
        note=f"{pm['N']} ETFs, {pm['T']} weeks. First pass: full-sample betas on the EM market and the USD/EM FX basket; second pass: weekly cross-sectional regressions of returns on the betas and the Randori composite score (per 10 points). Premia are weekly; multiply by 52 for annual. Cross-sectional R-squared of average returns on betas: {pm['r2_cross_section']:.2f}.")
    titles.append(row)
    row = _table(P, row, "Table 6b. Risk premia: GMM estimate of the factor premia (two-step, HAC weighting) with the Hansen J test of the pricing errors", gm, [
        ("factor", "Factor", 0), ("premium_per_period", "Premium per week", 5), ("se", "SE", 5), ("t", "t", 2)],
        note=f"Moment conditions: average pricing error of each ETF equals zero. J = {pm['J']:.2f}, p = {pm['J_p']:.3f} (a high p means the two factors are not rejected as a pricing model, which with three years of weekly data mostly reflects low power).")
    titles.append(row)
    row = _table(P, row, "Table 7. GARCH + EVT: generalized Pareto tail on the standardized losses (peaks over the 90th percentile)", e.evt, [
        ("country", "Country", 0), ("kind", "Series", 0), ("ticker", "Ticker", 0), ("threshold_u", "Threshold u (std units)", 2), ("exceedances", "Exceedances", 0), ("gpd_xi", "GPD shape xi", 3), ("gpd_beta", "GPD scale", 3), ("tail_index_1_over_xi", "Tail index 1/xi", 1),
        ("var99_1d_evt_pct", "VaR99 1d EVT %", 2), ("var99_1d_t_pct", "VaR99 1d Student-t %", 2), ("var999_1d_evt_pct", "VaR99.9 1d EVT %", 2), ("var999_1d_t_pct", "VaR99.9 1d Student-t %", 2),
        ("es99_1d_evt_pct", "ES99 1d EVT %", 2), ("es999_1d_evt_pct", "ES99.9 1d EVT %", 2), ("exposure_mm", "Book exposure $mm", 1), ("var999_10d_evt_mm", "VaR99.9 10d EVT $mm", 2)],
        note="Shape xi above 0 means a heavy (Pareto) tail; the tail index 1/xi is the highest finite moment. EVT and Student-t agree at 99%; the difference at 99.9% is the sizing error of a parametric tail. ES undefined when xi is at or above 1.")
    titles.append(row)
    row = _table(P, row, "Table 8. Joint tail risk: Student-t and Clayton copulas on GARCH-standardized losses (lower-tail dependence = chance both lose together in the tail)", e.copulas, [
        ("pair", "Pair", 0), ("countries", "Countries", 0), ("obs", "Obs", 0), ("kendall_tau", "Kendall tau", 3), ("t_rho", "t copula rho", 3), ("t_nu", "t copula df", 1), ("t_lambda_joint_loss", "Tail dependence, t", 3),
        ("clayton_theta", "Clayton theta", 3), ("clayton_lambda_joint_loss", "Tail dependence, Clayton", 3), ("empirical_lambda_5pct", "Empirical (5% tail)", 3), ("better_fit", "Better fit (AIC)", 0), ("aic_t", "AIC t", 1), ("aic_clayton", "AIC Clayton", 1)],
        note="The eight most correlated ETF pairs and five currency pairs. Tail dependence of 0.2 means that when one asset has a 1-in-100 loss day, the other has a 20% chance of its own 1-in-100 loss. The Student-t fits better everywhere here, which supports the t copula used in the Monte Carlo engine.")
    titles.append(row)
    fc = e.forecasts
    row = _table(P, row, "Table 9. Forecasting next-21-day volatility with many predictors: out-of-sample comparison", fc, [
        ("model", "Model", 0), ("features", "Predictors", 0), ("n_train", "Training rows", 0), ("n_test", "Test rows", 0), ("r2_in_sample", "R-squared in sample", 3), ("r2_out_of_sample", "R-squared out of sample", 3), ("rmse_oos_log_vol", "RMSE out of sample (log vol)", 3)],
        note=f"Panel of all series, daily rows; target is log realized volatility over the next 21 days; 12 predictors (rolling vols, GARCH vol, momentum, EEM and FX-basket vol, last GPR change, series type). Train before {e.notes['forecast_split']}, test after. Random forest fits the training sample best and generalizes worst: the classic overfitting signature.")
    imp = e.forecast_importance.reset_index().rename(columns={"index": "predictor"})
    titles.append(row)
    row = _table(P, row, "Table 9b. Which predictors matter: lasso coefficients (standardized) and random-forest importances", imp, [
        ("predictor", "Predictor", 0), ("lasso_coef", "Lasso coefficient", 3), ("rf_importance", "Random-forest importance", 3)])
    titles.append(row)
    row = _table(P, row, "Table 10. Event study: country ETF abnormal returns around currency shocks (market model on EEM, estimation window days -250 to -21)", e.events, [
        ("country", "Country", 0), ("etf", "ETF", 0), ("fx", "Currency", 0), ("n_events", "Events", 0), ("fx_threshold_pct", "Shock threshold (daily depreciation %)", 2),
        ("car_0_0_pct", "AR day 0 %", 2), ("t_0_0", "t", 2), ("car_0_1_pct", "CAR days 0-1 %", 2), ("t_0_1", "t", 2), ("car_0_5_pct", "CAR days 0-5 %", 2), ("t_0_5", "t", 2), ("car_0_20_pct", "CAR days 0-20 %", 2), ("t_0_20", "t", 2)],
        note="An event is a one-day depreciation beyond three robust standard deviations, at least 21 trading days apart. Abnormal return = ETF return minus its market-model fit on EEM. A negative CAR with |t| above 2 means the equity market reliably sells off on currency shocks beyond what EM equities did that day.")
    return P, titles
