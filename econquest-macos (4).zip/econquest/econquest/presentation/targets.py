"""Target-state scorecard (EQ-C-0061, PI-5): re-scores the plan's target-state table and gate criteria from evidence.

Source of the targets: the Claude Doc "EconQuest: plan to an institutional-grade desk" (Sam, 2026-10-23), section
"Target state" (six dimensions: coverage, data, models, track record, research, controls) and the PI gate criteria
of "The increments". Every row here is computed from a file in the repository or the record; nothing is typed by
hand. A row whose evidence is missing or unreadable is scored "no evidence", never "yes". A criterion that only Sam
can unlock (a licence, real P&L) is scored "waiting on Sam" when not met, as the plan asks ("never marked failed").

    target_scorecard(data_dir, outputs_dir, root=None, tests_file=None) -> pd.DataFrame   (one row per target)
    to_markdown(df) -> str ;  write_scorecard(df, out_dir) -> (md_path, csv_path)

Columns: id, dimension, target, current, met (yes | no | waiting on Sam | no evidence), evidence (path).
The evidence bundle (`econquest evidence`, EQ-C-0060) can call target_scorecard and write_scorecard directly.
"""
from __future__ import annotations

import datetime as dt
import json
import re
from pathlib import Path
from typing import Callable

import pandas as pd

COLUMNS = ["id", "dimension", "target", "current", "met", "evidence"]
MET = ("yes", "no", "waiting on Sam", "no evidence")
ROOT = Path(__file__).resolve().parents[2]
PLAN = 'Claude Doc "EconQuest: plan to an institutional-grade desk", Target state and gate criteria (2026-10-23)'

# Thresholds, each quoted from the plan (target-state table unless a gate is named)
MIN_SOVEREIGNS = 60                 # Coverage: 60+ sovereigns
MAX_MISSING_SHARE = 0.05            # Coverage: missing-cell report under 5%
MIN_LIVE_SHARE = 0.60               # PI-3 gate: 60% or more of Inputs cells live
MIN_AUC_TARGET = 0.70               # Models: hazard OOS AUC at least 0.70 on 30+ events
MIN_AUC_GATE = 0.75                 # PI-2 gate: AUC at least 0.75 on 30+ events, passing the --apply gate
MIN_EVENTS = 30
MIN_RECORD_DAYS = 250               # Track record: 250+ trading days passing Basel green
MIN_IDEA_DAYS = 273                 # PI-5 gate: trade-idea track record for 3 quarters (3 x 91 days)


class NoEvidence(Exception):
    """The evidence file for a row is missing or unreadable."""


def _row(rid, dimension, target, evidence, fn: Callable[[], tuple[str, str]]) -> dict:
    try:
        current, met = fn()
    except NoEvidence as e:
        current, met = str(e), "no evidence"
    except Exception as e:  # noqa: BLE001 - a broken evidence file scores "no evidence", it never stops the scorecard
        current, met = f"evidence unreadable: {type(e).__name__}: {str(e)[:160]}", "no evidence"
    assert met in MET, met
    return {"id": rid, "dimension": dimension, "target": target, "current": current, "met": met, "evidence": evidence}


def _yn(ok: bool) -> str:
    return "yes" if ok else "no"


def _need(path: Path) -> Path:
    if not Path(path).exists():
        raise NoEvidence(f"{path} missing")
    return Path(path)


def _rel(path: Path, root: Path) -> str:
    try:
        return str(Path(path).resolve().relative_to(root.resolve()))
    except ValueError:
        return str(path)


# ------------------------------------------------------------------------------------------------- evidence readers

def _missing_report(data_dir: Path):
    from ..ingestion.universe import missing_cell_report
    _need(data_dir / "live" / "live_inputs.csv")
    return missing_cell_report(data_dir)


def security_findings(root: Path) -> pd.DataFrame:
    """id, status of every team/security/SEC-*.md (the `status:` front-matter line)."""
    rows = []
    for p in sorted((root / "team" / "security").glob("SEC-*.md")):
        m = re.search(r"^status:\s*([A-Za-z-]+)", p.read_text(encoding="utf-8", errors="replace"), re.MULTILINE)
        rows.append({"id": p.stem, "status": m.group(1).lower() if m else "unknown"})
    return pd.DataFrame(rows, columns=["id", "status"])


def _open_validation(status: str) -> bool:
    s = str(status).strip().lower()
    return s.startswith("open") or s.startswith("in progress") or not s


def test_result(root: Path, tests_file=None) -> tuple[int, int, int, Path]:
    """(passed, failed, skipped, source) from a saved pytest output (`tests_file`), else from the newest release
    note under docs/governance/releases/ that records a full-suite result."""
    def parse(text: str):
        m = re.search(r"([\d,]+) passed", text)
        if not m:
            return None
        n = lambda k: int(re.search(rf"([\d,]+) {k}", text).group(1).replace(",", "")) if re.search(rf"([\d,]+) {k}", text) else 0  # noqa: E731
        return int(m.group(1).replace(",", "")), n("failed") + n("error"), n("skipped")
    if tests_file is not None:
        p = _need(Path(tests_file))
        text = p.read_text(encoding="utf-8", errors="replace")
        if text.lstrip().startswith("<"):                    # a junit XML report (pytest --junitxml)
            from defusedxml import ElementTree as ET
            try:
                top = ET.fromstring(p.read_bytes())
            except ET.ParseError as e:
                raise NoEvidence(f"{p}: not valid junit XML ({e})") from None
            suites = [top] if top.tag == "testsuite" else top.findall("testsuite")
            if not suites:
                raise NoEvidence(f"{p}: junit XML has no <testsuite>")
            n = {k: sum(int(x.get(k, 0) or 0) for x in suites) for k in ("tests", "failures", "errors", "skipped")}
            bad = n["failures"] + n["errors"]
            return n["tests"] - bad - n["skipped"], bad, n["skipped"], p
        tail = text.splitlines()[-30:]
        r = parse("\n".join(tail))
        if r is None:
            raise NoEvidence(f"{p}: no pytest summary line")
        return (*r, p)

    def version(p: Path):
        m = re.match(r"(\d+)\.(\d+)\.(\d+)", p.name)
        return tuple(int(x) for x in m.groups()) if m else (-1,)
    notes = sorted((root / "docs" / "governance" / "releases").glob("*.md"), key=lambda p: (version(p), "package" in p.name),
                   reverse=True)
    for p in notes:
        for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
            if re.search(r"(full suite|tests:)", line, re.IGNORECASE):
                r = parse(line)
                if r:
                    return (*r, p)
    raise NoEvidence("no saved pytest output and no release note with a full-suite result")


# ------------------------------------------------------------------------------------------------- the scorecard

def target_scorecard(data_dir, outputs_dir, root=None, tests_file=None, replication_table=None) -> pd.DataFrame:
    """One row per target, scored from the evidence under data_dir, outputs_dir and the repository root.
    replication_table: the replication result to score (as a DataFrame) instead of <outputs>/replication/replication.csv."""
    d, out = Path(data_dir), Path(outputs_dir)
    root = Path(root) if root is not None else ROOT
    rows = []
    add = lambda *a: rows.append(_row(*a))  # noqa: E731
    cache: dict = {}

    def missing():
        if "m" not in cache:
            cache["m"] = _missing_report(d)
        return cache["m"]

    # ---- Coverage
    def sovereigns():
        c = pd.read_csv(_need(d / "countries.csv"))
        return f"{len(c)} sovereigns", _yn(len(c) >= MIN_SOVEREIGNS)
    add("COV-1", "Coverage", f"{MIN_SOVEREIGNS}+ sovereigns in the universe", _rel(d / "countries.csv", root), sovereigns)

    def missing_share():
        s = missing().summary
        share = 1 - float(s["pct_live_overall"])
        return (f"{share:.1%} of Inputs cells not live ({s['n_countries']} countries; "
                f"{s['cells_without_any_value']} cells with no value at all)"), _yn(share < MAX_MISSING_SHARE)
    add("COV-2", "Coverage", f"missing-cell report under {MAX_MISSING_SHARE:.0%}", _rel(d / "live" / "live_inputs.csv", root),
        missing_share)

    # ---- Data
    def live_share():
        s = missing().summary
        return (f"{float(s['pct_live_overall']):.1%} live; {s['countries_meeting_target']} of {s['n_countries']} countries "
                f"at {float(s['target']):.0%}"), _yn(float(s["pct_live_overall"]) >= MIN_LIVE_SHARE)
    add("DAT-1", "Data", f"{MIN_LIVE_SHARE:.0%} or more of Inputs cells live (PI-3 gate)",
        _rel(d / "live" / "live_inputs.csv", root), live_share)

    def seed_rows():
        a = pd.read_csv(_need(d / "audit_trail.csv"), dtype=str, keep_default_na=False)
        seed = a["origin"].str.lower().str.startswith("seed")
        hand = a["origin"].str.contains("UNATTESTED", regex=False)
        return (f"{int(seed.sum())} of {len(a)} audit-trail cells are seed values; {int(hand.sum())} hand-entered cells "
                "unattested"), _yn(not seed.any())
    add("DAT-2", "Data", "audit trail with no seed rows", _rel(d / "audit_trail.csv", root), seed_rows)

    def quality_gate():
        rv = pd.read_csv(_need(d / "live" / "review.csv"), dtype=str, keep_default_na=False)
        st = rv["status"].value_counts().to_dict() if "status" in rv else {}
        return (f"gate ran on the latest pull: {len(rv)} cells reviewed, "
                + ", ".join(f"{v} {k}" for k, v in sorted(st.items()))), "yes"
    add("DAT-3", "Data", "quality gate on every pull (data quality gate)", _rel(d / "live" / "review.csv", root), quality_gate)

    def market_gate():
        from ..ingestion.market.cds_export import market_gate_review
        try:
            review, cur = market_gate_review(d)
        except FileNotFoundError:
            return "no market snapshot under data/live/market: spreads still hand-entered", "waiting on Sam"
        held = int((review["status"] == "hold").sum())
        srcs = sorted(set(cur["source"])) if "source" in cur else []
        return f"{len(review)} series, {held} held; sources {srcs}", _yn(len(review) > 0 and held == 0)
    add("DAT-4", "Data", "market gate passes on the latest market data (no held series)",
        _rel(d / "live" / "market" / "snapshots", root), market_gate)

    def licences():
        from ..ingestion.market.vendors import vendor_status
        st = vendor_status(d)
        ok = st.loc[st["usable"], "vendor"].tolist()
        lic = st.loc[st["licence"] == "ok", "vendor"].tolist()
        return (f"usable vendor adapters: {ok or 'none'}; licences configured: {lic or 'none'}"), \
            ("yes" if ok else "waiting on Sam")
    add("DAT-5", "Data", "vendor licences on file (Bloomberg / LSEG, paid roadmap feature)",
        _rel(d / "vendor_licences.json", root) + " or $ECONQUEST_VENDOR_LICENCE_<VENDOR>", licences)

    # ---- Models
    def hazard(min_auc: float):
        def fn():
            fit = json.loads(_need(out / "hazard_fit.json").read_text(encoding="utf-8"))
            oos = fit.get("out_of_sample") or {}
            if "auc" not in oos:
                raise NoEvidence(f"{out / 'hazard_fit.json'}: no out-of-sample result")
            auc, ev = float(oos["auc"]), int(oos.get("events", 0))
            return (f"OOS AUC {auc:.3f} on {ev} events ({oos.get('first_year')}-{oos.get('last_year')}); panel "
                    f"{(fit.get('panel') or {}).get('events', '?')} events"), _yn(auc >= min_auc and ev >= MIN_EVENTS)
        return fn
    add("MOD-1", "Models", f"hazard OOS AUC at least {MIN_AUC_TARGET:.2f} on {MIN_EVENTS}+ events",
        _rel(out / "hazard_fit.json", root), hazard(MIN_AUC_TARGET))
    add("MOD-2", "Models", f"hazard gate: AUC at least {MIN_AUC_GATE:.2f} on {MIN_EVENTS}+ events, passing --apply (PI-2 gate)",
        _rel(out / "hazard_fit.json", root), hazard(MIN_AUC_GATE))

    def replication():
        r = (replication_table.astype(str) if replication_table is not None
             else pd.read_csv(_need(out / "replication" / "replication.csv"), dtype=str, keep_default_na=False))
        st = r["status"].str.upper()
        n_fail = int((st == "FAIL").sum())
        other = {k: int(v) for k, v in st[~st.isin(["PASS", "FAIL"])].value_counts().items()}
        return (f"{int((st == 'PASS').sum())} PASS, {n_fail} FAIL of {len(r)} checks" + (f" (also {other})" if other else "")), \
            _yn(len(r) > 0 and n_fail == 0)
    add("MOD-3", "Models", "same hashes give the same numbers (replication: 0 FAIL)",
        _rel(out / "replication" / "replication.csv", root), replication)

    # ---- Track record
    def record():
        from ..validation.record import load_record, record_for_backtest
        rec = record_for_backtest(load_record(_need(d / "forecast_record.csv")))
        n = len(rec)
        if n == 0:
            return "0 testable days", "no"
        from ..validation.backtests import basel_zone
        exc = int((rec["loss"].astype(float) > rec["var"].astype(float)).sum())
        zone = basel_zone(exc, n)
        span = f"{pd.Timestamp(rec['date'].min()).date()} to {pd.Timestamp(rec['date'].max()).date()}"
        return (f"{n} testable days ({span}), {exc} VaR99 exceedances, Basel {zone}"), \
            _yn(n >= MIN_RECORD_DAYS and zone == "Green")
    add("TRK-1", "Track record", f"{MIN_RECORD_DAYS}+ trading days of VaR/ES record passing Basel green",
        _rel(d / "forecast_record.csv", root), record)

    def ideas():
        log = pd.read_csv(_need(out / "idea_log.csv"), dtype=str, keep_default_na=False)
        if log.empty:
            return "0 ideas logged", "no"
        closed = log[log["status"] == "closed"]
        pnl = pd.to_numeric(closed["pnl_mm"], errors="coerce").dropna()
        dates = pd.to_datetime(pd.concat([log["as_of"], log["mark_date"], log["close_date"]]), errors="coerce").dropna()
        span = int((dates.max() - dates.min()).days) if len(dates) else 0
        hit = f", hit rate {float((pnl > 0).mean()):.0%}, P&L {pnl.sum():+.2f} $mm" if len(pnl) else ""
        return (f"{len(log)} ideas, {len(closed)} closed{hit}; log spans {span} days"), \
            _yn(len(pnl) > 0 and span >= MIN_IDEA_DAYS)
    add("TRK-2", "Track record", "idea log scored with hit rate and P&L over 3 quarters (PI-5 gate)",
        _rel(out / "idea_log.csv", root), ideas)

    # ---- Research
    def research():
        from . import editorial as E
        if not E.ledger_path(out).exists():
            return "no editorial ledger: 0 published items", "no"
        if E.verify_chain(out):
            return "editorial ledger hash chain broken", "no"
        pub = E.list_items(out, state="published")
        if not pub:
            return "0 published items", "no"
        bad = [i["item_id"] for i in pub if not (i.get("author") and i.get("reviewer") and (i.get("meta") or {}).get("as_of"))]
        kinds = pd.Series([i["kind"] for i in pub]).value_counts().to_dict()
        return (f"{len(pub)} published ({kinds}); {len(bad)} without author, reviewer or data as-of"), _yn(not bad)
    add("RES-1", "Research", "every published note has an author, a reviewer and a data as-of",
        _rel(out / "editorial" / "ledger.jsonl", root), research)

    # ---- Controls
    def security():
        f = security_findings(root)
        if f.empty:
            raise NoEvidence(f"no findings under {root / 'team' / 'security'}")
        op = f.loc[f["status"] == "open", "id"].tolist()
        return f"{len(op)} open of {len(f)} security findings" + (f": {op}" if op else ""), _yn(not op)
    add("CTL-1", "Controls", "security findings closed (AGENT-09)", "team/security/SEC-*.md", security)

    def validation():
        r = pd.read_csv(_need(root / "docs" / "validation" / "dossier" / "findings-register.csv"), dtype=str,
                        keep_default_na=False)
        op = r[r["status"].map(_open_validation)]
        sev = op["severity"].value_counts().to_dict() if "severity" in op else {}
        return f"{len(op)} open of {len(r)} validation findings {sev}", _yn(len(op) == 0)
    add("CTL-2", "Controls", "validator findings closed", "docs/validation/dossier/findings-register.csv", validation)

    src = {"path": "docs/governance/releases/ (latest note with a full-suite result)"}

    def tests():
        passed, failed, skipped, p = test_result(root, tests_file)
        src["path"] = _rel(p, root)
        return f"{passed} passed, {failed} failed, {skipped} skipped", _yn(passed > 0 and failed == 0)
    rows.append(_row("CTL-3", "Controls", "full test suite green", "", tests))
    rows[-1]["evidence"] = src["path"]
    return pd.DataFrame(rows, columns=COLUMNS)


def to_markdown(df: pd.DataFrame, now: dt.datetime | None = None) -> str:
    now = now or dt.datetime.now(dt.timezone.utc)
    esc = lambda s: str(s).replace("|", "\\|").replace("\n", " ")  # noqa: E731
    counts = df["met"].value_counts().to_dict()
    lines = [f"# Target-state scorecard ({now.strftime('%Y-%m-%d %H:%M')}Z)", "",
             f"Targets: {PLAN}. Every row is computed from the evidence file named; nothing is entered by hand.", "",
             "Met: " + ", ".join(f"{counts.get(m, 0)} {m}" for m in MET) + f" (of {len(df)}).", "",
             "| id | dimension | target | current | met | evidence |", "|---|---|---|---|---|---|"]
    lines += [f"| {r.id} | {esc(r.dimension)} | {esc(r.target)} | {esc(r.current)} | **{r.met}** | `{esc(r.evidence)}` |"
              for r in df.itertuples(index=False)]
    return "\n".join(lines) + "\n"


def write_scorecard(df: pd.DataFrame, out_dir, now: dt.datetime | None = None) -> tuple[Path, Path]:
    """targets.md and targets.csv in out_dir (created)."""
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    md, csv = out / "targets.md", out / "targets.csv"
    md.write_text(to_markdown(df, now), encoding="utf-8")
    df.to_csv(csv, index=False)
    return md, csv
