"""Local desktop GUI: a browser app served from the standard library, with charts (Plotly) and buttons that run the
program's own commands (fetch, run, garch, econ, publish) as background jobs with a live log.

    econquest gui                 # starts http://127.0.0.1:8765 and opens the browser

Routes (in addition to everything in api.py):
  GET  /                         the app page
  GET  /api/status               which outputs exist and when they were produced
  GET  /api/table/<name>         an outputs CSV as JSON records (country_risk, garch/series, econometrics/svar, ...)
  GET  /api/json/<name>          an outputs JSON file (stress, backtest)
  GET  /api/data/<name>          a data CSV as JSON records (countries, portfolio, indicators, ...)
  GET  /api/events               event heat by country and source, week-on-week change (events_view.event_summary for
                                 the latest run's countries; status "missing" / "stale" when the feed is absent or old)
  GET  /api/ideas                trade-idea ledger by quarter (ideas_view.ideas_summary of outputs/idea_log.csv; status
                                 "missing" / "empty" / "invalid" when there is no log, no ideas or an unreadable log)
  GET  /api/rv                   bond relative value and CDS curves (rv_view.rv_summary of outputs/bond_rv.csv,
                                 bond_rv_positions.csv, cds_curves.csv; per-file status "missing" / "empty" / "invalid";
                                 read-only, file names only, never test data; EQ-C-0046)
  GET  /api/evidence-clock       calendar-gated evidence monitor (evidence_view.evidence_clock; ?as_of=YYYY-MM-DD, default
                                 settings as_of, else today; read-only, file names only; EQ-C-0068)
  GET  /api/jobs                job list with status and log tail
  POST /api/job                  {"cmd": "run"|"stress"|"fetch"|"garch"|"econ"|"publish", "args": [...], "sheets_token": "..."} -> start a job
                                 (the token reaches the child in $ECONQUEST_SHEETS_TOKEN, never its argv or the job log)
  POST /api/reload               reload the latest run from the store after a `run` job
"""
from __future__ import annotations
import json
import os
import subprocess
import sys
import threading
import time
import webbrowser
from http.server import ThreadingHTTPServer
from pathlib import Path
from urllib.parse import parse_qs, urlparse, unquote
import numpy as np
import pandas as pd
from ..engine.pipeline import dumps
from .api import App, make_handler

STATIC = Path(__file__).resolve().parent / "static"
ALLOWED_CMDS = {"run", "stress", "backtest", "fetch", "garch", "econ", "publish", "arbitrage", "record", "prices", "audit", "fit-hazard", "cds", "benchmark", "report", "alerts", "limits", "monitor", "scenarios", "reverse-stress", "governance", "dsa", "regimes", "ideas"}
# Commands a GUI job may run only with one of these subcommands, given first (EQ-C-0063, usability U22). `ideas report`
# prints outputs/idea_report.md; `ideas log` advances outputs/idea_log.csv from an archived base run, as `run` already
# does from the GUI. Neither writes data/ or the workbook or needs an identity. `ideas mark` stays CLI-only.
GUI_SUBCMDS = {"ideas": ("report", "log")}
TOKEN_ENV = "ECONQUEST_SHEETS_TOKEN"            # same name cli.resolve_token reads
FETCH_IDENTITY_FLAGS = ("--force", "--author", "--approver", "--self-approved")   # CLI-only: need a named operator
IDENTITY_CMDS = {"fetch", "market", "review"}   # commands whose FETCH_IDENTITY_FLAGS a GUI job drops (market: EQ-C-0053;
# review, not in ALLOWED_CMDS either, defence in depth for decide/approve --author/--approver/--self-approved: SEC-C-007)
WRITER_CMDS = {"publish", "garch", "econ", "audit", "record", "dsa", "benchmark"}   # subcommands that take --write
INDEXED = {"latent_correlation", "country_risk", "positions", "garch/dcc_fx", "garch/dcc_eq", "garch/vol_history",
           "econometrics/premia_fm", "econometrics/premia_gmm", "econometrics/forecast_importance"}


class Jobs:
    """Runs one CLI command at a time in a subprocess and keeps its log in memory."""

    def __init__(self, data_dir: str, out_dir: str):
        self.data_dir, self.out_dir = data_dir, out_dir
        self.jobs: list[dict] = []; self.lock = threading.Lock(); self.proc: subprocess.Popen | None = None

    def running(self) -> bool:
        return self.proc is not None and self.proc.poll() is None

    def start(self, cmd: str, args: list[str], secrets: list[str] | None = None, sheets_token: str | None = None) -> dict:
        """Start one CLI job. The Sheets token goes to the child in $ECONQUEST_SHEETS_TOKEN, never on argv (EQ-C-0002):
        a legacy `--token X` / `--token=X` in args is taken out of argv and moved to the environment. A writer job
        gets `--write` only when it has a token; a client-sent `--write` or `--token-file` is dropped, so a job
        without a token can never pick up the Keychain."""
        if cmd not in ALLOWED_CMDS:
            raise ValueError(f"unknown command {cmd}")
        if self.running():
            raise RuntimeError("a job is already running")
        args = [str(a) for a in args]; clean: list[str] = []; i = 0
        while i < len(args):
            a = args[i]
            if a == "--token":
                if i + 1 < len(args):
                    sheets_token = sheets_token or args[i + 1]
                i += 2; continue
            if a.startswith("--token="):
                sheets_token = sheets_token or a[len("--token="):]
                i += 1; continue
            # Only this server decides whether a job writes. argparse also accepts unique prefixes (--wr, --token-f,
            # --token-fi=PATH), so any prefix of --write / --token-file is dropped too (SEC-C review of EQ-C-0002).
            f = a.split("=", 1)[0]
            if len(f) > 2 and ("--write".startswith(f) or "--token-file".startswith(f)):
                i += 2 if ("--token-file".startswith(f) and "=" not in a) else 1; continue
            # The run gate's per-invocation override is an operator decision recorded under an identity; GUI jobs have
            # none, so a GUI client cannot pass it (AGENT-09 review of EQ-C-0034, SEC-C-004)
            if len(f) > 2 and "--allow-unattested".startswith(f):        # argparse prefixes too (--a, --allow)
                i += 1; continue
            # GUI jobs carry no identity, so a GUI fetch cannot claim a forced apply or a four-eyes approval (EQ-C-0019).
            # `market` (enter --author/--approver/--self-approved, HO-20261023-A-C-015) is not in ALLOWED_CMDS; if it is
            # ever allowed, its identity flags are stripped the same way (EQ-C-0053)
            if cmd in IDENTITY_CMDS and len(f) > 2 and any(o.startswith(f) for o in FETCH_IDENTITY_FLAGS):
                takes_value = any(o.startswith(f) for o in ("--author", "--approver"))
                i += 2 if (takes_value and "=" not in a) else 1; continue
            clean.append(a); i += 1
        if cmd in GUI_SUBCMDS and (not clean or clean[0] not in GUI_SUBCMDS[cmd]):
            raise ValueError(f"{cmd}: the GUI runs only {' or '.join(f'{cmd} {c}' for c in GUI_SUBCMDS[cmd])}")
        if cmd not in WRITER_CMDS:
            sheets_token = None
        if sheets_token:
            clean.append("--write")                               # write only because this request carried a token
        hidden = [str(x) for x in [sheets_token, *(secrets or [])] if x]
        argv = [sys.executable, "-m", "econquest", "--data", self.data_dir, "--out", self.out_dir, cmd, *clean]
        shown = self._redact(" ".join(("***" if a in hidden else a) for a in argv[2:]), hidden)
        job = {"id": len(self.jobs) + 1, "cmd": cmd, "argv": shown, "started": time.strftime("%Y-%m-%d %H:%M:%S"), "status": "running",
               "log": [], "returncode": None, "finished": None}
        with self.lock:
            self.jobs.append(job)
        root = Path(__file__).resolve().parents[2]            # the folder that holds the econquest package: run that exact code
        env = dict(os.environ); env["PYTHONPATH"] = str(root) + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
        env.setdefault("PYTHONUNBUFFERED", "1")
        env.pop(TOKEN_ENV, None)                              # a job writes the workbook only when this request gave it a token
        if sheets_token:
            env[TOKEN_ENV] = sheets_token
        self.proc = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True, bufsize=1, cwd=str(root), env=env)
        threading.Thread(target=self._pump, args=(job, self.proc, hidden), daemon=True).start()
        return self.view(job)

    @staticmethod
    def _redact(line: str, hidden: list[str]) -> str:
        for h in hidden:
            line = line.replace(h, "***")
        return line

    def _pump(self, job: dict, proc: subprocess.Popen, hidden: list[str] | None = None):
        for line in proc.stdout:
            with self.lock:
                job["log"].append(self._redact(line.rstrip("\n"), hidden or []))
                if len(job["log"]) > 2000:
                    del job["log"][:500]
        proc.wait()
        with self.lock:
            job["returncode"] = proc.returncode; job["status"] = "done" if proc.returncode == 0 else "failed"
            job["finished"] = time.strftime("%Y-%m-%d %H:%M:%S")

    def view(self, job: dict, tail: int = 400) -> dict:
        with self.lock:
            return {k: v for k, v in job.items() if k != "log"} | {"log": job["log"][-tail:]}

    def list(self) -> list[dict]:
        return [self.view(j, tail=60) for j in self.jobs[-20:]]


def _records(df: pd.DataFrame) -> str:
    df = df.replace([np.inf, -np.inf], np.nan)
    return df.to_json(orient="records", date_format="iso", double_precision=6)


def make_gui_handler(app: App, jobs: Jobs, out_dir: Path, data_dir: Path):
    Base = make_handler(app)

    class G(Base):
        def do_GET(self):
            if not self._guard(write=False):
                return
            p = urlparse(self.path); path = unquote(p.path)
            if path == "/":
                page = (STATIC / "gui.html").read_text(encoding="utf-8").replace("__ECONQUEST_TOKEN__", app.token)
                return self._send(200, page, "text/html; charset=utf-8")
            if path == "/favicon.ico":
                self.send_response(204); self.end_headers(); return
            if path.startswith("/static/"):
                f = STATIC / path[len("/static/"):]
                if ".." in path or not f.is_file():
                    return self._send(404, dumps({"error": "not found"}))
                ctype = "application/javascript" if f.suffix == ".js" else "text/css" if f.suffix == ".css" else "application/octet-stream"
                data = f.read_bytes()
                self.send_response(200); self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(data)))
                self.send_header("Cache-Control", "max-age=86400"); self.end_headers(); self.wfile.write(data); return
            if path == "/api/status":
                return self._send(200, dumps(self._status()))
            if path.startswith("/api/table/"):
                name = path[len("/api/table/"):].strip("/")
                f = out_dir / f"{name}.csv"
                if ".." in name or not f.exists():
                    return self._send(404, dumps({"error": f"no table {name}"}))
                df = pd.read_csv(f, index_col=0 if name in INDEXED else None)
                if name in INDEXED:
                    df.index.name = df.index.name or "index"; df = df.reset_index()
                return self._send(200, _records(df))
            if path.startswith("/api/data/"):
                name = path[len("/api/data/"):].strip("/")
                f = data_dir / f"{name}.csv"
                if ".." in name or not f.exists():
                    return self._send(404, dumps({"error": f"no data file {name}"}))
                return self._send(200, _records(pd.read_csv(f)))
            if path.startswith("/api/json/"):
                name = path[len("/api/json/"):].strip("/")
                f = out_dir / f"{name}.json"
                if ".." in name or not f.exists():
                    return self._send(404, dumps({"error": f"no file {name}"}))
                return self._send(200, f.read_text())
            if path == "/api/events":
                return self._send(200, dumps(self._events()))
            if path == "/api/ideas":
                from .ideas_view import ideas_summary
                return self._send(200, dumps(ideas_summary(out_dir)))
            if path == "/api/rv":
                from .rv_view import rv_summary
                return self._send(200, dumps(rv_summary(out_dir)))
            if path == "/api/evidence-clock":
                from .evidence_view import as_of_param, evidence_clock
                q = (parse_qs(p.query).get("as_of") or [""])[0].strip()
                if q:
                    try:
                        q = as_of_param(q)                 # strict YYYY-MM-DD (SEC-C-009)
                    except ValueError:
                        return self._send(400, dumps({"error": "as_of must be YYYY-MM-DD"}))
                return self._send(200, dumps(evidence_clock(data_dir, out_dir, q or None)))
            if path == "/api/jobs":
                return self._send(200, json.dumps({"running": jobs.running(), "jobs": jobs.list()}))
            if path.startswith("/api/job/"):
                try:
                    j = jobs.jobs[int(path.rsplit("/", 1)[1]) - 1]
                except (ValueError, IndexError):
                    return self._send(404, dumps({"error": "no such job"}))
                return self._send(200, json.dumps(jobs.view(j)))
            return super().do_GET()

        def do_POST(self):
            if not self._guard(write=True):
                return
            p = urlparse(self.path)
            if p.path == "/api/job":
                try:
                    n = int(self.headers.get("Content-Length", 0)); body = json.loads(self.rfile.read(n) or b"{}")
                except ValueError:
                    return self._send(400, json.dumps({"error": "body must be JSON"}))
                if not isinstance(body, dict):
                    return self._send(400, json.dumps({"error": "body must be a JSON object"}))
                try:
                    kw = {"sheets_token": str(body["sheets_token"])} if body.get("sheets_token") else {}
                    j = jobs.start(body.get("cmd", ""), body.get("args", []), secrets=body.get("secrets"), **kw)
                    return self._send(200, json.dumps(j))
                except (ValueError, RuntimeError) as e:
                    return self._send(400, json.dumps({"error": str(e)}))
            if p.path == "/api/reload":
                latest = app.store.latest("base") or app.store.latest()
                if latest is not None:
                    app.latest = latest
                return self._send(200, dumps({"run_id": app.latest["summary"]["run_id"]}))
            return super().do_POST()

        def _events(self) -> dict:
            from .events_view import event_summary
            from .report import run_as_of
            run = app.latest or {}
            cs = [(r.get("country"), r.get("iso")) for r in run.get("country") or [] if isinstance(r, dict) and r.get("country")]
            ev = event_summary(data_dir, countries=cs or None, as_of=run_as_of(run), outputs_dir=out_dir)
            ev["files"] = [Path(f).name for f in ev.get("files") or []]          # names only: no local paths in the page
            ev["run_id"] = (run.get("summary") or {}).get("run_id")
            for r in ev["rows"]:
                r["top_types"] = "; ".join(f"{t} ({c:.0f})" if c is not None else str(t) for t, c in r.get("top_types") or [])
            return ev

        def _status(self) -> dict:
            def info(rel: str):
                f = out_dir / rel
                return {"exists": f.exists(), "modified": time.strftime("%Y-%m-%d %H:%M", time.localtime(f.stat().st_mtime))} if f.exists() else {"exists": False}
            live = data_dir / "live"
            return {"run": info("run_latest.json"), "stress": info("stress.json"), "backtest": info("backtest.json"),
                    "garch": info("garch/series.csv"), "econ": info("econometrics/workflow.csv"),
                    "prices": info("../data/market_history/prices.csv"), "audit": info("../data/audit_trail.csv"), "hazard_fit": info("hazard_fit.json"), "ideas": info("idea_log.csv"), "hazard_panel": info("../data/panel/hazard_panel.csv"),
                    "live": {"exists": live.exists(), "files": sorted(p.name for p in live.glob("*")) if live.exists() else []},
                    "run_id": app.latest["summary"]["run_id"], "data_dir": str(data_dir), "out_dir": str(out_dir)}

    return G


def gui(data_dir: str, out_dir: str, host: str = "127.0.0.1", port: int = 8765, open_browser: bool = True):
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    app = App(data_dir, str(out / "store"))
    jobs = Jobs(data_dir, out_dir)
    srv = ThreadingHTTPServer((host, port), make_gui_handler(app, jobs, out, Path(data_dir)))
    url = f"http://{host}:{port}/"
    print(f"EconQuest GUI at {url}  (Ctrl-C to stop)")
    if open_browser:
        threading.Timer(0.8, lambda: webbrowser.open(url)).start()
    try:
        srv.serve_forever()
    except KeyboardInterrupt:
        print("\nstopped")
