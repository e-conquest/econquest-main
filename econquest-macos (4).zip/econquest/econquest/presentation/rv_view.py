"""Relative-value views (EQ-C-0046, contract HO-20261023-B-C-014): Eurobond rich/cheap against the model-fair spread and
the CDS hazard curves, for the GUI Relative value tab (GET /api/rv), the RV section of country notes (HTML and Markdown)
and the opt-in workbook 'Weekly RV' tab (sheets_publish.rv_plan, `publish --rv`).

Formatting only: every number is Team B's (engine/bond_rv.py, engine/cds_curves.py), read from the run's outputs dir:
    outputs/bond_rv.csv            country x as_of   (fair_bp, market_bp, gap_bp = market - fair, + = cheap; z; rv_read)
    outputs/bond_rv_positions.csv  position x as_of  (the same columns at the position's duration, for_position)
    outputs/cds_curves.csv         iso3 x tenor x as_of (par spread, forward hazard, survival, cum PD, flags)
Files are read by column name (unknown extra columns are ignored, a missing optional column is blank). A missing file,
a zero-byte file or a header-only file is a clean state ("missing" / "empty"), never an error and never test data: this
module reads only the outputs dir it is given and has no fallback to any fixture. Rules applied here:
  * z is blank for a distressed row (spread RV does not apply), whatever the file holds;
  * a market_source containing "(SYNTHETIC)" and a curve with synthetic=True (or SYNTHETIC in source / licence) are
    marked SYNTHETIC, and the marker is shown wherever the row is shown;
  * curve flags (comma list) are kept per curve and shown next to it.
Units: bp for spreads, gaps and EL / premium; fractions (pd_12m, lgd, survival, cum_pd, fwd_pd, recovery) are shown as %;
hazards are per year (shown as % / yr); risk_premium_ratio is a multiple (x).
Status: diagnostic only (Team B, not wired into pipeline.py); no PD, VaR, ES, EL, trade or size reads these files.

    from econquest.presentation.rv_view import rv_summary
    s = rv_summary("outputs")   # {"rv": {...}, "positions": {...}, "curves": {...}, "as_of", "synthetic", "label"}
"""
from __future__ import annotations
import csv
import io
import math
from pathlib import Path

from .report import _e, _f, _pct, md_text

RV_FILE, POS_FILE, CURVES_FILE = "bond_rv.csv", "bond_rv_positions.csv", "cds_curves.csv"
LABEL = ("Diagnostic only (Team B EQ-B-0049 / EQ-B-0048, not yet wired into the run): model-fair Eurobond spread = PD x LGD x "
         "risk-premium ratio against the market spread. Gap = market - fair in bp (+ = cheap vs model, - = rich). "
         "No PD, VaR, ES, EL, trade or size reads it; decision support, not a trade instruction.")
SYN = "SYNTHETIC"
DISTRESSED_TAG = " <span class='tag stale'>DISTRESSED</span>"
SYN_NOTE = "SYNTHETIC: test or illustrative quotes, not market data. Do not read as a market level."

RV_COLS = ("as_of", "country", "iso3", "rating", "tenor_y", "pd_12m", "hazard_phys", "lgd", "risk_premium_ratio", "el_bp",
           "risk_premium_bp", "fair_bp", "market_bp", "market_source", "gap_bp", "z", "z_xs", "distressed", "rv_read")
POS_COLS = ("id", "asset_class", "direction", "notional_mm", "duration_yrs") + RV_COLS + ("for_position",)
CURVE_COLS = ("iso3", "as_of", "snapshot_id", "recovery", "recovery_source", "currency", "doc_clause", "source", "licence",
              "synthetic", "tenor_y", "quote_type", "quote_value", "par_spread_bp", "hazard_fwd", "hazard_fwd_raw", "survival",
              "cum_pd", "fwd_pd", "reprice_error_bp", "flags")
TEXT = {"as_of", "country", "iso3", "rating", "market_source", "rv_read", "id", "asset_class", "direction", "for_position",
        "snapshot_id", "recovery_source", "currency", "doc_clause", "source", "licence", "quote_type", "flags"}
BOOL = {"distressed", "synthetic"}
REQUIRED = {RV_FILE: ("country", "fair_bp", "market_bp", "gap_bp"), POS_FILE: ("id", "fair_bp", "market_bp", "gap_bp"),
            CURVES_FILE: ("iso3", "tenor_y", "par_spread_bp")}
MESSAGES = {
    RV_FILE: {"missing": "No bond RV yet: outputs/bond_rv.csv is not written (Team B's bond_rv is not wired into the run yet).",
              "empty": "No bond RV rows: outputs/bond_rv.csv has no rows."},
    POS_FILE: {"missing": "No position RV yet: outputs/bond_rv_positions.csv is not written.",
               "empty": "No position RV rows: the book has no Eurobond or CDS position (outputs/bond_rv_positions.csv is empty)."},
    CURVES_FILE: {"missing": "No CDS curves: outputs/cds_curves.csv is not written (no CDS snapshot has been loaded).",
                  "empty": "No CDS curves: outputs/cds_curves.csv is empty until real CDS snapshots are loaded (EQ-A-0029)."},
}
# Workbook / table columns (also the 'Weekly RV' header order)
RV_SHEET_COLS = ("as_of", "country", "iso3", "rating", "tenor_y", "pd_12m", "lgd", "risk_premium_ratio", "el_bp", "risk_premium_bp",
                 "fair_bp", "market_bp", "gap_bp", "z", "z_xs", "distressed", "rv_read", "market_source")
RV_SHEET_HEADER = ["As of", "Country", "ISO3", "Rating", "Tenor (y)", "PD 12m (fraction)", "LGD (fraction)", "Risk-premium ratio (x)",
                   "EL (bp/yr)", "Risk premium (bp/yr)", "Fair spread (bp)", "Market spread (bp)", "Gap market - fair (bp, + = cheap)",
                   "z (blank if distressed)", "Cross-sectional z", "Distressed", "RV read", "Market source"]
CURVE_SHEET_COLS = ("iso3", "as_of", "snapshot_id", "tenor_y", "quote_type", "quote_value", "par_spread_bp", "hazard_fwd",
                    "hazard_fwd_raw", "survival", "cum_pd", "fwd_pd", "reprice_error_bp", "recovery", "recovery_source", "currency",
                    "doc_clause", "synthetic", "flags", "source", "licence")
CURVE_SHEET_HEADER = ["ISO3", "As of", "Snapshot", "Tenor (y)", "Quote type", "Quote value (bp or points)", "Par spread (bp)",
                      "Forward hazard (/yr, used)", "Forward hazard raw (/yr)", "Survival (fraction)", "Cumulative PD (fraction)",
                      "Forward PD (fraction)", "Reprice error (bp)", "Recovery (fraction)", "Recovery source", "Currency",
                      "Doc clause", "Synthetic", "Flags", "Source", "Licence"]


def _num(v):
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    return x if math.isfinite(x) else None


def _bool(v) -> bool:
    return str(v).strip().lower() in ("true", "1", "yes", "y", "t")


def _cell(col: str, v):
    if col in BOOL:
        return _bool(v)
    if col in TEXT:
        return "" if v is None else str(v)
    return _num(v)


def read_table(path: Path, cols: tuple[str, ...], required: tuple[str, ...]) -> tuple[str, list[dict], str | None]:
    """(status, rows, problem) for one outputs CSV read by column name. status: ok, empty (zero bytes or header only),
    missing (no file), invalid (unreadable or a required column absent; problem names it, never a local path)."""
    if not path.exists():
        return "missing", [], None
    try:
        text = path.read_text(encoding="utf-8-sig")
    except (OSError, UnicodeDecodeError) as e:
        return "invalid", [], f"{path.name} could not be read ({type(e).__name__})"
    if not text.strip():
        return "empty", [], None
    try:
        reader = csv.DictReader(io.StringIO(text))
        header = [h.strip() for h in (reader.fieldnames or [])]
        reader.fieldnames = header
        raw = [r for r in reader if any((v or "").strip() for k, v in r.items() if k is not None)]
    except csv.Error as e:
        return "invalid", [], f"{path.name} could not be parsed ({type(e).__name__})"
    miss = [c for c in required if c not in header]
    if miss:
        return "invalid", [], f"{path.name} lacks column(s) {', '.join(miss)}"
    rows = [{c: _cell(c, r.get(c)) for c in cols} for r in raw]
    return ("ok" if rows else "empty"), rows, None


def _rv_rows(rows: list[dict]) -> list[dict]:
    for r in rows:
        if r.get("distressed"):
            r["z"] = None                              # spread RV does not apply to a distressed name (contract)
        r["synthetic"] = SYN in str(r.get("market_source") or "").upper()
    return rows


def _curves(rows: list[dict]) -> list[dict]:
    """Curve points grouped by (iso3, snapshot_id, as_of), tenors ascending, flags merged per curve."""
    groups: dict[tuple, dict] = {}
    for r in rows:
        key = (r["iso3"], r["snapshot_id"], r["as_of"])
        g = groups.get(key)
        if g is None:
            g = groups[key] = {k: r.get(k) for k in ("iso3", "as_of", "snapshot_id", "recovery", "recovery_source", "currency",
                                                    "doc_clause", "source", "licence")}
            g.update(synthetic=False, flags=[], points=[])
        g["synthetic"] = g["synthetic"] or bool(r.get("synthetic")) or SYN in f"{r.get('source')} {r.get('licence')}".upper()
        for fl in str(r.get("flags") or "").split(","):
            fl = fl.strip()
            if fl and fl not in g["flags"]:
                g["flags"].append(fl)
        g["points"].append({k: r.get(k) for k in ("tenor_y", "quote_type", "quote_value", "par_spread_bp", "hazard_fwd", "hazard_fwd_raw",
                                                  "survival", "cum_pd", "fwd_pd", "reprice_error_bp")})
    out = list(groups.values())
    for g in out:
        g["points"].sort(key=lambda p: (p["tenor_y"] is None, p["tenor_y"] or 0))
        g["synthetic_note"] = SYN_NOTE if g["synthetic"] else ""
    return sorted(out, key=lambda g: (str(g["iso3"]), str(g["as_of"]), str(g["snapshot_id"])))


def _part(out: Path, name: str, cols: tuple[str, ...]) -> dict:
    status, rows, problem = read_table(out / name, cols, REQUIRED[name])
    msg = problem + ": rerun the producer (Team B)." if status == "invalid" else MESSAGES[name].get(status, f"{len(rows)} rows from outputs/{name}.")
    return {"status": status, "file": name, "message": msg, "rows": rows}


def rv_summary(out_dir: str | Path) -> dict:
    """The three RV views of <out_dir>. Text is returned raw: the GUI escapes it, the notes HTML- / Markdown-escape it and
    the workbook plan formula-escapes it (safe_cell)."""
    out = Path(out_dir)
    rv, pos, cur = _part(out, RV_FILE, RV_COLS), _part(out, POS_FILE, POS_COLS), _part(out, CURVES_FILE, CURVE_COLS)
    _rv_rows(rv["rows"]); _rv_rows(pos["rows"])
    cur["curves"] = _curves(cur["rows"])
    dates = sorted({r["as_of"] for r in rv["rows"] if r.get("as_of")})
    syn = any(r["synthetic"] for r in rv["rows"] + pos["rows"]) or any(c["synthetic"] for c in cur["curves"])
    counts = {}
    for r in rv["rows"]:
        k = "distressed" if r.get("distressed") else (r.get("rv_read") or "n/a")
        counts[k] = counts.get(k, 0) + 1
    return {"label": LABEL, "as_of": dates[-1] if dates else None, "as_of_dates": dates, "synthetic": syn,
            "synthetic_note": SYN_NOTE if syn else "", "reads": counts, "rv": rv, "positions": pos, "curves": cur,
            "flagged": [{"iso3": c["iso3"], "snapshot_id": c["snapshot_id"], "flags": c["flags"]} for c in cur["curves"] if c["flags"]]}


# ---------------------------------------------------------------- country-note section
def _country_rows(summary: dict, country: str, iso: str | None):
    def mine(r):
        return r.get("country") == country or (iso and r.get("iso3") == iso)
    rv = [r for r in summary["rv"]["rows"] if mine(r)]
    pos = [r for r in summary["positions"]["rows"] if mine(r)]
    cur = [c for c in summary["curves"].get("curves") or [] if iso and c["iso3"] == iso]
    return rv, pos, cur


def _gap(v) -> str:
    x = _num(v)
    return "" if x is None else f"{x:+,.0f}"


def _syn_tag_html(on: bool) -> str:
    return " <span class='tag fire'>SYNTHETIC</span>" if on else ""


def country_rv_html(summary: dict, country: str, iso: str | None = None) -> str:
    """The RV section of a country note: the country's rich/cheap row, its book positions and its CDS curve. Every text
    from the files goes through _e (HTML-escaped)."""
    rv, pos, cur = _country_rows(summary, country, iso)
    h = f"<p class='note'>{_e(LABEL)}</p>"
    if rv:
        body = ""
        for r in rv:
            body += (f"<tr><td>{_e(r['as_of'])}</td><td>{_e(r['rating'])}</td><td class='n'>{_f(r['tenor_y'], 0)}</td><td class='n'>{_pct(r['pd_12m'])}</td>"
                     f"<td class='n'>{_pct(r['lgd'], 0)}</td><td class='n'>{_f(r['risk_premium_ratio'], 2)}x</td><td class='n'>{_f(r['fair_bp'], 0)}</td>"
                     f"<td class='n'>{_f(r['market_bp'], 0)}</td><td class='n'><b>{_gap(r['gap_bp'])}</b></td><td class='n'>{_f(r['z'], 2)}</td>"
                     f"<td class='n'>{_f(r['z_xs'], 2)}</td><td><b>{_e(r['rv_read'])}</b>{DISTRESSED_TAG if r['distressed'] else ''}</td>"
                     f"<td>{_e(r['market_source'])}{_syn_tag_html(r['synthetic'])}</td></tr>")
        h += ("<table class='compact'><tr><th>As of</th><th>Rating</th><th class='n'>Tenor y</th><th class='n'>PD 12m</th><th class='n'>LGD</th>"
              "<th class='n'>Risk-premium ratio</th><th class='n'>Fair bp</th><th class='n'>Market bp</th><th class='n'>Gap bp (+ cheap)</th>"
              f"<th class='n'>z</th><th class='n'>z cross-section</th><th>Read</th><th>Market source</th></tr>{body}</table>")
        if any(r["synthetic"] for r in rv):
            h += f"<p><span class='tag fire'>SYNTHETIC</span> {_e(SYN_NOTE)}</p>"
        if any(r["distressed"] for r in rv):
            h += "<p class='note'>Distressed: price / recovery trade, not spread RV; z is left blank.</p>"
    else:
        h += f"<p class='empty'>{_e(summary['rv']['message'] if summary['rv']['status'] != 'ok' else f'No bond RV row for {country} in outputs/bond_rv.csv.')}</p>"
    if pos:
        h += ("<h3>Book positions (RV at the position's duration)</h3><table class='compact'><tr><th>ID</th><th>Asset</th><th>Side</th>"
              "<th class='n'>Notional $mm</th><th class='n'>Duration y</th><th class='n'>Fair bp</th><th class='n'>Market bp</th><th class='n'>Gap bp</th>"
              "<th class='n'>z</th><th>For the position</th></tr>" + "".join(
                  f"<tr><td>{_e(p['id'])}</td><td>{_e(p['asset_class'])}</td><td>{_e(p['direction'])}</td><td class='n'>{_f(p['notional_mm'], 1)}</td>"
                  f"<td class='n'>{_f(p['duration_yrs'], 1)}</td><td class='n'>{_f(p['fair_bp'], 0)}</td><td class='n'>{_f(p['market_bp'], 0)}</td>"
                  f"<td class='n'>{_gap(p['gap_bp'])}</td><td class='n'>{_f(p['z'], 2)}</td><td>{_e(p['for_position'])}{_syn_tag_html(p['synthetic'])}</td></tr>" for p in pos)
              + "</table>")
    if cur:
        for c in cur:
            pts = "".join(f"<tr><td class='n'>{_f(p['tenor_y'], 1)}</td><td class='n'>{_f(p['par_spread_bp'], 0)}</td><td class='n'>{_pct(p['hazard_fwd'])}</td>"
                          f"<td class='n'>{_pct(p['survival'], 1)}</td><td class='n'>{_pct(p['cum_pd'], 1)}</td><td class='n'>{_f(p['reprice_error_bp'], 1)}</td></tr>" for p in c["points"])
            flags = ", ".join(c["flags"])
            h += (f"<h3>CDS curve {_e(c['snapshot_id'])} as of {_e(c['as_of'])}{_syn_tag_html(c['synthetic'])}</h3>"
                  + (f"<p><span class='tag stale'>FLAGS</span> {_e(flags)}</p>" if flags else "<p class='note'>No curve flags.</p>")
                  + "<table class='compact'><tr><th class='n'>Tenor y</th><th class='n'>Par spread bp</th><th class='n'>Forward hazard %/yr</th>"
                  f"<th class='n'>Survival</th><th class='n'>Cumulative PD</th><th class='n'>Reprice error bp</th></tr>{pts}</table>"
                  f"<p class='note'>Source: {_e(c['source'])} (licence {_e(c['licence'])}); recovery {_pct(c['recovery'], 0)} ({_e(c['recovery_source'])}).</p>"
                  + (f"<p><span class='tag fire'>SYNTHETIC</span> {_e(SYN_NOTE)}</p>" if c["synthetic"] else ""))
    else:
        cs = summary["curves"]
        h += f"<p class='empty'>{_e(cs['message'] if cs['status'] != 'ok' else 'No CDS curves for this country in outputs/cds_curves.csv.')}</p>"
    return h


def country_rv_md(summary: dict, country: str, iso: str | None = None) -> list[str]:
    """Markdown lines of the same section; every text from the files goes through md_text."""
    rv, pos, cur = _country_rows(summary, country, iso)
    L = ["## Relative value", "", md_text(LABEL), ""]
    if rv:
        L += ["| As of | Rating | Fair bp | Market bp | Gap bp (+ cheap) | z | Read | Market source |", "|---|---|---:|---:|---:|---:|---|---|"]
        L += [f"| {md_text(r['as_of'])} | {md_text(r['rating'])} | {_f(r['fair_bp'], 0)} | {_f(r['market_bp'], 0)} | {_gap(r['gap_bp'])} | {_f(r['z'], 2)} | "
              f"{md_text(r['rv_read'])}{' (DISTRESSED)' if r['distressed'] else ''} | {md_text(r['market_source'])}{' **SYNTHETIC**' if r['synthetic'] else ''} |" for r in rv]
        if any(r["synthetic"] for r in rv):
            L += ["", f"**{md_text(SYN_NOTE)}**"]
    else:
        L += [md_text(summary["rv"]["message"] if summary["rv"]["status"] != "ok" else f"No bond RV row for {country} in outputs/bond_rv.csv.")]
    for p in pos:
        L += ["", f"- Position {md_text(p['id'])} {md_text(p['asset_class'])} {md_text(p['direction'])} {_f(p['notional_mm'], 1)} $mm: gap {_gap(p['gap_bp'])} bp, "
                  f"{md_text(p['for_position'])}{' **SYNTHETIC**' if p['synthetic'] else ''}"]
    if cur:
        for c in cur:
            L += ["", f"CDS curve {md_text(c['snapshot_id'])} as of {md_text(c['as_of'])}{' **SYNTHETIC**' if c['synthetic'] else ''}; "
                      f"flags: {md_text(', '.join(c['flags']) or 'none')}; source {md_text(c['source'])}.", "",
                  "| Tenor y | Par spread bp | Forward hazard %/yr | Cumulative PD |", "|---:|---:|---:|---:|"]
            L += [f"| {_f(p['tenor_y'], 1)} | {_f(p['par_spread_bp'], 0)} | {_pct(p['hazard_fwd'])} | {_pct(p['cum_pd'], 1)} |" for p in c["points"]]
    else:
        cs = summary["curves"]
        L += ["", md_text(cs["message"] if cs["status"] != "ok" else "No CDS curves for this country in outputs/cds_curves.csv.")]
    return L
