"""Editorial states for research products (EQ-C-0026): draft -> reviewed -> published, plus withdrawn and corrected.

Products: daily_report (report.py), weekly_monitor (risk_monitor.py), country_note, scenario_brief. Every action is one
row of `outputs/editorial/ledger.jsonl`, an append-only, hash-chained JSON-lines file: each row carries `seq`,
`prev_hash` (row_hash of the row before, GENESIS for the first) and `row_hash` (sha256 of the canonical JSON of the row
without row_hash). `verify_chain` recomputes the chain; an item's state is derived only by replaying the ledger.

- `register_draft` records the item id, the sha256 of each file, the run stamps (run_id, as_of, data_hash, run_hash),
  the author and the UTC time. Files stay where the generator wrote them; the ledger pins their hashes.
- `review` needs a reviewer other than the author (ledger.person_key: case, whitespace, NFKC, zero-width characters).
  Single-operator mode (Sam, 2026-10-23, as for the fetch ledger): a self-review is allowed only with
  `self_reviewed=True` and is recorded as reviewer = author, self_reviewed "yes". The files must still match the draft.
- `publish` takes only a reviewed item whose files are byte-identical to what was reviewed, and every HTML/Markdown/text
  file must carry report.DISCLAIMER. It copies them to `outputs/published/<kind>/<date>-<id>/` with a manifest.json,
  files chmod 0444 and the directory 0555. A published copy is immutable: an id publishes once; a change is a new item
  (`correct`).
- `correct` registers a new draft linked by `correction_of`; when the correction is published the original's state
  becomes "corrected" (its published copy stays as it was).
- `withdraw` never deletes: it adds a ledger row and a line to `outputs/published/WITHDRAWN.jsonl` (the published
  directories are read-only, so the registry sits beside them).
- `verify_published` checks the chain, every manifest against the ledger and every published file against the
  manifest, and the withdrawn registry against the ledger.

- `checklist` (EQ-C-0036) records the manual items of the compliance checklist (compliance.py): the author's conflicts
  of interest declaration, the reviewer's acknowledgement of each flagged use restriction, and the compliance sign-off
  (a person other than the author; a flagged self-sign is recorded as an exception). Automatic items (disclaimer,
  sources, Input caveats block) run at review, at sign-off and again at publish; publish refuses until every item passes
  and the manifest carries the completed checklist. A checklist row after a sign-off voids it (sign again).
  Items published before EQ-C-0036 carry no checklist and stay valid in verify_published.

Identity is self-asserted (honour system), as in the fetch and review ledgers."""
from __future__ import annotations

import contextlib
import datetime as dt
import hashlib
import json
import os
import shutil
import stat
import tempfile
from pathlib import Path

from ..ingestion.ledger import check_approval, clean_person, person_key
from . import compliance as C
from .report import DISCLAIMER, run_as_of, run_hash_of

try:                                    # POSIX only; elsewhere writes are unlocked
    import fcntl
except ImportError:                     # pragma: no cover
    fcntl = None

KINDS = ("daily_report", "weekly_monitor", "country_note", "scenario_brief")
STATES = ("draft", "reviewed", "published", "withdrawn", "corrected")
EVENTS = ("draft", "review", "checklist", "publish", "withdraw")
GENESIS = "0" * 64
META_KEYS = ("run_id", "as_of", "data_hash", "run_hash")
TEXT_SUFFIXES = (".html", ".htm", ".md", ".txt")       # files that must carry the disclaimer
FILE_MODE, DIR_MODE = 0o444, 0o555


class EditorialError(ValueError):
    """A refused editorial action (wrong state, four-eyes, changed file, republish, missing disclaimer)."""


# ---------------------------------------------------------------- paths, hashing, time
def editorial_dir(outputs_dir) -> Path:
    return Path(outputs_dir) / "editorial"


def ledger_path(outputs_dir) -> Path:
    return editorial_dir(outputs_dir) / "ledger.jsonl"


def published_root(outputs_dir) -> Path:
    return Path(outputs_dir) / "published"


def withdrawn_path(outputs_dir) -> Path:
    return published_root(outputs_dir) / "WITHDRAWN.jsonl"


def sha256_file(path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _canon(obj) -> str:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)


def _row_hash(row: dict) -> str:
    return hashlib.sha256(_canon({k: v for k, v in row.items() if k != "row_hash"}).encode("utf-8")).hexdigest()


def _ts(now: dt.datetime | None = None) -> str:
    now = now or dt.datetime.now(dt.timezone.utc)
    now = now.replace(tzinfo=dt.timezone.utc) if now.tzinfo is None else now.astimezone(dt.timezone.utc)
    return now.strftime("%Y-%m-%dT%H:%M:%S.%fZ")


# ---------------------------------------------------------------- ledger
@contextlib.contextmanager
def _locked(outputs_dir):
    """Exclusive lock over the whole read-validate-append of one action, so two sessions cannot both publish an id."""
    d = editorial_dir(outputs_dir); d.mkdir(parents=True, exist_ok=True)
    with open(d / ".lock", "a") as lf:
        if fcntl is not None:
            fcntl.flock(lf.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            if fcntl is not None:
                fcntl.flock(lf.fileno(), fcntl.LOCK_UN)


def read_ledger(outputs_dir) -> list[dict]:
    p = ledger_path(outputs_dir)
    if not p.exists():
        return []
    with open(p, encoding="utf-8") as f:
        return [json.loads(line) for line in f if line.strip()]


def verify_chain(outputs_dir) -> list[str]:
    """Problems with the hash chain (empty list when intact): unparseable line, seq gap, prev_hash or row_hash mismatch."""
    p = ledger_path(outputs_dir)
    if not p.exists():
        return []
    problems, prev, seq = [], GENESIS, 0
    with open(p, encoding="utf-8") as f:
        for n, line in enumerate(f, 1):
            if not line.strip():
                continue
            try:
                row = json.loads(line)
            except json.JSONDecodeError:
                problems.append(f"ledger line {n}: not valid JSON"); prev = None; continue
            seq += 1
            if row.get("seq") != seq:
                problems.append(f"ledger line {n}: seq {row.get('seq')} expected {seq}")
            if prev is not None and row.get("prev_hash") != prev:
                problems.append(f"ledger line {n}: prev_hash does not match the previous row")
            if row.get("row_hash") != _row_hash(row):
                problems.append(f"ledger line {n}: row_hash does not match the row (edited?)")
            prev = row.get("row_hash")
    return problems


def _append(outputs_dir, rows: list[dict], event: dict) -> dict:
    """Append one event (caller holds _locked and passes the rows it validated against). Refuses on a broken chain."""
    bad = verify_chain(outputs_dir)
    if bad:
        raise EditorialError("editorial ledger chain is broken, nothing appended: " + "; ".join(bad[:3]))
    row = {"seq": len(rows) + 1, "ts_utc": _ts(), **event, "prev_hash": rows[-1]["row_hash"] if rows else GENESIS}
    row["row_hash"] = _row_hash(row)
    with open(ledger_path(outputs_dir), "a", encoding="utf-8") as f:
        f.write(_canon(row) + "\n"); f.flush(); os.fsync(f.fileno())
    return row


# ---------------------------------------------------------------- state
def _items(rows: list[dict]) -> dict[str, dict]:
    """Replay the ledger into {item_id: item}."""
    items: dict[str, dict] = {}
    for r in rows:
        ev, iid = r.get("event"), r.get("item_id")
        if ev == "draft":
            items[iid] = {"item_id": iid, "kind": r["kind"], "state": "draft", "files": r["files"], "meta": r["meta"],
                          "author": r["author"], "drafted_utc": r["ts_utc"], "correction_of": r.get("correction_of"),
                          "reason": r.get("reason"), "corrected_by": None, "draft_row_hash": r["row_hash"], "checklist": {}}
            if r.get("correction_of") in items:
                items[r["correction_of"]]["corrected_by"] = iid
        elif iid in items:
            it = items[iid]
            if ev == "review":
                it.update(state="reviewed", reviewer=r["reviewer"], self_reviewed=r.get("self_reviewed", ""),
                          review_note=r.get("note", ""), reviewed_utc=r["ts_utc"], review_row_hash=r["row_hash"],
                          review_checks=r.get("compliance_checks"))
            elif ev == "checklist":
                _apply_checklist(it["checklist"], r)
            elif ev == "publish":
                it.update(state="published", publisher=r["publisher"], published_utc=r["ts_utc"],
                          published_dir=r["published_dir"], manifest_sha256=r["manifest_sha256"],
                          compliance_version=r.get("compliance_version"),
                          compliance_signoff_row_hash=r.get("compliance_signoff_row_hash"))
                orig = items.get(it.get("correction_of"))
                if orig and orig["state"] == "published":
                    orig["state"] = "corrected"
            elif ev == "withdraw":
                it.update(state="withdrawn", withdrawn_by=r["by"], withdrawn_utc=r["ts_utc"], withdraw_reason=r.get("reason", ""))
    return items


def _apply_checklist(cl: dict, r: dict) -> None:
    """Fold one checklist row into an item's checklist state."""
    if cl.get("signoff") and (r.get("conflicts") is not None or r.get("acknowledge")):
        cl["signoff"] = None; cl["signoff_voided"] = f"checklist row seq {r['seq']}"
    if r.get("conflicts") is not None:
        cl["conflicts"] = {"by": r["by"], "text": r["conflicts"], "has_conflicts": r.get("has_conflicts", False),
                           "ts_utc": r["ts_utc"], "row_hash": r["row_hash"]}
    for a in r.get("acknowledge") or []:
        cl.setdefault("acknowledged", {})[a["restriction"]] = {"by": r["by"], "refs": a.get("refs", ""),
                                                               "ts_utc": r["ts_utc"], "row_hash": r["row_hash"]}
    so = r.get("compliance_signoff")
    if so:
        cl["signoff"] = {**so, "ts_utc": r["ts_utc"], "row_hash": r["row_hash"]}; cl.pop("signoff_voided", None)


def get_item(outputs_dir, item_id: str) -> dict:
    it = _items(read_ledger(outputs_dir)).get(str(item_id))
    if it is None:
        raise EditorialError(f"no editorial item {item_id!r}")
    return it


def list_items(outputs_dir, state: str | None = None, kind: str | None = None) -> list[dict]:
    """Items in registration order, optionally filtered by state and kind."""
    if state is not None and state not in STATES:
        raise EditorialError(f"state must be one of {STATES}, got {state!r}")
    if kind is not None and kind not in KINDS:
        raise EditorialError(f"kind must be one of {KINDS}, got {kind!r}")
    return [i for i in _items(read_ledger(outputs_dir)).values()
            if (state is None or i["state"] == state) and (kind is None or i["kind"] == kind)]


# ---------------------------------------------------------------- helpers for callers (cli.py)
def meta_from_run(run) -> dict:
    """run_id / as_of / data_hash / run_hash from an archived run (Store.load / report.latest_run)."""
    if run is None:
        return {k: None for k in META_KEYS}
    s = run.get("summary", run) if isinstance(run, dict) else {}
    v = s.get("versions") or ((run.get("provenance") or {}).get("versions") if isinstance(run, dict) else None) or {}
    return {"run_id": s.get("run_id"), "as_of": run_as_of(run), "data_hash": v.get("data_hash"), "run_hash": run_hash_of(run)}


def files_from_result(res: dict) -> list[str]:
    """The dated product files in a generator's result dict: res['paths'] when given (list or dict), else html + md.
    latest*.html is a moving copy and is left out."""
    paths = res.get("paths")
    if isinstance(paths, dict):
        paths = list(paths.values())
    if not paths:
        paths = [res[k] for k in ("html", "md") if res.get(k)]
    return [str(p) for p in paths if not Path(p).name.startswith("latest")]


def meta_from_result(res: dict, run=None) -> dict:
    """Run stamps from a generator's result dict, filled in from `run` where the dict lacks them."""
    base = meta_from_run(run) if run is not None else {k: None for k in META_KEYS}
    return {k: res.get(k) if res.get(k) not in (None, "") else base[k] for k in META_KEYS}


# ---------------------------------------------------------------- actions
def _hash_files(files, outputs_dir=None) -> list[dict]:
    out, names = [], set()
    root = Path(outputs_dir).resolve() if outputs_dir is not None else None
    for f in files:
        p = Path(f).resolve()
        if not p.is_file():
            raise EditorialError(f"not a file: {f}")
        # Only products the generators wrote under outputs/ can be published (AGENT-09 review, SEC-C-003): a draft
        # must not pull in ~/.ssh/id_rsa or any other file and publish a copy. Symlinks are resolved first.
        if root is not None and (root not in p.parents or published_root(root).resolve() in p.parents
                                 or editorial_dir(root).resolve() in p.parents):
            raise EditorialError(f"{f}: only files under {root} (not published/ or editorial/) can be drafted")
        if p.name == "manifest.json":
            raise EditorialError(f"{f}: manifest.json is reserved for the published copy's manifest")
        if p.name in names:
            raise EditorialError(f"two files named {p.name}: published copies sit in one directory")
        names.add(p.name)
        out.append({"name": p.name, "path": str(p), "sha256": sha256_file(p), "bytes": p.stat().st_size})
    if not out:
        raise EditorialError("a draft needs at least one file")
    return out


def _current_mismatch(files: list[dict]) -> list[str]:
    bad = []
    for f in files:
        p = Path(f["path"])
        if not p.is_file():
            bad.append(f"{f['name']} (missing)")
        elif sha256_file(p) != f["sha256"]:
            bad.append(f"{f['name']} (changed)")
    return bad


def _new_id(rows: list[dict]) -> str:
    n = sum(1 for r in rows if r.get("event") == "draft") + 1
    return f"ed-{dt.datetime.now(dt.timezone.utc):%Y%m%d}-{n:04d}"


def _draft(outputs_dir, kind, files, meta, author, correction_of=None, reason=None) -> dict:
    if kind not in KINDS:
        raise EditorialError(f"kind must be one of {KINDS}, got {kind!r}")
    author = clean_person(author)
    if not person_key(author):
        raise EditorialError("author is required")
    meta = {k: (None if (meta or {}).get(k) in (None, "") else str(meta[k])) for k in META_KEYS}
    if not meta["run_id"]:
        raise EditorialError("meta must carry the run_id the product was built from")
    hashed = _hash_files(files, outputs_dir)
    with _locked(outputs_dir):
        rows = read_ledger(outputs_dir)
        iid = _new_id(rows)
        ev = {"event": "draft", "item_id": iid, "kind": kind, "files": hashed, "meta": meta, "author": author}
        if correction_of:
            ev.update(correction_of=correction_of, reason=reason or "")
        _append(outputs_dir, rows, ev)
        return _items(read_ledger(outputs_dir))[iid]


def register_draft(outputs_dir, kind: str, files, meta: dict, author: str) -> dict:
    """Record a draft: kind, file sha256s, run stamps (meta: run_id required, as_of, data_hash, run_hash), author, time."""
    return _draft(outputs_dir, kind, files, meta, author)


def _data_dir(outputs_dir, data_dir=None) -> Path:
    """The data folder whose input caveats apply: data_dir, else the sibling of outputs/ (repo layout data/, outputs/)."""
    return Path(data_dir) if data_dir is not None else Path(outputs_dir).resolve().parent / "data"


def _run_of(outputs_dir, meta: dict):
    """The archived run the item was built from (outputs/store/archive/<run_id>.json), or None. Read directly so that
    checking a product never creates a store."""
    rid = str((meta or {}).get("run_id") or "")
    if not rid or "/" in rid or "\\" in rid or rid.startswith("."):
        return None
    p = Path(outputs_dir) / "store" / "archive" / f"{rid}.json"
    try:
        return json.loads(p.read_text(encoding="utf-8")) if p.is_file() else None
    except (OSError, ValueError):
        return None


def _auto(outputs_dir, it: dict, data_dir=None) -> dict:
    return C.automatic_checks(it["files"], it["meta"], _data_dir(outputs_dir, data_dir), _run_of(outputs_dir, it["meta"]))


def _summary(auto: dict) -> dict:
    return {k: {"ok": v["ok"], "problems": v.get("problems", [])} for k, v in auto.items()}


def review(outputs_dir, item: str, reviewer: str, note: str = "", self_reviewed: bool = False, data_dir=None) -> dict:
    """Mark a draft reviewed. Reviewer must differ from the author (person_key) unless self_reviewed=True (single-operator
    mode, recorded). The files must still match the draft. The automatic compliance checks run and are recorded in the
    review row (compliance_checks); they do not block the review, publish enforces them."""
    with _locked(outputs_dir):
        rows = read_ledger(outputs_dir)
        it = _items(rows).get(item)
        if it is None:
            raise EditorialError(f"no editorial item {item!r}")
        if it["state"] != "draft":
            raise EditorialError(f"{item} is {it['state']}: only a draft can be reviewed")
        try:
            _, rev, flag = check_approval(it["author"], reviewer, self_reviewed)
        except ValueError as e:
            # EQ-C-0052 (U12): name the CLI flag, and "a reviewer", not "an reviewer"
            raise EditorialError(f"review of {item}: " + str(e).replace("an approver", "a reviewer").replace("approver", "reviewer")
                                 .replace("self_approved=True", "--self-reviewed").replace("self-approval", "self-review")) from None
        bad = _current_mismatch(it["files"])
        if bad:
            raise EditorialError(f"{item}: files differ from the draft ({', '.join(bad)}); register a new draft")
        checks = _summary(_auto(outputs_dir, it, data_dir))
        _append(outputs_dir, rows, {"event": "review", "item_id": item, "reviewer": rev, "self_reviewed": flag,
                                    "note": str(note or ""), "files": it["files"], "compliance_checks": checks})
        return _items(read_ledger(outputs_dir))[item]


def _has_disclaimer(path: Path) -> bool:
    return C.has_disclaimer(path.read_text(encoding="utf-8", errors="replace"))


def checklist(outputs_dir, item: str, by: str, conflicts: str | None = None, acknowledge=(),
              compliance_approve: bool | str = False, self_signed: bool = False, data_dir=None, exc_id=None) -> dict:
    """Record manual compliance checklist items for `item` as one ledger row (EQ-C-0036):
    - conflicts: the author's declaration, "no conflicts" or a text (by must be the author; draft or reviewed);
    - acknowledge: restriction codes (e.g. ["6.1", "6.2"]) flagged by the input caveats, acknowledged by the reviewer
      (by must be the reviewer of record; reviewed state);
    - compliance_approve: True (or a note) for the compliance sign-off, by a person other than the author, or the author
      with self_signed=True and exc_id "EXC-nnn" (docs/governance/issues-log.md, as `change approve --self-approved`)
      when data/compliance.json allows it (the default), recorded as an exception with the EXC id.
      The sign-off is refused until items 1 to 4 pass (automatic checks run now). Returns the item with "checklist_status"."""
    by = clean_person(by)
    if not person_key(by):
        raise EditorialError("checklist needs --by (who is recording it)")
    acknowledge = [acknowledge] if isinstance(acknowledge, str) else list(acknowledge or [])
    if conflicts is None and not acknowledge and not compliance_approve:
        raise EditorialError("checklist: nothing to record (give --conflicts, --acknowledge or --compliance-approve)")
    with _locked(outputs_dir):
        rows = read_ledger(outputs_dir)
        it = _items(rows).get(item)
        if it is None:
            raise EditorialError(f"no editorial item {item!r}")
        if it["state"] not in ("draft", "reviewed"):
            raise EditorialError(f"{item} is {it['state']}: the checklist is recorded before publish only")
        bad = _current_mismatch(it["files"])
        if bad:
            raise EditorialError(f"{item}: files differ from the draft ({', '.join(bad)}); register a new draft")
        ev: dict = {"event": "checklist", "item_id": item, "by": by, "draft_row_hash": it["draft_row_hash"]}
        tag = f"checklist of {item}"
        if conflicts is not None:
            text = " ".join(str(conflicts).split())
            if not text:
                raise EditorialError(f"{tag}: --conflicts needs \"no conflicts\" or a declaration text")
            if person_key(by) != person_key(it["author"]):
                raise EditorialError(f"{tag}: conflicts of interest are declared by the author ({it['author']}), not {by}")
            ev.update(conflicts=text, has_conflicts=not C.is_no_conflict(text))
        auto = None
        if acknowledge or compliance_approve:
            if it["state"] != "reviewed":
                raise EditorialError(f"{tag}: {item} is a draft; restrictions are acknowledged and signed off after review")
            auto = _auto(outputs_dir, it, data_dir)
        if acknowledge:
            if person_key(by) != person_key(it["reviewer"]):
                raise EditorialError(f"{tag}: restrictions are acknowledged by the reviewer ({it['reviewer']}), not {by}")
            if auto["caveats"].get("error"):
                raise EditorialError(f"{tag}: {auto['caveats']['error']}")
            flags = auto["caveats"]["flags"]
            allowed = set(flags["shown"]) | set(flags["ack"])
            acks = []
            for code in acknowledge:
                try:
                    c = C.normalise_restriction(code)
                except C.ComplianceError as e:
                    raise EditorialError(f"{tag}: {e}") from None
                if c not in allowed:
                    raise EditorialError(f"{tag}: restriction {c} is not flagged for this item (flagged: "
                                         f"{', '.join(sorted(allowed)) or 'none'})")
                if c not in [a["restriction"] for a in acks]:
                    acks.append({"restriction": c, "refs": flags["ack"].get(c, {}).get("refs", "")})
            ev["acknowledge"] = acks
        if compliance_approve:
            try:
                cfg = C.load_config(_data_dir(outputs_dir, data_dir), outputs_dir)
                approver, flag, exc = C.check_signoff(it["author"], by, cfg, self_signed, exc_id)
            except C.ComplianceError as e:
                raise EditorialError(f"{tag}: {e}") from None
            trial = {**it, "checklist": json.loads(json.dumps(it["checklist"]))}
            _apply_checklist(trial["checklist"], {**ev, "seq": len(rows) + 1, "ts_utc": "", "row_hash": "", "compliance_signoff": None})
            pre = C.evaluate(trial, auto, for_signoff=True)
            if not pre["complete"]:
                raise EditorialError(f"{tag}: compliance sign-off refused, the checklist is incomplete: " + "; ".join(pre["problems"]))
            ev["compliance_signoff"] = {
                "approver": approver, "self_signed": flag, "role": cfg["role"],
                "exception": (f"single-operator self-sign under {exc}: no independent " + cfg["role"]
                              + _exc_note(_data_dir(outputs_dir, data_dir), exc)) if flag else "",
                "exc_id": exc,
                "note": compliance_approve if isinstance(compliance_approve, str) else "",
                "config_source": cfg["source"], "config_sha256": cfg["sha256"], "config_status": cfg["status"],
                "config_change_id": cfg["change_id"], "checks": _summary(auto)}
        _append(outputs_dir, rows, ev)
        it = _items(read_ledger(outputs_dir))[item]
        it["checklist_status"] = C.evaluate(it, auto) if auto is not None else None
        return it


def _exc_note(data_dir, exc: str) -> str:
    """" [EXC-nnn not yet in issues-log.md]" when the issues log is there and lacks the id (as change approve notes)."""
    from ..ops.approvals import exc_logged
    return f" [{exc} not yet in issues-log.md]" if exc_logged(data_dir, exc) is False else ""


def checklist_status(outputs_dir, item: str, data_dir=None) -> dict:
    """The compliance checklist of `item` evaluated now (automatic checks rerun on its files): {"complete", "items",
    "problems", "version"}. For a published item this is the current view; the manifest holds the one at publish."""
    it = get_item(outputs_dir, item)
    return C.evaluate(it, _auto(outputs_dir, it, data_dir))


def publish(outputs_dir, item: str, publisher: str, data_dir=None) -> dict:
    """Publish a reviewed item whose files are unchanged since review and whose compliance checklist is complete
    (automatic checks rerun now): read-only copy plus manifest.json (with the checklist) under
    outputs/published/<kind>/<date>-<id>/. Refuses any other state (an id publishes once)."""
    publisher = clean_person(publisher)
    if not person_key(publisher):
        raise EditorialError("publisher is required")
    with _locked(outputs_dir):
        rows = read_ledger(outputs_dir)
        it = _items(rows).get(item)
        if it is None:
            raise EditorialError(f"no editorial item {item!r}")
        if any(r.get("event") == "publish" and r.get("item_id") == item for r in rows):
            raise EditorialError(f"{item} is already published: published copies are immutable; register a correction")
        if it["state"] != "reviewed":
            raise EditorialError(f"{item} is {it['state']}: only a reviewed item can be published")
        bad = _current_mismatch(it["files"])
        if bad:
            raise EditorialError(f"{item}: files changed since review ({', '.join(bad)}); register a new draft and review it")
        texts = [f for f in it["files"] if Path(f["name"]).suffix.lower() in TEXT_SUFFIXES]
        missing = [f["name"] for f in texts if not _has_disclaimer(Path(f["path"]))]
        if not texts or missing:
            raise EditorialError(f"{item}: the disclaimer (report.DISCLAIMER) is missing from "
                                 f"{', '.join(missing) if missing else 'every file (no HTML/Markdown/text file)'}")
        status = C.evaluate(it, _auto(outputs_dir, it, data_dir))
        if not status["complete"]:
            raise EditorialError(f"{item}: compliance checklist incomplete, not published ({len(status['problems'])} "
                                 "problem(s)): " + "; ".join(status["problems"]))
        signoff = status["items"]["compliance_signoff"]
        so_row = it["checklist"].get("signoff") or {}
        try:
            cfg_now = C.load_config(_data_dir(outputs_dir, data_dir), outputs_dir)
        except C.ComplianceError as e:
            raise EditorialError(f"{item}: {e}") from None
        if so_row.get("config_sha256") != cfg_now["sha256"]:      # SEC-C-004 R1: approver config changed since sign-off
            raise EditorialError(f"{item}: the compliance approver configuration ({cfg_now['source']}) changed since the "
                                 "sign-off; record the compliance sign-off again")
        date = (it["meta"].get("as_of") or "")[:10] or f"{dt.datetime.now(dt.timezone.utc):%Y-%m-%d}"
        kind_dir = published_root(outputs_dir) / it["kind"]; kind_dir.mkdir(parents=True, exist_ok=True)
        final = kind_dir / f"{date}-{item}"
        if final.exists():
            raise EditorialError(f"{final} already exists: refusing to overwrite a published copy")
        now = _ts()
        manifest = {"item_id": item, "kind": it["kind"], **it["meta"], "author": it["author"], "reviewer": it["reviewer"],
                    "self_reviewed": it.get("self_reviewed", ""), "review_note": it.get("review_note", ""), "publisher": publisher,
                    "drafted_utc": it["drafted_utc"], "reviewed_utc": it["reviewed_utc"], "published_utc": now,
                    "correction_of": it.get("correction_of"), "correction_reason": it.get("reason") if it.get("correction_of") else None,
                    "review_row_hash": it["review_row_hash"], "disclaimer": DISCLAIMER,
                    "compliance": {**status, "checked_utc": now, "review_checks": it.get("review_checks")},
                    "files": [{"name": f["name"], "sha256": f["sha256"], "bytes": f["bytes"],
                               "disclaimer_present": f in texts} for f in it["files"]]}
        tmp = Path(tempfile.mkdtemp(dir=kind_dir, prefix=f".{item}."))
        try:
            for f in it["files"]:
                shutil.copyfile(f["path"], tmp / f["name"])
                if sha256_file(tmp / f["name"]) != f["sha256"]:
                    raise EditorialError(f"{item}: {f['name']} changed while copying")
            (tmp / "manifest.json").write_text(json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")
            for p in tmp.iterdir():
                os.chmod(p, FILE_MODE)
            os.chmod(tmp, DIR_MODE)
            os.rename(tmp, final)
        except BaseException:
            _rmtree_ro(tmp)
            raise
        _append(outputs_dir, rows, {"event": "publish", "item_id": item, "publisher": publisher,
                                    "published_dir": str(final.relative_to(Path(outputs_dir))),
                                    "manifest_sha256": sha256_file(final / "manifest.json"),
                                    "compliance_version": status["version"], "compliance_signoff_row_hash": signoff["row_hash"]})
        return _items(read_ledger(outputs_dir))[item]


def _rmtree_ro(path: Path) -> None:
    """Remove an unfinished temporary copy (only ever called on publish's own temp dir)."""
    if not path.exists():
        return
    os.chmod(path, 0o700)                         # owner-only: just enough to delete it (bandit B103)
    for p in path.iterdir():
        os.chmod(p, 0o600)
    shutil.rmtree(path, ignore_errors=True)


def correct(outputs_dir, item: str, new_files, author: str, reason: str, meta: dict | None = None) -> dict:
    """New draft linked to `item` by correction_of (item must be published, corrected or withdrawn). meta defaults to the
    original's stamps; pass meta when the corrected files come from another run."""
    if not str(reason or "").strip():
        raise EditorialError("a correction needs a reason")
    it = get_item(outputs_dir, item)
    if it["state"] not in ("published", "corrected", "withdrawn"):
        raise EditorialError(f"{item} is {it['state']}: only a published item is corrected (edit the draft and register it again)")
    return _draft(outputs_dir, it["kind"], new_files, meta or it["meta"], author, correction_of=item, reason=str(reason).strip())


def withdraw(outputs_dir, item: str, by: str, reason: str) -> dict:
    """Mark a published (or corrected) item withdrawn: ledger row plus a line in outputs/published/WITHDRAWN.jsonl.
    The published copy is kept."""
    by = clean_person(by)
    if not person_key(by):
        raise EditorialError("withdraw needs --by")
    if not str(reason or "").strip():
        raise EditorialError("withdraw needs a reason")
    with _locked(outputs_dir):
        rows = read_ledger(outputs_dir)
        it = _items(rows).get(item)
        if it is None:
            raise EditorialError(f"no editorial item {item!r}")
        if it["state"] not in ("published", "corrected"):
            raise EditorialError(f"{item} is {it['state']}: only a published item can be withdrawn")
        row = _append(outputs_dir, rows, {"event": "withdraw", "item_id": item, "by": by, "reason": str(reason).strip()})
        entry = {"item_id": item, "kind": it["kind"], "published_dir": it["published_dir"], "by": by, "reason": row["reason"],
                 "withdrawn_utc": row["ts_utc"], "ledger_row_hash": row["row_hash"]}
        with open(withdrawn_path(outputs_dir), "a", encoding="utf-8") as f:
            f.write(_canon(entry) + "\n")
        return _items(read_ledger(outputs_dir))[item]


# ---------------------------------------------------------------- verification
def verify_published(outputs_dir) -> dict:
    """Check the ledger chain, each published manifest (sha256 vs the ledger, stamps vs the item), each published file
    (sha256 vs the manifest, no extra or missing files, read-only modes), directories with no publish row, and the
    withdrawn registry vs the ledger. Returns {"ok", "checked", "problems"}."""
    out = Path(outputs_dir)
    problems = verify_chain(out)
    rows = read_ledger(out) if not any("not valid JSON" in p for p in problems) else []
    items = _items(rows)
    pubs = [i for i in items.values() if i.get("published_dir")]
    known = set()
    for it in pubs:
        d = out / it["published_dir"]; known.add(d.resolve())
        tag = f"{it['item_id']} ({it['published_dir']})"
        mp = d / "manifest.json"
        if not mp.is_file():
            problems.append(f"{tag}: manifest.json missing"); continue
        if sha256_file(mp) != it["manifest_sha256"]:
            problems.append(f"{tag}: manifest.json differs from the one recorded at publish")
        try:
            man = json.loads(mp.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            problems.append(f"{tag}: manifest.json is not valid JSON"); continue
        for k in ("item_id", "kind", "author", "reviewer", "publisher", *META_KEYS):
            want = it["meta"].get(k) if k in META_KEYS else it.get(k)
            if man.get(k) != want:
                problems.append(f"{tag}: manifest {k} {man.get(k)!r} != ledger {want!r}")
        if [f["sha256"] for f in man.get("files", [])] != [f["sha256"] for f in it["files"]]:
            problems.append(f"{tag}: manifest file hashes differ from the reviewed draft")
        if man.get("disclaimer") != DISCLAIMER:
            problems.append(f"{tag}: manifest disclaimer differs from report.DISCLAIMER (changed since publish?)")
        if it.get("compliance_version"):              # published under EQ-C-0036; earlier items carry no checklist
            comp = man.get("compliance") if isinstance(man.get("compliance"), dict) else {}
            so = (comp.get("items") or {}).get("compliance_signoff") or {}
            led = (it.get("checklist") or {}).get("signoff") or {}
            if not comp.get("complete"):
                problems.append(f"{tag}: manifest compliance checklist missing or incomplete")
            elif not (so.get("row_hash") == it.get("compliance_signoff_row_hash") == led.get("row_hash")):
                problems.append(f"{tag}: manifest compliance sign-off does not match the ledger")
        names = {f["name"] for f in man.get("files", [])}
        on_disk = {p.name for p in d.iterdir()} - {"manifest.json"}
        for extra in sorted(on_disk - names):
            problems.append(f"{tag}: unexpected file {extra}")
        for f in man.get("files", []):
            p = d / f["name"]
            if not p.is_file():
                problems.append(f"{tag}: {f['name']} missing")
            elif sha256_file(p) != f["sha256"]:
                problems.append(f"{tag}: {f['name']} sha256 differs from the manifest (tampered)")
            elif stat.S_IMODE(p.stat().st_mode) & 0o222:
                problems.append(f"{tag}: {f['name']} is writable (expected 0444)")
        if stat.S_IMODE(d.stat().st_mode) & 0o222:
            problems.append(f"{tag}: directory is writable (expected 0555)")
    root = published_root(out)
    if root.is_dir():
        for kd in root.iterdir():
            if kd.is_dir():
                for d in kd.iterdir():
                    if d.is_dir() and not d.name.startswith(".") and d.resolve() not in known:
                        problems.append(f"{d.relative_to(out)}: published directory with no publish row in the ledger")
    w_ledger = {r["row_hash"]: r["item_id"] for r in rows if r.get("event") == "withdraw"}
    w_reg = {}
    wp = withdrawn_path(out)
    if wp.exists():
        for n, line in enumerate(wp.read_text(encoding="utf-8").splitlines(), 1):
            if line.strip():
                try:
                    e = json.loads(line); w_reg[e.get("ledger_row_hash")] = e.get("item_id")
                except json.JSONDecodeError:
                    problems.append(f"WITHDRAWN.jsonl line {n}: not valid JSON")
    for h, iid in w_ledger.items():
        if w_reg.get(h) != iid:
            problems.append(f"{iid}: withdrawn in the ledger but missing from WITHDRAWN.jsonl")
    for h, iid in w_reg.items():
        if w_ledger.get(h) != iid:
            problems.append(f"{iid}: listed in WITHDRAWN.jsonl with no matching ledger row")
    return {"ok": not problems, "checked": len(pubs), "problems": problems}
