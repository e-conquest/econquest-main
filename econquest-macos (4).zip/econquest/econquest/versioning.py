"""Run versioning: fingerprints of the code and of every data file, stored with each run so that any run can be
reproduced from the same code and data vintages (roadmap item 2.5).

`data_files(data_dir)` is the one list of inputs that `data_hash` covers: the fixed files in `DATA_FILES` plus every
file matched by `DATA_GLOBS` (the default-episode and hazard panels, the current live pull and its raw feeds),
minus `DATA_EXCLUDE`. Archives (`live/vintages/`) and files the engine writes but never reads back as inputs
(`forecast_record.csv`, `benchmarks.csv`, `audit_trail.csv`, `live/diff_vs_seed.csv`) are left out, so recording a
run does not by itself change the data hash. Globs are one level deep: `live/*.csv` never reaches the archives
`live/vintages/` or `live/snapshots/`, so a replayed run's data_hash equals the original run's (HO-20261023-A-C-006).

`stamp(data_dir, as_of=None)` also records the run's as-of date and a `run_hash` over (code_hash, data_hash, as_of):
two runs with the same run_hash saw the same code, the same inputs and the same as-of date (EQ-C-0011). A replayed
run (`stamp(..., replay=u.provenance["replay"])` or `with_replay`) also records and hashes vintage_id and inputs_hash."""
from __future__ import annotations

import hashlib
import platform
from functools import lru_cache
from pathlib import Path

from . import __version__

PACKAGE_ROOT = Path(__file__).resolve().parent
DATA_FILES = ("assumptions.json", "countries.csv", "indicators.csv", "rulebook.csv", "adjustments.csv", "portfolio.csv",
              "prediction_markets.csv", "gpr_monthly.csv", "playbook.csv", "backtest_history.csv", "market_history/prices.csv", "limits.json", "scenarios.json",
              "cds_quotes.csv", "dsa_inputs.csv")
DATA_GLOBS = ("panel/*.csv", "live/*.csv", "live/*.json")
DATA_EXCLUDE = frozenset({"live/diff_vs_seed.csv",        # written by `fetch` for review, never read by a run
                          "replay_manifest.json"})          # written by replay.materialize_vintage into a replay dir


def file_hash(path: Path, n: int = 16) -> str | None:
    p = Path(path)
    if not p.is_file():
        return None
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()[:n]


@lru_cache(maxsize=1)
def code_hash(n: int = 16) -> str:
    """SHA-256 over every .py and static file in the package, in path order."""
    h = hashlib.sha256()
    for p in sorted(PACKAGE_ROOT.rglob("*")):
        if p.is_file() and p.suffix in (".py", ".html", ".js") and "__pycache__" not in p.parts:
            h.update(str(p.relative_to(PACKAGE_ROOT)).encode()); h.update(p.read_bytes())
    return h.hexdigest()[:n]


def data_files(data_dir: str | Path) -> list[str]:
    """Relative paths (POSIX, sorted) of every input file present under data_dir that the data hash covers."""
    d = Path(data_dir)
    rels = {rel for rel in DATA_FILES if (d / rel).is_file()}
    for pattern in DATA_GLOBS:
        rels.update(p.relative_to(d).as_posix() for p in d.glob(pattern) if p.is_file())
    return sorted(rels - DATA_EXCLUDE)


def data_hashes(data_dir: str | Path) -> dict[str, str]:
    d = Path(data_dir)
    out = {}
    for rel in data_files(d):
        hv = file_hash(d / rel)
        if hv:
            out[rel] = hv
    return out


def _combine(files: dict[str, str], n: int = 16) -> str:
    h = hashlib.sha256()
    for k, v in sorted(files.items()):
        h.update(f"{k}={v};".encode())
    return h.hexdigest()[:n]


def data_hash(data_dir: str | Path, n: int = 16) -> str:
    """One hash over all data-file hashes: two runs with the same data_hash saw the same inputs."""
    return _combine(data_hashes(data_dir), n)


def _as_of_str(as_of) -> str | None:
    if as_of is None or as_of == "":
        return None
    if hasattr(as_of, "strftime"):                 # date, datetime, pandas Timestamp
        return as_of.strftime("%Y-%m-%d")
    return str(as_of)


def run_hash(code_h: str, data_h: str, as_of=None, n: int = 16, vintage_id: str | None = None, inputs_hash: str | None = None) -> str:
    """SHA-256 over code hash, data hash and as-of date (ISO string; empty when the run has none). A replayed run
    (EQ-C-0015) also hashes its vintage_id and inputs_hash; without them the payload, and so the hash, is exactly the
    pre-replay one, so non-replay run hashes do not move."""
    payload = f"code={code_h};data={data_h};as_of={_as_of_str(as_of) or ''};"
    if vintage_id or inputs_hash:
        payload += f"vintage={vintage_id or ''};inputs={inputs_hash or ''};"
    return hashlib.sha256(payload.encode()).hexdigest()[:n]


def _rehash(v: dict) -> dict:
    v.setdefault("vintage_id", None); v.setdefault("inputs_hash", None)
    v["run_hash"] = run_hash(v.get("code_hash", ""), v.get("data_hash", ""), v.get("as_of"),
                             vintage_id=v.get("vintage_id"), inputs_hash=v.get("inputs_hash"))
    return v


def with_as_of(versions: dict, as_of=None) -> dict:
    """A copy of a `stamp()` dict with `as_of` and `run_hash` set for this as-of date. For callers that stamped the
    data before the run settings were known (`load_universe` stamps at load time; the pipeline knows settings.as_of).
    Replay fields already on the dict are kept and stay in the hash."""
    v = dict(versions or {})
    v["as_of"] = _as_of_str(as_of)
    return _rehash(v)


def with_replay(versions: dict, replay: dict | None = None) -> dict:
    """A copy of a `stamp()` dict carrying `vintage_id` and `inputs_hash` from `u.provenance["replay"]` (set by
    `load_universe(vintage=...)`), with `run_hash` recomputed. `replay=None` or `{}` leaves both None. Order with
    `with_as_of` does not matter."""
    v = dict(versions or {})
    r = replay or {}
    v["vintage_id"], v["inputs_hash"] = r.get("vintage_id"), r.get("inputs_hash")
    return _rehash(v)


def stamp(data_dir: str | Path, as_of=None, replay: dict | None = None) -> dict:
    """Everything needed to say which code, data, as-of date and (for a replay) frozen vintage produced a run."""
    import numpy
    import pandas
    import scipy
    files = data_hashes(data_dir)
    out = {"code_version": __version__, "code_hash": code_hash(), "data_hash": _combine(files), "data_files": files,
           "python": platform.python_version(), "numpy": numpy.__version__, "pandas": pandas.__version__, "scipy": scipy.__version__,
           "platform": platform.platform()}
    return with_replay(with_as_of(out, as_of), replay)
