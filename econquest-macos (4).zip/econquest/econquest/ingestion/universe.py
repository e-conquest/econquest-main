"""Universe expansion (epic A6, tickets EQ-A-0025 and EQ-A-0026): the proposed sovereign master list, its
validation, a per-country feed coverage report, an offline staging of candidate `countries.csv` / `indicators.csv`
for the new countries, and a missing-cell report after a fetch.

Nothing here touches the live input files. `expand_countries` writes only to a staging folder
(default `data/panel/universe_staging/`) and refuses a destination inside the live data folder's top level;
`stage_data_dir` builds a separate, complete data folder that `econquest --data <folder> fetch` can pull into on
Sam's Mac without changing `data/`.

The proposal (`data/panel/universe_proposal.csv`) is a draft for Sam's approval. Every field that was not taken
from `data/countries.csv` or an ISO standard is an analyst estimate written from memory and says so in `basis`.

Command line (no cli.py change needed):
    python -m econquest.ingestion.universe validate [--proposal P] [--data D]
    python -m econquest.ingestion.universe coverage [--proposal P] [--data D] [--out CSV]
    python -m econquest.ingestion.universe expand   [--proposal P] [--data D] [--out DIR]
    python -m econquest.ingestion.universe stage    --staging DIR --dest DIR [--data D]
    python -m econquest.ingestion.universe missing  --data DIR [--target 0.6] [--out CSV]
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import re
import shutil
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import pandas as pd

from .feeds import BIS_SOURCE_SERIES, WB_SOURCE_SERIES, WEO_SOURCE_SERIES
from .sources import read_csv_keep_na_code

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_DATA = ROOT / "data"
DEFAULT_PROPOSAL = DEFAULT_DATA / "panel" / "universe_proposal.csv"
DEFAULT_STAGING = DEFAULT_DATA / "panel" / "universe_staging"
LIVE_TARGET = 0.60                                     # epic A6: at least 60% of Inputs cells live

ESTIMATE_TAG = "analyst estimate (Claude, Oct 2026 knowledge), verify"
PROPOSAL_COLUMNS = ["iso3", "iso2", "name", "currency", "region", "income_group", "tier", "embi_member",
                    "frontier_index", "rating_bucket", "fx_regime", "yahoo_fx", "etf", "bis_iso2", "weo_available",
                    "notes", "basis"]
ENUMS = {
    "tier": {"desk_current", "EM", "frontier", "DM_anchor"},
    "embi_member": {"Y", "N", "unknown"},
    "rating_bucket": {"IG", "HY", "distressed", "NR", "unknown"},
    "fx_regime": {"hard peg", "soft peg", "floating", "free floating", "other", "unknown"},
    "weo_available": {"Y", "N"},
    "income_group": {"high", "upper-middle", "lower-middle", "low", "unknown"},
    "region": {"Asia", "LatAm", "Africa", "Europe", "Middle East", "North America"},
}
PATTERNS = {
    "iso3": re.compile(r"^[A-Z]{3}$"),
    "iso2": re.compile(r"^[A-Z]{2}$"),
    "currency": re.compile(r"^[A-Z]{3}$"),
    "yahoo_fx": re.compile(r"^([A-Z]{3}=X)?$"),
    "etf": re.compile(r"^([A-Z]{1,5})?$"),
    "bis_iso2": re.compile(r"^([A-Z]{2})?$"),
}
FORMULA_START = ("=", "+", "-", "@")                   # CSV/Sheets formula injection guard (AGENT-09 note on EQ-A-0016)
MIN_ROWS, MAX_ROWS = 70, 90

# desk vocabulary for countries.csv fxregime (engine: layer2 w_fx_regime_scale, stress fxregime_in, dsa fx vol)
DESK_FXREGIME = {"hard peg": "Peg", "soft peg": "Peg", "floating": "Float", "free floating": "Float", "other": "Managed"}

# indicator id -> feed and series that serve it (feeds.py transforms); 5.13 also needs WEO CPI
FEED_IDS = {"weo": set(WEO_SOURCE_SERIES), "worldbank": {k for k in WB_SOURCE_SERIES if re.match(r"^\d+\.\d+$", k)},
            "bis": set(BIS_SOURCE_SERIES)}
BIS_ID_SERIES = {"2.12": "EER_REAL_BROAD", "5.9": "CREDIT_GAP", "5.13": "POLICY_RATE"}
IDS_IDS = {"2.9", "2.10"}                              # IDS-based data (2.9 is fetched from WDI since EQ-A-0027): low- and middle-income economies only
MANUAL_API = re.compile(r"manual|analyst", re.I)

# Country Profile fields: filled by a feed vs entered by hand (countries.csv columns)
# EQ-A-0040: fx3m comes from the official FX feeds (BIS WS_XRU, ECB EXR), not Yahoo. The universe file's `yahoo_fx`
# column is kept as the record of which currencies were quoted, and a country is expected to get fx3m when it has a
# currency that is not USD and not in feeds.NO_FX_QUOTE (official_fx_plan decides at fetch time).
PROFILE_FEED = {"pop": "worldbank", "exports": "worldbank", "reserves": "worldbank", "fx3m": "fx", "policy": "bis"}
PROFILE_KEYS = {"country", "iso", "iso2", "currency", "region", "fxregime", "etf", "tier"}
PROFILE_TIER = "tier"                                  # HO-20261023-B-A-008: Country Profile tier, copied from the proposal


# ----------------------------------------------------------------------------------------------
# Load and validate
# ----------------------------------------------------------------------------------------------
def _read_str_csv(path: Path) -> pd.DataFrame:
    """Every cell as a string, empty for blank; 'NA' (Namibia's ISO2) stays 'NA'."""
    return pd.read_csv(path, dtype=str, keep_default_na=False, na_values=[])


def load_universe_proposal(path: str | Path = DEFAULT_PROPOSAL) -> pd.DataFrame:
    """Read the proposal CSV with every field as a stripped string (blank = '')."""
    df = _read_str_csv(Path(path))
    for c in df.columns:
        df[c] = df[c].str.strip()
    df.attrs["source"] = str(path)
    return df


def _desk(data_dir: str | Path | None) -> pd.DataFrame:
    return _read_str_csv(Path(data_dir or DEFAULT_DATA) / "countries.csv")


def validate_universe(df: pd.DataFrame, desk: pd.DataFrame | None = None, data_dir: str | Path | None = None,
                      min_rows: int = MIN_ROWS, max_rows: int = MAX_ROWS) -> list[str]:
    """Problems with a proposal (empty list = valid). `desk` is the current countries.csv (read from data_dir when
    None). Checks columns, row count, unique ISO3/ISO2/name, code formats, enumerations, formula-like cells, the
    basis tag on estimated rows, and that every current desk country is present as desk_current with the same
    iso2 and name (the name is the column key in indicators.csv), and, when countries.csv has a `tier` column, that
    it equals the proposal tier (validate_profile_tiers)."""
    problems: list[str] = []
    missing = [c for c in PROPOSAL_COLUMNS if c not in df.columns]
    if missing:
        return [f"missing columns: {missing}"]
    n = len(df)
    if n < min_rows or n > max_rows:
        problems.append(f"{n} rows; the A6 target is {min_rows}-{max_rows}")
    for c in ("iso3", "iso2", "name"):
        dup = df[c][df[c].duplicated(keep=False)]
        if len(dup):
            problems.append(f"duplicate {c}: {sorted(set(dup))}")
    for c, rx in PATTERNS.items():
        bad = df.loc[~df[c].fillna("").map(lambda v, rx=rx: bool(rx.match(v))), "iso3"]
        if len(bad):
            problems.append(f"bad {c} format for {list(bad)}")
    for c, allowed in ENUMS.items():
        bad = df.loc[~df[c].isin(allowed), ["iso3", c]]
        if len(bad):
            problems.append(f"{c} not in {sorted(allowed)}: {dict(zip(bad['iso3'], bad[c]))}")
    bis_mismatch = df[(df["bis_iso2"] != "") & (df["bis_iso2"] != df["iso2"])]
    if len(bis_mismatch):
        problems.append(f"bis_iso2 differs from iso2 for {list(bis_mismatch['iso3'])} (BIS uses ISO 3166 alpha-2)")
    for c in df.columns:
        bad = df.loc[df[c].fillna("").str.startswith(FORMULA_START), "iso3"]
        if len(bad):
            problems.append(f"{c} starts with a formula character for {list(bad)}")
    no_basis = df.loc[(df["tier"] != "desk_current") & ~df["basis"].str.contains(ESTIMATE_TAG, regex=False), "iso3"]
    if len(no_basis):
        problems.append(f"basis lacks '{ESTIMATE_TAG}' for {list(no_basis)}")
    desk = _desk(data_dir) if desk is None else desk
    prop = df.set_index("iso3")
    for r in desk.itertuples(index=False):
        if r.iso not in prop.index:
            problems.append(f"current desk country {r.country} ({r.iso}) missing")
            continue
        p = prop.loc[r.iso]
        if p["tier"] != "desk_current":
            problems.append(f"{r.iso} is a desk country but tier is {p['tier']}")
        if p["name"] != r.country:
            problems.append(f"{r.iso} name {p['name']!r} differs from countries.csv {r.country!r}")
        if p["iso2"] != getattr(r, "iso2", p["iso2"]):
            problems.append(f"{r.iso} iso2 {p['iso2']} differs from countries.csv {r.iso2}")
    extra = sorted(set(df.loc[df["tier"] == "desk_current", "iso3"]) - set(desk["iso"]))
    if extra:
        problems.append(f"tier desk_current but not in countries.csv: {extra}")
    if PROFILE_TIER in desk.columns:
        problems += validate_profile_tiers(desk, df)
    return problems


def validate_profile_tiers(countries: pd.DataFrame, proposal: pd.DataFrame) -> list[str]:
    """HO-20261023-B-A-008: a Country Profile (countries.csv frame, read with keep_default_na=False) must carry a
    `tier` column whose value equals the proposal's `tier` for the same ISO3 (`iso` -> `iso3`). Problems, empty when
    valid: a missing column, a blank or unknown tier, an ISO3 absent from the proposal, or a tier that differs."""
    if PROFILE_TIER not in countries.columns:
        return [f"Country Profile has no {PROFILE_TIER!r} column"]
    prop = dict(zip(proposal["iso3"].astype(str).str.strip(), proposal["tier"].astype(str).str.strip()))
    problems = []
    for iso, tier in zip(countries["iso"].astype(str).str.strip(), countries[PROFILE_TIER].fillna("").astype(str).str.strip()):
        if tier not in ENUMS["tier"]:
            problems.append(f"{iso} profile tier {tier!r} not in {sorted(ENUMS['tier'])}")
        elif iso not in prop:
            problems.append(f"{iso} is in the Country Profile but not in the proposal")
        elif prop[iso] != tier:
            problems.append(f"{iso} profile tier {tier} differs from proposal tier {prop[iso]}")
    return problems


# ----------------------------------------------------------------------------------------------
# Coverage report (what the current feeds can serve for each proposed country)
# ----------------------------------------------------------------------------------------------
def indicator_sources(data_dir: str | Path | None = None) -> pd.DataFrame:
    """One row per Inputs indicator id: source_class weo | worldbank | bis (feed-backed in feeds.py) | manual
    (rulebook api says Manual/analyst) | planned_api (an API is named but no feed is built), plus the api text."""
    d = Path(data_dir or DEFAULT_DATA)
    rb = pd.read_csv(d / "rulebook.csv", dtype={"id": str})
    rows = []
    for r in rb.itertuples(index=False):
        cls = next((f for f, ids in FEED_IDS.items() if r.id in ids), None)
        if cls is None:
            cls = "manual" if MANUAL_API.search(str(r.api)) else "planned_api"
        rows.append({"id": r.id, "pillar": str(r.pillar), "indicator": r.indicator, "source_class": cls, "api": r.api})
    return pd.DataFrame(rows)


def _observed(data_dir: Path) -> dict:
    """What the latest pull in data/live returned: Inputs keys with any live value, live cells per country name,
    and the ISO3s each BIS series returned. Empty sets when the files are absent."""
    live = data_dir / "live"
    out: dict = {"keys": None, "per_country": {}, "bis": {s: set() for s in BIS_ID_SERIES.values()}, "fx": set()}
    if (live / "provenance.csv").exists():
        p = pd.read_csv(live / "provenance.csv", dtype={"key": str})
        ind = p[p["table"] == "Inputs"]
        out["keys"] = set(ind["key"])
        out["per_country"] = ind.groupby("country").size().to_dict()
    if (live / "raw_bis.csv").exists():
        b = pd.read_csv(live / "raw_bis.csv", usecols=["iso", "series"])
        for s, g in b.groupby("series"):
            out["bis"][s] = set(g["iso"])
    # EQ-A-0040: the official FX rates are keyed by currency, so a country is "seen today" when the pull wrote its
    # fx3m cell (provenance), not when a ticker came back.
    if (live / "provenance.csv").exists():
        pv = pd.read_csv(live / "provenance.csv", dtype={"key": str})
        names = set(pv.loc[(pv["table"] == "Country Profile") & (pv["key"] == "fx3m"), "country"])
        cty = live.parent / "countries.csv"
        if names and cty.exists():
            c = read_csv_keep_na_code(cty, dtype=str)
            out["fx"] = set(c.loc[c["country"].isin(names), "iso"])
    return out


@dataclass
class CoverageReport:
    countries: pd.DataFrame              # one row per proposed country
    indicators: pd.DataFrame             # one row per indicator id with its source class
    summary: dict = field(default_factory=dict)


def coverage_report(df: pd.DataFrame, data_dir: str | Path | None = None, target: float = LIVE_TARGET) -> CoverageReport:
    """Per proposed country, which feeds can serve it with the mappings in the proposal, and the share of its
    Inputs cells (one per rulebook indicator) expected live.

    expected_live (conservative): WEO ids if weo_available=Y; World Bank ids for any ISO3 (IDS ids 2.9/2.10 not
    for high income); BIS ids only if bis_iso2 is set and data/live/raw_bis.csv shows that series for the
    country today (5.13 also needs WEO). Feed-backed ids that returned no value for any country in the latest
    pull (data/live/provenance.csv) are counted as `dead` and excluded. upper_bound_live counts BIS for every
    country with bis_iso2 and includes dead ids. The FX feeds serve the Country Profile field fx3m, not Inputs, and
    are reported separately: `yahoo_fx` is the universe file's record of which currencies are quoted at all (shared
    tickers EUR=X, XOF=X, XAF=X serve every country using them; summary["shared_yahoo_tickers"] lists them), and
    `fx3m_seen_today` says whether the latest pull wrote that country's fx3m from the official sources (EQ-A-0040).
    Countries without a quoted currency (dollarised, ZWL) are 'N'. equity_vol has no free official source since
    EQ-A-0040 and is served by no feed."""
    d = Path(data_dir or DEFAULT_DATA)
    src = indicator_sources(d)
    obs = _observed(d)
    ids_by = {c: set(src.loc[src["source_class"] == c, "id"]) for c in ("weo", "worldbank", "bis", "manual", "planned_api")}
    feed_ids = ids_by["weo"] | ids_by["worldbank"] | ids_by["bis"]
    dead = set() if obs["keys"] is None else feed_ids - obs["keys"]
    n_ind = len(src)
    ccy_counts = df.loc[df["yahoo_fx"] != "", "yahoo_fx"].value_counts()
    rows = []
    for r in df.itertuples(index=False):
        weo = r.weo_available == "Y"
        high = r.income_group == "high"
        weo_ids = ids_by["weo"] if weo else set()
        wb_ids = {i for i in ids_by["worldbank"] if not (high and i in IDS_IDS)}
        bis_conf, bis_poss = set(), set()
        if r.bis_iso2:
            for i in ids_by["bis"]:
                if i == "5.13" and not weo:
                    continue
                bis_poss.add(i)
                if r.iso3 in obs["bis"].get(BIS_ID_SERIES.get(i, ""), set()):
                    bis_conf.add(i)
        expected = (weo_ids | wb_ids | bis_conf) - dead
        upper = weo_ids | wb_ids | bis_poss
        yfx = "Y" if r.yahoo_fx else "N"
        rows.append({
            "iso3": r.iso3, "name": r.name, "tier": r.tier, "region": r.region,
            "weo": "Y" if weo else "N", "worldbank": "Y",
            "bis": "confirmed" if bis_conf else ("mapped, unconfirmed" if bis_poss else "N"),
            "yahoo_fx": yfx, "fx3m_seen_today": "Y" if r.iso3 in obs["fx"] else "N", "etf": "Y" if r.etf else "N",
            "n_indicators": n_ind, "expected_live": len(expected), "upper_bound_live": len(upper),
            "pct_expected": round(len(expected) / n_ind, 4), "pct_upper": round(len(upper) / n_ind, 4),
            "observed_live_today": obs["per_country"].get(r.name, np.nan) if r.tier == "desk_current" else np.nan,
            "stays_seed_or_manual": n_ind - len(expected),
            "manual": len(ids_by["manual"]), "planned_api": len(ids_by["planned_api"]), "dead_feed_ids": len(dead & upper),
        })
    cov = pd.DataFrame(rows)
    tot = n_ind * len(cov)
    summary = {
        "n_countries": len(cov), "n_indicators": n_ind,
        "pct_expected_overall": round(cov["expected_live"].sum() / tot, 4) if tot else 0.0,
        "pct_upper_overall": round(cov["upper_bound_live"].sum() / tot, 4) if tot else 0.0,
        "target": target, "cells_per_country_for_target": int(np.ceil(target * n_ind)),
        "feed_backed_ids": sorted(feed_ids, key=_idkey), "dead_feed_ids": sorted(dead, key=_idkey),
        "manual_ids": sorted(ids_by["manual"], key=_idkey), "planned_api_ids": sorted(ids_by["planned_api"], key=_idkey),
        "countries_meeting_target": int((cov["pct_expected"] >= target).sum()),
        "by_tier": cov.groupby("tier")["pct_expected"].mean().round(4).to_dict(),
        "shared_yahoo_tickers": sorted(ccy_counts[ccy_counts > 1].index),
    }
    return CoverageReport(cov, src, summary)


def _idkey(i: str):
    a, _, b = str(i).partition(".")
    return (int(a) if a.isdigit() else 0, int(b) if b.isdigit() else 0)


# ----------------------------------------------------------------------------------------------
# Part 2 (EQ-A-0026): staging of candidate input files, staged data folder, missing-cell report
# ----------------------------------------------------------------------------------------------
def _sha256(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _refuse_live(out: Path, data_dir: Path) -> None:
    out_r, d_r = out.resolve(), data_dir.resolve()
    if out_r == d_r or out_r == d_r / "live" or d_r / "live" in out_r.parents:
        raise ValueError(f"refusing to write staging files into the live data folder {out_r}; use e.g. {d_r / 'panel' / 'universe_staging'}")


def expand_countries(proposal: str | Path | pd.DataFrame = DEFAULT_PROPOSAL, data_dir: str | Path | None = None,
                     out_dir: str | Path | None = None, now: dt.datetime | None = None) -> dict:
    """Write candidate countries.csv and indicators.csv for the whole proposed universe into out_dir (default
    data/panel/universe_staging/). Current desk rows and columns are copied unchanged, plus a `tier` column (the
    proposal tier per ISO3, HO-20261023-B-A-008; desk rows desk_current) when the desk file has none; each new country gets a
    countries.csv row with iso, iso2, currency, region, etf and the desk fxregime (Peg/Float/Managed mapped from
    fx_regime; blank when unknown), and an indicators.csv column of blanks (NaN) that the live fetch fills.
    cells_to_fill.csv lists, for every new country, each Inputs and Country Profile cell and whether a feed is
    expected to fill it (awaiting_fetch) or it must be entered by hand (manual / planned_api).
    universe_meta.csv keeps the proposal columns; manifest.json records hashes and counts.
    Raises ValueError when the proposal fails validation or out_dir is the live data folder. Never writes
    data/countries.csv or data/indicators.csv."""
    d = Path(data_dir or DEFAULT_DATA)
    out = Path(out_dir or d / "panel" / "universe_staging")
    _refuse_live(out, d)
    if isinstance(proposal, pd.DataFrame):
        prop, prop_hash = proposal.copy(), hashlib.sha256(proposal.to_csv(index=False).encode()).hexdigest()
    else:
        prop, prop_hash = load_universe_proposal(proposal), _sha256(Path(proposal))
    desk = _desk(d)
    problems = validate_universe(prop, desk=desk)
    if problems:
        raise ValueError("proposal failed validation: " + "; ".join(problems))
    ind = _read_str_csv(d / "indicators.csv")
    new = prop[~prop["iso3"].isin(desk["iso"])]
    cov = coverage_report(prop, d)
    src = cov.indicators.set_index("id")
    dead = set(cov.summary["dead_feed_ids"])
    obs_bis = _observed(d)["bis"]

    # HO-20261023-B-A-008: the Country Profile carries the proposal tier (appended as the last column when the desk
    # file has none yet; desk rows are desk_current, which validate_universe has checked above)
    tier_of = dict(zip(prop["iso3"], prop["tier"]))
    desk_out = desk.copy()
    desk_out[PROFILE_TIER] = desk_out["iso"].map(tier_of)
    cols = list(desk_out.columns)
    rows = []
    for r in new.itertuples(index=False):
        row = {c: "" for c in cols}
        row.update(country=r.name, iso=r.iso3, iso2=r.iso2, currency=r.currency, region=r.region,
                   fxregime=DESK_FXREGIME.get(r.fx_regime, ""), etf=r.etf, tier=r.tier)
        rows.append(row)
        ind[r.name] = ""
    countries = pd.concat([desk_out, pd.DataFrame(rows, columns=cols)], ignore_index=True)
    tier_problems = validate_profile_tiers(countries, prop)
    if tier_problems:
        raise ValueError("staged Country Profile tier check failed: " + "; ".join(tier_problems))

    cells = []
    for r in new.itertuples(index=False):
        high = r.income_group == "high"
        for i in ind["id"]:
            cls = src.at[i, "source_class"] if i in src.index else "unknown"
            if cls in ("weo", "worldbank", "bis"):
                ok = (cls != "weo" or r.weo_available == "Y") and not (cls == "worldbank" and high and i in IDS_IDS) \
                     and (cls != "bis" or bool(r.bis_iso2)) and not (i == "5.13" and r.weo_available != "Y")
                status = "awaiting_fetch" if ok else "manual"
                note = ("feed returned no value for any desk country in the latest pull" if i in dead else
                        ("BIS coverage unconfirmed" if cls == "bis" and ok and r.iso3 not in obs_bis.get(BIS_ID_SERIES.get(i, ""), set()) else ""))
                if not ok:
                    note = f"{cls} cannot serve this country with the proposed mappings"
            else:
                status, note = cls, str(src.at[i, "api"]) if i in src.index else ""
            cells.append({"table": "Inputs", "key": i, "country": r.name, "iso3": r.iso3, "source_class": cls,
                          "status": status, "note": note})
        for k in cols:
            if k in PROFILE_KEYS:
                continue
            if k in PROFILE_FEED:
                f = PROFILE_FEED[k]
                ok = (f != "bis" or bool(r.bis_iso2)) and (f != "fx" or bool(r.yahoo_fx))
                status, cls = ("awaiting_fetch" if ok else "manual"), f
            else:
                status, cls = "manual", "hand-entered"
            cells.append({"table": "Country Profile", "key": k, "country": r.name, "iso3": r.iso3, "source_class": cls,
                          "status": status, "note": ""})
        if not DESK_FXREGIME.get(r.fx_regime):
            cells.append({"table": "Country Profile", "key": "fxregime", "country": r.name, "iso3": r.iso3,
                          "source_class": "hand-entered", "status": "manual", "note": "proposal fx_regime unknown"})
    cells = pd.DataFrame(cells, columns=["table", "key", "country", "iso3", "source_class", "status", "note"])
    # HO-20261023-B-A-007 item 3: an explicit zero adjustments.csv column for each new country (the engine falls back
    # to 0 without one; the explicit column is what analysts edit)
    adjustments = _read_str_csv(d / "adjustments.csv")
    for r in new.itertuples(index=False):
        if r.name not in adjustments.columns:
            adjustments[r.name] = "0.0"

    out.mkdir(parents=True, exist_ok=True)
    files = {"countries.csv": countries, "indicators.csv": ind, "adjustments.csv": adjustments, "cells_to_fill.csv": cells,
             "universe_meta.csv": prop, "coverage.csv": cov.countries}
    for name, frame in files.items():
        frame.to_csv(out / name, index=False)
    # HO-20261023-B-A-007 item 2: which cells block scoring, from the engine's own readiness check on the staged universe
    cells = mark_blocking(cells, staged_readiness(out, d))
    files["cells_to_fill.csv"] = cells
    cells.to_csv(out / "cells_to_fill.csv", index=False)
    now = now or dt.datetime.now(dt.timezone.utc)
    manifest = {
        "created_utc": now.strftime("%Y-%m-%dT%H:%M:%SZ"), "status": "candidate - not live; Sam approves before any copy to data/",
        "proposal_sha256": prop_hash, "desk_countries_sha256": _sha256(d / "countries.csv"),
        "desk_indicators_sha256": _sha256(d / "indicators.csv"),
        "n_desk": int(len(desk)), "n_new": int(len(new)), "n_total": int(len(countries)),
        "cells": cells.groupby(["table", "status"]).size().rename("n").reset_index().to_dict("records"),
        "cells_blocking": int(cells["blocking"].sum()),
        "coverage": {k: cov.summary[k] for k in ("pct_expected_overall", "pct_upper_overall", "target")},
        "files": {n: _sha256(out / n) for n in files},
    }
    (out / "manifest.json").write_text(json.dumps(manifest, indent=1))
    return {"out_dir": str(out), "n_desk": len(desk), "n_new": len(new), "n_total": len(countries),
            "cells_awaiting_fetch": int((cells["status"] == "awaiting_fetch").sum()), "cells_blocking": int(cells["blocking"].sum()),
            "cells_manual": int((cells["status"] != "awaiting_fetch").sum()), "coverage": cov.summary}


STAGED_FILES = ("countries.csv", "indicators.csv")            # required in the staging folder
STAGED_OPTIONAL = ("adjustments.csv",)                         # copied over data/'s when the staging folder has it


def _staged_universe_dir(staging_dir: Path, data_dir: Path, dest: Path) -> Path:
    """A minimal data folder for load_universe: data_dir's top-level files (no subfolders, so no live pull, history or
    vintages) with the staged files on top."""
    dest.mkdir(parents=True)
    for f in Path(data_dir).iterdir():
        if f.is_file():
            shutil.copyfile(f, dest / f.name)
    for f in STAGED_FILES + STAGED_OPTIONAL:
        if (Path(staging_dir) / f).exists():
            shutil.copyfile(Path(staging_dir) / f, dest / f)
    return dest


def staged_readiness(staging_dir: str | Path = DEFAULT_STAGING, data_dir: str | Path | None = None) -> pd.DataFrame:
    """`econquest.scorecard.check_readiness(u, settings).to_frame()` (country, field, kind, blocking) for the staged
    universe: load_universe on a temporary minimal data folder (`_staged_universe_dir`), settings from its
    assumptions.json. Reads only; the temporary folder is removed."""
    import tempfile
    from ..config import Settings
    from ..scorecard import check_readiness
    from .loaders import load_universe
    d = Path(data_dir or DEFAULT_DATA)
    with tempfile.TemporaryDirectory(prefix="econquest-staged-") as td:
        sd = _staged_universe_dir(Path(staging_dir), d, Path(td) / "data")
        u = load_universe(sd)
        settings = Settings.load(sd / "assumptions.json") if (sd / "assumptions.json").exists() else None
        return check_readiness(u, settings).to_frame()


def _readiness_target(fld: str) -> tuple[str, str]:
    """(table, key) of the cells_to_fill row a readiness field refers to: 'indicator 1.3' -> (Inputs, 1.3),
    'flag default' -> (Country Profile, default), 'rating (unknown ...)' -> (Country Profile, rating); pillars and
    adjustments have no cell row -> (Readiness, field)."""
    if fld.startswith("indicator "):
        return "Inputs", fld.split(" ", 1)[1]
    if fld.startswith(("pillar ", "adjustments")):
        return "Readiness", fld
    base = fld.split(" (")[0]
    return "Country Profile", base[5:] if base.startswith("flag ") else base


def mark_blocking(cells: pd.DataFrame, readiness: pd.DataFrame) -> pd.DataFrame:
    """cells_to_fill with a `blocking` column (True when check_readiness lists the cell as a blocking field for that
    country) and one extra row (table Readiness, status blocking) for each blocking field that has no cell row, such
    as 'pillar 3 (no scored indicator)'. Countries not in `cells` (the desk) only get rows when they block."""
    cells = cells.drop(columns=["blocking"], errors="ignore").copy()
    blk = readiness[readiness["blocking"].astype(bool)]
    want = {(r.country, *_readiness_target(r.field)): r.field for r in blk.itertuples(index=False)}
    keys = list(zip(cells["country"], cells["table"], cells["key"].astype(str)))
    cells["blocking"] = [k in want for k in keys]
    iso = dict(zip(cells["country"], cells["iso3"]))
    have = set(keys)
    extra = [{"table": t, "key": k, "country": c, "iso3": iso.get(c, ""), "source_class": "readiness", "status": "blocking",
              "note": f"scorecard.check_readiness: {fld}", "blocking": True}
             for (c, t, k), fld in want.items() if (c, t, k) not in have]
    if extra:
        cells = pd.concat([cells, pd.DataFrame(extra, columns=cells.columns)], ignore_index=True)
    return cells


def stage_data_dir(staging_dir: str | Path, dest: str | Path, data_dir: str | Path | None = None) -> Path:
    """Copy the data folder to `dest` (which must not exist and must lie outside data_dir) and replace its
    countries.csv and indicators.csv (and adjustments.csv when staged) with the staged candidates, so
    `econquest --data <dest> fetch` pulls the expanded universe without touching data/. Returns dest."""
    d, s, dst = Path(data_dir or DEFAULT_DATA).resolve(), Path(staging_dir), Path(dest).resolve()
    if dst == d or d in dst.parents:
        raise ValueError(f"dest {dst} must be outside the live data folder {d}")
    if dst.exists():
        raise FileExistsError(f"{dst} exists; choose a new folder")
    for f in STAGED_FILES:
        if not (s / f).exists():
            raise FileNotFoundError(f"{s / f} missing; run expand first")
    shutil.copytree(d, dst, ignore=shutil.ignore_patterns("universe_staging", "__pycache__"))
    for f in STAGED_FILES + tuple(f for f in STAGED_OPTIONAL if (s / f).exists()):
        shutil.copyfile(s / f, dst / f)
    return dst


@dataclass
class MissingCellReport:
    countries: pd.DataFrame              # one row per country: live, held, missing, pct_live, meets_target
    cells: pd.DataFrame                  # one row per Inputs cell that is not live, with the reason
    summary: dict = field(default_factory=dict)


def missing_cell_report(data_dir: str | Path, target: float = LIVE_TARGET) -> MissingCellReport:
    """After `econquest --data <data_dir> fetch`: per country, the Inputs cells the pull filled (finite in
    live/live_inputs.csv and not held in live/review.csv), the cells held by the gate, and the cells still missing
    with the reason (held | feed returned no value | manual | planned_api), with or without a seed value in
    indicators.csv. pct_live = live / indicators; meets_target compares with `target` (A6: 0.60)."""
    d = Path(data_dir)
    live_path = d / "live" / "live_inputs.csv"
    if not live_path.exists():
        raise FileNotFoundError(f"{live_path} missing: run `econquest --data {d} fetch` first")
    live = pd.read_csv(live_path, dtype=str, keep_default_na=False)       # ids as text: '2.10' must not become 2.1
    live = live.set_index(live.columns[0]).apply(pd.to_numeric, errors="coerce")
    ind = pd.read_csv(d / "indicators.csv", dtype={"id": str})
    names = [c for c in ind.columns if c not in ("id", "pillar", "indicator", "unit")]
    held = set()
    if (d / "live" / "review.csv").exists():
        rv = pd.read_csv(d / "live" / "review.csv", dtype={"key": str})
        held = {(str(r.key), r.country) for r in rv.itertuples(index=False) if r.table == "Inputs" and r.status == "hold"}
    src = indicator_sources(d).set_index("id")["source_class"].to_dict()
    seed = ind.set_index("id")
    rows, cells = [], []
    for n in names:
        n_live = n_held = 0
        for i in ind["id"]:
            v = live.at[i, n] if (i in live.index and n in live.columns) else np.nan
            if pd.notna(v) and (i, n) not in held:
                n_live += 1
                continue
            cls = src.get(i, "unknown")
            if pd.notna(v):
                n_held += 1; reason = "held by quality gate"
            elif cls in ("weo", "worldbank", "bis"):
                reason = f"{cls} returned no value"
            else:
                reason = cls
            s = pd.to_numeric(seed.at[i, n], errors="coerce") if n in seed.columns else np.nan
            cells.append({"key": i, "country": n, "source_class": cls, "reason": reason, "seed_present": "Y" if pd.notna(s) else "N"})
        n_ind = len(ind)
        rows.append({"country": n, "n_indicators": n_ind, "live": n_live, "held": n_held, "missing": n_ind - n_live,
                     "pct_live": round(n_live / n_ind, 4) if n_ind else 0.0, "meets_target": n_live / n_ind >= target if n_ind else False})
    cty = pd.DataFrame(rows)
    cells = pd.DataFrame(cells, columns=["key", "country", "source_class", "reason", "seed_present"])
    tot = int(cty["n_indicators"].sum())
    summary = {"n_countries": len(cty), "pct_live_overall": round(cty["live"].sum() / tot, 4) if tot else 0.0, "target": target,
               "countries_meeting_target": int(cty["meets_target"].sum()),
               "cells_without_any_value": int((cells["seed_present"] == "N").sum()),
               "by_reason": cells["reason"].value_counts().to_dict()}
    return MissingCellReport(cty, cells, summary)


# ----------------------------------------------------------------------------------------------
# Command line
# ----------------------------------------------------------------------------------------------
def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.universe", description=__doc__.split("\n\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("validate", "coverage", "expand"):
        p = sub.add_parser(name)
        p.add_argument("--proposal", default=str(DEFAULT_PROPOSAL))
        p.add_argument("--data", default=str(DEFAULT_DATA))
        if name in ("coverage", "expand"):
            p.add_argument("--out")
    p = sub.add_parser("stage"); p.add_argument("--staging", default=str(DEFAULT_STAGING)); p.add_argument("--dest", required=True)
    p.add_argument("--data", default=str(DEFAULT_DATA))
    p = sub.add_parser("missing"); p.add_argument("--data", required=True); p.add_argument("--target", type=float, default=LIVE_TARGET)
    p.add_argument("--out")
    a = ap.parse_args(argv)
    if a.cmd == "validate":
        prop = load_universe_proposal(a.proposal)
        problems = validate_universe(prop, data_dir=a.data)
        staged = Path(a.data) / "panel" / "universe_staging" / "countries.csv"
        if staged.exists():                            # HO-20261023-B-A-008: the staged profile tier matches too
            problems += [f"staging: {p}" for p in validate_profile_tiers(_read_str_csv(staged), prop)]
        print("\n".join(problems) if problems else f"ok: {a.proposal} is valid")
        return 1 if problems else 0
    if a.cmd == "coverage":
        rep = coverage_report(load_universe_proposal(a.proposal), a.data)
        print(rep.countries[["iso3", "tier", "bis", "yahoo_fx", "expected_live", "upper_bound_live", "pct_expected"]].to_string(index=False))
        print(json.dumps(rep.summary, indent=1, default=str))
        if a.out:
            rep.countries.to_csv(a.out, index=False)
        return 0
    if a.cmd == "expand":
        res = expand_countries(a.proposal, a.data, a.out)
        print(json.dumps(res, indent=1, default=str))
        return 0
    if a.cmd == "stage":
        print(f"staged data folder: {stage_data_dir(a.staging, a.dest, a.data)}")
        return 0
    rep = missing_cell_report(a.data, a.target)
    print(rep.countries.to_string(index=False))
    print(json.dumps(rep.summary, indent=1, default=str))
    if a.out:
        rep.cells.to_csv(a.out, index=False)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
