"""Review ledger (EQ-A-0006): analysts' decisions on quality-gate cells, kept apart from the gate output.

`data/live/review_ledger.csv` is append-only: `record_decision` opens it in append mode (under an exclusive lock on
POSIX) and never rewrites a row, so every decision keeps its author, approver and time. `data/live/review.csv` is
regenerated on every fetch by `write_review` as the fresh gate output joined with the latest ledger decision per cell,
so a new pull never loses a decision. `effective_holds` turns gate status plus decisions into the set of cells
`apply_report` must skip.

Four-eyes rule (roadmap 4.4): applying a cell the gate held needs an approver who is not the author. Single-operator
mode (Sam, 2026-10-23): a self-approval is allowed only when flagged with `self_approved=True`; the row then has
approver = author and `self_approved` = "yes", so the audit trail shows it as a governance exception.

An approval is bound to what was approved (SEC-A-001 M1): an 'apply' decision releases a gate hold only for the same
vintage or the same live value. hold and reject decisions stay in force across vintages.

Overriding a colleague (SEC-A-001 L3, HO-20261023-C-A-004): an 'apply' that follows a hold or reject by another person
needs the same approval as a gate-held cell (different approver, or flagged self-approval), whatever the gate says.
record_decision refuses it otherwise, and effective_holds keeps the cell held if such a row reaches the ledger anyway.

Every text column written to the ledger is neutralised against spreadsheet formula injection (SEC-A-001 L4).

Hand-entered cells (EQ-A-0018): data/adjustments.csv, data/cds_quotes.csv and data/prediction_markets.csv are typed by
analysts, not pulled. `attest_cells` records one ledger row per cell (table = file stem, decision 'apply', live = the
value, `content_sha256` of what was attested) under the four-eyes rule, and `unattested_cells` lists every cell whose
current content has no such attestation. Loading never blocks on an unattested cell: the audit trail reports it."""
from __future__ import annotations

import contextlib
import csv
import datetime as dt
import hashlib
import json
import math
import os
import tempfile
import unicodedata
from pathlib import Path

import pandas as pd

try:                                    # POSIX only; on other platforms appends are unlocked
    import fcntl
except ImportError:                     # pragma: no cover
    fcntl = None

LEDGER_COLUMNS = ["ts_utc", "vintage_id", "table", "key", "country", "gate_status", "live", "decision", "author", "approver",
                  "note", "self_approved", "content_sha256"]
DECISIONS = ("apply", "hold", "reject")
CELL = ["table", "key", "country"]
REVIEW_DECISION_COLUMNS = ["decision", "author", "approver", "self_approved", "decided_utc"]
LEGACY_AUTHOR = "unknown (imported from hand-edited review.csv)"
LIVE_REL_TOL, LIVE_ABS_TOL = 1e-6, 1e-9
# every text column is neutralised against spreadsheet formula injection (SEC-A-001 L4); ts_utc is ours, live numeric
_TEXT_FIELDS = ("vintage_id", "table", "key", "country", "gate_status", "decision", "author", "approver", "note",
                "self_approved")
_FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r")
_UNGUARD_FIELDS = ("vintage_id", "table", "key", "country")   # identifiers: guard apostrophe dropped on read for matching
# Small confusables map (SEC-A-001 L2): Cyrillic and Greek lowercase letters that look like Latin ones (applied after
# casefold). Deliberately small: a false match only makes the four-eyes check stricter.
_CONFUSABLES = str.maketrans({
    "а": "a", "в": "b", "е": "e", "ё": "e", "з": "3", "и": "u", "і": "i", "ї": "i", "ј": "j", "к": "k", "м": "m",
    "н": "h", "о": "o", "р": "p", "с": "c", "т": "t", "у": "y", "х": "x", "ѕ": "s", "һ": "h", "ԁ": "d", "ӏ": "l",
    "ԛ": "q", "ԝ": "w",
    "α": "a", "β": "b", "ε": "e", "η": "n", "ι": "i", "κ": "k", "μ": "m", "ν": "v", "ο": "o", "ρ": "p", "τ": "t",
    "υ": "u", "χ": "x", "ζ": "z", "ı": "i",
})


def ledger_path(data_dir: Path) -> Path:
    return Path(data_dir) / "live" / "review_ledger.csv"


def _ts(now: dt.datetime | None) -> str:
    now = now or dt.datetime.now(dt.timezone.utc)
    now = now.replace(tzinfo=dt.timezone.utc) if now.tzinfo is None else now.astimezone(dt.timezone.utc)
    return now.strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def clean_person(name) -> str:
    """A person's name as stored: NFKC-normalised, Unicode format characters (category Cf, e.g. zero-width space)
    removed, runs of whitespace collapsed to one space, surrounding whitespace stripped."""
    s = unicodedata.normalize("NFKC", "" if name is None else str(name))
    return " ".join("".join(ch for ch in s if unicodedata.category(ch) != "Cf").split())


def person_key(name) -> str:
    """Comparison key for author/approver: clean_person, every leading apostrophe dropped (formula guard or typed),
    casefolded, all whitespace removed, and common Cyrillic/Greek homoglyphs mapped to Latin (SEC-A-001 L2). So
    `'alice`, `a lice`, `ALICE` and Cyrillic `аlice` all compare equal to `alice`. Names stay self-asserted: this is a
    guard against accidental or lazy evasion, not authentication."""
    s = clean_person(name).lstrip("'").casefold()
    s = "".join(s.split()).translate(_CONFUSABLES)
    return "" if s == "nan" else s


def _is_number(v: str) -> bool:
    try:
        return math.isfinite(float(v))
    except ValueError:
        return False


def _neutralise(v):
    """Prefix text starting with = + - @ TAB or CR with an apostrophe so a spreadsheet opening the ledger treats it as
    text. A plain number such as '-1.5' is left alone (a spreadsheet does not evaluate it)."""
    if isinstance(v, str) and v[:1] in _FORMULA_PREFIXES and not _is_number(v):
        return "'" + v
    return v


def _unguard(v: str) -> str:
    """Inverse of _neutralise for identifier columns, so a neutralised key still matches the review frame."""
    return v[1:] if isinstance(v, str) and v[:1] == "'" and v[1:2] in _FORMULA_PREFIXES else v


def check_approval(author, approver=None, self_approved: bool = False) -> tuple[str, str, str]:
    """Validate an approval of a gate-held cell and return (author, approver, self_approved flag) as stored.
    Four-eyes: approver must be given and differ from author after normalisation. With self_approved=True the
    approver may be empty or equal to the author; it is then stored as the author and the flag is "yes". A distinct
    approver is an ordinary four-eyes approval even when self_approved=True (flag "")."""
    author, approver = clean_person(author), clean_person(approver)
    if not person_key(author):
        raise ValueError("author is required")
    if not person_key(approver) or person_key(approver) == person_key(author):
        if not self_approved:
            raise ValueError("needs an approver other than the author (four-eyes); pass self_approved=True for a "
                             "flagged single-operator self-approval")
        return author, author, "yes"
    return author, approver, ""


@contextlib.contextmanager
def locked_append(path: Path, fieldnames: list[str]):
    """Open `path` for append under an exclusive flock (POSIX) and yield (DictWriter, file, is_new). is_new is decided
    after the lock is taken, so two concurrent writers never both write a header."""
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "a", newline="") as f:
        if fcntl is not None:
            fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        try:
            f.seek(0, os.SEEK_END)
            new = f.tell() == 0
            yield csv.DictWriter(f, fieldnames=fieldnames, extrasaction="ignore"), f, new
            f.flush()
        finally:
            if fcntl is not None:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)


def _append(data_dir: Path, rows: list[dict]) -> None:
    """Append rows to the ledger (header first when the file is new). Existing bytes are never rewritten. A ledger
    written before the self_approved column existed keeps its old header; new rows carry the extra trailing field and
    read_ledger maps it."""
    with locked_append(ledger_path(data_dir), LEDGER_COLUMNS) as (w, f, new):
        if new:
            w.writeheader()
        for r in rows:
            w.writerow({c: _cell_out(c, r.get(c)) for c in LEDGER_COLUMNS})


def _cell_out(col: str, v):
    if v is None:
        return ""
    if col in _TEXT_FIELDS:
        return _neutralise(str(v))
    if col == "live" and isinstance(v, str) and not _is_number(v.strip() or "0"):
        return _neutralise(v)                    # live is numeric; text in it is guarded like any other text
    return v


def _standing_objection(rows) -> str:
    """Walk one cell's decisions in order and return the author of the hold/reject still in force, or ''.
    A hold/reject stands until its own author applies, or an approved apply (_approved) supersedes it. An unapproved
    apply by someone else leaves it standing (SEC-A-001 L3). A row may carry `objection_by` (from load_decisions):
    the objection standing before it."""
    standing = ""
    for d in rows:
        prior = str(getattr(d, "objection_by", "") or "").strip()
        if prior and prior != "nan":
            standing = prior
        dec = str(getattr(d, "decision", "") or "")
        if dec in ("hold", "reject"):
            standing = clean_person(getattr(d, "author", "")) or "unknown"
        elif dec == "apply":
            if not standing or person_key(standing) == person_key(getattr(d, "author", "")) or _approved(d):
                standing = ""
    return standing


def record_decision(data_dir: Path, table: str, key: str, country: str, decision: str, author: str, approver: str | None = None,
                    note: str = "", vintage_id: str = "", live=None, gate_status: str = "", now: dt.datetime | None = None,
                    self_approved: bool = False) -> dict:
    """Append one decision on one cell and return the row written. `decision` is apply, hold or reject; `author` is
    required. Applying a cell whose gate status is 'hold' needs an `approver` different from the author (four-eyes),
    otherwise ValueError, unless `self_approved=True` (single-operator mode: approver stored as the author,
    self_approved "yes"). Pass `vintage_id` and/or `live`: an apply releases a gate hold only for the same vintage or
    the same live value (effective_holds)."""
    decision = str(decision).strip().lower()
    if decision not in DECISIONS:
        raise ValueError(f"decision must be one of {DECISIONS}, got {decision!r}")
    author, approver = clean_person(author), clean_person(approver)
    if not person_key(author):
        raise ValueError("author is required")
    flag = ""
    objection = ""
    if decision == "apply":
        hist = read_ledger(data_dir)
        hist = hist[(hist["table"] == str(table)) & (hist["key"] == str(key)) & (hist["country"] == str(country))]
        objection = _standing_objection(hist.itertuples(index=False))
        if objection and person_key(objection) == person_key(author):
            objection = ""
    if decision == "apply" and (gate_status == "hold" or objection):
        why = "a held cell" if gate_status == "hold" else f"a cell {objection} put on hold or rejected"
        try:
            author, approver, flag = check_approval(author, approver, self_approved)
        except ValueError as e:
            raise ValueError(f"applying {why} ({table}, {key}, {country}) {e}") from None
    elif self_approved and (not person_key(approver) or person_key(approver) == person_key(author)):
        approver, flag = author, "yes"
    row = {"ts_utc": _ts(now), "vintage_id": vintage_id or "", "table": table, "key": str(key), "country": country,
           "gate_status": gate_status, "live": "" if live is None else live, "decision": decision, "author": author,
           "approver": approver, "note": note, "self_approved": flag}
    _append(data_dir, [row])
    return row


def read_ledger(data_dir: Path) -> pd.DataFrame:
    """Every ledger row, in the order written, with all LEDGER_COLUMNS as strings (self_approved is '' for rows
    written before that column existed)."""
    p = ledger_path(data_dir)
    if not p.exists() or p.stat().st_size == 0:
        return pd.DataFrame(columns=LEDGER_COLUMNS)
    with open(p, newline="") as f:
        rows = list(csv.reader(f))
    header, body = rows[0], [r for r in rows[1:] if r]
    out = []
    for r in body:
        names = LEDGER_COLUMNS if len(r) > len(header) and header == LEDGER_COLUMNS[:len(header)] else header
        rec = dict(zip(names, r))
        out.append({c: (_unguard(rec.get(c, "")) if c in _UNGUARD_FIELDS else rec.get(c, "")) for c in LEDGER_COLUMNS})
    return pd.DataFrame(out, columns=LEDGER_COLUMNS, dtype=str)


def load_decisions(data_dir: Path) -> pd.DataFrame:
    """The latest decision per (table, key, country): the last row written for that cell (all ledger columns,
    including vintage_id, live and self_approved), plus `objection_by`: the author of a colleague's hold/reject still
    standing before that row ('' if none), which effective_holds uses (SEC-A-001 L3)."""
    led = read_ledger(data_dir)
    if led.empty:
        return led.assign(objection_by=pd.Series(dtype=str))
    latest = led.drop_duplicates(CELL, keep="last")
    obj = {}
    for cell, g in led.groupby(CELL, sort=False):
        obj[cell] = _standing_objection(g.iloc[:-1].itertuples(index=False))
    latest = latest.assign(objection_by=[obj[(r.table, r.key, r.country)] for r in latest.itertuples(index=False)])
    return latest.reset_index(drop=True)


def normalise_decision(text) -> str:
    """Map a decision cell to apply, hold, reject or '' (free text from the hand-edited review.csv: 'applied ...' is
    apply, 'kept on hold ...' is hold)."""
    t = str(text if text is not None else "").strip().lower()
    if t in ("", "nan"):
        return ""
    if t.startswith("appl"):
        return "apply"
    if t.startswith("reject"):
        return "reject"
    if "hold" in t or "keep seed" in t:
        return "hold"
    return ""


def import_legacy_review(data_dir: Path, now: dt.datetime | None = None) -> int:
    """One-off: when the ledger does not exist yet, copy the free-text decisions in the current review.csv into it,
    with author LEGACY_AUTHOR, no approver and the original text as note (so a legacy 'apply' never clears a gate
    hold). Returns the number of rows imported; does nothing once the ledger exists.
    The gate never writes status 'ok' with a reason (a reason always makes the cell 'hold' or 'missing'), so such a row
    is a hold whose status was hand-edited to 'ok' when it was accepted on review (the 2026-10-23 review.csv has 72):
    it is imported with gate_status 'hold' and a note saying so, so the ledger keeps the gate's verdict (EQ-A-0044)."""
    rev_p = Path(data_dir) / "live" / "review.csv"
    if ledger_path(data_dir).exists() or not rev_p.exists():
        return 0
    old = pd.read_csv(rev_p, dtype=str, keep_default_na=False)
    if "decision" not in old.columns:
        return 0

    def gate_status(r) -> tuple[str, str]:
        st, reason = str(r.get("status", "")), str(r.get("reason", "") or "").strip()
        if st == "ok" and reason:
            return "hold", f"[gate held it ({reason}); review.csv status hand-edited to ok] "
        return st, ""

    rows = []
    for _, r in old.iterrows():
        if normalise_decision(r["decision"]):
            st, prefix = gate_status(r)
            rows.append({"ts_utc": _ts(now), "vintage_id": "", "table": r["table"], "key": r["key"], "country": r["country"],
                         "gate_status": st, "live": r.get("live", ""), "decision": normalise_decision(r["decision"]),
                         "author": LEGACY_AUTHOR, "approver": "", "note": prefix + r["decision"]})
    if rows:
        _append(data_dir, rows)
    return len(rows)


def write_review(data_dir: Path, review: pd.DataFrame, now: dt.datetime | None = None) -> pd.DataFrame:
    """Write data/live/review.csv as the fresh gate output joined with the latest ledger decision per cell (columns
    decision, author, approver, self_approved, decided_utc) and return it. Use this instead of `review.to_csv`. The
    ledger is only read (after a one-off import of legacy free-text decisions), so the gate never deletes a decision."""
    import_legacy_review(data_dir, now)
    dec = load_decisions(data_dir)[CELL + ["decision", "author", "approver", "self_approved", "ts_utc"]].rename(columns={"ts_utc": "decided_utc"})
    base = review.drop(columns=[c for c in REVIEW_DECISION_COLUMNS if c in review.columns]).copy()
    base["key"] = base["key"].astype(str)
    merged = base.merge(dec, on=CELL, how="left")
    merged[REVIEW_DECISION_COLUMNS] = merged[REVIEW_DECISION_COLUMNS].fillna("")
    p = Path(data_dir) / "live" / "review.csv"; p.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=p.parent, prefix=".review.csv.", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", newline="") as f:
            merged.to_csv(f, index=False)
        os.chmod(tmp, 0o644); os.replace(tmp, p)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise
    return merged


def decisions_from_review(review: pd.DataFrame | None) -> pd.DataFrame:
    """Decisions carried in a review frame's decision / author / approver columns (as written by write_review, or free
    text from the hand-edited review.csv), in the shape of load_decisions. For display only: apply_report reads
    decisions from the ledger, never from a review frame (SEC-A-001)."""
    if review is None or "decision" not in review.columns:
        return pd.DataFrame(columns=LEDGER_COLUMNS)
    d = review.copy()
    d["decision"] = d["decision"].map(normalise_decision)
    for c in ("author", "approver", "self_approved", "vintage_id", "live"):
        d[c] = d[c].fillna("").astype(str) if c in d.columns else ""
    d["key"] = d["key"].astype(str)
    return d[d["decision"] != ""][CELL + ["decision", "author", "approver", "self_approved", "vintage_id", "live"]].reset_index(drop=True)


def _num(v) -> float | None:
    try:
        x = float(str(v).strip().lstrip("'"))
    except (TypeError, ValueError):
        return None
    return x if math.isfinite(x) else None


def _bound(d, row, review_vintage: str | None) -> bool:
    """True when decision d was made on what the review row now shows: same vintage (both known) or same live value
    within LIVE_REL_TOL / LIVE_ABS_TOL."""
    a, b = _num(getattr(d, "live", None)), _num(getattr(row, "live", None))
    if a is not None and b is not None:          # a decision that names a value binds to that value (SEC-A-001 L1)
        return math.isclose(a, b, rel_tol=LIVE_REL_TOL, abs_tol=LIVE_ABS_TOL)
    dv = str(getattr(d, "vintage_id", "") or "").strip()
    rv = str(getattr(row, "vintage_id", "") or "").strip() or str(review_vintage or "").strip()
    return dv not in ("", "nan") and rv not in ("", "nan") and Path(dv).name == Path(rv).name


def _approved(d) -> bool:
    """An 'apply' with a four-eyes approver, or a flagged single-operator self-approval."""
    if d is None or str(d.decision) != "apply":
        return False
    author, approver = person_key(getattr(d, "author", "")), person_key(getattr(d, "approver", ""))
    if not author or not approver:
        return False
    return approver != author or str(getattr(d, "self_approved", "") or "").strip().lower() == "yes"


def effective_holds(review: pd.DataFrame | None, decisions: pd.DataFrame | None, vintage_id: str | None = None) -> set:
    """Cells (table, key, country) apply_report must not apply:
    - gate status 'hold', unless the latest decision is an approved 'apply' (four-eyes, or flagged self-approval)
      bound to this review: its vintage_id equals the review's vintage (row column `vintage_id`, else the
      `vintage_id` argument) or its `live` equals the review's live value (rel tol 1e-6, abs 1e-9);
    - any cell whose latest decision is 'hold' or 'reject', even when the gate passed it (sticky across vintages);
    - any cell where an apply by someone else follows a hold/reject without _approved (SEC-A-001 L3), gate ok or not.
    `decisions` is load_decisions (latest row per cell with objection_by) or the full ledger in written order."""
    latest, history = {}, {}
    if decisions is not None and len(decisions):
        for r in decisions.itertuples(index=False):
            cell = (r.table, str(r.key), r.country)
            latest[cell] = r
            history.setdefault(cell, []).append(r)
    out = set()
    if review is not None:
        for r in review.itertuples(index=False):
            cell = (r.table, str(r.key), r.country)
            if r.status == "hold":
                d = latest.get(cell)
                if not (_approved(d) and _bound(d, r, vintage_id)):
                    out.add(cell)
    out |= {cell for cell, d in latest.items() if d.decision in ("hold", "reject")}
    out |= {cell for cell, rows in history.items() if _standing_objection(rows)}
    return out


# ---- Hand-entered cells (EQ-A-0018) ----------------------------------------------------------------------------------
# file -> how a cell is identified. Wide files have one cell per (row, country column); long files one cell per row.
HAND_ENTERED = {
    "adjustments.csv": {"key": ("block", "pillar"), "fixed": ("block", "pillar", "item", "rule"), "wide": True,
                        "label": ("block", "item")},
    "cds_quotes.csv": {"key": ("date", "tenor_y"), "country": "country", "value": "spread_bp",
                       "label": ("date", "tenor_y", "source")},
    "prediction_markets.csv": {"key": ("id",), "country": "country", "value": "yes_price", "label": ("contract",)},
}
ATTEST_NOTE = "attested hand-entered cell"
ATTEST_COLUMNS = ["table", "key", "country", "label", "value", "content_sha256", "attested", "author", "approver",
                  "self_approved", "attested_utc"]


def _hand_file(file) -> str:
    name = str(file)
    name = name if name.endswith(".csv") else name + ".csv"
    if name not in HAND_ENTERED:                         # a bare file name only: never a path
        raise ValueError(f"not a hand-entered file: {file!r} (one of {sorted(HAND_ENTERED)})")
    return name


def hand_entered_cells(data_dir: Path, file) -> list[dict]:
    """The cells of one hand-entered file as dicts: table (file stem), key, country, label, value (raw text) and
    content_sha256 (SHA-256 over the file stem, key, country and the raw text of every field that defines the cell:
    the whole row for long files, the row's descriptive columns plus that country's value for wide ones)."""
    name = _hand_file(file)
    spec, p = HAND_ENTERED[name], Path(data_dir) / name
    if not p.exists():
        return []
    with open(p, newline="") as f:
        rd = csv.DictReader(f)
        cols, rows = list(rd.fieldnames or []), list(rd)
    stem = name[:-4]
    out = []

    def add(r, country, value, fields):
        key = "|".join(str(r.get(k, "") or "").strip() for k in spec["key"])
        blob = json.dumps({"file": stem, "key": key, "country": country, "fields": fields}, sort_keys=True,
                          ensure_ascii=False)
        out.append({"table": stem, "key": key, "country": country,
                    "label": " | ".join(str(r.get(k, "") or "").strip() for k in spec["label"] if r.get(k)),
                    "value": value, "content_sha256": hashlib.sha256(blob.encode()).hexdigest()})

    for r in rows:
        if spec.get("wide"):
            fixed = {c: r.get(c, "") for c in spec["fixed"]}
            for c in cols:
                if c not in spec["fixed"]:
                    add(r, c, r.get(c, "") or "", {**fixed, c: r.get(c, "") or ""})
        else:
            add(r, str(r.get(spec["country"], "") or "").strip(), r.get(spec["value"], "") or "",
                {c: r.get(c, "") or "" for c in cols})
    return out


def _attest_live(value: str):
    x = _num(value)
    return x if x is not None else value


def attest_cells(data_dir: Path, file, author: str, approver: str | None = None, self_approved: bool = False,
                 note: str = "", all_cells: bool = False, now: dt.datetime | None = None) -> list[dict]:
    """Record that `author` entered, and `approver` checked, the current content of a hand-entered file: one ledger row
    per cell (table = file stem, key, country, decision 'apply', live = value, content_sha256). Four-eyes as for gate
    holds: an approver other than the author, or `self_approved=True` (flagged 'yes'); ValueError before anything is
    written otherwise. By default only cells whose current content is not yet attested are written (`all_cells=True`
    re-attests every cell). Returns the rows written."""
    name = _hand_file(file)
    author, approver, flag = check_approval(author, approver, self_approved)
    cells = hand_entered_cells(data_dir, name)
    if not all_cells:
        todo = {(c["table"], c["key"], c["country"], c["content_sha256"]) for c in unattested_cells(data_dir, [name])}
        cells = [c for c in cells if (c["table"], c["key"], c["country"], c["content_sha256"]) in todo]
    ts = _ts(now)
    rows = [{"ts_utc": ts, "vintage_id": "", "table": c["table"], "key": c["key"], "country": c["country"],
             "gate_status": "", "live": _attest_live(c["value"]), "decision": "apply", "author": author,
             "approver": approver, "note": (note or ATTEST_NOTE), "self_approved": flag,
             "content_sha256": c["content_sha256"]} for c in cells]
    if rows:
        _append(data_dir, rows)
    return rows


def attestation_status(data_dir: Path, files=None) -> list[dict]:
    """Every cell of the hand-entered files (all of HAND_ENTERED by default) with its attestation: attested 'yes'
    when the ledger holds an approved 'apply' (_approved) for that cell with the cell's current content_sha256 and no
    later hold/reject on the cell; then author, approver, self_approved and attested_utc of that row. 'no' otherwise
    (never attested, or the content changed since, or a later hold/reject)."""
    files = [_hand_file(f) for f in (files or HAND_ENTERED)]
    led = read_ledger(data_dir)
    led = led[led["table"].isin([f[:-4] for f in files])]
    best: dict = {}                                      # cell -> {content_sha256: latest approved attestation row}
    for r in led.itertuples(index=False):
        cell = (r.table, r.key, r.country)
        if r.decision in ("hold", "reject"):
            best.pop(cell, None)                         # a later hold/reject withdraws every earlier attestation
        elif r.decision == "apply" and r.content_sha256 and _approved(r):
            best.setdefault(cell, {})[r.content_sha256] = r
    out = []
    for f in files:
        for c in hand_entered_cells(data_dir, f):
            r = (best.get((c["table"], c["key"], c["country"])) or {}).get(c["content_sha256"])
            out.append({**c, "attested": "yes" if r is not None else "no",
                        "author": r.author if r is not None else "", "approver": r.approver if r is not None else "",
                        "self_approved": r.self_approved if r is not None else "",
                        "attested_utc": r.ts_utc if r is not None else ""})
    return out


def unattested_cells(data_dir: Path, files=None) -> list[dict]:
    """The hand-entered cells whose current content has no matching attestation (see attestation_status). Report
    only: loading never blocks on these (whether it should is a policy decision for Sam)."""
    return [c for c in attestation_status(data_dir, files) if c["attested"] != "yes"]


# ---- Attested rows of other append-only tables (EQ-A-0032, additive) -------------------------------------------------
def attest_rows(data_dir: Path, table: str, cells: list[dict], author: str, approver: str | None = None,
                self_approved: bool = False, note: str = "", now: dt.datetime | None = None) -> list[dict]:
    """Like attest_cells, for rows that do not live in a HAND_ENTERED file (e.g. data/live/market/manual_quotes.csv):
    one 'apply' ledger row per cell dict (key, country, value, content_sha256) under `table`. Four-eyes via
    check_approval (ValueError before anything is written). Returns the rows written."""
    if not isinstance(table, str) or not table.replace("_", "").isalnum() or table + ".csv" in HAND_ENTERED:
        raise ValueError(f"bad attestation table {table!r}")
    author, approver, flag = check_approval(author, approver, self_approved)
    ts = _ts(now)
    rows = []
    for c in cells:
        if not str(c.get("content_sha256", "")).strip():
            raise ValueError("every attested cell needs a content_sha256")
        rows.append({"ts_utc": ts, "vintage_id": c.get("vintage_id", ""), "table": table, "key": str(c["key"]),
                     "country": str(c.get("country", "") or ""), "gate_status": "",
                     "live": _attest_live(str(c.get("value", ""))), "decision": "apply", "author": author,
                     "approver": approver, "note": (note or ATTEST_NOTE), "self_approved": flag,
                     "content_sha256": c["content_sha256"]})
    if rows:
        _append(data_dir, rows)
    return rows


def attested_content(data_dir: Path, table: str) -> dict:
    """(key, country) -> {content_sha256: latest approved 'apply' ledger row} for one table, with the same rule as
    attestation_status: a later hold/reject on the cell withdraws every earlier attestation."""
    led = read_ledger(data_dir)
    best: dict = {}
    for r in led[led["table"] == table].itertuples(index=False):
        cell = (r.key, r.country)
        if r.decision in ("hold", "reject"):
            best.pop(cell, None)
        elif r.decision == "apply" and r.content_sha256 and _approved(r):
            best.setdefault(cell, {})[r.content_sha256] = r
    return best
