"""Audit trail (roadmap 1.6): one row per Inputs and Country Profile cell saying where its value came from.

For every cell the row carries the current value, its origin (live feed, seed kept after a hold, seed estimate),
the source and series, the transform that turned the raw series into the workbook unit, the retrieval date of the
vintage, the quality-gate status and reason, the review decision, and any robustness rule the transform applied.
Everything is read from data/: indicators.csv, countries.csv, rulebook.csv and data/live/{provenance,review,transform_log}.csv.

EQ-A-0018 (columns added at the end, existing ones unchanged): `author`, `approver`, `self_approved` (from the review
ledger decision for Inputs / Country Profile cells, from the attestation for hand-entered cells) and `attested`. The
hand-entered files (ledger.HAND_ENTERED: adjustments, cds_quotes, prediction_markets) get one row per cell with
origin "hand-entered (attested)" or "hand-entered (UNATTESTED)" and attested yes/no. Unattested cells are reported,
never blocked: whether loading should refuse them is a policy decision for Sam.

SEC-A-006 M1 (EQ-A-0045): `restricted_source_cells(data_dir)` lists the applied cells (indicators.csv, countries.csv)
whose value came from a source whose terms bar desk use: Yahoo Finance / yfinance (personal, non-commercial terms;
Sam replaced Yahoo on 2026-10-23, EQ-A-0040) or any record whose licence carries a desk-barred term (non-commercial,
personal: market.gate.DESK_BARRED_LICENCE_TERMS). `econquest fetch --apply` and `review apply` print a loud warning
while the list is not empty (feeds.apply_report); after the first official FX pull it must be empty:

    python -m econquest.ingestion.audit restricted        # exit 0 and "0 restricted-source cells", else 1 and the list
"""
from __future__ import annotations

import argparse
import datetime as dt
import re
import sys
from pathlib import Path

import numpy as np
import pandas as pd

from .sources import read_csv_keep_na_code
from .feeds import WEO_SOURCE_SERIES, WB_SOURCE_SERIES, BIS_SOURCE_SERIES, NO_OFFICIAL_SOURCE, RG_CAP
from .ledger import attestation_status

PROFILE_FIELDS = {"pop": "Population (mm)", "exports": "Exports (% of GDP)", "reserves": "Reserves (% of GDP)",
                  "fx3m": "FX change 3m (%)", "policy": "Policy rate (%)"}

TRANSFORMS = {
    "1.1": "econquest dsa: (WEO interest + debt / average maturity) / revenue, year t+1",
    "1.2": "econquest dsa: World Bank IDS PPG debt service years t+1 and t+2 / reserves",
    "2.1": "econquest dsa: usable reserves / IMF ARA metric (fixed 30/20/10/10, floating 30/15/5/5, managed averaged)",
    "1.3": "GGXWDG_NGDP, year t as delivered",
    "1.6": f"primary balance minus debt-stabilising balance: pb - (r-g)/(1+g) x d(t-1); r = (pb - overall balance)/d(t-1); g = nominal GDP growth with a 3-SD outlier fallback to t-1; r-g capped at +/-{RG_CAP:g}",
    "1.7": "GGXWDG_NGDP(t) - GGXWDG_NGDP(t-5)",
    "2.8": "BCA_NGDPD, year t; falls back to t-1 when |change| > 3 SD of 15y annual changes",
    "5.5": "PCPIPCH, year t as delivered",
    "5.6": "NGDP_RPCH, year t+1 (projection)",
    "5.12": "SD of NGDP_RPCH over 15y excluding 2020-21",
    "5.14": "NGDPDPC, year t as delivered",
    "2.9": "latest IDS value as delivered",
    "2.10": "latest IDS value as delivered",
    "3.4": "mean WGI rank (RL, CC, RQ), latest minus 3 years earlier",
    "3.5": "mean WGI rank (RL, CC, RQ), latest year",
    "5.10": "latest value as delivered",
    "6.2": "latest value as delivered",
    "6.6": "latest value as delivered",
    "2.12": "latest real broad EER / mean of last 120 months x 100 - 100",
    "5.9": "latest BIS credit-to-GDP gap as delivered",
    "5.13": "BIS policy rate minus WEO PCPIPCH (year t)",
    "pop": "SP.POP.TOTL / 1e6",
    "exports": "NE.EXP.GNFS.ZS latest as delivered",
    "reserves": "FI.RES.TOTL.CD / NY.GDP.MKTP.CD x 100",
    "fx3m": "local currency per USD: % change over about 91 days (positive = weaker)",
    "equity_vol": "annualised SD of ETF daily log returns, last 60 trading days (no live source since EQ-A-0040)",
    "policy": "latest BIS WS_CBPOL policy rate",
}
SERIES = {**WEO_SOURCE_SERIES, **WB_SOURCE_SERIES, **BIS_SOURCE_SERIES, "policy": "WS_CBPOL",
          # EQ-A-0040: official FX; equity_vol has no official free source and is left unserved
          "fx3m": "BIS WS_XRU D.<area>.<CCY>.A, else ECB EXR D.<CCY>.EUR.SP00.A via EUR/USD",
          "equity_vol": f"none: {NO_OFFICIAL_SOURCE}"}
SEED_NOTE = "seed estimate (analyst/Claude, Oct 2026); not yet replaced by a feed"
ATTESTATION_COLUMNS = ["author", "approver", "self_approved", "attested"]     # EQ-A-0018, after the original columns
HAND_ATTESTED = "hand-entered (attested)"
HAND_UNATTESTED = "hand-entered (UNATTESTED: no author/approver for the current content)"


def _read(p: Path, **kw) -> pd.DataFrame | None:
    return pd.read_csv(p, **kw) if p.exists() else None


def _text(v) -> str:
    return v if isinstance(v, str) else ""


def build_audit_trail(data_dir: str | Path, hand_entered: bool = True) -> pd.DataFrame:
    """One row per Inputs and Country Profile cell and, with `hand_entered` (default), one row per hand-entered cell
    with its attestation (EQ-A-0018). Columns: the original 16 followed by ATTESTATION_COLUMNS."""
    d = Path(data_dir)
    ind = pd.read_csv(d / "indicators.csv", dtype={"id": str, "pillar": str})
    cty = read_csv_keep_na_code(d / "countries.csv", dtype=str)   # keep ISO2 "NA" (Namibia), EQ-A-0027
    rb = pd.read_csv(d / "rulebook.csv", dtype={"id": str}).set_index("id")
    names = list(cty["country"])
    live = d / "live"
    prov = _read(live / "provenance.csv", dtype={"key": str})
    review = _read(live / "review.csv", dtype={"key": str})
    tlog = _read(live / "transform_log.csv")
    prov_i = prov.set_index(["table", "key", "country"]) if prov is not None and len(prov) else None
    rev_i = review.set_index(["table", "key", "country"]) if review is not None and len(review) else None
    tlog_i = {}
    if tlog is not None and len(tlog):
        for r in tlog.itertuples(index=False):
            key = "2.8" if r.series == "BCA_NGDPD" else "1.6"
            tlog_i.setdefault((r.country, key), []).append(r.rule)

    def cell(table, key, country, label, value):
        row = {"table": table, "key": key, "indicator": label, "country": country, "value": value,
               "origin": "", "source": "", "series": "", "transform": "", "retrieved": "", "gate_status": "", "gate_reason": "",
               "decision": "", "seed_value": np.nan, "live_value": np.nan, "robustness_rule": "; ".join(tlog_i.get((country, key), [])),
               "author": "", "approver": "", "self_approved": "", "attested": ""}
        k = (table, key, country)
        rv = rev_i.loc[k] if rev_i is not None and k in rev_i.index else None
        pv = prov_i.loc[k] if prov_i is not None and k in prov_i.index else None
        if rv is not None:
            row["gate_status"], row["gate_reason"] = rv["status"], rv["reason"] if isinstance(rv["reason"], str) else ""
            row["decision"] = rv["decision"] if isinstance(rv["decision"], str) else ""
            row["seed_value"], row["live_value"] = rv["seed"], rv["live"]
            for c in ("author", "approver", "self_approved"):     # written by ledger.write_review
                row[c] = _text(rv.get(c, ""))
        if pv is not None:
            row["source"], row["series"], row["retrieved"] = pv["source"], pv["series"], pv["retrieved"]
            row["transform"] = TRANSFORMS.get(key, "as delivered")
            applied = np.isfinite(value) and np.isfinite(pv["value"]) and abs(float(pv["value"]) - value) <= 1e-3 * max(1.0, abs(value))  # indicators.csv keeps 4 decimals
            if applied:
                row["origin"] = "live feed"
            elif rv is not None and rv["status"] == "hold":
                row["origin"] = "seed kept (live value held by the quality gate)"
            else:
                row["origin"] = "seed kept (live value not applied)"
        else:
            if rv is not None and rv["status"] == "missing":
                row["origin"] = "seed estimate (feed returned no value)"
            else:
                row["origin"] = "seed estimate"
            row["source"] = SEED_NOTE
            if table == "Inputs" and key in rb.index:
                src = rb.at[key, "source"]; api = rb.at[key, "api"]
                row["series"] = f"intended: {src}" if isinstance(src, str) else ""
                row["transform"] = f"planned feed: {api}" if isinstance(api, str) else ""
            else:
                row["series"] = f"intended: {SERIES.get(key, '')}"; row["transform"] = TRANSFORMS.get(key, "")
        return row

    rows = []
    for _, r in ind.iterrows():
        for n in names:
            v = pd.to_numeric(r.get(n), errors="coerce")
            rows.append(cell("Inputs", r["id"], n, r["indicator"], float(v) if pd.notna(v) else np.nan))
    for _, c in cty.iterrows():
        for key, label in PROFILE_FIELDS.items():
            if key in cty.columns:
                v = pd.to_numeric(c[key], errors="coerce")
                rows.append(cell("Country Profile", key, c["country"], label, float(v) if pd.notna(v) else np.nan))
    if hand_entered:
        for c in attestation_status(d):
            ok = c["attested"] == "yes"
            v = pd.to_numeric(c["value"], errors="coerce")
            rows.append({"table": c["table"], "key": c["key"], "indicator": c["label"], "country": c["country"],
                         "value": float(v) if pd.notna(v) else np.nan, "origin": HAND_ATTESTED if ok else HAND_UNATTESTED,
                         "source": f"hand-entered: data/{c['table']}.csv", "series": "", "transform": "",
                         "retrieved": c["attested_utc"], "gate_status": "", "gate_reason": "",
                         "decision": "attested" if ok else "", "seed_value": np.nan, "live_value": np.nan,
                         "robustness_rule": "", "author": c["author"], "approver": c["approver"],
                         "self_approved": c["self_approved"], "attested": c["attested"]})
    df = pd.DataFrame(rows)
    df.attrs["built"] = dt.date.today().isoformat()
    return df


def audit_summary(df: pd.DataFrame) -> pd.DataFrame:
    s = df.groupby(["table", "origin"]).size().rename("cells").reset_index()
    return s.sort_values(["table", "cells"], ascending=[True, False])


def audit_plan(df: pd.DataFrame, sheet: str = "Audit Trail") -> list[dict]:
    """Values for the Audit Trail tab: title, note, header on row 4, one row per cell from row 5."""
    from ..common_format import _v
    cols = ["table", "key", "indicator", "country", "value", "origin", "source", "series", "transform", "retrieved",
            "gate_status", "gate_reason", "decision", "seed_value", "live_value", "robustness_rule"]
    header = ["Table", "Id", "Indicator", "Country", "Value in workbook", "Origin", "Source (seed = analyst estimate, Oct 2026)", "Series (for seed rows: intended source)", "Transform (for seed rows: planned feed)", "Retrieved",
              "Gate status", "Gate reason", "Review decision", "Seed value", "Live value", "Robustness rule applied"]
    summ = audit_summary(df)
    counts = "; ".join(f"{r.table}: {r.cells} {r.origin}" for r in summ.itertuples(index=False))
    note = (f"Written by `python -m econquest audit` on {df.attrs.get('built', dt.date.today().isoformat())}. One row per Inputs and Country Profile cell: "
            f"where the value came from, how it was transformed, when it was retrieved and what the quality gate decided. {counts}.")
    wb = df.copy()
    seed = wb["origin"].str.startswith("seed estimate")
    wb.loc[seed, "source"] = "seed"                      # keep the tab compact: the long note is in audit_trail.csv
    wb.loc[seed, "series"] = wb.loc[seed, "series"].str.replace("intended: ", "", regex=False)
    wb.loc[seed, "transform"] = wb.loc[seed, "transform"].str.replace("planned feed: ", "", regex=False)
    body = [[_v(x) for x in row] for row in wb[cols].itertuples(index=False)]
    return [{"range": f"'{sheet}'!A1:A2", "values": [["Audit trail: provenance of every input cell"], [note]]},
            {"range": f"'{sheet}'!A4:P4", "values": [header]},
            {"range": f"'{sheet}'!A5:P{4 + len(body)}", "values": body}]



# ------------------------------------------------------------------------------------------------ SEC-A-006 M1
RESTRICTED_SOURCE_RE = re.compile(r"yahoo|yfinance", re.IGNORECASE)
RESTRICTED_SOURCE_REASON = ("Yahoo Finance terms: personal, non-commercial use only; not allowed in desk numbers or a "
                            "publish (Sam 2026-10-23, EQ-A-0040)")
LICENCE_COLUMNS = ("licence", "license", "licences", "licenses")
RESTRICTED_COLUMNS = ["table", "key", "country", "value", "source", "series", "retrieved", "reason", "evidence"]


def restricted_reason(source="", licence="") -> str | None:
    """Why a record's source or licence bars its value from desk numbers (SEC-A-006 M1), or None."""
    from .market.gate import DESK_BARRED_LICENCE_TERMS
    if RESTRICTED_SOURCE_RE.search(_text(source)):
        return RESTRICTED_SOURCE_REASON
    lic = _text(licence).casefold()
    hits = [t for t in DESK_BARRED_LICENCE_TERMS if t in lic]
    if hits:
        return f"licence: {', '.join(hits)} use only ({_text(licence)[:120]}); not allowed in desk numbers or a publish"
    return None


def _same(a: float, b: float) -> bool:
    """indicators.csv keeps 4 decimals and countries.csv 4 significant digits: the tolerance build_audit_trail uses."""
    return bool(np.isfinite(a) and np.isfinite(b) and abs(a - b) <= 1e-3 * max(1.0, abs(a)))


def _records(path: Path, evidence: str, value_col: str) -> list[dict]:
    """Rows of a provenance-like CSV (table, key, country, value, source[, series, retrieved, licence])."""
    if not path.is_file() or path.is_symlink():
        return []
    try:
        df = pd.read_csv(path, dtype=str, keep_default_na=False)
    except (ValueError, OSError):
        return []
    if not {"table", "key", "country", "source", value_col} <= set(df.columns):
        return []
    lic = next((c for c in df.columns if c.strip().lower() in LICENCE_COLUMNS), None)
    out = []
    for r in df.to_dict("records"):
        out.append({"table": r["table"], "key": str(r["key"]), "country": r["country"], "source": r["source"],
                    "series": r.get("series", ""), "retrieved": r.get("retrieved", ""),
                    "licence": r.get(lic, "") if lic else "",
                    "value": pd.to_numeric(r[value_col], errors="coerce"), "evidence": evidence})
    return out


def restricted_source_cells(data_dir: str | Path) -> pd.DataFrame:
    """Applied cells whose current value came from a restricted source (SEC-A-006 M1): one row per cell, columns
    RESTRICTED_COLUMNS, empty when none.

    A cell is listed when its value in indicators.csv (Inputs) or countries.csv (Country Profile) matches, within the
    audit trail's rounding tolerance, a value that a record attributes to Yahoo / yfinance or to a non-commercial or
    personal licence: the current pull's live/provenance.csv, the provenance.csv of any live vintage (so a value
    applied from an older pull is still found after the next pull replaced provenance.csv) or audit_trail.csv. It is
    not listed when the current pull's provenance.csv gives the same value from a source that is not restricted.
    `evidence` names the files that tie the value to the restricted source. Reads only; never changes data."""
    d = Path(data_dir)
    live = d / "live"
    current = _records(live / "provenance.csv", "live/provenance.csv", "value")
    recs = list(current)
    vroot = live / "vintages"
    if vroot.is_dir() and not vroot.is_symlink():
        for v in sorted(p for p in vroot.iterdir() if p.is_dir() and not p.is_symlink()):
            recs += _records(v / "provenance.csv", f"live/vintages/{v.name}/provenance.csv", "value")
    recs += _records(d / "audit_trail.csv", "audit_trail.csv", "value")
    bad = [dict(r, reason=restricted_reason(r["source"], r["licence"])) for r in recs]
    bad = [r for r in bad if r["reason"] and np.isfinite(r["value"])]
    if not bad:
        return pd.DataFrame(columns=RESTRICTED_COLUMNS)
    allowed = {}
    for r in current:
        if not restricted_reason(r["source"], r["licence"]) and np.isfinite(r["value"]):
            allowed.setdefault((r["table"], r["key"], r["country"]), []).append(float(r["value"]))

    values: dict = {}
    cty = read_csv_keep_na_code(d / "countries.csv", dtype=str)   # keep ISO2 "NA" (Namibia), EQ-A-0027
    names = list(cty["country"])
    keys = {r["key"] for r in bad if r["table"] == "Country Profile"} & set(cty.columns)
    for _, row in cty.iterrows():
        for k in keys:
            v = pd.to_numeric(row[k], errors="coerce")
            if pd.notna(v):
                values[("Country Profile", k, row["country"])] = float(v)
    ind = d / "indicators.csv"
    if any(r["table"] == "Inputs" for r in bad) and ind.is_file():
        df = pd.read_csv(ind, dtype={"id": str, "pillar": str})
        for _, row in df.iterrows():
            for c in names:
                v = pd.to_numeric(row.get(c), errors="coerce")
                if pd.notna(v):
                    values[("Inputs", str(row["id"]), c)] = float(v)

    cells: dict = {}
    for r in bad:
        cell = (r["table"], r["key"], r["country"])
        v = values.get(cell)
        if v is None or not _same(v, float(r["value"])):
            continue
        if any(_same(v, a) for a in allowed.get(cell, [])):
            continue                                     # the current pull gives the same value from an allowed source
        if cell not in cells:
            cells[cell] = {"table": cell[0], "key": cell[1], "country": cell[2], "value": v, "source": r["source"],
                           "series": r["series"], "retrieved": r["retrieved"], "reason": r["reason"], "evidence": []}
        if r["evidence"] not in cells[cell]["evidence"]:
            cells[cell]["evidence"].append(r["evidence"])
    rows = [dict(c, evidence="; ".join(c["evidence"])) for _, c in sorted(cells.items())]
    return pd.DataFrame(rows, columns=RESTRICTED_COLUMNS)


def restricted_warning(cells: pd.DataFrame, limit: int = 20) -> str:
    """The loud multi-line warning fetch / review apply print while restricted-source cells are applied, or ''."""
    if cells is None or cells.empty:
        return ""
    by_key = cells.groupby(["table", "key"]).size()
    lines = ["!" * 100,
             f"WARNING (SEC-A-006 M1): {len(cells)} applied cell(s) still hold values from a restricted source "
             f"({', '.join(f'{t} {k}: {n}' for (t, k), n in by_key.items())}).",
             "They must not reach desk numbers or a publish. Replace them with the official FX pull on the Mac "
             "(docs/runbooks/A-official-fx.md):  econquest fetch --only fx --apply",
             "Check with:  python -m econquest.ingestion.audit restricted"]
    for r in cells.head(limit).itertuples(index=False):
        lines.append(f"  {r.table} {r.key} {r.country} = {r.value:g}  ({r.source}; {r.evidence})")
    if len(cells) > limit:
        lines.append(f"  ... and {len(cells) - limit} more")
    lines.append("!" * 100)
    return "\n".join(lines)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.audit",
                                 description="Audit-trail checks (Team A)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("restricted", help="list applied cells whose value came from Yahoo or a non-commercial / "
                                          "personal licence (SEC-A-006 M1); exit 1 when any")
    r.add_argument("--data", default="data", help="econquest data folder (default: data)")
    r.add_argument("--csv", action="store_true", help="print the cells as CSV")
    a = ap.parse_args(argv)
    cells = restricted_source_cells(a.data)
    if a.csv:
        cells.to_csv(sys.stdout, index=False)
    else:
        print(f"{len(cells)} restricted-source cells in {a.data}")
        if len(cells):
            print(restricted_warning(cells, limit=len(cells)))
    return 1 if len(cells) else 0


if __name__ == "__main__":
    sys.exit(main())
