"""Validator data room, data side (EQ-A-0041, PI-5 independent validation).

`build_data_room(data_dir, as_of, out_dir)` exports, for one as-of date, every Team A data record that existed at
that date into a self-contained, read-only folder an external validator can verify and replay without econquest:

    <out_dir>/
        MANIFEST.json        every file: path, size, sha256, source, kind, as-of rule; top hash; code version
        README.md            for the validator: folders, how to verify, known limitations
        verify.py            standard-library verifier (a copy of econquest/ingestion/dataroom_verify.py)
        data/...             point-in-time copies, at the same relative paths as in data_dir
        derived/four_eyes.csv  one row per review-ledger decision with its four-eyes / self-approval / attestation flags

Point in time (the cutoff is the end of the as-of day in UTC, or the exact instant when as_of carries a time):
* vintages, snapshots and archives by the UTC timestamp in their folder id (`<YYYY-MM-DD>T<HHMMSS>Z-<hash8>`; a legacy
  date-only id counts as the end of that day): live vintages, panel vintages, market snapshots, event vintages, event
  export archives, pre-apply snapshots. Their index.csv files keep only the rows of selected folders whose own
  timestamp column is not after the cutoff.
* frozen replay inputs (replay.freeze_inputs, TEAM_A_RUN_INPUTS) by the snapshots/index.csv row's frozen_utc.
* append-only row files by each row's timestamp: review_ledger.csv (ts_utc, which also carries every attestation),
  market/manual_quotes.csv (entered_utc), market/cds_snapshots.csv (snapshot id time and as_of), approvals/log.jsonl
  (ts_utc) and approvals/proposals by the time in the change id. A row without a readable timestamp is dropped.
* audit_trail.csv: rows retrieved after the cutoff are dropped; rows with no retrieved date (seed and hand-entered
  values) are kept, because the file is regenerated per run and those rows carry no date.
* the current pull (data/live/*.csv, *.json one level: transform_log, unserved, feed_failures, provenance ...) as a
  whole, dated by data/live/feeds.json `retrieved`.
* anything else is an undated working copy (indicators.csv, countries.csv, other teams' files ...): left out and
  listed under build.excluded, unless include_current=True, which is refused when any dated record is after the
  cutoff (then the working copies may already hold later data).

Never exported: data/vendor_licences.json, credential-named files (.env, *.pem, *secret*, *token* ...), JSON files
with credential keys and files whose text matches a credential pattern; hidden, lock and temporary files; symlinks.
Licence tags inside data (licence columns, manifest licences) are kept.

Licence-restricted files (EQ-A-0044) are withheld by default (include_restricted=False): raw_yahoo.csv anywhere
(Yahoo's terms are personal, non-commercial use and do not allow passing the data to an external validator; Sam
replaced Yahoo on 2026-10-23, EQ-A-0040) and any CSV whose licence column says non-commercial or personal
(market.gate.DESK_BARRED_LICENCE_TERMS). Each is listed under build.excluded with its reason and, because it would
otherwise be in the room, under the hashed `withheld` list with its path, size and sha256, so verify.py does not
report it missing. This covers the frozen 2026-10-23 live vintage, which holds raw_yahoo.csv.

Yahoo-derived values are blanked in the room copies (SEC-A-006 M2, EQ-A-0045; data_dir is never changed). Sam
replaced Yahoo because its terms are personal and non-commercial, and that covers values computed from Yahoo data,
not only raw_yahoo.csv. Unless include_restricted=True, in every CSV copied into the room:
* a row whose own `source` (or licence column) is Yahoo / yfinance or carries a non-commercial or personal licence
  (audit.restricted_reason) has its value columns (RESTRICTED_VALUE_COLUMNS: value, live, live_value, change,
  gate_reason, reason ...) blanked: provenance.csv (current pull and vintages), audit_trail.csv, market quotes. A CSV
  with such rows but none of those columns is withheld instead, since its data columns cannot be told apart;
* a long file without a source column (review.csv, diff_vs_seed.csv, the review ledger ...: columns table, key,
  country and live / value) has those columns blanked on rows whose value equals a value that a provenance record
  or the audit trail attributes to a restricted source for that cell (restricted_value_index);
* a wide table (live_profile.csv, live_inputs.csv, countries.csv, indicators.csv, in the current pull, vintages and
  snapshots) has each such cell blanked.
Each changed file is listed under the hashed `redactions` list with `restricted_rows`, `restricted_cells` and the
original sha256 and size, so a vintage holding one is reported `altered` by verify.py (as for a withheld file).

E-mail addresses are redacted at source (EQ-A-0044, for SEC-C-008 R6): in every text file copied into the room,
each match of EMAIL_RE (the same pattern as Team C's evidence bundle) and of its %40-encoded form (EMAIL_PCT_RE) is
replaced by `[redacted-email]` before the file is hashed. UTF-8 files and UTF-16/32 files with a byte-order mark are
scanned (secrets and e-mails, SEC-A-006 L4); any other file that is not UTF-8 text (binary, BOM-less UTF-16: NUL
bytes) cannot be scanned reliably and is withheld with that reason. The hashed `redactions` list names each file with
its replacement count and its original sha256 and size. data_dir is never changed.

A live or panel vintage's content hash covers the original bytes of every file in the folder, so a vintage with a
withheld or redacted file cannot be re-verified from the room. The build verifies the source folder against
vintages/index.csv and records the result in the hashed `altered_anchors`. verify.py then reports the folder as
`altered` (a warning) when the room's index row matches what was verified and the file count adds up, and `failed`
otherwise. Anchors that compare a sha256 (market and event manifests, replay manifests) use the recorded original.

The data limitations register (econquest.ingestion.limitations.build_register) is generated for the as-of into
limitations/data-limitations.md (EQ-A-0044). The manifest's `limitations` entry says whether it was generated, from
which pull and, if not, why.

Nothing in data_dir is written: files are read, and the room is built in a temporary sibling of out_dir and renamed
into place (files 0444). Deterministic: the same data and code give the same MANIFEST.json except its `build`
section (build time, source path, exclusions), which is outside both hashes. Selection uses only records dated at
or before the cutoff, so a room rebuilt later for the same as-of date has the same hash while the append-only
stores are unchanged (current-pull files and audit_trail.csv are working copies and may move it; README says so).

`verify_data_room(path)` runs dataroom_verify.verify_room, the same code as the room's verify.py.
Command line: python -m econquest.ingestion.dataroom build --as-of 2026-10-23      # -> outputs/dataroom/2026-10-23
              python -m econquest.ingestion.dataroom build --data data --as-of 2026-10-23 --out /tmp/room
              python -m econquest.ingestion.dataroom verify /tmp/room"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import io
import json
import os
import platform
import re
import shutil
import sys
import tempfile
from pathlib import Path

from .dataroom_verify import MANIFEST_NAME, SCHEMA, _anchor_checks, altered_map, content_hash, manifest_hash, verify_room

VERIFY_SOURCE = Path(__file__).with_name("dataroom_verify.py")
LIMITATIONS_DOC = "docs/validation/data-limitations.md"
LIMITATIONS_PATH = "limitations/data-limitations.md"
REDACTED_EMAIL = "[redacted-email]"
# The same pattern as Team C's evidence bundle (econquest/ops/evidence.py EMAIL_RE, SEC-C-008 R6), so nothing in the
# room is left for the bundle to redact; tests/test_dataroom.py checks that the two agree.
EMAIL_RE = re.compile(r"[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?(?:\.[A-Za-z0-9-]+)+")
# SEC-A-006 L4: the same address URL-encoded (sam%40example.com); EMAIL_RE itself stays Team C's pattern
EMAIL_PCT_RE = re.compile(r"[A-Za-z0-9.!#$&'*+/=?^_`{|}~-]+%40[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?(?:\.[A-Za-z0-9-]+)+",
                          re.IGNORECASE)
YAHOO_FILE_REASON = ("licence: Yahoo Finance data, personal non-commercial use only; may not be passed to an "
                     "external validator (Yahoo replaced by Sam 2026-10-23, EQ-A-0040)")
RESTRICTED_FILES = {"raw_yahoo.csv": YAHOO_FILE_REASON}       # matched case-insensitively, as is any *yahoo* name
UNSCANNABLE_REASON = ("unscannable: not UTF-8 text and no UTF-16/32 byte-order mark (binary, or text with NUL bytes), "
                      "so secrets and e-mail addresses cannot be checked; withheld rather than exported unscanned "
                      "(SEC-A-006 L4)")
# SEC-A-006 M2: columns blanked on a row tied to a restricted source (Yahoo, non-commercial / personal licence)
RESTRICTED_VALUE_COLUMNS = ("value", "live", "live_value", "change", "change_pct", "pct_change", "rel_change",
                            "gate_reason", "reason", "close", "adj_close", "price", "open", "high", "low")
RESTRICTED_NO_VALUE_COLUMNS = ("licence: rows from a restricted source (Yahoo / non-commercial / personal) in a CSV with "
                               "none of the known value columns, so they cannot be blanked; withheld (SEC-A-006 M2)")
LICENCE_COLUMNS = ("licence", "license", "licences", "licenses")
DERIVED_FOUR_EYES = "derived/four_eyes.csv"
FOUR_EYES_COLUMNS = ["ts_utc", "vintage_id", "table", "key", "country", "gate_status", "decision", "author", "approver",
                     "self_approved", "four_eyes", "attestation", "content_sha256", "note"]

RULES = {
    "live_vintage": "folder id timestamp (UTC; legacy date id = end of that day) <= cutoff",
    "live_vintage_index": "rows of selected live vintages whose retrieved_utc <= cutoff",
    "panel_vintage": "folder id timestamp (UTC) <= cutoff",
    "panel_vintage_index": "rows of selected panel vintages whose created_utc <= cutoff",
    "market_snapshot": "snapshot id timestamp (save time, UTC) <= cutoff",
    "market_snapshot_index": "rows of selected market snapshots whose saved_utc <= cutoff",
    "cds_snapshots": "rows whose snapshot_id timestamp <= cutoff and as_of <= cutoff",
    "manual_quotes": "rows whose entered_utc <= cutoff (rows without a timestamp dropped)",
    "event_vintage": "folder id timestamp (save time, UTC) <= cutoff",
    "event_vintage_index": "rows of selected event vintages whose retrieved_utc (save time) <= cutoff",
    "event_export": "export id timestamp (created_utc) <= cutoff",
    "event_export_index": "rows of selected event exports whose created_utc <= cutoff",
    "replay_snapshot": "named by a kept snapshots/index.csv row (frozen_utc <= cutoff, its vintage selected)",
    "replay_snapshot_index": "rows whose frozen_utc <= cutoff and whose live vintage is selected",
    "pre_apply_snapshot": "folder id timestamp (UTC) <= cutoff",
    "review_ledger": "rows whose ts_utc <= cutoff (rows without a timestamp dropped)",
    "approvals_log": "rows whose ts_utc <= cutoff (a prefix of the hash chain)",
    "approvals_proposal": "change id timestamp (CHG-<YYYYMMDD>T<HHMMSS>Z) <= cutoff",
    "audit_trail": "rows whose retrieved date <= cutoff; rows with no retrieved date (seed, hand-entered) kept",
    "current_pull": "data/live/feeds.json retrieved date (end of day) <= cutoff; whole files",
    "current_working_copy": "undated working copy, included only with include_current and no dated record after cutoff",
    "derived": "generated from the kept review_ledger rows",
    "verify_script": "standard-library verifier copied from econquest/ingestion/dataroom_verify.py",
    "limitations": ("generated by econquest.ingestion.limitations.build_register from the newest pull at or before the "
                    "cutoff (audit_trail rows by retrieved date); its narrative is hand-written (EQ-A-0042) "
                    "and indicators/countries/rulebook are read as working copies"),
    "readme": "generated for the validator",
}

SECRET_FILES = {"vendor_licences.json", "vendor_licenses.json", ".netrc", ".pgpass", "credentials", "credentials.json"}
SECRET_NAME_RE = re.compile(
    r"(^\.env|(^|[._-])(secrets?|credentials?|passwords?|passwd|tokens?|api[_-]?keys?|app[_-]?keys?|private[_-]?key)"
    r"([._-]|$)|\.(pem|key|p12|pfx|jks|keystore|kdbx)$|^id_(rsa|dsa|ecdsa|ed25519))", re.IGNORECASE)
SECRET_KEY_RE = re.compile(r"(password|passwd|pass|pwd|pw|secret|client_secret|api_?key|app_?key|access_?token|"
                           r"refresh_?token|auth|auth_?token|authorization|bearer|token|credentials?|private_?key|"
                           r"keychain)", re.IGNORECASE)
SECRET_TEXT_RE = re.compile(
    r"(-----BEGIN [A-Z ]*PRIVATE KEY-----|\bAKIA[0-9A-Z]{16}\b|\bgh[pousr]_[A-Za-z0-9]{30,}|\bgithub_pat_[A-Za-z0-9_]{30,}"
    r"|\bxox[abprs]-[A-Za-z0-9-]{10,}|\bsk-(ant-)?[A-Za-z0-9_-]{24,}"
    r"|\bBearer\s+[A-Za-z0-9._~+/-]{16,}|\beyJ[\w-]{8,}\.[\w-]{8,}\."                      # SEC-A-006 L4: bearer, JWT
    r"|\b(password|passwd|pass|pwd|api[_-]?key|app[_-]?key|client[_-]?secret|access[_-]?token|auth[_-]?token)\b"
    r"\s*[:=]\s*[\"']?[A-Za-z0-9_\-./+]{8,})", re.IGNORECASE)

_ID_RE = re.compile(r"(\d{4}-\d{2}-\d{2})(?:T(\d{2})(\d{2})(\d{2})Z)?(?=$|-)")
_CHG_RE = re.compile(r"CHG-(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})Z")
_DATE_RE = re.compile(r"\d{4}-\d{2}-\d{2}")


# ------------------------------------------------------------------------------------------------ time

def _end_of_day(day: str) -> dt.datetime:
    return dt.datetime.combine(dt.date.fromisoformat(day), dt.time.max, tzinfo=dt.timezone.utc)


def parse_ts(value) -> dt.datetime | None:
    """A UTC instant from a stored timestamp: ISO date (taken as the end of that day, so it is never earlier than the
    event it dates), ISO date-time (Z, offset or naive = UTC, any fraction) or the compact id form YYYY-MM-DDTHHMMSSZ.
    None when blank or unreadable."""
    s = str(value if value is not None else "").strip().lstrip("'")
    if not s or s.lower() == "nan":
        return None
    try:
        if _DATE_RE.fullmatch(s):
            return _end_of_day(s)
        m = re.fullmatch(r"(\d{4}-\d{2}-\d{2})T(\d{2})(\d{2})(\d{2})Z", s)
        if m:
            return dt.datetime.fromisoformat(f"{m[1]}T{m[2]}:{m[3]}:{m[4]}+00:00")
        t = dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
    except ValueError:
        return None
    return t.replace(tzinfo=dt.timezone.utc) if t.tzinfo is None else t.astimezone(dt.timezone.utc)


def id_ts(name: str) -> dt.datetime | None:
    """Timestamp at the start of a folder or record id: `<YYYY-MM-DD>T<HHMMSS>Z...`, a legacy `<YYYY-MM-DD>...`
    (end of that day) or a change id `CHG-<YYYYMMDD>T<HHMMSS>Z-...`."""
    name = str(name or "")
    m = _CHG_RE.match(name)
    if m:
        return dt.datetime(*(int(x) for x in m.groups()), tzinfo=dt.timezone.utc)
    m = _ID_RE.match(name)
    if not m:
        return None
    try:
        if m[2] is None:
            return _end_of_day(m[1])
        return dt.datetime.fromisoformat(f"{m[1]}T{m[2]}:{m[3]}:{m[4]}+00:00")
    except ValueError:
        return None


def cutoff_of(as_of) -> tuple[str, dt.datetime]:
    """(as_of label, cutoff instant). A date (or 'YYYY-MM-DD') means the end of that UTC day; a datetime or ISO
    date-time string is used as given (naive = UTC)."""
    if isinstance(as_of, dt.datetime):
        t = as_of.replace(tzinfo=dt.timezone.utc) if as_of.tzinfo is None else as_of.astimezone(dt.timezone.utc)
        return t.strftime("%Y-%m-%dT%H:%M:%SZ") if not t.microsecond else t.isoformat(), t
    if isinstance(as_of, dt.date):
        return as_of.isoformat(), _end_of_day(as_of.isoformat())
    s = str(as_of).strip()
    if _DATE_RE.fullmatch(s):
        return s, _end_of_day(s)
    t = parse_ts(s)
    if t is None:
        raise ValueError(f"as_of {as_of!r} is not a date (YYYY-MM-DD) or an ISO date-time")
    return cutoff_of(t)


def _iso(t: dt.datetime) -> str:
    return t.strftime("%Y-%m-%dT%H:%M:%S.%fZ")


# ------------------------------------------------------------------------------------------------ secrets

def _json_secret_keys(doc, path="") -> list[str]:
    out = []
    if isinstance(doc, dict):
        for k, v in doc.items():
            p = f"{path}.{k}" if path else str(k)
            if SECRET_KEY_RE.fullmatch(str(k)):
                out.append(p)
            out += _json_secret_keys(v, p)
    elif isinstance(doc, list):
        for i, v in enumerate(doc):
            out += _json_secret_keys(v, f"{path}[{i}]")
    return out


_BOMS = ((b"\xff\xfe\x00\x00", "utf-32-le"), (b"\x00\x00\xfe\xff", "utf-32-be"), (b"\xff\xfe", "utf-16-le"),
         (b"\xfe\xff", "utf-16-be"))


def decode_text(body: bytes) -> tuple[str, str, bytes] | None:
    """(text, codec, bom) for a file that can be scanned reliably: UTF-8 (an optional BOM kept as text) or UTF-16/32
    with a byte-order mark. None for anything else, and for text with NUL bytes (BOM-less UTF-16, binary):
    SEC-A-006 L4."""
    for bom, codec in _BOMS:
        if body.startswith(bom):
            try:
                text = body[len(bom):].decode(codec)
            except UnicodeDecodeError:
                return None
            return (text, codec, bom) if "\0" not in text else None
    try:
        text = body.decode("utf-8")
    except UnicodeDecodeError:
        return None
    return (text, "utf-8", b"") if "\0" not in text else None


def secret_reason(rel: str, body: bytes) -> str | None:
    """Why a file must not leave data_dir (credential or licence file with credentials), or None."""
    name = rel.rsplit("/", 1)[-1]
    if name.lower() in SECRET_FILES:
        return "secret: licence or credential file (never exported)"
    if SECRET_NAME_RE.search(name):
        return "secret: credential-like file name"
    dec = decode_text(body)
    text = dec[0] if dec else body.decode("utf-8", errors="ignore")
    if name.lower().endswith(".json"):
        try:
            keys = _json_secret_keys(json.loads(text))
        except ValueError:
            keys = []
        if keys:
            return f"secret: JSON with credential-like keys ({len(keys)})"
    if SECRET_TEXT_RE.search(text):
        return "secret: text matches a credential pattern"
    return None


def restricted_reason(rel: str, body: bytes) -> str | None:
    """Why a file's licence bars it from the room (EQ-A-0044), or None: raw_yahoo.csv, or a CSV (not an index.csv,
    which only lists licences as anchor metadata) with a licence column that carries a desk-barred term
    (non-commercial, personal)."""
    name = rel.rsplit("/", 1)[-1]
    if name.lower() in RESTRICTED_FILES:                  # SEC-A-006 L4: case-insensitive, and any *yahoo* file
        return RESTRICTED_FILES[name.lower()]
    if "yahoo" in name.lower():
        return YAHOO_FILE_REASON
    if not name.lower().endswith(".csv") or name == "index.csv":
        return None
    dec = decode_text(body)
    if dec is None:
        return None
    text = dec[0]
    reader = csv.reader(io.StringIO(text, newline=""))
    header = next(reader, None) or []
    cols = [i for i, h in enumerate(header) if h.strip().lower() in LICENCE_COLUMNS]
    if not cols:
        return None
    from .market.gate import DESK_BARRED_LICENCE_TERMS
    hits: dict[str, int] = {}
    for row in reader:
        for i in cols:
            v = row[i].casefold() if i < len(row) else ""
            term = next((t for t in DESK_BARRED_LICENCE_TERMS if t in v), None)
            if term:
                hits[term] = hits.get(term, 0) + 1
                break
    if not hits:
        return None
    return ("licence: rows licensed " + ", ".join(f"{t!r} ({n})" for t, n in sorted(hits.items()))
            + "; not for an external validator (market.gate.DESK_BARRED_LICENCE_TERMS)")


def redact_emails(body: bytes) -> tuple[bytes, int]:
    """(body with every EMAIL_RE and EMAIL_PCT_RE match replaced by REDACTED_EMAIL, replacements). UTF-8 and
    BOM-marked UTF-16/32 text is scanned and written back in its own encoding; other bytes are returned as they are
    (the build withholds them, SEC-A-006 L4)."""
    dec = decode_text(body)
    if dec is None:
        return body, 0
    text, codec, bom = dec
    new, n = EMAIL_RE.subn(REDACTED_EMAIL, text)
    new, n2 = EMAIL_PCT_RE.subn(REDACTED_EMAIL, new)
    return (bom + new.encode(codec), n + n2) if n + n2 else (body, 0)


# ------------------------------------------------------------------------------------------------ restricted values

def restricted_value_index(d: Path) -> dict:
    """{(table, key, country): [values]} that a record attributes to a restricted source (Yahoo / yfinance, or a
    non-commercial / personal licence): the current pull's live/provenance.csv, every live vintage's provenance.csv
    and audit_trail.csv (audit.restricted_reason). Read from data_dir whatever the cutoff, only to recognise values."""
    from .audit import _records, restricted_reason as source_reason
    recs = _records(d / "live" / "provenance.csv", "live/provenance.csv", "value")
    root = d / "live" / "vintages"
    if root.is_dir() and not root.is_symlink():
        for v in sorted(p for p in root.iterdir() if p.is_dir() and not p.is_symlink()):
            recs += _records(v / "provenance.csv", v.name, "value")
    recs += _records(d / "audit_trail.csv", "audit_trail.csv", "value")
    out: dict = {}
    for r in recs:
        if source_reason(r["source"], r["licence"]) and r["value"] == r["value"]:      # not NaN
            out.setdefault((r["table"], str(r["key"]), r["country"]), []).append(float(r["value"]))
    return out


def _num(v) -> float | None:
    try:
        x = float(str(v).strip().lstrip("'"))
    except ValueError:
        return None
    return x if x == x else None


def _restricted_value(index: dict, cell: tuple, v) -> bool:
    from .audit import _same
    x = _num(v)
    return x is not None and any(_same(x, y) for y in index.get(cell, ()))


# wide tables: file name -> (table, id column or None for the first column, rows are 'countries' or 'keys')
WIDE_TABLES = {"live_profile.csv": ("Country Profile", None, "countries"), "live_inputs.csv": ("Inputs", None, "keys"),
               "countries.csv": ("Country Profile", "country", "countries"), "indicators.csv": ("Inputs", "id", "keys")}


def blank_restricted(rel: str, body: bytes, index: dict) -> tuple[bytes, dict | None, str | None]:
    """SEC-A-006 M2: (body with Yahoo-derived values blanked, {"restricted_rows", "restricted_cells", "rule"} or None
    when nothing changed, a withhold reason or None). See the module docstring for the three rules. index.csv
    files (anchor metadata) and non-CSV files are returned unchanged."""
    from .audit import LICENCE_COLUMNS as LIC, restricted_reason as source_reason
    name = rel.rsplit("/", 1)[-1]
    if not name.lower().endswith(".csv") or name == "index.csv":
        return body, None, None
    dec = decode_text(body)
    if dec is None:
        return body, None, None
    text, codec, bom = dec
    rows = list(csv.reader(io.StringIO(text, newline="")))
    if len(rows) < 2:
        return body, None, None
    header = rows[0]
    low = [h.strip().lower() for h in header]
    vals = [i for i, h in enumerate(low) if h in RESTRICTED_VALUE_COLUMNS]
    src = low.index("source") if "source" in low else None
    lic = next((i for i, h in enumerate(low) if h in LIC), None)
    n_rows = n_cells = 0

    def cell(r, i):
        return r[i] if i < len(r) else ""

    def blank(r, idx):
        nonlocal n_cells
        for i in idx:
            if i < len(r) and r[i] != "":
                r[i] = ""
                n_cells += 1

    long_ = {"table", "key", "country"} <= set(low)
    t, k, c = (low.index("table"), low.index("key"), low.index("country")) if long_ else (0, 0, 0)
    probe = [low.index(x) for x in ("live", "value", "live_value") if x in low]

    def by_value(r):
        return long_ and any(_restricted_value(index, (cell(r, t), cell(r, k), cell(r, c)), cell(r, i)) for i in probe)

    if src is not None or lic is not None:                                     # rule 1: the row's own source
        rule = "source"
        hits = [r for r in rows[1:] if source_reason(cell(r, src) if src is not None else "",
                                                     cell(r, lic) if lic is not None else "") or by_value(r)]
        if hits and not vals:
            return body, None, RESTRICTED_NO_VALUE_COLUMNS
        for r in hits:
            n_rows += 1
            blank(r, vals)
    elif long_ and vals:                                                        # rule 2: long file, by value
        rule = "value"
        for r in rows[1:]:
            if by_value(r):
                n_rows += 1
                blank(r, vals)
    elif name.lower() in WIDE_TABLES:                                           # rule 3: wide table, by value
        rule = "value"
        table, id_col, rows_are = WIDE_TABLES[name.lower()]
        ic = low.index(id_col) if id_col and id_col in low else 0
        for r in rows[1:]:
            hit = False
            for i, h in enumerate(header):
                if i == ic or i >= len(r):
                    continue
                key = (table, h, r[ic]) if rows_are == "countries" else (table, r[ic], h)
                if r[i] != "" and _restricted_value(index, key, r[i]):
                    r[i] = ""
                    n_cells += 1
                    hit = True
            n_rows += hit
    else:
        return body, None, None
    if not n_cells:
        return body, None, None
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\r\n" if text.split("\n", 1)[0].endswith("\r") else "\n")
    w.writerows(rows)
    return bom + buf.getvalue().encode(codec), {"restricted_rows": n_rows, "restricted_cells": n_cells, "rule": rule}, None


# ------------------------------------------------------------------------------------------------ row filters

def _lineterminator(body: bytes) -> str:
    first = body.split(b"\n", 1)[0]
    return "\r\n" if first.endswith(b"\r") else "\n"


def filter_csv(body: bytes, keep) -> tuple[bytes, dict]:
    """Keep the header and the rows for which keep(row_dict) is True; keep may return None for 'undated' (dropped).
    Rows are re-serialised with the csv module and the source's line terminator (values unchanged)."""
    text = body.decode("utf-8")
    rows = list(csv.reader(io.StringIO(text, newline="")))
    st = {"rows_kept": 0, "rows_dropped": 0, "rows_undated": 0}
    if not rows:
        return body, st
    header, buf = rows[0], io.StringIO()
    w = csv.writer(buf, lineterminator=_lineterminator(body))
    w.writerow(header)
    for r in rows[1:]:
        k = keep(dict(zip(header, r)))
        if k:
            w.writerow(r)
            st["rows_kept"] += 1
        else:
            st["rows_undated" if k is None else "rows_dropped"] += 1
    return buf.getvalue().encode("utf-8"), st


def _ts_keep(col: str, cut: dt.datetime, seen: list, undated=None):
    def keep(row):
        t = parse_ts(row.get(col))
        if t is None:
            return undated
        seen.append(t)
        return t <= cut
    return keep


def filter_jsonl(body: bytes, cut: dt.datetime, seen: list) -> tuple[bytes, dict]:
    out, st = [], {"rows_kept": 0, "rows_dropped": 0, "rows_undated": 0}
    for line in body.decode("utf-8").splitlines(keepends=True):
        if not line.strip():
            continue
        try:
            t = parse_ts(json.loads(line).get("ts_utc"))
        except (ValueError, AttributeError):
            t = None
        if t is None:
            st["rows_undated"] += 1
            continue
        seen.append(t)
        if t <= cut:
            out.append(line if line.endswith("\n") else line + "\n")
            st["rows_kept"] += 1
        else:
            st["rows_dropped"] += 1
    return "".join(out).encode("utf-8"), st


# ------------------------------------------------------------------------------------------------ selection

# (path prefix parts, kind, index timestamp column, index id column)
FOLDER_STORES = (
    (("live", "vintages"), "live_vintage", "retrieved_utc", "vintage_id"),
    (("panel", "vintages"), "panel_vintage", "created_utc", "vintage_id"),
    (("live", "market", "snapshots"), "market_snapshot", "saved_utc", "snapshot_id"),
    (("live", "events", "exports"), "event_export", "created_utc", "export_id"),
)


def _store_of(parts: tuple) -> tuple | None:
    """(store root parts, kind, ts column, id column) for a path inside a folder store, else None."""
    for root, kind, tcol, icol in FOLDER_STORES:
        if parts[:len(root)] == root:
            return root, kind, tcol, icol
    if len(parts) >= 4 and parts[:2] == ("live", "events") and parts[3] == "vintages":
        return parts[:4], "event_vintage", "retrieved_utc", "vintage_id"
    if parts[:2] == ("live", "snapshots"):
        return ("live", "snapshots"), "snapshot", "frozen_utc", "snapshot"
    return None


def _all_files(d: Path) -> list[str]:
    return sorted(p.relative_to(d).as_posix() for p in d.rglob("*") if p.is_file() or p.is_symlink())


def _plan(d: Path, cut: dt.datetime, include_current: bool, include_restricted: bool = False
          ) -> tuple[list[dict], list[dict], list[dict], list, list[dict]]:
    """Classify every file under d: (entries to write, excluded, filter stats, timestamps seen, withheld)."""
    entries, excluded, filtered, seen, withheld = [], [], [], [], []
    rels = _all_files(d)
    index = {} if include_restricted else restricted_value_index(d)

    def skip(rel, reason):
        excluded.append({"source": rel, "reason": reason})

    def add(rel, kind, body, stats=None):
        why = None if include_restricted else restricted_reason(rel, body)
        if why is None and decode_text(body) is None:   # SEC-A-006 L4: cannot be scanned for secrets or e-mails
            why = UNSCANNABLE_REASON
        info = None
        if why is None and not include_restricted:       # SEC-A-006 M2: blank Yahoo-derived values
            new, info, why = blank_restricted(rel, body, index)
        if why:                                # would be in the room: withheld, and listed in the hashed manifest
            skip(rel, why)
            withheld.append({"path": f"data/{rel}", "source": rel, "size": len(body),
                             "sha256": hashlib.sha256(body).hexdigest(), "reason": why})
            return
        e = {"path": f"data/{rel}", "source": rel, "kind": kind, "body": body}
        if info:
            e.update(body=new, original=body, restricted=info)
        if stats is not None:
            e["filter"] = {"rows_kept": stats["rows_kept"]}
            filtered.append({"source": rel, **stats})
        entries.append(e)

    # pass 1: which folders of each store are selected (by the timestamp in their id)
    selected: dict[tuple, set] = {}
    for rel in rels:
        parts = tuple(rel.split("/"))
        st = _store_of(parts)
        if st is None or len(parts) < len(st[0]) + 2 or any(p.startswith(".") for p in parts):
            continue
        folder = parts[len(st[0])]
        t = id_ts(folder)
        if t is not None:
            seen.append(t)
        if t is not None and t <= cut and st[1] != "snapshot":
            selected.setdefault(st[0], set()).add(folder)
    live_sel = selected.get(("live", "vintages"), set())
    snap_rows: set = set()
    idx = d / "live" / "snapshots" / "index.csv"
    if idx.is_file() and not idx.is_symlink():
        with open(idx, newline="", encoding="utf-8") as f:
            for r in csv.DictReader(f):
                t = parse_ts(r.get("frozen_utc"))
                if t is not None:
                    seen.append(t)
                if t is not None and t <= cut and r.get("vintage_id") in live_sel:
                    snap_rows.add(r.get("snapshot"))
    snaps = set(snap_rows)
    for rel in rels:
        parts = tuple(rel.split("/"))
        if parts[:2] == ("live", "snapshots") and len(parts) >= 4 and "-pre-apply" in parts[2]:
            t = id_ts(parts[2])
            if t is not None and t <= cut:
                snaps.add(parts[2])
    selected[("live", "snapshots")] = snaps

    feeds_t = None
    fj = d / "live" / "feeds.json"
    if fj.is_file() and not fj.is_symlink():
        try:
            feeds_t = parse_ts(json.loads(fj.read_text(encoding="utf-8")).get("retrieved"))
        except (OSError, ValueError, AttributeError):
            feeds_t = None
    if feeds_t is not None:
        seen.append(feeds_t)

    undated = []
    for rel in rels:
        parts = tuple(rel.split("/"))
        p = d / rel
        if any(x.startswith(".") for x in parts):
            skip(rel, "hidden, lock or temporary file")
            continue
        if p.is_symlink():
            skip(rel, "symlink (never followed)")
            continue
        body = p.read_bytes()
        why = secret_reason(rel, body)
        if why:
            skip(rel, why)
            continue
        st = _store_of(parts)
        if st is not None:
            root, kind, tcol, icol = st
            n = len(root)
            if len(parts) == n + 1 and parts[-1] == "index.csv":
                sel = selected.get(root, set())
                if kind == "snapshot":
                    kind_i = "replay_snapshot_index"
                    keep_rows = snap_rows

                    def keep(r, _k=keep_rows):
                        t = parse_ts(r.get("frozen_utc"))
                        return None if t is None else (r.get("snapshot") in _k and t <= cut)
                else:
                    kind_i = f"{kind}_index"

                    def keep(r, _sel=sel, _t=tcol, _i=icol):
                        t = parse_ts(r.get(_t))
                        return None if t is None else (r.get(_i) in _sel and t <= cut)
                out, stats = filter_csv(body, keep)
                add(rel, kind_i, out, stats)
                continue
            if len(parts) >= n + 2:
                folder = parts[n]
                if folder in selected.get(root, set()):
                    k = kind if kind != "snapshot" else ("pre_apply_snapshot" if "-pre-apply" in folder else "replay_snapshot")
                    add(rel, k, body)
                # folders after the cutoff (or not selected) are simply not part of this as-of room
                continue
            undated.append((rel, body))
            continue
        if rel == "live/review_ledger.csv":
            out, stats = filter_csv(body, _ts_keep("ts_utc", cut, seen))
            add(rel, "review_ledger", out, stats)
        elif rel == "live/market/manual_quotes.csv":
            out, stats = filter_csv(body, _ts_keep("entered_utc", cut, seen))
            add(rel, "manual_quotes", out, stats)
        elif rel == "market/cds_snapshots.csv":
            def keep_cds(r):
                t, a = id_ts(r.get("snapshot_id")), parse_ts(r.get("as_of"))
                if t is None or a is None:
                    return None
                seen.append(t)
                return t <= cut and a <= cut
            out, stats = filter_csv(body, keep_cds)
            add(rel, "cds_snapshots", out, stats)
        elif rel == "approvals/log.jsonl":
            out, stats = filter_jsonl(body, cut, seen)
            add(rel, "approvals_log", out, stats)
        elif parts[:2] == ("approvals", "proposals") and len(parts) == 3:
            t = id_ts(Path(parts[2]).stem)
            if t is not None:
                seen.append(t)
            if t is not None and t <= cut:
                add(rel, "approvals_proposal", body)
            elif t is None:
                skip(rel, "approval proposal without a change-id timestamp")
        elif rel == "approvals/head.json":
            skip(rel, "current hash-chain head: the kept log prefix is verified from genesis by verify.py instead")
        elif rel == "audit_trail.csv":
            out, stats = filter_csv(body, _ts_keep("retrieved", cut, seen, undated=True))
            stats["rows_undated_kept"] = stats["rows_kept"] - sum(
                1 for r in csv.DictReader(io.StringIO(out.decode("utf-8"))) if parse_ts(r.get("retrieved")))
            add(rel, "audit_trail", out, stats)
        elif (len(parts) == 2 and parts[0] == "live" and p.suffix in (".csv", ".json")
              and parts[1] not in ("events_weekly.csv",)):
            if feeds_t is not None and feeds_t <= cut:
                add(rel, "current_pull", body)
            elif feeds_t is None:
                undated.append((rel, body))
            # a current pull retrieved after the cutoff is not part of this as-of room
        else:
            undated.append((rel, body))

    for rel, body in undated:
        if include_current:
            add(rel, "current_working_copy", body)
        else:
            skip(rel, "undated working copy: no point-in-time record (see README; include_current to add)")
    return entries, excluded, filtered, seen, withheld


def _altered_anchors(d: Path, altered: dict) -> dict:
    """What the build verified on the source for each live/panel vintage folder and approvals log it altered
    (withheld or redacted files): {room path: {...,"verified_at_build": "ok" | problem}} (EQ-A-0044)."""
    from .dataroom_verify import _last_row, _rows, _vintage_row, folder_content_hash
    out = {}
    folders = set()
    for path in altered:
        parts = path.split("/")
        if parts[:3] in (["data", "live", "vintages"], ["data", "panel", "vintages"]) and len(parts) == 5:
            folders.add("/".join(parts[:4]))
    for room in sorted(folders):
        src = d / room[len("data/"):]
        digest, n = folder_content_hash(src)
        idx = src.parent / "index.csv"
        rows = _rows(idx) if idx.is_file() else []
        if room.startswith("data/live/"):
            row, agree = _vintage_row(rows, src.name)
        else:
            row, agree = _last_row(rows, "vintage_id", src.name), True
        if row is None:
            ver = "unanchored: no row in index.csv"
        elif not agree:
            ver = "failed: index.csv rows for this id disagree"
        elif row.get("hash") != digest or str(row.get("n_files")) != str(n):
            ver = f"failed: source content hash {digest[:12]} / {n} files != index.csv"
        else:
            ver = "ok"
        out[room] = {"index_hash": row.get("hash") if row else None, "n_files": n, "source_content_hash": digest,
                     "verified_at_build": ver}
    return out


def _four_eyes(ledger_body: bytes) -> bytes:
    from .ledger import person_key
    rows = list(csv.DictReader(io.StringIO(ledger_body.decode("utf-8"), newline="")))
    buf = io.StringIO()
    w = csv.DictWriter(buf, FOUR_EYES_COLUMNS, lineterminator="\n", extrasaction="ignore")
    w.writeheader()
    for r in rows:
        author, approver = r.get("author", ""), r.get("approver", "")
        selfa = str(r.get("self_approved", "")).strip().lstrip("'").lower() == "yes"
        if selfa:
            fe = "self-approved"
        elif approver.strip() and person_key(approver) != person_key(author):
            fe = "yes"
        elif approver.strip():
            fe = "no (approver is the author, not flagged)"
        else:
            fe = "no approver"
        w.writerow({**{c: r.get(c, "") for c in FOUR_EYES_COLUMNS}, "four_eyes": fe,
                    "attestation": "yes" if str(r.get("content_sha256", "")).strip() else "no"})
    return buf.getvalue().encode("utf-8")


def _code_version() -> dict:
    try:
        from .. import __version__
        from ..versioning import code_hash
        return {"version": __version__, "code_hash": code_hash()}
    except Exception as e:  # noqa: BLE001 - recorded, never blocks the export
        return {"version": None, "code_hash": None, "error": type(e).__name__}


# ------------------------------------------------------------------------------------------------ README

def _readme(as_of: str, cut: dt.datetime, files: list[dict], counts: dict, checks: list[dict], options: dict,
            code: dict, withheld: list | None = None, redactions: list | None = None, lim: dict | None = None) -> str:
    withheld, redactions, lim = withheld or [], redactions or [], lim or {}
    altered_checks = [c for c in checks if c["status"] == "altered"]
    kinds = sorted(counts)
    unanchored = [c for c in checks if c["status"] == "unanchored"]
    failed = [c for c in checks if c["status"] == "failed"]
    has_replay = counts.get("replay_snapshot", {}).get("files", 0) > 0
    L = [f"# econquest data room, as of {as_of}", "",
         "Point-in-time export of the data inputs econquest held at the cutoff below, for independent validation "
         "(PI-5). Built by `econquest.ingestion.dataroom` (EQ-A-0041). Everything here is a byte copy of a file in the "
         "econquest data folder, or a row subset of an append-only file, selected by the as-of rule recorded for that "
         "file in MANIFEST.json. Nothing dated after the cutoff is included.", "",
         f"- as-of: `{as_of}`; cutoff (UTC, inclusive): `{_iso(cut)}`",
         f"- code: econquest {code.get('version')} (code hash `{code.get('code_hash')}`)",
         f"- files listed in MANIFEST.json: {len(files)} (this README and verify.py included)",
         f"- include_current: {options['include_current']}; include_restricted: {options.get('include_restricted', False)}",
         "",
         "## How to verify", "",
         "```", "python -I verify.py            # standard library only; exit 0 = VERIFIED", "python -I verify.py --json", "```", "",
         "verify.py recomputes the sha256 and size of every file in MANIFEST.json, reports missing, extra and changed "
         "files, recomputes `manifest_sha256` (SHA-256 of the canonical JSON of MANIFEST.json without "
         "`manifest_sha256` and `build`) and `content_sha256` (SHA-256 of `path=sha256;` over all files in path order), "
         "and re-runs the integrity anchors of each store: vintage content hashes against index.csv, snapshot and "
         "export manifests against their index.csv rows, frozen replay inputs against snapshots/index.csv, and the "
         "change-approval log's hash chain from genesis. Compare `manifest_sha256` with the value recorded in the "
         "evidence bundle or sent to you separately: a matching recomputed hash proves the room is the one exported.", "",
         "With econquest installed, `python -m econquest.ingestion.dataroom verify <room>` runs the same code.", "",
         "## Folders", "",
         "| path | what it is | as-of rule |", "|---|---|---|"]
    guide = [
        ("data/live/vintages/<id>/", "live pull vintages: what each IMF/World Bank/BIS/market pull returned (raw_*, live_inputs, provenance, review, unserved, feeds.json)", "live_vintage"),
        ("data/live/vintages/index.csv", "content hash and file count per vintage (the anchor)", "live_vintage_index"),
        ("data/panel/vintages/<id>/", "hazard panel and default-episode vintages", "panel_vintage"),
        ("data/live/market/snapshots/<id>/", "market quote snapshots (quotes.csv with licence column, manifest.json)", "market_snapshot"),
        ("data/market/cds_snapshots.csv", "gated CDS curve rows exported for the models", "cds_snapshots"),
        ("data/live/market/manual_quotes.csv", "hand-typed market quotes with author, approver and content hash", "manual_quotes"),
        ("data/live/events/<source>/vintages/<id>/", "event feed vintages (UCDP, GDELT, ACLED)", "event_vintage"),
        ("data/live/events/exports/<id>/", "archived event feed exports (events_long, events_weekly) as consumed", "event_export"),
        ("data/live/snapshots/<vintage>-inputs/", "frozen run inputs of an applied vintage (replay.freeze_inputs), with manifest.json", "replay_snapshot"),
        ("data/live/snapshots/<ts>-pre-apply/", "indicators/countries before an apply, forced_cells.csv", "pre_apply_snapshot"),
        ("data/live/review_ledger.csv", "review ledger: every gate decision and attestation with author, approver, self_approved", "review_ledger"),
        ("derived/four_eyes.csv", "the ledger rows with four-eyes / self-approval / attestation flags spelled out", "derived"),
        ("data/approvals/", "change-approval log (hash chained) and proposals for assumptions and limits", "approvals_log"),
        ("data/audit_trail.csv", "per-cell provenance of the run inputs (origin, source, series, transform, decision)", "audit_trail"),
        ("data/live/*.csv, *.json", "the current pull: transform_log, unserved, feed_failures, provenance, diff_vs_seed, review", "current_pull"),
        (LIMITATIONS_PATH, "data limitations register (GOV-010): per indicator source, coverage, seed share, gate holds, known issues", "limitations"),
    ]
    for path, what, kind in guide:
        L.append(f"| `{path}` | {what} | {RULES[kind]} |")
    L += ["", "## Contents by kind (this README not counted)", "", "| kind | files | bytes |", "|---|---:|---:|"]
    L += [f"| {k} | {counts[k]['files']} | {counts[k]['bytes']} |" for k in kinds]
    if lim.get("generated"):
        reg = (f"The data limitations register (per indicator source, coverage, seed share, gate holds, known issues) is "
               f"`{LIMITATIONS_PATH}`, generated for this as-of from `{lim.get('live_source')}`. Its two Register tables "
               "are computed; its narrative (summary, column notes, cross-cutting table) was written by hand "
               "(EQ-A-0042), may postdate the cutoff and is the one exception to the cutoff rule.")
    else:
        reg = (f"The data limitations register was not generated for this as-of ({lim.get('reason', 'not requested')}); "
               f"see `{LIMITATIONS_DOC}` in the econquest repository.")
    L += ["", "## Known limitations", "", reg, "",
          "- Legacy date-only vintage ids (`YYYY-MM-DD`) carry no time: they count as the end of that UTC day, "
          "so they enter a room only when the cutoff is at or after the end of that day.",
          "- `audit_trail.csv` is regenerated by every run. Rows retrieved after the cutoff are dropped, rows with no "
          "retrieved date (seed estimates, hand-entered values) are kept, and the remaining columns show the view of "
          "the run that last wrote the file, which can be later than the cutoff. The vintages and the ledger are the "
          "point-in-time record.",
          "- Current-pull files (`data/live/*.csv`, `*.json`) are dated as a whole by `live/feeds.json` `retrieved`, a "
          "date only. They are replaced by the next pull, so a room rebuilt later for the same as-of date may no longer "
          "contain them; the vintage folders hold what each pull returned.",
          "- Filtered row files (index.csv files, the ledger, approvals log, cds_snapshots, manual_quotes, audit_trail) "
          "are row subsets re-written with the csv module; values are unchanged, but when rows were dropped the file "
          "hash differs from the source file. Each such entry has `filter.rows_kept` in MANIFEST.json.",
          "- `approvals/head.json` is not exported: it names the current chain head. verify.py checks the exported "
          "prefix of the chain from genesis instead.",
          "- Secrets are never exported (`vendor_licences.json`, credential-named files, JSON with credential keys, "
          "text matching credential patterns). Licence tags inside the data are kept. Exclusions are listed under "
          "`build.excluded` in MANIFEST.json, outside the hash."]
    if withheld:
        L.append(f"- {len(withheld)} file(s) withheld because their licence does not allow passing them to an external "
                 "validator, or because they could not be scanned for secrets (listed under `withheld` in "
                 "MANIFEST.json with size, sha256 and reason; verify.py does not report them missing): "
                 + ", ".join(f"`{w['path']}`" for w in withheld[:10]) + (" ..." if len(withheld) > 10 else ""))
    restricted = [r for r in redactions if r.get("restricted_cells")]
    if restricted:
        L.append(f"- Values derived from Yahoo Finance data (personal, non-commercial terms; replaced by official "
                 f"sources on 2026-10-23) are blank in {len(restricted)} file(s), "
                 f"{sum(r['restricted_cells'] for r in restricted)} cell(s) in "
                 f"{sum(r['restricted_rows'] for r in restricted)} row(s); the source labels are kept, so each blank "
                 "is traceable (listed under `redactions` in MANIFEST.json with the original sha256 and size): "
                 + ", ".join(f"`{r['path']}`" for r in restricted[:10]) + (" ..." if len(restricted) > 10 else ""))
    emails = [r for r in redactions if r.get("replacements")]
    if emails:
        L.append(f"- E-mail addresses were replaced by `{REDACTED_EMAIL}` in {len(emails)} file(s), "
                 f"{sum(r['replacements'] for r in emails)} replacement(s) (listed under `redactions` in "
                 "MANIFEST.json with the original sha256 and size).")
    if altered_checks:
        L.append(f"- {len(altered_checks)} anchor(s) are `altered`: a vintage content hash (or the approvals chain) covers "
                 "the original bytes of a withheld or redacted file, so verify.py checks the index row against what the "
                 "build verified on the source (`altered_anchors` in MANIFEST.json) instead of recomputing it: "
                 + ", ".join(f"`{c['path']}`" for c in altered_checks[:10]))
    if not has_replay:
        L.append("- No frozen replay-input snapshot (`replay.freeze_inputs`) exists at or before the cutoff, so the "
                 "applied working files a run reads (indicators.csv, countries.csv, market_history, panel CSVs, "
                 "hand-entered CSVs) are not in this room: they are undated working copies. Rebuild from the vintages, "
                 "or build with include_current when the as-of date is the latest record.")
    if options["include_current"]:
        L.append("- include_current was set: files of kind `current_working_copy` are copied as they were at build "
                 "time. That was allowed because no dated record in the data is after the cutoff; they are not "
                 "anchored by any vintage.")
    if unanchored:
        L.append(f"- {len(unanchored)} folder(s) have no index row to anchor them (reported as `unanchored` by "
                 "verify.py): " + ", ".join(f"`{c['path']}`" for c in unanchored[:10]) + (" ..." if len(unanchored) > 10 else ""))
    if failed:
        L.append(f"- {len(failed)} integrity anchor(s) FAILED at build time (source data inconsistent): "
                 + ", ".join(f"`{c['path']}`" for c in failed[:10]))
    return "\n".join(L) + "\n"


# ------------------------------------------------------------------------------------------------ build / verify

def _limitations_entry(d: Path, as_of) -> tuple[dict | None, dict]:
    """(room entry for limitations/data-limitations.md or None, the manifest's `limitations` record)."""
    from .limitations import build_register
    try:
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "data-limitations.md"
            stats = build_register(d, p, as_of=as_of)
            body = p.read_bytes()
    except (ValueError, FileNotFoundError, KeyError) as e:   # pandas parse errors are ValueErrors
        reason = str(e).replace(str(d.resolve()), "<data>").replace(str(d), "<data>")
        return None, {"generated": False, "reason": f"{type(e).__name__}: {reason}"}
    return ({"path": LIMITATIONS_PATH, "source": "econquest/ingestion/limitations.py", "kind": "limitations", "body": body},
            {"generated": True, "path": LIMITATIONS_PATH, "live_source": stats["live_source"],
             "narrative": "header, column notes and cross-cutting table hand-written (EQ-A-0042); "
                          "the two Register tables computed for this as-of"})


def build_data_room(data_dir, as_of, out_dir, *, include_current: bool = False, now: dt.datetime | None = None,
                    include_restricted: bool = False, limitations: bool = True) -> dict:
    """Export the point-in-time data room for `as_of` from `data_dir` into `out_dir` (must not exist or be empty, and
    must not lie inside data_dir). Returns the manifest written to out_dir/MANIFEST.json. `now` fixes the build time
    (tests). Raises ValueError for a bad as_of, an out_dir inside data_dir, or include_current with a dated record
    after the cutoff; FileExistsError when out_dir is not empty; FileNotFoundError when data_dir is missing.
    include_restricted=True keeps licence-restricted files (raw_yahoo.csv, non-commercial/personal licence columns),
    which are withheld by default, and the Yahoo-derived values that are otherwise blanked (SEC-A-006 M2); limitations=False skips the generated data limitations register. E-mail addresses
    are always redacted in the copies (module docstring)."""
    d = Path(data_dir)
    if not d.is_dir():
        raise FileNotFoundError(f"data_dir {d} is not a folder")
    out = Path(out_dir)
    dr, outr = d.resolve(), out.resolve()
    if outr == dr or dr in outr.parents:
        raise ValueError(f"out_dir {out} must not be inside data_dir {d}")
    if out.exists() and (not out.is_dir() or any(out.iterdir())):
        raise FileExistsError(f"{out} is not empty")
    label, cut = cutoff_of(as_of)
    entries, excluded, filtered, seen, withheld = _plan(d, cut, include_current, include_restricted)
    if include_current:
        later = [t for t in seen if t > cut]
        if later:
            raise ValueError(f"include_current refused: the data holds records dated after the cutoff {_iso(cut)} "
                             f"(latest {_iso(max(later))}), so its working copies may already contain later data")
    ledger = [e for e in entries if e["kind"] == "review_ledger"]
    if ledger:
        entries.append({"path": DERIVED_FOUR_EYES, "source": "live/review_ledger.csv", "kind": "derived",
                        "body": _four_eyes(ledger[0]["body"])})
    entries.append({"path": "verify.py", "source": "econquest/ingestion/dataroom_verify.py", "kind": "verify_script",
                    "body": VERIFY_SOURCE.read_bytes()})
    lim = {"generated": False, "reason": "not requested (limitations=False)"}
    if limitations:
        e, lim = _limitations_entry(d, as_of)
        if e is not None:
            entries.append(e)
    # e-mail addresses redacted at source, before hashing (SEC-C-008 R6), after the Yahoo-derived values were blanked
    # (SEC-A-006 M2, in _plan); the original sha256 (before either change) is recorded
    redactions = []
    for e in entries:
        body, n = redact_emails(e["body"])
        if n or e.get("restricted"):
            orig = e.get("original", e["body"])
            r = {"path": e["path"], "replacements": n, "original_sha256": hashlib.sha256(orig).hexdigest(),
                 "original_size": len(orig)}
            if e.get("restricted"):
                r.update(restricted_rows=e["restricted"]["restricted_rows"],
                         restricted_cells=e["restricted"]["restricted_cells"],
                         restricted_rule=e["restricted"]["rule"],
                         reason="restricted source: Yahoo-derived (or non-commercial / personal licence) values blanked "
                                "(SEC-A-006 M2)")
            redactions.append(r)
            e["body"] = body
    redactions.sort(key=lambda r: r["path"])
    withheld.sort(key=lambda r: r["path"])
    altered = altered_map({"withheld": withheld, "redactions": redactions})
    altered_anchors = _altered_anchors(d, altered)
    if "data/approvals/log.jsonl" in altered:              # chain verified on the original (kept-rows) bytes
        from .dataroom_verify import chain_problem
        prob, n = chain_problem(filter_jsonl((d / "approvals" / "log.jsonl").read_bytes(), cut, [])[0].decode("utf-8"))
        altered_anchors["data/approvals/log.jsonl"] = {"verified_at_build": prob or "ok", "rows": n}
    code = _code_version()
    options = {"include_current": bool(include_current), "include_restricted": bool(include_restricted),
               "limitations": bool(limitations)}

    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = Path(tempfile.mkdtemp(dir=out.parent, prefix=f".{out.name}.dataroom."))
    try:
        def write(e):
            p = tmp / e["path"]
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(e["body"])

        for e in entries:
            write(e)
        # integrity anchors on the room's own copies (same code as verify.py); recorded in the hashed manifest
        checks = _anchor_checks(tmp, altered, altered_anchors)

        def entry(e):
            r = {"path": e["path"], "size": len(e["body"]), "sha256": hashlib.sha256(e["body"]).hexdigest(),
                 "source": e["source"], "kind": e["kind"], "as_of_rule": RULES[e["kind"]]}
            if "filter" in e:
                r["filter"] = e["filter"]
            return r

        files = [entry(e) for e in entries]
        counts: dict = {}
        for f in files:
            c = counts.setdefault(f["kind"], {"files": 0, "bytes": 0})
            c["files"] += 1; c["bytes"] += f["size"]
        readme = {"path": "README.md", "source": None, "kind": "readme",
                  "body": _readme(label, cut, files + [{"path": "README.md"}], counts, checks, options, code,
                                  withheld, redactions, lim).encode("utf-8")}
        write(readme)
        files.append(entry(readme))
        c = counts.setdefault("readme", {"files": 0, "bytes": 0})
        c["files"] += 1; c["bytes"] += files[-1]["size"]
        files.sort(key=lambda f: f["path"])
        manifest = {"schema": SCHEMA, "as_of": label, "cutoff_utc": _iso(cut), "code": code, "options": options,
                    "rules": {k: RULES[k] for k in sorted({f["kind"] for f in files})},
                    "counts": dict(sorted(counts.items())),
                    "totals": {"files": len(files), "bytes": sum(f["size"] for f in files)},
                    "files": files, "checks": checks, "withheld": [{k: w[k] for k in ("path", "size", "sha256", "reason")}
                                                                   for w in withheld],
                    "redactions": redactions, "altered_anchors": altered_anchors, "limitations": lim,
                    "content_sha256": content_hash(files)}
        manifest["manifest_sha256"] = manifest_hash(manifest)
        built = (now or dt.datetime.now(dt.timezone.utc))
        built = built.replace(tzinfo=dt.timezone.utc) if built.tzinfo is None else built.astimezone(dt.timezone.utc)
        manifest["build"] = {"built_utc": built.strftime("%Y-%m-%dT%H:%M:%SZ"), "source_data_dir": dr.name,     # basename only: the manifest ships in the evidence bundle
                             "python": platform.python_version(), "builder": "econquest.ingestion.dataroom",
                             "ticket": "EQ-A-0041", "excluded": excluded, "filtered": filtered,
                             "note": "build is outside manifest_sha256 and content_sha256"}
        (tmp / MANIFEST_NAME).write_text(json.dumps(manifest, indent=1, sort_keys=True) + "\n", encoding="utf-8")
        for p in tmp.rglob("*"):
            if p.is_file():
                os.chmod(p, 0o444)
        # B103: the room folder is 0o755 (owner rwx, others r-x), like the replay snapshots; every file is 0o444
        os.chmod(tmp, 0o755)  # nosec B103
        if out.exists():
            out.rmdir()                               # empty (checked above); fails if a racer filled it
        os.rename(tmp, out)
    except BaseException:
        shutil.rmtree(tmp, ignore_errors=True)
        raise
    return manifest


def home_dir() -> Path:
    """The folder holding data/ and outputs/, resolved as econquest/cli.py does: $ECONQUEST_HOME, else the checkout."""
    return Path(os.environ.get("ECONQUEST_HOME", Path(__file__).resolve().parent.parent.parent))


def default_room_dir(as_of, outputs_dir=None) -> Path:
    """Where `dataroom build` writes by default and where `econquest evidence --as-of` (EQ-C-0060) looks:
    <outputs>/dataroom/<as_of>, <outputs> being outputs_dir or <home>/outputs. A date-time as_of drops its colons."""
    label = cutoff_of(as_of)[0].replace(":", "")
    return Path(outputs_dir if outputs_dir is not None else home_dir() / "outputs") / "dataroom" / label


def verify_data_room(path) -> dict:
    """Recompute every file hash, the size, manifest_sha256 and content_sha256, list missing / extra / changed files
    and re-run the integrity anchors (dataroom_verify.verify_room, the code the room's verify.py runs). `ok` is True
    only when nothing is missing, extra or changed, both hashes match and no anchor failed."""
    return verify_room(path)


def main(argv=None) -> int:
    from .dataroom_verify import format_report
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.dataroom",
                                 description="Validator data room (EQ-A-0041): point-in-time export and verification")
    sub = ap.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("build", help="export the data room for one as-of date")
    b.add_argument("--data", default=None, help="econquest data folder (default: <ECONQUEST_HOME or checkout>/data)")
    b.add_argument("--as-of", required=True, help="YYYY-MM-DD (end of that UTC day) or an ISO date-time")
    b.add_argument("--out", default=None, help="room folder (must not exist or be empty; not inside --data; "
                                                "default <outputs>/dataroom/<as_of>)")
    b.add_argument("--outputs", default=None, help="outputs folder for the default --out (default <home>/outputs)")
    b.add_argument("--include-current", action="store_true",
                   help="also copy undated working copies (refused when any record is dated after the cutoff)")
    b.add_argument("--include-restricted", action="store_true",
                   help="keep licence-restricted files (raw_yahoo.csv, non-commercial/personal licence columns) and "
                        "Yahoo-derived values (blanked by default); only when Sam confirms the licence allows passing "
                        "them on")
    b.add_argument("--no-limitations", action="store_true", help="do not generate limitations/data-limitations.md")
    b.add_argument("--json", action="store_true", help="print the manifest summary as JSON")
    v = sub.add_parser("verify", help="verify a data room (same checks as its verify.py)")
    v.add_argument("room"); v.add_argument("--json", action="store_true")
    a = ap.parse_args(argv)
    if a.cmd == "build":
        try:
            a.data = a.data or str(home_dir() / "data")
            a.out = a.out or str(default_room_dir(a.as_of, a.outputs))
            m = build_data_room(a.data, a.as_of, a.out, include_current=a.include_current,
                                include_restricted=a.include_restricted, limitations=not a.no_limitations)
        except (ValueError, FileExistsError, FileNotFoundError) as e:
            print(f"dataroom build: {e}", file=sys.stderr)
            return 2
        summary = {"out": str(a.out), "as_of": m["as_of"], "cutoff_utc": m["cutoff_utc"], "files": m["totals"]["files"],
                   "bytes": m["totals"]["bytes"], "manifest_sha256": m["manifest_sha256"],
                   "content_sha256": m["content_sha256"], "counts": m["counts"], "excluded": len(m["build"]["excluded"]),
                   "withheld": len(m["withheld"]), "redacted_files": len(m["redactions"]),
                   "limitations": m["limitations"]["generated"],
                   "anchors_failed": sum(c["status"] == "failed" for c in m["checks"]),
                   "anchors_unanchored": sum(c["status"] == "unanchored" for c in m["checks"])}
        if a.json:
            print(json.dumps(summary, indent=1, sort_keys=True))
        else:
            print(f"data room {a.out}: as of {m['as_of']} (cutoff {m['cutoff_utc']}), {summary['files']} files, "
                  f"{summary['bytes']} bytes, {summary['excluded']} source files excluded\n"
                  f"manifest_sha256 {m['manifest_sha256']}\n"
                  + "\n".join(f"  {k}: {c['files']} files, {c['bytes']} bytes" for k, c in m["counts"].items()))
        return 0
    rep = verify_data_room(a.room)
    print(json.dumps(rep, indent=1, sort_keys=True) if a.json else format_report(rep))
    return 0 if rep["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
