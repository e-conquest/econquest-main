"""Market History tab -> data/market_history/prices.csv.

The workbook's Market History tab holds one GOOGLEFINANCE block per series: a two-column (date, price) block whose
heading is in row 2 ("Vietnam USDVND", "", "Philippines USDPHP", "", ...). This module turns the raw cell values
(as returned by the Sheets API values.get, i.e. a list of rows) into the wide prices table the GARCH and
econometrics layers read."""
from __future__ import annotations
import json
from pathlib import Path
import pandas as pd


def parse_sheet_values(values: list[list], headings: list[str] | None = None) -> pd.DataFrame:
    """values: rows of the Market History tab starting at row 2 (the heading row). Returns a wide DataFrame
    indexed by date with one column per ticker (the last word of each heading)."""
    if not values:
        return pd.DataFrame()
    head = headings or [str(h) for h in values[0]]
    body = values[1:]
    series = {}
    for col in range(0, len(head), 2):
        h = str(head[col]).strip()
        if not h:
            continue
        ticker = h.split()[-1]
        dates, px = [], []
        for r in body:
            if len(r) <= col + 1 or r[col] in ("", None) or r[col + 1] in ("", None):
                continue
            d = pd.to_datetime(str(r[col]), errors="coerce")
            if pd.isna(d):
                continue                                   # header rows such as "Date"/"Close"
            try:
                v = float(str(r[col + 1]).replace(",", ""))
            except ValueError:
                continue
            dates.append(d.normalize()); px.append(v)
        if dates:
            s = pd.Series(px, index=pd.DatetimeIndex(dates))
            series[ticker] = s[~s.index.duplicated(keep="last")].sort_index()
    df = pd.DataFrame(series).sort_index()
    df.index.name = "date"
    return df


def merge_prices(existing: pd.DataFrame | None, new: pd.DataFrame) -> pd.DataFrame:
    """Keep every date already stored (point-in-time: a price once recorded is not rewritten) and add new dates
    and columns. Where both have a value for the same date, the new one wins only if the old one is missing."""
    if existing is None or existing.empty:
        return new
    out = existing.combine_first(new)
    out.index.name = "date"
    return out.sort_index()


def update_prices_from_sheet_json(json_path: str | Path, data_dir: str | Path, headings: list[str] | None = None) -> tuple[Path, dict]:
    """json_path: one or more saved values.get results (a JSON object with "values", or a list of such objects, or
    a bare list of rows). Writes data/market_history/prices.csv and returns (path, summary)."""
    raw = json.loads(Path(json_path).read_text())
    blobs = raw if isinstance(raw, list) and raw and isinstance(raw[0], dict) else [raw]
    rows: list[list] = []
    for b in blobs:
        rows += b["values"] if isinstance(b, dict) else b
    new = parse_sheet_values(rows, headings)
    out = Path(data_dir) / "market_history" / "prices.csv"
    old = pd.read_csv(out, index_col=0, parse_dates=True) if out.exists() else None
    merged = merge_prices(old, new)
    out.parent.mkdir(parents=True, exist_ok=True)
    merged.to_csv(out)
    summary = {"series": int(merged.shape[1]), "dates": int(len(merged)), "first": str(merged.index.min().date()) if len(merged) else None,
               "last": str(merged.index.max().date()) if len(merged) else None,
               "new_dates": int(len(new.index.difference(old.index))) if old is not None and len(new) else int(len(new))}
    return out, summary
