"""Official sovereign default panel: import the Bank of Canada-Bank of England sovereign default database (CRAG).

Replaces the hand-compiled `data/panel/sovereign_defaults.csv` with episodes derived from the official workbook
(EQ-A-0008, GOV-044). Three entry points:

* `import_crag(xlsx_path, out_csv, source_label, vintage)` reads the workbook (or a CSV export / the Valet CSV),
  sums the in-scope creditor categories per country-year and writes one row per default spell in the
  `sovereign_defaults.csv` schema (iso, country, start, end, creditors, note) plus two trailing provenance columns,
  `source` and `source_vintage`. `hazard_panel.load_default_events` checks only for iso/start/end and keeps
  extra columns, so the file stays a drop-in replacement.
* `compare_panels(old_csv, new_csv)` pairs episodes by country and overlapping years and returns what was
  added, removed and changed, for review by Sam and Team B before any refit.
* `checksum(path)` is the SHA-256 recorded for provenance.

Scope rule (data/panel/README.md): private creditors and local-currency debt only, i.e. foreign-currency bank
loans, foreign-currency bonds and local-currency debt. Official creditors (IMF, IBRD, IDA, IADB, Paris Club, China,
other official), domestic/fiscal arrears and other private (supplier) credit are excluded, so arrears to official
creditors alone never make a spell. Aggregate columns (TOTAL, PRIVATE_CREDITORS) are never summed, to avoid
double counting.

Layout. The 2026 edition is published as an xlsx and as Valet group DEBT_2026, whose series are COUNTRY,
COUNTRY_GROUP, YEAR, TOTAL, IMF, IBRD, IDA, IADB, PARIS_CLUB, CHINA, OTHER_OFFICIAL_CREDITORS, PRIVATE_CREDITORS,
FC_BANK_LOANS, FC_BONDS, LC_DEBT, FISCAL_ARREARS, ... (each suffixed _2026): a LONG table, one row per country-year,
one column per creditor category. The xlsx sheet layout is assumed to match but was not inspected, so the parser
also accepts the older WIDE layout (one row per country and category, years as columns) and every name is
configurable (`sheet`, `country_col`, `year_col`, `iso_col`, `category_map`).
"""
from __future__ import annotations

import hashlib
import re
from pathlib import Path

import pandas as pd

from ..common_format import escape_formula

SCHEMA = ["iso", "country", "start", "end", "creditors", "note"]
PROVENANCE = ["source", "source_vintage"]

# canonical category -> label written to the creditors column
IN_SCOPE = {"FC_BANK_LOANS": "bank loans", "FC_BONDS": "bonds", "LC_DEBT": "LC debt"}

COUNTRY_NAMES = ("COUNTRY", "COUNTRY_NAME", "ECONOMY", "SOVEREIGN", "NAME")
YEAR_NAMES = ("YEAR", "DATE", "PERIOD")
ISO_NAMES = ("ISO", "ISO3", "ISO_CODE", "ISO3_CODE", "COUNTRY_CODE", "CODE")
CATEGORY_NAMES = ("CREDITOR", "CREDITORS", "CATEGORY", "TYPE", "INSTRUMENT", "CREDITOR_CATEGORY", "SERIES")
AGGREGATE_ROWS = re.compile(r"^(?:world|global|total|all|grand total|sum)\b|countries|economies|^hipc|^ssa\b|^other$", re.I)

ISO3_RE = re.compile(r"[A-Z]{3}")
REPO_DATA = Path(__file__).resolve().parents[2] / "data"

# Reference ISO 3166-1 alpha-3 codes by country name, with the name variants used by the World Bank, the IMF and the
# BoC-BoE database (keys are normalised by _name_key, so case, punctuation and spaces do not matter). Lowest
# precedence: an ISO column in the file, iso_map / iso_map_csv and the repo's own tables override it. XKX (Kosovo)
# follows the World Bank; the IMF uses UVK.
ISO3_NAMES = """
AFG|Afghanistan|Afghanistan, Islamic Republic of|Islamic Republic of Afghanistan
ALB|Albania
DZA|Algeria
AGO|Angola
ATG|Antigua and Barbuda|Antigua & Barbuda
ARG|Argentina
ARM|Armenia|Armenia, Republic of
ABW|Aruba|Aruba, Kingdom of the Netherlands
AUS|Australia
AUT|Austria
AZE|Azerbaijan|Azerbaijan, Republic of
BHS|Bahamas|The Bahamas|Bahamas, The|Bahamas, the
BHR|Bahrain|Bahrain, Kingdom of
BGD|Bangladesh
BRB|Barbados
BLR|Belarus|Belarus, Republic of
BEL|Belgium
BLZ|Belize
BEN|Benin
BTN|Bhutan
BOL|Bolivia|Bolivia, Plurinational State of|Plurinational State of Bolivia
BIH|Bosnia and Herzegovina|Bosnia & Herzegovina|Bosnia-Herzegovina
BWA|Botswana
BRA|Brazil
BRN|Brunei Darussalam|Brunei
BGR|Bulgaria
BFA|Burkina Faso
BDI|Burundi
CPV|Cabo Verde|Cape Verde
KHM|Cambodia
CMR|Cameroon
CAN|Canada
CAF|Central African Republic|Central African Rep.|CAR
TCD|Chad
CHL|Chile
CHN|China|China, People's Republic of|People's Republic of China|China, P.R.: Mainland
COL|Colombia
COM|Comoros|Comoros, Union of the
COD|Congo, Dem. Rep.|Congo, Democratic Republic of the|Democratic Republic of the Congo|Congo DR|DR Congo|Congo, Dem. Rep. of|Zaire|Congo (Kinshasa)
COG|Congo, Rep.|Congo, Republic of|Republic of Congo|Congo|Congo (Brazzaville)|Congo, Rep. of
CRI|Costa Rica
CIV|Cote d'Ivoire|Côte d'Ivoire|Ivory Coast
HRV|Croatia|Croatia, Republic of
CUB|Cuba
CYP|Cyprus
CZE|Czech Republic|Czechia
DNK|Denmark
DJI|Djibouti
DMA|Dominica
DOM|Dominican Republic|Dominican Rep.
ECU|Ecuador
EGY|Egypt|Egypt, Arab Rep.|Arab Republic of Egypt
SLV|El Salvador
GNQ|Equatorial Guinea
ERI|Eritrea|Eritrea, The State of
EST|Estonia|Estonia, Republic of
SWZ|Eswatini|Eswatini, Kingdom of|Swaziland
ETH|Ethiopia|Ethiopia, The Federal Democratic Republic of
FJI|Fiji|Fiji, Republic of
FIN|Finland
FRA|France
GAB|Gabon
GMB|Gambia|The Gambia|Gambia, The|Gambia, the
GEO|Georgia
DEU|Germany
GHA|Ghana
GRC|Greece
GRD|Grenada
GTM|Guatemala
GIN|Guinea
GNB|Guinea-Bissau|Guinea Bissau
GUY|Guyana
HTI|Haiti
HND|Honduras
HKG|Hong Kong SAR, China|Hong Kong SAR|Hong Kong
HUN|Hungary
ISL|Iceland
IND|India
IDN|Indonesia
IRN|Iran|Iran, Islamic Rep.|Iran, Islamic Republic of|Islamic Republic of Iran
IRQ|Iraq
IRL|Ireland
ISR|Israel
ITA|Italy
JAM|Jamaica
JPN|Japan
JOR|Jordan
KAZ|Kazakhstan|Kazakhstan, Republic of
KEN|Kenya
KIR|Kiribati
PRK|Korea, Dem. People's Rep.|North Korea|Korea, Democratic People's Republic of|Democratic People's Republic of Korea
KOR|Korea|Korea, Rep.|Korea, Republic of|South Korea|Republic of Korea
XKX|Kosovo|Kosovo, Republic of
KWT|Kuwait
KGZ|Kyrgyz Republic|Kyrgyzstan
LAO|Lao PDR|Lao P.D.R.|Laos|Lao People's Democratic Republic
LVA|Latvia
LBN|Lebanon
LSO|Lesotho|Lesotho, Kingdom of
LBR|Liberia
LBY|Libya
LTU|Lithuania
LUX|Luxembourg
MAC|Macao SAR, China|Macao SAR|Macao|Macau
MDG|Madagascar|Madagascar, Republic of
MWI|Malawi
MYS|Malaysia
MDV|Maldives
MLI|Mali
MLT|Malta
MHL|Marshall Islands|Marshall Islands, Republic of the
MRT|Mauritania|Mauritania, Islamic Republic of
MUS|Mauritius
MEX|Mexico
FSM|Micronesia|Micronesia, Fed. Sts.|Micronesia, Federated States of
MDA|Moldova|Moldova, Republic of
MNG|Mongolia
MNE|Montenegro
MAR|Morocco
MOZ|Mozambique|Mozambique, Republic of
MMR|Myanmar|Burma
NAM|Namibia
NRU|Nauru|Nauru, Republic of
NPL|Nepal
NLD|Netherlands|The Netherlands|Netherlands, The
NZL|New Zealand
NIC|Nicaragua
NER|Niger
NGA|Nigeria
MKD|North Macedonia|North Macedonia, Republic of|Macedonia|Macedonia, FYR|FYR Macedonia
NOR|Norway
OMN|Oman
PAK|Pakistan
PLW|Palau|Palau, Republic of
PSE|West Bank and Gaza|West Bank & Gaza|Palestine|West Bank and Gaza Strip
PAN|Panama
PNG|Papua New Guinea
PRY|Paraguay
PER|Peru
PHL|Philippines
POL|Poland|Poland, Republic of
PRT|Portugal
PRI|Puerto Rico
QAT|Qatar
ROU|Romania
RUS|Russia|Russian Federation
RWA|Rwanda
WSM|Samoa
SMR|San Marino|San Marino, Republic of
STP|Sao Tome and Principe|São Tomé and Príncipe|Sao Tome & Principe|Democratic Republic of Sao Tome and Principe
SAU|Saudi Arabia
SEN|Senegal
SRB|Serbia|Serbia, Republic of
SYC|Seychelles
SLE|Sierra Leone
SGP|Singapore
SVK|Slovak Republic|Slovakia
SVN|Slovenia|Slovenia, Republic of
SLB|Solomon Islands
SOM|Somalia
ZAF|South Africa
SSD|South Sudan|South Sudan, Republic of
ESP|Spain
LKA|Sri Lanka
KNA|St. Kitts and Nevis|Saint Kitts and Nevis|St Kitts and Nevis|St. Kitts & Nevis
LCA|St. Lucia|Saint Lucia|St Lucia
VCT|St. Vincent and the Grenadines|Saint Vincent and the Grenadines|St Vincent and the Grenadines|St. Vincent & the Grenadines
SDN|Sudan
SUR|Suriname
SWE|Sweden
CHE|Switzerland
SYR|Syrian Arab Republic|Syria
TWN|Taiwan|Taiwan Province of China|Taiwan, China
TJK|Tajikistan
TZA|Tanzania|Tanzania, United Republic of|United Republic of Tanzania
THA|Thailand
TLS|Timor-Leste|East Timor|Timor-Leste, Democratic Republic of
TGO|Togo
TON|Tonga
TTO|Trinidad and Tobago|Trinidad & Tobago
TUN|Tunisia
TUR|Turkey|Turkiye|Türkiye|Türkiye, Republic of
TKM|Turkmenistan
TUV|Tuvalu
UGA|Uganda
UKR|Ukraine
ARE|United Arab Emirates|UAE
GBR|United Kingdom|UK
USA|United States|United States of America|USA
URY|Uruguay
UZB|Uzbekistan|Uzbekistan, Republic of
VUT|Vanuatu
VEN|Venezuela|Venezuela, RB|Venezuela, República Bolivariana de|Venezuela, Bolivarian Republic of
VNM|Vietnam|Viet Nam
YEM|Yemen|Yemen, Rep.|Yemen, Republic of
ZMB|Zambia
ZWE|Zimbabwe
"""


def checksum(path: str | Path) -> str:
    """SHA-256 hex digest of a file."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def _norm(label) -> str:
    """'DEBT_FC_BONDS_2026' / 'FC bonds' / 'FC Bonds (USD mm)' -> 'FC_BONDS'."""
    s = re.sub(r"\(.*?\)", "", str(label)).strip().upper()
    s = re.sub(r"[^A-Z0-9]+", "_", s).strip("_")
    s = re.sub(r"^DEBT_", "", s)
    s = re.sub(r"_(19|20)\d\d$", "", s)
    return s


def canonical_category(label) -> str | None:
    """Map a creditor/instrument label to a canonical category. Only IN_SCOPE keys are summed."""
    s = _norm(label)
    if not s or re.match(r"^(DEFRATE|DEF_|GROSS|SHARE|PCT|RATE|NUMBER|COUNT|N_)", s):
        return None
    if "ARREAR" in s:
        return "ARREARS"
    if re.search(r"(^|_)(LC|LOCAL|DOMESTIC)(_|$)", s) or "LOCAL_CURRENCY" in s:
        return "LC_DEBT"
    if any(k in s for k in ("IMF", "IBRD", "IDA", "IADB", "PARIS", "CHINA", "OFFICIAL", "WORLD_BANK", "MULTILATERAL", "BILATERAL")):
        return "OFFICIAL"
    if "SUPPLIER" in s or "OTHER_PRIVATE" in s:
        return "OTHER_PRIVATE"
    if "BANK" in s:
        return "FC_BANK_LOANS"
    if "BOND" in s or "SECURIT" in s:
        return "FC_BONDS"
    if "PRIVATE" in s:
        return "PRIVATE_TOTAL"
    if s == "TOTAL" or s.startswith("TOTAL"):
        return "TOTAL"
    return None


def _is_year(v) -> int | None:
    """2025, 2025.0, '2025', '2025-01-01' -> 2025; anything else -> None."""
    s = str(v).strip()
    m = re.match(r"^(\d{4})-\d\d", s)
    if m:
        s = m.group(1)
    try:
        f = float(s)
    except ValueError:
        return None
    return int(f) if f == int(f) and 1900 <= f <= 2100 else None


def _read_frames(path: Path, sheet) -> list[tuple[str, pd.DataFrame]]:
    if path.suffix.lower() in (".xlsx", ".xlsm", ".xls"):
        sheets = pd.read_excel(path, sheet_name=sheet if sheet is not None else None, header=None)
        if isinstance(sheets, pd.DataFrame):
            return [(str(sheet), sheets)]
        return [(str(k), v) for k, v in sheets.items()]
    import csv
    with open(path, newline="", encoding="utf-8-sig") as f:
        rows = list(csv.reader(f))
    width = max((len(r) for r in rows), default=0)
    return [(path.name, pd.DataFrame([r + [None] * (width - len(r)) for r in rows]))]


def _find_table(frames, country_col, year_col, max_scan=300):
    """Return (sheet, layout, header_row_index, DataFrame with named columns). layout is 'long' or 'wide'."""
    want_country = {_norm(country_col)} if country_col else set(COUNTRY_NAMES)
    want_year = {_norm(year_col)} if year_col else set(YEAR_NAMES)
    tried = []
    for name, raw in frames:
        for i in range(min(max_scan, len(raw))):
            cells = [_norm(c) if pd.notna(c) else "" for c in raw.iloc[i].tolist()]
            has_country = any(c in want_country for c in cells)
            n_cat = sum(canonical_category(c) in IN_SCOPE for c in cells)
            n_years = sum(_is_year(c) is not None for c in raw.iloc[i].tolist() if pd.notna(c))
            if has_country and any(c in want_year for c in cells) and n_cat >= 1:
                layout = "long"
            elif has_country and n_years >= 8:
                layout = "wide"
            else:
                continue
            df = raw.iloc[i + 1:].copy()
            df.columns = [str(c).strip() if pd.notna(c) else f"_col{j}" for j, c in enumerate(raw.iloc[i].tolist())]
            return name, layout, i, df.reset_index(drop=True)
        tried.append(name)
    raise ValueError(
        f"no CRAG table found in sheets {tried}: expected a header row with a country column {sorted(want_country)} and either "
        f"a year column {sorted(want_year)} plus creditor-category columns (FC_BANK_LOANS, FC_BONDS, LC_DEBT), or at least 8 year "
        "columns. Pass sheet=, country_col=, year_col= or category_map= to match this edition.")


def _col(df, wanted, explicit):
    if explicit:
        for c in df.columns:
            if c == explicit or _norm(c) == _norm(explicit):
                return c
        raise ValueError(f"column {explicit!r} not in {list(df.columns)}")
    for w in wanted:  # wanted is ordered by preference (YEAR before DATE)
        for c in df.columns:
            if _norm(c) == w:
                return c
    return None


def _long_amounts(df, layout, country_col, year_col, iso_col, category_map, category_col):
    """Country-year-category amounts (long) from either layout."""
    ccol = _col(df, COUNTRY_NAMES, country_col)
    icol = _col(df, ISO_NAMES, iso_col)
    cat_of = (lambda c: category_map.get(c, category_map.get(_norm(c), canonical_category(c)))) if category_map else canonical_category
    if layout == "long":
        ycol = _col(df, YEAR_NAMES, year_col)
        cats = {c: cat_of(c) for c in df.columns if c not in (ccol, ycol, icol)}
        cats = {c: k for c, k in cats.items() if k in IN_SCOPE}
        exact = {c: k for c, k in cats.items() if _norm(c) in IN_SCOPE}
        if exact and not category_map:  # the edition names the categories exactly: ignore look-alike columns
            cats = exact
        ids = [ccol, ycol] + ([icol] if icol else [])
        out = df[ids + list(cats)].melt(id_vars=ids, var_name="raw_cat", value_name="amt")
        out["category"] = out["raw_cat"].map(cats)
        out["year"] = out[ycol].map(_is_year)
    else:
        kcol = _col(df, CATEGORY_NAMES, category_col)
        if kcol is None:
            raise ValueError("wide CRAG layout needs a creditor/category column; pass category_col=")
        ycols = [c for c in df.columns if _is_year(c) is not None]
        ids = [ccol, kcol] + ([icol] if icol else [])
        out = df[ids + ycols].melt(id_vars=ids, var_name="ycol", value_name="amt")
        out["category"] = out[kcol].map(cat_of)
        out["year"] = out["ycol"].map(_is_year)
    out = out.rename(columns={ccol: "country", **({icol: "iso_src"} if icol else {})})
    out["country"] = out["country"].astype(str).str.strip()
    out = out[out["category"].isin(list(IN_SCOPE)) & out["year"].notna()]
    out = out[~out["country"].isin(["", "nan", "None"]) & ~out["country"].str.contains(AGGREGATE_ROWS)]
    out["amt"] = pd.to_numeric(out["amt"], errors="coerce").fillna(0.0).astype(float)
    out["year"] = out["year"].astype(int)
    keep = ["country", "year", "category", "amt"] + (["iso_src"] if icol else [])
    return out[keep]


def _name_key(name: str) -> str:
    return re.sub(r"[^a-z]", "", str(name).lower().replace("&", "and"))


def default_iso_lookup(extra: dict[str, str] | None = None, map_csv: str | Path | None = None) -> dict[str, str]:
    """Country name -> ISO3 from the repo's own tables (countries.csv, the current episode list), an optional
    two-column map CSV (country,iso; e.g. data/panel/crag_iso_map.csv) and `extra`, over the built-in ISO3_NAMES
    reference table (lowest precedence). Keys are normalised names."""
    look: dict[str, str] = {}
    for line in ISO3_NAMES.strip().splitlines():
        code, *names = line.split("|")
        look.update({_name_key(n): code for n in names})
    for p, n, i in ((REPO_DATA / "countries.csv", "country", "iso"), (REPO_DATA / "panel" / "sovereign_defaults.csv", "country", "iso")):
        try:
            t = pd.read_csv(p, usecols=[n, i], comment="#")
            look.update({_name_key(a): str(b).upper() for a, b in zip(t[n], t[i]) if pd.notna(a) and pd.notna(b)})
        except (OSError, ValueError):
            pass
    if map_csv and Path(map_csv).is_file():
        t = pd.read_csv(map_csv, dtype=str).dropna(subset=["country", "iso"])
        t = t[t["iso"].str.strip() != ""]
        bad = [(a, b) for a, b in zip(t["country"], t["iso"]) if not ISO3_RE.fullmatch(b.strip().upper())]
        if bad:                                                   # SEC review S5: only ISO3 codes enter the panel
            raise ValueError(f"{map_csv}: iso must be three letters A-Z, got {bad[:5]}")
        look.update({_name_key(a): b.strip().upper() for a, b in zip(t["country"], t["iso"]) if b.strip()})
    look.update({_name_key(k): v.upper() for k, v in (extra or {}).items()})
    return look


def _spells(g: pd.DataFrame, min_amount: float, last_year: int) -> list[dict]:
    """Runs of consecutive years with in-scope debt in default > min_amount."""
    rows, cur = [], None
    for y, r in g.sort_index().iterrows():
        in_def = r.sum() > min_amount
        if in_def and cur is not None and y == cur["end"] + 1:
            cur["end"] = y
        elif in_def:
            if cur:
                rows.append(cur)
            cur = {"start": y, "end": y, "cats": set(), "peak": 0.0, "peak_year": y}
        elif cur:
            rows.append(cur); cur = None
            continue
        if in_def:
            cur["cats"] |= {c for c, v in r.items() if v > min_amount}
            if r.sum() > cur["peak"]:
                cur["peak"], cur["peak_year"] = float(r.sum()), y
    if cur:
        rows.append(cur)
    for s in rows:
        s["ongoing"] = s["end"] == last_year
    return rows


def import_crag(xlsx_path: str | Path, out_csv: str | Path, source_label: str, vintage: str, *,
                sheet=None, country_col: str | None = None, year_col: str | None = None, iso_col: str | None = None,
                category_col: str | None = None, category_map: dict[str, str] | None = None,
                iso_map: dict[str, str] | None = None, iso_map_csv: str | Path | None = None,
                min_amount: float = 0.0, start_year: int = 1960, on_unmapped: str = "error",
                from_year: int = 1980, save_vintage: bool = True, panel_dir: str | Path | None = None,
                now=None) -> dict:
    """Convert the official BoC-BoE workbook into the sovereign_defaults.csv schema plus source/source_vintage.

    Every economy in the database is covered (no filter to the desk countries). source_label: e.g. "BoC-BoE
    Sovereign Default Database 2026 (BoC-BoE-Database-2026.xlsx)"; the input file's SHA-256 (first 16 hex) is
    appended so each row identifies the exact file. vintage: edition or download date.
    Countries are mapped to ISO3 by an ISO column in the file if present, else by name (`default_iso_lookup`, which
    includes the built-in ISO3_NAMES table). Unmapped names of countries with a spell raise (on_unmapped="error",
    default) after writing `<out_csv stem>_unmapped.csv` (country,iso) for completion; on_unmapped="skip" drops them
    and lists them in the result.

    Spells are found on every year from `start_year` (so a spell that began before 1980 keeps its true start) and
    kept when they end in or after `from_year` (default 1980, the hazard panel's first year).

    Also writes `<out_csv stem>_universe.csv` (iso, country, first_year, last_year, has_spell): every country the
    database covers, including those never in default, so `panel_coverage` can tell a true zero from a country
    CRAG does not cover. With save_vintage (default) the output, the universe file and a JSON summary are copied to
    an append-only panel vintage under `<panel_dir or out_csv's folder>/vintages/` (panel_history.save_panel_vintage).
    Returns a summary dict.
    """
    src = Path(xlsx_path)
    out = Path(out_csv)
    if not src.is_file():
        raise FileNotFoundError(src)
    if out.resolve() == src.resolve():
        raise ValueError("out_csv must differ from the input file")
    if not str(source_label).strip() or not str(vintage).strip():
        raise ValueError("source_label and vintage are required for provenance")
    digest = checksum(src)
    sheet_name, layout, hdr, table = _find_table(_read_frames(src, sheet), country_col, year_col)
    amounts = _long_amounts(table, layout, country_col, year_col, iso_col, category_map, category_col)
    amounts = amounts[amounts["year"] >= start_year]
    if amounts.empty:
        raise ValueError(f"no in-scope creditor data ({', '.join(IN_SCOPE)}) found in {src.name} sheet {sheet_name}")
    last_year = int(amounts["year"].max())
    covered = amounts.groupby("country")["year"].agg(["min", "max"])        # every country in the database
    lookup = default_iso_lookup(iso_map, iso_map_csv)
    iso_of: dict[str, str] = {}
    if "iso_src" in amounts:
        firsts = amounts.dropna(subset=["iso_src"]).groupby("country")["iso_src"].first()
        iso_of.update({k: str(v).strip().upper() for k, v in firsts.items() if re.fullmatch(r"[A-Za-z]{3}", str(v).strip())})
    for n in covered.index:
        if n not in iso_of and _name_key(n) in lookup:
            iso_of[n] = lookup[_name_key(n)]
    first_year = int(amounts["year"].min())
    amounts = amounts[amounts["country"].isin(set(amounts.loc[amounts["amt"] > min_amount, "country"]))]  # only countries with a spell need an ISO code
    names = sorted(amounts["country"].unique())
    unmapped = [n for n in names if n not in iso_of]
    if unmapped and on_unmapped == "error":
        tpl = out.with_name(out.stem + "_unmapped.csv")
        pd.DataFrame({"country": [escape_formula(n) for n in unmapped], "iso": ""}).to_csv(tpl, index=False)
        raise ValueError(f"{len(unmapped)} country names have no ISO3 code (e.g. {unmapped[:5]}). Fill the iso column of {tpl}, "
                         f"save it as the iso_map_csv (e.g. data/panel/crag_iso_map.csv) and rerun, or pass iso_map=.")

    source = f"{source_label.strip()} sha256:{digest[:16]}"
    wide = amounts[amounts["country"].isin(iso_of)].pivot_table(index=["country", "year"], columns="category", values="amt", aggfunc="sum", fill_value=0.0)
    rows = []
    for name, g in wide.groupby(level=0):
        g = g.droplevel(0)
        for s in _spells(g, min_amount, last_year):
            if s["end"] < from_year:
                continue
            cats = "; ".join(IN_SCOPE[c] for c in IN_SCOPE if c in s["cats"])
            note = f"CRAG peak {s['peak']:,.0f} in {s['peak_year']}" + (f"; ongoing at last data year {last_year}" if s["ongoing"] else "")
            rows.append({"iso": iso_of[name], "country": name, "start": int(s["start"]), "end": int(s["end"]),
                         "creditors": cats, "note": note, "source": source, "source_vintage": str(vintage).strip()})
    df = pd.DataFrame(rows, columns=SCHEMA + PROVENANCE).sort_values(["iso", "start"]).reset_index(drop=True)
    if len(df) and (df["source"].astype(str).str.strip().eq("") | df["source_vintage"].astype(str).str.strip().eq("")).any():
        raise ValueError("every episode needs source and source_vintage")
    with_spell = set(df["country"])
    universe = pd.DataFrame({"iso": [iso_of.get(n, "") for n in covered.index], "country": list(covered.index),
                             "first_year": covered["min"].astype(int).values, "last_year": covered["max"].astype(int).values,
                             "has_spell": [n in with_spell for n in covered.index]}).sort_values(["iso", "country"]).reset_index(drop=True)
    uni_path = out.with_name(out.stem + "_universe.csv")
    out.parent.mkdir(parents=True, exist_ok=True)
    # country names come from the input workbook: escape formula-like text before it reaches a CSV (SEC review S5)
    df.assign(country=df["country"].map(escape_formula)).to_csv(out, index=False)
    universe.assign(country=universe["country"].map(escape_formula)).to_csv(uni_path, index=False)
    summary = {"input": str(src), "input_sha256": digest, "source_label": source_label, "source_vintage": str(vintage).strip(),
               "sheet": sheet_name, "layout": layout, "header_row": int(hdr), "years": (first_year, last_year),
               "from_year": int(from_year), "episodes": len(df), "countries": int(df["iso"].nunique()),
               "universe_countries": int(len(universe)), "universe_unmapped": sorted(universe.loc[universe["iso"] == "", "country"]),
               "unmapped_skipped": unmapped, "output": str(out), "output_sha256": checksum(out),
               "universe": str(uni_path), "universe_sha256": checksum(uni_path)}
    if save_vintage:
        import json
        from .panel_history import save_panel_vintage
        meta = {k: v for k, v in summary.items() if k not in ("input", "output", "universe")}
        v = save_panel_vintage(panel_dir or out.parent,
                               {out.name: out, uni_path.name: uni_path,
                                "crag_import.json": json.dumps(meta, indent=1, sort_keys=True, default=str).encode()},
                               label=f"default episodes: {source_label} ({vintage})", now=now)
        summary["panel_vintage"] = str(v)
    return summary


def panel_coverage(defaults_csv: str | Path, history_csv: str | Path, universe_csv: str | Path | None = None,
                   start: int = 1980) -> dict:
    """How the episode file and the predictor history line up, before a refit (EQ-A-0016, HO-20261023-B-A-002).

    defaults_csv: an episode file (iso, start, end, ...). history_csv: a long history file (weo_history.csv; any
    file with an iso column). universe_csv: the `<stem>_universe.csv` written by import_crag; when given, countries
    in the history without any spell are split into those CRAG covers (true zeros) and those it does not (zeros
    that are an assumption). Aggregates (hazard_panel.AGGREGATES) and non-ISO3 codes are ignored. Spells that end
    before `start` do not count.

    Returns n_countries (history economies), n_ever_defaulted, ever_defaulted_share, history_missing_from_defaults
    (they enter the panel as zeros), defaults_missing_from_history (they drop out of the panel),
    zeros_covered_by_crag / zeros_not_covered_by_crag (None without universe_csv), defaults_without_source, and
    `checks` for the HO-20261023-B-A-002 acceptance (>= 100 countries, ever-defaulted share below 55%)."""
    from ..validation.hazard_panel import AGGREGATES
    ev = pd.read_csv(defaults_csv, comment="#")
    ev["iso"] = ev["iso"].astype(str).str.upper().str.strip()
    ev = ev[ev["end"].astype(int) >= start]
    hist = pd.read_csv(history_csv, usecols=["iso"], dtype=str)["iso"].astype(str).str.upper().str.strip()
    economies = {i for i in hist.unique() if re.fullmatch(r"[A-Z]{3}", i) and i not in AGGREGATES}
    defaulted = set(ev["iso"])
    ever = economies & defaulted
    zeros = sorted(economies - defaulted)
    if {"source", "source_vintage"} <= set(ev.columns):
        no_src = int((ev["source"].isna() | ev["source_vintage"].isna() | ev["source"].astype(str).str.strip().eq("")).sum())
    else:
        no_src = int(len(ev))
    covered = not_covered = None
    if universe_csv is not None:
        uni = set(pd.read_csv(universe_csv, dtype=str)["iso"].dropna().str.upper().str.strip()) - {""}
        covered = [i for i in zeros if i in uni]
        not_covered = [i for i in zeros if i not in uni]
    share = len(ever) / len(economies) if economies else float("nan")
    return {"n_countries": len(economies), "n_ever_defaulted": len(ever), "ever_defaulted_share": round(share, 4),
            "history_missing_from_defaults": zeros, "defaults_missing_from_history": sorted(defaulted - economies),
            "zeros_covered_by_crag": covered, "zeros_not_covered_by_crag": not_covered,
            "defaults_episodes": int(len(ev)), "defaults_without_source": no_src,
            "checks": {"at_least_100_countries": len(economies) >= 100, "share_below_55pct": bool(share < 0.55),
                       "every_episode_sourced": no_src == 0,
                       "all_zeros_covered_by_crag": (not not_covered) if not_covered is not None else None}}


def _overlap(a, b, tol) -> bool:
    return a[0] <= b[1] + tol and b[0] <= a[1] + tol


def compare_panels(old_csv: str | Path, new_csv: str | Path, tolerance: int = 1) -> dict:
    """Episodes added, removed and changed between two episode files (any file load_default_events reads).

    Spells of the same country are paired when their year ranges overlap or lie within `tolerance` years of each
    other; a pair whose start or end differs is "changed". Returns {"added", "removed", "changed": DataFrame,
    "unchanged": int, "summary": dict}. `comparison_table(result)` flattens it for a review CSV."""
    def load(p):
        d = pd.read_csv(p, comment="#")
        d["iso"] = d["iso"].astype(str).str.upper().str.strip()
        d["start"] = d["start"].astype(int); d["end"] = d["end"].astype(int)
        if "country" not in d:
            d["country"] = ""
        return d.sort_values(["iso", "start"]).reset_index(drop=True)
    old, new = load(old_csv), load(new_csv)
    added, removed, changed, same = [], [], [], 0
    for iso in sorted(set(old["iso"]) | set(new["iso"])):
        o = old[old["iso"] == iso].to_dict("records")
        n = new[new["iso"] == iso].to_dict("records")
        used = set()
        for a in o:
            best, score = None, None
            for j, b in enumerate(n):
                if j in used or not _overlap((a["start"], a["end"]), (b["start"], b["end"]), tolerance):
                    continue
                s = abs(a["start"] - b["start"]) + abs(a["end"] - b["end"])
                if score is None or s < score:
                    best, score = j, s
            if best is None:
                removed.append({"iso": iso, "country": a.get("country", ""), "start": a["start"], "end": a["end"]})
                continue
            used.add(best)
            b = n[best]
            if (a["start"], a["end"]) == (b["start"], b["end"]):
                same += 1
            else:
                changed.append({"iso": iso, "country": b.get("country") or a.get("country", ""), "old_start": a["start"], "old_end": a["end"],
                                "new_start": b["start"], "new_end": b["end"], "start_shift": b["start"] - a["start"], "end_shift": b["end"] - a["end"]})
        for j, b in enumerate(n):
            if j not in used:
                added.append({"iso": iso, "country": b.get("country", ""), "start": b["start"], "end": b["end"]})
    res = {"added": pd.DataFrame(added, columns=["iso", "country", "start", "end"]),
           "removed": pd.DataFrame(removed, columns=["iso", "country", "start", "end"]),
           "changed": pd.DataFrame(changed, columns=["iso", "country", "old_start", "old_end", "new_start", "new_end", "start_shift", "end_shift"]),
           "unchanged": same}
    res["summary"] = {"old_episodes": len(old), "new_episodes": len(new), "added": len(added), "removed": len(removed),
                      "changed": len(changed), "unchanged": same, "old_sha256": checksum(old_csv), "new_sha256": checksum(new_csv)}
    return res


def comparison_table(result: dict) -> pd.DataFrame:
    """One row per difference (status = added / removed / changed), for data/panel/crag_comparison.csv."""
    cols = ["status", "iso", "country", "old_start", "old_end", "new_start", "new_end"]
    a = result["added"].rename(columns={"start": "new_start", "end": "new_end"}).assign(status="added")
    r = result["removed"].rename(columns={"start": "old_start", "end": "old_end"}).assign(status="removed")
    c = result["changed"].assign(status="changed")
    parts = [p.reindex(columns=cols) for p in (r, c, a) if len(p)]
    t = (pd.concat(parts, ignore_index=True) if parts else pd.DataFrame(columns=cols)).sort_values(["iso", "status"], kind="stable").reset_index(drop=True)
    t["country"] = t["country"].map(escape_formula)            # written to a review CSV (SEC review S5)
    return t
