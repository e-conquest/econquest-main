"""Attested manual entry of hand-typed CDS and spread quotes (EQ-A-0032), until a vendor licence exists.

enter_quotes(data_dir, rows, author, approver=None, self_approved=False, note=""):
  1. four-eyes check (ledger.check_approval): an approver other than the author, or self_approved=True for Sam's
     single-operator mode (stored approver = author, self_approved 'yes'); ValueError before anything is written;
     an author, approver or note that schema.text_problem objects to (formula lead, control characters, too long)
     raises MarketDataError, also before anything is written;
  2. each row is completed (source 'manual', licence 'n/a (hand-entered)', unit from the field, derived false,
     retrieved_utc = entry time) and validated against the market schema (MarketDataError lists every problem);
  3. rows are appended to data/live/market/manual_quotes.csv (append-only, ledger.locked_append; MANUAL_COLUMNS =
     MARKET_COLUMNS + entry_id, content_sha256, author, approver, self_approved, entered_utc, note);
  4. one ledger attestation per row (ledger.attest_rows, table 'market_manual', key
     "asof|instrument|currency|tenor|field|doc_clause", country = iso, content_sha256 of the quote fields);
  5. a market snapshot (store.save_market_snapshot) of the batch, so engine reads are point-in-time. The quotes
     reach data/market/cds_snapshots.csv only through the gated export (cds_export), which re-checks the attestation.
A correction is a new entry for the same key: the later snapshot wins in latest_market; the old row stays.

unattested_manual(data_dir) lists manual rows whose current content has no approved attestation (never attested,
edited after attestation, or withdrawn by a later hold/reject). Report only.

cds_quotes_migration(data_dir) reads data/cds_quotes.csv (read only) and returns the rows as entry rows for
enter_quotes plus a count; nothing is written. Currency is assumed USD (that file has no currency column) and
flagged in the note.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import uuid
from pathlib import Path

import pandas as pd

from econquest.ingestion import ledger
from econquest.ingestion.market.schema import (FIELD_UNITS, MANUAL_LICENCE, MANUAL_SOURCE, MARKET_COLUMNS,
                                               MarketDataError, text_problem, validate_market)
from econquest.ingestion.market.store import market_root, save_market_snapshot, utc_stamp

TABLE = "market_manual"
ENTRY_FIELDS = ["asof", "instrument", "iso", "currency", "tenor_y", "field", "value", "unit", "doc_clause",
                "vendor_ticker"]
HASH_FIELDS = ["asof", "instrument", "iso", "currency", "tenor_y", "field", "value", "unit", "doc_clause"]
MANUAL_COLUMNS = MARKET_COLUMNS + ["entry_id", "content_sha256", "author", "approver", "self_approved", "entered_utc",
                                   "note"]
MAX_ROWS_PER_ENTRY = 2000


def manual_path(data_dir: Path) -> Path:
    return market_root(data_dir) / "manual_quotes.csv"


def _num(x) -> str:
    return f"{float(x):.10g}"


def cell_key(r) -> str:
    return "|".join([str(r["asof"]), str(r["instrument"]), str(r["currency"]), _num(r["tenor_y"]), str(r["field"]),
                     str(r["doc_clause"])])


def content_sha256(r) -> str:
    blob = {c: (_num(r[c]) if c in ("tenor_y", "value") else str(r[c])) for c in HASH_FIELDS}
    return hashlib.sha256(json.dumps({"table": TABLE, **blob}, sort_keys=True).encode()).hexdigest()


def _complete(rows, stamp: str) -> pd.DataFrame:
    df = pd.DataFrame(rows).copy() if not isinstance(rows, pd.DataFrame) else rows.copy()
    if df.empty:
        raise MarketDataError("no rows to enter")
    if len(df) > MAX_ROWS_PER_ENTRY:
        raise MarketDataError(f"more than {MAX_ROWS_PER_ENTRY} rows in one entry")
    extra = sorted(set(df.columns) - set(ENTRY_FIELDS) - {"source", "licence"})
    if extra:
        raise MarketDataError(f"unexpected columns {extra}; manual rows take {ENTRY_FIELDS}")
    for c in ("source", "licence"):
        if c in df.columns and set(df[c].fillna("").astype(str)) - {"", MANUAL_SOURCE if c == "source" else MANUAL_LICENCE}:
            raise MarketDataError(f"manual rows always carry {c} "
                                  f"{MANUAL_SOURCE if c == 'source' else MANUAL_LICENCE!r}; use the importers for vendor data")
    for c in ("iso", "doc_clause", "vendor_ticker", "unit"):
        if c not in df.columns:
            df[c] = ""
    df = df.fillna({"iso": "", "doc_clause": "", "vendor_ticker": "", "unit": ""})
    df["unit"] = [u if str(u).strip() else FIELD_UNITS.get(str(f), "") for u, f in zip(df["unit"], df["field"])]
    df = df.assign(source=MANUAL_SOURCE, licence=MANUAL_LICENCE, derived=False, snapshot_id="", retrieved_utc=stamp)
    missing = [c for c in ENTRY_FIELDS if c not in df.columns]
    if missing:
        raise MarketDataError(f"manual rows need {missing}")
    return validate_market(df[MARKET_COLUMNS])


def enter_quotes(data_dir: Path, rows, author: str, approver: str | None = None, self_approved: bool = False,
                 note: str = "", now: dt.datetime | None = None) -> dict:
    """Validate, record and attest hand-typed quotes; returns {'entry_id', 'rows' (frame as appended),
    'attestations' (ledger rows), 'snapshot' (folder path)}."""
    author, approver, flag = ledger.check_approval(author, approver, self_approved)
    for role, who in (("author", author), ("approver", approver)):      # SEC-A-003 L1: refused, not escaped
        if text_problem(who):
            raise MarketDataError(f"{role} refused: {text_problem(who)}")
    note = "" if note is None else str(note)
    if note and text_problem(note):
        raise MarketDataError(f"note refused: {text_problem(note)}")
    stamp = utc_stamp(now)
    q = _complete(rows, stamp)
    entry_id = f"{stamp.replace(':', '').replace('-', '')}-{uuid.uuid4().hex[:8]}"
    q = q.assign(entry_id=entry_id, content_sha256=[content_sha256(r) for _, r in q.iterrows()], author=author,
                 approver=approver, self_approved=flag, entered_utc=stamp, note=note)
    with ledger.locked_append(manual_path(data_dir), MANUAL_COLUMNS) as (w, _f, new):
        if new:
            w.writeheader()
        for r in q.to_dict("records"):
            w.writerow({c: ("true" if r[c] else "false") if c == "derived" else
                        (_num(r[c]) if c in ("tenor_y", "value") else r[c]) for c in MANUAL_COLUMNS})
    cells = [{"key": cell_key(r), "country": r["iso"], "value": _num(r["value"]), "content_sha256": r["content_sha256"]}
             for _, r in q.iterrows()]
    att = ledger.attest_rows(data_dir, TABLE, cells, author, approver, self_approved, note=note or
                             f"attested hand-entered market quote (entry {entry_id})", now=now)
    snap = save_market_snapshot(data_dir, q[MARKET_COLUMNS], now=now,
                                provenance={"importer": "manual entry", "entry_id": entry_id, "author": author,
                                            "approver": approver, "self_approved": flag})
    return {"entry_id": entry_id, "rows": q, "attestations": att, "snapshot": snap}


def read_manual(data_dir: Path) -> pd.DataFrame:
    p = manual_path(data_dir)
    if not p.exists():
        return pd.DataFrame(columns=MANUAL_COLUMNS)
    return pd.read_csv(p, dtype=str, keep_default_na=False)


def unattested_manual(data_dir: Path) -> list[dict]:
    """Manual rows whose content (recomputed from the row, not trusted from its content_sha256 column) has no
    approved attestation in the ledger. Each item: entry_id, key, iso, value, reason."""
    m = read_manual(data_dir)
    if m.empty:
        return []
    best = ledger.attested_content(data_dir, TABLE)
    out = []
    for _, r in m.iterrows():
        try:
            h, k = content_sha256(r), cell_key(r)
        except (KeyError, ValueError):
            out.append({"entry_id": r.get("entry_id", ""), "key": "", "iso": r.get("iso", ""), "value": r.get("value", ""),
                        "reason": "row unreadable"})
            continue
        reason = ""
        if h != r.get("content_sha256", ""):
            reason = "row edited after entry (content hash differs)"
        elif h not in best.get((k, r["iso"]), {}):
            reason = "no approved attestation for this content (or withdrawn by a later hold/reject)"
        if reason:
            out.append({"entry_id": r["entry_id"], "key": k, "iso": r["iso"], "value": r["value"], "reason": reason})
    return out


def cds_quotes_migration(data_dir: Path) -> tuple[pd.DataFrame, int]:
    """Read-only: data/cds_quotes.csv rows as enter_quotes rows (spread_bp and, where given, recovery at the same
    tenor) and the number of source rows. Country names map to ISO3 through data/countries.csv; an unknown name
    raises MarketDataError. Nothing is written: Sam (or the analyst) re-enters them with enter_quotes."""
    p = Path(data_dir) / "cds_quotes.csv"
    if not p.exists():
        return pd.DataFrame(columns=ENTRY_FIELDS), 0
    src = pd.read_csv(p, dtype=str, keep_default_na=False)
    if src.empty:
        return pd.DataFrame(columns=ENTRY_FIELDS), 0
    c = pd.read_csv(Path(data_dir) / "countries.csv", dtype=str, keep_default_na=False)
    iso = dict(zip(c["country"], c["iso"]))
    unknown = sorted(set(src["country"]) - set(iso))
    if unknown:
        raise MarketDataError(f"cds_quotes.csv countries not in countries.csv: {unknown}")
    rows = []
    for r in src.itertuples(index=False):
        base = {"asof": r.date, "instrument": "cds", "iso": iso[r.country], "currency": "USD", "tenor_y": r.tenor_y,
                "doc_clause": "", "vendor_ticker": ""}
        rows.append({**base, "field": "spread_bp", "value": r.spread_bp, "unit": "bp"})
        if str(getattr(r, "recovery", "")).strip():
            rows.append({**base, "field": "recovery", "value": r.recovery, "unit": "fraction"})
    out = pd.DataFrame(rows, columns=ENTRY_FIELDS)
    out.attrs["note"] = ("currency assumed USD and doc_clause blank (cds_quotes.csv has neither); source column "
                         f"values {sorted(set(src['source']))} are not carried; verify before enter_quotes")
    return out, int(len(src))
