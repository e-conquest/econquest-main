"""Free public market data into market snapshots (EQ-A-0030, epic A7).

Sources (live pulls run on Sam's Mac; this cloud cannot reach them):

  fred    US Treasury constant-maturity curve, FRED API (api.stlouisfed.org/fred/series/observations), series
          FRED_SERIES = DGS1MO DGS3MO DGS6MO DGS1 DGS2 DGS3 DGS5 DGS7 DGS10 DGS20 DGS30 -> govt_yield, iso USA,
          USD, field yield_pct. Values are Treasury par yields on a bond-equivalent (semiannual) basis, in percent.
          '.' (FRED's missing marker: holidays, no auction) is skipped and counted, never filled.
          API key: environment variable FRED_API_KEY only. FRED takes it as the `api_key` query parameter (it has no
          header form), so every error message is built from host + path only and the key is redacted from any
          message a fetcher raises.
  alfred  Same series, point-in-time: the same endpoint with realtime_start/realtime_end (ALFRED vintages). For an
          as-of date A, each observation date keeps the vintage valid at A (realtime_start <= A <= realtime_end);
          vendor_ticker records it as "<series>@<realtime_start>". Source slug 'alfred'.
  ecb     Euro area yield curves, ECB Data Portal SDMX REST (data-api.ecb.europa.eu/service/data/YC), no key.
          Series key YC.B.U2.EUR.4F.<curve>.SV_C_YM.<maturity>:
              B          business-daily (TARGET days)
              U2         euro area (changing composition)
              EUR        currency
              4F         provider: ECB
              G_N_A      AAA-rated euro area central government bonds  -> source ecb_yc_aaa
              G_N_C      all euro area central government bonds         -> source ecb_yc_all
              SV_C_YM    Svensson model, continuous compounding, yield error minimisation
              SR_<n>Y / SR_<n>M / SR_<n>Y<m>M   spot (zero-coupon) rate at that maturity, percent
          -> govt_yield, iso EURO_AREA_ISO ('EMU', the World Bank aggregate code for the euro area: the schema needs
          an ISO3-shaped code for govt_yield and the curve has no single sovereign), EUR, field yield_pct.
  bis     Central-bank policy rates already pulled by feeds.BisFeed (WS_CBPOL) into data/live/raw_bis.csv: converted
          offline (bis_policy_rows), no second BIS client. -> policy_rate, iso = country, currency from countries.csv.

Each source writes one snapshot through store.save_market_snapshot with its licence string on every row and the
request details (endpoint, series keys, period, vintage, skipped counts; never the key) in the manifest provenance.

CLI (on the Mac):
    python -m econquest.ingestion.market.public --source fred --start 2026-01-01 --end 2026-10-23 --data-dir data
    python -m econquest.ingestion.market.public --source fred --asof 2025-06-30 --start 2025-06-01 --end 2025-06-30 \
        --data-dir data/replay/alfred-2025-06-30
    python -m econquest.ingestion.market.public --source ecb --start 2026-01-01 --end 2026-10-23 --data-dir data
    python -m econquest.ingestion.market.public --source bis --start 2026-01-01 --end 2026-10-23 --data-dir data

Licence strings below are written from the providers' published terms as remembered, not re-read from this cloud:
they are marked "(unverified)" until Sam or AGENT-09 confirms them against the cited pages.
"""
from __future__ import annotations

import argparse
import datetime as dt
import functools
import io
import json
import os
import re
import sys
import urllib.parse
from pathlib import Path
from typing import Callable

import pandas as pd

from econquest.ingestion.events.base import (DEFAULT_MAX_BYTES, FetchError, TransientFetchError, fetch_with_retries,
                                             http_fetch)
from econquest.ingestion.market.schema import MARKET_COLUMNS, MarketDataError, validate_market
from econquest.ingestion.market.store import save_market_snapshot, utc_stamp

# ------------------------------------------------------------------------------------------------------------ FRED
FRED_BASE = "https://api.stlouisfed.org/fred/series/observations"
FRED_KEY_ENV = "FRED_API_KEY"
FRED_KEY_RE = re.compile(r"[a-z0-9]{32}")            # FRED keys are 32 lower-case alphanumerics
FRED_SERIES = {"DGS1MO": 1 / 12, "DGS3MO": 0.25, "DGS6MO": 0.5, "DGS1": 1.0, "DGS2": 2.0, "DGS3": 3.0, "DGS5": 5.0,
               "DGS7": 7.0, "DGS10": 10.0, "DGS20": 20.0, "DGS30": 30.0}
FRED_LICENCE = ("public domain (US Treasury yields via Fed H.15); cite FRED, Federal Reserve Bank of St. Louis; "
                "FRED terms apply (unverified)")
FRED_TERMS_URL = "https://fred.stlouisfed.org/legal/"
FRED_MISSING = "."
FRED_SERIES_RE = re.compile(r"[A-Z0-9]{1,30}")

# ------------------------------------------------------------------------------------------------------------ ECB
ECB_BASE = "https://data-api.ecb.europa.eu/service/data"
ECB_FLOW = "YC"
ECB_MODEL = "SV_C_YM"
ECB_CURVES = {"G_N_A": "ecb_yc_aaa", "G_N_C": "ecb_yc_all"}
ECB_MATURITIES = ("SR_3M", "SR_6M", "SR_1Y", "SR_2Y", "SR_3Y", "SR_5Y", "SR_7Y", "SR_10Y", "SR_15Y", "SR_20Y", "SR_30Y")
ECB_SERIES_KEY = "YC.B.U2.EUR.4F.{curve}.SV_C_YM.{maturity}"
ECB_LICENCE = "ECB statistics: reuse free of charge with the source (ECB Data Portal) acknowledged (unverified)"
ECB_TERMS_URL = "https://www.ecb.europa.eu/stats/ecb_statistics/governance_and_quality_framework/html/usage_policy.en.html"
ECB_MATURITY_RE = re.compile(r"SR_(?:(\d{1,2})Y)?(?:(\d{1,2})M)?")
EURO_AREA_ISO = "EMU"

# ------------------------------------------------------------------------------------------------------------ BIS
BIS_LICENCE = "BIS statistics: free reuse with attribution to the BIS per bis.org terms of use (unverified)"
BIS_TERMS_URL = "https://www.bis.org/terms_conditions.htm"
BIS_POLICY_SERIES = "POLICY_RATE"

# Free, documented central-bank APIs not wired yet (no scraping): see docs/runbooks/A-market-data.md section 5.
FUTURE_SOURCES = {
    "ecb_estr": "https://data.ecb.europa.eu/data/datasets/EST (euro short-term rate, ECB Data Portal, no key)",
    "boe_iadb": "https://www.bankofengland.co.uk/boeapps/database/ (Bank of England database, CSV download)",
    "boc_valet": "https://www.bankofcanada.ca/valet/docs (Bank of Canada Valet API, JSON, no key)",
    "bcb_sgs": "https://dadosabertos.bcb.gov.br/ (Banco Central do Brasil SGS series API, JSON, no key)",
    "banxico_sie": "https://www.banxico.org.mx/SieAPIRest/ (Banxico SIE API, free token)",
    "snb_data": "https://data.snb.ch/en (Swiss National Bank data portal API)",
    "rba_tables": "https://www.rba.gov.au/statistics/tables/ (RBA statistical tables, CSV)",
    "fred_sofr_effr": "FRED series SOFR, EFFR, DFEDTARU/DFEDTARL (same client as fred; overnight rates, not yet mapped)",
}

Fetcher = Callable[..., bytes]


class PublicSourceError(RuntimeError):
    """A public-source pull failed. The message never contains query strings or the API key."""


def _now(now: dt.datetime | None) -> dt.datetime:
    now = now or dt.datetime.now(dt.timezone.utc)
    return now.astimezone(dt.timezone.utc) if now.tzinfo else now.replace(tzinfo=dt.timezone.utc)


def _date(s, what: str) -> str:
    try:
        return dt.date.fromisoformat(str(s)).isoformat()
    except ValueError:
        raise ValueError(f"{what} must be YYYY-MM-DD, got {s!r}") from None


def redact(msg: str, *secrets: str) -> str:
    """Strip query strings and the given secrets from an error message."""
    out = re.sub(r"\?\S*", "?<redacted>", str(msg))
    for s in secrets:
        if s:
            out = out.replace(s, "<redacted>")
    return out[:300]


def _fetch(fetcher: Fetcher | None, url: str, *, retries: int, sleep, max_bytes: int, secrets=(), label: str) -> bytes:
    """GET through fetch_with_retries; default fetcher is http_fetch (https only, no redirects, size cap). Any error
    is re-raised as PublicSourceError naming only `label` (host/path), with secrets and query strings redacted."""
    f = fetcher or functools.partial(http_fetch, max_bytes=max_bytes)
    kw = {"sleep": sleep} if sleep is not None else {}
    try:
        return fetch_with_retries(f, url, {"Accept": "application/json, text/csv"}, retries=retries, **kw)
    except (FetchError, TransientFetchError, ValueError) as e:  # ValueError: http_fetch refuses non-https first
        msg = f"{label}: {redact(str(e), *secrets)}"
    except Exception as e:  # noqa: BLE001 - a custom fetcher's message may carry the URL: never echo it raw
        msg = f"{label}: {type(e).__name__}: {redact(str(e), *secrets)}"
    # SEC-A-003 I1: raised outside the except block, so __context__ / __cause__ do not keep the original exception
    # (whose text may hold the full URL with the key)
    raise PublicSourceError(msg)


def _host_path(base: str) -> str:
    """'host/path' of a base URL for error labels and provenance (no scheme, no query, no double slash)."""
    u = urllib.parse.urlsplit(base)
    return u.netloc + u.path


def _row(asof, instrument, iso, ccy, tenor, value, source, ticker, licence, retrieved) -> dict:
    return {"asof": asof, "instrument": instrument, "iso": iso, "currency": ccy, "tenor_y": float(tenor),
            "field": "yield_pct", "value": float(value), "unit": "pct", "doc_clause": "", "source": source,
            "vendor_ticker": ticker, "licence": licence, "derived": False, "snapshot_id": "", "retrieved_utc": retrieved}


def _frame(rows: list[dict]) -> pd.DataFrame:
    return pd.DataFrame(rows, columns=MARKET_COLUMNS)


# ------------------------------------------------------------------------------------------------------------ FRED

def fred_api_key(key: str | None = None) -> str:
    """The FRED key: `key` or $FRED_API_KEY. Refused (without echoing it) when missing or not 32 [a-z0-9]."""
    k = (key if key is not None else os.environ.get(FRED_KEY_ENV, "")).strip()
    if not k:
        raise PublicSourceError(f"FRED API key missing: set {FRED_KEY_ENV} in the environment (never in a file)")
    if not FRED_KEY_RE.fullmatch(k):
        raise PublicSourceError(f"{FRED_KEY_ENV} is not a FRED API key (32 lower-case letters/digits expected)")
    return k


def fred_url(series_id: str, start: str, end: str, api_key: str, realtime_end: str | None = None,
             base: str = FRED_BASE) -> str:
    if not FRED_SERIES_RE.fullmatch(series_id):
        raise ValueError(f"bad FRED series id {series_id!r}")
    q = {"series_id": series_id, "api_key": api_key, "file_type": "json", "observation_start": start,
         "observation_end": end}
    if realtime_end:                                   # ALFRED: every vintage from the first observation date to A
        q.update(realtime_start=start, realtime_end=realtime_end)
    return f"{base}?{urllib.parse.urlencode(q)}"


def parse_fred_json(body: bytes, series_id: str, asof: str | None = None) -> pd.DataFrame:
    """FRED/ALFRED observations JSON -> frame (date, value, realtime_start, realtime_end). '.' values are skipped and
    counted in attrs['missing']. With `asof` (ALFRED), only observations whose real-time period contains asof are
    kept (the vintage valid on that day) and dates after asof are dropped; without it, the newest vintage per date.
    A vintage whose value is '.' stays missing: an older vintage is never used in its place."""
    doc, ok = None, False
    try:
        doc, ok = json.loads(body.decode("utf-8")), True
    except (UnicodeDecodeError, json.JSONDecodeError):
        pass                                     # raised below: the decode error's .doc holds the raw body
    if not ok:
        raise PublicSourceError(f"FRED {series_id}: response is not JSON")
    if not isinstance(doc, dict):
        raise PublicSourceError(f"FRED {series_id}: unexpected JSON shape")
    if "error_message" in doc or "error_code" in doc:
        raise PublicSourceError(f"FRED {series_id}: API error {redact(str(doc.get('error_code', '')))}: "
                                f"{redact(str(doc.get('error_message', '')))[:200]}")
    obs = doc.get("observations")
    if not isinstance(obs, list):
        raise PublicSourceError(f"FRED {series_id}: no 'observations' list in the response")
    recs = []
    for o in obs:
        if not isinstance(o, dict):
            continue
        d, rs, re_ = str(o.get("date", "")), str(o.get("realtime_start", "")), str(o.get("realtime_end", ""))
        _date(d, f"FRED {series_id} date")
        recs.append({"date": d, "value": str(o.get("value", "")).strip(), "realtime_start": rs, "realtime_end": re_})
    df = pd.DataFrame(recs, columns=["date", "value", "realtime_start", "realtime_end"])
    if asof is not None:
        a = _date(asof, "asof")
        df = df[(df["realtime_start"] <= a) & (df["realtime_end"] >= a) & (df["date"] <= a)]
    # one vintage per date: the newest real-time start (the only one when asof selected a single vintage)
    df = df.sort_values(["date", "realtime_start"], kind="mergesort").drop_duplicates("date", keep="last")
    missing = df["value"] == FRED_MISSING
    out = df[~missing].copy()
    vals = pd.to_numeric(out["value"], errors="coerce")
    if vals.isna().any():
        bad = out.loc[vals.isna(), "value"].head(3).tolist()
        raise PublicSourceError(f"FRED {series_id}: non-numeric values {bad!r}")
    out["value"] = vals.astype(float)
    out = out.reset_index(drop=True)
    out.attrs["missing"] = int(missing.sum())
    return out


def fetch_fred(start, end, series=None, *, api_key: str | None = None, asof=None, fetcher: Fetcher | None = None,
               retries: int = 3, sleep=None, max_bytes: int = DEFAULT_MAX_BYTES, base: str = FRED_BASE,
               now: dt.datetime | None = None) -> pd.DataFrame:
    """UST curve rows (govt_yield, USA, USD) for observation dates start..end. With `asof`, ALFRED vintages as known
    on that date (source 'alfred', vendor_ticker '<series>@<vintage start>'), dates capped at asof.
    attrs['provenance'] holds endpoint, series, period, vintage and missing counts (never the key)."""
    start, end = _date(start, "start"), _date(end, "end")
    a = _date(asof, "asof") if asof is not None else None
    if a is not None and end > a:
        end = a
    if start > end:
        raise ValueError(f"start {start} is after end {end}")
    key = fred_api_key(api_key)
    series = list(series or FRED_SERIES)
    unknown = [s for s in series if s not in FRED_SERIES]
    if unknown:
        raise ValueError(f"no tenor mapping for FRED series {unknown}; known: {list(FRED_SERIES)}")
    stamp = utc_stamp(_now(now))
    source = "alfred" if a else "fred"
    host_path = _host_path(base)
    rows, missing = [], {}
    for sid in series:
        body = _fetch(fetcher, fred_url(sid, start, end, key, a, base), retries=retries, sleep=sleep,
                      max_bytes=max_bytes, secrets=(key,), label=f"FRED {sid} ({host_path})")
        err = None
        try:
            obs = parse_fred_json(body, sid, asof=a)
        except PublicSourceError as e:            # an API error message may quote the key back
            err = redact(str(e), key)
        if err is not None:                       # raised outside the except block: no __context__ with the key
            raise PublicSourceError(err)
        missing[sid] = obs.attrs["missing"]
        for r in obs.itertuples(index=False):
            if not start <= r.date <= end:
                continue
            ticker = f"{sid}@{r.realtime_start}" if a else sid
            rows.append(_row(r.date, "govt_yield", "USA", "USD", FRED_SERIES[sid], r.value, source, ticker,
                             FRED_LICENCE, stamp))
    df = _frame(rows)
    df.attrs["provenance"] = {
        "source": source, "endpoint": host_path, "series": {s: FRED_SERIES[s] for s in series},
        "observation_start": start, "observation_end": end, "realtime_asof": a, "missing_dot_values": missing,
        "units": "percent, bond-equivalent (semiannual) par yield", "licence": FRED_LICENCE, "terms": FRED_TERMS_URL,
        "retrieved_utc": stamp}
    return df


# ------------------------------------------------------------------------------------------------------------ ECB

def ecb_maturity_years(code: str) -> float:
    """'SR_10Y' -> 10.0, 'SR_3M' -> 0.25, 'SR_1Y6M' -> 1.5. Anything else raises."""
    m = ECB_MATURITY_RE.fullmatch(code or "")
    if not m or not (m.group(1) or m.group(2)):
        raise MarketDataError(f"ECB YC maturity {code!r} is not SR_<n>Y / SR_<n>M / SR_<n>Y<m>M")
    return int(m.group(1) or 0) + int(m.group(2) or 0) / 12


def ecb_url(start: str, end: str, curves=tuple(ECB_CURVES), maturities=ECB_MATURITIES, base: str = ECB_BASE) -> str:
    for c in curves:
        if c not in ECB_CURVES:
            raise ValueError(f"unknown ECB curve {c!r}; known: {list(ECB_CURVES)}")
    for mt in maturities:
        ecb_maturity_years(mt)
    key = f"B.U2.EUR.4F.{'+'.join(curves)}.{ECB_MODEL}.{'+'.join(maturities)}"
    q = urllib.parse.urlencode({"startPeriod": start, "endPeriod": end, "format": "csvdata", "detail": "dataonly"})
    return f"{base}/{ECB_FLOW}/{key}?{q}"


def parse_ecb_csv(body: bytes, *, retrieved_utc: str = "", licence: str = ECB_LICENCE) -> pd.DataFrame:
    """ECB SDMX-CSV (format=csvdata) for the YC dataflow -> govt_yield rows. The series is read from the KEY column
    (YC.B.U2.EUR.4F.<curve>.SV_C_YM.<maturity>) or, when absent, from the dimension columns. A series that is not
    business-daily euro area EUR from provider 4F with model SV_C_YM, or a curve not in ECB_CURVES, raises
    MarketDataError. Blank / NaN OBS_VALUE cells are skipped and counted in attrs['missing']."""
    try:
        raw = pd.read_csv(io.BytesIO(body), dtype=str, keep_default_na=False)
    except (pd.errors.ParserError, pd.errors.EmptyDataError, UnicodeDecodeError):
        raise PublicSourceError("ECB YC: response is not SDMX-CSV") from None
    if raw.empty:
        out = _frame([])
        out.attrs["missing"] = 0
        return out
    need = {"TIME_PERIOD", "OBS_VALUE"}
    if not need <= set(raw.columns):
        raise PublicSourceError(f"ECB YC: SDMX-CSV without {sorted(need - set(raw.columns))}")
    if "KEY" in raw.columns:
        keys = raw["KEY"].astype(str).str.strip()
    else:
        dims = ["FREQ", "REF_AREA", "CURRENCY", "PROVIDER_FM", "INSTRUMENT_FM", "PROVIDER_FM_ID", "DATA_TYPE_FM"]
        miss = [c for c in dims if c not in raw.columns]
        if miss:
            raise PublicSourceError(f"ECB YC: no KEY column and dimension columns missing: {miss}")
        keys = "YC." + raw[dims].astype(str).agg(".".join, axis=1)
    rows, missing, problems = [], 0, set()
    for k, d, v in zip(keys, raw["TIME_PERIOD"], raw["OBS_VALUE"]):
        parts = k.split(".")
        if (len(parts) != 8 or parts[:5] != ["YC", "B", "U2", "EUR", "4F"] or parts[6] != ECB_MODEL
                or parts[5] not in ECB_CURVES):
            problems.add(k)
            continue
        if v.strip() in ("", "NaN", "nan", "NA"):
            missing += 1
            continue
        tenor = ecb_maturity_years(parts[7])
        try:
            val = float(v)
        except ValueError:
            raise PublicSourceError(f"ECB YC {k}: non-numeric OBS_VALUE {v[:20]!r}") from None
        rows.append(_row(_date(d, f"ECB {k} TIME_PERIOD"), "govt_yield", EURO_AREA_ISO, "EUR", tenor, val,
                         ECB_CURVES[parts[5]], k, licence, retrieved_utc))
    if problems:
        raise MarketDataError(f"ECB YC: unexpected series keys {sorted(problems)[:5]} (expected "
                              f"{ECB_SERIES_KEY} with curve in {list(ECB_CURVES)})")
    out = _frame(rows)
    out.attrs["missing"] = missing
    return out


def _year_chunks(start: str, end: str):
    s, e = dt.date.fromisoformat(start), dt.date.fromisoformat(end)
    while s <= e:
        ce = min(dt.date(s.year, 12, 31), e)
        yield s.isoformat(), ce.isoformat()
        s = ce + dt.timedelta(days=1)


def fetch_ecb(start, end, curves=tuple(ECB_CURVES), maturities=ECB_MATURITIES, *, fetcher: Fetcher | None = None,
              retries: int = 3, sleep=None, max_bytes: int = DEFAULT_MAX_BYTES, base: str = ECB_BASE,
              now: dt.datetime | None = None) -> pd.DataFrame:
    """Euro area AAA and all-issuer spot curves, one request per calendar year (all curves and maturities batched
    with the SDMX '+' operator, detail=dataonly) to stay far below the response size cap."""
    start, end = _date(start, "start"), _date(end, "end")
    if start > end:
        raise ValueError(f"start {start} is after end {end}")
    stamp = utc_stamp(_now(now))
    host_path = _host_path(base) + f"/{ECB_FLOW}"
    frames, missing, requests = [], 0, []
    for s, e in _year_chunks(start, end):
        url = ecb_url(s, e, curves, maturities, base)
        requests.append(urllib.parse.urlsplit(url).path)
        body = _fetch(fetcher, url, retries=retries, sleep=sleep, max_bytes=max_bytes, label=f"ECB YC ({host_path})")
        f = parse_ecb_csv(body, retrieved_utc=stamp)
        missing += f.attrs["missing"]
        frames.append(f[(f["asof"] >= s) & (f["asof"] <= e)])
    df = pd.concat(frames, ignore_index=True) if frames else _frame([])
    df = df[(df["asof"] >= start) & (df["asof"] <= end)].reset_index(drop=True)
    df.attrs["provenance"] = {
        "source": "ecb", "endpoint": host_path, "requests": requests,
        "series_keys": [ECB_SERIES_KEY.format(curve=c, maturity=m) for c in curves for m in maturities],
        "curves": {c: ECB_CURVES[c] for c in curves}, "period": [start, end], "missing_values": missing,
        "iso_convention": f"{EURO_AREA_ISO} = euro area aggregate (World Bank code), not an ISO 3166 country",
        "units": "percent, zero-coupon spot rate, continuous compounding (Svensson, SV_C_YM)",
        "licence": ECB_LICENCE, "terms": ECB_TERMS_URL, "retrieved_utc": stamp}
    return df


# ------------------------------------------------------------------------------------------------------------ BIS

def bis_policy_rows(raw_bis: pd.DataFrame, currencies: dict, start=None, end=None, *, retrieved_utc: str = "",
                    licence: str = BIS_LICENCE) -> pd.DataFrame:
    """policy_rate rows from feeds.BisFeed's long table (data/live/raw_bis.csv: iso, series, period, value, source),
    series POLICY_RATE (BIS WS_CBPOL, daily, percent). currencies maps ISO3 -> ISO 4217 (countries.csv); a country
    with no currency raises MarketDataError. No second BIS client: the pull stays in feeds.py."""
    need = {"iso", "series", "period", "value"}
    if not need <= set(raw_bis.columns):
        raise MarketDataError(f"raw BIS table missing {sorted(need - set(raw_bis.columns))}")
    p = raw_bis[raw_bis["series"].astype(str) == BIS_POLICY_SERIES].copy()
    p["period"] = p["period"].astype(str)
    p = p[p["period"].str.fullmatch(r"\d{4}-\d{2}-\d{2}")]
    if start is not None:
        p = p[p["period"] >= _date(start, "start")]
    if end is not None:
        p = p[p["period"] <= _date(end, "end")]
    p["value"] = pd.to_numeric(p["value"], errors="coerce")
    p = p.dropna(subset=["value"])
    unknown = sorted(set(p["iso"]) - {k for k, v in currencies.items() if isinstance(v, str) and v})
    if unknown:
        raise MarketDataError(f"no currency for {unknown} in countries.csv; policy rates not converted")
    rows = [{**_row(r.period, "policy_rate", r.iso, currencies[r.iso], 0.0, r.value, "bis", "WS_CBPOL", licence,
                    retrieved_utc)} for r in p.itertuples(index=False)]
    return _frame(rows)


# ------------------------------------------------------------------------------------------------------------ save + CLI

def save_public(data_dir, df: pd.DataFrame, now: dt.datetime | None = None) -> Path:
    """validate_market + save_market_snapshot with df.attrs['provenance'] in the manifest."""
    prov = dict(df.attrs.get("provenance") or {})
    return save_market_snapshot(Path(data_dir), validate_market(df), now=now, provenance=prov)


def _currencies(data_dir: Path) -> dict:
    c = pd.read_csv(Path(data_dir) / "countries.csv", dtype=str, keep_default_na=False)
    return dict(zip(c["iso"], c["currency"]))


def pull(source: str, data_dir, start, end, *, asof=None, series=None, curves=None, fetcher=None,
         now: dt.datetime | None = None) -> pd.DataFrame:
    """One source -> validated market rows with attrs['provenance'] (no save)."""
    if source == "fred":
        df = fetch_fred(start, end, series, asof=asof, fetcher=fetcher, now=now)
    elif source == "ecb":
        df = fetch_ecb(start, end, tuple(curves or ECB_CURVES), fetcher=fetcher, now=now)
    elif source == "bis":
        raw_path = Path(data_dir) / "live" / "raw_bis.csv"
        if not raw_path.exists():
            raise FileNotFoundError(f"{raw_path} missing: run the BIS feed first (fetch --apply on the Mac)")
        mtime = dt.datetime.fromtimestamp(raw_path.stat().st_mtime, dt.timezone.utc)
        raw = pd.read_csv(raw_path, dtype=str, keep_default_na=False)
        df = bis_policy_rows(raw, _currencies(data_dir), start, end, retrieved_utc=utc_stamp(mtime))
        df.attrs["provenance"] = {"source": "bis", "from": str(raw_path), "flow": "WS_CBPOL (via feeds.BisFeed)",
                                  "period": [str(start), str(end)], "raw_mtime_utc": utc_stamp(mtime),
                                  "licence": BIS_LICENCE, "terms": BIS_TERMS_URL}
    else:
        raise ValueError(f"unknown source {source!r}: fred, ecb or bis")
    prov = df.attrs.get("provenance", {})
    out = validate_market(df)
    out.attrs["provenance"] = prov
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.market.public",
                                 description="Pull free public market data (FRED/ALFRED, ECB YC, BIS policy rates "
                                             "from raw_bis.csv) into an append-only market snapshot.")
    ap.add_argument("--source", required=True, choices=("fred", "ecb", "bis"))
    ap.add_argument("--start", required=True, help="first observation date YYYY-MM-DD")
    ap.add_argument("--end", required=True, help="last observation date YYYY-MM-DD")
    ap.add_argument("--data-dir", default="data")
    ap.add_argument("--asof", help="fred only: ALFRED vintage date (values as known on that day)")
    ap.add_argument("--series", help="fred only: comma list, default all of " + ",".join(FRED_SERIES))
    ap.add_argument("--curves", help="ecb only: comma list of " + ",".join(ECB_CURVES))
    ap.add_argument("--dry-run", action="store_true", help="fetch and validate, print a summary, save nothing")
    a = ap.parse_args(argv)
    if a.asof and a.source != "fred":
        ap.error("--asof applies to --source fred (ALFRED) only")
    try:
        df = pull(a.source, a.data_dir, a.start, a.end, asof=a.asof,
                  series=a.series.split(",") if a.series else None, curves=a.curves.split(",") if a.curves else None)
    except (PublicSourceError, MarketDataError, FileNotFoundError, ValueError) as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    if df.empty:
        print(f"error: {a.source} returned no observations for {a.start}..{a.end}; nothing saved", file=sys.stderr)
        return 2
    from econquest.ingestion.market.gate import market_gate
    review = market_gate(df)
    holds = review[review["status"] == "hold"]
    print(f"{a.source}: {len(df)} rows, {df['asof'].min()}..{df['asof'].max()}, "
          f"{df.groupby(['source', 'tenor_y']).ngroups} series; gate holds: {len(holds)}")
    for r in holds.head(20).itertuples(index=False):
        print(f"  hold {r.key}: {r.reason}")
    if a.dry_run:
        return 0
    folder = save_public(a.data_dir, df)
    print(f"saved {folder}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
