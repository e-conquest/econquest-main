"""UCDP Georeferenced Event Dataset adapter (EQ-A-0022): annual GED plus monthly Candidate events -> monthly counts.

Source facts (docs/runbooks/A-spike-event-feeds.md, UCDP API docs read 2026-10-23):
- Licence CC BY 4.0; cite UCDP. The API is free.
- Endpoint https://ucdpapi.pcr.uu.se/api/gedevents/<version>. GED 26.1 (yearly, 1989-2025) and Candidate 26.0.9
  (monthly, current year). A version URL returns the same data indefinitely, so a pull is reproducible.
- Pagination: `pagesize` (max 1000 *(verify)*) and `page` (from 0), response keys TotalCount, TotalPages,
  NextPageUrl, Result *(verify the exact key names on the first live pull)*. We step `page` to TotalPages ourselves
  and never follow a URL from the response.
- Filters `Country` (Gleditsch-Ward ids, comma separated), `StartDate`, `EndDate` (YYYY-MM-DD) *(verify)*.
- Auth: token in header `x-ucdp-access-token`, from env UCDP_API_TOKEN only. 5,000 requests per day, errors
  included; RequestBudget stops at `daily_request_limit` (default 4,500, leaving headroom).
- Event fields used: id, country, country_id (Gleditsch-Ward), type_of_violence (1 state-based, 2 non-state,
  3 one-sided), best, date_start *(verify in the GED codebook)*.

UCDP only records organised violence with at least one death: no protests, no non-lethal attacks. Monthly counts
are zero-filled for every requested country inside each dataset's coverage window (an absent month means no fatal
event), and nowhere outside it.

Output metrics (freq "M", period = month of date_start): events_state_based, events_non_state, events_one_sided,
events_total, fatalities_best, fatalities_state_based, fatalities_non_state, fatalities_one_sided.
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import json
import re
from pathlib import Path

import pandas as pd

from econquest.ingestion.events.base import (
    EVENT_COLUMNS, ISO3_RE, EventAdapter, EventDataError, RequestBudget, check_env_name, fetch_with_retries, http_fetch,
    is_enabled, load_event_config, env_secret, month_start, save_event_vintage, utc_stamp,
)

API_BASE = "https://ucdpapi.pcr.uu.se/api/"
ALLOWED_HOST = "ucdpapi.pcr.uu.se"
TOKEN_HEADER = "x-ucdp-access-token"
DEFAULT_GED_VERSION = "26.1"
DEFAULT_CANDIDATE_VERSION = "26.0.9"
DEFAULT_PAGESIZE = 1000
DEFAULT_DAILY_LIMIT = 4500                       # UCDP allows 5,000/day including errors
LICENCE = "CC BY 4.0"
CITATION = "UCDP Georeferenced Event Dataset (GED) Global and UCDP Candidate Events Dataset, Uppsala University"
VERSION_RE = re.compile(r"^\d{1,2}\.\d{1,2}(\.\d{1,2})?$")

VIOLENCE_TYPES = {1: "state_based", 2: "non_state", 3: "one_sided"}
METRICS = ["events_state_based", "events_non_state", "events_one_sided", "events_total", "fatalities_best",
           "fatalities_state_based", "fatalities_non_state", "fatalities_one_sided"]

# The desk's 18 countries (data/countries.csv): Gleditsch-Ward id -> ISO3, with the GED country name(s).
# GW ids are the standard Gleditsch-Ward list; GED names with a former name in brackets follow the GED convention
# *(verify both against the GED codebook / first pull)*.
GW_TO_ISO3 = {
    816: "VNM", 840: "PHL", 710: "CHN", 820: "MYS", 830: "SGP", 740: "JPN", 732: "KOR", 750: "IND", 770: "PAK",
    80: "BLZ", 140: "BRA", 160: "ARG", 100: "COL", 101: "VEN", 475: "NGA", 433: "SEN", 551: "ZMB", 552: "ZWE",
}
NAME_TO_ISO3 = {
    "vietnam": "VNM", "vietnam (north vietnam)": "VNM", "philippines": "PHL", "china": "CHN", "malaysia": "MYS",
    "singapore": "SGP", "japan": "JPN", "south korea": "KOR", "korea, republic of": "KOR", "india": "IND",
    "pakistan": "PAK", "belize": "BLZ", "brazil": "BRA", "argentina": "ARG", "colombia": "COL", "venezuela": "VEN",
    "nigeria": "NGA", "senegal": "SEN", "zambia": "ZMB", "zimbabwe": "ZWE", "zimbabwe (rhodesia)": "ZWE",
}


class UnmappedCountryError(EventDataError):
    """UCDP rows (or requested ISO3 codes) that the country map does not cover. Never guessed."""


def load_country_map(override_csv: Path | None = None) -> tuple[dict[int, str], dict[str, str]]:
    """Built-in map overlaid with a CSV (columns ucdp_id, ucdp_name, iso; either id or name may be blank)."""
    by_id, by_name = dict(GW_TO_ISO3), dict(NAME_TO_ISO3)
    if override_csv is not None and Path(override_csv).exists():
        with open(override_csv, newline="") as f:
            for n, row in enumerate(csv.DictReader(f), start=2):
                iso = (row.get("iso") or "").strip().upper()
                if not ISO3_RE.fullmatch(iso):
                    raise ValueError(f"{override_csv}:{n}: iso {iso!r} is not ISO3")
                uid, name = (row.get("ucdp_id") or "").strip(), (row.get("ucdp_name") or "").strip().lower()
                if not uid and not name:
                    raise ValueError(f"{override_csv}:{n}: needs ucdp_id or ucdp_name")
                if uid:
                    if not uid.isdigit():
                        raise ValueError(f"{override_csv}:{n}: ucdp_id {uid!r} is not an integer")
                    by_id[int(uid)] = iso
                if name:
                    by_name[name] = iso
    return by_id, by_name


def map_countries(events: list[dict], by_id: dict[int, str], by_name: dict[str, str]) -> list[str]:
    """ISO3 per event: by country_id first, then by name; an id/name conflict or a miss is an error, never a guess."""
    out, missing, conflict = [], set(), set()
    for e in events:
        cid, name = e.get("country_id"), str(e.get("country") or "").strip()
        iso_id = by_id.get(int(cid)) if str(cid).strip().lstrip("-").isdigit() else None
        iso_nm = by_name.get(name.lower()) if name else None
        if iso_id and iso_nm and iso_id != iso_nm:
            conflict.add((cid, name, iso_id, iso_nm))
        iso = iso_id or iso_nm
        if not iso:
            missing.add((cid, name))
        out.append(iso)
    if conflict:
        raise UnmappedCountryError(f"UCDP country id and name map to different ISO3 codes: {sorted(conflict, key=str)}")
    if missing:
        raise UnmappedCountryError(f"UCDP countries not in the map (add them to the override CSV): {sorted(missing, key=str)}")
    return out


def aggregate_monthly(events: list[dict], isos: list[str], coverage: list[tuple[dt.date, dt.date]],
                      retrieved_utc: str, licence: str = LICENCE) -> pd.DataFrame:
    """Raw GED events (already carrying 'iso') -> monthly rows per iso and metric, zero-filled inside `coverage`."""
    months = set()
    for lo, hi in coverage:
        for p in pd.period_range(month_start(lo), month_start(hi), freq="M"):
            months.add(p.start_time.date())
    rows = []
    for e in events:
        tv = int(e["type_of_violence"])
        if tv not in VIOLENCE_TYPES:
            raise EventDataError(f"UCDP event {e.get('id')}: unknown type_of_violence {tv}")
        best = float(e["best"])
        if not best >= 0:
            raise EventDataError(f"UCDP event {e.get('id')}: best {e.get('best')!r} is not a count")
        rows.append({"iso": e["iso"], "period": month_start(str(e["date_start"])[:10]), "kind": VIOLENCE_TYPES[tv],
                     "best": best})
    ev = pd.DataFrame(rows, columns=["iso", "period", "kind", "best"])
    ev = ev[ev["period"].isin(months) & ev["iso"].isin(isos)]
    grid = pd.MultiIndex.from_product([sorted(set(isos)), sorted(months)], names=["iso", "period"])
    out = pd.DataFrame(index=grid)
    for kind in VIOLENCE_TYPES.values():
        sub = ev[ev["kind"] == kind].groupby(["iso", "period"])["best"]
        out[f"events_{kind}"] = sub.size().reindex(grid, fill_value=0).astype(float)
        out[f"fatalities_{kind}"] = sub.sum().reindex(grid, fill_value=0.0).astype(float)
    out["events_total"] = out[[f"events_{k}" for k in VIOLENCE_TYPES.values()]].sum(axis=1)
    out["fatalities_best"] = out[[f"fatalities_{k}" for k in VIOLENCE_TYPES.values()]].sum(axis=1)
    long = out[METRICS].reset_index().melt(id_vars=["iso", "period"], var_name="metric", value_name="value")
    long["period"] = long["period"].map(lambda d: d.isoformat())
    long["freq"], long["source"], long["vintage_id"] = "M", "ucdp", ""
    long["retrieved_utc"], long["licence"] = retrieved_utc, licence
    return long[EVENT_COLUMNS].sort_values(["iso", "period", "metric"]).reset_index(drop=True)


def ged_year_end(version: str) -> dt.date:
    """GED <yy>.1 covers events up to 31 December 20<yy-1> (GED 26.1 -> 2025-12-31) *(verify per release note)*."""
    return dt.date(2000 + int(version.split(".")[0]) - 1, 12, 31)


class UcdpAdapter(EventAdapter):
    source = "ucdp"
    licence = LICENCE

    def __init__(self, data_dir: Path | None = None, ged_version: str | None = None,
                 candidate_version: str | None = None, token_env: str | None = None, pagesize: int = DEFAULT_PAGESIZE,
                 country_map_csv: Path | None = None, budget: RequestBudget | None = None, retries: int = 3,
                 backoff: float = 2.0, sleep=None, max_pages: int = 500, candidate_coverage_end: dt.date | None = None,
                 now: dt.datetime | None = None):
        cfg = load_event_config(data_dir).get("ucdp", {}) if data_dir else {}
        self.enabled = is_enabled(cfg, default=True)               # only JSON true enables; "false" does not
        self.ged_version = str(ged_version or cfg.get("ged_version", DEFAULT_GED_VERSION))
        self.candidate_version = str(candidate_version or cfg.get("candidate_version", DEFAULT_CANDIDATE_VERSION))
        for v in (self.ged_version, self.candidate_version):
            if not VERSION_RE.fullmatch(v):
                raise ValueError(f"bad UCDP dataset version {v!r}")
        self.token_env = check_env_name(token_env or cfg.get("token_env", "UCDP_API_TOKEN"), "ucdp.token_env", "UCDP_")
        self.pagesize = int(pagesize)
        if country_map_csv is None and data_dir is not None:
            country_map_csv = Path(data_dir) / "live" / "events" / "ucdp" / "country_map.csv"
        self.by_id, self.by_name = load_country_map(country_map_csv)
        limit = int(cfg.get("daily_request_limit", DEFAULT_DAILY_LIMIT))
        self.budget = budget or RequestBudget(limit, (Path(data_dir) / "live" / "events" / "ucdp" / "request_budget.json")
                                              if data_dir else None)
        self.retries, self.backoff, self.sleep, self.max_pages = retries, backoff, sleep, max_pages
        self.candidate_coverage_end = candidate_coverage_end
        self.now = now
        self._prov: dict = {}

    # -- helpers
    def _gw_ids(self, isos: list[str]) -> list[int]:
        rev: dict[str, list[int]] = {}
        for gid, iso in self.by_id.items():
            rev.setdefault(iso, []).append(gid)
        missing = [i for i in isos if i not in rev]
        if missing:
            raise UnmappedCountryError(f"no UCDP (Gleditsch-Ward) id for ISO3 {missing}; add them to the override CSV")
        return sorted({g for i in isos for g in rev[i]})

    def _url(self, version: str, params: dict) -> str:
        from urllib.parse import urlencode
        return f"{API_BASE}gedevents/{version}?{urlencode(params)}"

    def _pull(self, version: str, gw: list[int], lo: dt.date, hi: dt.date, fetcher, headers) -> list[dict]:
        events, page, total_pages = [], 0, None
        while True:
            params = {"pagesize": self.pagesize, "page": page, "Country": ",".join(map(str, gw)),
                      "StartDate": lo.isoformat(), "EndDate": hi.isoformat()}
            body = fetch_with_retries(fetcher, self._url(version, params), headers, retries=self.retries,
                                      backoff=self.backoff, budget=self.budget,
                                      **({"sleep": self.sleep} if self.sleep else {}))
            try:
                doc = json.loads(body)
            except ValueError:
                raise EventDataError(f"UCDP {version} page {page}: response is not JSON") from None
            if not isinstance(doc, dict) or not isinstance(doc.get("Result"), list):
                raise EventDataError(f"UCDP {version} page {page}: no 'Result' list in response")
            tp = doc.get("TotalPages")
            if not isinstance(tp, int) or tp < 0:
                raise EventDataError(f"UCDP {version} page {page}: TotalPages missing or invalid")
            if total_pages is None:
                total_pages = tp
                if total_pages > self.max_pages:
                    raise EventDataError(f"UCDP {version}: {total_pages} pages exceeds max_pages {self.max_pages}")
            events.extend(doc["Result"])
            page += 1
            if page >= total_pages:
                break
        tc = doc.get("TotalCount")
        if isinstance(tc, int) and tc != len(events):
            raise EventDataError(f"UCDP {version}: got {len(events)} events, TotalCount says {tc}")
        self._prov.setdefault("datasets", []).append(
            {"dataset": "GED" if version == self.ged_version else "Candidate", "version": version,
             "endpoint": f"{API_BASE}gedevents/{version}", "start": lo.isoformat(), "end": hi.isoformat(),
             "pages": total_pages, "events": len(events)})
        return events

    # -- contract
    def fetch(self, isos, start, end, fetcher=None) -> pd.DataFrame:
        if not self.enabled:
            raise RuntimeError("UCDP feed is disabled in data/live/events/feeds.json")
        isos = sorted({str(i).upper() for i in isos})
        bad = [i for i in isos if not ISO3_RE.fullmatch(i)]
        if bad:
            raise ValueError(f"not ISO3: {bad}")
        start, end = pd.Timestamp(start).date(), pd.Timestamp(end).date()
        if start > end:
            raise ValueError("start after end")
        gw = self._gw_ids(isos)
        token = env_secret(self.token_env)
        if not token:
            raise RuntimeError(f"UCDP token missing: set environment variable {self.token_env} (never pass it on the "
                               f"command line or store it in a file in the repo)")
        if not API_BASE.startswith(f"https://{ALLOWED_HOST}/"):
            raise RuntimeError("UCDP API base must be https://" + ALLOWED_HOST)
        headers = {TOKEN_HEADER: token, "Accept": "application/json"}
        fetcher = fetcher or http_fetch
        self._prov = {"citation": CITATION, "licence": LICENCE, "api_base": API_BASE, "auth": f"header {TOKEN_HEADER}",
                      "isos": isos, "gw_ids": gw, "start": start.isoformat(), "end": end.isoformat()}
        retrieved = utc_stamp(self.now)
        g_end = ged_year_end(self.ged_version)
        events, coverage = [], []
        if start <= g_end:
            hi = min(end, g_end)
            events += self._pull(self.ged_version, gw, start, hi, fetcher, headers)
            coverage.append((start, hi))
        if end > g_end:
            lo = max(start, g_end + dt.timedelta(days=1))
            cand = self._pull(self.candidate_version, gw, lo, end, fetcher, headers)
            events += cand
            c_end = self.candidate_coverage_end
            if c_end is None:                                     # latest event month seen in the Candidate pull
                dates = [str(e.get("date_start", ""))[:10] for e in cand if e.get("date_start")]
                c_end = (pd.Timestamp(max(dates)) + pd.offsets.MonthEnd(0)).date() if dates else None
            if c_end is not None:
                coverage.append((lo, min(end, c_end)))
            self._prov["candidate_coverage_end"] = c_end.isoformat() if c_end else None
        if any(not str(e.get("date_start", "")).strip() for e in events):
            raise EventDataError("UCDP events without date_start")
        isos_ev = map_countries(events, self.by_id, self.by_name)
        for e, iso in zip(events, isos_ev):
            e["iso"] = iso
        self._prov["coverage"] = [[a.isoformat(), b.isoformat()] for a, b in coverage]
        self._prov["requests_used_today"] = self.budget.used()
        df = aggregate_monthly(events, isos, coverage, retrieved)
        return self.validate(df)

    def provenance(self) -> dict:
        return dict(self._prov)


def events_from_api_pages(pages: list[dict], isos, coverage, retrieved_utc: str, country_map_csv: Path | None = None) -> pd.DataFrame:
    """Offline helper: aggregate already-downloaded API pages (e.g. saved raw JSON) the same way fetch() does."""
    by_id, by_name = load_country_map(country_map_csv)
    events = [e for p in pages for e in p["Result"]]
    for e, iso in zip(events, map_countries(events, by_id, by_name)):
        e["iso"] = iso
    cov = [(pd.Timestamp(a).date(), pd.Timestamp(b).date()) for a, b in coverage]
    return aggregate_monthly(events, list(isos), cov, retrieved_utc)


def desk_isos(data_dir: Path) -> list[str]:
    """ISO3 codes of the desk's countries (data/countries.csv)."""
    return sorted(pd.read_csv(Path(data_dir) / "countries.csv", dtype=str)["iso"].str.upper().tolist())


def pull_and_save(data_dir: Path, start, end, isos=None, fetcher=None, now: dt.datetime | None = None) -> Path:
    """Mac entry point: fetch UCDP monthly counts for the desk (or `isos`) and save an append-only vintage."""
    ad = UcdpAdapter(data_dir=data_dir, now=now)
    df = ad.fetch(isos or desk_isos(data_dir), start, end, fetcher=fetcher)
    return save_event_vintage(data_dir, df, "ucdp", now=now, provenance=ad.provenance())


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.events.ucdp",
                                 description="Pull UCDP GED + Candidate events (token from $UCDP_API_TOKEN) and save a vintage")
    ap.add_argument("--data-dir", default="data")
    ap.add_argument("--start", required=True, help="YYYY-MM-DD")
    ap.add_argument("--end", required=True, help="YYYY-MM-DD")
    ap.add_argument("--isos", default="", help="comma-separated ISO3; default: every country in data/countries.csv")
    a = ap.parse_args(argv)
    isos = [i.strip() for i in a.isos.split(",") if i.strip()] or None
    v = pull_and_save(Path(a.data_dir), a.start, a.end, isos)
    print(f"saved {v}")
    from econquest.ingestion.events.export import write_event_exports   # keep the consumer exports current (EQ-A-0028)
    ex = write_event_exports(Path(a.data_dir))
    print(f"exports {ex['long']} ({ex['long_rows']} rows), {ex['weekly']} ({ex['weekly_rows']} rows)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
