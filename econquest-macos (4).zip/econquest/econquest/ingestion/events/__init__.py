"""Event-data feeds (UCDP, GDELT, ACLED) for scorecard indicators 4.1, 6.4 and 6.9 (GOV-014, EQ-A-0022..0024).

The shared contract (EVENT_COLUMNS, EventAdapter, vintages, config) lives in `base`. Adapters: `ucdp`, `gdelt`,
`acled`; `indicators` turns stored events into candidate indicator values; `export` derives the consumer tables
(Team B data/live/events/events_long.csv, Team C data/live/events_weekly.csv; EQ-A-0028). Live pulls run on Sam's Mac only
(docs/runbooks/A-event-feeds.md).
"""
from econquest.ingestion.events.base import (  # noqa: F401
    DEFAULT_EVENT_CONFIG, EVENT_COLUMNS, EVENT_CONFIG_PATH, EventAdapter, EventDataError, latest_events,
    list_event_vintages, load_event_config, save_event_vintage, validate_events,
)
from econquest.ingestion.events.export import (  # noqa: F401,E402
    build_events_long, build_events_weekly, load_events_long, write_event_exports,
)
