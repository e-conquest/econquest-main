"""Resumable, staged, point-in-time predictor history for the hazard panel (EQ-A-0010, EQ-A-0015).

Run on Sam's Mac (the cloud sessions cannot reach the IMF or the World Bank):

    python -m econquest.ingestion.panel_history --out data/panel            # new run
    python -m econquest.ingestion.panel_history --out data/panel --resume <run_id>
    python -m econquest.ingestion.panel_history --list-vintages              # what would be pulled, no network

What it does
* Work is split into units: one per WEO release (``weo/<YYYY-MM>``, e.g. ``weo/2019-04``) and one per World Bank
  series (``worldbank/<code>``). Each unit is fetched with retries and exponential backoff and written through a
  temp file + ``os.replace`` to ``<out>/staging/<run_id>/<source>/<unit>.csv``. ``manifest.json`` next to them
  records status, rows, sha256, attempts, error and the source string per unit, and is rewritten atomically after
  every unit, so an interrupted run loses at most the unit in flight.
* Resume (``run_id=`` / ``--resume``) skips every unit whose status is ``ok`` and whose staged file still has the
  recorded sha256; everything else is fetched again.
* Fail loudly: if any unit is still missing at the end, ``IncompleteFetchError`` is raised (``main`` exits 1) and
  the final files are not touched. Only when every unit is ``ok`` are ``<out>/weo_history.csv`` (columns
  ``iso, series, period, value, source, vintage``) and ``<out>/worldbank_history.csv`` (``iso, series, period,
  value, source``) written, through temp files and ``os.replace``. That is the long format
  ``validation.hazard_panel.panel_from_long`` reads; the WEO ``vintage`` column (``YYYY-MM`` of the release) makes
  the WEO features point in time. The World Bank file has no vintage column on purpose: wbgapi serves only the
  current database, and a made-up vintage would claim a point-in-time property the data does not have.
* The universe is every economy the sources return (``isos=None``); nothing is filtered to the desk countries, so
  never-defaulted countries enter the panel as zeros. Aggregates are left in; ``panel_from_long`` drops them.
* After success the final files and the manifest are copied to an append-only panel vintage,
  ``<out>/vintages/<YYYY-MM-DD>T<HHMMSS>Z-<hash8>/`` (files 0444, folder 0555), indexed in ``<out>/vintages/index.csv``
  (``save_panel_vintage``, also used by ``default_panel.import_crag``).

WEO releases and how each is reached (documentation reading on 2026-10-23; nothing was downloaded from the cloud)
* ``imf-reader`` 2.2.0 (``imf_reader.weo.fetch_data(("April", 2019))``): bulk SDMX archive for April 2019 to April
  2025 (the IMF stopped the bulk archive after April 2025); April 2021 and October 2023 are corrupt in the IMF's own
  archive (imf-reader's ``KNOWN_CORRUPT_RELEASES``); October 2025 onwards through the IMF SDMX 3.0 API (``WEO`` and
  ``WEO_<YYYY>_<MON>_VINTAGE`` dataflows).
* ``weo`` package 0.8.4 (``weo.download(year, release)``): the tab-delimited "all countries" file of every release
  from October 2007 (September 2011 is the 2011 autumn release) via imf.org media URLs; its README says "latest
  confirmed April 2024". Used here for October 2007 to April 2025, and as the fallback for the two corrupt SDMX
  releases.
* Earlier releases (1999-2007): the IMF website has WEO database archive pages, but no package wraps them and the
  URLs were not verified. Download the release's tab-delimited file by hand and drop it in the cache folder as
  ``weo_<YYYY-MM>.xls`` (or ``.csv``/``.tsv``/``.txt``); the fetcher reads local files before going to the network.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import re
import shutil
import stat
import sys
import tempfile
import time
from pathlib import Path
from typing import Callable, Iterable

import pandas as pd

from ..common_format import escape_formula
# Series codes are hazard_panel's (Team B owns that module; imported read-only so the two cannot drift apart).
from ..validation.hazard_panel import WB_CODES, WEO_CODES

RUN_ID_RE = re.compile(r"\d{8}T\d{6}Z(-\d+)?")
UNIT_RE = re.compile(r"weo/\d{4}-\d{2}|worldbank/[A-Z0-9.]+")     # manifest unit keys (SEC review S1)
PANEL_VINTAGE_RE = re.compile(r"\d{4}-\d{2}-\d{2}T\d{6}Z-[0-9a-f]{8}")
MAX_WEO_BYTES = 200 * 2**20

LONG_COLUMNS = ["iso", "series", "period", "value", "source"]
WEO_COLUMNS = LONG_COLUMNS + ["vintage"]
SOURCES = ("weo", "worldbank")
FIRST_WEO_PACKAGE = "2007-10"     # weo package: first release it knows
LAST_WEO_BULK = "2025-04"         # IMF stopped publishing bulk files after April 2025
FIRST_IMF_READER = "2019-04"      # imf-reader bulk SDMX archive starts here
IMF_READER_CORRUPT = {"2021-04", "2023-10"}
PANEL_VINTAGE_INDEX = ["vintage_id", "created_utc", "hash", "n_files", "label", "files"]
_MONTHS = {"jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6, "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12}


class IncompleteFetchError(RuntimeError):
    """Raised when units are still missing after the retries. `.manifest` holds the manifest; `.missing` the units."""

    def __init__(self, msg: str, manifest: dict, missing: list[str]):
        super().__init__(msg)
        self.manifest, self.missing = manifest, missing


class FetchUnitError(RuntimeError):
    """A single unit could not be fetched (no route, empty result, bad columns)."""


# ------------------------------------------------------------------------------------------ small utilities

def _utc(now: dt.datetime | None = None) -> dt.datetime:
    now = now or dt.datetime.now(dt.timezone.utc)
    return now.replace(tzinfo=dt.timezone.utc) if now.tzinfo is None else now.astimezone(dt.timezone.utc)


def _stamp(now: dt.datetime) -> str:
    return now.strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def _atomic_write_bytes(path: Path, data: bytes, mode: int = 0o644) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        os.chmod(tmp, mode)
        os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def _csv_bytes(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False, lineterminator="\n").encode()


def normalise_vintage(v) -> str:
    """'2019-04', '2019-4', 'Apr 2019', '2019-Apr', ('April', 2019), 'October 2011' -> 'YYYY-MM'.
    The autumn 2011 release is September ('2011-09'); 'Oct 2011' is mapped to it."""
    if isinstance(v, (tuple, list)) and len(v) == 2:
        v = f"{v[0]} {v[1]}"
    s = str(v).strip()
    m = re.fullmatch(r"(\d{4})-(\d{1,2})", s)
    if m:
        year, month = int(m.group(1)), int(m.group(2))
    else:
        y = re.search(r"(\d{4})", s)
        mo = re.search(r"([A-Za-z]{3})", s)
        if not y or not mo or mo.group(1).lower() not in _MONTHS:
            raise ValueError(f"cannot read WEO release {v!r}: use YYYY-MM, e.g. 2019-04")
        year, month = int(y.group(1)), _MONTHS[mo.group(1).lower()]
    if year == 2011 and month == 10:
        month = 9
    if not 1 <= month <= 12 or not 1990 <= year <= 2100:
        raise ValueError(f"bad WEO release {v!r}")
    return f"{year:04d}-{month:02d}"


def default_weo_vintages(today: dt.date | None = None, first: str = FIRST_WEO_PACKAGE) -> list[str]:
    """April and October releases from `first` (default October 2007, the first the weo package serves) to the
    latest one assumed published by `today` (April from the 20th of April, October from the 20th of October)."""
    today = today or dt.date.today()
    out = []
    for year in range(int(first[:4]), today.year + 1):
        for month in (4, 10):
            v = normalise_vintage(f"{year}-{month:02d}")
            if v < first or dt.date(year, month, 20) > today:
                continue
            out.append(v)
    return out


def _parse_vintage_arg(text: str) -> list[str]:
    """'2007-10:2026-10' (range of April/October releases) or a comma list."""
    out: list[str] = []
    for part in [p.strip() for p in text.split(",") if p.strip()]:
        if ":" in part:
            a, b = (normalise_vintage(x) for x in part.split(":", 1))
            for year in range(int(a[:4]), int(b[:4]) + 1):
                for month in (4, 10):
                    v = normalise_vintage(f"{year}-{month:02d}")
                    if a <= v <= b:
                        out.append(v)
        else:
            out.append(normalise_vintage(part))
    return sorted(set(out))


# ------------------------------------------------------------------------------------------ WEO fetcher adapter

def _num(x):
    if isinstance(x, str):
        x = x.replace(",", "").strip()
        if x in ("", "n/a", "--", "NA", "N/A", "..."):
            return float("nan")
    try:
        return float(x)
    except (TypeError, ValueError):
        return float("nan")


def parse_weo_tab(path: str | Path, codes: Iterable[str], isos: Iterable[str] | None = None) -> pd.DataFrame:
    """Read one WEO 'all countries' file (tab-delimited despite the .xls name; UTF-16 from October 2020, Latin-1
    before) into long rows iso, series, period, value. Columns are found by name ('ISO', 'WEO Subject Code', year
    columns); a file without them raises FetchUnitError."""
    if Path(path).stat().st_size > MAX_WEO_BYTES:                    # refuse oversized downloads before parsing (S2)
        raise FetchUnitError(f"{path}: larger than {MAX_WEO_BYTES // 2**20} MB, not a WEO release file")
    raw = Path(path).read_bytes()
    encodings = ("utf-16",) if raw[:2] in (b"\xff\xfe", b"\xfe\xff") else ("utf-8-sig", "utf-16-le", "iso-8859-1")
    df, last = None, None
    import io
    for enc in encodings:
        try:
            t = pd.read_csv(io.BytesIO(raw), sep="\t", encoding=enc, dtype=str, on_bad_lines="skip")
        except (UnicodeError, ValueError, pd.errors.ParserError) as e:
            last = e
            continue
        cols = {str(c).strip().lower(): c for c in t.columns}
        if "iso" in cols and "weo subject code" in cols:
            df = t.rename(columns={cols["iso"]: "ISO", cols["weo subject code"]: "CODE"})
            break
    if df is None:
        raise FetchUnitError(f"{Path(path).name}: not a WEO tab-delimited file (no ISO / WEO Subject Code columns; {last})")
    years = [c for c in df.columns if re.fullmatch(r"\d{4}", str(c).strip())]
    if not years:
        raise FetchUnitError(f"{Path(path).name}: no year columns")
    sub = df[df["CODE"].astype(str).str.strip().isin(set(codes))]
    if isos is not None:
        sub = sub[sub["ISO"].astype(str).str.strip().isin(set(isos))]
    long = sub.melt(id_vars=["ISO", "CODE"], value_vars=years, var_name="period", value_name="value")
    long["value"] = long["value"].map(_num)
    long = long.dropna(subset=["value"])
    return pd.DataFrame({"iso": long["ISO"].astype(str).str.strip(), "series": long["CODE"].astype(str).str.strip(),
                         "period": long["period"].astype(str).str.strip().astype(int), "value": long["value"].astype(float)})


class WeoVintageFetcher:
    """Fetch one WEO release (``vintage`` 'YYYY-MM') for the given codes. Route, first that applies:

    1. a local file ``<cache_dir>/weo_<vintage>.(xls|csv|tsv|txt)`` (manual downloads of pre-2007 releases, and the
       cache of route 3);
    2. ``imf_reader.weo.fetch_data((month, year))`` for 2019-04 onwards, except the two releases that are corrupt in
       the IMF's bulk archive (2021-04, 2023-10);
    3. ``weo.download(year, release)`` for 2007-10 .. 2025-04 (also the fallback when route 2 fails).
    Anything else raises FetchUnitError naming the file to drop in the cache folder.
    `imf_reader_fetch` and `weo_download` are injectable for tests."""

    def __init__(self, cache_dir: str | Path, imf_reader_fetch: Callable | None = None, weo_download: Callable | None = None):
        self.cache_dir = Path(cache_dir)
        self._imf = imf_reader_fetch
        self._dl = weo_download

    def local_file(self, vintage: str) -> Path | None:
        for ext in (".xls", ".csv", ".tsv", ".txt"):
            p = self.cache_dir / f"weo_{vintage}{ext}"
            if p.is_file() and p.stat().st_size > 0:
                return p
        return None

    @staticmethod
    def routes(vintage: str) -> list[str]:
        r = []
        if vintage >= FIRST_IMF_READER and vintage not in IMF_READER_CORRUPT:
            r.append("imf-reader")
        if FIRST_WEO_PACKAGE <= vintage <= LAST_WEO_BULK:
            r.append("weo-package")
        return r

    def _imf_reader(self, vintage: str, codes, isos) -> pd.DataFrame:
        fetch = self._imf
        if fetch is None:
            from imf_reader import weo as imf_weo  # optional dependency, Mac only
            fetch = imf_weo.fetch_data
        month = "April" if int(vintage[5:]) < 7 else "October"
        df = fetch((month, int(vintage[:4])))
        got = getattr(fetch, "last_version_fetched", None)
        if got is not None and tuple(got) != (month, int(vintage[:4])):
            raise FetchUnitError(f"imf-reader served {got}, not {month} {vintage[:4]}")
        sub = df[df["CONCEPT_CODE"].astype(str).isin(set(codes))]
        if isos is not None:
            sub = sub[sub["REF_AREA_CODE"].astype(str).isin(set(isos))]
        out = pd.DataFrame({"iso": sub["REF_AREA_CODE"].astype(str), "series": sub["CONCEPT_CODE"].astype(str),
                            "period": pd.to_numeric(sub["TIME_PERIOD"], errors="coerce"),
                            "value": pd.to_numeric(sub["OBS_VALUE"], errors="coerce")}).dropna(subset=["period", "value"])
        out["period"] = out["period"].astype(int)
        out["source"] = f"IMF WEO {month} {vintage[:4]} via imf-reader"
        return out

    def _weo_package(self, vintage: str, codes, isos) -> pd.DataFrame:
        dl = self._dl
        if dl is None:
            import weo  # optional dependency, Mac only
            dl = weo.download
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        name = f"weo_{vintage}.xls"
        tmp = f".{name}.part"
        if (self.cache_dir / tmp).exists():
            (self.cache_dir / tmp).unlink()
        res = dl(int(vintage[:4]), "Apr" if int(vintage[5:]) < 7 else "Oct", filename=tmp, directory=str(self.cache_dir))
        url = res[1] if isinstance(res, (tuple, list)) and len(res) > 1 else ""
        try:
            out = parse_weo_tab(self.cache_dir / tmp, codes, isos)  # parse before caching: a bot-check HTML page never sticks
        except BaseException:
            (self.cache_dir / tmp).unlink(missing_ok=True)
            raise
        os.replace(self.cache_dir / tmp, self.cache_dir / name)
        out["source"] = f"IMF WEO {vintage} via weo package" + (f" ({url})" if url else "")
        return out

    def __call__(self, vintage: str, codes: Iterable[str], isos: Iterable[str] | None = None) -> pd.DataFrame:
        vintage = normalise_vintage(vintage)
        codes = list(codes)
        p = self.local_file(vintage)
        if p is not None:
            out = parse_weo_tab(p, codes, isos)
            out["source"] = f"IMF WEO {vintage} local file {p.name} sha256:{sha256_file(p)[:16]}"
            return out
        errors = []
        for route in self.routes(vintage):
            try:
                return self._imf_reader(vintage, codes, isos) if route == "imf-reader" else self._weo_package(vintage, codes, isos)
            except Exception as e:  # noqa: BLE001 - try the next route, report all at the end
                errors.append(f"{route}: {type(e).__name__}: {str(e)[:200]}")
        if not errors:
            raise FetchUnitError(f"no download route for WEO {vintage}: save the release's tab-delimited 'all countries' file "
                                 f"as {self.cache_dir / f'weo_{vintage}.xls'} and resume")
        raise FetchUnitError(f"WEO {vintage}: " + " | ".join(errors))


def worldbank_series_fetcher(code: str, start: int, end: int, isos: Iterable[str] | None = None) -> pd.DataFrame:
    """One World Bank series for every economy (aggregates skipped) through wbgapi; raises on failure (no silent
    skip). PV.EST and other WGI series are retried against database 3 (WGI) if the default database refuses them."""
    import wbgapi as wb  # optional dependency, Mac only
    kw = dict(time=range(start, end + 1), labels=False, skipAggs=True, numericTimeKeys=True)
    economy = list(isos) if isos is not None else "all"
    try:
        df = wb.data.DataFrame(code, economy, **kw)
    except Exception:  # noqa: BLE001 - second chance on the WGI database, then let it raise
        if not code.endswith((".EST", ".PER.RNK")):
            raise
        df = wb.data.DataFrame(code, economy, db=3, **kw)
    long = df.reset_index().melt(id_vars=df.index.name or "economy", var_name="period", value_name="value")
    long.columns = ["iso", "period", "value"]
    long = long.dropna(subset=["value"])
    return pd.DataFrame({"iso": long["iso"].astype(str), "series": code, "period": long["period"].astype(int),
                         "value": long["value"].astype(float), "source": "World Bank API via wbgapi"})


# ------------------------------------------------------------------------------------------ panel vintages

def _content_hash(files: dict[str, bytes]) -> str:
    h = hashlib.sha256()
    for name in sorted(files):
        h.update(name.encode() + b"\0" + files[name] + b"\0")
    return h.hexdigest()


def list_panel_vintages(panel_dir: str | Path) -> list[str]:
    root = Path(panel_dir) / "vintages"
    return sorted(p.name for p in root.iterdir() if p.is_dir() and p.name[:4].isdigit()) if root.exists() else []


def save_panel_vintage(panel_dir: str | Path, files: dict[str, str | Path | bytes], label: str = "",
                       now: dt.datetime | None = None) -> Path:
    """Append-only copy of `files` ({published name: path or bytes}) to <panel_dir>/vintages/<UTC ts>-<hash8>/.

    The folder is created with exist_ok=False (never overwritten), files are 0444 and the folder 0555; a row is
    appended to vintages/index.csv under an exclusive lock. If the newest indexed vintage has the same content
    hash, it is returned instead of making a duplicate."""
    from .ledger import locked_append
    now = _utc(now)
    blobs = {}
    for name, src in files.items():
        if "/" in name or "\\" in name or name.startswith("."):
            raise ValueError(f"bad file name for a panel vintage: {name!r}")
        blobs[name] = src if isinstance(src, bytes) else Path(src).read_bytes()
    digest = _content_hash(blobs)
    root = Path(panel_dir) / "vintages"
    root.mkdir(parents=True, exist_ok=True)
    idx = root / "index.csv"
    if idx.exists():
        prev = pd.read_csv(idx, dtype=str)
        same = prev[prev["hash"] == digest]
        if len(same) and (root / same.iloc[-1]["vintage_id"]).is_dir():
            return root / same.iloc[-1]["vintage_id"]
    v = root / f"{now.strftime('%Y-%m-%dT%H%M%SZ')}-{digest[:8]}"
    v.mkdir(exist_ok=False)
    for name in sorted(blobs):
        (v / name).write_bytes(blobs[name])
        os.chmod(v / name, 0o444)
    # a directory needs the x bit to be listed; no write bit anywhere, so the vintage is read-only
    os.chmod(v, 0o555)  # nosec B103
    with locked_append(idx, PANEL_VINTAGE_INDEX) as (w, f, new):
        if new:
            w.writeheader()
        w.writerow({"vintage_id": v.name, "created_utc": _stamp(now), "hash": digest, "n_files": len(blobs),
                    "label": escape_formula(str(label)), "files": ";".join(sorted(blobs))})
    return v


def remove_panel_vintage(path: str | Path) -> None:
    """Delete one panel vintage folder (``<panel>/vintages/<YYYY-MM-DD>T<HHMMSS>Z-<hash8>``) for clean-up.

    Vintages are written read-only (files 0444, folder 0555), so a plain ``rm -r`` fails for a normal user; this
    restores the owner's write bit first (the ``chmod -R u+w`` of the runbook) and then removes the folder. Only a
    folder named like a vintage directly inside a ``vintages`` folder is accepted. The row in vintages/index.csv is
    kept (the index is append-only); ``save_panel_vintage`` ignores rows whose folder no longer exists."""
    v = Path(path)
    if v.is_symlink() or not v.is_dir() or v.parent.name != "vintages" or not PANEL_VINTAGE_RE.fullmatch(v.name):
        raise ValueError(f"not a panel vintage folder: {v}")
    os.chmod(v, stat.S_IRWXU | stat.S_IRGRP | stat.S_IXGRP)
    for child in v.iterdir():
        if not child.is_symlink():
            os.chmod(child, child.stat().st_mode | stat.S_IWUSR)
    shutil.rmtree(v)


# ------------------------------------------------------------------------------------------ staged fetch

def _units(sources, weo_vintages, wb_codes) -> list[str]:
    u = []
    if "weo" in sources:
        u += [f"weo/{v}" for v in weo_vintages]
    if "worldbank" in sources:
        u += [f"worldbank/{c}" for c in wb_codes]
    return u


def _check_units(units: Iterable[str], params: dict) -> None:
    """Every unit key must match UNIT_RE and the set of units must be exactly the one the params describe, so a
    hand-edited manifest cannot point the fetch or the final assembly at other files (SEC review S1)."""
    units = list(units)
    bad = [u for u in units if not isinstance(u, str) or not UNIT_RE.fullmatch(u)]
    if bad:
        raise ValueError(f"bad unit key(s) in manifest: {bad[:5]}")
    want = set(_units(params.get("sources", []), params.get("weo_vintages", []), params.get("wb_codes", [])))
    if set(units) != want:
        raise ValueError(f"manifest units do not match its params: extra {sorted(set(units) - want)[:5]}, "
                         f"missing {sorted(want - set(units))[:5]}")


def _staged_path(stage: Path, src: str, key: str) -> Path:
    """<stage>/<src>/<key>.csv, refused if it resolves outside the stage folder."""
    f = stage / src / f"{key}.csv"
    root = stage.resolve()
    if not f.resolve().is_relative_to(root):
        raise ValueError(f"staged file {f} resolves outside {root}")
    return f


def _write_manifest(stage: Path, manifest: dict) -> None:
    _atomic_write_bytes(stage / "manifest.json", json.dumps(manifest, indent=1, sort_keys=True).encode())


def _validated(df: pd.DataFrame, unit: str, vintage: str | None) -> pd.DataFrame:
    if df is None or not isinstance(df, pd.DataFrame):
        raise FetchUnitError(f"{unit}: fetcher returned {type(df).__name__}, not a DataFrame")
    miss = [c for c in LONG_COLUMNS if c not in df.columns]
    if miss:
        raise FetchUnitError(f"{unit}: missing columns {miss}")
    d = df[LONG_COLUMNS].copy()
    d["iso"] = d["iso"].astype(str).str.strip().str.upper()
    d["series"] = d["series"].astype(str).str.strip()
    d["period"] = pd.to_numeric(d["period"], errors="coerce")
    d["value"] = pd.to_numeric(d["value"], errors="coerce")
    d = d.dropna(subset=["period", "value"])
    d = d[d["iso"].str.fullmatch(r"[A-Z0-9]{3}")]
    d["period"] = d["period"].astype(int)
    if d.empty:
        raise FetchUnitError(f"{unit}: no rows")
    if vintage is not None:
        d["vintage"] = vintage
    return d.sort_values(["iso", "series", "period"]).reset_index(drop=True)


def fetch_history(out_dir: str | Path, sources: Iterable[str] = SOURCES, weo_vintages: Iterable[str] | None = None,
                  isos: Iterable[str] | None = None, retries: int = 3, backoff: float = 2.0, fetchers: dict | None = None, *,
                  run_id: str | None = None, wb_codes: Iterable[str] | None = None, weo_codes: Iterable[str] | None = None,
                  wb_start: int = 1980, wb_end: int | None = None, cache_dir: str | Path | None = None,
                  save_vintage: bool = True, now: dt.datetime | None = None, sleep: Callable[[float], None] = time.sleep,
                  log: Callable[[str], None] = print) -> dict:
    """Staged, resumable pull of every economy's WEO (one unit per release) and World Bank (one unit per series)
    history. Returns the manifest (dict) when every unit is ok and the final files are written; raises
    IncompleteFetchError (final files untouched) otherwise.

    run_id: None starts a new run (UTC timestamp id); an existing id resumes it with the parameters stored in its
    manifest (sources, vintages, codes, isos, years), skipping units already ok with a matching sha256.
    fetchers: {"weo": f(vintage, codes, isos) -> DataFrame, "worldbank": f(code, start, end, isos) -> DataFrame},
    each returning columns iso, series, period, value, source; defaults are WeoVintageFetcher and
    worldbank_series_fetcher. retries: extra attempts per unit after the first; the wait before retry k is
    backoff * 2**(k-1) seconds."""
    out = Path(out_dir)
    now = _utc(now)
    staging = out / "staging"
    if run_id:
        if not RUN_ID_RE.fullmatch(str(run_id)):                     # --resume value: no path parts (SEC review S1)
            raise ValueError(f"bad run id {run_id!r}: expected YYYYMMDDTHHMMSSZ[-n]")
        stage = staging / run_id
        mpath = stage / "manifest.json"
        if not mpath.is_file():
            raise FileNotFoundError(f"no run {run_id!r}: {mpath} does not exist")
        manifest = json.loads(mpath.read_text())
        params = manifest["params"]
        _check_units(manifest["units"], params)
        log(f"resuming run {run_id}: {sum(u['status'] == 'ok' for u in manifest['units'].values())}/{len(manifest['units'])} units ok")
    else:
        run_id = now.strftime("%Y%m%dT%H%M%SZ")
        stage = staging / run_id
        n = 0
        while stage.exists():
            n += 1
            stage = staging / f"{run_id}-{n}"
        run_id = stage.name
        sources = [s for s in sources]
        bad = [s for s in sources if s not in SOURCES]
        if bad or not sources:
            raise ValueError(f"sources must be a non-empty subset of {SOURCES}, got {sources}")
        vint = sorted({normalise_vintage(v) for v in weo_vintages}) if weo_vintages is not None else default_weo_vintages(now.date())
        params = {"sources": sources, "weo_vintages": vint if "weo" in sources else [],
                  "weo_codes": list(weo_codes or WEO_CODES), "wb_codes": list(wb_codes or WB_CODES) if "worldbank" in sources else [],
                  "isos": sorted(set(isos)) if isos is not None else None,
                  "wb_start": int(wb_start), "wb_end": int(wb_end or now.year)}
        manifest = {"run_id": run_id, "created_utc": _stamp(now), "params": params, "status": "running",
                    "units": {u: {"status": "pending", "rows": 0, "sha256": "", "file": "", "attempts": 0, "error": ""}
                              for u in _units(params["sources"], params["weo_vintages"], params["wb_codes"])}}
        _check_units(manifest["units"], params)
        stage.mkdir(parents=True, exist_ok=False)
        _write_manifest(stage, manifest)
        log(f"new run {run_id}: {len(manifest['units'])} units -> {stage}")
    if not manifest["units"]:
        raise ValueError("nothing to fetch (no WEO releases and no World Bank series)")

    fetchers = dict(fetchers or {})
    if "weo" not in fetchers:
        fetchers["weo"] = WeoVintageFetcher(cache_dir or (staging / "weo_cache"))
    fetchers.setdefault("worldbank", worldbank_series_fetcher)
    p = params
    for unit, rec in manifest["units"].items():
        src, key = unit.split("/", 1)
        f = _staged_path(stage, src, key)
        if rec["status"] == "ok" and f.is_file() and sha256_file(f) == rec["sha256"]:
            continue
        rec.update(status="pending", error="")
        for attempt in range(1, retries + 2):
            rec["attempts"] = int(rec.get("attempts", 0)) + 1
            try:
                if src == "weo":
                    df = _validated(fetchers["weo"](key, p["weo_codes"], p["isos"]), unit, key)
                else:
                    df = _validated(fetchers["worldbank"](key, p["wb_start"], p["wb_end"], p["isos"]), unit, None)
                data = _csv_bytes(df)
                _atomic_write_bytes(f, data)
                rec.update(status="ok", rows=len(df), sha256=hashlib.sha256(data).hexdigest(), file=f"{src}/{key}.csv",
                           error="", fetched_utc=_stamp(_utc()), n_economies=int(df["iso"].nunique()),
                           source=str(df["source"].iloc[0]),
                           codes_missing=sorted(set(p["weo_codes"]) - set(df["series"])) if src == "weo" else [])
                log(f"  {unit}: ok, {len(df):,} rows, {df['iso'].nunique()} economies")
                break
            except Exception as e:  # noqa: BLE001 - any failure is recorded and retried, then reported
                rec.update(status="failed", error=f"{type(e).__name__}: {str(e)[:300]}")
                log(f"  {unit}: attempt {attempt} failed: {rec['error']}")
                if attempt <= retries:
                    sleep(backoff * 2 ** (attempt - 1))
        _write_manifest(stage, manifest)

    missing = [u for u, r in manifest["units"].items() if r["status"] != "ok"]
    if missing:
        manifest["status"] = "incomplete"
        _write_manifest(stage, manifest)
        raise IncompleteFetchError(f"{len(missing)} of {len(manifest['units'])} units missing after retries: {missing[:10]}. "
                                   f"Final files not written. Resume with --resume {run_id}", manifest, missing)

    # every unit ok: assemble, then replace the final files
    finals: dict[str, bytes] = {}
    if "weo" in p["sources"]:
        weo = pd.concat([pd.read_csv(_staged_path(stage, "weo", v), dtype={"iso": str, "series": str, "vintage": str})
                         for v in p["weo_vintages"]], ignore_index=True)
        finals["weo_history.csv"] = _csv_bytes(weo[WEO_COLUMNS].sort_values(["vintage", "iso", "series", "period"], kind="stable"))
    if "worldbank" in p["sources"]:
        wbh = pd.concat([pd.read_csv(_staged_path(stage, "worldbank", c), dtype={"iso": str, "series": str})
                         for c in p["wb_codes"]], ignore_index=True)
        finals["worldbank_history.csv"] = _csv_bytes(wbh[LONG_COLUMNS].sort_values(["series", "iso", "period"], kind="stable"))
    tmp = {}
    try:
        for name, data in finals.items():
            fd, t = tempfile.mkstemp(dir=out, prefix=f".{name}.", suffix=".tmp")
            with os.fdopen(fd, "wb") as fh:
                fh.write(data)
            os.chmod(t, 0o644)
            tmp[name] = t
        for name, t in tmp.items():
            os.replace(t, out / name)
    finally:
        for t in tmp.values():
            if os.path.exists(t):
                os.unlink(t)
    manifest["status"] = "complete"
    manifest["final"] = {name: {"sha256": hashlib.sha256(d).hexdigest(), "bytes": len(d)} for name, d in finals.items()}
    manifest["completed_utc"] = _stamp(_utc())
    if save_vintage:
        files = {name: out / name for name in finals}
        files["manifest.json"] = json.dumps(manifest, indent=1, sort_keys=True).encode()
        v = save_panel_vintage(out, files, label=f"history run {run_id}", now=now)
        manifest["panel_vintage"] = v.name
        log(f"panel vintage {v}")
    _write_manifest(stage, manifest)
    for name in finals:
        log(f"wrote {out / name} (sha256 {manifest['final'][name]['sha256'][:16]})")
    return manifest


# ------------------------------------------------------------------------------------------ command line

def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.panel_history",
                                 description="Staged, resumable WEO (all releases) and World Bank history pull for the hazard panel.")
    ap.add_argument("--out", default="data/panel", help="panel folder (default data/panel)")
    ap.add_argument("--resume", metavar="RUN_ID", help="resume a run under <out>/staging/RUN_ID with its stored parameters")
    ap.add_argument("--sources", default="weo,worldbank", help="comma list of weo, worldbank")
    ap.add_argument("--weo-vintages", help="WEO releases: '2007-10:2026-10' or a comma list (default: Oct 2007 to the latest)")
    ap.add_argument("--isos", help="comma list of ISO3 codes (default: every economy)")
    ap.add_argument("--retries", type=int, default=3)
    ap.add_argument("--backoff", type=float, default=2.0)
    ap.add_argument("--wb-start", type=int, default=1980)
    ap.add_argument("--wb-end", type=int)
    ap.add_argument("--cache-dir", help="WEO file cache and drop folder for manual downloads (default <out>/staging/weo_cache)")
    ap.add_argument("--no-vintage", action="store_true", help="do not save a panel vintage after success")
    ap.add_argument("--list-vintages", action="store_true", help="print the WEO releases and download route of each, then exit")
    a = ap.parse_args(argv)
    try:
        vint = _parse_vintage_arg(a.weo_vintages) if a.weo_vintages else None
    except ValueError as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    out = Path(a.out)
    if a.list_vintages:
        cache = Path(a.cache_dir) if a.cache_dir else out / "staging" / "weo_cache"
        fx = WeoVintageFetcher(cache)
        for v in vint or default_weo_vintages():
            r = (["local file"] if fx.local_file(v) else []) + fx.routes(v)
            print(f"{v}  {', '.join(r) if r else 'NO ROUTE: drop weo_' + v + '.xls in ' + str(cache)}")
        return 0
    if not out.is_dir():
        print(f"error: {out} is not a folder (run from the econquest folder)", file=sys.stderr)
        return 2
    try:
        m = fetch_history(out, sources=[s.strip() for s in a.sources.split(",") if s.strip()], weo_vintages=vint,
                          isos=[s.strip().upper() for s in a.isos.split(",")] if a.isos else None, retries=a.retries,
                          backoff=a.backoff, run_id=a.resume, wb_start=a.wb_start, wb_end=a.wb_end,
                          cache_dir=a.cache_dir, save_vintage=not a.no_vintage)
    except IncompleteFetchError as e:
        print(f"INCOMPLETE: {e}", file=sys.stderr)
        for u in e.missing:
            print(f"  {u}: {e.manifest['units'][u]['error']}", file=sys.stderr)
        return 1
    except (ValueError, FileNotFoundError) as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    n = {u: r for u, r in m["units"].items()}
    print(f"complete: run {m['run_id']}, {len(n)} units, panel vintage {m.get('panel_vintage', '(not saved)')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
