"""Live data feeds for the Inputs and Country Profile tables.

Packages (chosen by Sam, 2026-10-23): `imf-reader` (IMF WEO through the IMF SDMX API, with the `weo`
package's bulk download as a fallback), `wbgapi` (World Bank WDI, IDS and WGI). `bis-fetcher` turned out to scrape
BIS central-bank speeches, not BIS statistics, so the BIS series (effective exchange rates, credit-to-GDP gaps, policy
rates, daily exchange rates) are read from the BIS SDMX REST API directly (stats.bis.org, no key).

FX (EQ-A-0040, Sam 2026-10-23 "Replace with free official"): the Country Profile fx3m comes from official daily
reference rates, BIS WS_XRU (feed `bis_xru`, primary) with the ECB EXR reference rates (feed `ecb_exr`) as cross-check
and as the fallback for currencies BIS has no series for. Yahoo Finance (`yfinance`) is personal, non-commercial use
under Yahoo's terms: it is no longer a fetch_all feed, and naming it (`only=["yahoo"]`) is refused, not fetched.
YahooFeed stays in this module for non-desk research only. Equity ETF prices and equity_vol have no official free
source: they are left unserved with NO_OFFICIAL_SOURCE (docs/runbooks/A-official-fx.md).

Every feed returns a long table with the same columns: iso, series, period, value, source. Transforms
(`build_live_tables`) turn those into the Inputs unit for each indicator the API Map marks as a scripted
series, plus the Country Profile fields population, exports, reserves, FX change and policy rate.
Indicators that the API Map marks Manual or File stay as the analyst entered them.

A feed that cannot be reached raises `FeedError`; `fetch_all` catches it per feed and reports it, so a
blocked network never silently mixes stale and live numbers: every value written carries its source and
retrieval date in `data/live/provenance.csv`."""
from __future__ import annotations

import contextlib
import csv
import datetime as dt
import errno
import hashlib
import io
import json
import logging
import math
import os
import re
import shutil
import socket
import ssl
import sys
import tempfile
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Iterable

import numpy as np
import pandas as pd

from .sources import RedirectRefused, https_get, read_csv_keep_na_code

LONG_COLUMNS = ["iso", "series", "period", "value", "source"]


class FeedError(RuntimeError):
    """A feed could not be reached or returned nothing usable."""


class FeedUnreachable(FeedError):
    """EQ-A-0037: a request of the feed failed in a way that every further request would repeat (the proxy refused the
    CONNECT tunnel, or the host name does not resolve), so the feed stops there instead of retrying per batch, per
    country or per series. `reason` is the short text fetch_all prints."""

    def __init__(self, reason: str):
        super().__init__(reason)
        self.reason = reason


class NoFeedSucceeded(SystemExit):
    """EQ-A-0037 (usability U04): save_report / save_vintage refuse a report in which no feed succeeded, before anything
    is written, so an offline `econquest fetch` leaves data/live and the vintages untouched. A SystemExit (like
    cli.RunGateBlocked) so the command stops with this one line and exit status 1 instead of a traceback."""


# ----------------------------------------------------------------------------------------------
# Connectivity (EQ-A-0037, HO-20261023-C-A-008, usability U04): one cheap probe per host before a feed's work, and
# proxy/tunnel refusals are never retried. Offline, the old pull ran 400+ s and printed the same proxy error ~20x per
# feed (BIS: retries with backoff on every batch, then every country; World Bank: every series one by one).
# ----------------------------------------------------------------------------------------------
# Hosts each feed talks to, read from the packages' sources (imf-reader 2.2.0, weo 0.8.4, wbgapi 1.0.14, yfinance
# 1.7.0) and BisFeed.base. A feed is skipped only when every one of its hosts fails the probe.
FEED_HOSTS = {
    "weo": ("api.imf.org", "www.imf.org"),          # imf-reader SDMX 3.0 API; imf-reader scraper and the weo package
    "worldbank": ("api.worldbank.org",),            # wbgapi.endpoint
    "worldbank_history": ("api.worldbank.org",),
    "bis": ("stats.bis.org",),                      # BisFeed.base
    "bis_cbs": ("stats.bis.org",),
    "bis_xru": ("stats.bis.org",),                  # EQ-A-0040: BIS daily exchange rates, same client as BisFeed
    "ecb_exr": ("data-api.ecb.europa.eu",),         # EQ-A-0040: ECB reference rates, EcbExrFeed.base
}
# Not a fetch_all feed since EQ-A-0040 (Yahoo terms: personal, non-commercial use); kept for YahooFeed's messages.
YAHOO_HOSTS = ("query2.finance.yahoo.com", "query1.finance.yahoo.com")     # yfinance _BASE_URL_ (chart), _QUERY1_URL_
WB_HOST = "api.worldbank.org"
PROBE_TIMEOUT = 4.0           # seconds; a probe is one HEAD request to https://<host>/

_PROXY_MARKERS = ("tunnel connection failed", "unable to connect to proxy", "connect tunnel failed",
                  "from proxy after connect", "proxy authentication required", "could not resolve proxy")
_DNS_MARKERS = ("name or service not known", "nodename nor servname", "temporary failure in name resolution",
                "getaddrinfo failed", "failed to resolve", "could not resolve host", "no address associated with hostname")


def _exc_chain(e: BaseException | None):
    """e, its causes, contexts, URLError reasons and exception args (requests and urllib3 nest the socket error)."""
    seen, stack = set(), [e]
    while stack:
        x = stack.pop()
        if not isinstance(x, BaseException) or id(x) in seen:
            continue
        seen.add(id(x))
        yield x
        stack += [x.__cause__, x.__context__, getattr(x, "reason", None)] + [a for a in x.args if isinstance(a, BaseException)]


def _text(x: BaseException) -> str:
    return f"{type(x).__name__}: {x}".lower()


def _is_proxy_refusal(e: BaseException) -> bool:
    """The proxy refused to open a tunnel (CONNECT 403/407, urllib 'Tunnel connection failed', requests ProxyError,
    curl 'CONNECT tunnel failed'). Retrying cannot help within a run."""
    for x in _exc_chain(e):
        if isinstance(x, urllib.error.HTTPError) and x.code == 407:
            return True
        if type(x).__name__ == "ProxyError" or any(m in _text(x) for m in _PROXY_MARKERS):
            return True
    return False


def _is_dns_failure(e: BaseException) -> bool:
    return any(isinstance(x, socket.gaierror) or any(m in _text(x) for m in _DNS_MARKERS) for x in _exc_chain(e))


def _stop_reason(e: BaseException, host: str) -> str | None:
    """Short reason when `e` means no further request to `host` can work in this run (proxy refusal, DNS failure),
    else None. Timeouts, resets, 429 and 5xx are not stop reasons: they keep their retries."""
    if _is_proxy_refusal(e):
        return f"proxy refused CONNECT to {host}"
    if _is_dns_failure(e):
        return f"DNS lookup failed for {host}"
    redirect = next((x for x in _exc_chain(e) if isinstance(x, RedirectRefused)), None)
    if redirect is not None:              # SEC-A-006 L1: a portal or CDN redirecting one request redirects them all
        return str(redirect)
    return None


def _stop_if_unreachable(e: BaseException, host: str) -> None:
    why = _stop_reason(e, host)
    if why:
        raise FeedUnreachable(why) from e


def _unreachable_reason(e: BaseException, host: str, timeout: float = PROBE_TIMEOUT) -> str:
    """Short reason for a failed probe of `host`."""
    why = _stop_reason(e, host)
    if why:
        return why
    chain = list(_exc_chain(e))
    if any(isinstance(x, (TimeoutError, socket.timeout)) or "timed out" in _text(x) for x in chain):
        return f"no answer from {host} within {timeout:g} s"
    if any(isinstance(x, ConnectionRefusedError) for x in chain):
        return f"connection to {host} refused"
    if any(isinstance(x, OSError) and x.errno in (errno.ENETUNREACH, errno.EHOSTUNREACH) for x in chain):
        return f"network unreachable for {host}"
    return f"cannot connect to {host}: {type(e).__name__}: {str(getattr(e, 'reason', e))[:80]}"


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, *a, **k):        # a 3xx answer already proves the host is reachable
        return None


def probe_host(host: str, timeout: float = PROBE_TIMEOUT) -> str | None:
    """One HEAD request to https://<host>/ through the same proxy settings the feed packages use (environment
    variables). None when the host answers with any HTTP status (a 403 or 404 page is an answer); a TLS failure also
    counts as reachable, since the tunnel was opened and the feed itself reports certificate problems. Otherwise a
    short reason (proxy refusal, DNS, timeout, refused)."""
    if not host or "/" in host or ":" in host:
        raise ValueError(f"probe_host takes a bare host name: {host!r}")
    opener = urllib.request.build_opener(_NoRedirect())
    req = urllib.request.Request(f"https://{host}/", method="HEAD", headers={"User-Agent": "econquest/0.2"})
    try:
        # B310: fixed https scheme and a bare host name checked above (EQ-A-0037)
        with opener.open(req, timeout=timeout):  # nosec B310
            return None
    except urllib.error.HTTPError as e:
        return f"proxy refused CONNECT to {host}" if e.code == 407 else None
    except Exception as e:  # noqa: BLE001 - classified below
        if not _is_proxy_refusal(e) and any(isinstance(x, ssl.SSLError) for x in _exc_chain(e)):
            return None
        return _unreachable_reason(e, host, timeout)


def _one_line(s: str, n: int = 300) -> str:
    s = " ".join(str(s).split())
    return s if len(s) <= n else s[:n - 3] + "..."


def _is_transient(e: BaseException) -> bool:
    """Worth retrying: timeouts, connection errors, HTTP 429 and 5xx. HTTP 4xx other than 429 (e.g. 404 'no data
    for this key') is final, and so is a proxy refusing the CONNECT tunnel (403/407), which no retry can fix
    (EQ-A-0037)."""
    if _is_proxy_refusal(e):
        return False
    if isinstance(e, urllib.error.HTTPError):
        return e.code == 429 or e.code >= 500
    return isinstance(e, (urllib.error.URLError, TimeoutError, ConnectionError))


def _with_retries(fn: Callable[[], object], retries: int = 3, backoff: float = 1.0,
                  sleep: Callable[[float], None] | None = None):
    """fn() with up to `retries` retries on transient errors, waiting backoff * 2**attempt between attempts."""
    sleep = sleep or time.sleep
    for attempt in range(retries + 1):
        try:
            return fn()
        except Exception as e:  # noqa: BLE001 - classified below
            if attempt == retries or not _is_transient(e):
                raise
            sleep(backoff * (2 ** attempt))
    raise AssertionError("unreachable")


def _long(rows: list[dict], source: str) -> pd.DataFrame:
    df = pd.DataFrame(rows, columns=LONG_COLUMNS[:-1])
    df["source"] = source
    df["value"] = pd.to_numeric(df["value"], errors="coerce")
    return df.dropna(subset=["value"]).reset_index(drop=True)


def _long_keyed(rows: list[dict], source: str) -> pd.DataFrame:
    """_long plus an `sdmx_key` column naming the series each row came from (EQ-A-0040: raw_bis_xru / raw_ecb_exr)."""
    df = pd.DataFrame(rows, columns=[*LONG_COLUMNS[:-1], "sdmx_key"])
    df["source"] = source
    df["value"] = pd.to_numeric(df["value"], errors="coerce")
    return df.dropna(subset=["value"])[[*LONG_COLUMNS, "sdmx_key"]].reset_index(drop=True)


# ----------------------------------------------------------------------------------------------
# IMF World Economic Outlook
# ----------------------------------------------------------------------------------------------
WEO_CODES = ["GGXWDG_NGDP", "GGXONLB_NGDP", "GGXCNL_NGDP", "NGDP", "NGDP_RPCH", "PCPIPCH", "BCA_NGDPD", "NGDPDPC", "NGDPD", "GGR_NGDP"]


@dataclass
class WeoFeed:
    """IMF WEO via imf-reader (SDMX API); falls back to the `weo` package's spreadsheet download."""
    version: tuple[str, int] | None = None     # ("October", 2026); None = latest published
    cache_dir: Path | None = None

    def fetch(self, isos: Iterable[str], codes: Iterable[str] = WEO_CODES, offline: bool = False) -> pd.DataFrame:
        """offline=True (EQ-A-0037: the IMF hosts failed the probe) reads only the cached `weo` download
        (`cache_file()`), never the network."""
        isos, codes = list(isos), list(codes)
        if offline:
            if not self.cache_file().exists():
                raise FeedError(f"IMF WEO: hosts unreachable and no cached download at {self.cache_file()}")
            try:
                return self._weo_package(isos, codes)
            except Exception as e:  # noqa: BLE001
                raise FeedError(f"IMF WEO cached download {self.cache_file().name} unusable: {type(e).__name__}: {str(e)[:160]}") from e
        try:
            return self._imf_reader(isos, codes)
        except Exception as e1:  # noqa: BLE001 - we want the fallback whatever the cause
            try:
                return self._weo_package(isos, codes)
            except Exception as e2:  # noqa: BLE001
                why = _stop_reason(e1, "api.imf.org") and _stop_reason(e2, "www.imf.org")
                if why:                     # both paths refused by the proxy / DNS: one short line, no package noise
                    raise FeedUnreachable(why) from e2
                raise FeedError(f"IMF WEO unreachable: imf-reader said {type(e1).__name__}: {str(e1)[:160]}; weo said {type(e2).__name__}: {str(e2)[:160]}") from e2

    def _release(self) -> tuple[int, str]:
        year, rel = self.version[1] if self.version else dt.date.today().year, ("Oct" if (self.version or ("October",))[0].startswith("Oct") else "Apr")
        if self.version is None:
            rel = "Oct" if dt.date.today().month >= 10 else "Apr"
        return year, rel

    def cache_file(self) -> Path:
        """Where the `weo` package's download for this release is cached (outputs/cache/weo_<year>_<Oct|Apr>.csv)."""
        year, rel = self._release()
        return Path(self.cache_dir or Path.cwd() / "outputs" / "cache") / f"weo_{year}_{rel}.csv"

    def _imf_reader(self, isos, codes) -> pd.DataFrame:
        from imf_reader import weo as imf_weo
        df = imf_weo.fetch_data(version=self.version)
        sub = df[df["CONCEPT_CODE"].isin(codes) & df["REF_AREA_CODE"].astype(str).isin(isos)]
        if sub.empty:
            raise FeedError("imf-reader returned no rows for the requested countries")
        ver = self.version or (None, None)
        src = f"imf-reader WEO {ver[0] or 'latest'} {ver[1] or ''}".strip()
        rows = [{"iso": str(r.REF_AREA_CODE), "series": r.CONCEPT_CODE, "period": int(r.TIME_PERIOD), "value": r.OBS_VALUE} for r in sub.itertuples()]
        return _long(rows, src)

    def _weo_package(self, isos, codes) -> pd.DataFrame:
        import weo
        year, rel = self._release()
        path = self.cache_file(); d = path.parent; d.mkdir(parents=True, exist_ok=True)
        if not path.exists():
            weo.download(year, rel, filename=path.name, directory=str(d))
        w = weo.WEO(str(path))
        rows = []
        for code in codes:
            try:
                frame = w.getc(code)      # index: year, columns: ISO3
            except Exception:  # noqa: BLE001 - code missing in this vintage
                continue
            for iso in isos:
                if iso in frame.columns:
                    for period, value in frame[iso].dropna().items():
                        rows.append({"iso": iso, "series": code, "period": int(period), "value": value})
        return _long(rows, f"weo package WEO {rel} {year}")


# ----------------------------------------------------------------------------------------------
# World Bank (WDI source 2, IDS source 6, WGI source 3)
# ----------------------------------------------------------------------------------------------
WB_SERIES = {
    # series: (database, label). EQ-A-0027: one wbgapi call per database; when it fails the series are retried one by
    # one, so a single invalid code no longer empties the whole database (that is how 3.4/3.5 died on 2026-10-23).
    "SP.POP.TOTL": (2, "population"),
    "NE.EXP.GNFS.ZS": (2, "exports % GDP"),
    "FI.RES.TOTL.CD": (2, "total reserves US$"),
    "NY.GDP.MKTP.CD": (2, "GDP US$"),
    "FB.AST.NPER.ZS": (2, "NPL % loans"),
    "VC.IHR.PSRC.P5": (2, "homicides per 100k"),
    "SL.UEM.1524.ZS": (2, "youth unemployment"),
    # 2.9: WDI (source 2) series. The 2026-10-23 pull asked IDS (source 6) for it in the same call that returned
    # DT.DOD.DECT.EX.ZS and DT.TDS.DPPG.CD for 13 countries, and got no row for any country. Retried in IDS if WDI is empty.
    "DT.DOD.DSTC.IR.ZS": (2, "short-term external debt % reserves"),
    "DT.DOD.DECT.EX.ZS": (6, "external debt % exports"),
    "DT.TDS.DPPG.CD": (6, "PPG debt service US$"),
    # WGI (source 3). Legacy percentile-rank codes (2026-10-23: no WGI row at all came back) and the codes the
    # rulebook API Map names (GOV_WGI_*.SC). wb_transforms uses one family per country, percentile ranks first.
    "RL.PER.RNK": (3, "WGI rule of law percentile"),
    # cross-source counterparts of WEO series (EQ-A-0017 crosscheck.CROSS_PAIRS); fetched for the gate only
    "NY.GDP.MKTP.KD.ZG": (2, "real GDP growth %"),
    "FP.CPI.TOTL.ZG": (2, "CPI inflation %"),
    "BN.CAB.XOKA.GD.ZS": (2, "current account % GDP"),
    "CC.PER.RNK": (3, "WGI control of corruption percentile"),
    "RQ.PER.RNK": (3, "WGI regulatory quality percentile"),
    "GOV_WGI_RL.SC": (3, "WGI rule of law score (rulebook code)"),
    "GOV_WGI_CC.SC": (3, "WGI control of corruption score (rulebook code)"),
    "GOV_WGI_RQ.SC": (3, "WGI regulatory quality score (rulebook code)"),
}
WB_ALT_DB = {"DT.DOD.DSTC.IR.ZS": (6,)}     # databases to try when a series' primary database returns no row
WGI_FAMILIES = (("RL.PER.RNK", "CC.PER.RNK", "RQ.PER.RNK"), ("GOV_WGI_RL.SC", "GOV_WGI_CC.SC", "GOV_WGI_RQ.SC"))
# EQ-A-0036: the 2024+ WGI database reports GOV_WGI_*.SC as a 0-100 *score* (a rescaled estimate), not a percentile
# rank, while 3.5 and its thresholds are percentile ranks. WorldBankFeed pulls the score family for all economies
# (aggregates excluded) and tags those rows with WGI_XS_SOURCE, so wb_transforms can rank each score among all
# economies of the same year offline, from the vintage. Without that cross-section 3.4/3.5 stay empty.
WGI_SCORE_FAMILY = WGI_FAMILIES[1]
WGI_XS_SOURCE = "wbgapi World Bank API v2, all economies (WGI cross-section for percentile ranks, aggregates excluded)"
WGI_XS_MIN = 100            # fewer economies than this in a year is not a usable cross-section (WGI covers ~200)
# World Bank region/income/lending aggregates (no ISO3 country code). Belt and braces next to wbgapi's skipAggs and
# the per-record `aggregate` flag: a code in this set never enters a WGI ranking.
WB_AGGREGATE_CODES = frozenset(
    "AFE AFW ARB CEB CSS EAP EAR EAS ECA ECS EMU EUU FCS HIC HPC IBD IBT IDA IDB IDX INX LAC LCN LDC LIC LMC LMY "
    "LTE MEA MIC MNA NAC OED OSS PRE PSS PST SAS SSA SSF SST TEA TEC TLA TMN TSA TSS UMC WLD".split())


@dataclass
class WorldBankFeed:
    """World Bank API via wbgapi. `mrnev` most-recent non-empty values per economy."""
    series: dict = field(default_factory=lambda: dict(WB_SERIES))
    mrnev: int = 6

    alt_db: dict = field(default_factory=lambda: dict(WB_ALT_DB))

    def fetch(self, isos: Iterable[str]) -> pd.DataFrame:
        import wbgapi as wb
        isos = list(isos); rows = []; failures = []
        by_db: dict[int, list[str]] = {}
        xs = [s for s in WGI_SCORE_FAMILY if s in self.series]     # pulled for all economies below (EQ-A-0036)
        for s, (db, _) in self.series.items():
            if s not in xs:
                by_db.setdefault(db, []).append(s)

        def pull(series: list[str], db: int) -> list[dict]:
            return [{"iso": rec["economy"], "series": rec["series"], "period": int(str(rec["time"]).replace("YR", "")), "value": rec["value"]}
                    for rec in wb.data.fetch(series, isos, mrnev=self.mrnev, db=db, skipBlanks=True)]

        xs_rows: list[dict] = []
        if xs:
            xdb = self.series[xs[0]][0]
            try:
                xs_rows = [{"iso": rec["economy"], "series": rec["series"], "period": int(str(rec["time"]).replace("YR", "")), "value": rec["value"]}
                           for rec in wb.data.fetch(xs, "all", mrnev=self.mrnev, db=xdb, skipBlanks=True, skipAggs=True)
                           if not rec.get("aggregate") and rec["economy"] not in WB_AGGREGATE_CODES]
                if not xs_rows:
                    failures.append(f"db {xdb} {xs} (all economies): no rows")
            except Exception as e:  # noqa: BLE001 - recorded; the universe-only pull below keeps the raw scores
                _stop_if_unreachable(e, WB_HOST)                   # EQ-A-0037: proxy/DNS refusal ends the feed here
                failures.append(f"db {xdb} {xs} (all economies): {type(e).__name__}: {str(e)[:120]}; no WGI percentile ranks")
            if not xs_rows:
                by_db.setdefault(xdb, []).extend(xs)               # scores for the universe only: kept raw, never ranked

        for db, series in by_db.items():
            try:
                rows += pull(series, db)
            except Exception as e:  # noqa: BLE001 - retry one series at a time so one bad code cannot sink the rest
                _stop_if_unreachable(e, WB_HOST)                   # no per-series retries when the host is refused
                failures.append(f"db {db}: {type(e).__name__}: {str(e)[:120]}")
                if len(series) > 1:
                    for s in series:
                        try:
                            rows += pull([s], db)
                        except Exception as e1:  # noqa: BLE001
                            _stop_if_unreachable(e1, WB_HOST)
                            failures.append(f"db {db} {s}: {type(e1).__name__}: {str(e1)[:120]}")
        got = {r["series"] for r in rows}
        for s, dbs in self.alt_db.items():
            if s not in self.series or s in got:
                continue
            for db in dbs:
                try:
                    extra = pull([s], db)
                except Exception as e:  # noqa: BLE001
                    _stop_if_unreachable(e, WB_HOST)
                    failures.append(f"db {db} {s} (alternate): {type(e).__name__}: {str(e)[:120]}")
                    continue
                if extra:
                    rows += extra; break
        missing = sorted(set(self.series) - {r["series"] for r in rows + xs_rows})
        if missing:
            failures.append(f"no rows for {missing}")
        if not rows and not xs_rows:
            raise FeedError("World Bank API unreachable: " + "; ".join(failures[:3]) + (f" (+{len(failures) - 3} more)" if len(failures) > 3 else ""))
        out = _long(rows, "wbgapi World Bank API v2")
        if xs_rows:
            out = pd.concat([out, _long(xs_rows, WGI_XS_SOURCE)], ignore_index=True)
        out.attrs["failures"] = failures
        return out


# World Bank history for fitted layer 1 (HO-20261023-B-A-006, EQ-A-0028): the three hazard-panel series as annual
# history from 1996 (WGI starts 1996) for every universe economy -> data/live/raw_worldbank_history.csv. wbgapi serves
# only the current database, so these are current-database values, not point-in-time vintages.
WB_HISTORY_SERIES = ("DT.DOD.DSTC.IR.ZS", "FI.RES.TOTL.MO", "PV.EST")
WB_HISTORY_START = 1996


def _wb_history_frame(code: str, start: int, end: int, isos: list[str], db: int) -> pd.DataFrame:
    """One series from an explicit wbgapi database, in the long layout of panel_history.worldbank_series_fetcher."""
    import wbgapi as wb  # optional dependency, Mac only
    df = wb.data.DataFrame(code, isos, db=db, time=range(start, end + 1), labels=False, skipAggs=True, numericTimeKeys=True)
    long = df.reset_index().melt(id_vars=df.index.name or "economy", var_name="period", value_name="value")
    long.columns = ["iso", "period", "value"]
    long = long.dropna(subset=["value"])
    return pd.DataFrame({"iso": long["iso"].astype(str), "series": code, "period": long["period"].astype(int), "value": long["value"].astype(float)})


@dataclass
class WorldBankHistoryFeed:
    """Annual history of WB_HISTORY_SERIES for the given ISO3s, one wbgapi call per series through
    `panel_history.worldbank_series_fetcher` (the panel's fetcher, reused so the two cannot drift; it retries PV.EST
    on the WGI database). A series that fails or comes back empty is retried on its WB_ALT_DB databases
    (DT.DOD.DSTC.IR.ZS: IDS). Returns iso, series, period (int year), value, source; attrs["failures"] lists what is
    missing. Raises FeedError when no series returned a row."""
    series: tuple = WB_HISTORY_SERIES
    start: int = WB_HISTORY_START
    end: int | None = None
    fetcher: Callable | None = None                 # (code, start, end, isos) -> long frame; tests inject a stand-in
    alt_fetcher: Callable | None = None             # (code, start, end, isos, db) -> long frame
    alt_db: dict = field(default_factory=lambda: dict(WB_ALT_DB))

    def fetch(self, isos: Iterable[str]) -> pd.DataFrame:
        isos = [i for i in dict.fromkeys(isos) if isinstance(i, str) and i]
        end = int(self.end or dt.date.today().year)
        if self.fetcher is None:
            from .panel_history import worldbank_series_fetcher as fetch_one
        else:
            fetch_one = self.fetcher
        alt = self.alt_fetcher or _wb_history_frame
        frames, failures = [], []
        for code in self.series:
            df = None
            try:
                df = fetch_one(code, self.start, end, isos)
            except Exception as e:  # noqa: BLE001 - recorded; the alternate database may still serve it
                _stop_if_unreachable(e, WB_HOST)               # EQ-A-0037: no further series once the host is refused
                failures.append(f"{code}: {type(e).__name__}: {str(e)[:120]}")
            if (df is None or df.empty) and code in self.alt_db:
                for db in self.alt_db[code]:
                    try:
                        df = alt(code, self.start, end, isos, db)
                    except Exception as e:  # noqa: BLE001
                        _stop_if_unreachable(e, WB_HOST)
                        failures.append(f"{code} db {db} (alternate): {type(e).__name__}: {str(e)[:120]}")
                        continue
                    if df is not None and not df.empty:
                        break
            if df is None or df.empty:
                failures.append(f"no rows for {code}")
                continue
            frames.append(df[df["iso"].astype(str).isin(isos)][["iso", "series", "period", "value"]])
        if not frames:
            raise FeedError("World Bank history unreachable: " + "; ".join(failures[:3]))
        rows = pd.concat(frames, ignore_index=True)
        rows = rows[(rows["period"].astype(int) >= self.start) & (rows["period"].astype(int) <= end)]
        out = _long(rows.to_dict("records"), "wbgapi World Bank API v2 (current database, not point in time)")
        out["period"] = out["period"].astype(int)
        missing = sorted(set(isos) - set(out["iso"]))
        if missing:
            failures.append(f"no history for {len(missing)} economies: {', '.join(missing)}")
        out = out.sort_values(["series", "iso", "period"]).reset_index(drop=True)
        out.attrs["failures"] = failures
        return out


# ----------------------------------------------------------------------------------------------
# BIS statistics (SDMX REST, CSV)
# ----------------------------------------------------------------------------------------------
BIS_FLOWS = {
    "EER_REAL_BROAD": ("WS_EER", "M.R.B.{iso2}"),       # monthly real broad effective exchange rate
    "CREDIT_GAP": ("WS_CREDIT_GAP", "Q.{iso2}.P.A.C"),  # credit-to-GDP gap, private non-financial sector
    "POLICY_RATE": ("WS_CBPOL", "D.{iso2}"),            # daily policy rate
}


BIS_AREA_COLUMNS = ("REF_AREA", "BORROWERS_CTY", "EER_REF_AREA", "REF_AREA_CODE")   # country dimension, by flow

# BIS consolidated banking statistics (HO-20261023-B-A-005, EQ-A-0028). Dataflow WS_CBS_PUB, key dimensions in order:
# FREQ.L_MEASURE.L_REP_CTY.CBS_BANK_TYPE.CBS_BASIS.L_POSITION.L_INSTR.REM_MATURITY.CURR_TYPE_BOOK.L_CP_SECTOR.L_CP_COUNTRY
# Q quarterly, S amounts outstanding, reporter left open (all reporters; aggregates such as 5A dropped after the call),
# C claims, A all instruments, A all maturities, TO1 all currencies, A all counterparty sectors, debtor ISO2 ('+' batch).
# UNVERIFIED (written from the BIS CBS documentation and codelists as remembered, not checked against a live response
# from this cloud, which cannot reach stats.bis.org): CBS_BASIS "U" = ultimate risk basis (F = immediate counterparty,
# R = guarantor basis) and CBS_BANK_TYPE "4R" = domestic banks, the ultimate-risk reporting population. The first Mac
# pull must confirm both; fetch_cbs keeps only rows whose CBS_BASIS column equals the requested code and records it in
# `basis`, so a wrong code fails loudly (no rows) instead of silently mixing bases.
CBS_FLOW = "WS_CBS_PUB"
CBS_KEY = "Q.S..{bank_type}.{basis}.C.A.A.TO1.A.{cp}"
CBS_BASIS_ULTIMATE_RISK = "U"
CBS_BANK_TYPE_ULTIMATE_RISK = "4R"
CBS_QUARTERS = 8                       # latest quarters kept in raw_bis_cbs.csv
CBS_COLUMNS = ["creditor_iso2", "debtor_iso3", "period", "claims_usd_mn", "basis", "source"]

# BIS daily bilateral exchange rates (EQ-A-0040, Sam 2026-10-23: replace Yahoo with free official sources). Dataflow
# WS_XRU, key dimensions FREQ.REF_AREA.CURRENCY.COLLECTION. UNVERIFIED (written from the BIS documentation as
# remembered, not checked against a live response from this cloud, which cannot reach stats.bis.org): FREQ "D" daily,
# COLLECTION "A" for the daily series, values in units of national currency per US dollar, and REF_AREA "XM" for the
# euro area's EUR series. fetch_xru keeps only rows whose REF_AREA/CURRENCY (and COLLECTION when delivered) equal the
# requested codes, so a wrong code fails loudly (no rows, then the ECB fallback or an unserved cell with the reason).
# The first Mac pull must confirm all four (docs/runbooks/A-official-fx.md).
XRU_FLOW = "WS_XRU"
XRU_KEY = "D.{area}.{ccy}.A"
XRU_COLLECTION = "A"
XRU_SERIES_SUFFIX = "_PER_USD"
XRU_DAYS = 400                     # calendar days pulled: fx3m needs > 70 observations and one at least 91 days back
XRU_SOURCE = f"BIS SDMX REST {XRU_FLOW} (stats.bis.org)"
EURO_AREA_BIS = "XM"               # UNVERIFIED: BIS reference area of the euro area
BIS_MAX_BYTES = 50 * 1024 * 1024    # SEC-A-006 L1: per-response cap (a 25-country WS_XRU batch is ~1 MB)


@dataclass
class BisFeed:
    """BIS SDMX REST. EQ-A-0027: countries are batched into one key per flow with the SDMX OR operator ('+', e.g.
    M.R.B.BR+CL+CO), `batch` countries per call (3 flows x 88 countries = 9 calls, not 264), with retries and
    exponential backoff on timeouts, connection errors, 429 and 5xx. A batch whose response cannot be attributed to
    countries, or that fails for good, is retried one country at a time, so one unknown code costs only itself."""
    base: str = "https://stats.bis.org/api/v1/data"
    timeout: float = 30.0
    batch: int = 25
    retries: int = 3
    backoff: float = 2.0
    sleep: Callable[[float], None] | None = None
    max_bytes: int = BIS_MAX_BYTES

    def _get(self, flow: str, key: str, params: dict | None = None) -> pd.DataFrame:
        query = urllib.parse.urlencode({"format": "csv", **(params or {})})
        url = f"{self.base}/{flow}/{key}/all?{query}"
        if not url.startswith("https://"):
            raise ValueError(f"BIS base must be https: {self.base!r}")
        # host is the BIS SDMX API (EQ-A-0012, SEC-C-002); redirects refused and body capped (SEC-A-006 L1)
        body = https_get(url, {"User-Agent": "econquest/0.2", "Accept": "text/csv"}, timeout=self.timeout,
                         max_bytes=self.max_bytes)
        # 'NA' (Namibia) must stay a country code in the area column
        return read_csv_keep_na_code(io.StringIO(body.decode("utf-8")))

    def _get_retry(self, flow: str, key: str, params: dict | None = None) -> pd.DataFrame:
        """_get with retries on transient errors. EQ-A-0037: a proxy refusal or DNS failure raises FeedUnreachable,
        which the callers let through, so the feed stops instead of falling back to one call per country."""
        try:
            if params:
                return _with_retries(lambda: self._get(flow, key, params), retries=self.retries, backoff=self.backoff, sleep=self.sleep)
            return _with_retries(lambda: self._get(flow, key), retries=self.retries, backoff=self.backoff, sleep=self.sleep)
        except Exception as e:  # noqa: BLE001 - classified, then re-raised as it was
            _stop_if_unreachable(e, urllib.parse.urlsplit(self.base).hostname or self.base)
            raise

    @staticmethod
    def _area_column(df: pd.DataFrame, codes: set[str]) -> str | None:
        """The column holding the country code: a known dimension name, else the column whose values are all
        requested codes (most matches wins)."""
        for c in BIS_AREA_COLUMNS:
            if c in df.columns and df[c].dropna().astype(str).isin(codes).all():
                return c
        best, n = None, 0
        for c in df.columns:
            if c in ("TIME_PERIOD", "OBS_VALUE"):
                continue
            v = df[c].dropna().astype(str)
            if len(v) and v.isin(codes).all() and v.nunique() > n:
                best, n = c, v.nunique()
        return best

    def fetch(self, iso2s: dict[str, str]) -> pd.DataFrame:
        """iso2s maps ISO3 -> ISO2 (BIS uses ISO 3166 alpha-2)."""
        rows = []; failures = []
        pairs = [(i3, i2) for i3, i2 in iso2s.items() if isinstance(i2, str) and i2]
        size = max(1, int(self.batch))
        for name, (flow, key) in BIS_FLOWS.items():
            for start in range(0, len(pairs), size):
                chunk = pairs[start:start + size]
                to_iso3 = {i2: i3 for i3, i2 in chunk}
                df, err = None, None
                try:
                    df = self._get_retry(flow, key.format(iso2="+".join(to_iso3)))
                except FeedUnreachable:
                    raise
                except Exception as e:  # noqa: BLE001
                    err = e
                col = None if df is None or df.empty else self._area_column(df, set(to_iso3))
                if df is not None and not df.empty and "OBS_VALUE" in df.columns and (col or len(chunk) == 1):
                    areas = df[col].astype(str) if col else pd.Series([chunk[0][1]] * len(df), index=df.index)
                    for a, r in zip(areas, df.itertuples()):
                        if a in to_iso3:
                            rows.append({"iso": to_iso3[a], "series": name, "period": str(r.TIME_PERIOD), "value": r.OBS_VALUE})
                    continue
                if len(chunk) == 1:
                    if err is not None:
                        failures.append(f"{flow} {chunk[0][1]}: {type(err).__name__}: {str(err)[:100]}")
                    continue
                if err is not None:
                    failures.append(f"{flow} batch of {len(chunk)}: {type(err).__name__}: {str(err)[:100]}; retrying one by one")
                for iso3, iso2 in chunk:            # fall back: one country per call
                    try:
                        one = self._get_retry(flow, key.format(iso2=iso2))
                    except FeedUnreachable:
                        raise
                    except Exception as e:  # noqa: BLE001
                        failures.append(f"{flow} {iso2}: {type(e).__name__}: {str(e)[:100]}")
                        continue
                    if one.empty or "OBS_VALUE" not in one.columns:
                        continue
                    for r in one.itertuples():
                        rows.append({"iso": iso3, "series": name, "period": str(r.TIME_PERIOD), "value": r.OBS_VALUE})
        if not rows:
            raise FeedError("BIS statistics API unreachable: " + "; ".join(failures[:3]))
        out = _long(rows, "BIS SDMX REST (stats.bis.org)")
        out.attrs["failures"] = failures
        return out

    def fetch_cbs(self, iso2s: dict[str, str], quarters: int = CBS_QUARTERS, basis: str = CBS_BASIS_ULTIMATE_RISK,
                  bank_type: str = CBS_BANK_TYPE_ULTIMATE_RISK, today: dt.date | None = None) -> pd.DataFrame:
        """BIS consolidated banking statistics (HO-20261023-B-A-005): foreign claims (amounts outstanding, all sectors,
        instruments, maturities and currencies) of every individual reporting banking system on each debtor in `iso2s`
        (ISO3 -> ISO2), on `basis` (ultimate risk by default, see CBS_KEY), for the last `quarters` quarters.
        Debtors are batched with the SDMX OR operator ('+') and the reporter dimension is left open; BIS aggregate
        reporters (codes that are not two letters, e.g. 5A, 5J) are dropped. Same retries and per-country fallback as
        `fetch`. Returns CBS_COLUMNS, one row per (creditor, debtor, period), USD mn; attrs["not_reported"] lists the
        debtors (ISO3) with no claim in the latest period, attrs["latest_period"] that period and attrs["failures"]
        what went wrong. Raises FeedError when nothing came back. Never switches basis on its own: an empty
        ultimate-risk answer is a failure, not a reason to mix in immediate-counterparty numbers."""
        today = today or dt.date.today()
        start = f"{today.year - (int(quarters) + 3) // 4 - 1}-Q1"
        pairs = [(i3, i2) for i3, i2 in iso2s.items() if isinstance(i2, str) and i2]
        size = max(1, int(self.batch))
        frames, failures = [], []

        def keep(df: pd.DataFrame | None, to_iso3: dict) -> pd.DataFrame | None:
            if df is None or df.empty or not {"L_REP_CTY", "L_CP_COUNTRY", "TIME_PERIOD", "OBS_VALUE"} <= set(df.columns):
                return None
            for col, want in (("L_MEASURE", "S"), ("L_POSITION", "C"), ("CBS_BASIS", basis)):
                if col in df.columns:
                    df = df[df[col].astype(str) == want]
            df = df[df["L_REP_CTY"].astype(str).str.fullmatch(r"[A-Z]{2}") & df["L_CP_COUNTRY"].astype(str).isin(to_iso3)]
            return pd.DataFrame({"creditor_iso2": df["L_REP_CTY"].astype(str), "debtor_iso3": df["L_CP_COUNTRY"].astype(str).map(to_iso3),
                                 "period": df["TIME_PERIOD"].astype(str), "claims_usd_mn": pd.to_numeric(df["OBS_VALUE"], errors="coerce")})

        def key(cp: str) -> str:
            return CBS_KEY.format(bank_type=bank_type, basis=basis, cp=cp)

        for i in range(0, len(pairs), size):
            chunk = pairs[i:i + size]
            to_iso3 = {i2: i3 for i3, i2 in chunk}
            df, err = None, None
            try:
                df = self._get_retry(CBS_FLOW, key("+".join(to_iso3)), {"startPeriod": start})
            except FeedUnreachable:
                raise
            except Exception as e:  # noqa: BLE001
                err = e
            got = keep(df, to_iso3)
            if got is not None:
                frames.append(got); continue
            if len(chunk) == 1:
                if err is not None:
                    failures.append(f"{CBS_FLOW} {chunk[0][1]}: {type(err).__name__}: {str(err)[:100]}")
                continue
            failures.append(f"{CBS_FLOW} batch of {len(chunk)}: " + (f"{type(err).__name__}: {str(err)[:100]}" if err is not None else "unusable response")
                            + "; retrying one by one")
            for iso3, iso2 in chunk:            # fall back: one debtor per call
                try:
                    one = self._get_retry(CBS_FLOW, key(iso2), {"startPeriod": start})
                except FeedUnreachable:
                    raise
                except Exception as e:  # noqa: BLE001
                    failures.append(f"{CBS_FLOW} {iso2}: {type(e).__name__}: {str(e)[:100]}")
                    continue
                got = keep(one, {iso2: iso3})
                if got is not None:
                    frames.append(got)
        out = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(columns=CBS_COLUMNS[:4])
        out = out.dropna(subset=["claims_usd_mn"])
        if out.empty:
            raise FeedError(f"BIS {CBS_FLOW} returned no claims on basis {basis}: " + "; ".join(failures[:3]))
        periods = sorted(out["period"].unique())[-max(1, int(quarters)):]
        out = (out[out["period"].isin(periods)].groupby(["creditor_iso2", "debtor_iso3", "period"], as_index=False)["claims_usd_mn"].sum()
               .sort_values(["period", "debtor_iso3", "creditor_iso2"]).reset_index(drop=True))
        out["basis"] = basis
        out["source"] = f"BIS SDMX REST {CBS_FLOW} {key('<debtor>')} (stats.bis.org)"
        latest = periods[-1]
        have = set(out.loc[out["period"] == latest, "debtor_iso3"])
        not_reported = sorted(i3 for i3 in iso2s if i3 not in have)
        if not_reported:
            failures.append(f"{CBS_FLOW}: no claims on {len(not_reported)} debtors in {latest}: {', '.join(not_reported)}")
        out = out[CBS_COLUMNS]
        out.attrs.update(not_reported=not_reported, latest_period=latest, failures=failures)
        return out

    def fetch_xru(self, areas: dict[str, str], days: int | None = None, today: dt.date | None = None) -> pd.DataFrame:
        """BIS daily bilateral exchange rates (EQ-A-0040), dataflow WS_XRU (XRU_KEY, UNVERIFIED), one series per
        currency: `areas` maps a currency (ISO 4217) to the BIS reference area (ISO2) whose series serves it
        (official_fx_plan; EUR -> EURO_AREA_BIS). Values are units of the currency per US dollar, as BIS publishes
        them, from `days` (default XRU_DAYS) before `today`. Pairs are batched with the SDMX OR operator on both
        dimensions (D.BR+CL.BRL+CLP.A) and only the requested (area, currency) pairs are kept, so a cross-product
        series (e.g. a legacy currency of the same area) never enters. A batch whose answer cannot be attributed is
        retried one pair at a time. Same retries, FeedUnreachable fail-fast and fallback as `fetch`.
        Returns LONG_COLUMNS plus `sdmx_key`: iso = the BIS area as delivered, series '<CCY>_PER_USD', period
        YYYY-MM-DD. attrs["missing"] lists the requested currencies with no row, attrs["failures"] what went wrong.
        Raises FeedError when nothing came back."""
        today = today or dt.date.today()
        start = (today - dt.timedelta(days=int(days or XRU_DAYS))).isoformat()
        pairs = list(dict.fromkeys((c, a) for c, a in areas.items() if isinstance(c, str) and c and isinstance(a, str) and a))
        size = max(1, int(self.batch))
        rows: list[dict] = []
        failures: list[str] = []

        def keep(df: pd.DataFrame | None, chunk: list[tuple[str, str]]) -> list[dict] | None:
            if df is None or df.empty or not {"TIME_PERIOD", "OBS_VALUE"} <= set(df.columns):
                return None
            if {"REF_AREA", "CURRENCY"} <= set(df.columns):
                for col, want in (("FREQ", "D"), ("COLLECTION", XRU_COLLECTION)):
                    if col in df.columns:
                        df = df[df[col].astype(str) == want]
                found = list(zip(df["CURRENCY"].astype(str), df["REF_AREA"].astype(str)))
            elif len(chunk) == 1:
                found = [chunk[0]] * len(df)
            else:
                return None
            wanted = set(chunk)
            return [{"iso": a, "series": f"{c}{XRU_SERIES_SUFFIX}", "period": str(r.TIME_PERIOD), "value": r.OBS_VALUE,
                     "sdmx_key": f"{XRU_FLOW} {XRU_KEY.format(area=a, ccy=c)}"}
                    for (c, a), r in zip(found, df.itertuples()) if (c, a) in wanted]

        for i in range(0, len(pairs), size):
            chunk = pairs[i:i + size]
            key = XRU_KEY.format(area="+".join(dict.fromkeys(a for _, a in chunk)), ccy="+".join(dict.fromkeys(c for c, _ in chunk)))
            df, err = None, None
            try:
                df = self._get_retry(XRU_FLOW, key, {"startPeriod": start})
            except FeedUnreachable:
                raise
            except Exception as e:  # noqa: BLE001
                err = e
            got = keep(df, chunk)
            if got is not None:
                rows += got; continue
            if len(chunk) == 1:
                if err is not None:
                    failures.append(f"{XRU_FLOW} {key}: {type(err).__name__}: {str(err)[:100]}")
                continue
            failures.append(f"{XRU_FLOW} batch of {len(chunk)}: " + (f"{type(err).__name__}: {str(err)[:100]}" if err is not None
                                                                     else "unusable response") + "; retrying one by one")
            for ccy, area in chunk:             # fall back: one pair per call
                one_key = XRU_KEY.format(area=area, ccy=ccy)
                try:
                    one = self._get_retry(XRU_FLOW, one_key, {"startPeriod": start})
                except FeedUnreachable:
                    raise
                except Exception as e:  # noqa: BLE001
                    failures.append(f"{XRU_FLOW} {one_key}: {type(e).__name__}: {str(e)[:100]}")
                    continue
                rows += keep(one, [(ccy, area)]) or []
        out = _long_keyed(rows, XRU_SOURCE)
        if out.empty:
            raise FeedError(f"BIS {XRU_FLOW} returned no exchange rate: " + "; ".join(failures[:3]))
        have = {s[:-len(XRU_SERIES_SUFFIX)] for s in out["series"].unique()}
        missing = sorted(c for c, _ in pairs if c not in have)
        if missing:
            failures.append(f"{XRU_FLOW}: no series for {', '.join(missing)} (ECB EXR is the fallback where it has the currency)")
        out.attrs.update(missing=missing, failures=failures)
        return out


# ----------------------------------------------------------------------------------------------
# ECB euro foreign exchange reference rates (EQ-A-0040): cross-check of BIS WS_XRU and the fallback for
# currencies BIS has no series for.
# ----------------------------------------------------------------------------------------------
# Dataflow EXR, key FREQ.CURRENCY.CURRENCY_DENOM.EXR_TYPE.EXR_SUFFIX. UNVERIFIED (written from the ECB Data Portal
# documentation as remembered, not checked against a live response from this cloud, which cannot reach
# data-api.ecb.europa.eu): EXR_TYPE "SP00" = foreign exchange reference rate, EXR_SUFFIX "A" = average/standardised
# measure, and the values are units of the quoted currency per 1 euro. The first Mac pull must confirm all three
# (docs/runbooks/A-official-fx.md). parse_ecb_exr refuses any series key that is not D.<CCY>.EUR.SP00.A, so a wrong
# dimension fails loudly instead of being read as something else.
EXR_FLOW = "EXR"
EXR_KEY = "D.{ccy}.EUR.SP00.A"
EXR_SERIES_SUFFIX = "_PER_EUR"
EXR_SOURCE = "ECB Data Portal SDMX REST EXR (data-api.ecb.europa.eu)"
EXR_BASE = "https://data-api.ecb.europa.eu/service/data"
EXR_DAYS = XRU_DAYS
EXR_BATCH = 40                     # currencies per request (SDMX OR operator on the CURRENCY dimension)
EXR_MAX_BYTES = 20 * 1024 * 1024    # SEC-A-006 L1: per-response cap
FX_PER_USD_SUFFIX = XRU_SERIES_SUFFIX


@dataclass
class EcbExrFeed:
    """ECB euro foreign exchange reference rates over SDMX-CSV, same retry and fail-fast behaviour as BisFeed
    (EQ-A-0037: a proxy refusal or DNS failure raises FeedUnreachable and ends the feed)."""
    base: str = EXR_BASE
    timeout: float = 30.0
    batch: int = EXR_BATCH
    retries: int = 3
    backoff: float = 2.0
    sleep: Callable[[float], None] | None = None
    max_bytes: int = EXR_MAX_BYTES

    def _get(self, key: str, params: dict | None = None) -> str:
        query = urllib.parse.urlencode({"format": "csvdata", **(params or {})})
        url = f"{self.base}/{EXR_FLOW}/{key}?{query}"
        if not url.startswith("https://"):
            raise ValueError(f"ECB base must be https: {self.base!r}")
        # host is the ECB Data Portal SDMX API (EQ-A-0040); redirects refused and body capped (SEC-A-006 L1)
        return https_get(url, {"User-Agent": "econquest/0.2", "Accept": "text/csv"}, timeout=self.timeout,
                         max_bytes=self.max_bytes).decode("utf-8")

    def _get_retry(self, key: str, params: dict | None = None) -> str:
        try:
            return _with_retries(lambda: self._get(key, params), retries=self.retries, backoff=self.backoff, sleep=self.sleep)
        except Exception as e:  # noqa: BLE001 - classified, then re-raised as it was
            _stop_if_unreachable(e, urllib.parse.urlsplit(self.base).hostname or self.base)
            raise

    def fetch(self, currencies: Iterable[str], days: int | None = None, today: dt.date | None = None) -> pd.DataFrame:
        """Daily reference rates for `currencies` (ISO 4217, EUR and USD handled by the caller through the EUR/USD
        cross) from `days` (default EXR_DAYS) before `today`. USD is always requested: every per-USD rate is derived
        from the same date's EUR/USD rate (`ecb_per_usd`). Returns LONG_COLUMNS plus `sdmx_key`, series
        '<CCY>_PER_EUR', iso blank (the rates are currency-level, not country-level). attrs["missing"] lists the
        currencies with no row. Raises FeedError when nothing came back."""
        today = today or dt.date.today()
        start = (today - dt.timedelta(days=int(days or EXR_DAYS))).isoformat()
        want = [c for c in dict.fromkeys([*currencies, EXR_USD]) if isinstance(c, str) and len(c) == 3 and c.isalpha()
                and c.upper() != "EUR"]
        want = [c.upper() for c in want]
        if not want:
            raise FeedError("ECB EXR: no currency to fetch")
        size = max(1, int(self.batch))
        rows, failures = [], []
        for i in range(0, len(want), size):
            chunk = want[i:i + size]
            key = EXR_KEY.format(ccy="+".join(chunk))
            try:
                body = self._get_retry(key, {"startPeriod": start})
            except FeedUnreachable:
                raise
            except Exception as e:  # noqa: BLE001
                failures.append(f"{EXR_FLOW} {key}: {type(e).__name__}: {str(e)[:100]}")
                continue
            try:
                rows += parse_ecb_exr(body, chunk)
            except FeedError as e:
                failures.append(f"{EXR_FLOW} {key}: {_one_line(e, 150)}")
        out = _long_keyed(rows, EXR_SOURCE)
        if out.empty:
            raise FeedError(f"ECB {EXR_FLOW} returned no reference rate: " + "; ".join(failures[:3]))
        have = {s[:-len(EXR_SERIES_SUFFIX)] for s in out["series"].unique()}
        missing = sorted(c for c in want if c not in have)
        if missing:
            failures.append(f"{EXR_FLOW}: no series for {', '.join(missing)}")
        out.attrs.update(missing=missing, failures=failures)
        return out


EXR_USD = "USD"


def parse_ecb_exr(body: str, currencies: Iterable[str] | None = None) -> list[dict]:
    """ECB SDMX-CSV (format=csvdata) of the EXR dataflow -> raw rows for `_long_keyed`. The series key is read from
    the KEY column, else rebuilt from the dimension columns, and must be D.<CCY>.EUR.SP00.A: any other frequency,
    denominator, type or suffix raises FeedError rather than being read as a reference rate. Rows whose OBS_VALUE is
    empty or non-numeric (ECB closing days) are skipped, never filled."""
    try:
        raw = read_csv_keep_na_code(io.StringIO(body))
    except Exception as e:  # noqa: BLE001
        raise FeedError(f"ECB {EXR_FLOW}: response is not SDMX-CSV: {type(e).__name__}") from e
    if raw.empty or not {"TIME_PERIOD", "OBS_VALUE"} <= set(raw.columns):
        raise FeedError(f"ECB {EXR_FLOW}: SDMX-CSV without TIME_PERIOD / OBS_VALUE")
    if "KEY" in raw.columns:
        keys = raw["KEY"].astype(str)
    else:
        dims = ("FREQ", "CURRENCY", "CURRENCY_DENOM", "EXR_TYPE", "EXR_SUFFIX")
        missing = [d for d in dims if d not in raw.columns]
        if missing:
            raise FeedError(f"ECB {EXR_FLOW}: no KEY column and dimension columns missing: {missing}")
        keys = raw[list(dims)].astype(str).agg(".".join, axis=1)
        keys = EXR_FLOW + "." + keys
    wanted = {c.upper() for c in (currencies or [])}
    rows = []
    for k, period, value in zip(keys, raw["TIME_PERIOD"].astype(str), raw["OBS_VALUE"]):
        parts = [p for p in str(k).split(".") if p != ""]
        if parts and parts[0] == EXR_FLOW:
            parts = parts[1:]
        if len(parts) != 5 or parts[0] != "D" or parts[2] != "EUR" or parts[3] != "SP00" or parts[4] != "A":
            raise FeedError(f"ECB {EXR_FLOW}: unexpected series key {k!r} (expected {EXR_KEY})")
        ccy = parts[1].upper()
        if wanted and ccy not in wanted:
            continue
        v = pd.to_numeric(value, errors="coerce")
        if pd.isna(v):
            continue                                    # ECB closing day: no rate published, never filled
        rows.append({"iso": "", "series": f"{ccy}{EXR_SERIES_SUFFIX}", "period": str(period), "value": float(v),
                     "sdmx_key": f"{EXR_FLOW} {EXR_KEY.format(ccy=ccy)}"})
    return rows


def ecb_per_usd(raw_ecb: pd.DataFrame, currencies: Iterable[str] | None = None) -> pd.DataFrame:
    """ECB per-EUR reference rates -> units of each currency per 1 USD, through the EUR/USD rate of the same date
    (no rate is carried over from another date):
        CCY per USD = (CCY per EUR) / (USD per EUR)        EUR per USD = 1 / (USD per EUR)
    Returns LONG_COLUMNS plus `sdmx_key` with series '<CCY>_PER_USD'; a date without a USD reference rate yields no
    row. `currencies`, when given, limits the output."""
    if raw_ecb is None or not len(raw_ecb):
        return _long_keyed([], EXR_SOURCE)
    df = raw_ecb.copy()
    df["series"] = df["series"].astype(str)
    df["period"] = df["period"].astype(str)
    df["value"] = pd.to_numeric(df["value"], errors="coerce")
    usd = df[df["series"] == f"{EXR_USD}{EXR_SERIES_SUFFIX}"].dropna(subset=["value"])
    usd_per_eur = dict(zip(usd["period"], usd["value"]))
    want = {c.upper() for c in (currencies or [])}
    rows = []
    for r in df.dropna(subset=["value"]).itertuples(index=False):
        ccy = r.series[:-len(EXR_SERIES_SUFFIX)] if r.series.endswith(EXR_SERIES_SUFFIX) else ""
        if not ccy or ccy == EXR_USD:
            continue
        u = usd_per_eur.get(r.period)
        if u is None or not np.isfinite(u) or u <= 0:
            continue
        for out_ccy, value in ((ccy, float(r.value) / float(u)), ("EUR", 1.0 / float(u))):
            if want and out_ccy not in want:
                continue
            rows.append({"iso": "", "series": f"{out_ccy}{FX_PER_USD_SUFFIX}", "period": r.period, "value": value,
                         "sdmx_key": (f"{EXR_FLOW} {EXR_KEY.format(ccy=out_ccy)} / {EXR_KEY.format(ccy=EXR_USD)}"
                                      if out_ccy != "EUR" else f"{EXR_FLOW} 1 / {EXR_KEY.format(ccy=EXR_USD)}")})
    out = _long_keyed(rows, f"{EXR_SOURCE}, converted to per-USD through EUR/USD of the same date")
    return out.drop_duplicates(["series", "period"]).reset_index(drop=True)


# ----------------------------------------------------------------------------------------------
# Official FX plan: which official series serves each country's fx3m (EQ-A-0040)
# ----------------------------------------------------------------------------------------------
# Currencies with no official daily rate against the dollar: the country gets no fx3m (NaN) and this reason, never
# another country's rows. Carried over from the Yahoo era (EQ-A-0027) with the reasons restated for the new sources.
NO_FX_QUOTE = {
    "USD": "dollarised: the currency is the US dollar, so there is no FX rate against USD (fx3m stays empty)",
    "ZWL": ("Zimbabwe: ZWL was replaced by ZiG (ZWG) in April 2024 and neither BIS WS_XRU nor the ECB reference "
            "rates quote either (fx3m stays empty)"),
}
NO_OFFICIAL_SOURCE = "no official free source (Yahoo removed, Sam 2026-10-23)"
# Reference area of the BIS WS_XRU series for a currency several countries share. UNVERIFIED: written from the BIS
# codelists as remembered; the first Mac pull confirms them, and a currency whose series comes back empty falls to
# the ECB and then to an unserved fx3m with a reason, never to a guessed rate.
SHARED_FX_AREA = {"EUR": EURO_AREA_BIS, "XOF": "SN", "XAF": "CM"}
FX_SHARED_CURRENCIES = tuple(SHARED_FX_AREA)


@dataclass
class FxPlan:
    """Which official daily FX series serves each country (EQ-A-0040)."""
    currency: dict          # iso3 -> ISO 4217 code of the country's currency
    bis_area: dict          # currency -> BIS WS_XRU reference area asked for it
    ecb: tuple              # currencies asked of the ECB (cross-check, and fallback where BIS has none)
    why: dict               # iso3 -> reason this country gets no fx3m


def official_fx_plan(countries: pd.DataFrame) -> FxPlan:
    """Plan the official FX pull from countries.csv. Keyed by country, so countries sharing a currency (EUR, XOF,
    XAF) all get the same shared series (SHARED_FX_AREA). A country whose currency is USD or in NO_FX_QUOTE, or that
    has no currency, gets no series and a reason. The BIS reference area of a non-shared currency is the country's
    `bis_iso2` (else `iso2`); without one, only the ECB can serve the currency."""
    currency, areas, why = {}, {}, {}
    has_bis = "bis_iso2" in countries.columns
    for r in countries.to_dict("records"):
        iso = r.get("iso")
        if not isinstance(iso, str) or not iso:
            continue
        ccy = r.get("currency")
        ccy = ccy.strip().upper() if isinstance(ccy, str) else ""
        if ccy in NO_FX_QUOTE:
            why[iso] = NO_FX_QUOTE[ccy]
            continue
        if not ccy:
            why[iso] = "no currency in countries.csv (fx3m stays empty)"
            continue
        currency[iso] = ccy
        if ccy in SHARED_FX_AREA:
            areas[ccy] = SHARED_FX_AREA[ccy]
            continue
        area = (r.get("bis_iso2") if has_bis else None) or r.get("iso2")
        area = area.strip().upper() if isinstance(area, str) and area.strip() else ""
        if area and ccy not in areas:
            areas[ccy] = area
    ecb = tuple(dict.fromkeys(currency.values()))
    return FxPlan(currency=currency, bis_area=areas, ecb=ecb, why=why)


def fx_usd_series(long: pd.DataFrame | None, ccy: str) -> pd.Series:
    """Daily '<CCY> per USD' closes of `ccy` from an official long table (BIS WS_XRU rows, or ECB rows already
    converted with `ecb_per_usd`), indexed by date string, oldest first. Empty when the table has no such series."""
    if long is None or not len(long):
        return pd.Series(dtype=float)
    s = long[long["series"].astype(str) == f"{ccy}{FX_PER_USD_SUFFIX}"]
    if s.empty:
        return pd.Series(dtype=float)
    s = s.sort_values("period")
    out = pd.Series(pd.to_numeric(s["value"], errors="coerce").to_numpy(), index=s["period"].astype(str).to_numpy(), dtype=float)
    return out[~out.index.duplicated(keep="last")].dropna()


def fx3m(series: pd.Series, as_of: pd.Timestamp | None = None) -> float:
    """fx3m: % depreciation of the local currency against USD over about 3 months (positive = weaker), from a daily
    '<CCY> per USD' series. The definition and sign convention are the Yahoo-era ones (EQ-A-0027), unchanged by
    EQ-A-0040: at least 71 observations, the last value against the last value on or before `as_of` (default: the
    last date of the series) minus 91 days. NaN when the series is too short or has no observation that far back."""
    if series is None or len(series) <= 70:
        return float("nan")
    s = pd.Series(series.to_numpy(dtype=float), index=pd.to_datetime(series.index)).sort_index()
    end = as_of or s.index.max()
    start = end - pd.Timedelta(days=91)
    before = s[s.index <= start]
    if not len(before):
        return float("nan")
    return float(s.iloc[-1] / before.iloc[-1] * 100 - 100)


def official_fx_transforms(raw: dict, iso: str, plan: FxPlan, as_of: pd.Timestamp | None = None,
                           ecb_converted: pd.DataFrame | None = None) -> tuple[dict, str, str]:
    """({'fx3m': value} or {}, source, series) for one country from the official raw tables
    (`raw['bis_xru']`, `raw['ecb_exr']`). BIS is used when it carries the currency, else the ECB rates converted
    through EUR/USD. Never mixes the two in one number. `ecb_converted` is `ecb_per_usd(raw['ecb_exr'])` when the
    caller has it already (fetch_all converts once for every country)."""
    ccy = plan.currency.get(iso)
    if not ccy:
        return {}, "", ""
    bis = raw.get("bis_xru")
    s = fx_usd_series(bis, ccy)
    if len(s):
        v = fx3m(s, as_of)
        key = f"{XRU_FLOW} {XRU_KEY.format(area=plan.bis_area.get(ccy, '?'), ccy=ccy)}"
        return ({"fx3m": v} if np.isfinite(v) else {}), XRU_SOURCE, key
    ecb = raw.get("ecb_exr")
    if ecb_converted is None:
        ecb_converted = ecb_per_usd(ecb, [ccy]) if ecb is not None else None
    s = fx_usd_series(ecb_converted, ccy)
    if len(s):
        v = fx3m(s, as_of)
        key = (f"{EXR_FLOW} {EXR_KEY.format(ccy=ccy)} / {EXR_KEY.format(ccy=EXR_USD)}" if ccy != "EUR"
               else f"{EXR_FLOW} 1 / {EXR_KEY.format(ccy=EXR_USD)}")
        return ({"fx3m": v} if np.isfinite(v) else {}), f"{EXR_SOURCE}, converted to per-USD through EUR/USD of the same date", key
    return {}, "", ""


FX_CROSS_TOL = 0.01          # |BIS - ECB| / BIS on the latest common date: above this the fx3m cell is held


def fx_cross_checks(raw: dict, plan: FxPlan, u, tol: float = FX_CROSS_TOL) -> pd.DataFrame:
    """BIS WS_XRU against the ECB reference rates (EQ-A-0040) for every currency both carry, on the latest date both
    quote. Returns crosscheck.CHECK_COLUMNS rows (check 'fx_cross_source', one per country using the currency);
    status 'hold' when the two sources differ by more than `tol` of the BIS rate. No row when only one source has
    the currency: that is reported as the source actually used, not as a disagreement."""
    from .crosscheck import CHECK_COLUMNS
    bis, ecb = raw.get("bis_xru"), raw.get("ecb_exr")
    rows: list[dict] = []
    if bis is None or ecb is None:
        return pd.DataFrame(rows, columns=CHECK_COLUMNS)
    conv = ecb_per_usd(ecb, sorted(set(plan.currency.values())))
    by_country: dict[str, list[str]] = {}
    for name, iso in zip(u.names, u.countries["iso"].astype(str)):
        by_country.setdefault(plan.currency.get(iso, ""), []).append(name)
    for ccy in sorted({c for c in plan.currency.values()}):
        a, b = fx_usd_series(bis, ccy), fx_usd_series(conv, ccy)
        common = sorted(set(a.index) & set(b.index))
        if not common:
            continue
        d = common[-1]
        x, y = float(a[d]), float(b[d])
        diff = abs(x - y) / max(abs(x), 1e-12)
        bad = diff > tol
        reason = (f"{ccy}/USD {d}: BIS {XRU_FLOW} {x:.6g} vs ECB {EXR_FLOW} via EUR/USD {y:.6g} "
                  f"({diff:.2%} apart; tolerance {tol:.0%})" + ("" if bad else " within tolerance"))
        basis = f"BIS {XRU_FLOW} vs ECB {EXR_FLOW} ({EXR_KEY.format(ccy=ccy)} / {EXR_KEY.format(ccy=EXR_USD)}), {d}"
        for country in by_country.get(ccy, []):
            rows.append({"table": "Country Profile", "key": "fx3m", "country": country, "check": "fx_cross_source",
                         "status": "hold" if bad else "ok", "reason": reason, "live": np.nan, "basis": basis})
    return pd.DataFrame(rows, columns=CHECK_COLUMNS)


# ----------------------------------------------------------------------------------------------
# Yahoo Finance (FX and equity ETFs) - NOT a desk feed since EQ-A-0040
# ----------------------------------------------------------------------------------------------
# Sam decided on 2026-10-23 ("Replace with free official") that Yahoo Finance must not feed desk numbers: its terms
# allow personal, non-commercial use only. `fetch_all` no longer runs this feed and refuses `only=["yahoo"]`
# (YAHOO_REFUSED); the Country Profile fx3m comes from BIS WS_XRU / ECB EXR instead. YahooFeed, fx_tickers and
# yahoo_transforms stay here for research that is not published and not part of a run: nothing in the pipeline calls
# them. Rows they return carry no licence and must never be written into data/live or a market snapshot.
YAHOO_REFUSED = ("Yahoo Finance is not a desk feed (Sam 2026-10-23: replace with free official sources; Yahoo's "
                 "terms are personal, non-commercial). Use the official FX feeds bis_xru / ecb_exr.")


def fx_tickers(countries: pd.DataFrame) -> tuple[dict[str, str], dict[str, str]]:
    """Yahoo FX ticker per country (EQ-A-0027): ({iso3: 'CCY=X'}, {iso3: reason}) for countries.csv rows. Keyed by
    country, so countries that share EUR, XOF or XAF each get the shared ticker. A `yahoo_fx` column (as in the
    universe proposal) wins when present; a blank there, a USD currency (dollarised), a currency in NO_FX_QUOTE or a
    missing currency gives no ticker and a reason."""
    tick, why = {}, {}
    has_col = "yahoo_fx" in countries.columns
    for r in countries.to_dict("records"):
        iso = r.get("iso")
        if not isinstance(iso, str) or not iso:
            continue
        ccy = r.get("currency")
        ccy = ccy.strip().upper() if isinstance(ccy, str) else ""
        yfx = r.get("yahoo_fx") if has_col else None
        if has_col and isinstance(yfx, str) and yfx.strip():
            tick[iso] = yfx.strip()
        elif ccy in NO_FX_QUOTE:
            why[iso] = NO_FX_QUOTE[ccy]
        elif not ccy:
            why[iso] = "no currency in countries.csv (fx3m stays empty)"
        elif has_col:
            why[iso] = f"no Yahoo FX ticker in the universe file for {ccy} (hard peg or not quoted; fx3m stays empty)"
        else:
            tick[iso] = f"{ccy}=X"
    return tick, why


@dataclass
class YahooFeed:
    period: str = "1y"

    def fetch(self, fx: dict[str, str], etfs: dict[str, str]) -> pd.DataFrame:
        """fx: ISO3 -> Yahoo FX ticker ('CCY=X', units of CCY per USD; a bare currency code is turned into one, USD
        skipped); etfs: ISO3 -> ETF ticker. Each distinct ticker is downloaded once and its closes are written for
        every country that uses it, so EUR, XOF and XAF countries all get FX rows (EQ-A-0027). Returns daily closes
        as long rows (period = date)."""
        import yfinance as yf
        want: list[tuple[str, str, str]] = []           # (iso, kind, ticker)
        for iso, t in fx.items():
            if isinstance(t, str) and t and t.upper() != "USD":
                want.append((iso, "FX_USD", t if t.endswith("=X") else f"{t}=X"))
        want += [(iso, "ETF", t) for iso, t in etfs.items() if isinstance(t, str) and t]
        distinct = list(dict.fromkeys(t for _, _, t in want))
        if not distinct:
            raise FeedError("Yahoo Finance: no tickers to fetch")
        noise: list[str] = []
        try:
            with _captured_output("yfinance", noise):      # EQ-A-0037: its per-ticker error lines go to failures
                px = yf.download(distinct, period=self.period, interval="1d", auto_adjust=False, progress=False, group_by="ticker", threads=True)
        except Exception as e:  # noqa: BLE001
            _stop_if_unreachable(e, YAHOO_HOSTS[0])
            raise FeedError(f"Yahoo Finance unreachable: {type(e).__name__}: {str(e)[:160]}") from e
        closes: dict[str, pd.Series] = {}
        for t in distinct:
            try:
                if isinstance(px.columns, pd.MultiIndex):
                    closes[t] = px[t]["Close"].dropna()
                elif len(distinct) == 1:
                    closes[t] = px["Close"].dropna()
            except KeyError:
                continue
        rows = []
        for iso, kind, t in want:
            for d, v in closes.get(t, pd.Series(dtype=float)).items():
                rows.append({"iso": iso, "series": kind, "period": pd.Timestamp(d).strftime("%Y-%m-%d"), "value": v})
        if not rows:
            said = " ".join(noise).lower()
            if any(m in said for m in _PROXY_MARKERS):
                raise FeedUnreachable(f"proxy refused CONNECT to {YAHOO_HOSTS[0]}")
            if any(m in said for m in _DNS_MARKERS):
                raise FeedUnreachable(f"DNS lookup failed for {YAHOO_HOSTS[0]}")
            raise FeedError("Yahoo Finance returned no prices (network blocked or tickers unknown)"
                            + (f"; yfinance said: {_one_line(noise[0], 200)}" if noise else ""))
        out = _long(rows, "yfinance (Yahoo Finance)")
        out.attrs["failures"] = [f"yfinance: {_one_line(m, 300)}" for m in noise[:20]]
        return out


@contextlib.contextmanager
def _captured_output(logger_name: str, into: list[str]):
    """Collect what a package logs (logger `logger_name`, WARNING and up) or prints during the block into `into`, one
    entry per distinct non-empty line, instead of letting it reach the terminal. The logger's handlers and
    propagation flag and sys.stdout/stderr are restored afterwards."""
    lg = logging.getLogger(logger_name)

    class _Keep(logging.Handler):
        def emit(self, record):
            try:
                into.append(record.getMessage())
            except Exception:  # noqa: BLE001 - a bad log record must not break the fetch
                pass
    h = _Keep(level=logging.WARNING)
    prop = lg.propagate
    out, err = io.StringIO(), io.StringIO()
    lg.addHandler(h); lg.propagate = False
    try:
        with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
            yield into
    finally:
        lg.removeHandler(h); lg.propagate = prop
        lines = [ln.strip() for chunk in (out.getvalue(), err.getvalue()) for ln in chunk.splitlines()]
        into += [ln for ln in lines if ln]
        uniq = list(dict.fromkeys(m.strip() for m in into if m and m.strip()))
        into[:] = uniq


# ----------------------------------------------------------------------------------------------
# Transforms: long tables -> Inputs units
# ----------------------------------------------------------------------------------------------
def _latest(long: pd.DataFrame, iso: str, series: str, period=None, max_period=None):
    s = long[(long["iso"] == iso) & (long["series"] == series)]
    if period is not None:
        s = s[s["period"] == period]
    if max_period is not None:
        s = s[s["period"] <= max_period]
    if s.empty:
        return np.nan
    return float(s.sort_values("period").iloc[-1]["value"])


def _series(long: pd.DataFrame, iso: str, series: str) -> pd.Series:
    s = long[(long["iso"] == iso) & (long["series"] == series)].sort_values("period")
    return pd.Series(s["value"].to_numpy(), index=s["period"].to_numpy(), dtype=float)


def _robust_latest(long: pd.DataFrame, iso: str, series: str, year: int, nsd: float = 3.0, min_hist: int = 8, log: list | None = None) -> float:
    """Year-t value of a flow ratio, falling back to year t-1 when the t value is an implausible jump.

    A jump is implausible when |x(t) - x(t-1)| exceeds `nsd` standard deviations of the annual changes
    observed over the previous 15 years (at least `min_hist` changes). Used for ratios such as the current
    account balance where a single projected year can be an outlier in the delivered vintage
    (e.g. WEO Oct 2026 Korea BCA 2026 = 18.8% of GDP after 6.5% in 2025).
    """
    return _robust_value(_series(long, iso, series), iso, series, year, nsd=nsd, min_hist=min_hist, log=log)


def _robust_value(s: pd.Series, iso: str, series: str, year: int, nsd: float = 3.0, min_hist: int = 8, log: list | None = None) -> float:
    """Same rule as _robust_latest, on an already extracted annual series (index = year)."""
    if year not in s.index:
        return np.nan
    x = float(s[year])
    if (year - 1) not in s.index:
        return x
    hist = s[(s.index <= year - 1) & (s.index > year - 16)].diff().dropna()
    if len(hist) < min_hist:
        return x
    sd = float(hist.std(ddof=1))
    jump = x - float(s[year - 1])
    if sd > 0 and abs(jump) > nsd * sd:
        if log is not None:
            log.append({"iso": iso, "series": series, "year": year, "value": x, "fallback": float(s[year - 1]),
                        "jump": jump, "sd_changes": sd, "rule": f"|change| > {nsd:g} SD of annual changes; used {year - 1}"})
        return float(s[year - 1])
    return x


RG_CAP = 0.10  # cap on |r - g| (share) in the primary-balance gap, avoids inflation artefacts (Argentina 2026 r-g = -0.3)


def weo_transforms(long: pd.DataFrame, iso: str, year: int, log: list | None = None) -> dict[str, float]:
    """Indicators the API Map draws from WEO: 1.3, 1.6, 1.7, 2.8, 5.5, 5.6, 5.12, 5.14 (and CPI for 5.13)."""
    out = {}
    debt = _series(long, iso, "GGXWDG_NGDP")
    out["1.3"] = _latest(long, iso, "GGXWDG_NGDP", period=year)
    if year in debt.index and (year - 5) in debt.index:
        out["1.7"] = float(debt[year] - debt[year - 5])
    out["2.8"] = _robust_latest(long, iso, "BCA_NGDPD", year, log=log)
    out["5.5"] = _latest(long, iso, "PCPIPCH", period=year)
    out["5.6"] = _latest(long, iso, "NGDP_RPCH", period=year + 1)
    out["5.14"] = _latest(long, iso, "NGDPDPC", period=year)
    g = _series(long, iso, "NGDP_RPCH")
    hist = g[(g.index <= year) & (g.index > year - 15) & ~g.index.isin([2020, 2021])]
    if len(hist) >= 8:
        out["5.12"] = float(hist.std(ddof=1))
    # 1.6 primary balance gap: pb - (r - g)/(1 + g) x d(t-1), all in % of GDP
    pb = _latest(long, iso, "GGXONLB_NGDP", period=year)
    ob = _latest(long, iso, "GGXCNL_NGDP", period=year)
    ngdp = _series(long, iso, "NGDP")
    if all(np.isfinite([pb, ob])) and (year - 1) in debt.index and debt[year - 1] > 0 and year in ngdp.index and (year - 1) in ngdp.index and ngdp[year - 1] > 0:
        interest = pb - ob                               # % of GDP
        r = interest / debt[year - 1]                    # effective nominal rate (share)
        growth = ngdp.pct_change().dropna()              # nominal growth (share); robust to a one-year outlier in the vintage
        gn = _robust_value(growth, iso, "NGDP (growth)", year, log=log)
        rg = float(np.clip(r - gn, -RG_CAP, RG_CAP))  # cap r-g: high-inflation years give meaningless gaps otherwise
        if log is not None and rg != r - gn:
            log.append({"iso": iso, "series": "GGXONLB_NGDP", "year": year, "value": r - gn, "fallback": rg,
                        "jump": np.nan, "sd_changes": np.nan, "rule": f"r-g capped at +/-{RG_CAP:g} in the 1.6 gap"})
        pb_star = rg / (1 + gn) * debt[year - 1]
        out["1.6"] = float(pb - pb_star)
    return {k: v for k, v in out.items() if v is not None and np.isfinite(v)}


def wgi_percentile_rank(long: pd.DataFrame, series: str, iso: str, period: int, min_n: int = WGI_XS_MIN) -> tuple[float, int]:
    """Percentile rank (0-100) of `iso`'s `series` value in `period` among all economies of the WGI cross-section
    (rows tagged WGI_XS_SOURCE), by the method of the WB *.PER.RNK series: the share of the other economies that rank
    strictly below, 100 x below / (n - 1), so the lowest is 0 and the highest 100; ties share the lower rank.
    Returns (rank, n); rank is NaN when the cross-section has fewer than `min_n` economies that year or lacks `iso`."""
    x = long[(long["series"] == series) & (long["source"] == WGI_XS_SOURCE)
             & (pd.to_numeric(long["period"], errors="coerce") == period) & ~long["iso"].isin(WB_AGGREGATE_CODES)]
    vals = pd.to_numeric(x["value"], errors="coerce").groupby(x["iso"].to_numpy()).last().dropna()
    n = len(vals)
    if n < max(min_n, 2) or iso not in vals.index:
        return float("nan"), n
    return float((vals < vals[iso]).sum() / (n - 1) * 100), n


def wb_transforms(long: pd.DataFrame, iso: str, used: dict | None = None, why: dict | None = None,
                  min_n: int = WGI_XS_MIN) -> tuple[dict[str, float], dict[str, float]]:
    """Indicators 2.9, 2.10, 3.4, 3.5, 5.10, 6.2, 6.6 and profile fields pop, exports, reserves.
    3.4/3.5 use the first WGI_FAMILIES family with all three series for the country (never a mix); `used`, when
    given, receives {"3.4"/"3.5": "<codes> (WGI...)"} for provenance. 3.5 is a percentile rank: the *.PER.RNK family
    as delivered, or the GOV_WGI_*.SC 0-100 scores converted with wgi_percentile_rank (EQ-A-0036). When only the
    scores are there and the all-economy cross-section is not, 3.4/3.5 stay empty (the raw score is never used) and
    `why`, when given, receives the reason per key."""
    ind, prof = {}, {}
    ind["2.9"] = _latest(long, iso, "DT.DOD.DSTC.IR.ZS")
    ind["2.10"] = _latest(long, iso, "DT.DOD.DECT.EX.ZS")
    ind["5.10"] = _latest(long, iso, "FB.AST.NPER.ZS")
    ind["6.2"] = _latest(long, iso, "VC.IHR.PSRC.P5")
    ind["6.6"] = _latest(long, iso, "SL.UEM.1524.ZS")
    for fam in WGI_FAMILIES:
        wgi = [_series(long, iso, s) for s in fam]
        if not all(len(s) for s in wgi):
            continue
        last = min(s.index.max() for s in wgi)
        if not all(last in s.index for s in wgi):
            continue
        if fam == WGI_SCORE_FAMILY:                      # 0-100 scores: rank among all economies, never the score
            codes = "/".join(fam)

            def ranks(year, fam=fam):          # fam bound at definition (ruff B023; the loop breaks below anyway)
                r = [wgi_percentile_rank(long, s, iso, year, min_n) for s in fam]
                return (float(np.mean([v for v, _ in r])) if all(np.isfinite(v) for v, _ in r) else float("nan")), [k for _, k in r]

            now, ns = ranks(last)
            if not np.isfinite(now):
                reason = (f"{codes} are 0-100 WGI scores, not percentile ranks; no all-economy cross-section for {last} "
                          f"(economies per series: {'/'.join(map(str, ns))}, need >= {min_n}), so no percentile rank; the raw score is not used")
                if why is not None:
                    why["3.5"] = why["3.4"] = reason
                break
            ind["3.5"] = now
            label = f"{codes} (WGI 0-100 score) -> percentile rank among {min(ns)}-{max(ns)} economies in {last} (share ranking below)"
            if used is not None:
                used["3.5"] = label
            before, nb = ranks(last - 3)
            if np.isfinite(before):
                ind["3.4"] = now - before
                if used is not None:
                    used["3.4"] = f"{codes} (WGI 0-100 score) -> percentile rank, {last} minus {last - 3} ({min(nb)}-{max(nb)} economies in {last - 3})"
            elif why is not None:
                why["3.4"] = f"{codes}: no all-economy percentile rank for {last - 3} (economies per series: {'/'.join(map(str, nb))}, need >= {min_n})"
            break
        now = np.mean([s[last] for s in wgi])
        ind["3.5"] = float(now)
        label = "/".join(fam) + " (WGI)"
        if used is not None:
            used["3.5"] = label
        if all((last - 3) in s.index for s in wgi):
            ind["3.4"] = float(now - np.mean([s[last - 3] for s in wgi]))
            if used is not None:
                used["3.4"] = label + ", 3y change"
        break
    pop = _latest(long, iso, "SP.POP.TOTL")
    if np.isfinite(pop):
        prof["pop"] = pop / 1e6
    prof["exports"] = _latest(long, iso, "NE.EXP.GNFS.ZS")
    res, gdp = _latest(long, iso, "FI.RES.TOTL.CD"), _latest(long, iso, "NY.GDP.MKTP.CD")
    if np.isfinite(res) and np.isfinite(gdp) and gdp > 0:
        prof["reserves"] = res / gdp * 100
    f = lambda d: {k: v for k, v in d.items() if v is not None and np.isfinite(v)}  # noqa: E731
    return f(ind), f(prof)


def bis_transforms(long: pd.DataFrame, iso: str, cpi: float | None) -> tuple[dict[str, float], dict[str, float]]:
    """2.12 real effective exchange rate vs 10-year average; 5.9 credit gap; 5.13 real policy rate; profile policy rate."""
    ind, prof = {}, {}
    eer = _series(long, iso, "EER_REAL_BROAD")
    if len(eer) >= 60:
        ind["2.12"] = float(eer.iloc[-1] / eer.iloc[-120:].mean() * 100 - 100)
    gap = _series(long, iso, "CREDIT_GAP")
    if len(gap):
        ind["5.9"] = float(gap.iloc[-1])
    pol = _series(long, iso, "POLICY_RATE")
    if len(pol):
        prof["policy"] = float(pol.iloc[-1])
        if cpi is not None and np.isfinite(cpi):
            ind["5.13"] = float(pol.iloc[-1] - cpi)
    return ind, prof


def yahoo_transforms(long: pd.DataFrame, iso: str, as_of: pd.Timestamp | None = None) -> dict[str, float]:
    """fx3m: % depreciation of the local currency against USD over ~3 months (positive = weaker);
    equity_vol: annualized realized volatility of the country ETF over the last 60 trading days."""
    out = {}
    v = fx3m(_series(long, iso, "FX_USD"), as_of)        # EQ-A-0040: one definition, shared with the official feeds
    if np.isfinite(v):
        out["fx3m"] = v
    etf = _series(long, iso, "ETF")
    if len(etf) > 61:
        rets = np.log(etf.to_numpy()[1:] / etf.to_numpy()[:-1])[-60:]
        out["equity_vol"] = float(np.std(rets, ddof=1) * math.sqrt(252) * 100)
    return out


# ----------------------------------------------------------------------------------------------
# Orchestration
# ----------------------------------------------------------------------------------------------
UNSERVED_COLUMNS = ["table", "key", "country", "iso", "feed", "reason"]
# --only names: 'bis' and 'worldbank' also pull their EQ-A-0028 companions (CBS claims, WB history); each can be named
# alone. 'fx' (EQ-A-0040) is the official FX pair: BIS WS_XRU and the ECB reference rates. 'yahoo' is not a feed any
# more (YAHOO_REFUSED): naming it raises ValueError before any request.
FEED_ALIASES = {"weo": ("weo",), "worldbank": ("worldbank", "worldbank_history"),
                "bis": ("bis", "bis_cbs", "bis_xru"), "fx": ("bis_xru", "ecb_exr")}


@dataclass
class FetchReport:
    indicators: pd.DataFrame        # id x country (NaN where no live value)
    profile: pd.DataFrame           # country x field
    provenance: pd.DataFrame        # one row per written cell
    feeds: dict                     # feed -> "ok (n rows)" | error text
    raw: dict                       # feed -> long table
    transform_log: pd.DataFrame = field(default_factory=pd.DataFrame)  # robustness rules that changed a value
    unserved: pd.DataFrame = field(default_factory=lambda: pd.DataFrame(columns=UNSERVED_COLUMNS))  # cells no feed can serve, with the reason


def fetch_all(u, only: Iterable[str] | None = None, year: int | None = None, weo_version=None, log: Callable[[str], None] = print,
              probe: Callable[[str], str | None] | None = None) -> FetchReport:
    """Pull every feed for every country in `u` (any number of countries; EQ-A-0027 sized it for 88). BIS uses a
    `bis_iso2` column when countries.csv has one, else iso2; the official FX series are keyed by currency and shared
    by every country using it (`official_fx_plan`).
    `only` takes feed names; 'bis' and 'worldbank' include 'bis_cbs' (BIS consolidated banking statistics,
    HO-20261023-B-A-005), 'bis_xru' (daily exchange rates, EQ-A-0040) and 'worldbank_history' (WB_HISTORY_SERIES from
    1996, HO-20261023-B-A-006), which can also be named alone (FEED_ALIASES). bis_cbs and worldbank_history fill no
    Inputs cell: they are kept as raw tables (save_report writes live/raw_bis_cbs.csv and
    live/raw_worldbank_history.csv, save_vintage the vintage copies); the CBS pull adds one provenance row per debtor
    (table 'BIS CBS') and an unserved row for every debtor not reported.

    FX (EQ-A-0040, Sam 2026-10-23): the Country Profile fx3m is computed from BIS WS_XRU, or from the ECB reference
    rates through the same date's EUR/USD when BIS has no series for the currency; the two are cross-checked in
    `quality_gate`. Yahoo Finance is refused (`only=["yahoo"]` raises ValueError, YAHOO_REFUSED) and equity_vol is
    left unserved with NO_OFFICIAL_SOURCE: no official free source replaces the ETF prices.

    EQ-A-0037 (usability U04): before a feed's work its hosts (FEED_HOSTS) are probed, each host at most once per
    call (`probe`, default probe_host: host -> None when reachable, else a short reason). A feed none of whose hosts
    answers is skipped with one line, e.g. `[fetch] bis: unreachable (proxy refused CONNECT to stats.bis.org):
    skipped`; WEO still reads its cached `weo` download when there is one. A feed that hits a proxy refusal or DNS
    failure mid-way stops at once (FeedUnreachable). One log line per feed; a missing package is a failed feed, not
    a traceback."""
    year = year or dt.date.today().year
    names = u.names
    iso3 = dict(zip(names, u.countries["iso"]))
    none = pd.Series([None] * len(names), index=u.countries.index)
    bis_col = "bis_iso2" if "bis_iso2" in u.countries.columns else "iso2"
    iso2 = dict(zip(u.countries["iso"], u.countries.get(bis_col, none)))
    fxplan = official_fx_plan(u.countries)
    etfs = dict(zip(u.countries["iso"], u.countries.get("etf", none)))
    asked = list(only) if only is not None else list(FEED_ALIASES)
    refused = [x for x in asked if str(x).strip().lower() in ("yahoo", "yfinance")]
    if refused:
        raise ValueError(f"feed {refused[0]!r}: {YAHOO_REFUSED}")
    want = {f for x in asked for f in FEED_ALIASES.get(x, (x,))}
    raw, feeds = {}, {}
    plan = {
        "weo": lambda: WeoFeed(version=weo_version).fetch(iso3.values()),
        "worldbank": lambda: WorldBankFeed().fetch(iso3.values()),
        "worldbank_history": lambda: WorldBankHistoryFeed().fetch(iso3.values()),
        "bis": lambda: BisFeed().fetch({k: v for k, v in iso2.items() if isinstance(v, str) and v}),
        "bis_cbs": lambda: BisFeed().fetch_cbs(dict(iso2)),
        "bis_xru": lambda: BisFeed().fetch_xru(dict(fxplan.bis_area)),
        "ecb_exr": lambda: EcbExrFeed().fetch(fxplan.ecb),
    }
    probe = probe or (lambda h: probe_host(h))          # looked up at call time, so tests can stub probe_host
    probed: dict[str, str | None] = {}

    def unreachable(name: str) -> str | None:
        """None when any host of the feed answers (or it has none listed), else the reasons."""
        reasons = []
        for h in FEED_HOSTS.get(name, ()):
            if h not in probed:
                probed[h] = probe(h)
            if probed[h] is None:
                return None
            reasons.append(probed[h])
        return "; ".join(reasons) or None

    for name, fn in plan.items():
        if name not in want:
            feeds[name] = "skipped"; continue
        why = unreachable(name)
        if why and name == "weo" and WeoFeed(version=weo_version).cache_file().exists():
            fn = lambda: WeoFeed(version=weo_version).fetch(iso3.values(), offline=True)   # noqa: E731 - cached release only
        elif why:
            feeds[name] = f"unreachable ({why}): skipped"; log(f"[fetch] {name}: {feeds[name]}"); continue
        try:
            raw[name] = fn(); feeds[name] = f"ok ({len(raw[name])} rows)" + (f" from the cached download ({why})" if why else "")
        except FeedUnreachable as e:
            feeds[name] = f"unreachable ({e.reason}): stopped at the first refused request"
        except FeedError as e:
            feeds[name] = f"unreachable ({why}), cached download not used: {_one_line(e, 200)}" if why else f"failed: {_one_line(e)}"
        except ImportError as e:           # wbgapi / yfinance / imf-reader not installed: one line, not a traceback
            feeds[name] = f"failed: package {getattr(e, 'name', None) or e} is not installed (see docs/runbooks/A-fetch-on-mac.md)"
        log(f"[fetch] {name}: {feeds[name]}")
    ind = pd.DataFrame(index=list(u.indicators["id"].astype(str)), columns=names, dtype=float)
    prof = pd.DataFrame(index=names, columns=["pop", "exports", "reserves", "fx3m", "policy", "equity_vol"], dtype=float)
    prov = []
    tlog: list = []
    wb_unserved: list = []      # EQ-A-0036: WGI cells left empty on purpose (scores without the all-economy cross-section)
    today = dt.date.today().isoformat()
    # EQ-A-0040: convert the ECB reference rates to per-USD once, not once per country
    ecb_usd = ecb_per_usd(raw["ecb_exr"]) if "ecb_exr" in raw else None

    def put(country, kind, key, value, source, series):
        if value is None or not np.isfinite(value):
            return
        if kind == "indicator":
            ind.at[key, country] = value
        else:
            prof.at[country, key] = value
        prov.append({"table": "Inputs" if kind == "indicator" else "Country Profile", "key": key, "country": country, "value": value, "source": source, "series": series, "retrieved": today})

    for n in names:
        iso = iso3[n]
        cpi = None
        if "weo" in raw:
            n0 = len(tlog)
            vals = weo_transforms(raw["weo"], iso, year, log=tlog)
            for e in tlog[n0:]:
                e["country"] = n
            cpi = vals.get("5.5")
            for k, v in vals.items():
                put(n, "indicator", k, v, raw["weo"].attrs.get("source", raw["weo"]["source"].iloc[0]), WEO_SOURCE_SERIES.get(k, ""))
        if "worldbank" in raw:
            used: dict = {}; wb_why: dict = {}
            i, p = wb_transforms(raw["worldbank"], iso, used=used, why=wb_why)
            wb_unserved += [{"table": "Inputs", "key": k, "country": n, "iso": iso, "feed": "worldbank", "reason": r}
                            for k, r in wb_why.items() if k not in i]
            for k, v in i.items():
                put(n, "indicator", k, v, raw["worldbank"]["source"].iloc[0], used.get(k, WB_SOURCE_SERIES.get(k, "")))
            for k, v in p.items():
                put(n, "profile", k, v, raw["worldbank"]["source"].iloc[0], WB_SOURCE_SERIES.get(k, ""))
        if "bis" in raw:
            i, p = bis_transforms(raw["bis"], iso, cpi)
            for k, v in i.items():
                put(n, "indicator", k, v, raw["bis"]["source"].iloc[0], BIS_SOURCE_SERIES.get(k, ""))
            for k, v in p.items():
                put(n, "profile", k, v, raw["bis"]["source"].iloc[0], "WS_CBPOL")
        if "bis_xru" in raw or "ecb_exr" in raw:          # EQ-A-0040: official FX, BIS first then ECB via EUR/USD
            vals, src, series = official_fx_transforms(raw, iso, fxplan, ecb_converted=ecb_usd)
            for k, v in vals.items():
                put(n, "profile", k, v, src, series)
    # EQ-A-0040: cells left empty on purpose, each with the reason (never another country's or another source's number)
    fx_feed = "bis_xru" if "bis_xru" in raw else ("ecb_exr" if "ecb_exr" in raw else "fx")
    unserved = [{"table": "Country Profile", "key": "fx3m", "country": n, "iso": iso3[n], "feed": fx_feed,
                 "reason": fxplan.why[iso3[n]]} for n in names if iso3[n] in fxplan.why]
    if "bis_xru" in raw or "ecb_exr" in raw:
        for n in names:
            iso = iso3[n]
            if iso in fxplan.why or np.isfinite(prof.at[n, "fx3m"]):
                continue
            ccy = fxplan.currency.get(iso, "")
            unserved.append({"table": "Country Profile", "key": "fx3m", "country": n, "iso": iso, "feed": fx_feed,
                             "reason": f"no official daily {ccy}/USD rate in BIS {XRU_FLOW} or ECB {EXR_FLOW} "
                                       f"(fx3m stays empty; see docs/runbooks/A-official-fx.md)"})
    unserved += [{"table": "Country Profile", "key": "equity_vol", "country": n, "iso": iso3[n], "feed": "none",
                  "reason": NO_OFFICIAL_SOURCE + (f"; ETF {etfs.get(iso3[n])}" if etfs.get(iso3[n]) else "")}
                 for n in names]
    unserved += wb_unserved
    if "bis_cbs" in raw:          # HO-20261023-B-A-005: one provenance row per debtor, and every debtor not reported
        cbs = raw["bis_cbs"]; latest = cbs.attrs.get("latest_period") or cbs["period"].max()
        tot = cbs[cbs["period"] == latest].groupby("debtor_iso3")["claims_usd_mn"].sum()
        for n in names:
            if iso3[n] in tot.index:
                prov.append({"table": "BIS CBS", "key": "foreign_claims_usd_mn", "country": n, "value": float(tot[iso3[n]]),
                             "source": cbs["source"].iloc[0], "series": f"{CBS_FLOW} basis {cbs['basis'].iloc[0]}, {latest}, sum over reporters",
                             "retrieved": today})
            else:
                unserved.append({"table": "BIS CBS", "key": "foreign_claims_usd_mn", "country": n, "iso": iso3[n], "feed": "bis_cbs",
                                 "reason": f"BIS {CBS_FLOW}: no reporting banking system shows claims on this country in {latest}"})
    return FetchReport(ind, prof, pd.DataFrame(prov), feeds, raw, pd.DataFrame(tlog),
                       pd.DataFrame(unserved, columns=UNSERVED_COLUMNS))


WEO_SOURCE_SERIES = {"1.3": "GGXWDG_NGDP", "1.6": "GGXONLB_NGDP, GGXCNL_NGDP, GGXWDG_NGDP, NGDP", "1.7": "GGXWDG_NGDP (t minus t-5)", "2.8": "BCA_NGDPD",
                     "5.5": "PCPIPCH", "5.6": "NGDP_RPCH (t+1)", "5.12": "NGDP_RPCH (15y SD ex 2020-21)", "5.14": "NGDPDPC"}
WB_SOURCE_SERIES = {"2.9": "DT.DOD.DSTC.IR.ZS (WDI, IDS fallback)", "2.10": "DT.DOD.DECT.EX.ZS (IDS)",
                    "3.4": "RL/CC/RQ.PER.RNK or GOV_WGI_RL/CC/RQ.SC ranked among all economies (WGI, 3y change)", "3.5": "RL/CC/RQ.PER.RNK or GOV_WGI_RL/CC/RQ.SC ranked among all economies (WGI)",
                    "5.10": "FB.AST.NPER.ZS", "6.2": "VC.IHR.PSRC.P5", "6.6": "SL.UEM.1524.ZS", "pop": "SP.POP.TOTL", "exports": "NE.EXP.GNFS.ZS", "reserves": "FI.RES.TOTL.CD / NY.GDP.MKTP.CD"}
BIS_SOURCE_SERIES = {"2.12": "WS_EER M.R.B (vs 10y mean)", "5.9": "WS_CREDIT_GAP Q.P.A.C", "5.13": "WS_CBPOL minus WEO PCPIPCH"}


def diff_against_seed(u, report: FetchReport) -> pd.DataFrame:
    """Side-by-side of seed inputs and live values for every cell the feeds filled."""
    rows = []
    seed = u.indicators.set_index("id")
    for key in report.indicators.index:
        for n in report.indicators.columns:
            v = report.indicators.at[key, n]
            if np.isfinite(v):
                old = pd.to_numeric(seed.at[key, n], errors="coerce") if key in seed.index else np.nan
                rows.append({"table": "Inputs", "key": key, "country": n, "seed": old, "live": v, "change": v - old if np.isfinite(old) else np.nan})
    prof = u.countries.set_index("country")
    for n in report.profile.index:
        for k in report.profile.columns:
            v = report.profile.at[n, k]
            if np.isfinite(v):
                old = pd.to_numeric(prof.at[n, k], errors="coerce") if k in prof.columns else np.nan
                rows.append({"table": "Country Profile", "key": k, "country": n, "seed": old, "live": v, "change": v - old if np.isfinite(old) else np.nan})
    return pd.DataFrame(rows, columns=["table", "key", "country", "seed", "live", "change"])


def _require_a_feed(report: FetchReport, data_dir: Path) -> None:
    """EQ-A-0037: raise NoFeedSucceeded when the report lists feeds and none of them is 'ok ...', before any write."""
    feeds = getattr(report, "feeds", None) or {}
    if feeds and not any(str(v).startswith("ok") for v in feeds.values()):
        tried = [k for k, v in feeds.items() if v != "skipped"]
        raise NoFeedSucceeded(f"Nothing applied: no feed succeeded ({', '.join(tried) or 'no feed was requested'}). "
                              f"Nothing written to {Path(data_dir) / 'live'}; no vintage saved.")


def save_report(report: FetchReport, data_dir: Path, diff: pd.DataFrame | None = None) -> Path:
    """Write the pull under data/live. Refuses (NoFeedSucceeded, nothing written) when no feed succeeded (EQ-A-0037).
    feed_failures.csv lists each raw table's failures and, per failed or unreachable feed, its one-line status."""
    _require_a_feed(report, data_dir)
    live = Path(data_dir) / "live"; live.mkdir(parents=True, exist_ok=True)
    report.indicators.to_csv(live / "live_inputs.csv")
    report.profile.to_csv(live / "live_profile.csv")
    report.provenance.to_csv(live / "provenance.csv", index=False)
    report.transform_log.to_csv(live / "transform_log.csv", index=False)
    if diff is not None:
        diff.to_csv(live / "diff_vs_seed.csv", index=False)
    for name, df in report.raw.items():
        df.to_csv(live / f"raw_{name}.csv", index=False)
    unserved = getattr(report, "unserved", None)
    (unserved if unserved is not None else pd.DataFrame(columns=UNSERVED_COLUMNS)).to_csv(live / "unserved.csv", index=False)
    failures = [{"feed": name, "failure": f} for name, df in report.raw.items() for f in df.attrs.get("failures", [])]
    failures += [{"feed": name, "failure": str(v)} for name, v in (report.feeds or {}).items()
                 if name not in report.raw and not str(v).startswith(("ok", "skipped"))]
    pd.DataFrame(failures, columns=["feed", "failure"]).to_csv(live / "feed_failures.csv", index=False)
    (live / "feeds.json").write_text(json.dumps({"feeds": report.feeds, "retrieved": dt.date.today().isoformat()}, indent=1))
    return live


# ----------------------------------------------------------------------------------------------
# Quality gate (roadmap 1.5): a live value is held for review, not applied, when it fails a check
# ----------------------------------------------------------------------------------------------
WB_STALE_SERIES = {"2.9": "DT.DOD.DSTC.IR.ZS", "2.10": "DT.DOD.DECT.EX.ZS", "5.10": "FB.AST.NPER.ZS", "6.2": "VC.IHR.PSRC.P5", "6.6": "SL.UEM.1524.ZS",
                   "pop": "SP.POP.TOTL", "exports": "NE.EXP.GNFS.ZS", "reserves": "FI.RES.TOTL.CD"}
# EQ-A-0044: BIS series are dated observations, not annual periods, so their staleness is an age in days between the
# last observation (end of its period) and the gate's reference date. The limit is set per frequency, from the period
# format of the raw rows: about one publication cycle plus the usual BIS release lag.
#   D (YYYY-MM-DD, WS_CBPOL policy rate): 30 days. Central banks set rates at least every 6-8 weeks and BIS carries the
#     rate on every business day, so a month with no observation means the series stopped (Argentina ends 2025-07-10).
#   M (YYYY-MM, WS_EER real effective rate): 92 days, about two monthly releases after the month ends.
#   Q (YYYY-Qn, WS_CREDIT_GAP): 275 days. The credit gap is published about two quarters after the quarter ends, so
#     the quarter before last is still current; three quarters past the end of the last one is stale.
BIS_STALE_SERIES = {"2.12": "EER_REAL_BROAD", "5.9": "CREDIT_GAP", "5.13": "POLICY_RATE", "policy": "POLICY_RATE"}
BIS_STALE_DAYS = {"D": 30, "M": 92, "Q": 275}


def _period_end(period) -> tuple[dt.date, str] | None:
    """(last day, frequency D/M/Q) of a BIS period 'YYYY-MM-DD', 'YYYY-MM' or 'YYYY-Qn'; None when unreadable."""
    s = str(period).strip()
    try:
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", s):
            return dt.date.fromisoformat(s), "D"
        m = re.fullmatch(r"(\d{4})-(\d{2})", s)
        if m:
            y, mo = int(m[1]), int(m[2])
            return dt.date(y + mo // 12, mo % 12 + 1, 1) - dt.timedelta(days=1), "M"
        m = re.fullmatch(r"(\d{4})-Q([1-4])", s)
        if m:
            y, q = int(m[1]), int(m[2])
            return dt.date(y + q // 4, (q * 3) % 12 + 1, 1) - dt.timedelta(days=1), "Q"
    except ValueError:
        return None
    return None


def bis_staleness(raw_bis: pd.DataFrame | None, iso: str, series: str, ref: dt.date,
                  max_days: dict | None = None) -> str:
    """'' when the BIS `series` of `iso` has an observation recent enough at `ref`, else the stale reason, e.g.
    'stale: BIS POLICY_RATE last observation 2025-07-10, 470 days before 2026-10-23 (limit 30 days, daily)'.
    No rows for the country: '' (the missing-value check reports that)."""
    if raw_bis is None or not len(raw_bis):
        return ""
    s = raw_bis[(raw_bis["iso"] == iso) & (raw_bis["series"] == series)]
    ends = [e for e in (_period_end(p) for p in s["period"]) if e is not None]
    if not ends:
        return ""
    last, freq = max(ends)
    limit = (max_days or BIS_STALE_DAYS)[freq]
    age = (ref - last).days
    if age <= limit:
        return ""
    name = {"D": "daily", "M": "monthly", "Q": "quarterly"}[freq]
    return f"stale: BIS {series} last observation {last.isoformat()}, {age} days before {ref.isoformat()} (limit {limit} days, {name})"


def _gate_reference_date(report: FetchReport, as_of) -> dt.date:
    """Reference date of the BIS staleness check: as_of when given, else the pull date (latest provenance
    'retrieved'), else today (UTC)."""
    if as_of is not None:
        return pd.Timestamp(as_of).date()
    prov = getattr(report, "provenance", None)
    if prov is not None and len(prov) and "retrieved" in prov.columns:
        t = pd.to_datetime(prov["retrieved"], errors="coerce", utc=True).max()
        if pd.notna(t):
            return t.date()
    return dt.datetime.now(dt.timezone.utc).date()


PROFILE_RANGES = {"pop": (0.1, 2000), "exports": (0, 250), "reserves": (0, 200), "fx3m": (-80, 400), "policy": (-5, 200), "equity_vol": (0, 300)}


def quality_gate(u, report: FetchReport, diff: pd.DataFrame, max_rel_change: float = 0.5, span_mult: float = 2.0,
                 stale_years: int = 3, year: int | None = None, data_dir: Path | None = None,
                 previous_vintage_id: str | None = None, as_of=None) -> pd.DataFrame:
    """Checks every live cell and returns a review table with one row per cell: table, key, country, seed, live,
    status ('ok' or 'hold'), reason. Checks:
      range   value far outside the rulebook thresholds t0..t100 (beyond span_mult x their span) or a profile range
      change  |live - seed| above max_rel_change of |seed| AND above a quarter of the threshold span
      stale   World Bank value whose latest period is more than stale_years before `year`; BIS value (BIS_STALE_SERIES)
              whose last observation is older than BIS_STALE_DAYS for its frequency (daily 30, monthly 92, quarterly
              275 days) at `as_of` (default: the pull date from provenance 'retrieved', else today UTC; EQ-A-0044)
    Plus a missing-country row ('missing') for every indicator a successful feed left empty for some country, and for
    every cell the report lists as unserved (EQ-A-0040: equity_vol, currencies with no official rate), with its reason.
    The official FX sources are cross-checked against each other (`fx_cross_checks`): BIS WS_XRU against the ECB
    reference rates converted through EUR/USD, holding fx3m when they disagree.
    Gate v2 (EQ-A-0017, ingestion/crosscheck.py): WEO vs World Bank on matching concepts ('cross: ...') and, when
    data_dir is given, the previous vintage ('vintage: ...'); either turns a cell to hold, never back to ok."""
    year = year or dt.date.today().year
    ref = _gate_reference_date(report, as_of)
    iso_of = dict(zip(u.names, u.countries["iso"]))
    rb = u.rulebook.set_index("id")
    rows = []
    for r in diff.itertuples(index=False):
        reasons = []
        seed, live = r.seed, r.live
        if r.table == "Inputs" and r.key in rb.index:
            th = pd.to_numeric(rb.loc[r.key, ["t0", "t25", "t50", "t75", "t100"]], errors="coerce").dropna()
            if len(th) >= 2:
                lo, hi = float(th.min()), float(th.max()); span = max(hi - lo, 1e-9)
                if live < lo - span_mult * span or live > hi + span_mult * span:
                    reasons.append(f"range: {live:.4g} outside [{lo - span_mult * span:.4g}, {hi + span_mult * span:.4g}] (thresholds {lo:.4g}..{hi:.4g})")
                if np.isfinite(seed) and abs(live - seed) > max_rel_change * max(abs(seed), 1e-9) and abs(live - seed) > 0.25 * span:
                    reasons.append(f"change: {seed:.4g} -> {live:.4g} ({(live - seed) / max(abs(seed), 1e-9) * 100:+.0f}%)")
        elif r.table == "Country Profile" and r.key in PROFILE_RANGES:
            lo, hi = PROFILE_RANGES[r.key]
            if live < lo or live > hi:
                reasons.append(f"range: {live:.4g} outside [{lo}, {hi}]")
            if np.isfinite(seed) and abs(live - seed) > max_rel_change * max(abs(seed), 1e-9):
                reasons.append(f"change: {seed:.4g} -> {live:.4g} ({(live - seed) / max(abs(seed), 1e-9) * 100:+.0f}%)")
        if r.key in WB_STALE_SERIES and "worldbank" in report.raw:
            iso = dict(zip(u.names, u.countries["iso"])).get(r.country)
            s = report.raw["worldbank"]; s = s[(s["iso"] == iso) & (s["series"] == WB_STALE_SERIES[r.key])]
            if len(s):
                last = pd.to_numeric(s["period"], errors="coerce").max()
                if np.isfinite(last) and last < year - stale_years:
                    reasons.append(f"stale: latest period {int(last)}")
        if r.key in BIS_STALE_SERIES and "bis" in report.raw:
            why = bis_staleness(report.raw["bis"], iso_of.get(r.country), BIS_STALE_SERIES[r.key], ref)
            if why:
                reasons.append(why)
        rows.append({"table": r.table, "key": r.key, "country": r.country, "seed": seed, "live": live,
                     "status": "hold" if reasons else "ok", "reason": "; ".join(reasons)})
    ok_feeds = [k for k, v in report.feeds.items() if str(v).startswith("ok")]
    unserved = getattr(report, "unserved", None)
    why = {} if unserved is None or not len(unserved) else {(r.table, str(r.key), r.country): f"{r.feed}: not served - {r.reason}" for r in unserved.itertuples(index=False)}
    feed_keys = {"weo": set(WEO_SOURCE_SERIES), "worldbank": set(WB_SOURCE_SERIES), "bis": set(BIS_SOURCE_SERIES),
                 "bis_xru": {"fx3m"}, "ecb_exr": {"fx3m"}}      # EQ-A-0040: the two official FX feeds share fx3m
    seen = {(r["table"], str(r["key"]), r["country"]) for r in rows}
    for f in ok_feeds:
        for key in sorted(feed_keys.get(f, ())):
            tbl = "Inputs" if key in report.indicators.index else "Country Profile"
            for n in u.names:
                v = report.indicators.at[key, n] if tbl == "Inputs" else (report.profile.at[n, key] if key in report.profile.columns else np.nan)
                if np.isfinite(v) or (tbl, key, n) in seen:
                    continue
                seen.add((tbl, key, n))
                rows.append({"table": tbl, "key": key, "country": n, "seed": np.nan, "live": np.nan, "status": "missing",
                             "reason": why.get((tbl, key, n), f"{f} returned no value")})
    # EQ-A-0040: a cell no feed even tried (equity_vol has no official free source) is still reported, with its reason
    for (tbl, key, n), reason in why.items():
        if (tbl, key, n) not in seen:
            seen.add((tbl, key, n))
            rows.append({"table": tbl, "key": key, "country": n, "seed": np.nan, "live": np.nan, "status": "missing",
                         "reason": reason})
    review = pd.DataFrame(rows, columns=["table", "key", "country", "seed", "live", "status", "reason"])
    # Gate v2 (EQ-A-0017): WEO vs World Bank, and (with data_dir) the previous vintage; holds are merged, never downgraded
    from .crosscheck import cross_source_checks, merge_into_review, vintage_checks   # lazy: crosscheck imports feeds
    extra = [cross_source_checks(report, u, year), fx_cross_checks(report.raw, official_fx_plan(u.countries), u)]
    if data_dir is not None:
        extra.append(vintage_checks(data_dir, report, previous_vintage_id, max_rel_change=max_rel_change, u=u))
    return merge_into_review(review, pd.concat(extra, ignore_index=True))


VINTAGE_INDEX_COLUMNS = ["vintage_id", "retrieved_utc", "hash", "n_files"]


def _utc(now: dt.datetime | None) -> dt.datetime:
    """`now` as an aware UTC datetime (naive values are taken to be UTC); the current time when None."""
    now = now or dt.datetime.now(dt.timezone.utc)
    return now.replace(tzinfo=dt.timezone.utc) if now.tzinfo is None else now.astimezone(dt.timezone.utc)


def _content_hash(files: dict[str, bytes]) -> str:
    """SHA-256 over the files in name order (name, NUL, content, NUL for each), so the hash is deterministic."""
    h = hashlib.sha256()
    for name in sorted(files):
        h.update(name.encode() + b"\0" + files[name] + b"\0")
    return h.hexdigest()


def _vintage_root(data_dir: Path) -> Path:
    return Path(data_dir) / "live" / "vintages"


def _is_vintage_dir(p: Path) -> bool:
    return p.is_dir() and not p.name.startswith(".") and p.name[:4].isdigit()


def list_vintages(data_dir: Path) -> list[str]:
    """Vintage ids under data/live/vintages/, oldest first. Legacy ids are a bare date (`2026-10-23`); new ids are
    `<YYYY-MM-DD>T<HHMMSS>Z-<hash8>`, which sort after the legacy folder of the same day."""
    root = _vintage_root(data_dir)
    return sorted(p.name for p in root.iterdir() if _is_vintage_dir(p)) if root.exists() else []


def vintage_path(data_dir: Path, vintage_id: str) -> Path:
    """Folder of a vintage. `vintage_id` is a full id, a legacy date id, or a date (`YYYY-MM-DD`), which means the
    latest vintage of that day. Raises FileNotFoundError when nothing matches (never falls back to another day)."""
    ids = list_vintages(data_dir)
    if vintage_id in ids:
        return _vintage_root(data_dir) / vintage_id
    same_day = [v for v in ids if v.startswith(f"{vintage_id}T")]
    if same_day:
        return _vintage_root(data_dir) / same_day[-1]
    raise FileNotFoundError(f"no vintage {vintage_id!r} under {_vintage_root(data_dir)}")


def _append_index(root: Path, row: dict) -> None:
    """Append one row to vintages/index.csv under an exclusive lock (POSIX), so concurrent fetches never write two
    headers. On first creation the legacy date-only folders are indexed too (hash over their files, read only; the
    folders are not modified)."""
    from .ledger import locked_append
    with locked_append(root / "index.csv", VINTAGE_INDEX_COLUMNS) as (w, f, new):
        if new:
            w.writeheader()
            for p in sorted(root.iterdir()):
                if _is_vintage_dir(p) and "T" not in p.name:
                    files = {q.name: q.read_bytes() for q in p.iterdir() if q.is_file()}
                    try:
                        retrieved = json.loads(files.get("feeds.json", b"{}")).get("retrieved", p.name)
                    except ValueError:
                        retrieved = p.name
                    w.writerow({"vintage_id": p.name, "retrieved_utc": retrieved, "hash": _content_hash(files), "n_files": len(files)})
        w.writerow(row)


_VINTAGE_HASH8_RE = re.compile(r"\d{4}-\d{2}-\d{2}T\d{6}Z-([0-9a-f]{8})")


def verify_vintage(data_dir: Path, vintage_id: str) -> dict:
    """Recompute a vintage's content hash and compare it with its rows in vintages/index.csv. index.csv is append-only,
    so the row written at save time is the first one for the id; every row for the id must carry the same hash and file
    count (SEC-A-004 L1: a later appended row can never override the first). For a new-style id
    `<YYYY-MM-DD>T<HHMMSS>Z-<hash8>` the hash8 suffix must also equal the first 8 hex digits of the recomputed hash
    (save_vintage names the folder after its content). Returns {"vintage_id", "hash", "n_files"} when everything
    agrees; raises replay.VintageIntegrityError (a ValueError) when the hash, file count or hash8 differs, the index
    rows for the id disagree, or the vintage has no index row; FileNotFoundError when there is no such vintage."""
    from .replay import VintageIntegrityError
    v = vintage_path(data_dir, vintage_id)
    files = {q.name: q.read_bytes() for q in v.iterdir() if q.is_file()}
    digest = _content_hash(files)
    idx = _vintage_root(data_dir) / "index.csv"
    rows = []
    if idx.exists():
        with open(idx, newline="") as f:
            rows = [r for r in csv.DictReader(f) if r.get("vintage_id") == v.name]
    if not rows:
        raise VintageIntegrityError(f"vintage {v.name} has no row in {idx}")
    if len({(r.get("hash"), str(r.get("n_files"))) for r in rows}) > 1:
        raise VintageIntegrityError(f"vintage {v.name} failed verification: {len(rows)} rows in {idx} disagree on hash or "
                                    "file count (index.csv is append-only; a second row for an id is not a fix)")
    want = rows[0]
    problems = []
    if want.get("hash") != digest:
        problems.append(f"hash {digest} != index {want.get('hash')}")
    if str(want.get("n_files")) != str(len(files)):
        problems.append(f"{len(files)} files != index {want.get('n_files')}")
    m = _VINTAGE_HASH8_RE.fullmatch(v.name)
    if m and m.group(1) != digest[:8]:
        problems.append(f"folder hash8 {m.group(1)} != content hash {digest[:8]}")
    if problems:
        raise VintageIntegrityError(f"vintage {v.name} failed verification: " + "; ".join(problems))
    return {"vintage_id": v.name, "hash": digest, "n_files": len(files)}


def save_vintage(data_dir: Path, report: FetchReport, review: pd.DataFrame | None = None, now: dt.datetime | None = None) -> Path:
    """Point-in-time copy (roadmap 1.2), append-only: data/live/vintages/<YYYY-MM-DD>T<HHMMSS>Z-<hash8>/ keeps what the
    pull returned. hash8 is the first 8 hex digits of `_content_hash` over the files written. The folder is created with
    exist_ok=False, so an existing vintage is never overwritten (FileExistsError); files are made read-only (0o444) and
    the vintage is appended to vintages/index.csv. `now` fixes the clock (UTC) for tests. Every raw table is kept as
    raw_<feed>.csv, including raw_bis_cbs.csv and raw_worldbank_history.csv (EQ-A-0028), and unserved.csv when the
    report lists unserved cells (debtors BIS does not report, currencies with no official rate, equity_vol). Refuses (NoFeedSucceeded,
    nothing written) when no feed succeeded (EQ-A-0037)."""
    _require_a_feed(report, data_dir)
    now = _utc(now)
    files = {"live_inputs.csv": report.indicators.to_csv().encode(), "live_profile.csv": report.profile.to_csv().encode(),
             "provenance.csv": report.provenance.to_csv(index=False).encode()}
    for name, df in report.raw.items():
        files[f"raw_{name}.csv"] = df.to_csv(index=False).encode()
    if review is not None:
        files["review.csv"] = review.to_csv(index=False).encode()
    unserved = getattr(report, "unserved", None)
    if unserved is not None and len(unserved):
        files["unserved.csv"] = unserved.to_csv(index=False).encode()
    files["feeds.json"] = json.dumps({"feeds": report.feeds, "retrieved": now.strftime("%Y-%m-%dT%H:%M:%SZ")}, indent=1).encode()
    digest = _content_hash(files)
    root = _vintage_root(data_dir); root.mkdir(parents=True, exist_ok=True)
    v = root / f"{now.strftime('%Y-%m-%dT%H%M%SZ')}-{digest[:8]}"
    v.mkdir(exist_ok=False)
    for name in sorted(files):
        (v / name).write_bytes(files[name]); os.chmod(v / name, 0o444)
    _append_index(root, {"vintage_id": v.name, "retrieved_utc": now.strftime("%Y-%m-%dT%H:%M:%SZ"), "hash": digest, "n_files": len(files)})
    return v


def _snapshot_inputs(d: Path, now: dt.datetime | None = None) -> Path:
    """Copy indicators.csv and countries.csv to data/live/snapshots/<UTC ts>-pre-apply/ (read-only). Never overwrites:
    a second apply in the same second gets a -1, -2 ... suffix."""
    root = d / "live" / "snapshots"; root.mkdir(parents=True, exist_ok=True)
    base = f"{_utc(now).strftime('%Y-%m-%dT%H%M%SZ')}-pre-apply"
    for n in range(1000):
        snap = root / (base if n == 0 else f"{base}-{n}")
        try:
            snap.mkdir(exist_ok=False); break
        except FileExistsError:
            continue
    else:
        raise FileExistsError(f"no free snapshot folder for {base}")
    for f in ("indicators.csv", "countries.csv"):
        if (d / f).exists():
            shutil.copy2(d / f, snap / f); os.chmod(snap / f, 0o444)
    return snap


def _atomic_csv(df: pd.DataFrame, path: Path) -> None:
    """Write df to path through a temp file in the same folder and os.replace. The new file is always mode 0o644 (a
    read-only mode left by a restore is not carried over)."""
    mode = 0o644
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", newline="") as f:
            df.to_csv(f, index=False)
        os.chmod(tmp, mode); os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


APPLY_COUNT_KEYS = ("indicator_cells", "profile_cells", "held_for_review")
FORCED_COLUMNS = ["table", "key", "country", "live", "gate_status", "vintage_id", "author", "approver", "self_approved", "ts_utc"]


def apply_report(report: FetchReport, data_dir: Path, review: pd.DataFrame | None = None, force: bool = False,
                 now: dt.datetime | None = None, vintage_id: str | None = None, author: str | None = None,
                 approver: str | None = None, self_approved: bool = False, rollback: dict | None = None) -> dict:
    """Overwrite seed values in indicators.csv and countries.csv with the live values (only where a live value
    exists). Cells that must not be applied are `ledger.effective_holds(review, <ledger decisions>, vintage_id)`:
    gate holds unless approved under four-eyes (or a flagged self-approval) for this vintage or live value, plus any
    cell whose latest ledger decision is hold or reject. Decisions are read from data/live/review_ledger.csv only; a
    decision column in `review` is ignored.
    force=True applies those cells too. It needs `author` and an `approver` other than the author (or
    `self_approved=True`, single-operator mode), else ValueError before anything is written; each forced cell gets a
    ledger row (decision apply, note 'forced') and is listed in forced_cells.csv in the pre-apply snapshot folder.
    Before writing, the current files are copied to data/live/snapshots/<UTC ts>-pre-apply/; both files are then
    replaced atomically. Returns a plain dict: the counts indicator_cells, profile_cells, held_for_review, plus
    "snapshot" (str), "inputs_snapshot" (with vintage_id) and, with force=True, "forced_cells" (list of
    (table, key, country) tuples applied although they would have been held).
    With `vintage_id` (the vintage this report was saved as), the full set of Team A run inputs is then frozen with
    `replay.freeze_inputs` and the folder is returned as "inputs_snapshot" (EQ-A-0007: replay with
    load_universe(vintage=...)).
    `rollback` (apply_vintage on an older vintage, SEC-A-004 L2) is written as rollback.json (read-only) into the
    pre-apply snapshot folder before the data files change, and returned as "rollback".
    After the write, "restricted_source_cells" is the number of applied cells that still hold a Yahoo or
    non-commercial value (audit.restricted_source_cells, SEC-A-006 M1); while it is not 0 a loud warning goes to stderr."""
    from .ledger import _append as _ledger_append, _ts, check_approval, effective_holds, load_decisions
    d = Path(data_dir)
    if force:
        try:
            author, approver, flag = check_approval(author, approver, self_approved)
        except ValueError as e:
            raise ValueError(f"apply_report(force=True) {e}") from None
    # resolve before anything is matched or written: an unknown vintage must not release holds (SEC-A-001 L1)
    vid = vintage_path(d, str(vintage_id)).name if vintage_id is not None else ""
    held = effective_holds(review, load_decisions(d), vintage_id=vid or None)
    gate = {}
    if review is not None:
        gate = {(r.table, str(r.key), r.country): r.status for r in review.itertuples(index=False)}
    forced = []
    if force:
        must_hold, held = held, set()
    ind = pd.read_csv(d / "indicators.csv", dtype={"id": str, "pillar": str})
    n_ind = n_held = 0
    live_of = {}
    for key in report.indicators.index:
        m = ind["id"] == key
        if not m.any():
            continue
        for c in report.indicators.columns:
            v = report.indicators.at[key, c]
            if np.isfinite(v) and c in ind.columns:
                if ("Inputs", key, c) in held:
                    n_held += 1; continue
                if force and ("Inputs", key, c) in must_hold:
                    forced.append(("Inputs", key, c)); live_of[forced[-1]] = float(v)
                ind.loc[m, c] = round(float(v), 4); n_ind += 1
    cty = read_csv_keep_na_code(d / "countries.csv", dtype=str)    # Namibia's iso2 'NA' must be written back as 'NA'
    n_prof = 0
    for n in report.profile.index:
        m = cty["country"] == n
        for k in ("pop", "exports", "reserves", "fx3m", "policy"):
            v = report.profile.at[n, k]
            if np.isfinite(v) and k in cty.columns:
                if ("Country Profile", k, n) in held:
                    n_held += 1; continue
                if force and ("Country Profile", k, n) in must_hold:
                    forced.append(("Country Profile", k, n)); live_of[forced[-1]] = float(v)
                cty.loc[m, k] = f"{float(v):.4g}"; n_prof += 1
    snap = _snapshot_inputs(d, now)
    if force:
        ts = _ts(now)
        rows = [{"ts_utc": ts, "vintage_id": vid, "table": t, "key": str(k), "country": c, "gate_status": gate.get((t, str(k), c), ""),
                 "live": live_of[(t, k, c)], "decision": "apply", "author": author, "approver": approver, "note": "forced",
                 "self_approved": flag} for t, k, c in forced]
        fc = snap / "forced_cells.csv"
        pd.DataFrame(rows, columns=FORCED_COLUMNS + ["decision", "note"])[FORCED_COLUMNS].to_csv(fc, index=False)
        os.chmod(fc, 0o444)
        if rows:
            _ledger_append(d, rows)            # recorded before the data files change
    if rollback:
        rb = snap / "rollback.json"            # recorded before the data files change, like forced_cells.csv
        rb.write_text(json.dumps(rollback, indent=1, sort_keys=True) + "\n")
        os.chmod(rb, 0o444)
    _atomic_csv(ind, d / "indicators.csv")
    _atomic_csv(cty, d / "countries.csv")
    out = {"indicator_cells": n_ind, "profile_cells": n_prof, "held_for_review": n_held, "snapshot": str(snap)}
    if vintage_id is not None:
        from .replay import freeze_inputs
        out["inputs_snapshot"] = str(freeze_inputs(d, vid, now))
    if force:
        out["forced_cells"] = forced
    if rollback:
        out["rollback"] = dict(rollback, record=str(snap / "rollback.json"))
    out["restricted_source_cells"] = _warn_restricted_cells(d)
    return out


def _warn_restricted_cells(d: Path) -> int | None:
    """SEC-A-006 M1: after an apply, the number of applied cells still holding a Yahoo / non-commercial value
    (audit.restricted_source_cells), with a loud warning on stderr while it is not 0. None when the check could not
    run (also warned): the apply itself has already happened and stays."""
    from .audit import restricted_source_cells, restricted_warning      # here: audit imports this module
    try:
        cells = restricted_source_cells(d)
    except (OSError, ValueError, KeyError) as e:
        print(f"WARNING (SEC-A-006 M1): could not check the applied cells for restricted sources: "
              f"{type(e).__name__}: {e}", file=sys.stderr)
        return None
    if len(cells):
        print(restricted_warning(cells), file=sys.stderr)
    return len(cells)


# ----------------------------------------------------------------------------------------------
# Re-apply a saved vintage offline (EQ-A-0035). `fetch --apply` refetches, so a decision bound to the vintage (or live
# value) Sam reviewed no longer binds to the new pull. These functions work from the vintage folder alone: no network.
# ----------------------------------------------------------------------------------------------
VINTAGE_REQUIRED_FILES = ("live_inputs.csv", "live_profile.csv", "review.csv")
VINTAGE_REVIEW_REQUIRED = ("table", "key", "country", "live", "status")
PROFILE_APPLY_KEYS = ("pop", "exports", "reserves", "fx3m", "policy")       # the profile fields apply_report writes


class VintageContentError(ValueError):
    """A vintage lacks what an offline re-apply needs (live tables or the gate's review.csv), or names unknown cells."""


def latest_vintage(data_dir: Path) -> str:
    """Id of the newest vintage under data/live/vintages/ (last of list_vintages). FileNotFoundError when there is none."""
    ids = list_vintages(data_dir)
    if not ids:
        raise FileNotFoundError(f"no vintage under {_vintage_root(data_dir)}: run `econquest fetch` first")
    return ids[-1]


def _resolve_vintage(data_dir: Path, vintage_id: str | None) -> str:
    return vintage_path(data_dir, str(vintage_id)).name if vintage_id else latest_vintage(data_dir)


def _wide_from_bytes(b: bytes) -> pd.DataFrame:
    """A live_inputs/live_profile table as saved by save_vintage: first column is the string index (indicator ids such as
    '2.10' stay strings), the rest float (blank -> NaN)."""
    df = pd.read_csv(io.BytesIO(b), dtype=str, keep_default_na=False)
    df = df.set_index(df.columns[0])
    df.index = df.index.astype(str); df.index.name = None
    return df.apply(pd.to_numeric, errors="coerce").astype(float)


def load_vintage(data_dir: Path, vintage_id: str | None = None) -> tuple[str, FetchReport, pd.DataFrame]:
    """Read a saved vintage back for an offline re-apply: (vintage_id, FetchReport, review). Default: the latest vintage.
    The files are read once into memory and their content hash must equal both verify_vintage and the vintage's row
    in vintages/index.csv, so a tampered, incomplete or concurrently changed folder raises replay.VintageIntegrityError
    (a ValueError) and nothing is returned. A vintage without live_inputs.csv, live_profile.csv or review.csv (legacy
    folders, or a pull saved without a gate review) raises VintageContentError: without review.csv there is no record
    of which cells the gate held, and this function does not re-run the gate or guess.
    The FetchReport carries indicators, profile, provenance and feeds (from feeds.json); raw tables and the transform
    log are not reloaded (apply_report does not use them). The review keeps the gate columns (table, key, country,
    seed, live, status, reason, ...); the decision columns written at fetch time are dropped, because decisions are
    read from the ledger at apply time."""
    from .replay import VintageIntegrityError
    d = Path(data_dir)
    vid = _resolve_vintage(d, vintage_id)
    v = vintage_path(d, vid)
    files = {q.name: q.read_bytes() for q in v.iterdir() if q.is_file()}
    checked = verify_vintage(d, vid)
    if checked["hash"] != _content_hash(files):
        raise VintageIntegrityError(f"vintage {vid} changed while it was being read; nothing loaded")
    missing = [n for n in VINTAGE_REQUIRED_FILES if n not in files]
    if missing:
        raise VintageContentError(f"vintage {vid} has no {', '.join(missing)}: it cannot be re-applied offline "
                                  "(review.csv is the gate's list of held cells). Run `econquest fetch` for a new vintage.")
    ind = _wide_from_bytes(files["live_inputs.csv"])
    prof = _wide_from_bytes(files["live_profile.csv"])
    prof = prof.reindex(columns=list(dict.fromkeys([*prof.columns, *PROFILE_APPLY_KEYS])))
    review = pd.read_csv(io.BytesIO(files["review.csv"]), dtype=str, keep_default_na=False)
    lacking = [c for c in VINTAGE_REVIEW_REQUIRED if c not in review.columns]
    if lacking:
        raise VintageContentError(f"vintage {vid} review.csv lacks column(s) {', '.join(lacking)}")
    from .ledger import REVIEW_DECISION_COLUMNS
    review = review.drop(columns=[c for c in (*REVIEW_DECISION_COLUMNS, "vintage_id") if c in review.columns])
    for c in ("seed", "live"):
        if c in review.columns:
            review[c] = pd.to_numeric(review[c], errors="coerce")
    prov = pd.read_csv(io.BytesIO(files["provenance.csv"])) if files.get("provenance.csv", b"").strip() else pd.DataFrame()
    try:
        feeds = json.loads(files.get("feeds.json", b"{}")).get("feeds", {})
    except ValueError:
        feeds = {}
    unserved = (pd.read_csv(io.BytesIO(files["unserved.csv"])) if "unserved.csv" in files
                else pd.DataFrame(columns=UNSERVED_COLUMNS))
    return vid, FetchReport(ind, prof, prov, dict(feeds), {}, unserved=unserved), review


def _cell(c) -> tuple[str, str, str]:
    """A cell as (table, key, country) from a tuple/list or a dict with those keys."""
    if isinstance(c, dict):
        c = (c.get("table"), c.get("key"), c.get("country"))
    if not isinstance(c, (tuple, list)) or len(c) != 3 or not all(str(x or "").strip() for x in c):
        raise ValueError(f"a cell is (table, key, country), got {c!r}")
    return str(c[0]).strip(), str(c[1]).strip(), str(c[2]).strip()


def vintage_review(data_dir: Path, vintage_id: str | None = None) -> pd.DataFrame:
    """The gate review of a vintage (default: the latest) with the latest ledger decision per cell and what an
    apply_vintage would do now. Columns: vintage_id, the review's gate columns, decision, author, approver,
    self_approved, decided_utc, decision_vintage, decision_live, and `effective`:
      'apply'               gate ok, will be applied
      'released'            gate hold, released by an approved apply bound to this vintage or its live value
      'held'                gate hold, no approved decision bound to this vintage/value: stays on seed
      'held (decision)'     gate ok, but the latest ledger decision is hold/reject (or an unapproved override)
      'missing'             no live value
    Read-only: nothing is written."""
    from .ledger import effective_holds, load_decisions
    d = Path(data_dir)
    vid, _, review = load_vintage(d, vintage_id)
    dec = load_decisions(d)
    held = effective_holds(review, dec, vintage_id=vid)
    latest = {(r.table, str(r.key), r.country): r for r in dec.itertuples(index=False)} if len(dec) else {}
    out = review.copy()
    out.insert(0, "vintage_id", vid)
    extra = {k: [] for k in ("decision", "author", "approver", "self_approved", "decided_utc", "decision_vintage",
                             "decision_live", "effective")}
    for r in review.itertuples(index=False):
        cell = (r.table, str(r.key), r.country)
        dd = latest.get(cell)
        for k, src in (("decision", "decision"), ("author", "author"), ("approver", "approver"),
                       ("self_approved", "self_approved"), ("decided_utc", "ts_utc"), ("decision_vintage", "vintage_id"),
                       ("decision_live", "live")):
            extra[k].append("" if dd is None else str(getattr(dd, src, "") or ""))
        if r.status == "missing":
            eff = "missing"
        elif cell in held:
            eff = "held" if r.status == "hold" else "held (decision)"
        else:
            eff = "released" if r.status == "hold" else "apply"
        extra["effective"].append(eff)
    for k, vals in extra.items():
        out[k] = vals
    return out


def record_vintage_decisions(data_dir: Path, cells: Iterable, author: str, approver: str | None = None,
                             self_approved: bool = False, vintage_id: str | None = None, decision: str = "apply",
                             note: str = "", now: dt.datetime | None = None) -> list[dict]:
    """Record one ledger decision per cell against a saved vintage (default: the latest) and return the rows written.
    Each row carries the vintage id, the cell's live value and gate status taken from the vintage's review.csv, so an
    apply binds to exactly what was reviewed (ledger.effective_holds). `cells` are (table, key, country) tuples or dicts.
    Everything is checked before the first row is written: the vintage verifies (load_vintage), every cell is in its
    review, an apply has a live value, and when any applied cell is gate-held or carries a colleague's standing
    hold/reject, the four-eyes rule (`approver` other than `author`, or `self_approved=True`, recorded as
    self_approved=yes) exactly as ledger.check_approval. Each row is then written with ledger.record_decision, which
    re-applies the same rules; nothing is applied to indicators.csv or countries.csv (see apply_vintage)."""
    from .ledger import DECISIONS, _standing_objection, check_approval, person_key, read_ledger, record_decision
    d = Path(data_dir)
    decision = str(decision).strip().lower()
    if decision not in DECISIONS:
        raise ValueError(f"decision must be one of {DECISIONS}, got {decision!r}")
    want = list(dict.fromkeys(_cell(c) for c in (cells or [])))
    if not want:
        raise ValueError("no cells given")
    vid, _, review = load_vintage(d, vintage_id)
    rows = {(r.table, str(r.key), r.country): r for r in review.itertuples(index=False)}
    unknown = [c for c in want if c not in rows]
    if unknown:
        raise VintageContentError(f"not in the review of vintage {vid}: {unknown}; nothing recorded")
    live = {c: (float(rows[c].live) if np.isfinite(rows[c].live) else None) for c in want}
    if decision == "apply":
        no_live = [c for c in want if live[c] is None]
        if no_live:
            raise VintageContentError(f"no live value in vintage {vid} for {no_live}; nothing recorded")
        led = read_ledger(d)
        objected = []
        for c in want:
            h = led[(led["table"] == c[0]) & (led["key"] == c[1]) & (led["country"] == c[2])]
            who = _standing_objection(h.itertuples(index=False))
            if who and person_key(who) != person_key(author):
                objected.append(c)
        if any(rows[c].status == "hold" for c in want) or objected:
            try:
                check_approval(author, approver, self_approved)
            except ValueError as e:
                raise ValueError(f"applying held cell(s) of vintage {vid}: {e}; nothing recorded") from None
    out = []
    for c in want:
        out.append(record_decision(d, c[0], c[1], c[2], decision, author, approver=approver, note=note, vintage_id=vid,
                                   live=live[c], gate_status=str(rows[c].status), now=now, self_approved=self_approved))
    return out


class OlderVintageError(VintageContentError):
    """apply_vintage was asked to apply a vintage that is not the latest without allow_older=True (SEC-A-004 L2)."""


def _check_not_older(d: Path, vid: str, allow_older: bool) -> str:
    """The latest vintage id; raises OlderVintageError when `vid` is older and allow_older is False."""
    latest = latest_vintage(d)
    if vid != latest and not allow_older:
        raise OlderVintageError(f"vintage {vid} is not the latest ({latest}): applying it would put its ok cells back over "
                                "newer values (a rollback). Pass allow_older=True (CLI --allow-older) to do it anyway; "
                                "nothing recorded or applied")
    return latest


def apply_vintage(data_dir: Path, vintage_id: str | None = None, author: str | None = None, approver: str | None = None,
                  self_approved: bool = False, cells: Iterable | None = None, note: str = "",
                  now: dt.datetime | None = None, allow_older: bool = False) -> dict:
    """Apply a saved vintage (default: the latest) to indicators.csv and countries.csv offline, without refetching.
    Every refusal is checked before anything is written (SEC-A-004 L3): the vintage resolves, is the latest unless
    allow_older=True (else OlderVintageError, SEC-A-004 L2), verifies against vintages/index.csv (load_vintage), has
    review.csv and at least one successful feed, and with `cells` an author is given. Only then, with `cells`, an
    apply decision is recorded for each of them against this vintage (record_vintage_decisions with author / approver
    / self_approved / note; four-eyes as ledger.check_approval, which writes nothing when it refuses). The vintage is
    then loaded and verified again and passed to apply_report(report, review=<vintage review>, vintage_id=<id>,
    force=False): the gate's ok cells are applied, a gate-held cell only when its latest ledger decision is an approved
    apply bound to this vintage or this live value, and a cell whose latest decision is hold/reject never. Same
    pre-apply snapshot, atomic writes and inputs_snapshot (replay.freeze_inputs) as `fetch --apply`. Never forces.
    Re-applying an older vintage (allow_older=True) puts its ok cells back over newer values: that rollback is recorded
    as rollback.json in the pre-apply snapshot folder (before the data files change) and returned as "rollback"
    ({vintage_id, latest_vintage, allow_older, author, note, ts_utc, record}); it is None when vintage_id is the latest.
    Returns apply_report's dict plus vintage_id, latest_vintage, rollback, released (gate-held cells applied),
    still_held (gate-held cells left on seed) and decisions_recorded."""
    from .ledger import _ts, effective_holds, load_decisions
    d = Path(data_dir)
    vid = _resolve_vintage(d, vintage_id)
    _check_not_older(d, vid, allow_older)
    if cells and not _has_person(author):
        raise ValueError("apply_vintage(cells=...) records an apply decision per cell: author is required")
    vid, rep, review = load_vintage(d, vid)
    # SEC-A-006 L5: an empty feeds.json ({} or {"feeds": {}}) or one without a `feeds` key counts as "no feed succeeded"
    if not any(str(v).startswith("ok") for v in (rep.feeds if isinstance(rep.feeds, dict) else {}).values()):
        raise VintageContentError(f"vintage {vid}: no feed succeeded ({rep.feeds or 'no feeds listed'}); "
                                  "nothing recorded or applied")
    recorded = []
    if cells:
        recorded = record_vintage_decisions(d, cells, author, approver=approver, self_approved=self_approved,
                                            vintage_id=vid, note=note, now=now)
    vid, rep, review = load_vintage(d, vid)            # verified again: the folder must not change between the steps
    latest = _check_not_older(d, vid, allow_older)     # a fetch that finished meanwhile makes this vintage older
    rollback = None
    if vid != latest:
        rollback = {"vintage_id": vid, "latest_vintage": latest, "allow_older": True, "author": str(author or ""),
                    "note": note, "ts_utc": _ts(now),
                    "what": "older vintage re-applied: its ok cells overwrite values applied from newer vintages"}
    held_by_gate = {(r.table, str(r.key), r.country) for r in review.itertuples(index=False)
                    if r.status == "hold" and np.isfinite(r.live)}
    still = effective_holds(review, load_decisions(d), vintage_id=vid)
    res = apply_report(rep, d, review=review, force=False, now=now, vintage_id=vid, rollback=rollback)
    res.update({"vintage_id": vid, "latest_vintage": latest, "rollback": res.get("rollback"),
                "released": sorted(held_by_gate - still), "still_held": sorted(held_by_gate & still),
                "decisions_recorded": len(recorded)})
    return res


def _has_person(name) -> bool:
    from .ledger import person_key
    return bool(person_key(name))
