"""Recalibration of the layer-1 hazard model on a real sovereign default panel (roadmap item 2.3).

Pieces:
* default events: `load_default_events` reads data/panel/sovereign_defaults.csv (episode table, one row per
  default spell with start and end year); `load_crag` takes the Bank of Canada-Bank of England sovereign default
  database (CRAG; 2026 long layout or older wide layout, file or DataFrame) through Team A's
  `ingestion.default_panel.import_crag`, which derives spells as the years a country has a positive amount in
  default on foreign-currency bank loans, bonds or local-currency debt and maps proper ISO3 codes; `load_events`
  dispatches between the two for fit-hazard --defaults.
* predictor history: `panel_from_long` turns tidy long tables (iso, series, period, value) from the IMF WEO
  and the World Bank into a country-year table of the hazard features; `fetch_weo_history` and
  `fetch_worldbank_history` pull every economy from the APIs (run on a machine that can reach them).
* label: event = 1 when a default spell starts in year t+1 and the country is not in default in year t
  (12-month-ahead hazard); country-years inside a spell are not at risk and are dropped. Predictors for row t
  are year t-1 values by default (`lag`), point-in-time when the history carries a `vintage` column.
* `fit_and_validate`: Firth logit on standardized features, rolling-origin out-of-sample test (fit on years
  before T, score year T), AUC, Brier score, log loss against the training-window base rate, calibration by
  equal-count bins (deciles when there are enough test rows), and the
  coefficient table with standard errors. `write_report` renders it as Markdown; `fitted_block` gives the
  assumptions.json entry the engine reads when layer1.mode is "fitted".
"""
from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
import numpy as np
import pandas as pd

from ..engine.common import expit
from ..engine.layer1_hazard import fit_firth

# feature -> (source table, series code, transform) ; the same names are produced today by layer1_hazard.build_features
PANEL_FEATURES: dict[str, tuple[str, str, str]] = {
    "debt_gdp": ("weo", "GGXWDG_NGDP", "level"),
    "primary_deficit": ("weo", "GGXONLB_NGDP", "negate"),
    "current_account": ("weo", "BCA_NGDPD", "level"),
    "real_growth": ("weo", "NGDP_RPCH", "level"),
    "inflation_log": ("weo", "PCPIPCH", "log1p_pct"),
    "stfx_debt_reserves": ("worldbank", "DT.DOD.DSTC.IR.ZS", "level"),
    "reserves_months_imports": ("worldbank", "FI.RES.TOTL.MO", "level"),
    "pitf_instability": ("worldbank", "PV.EST", "wgi_to_pitf"),
}
WEO_CODES = ["GGXWDG_NGDP", "GGXONLB_NGDP", "BCA_NGDPD", "NGDP_RPCH", "PCPIPCH"]
WB_CODES = ["DT.DOD.DSTC.IR.ZS", "FI.RES.TOTL.MO", "PV.EST"]
DEFAULT_FEATURES = ["debt_gdp", "primary_deficit", "current_account", "real_growth", "inflation_log"]
AGGREGATES = {"WLD", "EMU", "EUQ", "EUR", "EAS", "ECS", "LCN", "MEA", "NAC", "SAS", "SSF", "HIC", "LIC", "LMC", "UMC", "MIC",
              "OED", "ARB", "CEB", "EAP", "ECA", "LAC", "MNA", "SSA", "IBD", "IBT", "IDA", "IDB", "IDX", "LDC", "LMY", "PRE",
              "PST", "FCS", "HPC", "OSS", "SST", "TEA", "TEC", "TLA", "TMN", "TSA", "TSS", "AFE", "AFW", "EAR", "LTE", "INX"}


def _transform(v: pd.Series, how: str) -> pd.Series:
    if how == "negate":
        return -v
    if how == "log1p_pct":
        return 100.0 * np.log1p(v.clip(lower=-95.0) / 100.0)
    if how == "wgi_to_pitf":
        return ((2.5 - v) / 1.25).clip(0.0, 4.0)
    return v


def transform_today(feature: str, raw: float) -> float:
    """Apply the panel transform to a single current value (used by build_features at prediction time)."""
    how = PANEL_FEATURES.get(feature, ("", "", "level"))[2]
    return float(_transform(pd.Series([raw], dtype=float), how).iloc[0])


# ---------------------------------------------------------------- default events

def _events_frame(df: pd.DataFrame, what: str = "default events", iso3: bool = False) -> pd.DataFrame:
    need = {"iso", "start", "end"}
    if not need.issubset(df.columns):
        raise ValueError(f"{what} needs columns {sorted(need)}, found {list(df.columns)}")
    df = df.copy()
    df["iso"] = df["iso"].astype(str).str.upper().str.strip()
    bad = df[~df["iso"].str.fullmatch(r"[A-Z]{3}")] if iso3 else df.iloc[:0]
    if len(bad):
        raise ValueError(f"{what}: iso must be ISO3 codes; got {sorted(bad['iso'].unique())[:5]}")
    df["start"] = df["start"].astype(int)
    df["end"] = df["end"].astype(int)
    return df.sort_values(["iso", "start"]).reset_index(drop=True)


def load_default_events(path: str | Path) -> pd.DataFrame:
    """Episode table with columns iso, start, end (inclusive years); extra columns are kept (e.g. the
    source / source_vintage columns written by ingestion.default_panel.import_crag)."""
    return _events_frame(pd.read_csv(path, comment="#"))


def _is_episode_table(path: Path) -> bool:
    if path.suffix.lower() not in (".csv", ".txt"):
        return False
    try:
        cols = {str(c).strip().lower() for c in pd.read_csv(path, comment="#", nrows=0).columns}
    except (ValueError, OSError, pd.errors.ParserError):
        return False
    return {"iso", "start", "end"}.issubset(cols)


def load_crag(src: str | Path | pd.DataFrame, *, source_label: str | None = None, vintage: str | None = None,
              out_csv: str | Path | None = None, iso_map: dict[str, str] | None = None,
              iso_map_csv: str | Path | None = None, **import_kw) -> pd.DataFrame:
    """Default spells from the Bank of Canada-Bank of England database (CRAG) through Team A's importer (EQ-B-0015).

    `src` is either
    * an episode table already converted by `ingestion.default_panel.import_crag` (CSV path or DataFrame with
      iso, start, end and usually source, source_vintage): it is validated and returned as is; or
    * a raw CRAG file: the 2026 long layout (one row per country-year, creditor-category columns; the xlsx or the
      Valet DEBT_2026 CSV) or the older wide layout (years as columns), or a DataFrame of either with its header as
      columns. It is converted by `import_crag`, which keeps the scope rule (foreign-currency bank loans and bonds
      plus local-currency debt; official creditors excluded) and maps ISO3 from the file's ISO column or by name
      through countries.csv, the episode list, `iso_map_csv` and `iso_map`. Unmapped names raise, listing them all;
      no code is ever guessed from the name (the old `name[:3]` mapping is gone).

    `out_csv` keeps the converted episode file (default: a temporary file that is removed). `import_kw` passes
    sheet, country_col, year_col, iso_col, category_col, category_map, min_amount or start_year to import_crag."""
    import tempfile
    from ..ingestion.default_panel import import_crag
    if isinstance(src, pd.DataFrame) and {"iso", "start", "end"}.issubset(src.columns):
        return _events_frame(src, "CRAG episode table", iso3=True)
    if not isinstance(src, pd.DataFrame) and _is_episode_table(Path(src)):
        return _events_frame(pd.read_csv(src, comment="#"), f"CRAG episode table {Path(src).name}", iso3=True)
    with tempfile.TemporaryDirectory() as tmp:
        if isinstance(src, pd.DataFrame):
            raw = Path(tmp) / "crag_input.csv"
            src.to_csv(raw, index=False)
            name = "DataFrame"
        else:
            raw = Path(src)
            name = raw.name
        target = Path(out_csv) if out_csv else Path(tmp) / "crag_episodes.csv"
        try:
            import_crag(raw, target, source_label or f"CRAG file {name}", vintage or "not stated (hazard_panel.load_crag)",
                        iso_map=iso_map, iso_map_csv=iso_map_csv, **import_kw)
        except ValueError as e:
            tpl = target.with_name(target.stem + "_unmapped.csv")
            if "no ISO3 code" in str(e) and tpl.exists():
                names = pd.read_csv(tpl)["country"].tolist()
                raise ValueError(f"CRAG country names without an ISO3 code: {names}. Add them to iso_map_csv "
                                 "(country,iso; e.g. data/panel/crag_iso_map.csv) or pass iso_map=.") from e
            raise
        return _events_frame(pd.read_csv(target), "import_crag output", iso3=True)


def load_events(path: str | Path, **crag_kw) -> pd.DataFrame:
    """Default episodes for fit-hazard --defaults: an episode CSV (sovereign_defaults.csv schema, including the
    import_crag output) is read directly; anything else (CRAG xlsx, Valet CSV) goes through `load_crag`."""
    p = Path(path)
    return load_default_events(p) if _is_episode_table(p) else load_crag(p, **crag_kw)


def load_crag_workbook(path: str | Path, iso_map: dict[str, str] | None = None, private_only: bool = True) -> pd.DataFrame:
    """Deprecated (EQ-B-0015): kept for callers of the old name; now `load_crag(path, iso_map=iso_map)`.

    The old parser read only the wide layout and mapped ISO by `name[:3]`; the 2026 edition is long. Scope is
    import_crag's rule (private creditors and local-currency debt), so `private_only=False` is refused."""
    if not private_only:
        raise ValueError("private_only=False is not supported: CRAG scope is import_crag's (FC bank loans, FC bonds, LC debt)")
    return load_crag(path, iso_map=iso_map)


def default_status(events: pd.DataFrame, years: range) -> pd.DataFrame:
    """Country-year table: in_default (inside a spell), starts (a spell starts this year)."""
    rows = []
    for iso, g in events.groupby("iso"):
        spells = list(zip(g["start"], g["end"]))
        for y in years:
            rows.append({"iso": iso, "year": y,
                         "in_default": any(s <= y <= e for s, e in spells),
                         "starts": any(s == y for s, _ in spells)})
    return pd.DataFrame(rows, columns=["iso", "year", "in_default", "starts"])


# ---------------------------------------------------------------- predictor history

def fetch_weo_history(version=None, codes: list[str] | None = None) -> pd.DataFrame:
    """Every economy's WEO history through imf-reader (needs api.imf.org)."""
    from imf_reader import weo as imf_weo
    df = imf_weo.fetch_data(version=version)
    codes = codes or WEO_CODES
    sub = df[df["CONCEPT_CODE"].isin(codes)]
    out = pd.DataFrame({"iso": sub["REF_AREA_CODE"].astype(str), "series": sub["CONCEPT_CODE"].astype(str),
                        "period": pd.to_numeric(sub["TIME_PERIOD"], errors="coerce"), "value": pd.to_numeric(sub["OBS_VALUE"], errors="coerce")})
    out = out.dropna(subset=["period", "value"])
    out["period"] = out["period"].astype(int)
    out["source"] = f"imf-reader WEO {version or 'latest'}"
    return out[out["iso"].str.len() == 3].reset_index(drop=True)


def fetch_worldbank_history(codes: list[str] | None = None, start: int = 1980, end: int | None = None, as_of=None) -> pd.DataFrame:
    """Every economy's World Bank history (IDS, WDI, WGI) through wbgapi (needs api.worldbank.org). `end` defaults
    to the year of `as_of` (VF-006), else the current year."""
    import wbgapi as wb
    codes = codes or WB_CODES
    end = end or _as_of_year(as_of)
    rows = []
    for code in codes:
        try:
            df = wb.data.DataFrame(code, time=range(start, end + 1), labels=False, skipAggs=True, numericTimeKeys=True)
        except Exception as e:  # noqa: BLE001 - one series failing should not sink the panel
            print(f"world bank {code}: {type(e).__name__}: {str(e)[:120]}")
            continue
        for iso, r in df.iterrows():
            for y, v in r.items():
                if pd.notna(v):
                    rows.append({"iso": str(iso), "series": code, "period": int(y), "value": float(v), "source": "wbgapi"})
    return pd.DataFrame(rows, columns=["iso", "series", "period", "value", "source"])


def _vintage_year(v: pd.Series) -> pd.Series:
    """Publication year of a vintage column given as a year (2019) or a date ('2019-04-15', '2019-04')."""
    num = pd.to_numeric(v, errors="coerce")
    if num.notna().all() and (num.between(1900, 2200)).all():
        return num.astype(int)
    return pd.to_datetime(v.astype(str), errors="coerce").dt.year


def _vintage_date(v: pd.Series) -> pd.Series:
    """Release date of a vintage ('2019-10', '2019-04-15', or a bare year read as 1 January) for ordering."""
    num = pd.to_numeric(v, errors="coerce")
    if num.notna().all() and (num.between(1900, 2200)).all():
        return pd.to_datetime(num.astype(int).astype(str) + "-01-01")
    return pd.to_datetime(v.astype(str), errors="coerce", format="mixed")


def _as_of_year(as_of=None) -> int:
    """Calendar year of the model date `as_of` (YYYY-MM-DD); the wall clock only when no as_of is given."""
    return int(pd.Timestamp(as_of).year) if as_of is not None else int(pd.Timestamp.now().year)


def panel_from_long(weo: pd.DataFrame, worldbank: pd.DataFrame | None, events: pd.DataFrame, features: list[str] | None = None,
                    start: int = 1980, end: int | None = None, forecast_cutoff: int | None = None, lag: int = 1,
                    pre_first_release: str = "earliest", as_of=None) -> pd.DataFrame:
    """Country-year panel with the chosen features and the 12-month-ahead default label.

    Row (iso, t) predicts a spell starting in t+1 from information available at the end of year t (EQ-B-0006,
    GOV-006): the predictors are the values for year t - `lag` (default 1: year-t outturns are not published until
    the April WEO of t+1, after part of the prediction window). When the long table has a `vintage` column
    (publication year or date) the value is point-in-time: the latest vintage published in or before year t, so
    later revisions cannot leak in. Without it the values are the latest vintage, which still embeds revisions
    (noted in `attrs["point_in_time"]`). `lag=0` reproduces the old contemporaneous alignment (look-ahead).
    Among vintages of the same year the later release wins (October over April), by a stable sort on the full
    vintage date (HO-20261023-A-B-007).

    Rows for years before a series' first release (WEO history reaches back to 2007-10 only): with
    `pre_first_release="earliest"` (default) they take the earliest release, which embeds revisions for those
    years, and `attrs["pit_from"]` is the first year from which every row is point-in-time; the hazard-fit report
    labels earlier rows "partial-pre-<first release>". `"drop"` removes them (the panel then starts at the first
    release year and loses most 1980s-1990s defaults).

    `forecast_cutoff` drops WEO rows for periods after that year (projections are not outcomes); it defaults to
    the last year with a default label (end). Rows missing any feature are dropped; rows inside a default spell
    are dropped (not at risk); the label is 1 when a spell starts the following year."""
    if lag < 0:
        raise ValueError("lag must be >= 0")
    features = features or DEFAULT_FEATURES
    end = end or (_as_of_year(as_of) - 1)          # VF-006: last labelled row from the model date, not the clock
    forecast_cutoff = forecast_cutoff or end
    src = {"weo": weo, "worldbank": worldbank if worldbank is not None else pd.DataFrame(columns=["iso", "series", "period", "value"])}
    cols = {}
    pit = {}
    first_release: dict[str, int | None] = {}
    for f in features:
        tab, code, how = PANEL_FEATURES[f]
        t = src[tab]
        s = t[(t["series"] == code) & (t["period"] >= start - lag) & (t["period"] <= forecast_cutoff)]
        s = s[~s["iso"].isin(AGGREGATES)].copy()
        s["year"] = s["period"].astype(int) + lag             # the row whose prediction may use this observation
        if "vintage" in s.columns:
            s["_vy"] = _vintage_year(s["vintage"])
            s["_vd"] = _vintage_date(s["vintage"])
            s = s[s["_vy"].notna()].sort_values("_vd", kind="stable")
            first = int(s["_vy"].min()) if len(s) else None
            ok = s[s["_vy"] <= s["year"]]                       # only vintages published by the end of year t
            ok = ok.drop_duplicates(["iso", "year"], keep="last")   # the latest of those (October over April)
            if pre_first_release == "earliest" and first is not None:
                pre = s[s["year"] < first].drop_duplicates(["iso", "year"], keep="first")
                ok = pd.concat([ok, pre[~pre.set_index(["iso", "year"]).index.isin(ok.set_index(["iso", "year"]).index)]])
            elif pre_first_release != "drop":
                raise ValueError("pre_first_release must be 'earliest' or 'drop'")
            s = ok
            first_release[f] = first
            pit[f] = True
        else:
            pit[f] = False
        piv = s.pivot_table(index=["iso", "year"], values="value", aggfunc="first")["value"]
        cols[f] = _transform(piv.astype(float), how)
    X = pd.DataFrame(cols).reset_index()
    X = X[(X["year"] >= start) & (X["year"] <= end)]
    st = default_status(events, range(start, end + 2))
    nxt = st.rename(columns={"year": "year_next", "starts": "event"})[["iso", "year_next", "event"]]
    nxt["year"] = nxt["year_next"] - 1
    df = X.merge(st[["iso", "year", "in_default"]], on=["iso", "year"], how="left").merge(nxt[["iso", "year", "event"]], on=["iso", "year"], how="left")
    df["in_default"] = df["in_default"].eq(True)
    df["event"] = df["event"].eq(True).astype(int)
    df = df[~df["in_default"]].dropna(subset=features)
    df["ever_defaulted"] = df["iso"].isin(set(events["iso"]))
    out = df.sort_values(["iso", "year"]).reset_index(drop=True)[["iso", "year", *features, "event", "ever_defaulted"]]
    out.attrs["predictor_lag"] = int(lag)
    known = [v for v in first_release.values() if v is not None]
    out.attrs["pit_from"] = (max(known) if known and pre_first_release == "earliest" else None)
    out.attrs["pre_first_release"] = pre_first_release
    out.attrs["point_in_time"] = ("all features" if all(pit.values()) else
                                  "none: latest-vintage values (revisions look-ahead remains)" if not any(pit.values()) else
                                  "partial: " + ", ".join(f for f, v in pit.items() if v))
    return out


# ---------------------------------------------------------------- fitting and validation

def auc(y: np.ndarray, p: np.ndarray) -> float:
    y = np.asarray(y, dtype=float); p = np.asarray(p, dtype=float)
    pos = p[y == 1]; neg = p[y == 0]
    if len(pos) == 0 or len(neg) == 0:
        return float("nan")
    # Mann-Whitney statistic with ties counted half
    s = pd.Series(np.concatenate([pos, neg])).rank(method="average").to_numpy()
    r_pos = s[: len(pos)].sum()
    return float((r_pos - len(pos) * (len(pos) + 1) / 2) / (len(pos) * len(neg)))


def brier(y, p) -> float:
    y = np.asarray(y, dtype=float); p = np.asarray(p, dtype=float)
    return float(np.mean((p - y) ** 2))


def log_loss(y, p) -> float:
    y = np.asarray(y, dtype=float); p = np.clip(np.asarray(p, dtype=float), 1e-6, 1 - 1e-6)
    return float(-np.mean(y * np.log(p) + (1 - y) * np.log(1 - p)))


@dataclass
class FitResult:
    features: list[str]
    coef: dict[str, float]
    intercept: float
    scale: dict[str, tuple[float, float]]
    se: dict[str, float]
    n: int
    events: int
    countries: int
    years: tuple[int, int]
    in_sample: dict
    out_of_sample: dict
    calibration: pd.DataFrame
    oos_by_year: pd.DataFrame
    panel_source: dict = field(default_factory=dict)
    predictor_lag: int | None = None          # years between the predictor values and the row's year t (None: unknown)

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        z = np.column_stack([(X[f].to_numpy(dtype=float) - self.scale[f][0]) / self.scale[f][1] for f in self.features])
        return expit(self.intercept + z @ np.array([self.coef[f] for f in self.features]))

    def fitted_block(self) -> dict:
        return {"features": self.features, "coef": self.coef, "intercept": self.intercept,
                "scale": {f: list(v) for f, v in self.scale.items()}, "standard_errors": self.se,
                "panel": {"n": self.n, "events": self.events, "countries": self.countries, "years": list(self.years), **self.panel_source},
                **({"predictor_lag": int(self.predictor_lag)} if self.predictor_lag is not None else {}),   # omitted when unknown, never null
                "in_sample": self.in_sample, "out_of_sample": self.out_of_sample, "fitted_on": pd.Timestamp.now().strftime("%Y-%m-%d")}


def _standardize(panel: pd.DataFrame, features: list[str]) -> tuple[np.ndarray, dict[str, tuple[float, float]]]:
    scale = {}
    cols = []
    for f in features:
        v = panel[f].to_numpy(dtype=float)
        m, s = float(np.mean(v)), float(np.std(v, ddof=1))
        s = s if s > 0 else 1.0
        scale[f] = (m, s)
        cols.append((v - m) / s)
    return np.column_stack(cols), scale


def _fit(panel: pd.DataFrame, features: list[str]):
    Z, scale = _standardize(panel, features)
    y = panel["event"].to_numpy(dtype=float)
    b, info = fit_firth(Z, y)
    return b, info, scale


def fit_and_validate(panel: pd.DataFrame, features: list[str] | None = None, oos_start: int | None = None, min_train_events: int = 5) -> FitResult:
    features = features or [f for f in DEFAULT_FEATURES if f in panel.columns]
    meta = dict(panel.attrs)                                  # predictor_lag / point_in_time from panel_from_long
    panel = panel.dropna(subset=features).reset_index(drop=True)
    y = panel["event"].to_numpy(dtype=float)
    b, info, scale = _fit(panel, features)
    coef = {f: float(b[i + 1]) for i, f in enumerate(features)}
    se = {"intercept": float(info["se"][0]), **{f: float(info["se"][i + 1]) for i, f in enumerate(features)}}
    res = FitResult(features, coef, float(b[0]), scale, se, int(len(panel)), int(y.sum()), int(panel["iso"].nunique()),
                    (int(panel["year"].min()), int(panel["year"].max())), {}, {}, pd.DataFrame(), pd.DataFrame(),
                    predictor_lag=meta.get("predictor_lag"))
    p_in = res.predict(panel)
    base = float(y.mean())
    res.in_sample = {"auc": auc(y, p_in), "brier": brier(y, p_in), "brier_base_rate": brier(y, np.full_like(y, base)),
                     "log_loss": log_loss(y, p_in), "log_loss_base_rate": log_loss(y, np.full_like(y, base)), "base_rate": base}
    # rolling-origin out of sample
    years = sorted(panel["year"].unique())
    oos_start = oos_start or years[len(years) // 2]
    preds = []
    for T in [yy for yy in years if yy >= oos_start]:
        train = panel[panel["year"] < T]
        test = panel[panel["year"] == T]
        if train["event"].sum() < min_train_events or test.empty:
            continue
        bT, _, scT = _fit(train, features)
        zT = np.column_stack([(test[f].to_numpy(dtype=float) - scT[f][0]) / scT[f][1] for f in features])
        pT = expit(bT[0] + zT @ bT[1:])
        # the benchmark forecaster only knows the training window's event rate, never the test year's (EQ-B-0006)
        base_T = float(train["event"].mean())
        preds.append(pd.DataFrame({"iso": test["iso"].to_numpy(), "year": T, "event": test["event"].to_numpy(), "p": pT, "p_base": base_T}))
    if preds:
        oos = pd.concat(preds, ignore_index=True)
        yo, po, pb = oos["event"].to_numpy(dtype=float), oos["p"].to_numpy(dtype=float), oos["p_base"].to_numpy(dtype=float)
        res.out_of_sample = {"auc": auc(yo, po), "brier": brier(yo, po), "brier_base_rate": brier(yo, pb),
                             "log_loss": log_loss(yo, po), "log_loss_base_rate": log_loss(yo, pb),
                             "base_rate": "training-window event rate per origin", "n": int(len(oos)), "events": int(yo.sum()),
                             "first_year": int(oos["year"].min()), "last_year": int(oos["year"].max()),
                             "predictor_lag": meta.get("predictor_lag"), "point_in_time": meta.get("point_in_time"),
                             "pit_from": meta.get("pit_from")}
        res.oos_by_year = oos.groupby("year").agg(n=("p", "size"), events=("event", "sum"), mean_p=("p", "mean"), base_p=("p_base", "first")).reset_index()
        # calibration by equal-count bins of predicted probability (out of sample): deciles when there are at least
        # 300 test rows, fewer bins otherwise, and the column says "bin" so the table never claims deciles it lacks
        n_bins = min(10, max(2, len(oos) // 30))
        q = pd.qcut(oos["p"].rank(method="first"), n_bins, labels=False)
        cal = oos.groupby(q).agg(n=("p", "size"), predicted=("p", "mean"), observed=("event", "mean"), events=("event", "sum")).reset_index(drop=True)
        cal.index.name = "bin"
        res.calibration = cal.reset_index()
        res.calibration["bin"] += 1
        res.calibration.attrs["n_bins"] = n_bins
    return res


def calibration_label(n_bins: int) -> str:
    return {10: "decile", 5: "quintile", 4: "quartile"}.get(int(n_bins), f"{int(n_bins)}-quantile bin")


# ---------------------------------------------------------------- the fitted-mode gate (EQ-B-0020, Story 5)

GATE_MIN_AUC = 0.75      # out-of-sample AUC (ticket EQ-B-0020; the literature's "good" threshold, see write_report)
GATE_MIN_EVENTS = 30     # default starts in the panel


def gate_check(res: FitResult, min_auc: float = GATE_MIN_AUC, min_events: int = GATE_MIN_EVENTS) -> dict:
    """Whether a fit may switch layer1.mode to "fitted": OOS AUC >= min_auc, panel events >= min_events and an
    out-of-sample Brier score strictly below the trailing (training-window) base-rate benchmark. Every check is
    reported with its figure, so a failing gate says by how much."""
    o = res.out_of_sample or {}
    auc_v, br, br0 = o.get("auc"), o.get("brier"), o.get("brier_base_rate")
    checks = {
        "oos_auc": {"value": auc_v, "threshold": min_auc, "rule": ">=",
                    "pass": bool(auc_v is not None and np.isfinite(auc_v) and auc_v >= min_auc)},
        "events": {"value": int(res.events), "threshold": int(min_events), "rule": ">=", "pass": bool(res.events >= min_events)},
        "oos_brier_vs_trailing_base": {"value": br, "threshold": br0, "rule": "<",
                                       "pass": bool(br is not None and br0 is not None and br < br0)},
    }
    return {"cleared": bool(o) and all(c["pass"] for c in checks.values()), "checks": checks,
            "oos_events": o.get("events"), "oos_n": o.get("n"), "predictor_lag": o.get("predictor_lag", res.predictor_lag),
            "base_rate": o.get("base_rate")}


def gate_summary(g: dict) -> str:
    def fmt(v):
        return "n/a" if v is None else (f"{v:.4f}" if isinstance(v, float) else str(v))
    parts = [f"{k} {fmt(c['value'])} {c['rule']} {fmt(c['threshold'])}: {'pass' if c['pass'] else 'FAIL'}" for k, c in g["checks"].items()]
    return ("CLEARED" if g["cleared"] else "NOT CLEARED") + " (" + "; ".join(parts) + ")"


def refit(weo: pd.DataFrame, worldbank: pd.DataFrame | None, events: pd.DataFrame, features: list[str] | None = None,
          start: int = 1980, end: int | None = None, oos_start: int | None = None, lag: int = 1,
          min_auc: float = GATE_MIN_AUC, min_events: int = GATE_MIN_EVENTS) -> tuple[pd.DataFrame, FitResult, dict]:
    """Build the panel (lag `lag`, point-in-time when vintaged), fit, validate and gate in one step.

    `end` is the last row year t that can be labelled: its label needs year t+1 default data, so it defaults to
    the last year the episode table covers minus one (max of start/end), never the wall clock."""
    features = features or list(DEFAULT_FEATURES)
    if end is None:
        end = int(max(events["end"].max(), events["start"].max())) - 1
    panel = panel_from_long(weo, worldbank, events, features=features, start=start, end=end, forecast_cutoff=end, lag=lag)
    res = fit_and_validate(panel, features=features, oos_start=oos_start)
    res.panel_source = {**res.panel_source, "label_years": f"{start}-{end} (row t labelled by a default start in t+1; last label year {end + 1})"}
    return panel, res, gate_check(res, min_auc, min_events)


def refit_from_files(data_dir: str | Path, out_dir: str | Path, defaults: str | Path | None = None, features: list[str] | None = None,
                     start: int = 1980, end: int | None = None, oos_start: int | None = None, lag: int = 1,
                     report_name: str | None = None, as_of: str | None = None) -> dict:
    """End-to-end refit from the files on disk, writing only under `out_dir` (never assumptions.json or docs/).

    Reads the episodes (`defaults`, default data/panel/sovereign_defaults.csv; CRAG files through `load_events`),
    the WEO history (data/panel/weo_history.csv, else data/live/raw_weo.csv) and, if present,
    data/panel/worldbank_history.csv. Writes the lag-`lag` panel CSV, the fitted block with the gate (JSON) and
    the report (Markdown). Returns paths, gate and headline figures."""
    import json
    data, out = Path(data_dir), Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    dfile = Path(defaults) if defaults else data / "panel" / "sovereign_defaults.csv"
    events = load_events(dfile)
    weo_path = data / "panel" / "weo_history.csv"
    weo_path = weo_path if weo_path.exists() else data / "live" / "raw_weo.csv"
    if not weo_path.exists():
        raise FileNotFoundError("no WEO history: data/panel/weo_history.csv or data/live/raw_weo.csv")
    weo = pd.read_csv(weo_path, dtype={"iso": str, "series": str})
    wb_path = data / "panel" / "worldbank_history.csv"
    wbh = pd.read_csv(wb_path, dtype={"iso": str, "series": str}) if wb_path.exists() else None
    panel, res, gate = refit(weo, wbh, events, features=features, start=start, end=end, oos_start=oos_start, lag=lag)
    res.panel_source = {"default_episodes": f"{dfile.name} ({len(events)} spells, {events['iso'].nunique()} countries)",
                        "weo_history": f"{weo_path.name} ({weo['iso'].nunique()} economies, {int(weo['period'].min())}-{int(weo['period'].max())})",
                        "worldbank_history": f"{wb_path.name} ({wbh['iso'].nunique()} economies)" if wbh is not None else "none (World Bank features not available)",
                        **res.panel_source}
    stamp = as_of or pd.Timestamp.now().strftime("%Y-%m-%d")
    panel_csv = out / f"hazard_panel_lag{lag}.csv"
    panel.to_csv(panel_csv, index=False)
    block = {**res.fitted_block(), "gate": gate}
    js = out / "hazard_fit_refit.json"
    js.write_text(json.dumps(block, indent=2, default=float))
    notes = [f"Gate: {gate_summary(gate)}."]
    if panel["iso"].nunique() < 40:
        notes.append(f"Pilot panel: {panel['iso'].nunique()} countries with WEO history. The production refit needs every economy's WEO "
                     "history and vintages (Team A EQ-A-0015/0016, live fetch on Sam's Mac); these figures do not support a fitted switch.")
    rep = write_report(res, out / (report_name or f"hazard-fit-report-refit-{stamp}.md"), panel=panel, notes=notes, gate=gate,
                       generator="econquest.validation.hazard_panel.refit_from_files")
    return {"report": str(rep), "fitted_block": str(js), "panel": str(panel_csv), "gate": gate,
            "n": res.n, "events": res.events, "countries": res.countries, "years": res.years,
            "in_sample": res.in_sample, "out_of_sample": res.out_of_sample}


def write_report(res: FitResult, path: str | Path, panel: pd.DataFrame | None = None, notes: list[str] | None = None,
                 gate: dict | None = None, generator: str = "econquest fit-hazard") -> Path:
    p = Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    L = []
    L.append(f"# Hazard model recalibration report\n\nGenerated {pd.Timestamp.now().strftime('%Y-%m-%d %H:%M')} by `{generator}`.\n")
    L.append("## Panel\n")
    L.append(f"- Country-years at risk: {res.n:,}; default starts (12-month-ahead events): {res.events}; countries: {res.countries}; years {res.years[0]}-{res.years[1]}.")
    for k, v in res.panel_source.items():
        L.append(f"- {k}: {v}")
    if panel is not None and "ever_defaulted" in panel:
        ev = panel[panel["event"] == 1][["iso", "year"]]
        lag_txt = f"predictors from year t-{res.predictor_lag}" if res.predictor_lag else "predictors from year t"
        L.append(f"- Event rows (country, row year t; {lag_txt}; default starts in t+1): " + ", ".join(f"{i} {y}" for i, y in ev.itertuples(index=False)))
    L.append("\n## Coefficients (Firth penalized logit on standardized predictors)\n")
    L.append("| predictor | centre | spread | coefficient | s.e. | z |\n|---|---|---|---|---|---|")
    L.append(f"| intercept | | | {res.intercept:.3f} | {res.se['intercept']:.3f} | {res.intercept / res.se['intercept']:.2f} |")
    for f in res.features:
        m, s = res.scale[f]
        L.append(f"| {f} | {m:.2f} | {s:.2f} | {res.coef[f]:.3f} | {res.se[f]:.3f} | {res.coef[f] / res.se[f]:.2f} |")
    L.append("\nA coefficient is the change in the log-odds of a default starting within 12 months for a one-standard-deviation move in the predictor. Base rate: "
             f"{100 * res.in_sample['base_rate']:.2f}% of country-years.\n")
    L.append("## In-sample fit\n")
    i = res.in_sample
    L.append(f"- AUC {i['auc']:.3f}; Brier {i['brier']:.4f} against {i['brier_base_rate']:.4f} for the base rate; log loss {i['log_loss']:.4f} against {i['log_loss_base_rate']:.4f}.\n")
    L.append("## Out-of-sample test (rolling origin: fit on years before T, score year T)\n")
    o = res.out_of_sample
    if o:
        L.append(f"- Years {o['first_year']}-{o['last_year']}: {o['n']:,} country-years, {o['events']} events. AUC {o['auc']:.3f}; Brier {o['brier']:.4f} against {o['brier_base_rate']:.4f} for the base rate; log loss {o['log_loss']:.4f} against {o['log_loss_base_rate']:.4f}.")
        nb = int(res.calibration.attrs.get("n_bins", len(res.calibration)))
        lab = calibration_label(nb)
        L.append("- Base-rate benchmark: each origin's training-window event rate (not the test years' own mean).")
        if o.get("predictor_lag") is not None:
            pit_txt = (f"; rows from {o['pit_from']} are point-in-time, earlier rows use the earliest release (partial-pre-{o['pit_from']})"
                       if o.get("pit_from") else "")
            L.append(f"- Predictors lagged {o['predictor_lag']} year(s) behind the row year t (a start in t+1 is predicted with information available at t); point-in-time vintages: {o.get('point_in_time')}{pit_txt}.")
        L.append(f"\n### Calibration by {lab} of predicted probability (out of sample, {nb} equal-count bins)\n")
        L.append(f"| {lab} | n | predicted | observed | events |\n|---|---|---|---|---|")
        for r in res.calibration.itertuples(index=False):
            L.append(f"| {int(r.bin)} | {int(r.n)} | {100 * r.predicted:.2f}% | {100 * r.observed:.2f}% | {int(r.events)} |")
        L.append("\n### Out-of-sample years\n")
        L.append("| year | n | events | mean predicted | training base rate |\n|---|---|---|---|---|")
        for r in res.oos_by_year.itertuples(index=False):
            L.append(f"| {int(r.year)} | {int(r.n)} | {int(r.events)} | {100 * r.mean_p:.2f}% | {100 * r.base_p:.2f}% |")
    else:
        L.append("- Not enough events for a rolling-origin test.")
    if gate is not None:
        L.append("\n## Fitted-mode gate\n")
        L.append(f"Result: **{'cleared' if gate['cleared'] else 'not cleared'}**. A fitted switch is a Tier 1 model change and needs Sam's approval even when cleared.\n")
        L.append("| check | value | rule | threshold | result |\n|---|---|---|---|---|")
        for k, c in gate["checks"].items():
            v, t = c["value"], c["threshold"]
            fv = "n/a" if v is None else (f"{v:.4f}" if isinstance(v, float) else str(v))
            ft = "n/a" if t is None else (f"{t:.4f}" if isinstance(t, float) else str(t))
            L.append(f"| {k} | {fv} | {c['rule']} | {ft} | {'pass' if c['pass'] else 'fail'} |")
    L.append("\n## Reading the result\n")
    L.append("- An AUC of 0.5 is no discrimination; above 0.75 is good for annual sovereign default prediction in the literature (Manasse-Roubini, Savona-Vezzoli report 0.75-0.85 in sample).")
    L.append("- The Brier score and log loss should beat the base-rate benchmark; if they do not, the model ranks countries but is miscalibrated.")
    L.append("- Calibration bins compare predicted and observed default frequencies; observed should rise with predicted and sit near it.")
    for n_ in notes or []:
        L.append(f"- {n_}")
    p.write_text("\n".join(L) + "\n")
    return p
