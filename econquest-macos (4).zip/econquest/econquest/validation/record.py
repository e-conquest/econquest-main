"""Daily forecast record (roadmap item 2.2): every run appends one row per trading day with the realised loss of the
book marked against Market History prices and the one-day VaR/ES that was forecast for that day. The record is
the P&L history the backtests need, built forward from the day it starts.

Columns of data/forecast_record.csv
  date            trading day T (last date in prices.csv when the record was taken)
  loss            realised loss of the book on T in $mm (+ = loss), from prices T-1 -> T; FX, local-bond and equity
                  positions only (Eurobonds have no daily price here and are excluded, see marked_* columns)
  var, es         the one-day 99% VaR / ES forecast FOR day T, i.e. the forecast recorded on the previous trading day
  var_next, es_next   the one-day forecast made ON day T for the next trading day (GARCH-DCC book VaR)
  var99_12m, es99_12m the Monte Carlo 12-month VaR / ES of the full book on day T
  regime, marked_positions, marked_notional_mm, code_hash, data_hash, recorded_at
"""
from __future__ import annotations
import datetime as dt
from pathlib import Path
import numpy as np
import pandas as pd

COLUMNS = ["date", "loss", "var", "es", "var_next", "es_next", "var99_12m", "es99_12m", "regime", "marked_positions",
           "marked_notional_mm", "code_hash", "data_hash", "recorded_at"]


def book_weights(u, prices: pd.DataFrame) -> pd.DataFrame:
    """One row per markable position: ticker, loss weight w (loss on day t = w * log return of ticker)."""
    cty = u.countries.set_index("country")
    rows = []
    for p in u.portfolio.itertuples():
        sign = 1.0 if str(p.direction).lower().startswith("long") else -1.0
        ccy = str(cty.at[p.country, "currency"]) if "currency" in cty.columns else ""
        etf = cty.at[p.country, "etf"] if "etf" in cty.columns else None
        if p.asset_class in ("FX", "Local bond"):
            ticker, loss_sign = f"USD{ccy}", 1.0          # quote is local per USD: long local loses when it rises
        elif p.asset_class == "Equity":
            ticker, loss_sign = (str(etf) if pd.notna(etf) else ""), -1.0
        else:
            continue
        if ticker and ticker in prices.columns:
            rows.append({"id": p.id, "country": p.country, "asset_class": p.asset_class, "ticker": ticker,
                         "notional_mm": float(p.notional_mm), "w": float(p.notional_mm) * sign * loss_sign})
    return pd.DataFrame(rows, columns=["id", "country", "asset_class", "ticker", "notional_mm", "w"])


def _weekdays(px: pd.DataFrame) -> pd.DataFrame:
    """Google Finance carries weekend FX rows; the record is kept on weekdays only."""
    px = px.copy(); px.index = pd.to_datetime(px.index)
    return px[px.index.dayofweek < 5].sort_index()


def complete_date(px: pd.DataFrame, min_share: float = 0.6) -> pd.Timestamp:
    """Last date on which at least min_share of the series have a price (Google Finance fills the newest day
    gradually, so the very last row is often partial)."""
    share = px.notna().mean(axis=1)
    ok = share[share >= min_share]
    return ok.index.max() if len(ok) else px.index.max()


def realised_loss(u, prices: pd.DataFrame, date: pd.Timestamp | None = None) -> dict:
    """Loss of the markable book from the previous trading day to `date` (default: last date in prices)."""
    px = _weekdays(prices)
    date = pd.Timestamp(date) if date is not None else complete_date(px)
    prev_idx = px.index[px.index < date]
    if len(prev_idx) == 0:
        return {"date": date, "loss": np.nan, "prev_date": None, "marked_positions": 0, "marked_notional_mm": 0.0}
    prev = prev_idx.max()
    w = book_weights(u, px)
    loss, n, notional = 0.0, 0, 0.0
    for r in w.itertuples():
        p0, p1 = px.at[prev, r.ticker], px.at[date, r.ticker]
        if pd.notna(p0) and pd.notna(p1) and p0 > 0 and p1 > 0:
            loss += r.w * float(np.log(p1 / p0)); n += 1; notional += r.notional_mm
    return {"date": date, "prev_date": prev, "loss": loss, "marked_positions": n, "marked_notional_mm": notional}


def load_record(path: Path) -> pd.DataFrame:
    if Path(path).exists():
        df = pd.read_csv(path, parse_dates=["date"])
        for c in COLUMNS:
            if c not in df.columns:
                df[c] = np.nan
        return df[COLUMNS]
    return pd.DataFrame(columns=COLUMNS)


def append_record(path: Path, row: dict) -> pd.DataFrame:
    """Insert or replace the row for row['date']; carry the previous row's var_next/es_next into var/es."""
    rec = load_record(path)
    date = pd.Timestamp(row["date"]).normalize()
    rec = rec[rec["date"] != date]
    earlier = rec[rec["date"] < date].sort_values("date")
    if len(earlier) and (pd.isna(row.get("var")) or row.get("var") is None):
        last = earlier.iloc[-1]
        row["var"], row["es"] = last["var_next"], last["es_next"]
    row["date"] = date
    new = pd.DataFrame([row])[COLUMNS]
    rec = (pd.concat([rec, new], ignore_index=True) if len(rec) else new).sort_values("date").reset_index(drop=True)
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    rec.to_csv(path, index=False)
    return rec


def record_for_backtest(rec: pd.DataFrame) -> pd.DataFrame:
    """Rows where a forecast existed for the day: the history the backtests consume."""
    r = rec.dropna(subset=["loss", "var", "es"]).copy()
    r["period"] = np.arange(1, len(r) + 1)
    return r[["period", "date", "loss", "var", "es"]]


def take_record(u, settings, prices: pd.DataFrame, data_dir: Path, run_mc: bool = True, log=print) -> dict:
    """Mark the book for the last trading day in prices, fit GARCH-DCC for the next day's VaR/ES, optionally run
    the 12-month Monte Carlo, and append the row. Returns the row."""
    from ..engine.garch import run_garch
    px = _weekdays(prices); px = px.loc[:complete_date(px)]
    rl = realised_loss(u, px)
    g = run_garch(u, px, settings, u.gpr)
    port = g.portfolio
    row = {"date": rl["date"], "loss": rl["loss"], "var": np.nan, "es": np.nan,
           "var_next": port.get("total_var99_1d_mm", np.nan), "es_next": port.get("total_es99_1d_mm", np.nan),
           "var99_12m": np.nan, "es99_12m": np.nan, "regime": "", "marked_positions": rl["marked_positions"],
           "marked_notional_mm": rl["marked_notional_mm"], "recorded_at": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")}
    v = (u.provenance.get("versions") or {})
    row["code_hash"], row["data_hash"] = v.get("code_hash", ""), v.get("data_hash", "")
    if run_mc:
        from ..engine import run_pipeline
        res = run_pipeline(u, settings, label="record")
        m = res.metrics
        row["var99_12m"], row["es99_12m"], row["regime"] = m["var99_mm"], m["es99_mm"], res.diagnostics["global_regime"]
    rec = append_record(Path(data_dir) / "forecast_record.csv", row)
    log(record_line(row, rl["prev_date"], len(rec), len(record_for_backtest(rec))))
    return row


def record_line(row: dict, prev_date, n_rows: int, n_tested: int) -> str:
    """The `[record]` log line. U03 (HO-20261023-C-B-010): the recorded date is the last complete trading day in
    Market History (complete_date: >= 60% of series priced), which can be earlier than the day the command runs, so
    the line says so."""
    prev = pd.Timestamp(prev_date).date() if prev_date is not None else "n/a"
    return (f"[record] {pd.Timestamp(row['date']).date()} (last complete trading day in Market History): loss {row['loss']:.3f} $mm "
            f"on {row['marked_positions']} positions (prev {prev}); forecast for next day VaR99 {row['var_next']:.3f} / "
            f"ES99 {row['es_next']:.3f} $mm; record has {n_rows} rows, {n_tested} with a forecast to test")


def _portfolio_var(u, g, prices_to: pd.DataFrame, a99: float = 0.99) -> tuple[float, float]:
    """One-day book VaR/ES using the fits in g (parameters and DCC R_next) with conditional variances filtered
    forward through the returns in prices_to (which may extend past the fit date)."""
    import math
    from ..engine.garch import _returns, t_quantile, t_es, clean_bad_ticks, _business_daily
    prices_to, _ = clean_bad_ticks(prices_to); prices_to = _business_daily(prices_to)   # same alignment as the fit
    w = book_weights(u, prices_to)
    if w.empty or not g.fits:
        return np.nan, np.nan
    agg = w.groupby("ticker")["w"].sum()
    out_v, out_e = 0.0, 0.0
    for kind, dcc in (("FX", g.dcc_fx), ("Equity", g.dcc_eq)):
        tick = [t for t in agg.index if t in g.fits and t in (dcc.labels if dcc else []) and (t.startswith("USD") == (kind == "FX"))]
        if not tick:
            continue
        s1, nus = [], []
        for t in tick:
            f = g.fits[t]; r = _returns(prices_to[t]).to_numpy()
            n_fit = f.n; sig = f.sigma2[-1]; last_r = f.resid[-1]
            for x in r[n_fit:]:                                   # filter forward through returns after the fit
                sig = f.omega + f.alpha * last_r ** 2 + f.beta * sig; last_r = x - f.mu
            s1.append(math.sqrt(f.omega + f.alpha * last_r ** 2 + f.beta * sig)); nus.append(f.nu)
        idx = [dcc.labels.index(t) for t in tick]; R = dcc.R_next[np.ix_(idx, idx)]
        wv = agg[tick].to_numpy(); s1 = np.array(s1); nu = float(np.median(nus))
        v = math.sqrt(wv @ (np.outer(s1, s1) * R) @ wv)
        out_v += (t_quantile(a99, nu) * v) ** 2; out_e += (t_es(a99, nu) * v) ** 2
    return math.sqrt(out_v), math.sqrt(out_e)


def backfill_record(u, settings, prices: pd.DataFrame, data_dir: Path, days: int = 250, step: int = 21, log=print) -> pd.DataFrame:
    """Build the record backwards over the last `days` trading days: GARCH-DCC is refitted every `step` days on
    data up to that date only (no look-ahead), and the one-day VaR/ES for each following day comes from filtering
    the conditional variances forward. Marks the current book on each day. Rows already in the record are kept."""
    from ..engine.garch import run_garch
    px = _weekdays(prices); px = px.loc[:complete_date(px)]
    dates = px.index[-days - 1:]
    path = Path(data_dir) / "forecast_record.csv"
    existing = set(pd.to_datetime(load_record(path)["date"]))
    v = (u.provenance.get("versions") or {})
    g = None; fit_date = None; n_new = 0
    for i in range(1, len(dates)):
        d = dates[i]
        if d in existing:
            continue
        if g is None or (i - 1) % step == 0:
            cut = px.loc[:dates[i - 1]]
            g = run_garch(u, cut, settings, u.gpr); fit_date = dates[i - 1]
            log(f"[backfill] refit GARCH-DCC on data to {fit_date.date()}")
        var_d, es_d = _portfolio_var(u, g, px.loc[:dates[i - 1]])          # forecast for d made at d-1
        var_n, es_n = _portfolio_var(u, g, px.loc[:d])                      # forecast for d+1 made at d
        rl = realised_loss(u, px, d)
        row = {"date": d, "loss": rl["loss"], "var": var_d, "es": es_d, "var_next": var_n, "es_next": es_n, "var99_12m": np.nan, "es99_12m": np.nan,
               "regime": "", "marked_positions": rl["marked_positions"], "marked_notional_mm": rl["marked_notional_mm"],
               "code_hash": v.get("code_hash", ""), "data_hash": v.get("data_hash", ""), "recorded_at": "backfill " + dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds")}
        append_record(path, row); n_new += 1
    rec = load_record(path)
    log(f"[backfill] {n_new} rows added; record has {len(rec)} rows, {len(record_for_backtest(rec))} testable")
    return rec
