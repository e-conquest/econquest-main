"""PD benchmarks (roadmap item 2.6): the model's 12-month default probability beside the alternatives.

Sources compared per country: model (pd_default, after regime multiplier and prediction-market blend), hazard
layer alone (pd_hazard_l1), rating-implied (pd_rating), spread-implied from the Country Profile spread
(pd_market), CDS-implied from `econquest cds` quotes when present, and prediction-market-implied (pm_default)
where a default contract is priced. Each run appends a dated snapshot to data/benchmarks.csv; once a snapshot
is 12 months old its rows are scored against realised default starts (data/panel/sovereign_defaults.csv, kept
up to date by the analyst), giving a Brier score, log loss and AUC per source. Until then the table shows
where the sources disagree.

`score_benchmarks(history, events, as_of)` (EQ-B-0022, GOV-011) is the full framework: per source and horizon, on
matured rows (snapshot date + horizon <= an explicit as_of), Brier, log loss, base-rate Brier, Brier skill, AUC,
equal-count calibration bins and a country-clustered Diebold-Mariano comparison against the model;
`write_benchmark_scores` writes outputs/benchmark_scores.csv and benchmark_calibration.csv. Method:
docs/validation/benchmarks.md. `outcomes`/`score_sources` remain for the existing `benchmark` command.
"""
from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
import datetime as dt
import numpy as np
import pandas as pd
from scipy import stats

from ..common_format import safe_cell as _v       # neutral cell helper: validation must not import presentation (EQ-B-0002)
from .hazard_panel import auc, brier, log_loss

SOURCES = {"pd_model": "model (final)", "pd_hazard": "hazard layer", "pd_rating": "rating-implied", "pd_spread": "spread-implied",
           "pd_cds": "CDS-implied", "pd_pm": "prediction market"}
DEFAULT_RATINGS = {"SD", "D", "RD", "SD/D"}            # agency ratings that mean the sovereign is already in default
COLUMNS = ["date", "country", "iso", "rating", "regime", "composite", "in_default", *SOURCES, "model_vs_rating_pp", "model_vs_spread_pp", "model_vs_cds_pp", "model_vs_pm_pp",
           "spread_bps", "code_hash", "data_hash"]


def _yes(x) -> bool:
    if isinstance(x, str):
        return x.strip().lower() in ("yes", "y", "true", "1")
    return bool(x) if x is not None and not (isinstance(x, float) and np.isnan(x)) else False


def benchmark_snapshot(country: pd.DataFrame, cds_table: pd.DataFrame | None = None, as_of: str | None = None, versions: dict | None = None,
                       default_status: pd.Series | None = None) -> pd.DataFrame:
    """One row per country from a RunResult.country table (indexed by country name).

    `in_default` records whether the sovereign was already in default on the snapshot date: from `default_status`
    (countries.csv `default`, indexed by country) or a `default` column when given, otherwise from an SD/D rating."""
    as_of = as_of or dt.date.today().isoformat()
    c = country
    snap = pd.DataFrame({"date": as_of, "country": c.index, "iso": c["iso"].to_numpy(), "rating": c["rating"].to_numpy(), "regime": c["regime"].to_numpy(),
                         "composite": c["composite"].to_numpy(dtype=float), "pd_model": c["pd_default"].to_numpy(dtype=float),
                         "pd_hazard": c["pd_hazard_l1"].to_numpy(dtype=float), "pd_rating": c["pd_rating"].to_numpy(dtype=float),
                         "pd_spread": c["pd_market"].to_numpy(dtype=float), "pd_cds": np.nan,
                         "pd_pm": c["pm_default"].to_numpy(dtype=float) if "pm_default" in c else np.nan, "spread_bps": c["spread_bps"].to_numpy(dtype=float)})
    if default_status is None and "default" in c:
        default_status = c["default"]
    rated_default = snap["rating"].astype(str).str.strip().str.upper().isin(DEFAULT_RATINGS)
    if default_status is not None:
        flag = snap["country"].map(pd.Series(default_status).map(_yes))
        snap["in_default"] = flag.where(flag.notna(), rated_default).astype(bool) | rated_default
    else:
        snap["in_default"] = rated_default
    if cds_table is not None and len(cds_table):
        m = cds_table.set_index("country")["cds_pd_12m"]
        snap["pd_cds"] = snap["country"].map(m).astype(float)
    for src, col in (("pd_rating", "model_vs_rating_pp"), ("pd_spread", "model_vs_spread_pp"), ("pd_cds", "model_vs_cds_pp"), ("pd_pm", "model_vs_pm_pp")):
        snap[col] = (snap["pd_model"] - snap[src]) * 100
    v = versions or {}
    snap["code_hash"] = v.get("code_hash", ""); snap["data_hash"] = v.get("data_hash", "")
    return snap[COLUMNS].reset_index(drop=True)


def load_history(path: Path) -> pd.DataFrame:
    if Path(path).exists():
        h = pd.read_csv(path, dtype={"iso": str, "code_hash": str, "data_hash": str})
        for col in COLUMNS:
            if col not in h.columns:
                h[col] = np.nan
        return h[COLUMNS]
    return pd.DataFrame(columns=COLUMNS)


def append_history(path: Path, snap: pd.DataFrame) -> pd.DataFrame:
    """Append a snapshot, replacing any earlier snapshot taken the same day."""
    h = load_history(path)
    h = h[h["date"] != snap["date"].iloc[0]]
    h = pd.concat([h, snap], ignore_index=True).sort_values(["date", "country"]).reset_index(drop=True)
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    h.to_csv(path, index=False)
    return h


def in_spell(history: pd.DataFrame, events: pd.DataFrame) -> pd.Series:
    """True for snapshot rows taken while the sovereign was already in default: the row's `in_default` flag, an
    SD/D rating, or a spell in `events` that started (its `start_date` when every event has one, else 1 July of the start year) on or before the snapshot date and had not
    ended (end year inclusive) by it. Such rows cannot record a new default start and are not scored (EQ-B-0005)."""
    d = pd.to_datetime(history["date"])
    flag = history["in_default"].map(_yes) if "in_default" in history else pd.Series(False, index=history.index)
    flag = flag | history["rating"].astype(str).str.strip().str.upper().isin(DEFAULT_RATINGS)
    spells: dict[str, list[tuple[pd.Timestamp, float]]] = {}
    if events is not None and len(events):
        day = "start_date" in events and events["start_date"].notna().all()     # same dating rule as matured_outcomes
        for r in events.itertuples(index=False):
            end = getattr(r, "end", np.nan)
            s0 = pd.Timestamp(r.start_date) if day else pd.Timestamp(year=int(r.start), month=7, day=1)
            spells.setdefault(str(r.iso), []).append((s0, float(end) if pd.notna(end) else np.inf))
    covered = [any(s0 <= di and (e == np.inf or di.year <= e) for s0, e in spells.get(str(iso), []))
               for iso, di in zip(history["iso"], d)]
    return (flag | pd.Series(covered, index=history.index, dtype=bool)).astype(bool)


def outcomes(history: pd.DataFrame, events: pd.DataFrame, horizon_days: int = 365, today: dt.date | None = None,
             as_of=None) -> pd.DataFrame:
    """Realised 12-month outcome for each snapshot row old enough to be scored: 1 if a default spell started
    within `horizon_days` after the snapshot date, 0 otherwise, NaN when the horizon has not elapsed or the
    sovereign was already in default on the snapshot date (`in_spell` True; see `in_spell`). The scoring date is
    `today`, else `as_of` (YYYY-MM-DD, VF-006), else the wall clock."""
    today = today or (pd.Timestamp(as_of).date() if as_of is not None else dt.date.today())
    h = history.copy()
    h["in_spell"] = in_spell(h, events).to_numpy()
    h["date"] = pd.to_datetime(h["date"])
    starts = {iso: sorted(g["start"].astype(int).tolist()) for iso, g in events.groupby("iso")}
    out = []
    for r in h.itertuples(index=False):
        end = r.date + pd.Timedelta(days=horizon_days)
        if end.date() > today or r.in_spell:
            out.append(np.nan); continue
        ys = starts.get(str(r.iso), [])
        # an episode table has yearly resolution: a start in year y counts when y's mid-year falls inside the window
        hit = any(r.date <= pd.Timestamp(year=y, month=7, day=1) <= end for y in ys)
        out.append(1.0 if hit else 0.0)
    h["outcome"] = out
    return h


def score_sources(scored: pd.DataFrame) -> pd.DataFrame:
    """Brier, log loss and AUC per source on the rows with a realised outcome."""
    rows = []
    s = scored.dropna(subset=["outcome"])
    base = float(s["outcome"].mean()) if len(s) else np.nan
    for src, label in SOURCES.items():
        g = s.dropna(subset=[src])
        if g.empty:
            rows.append({"source": label, "rows": 0, "events": 0, "brier": np.nan, "brier_base_rate": np.nan, "log_loss": np.nan, "auc": np.nan}); continue
        y = g["outcome"].to_numpy(dtype=float); p = np.clip(g[src].to_numpy(dtype=float), 1e-6, 1 - 1e-6)
        rows.append({"source": label, "rows": int(len(g)), "events": int(y.sum()), "brier": brier(y, p), "brier_base_rate": brier(y, np.full_like(y, y.mean())),
                     "log_loss": log_loss(y, p), "auc": auc(y, p) if 0 < y.sum() < len(y) else np.nan})
    df = pd.DataFrame(rows)
    df.attrs["base_rate"] = base
    return df


def disagreement_table(snap: pd.DataFrame) -> pd.DataFrame:
    """Countries ordered by how far the model sits from the market and rating views."""
    t = snap[["country", "rating", "regime", "pd_model", "pd_hazard", "pd_rating", "pd_spread", "pd_cds", "pd_pm", "model_vs_rating_pp", "model_vs_spread_pp", "model_vs_pm_pp"]].copy()
    t["max_abs_gap_pp"] = t[["model_vs_rating_pp", "model_vs_spread_pp", "model_vs_pm_pp"]].abs().max(axis=1)
    t["read"] = np.where(t["model_vs_rating_pp"] > 5, "model more pessimistic than the rating",
                np.where(t["model_vs_rating_pp"] < -5, "model more optimistic than the rating", "model close to the rating"))
    return t.sort_values("max_abs_gap_pp", ascending=False).reset_index(drop=True)


def benchmarks_plan(snap: pd.DataFrame, scores: pd.DataFrame, history_rows: int, sheet: str = "PD Benchmarks") -> list[dict]:
    """Values for the PD Benchmarks tab: title and note, the snapshot table from row 4, the scores table below it."""
    dis = disagreement_table(snap)
    cols = ["country", "rating", "regime", "pd_model", "pd_hazard", "pd_rating", "pd_spread", "pd_cds", "pd_pm", "model_vs_rating_pp", "model_vs_spread_pp", "model_vs_pm_pp", "read"]
    header = ["Country", "Rating", "Regime", "Model PD 12m", "Hazard layer PD", "Rating-implied PD", "Spread-implied PD", "CDS-implied PD", "Prediction-market PD",
              "Model minus rating (pp)", "Model minus spread (pp)", "Model minus market (pp)", "Read"]
    note = (f"Written by `python -m econquest benchmark` on {snap['date'].iloc[0]}. Each run appends a dated snapshot to data/benchmarks.csv ({history_rows} rows so far); "
            "rows are scored against realised defaults once 12 months old. Brier score: lower is better; AUC: 0.5 is no discrimination.")
    body = [[_v(r[c]) for c in cols] for _, r in dis.iterrows()]
    n = len(body)
    srow = 6 + n
    scols = ["source", "rows", "events", "brier", "brier_base_rate", "log_loss", "auc"]
    sheader = ["Source", "Scored rows", "Realised defaults", "Brier", "Brier of base rate", "Log loss", "AUC"]
    sbody = [[_v(r[c]) for c in scols] for _, r in scores.iterrows()]
    plan = [{"range": f"'{sheet}'!A1:A2", "values": [["PD benchmarks: model against rating, spread, CDS and prediction-market probabilities"], [note]]},
            {"range": f"'{sheet}'!A4:M4", "values": [header]},
            {"range": f"'{sheet}'!A5:M{4 + n}", "values": body},
            {"range": f"'{sheet}'!A{srow}:G{srow}", "values": [["Scoring against realised 12-month outcomes (rows older than 12 months)"] + [""] * 6]},
            {"range": f"'{sheet}'!A{srow + 1}:G{srow + 1}", "values": [sheader]},
            {"range": f"'{sheet}'!A{srow + 2}:G{srow + 1 + len(sbody)}", "values": sbody}]
    return plan


# ---------------------------------------------------------------------------------------------------------------
# Scoring by source and horizon (EQ-B-0022, GOV-011). Method and formulas: docs/validation/benchmarks.md.
# ---------------------------------------------------------------------------------------------------------------
HORIZONS = {"12m": 12}            # label -> months. Sub-annual horizons need day-resolution events (a start_date column)
BASE_HORIZON_MONTHS = 12          # every PD in the snapshot is a 12-month probability
LOGLOSS_EPS = 1e-6                # log loss clips p to [eps, 1 - eps]: a confident miss costs at most -ln(1e-6) = 13.8
CALIBRATION_BINS = 5              # equal-count bins (quintiles when n >= 5)
MIN_ROWS_COMPARE = 30             # paired comparison vs model needs this many paired rows ...
MIN_CLUSTERS_COMPARE = 5          # ... and this many countries (standard errors are clustered by country)
MODEL_SOURCE = "pd_model"
SCORE_COLUMNS = ["as_of", "horizon", "horizon_months", "source", "label", "status", "n", "events", "base_rate", "brier", "brier_base_rate",
                 "brier_skill", "log_loss", "log_loss_base_rate", "auc", "n_snapshot_rows", "n_excluded_in_spell", "n_pending",
                 "first_maturity", "next_maturity", "n_paired", "brier_diff_vs_model", "dm_stat", "dm_p_value", "dm_clusters",
                 "log_loss_diff_vs_model", "comparison_note"]
CALIBRATION_COLUMNS = ["as_of", "horizon", "source", "bin", "bin_label", "n", "p_min", "p_max", "mean_pred", "observed_rate", "events"]


@dataclass
class BenchmarkScores:
    """Result of `score_benchmarks`: `scores` has one row per horizon and source (always, even when nothing is scorable),
    `calibration` one row per horizon, source and bin, `status` the horizon-level status line."""
    as_of: str
    scores: pd.DataFrame
    calibration: pd.DataFrame
    status: dict = field(default_factory=dict)

    @property
    def scorable(self) -> bool:
        return bool((self.scores["n"] > 0).any()) if len(self.scores) else False


def horizon_pd(p, months: int, base_months: int = BASE_HORIZON_MONTHS) -> np.ndarray:
    """Probability over `months` from a `base_months` probability under a constant hazard: 1 - (1 - p)^(months/base)."""
    p = np.clip(np.asarray(p, dtype=float), 0.0, 1.0)
    return p if months == base_months else 1.0 - (1.0 - p) ** (months / base_months)


def _as_of(as_of) -> pd.Timestamp:
    if as_of is None or (isinstance(as_of, str) and not as_of.strip()):
        raise ValueError("as_of is required: scoring never reads the wall clock (pass the run's as-of date)")
    return pd.Timestamp(as_of).normalize()


def _event_starts(events: pd.DataFrame) -> tuple[dict[str, list[pd.Timestamp]], bool]:
    """Default start dates per ISO and whether they have day resolution. Without a `start_date` column a start year y is
    dated 1 July y (the mid-year convention of `outcomes`)."""
    if events is None or not len(events):
        return {}, False
    day = "start_date" in events and events["start_date"].notna().all()
    out: dict[str, list[pd.Timestamp]] = {}
    for r in events.itertuples(index=False):
        ts = pd.Timestamp(r.start_date) if day else pd.Timestamp(year=int(r.start), month=7, day=1)
        out.setdefault(str(r.iso).upper().strip(), []).append(ts)
    return out, day


def matured_outcomes(history: pd.DataFrame, events: pd.DataFrame, as_of, months: int = 12) -> pd.DataFrame:
    """Snapshot rows with `maturity` (snapshot date + `months` calendar months), `in_spell`, `matured`
    (maturity <= as_of and not in spell) and `outcome` (1 if a default spell starts in [date, maturity], 0 if none,
    NaN when not matured or in spell)."""
    t = _as_of(as_of)
    h = history.copy().reset_index(drop=True)
    if h.empty:
        for c in ("maturity", "in_spell", "matured", "outcome"):
            h[c] = pd.Series(dtype=float)
        return h
    h["date"] = pd.to_datetime(h["date"])
    h["maturity"] = h["date"] + pd.DateOffset(months=months)
    h["in_spell"] = in_spell(h.assign(date=h["date"].dt.strftime("%Y-%m-%d")), events).to_numpy()
    h["matured"] = (h["maturity"] <= t) & ~h["in_spell"]
    starts, _ = _event_starts(events)
    hit = [any(d <= s <= m for s in starts.get(str(iso).upper().strip(), [])) for iso, d, m in zip(h["iso"], h["date"], h["maturity"])]
    h["outcome"] = np.where(h["matured"], np.asarray(hit, dtype=float), np.nan)
    return h


def _paired_dm(d: np.ndarray, clusters: np.ndarray, min_rows: int, min_clusters: int) -> tuple[float, float, int, str]:
    """Diebold-Mariano-style t on per-row loss differences with standard errors clustered by country (overlapping
    snapshots of one country are not independent). Returns (t, two-sided p on G-1 df, G, note)."""
    n = len(d); groups = pd.unique(clusters); g = len(groups)
    if n < min_rows or g < min_clusters:
        return np.nan, np.nan, g, f"not tested: {n} paired rows in {g} countries (needs {min_rows} rows and {min_clusters} countries)"
    e = d - d.mean()
    s = pd.Series(e).groupby(np.asarray(clusters)).sum().to_numpy()
    se = float(np.sqrt(g / (g - 1) * np.sum(s ** 2)) / n)
    if se == 0:
        return np.nan, np.nan, g, "not tested: loss differences have zero variance"
    t = float(d.mean() / se)
    return t, float(2 * stats.t.sf(abs(t), g - 1)), g, "cluster-robust DM on Brier loss difference (source minus model)"


def calibration_table(y: np.ndarray, p: np.ndarray, n_bins: int = CALIBRATION_BINS) -> pd.DataFrame:
    """Equal-count bins over the forecasts sorted ascending (ties keep row order). Bin labels give the actual
    forecast range in the bin, so tied values on a boundary show as overlapping ranges rather than a false cut."""
    y = np.asarray(y, dtype=float); p = np.asarray(p, dtype=float)
    k = int(min(n_bins, len(p)))
    if k == 0:
        return pd.DataFrame(columns=["bin", "bin_label", "n", "p_min", "p_max", "mean_pred", "observed_rate", "events"])
    order = np.argsort(p, kind="mergesort")
    rows = []
    for i, idx in enumerate(np.array_split(order, k), start=1):
        pp, yy = p[idx], y[idx]
        rows.append({"bin": i, "bin_label": f"bin {i} of {k} (equal-count): p {pp.min():.4f} to {pp.max():.4f}", "n": int(len(idx)),
                     "p_min": float(pp.min()), "p_max": float(pp.max()), "mean_pred": float(pp.mean()), "observed_rate": float(yy.mean()),
                     "events": int(yy.sum())})
    return pd.DataFrame(rows)


def _fmt(ts) -> str:
    return pd.Timestamp(ts).strftime("%Y-%m-%d") if ts is not None and pd.notna(ts) else ""


def score_benchmarks(history: pd.DataFrame, events: pd.DataFrame, as_of, horizons: dict[str, int] | None = None,
                     n_bins: int = CALIBRATION_BINS, eps: float = LOGLOSS_EPS, min_rows_compare: int = MIN_ROWS_COMPARE,
                     min_clusters_compare: int = MIN_CLUSTERS_COMPARE) -> BenchmarkScores:
    """Brier, log loss, base-rate Brier, Brier skill, AUC, calibration and a paired comparison against the model, per
    source in SOURCES and per horizon, on matured snapshot rows (date + horizon <= as_of, not already in default).
    Always returns one scores row per horizon and source; `status` says why a horizon is not scorable."""
    t = _as_of(as_of); as_of_s = _fmt(t)
    horizons = horizons or HORIZONS
    history = history if history is not None else pd.DataFrame(columns=COLUMNS)
    _, day_resolution = _event_starts(events)
    score_rows, cal_rows, status = [], [], {}
    for hlabel, months in horizons.items():
        h = matured_outcomes(history, events, t, months)
        elig = h[~h["in_spell"].astype(bool)] if len(h) else h
        pending = elig[elig["maturity"] > t] if len(elig) else elig
        first_m = elig["maturity"].min() if len(elig) else None
        next_m = pending["maturity"].min() if len(pending) else None
        n_spell = int(h["in_spell"].astype(bool).sum()) if len(h) else 0
        m = h[h["matured"].astype(bool)] if len(h) else h
        if months < BASE_HORIZON_MONTHS and not day_resolution:
            hstatus = (f"not scorable: default events have yearly resolution (start year only); a {hlabel} horizon needs a "
                       "start_date column in the events table")
            m = m.iloc[0:0]
        elif h.empty:
            hstatus = "not yet scorable: no snapshots in the history"
        elif elig.empty:
            hstatus = "not yet scorable: every snapshot row is already in default"
        elif m.empty:
            hstatus = f"not yet scorable, first maturity {_fmt(first_m)}"
        else:
            hstatus = f"scored: {len(m)} matured rows" + (f", next maturity {_fmt(next_m)}" if next_m is not None else "")
        status[hlabel] = hstatus
        model_loss = None
        if len(m) and m[MODEL_SOURCE].notna().any():
            mm = m[m[MODEL_SOURCE].notna()]
            model_loss = pd.DataFrame({"bl": (horizon_pd(mm[MODEL_SOURCE], months) - mm["outcome"]) ** 2,
                                       "ll": _row_log_loss(mm["outcome"].to_numpy(dtype=float), horizon_pd(mm[MODEL_SOURCE], months), eps)},
                                      index=mm.index)
        for src, label in SOURCES.items():
            row = {c: np.nan for c in SCORE_COLUMNS}
            row.update({"as_of": as_of_s, "horizon": hlabel, "horizon_months": months, "source": src, "label": label, "n": 0, "events": 0,
                        "n_snapshot_rows": int(len(h)), "n_excluded_in_spell": n_spell, "n_pending": int(len(pending)),
                        "first_maturity": _fmt(first_m), "next_maturity": _fmt(next_m), "n_paired": 0, "comparison_note": ""})
            g = m[m[src].notna()] if len(m) else m
            if m.empty:
                row["status"] = hstatus
            elif g.empty:
                row["status"] = "no forecasts from this source on the matured rows"
            else:
                y = g["outcome"].to_numpy(dtype=float); p = horizon_pd(g[src], months)
                base = float(y.mean()); bb = float(np.mean((base - y) ** 2)); b = float(np.mean((p - y) ** 2))
                row.update({"status": "scored", "n": int(len(g)), "events": int(y.sum()), "base_rate": base, "brier": b, "brier_base_rate": bb,
                            "brier_skill": 1 - b / bb if bb > 0 else np.nan, "log_loss": float(_row_log_loss(y, p, eps).mean()),
                            "log_loss_base_rate": float(_row_log_loss(y, np.full_like(y, base), eps).mean()),
                            "auc": auc(y, p) if 0 < y.sum() < len(y) else np.nan})
                c = calibration_table(y, p, n_bins)
                if len(c):
                    cal_rows.append(c.assign(as_of=as_of_s, horizon=hlabel, source=src))
                if src != MODEL_SOURCE and model_loss is not None:
                    both = g.index.intersection(model_loss.index)
                    if len(both):
                        gb = g.loc[both]; pb = horizon_pd(gb[src], months); yb = gb["outcome"].to_numpy(dtype=float)
                        d = (pb - yb) ** 2 - model_loss.loc[both, "bl"].to_numpy()
                        dl = _row_log_loss(yb, pb, eps) - model_loss.loc[both, "ll"].to_numpy()
                        tstat, pval, ng, note = _paired_dm(d, gb["iso"].astype(str).to_numpy(), min_rows_compare, min_clusters_compare)
                        row.update({"n_paired": int(len(both)), "brier_diff_vs_model": float(d.mean()), "log_loss_diff_vs_model": float(dl.mean()),
                                    "dm_stat": tstat, "dm_p_value": pval, "dm_clusters": ng, "comparison_note": note})
                    else:
                        row["comparison_note"] = "no rows where both this source and the model have a forecast"
            score_rows.append(row)
    scores = pd.DataFrame(score_rows, columns=SCORE_COLUMNS)
    cal = pd.concat(cal_rows, ignore_index=True)[CALIBRATION_COLUMNS] if cal_rows else pd.DataFrame(columns=CALIBRATION_COLUMNS)
    return BenchmarkScores(as_of=as_of_s, scores=scores, calibration=cal, status=status)


def _row_log_loss(y: np.ndarray, p: np.ndarray, eps: float = LOGLOSS_EPS) -> np.ndarray:
    p = np.clip(np.asarray(p, dtype=float), eps, 1 - eps); y = np.asarray(y, dtype=float)
    return -(y * np.log(p) + (1 - y) * np.log(1 - p))


def write_benchmark_scores(result: BenchmarkScores, out_dir: Path) -> dict[str, Path]:
    """Write outputs/benchmark_scores.csv (one row per horizon and source, with the status line) and
    outputs/benchmark_calibration.csv. Both files are written with headers even when nothing is scorable."""
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    paths = {"scores": out / "benchmark_scores.csv", "calibration": out / "benchmark_calibration.csv"}
    result.scores.to_csv(paths["scores"], index=False)
    result.calibration.to_csv(paths["calibration"], index=False)
    return paths
