"""Model governance pack support (roadmap items 2.5 and 4.4): a change log built from the archived runs and the
live facts the model inventory quotes.

`change_log(store)` reads the `runs` table of the SQLite store (run_id, created_at, label, settings JSON,
summary JSON) and gives one row per archived run with the code and data hashes stamped by `versioning.stamp`,
the headline metrics, and three flags that compare each run with the previous run carrying the same label,
in chronological order: `code_changed` (code_hash differs), `data_changed` (data_hash differs) and
`settings_changed` (the settings JSON differs), plus `settings_diff`, a short "key: old -> new" list of the
dotted keys that moved. The run's `as_of` date is not a model setting and is left out of that comparison
(EQ-B-0011): two daily runs with identical parameters are not a settings change. Runs archived before versioning existed have no hashes; a comparison against one of
them is reported as changed, because nothing proves otherwise.

`write_change_log(df, path)` renders the table as docs/governance/change-log.md, newest first.

`inventory_status(data_dir, out_dir)` collects what the inventory and the revalidation routine need without
running anything: layer1.mode, the Merton uplift switch, the fitted-panel gate figures, the number of archived
runs and the latest run's id and hashes, the current code and data hashes, and the sizes of the evidence
files (forecast record, benchmarks, CDS quotes, review holds). No subprocess is started.
"""
from __future__ import annotations
import json
import sqlite3
from pathlib import Path
import pandas as pd
from .hazard_panel import GATE_MIN_AUC, GATE_MIN_EVENTS

LOG_COLUMNS = ["run_id", "created_at", "label", "code_version", "code_hash", "data_hash", "paths", "var99_mm", "es99_mm", "expected_loss_mm",
               "code_changed", "data_changed", "settings_changed", "settings_diff", "as_of", "run_hash"]


def flatten(d, prefix: str = "") -> dict:
    """Nested dict -> {dotted.key: scalar}; lists and other non-dict values are kept whole."""
    out = {}
    if not isinstance(d, dict):
        return {prefix.rstrip("."): d}
    for k, v in d.items():
        key = f"{prefix}{k}"
        if isinstance(v, dict):
            out.update(flatten(v, key + "."))
        else:
            out[key] = v
    return out


def _short(v) -> str:
    s = json.dumps(v) if isinstance(v, (list, dict)) else str(v)
    return s if len(s) <= 24 else s[:21] + "..."


def settings_diff(old: dict | None, new: dict | None, max_len: int = 200) -> str:
    """'key: old -> new' for every dotted key that differs (added keys show 'absent'), cut at `max_len`."""
    a, b = flatten(old or {}), flatten(new or {})
    changed, removed, added = [], [], []
    for k in sorted(set(a) | set(b)):
        if k in a and k in b:
            if a[k] != b[k]:
                changed.append(f"{k}: {_short(a[k])} -> {_short(b[k])}")
        elif k in a:
            removed.append(f"{k}: {_short(a[k])} -> absent")
        else:
            added.append(f"{k}: absent -> {_short(b[k])}")
    parts = changed + removed + added          # keys that moved first, then removed, then added
    s = "; ".join(parts)
    if len(s) > max_len:
        s = s[:max_len - 3].rsplit(";", 1)[0] + f"; ... ({len(parts)} keys)"
    return s


def _rows(store, limit: int) -> list[dict]:
    db = Path(store.db) if hasattr(store, "db") else Path(store) / "econquest.sqlite"
    with sqlite3.connect(db) as c:
        rows = c.execute("SELECT run_id, created_at, label, settings, summary FROM runs ORDER BY created_at DESC LIMIT ?", (int(limit),)).fetchall()
    out = []
    for run_id, created, label, settings, summary in rows:
        try:
            st = json.loads(settings) if settings else {}
        except json.JSONDecodeError:
            st = {}
        try:
            sm = json.loads(summary) if summary else {}
        except json.JSONDecodeError:
            sm = {}
        out.append({"run_id": run_id, "created_at": created, "label": label, "settings": st, "summary": sm})
    return out


def _model_settings(s: dict | None) -> dict | None:
    """Settings without the run date, which every daily run changes."""
    return {k: v for k, v in s.items() if k != "as_of"} if isinstance(s, dict) else s


def change_log(store, limit: int = 200) -> pd.DataFrame:
    """One row per archived run, newest first, with change flags against the previous run of the same label."""
    runs = sorted(_rows(store, limit), key=lambda r: (r["created_at"] or "", r["run_id"]))
    last_by_label: dict[str, dict] = {}
    recs = []
    for r in runs:
        s = r["summary"]; m = s.get("metrics") or {}; v = s.get("versions") or {}
        rec = {"run_id": r["run_id"], "created_at": r["created_at"], "label": r["label"], "code_version": v.get("code_version"),
               "code_hash": v.get("code_hash"), "data_hash": v.get("data_hash"), "paths": m.get("paths"),
               "var99_mm": m.get("var99_mm"), "es99_mm": m.get("es99_mm"), "expected_loss_mm": m.get("expected_loss_mm"),
               "as_of": v.get("as_of") or (r["settings"] or {}).get("as_of"), "run_hash": v.get("run_hash")}
        prev = last_by_label.get(r["label"])
        if prev is None:
            rec.update(code_changed=False, data_changed=False, settings_changed=False, settings_diff="first run with this label")
        else:
            pv = (prev["summary"].get("versions") or {})
            rec["code_changed"] = rec["code_hash"] != pv.get("code_hash")
            rec["data_changed"] = rec["data_hash"] != pv.get("data_hash")
            old_s, new_s = _model_settings(prev["settings"]), _model_settings(r["settings"])
            rec["settings_changed"] = new_s != old_s
            rec["settings_diff"] = settings_diff(old_s, new_s) if rec["settings_changed"] else ""
        recs.append(rec)
        last_by_label[r["label"]] = r
    df = pd.DataFrame(recs, columns=LOG_COLUMNS)
    if len(df):
        df = df.sort_values(["created_at", "run_id"], ascending=False).reset_index(drop=True)
    return df


def _fmt(v) -> str:
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return ""
    if isinstance(v, bool):
        return "yes" if v else "no"
    if isinstance(v, float):
        return f"{v:.2f}"
    return str(v).replace("|", "\\|")


def write_change_log(df: pd.DataFrame, path: str | Path) -> Path:
    """Render the change log as a Markdown table with a header paragraph explaining the columns."""
    path = Path(path); path.parent.mkdir(parents=True, exist_ok=True)
    today = pd.Timestamp.now("UTC").strftime("%Y-%m-%d")
    lines = ["# Change log of archived runs", "",
             f"Generated {today} by `econquest.validation.governance.write_change_log` from the `runs` table of "
             "`outputs/store/econquest.sqlite` ({n} runs, newest first). Regenerate with `python -m econquest governance` or "
             "`write_change_log(change_log(Store('outputs/store')), 'docs/governance/change-log.md')`.".format(n=len(df)), "",
             "Columns: `run_id` and `created_at` identify the archived run (`label` is `base`, `stress-A/B/C`, `workbench` or a custom "
             "`run --label`); `code_version`, `code_hash` and `data_hash` are the stamps written by `econquest/versioning.py` "
             "(`__version__`, SHA-256 over the package's `.py`/`.html`/`.js` files, and a hash over the data files listed in "
             "`versioning.DATA_FILES`, 16 hex characters each; blank for runs archived before versioning existed); `paths`, "
             "`var99_mm`, `es99_mm` and `expected_loss_mm` come from the run summary ($mm, 12-month horizon). The flags "
             "`code_changed`, `data_changed` and `settings_changed` compare the run with the previous archived run of the same "
             "label in chronological order: a `yes` means the code hash, the data hash or the settings JSON (the copy of "
             "`data/assumptions.json` plus any CLI or scenario patch the run used) differs from that predecessor. "
             "`settings_diff` lists the dotted keys that moved as `key: old -> new`, cut at about 200 characters. Under the "
             "model-risk policy (`model-risk-policy.md`) any `yes` in the three flag columns is a model change and must have a "
             "sign-off row in `change-control.md`; a stress run differing from its base run in `settings_diff` only through the "
             "scenario patch (for example `market.lgd_hard: 60.0 -> 78.0` for scenario B) is expected and needs no sign-off.", "",
             "| " + " | ".join(LOG_COLUMNS) + " |", "|" + "---|" * len(LOG_COLUMNS)]
    for _, r in df.iterrows():
        lines.append("| " + " | ".join(_fmt(r[c]) for c in LOG_COLUMNS) + " |")
    if not len(df):
        lines.append("| (no runs archived yet) |" + " |" * (len(LOG_COLUMNS) - 1))
    path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return path


def _csv_rows(path: Path) -> int:
    try:
        return int(pd.read_csv(path).shape[0]) if path.is_file() else 0
    except Exception:
        return 0


def _review_holds(path: Path) -> int:
    """Cells the quality gate held (status 'hold') on the last pull; review.csv also lists ok and missing cells."""
    try:
        r = pd.read_csv(path) if path.is_file() else None
        return int((r["status"] == "hold").sum()) if r is not None and "status" in r else 0
    except Exception:
        return 0


def inventory_status(data_dir: str | Path, out_dir: str | Path) -> dict:
    """Live facts for the model inventory. Reads files only; nothing is run."""
    from ..versioning import code_hash, data_hash
    from .. import __version__
    data, out = Path(data_dir), Path(out_dir)
    try:
        a = json.loads((data / "assumptions.json").read_text())
    except (OSError, json.JSONDecodeError):
        a = {}
    l1 = a.get("layer1") or {}; fit = a.get("layer1_fitted") or {}; oos = fit.get("out_of_sample") or {}; panel = fit.get("panel") or {}
    status = {
        "as_of": pd.Timestamp.now("UTC").strftime("%Y-%m-%d"),
        "code_version": __version__, "code_hash_now": code_hash(), "data_hash_now": data_hash(data),
        "layer1": {"mode": l1.get("mode"), "hazard_weight": l1.get("hazard_weight"), "calibrate_to": l1.get("calibrate_to"),
                   "fitted_on": fit.get("fitted_on"), "fitted_events": panel.get("events"), "fitted_n": panel.get("n"),
                   "oos_auc": oos.get("auc"), "oos_brier": oos.get("brier"), "oos_brier_base_rate": oos.get("brier_base_rate"),
                   "gate_min_auc": GATE_MIN_AUC, "gate_min_events": GATE_MIN_EVENTS,     # one source with fit-hazard (EQ-B-0028)
                   "gate_cleared": bool(oos.get("auc") is not None and oos.get("auc") >= GATE_MIN_AUC and (panel.get("events") or 0) >= GATE_MIN_EVENTS
                                        and oos.get("brier") is not None and oos.get("brier") < (oos.get("brier_base_rate") or 0))},
        "layer4": {"apply_uplift": (a.get("layer4") or {}).get("merton", {}).get("apply_uplift"), "gpd_xi": (a.get("layer4") or {}).get("gpd_xi"),
                   "lgd_sd": (a.get("layer4") or {}).get("lgd_sd")},
        "monte_carlo": {"paths": (a.get("monte_carlo") or {}).get("paths"), "df_calm": (a.get("monte_carlo") or {}).get("df_calm"),
                        "df_stressed": (a.get("monte_carlo") or {}).get("df_stressed")},
        "probability": {k: (a.get("probability") or {}).get(k) for k in ("w_s", "w_m", "w_t", "w_fx")},
        "alerts": a.get("alerts") or {},
        "evidence": {"forecast_record_rows": _csv_rows(data / "forecast_record.csv"), "benchmark_rows": _csv_rows(data / "benchmarks.csv"),
                     "cds_quote_rows": _csv_rows(data / "cds_quotes.csv"), "backtest_history_rows": _csv_rows(data / "backtest_history.csv"),
                     "review_holds": _review_holds(data / "live" / "review.csv"), "default_episodes": _csv_rows(data / "panel" / "sovereign_defaults.csv"),
                     "validation_docs": len(list((Path(__file__).resolve().parents[2] / "docs" / "validation").glob("*.md")))},
        "store": {"runs": 0, "latest_run_id": None, "latest_created_at": None, "latest_code_hash": None, "latest_data_hash": None,
                  "code_hash_matches_latest_run": None},
    }
    pm = data / "prediction_markets.csv"
    try:
        cols = set(pd.read_csv(pm, nrows=0).columns) if pm.is_file() else set()
    except Exception:
        cols = set()
    status["prediction_markets_live_mapped"] = bool({"slug", "ticker"} & cols)
    lim = data / "limits.json"
    try:
        status["limits_warning_level"] = json.loads(lim.read_text()).get("warning_level") if lim.is_file() else None
    except (OSError, json.JSONDecodeError):
        status["limits_warning_level"] = None
    db = out / "store" / "econquest.sqlite"
    if db.is_file():
        with sqlite3.connect(db) as c:
            n = c.execute("SELECT COUNT(*) FROM runs").fetchone()[0]
            row = c.execute("SELECT run_id, created_at, summary FROM runs WHERE label='base' ORDER BY created_at DESC LIMIT 1").fetchone() \
                or c.execute("SELECT run_id, created_at, summary FROM runs ORDER BY created_at DESC LIMIT 1").fetchone()
        status["store"]["runs"] = int(n)
        if row:
            v = (json.loads(row[2]).get("versions") or {}) if row[2] else {}
            status["store"].update(latest_run_id=row[0], latest_created_at=row[1], latest_code_hash=v.get("code_hash"), latest_data_hash=v.get("data_hash"),
                                   code_hash_matches_latest_run=v.get("code_hash") == status["code_hash_now"],
                                   data_hash_matches_latest_run=v.get("data_hash") == status["data_hash_now"])
    try:                                                     # approvals ledger: hand edits outside `econquest change` (EQ-B-0032)
        from ..ops.approvals import detect_unapproved
        d = detect_unapproved(data)
        status["approvals"] = {"ok": d["ok"], "chain_ok": d["chain_ok"], "files": {f["file"]: f["status"] for f in d["files"]}}
    except Exception as e:                                   # never fail the governance pack on the drift check
        status["approvals"] = {"ok": None, "error": type(e).__name__}
    return status
