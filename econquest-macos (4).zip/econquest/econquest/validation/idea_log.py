"""Trade-idea log (EQ-B-0038, GOV-032): every Playbook idea a run activates is logged once at entry, marked daily
against Market History prices, and closed when it stops firing, hits its stop or target, or reaches its maximum
holding period. The report gives hit rate and P&L per playbook id and per stance. Tier 3 (illustrative): no reported,
limit-tested or sized number reads the log.

One row per idea in outputs/idea_log.csv
  idea_id            "<trade>-<ISO3>-<entry as_of yyyymmdd>"
  run_id, as_of      the run that opened the idea and its as_of date
  trade_id, strategy, country, iso, stance, instrument   from the playbook and the country table
  signal_value       the activated value (trade_activation)
  regime, notional_mm, country_notional_mm
                     dashboard sizing applied per idea: risk_budget_mm x value / 100 x regime_scalar[regime], 0 for
                     an unsized stance (Hedge); the country's dashboard notional_mm is the largest of its ideas'
  ticker, direction  the Market History series the instrument maps to and the side (+1 long the quote, -1 short);
                     empty / 0 when the idea is unmarked (unmarked_reason says why)
  entry_date, entry_price   last price of the ticker on or before as_of (never after), at most max_stale_days old
  vol_3m             realised vol over the 3-month window to entry: std of the last vol_window_days daily log returns
                     x sqrt(vol_window_days)
  stop, target       entry x exp(-/+ stop_vol_mult / target_vol_mult x vol_3m) on the adverse / favourable side
  max_exit_date      entry_date + upper end of the playbook horizon in months (default_max_hold_months if open-ended)
  status             open / closed;  rearm: False after a stop/target/max-holding exit until the idea stops firing
  last_fired_as_of, mark_date, mark_price, return_pct, pnl_mm
  close_date, close_price, close_reason (stop, target, max_holding, stopped_firing), close_run_id

P&L in $mm on notional N: an equity ETF (USD quote) earns direction x N x (P / P0 - 1); an FX position on a
USD/local quote earns direction x N x (1 - P0 / P), the USD value of a long-USD position funded in local currency.
Carry, financing and costs are not included. Stops and targets are tested on daily closes, so an exit is at the
close of the day the level is crossed, not at the level.
"""
from __future__ import annotations
import math
import re
from pathlib import Path
import numpy as np
import pandas as pd

from .record import _weekdays

COLUMNS = ["idea_id", "run_id", "as_of", "trade_id", "strategy", "country", "iso", "stance", "instrument", "signal_value", "regime",
           "notional_mm", "country_notional_mm", "ticker", "direction", "markable", "unmarked_reason", "entry_date", "entry_price",
           "vol_3m", "stop", "target", "max_exit_date", "status", "rearm", "last_fired_as_of", "mark_date", "mark_price",
           "return_pct", "pnl_mm", "close_date", "close_price", "close_reason", "close_run_id"]
DATE_COLS = ["as_of", "entry_date", "max_exit_date", "last_fired_as_of", "mark_date", "close_date"]

# Code defaults (no `ideas` block in assumptions.json yet; proposed keys listed in the validation document)
DEFAULTS = {"vol_window_days": 63, "min_vol_obs": 20, "stop_vol_mult": 2.0, "target_vol_mult": 2.0,
            "default_max_hold_months": 12, "max_stale_days": 7}

# Playbook instrument -> how it is marked: (ticker template, direction by stance). Only FX forwards/NDFs (USD/local
# quote) and country equity ETFs have a daily price in Market History. CDS, Eurobond, local rates, FX options and
# "Any" (insurance, cross-asset, prediction markets) are logged unmarked.
MARKABLE = {"FX": ("fx", {"Risk-off": 1, "Risk-on": -1}),          # Risk-off = long USD vs local; Risk-on = carry, long local
            "Equity": ("etf", {"Risk-off": -1, "Risk-on": 1})}     # Risk-off = underweight / short; Risk-on = overweight
CLOSE_REASONS = ("stop", "target", "max_holding", "stopped_firing")


def _param(settings, key):
    return settings.get("ideas", key, default=DEFAULTS[key]) if settings is not None else DEFAULTS[key]


def max_hold_months(horizon, default: int) -> int:
    """Upper end of a playbook horizon in months: '3-12 months' -> 12, '12+ months' -> 12, 'Event to 1 month' -> 1;
    anything without a month count (open-ended, seasonal, to contract resolution) -> default."""
    nums = [int(x) for x in re.findall(r"\d+", str(horizon))] if isinstance(horizon, str) and "month" in horizon.lower() else []
    return max(nums) if nums else int(default)


def instrument_ticker(instrument: str, stance: str, currency, etf) -> tuple[str, int, str]:
    """(ticker, direction, unmarked_reason) for one idea; ticker '' and direction 0 when it cannot be marked."""
    if instrument not in MARKABLE:
        return "", 0, f"no price series for instrument {instrument}"
    kind, sides = MARKABLE[instrument]
    if stance not in sides:
        return "", 0, f"no direction rule for stance {stance} on {instrument}"
    if kind == "fx":
        tick = f"USD{currency}" if isinstance(currency, str) and currency else ""
    else:
        tick = str(etf) if isinstance(etf, str) and etf else ""
    return (tick, sides[stance], "") if tick else ("", 0, f"no {instrument} ticker for the country")


def _price_on(series: pd.Series, as_of: pd.Timestamp, max_stale_days: int):
    """Last price on or before as_of (point in time), if it is at most max_stale_days old."""
    s = series.loc[:as_of].dropna()
    s = s[s > 0]
    if s.empty or (as_of - s.index[-1]).days > max_stale_days:
        return None, np.nan
    return s.index[-1], float(s.iloc[-1])


def _vol_3m(series: pd.Series, entry_date: pd.Timestamp, window: int, min_obs: int) -> float:
    s = series.loc[:entry_date].dropna()
    r = np.log(s[s > 0]).diff().dropna().iloc[-window:]
    return float(r.std(ddof=1) * math.sqrt(window)) if len(r) >= min_obs else np.nan


def idea_return(instrument: str, direction: int, p0: float, p: float) -> float:
    """Direction-adjusted return on notional (see the module docstring for the FX convention)."""
    raw = (1.0 - p0 / p) if instrument == "FX" else (p / p0 - 1.0)
    return direction * raw


# --- ideas activated by a run ----------------------------------------------------------------------------------

def _run_parts(run):
    """(run_id, as_of, activation wide [trade x country], dashboard indexed by country) from a RunResult or run dict."""
    if isinstance(run, dict):
        s = run["summary"]; run_id = s["run_id"]
        as_of = (run.get("settings") or {}).get("as_of") or s.get("as_of") or s["created_at"][:10]
        act = pd.DataFrame(run.get("activation") or []).set_index("trade") if run.get("activation") else pd.DataFrame()
        dash = pd.DataFrame(run.get("dashboard") or []).set_index("country") if run.get("dashboard") else pd.DataFrame()
    else:
        run_id = run.run_id
        as_of = (run.settings or {}).get("as_of") or str(run.created_at)[:10]
        act = run.activation if run.activation is not None else pd.DataFrame()
        dash = run.dashboard if run.dashboard is not None else pd.DataFrame()
    return run_id, pd.Timestamp(as_of).normalize(), act.apply(pd.to_numeric, errors="coerce"), dash


def run_ideas(run, u, settings) -> pd.DataFrame:
    """One row per (trade, country) the run activated, with the per-idea dashboard sizing."""
    run_id, as_of, act, dash = _run_parts(run)
    if len(act) and act.notna().any().any() and not len(dash):
        raise ValueError(f"run {run_id} has activations but no dashboard: idea sizing needs the dashboard regime")
    pb = u.playbook.set_index("id")
    cty = u.countries.set_index("country")
    sg = settings["signals"]
    unsized = set(settings.get("signals", "unsized_stances", default=["Hedge"]))
    rows = []
    for tid, rec in act.iterrows():
        t = pb.loc[tid]
        for c, v in rec.dropna().items():
            regime = str(dash.at[c, "regime"])
            notional = 0.0 if t["stance"] in unsized else sg["risk_budget_mm"] * float(v) / 100 * sg["regime_scalar"][regime]
            tick, d, why = instrument_ticker(t["instrument"], t["stance"], cty.at[c, "currency"] if "currency" in cty.columns else None,
                                             cty.at[c, "etf"] if "etf" in cty.columns else None)
            rows.append({"run_id": run_id, "as_of": as_of, "trade_id": tid, "strategy": t["strategy"], "country": c,
                         "iso": cty.at[c, "iso"] if "iso" in cty.columns else c, "stance": t["stance"], "instrument": t["instrument"],
                         "signal_value": float(v), "regime": regime, "notional_mm": round(notional, 2),
                         "country_notional_mm": float(dash.at[c, "notional_mm"]) if c in dash.index else np.nan,
                         "ticker": tick, "direction": d, "unmarked_reason": why, "horizon": t.get("horizon")})
    return pd.DataFrame(rows)


# --- the log ---------------------------------------------------------------------------------------------------

def empty_log() -> pd.DataFrame:
    return pd.DataFrame(columns=COLUMNS)


def load_log(path) -> pd.DataFrame:
    if not Path(path).exists():
        return empty_log()
    df = pd.read_csv(path, keep_default_na=True)
    for c in COLUMNS:
        if c not in df.columns:
            df[c] = np.nan
    df = df[COLUMNS]
    for c in DATE_COLS:
        df[c] = pd.to_datetime(df[c])
    for c in ("ticker", "unmarked_reason", "close_reason", "close_run_id"):
        df[c] = df[c].fillna("").astype(str)
    df["markable"] = df["markable"].astype(str).str.lower().eq("true")
    df["rearm"] = df["rearm"].astype(str).str.lower().eq("true")
    df["direction"] = df["direction"].fillna(0).astype(int)
    return df


def save_log(log: pd.DataFrame, path) -> None:
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    out = log[COLUMNS].copy()
    for c in DATE_COLS:
        out[c] = pd.to_datetime(out[c]).dt.strftime("%Y-%m-%d")
    out.to_csv(path, index=False)


def _close(log, i, date, price, reason, run_id=""):
    log.at[i, "status"] = "closed"; log.at[i, "close_date"] = date; log.at[i, "close_price"] = price
    log.at[i, "close_reason"] = reason; log.at[i, "close_run_id"] = run_id
    log.at[i, "rearm"] = reason == "stopped_firing"


def _set_mark(log, i, date, price):
    r = log.loc[i]
    ret = idea_return(r["instrument"], int(r["direction"]), float(r["entry_price"]), price)
    log.at[i, "mark_date"] = date; log.at[i, "mark_price"] = price
    log.at[i, "return_pct"] = 100 * ret; log.at[i, "pnl_mm"] = float(r["notional_mm"]) * ret


def mark(log: pd.DataFrame, prices: pd.DataFrame, as_of, settings=None) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Mark every open idea daily from its entry to as_of, using prices dated on or before as_of only. An idea closes
    on the first close at or through its stop or target, or on the first day at or after its max_exit_date.
    Returns (log, daily marks with idea_id, date, price, return_pct, pnl_mm)."""
    as_of = pd.Timestamp(as_of).normalize()
    log = log.copy()
    px = _weekdays(prices).loc[:as_of] if prices is not None and len(prices) else pd.DataFrame()
    marks = []
    for i in log.index[log["status"] == "open"]:
        r = log.loc[i]
        if pd.Timestamp(r["entry_date"] if pd.notna(r["entry_date"]) else r["as_of"]) > as_of:
            continue                                                            # entered after as_of: nothing to mark yet
        mx = pd.Timestamp(r["max_exit_date"])
        if not r["markable"]:
            if as_of >= mx:
                _close(log, i, mx, np.nan, "max_holding")
            continue
        s = px[r["ticker"]].dropna() if r["ticker"] in px.columns else pd.Series(dtype=float)
        s = s[(s.index > pd.Timestamp(r["entry_date"])) & (s > 0)]
        d = int(r["direction"]); closed = False
        for date, p in s.items():
            _set_mark(log, i, date, float(p))
            marks.append({"idea_id": r["idea_id"], "date": date, "price": float(p), "return_pct": log.at[i, "return_pct"], "pnl_mm": log.at[i, "pnl_mm"]})
            hit_stop = pd.notna(r["stop"]) and (p <= r["stop"] if d > 0 else p >= r["stop"])
            hit_target = pd.notna(r["target"]) and (p >= r["target"] if d > 0 else p <= r["target"])
            reason = "stop" if hit_stop else "target" if hit_target else "max_holding" if date >= mx else None
            if reason:
                _close(log, i, date, float(p), reason); closed = True
                break
        if not closed and as_of >= mx:                                          # horizon passed with no price on/after it
            last = log.at[i, "mark_price"] if pd.notna(log.at[i, "mark_price"]) else r["entry_price"]
            if pd.isna(log.at[i, "mark_price"]):
                _set_mark(log, i, pd.Timestamp(r["entry_date"]), float(last))
            _close(log, i, pd.Timestamp(log.at[i, "mark_date"]), float(last), "max_holding")
    return log, pd.DataFrame(marks, columns=["idea_id", "date", "price", "return_pct", "pnl_mm"])


def update_log(log: pd.DataFrame, run, u, settings, prices: pd.DataFrame | None) -> pd.DataFrame:
    """Advance the log by one run: mark open ideas to the run's as_of, close open ideas the run no longer fires, open
    new ideas for firings with no open idea (a re-fire never duplicates). After a stop, target or max-holding exit the
    idea re-arms only once it has stopped firing, so one signal episode gives one idea."""
    ideas = run_ideas(run, u, settings)
    run_id, as_of, _, _ = _run_parts(run)
    log, _ = mark(log if len(log) else empty_log(), prices, as_of, settings)
    px = _weekdays(prices).loc[:as_of] if prices is not None and len(prices) else pd.DataFrame()
    stale = int(_param(settings, "max_stale_days"))
    firing = set(zip(ideas["trade_id"], ideas["country"])) if len(ideas) else set()
    keys = list(zip(log["trade_id"], log["country"]))

    for i, k in zip(log.index, keys):
        r = log.loc[i]
        if r["status"] == "open" and k not in firing and pd.Timestamp(r["entry_date"] if pd.notna(r["entry_date"]) else r["as_of"]) <= as_of:
            price = np.nan; date = as_of
            if r["markable"] and r["ticker"] in px.columns:
                d0, p0 = _price_on(px[r["ticker"]], as_of, stale)
                if d0 is not None:
                    date, price = d0, p0
                    _set_mark(log, i, d0, p0)
            _close(log, i, date, price, "stopped_firing", run_id)
        elif r["status"] == "closed" and k not in firing and not r["rearm"]:
            log.at[i, "rearm"] = True
        if k in firing:
            log.at[i, "last_fired_as_of"] = as_of

    new = []
    for _, t in ideas.iterrows():
        k = (t["trade_id"], t["country"])
        mine = log[(log["trade_id"] == k[0]) & (log["country"] == k[1])]
        if (mine["status"] == "open").any():
            continue
        if len(mine) and not bool(mine.sort_values("as_of").iloc[-1]["rearm"]):
            continue                                                            # same episode, exited on stop/target/max
        entry_date, entry_price, vol, stop, target = pd.NaT, np.nan, np.nan, np.nan, np.nan
        tick, why = t["ticker"], t["unmarked_reason"]
        if tick and tick not in px.columns:
            why = f"ticker {tick} not in market history"
        elif tick:
            d0, p0 = _price_on(px[tick], as_of, stale)
            if d0 is None:
                why = f"no {tick} price within {stale} days before as_of"
            else:
                entry_date, entry_price = d0, p0
                vol = _vol_3m(px[tick], d0, int(_param(settings, "vol_window_days")), int(_param(settings, "min_vol_obs")))
                if pd.notna(vol):
                    sd, td = float(_param(settings, "stop_vol_mult")) * vol, float(_param(settings, "target_vol_mult")) * vol
                    d = int(t["direction"])
                    stop, target = p0 * math.exp(-d * sd), p0 * math.exp(d * td)
        markable = pd.notna(entry_price)
        start = entry_date if markable else as_of
        months = max_hold_months(t["horizon"], int(_param(settings, "default_max_hold_months")))
        new.append({**{c: t[c] for c in ("run_id", "as_of", "trade_id", "strategy", "country", "iso", "stance", "instrument",
                                         "signal_value", "regime", "notional_mm", "country_notional_mm")},
                    "idea_id": f"{t['trade_id']}-{t['iso']}-{as_of:%Y%m%d}", "ticker": tick if markable else "",
                    "direction": int(t["direction"]) if markable else 0, "markable": markable, "unmarked_reason": "" if markable else why,
                    "entry_date": entry_date, "entry_price": entry_price, "vol_3m": vol, "stop": stop, "target": target,
                    "max_exit_date": start + pd.DateOffset(months=months), "status": "open", "rearm": False, "last_fired_as_of": as_of,
                    "mark_date": entry_date, "mark_price": entry_price, "return_pct": 0.0 if markable else np.nan,
                    "pnl_mm": 0.0 if markable else np.nan, "close_date": pd.NaT, "close_price": np.nan, "close_reason": "", "close_run_id": ""})
    if new:
        add = pd.DataFrame(new)[COLUMNS]
        log = add if not len(log) else pd.concat([log, add], ignore_index=True)
    return log.reset_index(drop=True)


# --- report ----------------------------------------------------------------------------------------------------

def _group_stats(g: pd.DataFrame) -> dict:
    marked = g[g["markable"]]
    closed = marked[marked["status"] == "closed"]
    hits = closed["return_pct"] > 0
    seen = marked[pd.to_datetime(marked["mark_date"]) > pd.to_datetime(marked["entry_date"])]   # marked at least once after entry
    return {"ideas": len(g), "open": int((g["status"] == "open").sum()), "closed": int((g["status"] == "closed").sum()),
            "marked": len(marked), "unmarked": len(g) - len(marked), "unmarked_share": (len(g) - len(marked)) / len(g) if len(g) else np.nan,
            "closed_marked": len(closed), "hit_rate": float(hits.mean()) if len(closed) else np.nan,
            "hit_rate_incl_open": float((seen["return_pct"] > 0).mean()) if len(seen) else np.nan,
            "pnl_realised_mm": float(closed["pnl_mm"].sum()), "pnl_open_mm": float(marked.loc[marked["status"] == "open", "pnl_mm"].sum()),
            "pnl_total_mm": float(marked["pnl_mm"].sum()), "notional_mm": float(g["notional_mm"].sum()),
            **{f"n_{r}": int((g["close_reason"] == r).sum()) for r in CLOSE_REASONS}}


def idea_report(log: pd.DataFrame) -> pd.DataFrame:
    """Rows: one 'all' row, one per playbook id, one per stance, one per instrument. hit_rate is the share of closed,
    marked ideas with a positive return; hit_rate_incl_open also counts open ideas at their latest mark (ideas not yet
    marked after entry are left out of it)."""
    rows = [{"group": "all", "key": "all", "label": "All ideas", **_group_stats(log)}]
    names = dict(zip(log["trade_id"], log["strategy"]))
    for col, grp in (("trade_id", "playbook_id"), ("stance", "stance"), ("instrument", "instrument")):
        for k, g in log.groupby(col, sort=True):
            rows.append({"group": grp, "key": k, "label": names.get(k, k) if grp == "playbook_id" else k, **_group_stats(g)})
    return pd.DataFrame(rows)


def _fmt(v, pct=False, nd=2):
    if v is None or (isinstance(v, float) and np.isnan(v)):
        return "n/a"
    return f"{100 * v:.0f}%" if pct else (f"{v:.{nd}f}" if isinstance(v, float) else str(v))


def report_markdown(rep: pd.DataFrame, log: pd.DataFrame, as_of=None) -> str:
    a = rep.iloc[0]
    lines = ["# Trade-idea log report", "",
             "Illustrative (Tier 3, GOV-032): ideas are the Playbook activations sized by the dashboard rule; no reported,",
             "limit-tested or sized number reads this log. P&L excludes carry, financing and costs.", "",
             f"As of {pd.Timestamp(as_of).date() if as_of is not None else 'n/a'}. Ideas {a['ideas']} ({a['open']} open, {a['closed']} closed); "
             f"marked {a['marked']}, unmarked {a['unmarked']} ({_fmt(a['unmarked_share'], pct=True)} unmarked). "
             f"Hit rate (closed, marked) {_fmt(a['hit_rate'], pct=True)} on {a['closed_marked']}; P&L {_fmt(a['pnl_total_mm'])} $mm "
             f"(realised {_fmt(a['pnl_realised_mm'])}, open {_fmt(a['pnl_open_mm'])}).", ""]
    hdr = "| {} | Ideas | Open | Marked | Unmarked | Hit rate | Hit incl. open | P&L realised $mm | P&L open $mm | Stop / target / max / unfired |"
    for grp, title in (("playbook_id", "Playbook id"), ("stance", "Stance"), ("instrument", "Instrument")):
        sub = rep[rep["group"] == grp]
        lines += [f"## By {title.lower()}", "", hdr.format(title), "|---|---|---|---|---|---|---|---|---|---|"]
        for _, r in sub.iterrows():
            key = f"{r['key']} {r['label']}" if grp == "playbook_id" else r["key"]
            lines.append(f"| {key} | {r['ideas']} | {r['open']} | {r['marked']} | {r['unmarked']} | {_fmt(r['hit_rate'], pct=True)} | "
                         f"{_fmt(r['hit_rate_incl_open'], pct=True)} | {_fmt(r['pnl_realised_mm'])} | {_fmt(r['pnl_open_mm'])} | "
                         f"{r['n_stop']} / {r['n_target']} / {r['n_max_holding']} / {r['n_stopped_firing']} |")
        lines.append("")
    why = log.loc[~log["markable"], "unmarked_reason"].value_counts()
    if len(why):
        lines += ["## Why ideas are unmarked", ""] + [f"- {k}: {v}" for k, v in why.items()] + [""]
    return "\n".join(lines)


def _csv_safe(df: pd.DataFrame) -> pd.DataFrame:
    """Text cells starting with = + - @ get a leading apostrophe, so a spreadsheet never runs them as a formula."""
    out = df.copy()
    for c in out.columns:
        if not pd.api.types.is_numeric_dtype(out[c]):
            out[c] = out[c].map(lambda v: "'" + v if isinstance(v, str) and v[:1] in ("=", "+", "-", "@") else v)
    return out


def write_report(log: pd.DataFrame, out_dir, as_of=None) -> pd.DataFrame:
    rep = idea_report(log)
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    _csv_safe(rep).to_csv(out / "idea_report.csv", index=False)
    (out / "idea_report.md").write_text(report_markdown(rep, log, as_of))
    return rep


def log_run(run, u, settings, prices: pd.DataFrame | None, out_dir, log=print) -> pd.DataFrame:
    """The daily job: load outputs/idea_log.csv, advance it by `run`, save it and rewrite the report."""
    path = Path(out_dir) / "idea_log.csv"
    lg = update_log(load_log(path), run, u, settings, prices)
    save_log(lg, path)
    _, as_of, _, _ = _run_parts(run)
    rep = write_report(lg, out_dir, as_of)
    a = rep.iloc[0]
    log(f"[ideas] {as_of.date()}: {a['ideas']} ideas ({a['open']} open, {a['closed']} closed), {a['marked']} marked, "
        f"{_fmt(a['unmarked_share'], pct=True)} unmarked; P&L {a['pnl_total_mm']:.3f} $mm")
    return lg


def mark_log(out_dir, prices: pd.DataFrame, as_of, settings=None, log=print) -> pd.DataFrame:
    """The daily mark without a new run: load outputs/idea_log.csv, mark open ideas to as_of, save, rewrite the report."""
    path = Path(out_dir) / "idea_log.csv"
    lg, marks = mark(load_log(path), prices, as_of, settings)
    save_log(lg, path)
    # the report's As of never moves back: a mark to the last complete price day can be earlier than the latest run
    if len(lg) and lg["as_of"].notna().any():
        as_of = max(pd.Timestamp(as_of), pd.to_datetime(lg["as_of"]).max())
    rep = write_report(lg, out_dir, as_of)
    a = rep.iloc[0]
    log(f"[ideas] marked to {pd.Timestamp(as_of).date()}: {a['open']} open, {a['closed']} closed; P&L {a['pnl_total_mm']:.3f} $mm")
    return lg
