"""Calendar-gated evidence monitor (EQ-B-0061): how far each slow-accumulating validation test has got, and when it can
first be run.

Three pieces of evidence only accumulate with the calendar:

  var_record_250d     the daily VaR forecast record (data/forecast_record.csv, validation/record.py). Kupiec and the
                      Basel traffic light have power from 250 tested days (docs/validation/backtests-and-forecast-record.md).
                      Progress: tested rows (loss, var and es present). Earliest test date: the 250th tested row's date,
                      or, until then, the last tested date + the missing count in weekdays (the record is kept on
                      weekdays, record._weekdays): the earliest it can arrive, if every weekday after the last tested
                      date gets a row (late days by `econquest record --backfill`).
  benchmark_12m       12-month PD benchmark scoring (data/benchmarks.csv, validation/benchmarks.py). A snapshot row can
                      be scored once it is 12 months old and was not taken during a default spell (matured_outcomes).
                      Progress: days since the oldest eligible snapshot. Earliest test date: the first maturity.
  idea_quarters       trade-idea hit rate (outputs/idea_log.csv, validation/idea_log.py) needs about four quarters of
                      daily marks (docs/validation/signals-trades.md, gap assessment E7). Progress: days from the first
                      logged idea to the latest mark. Earliest test date: first idea + 4 x 3 months.

Status: "testable" once the requirement is met on or before `as_of`; "overdue" when the earliest test date has passed
and the requirement is still not met (the record or the marks stopped); otherwise "accumulating".

Point in time: only data stored on or before `as_of` counts: record rows dated and recorded (`recorded_at`, including
"backfill <timestamp>") on or before `as_of`, benchmark snapshots dated on or before it, ideas opened on or before it
and marks dated on or before it. The idea log keeps only the latest mark, so a mark dated after `as_of` is ignored
(not counted up to `as_of`): a replay then shows the progress it can prove, and an "overdue" is never hidden. No number reads the wall clock: `as_of` is required. Read-only; Tier 3 (no reported number reads it).
"""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd

from .benchmarks import HORIZONS, load_history, matured_outcomes
from .idea_log import load_log
from .record import load_record, record_for_backtest

RECORD_DAYS = 250                  # tested days for Kupiec / Basel traffic light at alpha 0.99
BENCHMARK_MONTHS = HORIZONS["12m"]
IDEA_QUARTERS = 4                  # quarters of daily marks before a hit rate means anything (E7)
STATUSES = ("accumulating", "testable", "overdue")
COLUMNS = ["evidence", "source", "unit", "progress", "required", "progress_pct", "first_obs", "last_obs", "lag_days",
           "earliest_test_date", "days_to_test", "status", "note"]


def _as_of(as_of) -> pd.Timestamp:
    if as_of is None or (isinstance(as_of, str) and not as_of.strip()):
        raise ValueError("as_of is required: the evidence monitor never reads the wall clock")
    return pd.Timestamp(as_of).normalize()


def _d(ts) -> str:
    return "" if ts is None or pd.isna(ts) else pd.Timestamp(ts).strftime("%Y-%m-%d")


def _status(met: bool, earliest, t: pd.Timestamp) -> str:
    if met:
        return "testable"
    return "overdue" if earliest is not None and pd.notna(earliest) and pd.Timestamp(earliest) <= t else "accumulating"


def _row(evidence, source, unit, progress, required, first, last, earliest, met, t, note) -> dict:
    return {"evidence": evidence, "source": source, "unit": unit, "progress": int(progress), "required": int(required),
            "progress_pct": round(100.0 * min(progress, required) / required, 1) if required else np.nan,
            "first_obs": _d(first), "last_obs": _d(last),
            "lag_days": int((t - pd.Timestamp(last)).days) if last is not None and pd.notna(last) else np.nan,
            "earliest_test_date": _d(earliest),
            "days_to_test": int((pd.Timestamp(earliest) - t).days) if earliest is not None and pd.notna(earliest) else np.nan,
            "status": _status(met, earliest, t), "note": note}


def _recorded_on(s: pd.Series) -> pd.Series:
    """Date part of `recorded_at` ("2026-10-23T04:27:13+00:00" or "backfill 2026-10-23T..."); NaT when absent."""
    txt = s.astype(str).str.replace("backfill", "", regex=False).str.strip().str.slice(0, 10)
    return pd.to_datetime(txt, errors="coerce", format="%Y-%m-%d")


def record_progress(record: pd.DataFrame, as_of, required: int = RECORD_DAYS) -> dict:
    """The 250-day forecast record row. `record` as validation.record.load_record returns it."""
    t = _as_of(as_of)
    rec = record.copy() if record is not None else pd.DataFrame(columns=["date", "loss", "var", "es", "recorded_at"])
    if len(rec):
        rec["date"] = pd.to_datetime(rec["date"])
        known = _recorded_on(rec["recorded_at"]) if "recorded_at" in rec else pd.Series(pd.NaT, index=rec.index)
        rec = rec[(rec["date"] <= t) & (known.isna() | (known <= t))]
    tested = record_for_backtest(rec) if len(rec) else rec
    n = len(tested)
    first = tested["date"].min() if n else None
    last = tested["date"].max() if n else None
    if n >= required:
        earliest = tested["date"].sort_values().iloc[required - 1]
    else:
        anchor = last if last is not None else t
        earliest = anchor + pd.offsets.BDay(required - n)
    nb = int(rec["recorded_at"].astype(str).str.startswith("backfill").sum()) if len(rec) and "recorded_at" in rec else 0
    note = f"{n} tested of {len(rec)} rows; {nb} backfilled, {len(rec) - nb} taken daily"
    if n < required:
        note += f"; {required - n} weekdays to go"
    return _row("var_record_250d", "data/forecast_record.csv", "tested days", n, required, first, last, earliest,
                n >= required, t, note)


def benchmark_progress(history: pd.DataFrame, events: pd.DataFrame | None, as_of, months: int = BENCHMARK_MONTHS) -> dict:
    """The 12-month benchmark scoring row. `history` as validation.benchmarks.load_history returns it, `events` the
    default episodes (data/panel/sovereign_defaults.csv) or None."""
    t = _as_of(as_of)
    h = history.copy() if history is not None else pd.DataFrame(columns=["date"])
    if len(h):
        h = h[pd.to_datetime(h["date"]) <= t]
    m = matured_outcomes(h, events, t, months)
    elig = m[~m["in_spell"].astype(bool)] if len(m) else m
    n_dates = int(pd.to_datetime(h["date"]).nunique()) if len(h) else 0
    if len(elig):
        first = pd.Timestamp(elig["date"].min()); last = pd.Timestamp(elig["date"].max())
        earliest = pd.Timestamp(elig["maturity"].min()); matured = int(elig["matured"].astype(bool).sum())
        progress, required = (t - first).days, (earliest - first).days
        note = (f"{len(h)} snapshot rows on {n_dates} date(s), {len(m) - len(elig)} in a default spell, "
                f"{matured} matured")
    else:
        first = last = None; matured = 0
        earliest = t + pd.DateOffset(months=months)
        progress, required = 0, (earliest - t).days
        note = ("no eligible snapshot yet" if not len(h) else f"all {len(h)} snapshot rows are in a default spell") + \
               f"; a snapshot taken on {_d(t)} matures {_d(earliest)}"
    return _row(f"benchmark_{months}m", "data/benchmarks.csv", "days since first snapshot", progress, required, first,
                last, earliest, matured > 0, t, note)


def idea_progress(log: pd.DataFrame, as_of, quarters: int = IDEA_QUARTERS) -> dict:
    """The trade-idea quarters row. `log` as validation.idea_log.load_log returns it."""
    t = _as_of(as_of)
    lg = log.copy() if log is not None else pd.DataFrame(columns=["as_of", "mark_date"])
    if len(lg):
        lg["as_of"] = pd.to_datetime(lg["as_of"]); lg["mark_date"] = pd.to_datetime(lg["mark_date"])
        lg = lg[lg["as_of"] <= t]
    if len(lg):
        first = lg["as_of"].min()
        marks = lg["mark_date"].dropna()
        marks = marks[marks <= t]                              # point in time: a later mark is not evidence at as_of
        last = marks.max() if len(marks) else None
        earliest = first + pd.DateOffset(months=3 * quarters)
        progress = (last - first).days if last is not None else 0
        required = (earliest - first).days
        mk = lg["markable"].astype(str).str.lower().eq("true") if "markable" in lg else pd.Series(False, index=lg.index)
        closed = lg["status"].astype(str).eq("closed") if "status" in lg else pd.Series(False, index=lg.index)
        if "close_date" in lg:
            closed &= pd.to_datetime(lg["close_date"]).le(t).fillna(False)
        done_q = sum(1 for k in range(1, quarters + 1) if last is not None and first + pd.DateOffset(months=3 * k) <= last)
        note = (f"{len(lg)} ideas, {int(mk.sum())} markable, {int((closed & mk).sum())} closed and marked; "
                f"{done_q} of {quarters} quarters marked")
        met = last is not None and last >= earliest
    else:
        first = last = None
        earliest = t + pd.DateOffset(months=3 * quarters)
        progress, required, met = 0, (earliest - t).days, False
        note = f"no idea logged yet; an idea logged on {_d(t)} reaches {quarters} quarters on {_d(earliest)}"
    return _row(f"idea_quarters_{quarters}q", "outputs/idea_log.csv", "days of daily marks", progress, required, first,
                last, earliest, met, t, note)


def evidence_table(record: pd.DataFrame | None, history: pd.DataFrame | None, events: pd.DataFrame | None,
                   idea_log: pd.DataFrame | None, as_of, record_days: int = RECORD_DAYS,
                   benchmark_months: int = BENCHMARK_MONTHS, idea_quarters: int = IDEA_QUARTERS) -> pd.DataFrame:
    """One row per calendar-gated test (COLUMNS), from data already loaded. Pure: no file or clock read."""
    rows = [record_progress(record, as_of, record_days), benchmark_progress(history, events, as_of, benchmark_months),
            idea_progress(idea_log, as_of, idea_quarters)]
    out = pd.DataFrame(rows, columns=COLUMNS)
    out.attrs["as_of"] = _d(_as_of(as_of))
    return out


def evidence_monitor(as_of, data_dir="data", out_dir="outputs", **kw) -> pd.DataFrame:
    """evidence_table from the stored files: data/forecast_record.csv, data/benchmarks.csv,
    data/panel/sovereign_defaults.csv and outputs/idea_log.csv. Missing files count as no data."""
    data, out = Path(data_dir), Path(out_dir)
    epath = data / "panel" / "sovereign_defaults.csv"
    events = pd.read_csv(epath) if epath.exists() else None
    return evidence_table(load_record(data / "forecast_record.csv"), load_history(data / "benchmarks.csv"), events,
                          load_log(out / "idea_log.csv"), as_of, **kw)


def monitor_markdown(table: pd.DataFrame, as_of=None) -> str:
    """The table as a markdown section."""
    a = _d(_as_of(as_of)) if as_of is not None else table.attrs.get("as_of", "")
    head = ["Evidence", "Progress", "First", "Last", "Earliest test", "Days to test", "Status", "Note"]
    lines = [f"## Calendar-gated evidence, as of {a}", "", "| " + " | ".join(head) + " |", "|" + "---|" * len(head)]
    for r in table.to_dict(orient="records"):
        prog = f"{r['progress']} / {r['required']} {r['unit']} ({r['progress_pct']:.1f}%)"
        dtt = "" if pd.isna(r["days_to_test"]) else str(int(r["days_to_test"]))
        lines.append(f"| {r['evidence']} | {prog} | {r['first_obs']} | {r['last_obs']} | {r['earliest_test_date']} | {dtt} | "
                     f"{r['status']} | {r['note']} |")
    return "\n".join(lines) + "\n"


def write_monitor(table: pd.DataFrame, out_dir) -> tuple[Path, Path]:
    """Write evidence_monitor.csv and evidence_monitor.md to `out_dir`."""
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    csv, md = out / "evidence_monitor.csv", out / "evidence_monitor.md"
    table.to_csv(csv, index=False)
    md.write_text(monitor_markdown(table))
    return csv, md
