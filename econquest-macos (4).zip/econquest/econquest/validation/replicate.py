"""Independent replication of the reported numbers (EQ-B-0051, GOV-042).

Reruns every number in the 0.1.4 release note (docs/governance/releases/0.1.4-2026-10-23.md) and the key
numbers of the validation documents from public functions and the stored inputs in `--data`, and writes a
pass/fail table. It never reads the run archive, `outputs/*.json` or any other result file: every figure is
recomputed here.

    python -m econquest.validation.replicate --data data --out outputs/replication
    python -m econquest.validation.replicate --data data --out /tmp/rep --quick --only release,backtest

Status per check:
- PASS: recomputed value within tolerance of the reported value.
- FAIL: outside tolerance and the source gives no reason to expect a difference. Exit code 1.
- STALE: outside tolerance, and the reported value is known to predate a recorded change (the check names it).
  The document needs refreshing; not a replication failure of the current model. Every STALE check carries a
  drift band (EQ-B-0054): the current value it was last seen at, with the same tolerance rule; a recomputed value
  outside that band is a FAIL, so a regression on a stale item still fails the run. A stale reason without a
  current value is a FAIL.
- INFO: recorded for the reader (hashes, environment), not compared.
- SKIP: not run in this mode or the input is missing.

Tolerance. Full mode recomputes at the stated path count with the stated seed (scrambled Sobol, seed 7), so the
numbers are deterministic: the tolerance is half a unit of the reported last digit, widened to 0.1 percent of the
value as a platform allowance (numpy/scipy builds). Quick mode (`--quick`) runs every Monte Carlo check at
20,000 requested paths (32,768 Sobol); checks stated at a larger count are compared with a loose tolerance
(3 percent on VaR/ES/L-VaR, 0.15 $mm on EL, 6 points on a stress change in percent); deterministic checks keep
their full-mode tolerance. GARCH refits (about a minute) run in full mode only.
"""
from __future__ import annotations

import argparse
import math
import sys
import time
from dataclasses import dataclass, field
from pathlib import Path

import numpy as np
import pandas as pd

AS_OF = "2026-10-23"
# Last price row the 0.1.4 release run saw. The daily record job appends a close to prices.csv every trading day
# (including AS_OF itself), so replication pins the price history here instead of reading whatever has grown since.
PRICES_THROUGH = "2026-10-22"
# The price history the release ran on, frozen with the release (Team A backfills series in prices.csv, e.g. INDA on
# 2026-10-23 22:24Z, which moves the estimated loadings). Used for the Monte Carlo runs when present.
FROZEN_PRICES = Path(__file__).resolve().parents[2] / "docs" / "governance" / "releases" / "inputs" / "0.1.4" / "prices.csv"
RELEASE = "docs/governance/releases/0.1.4-2026-10-23.md"
QUICK_PATHS = 20_000
GROUPS = ("release", "docs", "backtest", "hazard", "scorecard", "garch")

# Settings that reproduce the 0.1.3 assumptions on today's assumptions.json (0.1.4 only added these two keys
# with non-default values; CHG-20261023T190523Z-b96d25).
PRE_014 = {"monte_carlo.vol_source": "regime", "copula.source": "judgement"}
FX_SCALE_ONE = {"Float": 1.0, "Managed": 1.0, "Peg": 1.0, "Dollarized": 1.0, "default": 1.0}


@dataclass
class Check:
    id: str
    group: str
    source: str            # document and place the reported value comes from
    quantity: str
    reported: object
    recomputed: object = None
    tolerance: float | None = None
    status: str = "SKIP"
    note: str = ""


@dataclass
class Ctx:
    data: Path
    quick: bool
    log: object = print
    prices: Path | None = None
    _u: object = None
    _s: object = None
    runs: dict = field(default_factory=dict)

    def universe(self):
        if self._u is None:
            from econquest.config import Settings
            from econquest.ingestion import load_universe
            self._u = load_universe(self.data)
            if self.prices is not None and Path(self.prices).is_file():
                self._u.prices = pd.read_csv(self.prices, parse_dates=["date"], index_col="date")
            else:
                self.log(f"  frozen release prices not found ({self.prices}); using {self.data}/market_history/prices.csv "
                         f"up to {PRICES_THROUGH}, which may have been revised since the release")
            px = getattr(self._u, "prices", None)
            if px is not None and len(px):
                d = pd.to_datetime(px["date"] if "date" in px.columns else px.index)
                self._u.prices = px[np.asarray(d <= pd.Timestamp(PRICES_THROUGH))]
            self._s = Settings.load(self.data / "assumptions.json")
        return self._u, self._s


# ---------------------------------------------------------------------------------------------- comparison

def decimals(x) -> int:
    """Decimals shown in a reported number. Reported values are written as strings where trailing zeros
    carry precision ("74.70" -> 2, "0.0320" -> 4); floats use their repr (74.35 -> 2)."""
    s = repr(x) if isinstance(x, float) else str(x)
    return len(s.split(".")[1]) if "." in s else 0


def as_number(x) -> float | None:
    if isinstance(x, bool):
        return None
    try:
        return float(x)
    except (TypeError, ValueError):
        return None


def full_tolerance(reported) -> float:
    """Half a unit of the last reported digit; non-integers get a 0.1 percent platform allowance."""
    half = 0.5 * 10 ** -decimals(reported)
    return half if decimals(reported) == 0 else max(half, 0.001 * abs(float(reported)))


def compare(c: Check, value, tol: float | None = None, stale_reason: str | None = None, stale_current=None) -> Check:
    """Fill recomputed/tolerance/status. Strings and bools compare exactly.

    `stale_reason` with `stale_current` (the value the stale item is known to sit at today): outside tolerance of
    the reported value gives STALE only while the recomputed value stays within the drift band around
    `stale_current` (same tolerance rule as the reported value, or `tol`); otherwise FAIL."""
    c.recomputed = value
    if value is None or (isinstance(value, float) and math.isnan(value)):
        c.status, c.note = "FAIL", (c.note + "; " if c.note else "") + "not computable"
        return c
    if as_number(c.reported) is None or as_number(value) is None:
        ok = str(value) == str(c.reported)
        c.tolerance = None
    else:
        c.tolerance = full_tolerance(c.reported) if tol is None else tol
        ok = abs(float(value) - float(c.reported)) <= c.tolerance + 1e-12
    if ok:
        c.status = "PASS"
    elif stale_reason:
        c.note = (c.note + "; " if c.note else "") + stale_reason
        cur = as_number(stale_current)
        if cur is None or as_number(value) is None:
            c.status = "FAIL"; c.note += "; no drift band (stale_current missing)"
            return c
        band = full_tolerance(stale_current) if tol is None else tol
        if abs(float(value) - cur) <= band + 1e-12:
            c.status = "STALE"; c.note += f"; drift band {_fmt(cur)} +/- {_fmt(band)}"
        else:
            c.status = "FAIL"; c.note += f"; moved beyond drift band {_fmt(cur)} +/- {_fmt(band)}"
    else:
        c.status = "FAIL"
    return c


MC_LOOSE = {"var99_mm": ("rel", 0.03), "es99_mm": ("rel", 0.03), "lvar99_mm": ("rel", 0.03), "expected_loss_mm": ("abs", 0.15),
            "change_pct": ("abs", 6.0), "mean_corr": ("abs", 0.005)}


def mc_tol(ctx: Ctx, kind: str, reported: float, stated_paths: int) -> float | None:
    """None = full tolerance. Loose only when quick mode runs below the stated path count."""
    if not ctx.quick or stated_paths <= QUICK_PATHS:
        return None
    how, v = MC_LOOSE.get(kind, ("rel", 0.03))
    return max(full_tolerance(reported), v * abs(float(reported)) if how == "rel" else v)


def run(ctx: Ctx, stated_paths: int, patches: dict | None = None, scenario: str | None = None):
    """One pipeline run (cached) at the stated count, or at QUICK_PATHS in quick mode."""
    from econquest.engine.pipeline import run_pipeline
    from econquest.engine.stress import load_scenarios
    paths = min(stated_paths, QUICK_PATHS) if ctx.quick else stated_paths
    key = (paths, tuple(sorted((k, repr(v)) for k, v in (patches or {}).items())), scenario)
    if key not in ctx.runs:
        u, s = ctx.universe()
        if patches:
            s = s.copy_with(**patches)
        if scenario:
            u, s = load_scenarios(ctx.data / "scenarios.json")[scenario].apply(u, s)
        t = time.perf_counter()
        r = run_pipeline(u, s, label=f"replicate-{scenario or 'base'}", paths=paths, as_of=AS_OF)
        ctx.log(f"  run paths={paths} patches={patches or {}} scenario={scenario or '-'}: {time.perf_counter() - t:.1f} s")
        ctx.runs[key] = r
    return ctx.runs[key]


# ---------------------------------------------------------------------------------------------- groups

STRESS_ES99 = {"A": (155.5, 61.2), "B": (102.9, 6.7), "C": (114.9, 19.1), "DOWNGRADE": (101.7, 5.4),
               "TAIWAN": (165.1, 71.1), "HORMUZ": (167.1, 73.2), "TARIFF": (154.8, 60.5), "CHINA_HL": (165.2, 71.2)}


def group_release(ctx: Ctx) -> list[Check]:
    out = []
    base = run(ctx, 100_000)
    m = base.metrics
    for cid, k, rep in (("R01", "var99_mm", 74.35), ("R02", "es99_mm", 96.48), ("R03", "expected_loss_mm", 0.45), ("R04", "lvar99_mm", 79.63)):
        out.append(compare(Check(cid, "release", f"{RELEASE} Effect table, 0.1.4 base", f"base {k} ($mm), 100,000 requested, as_of {AS_OF}", rep),
                           float(m[k]), mc_tol(ctx, k, rep, 100_000)))
    c = Check("R05", "release", f"{RELEASE} Effect", "Sobol paths simulated for 100,000 requested", 131072)
    out.append(compare(c, int(m["paths"])) if not ctx.quick else _skip(c, "quick mode runs 20,000 requested"))
    from econquest.engine.limits import load_limits
    lim = load_limits(ctx.data / "limits.json")["book"]
    for cid, k, rep in (("R06", "es99_mm", 84), ("R07", "var99_mm", 78), ("R08", "lvar99_mm", 80)):
        val = 100 * float(m[k]) / float(lim[k])
        out.append(compare(Check(cid, "release", f"{RELEASE} Limits", f"book {k} as percent of data/limits.json limit", rep), val,
                           None if not ctx.quick else 5.0))
    i = 9
    for key, (es_rep, chg_rep) in STRESS_ES99.items():
        r2 = run(ctx, 100_000, scenario=key)
        es = float(r2.metrics["es99_mm"]); chg = 100 * (es / float(m["es99_mm"]) - 1)
        out.append(compare(Check(f"R{i:02d}", "release", f"{RELEASE} Stress runs", f"stress {key} ES99 ($mm)", es_rep), es,
                           mc_tol(ctx, "es99_mm", es_rep, 100_000))); i += 1
        out.append(compare(Check(f"R{i:02d}", "release", f"{RELEASE} Stress runs", f"stress {key} ES99 change vs base (%)", chg_rep), chg,
                           mc_tol(ctx, "change_pct", chg_rep, 100_000))); i += 1
    ld = base.diagnostics["loadings"]
    for country, rep in (("Singapore", 0.81), ("South Korea", 0.51), ("Malaysia", 0.51)):
        out.append(compare(Check(f"R{i:02d}", "release", f"{RELEASE} How the new values work", f"estimated Calm global loading {country}", rep),
                           float(ld[country]))); i += 1
    pos = base.positions
    ewy = pos[pos["vol_from"].astype(str) == "garch:EWY"]
    out.append(compare(Check(f"R{i:02d}", "release", "docs/validation/garch-dcc.md Monte Carlo marginals (P07)", "EWY 12-month GARCH vol in the Monte Carlo (%)", 42.8),
                       float(ewy["market_vol_pct"].iloc[0]) if len(ewy) else None)); i += 1
    # PD moves: none (both 0.1.4 changes sit in layers 5 and 6)
    pre = run(ctx, 100_000, PRE_014)
    dpd = float(np.max(np.abs(base.country["pd_default"].to_numpy() - pre.country["pd_default"].to_numpy())))
    out.append(compare(Check(f"R{i:02d}", "release", f"{RELEASE} Effect", "largest PD move from the 0.1.4 change (pp)", 0.0), 100 * dpd, 1e-9)); i += 1
    v = (base.provenance or {}).get("versions") or {}
    for k, rep in (("code_hash", "aa838e7b3c2afa89"), ("data_hash", "d26e6518631437a3")):
        c = Check(f"R{i:02d}", "release", f"{RELEASE} Base run hashes", k, rep, v.get(k), status="INFO"); i += 1
        c.note = "same" if v.get(k) == rep else "differs: the files moved since the release (no frozen copy; hash is not evidence of a different model number)"
        out.append(c)
    return out


def _skip(c: Check, why: str) -> Check:
    c.status, c.note = "SKIP", why
    return c


# stated paths, patches, {metric: reported}, source, stale: None (should reproduce) or (reason, {metric: current value})
DOC_RUNS = [
    ("D01", 100_000, PRE_014, {"var99_mm": 63.98, "es99_mm": 83.02, "expected_loss_mm": 0.529, "lvar99_mm": 69.26, "mean_corr": 0.239},
     "copula-montecarlo-layers5-6.md EQ-B-0035/0036 tables; releases/0.1.4 (0.1.3 base)", None),
    ("D02", 100_000, {"monte_carlo.vol_source": "garch", "copula.source": "judgement"},
     {"var99_mm": 63.79, "es99_mm": 81.96, "expected_loss_mm": 0.457, "lvar99_mm": 69.08}, "copula-montecarlo-layers5-6.md EQ-B-0035 (GARCH)", None),
    ("D03", 100_000, {"monte_carlo.vol_source": "regime", "copula.source": "estimated", "copula.nu_source": "judgement"},
     {"var99_mm": "74.70", "es99_mm": 98.34, "expected_loss_mm": 0.525, "mean_corr": 0.335}, "copula-montecarlo-layers5-6.md EQ-B-0036 (estimated loadings, nu 5)", None),
    ("D04", 100_000, {"monte_carlo.vol_source": "regime", "copula.source": "estimated", "copula.nu_source": "estimated"},
     {"var99_mm": 68.59, "es99_mm": 84.87, "expected_loss_mm": 0.605}, "copula-montecarlo-layers5-6.md EQ-B-0036 (loadings and nu)", None),
    ("D05", 20_000, PRE_014, {"var99_mm": 64.2337, "es99_mm": 83.6673, "expected_loss_mm": 0.53438},
     "releases/0.1.4 Evidence (default-is-identical proof); scorecard.md; stress-scenarios.md", None),
    ("D06", 100_000, {**PRE_014, "regime.method": "hmm"}, {"var99_mm": 80.98, "es99_mm": 105.19, "expected_loss_mm": 0.622},
     "regime-layer3.md EQ-B-0036 (hmm)", None),
    ("D07", 100_000, {**PRE_014, "monte_carlo.global_stress_share": 0.4}, {"var99_mm": 73.23, "es99_mm": 96.21, "expected_loss_mm": 0.508},
     "regime-layer3.md EQ-B-0036 (cliff reference, GOV-018)", None),
    ("D08", 20_000, {**PRE_014, "probability.risk_premium_ratio": 1.0, "probability.w_fx_regime_scale": FX_SCALE_ONE},
     {"var99_mm": 68.54, "es99_mm": 87.42, "expected_loss_mm": 1.855}, "bayesian-layer2.md EQ-B-0021 table (pre-0.1.3 base)", None),
    ("D09", 20_000, {**PRE_014, "probability.w_m": 0.35}, {"var99_mm": 63.13, "es99_mm": 82.71, "expected_loss_mm": 0.236},
     "bayesian-layer2.md EQ-B-0021 table (w_m 0.35 + ratio 2 + Peg 0)", None),
    # refreshed to 0.1.4 by EQ-B-0054 (VF-002); before: D10 66.07/85.30/71.35 (0.1.3 settings), D11 68.02/86.92/1.87,
    # D12 60.5 and D13 74.7 (0.1.3 settings, pre GOV-001..005)
    ("D10", 100_000, {}, {"var99_mm": 74.35, "es99_mm": 96.48, "lvar99_mm": 79.63}, "docs/validation/README.md review checklist step 2", None),
    ("D11", 100_000, {}, {"var99_mm": 74.35, "es99_mm": 96.48, "expected_loss_mm": 0.45}, "docs/governance/model-inventory.md components 6-8 (0.1.4 base)", None),
    ("D12", 20_000, {"monte_carlo.df_calm": 30}, {"var99_mm": 69.16}, "docs/validation/README.md review checklist step 4 (df_calm 30, 0.1.4)", None),
    ("D13", 20_000, {"regime.Calm.global_loading": 0.30}, {"var99_mm": 81.26}, "docs/validation/README.md review checklist step 4 (Calm loading 0.30, 0.1.4)", None),
    ("D15", 20_000, {**PRE_014, "monte_carlo.df_calm": 30}, {"var99_mm": 58.52}, "docs/validation/README.md review checklist step 4 (df_calm 30, 0.1.3 settings)", None),
    ("D16", 20_000, {**PRE_014, "regime.Calm.global_loading": 0.30}, {"var99_mm": 72.69},
     "docs/validation/README.md review checklist step 4 (Calm loading 0.30, 0.1.3 settings)", None),
]


def group_docs(ctx: Ctx) -> list[Check]:
    out = []
    for cid, paths, patches, metrics, src, stale in DOC_RUNS:
        r = run(ctx, paths, patches)
        for j, (k, rep) in enumerate(metrics.items(), 1):
            val = float(r.diagnostics["mean_latent_correlation"]) if k == "mean_corr" else float(r.metrics[k])
            c = Check(f"{cid}.{j}", "docs", src if src.startswith("docs/") else ("docs/governance/" if src.startswith("releases") else "docs/validation/") + src,
                      f"{k} at {paths:,} requested, patches {patches or 'none (current assumptions)'}", rep)
            reason, current = stale if stale else (None, {})
            out.append(compare(c, val, mc_tol(ctx, k, rep, paths), reason, current.get(k)))
    # scenario A on the current model vs the policy's restriction 6.6 text and the inventory (11:13 runs)
    base = run(ctx, 100_000); a = run(ctx, 100_000, scenario="A")
    chg = 100 * (float(a.metrics["es99_mm"]) / float(base.metrics["es99_mm"]) - 1)
    out.append(compare(Check("D14", "docs", "docs/governance/model-risk-policy.md 6.6", "scenario A ES99 change (%)", 61.2),
                       chg, 0.5))                                       # was +80% before 0.1.4 (EQ-B-0054 refreshed)
    return out


def group_backtest(ctx: Ctx) -> list[Check]:
    from econquest.validation.backtests import backtest_history
    from econquest.validation.record import record_for_backtest
    out = []
    src = "docs/validation/backtests-and-forecast-record.md Outputs"
    hist = pd.read_csv(ctx.data / "backtest_history.csv")
    b = backtest_history(hist, alpha=0.99)
    rows = [("B01", "120-month history: exceedances", 4, b["kupiec"]["exceedances"]),
            ("B02", "120-month history: Kupiec LR_uc", 4.098, b["kupiec"]["LR_uc"]),
            ("B03", "120-month history: Kupiec p", 0.043, b["kupiec"]["p_value"]),
            ("B04", "120-month history: Christoffersen LR_ind", 0.278, b["christoffersen"]["LR_ind"]),
            ("B05", "120-month history: Christoffersen p_cc", 0.112, b["christoffersen"]["p_value_cc"]),
            ("B06", "120-month history: Acerbi-Szekely Z2", -2.659, b["acerbi_szekely"]["Z2"]),
            ("B07", "120-month history: Basel zone", "Yellow", b["basel_zone"]),
            ("B08", "120-month history: verdict", "Fail", b["verdict"])]
    rec_path = ctx.data / "forecast_record.csv"
    if rec_path.exists():
        rec = record_for_backtest(pd.read_csv(rec_path)).dropna(subset=["loss", "var", "es"])
        rec = rec[pd.to_datetime(rec["date"]) <= pd.Timestamp(AS_OF)]      # the document's sample: rows up to the as_of
        f = backtest_history(rec, alpha=0.99)
        rows += [("B09", "forecast record: exceedances", 1, f["kupiec"]["exceedances"]),
                 ("B10", "forecast record: Kupiec LR_uc", 0.224, f["kupiec"]["LR_uc"]),
                 ("B11", "forecast record: Kupiec p", 0.636, f["kupiec"]["p_value"]),
                 ("B12", "forecast record: Christoffersen p_cc", 0.879, f["christoffersen"]["p_value_cc"]),
                 ("B13", "forecast record: Z2", -0.269, f["acerbi_szekely"]["Z2"]),
                 ("B14", "forecast record: Basel zone", "Green", f["basel_zone"]),
                 ("B15", "forecast record: verdict", "Pass", f["verdict"])]
    for cid, q, rep, val in rows:
        c = Check(cid, "backtest", src, q, rep)
        c.note = "history is synthetic (GOV-028): tests the arithmetic, not the model" if cid <= "B08" else "underpowered (GOV-029, restriction 6.4)"
        out.append(compare(c, val))
    return out


HAZARD_REPORT = {"in_sample.auc": 0.882, "in_sample.brier": 0.0207, "in_sample.brier_base_rate": 0.0209, "in_sample.log_loss": 0.0849,
                 "in_sample.log_loss_base_rate": "0.1034", "out_of_sample.auc": "0.780", "out_of_sample.brier": "0.0320",
                 "out_of_sample.brier_base_rate": 0.0234, "out_of_sample.log_loss": 0.1242, "out_of_sample.log_loss_base_rate": 0.1166,
                 "out_of_sample.n": 168, "out_of_sample.events": 4, "events": 9, "rows": 421, "intercept": -4.501,
                 "coef.debt_gdp": 0.057, "coef.primary_deficit": -0.483, "coef.current_account": -0.975, "coef.real_growth": "-1.050",
                 "coef.inflation_log": 0.085}
# hazard-fit-report.md "Rebuilt panel" section (EQ-B-0054): today's builder on the raw inputs
HAZARD_REBUILT = {"rows": 391, "events": 9, "out_of_sample.auc": 0.789, "out_of_sample.brier": 0.0361, "out_of_sample.n": 152}


def _hazard_values(res, panel) -> dict:
    v = {"events": int(panel["event"].sum()), "rows": len(panel), "intercept": res.intercept}
    v.update({f"in_sample.{k}": res.in_sample.get(k) for k in ("auc", "brier", "brier_base_rate", "log_loss", "log_loss_base_rate")})
    v.update({f"out_of_sample.{k}": res.out_of_sample.get(k) for k in ("auc", "brier", "brier_base_rate", "log_loss", "log_loss_base_rate", "n", "events")})
    v.update({f"coef.{k}": c for k, c in res.coef.items()})
    return v


def group_hazard(ctx: Ctx) -> list[Check]:
    from econquest.validation import hazard_panel as hp
    out = []
    src = "docs/validation/hazard-fit-report.md (generated 2026-10-23 10:10, EQ-B-0054 update)"
    feats = list(hp.DEFAULT_FEATURES)
    stored = ctx.data / "panel" / "hazard_panel.csv"
    if stored.exists():
        panel = pd.read_csv(stored, dtype={"iso": str})
        res = hp.fit_and_validate(panel, features=feats)
        vals = _hazard_values(res, panel)
        for j, (k, rep) in enumerate(HAZARD_REPORT.items(), 1):
            c = Check(f"H{j:02d}", "hazard", src, f"refit on stored panel data/panel/hazard_panel.csv: {k}", rep)
            out.append(compare(c, None if vals.get(k) is None else float(vals[k])))
    # rebuild the panel from the raw inputs with today's builder (what `fit-hazard` would do now)
    events = hp.load_events(ctx.data / "panel" / "sovereign_defaults.csv")
    weo_path = ctx.data / "panel" / "weo_history.csv"
    weo_path = weo_path if weo_path.exists() else ctx.data / "live" / "raw_weo.csv"
    if weo_path.exists():
        end = int(max(events["end"].max(), events["start"].max())) - 1
        weo = pd.read_csv(weo_path, dtype={"iso": str, "series": str, "vintage": str})
        panel2 = hp.panel_from_long(weo, None, events, features=feats, start=1980, end=end, forecast_cutoff=end)
        res2 = hp.fit_and_validate(panel2, features=feats)
        vals2 = _hazard_values(res2, panel2)
        for j, (k, rep) in enumerate(HAZARD_REBUILT.items(), 1):
            c = Check(f"H{20 + j:02d}", "hazard", src + " Rebuilt panel", f"rebuilt panel ({weo_path.name} + sovereign_defaults.csv): {k}", rep)
            out.append(compare(c, float(vals2[k])))
    return out


def group_scorecard(ctx: Ctx) -> list[Check]:
    import json
    from econquest.config import Settings
    from econquest.ingestion import load_universe
    from econquest.scorecard import score_universe
    from econquest.engine.pipeline import run_pipeline
    seed = Path(__file__).resolve().parents[2] / "tests" / "seed_data"
    ref_path = ctx.data / "workbook_reference.json"
    src = "docs/validation/scorecard.md Benchmarks (workbook reference, seed snapshot)"
    if not (seed.is_dir() and ref_path.exists()):
        return [_skip(Check("S01", "scorecard", src, "scorecard vs workbook", "match"), "tests/seed_data or workbook_reference.json missing")]
    ref = json.loads(ref_path.read_text())
    u = load_universe(seed); s = Settings.load(seed / "assumptions.json")
    sc = score_universe(u, s)
    out = [compare(Check("S01", "scorecard", src, "max |composite - workbook| (points), tolerance 0.15", 0.0),
                   float(np.max(np.abs(sc.composite.to_numpy() - np.array(ref["composite"])))), 0.15)]
    worst = max(float(np.max(np.abs(sc.pillar_final.loc[p].to_numpy() - np.array(ref["final_pillars"][str(p)])))) for p in range(1, 8))
    out.append(compare(Check("S02", "scorecard", src, "max |pillar - workbook| over 7 pillars (points), tolerance 0.1", 0.0), worst, 0.1))
    out.append(compare(Check("S03", "scorecard", src, "grades equal to workbook (count of 18)", 18),
                       int(sum(int(a) == int(b) for a, b in zip(sc.grade, ref["grade"]))), 0))
    r = run_pipeline(u, s, paths=2000, as_of=AS_OF)
    out.append(compare(Check("S04", "scorecard", "docs/validation/regime-layer3.md Benchmarks (workbook regimes, seed snapshot)",
                             "regimes equal to workbook (count of 18)", 18), int(sum(a == b for a, b in zip(r.country["regime"], ref["regime"]))), 0))
    return out


def group_garch(ctx: Ctx) -> list[Check]:
    c0 = Check("G01", "garch", "docs/validation/garch-dcc.md Outputs", "GARCH refit", "run")
    if ctx.quick:
        return [_skip(c0, "full mode only (about a minute)")]
    from econquest.engine.garch import run_garch, load_prices
    u, s = ctx.universe()
    px = load_prices(ctx.data)
    if px is None:
        return [_skip(c0, "no data/market_history/prices.csv")]
    px = px[pd.to_datetime(px.index) <= pd.Timestamp(PRICES_THROUGH)]     # the document's run date
    g = run_garch(u, px, s, u.gpr)
    ser = g.series
    src = "docs/validation/garch-dcc.md Outputs (run 2026-10-22)"
    rows = [("G01", "persistence median", 0.909, float(ser["persistence"].median())),
            ("G02", "Student-t nu median", "4.20", float(ser["nu"].median())),
            ("G03", "number of series fitted", 27, len(ser)),
            ("G04", "fits converged (count)", 27, int(ser["converged"].sum()))]
    if g.dcc_fx:
        rows.append(("G05", "DCC FX average one-step correlation", 0.089, float(g.dcc_fx.avg_corr(g.dcc_fx.R_next))))
    if g.dcc_eq:
        rows.append(("G06", "DCC equity average correlation", 0.364, float(g.dcc_eq.avg_corr(g.dcc_eq.R_next))))
    return [compare(Check(cid, "garch", src, q, rep), val) for cid, q, rep, val in rows]


GROUP_FN = {"release": group_release, "docs": group_docs, "backtest": group_backtest, "hazard": group_hazard,
            "scorecard": group_scorecard, "garch": group_garch}


# ---------------------------------------------------------------------------------------------- output

def _fmt(v) -> str:
    if v is None:
        return ""
    if isinstance(v, float):
        return f"{v:.6g}" if abs(v) < 1e6 else f"{v:.0f}"
    return str(v)


def to_frame(checks: list[Check]) -> pd.DataFrame:
    return pd.DataFrame([{"id": c.id, "group": c.group, "status": c.status, "quantity": c.quantity, "reported": _fmt(c.reported),
                          "recomputed": _fmt(c.recomputed), "tolerance": _fmt(c.tolerance), "source": c.source, "note": c.note} for c in checks])


def write_outputs(checks: list[Check], out: Path, meta: dict) -> dict:
    out.mkdir(parents=True, exist_ok=True)
    df = to_frame(checks)
    csv = out / "replication.csv"; md = out / "replication.md"
    df.to_csv(csv, index=False)
    counts = df["status"].value_counts().to_dict() if len(df) else {}
    lines = ["# Independent replication (EQ-B-0051)", "",
             f"- Mode: {'quick (20,000 requested paths, loose tolerance on larger stated counts)' if meta['quick'] else 'full (stated path counts)'}",
             f"- as_of {AS_OF}; data `{meta['data']}`; groups {', '.join(meta['groups'])}; runtime {meta['seconds']:.0f} s",
             f"- Environment: python {meta['python']}, numpy {np.__version__}, pandas {pd.__version__}",
             "- Recomputed from public functions and stored inputs; no archived run or output file is read.",
             "- Status counts: " + ", ".join(f"{k} {v}" for k, v in sorted(counts.items())),
             "- STALE checks: " + (", ".join(stale_ids(checks)) or "none"), "",
             "| id | status | quantity | reported | recomputed | tol | source | note |", "|---|---|---|---|---|---|---|---|"]
    for r in df.itertuples(index=False):
        lines.append("| " + " | ".join(str(x).replace("|", "/") for x in (r.id, r.status, r.quantity, r.reported, r.recomputed, r.tolerance, r.source, r.note)) + " |")
    md.write_text("\n".join(lines) + "\n")
    return {"csv": csv, "md": md, "counts": counts, "stale": stale_ids(checks)}


def stale_ids(checks: list[Check]) -> list[str]:
    return [c.id for c in checks if c.status == "STALE"]


def summary_line(res: dict) -> str:
    """Console summary: status counts, the STALE ids (each still inside its drift band) and the table path."""
    line = "status: " + ", ".join(f"{k} {v}" for k, v in sorted(res["counts"].items()))
    if res.get("stale"):
        line += "; STALE " + ", ".join(res["stale"])
    return line + f"; table {res['md']}"


def replicate(data: str | Path = "data", out: str | Path = "outputs/replication", quick: bool = False, groups=None, log=print,
              prices: str | Path | None = FROZEN_PRICES) -> dict:
    t0 = time.perf_counter()
    data = Path(data)
    groups = list(groups or GROUPS)
    bad = [g for g in groups if g not in GROUP_FN]
    if bad:
        raise ValueError(f"unknown group(s) {bad}; choose from {list(GROUPS)}")
    ctx = Ctx(data=data, quick=quick, log=log, prices=Path(prices) if prices else None)
    checks: list[Check] = []
    for g in groups:
        log(f"[{g}]")
        checks += GROUP_FN[g](ctx)
    meta = {"quick": quick, "data": str(data), "prices": str(ctx.prices) if ctx.prices else "data", "groups": groups, "seconds": time.perf_counter() - t0, "python": sys.version.split()[0]}
    res = write_outputs(checks, Path(out), meta)
    res["checks"] = checks
    return res


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="python -m econquest.validation.replicate", description=__doc__.split("\n\n")[0])
    p.add_argument("--data", default="data", help="data folder (stored inputs)")
    p.add_argument("--out", default="outputs/replication", help="folder for replication.csv and replication.md")
    p.add_argument("--quick", action="store_true", help="20,000 requested paths, loose tolerance; skips the GARCH refit")
    p.add_argument("--prices", default=str(FROZEN_PRICES), help="price history the release ran on (default: the frozen copy); "
                   "'data' uses the data folder's prices.csv up to the release date")
    p.add_argument("--only", help=f"comma list of groups: {','.join(GROUPS)}")
    a = p.parse_args(argv)
    groups = [g.strip() for g in a.only.split(",") if g.strip()] if a.only else None
    res = replicate(a.data, a.out, quick=a.quick, groups=groups, prices=None if a.prices == "data" else a.prices)
    print(summary_line(res))
    return 1 if res["counts"].get("FAIL") else 0


if __name__ == "__main__":
    raise SystemExit(main())
