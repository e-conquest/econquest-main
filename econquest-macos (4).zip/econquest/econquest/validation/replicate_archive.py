"""Second-line replication of the release notes from the run archive (EQ-B-0058, GOV-042).

The first line (`econquest.validation.replicate`) recomputes the 0.1.4 numbers from today's code and inputs and
never reads an archived run. This module does the opposite: for every number reported in the release notes it
names the archived run the number comes from, reads the archived value and its recorded hashes, and says whether
the note matches the archive and whether the run's stamp is consistent with the release. Where a release zip is
kept, it also checks the package figures against the zip and (with `--rerun`) reruns the zip's own engine on its
own frozen inputs in a subprocess, for numbers that no archive holds.

    python -m econquest.validation.replicate_archive --out outputs/replication-archive
    python -m econquest.validation.replicate_archive --out <dir> --zip ../econquest-macos.zip --rerun

Read-only: archives are opened for reading only (the SQLite store in `mode=ro`), the zip is unpacked into a
temporary folder, and `--out` may not sit inside the archive folder. Writes `archive-replication.csv` and
`archive-replication.md` to `--out`.

Status per claim:
- MATCH: the evidence value rounds to the reported value (half a unit of the reported last digit; strings exact).
- MISMATCH: it does not. The `finding` column names the findings-register row when one is open.
- UNARCHIVED: no archived run, kept zip or rerun holds the number (the note says why).
- MISSING_ARCHIVE: the claim cites a run id that is not in the archive.
- NOT_RUN: the evidence needs `--zip` or `--rerun` and was not asked for.
`source` says where the evidence came from: archive (run JSON, cross-checked with the SQLite store), zip, file,
rerun (the zip's engine on frozen inputs; the run itself is not archived) or none. `kind`: model (a model number),
parameter (a setting), hash, package (zip facts) or process (test counts, timings, review counts: never archived).

Hash checks per cited run (`hash_check`): run_hash recomputes from (code_hash, data_hash, as_of) with
`versioning.run_hash`, data_hash recomputes from the recorded per-file hashes, the SQLite row agrees with the
JSON, and the code_version the run was stamped with against the release that reports it.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import math
import re
import sqlite3
import subprocess
import sys
import tempfile
import time
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

import pandas as pd

from econquest import versioning as V
from econquest.common_format import escape_formula

ROOT = Path(__file__).resolve().parents[2]
RELEASES = ROOT / "docs" / "governance" / "releases"
ARCHIVE = ROOT / "outputs" / "store" / "archive"
DB = ROOT / "outputs" / "store" / "econquest.sqlite"
DEFAULT_ZIP = ROOT.parent / "econquest-macos.zip"
FROZEN_014 = RELEASES / "inputs" / "0.1.4" / "prices.csv"
WORKER = Path(__file__).resolve().parent / "_rerun_worker.py"
LIMITS = ROOT / "data" / "limits.json"
AS_OF = "2026-10-23"
PRICES_THROUGH = "2026-10-22"            # last price row the 0.1.4 release run saw (replicate.PRICES_THROUGH)
STATUSES = ("MATCH", "MISMATCH", "UNARCHIVED", "MISSING_ARCHIVE", "NOT_RUN")
COLUMNS = ["id", "release", "doc", "kind", "quantity", "reported", "value", "status", "source", "run_id", "hash_check",
           "finding", "note"]


class Missing(Exception):
    """A cited run (or a field of it) is not in the archive."""


class NotRun(Exception):
    """The evidence needs --zip or --rerun."""


@dataclass
class Ev:
    value: object
    source: str = "archive"
    runs: tuple = ()
    note: str = ""


@dataclass
class Claim:
    id: str
    release: str
    doc: str                      # file name under the releases folder
    quantity: str
    reported: str                 # as written in the note
    kind: str = "model"
    ev: Callable | None = None    # ctx -> Ev; None = nothing holds the number
    why: str = ""                 # for UNARCHIVED: why no evidence exists
    tol: float | None = None      # override of the half-unit tolerance
    finding: str = ""             # findings-register id when a mismatch is known


# ---------------------------------------------------------------------------------------------- archive (read-only)

class Archive:
    """Run JSONs under `folder` and the runs table of the SQLite store, opened read-only."""

    def __init__(self, folder: Path, db: Path | None = None):
        self.folder = Path(folder)
        self.files = {p.stem: p for p in sorted(self.folder.glob("*.json"))} if self.folder.is_dir() else {}
        self.db = Path(db) if db and Path(db).is_file() else None
        self._cache: dict = {}
        self._integrity: dict = {}

    def run(self, run_id: str) -> dict:
        if run_id not in self._cache:
            if run_id not in self.files:
                raise Missing(f"run {run_id} not in {self.folder}")
            with open(self.files[run_id], "rb") as f:            # read-only
                self._cache[run_id] = json.loads(f.read())
        return self._cache[run_id]

    def get(self, run_id: str, dotted: str):
        node = self.run(run_id)
        for k in dotted.split("."):
            if not isinstance(node, dict) or k not in node:
                raise Missing(f"{run_id}: no field {dotted}")
            node = node[k]
        return node

    def versions(self, run_id: str) -> dict:
        d = self.run(run_id)
        return (d.get("provenance") or {}).get("versions") or (d.get("summary") or {}).get("versions") or {}

    def db_summary(self, run_id: str) -> dict | None:
        if self.db is None:
            return None
        con = sqlite3.connect(f"file:{self.db}?mode=ro", uri=True)
        try:
            row = con.execute("select summary from runs where run_id = ?", (run_id,)).fetchone()
        finally:
            con.close()
        return json.loads(row[0]) if row else None

    def integrity(self, run_id: str) -> dict:
        """Recompute run_hash and data_hash from the recorded fields; compare the SQLite row with the JSON."""
        if run_id in self._integrity:
            return self._integrity[run_id]
        v = self.versions(run_id)
        out = {"code_version": v.get("code_version"), "code_hash": v.get("code_hash"), "data_hash": v.get("data_hash"),
               "run_hash": v.get("run_hash"), "problems": []}
        if v.get("run_hash"):
            rh = V.run_hash(v.get("code_hash", ""), v.get("data_hash", ""), v.get("as_of"), vintage_id=v.get("vintage_id"),
                            inputs_hash=v.get("inputs_hash"))
            if rh != v["run_hash"]:
                out["problems"].append(f"run_hash recomputes to {rh}")
        if v.get("data_files") and v.get("data_hash") and V._combine(v["data_files"]) != v["data_hash"]:
            out["problems"].append("data_hash does not recompute from data_files")
        s = (self.run(run_id).get("summary") or {})
        dbs = self.db_summary(run_id)
        if self.db is not None:
            if dbs is None:
                out["problems"].append("not in SQLite store")
            elif dbs.get("metrics") != s.get("metrics"):
                out["problems"].append("SQLite metrics differ from archive JSON")
        out["db"] = "agrees" if (self.db is not None and dbs is not None and not out["problems"]) else ("no store" if self.db is None else "")
        self._integrity[run_id] = out
        return out


# ---------------------------------------------------------------------------------------------- zip and rerun

def tree_code_hash(pkg: Path, version_as: str | None = None) -> str:
    """versioning.code_hash over a package folder; `version_as` swaps the __version__ string in __init__.py."""
    h = hashlib.sha256()
    for p in sorted(Path(pkg).rglob("*")):
        if p.is_file() and p.suffix in (".py", ".html", ".js") and "__pycache__" not in p.parts:
            b = p.read_bytes()
            rel = p.relative_to(pkg).as_posix()
            if version_as and rel == "__init__.py":
                b = re.sub(rb'__version__ = "[^"]+"', f'__version__ = "{version_as}"'.encode(), b)
            h.update(rel.encode()); h.update(b)
    return h.hexdigest()[:16]


@dataclass
class ZipFacts:
    path: Path
    sha256: str
    root: Path                    # unpacked folder that holds econquest/ and data/
    version: str
    entries: int                  # file entries in the zip
    manifest_files: int           # files listed in RELEASE-MANIFEST.txt
    epoch_dates: set
    hashes: dict                  # RELEASE-HASHES.json
    code_hash: str                # recomputed from the unpacked package
    data_hash: str                # recomputed from the unpacked data folder
    replication_md: str


MAX_ZIP_ENTRIES = 5_000                 # the 0.1.5 zip has 591 entries
MAX_ZIP_BYTES = 512 * 1024 * 1024       # total uncompressed size; the 0.1.5 zip unpacks to about 25 MB


def open_zip(path: Path, into: Path, max_entries: int = MAX_ZIP_ENTRIES, max_bytes: int = MAX_ZIP_BYTES) -> ZipFacts:
    """Hash the zip, then unpack it into `into`, refusing archives with more than `max_entries` entries or more
    than `max_bytes` uncompressed (zip bombs) before anything is written."""
    path = Path(path)
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    with zipfile.ZipFile(path) as z:
        infos = z.infolist()
        files = [i for i in infos if not i.is_dir()]
        total = sum(i.file_size for i in infos)
        if len(infos) > max_entries or total > max_bytes:
            raise ValueError(f"zip {path.name} refused: {len(infos)} entries, {total:,} bytes uncompressed "
                             f"(caps {max_entries} entries, {max_bytes:,} bytes)")
        z.extractall(into)                                   # zipfile drops absolute and ../ components
        names = {i.filename for i in files}
        top = sorted({n.split("/", 1)[0] for n in names})
    root = Path(into) / (top[0] if len(top) == 1 else "")
    pkg = root / "econquest"
    init = (pkg / "__init__.py").read_text()
    m = re.search(r'__version__ = "([^"]+)"', init)
    man = root / "RELEASE-MANIFEST.txt"
    hashes_f = root / "RELEASE-HASHES.json"
    rep = root / "RELEASE-REPLICATION.md"
    return ZipFacts(path=path, sha256=h.hexdigest(), root=root, version=m.group(1) if m else "",
                    entries=len(files), manifest_files=sum(1 for ln in man.read_text().splitlines() if ln.strip()) if man.is_file() else 0,
                    epoch_dates={i.date_time for i in infos}, hashes=json.loads(hashes_f.read_text()) if hashes_f.is_file() else {},
                    code_hash=tree_code_hash(pkg), data_hash=V.data_hash(root / "data"),
                    replication_md=rep.read_text() if rep.is_file() else "")


def catalogued_sha(version: str, claims: list[Claim] | None = None) -> str | None:
    """The SHA-256 the package note of `version` reports for its zip (claim 'zip SHA-256')."""
    for c in claims if claims is not None else catalogue():
        if c.release == version and c.quantity == "zip SHA-256":
            return c.reported
    return None


def verify_zip(zf: ZipFacts, claims: list[Claim] | None = None) -> None:
    """Refuse to run a zip's engine unless its SHA-256 is the one its package note reports."""
    want = catalogued_sha(zf.version, claims)
    if want is None or zf.sha256 != want:
        raise ValueError(f"zip {zf.path} (version {zf.version}) has SHA-256 {zf.sha256}; the package note reports "
                         f"{want or 'none'}: refusing to run its engine")


def rerun_jobs(zf: ZipFacts, frozen_prices: Path) -> list[dict]:
    """The reruns the catalogue cites: the 0.1.5 engine on its own data, and on the frozen 0.1.4 prices."""
    fp = {"prices": str(frozen_prices), "prices_through": PRICES_THROUGH}
    pre014 = {"monte_carlo.vol_source": "regime", "copula.source": "judgement"}
    pre013 = {**pre014, "probability.risk_premium_ratio": 1.0,
              "probability.w_fx_regime_scale": {"Float": 1.0, "Managed": 1.0, "Peg": 1.0, "Dollarized": 1.0, "default": 1.0}}
    return [{"id": "n_scenarios", "count_scenarios": True},
            {"id": "base100", "paths": 100_000},
            {"id": "fed22_100", "paths": 100_000, "scenario": "FED22"},
            {"id": "taper13_100", "paths": 100_000, "scenario": "TAPER13"},
            {"id": "base100_p014", "paths": 100_000, **fp},
            {"id": "base20_p014", "paths": 20_000, **fp},
            {"id": "fed22_noshock20_p014", "paths": 20_000, "scenario": "FED22", "drop_rates": True, **fp},
            {"id": "taper13_noshock20_p014", "paths": 20_000, "scenario": "TAPER13", "drop_rates": True, **fp},
            {"id": "pre014_20_p014", "paths": 20_000, "patches": pre014, **fp},
            {"id": "pre013_20_p014", "paths": 20_000, "patches": pre013, **fp},
            {"id": "logistic20_p014", "paths": 20_000, "patches": {"regime.global_switch": "logistic"}, **fp},
            {"id": "step04_20_p014", "paths": 20_000, "patches": {"monte_carlo.global_stress_share": 0.4}, **fp},
            {"id": "hmm20_p014", "paths": 20_000, "patches": {"regime.method": "hmm"}, **fp}]


def run_worker(zf: ZipFacts, jobs: list[dict], tmp: Path, timeout: int = 1800) -> dict:
    """Run the zip's engine in `python -I` (the working tree's econquest is not importable there)."""
    spec = Path(tmp) / "rerun-spec.json"
    spec.write_text(json.dumps({"root": str(zf.root), "data": str(zf.root / "data"), "jobs": jobs}))
    p = subprocess.run([sys.executable, "-I", str(WORKER), str(spec)], capture_output=True, text=True, timeout=timeout,
                       cwd=str(tmp), check=False)
    if p.returncode != 0:
        raise RuntimeError(f"rerun worker failed: {p.stderr[-2000:]}")
    return json.loads(p.stdout.strip().splitlines()[-1])


# ---------------------------------------------------------------------------------------------- context

@dataclass
class Ctx:
    archive: Archive
    zip: ZipFacts | None = None
    reruns: dict | None = None
    limits_path: Path = LIMITS
    frozen_prices: Path = FROZEN_014
    findings: dict = field(default_factory=dict)
    _zip_code: dict = field(default_factory=dict)

    def zip_code_as(self, version: str) -> str:
        """Code hash of the kept zip with __version__ set to `version` (memoised per run)."""
        if version not in self._zip_code:
            self._zip_code[version] = tree_code_hash(self.zip.root / "econquest", version_as=version)
        return self._zip_code[version]

    # archive helpers --------------------------------------------------------------------------------------
    def metric(self, run: str, key: str, scale: float = 1.0) -> Ev:
        return Ev(float(self.archive.get(run, f"summary.metrics.{key}")) * scale, "archive", (run,))

    def field(self, run: str, dotted: str, scale: float | None = None) -> Ev:
        v = self.archive.get(run, dotted)
        return Ev(float(v) * scale if scale is not None else v, "archive", (run,))

    def change(self, run: str, key: str, base_run: str) -> Ev:
        a = float(self.archive.get(run, f"summary.metrics.{key}")); b = float(self.archive.get(base_run, f"summary.metrics.{key}"))
        return Ev(100.0 * (a / b - 1.0), "archive", (run, base_run))

    def version(self, run: str, key: str) -> Ev:
        v = self.archive.versions(run)
        if key not in v:
            raise Missing(f"{run}: no versions.{key}")
        return Ev(v[key], "archive", (run,))

    def limit_use(self, run: str, key: str) -> Ev:
        """Utilisation (percent) of the book limit, using data/limits.json only if it is byte-identical to the
        limits.json the run hashed."""
        rec = (self.archive.versions(run).get("data_files") or {}).get("limits.json")
        cur = V.file_hash(self.limits_path)
        if rec is None or rec != cur:
            raise Missing(f"limits.json the run saw ({rec}) is not the file at hand ({cur})")
        lim = json.loads(Path(self.limits_path).read_text())["book"][key]
        return Ev(100.0 * float(self.archive.get(run, f"summary.metrics.{key}")) / float(lim), "archive", (run,),
                  f"limit {lim} from limits.json, hash {cur} = the run's")

    def pd_pp(self, run: str, country: str) -> Ev:
        return Ev(100.0 * self._pd(run)[country], "archive", (run,))

    def _pd(self, run: str) -> dict:
        return {r["country"]: float(r["pd_default"]) for r in self.archive.get(run, "country")}

    def runs_sharing(self, run: str, prefix: str = "-stress-") -> list[str]:
        """Archived stress runs on the same code and data as `run` (run_hash, or data_hash before run_hash)."""
        v0 = self.archive.versions(run)
        key = lambda v: (v.get("code_hash"), v.get("run_hash") or v.get("data_hash"))      # noqa: E731
        return sorted(r for r in self.archive.files if prefix in r and key(self.archive.versions(r)) == key(v0))

    # zip and rerun helpers --------------------------------------------------------------------------------
    def need_zip(self, version: str) -> ZipFacts:
        if self.zip is None:
            raise NotRun("needs --zip (the kept release zip)")
        if self.zip.version != version:
            raise Missing(f"the kept zip is {self.zip.version}, not {version}; the {version} zip is not kept")
        return self.zip

    def rerun(self, job: str, key: str) -> Ev:
        if self.reruns is None:
            raise NotRun("needs --rerun with the 0.1.5 zip")
        return Ev(float(self.reruns[job][key]), "rerun", (), f"0.1.5 zip engine, job {job}")

    def rerun_change(self, job: str, key: str, base_job: str) -> Ev:
        a = self.rerun(job, key).value; b = self.rerun(base_job, key).value
        return Ev(100.0 * (a / b - 1.0), "rerun", (), f"0.1.5 zip engine, {job} vs {base_job}")


# ---------------------------------------------------------------------------------------------- comparison

def decimals(s: str) -> int:
    m = re.search(r"\.(\d+)", s)
    return len(m.group(1)) if m else 0


def parse_number(s: str) -> float | None:
    t = str(s).strip().replace(",", "").replace("−", "-")
    t = re.sub(r"(\s*(%|pp|bp|\$mm|s))$", "", t).strip()
    try:
        return float(t)
    except ValueError:
        return None


def evaluate(c: Claim, ctx: Ctx) -> dict:
    row = {"id": c.id, "release": c.release, "doc": c.doc, "kind": c.kind, "quantity": c.quantity, "reported": c.reported,
           "value": "", "status": "UNARCHIVED", "source": "none", "run_id": "", "hash_check": "", "finding": "", "note": c.why}
    if c.ev is None:
        return row
    try:
        ev = c.ev(ctx)
    except NotRun as e:
        row.update(status="NOT_RUN", note=str(e)); return row
    except (Missing, KeyError) as e:
        row.update(status="MISSING_ARCHIVE" if "not in" in str(e) and "run " in str(e) else "UNARCHIVED", note=str(e).strip("'"))
        return row
    row.update(source=ev.source, run_id=" ".join(ev.runs), note="; ".join(x for x in (ev.note, c.why) if x))
    rep = parse_number(c.reported)
    val = ev.value
    if isinstance(val, bool) or rep is None or not isinstance(val, (int, float)):
        row["value"] = val if not isinstance(val, (list, tuple, set)) else ", ".join(map(str, val))
        ok = str(row["value"]) == c.reported
    else:
        tol = c.tol if c.tol is not None else 0.5 * 10 ** -decimals(c.reported)
        row["value"] = f"{val:.6g}" if not float(val).is_integer() else str(int(val))
        ok = not math.isnan(val) and abs(float(val) - rep) <= tol + 1e-9
    row["status"] = "MATCH" if ok else "MISMATCH"
    if not ok:
        row["finding"] = c.finding
    row["hash_check"] = "; ".join(hash_check(ctx, r, c.release) for r in ev.runs)
    return row


def _vt(v: str | None) -> tuple:
    try:
        return tuple(int(x) for x in str(v).split("."))
    except ValueError:
        return ()


def hash_check(ctx: Ctx, run: str, release: str) -> str:
    try:
        i = ctx.archive.integrity(run)
    except Missing:
        return f"{run}: missing"
    parts = ["integrity ok" if not i["problems"] else "INTEGRITY " + ", ".join(i["problems"])]
    cv = i["code_version"]
    if cv is None:
        parts.append("no version stamp")
    elif cv == release:
        parts.append(f"stamped {cv}")
    elif _vt(cv) < _vt(release):
        parts.append(f"stamped {cv} (pre-bump for {release})")
    else:
        parts.append(f"stamped {cv} (later than {release})")
    if ctx.zip is not None and i["code_hash"] and _vt(cv) < _vt(ctx.zip.version) and cv == _prev(ctx.zip.version) \
            and ctx.zip_code_as(cv) == i["code_hash"]:
        parts.append(f"code = {ctx.zip.version} zip with version {cv}")
    return f"{run}: " + ", ".join(parts)


def _prev(v: str) -> str:
    t = _vt(v)
    return ".".join(map(str, (*t[:-1], t[-1] - 1))) if t and t[-1] > 0 else ""


# ---------------------------------------------------------------------------------------------- number scan

STRIP = (r"`[^`\n]*`", r"\b[A-Z][A-Za-z]*(?:-[A-Z0-9]+)*-\d+\b", r"\b\d{8}T\d{6}Z?-[\w-]+", r"\b(?:EQ|HO|GOV|VF|SEC|EXC|ADR|CHG)-[\w-]+", r"\b\d{4}-\d{2}-\d{2}\b",
         r"\b\d{1,2}:\d{2}Z?", r"\b\d+\.\d+\.\d+\b", r"\b[0-9a-f]{12,}\b", r"[0-9a-f]{8}…[0-9a-f]{4}")
NUM = re.compile(r"(?<![\w.])[-+]?\d[\d,]*(?:\.\d+)?")


def numbers_in(text: str) -> list[tuple[int, str]]:
    """(line, token) for every number in a note, after removing ids, dates, times, versions, hashes and code spans."""
    for p in STRIP:
        text = re.sub(p, " ", text)
    return [(i, m.group().lstrip("+-").rstrip(",")) for i, ln in enumerate(text.splitlines(), 1) for m in NUM.finditer(ln)]


def uncatalogued(doc_text: str, claims: list[Claim], labels: str = "") -> list[tuple[int, str]]:
    """Numbers in the note that no claim reports and the label list does not name (labels: tier and step numbers,
    ticket suffixes, formula constants and other numbers that are not reported results)."""
    covered = set(labels.split())
    for c in claims:
        covered.update(t.lstrip("+-").rstrip(",") for t in NUM.findall(c.reported + " " + c.quantity))
    return [(i, t) for i, t in numbers_in(doc_text) if t not in covered]


# ---------------------------------------------------------------------------------------------- catalogue

N011, P011 = "0.1.1-2026-10-23.md", "0.1.1-2026-10-23-package.md"
P012 = "0.1.2-2026-10-23-package.md"
N013, P013 = "0.1.3-2026-10-23.md", "0.1.3-2026-10-23-package.md"
N014, P014 = "0.1.4-2026-10-23.md", "0.1.4-2026-10-23-package.md"
N015, P015 = "0.1.5-2026-10-23.md", "0.1.5-2026-10-23-package.md"
B011, PRE011 = "20261023T142202-base", "20261023T120005-base"
B013, B014, B015 = "20261023T163707-base", "20261023T194510-base", "20261023T225023-base"
STRESS = ("A", "B", "C", "DOWNGRADE", "TAIWAN", "HORMUZ", "TARIFF", "CHINA_HL")
PROCESS = "process figure (tests, reviews, timings, counts); no run archive holds it"
NOZIP = "release zip not kept (only the latest zip, 0.1.5, is)"


def _s(run: str, label: str) -> str:
    return run.replace("-base", f"-{label}")


def _zip_attr(version: str, fn: Callable) -> Callable:
    return lambda c: Ev(fn(c.need_zip(version)), "zip")


def _hash_in_archive(h: str) -> Callable:
    def f(c: Ctx) -> Ev:
        runs = [r for r in c.archive.files if (c.archive.versions(r).get("code_hash") == h)]
        if not runs:
            raise Missing(f"no archived run carries code_hash {h}: no run on the shipped code")
        return Ev(h, "archive", (runs[0],), f"{len(runs)} archived runs carry it")
    return f


def _first_stress(c: Ctx, run: str, label: str) -> str:
    """The stress run of a base run: same code and data (run_hash, or data_hash before run_hash existed), the first
    one archived after the base."""
    v0 = c.archive.versions(run)
    key = lambda v: (v.get("code_hash"), v.get("run_hash") or v.get("data_hash"))          # noqa: E731
    hits = sorted(r for r in c.archive.files if r.endswith(f"-stress-{label}") and r > run and key(c.archive.versions(r)) == key(v0))
    if not hits:
        raise Missing(f"run stress-{label} of {run} not in archive")
    return hits[0]


def _stress_es(run: str, label: str) -> Callable:
    return lambda c: c.metric(_first_stress(c, run, label), "es99_mm")


def _stress_chg(run: str, label: str) -> Callable:
    return lambda c: c.change(_first_stress(c, run, label), "es99_mm", run)


def _notional(run: str, country: str) -> Callable:
    return lambda c: Ev(next(float(r["notional_mm"]) for r in c.archive.get(run, "dashboard") if r["country"] == country), "archive", (run,))


def _fired(c: Ctx) -> Ev:
    n = {r: sum(1 for row in c.archive.get(r, "activation") for k, v in row.items() if k != "trade" and v is not None) for r in (PRE011, B011)}
    return Ev(n[B011] if n[B011] == n[PRE011] else f"{n[PRE011]} -> {n[B011]}", "archive", (PRE011, B011), "fired (trade, country) cells, before and after")


def _movers(a: dict, b: dict, pp: float = 2.0) -> list[str]:
    return sorted((k for k in a if abs(b[k] - a[k]) > pp / 100), key=lambda k: a[k] - b[k], reverse=True)


def _pd_movers(c: Ctx) -> Ev:
    a, b = c._pd(B011), c._pd(B013)
    ev = Ev(", ".join(_movers(a, b)), "archive", (B011, B013), "archive pair (0.1.1 base -> 0.1.3 base)")
    if c.reruns is not None:
        ra, rb = c.reruns["pre013_20_p014"]["pd_default"], c.reruns["pre014_20_p014"]["pd_default"]
        ev.note += "; frozen-input rerun (0.1.5 engine, settings before/after EQ-B-0021): " + ", ".join(
            f"{k} {100 * (rb[k] - ra[k]):+.2f} pp" for k in _movers(ra, rb))
    return ev


def _pd_move(r1: str, r2: str, country: str) -> Callable:
    return lambda c: Ev(c.pd_pp(r2, country).value - c.pd_pp(r1, country).value, "archive", (r1, r2))


def _max_pd_move(r1: str, r2: str) -> Callable:
    def f(c: Ctx) -> Ev:
        a, b = c._pd(r1), c._pd(r2)
        return Ev(max(abs(b[k] - a[k]) for k in a) * 100.0, "archive", (r1, r2), "max |PD move| over the countries, pp")
    return f


def _rate_cost(c: Ctx) -> Ev:
    pos = c.archive.get(B015, "positions")
    v = sum(float(p["duration_yrs"]) * float(p["notional_mm"]) for p in pos if p["asset_class"] in ("Eurobond", "Local bond")) / 100.0
    return Ev(v, "archive", (B015,), "sum of duration x notional over bond positions, x 1 pp")


def _se_gap(c: Ctx) -> Ev:
    lim = json.loads(Path(c.limits_path).read_text())
    lvar = c.metric(B015, "lvar99_mm").value; se = c.metric(B015, "lvar99_se_mm").value
    return Ev((lim["warning_level"] * lim["book"]["lvar99_mm"] - lvar) / se, "archive", (B015,), "(warning level x limit - L-VaR99) / SE")


def _zip_rates(c: Ctx, key: str) -> str:
    zf = c.need_zip("0.1.5")
    sc = next(s for s in json.loads((zf.root / "data" / "scenarios.json").read_text())["scenarios"] if s["key"] == key)
    vals = sorted({float(s["value"]) for s in sc["shocks"] if s.get("target") == "rates"})
    legs = sorted(s["leg"] for s in sc["shocks"] if s.get("target") == "rates")
    return f"+{vals[0]:.0f} bp" if len(vals) == 1 and legs == ["hard", "local"] else f"{vals} {legs}"


def _rep_counts(c: Ctx, status: str) -> Ev:
    md = c.need_zip("0.1.5").replication_md
    m = re.search(r"Status counts: ([^\n]+)", md)
    counts = dict((k, int(v)) for k, v in re.findall(r"([A-Z]+) (\d+)", m.group(1))) if m else {}
    return Ev(counts.get(status, 0), "zip", (), "RELEASE-REPLICATION.md in the zip")


def _register_rows(c: Ctx) -> Ev:
    p = c.need_zip("0.1.5").root / "docs" / "validation" / "dossier" / "findings-register.csv"
    return Ev(len(pd.read_csv(p)), "zip", (), "docs/validation/dossier/findings-register.csv in the 0.1.5 zip")


def _zip_gate(c: Ctx, name: str) -> Ev:
    src = (c.need_zip("0.1.5").root / "econquest" / "validation" / "hazard_panel.py").read_text()
    m = re.search(rf"{name} = ([\d.]+)", src)
    return Ev(float(m.group(1)) if m else None, "zip", (), f"hazard_panel.{name} in the 0.1.5 zip (code constant)")


def _frozen_prices(c: Ctx) -> Ev:
    full = hashlib.sha256(Path(c.frozen_prices).read_bytes()).hexdigest()
    rec = c.archive.versions(B014).get("data_files", {}).get("market_history/prices.csv")
    same = rec == full[:16]
    return Ev(f"{full[:8]}…{full[-4:]}", "file", (B014,), f"sha256 {full}; {'equals' if same else 'DIFFERS from'} the 0.1.4 run's prices.csv hash {rec}")


def _data_not_code(c: Ctx) -> Ev:
    ev = c.rerun("base100_p014", "var99_mm")
    a = c.archive.versions(B014).get("data_files", {}); b = c.archive.versions(B015).get("data_files", {})
    moved = sorted(k for k in set(a) | set(b) if a.get(k) != b.get(k))
    ev.note += f"; 0.1.5 engine on the frozen 0.1.4 prices gives the 0.1.4 base; files whose hash moved between {B014} and {B015}: {', '.join(moved)}"
    ev.runs = (B014, B015)
    return ev


def _zip_revert(c: Ctx) -> Ev:
    zf = c.need_zip("0.1.5")
    return Ev(c.zip_code_as("0.1.4") if zf else "", "zip", (B015,),
              "code hash of the 0.1.5 zip with __version__ set back to 0.1.4")


def _zip_data_vs_run(c: Ctx) -> Ev:
    zf = c.need_zip("0.1.5")
    a = c.archive.versions(B015).get("data_files", {}); b = V.data_hashes(zf.root / "data")
    moved = sorted(k for k in set(a) | set(b) if a.get(k) != b.get(k))
    return Ev(zf.data_hash, "zip", (B015,), "data files that differ from the 0.1.5 base run: " + (", ".join(moved) or "none"))


def catalogue() -> list[Claim]:
    """Every number reported in the Team B release notes 0.1.1, 0.1.3, 0.1.4, 0.1.5 and the Team C package notes
    0.1.1 to 0.1.5, with the evidence for it."""
    C: list[Claim] = []

    def add(cid, rel, doc, q, rep, ev=None, kind="model", why="", tol=None):
        C.append(Claim(cid, rel, doc, q, rep, kind, ev, why, tol))

    m = lambda run, k, scale=1.0: (lambda c: c.metric(run, k, scale))           # noqa: E731
    f = lambda run, d, scale=None: (lambda c: c.field(run, d, scale))            # noqa: E731
    ver = lambda run, k: (lambda c: c.version(run, k))                          # noqa: E731
    rr = lambda job, k: (lambda c: c.rerun(job, k))                             # noqa: E731
    rc = lambda job, k, base: (lambda c: c.rerun_change(job, k, base))          # noqa: E731
    lim = lambda run, k: (lambda c: c.limit_use(run, k))                        # noqa: E731
    pdpp = lambda run, k: (lambda c: c.pd_pp(run, k))                           # noqa: E731

    # ---------------------------------------------------------------- 0.1.1 Team B note
    r = "0.1.1"
    add("N011-01", r, N011, "paths requested (EQ-B-0007)", "100,000", m(B011, "paths_requested"))
    add("N011-02", r, N011, "Sobol paths simulated, 2^17", "131,072", m(B011, "paths"))
    for i, k in enumerate(("VaR99 +0.12%", "ES99 -0.14%", "EL +0.08%"), 3):
        add(f"N011-{i:02d}", r, N011, f"EQ-B-0007 move on frozen inputs: {k.split()[0]}", k.split()[1],
            why="frozen-input before/after run not archived; 0.1.0/0.1.1 code not kept")
    add("N011-06", r, N011, "EQ-B-0007 layer 6 time", "+32%", kind="process", why=PROCESS)
    add("N011-07", r, N011, "EQ-B-0007 memory (MB)", "+55", kind="process", why=PROCESS)
    add("N011-08", r, N011, "signal 15 scale signals.complacency_scale_log2", "0.944", f(B011, "settings.signals.complacency_scale_log2"), "parameter")
    for i, (cty, a, b) in enumerate((("Colombia", "10.0", "9.3"), ("Nigeria", "7.5", "6.45"), ("Belize", "6.0", "5.85"), ("Zimbabwe", "4.5", "3.75"))):
        add(f"N011-{9 + 2 * i:02d}", r, N011, f"{cty} notional $mm before EQ-B-0008 (last pre-0.1.1 base)", a, _notional(PRE011, cty))
        add(f"N011-{10 + 2 * i:02d}", r, N011, f"{cty} notional $mm after EQ-B-0008", b, _notional(B011, cty))
    add("N011-17", r, N011, "trades firing (unchanged)", "72", _fired)
    add("N011-18", r, N011, "EQ-B-0001 max PD move (pp)", "0.009", why="frozen-input before/after run not archived")
    add("N011-19", r, N011, "tests passed (previous release 72-104)", "322", kind="process", why=PROCESS)
    add("N011-20", r, N011, "base code_hash", "9aad74bc0c0f6737", ver(B011, "code_hash"), "hash")
    add("N011-21", r, N011, "base data_hash", "f8cf431f5066ff35", ver(B011, "data_hash"), "hash")
    add("N011-22", r, N011, "base paths (requested 100,000)", "131,072", m(B011, "paths"))
    for i, (k, v) in enumerate((("var99_mm", "67.90"), ("es99_mm", "86.85"), ("expected_loss_mm", "1.83"), ("lvar99_mm", "73.18")), 23):
        add(f"N011-{i}", r, N011, f"base {k}", v, m(B011, k))
    add("N011-27", r, N011, "stress runs archived with the base's run_hash", "8", lambda c: Ev(len(c.runs_sharing(B011)), "archive", (B011,)))
    add("N011-28", r, N011, "backtest Kupiec p", "0.043", why="backtest result not stored in the run archive or the SQLite store")
    add("N011-29", r, N011, "backtest zone", "Yellow", why="backtest result not stored in the run archive or the SQLite store")
    add("N011-30", r, N011, "seed stability: VaR99 spread over 5 seeds", "1.78%", why="seed study not archived")
    add("N011-31", r, N011, "seed stability: VaR99 sd over 10 seeds", "0.53%", why="seed study not archived")

    # ---------------------------------------------------------------- 0.1.1 Team C package
    add("P011-01", r, P011, "zip file count", "273", kind="package", why=NOZIP)
    add("P011-02", r, P011, "zip SHA-256", "9fe1bedaf7773052411c21b6fb269ffc45b5adbb06e8f025976e46582b750f6a", kind="package", why=NOZIP)
    add("P011-03", r, P011, "package code_hash", "8f89f61b67662ebd", _hash_in_archive("8f89f61b67662ebd"), "hash")
    add("P011-04", r, P011, "full suite: 404 passed, 2 skipped; teamctl 0 problems", "404", kind="process", why=PROCESS)
    add("P011-05", r, P011, "bandit medium findings left (Team A and B files)", "7", kind="process", why=PROCESS)
    add("P011-06", r, P011, "presentation test coverage 18% to 90%", "90%", kind="process", why=PROCESS)

    # ---------------------------------------------------------------- 0.1.2 Team C package (no Team B note)
    r = "0.1.2"
    add("P012-01", r, P012, "zip file count", "326", kind="package", why=NOZIP)
    add("P012-02", r, P012, "zip SHA-256", "1a50014762677a1293c6e79fd8ee9a461a1b8cb78ee087f3bf3269ca30a4c22c", kind="package", why=NOZIP)
    add("P012-03", r, P012, "package code_hash", "3b4365831a0eb0f3", _hash_in_archive("3b4365831a0eb0f3"), "hash")
    add("P012-04", r, P012, "full suite: 659 passed, 2 skipped; teamctl 0 problems", "659", kind="process", why=PROCESS)
    add("P012-05", r, P012, "restore-drill time (target under 4 h)", "3.7 s", kind="process", why=PROCESS)
    add("P012-06", r, P012, "country notes (18) build time", "6 s", kind="process", why=PROCESS)
    add("P012-07", r, P012, "fit-hazard gate AUC", "0.75", lambda c: _zip_gate(c, "GATE_MIN_AUC"), "parameter")

    # ---------------------------------------------------------------- 0.1.3 Team B note
    r = "0.1.3"
    add("N013-01", r, N013, "probability.risk_premium_ratio old", "1.0", f(B011, "settings.probability.risk_premium_ratio"), "parameter")
    add("N013-02", r, N013, "probability.risk_premium_ratio new", "2.0", f(B013, "settings.probability.risk_premium_ratio"), "parameter")
    add("N013-03", r, N013, "probability.w_fx_regime_scale.Peg old", "1.0", f(B011, "settings.probability.w_fx_regime_scale.Peg"), "parameter")
    add("N013-04", r, N013, "probability.w_fx_regime_scale.Peg new", "0.0", f(B013, "settings.probability.w_fx_regime_scale.Peg"), "parameter")
    add("N013-05", r, N013, "probability.w_fx_regime_scale.Dollarized old", "1.0", f(B011, "settings.probability.w_fx_regime_scale.Dollarized"), "parameter")
    add("N013-06", r, N013, "probability.w_fx_regime_scale.Dollarized new", "0.0", f(B013, "settings.probability.w_fx_regime_scale.Dollarized"), "parameter")
    add("N013-07", r, N013, "probability.w_m old", "0.5", f(B011, "settings.probability.w_m"), "parameter")
    add("N013-08", r, N013, "probability.w_m new", "0.5", f(B013, "settings.probability.w_m"), "parameter")
    add("N013-09", r, N013, "base code_hash", "f0ce1cbbaee2e577", ver(B013, "code_hash"), "hash")
    add("N013-10", r, N013, "base data_hash", "73569c0bfdd41d7e", ver(B013, "data_hash"), "hash")
    add("N013-11", r, N013, "base run_hash", "69c594db2b543c18", ver(B013, "run_hash"), "hash")
    add("N013-12", r, N013, "base paths", "131,072", m(B013, "paths"))
    add("N013-13", r, N013, "base paths requested", "100,000", m(B013, "paths_requested"))
    for i, (k, a, b) in enumerate((("var99_mm", "67.90", "63.98"), ("es99_mm", "86.85", "83.02"), ("expected_loss_mm", "1.83", "0.53"),
                                   ("lvar99_mm", "73.18", "69.26"))):
        add(f"N013-{14 + 2 * i}", r, N013, f"0.1.1 base {k}", a, m(B011, k))
        add(f"N013-{15 + 2 * i}", r, N013, f"0.1.3 base {k}", b, m(B013, k))
    why_rr = "0.1.2 code not kept: 0.1.5 engine on the frozen 0.1.4 prices with the pre-change settings"
    add("N013-22", r, N013, "EQ-B-0021 before: VaR99 at 32,768 paths", "68.54", rr("pre013_20_p014", "var99_mm"), why=why_rr)
    add("N013-23", r, N013, "EQ-B-0021 after: VaR99 at 32,768 paths", "64.23", rr("pre014_20_p014", "var99_mm"), why=why_rr)
    add("N013-24", r, N013, "EQ-B-0021 VaR99 change", "-6.3%", rc("pre014_20_p014", "var99_mm", "pre013_20_p014"), why=why_rr)
    add("N013-25", r, N013, "EQ-B-0021 before: ES99", "87.42", rr("pre013_20_p014", "es99_mm"), why=why_rr)
    add("N013-26", r, N013, "EQ-B-0021 after: ES99", "83.67", rr("pre014_20_p014", "es99_mm"), why=why_rr)
    add("N013-27", r, N013, "EQ-B-0021 before: EL", "1.86", rr("pre013_20_p014", "expected_loss_mm"), why=why_rr)
    add("N013-28", r, N013, "EQ-B-0021 after: EL", "0.53", rr("pre014_20_p014", "expected_loss_mm"), why=why_rr)
    add("N013-29", r, N013, "countries with a PD move above 2 pp (0.1.1 -> 0.1.3 base)", "Senegal, Pakistan, Argentina", _pd_movers)
    for i, (cty, a, b, d) in enumerate((("Senegal", "23.6", "15.9", "-7.7"), ("Pakistan", "11.5", "8.6", "-2.9"), ("Argentina", "11.9", "9.5", "-2.4"))):
        add(f"N013-{30 + 3 * i}", r, N013, f"{cty} PD (pp) before", a, pdpp(B011, cty))
        add(f"N013-{31 + 3 * i}", r, N013, f"{cty} PD (pp) after", b, pdpp(B013, cty))
        add(f"N013-{32 + 3 * i}", r, N013, f"{cty} PD move (pp)", d,
            _pd_move(B011, B013, cty))
    add("N013-39", r, N013, "Venezuela PD (pp), capped, unchanged", "99.0", pdpp(B013, "Venezuela"))
    add("N013-40", r, N013, "Zimbabwe PD (pp), SD-exempt, unchanged", "78.4", pdpp(B013, "Zimbabwe"))
    add("N013-41", r, N013, "VaR alert threshold alerts.var_change_pct", "10%", f(B013, "settings.alerts.var_change_pct"), "parameter")
    add("N013-42", r, N013, "stress A ES99", "152.4", _stress_es(B013, "A"))
    add("N013-43", r, N013, "stress TAIWAN ES99", "165.8", _stress_es(B013, "TAIWAN"))
    add("N013-44", r, N013, "backtest Kupiec p", "0.043", why="backtest result not stored in the run archive or the SQLite store")
    add("N013-45", r, N013, "governance gate AUC", "0.75", lambda c: _zip_gate(c, "GATE_MIN_AUC"), "parameter")
    add("N013-46", r, N013, "governance gate events", "30", lambda c: _zip_gate(c, "GATE_MIN_EVENTS"), "parameter")
    add("N013-47", r, N013, "tests: 660 passed, 2 skipped", "660", kind="process", why=PROCESS)
    add("N013-48", r, N013, "EQ-B-0020 refit: panel countries / events", "15 / 9", why="hazard refit not archived (no fit archive)")
    add("N013-49", r, N013, "EQ-B-0020 refit Brier", "0.0361", why="hazard refit not archived (no fit archive)")
    add("N013-50", r, N013, "EQ-B-0020 base-rate Brier", "0.0258", why="hazard refit not archived (no fit archive)")
    add("N013-51", r, N013, "stress runs archived with the base's run_hash", "8", lambda c: Ev(len(c.runs_sharing(B013)), "archive", (B013,)))

    # ---------------------------------------------------------------- 0.1.3 Team C package
    add("P013-01", r, P013, "zip file count", "333", kind="package", why=NOZIP)
    add("P013-02", r, P013, "zip SHA-256", "a79b7b9fe022bb3ae4c80c6614fa9c5060b94173a8e5acd4cd1d20d70aec14b9", kind="package", why=NOZIP)
    add("P013-03", r, P013, "package code_hash", "7e5266fe255912d1", _hash_in_archive("7e5266fe255912d1"), "hash")
    add("P013-04", r, P013, "full suite: 660 passed, 2 skipped, then 4 installer tests", "660", kind="process", why=PROCESS)
    add("P013-05", r, P013, "probability.risk_premium_ratio in the zip", "2.0", f(B013, "settings.probability.risk_premium_ratio"), "parameter",
        why="zip not kept; value from the 0.1.3 base run's settings")
    add("P013-06", r, P013, "approval chain rows", "3", kind="process", why=PROCESS)

    # ---------------------------------------------------------------- 0.1.4 Team B note
    r = "0.1.4"
    for i, (d, v) in enumerate((("monte_carlo.vol_source", "garch"), ("copula.source", "estimated"), ("copula.nu_source", "judgement"),
                                ("layer4.lgd_source", "judgement"), ("probability.text_index.source", "none")), 1):
        add(f"N014-{i:02d}", r, N014, d, v, f(B014, "settings." + d), "parameter")
    for i, (cty, v) in enumerate((("Singapore", "0.81"), ("South Korea", "0.51"), ("Malaysia", "0.51")), 6):
        add(f"N014-{i:02d}", r, N014, f"estimated Calm loading {cty}", v, f(B014, f"diagnostics.loadings.{cty}"))
    add("N014-09", r, N014, "judgement Calm global loading", "0.15", f(B014, "settings.regime.Calm.global_loading"), "parameter")
    add("N014-10", r, N014, "HMM regimes VaR99 move (not adopted)", "+27%", rc("hmm20_p014", "var99_mm", "base20_p014"),
        why="experiment not archived; rerun at 20,000 requested paths")
    add("N014-11", r, N014, "base code_hash", "aa838e7b3c2afa89", ver(B014, "code_hash"), "hash")
    add("N014-12", r, N014, "base data_hash", "d26e6518631437a3", ver(B014, "data_hash"), "hash")
    add("N014-13", r, N014, "base run_hash", "81577ea89f9900be", ver(B014, "run_hash"), "hash")
    add("N014-14", r, N014, "base paths", "131,072", m(B014, "paths"))
    add("N014-15", r, N014, "base paths requested", "100,000", m(B014, "paths_requested"))
    for i, (k, a, b) in enumerate((("var99_mm", "63.98", "74.35"), ("es99_mm", "83.02", "96.48"), ("expected_loss_mm", "0.53", "0.45"),
                                   ("lvar99_mm", "69.26", "79.63"))):
        add(f"N014-{16 + 2 * i}", r, N014, f"0.1.3 base {k}", a, m(B013, k))
        add(f"N014-{17 + 2 * i}", r, N014, f"0.1.4 base {k}", b, m(B014, k))
    add("N014-24", r, N014, "VaR99 change 0.1.3 -> 0.1.4", "+16%", lambda c: c.change(B014, "var99_mm", B013))
    add("N014-25", r, N014, "ES99 change 0.1.3 -> 0.1.4", "+16%", lambda c: c.change(B014, "es99_mm", B013))
    add("N014-26", r, N014, "max PD move 0.1.3 -> 0.1.4 (pp), 'No PD moves'", "0", _max_pd_move(B013, B014))
    add("N014-27", r, N014, "VaR alert threshold alerts.var_change_pct", "10%", f(B014, "settings.alerts.var_change_pct"), "parameter")
    add("N014-28", r, N014, "book ES99 (limit section)", "96.5", m(B014, "es99_mm"))
    add("N014-29", r, N014, "ES99 limit", "115", lambda c: Ev(json.loads(Path(c.limits_path).read_text())["book"]["es99_mm"], "file"), "parameter")
    add("N014-30", r, N014, "ES99 utilisation", "84%", lim(B014, "es99_mm"))
    add("N014-31", r, N014, "warning band", "80%", lambda c: Ev(100 * json.loads(Path(c.limits_path).read_text())["warning_level"], "file"), "parameter")
    add("N014-32", r, N014, "VaR99 utilisation", "78%", lim(B014, "var99_mm"))
    add("N014-33", r, N014, "L-VaR99 utilisation (just under the band)", "80%", lim(B014, "lvar99_mm"))
    add("N014-34", r, N014, "stress table base ES99", "96.5", m(B014, "es99_mm"))
    rows = (("155.5", "+61.2%"), ("102.9", "+6.7%"), ("114.9", "+19.1%"), ("101.7", "+5.4%"), ("165.1", "+71.1%"), ("167.1", "+73.2%"),
            ("154.8", "+60.5%"), ("165.2", "+71.2%"))
    for i, (lab, (es, ch)) in enumerate(zip(STRESS, rows)):
        add(f"N014-{35 + 2 * i}", r, N014, f"stress {lab} ES99", es, _stress_es(B014, lab))
        add(f"N014-{36 + 2 * i}", r, N014, f"stress {lab} ES99 change", ch, _stress_chg(B014, lab))
    add("N014-51", r, N014, "EQ-B-0034: countries tested / 88-country run time at 100,000 paths", "7.4 s", kind="process", why=PROCESS)
    add("N014-52", r, N014, "EQ-B-0041: base run time before -> after", "4.8 s -> 2.0 s", kind="process", why=PROCESS)
    add("N014-53", r, N014, "tests: 1,184 passed, 5 skipped", "1,184", kind="process", why=PROCESS)
    why_rr = "proof run not archived; 0.1.5 engine on the frozen 0.1.4 prices with 0.1.3 settings"
    add("N014-54", r, N014, "default-identical proof VaR99 at 20,000", "64.2337", rr("pre014_20_p014", "var99_mm"), why=why_rr)
    add("N014-55", r, N014, "default-identical proof ES99 at 20,000", "83.6673", rr("pre014_20_p014", "es99_mm"), why=why_rr)
    add("N014-56", r, N014, "default-identical proof EL at 20,000", "0.53438", rr("pre014_20_p014", "expected_loss_mm"), why=why_rr)
    add("N014-57", r, N014, "layer 1 calibration set: max desk PD move in placeholder test", "11 pp", why="placeholder test, not archived")
    add("N014-58", r, N014, "desk names (countries in the base run)", "18", lambda c: Ev(len(c.archive.get(B014, "country")), "archive", (B014,)))
    add("N014-59", r, N014, "EQ-B-0034 countries tested", "70", kind="process", why=PROCESS)
    add("N014-60", r, N014, "stress runs archived with the base's run_hash", "8", lambda c: Ev(len(c.runs_sharing(B014)), "archive", (B014,)))

    # ---------------------------------------------------------------- 0.1.4 Team C package
    add("P014-01", r, P014, "zip file count", "427", kind="package", why=NOZIP)
    add("P014-02", r, P014, "zip SHA-256", "891d97ca127aa58702ffb56b9d0f95172fcd0562fd78a76196c58d2cb000df59", kind="package", why=NOZIP)
    add("P014-03", r, P014, "package code_hash", "e8002428bcfbbe1c", _hash_in_archive("e8002428bcfbbe1c"), "hash")
    add("P014-04", r, P014, "SOURCE_DATE_EPOCH", "1761177600", kind="package", why=NOZIP)
    add("P014-05", r, P014, "full suite: 1184 passed, 5 skipped", "1184", kind="process", why=PROCESS)
    add("P014-06", r, P014, "approval chain rows", "6", kind="process", why=PROCESS)
    why_acc = "acceptance run on the unzipped copy is not archived; value from the 0.1.4 base run"
    add("P014-07", r, P014, "acceptance VaR99", "74.35", m(B014, "var99_mm"), why=why_acc)
    add("P014-08", r, P014, "acceptance ES99", "96.48", m(B014, "es99_mm"), why=why_acc)
    add("P014-09", r, P014, "0.1.3 VaR99 (was)", "63.98", m(B013, "var99_mm"))
    add("P014-10", r, P014, "0.1.3 ES99 (was)", "83.02", m(B013, "es99_mm"))
    add("P014-11", r, P014, "ES99 utilisation of 115", "84%", lim(B014, "es99_mm"))
    add("P014-12", r, P014, "unattested hand-entered cells (adjustments 378, prediction_markets 18)", "396", kind="process", why=PROCESS)

    # ---------------------------------------------------------------- 0.1.5 Team B note
    r = "0.1.5"
    add("N015-01", r, N015, "FED22 rates shock (both legs) in scenarios.json", "+200 bp", lambda c: Ev(_zip_rates(c, "FED22"), "zip"), "parameter")
    add("N015-02", r, N015, "TAPER13 rates shock (both legs) in scenarios.json", "+100 bp", lambda c: Ev(_zip_rates(c, "TAPER13"), "zip"), "parameter")
    why_sc = "no FED22/TAPER13 run archived (the 0.1.5 base set ran before the scenario change); 0.1.5 zip engine on zip data"
    add("N015-03", r, N015, "FED22 VaR99 at 100,000 requested", "147.91", rr("fed22_100", "var99_mm"), why=why_sc)
    add("N015-04", r, N015, "FED22 ES99", "176.26", rr("fed22_100", "es99_mm"), why=why_sc)
    add("N015-05", r, N015, "FED22 ES99 vs base", "+84.7%", rc("fed22_100", "es99_mm", "base100"), why=why_sc)
    add("N015-06", r, N015, "TAPER13 VaR99 at 100,000 requested", "135.36", rr("taper13_100", "var99_mm"), why=why_sc)
    add("N015-07", r, N015, "TAPER13 ES99", "166.05", rr("taper13_100", "es99_mm"), why=why_sc)
    add("N015-08", r, N015, "TAPER13 ES99 vs base", "+74.0%", rc("taper13_100", "es99_mm", "base100"), why=why_sc)
    why_p = "not archived; 0.1.5 zip engine on the frozen 0.1.4 prices, rates shocks removed, 20,000 requested"
    add("N015-09", r, N015, "FED22 ES99 before the shock (0.1.4 data)", "168.67", rr("fed22_noshock20_p014", "es99_mm"), why=why_p)
    add("N015-10", r, N015, "TAPER13 ES99 before the shock (0.1.4 data)", "161.79", rr("taper13_noshock20_p014", "es99_mm"), why=why_p)
    why_f = "AGENT-05 comparison not archived; 0.1.5 zip engine on the frozen 0.1.4 prices, 20,000 requested"
    add("N015-11", r, N015, "fixed-input base VaR99 at 20,000", "74.2474", rr("base20_p014", "var99_mm"), why=why_f)
    add("N015-12", r, N015, "fixed-input base ES99 at 20,000", "96.6153", rr("base20_p014", "es99_mm"), why=why_f)
    add("N015-13", r, N015, "fixed-input base EL at 20,000", "0.46273", rr("base20_p014", "expected_loss_mm"), why=why_f)
    add("N015-14", r, N015, "loadable scenarios", "13", lambda c: c.rerun("n_scenarios", "loadable_scenarios"))
    add("N015-15", r, N015, "base paths", "131,072", m(B015, "paths"))
    add("N015-16", r, N015, "base paths requested", "100,000", m(B015, "paths_requested"))
    add("N015-17", r, N015, "base code_hash", "42e612deed7ffdc7", ver(B015, "code_hash"), "hash")
    add("N015-18", r, N015, "base data_hash", "5b4c2637ad43356c", ver(B015, "data_hash"), "hash")
    add("N015-19", r, N015, "base run_hash", "19c63d322677eb94", ver(B015, "run_hash"), "hash")
    for i, (k, a, b) in enumerate((("var99_mm", "74.35", "73.11"), ("es99_mm", "96.48", "95.41"), ("expected_loss_mm", "0.45", "0.46"),
                                   ("lvar99_mm", "79.63", "78.39"))):
        add(f"N015-{20 + 2 * i}", r, N015, f"0.1.4 base {k}", a, m(B014, k))
        add(f"N015-{21 + 2 * i}", r, N015, f"0.1.5 base {k}", b, m(B015, k))
    add("N015-28", r, N015, "VaR99 Monte Carlo SE", "0.31", m(B015, "var99_se_mm"))
    add("N015-29", r, N015, "ES99 Monte Carlo SE", "0.36", m(B015, "es99_se_mm"))
    add("N015-30", r, N015, "Singapore estimated loading 0.1.4", "0.81", f(B014, "diagnostics.loadings.Singapore"))
    add("N015-31", r, N015, "Singapore estimated loading 0.1.5", "0.87", f(B015, "diagnostics.loadings.Singapore"))
    add("N015-32", r, N015, "frozen 0.1.4 prices SHA-256", "c8ddae65…1748", _frozen_prices, "hash")
    add("N015-33", r, N015, "'data, not code': 0.1.5 engine on frozen 0.1.4 prices gives the 0.1.4 VaR99", "74.35", _data_not_code)
    add("N015-34", r, N015, "book ES99 (limits)", "95.4", m(B015, "es99_mm"))
    add("N015-35", r, N015, "ES99 limit", "115", lambda c: Ev(json.loads(Path(c.limits_path).read_text())["book"]["es99_mm"], "file"), "parameter")
    add("N015-36", r, N015, "ES99 utilisation", "83%", lim(B015, "es99_mm"))
    add("N015-37", r, N015, "L-VaR99", "78.4", m(B015, "lvar99_mm"))
    add("N015-38", r, N015, "L-VaR99 utilisation", "78%", lim(B015, "lvar99_mm"))
    add("N015-39", r, N015, "L-VaR99 SEs under the 80% warning level ('about 5')", "5", _se_gap, tol=0.5)
    add("N015-40", r, N015, "warning level", "80%", lambda c: Ev(100 * json.loads(Path(c.limits_path).read_text())["warning_level"], "file"), "parameter")
    add("N015-41", r, N015, "stress base ES99", "95.4", m(B015, "es99_mm"))
    rows = (("155.4", "+62.9%"), ("102.1", "+7.0%"), ("114.3", "+19.8%"), ("100.9", "+5.8%"), ("164.8", "+72.8%"), ("166.8", "+74.8%"),
            ("154.8", "+62.3%"), ("165.1", "+73.0%"))
    for i, (lab, (es, ch)) in enumerate(zip(STRESS, rows)):
        add(f"N015-{42 + 2 * i}", r, N015, f"stress {lab} ES99", es, _stress_es(B015, lab))
        add(f"N015-{43 + 2 * i}", r, N015, f"stress {lab} ES99 change", ch, _stress_chg(B015, lab))
    add("N015-58", r, N015, "replication PASS", "121", lambda c: _rep_counts(c, "PASS"))
    add("N015-59", r, N015, "replication STALE", "0", lambda c: _rep_counts(c, "STALE"))
    add("N015-60", r, N015, "replication FAIL", "0", lambda c: _rep_counts(c, "FAIL"))
    add("N015-61", r, N015, "replication INFO", "2", lambda c: _rep_counts(c, "INFO"))
    why_l = "experiment not archived; 0.1.5 zip engine on the frozen 0.1.4 prices, 20,000 requested"
    add("N015-62", r, N015, "EQ-B-0042 logistic switch VaR99 move", "+4.2%", rc("logistic20_p014", "var99_mm", "base20_p014"), why=why_l)
    add("N015-63", r, N015, "EQ-B-0042 step at 0.4 VaR99 move", "+15.8%", rc("step04_20_p014", "var99_mm", "base20_p014"), why=why_l)
    add("N015-64", r, N015, "EQ-B-0044 cost of +100 bp on today's book", "8.8 $mm", _rate_cost)
    add("N015-65", r, N015, "EQ-B-0051 findings register rows at release", "56", _register_rows, "process")
    add("N015-66", r, N015, "EQ-B-0054 MC SE batches (Sobol blocks)", "32", m(B015, "mc_error_batches"), "parameter")
    add("N015-67", r, N015, "tests: 1,637 passed, 5 skipped", "1,637", kind="process", why=PROCESS)
    add("N015-68", r, N015, "stress runs archived with the base's run_hash", "8", lambda c: Ev(len(c.runs_sharing(B015)), "archive", (B015,)))
    add("N015-69", r, N015, "base code_hash = 0.1.5 zip code with version 0.1.4", "42e612deed7ffdc7", _zip_revert, "hash")

    # ---------------------------------------------------------------- 0.1.5 Team C package
    add("P015-01", r, P015, "zip file count (RELEASE-MANIFEST.txt lines)", "532", _zip_attr("0.1.5", lambda z: z.manifest_files), "package")
    add("P015-02", r, P015, "zip SHA-256", "f738efe07f48f889031627e6fd07ae4fa0847fe22cf36f722c3f511c8ac9871f", _zip_attr("0.1.5", lambda z: z.sha256), "package")
    add("P015-03", r, P015, "package code_hash (recomputed from the zip)", "fd589adddf6acb2f", _zip_attr("0.1.5", lambda z: z.code_hash), "hash")
    add("P015-04", r, P015, "package data_hash (recomputed from the zip)", "af758691c6b94f89", _zip_data_vs_run, "hash")
    add("P015-05", r, P015, "SOURCE_DATE_EPOCH (zip entry dates)", "1761177600", _zip_attr("0.1.5", lambda z: str(int(pd.Timestamp(
        *sorted(z.epoch_dates)[0], tz="UTC").timestamp())) if len(z.epoch_dates) == 1 else str(sorted(z.epoch_dates))), "package")
    add("P015-06", r, P015, "full suite: 1637 passed, 5 skipped", "1637", kind="process", why=PROCESS)
    add("P015-07", r, P015, "replication PASS", "121", lambda c: _rep_counts(c, "PASS"))
    add("P015-08", r, P015, "replication INFO", "2", lambda c: _rep_counts(c, "INFO"))
    add("P015-09", r, P015, "replication FAIL", "0", lambda c: _rep_counts(c, "FAIL"))
    add("P015-10", r, P015, "approval chain rows", "6", kind="process", why=PROCESS)
    for i, (k, v) in enumerate((("var99_mm", "73.11"), ("var99_ci95_lo_mm", "72.48"), ("var99_ci95_hi_mm", "73.73"), ("es99_mm", "95.41"),
                                ("es99_ci95_lo_mm", "94.69"), ("es99_ci95_hi_mm", "96.14"), ("expected_loss_mm", "0.46"), ("lvar99_mm", "78.39"),
                                ("lvar99_ci95_lo_mm", "77.76"), ("lvar99_ci95_hi_mm", "79.01")), 11):
        add(f"P015-{i}", r, P015, f"acceptance {k}", v, m(B015, k), why="acceptance run on the unzipped copy not archived; value from the 0.1.5 base run")
    add("P015-21", r, P015, "acceptance VaR99 rerun on the unzipped copy", "73.11", rr("base100", "var99_mm"))
    add("P015-22", r, P015, "0.1.4 VaR99", "74.35", m(B014, "var99_mm"))
    add("P015-23", r, P015, "0.1.4 ES99", "96.48", m(B014, "es99_mm"))
    add("P015-24", r, P015, "ES99 utilisation", "83%", lim(B015, "es99_mm"))
    add("P015-25", r, P015, "usability SUS estimate", "55", kind="process", why=PROCESS)
    add("P015-26", r, P015, "offline fetch exit time", "5 s", kind="process", why=PROCESS)
    return C


# Numbers in each note that are not reported results: tier, step, layer and list numbers, ticket suffixes, formula
# constants, scenario names, thresholds quoted as definitions, and identifiers the strip patterns leave behind.
LABELS = {
    N011: "1 2 3 15 19 6 9 17 50 100 2027 10 0009 0010 0011 0012 1% 18 4",
    P011: "10 0006 0002 0007 0008 0010 0012 0013 0014 0015 0016 0009 0004 18 6 2 0",
    P012: "10 2 0 0027 15 14 8 4 0025 18 1 5 3 6 7",
    # the 0.1.3 errata (2026-10-24) quote the archived values this module found (VF-015 Belize, VF-016 rounding)
    N013: "0 2 0015 0016 0017 0018 0019 0022 0028 0030 0031 0032 1 12 3 9 6 1.5 0.0 0.5 32,768 2 1 2026 8 0013 0021 0020 0016 0.70 15 10 "
          "7.15 4.86 2.29 7.64 2.84 1.85488",
    P013: "2 1 10 4 3 5 6",
    N014: "0033 0034 0037 0038 0040 0041 0045 0046 1 3 9 6 12 1,1 250 0.30 0 5 88 100,000 20,000 0029 0035 0036 0043 0044 0047 "
          "200 30 2.0 4.8 11",
    P014: "1 10 88 18 378 3 2 4 5 7",
    N015: "0043 0044 0047 0048 0049 0051 0054 2 18 3 1 9 100 200 100,000 20,000 0.4 0042 13 16 88",
    P015: "200 100 10 2 1 23 0052 0056 0057 3.4 3.5 98 95 3 4 7 8 40 5 6",
}


# ---------------------------------------------------------------------------------------------- run and outputs

def replicate_archive(out: str | Path, archive: str | Path = ARCHIVE, db: str | Path | None = DB, zip_path: str | Path | None = None,
                      rerun: bool = False, releases: str | Path = RELEASES, claims: list[Claim] | None = None,
                      labels: dict | None = None, findings: dict | None = None, limits: str | Path = LIMITS,
                      frozen_prices: str | Path = FROZEN_014, log=print) -> dict:
    t0 = time.perf_counter()
    out = Path(out).resolve()
    arch = Archive(Path(archive), Path(db) if db else None)
    if arch.folder.is_dir() and (out == arch.folder.resolve() or arch.folder.resolve() in out.parents):
        raise ValueError(f"--out {out} is inside the archive folder {arch.folder}; the archive is read-only")
    claims = catalogue() if claims is None else claims
    labels = LABELS if labels is None else labels
    ctx = Ctx(arch, limits_path=Path(limits), frozen_prices=Path(frozen_prices), findings=dict(findings or KNOWN_FINDINGS))
    with tempfile.TemporaryDirectory(prefix="eq-archive-") as tmp:
        if zip_path and Path(zip_path).is_file():
            log(f"zip {zip_path}")
            ctx.zip = open_zip(Path(zip_path), Path(tmp) / "zip")
            if rerun:
                if ctx.zip.version != "0.1.5":
                    log(f"  reruns are defined for the 0.1.5 zip; this zip is {ctx.zip.version}: skipped")
                else:
                    verify_zip(ctx.zip, claims)
                    log("  rerunning the zip's engine on frozen inputs (about a minute)")
                    ctx.reruns = run_worker(ctx.zip, rerun_jobs(ctx.zip, Path(frozen_prices)), Path(tmp))
        rows = [tag_finding(evaluate(c, ctx), ctx.findings, KNOWN_BY_KIND if findings is None else {}) for c in claims]
        scan = {}
        for doc in sorted({c.doc for c in claims}):
            p = Path(releases) / doc
            if p.is_file():
                scan[doc] = uncatalogued(p.read_text(), [c for c in claims if c.doc == doc], labels.get(doc, ""))
        stamps = release_stamps(ctx)
    df = pd.DataFrame(rows, columns=COLUMNS)
    meta = {"archive": str(arch.folder), "db": str(arch.db) if arch.db else "none", "zip": str(zip_path) if ctx.zip else "none",
            "zip_version": ctx.zip.version if ctx.zip else "", "rerun": ctx.reruns is not None, "runs": len(arch.files),
            "seconds": time.perf_counter() - t0}
    res = write_outputs(df, scan, stamps, out, meta)
    res.update(rows=df, scan=scan, stamps=stamps)
    return res


def release_stamps(ctx: Ctx) -> list[dict]:
    """Per release: the evidence base run's stamp against the package's stated code_hash."""
    pk = {"0.1.1": "8f89f61b67662ebd", "0.1.3": "7e5266fe255912d1", "0.1.4": "e8002428bcfbbe1c", "0.1.5": "fd589adddf6acb2f"}
    out = []
    for rel, run in (("0.1.1", B011), ("0.1.3", B013), ("0.1.4", B014), ("0.1.5", B015)):
        try:
            i = ctx.archive.integrity(run)
        except Missing:
            out.append({"release": rel, "run": run, "status": "MISSING_ARCHIVE"}); continue
        link = "no"
        if ctx.zip is not None and ctx.zip.version == rel:
            link = "yes: zip code with version {} = run code_hash".format(i["code_version"]) if ctx.zip_code_as(
                i["code_version"]) == i["code_hash"] else "NO: zip code differs beyond the version string"
        elif ctx.zip is None or ctx.zip.version != rel:
            link = "unprovable: zip not kept"
        out.append({"release": rel, "run": run, "stamped_version": i["code_version"], "run_code_hash": i["code_hash"], "package_code_hash": pk[rel],
                    "integrity": "ok" if not i["problems"] else "; ".join(i["problems"]), "sqlite": i["db"],
                    "same_code_as_package": link})
    return out


def write_outputs(df: pd.DataFrame, scan: dict, stamps: list[dict], out: Path, meta: dict) -> dict:
    out.mkdir(parents=True, exist_ok=True)
    csv = out / "archive-replication.csv"; md = out / "archive-replication.md"
    df.map(escape_formula).to_csv(csv, index=False)          # "+15.8%", "-7.7" would open as formulas
    counts = df.groupby(["release", "status"]).size().unstack(fill_value=0) if len(df) else pd.DataFrame()
    for s in STATUSES:
        if s not in counts.columns:
            counts[s] = 0
    counts = counts[list(STATUSES)] if len(counts) else counts
    by_src = df[df.status == "MATCH"].groupby(["release", "source"]).size().unstack(fill_value=0) if len(df) else pd.DataFrame()
    esc = lambda x: str(x).replace("|", "/").replace("\n", " ")                       # noqa: E731
    L = ["# Second-line replication of the release notes from the run archive (EQ-B-0058)", "",
         f"- Archive `{meta['archive']}` ({meta['runs']} runs, read-only); SQLite store `{meta['db']}` (mode=ro).",
         f"- Release zip: {meta['zip']}" + (f" (version {meta['zip_version']})" if meta['zip_version'] else "")
         + f"; reruns of the zip's engine: {'yes' if meta['rerun'] else 'no'}. Runtime {meta['seconds']:.0f} s.",
         "- Evidence per claim: the archived run (JSON, cross-checked with the SQLite row), the kept zip, a file, or a rerun of the "
         "0.1.5 zip's own engine on frozen inputs (`source`). UNARCHIVED: nothing holds the number.", "",
         "## Counts by release", "", "| release | " + " | ".join(STATUSES) + " | matched from archive | matched by rerun/zip/file only |",
         "|---" * (len(STATUSES) + 3) + "|"]
    for rel, row in counts.iterrows():
        src = by_src.loc[rel] if rel in by_src.index else pd.Series(dtype=int)
        L.append(f"| {rel} | " + " | ".join(str(int(row[s])) for s in STATUSES)
                 + f" | {int(src.get('archive', 0))} | {int(sum(v for k, v in src.items() if k != 'archive'))} |")
    kinds = df[df.status == "UNARCHIVED"].groupby(["release", "kind"]).size() if len(df) else pd.Series(dtype=int)
    if len(kinds):
        L += ["", "UNARCHIVED by kind: " + "; ".join(f"{r} {k} {n}" for (r, k), n in kinds.items())]
    L += ["", "## Release stamps (evidence base run against the package)", "",
          "| release | run | stamped version | run code_hash | package code_hash | integrity | SQLite | same code as package |", "|---|---|---|---|---|---|---|---|"]
    for s in stamps:
        L.append("| " + " | ".join(esc(s.get(k, "")) for k in ("release", "run", "stamped_version", "run_code_hash", "package_code_hash",
                                                                 "integrity", "sqlite", "same_code_as_package")) + " |")
    bad = df[df.status.isin(["MISMATCH", "MISSING_ARCHIVE"])]
    L += ["", "## Mismatches", ""] + ([f"- {r.id} ({r.doc}): {r.quantity}: note {r.reported}, evidence {r.value} [{r.source} {r.run_id}]"
                                       + (f" -> {r.finding}" if r.finding else "") for r in bad.itertuples()] or ["- none"])
    L += ["", "## Numbers in the notes not catalogued", ""]
    left = [(d, i, t) for d, toks in scan.items() for i, t in toks]
    L += [f"- {d} line {i}: {t}" for d, i, t in left] or ["- none: every number is a claim above or a listed label (tier, step, ticket suffix, formula constant)"]
    L += ["", "## Claims", "", "| " + " | ".join(COLUMNS) + " |", "|---" * len(COLUMNS) + "|"]
    for r in df.itertuples(index=False):
        L.append("| " + " | ".join(esc(x) for x in r) + " |")
    md.write_text("\n".join(L) + "\n")
    return {"csv": csv, "md": md, "counts": df["status"].value_counts().to_dict() if len(df) else {},
            "uncatalogued": len(left), "unexplained": int(((df.status == "MISMATCH") & (df.finding == "")).sum() + (df.status == "MISSING_ARCHIVE").sum())}


# Open rows in docs/validation/dossier/findings-register.csv (EQ-B-0058): per claim id, then per (status, kind).
KNOWN_FINDINGS = {"N013-29": "VF-015", "N013-27": "VF-016", "N013-32": "VF-016", "N013-35": "VF-016"}
KNOWN_BY_KIND = {("UNARCHIVED", "hash"): "VF-014", ("UNARCHIVED", "package"): "VF-014", ("UNARCHIVED", "model"): "VF-017"}


def tag_finding(row: dict, findings: dict, by_kind: dict) -> dict:
    """Name the findings-register row that covers a claim that is not a MATCH."""
    if row["status"] != "MATCH" and not row["finding"]:
        row["finding"] = findings.get(row["id"]) or by_kind.get((row["status"], row["kind"]), "")
    return row


def main(argv=None) -> int:
    p = argparse.ArgumentParser(prog="python -m econquest.validation.replicate_archive", description=__doc__.split("\n\n")[0])
    p.add_argument("--out", default="outputs/replication-archive", help="folder for archive-replication.csv and .md")
    p.add_argument("--archive", default=str(ARCHIVE), help="run archive folder (read-only)")
    p.add_argument("--db", default=str(DB), help="SQLite store (opened read-only); 'none' to skip the cross-check")
    p.add_argument("--zip", default=str(DEFAULT_ZIP) if DEFAULT_ZIP.is_file() else "none", help="kept release zip; 'none' to skip")
    p.add_argument("--rerun", action="store_true", help="rerun the 0.1.5 zip's engine on frozen inputs (about a minute)")
    a = p.parse_args(argv)
    res = replicate_archive(a.out, a.archive, None if a.db == "none" else a.db, None if a.zip == "none" else a.zip, a.rerun)
    print("status: " + ", ".join(f"{k} {v}" for k, v in sorted(res["counts"].items())) + f"; uncatalogued numbers {res['uncatalogued']}; table {res['md']}")
    return 1 if res["unexplained"] else 0


if __name__ == "__main__":
    raise SystemExit(main())
