"""Scheduled jobs on Sam's Mac (EQ-C-0021): launchd plists in ~/Library/LaunchAgents/com.econquest.<job>.plist.

Jobs (times are in `tz`, default America/New_York; change them in <home>/ops.json or with the CLI flags):

    record   weekdays 18:20  export the Market History tab, `econquest prices`, `econquest record`
                             (docs/runbooks/A-daily-record.md)
    morning  weekdays 07:00  `econquest run` then `econquest report`
    monitor  Mondays  07:45  `econquest monitor` (weekly risk monitor)
    backup   daily    23:30  `python -m econquest.ops.backup --verify` (EQ-C-0022)
    health   every 15 minutes `python -m econquest.ops.health`

Every job runs through the wrapper `python -m econquest.ops.jobs` (jobs.py), which records start, end and exit code
in outputs/logs/ so the health check can see failures. stdout/stderr go to outputs/logs/<job>.out.log / .err.log.

Time zone assumption: launchd's StartCalendarInterval uses the Mac's local clock. Sam is in New York (the record
runbook's 6:20pm New York), so the default assumes the Mac runs on America/New_York and writes the times unchanged.
If the Mac's local zone differs, `install` converts each time to the local clock for today's offsets and prints a
warning: the conversion is then wrong after a DST change in either zone, so reinstall at each change.

`install` and `uninstall` only write or remove plist files and print the `launchctl` commands; they run launchctl
only with load=True (`--load`) on macOS. Plists never contain a token or password: the record job reads the
Sheets token from $ECONQUEST_SHEETS_TOKEN or the Keychain at run time, and jobs.py loads alert settings from
<home>/.ops.env (chmod 600) when present.
"""
from __future__ import annotations
import argparse
import copy
import datetime as dt
import json
import os
import plistlib
import re
import shlex
import subprocess
import sys
from pathlib import Path

LABEL_PREFIX = "com.econquest."
DEFAULT_TZ = "America/New_York"
SPREADSHEET_ID = "1w4OLCkv4EvDFgaO6MBOipAuY2fjAlCQJ-OjtmHJshQY"     # the Risk Desk workbook (cli.py record default)
WEEKDAYS = [1, 2, 3, 4, 5]                                          # launchd Weekday: 0/7 Sunday, 1 Monday ... 6 Saturday
ALL_DAYS = [0, 1, 2, 3, 4, 5, 6]

# Step 1 of the record runbook. The token goes to curl on stdin (-H @-), never on a command line or in the plist.
EXPORT_SCRIPT = (
    'set -euo pipefail\n'
    'TOKEN="${ECONQUEST_SHEETS_TOKEN:-$(security find-generic-password -s econquest-sheets -w)}"\n'
    'printf "Authorization: Bearer %s\\n" "$TOKEN" | curl -sf -H @- '
    '"https://sheets.googleapis.com/v4/spreadsheets/{spreadsheet_id}/values/%27Market%20History%27%21A2%3ABF" '
    '-o "$ECONQUEST_HOME/outputs/market_history.json"\n'
)

DEFAULT_JOBS: dict[str, dict] = {
    "record": {"hour": 18, "minute": 20, "weekdays": WEEKDAYS, "max_minutes": 30, "evidence": "forecast_record",
               "steps": [["/bin/bash", "-c", EXPORT_SCRIPT],
                         ["{launcher}", "prices", "--sheet-json", "{home}/outputs/market_history.json"],
                         ["{launcher}", "record"]]},
    "morning": {"hour": 7, "minute": 0, "weekdays": WEEKDAYS, "max_minutes": 90, "evidence": "store_run",
                "steps": [["{launcher}", "run"], ["{launcher}", "report"]]},
    "monitor": {"hour": 7, "minute": 45, "weekdays": [1], "max_minutes": 30, "evidence": "job",
                "steps": [["{launcher}", "monitor"]]},
    "backup": {"hour": 23, "minute": 30, "weekdays": ALL_DAYS, "max_minutes": 60, "evidence": "job",
               "steps": [["{python}", "-m", "econquest.ops.backup", "--home", "{home}", "--verify"]]},
    "health": {"interval_minutes": 15, "max_minutes": 5, "evidence": None,
               "steps": [["{python}", "-m", "econquest.ops.health", "--home", "{home}"]]},
}

DEFAULT_CONFIG = {"tz": DEFAULT_TZ, "grace_minutes": 15, "stale_feed_days": 7, "holidays": [],
                  "spreadsheet_id": SPREADSHEET_ID, "jobs": DEFAULT_JOBS}


def _merge(base: dict, over: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        out[k] = _merge(out[k], v) if isinstance(v, dict) and isinstance(out.get(k), dict) else copy.deepcopy(v)
    return out


def load_config(home: str | Path, overrides: dict | None = None) -> dict:
    """Defaults, then <home>/ops.json (Sam's local settings, optional), then `overrides`."""
    cfg = copy.deepcopy(DEFAULT_CONFIG)
    p = Path(home) / "ops.json"
    if p.exists():
        cfg = _merge(cfg, json.loads(p.read_text()))
    return _merge(cfg, overrides or {})


def paths(home: str | Path, launcher: str | Path | None = None, python: str | Path | None = None,
          launch_agents: str | Path | None = None) -> dict:
    """Absolute paths the plists use. The launcher is the one install.sh writes ($HOME/.local/bin/econquest)."""
    home = Path(home).expanduser().resolve()
    return {"home": home,
            "launcher": Path(launcher).expanduser() if launcher else Path.home() / ".local" / "bin" / "econquest",
            "python": Path(python).expanduser() if python else home / ".venv" / "bin" / "python",
            "logs": home / "outputs" / "logs",
            "launch_agents": Path(launch_agents).expanduser() if launch_agents else Path.home() / "Library" / "LaunchAgents"}


def resolve_steps(job: dict, p: dict, cfg: dict) -> list[list[str]]:
    sid = str(cfg.get("spreadsheet_id", SPREADSHEET_ID))
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", sid):        # spliced into the record job's bash -c script (AGENT-09 review)
        raise ValueError(f"spreadsheet_id in ops.json must be letters, digits, '-' or '_', got {sid!r}")
    sub = {"home": str(p["home"]), "launcher": str(p["launcher"]), "python": str(p["python"]), "spreadsheet_id": sid}
    def fill(a: str) -> str:                       # plain replace: the shell step also holds ${...} expansions
        for k, v in sub.items():
            a = a.replace("{" + k + "}", v)
        return a
    return [[fill(a) for a in step] for step in job["steps"]]


def to_local(hour: int, minute: int, weekdays: list[int], tz: str, local_tz=None, on: dt.date | None = None) -> tuple[int, int, list[int], bool]:
    """Convert a wall-clock time in `tz` to the Mac's local clock for the offsets on date `on`.
    Returns (hour, minute, weekdays, converted). Weekdays shift when the conversion crosses midnight."""
    from zoneinfo import ZoneInfo
    on = on or dt.date.today()
    src = dt.datetime.combine(on, dt.time(hour, minute), tzinfo=ZoneInfo(tz))
    local_tz = local_tz or dt.datetime.now().astimezone().tzinfo
    loc = src.astimezone(local_tz)
    if loc.utcoffset() == src.utcoffset():
        return hour, minute, list(weekdays), False
    shift = (loc.date() - src.date()).days
    return loc.hour, loc.minute, sorted({(d + shift) % 7 for d in weekdays}), True


def plist_for(name: str, job: dict, p: dict, cfg: dict, local_tz=None, on: dt.date | None = None) -> tuple[dict, list[str]]:
    """The launchd plist dict for one job, and any warnings."""
    warnings: list[str] = []
    steps = resolve_steps(job, p, cfg)
    args = [str(p["python"]), "-m", "econquest.ops.jobs", "--home", str(p["home"]), "--job", name]
    for s in steps:
        args += ["--step", json.dumps(s)]
    env = {"ECONQUEST_HOME": str(p["home"]),
           "PATH": f"{p['launcher'].parent}:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"}
    if os.environ.get("ECONQUEST_BACKUP_DEST") and name == "backup":
        env["ECONQUEST_BACKUP_DEST"] = os.environ["ECONQUEST_BACKUP_DEST"]
    pl = {"Label": LABEL_PREFIX + name, "ProgramArguments": args, "WorkingDirectory": str(p["home"]),
          "EnvironmentVariables": env, "RunAtLoad": False, "ProcessType": "Background",
          "StandardOutPath": str(p["logs"] / f"{name}.out.log"), "StandardErrorPath": str(p["logs"] / f"{name}.err.log")}
    if job.get("interval_minutes"):
        pl["StartInterval"] = int(job["interval_minutes"]) * 60
    else:
        h, m, days, conv = to_local(int(job["hour"]), int(job["minute"]), job.get("weekdays", ALL_DAYS), cfg.get("tz", DEFAULT_TZ), local_tz, on)
        if conv:
            warnings.append(f"{name}: {job['hour']:02d}:{job['minute']:02d} {cfg.get('tz')} written as {h:02d}:{m:02d} Mac local time; "
                            "reinstall after a DST change")
        if sorted(days) == ALL_DAYS:
            pl["StartCalendarInterval"] = {"Hour": h, "Minute": m}
        else:
            pl["StartCalendarInterval"] = [{"Weekday": d, "Hour": h, "Minute": m} for d in days]
    return pl, warnings


def plist_path(p: dict, name: str) -> Path:
    return p["launch_agents"] / f"{LABEL_PREFIX}{name}.plist"


def launchctl_commands(p: dict, names: list[str], action: str) -> list[str]:
    out = []
    for n in names:
        f = shlex.quote(str(plist_path(p, n)))
        if action == "install":
            out += [f"launchctl bootout gui/$UID/{LABEL_PREFIX}{n} 2>/dev/null || true", f"launchctl bootstrap gui/$UID {f}"]
        else:
            out.append(f"launchctl bootout gui/$UID/{LABEL_PREFIX}{n}")
    return out


def _run_launchctl(cmds: list[str], log) -> None:
    if sys.platform != "darwin":
        log("[schedule] --load ignored: launchctl runs on macOS only. Commands not run.")
        return
    uid = str(os.getuid())
    for c in cmds:
        argv = shlex.split(c.replace("$UID", uid).replace(" 2>/dev/null || true", ""))
        r = subprocess.run(argv, capture_output=True, text=True)
        log(f"[schedule] {' '.join(argv)} -> exit {r.returncode} {r.stderr.strip()}")


def install(home: str | Path, cfg: dict | None = None, jobs: list[str] | None = None, load: bool = False, now: dt.datetime | None = None,
            local_tz=None, log=print, **path_kw) -> dict:
    """Write the plists (backing up a different existing one to <plist>.bak-<ts>), write outputs/logs/schedule.json
    (what the health check expects) and print the launchctl commands. Runs launchctl only with load=True on macOS."""
    p = paths(home, **path_kw)
    cfg = cfg or load_config(p["home"])
    now = now or dt.datetime.now(dt.timezone.utc)
    names = jobs or list(cfg["jobs"])
    p["launch_agents"].mkdir(parents=True, exist_ok=True); p["logs"].mkdir(parents=True, exist_ok=True)
    written, warnings = [], []
    for n in names:
        pl, w = plist_for(n, cfg["jobs"][n], p, cfg, local_tz, now.date())
        warnings += w
        f = plist_path(p, n); data = plistlib.dumps(pl)
        if f.exists() and f.read_bytes() != data:
            bak = f.with_name(f.name + f".bak-{now.strftime('%Y%m%dT%H%M%SZ')}")
            bak.write_bytes(f.read_bytes()); log(f"[schedule] existing {f} saved as {bak}")
        f.write_bytes(data); written.append(str(f))
    for w in warnings:
        log(f"[schedule] WARNING {w}")
    if not p["launcher"].exists():
        log(f"[schedule] WARNING launcher {p['launcher']} not found: run install.sh first")
    rec_path = p["logs"] / "schedule.json"
    rec = json.loads(rec_path.read_text()) if rec_path.exists() else {}
    rec.update({"installed_at": rec.get("installed_at") if rec.get("status") == "installed" else now.isoformat(timespec="seconds"),
                "updated_at": now.isoformat(timespec="seconds"), "status": "installed", "tz": cfg.get("tz", DEFAULT_TZ),
                "grace_minutes": cfg.get("grace_minutes", 15), "stale_feed_days": cfg.get("stale_feed_days", 7),
                "holidays": cfg.get("holidays", []), "plists": written,
                "jobs": {n: {k: v for k, v in cfg["jobs"][n].items() if k != "steps"} for n in names}})
    rec_path.write_text(json.dumps(rec, indent=1))
    cmds = launchctl_commands(p, names, "install")
    log("[schedule] wrote " + ", ".join(written))
    log("[schedule] load them with:\n  " + "\n  ".join(cmds))
    log("[schedule] the Mac must be awake: e.g. sudo pmset repeat wakeorpoweron MTWRF 06:55:00 (launchd runs a calendar job "
        "missed during sleep once on wake)")
    if load:
        _run_launchctl(cmds, log)
    return {"plists": written, "commands": cmds, "warnings": warnings, "schedule": str(rec_path)}


def uninstall(home: str | Path, jobs: list[str] | None = None, load: bool = False, now: dt.datetime | None = None, log=print, **path_kw) -> dict:
    """Print the bootout commands (run them with load=True on macOS), then remove the com.econquest.<job> plists."""
    p = paths(home, **path_kw)
    now = now or dt.datetime.now(dt.timezone.utc)
    names = jobs or list(DEFAULT_JOBS)
    cmds = launchctl_commands(p, names, "uninstall")
    log("[schedule] unload with:\n  " + "\n  ".join(cmds))
    if load:
        _run_launchctl(cmds, log)
    removed = []
    for n in names:
        f = plist_path(p, n)
        if f.exists():
            f.unlink(); removed.append(str(f))
    rec_path = p["logs"] / "schedule.json"
    if rec_path.exists():
        rec = json.loads(rec_path.read_text())
        left = {k: v for k, v in rec.get("jobs", {}).items() if k not in names}
        rec.update({"jobs": left, "status": "installed" if left else "uninstalled", "updated_at": now.isoformat(timespec="seconds")})
        rec_path.write_text(json.dumps(rec, indent=1))
    log("[schedule] removed " + (", ".join(removed) or "nothing (no plists found)"))
    return {"removed": removed, "commands": cmds}


def show(home: str | Path, cfg: dict | None = None, log=print, **path_kw) -> dict:
    p = paths(home, **path_kw)
    cfg = cfg or load_config(p["home"])
    rows = {}
    for n, j in cfg["jobs"].items():
        f = plist_path(p, n)
        when = f"every {j['interval_minutes']} min" if j.get("interval_minutes") else \
            f"{j['hour']:02d}:{j['minute']:02d} {cfg.get('tz')} on {','.join('SMTWTFS'[d] for d in j.get('weekdays', ALL_DAYS))}"
        last = p["logs"] / "jobs" / f"{n}.last.json"
        lj = json.loads(last.read_text()) if last.exists() else {}
        rows[n] = {"when": when, "plist": str(f), "installed": f.exists(), "last_status": lj.get("status"),
                   "last_exit": lj.get("exit_code"), "last_end": lj.get("ended_at")}
        log(f"{n:8s} {when:38s} {'installed' if f.exists() else 'not installed':14s} last: {lj.get('status', '-')} "
            f"exit {lj.get('exit_code', '-')} {lj.get('ended_at') or ''}")
    return rows


def _time_arg(s: str) -> tuple[int, int]:
    h, m = s.split(":")
    h, m = int(h), int(m)
    if not (0 <= h < 24 and 0 <= m < 60):
        raise argparse.ArgumentTypeError(f"bad time {s}: use HH:MM")
    return h, m


def add_arguments(ap: argparse.ArgumentParser) -> None:
    ap.add_argument("action", choices=["install", "uninstall", "show"])
    ap.add_argument("--job", action="append", choices=list(DEFAULT_JOBS), help="only this job (repeatable; default all)")
    ap.add_argument("--load", action="store_true", help="also run launchctl bootstrap/bootout (macOS only)")
    ap.add_argument("--tz", help=f"time zone the job times are in (default {DEFAULT_TZ})")
    for j in ("record", "morning", "monitor", "backup"):
        ap.add_argument(f"--{j}-time", type=_time_arg, metavar="HH:MM", help=f"{j} job time (default {DEFAULT_JOBS[j]['hour']:02d}:{DEFAULT_JOBS[j]['minute']:02d})")
    ap.add_argument("--launcher", help="econquest launcher (default ~/.local/bin/econquest, written by install.sh)")
    ap.add_argument("--python", help="venv python (default <home>/.venv/bin/python)")
    ap.add_argument("--launch-agents", help="plist folder (default ~/Library/LaunchAgents)")


def run_from_args(args, home: str | Path, log=print) -> dict:
    over: dict = {"jobs": {}}
    if args.tz:
        over["tz"] = args.tz
    for j in ("record", "morning", "monitor", "backup"):
        t = getattr(args, f"{j}_time")
        if t:
            over["jobs"][j] = {"hour": t[0], "minute": t[1]}
    kw = {"launcher": args.launcher, "python": args.python, "launch_agents": args.launch_agents}
    if args.action == "install":
        return install(home, load_config(home, over), jobs=args.job, load=args.load, log=log, **kw)
    if args.action == "uninstall":
        return uninstall(home, jobs=args.job, load=args.load, log=log, **kw)
    return show(home, load_config(home, over), log=log, **kw)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ops.schedule", description="launchd jobs for econquest on macOS")
    ap.add_argument("--home", default=os.environ.get("ECONQUEST_HOME", str(Path.home() / "econquest")))
    add_arguments(ap)
    args = ap.parse_args(argv)
    run_from_args(args, args.home)
    return 0


if __name__ == "__main__":
    sys.exit(main())
