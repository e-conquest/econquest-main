"""Nightly backup, verify, restore and the restore drill (EQ-C-0022).

What is backed up: all of <home>/data (inputs, data/live incl. vintages/, snapshots/ and review_ledger.csv,
forecast_record.csv, benchmarks.csv, market_history/) and the run store <home>/outputs/store (econquest.sqlite,
panoptix.sqlite, archive/ with run JSONs and loss paths). SQLite files are copied with the sqlite3 backup API so a
job writing at the same time cannot leave a torn copy. Symlinks are followed: the archive holds files, not links.

Where: $ECONQUEST_BACKUP_DEST, else ~/econquest-backups/nightly. Point ECONQUEST_BACKUP_DEST at an iCloud Drive,
Dropbox or external-drive folder to get the copy off the Mac's disk. Each backup is

    <dest>/<UTC date>/econquest-<UTC ts>.tar.gz          the archive; MANIFEST.json inside lists sha256 per file
    <dest>/<UTC date>/econquest-<UTC ts>.manifest.json   the same manifest plus the archive's own sha256

Retention (only folders named YYYY-MM-DD under <dest> are ever deleted): the 14 newest daily folders, plus the newest
folder of each of the 8 most recent ISO weeks not already covered by those 14.

verify: archive sha256 equals the sidecar's, every member's sha256 equals the manifest, no file missing or extra.
restore(backup, target): verifies, extracts regular files only (no absolute paths, no "..", no links) into an empty
target, and re-hashes every restored file.

File modes (HO-20261024-A-C-006, SEC-A-006 L7): manifest format 2 records each file's permission bits ("mode") and
restore re-applies them. Vintage and replay-snapshot trees (READ_ONLY_PREFIXES, threat model T4) are restored
read-only whatever the backup says: files 0444, the directories below each prefix 0555. A format 1 backup (no
modes) restores those trees read-only and every other file with the default mode. restore_drill: restore the latest backup into a temp dir, smoke check
(load_universe on the restored data/, open the restored store and load its latest run, data_hash equals the one
recorded at backup time), time it against the 4-hour target, write outputs/logs/restore-drill-<ts>.json.
"""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import io
import json
import os
import re
import shutil
import sqlite3
import stat
import sys
import tarfile
import tempfile
import time
from pathlib import Path, PurePosixPath

SOURCES = ("data", "outputs/store")
SKIP_NAMES = {"__pycache__", ".DS_Store"}
DAY_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
MANIFEST_NAME = "MANIFEST.json"
KEEP_DAILY, KEEP_WEEKLY = 14, 8
DRILL_TARGET_HOURS = 4.0
MANIFEST_FORMAT = 2                                   # 2: files[rel]["mode"] (EQ-C-0070); 1: no modes
READ_ONLY_PREFIXES = ("data/live/vintages", "data/live/snapshots", "data/panel/vintages", "data/live/market/snapshots")
READ_ONLY_FILE_MODE, READ_ONLY_DIR_MODE = 0o444, 0o555


class BackupError(RuntimeError):
    pass


def default_dest(env: dict | None = None) -> Path:
    env = os.environ if env is None else env
    return Path(env.get("ECONQUEST_BACKUP_DEST") or Path.home() / "econquest-backups" / "nightly").expanduser()


def _sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _iter_files(root: Path):
    """Regular files under root, following symlinks (a symlinked data/ is backed up as files)."""
    for dirpath, dirnames, filenames in os.walk(root, followlinks=True):
        dirnames[:] = sorted(d for d in dirnames if d not in SKIP_NAMES)
        for fn in sorted(filenames):
            if fn in SKIP_NAMES or fn.endswith((".pyc", "-journal", "-wal", "-shm")):
                continue
            p = Path(dirpath) / fn
            if p.is_file():
                yield p


def _is_sqlite(p: Path) -> bool:
    if p.suffix not in (".sqlite", ".sqlite3", ".db"):
        return False
    with open(p, "rb") as f:
        return f.read(16) == b"SQLite format 3\x00"


def _sqlite_snapshot(src: Path, dst: Path) -> None:
    s = sqlite3.connect(f"file:{src}?mode=ro", uri=True)
    d = sqlite3.connect(dst)
    try:
        s.backup(d)
    finally:
        d.close(); s.close()


def create_backup(home: str | Path, dest: str | Path | None = None, now: dt.datetime | None = None, prune: bool = True,
                  keep_daily: int = KEEP_DAILY, keep_weekly: int = KEEP_WEEKLY, verify_after: bool = False, log=print) -> dict:
    """Write one backup of data/ and outputs/store. Returns {archive, manifest, files, bytes, pruned, verify}."""
    home = Path(home).expanduser()
    dest = Path(dest).expanduser() if dest else default_dest()
    now = (now or dt.datetime.now(dt.timezone.utc)).astimezone(dt.timezone.utc)
    if not (home / "data").is_dir():
        raise BackupError(f"{home / 'data'} not found: nothing to back up")
    rdest = dest.resolve()
    for src in SOURCES:                                   # a dest inside a source would back up (and prune) itself
        if rdest == (home / src).resolve() or (home / src).resolve() in rdest.parents:
            raise BackupError(f"backup destination {dest} is inside {home / src}; choose a folder outside data/ and outputs/store")
    day = dest / now.strftime("%Y-%m-%d"); day.mkdir(parents=True, exist_ok=True)
    stem = f"econquest-{now.strftime('%Y%m%dT%H%M%SZ')}"
    arch = day / f"{stem}.tar.gz"
    n = 1
    while arch.exists():
        n += 1; arch = day / f"{stem}-{n}.tar.gz"
    files: dict[str, dict] = {}
    partial = arch.with_name(arch.name + ".partial")
    t0 = time.monotonic()
    with tempfile.TemporaryDirectory(prefix="econquest-backup-") as td, tarfile.open(partial, "w:gz", compresslevel=6) as tar:
        for src in SOURCES:
            root = home / src
            if not root.exists():
                log(f"[backup] {root} not found: skipped")
                continue
            for p in _iter_files(root):
                rel = (PurePosixPath(src) / p.relative_to(root).as_posix()).as_posix()
                real = p
                if _is_sqlite(p):
                    real = Path(td) / f"snap-{len(files)}.sqlite"; _sqlite_snapshot(p, real)
                data = real.read_bytes()                # files are small (largest a few MB); hash exactly what is archived
                digest = hashlib.sha256(data).hexdigest()
                st = p.stat()
                mode = stat.S_IMODE(st.st_mode) & 0o777          # permission bits only (no setuid/setgid/sticky)
                ti = tarfile.TarInfo(rel); ti.size = len(data); ti.mtime = int(st.st_mtime); ti.mode = mode
                tar.addfile(ti, io.BytesIO(data))
                files[rel] = {"sha256": digest, "size": len(data), "mode": f"{mode:04o}"}
        try:
            from ..versioning import data_hash
            dh = data_hash(home / "data")
        except Exception as e:                          # never fail a backup on the hash
            dh = None; log(f"[backup] data_hash not computed: {e}")
        try:
            from .. import __version__ as ver
        except ImportError:
            ver = None
        manifest = {"format": MANIFEST_FORMAT, "created_at": now.isoformat(timespec="seconds"), "home": str(home), "sources": list(SOURCES),
                    "econquest_version": ver, "data_hash": dh, "file_count": len(files),
                    "bytes": sum(f["size"] for f in files.values()), "files": files}
        mb = json.dumps(manifest, indent=1, sort_keys=True).encode()
        ti = tarfile.TarInfo(MANIFEST_NAME); ti.size = len(mb); ti.mtime = int(now.timestamp()); ti.mode = 0o644
        tar.addfile(ti, io.BytesIO(mb))
    partial.replace(arch)
    side = {**manifest, "archive": arch.name, "archive_sha256": _sha256_file(arch), "archive_bytes": arch.stat().st_size}
    mpath = arch.with_name(arch.name[:-len(".tar.gz")] + ".manifest.json")
    mpath.write_text(json.dumps(side, indent=1, sort_keys=True))
    log(f"[backup] {arch} ({len(files)} files, {side['archive_bytes'] / 1e6:.1f} MB compressed, {time.monotonic() - t0:.1f}s)")
    out = {"archive": str(arch), "manifest": str(mpath), "files": len(files), "bytes": manifest["bytes"], "data_hash": dh,
           "pruned": [], "verify": None}
    if verify_after:
        out["verify"] = verify(arch, log=log)
    if prune:
        out["pruned"] = prune_backups(dest, keep_daily, keep_weekly, log=log)
    return out


def select_retained(days: list[dt.date], keep_daily: int = KEEP_DAILY, keep_weekly: int = KEEP_WEEKLY) -> set[dt.date]:
    """The newest keep_daily days, plus the newest day of each of the keep_weekly most recent ISO weeks that have no day
    among those kept as daily."""
    ds = sorted(set(days), reverse=True)
    keep = set(ds[:keep_daily])
    covered = {d.isocalendar()[:2] for d in keep}
    weeks: list[dt.date] = []
    seen: set = set()
    for d in ds[keep_daily:]:
        wk = d.isocalendar()[:2]
        if wk in covered or wk in seen:
            continue
        seen.add(wk); weeks.append(d)
        if len(weeks) >= keep_weekly:
            break
    return keep | set(weeks)


def prune_backups(dest: str | Path, keep_daily: int = KEEP_DAILY, keep_weekly: int = KEEP_WEEKLY, log=print) -> list[str]:
    dest = Path(dest)
    days = {}
    for p in dest.iterdir() if dest.exists() else []:
        # Only day folders this tool wrote (they hold an econquest-*.manifest.json), never a symlink: a dest pointed at
        # the wrong folder (e.g. data/live/vintages, whose legacy ids are dates) must not lose it (AGENT-09 review).
        if p.is_dir() and not p.is_symlink() and DAY_RE.match(p.name) and any(p.glob("econquest-*.manifest.json")):
            try:
                days[dt.date.fromisoformat(p.name)] = p
            except ValueError:
                continue
    keep = select_retained(list(days), keep_daily, keep_weekly)
    removed = []
    for d, p in sorted(days.items()):
        if d not in keep:
            shutil.rmtree(p); removed.append(str(p))
    if removed:
        log(f"[backup] retention removed {len(removed)} folder(s): {', '.join(Path(r).name for r in removed)}")
    return removed


def list_backups(dest: str | Path | None = None) -> list[Path]:
    """Archives under dest, oldest first."""
    dest = Path(dest).expanduser() if dest else default_dest()
    if not dest.exists():
        return []
    return sorted((a for d in dest.iterdir() if d.is_dir() and DAY_RE.match(d.name) for a in d.glob("econquest-*.tar.gz")),
                  key=lambda a: a.name)


def _resolve(backup: str | Path) -> tuple[Path, Path]:
    b = Path(backup).expanduser()
    if b.is_dir():
        found = sorted(b.glob("econquest-*.tar.gz")) or (list_backups(b)[-1:] if list_backups(b) else [])
        if not found:
            raise BackupError(f"no econquest-*.tar.gz in {b}")
        b = found[-1]
    if b.name.endswith(".manifest.json"):
        b = b.with_name(b.name[:-len(".manifest.json")] + ".tar.gz")
    m = b.with_name(b.name[:-len(".tar.gz")] + ".manifest.json")
    if not b.exists():
        raise BackupError(f"{b} not found")
    if not m.exists():
        raise BackupError(f"manifest {m} not found")
    return b, m


def _safe_name(name: str) -> bool:
    p = PurePosixPath(name)
    return bool(name) and not p.is_absolute() and ".." not in p.parts and "\\" not in name and ":" not in p.parts[0]


def _read_only_path(rel: str) -> bool:
    return any(rel.startswith(p + "/") for p in READ_ONLY_PREFIXES)


def restored_mode(rel: str, entry: dict) -> int | None:
    """The mode a restored file gets: read-only under READ_ONLY_PREFIXES, else the recorded mode (format 2), else None
    (format 1: leave the default)."""
    rec = entry.get("mode")
    mode = None
    if isinstance(rec, str) and re.fullmatch(r"0?[0-7]{3}", rec):
        mode = (int(rec, 8) & 0o777) | 0o400         # the owner can always read it back (re-hash)
    if _read_only_path(rel):
        return READ_ONLY_FILE_MODE if mode is None else mode & READ_ONLY_FILE_MODE
    return mode


def _read_only_dirs(root: Path, rels) -> list[Path]:
    """The directories strictly below each READ_ONLY_PREFIX that hold a restored file, deepest first (the prefix
    itself stays writable, so new vintages can be added)."""
    dirs = set()
    for rel in rels:
        for pre in READ_ONLY_PREFIXES:
            if rel.startswith(pre + "/"):
                parts = PurePosixPath(rel[len(pre) + 1:]).parts[:-1]
                for i in range(1, len(parts) + 1):
                    dirs.add(PurePosixPath(pre, *parts[:i]).as_posix())
    return [root / d for d in sorted(dirs, key=lambda d: (-d.count("/"), d))]


def _rmtree(path: Path) -> None:
    """shutil.rmtree for a tree with read-only directories (a restored vintage tree is 0555): make every directory
    owner-writable first, then delete. Symlinks are never followed."""
    for dirpath, dirnames, _ in os.walk(path):
        for d in dirnames:
            q = os.path.join(dirpath, d)
            if not os.path.islink(q):
                try:
                    os.chmod(q, 0o700)
                except OSError:
                    pass
    shutil.rmtree(path, ignore_errors=True)


def _walk_archive(arch: Path, manifest: dict, sink=None) -> list[str]:
    """Hash every member against the manifest; with `sink(rel, fileobj_bytes)` also write them. Returns errors."""
    errors, seen = [], set()
    files = manifest.get("files", {})
    with tarfile.open(arch, "r:gz") as tar:
        for ti in tar:
            if ti.name == MANIFEST_NAME:
                continue
            if not ti.isfile():
                errors.append(f"{ti.name}: not a regular file (refused)"); continue
            if not _safe_name(ti.name) or not any(ti.name == s or ti.name.startswith(s + "/") for s in SOURCES):
                errors.append(f"{ti.name}: unsafe or unexpected path (refused)"); continue
            exp = files.get(ti.name)
            if exp is None:
                errors.append(f"{ti.name}: not in the manifest"); continue
            data = tar.extractfile(ti).read()
            seen.add(ti.name)
            if hashlib.sha256(data).hexdigest() != exp["sha256"]:
                errors.append(f"{ti.name}: sha256 mismatch"); continue
            if sink:
                sink(ti.name, data)
    errors += [f"{rel}: missing from the archive" for rel in sorted(set(files) - seen)]
    return errors


def verify(backup: str | Path, log=print) -> dict:
    """Check the archive hash and every file hash. Returns {ok, archive, files, errors}."""
    arch, mpath = _resolve(backup)
    side = json.loads(mpath.read_text())
    errors = []
    if _sha256_file(arch) != side.get("archive_sha256"):
        errors.append("archive sha256 differs from the manifest (file changed or truncated)")
    try:
        with tarfile.open(arch, "r:gz") as tar:
            inner = json.loads(tar.extractfile(MANIFEST_NAME).read())
        if inner.get("files") != side.get("files"):
            errors.append("MANIFEST.json inside the archive differs from the sidecar manifest")
        errors += _walk_archive(arch, side)
    except (tarfile.TarError, OSError, KeyError, EOFError, json.JSONDecodeError) as e:
        errors.append(f"archive unreadable: {e}")
    ok = not errors
    log(f"[backup] verify {arch.name}: {'OK' if ok else 'FAILED'} ({side.get('file_count')} files)" + ("" if ok else "\n  " + "\n  ".join(errors[:20])))
    return {"ok": ok, "archive": str(arch), "files": side.get("file_count"), "errors": errors}


def restore(backup: str | Path, target_dir: str | Path, log=print) -> dict:
    """Verify, then extract into target_dir (must be empty or absent) and re-hash every restored file."""
    arch, mpath = _resolve(backup)
    target = Path(target_dir).expanduser()
    if target.exists() and any(target.iterdir()):
        raise BackupError(f"{target} is not empty: restore only into an empty folder, then copy back by hand (A-restore.md)")
    v = verify(arch, log=log)
    if not v["ok"]:
        return {"ok": False, "target": str(target), "files": 0, "errors": v["errors"], "archive": str(arch)}
    side = json.loads(mpath.read_text())
    target.mkdir(parents=True, exist_ok=True)
    root = target.resolve()

    def sink(rel: str, data: bytes):
        out = (root / rel).resolve()
        if root not in out.parents:
            raise BackupError(f"{rel} escapes {root}")
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(data)
        mode = restored_mode(rel, side["files"].get(rel, {}))
        if mode is not None:
            os.chmod(out, mode)

    errors = _walk_archive(arch, side, sink)
    for d in _read_only_dirs(root, side["files"]):              # after every file is written: deepest first
        if d.is_dir() and not d.is_symlink():
            os.chmod(d, READ_ONLY_DIR_MODE)
    for rel, f in side["files"].items():                          # re-hash what landed on disk
        p = root / rel
        if not p.exists() or _sha256_file(p) != f["sha256"]:
            errors.append(f"{rel}: restored file missing or hash differs")
    ok = not errors
    log(f"[restore] {arch.name} -> {target}: {'OK' if ok else 'FAILED'} ({len(side['files'])} files)")
    return {"ok": ok, "target": str(target), "files": len(side["files"]), "errors": errors, "archive": str(arch),
            "data_hash": side.get("data_hash")}


def smoke_check(target: str | Path, expected_data_hash: str | None = None) -> dict:
    """load_universe on the restored data/ and open the restored run store."""
    target = Path(target)
    out: dict = {"ok": True, "errors": []}
    try:
        from ..ingestion import load_universe
        u = load_universe(target / "data")
        probs = u.validate()
        out["countries"] = len(u.names); out["positions"] = len(u.portfolio)
        if probs:
            out["errors"].append(f"universe validation: {probs}")
    except Exception as e:
        out["errors"].append(f"load_universe failed: {type(e).__name__}: {e}")
    store_dir = target / "outputs" / "store"
    if (store_dir / "econquest.sqlite").exists():
        try:
            from ..persistence import Store
            s = Store(store_dir)
            runs = s.runs(limit=1)
            out["runs_in_store"] = len(s.runs(limit=100000))
            if runs:
                out["latest_run"] = runs[0]["run_id"]
                s.load(runs[0]["run_id"])
        except Exception as e:
            out["errors"].append(f"store failed: {type(e).__name__}: {e}")
    else:
        out["runs_in_store"] = 0; out["note"] = "no run store in the backup"
    if expected_data_hash:
        try:
            from ..versioning import data_hash
            out["data_hash"] = data_hash(target / "data")
            if out["data_hash"] != expected_data_hash:
                out["errors"].append(f"data_hash {out['data_hash']} differs from the backup's {expected_data_hash}")
        except Exception as e:
            out["errors"].append(f"data_hash failed: {e}")
    out["ok"] = not out["errors"]
    return out


def restore_drill(home: str | Path, backup: str | Path | None = None, dest: str | Path | None = None, keep: bool = False,
                  target_hours: float = DRILL_TARGET_HOURS, now: dt.datetime | None = None, log=print) -> dict:
    """Restore the latest (or given) backup into a temp folder, verify every hash, smoke check, time it, and write
    outputs/logs/restore-drill-<ts>.json and outputs/restore_drill.json."""
    home = Path(home).expanduser()
    now = now or dt.datetime.now(dt.timezone.utc)
    if backup is None:
        found = list_backups(dest)
        if not found:
            raise BackupError(f"no backup found under {Path(dest).expanduser() if dest else default_dest()}")
        backup = found[-1]
    t0 = time.monotonic()
    td = Path(tempfile.mkdtemp(prefix="econquest-drill-"))
    try:
        r = restore(backup, td / "restore", log=log)
        t_restore = time.monotonic() - t0
        smoke = smoke_check(td / "restore", r.get("data_hash")) if r["ok"] else {"ok": False, "errors": ["skipped: restore failed"]}
        secs = time.monotonic() - t0
    finally:
        if not keep:
            _rmtree(td)                                 # the restored vintage tree is read-only
    rep = {"drill_at": now.isoformat(timespec="seconds"), "backup": r["archive"], "files": r["files"],
           "restore_ok": r["ok"], "restore_errors": r["errors"][:50], "smoke": smoke, "restore_seconds": round(t_restore, 2),
           "duration_seconds": round(secs, 2), "target_hours": target_hours, "within_target": secs < target_hours * 3600,
           "kept_at": str(td / "restore") if keep else None}
    rep["ok"] = bool(r["ok"] and smoke["ok"] and rep["within_target"])
    logs = home / "outputs" / "logs"; logs.mkdir(parents=True, exist_ok=True)
    p = logs / f"restore-drill-{now.strftime('%Y%m%dT%H%M%SZ')}.json"
    p.write_text(json.dumps(rep, indent=1, default=str))
    (home / "outputs" / "restore_drill.json").write_text(json.dumps(rep, indent=1, default=str))
    rep["report"] = str(p)
    log(f"[drill] {'PASS' if rep['ok'] else 'FAIL'}: {r['files']} files restored and verified in {secs:.1f}s "
        f"(target < {target_hours:g} h); smoke {'ok' if smoke['ok'] else smoke['errors']}; report {p}")
    return rep


def add_backup_arguments(ap: argparse.ArgumentParser) -> None:
    ap.add_argument("--dest", help="backup folder (default $ECONQUEST_BACKUP_DEST, else ~/econquest-backups/nightly)")
    ap.add_argument("--verify", action="store_true", help="verify the new backup after writing it (exit 1 if it fails)")
    ap.add_argument("--verify-only", metavar="BACKUP", help="verify an existing backup (archive, manifest or day folder) and exit")
    ap.add_argument("--no-prune", action="store_true", help="do not apply retention (14 daily + 8 weekly)")
    ap.add_argument("--list", action="store_true", help="list backups and exit")


def add_drill_arguments(ap: argparse.ArgumentParser) -> None:
    ap.add_argument("--dest", help="backup folder to take the latest backup from")
    ap.add_argument("--backup", help="a specific backup (archive, manifest or day folder)")
    ap.add_argument("--keep", action="store_true", help="keep the restored copy (path printed) instead of deleting it")


def backup_from_args(args, home) -> int:
    if args.list:
        for a in list_backups(args.dest):
            print(f"{a}  {a.stat().st_size / 1e6:.1f} MB")
        return 0
    if args.verify_only:
        return 0 if verify(args.verify_only)["ok"] else 1
    r = create_backup(home, args.dest, prune=not args.no_prune, verify_after=args.verify)
    return 1 if args.verify and not r["verify"]["ok"] else 0


def drill_from_args(args, home) -> int:
    return 0 if restore_drill(home, backup=args.backup, dest=args.dest, keep=args.keep)["ok"] else 1


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    drill = bool(argv) and argv[0] == "drill"
    ap = argparse.ArgumentParser(prog="python -m econquest.ops.backup" + (" drill" if drill else ""),
                                 description="restore drill" if drill else "nightly backup of data/ and outputs/store")
    ap.add_argument("--home", default=os.environ.get("ECONQUEST_HOME", str(Path.home() / "econquest")))
    (add_drill_arguments if drill else add_backup_arguments)(ap)
    args = ap.parse_args(argv[1:] if drill else argv)
    try:
        return (drill_from_args if drill else backup_from_args)(args, Path(args.home))
    except BackupError as e:
        print(f"[backup] error: {e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
