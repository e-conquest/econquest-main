"""Wrapper every scheduled job runs through (EQ-C-0021).

    python -m econquest.ops.jobs --home ~/econquest --job record --step '["/path/econquest","record"]' [--step ...]

Runs the steps in order in <home> (stops at the first non-zero exit) and records the job in outputs/logs/jobs/:

    <job>.last.json   the latest run: status (running / ok / failed / skipped), started_at, ended_at, exit_code, steps
    history.jsonl     one line per start and one per end, for every job

The health check reads <job>.last.json to flag a failed or hung job. A second start while the first still runs
(lock file with a live pid) is recorded as skipped with exit code 75 and does not run the steps.

Alert settings (ECONQUEST_ALERT_WEBHOOK, ECONQUEST_SMTP_*) are not in the plists. When <home>/.ops.env exists and is
readable by its owner only (chmod 600), its KEY=VALUE lines are added to the environment of the steps.
"""
from __future__ import annotations
import argparse
import datetime as dt
import json
import os
import signal
import stat
import subprocess
import sys
import time
from pathlib import Path

EXIT_OVERLAP = 75


def jobs_dir(home: str | Path) -> Path:
    return Path(home) / "outputs" / "logs" / "jobs"


def _now() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def _iso(t: dt.datetime) -> str:
    return t.astimezone(dt.timezone.utc).isoformat(timespec="seconds")


def load_env_file(path: Path, log=print) -> dict:
    """KEY=VALUE lines (no shell expansion). Refused when group or others can read the file."""
    if not path.exists():
        return {}
    if path.stat().st_mode & (stat.S_IRWXG | stat.S_IRWXO):
        log(f"[job] {path} ignored: readable by group/others; run chmod 600 {path}")
        return {}
    env = {}
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k = k.strip().removeprefix("export ").strip()
        env[k] = v.strip().strip('"').strip("'")
    return env


def _pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def _write_last(d: Path, job: str, rec: dict) -> None:
    tmp = d / f".{job}.last.json.tmp"
    tmp.write_text(json.dumps(rec, indent=1)); tmp.replace(d / f"{job}.last.json")


def _history(d: Path, rec: dict) -> None:
    with open(d / "history.jsonl", "a") as f:
        f.write(json.dumps(rec) + "\n")


def run_job(job: str, steps: list[list[str]], home: str | Path, runner=subprocess.run, clock=_now, env: dict | None = None,
            log=print) -> int:
    """Run `steps` for `job`, recording start, end and exit code. Returns the job's exit code."""
    home = Path(home)
    d = jobs_dir(home); d.mkdir(parents=True, exist_ok=True)
    lock = d / f"{job}.lock"
    if lock.exists():
        try:
            pid = int(lock.read_text().strip() or 0)
        except ValueError:
            pid = 0
        if pid and pid != os.getpid() and _pid_alive(pid):
            t = clock()
            rec = {"job": job, "status": "skipped", "reason": f"previous run (pid {pid}) still running", "started_at": _iso(t),
                   "ended_at": _iso(t), "exit_code": EXIT_OVERLAP, "pid": os.getpid()}
            _history(d, {"event": "skipped", **rec}); log(f"[job] {job} skipped: pid {pid} still running")
            return EXIT_OVERLAP                       # last.json keeps the running job's record
    lock.write_text(str(os.getpid()))
    run_env = dict(os.environ if env is None else env)
    run_env.setdefault("ECONQUEST_HOME", str(home))
    run_env.update(load_env_file(home / ".ops.env", log))
    start = clock()
    rec = {"job": job, "status": "running", "started_at": _iso(start), "ended_at": None, "exit_code": None, "pid": os.getpid(),
           "host": os.uname().nodename if hasattr(os, "uname") else None, "steps": []}
    _write_last(d, job, rec); _history(d, {"event": "start", "job": job, "at": rec["started_at"], "pid": rec["pid"]})
    log(f"[job] {job} started {rec['started_at']} ({len(steps)} steps)")
    code = 0
    try:
        for argv in steps:
            t0 = time.monotonic()
            try:
                rc = runner(argv, cwd=str(home), env=run_env).returncode
            except (OSError, subprocess.SubprocessError) as e:
                log(f"[job] {job}: could not start {argv[0]}: {e}"); rc = 127
            rec["steps"].append({"argv0": Path(argv[0]).name, "args": argv[1:3] if argv[0].endswith("bash") else argv[1:],
                                 "exit_code": rc, "seconds": round(time.monotonic() - t0, 1)})
            if rc != 0:
                code = rc
                break
    except BaseException as e:                          # KeyboardInterrupt / SIGTERM from launchd
        code = 130 if isinstance(e, KeyboardInterrupt) else (e.code if isinstance(e, SystemExit) and isinstance(e.code, int) else 1)
        raise
    finally:
        end = clock()
        rec.update({"status": "ok" if code == 0 else "failed", "ended_at": _iso(end), "exit_code": code,
                    "seconds": round((end - start).total_seconds(), 1)})
        _write_last(d, job, rec)
        _history(d, {"event": "end", "job": job, "at": rec["ended_at"], "exit_code": code, "status": rec["status"]})
        try:
            lock.unlink()
        except FileNotFoundError:
            pass
        log(f"[job] {job} {rec['status']} exit {code} at {rec['ended_at']}")
    return code


def last_runs(home: str | Path) -> dict[str, dict]:
    d = jobs_dir(home)
    out = {}
    for f in sorted(d.glob("*.last.json")) if d.exists() else []:
        try:
            out[f.name[:-len(".last.json")]] = json.loads(f.read_text())
        except (OSError, json.JSONDecodeError):
            continue
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ops.jobs", description="run a scheduled econquest job and record its exit code")
    ap.add_argument("--home", default=os.environ.get("ECONQUEST_HOME", str(Path.home() / "econquest")))
    ap.add_argument("--job", required=True)
    ap.add_argument("--step", action="append", required=True, help="one step as a JSON argv list (repeatable, run in order)")
    args = ap.parse_args(argv)
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(143))     # launchd stops jobs with SIGTERM: still record the end
    steps = [json.loads(s) for s in args.step]
    if not all(isinstance(s, list) and s and all(isinstance(a, str) for a in s) for s in steps):
        ap.error("each --step must be a non-empty JSON list of strings")
    return run_job(args.job, steps, args.home)


if __name__ == "__main__":
    sys.exit(main())
