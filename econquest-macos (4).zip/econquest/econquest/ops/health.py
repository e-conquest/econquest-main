"""Health check (EQ-C-0021), run every 15 minutes by launchd: writes outputs/health.json and sends new alerts through
validation.alerts.deliver_alerts (webhook / email when configured).

Checks
  missed_run   For each scheduled job, the latest slot whose deadline has passed: slot time (in the schedule's tz,
               default America/New_York) + the job's max_minutes = deadline; flagged once deadline + grace (15 min)
               has passed without evidence. Weekday jobs count business days only: Monday to Friday, minus the
               optional `holidays` list (no exchange holiday calendar is built in). Evidence:
                 record   a row in data/forecast_record.csv recorded at or after the slot (recorded_at, "backfill" rows
                          too) - the run is archived in the forecast record
                 morning  a run in outputs/store (label base) created at or after the slot - archived in the run store
                 others   outputs/logs/jobs/<job>.last.json ended ok at or after the slot
               Slots before the schedule was installed (outputs/logs/schedule.json installed_at) are not checked, and
               with no schedule.json this check reports "not installed" and raises nothing.
  stale_feed   The newest live pull (data/live/feeds.json "retrieved", or the newest data/live/vintages/<date...>
               folder) is older than stale_feed_days (default 7); a feed whose status is not "ok"; no pull at all.
  job_failed   <job>.last.json has a non-zero exit code; job_hung: status running for more than 2 x max_minutes.
  approvals_log  data/approvals/log.jsonl is missing or has no rows (EQ-C-0050, SEC-C-005 R1). Unconditional on
               purpose: the release ships a non-empty log (the baselines), so a missing or empty one means data/approvals/
               was deleted or never installed, and every governed file (assumptions, limits, compliance) then reads as
               never governed. Comparing assumptions.json with a "shipped default" would need a reference copy that the
               same deletion can remove, and it misses the compliance.json case R1 is about.

Alerts use the validation.alerts dict shape (severity, kind, scope, country, message, value, threshold). An alert is
delivered once: health.json keeps the keys already sent, and a key that clears and comes back is sent again.
"""
from __future__ import annotations
import argparse
import datetime as dt
import json
import os
import sys
from pathlib import Path

import pandas as pd

from . import schedule as _schedule
from .jobs import last_runs

SEV = {"record": "critical", "morning": "critical"}


def _alert(severity, kind, scope, message, value=None, threshold=None, key=None) -> dict:
    return {"severity": severity, "kind": kind, "scope": scope, "country": None, "message": message, "value": value,
            "threshold": threshold, "key": key or f"{kind}:{scope}"}


def _parse(ts) -> dt.datetime | None:
    if ts is None or (isinstance(ts, float) and ts != ts):
        return None
    s = str(ts).strip().removeprefix("backfill").strip()
    try:
        t = dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
    except ValueError:
        return None
    return t if t.tzinfo else t.replace(tzinfo=dt.timezone.utc)


def _zone(tz: str):
    from zoneinfo import ZoneInfo
    return ZoneInfo(tz)


def is_run_day(d: dt.date, weekdays: list[int], holidays: set[dt.date]) -> bool:
    """launchd weekday numbers (0/7 Sunday ... 6 Saturday). Weekday-only jobs also skip `holidays`."""
    lw = (d.isoweekday() % 7)                                 # Monday 1 ... Saturday 6, Sunday 0
    if lw not in {w % 7 for w in weekdays}:
        return False
    return not (set(weekdays) <= set(range(1, 6)) and d in holidays)


def latest_due_slot(job: dict, now: dt.datetime, tz: str, grace_minutes: int, holidays: set[dt.date], lookback_days: int = 10):
    """(slot, deadline) of the newest slot whose deadline + grace has passed, in UTC; None if none in the lookback."""
    z = _zone(tz)
    local_now = now.astimezone(z)
    for back in range(lookback_days + 1):
        d = local_now.date() - dt.timedelta(days=back)
        if not is_run_day(d, job.get("weekdays", _schedule.ALL_DAYS), holidays):
            continue
        slot = dt.datetime.combine(d, dt.time(int(job["hour"]), int(job["minute"])), tzinfo=z)
        deadline = slot + dt.timedelta(minutes=int(job.get("max_minutes", 30)))
        if deadline + dt.timedelta(minutes=grace_minutes) <= local_now:
            return slot.astimezone(dt.timezone.utc), deadline.astimezone(dt.timezone.utc)
    return None


def _record_times(data_dir: Path) -> list[dt.datetime]:
    p = data_dir / "forecast_record.csv"
    if not p.exists():
        return []
    try:
        df = pd.read_csv(p, usecols=["recorded_at"])
    except (ValueError, pd.errors.EmptyDataError):
        return []
    return [t for t in (_parse(v) for v in df["recorded_at"]) if t]


def _store_times(out_dir: Path, label: str = "base") -> list[dt.datetime]:
    db = out_dir / "store" / "econquest.sqlite"
    if not db.exists():
        return []
    import sqlite3
    with sqlite3.connect(f"file:{db}?mode=ro", uri=True) as c:          # read only: never create or migrate the store
        rows = c.execute("SELECT created_at FROM runs WHERE label=? ORDER BY created_at DESC LIMIT 50", (label,)).fetchall()
    return [t for t in (_parse(r[0]) for r in rows) if t]


def evidence_since(kind: str | None, name: str, slot: dt.datetime, data_dir: Path, out_dir: Path, last: dict,
                   early_minutes: int = 120) -> tuple[bool, str]:
    """Was the job's slot done? Runs started up to early_minutes before the slot count (a manual run just before)."""
    since = slot - dt.timedelta(minutes=early_minutes)
    if kind == "forecast_record":
        ts = [t for t in _record_times(data_dir) if t >= since]
        return bool(ts), (f"forecast record row recorded {max(ts).isoformat(timespec='seconds')}" if ts else "no forecast record row since the slot")
    if kind == "store_run":
        ts = [t for t in _store_times(out_dir) if t >= since]
        return bool(ts), (f"base run archived {max(ts).isoformat(timespec='seconds')}" if ts else "no base run archived in outputs/store since the slot")
    lj = last.get(name) or {}
    end = _parse(lj.get("ended_at"))
    ok = lj.get("status") == "ok" and end is not None and end >= since
    return ok, (f"job ended ok {lj.get('ended_at')}" if ok else f"no successful {name} job since the slot (last: {lj.get('status', 'none')} {lj.get('ended_at') or ''})".strip())


def check_missed(sched: dict | None, now: dt.datetime, data_dir: Path, out_dir: Path, last: dict) -> tuple[list[dict], list[dict]]:
    checks, alerts = [], []
    if not sched or sched.get("status") != "installed":
        return [{"check": "missed_run", "status": "skipped", "detail": "schedule not installed (no outputs/logs/schedule.json)"}], []
    tz = sched.get("tz", _schedule.DEFAULT_TZ); grace = int(sched.get("grace_minutes", 15))
    holidays = {dt.date.fromisoformat(h) for h in sched.get("holidays", [])}
    installed = _parse(sched.get("installed_at"))
    for name, job in sched.get("jobs", {}).items():
        if job.get("interval_minutes") or "hour" not in job:
            continue
        due = latest_due_slot(job, now, tz, grace, holidays)
        if due is None or (installed and due[0] < installed):
            checks.append({"check": "missed_run", "job": name, "status": "ok", "detail": "no slot due since install"})
            continue
        slot, deadline = due
        ok, detail = evidence_since(job.get("evidence"), name, slot, data_dir, out_dir, last)
        lj = last.get(name) or {}
        ended = _parse(lj.get("ended_at"))
        failed = not ok and lj.get("status") == "failed" and ended is not None and ended >= slot - dt.timedelta(minutes=120)
        checks.append({"check": "missed_run", "job": name, "status": "ok" if ok else ("failed" if failed else "missed"),
                       "slot": slot.isoformat(), "deadline": deadline.isoformat(), "detail": detail})
        if not ok and not failed:                         # a run that started and failed is reported once, as job_failed
            local = slot.astimezone(_zone(tz))
            alerts.append(_alert(SEV.get(name, "warning"), "missed_run", name,
                                 f"Scheduled {name} job for {local:%a %Y-%m-%d %H:%M} {tz} has no result by its deadline "
                                 f"{deadline.astimezone(_zone(tz)):%H:%M} + {grace} min: {detail}",
                                 value=detail, threshold=deadline.isoformat(), key=f"missed_run:{name}:{slot.isoformat()}"))
    return checks, alerts


def feed_age(data_dir: Path) -> tuple[dt.date | None, dict]:
    live = data_dir / "live"
    dates, status = [], {}
    f = live / "feeds.json"
    if f.exists():
        try:
            j = json.loads(f.read_text())
            status = j.get("feeds", {}) if isinstance(j, dict) else {}
            if j.get("retrieved"):
                dates.append(dt.date.fromisoformat(str(j["retrieved"])[:10]))
        except (ValueError, json.JSONDecodeError):
            pass
    vd = live / "vintages"
    if vd.exists():
        for p in vd.iterdir():
            try:
                dates.append(dt.date.fromisoformat(p.name[:10]))
            except ValueError:
                continue
    return (max(dates) if dates else None), status


def check_feeds(data_dir: Path, now: dt.datetime, stale_days: int, tz: str) -> tuple[list[dict], list[dict]]:
    newest, status = feed_age(data_dir)
    today = now.astimezone(_zone(tz)).date()
    alerts = []
    if newest is None:
        alerts.append(_alert("warning", "stale_feed", "data", "No live pull recorded (no data/live/feeds.json or vintages)", key="stale_feed:none"))
        checks = [{"check": "stale_feed", "status": "stale", "detail": "no live pull recorded"}]
    else:
        age = (today - newest).days
        stale = age > stale_days
        checks = [{"check": "stale_feed", "status": "stale" if stale else "ok", "newest_pull": newest.isoformat(), "age_days": age,
                   "threshold_days": stale_days}]
        if stale:
            alerts.append(_alert("warning", "stale_feed", "data", f"Live inputs are {age} days old (last pull {newest}; limit {stale_days} days): run econquest fetch",
                                 value=age, threshold=stale_days, key=f"stale_feed:{newest.isoformat()}"))
    for name, st in (status or {}).items():
        if not str(st).lower().startswith("ok"):
            alerts.append(_alert("warning", "feed_failure", "data", f"Feed {name} failed on the last pull: {st}", value=str(st),
                                 key=f"feed_failure:{name}:{newest}"))
            checks.append({"check": "feed_status", "feed": name, "status": "failed", "detail": str(st)})
    return checks, alerts


def check_jobs(last: dict, sched: dict | None, now: dt.datetime) -> tuple[list[dict], list[dict]]:
    checks, alerts = [], []
    jobs_cfg = (sched or {}).get("jobs") or _schedule.DEFAULT_JOBS
    for name, lj in sorted(last.items()):
        status, code = lj.get("status"), lj.get("exit_code")
        if status == "failed" or (status in ("ok", "failed") and code not in (0, None)):
            checks.append({"check": "job", "job": name, "status": "failed", "exit_code": code, "ended_at": lj.get("ended_at")})
            alerts.append(_alert("critical", "job_failed", name, f"Scheduled job {name} failed with exit code {code} at {lj.get('ended_at')} "
                                 f"(log outputs/logs/{name}.err.log)", value=code, key=f"job_failed:{name}:{lj.get('ended_at')}"))
        elif status == "running":
            started = _parse(lj.get("started_at"))
            limit = 2 * int((jobs_cfg.get(name) or {}).get("max_minutes", 60))
            if started and now - started > dt.timedelta(minutes=limit):
                checks.append({"check": "job", "job": name, "status": "hung", "started_at": lj.get("started_at")})
                alerts.append(_alert("warning", "job_hung", name, f"Scheduled job {name} started {lj.get('started_at')} and has not ended "
                                     f"after {limit} min (stopped or still running)", key=f"job_hung:{name}:{lj.get('started_at')}"))
            else:
                checks.append({"check": "job", "job": name, "status": "running", "started_at": lj.get("started_at")})
        else:
            checks.append({"check": "job", "job": name, "status": status or "unknown", "exit_code": code, "ended_at": lj.get("ended_at")})
    return checks, alerts


def check_approvals_log(data_dir: Path) -> tuple[list[dict], list[dict]]:
    """approvals_log check (see the module docstring): warning when data/approvals/log.jsonl is missing or empty."""
    p = data_dir / "approvals" / "log.jsonl"
    try:
        empty = not p.read_text(encoding="utf-8", errors="replace").strip()
        state = "empty" if empty else "ok"
    except FileNotFoundError:
        state = "missing"
    except OSError as e:
        state = f"unreadable ({type(e).__name__})"
    if state == "ok":
        return [{"check": "approvals_log", "status": "ok"}], []
    return [{"check": "approvals_log", "status": state.split()[0], "detail": str(p)}], [
        _alert("warning", "approvals_log", "data",
               f"data/approvals/log.jsonl is {state}: the change-approval record of assumptions.json, limits.json and "
               "compliance.json is gone, so those files read as never governed (restore data/approvals/ from the backup; "
               "econquest change verify)", value=state, key=f"approvals_log:{state.split()[0]}")]


def run_health(data_dir: str | Path, out_dir: str | Path, now: dt.datetime | None = None, deliver: bool = True, env: dict | None = None,
               stale_days: int | None = None, log=print, deliver_fn=None) -> dict:
    """Run every check, write outputs/health.json, deliver alerts not sent before. Returns the health dict."""
    data_dir, out_dir = Path(data_dir), Path(out_dir)
    now = now or dt.datetime.now(dt.timezone.utc)
    home = out_dir.parent
    sp = out_dir / "logs" / "schedule.json"
    sched = json.loads(sp.read_text()) if sp.exists() else None
    cfg = _schedule.load_config(home)
    tz = (sched or {}).get("tz") or cfg.get("tz", _schedule.DEFAULT_TZ)
    stale = int(stale_days if stale_days is not None else (sched or {}).get("stale_feed_days", cfg.get("stale_feed_days", 7)))
    last = last_runs(home)
    checks, alerts = [], []
    for c, a in (check_missed(sched, now, data_dir, out_dir, last), check_feeds(data_dir, now, stale, tz), check_jobs(last, sched, now),
                 check_approvals_log(data_dir)):
        checks += c; alerts += a
    hp = out_dir / "health.json"
    prev = {}
    if hp.exists():
        try:
            prev = json.loads(hp.read_text()).get("alerted", {})
        except (OSError, json.JSONDecodeError):
            prev = {}
    new = [a for a in alerts if a["key"] not in prev]
    alerted = {a["key"]: prev.get(a["key"], now.isoformat(timespec="seconds")) for a in alerts}
    worst = min((["critical", "warning", "info"].index(a["severity"]) for a in alerts), default=None)
    delivery = None
    if new and deliver:
        if deliver_fn is None:
            from ..validation.alerts import deliver_alerts as deliver_fn
        # out_dir=None: do not overwrite the run's outputs/alerts.json; health.json holds these alerts
        delivery = deliver_fn([{k: v for k, v in a.items() if k != "key"} for a in new], {}, env, out_dir=None, run_id="health", log=log)
        if any(str((delivery or {}).get(k, "")).startswith("error") for k in ("webhook", "email")):
            alerted = {k: v for k, v in alerted.items() if k in prev}      # failed delivery: send these again next check
        try:                                                # EQ-C-0045: delivery latency (econquest distribute status)
            from .distribute import log_alert_delivery
            log_alert_delivery(out_dir, new, delivery, now=now)
        except Exception as e:                              # noqa: BLE001 - never fail the health check on the log
            log(f"[health] delivery log not written: {type(e).__name__}")
    result = {"generated_at": now.isoformat(timespec="seconds"), "status": "ok" if worst is None else ["critical", "warning", "info"][worst],
              "tz": tz, "schedule": (sched or {}).get("status", "not installed"), "checks": checks, "alerts": alerts,
              "new_alerts": len(new), "delivery": delivery, "alerted": alerted}
    out_dir.mkdir(parents=True, exist_ok=True)
    tmp = out_dir / ".health.json.tmp"; tmp.write_text(json.dumps(result, indent=1, default=str)); tmp.replace(hp)
    log(f"[health] {result['status']}: {len(alerts)} alerts ({len(new)} new) -> {hp}")
    for a in alerts:
        log(f"  [{a['severity'].upper():8s}] {a['kind']:12s} {a['message']}")
    return result


def add_arguments(ap: argparse.ArgumentParser) -> None:
    ap.add_argument("--no-deliver", action="store_true", help="write health.json only; no webhook or email")
    ap.add_argument("--stale-days", type=int, help="live inputs older than this are stale (default 7, or ops.json stale_feed_days)")
    ap.add_argument("--strict", action="store_true", help="exit 1 when any critical alert is open")


def run_from_args(args, data_dir, out_dir) -> int:
    r = run_health(data_dir, out_dir, deliver=not args.no_deliver, stale_days=args.stale_days)
    return 1 if args.strict and r["status"] == "critical" else 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ops.health", description="econquest scheduled-job and feed health check")
    ap.add_argument("--home", default=os.environ.get("ECONQUEST_HOME", str(Path.home() / "econquest")))
    add_arguments(ap)
    args = ap.parse_args(argv)
    home = Path(args.home)
    return run_from_args(args, home / "data", home / "outputs")


if __name__ == "__main__":
    sys.exit(main())
