"""Change approvals for data/assumptions.json, data/limits.json and data/compliance.json (EQ-C-0023, roadmap 4.4,
model-risk-policy s.4-5; compliance.json since EQ-C-0040, SEC-C-004 R1).

A change goes propose -> approve (or reject) -> apply. Nothing but `apply` writes the governed files, and it writes
exactly the bytes that were proposed and approved, only while the file still has the sha256 the proposal was based on.

Records under `<data_dir>/approvals/`:
- `proposals/<id>.json`: one file per proposal, written once (id, file, base_sha256, new_sha256, diff, author, reason,
  tier, created_utc and the full new text). Its sha256 is logged, so editing it afterwards is detected.
- `log.jsonl`: every event (propose, approve, reject, apply, baseline) as one JSON row in a hash chain: `seq` counts
  from 1, `prev_hash` is the previous row's `row_hash` (64 zeros for the first) and
  `row_hash = sha256(prev_hash + canonical row)`, the canonical row being the row without `row_hash` as JSON with
  sorted keys and no spaces. `verify_chain` detects any edited, deleted, inserted or reordered row.
- `head.json`: seq and row_hash of the last row, rewritten on every append, so truncating the tail is detected too.
  The chain proves internal consistency only: someone who rewrites the log, the head and the proposals together can
  forge it; copy `head.json` into the release note to anchor it outside the folder.

Four-eyes uses Team A's rules (`econquest.ingestion.ledger.check_approval`, `person_key`: NFKC, zero-width and other
Unicode format characters removed, whitespace stripped, casefolded). Single-operator mode (Sam, 2026-10-23) needs
`self_approved=True` and an exception id `EXC-nnn` from docs/governance/issues-log.md; it is stored as approver =
author, self_approved "yes" and the EXC id, for every tier.

Tiers (policy s.2 and s.4): any limits.json change is "limit" (approver signs; the owner cannot raise a limit on
himself); compliance.json (who may sign off research products) is Tier 2, owner + approver; assumptions.json keys map to Tier 1 or 2 by section (unknown sections are Tier 1); `monte_carlo.paths` and
`monte_carlo.seed` alone are "run" settings. A proposal takes the highest tier among its changed keys; an explicit
tier may raise it but not lower it. `layer1.mode` also needs the validator (restriction 6.1), shown as
"independent review pending".

`detect_unapproved` compares each governed file's current sha256 with the last one this tool applied (or
baselined) and reports drift, i.e. a hand edit outside the tool (also `fit-hazard --apply`, which writes
assumptions.json directly). Text fields are neutralised against spreadsheet formula injection
(`common_format.escape_formula`) before they are stored and hashed.
"""
from __future__ import annotations

import contextlib
import copy
import datetime as dt
import hashlib
import json
import os
import re
import secrets
import tempfile
from pathlib import Path

from ..common_format import escape_formula
from ..ingestion.ledger import check_approval, clean_person, person_key

try:                                    # POSIX only; elsewhere events are unlocked
    import fcntl
except ImportError:                     # pragma: no cover
    fcntl = None

FILES = ("assumptions.json", "limits.json", "compliance.json")
OPTIONAL_FILES = frozenset({"compliance.json"})          # absent and never applied = built-in default, not "missing"
TIERS = ("limit", "1", "2", "3", "run")                 # most to least demanding
_RANK = {"limit": 4, "1": 3, "2": 2, "3": 1, "run": 0}
TIER2_SECTIONS = frozenset({"regime", "regime_rules", "transition_matrix", "stress_path", "gpr", "signals", "garch",
                            "cds", "alerts"})
TIER1_SECTIONS = frozenset({"scorecard", "probability", "ratings_pd", "floors", "market", "monte_carlo", "layer1",
                            "layer1_paper_coefficients", "layer1_fitted", "layer4", "liquidity", "perils",
                            "sector_multipliers", "location_multipliers", "boom_trigger", "prediction_markets"})
RUN_SETTINGS = frozenset({"/monte_carlo/paths", "/monte_carlo/seed"})
VALIDATOR_KEYS = frozenset({"/layer1/mode"})
EVENTS = ("propose", "approve", "reject", "apply", "baseline")
LOG_FIELDS = ["seq", "ts_utc", "event", "id", "file", "tier", "actor", "approver", "self_approved", "exc_id",
              "base_sha256", "new_sha256", "file_sha256", "proposal_sha256", "note", "prev_hash", "row_hash"]
_TEXT_FIELDS = ("actor", "approver", "exc_id", "note")
GENESIS = "0" * 64
EXC_RE = re.compile(r"EXC-\d{3,}")
ID_RE = re.compile(r"CHG-\d{8}T\d{6}Z-[0-9a-f]{6}")


class ApprovalError(ValueError):
    """A refused propose/approve/reject/apply/baseline."""


# ---------------------------------------------------------------- paths, hashing, io

def approvals_dir(data_dir) -> Path:
    return Path(data_dir) / "approvals"


def log_path(data_dir) -> Path:
    return approvals_dir(data_dir) / "log.jsonl"


def head_path(data_dir) -> Path:
    return approvals_dir(data_dir) / "head.json"


def proposal_path(data_dir, change_id: str) -> Path:
    return approvals_dir(data_dir) / "proposals" / f"{_check_id(change_id)}.json"


def _check_id(change_id) -> str:
    s = str(change_id or "").strip()
    if not ID_RE.fullmatch(s):
        raise ApprovalError(f"not a change id: {change_id!r} (expected CHG-YYYYMMDDTHHMMSSZ-xxxxxx)")
    return s


def _file_name(file) -> str:
    name = Path(str(file)).name
    if name not in FILES:
        raise ApprovalError(f"only {', '.join(FILES)} are governed by change approvals, got {file!r}")
    return name


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def file_sha256(path) -> str | None:
    p = Path(path)
    return sha256_bytes(p.read_bytes()) if p.exists() else None


def _ts(now: dt.datetime | None) -> str:
    now = now or dt.datetime.now(dt.timezone.utc)
    now = now.replace(tzinfo=dt.timezone.utc) if now.tzinfo is None else now.astimezone(dt.timezone.utc)
    return now.strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def serialise(doc) -> str:
    """The text apply writes: 2-space indent, UTF-8, trailing newline; NaN/inf refused (not valid JSON)."""
    try:
        return json.dumps(doc, indent=2, ensure_ascii=False, allow_nan=False) + "\n"
    except (TypeError, ValueError) as e:
        raise ApprovalError(f"result is not valid JSON: {e}") from None


def _atomic_write(path: Path, data: bytes, exclusive: bool = False) -> None:
    """Write via a temp file in the same folder and os.replace (keeps the old file's mode; no hard links, which some
    network mounts lack). exclusive: refuse if the target exists."""
    path.parent.mkdir(parents=True, exist_ok=True)
    if exclusive and path.exists():
        raise ApprovalError(f"{path.name} already exists")
    mode = path.stat().st_mode & 0o777 if path.exists() else 0o644
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.chmod(tmp, mode)
        if exclusive and path.exists():  # callers hold _locked, so this re-check closes the window
            raise ApprovalError(f"{path.name} already exists")
        os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


@contextlib.contextmanager
def _locked(data_dir):
    """Exclusive lock over the approvals folder for one read-check-append (POSIX flock)."""
    d = approvals_dir(data_dir); d.mkdir(parents=True, exist_ok=True)
    with open(d / ".lock", "a") as f:
        if fcntl is not None:
            fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            if fcntl is not None:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)


# ---------------------------------------------------------------- hash-chained log

def canonical(row: dict) -> str:
    return json.dumps({k: v for k, v in row.items() if k != "row_hash"}, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False)


def row_hash(prev_hash: str, row: dict) -> str:
    return sha256_bytes((prev_hash + canonical(row)).encode("utf-8"))


def read_log(data_dir) -> list[dict]:
    """Every log row in file order (unparseable lines raise ApprovalError; use verify_chain to diagnose)."""
    p = log_path(data_dir)
    if not p.exists():
        return []
    rows = []
    for i, line in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            raise ApprovalError(f"log.jsonl line {i} is not JSON") from None
    return rows


def _append_event(data_dir, event: str, now=None, **fields) -> dict:
    """Append one event (caller holds _locked). Text fields are formula-neutralised before hashing."""
    rows = read_log(data_dir)
    prev = rows[-1]["row_hash"] if rows else GENESIS
    row = {c: "" for c in LOG_FIELDS}
    row.update({k: ("" if v is None else v) for k, v in fields.items() if k in LOG_FIELDS})
    for c in _TEXT_FIELDS:
        row[c] = escape_formula(str(row[c]))
    row.update(seq=len(rows) + 1, ts_utc=_ts(now), event=event, prev_hash=prev)
    row["row_hash"] = row_hash(prev, row)
    p = log_path(data_dir); p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n"); f.flush(); os.fsync(f.fileno())
    _atomic_write(head_path(data_dir), (json.dumps({"seq": row["seq"], "row_hash": row["row_hash"]}) + "\n").encode())
    return row


def verify_chain(data_dir) -> dict:
    """Check the log: every row parses, seq runs 1..n, each prev_hash is the previous row_hash, each row_hash
    recomputes, head.json names the last row, and every proposal file still has the sha256 its propose event logged.
    Returns {"ok", "rows", "head", "errors": [...]}."""
    errors, rows = [], []
    p = log_path(data_dir)
    lines = p.read_text(encoding="utf-8").splitlines() if p.exists() else []
    prev = GENESIS
    for i, line in enumerate(lines, 1):
        if not line.strip():
            errors.append(f"line {i}: blank line"); continue
        try:
            r = json.loads(line)
        except json.JSONDecodeError:
            errors.append(f"line {i}: not JSON"); prev = None; continue
        if r.get("seq") != len(rows) + 1:
            errors.append(f"line {i}: seq {r.get('seq')} where {len(rows) + 1} expected (row deleted, inserted or moved)")
        if prev is not None and r.get("prev_hash") != prev:
            errors.append(f"line {i}: prev_hash does not match the previous row (row deleted, inserted or moved)")
        if r.get("row_hash") != row_hash(str(r.get("prev_hash", "")), r):
            errors.append(f"line {i}: row_hash does not recompute (row edited)")
        prev = r.get("row_hash")
        rows.append(r)
    head = None
    hp = head_path(data_dir)
    if hp.exists():
        try:
            head = json.loads(hp.read_text())
        except json.JSONDecodeError:
            errors.append("head.json is not JSON")
    if rows and head is None and not hp.exists():
        errors.append("head.json missing")
    if isinstance(head, dict):
        last = rows[-1] if rows else {"seq": 0, "row_hash": GENESIS}
        if head.get("seq") != last.get("seq") or head.get("row_hash") != last.get("row_hash"):
            errors.append(f"head.json names seq {head.get('seq')} but the log ends at seq {last.get('seq')} "
                          "(rows removed from or added to the end)")
    for r in rows:
        if r.get("event") == "propose" and ID_RE.fullmatch(str(r.get("id", ""))):
            pp = proposal_path(data_dir, r["id"])
            if file_sha256(pp) != r.get("proposal_sha256"):
                errors.append(f"proposal {r['id']}: file {'missing' if not pp.exists() else 'changed'} since it was logged")
    return {"ok": not errors, "rows": len(rows), "head": head, "errors": errors}


def _require_chain(data_dir) -> list[dict]:
    v = verify_chain(data_dir)
    if not v["ok"]:
        raise ApprovalError("approvals log failed verification, refusing: " + "; ".join(v["errors"][:5]))
    return read_log(data_dir)


# ---------------------------------------------------------------- JSON pointer patching and diff

def _pointer(path: str) -> list[str]:
    if not isinstance(path, str) or not path.startswith("/"):
        raise ApprovalError(f"key path must be a JSON pointer starting with '/', got {path!r}")
    return [s.replace("~1", "/").replace("~0", "~") for s in path[1:].split("/")]


def _escape_seg(s) -> str:
    return str(s).replace("~", "~0").replace("/", "~1")


def _kind(v) -> str:
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "bool"
    if isinstance(v, (int, float)):
        return "number"
    return {str: "string", dict: "object", list: "array"}.get(type(v), type(v).__name__)


def apply_patch(doc, patch: dict, allow_new_keys: bool = False):
    """Copy of doc with each {json_pointer: new_value} set. Every parent must exist; the last segment must exist
    unless allow_new_keys (an array index '-' appends)."""
    if not isinstance(patch, dict) or not patch:
        raise ApprovalError("patch must be a non-empty {json_pointer: new value} mapping")
    out = copy.deepcopy(doc)
    for path, value in patch.items():
        segs = _pointer(path)
        if segs == [""]:
            raise ApprovalError("the empty pointer would replace the whole file; pass replace=True instead")
        node = out
        for depth, seg in enumerate(segs):
            last = depth == len(segs) - 1
            where = "/" + "/".join(_escape_seg(s) for s in segs[:depth + 1])
            if isinstance(node, dict):
                if seg not in node and not (last and allow_new_keys):
                    raise ApprovalError(f"{where}: key does not exist" + (" (pass allow_new_keys to add it)" if last else ""))
                if last:
                    node[seg] = copy.deepcopy(value)
                else:
                    node = node[seg]
            elif isinstance(node, list):
                if seg == "-" and last and allow_new_keys:
                    node.append(copy.deepcopy(value)); continue
                if not (seg.isascii() and seg.isdigit()) or int(seg) >= len(node):   # "²", "١" are isdigit()
                    raise ApprovalError(f"{where}: no such array index")
                if last:
                    node[int(seg)] = copy.deepcopy(value)
                else:
                    node = node[int(seg)]
            else:
                raise ApprovalError(f"{where}: parent is a {_kind(node)}, not an object or array")
    return out


def diff_docs(old, new, path: str = "") -> list[dict]:
    """Leaf-level changes [{path, op (change|add|remove), old, new}]; arrays of different length are one change."""
    if isinstance(old, dict) and isinstance(new, dict):
        out = []
        for k in old:
            p = f"{path}/{_escape_seg(k)}"
            out += diff_docs(old[k], new[k], p) if k in new else [{"path": p, "op": "remove", "old": old[k], "new": None}]
        out += [{"path": f"{path}/{_escape_seg(k)}", "op": "add", "old": None, "new": new[k]} for k in new if k not in old]
        return out
    if isinstance(old, list) and isinstance(new, list) and len(old) == len(new):
        return [c for i, (a, b) in enumerate(zip(old, new)) for c in diff_docs(a, b, f"{path}/{i}")]
    if _kind(old) == _kind(new) and old == new:
        return []
    return [{"path": path or "/", "op": "change", "old": old, "new": new}]


def infer_tier(file: str, diff: list[dict]) -> tuple[str, bool]:
    """(tier, needs_validator) for a diff of `file` (model-risk-policy s.2 and s.4)."""
    if _file_name(file) == "limits.json":
        return "limit", False
    if _file_name(file) == "compliance.json":             # a control, not a model parameter: owner + approver
        return "2", False
    best, validator = "run", False
    for c in diff:
        p = c["path"]
        top = _pointer(p)[0] if p != "/" else ""
        if p in RUN_SETTINGS:
            t = "run"
        elif top in TIER2_SECTIONS:
            t = "2"
        else:                                     # TIER1_SECTIONS and anything unknown
            t = "1"
        validator = validator or p in VALIDATOR_KEYS or p == "/layer1"
        best = t if _RANK[t] > _RANK[best] else best
    return best, validator


# ---------------------------------------------------------------- state

def _events_by_id(rows) -> dict[str, list[dict]]:
    out: dict[str, list[dict]] = {}
    for r in rows:
        if r.get("id"):
            out.setdefault(r["id"], []).append(r)
    return out


def _status(events: list[dict]) -> str:
    st = "unknown"
    for e in events:
        st = {"propose": "proposed", "approve": "approved", "reject": "rejected", "apply": "applied"}.get(e["event"], st)
    return st


def load_proposal(data_dir, change_id: str) -> dict:
    p = proposal_path(data_dir, change_id)
    if not p.exists():
        raise ApprovalError(f"no proposal {change_id}")
    return json.loads(p.read_text(encoding="utf-8"))


# ---------------------------------------------------------------- public API

def propose(data_dir, file, patch, author, reason, tier=None, replace: bool = False, allow_new_keys: bool = False,
            allow_type_change: bool = False, now: dt.datetime | None = None) -> dict:
    """Record a proposed change to data/<file> and return the proposal. `patch` is {json_pointer: new value}
    (e.g. {"/layer4/lgd_sd": 0.12}) or, with replace=True, the whole new document. Keys must exist (adding them, or
    removing them in a replacement, needs allow_new_keys); a value may not change JSON type without
    allow_type_change; the result must be valid JSON (no NaN/inf). The tier is inferred; an explicit `tier` may raise
    it, not lower it. The governed file is not touched."""
    name = _file_name(file)
    author, reason = clean_person(author), str(reason or "").strip()
    if not person_key(author):
        raise ApprovalError("author is required")
    if not reason:
        raise ApprovalError("reason is required")
    target = Path(data_dir) / name
    if not target.exists():
        raise ApprovalError(f"{target} does not exist")
    base_bytes = target.read_bytes()
    try:
        old = json.loads(base_bytes.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise ApprovalError(f"{name} is not valid JSON now ({e}); repair it before proposing") from None
    if replace:
        if isinstance(patch, (str, bytes)):
            try:
                patch = json.loads(patch)
            except json.JSONDecodeError as e:
                raise ApprovalError(f"replacement is not valid JSON: {e}") from None
        new = copy.deepcopy(patch)
    else:
        new = apply_patch(old, patch, allow_new_keys=allow_new_keys)
    new_text = serialise(new)
    new = json.loads(new_text)                    # exactly what will be written
    diff = diff_docs(old, new)
    if not diff:
        raise ApprovalError("the change leaves the file's content unchanged")
    if not isinstance(new, dict) or not isinstance(old, dict):
        raise ApprovalError("the file must stay a JSON object")
    if name == "compliance.json":                       # refuse a config that sign-off would then reject
        from ..presentation.compliance import ComplianceError, validate_config
        try:
            validate_config(new, name)
        except ComplianceError as e:
            raise ApprovalError(str(e)) from None
    structural = [c["path"] for c in diff if c["op"] in ("add", "remove")]
    if structural and not allow_new_keys:
        raise ApprovalError(f"adds or removes keys {structural[:5]}; pass allow_new_keys to allow that")
    retyped = [c["path"] for c in diff if c["op"] == "change" and _kind(c["old"]) != _kind(c["new"])]
    if retyped and not allow_type_change:
        raise ApprovalError(f"changes the JSON type of {retyped[:5]}; pass allow_type_change to allow that")
    inferred, needs_validator = infer_tier(name, diff)
    if tier is None or str(tier).strip() == "":
        tier = inferred
    else:
        tier = str(tier).strip().lower().removeprefix("tier").strip()
        if tier not in TIERS:
            raise ApprovalError(f"tier must be one of {TIERS}, got {tier!r}")
        if _RANK[tier] < _RANK[inferred]:
            raise ApprovalError(f"tier {tier} is below the inferred tier {inferred} for these keys; a tier can only be raised")
    with _locked(data_dir):
        _require_chain(data_dir)
        ts = _ts(now)
        change_id = f"CHG-{ts[:4]}{ts[5:7]}{ts[8:10]}T{ts[11:13]}{ts[14:16]}{ts[17:19]}Z-{secrets.token_hex(3)}"
        prop = {"id": change_id, "file": name, "base_sha256": sha256_bytes(base_bytes),
                "new_sha256": sha256_bytes(new_text.encode("utf-8")), "diff": diff,
                "author": escape_formula(author), "reason": escape_formula(reason), "tier": tier,
                "tier_inferred": inferred, "needs_validator": needs_validator, "created_utc": ts, "new_text": new_text}
        pbytes = (json.dumps(prop, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
        _atomic_write(proposal_path(data_dir, change_id), pbytes, exclusive=True)
        _append_event(data_dir, "propose", now=now, id=change_id, file=name, tier=tier, actor=author,
                      base_sha256=prop["base_sha256"], new_sha256=prop["new_sha256"],
                      proposal_sha256=sha256_bytes(pbytes), note=reason)
    return prop


def _signoff(author, approver, self_approved, exc_id, what: str, data_dir=None) -> tuple[str, str, str, str]:
    """(author, approver, self_flag, exc_id) after the four-eyes rule; self-approval needs an EXC-nnn id."""
    try:
        author, approver, flag = check_approval(author, approver, self_approved)
    except ValueError as e:
        raise ApprovalError(f"{what}: {e} together with an exception id (EXC-nnn)") from None
    return author, approver, flag, check_exc(flag, exc_id, what)


def check_exc(flag: str, exc_id, what: str, kind: str = "self-approval") -> str:
    """The EXC-nnn id after the single-operator rule: required when flag is "yes", well-formed when given at all.
    Shared by change approve/baseline and the compliance self-sign (EQ-C-0041)."""
    exc = str(exc_id or "").strip()
    if flag == "yes":
        if not EXC_RE.fullmatch(exc):
            raise ApprovalError(f"{what}: a {kind} (single-operator mode) needs an exception id EXC-nnn from "
                                f"docs/governance/issues-log.md (--exc EXC-nnn), got {exc_id!r}")
    elif exc and not EXC_RE.fullmatch(exc):
        raise ApprovalError(f"{what}: exception id must look like EXC-nnn, got {exc_id!r}")
    return exc


def exc_logged(data_dir, exc_id: str) -> bool | None:
    """True/False when docs/governance/issues-log.md (next to data/) lists exc_id as a table row id; None when the
    issues log is not there."""
    p = Path(data_dir).resolve().parent / "docs" / "governance" / "issues-log.md"
    if not p.exists() or not exc_id:
        return None
    return re.search(rf"^\|\s*{re.escape(exc_id)}\s*\|", p.read_text(encoding="utf-8"), re.M) is not None


def approve(data_dir, change_id, approver=None, self_approved: bool = False, exc_id=None, note: str = "",
            now: dt.datetime | None = None) -> dict:
    """Approve a proposed change. Four-eyes: the approver must differ from the author (ledger.person_key: case,
    whitespace, NFKC and zero-width characters ignored). Single-operator mode needs self_approved=True and
    exc_id 'EXC-nnn'; it is stored as approver = author, self_approved 'yes'. Returns the log row."""
    change_id = _check_id(change_id)
    with _locked(data_dir):
        rows = _require_chain(data_dir)
        prop = load_proposal(data_dir, change_id)
        st = _status(_events_by_id(rows).get(change_id, []))
        if st != "proposed":
            raise ApprovalError(f"{change_id} is {st}, only a proposed change can be approved")
        _, appr, flag, exc = _signoff(prop["author"], approver, self_approved, exc_id, f"approving {change_id}")
        extra = ""
        if flag == "yes":
            logged = exc_logged(data_dir, exc)
            extra = {True: "", False: f" [{exc} not yet in issues-log.md]", None: ""}[logged]
        if prop.get("needs_validator"):
            extra += " [independent review pending]"
        return _append_event(data_dir, "approve", now=now, id=change_id, file=prop["file"], tier=prop["tier"],
                             actor=appr, approver=appr, self_approved=flag, exc_id=exc,
                             base_sha256=prop["base_sha256"], new_sha256=prop["new_sha256"],
                             note=(str(note or "").strip() + extra).strip())


def reject(data_dir, change_id, by, reason: str = "", now: dt.datetime | None = None) -> dict:
    """Reject (or, by the author, withdraw) a proposed or approved change that was not applied."""
    change_id = _check_id(change_id)
    by = clean_person(by)
    if not person_key(by):
        raise ApprovalError("reject needs who rejects (by)")
    with _locked(data_dir):
        rows = _require_chain(data_dir)
        prop = load_proposal(data_dir, change_id)
        st = _status(_events_by_id(rows).get(change_id, []))
        if st not in ("proposed", "approved"):
            raise ApprovalError(f"{change_id} is {st}, cannot reject it")
        return _append_event(data_dir, "reject", now=now, id=change_id, file=prop["file"], tier=prop["tier"],
                             actor=by, base_sha256=prop["base_sha256"], new_sha256=prop["new_sha256"],
                             note=str(reason or "").strip())


def apply(data_dir, change_id, actor=None, now: dt.datetime | None = None) -> dict:
    """Write an approved change. Refused when it is not approved, when the governed file's sha256 is no longer the
    proposal's base (stale: re-propose), when the proposal file or log was tampered with. Writes atomically (temp file
    + rename) and logs the applied sha256. Returns the log row."""
    change_id = _check_id(change_id)
    with _locked(data_dir):
        rows = _require_chain(data_dir)
        prop = load_proposal(data_dir, change_id)
        st = _status(_events_by_id(rows).get(change_id, []))
        if st != "approved":
            raise ApprovalError(f"{change_id} is {st}; only an approved change can be applied")
        data = prop["new_text"].encode("utf-8")
        if sha256_bytes(data) != prop["new_sha256"]:
            raise ApprovalError(f"{change_id}: proposal text does not match its new_sha256")
        target = Path(data_dir) / _file_name(prop["file"])
        cur = file_sha256(target)
        if cur != prop["base_sha256"]:
            raise ApprovalError(f"{change_id} is stale: {prop['file']} has sha256 {str(cur)[:12]}... but the proposal was "
                                f"made against {prop['base_sha256'][:12]}...; reject it and propose again")
        _atomic_write(target, data)
        applied = file_sha256(target)
        return _append_event(data_dir, "apply", now=now, id=change_id, file=prop["file"], tier=prop["tier"],
                             actor=clean_person(actor) or "", base_sha256=prop["base_sha256"],
                             new_sha256=prop["new_sha256"], file_sha256=applied)


def _last_applied(rows, name: str) -> dict | None:
    last = None
    for r in rows:
        if r.get("file") == name and r.get("event") in ("apply", "baseline"):
            last = r
    return last


def baseline(data_dir, file, actor, reason, approver=None, self_approved: bool = False, exc_id=None,
             now: dt.datetime | None = None) -> dict:
    """Record the governed file's current sha256 as accepted, so detect_unapproved can start (first use) or accept a
    hand edit it reported (re-baseline). The first baseline of a file needs only the actor; accepting drift is a
    sign-off and follows the approve rules (approver other than the actor, or self_approved with EXC-nnn)."""
    name = _file_name(file)
    actor, reason = clean_person(actor), str(reason or "").strip()
    if not person_key(actor) or not reason:
        raise ApprovalError("baseline needs an actor and a reason")
    with _locked(data_dir):
        rows = _require_chain(data_dir)
        cur = file_sha256(Path(data_dir) / name)
        if cur is None:
            raise ApprovalError(f"{name} does not exist")
        prev = _last_applied(rows, name)
        appr, flag, exc = "", "", ""
        if prev is not None:
            if prev.get("file_sha256") == cur:
                raise ApprovalError(f"{name} already matches the last applied sha256; nothing to baseline")
            _, appr, flag, exc = _signoff(actor, approver, self_approved, exc_id, f"accepting drift in {name}")
        return _append_event(data_dir, "baseline", now=now, file=name, tier="limit" if name == "limits.json" else "",
                             actor=actor, approver=appr, self_approved=flag, exc_id=exc,
                             base_sha256=(prev or {}).get("file_sha256", ""), file_sha256=cur, note=reason)


def list_changes(data_dir, status: str | None = None) -> list[dict]:
    """One summary row per proposal, oldest first: id, file, tier, author, created_utc, status, changes, reason."""
    rows = read_log(data_dir)
    out = []
    for cid, evs in _events_by_id(rows).items():
        p0 = next((e for e in evs if e["event"] == "propose"), None)
        if p0 is None:
            continue
        st = _status(evs)
        if status and st != status:
            continue
        try:
            n = len(load_proposal(data_dir, cid)["diff"])
        except (ApprovalError, OSError, ValueError, KeyError):
            n = None
        out.append({"id": cid, "file": p0["file"], "tier": p0["tier"], "author": p0["actor"],
                    "created_utc": p0["ts_utc"], "status": st, "changes": n, "reason": p0["note"]})
    return out


def show(data_dir, change_id) -> dict:
    """The proposal (without new_text) with its status and events."""
    change_id = _check_id(change_id)
    prop = load_proposal(data_dir, change_id)
    evs = _events_by_id(read_log(data_dir)).get(change_id, [])
    out = {k: v for k, v in prop.items() if k != "new_text"}
    out["status"] = _status(evs)
    out["events"] = [{k: e.get(k, "") for k in ("seq", "ts_utc", "event", "actor", "approver", "self_approved",
                                                "exc_id", "file_sha256", "note")} for e in evs]
    return out


def _file_state(data_dir, rows, name: str) -> dict:
    cur = file_sha256(Path(data_dir) / name)
    last = _last_applied(rows, name)
    exp = (last or {}).get("file_sha256") or None
    st = ("default" if name in OPTIONAL_FILES and exp is None else "missing") if cur is None else \
        ("no_baseline" if exp is None else ("ok" if cur == exp else "drift"))
    return {"file": name, "status": st, "current_sha256": cur, "approved_sha256": exp,
            "last_event": (last or {}).get("event", ""), "last_id": (last or {}).get("id", ""),
            "last_ts_utc": (last or {}).get("ts_utc", "")}


def file_status(data_dir, file) -> dict:
    """detect_unapproved for one governed file, plus "chain_ok"; a log that does not verify gives chain_ok False."""
    name = _file_name(file)
    v = verify_chain(data_dir)
    try:
        rows = read_log(data_dir)
    except ApprovalError:
        rows = []
    return {**_file_state(data_dir, rows, name), "chain_ok": v["ok"], "chain_errors": v["errors"][:5]}


def detect_unapproved(data_dir) -> dict:
    """Drift check for health/governance: per governed file, current sha256 vs the last one applied or baselined
    through this tool. Status ok, drift (edited outside the tool), no_baseline (tool never used on it), missing, or
    default (an optional file, compliance.json, absent and never applied: the built-in default applies).
    Returns {"ok": no drift and chain verifies, "chain_ok", "files": [...]}."""
    v = verify_chain(data_dir)
    try:
        rows = read_log(data_dir)
    except ApprovalError:
        rows = []
    files = [_file_state(data_dir, rows, name) for name in FILES]
    return {"ok": v["ok"] and not any(f["status"] in ("drift", "missing") for f in files), "chain_ok": v["ok"],
            "files": files}
