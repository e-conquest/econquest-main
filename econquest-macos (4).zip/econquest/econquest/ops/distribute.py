"""Distribution of published research products by email (EQ-C-0045).

    econquest distribute queue ITEM [--actor NAME]       queue a published item (editorial publish does this itself)
    econquest distribute send [--item ITEM] [--send]     dry run by default: prints what would be sent, sends nothing
        [--confirm-new ADDR[,ADDR] | all-listed]         confirm once each address never delivered to (EQ-C-0051)
    econquest distribute status [--json]                 queue, deliveries, failures, latency p50/p95 (products, alerts)
    econquest distribute verify                          check the delivery log's hash chain; exit 1 on a break

Rules
- Only an item whose editorial state is "published" (immutable copy under outputs/published/, manifest and files
  checked against the ledger by editorial.verify_published) is ever distributed. Withdrawn or corrected items are
  skipped. The email carries a link into the published archive (data/distribution.json `archive_base_url` + the
  published directory, or a file:// path when no base URL is set) and the manifest's file names and sha256; nothing
  is attached, so no draft or unpublished file can leave the machine.
- Subscribers per product kind (editorial.KINDS) live in data/distribution.json; one message per recipient (no
  recipient sees another). Any CR or LF in an address, the subject prefix or a value that goes into a header is
  refused (header injection), and addresses must be plain addr-spec (no display names, commas or angle brackets).
- Sending needs `--send` and ECONQUEST_SMTP_HOST; without `--send` nothing connects anywhere. SMTP settings are the
  alert settings (validation.alerts.send_email, reused: STARTTLS or SMTPS, fail closed): ECONQUEST_SMTP_HOST, _PORT,
  _USER, _FROM, and the password from $ECONQUEST_SMTP_PASSWORD or the macOS Keychain item `econquest-smtp`, never a
  file in the repo. The password and user are masked in every message and log row.
- Confirm once (EQ-C-0051, SEC-C-005 R4): on `--send`, an address with no "sent" deliver row and no "confirm" row is
  new; its messages are withheld (and printed) unless `--confirm-new` names it (or `all-listed`, which prints each)
  and `--actor` says who confirms. A confirmation is a "confirm" row (actor, recipient, config_sha256, ts), written
  only on a real `--send`; the dry run lists the addresses that would need it. Other recipients are not held up.
- Every queue, delivery and alert-delivery is one row of <out>/store/deliveries.jsonl (backed up with the store),
  hash-chained like the change-approval log (approvals.row_hash; deliveries.head.json names the last row). Rows: seq,
  ts_utc, event (queue | deliver | alert | confirm), item_id, kind, recipient, actor, result ("sent", "error: ...", "skipped:
  ..."), event_utc (when the thing being delivered happened: publish time, or the alert's deadline / job time),
  latency_s (ts_utc - event_utc for a sent row), config_sha256, note, prev_hash, row_hash. A recipient with a "sent"
  row for an item is never sent it again; a broken chain refuses sending (the sent state cannot be trusted).
- Latency: products from published_utc to the sent row; alerts from the alert's own timestamp (missed_run deadline,
  job_failed end, job_hung start) to delivery, as logged by ops/health.py through log_alert_delivery.
"""
from __future__ import annotations

import contextlib
import datetime as dt
import json
import math
import os
import re
import urllib.parse
from pathlib import Path

from .approvals import GENESIS, _atomic_write, _ts, row_hash, sha256_bytes

try:
    import fcntl
except ImportError:                                     # pragma: no cover - Windows
    fcntl = None

CONFIG_NAME = "distribution.json"
LOG_NAME, HEAD_NAME = "deliveries.jsonl", "deliveries.head.json"
KEYCHAIN_SERVICE = "econquest-smtp"
FIELDS = ("seq", "ts_utc", "event", "item_id", "kind", "recipient", "actor", "result", "event_utc", "latency_s",
          "config_sha256", "note", "prev_hash", "row_hash")
_ADDR = re.compile(r"[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?"
                   r"(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?)+")
_CRLF = re.compile(r"[\r\n\x00\x0b\x0c\x1c-\x1e  \x85]")      # every str.splitlines boundary (SEC-C-005)


class DistributionError(ValueError):
    """A refused distribution action (bad config, unpublished item, header injection, broken log)."""


# ---------------------------------------------------------------- config
def config_path(data_dir) -> Path:
    return Path(data_dir) / CONFIG_NAME


def header_safe(value, what: str) -> str:
    """value as str, or DistributionError when it holds CR, LF (or NUL, VT, FF, FS/GS/RS, U+2028/9, NEL): header
    injection."""
    s = str(value if value is not None else "")
    if _CRLF.search(s):
        raise DistributionError(f"{what} contains a line break; refused (header injection): {s[:60]!r}")
    return s


def check_address(addr, what: str = "subscriber") -> str:
    a = header_safe(addr, what).strip()
    if not _ADDR.fullmatch(a) or len(a) > 254:
        raise DistributionError(f"{what} {a[:60]!r} is not a plain email address (name@domain, no display name, "
                                "comma or angle brackets)")
    return a


def load_config(data_dir) -> dict:
    """data/distribution.json: {"archive_base_url": "" | https URL, "subject_prefix": str,
    "subscribers": {kind: [address, ...]}}. Missing file = no subscribers. Returns it normalised with "sha256"."""
    from ..presentation.editorial import KINDS
    p = config_path(data_dir)
    if not p.exists():
        return {"archive_base_url": "", "subject_prefix": "EconQuest", "subscribers": {k: [] for k in KINDS},
                "sha256": None, "source": "default"}
    raw = p.read_bytes()
    try:
        doc = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise DistributionError(f"{p}: not valid JSON ({e})") from None
    if not isinstance(doc, dict) or set(doc) - {"archive_base_url", "subject_prefix", "subscribers"}:
        raise DistributionError(f"{p}: expected an object with keys archive_base_url, subject_prefix, subscribers")
    subs = doc.get("subscribers") or {}
    if not isinstance(subs, dict) or set(subs) - set(KINDS):
        raise DistributionError(f"{p}: subscribers must map product kinds ({', '.join(KINDS)}) to address lists")
    out = {}
    for k in KINDS:
        lst = subs.get(k) or []
        if not isinstance(lst, list):
            raise DistributionError(f"{p}: subscribers.{k} must be a list of addresses")
        seen, clean = set(), []
        for a in lst:
            a = check_address(a, f"subscribers.{k} entry")
            if a.casefold() not in seen:
                seen.add(a.casefold()); clean.append(a)
        out[k] = clean
    prefix = header_safe(doc.get("subject_prefix", "EconQuest"), "subject_prefix").strip()
    if len(prefix) > 60:
        raise DistributionError(f"{p}: subject_prefix longer than 60 characters")
    base = header_safe(doc.get("archive_base_url") or "", "archive_base_url").strip()
    if base:
        from ..validation.alerts import check_webhook_url      # same rule: https, or http only to loopback
        try:
            check_webhook_url(base)
        except ValueError as e:
            raise DistributionError(f"{p}: archive_base_url: {str(e).replace('webhook URL', 'URL')}") from None
        u = urllib.parse.urlsplit(base)                    # SEC-C-005: the link goes to every subscriber
        if u.username is not None or u.password is not None or u.query or u.fragment or "@" in u.netloc:
            raise DistributionError(f"{p}: archive_base_url must be a plain https://host/path (no user:password@, "
                                    "query or fragment): the link is mailed to every subscriber")
    return {"archive_base_url": base, "subject_prefix": prefix, "subscribers": out, "sha256": sha256_bytes(raw),
            "source": str(p)}


# ---------------------------------------------------------------- delivery log (hash chain)
def log_path(out_dir) -> Path:
    return Path(out_dir) / "store" / LOG_NAME


def head_path(out_dir) -> Path:
    return Path(out_dir) / "store" / HEAD_NAME


@contextlib.contextmanager
def _locked(out_dir):
    p = log_path(out_dir); p.parent.mkdir(parents=True, exist_ok=True)
    with open(p.with_name(".deliveries.lock"), "a") as f:
        if fcntl is not None:
            fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            if fcntl is not None:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)


def read_log(out_dir) -> list[dict]:
    p = log_path(out_dir)
    if not p.exists():
        return []
    rows = []
    for line in p.read_text(encoding="utf-8").splitlines():
        if line.strip():
            try:
                r = json.loads(line)
            except json.JSONDecodeError:
                r = {}
            rows.append(r if isinstance(r, dict) else {})       # SEC-C-005: a non-object line is a broken row
    return rows


def verify(out_dir) -> dict:
    """seq runs 1..n, each prev_hash is the previous row_hash, each row_hash recomputes, the head names the last row."""
    p = log_path(out_dir)
    errors, rows, prev = [], [], GENESIS
    for i, line in enumerate(p.read_text(encoding="utf-8").splitlines() if p.exists() else [], 1):
        try:
            r = json.loads(line)
        except json.JSONDecodeError:
            errors.append(f"line {i}: not JSON"); prev = None; continue
        if not isinstance(r, dict):                          # SEC-C-005: report, do not crash
            errors.append(f"line {i}: not a JSON object"); prev = None; continue
        if r.get("seq") != len(rows) + 1:
            errors.append(f"line {i}: seq {r.get('seq')} where {len(rows) + 1} expected (row deleted, inserted or moved)")
        if prev is not None and r.get("prev_hash") != prev:
            errors.append(f"line {i}: prev_hash does not match the previous row")
        if r.get("row_hash") != row_hash(str(r.get("prev_hash", "")), r):
            errors.append(f"line {i}: row_hash does not recompute (row edited)")
        prev = r.get("row_hash"); rows.append(r)
    hp = head_path(out_dir)
    if hp.exists():
        try:
            head = json.loads(hp.read_text())
        except json.JSONDecodeError:
            head = None; errors.append(f"{HEAD_NAME} is not JSON")
        last = rows[-1] if rows else {"seq": 0, "row_hash": GENESIS}
        if isinstance(head, dict) and (head.get("seq"), head.get("row_hash")) != (last.get("seq"), last.get("row_hash")):
            errors.append(f"{HEAD_NAME} names seq {head.get('seq')} but the log ends at seq {last.get('seq')}")
    elif rows:
        errors.append(f"{HEAD_NAME} missing (rows removed from the end?)")
    return {"ok": not errors, "rows": len(rows), "errors": errors, "path": str(p)}


def _append(out_dir, event: str, now=None, **fields) -> dict:
    """Append one row (caller holds _locked and has verified the chain)."""
    rows = read_log(out_dir)
    row = {c: "" for c in FIELDS}
    row.update({k: ("" if v is None else v) for k, v in fields.items() if k in FIELDS})
    row.update(seq=len(rows) + 1, ts_utc=_ts(now), event=event, prev_hash=rows[-1].get("row_hash", "") if rows else GENESIS)
    row["row_hash"] = row_hash(row["prev_hash"], row)
    with open(log_path(out_dir), "a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n"); f.flush(); os.fsync(f.fileno())
    _atomic_write(head_path(out_dir), (json.dumps({"seq": row["seq"], "row_hash": row["row_hash"]}) + "\n").encode())
    return row


def _require_chain(out_dir) -> list[dict]:
    v = verify(out_dir)
    if not v["ok"]:
        raise DistributionError(f"delivery log {v['path']} failed verification, refusing: " + "; ".join(v["errors"][:3]))
    return read_log(out_dir)


def _parse(ts) -> dt.datetime | None:
    try:
        t = dt.datetime.fromisoformat(str(ts).replace("Z", "+00:00"))
    except ValueError:
        return None
    return t.replace(tzinfo=dt.timezone.utc) if t.tzinfo is None else t


def _latency(ts_utc: str, event_utc) -> float | str:
    a, b = _parse(ts_utc), _parse(event_utc)
    return round((a - b).total_seconds(), 3) if a and b else ""


# ---------------------------------------------------------------- published items
def _published(out_dir, item_id: str) -> dict:
    """The item when it is published and its archive copy verifies; DistributionError otherwise."""
    from ..presentation import editorial as E
    try:
        it = E.get_item(out_dir, item_id)
    except E.EditorialError as e:
        raise DistributionError(str(e)) from None
    if it["state"] != "published":
        raise DistributionError(f"{item_id} is {it['state']}: only a published item is distributed")
    probs = [p for p in E.verify_published(out_dir)["problems"]
             if p.startswith(f"{item_id} (") or p.startswith("ledger line")]
    if probs:
        raise DistributionError(f"{item_id}: published copy does not verify: " + "; ".join(probs[:3]))
    return it


def archive_link(out_dir, it: dict, cfg: dict) -> str:
    rel = Path(it["published_dir"])                         # published/<kind>/<date>-<id>
    if cfg.get("archive_base_url"):
        sub = "/".join(urllib.parse.quote(s) for s in rel.parts[1:])
        return cfg["archive_base_url"].rstrip("/") + "/" + sub + "/"
    return (Path(out_dir).resolve() / rel).as_uri()


def compose(out_dir, it: dict, cfg: dict) -> tuple[str, str]:
    """(subject, text body) for a published item. Header values are checked for line breaks."""
    man = json.loads((Path(out_dir) / it["published_dir"] / "manifest.json").read_text(encoding="utf-8"))
    as_of = header_safe(it["meta"].get("as_of") or "", "as_of")[:10]
    kind = header_safe(it["kind"], "kind"); iid = header_safe(it["item_id"], "item id")
    subject = header_safe(f"{cfg['subject_prefix']}: {kind.replace('_', ' ')} {as_of} ({iid})".strip(), "subject")
    lines = [f"{kind.replace('_', ' ').capitalize()} {iid}, as of {as_of or 'n/a'}, published {it.get('published_utc', '')}.",
             "", f"Read it in the published archive: {archive_link(out_dir, it, cfg)}", "", "Files (sha256):"]
    lines += [f"  {f['name']}  {f['sha256']}" for f in man.get("files", [])]
    if it.get("correction_of"):
        lines += ["", f"This corrects {it['correction_of']}."]
    lines += ["", man.get("disclaimer", ""), "", "You receive this because you subscribe to this product. "
              "Nothing is attached; the archive copy is read-only and listed in its manifest.json."]
    return subject, "\n".join(lines) + "\n"


# ---------------------------------------------------------------- queue / send / status
def _queued(rows) -> list[str]:
    seen = []
    for r in rows:
        if r.get("event") == "queue" and r.get("item_id") not in seen:
            seen.append(r["item_id"])
    return seen


def _known(rows) -> set[str]:
    """Addresses (casefolded) with a confirmed delivery: a "sent" deliver row or a "confirm" row (EQ-C-0051)."""
    return {str(r.get("recipient")).casefold() for r in rows
            if (r.get("event") == "deliver" and r.get("result") == "sent") or r.get("event") == "confirm"}


def parse_confirm(arg, listed) -> set[str] | None:
    """--confirm-new: None (nothing confirmed), "all-listed" (every listed address) or a comma list. Each address passes
    header and address validation and must be a listed subscriber. Returns casefolded addresses."""
    if arg is None or str(arg).strip() == "":
        return None
    a = header_safe(arg, "--confirm-new").strip()
    listed = {x.casefold() for x in listed}
    if a == "all-listed":
        return set(listed)
    out = set()
    for part in a.split(","):
        addr = check_address(part, "--confirm-new address").casefold()
        if addr not in listed:
            raise DistributionError(f"--confirm-new {addr}: not a subscriber in data/distribution.json")
        out.add(addr)
    return out


def _sent(rows) -> set[tuple[str, str]]:
    return {(r["item_id"], str(r["recipient"]).casefold()) for r in rows
            if r.get("event") == "deliver" and r.get("result") == "sent"}


def queue(out_dir, item_id: str, actor: str = "", data_dir=None, now=None) -> dict:
    """Queue a published item for distribution (nothing is sent). Queuing twice is a no-op."""
    it = _published(out_dir, item_id)
    cfg = load_config(data_dir) if data_dir is not None else {"sha256": None}
    with _locked(out_dir):
        rows = _require_chain(out_dir)
        if item_id in _queued(rows):
            return {"item_id": item_id, "queued": False, "note": "already queued"}
        _append(out_dir, "queue", now=now, item_id=item_id, kind=it["kind"], actor=header_safe(actor, "actor")[:80],
                event_utc=it.get("published_utc"), config_sha256=cfg.get("sha256"), note=it["published_dir"])
    return {"item_id": item_id, "queued": True, "kind": it["kind"]}


def smtp_password(env: dict, keychain=None) -> str:
    """$ECONQUEST_SMTP_PASSWORD, else the Keychain item econquest-smtp, else ""."""
    pw = (env.get("ECONQUEST_SMTP_PASSWORD") or "").strip()
    return pw or ((keychain or _keychain_secret)(KEYCHAIN_SERVICE) or "")


def _keychain_secret(service: str) -> str | None:
    """macOS Keychain: `security find-generic-password -s <service> -w` (as cli._keychain_token). Failure = None."""
    import shutil
    import subprocess  # nosec B404: only the fixed Keychain lookup below
    exe = shutil.which("security")
    if not exe:
        return None
    try:
        r = subprocess.run([exe, "find-generic-password", "-s", service, "-w"], capture_output=True, text=True,
                           timeout=10)  # nosec B603: fixed argv, no shell
    except (OSError, subprocess.SubprocessError):
        return None
    s = (r.stdout or "").strip()
    return s if r.returncode == 0 and s else None


def _mask(text: str, secrets) -> str:
    from .actionlog import mask
    return mask(str(text), [s for s in secrets if s])


def plan(out_dir, data_dir, item_id: str | None = None) -> dict:
    """What a send would do now: {"messages": [{item_id, kind, recipient, subject, body}], "skipped": [...],
    "config": cfg}. Reads only."""
    cfg = load_config(data_dir)
    rows = _require_chain(out_dir)
    sent = _sent(rows)
    items = [item_id] if item_id else _queued(rows)
    if item_id and item_id not in _queued(rows):
        raise DistributionError(f"{item_id} is not queued: run `econquest distribute queue {item_id}` first")
    msgs, skipped = [], []
    known = _known(rows)
    for iid in items:
        try:
            it = _published(out_dir, iid)
        except DistributionError as e:
            skipped.append({"item_id": iid, "reason": str(e)}); continue
        subs = cfg["subscribers"].get(it["kind"], [])
        if not subs:
            skipped.append({"item_id": iid, "reason": f"no subscribers for {it['kind']} in {cfg['source']}"}); continue
        subject, body = compose(out_dir, it, cfg)
        for a in subs:
            if (iid, a.casefold()) not in sent:
                msgs.append({"item_id": iid, "kind": it["kind"], "recipient": a, "subject": subject, "body": body,
                             "event_utc": it.get("published_utc")})
    new = sorted({m["recipient"].casefold() for m in msgs} - known)
    return {"messages": msgs, "skipped": skipped, "config": cfg, "new_recipients": new}


def send(out_dir, data_dir, item_id: str | None = None, really_send: bool = False, actor: str = "",
         env: dict | None = None, send_fn=None, keychain=None, log=print, now=None, confirm_new=None) -> dict:
    """Deliver queued items. really_send=False (the default, `--dry-run`): print what would be sent, connect nowhere,
    write nothing. really_send=True needs ECONQUEST_SMTP_HOST; each recipient gets one message (validation.alerts
    .send_email with that recipient), and each attempt is one delivery-log row. Messages to a new address (never
    delivered to, never confirmed) are withheld unless confirm_new names it ("all-listed" or a comma list; see
    parse_confirm); a confirmation is a "confirm" row. Returns {"sent", "failed", "would_send", "skipped", "withheld",
    "confirmed"}."""
    env = dict(os.environ if env is None else env)
    actor = header_safe(actor, "actor")[:80]
    if not really_send:
        p = plan(out_dir, data_dir, item_id)
        conf = parse_confirm(confirm_new, [a for v in p["config"]["subscribers"].values() for a in v]) or set()
        need = [a for a in p["new_recipients"] if a not in conf]
        for m in p["messages"]:
            log(f"[distribute] DRY RUN would send {m['item_id']} ({m['kind']}) to {m['recipient']}: {m['subject']}")
        for s in p["skipped"]:
            log(f"[distribute] skip {s['item_id']}: {s['reason']}")
        for a in need:
            log(f"[distribute] DRY RUN new address, --send would withhold it without --confirm-new: {a}")
        log(f"[distribute] dry run: {len(p['messages'])} message(s) would be sent; nothing sent (pass --send)")
        return {"sent": 0, "failed": 0, "would_send": len(p["messages"]), "skipped": p["skipped"], "messages": p["messages"],
                "needs_confirmation": need}
    if not env.get("ECONQUEST_SMTP_HOST"):
        raise DistributionError("--send needs ECONQUEST_SMTP_HOST (and _PORT, _USER, _FROM; password from "
                                f"$ECONQUEST_SMTP_PASSWORD or the Keychain item {KEYCHAIN_SERVICE})")
    header_safe(env.get("ECONQUEST_SMTP_FROM") or env.get("ECONQUEST_SMTP_USER") or "", "ECONQUEST_SMTP_FROM")
    pw = smtp_password(env, keychain)
    secrets = [pw, env.get("ECONQUEST_SMTP_USER", "")]
    if send_fn is None:
        from ..validation.alerts import send_email as send_fn
    res = {"sent": 0, "failed": 0, "would_send": 0, "skipped": [], "withheld": [], "confirmed": []}
    with _locked(out_dir):                                   # one sender at a time: no double sends
        p = plan(out_dir, data_dir, item_id)
        res["skipped"] = p["skipped"]
        conf = parse_confirm(confirm_new, [a for v in p["config"]["subscribers"].values() for a in v]) or set()
        if conf & set(p["new_recipients"]) and not actor:
            raise DistributionError("--confirm-new needs --actor (who confirms the new addresses)")
        for a in p["new_recipients"]:                        # EQ-C-0051: confirm once, recorded before the send
            if a in conf:
                _append(out_dir, "confirm", now=now, recipient=a, actor=actor, result="confirmed",
                        config_sha256=p["config"]["sha256"], note="--confirm-new" + (" all-listed" if confirm_new == "all-listed" else ""))
                res["confirmed"].append(a); log(f"[distribute] confirmed new address {a} (by {actor})")
            else:
                res["withheld"].append(a)
                log(f"[distribute] WITHHELD new address {a}: never delivered to; confirm with --confirm-new {a}")
        for m in p["messages"]:
            if m["recipient"].casefold() in res["withheld"]:
                continue
            rcpt = check_address(m["recipient"])
            e1 = {**env, "ECONQUEST_SMTP_TO": rcpt, "ECONQUEST_SMTP_PASSWORD": pw}
            try:
                send_fn(e1, header_safe(m["subject"], "subject"), m["body"])
                result = "sent"; res["sent"] += 1
            except Exception as e:                           # noqa: BLE001 - logged per recipient, others continue
                result = _mask(f"error: {type(e).__name__}: {e}", secrets)[:300]; res["failed"] += 1
            ts = _ts(now)
            _append(out_dir, "deliver", now=now, item_id=m["item_id"], kind=m["kind"], recipient=rcpt, actor=actor,
                    result=result, event_utc=m["event_utc"], latency_s=_latency(ts, m["event_utc"]) if result == "sent" else "",
                    config_sha256=p["config"]["sha256"])
            log(f"[distribute] {m['item_id']} -> {rcpt}: {result}")
    log(f"[distribute] {res['sent']} sent, {res['failed']} failed, {len(res['withheld'])} new address(es) withheld, "
        f"{len(res['skipped'])} item(s) skipped")
    return res


def alert_event_time(alert: dict) -> str | None:
    """The time the alerted condition began, from the health alert itself: a missed run's deadline (threshold), a
    failed job's end or a hung job's start (the last part of its key). None when the alert carries no time."""
    kind, key = alert.get("kind"), str(alert.get("key") or "")
    if kind == "missed_run":
        return alert.get("threshold") if _parse(alert.get("threshold")) else None
    if kind in ("job_failed", "job_hung") and key.count(":") >= 2:
        t = key.split(":", 2)[2]
        return t if _parse(t) else None
    return None


def log_alert_delivery(out_dir, alerts: list[dict], delivery: dict | None, now=None) -> int:
    """Record health alert deliveries (ops/health.py) for the latency measure: one "alert" row per alert and channel
    that was attempted (status not skipped / not configured). Returns rows written. Never raises on a broken chain:
    the alert already went out, so the row is appended and `distribute verify` reports the break."""
    chans = {k: str(v) for k, v in (delivery or {}).items() if k in ("webhook", "email")
             and v and not str(v).startswith(("skipped", "not configured"))}
    if not chans or not alerts:
        return 0
    n = 0
    with _locked(out_dir):
        for a in alerts:
            ev = alert_event_time(a)
            for ch, st in chans.items():
                ok = not st.startswith("error")
                ts = _ts(now)
                _append(out_dir, "alert", now=now, item_id=str(a.get("key") or a.get("kind")), kind=a.get("kind"),
                        recipient=ch, actor="health", result="sent" if ok else st[:300], event_utc=ev,
                        latency_s=_latency(ts, ev) if ok and ev else "")
                n += 1
    return n


def _pct(vals: list[float], q: float) -> float | None:
    """Nearest-rank percentile."""
    if not vals:
        return None
    s = sorted(vals)
    return s[max(0, math.ceil(q * len(s)) - 1)]


def status(out_dir, data_dir=None) -> dict:
    """Queue, deliveries and latency: {"chain", "queued", "pending", "sent", "failed", "latency": {"products",
    "alerts": {"n", "p50_s", "p95_s", "max_s"}}, "subscribers": {kind: n}}."""
    v = verify(out_dir)
    rows = [r for r in read_log(out_dir) if r]
    sent = _sent(rows)
    lat = {}
    for name, ev in (("products", "deliver"), ("alerts", "alert")):
        xs = [float(r["latency_s"]) for r in rows if r.get("event") == ev and r.get("result") == "sent"
              and isinstance(r.get("latency_s"), (int, float))]
        lat[name] = {"n": len(xs), "p50_s": _pct(xs, 0.5), "p95_s": _pct(xs, 0.95), "max_s": max(xs) if xs else None}
    out = {"chain": {"ok": v["ok"], "rows": v["rows"], "errors": v["errors"][:5]}, "queued": len(_queued(rows)),
           "sent": sum(1 for r in rows if r.get("event") == "deliver" and r.get("result") == "sent"),
           "failed": sum(1 for r in rows if r.get("event") == "deliver" and str(r.get("result")).startswith("error")),
           "latency": lat, "pending": None, "subscribers": None}
    if data_dir is not None:
        try:
            cfg = load_config(data_dir)
            out["subscribers"] = {k: len(v) for k, v in cfg["subscribers"].items()}
            out["pending"] = 0
            from ..presentation import editorial as E
            items = {i["item_id"]: i for i in E.list_items(out_dir)}
            for iid in _queued(rows):
                it = items.get(iid)
                if it and it["state"] == "published":
                    out["pending"] += sum(1 for a in cfg["subscribers"].get(it["kind"], []) if (iid, a.casefold()) not in sent)
        except DistributionError as e:
            out["config_error"] = str(e)
    return out


def format_status(st: dict) -> list[str]:
    def f(x):
        return "-" if x is None else (f"{x / 60:.1f} min" if x >= 120 else f"{x:.0f} s")
    lines = [f"delivery log: {'ok' if st['chain']['ok'] else 'BROKEN'} ({st['chain']['rows']} rows)"]
    lines += ["  " + e for e in st["chain"]["errors"]]
    lines.append(f"queued items: {st['queued']}; pending messages: {st['pending'] if st['pending'] is not None else '?'}; "
                 f"sent: {st['sent']}; failed attempts: {st['failed']}")
    for k, v in st["latency"].items():
        lines.append(f"{k} delivery latency: n={v['n']} p50 {f(v['p50_s'])} p95 {f(v['p95_s'])} max {f(v['max_s'])}")
    if st.get("subscribers") is not None:
        lines.append("subscribers: " + ", ".join(f"{k} {n}" for k, n in st["subscribers"].items()))
    if st.get("config_error"):
        lines.append("config error: " + st["config_error"])
    return lines


# ---------------------------------------------------------------- CLI (registered by ops/commands.py)
def add_arguments(ap) -> None:
    ds = ap.add_subparsers(dest="dist_cmd", required=True)
    q = ds.add_parser("queue", help="queue a published item (editorial publish queues automatically; nothing is sent)")
    q.add_argument("item"); q.add_argument("--actor")
    s = ds.add_parser("send", help="deliver queued items to their subscribers: DRY RUN unless --send")
    s.add_argument("--item", help="only this queued item"); s.add_argument("--actor", help="who sends (delivery log)")
    g = s.add_mutually_exclusive_group()
    g.add_argument("--send", action="store_true", help="really send (needs ECONQUEST_SMTP_HOST; Mac only)")
    g.add_argument("--dry-run", action="store_true", help="print what would be sent (the default)")
    s.add_argument("--confirm-new", metavar="ADDR[,ADDR]|all-listed",
                   help="confirm addresses never delivered to (recorded on --send; others are withheld); needs --actor")
    st = ds.add_parser("status", help="queue, deliveries, failures and delivery latency p50/p95 (products and alerts)")
    st.add_argument("--json", action="store_true")
    ds.add_parser("verify", help="check the delivery log's hash chain; exit 1 on a break")


def run_from_args(args) -> int:
    out, data = Path(args.out), Path(args.data)
    try:
        if args.dist_cmd == "queue":
            r = queue(out, args.item, actor=args.actor or "", data_dir=data)
            print(f"{args.item}: {'queued' if r['queued'] else r['note']}")
        elif args.dist_cmd == "send":
            send(out, data, item_id=args.item, really_send=bool(args.send), actor=args.actor or "",
                 confirm_new=args.confirm_new)
        elif args.dist_cmd == "status":
            st = status(out, data)
            print(json.dumps(st, indent=1) if args.json else "\n".join(format_status(st)))
        else:
            v = verify(out)
            print(f"delivery log: {'ok' if v['ok'] else 'BROKEN'} ({v['rows']} rows) {v['path']}")
            for e in v["errors"]:
                print("  " + e)
            return 0 if v["ok"] else 1
    except DistributionError as e:
        raise SystemExit(f"distribute {args.dist_cmd}: {e}") from None
    return 0
