"""CLI subcommands for the ops modules (EQ-C-0021, EQ-C-0022). econquest/cli.py adds them with

    from .ops.commands import register as register_ops
    register_ops(sub, HOME_DIR)

    econquest schedule install|uninstall|show [--job J] [--load] [--tz TZ] [--record-time HH:MM] ...
    econquest health [--no-deliver] [--stale-days N] [--strict]
    econquest backup [--verify] [--verify-only BACKUP] [--dest DIR] [--no-prune] [--list]
    econquest restore-drill [--backup BACKUP] [--dest DIR] [--keep]
    econquest distribute queue|send|status|verify   (EQ-C-0045; send is a dry run unless --send)
    econquest evidence --as-of D [--out DIR] [--quick] [--tests-from FILE] | evidence verify ZIP   (EQ-C-0060)

The top-level --data / --out are honoured by health; schedule, backup and restore-drill work on the install folder
(the parent of --out, i.e. ECONQUEST_HOME), because they cover data/ and outputs/ together.
"""
from __future__ import annotations
import sys
from pathlib import Path


def _home(args, default_home) -> Path:
    out = getattr(args, "out", None)
    return Path(out).expanduser().resolve().parent if out else Path(default_home)


def register(sub, default_home) -> None:
    from . import backup, distribute, health, schedule

    def _exit(code: int) -> None:
        if code:
            sys.exit(code)

    sc = sub.add_parser("schedule", help="launchd jobs on macOS (record 18:20 NY weekdays, morning run+report, Monday monitor, nightly backup, 15-min health): install, uninstall or show")
    schedule.add_arguments(sc)
    sc.set_defaults(fn=lambda a: schedule.run_from_args(a, _home(a, default_home)) and None)

    he = sub.add_parser("health", help="missed scheduled runs, stale live feeds and failed jobs; writes outputs/health.json and delivers new alerts")
    health.add_arguments(he)
    he.set_defaults(fn=lambda a: _exit(health.run_from_args(a, a.data, a.out)))

    bk = sub.add_parser("backup", help="tar.gz of data/ and outputs/store with a sha256 manifest to $ECONQUEST_BACKUP_DEST (default ~/econquest-backups/nightly/<UTC date>/); keeps 14 daily + 8 weekly")
    backup.add_backup_arguments(bk)
    bk.set_defaults(fn=lambda a: _exit(_guard(backup.backup_from_args, a, _home(a, default_home))))

    rd = sub.add_parser("restore-drill", help="restore the latest backup into a temp folder, verify every hash, smoke check, time it (target < 4 h); writes outputs/logs/restore-drill-<ts>.json")
    backup.add_drill_arguments(rd)
    rd.set_defaults(fn=lambda a: _exit(_guard(backup.drill_from_args, a, _home(a, default_home))))

    di = sub.add_parser("distribute", help="email published products to their subscribers (data/distribution.json) with an archive link: "
                                           "queue, send (dry run unless --send), status (latency p95), verify the delivery log")
    distribute.add_arguments(di)
    di.set_defaults(fn=lambda a: _exit(distribute.run_from_args(a)))

    from . import evidence
    ev = sub.add_parser("evidence", help="one verifiable zip for an independent validator: governance and validation docs, the stored runs "
                                         "for --as-of with their hashes, test results, replication, hash chains, dossier and release "
                                         "manifests (outputs/evidence/evidence-<as_of>.zip); `evidence verify ZIP` rechecks it offline")
    evidence.add_arguments(ev)
    ev.set_defaults(fn=lambda a: _exit(evidence.run_from_args(a, default_home)))


def _guard(fn, args, home) -> int:
    from .backup import BackupError
    try:
        return fn(args, home)
    except BackupError as e:
        print(f"[backup] error: {e}", file=sys.stderr)
        return 2
