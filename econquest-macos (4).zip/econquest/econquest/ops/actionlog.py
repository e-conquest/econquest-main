"""Tamper-evident log of operator actions (EQ-C-0035).

One JSON object per line in <out>/store/actions.jsonl (override: $ECONQUEST_ACTION_LOG, a file path), hash-chained the
same way as the change-approval log (ops/approvals.py, whose helpers are reused): every row carries `seq` (1..n),
`prev_hash` (the previous row's `row_hash`, 64 zeros for the first) and `row_hash` = sha256(prev_hash + the canonical
JSON of the row without row_hash). actions.head.json beside the log names the last seq and row_hash, so removing rows
from the end is caught too.

Why <out>/store: the nightly backup (ops/backup.py) covers data/ and outputs/store, so the log is backed up and
restore-drilled; outputs/ is never shipped in a release zip and never replaced by install.sh (data/approvals/ is: the
installer copies the release's approvals folder over the installed one on upgrade, which would overwrite this log).

Row fields: seq, ts_utc, command ("change approve", "publish", "run-gate override", ...), args (the parsed options with
every secret-looking option dropped and every known secret value masked), actor and actor_source ("flag" when it came
from --author/--reviewer/--publisher/--by/--approver/--actor, "os" for $USER), outcome ("ok" or "error"), exit_code,
error (message, secrets masked), versions {code_version, code_hash, run_id}, prev_hash, row_hash.

    append(out_dir, command, args, ...) -> row        (never raises for the caller in cli.py: see cli._record_action)
    verify(out_dir) -> {"ok", "rows", "head", "errors"}
    tail(out_dir, n) -> last n rows
"""
from __future__ import annotations

import contextlib
import json
import os
import re
from pathlib import Path

from .approvals import GENESIS, _atomic_write, _ts, row_hash

try:
    import fcntl
except ImportError:                                     # pragma: no cover - Windows
    fcntl = None

LOG_ENV = "ECONQUEST_ACTION_LOG"
LOG_NAME = "actions.jsonl"
HEAD_NAME = "actions.head.json"
REDACTED = "***"
# option names whose values never reach the log (the Sheets token above all; token_file is a path but is dropped too)
SECRET_KEY_RE = re.compile(r"token|passw|secret|api_?key|credential|webhook", re.I)
FIELDS = ("seq", "ts_utc", "command", "args", "actor", "actor_source", "outcome", "exit_code", "error", "versions",
          "prev_hash", "row_hash")


def log_path(out_dir) -> Path:
    env = os.environ.get(LOG_ENV, "").strip()
    return Path(env).expanduser() if env else Path(out_dir) / "store" / LOG_NAME


def head_path(out_dir) -> Path:
    return log_path(out_dir).with_name(HEAD_NAME)


@contextlib.contextmanager
def _locked(out_dir):
    p = log_path(out_dir); p.parent.mkdir(parents=True, exist_ok=True)
    with open(p.with_name(".actions.lock"), "a") as f:
        if fcntl is not None:
            fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            if fcntl is not None:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)


def mask(text: str, secrets) -> str:
    for s in secrets or ():
        if s and len(s) >= 4:
            text = text.replace(s, REDACTED)
    return text


def _jsonable(v, secrets):
    if v is None or isinstance(v, (bool, int, float)):
        return v
    if isinstance(v, str):
        return mask(v, secrets)
    if isinstance(v, Path):
        return mask(str(v), secrets)
    if isinstance(v, dict):
        return {str(k): (REDACTED if SECRET_KEY_RE.search(str(k)) and val not in (None, False, "") else _jsonable(val, secrets))
                for k, val in v.items()}
    if isinstance(v, (list, tuple, set)):
        return [_jsonable(x, secrets) for x in v]
    if callable(v):
        return None
    return mask(str(v), secrets)


def redact_args(args: dict, secrets=()) -> dict:
    """The parsed options as JSON: callables dropped, secret-named options masked, secret values masked anywhere."""
    return _jsonable({k: v for k, v in (args or {}).items() if not callable(v)}, [s for s in secrets if s])


def _read_rows(p: Path) -> list[dict]:
    rows = []
    if p.exists():
        for line in p.read_text(encoding="utf-8").splitlines():
            if line.strip():
                try:
                    rows.append(json.loads(line))
                except json.JSONDecodeError:
                    rows.append({})                     # verify() reports it; the chain continues from the last good row
    return rows


def append(out_dir, command: str, args: dict | None = None, actor: str = "", actor_source: str = "", outcome: str = "ok",
           exit_code: int = 0, error: str = "", versions: dict | None = None, secrets=(), now=None) -> dict:
    """Append one row under the lock and move the head. A broken chain is not refused (an operator action has already
    happened and must be recorded); `econquest log verify` reports the break."""
    with _locked(out_dir):
        p = log_path(out_dir)
        rows = _read_rows(p)
        last = next((r for r in reversed(rows) if r.get("row_hash")), None)
        prev = last["row_hash"] if last else GENESIS
        row = {"seq": len(rows) + 1, "ts_utc": _ts(now), "command": command, "args": redact_args(args, secrets),
               "actor": mask(str(actor or ""), secrets), "actor_source": actor_source, "outcome": outcome,
               "exit_code": int(exit_code), "error": mask(str(error or ""), secrets)[:2000],
               "versions": _jsonable(versions or {}, secrets), "prev_hash": prev}
        row["row_hash"] = row_hash(prev, row)
        with open(p, "a", encoding="utf-8") as f:
            f.write(json.dumps(row, ensure_ascii=False, sort_keys=False) + "\n"); f.flush(); os.fsync(f.fileno())
        _atomic_write(head_path(out_dir), (json.dumps({"seq": row["seq"], "row_hash": row["row_hash"]}) + "\n").encode())
        return row


def read(out_dir) -> list[dict]:
    return [r for r in _read_rows(log_path(out_dir)) if r]


def tail(out_dir, n: int = 20) -> list[dict]:
    rows = read(out_dir)
    return rows[-n:] if n > 0 else rows


def verify(out_dir) -> dict:
    """seq runs 1..n, each prev_hash is the previous row_hash, each row_hash recomputes, the head names the last row."""
    p = log_path(out_dir)
    errors, rows, prev = [], [], GENESIS
    lines = p.read_text(encoding="utf-8").splitlines() if p.exists() else []
    for i, line in enumerate(lines, 1):
        if not line.strip():
            errors.append(f"line {i}: blank line"); continue
        try:
            r = json.loads(line)
        except json.JSONDecodeError:
            errors.append(f"line {i}: not JSON"); prev = None; continue
        if r.get("seq") != len(rows) + 1:
            errors.append(f"line {i}: seq {r.get('seq')} where {len(rows) + 1} expected (row deleted, inserted or moved)")
        if prev is not None and r.get("prev_hash") != prev:
            errors.append(f"line {i}: prev_hash does not match the previous row (row deleted, inserted or moved)")
        if r.get("row_hash") != row_hash(str(r.get("prev_hash", "")), r):
            errors.append(f"line {i}: row_hash does not recompute (row edited)")
        prev = r.get("row_hash")
        rows.append(r)
    head, hp = None, head_path(out_dir)
    if hp.exists():
        try:
            head = json.loads(hp.read_text())
        except json.JSONDecodeError:
            errors.append(f"{HEAD_NAME} is not JSON")
    elif rows:
        errors.append(f"{HEAD_NAME} missing")
    if isinstance(head, dict):
        last = rows[-1] if rows else {"seq": 0, "row_hash": GENESIS}
        if head.get("seq") != last.get("seq") or head.get("row_hash") != last.get("row_hash"):
            errors.append(f"{HEAD_NAME} names seq {head.get('seq')} but the log ends at seq {last.get('seq')} "
                          "(rows removed from or added to the end)")
    return {"ok": not errors, "rows": len(rows), "head": head, "errors": errors, "path": str(p)}


def format_row(r: dict) -> str:
    a = r.get("args") or {}
    keep = {k: v for k, v in a.items() if v not in (None, False, "", [], {}) and k not in ("cmd", "data", "out")}
    return (f"{r.get('seq', '?'):>5}  {str(r.get('ts_utc', ''))[:19]}  {r.get('outcome', '?')}({r.get('exit_code', '?')})  "
            f"{r.get('actor', '') or '-'}  {r.get('command', '')}  {json.dumps(keep, ensure_ascii=False)}"
            + (f"  error: {r['error'][:160]}" if r.get("error") else ""))
