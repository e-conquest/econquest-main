"""Command line: python -m econquest <command> [options]"""
from __future__ import annotations
import argparse
import os
import json
import sys
from pathlib import Path
import numpy as np
import pandas as pd
from .config import Settings
from .ingestion import load_universe
from .engine import run_pipeline
from .engine.pipeline import dumps
from .engine.stress import load_scenarios, compare, reverse_stress, single_factor_reverse, SINGLE_FACTORS, summarise_shocks
from .validation import backtest_history
from .validation.backtests import synthetic_history
from .persistence import Store
from .presentation import render_dashboard, serve

HERE = Path(__file__).resolve().parent.parent
# ECONQUEST_HOME points at the folder holding data/ and outputs/ when the package is installed
# outside that folder (the macOS installer sets it); otherwise the source checkout is used.
HOME_DIR = Path(os.environ.get("ECONQUEST_HOME", HERE))
DEFAULT_DATA = HOME_DIR / "data"
DEFAULT_OUT = HOME_DIR / "outputs"


TOKEN_ENV = "ECONQUEST_SHEETS_TOKEN"
KEYCHAIN_SERVICE = "econquest-sheets"


def _token_args(p):
    """Sheets credential options for a subcommand that can write the workbook (EQ-C-0002)."""
    p.add_argument("--write", action="store_true", help=f"write the tab(s) to the live workbook, with the token from ${TOKEN_ENV} or the macOS Keychain item '{KEYCHAIN_SERVICE}' (or --token-file). Without --write, or an explicit --token-file, the plan is only saved")
    p.add_argument("--token-file", help="file holding the Google Sheets OAuth token; giving it means write (it wins over the env var and Keychain)")
    p.add_argument("--token", help=f"DEPRECATED: puts the token in the process list and shell history; use --write with ${TOKEN_ENV} or the Keychain, or --token-file")
    p.add_argument("--dry-run", action="store_true", help="save the plan JSON only: never look up a token or call Sheets, even with --write or --token-file")


def _keychain_token() -> str | None:
    """macOS Keychain: `security find-generic-password -s econquest-sheets -w`. Any failure means no token."""
    import shutil
    import subprocess
    exe = shutil.which("security")
    if not exe:
        return None
    try:
        r = subprocess.run([exe, "find-generic-password", "-s", KEYCHAIN_SERVICE, "-w"], capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.SubprocessError):
        return None
    tok = (r.stdout or "").strip()
    return tok if r.returncode == 0 and tok else None


def _read_token_file(path: str) -> str:
    try:
        tok = Path(path).expanduser().read_text(encoding="utf-8").strip()
    except OSError as e:
        raise SystemExit(f"cannot read --token-file {path}: {e.strerror}") from None
    if not tok:
        raise SystemExit(f"--token-file {path} is empty")
    return tok


def resolve_token(args) -> str | None:
    """The Sheets OAuth token, or None (the command then only saves its plan). Ambient credentials never cause a
    live write on their own: the user must ask for it.
      1. --token-file PATH (explicit: means write; beats the env var and Keychain)
      2. --token VALUE (deprecated, warns on stderr; explicit: means write)
      3. --write: $ECONQUEST_SHEETS_TOKEN, then the macOS Keychain item 'econquest-sheets'; none found is an error
      4. otherwise None, and neither the env var nor the Keychain is looked at."""
    legacy = getattr(args, "token", None)
    if legacy:
        print(f"warning: --token is deprecated (the token is visible in the process list and shell history); "
              f"use --write with ${TOKEN_ENV} or the Keychain (service '{KEYCHAIN_SERVICE}'), or --token-file", file=sys.stderr)
    path = getattr(args, "token_file", None)
    if path:
        return _read_token_file(path)
    if legacy:
        return legacy
    if not getattr(args, "write", False):
        return None
    tok = os.environ.get(TOKEN_ENV, "").strip() or _keychain_token()
    if not tok:
        raise SystemExit(f"--write needs a Sheets token: set ${TOKEN_ENV}, add the Keychain item "
                         f"(security add-generic-password -s {KEYCHAIN_SERVICE} -a \"$USER\" -w) or pass --token-file")
    return tok


def _load(args):
    s = Settings.load(Path(args.data) / "assumptions.json", paths=getattr(args, "paths", None), seed=getattr(args, "seed", None),
                      scenario_override=getattr(args, "override", None))
    if getattr(args, "no_sobol", False):
        s.use_sobol = False
    vintage = getattr(args, "vintage", None)
    if vintage and getattr(args, "live_markets", False):
        raise SystemExit("--vintage replays frozen inputs; it cannot be combined with --live-markets")
    if vintage:
        u = load_universe(args.data, live_markets=False, vintage=vintage)
        rp = (getattr(u, "provenance", None) or {}).get("replay") or {}
        print(f"Replaying vintage {rp.get('vintage_id', vintage)} (inputs_hash {rp.get('inputs_hash', '?')})")
        if rp.get("drift"):
            print(f"warning: files not frozen with the vintage changed since it was applied, so this is not an exact replay: {', '.join(map(str, rp['drift']))}", file=sys.stderr)
    else:
        u = load_universe(args.data, live_markets=getattr(args, "live_markets", False))
    return u, s


def _as_of_arg(text: str) -> str:
    """argparse type for --as-of: a YYYY-MM-DD date, normalised. A year before 1000 is refused: strftime writes it
    with fewer than four digits ("1-01-01"), which resolve_as_of then read as 2001-01-01 (SEC-C-009)."""
    try:
        out = pd.Timestamp(text).strftime("%Y-%m-%d")
    except (ValueError, TypeError):
        out = ""
    if len(out) != 10 or not out[:4].isdigit():
        raise argparse.ArgumentTypeError(f"not a date (YYYY-MM-DD): {text!r}") from None
    return out


def _vintage_date(u) -> str | None:
    """The date of the replayed vintage (vintage ids start YYYY-MM-DD), or None when the universe is not a replay."""
    vid = str(((getattr(u, "provenance", None) or {}).get("replay") or {}).get("vintage_id") or "")
    try:
        return _as_of_arg(vid[:10]) if len(vid) >= 10 and vid[4] == "-" and vid[7] == "-" else None
    except argparse.ArgumentTypeError:
        return None


def cmd_run(args):
    u, s = _load(args)
    as_of = getattr(args, "as_of", None)
    res = run_pipeline(u, s, label=args.label, as_of=as_of, market_dir=args.data)   # HO-20261024-B-C-002
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    store = Store(out / "store"); store.save_rulebook(u.rulebook); store.save_run(res, keep_paths=not args.no_paths)
    res.country.to_csv(out / "country_risk.csv"); res.positions.to_csv(out / "positions.csv")
    res.mc.contributions.to_csv(out / "contributions.csv"); res.arbitrage.to_csv(out / "arbitrage.csv", index=False)
    res.correlation.round(4).to_csv(out / "latent_correlation.csv")
    (out / "run_latest.json").write_text(dumps(res.to_dict()))
    # trade-idea log (HO-20261023-B-C-010): base run only; a --vintage replay is a past date and the log only moves forward
    if not str(args.label).startswith("stress-") and not getattr(args, "vintage", None):
        from .engine.garch import load_prices
        from .validation import idea_log
        px = u.prices if getattr(u, "prices", None) is not None else load_prices(args.data)
        _idea_hook("run", idea_log.log_run, res, u, s, px, out)
    stress = None; bt = None
    if args.stress:
        stress = {}
        scen = load_scenarios(Path(args.data) / "scenarios.json")
        keys = [k.upper() for k in args.scenario] if getattr(args, "scenario", None) else [k for k, sc in scen.items() if sc.kind != "historical"]
        for k in keys:
            sc = scen[k]
            u2, s2 = sc.apply(u, s)
            r2 = run_pipeline(u2, s2, label=f"stress-{k}", paths=args.stress_paths, as_of=as_of, market_dir=args.data)
            store.save_run(r2, keep_paths=False)
            stress[k] = {"name": sc.name, "description": sc.description, "comparison": compare(res, r2)}
        (out / "stress.json").write_text(dumps(stress))
    if args.backtest:
        hist = pd.read_csv(Path(args.data) / "backtest_history.csv") if (Path(args.data) / "backtest_history.csv").exists() else \
            synthetic_history(res.mc.losses, res.metrics["var99_mm"], res.metrics["es99_mm"], as_of=res.settings.get("as_of"))   # VF-006: replayable dates
        bt = backtest_history(hist, alpha=0.99); (out / "backtest.json").write_text(dumps(bt))
    from .presentation.mc_band import load_book_limits    # EQ-C-0055: limit verdicts with the MC band on the dashboard
    limits = load_book_limits(args.data)
    (out / "dashboard.html").write_text(render_dashboard(res.to_dict(), stress, bt, limits=limits))
    print(dumps(res.summary()))
    if stress:
        for k, v in stress.items():
            c = v["comparison"]
            print(f"Scenario {k} {v['name']}: ES99 {c['es99_mm']['base']:.1f} -> {c['es99_mm']['stress']:.1f} ({c['es99_mm']['change_pct']:+.1f}%), "
                  f"L-VaR99 {c['lvar99_mm']['stress']:.1f}, liquidity cost {c['liquidity_cost99_mm']['change_pct']:+.1f}%, moved to Crisis {c['share_to_crisis']*100:.0f}%")
    if bt:
        print(f"Backtest: {bt['verdict']} (Kupiec p={bt['kupiec']['p_value']:.3f}, Christoffersen cc p={bt['christoffersen']['p_value_cc']:.3f}, Z2={bt['acerbi_szekely']['Z2']:.3f}, zone {bt['basel_zone']})")
    print(f"Outputs in {out}")
    from .presentation.dashboard import run_headline   # EQ-C-0048: the decision numbers, with units, as the last line
    print(run_headline(res.summary(), limits=limits))


def cmd_stress(args):
    u, s = _load(args)
    scen = load_scenarios(Path(args.data) / "scenarios.json")
    base = run_pipeline(u, s, label="base", paths=args.paths, market_dir=args.data)   # HO-20261024-B-C-002
    rows = []
    for k in (args.scenario or list(scen)):
        sc = scen[k.upper()]
        u2, s2 = sc.apply(u, s, scale=args.scale)
        r2 = run_pipeline(u2, s2, label=f"stress-{k}", paths=args.paths, market_dir=args.data)
        cmp_ = compare(base, r2)
        rows.append({"scenario": sc.key, "name": sc.name, "kind": sc.kind, "scale": args.scale, **{m: cmp_[m]["stress"] for m in ("var99_mm", "es99_mm", "lvar99_mm", "expected_loss_mm")},
                     **{m + "_pct": cmp_[m]["change_pct"] for m in ("var99_mm", "es99_mm")}, "to_crisis": cmp_["share_to_crisis"], "mean_pd_pp": cmp_["mean_pd_default_change_pp"]})
        print(f"\n== Scenario {sc.key}: {sc.name} ({sc.kind}, scale {args.scale})\n{sc.description}")
        print(dumps(cmp_))
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    table = pd.DataFrame(rows); table.to_csv(out / "scenario_library.csv", index=False)
    pd.set_option("display.width", 220)
    print(f"\nBase VaR99 {base.metrics['var99_mm']:.1f}, ES99 {base.metrics['es99_mm']:.1f} $mm ({base.metrics['paths']} paths)")
    print(table.round(3).to_string(index=False)); print(f"Written {out / 'scenario_library.csv'}")


def cmd_scenarios(args):
    """List the scenario library (data/scenarios.json) with its shocks."""
    scen = load_scenarios(Path(args.data) / "scenarios.json")
    for sc in scen.values():
        print(f"{sc.key:10s} {sc.name} [{sc.kind}]\n    {sc.description}\n    source: {sc.source or 'n/a'}")
        if args.shocks:
            for line in summarise_shocks(sc.shocks): print(f"      - {line}")


def cmd_reverse_stress(args):
    """Reverse stress (roadmap 3.4): the smallest severity of each scenario, and of each single factor, that breaches a book limit."""
    from .engine import limits as LM
    u, s = _load(args)
    lim = LM.load_limits(Path(args.data) / "limits.json")
    scen = load_scenarios(Path(args.data) / "scenarios.json")
    paths = args.paths or 20000
    base = run_pipeline(u, s, label="rs-base", paths=paths)
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    results = {"measure": args.measure, "limit": lim["book"][args.measure], "paths": paths, "base": float(base.metrics[args.measure]), "scenarios": [], "factors": []}
    print(f"Reverse stress on {args.measure}: base {base.metrics[args.measure]:.2f} vs limit {lim['book'][args.measure]:.2f} $mm ({paths} paths)")
    keys = [k.upper() for k in args.scenario] if args.scenario else list(scen)
    if not args.factors_only:
        for k in keys:
            print(f"\n== Scenario {k}: {scen[k].name}")
            r = reverse_stress(u, s, scen[k], lim, args.measure, paths, scale_max=args.scale_max, base=base, log=print)
            results["scenarios"].append(r)
            if r["breach_scale"] is not None:
                print(f"  -> breaches at scale {r['breach_scale']:.3f} of the scenario ({args.measure} {r.get('value_at_breach', r['base']):.1f}); shocks at that point:")
                for line in r["shocks_at_breach"]: print(f"       {line}")
            else:
                print(f"  -> {r['status']} ({args.measure} {r.get('value_at_max', float('nan')):.1f} at scale {args.scale_max})")
    if not args.scenarios_only:
        for f in (args.factor or list(SINGLE_FACTORS)):
            print(f"\n== Factor {f}: {SINGLE_FACTORS[f]['label']}")
            r = single_factor_reverse(u, s, lim, f, args.measure, paths, base=base, log=print)
            results["factors"].append(r)
            if r["breach_scale"] is not None:
                print(f"  -> breaches at {r['breach_size']:.3g} {r['unit']}")
            else:
                print(f"  -> {r['status']}")
    (out / "reverse_stress.json").write_text(dumps(results))
    rows = [{"kind": "scenario", "key": r["scenario"], "label": r.get("scenario_name", r["scenario"]), "breach_scale": r["breach_scale"], "breach_size": r["breach_scale"], "unit": "x scenario", "status": r["status"]} for r in results["scenarios"]] + \
           [{"kind": "factor", "key": r["factor"], "label": r["label"], "breach_scale": r["breach_scale"], "breach_size": r.get("breach_size"), "unit": r["unit"], "status": r["status"]} for r in results["factors"]]
    pd.DataFrame(rows).to_csv(out / "reverse_stress.csv", index=False)
    print(f"\nWritten {out / 'reverse_stress.json'} and reverse_stress.csv")


def cmd_arbitrage(args):
    u, s = _load(args)
    res = run_pipeline(u, s, paths=20000, market_dir=args.data)
    cols = ["id", "platform", "country", "side", "yes_price", "model_p_res", "net_edge_pp", "kelly", "stake_k", "expected_profit_k", "divergence_flag"]
    pd.set_option("display.width", 200)
    print(res.arbitrage.sort_values("net_edge_pp", ascending=False)[cols].round(3).to_string(index=False))


def cmd_backtest(args):
    hist = pd.read_csv(args.history)
    if "var_next" in hist.columns:                      # a forecast record: use the rows that had a forecast for the day
        from .validation.record import record_for_backtest
        hist = record_for_backtest(hist)
    hist = hist.dropna(subset=["loss", "var", "es"])
    if len(hist) < 20:
        raise SystemExit(f"Only {len(hist)} periods with a realised loss and a forecast; the tests need at least 20 (250 for a meaningful Basel zone).")
    print(dumps(backtest_history(hist, alpha=args.alpha)))


def cmd_record(args):
    """Append today's row to data/forecast_record.csv: realised loss of the book, next-day GARCH-DCC VaR/ES, 12-month MC VaR/ES."""
    import warnings
    from .engine.garch import load_prices
    from .validation.record import take_record, load_record, record_for_backtest
    warnings.filterwarnings("ignore", category=RuntimeWarning)
    u, s = _load(args)
    px = load_prices(args.data)
    if px is None:
        raise SystemExit("No price history: update data/market_history/prices.csv first (econquest prices --sheet-json ...).")
    if args.backfill:
        from .validation.record import backfill_record
        backfill_record(u, s, px, Path(args.data), days=args.backfill, step=args.step)
    else:
        row = take_record(u, s, px, Path(args.data), run_mc=not args.no_mc)
        from .validation import idea_log                  # mark open ideas to the record date; not on --backfill (point in time)
        _idea_hook("record", idea_log.mark_log, Path(args.out or "outputs"), px, row["date"], s)
    rec = load_record(Path(args.data) / "forecast_record.csv")
    bt = record_for_backtest(rec)
    print(f"Record: {len(rec)} rows -> {Path(args.data) / 'forecast_record.csv'}")
    if len(bt) >= 20:
        print(dumps(backtest_history(bt, alpha=0.99)))
    else:
        print(f"{len(bt)} rows with a forecast to test; the backtests start at 20 rows and the Basel zone is meaningful from 250.")
    if args.token:
        from .presentation.sheets_publish import apply_plan
        from .presentation.record_publish import record_plan
        r = apply_plan(record_plan(rec), args.spreadsheet_id, args.token)
        print(f"Wrote {r.get('totalUpdatedCells')} cells to the Forecast Record tab")


def _idea_hook(job: str, fn, *a) -> None:
    """Trade-idea log from a daily job (HO-20261023-B-C-010). Tier 3, illustrative: a failure warns, never fails the job."""
    try:
        fn(*a)
    except Exception as e:                             # noqa: BLE001
        print(f"warning: trade-idea log not updated by {job}: {type(e).__name__}: {e}", file=sys.stderr)


def cmd_ideas(args):
    """Trade-idea log (EQ-B-0038, GOV-032; Tier 3): `log` advances outputs/idea_log.csv by an archived base run, `mark`
    marks open ideas to a trading day, `report` prints outputs/idea_report.md."""
    import re
    from .engine.garch import load_prices
    from .validation import idea_log
    out = Path(args.out)
    if args.ideas_cmd == "report":
        md = out / "idea_report.md"
        if not (out / "idea_log.csv").exists() or not md.exists():
            raise SystemExit(f"No trade-idea log in {out}: run `econquest ideas log` (or `econquest run`) first.")
        print(md.read_text(encoding="utf-8"))
        return
    u, s = _load(args)
    px = load_prices(args.data)
    if args.ideas_cmd == "mark":
        if px is None:
            raise SystemExit("No price history: update data/market_history/prices.csv first (econquest prices --sheet-json ...).")
        from .validation.record import complete_date, _weekdays
        as_of = args.as_of or complete_date(_weekdays(px))      # the trading day the forecast record uses
        idea_log.mark_log(out, px, as_of, s)
        return
    store = Store(out / "store")
    if args.run_id and not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]*", args.run_id):    # a file name in store/archive, no path
        raise SystemExit(f"not a run id: {args.run_id!r}")
    try:
        d = store.load(args.run_id) if args.run_id else store.latest("base")
    except FileNotFoundError:
        raise SystemExit(f"Run {args.run_id} is not archived in {out / 'store'} (econquest runs lists them).") from None
    if d is None:
        raise SystemExit(f"No base run archived in {out / 'store'}: run `econquest run` first.")
    label = str(d["summary"].get("label") or "")
    if label.startswith("stress-"):
        raise SystemExit(f"Run {d['summary']['run_id']} is a stress run ({label}); the trade-idea log takes base runs only.")
    idea_log.log_run(d, u, s, px, out)


def cmd_prices(args):
    """Update data/market_history/prices.csv from saved Sheets API values of the Market History tab."""
    from .ingestion.market_history import update_prices_from_sheet_json
    out, summary = update_prices_from_sheet_json(args.sheet_json, args.data)
    print(f"{out}: {summary}")


def cmd_runs(args):
    """List archived runs with their code and data versions."""
    store = Store(Path(args.out) / "store")
    rows = []
    for r in store.runs(limit=args.limit):
        s = r["summary"]; m = s.get("metrics", {}); v = s.get("versions", {})
        rows.append({"run_id": r["run_id"], "label": r["label"], "created": r["created_at"][:19], "var99": m.get("var99_mm"), "es99": m.get("es99_mm"),
                     "regime": s.get("global_regime"), "code": v.get("code_hash", ""), "data": v.get("data_hash", ""),
                     "vintage": v.get("vintage_id") or "", "inputs": v.get("inputs_hash") or ""})
    print(pd.DataFrame(rows).round(2).to_string(index=False) if rows else "No runs archived yet.")


def cmd_fit_hazard(args):
    """Recalibrate the layer-1 hazard model on a sovereign default panel (roadmap 2.3).

    --panel <csv>        a ready country-year panel with the feature columns and `event`
    --build-panel        build it from WEO (and World Bank) history + the default episode table
    --fetch              pull every WEO release and World Bank series first (ingestion.panel_history: staged, resumable,
                         point in time; needs network); an incomplete pull exits 1 and leaves the history files untouched
    --resume RUN_ID      with --fetch: resume that staged run, refetching only the units still missing
    --defaults <file>    an episode CSV (default data/panel/sovereign_defaults.csv, including import_crag output) or the
                         CRAG workbook / Valet CSV (2026 long layout)
    --apply              propose (econquest change) the fitted coefficients for assumptions.json (layer1_fitted) and the switch
                         of layer1.mode to "fitted" when hazard_panel.gate_check clears (OOS AUC >= --min-auc, >= --min-events
                         events, Brier strictly below the trailing base rate); needs --author, and the change lands only after
                         approve + apply"""
    from .validation import hazard_panel as hp
    if args.apply and not args.author:
        raise SystemExit("fit-hazard --apply proposes a Tier 1 change and needs --author NAME")
    if (args.resume or args.weo_vintages) and not args.fetch:
        raise SystemExit("--resume and --weo-vintages only apply with --fetch")
    data = Path(args.data); out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    features = [f.strip() for f in args.features.split(",")] if args.features else None
    source = {}
    if args.panel and not args.build_panel:
        panel = pd.read_csv(args.panel, dtype={"iso": str})
        source["panel_file"] = str(args.panel)
    else:
        dfile = Path(args.defaults) if args.defaults else data / "panel" / "sovereign_defaults.csv"
        events = hp.load_events(dfile)
        end = args.end if args.end is not None else int(max(events["end"].max(), events["start"].max())) - 1
        source["default_episodes"] = f"{dfile.name} ({len(events)} spells, {events['iso'].nunique()} countries)"
        hist = data / "panel"
        hist.mkdir(parents=True, exist_ok=True)
        if args.fetch:
            from .ingestion import panel_history as ph
            try:
                vint = ph._parse_vintage_arg(args.weo_vintages) if args.weo_vintages else None
                m = ph.fetch_history(hist, weo_vintages=vint, run_id=args.resume, log=print)
            except ph.IncompleteFetchError as e:
                print(f"INCOMPLETE: {e}", file=sys.stderr)
                for unit in e.missing:
                    print(f"  {unit}: {e.manifest['units'][unit].get('error', '')}", file=sys.stderr)
                raise SystemExit(1) from None
            except (ValueError, FileNotFoundError) as e:
                raise SystemExit(f"fit-hazard --fetch: {e}") from None
            fin = m.get("final", {})
            source["panel_history"] = (f"run {m.get('run_id')}, panel vintage {m.get('panel_vintage', '(not saved)')}; "
                                       + ", ".join(f"{k} sha256 {v['sha256'][:16]}" for k, v in fin.items()))
        weo_path = hist / "weo_history.csv" if (hist / "weo_history.csv").exists() else data / "live" / "raw_weo.csv"
        if not weo_path.exists():
            raise SystemExit("no WEO history: run with --fetch on a machine that reaches api.imf.org, or run `econquest fetch` first")
        weo = pd.read_csv(weo_path, dtype={"iso": str, "series": str, "vintage": str})
        wbh = pd.read_csv(hist / "worldbank_history.csv", dtype={"iso": str, "series": str}) if (hist / "worldbank_history.csv").exists() else None
        source["weo_history"] = f"{weo_path.name} ({weo['iso'].nunique()} economies, {int(weo['period'].min())}-{int(weo['period'].max())})"
        source["worldbank_history"] = f"worldbank_history.csv ({wbh['iso'].nunique()} economies)" if wbh is not None else "none (World Bank features not available)"
        if features is None:
            features = list(hp.DEFAULT_FEATURES) + ([f for f in ("stfx_debt_reserves", "reserves_months_imports", "pitf_instability")] if wbh is not None else [])
        panel = hp.panel_from_long(weo, wbh, events, features=features, start=args.start, end=end, forecast_cutoff=end)
        panel.to_csv(hist / "hazard_panel.csv", index=False)
        print(f"panel: {len(panel):,} country-years at risk, {int(panel['event'].sum())} default starts, {panel['iso'].nunique()} countries -> {hist / 'hazard_panel.csv'}")
    res = hp.fit_and_validate(panel, features=features, oos_start=args.oos_start)
    res.panel_source = source
    gate = hp.gate_check(res, args.min_auc, args.min_events); ok = gate["cleared"]
    rep = hp.write_report(res, args.report or (data.parent / "docs" / "validation" / "hazard-fit-report.md"), panel=panel, gate=gate,
                          notes=["Pilot panels built from the 18-country live vintage are too thin for production use; the full panel needs `--fetch`."] if panel["iso"].nunique() < 40 else None)
    (out / "hazard_fit.json").write_text(dumps(res.fitted_block()))
    o = res.out_of_sample
    print(dumps({"coef": res.coef, "intercept": res.intercept, "in_sample_auc": res.in_sample["auc"], "out_of_sample": o}))
    print(f"report: {rep}")
    print(f"gate: {hp.gate_summary(gate)}")
    if args.apply:
        # A layer-1 recalibration is a Tier 1 change: --apply proposes it through `econquest change` (EQ-C-0023)
        # instead of writing assumptions.json, so it needs an approver (or a self-approval under an EXC) before it lands.
        from .ops import approvals as ap
        patch = {"/layer1_fitted": res.fitted_block()}
        if ok:
            patch["/layer1/mode"] = "fitted"
        else:
            print(f"NOT proposing the switch to fitted: gate {hp.gate_summary(gate)}; proposing the coefficients under layer1_fitted only")
        try:
            prop = ap.propose(data, "assumptions.json", json.loads(dumps(patch)), args.author,
                              f"fit-hazard: OOS AUC {o.get('auc', float('nan')):.3f}, {res.events} events", allow_new_keys=True,
                              allow_type_change=True)   # the fitted block is regenerated wholesale
        except ap.ApprovalError as e:
            raise SystemExit(f"fit-hazard --apply: {e}") from None
        print(f"proposed {prop['id']} (tier {prop['tier']}): approve with `econquest change approve {prop['id']} --approver NAME` "
              f"(or --self-approved --exc EXC-nnn), then `econquest change apply {prop['id']}`")


def cmd_cds(args):
    """CDS-implied PD term structure and bond relative value from data/cds_quotes.csv (roadmap 3.3)."""
    from .engine import cds
    from .engine.pipeline import run_pipeline
    u, s = _load(args)
    qpath = Path(args.data) / "cds_quotes.csv"
    quotes = pd.read_csv(qpath) if qpath.exists() else pd.DataFrame(columns=["country", "date", "tenor_y", "spread_bp", "recovery", "source"])
    if quotes.empty:
        print(f"no CDS quotes in {qpath}: add rows (country,date,tenor_y,spread_bp,recovery,source) and rerun")
        return
    cfg = s.get("cds", default={}) or {}
    r = run_pipeline(u, s, paths=min(s.paths, 20000), market_dir=args.data)
    pd12 = r.country["pd_default"]          # indexed by country name
    table = cds.cds_table(quotes, pd12, recovery=cfg.get("recovery", 0.4), rate=cfg.get("risk_free", 0.04), freq=int(cfg.get("frequency", 4)))
    rv = cds.eurobond_relative_value(u.portfolio, table)
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    table.to_csv(out / "cds_implied.csv", index=False); rv.to_csv(out / "cds_relative_value.csv", index=False)
    print(table.round(4).to_string(index=False)); print(); print(rv.round(1).to_string(index=False) if len(rv) else "no Eurobond or CDS positions with quotes")


def cmd_benchmark(args):
    """PD benchmarks (roadmap 2.6): model PD beside rating, spread, CDS and prediction-market probabilities; dated history and scoring."""
    from .validation import benchmarks as bm
    from .validation.hazard_panel import load_default_events
    from .engine import cds
    from .presentation.sheets_publish import save_plan, apply_plan
    u, s = _load(args)
    data = Path(args.data); out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    r = run_pipeline(u, s, paths=args.paths or min(s.paths, 20000), market_dir=args.data)
    cds_table = None
    qpath = data / "cds_quotes.csv"
    if qpath.exists():
        quotes = pd.read_csv(qpath)
        if len(quotes):
            cfg = s.get("cds", default={}) or {}
            cds_table = cds.cds_table(quotes, r.country["pd_default"], recovery=cfg.get("recovery", 0.4), rate=cfg.get("risk_free", 0.04), freq=int(cfg.get("frequency", 4)))
    versions = (r.summary() if callable(getattr(r, "summary", None)) else {}).get("versions", {}) if hasattr(r, "summary") else {}
    snap = bm.benchmark_snapshot(r.country, cds_table, as_of=args.as_of, versions=versions or u.provenance.get("versions", {}))
    hist = bm.append_history(data / "benchmarks.csv", snap)
    epath = data / "panel" / "sovereign_defaults.csv"
    events = load_default_events(epath) if epath.exists() else pd.DataFrame(columns=["iso", "start", "end"])
    as_of = snap["date"].iloc[0]                                   # the snapshot's as-of (from --as-of, else today once)
    scores = bm.score_sources(bm.outcomes(hist, events, as_of=as_of))      # VF-006 (HO-20261023-B-C-016): same date as today= before
    try:
        horizons = {h.strip(): int(h.strip()[:-1]) for h in args.horizons.split(",") if h.strip()}
    except ValueError:
        raise SystemExit(f"--horizons: expected a comma list like 12m,6m,3m, got {args.horizons!r}") from None
    full = bm.score_benchmarks(hist, events, as_of=as_of, horizons=horizons)
    paths = bm.write_benchmark_scores(full, out)
    print(f"benchmark scoring as of {as_of}: " + "; ".join(f"{k} {v}" for k, v in full.status.items()) + f" ({paths['scores']})")
    dis = bm.disagreement_table(snap)
    print(dis.round(4).to_string(index=False)); print()
    scored = int(scores["rows"].max()) if len(scores) else 0
    print(scores.round(4).to_string(index=False) if scored else f"no snapshot is 12 months old yet ({len(hist)} rows in data/benchmarks.csv); scoring starts then")
    plan = bm.benchmarks_plan(snap, scores, len(hist))
    save_plan(plan, out / "benchmarks_plan.json"); dis.to_csv(out / "benchmarks_snapshot.csv", index=False); scores.to_csv(out / "benchmarks_scores.csv", index=False)
    if args.token:
        print("Written:", apply_plan(plan, args.spreadsheet_id, args.token))


def cmd_hmm(args):
    from .engine.layer3_regime import GaussianHMM
    if args.series:
        X = pd.read_csv(args.series).select_dtypes(include=[np.number]).to_numpy()
    else:
        rng = np.random.default_rng(3)                       # demo: synthetic calm / stressed / crisis monthly data
        states = [0]
        P = np.array([[0.95, 0.04, 0.01], [0.10, 0.85, 0.05], [0.05, 0.20, 0.75]])
        for _ in range(239):
            states.append(rng.choice(3, p=P[states[-1]]))
        mu = np.array([[150, 0.5, 0.5], [500, 4, -3], [1500, 15, -10]]); sd = np.array([[60, 1.5, 2], [150, 3, 4], [500, 8, 6]])
        X = np.array([rng.normal(mu[s_], sd[s_]) for s_ in states])
    m = GaussianHMM().fit(X)
    st = m.decode(X)
    print(dumps({"means (spread bps, fx 3m %, reserves 3m %)": m.mu.round(2), "monthly_transition": m.A.round(3), "twelve_month_transition": m.transition_matrix_12m().round(3),
                 "last_state": GaussianHMM.labels(st[-1:])[0], "state_counts": {str(int(k)): int(v) for k, v in zip(*np.unique(st, return_counts=True))}}))


def cmd_publish(args):
    """Run the pipeline and write every model output into the workbook as values (or save the plan)."""
    from .presentation.sheets_publish import build_plan, save_plan, apply_plan
    u, s = _load(args)
    res = run_pipeline(u, s, label="publish", market_dir=args.data)
    hist_path = Path(args.data) / "backtest_history.csv"
    hist = pd.read_csv(hist_path) if hist_path.exists() else None
    ideas = None
    if getattr(args, "ideas", False):                     # opt-in: the 'Trade Ideas' tab must exist in the workbook (EQ-C-0047)
        from .presentation.ideas_view import ideas_summary
        ideas = ideas_summary(Path(args.out))
    rv = None
    if getattr(args, "rv", False):                        # opt-in: the 'Weekly RV' tab must exist, widened to AN (EQ-C-0046)
        from .presentation.rv_view import rv_summary
        rv = rv_summary(Path(args.out))
    plan = build_plan(res, u, s, hist, mc_rows=args.mc_rows, ideas=ideas, rv=rv)
    from .engine.garch import load_prices, run_garch
    px = load_prices(args.data)
    if px is not None and not args.no_garch:
        from .presentation.garch_publish import garch_plan
        g = run_garch(u, px, s, u.gpr)
        plan += garch_plan(g, u)
        if not args.no_econ:
            from .engine.econometrics import run_econometrics
            from .presentation.econ_publish import econ_plan
            from .scorecard import score_universe
            plan += econ_plan(run_econometrics(u, px, g, s, u.gpr, score_universe(u, s).composite, log=lambda *a: None))[0]
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    save_plan(plan, out / "publish_plan.json")
    cells = sum(len(b["values"]) * max(len(r) for r in b["values"]) for b in plan)
    print(f"Publish plan: {len(plan)} ranges, about {cells:,} cells -> {out / 'publish_plan.json'}")
    if args.token:
        r = apply_plan(plan, args.spreadsheet_id, args.token)
        print(f"Wrote {r.get('totalUpdatedCells')} cells to {args.spreadsheet_id}")
    else:
        # with --dry-run the command wrapper prints its own "Dry run: ..." line, so say it once (EQ-C-0048)
        print(("Plan saved" if getattr(args, "dry_run", False) else "No --write given: plan saved only (pass --write to write the workbook)") + ". Apply it with any Sheets client (values:batchUpdate, USER_ENTERED), or preview it first with `econquest publish-preview`.")


def cmd_fetch(args):
    """Pull live inputs from IMF WEO, World Bank and BIS, with FX from BIS WS_XRU and the ECB euro reference rates (EXR);
    save under data/live; optionally apply. Yahoo Finance is not a desk feed (EQ-A-0040): `--only yahoo` exits with
    feeds.fetch_all's one-line refusal before any request (HO-20261024-A-C-002)."""
    from .ingestion.feeds import fetch_all, diff_against_seed, save_report, apply_report, quality_gate, save_vintage
    from .ingestion.ledger import write_review, check_approval
    if args.apply and args.force:                         # fail before any network call (four-eyes, SEC-A-001)
        try:
            check_approval(args.author, args.approver, args.self_approved)
        except ValueError as e:
            raise SystemExit(f"fetch --apply --force: {e}. Pass --author NAME and --approver OTHER, or --author NAME --self-approved (single-operator mode, recorded as self_approved=yes).") from None
    u, _ = _load(args)
    only = [x.strip() for x in args.only.split(",")] if args.only else None
    wv = tuple(args.weo_version.split(",")) if args.weo_version else None
    if wv:
        wv = (wv[0], int(wv[1]))
    try:
        rep = fetch_all(u, only=only, year=args.year, weo_version=wv)
    except ValueError as e:                               # e.g. --only yahoo: refused before any request (EQ-A-0040)
        raise SystemExit(f"fetch: {' '.join(str(e).split())}") from None
    diff = diff_against_seed(u, rep)
    live = save_report(rep, Path(args.data), diff)
    # data_dir enables the vintage-to-vintage check (HO-20261023-A-C-009); before save_vintage so the latest saved
    # vintage is the previous pull
    review = quality_gate(u, rep, diff, max_rel_change=args.max_change, year=args.year, data_dir=Path(args.data))
    review = write_review(Path(args.data), review)        # atomic; keeps ledger decisions (EQ-A-0006)
    vintage = save_vintage(Path(args.data), rep, review)
    ok = [k for k, v in rep.feeds.items() if v.startswith("ok")]
    print("Feeds: " + "; ".join(f"{k}: {v}" for k, v in rep.feeds.items()))
    filled = int(rep.indicators.notna().sum().sum()) + int(rep.profile.notna().sum().sum())
    print(f"Live cells: {filled} ({len(diff)} compared with seed) -> {live}; vintage kept in {vintage}")
    if len(diff):
        big = diff.loc[diff["change"].abs().sort_values(ascending=False).index].head(args.top)
        print(big.to_string(index=False))
    held = review[review["status"] == "hold"]; missing = review[review["status"] == "missing"]
    print(f"Quality gate: {int((review['status'] == 'ok').sum())} ok, {len(held)} held for review, {len(missing)} missing (details in {live / 'review.csv'})")
    if len(held):
        print(held[["table", "key", "country", "seed", "live", "reason"]].head(args.top).to_string(index=False))
    _missing_cells(Path(args.data))
    if args.apply:
        if not ok:
            print("Nothing applied: no feed succeeded.")
        else:
            try:
                res = apply_report(rep, Path(args.data), review=review, force=args.force, vintage_id=vintage.name,
                                   author=args.author, approver=args.approver, self_approved=args.self_approved)
            except ValueError as e:
                raise SystemExit(f"Nothing applied: {e}") from None
            print("Applied:", res)
            if len(held) and not args.force:
                print(f"{len(held)} held cells were not applied; check review.csv and rerun with --force to apply them too.")


def _missing_cells(data_dir: Path) -> None:
    """Missing-country report on every pull (HO-20261023-A-C-014, epic A6): summary, countries below the live target and
    <data>/live/missing_cells.csv. A report that cannot be built warns; the fetch carries on."""
    try:
        from .ingestion.universe import missing_cell_report
        rep = missing_cell_report(data_dir)
        path = data_dir / "live" / "missing_cells.csv"
        rep.cells.to_csv(path, index=False)
        low = rep.countries[~rep.countries["meets_target"].astype(bool)]
        below = ", ".join(f"{r.country} {r.pct_live:.0%}" for r in low.itertuples(index=False))
    except Exception as e:                             # noqa: BLE001 - the pull and the gate matter more than the report
        print(f"warning: missing-cell report not written: {type(e).__name__}: {e}", file=sys.stderr)
        return
    print("Missing cells: " + json.dumps(rep.summary, default=str))
    print(f"Countries below the {float(rep.summary.get('target', 0)):.0%} live target: {len(low)} of {len(rep.countries)}"
          + (f": {below}" if below else "") + f" (cells in {path})")


def _market_gate(d: Path, as_of: str | None):
    """(review, latest market) for `market gate` and `market cds-quotes` (HO-20261023-A-C-015): Team A's
    cds_export.market_gate_review, which seeds the gate only from earlier rows that passed it and the attestation check,
    so a re-saved held quote is held again (SEC-A-003 L5, HO-20261023-A-C-019)."""
    from .ingestion.market.cds_export import market_gate_review
    try:
        return market_gate_review(d, as_of)
    except FileNotFoundError as e:
        raise SystemExit(f"market: {e}") from None


def _atomic_csv_write(df: pd.DataFrame, path: Path) -> None:
    """Write df to path through a temp file in the same folder and os.replace, so a reader never sees half a file."""
    import tempfile
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", newline="", encoding="utf-8") as f:
            df.to_csv(f, index=False)
        os.chmod(tmp, 0o644); os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


def cmd_market(args):
    """Market data (HO-20261023-A-C-015, Team A's econquest/ingestion/market/): import a vendor CSV export, enter attested
    hand-typed quotes, run the market quality gate, and write data/cds_quotes.csv from the latest snapshot minus held series.
    Runbook: docs/runbooks/A-market-data.md."""
    from .ingestion.market import MarketDataError
    d = Path(args.data)
    try:
        if args.market_cmd == "import":
            from .ingestion.market.importers import ensure_ticker_map, import_and_save
            if args.init_map:
                print(f"Ticker map: {ensure_ticker_map(d)} (created from the template if missing, never overwritten). "
                      "Check each row against a real export and set status=verified.")
                return
            if not (args.file and args.profile and args.licence):
                raise SystemExit("market import: needs --profile bloomberg|lseg, --licence TEXT and the CSV file (or --init-map)")
            folder = import_and_save(d, args.file, args.profile, args.licence, mapping=args.map)
            man = json.loads((folder / "manifest.json").read_text(encoding="utf-8"))
            print(f"Saved snapshot {folder.name}: {man['rows']} quotes ({', '.join(man['instruments'])}), as of {man['asof_min']} to "
                  f"{man['asof_max']}, {man['provenance'].get('skipped_missing', 0)} missing values skipped -> {folder}")
        elif args.market_cmd == "enter":
            from .ingestion.market.manual import enter_quotes
            try:
                rows = pd.read_csv(args.file, dtype=str, keep_default_na=False)
            except (OSError, pd.errors.ParserError, pd.errors.EmptyDataError) as e:
                raise SystemExit(f"market enter: cannot read {args.file}: {e}") from None
            r = enter_quotes(d, rows, args.author, approver=args.approver, self_approved=args.self_approved, note=args.note or "")
            q = r["rows"]
            print(f"Entered {len(q)} quotes as {r['entry_id']} (author {q['author'].iloc[0]}, approver {q['approver'].iloc[0]}"
                  + (", self-approved" if q["self_approved"].iloc[0] == "yes" else "") + f"); {len(r['attestations'])} attestations; "
                  f"snapshot {Path(r['snapshot']).name}")
        elif args.market_cmd == "cds-snapshots":          # HO-20261023-A-C-017: gated export to data/market/cds_snapshots.csv
            from .ingestion.market.store import export_cds_snapshots
            try:
                rep = export_cds_snapshots(d, [args.snapshot] if args.snapshot else None, dry_run=args.dry_run)
            except FileNotFoundError as e:
                raise SystemExit(f"market cds-snapshots: {e}") from None
            print(rep.summary())
            if len(rep.dropped):
                print(rep.dropped.head(args.top).to_string(index=False))
        else:                                   # gate, cds-quotes
            from .ingestion.market.gate import series_key
            review, cur = _market_gate(d, args.asof)
            held = review[review["status"] == "hold"]
            flags = review[(review["status"] != "hold") & review["reason"].str.contains("flag:", regex=False)]
            print(f"Market gate{' as of ' + args.asof if args.asof else ''}: {int((review['status'] == 'ok').sum())} ok, {len(held)} held, "
                  f"{len(flags)} flagged ({len(review)} series)")
            if len(held) or len(flags):
                print(pd.concat([held, flags])[["key", "country", "seed", "live", "status", "reason"]].head(args.top).to_string(index=False))
            if args.market_cmd == "gate":
                out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
                review.to_csv(out / "market_gate.csv", index=False)
                print(f"Review table -> {out / 'market_gate.csv'}")
                if args.strict and len(held):
                    raise SystemExit(1)
                return
            from .ingestion.market import to_cds_quotes
            hold = set(zip(held["key"], held["country"]))
            is_held = pd.Series([(series_key(r), r["iso"]) in hold for _, r in cur.iterrows()], index=cur.index, dtype=bool)
            dropped = int((is_held & (cur["instrument"] == "cds")).sum())
            cds = to_cds_quotes(cur[~is_held], country_names=d / "countries.csv")
            dest = Path(args.dest) if args.dest else d / "cds_quotes.csv"
            if cds.empty:
                raise SystemExit(f"market cds-quotes: no CDS spread quotes left after excluding {dropped} held cds series; {dest} not changed")
            if args.dry_run:
                print(cds.to_string(index=False))
                print(f"Dry run: {len(cds)} rows not written to {dest} ({dropped} held cds series excluded)")
                return
            _atomic_csv_write(cds, dest)
            print(f"Wrote {len(cds)} rows ({cds['country'].nunique()} countries) to {dest}; {dropped} held cds series excluded")
    except (MarketDataError, ValueError, OSError) as e:      # OSError (FileExistsError, a directory as file/--dest): AGENT-09 SEC-C-006 L2
        raise SystemExit(f"market {args.market_cmd}: {e}") from None


VENDOR_EXIT = 2
VENDOR_STATUS_COLUMNS = ["vendor", "package_ok", "licence", "licence_id", "scope", "expiry", "usable"]


def cmd_vendor(args):
    """Licensed vendor adapters (HO-20261023-A-C-021, Team A's econquest/ingestion/market/vendors/, EQ-A-0033): ROADMAP,
    PAID FEATURE, OFF BY DEFAULT. status shows the licence gate without opening a session; test pulls and gates in memory
    (saves nothing); pull saves a snapshot, gates it and runs the gated CDS export. Every refusal (not licensed, bad
    request, session error) prints its message and exits VENDOR_EXIT. No credential is ever an argument: they come only
    from the environment or the OS keychain. Runbook: docs/runbooks/A-licensed-vendors.md."""
    from .ingestion.market import MarketDataError
    from .ingestion.market.vendors import VendorConnectionError, VendorNotLicensed, VendorRequestError, get_adapter, vendor_status
    d = Path(args.data)
    if args.vendor_cmd == "status":
        st = vendor_status(d)
        print("Licensed vendor adapters: paid roadmap feature, off by default (runbook docs/runbooks/A-licensed-vendors.md); no session opened")
        print(st[VENDOR_STATUS_COLUMNS].to_string(index=False))
        for r in st.itertuples(index=False):
            if r.problems:
                print(f"{r.vendor}: {r.problems}")
        return
    if args.vendor_cmd == "pull" and args.asof and (args.start or args.end):
        print("vendor pull: --as-of cannot be combined with --start/--end", file=sys.stderr)
        raise SystemExit(VENDOR_EXIT)
    if args.vendor_cmd == "pull" and bool(args.start) != bool(args.end):
        print("vendor pull: --start and --end go together", file=sys.stderr)
        raise SystemExit(VENDOR_EXIT)
    from .ingestion.market.vendors.pipeline import pull_to_store
    try:
        adapter = get_adapter(args.vendor, data_dir=d)          # a fresh adapter per invocation: an adapter connects only once
        if args.vendor_cmd == "test":
            res = pull_to_store(adapter, d, args.ticker, as_of=args.asof, dry_run=True)
            print(res.summary())
            print(res.rows.to_string(index=False) if len(res.rows) else "No quotes returned.")
            if len(res.review):
                print(res.review.to_string(index=False))
            return
        res = pull_to_store(adapter, d, args.ticker, args.field or None, start=args.start, end=args.end, as_of=args.asof,
                            dry_run=False, export_cds=not args.no_export)
        print(res.summary())
        if res.cds_export is not None and len(res.cds_export.dropped):
            print(res.cds_export.dropped.to_string(index=False))
    except (VendorNotLicensed, VendorRequestError, VendorConnectionError, MarketDataError, OSError) as e:   # OSError: as market (SEC-C-006 L2)
        print(f"vendor {args.vendor_cmd}: {e}", file=sys.stderr)
        raise SystemExit(VENDOR_EXIT) from None


def cmd_targets(args):
    """Target-state scorecard (EQ-C-0061, PI-5): re-scores the plan's target-state table and gate criteria from evidence
    (presentation/targets.py) and writes targets.md and targets.csv. Read-only on data/; nothing is scored by hand."""
    from .presentation import targets as T
    df = T.target_scorecard(args.data, args.out, tests_file=args.tests)
    md, csv = T.write_scorecard(df, Path(args.dest) if args.dest else Path(args.out) / "targets")
    counts = df["met"].value_counts().to_dict()
    print(df[["id", "target", "current", "met"]].to_string(index=False))
    print("Target-state scorecard: " + ", ".join(f"{counts.get(m, 0)} {m}" for m in T.MET) + f" (of {len(df)}) -> {md}, {csv}")


def cmd_evidence_clock(args):
    """Evidence clock (EQ-C-0068, HO-20261024-B-C-001): Team B's calendar-gated evidence monitor (250-day forecast record,
    12-month benchmark scoring, trade-idea quarters) as of --as-of (default: settings as_of, else today). Read-only;
    --write saves <out>/evidence_monitor.csv and .md. Named evidence-clock: `evidence` is the EQ-C-0060 bundle."""
    from .presentation.evidence_view import default_as_of
    from .validation.evidence_monitor import evidence_monitor, monitor_markdown, write_monitor
    as_of = default_as_of(args.data, args.as_of)
    table = evidence_monitor(as_of, data_dir=args.data, out_dir=args.out)
    print(monitor_markdown(table), end="")
    if args.write:
        csv, md = write_monitor(table, args.out)
        print(f"Evidence clock written: {csv}, {md}")


def cmd_attest(args):
    """Attest hand-entered cells (adjustments, cds_quotes, prediction_markets) in the review ledger (EQ-A-0018), or --list
    the cells whose current content is not attested. Four-eyes: --approver OTHER, or --self-approved."""
    from .ingestion.ledger import attest_cells, unattested_cells
    d = Path(args.data)
    if args.list:
        try:
            cells = unattested_cells(d, [args.file] if args.file else None)
        except ValueError as e:
            raise SystemExit(f"attest: {e}") from None
        if not cells:
            print("All hand-entered cells are attested." if not args.file else f"All cells of {args.file} are attested.")
            return
        print(pd.DataFrame(cells)[["table", "key", "country", "value"]].to_string(index=False))
        print(f"{len(cells)} unattested hand-entered cells")
        return
    if not args.file or not args.author:
        raise SystemExit("attest: --file and --author are required (or use --list)")
    try:
        rows = attest_cells(d, args.file, args.author, approver=args.approver, self_approved=args.self_approved,
                            note=args.note or "", all_cells=args.all)
    except ValueError as e:
        raise SystemExit(f"attest: {e}") from None
    print(f"Attested {len(rows)} cells of {args.file}.csv (author {args.author}, approver {rows[0]['approver'] if rows else args.approver or '-'})")


def cmd_audit(args):
    """Audit trail: one row per Inputs / Country Profile cell with origin, source, series, transform, vintage and gate decision."""
    from .ingestion.audit import build_audit_trail, audit_summary, audit_plan
    from .presentation.sheets_publish import save_plan, apply_plan
    df = build_audit_trail(args.data)
    out_csv = Path(args.data) / "audit_trail.csv"
    df.to_csv(out_csv, index=False)
    plan = audit_plan(df)
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    save_plan(plan, out / "audit_plan.json")
    print(f"Audit trail: {len(df)} cells -> {out_csv}; workbook plan -> {out / 'audit_plan.json'}")
    print(audit_summary(df).to_string(index=False))
    if "attested" in df.columns:
        n = int((df["attested"].astype(str) == "no").sum())
        if n:
            print(f"{n} hand-entered cells are not attested: see `econquest attest --list`")
    if args.token:
        print("Written:", apply_plan(plan, args.spreadsheet_id, args.token))


def cmd_garch(args):
    """GARCH(1,1)-t per FX pair and ETF, DCC correlations, GARCH-DCC portfolio VaR, option fair values, GPR volatility."""
    from .engine.garch import run_garch, load_prices
    from .presentation.garch_publish import garch_plan, garch_tables
    from .presentation.sheets_publish import save_plan, apply_plan
    u, s = _load(args)
    px = load_prices(args.data)
    if px is None:
        raise SystemExit("No price history: export the Market History tab to data/market_history/prices.csv (date index, one column per ticker).")
    quotes = None
    if args.quotes:
        q = pd.read_csv(args.quotes); quotes = dict(zip(q.iloc[:, 0].astype(str), pd.to_numeric(q.iloc[:, 1], errors="coerce")))
    # VF-007 (HO-20261023-B-C-016): fit no price after --as-of; a --vintage replay defaults to the vintage's date; neither
    # given -> run_garch falls back to settings as_of, else every row (unchanged)
    as_of = getattr(args, "as_of", None) or (_vintage_date(u) if getattr(args, "vintage", None) else None)
    if as_of:
        print(f"GARCH fitted on prices dated on or before {as_of}")
    g = run_garch(u, px, s, u.gpr, quotes=quotes, as_of=as_of)
    out = Path(args.out) / "garch"; out.mkdir(parents=True, exist_ok=True)
    for name, df in garch_tables(g).items():
        df.to_csv(out / f"{name}.csv", index=name.startswith("dcc") or name == "vol_history")
    plan = garch_plan(g, u)
    save_plan(plan, out / "garch_plan.json")
    cols = ["country", "kind", "ticker", "persistence", "nu", "cond_vol_pct", "fcst_21d_vol_pct", "realized_60d_vol_pct", "var99_1d_pct", "exposure_mm", "var99_10d_mm", "vol_target_scalar"]
    print(g.series[cols].round(3).to_string(index=False))
    p = g.portfolio
    print(f"\nGARCH-DCC book VaR99 ($mm): FX 1d {p['FX']['var99_1d_mm']:.2f} / 10d {p['FX']['var99_10d_mm']:.2f}; equity 1d {p['Equity']['var99_1d_mm']:.2f} / 10d {p['Equity']['var99_10d_mm']:.2f}; total 1d {p['total_var99_1d_mm']:.2f} / 10d {p['total_var99_10d_mm']:.2f}")
    if g.dcc_fx:
        print(f"DCC FX: a={g.dcc_fx.a:.3f} b={g.dcc_fx.b:.3f} avg corr {g.dcc_fx.avg_corr(g.dcc_fx.R_next):.3f}")
    if g.dcc_eq:
        print(f"DCC equity: a={g.dcc_eq.a:.3f} b={g.dcc_eq.b:.3f} avg corr {g.dcc_eq.avg_corr(g.dcc_eq.R_next):.3f}")
    print(f"Tables -> {out}; GARCH tab plan ({len(plan)} ranges) -> {out / 'garch_plan.json'}")
    if args.token:
        r = apply_plan(plan, args.spreadsheet_id, args.token)
        print(f"Wrote {r.get('totalUpdatedCells')} cells to the GARCH tab")


def cmd_econ(args):
    """Econometrics toolkit on the Market History prices: workflow tests, cointegration, SVAR, Kalman betas, regimes, premia, EVT, copulas, forecasts, event study."""
    import warnings
    from .engine.garch import run_garch, load_prices
    from .engine.econometrics import run_econometrics
    from .presentation.econ_publish import econ_plan
    from .presentation.sheets_publish import save_plan, apply_plan
    from .scorecard import score_universe
    warnings.filterwarnings("ignore", category=RuntimeWarning)
    u, s = _load(args)
    px = load_prices(args.data)
    if px is None:
        raise SystemExit("No price history: export the Market History tab to data/market_history/prices.csv first.")
    g = run_garch(u, px, s, u.gpr)
    e = run_econometrics(u, px, g, s, u.gpr, score_universe(u, s).composite)
    out = Path(args.out) / "econometrics"; out.mkdir(parents=True, exist_ok=True)
    for name in ("workflow", "cointegration", "svar", "kalman", "regimes", "premia_fm", "premia_gmm", "evt", "copulas", "forecasts", "forecast_importance", "events"):
        getattr(e, name).to_csv(out / f"{name}.csv", index=name.startswith("premia") or name == "forecast_importance")
    plan, _ = econ_plan(e)
    save_plan(plan, out / "econ_plan.json")
    wf = e.workflow
    print(f"Series: {len(wf)}; returns stationary (ADF, FDR 5%): {int(wf['adf_return_bh_reject'].sum())}; ARCH effects (FDR 5%): {int(wf['arch_bh_reject'].sum())}; out-of-sample best: {wf['oos_best'].value_counts().to_dict()}")
    print(f"Cointegration: {e.cointegration['read'].value_counts().to_dict()}")
    print("Forecasts (R2 out of sample): " + "; ".join(f"{r.model}: {r.r2_out_of_sample:.3f}" for r in e.forecasts.itertuples()))
    print(f"Premia (weekly, Fama-MacBeth):\n{e.premia_fm.round(5).to_string()}")
    print(f"Tables -> {out}; Econometrics tab plan ({len(plan)} ranges) -> {out / 'econ_plan.json'}")
    if args.token:
        r = apply_plan(plan, args.spreadsheet_id, args.token)
        print(f"Wrote {r.get('totalUpdatedCells')} cells to the Econometrics tab")


def _loopback_host(host: str, cmd: str) -> str:
    """gui/serve bind only to loopback (SEC-C-007 O1): the Host-header guard does not check who connects, so another
    machine on the network could read the session token and start jobs."""
    import ipaddress
    h = str(host).strip().strip("[]")
    try:
        ok = h.lower() == "localhost" or ipaddress.ip_address(h).is_loopback
    except ValueError:
        ok = False
    if not ok:
        raise SystemExit(f"{cmd}: --host {host!r} is not a loopback address; the {cmd} is for this machine only (use 127.0.0.1)")
    return h


def cmd_serve(args):
    _loopback_host(args.host, "serve")
    serve(args.data, str(Path(args.out) / "store"), host=args.host, port=args.port)


def cmd_gui(args):
    """Local browser app with charts and buttons for every command."""
    from .presentation.gui import gui
    _loopback_host(args.host, "gui")
    gui(args.data, args.out, host=args.host, port=args.port, open_browser=not args.no_browser)


def cmd_monitor(args):
    """Weekly risk monitor (EQ-C-0009): latest archived run vs the run about --days earlier; outputs/reports/risk-monitor-<as_of>.html, .md and latest-monitor.html."""
    from .presentation.risk_monitor import build_monitor
    r = build_monitor(args.out, args.data, Path(args.out) / "reports", days=args.days)
    print(f"Monitor: {r['html']} (markdown {r['md']}; latest {r['latest']}); run {r['run_id']} as of {r['as_of'] or 'not recorded'} vs {r['reference_run_id'] or 'none'}; {r['caveats']} input caveats")


def cmd_report(args):
    """Daily risk report (roadmap 4.2) from the latest archived run (or a fresh run when none is archived): outputs/reports/risk-report-<date>.html, .md and latest.html."""
    from .presentation.report import build_report
    from .validation.alerts import deliver_alerts
    r = build_report(args.data, args.out, paths=args.paths)
    s = Settings.load(Path(args.data) / "assumptions.json")
    deliver_alerts(r["alerts"], s, os.environ, out_dir=args.out, webhook=not args.no_deliver, email=not args.no_deliver, run_id=r["run_id"], html=r["html_text"])
    print(f"Report: {r['html']} (markdown {r['md']}; latest {r['latest']}); run {r['run_id']} vs previous {r['previous_run_id'] or 'none'}; {len(r['alerts'])} alerts")


def cmd_alerts(args):
    """Alerts (roadmap 4.3): compare the latest archived run with the previous one (or --previous <run id>), test the forecast record, check the data layer; write outputs/alerts.json and deliver."""
    from .validation.alerts import detect_alerts, deliver_alerts, load_data_issues
    from .validation.record import load_record
    from .presentation.report import latest_run, previous_run
    store = Store(Path(args.out) / "store")
    cur = latest_run(store)
    if cur is None:
        raise SystemExit("No archived run: run `econquest run` first.")
    prev = store.load(args.previous) if args.previous else previous_run(store, cur)
    s = Settings.load(Path(args.data) / "assumptions.json")
    review, feeds = load_data_issues(args.data)
    rec_path = Path(args.data) / "forecast_record.csv"
    alerts = detect_alerts(cur, prev, load_record(rec_path) if rec_path.exists() else None, s, review=review, feeds=feeds)
    st = deliver_alerts(alerts, s, os.environ, out_dir=args.out, webhook=args.webhook, email=args.email, run_id=cur["summary"]["run_id"])
    print(f"Run {cur['summary']['run_id']} vs {prev['summary']['run_id'] if prev else 'no previous run'}: {len(alerts)} alerts -> {st['written']}; webhook {st['webhook']}; email {st['email']}")


def cmd_limits(args):
    """Limits table for the current book and, with --propose, the pre-trade check (roadmap 4.1)."""
    from .engine import limits as LM
    u, s = _load(args)
    lim = LM.load_limits(Path(args.data) / "limits.json")
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    paths = args.paths or 20000
    pd.set_option("display.width", 200)
    if args.propose:
        res = LM.pretrade_check(u, s, lim, args.propose, paths=paths)
        table = res["limits_after"]
        table.to_csv(out / "limits.csv", index=False)
        (out / "pretrade.json").write_text(dumps(LM.pretrade_to_dict(res)))
        b, a = res["before_common_paths"], res["after"]
        print(f"Proposed: {res['proposal']}  ({paths} paths, seed {res['seed']})")
        print(f"VaR99 {b['var99_mm']:.1f} -> {a['var99_mm']:.1f} (marginal {res['marginal_var99_mm']:+.2f}), ES99 {b['es99_mm']:.1f} -> {a['es99_mm']:.1f} (marginal {res['marginal_es99_mm']:+.2f}), "
              f"L-VaR99 {b['lvar99_mm']:.1f} -> {a['lvar99_mm']:.1f}, gross {res['before']['gross_notional_mm']:.0f} -> {a['gross_notional_mm']:.0f}")
        print(f"VERDICT: {res['verdict'].upper()}")
        for r in res["reasons"]:
            print("  " + r)
        if not res["reasons"]:
            print("  no limit at or above its warning level after the trade")
    else:
        r = run_pipeline(u, s, paths=paths, market_dir=args.data)
        table = LM.check_book(r, u, lim)
        table.to_csv(out / "limits.csv", index=False)
    shown = table.sort_values("utilisation", ascending=False)
    print(); print(shown.round(4).to_string(index=False))
    n = table["status"].value_counts()
    print(f"\n{int(n.get('pass', 0))} pass, {int(n.get('warning', 0))} warning, {int(n.get('breach', 0))} breach. Written {out / 'limits.csv'}" + (f" and {out / 'pretrade.json'}" if args.propose else ""))


def cmd_replicate(args):
    """Independent replication of the reported numbers (HO-20261023-B-C-015, EQ-B-0051): a pass-through to
    econquest.validation.replicate.main with the same flags and its exit code (1 on any FAIL). Maintenance change: no
    logic here, no model number moves."""
    from .validation import replicate as R
    argv = ["--data", str(args.data), "--out", str(args.rep_out or Path(args.out) / "replication")]
    argv += (["--quick"] if args.quick else []) + (["--only", args.only] if args.only else [])
    code = R.main(argv)
    if code:
        raise SystemExit(code)


def cmd_replicate_archive(args):
    """Second-line replication of the release notes 0.1.1-0.1.5 against the archived runs, the kept zip and (--rerun) a
    rerun of the 0.1.5 zip's engine (HO-20261024-B-C-003 part 1, EQ-B-0058): a pass-through to
    econquest.validation.replicate_archive.main with the same flags and its exit code (1 = a mismatch without a
    findings-register row, or a cited run missing). Read-only on the archive and the store; writes only to --out."""
    import zipfile
    from .validation import replicate_archive as RA

    def opt(flag, val):                                # SEC-C-009: a value starting with '-' stays the flag's value
        return [f"{flag}={val}"] if str(val).startswith("-") else [flag, str(val)]
    if args.zip is not None and args.zip != "none" and not Path(args.zip).is_file():
        raise SystemExit(f"replicate-archive: --zip {args.zip} is not a file (pass --zip none to skip the zip checks)")
    argv = opt("--out", args.ra_out or Path(args.out) / "replication-archive")
    for flag, val in (("--archive", args.archive), ("--db", args.db), ("--zip", args.zip)):
        if val is not None:
            argv += opt(flag, val)
    argv += ["--rerun"] if args.rerun else []
    try:
        code = RA.main(argv)
    except (ValueError, OSError, zipfile.BadZipFile) as e:   # e.g. --out inside the archive, a damaged or wrong zip
        raise SystemExit(f"replicate-archive: {' '.join(str(e).split())}") from None
    if code:
        raise SystemExit(code)


def cmd_governance(args):
    """Governance pack: regenerate docs/governance/change-log.md from the run archive and print the inventory status."""
    from .validation.governance import change_log, write_change_log, inventory_status
    store = Store(Path(args.out) / "store")
    df = change_log(store, limit=args.limit)
    docs = Path(args.docs) if args.docs else HOME_DIR / "docs" / "governance"
    path = write_change_log(df, docs / "change-log.md")
    print(f"Change log: {len(df)} runs -> {path}")
    if len(df):
        print(df[["run_id", "label", "code_hash", "data_hash", "var99_mm", "es99_mm", "code_changed", "data_changed", "settings_changed"]].round(2).to_string(index=False))
    status = inventory_status(args.data, args.out)
    (Path(args.out) / "governance_status.json").write_text(dumps(status))
    print(dumps(status))


def cmd_editorial(args):
    """Editorial states (EQ-C-0026): draft -> reviewed -> published; correct, withdraw, list, verify (outputs/editorial/ledger.jsonl, outputs/published/)."""
    from .presentation import editorial as E
    from .presentation.report import latest_run
    out = Path(args.out)
    try:
        if args.ed_cmd in ("draft", "correct"):
            run = Store(out / "store").load(args.run_id) if args.run_id else latest_run(Store(out / "store"))
            meta = E.meta_from_run(run) if (run is not None or args.ed_cmd == "draft") else None
            it = (E.register_draft(out, args.kind, args.file, meta, args.author) if args.ed_cmd == "draft"
                  else E.correct(out, args.item, args.file, args.author, args.reason, meta=meta if args.run_id else None))
        elif args.ed_cmd == "review":
            it = E.review(out, args.item, args.reviewer, args.note or "", self_reviewed=args.self_reviewed, data_dir=args.data)
        elif args.ed_cmd == "checklist":
            if args.show:
                st = E.checklist_status(out, args.item, data_dir=args.data)
            else:
                if not args.by:
                    raise E.EditorialError("checklist needs --by (or --show)")
                it = E.checklist(out, args.item, args.by, conflicts=args.conflicts, acknowledge=args.acknowledge or [],
                                 compliance_approve=(args.note or True) if args.compliance_approve else False,
                                 self_signed=args.self_signed, data_dir=args.data, exc_id=args.exc)
                st = it["checklist_status"] or E.checklist_status(out, args.item, data_dir=args.data)
            for name, v in st["items"].items():
                extra = (f" (by {v.get('approver') or v.get('by')}{', SELF-SIGNED exception ' + str(v.get('exc_id') or '') if v.get('self_signed') else ''})"
                         if v["ok"] and v.get("mode") == "manual" else "")
                print(f"  [{'x' if v['ok'] else ' '}] {name:<19} {v['mode']}{extra}")
                for p in v["problems"]:
                    print(f"        - {p}")
            print(f"{args.item}: checklist {'complete' if st['complete'] else 'INCOMPLETE'}")
            if args.show and not st["complete"]:
                raise SystemExit(1)
            return
        elif args.ed_cmd == "publish":
            it = E.publish(out, args.item, args.publisher, data_dir=args.data)
            try:                                # EQ-C-0045: queue only; `econquest distribute send --send` delivers
                from .ops import distribute as D
                if D.queue(out, it["item_id"], actor=args.publisher, data_dir=args.data)["queued"]:
                    print(f"{it['item_id']}: queued for distribution (econquest distribute send; dry run unless --send)")
            except Exception as e:              # noqa: BLE001 - publishing stands; queue later by hand
                print(f"warning: not queued for distribution ({e}); run `econquest distribute queue {it['item_id']}`", file=sys.stderr)
        elif args.ed_cmd == "withdraw":
            it = E.withdraw(out, args.item, args.by, args.reason)
        elif args.ed_cmd == "list":
            items = E.list_items(out, state=args.state, kind=args.kind)
            for i in items[-args.limit:]:
                print(f"{i['item_id']}  {i['kind']:<15} {i['state']:<10} run {i['meta']['run_id']}  as_of {i['meta']['as_of']}  "
                      f"author {i['author']}  reviewer {i.get('reviewer', '-')}{' (self)' if i.get('self_reviewed') else ''}"
                      f"{'  correction_of ' + i['correction_of'] if i.get('correction_of') else ''}  {i.get('published_dir', '')}")
            if not items:
                print("No editorial items.")
            return
        else:  # verify
            r = E.verify_published(out)
            print(f"verify: {r['checked']} published item(s), {len(r['problems'])} problem(s)")
            for p in r["problems"]:
                print("  " + p)
            if not r["ok"]:
                raise SystemExit(1)
            return
    except E.EditorialError as e:
        raise SystemExit(f"editorial {args.ed_cmd}: {e}") from None
    print(f"{it['item_id']} ({it['kind']}): {it['state']}" + (f" -> {it['published_dir']}" if it.get("published_dir") else ""))


def cmd_change(args):
    """Change approvals for data/assumptions.json, data/limits.json and data/compliance.json (EQ-C-0023, EQ-C-0040):
    propose, approve, reject, apply, list, show, verify (hash chain + drift), baseline."""
    from .ops import approvals as ap
    d = Path(args.data)
    try:
        if args.change_cmd == "propose":
            if args.replace_file:
                patch, replace = Path(args.replace_file).read_text(encoding="utf-8"), True
            else:
                patch, replace = {}, False
                if args.patch_file:
                    patch.update(json.loads(Path(args.patch_file).read_text(encoding="utf-8")))
                for kv in args.set or []:
                    path, sep, raw = kv.partition("=")
                    if not sep:
                        raise SystemExit(f"change propose: --set needs /json/pointer=VALUE, got {kv!r}")
                    try:
                        patch[path] = json.loads(raw)
                    except json.JSONDecodeError:
                        raise SystemExit(f"change propose: value for {path} must be JSON (quote strings: '\"text\"'), got {raw!r}") from None
            p = ap.propose(d, args.file, patch, args.author, args.reason, tier=args.tier, replace=replace,
                           allow_new_keys=args.allow_new_keys, allow_type_change=args.allow_type_change)
            print(f"Proposed {p['id']} ({p['file']}, tier {p['tier']}{', validator needed' if p['needs_validator'] else ''}):")
            for c in p["diff"]:
                print(f"  {c['op']:6} {c['path']}: {json.dumps(c['old'])} -> {json.dumps(c['new'])}")
        elif args.change_cmd == "approve":
            r = ap.approve(d, args.id, approver=args.approver, self_approved=args.self_approved, exc_id=args.exc, note=args.note or "")
            print(f"Approved {args.id} by {r['approver']}" + (f" (self-approved under {r['exc_id']})" if r["self_approved"] else "") + (f" {r['note']}" if r["note"] else ""))
        elif args.change_cmd == "reject":
            ap.reject(d, args.id, args.by, args.reason or "")
            print(f"Rejected {args.id}")
        elif args.change_cmd == "apply":
            r = ap.apply(d, args.id, actor=args.actor)
            print(f"Applied {args.id}: {r['file']} sha256 {r['file_sha256']}")
        elif args.change_cmd == "list":
            rows = ap.list_changes(d, status=args.status)
            print(pd.DataFrame(rows).tail(args.limit).to_string(index=False) if rows else "No changes recorded.")
        elif args.change_cmd == "show":
            print(dumps(ap.show(d, args.id)))
        elif args.change_cmd == "baseline":
            r = ap.baseline(d, args.file, args.actor, args.reason, approver=args.approver, self_approved=args.self_approved, exc_id=args.exc)
            print(f"Baselined {r['file']} at sha256 {r['file_sha256']}")
        else:                                   # verify
            v, drift = ap.verify_chain(d), ap.detect_unapproved(d)
            print(f"Chain: {'ok' if v['ok'] else 'BROKEN'} ({v['rows']} rows)")
            for e in v["errors"]:
                print("  " + e)
            for f in drift["files"]:
                print(f"{f['file']}: {f['status']}" + (f" (current {str(f['current_sha256'])[:12]}, approved {str(f['approved_sha256'])[:12]})" if f["status"] == "drift" else ""))
            if not drift["ok"]:
                raise SystemExit(1)
    except ap.ApprovalError as e:
        raise SystemExit(f"change {args.change_cmd}: {e}") from None


def cmd_notes(args):
    """Country notes (EQ-C-0024): one HTML note per country, PDF with --pdf when Chrome/Chromium is found."""
    from .presentation.country_note import build_country_notes
    r = build_country_notes(args.out, args.data, args.dest or Path(args.out) / "notes", countries=args.country, pdf=args.pdf, chrome=args.chrome)
    print(f"{len(r['items'])} notes, {r['pdf_ok']} PDFs, {r['elapsed_s']}s -> {r['out_dir']} (pillars: {r['pillar_source']})")


def cmd_briefs(args):
    """Scenario briefs (EQ-C-0025) from stress.json, archived stress runs and reverse_stress.json."""
    from .presentation.scenario_brief import build_scenario_briefs
    r = build_scenario_briefs(args.out, args.data, args.dest or Path(args.out) / "briefs", scenarios=args.scenario, pdf=args.pdf, chrome=args.chrome)
    print(f"{len(r['items'])} briefs -> {r['out_dir']}")


def cmd_publish_preview(args):
    """Republish preview (EQ-C-0027): diff the saved publish plan against a values:batchGet JSON or a previous plan."""
    from .presentation.republish_preview import preview, batchget_urls, load_blocks
    plan = args.plan or Path(args.out) / "publish_plan.json"
    if args.urls:
        for u in batchget_urls(load_blocks(plan)[0], args.spreadsheet_id or "SPREADSHEET_ID"):
            print(u)
        return
    if not args.baseline:
        raise SystemExit("--baseline FILE required (or --urls to print the batchGet URLs to fetch)")
    s = preview(plan, args.baseline, args.dest or Path(args.out) / "preview", tolerance=args.tolerance, large=args.large, data_dir=args.data)
    print(s["html"])


def cmd_review(args):
    """Review ledger (EQ-A-0006): `review decide` appends one decision row; `review list` prints the latest decision per cell;
    `review approve` / `review apply` decide and apply against a saved vintage (HO-20261023-A-C-016)."""
    from .ingestion.ledger import record_decision, load_decisions, check_approval
    d = Path(args.data)
    if args.review_cmd == "approve":                                  # HO-20261023-A-C-016: decide against a saved vintage
        return _review_approve(d, args)
    if args.review_cmd == "apply":
        return _review_apply(d, args)
    if args.review_cmd == "decide" and _review_is_batch(args):        # EQ-C-0052 (U06): several held cells at once
        cells = _decide_cells(d, args)

        def decide_one(c):
            return record_decision(d, c["table"], c["key"], c["country"], args.decision, args.author, approver=args.approver,
                                   note=args.note or "", vintage_id=args.vintage or "", live=c["live"],
                                   gate_status=c["gate_status"], self_approved=args.self_approved)

        def precheck(c):                                # every batch cell is gate-held: four-eyes before anything is written
            if args.decision == "apply":
                try:
                    check_approval(args.author, args.approver, args.self_approved)
                except ValueError as e:
                    raise ValueError(f"applying held cell ({c['table']}, {c['key']}, {c['country']}) "
                                     + str(e).replace("self_approved=True", "--self-approved")) from None
        _review_batch(args, "review decide", cells, decide_one, precheck)
        return
    if args.review_cmd == "decide":
        if not (args.table and args.key and args.country):
            raise SystemExit("review decide: give --table, --key and --country for one cell, or --cell TABLE KEY COUNTRY "
                             "(repeat) or --all-pending for several")
        try:
            row = record_decision(d, args.table, args.key, args.country, args.decision, args.author, approver=args.approver,
                                  note=args.note or "", vintage_id=args.vintage or "", live=args.live, gate_status=args.gate_status or "",
                                  self_approved=args.self_approved)
        except ValueError as e:
            raise SystemExit(f"review decide: {e}") from None
        print("Recorded:", ", ".join(f"{k}={v}" for k, v in row.items() if v not in ("", None)))
    else:
        dec = load_decisions(d)
        if args.country:
            dec = dec[dec["country"] == args.country]
        if args.table:
            dec = dec[dec["table"] == args.table]
        if getattr(args, "vintage", None) and not getattr(args, "pending", False):
            raise SystemExit("review list: --vintage needs --pending (review list --pending --vintage ID)")
        if getattr(args, "pending", False):
            if args.vintage:
                return _review_pending_vintage(d, args)
            dec = _review_pending(d, dec, args)
            print(dec.tail(args.limit).to_string(index=False) if len(dec) else "No held cells waiting for a decision.")
            if len(dec):
                print(APPROVE_HINT)
                print("Decide several: econquest review decide --all-pending (or --cell TABLE KEY COUNTRY, repeated) "
                      "--decision apply|hold|reject --author NAME (--approver OTHER, or --self-approved)")
            return
        print(dec.tail(args.limit).to_string(index=False) if len(dec) else "No review decisions recorded.")
        n = len(_review_pending(d, load_decisions(d), args))        # EQ-C-0048: say what is still waiting, not only what was decided
        if n:
            print(f"{n} cell(s) held by the quality gate have no decision yet (data/live/review.csv): econquest review list --pending")


def _read_review_csv(f: Path) -> pd.DataFrame:
    """data/live/review.csv as text, or a clean refusal when it is empty, unparseable or lacks the cell columns
    (AGENT-09 SEC-C-007 L2: a KeyError traceback before)."""
    try:
        rv = pd.read_csv(f, dtype=str, keep_default_na=False)
    except (pd.errors.EmptyDataError, pd.errors.ParserError, UnicodeDecodeError) as e:
        raise SystemExit(f"review: cannot read {f}: {e} (rerun econquest fetch)") from None
    missing = [c for c in ("table", "key", "country") if c not in rv.columns]
    if missing:
        raise SystemExit(f"review: {f} lacks the column(s) {', '.join(missing)} (rerun econquest fetch)")
    return rv


def _review_pending(d: Path, dec: pd.DataFrame, args) -> pd.DataFrame:
    """Cells the last fetch held (data/live/review.csv status hold) with no decision in the ledger yet."""
    f = d / "live" / "review.csv"
    if not f.exists():
        return pd.DataFrame(columns=["table", "key", "country", "seed", "live", "reason"])
    rv = _read_review_csv(f)
    rv = rv[rv.get("status", pd.Series(dtype=str)).eq("hold")] if "status" in rv.columns else rv.iloc[0:0]
    done = set(zip(dec["table"].astype(str), dec["key"].astype(str), dec["country"].astype(str))) if len(dec) else set()
    rv = rv[[(t, k, c) not in done for t, k, c in zip(rv["table"], rv["key"], rv["country"])]]
    if getattr(args, "country", None):
        rv = rv[rv["country"] == args.country]
    if getattr(args, "table", None):
        rv = rv[rv["table"] == args.table]
    return rv[[c for c in ("table", "key", "country", "seed", "live", "reason") if c in rv.columns]]


def _review_is_batch(args) -> bool:
    return bool(getattr(args, "cell", None) or getattr(args, "all_pending", False))


def _decide_cells(d: Path, args) -> list[dict]:
    """The cells of a batch `review decide` (EQ-C-0052, U06), each {"table", "key", "country", "live", "gate_status"}.
    Live value and gate status come from data/live/review.csv, so nothing is copied by hand: --all-pending takes the held
    cells with no decision yet (as `review list --pending`, --table/--country filter); --cell takes named cells, each of
    which must be held in review.csv."""
    from .ingestion.ledger import load_decisions
    if args.cell and args.all_pending:
        raise SystemExit("review decide: give --cell or --all-pending, not both")
    if args.live is not None or args.gate_status or args.key or (args.cell and (args.table or args.country)):
        raise SystemExit("review decide: with --cell/--all-pending the cells, live values and gate status come from "
                         "data/live/review.csv (--table/--country only filter --all-pending)")
    f = d / "live" / "review.csv"
    rv = _read_review_csv(f) if f.exists() else pd.DataFrame(columns=["table", "key", "country"])
    held = rv[rv["status"].eq("hold")] if "status" in rv.columns else rv.iloc[0:0]
    if args.all_pending:
        rows = _review_pending(d, load_decisions(d), args)
    else:
        want = [tuple(c) for c in args.cell]
        have = {(r["table"], r["key"], r["country"]): r for r in held.to_dict("records")}
        missing = [c for c in want if c not in have]
        if missing:
            raise SystemExit("review decide: not a held cell in data/live/review.csv: "
                             + "; ".join(" ".join(c) for c in missing) + " (econquest review list --pending)")
        rows = pd.DataFrame([have[c] for c in dict.fromkeys(want)])

    def live(v):
        try:
            return float(v)
        except (TypeError, ValueError):
            return None
    return [{"table": r["table"], "key": r["key"], "country": r["country"], "live": live(r.get("live")), "gate_status": "hold"}
            for r in rows.to_dict("records")]


def _review_batch(args, command: str, cells: list[dict], write_one=None, precheck=None, write_all=None, show=None) -> list[dict]:
    """Write one ledger decision per cell with write_one(cell) -> row, and one action-log row per cell (EQ-C-0052, U06).
    precheck(cell) runs on every cell first (raise ValueError to refuse), so a four-eyes refusal writes nothing; a refusal
    by write_one stops the batch there and says how many were recorded. Shared by every multi-cell review command.
    write_all(cells) -> rows replaces write_one with one call that checks every cell before writing any
    (feeds.record_vintage_decisions for `review approve`, HO-20261023-A-C-016): its refusal (ValueError, OSError) is
    one error row in the action log and nothing is recorded. show(row) -> the line printed per row written."""
    secrets = [os.environ.get(k, "") for k in (TOKEN_ENV, "ECONQUEST_SMTP_PASSWORD", "ECONQUEST_ALERT_WEBHOOK")]

    def log(c, code, err, i):
        a = {k: v for k, v in vars(args).items() if k not in ("fn", "cell", "all_pending", "cells")}
        a.update({k: c.get(k) for k in ("table", "key", "country", "live", "gate_status")}, batch=f"{i}/{len(cells)}")
        _record_action(args, command, code, err, secrets, extra_args=a)
    if not cells:
        print("No held cells waiting for a decision.")
        return []
    try:
        for c in cells:
            precheck and precheck(c)
    except ValueError as e:
        msg = f"{command}: {e} (nothing recorded for the {len(cells)} cell(s))"
        _record_action(args, command, 1, msg, secrets, extra_args={k: v for k, v in vars(args).items() if k != "fn"})
        raise SystemExit(msg) from None
    if write_all is not None:
        try:
            rows = write_all(cells)
        except (ValueError, OSError) as e:             # FileNotFoundError: no such vintage
            msg = f"{command}: {e}"
            _record_action(args, command, 1, msg, secrets, extra_args={k: v for k, v in vars(args).items() if k != "fn"})
            raise SystemExit(msg) from None
        for i, r in enumerate(rows, 1):
            log(r, 0, "", i)
            print(show(r) if show else "Recorded: " + ", ".join(f"{k}={v}" for k, v in r.items() if v not in ("", None)))
        print(f"{len(rows)} decision(s) recorded.")
        return rows
    rows = []
    for i, c in enumerate(cells, 1):
        try:
            rows.append(write_one(c))
        except ValueError as e:
            msg = f"{command}: {e} ({len(rows)} of {len(cells)} cell(s) recorded before this one)"
            log(c, 1, msg, i)
            raise SystemExit(msg) from None
        log(c, 0, "", i)
        print("Recorded:", ", ".join(f"{k}={v}" for k, v in rows[-1].items() if v not in ("", None)))
    print(f"{len(rows)} decision(s) recorded.")
    return rows


# ---------------------------------------------------------------- review against a saved vintage (HO-20261023-A-C-016)
# Thin wrappers over Team A's feeds.vintage_review / record_vintage_decisions / apply_vintage (EQ-A-0035): offline, the
# decision binds to the vintage id and the live value Sam reviewed, and `review apply` re-applies that same vintage.
REVIEW_TABLES = ("Inputs", "Country Profile")
APPROVE_HINT = ("Decide one: econquest review approve TABLE KEY COUNTRY [TABLE KEY COUNTRY ...] --author NAME "
                "(--approver OTHER, or --self-approved) [--decision hold|reject] [--vintage ID] [--note TEXT]")


def _approve_cells(args) -> list[dict]:
    """The positional cells of `review approve` as {"table", "key", "country"}, in order, duplicates dropped."""
    v = [str(x).strip() for x in args.cells]
    if len(v) % 3:
        raise SystemExit(f"review approve: give cells as TABLE KEY COUNTRY triples, e.g. \"Country Profile\" fx3m Brazil "
                         f"(got {len(v)} value(s), not a multiple of 3)")
    cells = list(dict.fromkeys(tuple(v[i:i + 3]) for i in range(0, len(v), 3)))
    bad = [c for c in cells if c[0] not in REVIEW_TABLES]
    if bad:
        raise SystemExit("review approve: the table of a cell is Inputs or \"Country Profile\", got "
                         + "; ".join(" ".join(c) for c in bad))
    return [{"table": t, "key": k, "country": c} for t, k, c in cells]


def _review_approve(d: Path, args) -> list[dict]:
    """`review approve`: feeds.record_vintage_decisions over every cell at once (it checks the vintage hash, that each
    cell is in the vintage's review, and four-eyes over all cells before writing any), one action-log row per row."""
    from .ingestion.feeds import record_vintage_decisions
    cells = _approve_cells(args)

    def write_all(cs):
        try:
            return record_vintage_decisions(d, [(c["table"], c["key"], c["country"]) for c in cs], args.author,
                                            approver=args.approver, self_approved=args.self_approved,
                                            vintage_id=args.vintage, decision=args.decision, note=args.note or "")
        except ValueError as e:
            raise ValueError(str(e).replace("self_approved=True", "--self-approved")) from None

    def show(r):
        return (f"Recorded: {r['table']} {r['key']} {r['country']}  decision={r['decision']} vintage_id={r['vintage_id']} "
                f"live={r['live']} approver={r.get('approver') or '-'} self_approved={r.get('self_approved') or 'no'}")
    rows = _review_batch(args, "review approve", cells, precheck=None, write_all=write_all, show=show)
    if rows and args.decision == "apply":
        print(f"Apply them (offline, no refetch): econquest review apply --vintage {rows[0]['vintage_id']}")
    return rows


def _vintage_label(vid: str, latest: str) -> str:
    return f"vintage {vid} (latest)" if vid == latest else f"vintage {vid} (not the latest; latest is {latest})"


def _review_pending_vintage(d: Path, args) -> None:
    """`review list --pending --vintage ID`: the gate-held cells of that saved vintage with feeds.vintage_review's
    `effective` column (released = an approved apply binds to this vintage or its live value; held = stays on seed)."""
    from .ingestion.feeds import latest_vintage, vintage_review
    try:
        r = vintage_review(d, args.vintage)
        latest = latest_vintage(d)
    except (ValueError, OSError) as e:
        raise SystemExit(f"review list: {e}") from None
    vid = str(r["vintage_id"].iloc[0]) if len(r) else str(args.vintage)
    held = r[r["status"] == "hold"]
    if args.country:
        held = held[held["country"] == args.country]
    if args.table:
        held = held[held["table"] == args.table]
    if not len(held):
        print(f"No held cells in {_vintage_label(vid, latest)}.")
        return
    waiting = int((held["effective"] == "held").sum())
    print(f"{_vintage_label(vid, latest)}: {len(held)} held cell(s), {waiting} with no approved apply bound to it (effective held)")
    cols = [c for c in ("table", "key", "country", "seed", "live", "reason", "decision", "approver", "decision_vintage", "effective")
            if c in held.columns]
    print(held[cols].tail(args.limit).to_string(index=False))
    if waiting:
        print(APPROVE_HINT.replace("[--vintage ID]", f"--vintage {vid}"))
    print(f"Then apply (offline, no refetch): econquest review apply --vintage {vid}")


def _review_apply(d: Path, args) -> None:
    """`review apply [--vintage ID] [--dry-run]`: feeds.apply_vintage (verifies the vintage, applies its ok cells and the
    held cells released by an approved decision bound to it; never forces). --dry-run prints feeds.vintage_review's
    effective counts and writes nothing. An older vintage is refused by apply_vintage itself (OlderVintageError,
    SEC-A-004 L2, on the resolved id, so a date id of the latest vintage passes) unless --allow-older; the rollback
    it then records (res["rollback"], rollback.json in the pre-apply snapshot) is printed (HO-20261024-A-C-003)."""
    from .ingestion.feeds import OlderVintageError, apply_vintage, latest_vintage, vintage_review
    try:
        if args.dry_run:
            r = vintage_review(d, args.vintage)
            latest = latest_vintage(d)
        else:
            res = apply_vintage(d, vintage_id=args.vintage, allow_older=args.allow_older)
    except OlderVintageError as e:                     # one line, nothing written (apply_vintage checks before any write)
        raise SystemExit(f"review apply: {' '.join(str(e).split())}; --dry-run shows it first") from None
    except (ValueError, OSError) as e:
        raise SystemExit(f"review apply: {e}") from None
    if args.dry_run:
        vid = str(r["vintage_id"].iloc[0]) if len(r) else str(args.vintage)
        counts = r["effective"].value_counts()
        print(f"Dry run: {_vintage_label(vid, latest)}: "
              + (", ".join(f"{int(n)} {k}" for k, n in counts.items()) or "no cells") + "; nothing written")
        held = r[r["status"] == "hold"]
        if len(held):
            print(held[["table", "key", "country", "seed", "live", "decision", "effective"]].to_string(index=False))
    else:
        vid, latest = res["vintage_id"], res["latest_vintage"]
        print("Applied:", res)
        live = {}
        try:                                           # the live value of each held cell, for the lines below (read-only)
            rv = vintage_review(d, vid)
            live = {(t, str(k), c): v for t, k, c, v in zip(rv["table"], rv["key"], rv["country"], rv["live"])}
        except (ValueError, OSError):
            pass
        for name in ("released", "still_held"):
            print(f"{name} ({len(res[name])}):")
            for c in res[name]:
                print("  " + " ".join(map(str, c)) + (f"  live={live[tuple(c)]}" if tuple(c) in live else ""))
        rb = res.get("rollback")
        if rb:                                         # SEC-A-004 I4: the rollback apply_vintage recorded
            print(f"rollback: {rb.get('vintage_id')} re-applied over latest {rb.get('latest_vintage')} at {rb.get('ts_utc')}"
                  + (f" by {rb['author']}" if rb.get("author") else "") + f"; recorded in {rb.get('record')}")
    if vid != latest:
        print(f"warning: {vid} is not the latest vintage ({latest}): re-applying an older vintage also re-applies its ok "
              "cells over newer values", file=sys.stderr)


def cmd_dsa(args):
    """Debt sustainability and reserve adequacy (roadmap 3.1, 3.2): fan charts around the WEO baseline, the IMF ARA metric, and the derived scorecard inputs 1.1, 1.2, 2.1."""
    from .engine import dsa as D
    from .presentation.sheets_publish import save_plan, apply_plan
    u, s = _load(args)
    d = Path(args.data); live = d / "live"
    weo_p = live / "raw_weo.csv"
    if not weo_p.exists():
        raise SystemExit("No data/live/raw_weo.csv: run `econquest fetch` first (needs api.imf.org).")
    weo = pd.read_csv(weo_p); wb = pd.read_csv(live / "raw_worldbank.csv") if (live / "raw_worldbank.csv").exists() else None
    inputs = D.load_dsa_inputs(d / "dsa_inputs.csv")
    as_of = args.as_of or pd.Timestamp.today().strftime("%Y-%m-%d")
    table, fans, diag = D.dsa_table(u, s, weo, wb, inputs, year0=args.year, paths=args.paths or 10000, as_of=as_of)
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    table.to_csv(out / "dsa.csv", index=False); fans.to_csv(out / "dsa_fan.csv", index=False)
    (out / "dsa_diagnostics.json").write_text(dumps(diag))
    plan = D.dsa_plan(table, fans, as_of); save_plan(plan, out / "dsa_plan.json")
    pd.set_option("display.width", 260)
    cols = ["country", "debt_now", "r_minus_g", "pb_gap", "debt_baseline_5y", "debt_median_5y", "debt_p10_5y", "debt_p90_5y", "p_debt_rising", "gfn_pct_gdp", "debt_service_pct_revenue", "fx_debt_service_24m_pct_reserves", "reserves_pct_ara", "read"]
    print(table[cols].round(2).to_string(index=False))
    missing = sorted(set(u.names) - set(table["country"]))
    if missing:
        print(f"No WEO debt history for: {', '.join(missing)}")
    print(f"Written {out / 'dsa.csv'}, dsa_fan.csv, dsa_plan.json")
    # EQ-B-0010 / HO-20261023-B-C-004: the DSA never writes data/; its scorecard inputs are an engine output that
    # Team A's ingestion gate applies.
    feeds = D.scorecard_feeds(table, retrieved=as_of, keys=tuple(args.keys))
    path = D.write_scorecard_feeds(feeds, out)
    print(f"Written {path}: {len(feeds)} proposed cells for {', '.join(args.keys)}; apply through the ingestion gate")
    if args.apply or args.force:
        print("--apply/--force no longer change data/ here: the ingestion quality gate applies outputs/dsa_scorecard_feeds.csv "
              "(Team A, HO-20261023-A-B-001). Nothing under data/ was changed.")
    if args.token:
        print("Written:", apply_plan(plan, args.spreadsheet_id, args.token))


def cmd_log(args):
    """Operator action log (EQ-C-0035): `log verify` checks the hash chain (exit 1 when broken); `log tail` prints rows."""
    from .ops import actionlog as AL
    out = action_out(args)
    if args.log_cmd == "verify":
        v = AL.verify(out)
        print(f"Action log {v['path']}: {'ok' if v['ok'] else 'BROKEN'} ({v['rows']} rows)")
        for e in v["errors"]:
            print("  " + e)
        if not v["ok"]:
            raise SystemExit(1)
        return
    rows = AL.tail(out, args.n)
    if args.json:
        for r in rows:
            print(json.dumps(r, ensure_ascii=False))
    elif rows:
        for r in rows:
            print(AL.format_row(r))
    else:
        print(f"No operator actions logged in {AL.log_path(out)}.")


# ---------------------------------------------------------------- run gate for unattested hand-entered cells (EQ-C-0034)
# The one place the policy lives. Values: warn (print counts and the fix, carry on), block (exit 3 before the command
# runs, so before any Sheets call), off. Keys are command names; "sheets_write" is every invocation that would write the
# workbook (publish --write and every writer with --write/--token-file, never --dry-run), and "<cmd>:write" overrides it
# for one writer. Sam has not chosen yet (EQ-C-0034): these are the recommended defaults. Overrides, later wins:
#   <home>/ops.json  {"run_gate": "warn"}  or  {"run_gate": {"publish:write": "warn", "run": "block"}}
#   $ECONQUEST_RUN_GATE  "warn" | "block" | "off"  or  "run=block,sheets_write=warn"
# A plain value sets every key. --allow-unattested on one invocation proceeds past a block and is recorded in the action log.
RUN_GATE_ENV = "ECONQUEST_RUN_GATE"
RUN_GATE_MODES = ("warn", "block", "off")
RUN_GATE_DEFAULT = {
    "run": "warn", "stress": "warn", "record": "warn", "report": "warn", "monitor": "warn", "notes": "warn", "briefs": "warn",
    "cds": "warn", "arbitrage": "warn",                                        # read cds_quotes / prediction_markets directly
    "publish": "warn", "benchmark": "warn", "garch": "warn", "econ": "warn", "dsa": "warn",   # writers saving a plan only
    "audit": "off",                                                            # reports the unattested count itself
    "sheets_write": "block",
}
RUN_GATE_EXIT = 3


class RunGateBlocked(SystemExit):
    """Exit RUN_GATE_EXIT; the action log records the reason."""
    reason = "run gate: blocked on unattested hand-entered cells"
WRITER_COMMANDS = ("publish", "benchmark", "record", "audit", "garch", "econ", "dsa")


def _home_of(args) -> Path:
    out = getattr(args, "out", None)
    return Path(out).expanduser().resolve().parent if out else HOME_DIR


def _gate_entries(spec, where: str) -> dict:
    if isinstance(spec, str) and "=" not in spec:
        spec = spec.strip().lower()
        if spec not in RUN_GATE_MODES:
            raise SystemExit(f"run gate: {where} must be one of {', '.join(RUN_GATE_MODES)}, got {spec!r}")
        return {k: spec for k in RUN_GATE_DEFAULT} | {"*": spec}
    if isinstance(spec, str):
        spec = dict(p.split("=", 1) for p in spec.split(",") if "=" in p)
    if not isinstance(spec, dict):
        raise SystemExit(f"run gate: {where} must be a mode or a mapping of command to mode")
    out = {}
    for k, v in spec.items():
        v = str(v).strip().lower()
        if v not in RUN_GATE_MODES:
            raise SystemExit(f"run gate: {where} {k!r} must be one of {', '.join(RUN_GATE_MODES)}, got {v!r}")
        out[str(k).strip()] = v
    return out


def run_gate_policy(home=None, env=None) -> dict:
    """Effective policy: RUN_GATE_DEFAULT, then <home>/ops.json "run_gate", then $ECONQUEST_RUN_GATE."""
    pol = dict(RUN_GATE_DEFAULT)
    p = Path(home or HOME_DIR) / "ops.json"
    if p.exists():
        try:
            cfg = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as e:
            raise SystemExit(f"run gate: cannot read {p}: {e}") from None
        if isinstance(cfg, dict) and cfg.get("run_gate") is not None:
            pol.update(_gate_entries(cfg["run_gate"], f"{p} run_gate"))
    raw = (os.environ if env is None else env).get(RUN_GATE_ENV, "").strip()
    if raw:
        pol.update(_gate_entries(raw, f"${RUN_GATE_ENV}"))
    return pol


def gate_mode(policy: dict, cmd: str, writes: bool) -> tuple[str, str]:
    """(mode, the policy key that decided it) for one invocation."""
    if writes:
        for k in (f"{cmd}:write", "sheets_write"):
            if k in policy:
                return policy[k], k
    if cmd in policy:
        return policy[cmd], cmd
    return policy.get("*", "off"), "*"


def _unattested_counts(data_dir) -> dict[str, int]:
    from collections import Counter
    from .ingestion.ledger import unattested_cells
    return dict(sorted(Counter(c["table"] for c in unattested_cells(Path(data_dir))).items()))


def _gate_text(counts: dict, mode: str, key: str, label: str) -> str:
    n = sum(counts.values())
    per = ", ".join(f"{f}.csv {c}" for f, c in counts.items())
    first = next(iter(counts), "adjustments")
    return (f"{n} hand-entered cell(s) are not attested ({per}).\n"
            f"  list them:  econquest attest --list [--file {first}]\n"
            f"  attest:     econquest attest --file {first} --author NAME --approver OTHER   (or --self-approved)\n"
            f"  policy:     run gate '{mode}' for {label} (key '{key}'; set in ops.json run_gate or ${RUN_GATE_ENV}); "
            f"--allow-unattested proceeds once and is recorded in the action log")


def _gate_warning(counts: dict, label: str) -> str:
    """The warn-mode message: one line (usability U02, EQ-C-0063). A block keeps the full _gate_text."""
    return (f"warning: {sum(counts.values())} hand-entered cell(s) not attested; {label} continues (run gate 'warn'). "
            f"List and fix: econquest attest --list")


def run_gate(args, writes: bool, log_override=None) -> dict | None:
    """Warn or block (SystemExit RUN_GATE_EXIT) when hand-entered cells are unattested. Returns what it found."""
    cmd = getattr(args, "cmd", "")
    if not hasattr(args, "allow_unattested"):
        return None
    mode, key = gate_mode(run_gate_policy(_home_of(args)), cmd, writes)
    if mode == "off":
        return None
    label = f"{cmd} --write" if writes else cmd
    try:
        counts = _unattested_counts(args.data)
    except (ValueError, OSError) as e:                 # cannot tell: a block fails closed, a warning says so
        if mode == "block" and not args.allow_unattested:
            print(f"run gate: blocked {label}: cannot check attestations in {args.data}: {e}. Nothing was sent to Sheets.", file=sys.stderr)
            raise RunGateBlocked(RUN_GATE_EXIT) from None
        print(f"warning: run gate could not check attestations in {args.data}: {e}", file=sys.stderr)
        return None
    if not counts:
        return {"mode": mode, "key": key, "counts": {}}
    found = {"mode": mode, "key": key, "counts": counts, "total": sum(counts.values()), "command": label}
    if args.allow_unattested:
        print(f"run gate: --allow-unattested: proceeding with {found['total']} unattested hand-entered cell(s) "
              f"({', '.join(f'{f} {c}' for f, c in counts.items())}); policy was '{mode}'; recorded in the action log", file=sys.stderr)
        if log_override:
            log_override(found)
        return found
    if mode == "block":
        print(f"run gate: blocked {label}: " + _gate_text(counts, mode, key, label) + "\nNothing was sent to Sheets.", file=sys.stderr)
        raise RunGateBlocked(RUN_GATE_EXIT)
    print(_gate_warning(counts, label), file=sys.stderr)
    return found


def _gated(name: str) -> bool:
    return name in RUN_GATE_DEFAULT or name in WRITER_COMMANDS


# ---------------------------------------------------------------- restricted-source gate (SEC-A-006 M1, HO-20261024-A-C-007)
# Applied cells whose value came from Yahoo / yfinance or a non-commercial / personal licence (Team A's
# audit.restricted_source_cells) must not reach a publish. `run`, `publish` without a write and `publish-preview`
# print restricted_warning(cells) on stderr and carry on; every invocation that would write the workbook (publish
# --write / --token-file, and any other writer with --write) is refused before the token lookup, so nothing is sent
# to Sheets. A check that raises fails closed on a write. No override flag: Sam's 2026-10-23 decision (EQ-A-0040)
# gives no basis for one. Scheduled jobs (ops/jobs.py) and GUI jobs run `econquest ...` through main(), so they
# hit the same refusal.
RESTRICTED_WARN_COMMANDS = ("run", "publish", "publish-preview")


class RestrictedSourceBlocked(RunGateBlocked):
    """Exit RUN_GATE_EXIT; the action log records the reason."""
    reason = "restricted-source gate: blocked on Yahoo / non-commercial cells (SEC-A-006 M1)"


def _restricted_cells(data_dir):
    from .ingestion.audit import restricted_source_cells
    return restricted_source_cells(data_dir)


def restricted_gate(args, writes: bool) -> int | None:
    """Warn (run, publish, publish-preview) or refuse (any workbook write) while restricted-source cells are applied.
    Returns the number of cells found, or None when the command is not gated or the check could not run (warn only)."""
    cmd = getattr(args, "cmd", "")
    if not writes and cmd not in RESTRICTED_WARN_COMMANDS:
        return None
    label = f"{cmd} --write" if writes else cmd
    try:
        cells = _restricted_cells(args.data)
    except Exception as e:                             # noqa: BLE001 - cannot tell: a write fails closed
        if writes:
            print(f"restricted-source gate: blocked {label}: cannot check {args.data} for restricted-source cells "
                  f"({type(e).__name__}: {e}). Nothing was sent to Sheets.", file=sys.stderr)
            raise RestrictedSourceBlocked(RUN_GATE_EXIT) from None
        print(f"warning: restricted-source gate could not check {args.data}: {type(e).__name__}: {e}", file=sys.stderr)
        return None
    if cells is None or cells.empty:
        return 0
    from .ingestion.audit import restricted_warning
    print(restricted_warning(cells), file=sys.stderr)
    if writes:
        print(f"restricted-source gate: blocked {label}: {len(cells)} applied cell(s) hold values from a restricted "
              f"source. Nothing was sent to Sheets. There is no override: replace them first "
              f"(econquest fetch --only fx --apply on the Mac).", file=sys.stderr)
        raise RestrictedSourceBlocked(RUN_GATE_EXIT)
    return len(cells)


# ---------------------------------------------------------------- operator action log (EQ-C-0035)
ACTOR_FLAGS = ("author", "reviewer", "publisher", "by", "approver", "actor")


def _will_write(args) -> bool:
    """The invocation would write the workbook (decided from the flags, before any token lookup)."""
    return (hasattr(args, "token_file") and not getattr(args, "dry_run", False)
            and bool(getattr(args, "token_file", None) or getattr(args, "token", None) or getattr(args, "write", False)))


def action_label(args, writes: bool) -> str | None:
    """The action-log name of this invocation, or None when it is not an operator action that is logged."""
    cmd = getattr(args, "cmd", "")
    if cmd == "review":
        if args.review_cmd == "apply":                 # HO-20261023-A-C-016: writes indicators.csv/countries.csv
            return None if args.dry_run else "review apply"
        # review approve and a batch decide log one row per cell themselves (_review_batch)
        return "review decide" if args.review_cmd == "decide" and not _review_is_batch(args) else None
    if cmd == "attest":
        return None if args.list else "attest"
    if cmd == "change":
        return f"change {args.change_cmd}" if args.change_cmd in ("propose", "approve", "reject", "apply", "baseline") else None
    if cmd == "editorial":
        return f"editorial {args.ed_cmd}"
    if cmd == "distribute":
        return {"queue": "distribute queue", "send": "distribute send --send" if getattr(args, "send", False) else None}.get(args.dist_cmd)
    if cmd == "fetch":
        return "fetch --apply" if (args.apply or args.force) else None
    if cmd == "schedule":
        return f"schedule {args.action}" if args.action in ("install", "uninstall") else None
    if cmd == "fit-hazard":
        return "fit-hazard --apply" if args.apply else None
    if cmd == "market":                                # HO-20261023-A-C-015: the commands that write data/
        if args.market_cmd == "gate" or (args.market_cmd == "import" and args.init_map) or getattr(args, "dry_run", False):
            return None
        return f"market {args.market_cmd}"
    if cmd == "vendor":                                # HO-20261023-A-C-021: only pull saves a snapshot; status and test write nothing
        return "vendor pull" if args.vendor_cmd == "pull" else None
    if writes:
        return f"{cmd} --write"
    return None


def _actor(args) -> tuple[str, str]:
    for k in ACTOR_FLAGS:
        v = getattr(args, k, None)
        if isinstance(v, str) and v.strip():
            return v.strip(), "flag"
    import getpass
    try:
        return os.environ.get("USER") or getpass.getuser(), "os"
    except Exception:                                  # noqa: BLE001 - no user name is not an error
        return "", "os"


def _versions(args) -> dict:
    from . import __version__
    v = {"code_version": __version__}
    try:
        from .versioning import code_hash
        v["code_hash"] = code_hash()
    except Exception:                                  # noqa: BLE001 - the log row matters more than the hash
        pass
    rid = getattr(args, "run_id", None)
    if rid:
        v["run_id"] = rid
    return v


def action_out(args) -> Path:
    """The outputs/ folder whose store/ holds the action log: --out when given, else the outputs/ beside a --data
    folder that was given (so the log stays with the install the command acted on), else the default outputs/."""
    out, data = str(getattr(args, "out", DEFAULT_OUT)), str(getattr(args, "data", DEFAULT_DATA))
    if out == str(DEFAULT_OUT) and data != str(DEFAULT_DATA):
        return Path(data).parent / "outputs"
    return Path(out)


def _record_action(args, command: str, code: int, error: str, secrets, extra_args: dict | None = None, strict: bool = False) -> None:
    """Append to the action log; a failure to log is reported on stderr and never changes the command's outcome, except
    with strict=True (the run-gate override): an override that cannot be recorded is refused (AGENT-09, SEC-C-004)."""
    from .ops import actionlog as AL
    try:
        actor, src = _actor(args)
        a = dict(vars(args)) if extra_args is None else extra_args
        AL.append(action_out(args), command, a, actor=actor, actor_source=src, outcome="ok" if code == 0 else "error",
                  exit_code=code, error=error, versions=_versions(args), secrets=secrets)
    except Exception as e:                             # noqa: BLE001
        if strict:
            print(f"run gate: --allow-unattested refused: the override could not be recorded in {AL.log_path(action_out(args))}: {e}", file=sys.stderr)
            raise RunGateBlocked(RUN_GATE_EXIT) from None
        print(f"warning: could not write the action log {AL.log_path(action_out(args))}: {e}", file=sys.stderr)


def _exit_code(e: SystemExit) -> tuple[int, str]:
    if isinstance(e, RunGateBlocked):
        return RUN_GATE_EXIT, e.reason
    if e.code is None:
        return 0, ""
    if isinstance(e.code, int):
        return e.code, ""
    return 1, str(e.code)


def main(argv=None):
    ap = argparse.ArgumentParser(prog="econquest", description="EconQuest sovereign tail-risk engine")
    ap.add_argument("--data", default=str(DEFAULT_DATA), help="input folder (default: %(default)s)")
    ap.add_argument("--out", default=str(DEFAULT_OUT), help="outputs folder (default: %(default)s)")
    from . import __version__ as _ver                      # EQ-C-0048: which release is installed
    ap.add_argument("--version", action="version", version=f"econquest {_ver}")
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run", help="full pipeline on the snapshot; writes outputs and the dashboard")
    r.add_argument("--paths", type=int); r.add_argument("--seed", type=int); r.add_argument("--override", choices=["Model", "All stressed", "All crisis"])
    r.add_argument("--label", default="base"); r.add_argument("--stress", action="store_true"); r.add_argument("--stress-paths", type=int, default=None); r.add_argument("--scenario", nargs="*", help="scenario keys for --stress (default: all non-historical)")
    r.add_argument("--backtest", action="store_true"); r.add_argument("--live-markets", action="store_true"); r.add_argument("--no-sobol", action="store_true")
    r.add_argument("--no-paths", action="store_true", help="do not archive simulation paths")
    r.add_argument("--as-of", type=_as_of_arg, help="model date YYYY-MM-DD (default: settings as_of, else today); fixes the run so a replay gives the same numbers")
    r.add_argument("--vintage", help="replay the inputs frozen with this fetch vintage (id, or a date for that day's latest); not with --live-markets"); r.set_defaults(fn=cmd_run)
    st = sub.add_parser("stress", help="run the scenario library (data/scenarios.json): the paper's A, B, C plus historical episodes; writes outputs/scenario_library.csv"); st.add_argument("--scenario", nargs="*", help="scenario keys (default: all)"); st.add_argument("--paths", type=int); st.add_argument("--scale", type=float, default=1.0, help="severity scale applied to every shock (1 = as defined)"); st.set_defaults(fn=cmd_stress)
    sl = sub.add_parser("scenarios", help="list the scenario library"); sl.add_argument("--shocks", action="store_true", help="print each scenario's shocks"); sl.set_defaults(fn=cmd_scenarios)
    rs = sub.add_parser("reverse-stress", help="smallest severity of each scenario and single factor (spreads, FX, LGD, PD multiplier, loading, downgrades) that breaches a book limit in data/limits.json; writes outputs/reverse_stress.json and .csv")
    rs.add_argument("--measure", default="var99_mm", choices=["var99_mm", "es99_mm", "lvar99_mm", "expected_loss_mm"]); rs.add_argument("--scenario", nargs="*", help="scenario keys (default: all)"); rs.add_argument("--factor", nargs="*", choices=list(SINGLE_FACTORS))
    rs.add_argument("--paths", type=int, help="Monte Carlo paths per run (default 20000)"); rs.add_argument("--scale-max", type=float, default=4.0, help="largest scenario scale searched"); rs.add_argument("--scenarios-only", action="store_true"); rs.add_argument("--factors-only", action="store_true"); rs.set_defaults(fn=cmd_reverse_stress)
    a = sub.add_parser("arbitrage", help="prediction-market arbitrage monitor"); a.add_argument("--live-markets", action="store_true"); a.set_defaults(fn=cmd_arbitrage)
    b = sub.add_parser("backtest", help="Kupiec, Christoffersen, Acerbi-Szekely on a history CSV (loss, var, es)")
    b.add_argument("--history", default=str(DEFAULT_DATA / "backtest_history.csv")); b.add_argument("--alpha", type=float, default=0.99); b.set_defaults(fn=cmd_backtest)
    f = sub.add_parser("fit-hazard", help="recalibrate the hazard model on a sovereign default panel (Firth logit, out-of-sample test, report)")
    f.add_argument("--panel"); f.add_argument("--build-panel", action="store_true"); f.add_argument("--fetch", action="store_true"); f.add_argument("--defaults")
    f.add_argument("--features"); f.add_argument("--start", type=int, default=1980); f.add_argument("--end", type=int, default=None, help="last row year t (default: last episode year - 1)")
    f.add_argument("--oos-start", type=int); f.add_argument("--report"); f.add_argument("--apply", action="store_true", help="propose the fit as a change (see econquest change)")
    f.add_argument("--author", help="who proposes the change (required with --apply)")
    cd = sub.add_parser("cds", help="CDS-implied PDs and model-fair spreads from data/cds_quotes.csv"); cd.set_defaults(fn=cmd_cds)
    bmk = sub.add_parser("benchmark", help="PD benchmarks: model vs rating, spread, CDS and prediction-market PDs, with a dated history and scoring")
    bmk.add_argument("--paths", type=int); bmk.add_argument("--as-of"); bmk.add_argument("--horizons", default="12m", help="comma list of 12m,6m,3m"); _token_args(bmk); bmk.add_argument("--spreadsheet-id", default="1w4OLCkv4EvDFgaO6MBOipAuY2fjAlCQJ-OjtmHJshQY"); bmk.set_defaults(fn=cmd_benchmark)
    f.add_argument("--resume", metavar="RUN_ID", help="with --fetch: resume a staged panel_history run (data/panel/staging/RUN_ID)")
    f.add_argument("--weo-vintages", help="with --fetch: WEO releases, '2007-10:2026-10' or a comma list (default Oct 2007 to the latest)")
    f.add_argument("--min-auc", type=float, default=0.75); f.add_argument("--min-events", type=int, default=30); f.set_defaults(fn=cmd_fit_hazard)
    h = sub.add_parser("hmm", help="fit the 3-state Gaussian HMM on a series CSV (spread, fx 3m, reserves 3m) or a demo"); h.add_argument("--series"); h.set_defaults(fn=cmd_hmm)
    pub = sub.add_parser("publish", help="write the run into the workbook as values (needs --write or --token-file) or save the plan")
    pub.add_argument("--paths", type=int); pub.add_argument("--seed", type=int); pub.add_argument("--mc-rows", type=int, default=2000, help="MC paths shown on the MC tab (use 100 when applying through the Sheets connector)"); _token_args(pub)
    pub.add_argument("--no-garch", action="store_true", help="skip the GARCH and Econometrics tabs"); pub.add_argument("--no-econ", action="store_true", help="skip the Econometrics tab")
    pub.add_argument("--ideas", action="store_true", help="also write the 'Trade Ideas' tab: hit rate and P&L by quarter from outputs/idea_log.csv (illustrative, Tier 3; create the tab first)")
    pub.add_argument("--rv", action="store_true", help="also write the 'Weekly RV' tab: bond rich/cheap vs model and CDS curves from outputs/bond_rv.csv and outputs/cds_curves.csv (diagnostic; create the tab with columns to AN first)"); pub.add_argument("--spreadsheet-id", default="1w4OLCkv4EvDFgaO6MBOipAuY2fjAlCQJ-OjtmHJshQY"); pub.set_defaults(fn=cmd_publish)
    gu = sub.add_parser("gui", help="local browser app: charts, tables, analyst workbench and buttons for fetch/run/garch/econ/publish")
    gu.add_argument("--host", default="127.0.0.1"); gu.add_argument("--port", type=int, default=8765); gu.add_argument("--no-browser", action="store_true"); gu.set_defaults(fn=cmd_gui)
    fe = sub.add_parser("fetch", help="pull live inputs (IMF WEO via imf-reader/weo, World Bank via wbgapi, BIS SDMX; FX from BIS WS_XRU and the ECB euro reference rates) into data/live")
    fe.add_argument("--only", help="comma list of feeds: weo,worldbank,bis,fx (fx = BIS WS_XRU and ECB EXR reference rates; bis also pulls bis_xru); single feeds: bis_xru, ecb_exr, bis_cbs, worldbank_history. Yahoo Finance is not a desk feed"); fe.add_argument("--year", type=int); fe.add_argument("--weo-version", help="e.g. October,2026")
    fe.add_argument("--apply", action="store_true", help="overwrite seed values in indicators.csv / countries.csv with live values that pass the quality gate"); fe.add_argument("--top", type=int, default=25)
    fe.add_argument("--max-change", type=float, default=0.5, help="hold a value whose change vs seed exceeds this fraction (default 0.5)"); fe.add_argument("--force", action="store_true", help="apply held values too (needs --author and --approver, or --self-approved)")
    fe.add_argument("--author", help="who applies the values (recorded in data/live/review_ledger.csv; required with --force)")
    fe.add_argument("--approver", help="second person approving forced cells (four-eyes; must differ from --author)")
    fe.add_argument("--self-approved", action="store_true", help="single-operator mode: the author approves their own forced cells, recorded as self_approved=yes"); fe.set_defaults(fn=cmd_fetch)
    mk = sub.add_parser("market", help="market data (CDS, curves, EMBI, FX) snapshots under data/live/market: import a vendor CSV export, enter attested hand-typed quotes, run the market gate, write data/cds_quotes.csv (runbook docs/runbooks/A-market-data.md)")
    mks = mk.add_subparsers(dest="market_cmd", required=True)
    m = mks.add_parser("import", help="import a Bloomberg or LSEG CSV export through the ticker map (data/live/market/ticker_map.csv, verified rows only) and save a snapshot")
    m.add_argument("file", nargs="?", help="the exported CSV"); m.add_argument("--profile", choices=["bloomberg", "lseg"]); m.add_argument("--licence", help="licence the data is used under (required; recorded on every quote)")
    m.add_argument("--map", help="ticker map CSV (default data/live/market/ticker_map.csv)"); m.add_argument("--init-map", action="store_true", help="create data/live/market/ticker_map.csv from the template (never overwrites) and stop")
    m = mks.add_parser("enter", help="enter hand-typed quotes from a CSV (asof, instrument, iso, currency, tenor_y, field, value[, unit, doc_clause, vendor_ticker]) with four-eyes attestation, and save a snapshot")
    m.add_argument("file"); m.add_argument("--author", required=True, help="who typed the quotes")
    m.add_argument("--approver", help="second person who checked them (four-eyes; must differ from --author)")
    m.add_argument("--self-approved", action="store_true", help="single-operator mode: the author approves their own quotes, recorded as self_approved=yes (as fetch --self-approved)"); m.add_argument("--note")
    m = mks.add_parser("gate", help="market quality gate on the latest quotes vs the previous snapshot (stale, range, curve, CIP, jump, basis); prints holds, writes outputs/market_gate.csv")
    m.add_argument("--as-of", "--asof", dest="asof", type=_as_of_arg, help="only snapshots saved and quotes dated on or before YYYY-MM-DD (default: everything, latest quote date)")
    m.add_argument("--strict", action="store_true", help="exit 1 when any series is held"); m.add_argument("--top", type=int, default=50)
    m = mks.add_parser("cds-quotes", help="write data/cds_quotes.csv (atomically) from the latest CDS quotes, leaving out every series the market gate holds")
    m.add_argument("--as-of", "--asof", dest="asof", type=_as_of_arg, help="point-in-time: only snapshots saved and quotes dated on or before YYYY-MM-DD")
    m.add_argument("--dest", help="file to write (default <data>/cds_quotes.csv)"); m.add_argument("--dry-run", action="store_true", help="print the rows, write nothing"); m.add_argument("--top", type=int, default=50)
    m = mks.add_parser("cds-snapshots", help="gated export of the stored CDS quotes to data/market/cds_snapshots.csv (Team B's CDS curves): appends rows that passed the market gate and the attestation check, reports each dropped row")
    m.add_argument("--snapshot", help="export only this snapshot id (default: every stored snapshot; rerunning is safe)")
    m.add_argument("--dry-run", action="store_true", help="report what would be appended, write nothing"); m.add_argument("--top", type=int, default=50)
    mk.set_defaults(fn=cmd_market)
    vd = sub.add_parser("vendor", help="licensed vendor adapters (Bloomberg BLPAPI, LSEG Data Library): PAID ROADMAP FEATURE, OFF BY DEFAULT; status of the licence gate, a dry-run test pull, or a pull that saves a snapshot (runbook docs/runbooks/A-licensed-vendors.md)")
    vds = vd.add_subparsers(dest="vendor_cmd", required=True)
    v = vds.add_parser("status", help="one row per adapter: package, licence (ok / expired / not configured), licence id, scope, expiry, usable, problems; opens no session")
    v.add_argument("--data", default=argparse.SUPPRESS, help="input folder (same as the top-level --data)")
    v = vds.add_parser("test", help="dry run: pull through the adapter and run the market gate in memory; saves nothing")
    v.add_argument("vendor", choices=["bloomberg", "lseg"]); v.add_argument("--ticker", action="append", required=True, help="vendor identifier with a verified ticker map row (repeat)")
    v.add_argument("--as-of", "--asof", dest="asof", type=_as_of_arg, help="the daily close of YYYY-MM-DD (default: the vendor's current value)")
    v.add_argument("--data", default=argparse.SUPPRESS, help="input folder (same as the top-level --data)")
    v = vds.add_parser("pull", help="pull, save a snapshot under data/live/market, gate it and append the CDS rows that pass to data/market/cds_snapshots.csv")
    v.add_argument("vendor", choices=["bloomberg", "lseg"]); v.add_argument("--ticker", action="append", required=True, help="vendor identifier with a verified ticker map row (repeat)")
    v.add_argument("--field", action="append", help="vendor field (repeat; default: the ticker map's vendor_field)")
    v.add_argument("--as-of", "--asof", dest="asof", type=_as_of_arg, help="the daily close of YYYY-MM-DD (default: the vendor's current value)")
    v.add_argument("--start", type=_as_of_arg, help="daily closes from YYYY-MM-DD (with --end)"); v.add_argument("--end", type=_as_of_arg, help="daily closes to YYYY-MM-DD (with --start)")
    v.add_argument("--no-export", action="store_true", help="save and gate only; skip the gated CDS export")
    v.add_argument("--data", default=argparse.SUPPRESS, help="input folder (same as the top-level --data)")
    vd.set_defaults(fn=cmd_vendor)
    tg = sub.add_parser("targets", help="target-state scorecard: re-score the plan's target table (coverage, data, models, track record, research, controls) from evidence; writes outputs/targets/targets.md and .csv")
    tg.add_argument("--tests", help="saved pytest output to score the test suite from (default: the latest release note's full-suite result)")
    tg.add_argument("--dest", help="folder for targets.md and targets.csv (default <out>/targets)"); tg.set_defaults(fn=cmd_targets)
    ec = sub.add_parser("evidence-clock", help="calendar-gated evidence monitor (250-day forecast record, 12-month benchmark scoring, trade-idea quarters): progress and earliest test date; read-only, --write saves outputs/evidence_monitor.csv and .md")
    ec.add_argument("--as-of", type=_as_of_arg, help="as-of date YYYY-MM-DD (default: settings as_of, else today); only data stored on or before it counts")
    ec.add_argument("--write", action="store_true", help="also write <out>/evidence_monitor.csv and evidence_monitor.md"); ec.set_defaults(fn=cmd_evidence_clock)
    rc = sub.add_parser("record", help="append today's row to the forecast record (realised book loss, next-day VaR/ES, 12m MC VaR/ES) and run the backtests on it")
    rc.add_argument("--no-mc", action="store_true", help="skip the 12-month Monte Carlo"); rc.add_argument("--backfill", type=int, help="build the record for the last N trading days (GARCH refitted every --step days, no look-ahead)"); rc.add_argument("--step", type=int, default=21); _token_args(rc); rc.add_argument("--spreadsheet-id", default="1w4OLCkv4EvDFgaO6MBOipAuY2fjAlCQJ-OjtmHJshQY"); rc.set_defaults(fn=cmd_record)
    pr = sub.add_parser("prices", help="update data/market_history/prices.csv from a saved Sheets values JSON of the Market History tab")
    pr.add_argument("--sheet-json", required=True, help="file with the values.get result(s) for 'Market History'!A2:BF (one object, a list of objects, or a list of rows)"); pr.set_defaults(fn=cmd_prices)
    rp = sub.add_parser("report", help="daily risk report (HTML + Markdown) from the latest archived run: outputs/reports/risk-report-<date>.html and latest.html; also writes outputs/alerts.json and delivers alerts if a webhook or SMTP is configured")
    rp.add_argument("--paths", type=int, help="Monte Carlo paths if no run is archived and the pipeline has to run"); rp.add_argument("--no-deliver", action="store_true", help="write alerts.json only, no webhook or email"); rp.set_defaults(fn=cmd_report)
    mo = sub.add_parser("monitor", help="weekly risk monitor (HTML + Markdown) from the latest archived run vs the run about a week earlier: outputs/reports/risk-monitor-<as_of>.html and latest-monitor.html")
    mo.add_argument("--days", type=int, default=7, help="look-back in days for the reference run (default 7)"); mo.set_defaults(fn=cmd_monitor)
    al = sub.add_parser("alerts", help="regime flips, PD and VaR moves, signal crossings, backtest failures and data issues since the previous archived run; writes outputs/alerts.json")
    al.add_argument("--webhook", action="store_true", help="post to ECONQUEST_ALERT_WEBHOOK (Slack or Teams incoming webhook)"); al.add_argument("--email", action="store_true", help="send via SMTP (ECONQUEST_SMTP_HOST, _PORT, _USER, _PASSWORD, _FROM, _TO)"); al.add_argument("--previous", help="run id to compare against instead of the previous archived run"); al.set_defaults(fn=cmd_alerts)
    li = sub.add_parser("limits", help="limits table for the book (data/limits.json) and, with --propose, the pre-trade check")
    li.add_argument("--propose", help='proposed position "country,asset_class,direction,notional_mm[,duration_yrs]", e.g. "Argentina,Eurobond,Long,10,6"')
    li.add_argument("--paths", type=int, help="Monte Carlo paths for the before and after runs (default 20000)"); li.set_defaults(fn=cmd_limits)
    gv = sub.add_parser("governance", help="governance pack: rebuild docs/governance/change-log.md from the run archive and print the model inventory status (layer1 mode, hashes, evidence sizes)")
    gv.add_argument("--limit", type=int, default=200); gv.add_argument("--docs", help="governance folder (default <home>/docs/governance)"); gv.set_defaults(fn=cmd_governance)
    rep = sub.add_parser("replicate", help="independent replication of the release-note and validation numbers from stored inputs (econquest.validation.replicate); writes replication.csv and replication.md; exit 1 on any FAIL")
    rep.add_argument("--out", dest="rep_out", metavar="DIR", help="folder for replication.csv and replication.md (default <out>/replication)")
    rep.add_argument("--quick", action="store_true", help="20,000 requested paths, loose tolerance; skips the GARCH refit")
    rep.add_argument("--only", help="comma list of groups: release,docs,backtest,hazard,scorecard,garch"); rep.set_defaults(fn=cmd_replicate)
    rpa_help = ("second-line replication: every number in the release notes 0.1.1-0.1.5 against the archived runs (read-only), the kept release zip and, with --rerun, a rerun of the 0.1.5 zip's engine (econquest.validation.replicate_archive); writes archive-replication.csv and .md; exit 1 on a mismatch without a findings-register row or a cited run missing")
    rpa = sub.add_parser("replicate-archive", help=rpa_help, description=rpa_help + " (HO-20261024-B-C-003)")
    rpa.add_argument("--out", dest="ra_out", metavar="DIR", help="folder for archive-replication.csv and .md (default <out>/replication-archive)")
    rpa.add_argument("--archive", metavar="DIR", help="run archive folder, read-only (default outputs/store/archive)")
    rpa.add_argument("--db", metavar="PATH", help="SQLite store, opened read-only; 'none' skips the cross-check (default outputs/store/econquest.sqlite)")
    rpa.add_argument("--zip", metavar="PATH", help="kept release zip; 'none' to skip (default: the kept 0.1.5 zip when present)")
    rpa.add_argument("--rerun", action="store_true", help="rerun the 0.1.5 zip's engine on frozen inputs (about a minute)")
    rpa.set_defaults(fn=cmd_replicate_archive)
    ds = sub.add_parser("dsa", help="debt sustainability fan charts (WEO baseline, stochastic shocks) and IMF ARA reserve adequacy; writes outputs/dsa.csv, dsa_fan.csv, dsa_plan.json; --apply feeds indicators 1.1, 1.2, 2.1 through the quality gate; --write writes the Debt Sustainability tab")
    ds.add_argument("--paths", type=int, help="simulation paths per country (default 10000)"); ds.add_argument("--year", type=int, help="base year (default: from --as-of)"); ds.add_argument("--as-of", help="as-of date YYYY-MM-DD (default today); sets the base year and the retrieved date"); ds.add_argument("--apply", action="store_true"); ds.add_argument("--force", action="store_true", help="apply values the quality gate would hold")
    ds.add_argument("--keys", nargs="*", default=["1.1", "1.2", "2.1"], help="indicator ids written to dsa_scorecard_feeds.csv"); _token_args(ds); ds.add_argument("--spreadsheet-id", default="1w4OLCkv4EvDFgaO6MBOipAuY2fjAlCQJ-OjtmHJshQY"); ds.set_defaults(fn=cmd_dsa)
    ed = sub.add_parser("editorial", help="editorial states for research products: draft, review (four-eyes), publish (read-only copy + manifest), correct, withdraw, list, verify")
    eds = ed.add_subparsers(dest="ed_cmd", required=True)
    kinds = ["daily_report", "weekly_monitor", "country_note", "scenario_brief"]
    e1 = eds.add_parser("draft", help="register product files as a draft, stamped with the latest (or --run-id) run")
    e1.add_argument("--kind", required=True, choices=kinds); e1.add_argument("--file", action="append", required=True, help="product file (repeat)")
    e1.add_argument("--author", required=True); e1.add_argument("--run-id", help="archived run the files were built from (default latest)")
    e2 = eds.add_parser("review", help="mark a draft reviewed; reviewer must differ from author unless --self-reviewed")
    e2.add_argument("item"); e2.add_argument("--reviewer", required=True); e2.add_argument("--note")
    e2.add_argument("--self-reviewed", action="store_true", help="single-operator self-review (recorded as self_reviewed=yes)")
    e3 = eds.add_parser("publish", help="publish a reviewed item to outputs/published/<kind>/<date>-<id>/ (read-only)"); e3.add_argument("item"); e3.add_argument("--publisher", required=True)
    e4 = eds.add_parser("correct", help="register corrected files as a new draft linked to a published item")
    e4.add_argument("item"); e4.add_argument("--file", action="append", required=True); e4.add_argument("--author", required=True)
    e4.add_argument("--reason", required=True); e4.add_argument("--run-id", help="run of the corrected files (default: the original's stamps)")
    e5 = eds.add_parser("withdraw", help="mark a published item withdrawn (kept on disk, listed in outputs/published/WITHDRAWN.jsonl)")
    e5.add_argument("item"); e5.add_argument("--by", required=True); e5.add_argument("--reason", required=True)
    e6 = eds.add_parser("list", help="editorial items"); e6.add_argument("--state", choices=["draft", "reviewed", "published", "withdrawn", "corrected"])
    e6.add_argument("--kind", choices=kinds); e6.add_argument("--limit", type=int, default=50)
    e7 = eds.add_parser("checklist", help="compliance checklist (EQ-C-0036): author's conflicts, reviewer's acknowledgement of flagged "
                        "restrictions, compliance sign-off; --show prints it (exit 1 if incomplete). publish refuses until complete")
    e7.add_argument("item"); e7.add_argument("--by", help="who records it: the author for --conflicts, the reviewer for --acknowledge, the approver for --compliance-approve")
    e7.add_argument("--conflicts", help='author\'s declaration: "no conflicts" or the text')
    e7.add_argument("--acknowledge", action="append", metavar="RESTRICTION", help="flagged use restriction the reviewer acknowledges, e.g. 6.1 (repeat)")
    e7.add_argument("--compliance-approve", action="store_true", help="compliance sign-off by a person other than the author")
    e7.add_argument("--self-signed", action="store_true", help="single-operator self-sign by the author, recorded as an exception (needs --exc)")
    e7.add_argument("--exc", help="exception id EXC-nnn from docs/governance/issues-log.md (required with --self-signed, as change approve)")
    e7.add_argument("--note", help="sign-off note"); e7.add_argument("--show", action="store_true", help="print the checklist evaluated now")
    eds.add_parser("verify", help="check the ledger chain and every published copy against its manifest; exit 1 on any problem")
    ed.set_defaults(fn=cmd_editorial)
    rv = sub.add_parser("review", help="review ledger for gate-held input cells (data/live/review_ledger.csv): decide, list, approve or apply against a saved vintage")
    rvs = rv.add_subparsers(dest="review_cmd", required=True)
    rd = rvs.add_parser("decide", help="append one decision per cell (apply, hold or reject): one cell (--table --key --country), or several held cells (--cell repeated, --all-pending); applying a held cell needs --approver or --self-approved")
    rd.add_argument("--table", choices=["Inputs", "Country Profile"], help="one cell's table (with --all-pending: only this table)"); rd.add_argument("--key", help="indicator id (e.g. 1.1) or profile field")
    rd.add_argument("--country", help="one cell's country (with --all-pending: only this country)"); rd.add_argument("--decision", required=True, choices=["apply", "hold", "reject"])
    rd.add_argument("--cell", nargs=3, action="append", metavar=("TABLE", "KEY", "COUNTRY"), help="a held cell from data/live/review.csv (repeat for several); live value and gate status are taken from it")
    rd.add_argument("--all-pending", action="store_true", help="every held cell with no decision yet (as `review list --pending`); one ledger row and one action-log row per cell")
    rd.add_argument("--author", required=True); rd.add_argument("--approver"); rd.add_argument("--self-approved", action="store_true", help="single-operator self-approval (recorded as self_approved=yes)")
    rd.add_argument("--note"); rd.add_argument("--vintage", help="vintage id the decision applies to"); rd.add_argument("--live", type=float, help="live value the decision applies to")
    rd.add_argument("--gate-status", choices=["ok", "hold", "missing"], help="gate status of the cell (hold => four-eyes)")
    rl = rvs.add_parser("list", help="latest decision per cell; --pending lists the held cells still waiting for one"); rl.add_argument("--country"); rl.add_argument("--table"); rl.add_argument("--limit", type=int, default=200)
    rl.add_argument("--pending", action="store_true", help="cells the last fetch held (data/live/review.csv) that have no decision yet")
    rl.add_argument("--vintage", metavar="ID", help="with --pending: the held cells of this saved vintage (data/live/vintages/ID) and their effective "
                    "status (released: an approved apply binds to this vintage or its live value; held: stays on seed)")
    ra = rvs.add_parser("approve", help="decide held cells against a saved vintage (default: the latest), offline: each ledger row carries the vintage id and the cell's live value from it; applying a held cell needs --approver or --self-approved; then `review apply`")
    ra.add_argument("cells", nargs="+", metavar="TABLE KEY COUNTRY", help='one or more cells as triples, e.g. "Country Profile" fx3m Brazil Inputs 1.3 Vietnam (table: Inputs or "Country Profile")')
    ra.add_argument("--author", required=True); ra.add_argument("--approver", help="second person (four-eyes); must differ from --author")
    ra.add_argument("--self-approved", action="store_true", help="single-operator self-approval (recorded as self_approved=yes)")
    ra.add_argument("--decision", choices=["apply", "hold", "reject"], default="apply", help="default apply; hold or reject keeps the cells on seed (no approver needed)")
    ra.add_argument("--vintage", metavar="ID", help="saved vintage the decisions bind to (default: the latest under data/live/vintages/)"); ra.add_argument("--note")
    rp = rvs.add_parser("apply", help="apply a saved vintage to indicators.csv and countries.csv offline (no refetch): its ok cells plus the held cells approved for it; never forces")
    rp.add_argument("--vintage", metavar="ID", help="saved vintage to apply (default: the latest); an older one also re-applies its ok cells over newer values")
    rp.add_argument("--dry-run", action="store_true", help="print what an apply would do (effective status per cell) and write nothing")
    rp.add_argument("--allow-older", action="store_true", help="apply a --vintage that is not the latest (its ok cells overwrite newer values)")
    rv.set_defaults(fn=cmd_review)
    ch = sub.add_parser("change", help="change approvals for data/assumptions.json, data/limits.json and data/compliance.json: propose, approve, reject, apply, list, show, verify, baseline (data/approvals/)")
    chs = ch.add_subparsers(dest="change_cmd", required=True)
    c = chs.add_parser("propose", help="record a proposed change (the file is not touched)")
    c.add_argument("file", choices=["assumptions.json", "limits.json", "compliance.json"])
    c.add_argument("--set", action="append", metavar="/POINTER=JSON", help="e.g. --set /layer4/lgd_sd=0.12 (repeatable; strings quoted)")
    c.add_argument("--patch-file", help="JSON file {pointer: value}"); c.add_argument("--replace-file", help="whole new file")
    c.add_argument("--author", required=True); c.add_argument("--reason", required=True)
    c.add_argument("--tier", choices=["limit", "1", "2", "3", "run"], help="default: inferred; may raise, never lower")
    c.add_argument("--allow-new-keys", action="store_true"); c.add_argument("--allow-type-change", action="store_true")
    c = chs.add_parser("approve", help="four-eyes approval (approver other than the author), or --self-approved with --exc EXC-nnn")
    c.add_argument("id"); c.add_argument("--approver"); c.add_argument("--self-approved", action="store_true")
    c.add_argument("--exc", help="exception id EXC-nnn from docs/governance/issues-log.md (required with --self-approved)"); c.add_argument("--note")
    c = chs.add_parser("reject", help="reject or withdraw a change not yet applied"); c.add_argument("id"); c.add_argument("--by", required=True); c.add_argument("--reason")
    c = chs.add_parser("apply", help="write an approved change (refused if the file changed since the proposal)"); c.add_argument("id"); c.add_argument("--actor")
    c = chs.add_parser("list", help="proposals and their status"); c.add_argument("--status", choices=["proposed", "approved", "rejected", "applied"]); c.add_argument("--limit", type=int, default=50)
    c = chs.add_parser("show", help="one proposal with its diff and events"); c.add_argument("id")
    chs.add_parser("verify", help="verify the hash-chained log and report drift (hand edits outside the tool); exit 1 on failure")
    c = chs.add_parser("baseline", help="record a file's current sha256 as accepted (first use, or accepting reported drift with four-eyes)")
    c.add_argument("file", choices=["assumptions.json", "limits.json", "compliance.json"]); c.add_argument("--actor", required=True); c.add_argument("--reason", required=True)
    c.add_argument("--approver"); c.add_argument("--self-approved", action="store_true"); c.add_argument("--exc")
    ch.set_defaults(fn=cmd_change)
    ru = sub.add_parser("runs", help="list archived runs with code and data versions"); ru.add_argument("--limit", type=int, default=20); ru.set_defaults(fn=cmd_runs)
    at = sub.add_parser("attest", help="attest hand-entered cells (adjustments, cds_quotes, prediction_markets) in the review ledger, or --list the unattested ones")
    at.add_argument("--file", choices=["adjustments", "cds_quotes", "prediction_markets"]); at.add_argument("--author"); at.add_argument("--approver", help="second person (four-eyes; must differ from --author)")
    at.add_argument("--self-approved", action="store_true", help="single-operator self-attestation, recorded as self_approved=yes"); at.add_argument("--note")
    at.add_argument("--all", action="store_true", help="re-attest every cell, not only those not yet attested"); at.add_argument("--list", action="store_true", help="print the unattested cells")
    at.set_defaults(fn=cmd_attest)
    au = sub.add_parser("audit", help="audit trail: provenance, transform, vintage and gate decision for every Inputs and Country Profile cell (data/audit_trail.csv, Audit Trail tab)")
    _token_args(au); au.add_argument("--spreadsheet-id", default="1w4OLCkv4EvDFgaO6MBOipAuY2fjAlCQJ-OjtmHJshQY"); au.set_defaults(fn=cmd_audit)
    ga = sub.add_parser("garch", help="GARCH(1,1)-t and DCC-GARCH volatility layer from data/market_history; writes outputs/garch and the GARCH tab plan")
    ga.add_argument("--quotes", help="CSV of ticker, market price of the ATM 63-day put (for implied vol)"); _token_args(ga)
    ga.add_argument("--as-of", type=_as_of_arg, help="fit only prices dated on or before YYYY-MM-DD (default: settings as_of, else every row)")
    ga.add_argument("--vintage", help="replay the inputs frozen with this fetch vintage; --as-of defaults to the vintage date")
    ga.add_argument("--spreadsheet-id", default="1w4OLCkv4EvDFgaO6MBOipAuY2fjAlCQJ-OjtmHJshQY"); ga.set_defaults(fn=cmd_garch)
    ec = sub.add_parser("econ", help="econometrics toolkit (stationarity, AR+GARCH, cointegration, SVAR, Kalman, regimes, premia, EVT, copulas, forecasts, event study) from data/market_history")
    _token_args(ec); ec.add_argument("--spreadsheet-id", default="1w4OLCkv4EvDFgaO6MBOipAuY2fjAlCQJ-OjtmHJshQY"); ec.set_defaults(fn=cmd_econ)
    ide = sub.add_parser("ideas", help="trade-idea log (illustrative, Tier 3, GOV-032): log an archived base run's Playbook ideas, mark them against Market History, "
                                       "report hit rate and P&L (outputs/idea_log.csv, idea_report.md/.csv); run and record update it too")
    ids = ide.add_subparsers(dest="ideas_cmd", required=True)
    i1 = ids.add_parser("log", help="advance the log by an archived run (default: the latest base run; stress runs refused)"); i1.add_argument("--run-id")
    i2 = ids.add_parser("mark", help="mark open ideas to a trading day (default: the last complete day in Market History, as record uses)")
    i2.add_argument("--as-of", type=_as_of_arg, help="mark date YYYY-MM-DD; only prices on or before it are used")
    ids.add_parser("report", help="print outputs/idea_report.md"); ide.set_defaults(fn=cmd_ideas)
    sv = sub.add_parser("serve", help="JSON API, SSE and dashboard"); sv.add_argument("--host", default="127.0.0.1"); sv.add_argument("--port", type=int, default=8080); sv.set_defaults(fn=cmd_serve)
    n = sub.add_parser("notes", help="country notes (HTML, PDF with --pdf when Chrome/Chromium is found): outputs/notes/")
    n.add_argument("--country", nargs="*"); n.add_argument("--pdf", action="store_true"); n.add_argument("--chrome", help="browser binary for --pdf (default: search; or $ECONQUEST_CHROME)"); n.add_argument("--dest"); n.set_defaults(fn=cmd_notes)
    b = sub.add_parser("briefs", help="scenario briefs from stress.json, archived stress runs and reverse_stress.json: outputs/briefs/")
    b.add_argument("--scenario", nargs="*"); b.add_argument("--pdf", action="store_true"); b.add_argument("--chrome"); b.add_argument("--dest"); b.set_defaults(fn=cmd_briefs)
    pp = sub.add_parser("publish-preview", help="diff the saved publish plan against a values:batchGet JSON or a previous plan before publish --write (no network)")
    pp.add_argument("--baseline", nargs="+", metavar="FILE", help="what the workbook holds now: values:batchGet JSON file(s) saved from the --urls, or a previous publish_plan.json")
    pp.add_argument("--plan", metavar="FILE", help="the new plan to check (default: <out>/publish_plan.json)")
    pp.add_argument("--tolerance", type=float, default=1e-6, help="numbers within tolerance x max(1, |old|, |new|) count as unchanged (default 1e-6)")
    pp.add_argument("--large", type=float, default=0.25, help="relative change flagged as large (default 0.25 = 25%%); sign flips and cleared cells are always large")
    pp.add_argument("--dest", metavar="DIR", help="folder for the HTML and CSV report (default: <out>/preview)"); pp.add_argument("--urls", action="store_true", help="print the batchGet URLs to fetch the live values")
    pp.add_argument("--spreadsheet-id", default="1w4OLCkv4EvDFgaO6MBOipAuY2fjAlCQJ-OjtmHJshQY", help="workbook the --urls point at (default: the Risk Desk workbook)"); pp.set_defaults(fn=cmd_publish_preview)
    from .ops.commands import register as register_ops
    register_ops(sub, HOME_DIR)   # schedule install|uninstall|show, health, backup [--verify], restore-drill (EQ-C-0021/0022)
    lg = sub.add_parser("log", help="operator action log (outputs/store/actions.jsonl, hash-chained): verify the chain or tail it")
    lgs = lg.add_subparsers(dest="log_cmd", required=True)
    lgs.add_parser("verify", help="check seq, prev_hash, row_hash and the head; exit 1 on any break")
    lt = lgs.add_parser("tail", help="print the last rows"); lt.add_argument("-n", type=int, default=20); lt.add_argument("--json", action="store_true")
    lg.set_defaults(fn=cmd_log)
    for name, p in sub.choices.items():                   # EQ-C-0034: per-invocation override of the run gate
        if _gated(name):
            p.add_argument("--allow-unattested", action="store_true",
                           help="proceed even if the run gate would block on unattested hand-entered cells (recorded in the action log)")
    args = ap.parse_args(argv)
    writer = hasattr(args, "token_file")                  # a subcommand that can write the workbook
    writes = _will_write(args)
    label = action_label(args, writes)
    secrets = [os.environ.get(k, "") for k in (TOKEN_ENV, "ECONQUEST_SMTP_PASSWORD", "ECONQUEST_ALERT_WEBHOOK")] + [getattr(args, "token", None) or ""]
    code, err = 0, ""

    def log_override(found):
        _record_action(args, "run-gate override", 0, "", secrets,
                       extra_args={"command": found["command"], "policy": found["mode"], "policy_key": found["key"],
                                   "unattested": found["counts"], "total": found["total"]}, strict=True)
    try:
        restricted_gate(args, writes)                     # HO-20261024-A-C-007: before the run gate and any override
        run_gate(args, writes, log_override=log_override)
        if writer:
            args.token = None if args.dry_run else resolve_token(args)
            secrets.append(args.token or "")
        args.fn(args)
        if writer and args.dry_run:
            print("Dry run: plan saved only; no token looked up and nothing sent to Sheets.", file=sys.stderr)
        elif writer and not args.token and args.cmd != "publish":     # publish prints its own hint
            print("Workbook not written: plan saved only. Pass --write to write it (token from $ECONQUEST_SHEETS_TOKEN or the Keychain) or --token-file PATH.", file=sys.stderr)
    except SystemExit as e:
        code, err = _exit_code(e)
        raise
    except KeyboardInterrupt:
        code, err = 130, "interrupted"
        raise
    except BaseException as e:
        code, err = 1, f"{type(e).__name__}: {e}"
        raise
    finally:
        if label:
            _record_action(args, label, code, err, secrets)


if __name__ == "__main__":
    main()
