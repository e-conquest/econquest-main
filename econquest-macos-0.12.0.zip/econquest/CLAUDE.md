# econquest: instructions for Claude sessions

econquest is a sovereign tail-risk and geopolitical engine (Python) whose results feed the Risk Desk
Google Sheet. It is built by a team of agents defined in `.claude/agents/` and run under
`team/operating-model.md`.

## Who you are in this session
- Start sessions as the team lead: `claude --agent agent-08-tech-lead-orchestrator`. If a session was
  started without `--agent`, act as AGENT-08 anyway: plan, route work to the AGENT-01 to AGENT-11
  subagents, review their reports, and decide merge readiness.
- Your team letter (A = Data, B = Models, C = Platform) comes from the session brief ("You are Team B")
  or `$ECONQUEST_TEAM`. Pass `--team` on every `teamctl` call. If neither says, ask Sam before
  changing anything. The three team sessions share this folder, so never write `team/local.team` here.

## Rules that hold for every agent
1. Every change belongs to a ticket `EQ-<team>-nnnn` on `team/board/<team>.csv`.
2. Edit only paths your team owns. Before editing a file, run
   `python team/teamctl.py checkpoint <path> --ticket <id>`: it refuses other teams' files (send a
   handoff instead, `team/handoff-protocol.md`) and saves the original, which is the only undo because
   this folder is not under git. `python team/teamctl.py check --ticket <id>` must pass before Done.
3. Other sessions edit this folder at the same time. If a test fails in a file your team does not own,
   check `teamctl owner` and the other team's log before debugging it: it may be mid-change.
4. Log work in `team/logs/<team>.jsonl` with `teamctl log`; read the last 30 lines before starting.
5. Model and limit changes follow `docs/governance/change-control.md`. Tier 1 changes, live workbook
   publishes, credentials, licences and anything needing Sam's data are escalated to Sam, never done
   on an agent's own authority.
6. Tests: `python -m pytest -q tests` from this folder. Add a regression test for every defect fixed.
7. This cloud environment cannot reach IMF, World Bank, BIS or Yahoo; live fetches run on Sam's Mac.
   Work offline from `data/live/vintages/<date>/`.
8. Do not hand-edit generated files: `docs/governance/change-log.md`, `docs/validation/hazard-fit-report.md`,
   `team/catalog/modules.md`, `team/board/jira-import.csv`.

## Commands
```
python -m econquest run --stress --backtest     # base + stress run (100,000 requested, 131,072 Sobol paths simulated)
python -m econquest runs --limit 5             # recent runs with code/data hashes
python -m pytest -q tests                      # full suite
python team/teamctl.py status                  # board, inbound handoffs, recent activity
python team/teamctl.py catalog                 # regenerate the codebase catalog
```
