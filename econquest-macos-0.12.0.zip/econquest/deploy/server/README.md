# econquest server option (EQ-C-0157)

**Optional and off by default.** This folder lets econquest's scheduled jobs, nightly backup, restore drill and
health check run in a container on a server instead of Sam's Mac. Nothing here is deployed anywhere, no image is
pushed to a registry, and the Mac install (`install.sh`, launchd plists from `econquest schedule install`) is
unchanged. Whether to use it, which host, and the credentials are Sam's decision (parked item "Server deployment").
Security note: `team/security/SEC-C-024.md`.

| File | What it is |
|---|---|
| `Dockerfile` | Pinned base (`python:3.13.17-slim-trixie@sha256:d98cc29d…`), deps from `requirements-lock.txt` with `--require-hashes`, non-root user `econquest` (uid 10001), volumes for data, outputs, backups, `HEALTHCHECK` |
| `Dockerfile.dockerignore` | Allow-list: only `econquest/`, `pyproject.toml`, `requirements-lock.txt` and the entrypoint go into the build |
| `entrypoint.sh` | `run` / `check` / `plan` / `selftest` go to `econquest server …`; anything else goes to `econquest …` |
| `compose.example.yaml` | Example only: volumes, read-only root, no capabilities, no ports, secret-file mounts (commented) |
| `.env.example` | Variable names with no values |

## What runs

`econquest server run` (the container's default command) is a small stdlib loop, not system cron. It reads the same
job table that launchd installs on the Mac: `schedule.DEFAULT_JOBS`, then `<home>/ops.json`, through
`schedule.effective_job` and `resolve_steps`. Every job goes through `econquest.ops.jobs.run_job`, so
`outputs/logs/jobs/` and `econquest health` work exactly as on the Mac. Times are New York wall-clock times
(`TZ=America/New_York` in the image), and DST is handled by `zoneinfo`.

```
econquest server plan --days 1        # every job slot in the next day, NY and UTC
econquest server plan --days 7 --json
```

A slot missed while the host was down runs once when the loop is back, which is what launchd does on wake. If a job
is still running when its next slot comes, that slot is skipped and logged. The loop writes
`outputs/logs/schedule.json` (runner `server`), which the health check needs for missed-run detection, and a
heartbeat every 30 s in `outputs/logs/server/heartbeat.json`.

The switch: the loop starts only with `ECONQUEST_SERVER_ENABLED=1`. With any other value it prints "off", runs
nothing and exits 3.

## Health, backups, restore drill

- Container health: `HEALTHCHECK` runs `econquest server check --healthcheck`. It passes while the scheduler's
  heartbeat is less than 5 minutes old. `--strict` also fails on a critical alert in `outputs/health.json`. Nothing
  listens on a port.
- The 15-minute `health` job and the nightly `backup` job (`--verify`) are in the job table. The image sets
  `ECONQUEST_BACKUP_DEST=/backups/nightly`, so backups go to the backup volume. Put that volume on storage other
  than the data disk.
- Restore drill: `docker compose run --rm econquest restore-drill`. It restores the latest backup into a temp
  folder, checks every hash and runs the smoke check.
- `econquest server check` is read-only. It checks the data volume, that outputs is writable, the backup folder
  (set, writable, outside data/ and outputs/), that every job step can be resolved (executable found, module
  importable), the credential sources (names only) and, when on, the heartbeat.

## Selftest (no docker needed)

```
econquest server selftest [--keep] [--report PATH] [--json]
```

This runs a compressed day. It copies the data folder (`--data`, default `<home>/data`) into a temp home and starts
a fake clock at the next minute. Every job fires once at its next slot (monthly jobs on their day), and each fire is
checked against `next_fire`. The backup and health steps run for real. Every other step is checked without running:
its executable is found and its `-m` module imports. This means no network call is made and the model is never
run. Then the backup is verified, the restore drill and the health check run, and the healthcheck runs. The source
data is compared before and after (path, size, mtime). Any change is a failure. `demo_server(out_dir)` in
`econquest/ops/server.py` runs the same selftest for a possible demo row.

Inside the image, with the data volume mounted read-only:

```
docker run --rm --network none --read-only --tmpfs /tmp \
  -v "$PWD/data:/srv/econquest/data:ro" -v "$PWD/scratch/outputs:/srv/econquest/outputs" \
  -v "$PWD/scratch/backups:/backups" econquest-server:local selftest
```

## Credentials

The macOS Keychain does not exist on a server. Every credential econquest reads already has an environment
variable. The server adds a file fallback for secret mounts: when `<NAME>` is unset and `<NAME>_FILE` names a
regular file that is not group- or world-writable, non-empty and under 64 KB, its content becomes `<NAME>` in the
job steps' environment. Only the source is logged (`env`, `file`, `missing`, `refused: <reason>`), never the value.

| Variable | Used by | Notes |
|---|---|---|
| `UCDP_API_TOKEN` / `_FILE` | `data_ops` job (incremental UCDP pull) | Missing: health reports `events_incremental_error`; the rest of data_ops still runs |
| `ECONQUEST_SHEETS_TOKEN` / `_FILE` | Only a manual `econquest … --write` | No scheduled job writes the workbook |
| `ECONQUEST_ALERT_WEBHOOK` / `_FILE`, `ECONQUEST_SMTP_*` (`_PASSWORD_FILE`) | Health job alert delivery | Optional; unset means alerts stay in `outputs/health.json` |

`<home>/.ops.env` (chmod 600) is still read by `jobs.run_job`, as on the Mac.

## Data volume

The image has code only: no `data/`, no `data/live`, no outputs, no secrets. Seed the data volume once from the
release's `release-data/` or a copy of the desk's `data/`, as `install.sh` does for a fresh install. After that it
lives on the volume and in the backups.

## Build (local only)

```
docker build -f deploy/server/Dockerfile -t econquest-server:local .
```

On a build host behind a TLS-inspecting proxy, pass its CA as a BuildKit secret, which is never stored in a layer:
`--secret id=build_ca,src=/path/ca.pem`. If Docker Hub rate-limits, use `--build-arg PYTHON_BASE=<mirror>/library/python:3.13.17-slim-trixie@sha256:d98cc29d3266e535dd9da1099688d9cb3ca4753813571e071763d17725460962`
(same digest). Tested 2026-10-26 in the cloud container: the image is 981 MB on disk (226 MB content), and
selftest passes inside it with `--network none`, a read-only root and a read-only data mount.
