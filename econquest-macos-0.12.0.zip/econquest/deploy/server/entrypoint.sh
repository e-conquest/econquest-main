#!/bin/sh
# econquest server entrypoint (EQ-C-0157). The scheduler is `econquest server run`: a stdlib loop over the same job
# table launchd installs on the Mac (schedule.DEFAULT_JOBS + ops.json, New York times), each job through
# econquest.ops.jobs.run_job. It refuses to start unless ECONQUEST_SERVER_ENABLED=1. No system cron.
#
#   (no args) | run | check | plan | selftest   -> econquest server <that>
#   anything else                              -> econquest <args>   (e.g. backup --verify, restore-drill, health)
set -eu
umask 077
if [ "$(id -u)" = "0" ]; then
  echo "[entrypoint] refusing to run as root: the image runs as the econquest user (uid 10001)" >&2
  exit 64
fi
case "${1:-run}" in
  run|check|plan|selftest)
    cmd="${1:-run}"; [ "$#" -gt 0 ] && shift
    exec econquest server "$cmd" "$@" ;;
  *)
    exec econquest "$@" ;;
esac
