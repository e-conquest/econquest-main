# Runbook: restore inputs, live data and the workbook

Ticket EQ-A-0009. Owner: Team A, AGENT-06. Operator: Sam on the Mac, or an agent working on the project
copy. Written 2026-10-23 from `econquest/ingestion/feeds.py`, `install.sh` and the README.

## Purpose

Put `data/` or the workbook back to a known good state after a bad apply, a lost file or a bad publish.

## When

- A bad `fetch --apply` or `dsa --apply`.
- A reinstall that overwrote `data/`.
- A deleted or corrupted file.
- Wrong values or broken formulas in the workbook.

## Where good copies live

| What | Copy | Notes |
|---|---|---|
| `indicators.csv`, `countries.csv` before an apply | `data/live/snapshots/<UTC ts>-pre-apply/` | From EQ-A-0005/0006: one folder per apply, read-only |
| What a pull returned (live tables, raw feeds, provenance, gate output) | `data/live/vintages/<id>/`, listed in `data/live/vintages/index.csv` | From EQ-A-0005/0006. Ids are `<YYYY-MM-DD>T<HHMMSS>Z-<hash8>`; the older folder `2026-10-23/` is a date-only id. Read-only; never edit |
| Analyst decisions on held cells | `data/live/review_ledger.csv` | From EQ-A-0006. Append-only; never trim |
| October 2026 seed inputs (pre-live) | `tests/seed_data/` | Test fixture: copy **from** it, never edit it |
| Whole `data/` and the run store `outputs/store` | Nightly `econquest backup --verify` (23:30 job from `econquest schedule`) into `$ECONQUEST_BACKUP_DEST`, default `~/econquest-backups/nightly`; 14 daily + 8 weekly kept. Also `~/econquest-backups/<UTC ts>/` made by every reinstall, `~/econquest-backup/data-<ts>/` from the fetch runbook, and the Claude project copy `econquest/data/` | Point `ECONQUEST_BACKUP_DEST` at an off-machine folder (iCloud Drive, external disk) to cover a lost Mac |
| Workbook formulas | Drive: "Geopolitical-Macro Risk Desk (formula backup 2026-10-20)" | All-formula version from before values-only publishing |
| Workbook values | Sheets version history, or republish | |

The nightly backup covers `forecast_record.csv`, `benchmarks.csv`, `market_history/prices.csv` and the run store.
Check it works with a monthly drill:

```bash
econquest backup --list                      # backups, oldest first
econquest backup --verify-only <archive>     # re-hash one backup
econquest restore-drill                      # restore the latest into a temp folder, verify, smoke-test, time it;
                                             # writes outputs/restore_drill.json
```

## Prerequisites

- Stop scheduled jobs while restoring: `econquest schedule uninstall --load` (reinstall them afterwards with
  `econquest schedule install --load`).
- Copy the current state first, even if it is bad: `mkdir -p ~/econquest-backup && cp -Rp ~/econquest/data ~/econquest-backup/data-broken-$(date +%Y%m%d-%H%M)`.
- Reinstalls are safe from 0.1.1 on (EQ-C-0016): `install.sh` backs up `data/` and `outputs/` to
  `~/econquest-backups/<UTC ts>/`, never overwrites them, and only adds data files the new version brings.
  Older installers (0.1.0) did overwrite `data/`: back up by hand before replacing one.

## Steps

**A. Undo the last apply** (indicators and countries):
```bash
cd ~/econquest
ls -1 data/live/snapshots | tail -3                       # pick the folder from just before the bad apply
S=data/live/snapshots/<ts>-pre-apply
cp $S/indicators.csv $S/countries.csv data/ && chmod u+w data/indicators.csv data/countries.csv
```
Without snapshots (older install), copy the two files from `~/econquest-backup/data-<ts>/`. Use
`tests/seed_data/` only as a last resort, because it holds the pre-live seeds.

**B. Restore `data/live/` working tables from a vintage:**
```bash
V=data/live/vintages/<id>
cp $V/live_inputs.csv $V/live_profile.csv $V/provenance.csv $V/raw_*.csv $V/review.csv data/live/ && chmod u+w data/live/*.csv
```
This does not change `indicators.csv`. To re-run a past run exactly, use replay (EQ-A-0007):
`load_universe(data_dir, vintage=<id>)`, and `econquest run --vintage <id>` once Team C's flag ships. To get a
vintage's values back into the inputs, restore the matching pre-apply snapshot (A) or run a new `fetch --apply`.

**C. Restore a whole file or folder from a nightly backup:**
```bash
econquest restore-drill --backup <archive> --keep     # verified restore into a temp folder; prints kept_at
cp -p <kept_at>/data/<file> data/                   # copy back only what you need
```
Or copy from `~/econquest-backups/<ts>/` (reinstall backups) or `~/econquest-backup/data-<ts>/`. Use the
project copy if the Mac copies are gone. Never copy over `data/live/vintages/` or `review_ledger.csv`; add to them only.

To add back a vintage or snapshot folder that is missing, copy it and then make it read-only again: a restore
writes every file 0644, while the T4 control needs vintage and snapshot files 0444 (SEC-A-006 L7; Team C's fix is
pending under HO-20261024-A-C-006, until then this `chmod` is the control):
```bash
cp -Rp <kept_at>/data/live/vintages/<id> data/live/vintages/          # only if data/live/vintages/<id> is missing
chmod -R a-w data/live/vintages/<id>                                  # files 0444, folder read-only again
# the same for data/live/snapshots/<id>, data/panel/vintages/<id> and data/live/market/snapshots/<id>
python -c "from pathlib import Path; from econquest.ingestion.feeds import verify_vintage; print(verify_vintage(Path('data'), '<id>'))"   # live vintages
```

**D. Workbook values:** restore `data/` first (A to C), then republish (`A-publish.md`).

**E. Workbook formulas:** open the Drive formula backup, right-click the tab you need, choose *Copy to >
Existing spreadsheet*, and pick the live workbook. Rename the tab to the original name only after checking
anchors with Team C (C11). For a recent mistake, *File > Version history* on the live workbook is faster.

## Verification

```bash
cd ~/econquest
.venv/bin/python -m pytest -q tests              # suite passes
econquest run && econquest runs --limit 3        # data_hash equals the run you restored to
econquest audit                                  # origin counts match that date's audit
```

For A and B, `data_hash` must equal the hash recorded on the last good run (`econquest runs`, or the
`data_hash` column of `forecast_record.csv`).

## Failure handling

- Hash does not match: another file differs. Per-file hashes are in `provenance.versions.data_files` of
  `outputs/run_latest.json`. Compare them between the current run and the good run (that run's archived
  summary in `outputs/store/`) and restore the file whose hash differs. The hash leaves out
  `live/vintages/`, `forecast_record.csv`, `benchmarks.csv` and `audit_trail.csv`
  (`econquest/versioning.py`, which is being extended now), so check those files by hand.
- Tests fail after restore: check `teamctl owner` for the failing file. If it is not data, it is not
  a restore problem.
- No good copy exists: stop. Report what was lost to AGENT-08. Do not rebuild values from memory.

## Drill evidence (PI-5)

Ticket EQ-A-0043. Run by AGENT-09 on 2026-10-24, between 01:51 and 01:55 UTC, in the cloud project copy:
- Python 3.13.17, econquest 0.1.5.
- The commands are `econquest backup` and `econquest restore-drill`. They are registered by `register_ops` in
  `econquest/cli.py` and live in `econquest/ops/commands.py` and `econquest/ops/backup.py` (Team C, EQ-C-0022).

**Isolation.**
- Nothing ran against the real `data/`. Each drill used a scratch home in the session scratchpad
  (`/tmp/claude-0/-home-claude-econquest-main/4d046af0-0329-5499-894e-87a0bbd3789c/scratchpad/drill/`).
- That home held copies of `data/` and `outputs/store`, with `ECONQUEST_HOME`, `ECONQUEST_BACKUP_DEST`/`--dest` and
  `TMPDIR` all pointing there.
- Wall times are measured around each command with `date +%s.%N`.

| Drill | What was backed up | Files | Bytes (uncompressed / archive) | `backup --verify` | `restore-drill --keep` (wall) | Drill's own timing |
|---|---|---:|---|---|---|---|
| D1: copy of the real `data/` + `outputs/store` | 59 data files, 90 store files | 149 | 151,571,333 / 114,150,872 | rc 0, 7.1 s (archive 4.3 s + verify), "verify OK (149 files)" | rc 0, 4.5 s, PASS | restore 1.97 s, total 2.78 s, target < 4 h |
| D2: D1 + fixture vintages, ledger and snapshots | as D1, plus 2 indexed vintages saved with `save_vintage`, 1 four-eyes `apply` ledger row, an `apply_vintage` pre-apply snapshot and a replay snapshot | 195 | 159,774,462 / 114,845,029 | rc 0, 7.0 s, "verify OK (195 files)" | rc 0, 5.2 s, PASS | restore 2.36 s, total 3.15 s |

**What the commands verified.**
- `backup --verify`: the archive sha256 equals the sidecar's, every member's sha256 equals the manifest, and no member
  is missing or extra.
- `restore-drill`: the same check on the restore, then a smoke check:
  - `load_universe`: 18 countries, 24 positions;
  - the run store: 70 runs, latest `20261024T011734-stress-TAPER13`;
  - `data_hash` equal to the backup's: D1 `af758691c6b94f89`, D2 `c947471d59040a46`.
- Reports went to `<home>/outputs/restore_drill.json` and `<home>/outputs/logs/restore-drill-<ts>.json`.

**Independent re-verification of the restored copy.** Script: `scratchpad/sec43/reverify.py`.

| Check | D1 (real data) | D2 (fixtures) |
|---|---|---|
| Byte compare, restored vs source | 149/149 present; every `data/` file identical | 195/195; every `data/` file identical |
| `outputs/store/*.sqlite` | Bytes differ by design (backup takes a sqlite online snapshot). The logical dump (`iterdump`) is identical for `econquest.sqlite` and `panoptix.sqlite` | same |
| `feeds.verify_vintage` on every vintage | `2026-10-23`: VintageIntegrityError "no row in index.csv", on the source **and** the restore (see note 1) | 3/3 ok, on source and restore: `2026-10-23` 707bee70e180, `…T010000Z-fba0c9f2`, `…T020000Z-e78a10e0` |
| Review ledger (`data/live/review_ledger.csv`) | Absent in `data/` (no decisions recorded yet) | 1 row, sha256 f25190945138… identical |
| Approvals chain (`ops.approvals.verify_chain`) | ok, 6 rows, head seq 6 `0fba74a5…`, identical | same |
| Data room `build_data_room(as_of)` + `verify_data_room` on the restore | as of 2026-10-23: VERIFIED, 25 files, 14,008,426 bytes, 0 anchors failed, 1 unanchored (legacy vintage). `manifest_sha256 60d5b083878d57ea…` equals the room built from the source | as of 2026-10-24: VERIFIED, 69 files, 21,774,492 bytes, 0 failed, 4 warnings (3 vintages `altered` by the withheld `raw_yahoo.csv`, 1 pre-apply snapshot unanchored), replay snapshot ok, approvals chain ok. `manifest_sha256 5d9fa9dfa8c1f49c…` equals the source room |

Build and verify times for the room: 3.5 to 6.2 s to build, under 0.1 s to verify. The whole re-verification took
8.7 s (D1) and 12.2 s (D2).

**Notes and defects found.**
1. The only vintage in the real `data/` (`2026-10-23`, a legacy date id) has no `vintages/index.csv` row yet. The
   index is created by the first `save_vintage` on the Mac. So the D1 restore was proven by byte comparison, not by
   verify_vintage. The first `save_vintage` also hashes the legacy folder as it is then (trust on first use): check
   that folder against a backup before that first Mac fetch (SEC-A-006 I4).
2. A restore drops the read-only mode. Vintage and replay-snapshot files are `0444` in the source and `0644` after
   the restore, because `ops/backup.py:126` stores every member as 0644. Content and hashes are unaffected. Until it
   is fixed, run `chmod a-w` on a vintage or snapshot folder after copying it back in step C. Routed to Team C as a
   defect (SEC-A-006 L7).
3. Restoring the store also takes an online sqlite snapshot, so compare the store by `econquest runs`, not by file
   hash.

Result: **backup and restore drill PASS on both fixtures, about 5 s each against the 4-hour target. Restored
vintages, ledgers and data rooms re-verify.** Re-run this drill on the Mac with the real backup destination, monthly,
as the "Where good copies live" section above says.

## Owner

Runbook: Team A, AGENT-06. Restores on the Mac and workbook restores: Sam.
