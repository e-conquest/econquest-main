# Coverage to 60%: source map, arithmetic and adapter plan (EQ-A-0049 part 1)

Team A, AGENT-02, 2026-10-24. Read-only audit plus one data file: `data/panel/coverage_source_map.csv` (one row per
Inputs indicator, 83 rows). No source or test file was changed. This cloud cannot reach the IMF, World Bank, BIS, OECD
or Eurostat, so **every series code, dataflow id and coverage count that is not already served by `feeds.py` is
unverified** (column `verified` = no). The notes give a documentation URL for each one. AGENT-06 must confirm each
code against a live response on Sam's Mac before relying on it (EQ-A-0049 adapters, EQ-A-0050).

## 1. Headline

> **Metric decided (Sam 2026-10-24 12:41Z, EQ-A-0055): 60% of feed-eligible cells.** The target counts only the 50
> indicators whose `candidate_source` in `coverage_source_map.csv` is not `manual-only`: 30 of 50 cells per country,
> 540 of 900 for the 18, 2,640 of 4,400 for the 88. `universe.feed_eligible_ids` is the one definition;
> `missing_cell_report` and `coverage_report` set `meets_target` on `pct_live_eligible` / `pct_expected_eligible` and
> keep the all-cells share (`pct_live`, `pct_expected`) as an informational column. Every summary states the
> denominator: "60% of 50 feed-eligible cells per country; Sam 2026-10-24".
>
> **On the new metric today:** 224 of 900 feed-eligible cells are live for the 18 (24.9%; all 224 live cells are
> feed-eligible). 0 of 18 countries meet 30 of 50; the best are China, India, Brazil, Argentina and Colombia at
> 15 of 50, and the lowest is Senegal at 4 of 50. For the 88, the existing feeds are expected to fill 24.0% of eligible
> cells (1,058 of 4,400; the best country 15 of 50), and 0 of 88 countries are expected to meet the target. The upper
> bound is 37.7% of eligible cells (22.7% of all cells), up from 31.7% (19.1%) because EQ-A-0049 added the World Bank
> ids 2.2, 2.11 and 7.10 to `feeds.py` at 12:50Z on 2026-10-24. No pull has served them yet, so they count as dead
> and are not in the expected share. Source:
> `python -m econquest.ingestion.universe missing --data data` and `... coverage --data data`, run 2026-10-24 on this
> folder's 2026-10-23 pull. The bullets below are the all-cells analysis that led to the decision; they are unchanged.

- **Today:** 224 of 1,494 Inputs cells are live for the 18 desk countries (15.0%, `python -m econquest.ingestion.universe
  missing --data data`). For the 88-country universe, the existing feeds are expected to fill 14.5% (ceiling 19.1%,
  `universe coverage`).
- **Hard ceiling:** 33 of the 83 indicators are judgement levels or come from licensed sources only (manual-only below).
  Even if every other indicator were live for every country, the most any country could reach is 50/83 = **60.2%**.
  60% (50 cells per country, `cells_per_country_for_target`) leaves **no slack**: one missing cell in any country puts
  that country below target.
- **Official sources only** (IMF, World Bank, BIS, central banks): the ceiling is 35/83 = **42.2%**. The rulebook
  names research and NGO datasets (V-Dem, UCDP, ND-GAIN, GTI, WJP, ...) for 15 indicators. These are free but not official, and
  they are needed to get past 42%.
- **Planning case** (coverage assumptions in section 3): about **33%** with official sources and about **49%** with
  the research datasets added, for both the 18 and the 88.
- **Conclusion: 60% of all Inputs cells is not reachable with free sources under the current definition.** Sam needs to
  choose one of the options in section 6.

## 2. How the indicators split (from `coverage_source_map.csv`)

| Group | Indicators | Ids |
|---|---|---|
| Existing feeds (WEO, World Bank, BIS in `feeds.py`) | 18 | 1.3 1.6 1.7 2.8 2.9 2.10 2.12 3.4 3.5 5.5 5.6 5.9 5.10 5.12 5.13 5.14 6.2 6.6 |
| New official adapters (IMF SDMX, World Bank, central bank file) | 17 | 1.1 1.2 1.4 1.5 1.8 2.1 2.2 2.3 2.4 2.11 5.1 5.2 5.4 5.7 5.11 6.10 7.10 |
| Research or NGO datasets (free, not official) | 15 | 3.6 3.7 4.3 4.4 6.1 6.7 6.9 6.11 6.12 6.13 7.1 7.2 7.8 7.11 7.12 |
| Manual-only (never live) | 33 | section 5 |

`candidate_source` uses the values in the brief, plus one more: `research dataset (free, not official)`. The brief's
list has no category for these 15 indicators, and filing them under an official category would overstate them.
OECD and Eurostat are not the primary candidate for any indicator. Section 4 explains why.

## 3. Arithmetic

Cells: 83 indicators x 88 countries = 7,304; 60% = 4,383 cells. For the 18: 1,494 cells; 60% = 897.

Assumptions (all unverified; each is the `plan_cov88=` token in the row's `notes`):
- Existing feeds: the share of the 18 that is live on the 2026-10-23 pull, applied to the 88 (WEO 15-18 of 18). 2.9,
  3.4 and 3.5 are assumed fixed (EQ-A-0027, EQ-A-0036). 2.12, 5.9 and 5.13 are assumed to get IMF fallbacks.
- IDS-based ids (2.2, 2.9, 2.10, 1.1, 1.4): the 63 non-high-income countries in `universe_proposal.csv` x 13/15 (the
  2.10 hit rate among non-high-income desk names) = 55.
- New IMF SDMX series: 45 to 70 of the 88. This is lower for encouraged FSIs and IRFCL, which few frontier countries
  report, and higher for MFS and CPI.
- Research datasets: near-global (85 to 88), except IPC (20: it analyses food-crisis countries only) and the UCDP
  violence ratio (70: the ratio is undefined when the base is 0).

| Scenario | 88 countries: cells | 88: share | 18 countries: cells | 18: share | Ceiling (any n) |
|---|---|---|---|---|---|
| Today (measured for 18, expected for 88) | ~1,058 | 14.5% | 224 | 15.0% | 19.1% (88) |
| Existing feeds fixed (2.9, WGI, BIS fallbacks) | 1,383 | 18.9% | 285 | 19.1% | 21.7% |
| + new official adapters (IMF SDMX, WB, CRAG) | 2,391 | 32.7% | 487 | 32.6% | 42.2% |
| + research datasets | 3,586 | 49.1% | 729 | 48.8% | 60.2% |
| Target (old metric, all cells) | 4,383 | 60% | 897 | 60% | |

**The same scenarios on the decided metric (feed-eligible cells, EQ-A-0055).** Same cell counts (every cell counted
above is feed-eligible), divided by 50 eligible indicators instead of 83: 4,400 cells for the 88, 900 for the 18. The
scenario counts are the planning assumptions above and are unverified; only the "Today" row for the 18 is measured.

| Scenario | 88: cells | 88: share of eligible | 18: cells | 18: share of eligible | Ceiling (of 50) |
|---|---|---|---|---|---|
| Today (measured for 18, expected for 88) | ~1,058 | 24.0% | 224 | 24.9% | 37.7% (88, `pct_upper_eligible_overall`; 31.7% before 2.2/2.11/7.10) |
| Existing feeds fixed | 1,383 | 31.4% | 285 | 31.7% | 36% (18/50) |
| + new official adapters | 2,391 | 54.3% | 487 | 54.1% | 70% (35/50) |
| + research datasets | 3,586 | 81.5% | 729 | 81.0% | 100% |
| **Target (60% of eligible)** | **2,640** | 60% | **540** | 60% | 30 per country |

On this metric the planning case clears the target only with the research datasets (81%); official sources alone
reach about 54%, below 60%, with a 70% ceiling.

The 18-country column uses the same rates as the 88 (plan_cov88 / 88 x 18, and never below today's live count).
Central-bank adapters for the top 25 (EQ-A-0050) raise the hit rates of the existing and official groups for those
names, but they cannot lift any country above the 42.2% official ceiling.

**Which indicators matter most** (cells gained in the planning case, among non-manual indicators):
1. Fix the existing feeds that are dead today: 3.4 and 3.5 WGI (176 cells together) and 2.9 (55). These are
   engine-required or high-severity, and the code is already in place: they need only a verified live pull.
2. CRAG default record 1.8 (88). This is a file import that is already ticketed (EQ-A-0008/0016, Blocked on the Mac).
3. Cheap World Bank additions on the existing host: 2.11 export concentration (75, engine-required), 7.10 fuel exports
   (75), 6.10 Gini (70), and 2.2 from IDS (55).
4. IMF SDMX MFS/CPI/FSI/IRFCL: 5.11 (70), 5.1 (65), 2.3 (60), 5.9 and 2.12 fallbacks, then 1.2, 2.4, 5.2, 2.1 (45-50 each).
5. Engine-required gaps with weak sources: 1.4 GFN and 1.5 FX share of debt (proxies or partial coverage), 6.1 armed
   conflict (UCDP, needs a token), 7.2 PML (static UNDRR file).

## 4. Prioritised adapter list

Endpoints marked (unverified) come from memory or package documentation and were not tested from here.

| # | Adapter | Serves | Endpoint / access | Auth | Licence (URL) |
|---|---|---|---|---|---|
| 0 | Fix existing feeds (no new adapter) | 2.9, 3.4, 3.5; BIS staleness | existing `WorldBankFeed`, `BisFeed` | none | as below |
| 1 | **IMF SDMX** (new data portal) | 1.2, 1.4, 2.1 (IRFCL part), 2.3, 2.4, 5.1, 5.2, 5.4, 5.11; fallbacks for 2.12, 5.9, 5.10, 5.13 | SDMX 2.1 and 3.0 per https://data.imf.org/en/Resource-Pages/IMF-API ; Swagger https://portal.api.imf.org/apis#tags=iData ; host `api.imf.org` as already used by imf-reader (path unverified). Dataflows to confirm: IRFCL, FSI, MFS (incl. MFS_IR, named in the imfapi R package docs), CPI, BOP/IIP, FM | portal account referenced for the Swagger explorer; whether data calls need a key is not stated (unverified) | IMF Copyright and Usage https://www.imf.org/en/about/copyright-and-terms : free reuse with attribution and a dataset link; **commercial reuse needs permission (copyright@imf.org); automated bulk download needs explicit permission.** This also applies to the WEO feed in use today. Escalate to Sam. |
| 2 | **World Bank** additions (existing wbgapi host) | 2.2, 2.11, 7.10, 6.10, 1.1/1.4 IDS parts, 1.5 (QPSD, source id unverified), 5.7 (BRSS file) | `api.worldbank.org` v2 via wbgapi https://datahelpdesk.worldbank.org/knowledgebase/articles/889386 | none | mostly CC BY 4.0, per dataset https://www.worldbank.org/en/about/legal/Permissions , https://datacatalog.worldbank.org/faq |
| 3 | **OECD** | cross-checks and fill for the 17 OECD members of the 88 (USA DEU GBR FRA ITA CAN AUS JPN KOR MEX CHL COL CRI TUR POL HUN ISR): 1.5 central government debt by currency, 1.4 borrowing needs, 5.11/5.13 | SDMX REST `sdmx.oecd.org/public/rest/data/...` (unverified); docs https://www.oecd.org/en/data/insights/data-explainers/2024/09/api.html ; rate limits https://www.oecd.org/en/data/insights/data-explainers/2024/11/Api-best-practices-and-recommendations.html | none (unverified) | believed CC BY 4.0 (unverified) https://www.oecd.org/en/about/terms-conditions.html |
| 4 | **Eurostat** | 6 EU members (DEU FRA ITA POL HUN ROU) and partly candidates (SRB MKD MNE ALB TUR UKR GEO): government debt by currency (1.5), maturity (1.4), MFI data (5.1) | `https://ec.europa.eu/eurostat/api/dissemination/` statistics/1.0 JSON and sdmx/2.1 or 3.0 (per https://dlthub.com/context/source/eurostat ; official docs unverified) | none | free reuse with attribution (unverified) https://ec.europa.eu/eurostat/about-us/policies/copyright |
| 5 | **Central banks and national statistics, top 25** (EQ-A-0050) | exact definitions of 2.4, 5.1, 5.2, 5.11, 5.13, reserves, CPI, debt stock | per-bank; many publish SDMX or CSV (unverified per bank) | varies | varies per bank: record each in `licence_terms` |
| 6 | Research datasets (outside this ticket's adapter list, but needed beyond 42%) | 3.6, 4.3 V-Dem; 4.4 Powell-Thyne; 6.1, 6.9, 6.12 UCDP (+UNHCR); 6.7 GOCI; 6.11 IPC; 6.13 GTI; 3.7 WJP; 7.1/7.2 UNDRR; 7.8 LECZ; 7.11 ND-GAIN; 7.12 Aqueduct | annual or static files; UCDP API `https://ucdpapi.pcr.uu.se/api/<resource>/<version>` | **UCDP needs an access token** (header `x-ucdp-access-token`, 5,000 requests a day, https://ucdp.uu.se/apidocs/); IPC and Comtrade need keys (unverified) | several may be non-commercial (WJP, GTI, GOCI: unverified). Sam must clear the licences before the desk uses them. |

Why OECD and Eurostat come after the IMF and World Bank: together they cover 17 OECD and 6 EU members of the 88, which
are the best-served countries already, and they serve none of the 33 manual-only indicators. Their gain is roughly 1
to 2 points of coverage at most, plus better definitions for 1.4, 1.5 and 5.1 for those countries. Build them for
quality, not for the 60% count.

**Top 25 desk names:** no list is defined in the repo (team/board/A.csv EQ-A-0050 and B.csv EQ-B-0071 use the term
without one). Working proposal for AGENT-08 and Sam to confirm: the 18 `desk_current` names plus seven `EM` names from
`universe_proposal.csv` (for example IDN, MEX, TUR, ZAF, EGY, THA, SAU).

**Pipeline gaps for AGENT-06**
- 1.1, 1.2 and 2.1 are computed by `econquest dsa` and applied outside `live/live_inputs.csv`, so `missing_cell_report`
  never counts them as live.
- `universe.indicator_sources` classifies by the rulebook `api` text. Any new feed needs its ids added to `FEED_IDS`,
  otherwise the reason column of `missing_cell_report` stays wrong.
- 2.12, 5.9 and 5.13 need a per-country rule for which source wins (BIS or IMF), recorded in provenance.
- Several candidates need a mapping rule from Team B before they can be live: level mappings for 4.3, 4.4, 6.10, 6.12
  and 7.12; the window and series for 5.4; the zero base for 6.9; and blank versus 0 for 6.11 and dollarised 5.13.

## 5. Indicators that will never be live (33, manual-only)

These are judgement levels, or their only source is licensed or proprietary. The `notes` column in
`coverage_source_map.csv` gives the reason for each.
1.9, 2.5, 2.6, 2.7, 3.1, 3.2, 3.3, 3.8, 3.9, 3.10, 4.1, 4.2, 4.5, 4.6, 4.7, 4.8, 4.9, 4.10, 4.11, 5.3, 5.8, 6.3, 6.4
(ACLED only), 6.5, 6.8, 6.14, 7.3 (EM-DAT licensed), 7.4, 7.5 (Swiss Re proprietary), 7.6, 7.7, 7.9 (ACLED), 7.13.
Engine-required among them: 2.7 and 4.10. Data can inform several of them (FATF lists, AREAER, ISDS cases, GPR), but
the analyst sets the level.

## 6. Decision for Sam (needed before 60% is a meaningful target)

**Decided: option 1 (Sam 2026-10-24 12:41Z, "60% of feed-eligible cells"; implemented by EQ-A-0055).** The text
below is kept as the record of the options.

1. Measure 60% of **feed-eligible** cells (the 50 non-manual indicators), with manual cells tracked separately as
   attested or unattested. Planning case: 49.1 / 60.2 = about 82% of eligible cells (about 78% if only official
   sources count).
2. Keep "all Inputs cells" but lower the target to what the sources allow (about 45 to 50% with research datasets, about
   33% with official sources only).
3. Count analyst cells that have a four-eyes attestation in the review ledger as "maintained", next to "live".
Recommendation: option 1. The current metric mixes judgement levels, which can never be fed, with data cells.

## 7. How to refresh after a Mac pull

`python -m econquest.ingestion.universe missing --data <staged folder>` gives the measured share: `pct_live_eligible`
per country and `pct_live_eligible_overall` in the summary are the target metric; `pct_live` / `pct_live_overall`
are all cells, for information. Changing a row's `candidate_source` to or from `manual-only` changes the denominator
for every country; `feed_eligible_ids` refuses a map whose ids differ from `indicators.csv`. Update
`current_coverage_18`, replace the `plan_cov88` assumptions with observed counts, set `verified` to yes only where a
live response confirmed the code, and recompute section 3. The CSV was generated with a one-off script that reads
`rulebook.csv`, `live/live_inputs.csv` and `universe_proposal.csv`. Edit the CSV directly from now on.

## 8. Adapters built (EQ-A-0049 adapters, AGENT-06, 2026-10-24)

Code in `econquest/ingestion/official/` plus minimal wiring in `feeds.py` (fetch_all, FEED_ALIASES `imf`,
WB_SERIES, quality_gate). Tests: `tests/test_official_feeds.py`, `tests/test_audit_client_restricted.py` (synthetic,
offline). **Nothing below is verified against a live response.** Every cell these adapters fill is held by the gate
(`unverified`) until this map's `verified` column says `yes` for the indicator, which is set only after the Mac check
in `A-fetch-on-mac.md` (section "IMF/OECD/Eurostat").

**IMF licence (Sam 2026-10-24 12:38Z, HO-20261024-A-B-003):** IMF data is for internal research use only and never
goes into client output. IMF SDMX is therefore in the default fetch (no opt-in flag). Every IMF raw row carries the
tag `IMF: internal research use only (Sam 2026-10-24; commercial reuse/bulk download need IMF permission)`, and
`audit.client_output_reason` / `python -m econquest.ingestion.audit client` flag IMF and WEO values (and values
derived from WEO series) as restricted for client output. They are not withheld from desk numbers or the internal
data room. Blocking them in publish/distribution is Team C's (handoff from AGENT-08).

| Id | Status | Source / transform | What is pending |
|---|---|---|---|
| 2.11 | built | WB max of five WDI merchandise export groups, same year | Mac pull, then verified=yes |
| 7.10 | built | WB TX.VAL.FUEL.ZS.UN | Mac pull, then verified=yes |
| 2.2 | built | (-CA + IDS ST debt + PPG and PNG amortization) / WDI reserves, same year; CA from WEO | Mac pull; high income not covered (IDS) |
| 6.10 | raw only | WB SI.POV.GINI into raw_worldbank.csv | Team B level mapping (handoff to B/AGENT-05) |
| 2.12 | built (IMF fallback) | BIS first; IMF REER (candidate legacy code EREER_IX) where BIS has no value | confirm IMF EER flow and code |
| 5.13 | built (IMF fallback) | BIS first; IMF policy rate (candidate FPOLM_PA, MFS_IR) minus WEO CPI | confirm code; dollarised rule (Team B) |
| 5.9 | rule only | precedence BIS > IMF wired | IMF credit-gap method needs Team B approval |
| 5.11 | transform built, series unconfigured | MFS ODC deposits deflated by IMF CPI (CPI configured) | ODC deposit codes unknown: run `structure` |
| 5.1 | transform built, series unconfigured | ODC claims on central government / ODC total assets | ODC codes unknown |
| 2.3 | transform built, series unconfigured | IIP portfolio debt liabilities / IRFCL reserve assets (reserves configured, RAFA_USD candidate) | IIP code unknown |
| 1.2 | transform built, series unconfigured | IRFCL 12-month predetermined drains / reserve assets (12m, not 24m) | IRFCL drains code unknown |
| 2.4, 5.2 | transform built, series unconfigured | FSI FX liabilities share / FX loans share | FSI codes unknown |
| 2.1 | not served by an adapter | ARA metric is an annual IMF file, no SDMX series; reserves fetched raw | stays with `econquest dsa` |
| 1.5 | transform built, series unconfigured | Eurostat (general government) first, then OECD (central government): FC debt / total | dataset ids and keys unknown |
| 1.1, 1.4, 5.4, 5.7 | not built | dsa / proxies / Team B window / BRSS file | see section 4 |

Precedence (2.12, 5.9, 5.13): BIS first, then IMF, by source and never by freshness; when both have a value the gate
compares them (`bis_imf_cross`, tolerances 5 pp / 3 pp / 1 pp, to calibrate on the first pull) and holds the cell
beyond tolerance. The decision is written to `transform_log.csv`.

The `dsa` gap (1.1, 1.2, 2.1): `econquest/engine/dsa.py` is Team B's. It writes `outputs/dsa_scorecard_feeds.csv`
(source `econquest dsa`) and no ingestion code reads that file today, so these cells never count as live. A handoff
to B/AGENT-05 asks for the dsa rows to be recorded as derived-from-live with their input sources and vintage. The
ingestion side (gate and apply of that file) is a Team A follow-up.

`missing_cell_report` now classifies the new ids (`FEED_IDS`: imf_sdmx, oecd, eurostat; WB additions under
worldbank) and gives the `unserved.csv` reason for each empty cell (for example "imf_sdmx: not served - IMF series not
configured ..."). `coverage_report` still counts only WEO, World Bank and BIS ids as expected live.

## 9. Part 2: central-bank and national-statistics adapters (EQ-A-0050, AGENT-06, 2026-10-24)

Registry and adapters in `econquest/ingestion/official/central_banks.py` for the top 25 (`nowcast names`): policy
rate, CPI, reserves and debt stock per country. 18 machine-readable series in 7 countries (BCB SGS, BCRA, BoK ECOS,
Banxico SIE, BCCh, BCRPData, BNM OPR); the other 82 entries are manual, each with the reason. Named feed only
(`fetch --only cb`). **All unverified.** Precedence (`official/precedence.py`, `choose_national`): a national value
replaces BIS / IMF / WEO / World Bank only once `data/panel/cb_series_verified.csv` marks that exact series verified
after the Mac check; until then it only fills empty cells, and the gate holds them. Cells: `policy` and 5.13
(policy rate), 5.5 (CPI), profile `reserves`, 1.3 (only % of GDP series).

Expected effect on the 60% target: none until verification. Afterwards it is small. Of the 18 current desk names,
only BRA, ARG, KOR and MYS have adapters, and most of their target cells are already filled by WEO / BIS / WB. The
national series mainly improve timeliness and give a cross-check (`cb_cross`). `universe.FEED_IDS` is not changed:
every cell `cb` serves already has a feed class. Runbook with per-country verification commands:
`A-central-bank-adapters.md`.

## 10. Part 3: residual gaps per country, WDI fallbacks, documented manual reasons (EQ-A-0062, AGENT-06, 2026-10-24)

**Gap matrix.** `python -m econquest.ingestion.coverage_gaps build --data data [--summary <csv>]` writes
`data/panel/coverage_gaps_part3.csv`, one row per desk country and feed-eligible id (18 x 50 = 900), with columns
`iso3, id, state, candidate_source, reason, action`. The state comes from `universe.missing_cell_report` on this
folder's 2026-10-23 pull and from the adapters' own registries (`imf.IMF_SPECS`, `worldbank.WB_EXTRA_IDS`,
`wdi_extra.WDI_EXTRA_IDS`, `central_banks.CB_REGISTRY`), never from a hand list:

| State | Meaning | Cells (of 900) |
|---|---|---|
| live | finite in `live_inputs.csv`, not held | 224 |
| adapter_unverified | adapter built and configured; serves the cell once its codes are confirmed on the Mac | 124 |
| adapter_unconfigured | transform built, series codes unknown (IMF 5.11 5.1 2.3 1.2 2.4 5.2; OECD 1.5 for JPN KOR COL) | 111 |
| blocked_team_b | raw input fetched, level mapping is Team B's (6.10 Gini) | 18 |
| feed_no_value | a verified feed serves the id elsewhere; the source has nothing for this country | 19 |
| not_applicable | concept does not exist (Singapore 5.13: no policy rate) | 1 |
| no_adapter | documented reason below | 403 |

Expected share = live + adapter_unverified. Upper = expected + adapter_unconfigured + blocked_team_b. Which
countries a not-yet-pulled series covers is UNVERIFIED; the builder assumes IDS-based ids (2.9, 2.2) only where IDS
2.10 is live today, and BIS fallbacks for every non-BIS country.

**Expected share per country (target 30 of 50; Sam 2026-10-24).**

| iso3 | live | + built, unverified | expected | share | + unconfigured / Team B | upper | share | short of 30 (expected) |
|---|---|---|---|---|---|---|---|---|
| VNM | 12 | 9 | 21 | 42% | 7 | 28 | 56% | 9 |
| PHL | 14 | 7 | 21 | 42% | 7 | 28 | 56% | 9 |
| CHN | 15 | 6 | 21 | 42% | 7 | 28 | 56% | 9 |
| MYS | 14 | 4 | 18 | 36% | 7 | 25 | 50% | 12 |
| SGP | 12 | 4 | 16 | 32% | 7 | 23 | 46% | 14 |
| JPN | 13 | 5 | 18 | 36% | 8 | 26 | 52% | 12 |
| KOR | 14 | 4 | 18 | 36% | 8 | 26 | 52% | 12 |
| IND | 15 | 6 | 21 | 42% | 7 | 28 | 56% | 9 |
| PAK | 12 | 9 | 21 | 42% | 7 | 28 | 56% | 9 |
| BLZ | 12 | 9 | 21 | 42% | 7 | 28 | 56% | 9 |
| BRA | 15 | 6 | 21 | 42% | 7 | 28 | 56% | 9 |
| ARG | 15 | 6 | 21 | 42% | 7 | 28 | 56% | 9 |
| COL | 15 | 6 | 21 | 42% | 8 | 29 | 58% | 9 |
| VEN | 7 | 7 | 14 | 28% | 7 | 21 | 42% | 16 |
| NGA | 12 | 9 | 21 | 42% | 7 | 28 | 56% | 9 |
| SEN | 4 | 9 | 13 | 26% | 7 | 20 | 40% | 17 |
| ZMB | 12 | 9 | 21 | 42% | 7 | 28 | 56% | 9 |
| ZWE | 11 | 9 | 20 | 40% | 7 | 27 | 54% | 10 |
| **18** | **224** | **124** | **348** | **38.7%** | **129** | **477** | **53.0%** | |

**Every one of the 18 misses 30 of 50 even when every built adapter is verified**, and still misses it at the upper
bound (best: Colombia 29). Each country has 22 no-adapter cells, 15 of them research datasets. With all 15 research
datasets live on top of the expected column, 16 of 18 would reach 30; Senegal (28) and Venezuela (29) would not,
unless their WEO gaps close. The official-source route alone cannot meet the target: this is a decision for Sam
(research datasets and their licences), not more adapters.

**New adapter (part 3): `econquest/ingestion/official/wdi_extra.py`, feed `wdi_extra`** (World Bank WDI annual
history on the existing host; in the `worldbank` alias, so in the default fetch; `feeds.py` change: three lines,
FEED_HOSTS, FEED_ALIASES and the official-cells condition in `fetch_all`). Codes UNVERIFIED.

| Id | Series | Rule | Fills (desk) | Gate |
|---|---|---|---|---|
| 5.9 | FS.AST.PRVT.GD.ZS (domestic credit to private sector, % GDP) | one-sided HP gap, lambda 400,000/4^4 = 1,562.5, at least 15 consecutive years | the 9 names without a BIS credit gap: VNM PHL PAK BLZ VEN NGA SEN ZMB ZWE (coverage UNVERIFIED) | unverified, **method** (Team B), range, stale |
| 2.12 | PX.REX.REER (REER index, IMF IFS via WDI; client-restricted as IMF data) | latest year vs mean of last 10 years (at least 8) | third fallback after BIS and IMF for the 8 non-BIS names; no new cells in the count (IMF fallback already built), redundancy while IMF codes are unverified | unverified, **method** (Team B), range, stale |

Precedence BIS > IMF SDMX > WDI, by source; the WDI value only fills a cell both left empty, logged in
`transform_log.csv`. `wdi_extra.METHOD_APPROVED` is empty: the gate holds every WDI value with check `method` until
Team B approves the transform (a code change, not a data edit). Setting 2.12 to verified=yes in the map now needs
both the IMF REER code and PX.REX.REER confirmed. Tests: `tests/test_wdi_extra.py`.

**Fix in part 1 (EQ-A-0049) found here: per-creditor IDS rows.** `raw_worldbank.csv` holds up to 35 rows per country
and year for DT.TDS.DPPG.CD (3,808 rows, 13 countries): IDS US$ series come back one row per creditor and
`WorldBankFeed` drops the counterpart dimension. The 2.2 transform used to keep an arbitrary row; it now refuses
(`official/worldbank.py` `_by_year`, reason "per-creditor IDS rows"). 2.2 therefore stays empty until `WorldBankFeed`
records or filters the counterpart (World total). The wbgapi parameter for that is UNVERIFIED: confirm on the Mac
before changing `feeds.py`. `econquest dsa` (Team B) sums or takes the max per year for 1.2: the same issue (register X16).

**Gaps that stay manual (documented in the CSV `reason` / `action`).**

| Id | Why no adapter | Action |
|---|---|---|
| 1.1 | Rulebook source is the IMF Article IV DSA (manual); dsa proxy uses an analyst average maturity (derived_from mixed); domestic amortisation has no free cross-country API | stays manual / dsa |
| 1.2 | IMF IRFCL drains code unknown (adapter_unconfigured). dsa computes it from IDS projections | Mac structure check; ingesting dsa_scorecard_feeds.csv rows with derived_from=live is a Team A follow-up (after the creditor-row fix) |
| 1.4 | Rulebook: IMF Fiscal Monitor GFN (manual); FM dataflow UNVERIFIED; a WEO + IDS proxy misses domestic amortisation | stays manual; IMF FM once confirmed, then Team B |
| 1.5 | Outside OECD/EU members no confident free API (QPSD ids UNVERIFIED) | manual (debt office bulletins); re-check QPSD on the Mac |
| 1.8 | CRAG database is a file, not an API | file import EQ-A-0008 / EQ-A-0016 |
| 2.1 | IMF ARA metric is an annual file, no SDMX series; dsa uses analyst components | stays dsa / manual |
| 2.2, 2.9 (SGP JPN KOR MYS VEN) | IDS covers low- and middle-income reporters only; no 2.10 value today | manual |
| 5.4 | Pink Sheet is an Excel file; ODC credit codes unknown; Team B rule missing | manual until Team B rule |
| 5.7 | BRSS survey file, waves years apart, no API | manual |
| 6.10 | Gini fetched raw; 0-4 mapping is Team B's | Team B (HO from EQ-A-0049) |
| 3.6 3.7 4.3 4.4 6.1 6.7 6.9 6.11 6.12 6.13 7.1 7.2 7.8 7.11 7.12 | research datasets: annual or static files, token APIs (UCDP, IPC), licences UNVERIFIED (WJP, GTI, GOCI possibly non-commercial) | Sam: research-dataset and licence decision |
| SEN WEO ids (1.3 1.6 1.7 2.8 5.5 5.6 5.14) | the WEO vintage has no year after 2025 for Senegal; the transforms read the fetch year | none: re-check next WEO vintage (a latest-actual fallback would be a Team B rule) |
| VEN 1.3 1.6 1.7, 2.10, 5.10; SGP 1.6, 2.10; MYS/JPN/KOR 2.10; SEN/ZWE 5.10 | the source has no series for the country (raw evidence in the CSV reason) | none |
