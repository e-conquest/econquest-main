# Runbook: universe expansion to 70+ sovereigns (EQ-A-0025 review, EQ-A-0026 staged pull)

> **Mac pull pack (EQ-A-0048):** this pull is step 4 (`universe`, part 2 steps 1-3) of `python -m econquest.ingestion.pullpack run`, which runs every Mac-only pull in order, resumably, with disk checks and one report to send back: see `docs/runbooks/A-mac-pull-pack.md`. This page stays the reference for the step.

Owner: Team A, AGENT-06. Operator: Sam. Written 2026-10-23 from `econquest/ingestion/universe.py`.
Epic A6. Acceptance: `countries.csv` has 70 or more rows, at least 60% of Inputs cells are live, and every
pull has a missing-country report.

Nothing here changes `data/countries.csv` or `data/indicators.csv`. The live universe changes only in
step 4 of part 2, after your approval and after Teams B and C confirm their handoffs.

## Part 1: review the proposal (any machine, no network)

Files: `data/panel/universe_proposal.csv` (88 rows) and `data/panel/universe_proposal.md` (criteria,
columns, coverage, open decisions).

1. Open the CSV in Numbers or Excel. **Import it as text.** Namibia's iso2 is `NA`, and a spreadsheet can
   turn it into an empty cell. Save as CSV (UTF-8), not .numbers or .xlsx.
2. Review each row. Delete rows you do not want and add rows you do want. Correct anything marked
   `unknown` or wrong. When you check a field against a source, change `basis` for that row, for example
   `rating_bucket: S&P/Moody's/Fitch sites 2026-11-02 (SC); fx_regime: AREAER 2025 (SC); rest analyst estimate (Claude, Oct 2026 knowledge), verify`.
   For new rows, keep the phrase `analyst estimate (Claude, Oct 2026 knowledge), verify` as long as any
   field is still unchecked. The validator requires it.
3. Do not change the 18 `desk_current` rows' `iso3`, `iso2` or `name`. The name is the column key in
   `indicators.csv`.
4. Validate, then look at coverage:
   ```bash
   cd ~/econquest
   .venv/bin/python -m econquest.ingestion.universe validate          # prints ok or a list of problems; exit 1 on problems
   .venv/bin/python -m econquest.ingestion.universe coverage --out outputs/universe-coverage.csv
   ```
   `coverage` shows for each country which feeds can serve it, the expected live share of its 83 Inputs
   cells, and an upper bound. It also prints which indicator ids are feed-backed, which feed-backed ids
   returned nothing in the latest pull (`dead_feed_ids`), and which are manual or planned.
5. Tell AGENT-08 the list is approved (a message, or a row in `data/approvals/`). That releases EQ-A-0026.

## Part 2: staged pull for the new countries (Sam's Mac, network)

The feeds.py scale fixes are in (EQ-A-0027): FX is chosen per country, so EUR, XOF and XAF countries
all get fx3m; USD-currency countries and Zimbabwe are listed in `data/live/unserved.csv`. Before step 4, Teams B
and C must confirm their handoffs (see "Changes needed to scale").
Steps 1 to 3 work today and are safe to run.

```bash
cd ~/econquest
mkdir -p ~/econquest-backup && cp -Rp data ~/econquest-backup/data-$(date +%Y%m%d-%H%M)          # backup

# 1. candidate input files for the approved list, written to data/panel/universe_staging/ only
.venv/bin/python -m econquest.ingestion.universe expand
#    -> countries.csv, indicators.csv (new columns blank), cells_to_fill.csv, universe_meta.csv,
#       coverage.csv, manifest.json (hashes; status "candidate - not live")

# 2. a complete, separate data folder that uses the staged files (data/ is not touched)
STAGE=~/econquest-universe-$(date +%Y%m%d-%H%M)
.venv/bin/python -m econquest.ingestion.universe stage --dest "$STAGE"

# 3. pull live values for all countries into the staged folder (no --apply), then the missing-cell report
econquest --data "$STAGE" fetch 2>&1 | tee outputs/universe-fetch-$(date +%Y%m%d-%H%M).log
.venv/bin/python -m econquest.ingestion.universe missing --data "$STAGE" --out outputs/universe-missing-cells.csv
```

The fetch writes `$STAGE/live/` and a vintage under `$STAGE/live/vintages/`. Your real `data/live/` does not
change. `missing` prints one row per country (live, held, missing, `pct_live`, `meets_target` against 0.60)
and a summary. The CSV lists every cell that is not live, with its reason:
- `held by quality gate`: review it in `$STAGE/live/review.csv`.
- `<feed> returned no value`: no data for that country. Check the code mapping (iso2/BIS, currency/FX reference area).
- `manual` or `planned_api`: no feed exists for that cell.

and `seed_present = N`, meaning the cell has no value at all. For a new country, every non-live cell is
`seed_present = N` until someone fills it.

4. **Review** (you and AGENT-08). Do not continue unless:
   - every new country has its WEO cells (1.3, 1.6, 1.7, 2.8, 5.5, 5.6, 5.12, 5.14). If one has none, check
     `weo_available` and the ISO3;
   - the hand-entered Country Profile fields in `cells_to_fill.csv` (`rating`, `spread`, `fxregime` where
     the regime is unknown, market-availability flags, event flags, `stress_depreciation`) are filled for
     every new country. The engine cannot score a country without its rating and spread;
   - Teams B and C have confirmed their handoffs (thresholds and limits for new names; Sheets ranges and GUI).
   Only then: a separate ticket copies `$STAGE/countries.csv` and `$STAGE/indicators.csv` into `data/`
   through `teamctl checkpoint` (a C1 contract change, which needs an ADR), and then runs
   `econquest fetch --apply` on the real data folder in the usual way (`A-fetch-on-mac.md`).

Rollback: delete `$STAGE`, and `data/panel/universe_staging/` if you want. Nothing else changed.

## Changes needed to scale from 18 to 70+ columns

| Area | Owner | Issue |
|---|---|---|
| feeds.py FX fan-out | A (feeds owner) | Done in EQ-A-0027 (Yahoo tickers per country), carried over in EQ-A-0040: one official series per currency (`official_fx_plan`), shared by every country using it |
| feeds.py `BisFeed.fetch` | A | 3 flows × N countries, one HTTP call each: 264 calls for 88 countries, with no retry or backoff. Batch keys with `+` (SDMX OR) or add retries |
| feeds.py WGI / IDS | A | 2.9, 3.4 and 3.5 return nothing for all 18 desk countries today. WB `RL.PER.RNK` etc. vs the rulebook's `GOV_WGI_*.SC`; IDS short-term debt. Fix before measuring 60% |
| loaders `CsvSource` | A | `pd.read_csv` default NA handling turns Namibia's iso2 `NA` into NaN |
| fetch | C (cli) | Print the missing-cell report on every pull (A6 "missing-country report on every pull") using `universe.missing_cell_report` |
| Sheets publish `E5:V87` etc. | C | Ranges are fixed at 18 country columns (E..V) in `sheets_publish.py:56-101`. 88 countries reach column CN. The workbook template needs columns |
| GUI / dashboard / country note | C | Layouts sized for 18 |
| Engine | B | Rating notches and spreads are hand-entered and required (layer1 RatingChallenger, layer2, stress ladder). The copula's regional factor assumes Asia/LatAm/Africa, and `stress.py` special-cases `region == "Asia"`. The new regions Europe, Middle East and North America get their own factor. Monte Carlo cost grows with N² for correlation and N × paths |
| limits.json / playbook | B | Per-country limits name only Venezuela and Zimbabwe (defaults otherwise). Playbook triggers and thresholds are calibrated on 18 names |
| Hazard panel | B | 15 ISOs today. The PD model's calibration on 70+ countries depends on the CRAG import (EQ-A-0016) |
