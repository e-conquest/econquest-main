# Runbook: daily forecast record (`econquest record`), weekdays 6:20pm New York

Ticket EQ-A-0009. Owner: Team A, AGENT-06. Operator: Sam (or the scheduled job on the Mac). Written
2026-10-23 from `econquest/cli.py` (`cmd_record`, `cmd_prices`) and `econquest/validation/record.py`.

## Purpose

Append one row per trading day to `data/forecast_record.csv`. Each row holds the book's realised loss for
the day, the one-day VaR/ES forecast made the previous day, the GARCH-DCC forecast for the next day, the
12-month MC VaR/ES and regime, and the code and data hashes. After 250 rows the Basel traffic-light test
means something. A missed day cannot be recorded later as a true forecast.

## When

Weekdays at 18:20 America/New_York.

**Change 2026-10-24 (EQ-A-0054, Sam 12:31Z):** prices no longer come from Google Finance. The Sheets export
and `econquest prices --sheet-json` are retired; the latter refuses unless the research-only opt-in
`ECONQUEST_ALLOW_GOOGLEFINANCE=1` is set, and even then it writes only under `research/`. Daily prices will
come from official BIS/ECB FX (`python -m econquest.ingestion.market_history build|apply`, runbook
`A-official-fx.md`, section "Daily FX history"). Sam signed off the FX-only change (Tier 1, EQ-B-0077) on
2026-10-24. Until the first `market_history apply` on the Mac (see `A-mac-pull-pack.md`), `prices.csv` is not
refreshed and `record` re-records against its last date (2026-10-23), so those rows are not true daily
forecasts. Note any such days in the backtest notes.

## Prerequisites

- econquest at `/Users/smc/econquest`, with `data/market_history/prices.csv` present.
- Network access to BIS (`stats.bis.org`) and the ECB (`data-api.ecb.europa.eu`). No Sheets token is needed.
- Know how `record` handles prices: it marks the book against the **last complete date in `prices.csv`**.
  If prices were not refreshed, it re-records the previous day.

## Steps

```bash
cd ~/econquest
# 1. Record (marks the book on the last date in prices.csv)
econquest record 2>&1 | tee -a outputs/record.log
# 2. Build the official FX history (staged only; prices.csv untouched)
python -m econquest.ingestion.market_history build --start 2023-10-18
```

After the first manual `market_history apply` on the Mac (done only after Team B reran the effect table and
`replicate` on the staged build), set `"record_job_apply_prices": true` in `ops.json` in the econquest home folder
(off by default, from 0.4.0), then rerun `econquest schedule install --load`. `econquest health` warns
`pending_reinstall` on its `record_mode` check until you do; `econquest schedule show` prints the mode
(Team C runbook `team/runbooks/C-schedule.md`). The job then builds with `--apply` first and runs `record` second, so the record marks
the book on today's official rates. Never run `build --apply` unattended before that first manual apply.

Add `--no-mc` to step 3 to skip the 12-month Monte Carlo when time is short. The row then has no
`var99_12m`, `es99_12m` or regime.

**Scheduling.** Use `econquest schedule` (EQ-C-0022), not a hand-made plist. It writes launchd jobs that run
the steps above through the job wrapper (start, end and exit code are logged):

```bash
econquest schedule show                      # what would be installed: record weekdays 18:20 New York, plus
                                             # morning 07:00, monitor Mon 07:45, backup 23:30, health every 15 min
econquest schedule install --load            # writes ~/Library/LaunchAgents/com.econquest.*.plist and loads them;
                                             # an old com.econquest.record.plist is backed up first
econquest schedule install --job record --load --record-time 18:20   # only the record job
econquest schedule uninstall --load          # remove the jobs
```

Times are New York (`--tz America/New_York` is the default) and are converted to the Mac's clock when the
plists are written, so rerun `econquest schedule install --load` after a DST change if the Mac is not on New
York time. The Mac must be awake: `pmset repeat wakeorpoweron MTWRF 18:15:00`.

## Verification

- Step 2 prints the staged build folder (`data/market_history/builds/<vintage>/`) and any `unserved` columns or
  BIS/ECB disagreements. A build failure does not affect step 1.
- Step 1 prints `[record] <date>: loss ... on N positions (prev <date>)`. `<date>` is the last date in `prices.csv`;
  it is **today** (or the last trading day) only once official FX is applied daily, and N should match the markable positions (13 on the
  2026-10-23 book).
- `Record: R rows`. R went up by 1, or stayed level if this was a rerun on the same day.
- `tail -1 data/forecast_record.csv` has today's date, a non-empty `var` (yesterday's forecast) and
  `var_next`.
- Freshness of the record's input (EQ-A-0119, read only):
  `python -m econquest.ingestion.freshness prices`. It prints each `prices.csv` column's last priced date against
  the 30-day official FX limit, and the date `record` will mark with how many weekdays it trails today. On the shared
  data on 2026-10-25 it reported no breach, but `record` would mark 2026-10-20, three weekdays back. The BIS-served
  columns end on 2026-10-20, USDARS on 10-14 and USDCOP on 10-16, so only 7 of 17 columns are priced after 10-20.

## Failure handling

| Symptom | Action |
|---|---|
| Build fails (host unreachable, empty BIS pull) | Nothing is written. Rerun step 2 later; `record` is unaffected |
| `prices --sheet-json` refused | Expected since 2026-10-24: the Sheets/Google Finance step is retired. Remove it from any hand-made job and use `econquest schedule install --load` |
| `[record]` date is yesterday's | Prices were stale (expected until official FX is applied daily). Reruns are safe: `append_record` replaces the row for that date |
| `No price history: ...` | `data/market_history/prices.csv` is missing. Restore it (`A-restore.md`) |
| Day missed entirely | `econquest record --backfill 5` adds the missing weekdays without touching existing rows. Backfilled rows are marked `backfill` in `recorded_at` and use the backfill GARCH refits. Say so in the backtest notes |
| Forecast Record tab not written | The row is still in the CSV. The tab is rewritten in full the next time `record` or `publish` runs with a token |

## Owner

Runbook: Team A, AGENT-06. Job: Sam. Team C owns the scheduler work for moving this to a server (roadmap
4.6, epic A8).
