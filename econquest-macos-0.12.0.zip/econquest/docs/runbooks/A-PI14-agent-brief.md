# Team A PI-14 agent brief (Sam "Go" 2026-10-26 18:14Z)

Theme: trust and readiness for the real-data day, ending in 0.11.0 (Team C builds it last, demo rows M21-M24;
M21 is the real-data-day rehearsal and leans on A-0138). Everything is built on shared data; nothing depends on
Sam's Mac pass. Sam-gated items are parked in docs/runbooks/A-sam-ready.md (Team A) and team/when-sam-is-ready.md.

All standing rules apply (A-PI11/12/13 briefs):
- Never invent data. Make no cloud fetches of data hosts. Synthetic fixture content is labelled SYNTHETIC.
- No secrets in argv, logs or files.
- Checkpoint every file before editing it, and checkpoint new files BEFORE creating them. teamctl cannot checkpoint a directory.
- Run `teamctl check --ticket` to 0 before reporting.
- Run your own test files, not the whole suite.
- Runbook commands must be zsh-safe and use `--author Sam`.

Env: `export ECONQUEST_TEAM=A PYTHONPYCACHEPREFIX=/tmp/claude-0/-home-claude-econquest-main/4d046af0-0329-5499-894e-87a0bbd3789c/scratchpad/pyc`.
Repo: /mnt/attach/project-files/econquest.

Revert rule: never run `teamctl revert --ticket` on EQ-A-0077 or EQ-A-0130..0136. Their checkpoints of
data/licences.csv predate later rows. Revert by path, or remove rows by hand.

Invariants:
- data/ values, data/mvp (d3564255…) and Team B's base (desk 20k as of 2026-10-23: 66.55/88.44/4.00/71.83) do not
  move. No data/mvp rebuild is planned this PI; ask AGENT-08 first if you think one is needed.
- The DEMO data room is 2026-10-26T133300Z-DEMO. The client-safe datasets are d3_yes 686b3d24 and d3_no e1d98470.
- data/licences.csv is ffad313d (96 rows). AGENT-04 owns it, and only tighten-only rows may be added.
- New output folders need an ownership row: send AGENT-08 the pattern first.

| Ticket | Agent | Owns |
|---|---|---|
| A-0138 real-data day rehearsal + upgrade paths from every zip since 0.4.2 (feeds C-0166 M21) | AGENT-06 | landing.py, macpass_landing.py, replay.py, new tests; uses the shipped zips in /mnt/attach/project-files/ read-only |
| A-0140 hazard panel readiness (feeds B-0140) | AGENT-03 | panel_history.py, default_panel.py, data/panel/hazard_panel* (no value changes to data/), new panel outputs |
| A-0139 GDELT FIPS reference + event taxonomy shared with UCDP (feeds B-0142) | AGENT-02 | ingestion/events/*, reference tables with cited source |
| A-0141 security Lows for Team A paths + review of new adapters | AGENT-09 | review + small fixes, EXC rows via the exception process (Sam-approval rows parked) |
| structure review (last) | AGENT-05 | review + small fixes |

Hand-offs:
- When A-0140 passes, give B/AGENT-03 the panel API, the missing-predictor map and the one-command refit path.
- When A-0139 passes, give B/AGENT-02 the unified event API.
- When A-0138 passes, give C/AGENT-08 the M21 rehearsal command and expected output.
