# Desk assistant runtime: self-hosted model (Ollama or vLLM)

Team C, PI-15 (EQ-C-0170 provider interface, EQ-C-0171 runtime config). Code: `econquest/assistant/`.

This page is for when Sam chooses a model and a host (parked in `team/when-sam-is-ready.md`, PI-15). Nothing on it
has been done, and nothing in econquest depends on it. Until then the assistant is off, and every entry point says
so in one line:

```
econquest assistant status
assistant off: no assistant.json in the install folder. It ships off; to switch it on see docs/runbooks/C-assistant-runtime.md.
```

## What the assistant is

- It explains the desk from cited context. It never computes a risk number and never runs the engine.
- Every answer must cite its sources (`[cite:<id>]`). The model never writes a number: it writes slots such as
  `{{r1.var99_mm}}` or `{{<id>.t1}}`, and Team B's QA gate (eq-assistant-qa/2, EQ-C-0176) fills them from the cited
  rows. Any digit, number word or date the model types itself refuses the answer (`model_number`).
- Context comes from the `context_provider` hook. Later tickets connect Team A's `econquest.ingestion.context`. Until
  then it uses a read-only minimal context: the run summary and the country table from `outputs/run_latest.json`.
- Logs hold hashes and token counts only (`outputs/logs/assistant.jsonl` and the `econquest.assistant` logger). They
  never hold the prompt, the answer or a key.

## Backends

| backend | what | network | gates |
|---|---|---|---|
| `openai_compat` (default) | OpenAI-style `/v1/chat/completions` (Ollama, vLLM) | loopback only, unless the host is listed in `allow_hosts`; no proxy, no redirects; timeout and size cap | model licence row (below) |
| `anthropic` (optional) | Claude Messages API, model `claude-opus-5-5` by default | external HTTPS | `allow_external: true`; always refused for client-scope material; key from the macOS Keychain or `$ECONQUEST_ANTHROPIC_KEY` only |
| `stub` | deterministic answers from the context, for tests and the demo | none | none |

## The model licence gate

The `openai_compat` provider does not start until the configured `model` has a row in `data/licences.csv` (Team A's
register, read through `ops/licence_gov`). That row must have `terms_verified` yes, `commercial` yes and
`internal_use` yes. The row is either named by `licence_source_id`, or found as a `model_*` row whose `match_series`
regex matches the model id. Without one, `setup --check` and `ask` name the row that is needed.

Team A adds model rows on request (HO-20261027-C-A-001; tighten-only, so client output and the validator room stay
barred). The candidates there, still to be verified by Team A:

| row | model | licence (to verify) |
|---|---|---|
| `model_qwen2_5` | Qwen2.5 Instruct 7B / 14B / 32B | Apache-2.0 (the 3B and 72B weights use the Qwen licence instead) |
| `model_mistral_7b` | Mistral 7B Instruct v0.3 | Apache-2.0 |
| `model_llama_3` | Llama 3.1 / 3.2 / 3.3 | Llama Community Licence: commercial use allowed under conditions (700M monthly-user threshold, acceptable use policy, "Built with Llama" attribution); not OSI |
| `model_gpt_oss` | gpt-oss-20b / gpt-oss-120b | Apache-2.0 (plus OpenAI's usage policy) |

As a rough sizing guide, a 7B to 8B instruct model at 4-bit quantisation needs about 5-6 GB of memory. That runs on
an Apple-silicon Mac with 16 GB. The 20B to 32B models want 32 GB or more.

## Option 1: the Mac, with Ollama

1. Install Ollama (the macOS app from ollama.com, or `brew install ollama`). It serves on `127.0.0.1:11434` and
   exposes the OpenAI-style API under `/v1`.
2. Pull the chosen model, for example `ollama pull qwen2.5:7b-instruct`.
3. Write `~/econquest/assistant.json` (the install folder, next to `ops.json`):

   ```json
   {"enabled": true, "backend": "openai_compat", "base_url": "http://127.0.0.1:11434/v1",
    "model": "qwen2.5:7b-instruct", "licence_source_id": "model_qwen2_5"}
   ```

4. Check it without the network, then with a probe of the local server:

   ```
   econquest assistant setup --check
   econquest assistant setup --check --probe
   econquest assistant ask "Why is Pakistan in the stressed regime?" --country PAK
   ```

Keep Ollama bound to loopback (its default). Do not set `OLLAMA_HOST=0.0.0.0` on a laptop.

## Option 2: the server option, with vLLM or Ollama

The server deployment (`deploy/server/`, EQ-C-0157) is off by default. `deploy/server/compose.example.yaml` has an
optional `ollama` service, commented out. It publishes no port, and only the econquest container reaches it on the
compose network. To use it, uncomment the service and its `ollama-models` volume, and pin an exact image tag. Then
pull the model inside it (`docker compose exec ollama ollama pull qwen2.5:7b-instruct`) and set:

```json
{"enabled": true, "base_url": "http://ollama:11434/v1", "allow_hosts": ["ollama"],
 "model": "qwen2.5:7b-instruct", "licence_source_id": "model_qwen2_5"}
```

vLLM (Linux with an NVIDIA GPU) serves the same API. Run it on the server's loopback or private network, never
public:

```
vllm serve Qwen/Qwen2.5-7B-Instruct --host 127.0.0.1 --port 8000
```

Then use `"base_url": "http://127.0.0.1:8000/v1"` and `"model": "Qwen/Qwen2.5-7B-Instruct"` (the model id vLLM
reports). A private host name other than loopback goes in `allow_hosts`. The assistant contacts nothing else.

## The optional Claude backend

**Sam decided on 2026-10-27 (17:38Z): "Claude API is allowed".** The Claude backend is an allowed choice. It still ships
off, and it is used only when assistant.json sets `backend: anthropic` and `allow_external: true` and a key is in
the Keychain. It stays refused for client-scope material (client surfaces, client mode), and the same slot gate,
tool allow-list and fencing apply as for the self-hosted model.

- Key on the Mac: a Keychain item with service `econquest-anthropic`. The item is added interactively with
  `security add-generic-password -s econquest-anthropic -a econquest -w` (no value after `-w`, so the key is typed
  at the prompt and never lands in shell history or argv).
- Key on the server: the environment variable `ECONQUEST_ANTHROPIC_KEY`, set from the deployment's secret store. It
  never goes in a file in the repo, in assistant.json or in a log.
- assistant.json: `{"enabled": true, "backend": "anthropic", "allow_external": true}`. The model defaults to
  `claude-opus-5-5`; set `anthropic_model` to change it.
- Client-scope material is always refused for this backend, whatever the config says.
- The request uses API version `2026-10-21` and sends no `temperature`, which that version rejects.

## assistant.json keys

`enabled`, `backend`, `base_url`, `allow_hosts`, `model`, `licence_source_id`, `anthropic_model`, `allow_external`,
`timeout_s` (1-600, default 60), `max_response_bytes` (default 2 MB), `max_tokens` (default 800), `temperature`
(default 0), `tools` (`auto` default, `native`, `text` or `off`: how tools are offered, EQ-C-0176), `weights_digest`
(the model weights' digest, recorded on every draft) and `seed` (null or a whole number, recorded on every draft).
`strict` is still accepted and ignored: the slot gate alone decides (SEC-C-027 L10). An unknown key, a wrong type or a symlinked file is a problem, and the
assistant stays off. `econquest assistant setup --check` lists every problem and what is missing. It never writes
the file.

## Exit codes

- `ask`: 0 answered, 1 refused or error, 3 off.
- `setup --check`: 0 ok (including off, with nothing configured), 1 problems.
- `status`: always 0.

## Surfaces (EQ-C-0172)

Everything below is off while the assistant is off, and works offline with the `stub` backend.

- **Context.** With no hook installed, `ask` reads Team A's `econquest.ingestion.context.build_context`
  (HO-20261027-A-C-001) on `--data` and `--out`, keeps the chunks that best match the question (at most 40, about 24,000
  characters) and falls back to the built-in run-JSON context when that package cannot be imported or returns nothing.
  Client audience (`--client`, or research.json client mode in effect) asks for `scope="client"` chunks only.
- **Tools.** Team B's registry (`validation.assistant_tools`, EQ-B-0145) is offered in the native OpenAI `tools`
  field (Claude: `input_schema`) when the backend takes it; `tools: auto` falls back to the plain-text protocol
  (`TOOL_CALL {"name": ..., "arguments": {...}}` lines) when the server answers 400 or 422 to a request with tools.
  Only `event_lookup`, `archive_search` and `depth_views` are offered; the run tools need a pinned engine run and are
  not. At most 3 calls a reply, 2 rounds. Results reach the model as Team B's model_view rows (slots to copy).
- **QA gate.** Every answer, morning section and draft passes Team B's slot gate (HO-20261027-B-C-001 as amended):
  only `render_answer`'s text is shown (the label line, the body with slots filled, a Figures list and Citations;
  `<<` / `>>` escaped). Team C's own free-text number check is retired. A refusal shows the refusal text, never the model's; one retry is offered (a y/N prompt,
  `--retry`, or the GUI's *Ask once more*), never more.
- **Log.** `<out>/logs/assistant.jsonl`, one line per request: surface, backend, model, verdict, sha256 of the prompt,
  the reply and the shown text, token counts, and the gate's `res.to_dict()` with its text fields replaced by hashes.
- **GUI.** Home tab: *Ask the desk assistant* (`POST /api/assistant/ask`), *In plain words* (shown only when the
  morning payload carries it) and the *Draft note editor* (`POST /api/assistant/draft`). Same token, Origin, loopback
  and JSON content-type guard as every POST; text is shown through `esc()` only, sources as source_id text, URLs never
  as links.
- **Morning.** `econquest morning` and the Home tab add `plain_words` (text and JSON) only while the assistant is on:
  the day's drivers explained from the morning payload's own figures, gated.
- **Drafts.**

      econquest assistant draft --country PAK --by "First Last"   # gated, archived as a DRAFT version (v1)
      econquest assistant edit <id> --file note.md --by "First Last" --reason "why"
      econquest assistant drafts [--verify]                      # the drafts; --verify the audit chain
      econquest assistant sign <id> --by "First Last"            # re-gated, then a SIGNED version (research QA gate)

  Drafts are Team B's archive drafts (`validation.assistant_drafts`, EQ-B-0148, HO-20261027-B-C-005), labelled
  "model-assisted, not validated". Every version lives in the research archive, but list and search show a draft only
  once it is signed, and a draft is never the assistant's context. The editor holds slot text; a figure the analyst
  types goes in a marker, `[[analyst-entered: TEXT | source: CITATION]]`. Context dated after the run's as_of is left
  out of a draft. Signing is the CLI only (SEC-C-027 M7), by a named person, with the real data folder.

## Sam's choice: Ollama with Gemma 4 (2026-10-27)

Sam said on 2026-10-27 that he will likely use Ollama with Gemma 4. Notes for when he sets it up:

- **Licence.** Gemma 4 weights are released under Apache-2.0 (https://ai.google.dev/gemma/apache_2). Google's Gemma
  Terms of Use page says they do not govern Gemma 4. The register row `model_gemma_4` is UNVERIFIED until Sam approves
  it, so until then the gate refuses.
- **Tags.** Use a local tag: `gemma4:e4b` (about 7-10 GB, the Ollama default), `gemma4:12b` (about 8 GB, 256K
  context), `gemma4:26b` or `gemma4:31b` (16-20 GB), or the `-mlx` variants on Apple silicon. Never use `gemma4:cloud`
  or `*-cloud`: Ollama runs those off the machine, and the licence gate refuses them as an external send.
- **assistant.json** (in `<home>`):
  `{"enabled": true, "backend": "openai_compat", "base_url": "http://127.0.0.1:11434/v1", "model": "gemma4:12b",
  "licence_source_id": "model_gemma_4"}`.
  Then run `econquest assistant setup --check`, and add `--probe` once Ollama is running.
