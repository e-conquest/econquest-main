# Sanctions lists: adapters, store and exposure counts (EQ-A-0133)

Owner: Team A (AGENT-01). Code: `econquest/ingestion/sanctions/`. Tests: `tests/test_sanctions_a133.py`, which run on
SYNTHETIC fixtures in `tests/fixtures/sanctions/` (invented names; no real person or entity).

## Lists

| Key | List | File | How it is pulled |
|---|---|---|---|
| ofac_sdn | OFAC SDN | SDN.XML (preferred), or SDN.CSV + ADD.CSV | `fetch` on the Mac |
| ofac_cons | OFAC Consolidated (non-SDN) | CONSOLIDATED.XML | `fetch` on the Mac |
| eu_fsf | EU consolidated financial sanctions (FSF) | XML 1.1 full list | by hand: the FSF link carries a token |
| uk_ofsi | UK OFSI Consolidated List | ConList.csv (2022 format) | `fetch` on the Mac (check it is still published) |
| un_sc | UN Security Council Consolidated List | consolidated.xml | `fetch` on the Mac |

The URLs and hosts are in `sanctions/base.py` LIST_SPECS. None was reached from the cloud. Every layout follows the
publisher's documentation and is UNVERIFIED against a downloaded file (`layout_verified False`). An unexpected layout
is refused with LayoutError, never repaired. The first Mac pull is the layout check.

What each list gives:

| | Entry id | Publication date | Listing date | Country links |
|---|---|---|---|---|
| OFAC XML | uid | Publish_Date | not given | nationality, citizenship, address, vessel flag, programme |
| OFAC CSV | ent_num | not in the file: pass `--published` | not given | address (ADD.CSV), vessel flag, programme |
| EU | euReferenceNumber | generationDate | earliest regulation publicationDate | citizenship, address, birth, programme |
| UK | Group ID | Last Updated | Listed On | nationality, birth, address, regime |
| UN | REFERENCE_NUMBER | dateGenerated | LISTED_ON | nationality, address, birth, regime |

Country text is mapped through the repo's ISO tables. Misses are listed in the snapshot's meta.json `unmapped` and
never guessed. A programme links to a country only when its tag names one ("VENEZUELA-EO13850", EU "VEN", UN "DPRK"
through PROGRAMME_ALIASES). Thematic programmes (SDGT, GLOMAG, Counter-Terrorism) link to none.

## Store (data/sanctions/, approved by A/AGENT-08 2026-10-26)

```
data/sanctions/drop/<list>/                                   manual download (EU)
data/sanctions/snapshots/<list>/<publication_date>_<sha16>/   source_* (read-only), entries.csv, links.csv, meta.json
```

- Point-in-time: `store.snapshot_as_of(data, list, as_of)` returns the latest snapshot published on or before
  as_of. Later files are never seen.
- Write-once: the same bytes twice is a no-op.
- The store holds personal names. It is outside data/live, outside versioning's data hash
  (tested), and never frozen into data/mvp. `sanctions` is added to mvp_dataset.EXCLUDE_DIRS in EQ-A-0130;
  until then the test is xfail.

## Exposure counts

```
python -m econquest.ingestion.sanctions exposure --as-of 2026-10-25 --data data            # counts, CSV
python -m econquest.ingestion.sanctions exposure --as-of 2026-10-25 --data data --programmes
```

Counts are per desk country and list. The metrics are in `exposure.METRICS`:
- links: entries linked by any link, then by link type;
- entry types: individuals, entities, vessels;
- flags: central_bank and state_owned, both text flags and so lower bounds;
- listed_12m.

The per-programme table counts entries per programme. A list with no snapshot gives no rows, never 0.

Indicator candidate: `exposure.candidate_rows` emits kind "input" rows proposed for 4.10, plus 2.7 for OFAC. They
never reach indicators.csv. A desk cell needs Team B's level rule (HO-20261026-A-B-009), and the cells stay held
until it exists.

## Licences

The rows in data/licences.csv are ofac_sanctions, eu_sanctions, uk_ofsi_sanctions and un_sanctions. They match by
path under data/sanctions/, and ofac_sanctions also matches the exposure-row tag.
- All four are UNVERIFIED and tighten-only: internal use yes, client output restricted, validator room UNVERIFIED.
- The ticket brief says OFAC is a US Government work (public domain) and that the EU, UK (OGL) and UN lists are
  generally reusable. That is recorded as the brief's statement, not as terms read on record.
- Loosening a row needs the terms page read and quoted, and Sam's decision (A-sam-ready item 16).

## On the Mac

See docs/runbooks/A-sam-ready.md item 16. After each pull:
1. Run `python -m econquest.ingestion.sanctions snapshots <list>` and check the entry count against the publisher's
   page.
2. Read `unmapped` in meta.json, and send any desk-relevant country names to AGENT-01 for an ISO table row.
