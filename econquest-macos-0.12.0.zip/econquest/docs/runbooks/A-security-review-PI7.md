# PI-7 data security review (SEC-A-008, EQ-A-0066)

- **Author:** A/AGENT-09
- **Date:** 2026-10-24
- **Ticket:** EQ-A-0066 (In Progress)
- **Severity summary:** 0 Critical, 0 High, 2 Medium (fixed), 3 Low (fixed), 9 Info.
- **Merge veto:** none. No Critical or High finding.

This review lives here because `teamctl owner team/security/...` gives Team C. The threat-model rows are staged at
`/mnt/attach/project-files/staging/EQ-A-0066/threat-model-rows.md` for C/AGENT-09 (handoff below). The previous
review is `A-security-review-PI6.md` (SEC-A-007).

## Scope

| Ticket | Code |
|---|---|
| EQ-A-0061 | `econquest/ingestion/landing.py` (reads report.json, state.json and pullpack.log from Sam's Mac: untrusted) |
| EQ-A-0063 | `econquest/ingestion/spreads.py`, the `replay.py` SKIP_DIRS line |
| EQ-A-0064 | `econquest/ingestion/weo_vintages.py`, the `panel_history.parse_weo_tab` change |
| EQ-A-0065 | `econquest/ingestion/dq_report.py` |
| EQ-A-0062 | `econquest/ingestion/coverage_gaps.py`, `official/wdi_extra.py`, the three `feeds.py` lines |
| EQ-A-0060 | `audit.py` client restriction for national sources and CSV neutralising; `market_history` apply rebuild-compare and crash safety; `nowcast_feed` MergeStopped; the spreads/ withhold rule |
| — | `dataroom.py` handling of `data/live/landing`, `data/panel/weo_vintages`, `data/market_history/spreads`, `outputs/dq` |

## Method

- **Code review.** The `teamctl diff --ticket` output of EQ-A-0060 to EQ-A-0065, and the functions those diffs call:
  `pullpack._fx_verify/_fxh_verify/_ph_verify/_events_verify`, `feeds.verify_vintage/vintage_path`,
  `events.base.read_event_vintage`, `replay.freeze_inputs`, `dataroom._plan`, `audit.client_output_reason`,
  `official.central_banks.licence_ok_sources`, `market.public.fred_url/fred_api_key`.
- **Probes.** Offline, in the scratchpad, not committed:
  - landing on a synthetic pack whose state.json points `fx_history.prices` at a file outside `--data`, at
    `../secret.csv` and at a symlink leaving `--data`; a `run_id` of `../../../evil`; a step record that is a string;
    a state.json nested 200,000 levels deep; a `reason` holding `\n- [x] forged check line`;
  - `dataroom._plan` on a copy of `data/` with a `live/landing/landing_report.json`, with and without include_current;
  - `audit.client_output_reason` on the WDI REER and credit series texts and on an unlisted national source;
  - formula-prefix scan of `coverage_gaps_part3.csv` and the three `market_history/spreads/*.csv` files: 0 cells.
- **Bandit 1.9.4** on the 13 in-scope modules (7,870 lines): 0 issues; 6 existing justified `nosec` skips.
- **Credential grep.** FRED_API_KEY and ECOS_API_KEY assigned to 8 or more characters over `data/`, `docs/`,
  `econquest/`, `tests/`: no hits.
- **No network calls.** pip-audit was not run, because it needs the network. Run it on the Mac or in CI (T5).

## Findings

| ID | Severity | Status | Where | Summary |
|---|---|---|---|---|
| M1 | Medium | fixed | `landing.locate`, `_v_panel_history`, `_panel_vintage_ok`; `pullpack._ph_verify` | Paths and ids from the untrusted pack files were followed outside `--data`; the first line of any local file could be quoted into the landing report |
| M2 | Medium | fixed | `replay.SKIP_DIRS`; `dataroom` FOLDER_STORES | Every pull froze the whole WEO archive (and panel staging runs with the WEO file cache) into a new replay snapshot; the data room got the archive only through those copies |
| L1 | Low | fixed | `landing._read_json`, `load_pack`, `check_step` | No size bound on report.json / state.json; deep nesting and non-object step records crashed with a traceback |
| L2 | Low | fixed | `landing._md` | Pack text (reason, details, notes) could open its own Markdown lines, e.g. a forged `- [x]` check line in landing_report.md |
| L3 | Low | fixed | `dq_report._md_cell`, `_counts_line`, `_status_line`, findings and errors | CR was not collapsed in table cells; counts lines, status details, findings and errors were written unescaped |
| I1 | Info | open | `spreads.py` | BoK ECOS rows are `restricted=False` with an UNVERIFIED licence; raw CSV rows carry no licence column |
| I2 | Info | open | `weo_vintages.verify_release` | Follows a symlinked file inside a release folder; a basis other than `estimated` is not checked against a rule |
| I3 | Info | open | `market_history._is_official_prices` | Trusts any `builds/<x>/` whose own sidecar matches its prices.csv, without re-verifying that build's vintage |
| I4 | Info | for AGENT-08 | data room, `data/live/landing` | Left out by default (undated working copy); with include_current it goes in, with Mac paths and pack text |
| I5 | Info | by design | data room, WEO raw files before 2020-10 | Latin-1 without a BOM: withheld as unscannable, so the release folder is `altered` in the room |
| I6 | Info | residual | `landing._stage_dir` | A recorded staged folder outside `--data` is still used when it is a real econquest data folder |
| I7 | Info | known | `official/wdi_extra.py` | wbgapi does its own HTTP (SEC-A-006/007 I5). REER (IMF via WDI) is client-restricted: verified |
| I8 | Info | by design | `central_banks.licence_ok_sources` | A national source is cleared when all its rows in cb_series_verified.csv say licence_ok=yes |
| I9 | Info | open (carried) | `nowcast_feed.BisNowcastFeed.url` | SEC-A-007 I2 unchanged: flow and key from the map CSV are not URL-quoted, and `key` is used as a format string |

### M1: landing check follows untrusted paths outside the data folder (fixed)

**What.** `landing.check` reads report.json and state.json that Sam sends from his Mac, and uses the paths and ids
recorded there.

- `locate()` joined each recorded path onto `--data` unchecked, so `..` parts left the folder.
- It followed symlinks.
- It fell back to the recorded path itself whenever that path existed on this machine, so any absolute path was
  accepted.
- `_v_panel_history` joined `run_id`, and `_panel_vintage_ok` joined `panel_vintage`, to paths without a format check.
- `pullpack._ph_verify` (re-used here) joined the manifest's `final` file names to `data/panel`.

Probe result: with `fx_history.artifacts.prices` set to `/tmp/.../secret.csv`, the landing report quoted that file's
first line: `extra ['TOPSECRET', 'line']`.

**Exploit scenario.** A pack file that was edited in transit, or by mistake, does two things:

- **Integrity.** It points re-verification at files outside the landed data (for example a hand-made build
  elsewhere on disk). A step then "passes" on files that are not the landing. The check exists to stop exactly that:
  the report's own verdicts are never evidence, and AGENT-08 unblocks tickets on its output.
- **Disclosure.** It quotes the header line of local files into `data/live/landing/landing_report.{md,json}`.

Needs a modified report.json or state.json. No code execution.

**Fix.**

- `locate()` refuses any `..` part. A candidate under `--data` is returned only when its resolved path (symlinks
  followed) stays inside `--data`. The recorded path itself is used only when it resolves inside `--data`.
- The universe staged folder is the only exception, because pullpack writes it beside the data folder
  (`~/econquest-universe-<ts>`). `_stage_dir` passes `outside_dir_ok`, which allows a real directory (not a symlink)
  that holds `countries.csv`. `--stage-dir` from the operator is unchanged.
- `run_id` must match `panel_history.RUN_ID_RE`, and a panel vintage id must match `YYYY-MM-DDTHHMMSSZ-hash8`,
  before any path is built.
- `pullpack._ph_verify` fails a `final` entry whose name is not a plain file name.

**Verify.** `pytest tests/test_sec_a_pi7.py -k m1`

### M2: replay froze the WEO archive into every snapshot (fixed)

**What.** `replay.freeze_inputs` runs on every `fetch_and_save` (feeds.py line 2147). It copies every file under
`data/panel` (FROZEN_TREES), skipping only SKIP_DIRS. EQ-A-0063 added `market_history/spreads` there. EQ-A-0064 did
not add `panel/weo_vintages`. So every pull would copy the whole WEO archive into a new
`live/snapshots/<vintage>-inputs/` folder: a raw release file per WEO release since 2007 plus `weo_long.csv`. It would
also copy panel_history's `staging/` runs and the `staging/weo_cache` release files it imports from.

`dataroom.build_data_room` exports every replay snapshot up to the cutoff, so a room would hold one copy of the archive
per pull. The archive reached the room only through those copies: `panel/weo_vintages` is not a folder store, and its
`YYYY-MM` folder ids carry no time, so the folders themselves were undated working copies.

**Impact.** Availability and data hygiene, with no attacker needed. It is latent until the first real history pull
and WEO import: no WEO release is archived yet, and `data/panel/staging` does not exist. The archive itself gains
nothing from being frozen:

- it is append-only, 0444 and hash-indexed;
- `weo_asof` reads it point in time by release date.

**Fix.**

- `replay.SKIP_DIRS` gains `panel/weo_vintages` and `panel/staging`.
- `dataroom` gains a folder store for `panel/weo_vintages`. A release folder is selected when its first
  `index.csv` row has `imported_utc` at or before the cutoff. The index is filtered to the selected rows. The kinds
  `weo_vintage` and `weo_vintage_index` have their own as-of rules.
- The README's folder table names the archive, and its IMF note cites EXC-003. The room keeps including the archive
  for the validator under NDA, as Sam decided (EXC-003), once and point in time.

**Verify.** `pytest tests/test_sec_a_pi7.py -k m2`

### L1: pack JSON parsing limits (fixed)

- `_read_json` refuses a file larger than `MAX_PACK_JSON_BYTES` (16 MiB) before parsing.
- A `RecursionError` (deep nesting) becomes a `LandingError`: exit 1 with one line, no traceback.
- `load_pack` ignores step records that are not JSON objects, and says so in the notes.
- `check_step` reads `verify` and `unblocks` only when they have the expected types.

**Verify.** `-k l1`

### L2: Markdown injection in landing_report.md (fixed)

Every value in `_md` that can come from the pack, the board or the log goes through `_one()`. `_one()` collapses CR,
LF and whitespace runs to a single space. Table cells also turn `|` into `/`. A reason or detail can no longer add a
heading, a list item or a `- [x]` evidence line that AGENT-08 reads as a passed check. landing_report.json is
`json.dumps` and was already safe.

**Verify.** `-k l2`

### L3: dq_report Markdown values (fixed)

- `_md_cell` now collapses CR as well as LF (one-line `_one()`), then escapes `|` and keeps the spreadsheet formula
  guard.
- `_counts_line` (gate reasons, indicators, countries, feed names), `_status_line` details, findings and errors are
  made one-line the same way.
- dq_report writes no CSV.
- `write_report` already refuses an `--out` inside the data folder (resolved, so symlinks count). The build reads
  only (existing test `test_read_only_and_refuses_output_in_data`).

**Verify.** `-k l3`

### Info

- **I1. spreads licences.** The OECD-on-FRED rows are `restricted=True`, and DGS10 is public domain. BoK ECOS
  `817Y002` is `restricted=False`, but its licence text says UNVERIFIED. Raw `raw_fred.csv` / `raw_ecos.csv` rows have
  no licence column. The licence per series is in the vintage's `request.json` (registry) and in the build sidecar.

  Nothing reads these files yet (no apply), the data room withholds all of `market_history/spreads/`, and replay skips
  it. Before Team B wires any of it in (HO-20261024-A-B-009), the ECOS terms should be checked and a `licence` column
  added to the spread rows.
- **I2. WEO archive verification.** `verify_release` reads files with `read_bytes()`, which follows a symlinked file
  inside a release folder. A later content change is still caught by the content hash. A manifest with
  `release_date_basis` other than `estimated` skips the rule check, but the index.csv row must agree with it, and
  import only ever writes `estimated`. Both need local write access to `data/` (A3).
- **I3. market_history crash safety.** The sidecar-first order and `_build_shas` are sound. After a crash, the old
  prices.csv stays with the new sidecar, is not "official", and is archived again on the next apply. `_build_shas`
  accepts any `builds/<x>/` whose own sidecar hash matches, without re-verifying that build's vintage. A planted
  build folder (A3) could make a GOOGLEFINANCE prices.csv without ETF columns look official.

  Apply itself is sound: it now rebuilds an existing build from the verified vintage and compares the bytes.
- **I4. data room and the landing folder.** `data/live/landing/` has no point-in-time record, so it is left out by
  default. With `include_current` it is copied like any working copy. landing_report.json then carries Sam's Mac paths
  (his user name) and pack text: e-mail addresses are redacted, user names are not. It is a derived check report, not
  data. Suggest withholding `live/landing/` from the room even with include_current. That is AGENT-08's call.

  `outputs/dq/` is outside `data/` and never enters the room. `market_history/spreads/` is withheld (reason
  `SPREADS_RESTRICTED_REASON`, verified with include_current on a data copy).
- **I5. WEO raw files in the room.** WEO files before October 2020 are Latin-1 without a byte-order mark. The room
  withholds them as unscannable (SEC-A-006 L4), so those release folders are reported `altered`. `weo_long.csv` and
  `manifest.json` (with the licence) still go in. This fails closed.
- **I6. staged universe folder.** After M1, a staged folder recorded outside `--data` is still used when it is a real
  econquest data folder: needed for the check on the Mac and for the existing full-pass test. A forged report could
  name another data folder on the analyst's disk. The staged vintage hash is still verified. Prefer `--stage-dir`
  (runbook).
- **I7. wdi_extra.** wbgapi does its own HTTP to `api.worldbank.org`, outside `https_get` (known, I5 in SEC-A-006/007).
  Failure text is cut to 120 characters, and the World Bank needs no key.
  `client_output_reason(..., series="WDI PX.REX.REER (IMF IFS via WDI) ...")` returns the IMF reason: verified. The
  credit series (FS.AST.PRVT.GD.ZS) returns None, as intended (CC BY 4.0). Every value is held by the gate
  (`unverified`, and `method` until Team B approves).
- **I8. national licence_ok.** `licence_ok_sources` clears a source text only when every row of that source in
  `cb_series_verified.csv` says `licence_ok=yes`. It fails closed when the column or file is missing (verified: an
  unlisted national source returns the national reason). A registry series with no row in the file is not counted.
  That is acceptable, because a licence is per publisher.
- **I9. BisNowcastFeed.url (carried from SEC-A-007 I2).** The map CSV's `key` is still unquoted and is used as a
  `str.format` template with `area`. A format field such as `{area.__class__}` can only render attributes of a `str`
  into the URL, and the host stays fixed. Suggest `quote(key, safe="+.{}")` and a key pattern check in `map-set`.

## Controls verified OK (no change)

- **spreads.**
  - FRED_API_KEY is read from the environment only. ECOS_API_KEY is read from the environment, then the Keychain
    (`market.vendors.base.secret`).
  - `fred_api_key` refuses a malformed key without echoing it.
  - Every request goes through `sources.https_get` (https only, redirects refused, 20 MB cap) with bounded retries.
  - DGS10 is pulled first. Any failure raises before anything is written, and the exception is raised outside the
    `except` block, so the key is not in `__context__`.
  - Failure text is redacted with `central_banks._redact` (raw, path-quoted and form-encoded spellings) for both keys.
  - Vintages: id format checked (`check_vintage_id`), `exist_ok=False`, files 0444, index appended under
    `locked_append`, hash8 tied to the content hash. Builds are written to a temp folder and renamed, and are never
    overwritten.
  - `restricted` and `verified` are on every spread row. replay skips `market_history/spreads`.
- **weo_vintages.**
  - Import downloads nothing.
  - The staging run name must match RUN_ID_RE. Release ids must match `\d{4}-\d{2}`.
  - Staged files are checked against the run manifest's sha256. Cache file names come from a fixed pattern
    (`_LOCAL_RE`, `weo_<rel>.xls`), and a cache file must contain every staged row with the same value.
  - `parse_weo_tab` refuses files over `MAX_WEO_BYTES` before reading.
  - Release folders are written to a temp folder (files 0444, folder 0555) and renamed. An existing release is never
    overwritten: unchanged, covered or refused.
  - verify checks manifest, raw.sha256, weo_long.csv, the folder content hash against the first index row, and
    flags extra files and writable modes.
  - `weo_asof` verifies the chosen release and refuses rows dated after the as-of.
- **dq_report.** It reads the data folder only (existing read-only test) and refuses an `--out` inside it. It writes
  two files atomically and no CSV.
- **coverage_gaps.** Writes one CSV (default `data/panel/coverage_gaps_part3.csv`). Every text cell is built by code
  from fixed reason strings. A scan of the committed file found 0 formula-prefixed cells.
- **EQ-A-0060 fixes.**
  - `audit._csv_export` neutralises `= + - @ TAB CR` (SEC-A-007 I1 closed: `=HYPERLINK(1)` gives `'=HYPERLINK(1)`,
    and `-1.5` is left alone).
  - National sources are client-restricted unless licence_ok=yes, and this fails closed.
  - market_history apply: rebuild-compare of an existing build, sidecar before prices, and `archive_legacy_file`
    refuses before deleting.
  - `nowcast_feed` raises `MergeStopped`, and pullpack step 6 reports it as a failure, not a skip.
  - `market_restricted_reason` withholds `market_history/spreads/**`, including inside replay snapshots.
- **landing, other.**
  - Nothing executes. The only subprocess is Team B's validator through `nowcast_feed.validate_file`, run on the
    fixed path `data/live/nowcast_inputs.csv`.
  - No pickle or eval.
  - Vintage ids reach `feeds.vintage_path` (allowlisted against `list_vintages`) and `read_event_vintage`
    (VINTAGE_ID_RE).
  - Writes go only to `<data>/live/landing/` (or `--out`): landing_report.json/.md, written atomically, the
    missing-cell CSVs, `crag_comparison.csv` and `gdelt_mapping_qa.csv`. The functions it calls (compare_panels,
    panel_coverage, missing_cell_report, gdelt_qa) do not write.
  - `data/live/landing/` is three levels deep, so replay does not freeze it and it is not a current-pull file.

## Changed (all checkpointed under EQ-A-0066)

- `econquest/ingestion/landing.py`: M1, L1, L2
- `econquest/ingestion/pullpack.py`: M1 (`_ph_verify` final names)
- `econquest/ingestion/replay.py`: M2
- `econquest/ingestion/dataroom.py`: M2 (WEO archive store, rules, README row and note)
- `econquest/ingestion/dq_report.py`: L3
- `tests/test_sec_a_pi7.py`: 10 tests, one or more per fixed finding
- `docs/runbooks/A-security-review-PI7.md`: this review

## Handoffs

- **New handoff to C/AGENT-09:** merge the staged rows: T22 and T23 are new, and T2, T4, T16, T20 and T21 get additions.
- **For AGENT-08 (no handoff):** I4 (withhold `live/landing` from the room even with include_current?), and I1
  (licence check for ECOS before any spreads wiring) for the EQ-A-0063 owner.
