# Runbook: licensed feed go-live (Bloomberg or LSEG CDS and bond curves into layer 2)

**Status: kit built and tested on SYNTHETIC fixtures, plus an end-to-end dry run on the vendor simulator (EQ-A-0123).
Roadmap paid feature, off by default.**

Ticket EQ-A-0107. Owner: Team A, AGENT-03. Date: 2026-10-25. Builds on EQ-A-0033 (adapters,
`docs/runbooks/A-licensed-vendors.md`), EQ-A-0097 (vendor comparison `docs/runbooks/A-vendor-comparison.md`, replay
dry run), EQ-C-0108 (`econquest vendor check`), EQ-C-0106 (`econquest change` on `data/licences.csv`) and Team B's
EQ-B-0100 (layer-2 market term from CDS curves).
Code: `econquest/ingestion/market/vendors/golive.py`. Tests: `tests/test_vendor_golive_a107.py` (14 tests).
Fixtures: `tests/fixtures/vendors/golive_bloomberg/`, `tests/fixtures/vendors/golive_lseg/`.

This page is the one path from "Sam picks a vendor and signs a licence" to "live CDS and bond curves in the market
store that layer 2 reads". Licensed data is not part of the MVP (`team/mvp-checklist.md`). Every step marked
**when Sam is ready** waits for the post-MVP pass in `team/when-sam-is-ready.md`.

> **The fixtures are invented.** They use the desk's ISO codes, but the values and identifiers are made up and
> every identifier says SYNTHETIC. They are shaped after the adapters' reading of the vendor docs. They are not a
> recording of a vendor session and not market data. The wire formats are still untested against a terminal: the
> first run on a licensed machine (step 3) is the real test.

## What stays off, and why

Nothing in this kit changes a default. Today:

| Guard | Where | Effect today |
|---|---|---|
| Licence entitlement | `vendors/base.py` `require()` | No entitlement configured, so each adapter refuses before any request |
| Register approval | `golive.capture` uses the approved register from `econquest change` | No baseline yet, and the bloomberg and lseg rows are `terms_verified UNVERIFIED`, so capture refuses |
| Layer 2 switch | Team B, `probability.market_term` (not in `assumptions.json`) | Layer 2 uses profile spreads; no curve is read |
| Layer 2 licence allow-list | Team B, `layer2_bayesian.licence_approved` | A curve is used only with a `terms_verified yes` row for its exact licence tag |
| Layer 2 SYNTHETIC filter | Team B, `allow_synthetic` false | Fixture curves are never used outside tests |
| Schedule | Team C, `ops/schedule.py` `DEFAULT_JOBS` | No capture job. One exists only if `ops.json` adds it (step 6) |

The tests prove each of these on the fixtures: `test_default_register_refuses_capture_and_writes_nothing`,
`test_shipped_settings_and_schedule_keep_it_off`, and the layer-2 asserts in the two end-to-end tests.

## Already done (no Sam needed)

- [x] Adapters, licence gate, ticker map, snapshot store, market gate (EQ-A-0029, EQ-A-0031, EQ-A-0033).
- [x] Vendor comparison and recommendation: one desk-internal seat, Bloomberg or LSEG (EQ-A-0097,
  `A-vendor-comparison.md` section 8).
- [x] Register rows `bloomberg`, `lseg` (tight: UNVERIFIED, client output and validator barred) and
  `vendor_market_snapshots` (the store folder, internal only), added under EQ-A-0093.
- [x] `econquest vendor check` onboarding wizard (Team C, EQ-C-0108).
- [x] Go-live kit (this ticket):
  - ticker verification against the desk universe;
  - the register patch generator;
  - the ops.json schedule fragment;
  - gated capture (gates run before the snapshot is saved);
  - layer-2 preview;
  - an end-to-end test from fixture to the layer-2 input for both vendor shapes.

## Dry run on the vendor simulator (EQ-A-0123, no licence needed)

Owner: Team A, AGENT-06. Code: `econquest/ingestion/market/vendors/vendor_sim.py` (generator),
`vendor_sim_dryrun.py` (dry run), `econquest/ingestion/market/vendor_sim_guard.py` (the sandbox rule). Tests:
`tests/test_vendor_sim_a123.py` (10 tests).

> **Every value is SIMULATED.** The values are synthetic, generated from a fixed seed (20261026). The scale comes
> from desk anchors: the `spread` and `policy` columns of `data/countries.csv`, the last USD rates in
> `data/market_history/prices.csv`, and `cds.risk_free` in `data/assumptions.json`. These are not market data and
> not a vendor recording. Each identifier starts with `SIMULATED`. Each row's licence reads
> `<vendor>:SIMULATED-SYNTHETIC-<BBG|LSEG>-A123 (desk-internal)`. Each manifest carries the label `SIMULATED`.

It runs the whole kit, steps 2 to 7 below, on simulated CDS curves, bond curves (local and USD Eurobond), OIS, FX spot
and FX forwards for the desk names. The data goes through the real Bloomberg and LSEG adapter code: request builders,
the `parse_*` functions, the replay sessions of `replay.py`, the market gate, the go-live gates, the store,
`gated_market_history` and Team B's layer 2. Everything happens in a sandbox folder. The command is one line:

```
python -m econquest.ingestion.market.vendors.vendor_sim_dryrun --out "${TMPDIR:-/tmp}/econquest-sim-$(date +%Y%m%d%H%M%S)"
```

Without `--out`, the run uses a new temporary folder. Other options: `--seed`, `--as-of YYYY-MM-DD` (the last
simulated business day, default 2026-10-23) and `--days N` (the number of daily captures, default 3). The run takes
about a minute.

| Step | What it proves |
|---|---|
| generate | Fixtures in each vendor's wire format, `sim_manifest.json` (seed, anchors, file hashes, names left out for lack of an anchor), and the same values again from the same seed |
| probe | The real adapters accept the simulated entitlement from a private env dict, and the ticker map verifies against the desk universe. The real switches stay off: no adapter is usable on `data/`, the shipped register approves no bloomberg or lseg row, and `probability.market_term` is unset |
| pull | `pull_to_store(dry_run=True)` over the window gives back every generated value exactly, all labelled SIMULATED, with no vendor errors and nothing saved |
| gate | `golive.capture` runs each day for each vendor, with gates before the save. Only the deliberate canary is held: on the last day Bloomberg's PAK 3y CDS is quoted above its 5y, so the whole PAK Bloomberg curve is non-monotone |
| store | The snapshots verify, every row and manifest is SIMULATED, and the gated CDS export stays in the sandbox. The refusals are tested live: a desk-like folder refuses the save, and the gate holds SIMULATED rows with no data folder, `data/` or `data/mvp` |
| gated history | `gated_market_history` returns every saved row, the held canary is absent, and a second export would append nothing |
| readiness | Layer 2 preview with the default settings: every curve refused (synthetic marker). With the shipped register: refused (UNVERIFIED). Only with the sandbox register, which approves the SIMULATED ids alone and is used in memory through `licences.use_register`, plus `allow_synthetic`: every CDS name gives "curve used" |

Outputs in the sandbox:
- `report.md` and `report.json`, both headed SIMULATED;
- `fixtures/<vendor>/`;
- `sim_manifest.json`;
- `licences_sandbox.csv`;
- `live/market/snapshots/` (with the go-live reports under `golive/`);
- `market/cds_snapshots.csv`.

Exit codes: `0` when all seven steps pass, `1` otherwise or when the folder is refused.

**Why simulated values cannot reach desk data.** The rule is in code (`vendor_sim_guard.py`), with no switch or
environment variable to widen it.

A sandbox is a folder with these four properties:
- it holds `SIMULATED_SANDBOX.json`;
- it is outside the econquest folder (so not `data/`, `data/mvp`, a vintage, `outputs/` or a release);
- it has no `countries.csv`, `assumptions.json`, `indicators.csv` or `licences.csv` in itself or a parent;
- it holds no symbolic link anywhere inside it (SEC-A-014 M1: a link would carry writes out of the sandbox).

Two places enforce the rule:
- `store.save_market_snapshot` and the CDS export writer raise `SimulatedDataError` for SIMULATED rows, or SIMULATED
  provenance, anywhere else.
- `gate.market_gate` holds every SIMULATED row unless its `data_dir` is a sandbox. `golive.capture`,
  `pipeline.pull_to_store`, `cds_export.gated_history` and `market_gate_review` pass their data folder.

Layer 2 also refuses the curves by default, because the licence id contains SYNTHETIC. The tests prove each refusal
on `data/` and `data/mvp`, and check that the files under `data/` are byte-identical after a full run.

## The steps

Run every command from the econquest folder. The commands are zsh-safe. Replace each quoted `PASTE_...` placeholder, keeping the quotes.

### Step 1. Choose the vendor and sign (when Sam is ready, Tier 1)

Sam's decision, with the options and costs in `A-vendor-comparison.md` section 8. Recommended: one desk-internal
seat. Ask each vendor for a coverage file for the 18 desk names and a written quote that names the CDS entitlement.
Defer redistribution until client output is scheduled.

Sam keeps three things from the contract, all needed in step 4:
- the contract or account number (the licence id);
- the terms page or contract PDF location;
- the clauses on internal use and redistribution.

### Step 2. Install and configure the entitlement (when Sam is ready, on the licensed Mac)

Follow `A-licensed-vendors.md` sections 1 and 2:
- the vendor package;
- credentials in the environment or the Keychain only;
- `ECONQUEST_VENDOR_LICENCE_<VENDOR>` or `data/vendor_licences.json`, with `scope=desk-internal`.

Then check the entitlement. `econquest vendor check` reports credentials by presence only:

```
econquest vendor status
econquest vendor check bloomberg
```

### Step 3. Verify the tickers against the desk universe (when Sam is ready; on the terminal)

1. Create the ticker map: `python -c "from econquest.ingestion.market.importers import ensure_ticker_map; ensure_ticker_map('data')"`.
2. Verify each row on the terminal (`A-licensed-vendors.md` section 3). Set `status` to `verified`, and replace the
   `TEMPLATE GUESS` note with who checked the row and when.
3. Check the map against the desk universe:

```
python -m econquest.ingestion.market.vendors.golive verify --vendor bloomberg --data data
```

It exits 0 only when there are no problems and at least one instrument is ready. A problem is any of these, on a
verified row:
- an ISO that is not one of the 18 desk names (the UST benchmark `USA` is allowed);
- an fx currency that is not a desk currency;
- the wrong unit for the field;
- a CDS row without a doc clause;
- a government curve in a currency other than the country's own, USD or EUR;
- a blank vendor field where the adapter has no default (LSEG);
- a note still saying TEMPLATE GUESS;
- a duplicate identifier or series.

Coverage gaps are listed but are not problems. A gap is a desk name that trades CDS but is missing one of the
1, 3, 5 or 10 year tenors.

4. Run one dry run per vendor with someone watching. It pulls and gates in memory and saves nothing:

```
econquest vendor check bloomberg --ticker "PASTE_ONE_VERIFIED_TICKER" --as-of "PASTE_LAST_BUSINESS_DAY_YYYY-MM-DD" --dry-run-pull
```

Compare each value with the terminal screen. If a value, date or unit differs, stop and open a defect on EQ-A-0033.
The parsers were written from docs (`A-licensed-vendors.md` section 5).

### Step 4. Approve the licence in the register (when Sam is ready; `econquest change`)

The register must first have an approved baseline. That is Sam's sign-off, R44 (`ops/licence_gov.py`
`FIRST_BASELINE_CMD`):

```
python -m econquest change baseline licences.csv --actor "Team A AGENT-06" --approver Sam --reason "R44: first approved licence register (EQ-C-0106)"
```

Write the patch from the contract. Every value comes from the signed contract, and nothing is defaulted:

```
python -m econquest.ingestion.market.vendors.golive register-patch --vendor bloomberg --licence-id "PASTE_CONTRACT_NUMBER" --scope desk-internal --terms-url "PASTE_HTTPS_TERMS_PAGE" --terms-read "PASTE_DATE_READ_YYYY-MM-DD" --clause '[internal use] "PASTE_QUOTE" [redistribution] "PASTE_QUOTE"' --licence-text "PASTE_LICENCE_AS_SIGNED" --out /tmp/bloomberg-golive.json
```

The patch changes only the existing `bloomberg` (or `lseg`) row:
- `match_licence` is narrowed to exactly `^bloomberg:<id> \(desk-internal\)$`. Another licence id, or the
  redistribution scope, matches no approved row.
- `terms_verified` becomes `yes`.
- `licence_text`, `terms_url`, `terms_read_utc` and `clause` hold the evidence, and `notes` records the ticket.
- `client_output` and `validator_nda` stay `barred`. Those are a separate decision for Sam.

The tool validates the patched register before it writes the file. The change is a loosening, so only Sam can
approve it:

```
python -m econquest change propose licences.csv --patch-file /tmp/bloomberg-golive.json --author Sam --reason "EQ-A-0107 go-live: PASTE_VENDOR licence PASTE_CONTRACT_NUMBER, terms read PASTE_DATE_READ"
python -m econquest change approve "PASTE_THE_CHANGE_ID_HERE" --self-approved --exc "PASTE_EXC_ID_HERE"
python -m econquest change apply "PASTE_THE_CHANGE_ID_HERE" --actor Sam
```

`change approve` has no `--author`: the author is set at propose (`--author Sam`), and `--self-approved` records Sam, the author, as the approver. The approval can be four-eyes instead: someone else proposes, and Sam approves with `--approver Sam`. The
`--self-approved` route needs a named exception row in `docs/governance/issues-log.md`.

### Step 5. First live capture (when Sam is ready; on the licensed Mac)

```
python -m econquest.ingestion.market.vendors.golive capture --vendor bloomberg --data data --as-of "PASTE_LAST_BUSINESS_DAY_YYYY-MM-DD"
```

`capture` checks, in this order, and refuses with nothing requested if any check fails:
1. the entitlement;
2. the approved register row for this exact licence tag;
3. the ticker verification (step 3).

It then pulls one dated close for every verified desk instrument and gates it before anything is saved:

| Gate | Check | Effect |
|---|---|---|
| Market gate, stale | A quote more than 3 business days (CDS, bonds) before the requested close | Hold |
| Market gate, range | A value outside the plausible range | Hold |
| Market gate, jump | A move against the last value that passed (relative and absolute limits, e.g. CDS 30% and 30bp) | Hold |
| Market gate, CDS curve | A non-monotone curve | Hold the whole curve |
| Market gate, CDS curve | Inverted by more than 25bp | Flag |
| Market gate, licence and basis | The checks in `ingestion/market/gate.py` | Hold |
| Go-live, future | A quote dated after the requested close | Hold |
| Go-live, desk | An ISO that is not a desk name | Hold |
| Go-live, bond curve | An interior tenor more than 2pp off the line between its neighbours | Hold the whole curve |
| Go-live, bond curve | Inverted by more than 1.5pp | Flag |
| Go-live, seed outlier | 5y CDS more than 4x or less than 1/4 of the desk seed spread, and more than 300bp apart | Flag |
| Go-live, tenors | A CDS curve with fewer than 2 tenors (layer 2 fits a flat hazard) | Flag |

Only rows that pass are saved, as one snapshot under `data/live/market/snapshots/<stamp>-<hash8>/`. That is the
file layer 2 reads. The gated CDS rows are also appended to `data/market/cds_snapshots.csv`.

Held rows, the full review and `report.json` are written to `data/live/market/snapshots/golive/<stamp>-<vendor>/`.
The report lists holds, flags, missing values, vendor errors and CDS tenor gaps. That folder is not a snapshot: the
store reads `index.csv` only. It stays internal under the `vendor_market_snapshots` register row.

Exit codes:

| Code | Meaning |
|---|---|
| 0 | A snapshot was saved |
| 2 | Nothing passed |
| 1 | Refused |

### Step 6. Schedule the daily capture (when Sam is ready; Team C's schedule)

Print the fragment and merge it into `<home>/ops.json` under `"jobs"`:

```
python -m econquest.ingestion.market.vendors.golive schedule --vendor bloomberg --time 18:45
econquest schedule install --load
econquest schedule check
```

The job `vendor_capture_bloomberg` runs on weekdays at 18:45 New York through `econquest.ops.jobs`, with
`--as-of {as_of}` filled by the job wrapper. The Bloomberg Desktop API needs the Terminal logged in at that time.
B-PIPE does not. The test `test_schedule_fragment_merges_into_teamc_schedule` renders the plist from the fragment
with Team C's `schedule.plist_for`.

### Step 7. See what layer 2 would do, then switch it on (when Sam is ready; Team B, Tier 1)

Preview, read-only: probability.market_term is set to cds_curves in memory only.

```
python -m econquest.ingestion.market.vendors.golive layer2-preview --market data --as-of "PASTE_RUN_DATE_YYYY-MM-DD" --data data
```

Each desk name shows either `curve used` or `profile fallback: <why>`. The reasons are:
- no curve;
- a synthetic marker;
- licence not approved;
- the curve is older than 7 days;
- the curve did not fit.

Switching layer 2 to the curves (`probability.market_term.source = "cds_curves"` in `assumptions.json`) is a Team B
Tier 1 model change, with its effect table (`python -m econquest.validation.licensed_readiness`). It goes through
`econquest change` and Sam, and it is not part of this kit (EQ-B-0108).

## Evidence (fixtures, 2026-10-25)

`python -m pytest -q tests/test_vendor_golive_a107.py -p no:cacheprovider`: 14 passed.

| Fixture | Pulled | Saved | Held | Layer 2, shipped register | Layer 2, approved test register |
|---|---|---|---|---|---|
| golive_bloomberg (PHL, BRA, NGA, PAK CDS; USA, BRA, PHL govt) | 25 | 18 | 7: PAK non-monotone CDS curve, BRA 5y local-curve kink | PHL, BRA, NGA refused: synthetic marker by default; "licence not approved ... UNVERIFIED" even with allow_synthetic | PHL, BRA, NGA "curve used"; PAK "no CDS curve" |
| golive_lseg (COL, BRA, PHL CDS; USA, COL govt) | 17 | 17 | 0 (COL 10y missing on the close: 1 skipped) | refused | COL, BRA, PHL "curve used"; an approval for another lseg id refuses all three |

Also tested:
- A second-day capture with PHL 5y moving from 75 to 300bp is held by the jump check against the last passed
  capture.
- A close after the capture day is refused by the adapter.
- A fixture capture into a desk data folder (one that has `countries.csv`) is refused.
- Before Sam's baseline, capture refuses. After the baseline it still refuses while the row is UNVERIFIED. After a
  Sam-approved `econquest change` of the generated patch, it saves.

## Known gaps

- **Wire formats untested.** The fixtures are synthetic. The first licensed dry run (step 3) is the test. A folder
  recorded there (`provenance: recorded`, `replay.py` docstring) replaces them as evidence.
- **Layer 2 reads every saved snapshot, gated or not.** `cds_curves.curves_from_market` reads the store directly.
  Snapshots saved by `golive capture` hold only rows that passed. A snapshot saved by `econquest vendor pull` or a
  CSV import is gated after it is saved, so its held rows are still in the store. Use `golive capture` for any data
  meant for layer 2. Held-row filtering on Team B's side was raised with Team B (HO to B/AGENT-05).
- **Bond curves have no layer-2 consumer.** Government curves land in the store, gated, but no engine reads
  `govt_yield` from the store today.
- **One dated close per capture.** History backfill stays on `econquest vendor pull --start --end`, which saves
  before gating.
- **No CLI wrapper yet.** The kit runs as `python -m ...golive`. An `econquest vendor golive` wrapper and health
  recognition of the `vendor_capture_*` jobs are Team C's (handoff to C/AGENT-08).
