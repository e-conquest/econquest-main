# Licensed market data: vendor comparison for Sam (EQ-A-0097)

Ticket EQ-A-0097. Author: Team A, AGENT-03. Date: 2026-10-25. Status: **proposal for Sam's decision (through
AGENT-08).** Nothing here is bought, configured or enabled. Team C (AGENT-07) is asked by handoff to place or link this
page at `docs/research/vendor-comparison.md`; this copy stays in Team A's runbooks because `docs/research/` is Team C's.

Related: `docs/runbooks/A-licensed-vendors.md` (the Bloomberg/LSEG adapter framework, EQ-A-0033), section 5 of this
page (dry run on fixtures), `data/licences.csv` (register, EQ-A-0093).

## How to read this page

- Every fact about a vendor comes from a page fetched on 2026-10-25 and is cited by URL. Where a page did not say
  something, this page says **not stated**, rather than filling it in.
- **No vendor publishes a price.** All four ask buyers to contact sales. Every number in the cost column comes
  from a third-party buyer-report site and is labelled **ESTIMATE (third party)**. These are not quotes.
- No vendor publishes a per-country sovereign list on a public page. Coverage of the 88 countries and the 18 desk
  names is therefore **not verified for any vendor**. Section 2 says what can be said and what must be asked for.
- Licence statements come from public pages, not from a contract. No contract has been read. Licence-tier
  statements are marked UNVERIFIED until Sam or counsel reads the actual order form.

## 1. Summary table

| | Bloomberg | LSEG (Refinitiv) | S&P Global (IHS Markit) CDS Pricing | ICE Data Derivatives (credit) |
|---|---|---|---|---|
| What it is | Terminal (desk seat), plus enterprise feeds: Data License (bulk/per-security), B-PIPE (real time) | Workspace (desk seat) with LSEG Data Library for Python; LSEG Data Platform for enterprise | CDS-only pricing service (single names, indices, tranches, options, sector curves) | CDS single-name and index pricing, including sovereigns |
| CDS | Yes, entitlement-dependent (runbook: CBIN/CMAN/CBGN sources are often priced separately) | Yes, entitlement-dependent (LSEG CDS RICs) | Core product: ~3,800 CDS entities, 10,000+ curves, 20+ market makers, single names since 2001 [S2] | Core product: 2,250+ single-name CDS prices, sovereigns named as a covered type, 18+ years of history [I1][I2] |
| Govt bond yields / spreads | Not itemised on the Data License page ("Pricing, Reference, ... Historical data") [B2] | Not itemised in the fetched pages ("equities, bonds, commodities") [L1] | Not in this product | Not in this product (ICE bond pricing is a separate product; not assessed) |
| FX | Not itemised on the fetched page | Not itemised on the fetched page | No | No |
| Sovereign count | Not stated | Not stated | Not stated ("sovereign CDS count not given") [S2] | Not stated; "coverage can be checked after logging in" [I2] |
| Delivery | Terminal + Desktop API (localhost:8194); Data License via "DATA <GO>, REST API, SFTP, Web Services or natively in all major cloud providers" [B2]; B-PIPE | Workspace desktop session + Data Library for Python; platform session (RDP) | "SFTP flat files, API access, Excel plug-in, and the Price Viewer web portal"; EOD snap 9 PM NY, published 11 PM NY [S2] | "ICE Connect, ICE Consolidated History, ICE Consolidated Feed, ICE Data API, and ICE Data Files" [I2]; CSV/XML via SFTP, API [I1] |
| Already supported in econquest | **Yes** (adapter `bloomberg.py`, dry run passes on fixtures) | **Yes** (adapter `lseg.py`, dry run passes on fixtures) | No adapter | No adapter |
| Public price | None | None | None ("CustomerCare@ihsmarkit.com") [S2] | None ("Contact us") [I2] |
| Cost band | **ESTIMATE (third party):** Terminal about US$28k–32k per seat per year; B-PIPE/SAPI "$50,000–$200,000+/year" (no source given) [E1] | **ESTIMATE (third party):** Workspace "typical all-in" US$2,000–3,500 per user per month; under 10 users US$75k–150k per year [E2]. The same page's median (US$4,752/yr, 35 deals) does not reconcile with these. | No estimate found. **Unknown.** | No estimate found. **Unknown.** |

Source keys are in section 7.

## 2. Coverage of the 88 countries and the 18 desk names

**What is verified: nothing per country.** No fetched vendor page lists sovereign reference entities. ICE says
coverage detail sits behind a login [I2]. S&P gives entity totals, not sovereign lists [S2].

**What public data shows about the CDS market itself (not a vendor):** DTCC's top-15 sovereign reference entities
by net notional for the week ending 2026-03-27 include five desk names: **CHN, KOR, BRA, COL, JPN** [D1]. The other
desk names were not in that top 15. This shows only that those five have an actively traded CDS market. It says
nothing about the other 13 either way.

**Expectation, UNVERIFIED (to confirm from vendor coverage files):**

| Desk names | CDS | Bond yields | FX |
|---|---|---|---|
| CHN, KOR, BRA, COL, JPN | Likely on all four vendors (in DTCC top 15 [D1]) | Likely on Bloomberg and LSEG | Likely on Bloomberg and LSEG |
| PHL, MYS, IND, VNM, PAK, ARG, NGA, SGP, VEN | Unknown; ask each vendor | Unknown per name; ask | Likely on Bloomberg and LSEG; ask |
| BLZ, SEN, ZMB, ZWE | Unknown; thinly traded or no market is possible, which no vendor can fix | Unknown; ask | Unknown; ask |

Two consequences:

1. **S&P and ICE cover CDS only.** They cannot supply the yield and FX columns. If one of them is bought, Bloomberg
   or LSEG (or the existing official/public sources) is still needed for yields and FX.
2. **Ask for coverage before paying.** Each RFQ must include the 18 desk names and the 88-country list and ask for
   the vendor's coverage file: per name, CDS (tenors, doc clause, currency, whether composite or contributed and how
   many contributors), the local and USD benchmark bond yields, and the FX spot. Without this file no coverage claim
   in this page can move from UNVERIFIED.

## 3. Licence scope

The adapter framework already records two scopes per entitlement (`base.SCOPES`): **desk-internal** and
**redistribution**. Every pulled row carries `<vendor>:<licence id> (<scope>)` in its `licence` column, so the
gate can bar client output and the validator room by scope.

| Use | Bloomberg | LSEG | S&P CDS Pricing | ICE |
|---|---|---|---|---|
| Internal desk use | Terminal: yes, on that seat. A university library's summary of its Bloomberg agreement says Excel API data "is to be used only on the terminal from which it was downloaded" [B3]. | Workspace: "for the use of licensed users only"; "Detailed information on permitted usage can be found in your contract" [L1] | Per contract; not stated publicly | Per contract; not stated publicly |
| Client output (our reports to clients) | Terminal: **no**, as far as public text shows: "No data (whether raw or derived) should be disseminated from the Bloomberg terminal" [B3, an academic licence; a commercial seat's terms must be read]. Enterprise (Data License / B-PIPE) can carry redistribution or derived-data rights by contract; not stated publicly [B2]. | Workspace: "republication or redistribution of LSEG content is prohibited without LSEG's prior written consent" [L1]. Enterprise rights by contract. | "may not be reproduced or distributed without the prior written permission" [S2] | Not stated |
| NDA validator (data room) | Treat as redistribution: barred unless the contract allows it | Same | Same | Same |
| Programmatic access | Desktop API on the seat's machine; B-PIPE or Data License for servers | Data Library: about 5 requests/s per Workspace session, get_history about 3,000 rows per daily request; "not large-scale data lake extraction" [L2] | API / SFTP | API / SFTP / files |

**Plain reading:** a desk seat (Terminal or Workspace) supports desk-internal use only. Client output and the NDA
validator need a **redistribution / derived-data** licence, which is an enterprise contract on every vendor and
priced individually. Until such a contract is signed and read, the register rows in section 6 keep vendor data
barred from client output and the validator room.

## 4. Delivery and fit with econquest

- **Bloomberg and LSEG fit today.** Their adapters exist. Section 5 shows they run end to end on fixtures with no
  network. On a licensed machine, the first run is the dry run in `A-licensed-vendors.md` section 5.
- **S&P and ICE need new work.** Both deliver flat files (SFTP) or an API. The cheapest fit would be a file-drop
  importer into the existing `MARKET_COLUMNS` store, not a new session adapter. Not built. It would be a new ticket.

## 5. Dry run on fixtures (deliverable b)

The existing framework was run end to end on fixture folders, with no network and no credentials:

```bash
python -m econquest.ingestion.market.vendors.replay --fixtures tests/fixtures/vendors/bloomberg
python -m econquest.ingestion.market.vendors.replay --fixtures tests/fixtures/vendors/lseg --history
```

- The fixtures are **synthetic**: fictional countries XAA/XBB, test currency XTS, ZZFAKE identifiers, made-up
  values. They are shaped after the adapters' own reading of the vendor docs. They prove that the licence gate,
  ticker map, request building, parsing, validation and market gate run together. They do **not** prove that the wire
  format is right. That still needs a licensed machine.
- Results:
  - Bloomberg snapshot: 3 quotes, 2 vendor errors reported (a securityError and a fieldException, as fixtures).
  - Bloomberg history: 6 quotes, 1 null point skipped.
  - LSEG snapshot: 4 quotes.
  - LSEG history: 11 quotes, 1 skipped.
  - Gate: all ok.
  - Nothing saved.
- Tests: `tests/test_vendor_replay.py`, 13 tests. Network use is made to fail the test.
- **One fix found by the dry run:** `pipeline.pull_to_store` opened a vendor session before checking the ticker map,
  so an unverified ticker was refused only after a session had started. Now `adapter.plan()` runs before the
  session opens, and an unverified ticker is refused with no session and no request.

## 6. Proposed `data/licences.csv` rows (deliverable c, for AGENT-04)

This is a **proposal only**. AGENT-04 owns the register (EQ-A-0093) and decides whether to add these rows. The
rows are deliberately restrictive: `terms_verified=UNVERIFIED` because no contract has been read;
`client_output` and `validator_nda` are `barred`, which matches what the code does for the desk-internal scope.
They would change only when a signed contract's clause is read and quoted in `clause`.

```csv
source_id,name,match_source,match_licence,match_series,match_path,licence_text,url,terms_verified,commercial,internal_use,client_output,validator_nda,exc_id,attribution_text,notes,terms_url,terms_read_utc,clause
bloomberg,Bloomberg (Terminal Desktop API / B-PIPE) via vendors/bloomberg.py,^bloomberg$,^bloomberg:,,,"Bloomberg agreement held by the desk (none yet). Row licence = 'bloomberg:<licence id> (<scope>)' from the entitlement (vendors/base.py licence_tag); scope desk-internal unless the contract grants redistribution",https://professional.bloomberg.com/products/data/data-license/,UNVERIFIED,unknown,yes,barred,barred,,Source: Bloomberg Finance L.P. (wording per contract),"Roadmap paid feature, off (EQ-A-0033). No contract read. Public text (library summary of an academic agreement) says no raw or derived data may be disseminated from a Terminal. Client output / validator need a redistribution or derived-data licence (EQ-A-0097 docs/runbooks/A-vendor-comparison.md)",,,
lseg,LSEG Workspace / Data Platform via vendors/lseg.py,^lseg$,^lseg:,,,"LSEG agreement held by the desk (none yet). Row licence = 'lseg:<licence id> (<scope>)' from the entitlement (vendors/base.py licence_tag); scope desk-internal unless the contract grants redistribution",https://www.lseg.com/content/dam/data-analytics/en_us/documents/support/workspace/teams-service-description.pdf,UNVERIFIED,unknown,yes,barred,barred,,Source: LSEG Data & Analytics (wording per contract),"Roadmap paid feature, off (EQ-A-0033). No contract read. Public text: republication or redistribution prohibited without LSEG's prior written consent; permitted usage per contract. (EQ-A-0097 docs/runbooks/A-vendor-comparison.md)",,,
```

Notes for AGENT-04:

- `match_path` is left empty. Vendor rows land in the market snapshot store and are matched by `source` and
  `licence`, not by a file of their own. Check this against `licences.py` matching before adding.
- `internal_use=yes` means "allowed only while a valid entitlement is configured". The adapter refuses without one.
  The register's `internal_use` is yes/no only, so the condition lives in `notes`. Choose `no` only if vendor data
  should be kept off desk numbers even with an entitlement.
- Both rows pass `licences._validate` as written, checked by AGENT-03 on 2026-10-25 against a scratch copy of the
  register. The register file was not edited.
- No rows are proposed for S&P or ICE, because there is no adapter or file path that would produce their rows.

## 7. Sources (fetched 2026-10-25)

- [B2] Bloomberg Data License: https://professional.bloomberg.com/products/data/data-license/
- [B3] Harvard Business School library, Bloomberg access terms (academic agreement summary; indicative only for a commercial seat): https://www.library.hbs.edu/Find/Databases/Bloomberg
- [E1] **ESTIMATE (third party)** CostBench, Bloomberg Terminal pricing (says Bloomberg publishes no list price; figures from buyer reports; B-PIPE range unsourced): https://costbench.com/software/financial-data-terminals/bloomberg-terminal/
- [E2] **ESTIMATE (third party)** Vendr, Refinitiv/LSEG (ranges with no stated method; median not reconciled): https://www.vendr.com/marketplace/refinitiv
- [L1] LSEG Workspace in Teams service description: https://www.lseg.com/content/dam/data-analytics/en_us/documents/support/workspace/teams-service-description.pdf
- [L2] LSEG Data Library for Python, maximum usage guide: https://developers.lseg.com/en/article-catalog/article/the-data-library-for-python-maximum-usage-reference-guide
- [S1] S&P Global, CDS single names pricing data (overview only): https://www.spglobal.com/market-intelligence/en/solutions/products/single-name-pricing-data
- [S2] S&P Global / IHS Markit CDS Pricing brochure (dated 2019; counts may be out of date): https://cdn.ihsmarkit.com/www/pdf/0919/383074646-0819-CW-FIN-Brochure-CDSPricing-HighRes.pdf
- [S3] S&P Global Marketplace, CDS Pricing dataset (no counts or prices): https://marketplace.spglobal.com/en/datasets/cds-pricing-(251)
- [I1] ICE, credit derivatives data: https://www.ice.com/fixed-income-data-services/data-and-analytics/derivatives/credit
- [I2] ICE developer catalog, ICE Data Derivatives credit data: https://developer.ice.com/fixed-income-data-services/catalog/ice-data-derivatives-credit-data
- [D1] DTCC CDS Top 15 report, quarterly, April 2026 (week ending 2026-03-27): https://www.dtcc.com/-/media/Files/Downloads/Data-Services/dtccdata/CDS-Top-15-Report-Quarterly-Apr-2026.pdf

## 8. Recommendation and the decision Sam faces

**Recommendation (AGENT-03):**

1. Do not buy S&P or ICE now. They are CDS-only, have no adapter, and publish no price.
2. Buy **one desk-internal seat from Bloomberg or LSEG**. Both cover CDS, yields and FX in one product, and the
   econquest adapters already exist for both.
3. Decide between the two **only after each returns a coverage file** for the 18 desk names (section 2) and a
   written quote that names the CDS entitlement.
4. Defer any **redistribution / derived-data** licence until client output is actually scheduled. It is the
   enterprise tier on every vendor and the largest cost.

**Decision for Sam (through AGENT-08), Tier 1:**

- **Vendor:** Bloomberg or LSEG. Recommended: send an RFQ to both and choose on coverage of the 18 desk names and
  the quoted price.
- **Licence tier:** desk-internal seat now, or a redistribution / derived-data enterprise licence that lets vendor
  values reach client output and the NDA validator. Recommended: desk-internal now. Vendor data stays barred from
  clients and the validator until a contract clause is read.
