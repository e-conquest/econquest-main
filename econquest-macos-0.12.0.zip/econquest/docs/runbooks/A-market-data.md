# Runbook: market data (CDS, curves, EMBI, FX forwards): vendor CSV import and attested manual entry

Tickets EQ-A-0029 (schema, store, importers), EQ-A-0032 (attested manual entry), EQ-A-0031 (market gate),
EQ-A-0030 (free public sources and CIP-derived FX forwards, section 5), EQ-A-0038 (SEC-A-003 fixes: gated CDS
snapshot export, section 6).
Epic A7. Owner: Team A, AGENT-06. Date: 2026-10-23. Contract handoff to Team B: HO-20261023-A-B-010.
Code: `econquest/ingestion/market/` (`schema.py`, `store.py`, `importers.py`, `manual.py`, `gate.py`, `public.py`,
`forwards.py`, `cds_export.py`).

There is no licensed market data feed yet. Free public curves (UST, euro area, policy rates) come from FRED, the
ECB and the BIS (section 5); CDS and EMBI do not exist in any free source. Until Sam buys one (Bloomberg, LSEG or a CDS vendor; gap
assessment 2026-10-23 section 3), quotes are either typed by hand with an author and an approver
(section 2) or exported by hand from a terminal someone is licensed to use (section 3). No vendor API
is called from econquest. The tests and fixtures use only synthetic numbers.

## Where outputs land

| What | Path |
|---|---|
| Snapshots (append-only, files 0444) | `data/live/market/snapshots/<YYYY-MM-DDTHHMMSSZ>-<hash8>/quotes.csv` + `manifest.json` (rows, sha256, sources, licences, as-of range, provenance) |
| Snapshot index | `data/live/market/snapshots/index.csv` (`snapshot_id, saved_utc, sha256, rows, sources, licences, instruments, asof_min, asof_max`) |
| Hand-entered quotes (append-only) | `data/live/market/manual_quotes.csv` (market columns + `entry_id, content_sha256, author, approver, self_approved, entered_utc, note`) |
| Attestations | `data/live/review_ledger.csv`, table `market_manual`, one `apply` row per quote with its `content_sha256` |
| Ticker map (edit by hand) | `data/live/market/ticker_map.csv`, created from `econquest/ingestion/market/ticker_map_template.csv` |
| Engine input (unchanged format) | `data/cds_quotes.csv` (`country, date, tenor_y, spread_bp, recovery, source`), written from a snapshot with `to_cds_quotes` |
| CDS curve snapshots for Team B (append-only) | `data/market/cds_snapshots.csv` (`cds_curves.SNAPSHOT_COLUMNS`), written **only** by the gated export step (section 6), never by a save |

Quote format (`MARKET_COLUMNS`): `asof, instrument, iso, currency, tenor_y, field, value, unit, doc_clause,
source, vendor_ticker, licence, derived, snapshot_id, retrieved_utc`. See the docstring in `schema.py` for the
rules of each column.

## 1. Point-in-time reads

```python
from econquest.ingestion.market import latest_market, market_history, to_cds_quotes
q = latest_market("data", instrument="cds", asof="2026-10-20")   # only snapshots saved by end of 2026-10-20 UTC
cds = to_cds_quotes(q, country_names="data/countries.csv")
```

A run as of date D uses only snapshots saved on or before D, and only quotes dated on or before D. If two
snapshots hold the same key, the later one wins, and the earlier one stays on disk. If no snapshot exists the read
raises `FileNotFoundError`. It never falls back to seed spreads.

Every read checks the snapshot's integrity (EQ-A-0038). `quotes.csv` must match the manifest `sha256` and the
`sha256` of its row in the append-only `index.csv`. Its content hash, recomputed with `snapshot_id` blanked, must
equal the manifest `content_hash` and the hash8 in the folder name. Editing a quote and the manifest together still
fails with `MarketDataError`. Never edit a snapshot: save a correction instead.

## 2. Hand-typed quotes (until a licence exists)

```python
from econquest.ingestion.market.manual import enter_quotes, unattested_manual, cds_quotes_migration
rows = [{"asof": "2026-10-20", "instrument": "cds", "iso": "BRA", "currency": "USD", "tenor_y": 5,
         "field": "spread_bp", "value": <typed value>, "doc_clause": "CR14"}]
enter_quotes("data", rows, author="<who typed it>", approver="<who checked it>", note="dealer run, 2026-10-20 close")
```

- The approver must not be the author (four-eyes). In Sam's single-operator mode, pass `self_approved=True`.
  The rows then record the approver as the author and `self_approved = yes`, so the self-approval is visible
  as a governance exception.
- Each call validates the rows, appends them to `manual_quotes.csv`, writes one ledger attestation per row,
  and saves a snapshot with source `manual` and licence `n/a (hand-entered)`.
- An author, approver or note that starts with a formula character (`= + - @`, also after leading spaces), or
  that contains control characters, is refused before anything is written (EQ-A-0038).
- Entered quotes reach `data/market/cds_snapshots.csv` only through the gated export (section 6). That export checks
  the attestation again when it runs.
- To correct a quote, enter it again with the right value. The later entry wins, and the old row stays.
- `unattested_manual("data")` lists rows that were edited after entry, or whose attestation was withdrawn by a
  later `hold`/`reject` in the ledger.
- Migration: `cds_quotes_migration("data")` reads `data/cds_quotes.csv` without changing it and returns the rows
  ready for `enter_quotes`, plus a count. On 2026-10-23 the count was **0**, so there is nothing to migrate. That
  file has no currency or doc clause columns, so migrated rows assume USD with a blank clause. Check these before
  you enter the rows.

## 3. Vendor CSV export (once a licence exists)

1. Once only: run `ensure_ticker_map("data")` to create `data/live/market/ticker_map.csv` from the template.
   Every template row is `status=verify`. The template has 186 rows: CDS 1/3/5/10y for the 18 desk countries in
   Bloomberg `"<NAME> CDS USD SR <T>Y D14 Corp"` and LSEG `"<ISO2>GV<T>YUSAC=R"` form, FX spot, and UST 2/5/10y.
   The names and RICs are guesses; only the BRAZIL example shape came from Sam's brief. Check each row against a
   real export, correct `vendor_ticker`, `doc_clause`, `unit` and `scale` (for example 0.0001 for FX points quoted
   in pips), then set `status=verified`. Rows that are not verified are refused.
2. On the terminal, export history to CSV:
   - Bloomberg: either a long sheet (`Ticker, Date, PX_LAST`), a wide sheet (`Date` followed by one column per
     ticker), or BDH blocks side by side (a ticker row above `Date, PX_LAST` pairs). Dates must be US `mm/dd/yyyy`
     or ISO. A few title rows above the header are fine.
   - LSEG Workspace: a long sheet (`Instrument`/`RIC`, `Date`, `CLOSE` or `Value`) or a wide sheet (`Date` followed
     by one column per RIC). Dates must be ISO or `dd-Mon-yyyy`.
3. Import and save:
   ```python
   from econquest.ingestion.market.importers import import_and_save
   import_and_save("data", "~/Downloads/cds.csv", "bloomberg", licence="<exact licence, e.g. Bloomberg Terminal, desk seat ...>")
   ```
   The import is refused when:
   - the licence is missing or a placeholder (`none`, `pending`, ...);
   - a ticker is unmapped or its map row is not verified (the error lists them all);
   - a cell looks like a formula;
   - the file is larger than 20 MiB;
   - a date is in a format the profile does not list.
   Vendor `#N/A` cells are skipped, and the manifest records how many.
4. Gate the new snapshot against the previous one before using it (section 4).
   Then run the gated CDS snapshot export (section 6), so that Team B's `cds_snapshots.csv` gets the quotes that passed.
5. Write the engine file: `to_cds_quotes(latest_market("data", "cds"), "data/countries.csv").to_csv("data/cds_quotes.csv", index=False)`.
   This is a Team A data write, so log it under the ticket.

Licence terms: data exported from a terminal is usually licensed for the named user's own use only. Do not
publish raw vendor values to the shared workbook until Sam has confirmed that the licence allows
redistribution. That decision belongs to Sam and AGENT-09.

## 4. Market quality gate

```python
from econquest.ingestion.market.gate import market_gate, GateParams
review = market_gate(new_snapshot_frame, previous=previous_frame, asof="2026-10-20")
```

The output has the same columns as `feeds.quality_gate`: `table, key, country, seed, live, status, reason`. Status
is `hold` or `ok`. A reason that starts with `flag:` asks for a look but does not hold the cell. Checks and default
tolerances (`GateParams`):

| Check | Default | Result |
|---|---|---|
| stale | 3 business days (FX spot 2, policy rate 45) | hold |
| range | CDS 0..50,000bp; yields -2..300%; FX > 0 | hold |
| curve non-monotone | adjacent CDS tenors move both up and down by more than 5bp | hold, all tenors |
| curve inverted | short end above long end by more than 25bp | flag only |
| arbitrage (CIP) | forward against spot x ((1+r_ccy)/(1+r_usd))^T, more than 2% of spot apart, with OIS (else swap) rates at the forward tenor | hold |
| jump vs previous | CDS 30% and 30bp; yields 20% and 0.5pp; FX 5% | hold |
| bond-CDS basis | 5y CDS against EMBI spread, or against USD 5y bond minus UST, more than max(150bp, 50% of CDS) apart | hold, both rows |

Hold decisions go through the review ledger as for the macro feeds (`record_decision`, four-eyes).

## 5. Free public sources (EQ-A-0030)

Code: `econquest/ingestion/market/public.py` (pulls) and `forwards.py` (derived FX forwards). The live pulls
run on Sam's Mac only. This cloud cannot reach these hosts. The tests use mocked fetchers and the SYNTHETIC
fixtures in `tests/fixtures/market/public/`. Every request goes through `events.base.http_fetch`, which allows
https only, refuses redirects, caps responses at 50 MiB and retries 429, 5xx and timeouts up to 3 times with
backoff. Error messages give only the host and path. Query strings and the API key are redacted.

| Source | Endpoint | Series | Market rows | Licence string (unverified) |
|---|---|---|---|---|
| `fred` | `https://api.stlouisfed.org/fred/series/observations` | `DGS1MO DGS3MO DGS6MO DGS1 DGS2 DGS3 DGS5 DGS7 DGS10 DGS20 DGS30` | `govt_yield`, iso `USA`, `USD`, `yield_pct` | public domain (US Treasury yields via Fed H.15); cite FRED, St. Louis Fed; FRED terms apply. Check against <https://fred.stlouisfed.org/legal/> |
| `alfred` | same endpoint with `realtime_start`/`realtime_end` | same | same, `vendor_ticker` = `<series>@<vintage start>` | same |
| `ecb_yc_aaa` / `ecb_yc_all` | `https://data-api.ecb.europa.eu/service/data/YC/<key>?format=csvdata&detail=dataonly` | `YC.B.U2.EUR.4F.G_N_A.SV_C_YM.SR_<m>` (AAA) and `YC.B.U2.EUR.4F.G_N_C.SV_C_YM.SR_<m>` (all issuers). Default m: 3M 6M 1Y 2Y 3Y 5Y 7Y 10Y 15Y 20Y 30Y | `govt_yield`, iso `EMU`, `EUR`, `yield_pct` | ECB statistics may be reused free of charge if the ECB Data Portal is acknowledged. Check against <https://www.ecb.europa.eu/stats/ecb_statistics/governance_and_quality_framework/html/usage_policy.en.html> |
| `bis` | none: reads `data/live/raw_bis.csv` written by `feeds.BisFeed` (WS_CBPOL) | `POLICY_RATE` | `policy_rate`, iso = country, currency from `countries.csv` | BIS statistics may be reused freely with attribution. Check against <https://www.bis.org/terms_conditions.htm> |

How each source is coded:
- **FRED.** Values are Treasury par yields in percent, on a bond-equivalent (semiannual) basis. FRED marks a
  missing value with `.` (holidays). Those rows are skipped and counted in the manifest's
  `provenance.missing_dot_values`, and never filled.
- **ECB YC key.** The parts of the key are: `B` business-daily, `U2` euro area (changing composition), `EUR`, `4F`
  ECB, `G_N_A` AAA-rated central government bonds or `G_N_C` all central government bonds, `SV_C_YM` Svensson
  model with continuous compounding, `SR_<m>` zero-coupon spot rate. Requests are batched with `+` and split
  into one request per calendar year.
- **Euro area ISO code.** The schema needs an ISO3-shaped code on `govt_yield`. The euro area is not an ISO 3166
  country, so its curves use `EMU`, the World Bank aggregate code. Team B should accept this convention
  (follow-up).

Mac commands (from the repo root):

```
export FRED_API_KEY=...            # from the keychain or shell profile, never a file in the repo
python -m econquest.ingestion.market.public --source fred --start 2026-01-01 --end 2026-10-23 --data-dir data
python -m econquest.ingestion.market.public --source ecb  --start 2026-01-01 --end 2026-10-23 --data-dir data
python -m econquest.ingestion.market.public --source bis  --start 2026-01-01 --end 2026-10-23 --data-dir data
python -m econquest.ingestion.market.forwards --data-dir data --asof 2026-10-22 --spot bis
```

- `--dry-run` fetches the data, validates it and runs the gate, then saves nothing. Run it first the first time.
- `--series DGS3MO,DGS10` limits FRED to those series. `--curves G_N_A` limits the ECB pull to the AAA curve.
- Each run saves one snapshot, prints how many gate holds there are, and exits 2 with a message when it is
  refused.

**ALFRED (as-of replay).** Add `--asof D` to the `fred` command. The values come from the vintage that was valid
on D: the one with `realtime_start <= D <= realtime_end`. Observation dates are capped at D. If a vintage holds
`.`, the date stays missing; an older vintage is never used instead. The snapshot store is point-in-time by
*save* time, and a replay is saved today. So save replays to a separate data dir, for example
`--data-dir data/replay/alfred-2025-06-30`, and never to `data/`. Otherwise the replay rows would override
current values in `latest_market`. ALFRED may not keep separate vintages for every daily DGS series; this is
unverified until the first Mac pull.

**Derived FX forwards (`forwards.py`).** These are computed with covered interest parity:
`F = S * exp((z_ccy - z_usd) * T)`.
- **Spot S.** Units are CCY per USD. Since EQ-A-0040 it comes from the official FX pull: `--spot bis`
  (default, `data/live/raw_bis_xru.csv`) or `--spot ecb` (`data/live/raw_ecb_exr.csv`, converted through the same
  date's EUR/USD), else from a snapshot (`--spot snapshot`). `--spot yahoo` is refused unless
  `ECONQUEST_ALLOW_YAHOO=1` is set (research only, never a publish: the market gate holds any row whose licence
  says non-commercial or personal). With a live spot source the spot rows are saved in the same snapshot, so the gate's CIP check
  can see them.
- **Tenors.** 1M, 3M, 6M and 12M. The year fraction T is 1/12, 0.25, 0.5 and 1 (an ACT/365F approximation).
  The T+2 spot lag, holiday calendars and ACT/360 money-market day counts are ignored, so the forward is an
  indication, not a dealable price.
- **Choosing rates.** Both rates must be quoted on the same date as the spot, at exactly the forward tenor.
  The order of preference is OIS, then swap, then the benchmark government curve (USD from `USA`/FRED, EUR
  from `EMU`, AAA before all-issuers). There is no interpolation. Policy rates are not used.
- **Converting to continuous zero rates.** FRED rates are semiannual: z = 2 ln(1 + r/2). ECB rates are already
  continuous. BIS rates are simple: z = ln(1 + rT)/T. Annual is z = ln(1 + r), the same convention as the
  gate's check. A source with no known convention is refused unless the caller passes it.
- **Refusals.** If either rate is missing, that forward is refused and listed with the reason. For example,
  there is no EUR 1M forward, because the default ECB pull has no 1M maturity. The rest are still saved.
- **Rows written.** `fx_forward` outright and points, `derived=true`, source `derived_cip`. The schema needs a
  slug for the source, so the label "derived (CIP)" goes in `vendor_ticker` and the licence. `vendor_ticker`
  names the spot source and both rate series. The manifest provenance holds the formula, the convention for
  each source, and every input (source, snapshot, ticker, value, licence).
- **Licence of a derived row (EQ-A-0038).** Input restrictions carry over to the derived row. If every distinct
  input licence fits in 128 characters, the row's licence lists them verbatim:
  `derived (CIP) from <s>+<c>+<u>; inputs: <licence> | ...`. If they do not fit, the row's licence lists every
  restrictive term found in the inputs, as it is written there, for example
  `derived (CIP) from yahoo+ecb_yc_aaa+fred; input restrictions: non-commercial, personal, unverified; input licences apply`.
  The terms are in `forwards.RESTRICTIVE_MARKERS`. A forward whose restrictions do not fit is refused. Sam still
  has to decide whether Yahoo spot may be used on a desk at all (SEC-A-003 L3). Sam decided on 2026-10-23
  (EQ-A-0040): it may not. The official spot sources carry the BIS / ECB licences instead, and a row that still
  carries a non-commercial or personal restriction is held by the market gate.
- **What the gate checks.** Forwards built from government curves pass through the gate's CIP check without
  being tested, because the gate checks only against OIS or swap rates.

Free policy-rate and curve sources not wired yet: each has a documented API, and none is to be scraped.
- ECB €STR: <https://data.ecb.europa.eu/data/datasets/EST>
- Bank of England database: <https://www.bankofengland.co.uk/boeapps/database/>
- Bank of Canada Valet: <https://www.bankofcanada.ca/valet/docs>
- BCB SGS: <https://dadosabertos.bcb.gov.br/>
- Banxico SIE (free token): <https://www.banxico.org.mx/SieAPIRest/>
- SNB data portal: <https://data.snb.ch/en>
- RBA tables: <https://www.rba.gov.au/statistics/tables/>
- FRED SOFR, EFFR and DFEDTARU/DFEDTARL: same client as `fred`, not mapped yet.

Most central-bank policy rates are already covered by BIS WS_CBPOL through `feeds.py`.

## 6. CDS curve snapshots for Team B: the gated export (EQ-A-0038, SEC-A-003 M1)

Saving a snapshot (vendor import, manual entry, public pull, CIP forwards, or a direct `save_market_snapshot`) no
longer writes `data/market/cds_snapshots.csv`. Before EQ-A-0038 every saved CDS quote was appended there at save
time, including quotes the gate would hold and manual quotes whose attestation was missing or withdrawn. The file
is now written only by one explicit step:

```bash
python -m econquest.ingestion.market.cds_export --data data --dry-run      # report only, writes nothing
python -m econquest.ingestion.market.cds_export --data data                # append what passed
python -m econquest.ingestion.market.cds_export --data data --snapshot 2026-10-22T180000Z-abdda7f3
```

```python
from econquest.ingestion.market.store import export_cds_snapshots     # = cds_export.export_gated_cds_snapshots
rep = export_cds_snapshots("data")            # CdsExportReport: appended, kept, dropped (one row per dropped quote)
print(rep.summary()); print(rep.dropped)
```

Run it after each save, once the gate review (section 4) is done. Rerunning is safe: rows already in the file are
skipped. Without `--snapshot` it walks every stored snapshot, so it doubles as the backfill. A backfill applies the
same checks, so it cannot re-import a held or unattested quote.

What the step does with each stored snapshot S, in save order:
1. **Market gate.** `gate.market_gate` runs for each quote date `a` of S's CDS rows, the same way
   `econquest market cds-quotes` does (`cli._market_gate`), with one difference (SEC-A-003 L5). The previous view
   holds only the rows that passed the gate and the attestation check: the passed rows of the snapshots saved
   before S, plus S's own earlier dates that passed. The current view is that plus S's rows dated `a`. The gate
   runs as of `a`. A held value is therefore never the seed of a later jump check. Saving 150, then 45000 (held),
   then 45000 again holds both 45000s. A CDS row in a held series is dropped, matched on (series key, iso) as in
   the CLI. The result depends only on snapshots saved up to S, so rerunning later gives the same answer
   (`cds_export.gated_history`).
2. **Attestation.** A `source=manual` row is kept only if its recomputed content hash is in
   `ledger.attested_content(data, "market_manual")` for its cell. A row is dropped when it was never attested (for
   example, saved with `save_market_snapshot` instead of `enter_quotes`), when it was changed after attestation, or
   when a later ledger `hold`/`reject` withdrew the attestation.
3. What passes goes through `schema.to_cds_snapshots` and is appended under a lock. Existing rows are never
   rewritten.

The report lists every dropped row with `check` (`gate` or `attestation`) and the reason. Read it before you tell
Team B the file is current.

Limits:
- **The file is append-only.** A row exported before a later reject stays in the file. The report marks it
  `already_in_file=True` and the summary prints a WARNING. Supersede it with a corrected capture: enter or import
  the right value. That creates a later snapshot, and `cds_curves.snapshot_as_of` prefers it.
- **A real move the gate holds is not exported for that snapshot.** An example is a 30%+ jump in a crisis. There is
  no override yet: the ledger decisions are not read for `market` gate holds. The next capture is gated against the
  held value, so it passes if the level is confirmed. If you need the held capture itself, ask AGENT-06.
- **The CLI gate still seeds from held values.** `econquest market gate` / `cds-quotes` (`cli._market_gate`, Team C)
  seed from every earlier snapshot. The fixed helper is `cds_export.market_gate_review(data, as_of)`; the handoff to
  C/AGENT-01 asks them to switch to it.
- **No `econquest market cds-snapshots` command yet.** `cli.py` belongs to Team C, so for now use the module CLI
  above.
