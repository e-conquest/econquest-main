# Team A: when Sam is ready

Sam's rule for PI-10 (2026-10-25 16:36Z): no Mac steps, reviews, uploads, commands or decisions from Sam until the MVP
(`team/mvp-checklist.md`) is reached. Team A builds and tests on shared data only. Everything that needs Sam is listed
here and in the program lead's `team/when-sam-is-ready.md`. Nothing here blocks a PI-10 ticket.

## When Sam is ready

1. **1.8 CRAG count, Tier 1 sign-off (EQ-A-0083).** Team B set the rule in indicator-rules.md section 16. The first
   values are held in the MVP dataset as `Tier 1: Sam sign-off (parked)`, and the seed stays. Two desk values change:
   Argentina 3 -> 1 and Zimbabwe 1 -> 2. Belize 4, Venezuela 1 and Zambia 1 are unchanged, and the other 10 served
   names are 0 = 0. JPN, KOR and SGP are not served. Sam decides on Team B's effect table in the parked decision pack.
   After sign-off, Team A wires 1.8 through the gate apply.
2. **Held cells in the 13:03Z full fetch (EQ-A-0110).** 90 review cells are held by the gate (change, range, stale,
   cross and unverified checks; reasons in `data/mvp/gate_report.json`). They stay on their current value until Sam
   reviews them on the Mac (`econquest review list --pending`). 211 cells are missing (no feed value).
3. **Legacy review decisions.** 82 rows of Sam's review.csv carry decisions imported from the hand-edited file
   (author "unknown"). They released nothing (EQ-A-0101). `ledger legacy-reset --author Sam --self-approved`
   replaces them with named holds when Sam wants a clean ledger.
4. **Refresh the MVP dataset after the first Mac pass.** Upload the new full-fetch review.csv; Team A rebuilds
   `data/mvp/` (`docs/runbooks/A-mvp-dataset.md`, "Rebuild when").
5. **Five official fx3m cells held by the gate (EQ-A-0112, HO-20261025-C-A-006).** The 17 applied Yahoo fx3m cells
   were replaced offline in derived vintage `2026-10-25T170547Z-67dffc57`: 12 applied at the official value, and 5 held
   by the gate's change check, so they went back to the labelled seed of the 2026-10-23 vintage. The 5 are Malaysia
   (seed -1, official -0.1525), Pakistan (0.5, -0.3153), Belize (0, 0 by the USD peg, so no change), Colombia
   (-1, -1.582) and Senegal (0, 1.644 by the EUR peg). Sam already applied these same official values in
   `team/inbox/pull-20261025-fullfetch/review.csv` (12:52Z, self-approved). When Sam is ready, he records the release
   on the Mac (`econquest review list --pending`, then approve) and Team A applies the vintage again. The gate is not
   loosened.

6. BIS consolidated banking statistics (CBS) exposures: no pull has saved `data/live/raw_bis_cbs.csv`, so Team B's
   stress scenario EMDEF_BRA is labelled "not run: no BIS CBS exposures" in the MVP. On the first Mac pass, the BIS
   feed's CBS step should save it (Team A to confirm the step name before the pass).

7. Licensed data go-live (EQ-A-0107; full steps in docs/runbooks/A-licensed-go-live.md). Sam's choices and steps:
   pick the vendor and licence tier (recommended: one desk-internal seat, Bloomberg or LSEG, chosen on a coverage file
   for the 18 names and a quote naming the CDS entitlement; Tier 1); on the licensed Mac configure the entitlement and
   run `econquest vendor status` and `econquest vendor check`; verify the ticker map on the terminal; after the first
   licence register baseline, approve the `golive register-patch` through `econquest change` (Sam only); first
   `golive capture`; add the schedule fragment; then Team B's Tier 1 switch of layer 2 to CDS curves.
8. **D3: are IMF-compiled World Bank WDI series client-safe? (EQ-A-0106, EQ-A-0117).** This is one switch: the
   `imf_via_wdi` row of `data/licences.csv`. Until Sam answers, the row is undecided and changes nothing: client
   output is the same as before the row existed, and the route's IMF-compiled values are not used. Each answer is
   one `econquest change`, made after the licence register baseline (first-mac-pass step 5). Either way, licence_gov
   treats the change as Tier 1, so only Sam approves it. The full report is in docs/runbooks/A-client-safe-sources.md,
   section "D3 switch".
   - **Yes:** 38 more cells get a non-IMF value (2.8 x16, 5.5 x15, 5.13 x7), and the 46 cells allowed today stay
     allowed. The counts use Sam's recorded WB pull of 2026-10-25 and the as-of date 2026-10-23.
   - **No:** 46 cells that are allowed today are withheld from client output. They are the Country Profile reserves
     (18), 1.2 (13) and 5.10 (15). Internal values do not change. Warning: reserves is a required field, so the
     client build stops with "universe not ready" for all 18 names until Team B gives reserves a non-IMF fallback. Do
     not apply "no" before that.
   - The commands are below. The first line writes the patch for the answer, here "yes"; for "no", put `no` in place
     of `yes`.

     ```
     cd ~/econquest
     python -m econquest.ingestion.official.client_safe_route --d3-patch yes > d3-patch.json
     python -m econquest change propose licences.csv --patch-file d3-patch.json --author Sam --reason "D3 answer from Sam"
     python -m econquest change approve "PASTE_THE_CHANGE_ID_HERE" --self-approved --exc "PASTE_EXC_ID_HERE"
     python -m econquest change apply "PASTE_THE_CHANGE_ID_HERE" --actor Sam
     ```

   - On the first Mac pass, also run the probe list in docs/runbooks/A-client-safe-sources.md.
9. EQ-A-0108 coverage: drop the UCDP GED and Candidate CSVs into data/panel/research/ucdp_ged/ and run the QEDS probe
   (docs/runbooks/A-coverage-60.md section 11.6); confirm UCDP CC BY 4.0 for the desk; rule on QEDS for clients.
10. EQ-A-0118 coverage part 6 (docs/runbooks/A-coverage-60.md section 12.6): the QEDS probe now also looks for the
    remaining-maturity series (2.2); drop the COW Direct Contiguity v3.2 `contdird.csv`, `states2016.csv` and an
    operator-made `unions.csv` into data/panel/research/cow/, then run
    `python -m econquest.ingestion.research.cow_contiguity build --data data` and send the summary line; confirm COW
    terms for the desk. After the pass, the upload is measured with `python -m econquest.ingestion.coverage_live
    measure` (the landing kit calls it).

11. **Review ledger hash chain (EQ-A-0103).** From 0.6.0, every new row of `data/live/review_ledger.csv` is chained.
   Sam's 0.5.0 ledger keeps its 87 rows, and they are reported as unchained, not as tampered. The first new decision
   writes one "chain starts here" row. To check it on the Mac (no change is made):

   ```
   cd ~/econquest
   python -m econquest.ingestion.ledger verify --data data
   ```

   The last line should read `RESULT: ok`. If a fetch stops with "the review ledger ... is missing but N vintage(s)
   exist", restore `data/live/review_ledger.csv` from a backup. Do not reimport. The `import-legacy --first-install`
   override is only for a genuine first install. Keyed seals (D4) are still Sam's decision.

12. **Terms of four nowcast sources and COW Direct Contiguity (EQ-A-0119).** Banco Central do Brasil (SGS), BCRP (BCRPData), datos.gob.ar
   (INDEC series) and OpenDOSM (data.gov.my) are in `data/licences.csv` as `nowcast_bcb_sgs`, `nowcast_bcrp`,
   `nowcast_datos_ar` and `nowcast_dosm`. Each is UNVERIFIED, internal only, client restricted and validator
   UNVERIFIED. Sam reads each publisher's terms and decides whether the rows may be loosened. Loosening a row is
   Sam's decision. Their nowcast map rows go in on the Mac with
   `python -m econquest.ingestion.nowcast_feed plan --add-defaults`, and then follow runbook A-nowcast-feed steps 2 to 5.
   The same applies to the Correlates of War Direct Contiguity terms (row `cow_contiguity`, HO-20261026-A-A-001). That
   row covers `data/panel/neighbours.csv` and `data/panel/research/cow/` for 6.12, and it is UNVERIFIED, internal only
   and client restricted. COW asks for citation. Sam reads the terms at https://correlatesofwar.org before any
   loosening.
13. **Stale World Bank and BIS cells that the gate released (EQ-A-0119 freshness check, 2026-10-25).** In
   `data/live/review.csv`, 10 cells carry a gate reason `stale: latest period ...` but status ok: 6.2 for VNM, CHN,
   IND, BLZ, VEN, SEN, ZMB and ZWE, and 5.10 for SGP and JPN. The freshness SLA reports them as breaches every day,
   as it does Argentina 5.13 / policy (BIS policy rate last 2025-07-10). The data_ops job therefore exits 2 daily. Sam
   either confirms them on the Mac (`econquest review list`) or asks for a newer source. The SLA is not loosened.
14. **Research cells at the first gate review (EQ-A-0089).** When research files are in `data/panel/research/KEY/`
   (drop list in docs/runbooks/A-research-datasets.md), pull pack step 7 and `econquest fetch` read them. Every research
   cell is held. Four ids need Sam's sign-off on Team B's batch effect before any apply (indicator-rules 13): 3.6 (no
   legislature: legislative part 0), 4.4 (annual-count fallback for the coup month), 6.10 (EPR level without the
   ACD2EPR conflict test) and 7.12 (Aqueduct category -1 as level 4). They are parked, not applied, and Team A does not
   ask before the first gate review. `data/live/pullpack/research/research_cells.csv` lists each held cell with its
   value, the desk value it would replace, and whether the licence register lets it reach client output.
15. **Validator data room label (EQ-A-0125).** The 0.8.0 validator room on shared data is labelled DEMO ("DEMO
   baseline: not Sam's approval"): its withholding and labels come from the 62-row `data/licences.csv` (sha256
   `395fedf3...`), which Sam has not approved. After Sam approves the first licence register baseline
   (first-mac-pass step 5), Team A rebuilds the room without the label (`python -m econquest.ingestion.dataroom build
   --as-of DATE --mvp`; `--demo-baseline` is refused once a real baseline exists). Before any room goes to a
   validator, Sam confirms that each licence lets that data go to the validator (runbook A-data-room.md, "Hand it
   over"). The IMF material stays in the room under NDA only (EQ-A-0059). Nothing here blocks a PI-12 ticket.
16. **Sanctions lists, first live pull and terms (EQ-A-0133).** The adapters for OFAC SDN and non-SDN, the EU FSF, UK
   OFSI and the UN SC are built and tested on SYNTHETIC fixtures only. No real list is on disk. On the Mac, from
   `~/econquest` (steps and checks in docs/runbooks/A-sanctions.md):

   ```
   python -m econquest.ingestion.sanctions fetch ofac_sdn --data data
   python -m econquest.ingestion.sanctions fetch ofac_cons --data data
   python -m econquest.ingestion.sanctions fetch un_sc --data data
   python -m econquest.ingestion.sanctions fetch uk_ofsi --data data
   python -m econquest.ingestion.sanctions ingest eu_fsf --data data
   ```

   - The EU file is downloaded by hand from the FSF page into `data/sanctions/drop/eu_fsf/` before the last line.
   - First check that OFSI still publishes ConList.csv. OFSI announced a move to the FCDO UK Sanctions List, which
     would need a new parser.
   - Sam, or AGENT-04 with the terms page open, reads each list's terms and records them in the four rows
     ofac_sanctions, eu_sanctions, uk_ofsi_sanctions and un_sanctions of `data/licences.csv`. Today they are
     UNVERIFIED, tighten-only and client-restricted. Loosening any of them is Sam's decision.
   - Snapshots hold personal names, so `data/sanctions/` never goes into data/mvp, the data hash or the validator
     room unless Sam decides otherwise.
   - Exposure counts stay held until Team B's level rule exists (HO-20261026-A-B-009).
17. **Macro inputs, first live pull (EQ-A-0134).** Download the World Bank Pink Sheet `CMO-Historical-Data-Monthly.xlsx`
   (https://www.worldbank.org/en/research/commodity-markets) to `~/Downloads`, then run
   `python -m econquest.ingestion.pullpack run --steps macro`. This pulls BIS WS_EER (REER and NEER, broad and narrow)
   and builds the export-share terms-of-trade index. Nothing is applied. Send `live/macro/vintages/<id>/manifest.json`
   and `checks.csv` to AGENT-08. Before any client use, Sam reads the Pink Sheet terms (row `worldbank_cmo`) and the
   UN Comtrade upstream of WDI TX.VAL (row `macro_tot_derived`). Steps are in docs/runbooks/A-macro-inputs.md.
18. **Text corpus, first live pull and terms (EQ-A-0131).** The adapters for 18 central banks (one per desk name;
   BCEAO for Senegal) and IMF press releases and country pages are built and tested on SYNTHETIC fixtures only. Their
   index URLs and page layouts are UNVERIFIED, and `data/corpus/` does not exist yet. On the Mac: first
   `python -m econquest.ingestion.text pull --dry-run`, then send the output to AGENT-08. After Team A has fixed the
   layouts, run the pull in docs/runbooks/A-text-corpus.md section 4 and upload `data/corpus/`. Before any client use,
   Sam reads each publisher's terms (rows `text_cb_<iso3>`, `text_imf` and `text_corpus_store`: internal only, client
   restricted, validator room UNVERIFIED). VNM, BLZ and VEN have no known feed and stay parked. Nothing here blocks a
   PI-13 ticket: until the pull, the corpus interface returns empty results.
19. **Event calendar, first live drops and terms (EQ-A-0132).** The adapters are built and tested on SYNTHETIC
   fixtures only, and their layouts are UNVERIFIED. They cover ElectionGuide elections, IMF MONA reviews and the
   agency EU sovereign rating calendars. Eurobond terms from prospectuses go through hand entry. `data/calendar/events.csv`
   today holds only the 78 aggregate external PPG debt-service events: 13 desk names, 2027-2032, built from the
   recorded IDS pull `team/inbox/pull-20261025T013150Z/raw_worldbank.csv`. On the Mac, save one file per source in
   `data/calendar/drop/<source>/`, then run `python -m econquest.ingestion.calendar drop electionguide`, then
   `drop imf_mona`, then `drop rating_calendar`. Send the JSON output to AGENT-08; a refused layout writes nothing.
   Before any client use, Sam reads each publisher's terms. The rows are `calendar_electionguide`,
   `calendar_national_electoral`, `calendar_imf_programmes`, `calendar_prospectus`, `calendar_rating_agencies` and
   `calendar_store`, all UNVERIFIED and client-restricted. Steps are in docs/runbooks/A-calendar.md. Nothing here
   blocks a PI-13 ticket.
20. **Two draft exception rows from the PI-14 security sweep (EQ-A-0141, SEC-A-016). Not approved, and not in
    `docs/governance/issues-log.md`.** AGENT-09 drafted them, and Sam decides each one. On a yes, AGENT-08 sends the
    row to Team B (owner of issues-log.md), which gives it the next free EXC id. EXC-006 is already proposed for the
    analyst overlay (team/when-sam-is-ready.md). On a no, the item stays an open Low in SEC-A-016, and the fix named
    under "If no" is scheduled. Today neither draft changes any number, gate or output.

    | Draft | Restriction or control | What would be accepted | Compensating control | If no | Expires |
    |---|---|---|---|---|---|
    | EXC-draft-A16-1 | The four-eyes rule and audit integrity of the shared ledgers: `data/live/review_ledger.csv`, the calendar `content_sha256`, and the landing report chain | Until D4 (keyed seals) is decided, the ledgers are hash-chained but not keyed, and author and approver names are self-asserted. Someone who can write `data/live` can rewrite a whole chain with recomputed hashes, or cut rows off the end. Covers SEC-A-001 L2 residual, SEC-A-011 L5, SEC-A-012 I1, SEC-A-013 I3 and SEC-A-015 C-I2 | Chain verified before every append and every apply (`LedgerBrokenError`); `ledger verify`; append-only writers; refusal of a missing ledger once named decisions exist; pre-apply snapshots; EXC-001 `self_approved` flag on every self-approval | Sam answers D4, then Team A adds a keyed seal over `chain_head()` | On the D4 decision, or 2027-01-22, whichever is first |
    | EXC-draft-A16-2 | Licence terms of research datasets (SEC-A-010 I4) | Datasets whose terms are unread or non-commercial are tagged "internal research use only". They may feed desk numbers after a gate review (wjp, coups, goci, ndgain, epr, unhcr; gti and undrr stay barred). Yahoo "personal non-commercial" data stays barred from desk numbers | Every research cell is held at the gate; 3.6, 4.4, 6.10 and 7.12 need Sam's sign-off; client output is restricted; the validator room withholds them while `validator_nda` is UNVERIFIED | Team A treats these rows like Yahoo: barred from desk numbers until Sam reads each publisher's terms | When Sam reads each dataset's terms, or 2027-01-22, whichever is first |
21. **Authoritative FIPS 10-4 list for GDELT (EQ-A-0139, Mac pull step).** GDELT codes countries in FIPS 10-4. The
    reference table (`econquest/ingestion/events/fips_reference.py`, docs/runbooks/A-event-taxonomy.md section 2)
    resolves only the 18 desk codes, copied from `gdelt.FIPS_TO_ISO3`. The other 70 universe countries stay unresolved
    until an authoritative list is recorded; nothing is inferred from ISO2 codes. This needs no UCDP token. That item
    is already parked in team/when-sam-is-ready.md ("UCDP token") and is not repeated here.
    - **Document to fetch:** GDELT's own FIPS country-code lookup, the one the GDELT 2.0 Event Codebook points to for
      `ActionGeo_CountryCode`. It is preferred because it is the list GDELT codes against. Fallback: the final FIPS
      PUB 10-4 country-code list and its change notices (NIST; maintenance later passed to NGA). **Exact URL TBC.**
      Read it from the codebook on the Mac; do not take it from this runbook.
    - **Source to record:** publisher, document title, exact URL, retrieval UTC time, sha256 of the saved file, and
      the terms text/URL. These go into `fips_reference.SOURCE["authoritative_list"]` and section 2 of the taxonomy runbook.
    - **Licence row it needs:** a tighten-only row in `data/licences.csv` (AGENT-04 owns it), e.g. `source_id`
      `gdelt_fips_lookup` (or `fips_10_4` for the fallback), with terms_verified UNVERIFIED and client_output
      restricted until Sam reads the terms. Add it before the file is stored.
    - **Folder:** the save folder below is new. AGENT-08 assigns its ownership row before this step runs. Do not
      save to `data/live/events/gdelt/fips_reference.csv`: mapping_qa reads that path as a complete list.

    ```
    cd ~/econquest
    mkdir -p data/live/events/gdelt/fips_source
    # save the downloaded file into data/live/events/gdelt/fips_source/ (keep the publisher's file name)
    shasum -a 256 data/live/events/gdelt/fips_source/"PASTE_THE_FILE_NAME_HERE"
    date -u +"%Y-%m-%dT%H:%M:%SZ"
    python -m econquest change propose licences.csv --patch-file fips-licence-patch.json --author Sam --reason "FIPS 10-4 source for GDELT (EQ-A-0139)"
    ```

    Send the sha256, the UTC time, the exact URL and the change id to AGENT-08. AGENT-04 prepares
    `fips-licence-patch.json` beforehand. Team A then builds the full table from the recorded file, under a new ticket.
    The table must be complete before it is written to the path mapping_qa reads.
22. **Should reserve-ratio WDI codes (e.g. DT.DOD.DSTC.IR.ZS) count as IMF-derived for client output?** (EQ-A-0144, SEC-A-017 Q-1.) Affected today: Inputs 2.9 for 8 countries, released live by the client-safe dataset under both D3 answers. Until Sam answers, the assistant scope alone treats them as internal (context/scope.py RESERVE_RATIO_CODES); client_safe_route.D3_CODES is unchanged.
23. **Assistant model: pick a model; someone reads its licence file and flips terms_verified** (EQ-A-0148, HO-20261027-C-A-001). Rows model_qwen2_5, model_qwen2_5_other, model_mistral_7b, model_llama_3 and model_gpt_oss are UNVERIFIED with commercial unknown, so the assistant licence gate refuses every model until then (through `econquest change`, with terms_url and terms_read_utc).
