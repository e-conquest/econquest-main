# Runbook: validator data room (data side)

Ticket EQ-A-0041 (PI-5 independent validation). Owner: Team A, AGENT-06. Operator: Sam on the Mac, or an agent
working on the project copy. Code: `econquest/ingestion/dataroom.py` and the standalone verifier
`econquest/ingestion/dataroom_verify.py`. Tests: `tests/test_dataroom.py`.

## Purpose

Give an external validator one folder per as-of date with every data record econquest held at that date, so they
can reproduce and verify each data input without econquest installed: vintages, snapshots, provenance, audit trail,
review ledger and attestations, change approvals, event feed exports and frozen replay inputs. Each file has a
sha256 in `MANIFEST.json`, a top hash covers the manifest, and `verify.py` (standard library only) checks it all.

The Team C evidence bundle (`econquest evidence --as-of`, EQ-C-0060) includes this room's `MANIFEST.json`; see
handoff HO-20261024-A-C-001 for the contract.

## Build

```bash
cd ~/econquest
python -m econquest.ingestion.dataroom build --as-of 2026-10-23        # -> outputs/dataroom/2026-10-23/
python -m econquest.ingestion.dataroom verify outputs/dataroom/2026-10-23
```

- Default location: `<outputs>/dataroom/<as_of>/`, where `econquest evidence --as-of` (EQ-C-0060) picks it up.
  `<outputs>` is `$ECONQUEST_HOME/outputs`, else the checkout's `outputs/` (as the rest of econquest); `--outputs DIR`
  or `--out DIR` override it. `--data` defaults to `<home>/data`. The manifest is always `MANIFEST.json` at the root.

- `--as-of YYYY-MM-DD` means the end of that UTC day; an ISO date-time (`2026-10-23T18:20:00Z`) cuts at that instant.
- `--out` must not exist or must be empty, and must not be inside `data/`. The room is built in a temporary sibling
  folder and renamed into place, so a failed build leaves nothing behind. Files in the room are read-only (0444).
- Nothing in `data/` is written or touched.
- `--json` prints a summary (files, bytes, manifest_sha256, counts per kind, excluded, anchor results).
- `--include-current` also copies undated working copies (indicators.csv, countries.csv, market_history, panel CSVs,
  hand-entered CSVs, other teams' config). It is refused when any dated record in `data/` is after the cutoff, since
  the working copies may then already hold later data. Use it only for an as-of date at or after the latest record.

Python: `build_data_room(data_dir, as_of, out_dir, *, include_current=False, now=None, include_restricted=False,
limitations=True) -> dict` (the manifest),
`default_room_dir(as_of, outputs_dir=None) -> Path` and
`verify_data_room(path) -> dict` (the report; `ok` is the verdict).

## What goes in, and the as-of rule for each

The cutoff is inclusive. A legacy date-only id (the `2026-10-23/` vintage) counts as the end of that UTC day.

| Room path | Source | Rule |
|---|---|---|
| `data/live/vintages/<id>/`, `index.csv` | live pulls | folder id time <= cutoff; index rows of selected vintages with retrieved_utc <= cutoff |
| `data/panel/vintages/<id>/`, `index.csv` | panel vintages | folder id time <= cutoff; rows by created_utc |
| `data/live/market/snapshots/<id>/`, `index.csv` | market snapshots | snapshot id time (save time) <= cutoff; rows by saved_utc |
| `data/market/cds_snapshots.csv` | gated CDS export | rows with snapshot_id time and as_of <= cutoff |
| `data/live/market/manual_quotes.csv` | hand-typed quotes | rows with entered_utc <= cutoff |
| `data/live/events/<source>/vintages/<id>/`, `index.csv` | event vintages | folder id time <= cutoff |
| `data/live/events/exports/<id>/`, `index.csv` | event export archives (events_long, events_weekly as consumed) | export id time <= cutoff |
| `data/live/snapshots/<vintage>-inputs/`, `index.csv` | `replay.freeze_inputs` (TEAM_A_RUN_INPUTS) | index row frozen_utc <= cutoff and its vintage selected |
| `data/live/snapshots/<ts>-pre-apply/` | pre-apply backups, forced_cells.csv | folder id time <= cutoff |
| `data/live/review_ledger.csv` | review ledger incl. attestations | rows with ts_utc <= cutoff |
| `derived/four_eyes.csv` | from the kept ledger rows | four_eyes = yes / self-approved / no approver, attestation yes/no |
| `data/approvals/log.jsonl`, `proposals/` | change approvals (Team C store, read only) | rows by ts_utc (a prefix of the hash chain); proposals by change-id time |
| `data/audit_trail.csv` | per-cell provenance | rows with retrieved > cutoff dropped; undated seed / hand-entered rows kept |
| `data/live/*.csv`, `*.json` | current pull (transform_log, unserved, feed_failures, provenance, review, raw_*) | whole files when `live/feeds.json` retrieved <= cutoff |

Never exported: `data/vendor_licences.json`, credential-named files (`.env`, `*.pem`, `*.key`, `*secret*`,
`*token*`, `*credential*`, `*password*`, `id_rsa` ...), JSON files with credential keys (`password`, `app_key`,
`api_key`, `token`, `secret` ...) at any depth, files whose text matches a credential pattern (private key blocks,
AWS / GitHub / Slack / `sk-` keys, `password=...`), hidden, lock and temp files, symlinks. Licence tags inside the
data (licence columns, manifest `licences`) are kept. Everything left out is listed with its reason under
`build.excluded` in `MANIFEST.json`.

**Licence-restricted files are withheld by default (EQ-A-0044).** Sam replaced Yahoo on 2026-10-23 (EQ-A-0040),
and Yahoo's terms (personal, non-commercial use) do not allow passing its data to an external validator. So
`raw_yahoo.csv` is left out wherever it is, including the frozen `2026-10-23/` vintage. Any CSV whose licence
column says non-commercial or personal (`market.gate.DESK_BARRED_LICENCE_TERMS`) is left out too. `index.csv`
files are exempt, because they only list licences. Each such file is listed under `build.excluded` with its reason,
and under the hashed `withheld` list with its path, size and sha256, so verify.py does not report it missing.
`--include-restricted` (`include_restricted=True`) keeps these files. Use it only when Sam confirms the licence
allows it. Any file named `*yahoo*` (any case, e.g. `RAW_YAHOO.csv`) counts as Yahoo data (SEC-A-006 L4).

**Yahoo-derived values are blanked in the room copies (SEC-A-006 M2, EQ-A-0045).** Values computed from Yahoo
data fall under the same terms as the prices. Without `--include-restricted`, the copies (never `data/`) are
changed as follows, in the current pull, the vintages and the snapshots:
- a row whose own `source` is Yahoo / yfinance, or whose licence column says non-commercial or personal, keeps its
  labels but has its value columns blanked (`value`, `live`, `live_value`, `change`, `gate_reason`, `reason` ...):
  `provenance.csv`, `audit_trail.csv`, market quotes. A CSV with such rows but none of those columns is withheld;
- `review.csv`, `diff_vs_seed.csv` and the ledger (no source column) have those columns blanked on rows whose value
  is one a provenance record or the audit trail attributes to Yahoo for that cell;
- `live_profile.csv`, `live_inputs.csv`, `countries.csv` and `indicators.csv` have each such cell blanked.
Each changed file is in the hashed `redactions` list with `restricted_rows`, `restricted_cells` and its original
sha256 and size, so a vintage holding one is reported `altered`, as for a withheld file. On the 2026-10-23 data:
8 files, the 27 Yahoo provenance rows (17 `fx3m`, 10 `equity_vol`) in the pull and the vintage, and the 17 audit
trail rows; none of the 27 Yahoo values is left in the room.

**Files that cannot be scanned are withheld (SEC-A-006 L4).** Secrets and e-mail addresses are looked for in UTF-8
text and in UTF-16/32 text with a byte-order mark. A file that is neither (binary, or BOM-less UTF-16) is withheld
with the reason `unscannable: ...` rather than exported unscanned. The secret patterns also cover `pass` / `pw` /
`auth` keys, `Bearer <token>` and JWTs, and `%40`-encoded e-mail addresses are redacted too.

**E-mail addresses are redacted at source (EQ-A-0044, SEC-C-008 R6).** In every text file copied into the
room (vintage files, the ledger and `derived/four_eyes.csv` included), each address is replaced by
`[redacted-email]` before the file is hashed. The pattern is Team C's evidence `EMAIL_RE`, so the bundle finds
nothing left to change. The hashed `redactions` list gives each file with its replacement count and the original
sha256 and size. `data/` is never changed.

**What this does to the vintage hash.** A live or panel vintage's content hash covers the original bytes of every
file in its folder, so a vintage with a withheld or redacted file cannot be re-hashed from the room. At build time,
the builder verifies the source folder against `vintages/index.csv` and records the result in `altered_anchors`.
verify.py then reports the folder as `altered` (a warning) when the room's index row matches that hash and the
present plus withheld files add up to its `n_files`, and as `failed` otherwise. The frozen `2026-10-23/` vintage has
no index row in the project copy, so it stays `unanchored`, and the note says raw_yahoo.csv is withheld. Its source
content hash is in `altered_anchors`, so it can be compared with the Mac's index. Anchors that compare a sha256
(market and event manifests and index rows, replay manifests) use the recorded original sha256 and still check
fully.

**Limitations register in the room.** `limitations/data-limitations.md` is generated for the as-of by
`econquest.ingestion.limitations.build_register` from the newest pull at or before the cutoff. Its two tables are
computed; its narrative is hand-written (EQ-A-0042) and may postdate the cutoff. The manifest's `limitations` entry
says whether it was generated and from which pull, or why not. `limitations=False` skips it.

## DEMO label, licence register and MVP dataset (EQ-A-0125)

Until Sam approves the first licence register baseline, a room built for a release is labelled DEMO:

```bash
cd ~/econquest
python -m econquest.ingestion.dataroom build --as-of 2026-10-26T06:24:15Z --demo-baseline --mvp
python -m econquest.ingestion.dataroom verify outputs/dataroom/2026-10-26T062415Z-DEMO --expect-manifest-sha256 HEX
```

- `--demo-baseline` (`licence_baseline="demo"`): the README opens with "DEMO baseline: not Sam's approval", verify.py
  prints the label in every report, and the hashed manifest key `licence_baseline` records the register (sha256, rows,
  counts of client_output and validator_nda, every row's status, the D3 `imf_via_wdi` state, the PI-11 rows, the
  row QEDS values match) and approver "DEMO (not Sam)". The build reads the data folder's own register
  (`licences.use_register`) and adds `data/licences.csv` (kind `licence_register`). Refused when the register's
  governance state is not `no_baseline` (a real or drifted baseline, a broken approvals chain) or the register is not
  a regular file. The default folder is `<as_of>-DEMO`, so evidence never takes it for the plain room of that date.
- `--mvp` (`include_mvp=True`): adds the frozen MVP dataset `data/mvp/` (kind `mvp_dataset`) when its manifest's
  `built_utc` is at or before the cutoff, else lists every MVP file under `build.excluded`. Its files pass the same
  licence, secret and e-mail rules as any other. The hashed `mvp` record keeps dataset_sha256, as_of, vintage_id,
  built_utc and what `mvp_dataset.verify(load=False)` said at build. verify.py's `mvp_dataset` anchor re-checks every
  file against `data/mvp/manifest.json` (the original sha256 for a withheld or redacted file), refuses an unlisted
  file and recomputes dataset_sha256, so a file changed under a re-signed MANIFEST.json still fails.
- Room sections: `data/`, `derived/` and `limitations/` are the internal section, under NDA. Content from
  client-restricted sources (IMF included) is only there. `MANIFEST.json`, `README.md` and `verify.py` carry paths,
  sizes, hashes, counts and register text, no data values.
- Without either flag the room is exactly as before (same files, options and manifest keys).

The 0.8.0 refresh (2026-10-26). Code 0.8.0 plus EQ-A-0125. The room is `outputs/dataroom/2026-10-26T062415Z-DEMO`,
manifest_sha256 `5a9ee799c92c1a9eb23e2b62df73d7e45846b839d2ce29e1779f9cb032e03c18`. It has 155 files, 32.0 MB.
- Register: 62 rows, sha256 `395fedf3...`. It is the same in data/ and data/mvp. HO-20261026-A-A-004 added two
  tighten-only rows, `ucdp_ged` and `research_pullpack`.
- data/mvp: `129268fcddc32547`, 71 files. 6 are withheld: benchmarks.csv and panel/sovereign_defaults.csv by
  `third_party_unverified`, the 3 spreads files by `fred_oecd`, and rulebook.csv because it has restricted-source
  rows and no value column. 4 have values blanked or addresses redacted.
- Result: VERIFIED, and `--expect-manifest-sha256` gives ok. Three warnings: the 2026-10-23 vintage is altered
  (Yahoo), the pre-apply backup has no anchor, and data/mvp is altered.

As-of change. The first build used the 0.8.0 package time, 2026-10-26T03:29:42Z, giving room `...T032942Z-DEMO`
(manifest_sha256 `23054c80...`, 60-row register `c3f90c33...`, data/mvp `6a30118871e2c50c`). Then the register
gained its two rows and data/mvp was rebuilt at 2026-10-26T06:24:15Z. At the old cutoff the builder leaves the new
data/mvp out, because it was built after that cutoff. AGENT-08 therefore moved the as-of to the data/mvp build time
and removed the stale room. A rebuild with the command above gives the same data files. manifest_sha256 also covers
the code hash in README.md, so it changes whenever the code changes.

## MANIFEST.json

`schema` (`econquest.dataroom/1`), `as_of`, `cutoff_utc`, `code` (`version`, `code_hash`), `options`
(`include_current`, `include_restricted`, `limitations`), `rules` (kind -> rule), `counts` (kind -> files, bytes), `totals`, `files` (one entry per file:
`path`, `size`, `sha256`, `source` (path relative to the data folder, or the package file for verify.py, null for
README.md), `kind`, `as_of_rule`, and `filter.rows_kept` for row-filtered files), `checks` (the integrity anchors run
at build time), `withheld`, `redactions`, `altered_anchors` and `limitations` (EQ-A-0044, above), `content_sha256` (SHA-256 of `path=sha256;` over all files in path order), `manifest_sha256`
(SHA-256 of the canonical JSON, sort_keys and `,` `:` separators, ASCII, of the manifest without `manifest_sha256`
and `build`), and `build` (built_utc, source_data_dir as the folder's basename only, python, excluded, filtered row counts;
outside both hashes).

Determinism: the same data and code give the same `manifest_sha256`, whatever the build time. A room rebuilt later for
the same as-of date keeps its hash while the append-only stores are unchanged, because only records dated at or
before the cutoff are selected. The current-pull files and `audit_trail.csv` are working copies, so a later pull or
run can change them (the README in the room says so).

## Verify (validator)

```bash
cd <room>
python -I verify.py            # exit 0 and "RESULT: VERIFIED", or exit 1 with the problems
python -I verify.py --json
```

`python -I verify.py --expect-manifest-sha256 HEX` (also `dataroom verify ROOM --expect-manifest-sha256 HEX`) fails
the room unless the recomputed manifest_sha256 equals HEX, the value sent separately (SEC-A-014 P3-L1, EQ-A-0125).
Without it, a room that was edited and then fully re-hashed (for example with its DEMO label and banner removed)
still verifies against itself. A labelled room whose folder name does not end in `-<LABEL>` gets a warning.

It reports missing, extra and changed files and unsafe manifest paths, recomputes both hashes and re-runs the
integrity anchors: live and panel vintage content hash against `index.csv`, market snapshot, event vintage and event
export manifests against their `index.csv`, frozen replay inputs against `snapshots/index.csv`, and the
approvals log hash chain from genesis. `unanchored` (a folder with no index row, e.g. the legacy `2026-10-23/`
vintage made before `index.csv` existed) and `altered` (a folder with a withheld or redacted file, checked against
what the build verified) are warnings; `failed` fails the room. A live vintage whose `index.csv` rows disagree fails
(SEC-A-004 L1). On a hostile room (SEC-A-006 L2/L3) verify.py never follows a symlink (any link in the room is
`unsafe`), refuses a MANIFEST.json over 64 MB, checks the types in the manifest and the withheld / redaction paths,
and reports a malformed or deeply nested manifest as FAILED, never with a traceback.

## Hand it over

1. Build the room for the agreed as-of date and run `verify` (expect VERIFIED).
2. Send the room (zip it as it is) and, separately, its `manifest_sha256` (email or the evidence bundle), so the
   validator can run `python -I verify.py --expect-manifest-sha256 <that value>`.
3. Point the validator at `README.md` and `limitations/data-limitations.md` in the room.
4. Licences: Yahoo data and files licensed non-commercial or personal are withheld by default. Other vendor data
   goes in under the licence tag recorded with it. Before sending, check that each licence lets you pass that data to
   the validator. Escalate to Sam: an agent never decides a licence question.

## Known gaps (2026-10-24)

- The project copy of `data/` has no frozen replay snapshot (`data/live/snapshots/` does not exist) and no
  `data/live/vintages/index.csv`, so a room today holds the legacy `2026-10-23/` vintage (unanchored), the current pull,
  the audit trail and the approvals log, but not indicators.csv / countries.csv as of the date. The first
  `fetch --apply` on the Mac after EQ-A-0007 freezes them; until then use `--include-current` for an as-of date at or
  after the latest record.
- No review ledger, market snapshot, event vintage or panel vintage exists in the project copy yet; the rules are
  covered by the tests with synthetic stores.
