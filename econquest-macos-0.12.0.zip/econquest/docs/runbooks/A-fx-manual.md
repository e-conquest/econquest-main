# Runbook: hand-entered fx3m from central-bank pages (data/fx_manual.csv)

Tickets EQ-A-0071 (hard pegs) and EQ-A-0072 (hand-entered rates). Owner: Team A, AGENT-06. Operator: Sam.
Written 2026-10-24 offline from `econquest/ingestion/feeds.py` (`HARD_PEGS`, `fx_manual_cells`,
`official_fx_transforms`) and `econquest/ingestion/ledger.py` (`HAND_ENTERED`). The cloud cannot reach any of
the pages below, so **no URL here was opened from this environment**. Deep links are marked UNVERIFIED; check
each one the first time you use it.

## Why

After the official FX pull (BIS WS_XRU, ECB EXR; `docs/runbooks/A-official-fx.md`) nine Country Profile fx3m
cells still held Yahoo values. They are covered like this:

| Country | Currency | How fx3m is filled now |
|---|---|---|
| Belize | BZD | Hard peg, automatic: BZD 2.00 per USD (Central Bank of Belize, since 1976), so fx3m = 0.0 |
| Senegal | XOF | Hard peg, automatic: XOF 655.957 per EUR (BCEAO, French Treasury guarantee, since 1999), so fx3m = fx3m of EUR per USD |
| Colombia, Malaysia | COP, MYR | Official values in the review ledger. Sam releases them (`econquest review approve` and `review apply`) |
| Venezuela, Nigeria, Pakistan, Vietnam, Zambia | VES, NGN, PKR, VND, ZMW | **Hand-entered** in `data/fx_manual.csv` (this runbook), used only once attested |

Precedence for every country is BIS, then ECB, then the legal parity of a hard peg, then an attested row
of `fx_manual.csv`. If BIS or the ECB starts quoting one of these currencies, that series wins and the peg
or the manual row is ignored.

## The five pages

Rates are in **currency units per 1 USD**, as the central bank publishes them. Use the same page and the same
rate type for both dates in a row.

| Currency | Central bank | Site (official domain) | Rates page | Rate to take |
|---|---|---|---|---|
| VES | Banco Central de Venezuela (BCV) | https://www.bcv.org.ve | Home page shows today's official USD rate. History: https://www.bcv.org.ve/estadisticas/tipo-cambio-de-referencia-smc **(UNVERIFIED)** | Official reference rate, Bs per USD |
| NGN | Central Bank of Nigeria (CBN) | https://www.cbn.gov.ng | https://www.cbn.gov.ng/rates/ExchRateByCurrency.html **(UNVERIFIED)** | NFEM official closing rate, NGN per USD |
| PKR | State Bank of Pakistan (SBP) | https://www.sbp.org.pk | https://www.sbp.org.pk/ecodata/rates/war/WAR-Current.asp **(UNVERIFIED)** | Weighted average customer rate, PKR per USD |
| VND | State Bank of Vietnam (SBV) | https://www.sbv.gov.vn | The central exchange rate ("Tỷ giá trung tâm") on the home page **(UNVERIFIED: no stable deep link known)** | Central rate, VND per USD |
| ZMW | Bank of Zambia (BoZ) | https://www.boz.zm | https://www.boz.zm/average-exchange-rates.htm **(UNVERIFIED)** | Average (mid) rate, ZMW per USD |

The rate type in the last column is a proposal. If a page offers several rates (buying, selling, mid), take
the mid or official one and write which one in `source`, for example `CBN NFEM closing rate`.

## Fill a row

`data/fx_manual.csv` has a header and no rows. Add one row per currency, with no comment lines (the
attestation reads every line as a cell):

```
country,currency,date_now,rate_now,date_3m,rate_3m,source,url,entered_by,entered_utc
Nigeria,NGN,2026-10-23,<rate on 2026-10-23>,2026-07-24,<rate on 2026-07-24>,CBN NFEM closing rate,https://www.cbn.gov.ng/...,Sam,2026-10-24T21:00:00Z
```

- `country` is the name as in `data/countries.csv` (ISO3 also works). `currency` must be that country's
  currency in countries.csv, or the row is held.
- `date_now` is the latest date the page publishes. `rate_now` is the rate on that date.
- `date_3m` is about 91 days earlier: **80 to 100 days** before `date_now`, otherwise the row is held. Take
  the business day closest to `date_now` minus 91 days, from the same page. `rate_3m` is the rate on that day.
- Both rates must be positive numbers, typed as the page shows them (no thousands separators).
- `date_now` must be no later than the run date and **at most 14 days** before it, otherwise the row is held
  as stale. Add a new row for each refresh. Do not edit an old row, because an edit withdraws its
  attestation. The newest attested row per country is used.
- fx3m = rate_now / rate_3m x 100 - 100 (positive = the currency weakened), the same definition as the BIS
  and ECB series.

## Attest

A row feeds fx3m only after the review ledger holds an attestation of its current content. The hash covers
the whole row, so changing rate_3m, either date, the source or the url withdraws the attestation in the same
way as changing rate_now. Four-eyes rule: `--approver <second person>`, or `--self-approved`, which is
recorded as a governance exception.

```bash
econquest attest --list                                   # fx_manual rows appear as table fx_manual, key CCY|date_now
# today: attest through the batch form (works now; key is "<currency>|<date_now>")
econquest attest --all-files --key "NGN|2026-10-23" --dry-run
econquest attest --all-files --key "NGN|2026-10-23" --confirm --author smc --self-approved --expect 1
# once Team C adds fx_manual to `attest --file` (handoff HO-20261024-A-C-020):
econquest attest --file fx_manual --author smc --self-approved
```

Do not use `--country Nigeria` with `--all-files`. It also selects Nigeria's unattested cells in
adjustments.csv.

## Rerun the transform

**No offline route recomputes fx3m from fx_manual.csv.** `econquest review apply --vintage <id>` re-applies
the values a saved vintage already holds, and a vintage taken before the rows were typed has no hand-entered
values. The manual and peg values are computed inside the official FX step, so rerun that step on the Mac.
It needs BIS or the ECB to answer, because if neither feed answers, the step stops and writes nothing:

```bash
caffeinate -i .venv/bin/python -m econquest.ingestion.pullpack run --steps fx --redo fx   # new vintage, no apply
# read the fx checklist in data/live/pullpack/report.md, then
.venv/bin/python -m econquest.ingestion.pullpack run --steps fx --apply-fx                # applies; never forces
```

(The same thing without the pack: `econquest fetch --only fx`, then `econquest review apply`.)

The quality gate still applies. A new fx3m that moves more than 50% from the value in countries.csv is held
as `change: ...`, and so is Belize (seed 1.464 from Yahoo, now 0.0). Release a held cell as in
`docs/runbooks/A-fetch-on-mac.md` step 3:

```bash
econquest review list --pending
econquest review approve "Country Profile" fx3m Belize --author smc --self-approved --note "legal parity, fx3m 0"
econquest review apply
```

A row that is unattested, edited after attestation, stale, outside the date window, non-positive or in the
wrong currency gives **no value**. The country appears in `data/live/unserved.csv` and in the review as
`not served - ... held: <reason>`. Nothing falls back to the old seed or to Yahoo.

## Check

```bash
python -m econquest.ingestion.audit restricted     # must print "0 restricted-source cells" and exit 0
```

It reaches 0 once Belize and Senegal (pegs) and the five hand-entered countries are applied, and Sam has
released Colombia and Malaysia. Peg values carry the source `official parity ...` and hand-entered values the
source `hand-entered from <source> (<url>), attested by <who>`. Neither is a restricted source.

Client output: hand-entered values are **desk numbers but not client numbers**. `python -m
econquest.ingestion.audit client` lists them with "licence of the central bank's page not checked", which is
the same rule as the national adapters (EQ-A-0060). Peg values are not client-restricted.
