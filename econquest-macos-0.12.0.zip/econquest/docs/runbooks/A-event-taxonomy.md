# A: event taxonomy, GDELT FIPS reference and unified event API (EQ-A-0139)

Owner: Team A / AGENT-02. Feeds Team B EQ-B-0142 (conflict escalation model). Written 2026-10-26.
Code: `econquest/ingestion/events/taxonomy.py`, `unified.py`, `fips_reference.py`, and `gdelt.py` (`--categories`).
Tests: `tests/test_events_taxonomy.py`, `tests/test_events_unified.py`, `tests/test_events_fips_reference.py`.

Everything here reads recorded data only. No data host was fetched, nothing under `data/` changed, `data/mvp` was
not touched and no new folder was created.

## 1. Where the 612k unmapped GDELT rows came from

GDELT codes `ActionGeo_CountryCode` (column 53) in FIPS 10-4, not ISO. `gdelt.map_countries` keeps a row only when its
code is in `gdelt.FIPS_TO_ISO3`, which holds the desk's 18 countries only. Every other row is dropped and counted per
code into the staging manifest. From there it goes into the vintage manifest (`provenance.unmapped`,
`unmapped_total`) and the pull-pack report.

Recorded counts (Mac pull pack, `team/inbox/<pull>/report.json`, step 5b `counts.unmapped_total`):

| Pull | GDELT vintage | Days | Rows stored | Unmapped rows |
|---|---|---|---|---|
| pull-20261024T183257Z | 2026-10-24T185014Z-5a8eb4f1 | 2026-10-17..23 | 882 | 612,127 |
| pull-20261025T013150Z | 2026-10-25T014301Z-101935a0 | 2026-10-18..24 | 882 | 614,172 |
| pull-20261025T121034Z | 2026-10-25T122156Z-57287fc7 | 2026-10-18..24 | 882 | 614,172 |

The unmapped figures are raw rows, counted before GlobalEventID dedupe and including non-root events. Nearly all of
them are events in countries outside the desk, so the desk's numbers were dropping them as designed. They are not
lost desk events. The per-code breakdown is in the vintage manifests on Sam's Mac only. The vintages are not on this
disk: `data/live/events/` does not exist here, and neither the shipped zips nor the DEMO data room carry them. For the
same reason, no mapped-event count per country is recorded here. The reports record only metric rows: 882 =
18 countries x 7 days x 7 metrics. That means every desk country had at least one root event on every staged day,
because the mean metrics are written only for days with events.

## 2. FIPS 10-4 -> ISO3 reference table

`python -m econquest.ingestion.events.fips_reference --data data --json` (add `--csv` and an output path to write the
table; unquoted `[...]` is a glob in zsh, so the options are not shown in brackets)

**Source.** No authoritative FIPS 10-4 file is on disk. The repo's data/tests/team/docs, the shipped zips and the
installed packages were checked; there is no pycountry or similar. The table is therefore derived from what econquest
already records, and nothing is typed from memory:

- **Resolved rows (18):** `gdelt.FIPS_TO_ISO3` copied verbatim. It was set in EQ-A-0023 (AGENT-06, 2026-10-23,
  "checked by hand against FIPS 10-4"). Its trap cases (NI = Nigeria vs NG = Niger, SN = Singapore vs SG = Senegal,
  ZA = Zambia) are pinned in tests. Names come from `data/countries.csv`.
- **Unresolved rows (70):** every ISO3 in the 88-country universe (`data/panel/universe_proposal.csv`) that no
  resolved row produces. Their FIPS column is left blank. An ISO2 code is not a FIPS code (NG is Nigeria in ISO but
  Niger in FIPS), so nothing is inferred from ISO2 codes or names.

**Licence.** The table is econquest's own derivation from its code, and no third-party file is copied. No
licence-register row is needed: no `data/` file and no new source label are added, and the GDELT row in
`data/licences.csv` (`gdelt`, terms verified 2026-10-25) covers the event data itself. If an authoritative list is
sourced later, AGENT-04 adds a tighten-only row for it before it is stored.

| FIPS | ISO3 | Country | | FIPS | ISO3 | Country |
|---|---|---|---|---|---|---|
| AR | ARG | Argentina | | MY | MYS | Malaysia |
| BH | BLZ | Belize | | NI | NGA | Nigeria |
| BR | BRA | Brazil | | PK | PAK | Pakistan |
| CH | CHN | China | | RP | PHL | Philippines |
| CO | COL | Colombia | | SG | SEN | Senegal |
| IN | IND | India | | SN | SGP | Singapore |
| JA | JPN | Japan | | VE | VEN | Venezuela |
| KS | KOR | South Korea | | VM | VNM | Vietnam |
| ZA | ZMB | Zambia | | ZI | ZWE | Zimbabwe |

**Unresolved (70 universe countries, FIPS blank):** AGO, ALB, ARE, ARM, AUS, AZE, BEN, BHR, BOL, CAN, CHL, CIV, CMR,
COG, CRI, DEU, DOM, ECU, EGY, ETH, FRA, GAB, GBR, GEO, GHA, GTM, HND, HUN, IDN, IRQ, ISR, ITA, JAM, JOR, KAZ, KEN, KWT,
LBN, LKA, MAR, MDV, MEX, MKD, MNE, MNG, MOZ, NAM, OMN, PAN, PER, PNG, POL, PRY, QAT, ROU, RWA, SAU, SLV, SRB, SUR, THA,
TJK, TTO, TUN, TUR, UKR, URY, USA, UZB, ZAF. The FIPS codes behind the 612,127 / 614,172 unmapped rows are also
unresolved, and here they are unknown as well (see section 1).

**Mapped count before and after:** 18 FIPS codes -> 18 ISO3 before, and 18 after. The universe has 18 of 88 resolved,
both before and after. The recorded unmapped totals cannot change, because no new code was resolved.

**Deliberately not done:** the table is not written to `data/live/events/gdelt/fips_reference.csv`. `mapping_qa` reads
a file there as a complete reference. With 18 rows it would count every non-desk code as unmapped and breach its 2%
threshold. Until a complete list exists, the QA keeps reporting "outside known map (reference table missing)".

**To resolve the rest (Sam's Mac, Sam-gated):** source GDELT's country lookup or the FIPS 10-4 publication, record
its URL and retrieval date in `fips_reference.SOURCE["authoritative_list"]`, have AGENT-04 add the licence row, and
only then add rows. A test pins the resolved rows to `gdelt.FIPS_TO_ISO3`, so the adapter map and the table change
together.

## 3. Event taxonomy (eq-events-taxonomy/1)

There is one small category set. Every source code maps to exactly one category or to none (`uncategorised`, which is
counted and never assigned).

| econquest category | GDELT CAMEO root (EventRootCode) | UCDP type_of_violence | Primary source |
|---|---|---|---|
| armed_conflict | 19 Fight, 20 Use unconventional mass violence | 1 state-based, 2 non-state | UCDP |
| violence_against_civilians | 18 Assault | 3 one-sided | UCDP |
| coercion | 15 Exhibit force posture, 16 Reduce relations, 17 Coerce | - | GDELT |
| protest | 14 Protest | - | GDELT |
| verbal_conflict | 09 Investigate, 10 Demand, 11 Disapprove, 12 Reject, 13 Threaten | - | GDELT |
| cooperation | 01-08 (statement, appeal, intent to cooperate, consult, diplomatic and material cooperation, aid, yield) | - | GDELT |

- **Measures:** `events` (both sources) and `fatalities` (UCDP only).
- **What each source counts:** UCDP codes fatal organised violence (at least one death). GDELT counts media-reported,
  machine-coded events, and its volume follows media attention. A category is shared across the two sources, but
  their values are on different scales and are never added together.
- **Root names and the QuadClass split** (09-13 = QuadClass 3, 14-20 = QuadClass 4) follow the GDELT 2.0 codebook
  as already used in `gdelt.py` and `export.py`. They carry the same caveat as there: *verify against the CAMEO
  manual*.
- **Stored GDELT vintages before this ticket** hold only `events_protest` (root 14) and `events_verbal_conflict`
  (QuadClass 3). From those vintages the API takes protest and verbal_conflict only ("legacy" resolution). It never
  splits QuadClass 4 into armed_conflict, coercion and violence against civilians.
- **New GDELT vintages saved with `--categories`** carry `cat_<category>` counts plus `cat_uncategorised`, which add
  up to `events_total`. They are computed from the staged event rows, which keep `event_root_code`, so no extra
  download is needed. When a vintage has them, its legacy metrics are ignored to avoid double counting.
- **`--categories` is off by default,** so existing vintages, the pull pack and the A-0138 rehearsal keep their shape.
  Turning it on in the pull pack is a follow-up for AGENT-06/AGENT-08.

## 4. De-duplication

1. **Events, within GDELT.** A GlobalEventID that appears in several 15-minute files or staged days is kept once
   (`gdelt.dedupe`, first file wins). This existed already and is unchanged.
2. **Across days and vintages.** Pull-pack and incremental vintages overlap. For each (source, iso, freq, period,
   category, measure) the API uses only the newest vintage saved at or before as_of, and drops and counts the older
   copies (`dropped_overlap`). This rule is checked in tests.
3. **Across sources.** Values are never summed across sources.
   - `combine="by_source"` (default) returns both sources, with `primary` marking the one to use.
   - `combine="primary"` keeps one row per (iso, period, category, measure), and the non-primary copy of a shared cell
     is dropped (`dropped_cross_source`).
   - The primary source is fixed per category, never chosen per cell, so a series never switches source or scale from
     month to month.
   - Non-primary rows that have no primary counterpart are also left out by "primary". This is policy, not
     de-duplication, so they are counted apart (`dropped_non_primary`) and kept out of the rate.

`dedup_rate = (dropped_overlap + dropped_cross_source) / rows_in`

**On the recorded pull shape** (three GDELT vintages, 18 countries, days 17..23 / 18..24 / 18..24, legacy metrics):
756 category cells go in, 468 overlap copies are dropped and 288 remain, so the rate is **61.9%**. All of it is
cross-day overlap. This was measured by running the API on a scratch store with the recorded shape and SYNTHETIC
values, because the real vintages are not on this disk. The cross-source rate is 0 today because UCDP has never been
pulled: every pull report says "UCDP_API_TOKEN is not set".

**Not possible from stored aggregates:** matching one real-world event that GDELT codes under several GlobalEventIDs
(re-reports across days), or one GDELT event to one UCDP event. Both need event-level records with actors and
locations. Neither the staging nor the vintages keep these, and adding them would change the stored data contract.
This is a candidate follow-up ticket.

## 5. Per-country coverage on recorded data

`python -m econquest.ingestion.events.unified coverage --data data --pull-report team/inbox/pull-20261024T183257Z/report.json team/inbox/pull-20261025T013150Z/report.json team/inbox/pull-20261025T121034Z/report.json`

Result on this disk, 2026-10-26:

- **Stored vintages:** gdelt 0, ucdp 0. The unified API has rows for 0 of the 88 universe countries.
- **From the pull reports:** GDELT covered the 18 desk countries on 2026-10-17..24 (8 distinct days across 3 pulls),
  with all 7 metrics on every country-day. No category split is recorded (all three are legacy vintages).
- **UCDP:** skipped in all three pulls (token not set), so there is no UCDP coverage.
- **The other 70 universe countries:** no GDELT coverage, because they have no FIPS mapping (section 2), and no UCDP
  coverage.

On the Mac, the same command reads the stored vintages. For each country, source, category and measure it reports the
first and last month, months covered, non-zero months, total and GDELT staged days. It also lists the unmapped top-20
codes per GDELT vintage from its manifest. It reports gaps and never fills them.

## 6. Unified event API (for Team B, EQ-B-0142)

```python
from econquest.ingestion.events.unified import unified_events, coverage_report, UNIFIED_COLUMNS
df = unified_events("data", as_of="2026-10-24", freq="M", combine="by_source",
                    isos=None, categories=None, sources=("gdelt", "ucdp"))
df.attrs["dedup"]   # api, taxonomy, as_of_utc, rows_in, dropped_overlap, cross_source_cells,
                    # dropped_cross_source, dropped_non_primary, rows_out, dedup_rate, gdelt_resolution
```

Columns: `iso, period, freq, source, category, measure, value, days_covered, primary, available_utc, vintage_id,
provenance`.

- **as_of:** a `YYYY-MM-DD` date (end of that UTC day), a timestamp, or None (everything stored). A row is used only
  when its vintage was saved by as_of and its period starts by as_of. The same as_of always returns the same table,
  whatever is saved later (tested).
- **available_utc:** the vintage's `saved_utc`. This is stricter than `export.events_long`, which dates a row by
  `retrieved_utc` or the UCDP release date.
- **freq:** `"D"` returns GDELT days only. `"M"` returns UCDP months, and GDELT days summed per month, with
  `days_covered` showing how many staged days went into the month.
- **vintage_id at freq M (GDELT):** the vintages whose days went into the month, joined with `|` in save order;
  `available_utc` is the newest of them (ARCH-A-PI14).
- **Explicit zeros:** a 0 means the source covered that cell and saw nothing.
- **Missing categories:** legacy GDELT vintages have no armed_conflict, coercion, violence_against_civilians or
  cooperation rows. `gdelt_resolution` says which vintages are legacy.
- **Empty store:** the result is an empty table with the columns, never an error and never a fallback.
- **CLI:** `python -m econquest.ingestion.events.unified events --as-of 2026-10-24 --freq M --out /tmp/u.csv` (the
  `--out` folder must exist; none is created)

The existing exports (`events_long.csv`, `events_weekly.csv`) and `engine/event_index.py` are unchanged.

## 7. Limitations and follow-ups

- **Resolve the 70 universe countries' FIPS codes** from an authoritative list on Sam's Mac (section 2). This is
  Sam-gated, and the licence row goes through AGENT-04.
- **Turn on `--categories` in the pull pack and incremental runs** (AGENT-06/AGENT-08), so GDELT armed_conflict,
  coercion and violence against civilians exist on real data.
- **Get the UCDP token** (Sam). Until then there is no UCDP data and no cross-source overlap.
- **Event-level cross-source and re-report dedup** needs a contract change for raw event storage (section 4).
- **The CAMEO root names and QuadClass split** carry the existing "verify against the CAMEO manual" caveat.

No command in this runbook takes `--author`. All paths are explicit, with no globs, so the commands are zsh-safe.
