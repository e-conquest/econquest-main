# Central-bank and national-statistics adapters (EQ-A-0050, coverage to 60% part 2)

Owner: Team A (AGENT-06). Code: `econquest/ingestion/official/central_banks.py`. Precedence:
`official/precedence.py` (`choose_national`). Gate: `official/central_banks.py` (`cb_gate_checks`, called from
`official/gate.py`). Verification file: `data/panel/cb_series_verified.csv`. Tests: `tests/test_central_banks.py`
(synthetic fixtures, offline).

**Status: nothing here is verified.** The cloud cannot reach any central bank. Endpoints, response layouts, series
codes and units are written from the institutions' API documentation as remembered. Every registry entry says
`verified="no"`, and every cell the feed fills is held by the gate until Sam's Mac check below marks its series
verified.

## 1. What it serves

The registry covers the top 25 from `python -m econquest.engine.nowcast names` (the 18 desk names plus IDN, MEX, CHL,
PER, URY, PAN and DOM). It has four concepts per country:

| Concept | Cell(s) | Rule |
|---|---|---|
| policy_rate | Country Profile `policy`; Inputs 5.13 | latest value; 5.13 = policy minus WEO PCPIPCH (same as the BIS rule) |
| cpi | Inputs 5.5 | published 12-month change, or index t / t-12 x 100 - 100 (monthly index only) |
| reserves | Country Profile `reserves` | latest stock in US$ / (WEO NGDPD of the fetch year x 1e9) x 100 |
| debt_stock | Inputs 1.3 | only when the national series is already % of GDP; a level series would be fetched raw only |

Machine-readable entries: 18 series in 7 countries. Everything else is `manual`, and the note on each entry gives the
reason. Run `python -m econquest.ingestion.official.central_banks list` for the full table.

| ISO3 | policy_rate | cpi | reserves | debt_stock |
|---|---|---|---|---|
| BRA | BCB SGS 432 (D) | BCB SGS 13522 (M, y/y) | BCB SGS 3546 (M, US$ mn) | BCB SGS 13762 (M, % GDP, BCB DBGG) |
| ARG | BCRA 6 (D) | BCRA 28 (M, y/y) | BCRA 1 (D, US$ mn) | manual |
| KOR | ECOS 722Y001/M/0101000 | ECOS 901Y009/M/0 (index) | ECOS 732Y001/M/99 (US$ th, unit unverified) | manual |
| MEX | Banxico SF61745 (D) | Banxico SP1 (index) | Banxico SF43707 (W, US$ mn) | manual |
| CHL | BCCh F022.TPM.TIN.D001.NO.Z.D (D) | code unknown | code unknown | manual |
| PER | BCRP PD04722MM (M) | BCRP PN01273PM (M, y/y) | BCRP PN00026MM (M, US$ mn, net) | manual |
| MYS | BNM Open API `opr` (latest decision only) | manual | manual | manual |
| SGP, IND, PHL, CHN, JPN, COL, NGA, VNM, PAK, SEN, ZMB, BLZ, VEN, ZWE, IDN, URY, PAN, DOM | manual | manual | manual | manual |

For PAN and SGP, policy_rate is marked "not applicable": PAN is dollarised with no central bank, and MAS runs an
exchange-rate band with no policy rate.

MEX, CHL and PER are not yet in `data/countries.csv` (the 18-country universe), so `fetch_all` asks for them only once
the universe includes them.

## 2. How it behaves

- **Named feed only.** `econquest fetch --only cb` runs it. It is not in `FEED_ALIASES`, so the default fetch skips it
  until series are verified. Run it with the other feeds so that precedence and cross-checks have something to compare
  against: `econquest fetch --only weo,worldbank,bis,imf,cb`.
- **Transport.** All requests go through `sources.https_get`: https only, redirects refused, body capped at 10 MB.
  Transient errors are retried. A proxy refusal, DNS failure or redirect stops further requests to that host while
  the other institutions continue. When every host tried is unreachable, the feed reports `unreachable`.
- **Raw rows.** These are saved as `data/live/raw_cb.csv` and in the vintage, with these columns: iso, series
  (concept), period, value, source, series_key, unit, freq, licence, and endpoint (the documented pattern, never a
  credential).
- **Precedence** (`choose_national`):
  - A verified national value replaces the BIS, IMF, WEO or World Bank value. The cell then has one provenance row,
    and the replaced value goes to `transform_log.csv`.
  - An unverified national value never replaces anything. It fills a cell only when no other feed did, and the gate
    holds that cell.
  - When both sources have a value, the comparison is written to `transform_log.csv`.
- **Unserved.** A cell left empty in a registry country gets a `cb` row in `unserved.csv`. The reason is either the
  manual note or the reason no observation came back.

## 3. Gate rules (per new series)

| Check | Rule |
|---|---|
| unverified | Hold unless `cb_series_verified.csv` has the row (iso3, concept, **same series_key**, verified=yes) |
| range (cell) | policy -2..200, 5.13 -100..100, 5.5 -30..1000, 1.3 0..300, reserves 0..200 % GDP |
| range (series) | Latest value by unit: pct_pa -2..200, pct_yoy -30..1000, index 1..1e7, pct_gdp 0..300, usd_mn 1..5e6, usd_th 1e3..5e9 (catches a wrong code or scale) |
| stale | Last observation older than D 30, W 45, M 92, Q 200, A 550 days at the gate date. E (BNM OPR: the latest decision, dated on its decision day) has no age limit |
| cb_cross | When a verified national value replaced another feed's value, hold if they differ by more than policy 1 pp, 5.13 1 pp, 5.5 3 pp, 1.3 10 pp, reserves 3 pp of GDP |

The tolerances are initial values and should be calibrated on the first Mac pull. `transform_log.csv` holds every
national-vs-existing pair.

## 4. Credentials (environment or OS keychain only)

| Variable | Used by | How to get it |
|---|---|---|
| `BANXICO_SIE_TOKEN` | Banxico SIE (sent as the `Bmx-Token` header) | Free token from Banxico's SIE API page |
| `ECOS_API_KEY` | BoK ECOS (sits in the URL path, as the API requires) | Free key from ecos.bok.or.kr |
| `BCCH_USER`, `BCCH_PASS` | BCCh SIETE (sit in the query string, as the API requires) | Free registration on the BCCh BDE site |

- The keychain fallback uses service `econquest` with the variable name as the account (`keyring`).
- None of these is ever read from argv or a file. Each is redacted from every failure message and never written to
  raw rows.
- A missing credential skips that series with a one-line reason.
- These are new secrets, so AGENT-09 reviews them (handoff from EQ-A-0050). The ECOS key and the BCCh password travel
  in the URL because those APIs offer no header form (as documented). Do not paste these URLs into tickets.

## 5. Verification on Sam's Mac (per country)

Each command fetches one series through the adapter (2 years) and prints its last 15 observations and any failures.
Compare the printed values with the institution's own website for the same dates. Then edit
`data/panel/cb_series_verified.csv` for that row: set `verified=yes`, `checked_on=YYYY-MM-DD`, `checked_by=Sam`, and
put the website page and value you compared against in `evidence`. If the code is wrong, fix `series_key` in
`central_banks.py` *and* in the file. A row verifies only the exact `series_key` it names.

Client output (EQ-A-0060): national licences are unchecked, so every `national: ...` value is held out of client
output (`python -m econquest.ingestion.audit client`) until Sam has checked the publisher's terms and set
`licence_ok=yes` on **every** row of that source in the file (default `no`). `verified` and `licence_ok` are separate:
the first lets the value into desk numbers, the second into client output.

```sh
cd ~/econquest && source .venv/bin/activate
python -m econquest.ingestion.official.central_banks list                    # registry, machine vs manual

# Brazil (BCB SGS, no key)
python -m econquest.ingestion.official.central_banks sample BRA policy_rate  # 432: Meta Selic, % p.a.
python -m econquest.ingestion.official.central_banks sample BRA cpi          # 13522: IPCA 12m, %
python -m econquest.ingestion.official.central_banks sample BRA reserves     # 3546: US$ mn (check the unit)
python -m econquest.ingestion.official.central_banks sample BRA debt_stock   # 13762: DBGG % GDP

# Argentina (BCRA, no key; if v3.0 answers 404/410, check the current API version on bcra.gob.ar)
python -m econquest.ingestion.official.central_banks sample ARG reserves     # 1: gross reserves, US$ mn
python -m econquest.ingestion.official.central_banks sample ARG policy_rate  # 6: may have stopped in 2024
python -m econquest.ingestion.official.central_banks sample ARG cpi          # 28: CPI y/y

# Korea (export ECOS_API_KEY first, or store it in the keychain)
python -m econquest.ingestion.official.central_banks sample KOR policy_rate  # 722Y001 base rate
python -m econquest.ingestion.official.central_banks sample KOR cpi          # 901Y009 CPI index
python -m econquest.ingestion.official.central_banks sample KOR reserves     # 732Y001 item 99: confirm the unit

# Mexico (export BANXICO_SIE_TOKEN)
python -m econquest.ingestion.official.central_banks sample MEX policy_rate  # SF61745
python -m econquest.ingestion.official.central_banks sample MEX cpi          # SP1 INPC index
python -m econquest.ingestion.official.central_banks sample MEX reserves     # SF43707 weekly, US$ mn

# Chile (export BCCH_USER and BCCH_PASS)
python -m econquest.ingestion.official.central_banks sample CHL policy_rate  # TPM
#   cpi / reserves codes: look them up in the BDE series search (website, or the SIETE SearchSeries function),
#   then set series_key in central_banks.py and add the rows to cb_series_verified.csv

# Peru (BCRPData, no key)
python -m econquest.ingestion.official.central_banks sample PER policy_rate  # PD04722MM
python -m econquest.ingestion.official.central_banks sample PER cpi          # PN01273PM, check it is the 12m change
python -m econquest.ingestion.official.central_banks sample PER reserves     # PN00026MM net reserves

# Malaysia (BNM Open API, no key)
python -m econquest.ingestion.official.central_banks sample MYS policy_rate  # latest OPR decision
```

Then run the full pull and review:

```sh
econquest fetch --only weo,worldbank,bis,imf,cb      # review.csv: cb cells held 'unverified' until the file says yes
python -m econquest.ingestion.official.central_banks template --out /tmp/cb_template.csv   # fresh rows if codes changed
```

Once a series is verified, precedence lets it replace the other feeds' values. `cb_cross` then holds any cell where
the national value and the replaced one differ beyond tolerance. Decide those in `review.csv` as usual.

**Only after a full verified pull:** move `cb` into the default fetch (add it to `FEED_ALIASES` in `feeds.py`), and
update the `fetch --only` help (Team C, `cli.py`).

## 6. Licence and terms (all unverified)

Each raw row carries the institution's licence note: BCB open data with attribution; Banxico SIE terms; BCRA public
API; BoK ECOS Open API; BCCh BDE registered use; BCRPData; BNM Open API. None of these terms has been checked. Before
any national value goes into client output, confirm the terms on each site and record them in the registry
(`licence`). Recommendation (not yet decided by Sam): until then, treat national values like IMF data, internal
research only.
