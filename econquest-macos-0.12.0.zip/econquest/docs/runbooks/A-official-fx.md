# Runbook: official FX feeds, and the series Yahoo leaves behind

> **Mac pull pack (EQ-A-0048):** this pull is step 1 (`fx`) of `python -m econquest.ingestion.pullpack run`, which runs every Mac-only pull in order, resumably, with disk checks and one report to send back: see `docs/runbooks/A-mac-pull-pack.md`. This page stays the reference for the step.

Ticket EQ-A-0040. Owner: Team A, AGENT-06. Operator: Sam. Written 2026-10-24 from
`econquest/ingestion/feeds.py` and `econquest/ingestion/market/forwards.py`. **This runbook was written
offline: the cloud cannot reach `stats.bis.org` or `data-api.ecb.europa.eu`, so every series key below is
marked UNVERIFIED until the first pull on the Mac confirms it.**

## Sam's decision (2026-10-23 23:16Z)

Asked "Allow Yahoo Finance prices in desk numbers?", Sam chose **Replace with free official**: Yahoo's
terms allow personal, non-commercial use only, so Team A swapped FX to BIS / ECB reference rates and
accepted the loss of some daily price history.

## What changed

| Before (Yahoo) | Now |
|---|---|
| `fetch` feed `yahoo` (yfinance): daily FX closes and country ETF closes | Feeds `bis_xru` (BIS daily exchange rates) and `ecb_exr` (ECB euro reference rates) |
| Country Profile `fx3m` from `<CCY>=X` closes | Same definition and sign convention, from the official daily series |
| Country Profile `equity_vol` from country ETFs | **Unserved**: "no official free source (Yahoo removed, Sam 2026-10-23)" |
| `forwards.py --spot yahoo` | `--spot bis` (default), `--spot ecb`, `--spot snapshot`; `--spot yahoo` refused |
| `fetch --only yahoo` | Refused with an error before any request (`feeds.YAHOO_REFUSED`) |

`fetch --only fx` pulls just the two FX feeds; `--only bis` pulls `bis`, `bis_cbs` and `bis_xru`.

## The series (UNVERIFIED until the first Mac pull)

**BIS daily exchange rates**, dataflow `WS_XRU`, key `D.<REF_AREA>.<CURRENCY>.A`
(`feeds.XRU_FLOW`, `XRU_KEY`), values in units of the currency per US dollar, pulled for the last
`XRU_DAYS` (400) calendar days and written to `data/live/raw_bis_xru.csv` before any transform.
Unverified: the frequency code `D`, the collection code `A`, the per-USD unit, and the euro-area
reference area `XM` (`feeds.EURO_AREA_BIS`). The reference area of a currency only one country uses is
that country's `bis_iso2` (else `iso2`); the shared currencies are in `feeds.SHARED_FX_AREA`
(EUR → `XM`, XOF → `SN`, XAF → `CM`, the last two also unverified).

**ECB euro foreign exchange reference rates**, dataflow `EXR`, key `D.<CCY>.EUR.SP00.A`
(`feeds.EXR_FLOW`, `EXR_KEY`), units of the currency per euro, written to `data/live/raw_ecb_exr.csv`
as delivered. Unverified: the type code `SP00`, the suffix `A`, and the per-EUR unit. Per-USD rates are
derived with the **same date's** EUR/USD reference rate (`feeds.ecb_per_usd`):

```
CCY per USD = (CCY per EUR) / (USD per EUR)          EUR per USD = 1 / (USD per EUR)
```

A date with no EUR/USD rate produces no row: no rate is ever carried over from another date.

**Which source serves a country.** BIS first; the ECB when BIS has no series for that currency. The two
are never mixed in one number, and the provenance row names the one actually used. Countries sharing a
currency (EUR, XOF, XAF) all get the same series, as they did under Yahoo.

**Cross-check.** `quality_gate` compares, per currency, the BIS rate with the ECB rate converted through
EUR/USD on the latest date both quote (`feeds.fx_cross_checks`, tolerance `FX_CROSS_TOL` = 1%). Above the
tolerance every `fx3m` cell of that currency is held with the reason `fx cross: ...`.

**No fx3m at all** (unserved, with the reason, in `data/live/unserved.csv` and as a `missing` row in
`review.csv`): dollarised countries, ZWL/ZWG (`feeds.NO_FX_QUOTE`), and any currency neither source
quotes.

## First pull on the Mac: what to check

```bash
cd ~/econquest
econquest fetch --only fx                 # no --apply on the first run
```

1. `Feeds: ... bis_xru: ok (...); ecb_exr: ok (...)`. If `bis_xru` says
   `BIS WS_XRU returned no exchange rate`, the key is wrong: open
   `https://stats.bis.org/api/v1/data/WS_XRU/D.BR.BRL.A/all?format=csv&lastNObservations=1` in a browser,
   note the dimension names and codes of the daily US-dollar series, and send them to Team A
   (`feeds.XRU_KEY`, `XRU_COLLECTION`, `EURO_AREA_BIS`, `SHARED_FX_AREA`). Do not edit the file by hand.
2. `data/live/raw_bis_xru.csv` and `data/live/raw_ecb_exr.csv` exist, with a `sdmx_key` column naming the
   series each row came from, and are copied into the new vintage folder.
3. `data/live/feed_failures.csv` lists every currency neither source served
   (`WS_XRU: no series for ...`).
4. Spot-check one rate against the central bank's own page (for example BRL/USD) before applying: the
   number should be the same to within a rounding step. If BIS and the ECB disagree by more than 1%, the
   gate already held the cell; send Team A the two numbers.
5. `fx3m` in `data/live/live_profile.csv` should be close to the last Yahoo-era value in
   `data/live/vintages/2026-10-23*/live_profile.csv` for the same country (reference rates and retail
   quotes differ by a fraction of a percent, not by points).

## Yahoo values still applied: the first official pull must clear them (SEC-A-006 M1, EQ-A-0045)

The `fetch --apply` of 2026-10-23 (before EQ-A-0040) wrote **17 Yahoo-derived `fx3m` cells** into
`data/countries.csv` (Vietnam, Philippines, China, Malaysia, Singapore, Japan, South Korea, India, Pakistan,
Belize, Brazil, Argentina, Colombia, Venezuela, Nigeria, Senegal, Zambia). The engine reads them
(layer 2 and layer 3). They are **not** edited by hand in the cloud copy: Sam's Mac data is authoritative,
and the replacement is the official pull below.

Check which applied cells still come from Yahoo or from a non-commercial / personal licence:

```bash
python -m econquest.ingestion.audit restricted        # "0 restricted-source cells" and exit 0 when clean
```

It lists every cell in `indicators.csv` / `countries.csv` whose value matches a value that the current
`data/live/provenance.csv`, any `data/live/vintages/*/provenance.csv` or `data/audit_trail.csv` attributes
to Yahoo / yfinance or a non-commercial licence (`audit.restricted_source_cells`), so a value is still
found after the next pull replaced `provenance.csv`. Today, on the 2026-10-23 data, it lists the 17 cells
above and exits 1.

**First PI-5 Mac task**, after the first-pull checks above:

```bash
econquest fetch --only fx --apply
python -m econquest.ingestion.audit restricted        # must print 0 restricted-source cells
econquest audit                                       # rewrites data/audit_trail.csv
grep -ci yfinance data/audit_trail.csv                # 0 once the audit trail is rewritten
```

While any restricted cell is left, `fetch --apply` (and `review apply`) prints a block of `!` lines
with `WARNING (SEC-A-006 M1): N applied cell(s) still hold values from a restricted source`, the cells,
and the commands above; the apply's result also carries `restricted_source_cells: N`. A cell can stay
because the official pull did not serve its currency, or because the gate held the new value (the
change from the Yahoo value was too large): review and apply it (`A-daily-record.md`), or send the list
to Team A. `econquest run` and `publish` warning on these cells, and `publish --write` refusing them,
are Team C's part (HO to C/AGENT-01 under EQ-A-0045, the same pattern as the attestation gate).

The validator data room never carries these values: it blanks every Yahoo-derived value in its copies
(`A-data-room.md`, SEC-A-006 M2).

## Series with no official free substitute

**Country Profile `equity_vol`** (annualised SD of country-ETF daily log returns, 60 trading days) was
the only Yahoo-only series in the desk pull. It is now left unserved for every country with the reason
`no official free source (Yahoo removed, Sam 2026-10-23)` and appears as a `missing` row in the gate
review and in the audit trail. It is **not** estimated, substituted or carried over.

**What loses an input.** Nothing in the engine. `equity_vol` was never written into `data/countries.csv`
(the file has no such column) and no engine reads the Country Profile `equity_vol`: the Monte Carlo's
`market.equity_vol` is the governed assumption in `data/assumptions.json` (Team B, EQ-B-0047), a
different number. The live `equity_vol` was a reported figure only — the dashboard Country Profile and
the audit trail. From this pull on, that figure is blank with a reason instead of being filled.

**`data/market_history/prices.csv`** was found under EQ-A-0040 to come from the workbook's **Market
History tab, which uses `GOOGLEFINANCE()`**, exported with `econquest prices --sheet-json ...`. Sam
decided on 2026-10-24 that it is rebuilt from official FX only: see the next section.

### Options for `equity_vol`, for Sam to choose

1. **The GOOGLEFINANCE workbook route.** *Ruled out by Sam's 2026-10-24 decision (next section).* Add the
   country ETFs' 60-day realised volatility to the Market History tab, export it with
   `econquest prices`, and compute `equity_vol` from `prices.csv` the way the GARCH module already does
   (`engine/garch.py` `market_vol`, kind `Equity`). Team A estimate: small, one ticket. It keeps the
   number inside the same source the models already use, and it removes the last reason to call Yahoo.
2. **Central-bank or exchange equity indices.** Several central banks and statistics offices publish a
   national equity index (and the ECB publishes euro-area indices) under the same free-reuse terms as the
   rates feeds. Coverage is partial, the index is not the ETF the desk holds, and currency exposure
   differs; it would be a different series, not a drop-in replacement. Medium effort, per-country mapping.
3. **A vendor licence.** Bloomberg or LSEG through the EQ-A-0033 adapter framework (off by default,
   behind the licence gate). Full coverage and dealable prices; paid, and needs Sam's licence decision.

Until Sam picks one, the cell stays blank with its reason. Nothing substitutes for it.

## Daily FX history: `data/market_history/prices.csv` (EQ-A-0054)

**Sam's decision (2026-10-24 12:31Z).** Asked "Keep using Google Finance prices for the volatility and
correlation models?", Sam chose **Rebuild from official FX only**. Google's terms for `GOOGLEFINANCE` say
the data is not for trading or professional use and that historical data is not to be accessed via the
Sheets API, which is how `econquest prices --sheet-json` fed `prices.csv`. The FX history is rebuilt from
BIS / ECB daily rates; the country ETF columns are dropped, so the equity factors in GARCH, the copula, the
HMM and econometrics fall back to judgement (Team B decides how, handoff under EQ-A-0054).

**What the build writes** (`econquest/ingestion/market_history.py`):

| Path | What | Mode |
|---|---|---|
| `data/market_history/vintages/<YYYY-MM-DD>T<HHMMSS>Z-<hash8>/` | raw pulls as delivered, written **first**: `raw_bis_xru_history.csv`, `raw_ecb_exr_history.csv`, `request.json` (range, areas, failures); row in `vintages/index.csv` | append-only, 0444 |
| `data/market_history/builds/<vintage_id>/` | `prices.csv`, `prices.provenance.json`, `disagreements.csv`, built from the vintage files read back from disk | 0444, never overwritten |
| `data/market_history/prices.csv` + `prices.provenance.json` | the installed build (only with `--apply` / `apply`) | replaced atomically |
| `data/market_history/archive/<name>-googlefinance-<date>.csv` + `.licence.json` | the GOOGLEFINANCE-era files, restricted licence, audit only | 0444 |

- **Columns and convention unchanged for FX**: `date, USDVND, USDPHP, USDCNY, USDMYR, USDSGD, USDJPY,
  USDKRW, USDINR, USDPKR, USDBZD, USDBRL, USDARS, USDCOP, USDVES, USDNGN, USDXOF, USDZMW`, units of the
  currency per 1 USD. The ETF columns `VNM, EPHE, MCHI, EWM, EWS, EWJ, EWY, INDA, EWZ, ARGT, GXG, EEM` are
  gone, and so is `inda.csv` (moved to the archive at apply, because `garch.load_prices` merges every
  top-level `market_history/*.csv`).
- **One source per column**: BIS WS_XRU when it serves the currency, else the ECB reference rate converted
  through the same date's EUR/USD. The sidecar names, per column, the source, the SDMX series key, the
  retrieval time (UTC), the licence tag (`forwards.BIS_SPOT_LICENCE` / `ECB_SPOT_LICENCE`), the count and
  first/last date, and the sha256 of `prices.csv`.
- **No forward fill, no carry-over.** A date a source did not publish is empty in `prices.csv`.
- **BIS vs ECB**: every date both publish is compared; more than 1% apart (`FX_HISTORY_TOL`) goes to
  `disagreements.csv` (check `bis_vs_ecb`) and the column's `cross_check` in the sidecar. Reported, not
  resolved: `prices.csv` keeps the BIS value. Send Team A the file if it has rows.
- **Administered and pegged rates kept as published, with a note** in the sidecar: USDARS, USDVES (official
  rates, parallel rates not used), USDNGN, USDPKR (managed), USDXOF (fixed at 655.957 XOF per EUR; checked
  against 655.957 x ECB EUR per USD, check `peg`), USDBZD (2.00 per USD; checked against the parity).
- **USDBZD**: UNVERIFIED whether BIS WS_XRU serves Belize (`D.BZ.BZD.A`); the ECB does not publish BZD. If
  BIS returns nothing, the column comes from theratesapi.com (EQ-A-0073, section below), else stays empty with
  the reason in the sidecar (`unserved`). The BZD parity is never written as data.
- **Fails loudly**: an unreachable host (proxy, DNS) or a BIS pull with no rows stops before anything is
  written. An ECB failure is recorded (`failures` in the sidecar); the ECB-only columns are then empty.

**On the Mac** (the cloud cannot reach BIS or the ECB). Also step 1b of the pull pack
(`python -m econquest.ingestion.pullpack run`, which stages only).

```bash
cd ~/econquest
python -m econquest.ingestion.market_history build --start 2023-10-18      # stages; prices.csv unchanged
#  -> prints the vintage id, dates, served columns (16 or 17 of 17), empty columns, disagreement rows
python -m econquest.ingestion.market_history restricted                     # lists prices.csv and inda.csv (GOOGLEFINANCE) until applied
# After Team B accepts the contract change (handoff under EQ-A-0054):
python -m econquest.ingestion.market_history apply                          # latest vintage; archives prices.csv and inda.csv
python -m econquest.ingestion.market_history restricted                     # must print 0 ... and exit 0
```

Check before `apply`: `builds/<id>/disagreements.csv` (empty, or rows explained), `unserved` in
`builds/<id>/prices.provenance.json` (USDBZD expected if BIS has no Belize series), and one rate against
the central bank's own page. If BIS returns nothing at all, the WS_XRU key is wrong: see "First pull on
the Mac" above.

**GOOGLEFINANCE import retired.** `update_prices_from_sheet_json` (behind `econquest prices --sheet-json`)
refuses with `GoogleFinanceRefused` unless `ECONQUEST_ALLOW_GOOGLEFINANCE=1` is set, and even then writes
only `data/market_history/research/prices-googlefinance-research.csv` with a restricted `.licence.json`,
never `prices.csv`. The command and its daily schedule entry are Team C's (`cli.py`, `ops/schedule.py`);
retiring them is a handoff to C/AGENT-01 under EQ-A-0054. Until it lands, the scheduled `prices` job fails
with the refusal message every day: that is intended.

**Archive.** `data/market_history/archive/prices-googlefinance-2026-10-24.csv` (sha256
`e568019e…7176ae`, the live file of 2026-10-24 12:43Z after the EQ-A-0056 INDA repair; see `archive/README.md`) is kept for audit only. The engine never reads it
(`load_prices` reads top-level `*.csv` only; `replay` skips `archive/`, `vintages/`, `builds/`,
`research/`), and the data room withholds it, its licence file, and any `market_history` CSV with an ETF
column, including frozen replay copies (`dataroom.restricted_reason`, `market_history.market_restricted_reason`).

## theratesapi.com: VES, NGN, PKR, VND, ZMW (EQ-A-0073, EXC-005)

**Sam's decisions (2026-10-24).** 20:32Z: take fx3m for VES, NGN, PKR, VND and ZMW from Banca d'Italia's daily
rates, which BIS and the ECB do not publish. 20:33Z: **internal research only**, logged as governance exception
**EXC-005** (`docs/governance/issues-log.md`), the same treatment as the IMF (EXC-003). 20:37Z: read them through
**theratesapi.com** instead of Banca d'Italia's own API.

**What theratesapi.com is** (its homepage, read 2026-10-24): a free, keyless JSON mirror of the ECB euro reference
rates (29 currencies) and Banca d'Italia's daily rates against the euro (121 more), ECB first where both publish.
A rate against any other base, USD included, is **computed by the mirror** from the per-EUR figures and rounded to
6 decimals: `CCY per USD = (Banca d'Italia CCY per EUR) / (USD per EUR)`. Banca d'Italia calls its rates
indicative, and its copyright page allows personal, non-profit use only; theratesapi.com's terms page says the
service is "as is", information only, and states no licence. Hence EXC-005 and the client-output restriction.

**Endpoint** (`econquest/ingestion/official/theratesapi.py`, feed `theratesapi_fx`, host `theratesapi.com`):

```
GET https://theratesapi.com/api/{YYYY-MM-DD|latest}?base=USD&symbols=VES,NGN,PKR,VND,ZMW
-> {"date": "2026-10-23", "base": "USD", "rates": {"VES": 885.1193, "NGN": 1344.4, ...}}
```

One request per business date for all five currencies (`THERATES_DAYS` = 110 calendar days, about 78 weekdays:
fx3m needs more than 70 observations and one at least 91 days back). A weekend or holiday answers with the
previous working day; rows are kept once per returned `date`. https only, this host only, redirects refused,
body capped, retries on 429/5xx, fail-fast on a proxy or DNS failure, at most 4 requests a second on every path
(SEC-A-009 L2). A bad answer (not UTF-8, not JSON, absurd number) costs only its date, and a failure of this feed
never discards the BIS/ECB results of the same pull (SEC-A-009 M1); 10 failed dates in a row (5xx, transport,
refused answers) end the feed. Answer bodies in the CSV files have formula prefixes neutralised (SEC-A-009 L3).
The history cache stores an answer dated before the requested date only once that date is more than 7 days old,
so a rate not yet published today is asked for again on the next build (SEC-A-009 L1).

**Checks.** An answer whose `base` is not USD is refused (never inverted); so is a `date` after the date asked
or more than 7 days before it, and a rate that is not a positive number. A currency missing from an answer has
no row that day: nothing is forward-filled. fx3m is refused with a reason when the series is too short, or when
the latest rate is unchanged over the last 10 observations (a carried-forward rate would look like that).

**Order in the official FX chain.** BIS WS_XRU, then ECB EXR via EUR/USD, then the hard-peg parity (EQ-A-0071),
**then theratesapi.com**, then an attested row of `data/fx_manual.csv` (EQ-A-0072). The price history keeps the
same order without the last step; there is one test per step in `tests/test_market_history_holds.py` (EQ-A-0077). A currency BIS or the ECB
serves never uses the mirror. Configured in `theratesapi.THERATES_CURRENCIES` (exactly the five above).

**Licence and audit.** Every raw row carries `THERATES_LICENCE` ("theratesapi.com mirror of Banca d'Italia
rates: internal research use only (EXC-005; client output restricted; mirror terms unverified)"); the source
string is "theratesapi.com (mirror of Banca d'Italia/ECB reference rates)".

- `python -m econquest.ingestion.audit client` lists these cells (reason names EXC-005): they stay out of client
  output.
- `python -m econquest.ingestion.audit restricted` does **not** list them: the licence carries no "personal"
  or "non-commercial" term, so they are allowed in desk numbers, as the IMF values are.
- Data room (Sam 2026-10-24 22:20Z, SEC-A-009 M2): the rates themselves (the `prices.csv` columns and the fx3m
  cells) go to the validator under NDA, as IMF data does (README line in the room); the raw answers
  (`raw_theratesapi*` files) and the answer cache are withheld (`market_history.market_restricted_reason`).

**Files.** `data/live/raw_theratesapi_fx.csv` (rows used, with the request date and the sha256 of the answer)
and `data/live/raw_theratesapi_fx_responses.csv` (every answer body as received), both copied into the vintage.

**On the Mac.**

```bash
cd ~/econquest
python -m econquest.ingestion.official.theratesapi --probe     # one GET of /api/latest
```

It prints the URL, the raw answer (size, sha256, text), `date ..., base USD`, and one line per currency, e.g.
`VES: 885.1193 per USD`, or `MISSING from the answer`. Exit 0 = all five there, 2 = some missing, 1 = the
request failed or the answer was refused (wrong base, bad date). Send Team A the output. Then:

```bash
econquest fetch --only fx                  # Feeds: ... theratesapi_fx: ok (N rows)
#   or the pull pack, step 1 (fx), which runs the same feeds
```

Check: the provenance rows of Venezuela, Nigeria, Pakistan, Vietnam and Zambia name theratesapi.com, with the
series `theratesapi.com /api/<date>?base=USD&symbols=<CCY> ...`; `data/live/unserved.csv` gives the reason for
any of the five left empty (too few observations, unchanged rate, no rate). Compare one rate with the probe and
with the central bank's own page.

**How to check the result.** After `econquest fetch --only fx --apply` (and once Sam has released the Malaysia
and Colombia holds and the pegs of EQ-A-0071 have landed), `python -m econquest.ingestion.audit restricted` must
print `0 restricted-source cells` and exit 0. `audit client` still lists the theratesapi.com cells: expected.

**Daily history for `prices.csv`.** `market_history build` fills, for columns BIS and the ECB leave empty, XOF
from the parity x ECB EUR per USD and the rest (USDVND, USDPKR, USDBZD, USDVES, USDNGN, USDZMW when empty) from
theratesapi.com: about 750 requests for three years at 4 a second, cached under
`data/market_history/.cache/theratesapi/` so a stopped pull resumes on the next `build`. The vintage keeps
`raw_theratesapi_history.csv` and `raw_theratesapi_responses.csv`; the sidecar names source, licence and
`exception: EXC-005` per column and lists them under `exceptions`. `--no-theratesapi` turns it off.

### Price-history holds for the theratesapi.com columns (EQ-A-0077)

Applies to every vintage saved by `market_history build` from EQ-A-0077 on (`request.json` has
`"checks": "EQ-A-0077"`). A vintage saved before that, including Sam's applied 2026-10-25T000005Z-d1f504f1, still
rebuilds byte for byte as before; `market_history review` (below) shows what the checks say about it.

| Check | Scope | Rule | Effect |
|---|---|---|---|
| Daily cross-check | every theratesapi.com rate in the vintage | on each date BIS or the ECB also quote the currency, more than 1% apart (`FX_HISTORY_TOL`) | row in `disagreements.csv`, check `theratesapi_vs_bis` / `theratesapi_vs_ecb`; reported, not resolved (BIS / ECB rank higher) |
| Peg | `USDBZD` (`PEG_HOLD_COLUMNS`) | any date off 2.00 by more than 1% (`peg_check`) | **hold** (whole column) |
| Staleness | columns filled from theratesapi.com | last observation more than 7 business days (Mon-Fri, no holiday calendar) before the build end | **hold** (whole column) |
| Outlier | columns filled from theratesapi.com | one-day move between consecutive observations above the currency's threshold | **hold** (that date); the value is never changed |

So that the cross-check has something to compare, the mirror is asked for all six (VND, PKR, BZD, VES, NGN, ZMW)
whenever it is called, which costs no extra request. A currency BIS or the ECB serves is then compared with the
mirror, and the mirror value is never used as data.

Staleness and outliers are checked on the mirror columns only. BIS WS_XRU is published weekly with a lag: on the
2026-10-25 build USDARS ended 2026-10-14, 7 business days before the build end, exactly at the limit (held only
above 7). A BIS lag of one more day would hold an official build for no fault of the data, so the rule is not
applied to them. The BIS-vs-ECB cross-check covers the official columns.

**Outlier thresholds** (`market_history.OUTLIER_THRESHOLDS`, the settings table; the default
`OUTLIER_DEFAULT` is 15%):

| Currency | Threshold | Why |
|---|---|---|
| VND | 5% | managed: the State Bank of Vietnam band is +-5% around its central rate |
| BZD | 1% | hard peg; the peg check holds as well |
| NGN, VES | 15% (not raised) | managed or administered, with regime jumps. NGN rose about 34% on 2024-01-31 and that move is real. The threshold stays at 15% so a jump is flagged and released by review, never passed silently and never dropped |
| PKR, ZMW | 15% (default) | |

Change a value only with a line here saying why.

**What "held" means (chosen: refuse to stage).** A build with an open hold is not written to `builds/<id>/`, and
`prices.csv` is untouched. The raw vintage is already saved. The build raises `FxHistoryHeld`, the pull pack marks
step 1b `held` with one line per hold, and the review is written to
`data/market_history/reviews/<vintage_id>/fx_review.csv` and `holds.json`. That folder is mutable review state:
it is not an engine input, replay skips it, and the data room withholds it. There are two ways past a hold:

- **Outlier date: release it** the same way quality-gate holds are released. Each release writes a ledger `apply`
  row to `data/live/review_ledger.csv` on (`market_history.prices`, column, date). It needs four eyes (`--approver`)
  or a flagged self-approval, and it is bound to the flagged value. The value stays as published.
- **Any hold: drop the column with a reason.** Each drop writes a ledger `reject` row on (`market_history.prices`,
  column, `(column)`) with the reason as its note. The next stage empties the column, lists it under `unserved`,
  writes the reason into `series.<col>.dropped` and `series.<col>.reason`, and removes the column from the EXC-005
  list. It is the only way past a stale or peg hold. A drop acts only while the column is held. The ledger row
  stays, so if a later vintage holds the column again the same drop applies, but a later vintage whose column passes
  every check keeps the column. To stop a standing drop from applying again, record an approved `apply` on the same
  cell (EQ-A-0090).

```bash
python -m econquest.ingestion.market_history build                 # exit 3 "HELD: ..." when a hold is open
cat data/market_history/reviews/<vintage_id>/fx_review.csv
python -m econquest.ingestion.market_history release --column USDNGN --date 2024-01-31 --author Sam --self-approved \
    --note "NGN unification; checked against the CBN page"
python -m econquest.ingestion.market_history drop --column USDVES --author Sam --reason "mirror stopped publishing VES"
python -m econquest.ingestion.market_history stage --vintage <vintage_id>   # builds from the saved vintage
python -m econquest.ingestion.market_history apply --vintage <vintage_id>
python -m econquest.ingestion.market_history review --build data/market_history   # read only; exit 1 while a hold is open
```

The staged build carries `fx_review.csv` (each hold and how it ended: released or dropped, and by whom) and
`review` in the sidecar (policy, released dates, dropped columns, and the ledger rows used). `apply` first checks
that every recorded row is still in `data/live/review_ledger.csv` (append-only) and refuses if one is missing
(EQ-A-0090). `apply` and a repeat `stage` rebuild with the recorded rows, so a later ledger change never makes an existing build look tampered. A
fresh `review` reads the ledger as it is now.

**Run on Sam's applied build** (`review --build data/market_history`, offline, 2026-10-25). USDNGN shows 6 outlier
dates at 15%: 2023-10-31 +15.6%, 2023-12-04 +15.7%, 2023-12-06 +16.6%, 2023-12-13 -15.7%, 2024-01-31 +34.1% and
2024-05-31 +23.2%. Nothing is flagged for VND, PKR, BZD (flat at 2.00), VES (largest move 3.6%) or ZMW (largest
7.1%), and none of the six columns is stale (last 2026-10-23). The December 2023 moves go up and back down within
days, which may be the mirror alternating between two published NGN rates. Sam should check them against the
CBN page before releasing them. The installed build is not changed by this.

**Landing check** (`python -m econquest.ingestion.landing`, step fx_history). On top of the hash and vintage checks,
it now requires:

- every column has values, unless the sidecar lists it unserved with a reason;
- every column filled from theratesapi.com carries `exception: EXC-005` and is listed under `exceptions.EXC-005`;
- `disagreements.rows` is 0, or `disagreements.csv` next to the sidecar has that many rows and
  `disagreements.columns` names them;
- for an EQ-A-0077 build, `review.open` is 0.

Sam's applied build passes all of these.

**Source code** (https://github.com/apiforfun/theratesapi, MIT; read by AGENT-08 on 2026-10-24, except
`controller/api.js`): only `/api/latest` and `/api/:date` exist (no range endpoint, hence one request per business
date); rates are stored per (date, currency, rate, source) from the ECB eurofxref files and Banca d'Italia
`dailyRates` against EUR, ECB first; Banca d'Italia is pulled on weekdays only, and a day with fewer than 100 rates
is treated as unpublished (on holidays it publishes a lone XDR rate). No rate limit in the code; the adapter
throttles anyway. A non-200 answer, an answer that fails a check, or a currency missing from an answer gives no
value for that date (recorded in `feed_failures.csv`), never a filled one. The MIT licence covers the code only; no
data terms are stated, so EXC-005 and its tag stand.

**Fallback option only (not built):** the mirror can be self-hosted (Express + PostgreSQL) from that repository if
the public service goes away. That would need its own ticket and Sam's decision; nothing here depends on it.

UNVERIFIED until the first Mac pull: that the five currencies are present on most business days, what the service
answers for a weekend or an unknown date (the README says the previous working day; the history pull asks for
weekdays only and dedupes on the returned `date`), and whether the mirror ever repeats an old rate on a day Banca
d'Italia published none.

## Yahoo after EQ-A-0040

`feeds.YahooFeed`, `fx_tickers` and `yahoo_transforms` stay in the code for research that is not
published and not part of a run; nothing in the pipeline calls them. `fetch` refuses `--only yahoo`.
`forwards.py --spot yahoo` is refused unless `ECONQUEST_ALLOW_YAHOO=1` is set in the environment, and the
rows it then produces carry `YAHOO_LICENCE` ("personal non-commercial use"), which the market gate now
holds (`gate.DESK_BARRED_LICENCE_TERMS`), so they cannot reach a desk number or a publish.
