# Event calendar (EQ-A-0132)

Module `econquest/ingestion/calendar/`, store `data/calendar/events.csv`. Elections, IMF programmes and reviews,
Eurobond maturities and amortisation, aggregate external debt service, and sovereign rating review dates for the
desk names. The calendar feeds Team C's GUI alerts and morning view (EQ-C-0155) and Team B (EQ-B-0135). It does not
feed the model.

## 1. Store and schema

- `data/calendar/events.csv` is append-only and written only by `calendar.store.record_events`. It holds one row per
  revision of an event. The columns are in `calendar.schema.EVENT_COLUMNS` (docstring).
- **Point in time.** `recorded_utc` is when econquest stored the revision. An as-of view sees only revisions recorded
  by then, taking the highest revision per `event_id`. A correction or cancellation is a new revision; old rows are
  never edited.
- **Idempotent.** Re-running an adapter on the same file writes nothing.
- **Tamper checks.** A row edited after storage (its `content_sha256` differs) is reported by `demo_calendar_data` and
  left out of every query.
- **No synthetic data.** Rows with `synthetic=true` are refused for the repo's `data/` (including `data/mvp`). Tests
  use tmp folders.
- **Stable keys (ARCH-A-PI13 F-1).** An event's key is its body or agency plus its cycle (the year), never its date.
  A date that moves becomes a new revision of the same event. Rating reviews are numbered within the year
  (`<agency>/<year>-1`, `-2`, ...). Several elections for one body in a year take `-2`, `-3` and so on, by date.
- **Withdrawals.** A drop pull writes a `withdrawn` revision for any event of that source missing from its new file.
  The event leaves default views and alerts; earlier as-of views still show it.
- **Not frozen.** `data/calendar/drop/` (raw publisher files) is excluded from data/mvp (EQ-A-0130).

## 2. Sources

| source_id | kind | file | licence row | state |
|---|---|---|---|---|
| worldbank_ids | external_debt_service | a Mac pull's `raw_worldbank.csv` (series DT.TDS.DPPG.CD, World counterpart) | worldbank_ids (CC BY 4.0) | **real**: 78 events from `team/inbox/pull-20261025T013150Z/raw_worldbank.csv` (sha256 d700f70f...) |
| electionguide | election | `data/calendar/drop/electionguide/<one csv>` with columns Country, Election For, Date, Status | calendar_electionguide | empty, layout UNVERIFIED |
| imf_mona | imf_review | `data/calendar/drop/imf_mona/<one csv>` with columns Arrangement Number, Country Name, Arrangement Type, Review Sequence, Original Schedule Date [, Board Action Date, Review Type] | calendar_imf_programmes (EXC-003) | empty, layout UNVERIFIED |
| rating_calendar | rating_review | `data/calendar/drop/rating_calendar/<one csv>` with columns Agency, Country, Date, Source URL (transcribed from the agencies' EU CRA Regulation calendars) | calendar_rating_agencies | empty, layout UNVERIFIED |
| prospectus | eurobond_maturity, eurobond_amortisation | hand entry only: `adapters.eurobond_rows` then `manual.enter_events` | calendar_prospectus | empty |
| national_electoral, imf_country_page | election, imf_programme | hand entry only | calendar_national_electoral, calendar_imf_programmes | empty |

The IDS events are **aggregate annual external PPG debt service, not bond-level**. They are projections on debt
outstanding at the reference date, so new borrowing is not included. Values are stored exactly as published. The
adapter only selects the World-counterpart rows: a country with more than one row per year and no counterpart column
is skipped, not summed.

Fixtures under `tests/fixtures/calendar/` are SYNTHETIC: invented rows in each layout. A leading `# ... SYNTHETIC`
comment line marks a file, and its rows carry `synthetic=true`.

## 3. Commands (zsh-safe, from the econquest folder)

```
python -m econquest.ingestion.calendar demo                       # M18 data check: ok, problems, counts
python -m econquest.ingestion.calendar drop electionguide         # parse the one drop file and record its events
python -m econquest.ingestion.calendar drop imf_mona
python -m econquest.ingestion.calendar drop rating_calendar
python -m econquest.ingestion.calendar ids --raw "PULL/raw_worldbank.csv" --pull "PULL" --retrieved "YYYY-MM-DDTHH:MM:SSZ"
```

## 4. Hand entry

`calendar.manual.enter_events(data_dir, rows, author, approver=None, self_approved=False, note="")` follows the
four-eyes rule (`ledger.check_approval`). Every row cites its source (`source_url` https, or `document`) and carries
`retrieved_utc`. Each written revision is attested in the review ledger: table `calendar_manual`, key
`<event_id>|<revision>`. `manual.unattested_manual` lists manual rows that are not attested or were edited after entry;
queries leave those rows out.

## 5. Query interface (stable; a change needs a handoff to Teams B and C)

```
from econquest.ingestion import calendar
calendar.events(data_dir=None, country=None, kinds=None, start=None, end=None, as_of=None, min_importance=None,
                include_hidden=False, include_unattested=False)  # DataFrame, columns calendar.QUERY_COLUMNS
calendar.upcoming(days, today=None, data_dir=None, country=None, kinds=None, min_importance=2, as_of=None)
                                                                 # alert rows: ALERT_FIELDS + event_id + days_until
calendar.demo_calendar_data(data_dir=None)                       # {"ok", "problems", "summary", "counts"} (M18)
```

- `country` takes ISO3 or a countries.csv name, alone or in a list. `kinds` takes any of `calendar.KINDS`.
- An event matches the window when its period (date..date_end) overlaps it.
- Held, cancelled and withdrawn events are hidden unless asked for.
- Alerts use these fields: date, date_end, precision, iso3, kind, importance (1-3), status, title, source_id,
  source_url, licence_id and client_output, which comes from the licences.csv row named by licence_id.
- Default importance by kind: election 3, imf_programme 3, eurobond_maturity 3, imf_review 2, eurobond_amortisation 2,
  rating_review 2, external_debt_service 1. `upcoming` alerts at importance >= 2 by default, so the IDS annual rows
  do not alert unless `min_importance=1` is passed.
