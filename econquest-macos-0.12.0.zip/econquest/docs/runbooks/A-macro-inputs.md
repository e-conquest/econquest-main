# Macro inputs: BIS EER, Pink Sheet commodities, export-share terms of trade (EQ-A-0134)

Module: `econquest/ingestion/official/macro.py`. Tests: `tests/test_official_macro_a134.py`. Pull-pack step 8 `macro`.

These are research inputs only. They write no desk cell, no Inputs row, nothing to `data/indicators.csv` and
nothing to `data/mvp`. A cell needs a Team B level rule first, and Team B was asked for one under EQ-A-0134.

## Sources and status

| Input | Source | Key or layout | Status today |
|---|---|---|---|
| REER broad | BIS WS_EER `M.R.B.{iso2}` through `feeds.BisFeed` (the 2.12 series) | confirmed by recorded responses | **Live on recorded data**: 10 desk names from `data/live/vintages/*/raw_bis.csv` |
| NEER broad, REER narrow, NEER narrow | BIS WS_EER `M.N.B`, `M.R.N`, `M.N.N` | UNVERIFIED (from the BIS key layout) | Parked: pull-pack step 8. Values are held `unverified` until a Mac response confirms the keys. The narrow basket covers about 27 economies, so most desk names have no narrow series |
| Commodity prices and indices | World Bank Pink Sheet, `CMO-Historical-Data-Monthly.xlsx`, sheets "Monthly Prices" and "Monthly Indices" | UNVERIFIED (layout as remembered) | Parked: no file is on disk. Sam downloads it to `~/Downloads`. Held `unverified` until `CMO_VERIFIED` is set |
| Export shares | WDI `TX.VAL.{FUEL,FOOD,AGRI,MMTL,MANF}.ZS.UN` (UN Comtrade via WITS) | recorded | **Live on recorded data**: 18 desk names from `team/inbox/pull-20261025T013150Z/raw_worldbank.csv`, retrieved 2026-10-25T01:43:14Z. Venezuela ends in 2013 and is held `stale` |
| Terms-of-trade index | econquest: Pink Sheet group indices weighted by the export shares | method (Team B) | Weights are built for 18 names. The index waits for the Pink Sheet file and is always held `method` until Team B approves it |

IMF PCPS is not used: IMF data is internal only (EXC-003).

## Index method (for the Team B review)

`idx_t = 100 * exp( sum_g w_g * ln(P_g,t / mean(P_g, 2010)) )`. Here `w_g` is the share of group g in merchandise
exports, taken from the latest year that has all four groups:

- fuel maps to Energy;
- food maps to Food;
- agricultural raw materials map to Raw Materials;
- ores and metals map to Metals & Minerals.

The manufactures and other share is held at a constant price. Prices are nominal US dollars. There is no import side,
because no `TM.VAL` shares are on disk, and there is no deflator.

## Point in time and gate

- An input retrieved after the as-of time is never read. A date-only stamp counts as the end of that day. Periods
  that end after the as-of date are dropped.
- `macro_gate` reuses `official.gate`: `OFFICIAL_STALE_DAYS`, the period parsing in `gate._age`, and the World Bank
  3-year rule. It gives every value `ok` or `hold`. The checks are `unverified`, `range`, `stale`, `method` and `pit`.
  Each check row uses `crosscheck.CHECK_COLUMNS` with table `Macro`.

## Offline build (cloud, recorded data)

```
python -m econquest.ingestion.official.macro build --data data --as-of 2026-10-26 --out /tmp/macro
python -m econquest.ingestion.official.macro verify /tmp/macro/vintages/<id>
```

`--out` is required and refuses anything under `data/mvp`. On 2026-10-26 the build gave 4,470 values: 4,430 ok and
40 held (30 Venezuela share values that are stale, and 10 ARG EER values). The 10 ARG values were held only because
the first range bound was too tight. The bound is now 5 to 2000, and the 1999 value of 500 is recorded data.

## On Sam's Mac (pull-pack step 8)

1. Download `CMO-Historical-Data-Monthly.xlsx` from https://www.worldbank.org/en/research/commodity-markets
   ("Monthly prices") to `~/Downloads`.
2. Run `python -m econquest.ingestion.pullpack run --steps macro`. Add `--cmo-xlsx PATH` if the file is elsewhere,
   and `--cmo-retrieved 2026-..T..:..:..Z` to record the download time instead of the file's modification time.
3. BIS is optional. If BIS is unreachable the step is reported and still runs on the file. With neither BIS nor the
   file, the step is skipped and gives the download message. If the file has a layout the parser does not know, the
   step fails loudly. It never guesses.
4. The step writes `data/live/macro/vintages/<id>/` with values.csv, weights.csv, checks.csv and manifest.json, and
   adds a row to `index.csv`. Nothing is applied. The landing check re-verifies the vintage (`landing._v_macro`).
5. Send `manifest.json` and `checks.csv` to AGENT-08. AGENT-04 then reads the answers:
   - It sets `EER_VERIFIED` for each WS_EER key that answered.
   - It sets `CMO_VERIFIED` once the sheets parsed as documented. If the World Bank changed the layout, it fixes the
     parser instead.

## Licences

`data/licences.csv` has three tighten-only rows. All three are internal only, client restricted and withheld from the
validator room until the terms are read:

- `worldbank_cmo`, for the Pink Sheet;
- `macro_tot_derived`, for the index and weights (the TX.VAL shares have a UN Comtrade upstream);
- `macro_inputs`, for the whole `data/live/macro/` folder.

BIS EER values keep the existing `bis` row. Loosening any of these rows is Sam's decision.
