# Runbook: text corpus (central bank statements and IMF press releases)

Ticket EQ-A-0131 (Team A, AGENT-02). Operator for the live pull: Sam, on the Mac. Code: `econquest/ingestion/text/`.
Tests: `tests/test_text_corpus.py`, on SYNTHETIC fixtures in `tests/fixtures/text_corpus/`. Consumers: Team B
EQ-B-0135 (text stress index) and Team C EQ-C-0155 (GUI and morning view).

**Written offline.** This cloud cannot reach any central bank or the IMF. Every index URL, link pattern and page
layout in the registry is UNVERIFIED (`layout_verified=False`), and no real document exists until the first Mac pull.
The fixtures are synthetic and say so. No synthetic text ever goes into `data/`.

## 1. What it is

| Piece | Where | Rule |
|---|---|---|
| Sources | `text/registry.py` | 18 central banks, one per desk name (BCEAO for Senegal); IMF press releases (one feed, kept when the title or summary names a desk name); 18 IMF country pages. VNM, BLZ and VEN are `manual`: no listing feed is known, so nothing is requested (parked) |
| Transport | `text/fetch.py` | https only, no redirects, body capped at 5 MB. User agent `econquest-corpus/0.1 (...)`. At least 5 s between requests to one host (or the robots.txt Crawl-delay, up to 60 s). robots.txt is obeyed; if it cannot be read, the host is skipped. Only the source's own hosts are requested. Two retries on 429/5xx, then the host is dropped for the run |
| Parsers | `text/parse.py` | RSS 2.0, RSS 1.0/RDF and Atom (defusedxml); HTML listings (link + date in the same item); article text (container, else article/main/body; scripts, menus and footers are dropped). PDFs are listed and skipped |
| Store | `data/corpus/` (approved by A/AGENT-08, 2026-10-26) | `CORPUS.json`, `index.jsonl` (append-only, one row per document version), `text/<sha[:2]>/<sha256>.txt`, `pulls.jsonl` (one line per run). Not in `data_hash`. Kept out of `data/mvp` (mvp_dataset EXCLUDE_DIRS, EQ-A-0130) |
| Read interface | `text/corpus.py` | `documents(country, since, as_of, basis=...)`, `documents_frame`, `latest`, `coverage`, `available`. See section 5 |
| Licence | `data/licences.csv` rows `text_cb_<iso3>` (18), `text_imf`, `text_corpus_store` | Internal use yes, client output restricted, validator room UNVERIFIED, terms UNVERIFIED. Tighten-only defaults until Sam reads each publisher's terms |

Each stored document has: source, family, iso3s, URL, title, publication timestamp (UTC, with its precision),
retrieval timestamp (UTC), language, sha256 of the text, character count, licence row and licence tag, a synthetic
flag and a layout-verified flag.

**Point in time.** `as_of` never returns a document published after it. When a page gives only a date, the
document is stamped 23:59:59 in the publisher's time zone. A query earlier that day therefore does not see it. A
corrected text is added as a new version, and the old version is kept. With `basis="published"` (the default, for
backtests) a query returns the first version of each document. With `basis="knowledge"` it returns only what had
been retrieved by `as_of`, as the latest version at that time.

## 2. Before the first pull (Sam)

Nothing here is needed for any PI-13 ticket. The corpus is simply empty until then, and the interface returns
empty results.

1. Open a terminal in the econquest folder:

   ```
   cd ~/econquest
   ```

2. List the sources:

   ```
   python -m econquest.ingestion.text sources
   ```

## 3. Dry run: check the layouts (reads indexes only, stores nothing)

```
python -m econquest.ingestion.text pull --dry-run
```

The command prints one line per source: status, entries listed, entries in scope, and errors. Send the output to
AGENT-08. Team A then fixes each source that lists 0 entries or fails, such as a moved URL, a new layout, or a
robots.txt refusal. A source is marked `layout_verified=True` only after its dry run lists real entries, and an
article read gives clean text. Team A checks the article text on a one-source pull (step 4) before marking it.

One source at a time (keys from `sources`, comma-separated, no spaces):

```
python -m econquest.ingestion.text pull --dry-run --only "cb_ind,imf_press"
```

## 4. The live pull

A first, small pull of one source:

```
python -m econquest.ingestion.text pull --only "cb_ind" --since "2024-01-01" --max-docs 5
```

```
python -m econquest.ingestion.text verify
```

The full pull. At 5 s per request, 38 sources and 50 documents each, it runs for about 2 to 3 hours. It is safe to
stop with Ctrl-C and run again, because stored URLs are skipped:

```
python -m econquest.ingestion.text pull --since "2015-01-01" --max-docs 50
```

```
python -m econquest.ingestion.text status
```

Later pulls use the same command. Use `--refresh` to re-read stored URLs: a changed text becomes a new version, and
nothing is overwritten. Never lower `--min-interval` below the default 5 s. Values below 2 s are refused.

After the pull, upload `data/corpus/` to the shared folder (the whole folder, as it is) and tell AGENT-08. Team B
then runs EQ-B-0135 on it.

## 5. Interface for Team B and Team C

```python
from econquest.ingestion.text import corpus

docs = corpus.documents("ARG", since="2015-01-01", as_of="2023-08-14")
df = corpus.documents_frame(None, as_of="2023-08-14", family="central_bank", with_text=False)
corpus.latest("PAK", as_of="2026-10-26", n=5)
corpus.coverage(as_of="2026-10-26")
corpus.available()
```

- `country`: a desk ISO3 or a desk-name alias; `None` means all names. An unknown name raises ValueError.
- `since` and `as_of`: a date, a datetime or ISO text. An `as_of` date means the end of that day (UTC).
- `sources`: registry keys. `family`: `central_bank` or `imf`. `basis`: `published` or `knowledge`.
- Results are ordered by publication time. An IMF release that names two desk names is returned for each of them.
- `latest` returns dicts with no body text, and its titles are Sheets-safe.
- Every document has `client_ok=False` today. Nothing from the corpus may go into client output.
- Changing a signature or a field needs a handoff to B/AGENT-08 and C/AGENT-08.

## 6. Limits

- PDF releases are skipped: SBP, CBN and BoZ publish many as PDF. PDF text extraction is a follow-up ticket.
- Pages rendered by script (SBV, possibly BSP and PBoC) give no listing to a plain HTTP read. These are parked or
  need a different entry point after the dry run.
- The text is stored as extracted, in its original language. Translation and sentiment are Team B's work
  (EQ-B-0135).
- The licence terms are not read for any publisher. All rows stay tighten-only until Sam reads them (A-sam-ready,
  item 18).
