# Spike: event data feeds (ACLED, GDELT, UCDP) for indicators 4.1, 6.4, 6.9

Ticket EQ-A-0004 (GOV-014, roadmap 1.4). Author: Team A, AGENT-06. Date: 2026-10-23. Documentation
research only: no data was pulled. Pages read are listed at the end. Anything marked *(estimate)* or
*(verify)* was not confirmed on a page read for this spike.

## Target indicators (`data/rulebook.csv`)

| id | Indicator | Type and thresholds | Rulebook source |
|---|---|---|---|
| 4.1 | Street pressure against promised adjustment | Level 0-4. Analyst guide: adjustment size (>=1.5% GDP) combined with protest intensity, reversal or deaths, and government fall | "Pillar 1 gap, ACLED/GDELT protest counts vs 5-year average"; API: ACLED (protests) + analyst |
| 6.4 | Attacks on business and staff | Level 0-4 (rare, isolated, regular kidnappings or infrastructure attacks, frequent, sites shut) | ACLED, press; API: ACLED strategic developments, abductions |
| 6.9 | Political violence trend (12 months vs 5-year average) | Ratio. Thresholds 0.8 / 1.0 / 1.5 / 2.0 / 3.0 | ACLED API |

## Sources compared

| | ACLED | GDELT | UCDP |
|---|---|---|---|
| **Terms for a commercial desk** | The EULA §1.2 says commercial entities "may not access or use the Content ... without first obtaining a corporate license". The free licence (§3.1) is non-commercial only. Material shared outside must be transformative and must not allow the data to be rebuilt; showing the data on a dashboard does not count as transformative. Credentials cannot be shared, and access ends after 3 months without use. **Free research access does not cover this desk.** Cost: USD 5-25k/yr *(estimate, from the gap assessment; ask ACLED)* | "Unlimited and unrestricted use for any academic, commercial, or governmental use of any kind without fee." Every use or redistribution must cite the GDELT Project and link to it | Datasets are CC BY 4.0, free, and may be redistributed with a citation. The API is free |
| **Access and endpoints** | OAuth: `POST https://acleddata.com/oauth/token` (password grant, `client_id=acled`); the token lasts 24 h. Data: `GET https://acleddata.com/api/acled/read?country=..&event_date=A\|B&event_date_where=BETWEEN&limit=..`. Default row limit 5,000; paginate. The Open tier has no API; Research, Partner and Enterprise do | Raw 15-minute event CSV zips (index files `data.gdeltproject.org/gdeltv2/lastupdate.txt`, `masterfilelist.txt` *(verify)*); Google BigQuery public tables; DOC 2.0 API for article timelines *(verify)* | `https://ucdpapi.pcr.uu.se/api/gedevents/<version>` (GED 26.1; Candidate monthly 26.0.9) and country-year datasets. Paginate with `pagesize`/`page` and follow `TotalPages`. Each version URL returns the same data indefinitely |
| **Auth** | Account username and password, then OAuth token. Per-person credentials | None for raw files. BigQuery needs a Google Cloud project with billing | Token in header `x-ucdp-access-token`, granted by email to the maintainer within 3-5 working days. 5,000 requests per day, errors included |
| **Update frequency** | Partner: weekly. Enterprise: weekly, expedited. Research: event data with a time lag | Every 15 minutes (GDELT 2.0) | GED: yearly. Candidate: monthly, with at most about a month's lag |
| **History** | Africa from 1997; other regions start later (South and Southeast Asia and Latin America about 2010-2018) *(estimate; verify per country)*. Enough for a 5-year base on all 18 countries *(estimate)* | 1979 onwards (v1, reconstructed); 15-minute v2 since Feb 2015 | 1989-2025 (GED); Candidate for the current year |
| **Country coding** | `iso` is ISO 3166-1 numeric (268 = Georgia in ACLED's example), plus the country name | FIPS 10-4 two-letter codes. This needs a FIPS-to-ISO3 crosswalk: Nigeria is `NI` in FIPS and Niger is `NG` | UCDP/Gleditsch-Ward country ids plus the name *(verify in the codebook)* |
| **What it measures** | Coded political violence, demonstrations and strategic developments, with sub-event types (abductions, looting/property destruction, remote violence) | Machine-coded news events (CAMEO; root 14 = protest *(verify)*). Volume follows media attention | Organised violence with at least one death only. No protests, no non-lethal attacks |

## Proposed mapping to the scorecard

- **6.9: automate fully.** Take ACLED political-violence events (Battles, Explosions/Remote violence,
  Violence against civilians) over the last 12 months and divide by the mean annual count over the previous
  5 years, per country. Until ACLED is licensed, an interim proxy is the same ratio on UCDP Candidate plus
  GED events. Label it as a proxy in provenance: it counts fatal events only, so it reads lower in protest-led
  unrest.
- **4.1: semi-automated; the analyst sets the level.** The feed supplies a protest ratio: ACLED Protests +
  Riots over the last 3 months against the 5-year monthly mean. Before ACLED, use GDELT root-14 events as a
  share of all GDELT events for the country, which controls for media volume. The adjustment-size half of
  the guide comes from WEO (indicator 1.6, already live). A proposed rule: the level is 2 when the
  adjustment is at least 1.5% of GDP and the protest ratio is at least 1.5. The analyst confirms levels 3-4
  (reversal, deaths, government fall).
- **6.4: semi-automated, ACLED only.** Count abductions and attacks over 12 months, plus looting and
  property destruction where the actor or notes match mines, pipelines, power or company staff. This needs
  keyword filtering because ACLED has no target-sector field *(estimate)*. Map counts to levels with
  per-country thresholds; the analyst confirms. GDELT and UCDP cannot support this indicator.
- **Pipeline:** new `EventFeed` adapters in `ingestion/feeds.py` returning the standard long table, a
  country-code crosswalk in `countries.csv` (`acled_iso_num`, `fips`, `ucdp_id`), gate rows, provenance and
  vintages as for the other feeds. Raw ACLED rows stay on the Mac (`raw_acled.csv`) and are not uploaded or
  published; only the derived ratios and levels leave the Mac (EULA §3.1). Adding columns to
  `countries.csv` is a contract change (ADR plus handoffs to Teams B and C).

## Recommendation

1. **Now, at no cost:** request a UCDP token and build 6.9 as an interim proxy on UCDP, plus a GDELT
   protest-ratio aid for 4.1. Both licences permit commercial use with a citation.
2. **Then:** license ACLED (Partner or Enterprise) and switch 6.9 to ACLED, keeping UCDP as a cross-check.
   Add 6.4 and the ACLED protest ratio for 4.1.
3. Do not register an Open or Research myACLED account for this desk. Under §1.2 that would breach the
   EULA. Roadmap 1.4's "ACLED account (free for research)" should be corrected.

## What Sam must decide

1. Whether to buy an ACLED corporate licence: which tier, whose name the account is in, and budget
   *(estimate USD 5-25k/yr)*.
2. GDELT access path: BigQuery (a Google Cloud project with billing, small query cost *(estimate)*) or raw
   file downloads on the Mac (no account).
3. Who emails UCDP for the API token and where it is stored (Keychain; AGENT-09 to review).
4. Whether interim proxies (UCDP for 6.9, GDELT for 4.1) may feed the scorecard, or only be shown as
   analyst aids. Changing an indicator's source definition goes through model-risk change control.
5. Whether 4.1 and 6.4 stay analyst levels with feed evidence, as proposed.

## Pages read

ACLED EULA (acleddata.com/eula); myACLED FAQs (acleddata.com/myacled-faqs); ACLED API getting started
(acleddata.com/api-documentation/getting-started); GDELT About (gdeltproject.org/about.html); ONS GDELT
methodology appendix (ons.gov.uk, "globaldatabaseofeventslanguageandtonegdeltappendix"); UCDP API docs
(ucdp.uu.se/apidocs); UCDP Download Center (ucdp.uu.se/downloads). Read 2026-10-23.
