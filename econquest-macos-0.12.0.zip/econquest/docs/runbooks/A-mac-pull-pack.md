# Runbook: Mac pull pack (every Mac-only pull in one resumable run)

Ticket EQ-A-0048. Owner: Team A, AGENT-06. Operator: Sam. Written 2026-10-24 from `econquest/ingestion/pullpack.py`.
It replaces running the separate runbooks one by one. They stay as the reference for each step:
`A-official-fx.md`, `A-full-panel-fetch.md`, `data/panel/README.md`, `A-universe-expansion.md`, `A-event-feeds.md`.

## Before you start (once)

- Mains power, and `caffeinate` (below) so the Mac does not sleep. About **4 GB free** for a full run (estimates below).
- BoC-BoE workbook: download https://www.bankofcanada.ca/wp-content/uploads/2026/10/BoC-BoE-Database-2026.xlsx to
  `~/Downloads/BoC-BoE-Database-2026.xlsx`. Without it, step 3 is skipped and says so.
- UCDP token (free, by email, 3-5 working days), kept in the Keychain:
  `security add-generic-password -s econquest-ucdp -a "$USER" -w`. Without it, step 5a is skipped and says so.

## Commands

```bash
cd ~/econquest
.venv/bin/python -m econquest.ingestion.pullpack plan          # what will run, disk needed, what is missing (no network)
export UCDP_API_TOKEN="$(security find-generic-password -s econquest-ucdp -w)"   # optional; never on the command line
caffeinate -i .venv/bin/python -m econquest.ingestion.pullpack run
unset UCDP_API_TOKEN
```

The run prints one line when a step starts and one when it ends, with the elapsed time; the details go to
`data/live/pullpack/pullpack.log`. After the FX step it also prints the FX checklist and the BIS-vs-ECB cross-check.
**Rerun the same command after any interruption**: steps already done and verified are skipped, a failed step resumes
(the panel history resumes its run, GDELT its staging). To run a finished step again: `run --redo panel_history`.

After checking the FX checklist (spot-check one rate, e.g. BRL/USD, against the central bank's page):

```bash
.venv/bin/python -m econquest.ingestion.pullpack run --apply-fx    # applies the verified FX vintage; no refetch
```

**After an upgrade, or once a newer FX vintage exists** (for example from a plain `econquest fetch --only fx`): the pack
keeps the FX vintage it fetched earlier and held for `--apply-fx`, and it does not refetch. That held vintage can be
older than a feed added since. The 2026-10-24 held vintage `2026-10-24T183253Z-c53c067e` was fetched on 0.4.0 and has
no theratesapi_fx (VES, NGN, PKR, VND, ZMW). In that case refetch inside the pack first, check the checklist, then apply:

```bash
econquest mac-pull run --steps fx --redo fx
econquest mac-pull run --steps fx --apply-fx
```

Applying a stale held vintage is refused, not done silently: `feeds.apply_vintage` raises OlderVintageError when a
newer vintage exists, and the pack reports `apply refused` and points to `--redo fx`.

Then install the official FX price history. Sam signed off FX-only prices (Tier 1) on Team B's decision card on
2026-10-24; the dossier is `docs/validation/dossier/fx-only-prices.md`. Step 1b staged the build. **Before
`apply`**, send the pull report to Team B: dossier section 7 requires the effect table and `replicate` to be rerun
on the staged build first. Once Team B confirms, run `apply` by hand. It checks the vintage and build hashes,
archives the GOOGLEFINANCE-era files as restricted and replaces `data/market_history/prices.csv`:

```bash
.venv/bin/python -m econquest.ingestion.market_history apply    # newest verified build; or --vintage <id> from the report
```

Send the `apply` output back with the report. Team B reruns the base on the real file and checks back with you if
a base number is more than 5% off the approved proxy (VaR99 62.33, ES99 83.15).

Other commands: `status` (one line per step), `report` (rewrites the report). Options: `--steps fx,crag` (only
these), `--crag-xlsx PATH`, `--universe-dest DIR`, `--gdelt-days 7` / `--gdelt-start D --gdelt-end D` (refused over
`--gdelt-max-days`, 366), `--ucdp-start 2019-01-01`, `--weo-vintages 2007-10:2026-10`.

## Next run after the 2026-10-24 pull (EQ-A-0068, RCA-A-002)

The pull of 2026-10-24 (`team/inbox/pull-20261024T183257Z/report.md`) failed step 2: 35 WEO releases (2007-10 to
2024-10) got HTTP 403 or a page that is not a WEO file from www.imf.org, and World Bank PV.EST got "JSON decoding
error". Step 4 refused 2.2 for 77 countries (IDS rows one per creditor). The fixes are in the econquest build that
includes EQ-A-0068; install it first. Then, in this order:

```bash
cd ~/econquest
# 1. Probe the IMF API (one catalogue request + up to 3 one-series samples, about 1 min). Exit 0 = WEO dataflows listed
#    and a sample parsed; exit 1 = it says why. Either way send the folder back.
.venv/bin/python -m econquest.ingestion.panel_history --probe-weo-api --probe-out outputs/weo_api_probe
echo "probe exit code: $?"

# 2. Rerun the pack, with step 4 again. Step 2 resumes run 20261024T183257Z (only the 36 missing units). Each WEO
#    release now tries local file -> IMF API dataflow -> imf-reader -> weo package; a 403 or a non-WEO page falls
#    through to the next route, and a release every route refused is not retried. PV.EST asks only years WGI lists.
#    `--redo universe` reruns step 4 so the World Bank pull reads IDS for the World counterpart only (2.2; 1.2 in dsa).
#    Done steps (1b, 5b, 6) are skipped; step 1 stays held until --apply-fx (above).
caffeinate -i .venv/bin/python -m econquest.ingestion.pullpack run --redo universe

# 3. Only if step 2 still lists WEO releases: the manual fallback list (no network). It prints, per missing release,
#    the exact file name, the folder, and the IMF page to download it from in a browser.
.venv/bin/python -m econquest.ingestion.panel_history --out data/panel --manual-list
#    Save each tab-delimited 'all countries' file under the printed name (not an .xlsx), then rerun step 2's command.
```

Send back, with `report.md` and `report.json`: `outputs/weo_api_probe/` (`probe.json`, `weo_dataflows.csv`,
`weo_api_samples.csv`), `data/panel/staging/weo_cache/weo_route_diagnostics.jsonl` (what the IMF served for each
refused download: status, content-type, first 512 bytes) and `data/panel/staging/20261024T183257Z/manifest.json`.
The refused bodies themselves stay in `data/panel/staging/weo_cache/rejected/`; send them only if asked.

Expect the manual list to be needed for 2007-10 to 2024-10. On the 20:16Z rerun (0.4.0), imf-reader reported "Version
('April', 2019) not available from the API. Available: [('April', 2025), ('April', 2026), ('October', 2026),
('October', 2025)]", and the weo package wrote an empty body (0.0Mb) for every release from 2007-10 to 2024-10. The
API route therefore probably serves only 2025-04 onwards. The probe settles it. A 0-byte download is now a refused
body: it is described, kept and falls through. The manual list then prints all 35 releases with file name, folder
and page. Allow about 35 browser downloads (estimate: 1-2 min each).

What the next report proves or disproves (each was UNVERIFIED from the cloud):

| Question | Where the answer is |
|---|---|
| Do releases before October 2025 exist as `WEO_<YYYY>_<MON>_VINTAGE` dataflows under `IMF.RES`? | `weo_dataflows.csv` (`vintage` column); step 2 units with source "via IMF SDMX 3.0 API" |
| Does the filtered request form (`c[INDICATOR]=..&c[FREQUENCY]=A`) work on WEO dataflows? | `weo_api_samples.csv` `status`; a unit source that says "(filtered)" or "(whole dataflow)" |
| What does www.imf.org serve to the weo package? | `weo_route_diagnostics.jsonl` (`status`, `content_type`, `kind`, `head`) |
| Is the IDS World counterpart code `WLD`? | step 4: 2.2 served, or `feed_failures` naming the counterparts served ("set official.worldbank.IDS_WORLD_COUNTERPART") |

## 0.6.0 Mac order (licence baseline; EQ-A-0096 dsa re-gate; EQ-A-0102 2.11 release; EQ-A-0094 World Bank-only panel; EQ-A-0098 haircut data)

Run this after installing 0.6.0. It replaces the 0.5.0 order, which was never run (nothing from it was uploaded).
Done steps are skipped, as before. WEO stays deferred (EQ-A-0087).

### 0. Licence register baseline (once, before anything else)

`data/licences.csv` is under change control (R44, EQ-C-0106). Until Sam approves its first baseline, every command that
reads the register (the pull pack's audit of restricted cells, the restructuring run in block B, client builds) only
warns. Approve it first, so the commands below read an approved register. If it answers that `licences.csv already matches the
last applied sha256; nothing to baseline`, the baseline was done before: carry on.

The lines below contain no comments and are safe to paste into zsh:

```bash
cd ~/econquest
.venv/bin/python -m econquest change baseline licences.csv --actor "Team A AGENT-06" --approver Sam --reason "R44: first approved licence register (EQ-C-0106)"
echo "baseline exit code: $?"
```

### 0a. Reset the decisions the old zip shipped (EQ-A-0101, once)

The 0.5.0 zip shipped a review.csv whose decisions were imported into your ledger as "unknown" (87 rows on 2026-10-25).
They cannot release any held cell, but this step records your own "hold" on each cell they touch that the gate holds
or has no value for (Pakistan and Argentina 1.2 among them), so every such cell needs your own decision later. Cells
the gate passes are left alone. It only appends to the ledger. Look at the dry run first, then run it:

```bash
cd ~/econquest
.venv/bin/python -m econquest.ingestion.ledger legacy-reset --data data --author Sam --self-approved --dry-run
.venv/bin/python -m econquest.ingestion.ledger legacy-reset --data data --author Sam --self-approved
echo "legacy-reset exit code: $?"
```

A second run writes 0 rows.

### 0b. Full desk fetch, then the dsa re-gate (EQ-A-0096)

`econquest dsa` reads the raw files that a fetch saved, so its 1.2 / 1.1 / 2.1 rows are gated after the fetch, for that
fetch's vintage only. The pack step `dsa_regate` (step 0) runs `econquest dsa` on the latest vintage and gates its rows
offline. It then saves a derived vintage. It applies nothing. It refuses, and changes nothing, when there is no vintage,
when the latest vintage is not a full fetch (for example after `pullpack run --steps fx`), when that vintage is already
a re-gate, or when the dsa rows name another vintage. It does not need any older vintage. Pakistan and Argentina 1.2
are held (`dsa_reseed`: their seeds came from the old `dsa --apply`). Only an apply decision that names its author and
is bound to the new vintage id releases them. Run the two commands in this order, before section A. The fetch comes
first, and the re-gate comes straight after it, before any other pack step:

```bash
cd ~/econquest
caffeinate -i .venv/bin/python -m econquest --data data fetch
echo "fetch exit code: $?"
.venv/bin/python -m econquest.ingestion.pullpack run --steps dsa_regate --redo dsa_regate
echo "dsa_regate exit code: $?"
```

Exit 0 means the derived vintage is saved and verified. The report's checklist lists the 1.2 cells the gate passed
and the cells it held. Exit 2 with `skipped` gives the reason (for example, "no vintage": run the fetch line first).

### 0c. Release the 2.11 export-concentration cells (EQ-A-0102)

Sam approved Team B's 2.11 rule on 2026-10-25 at 13:19Z (indicator-rules section 15, HO-20261025-A-B-005). The fetch
in 0b computes 2.11 with that rule. On the 0.4.2 data the rule gives six desk values: Belize 95.3, Nigeria 85.9,
Zambia 73.0, Brazil 40.7, Colombia 34.9 and Senegal 32.7. Your fetch may give slightly different values if the World
Bank has updated its data since.

The other desk countries keep their seed:
* Argentina and Zimbabwe are held, because the export groups cover less than 75% of exports.
* Venezuela is held because its data are stale (latest 2013).
* The nine manufacturers are blank, because manufactures are their largest group.

These cells move desk PDs (a Tier 1 batch). Release them only after 0b, against the vintage that 0b saved last.

1. Find the id of the vintage that 0b saved. The dsa_regate step prints it in its checklist, and report.md keeps it,
   in the line `derived vintage <id> saved`. The id looks like `2026-10-26T091500Z-1a2b3c4d`. This line shows it:

```bash
cd ~/econquest
grep "derived vintage" data/live/pullpack/report.md
```

2. Put that id in place of `PASTE_THE_VINTAGE_ID_HERE` in the first line below. Then list the held cells of that
   vintage and check the six 2.11 values against the numbers above:

```bash
VINTAGE=PASTE_THE_VINTAGE_ID_HERE
.venv/bin/python -m econquest --data data review list --pending --vintage "$VINTAGE"
```

3. In the same terminal, approve the six 2.11 cells against that vintage, then apply that vintage offline:

```bash
.venv/bin/python -m econquest --data data review approve Inputs 2.11 Belize Inputs 2.11 Nigeria Inputs 2.11 Zambia Inputs 2.11 Brazil Inputs 2.11 Colombia Inputs 2.11 Senegal --author Sam --self-approved --vintage "$VINTAGE" --note "EQ-A-0102: 2.11 rule indicator-rules 15, approved 2026-10-25 13:19Z"
echo "approve exit code: $?"
.venv/bin/python -m econquest --data data review apply --vintage "$VINTAGE" --dry-run
.venv/bin/python -m econquest --data data review apply --vintage "$VINTAGE"
echo "apply exit code: $?"
```

What to expect:
* With the id left as `PASTE_THE_VINTAGE_ID_HERE`, all three commands refuse and write nothing. If you open a new
  terminal, set `VINTAGE` again first.
* `review apply` refuses a vintage that is no longer the latest (for example, after another pack step saved a newer
  one). Then rerun 0b and this section; do not add `--allow-older`.
* `review approve` refuses, and writes nothing, if any of the six cells is not in that vintage's review. That
  happens if a value came back empty. Remove that cell from the line and run it again.
* If four-eyes is enforced, the command asks for a named sign-off. `review approve` has the flags `--as USER_ID`
  (Sam's id in data/users.json is `sam`) and `--exc EXC-nnn` (a named self-approval exception). Add
  `--as sam --exc EXC-nnn` with your exception id, or use `--approver OTHER` instead of `--self-approved`.
* `review apply` writes indicators.csv for every gate-ok cell of that vintage (not only 2.11) and the approved held
  cells. The `--dry-run` line shows that batch first. If the gate passed a 2.11 cell, it is not in the pending list
  and applies without approval: leave it out of the approve line.
* Argentina, Zimbabwe and Venezuela stay on their seed. Do not approve them.
* For a gold exporter only, a reviewer may release a held 2.11 cell with the value max(commodity max, 100 - sum)
  (indicator-rules section 15 rule 1). Neither Argentina nor Zimbabwe qualifies on the 0.4.2 data.

### A. World Bank probe, then the World Bank-only run

**Why step 2w.** Team B's interim hazard refit (EQ-B-0098) needs World Bank history for 2000-2025 for every economy.
The World Bank files we have hold only 2020-2025. That is `raw_worldbank.csv` from the desk fetch and from step 4
(universe), which asks for the six most recent values per economy (`mrnev=6`) for the 88 universe economies. Step 2
asks for every year from 1980 for every economy, but only for the three hazard-panel series (`DT.DOD.DSTC.IR.ZS`,
`FI.RES.TOTL.MO`, `PV.EST`), and none of them is one of Team B's interim features. On 0.4.2, PV.EST and 36 WEO
releases failed, so step 2 wrote no file at all. The new **step 2w `wb_panel`** is its own World Bank-only run, in
`data/panel/wb_interim/`. It fetches six series, each as its own resumable unit, for 2000-2025, for every economy. A
series that fails elsewhere (PV.EST) cannot hold it up, and it never writes `data/panel/worldbank_history.csv`.

| Series | Database | What | Status |
|---|---|---|---|
| `BN.CAB.XOKA.GD.ZS` | WDI (2) | current account % GDP | confirmed (feeds.WB_SERIES; served 88/88 on 0.4.2) |
| `NY.GDP.MKTP.KD.ZG` | WDI (2) | real GDP growth % | confirmed (88/88) |
| `FP.CPI.TOTL.ZG` | WDI (2) | CPI inflation % | confirmed (88/88) |
| `GOV_WGI_RL.SC` | WGI (3) | rule of law, 0-100 score (the code Team B's loader reads) | confirmed (216 economies) |
| `DT.DOD.DECT.EX.ZS` | IDS (6), World counterpart | external debt stocks % exports | confirmed (60/88) |
| `DT.DOD.DSTC.IR.ZS` | WDI (2) | short-term external debt % reserves | confirmed (57/88; 113 in step 2) |
| `RL.EST` | WGI (3) | rule of law estimate | **UNVERIFIED**: probe only, not fetched by 2w |
| `FM.LBL.BMNY.GD.ZS` | WDI (2) | broad money % GDP (Team B: a non-IMF 2.1) | **UNVERIFIED**: never pulled, not in feeds.WB_SERIES; probe only, not fetched by 2w |

Projection years are never kept. The last year is 2025, because 2026 is not over. IDS amortization, interest and
debt-service series (`DT.AMT.*`, `DT.INT.*`, `DT.TDS.*`) carry projected years that the API does not mark, so step 2w
refuses them.

**Size and time (estimates, not measured).** Each request returns one page of up to 1,000 rows. For `all`, WDI answers
about 266 economies (aggregates are dropped after the call), WGI about 214 and IDS about 125. Over 26 years that is 7
pages per WDI series, 6 for WGI and 4 for IDS: 38 data pages plus 4 metadata requests, so about 42 requests and at
most about 36,500 rows. At 1-3 s a request, that is 1-3 minutes. Allow up to 10 minutes if the WGI series needs the
one-request-per-year fallback (25 more requests) or if retries are needed. On disk it is a few MB (final file, staged
copy and panel vintage). The probe tries every route of the three WGI codes in full, so it makes about 100-150 requests and takes 3-8
minutes.

1. **Probe** (no token). It tries every request shape once for PV.EST, RL.EST, FM.LBL.BMNY.GD.ZS and the six series above, for
   2000-2025. It prints one block per code and then a `SUMMARY`. Exit 0: every code has a working route. Exit 1: at
   least one has none, and its `API answered HTTP ...` lines say why. Exit 1 is expected while PV.EST, RL.EST or
   FM.LBL.BMNY.GD.ZS are unresolved. Go on to step 2 either way.
2. **Step 2w only.** If a series fails, rerun the same line. It resumes and fetches only the missing series.

The lines below contain no comments and are safe to paste into zsh:

```bash
cd ~/econquest
.venv/bin/python -m econquest.ingestion.panel_history --probe-wb panel
echo "probe exit code: $?"
caffeinate -i .venv/bin/python -m econquest.ingestion.pullpack run --steps wb_panel
echo "wb_panel exit code: $?"
```

Exit 0 from the pack means step 2w is done and verified. The verify checks the columns, that every series is present,
that the years are within 2000-2025, and that there is one row per series, economy and year. Do not add `RL.EST` or
`FM.LBL.BMNY.GD.ZS` yourself. If the probe serves them, we will send you the line once Team B has confirmed the
series list.

**Send back** (to the Claude project files):
* the whole `outputs/wb_probe` folder (`probes.json`, `probe.json` and the `codes` folder) and the probe's printed
  output;
* `data/panel/wb_interim/worldbank_history.csv`;
* from `data/panel/wb_interim/staging`, only the `manifest.json` in the newest run folder;
* `data/live/pullpack/report.md`, `report.json`, `state.json` and `pullpack.log`.

Step 2 (`panel_history`, PV.EST) and `--redo universe` (the IDS year window, EQ-A-0086) from the 0.5.0 order are still
open. EQ-A-0094 does not need them. To run them too, paste this line after the ones above:

```bash
caffeinate -i .venv/bin/python -m econquest.ingestion.pullpack run --panel-sources worldbank --redo universe
```

### B. Haircut data (EQ-A-0098; AGENT-08 has cleared the promote)

1. In a browser, download
   `https://docs.google.com/spreadsheets/d/1yUUMPAEF9uKbYV6bG3dLZ6dzDQnkJqcS/export?format=xlsx`. Save it unchanged
   (do not open it in Excel and save it again) as
   `~/econquest/data/panel/research/haircuts/Cruces-Trebesch-Haircuts-2014-update.xlsx`. If the folder does not exist
   yet, the `mkdir` line below creates it. Run that line first, then save the file.
2. Build the haircut table from that file and promote it to `data/panel/cruces_trebesch_haircuts.csv`. Every build is
   also kept as an append-only vintage. Exit 2 with `refused:` means the file was not accepted, and the message says
   why.
3. Rerun the restructuring scenarios on the new file and write `restructuring.json`. The date below is an example.
   **Replace `2026-10-25` with today's date (YYYY-MM-DD) in the `--as-of` line and in the upload path.**

The lines below contain no comments and are safe to paste into zsh, once the date is changed:

```bash
cd ~/econquest
mkdir -p data/panel/research/haircuts
ls -l data/panel/research/haircuts/Cruces-Trebesch-Haircuts-2014-update.xlsx
.venv/bin/python -m econquest.ingestion.research.haircuts --data-dir data --promote
echo "haircuts exit code: $?"
.venv/bin/python -m econquest.engine.restructuring --as-of 2026-10-25 --paths 100000 --write
echo "restructuring exit code: $?"
```

**Send back:** `outputs/restructuring/2026-10-25/restructuring.json` (with your date in place of 2026-10-25) and the
printed output of the commands above.

## Steps, expected times and sizes (estimates, not measured)

| # | Step | Time | Disk checked before start | Unblocks |
|---|---|---|---|---|
| 0 | `dsa_regate`: `econquest dsa` on the latest full fetch, offline gate of its rows, derived vintage, no apply (EQ-A-0096); skipped when the latest vintage is not a full fetch | 1-10 min (estimate) | 50 MB | - |
| 1 | `fx`: BIS + ECB official FX, no apply; checklist and cross-check; apply only with `--apply-fx` | 1-5 min | 100 MB | SEC-A-006 M1 (restricted cells to 0) |
| 1b | `fx_history`: `prices.csv` from official FX (EQ-A-0054), staged; install with `market_history apply` (above) | 5-20 min | 200 MB | EQ-A-0054 |
| 2 | `panel_history`: every WEO release and 3 World Bank series | 30-120 min | 2 GB | EQ-A-0015, EQ-A-0016 |
| 2w | `wb_panel`: World Bank-only panel, 6 series, 2000-2025, every economy, into `data/panel/wb_interim/` (EQ-A-0094) | 2-10 min (estimate) | 100 MB | Team B EQ-B-0098 |
| 3 | `crag`: BoC-BoE import, comparison with the memory list, coverage | under 1 min | 100 MB | EQ-A-0008, EQ-A-0016 |
| 4 | `universe`: 88 countries into a staged copy (`~/econquest-universe-<ts>`), missing-cell report | 10-40 min | size of `data/` + 0.5 GB | EQ-A-0026 |
| 5a | `ucdp`: GED + Candidate from 2019 | 1-5 min | 50 MB | - |
| 5b | `gdelt`: last 7 days by default | 1-3 min a day | 41 MB a day + 250 MB | - |
| 6 | `nowcast`: IMF / OECD / BIS monthly series for the 25 nowcast names, archived as a vintage; verified map rows merged into `nowcast_inputs.csv` (`A-nowcast-feed.md`); skipped when no source host answers | 1-5 min | 50 MB | EQ-A-0057 |
| 7 | `research`: offline; research files dropped in `data/panel/research/KEY/` through Team B's rules and the gate; every cell held, 3.6/4.4/6.10/7.12 parked for Sam's sign-off, nothing applied; report in `live/pullpack/research/` (`A-research-datasets.md`, EQ-A-0089); skipped when no file is dropped | under 1 min | 10 MB | - |
| 8 | `macro`: BIS WS_EER (real/nominal, broad/narrow) through BisFeed (BIS optional) and the World Bank Pink Sheet file `CMO-Historical-Data-Monthly.xlsx` from `~/Downloads` (or `--cmo-xlsx`; never fetched), gated with the WDI export shares into `live/macro/vintages/<id>/`; nothing applied, no desk cell (`A-macro-inputs.md`, EQ-A-0134); skipped with the download message when neither answers | 1-5 min (estimate) | 50 MB | - |

Each step first checks its hosts (one probe each): an unreachable host skips that step with the reason; it never
hangs. Nothing is forced: cells the quality gate holds stay held, `data/countries.csv` and `data/indicators.csv`
change only in step 1 with `--apply-fx`, and the 88-country pull writes only to the staged copy.

Exit code: **0** every step done, **2** something skipped or held (the report says what and why), **1** a failure.

## What to send back

`data/live/pullpack/report.md` and `report.json` (written after every run). They list per step the status, counts,
vintage ids, verify results, what was held and why, which Blocked tickets are now free, and what you do next.
Upload them to the Claude project files with `state.json` and `pullpack.log`, and the uploads a step's "Next" line
asks for (for example `data/panel` with `staging/<run>/manifest.json` but without `staging/weo_cache`).
When step 7 ran, also send `data/live/pullpack/research/` (two files; EQ-A-0089).
`A-landing-check.md` is the full list (including the staged universe folder) and the token check to run before
sending; we verify everything with `python -m econquest.ingestion.landing check`.

## If something goes wrong

- A step `failed`: read its reason in `status` or report.md, fix it, rerun `run`. The log has the traceback.
- `crag` held with "no ISO3 code": fill `data/panel/sovereign_defaults_crag_unmapped.csv`, save it as
  `data/panel/crag_iso_map.csv`, rerun (`data/panel/README.md`).
- Disk refusal: free space or point `--universe-dest` at a bigger disk; shorten the GDELT range.
- State lives in `data/live/pullpack/state.json`. Do not edit it; `--redo STEP` is the way to run a step again.
