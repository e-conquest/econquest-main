# MVP shared dataset (EQ-A-0110, MVP row M2)

One complete offline dataset, frozen in the shared folder, that the engine and `econquest demo` (EQ-C-0121) run on
without a Mac pass. Built only from files already in the shared folder; nothing is fetched and nothing is invented.
Code: `econquest/ingestion/mvp_dataset.py`. Tests: `tests/test_mvp_dataset.py`, `tests/test_crag_count_a083.py`.

## What goes in

| Input | Used for |
|---|---|
| `data/` (seed tables, the 2026-10-23 vintage already applied, `audit_trail.csv`) | base values and their labels |
| `team/inbox/pull-20261025-fullfetch/review.csv` (Sam, 13:03Z, vintage `2026-10-25T130355Z-aac8592d`) | the live values Sam applied |
| `data/market_history/prices.csv` (+ provenance), `data/fx_manual.csv` | FX history and hand-entered official FX, copied as they are |
| `data/panel/sovereign_defaults_crag*.csv`, `panel/staging/crag/DEBT_2026.csv` (not frozen) | CRAG panel; indicator 1.8 count (EQ-A-0083) |

A review cell is taken live only when the gate passed it (`ok`) or a named, approved decision bound to that value
released a hold, and no sticky hold pins it. This is `ledger.effective_holds`, so legacy "apply" rows imported from
the hand-edited review.csv never release a hold (EQ-A-0101). Every other review cell keeps the value the shared folder
has and carries the gate's reason.

Not used: `pull-20261025T013150Z` (88-country universe pull, not applied to the desk; its desk cells are superseded
by the 13:03Z full fetch), `pull-20261025T121034Z/worldbank_history.csv` (hazard refit input; Team B's refit is not
cleared and Tier 1, so adding it would change layer 1 without approval), `raw_bis.csv` and `raw_yahoo.csv` (raw pull
responses the engine does not read), `live/vintages/`, `panel/staging/`, `market_history/archive|builds|repairs`.

## What comes out: `data/mvp/`

```
data/mvp/
  data/              a loadable data directory, files read-only (load_universe(data/mvp/data)), with the MVP's own
                     gate state: live/review.csv (Sam's 13:03Z review without non-cells, plus the 1.8 rows),
                     live/provenance.csv (one row per live cell) and audit_trail.csv (audit.build_audit_trail)
  provenance.csv     one row per cell of indicators.csv and countries.csv:
                     table, key, country, value, label (live | seed), source, vintage, gate_status, reason
  gate_report.json   every review cell and every 1.8 cell: outcome live | held | missing | not_a_cell, with its reason;
                     every blank seed cell with its reason; summary.unexplained must be 0
  manifest.json      sha256 per file, dataset_sha256, counts live/seed per table, as_of, vintage_id,
                     sha256 of the inputs (review upload, data/indicators.csv, countries.csv, audit_trail.csv)
```

Labels: `live` means the value came from a pull, and `vintage` names it: `2026-10-25T130355Z-aac8592d` (Sam's full
fetch) or `2026-10-23` (the earlier vintage already applied in `data/`). `seed` means a seed estimate, a hand-entered
value or a blank, with the reason in `source`. 32 cells were held or missing in the 13:03Z gate but already carried a
2026-10-23 live value. They keep that value, the value Sam's Mac has, and are labelled `seed`, because a gap sits on a
labelled seed value (M2). The `source` column names the earlier vintage; in audit_trail.csv the origin is "seed kept (value
from an earlier vintage; the new pull is held or missing)". Any shared record tying an MVP value to a restricted
source is carried into live/provenance.csv, so verify refuses the dataset rather than hiding it.

Build of 2026-10-25 23:42Z: after EQ-A-0112 (fx3m), EQ-A-0113 (licences attribution) and the M2 gate-state fix, and
with the data/ M2 fix and EQ-A-0114 ledger-only releases (dataset_sha256 `86db5f1e68736c0a...`; the values and the
base are unchanged). Rebuilt 2026-10-26 00:18Z under EQ-A-0114 for the 60-row data/licences.csv (imf_via_wdi, four
nowcast_* rows, cow_contiguity; HO-20261026-A-A-002): only licences.csv and the manifest changed, dataset_sha256
`6a30118871e2c50c...`, and the desk base is identical (A/B at 20,000 paths). Rebuilt again 2026-10-26 06:24Z under
EQ-A-0125 for the 62-row data/licences.csv (sha `395fedf3...`; AGENT-04 added the restricted path rows `ucdp_ged` and
`research_pullpack`). It was built in scratch first, then in place. Only licences.csv and the manifest changed;
countries.csv and indicators.csv are byte-identical. The new dataset_sha256 is `129268fcddc32547...`. verify gives ok
with 0 restricted cells, probe gate gives 301 held/missing cells and 0 unexplained, and the desk base at 20,000 paths
as of 2026-10-23 is identical (66.55 / 88.44 / 4.00 / 71.83). The base on data/ is the same with the 60-row and the
62-row register. `python -m econquest.ops.demo probe gate --data data/mvp/data` gives ok, 301
held/missing cells, 0 unexplained:

| Table | Cells | live | seed |
|---|---|---|---|
| indicators.csv | 1494 | 254 (245 from 13:03Z, 9 from 2026-10-23 that the 13:03Z review does not cover) | 1240 |
| countries.csv | 720 | 74 (all from 13:03Z) | 646 |

Gate report: 638 cells (620 review rows plus 18 cells for 1.8): 319 live, 105 held, 196 missing, 18 not_a_cell
(equity_vol, which has no column in countries.csv and is not served). 49 blank seed cells (7.7 for 14 names; prior,
etf, gpr_series and policy blanks in countries.csv). **0 unexplained.**

Indicator 1.8 (EQ-A-0083, indicator-rules.md section 16): 15 values held as a Tier 1 batch with the reason
`Tier 1: Sam sign-off (parked)`. JPN, KOR and SGP are not served (outside CRAG coverage). The seed stays in all 18
cells. The computed values are in `gate_report.json` (`live` column of the 1.8 rows).

Rebuilt 2026-10-26 under EQ-A-0130, the one planned PI-13 rebuild. The new dataset_sha256 is `9cbe721d7ee1a3aa...`.
indicators.csv and countries.csv are byte-identical to 129268fc, and so are the live/seed counts and the gate outcomes
(0 unexplained, 0 restricted). Desk base at 20,000 paths as of 2026-10-23: 66.55 / 88.44 / 4.00 / 71.83, and every
engine output CSV is byte-identical before and after. The rebuild changed:

- **Feed source per cell (ARCH-A-PI10 R4).** live/provenance.csv and audit_trail.csv now name the feed and series of
  each of the 319 full-fetch cells, never the generic "econquest full fetch" text, so the `econquest_derived`
  register row cannot match them. Sources were found in two ways:
  - 280 from the feed-specific vintage record of the same cell and value (data/live/provenance.csv or a vintage's
    provenance.csv);
  - 39 traced: the 2.9 x8, 3.4 x13 and 3.5 x18 cells. econquest's own `feeds.wb_transforms` reproduces each value
    exactly from Sam's recorded pull `team/inbox/pull-20261025T013150Z/raw_worldbank.csv` (World Bank WDI/IDS
    DT.DOD.DSTC.IR.ZS; WGI GOV_WGI_RL/CC/RQ.SC ranked among all economies).

  A cell with neither would be labelled `unestablished source ...`, which matches no register row. The count is 0;
  the manifest's `feed_source` lists any. Client-restricted cells go from 480 to 485: the 5 EXC-005 theratesapi fx3m
  cells are now caught at source. The desk count stays 0.
- **1.8 rule 16.3a (HO-20261026-B-A-004).** Argentina's held value goes from 1 to 4 (new defaults 2014, 2019, 2023).
  It is still held under TIER1_HOLD, and the seed of 3 stays. The other 14 served names are unchanged. A parity test
  checks all 18 names against `validation.crag_redefaults.desk_table`.
- **1.6 transform text.** audit_trail.csv now names the WEO inputs (`audit.TRANSFORMS["1.6"]`), with no value change.
- **New file.** `data/calendar/events.csv` (EQ-A-0132) is frozen.
- **Exclusions.** These are never frozen: `corpus`, `sanctions`, `calendar/drop` and `live/macro`.

## Commands (zsh-safe)

```
cd ~/econquest
python -m econquest.ingestion.mvp_dataset build
python -m econquest.ingestion.mvp_dataset verify
python -m econquest.ingestion.mvp_dataset materialize /tmp/econquest-mvp-data
python -m econquest --data /tmp/econquest-mvp-data --out /tmp/econquest-mvp-out run --as-of 2026-10-25
```

- `build` writes into a temporary sibling folder and renames it into place, so a failure leaves the previous
  `data/mvp/` as it was. The same inputs give the same `dataset_sha256`. It fails loudly when the review upload or the
  CRAG files are missing. `--no-crag` builds without the 1.8 cells, and the manifest then says so.
- `verify` checks every file against its sha256, refuses missing or extra files, checks the labels, requires 0
  unexplained cells in the gate report (recounted from the cells, not only the stored summary; a gate hold without a
  reason counts as unexplained), and loads the universe. Exit 1 with the reason on any failure. It never falls
  back to `data/`.
- `verify` also runs `audit.restricted_source_cells` on the MVP data: no value from Yahoo or a barred licence may be
  in it (MVP M6). `load_mvp_universe`, `mvp_data_dir` and `materialize` run the same check (ARCH-A-PI10). The build
  of 2026-10-25 has 0, also when every shared vintage's provenance.csv is added to the check. The shared `data/` had
  17 (the 2026-10-23 Yahoo fx3m) until AGENT-04 replaced them under EQ-A-0112; it has 0 now.
- A cell is labelled `live` from `audit_trail.csv` only when the trail's live record holds the value the cell has now
  (the audit trail's rounding tolerance). A stale live record leaves the cell `seed` (ARCH-A-PI10). The MVP fx3m cells are the gate-ok values from Sam's 13:03Z full
  fetch (the official FX step: BIS/ECB, with the theratesapi.com mirror for VES, NGN, PKR, VND and ZMW under EXC-005,
  internal use only). They do not come from the shared countries.csv. Files: AGENT-04 writes the shared
  `data/countries.csv` and provenance, and this job writes only `data/mvp/`. Rebuild after AGENT-04's change so that
  the frozen copy of the shared files matches it. Rebuilt 17:39Z after EQ-A-0112 (derived vintage
  2026-10-25T170547Z-67dffc57). Its 12 official fx3m values equal Sam's 13:03Z values. For MYR, PKR, BZD, COP and XOF,
  AGENT-04's gate held the cells at seed in the shared folder. The MVP keeps Sam's 13:03Z values for those five, because
  his gate passed them (`ok`) and he applied them by name (`--author Sam --self-approved`, 12:52Z).
- `materialize DEST` copies the verified data directory to a writable folder outside `data/`. Run the engine there,
  never with `--data data`: the MVP run must not overwrite `data/indicators.csv`.

## For Team C (econquest demo, EQ-C-0121)

```
from econquest.ingestion import mvp_dataset
info = mvp_dataset.verify()                    # dict: ok, as_of, vintage_id, dataset_sha256, counts, gate; raises MvpError
data_dir = mvp_dataset.materialize(dest)       # writable verified copy; then cli --data <data_dir>
u = mvp_dataset.load_mvp_universe()            # or a Universe straight away; provenance["mvp"] names the manifest
```

Evidence for M2: `verify()["gate"]["unexplained"] == 0` and `data/mvp/gate_report.json`.

## Engine check (2026-10-25, 131,072 paths, as_of 2026-10-25, scratch copy)

| Data | VaR99 | ES99 | EL | L-VaR99 |
|---|---|---|---|---|
| MVP dataset | 66.21 | 87.91 | 4.01 | 71.49 |
| shared `data/` as it is (comparison) | 66.70 | 88.43 | 4.08 | 71.99 |

$mm. The difference comes from Sam's 13:03Z values, mainly fx3m: 18 gate-ok cells, 5 of which also carry Sam's named apply.

## Hold releases come only from a verified ledger (EQ-A-0114, SEC-A-012 L3)

A gate hold goes live in data/mvp only when a row of a review ledger that `ledger.verify_ledger` passes releases it.
That row must be an approved apply by a named person, bound to the vintage or the live value (the effective_holds
rules; a dsa_reseed hold needs the vintage id). The decision, author and approver columns of an uploaded review.csv
are plain text: their hold and reject rows are honoured, but an "apply" typed there releases nothing. The manifest's
`releases` field says where releases came from.

## After the Mac pass: landing kit (EQ-A-0116)

Sam uploads, into one folder under team/inbox/: `review.csv`, `report.json` and `pullpack.log` (required), plus
`review_ledger.csv` (data/live/review_ledger.csv; without it no hold is released) and, if he has them,
`worldbank_history.csv` and the wb_probe outputs. Then, from the econquest folder:

```
python -m econquest.ingestion.macpass_landing check --inbox team/inbox/macpass-20261027
python -m econquest.ingestion.macpass_landing run --inbox team/inbox/macpass-20261027 --dry-run
python -m econquest.ingestion.macpass_landing run --inbox team/inbox/macpass-20261027
python -m econquest.ingestion.mvp_dataset verify
```

- `check` verifies the upload only:
  - required files are present and there are no links;
  - sha256 of every file, matched against SHA256SUMS and every hash report.json records (the wb_panel file);
  - no credential-like text (the report names file and line, never the text);
  - the pull pack ran econquest 0.7.0 or later and finished, with no step pending or running;
  - the vintage is newer than data/mvp's (`--vintage-id`, else report.json's dsa_regate vintage);
  - review.csv is whole: every desk country, and every cell of the current MVP review;
  - the ledger hash chain verifies.
- `run` also rebuilds data/mvp from the new review in a candidate folder. It runs `verify` (0 unexplained, 0
  restricted, the universe loads) and econquest demo's M2 probe on the candidate, which replaces data/mvp only if both
  pass. It measures desk coverage before and after (`coverage_live`, AGENT-01) and writes
  `outputs/macpass/FOLDER/landing.md` and `landing.json`:
  - cells moved to live or to seed;
  - live values changed;
  - new and cleared holds;
  - cells where data/mvp now differs from data/: what a reviewed apply would change in the base;
  - Tier 1 items for Sam: 1.5, 1.8, 2.11, dsa_reseed and other "Tier 1" holds.
- It never writes data/. Moving values into the base stays a reviewed apply on Sam's Mac (`econquest review apply`).
- Exit codes: 0 landed or checked; 2 refused (partial or stale, e.g. a missing file, an old pull pack, a truncated
  review, or the same upload twice); 1 error (a hash mismatch, a secret, a broken ledger chain, or the rebuilt dataset
  fails verification). A refusal writes `refused.md` and `refused.json` and leaves data/mvp as it was.
- Recorded uploads, all refused: pull-20261025-fullfetch (report.json and pullpack.log missing), pull-20261025T121034Z
  (pullpack.log missing), pull-20261025T013150Z (econquest 0.4.2), pull-20261024T183257Z (review.csv missing). The
  tests also land synthetic 0.7.0-shaped uploads: the dsa_regate vintage, the wb_panel file, and the 2.11 release by
  Sam in the ledger (`tests/test_macpass_landing.py`).

## Rebuild when

- After the Mac pass: use the landing kit above.
- When `data/` changes (an apply or a CRAG update): run `build`, `verify` and the engine check, and record the new
  dataset_sha256 here. `build` without arguments uses Sam's 13:03Z upload (`REVIEW_UPLOAD`, `VINTAGE_ID`).
  Once data/mvp is on a newer vintage from a landing, it refuses, so it cannot undo the landing: use the kit or `--review`.
