# Runbook: data operations (freshness SLA, cell lineage, daily event pulls)

Ticket EQ-A-0052. Owner: Team A (AGENT-04 wrote it; AGENT-06 owns the ingestion code). Date: 2026-10-24.
Everything here reads files already on disk and works offline, except `incremental run`, which pulls UCDP / GDELT on
the Mac. Run every command from the econquest folder.

## 1. Freshness SLA per series

Code: `econquest/ingestion/freshness.py`. Table: `data/live/freshness_sla.csv` (generated, never hand-edited).

```bash
python -m econquest.ingestion.freshness check                   # exit 0 clear, 2 breaches, 1 no pull / no SLA file
python -m econquest.ingestion.freshness check --json            # summary + failing cells, for a job or a ticket
python -m econquest.ingestion.freshness check --all             # every checked cell, ok ones too
python -m econquest.ingestion.freshness check --min-severity high   # fail only on engine-required series
python -m econquest.ingestion.freshness check --strict          # a cell that cannot be measured also fails
python -m econquest.ingestion.freshness check --vintage 2026-10-23 --as-of 2026-10-23   # a saved vintage, at a date
python -m econquest.ingestion.freshness sla --check             # exit 1 if the CSV no longer matches the rules
python -m econquest.ingestion.freshness sla --write             # regenerate the CSV after a rule change
```

Columns of the SLA table: `series_id, table, source, series, frequency, measure, max_age_days, severity, raw_file,
raw_series, basis`. Where the limits come from:

| Series | Measure | Limit | From |
|---|---|---|---|
| BIS policy rate (5.13, `policy`) | last observation | 30 days | quality gate EQ-A-0044, daily |
| BIS real EER (2.12) | last observation | 92 days | quality gate EQ-A-0044, monthly |
| BIS credit gap (5.9) | last observation | 275 days | quality gate EQ-A-0044, quarterly |
| World Bank (2.9, 2.10, 5.10, 6.2, 6.6, `pop`, `exports`, `reserves`) | last annual period | 1096 days | quality gate `stale_years=3` |
| WGI (3.4, 3.5) | last annual period | 1096 days | World Bank annual rule by frequency (no gate check today) |
| Official FX (`fx3m`) | last BIS WS_XRU / ECB EXR day | 30 days | BIS daily rule by frequency |
| IMF WEO (1.3, 1.6, 1.7, 2.8, 5.5, 5.6, 5.12, 5.14) | age of the pull | 214 days | Team A operating parameter, set by AGENT-08 2026-10-24: Apr/Oct release cycle (183) + 31 days; no gate rule |

Severity: `high` = engine-required in `data/panel/coverage_source_map.csv` notes, `medium` = other Inputs, `low` =
Country Profile. The check measures age at today (UTC) by default; the quality gate measures it at the pull date, so a
cell can pass the gate on the day of the pull and breach the SLA weeks later. `gate_status` in the output shows
whether the gate already holds the cell.

What a breach means and what to do:
- BIS daily or monthly breach for one country (e.g. Argentina policy rate, last observation 2025-07-10): BIS stopped
  carrying the series. The gate holds the value on the next pull; decide with AGENT-08 whether the seed stays.
- World Bank annual breach (e.g. 6.2 homicide rate for most desk countries, Nigeria exports with a 1960 last period):
  the source has nothing newer; the cell stays on seed or gets an analyst value. Nothing to re-pull.
- WEO retrieval breach, or every cell older than its limit: run `econquest fetch` on the Mac.
- `unknown`: the raw file for the SLA's source is not in the pull (on 2026-10-24 all 17 `fx3m` cells: the live pull
  predates the official FX feeds and still carries Yahoo rows). It clears after the first official FX pull.

On the 2026-10-23 pull checked at 2026-10-24: 302 cells, 271 ok, 14 breaches (6.2 x 8, 5.10 x 2, 5.13 and `policy`
Argentina, `reserves` Venezuela, `exports` Nigeria), 17 unknown (`fx3m`).

## 2. Lineage per cell

Code: `econquest/ingestion/lineage.py`. Read-only.

```bash
python -m econquest.ingestion.lineage show VNM 1.3              # ISO3 or country name, indicator id or profile key
python -m econquest.ingestion.lineage show Brazil fx3m --json
python -m econquest.ingestion.lineage export --out /tmp/lineage.csv        # every cell; stdout without --out
python -m econquest.ingestion.lineage export --no-hand-entered
```

Per cell: value and origin, source and series, `vintage_id` with `vintage_basis` (`apply record` when
`data/live/snapshots/index.csv` records an apply of that vintage with the same value, else `value match`, else
`current pull`), `fetched_utc` (vintage index / feeds.json), `applied_utc`, the gate's status and reason in that
vintage, `gate_decision` (applied, released, applied (forced), applied (now held), applied (hold not released in the
ledger), held, released (not applied), missing, not applied, seed; attested / unattested for hand-entered cells), the
latest ledger decision with author, approver, self-approval flag and time, and the newest vintage's live value and gate
status next to the value in use.

Notes:
- On 2026-10-24 the repo has one legacy vintage (`2026-10-23`), no review ledger and no apply records, so cells show
  `value match` and decisions come from the hand-typed `review.csv` (`decision_source` = `review.csv (legacy)`). 68
  cells are `applied (hold not released in the ledger)`: applied on 2026-10-23 from hand-typed decisions before the
  ledger existed.
- The export guards text against spreadsheet formula injection (leading `=`, `+`, `-`, `@` get an apostrophe).

## 3. Daily incremental UCDP / GDELT

Code: `econquest/ingestion/events/incremental.py` and `events/mapping_qa.py`. The first pull is the Mac pull pack
(steps 5a / 5b, `docs/runbooks/A-mac-pull-pack.md`); without a stored vintage `run` refuses (`no_history`) unless you
pass `--start`.

```bash
python -m econquest.ingestion.events.incremental plan                       # what a run would pull; no network
export UCDP_API_TOKEN="$(security find-generic-password -s econquest-ucdp -w)"    # token from the Keychain, never argv
python -m econquest.ingestion.events.incremental run --source all           # daily job
python -m econquest.ingestion.events.incremental run --source gdelt --max-days 30   # catch up after an outage
```

How a run works:
- Resume point: UCDP from the last day any vintage covers (monthly counts: the pull restarts at the start of a month,
  so a partial month is pulled again whole, never stacked); GDELT from the day after the last fully staged day, up to
  yesterday (UTC).
- Bounded: at most `--max-days` per run (UCDP 366, GDELT 7); `remaining_days` says what is left for the next run.
- Idempotent: a pull equal to what is stored saves nothing (`no_new_data`); a second run the same day is
  `up_to_date`. A lock (`data/live/events/<source>/incremental.lock`) refuses an overlapping run (`busy`).
- Saved vintages hold only the pulled window. `export.build_events_long` and `indicators.stored_events` read every
  vintage (`incremental.merged_events`: newest vintage wins per iso, period, freq and metric).
- Each run appends a row to `data/live/events/<source>/incremental_log.csv` and refreshes the consumer exports when a
  vintage was saved.
- A new UCDP GED release (e.g. 27.1) revises past months; the incremental run does not re-pull them. Re-run the full
  pull (pull pack step 5a) after a GED release.

Exit codes: 0 ok / no new data / up to date; 2 mapping QA breach; 1 error (token missing, incomplete GDELT day, lock
busy, no history). With `--source all` the worst code wins (1 over 2 over 0). GDELT without the FIPS reference
does not exit 2 for codes outside the desk map; it prints a `WARN:` line instead (see below).

### Country-mapping QA

Runs on every incremental pull and on its own:

```bash
python -m econquest.ingestion.events.mapping_qa gdelt --start 2026-10-01 --end 2026-10-23 [--json] [--threshold 0.02]
python -m econquest.ingestion.events.mapping_qa ucdp --pages saved_page0.json saved_page1.json
```

Each event is `mapped` (ISO3 in the universe: `data/panel/universe_proposal.csv`, else `data/countries.csv`),
`outside_universe` (resolves to an ISO3 outside it; not counted) or `unmapped` (counted per name / code). Exit 2 when
unmapped / (mapped + unmapped) is above the threshold (default 2%). The report also lists universe countries the
adapter's map cannot produce at all.

- UCDP: the adapter refuses a pull with any unmapped event (`mapping_failed`, nothing saved). Add the country to
  `data/live/events/ucdp/country_map.csv` (`ucdp_id, ucdp_name, iso`) from the GED codebook and re-run.
- GDELT: the adapter's FIPS map covers the 18 desk countries only. While no full FIPS 10-4 -> ISO3 reference exists
  at `data/live/events/gdelt/fips_reference.csv` (`fips,iso`), codes outside that map are reported as "outside known
  map (reference table missing)", are not counted, and the output starts with a `WARN:` line; only codes the desk map
  produces count against the threshold, so the run exits 0 unless those break it (AGENT-08 2026-10-24). Once the
  reference exists the full rule applies: codes it maps outside the universe are left out, everything else unresolved
  counts, and codes it maps to a universe country appear with `iso3_hint` (add them to the adapter's override CSV,
  `--fips-map`, `fips,iso`).
- The reference must come from GDELT's or another authoritative FIPS 10-4 list, sourced on Sam's Mac (the cloud
  cannot reach it). Never type it from memory.

### Scheduling

The scheduled job is Team C's (`econquest schedule`, `econquest/ops/`). Handoff to C/AGENT-01 asks for a daily job
running `incremental run --source all` then `freshness check --json`, both exit codes surfaced by `econquest health`.
Until it is wired, run the two commands by hand after `econquest fetch`.
