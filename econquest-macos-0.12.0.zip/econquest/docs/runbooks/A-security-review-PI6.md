# PI-6 data security review (SEC-A-007, EQ-A-0053)

- **Author:** A/AGENT-09
- **Date:** 2026-10-24
- **Ticket:** EQ-A-0053 (In Progress)
- **Severity summary:** 0 Critical, 0 High, 1 Medium (fixed), 7 Low (6 fixed, 1 accepted with conditions), 7 Info.
- **Merge veto:** none. No Critical or High finding.

This review lives here because `teamctl owner team/security/...` gives Team C. The threat-model rows are staged at
`/mnt/attach/project-files/staging/EQ-A-0053/threat-model-rows.md` for C/AGENT-09 (handoff below).

## Scope

| Ticket | Code |
|---|---|
| EQ-A-0049, EQ-A-0050 | `econquest/ingestion/official/` (sdmx, imf, oecd, eurostat, worldbank, precedence, gate, wiring, central_banks) and the related `feeds.py` changes |
| EQ-A-0048 | `econquest/ingestion/pullpack.py`, including AGENT-01's step 6 `nowcast` (EQ-A-0057), reviewed last |
| EQ-A-0054 | `econquest/ingestion/market_history.py` build/apply, and the `dataroom.py` and `replay.py` changes |
| EQ-A-0052 | `freshness.py`, `lineage.py`, `events/incremental.py`, `events/mapping_qa.py`, and the `events/ucdp.py` and `events/indicators.py` edits |
| EQ-A-0057 | `econquest/ingestion/nowcast_feed.py`, reviewed after AGENT-08 confirmed it was finished |
| — | `ingestion/audit.py` client-output hook (`client_output_reason`, `client_restricted_cells`) |

## Method

- **Code review.** The `teamctl diff --ticket` output of each ticket, plus the functions those diffs call: `sources.https_get`, `feeds._with_retries`, `_stop_reason`, `market.vendors.base.secret` and `events.base.http_fetch`.
- **Probes.** Offline, not committed:
  - BCCh URL redaction, with credentials that contain a space, `&`, `/` and `+`.
  - `dataroom.restricted_reason` on the real `data/market_history/repairs/inda_repair_EQ-A-0056.csv`, at its own path and at a replay-snapshot path.
- **Bandit 1.9.4** on official/, pullpack, nowcast_feed, market_history and events/incremental: 0 issues. The 2 skips are justified `nosec` B404/B603 on the nowcast validator subprocess (argument list, fixed module, no shell, timeout).
- **Credential grep.** Searched for ECOS_API_KEY, BANXICO_SIE_TOKEN, BCCH_PASS and UCDP_API_TOKEN assigned to 8 or more characters, over `data/`, `docs/`, `econquest/` and `tests/`: no hits.
- **No network calls.** pip-audit was not run because it needs the network. Run it on the Mac or in CI (T5).

## Findings

| ID | Severity | Status | Where | Summary |
|---|---|---|---|---|
| M1 | Medium | fixed | `market_history.py` `market_restricted_reason`; `replay.py` SKIP_DIRS | GOOGLEFINANCE INDA closes in `data/market_history/repairs/` were not withheld from the data room, and replay froze them into dated snapshots |
| L1 | Low | fixed | `pullpack.py` `run` | No run lock: two `pullpack run` processes could fetch and apply the same steps and overwrite each other's state.json |
| L2 | Low | fixed | `official/central_banks.py` `_redact` | The form-encoded (quote_plus) spelling of a BCCh credential was not redacted |
| L3 | Low | fixed | `market_history.py` `verify_fx_history_vintage`, `apply_official_fx_history` | The vintage id was joined to paths unchecked (`--vintage ../..`). Apply did not tie an existing build to its verified vintage |
| L4 | Low | fixed | `official/imf.py` `main` | `structure FLOW` joined FLOW unchecked to the URL path and to the `--out` file name |
| L5 | Low | fixed | `events/incremental.py` `plan_incremental` | `--max-days` had no ceiling. A GDELT run had no disk bound |
| L6 | Low | fixed | `nowcast_feed.py` `write_vintage`, `read_vintages` | index.csv rows were appended without a lock. Vintages were replayed without a hash check |
| L7 | Low | accepted with conditions (Sam) | `official/central_banks.py` APIS `bok_ecos`, `bcch` | The ECOS key (URL path) and the BCCh user and password (query string) travel in the URL |
| I1 | Info | open | `audit.py` `main` (`client --csv`, `restricted --csv`) | Provenance text is printed to CSV without formula neutralisation |
| I2 | Info | open | `nowcast_feed.py` `BisNowcastFeed.url` | flow and key come from the map CSV and are not URL-quoted. The host stays fixed |
| I3 | Info | for Sam | data room | IMF data goes into the room by design. The room's README addresses an external validator |
| I4 | Info | by design | `audit._matching_cells` | An IMF cell whose value equals a value from a non-IMF current source is not listed |
| I5 | Info | known | `feeds.py` (wbgapi, imf-reader, weo) | Third-party packages do their own HTTP, outside `https_get` |
| I6 | Info | by design | `pullpack.py` step 6 `nowcast` | Writes `data/live/nowcast_inputs.csv` directly: verified map rows only, after Team B's validator |
| I7 | Info | open | `market_history.verify_fx_history_vintage` | Follows symlinks inside a vintage folder |

### M1: GOOGLEFINANCE repair table reaches the data room (fixed)

**What.** AGENT-08 moved `inda_repair_EQ-A-0056.csv` to `data/market_history/repairs/` (EQ-A-0056). It holds two INDA close columns, `bad_INDA` and `inda_csv_INDA`, which are GOOGLEFINANCE-derived. Two gaps let it through:

- `market_restricted_reason` withheld only `archive/` and `research/`, plus CSVs whose header holds an ETF ticker as an exact column name.
- `replay.SKIP_DIRS` did not skip `repairs/`. The next `replay.freeze_inputs` would therefore copy the file into a dated `live/snapshots/<id>/market_history/repairs/` folder, which `build_data_room` exports to the external validator.

The probe returned `None`, meaning "not restricted", for both the working path and the snapshot path.

**Exploit scenario.** No attacker is needed. The next replay freeze followed by a data room build passes Google-terms-restricted data to a third party. That is the same class of problem as SEC-A-006 M1/M2.

**Fix.**

- `market_restricted_reason` now fails closed. Every file in a market_history sub-folder other than `vintages/` and `builds/` (`ROOM_SAFE_DIRS`) is withheld. A CSV is also withheld when an ETF ticker appears as a token of a column name (`bad_INDA`).
- `replay.SKIP_DIRS` gains `market_history/repairs`.

No snapshot holds the file yet (`find data -path '*repairs*'` shows only the working copy).

**Verify.** `pytest tests/test_sec_a_pi6.py -k m1`

### L1: no pull pack run lock (fixed)

`pullpack.run` now runs under `run_lock()`: a non-blocking `fcntl.flock` on `data/live/pullpack/run.lock`. The lock is released when the process exits, so a crash leaves no stale lock. A second run raises `PackBusy`, a subclass of `UsageError`, so `main` exits 1 with one line, and it writes nothing. The incremental runner already had a per-source flock (verified).

**Verify.** `-k l1`

### L2: BCCh redaction misses the quote_plus spelling (fixed)

`urlencode` writes a space as `+`, but `_redact` replaced only the raw and `quote(safe="")` forms. Probe output: `user=u+ser%40x.cl&pass=p+w%26d` survived redaction.

Today no exception message carries the query string, because `RedirectRefused` and `ResponseTooLarge` name the host and path only. So this was defence in depth. `_redact` now also replaces `quote_plus(s, safe="")`.

**Verify.** `-k l2`, plus the existing `tests/test_central_banks.py::test_failure_text_never_carries_a_credential`.

### L3: FX history vintage id and build tie (fixed)

`check_vintage_id` requires `YYYY-MM-DDTHHMMSSZ-hash8` before any path is built. It is called in `verify_fx_history_vintage` and `apply_official_fx_history`.

When a build already exists, apply now also requires the sidecar's `vintage_id` and `vintage_hash` to equal the verified vintage. Before this fix, a relabelled build whose prices sha256 matched its own sidecar was installed.

**Verify.** `-k l3`

### L4: `official.imf` structure/sample flow id (fixed)

The local operator's CLI argument went unchecked into the URL path and into `<out>/<flow>.structure.xml`, so `../../x` wrote outside `--out`. `FLOW_ID_RE` now refuses it, with exit 2 and no request.

**Verify.** `-k l4`

### L5: incremental `--max-days` ceiling (fixed)

`MAX_DAYS_CEILING`:

- **GDELT:** 366 days, the same limit as `pullpack --gdelt-max-days`, which is about 15 GB of raw files.
- **UCDP:** 3660 days.

A larger value raises `ValueError` before any pull. The pull pack's own GDELT bound (366 days) and its disk preflight (estimate x 1.1 with `shutil.disk_usage`) were verified.

**Verify.** `-k l5`

### L6: nowcast vintages (fixed)

- `write_vintage` appends to `nowcast_vintages/index.csv` through `ledger.locked_append`, the same pattern as feeds.
- `read_vintages` recomputes each vintage's content hash and refuses the vintage, with `FeedRefused` (exit 1, no traceback), when it does not match the folder's hash8. An edited or half-written vintage is never replayed into `nowcast_inputs.csv`.

**Verify.** `-k l6`

### L7: ECOS and BCCh credentials in the URL (accepted with conditions; answers HO-20261024-A-C-014)

**What the code does (verified).**

- Credentials are read only through `market.vendors.base.secret`: the environment, then the Keychain service `econquest`. They are never read from argv or files.
- Nothing that econquest writes holds them: raw rows (the `endpoint` column is the placeholder pattern), state.json, reports, or the `failures` list. The failures list is redacted before it is stored.
- `https_get` refuses redirects, so a 3xx cannot replay the URL to another host. HTTPS hides the path and query from a plain CONNECT proxy.
- The only messages that carry the path are `RedirectRefused`, `ResponseTooLarge` and the non-https `ValueError`. The ECOS key in them is path-quoted, and that form is redacted.
- urllib's `HTTPError.url` holds the full URL, but the object is discarded inside `CentralBankFeed.fetch` and never formatted.
- `cb` is not a pull-pack step. It runs only as `fetch --only cb`, outside the default fetch.

**Residual exposure, outside econquest:**

- the BoK and BCCh server access logs (inherent in the documented APIs);
- any TLS-intercepting proxy (a corporate MITM or an inspection agent) that logs full URLs;
- an HTTP debug level turned on by hand.

**Severity: Low.** These are free, read-only statistics keys, the BCCh account has no payment or trading rights, and the feed is run deliberately by the operator.

**Conditions (recommended to Sam):**

1. Use API-only credentials that are not reused anywhere else. This matters most for BCCh, because it is a user/password pair.
2. Do not run `--only cb` through a TLS-inspecting proxy. Check `echo $HTTPS_PROXY` and the system proxy settings on the Mac.
3. Rotate the credential if it appears in any log.
4. Ask BCCh whether a header or POST option exists, and switch to it if so.

Keeping ECOS and BCCh disabled is not needed: they are already off the default fetch, and every cell they fill is held by the gate until verified.

### Info

- **I1.** `python -m econquest.ingestion.audit client --csv` and `restricted --csv` write `source` and `series` text unescaped. The text is built by code, but `provenance.csv` and `audit_trail.csv` can be hand-edited. Suggest `ledger._neutralise` on object columns, as `lineage export` does. `audit.py` is UNOWNED in `team/ownership.csv`, so this review did not edit it.
- **I2.** `BisNowcastFeed.url` formats `flow` and `key` from `data/live/nowcast_series_map.csv` without quoting. The host stays `stats.bis.org` and the answer is parsed strictly, so the impact is a wrong request only. Suggest `urllib.parse.quote(key, safe="+.")`, as OECD and Eurostat do.
- **I3.** IMF rows (licence "internal research use only") go into the data room by Sam's decision ("internal data room", 2026-10-24 12:38Z). `dataroom.py` and its README describe the room as for "an external validator". Sam should confirm that handing IMF data to that validator counts as internal research use. If it does not, add `client_output_reason` to `dataroom.restricted_reason`.
- **I4.** `_matching_cells` skips a cell when the current provenance gives the same value from an allowed source. Same rule as `restricted`, and reasonable.
- **I5.** wbgapi, imf-reader and weo do their own HTTP (pre-existing, SEC-A-006). Every PI-6 adapter uses `https_get`.
- **I6.** Pull pack step 6 writes the engine input `nowcast_inputs.csv`, but only verified map rows. The write is append-only and goes through Team B's validator on a temp file before `os.replace`. This is consistent with the EQ-A-0057 design, and no held cell is forced.
- **I7.** `verify_fx_history_vintage` reads `q.read_bytes()` and follows symlinks. Exploiting it needs local write access to `data/`.

## Controls verified OK (no change)

- **HTTP.** sdmx/imf/oecd/eurostat (`SdmxFeed._get`), `central_banks` and `nowcast_feed` (through `SdmxFeed`) all use `sources.https_get`:
  - https only, else `ValueError`;
  - redirects refused (`RedirectRefused`, which is an HTTPError and final);
  - byte caps of 50 MB (SDMX) and 10 MB (cb);
  - explicit timeouts.

  `probe_host` sends HEAD requests without following redirects.
- **Fail fast.** Proxy refusal, DNS failure and redirect raise `FeedUnreachable` (sdmx) or kill only that host (cb). 4xx other than 429 is final, and 429/5xx/timeouts get bounded retries. A `FeedUnreachable` message carries the host, plus the path for a redirect, which is redacted for cb.
- **UCDP token.** Read from the environment only (`events.base.env_secret`) and sent as an unredirected header. Provenance records only `header x-ucdp-access-token`. The pull pack preflight records only the variable name. HTTP errors carry host and path only.
- **Licence tags on raw rows.** Present on IMF, OECD and Eurostat (`RAW_COLUMNS` licence), cb (`CB_RAW_COLUMNS` licence + endpoint pattern), nowcast raw and transformed tables and `nowcast_inputs.csv`. GOOGLEFINANCE archive and research files carry `.licence.json`. World Bank raw rows have no licence column (pre-existing; WB terms are in the coverage map).
- **Data room.**
  - Withheld: raw_yahoo, desk-barred licence CSVs, `market_history/archive|research` and now every non-official sub-folder (M1), and ETF-column CSVs.
  - Kept by design: IMF (I3).
  - Lock files, hidden and temporary files are excluded, so `run.lock` and `incremental.lock` never enter the room.
- **No-apply guarantees.**
  - `build_official_fx_history(apply=False)` never writes `prices.csv`. The pull pack calls it without apply.
  - The fx step applies only with `--apply-fx` after verify, and never forced.
  - The universe step uses `feeds.fetch_and_save` into a staged folder.
  - `update_prices_from_sheet_json` refuses without the `ECONQUEST_ALLOW_GOOGLEFINANCE=1` opt-in and writes only `research/`.
- **Atomic writes and locks.**
  - pullpack state.json uses `_atomic_write` (mkstemp + `os.replace`).
  - market_history uses `_atomic_bytes`, 0444 vintages and builds created with `exist_ok=False`, and `locked_append` for its index.
  - incremental has a per-source flock and `locked_append` for its log.
  - nowcast uses `_validated_write`, and `locked_append` since L6.
  - pullpack has a run lock since L1.
- **CSV formula injection.** `lineage export` neutralises object columns. freshness and mapping_qa print text or JSON only. SDMX raw strings are code-built: area values must be among those requested, and periods are normalised. See I1 for the audit CSV exports.
- **Deserialisation and execution.** No pickle or eval. The single subprocess (nowcast validator) uses an argument list, `sys.executable -m econquest.engine.nowcast`, `cwd` set to the repo root, and a 300 s timeout.

## Changed (all checkpointed under EQ-A-0053)

- `econquest/ingestion/market_history.py`: M1, L3
- `econquest/ingestion/replay.py`: M1
- `econquest/ingestion/pullpack.py`: L1. AGENT-01 then added step 6 on top, and both changes coexist.
- `econquest/ingestion/official/central_banks.py`: L2
- `econquest/ingestion/official/imf.py`: L4
- `econquest/ingestion/events/incremental.py`: L5
- `econquest/ingestion/nowcast_feed.py`: L6
- `tests/test_sec_a_pi6.py`: 16 tests, one or more per fixed finding

## Handoffs

- **New handoff to C/AGENT-09:** merge the staged rows (T18 to T21 new; additions to T2, T16 and T17). Its Context also carries the L7 assessment for HO-20261024-A-C-014.
- **HO-20261024-A-C-014:** Team A cannot write its Response, because the receiver writes the Response. C/AGENT-09 can close it with L7: no SEC change is required, and the conditions are listed under L7.
