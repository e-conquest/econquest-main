# Team A PI-15 agent brief (Sam "Go" 2026-10-27 10:25Z)

**Theme.** PI-15 adds an LLM assistant layer. By default it uses a self-hosted open-source model (Ollama or vLLM; Team C's EQ-C-0170/0171).
- It explains the desk.
- It never computes a risk number.
- It ships off.
- The PI ends in 0.12.0 (Team C builds it last, with demo rows M25-M27).

Nothing in this PI depends on Sam's Mac. Model choice, host, and "Claude API key yes/no" are parked for Sam (team/when-sam-is-ready.md).

**Standing rules.** All rules from the A-PI11..14 briefs still apply:
- Never invent data. Make no fetches. Label synthetic fixtures SYNTHETIC.
- No secrets in argv, logs or files.
- Checkpoint before editing; checkpoint new files BEFORE creating them.
- `teamctl check --ticket` must show 0 before you report.
- Run your own test files.
- Commands must be zsh-safe.
- Never run `teamctl revert --ticket` on EQ-A-0077 or EQ-A-0130..0141. Revert by path.

**Environment.**
- Env: `export ECONQUEST_TEAM=A PYTHONPYCACHEPREFIX=/tmp/claude-0/-home-claude-econquest-main/4d046af0-0329-5499-894e-87a0bbd3789c/scratchpad/pyc`
- Repo: /mnt/attach/project-files/econquest

**Invariants.**
- These do not move: data/ values, data/mvp (d3564255…), Team B's base (66.55/88.44/4.00/71.83), and the licence register except for tighten-only rows (5c98b226, 97 rows, owned by AGENT-04).
- The context builders are READ-ONLY. They never write under data/ and never call a model or the network.

## Shared contract: the context chunk (all three tickets build to this)
Package: `econquest/ingestion/context/` (Team A owns it under econquest/ingestion/*). Public API:
```python
from econquest.ingestion.context import build_context, Chunk
chunks = build_context(data_dir, *, kinds=None, country=None, as_of=None, scope="internal"|"client", limit=None)
```
`Chunk` is a frozen dataclass with these fields:
- `chunk_id`: stable; sha256 of source_id + text, first 16 characters.
- `kind`: one of run_output | archive | audit | calendar | ledger | corpus | events | dataset.
- `source_id`: path plus row/key or document id, citable.
- `country`: ISO3 or "".
- `as_of`: the date the fact is true for.
- `published_utc`: may be blank.
- `retrieved_utc`: may be blank.
- `text`: plain, already fenced if untrusted.
- `licence_ids`: tuple of register source_ids.
- `scope`: "internal" | "client_ok".
- `trust`: "econquest" for our own computed outputs | "ingested" for any third-party text.
- `provenance`: one line, human-readable.

Rules:
- `scope="client"` returns only `client_ok` chunks. Fail closed: if any licence row is restricted, unknown or unverified, the chunk is internal.
- Every chunk with `trust="ingested"` has its text passed through the A-0145 fence (`context.hygiene.fence(text, source_id)`). It is never raw.
- Point in time: with `as_of` set, no chunk published or recorded after as_of is returned.
- Deterministic: the same inputs give the same chunks in the same order.

## Who owns what

| Ticket | Agent | Owns |
|---|---|---|
| A-0143 context builders (run outputs, research archive, audit trail, calendar, review ledger; plus corpus/events) | AGENT-06 | context/__init__.py, builders.py, tests |
| A-0144 licence scope: licence tag on every chunk, fail-closed client scope, refusal tests | AGENT-04 | context/scope.py, register rows if needed, tests |
| A-0145 ingested-text hygiene: strip/fence instructions in CB/IMF/GDELT/news text, provenance label | AGENT-02 | context/hygiene.py, tests (SYNTHETIC injection fixtures) |
| A-0146 security review (last) | AGENT-09 | review + small fixes |
| structure review (last) | AGENT-05 | review + small fixes |

**Interfaces between tickets.**
- A-0144 and A-0145 expose small functions: `scope.chunk_scope(licence_ids) -> ("client_ok"|"internal", reason)` and `hygiene.fence(text, source_id) -> str`.
- A-0143 calls them. Until they land, A-0143 uses a stub that always returns "internal" and fences everything.
- Agree on the names by message. Don't edit each other's files.

**Hand-offs.** As soon as `build_context` works on shared data (even before A-0144/0145 are final), send the API note to:
- B/AGENT-05 (B-0145 tool contracts)
- C/AGENT-06 (C-0170 provider interface; C-0172 surfaces)
