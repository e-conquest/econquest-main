# Cruces-Trebesch haircuts (EQ-A-0098)

AGENT-01, 2026-10-25. This runbook covers the adapter `econquest/ingestion/research/haircuts.py`, the licence check,
how to drop the file, and how the 17 exchanges typed from memory in `engine/restructuring.py`
(`REFERENCE_RESTRUCTURINGS`, Team B) compare with the dataset. Team A did not change any engine value. Swapping the
values is Team B's refit (PI9-B2, EQ-B-0099), handed off as HO-20261025-A-B-007.

## 1. Where the 17 exchanges live and how they are used

| File | Owner | Use |
|---|---|---|
| `econquest/engine/restructuring.py` `REFERENCE_RESTRUCTURINGS` (17 rows: low-high haircut range, face cut, settled month, debt/GDP, IMF flag, delay, confidence) | B | `reference_table()` -> `fit_haircut_model` (WLS of the range midpoint on debt/GDP and IMF) -> restructuring path stress. Off by default; `run_pipeline` does not call it. |
| `econquest/engine/restructuring.py` `haircut_source` / `load_ct_haircuts` / `compare_with_ct` (EQ-B-0099) | B | Uses `data/panel/cruces_trebesch_haircuts.csv` (`CT_DEFAULT_RELPATH`) **instead of** the typed table whenever that file exists. |
| `econquest/engine/layer4_severity.py` `load_haircuts` / `fit_haircuts` (GOV-024) | B | Beta fit per instrument class for `layer4.lgd_source = "fitted"`; reads a CT-style file passed by path. |
| `data/assumptions.json`, `data/playbook.csv`, `data/approvals/proposals/CHG-*.json` | - | Mention "haircut" for other things (convertibility and equity haircuts, proposals text). They hold none of the 17. |

Ownership (`team/ownership.csv`): `econquest/engine/*` and `docs/validation/*` are Team B (AGENT-05).
`data/panel/*` and `docs/runbooks/A-*` are Team A.

## 2. Source and licence (read 2026-10-25)

| What | URL | Result |
|---|---|---|
| Trebesch data page | https://sites.google.com/site/christophtrebesch/data | Read with WebFetch. It lists "Haircut dataset, 1970-2013 (Cruces/Trebesch)", "2014 update of haircut dataset", 187 restructurings with foreign banks/bondholders. The download is https://docs.google.com/spreadsheets/d/1yUUMPAEF9uKbYV6bG3dLZ6dzDQnkJqcS/export?format=xlsx. It also lists "Sovereign Haircuts: 200 Years of Creditor Losses" (with Luckner, Meyer, Reinhart; IMF Economic Review 2025), "The full 200-year dataset is available", at https://drive.google.com/uc?export=download&id=1Uib7PTK7jDvEaeOYgwAOMRsHxt7P-po2. **No licence, terms of use, citation request or redistribution wording appears on the page.** |
| The workbook itself | the Sheets export above (Google serves it as `Cruces-Trebesch-Haircuts-2014-update.xlsx`) | Its title block says: "2014 update building on AEJ Macro 2013 paper "Sovereign Defaults: The Price of Haircuts", by Juan Cruces and Christoph Trebesch" and "This update: August 20, 2014". Sam's upload of it (sha256 `50c5ab9019daf22de35edf5dd9ccc1444f2ceeb337f138c09e59e2ffd302ec86`, 67,502 bytes) was read in a scratch copy on 2026-10-25: its "README (2012 version)" sheet holds only definitions (HSZ, HM, face value, case selection) and its "2014 Update Comments" sheet lists added, deleted and recoded cases. **Neither sheet states a licence or terms of use**, so the status stays UNVERIFIED. |
| AEA replication package | https://www.openicpsr.org/openicpsr/project/114278/version/V1/view (doi:10.3886/E114278V1) | Read with WebFetch. It shows no licence and no redistribution clause, only "This material is distributed exactly as it arrived from the data depositor." Distributed 2019-10-12, V1. |
| 200-year dataset (Drive) | the Drive link above | **UNVERIFIED**. The fetch was refused (robots_disallowed) and the file was not seen. |

**Licence status: UNVERIFIED.** Nothing grants redistribution. Tag: `internal research use only: Cruces-Trebesch
haircut dataset, licence UNVERIFIED (no terms on the data page; cite Cruces and Trebesch 2013)`, with client_ok
False. Because of this, Team A does **not** commit the workbook, or a CSV built from it, into the repo's `data/`.
Sam drops the file on his Mac, and the build runs there. Whether to ask the authors for terms is a licence decision
for Sam, through AGENT-08.

Cloud download: not possible. curl through the proxy gets a 403 for docs.google.com, sites.google.com and
openicpsr.org. WebFetch can follow the export redirect but returns "[binary data]" for the xlsx. The adapter's
downloader refuses redirects anyway, so the fetch mode is `manual`.

## 3. What Sam drops

1. Open https://docs.google.com/spreadsheets/d/1yUUMPAEF9uKbYV6bG3dLZ6dzDQnkJqcS/export?format=xlsx. It downloads
   `Cruces-Trebesch-Haircuts-2014-update.xlsx`.
2. Save it, unchanged, as `data/panel/research/haircuts/Cruces-Trebesch-Haircuts-2014-update.xlsx`. Keep exactly
   one file there; two matches are refused. Do not save a Google Sheets CSV export: it is locale-formatted
   ("9.900", "30,3%"), so it is refused.
3. Run `python -m econquest.ingestion.research.haircuts --data-dir data`. Add `--debt-gdp hazard_panel` to fill
   debt/GDP where the hazard panel has it (see section 5). Add `--promote` to write
   `data/panel/cruces_trebesch_haircuts.csv` and `cruces_trebesch_haircuts.provenance.json`. Promote only after
   AGENT-08 says Team B is ready: once that file exists, `restructuring.haircut_source` switches from the typed
   table to it.

Exit codes: 0 means built; 2 means refused (missing file or LayoutError), and the reason is printed.

## 4. Adapter output contract (AGENT-08 / Team B, 2026-10-25)

`data/panel/cruces_trebesch_haircuts.csv` has one row per exchange (CT case). Haircuts are **shares** (0.768 = 76.8%).

| column | meaning |
|---|---|
| country | "Country / Case" text from the file, e.g. `Argentina (Global)`, `Pakistan (Bond debt)` |
| iso3 | The file's Code when it is a known ISO3 and agrees with the name; otherwise the name through `default_panel.default_iso_lookup`. A code/name conflict or an unknown country is dropped and listed in `unmapped_dropped` (provenance), never guessed. |
| year, month | Exchange month from Date "MM / YYYY" |
| date_of_exchange | YYYY-MM-DD only when the source gives a day. CT gives month only, so it is always blank, with the reason in blank_reasons. |
| haircut_sz | Preferred Haircut HSZ (Sturzenegger-Zettelmeyer) |
| haircut_market | Market Haircut HM |
| debt_restructured_mm | Debt Restructured (m US$) |
| face_value_reduction | Face Value Reduction |
| debt_type | `bond` when Bond Exchange = 1, `bank` when 0 (CT covers foreign banks and bondholders only) |
| debt_gdp, debt_gdp_year, debt_gdp_source | Debt/GDP at year - 1 from a named table, else blank |
| imf_program, imf_program_source | Blank: no sourced programme table yet |
| case_id, data_quality | CT case number; Data Quality Index |
| blank_reasons | Each blank field and why |
| licence, source, vintage | Row licence tag (+ `debt_gdp imf_derived (EXC-003, internal use only)` when debt/GDP came from IMF data); source text; `CT 2014 update; sha256:<16>; <file>` |

Sheet choice (layout verified on Sam's file, 2026-10-25): the workbook has four sheets, "2014 Version (new)" (title
"... 1970-2013"), "2014 Update Comments", "README (2012 version)" and the superseded "2012 version (old)" (title
"... 1970-2010", with "Debt Affected" in place of "Debt Restructured"). When more than one sheet has an HSZ/HM header
row, the adapter uses the one whose title row has the latest end year. Ties go first to "new" in the sheet name and
then to the highest year in the name. The choice is written to provenance as `sheet` and `sheet_choice`. On Sam's file
it reads 187 cases from "2014 Version (new)" and writes 183 rows; the 4 Yugoslavia cases (YUG) have no ISO3 mapping
and are listed in `unmapped_dropped`.

Refused, never repaired (`LayoutError`): no sheet with the HSZ/HM header row, or a tie between such sheets; a missing
header on the chosen sheet; Date neither an Excel date cell nor "MM / YYYY"; Bond Exchange not 0/1; a haircut outside [-1, 1] as a share; locale-formatted numbers; a
duplicate or non-integer Case; data without a Case. xlsx input is checked with `safe_zip.check_zip_file` before it
is unpacked.

Vintages: `data/panel/research/haircuts/vintages/<UTC>-<sha8>/{haircuts.csv, provenance.json}` holds files written
once and made read-only. `vintages/index.csv` is append-only. Identical output is not stored again.

Team B's loader `restructuring.load_ct_haircuts` reads this file (test `test_output_reads_in_team_b_loader`). One
gap: `debt_restructured_mm` does not match `layer4_severity.HAIRCUT_COLUMNS["debt_restructured_mm"]` aliases
(normalised `debtrestructuredmm`), so B's loader leaves debt weights NaN until B adds that alias (in the handoff).

## 5. debt/GDP and IMF flag

CT has no debt/GDP. The only table in the repo is `data/panel/hazard_panel.csv`: IMF WEO GGXWDG_NGDP, licence row
`imf_derived`, EXC-003, internal use only. It covers 15 countries from 1980-2001 onward, with gaps. At year - 1 it
has **none** of the 9 matched comparator exchanges (GRC 2011, ARG 2004, ECU 1999, URY 2002, RUS 1999, PAK 1998, BLZ
2006, CIV 2009 all absent). So `--debt-gdp hazard_panel` fills little, and every blank says why. There are three
routes to real coverage, all needing a decision through AGENT-08 and none built:
(a) IMF Historical Public Debt Database (Mac download, tagged imf_derived, EXC-003);
(b) World Bank WDI GC.DOD.TOTL.GD.ZS (central government debt; World Bank terms, CC BY 4.0 UNVERIFIED for this
series), which is sparse before 2000;
(c) Reinhart-Rogoff debt series (terms UNVERIFIED).
A new source is one entry in `haircuts.DEBT_SOURCES`. The IMF programme flag has no sourced table (IMF MONA is IMF
terms and unreachable from the cloud), so it stays blank.

## 6. Comparison: the 17 typed-in exchanges vs the CT 2014 update

**PROVISIONAL.** The CT values below were read on 2026-10-25 through WebFetch of the sheet's CSV export
(https://docs.google.com/spreadsheets/d/1yUUMPAEF9uKbYV6bG3dLZ6dzDQnkJqcS/export?format=csv) and relayed by its
summariser. They were **not** parsed by the adapter from Sam's file. Re-run `restructuring.compare_with_ct` on the
promoted file before anyone relies on a figure. Match rule: same ISO3, exchange year within 1 (as in
`compare_with_ct`). "in range" means CT HSZ falls inside the typed low-high range.

| # | typed row (iso, year, settled) | typed HSZ range | typed face cut | CT case(s) | CT date | CT HSZ | CT HM | CT face cut | result |
|---|---|---|---|---|---|---|---|---|---|
| 1 | ARG 2020 (2020-09) | 40-55% | 2% | none | - | - | - | - | not in CT (1970-2013) |
| 2 | ECU 2020 (2020-08) | 25-40% | 9% | none | - | - | - | - | not in CT |
| 3 | ZMB 2024 (2024-06) | 30-50% | 18% | none (CT ZMB only 09/1994) | - | - | - | - | not in CT |
| 4 | LKA 2024 (2024-12) | 30-45% | 27% | none | - | - | - | - | not in CT |
| 5 | GHA 2024 (2024-10) | 35-50% | 37% | none | - | - | - | - | not in CT |
| 6 | UKR 2024 (2024-09) | 30-45% | 37% | none | - | - | - | - | not in CT |
| 7 | UKR 2015 (2015-11) | 20-30% | 20% | none (CT UKR 1998-2000 only) | - | - | - | - | not in CT |
| 8 | GRC 2012 (2012-03) | 60-70% | 53.5% | 60 "Greece *" | 03/2012 | 64.6% | 76.9% | 53.5% | in range; face cut equal; settled equal |
| 9 | ARG 2005 (2005-06) | 70-80% | - | 7 "Argentina (Global)" | 06/2005 | 76.8% | 78.8% | 29.4% | in range; settled equal; CT has a face cut where typed is None |
| 10 | ECU 2000 (2000-08) | 30-45% | - | 54 "Ecuador" | 08/2000 | 38.3% | 59.8% | 33.9% | in range; settled equal |
| 11 | URY 2003 (2003-05) | 5-20% | 0% | 177 "Uruguay" | 05/2003 | 9.8% | 8.8% | 0.0% | in range; face equal; settled equal |
| 12 | RUS 2000 (2000-08) | 45-60% | - | 145 "Russia (PRINs & IANs)"; also 144 "Russia (MinFin3)" 02/2000 | 08/2000 | 50.8% (MinFin3 51.5%) | 62.4% (50.0%) | 36.4% (0.0%) | in range (both cases) |
| 13 | PAK 1999 (1999-12) | 10-25% | 0% | 117 "Pakistan (Bank debt)", 118 "Pakistan (Bond debt)" | 12/1999 | 11.6% / 15.0% | 11.6% / 14.3% | 0.0% / 0.0% | in range (both); one typed row stands for two CT cases |
| 14 | BLZ 2007 (2007-02) | 20-30% | - | 8 "Belize" | 02/2007 | 23.7% | 29.1% | 0.0% | in range; settled equal |
| 15 | BLZ 2021 (2021-11) | 40-50% | 45% | none (CT BLZ 02/2013 case 9: 31.5%, not in the typed table) | - | - | - | - | not in CT |
| 16 | JAM 2010 (2010-02) | 10-20% | 0% | none (CT JAM cases end 06/1990) | - | - | - | - | not in CT. CT covers external private creditors; the 2010 JDX was a domestic exchange (reason UNVERIFIED) |
| 17 | CIV 2010 (2010-04) | 50-60% | - | 39 "Cote d'Ivoire" | 04/2010 | 55.2% | 52.3% | 20.0% | in range; settled equal |

Summary: 9 of 17 have a CT case, and all 9 typed ranges contain the CT HSZ. 8 are outside CT's 1970-2013 window or
scope: 7 post-2013 exchanges plus JAM 2010. CT has 187 cases, so a CT-based fit has about 10 times the rows (a Tier 1
question for Team B: weights, bank vs bond cases, years). For the 7 post-2013 cases, the 200-year dataset (Meyer,
Reinhart, Trebesch 2025) may help, but its file and terms are UNVERIFIED and the adapter refuses its layout until a
parser is written from the file.

Notes for Team B: when a typed row matches two CT cases (PAK 1999, RUS 2000), `compare_with_ct` picks the nearest
year, which is a tie, so it takes the first after the sort. Debt/GDP from data is thin (section 5), and
`haircut_source` marks a calibration verified only with at least 3 rows that have debt/GDP.

## 7. Licence register row (proposal for AGENT-04, data/licences.csv)

`cruces_trebesch_haircuts`: match_path `(^|/)panel/(cruces_trebesch_haircuts(\.provenance\.json|\.csv)|research/haircuts/)`;
licence "none stated (UNVERIFIED): Cruces-Trebesch 2014 update, christophtrebesch data page; cite Cruces and
Trebesch (2013) AEJ:Macro 5(3)"; terms_url https://sites.google.com/site/christophtrebesch/data; status
UNVERIFIED; internal_use yes; client_output restricted; validator_nda barred until the authors confirm; redistribution
no (do not commit the workbook); notes "EQ-A-0098; rows with debt_gdp from hazard_panel also imf_derived (EXC-003)".
