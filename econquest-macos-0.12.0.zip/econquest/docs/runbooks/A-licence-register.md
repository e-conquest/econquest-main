# Licence register (EQ-A-0076)

One machine-readable row per source or dataset: `data/licences.csv`, read by `econquest/ingestion/licences.py`.
It brings together licence knowledge that used to be spread across tag constants (`official.IMF_LICENCE`,
`official.theratesapi.THERATES_LICENCE`, `market_history.GOOGLEFINANCE_LICENCE`, ...), `panel/cb_series_verified.csv`
(`licence_ok`), the reason rules in `audit` and `dataroom`, and EXC-003 / EXC-005 in `docs/governance/issues-log.md`.

**The register records licence terms. It does not decide them.** `terms_verified=yes` means only that the terms
were read from the publisher's page and are quoted in the repo. That is true of WRI Aqueduct and CIESIN LECZ
(read 2026-10-25 under EQ-A-0067, docs/runbooks/A-research-datasets.md), of the desk's own adjustments, and, since
EQ-A-0093 (read 2026-10-25, quoted in the `clause` column), of CRAG (Bank of Canada terms), GPR, V-Dem, IEP GTI,
UNDRR, IMF (imf_weo, imf_sdmx, imf_derived), World Bank WDI, IDS and WGI, BIS, ECB, UCDP, GDELT and UNHCR. Sam has
not reviewed any of them. Every other third-party row says `UNVERIFIED`. Where the code lets a source through today
(OECD, Eurostat, FRED, pegs, hand-entered files, seed, prediction markets, CDS quotes), the row says `allowed`
*because that is what the code does*. That is not a licence clearance. Licence
decisions go to Sam through AGENT-08.

## Columns (contract, proposed as C14)

| Column | Values | Meaning |
|---|---|---|
| `source_id` | `[a-z0-9_]{1,40}`, unique | stable id |
| `name` | text | the source or dataset |
| `match_source` | regex (case-insensitive, search) | matched against a provenance `source` text |
| `match_licence` | regex | matched against a licence tag (licence column, licence constant) |
| `match_series` | regex | matched against a provenance `series` text (derived values, e.g. a WEO input) |
| `match_path` | regex | matched against a data-dir relative path with `/` separators (files) |
| `licence_text` | text | the terms as the repo records them, with the constant it mirrors in `[...]` |
| `url` | URL or empty | terms page, only when the repo records one |
| `terms_verified` | `yes` / `no` / `UNVERIFIED` | `yes`: the terms were read from the publisher's page and are quoted in `licence_text` |
| `commercial` | `yes` / `no` / `unknown` | commercial use, as the recorded terms say |
| `internal_use` | `yes` / `no` | `no`: barred from desk numbers (also forces `client_output=barred`) |
| `client_output` | `allowed` / `restricted` / `barred` | `restricted`: internal research only, by an exception or until checked; `barred`: the terms forbid it |
| `validator_nda` | `allowed` / `UNVERIFIED` / `barred` | may go into the independent validator's data room under NDA. `UNVERIFIED`: no licence is stated and Sam has not decided. The room withholds the file until he does |
| `exc_id` | `EXC-nnn` or empty | governance exception |
| `attribution_text` | text | required citation, when recorded |
| `notes` | text | decisions, tickets, code constants |
| `terms_url` | https URL or empty | evidence (EQ-A-0093): the terms page actually read |
| `terms_read_utc` | `YYYY-MM-DD[THH:MM:SSZ]` or empty | evidence: when it was read (needs `terms_url`) |
| `clause` | text, one line | evidence: the clauses read, quoted, tagged `[internal]`, `[commercial]`, `[clients]`, `[redistribution]`, `[validator NDA]`, `[attribution]`. For an `UNVERIFIED` row it says why (page not fetched, no licence stated, terms not settled) |

The three evidence columns are optional on read (`REQUIRED_COLUMNS` are the 16 above them; `REGISTER_COLUMNS` adds
`EVIDENCE_COLUMNS`), so an older 16-column copy still loads. No enforcement rule reads them.

**How the EQ-A-0093 quotes were taken.** The cloud proxy refuses curl to these sites, so each page was read with
WebFetch on 2026-10-25. WebFetch returns quotes of at most 125 characters, so a long clause arrives as consecutive
fragments. In `clause`, ` ... ` marks a joint between fragments, where words may be missing. The quotes are as
returned and were not paraphrased. They were not checked byte for byte against the page HTML: re-read the page before
relying on a single word.

A row matches a record when **any** of its non-empty matchers matches. When several rows match, the most
restrictive one wins: `internal_use` first, then `client_output`, then `validator_nda`. Ties go to the row that matched
on more fields, then to the earlier row in the file. For example, a BIS policy rate whose series names WEO PCPIPCH
matches both `bis` and `imf_derived`, and `imf_derived` (restricted) wins.

## API (`econquest.ingestion.licences`)

- `register_path(path=None, data_dir=None)` (EQ-A-0111, HO-20261025-C-A-004): which register file is used. The
  first that applies wins:
  1. `path`.
  2. The register of `data_dir`: the approved version when `econquest change` has one
     (`ops.licence_gov.state(data_dir)["approved_path"]`, used even when data_dir/licences.csv has drifted).
     Otherwise data_dir/licences.csv, when it is a regular file.
  3. The register set by an enclosing `use_register()`.
  4. `$ECONQUEST_LICENCE_REGISTER`.
  5. The package's data/licences.csv.

  With no argument and no `use_register()`, the resolution is the same as before.
- `use_register(path=None, data_dir=None)`: a context manager over a ContextVar, with no environment change.
  - Every hook inside the block reads that register: audit, dataroom, `licence_for`, `require_register`, and the rest.
  - The register is resolved once, on entry. Blocks nest, and the inner one wins.
  - A data folder with no approved version and no licences.csv leaves the current resolution unchanged.
  - A new thread starts without the context.
  - Example: `with licences.use_register(data_dir=mvp_dir): ...`
- `data_dir_register(data_dir)`: the register of one folder, or `None`.
- `load_register(path=None)`: validated rows, in file order. Raises `RegisterError` if the file is invalid, returns
  `[]` if it is missing. The path is `$ECONQUEST_LICENCE_REGISTER` if set, otherwise the package's `data/licences.csv`.
- `licence_for(source=, path=, licence=, series=)`: the matching row, or `None`.
- `cell_licence(provenance_row)`: the row for a provenance or audit-trail record (`source`, `series`, `licence`).
- `file_licence(rel_path)`: the row for a file in the data dir, matched by path.
- `most_restrictive(tags)`: the strictest of a list of tag strings (`allowed` / `restricted` / `barred`), or the
  strictest row from a list of rows or source_ids.
- `register_reason(row, use)`: the reason text used when only the register restricts.
- `column_licences(csv_path)`: column-level tags for a CSV that has a `<name>.provenance.json` sidecar. It reads
  the sidecar's `series` {column: source, licence} and `exceptions` {EXC-nnn: columns}. For example, in
  market_history/prices.csv only the theratesapi columns resolve to `theratesapi` (EXC-005); the BIS columns resolve
  to `bis` and XOF to `peg`. `file_licence` still tags the whole file with its strictest column, and that is what
  the data room uses.
- `validate_register(rows, where)`: the public check behind `load_register`. Team C's presentation/licences.py
  should call this instead of `_validate`, which is kept as an alias. Match regexes that can match the empty string
  are refused.
- `register_problem()`: returns `None`, `missing: <path>` or `invalid: <error>`.
- `require_register()`: raises `RegisterError` when the register is present but invalid.
- `invalid_reason()`: the fail-closed reason, or `None`.

## Hooks (existing behaviour unchanged)

`audit.restricted_reason`, `audit.client_output_reason` and `dataroom.restricted_reason` check the register first:

- `internal_use=no`, `client_output` restricted or barred, or `validator_nda=barred` restricts the record or file.
  The reason is the existing rule's text when the old rule also restricts it, so the wording does not change.
  Otherwise the reason is `licence register <id>: ...`.
- A row that allows the use, or no matching row, falls back to the old rules (`_restricted_reason_rules`,
  `_client_output_reason_rules`, `dataroom._restricted_reason_rules`). The register can add restrictions. It can
  never remove one.
- One exception to keeping the old wording: the IMF text (`CLIENT_RESTRICTED_REASON`) is kept only for the IMF rows
  (`audit.REGISTER_IMF`: imf_weo, imf_sdmx, imf_derived). A research dataset tagged `internal research use only`
  used to get the IMF text through the generic licence-term rule. It now gets the register's reason naming its own
  row, for example `licence register wjp: restricted for client output (...)`.
- `validator_nda=UNVERIFIED` withholds a file from the room, the same as `barred`. The reason says that Sam has not
  decided.
- `cb_registry` and `fx_manual` (`audit.REGISTER_CLEARABLE`) leave the decision to the per-series `licence_ok`
  check in `panel/cb_series_verified.csv` (EQ-A-0060).
- `dataroom.restricted_reason` checks the file's path and, for a CSV other than `index.csv`, each distinct value
  in its licence column.
- **Missing register:** the hooks run the old rules only.
- **Register present but invalid** (AGENT-05 review, SEC-A-010 L3): the hooks **fail closed**.
  - Every record is restricted, both for desk use and for client output, and every file is withheld from the room,
    with the reason `licence register invalid (...)`.
  - A loud warning prints once (RuntimeWarning plus a banner on stderr).
  - `build_data_room` refuses with `RegisterError`.
  - The evidence build is asked to do the same (Team C handoff).
- **Code rule on the old-rules path:** a file under `panel/research/<key>/` is withheld unless `research.REGISTRY`
  says that key is `client_ok=True` (V-Dem, Aqueduct, UCDP). An unknown key is withheld too.

Restrictions the register adds today (where the old rules let the record through):

| Row | What changes | Why |
|---|---|---|
| `acled` | barred from desk numbers, client output and the room | ACLED is off pending a corporate licence (EULA 1.2). No ACLED rows exist |
| `fred_oecd` | client output restricted, room barred, for any row tagged `spreads.OECD_FRED_LICENCE` | the constant says "no client output, no data room", but its wording ("internal research only") escaped `CLIENT_RESTRICTED_LICENCE_TERMS` |
| `ecos` | client output restricted, room barred | BoK ECOS terms unverified. Restricted by default (AGENT-05 review). `spreads.is_restricted()` reads this row, so ECOS spread rows are `restricted=True` (AGENT-02, EQ-A-0078) |
| research datasets with no stated licence (wjp, coups, goci, ndgain, epr, unhcr) | withheld from the room (`validator_nda=UNVERIFIED`) | no licence stated, so the default is all rights reserved. The validator decision is Sam's (A-research-datasets.md). No files under `data/panel/research/` today |
| gti, undrr, ipc | barred from desk numbers, client output and the room | GTI: commercial licence must be bought. UNDRR: personal, non-commercial, no derivatives. IPC: all rights reserved, not used. No adapters exist |

`tests/test_licences.py` checks these against the list above. It also checks that every `research.REGISTRY` entry
(EQ-A-0067) resolves to its own row by tag, source label and `data/panel/research/<key>/` path, and that `client_ok`
agrees with `client_output`. Any new divergence between the register and the code
fails the test.

## Consistency test

`tests/test_licences.py` covers:
- every licence tag constant in the code;
- every reason constant (`RESTRICTED_SOURCE_REASON`, `CLIENT_*_REASON`, `YAHOO_FILE_REASON`,
  `GOOGLEFINANCE_FILE_REASON`, `THERATES_ROOM_REASON`, `SPREADS_RESTRICTED_REASON`).

Each must resolve to a register row whose `internal_use`, `client_output` and `validator_nda` agree with what the old
rules do, apart from the documented tightenings. When you add a licence constant, add a row and a `TAGS` entry.

## Report

```
python -m econquest.ingestion.licences report --data data          # text, most restrictive first
python -m econquest.ingestion.licences report --data data --csv    # one row per source
python -m econquest.ingestion.licences check                       # validate the register
```

For each source_id the report lists:
- the cells, which are `audit_trail.csv` and `live/provenance.csv` records by (table, key, country), not matched to
  applied values (`audit restricted` / `audit client` do that matching);
- the files in the data dir;
- the source's tags.

Rows no register entry matches are listed under `(no register row)`. The report ends with a list of sources the code
allows for client output whose terms are unverified.

## Changing a row

1. Change only what a source document or a decision of Sam's supports, and cite it in `notes`. Never invent terms.
2. Run `python -m econquest.ingestion.licences check` and `python -m pytest -q tests/test_licences.py tests/test_audit*.py tests/test_dataroom.py -p no:cacheprovider`.
3. If the change loosens a restriction, the old rules may still restrict the record. Loosening needs a change to the code rule as well, which is Sam's decision.
4. Change control (R44, EQ-C-0106). `econquest change` now lists licences.csv (`ops.approvals.FILES`,
   `ops/licence_gov.py`). However, a proposal is accepted only against an approved register, and none exists yet:
   the first approval is Sam's baseline on the Mac (`licence_gov.FIRST_BASELINE_CMD`). EQ-A-0093 was therefore
   edited directly, as in PI-8. Sam's first baseline approves these edits too: `terms_verified` UNVERIFIED to yes,
   `commercial` to yes, and the new `licence_text` / `attribution_text`. licence_gov classes all of these as
   loosening. After the baseline, every edit goes through
   `econquest change propose licences.csv --replace-file <copy> --author <agent> ...`. Use `--replace-file`, not a
   patch: in patch mode `licence_gov.text_of` writes the C14 columns only. Team C has been asked to carry the
   evidence columns through and to class them as neutral (handoff in the EQ-A-0093 log).

## Data room labels (EQ-A-0091, HO-20261025-C-A-001 item 3)

`dataroom.build_data_room` labels the room from the register directly (`dataroom.licence_labels`). It does not
import from presentation.

- **README "Licences and attribution":** one line per register source present in an exported file. Each line gives
  the source's client-output tag, its EXC id and its `attribution_text`. Every `client_output=allowed` row carries
  an attribution line (tested).
- **README "Files holding client-restricted content":** every exported file with content whose row says restricted
  or barred, with the restricted columns where a provenance sidecar names them. For example, prices.csv lists only
  its six EXC-005 columns.
- **How a file's sources are found:** the file's path row, plus each value in its licence columns, plus the
  source/series records of files that also have a value column. Metadata tables such as cb_series_verified.csv
  only name sources, so their `source` column is not read.
- **MANIFEST.json:** the same data is stored under `licence_labels`, inside the hashed manifest.

## Seed cells: recommendation (HO-20261025-B-A-001 item 4; not applied)

Today's behaviour is unchanged. The `seed` row is `allowed`. However, `audit.client_output_reason` restricts any seed
cell whose `series` names an IMF or WEO source, through the `imf_derived` series rule. Team B's client-safe run looks
seeds up on their source only, so it keeps those cells. The two disagree on the seeds whose series names an IMF source. Team B counts 305 cells. `licences report` counts
292 audit-trail seed records under `imf_derived`.

Recommendation for Sam:
- Class a seed by what its value came from, not by what source it was meant to come from.
- An analyst/Claude seed whose recorded basis is an IMF publication (dsa_inputs.csv and Country Profile seeds
  "from IMF Article IV") is IMF-derived content. Treat it as `imf_derived` (client output restricted, EXC-003) until
  an official non-IMF value replaces it.
- Other seeds stay `seed` (allowed, the desk's own estimate).
- To do this, the seed rows would need a basis column. "Intended" series text is not evidence of where a value came
  from.
- Until Sam decides, client products should use the stricter audit reading. That is a tightening, so Team B can
  adopt it without a decision.

## Open decisions for Sam (through AGENT-08)

Superseded in part by "PI-9 decisions for Sam" below (EQ-A-0093): the terms of BIS, ECB, World Bank, GDELT, CRAG,
GPR, V-Dem, GTI, UNDRR, UCDP, UNHCR and IMF are now read and quoted. Still open from PI-8:

- Rows `allowed` for client output only because the code allows them, terms not read: OECD, Eurostat, FRED, pegs,
  prediction markets, CDS quotes, seed (not in EQ-A-0093).
- IPC: the API key and its terms.
- Seed classing: see the recommendation above.
- Change control: licences.csv is now in `econquest change` (R44, EQ-C-0106), but it has no approved baseline yet.
  Client output stays refused until Sam baselines it on the Mac (see "Changing a row", step 4).
- ACLED: corporate licence (the row is barred until then).
- Validator under NDA: the BIS, World Bank and CRAG terms read under EQ-A-0093 allow redistribution with attribution,
  which covers the room. The hand-entered files are still not checked (docs/validation/engagement/timeline.md item 4).

## PI-9 decisions for Sam (EQ-A-0093, terms read 2026-10-25)

Current setting = internal_use / client_output / validator_nda as in data/licences.csv today. Nothing in the
current settings was changed. Every proposed loosening below is waiting for Sam. The quotes are in the `clause`
column. Client mode is off, so none of these changes output today. "Effect" describes what happens once client
mode is on.

| # | Source | What the terms say (one line) | Current | Proposed | Effect on output |
|---|---|---|---|---|---|
| 1 | CRAG (BoC-BoE) | Bank of Canada site terms: free use, copying and distribution with attribution. Anything sold must tell buyers the content is free on bankofcanada.ca. No CRAG-specific terms; joint BoC-BoE work | yes / allowed / allowed | Keep. Add the "available free of charge from the Bank of Canada" notice to client packs | No number moves. One notice line in client packs |
| 2 | GPR (Caldara-Iacoviello) | CC BY: use, distribute and reproduce in any medium, crediting source and authors | yes / allowed / allowed | Keep (decision on the earlier open question: the terms allow it) | None. Citation now the 2022 AER paper |
| 3 | V-Dem | CC BY-SA 4.0, commercial use allowed. Derivatives must use the same licence | yes / allowed / allowed | Sam decides whether ShareAlike reaches scored output. If unsure, restrict the scored indicator only | If restricted: V-Dem-based scores leave client output |
| 4 | ECOS (Bank of Korea) | Terms page could not be fetched (site error, JS shell). UNVERIFIED | yes / restricted / barred | Keep. Sam reads the ECOS terms on the Mac or asks BoK | ECOS spread rows stay restricted |
| 5 | GTI (IEP) | CC BY-NC-SA, non-commercial only. Companies must buy a commercial licence before downloading | no / barred / barred | Keep. Buy the licence (about USD 2,000) or leave 6.13 to the analyst | 6.13 stays analyst-set |
| 6 | UNDRR | Personal, non-commercial use only. No redistribution or derivative works | no / barred / barred | Keep. Write to UNDRR, or keep 7.1/7.2 analyst-set | 7.1/7.2 stay analyst-set |
| 7 | IMF | Data may be used, derived, published and distributed with "Source: International Monetary Fund, ...". Commercial reuse needs permission (copyright@imf.org). Automated bulk download needs permission | yes / restricted / allowed (EXC-003) | Keep. Sam emails copyright@imf.org for (a) client output and (b) the automated WEO/SDMX pulls | IMF cells stay out of client output. Flag: (b) concerns internal pulls too |
| 8 | World Bank WDI, IDS, WGI | CC BY 4.0 per catalog entry; commercial use free; "The World Bank: Dataset name: Data source". Third-party indicators may carry their own terms | yes / allowed / allowed | Keep. Follow-up: check indicator metadata for third-party sources (for example IMF-sourced reserves) | None now. A third-party restriction found later would tighten those series |
| 9 | BIS | Statistics use unrestricted if the BIS is cited, the use is not misleading, and a commercial product charges nothing extra for them | yes / allowed / allowed | Keep, with the condition that client pricing never charges for BIS content | None. Pricing condition |
| 10 | ECB | Free reuse, commercial too, with "Source: ECB statistics." and the statistics unmodified. Third-party data excluded | yes / allowed / allowed | Keep. Label derived values (crosses) as econquest-derived, not as ECB statistics | None. Labelling |
| 11 | theratesapi / Banca d'Italia | Mirror states no licence. BdI site: personal use only, no use for profit, no modification, no republishing without written permission. BdI open data are CC BY 4.0, but whether the FX rates count as open data is UNVERIFIED | yes / restricted / allowed (EXC-005) | Sam asks BdI (or checks its open-data catalogue) whether the rates are CC BY. If yes: may loosen. If no: EXC-005 rests on Sam's risk acceptance, and the validator setting should become barred | If barred: the 6 EXC-005 columns of prices.csv leave the validator room |
| 12 | UCDP | CC BY 4.0, use and redistribute with citation | yes / allowed / allowed | Keep | None |
| 13 | GDELT | Unrestricted use, commercial included. Cite GDELT and link gdeltproject.org | yes / allowed / allowed | Keep | None |
| 14 | UNHCR | Terms of Use for Datasets: Refugee Population Statistics Database under CC BY 4.0. Third-party datasets excluded | yes / restricted / UNVERIFIED | Loosen to allowed / allowed (Sam). Code tag research/unhcr.py must change too (AGENT-01) | The UNHCR indicator can reach client output and the room |
| 15 | WJP, Powell-Thyne coups, GI-TOC, ND-GAIN, EPR | No licence on any page read. Default: all rights reserved | yes / restricted / UNVERIFIED | Ask the authors for written terms. Keep as is meanwhile. Sam also decides whether internal desk use is acceptable meanwhile | None (already withheld from clients and room) |
| 16 | Cruces-Trebesch haircuts (EQ-A-0098) | No licence, terms or redistribution clause on the page | yes / restricted / barred | Ask the authors for terms. Keep restricted / barred | Haircut data stays internal |
| 17 | Team B ask: 52 data files with no row (client-safe comparison 2026-10-23), now 5 rows: desk_config (19), desk_metadata (13), desk_model_records (3), live_pipeline_mixed (13), third_party_unverified (4) | No terms read. The first three groups hold desk-authored records, metadata or model outputs. live_pipeline_mixed mixes values from sources that already have rows. third_party_unverified holds agency ratings, spreads, index labels and a default-episode list of unrecorded origin | none (no row): left out of client output, exported to the validator room | Now: yes / restricted / allowed (first four groups), yes / restricted / UNVERIFIED (third_party_unverified). Proposed for Sam: (a) clear desk_config, desk_metadata and desk_model_records for clients (own records, no third-party licence); (b) name the sources of benchmarks.csv, the staging countries/meta files and sovereign_defaults.csv, so they can take their real rows | Client output: unchanged (already left out). Room: benchmarks.csv, panel/universe_staging/countries.csv, universe_meta.csv and panel/sovereign_defaults.csv are now withheld from the validator until Sam decides |
| 18 | live/raw_research.csv and its vintages (AGENT-01) and data/live/market/snapshots/ (vendor CDS store, Team B EQ-B-0100): rows research_raw and vendor_market_snapshots | No terms read. raw_research rows carry each dataset's own licence; the snapshots hold vendor quotes, and no contract has been read | none (no row) | yes / restricted / allowed, terms UNVERIFIED. validator_nda is set to allowed so the room behaves as today: it still checks each row's licence column (wjp rows withheld, bloomberg/lseg rows barred). Sam may withhold the folders from the room instead | The client-safe copy leaves both out. Room: unchanged |

Also for Sam:
- Rows 17 and 18 were added on request, not from terms that were read, and they only tighten. validator_nda stays
  `allowed` except on third_party_unverified. A path row set to `barred` would have withheld the audit trail,
  provenance, approvals log and vendor snapshots from the validator room. That is a separate decision, and it is Sam's.
- Setting `terms_verified=yes` counts towards Team C's client gate (`client_decision` licence_verification). It
  records that the terms were read, not that counsel or Sam cleared them.
- R44: the register has no approved version yet. Sam's first baseline on the Mac (`licence_gov.FIRST_BASELINE_CMD`)
  approves the register as it stands, including these EQ-A-0093 edits.


## Attribution lines: provenance and verification (EQ-A-0113, HO-20261025-B-A-003)

On 2026-10-25 the template placeholders in `attribution_text` were replaced (display text only; licence class,
`internal_use`, `client_output` and `validator_nda` unchanged). The register has no `attribution_verified` column, so
the state is recorded here. Every name and link comes from text already in the repo; none was fetched or invented.

| source_id | Dataset title and link used | Where it is stated in the repo | Attribution verified |
|---|---|---|---|
| imf_weo | "World Economic Outlook Database"; api.imf.org SDMX 3.0 dataflow IMF.RES/WEO, `https://api.imf.org/external/sdmx/3.0` | the row's own attribution_text (title); `official/imf_weo.py` docstring and `WEO_AGENCY` / `WEO_LATEST_FLOW`; `official/imf.py` `IMF_BASE` | no: the link is the API the feed calls, not an IMF dataset page (no WEO dataset page URL is recorded in the repo) |
| imf_sdmx | no single IMF database title is recorded, so "IMF data portal statistics as named in econquest (CPI, MFS, FSI, IRFCL, IIP, REER, policy rate)"; `https://data.imf.org/en/Resource-Pages/IMF-API` | the row's `name`; `official/imf.py` docstring and `IMF_SPECS` | no: the IMF's own dataset titles for these flows are not recorded |
| worldbank_wdi | "World Development Indicators"; `https://datacatalog.worldbank.org/search/dataset/0037712` | the row's `clause` (WDI catalog entry); `api.worldbank.org` in the feed code | no: the per-indicator "Data source (if known)" part of the World Bank form is not recorded, and the line says so |
| worldbank_ids | "International Debt Statistics"; `https://datacatalog.worldbank.org/search/dataset/0038015` | the row's `clause` (IDS catalog entry); `api.worldbank.org` in the feed code | no: as for WDI |

The IMF terms (quoted in `clause`) require any material transformation to be stated with the citation. The IMF
lines now say "Values may have been rescaled or combined by econquest." A per-figure statement is a Team B product
matter. Before a client release, someone should read the IMF and World Bank dataset pages and confirm the titles and
links. This is a desk check, not a Sam decision.
`data/mvp/data/licences.csv` is regenerated from this register by AGENT-06 (EQ-A-0110), never hand-edited.
