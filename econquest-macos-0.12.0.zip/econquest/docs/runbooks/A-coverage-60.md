# Coverage to 60%: projection, ranked gaps and plan (EQ-A-0078)

Team A, AGENT-02, 2026-10-25. This ticket is analysis, tooling and docs. No data cell was changed.

**Target.** Sam set the target on 2026-10-24 at 12:41Z (EQ-A-0055): 60% of the feed-eligible cells per desk country.
That is 30 of the 50 ids in `data/panel/coverage_source_map.csv` whose `candidate_source` is not `manual-only`. For
the 18 desk countries it is 540 of 900 cells.

**Reproduce every number on this page:**

```
python -m econquest.ingestion.coverage_gaps rank --data data \
    --report team/inbox/pull-20261024T183257Z/report.json \
    --projection docs/runbooks/A-coverage-60-projection.csv --out docs/runbooks/A-coverage-60-rank.csv
```

* `rank` builds the part-3 gap matrix (`coverage_gaps.build`). It then assigns each cell to the cases below
  (`case_flags`), counts them per country (`project`), and ranks the residual gaps of case b (`rank`; use `--case` to
  rank another case).
* It writes only the two CSVs you name. It never writes into `data/`.
* Read the CSVs with `coverage_gaps.read_matrix`, which reads every column as text. If ids are read as numbers,
  2.1 and 2.10 collide.
* Tests: `tests/test_coverage_gaps_rank.py`.

## 1. Headline

| Case | What it assumes | Live cells (of 900) | Share | Countries at 30 of 50 |
|---|---|---|---|---|
| **a** today | the shared `data/live` pull (2026-10-23) | **224** | 24.9% | **0** |
| **b** after the 0.4.2 Mac rerun | built adapters verified; 2.2 served by the IDS World counterpart; WDI 5.9 held; BIS fallbacks the 0.4.0 pull showed failing left out | **322** | 35.8% | **0** |
| b, without the 0.4.0 report evidence | as b, keeping the IMF 2.12 and 5.13 fallbacks | 339 | 37.7% | 0 |
| b_upper (part-3 "expected") | every built and configured adapter serves | 348 | 38.7% | 0 |
| **c** after EQ-A-0067 | b + every research dataset serves its indicators (15 ids, plus 6.10 with EPR) | **610** | 67.8% | **16** (not VEN, SEN) |
| c_strict | c, minus cells that also need a Team B rule, a token, or a licence or credential decision | 394 | 43.8% | 0 |
| d (plan bracket) | c + the S-effort adapters in section 4 (IMF codes, CRAG 1.8) | 736 | 81.8% | 18 |

* **The official route alone cannot reach 60%.** At the b_upper bound the best country has 21 of 50.
* **Case c meets 60% overall, and for 16 of 18 countries, only if every gate in section 3 opens.** That means the
  UCDP token, four Team B rules, and Sam's licence decisions on GTI, UNDRR and IPC.
* **With today's gates (c_strict), no country reaches 30.**
* **Venezuela and Senegal miss 30 even in case c.** Venezuela has 27 and Senegal 26. Both need the case-d adapters.
  They are short mainly because the WEO has no value for them in the fetch year (section 5).

The 0.4.0 staged pull (Sam's Mac, 2026-10-24T18:50Z, `report.json` universe step) covered the 88-country universe.
It had 27.59% of feed-eligible cells live and 0 of 88 countries at target. 352 cells were held by the quality gate.
The report gives counts, not countries, so case a uses the shared desk pull. The 88-country per-cell file
(`live/pullpack/universe_missing_cells.csv`) is still on the Mac.

## 2. Projection per desk country (30 of 50 needed)

From `A-coverage-60-projection.csv`. The b (no report) column is b_upper minus the WDI 5.9 cell, which only the
9 non-BIS names have.

| iso3 | a today | b rerun | b (no report) | b_upper | c research | c_strict | d plan | short of 30 in c |
|---|---|---|---|---|---|---|---|---|
| VNM | 12 | 18 | 20 | 21 | 34 | 22 | 41 | 0 |
| PHL | 14 | 20 | 20 | 21 | 36 | 24 | 43 | 0 |
| CHN | 15 | 21 | 21 | 21 | 37 | 25 | 44 | 0 |
| MYS | 14 | 18 | 18 | 18 | 34 | 22 | 41 | 0 |
| SGP | 12 | 16 | 16 | 16 | 32 | 20 | 39 | 0 |
| JPN | 13 | 17 | 18 | 18 | 33 | 21 | 40 | 0 |
| KOR | 14 | 18 | 18 | 18 | 34 | 22 | 41 | 0 |
| IND | 15 | 21 | 21 | 21 | 37 | 25 | 44 | 0 |
| PAK | 12 | 18 | 20 | 21 | 34 | 22 | 41 | 0 |
| BLZ | 12 | 18 | 20 | 21 | 34 | 22 | 41 | 0 |
| BRA | 15 | 21 | 21 | 21 | 37 | 25 | 44 | 0 |
| ARG | 15 | 21 | 21 | 21 | 37 | 25 | 44 | 0 |
| COL | 15 | 21 | 21 | 21 | 37 | 25 | 44 | 0 |
| VEN | 7 | 11 | 13 | 14 | 27 | 15 | 34 | **3** |
| NGA | 12 | 18 | 20 | 21 | 34 | 22 | 41 | 0 |
| SEN | 4 | 10 | 12 | 13 | 26 | 14 | 33 | **4** |
| ZMB | 12 | 18 | 20 | 21 | 34 | 22 | 41 | 0 |
| ZWE | 11 | 17 | 19 | 20 | 33 | 21 | 40 | 0 |
| **18** | **224** | **322** | **339** | **348** | **610** | **394** | **736** | |

## 3. Assumptions (every case; `coverage_gaps.CASE_ASSUMPTIONS` holds the same text)

A cell counts as live only when a named source serves it under the case's assumption. Seed values in
`indicators.csv`, `dsa` outputs and manual entries never count.

**Case a: today.**
* A cell is live when it is finite in `data/live/live_inputs.csv` (the 2026-10-23 desk pull) and not held in
  `review.csv`.
* Nothing else counts.

**Case b: after the 0.4.2 Mac rerun.** Case a, plus every `adapter_unverified` cell:
* 2.11 and 7.10: World Bank additions (18 each).
* 3.4 and 3.5: the WGI fix (18 each).
* 2.9: the IDS fallback (13).
* 2.2: 13 cells, the IDS countries, through the EQ-A-0068 World counterpart (`official/worldbank.fetch_ids`,
  counterpart code `WLD` UNVERIFIED).
* 5.13 and 2.12: BIS fallbacks.

Three conditions apply:
1. **Verification.** The quality gate holds every official-adapter value until the map row says `verified=yes`
   (`official/gate.py`, check `unverified`). Case b assumes that the rerun's response confirms the codes and that
   Team A then sets the flag (A-fetch-on-mac.md). Until then these cells are held, not live.
2. **WDI 5.9 is held.** The 9 cells are left out of b because `wdi_extra.METHOD_APPROVED` is empty and the gate holds
   them with check `method`.
   * Team B has answered HO-20261024-A-B-011: 5.9 is approved with five changes, and 2.12 with one change (a stale
     hold).
   * The changes are not built yet. Until a Team A ticket builds them, adds 5.9 and 2.12 to `METHOD_APPROVED`, and
     sends Sam the batch effect, expected coverage is **348 with these cells and 339 without them** (the AGENT-05
     review item).
3. **Report evidence (`--report`, `B_EVIDENCE`).** On the 0.4.0 staged pull:
   * 57 of 88 countries had no 5.13 value ("IMF SDMX returned no observation for policy_rate").
   * 34 of 88 had no 2.12 value ("no PX.REX.REER value").

   The report has no per-country rows, so b leaves out these fallbacks for every desk country they would fill:
   9 cells of 5.13 and 8 cells of 2.12. That accounts for 322 against 339.

The other EQ-A-0068 fixes add **0 Inputs cells**:
* The WEO routes feed `panel_history`.
* PV.EST feeds the layer-1 hazard panel's `pitf_instability` (`validation/hazard_panel.py`).
* They matter for the hazard refit, not for this metric.

**Case c: after EQ-A-0067.** Case b, plus:
* every `no_adapter` cell of the 15 research-dataset ids (3.6, 3.7, 4.3, 4.4, 6.1, 6.7, 6.9, 6.11, 6.12, 6.13, 7.1,
  7.2, 7.8, 7.11, 7.12);
* 6.10, from EPR with the WDI Gini that is already fetched.

Each dataset is assumed to serve all 18 desk countries. Country coverage is UNVERIFIED: V-Dem, GTI and WJP coverage
of Belize, and IPC outside food-crisis countries, are the doubtful cases.

**Case c_strict.** Case c, minus two groups.

Cells that need something besides the dataset (`C_GATES`):
* 6.1: the UCDP token.
* 6.9: the UCDP token and a Team B zero-base rule.
* 6.12: the UCDP token and a Team B neighbour and level rule.
* 4.3, 4.4, 7.12 and 6.10: Team B level mappings.
* 6.11: the IPC coverage rule.

Ids whose every `research.REGISTRY` entry (AGENT-01's EQ-A-0067 code, read when it can be imported) is blocked or
deferred:
* 6.13 GTI: blocked. IEP is CC BY-NC-SA, and commercial organisations must buy a licence.
* 7.1 and 7.2 UNDRR: blocked. There is no country file, and the site terms are personal and non-commercial.
* 6.11 IPC: deferred. It needs an API key and its terms are unread.
* 7.8 CIESIN: deferred. The data ships as an .xlsm file. AGENT-01 proposes WDI EN.POP.EL5M.ZS instead.

**Case d: a plan bracket, not a forecast.** Case c, plus the cells of every indicator whose next step in section 4
is an S-effort adapter on an unconfigured or no-adapter cell:
* the IMF transforms 1.2, 2.3, 2.4, 5.1, 5.2 and 5.11, once their codes are set on the Mac;
* the CRAG 1.8 count.

Each is assumed to serve every desk country. The FSI encouraged set (2.4, 5.2) is known to be sparse. Without those
two ids, d still gives 18 of 18 countries at 30 or more, and step 4 of section 5 still gives 16.

## 4. Residual gaps of case b, ranked by model weight x countries missing

**Model weight.** The model weight of an indicator is its share of the composite:
`assumptions.json scorecard.pillar_weights[p] x rulebook.csv weight` (pillar weights sum to 1, and indicator weights
sum to 1 in each pillar). It goes in through the pillar's weighted average (`scorecard/scoring.py`, read and not
edited). The worst-indicator blend (0.2), the floors and the triggers are not linear and are left out. Belize uses
the small-state weights (pop < 1.5m), which move pillar 7 from 0.05 to 0.15; the ranking uses the standard set.

Other columns in the table:
* `layer1`: the indicator feeds `engine/layer1_hazard.build_features`. Every pillar-4 id feeds it through
  `pitf_instability`.
* `required`: the id is in `scorecard/readiness.REQUIRED_INDICATORS`. A test keeps both lists in step with the
  engine.

The full table, 43 rows with the step, source, licence, effort and owner of each, is `A-coverage-60-rank.csv`. These
are the top 20:

| # | id | indicator | weight | missing | score | engine | next step | kind | source | licence | effort / who |
|---|---|---|---|---|---|---|---|---|---|---|---|
| 1 | 1.1 | Debt service | 0.050 | 18 | 0.900 | | dsa proxy with the analyst average maturity; never live | **manual** | IMF Article IV DSA | IMF terms | Team B analyst via `dsa_inputs.csv`, each Article IV and WEO (Apr/Oct) |
| 2 | 1.2 | FX debt service 24m | 0.0375 | 18 | 0.675 | | configure `irfcl_drains_12m` on the Mac; or ingest dsa 1.2 rows with derived_from=live after the IDS fix | **adapter** | IMF IRFCL II | IMF terms (client-restricted) | S; AGENT-06 + Mac |
| 3 | 2.1 | Net usable reserves | 0.030 | 18 | 0.540 | required | IMF ARA EM file import (JPN, KOR and SGP have no ARA: stay dsa) | **adapter** | IMF ARA file (format UNVERIFIED) | IMF terms | M; annual |
| 4 | 1.4 | Gross financing need | 0.025 | 18 | 0.450 | required | Fiscal Monitor GFN table by hand; adapter only if the Mac finds an FM dataflow | **manual** | IMF Fiscal Monitor | IMF terms | Team A analyst, Apr/Oct, attested like `fx_manual.csv` |
| 5 | 1.5 | FC share of debt | 0.025 | 18 | 0.450 | required | probe WB QPSD (non-OECD); OECD keys for JPN, KOR, COL; bulletins otherwise | **adapter** | WB QPSD (id UNVERIFIED), OECD | WB CC BY (UNVERIFIED) | M + S |
| 6 | 1.8 | Default record | 0.025 | 18 | 0.450 | | 20-year episode count from `sovereign_defaults_crag.csv` (EQ-A-0008, EQ-A-0069), as of the run date; Team B confirms the counting rule | **adapter** | BoC-BoE CRAG | UNVERIFIED (EQ-A-0069, EQ-A-0076) | S; annual with each CRAG update |
| 7 | 2.3 | Hot money | 0.020 | 18 | 0.360 | | configure `iip_portfolio_debt_liab` | **adapter** | IMF BOP/IIP | IMF terms | S |
| 8 | 2.4 | FX deposits | 0.020 | 18 | 0.360 | | configure `fsi_fx_liab_pct` (sparse set) | **adapter** | IMF FSI | IMF terms | S |
| 9 | 3.6 | V-Dem constraints | 0.015 | 18 | 0.270 | | EQ-A-0067 `vdem` (built) | **adapter** | V-Dem v16 | CC BY-SA 4.0 | S; manual download on the Mac |
| 10 | 3.7 | WJP civil justice | 0.015 | 18 | 0.270 | | EQ-A-0067 `wjp` (built) | **adapter** | WJP | none stated: internal only | S |
| 11 | 4.3 | Regime type | 0.015 | 18 | 0.270 | pitf | `vdem` + **Team B level rule** | **adapter** | V-Dem | CC BY-SA 4.0 | S after the rule |
| 12 | 4.4 | Coups | 0.015 | 18 | 0.270 | pitf | `coups` + **Team B level rule** | **adapter** | Powell-Thyne | none stated: internal only | S after the rule |
| 13 | 5.1 | Banks' claims on govt | 0.010 | 18 | 0.180 | | configure `odc_claims_cg`, `odc_total_assets` | **adapter** | IMF MFS ODC | IMF terms | S |
| 14 | 5.2 | FX loans | 0.010 | 18 | 0.180 | | configure `fsi_fx_loans_pct` (sparse set) | **adapter** | IMF FSI | IMF terms | S |
| 15 | 5.4 | Commodity link | 0.010 | 18 | 0.180 | | **accept**: no Team B rule; Pink Sheet is an Excel file | **accept** | | | re-open on a Team B rule |
| 16 | 6.1 | Armed conflict | 0.010 | 18 | 0.180 | required | `events.ucdp` exists; needs the **UCDP token** (Sam requested it) | **adapter** | UCDP GED | CC BY 4.0 | M |
| 17 | 2.2 | External financing need | 0.030 | 5 | 0.150 | | QEDS for SGP, JPN, KOR, MYS (one adapter also serves 2.9 and 2.10); VEN stays seed | **adapter** | WB QEDS (id UNVERIFIED) | WB CC BY (UNVERIFIED) | M |
| 18 | 7.1 | Expected annual loss | 0.0075 | 18 | 0.135 | | UNDRR **blocked**: no country file; non-commercial site terms | **adapter, blocked (Sam)** | UNDRR GAR | personal non-commercial | Sam: licence; else accept |
| 19 | 5.7 | State-owned banks | 0.005 | 18 | 0.090 | | **accept**: BRSS waves are years apart, so the staleness rule holds any value | **accept** | WB BRSS | | |
| 20 | 5.11 | Real deposit growth | 0.005 | 18 | 0.090 | | configure `odc_deposits` | **adapter** | IMF MFS ODC | IMF terms | S |

**Rows 21 to 43.**
* EQ-A-0067 research ids: 6.7, 7.11 and 7.12 are built (7.12 needs a Team B rule).
* UCDP ids: 6.9 and 6.12, which need the token and Team B.
* 6.10: EPR, which needs a Team B rule.
* Blocked or deferred: 6.11 (IPC), 6.13 (GTI) and 7.2 (UNDRR).
* 7.8: deferred, with WDI EN.POP.EL5M.ZS proposed instead.
* Built but held: 2.12 and 5.9, which need a Team B method build. 5.13 needs national central-bank series through
  `CB_REGISTRY` (Singapore: not applicable, accept).
* QEDS: 2.9 and 2.10 for SGP, JPN, KOR and MYS.
* Feed gaps on existing WEO and World Bank ids (accept, re-check each vintage): SEN and VEN 1.3, 1.6, 1.7; SGP 1.6;
  SEN 2.8, 5.5, 5.6, 5.14; VEN, SEN and ZWE 5.10.

**How to read the ranking.** Most of the model weight still missing sits in pillar 1 (1.1, 1.2, 1.4, 1.5, 1.8) and
pillar 2 (2.1, 2.3, 2.4). Most of the cell count sits in the research datasets.
* Two of the five heaviest gaps (1.1 and 1.4) have no free cross-country source. They stay manual and do not count
  toward 60%.
* After those, the cheapest weight is the IMF configs: six adapters of effort S each, already built and waiting on
  one Mac structure check. Next is 1.8 from the CRAG file that is already imported.

## 5. Plan to 30 of 50 per country

Each step adds cells only when its gate opens. The cumulative count comes from the same cell flags (snippet below).

| Step | Gate | Owner | Cells | Share | Countries at 30 |
|---|---|---|---|---|---|
| 0 | c_strict: case b plus the built research adapters (V-Dem 3.6, WJP, GOCI, ND-GAIN) | Mac rerun + EQ-A-0067 wave 2 (feeds wiring) | 394 | 43.8% | 0 |
| 1 | UCDP token (6.1) | Sam (requested) | 412 | 45.8% | 0 |
| 2 | Team B level rules 4.3, 4.4, 7.12, 6.10 | Team B (handoff below) | 484 | 53.8% | 5 |
| 3 | 7.8 through WDI EN.POP.EL5M.ZS (5 m vs 10 m is Team B's call) | Team A + Team B | 502 | 55.8% | 6 |
| 4 | IMF codes for 1.2, 2.3, 2.4, 5.1, 5.2, 5.11 on the Mac, plus the CRAG 1.8 count | AGENT-06 + Sam's Mac | 628 | 69.8% | 16 |
| 5 | 6.9 and 6.12 (token + Team B) | Sam, Team B | 664 | 73.8% | 17 (SEN 29) |
| 6 | 6.11, 6.13, 7.1, 7.2 (licence or credential) | Sam | 736 | 81.8% | 18 |

* **Steps 0 to 4 reach the target overall and for 16 of 18 countries.** None of them needs a licence purchase. The
  Mac work is one structure check per IMF dataflow, plus the CRAG transform.
* **Venezuela reaches 30 at step 5, Senegal at step 6.** Both are held back by WEO cells, which no adapter can fill:
  * Senegal has no WEO year after 2025 for 1.3, 1.6, 1.7, 2.8, 5.5, 5.6 and 5.14.
  * Venezuela has no 1.3, 1.6, 1.7, 2.10 or 5.10.
  * A latest-actual fallback for the WEO would be a Team B rule (raise it if the desk wants SEN and VEN without
    buying GTI).
* The 2.4 and 5.2 FSI encouraged-set series are sparse. Leaving both out of step 4 still leaves 16 countries at 30.

Reproduce the ladder:

```
python - <<'EOF'
from econquest.ingestion import coverage_gaps as C
f = C.case_flags(C.build("data"), "data", "team/inbox/pull-20261024T183257Z/report.json")
gap, quick, cur = f.c & ~f.c_strict, f.d & ~f.c, f.c_strict.copy()
for name, ids in [("0", None), ("1", {"6.1"}), ("2", {"4.3", "4.4", "7.12", "6.10"}), ("3", {"7.8"}), ("4", "Q"),
                  ("5", {"6.9", "6.12"}), ("6", {"6.11", "6.13", "7.1", "7.2"})]:
    cur = cur | quick if ids == "Q" else (cur | (gap & f.id.isin(ids)) if ids else cur)
    t = cur.groupby(f.iso3, sort=False).sum()
    print(name, int(cur.sum()), int((t >= 30).sum()), dict(t))
EOF
```

## 6. Findings

| id | Observation | Evidence | Class | Routed to |
|---|---|---|---|---|
| F1 | The EQ-A-0068 WEO-route and PV.EST fixes change 0 of the 900 Inputs cells. They feed panel history and the hazard panel. | `feeds.WB_HISTORY_SERIES`, `validation/hazard_panel.py:40`, `panel_history.py` | info | AGENT-08 (expectation for the Mac rerun) |
| F2 | HO-20261024-A-B-011 is answered (5.9 approved with 5 changes, 2.12 with 1), but `METHOD_APPROVED` is still empty and the changes are not built. 9 to 17 cells wait on a Team A build. | handoff Response; `wdi_extra.py:60` | structure | AGENT-08: new Team A ticket |
| F3 | The IMF policy-rate fallback (5.13) served no country beyond BIS on the 0.4.0 pull (57 of 88 empty). The 2.12 REER chain left 34 of 88 empty. | `report.json` universe `by_reason` | defect / coverage | AGENT-06 (Mac structure check of the MFS_IR codes) |
| F4 | The 0.4.0 pull held 352 cells at the gate. That is consistent with `verified=no` on the new World Bank and IMF rows. Coverage only moves when the map is flipped after the Mac check. | `report.json` | process | AGENT-06 / Sam |
| F5 | 1.8 can be served from the CRAG file that is already imported. No adapter exists for it yet. | `data/panel/sovereign_defaults_crag.csv` (210 episodes) | coverage | AGENT-06 (new ticket, S) |
| F6 | GTI (6.13) and UNDRR (7.1, 7.2) are licence-blocked in AGENT-01's registry. Case c's 16 of 18 depends on Sam buying or skipping them; c_strict does not. | `research/__init__.py` REGISTRY | licence | Sam via AGENT-08 |
| F7 | Four Team B level rules (4.3, 4.4, 7.12, 6.10) together add 72 cells, more than any other single gate. | section 5, step 2 | Team B rule | handoff to B/AGENT-05 (AGENT-08 to open) |

## 7. Case b against the 0.4.2 pull (Sam's Mac, 2026-10-25T01:43Z)

**Inputs.** All files are in `team/inbox/pull-20261025T013150Z/`:
* `report.json` (universe step);
* `universe_missing_cells.csv`, `universe_missing_countries.csv` (staged vintage 2026-10-25T014122Z-24d2af9e).

**Rerun the case flags against it:**

```
python -m econquest.ingestion.coverage_gaps rank --data data --report team/inbox/pull-20261025T013150Z/report.json
```

The rerun gives the same case b (322). Its evidence is unchanged: 57 of 88 countries have no 5.13 value and 34 of 88
have no 2.12 value.

**The two figures measure different things.**
* 27.6% is the 88-country share.
* The case b projection (35.8%) is for the 18 desk names.
* On the 0.4.2 pull the 18 desk names have **245 of 900 cells live (27.2%)**, with 0 countries at 30. That is 77 cells
  short of case b.
* For the 88 countries, 0.4.2 is the same as 0.4.0 on every total: 1,214 live eligible cells (27.59%), 352 held,
  0 at target.

### 7.1 Did IDS 2.2 serve?

**No. 2.2 served 0 of 88 countries, and 0 of the 13 IDS desk names.**
* **The EQ-A-0068 fix did take effect.**
  * On 0.4.0, 60 countries were refused with "per-creditor IDS rows". On 0.4.2 there are 0 such refusals.
  * The World Bank feed returned 14,067 rows instead of 59,256: one World row instead of one row per creditor.
* **Every 2.2 cell now fails the next step:** "no year with every component". The 88 cells break down as follows.

| Reason on 0.4.2 | Countries |
|---|---|
| no year with every component; every component is present, but no year is common to all of them | 38 |
| none for DT.DOD.DSTC.CD, DT.AMT.DPPG.CD, DT.AMT.PNGB.CD (high income: not in IDS) | 28 |
| none for DT.AMT.PNGB.CD | 19 |
| none for DT.AMT.PNGB.CD, FI.RES.TOTL.CD | 3 |

**Hypothesis (UNVERIFIED; the staged `raw_worldbank.csv` is on the Mac).** The 38 "no common year" cases point at the
fetch window.
* `WorldBankFeed` asks for `mrnev=6`, the 6 most recent non-empty values per series (`feeds.py:388`).
* The IDS amortisation series (DT.AMT.*) carry projection years. Their 6 most recent values are therefore future
  years.
* DT.DOD.DSTC.CD and FI.RES.TOTL.CD end at the latest actual year.
* `official/worldbank.py` then keeps years `<= year` and intersects them. Nothing is left.

**To confirm:** in `/Users/smc/econquest-universe-20261025-0133/live/raw_worldbank.csv`, compare the `period` ranges of
DT.AMT.DPPG.CD and DT.DOD.DSTC.CD for one IDS country (for example BRA).

**If confirmed, the fix is code, not data.** Request an explicit year range for the 2.2 IDS components instead of
mrnev. That belongs to AGENT-06 / AGENT-03 under a new ticket.

The 19 + 3 countries with no DT.AMT.PNGB.CD (private non-guaranteed amortisation) are a separate question: should a
missing PNG series count as 0 or stay blank? That needs a Team B rule.

### 7.2 Held cells (352 for the 88 countries; 77 for the desk names)

The gate's `unverified` hold applies only to the official-adapter ids:
* `IMF_IDS | WB_EXTRA_IDS | WDI_EXTRA_IDS | {1.5}` (`official/gate.py` `gate_checks`);
* the WDI fallback, which is also held with check `method`.

The report and the missing-cell file say "held by quality gate" without naming the check, so the split below is an
upper bound.

| Ids held on 0.4.2 | 88 countries | Desk | Held only because verified=no? |
|---|---|---|---|
| 2.11, 7.10 (World Bank additions; map verified=no) | 176 | 36 | **yes, at most.** `unverified` applies to every cell. A range or stale hold could also apply to some cells; only `review.csv` shows that |
| 5.9 | 55 | 9 | **no.** WDI cells also need `method` (Team B approved with changes in HO-011; not built). BIS cells come under the BIS staleness rule |
| 2.12 | 21 | 5 | **partly.** IMF/WDI fallback cells: `unverified` (+ `method` for WDI). BIS cells: `bis_imf_cross` |
| 5.13 | 5 | 1 | **partly**, same as 2.12 |
| 6.2, 5.14, 2.8, 5.5, 5.12, 3.4, 5.10, 5.6, 2.9, 1.6, 2.10, 1.7, 6.6 (feed ids, most verified=yes) | 95 | 26 | **no.** Held by feed checks (stale, range, crosscheck). Verification does not release them |

**At most 176 of the 352 (36 of the desk's 77) are held only because of verified=no.** A further 81 (desk: 15) need
verification and something else as well.

**What it takes to verify 2.11 and 7.10.** They are World Bank WDI series: TX.VAL.{FUEL,MMTL,FOOD,AGRI,MANF}.ZS.UN
and TX.VAL.FUEL.ZS.UN (A-fetch-on-mac.md).
1. **Sam uploads** the staged `live/review.csv` and `live/raw_worldbank.csv` from
   `/Users/smc/econquest-universe-20261025-0133/`. Nothing else is needed from Sam.
2. **Team A (AGENT-06) checks the data.** The codes must come back with values for the expected countries and years.
   Then spot-check two countries against the World Bank website (data.worldbank.org, the same indicator code):
   one commodity exporter (for example ZMB 2.11) and one fuel exporter (for example NGA 7.10).
3. **Team A sets `verified=yes`** on rows 2.11 and 7.10 of `data/panel/coverage_source_map.csv`. This is a map edit
   under a new ticket, with the evidence in `--ref`. This ticket makes no data changes.
4. **The next desk fetch, or a re-gate of the same vintage, releases the cells.** Expect up to +36 desk cells
   (+176 for the 88 countries), less any cell that `review.csv` shows with a second hold.

For 5.9 and 2.12, step 3 is not enough. The HO-011 changes must be built and the ids added to
`wdi_extra.METHOD_APPROVED`, with Sam told of the batch effect (F2).

### 7.3 Which case-b assumptions failed (desk names, 322 projected against 245 measured)

| Assumption in case b | Projected | 0.4.2 | Gap | Status |
|---|---|---|---|---|
| 2.11 and 7.10 served and verified | 36 | 0 live (36 held) | -36 | **failed: not verified.** The cells were served and are held `unverified` (section 7.2) |
| 2.2 served through the IDS World counterpart | 13 | 0 | -13 | **failed.** The counterpart fix works; the year intersection does not (section 7.1) |
| 2.9 (IDS fallback) served | 13 | 8 live, 4 held, 1 missing | -5 | partly |
| 3.4 (WGI fix) served | 18 | 13 live, 5 held | -5 | partly (held by feed checks) |
| 3.5 (WGI fix) served | 18 | 18 | 0 | **held true** |
| case-a cells stay live | 224 | 18 of them now held: 6.2 -8, 5.5 -2, 5.14 -2, 5.10 -2, 2.8 -1, 5.6 -1, 5.12 -1, 5.13 -1 | -18 | **failed.** Case b assumed nothing regresses. Most likely staleness on the newer reference date (6.2 VC.IHR.PSRC.P5 is a WB_STALE_SERIES id); UNVERIFIED until `review.csv` is uploaded |
| BIS fallbacks 5.13 and 2.12 left out (report evidence) | 0 | 0 new | 0 | held true |
| WDI 5.9 held (method) | 0 | 9 held | 0 | held true |
| **Total** | **322** | **245** | **-77** | |

The 77-cell gap breaks down as 36 + 13 + 5 + 5 + 18. Of the 77:
* 36 need only the verification step above.
* 13 need the 2.2 year-range fix.
* 28 need the gate reasons from `review.csv` before they can be called.

Once 2.11 and 7.10 are verified, the desk total would be about 281 (31.2%), still with 0 countries at 30.

## 8. AGENT-05 review items handled here (via AGENT-08)

* **(a)** Expected coverage is reported both ways, 348 and 339 (section 3). HO-011 has in fact been answered; the
  build is pending (F2).
* **(b)** `wdi_extra.CREDIT_MIN_TREND_YEARS` was unused and is removed. `CREDIT_MIN_YEARS = 15` is the stricter
  count that Team B approved.
* **(c)** Limitation X16 is refreshed in `econquest/ingestion/limitations.py`:
  * the EQ-A-0068 World-counterpart fix is recorded;
  * the 60 of 88 refusals on the 0.4.0 pull are recorded;
  * X16 stays open until the Mac rerun.

  `docs/validation/data-limitations.md` is Team B's file and is regenerated from that module.
* **(d)** `coverage_gaps.read_matrix` reads the module's CSVs with ids as text, and a test checks that 2.1 and 2.10
  stay distinct.
* **(e)** `spreads.status()` now reports, for the latest build, which vintage it came from and that vintage's hash
  check.
* **(f)** Not done: marking a spread series verified still needs a fresh pull. Follow-up in the report.
* **ECOS and SEC-A-010 L5.** `spreads.is_restricted` returns `s.restricted` OR the licence register row
  (`licences.licence_for(source, licence)`) saying anything but client_output=allowed.
  * The register can add a restriction but never lift one the code sets.
  * The ECOS registry default is True, so ECOS rows are restricted.
  * Clearing ECOS (Sam's decision) now takes both the register row and the ECOS flag in `spreads._ENTRIES`.
  * A test removes the `fred_oecd` register row and checks that the 4 IRLTLT01* series stay restricted.

## 9. Verifying 2.11 and 7.10 against the 0.4.2 review (EQ-A-0085, AGENT-06, 2026-10-25)

**Inputs.** Sam uploaded both files to `team/inbox/pull-20261025T013150Z/`: `review.csv` (176 rows for 2.11 and 7.10)
and `raw_worldbank.csv` (14,067 rows, columns iso, series, period, value, source). Nothing was fetched from the
cloud.

**Decision.**
* **7.10: `verified=yes`.** Set in `data/panel/coverage_source_map.csv` (checkpointed under EQ-A-0085).
* **2.11: left at `verified=no`.** The codes are confirmed, but the measure does not match the rulebook definition.
  Team B has to decide the rule (HO-20261025-A-B-005).
* Sam's website spot-check (9.6) is still to do. If it does not match, revert only the map:
  `python team/teamctl.py revert --ticket EQ-A-0085 data/panel/coverage_source_map.csv`.

### 9.1 What review.csv says

All 176 rows have status `hold` and none has a decision. Every row carries `unverified`.

| Reasons | 2.11 | 7.10 |
|---|---|---|
| unverified only | 74 | 84 |
| unverified + change (all desk names, 9.3) | 10 | 0 |
| unverified + stale: VEN latest 2013, SRB 2007, ISR 2022, RWA 2022 | 4 | 4 |
| **Total** | **88** | **88** |

Only the 18 desk names have a seed (36 rows). The other 140 rows have no seed, so the `change` check cannot apply to
them.

**Effect of this ticket.** At the next re-gate or fetch on the Mac:
* 84 of the 88 7.10 cells lose their only hold. For the desk that is 17 of 18; Venezuela stays held as stale.
* All 88 2.11 cells stay held.
* The desk gain is therefore **+17 cells, not the +36** in section 7.2.

### 9.2 Codes, series and periods (raw_worldbank.csv)

* **Codes.** `feeds.WB_SERIES` (feeds.py lines 358-362) and `official/worldbank.py` (`EXPORT_GROUPS`,
  `WB_EXTRA_COMPONENTS`) use the same codes as the map:
  * 2.11 = max of TX.VAL.{FUEL,MMTL,FOOD,AGRI,MANF}.ZS.UN, all five for one year;
  * 7.10 = TX.VAL.FUEL.ZS.UN, latest year.
* **Rows.** Each of the five series has 528 rows covering all 88 countries, every one from source `wbgapi World Bank
  API v2`. No (iso, series, period) appears twice.
* **Values.** Between 0 and 99.99, with none negative and none above 100: a percent scale, not fractions. For each
  country-year the five groups sum to at most 100.0 (520 complete country-years). That is what shares of one
  denominator should do, and it supports that the codes are the WDI "% of merchandise exports" series.
* **Periods used** (the same for both ids):

  | Year | Countries |
  |---|---|
  | 2025 | 57 |
  | 2024 | 18 |
  | 2023 | 9 |
  | 2022 | 2 (ISR, RWA) |
  | 2013 | 1 (VEN) |
  | 2007 | 1 (SRB) |

  The last four are the stale holds in 9.1.
* **Reproduction.** I recomputed every live value in `review.csv` from `raw_worldbank.csv` with the
  `wb_extra_transforms` rule, and all 176 match exactly. Scratch script, not kept in the repo.

### 9.3 Desk names: live against seed

| Country | 2.11 seed | 2.11 live (year, top group) | 7.10 seed | 7.10 live (year) |
|---|---|---|---|---|
| Vietnam | 35 | 84.97 (2023, MANF) **change +143%** | 3 | 0.95 (2023) -68% |
| Philippines | 55 | 76.54 (2025, MANF) +39% | 3 | 0.96 (2025) -68% |
| China | 25 | 90.55 (2025, MANF) **change +262%** | 2 | 1.36 (2025) |
| Malaysia | 40 | 72.75 (2025, MANF) **change +82%** | 20 | 11.17 (2025) |
| Singapore | 30 | 78.21 (2025, MANF) **change +161%** | 15 | 9.41 (2025) |
| Japan | 20 | 80.60 (2025, MANF) **change +303%** | 1 | 1.18 (2025) |
| South Korea | 25 | 87.95 (2025, MANF) **change +252%** | 10 | 6.66 (2025) |
| India | 20 | 70.11 (2025, MANF) **change +251%** | 12 | 13.15 (2025) |
| Pakistan | 55 | 73.20 (2025, MANF) +33% | 2 | 2.44 (2025) |
| Belize | 50 | 95.34 (2025, FOOD) **change +91%** | 2 | 0.01 (2025) -100% |
| Brazil | 15 | 40.73 (2025, FOOD) **change +172%** | 15 | 16.12 (2025) |
| Argentina | 25 | 50.15 (2025, FOOD) **change +101%** | 10 | 9.10 (2025) |
| Colombia | 40 | 34.90 (2025, FUEL) | 50 | 34.90 (2025) |
| Venezuela | 85 | 97.68 (2013, FUEL) stale | 90 | 97.68 (2013) stale |
| Nigeria | 85 | 85.90 (2025, FUEL) | 85 | 85.90 (2025) |
| Senegal | 25 | 32.71 (2024, FUEL) | 20 | 32.71 (2024) +64% |
| Zambia | 75 | 72.99 (2024, MMTL) | 1 | 2.72 (2024) +172% |
| Zimbabwe | 50 | 33.84 (2024, MMTL) | 5 | 2.91 (2024) |

**Differences above 50%.**
* **2.11: 10 rows,** all held by `change`.
* **7.10: 5 rows** (ZMB, BLZ, VNM, PHL, SEN). None is held by `change`, because the absolute move is under a quarter
  of the 5-70 threshold span (16.25 points). Four of them sit below t0 = 5 both before and after.
* **Largest 7.10 moves on the 0-100 threshold scale** (straight line between t0 and t100):

  | Country | Points | Seed -> live |
  |---|---|---|
  | Senegal | +20.1 | 20 -> 32.71 |
  | Colombia | -18.9 | 50 -> 34.90 |
  | Malaysia | -17.9 | 20 -> 11.17 |
  | Singapore | -14.0 | 15 -> 9.41 |
  | South Korea | -8.3 | 10 -> 6.66 |

  These move scores once the cells are released. Sam sees them in the next review.

### 9.4 Outliers, scale and sign (all 88)

* **Sign and scale.** No negative values. No country is on a fraction scale: no seed at 1 or below has a live value
  above 5, and the reverse does not occur either. The near-zero 7.10 values belong to countries that do not export
  fuel: BEN, CRI, HND, ETH, RWA, SUR and BLZ (0.01).
* **Outlier: Bahrain 7.10.** TX.VAL.FUEL.ZS.UN is 42.13 in 2019 and 29.82 in 2020, then 0.05 (2021), 0.04 (2022),
  0.25 (2023) and 0.0004 (2024, the value served).
  * This is a break in the reported series for an oil producer. Its cause is UNVERIFIED.
  * BHR has no seed, so no `change` check will catch it, and 7.10 verified=yes would release it.
  * **Sam: hold BHR 7.10 by a review decision on the re-gate** (`held (decision)`). It is not a desk name.
* **2.11 groups that do not cover all exports.** The five groups sum to well under 100 in some countries:

  | Country | Year | Sum of five groups | 2.11 value |
  |---|---|---|---|
  | SUR | 2025 | 7.2% | 2.35 |
  | GHA | 2025 | 36.9% | 19.7 |
  | UZB | 2024 | 56.2% | |
  | RWA | 2022 | 59.4% | |
  | ZWE | 2024 | 66.0% | |
  | ARG | 2025 | 72.5% | |
  | ALB | 2024 | 76.8% | |
  | GBR | 2025 | 79.7% | |

  Non-monetary gold and other unclassified exports fall in none of the five groups, so 2.11 understates
  concentration for gold exporters.

### 9.5 Codes and units against the rulebook

`docs/validation/indicator-rules.md` has no rule for 2.11 or 7.10, so `data/rulebook.csv` is the definition.

* **7.10.** The rulebook asks for "fossil fuels, % of exports or revenue" from UN Comtrade (HS 27).
  * TX.VAL.FUEL.ZS.UN is fuel (SITC 3, built from Comtrade) as a % of merchandise exports. SITC 3 broadly
    corresponds to HS 27.
  * The denominator leaves out services, so the value reads high against total exports for economies with large
    service exports.
  * The revenue variant stays manual.
  * The map already records both points. **This is an acceptable match.**
* **2.11.** The rulebook asks for "largest commodity or sector, % of exports" from UN Comtrade.
  * The proxy takes the largest of five broad SITC groups.
  * MANF ("manufactures", one group) is the top group for 40 of 88 countries. That makes diversified manufacturers
    (CHN, KOR, JPN, IND, VNM) look as concentrated as single-commodity exporters, and reverses the meaning of the
    indicator.
  * Together with the gold gap in 9.4, **the codes are right but the measure is not the rulebook's.** Releasing the
    74 cells that are held only as `unverified` would put this measure live. They include all 70 unseeded
    countries, which no `change` check covers.
  * Therefore 2.11 stays at verified=no until Team B sets a rule (HO-20261025-A-B-005: options are no WDI proxy, a
    commodity-only max, or as built, plus a floor on group coverage).

### 9.6 Spot-checks for Sam (data.worldbank.org; not done from the cloud)

Compare these values with the chart or table on each page. The site may round, and WDI may have been revised since
the pull.

| # | Country, year | Series | Value in raw_worldbank.csv | URL |
|---|---|---|---|---|
| 1 | Nigeria, 2025 | TX.VAL.FUEL.ZS.UN (7.10) | 85.9038 | https://data.worldbank.org/indicator/TX.VAL.FUEL.ZS.UN?locations=NG |
| 2 | Zambia, 2024 | TX.VAL.MMTL.ZS.UN (2.11 top group) | 72.9900 | https://data.worldbank.org/indicator/TX.VAL.MMTL.ZS.UN?locations=ZM |
| 3 | Bahrain, 2019 and 2024 | TX.VAL.FUEL.ZS.UN (7.10) | 42.1282 and 0.000372 | https://data.worldbank.org/indicator/TX.VAL.FUEL.ZS.UN?locations=BH |

* **If 1 or 2 differ beyond rounding,** revert the map row (see the decision above) and upload the page values.
* **If 3 shows the same break,** the source has it. Keep the BHR hold decision.

### 9.7 Tests

`tests/test_official_feeds.py::test_gate_world_bank_addition_staleness` read the repository map, so it failed once
7.10 became verified. It now writes its own map in `tmp_path`, and also checks that verified=yes leaves only the
`stale` hold.

## 10. Coverage part 4: WDI methods built, gaps re-ranked, two adapters (EQ-A-0084, EQ-A-0096; AGENT-02, 2026-10-25)

**Starting point.** Sam's 0.4.2 pull (`team/inbox/pull-20261025T013150Z/universe_missing_cells.csv`, desk rows):
**245 of 900 desk cells live (27.2%)**, 0 countries at 30. The interim target of 40% is **360 cells** (+115).

Nothing in this section was fetched from the cloud, and no data cell was changed. Every number comes from the
uploaded files or from the repository's `data/`.

### 10.1 EQ-A-0084: Team B's WDI changes are built; `METHOD_APPROVED` is still empty

Team B's decision is HO-20261024-A-B-011 (EQ-B-0086, `docs/validation/indicator-rules.md` section 12). Everything is
in `econquest/ingestion/official/wdi_extra.py`:

| Change | Built as |
|---|---|
| 5.9 (1) break hold | `credit_breaks`: in the run the transform uses (`credit_run`), a year-on-year step of more than 10 pp or more than 50% of the previous level. Gate check `break` (`wdi_gate_rows`) |
| 5.9 (2) and 2.12 stale | `WDI_STALE_YEARS = 2`: held when the latest year up to the as_of year is more than 2 years old. A stricter caller value still wins |
| 5.9 (3) IMF IFS, client-restricted | The provenance series says "IMF IFS via WDI", so `audit.client_output_reason` restricts it (tested) |
| 5.9 (4) label | Provenance starts `rule 5.9 WDI v1: domestic private credit gap (WDI/IFS, annual), not BIS total credit`. "method pending Team B" is removed. The series label says banks and other financial corporations |
| 5.9 (5) BIS comparison | `compare_with_bis` and the CLI `compare`: median of \|WDI gap - BIS Q4 gap\| for the same year, on the names that have a BIS gap. Above 5 pp, Team B reviews (exit 1) |
| `CREDIT_MIN_TREND_YEARS` | Already removed (section 8 b) |

`coverage_gaps.py` texts now say "approved with changes, built, awaiting Sam's Tier 1 sign-off".

**The one-line change for Sam (Tier 1, through AGENT-08).** In `econquest/ingestion/official/wdi_extra.py`:

```
-METHOD_APPROVED: frozenset = frozenset()
+METHOD_APPROVED: frozenset = frozenset({"2.12", "5.9"})
```

Before 5.9 goes in, run the Team B comparison on the Mac. 2.12 does not need it, so it can go in alone with
`frozenset({"2.12"})`.

```
python -m econquest.ingestion.official.wdi_extra compare --year 2026 \
    --raw /Users/smc/econquest-universe-20261025-0133/live/raw_wdi_extra.csv \
    --bis /Users/smc/econquest-universe-20261025-0133/live/raw_bis.csv
python -m econquest.ingestion.official.wdi_extra effect --year 2026 --desk \
    --review /Users/smc/econquest-universe-20261025-0133/live/review.csv \
    --raw /Users/smc/econquest-universe-20261025-0133/live/raw_wdi_extra.csv
```

`raw_wdi_extra.csv` was not uploaded. The `break` hold and the 2-year stale hold therefore cannot be checked from the
cloud for the cells below.

**Batch effect on the shared data** (`effect --review team/inbox/pull-20261025T013150Z/review.csv --year 2026 --desk`).
The holds that remain assume the Mac confirms the codes (map verified=yes). Without that, every cell also keeps
`unverified`. The values are the live values already in the review; nothing is recomputed.

| Cell | Seed -> live | Holds today | Holds after approval | Released | Score seed -> live |
|---|---|---|---|---|---|
| 2.12 Pakistan | 5.0 -> -0.10 | unverified, method | none | yes, unless 2-year stale | 25.0 -> 0.0 |
| 2.12 Belize | 0.0 -> 0.53 | unverified, method | none | yes, unless 2-year stale | 0.0 -> 2.6 |
| 2.12 Nigeria | -40.0 -> -30.88 | unverified, method | none | yes, unless 2-year stale | 0.0 -> 0.0 |
| 2.12 Zambia | -10.0 -> 2.16 | change, unverified, method | change | only by Sam's review decision | 0.0 -> 10.8 |
| 2.12 Venezuela | 30.0 -> 321.89 | range, change, unverified, method, stale | range, change, stale | no (PX.REX.REER ends 2016) | |
| 5.9 Philippines | 0.0 -> 0.21 | unverified, method | none | yes, unless break or 2-year stale | 0.0 -> 2.7 |
| 5.9 Belize | 0.0 -> -2.87 | unverified, method | none | yes, unless break or 2-year stale | 0.0 -> 0.0 |
| 5.9 Nigeria | 0.0 -> 1.85 | unverified, method | none | yes, unless break or 2-year stale | 0.0 -> 23.1 |
| 5.9 Zambia | 0.0 -> 3.40 | unverified, method | none | yes, unless break or 2-year stale | 0.0 -> 36.7 |
| 5.9 Zimbabwe | 0.0 -> 2.19 | unverified, method | none | yes, unless break or 2-year stale | 0.0 -> 26.6 |
| 5.9 Pakistan | -5.0 -> -1.24 | change, unverified, method | change | only by Sam's review decision | 0.0 -> 0.0 |
| 5.9 Senegal | 2.0 -> -2.28 | change, unverified, method | change | only by Sam's review decision | 25.0 -> 0.0 |
| 5.9 Vietnam | 8.0 -> 2.31 | change, unverified, method, stale | change, stale | no (latest year 2022) | |
| 5.9 Venezuela | -5.0 -> 5.94 | change, unverified, method, stale | change, stale | no | |

**Composite effect** (`score_universe` on `data/`, base vs the cells swapped in; scratch script, not kept). The 8
released cells move composites by: Pakistan -0.20, Zambia +0.15, Zimbabwe +0.11, Nigeria +0.09, Belize +0.02,
Philippines +0.01. No grade changes.
* Adding the 3 change-held cells as well gives Zambia +0.23 and Senegal -0.10; the others are unchanged.
* VaR and ES were not rerun. Team C or Team B can run that on the Mac if Sam wants it.
* The same line also releases WDI cells for non-desk names. The review has 46 such 5.9 cells and 16 such 2.12 cells,
  and 56 of the 62 carry no other hold, subject to break and 2-year stale. They do not count toward the desk
  metric, but Sam's review sees them.

**Coverage.** At most +8 desk cells: 2.12 PAK, BLZ, NGA and 5.9 PHL, BLZ, NGA, ZMB, ZWE. A further +3 need Sam's
change decisions.

### 10.2 Remaining feed-eligible gaps on 0.4.2, ranked by model weight

`docs/runbooks/A-coverage-60-p4-rank.csv` lists all 48 ids with a desk gap. Columns:
* `missing` and `held`: from the 0.4.2 desk rows.
* `model_weight`: pillar weight x rulebook weight, as in section 4.
* `route` and `interim_cells`: what closes the gap, and how many cells this section counts toward 40%.

The top 12:

| # | id | weight | missing | Route | Counted |
|---|---|---|---|---|---|
| 1 | 1.1 | 0.050 | 18 | manual; the dsa row is `mixed` (analyst maturity) | 0 |
| 2 | **1.2** | 0.0375 | 18 | **built here: `official/dsa_feed.py`** (10.3) | **9** |
| 3 | 2.1 | 0.030 | 18 | IMF ARA file; dsa rows `mixed` / `estimate` | 0 |
| 4 | 2.2 | 0.030 | 18 | in flight: EQ-A-0086 window + EQ-A-0100 PNGB rule (IDS names) | 13 |
| 5 | 1.4 | 0.025 | 18 | manual | 0 |
| 6 | **1.5** | 0.025 | 18 | **built here: `official/ids_fc_debt.py`**, waits on Team B (HO-20261025-A-B-008) | 0 (+13 later) |
| 7 | 1.8 | 0.025 | 18 | in flight: EQ-A-0092 CRAG count | 18 |
| 8 | 2.3 | 0.020 | 18 | Mac IMF config | 0 |
| 9 | 2.4 | 0.020 | 18 | Mac IMF config | 0 |
| 10 | 3.6 | 0.015 | 18 | research, EQ-A-0095 wiring | 18 |
| 11 | 3.7 | 0.015 | 18 | research, EQ-A-0095 wiring | 18 |
| 12 | 4.3 | 0.015 | 18 | research; the adapter must emit `v2cacamps_osp` first (rule 13.2) | 0 |

**Why only these two adapters.** Outside the in-flight work, the next heaviest gaps have no free source that runs
from the cloud or the Mac without a decision:
* 1.1 and 1.4 are manual.
* 2.1 needs the IMF ARA file.
* 2.3, 2.4, 5.1, 5.2 and 5.11 need one `official.imf structure` run each on the Mac. These are built and only need
  configuring.

1.2 is the heaviest gap a free official series can fill. Its source is named in the rulebook (IDS DT.TDS.DPPG.CD),
Team B's DSA already computes it, and the contract for Team A to ingest it (HO-20261024-A-B-007) is in place. 1.5
is next, through the fallback recorded in the map.
* QEDS for 2.2, 2.9 and 2.10 on MYS, SGP, JPN and KOR would add at most 8 cells at weight 0.01. It is not built; its
  database and codes are UNVERIFIED.
* 2.11 under Team B's rule 15 would add 6 cells. It is not built here, because it belongs in `official/worldbank.py`,
  where AGENT-03 is working (EQ-A-0100).

### 10.3 `official/dsa_feed.py`: 1.2 from `econquest dsa` live rows (+9 desk cells)

This module reads `outputs/dsa_scorecard_feeds.csv` (contract HO-20261024-A-B-007; the columns are tested against
`engine/dsa.FEED_COLUMNS`) and handles each row by its `derived_from`:
* `live` rows are served as feed `dsa`, with source `econquest dsa (derived from live)`;
* `mixed` rows are served and held (`dsa_mixed`);
* `estimate` rows are left unserved, with a reason.

The gate (`dsa_gate_rows`) also holds a cell for four reasons:
* `replay`: no vintage id, or the row comes from another vintage;
* `unverified`: a live input outside `DSA_VERIFIED_INPUTS`;
* `stale`: debt-service years that are not after the DSA base year, or reserves older than 3 years;
* `range`: the value is out of bounds.

For 1.2, the IMF IRFCL source comes first and this feed second.

**Inputs verified offline on the 0.4.2 upload** (`raw_worldbank.csv`):
* DT.TDS.DPPG.CD: 360 rows for 60 countries, with exactly one row per country and year, none negative or blank,
  years 2027-2032. The EQ-A-0068 World-counterpart fix took effect.
* FI.RES.TOTL.CD: 510 rows for 85 countries, one row per country and year.

**Real-data projection.** Team B's `engine/dsa.ppg_debt_service_detail` (base year 2025) and the latest WDI reserves
were run on the upload, and the rows were then put through `dsa_gate_rows`:

| Country | Seed | 0.4.2 value (2027-2028 / reserves) | dsa gate | Feed `change` check | Score seed -> new |
|---|---|---|---|---|---|
| Vietnam | 10.0 | 9.50 (res 2025) | served | ok | 0.0 -> 0.0 |
| Philippines | 15.0 | 14.20 | served | ok | 8.3 -> 7.0 |
| China | 2.0 | 2.70 | served | ok | 0.0 -> 0.0 |
| India | 8.0 | 11.25 | served | ok | 0.0 -> 2.1 |
| Pakistan | **131.40** | **65.70** | served | held (-50.0%) | 100.0 -> 65.7 |
| Belize | 30.0 | 48.68 | served | ok (+18.7 < 22.5) | 30.0 -> 48.7 |
| Brazil | 8.0 | 11.24 | served | ok | 0.0 -> 2.1 |
| Argentina | **72.63** | **36.32** | served | held (-50.0%) | 72.6 -> 36.3 |
| Colombia | 25.0 | 36.22 | served | ok | 25.0 -> 36.2 |
| Nigeria | 30.0 | 29.67 | served | ok | 30.0 -> 29.7 |
| Zambia | 40.0 | 73.89 (res 2024) | served | held (+85%) | 40.0 -> 73.9 |
| Zimbabwe | 150.0 | 182.23 (res 2024) | served | ok (+21%) | 100.0 -> 100.0 |
| Senegal | 80.0 | none: no WDI reserves (WAEMU), so dsa falls back to the profile seed (`mixed`) | held `dsa_mixed` | | |
| MYS SGP JPN KOR VEN | | no IDS projections | not served | | |

This gives **+9 desk cells, with 3 more by Sam's review decision.** Composite effect of the 12 served cells:
* Pakistan -1.03 and Argentina -1.09;
* Zambia +1.02, Belize +0.50, Colombia +0.34;
* every other country under 0.1;
* no grade changes.

**Finding F8 (defect, desk numbers).** The Pakistan and Argentina 1.2 seeds are exactly twice the World-counterpart
value.
* `data/indicators.csv` holds 131.4033 and 72.6303. They were applied on 2026-10-23 by `econquest dsa --apply`
  (`data/audit_trail.csv` rows 28 and 31).
* On that day's pull, `data/live/raw_worldbank.csv` had the World row and every creditor row for DT.TDS.DPPG.CD.
  For each year their sum is 2 x World (PAK 2027: 20.55 bn against 10.28 bn; ARG 2027: 14.86 bn against 7.43 bn).
* The old max-or-sum heuristic (limitation X16) took the sum. Today's dsa refuses such rows.
* The desk therefore carries PAK 1.2 at a score of 100 instead of 65.7, and ARG at 72.6 instead of 36.3.
* Releasing the dsa feed corrects both, through Sam's review of the `change` hold. Route: AGENT-08 to Sam, in the
  same Tier 1 batch.

### 10.4 `official/ids_fc_debt.py`: 1.5 proxy (0 cells now; +13 after Team B, the Mac probe and Sam)

The proxy is 1.5 = IDS DT.DOD.DPPG.CD / (WEO GGXWDG_NGDP x NGDPD) x 100, for the same year (the latest IDS year up
to the as_of year). It is the fallback the map already names. The module holds:
* `unverified`, until the map is set;
* `method`, until Team B answers HO-20261025-A-B-008;
* `range`, for a value above 100;
* `stale`, for data more than 3 years old.

Its values are client-restricted, because one input is WEO. The feed fetches the IDS World counterpart through
`feeds._wb_history_frame`.

**UNVERIFIED:** DT.DOD.DPPG.CD is not in any uploaded pull. Mac probe (exit 0 = rows, no duplicate country-years):

```
python -m econquest.ingestion.official.ids_fc_debt probe
```

### 10.5 Projection to the interim 40% (desk, from the measured 245)

| Step | Gate | Cells | Total | Share |
|---|---|---|---|---|
| 0 | measured on 0.4.2 | | 245 | 27.2% |
| 1 | 7.10 verified (EQ-A-0085): next re-gate on the Mac; VEN stays stale | +17 | 262 | 29.1% |
| 2 | 2.2 IDS names: EQ-A-0086 window + EQ-A-0100 PNGB rule; next Mac pull (Team B reviews if more than 5 desk names fall under rule 4) | +13 | 275 | 30.6% |
| 3 | 1.2 dsa feed (this ticket): feeds.py wiring (10.6), then `econquest dsa` on the pulled vintage before the re-gate | +9 | 284 | 31.6% |
| 4 | 1.8 CRAG count (EQ-A-0092) | +18 | 302 | 33.6% |
| 5 | WDI 2.12 / 5.9 (EQ-A-0084): Sam's sign-off, the Mac `compare` within 5 pp, codes verified; break and 2-year stale UNVERIFIED | +8 | 310 | 34.4% |
| 6 | Research datasets V-Dem 3.6, WJP 3.7, GOCI 6.7, ND-GAIN 7.11 (EQ-A-0095 wiring, layouts verified on the Mac; Belize coverage UNVERIFIED for V-Dem, WJP and GOCI) | +72 | **382** | **42.4%** |
| 7 | UCDP token: 6.1 | +18 | 400 | 44.4% |
| later | 1.5 IDS proxy (+13, Team B + Sam); change-held releases (+6: 1.2 PAK, ARG, ZMB; 2.12 ZMB; 5.9 PAK, SEN); 2.11 rule 15 (+6); 5.13 central banks (+9, Mac); IMF configs 2.3, 2.4, 5.1, 5.2, 5.11 (+90, Mac) | | | |

* **40% is reached at step 6 and depends on the research wiring (EQ-A-0095).** Official routes alone, steps 1-5,
  give 310 (34.4%).
* Steps 1-5 plus UCDP give 328 (36.4%).
* Steps 1-5 plus UCDP and every "later" item that needs no Mac configuration (1.5, the change releases, 2.11, 5.13)
  give 362. That is only just 40%, and it rests on four separate decisions.
* The Mac IMF configs are the largest lever outside the research datasets, at 18 cells per id.
* No step has been measured yet. Each count is a ceiling that the next Mac pull confirms or cuts.

### 10.6 feeds.py wiring needed (after AGENT-08 releases feeds.py; not done here)

1. **`dsa` feed.**
   * `fetch_all` / the re-gate takes a `dsa_feeds` path (default `outputs/dsa_scorecard_feeds.csv`), reads it with
     `dsa_feed.read_dsa_feeds`, and puts it in `raw["dsa"]`. It never fetches.
   * `official/wiring.country_cells` calls `dsa_feed.dsa_cells(raw.get("dsa"), country, iso, have, filled,
     vintage_id, year, tlog, unserved)` after the IMF block.
   * `official/gate._feed_of` maps source `econquest dsa (derived from live)` to `dsa`. `gate_checks` calls
     `dsa_gate_rows(key, n, value, series, raw.get("dsa"), vintage_id, year, stale_years)` for keys 1.1, 1.2 and 2.1.
   * Add `dsa` to `FEED_HOSTS` with no host (offline) and keep it out of the default `--only` list.
   * The pull order matters, and the pullpack order (AGENT-06 / Team C) must change with it: fetch, then
     `econquest dsa --as-of <date>` on the new vintage, then the re-gate with `dsa`. A dsa row from another vintage
     is refused.
2. **`ids_fc_debt` feed.**
   * `FEED_HOSTS["ids_fc_debt"] = (WB_HOST,)`, and add it to `FEED_ALIASES["worldbank"]`.
   * `official/wiring.fetch_plan` gets `IDS_FC_FEED: lambda: IdsFcDebtFeed().fetch(isos)`.
   * `country_cells` calls `ids_fc_debt.ids_fc_cells(raw, country, iso, filled, have, year, tlog, unserved)` after
     the Eurostat / OECD 1.5 block.
   * `gate._feed_of` maps `IDS_FC_LABEL` to the feed. `gate_checks` calls `ids_fc_gate_rows(n, value, series, raw,
     iso, year, ok_ids)`.
   * Update the expected feed lists in `tests/test_feeds_offline.py` and `tests/test_partial_fetch_coverage.py`.
3. **Map rows** (Team A, at verification time).
   * `coverage_source_map.csv` 1.2: candidate gains "econquest dsa (IDS DT.TDS.DPPG.CD / WDI FI.RES.TOTL.CD)". The
     dsa gate does not read `verified`; its verification is `DSA_VERIFIED_INPUTS`.
   * 1.5: verified=yes only after the probe.
4. **`coverage_gaps.py`.** Once `dsa` is wired, classify 1.2 for the IDS names as `adapter_unverified`.

**Status, 2026-10-25 (EQ-A-0096, second pass).**
* The `official/` side is wired. `wiring.country_cells` calls `dsa_cells` after the IMF block and `ids_fc_cells`
  after Eurostat / OECD. `gate._feed_of` and `gate_checks` dispatch both, and `gate_checks` takes a `dsa_vintage`
  argument.
* The two plan entries are in `wiring.a096_plan`, not yet in `fetch_plan`, so a pull's feed list stays the same
  until feeds.py names them. (`dsa_feed.fetch_dsa` was removed in EQ-A-0105: dsa is never a fetch_all feed; the
  re-gate reads the file with `dsa_feed.read_dsa_feeds`.)
* Tests: `tests/test_wiring_a096.py`.
* **Open: dsa needs a re-gate step.** `fetch_all` does not know the id of the vintage it is about to save. Wired
  into the plain fetch, `dsa` would read the previous pull's `outputs/dsa_scorecard_feeds.csv`. If the vintage
  argument is None, that row is accepted, which breaks point-in-time. The safe order is: fetch and save the vintage,
  then `econquest dsa`, then an offline re-gate of that vintage with `dsa_vintage=<id>`. There is no offline
  re-gate in feeds.py today, so this needs AGENT-06 (pullpack) and AGENT-08.
* 6.10: `WB_NOT_SERVED` now reads "held, research ...", and the coverage state `blocked_team_b` is renamed
  `held_research`.
* **Third pass (AGENT-08 decisions).**
  * `ids_fc_debt` is wired into feeds.py: in `FEED_HOSTS` (api.worldbank.org), in the `worldbank` alias, in
    `fetch_plan`, and in the feed check that decides whether official cells are built.
  * `dsa` is never a `fetch_all` feed.
  * The offline re-gate is not built, because it is larger than the agreed 150 lines. Its design is in the
    EQ-A-0096 report to AGENT-08.
* **Fourth pass (design approved): the re-gate is built.**
  * `official/dsa_regate.py` gates the latest full vintage offline and saves a derived vintage. It applies
    nothing. It refuses when there is no vintage, when the vintage is not the latest, when it is a partial pull,
    when it is already a re-gate, or when the dsa rows name another vintage.
  * `quality_gate` passes `dsa_vintage` on to the official gate.
  * The pull pack has a new step 0, `dsa_regate`. In the 0.6.0 Mac order in `A-mac-pull-pack.md` (section 0b) it
    runs straight after the full `econquest fetch`.
  * F8 guard `dsa_reseed`: a 1.2 / 1.1 / 2.1 seed whose latest `data/audit_trail.csv` row has source
    `econquest dsa` and origin `live feed` is held when the new value moves more than 25% from it.
    `ledger.effective_holds` releases that hold only for an apply that names its author and is bound to the
    re-gated vintage by its id. A matching live value alone is not enough, and neither is an author-unknown
    (imported) apply.
  * Real-data check (scratch copy of `data/` with the 0.4.2 `raw_worldbank.csv`, `econquest dsa` with 200 paths;
    nothing written to the repository):
    * 1.2: 9 cells apply (VNM, PHL, CHN, IND, BLZ, BRA, COL, NGA, ZWE).
    * PAK and ARG are held by `dsa_reseed` (-50.0%, on top of the change check).
    * SEN is held as mixed and ZMB by the change check.
    * 1.1 and 2.1 are all held (mixed).
    * The raw files are byte-identical in both vintages.
  * Row 3 of the table (+9) is now open: it needs only the Mac fetch and step 0.

### 10.7 Tests and checks

* `tests/test_wdi_extra.py`: 18 tests (10 old, 8 new: break, 2-year stale, label and client restriction, BIS
  comparison, reason parsing, approval effect, METHOD_APPROVED ids).
* `tests/test_dsa_feed_a096.py`: 7 tests, including the contract columns against `engine/dsa.FEED_COLUMNS`.
* `tests/test_ids_fc_debt_a096.py`: 5 tests.
* `tests/test_dsa_regate_a096.py`: 7 tests. They cover:
  * the derived vintage, with the IMF value kept and nothing applied;
  * the refusals for no vintage, another vintage, an older vintage, a partial pull and a second re-gate;
  * an author-unknown apply, a live-only apply and a base-vintage apply, none of which releases a `dsa_reseed` hold;
  * the audit-trail key;
  * the pack step.
* `tests/test_landing.py`: the full synthetic pack now runs step 0 as well.
* The importers (`test_coverage_gaps*`, `test_feeds_offline`, `test_feeds_scale`, `test_official_feeds`,
  `test_partial_fetch_coverage`, `test_central_banks`) pass. ruff is clean.
* Every test number is SYNTHETIC. The real-data figures in this section come from the uploaded 0.4.2 files.

## 11. Coverage part 5: measured on the 2026-10-25 full fetch, ranked by model weight, two adapters, D1 (EQ-A-0108; AGENT-01, 2026-10-25)

Nothing in this section was fetched from the cloud, and no data cell was changed. Measured numbers come from shared
files. **Every "after" number is a PROJECTION, a ceiling the next Mac pull confirms or cuts.** Under Sam's PI-10 rule
(no Mac steps before the MVP), nothing here is asked of Sam now. The Sam-gated items are in 11.6 for the "When Sam
is ready" list.

### 11.1 Measured coverage (before)

| Scope | File | Feed-eligible cells live | Share | Countries at 30 of 50 | Best country |
|---|---|---|---|---|---|
| Desk (18) | `team/inbox/pull-20261025-fullfetch/review.csv` | **245 of 900** | **27.2%** | **0** | 17 (PHL, CHN, IND, BRA, COL) |
| Universe (88) | `team/inbox/pull-20261025T121034Z/report.md` step 4 (0.5.0) and `pull-20261025T013150Z/universe_missing_countries.csv` (0.4.2) | **1,214 of 4,400** | **27.6%** | **0** | 18 |

How the desk number is counted:
* The review has 620 cells (319 ok, 90 hold, 211 missing). 522 of them are feed-eligible, meaning ids whose
  `coverage_source_map.csv` candidate is not `manual-only`. Of those, 245 are ok, 86 held and 191 missing.
* The other 21 eligible ids are not in the review at all (1.1, 1.4, 1.5, 1.8, the research ids, 6.1 and others), so
  they count as missing. That gives 18 x 50 = 900.
* Live means gate status `ok`. The 82 `apply` decisions are "unknown (imported from hand-edited review.csv)", which
  never release a hold (EQ-A-0101). Sam's 5 named applies are all fx3m, which is not an eligible id.
* Counting every apply would give 273 (30.3%). That figure is not a coverage measure.
* Per country: VNM 13, PHL 17, CHN 17, MYS 16, SGP 11, JPN 14, KOR 16, IND 17, PAK 15, BLZ 14, BRA 17, ARG 15,
  COL 17, NGA 13, ZMB 13, ZWE 10, VEN 5, SEN 5.
* **The full fetch measures the same 245 as the 0.4.2 pull (section 10).** None of the steps in 10.5 has been run on
  the Mac yet.

The universe figure is 0.2759 in both the 0.4.2 and the 0.5.0 reports. `data/live/vintages/` holds only 2026-10-23,
the desk pull behind case a (224).

### 11.2 Remaining gaps ranked by model weight

Weights come from `coverage_gaps.model_weights`: the rulebook weight within its pillar times the standard pillar
weight in `assumptions.json`. Team B owns both inputs.
* `validation.research_effect.run_effect` was **not** used. It computes the composite, PD and VaR effect of research
  cells that have values, and there are none in the shared folder.
* No model-sensitivity tool exists for the official ids.
* Gap weight = model weight x desk cells not ok (missing or held).

| # | id | weight | not ok | gap weight | Route | Part 5 |
|---|---|---|---|---|---|---|
| 1 | 1.1 | 0.050 | 18 | 0.900 | manual; dsa `mixed` | none (no free source) |
| 2 | 1.2 | 0.0375 | 18 | 0.675 | dsa feed built (10.3) | in flight (+9) |
| 3 | 2.2 | 0.030 | 18 | 0.540 | IDS, 9 held `unverified` | in flight (+13) |
| 4 | 2.1 | 0.030 | 18 | 0.540 | IMF ARA file | AGENT-02, EQ-A-0106 |
| 5 | 1.8 | 0.025 | 18 | 0.450 | CRAG | AGENT-06, in flight (+18) |
| 6 | 1.5 | 0.025 | 18 | 0.450 | IDS proxy built (10.4) | waits on Team B |
| 7 | 1.4 | 0.025 | 18 | 0.450 | WEO + IDS proxy (IMF) | none non-IMF |
| 8-9 | 2.3, 2.4 | 0.020 | 18 | 0.360 | IMF configs | AGENT-02, EQ-A-0106 |
| 10-13 | 4.4, 4.3, 3.7, 3.6 | 0.015 | 18 | 0.270 | research adapters built, files on the Mac | D1 below |
| **14** | **6.1** | 0.010 | 18 | **0.180** | UCDP API needs the token | **built: token-free GED CSV (11.3)** |
| 15-17 | 5.4, 5.2, 5.1 | 0.010 | 18 | 0.180 | Team B rule / IMF | none non-IMF |
| 18 | 2.11 | 0.010 | 18 held | 0.180 | built (EQ-A-0102) | release step |
| 20 | **2.9** | 0.010 | 10 | 0.100 | IDS; MYS SGP JPN KOR VEN SEN missing | **built: QEDS for the 4 SDDS names (11.4)** |
| 22 | **6.9** | 0.005 | 18 | 0.090 | UCDP | **built: same GED CSV (11.3)** |
| 35 | **2.10** | 0.010 | 5 | 0.050 | IDS; MYS SGP JPN KOR VEN missing | **built: QEDS (11.4)** |

The full list of 50 ids is reproducible with the scratch command in 11.7.

**Why these adapters.** The gaps above 6.1 are one of three things:
* in flight in another ticket (1.2, 2.2, 1.8, 1.5, 2.11);
* manual (1.1, 1.4);
* IMF-only (2.1, 2.3, 2.4, 5.1, 5.2). Those belong to AGENT-02's non-IMF route (EQ-A-0106), and AGENT-02 confirmed
  there is no overlap.

6.1 is the heaviest gap with a free, non-IMF, licence-compatible source that needs no credential: UCDP GED, CC BY 4.0,
CSV download. The same file serves 6.9. QEDS is the only free source for 2.9 and 2.10 on the four SDDS desk names.
Its licence status, however, is IMF-upstream, so it is restricted (see 11.4).

### 11.3 `research/ucdp_ged.py`: UCDP GED CSV without the token (6.1, 6.9 inputs; 0 cells now)

* Reads `ged*.csv`, `ged*-csv.zip` or `GEDEvent*.csv` from `data/panel/research/ucdp_ged/`: one annual GED file and,
  optionally, one Candidate file. It returns **the same monthly rows as the API adapter**. It calls
  `events/ucdp.map_countries` and `aggregate_monthly`, and a test asserts the output equals `events_from_api_pages`.
* A global file is filtered to the requested countries. Coverage:
  * GED: up to `ged_year_end(version)`;
  * Candidate: to the end of its last event month;
  * Candidate events inside the GED window are dropped.
* Refused: a missing column, a non-ISO date, a type of violence outside 1-3, an id/name conflict, a 2026 event in a
  26.1 annual file, or two annual files.
* **Off by default.** It is not in `research.REGISTRY`'s built list, `fetch_all` or the pull pack. `summary` writes
  nothing. `save` writes an append-only `ucdp` event vintage, the same store the API uses.
* UNVERIFIED (Mac probe list): the file name `ged261-csv.zip`, the CSV header (codebook names assumed), and the
  Candidate file name.
* Point in time: GED 26.1 ends 2025-12-31, so on its own it is stale for 6.9 (92 days) and 6.12 (183 days) at an
  October 2026 as_of. The Candidate file keeps 6.9 and 6.1 current.
* Cells: **0 now.** Filling 6.1 and 6.9 needs Team B's rules (HO-20261025-A-B-013 (a)): 6.1 has no written rule, and
  for 6.9 section 7 (floor 5, cap 10) differs from Team A's candidate code `events/indicators.py` (floor 1). It also
  needs a cells path (wiring by AGENT-02 / AGENT-06) and Sam's drop of the file. 6.12 still needs
  `data/panel/neighbours.csv`.
* Tests: `tests/test_ucdp_ged_a108.py` (6, SYNTHETIC).

### 11.4 `official/qeds.py`: QEDS 2.9 / 2.10 for MYS, SGP, JPN, KOR (0 cells now; +8 ceiling)

* 2.9 = QEDS short-term gross external debt Q4(Y) / WDI FI.RES.TOTL.CD(Y) x 100.
* 2.10 = QEDS gross external debt Q4(Y) / (NE.EXP.GNFS.ZS / 100 x NY.GDP.MKTP.CD)(Y) x 100.
* Y is the latest year up to the as_of year that has every input.
* All three denominators are in the 0.4.2 `raw_worldbank.csv` for the four names, through 2025 (NE.EXP.GNFS.ZS for
  JPN through 2024).
* Every cell is held:
  * `unverified` until the probe sets `QEDS_VERIFIED`;
  * `method` until Team B approves (HO-20261025-A-B-013 (b); a Tier 1 change through Sam);
  * plus `range` and `stale` where they apply.
* UNVERIFIED: wbgapi database 20, both series codes (placeholders), and the quarterly time-key format. Mac probe:
  `python -m econquest.ingestion.official.qeds probe`.
* **Licence (AGENT-02's point).** QEDS is joint World Bank / IMF, built from SDDS reports. The source label names
  the IMF, so `audit.client_output_reason` restricts every value (tested) until AGENT-09 or Sam rules.
* **Wired, off by default (EQ-A-0117, HO-20261025-A-A-002, with the 2.2 addendum).** `qeds` is a named feed only
  (`--only qeds`, like oecd, eurostat and cb).
  * It has a FEED_HOSTS entry, `api.worldbank.org`, but no FEED_ALIASES entry, so neither the default fetch nor the
    pull pack runs it.
  * `official.wiring.fetch_plan(isos, countries, year)` fetches QEDS_ISOS within the universe.
  * `country_cells` calls `qeds.qeds_cells` after the ids_fc step. It fills 2.2 / 2.9 / 2.10 only where the World
    Bank left the cell empty.
  * `gate_checks` adds `qeds_gate_rows`.
  * WB_SERIES now includes BX.GSR.TOTL.CD, the 2.10 denominator of indicator-rules 20.
  * Enabling the feed is AGENT-08's call. It means adding `qeds` to `FEED_ALIASES["worldbank"]` and updating the feed
    lists in `tests/test_feeds_offline.py` and `tests/test_partial_fetch_coverage.py`.
  * Tests: `tests/test_qeds_wiring_a117.py`.
  * Since indicator-rules 20 (AGENT-01, EQ-A-0118), QEDS_ISOS is MYS and KOR, and SGP and JPN keep their seeds.
* Universe: 59 cells of 2.9 / 2.10 say "worldbank returned no value" (31 countries, mostly high-income SDDS names).
  QEDS coverage of them is UNVERIFIED.
* Tests: `tests/test_qeds_a108.py` (6, SYNTHETIC).

### 11.5 ARCH-A-PI9 D1: research adapters emit `published`

* `research/base.py`:
  * `PUBLISHED_COLUMN` is an optional column after `LONG_COLUMNS`;
  * `with_published` checks YYYY-MM-DD dates.
* `wjp.py` writes per row the recorded edition date, or else 31 December of the label's last year (13.7).
* `aqueduct.py` writes the end of the publication month, 2023-08-31 (13.6).
* Adapters with no known date (V-Dem, coups, GOCI, ND-GAIN, EPR, UNHCR) keep 9 columns, and Team B's
  `PUBLISHED_DEFAULT` applies to them.
* `research/wiring._point_in_time` now **calls Team B's `research_effect.point_in_time`**. The local Aqueduct and WJP
  filters are gone.
* The divergence D1 found is closed: a single-year WJP label is now usable from 31 Dec of that year in both the pull
  and Team B's tool (parity test).
* The 13.1 no-legislature override stays in `wiring.cells` until Team B adds it to `rule_cells`
  (HO-20261025-A-B-012). It now reads the same point-in-time rows as Team B.
* Every research cell is still held at the gate.
* Tests: `tests/test_research_published_a108.py` (7).

### 11.6 Projection (desk, from the measured 245; PROJECTED, not measured)

| Step | Gate | Cells | Total | Share |
|---|---|---|---|---|
| 0 | measured, full fetch 2026-10-25 | | 245 | 27.2% |
| 1-6 | section 10.5 steps 1-6, unchanged (7.10, 2.2, 1.2, 1.8, WDI 2.12/5.9, research datasets) | +137 | 382 | 42.4% |
| 7 | 6.1 from UCDP: was "UCDP token"; now also possible from the GED + Candidate CSV (no token). Needs a Team B 6.1 rule and wiring | +18 | 400 | 44.4% |
| 8 | **6.9 from the same CSV** (Team B section 7 into a cells path, HO-...-013) | +18 | 418 | 46.4% |
| 9 | **2.9 / 2.10 QEDS, MYS SGP JPN KOR** (probe, Team B method, licence ruling, AGENT-02 wiring) | +8 | **426** | **47.3%** |

* **Part 5 adds at most +26 desk cells (+2.9 pp).** It also takes the UCDP token off the critical path of 6.1.
* **60% (540) is still not reached on any path in this document without the IMF configs.** Those are +90 (2.3, 2.4,
  5.1, 5.2, 5.11), and they are client-restricted and on AGENT-02's route. Even 426 + 90 = 516 (57.3%) falls short.
* Countries at 30 of 50: 0 measured, and about 0 projected. This is a rough per-country count of steps 1-9, not
  produced by a tool. Philippines goes from 17 to about 28: 7.10, 2.2, 1.2, 1.8, 5.9, four research ids, 6.1 and
  6.9. China, India, Brazil and Colombia go from 17 to about 27. Each of the five is 2 or 3 cells short.
* Universe (measured 1,214 / 4,400, 27.6%): UCDP 6.1 and 6.9 for all 88 names give +176, and QEDS at most +59
  (UNVERIFIED). The ceiling is 1,449 (32.9%).

**When Sam is ready (for `team/when-sam-is-ready.md`; Team C owns that file, so AGENT-08 adds these lines):**
* Mac pass:
  * download the UCDP GED 26.1 CSV, plus the latest Candidate CSV, into `data/panel/research/ucdp_ged/`;
  * run `python -m econquest.ingestion.research.ucdp_ged summary` and report the header and coverage;
  * run `python -m econquest.ingestion.official.qeds probe` and report the codes it prints.
* Decisions:
  * confirm UCDP CC BY 4.0 for the desk ([licence: Sam], indicator-rules);
  * rule on QEDS as IMF-upstream, client use or not;
  * sign off the Tier 1 changes `qeds.METHOD_APPROVED` and the 6.1 / 6.9 rules once Team B answers, with the batch
    effect.

### 11.7 Reproduce and tests

```
python -m pytest -q tests/test_research_published_a108.py tests/test_ucdp_ged_a108.py tests/test_qeds_a108.py -p no:cacheprovider
```

The coverage counts in 11.1 and 11.2 were made with a scratch script (not kept). It reads `review.csv` and
`coverage_source_map.csv` and uses `coverage_gaps.model_weights`: live = status `ok` for ids whose candidate is not
`manual-only`.

## 12. Coverage part 6: live measure for the Mac pass, next adapters (EQ-A-0118; AGENT-01, 2026-10-25)

Built and tested on shared data and recorded uploads only. Nothing was fetched and no data cell changed. Sam's Mac is
still on 0.5.0. **Every "after" number is PROJECTED.** The first measured "after" comes from 12.1, run on the upload
from the first Mac pass.

### 12.1 `coverage_live.py`: live measure after the Mac pass (for AGENT-06's landing kit, EQ-A-0116)

```
python -m econquest.ingestion.coverage_live measure --data data --review data/live/review.csv --baseline docs/runbooks/A-coverage-live-baseline-20261025.json --md coverage.md --json coverage.json
```

* **Python, the interface agreed with AGENT-06:** `measure(review, data_dir, universe_review=None, report=None,
  baseline=None)` returns a dict with schema `econquest.coverage_live/1`.
  * desk and universe: live, eligible cells, share, countries at target, best, per country, and `live_cells` as
    sorted `key|country` strings;
  * the pull report's universe step, as a cross-check;
  * `delta` against a baseline: cells gained and lost.
  * Invalid input raises one type, `CoverageError`, which the CLI turns into exit 2. Measuring is exit 0.
* **Definition, as in sections 10 and 11:**
  * Live means gate status `ok` on feed-eligible Inputs ids (`universe.feed_eligible_ids`). Ids absent from the
    review count as missing.
  * Named review applies are reported, not counted.
  * Scope is desk when every country is a `countries.csv` name. A partial desk review is refused.
* **Baseline:** `docs/runbooks/A-coverage-live-baseline-20261025.json`, written by the command above from the
  recorded uploads. Desk is 245 / 900 (27.2%) from the full fetch; universe is 1,214 / 4,400 (27.6%) from the 0.4.2
  review. Both match section 11.1 and the 0.5.0 report's `pct_live_eligible_overall` of 0.2759.
* **Today's files:** `data/live/review.csv` measures 245 against the baseline, with 39 cells gained and 39 lost. The
  2026-10-25 data/ edits changed which cells are live but not how many. `data/mvp/data/live/review.csv` measures 245,
  with 0 gained and 0 lost.
* Tests: `tests/test_coverage_live_a118.py` (10). They use the recorded team/inbox uploads and data/mvp.

### 12.2 Ranking: next gaps by model weight

The ranking continues from 11.2, with the same weights from `coverage_gaps.model_weights`.

**Team B's answers, as code.** Both handoffs are still "accepted", with no written response, and the QEDS method is
not yet answered. But Team B's `research_effect` already holds the answers:
* `rule_cells` now applies 13.1 (HO-20261025-A-B-012);
* a new `events=` argument computes 6.1 (section 19.1: UCDP state-based plus non-state deaths in 12 months; 0 / 1-24 /
  25-999 / 1,000+, held for the analyst; 183-day staleness);
* the same argument computes 6.9 (section 7 / 19.2: floor 5, cap 10, 92 days) (HO-20261025-A-B-013 (a)).

Wired in EQ-A-0118 (`research/wiring.py`):
* **13.1:** the local override in `cells` is removed, so 3.6 is Team B's cell alone.
* **6.1 / 6.9:** `cells(..., events=)` passes UCDP monthly rows to `rule_cells`. `ucdp_events(data_dir)` reads the
  stored UCDP vintages, whether from the API or from `research/ucdp_ged.py save`. The cells carry source "UCDP GED
  and Candidate events" and the CC BY 4.0 licence.
* The research gate still holds every cell.
* `feeds.py` does not pass `events` yet, so the pull is unchanged. AGENT-02 adds `events=_research.ucdp_events(
  data_dir)` to the `_research.cells` call. The call must also run when there are UCDP events but no research rows;
  today it is guarded by `len(raw["research"])`.
* Tests: `tests/test_research_ucdp_cells_a118.py` (5). They connect the GED CSV adapter to Team B's rules.

The gaps that stay closed:
* above 6.1, nothing changed: in flight, manual or IMF-only (11.2);
* 5.13 on 10 names: central banks are AGENT-02's area;
* 5.4, 5.1 and 5.2 are IMF;
* 7.8 waits on Team B's 5 m / 10 m choice;
* 5.7 BRSS is a static file that would be held stale.

The two next by weight with a free, non-IMF, licence-compatible source:

| id | weight | desk cells | gap weight | Source | Built |
|---|---|---|---|---|---|
| 2.2 (MYS SGP JPN KOR) | 0.030 | 4 | 0.120 | QEDS short-term debt by remaining maturity + WDI CA and reserves | `official/qeds.py` extended |
| 6.12 | 0.005 | 18 | 0.090 | COW Direct Contiguity (neighbour list for section 4) + UCDP + UNHCR | `research/cow_contiguity.py` |

### 12.3 `official/qeds.py`: 2.2 for the four SDDS names (0 cells now; +4 ceiling)

* 2.2 = (-WDI BN.CAB.XOKA.GD.ZS / 100 x NY.GDP.MKTP.CD + QEDS short-term external debt by remaining maturity, Q4 of
  Y) / WDI FI.RES.TOTL.CD x 100.
* Remaining maturity already includes long-term debt due within 12 months, which is the rulebook's "external debt due
  in 12m". So no separate amortisation term is added; the IDS names use the section 14 terms instead.
* All inputs except QEDS are in the 0.4.2 `raw_worldbank.csv` for the four names.
* The cell is held `unverified` and `method`; Team B is asked in HO-20261025-A-B-017, an addendum to -013. It is
  IMF-restricted by its label, and it is not wired. AGENT-02 has the wiring steps (HO-20261025-A-A-002 plus a message).
* UNVERIFIED: the remaining-maturity code, a placeholder. The probe now searches three concepts.
* Tests: `tests/test_qeds_22_a118.py` (3), plus `tests/test_qeds_a108.py` (6, updated for the third series).

### 12.4 `research/cow_contiguity.py`: the neighbour list for 6.12 (0 cells now; +18 ceiling with UCDP)

* Builds section 4's `data/panel/neighbours.csv` (columns iso3, neighbour_iso3, basis, source).
* Contiguity:
  * from COW `contdird.csv`, latest year, conttype 1-5;
  * the closest type wins, and pairs are made symmetric.
  * COW codes map to ISO3 through `states2016.csv` names and the repo ISO helpers. No code is mapped from memory, and
    unknown names are dropped and listed.
* Unions:
  * read only from an operator-made `unions.csv` (union, kind, iso3, source);
  * only the ten unions section 4 counts are accepted, and a free-trade bloc is refused;
  * no membership is invented, and without the file the result says unions were not applied.
* **Off by default:** `build` prints a summary. `build --write` writes the file and never overwrites one.
* UNVERIFIED: the v3.2 file names, headers and terms.
* 6.12 also needs the UCDP inputs (11.3) and Team B to compute section 4 (`research_effect.NOT_COMPUTED` today).
* Tests: `tests/test_cow_contiguity_a118.py` (4, SYNTHETIC; the ccodes are made up).

### 12.5 Projection (desk; PROJECTED, not measured)

| Step | Gate | Cells | Total | Share |
|---|---|---|---|---|
| 0 | measured (12.1 baseline) | | 245 | 27.2% |
| part 5 | section 11.6 steps 1-9 | +181 | 426 | 47.3% |
| 10 | 2.2 QEDS, MYS SGP JPN KOR (probe, Team B, licence ruling, wiring) | +4 | 430 | 47.8% |
| 11 | 6.12 (COW list + UCDP CSV + UNHCR, Team B computes section 4, Sam's files) | +18 | **448** | **49.8%** |

Steps 7 and 8 of 11.6 (6.1 and 6.9) no longer wait on a Team B rule: the rules are in `rule_cells` and wired.
They still need AGENT-02's one-line feeds.py change, the UCDP files or token on the Mac, and Sam's licence decision.
Their cell counts are unchanged.

* **Part 6 adds at most +22 desk cells.** 60% (540) still needs the IMF configs (+90, restricted, AGENT-02's route).
  Even 448 + 90 = 538 falls just short.
* Countries at 30: from the rough 11.6 count, PHL is about 28 + 6.12 = 29, and CHN, IND, BRA and COL about 28. Still
  0 at 30 without the IMF configs.
* Universe: QEDS 2.2 at most +28 (UNVERIFIED) and 6.12 +88, on top of 11.6's ceiling of 1,449. That gives 1,565 of
  4,400 (35.6%).

### 12.6 Mac probe list and Sam-gated items (in `docs/runbooks/A-sam-ready.md` item 10; first-mac-pass step 13)

* QEDS probe: `python -m econquest.ingestion.official.qeds probe`. It must find exactly one series for each of total,
  short and short_remaining.
* COW files in `data/panel/research/cow/`, then `python -m econquest.ingestion.research.cow_contiguity build --data
  data`. Report the summary line.
* After the pass, the landing kit calls `coverage_live.measure`. That gives the first measured "after".

### 12.7 Tests

```
python -m pytest -q tests/test_coverage_live_a118.py tests/test_qeds_a108.py tests/test_qeds_22_a118.py tests/test_cow_contiguity_a118.py tests/test_research_ucdp_cells_a118.py -p no:cacheprovider
```

### 12.8 Follow-up after Team B's answers (HO-20261025-A-B-012 and -013 done; EQ-A-0118 reopened)

| Item | Team B's answer | Done here |
|---|---|---|
| 13.1 | in `rule_cells` | The local override in `research/wiring.py` was already removed (12.2). The SAU fixture passes through `rule_cells` alone (`tests/test_research_ucdp_cells_a118.py::test_13_1_now_from_rule_cells`). |
| 3.7 default | Team B aligns `PUBLISHED_DEFAULT["3.7"]` to 13.7 once Team A flips its test | The "for the record" divergence assertion is gone. A new test requires 13.7 for rows without `published`. It is a strict xfail while Team B's default is still y+1, so it becomes a required pass when they align (HO-20261025-A-B-018). |
| 6.1 | section 19.1 | No Team A change. Team B's `rule_cells(events=)` already applies it, wired in 12.2. AGENT-02's feeds.py now passes `events=_research.ucdp_events(data_dir)`. |
| 6.9 | section 7 wins | `events/indicators.py` now follows section 7: floor 5 a year, 0.8 when both counts are below 5, N12/5 when only the base is, cap 10, stale after 92 days with no suggested level. ACLED and UCDP use the same rule. |
| QEDS 2.9 | approved as built | No change. `METHOD_APPROVED` stays empty (Tier 1). |
| QEDS 2.10 | denominator WDI BX.GSR.TOTL.CD | Changed. There is no goods-and-services fallback; without BX the cell is not served. BX.GSR.TOTL.CD is on the Mac probe list: `qeds probe` now looks it up in WDI. AGENT-02 added it to `feeds.WB_SERIES` (raw only). |
| QEDS names | MYS and KOR only | `QEDS_ISOS = ("MYS", "KOR")`. SGP and JPN return "held for the analyst (indicator-rules 20 / 17); seed kept" for every key, including 2.2, whose addendum HO-20261025-A-B-017 is still open. |

**Projection change (desk; PROJECTED).**
* QEDS now covers 2 names, not 4. That means 2.9 and 2.10 give +4 instead of +8, and 2.2 gives +2 instead of +4.
* Part 5 step 9 becomes 422. The 12.5 totals become 422 + 2 (2.2) + 18 (6.12) = **442 / 900 (49.1%)**.
* Universe ceiling: SGP and JPN are 2 of the 28 to 31 QEDS candidates, so it moves by about -6 at most. It is still
  about 35% and UNVERIFIED.
* First values stay parked (sections 19.3 and 20). Nothing was added to Sam's list. data/mvp verifies with 0
  unexplained and 0 restricted cells.

**Tests:** `tests/test_events_indicators_69_a118.py` (5 new); `tests/test_events_indicators.py` (2 expectations
moved to section 7); `tests/test_qeds_a108.py` and `tests/test_qeds_22_a118.py` (section 20, +1 test);
`tests/test_research_published_a108.py` (+1, xfail until Team B aligns).

## 13. Coverage part 7: measured on shared data, what PI-11 and EQ-A-0089 add, next licence-clean routes (EQ-A-0126; AGENT-01, 2026-10-26)

Shared data and recorded uploads only. Nothing was fetched, no data cell changed, and Sam's Mac is still on 0.5.0.
**Every "after" number is PROJECTED.**

### 13.1 Measured (coverage_live against the 2026-10-25 baseline)

```
python -m econquest.ingestion.coverage_live measure --data data --review data/live/review.csv --baseline docs/runbooks/A-coverage-live-baseline-20261025.json --md coverage.md --json coverage.json
```

| Review measured | Desk live / 900 | Share | At 30 of 50 | vs baseline |
|---|---|---|---|---|
| `data/live/review.csv` (data/, 2026-10-25 edits) | 245 | 27.2% | 0 | +0 (39 gained, 39 lost, as in 12.1) |
| `data/mvp/data/live/review.csv` (sha 6a301188...) | 245 | 27.2% | 0 | +0 (0 / 0) |
| `team/inbox/pull-20261025-fullfetch/review.csv` | 245 | 27.2% | 0 | +0 (0 / 0) |
| `outputs/client_safe_dataset/d3_yes/gate_review.csv` (EQ-A-0124) | 245 | 27.2% | 0 | +0 (0 / 0) |

Universe: 1,214 / 4,400 (27.6%), unchanged. No pull has run since the baseline, so no PI-11 or PI-12 work can show
in a measure yet. The first measured "after" is still the landing kit's `coverage_live.measure` on the Mac pass upload.

### 13.2 What PI-11 adds (PROJECTED)

| Ticket | Cells counted by coverage_live | Note |
|---|---|---|
| A-0118 part 6 | +2 (2.2 QEDS MYS, KOR) +18 (6.12) | 12.8: ceiling 442 / 900 (49.1%) |
| A-0117 client-safe sources, D3 switch | 0 | Changes what reaches client output, not internal coverage |
| A-0114 / A-0116 landing kit, A-0119 freshness, A-0121 gated history | 0 | Tooling, freshness holds, market history (not Inputs ids) |

### 13.3 What EQ-A-0089 adds, and a correction to step 6 of 10.5

EQ-A-0089 wires the research drop folders into the pull pack (step 7) and proves the path on fixtures. With no file on
disk, it adds **0 measured cells now**.

The correction: coverage_live counts gate status `ok`, and the research check holds **every** research cell.
Named applies are reported, not counted. So under the old code, the +72 of 10.5 step 6 could never be measured. The
cells are fixed by id:

| id | Source (register row, client) | Countable once | Cells |
|---|---|---|---|
| 4.3 | V-Dem `v2cacamps_osp` (vdem, allowed) | V-Dem layout verified (13.4); new, since the osp column is emitted | +18 |
| 3.7 | WJP (wjp, restricted) | WJP layout verified; Team B's rule gives a value (not stale) | +18 |
| 6.7 | GOCI (goci, restricted) | GOCI layout verified | +18 |
| 7.11 | ND-GAIN (ndgain, restricted) | ND-GAIN layout verified | +18 |
| 3.6, 4.4, 6.10, 7.12 | V-Dem, Powell-Thyne, EPR + WDI Gini, Aqueduct | Never `ok` at the gate: Sam's sign-off at the first gate review (parked in A-sam-ready item 14). An apply after review is not counted | 0 |

The step 6 total stays **+72**, because 4.3 replaces 3.6, so 442 / 900 (49.1%) stands. Two caveats: Belize coverage
of V-Dem, WJP and GOCI is UNVERIFIED, and 54 of the 72 are client-restricted. Internal coverage counts them; client
output withholds them.

### 13.4 Routes built in this part (work on fixtures and recorded uploads)

1. **Research layout switch** (`research/wiring.LAYOUT_VERIFIED`, empty).
   * Indicator-rules 13 holds research cells "`unverified` until the file layout is checked on Sam's Mac". The switch
     records which datasets passed that check.
   * For a cell made only from verified datasets, the `unverified` reason goes. Team B's rule holds stay, and the four
     sign-off ids stay held.
   * A cell with no reason left gets no research row, so the gate's other checks decide it.
   * The key is set by AGENT-08 from the Mac pass evidence: the `research/drops.py` report and the step 7 landing
     check. It is not Sam's decision.
   * `research/drops.verify` accepts a release only for a verified, non-sign-off cell.
   * Tests: `tests/test_research_coverage_a126.py`.
2. **6.10 Gini part with no EPR file** (`research/wiring.wants_cells`).
   * The fetch computed research cells only when research rows or UCDP events existed, so 6.10 was never computed.
     Yet `SI.POV.GINI` (World Bank, CC BY 4.0) is in the pull.
   * On Sam's recorded 0.4.2 `raw_worldbank.csv`, Team B's rule gives a level for **16 of the 18** desk names. SGP has
     no Gini, and VEN's latest is 2006.
   * Every cell is client-allowed, and all are held: Team B's "EPR missing" plus 6.10's sign-off. So **+16 held, 0
     counted** until EPR is dropped and Sam signs off.
   * `feeds.fetch_all` now gates the research branch with `wants_cells`. AGENT-02 (the owner) applied the one-line
     diff under EQ-A-0126.

### 13.5 Free, licence-clean routes left (none buildable now)

| id | Candidate | Why not now |
|---|---|---|
| 6.12 | COW contiguity + UCDP + UNHCR | COW row is restricted, terms UNVERIFIED (A-sam-ready item 12); Team B section 4 not computed |
| 6.1, 6.9 | UCDP GED CSV (CC BY 4.0) | Built and wired (11.3, 12.2); needs the files on the Mac. Register: the `ucdp` row does not match `panel/research/ucdp_ged/` (HO-20261026-A-A-004 to AGENT-04) |
| 7.8 | WDI EN.POP.EL5M.ZS | Team B's 5 m / 10 m choice |
| 7.1, 7.2, 6.11, 6.13 | UNDRR, IPC, GTI | Licence or credential (Sam) |
| 5.4, 5.7 | Pink Sheet + credit, BRSS | Team B rule plus IMF credit; BRSS static and stale |
| 1.5, 2.9, 2.10 (non-IDS names) | IDS proxy, QEDS | In flight (Team B, Sam); QEDS is IMF-upstream, client-restricted |

The remaining distance to 60% (540) is the IMF configs (+90, client-restricted, AGENT-02's route): 442 + 90 = 532,
still short.

### 13.6 Tests

```
python -m pytest -q tests/test_research_coverage_a126.py tests/test_research_drops_a089.py tests/test_coverage_live_a118.py -p no:cacheprovider
```

## 14. Coverage part 8: measured on shared data, what PI-12 and PI-13 add (EQ-A-0135; AGENT-01, 2026-10-26)

This part uses shared data and recorded uploads only. Nothing was fetched and no data cell changed. Sam's Mac pass
has not run, so no new pull exists. **Every "after" number is PROJECTED.**

### 14.1 Measured (coverage_live against the 2026-10-25 baseline)

```
python -m econquest.ingestion.coverage_live measure --data data --review data/mvp/data/live/review.csv --universe-review team/inbox/pull-20261025T013150Z/review.csv --baseline docs/runbooks/A-coverage-live-baseline-20261025.json --md coverage.md --json coverage.json
```

| Review measured (sha256, first 8) | Desk live / 900 | Share | At 30 of 50 | vs baseline |
|---|---|---|---|---|
| `data/live/review.csv` (89cdda1a) | 245 | 27.2% | 0 | +0 (39 gained, 39 lost, as in 12.1) |
| `data/mvp/data/live/review.csv` (420db9f1) | 245 | 27.2% | 0 | +0 (0 / 0) |
| `team/inbox/pull-20261025-fullfetch/review.csv` (f7108d24) | 245 | 27.2% | 0 | +0 (0 / 0) |
| `outputs/client_safe_dataset/d3_yes/gate_review.csv` (1d4cf94e; dataset 686b3d24...) | 112 | 12.4% | 0 | see correction below |
| `outputs/client_safe_dataset/d3_no/gate_review.csv` (afdd2eb5; dataset e1d98470...) | 99 | 11.0% | 0 | see correction below |

Universe: 1,214 / 4,400 (27.6%), unchanged (0 gained, 0 lost).

**Correction to 13.1.** The client-safe gate reviews no longer measure 245. EQ-A-0124 rounds 2 to 4 rebuilt them,
and they now keep only the rows a client may receive. So coverage_live on them counts client-releasable live
cells. Internal coverage is not changed. Read these two rows as the client-output measure, not as a loss against
the baseline.

Re-measured with coverage_live on the rebuild over the final data/mvp (d3564255, N-5 under EQ-A-0135; review
5913c36f), after EQ-A-0130 traced the 39 cells:

| Variant | Rows | Withheld | coverage_live (eligible Inputs ok) | All ok rows (Inputs + Country Profile) |
|---|---|---|---|---|
| D3 yes | 258 -> 297 | 524 -> 485 | 73 -> 112 / 900 (8.1% -> 12.4%) | 142 -> 181 |
| D3 no | 266 | 555 -> 516 | 60 -> 99 / 900 (6.7% -> 11.0%) | 153 now |

The +39 in both variants is the 39 traced cells (2.9 x8, 3.4 x13, 3.5 x18), now released. AGENT-08's "181 live"
counts every ok row, Country Profile included. coverage_live counts the 50 feed-eligible Inputs ids only, so
it gives 112. No country is at target.

### 14.2 What PI-12 adds (measured: 0)

| Ticket | Cells counted by coverage_live | Note |
|---|---|---|
| A-0089 research wiring | 0 | Every research cell is held (13.3). Counted only after layout checks on the Mac and Sam's sign-offs |
| A-0123 vendor simulator | 0 | Synthetic market data through the vendor adapters; no Inputs id |
| A-0124 client-safe dataset | 0 internal | Client-releasable live (coverage_live): 112 (D3 yes) / 99 (D3 no) after the N-5 rebuild, 14.1 |
| A-0125 data room, A-0127 / A-0128 reviews | 0 | Packaging and reviews |
| A-0126 coverage part 7 | 0 now | Layout switch and the 6.10 Gini part. The +16 for 6.10 are held, 0 counted (13.4) |
| A-0129 C15 helpers | 0 | Refactor. 6.9 has no Inputs row in either review |

### 14.3 What PI-13 adds (PROJECTED)

| Ticket | Cells counted by coverage_live | Note |
|---|---|---|
| A-0131 text corpus | 0 | Feeds B-0135's text stress index, a research view with no Inputs id |
| A-0132 event calendar | 0 | Elections and IMF dates are not feed-eligible Inputs ids |
| A-0133 sanctions lists | 0 | 2.7 and 4.10 are `manual-only` in coverage_source_map.csv, so they are not among the 50. Exposure counts are kind "input" rows, held until Team B's level rule (HO-20261026-A-B-009). Decision (A/AGENT-08, 2026-10-26): the denominator stays at 50 ids; the manual-only ids 2.7 and 4.10 are not counted until a feed can serve them |
| A-0134 macro inputs | 0 | REER broad covers the same 10 names that 2.12 already has live from BIS. ToT and REER variants would be new ids, outside the 50 (HO-20261026-A-B-010) |
| A-0130 data/mvp rebuild | 0 (measured) | Landed 2026-10-26 (AGENT-06, dataset_sha256 9cbe721d...). All 39 unsourced full-fetch cells (2.9 x8, 3.4 x13, 3.5 x18) were traced to the recorded World Bank pull (pull-20261025T013150Z, DT.DOD.DSTC.IR.ZS and WGI); none held. Re-measured: new `data/mvp/data/live/review.csv` (5913c36f) 245 / 900, +0 vs baseline. `sanctions` is now in mvp_dataset.EXCLUDE_DIRS |
| A-0136 security review | 0 | |

**Denominator decision (A/AGENT-08, 2026-10-26):** coverage stays measured on the 50 feed-eligible ids. The
sanctions ids 2.7 and 4.10 stay `manual-only` and uncounted until a feed can serve them.

PI-13 adds no counted cell by design: its work is research views and new inputs that wait on Team B's rules. The
A-0130 risk did not materialise: all 39 cells were traced, so desk stays 245.

### 14.4 Projection (desk; PROJECTED, not measured)

The step from part 7 stands:
- 245 now (A-0130 traced all 39 cells);
- 442 / 900 (49.1%) after the Mac pass, the part 6 adapters and the four verified research layouts (13.3);
- plus 90 from the IMF configs (client-restricted): 532, still short of 540 (60%).

No free, licence-clean route has been added since 13.5.

### 14.5 Tests

```
python -m pytest -q tests/test_coverage_live_a118.py tests/test_sanctions_a133.py -p no:cacheprovider
```
