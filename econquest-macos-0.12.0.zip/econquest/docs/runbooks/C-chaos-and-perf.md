# Runbook C: chaos faults and the daily-cycle performance budget (EQ-C-0164)

Owner: Team C AGENT-04. Tests: `tests/test_chaos_c164.py`, `tests/test_perf_budget_c164.py`. Everything here runs
offline, in temp folders; nothing reads the repository's `outputs/`.

## 1. What fails closed, and how it says so

| Fault | Where | What you see | What it never does |
|---|---|---|---|
| Killed job (SIGKILL, power cut) | `ops/jobs.py` | `<job>.last.json` stays `running`; health raises `job_hung` after 2 x max_minutes. The stale lock (dead pid) does not block the next run. A torn `last.json` is skipped. | Run two copies at once (a live pid still blocks: exit 75). |
| Killed or out-of-space backup | `ops/backup.py` | `[backup] error: backup: disk full (ENOSPC) ...`, exit 2. The `.partial` archive and its manifest are removed. | List an archive without its manifest. The manifest is written (temp + `os.replace`) before the archive is renamed into place. |
| Truncated backup archive or manifest | `backup --verify-only`, drill | `archive sha256 differs ... (file changed or truncated)` or `manifest ... unreadable or truncated`; the drill reports FAIL. | Restore from it. |
| Full disk in the drill | `restore-drill` | FAIL with `restore: disk full (ENOSPC)`; a report that cannot be written is `[backup] error: restore drill ... report was not written`. | Crash with a traceback, or leave the temp copy. |
| Full disk recording a job | `ops/jobs.py` | `[job] X: end not recorded (...); disk full?`; the lock is released; exit 74 if the job had succeeded. | Report an unrecorded run as ok. |
| Clock went back | `ops/jobs.py`, health | Job refused: `clock skew: the system clock reads ..., N min before the newest recorded job time ...`, exit 78, no step runs; health raises a critical `clock_skew` alert, and a warning when any recorded job time is in the future. | Run the calendar tests, record or morning for the wrong date. Durations are never negative (monotonic fallback, `clock_skew: true`). |
| Clock went back, backup | `ops/backup.py` | `WARNING clock skew ... retention is skipped`. | Prune the newest backup as "old". |
| Clock went back, research archive | `presentation/archive.py` | `clock skew: this version would be stamped ..., before the archive's last entry ...; nothing archived`. | Date versions out of order. |
| Corrupted review ledger (`data/live/review_ledger.csv`) | Team A `ingestion/ledger.py` | Append refused: `hash chain is broken, nothing appended`; health: critical `review_ledger` alert, exit 1. | Extend a broken chain. (Reads do not verify yet: HO-20261026-C-A-001.) |
| Corrupted archive index (`outputs/archive/index.jsonl`, head) | `presentation/archive.py` | `research archive index fails verification, nothing archived: index line N: ...`; `econquest archive verify` lists every break. A head left one row behind by a killed write counts as a break. | Append to a damaged index, or leave a version folder the index does not name. |
| Corrupted overlay ledger | Team B `validation/analyst_overlay.py` | `overlay ledger fails verification`; backdated events refused. | Append. (It is not in the backup yet: HO-20261026-C-B-002.) |

## 2. Recovery: the restore drill

1. Find the last good backup: `econquest backup --list`, then `econquest backup --verify-only <archive>` on the
   newest ones. A truncated archive fails here.
2. Prove it restores: `econquest restore-drill --backup <archive>`. The drill restores into a temp folder, re-hashes
   every file, smoke-checks the universe and the run store and now also verifies the restored **review ledger** and
   **research archive index** (`ledgers`, `ledgers_ok`, `ledger_problems` in `outputs/restore_drill.json`). The log line
   says `ledgers ok` or `ledgers NOT CLEAN: ...`. A backup taken after the damage restores faithfully but is
   `NOT CLEAN`: pick an earlier one.
3. Restore it for real: `econquest restore-drill --backup <archive> --keep` keeps the verified copy (path printed).
   Copy back only the damaged file or folder (`data/live/review_ledger.csv` or `outputs/archive/`) after moving the
   damaged one aside, then run `econquest health --no-deliver` and `econquest archive verify`.
   Decisions or versions written after that backup must be entered again; the damaged copy shows what they were.
4. Clock skew: fix the clock first (`date -u`). If an earlier run's clock was ahead, the job record is in the future
   and jobs keep refusing until real time passes it: after checking the clock, run the job once with
   `python -m econquest.ops.jobs ... --allow-clock-skew` (or `ECONQUEST_ALLOW_CLOCK_SKEW=1` for that one run).

## 3. Performance budget for the daily cycle

```
econquest perf-budget [--json]          # one timed cycle against team/perf/daily-cycle-budget.json; exit 1 over budget
econquest perf-budget --paths 2000      # quicker check (budgets are for the full run)
econquest perf-budget --steps run,health
econquest perf-budget --measure --runs 3  # re-baseline after an accepted change (AGENT-04 sign-off)
```

The cycle runs on a fresh temp home whose `data/` is a copy of `data/mvp`, with the same command lines as the jobs:
`run`, `report`, `morning --no-run --json`, `record --dry-run`, freshness `check` and `prices`, `calendar_tests`,
`benchmark_snapshot`, `health --no-deliver`, `backup --verify` (temp destination) and the restore drill. Each step is
timed with the monotonic clock in a child process. Not timed: the incremental events pull (network), shadow ratings
(its `--out` must be inside the repo `outputs/`) and the weekly and monthly jobs.

Budget rule: `budget_s = ceil(median of 3 cycles x 1.5 + 2 s)`. Measured 2026-10-26 on the 4-core cloud container
(Python 3.13), full 131,072-path run, cold fit cache:

| Step | Median s | Budget s |
|---|---|---|
| run | 17.9 | 29 |
| report | 4.3 | 9 |
| morning | 6.5 | 12 |
| record | 3.9 | 8 |
| freshness_check | 1.0 | 4 |
| freshness_prices | 0.9 | 4 |
| calendar_tests | 2.5 | 6 |
| benchmark_snapshot | 1.7 | 5 |
| health | 2.1 | 6 |
| backup | 1.5 | 5 |
| restore_drill | 2.8 | 7 |
| total | about 45 | 95 |

Over budget: rerun once (machine noise), then profile the step (`python -m cProfile -s cumtime -m econquest ...`)
and open a PERF report before changing the budget. Never raise a budget to make a regression pass.
