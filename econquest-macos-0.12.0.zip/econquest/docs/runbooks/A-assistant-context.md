# Assistant context builders (EQ-A-0143, PI-15)

`econquest.ingestion.context.build_context(data_dir, *, kinds, country, as_of, scope, limit, outputs_dir)` turns the
desk's stores into read-only, citable chunks for the LLM assistant. Contract: `docs/runbooks/A-PI15-agent-brief.md`;
code and per-kind sources: `econquest/ingestion/context/builders.py` (module docstring). Consumers: Team B B-0145
(HO-20261027-A-B-001), Team C C-0170/C-0172 (HO-20261027-A-C-001).

Nothing to schedule: it reads, never writes, and makes no network or model call. It is tested by `tests/test_context_*.py` and
`tests/test_sec_a_017.py`.

## Trust and fencing
- `econquest`: run outputs, audit trail, review ledger, MVP dataset cells.
- `ingested` (text passes through `context.hygiene.fence`): calendar, text corpus, unified events, and the research
  archive (SEC-A-017 H-3, AGENT-08 2026-10-27: archived notes can quote outside text).
- `scope.py` / `hygiene.py` are imported directly; an absent or broken module raises. The stubs exist only behind the
  test hook `builders.stub_hooks()`.

## Known limitations
- P-2 (SEC-A-017, Low): run_output chunks label stress scenarios from the *current* `data/scenarios.json` and trades
  from the *current* `data/playbook.csv`, not the versions in force at the run's as_of. Only names and descriptions
  come from these files; every number comes from the stored run. If a scenario or trade is renamed or redefined,
  an older run's chunk shows the new label.
- The audit kind is left out for an as_of earlier than the trail's last change (newest retrieval, review-ledger
  decision or `live/snapshots` apply stamp). With an as_of set, rows that have no time of their own are dropped.
- Archive, ledger, corpus and events are empty in the cloud; they are exercised on SYNTHETIC fixtures until the Mac
  pull fills them.
- The archive kind reads Team C's `econquest.presentation.archive` (ARCH-A-PI15 L-1); switch to Team C's public
  `documents()` reader when HO-20261027-A-C-001 is answered.
