# Runbook: update the BoC-BoE sovereign default database (`crag update`)

Ticket EQ-A-0069 (Sam, 2026-10-24 18:57Z: "update the BoC-BoE default database from the GUI and the CLI").
Owner: Team A, AGENT-06. Operator: Sam (Mac) or anyone with the file. Written 2026-10-25 offline from
`econquest/ingestion/crag_update.py` and `econquest/ingestion/default_panel.py`. The cloud cannot reach
bankofcanada.ca, so **no Bank of Canada URL here was opened from this environment**.

## What it does

| Step | What happens | Writes |
|---|---|---|
| 1. check | `.csv` (Valet export) or `.xlsx`/`.xlsm` (BoC-BoE workbook); not empty; at most 50 MB; xlsx must be a valid zip workbook that unpacks within budget (`safe_zip`: at most 500 MB in total, 300 MB per member, compression ratio at most 200:1 for members over 1 MB, checked from the zip directory before anything is decompressed) and passes its CRC check; CSV must be UTF-8 text with no NUL bytes | nothing |
| 2. import | `default_panel.import_crag`, the same parsers and `data/panel/crag_iso_map.csv` as EQ-A-0008 (Valet layout auto-detected, `DEBT_` prefix and `_YYYY` suffix stripped). Refused if the importer cannot find the table, a country with a spell has no ISO3 code, or the file gives 0 episodes | run folder only |
| 3. vintage | New append-only panel vintage `data/panel/vintages/<UTC>-<hash8>/` (episode file, universe file, `crag_import.json` with `licence_status: UNVERIFIED`); index label ends `[licence UNVERIFIED] crag_update`. Identical content is not stored twice; an older vintage is never touched | vintage store |
| 4. diff | Against **what `--apply` would replace**: the newest other CRAG vintage holding exactly the live `sovereign_defaults_crag.csv`, or the live file itself if no vintage holds it (an unapplied dry run is never the base while a live file exists; with no live file, the newest other CRAG vintage): added, removed and changed episodes with country, start/end year, type (creditor categories) and amount (CRAG peak, USD millions, and its year) | run folder |
| 5. apply | Only with `--apply`, after the diff, under the exclusive lock `data/panel/.crag_update.lock`: replaces `data/panel/sovereign_defaults_crag.csv`, `sovereign_defaults_crag_universe.csv` and `data/panel/crag_comparison.csv` (CRAG vs memory list) as one step: copies the old ones into the run folder, writes per-run temp copies (`.<file>.<run id>.<random>.tmp`, fsynced), then renames; if any step fails the files already replaced are restored. Refused if the live file changed since the run started | live CRAG files |

`data/panel/sovereign_defaults.csv` (the memory list the model uses) is **never written**. Its hash is checked
before and after every run. Swapping it for the CRAG file is a Tier 1 decision for Sam and Team B (EQ-A-0008
part 2), not part of this command.

Run folder: `data/panel/staging/crag/updates/<UTC run id>/` with `crag_update_diff.csv`,
`crag_update_summary.md`, `crag_update.json` (the full result; the input by basename and sha256, every path relative to the panel folder, never an absolute path), `crag_comparison.csv` (vs memory list), the
staged `sovereign_defaults_crag.csv` and universe file, and after `--apply` the `live_before_apply_*` copies.

## Commands

From the repo root (on the Mac use `.venv/bin/python`). Team C is wiring `econquest crag update` and a GUI button to
the same function (handoff in "For Team C" below); until then use the module:

```
# 1. dry run: import, new vintage, diff, one-screen summary. The live file is not changed.
python -m econquest.ingestion.crag_update --file ~/Downloads/DEBT_2026.csv
python -m econquest.ingestion.crag_update --file ~/Downloads/BoC-BoE-Database-2026.xlsx

# 2. read the diff (path printed), then apply the same file
python -m econquest.ingestion.crag_update --file ~/Downloads/DEBT_2026.csv --apply
```

Options: `--source-vintage 2026-10` (edition or download date written to every row's `source_vintage`; default
the current UTC `YYYY-MM`; EQ-A-0008 used `2026-10`), `--iso-map PATH` (default `data/panel/crag_iso_map.csv`),
`--panel-dir DIR` (default `data/panel`), `--json` (print the whole result instead of the summary).

Running the dry run and then `--apply` on the same file is safe: the second run finds the same vintage (not
duplicated) and compares with the same previous vintage.

Exit codes: **0** done (dry run or applied), **1** refused (nothing live changed), **2** `--fetch` not available.

Example (scratch copy of the panel, Sam's `DEBT_2026.csv` with Angola's rows deleted, `--apply`):

```
crag update (EQ-A-0069): APPLIED - live CRAG file replaced
input     DEBT_2026.csv (valet_csv, sha256 53d12d384e92)
vintage   new 2026-10-25T013150Z-adea9398 (created) | previous 2026-10-25T013137Z-c9549824
episodes  207 in 98 countries (previous 210)
changes   +0 added  -3 removed  ~0 changed  207 unchanged
licence   BoC-BoE terms UNVERIFIED (https://www.bankofcanada.ca/terms/ not read)
  - AGO Angola 1990 LC debt 867
  - AGO Angola 1992-1994 LC debt 2,727
  - AGO Angola 2010 LC debt 1,800
diff      .../staging/crag/updates/2026-10-25T013150Z/crag_update_diff.csv
summary   .../staging/crag/updates/2026-10-25T013150Z/crag_update_summary.md
live      .../sovereign_defaults_crag.csv sha256 7ebcb7dc31ba (was 37a05934978c)
memory    sovereign_defaults.csv unchanged (swapping it is Tier 1: Sam and Team B)
```

The unmodified `DEBT_2026.csv` gives 0 added / 0 removed / 0 changed against vintage 2026-10-24T190434Z-03d9c4c4,
and its staged episode file is byte-identical to the EQ-A-0008 file (sha256 37a05934...).

## Reading the diff

`crag_update_diff.csv`: `status` (added / removed / changed), `iso`, `country`, `old_start`, `old_end`,
`new_start`, `new_end`, `old_type`, `new_type`, `old_amount_usd_m`, `new_amount_usd_m`, `old_peak_year`,
`new_peak_year`, `changed_fields` (any of `start;end;type;amount`).

Pairing: spells of the same ISO3 code pair first on identical years, then on years that overlap or lie within one
year (the rule `compare_panels` uses), closest first. Amounts are compared to the nearest USD million (the note
stores them rounded). Amount = the largest in-scope amount in default in one year of the spell (FC bank loans + FC
bonds + LC debt), parsed from the note `CRAG peak X in YYYY`.

Warnings in the summary:
- more than 25% of the previous episodes removed: check the file is complete (a truncated download parses fine
  but loses rows) before `--apply`;
- the live file matches no stored CRAG vintage: it was edited by hand. The diff is then against the live file
  itself (what `--apply` replaces); `diff_base` in `crag_update.json` names the file compared.

## When it refuses

| Message | Do this |
|---|---|
| `not a valid xlsx workbook`, `not an Excel workbook`, `fails its CRC check` | Download again; the file is truncated or not the workbook |
| `NUL bytes`, `not UTF-8 text` | Not the Valet CSV export; download the CSV again (Valet exports are UTF-8) |
| `refused by the importer: no CRAG table found ...` | A new edition renamed sheets or columns: Team A adds `sheet=` / `category_map=` support for it (data/panel/README.md step 1) |
| `refused by the importer: N country names have no ISO3 code` | Fill the iso column of `staging/crag/updates/<run>/sovereign_defaults_crag_unmapped.csv` (never guess; Team B decides historical states), add the rows to `data/panel/crag_iso_map.csv`, rerun |
| `gives 0 default episodes` | Wrong file; no vintage was saved |
| `over the ... cap` | Not the BoC-BoE file (the 2026 CSV is 2.4 MB) |
| `compression ratio ...`, `unpacks to ...`, `members, over the ... limit` | Not a genuine BoC-BoE workbook (possibly a decompression bomb): do not open it; download again from the Bank of Canada page |
| `another crag update is applying (lock ...)` | Wait for the other apply (GUI or CLI) to finish and rerun. If none is running (a crash or a killed process left it), the lock is stale: check the `pid=` it names is not running (`ps -p <pid>`), delete `data/panel/.crag_update.lock`, rerun |

A refused run saves no vintage and changes nothing live; its run folder may hold the partial staging files.

## `--fetch` (UNVERIFIED, off)

`--fetch` is built but has no verified URL, so it prints the page to download from and exits 2:

```
python -m econquest.ingestion.crag_update --fetch      # -> exit 2, prints the page below
```

- Page: https://www.bankofcanada.ca/2026/10/staff-analytical-paper-2026-48/ (from data/panel/README.md)
- Candidates (UNVERIFIED, from data/panel/README.md): `https://www.bankofcanada.ca/valet/observations/group/DEBT_2026/csv`,
  `https://www.bankofcanada.ca/wp-content/uploads/2026/10/BoC-BoE-Database-2026.xlsx`

When a URL is verified, the download goes through `sources.https_get` (https only, redirects refused, 50 MB cap),
only to an allow-listed host (`www.bankofcanada.ca`, no port or user info), into a new file under
`data/panel/staging/crag/fetched/<run id>/` (never overwritten), then the normal steps run on it.

**Turning on `--fetch`:** on the Mac, download one candidate by hand (browser) and run a dry run on it; if it
imports and the diff is as expected, record the URL, date and file sha256 in the team log and ask AGENT-06 to set
`FETCH_URL_VERIFIED` in `crag_update.py` (one line, with a test). If the URL redirects, it will be refused by
design; record the final URL instead. Next year's edition (DEBT_2027, a new paper page) needs a new verified URL.

## Licence

No repo document records the BoC-BoE terms. The Valet export's TERMS AND CONDITIONS block names
https://www.bankofcanada.ca/terms/, which was not read from this environment; no Bank of England terms were found
in the repo. Every vintage this command saves is tagged `licence_status: UNVERIFIED` with that basis in
`crag_import.json`. Sam or AGENT-09 confirms internal use and data-room redistribution (with EQ-A-0076, the licence
register); until then treat the CRAG files as internal research data.

## For Team C (CLI and GUI)

```python
from econquest.ingestion.crag_update import crag_update
res = crag_update(file=None, *, apply=False, fetch=False, panel_dir=None, source_vintage=None,
                  source_label=None, iso_map_csv=None, now=None,
                  expect_live_sha256=None, expect_iso_map_sha256=None) -> dict
```

It never raises for a bad input. Show `res["summary_text"]` (about 25 lines); exit with `res["exit_code"]`.
`python -m econquest.ingestion.crag_update` is the reference CLI (`main(argv) -> int`, flags above). Result keys:

| Key | Meaning |
|---|---|
| `status` | `dry_run`, `applied`, `refused`, `changed` (apply with `expect_*` and the live file or country map is not the one the dry run saw; exit 1, nothing replaced), `fetch_unavailable`, `error` (memory list changed, or a failed `--apply` could not restore a live file: never expected; the message names the backup) |
| `exit_code`, `message` | 0 / 1 / 2 and a one-line reason |
| `summary_text` | the one-screen summary |
| `input`, `format`, `input_sha256` | the file used (`valet_csv`, `csv`, `xlsx`) |
| `new_vintage`, `new_vintage_created`, `previous_vintage` | vintage ids (`created` false when identical content was already stored; `previous_vintage` is the vintage holding the live file, None when the live file matches none) |
| `diff_base` | path of the file the diff compared with (a vintage's episode file, or the live file) |
| `counts` | `episodes`, `countries`, `previous_episodes`, `added`, `removed`, `changed`, `unchanged` |
| `diff_rows` | list of dicts with the diff CSV columns (None for empty cells) |
| `files` | `run_dir`, `staged_csv`, `staged_universe`, `diff_csv`, `summary_md`, `result_json`, `vs_memory_csv` |
| `warnings` | list of strings |
| `licence` | `licence_status` (UNVERIFIED), `licence_terms_url`, `licence_basis` |
| `live_file`, `live_replaced`, `live_sha256_before`, `live_sha256_after` | the live CRAG file |
| `iso_map_file`, `iso_map_sha256` | the country map the import read (None when absent); pass `iso_map_sha256` back as `expect_iso_map_sha256` |
| `expect_live_sha256`, `expect_iso_map_sha256` | the values passed in (None when not bound) |
| `memory_list`, `memory_list_sha256`, `memory_list_untouched` | `sovereign_defaults.csv` (always untouched) |
| `run_id`, `panel_dir`, `apply`, `fetched_from` | run details |

GUI flow: file picker, run without apply, show `summary_text` and `diff_rows`, then an "Apply" button that calls
again with the same file and `apply=True`, passing the dry run's `live_sha256_before` as `expect_live_sha256` and its
`iso_map_sha256` as `expect_iso_map_sha256` (`"absent"` where the dry run's value is None). Both are checked under the
apply lock right before the replace (HO-20261025-C-A-003, SEC-C-017 R51); a mismatch returns `status` `changed`:
show the message and ask for a new dry run. CLI: `--expect-live-sha256 HEX|absent`, `--expect-iso-map-sha256 HEX|absent`
(only with `--apply`). Keep `--fetch` behind its flag: it exits 2 today.

## Not covered

- The lock covers `--apply` only. Dry runs need no lock (each has its own run folder; vintages are append-only).
  A stale lock is never removed automatically (see "When it refuses").
- `panel_coverage` against `weo_history.csv` is not run here (pull pack step 3 does it once the history exists).
- Refitting the hazard model on the new file is Team B's and Tier 1.
