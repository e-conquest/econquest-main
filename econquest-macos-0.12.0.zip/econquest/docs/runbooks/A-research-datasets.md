# Research-dataset adapters: licence check and runbook (EQ-A-0067, EQ-A-0095, EQ-A-0089)

Decision: Sam, 2026-10-24 17:21Z, "Add them, licence-checked". This page covers research datasets for indicators that
have no adapter, on the way to the 60% coverage target. Terms pages were read on 2026-10-25 with a web-fetch tool. The
cloud cannot download from any of these hosts: a HEAD request from the cloud to every file URL below got no answer
through the proxy. Every download and every check of a real file layout therefore runs on Sam's Mac.

Code: `econquest/ingestion/research/` (`base.py` and one module per dataset). `research.REGISTRY` maps each dataset to
its module, indicators, licence tag and fetch mode. Nothing is wired into `feeds.py` yet; that is wave 2.

## Rules the adapters follow

* **Output.** Each adapter returns long rows with these columns: `indicator, iso3, year, value, metric, kind, source,
  licence, vintage`.
  * `kind = indicator`: the value is already in the indicator's unit from `indicators.csv`.
  * `kind = input`: a raw input that still needs a Team B rule. It is never written to `indicators.csv` as it stands.
* **Point in time.** `vintage` = `<dataset version>; sha256:<16 hex>; <file name>`. When a download is kept in the
  drop-in folder it is written once and made read-only (0444).
* **Countries.** Countries are mapped with `default_panel.default_iso_lookup`, which reads the repo tables and the
  ISO3 reference list.
  * A known ISO3 code in the file wins over the country name.
  * A code and a name that disagree, or a name the lookup does not know, are dropped and listed in
    `ResearchResult.unmapped`. They are never guessed.
* **Layouts.** Each parser checks the columns it needs. A missing column, a value off the codebook scale, or an
  unknown category raises `LayoutError`, which names what was found. Nothing is rescaled or repaired.
* **Downloads.** `base.download` accepts only:
  * datasets whose `fetch_mode` is `direct` or `api`;
  * https URLs on the dataset's host allow-list, with no credentials and no port in the URL.

  It uses `events.base.http_fetch`, which refuses redirects, caps the body size and checks the final URL. Zip files
  are read in memory with a cap on each member's unpacked size; they are never extracted to disk. Workbooks are read
  with openpyxl, which reads cell values only and never runs macros.
* **Licence tags.** Tags never contain a desk-barred term such as "non-commercial" or "personal" (see
  `market.gate.DESK_BARRED_LICENCE_TERMS`). `DatasetSpec` refuses any tag that does.
  * A dataset whose licence is non-commercial or not confirmed carries `internal research use only` in its tag. That
    keeps it out of client output, the same way IMF data is handled under EXC-003, while it stays usable in desk
    numbers.
  * Only a confirmed licence that allows commercial use carries an open tag: V-Dem (CC BY-SA 4.0), WRI Aqueduct
    (CC BY 4.0) and UCDP (CC BY 4.0).
* **Manual downloads.** A dataset behind a form or registration is downloaded by hand on the Mac into
  `data/panel/research/<dataset>/`. The folder list is in `data/panel/research/README.md`.

## Summary

Weights are taken from `data/rulebook.csv`. UNVERIFIED means a fact that could not be confirmed on the official page.

| Dataset | Indicators (weight) | Licence | Commercial use | Client output | NDA validator | Fetch | Adapter |
|---|---|---|---|---|---|---|---|
| V-Dem v16 | 3.6 (0.10), 4.3 (0.10) | CC BY-SA 4.0 | yes | allowed with attribution; whether ShareAlike reaches derived scores is Sam's call | yes | manual (form) | built: `vdem` |
| WJP Rule of Law Index | 3.7 (0.10) | none stated, UNVERIFIED | UNVERIFIED | internal research only | UNVERIFIED | direct (2021 file); newer files manual | built: `wjp` |
| Powell-Thyne coups | 4.4 (0.10) | none stated, UNVERIFIED | UNVERIFIED | internal research only | UNVERIFIED | direct (https UNVERIFIED) | built: `coups` |
| GI-TOC Organized Crime Index | 6.7 (0.05) | none stated, UNVERIFIED | UNVERIFIED | internal research only | UNVERIFIED | direct xlsx | built: `goci` |
| UCDP GED | 6.1 (0.10), 6.9 (0.05), 6.12 (0.05) | CC BY 4.0 | yes | allowed with citation | yes | API with token (existing); direct CSV possible | existing: `events.ucdp` |
| UNHCR population | 6.12 (0.05) | CC BY 4.0 per the World Bank listing; UNHCR's own terms UNVERIFIED | UNVERIFIED | internal research only until checked | UNVERIFIED | open API, no key | built: `unhcr` |
| IPC | 6.11 (0.05) | "(c) IPC. All rights reserved."; API terms not read | UNVERIFIED | not used | UNVERIFIED | API key after a request form | deferred |
| Global Terrorism Index (IEP) | 6.13 (0.05) | CC BY-NC-SA 4.0; commercial licence for sale | **no**: commercial organisations must buy a licence | blocked | n/a | request form | **blocked: Sam** |
| UNDRR GAR | 7.1 (0.15), 7.2 (0.10) | undrr.org terms: personal, non-commercial use, no redistribution | **no** (site terms) | blocked | no | no country file found | **blocked: Sam** |
| CIESIN LECZ v3 | 7.8 (0.05) | CC BY 4.0 | yes | allowed with attribution | yes | NASA Earthdata (login UNVERIFIED), .xlsm workbook | deferred (WDI route proposed) |
| ND-GAIN 2026 | 7.11 (0.05) | none stated, UNVERIFIED | UNVERIFIED | internal research only | UNVERIFIED | direct zip | built: `ndgain` |
| WRI Aqueduct 4.0 | 7.12 (0.05) | CC BY 4.0 | yes | allowed with attribution | yes | manual (form beside the link) | built: `aqueduct` |
| EPR Core 2021 | 6.10 (0.05) | none stated, UNVERIFIED | UNVERIFIED | internal research only | UNVERIFIED | direct CSV | built: `epr` |

"NDA validator UNVERIFIED" means: if no licence is stated, the default is all rights reserved, and showing the data to a
validator under NDA is Sam's call. The EXC-005 precedent says it is acceptable for internal-research data.

**Transforms that need Team B.** None of these is applied in code; each one is flagged.

| Item | Decision needed from Team B |
|---|---|
| 3.6 | Fall back to `v2x_jucon` alone where `v2xlg_legcon` is missing (no legislature)? Today the value is left blank. |
| 4.3 | Rule mapping `v2x_regime` and `v2cacamps` to the 0-4 level. |
| 4.4 | Rule mapping coup attempt and success counts, and their recency, to the 0-4 level. |
| 6.10 | Rule combining the EPR excluded-population share (a 0-1 fraction, not a percent) with the Gini to make the 0-4 level. |
| 6.12 | Neighbour list, plus the level rule combining refugees hosted and neighbour conflict. |
| 7.12 | Banding of `bws_score`, or use `bws_cat` directly. What should category -1 (arid, low water use) become? |
| 3.7 | Which data year a two-year WJP label such as "2017-2018" stands for. Today it is mapped to the last year. |
| 7.12 | Year stamp for a static baseline. Today it is stamped 2023, the release year. |

## V-Dem (3.6, 4.3)

* **Terms URL:** https://www.v-dem.net/data/the-v-dem-dataset/
* **Licence:** "published under a Creative Commons Attribution-ShareAlike (CC BY-SA) 4.0 license". The FAQ on the
  same page allows use, adaptation and sharing, including commercial use, with attribution. Adapted data must be
  shared under the same licence.
* **Commercial use:** yes.
* **Attribution:** Coppedge, Michael, John Gerring, Carl Henrik Knutsen, Staffan I. Lindberg, Jan Teorell, David
  Altman, et al. 2026. "V-Dem [Country-Year] Dataset v16". Varieties of Democracy (V-Dem) Project.
  https://doi.org/10.23696/vdemds26
* **Redistribution:** allowed under CC BY-SA. A validator under NDA may see it.
* **Open question for Sam:** if a scored indicator built from V-Dem goes into client output, does ShareAlike apply to
  that output?
* **Download:** v16 (March 2026). The download page
  (https://www.v-dem.net/data/the-v-dem-dataset/country-year-v-dem-core-v16/) is a form: email, format and a
  privacy-consent box. This makes it a **manual** download. Save the CSV, or its zip, as
  `data/panel/research/vdem/V-Dem-CY-Core-v16.csv`.
* **Layout:** codebook names `country_name, country_text_id, year, v2x_jucon, v2xlg_legcon, v2x_regime, v2cacamps`.
  The v16 file itself is UNVERIFIED.
* **Transform:**
  * 3.6 = mean(`v2x_jucon`, `v2xlg_legcon`), following the rulebook. Both indices are 0-1.
  * 4.3 is inputs only.
* **EQ-A-0095 (indicator-rules 13.1 and 13.2):** two optional columns, read when the file has them.
  * `v2cacamps_osp` (0-4) is emitted as the 4.3 polarisation input.
  * `v2lgbicam` is emitted as a 3.6 input. Where it is 0 and `v2xlg_legcon` is missing, the row
    `jucon_half_no_legislature` = `v2x_jucon` / 2 is added. It is held for Sam's sign-off.
  * A missing optional column is named in the notes. 4.3 then stays at its base level, held.

## WJP Rule of Law Index (3.7)

* **Pages read:**
  * https://worldjusticeproject.org/rule-of-law-index/: the 2026 edition, 143 countries.
  * The data page https://worldjusticeproject.org/our-work/research-and-data/wjp-rule-law-index-2020/current-historical-data
  * The Terms of Service: "These Terms apply only to use of the Community Forum".
  * The Copyright Policy https://worldjusticeproject.org/resources/copyright-policy: no data licence.
* **Licence:** none of these pages states a data licence. The only rights text is "(c) World Justice Project
  2008-2025". Licence, commercial use and redistribution are all **UNVERIFIED**, so the data is tagged internal
  research only.
* **Attribution:** World Justice Project, WJP Rule of Law Index, https://worldjusticeproject.org/rule-of-law-index/
* **Download:** the page links the file directly, with no form:
  https://worldjusticeproject.org/sites/default/files/documents/FINAL_2021_wjp_rule_of_law_index_HISTORICAL_DATA_FILE.xlsx
  That file is the 2021 edition. The URL of the current file is UNVERIFIED, so a newer file goes into
  `data/panel/research/wjp/` by hand.
* **Layout (UNVERIFIED):** a sheet with columns `Country`, `Year`, `Factor 7: Civil Justice`, and optionally
  `Country Code`. Older files with indicators in rows are refused.
* **Transform:** none. The Factor 7 score is already on a 0-1 scale.
* **Year (EQ-A-0095, indicator-rules 13.7):**
  * A two-year label ("2017-2018") gives the row its **first** year. Taking the last year was rejected.
  * An `edition_last_year` input row carries the label's last year.
  * An edition is usable from `wjp.PUBLISHED[label]`. That table is empty (dates UNVERIFIED), so editions are
    usable from 31 December of the label's last year.
* **Action:** email WJP to confirm the terms for commercial and client use.

## Powell-Thyne coups (4.4)

* **Page:** https://www.uky.edu/~clthyn2/coup_data/home.htm. The codebook is
  https://www.uky.edu/~clthyn2/coup_data/Codebook.pdf.
* **Licence:** no licence or terms on either page. **UNVERIFIED**, so the data is tagged internal research only.
* **Citation requested:** Powell, Jonathan M., and Clayton L. Thyne (2011). "Global Instances of Coups from 1950 to
  2010: A New Dataset." Journal of Peace Research 48(2): 249-259.
* **Download:** the page links http://www.uky.edu/~clthyn2/coup_data/powell_thyne_coups_final.txt. The adapter asks
  for the same path over https. Whether https serves the file is UNVERIFIED. A redirect is refused loudly; if that
  happens, download the file by hand.
* **Layout:** codebook columns `country, ccode (Gleditsch-Ward), year, month, day, coup`, where coup 1 = unsuccessful
  and 2 = successful. The delimiter is not stated, so tab or comma is accepted. UNVERIFIED.
* **Output:** inputs `coup_attempts` and `coup_successes` per country-year. Countries passed in `isos` get explicit
  zero rows for every year the file covers.

## GI-TOC Global Organized Crime Index (6.7)

* **Pages:** https://ocindex.net and https://ocindex.net/downloads. Editions: 2021, 2023, 2025.
* **Licence:** no licence, Creative Commons or terms text on either page. The only rights text is the copyright
  metadata "Global Initiative Against Transnational Organized Crime". **UNVERIFIED**, so the data is tagged internal
  research only.
* **Download:** direct, with no form (the survey and mailing list are optional):
  https://ocindex.net/assets/downloads/global_oc_index.xlsx
* **Layout (UNVERIFIED):** every sheet with `Country` and `Criminal markets` columns is read. The year comes from a
  `Year` column or from a year in the sheet name; a sheet with neither is refused. Values must be 1-10.
* **Transform:** none.

## UCDP (6.1, 6.9, 6.12)

* **Licence:** https://ucdp.uu.se/downloads/ says: "All datasets are free of charge and licensed under CC BY 4.0
  ... you are free to use and redistribute them provided you cite the relevant publications listed with each
  dataset". For GED, cite Davies, Pettersson and Oberg (2026), Journal of Peace Research,
  DOI 10.1093/jopres/xjag046.
* **API:** https://ucdp.uu.se/apidocs/. A token goes in the `x-ucdp-access-token` header. The limit is 5,000
  requests a day, and errors count towards it. Current versions: GED 26.1, Candidate 26.0.9.
* **Adapter:** already in the repo as `econquest/ingestion/events/ucdp.py`. Sam has requested the token.
* **New finding:** the GED file can be downloaded with no token, as https://ucdp.uu.se/downloads/ged/ged261-csv.zip
  (CC BY 4.0). No adapter is built for it yet. It is a wave-2 option if the token is slow to arrive.

## UNHCR (6.12, displacement)

* **API:** https://www.unhcr.org/refugee-statistics/insights/explainers/forcibly-displaced-api.html says the API is
  "open to all and requires no special credentials". The endpoint used is
  `https://api.unhcr.org/population/v1/population/?cf_type=ISO&coa_all=true&yearFrom=&yearTo=&limit=&page=`. It is
  taken from open-source clients and is UNVERIFIED against UNHCR's reference page.
* **Licence:**
  * The World Bank lists the UNHCR series SM.POP.RHCR.EA with "License : CC BY-4.0"
    (https://data.worldbank.org/indicator/SM.POP.RHCR.EA).
  * The `refugees` R package, whose copyright holder is UNHCR, is CC BY 4.0.
  * UNHCR's own data terms were not found. The licence is **UNVERIFIED** at source, so the data is tagged internal
    research only until it is checked.
* **Attribution:** UNHCR Refugee Population Statistics Database, https://www.unhcr.org/refugee-statistics/
* **Layout (UNVERIFIED):** pages of the form `{"items": [...], "page", "maxPages"}`. Each item has `year`,
  `coa_iso`, `refugees` and `asylum_seekers`. A count of "-" is treated as missing.
* **Output:** inputs `refugees_hosted` and `asylum_seekers_hosted` per country of asylum and year.

## IPC (6.11): deferred

* https://www.ipcinfo.org shows "(c) IPC. All rights reserved."
* The API page https://www.ipcinfo.org/ipc-country-analysis/api/ says: "To gain access to the IPC API, kindly fill
  in the request form ... the IPC will generate an API key". The "IPC-CH API Terms of Use" are linked from that page
  but were not read.
* Field names from the OCHA `ripc` client (https://github.com/OCHA-DAP/Ripc) are `p3plus` and `p3plus_percentage`,
  both UNVERIFIED.
* **Decisions for Sam:**
  * Request a key (a credential decision).
  * Read the terms (a licence decision).
* Coverage is about 20 of the 88 countries.

## Global Terrorism Index (6.13): blocked, licence decision for Sam

* https://www.visionofhumanity.org/maps/global-terrorism-index/ has the GTI 2026 edition (19 March 2026). It says:
  "Access Global Terrorism Index (GTI) data for free under IEP's non-commercial license".
* https://www.economicsandpeace.org/consulting/data-licensing/ says:
  * "Data from the Institute for Economics & Peace is available free of charge for non-commercial use under the
    Creative Commons Attribution-NonCommercial-ShareAlike 4.0 International License (CC BY-NC-SA 4.0)."
  * "Any use of IEP data by an organisation other than a non-profit or research institution is considered
    commercial use."
  * "Commercial organisations using IEP data must purchase a Commercial Licence before downloading any datasets."
* The price for one report, the GTI included, is USD 2,000, covering the last three years of data.
* Downloads go through a form that asks for the licence type and a consent to the terms.
* **Why this is blocked:** the decision of 17:21Z allows non-commercial data as internal research. IEP's terms,
  however, define any commercial organisation's use as commercial and require a purchase before download. Ticking
  "non-commercial" on the form would be a false statement. **Sam: buy the commercial licence, or leave 6.13 to the
  analyst.** No adapter was built.

## UNDRR GAR (7.1, 7.2): blocked

* https://www.undrr.org/gar and the GAR Atlas page list no country-level file of average annual loss (AAL) or
  probable maximum loss (PML).
* https://data.undrr.org/api/json lists only Sendai, MCR2030 and Hazard Information Profile APIs. That page says the
  data there may be copied with UNDRR cited.
* The site terms at https://www.undrr.org/quick/91862 allow download and copying "for the User's personal,
  non-commercial use, without any right to resell or redistribute them or to compile or create derivative works
  therefrom".
* The modelled successor, GIRI (https://giri.unepgrid.ch/faq), ships GeoTIFFs behind a form and carries "(c) All
  Rights Reserved by CDRI".
* **Result:** there is no file to parse, and the terms forbid derivative works. These are the two highest-weight
  indicators (0.15 and 0.10). **Sam decides:** write to UNDRR for a licence and the country tables, or keep 7.1 and
  7.2 analyst-set. No adapter was built.

## CIESIN LECZ (7.8): deferred, alternative proposed

* The LECZ v3 documentation
  (https://sedac.ciesin.columbia.edu/downloads/docs/lecz/lecz-urban-rural-population-land-area-estimates-v3-documentation.pdf)
  says: "This work is licensed under the Creative Commons Attribution 4.0 International License". Dataset DOI:
  https://doi.org/10.7927/d1x1-d702
* The dataset is hosted on NASA Earthdata
  (https://www.earthdata.nasa.gov/data/catalog/esdis-ciesin-sedac-lecz-urplaev3-3.00: "openly shared, without
  restriction"). Whether a login is needed is UNVERIFIED.
* The file is a macro-enabled pivot workbook (`.xlsm`) with filters by country, elevation source, urban concept and
  LECZ band.
* **Instead (EQ-A-0095):** the World Bank WDI series EN.POP.EL5M.ZS, "Population living in areas where elevation is
  below 5 meters (% of total population)". It is built from LECZ v3. The code is present in the WDI metadata: on
  2026-10-25, https://api.worldbank.org/v2/indicator/EN.POP.EL5M.ZS?format=json returned source 2 (WDI), with
  CIESIN LECZ v3 as the source organisation. Its **data** are UNVERIFIED until a Mac pull. Two changes go with it:
  * It is now in `feeds.WB_SERIES` as a raw-only series. It lands in raw_worldbank.csv, and no 7.8 cell is served.
  * `official.worldbank.WB_NOT_SERVED["7.8"]` says why: Team B must still choose between 5 m (this series) and
    10 m (the LECZ band the rulebook names). It is also on the Mac probe list below.

## ND-GAIN (7.11)

* **Page:** https://gain.nd.edu/our-work/country-index/download-data/. The zip
  https://gain.nd.edu/assets/647440/ndgain_countryindex_2026.zip needs no registration; the questionnaire is
  optional.
* **Licence:** none stated. The page shows only "Copyright (c) 2026 University of Notre Dame". **UNVERIFIED**, so
  the data is tagged internal research only.
* **Citation:** "Notre Dame Global Adaptation Initiative Country Index (ND-GAIN). (Current Year). University of
  Notre Dame."
* **Layout (UNVERIFIED):** the zip member `.../vulnerability/vulnerability.csv`, with columns `ISO3, Name` followed
  by one column per year. Values are 0-1, where higher means more vulnerable.
* **Transform:** none.

## WRI Aqueduct (7.12)

* **Licence:** https://www.wri.org/aqueduct says: "available for use under the Creative Commons Attribution
  International 4.0 License". So CC BY 4.0, and commercial use is allowed with attribution.
* **Download:** the dataset page https://www.wri.org/data/aqueduct-40-country-rankings shows a form (email, name,
  organisation, use) next to https://files.wri.org/aqueduct/aqueduct-4-0-country-rankings.zip. This makes it a
  **manual** download.
* **Layout (UNVERIFIED):** a sheet with `gid_0, name_0, indicator_name, weight, score, cat`. The adapter keeps the
  rows where the indicator is `bws` and the weight is `Tot`.
* **Output:** inputs `bws_score` (0-5) and `bws_cat` (-1 to 4).
* **Year stamp (EQ-A-0095, indicator-rules 13.6):** data year **2019**, the last year of the baseline according to
  Team B. The release year 2023 was rejected. Team A could not read the baseline period in the technical note
  (doi 10.46830/writn.23.00061) on 2026-10-25, so the period is UNVERIFIED. The release is usable only from
  `aqueduct.PUBLISHED` = 2023-08 (the day is UNVERIFIED), counted from the end of that month. The gate applies no
  year staleness to 7.12.

## EPR (6.10)

* **Page:** https://icr.ethz.ch/data/epr/. Latest version 2021 (released 8 June 2021), covering 1946-2021.
  Direct CSV: https://icr.ethz.ch/data/epr/core/EPR-2021.csv
* **Licence:** none stated. **UNVERIFIED**, so the data is tagged internal research only. The GESIS listing of the
  sister dataset EPR-O says "Free access (with registration)".
* **Citation:** Vogt et al. (2015), Journal of Conflict Resolution 59(7): 1327-42.
* **Layout:** codebook columns `gwid, statename, from, to, group, size, status`. UNVERIFIED.
* **Output:** input `excluded_pop_share`, the summed `size` of groups whose status is POWERLESS, DISCRIMINATED or
  SELF-EXCLUSION, as a 0-1 fraction per country-year. EQ-A-0095 (indicator-rules 13.4) adds two things:
  * `discriminated_pop_share`, the summed size of DISCRIMINATED groups (0.0 when there are none);
  * country-years whose groups are all IRRELEVANT now get 0.0 for both shares (level 0).
  Years with a STATE COLLAPSE group stay blank.

## In the pull (EQ-A-0095)

`econquest fetch` (and `pullpack`) now include the feed `research`. It is in `feeds.FEED_ALIASES` and is part of the
default fetch; `--only research` names it alone.
* Every **built** adapter in `research.REGISTRY` reads its drop-in folder `data/panel/research/<key>/`. These are
  local files only, with no network call.
* A folder with no file reads "not dropped". That is never a failure.
* A file the adapter refuses (LayoutError) reads "refused" and goes to `live/feed_failures.csv`.
* GTI, UNDRR, IPC and CIESIN (blocked or deferred) are never loaded. UCDP stays on its events path.
* `feeds.json` shows one line, for example `ok (412 rows; dropped: vdem, epr; not dropped: wjp, ...; refused: ...)`.
* The research feed is local, so it never counts as "a feed succeeded" when every network feed failed
  (`feeds.LOCAL_FEEDS`).

Cells come from Team B's rules alone (`econquest.rules.research.rule_cells`, contract C15; indicator-rules sections
1-5, 13 and 19), including 13.1 (no legislature), the 13.6 / 13.7 publication filters (`point_in_time` on the
adapters' `published` column) and 6.1 / 6.9 from stored UCDP events. Team A copies no rule (EQ-A-0118 removed the
last local override; EQ-A-0089 reads the 13.1 provenance text from `econquest.rules`). Team A only fills cells no
other feed filled.

Provenance `series` starts with `research <id>: <rule>; data year <y>; rule status <value|hold> (<reason>)`.
Provenance now has a `licence` column: the joined licence tags of the rows each cell came from, plus "World Bank WDI
(CC BY 4.0)" for a Gini part. `audit.restricted_reason` and `client_output_reason` read it. An "internal research
use only" tag keeps the value out of client output. Blank cells are listed in `unserved.csv` (feed `research`), each
with its reason.

**The gate holds every research cell.** The check is `research`, with the reason "unverified: research dataset, held
until the first gate review (EQ-A-0095)", plus Team B's own hold reason. For 3.6, 4.4, 6.10 and 7.12 it also adds
"Sam sign-off at first values (indicator-rules 13)". Nothing from this feed is applied without a review decision.

Not done yet (follow-ups):
* 13.3: coups by month. The annual fallback is in use.
* 13.5: UNHCR country of origin. 6.12 stays blocked on the UCDP token and neighbours.csv.
* WJP publication dates: `wjp.PUBLISHED` is empty, so each edition is usable from 31 December of its label's last
  year.

## In the pull pack: step 7 `research` (EQ-A-0089)

Mac file drops reach the gate in two ways, and both use the code above: the next `econquest fetch` (feed `research`),
and step 7 of the pull pack, which runs offline right after the downloads and says at once whether each file is read.

```
python -m econquest.ingestion.pullpack run --redo research
python -m econquest.ingestion.research.drops check --data data
python -m econquest.ingestion.research.drops verify --data data
```

* **No file, no failure.** With no file in any folder the step is `skipped` with the reason "no research file dropped:
  put a download into data/panel/research/KEY/ ...". With some files, each missing source is listed as `not dropped`
  with the adapter's message (the folder, the file pattern and how to get it). A file whose layout is refused is
  listed as `refused` (a layout to report), not a crash.
* **Rules.** `research.drops.check` calls `wiring.fetch` and `wiring.cells` for every desk country: Team B's rules
  only. World Bank Gini (6.10) comes from `live/raw_worldbank.csv` and UCDP events (6.1, 6.9) from the stored
  vintages, when present.
* **Gate.** `wiring.gate_checks` holds every cell. 3.6, 4.4, 6.10 and 7.12 also carry "Sam sign-off at first values"
  and are listed in the step's `held` list as parked. Nothing is applied.
* **Licence.** Each source must resolve to its own row in `data/licences.csv` by licence tag, drop folder and source
  text, and the three must agree. Each cell's client status is `audit.client_output_reason` (register first): WJP,
  Powell-Thyne, GOCI, ND-GAIN, EPR and UNHCR are withheld from client output; V-Dem and Aqueduct are allowed.
* **Output.** Only `data/live/pullpack/research/research_drops.json` and `research_cells.csv` (each cell with its
  value, the desk value it would replace, gate status and reason, register row and client status). The verify re-reads
  both (sha256), recomputes the client status and checks the drop files did not change. The landing check runs the
  same verify (`landing._v_research`).
* **Fixtures.** No research file is on disk yet, so `tests/test_research_drops_a089.py` proves the path with the
  recorded SYNTHETIC fixtures (one per adapter, plus `vdem_cy_full_v16_sample.csv` with `v2cacamps_osp` and
  `v2lgbicam`).
* **Register gap.** The `ucdp` row matches `panel/research/ucdp/`, but `research/ucdp_ged.py` reads
  `panel/research/ucdp_ged/`. The verify reports it as a note. AGENT-04 owns the register (handoff in EQ-A-0089).

## Mac drop list (EQ-A-0095)

Save each file **unchanged** and keep **one** file per folder. The name must match the adapter's pattern (shown).
The next `econquest fetch` reads the folders. `research_effect` (Team B) can be run on the same folders.

| # | Folder | File to save | Get it from | Notes |
|---|---|---|---|---|
| 1 | `data/panel/research/vdem/` | `V-Dem-CY-Full+Others-v16.csv` (pattern `V-Dem-CY-*.csv` or its `.zip`) | https://www.v-dem.net/data/the-v-dem-dataset/ (form: email, format CSV) | Prefer **Full+Others**. 4.3 needs `v2cacamps_osp` and 13.1 needs `v2lgbicam`; whether the Core file carries them is UNVERIFIED (the adapter notes "column absent", and 4.3 is then held at its base level) |
| 2 | `data/panel/research/wjp/` | the WJP historical data xlsx (pattern `*WJP*.xlsx`), e.g. `FINAL_2021_wjp_rule_of_law_index_HISTORICAL_DATA_FILE.xlsx` | https://worldjusticeproject.org/sites/default/files/documents/FINAL_2021_wjp_rule_of_law_index_HISTORICAL_DATA_FILE.xlsx (2021); newer editions from https://worldjusticeproject.org/rule-of-law-index/ | Licence UNVERIFIED: internal research only |
| 3 | `data/panel/research/coups/` | `powell_thyne_coups_final.txt` | http://www.uky.edu/~clthyn2/coup_data/powell_thyne_coups_final.txt (page https://www.uky.edu/~clthyn2/coup_data/home.htm) | Licence UNVERIFIED |
| 4 | `data/panel/research/goci/` | `global_oc_index.xlsx` | https://ocindex.net/assets/downloads/global_oc_index.xlsx | Licence UNVERIFIED |
| 5 | `data/panel/research/ndgain/` | `ndgain_countryindex_2026.zip` | https://gain.nd.edu/assets/647440/ndgain_countryindex_2026.zip | Licence UNVERIFIED |
| 6 | `data/panel/research/epr/` | `EPR-2021.csv` | https://icr.ethz.ch/data/epr/core/EPR-2021.csv | Licence UNVERIFIED |
| 7 | `data/panel/research/aqueduct/` | `aqueduct-4-0-country-rankings.zip` | https://files.wri.org/aqueduct/aqueduct-4-0-country-rankings.zip (form on https://www.wri.org/data/aqueduct-40-country-rankings) | CC BY 4.0 |
| 8 | `data/panel/research/haircuts/` | `Cruces-Trebesch-Haircuts-2014-update.xlsx` | https://docs.google.com/spreadsheets/d/1yUUMPAEF9uKbYV6bG3dLZ6dzDQnkJqcS/export?format=xlsx | EQ-A-0098 (not part of fetch; see A-haircuts.md) |
| - | `data/panel/research/unhcr/` | optional | API, no key | 6.12 is blocked anyway |

Probe on the Mac (World Bank series added raw-only): `python -m econquest.ingestion.panel_history --probe-wb
EN.POP.EL5M.ZS`. Exit 0 means a route serves it. Then check `raw_worldbank.csv` for 7.8 rows after the next fetch.

Never dropped by design: GTI, UNDRR, IPC (licence or credential decisions for Sam) and CIESIN LECZ (replaced by
EN.POP.EL5M.ZS above).

## Running one adapter by hand

```python
from econquest.ingestion import research
res = research.module("vdem").load("data")                       # reads data/panel/research/vdem/
res = research.module("goci").load("data", fetch=True)           # direct: downloads once, keeps the file read-only
res = research.module("unhcr").fetch(2015, 2025)                 # open API
res.rows, res.vintage, res.unmapped, res.notes
```
