# Runbook: free official sovereign spread history

Ticket EQ-A-0063. Owner: Team A (AGENT-02 built it, AGENT-06 owns the module). Operator: Sam, on the Mac.
Written 2026-10-24 from `econquest/ingestion/spreads.py`.

**This runbook was written offline.** The cloud cannot reach `api.stlouisfed.org` or `ecos.bok.or.kr`. Every series
code below follows the provider's documented pattern as remembered, so each one is **UNVERIFIED** until the first
pull on the Mac confirms it (section 4).

## 1. What it gives, and what it does not

For each of the 18 desk countries in `data/countries.csv`, the module gives a sovereign yield history minus the
10-year US Treasury (FRED `DGS10`), in basis points. It uses free official sources only, so no licence is bought.

| Spread type | Definition | What it measures |
|---|---|---|
| `local_minus_ust` | (local-currency 10y yield − UST 10y) × 100 | **Not a credit spread.** It includes the FX premium (expected depreciation) and the inflation differential, as well as default risk. It can be negative: JPY sits below UST. |
| `hard_minus_ust` | (US$ sovereign yield − UST 10y) × 100 | A credit spread. **No free official series is known for any desk name**, so no row of this type exists today. |

Layer 2 (`z_cds`) and the GPR elasticities read a *default-risk* spread (CDS/EMBI) in bp. A local-currency spread is a
different quantity. Team B decides whether, and how, to use it (handoff under EQ-A-0063). **Nothing in the engine
reads these files**, and there is no `apply` step.

## 2. Planned coverage (before the first pull)

`python -m econquest.ingestion.spreads plan` prints this table. `--write` also writes
`data/market_history/spreads/registry.csv` and `coverage.csv`.

| ISO | Local-currency candidate | Freq | Licence | Hard currency |
|---|---|---|---|---|
| JPN | FRED `IRLTLT01JPM156N` (OECD MEI) | M | **restricted** (OECD on FRED) | none (no US$ sovereign bonds) |
| KOR | BoK ECOS `817Y002/D/010210000` (Treasury 10y); fallback FRED `IRLTLT01KRM156N` | D (ECOS) / M | ECOS terms UNVERIFIED / restricted | none |
| IND | FRED `IRLTLT01INM156N` (MEI partner, may not exist) | M | **restricted** | none |
| COL | FRED `IRLTLT01COM156N` (OECD member since 2020) | M | **restricted** | none |
| VNM, PHL, CHN, MYS, SGP, PAK, BRA, ARG, NGA, SEN, ZMB | manual only: the publisher is named, but no machine API is known here | – | – | none |
| BLZ, VEN, ZWE | none: no local market with published yields | – | – | none (VEN in default, ZWE in arrears) |

So at best **4 of 18** desk names get a usable spread, all `local_minus_ust`, and 3 of those 4 are restricted.
`coverage.csv` gives the reason for every name that gets no spread. The ECB yield curves and the convergence
long-term rates cover the euro area and the EU only. No desk country is in the euro area. XOF is pegged to the euro,
but WAEMU sovereigns such as Senegal are not in ECB data.

## 3. Licences

| Source | Terms | Flag |
|---|---|---|
| FRED `DGS10` (Fed H.15) | US government data, public domain. Cite FRED. FRED terms: https://fred.stlouisfed.org/legal/ (UNVERIFIED) | `restricted = False` |
| OECD MEI `IRLTLT01*` on FRED | Third-party data. FRED shows it as copyright OECD, reprinted with permission (UNVERIFIED) | **`restricted = True`**: internal research only, no client output, no data room |
| BoK ECOS | Free registered key. BoK terms (UNVERIFIED) | `restricted = False`, terms unverified |

Every output row carries `restricted`. The data room already withholds everything under `data/market_history/spreads/`,
because only `vintages/` and `builds/` directly under `market_history/` are room-safe (SEC-A-007 M1). Replay snapshots
skip the folder (`replay.SKIP_DIRS`). The OECD's own data portal may license the same series under CC BY 4.0. That is
UNVERIFIED, and a direct OECD pull is a follow-up that could lift the restriction.

## 4. Commands (Mac)

```bash
cd ~/econquest && source .venv/bin/activate
export FRED_API_KEY=...          # 32 lower-case letters/digits; from the keychain or shell profile, never a file
export ECOS_API_KEY=...          # optional (Korea daily); or keychain service "econquest", account ECOS_API_KEY

# 1. plan: registry and coverage, no network
python -m econquest.ingestion.spreads plan

# 2. check each candidate code exists before trusting it (one FRED call per code; keys never printed)
for s in DGS10 IRLTLT01JPM156N IRLTLT01KRM156N IRLTLT01INM156N IRLTLT01COM156N; do
  curl -s "https://api.stlouisfed.org/fred/series?series_id=$s&api_key=$FRED_API_KEY&file_type=json" \
    | python -c 'import json,sys; d=json.load(sys.stdin); s=(d.get("seriess") or [{}])[0]; print(s.get("id"), "|", s.get("title"), "|", s.get("frequency"), "|", s.get("observation_end"), "|", (s.get("notes") or "")[:160].replace("\n"," "))'
done
# ECOS: confirm the STAT_CODE / ITEM_CODE1 of the Treasury 10y daily yield
curl -s "https://ecos.bok.or.kr/api/StatisticItemList/$ECOS_API_KEY/json/en/1/100/817Y002" | python -m json.tool | head -60

# 3. pull + raw vintage + staged build (default: 1 Jan ten years back .. today UTC)
python -m econquest.ingestion.spreads build --start 2016-01-01 --end 2026-10-23
#    point in time (ALFRED: FRED values as known on that date; the end date is capped at it)
python -m econquest.ingestion.spreads build --start 2016-01-01 --asof 2025-06-30

# 4. status: every vintage hash-checked (exit 1 if one fails), latest build coverage
python -m econquest.ingestion.spreads status

# rebuild from a saved vintage (no network), e.g. after marking series verified
python -m econquest.ingestion.spreads build --vintage <YYYY-MM-DDTHHMMSSZ-hash8>
```

After step 2, record each confirmed code in `data/market_history/spreads/series_verified.csv`: set `verified=yes`
and fill `checked_on`, `checked_by` and `evidence` (the FRED title and the observation end). A row counts only for the
exact `series_key` it names. An existing build is never overwritten. If you mark a series verified after a build,
rebuild with a new pull: `build --vintage` refuses when the result would differ from the build already on disk.

Check before sending results back:
- the title of `IRLTLT01INM156N` says India and the series is still updated. If the code does not exist, India drops
  to manual;
- the FRED notes for the OECD series state the copyright line. Send the exact wording to AGENT-09 for the licence flag;
- `status` shows `"check": "ok"`, and `coverage.csv` in the build lists the usable names.

## 5. Files

```
data/market_history/spreads/
  registry.csv            every candidate (iso3, leg, source, api, series_key, freq, tenor_y, licence, restricted, note)
  coverage.csv            planned coverage per desk country, with the reasons
  series_verified.csv     Sam's verification marks (all "no" today; never overwritten by plan --write)
  vintages/index.csv      vintage_id, retrieved_utc, hash, n_files
  vintages/<id>/          raw_fred.csv, raw_ecos.csv (parsed rows as delivered), request.json   (0444)
  builds/<id>/            spreads_daily.csv, spreads_monthly.csv, coverage.csv, spreads.provenance.json (0444)
```

Nothing is written at the top level of `data/market_history/`: `garch.load_prices` merges every top-level CSV there
into the price history.

Columns of `spreads_daily.csv` and `spreads_monthly.csv`: `date, period, iso, country, leg, spread_type, freq,
tenor_y, yield_pct, ust_pct, spread_bp, n_days, yield_source, yield_series, ust_series,
includes_fx_inflation_premium, restricted, verified`.

Rules:
- **No fill.** A daily row exists only on a date both the local series and DGS10 published.
- **Monthly rows** are calendar-month means, dated at the month end, because the average is only known then. A daily
  series needs at least 10 observations in the month. The UST month is the mean of DGS10 business days, the same
  definition as FRED GS10. A native monthly series (OECD, which FRED dates on the 1st) is re-dated to the month end. A
  month ending after `end` is dropped.
- **One source per country and leg**, never mixed across dates: the first registry entry that returned data. Korea
  uses ECOS first and FRED only when ECOS returns nothing. The coverage `reason` says which source was skipped.

## 6. Failure behaviour

| Case | Result |
|---|---|
| `FRED_API_KEY` missing or malformed | error before any request; nothing written |
| FRED unreachable (proxy refusal, DNS) on DGS10 | `FeedUnreachable` after one request; nothing written |
| DGS10 empty or unreadable | error; nothing written (no benchmark, no spread) |
| `ECOS_API_KEY` missing | Korea falls back to FRED monthly; a failure line names the key |
| one series fails (404, bad answer) | other series continue; the failure line is kept in `request.json` and the sidecar (credentials redacted) |
| a host refuses mid-run | no further request to that host; the others continue |

## 7. Not done here (follow-ups)

- Wiring into layer 2 or the GPR elasticities: Team B's decision (handoff HO under EQ-A-0063).
- A hard-currency leg: no free official source is known. EMBI, Bloomberg, ICE and LSEG need a licence (EQ-A-0033
  vendor adapters).
- Parsers for MoF Japan (daily JGB CSV) and Tesouro Nacional (Brazil): the layouts need confirming first.
- An OECD direct pull through `official/oecd.py`: it may remove the FRED third-party restriction (UNVERIFIED).
- Adding the module to the Mac pull pack (`pullpack.py`), once the codes are verified.
