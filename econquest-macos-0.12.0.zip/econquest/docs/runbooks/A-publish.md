# Runbook: publish to the Risk Desk workbook (`econquest publish`)

Ticket EQ-A-0009. Owner: Team A, AGENT-06 (runbook). Team C owns `presentation/sheets_publish.py` and
contract C11. Operator: **Sam only**. Written 2026-10-23 from `econquest/cli.py` (`resolve_token`,
`cmd_publish`) and `docs/governance/change-control.md` step 6.

## Purpose

Run the full pipeline and write every model tab of "Geopolitical-Macro Risk Desk" as values: 101 ranges,
plus the GARCH and Econometrics tabs when price history exists.

## Who may publish

Only Sam. Agents and cloud sessions never publish to the live workbook (CLAUDE.md rule 5). An agent may
produce `outputs/publish_plan.json` without a token for Sam to inspect.

## When

- After `fetch --apply` (`A-fetch-on-mac.md`).
- After an approved model or limit change (change-control step 6).
- Otherwise on demand.

## Prerequisites

- The run you mean to publish is the latest one: `econquest run` succeeded and `econquest runs --limit 2`
  shows the expected `code_hash` and `data_hash`.
- An OAuth access token with the spreadsheets scope for the account that owns the workbook. Google access
  tokens usually expire after about an hour.
- **Token handling.** Nothing writes the workbook unless you ask: pass `--write`, or an explicit
  `--token-file PATH`. Without either, `publish`, `record`, `audit`, `benchmark`, `garch`, `econ` and `dsa` save
  the plan JSON and never look for a token, even with one in the Keychain. `--token-file` wins; with `--write`
  the token comes from `$ECONQUEST_SHEETS_TOKEN`, then the Keychain item `econquest-sheets` (the command stops
  if neither has one). `--dry-run` saves the plan and never calls Sheets. Store the token with
  `security add-generic-password -U -s econquest-sheets -a "$USER" -w`; this prompts, so the token stays out
  of shell history. Remove it with `security delete-generic-password -s econquest-sheets`. `--token VALUE` was
  removed (EQ-C-0076): passing it stops with an error. Never put the token in a file inside `~/econquest`, a
  chat or a log. The README section "Sheets token" is the reference.

## Steps

```bash
cd ~/econquest
econquest run                                   # 1. fresh base run; note var99 / es99
econquest runs --limit 2                        # 2. hashes as expected
econquest publish --mc-rows 2000 2>&1 | tee outputs/publish-$(date +%Y%m%d-%H%M).log   # 3. publish
econquest audit && econquest benchmark          # 4. Audit Trail and PD Benchmarks tabs
```

To preview without writing to the live sheet, make a copy of the workbook in Drive and run
`econquest publish --spreadsheet-id <copy id>`. Running `publish` with no token found only saves
`outputs/publish_plan.json`.

## Verification (anchors, contract C11)

1. The log shows `Publish plan: N ranges, about X cells` and then `Wrote <cells> cells to 1w4OLCkv...`.
2. Cell **A2** of every model tab shows today's run date.
3. **Risk Engine rows R31-R33** (hazard PD, rating PD, Merton distance to distress) are filled for all 18
   countries.
4. Portfolio VaR results and the Backtesting block match `outputs/run_latest.json` (VaR99 and ES99 to the
   printed precision).
5. Tab names are unchanged and no input tab was touched. Labels and the GOOGLEFINANCE formulas on Market
   Feeds are still in place.

## Failure handling

| Symptom | Action |
|---|---|
| `HTTP Error 401` | Token expired. Store a new one and rerun step 3. Publishing is a values write to fixed ranges, so rerunning is safe |
| `HTTP Error 403` | Wrong account or scope. Get a token for the workbook owner with the spreadsheets scope |
| `HTTP Error 400` naming a range | A tab or anchor was renamed in the sheet (C11 break). Stop, do not rename back by guesswork, and raise it with Team C |
| Wrong numbers published | Republish from the correct data (`A-restore.md`, then steps 1-3). For formulas, see the Drive backup in `A-restore.md` |
| `No Sheets token found ... plan saved only` | Expected without a token. Apply the plan only through Sam's own Sheets client |

## Owner

Runbook: Team A, AGENT-06. Publishing: Sam. Code and anchors: Team C (C11). Credential review: AGENT-09.
