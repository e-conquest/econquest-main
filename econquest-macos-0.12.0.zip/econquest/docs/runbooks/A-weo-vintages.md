# Runbook: point-in-time WEO vintage archive (`weo_vintages`)

Ticket EQ-A-0064. Owner: Team A (AGENT-01 built it; AGENT-06 owns the feeds area). Operator: Sam (import) and any
agent (verify, list, asof). Written 2026-10-24. Code: `econquest/ingestion/weo_vintages.py`. Tests:
`tests/test_weo_vintages.py` (synthetic WEO-shaped data only).

## Purpose

Keep every IMF World Economic Outlook release (April and October, from October 2007; earlier releases if dropped in
by hand) as an immutable, verified vintage, so that the nowcast (Team B, EQ-B-0071) and the hazard refit can ask
"what did the WEO say on date D?" with no look-ahead.

Nothing is downloaded by this tool. It converts what `panel_history` already pulled (runbook
`A-full-panel-fetch.md`, step 2), so there is no second download.

## Layout

```
data/panel/weo_vintages/
  index.csv                          append-only: release, release_date, release_date_basis, imported_utc,
                                     content_hash, n_files, raw_kind, raw_sha256, normalised_sha256, rows,
                                     n_countries, n_indicators, route
  2019-04/                           one folder per release, folder 0555, files 0444, never rewritten
    raw_<name>                       the raw file (see "Raw kinds")
    raw.sha256                       "<sha256>  raw_<name>" (check with: shasum -a 256 -c raw.sha256)
    weo_long.csv                     iso3, indicator, year, value, vintage, release_date
    manifest.json                    source, route, method, licence, release_date (+ basis and rule), hashes,
                                     row/economy/indicator counts, which panel_history run or file it came from
```

`content_hash` in `index.csv` is a SHA-256 over every file in the folder (name, NUL, bytes, NUL in name order), the
same scheme as `data/live/vintages` and `data/panel/vintages`. The first index row for a release is the reference;
later rows never override it.

### Raw kinds

| raw_kind | When | Raw file | weo_long.csv |
|---|---|---|---|
| `release_file` | panel_history took the release from the weo package (2007-10 to 2018-10, 2021-04, 2023-10, fallback to 2025-04) or from a manual drop-in (`weo_<YYYY-MM>.xls` in the cache, e.g. pre-2007) | the IMF tab file byte for byte, from `data/panel/staging/weo_cache/` | every subject code and economy in the file. panel_history's staged rows are checked equal to it; a cache file that is not the one parsed is refused |
| `panel_history_extract` | panel_history took the release through imf-reader (2019-04 to 2025-04 except 2021-04 and 2023-10; SDMX 3.0 from 2025-10). imf-reader returns a parsed table, so no download was kept | panel_history's rows (`hazard_panel.WEO_CODES` only) as canonical CSV; this is not the IMF's file, and the manifest says so | the five WEO_CODES only |

So coverage of indicators differs by release: releases fetched through imf-reader have only GGXWDG_NGDP, GGXONLB_NGDP,
BCA_NGDPD, NGDP_RPCH and PCPIPCH. `manifest.json` (`normalised.indicators`) and `list` show what each release holds.

### Release dates (estimated)

The IMF's exact publication day is not in the pull and is not guessed. Every vintage gets the **last calendar day of
its release month** (`2019-04` -> `2019-04-30`; the autumn 2011 release `2011-09` -> `2011-09-30`), with
`release_date_basis = estimated` in the manifest, the index and every row's `release_date`. WEO databases normally
come out in the middle of the release month, so this date is late: `weo_asof` may still return the previous release
for about two weeks after the real publication, but it never returns a release before it was public. If a release
was ever posted after the end of its month, the rule would be early for it; none is known (not verified). Replacing
the estimate with official dates would be a new release folder schema (vintages are never edited) and needs a
source for the dates.

### Licence

Every manifest carries: `IMF: internal research use only (Sam 2026-10-24; commercial reuse/bulk download need IMF
permission); disclosure to the independent model validator under NDA allowed (Sam 2026-10-24)` (EXC-003 in
`docs/governance/issues-log.md`). Do not put these files in client output.

## Steps (on Sam's Mac, after a panel_history pull)

```bash
cd ~/econquest
# 1. Find the run: the pull prints "new run <run_id>"; or list the staging folder.
ls data/panel/staging/

# 2. Dry run, then import every WEO release of that run (ok units only; an incomplete run can be imported too).
.venv/bin/python -m econquest.ingestion.weo_vintages import --from data/panel/staging/<run_id> --dry-run
.venv/bin/python -m econquest.ingestion.weo_vintages import --from data/panel/staging/<run_id> 2>&1 | tee outputs/weo-vintages-import-$(date +%Y%m%d-%H%M).log
echo "exit code: ${PIPESTATUS[0]}"     # 0 = nothing refused, 1 = some release refused (see its line), 2 = usage error

# 3. Verify and list.
.venv/bin/python -m econquest.ingestion.weo_vintages verify
.venv/bin/python -m econquest.ingestion.weo_vintages list
```

Options: `--releases 2007-10:2026-10` or a comma list limits the releases; `--cache-dir DIR` if the pull used
`--cache-dir`; `--from data/panel/weo_history.csv` imports from the assembled file instead (when the staging run was
cleaned up; the cache is looked up in `data/panel/staging/weo_cache`); `--root DIR` for another archive folder.

After each new WEO release (April, October): run the pull for the new release, then step 2 on its run. Older releases
in the run come back `unchanged`.

## Using it

Python (the nowcast, the hazard refit):

```python
from econquest.ingestion.weo_vintages import weo_asof, NoVintageError
df = weo_asof("2019-12-31", indicators=["NGDP_RPCH", "PCPIPCH"], countries=["BRA", "TUR"])
df.attrs["vintage"], df.attrs["release_date"], df.attrs["missing_indicators"]
```

- Returns the rows (iso3, indicator, year, value, vintage, release_date) of the one latest release whose
  `release_date <= as_of`. Releases are never mixed; an indicator the chosen release lacks is listed in
  `attrs["missing_indicators"]` and is not filled from an older release.
- The chosen release is verified first (`verify=True`); a failure raises `WeoVintageError`.
- Before the first archived release: `NoVintageError` (or an empty frame with `strict=False`). With releases from
  October 2007 the point-in-time history starts with the 2007-10 release (as of 2007-10-31). Earlier years need Team
  B's rule (HO-20261023-A-B-007).
- `year` includes the IMF's projections for later years, as published in that release.
- The function never reads the clock; the caller passes as_of. Hazard row year t: `weo_asof(f"{t}-12-31")`.

Command line: `python -m econquest.ingestion.weo_vintages asof --as-of 2019-12-31 [--indicators A,B] [--countries
X,Y] [--out file.csv]` (exit 1 if no release is on or before the date).

## Verification

`verify` (all releases, or `verify 2019-04 2019-10`) checks, per release: the folder has exactly the four files;
`raw_<name>` matches the manifest sha256 and `raw.sha256`; `weo_long.csv` matches its sha256, its row count, and its
`vintage`/`release_date` columns match the manifest; an estimated `release_date` follows the rule; the folder content
hash equals the first `index.csv` row and every index row for the release agrees; index rows without a folder are
reported. Writable files are reported as warnings. Exit 0 when all pass, 1 otherwise.

## Results of an import, and what to do

| Status | Meaning | Action |
|---|---|---|
| `created` | new release folder written and indexed | none |
| `unchanged` | the release is archived with the same raw and normalised hashes | none (no-op) |
| `covered` | an extract import whose every row is already in the archived release with the same value (e.g. from `weo_history.csv` after the cache was cleaned) | none (no-op) |
| `refused: ... already archived with different content` | the IMF file or values differ from the archived vintage | nothing is written. Do not delete the vintage. Tell Team A (AGENT-08) with the log line: either the source changed (a revised file under the same release) or the pull is wrong |
| `refused: ... downloaded file ... is not there` | panel_history used the weo package or a local file, but the cache file is gone | pass `--cache-dir`, or `--allow-extract` to archive only the five WEO_CODES (the full file can then never be added: vintages are not upgraded) |
| `refused: ... not the file panel_history parsed` / `has changed since panel_history read it` | the cache file was replaced after the pull | re-run the pull for that release (new run), then import that run |
| `refused: ... does not match the run manifest sha256` / `unit ... is not ok` | the staged file was changed or the unit failed | resume the run (`panel_history --resume`) or start a new one |
| `refused: existing vintage fails verification` | the archived folder was tampered with or damaged | run `verify`, report to Team A; do not import over it |

## Failure handling

- **verify fails**: do not use the release. Report the output to Team A. Restore the folder from the backup or the
  upload zip; never edit files in place.
- **Interrupted import**: a release is built in a hidden temp folder and renamed into place, then indexed. A crash
  between the two leaves a folder without an index row; `verify` reports it, and a re-import refuses it. Report it to
  Team A, who check the folder against the run and remove it with `chmod -R u+w` + `rm -r` before re-importing.

## Cleanup

Never delete or edit a release folder that a fit, a nowcast log or a handoff may reference. The folders are
read-only; removal needs `chmod -R u+w data/panel/weo_vintages/<YYYY-MM>` first. `index.csv` is append-only.

## Upload

`data/panel/weo_vintages/` is under `data/panel`, so the upload zip in `A-full-panel-fetch.md` includes it. The raw
WEO files make it large (estimate: 10-40 MB per `release_file` release, before zipping); it is the point-in-time
record, so keep it in the zip.

## Risks and limits

- Releases fetched through imf-reader carry only the five WEO_CODES and no IMF file (see Raw kinds). A small,
  optional change to panel_history could store the imf-reader table per release; not done (follow-up).
- Release dates are estimates (above).
- Pre-2007 releases exist only as manual drop-ins; panel_history reads them, and this tool archives them like any
  other release file.
- No real WEO data has been archived yet: the cloud cannot reach the IMF, and no panel_history run exists in
  `data/panel` so far.
