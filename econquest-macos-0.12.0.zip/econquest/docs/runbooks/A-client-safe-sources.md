# Client-safe sources: non-IMF routes for IMF-derived cells (EQ-A-0106)

Owner: Team A, AGENT-02. Code: `econquest/ingestion/official/client_safe_route.py`. Tests:
`tests/test_client_safe_route_a106.py` (recorded data only). Model side: HO to B/AGENT-08 (wiring and definitions).

## Why

IMF data is for internal research use only (EXC-003, Sam 2026-10-24 12:38Z). Licence enforcement withholds every cell
that cites the IMF. On the 2026-10-23 data, Team B's client-safe comparison (`outputs/client-safe-comparison/2026-10-23`,
EQ-B-0096) withholds 492 cells. 465 of them are IMF cells in 29 Inputs indicators and 27 are Yahoo cells.
**No Country Profile cell is IMF-sourced:** pop, exports, reserves and policy come from the World Bank and BIS, or from
seeds that cite no IMF source. fx3m and equity_vol are Yahoo.

Before this ticket, Team B gave a cleared value to 18 of the 465 IMF cells (5.14, from World Bank GDP over population).
It put the rulebook midpoint in 198 required cells and left 249 blank.

## The rule

For each indicator, `ROUTE` lists the sources in order. A client-safe build uses the first step that is client `yes`,
verified, built and has a value. **The IMF is always last and is used only in internal mode.** Internal mode is
unchanged: `feeds.fetch_all` and the quality gate never call this module.

| client | meaning |
|---|---|
| yes | cleared: World Bank own data (national accounts, IDS, Comtrade via WITS), BIS, OECD, ECB, Eurostat, national sources |
| conditional | IMF data republished in a World Bank dataset (WDI metadata names IMF IFS, BOP, FSI or GFS). It is computed, and its series text names the IMF, so `audit.client_output_reason` withholds it. It is never used for a client cell until Sam or AGENT-09 rule on it (below). This is the rule Team B already applied to "IMF IFS via WDI" (HO-20261024-A-B-011, item 3). |
| no | IMF (EXC-003): internal mode only |

"verified" means the code and its values are present in recorded data in the shared folder: `data/live/` (2026-10-23)
and Sam's `team/inbox/pull-20261025T013150Z/raw_worldbank.csv` (sha256 d700f70f316d2a37..., 25 series, 216 economies).
Every other code is UNVERIFIED and is on the probe list. Nothing was fetched from the cloud.

When the client-safe build has no client `yes` value, the cell keeps Team B's fallback: the rulebook midpoint for a
required input, blank otherwise. The replacement text then carries a label, "no free non-IMF substitute (EQ-A-0106):
<why>".

## Table

Cells = withheld IMF cells on the 2026-10-23 data. "Cleared now" counts cells that get a client value from recorded
data once Sam's World Bank pull is landed in `data/live/`. "Conditional" counts cells that would be filled if the
IMF-compiled World Bank series are cleared.

| Indicator | IMF source today | Replacement (route order, IMF last) | Verified | Cells | Cleared now | Conditional |
|---|---|---|---|---:|---:|---:|
| 1.1 debt service % revenue | econquest dsa on WEO interest, debt, GGR | WDI GC.XPN.INTP.RV.ZS (IMF GFS, interest only) | UNVERIFIED | 18 | 0 | 0 |
| 1.2 FX debt service 24m % reserves (MYS SGP JPN KOR VEN) | analyst seed (IRFCL) | IDS DT.TDS.DPPG.CD / reserves: IDS has no rows for these 5 (for the 13 IDS names it is a D3-conditional step, EQ-A-0117) | yes (code) | 5 | 0 | 0 |
| 1.3 gross government debt | WEO GGXWDG_NGDP | national debt stock (BCB 13762, BRA); OECD general government debt (JPN KOR COL); WDI GC.DOD.TOTL.GD.ZS (IMF GFS, central government) | UNVERIFIED | 18 | 0 | 0 |
| 1.4 gross financing need | IMF Fiscal Monitor (seed) | none | - | 18 | 0 | 0 |
| 1.6 primary balance gap | WEO GGXONLB, GGXCNL, GGXWDG, NGDP | none | - | 18 | 0 | 0 |
| 1.7 change in debt/GDP, 5y | WEO GGXWDG_NGDP | OECD general government debt; WDI GC.DOD.TOTL.GD.ZS (IMF GFS) | UNVERIFIED | 18 | 0 | 0 |
| 2.1 net usable reserves % ARA | IMF ARA metric (dsa_inputs.csv) | Team B rule 17 ARA on WDI reserves, GDP, exports, broad money + IDS ST debt + national IIP (section below; reserves and broad money are IMF IFS via WDI); WDI FI.RES.TOTL.MO, months of imports (IMF IFS; different metric) | UNVERIFIED (broad money, IIP) | 18 | 0 | 0 |
| 2.2 external financing need | seed; built rule uses WEO CA | WDI BN.CAB.XOKA.GD.ZS x NY.GDP.MKTP.CD + IDS (IMF BOP and IFS) | yes (codes) | 18 | 0 | 0 (no common year in Sam's pull: DT.AMT.* projections only, pre EQ-A-0086 window) |
| 2.3 hot money | IMF IIP / investor base (seed) | BIS debt securities (different concept) | UNVERIFIED | 18 | 0 | 0 |
| 2.4 FX deposits | IMF FSI (seed) | national FX deposit statistics | UNVERIFIED | 18 | 0 | 0 |
| 2.5 exchange regime | IMF AREAER (seed) | Ilzetzki-Reinhart-Rogoff classification (licence unknown) | UNVERIFIED | 18 | 0 | 0 |
| 2.6 official backstop | IMF lending arrangements (seed) | none | - | 18 | 0 | 0 |
| 2.7 access to dollar banking | WB/IMF reports (seed) | FATF public statements, manual re-entry | UNVERIFIED | 18 | 0 | 0 |
| 2.8 current account | WEO BCA_NGDPD | OECD BOP (JPN KOR COL); WDI BN.CAB.XOKA.GD.ZS (IMF BOP) | WDI yes | 18 | 0 | 16 |
| 2.11 export concentration | seed (IMF BoP / Comtrade) | rule 2.11 WDI v1, TX.VAL.*.ZS.UN (Comtrade via WITS) | **yes** | 18 | **6** | 0 |
| 2.12 REER vs 10y (8 non-BIS names) | IMF REER (seed) | BIS (none for these 8); Bruegel REER; WDI PX.REX.REER (IMF IFS) | UNVERIFIED | 8 | 0 | 0 |
| 3.8 budget and data credibility | IMF DSBB / Article IV (seed) | Open Budget Survey, PEFA | UNVERIFIED | 18 | 0 | 0 |
| 5.1 banks' claims on government | IMF MFS (seed) | national monetary survey | UNVERIFIED | 18 | 0 | 0 |
| 5.2 FX loans | IMF FSI (seed) | national FX loan statistics | UNVERIFIED | 18 | 0 | 0 |
| 5.4 commodity-linked credit | IMF credit data (seed) | Pink Sheet + WDI FS.AST.PRVT.GD.ZS (IMF IFS) | UNVERIFIED | 18 | 0 | 0 |
| 5.5 inflation | WEO PCPIPCH | national CPI (BCB 13522, BCRA 28, BoK 901Y009); OECD CPI; WDI FP.CPI.TOTL.ZG (IMF IFS) | WDI yes | 18 | 0 | 15 |
| 5.6 real GDP growth t+1 | WEO NGDP_RPCH t+1 | World Bank Global Economic Prospects forecast; OECD Economic Outlook | UNVERIFIED | 18 | 0 | 0 |
| 5.8 lenders outside banks | IMF FSAP (seed) | FSB NBFI monitoring report | UNVERIFIED | 18 | 0 | 0 |
| 5.9 credit gap (9 non-BIS names) | computed from IMF data (seed) | BIS (none for these 9); WDI FS.AST.PRVT.GD.ZS HP gap (IMF IFS, method unapproved) | UNVERIFIED | 9 | 0 | 0 |
| 5.10 NPLs (VEN SEN ZWE) | IMF FSI (seed) | WDI FB.AST.NPER.ZS (IMF FSI): no values for these 3 | yes (code) | 3 | 0 | 0 |
| 5.12 growth volatility | WEO NGDP_RPCH 15y SD | WDI NY.GDP.MKTP.KD.ZG (World Bank national accounts) 15y SD ex 2020-21 | **yes** | 18 | 0 (pull has 6 years, rule needs 8) | 0 |
| 5.13 real policy rate (8) | BIS policy minus WEO PCPIPCH | BIS minus BIS CPI (WS_LONG_CPI); BIS minus national CPI; BIS minus WDI FP.CPI.TOTL.ZG (IMF IFS) | WDI yes | 8 | 0 | 7 |
| 5.14 GDP per person | WEO NGDPDPC | NY.GDP.MKTP.CD / SP.POP.TOTL | **yes** | 18 | 18 (Team B fallback, kept) | 0 |
| 7.13 recovery speed | IMF reviews / WEO (seed) | WB real GDP path after an EM-DAT date (EM-DAT licensed) | UNVERIFIED | 18 | 0 | 0 |
| **Total** | | | | **465** | **24** | **38** |

Print it from the code: `python -m econquest.ingestion.official.client_safe_route --route-table`

## Counts (client-safe cells with a cleared real value, out of 465 IMF cells)

| State | Cleared | Placeholder | Blank |
|---|---:|---:|---:|
| Before (Team B, 2026-10-23 data) | 18 | 198 | 249 |
| After, shipped `data/live` (9 WB series; no TX.VAL, no growth history) | 18 | 198 | 249 |
| After, Sam's WB pull landed in `data/live` | 24 | 192 | 249 |
| Projected, next pull with `feeds.WB_HISTORY_MRNEV` (5.12, 20 years) | 42 | 174 | 249 |
| Projected, if Sam clears IMF-compiled WDI series | up to 80 | | |

The withheld set does not change: 492 cells (465 IMF). The route changes only what a withheld cell is replaced with.

Note: at 17:07Z on 2026-10-25 the shared data changed (another ticket). The 13 econquest-dsa 1.2 cells went back to
their seeds, which cite "IMF reserves", so the withheld IMF count is now 478 (+13 blank 1.2 cells, with no free
substitute for the same reason as the other 5). The route's effect is unchanged: +6 cleared (2.11) once Sam's pull is
landed. The test checks it relative to the data as it stands. Update (EQ-A-0117): the 13 econquest-dsa 1.2 cells
are back on their computed values, and with the `imf_via_wdi` row at its default "no", the withheld set is 527. See
"D3 switch" below; that section's counts supersede this one.

## Cells with no free substitute

No free substitute exists in data we hold or can add today without a licence. These cells stay blank or on the
placeholder, with a label:

- **1.1, 1.4, 1.6, 2.6** (72 cells): only IMF (fiscal, GFN and programme data). The national-budget alternatives have
  no adapter.
- **1.3, 1.7** (36): only UNVERIFIED cleared candidates (national, OECD, 3 to 4 names). The World Bank series is IMF GFS.
- **1.2** (5: MYS SGP JPN KOR VEN): IDS does not cover them.
- **2.1** (18): the ARA metric is the IMF's own methodology. Months of imports would be a different indicator (Team B).
- **2.2** (18): every component path goes through IMF BOP or IFS data in WDI. Even with it there is no common year in
  the recorded pull.
- **2.3, 2.4, 5.1, 5.2, 5.8** (90): only national, BIS or FSB sources, all UNVERIFIED and with no adapter.
- **2.5, 2.7, 3.8** (54): research or manual sources (IRR, FATF, IBP/PEFA) with unknown licences. For 2.7, a manual
  re-entry citing FATF only would clear it.
- **2.12** (8), **5.9** (9), **5.10** (3): BIS has no series for these names. The WDI fallbacks are IMF IFS or FSI.
- **5.4, 7.13** (36): need IMF credit data or licensed EM-DAT.
- **5.6** (18): only forecasts. WB GEP and OECD EO are cleared candidates but UNVERIFIED (no adapter, no register row).
- **2.8, 5.5, 5.13** (44): conditional only (IMF BOP or IFS in WDI). National and OECD candidates are UNVERIFIED.
- **5.12** (18): a free substitute exists and is built, but the recorded pull has 6 years of growth and the rule needs
  8 usable ones. The next pull fixes this; it is not a missing source.
- **2.11** (12): rule 2.11 itself holds ARG and ZWE (coverage below 75%) and VEN (stale), and blanks the 9
  manufacturers. The placeholder stays.

## Wiring (Team B)

`validation.client_safe.plan_replacements` is Team B's file. The one change asked of Team B (HO to B/AGENT-08) is to call,
after the existing fallbacks:

```
from econquest.ingestion.official.client_safe_route import apply_route, client_safe_values
cls = apply_route(cls, client_safe_values(d, as_of))
```

`apply_route` touches only withheld IMF Inputs cells whose fallback is blank or the placeholder. The withheld set,
Team B's 5.14 and 2.1 recomputes and every non-withheld cell stay as they are (tested).
`client_safe_values` reads only `live/raw_worldbank.csv` and `live/raw_bis.csv`. It reads them only when the
licence register lets them out (fail closed).

## Definition changes for Team B to decide (in the handoff)

- **5.12**: the WEO window runs to year t and includes the current-year projection. The WDI window ends at the last
  actual year (published by 30 June of t+1). Same formula otherwise (tested for parity on the same numbers).
- **2.8, 5.5, 5.13** (conditional only): WDI gives the last actual year, while WEO gives year t, a projection. On the
  recorded data: KOR CA 6.6 (WDI 2025) vs 18.8 (WEO 2026); ARG CPI 219.9 (2024) vs 32.5. The route refuses a WDI year
  older than the last usable one, so ARG, VEN and ZWE CPI are refused.

## 2.1 inputs for Team B's non-IMF ARA (HO-20261025-B-A-002, indicator-rules 17)

**First, a licence point.** Under the rule above, two of the rule-17 inputs are IMF-compiled in WDI: WDI
FI.RES.TOTL.CD (reserves) and FM.LBL.BMNY.GD.ZS (broad money; WDI metadata as recalled names IMF IFS). So the
rule-17 route is **conditional**, not cleared. It becomes a client source only with Sam's ruling on IMF-compiled WDI
series (When Sam is ready). The national rows below are the cleared alternative, one country at a time.

1. **Broad money FM.LBL.BMNY.GD.ZS.** It is already opt-in in the World Bank panel probe set
   (`panel_history.WB_PANEL_UNVERIFIED`, HO-20261025-A-B-010): `pullpack run --steps wb_panel --wb-panel-codes <the
   six defaults>,FM.LBL.BMNY.GD.ZS` once `--probe-wb panel` serves it. It is on the probe list below and in the When
   Sam is ready items. Not fetched.
2. **Other liabilities: national IIP portfolio-investment liabilities, US$.** No free cross-country non-IMF series
   exists. OECD publishes IIP for JPN, KOR and COL (OECD SDMX, licence row `oecd`, terms UNVERIFIED). Otherwise the
   source is the national compiler. None has an adapter, a code in recorded data, or terms read. All are
   **UNVERIFIED**, licence **unknown**.

   | Country | National IIP source (publisher) | Licence |
   |---|---|---|
   | Vietnam | State Bank of Vietnam (BOP; no regular IIP found) | none known: mark none |
   | Philippines | Bangko Sentral ng Pilipinas, IIP | unknown |
   | China | SAFE, International Investment Position | unknown |
   | Malaysia | DOSM / Bank Negara Malaysia, IIP | unknown |
   | Singapore | Singapore Department of Statistics, IIP | unknown (SingStat open-data terms not read) |
   | Japan | Ministry of Finance / Bank of Japan, IIP; or OECD | unknown / `oecd` |
   | South Korea | Bank of Korea ECOS, IIP (ECOS adapter exists for other concepts) | unknown (`ecos` row) |
   | India | Reserve Bank of India, IIP | unknown |
   | Pakistan | State Bank of Pakistan, IIP | unknown |
   | Belize | Central Bank of Belize, IIP | unknown |
   | Brazil | Banco Central do Brasil, IIP (SGS) | unknown (`cb_registry`, licence_ok=no) |
   | Argentina | INDEC, IIP | unknown |
   | Colombia | Banco de la Republica, IIP; or OECD | unknown / `oecd` |
   | Venezuela | Banco Central de Venezuela (publication irregular) | none known: mark none |
   | Nigeria | Central Bank of Nigeria, IIP | unknown |
   | Senegal | BCEAO (WAEMU), IIP | unknown; 2.1 is blank for Senegal anyway (rule 17.2) |
   | Zambia | Bank of Zambia, IIP | unknown |
   | Zimbabwe | Reserve Bank of Zimbabwe | none known: mark none |
3. **National net-reserves figure (usable share) for PAK, ARG, VEN, NGA.** None of the four central banks publishes
   an official net-of-swaps-and-pledges figure that we know of. SBP (PAK), BCRA (ARG, `cb_registry` series 1:
   gross reserves, UNVERIFIED), BCV (VEN) and CBN (NGA) publish gross reserves. Net figures in the market are analyst
   or IMF-programme estimates, so the answer is **none**. Rule 17.4 applies: these four stay held.
4. **ara_applicable flag.** It is now `official.client_safe_route.ARA_NOT_APPLICABLE` (Singapore, Japan) with
   `ara_applicable(country)`. It is a desk judgement in code, readable without `dsa_inputs.csv`. A test keeps it
   equal to the `dsa_inputs.csv` column the internal engine still reads. Team B: read it from there in
   `nonimf_ara`.
5. **Short-term external debt for MYS, KOR, VEN** (outside IDS):
   - BIS consolidated banking statistics, claims with remaining maturity up to one year (feed `bis_cbs`, licence row
     `bis` allowed). Codes UNVERIFIED, and no recorded rows. It covers bank claims only, not total short-term
     external debt, so it is a proxy for Team B to accept or not.
   - National: Bank Negara Malaysia external debt by maturity, Bank of Korea ECOS short-term external debt. UNVERIFIED,
     licence unknown, no adapter.
   - Venezuela: none. Leave the cell held.
   - The World Bank QEDS (EQ-A-0108, `official/qeds.py`) is a joint World Bank and IMF database: same conditional
     status.

## Probe list (UNVERIFIED codes; one Mac pass after the MVP)

1. WDI indicator metadata (`sourceOrganization`) for FP.CPI.TOTL.ZG, BN.CAB.XOKA.GD.ZS, FI.RES.TOTL.CD,
   FI.RES.TOTL.MO, FB.AST.NPER.ZS, GC.DOD.TOTL.GD.ZS, GC.XPN.INTP.RV.ZS, NY.GDP.MKTP.KD.ZG: confirms which are IMF-compiled.
2. NY.GDP.MKTP.KD.ZG with 20 years (comes with the next normal `fetch`; `feeds.WB_HISTORY_MRNEV`).
3. BIS consumer prices dataflow (WS_LONG_CPI) for the 8 BIS policy-rate names (5.13).
4. OECD general government debt, CPI, BOP and Economic Outlook projections for JPN, KOR, COL (1.3, 1.7, 2.8, 5.5, 5.6).
5. World Bank Global Economic Prospects forecast download (5.6), plus a register row for it.
6. Central-bank series already in `data/panel/cb_series_verified.csv` (all verified=no): BCB 13522/13762, BCRA 28,
   BoK 901Y009.
7. FM.LBL.BMNY.GD.ZS (broad money; `--probe-wb panel`) and its WDI metadata; BIS CBS short-term claims on MYS, KOR,
   VEN; OECD IIP for JPN, KOR, COL (2.1 inputs above).
8. Licences: Bruegel REER, Ilzetzki-Reinhart-Rogoff, FATF statements, Open Budget Survey, PEFA, FSB NBFI data.

## D3 switch: IMF-compiled WDI series (EQ-A-0117)

Sam's decision D3 asks whether IMF-compiled WDI series are client-safe. These are IFS, BOP, FSI and GFS indicators
that the World Bank republishes under CC BY 4.0. The decision is one switch: the `imf_via_wdi` row of
`data/licences.csv`.

- **Undecided (the shipped default).** The row has `client_output = restricted`, and its match_series is only the
  tag `[imf_via_wdi]`. The route's conditional (COND) steps write that tag into their series text. As a result:
  - client output is exactly what it was before the row existed: 481 withheld cells on the shipped data;
  - `test_default_register_withholds_what_it_did_before_the_row` checks every recorded cell;
  - the conditional values are not used.

  An earlier version of this row matched the WDI codes at the default. That withheld reserves for all 18 names, and
  the client build failed with "universe not ready". The row was narrowed on 2026-10-26.
- **"Yes".** One `econquest change` sets the row's client_output to `allowed`. `client_safe_route.d3_yes()` reads the
  row, and `apply_route` then uses the COND steps.
- **"No".** One `econquest change` widens the row's match_series to `client_safe_route.D3_STRICT_SERIES`. That pattern
  matches FP.CPI.TOTL.ZG, BN.CAB.XOKA.*, FI.RES.TOTL.*, FM.LBL.BMNY.GD.ZS, FB.AST.NPER.ZS, GC.(DOD|XPN|NLD|REV).*,
  PX.REX.REER and FS.AST.PRVT.GD.ZS. Before "no" can be applied, Country Profile reserves needs a non-IMF fallback
  from Team B; without one the client build stops. The 1.2 and 5.10 cells just become blank.
- **Patches.** `python -m econquest.ingestion.official.client_safe_route --d3-patch yes` prints the patch for "yes";
  use `--d3-patch no` for "no". The commands are in docs/runbooks/A-sam-ready.md, item 8. licence_gov classes both
  patches as Tier 1.
- **Unchanged either way.** A series text that names WEO, or that names the IMF in plain words, still matches
  `imf_derived` and stays restricted. Two examples are the wdi_extra "IMF IFS via WDI" texts and the 2.1 sums with WEO
  inputs. BX.GSR.TOTL.CD (QEDS 2.10 denominator) is not in the pattern, because match_series is capped at 200
  characters; the QEDS label restricts 2.10 anyway.

Internal values are the same under all three states. data/ values do not move, so Team B's base holds.

To reproduce the report:

```
python -m econquest.ingestion.official.client_safe_route --as-of 2026-10-23 --d3-report --wb team/inbox/pull-20261025T013150Z/raw_worldbank.csv --out /tmp/d3
```

The command writes `d3_no_withholds.csv` and `d3_yes_clears.csv`. Without `--wb`, it reads the shipped `data/live`
pull.

The counts below cover all 1594 Inputs and Country Profile cells, with Sam's 2026-10-25 WB pull and as-of date
2026-10-23:

| Count | D3 no | D3 yes |
|---|---:|---:|
| Client cells with a real value | 1107 | 1191 |
| Withheld (all components) | 527 | 481 |
| Withheld IMF and D3 | 511 | 465 |
| ... given a cleared non-IMF value: route | 6 | 44 |
| ... Team B recompute (5.14) | 18 | 18 |
| ... rulebook placeholder | 192 | 161 |
| ... blank | 295 | 242 |

Today (undecided), the withheld cells are the "yes" set (481). The 38 cells stay a placeholder or blank, so 1153
client cells have a real value (1191 - 38).

With the shipped `data/live` pull instead, the client cells with a real value are 1101 under "no" and 1147 under
"yes".

- **"No" withholds 46 cells that are allowed today (and while undecided).**
  - Country Profile reserves (FI.RES.TOTL.CD / NY.GDP.MKTP.CD): 18 cells.
  - 1.2 econquest dsa (World Bank IDS debt service over FI.RES.TOTL.CD): 13 cells.
  - 5.10 FB.AST.NPER.ZS (IMF FSI): 15 cells.

  The earlier estimate was 32. The difference is that the 1.2 cells came off their seeds again and one more reserves
  cell matched. Under "no", reserves is blank for all 18 names, a required field, so the client build stops (see above).
- **"Yes" fills 38 cells that "no" leaves as a placeholder or blank:** 2.8 (16 cells), 5.5 (15) and 5.13 (7).
  - These cells are filled from IMF-compiled WDI values.
  - "Yes" also keeps the 46 cells above.
- **1.2 conditional step (new).** The step takes `engine.dsa.ppg_debt_service_detail` (IDS DT.TDS.DPPG.CD, the next
  two years after as_of.year-1) and divides it by the latest FI.RES.TOTL.CD. Countries that IDS does not cover (for
  example Malaysia) get no value.
- **Team B mapping (after "no").** Enforcement labels a D3-withheld cell with its source row (`worldbank_wdi` / `worldbank_ids`), so
  `plan_replacements` files it as component "other". The report re-labels these cells as "imf" from `d3_flips()`. Team B
  is asked (handoff) to map `imf_via_wdi` to "imf".

## 1.5 proxy (HO-20261025-A-B-008, indicator-rules 18), built under this ticket

- `ids_fc_debt.METHOD_APPROVED` now holds "1.5". Each cell note reads "proxy: IDS PPG external / WEO GG debt, year Y;
  external, not foreign-currency".
- New gate check `seed`: a first value (the applied cell does not already come from `ids_fc_debt`, per
  `audit_trail.csv`) more than 20 points from the `indicators.csv` value is held, with reason "1.5 proxy vs seed".
- Every first 1.5 value is also held by `tier1` ("Tier 1: Sam sign-off (parked): 1.5 first value", the same start as the 1.8 CRAG hold, so the Mac-pass landing lists
  it as a Tier 1 item; ARCH-A-PI10 R3, EQ-A-0117),
  including values within 20 points of the seed. Once a cell is applied from `ids_fc_debt`, later values are not
  first values.
- Every 1.5 cell is still held by `unverified`: DT.DOD.DPPG.CD is in no pull. The value has a WEO input, so it stays
  client-restricted (`imf_derived`). The first values are a parked Tier 1 batch for Sam.

## When Sam is ready (after the MVP)

- D3: one `econquest change` of the `imf_via_wdi` row for either answer (docs/runbooks/A-sam-ready.md, item 8).
  "No" waits for Team B's reserves fallback. AGENT-09 prepares the clause from the WDI metadata (probe 1).
- Land the 2026-10-25 World Bank pull (`team/inbox/pull-20261025T013150Z/raw_worldbank.csv`) through the normal
  pull-pack landing. That clears the 6 cells of 2.11 in the client-safe build.
- Run the probe list above on the Mac pass, including FM.LBL.BMNY.GD.ZS via `--probe-wb panel` (2.1).
- The 1.5 proxy's first values (13 IDS names) are a Tier 1 data batch, once DT.DOD.DPPG.CD is verified.

## Client-safe dataset: both D3 answers (EQ-A-0124)

`econquest/ingestion/client_safe_dataset.py` builds a variant of data/mvp for each D3 answer, side by side, in its own
folder `outputs/client_safe_dataset/` (Team A, AGENT-02). Nothing existing changes: data/, data/mvp (sha256
d3564255485aa044..., EQ-A-0130) and the `imf_via_wdi` row (undecided) stay as they are. The builder refuses an output folder inside
data/ and refuses to patch data/licences.csv.

Commands, run from the econquest folder:

```
python -m econquest.ingestion.client_safe_dataset build --d3 both
python -m econquest.ingestion.client_safe_dataset verify --d3 both
python -m econquest.ingestion.client_safe_dataset compare
```

`--d3 yes` or `--d3 no` builds or verifies one answer. `--route-wb team/inbox/pull-20261025T013150Z/raw_worldbank.csv`
reads Sam's recorded 2026-10-25 World Bank pull for the route instead of data/mvp's own file (see below).

How one variant is built:

1. data/mvp is verified and its data directory copied to a private work folder. In that copy only, each cell whose
   provenance says only "econquest full fetch ..." is re-stamped with its vintage record (data/live/provenance.csv
   and data/live/vintages/*/provenance.csv, same cell and same value), so the licence rule sees the feed
   (`source_restamp`, file `source_restamp.csv`). `verify` recomputes it and fails if any cell's work-copy record is
   less specific than its vintage record. A generic record with no vintage record of the same cell and value fails
   closed: it is listed with status `unmatched`, its source becomes "unestablished source: ..." (`UNMATCHED_SOURCE`),
   which matches no register row, so the licence rule withholds the cell as unregistered. The generic text itself
   matches the `econquest_derived` row (client_ok yes), so without this step those cells would ship. Build and
   `verify` fail if an unmatched cell is not withheld.
2. The D3 answer is applied to the copy's register only (`client_safe_route.d3_patch`). While the variant is built,
   every licence hook reads that copy.
3. The withheld cells are Team B's rule, `validation.client_safe.withheld_cells`, and the copy is Team B's
   `build_client_safe_copy`. That copy also leaves out restricted files and the EXC-005 price columns. The build
   stops unless its withheld set equals Team B's plan cell for cell.
4. Replacements come from Team B's labelled fallbacks, then from `client_safe_route.apply_route`. Under "yes" the
   conditional steps (IMF-compiled WDI) count. Under "no" only cleared steps count.
5. Checks. The build writes nothing unless all of them pass:
   - 0 cells from `audit.restricted_source_cells` and `audit.client_restricted_cells`, under the simulated register;
   - every cell Team A's audit restricts in data/mvp is in the withheld set;
   - the gate report has 0 unexplained cells, and `ops.demo.probe_gate` has 0 unexplained;
   - load and scorecard readiness pass. If readiness refuses, the error names the fields and the withheld cells
     behind them.

Files in each `d3_yes` and `d3_no` folder:

| File | Contents |
|---|---|
| `data/` | the client-safe data directory, read-only; raw-file rows are filtered by series |
| `data/client_safe.json` | the INTERNAL marker: internal_only, the notice and the placeholder cells |
| `provenance.csv` | one row per cell, with a label: live, seed, route, recomputed, official, placeholder or blank |
| `withheld.csv` | each withheld cell's register row, reason, fallback, label and new value (never the restricted value) |
| `replacements.csv` | the record of each replacement value |
| `source_restamp.csv` | each re-stamped cell: generic data/mvp source, vintage source, series and evidence file |
| `gate_review.csv` | data/mvp's gate review without the withheld cells |
| `gate_report.json` | the gate outcome of each cell |
| `licences_d3_yes.csv` or `licences_d3_no.csv` | the simulated register |
| `manifest.json` | sha256 of each file, plus dataset_sha256 and the check results |

`comparison.md` and `comparison_cells.csv` sit beside the two folders.

Result on data/mvp d3564255... (EQ-A-0130 rebuild, built 2026-10-26T13:29:17Z; as_of 2026-10-25; register sha256
ffad313d..., 96 rows), with data/mvp's own World Bank file. Variants built 2026-10-26T13:32Z (EQ-A-0130, AGENT-02;
handoff HO-20261026-A-B-014 to Team B; validation/client_safe.py sha256 5096d705...). PI-12 values (data/mvp 129268fc)
in brackets:

| | D3 yes | D3 no |
|---|---:|---:|
| dataset_sha256 | 686b3d24e7687205... (19bdc818...) | e1d984709bf52109... (8e7a8979...) |
| Withheld (IMF + EXC-005 fx3m + source not established) | 485 = 480 + 5 + 0 (524) | 516 = 511 + 5 + 0 (555) |
| ... route | 0 | 0 |
| ... recomputed (5.14, World Bank GDP / population) | 18 | 18 |
| ... placeholder | 203 (211) | 221 (229) |
| ... blank | 264 (295) | 277 (308) |
| Generic records re-stamped from their vintage record (matched) | 0 (280) | 0 (280) |
| Generic records with no vintage record (unmatched, withheld) | 0 (39) | 0 (39) |
| 1.6 rows re-stamped with the WEO derivation text in the work copy | 0 (15) | 0 (15) |
| Restricted cells left (desk / client audit) | 0 / 0 | 0 / 0 |
| Gate unexplained / probe_gate unexplained | 0 / 0 | 0 / 0 |
| Restricted raw rows (dropped) | 0 (0) | 0 (192) |
| Readiness | ok | ok |
| data/client_safe.json internal_only | true | true |

The two variants differ in 31 cells: Country Profile reserves for 18 names (FI.RES.TOTL.CD) and Inputs 5.10 for 13
names, all IMF-compiled WDI series withheld under "no". Reserves take Team B's judgement placeholder
`validation.client_safe.RESERVES_PLACEHOLDER_PCT_GDP`, read from Team B's module (HO-20261026-A-B-001, labelled
placeholder), so "no" passes readiness; 5.10 is left blank (no cleared fallback). Before the vintage re-stamp only 3
reserves cells differed: data/mvp named the other 15 reserves and 13 5.10 cells only as "econquest full fetch".

fx3m (HO-20261026-B-A-006). The five EXC-005 currencies (VND, PKR, VES, NGN, ZMW: Vietnam, Pakistan, Venezuela,
Nigeria, Zambia) came from the theratesapi mirror and are withheld under both answers. None has a cleared BIS / ECB /
parity value, so each takes Team B's stressed placeholder `validation.client_safe.FX3M_PLACEHOLDER_PCT`, read from
Team B's module (labelled placeholder, fallback "judgement placeholder: fx3m (stressed)"). The build and `verify`
fail on a withheld fx3m cell that is blank, 0 or an analyst seed; the manifest's `fx3m_placeholder` lists the names.

Caveats:

- **Fixed in EQ-A-0130 (data/mvp d3564255...).** data/mvp now names each cell's feed and series and stamps the 1.6
  derivation text at source, so the work-copy re-stamps find nothing to do (0 records). The 39 cells below trace to
  World Bank (team/inbox/pull-20261025T013150Z/raw_worldbank.csv) and are served under both answers (live labels under
  "yes" 142 -> 181), so withheld falls by exactly 39 in each variant; 1.6 live cells and the 5 EXC-005 fx3m cells stay
  withheld. The re-stamp and fail-closed code stays as a guard for any older data/mvp. The PI-12 text follows.
- (PI-12) data/mvp provenance does not name the feed (ARCH-A-PI10 R4). data/mvp's live/provenance.csv gives each
  applied-vintage cell only "econquest full fetch on Sam's Mac, vintage ...", so a licence rule keyed on the source
  (EXC-005 theratesapi, imf_via_wdi WDI series) misses it. data/mvp is not changed in PI-12: the builder re-stamps its
  private work copy (above). **The fix belongs in the PI-13 data/mvp rebuild: mvp_dataset must carry each cell's feed
  source and series into live/provenance.csv.** Of 319 generic records, 280 match a vintage record; the re-stamp
  newly withholds 5 cells under "yes" (the fx3m cells) and 33 under "no" (the 5 fx3m, 15 reserves, 13 of 5.10).
  The other 39 (2.9 x8, 3.4 x13, 3.5 x18; the full fetch's review.csv records no source, and data/live and its
  vintages have no value for them) are withheld under both answers: 2.9 is required, so it takes Team B's required
  placeholder; 3.4 and 3.5 are blank.
- Required Inputs placeholders follow Team B's EQ-B-0130 (c) rule: after the route, the builder calls
  `validation.client_safe.stress_placeholders`, so a cell still on the t50 marker takes the rulebook worst score
  t100 (206 cells in each variant). `client_safe_route.d3_report` does the same: it routes Team B's pre-route plan
  once per outcome, then calls `stress_placeholders` (HO-20261026-B-A-007). Each manifest records the
  validation/client_safe.py sha256 it was built with (`team_b.client_safe_py_sha256`), and `verify` reports whether
  the file is unchanged since (`client_safe_py_current`).
- These folders are INTERNAL. The register has no approved version yet (no_baseline), so nothing here clears output
  for clients. That still needs Sam's baseline and his D3 answer through `econquest change`.
- On data/mvp's own World Bank file, "yes" adds no route value. That file lacks BN.CAB.XOKA.GD.ZS, FP.CPI.TOTL.ZG and
  the 2.11 TX.VAL series, and the 1.2 conditional step is refused for these names.
- WEO inputs named only in the provenance (HO-20261026-B-A-005). data/mvp's applied-vintage audit rows give the
  source "econquest full fetch on Sam's Mac ..." with an empty series, and the WEO code appears only in `transform`.
  `audit.client_output_reason` now also reads the free-text provenance (`transform` and the other
  PROVENANCE_TEXT_COLUMNS), using Team C's WEO code rule (`ops.licence_rule.weo_code_re`, EQ-C-0151).
  `client_restricted_cells` carries the audit trail's transform onto the current pull's record of the same value.
  That withholds 133 more data/mvp cells: 1.3, 1.6, 1.7, 2.8, 5.5, 5.6, 5.12, 5.13 and 5.14.
- 1.6 is computed from WEO inputs. `audit.TRANSFORMS["1.6"]` now names them (GGXONLB_NGDP, GGXCNL_NGDP, GGXWDG_NGDP,
  NGDP). The builder re-stamps the transform text in its private work copy only (manifest `audit_transform_restamped`),
  so Team B's rule and Team A's audit both withhold 1.6.
  **The next audit run on data/, or the next data/mvp rebuild, will change only 1.6's transform text in
  audit_trail.csv, with no value change; data/mvp's dataset sha moves then.**
- With the fixed check, data/mvp reports 0 restricted cells for the desk (`restricted_source_cells`, what
  `mvp_dataset verify` checks). It reports 480 client-restricted cells, which are IMF and allowed there, because
  data/mvp is internal. Before the fix the client figure was 347.
- With `--route-wb` set to Sam's recorded pull (sha256 d700f70f..., not yet landed; counts measured before the WEO
  provenance fix), the counts change:
  - "yes": route 18, placeholder 79, blank 247;
  - "no": route 6 (2.11), placeholder 84, blank 257;
  - the variants then differ in 15 cells;
  - every check still passes.
- Team B's `plan_replacements` has passed the conditional route values under "yes" since 05:54Z
  (`include_conditional=d3_yes(reg)`, HO-20261026-A-B-003). Team B's plan and this dataset now carry the same values,
  so the manifest's `route_values_added` is 0.
- Raw files are filtered row by row (SEC-A-014 P2-M1). Team B's `file_decision` clears a file by its path, so
  `live/raw_worldbank.csv` would otherwise ship IMF-compiled rows under "no": 192 rows of FI.RES.TOTL.CD and
  FB.AST.NPER.ZS. The builder drops every row whose source or series `audit.client_output_reason` restricts under
  the variant's register. The build also fails if a shipped raw file still holds such a row. The manifest's
  `raw_rows_dropped` lists what was dropped.
- Each `data/` folder carries `client_safe.json` (SEC-A-014 P2-L4, HO-20261026-B-A-002). It holds
  `"internal_only": true`, the INTERNAL notice and the placeholder cells, so a copied `data/` keeps both. It stays
  true until the approved register itself carries the D3 answer, and `verify` refuses a marker set to false.
