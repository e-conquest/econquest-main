# Runbook: real-data day rehearsal (demo row M21)

Ticket EQ-A-0138. Owner: Team A, AGENT-06. Written 2026-10-26 from `econquest/ingestion/rehearsal.py`. Feeds Team C's
M21 (C-0166). Related: `A-mac-pull-pack.md` (the pull), `A-landing-check.md` (what comes back), `team/first-mac-pass.md`
(Sam's steps), `A-event-taxonomy.md` (GDELT categories, now on by default).

## Purpose

Before the first real Mac pass, the rehearsal replays Sam's earlier uploads and a set of SYNTHETIC fixtures through the
landing kit: `landing.py`, `macpass_landing.py`, `replay.py`, the pull pack and the feeds apply. It also tests the
upgrade path from every shipped zip since 0.4.2. Every failure mode must end in one plain-English line and a safe
state. A safe state means no Python traceback, no half-written `data/`, `data/mvp` either the old or the new dataset,
and nothing left half-built.

The rehearsal works on copies in a private temporary folder. It never writes `data/` or `data/mvp`, and its last row
(Z1) re-hashes both to prove it. It makes no network calls: the UCDP row unsets the token variable for its own run, and
the upgrade rows install with `ECONQUEST_INSTALL_SKIP_VENV=1`, which copies files only (no venv and no pip).

## The command (M21)

From the econquest folder (zsh-safe):

```zsh
cd ~/econquest
python -m econquest.ingestion.rehearsal run --zips ~/Downloads
```

- `--zips DIR` is the folder that holds the shipped `econquest-macos-<version>.zip` files and their `.sha256` files.
  Leave it out to skip the upgrade rows.
- `--current ZIP` gives the release zip of the current tree. By default the rehearsal builds one into its temporary
  folder with `scripts/build_release.py`, which takes about 30 s.
- `--quick` leaves out the two rows that rebuild `data/mvp` on a copy (S1 and S10/S11).
- `--keep` keeps the temporary folder and prints its path. `--json` prints every row as JSON at the end.
- `--out DIR` also writes `rehearsal.json` (every row) and `rehearsal.md` (a table and the M21 line) there. `econquest
  rehearse` (EQ-C-0168) passes `outputs/rehearsal/<UTC>/`. A folder inside the data folder is refused.

Exit code 0 means every row is ok and 1 means at least one is not. It runs in about 55 s with `--zips` (seven zips).
The source data folder must hold no symbolic link (AGENT-09 R-L1); a linked source is refused in one line.

Team C wraps it as `econquest rehearse [--zips DIR] [--quick] [--out DIR]` (EQ-C-0168, HO-20261026-A-C-016).

## Expected output (2026-10-26 19:00Z, current tree 0.10.0, data/mvp d3564255, all seven zips present)

Long paths and messages are shortened here. The last line is the M21 line:

```
[rehearsal] econquest 0.10.0 real-data day rehearsal (EQ-A-0138); copies in <tmp>; .../data and its mvp/ are read only
R1   ok  replay    pull-20261024T183257Z landing check            exit 2   steps: fail 1, not landed 2, not uploaded 5, missing 4
R2   ok  replay    pull-20261024T183257Z Mac-pass check           exit 2   refused: partial upload: review.csv missing ...
R3   ok  replay    pull-20261025-fullfetch Mac-pass check         exit 2   refused: partial upload: report.json, pullpack.log missing ...
R4   ok  replay    pull-20261025T013150Z landing check            exit 2   steps: fail 1, not landed 2, not uploaded 5, missing 4
R5   ok  replay    pull-20261025T013150Z Mac-pass check           exit 2   refused: stale upload: the pull pack ran econquest 0.4.2 ...
R6   ok  replay    pull-20261025T121034Z landing check            exit 2   steps: not landed 3, not uploaded 5, missing 4
R7   ok  replay    pull-20261025T121034Z Mac-pass check           exit 2   refused: partial upload: review.csv, pullpack.log missing ...
S1   ok  SYNTHETIC first pass, dry run (data/mvp kept)            exit 0   dry run: data/mvp kept, candidate discarded ...
S2   ok  SYNTHETIC partial pull: pullpack.log missing             exit 2   refused: partial upload: pullpack.log missing ...
S3   ok  SYNTHETIC partial pull: a step still running             exit 2   refused: partial upload: the pull pack had not finished (fx running) ...
S4   ok  SYNTHETIC partial pull: review.csv cut in half           exit 2   refused: partial upload: review.csv lacks 280 cells ...
S5   ok  SYNTHETIC stale feed: pack from econquest 0.4.2          exit 2   refused: stale upload: the pull pack ran econquest 0.4.2 ...
S6   ok  SYNTHETIC stale feed: vintage not newer than data/mvp    exit 2   refused: stale upload: vintage ... is not newer than ...
S7   ok  SYNTHETIC corrupt upload: report.json cut short          exit 1   error: report.json is not readable JSON ...
S8   ok  SYNTHETIC corrupt upload: SHA256SUMS mismatch            exit 1   error: hash mismatch, the upload is not what the Mac produced ...
S9   ok  SYNTHETIC corrupt upload: report.json steps damaged      exit 1   error: report.json is damaged: 'steps' is not a list ...
S10  ok  SYNTHETIC interrupted landing (Ctrl-C at the swap)       exit 1   interrupted: stopped before the end; data/mvp and data/ are as they were ...
S11  ok  SYNTHETIC landing killed between renames, next start     recovered  data/mvp put back from .mvp-old-<vintage> ...
S12  ok  SYNTHETIC corrupt vintage: apply refuses                 refused  vintage 2026-10-25T170547Z-67dffc57 failed verification: hash ...
S13  ok  SYNTHETIC corrupt frozen snapshot: replay refuses        refused  .../snapshots/2026-10-25T170547Z-67dffc57-inputs: hash mismatch ...
S14  ok  SYNTHETIC partial pull: nothing finished (landing)       exit 2   1 fx reported pending landing not landed pending: not run
S15  ok  SYNTHETIC corrupt pack: state.json cut short (landing)   exit 1   error: state .../state.json cannot be read: JSONDecodeError ...
S16  ok  SYNTHETIC missing token: UCDP (Keychain not exported)    exit 2   ... ucdp: skipped (0s) - UCDP_API_TOKEN is not set ...
S17  ok  SYNTHETIC corrupt pack: state.json damaged (pullpack)    exit 1   error: .../state.json cannot be read (JSONDecodeError); nothing was run ...
S18  ok  SYNTHETIC interrupted pull (Ctrl-C): state saved         exit 130 interrupted: the step that was running is recorded as failed ...
S19  ok  SYNTHETIC wrong folder: landing check in ~/Downloads copy exit 1  error: .../Downloads/econquest/data is not an econquest data folder ...
S20  ok  SYNTHETIC wrong folder: pull pack in ~/Downloads copy    exit 1   (same message)
S21  ok  SYNTHETIC wrong folder: Mac-pass landing --root Downloads exit 2  refused: wrong folder: ...
S22  ok  SYNTHETIC interrupted apply (Ctrl-C between the 2 files) restored apply stopped before both files were written: indicators.csv put back ...
U1   ok  upgrade   0.4.2 -> 0.10.0                                kept     backup <UTC> holds 92/92 files; kept 89, updated by design 3 (in the backup), lost 0, overwritten 0; review ledger kept, verifies (3 pre-chain rows, anchored at the next decision); held cells 26 (0 released by the upgrade); outputs kept; marker version=0.10.0
U2   ok  upgrade   0.5.0 -> 0.10.0                                kept     ... 101/101 ... (same as U1: 3 pre-chain ledger rows, held cells 26, 0 released)
U3   ok  upgrade   0.6.0 -> 0.10.0                                kept     ... 100/100 ...; held cells 32 (0 released by the upgrade, 31 more held from the review.csv or rules the release brings)
U4   ok  upgrade   0.7.0 -> 0.10.0                                kept     ... 184/184 ...; held cells 31 (0 released); data/mvp refreshed from the release, old copy in the backup
U5   ok  upgrade   0.8.0 -> 0.10.0                                kept     (as U4)
U6   ok  upgrade   0.9.0 -> 0.10.0                                kept     (as U4)
U7   ok  upgrade   0.10.0 -> 0.10.0                               kept     ... 186/186 ...
U1c  ok  code      0.4.2 -> 0.10.0 program files                  match    1720/1720 release program files match, copied with rsync --checksum
U2c  ok  code      0.5.0 -> 0.10.0 program files                  match    1720/1720 ... rsync --checksum; 1 file(s) of 0.5.0 left in place (install.sh never deletes): xxe.xlsx
...  (one Uc row after each U row; U4c also lists release-data/live/snapshots/2026-10-25T170637Z-pre-apply/countries.csv left from 0.7.0)
Z1   ok  safety    data/ and data/mvp untouched                   unchanged  re-hashed after the rehearsal: all 234 files of data/ (73 under mvp/)
[rehearsal] M21 PASS: 30/30 replay and failure-mode rows ended in a plain message and a safe state; upgrades 7/7 kept data/, backup and review ledger (0.4.2, 0.5.0, 0.6.0, 0.7.0, 0.8.0, 0.9.0, 0.10.0 -> 0.10.0); program files 7/7 match the release (rsync); zips missing: none
```

With `--quick` the line reads `27/27 replay and failure-mode rows` (S1, S10 and S11 are left out); the upgrade part is
the same.

R1 and R4 say `fail 1`: that is the panel_history step, which also failed on the Mac in those two pulls (no history run
manifest on disk, and weo_history.csv without the WEO vintage column). The rows are ok because a partial landing (exit
2) with a plain message is the expected outcome for a recorded upload sent without its data folder.

For the demo, check the last line. `M21 PASS` and exit 0 mean the rehearsal passed. Row counts change when new uploads
appear in `team/inbox/pull-*`. Each recorded pull gives one or two R rows.

## What each row family proves

| Rows | Failure mode | Expected outcome |
|---|---|---|
| R | Sam's recorded uploads (`team/inbox/pull-*`) | The landing check gives exit 2 (partial: files were not sent with the pack). The Mac-pass check refuses: no review.csv or pullpack.log, or a 0.4.2 pack is older than the Mac pass needs. No traceback. |
| S1 | First pass (SYNTHETIC: recorded review, pack re-stamped as the current version) | The dry run rebuilds a candidate `data/mvp`, verifies it, runs the M2 probe and discards it |
| S2-S4, S14 | Partial pull | Refused, exit 2. Names what is missing or unfinished |
| S5-S6 | Stale feed | Refused, exit 2: the pack is older than 0.7.0, or the vintage is not newer than `data/mvp` |
| S7-S9, S12, S13, S15, S17 | Corrupt upload, vintage, snapshot or state | Error, exit 1, with a plain line. Apply and replay refuse before writing; replay leaves no partial folder |
| S16 | Missing token (UCDP; Keychain item not exported) | The ucdp step is skipped with the reason: `UCDP_API_TOKEN is not set ...` (never on the command line) |
| S19-S21 | Wrong folder: the unzipped release in `~/Downloads` (release-data/, no data/) | The message names release-data/ and points to `~/econquest`. Nothing changed |
| S10, S11 | Interrupted landing (Ctrl-C at the `data/mvp` swap; a hard kill between its two renames) | `data/mvp` stays the old dataset; after a kill, the next landing puts it back |
| S18 | Interrupted pull (Ctrl-C) | Exit 130. state.json records the step as `interrupted`, and rerunning resumes |
| S22 | Interrupted apply (Ctrl-C after indicators.csv, before countries.csv) | Both files are put back from the pre-apply snapshot; stderr says so |
| U | Upgrade from each shipped zip | `data/` is backed up first (all files, same hashes) and nothing is lost or overwritten (model config may update by design; the backup holds the old copy). The review ledger, written by the installed version's own code (a hold and a four-eyes release on two held cells, plus one off-review hold), is byte-identical and verifies with the current code. No held cell is released by the upgrade (effective holds before, with the old code, against after, with the current code). outputs/ is kept, and the marker shows the new version. data/mvp may be kept (installer before EQ-C-0168) or refreshed from the release with the old copy in the backup (EQ-C-0168); both pass |
| Uc | Upgraded program files are the release's | After each upgrade, every program file of the install (all but data/, outputs/, the marker, the venv and caches) is hashed against the release's own tree. A release file missing or different is a FAIL naming the files. Files of the old version the release no longer has stay in place (install.sh never deletes) and are listed, not failed. The row says which copy path install.sh took: `rsync --checksum`, `rsync WITHOUT --checksum` or tar (an `rsync` shim on PATH logs install.sh's calls) |
| Z1 | Rehearsal writes nothing real | Every file of data/, data/mvp included, re-hashed after the run (hidden build-aside folders of other sessions left out) |

## Fixes made during the rehearsal (EQ-A-0138)

- **Wrong folder** (`pullpack.data_folder_problem`). The pull pack, the landing check and the Mac-pass landing now
  name the `~/Downloads` release copy. Before, the pull pack and landing check said only "no countries.csv", and the
  Mac-pass landing crashed with a traceback when `--root` had no data/.
- **Damaged pack files.** A damaged state.json is now a plain refusal in the pull pack; it used to be a traceback. In
  the landing check, a step id that is not text or a status that is a list used to crash; it is now read as
  "damaged". In the Mac-pass landing, `steps`, `summary` or `vintages` of the wrong type used to give a traceback;
  they are now a plain LandingError. Both CLIs now print any unexpected error as one line.
- **Interrupted landing.** `macpass_landing.swap_in` renames the old `data/mvp` back if the second rename fails or is
  interrupted. `recover_interrupted_swap` restores it at the next landing after a hard kill. Before, data/ could be
  left without an mvp.
- **Interrupted apply.** `feeds._write_both_or_neither`: if an apply stops between indicators.csv and countries.csv,
  both files are restored from the pre-apply snapshot. Before, the pair was left half-applied.
- **Interrupted pull.** `pullpack main` turns Ctrl-C into exit 130 with a resume line instead of a traceback.
- **Held step that built nothing.** The landing check now reports it as "not landed" with the Mac's reason. Before,
  it failed the check. An example is fx_history held with 6 open EQ-A-0077 holds in pull-20261025T121034Z.
- **AGENT-09 review (SEC-A-016):** `stage_data` refuses a source data folder holding a symbolic link and never
  chmods or tampers through a link (R-L1); `recover_interrupted_swap` never renames a symlinked `.mvp-old-*` into
  data/mvp; the Mac-pass landing's last-resort message now says when data/mvp had already been replaced before the
  error, instead of claiming nothing changed.
- **SEC-A-009 L5** (asked by AGENT-09). In report.md and landing_report.md, free text is now made inert with
  `pullpack.md_text`: `& < > \` | [ ]` become HTML entities and whitespace collapses. Landing table cells still
  turn `|` into `/`.
- **GDELT categories on** (AGENT-08, for A-0139). The pull pack (step 5b) and incremental runs pass
  `categories=True`, so new GDELT vintages carry `cat_<category>` counts. An explicit `adapter_kwargs` still wins.

## Upgrade from 0.5.0 (what Sam's Mac runs) and 0.4.2

Both zips arrived at 18:49Z (sha256 verified against their .sha256 files: 0.4.2 551abb68...bb22, 0.5.0 92151a5a...8516).
They ship the seed as `data/`, before release-data/ (0.6.0). Installed from Downloads and then upgraded, both pass:

- **Backup:** all 92 (0.4.2) and 101 (0.5.0) data files are in `~/econquest-backups/<UTC>/data` with the same hashes,
  taken before anything changed.
- **Review ledger:** 0.4.2 and 0.5.0 write ledger rows without the hash chain (EQ-A-0103 came later). The current code
  reads them: `verify_ledger` is ok with 3 legacy unchained rows, `fetch --apply` (`_require_ledger_chain`) is not
  blocked, and the next decision anchors the legacy rows.
- **Held cells:** 26 before (0.5.0 code) and 26 after (current code), so the upgrade releases none. The four-eyes
  release recorded with 0.5.0 still releases its cell under the current rules.
- **Model configuration:** 3 files are updated by design (assumptions, limits, scenarios, rulebook, playbook and
  approvals follow the release; the old copies are in the backup).
- **data/mvp:** none before (0.4.2 and 0.5.0 have no MVP dataset); the upgrade adds the release's.
- **Current code on the upgraded 0.5.0 data** (checked by hand on the U2 home): both vintages verify,
  `load_universe` loads, `mvp_dataset.verify` is ok, `pullpack status` works and `apply_vintage` applies. The apply
  prints the loud SEC-A-006 M1 warning: the 0.5.0 data carries 5 Country Profile fx3m cells from Yahoo (Belize,
  Colombia, Malaysia, Pakistan, Senegal), the restricted cells Sam reported on 0.5.0. They stay until the official FX
  pull on the Mac replaces them (`econquest fetch --only fx --apply`, docs/runbooks/A-official-fx.md). This is known
  and loud, not a break.
- **0.6.0 shipped no `live/review.csv`:** the upgrade adds the release's, so 31 cells become held from it (U3 says
  so). Nothing is released.

No 0.4.2- or 0.5.0-specific breakage was found in Team A code or in the installer. The only fix it needed was in the
rehearsal itself (0.6.0's missing review.csv).

## rsync and same-size program files (EQ-C-0168)

On a Mac, install.sh copies the program with rsync. Plain `rsync -a` skips a file whose size and mtime match, and every
zip entry carries the same mtime, so an upgrade could keep an old program file that happens to be the same size as the
new one. Team C added `--checksum` (EQ-C-0168). The Uc rows check the result, and
`tests/test_rehearsal.py::test_code_row_catches_a_same_size_file_rsync_skipped` proves the row catches the old bug: with
a copy of install.sh using plain `rsync -a` and a changed file of the same size and mtime, the row FAILs
(`4/5 release program files match, copied with rsync WITHOUT --checksum; DIFFER: econquest/mod.py`); with
`--checksum` it matches (5/5).

Run on 2026-10-26 19:07Z with rsync 3.2.7 installed for the session (the cloud container has none by default; on a
container without rsync the rows say "tar"): all seven upgrades took the rsync path with `--checksum`, and 1720/1720
program files match the release each time. Left in place, as information: `xxe.xlsx` at the install root from 0.5.0 (a
file 0.5.0 shipped by mistake), and one `release-data/live/snapshots/.../countries.csv` from 0.7.0.

The shipped 0.10.0 zip's install.sh (`econquest-macos.zip`) still uses plain `rsync -a`; the fix ships in the next
release built from this tree.

## Known limits and follow-ups

- **data/mvp on upgrade:** Team C decided (EQ-C-0168) that an upgrade refreshes data/mvp from release-data/mvp after
  the backup and says so in one line. The current tree's install.sh already does this (U4-U6 "refreshed"). The
  rehearsal also accepts the older behaviour (data/mvp kept, newer files added), so shipped installers pass too.
- **CLI wrappers (Team C, HO-20261026-A-C-016):** `econquest mac-pull run` re-raises Ctrl-C from `cli.main`, so Sam
  sees a traceback although state.json is saved. `econquest mac-pull` says "no countries.csv" in the Downloads copy;
  it should use `pullpack.data_folder_problem`.
- The recorded pulls are real uploads with recorded values. The synthetic fixtures change only the pack metadata
  (version, generated time, vintage id) and the review decisions in the upgrade homes, and are labelled SYNTHETIC.

## If a row is BAD

1. Rerun with `--keep` and read the row's files under the printed temporary folder (`landing/`, `macpass/`,
   `synthetic/`, `homes/<version>/`).
2. A `TRACEBACK` row is a defect in the landing kit. Open a Team A ticket, then add the case to
   `tests/test_rehearsal.py`.
3. A `STATE CHANGED` row is a safety defect. Stop the real-data day and tell AGENT-08.
4. Z1 `CHANGED` means something wrote to `data/` while the rehearsal ran, possibly another session. Check
   `python team/teamctl.py tail -n 30` before suspecting the rehearsal.
