# Runbook: monthly data quality report

Ticket EQ-A-0065. Owner: Team A (AGENT-04 built it; AGENT-08 reads it each month). Written 2026-10-24 from
`econquest/ingestion/dq_report.py`. Schedule: Team C (`econquest/ops/schedule.py`, requested in the EQ-A-0065
handoff to C/AGENT-01).

## What it is

One report per calendar month on the quality of the data we pulled: gate holds and their releases, staleness against
the freshness SLA, incidents, the feed-eligible coverage trend and the attestation of hand-entered cells. It is
offline and read-only: it reads records that already exist and writes only `dq_report.md` and `dq_report.json`.
Any input that does not exist is reported as **no record**, never as zero.

## Run it

```bash
python -m econquest.ingestion.dq_report build                      # the month before today (America/New_York)
python -m econquest.ingestion.dq_report build --month 2026-10      # a given month
python -m econquest.ingestion.dq_report build --as-of 2026-11-01   # the month before a run date (the schedule)
python -m econquest.ingestion.dq_report build --data data --out /some/dir --json
```

Output: `outputs/dq/<YYYY-MM>/dq_report.md` and `dq_report.json` (default folder is `<data>/../outputs/dq/<month>`).
`--out` inside the data folder is refused. Re-running replaces the two files (atomic write). About 2 s on the
current data.

Exit codes: **0** no finding, **2** findings, **1** error (bad arguments, no data folder, or a section could not be
read, e.g. a corrupt `state.json`; the report is still written and names the section under "Errors").

## What each section reads

The month window is `[YYYY-MM-01 00:00Z, first of next month 00:00Z)` in UTC.

| Section | Source | Notes |
|---|---|---|
| Gate holds | `data/live/vintages/*/review.csv` (status `hold`) of vintages retrieved in the month | Counts by indicator, country and reason category (the text before `:` in each `;` part, so a cell with "range ...; change ..." counts under both). "New" = not held in the vintage before. |
| Releases | `data/live/review_ledger.csv` | Approved `apply` rows (four-eyes or flagged self-approval) written in the month on a gate-held cell; attestation rows excluded. Time to release = release time minus the retrieval of the first vintage of the hold's unbroken run. |
| Analyst holds | ledger `hold` / `reject` rows written in the month | |
| Outstanding at month end | last vintage of the month + `ledger.effective_holds` with the ledger as of month end | |
| Staleness | `freshness.check_freshness` on the last vintage by month end, as of the month's last day | New / cleared against the same check at the previous month end. No record when no vintage existed then. |
| Feed failures | `feeds.json` of the month's vintages; `data/live/feed_failures.csv` when `data/live/feeds.json` was retrieved in the month | Deduplicated by (pull date, feed, text). |
| Restricted-source cells | `audit.restricted_source_cells` | **Current** applied values at build time, not month end. A finding. |
| Client-output restricted | `audit.client_restricted_cells` | Licence status (IMF internal-research data): informational, not a finding. |
| Pull pack failures | `data/live/pullpack/state.json`, steps `failed` with `finished_utc` in the month | `state.json` keeps only the latest record per step: an earlier failure overwritten by a rerun is not seen. |
| Event mapping-QA | `data/live/events/<source>/incremental_log.csv`, `qa_breach` true, `run_utc` in the month | |
| Nowcast merge stops | pull pack step `nowcast` failed with `MergeStopped` | `nowcast_feed` keeps no record of its own; a stop from a direct `nowcast_feed fetch` outside the pack is not seen. |
| Coverage trend | each vintage's `live_inputs.csv` and `review.csv` over the trailing 12 months (`--trend-months`) | EQ-A-0055 metric: live (finite, not held) cells among `universe.feed_eligible_ids` / feed-eligible cells; desk total and per country; target 60%. Same counting as `universe.missing_cell_report` (tested). |
| Attestation | `ledger.attestation_status` | Current content of `adjustments.csv`, `cds_quotes.csv`, `prediction_markets.csv`. |

## What counts as a finding (exit 2)

- no vintage retrieved in the month: "no pull this month" (a missed pull; AGENT-08 2026-10-24);
- any freshness SLA breach at month end;
- any incident: feed failure, restricted-source cell, pull pack step failure, mapping-QA breach, nowcast merge stop;
- desk feed-eligible live share below 60% on the last vintage of the month.

Informational only: gate holds (the gate working as designed), unattested cells (whether to block on them is Sam's
policy decision), client-output restricted cells. Other "no record" sections are not findings; the headline lists
them.

## Reading the report (AGENT-08, monthly)

1. Exit code and the Findings list at the top.
2. "No pull this month" finding: no pull ran; check the Mac pull schedule
   (`docs/runbooks/A-mac-pull-pack.md`) before anything else.
3. Staleness new breaches: route the series to the feed owner; cleared ones close any open item.
4. Releases with a long time to release or many self-approvals: raise in the review with Sam.
5. Coverage trend: compare with the A6 target; per-country table names who is below 60%.
6. File the month's `dq_report.md` link in the Team A log:
   `python team/teamctl.py log dq_report "<month>: exit N, ..." --team A --agent AGENT-08 --ref outputs/dq/<month>/dq_report.md`.

## If it fails

- Exit 1 with "data folder ... not found": wrong `--data`.
- Exit 1 with a section error: the named file is unreadable (corrupt JSON, missing columns). Fix or restore that file
  (`docs/runbooks/A-restore.md`); the rest of the report is still in the output.
- Coverage "no record" with a coverage map message: `data/panel/coverage_source_map.csv` is missing or
  `data/indicators.csv` is missing.

## Known limits

- Restricted-cell audits and attestation are of the data as it is when the report is built, so a past month rebuilt
  later shows today's status.
- Pull pack and nowcast merge stops are only as complete as `state.json` (latest record per step).
- The current `data/live/live_inputs.csv` is not a vintage and is not used for the trend: it was rewritten (2026-10-23 09:03,
  file time) after the 2026-10-23 vintage was saved (04:31), so `universe missing` on `data/` (24.9%) and this report (19.1%) differ.
