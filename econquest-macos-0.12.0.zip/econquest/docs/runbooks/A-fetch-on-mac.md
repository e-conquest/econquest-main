# Runbook: live input fetch on Sam's Mac (`fetch`, review, `fetch --apply`, `audit`)

Ticket EQ-A-0009. Owner: Team A, AGENT-06. Operator: Sam. Written 2026-10-23 from `econquest/cli.py`
(`cmd_fetch`, `cmd_audit`) and `econquest/ingestion/feeds.py`.

## Purpose

Replace seed inputs with IMF WEO, World Bank and BIS values and the official FX reference rates (BIS WS_XRU,
ECB EXR). Values that fail the quality gate stay on seed until a reviewed decision says otherwise. Every pull is
kept as a vintage. Yahoo Finance is no longer a feed (EQ-A-0040, Sam 2026-10-23): see `A-official-fx.md`.

## When

- Weekly, and after each WEO release (April and October).
- Before any `publish` that should carry new inputs.

The cloud sessions cannot reach these APIs, so the fetch always runs on the Mac.

## Prerequisites

- econquest at `/Users/smc/econquest`, installed from `econquest-macos.zip`, with `econquest` on PATH.
- Network access to the IMF (`api.imf.org`, `www.imf.org`), `api.worldbank.org`, `stats.bis.org` and
  `data-api.ecb.europa.eu`. These are the hosts fetch probes (`feeds.FEED_HOSTS`, EQ-A-0037). The Yahoo hosts are
  no longer needed (EQ-A-0040).
- For the national nowcast sources (EQ-A-0119, `nowcast_feed fetch --sources bcb_sgs,bcrp,datos_ar,dosm`, runbook
  `A-nowcast-feed.md` "National sources"), the Mac also needs `api.bcb.gov.br` (BCB SGS), `estadisticas.bcrp.gob.pe`
  (BCRPData), `apis.datos.gob.ar` (datos.gob.ar series API) and `api.data.gov.my` (OpenDOSM). The fetch probes each
  host first and skips a source whose host does not answer.
- **Back up `data/` first.** Reinstalling from a new zip copies the zip's `data/` over yours (see
  `A-restore.md`).

From EQ-A-0005/0006 (landing now; check that your installed zip has them):

- Vintage folders are append-only: `data/live/vintages/<YYYY-MM-DD>T<HHMMSS>Z-<hash8>/`, read-only, listed
  in `data/live/vintages/index.csv`.
- Before each apply, a copy of `indicators.csv` and `countries.csv` is saved in
  `data/live/snapshots/<ts>-pre-apply/`.
- Decisions on held cells live in the append-only `data/live/review_ledger.csv`.

On an older install, a second fetch on the same day **overwrites** that day's vintage (gap finding F1), and
`review.csv` loses your decisions on every fetch (F2).

## Steps

```bash
cd ~/econquest
mkdir -p ~/econquest-backup && cp -Rp data ~/econquest-backup/data-$(date +%Y%m%d-%H%M)     # 1. backup (about 15 MB)
econquest fetch 2>&1 | tee outputs/fetch-$(date +%Y%m%d-%H%M).log   # 2. pull, gate, vintage; nothing applied
```

3. **Review the gate output.** The fetch log ends with
   `Quality gate: N ok, H held for review, M missing`, followed by the held rows. Open
   `data/live/review.csv` and filter `status = hold`. The `reason` column says why each cell was held:
   `range`, `change` (more than `--max-change` of seed, default 0.5) or `stale` (World Bank series more than
   3 years old; BIS series whose last observation is older than 30 days for the daily policy rate, 92 days
   for the monthly REER, 275 days for the quarterly credit gap). Default: leave held cells on seed.

   To apply a held cell, approve it **against the vintage you reviewed** (EQ-A-0035). The decision stores
   that vintage id and the cell's live value from the vintage's `review.csv`, and the apply below re-applies
   that same saved vintage offline. It does not pull again, so the value you approved is the value written.
   The four-eyes rule applies: the approver must be someone other than the author. In single-operator mode,
   `self_approved=True` records `self_approved=yes` in the ledger as a governance exception.

   Use `econquest review` (Team C, HO-20261023-A-C-016; `econquest review --help`). The earlier
   `python -c` calls into `feeds` are retired: the commands below run the same functions with the same checks.
   ```bash
   # the held cells of the latest vintage and what an apply would do now (effective column)
   econquest review list --pending --vintage <id from ls data/live/vintages>
   # approve the four FX moves in one go (four-eyes: replace --self-approved with --approver <second person>)
   econquest review approve "Country Profile" fx3m Brazil "Country Profile" fx3m Colombia \
       "Country Profile" fx3m Pakistan "Country Profile" fx3m Nigeria --author smc --self-approved --note "real 3m FX move, checked"
   ```
   The whole batch is checked first (vintage hash, every cell in the vintage's review, four-eyes), so a
   refusal writes nothing. `review approve` binds to the latest vintage; add `--vintage <id>` for another one.
   To keep a cell off, even one the gate passed, add `--decision hold` or `--decision reject`; no approver is
   needed for that.

4. **Apply the reviewed vintage (offline, no refetch):**
   ```bash
   econquest review apply --dry-run          # what would be applied, released and still held; writes nothing
   econquest review apply 2>&1 | tee outputs/apply-vintage-$(date +%Y%m%d-%H%M).log
   ```
   This verifies the vintage against `data/live/vintages/index.csv` and refuses a changed folder. Every index
   row for the vintage must agree, and the `<hash8>` at the end of the folder name must match the content
   (SEC-A-004 L1). It then applies the gate's ok cells plus the held cells approved for this vintage or live
   value. It keeps the same pre-apply snapshot and inputs snapshot as `fetch --apply`. In the output, check
   `released` (the cells you approved) and `still_held` (everything else the gate held, still on seed).

   **Older vintages (`allow_older`).** Applying a vintage that is not the latest puts its ok cells back over
   newer values, which is a rollback. It is refused unless you ask for it (SEC-A-004 L2):
   `econquest review apply --vintage <older id> --allow-older` (in Python, `feeds.apply_vintage(...,
   allow_older=True)`). Without the flag nothing is recorded or applied. With it, the rollback is recorded in
   `rollback.json` in that apply's pre-apply snapshot folder (`data/live/snapshots/<ts>-pre-apply/`) and in
   the result's `rollback` entry, which gives the vintage applied, the latest vintage, the author and the time.
   To undo a rollback, apply the latest vintage again. Until Team C wires the flag through
   (HO-20261024-A-C-003), `review apply --allow-older` stops with "is not the latest". Use `--dry-run` to look
   at an older vintage. Do not run `fetch --apply` to release held cells: it pulls again, and a decision on
   the old vintage or value no longer binds to the new pull.

   Never use `--force` without a ledger decision for each cell. It applies every held value.

5. **Audit:**
   ```bash
   econquest audit
   ```
   This writes `data/audit_trail.csv` and prints the origin summary. If a Sheets token is in the Keychain
   or in `$ECONQUEST_SHEETS_TOKEN`, it also writes the Audit Trail tab.

6. **Check the run:**
   ```bash
   econquest run
   econquest runs --limit 2
   ```
   `data_hash` should differ from the previous run.

## Verification

- The log line `Feeds: weo: ok (...); worldbank: ok (...); bis: ok (...); bis_xru: ok (...); ecb_exr: ok (...)`
  shows every feed as ok. On the first pull after EQ-A-0040, work through the checks in `A-official-fx.md`
  before applying: the BIS and ECB series keys were written from documentation and are unverified.
- The log line `Applied: {'indicator_cells': ..., 'profile_cells': ..., 'held_for_review': H, ...}` shows H equal
  to the held count you reviewed minus the cells you approved; those are listed under `released`.
- `ls data/live/vintages` shows a new folder. On new code, `tail -2 data/live/vintages/index.csv` also
  shows the new row, and `ls data/live/snapshots` shows a new `-pre-apply` folder.
- In the `econquest audit` summary, the live-feed counts went up or stayed level and none moved to "seed
  because the feed returned nothing" unexpectedly.

- EQ-A-0028: the `Feeds:` line also shows `bis_cbs: ok (...)` and `worldbank_history: ok (...)`, and
  `data/live/raw_bis_cbs.csv` and `data/live/raw_worldbank_history.csv` exist (also in the new vintage folder).
  First pull only: check that `raw_bis_cbs.csv` has rows and `basis` is `U`. If `bis_cbs` failed with
  `no claims on basis U`, the ultimate-risk code is wrong: open
  `https://stats.bis.org/api/v1/data/WS_CBS_PUB/Q.S.5A...C.A.A.TO1.A.BR/all?format=csv&lastNObservations=1` in a browser, note the
  `CBS_BASIS` and `CBS_BANK_TYPE` codes of the ultimate-risk foreign-claims series, and send them to Team A
  (`feeds.CBS_BASIS_ULTIMATE_RISK`, `CBS_BANK_TYPE_ULTIMATE_RISK`). Do not edit the file by hand.
  Debtors BIS does not report are listed in `data/live/unserved.csv` (table `BIS CBS`).

## Failure handling

| Symptom | Action |
|---|---|
| One feed `failed: ...` | The other feeds still run, and apply uses only the feeds that succeeded. Rerun later with `--only <feed>`, for example `econquest fetch --only bis --apply`. The full list of what went wrong per feed is in `data/live/feed_failures.csv` |
| `[fetch] <feed>: unreachable (proxy refused CONNECT to <host>): skipped` | Before each feed, fetch sends one short probe (4 s timeout) to each of the feed's hosts. None answered, so the feed was skipped without a single data request. Other feeds still run. `proxy refused CONNECT`: the proxy or VPN blocks that host (check the proxy allow-list, or turn the VPN off). `DNS lookup failed`: no network or DNS. `no answer from <host> within 4 s`: network down or very slow. Fix the network, then `econquest fetch --only <feed>` |
| `[fetch] <feed>: unreachable (...): stopped at the first refused request` | The probe passed but a data request was then refused by the proxy (or its DNS failed). The feed stopped at once rather than retrying each country or series. Same action as above |
| `[fetch] weo: ok (...) from the cached download (...)` | The IMF hosts are unreachable, so WEO was read from the `weo` package's saved download in `outputs/cache/weo_<year>_<Oct\|Apr>.csv` (the same release as a live pull would use when that file exists). Values are real IMF numbers, not refreshed |
| `[fetch] <feed>: failed: package <name> is not installed` | Reinstall from the zip (`install.sh`), which installs `imf-reader`, `weo` and `wbgapi` (the FX feeds use the SDMX APIs directly, no package) |
| `Nothing applied: no feed succeeded (...). Nothing written to .../data/live; no vintage saved.` (exit status 1) | Every feed failed or was unreachable, typically no network. With or without `--apply`, nothing in `data/` changed: no `data/live` file, no `review.csv`, no vintage. On a blocked network this takes a few seconds (it used to run for more than 400 s). Check the VPN or proxy and retry |
| Many unexpected holds | Do not use `--force`. Upload the log and `data/live/review.csv` to the project for Team A |
| Applied values look wrong | Restore from `data/live/snapshots/<ts>-pre-apply/` or your backup (`A-restore.md`) |
| `FileExistsError` on a vintage | Two pulls in the same second. Rerun |
| `VintageIntegrityError: vintage ... failed verification` on approve or apply | The vintage folder no longer matches `vintages/index.csv`. Nothing was written. Do not edit vintage files. Upload the folder and `index.csv` for Team A, and run `econquest fetch` for a new vintage |
| `VintageContentError: vintage ... has no review.csv` | The vintage predates the gate review (legacy folder). Run `econquest fetch` and review the new vintage |
| `VintageContentError: not in the review of vintage ...` | Typo in table, key or country (`Country Profile`, `fx3m`, `Brazil`), or the cell was not live in that vintage. Nothing was recorded |

## Upload

```bash
cd ~/econquest && zip -r ~/Desktop/econquest-data-$(date +%Y%m%d).zip data/live data/indicators.csv data/countries.csv data/audit_trail.csv outputs/fetch-*.log
```

Upload the zip to the Claude project files (`econquest/data/...`). Then publish (`A-publish.md`).

## Owner

Runbook: Team A, AGENT-06. Running and decisions: Sam. The second approver for held cells is still to be
named (roadmap 4.4).

## EQ-A-0040: official FX, and `equity_vol` left unserved

Since 2026-10-24 `fx3m` comes from BIS `WS_XRU`, or from the ECB `EXR` reference rates through the same
date's EUR/USD when BIS has no series for the currency; `data/live/raw_bis_xru.csv` and
`data/live/raw_ecb_exr.csv` hold the raw pulls. The Country Profile `equity_vol` has **no official free
source** and is left blank for every country with that reason in `data/live/unserved.csv` and in the gate
review. Nothing in the engine loses an input (`data/market_history/prices.csv` comes from the workbook's
GOOGLEFINANCE Market History tab, not Yahoo). Sam's options for `equity_vol` are in
`docs/runbooks/A-official-fx.md`.

## IMF/OECD/Eurostat (EQ-A-0049): verify the new official series on the Mac

The IMF SDMX feed runs in every default `econquest fetch` (Sam 2026-10-24 12:38Z: IMF data is for internal research
use only, never client output). Every dataflow, dimension and code it uses is **unverified**, so the gate holds every
cell it fills until you have checked the series as below and `data/panel/coverage_source_map.csv` says
`verified=yes` for the indicator. OECD and Eurostat are named feeds only, with no series configured yet.

1. Pull the IMF feed and the World Bank additions alone, into the staged folder or `data`:
   ```bash
   cd ~/econquest && source .venv/bin/activate
   python -m econquest --data data fetch --only imf,worldbank 2>&1 | tee outputs/fetch-imf-$(date +%Y%m%d).log
   ```
   Expect `[fetch] imf_sdmx: ok (N rows)` or one line saying why not (unreachable, redirect, or failed with the
   first errors). `data/live/feed_failures.csv` lists each refused answer (`unexpected <DIM>=...`, `dimension
   column(s) ... missing`) and the series not configured.
2. Look at what came back before trusting it:
   ```bash
   python -c "import pandas as pd; r=pd.read_csv('data/live/raw_imf_sdmx.csv'); print(r.groupby('series').agg(n=('value','size'), countries=('iso','nunique'), last=('period','max'), key=('sdmx_key','first')))"
   ```
   For each series check, against the IMF data portal page of that dataset, that the dataflow and codes in
   `sdmx_key` mean what `official/imf.py` IMF_SPECS says (for example CPI all items index; official reserve assets in
   US$), and spot-check two countries' latest values against the portal.
3. Find the codes that are not configured yet (deposits, claims on government, total assets, FSI FX ratios, IRFCL
   drains, IIP portfolio debt). These commands save the dataflow structure with its codelists, then fetch one series
   for one country:
   ```bash
   python -m econquest.ingestion.official.imf structure MFS_ODC --out outputs/imf_structure
   python -m econquest.ingestion.official.imf sample CPI --iso BRA --filter INDEX_TYPE=CPI --filter COICOP_1999=_T --filter TYPE_OF_TRANSFORMATION=IX --filter FREQUENCY=M
   ```
   If the structure call fails with HTTP 404 or a redirect, the base URL or path in `IMF_BASE` is wrong: upload the
   log, do not edit the code yourself.
4. Upload `outputs/fetch-imf-*.log`, `data/live/raw_imf_sdmx.csv`, `data/live/feed_failures.csv` and
   `outputs/imf_structure/` to the project. Team A (AGENT-06) then sets the confirmed codes in `IMF_SPECS` and
   `verified=yes` in the coverage map for each indicator whose series it confirmed. The held cells are then released
   on the next fetch, or by a review decision for the current vintage.
5. World Bank additions (2.11, 7.10, 2.2): check in `data/live/raw_worldbank.csv` that TX.VAL.*.ZS.UN,
   DT.DOD.DSTC.CD, DT.AMT.DPPG.CD and DT.AMT.PNGB.CD came back (`feed_failures.csv` names any code that did not).
6. OECD and Eurostat are not configured yet. `python -m econquest --data data fetch --only oecd,eurostat` only
   reports "not configured". They are configured the same way once their dataset ids are known.
7. Check which applied cells must stay out of client output (IMF and WEO values):
   ```bash
   python -m econquest.ingestion.audit client --data data
   ```
