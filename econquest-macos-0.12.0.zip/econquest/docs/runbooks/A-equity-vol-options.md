# Spike: Country Profile `equity_vol` without Yahoo

Ticket EQ-A-0051 (spike). Author: Team A, AGENT-03. Date: 2026-10-24. Documentation research and a read of
the repository only: no source, test or data file was changed and no market data was pulled. The cloud cannot
reach most data APIs, so every claim about a source comes from a public documentation page read for this spike
(listed at the end). Anything marked **UNVERIFIED** was not confirmed on a page read here. No volatility number is
given anywhere in this document.

## 1. What the series was, and who would use it

- **Definition** (`econquest/ingestion/feeds.py` `yahoo_transforms`): annualised standard deviation of the
  country ETF's daily log returns over the last 60 trading days, x sqrt(252) x 100. In USD, so it mixes local
  equity risk and FX risk.
- **Today** (EQ-A-0040): unserved for every country with the reason `feeds.NO_OFFICIAL_SOURCE`
  = "no official free source (Yahoo removed, Sam 2026-10-23)", plus the ETF ticker where one exists.
- **Coverage under Yahoo**: 10 of 18 (`docs/validation/data-limitations.md` row `equity_vol`): the 10 desk
  countries with an `etf` in `data/countries.csv`, which are also exactly the 10 with `Equity = Yes`:
  Vietnam (VNM), Philippines (EPHE), China (MCHI), Malaysia (EWM), Singapore (EWS), Japan (EWJ), South Korea
  (EWY), India (INDA), Brazil (EWZ), Argentina (ARGT). The other 8 (Pakistan, Belize, Colombia, Venezuela,
  Nigeria, Senegal, Zambia, Zimbabwe) have no ETF and no equity product on the desk; they were blank under Yahoo
  too. So "full coverage" for this series means **10 countries**, not 18.
- **Readers.** No engine input. `grep equity_vol econquest/engine econquest/presentation` finds only the governed
  assumption `market.equity_vol` (`data/assumptions.json`, 25.0; `engine/layer6_montecarlo.py`, `engine/stress.py`),
  which is a different number. Team B confirmed the Country Profile series is not read (EQ-B-0064, Done). Its
  only consumers are the dashboard Country Profile, `ingestion/audit.py` and `ingestion/limitations.py`
  (documentation strings). It was never written to `data/countries.csv` (`PROFILE_APPLY_KEYS` excludes it).
- **What reads the same ETFs.** The ETF columns of `data/market_history/prices.csv` (GOOGLEFINANCE, see option c)
  feed `engine/garch.py` (`mc_vols`, GARCH/DCC Equity block, which the Monte Carlo uses when
  `monte_carlo.garch_vol` is on), `engine/layer5_copula.py` (estimated copula), `engine/regime_hmm.py` (HMM
  features), `engine/econometrics.py` (event study, Kalman, Fama-MacBeth) and `presentation/garch_publish.py` /
  `econ_publish.py`. `scorecard/readiness.py` says a blank `etf` drops the country from those fits. Those engine
  models are the real users of equity volatility; the Country Profile figure is a display.

Observed in `prices.csv` (count only): each of the 10 ETFs has 756-757 daily closes from 2023-10-18/19 to
2026-10-23. It also holds **GXG** (a Colombia ETF, 760 closes to 2026-10-22) although Colombia's `etf` is blank
in `countries.csv` (UNVERIFIED whether that is deliberate).

## 2. Options

### (a) Realised vol from official equity index levels

**FRED.** Two kinds of international equity series were found:

- `NIKKEI225` (Japan only): daily close, latest observation 2026-10-23. Notes: "Copyright, 2016, Nikkei Inc.
  Reprinted with permission"; downloading "for research reports or research projects is permitted"; other uses
  need Nikkei's permission. FRED's legal page: for third-party copyrighted series "you must contact the data owner
  to obtain permission" beyond personal use, and FRED Services may not be used "for any commercial use without the
  prior written consent of the Bank". Not usable for a desk number without a Nikkei licence.
- OECD Main Economic Indicators share price indices, monthly (`SPASTT01<CC>M661N`, index 2015=100, and growth-rate
  variants). Pages found for **Japan, South Korea, India, Brazil, China, Colombia**. Korea's page: monthly, Jan 1981
  to Aug 2026; India growth series to Jun 2026. FRED marks them "Data in this graph are copyrighted". No other
  daily non-US index was found on FRED (**UNVERIFIED** that none exists).

**OECD direct** (data-explorer.oecd.org, same MEI series): OECD terms section I(e) allow use "for any purpose"
with attribution, but "Data may be subject to restrictions beyond the scope of these Terms", and the OECD does
not warrant it holds all rights. Pulling from OECD rather than FRED avoids FRED's commercial-use clause.
**UNVERIFIED:** whether the MEI value is a monthly average or month-end close, the underlying index for each
country, and whether the index owners restrict reuse.

**Central-bank statistical releases** (candidates, none confirmed as a daily machine-readable series):
State Bank of Pakistan publishes KSE-100 and All Shares Index tables in its statistical bulletin (Capital Market
chapter); the RBI publishes "Trends in domestic stock indices" in its annual report appendix; Banco Central do
Brasil SGS and Bank of Korea ECOS are candidates for Ibovespa and KOSPI. **UNVERIFIED:** daily frequency, series
codes, and reuse terms for all four. The index values themselves belong to the exchange or index provider, so a
central bank republishing them does not by itself clear the licence.

**Exchange-published index data.** Exchanges license index values for use in calculations. Example read for this
spike: NSE (India) Non-Display Policy counts indices and end-of-day data as market data, and any automated use
"for internal analysis", risk management or valuation needs an agreement with NSE Data & Analytics and a fee. Other
exchanges were not checked (**UNVERIFIED**, but the same model is common).

Model point: an official local-currency index is not the USD ETF the desk holds; its vol excludes the FX
component, and monthly data gives a vol over years, not 60 days. It would be a new series with a new definition.

### (b) Proxy from sovereign spread vol or official FX vol

- **Spread vol: 0 of 18.** `spread` in `countries.csv` is one hand-entered number per country with no history;
  `data/cds_quotes.csv` is header-only; CDS/EMBI have no free source (`A-market-data.md`). There is no series to
  take a vol of.
- **FX vol from BIS WS_XRU**: a daily series is planned for 17 of 18 (not Zimbabwe, `feeds.NO_FX_QUOTE`); the key
  is **UNVERIFIED** until the first Mac pull (`A-official-fx.md`). Of the 10 equity countries, Argentina's USDARS is
  on the administered list (`engine/garch.py` `ADMINISTERED`), leaving 9 with a market FX rate. Licence: BIS terms
  (as for the FX feed). Model risk: **high**. FX vol is not equity vol; a mapping (ratio or regression) would have to
  be fitted on equity data we are not allowed to use, and it would be an estimate presented in a column whose
  definition says "realised vol of the ETF". `A-official-fx.md` states this series "is **not** estimated,
  substituted or carried over"; this option reverses that.

### (c) GOOGLEFINANCE through the workbook

Coverage: the same 10 ETFs, already in `prices.csv` daily from 2023-10-18 (counts above). Effort: small; no new
fetch, only computing the 60-day figure from `prices.csv` and serving it with a GOOGLEFINANCE provenance.
Google's help page for the function (support.google.com/docs/answer/3093281) says:

- "Information is provided 'as is' and solely for informational purposes, not for trading purposes or advice."
- "The data is not for financial industry professional use or use by other professionals at non-financial firms";
  "Professional use may be subject to additional licensing fees from a third-party data provider."
- "Historical data cannot be downloaded or accessed via the Sheets API or Apps Script."

These are at least as restrictive as the Yahoo terms Sam rejected on 2026-10-23. The last point matters beyond
this ticket: `econquest prices --sheet-json` takes a Sheets API `values.get` result for 'Market History'
(`cli.py`, `ingestion/market_history.py`, scheduled in `ops/schedule.py`), which is the access route the page says
is not provided for historical data. **UNVERIFIED:** how the workbook values reached the JSON (pasted values or the
API) and whether Google's page is a contractual term or a technical note. Either way, the licence question already
open for `prices.csv` decides this option too.

### (d) Licensed, through the EQ-A-0033 Bloomberg/LSEG framework

Coverage: expected 10 of 10 ETFs and local indices for most of the 18 (Pakistan KSE-100, Colombia, Nigeria,
Zambia, Zimbabwe exchanges are **UNVERIFIED** on a terminal). Daily. Terms: the desk's vendor contract
(`A-licensed-vendors.md`, entitlement `scope=desk-internal`); cost unknown. Effort: medium. The framework has no
equity instrument today (`market/schema.py` `INSTRUMENTS` = cds, govt_yield, embi_spread, fx_spot, fx_forward,
policy_rate, ois, swap), so it needs a schema extension, ticker-map rows and gate rules, and it runs only after Sam
buys a licence. Bloomberg/LSEG request handling is itself untested against a terminal. Best model fit: the same
ETF closes as before, under a licence that covers desk use.

### (e) Leave it blank

Coverage 0. Nothing in the engine loses an input (EQ-B-0064). The dashboard shows a blank with a reason. No
licence or model risk. Effort: none; already the state since EQ-A-0040.

## 3. Comparison, 18 desk countries

"Equity countries" = the 10 with an ETF and `Equity = Yes`.

| Option | Coverage of the 18 (names) | Frequency | Licence / terms (URL) | Effort | Model risk | Unverified |
|---|---|---|---|---|---|---|
| (a) FRED NIKKEI225 | 1: Japan | Daily | Nikkei copyright; research use only, else Nikkei permission; FRED no commercial use without consent. https://fred.stlouisfed.org/series/nikkei225, https://fred.stlouisfed.org/legal/ | Small | Medium (local index, no FX) | Whether a Nikkei licence is obtainable and its price |
| (a) OECD MEI share prices (via OECD or FRED) | 6: Japan, South Korea, India, Brazil, China, Colombia (5 of the 10 equity countries; Colombia has no equity product) | Monthly | OECD terms I(e): any purpose with attribution, third-party restrictions possible. https://t4.oecd.org/termsandconditions; FRED copy marked copyrighted | Medium | High (monthly, local currency, multi-year window; a different series) | Average vs close; underlying index; owner restrictions; full country list |
| (a) Central-bank releases | Candidates: Pakistan (SBP), India (RBI), Brazil (BCB SGS), South Korea (BoK ECOS) | UNVERIFIED (bulletins seen are monthly/annual) | Per bank; index owner rights apply | Medium-high, per-country mapping | Medium-high | Daily availability, codes, reuse terms for all four |
| (a) Exchange index data | Any of the 18 with a stock exchange (which ones have a usable index: UNVERIFIED) | Daily | Exchange licence and fee for non-display use, e.g. NSE: https://nsearchives.nseindia.com/web/sites/default/files/inline-files/Non_Display_Policy.pdf | High (one contract per exchange) | Medium | Every exchange other than NSE |
| (b) Spread vol | 0 | n/a | n/a | n/a | n/a | n/a (no spread history exists) |
| (b) FX vol (BIS WS_XRU) proxy | 9 of the 10 equity countries (not Argentina, administered); 17 of 18 have an FX series (not Zimbabwe) | Daily | BIS terms (as the FX feed) | Medium (fit and govern a mapping) | High (FX vol is not equity vol; contradicts "not estimated or substituted") | WS_XRU key; how to calibrate without equity data |
| (c) GOOGLEFINANCE workbook | 10: Vietnam, Philippines, China, Malaysia, Singapore, Japan, South Korea, India, Brazil, Argentina (+ GXG for Colombia) | Daily | "not for trading purposes or advice"; "not for financial industry professional use"; no historical data via Sheets API. https://support.google.com/docs/answer/3093281 | Small | Low (same definition as before) | Whether the terms bind; how the history reached the JSON |
| (d) Bloomberg / LSEG (EQ-A-0033) | 10 of 10 equity countries expected; local indices for more | Daily | Desk vendor contract, `desk-internal`. docs/runbooks/A-licensed-vendors.md | Medium (equity instrument, ticker map, gate) after purchase | Low | Price; terminal coverage of frontier exchanges; adapter untested |
| (e) Blank | 0 | n/a | none | None | None | none |

## 4. The 88-country universe (`data/panel/universe_proposal.csv`, not approved)

- Rows with an `etf`: 30 (the 10 desk ETFs, 7 DM anchors: US, Germany, UK, France, Italy, Canada, Australia, and
  13 EM: Indonesia, Thailand, Mexico, Chile, Peru, Turkey, Poland, Saudi Arabia, UAE, Qatar, Kuwait, Israel, South
  Africa). Every ETF ticker there is "from memory, verify". Options (c) and (d) scale to these 30; (c) would
  need 20 new GOOGLEFINANCE blocks, (d) 20 new ticker-map rows.
- (a) OECD MEI: OECD members and some partners; the members among the 88 add the DM anchors and several EM
  (Mexico, Chile, Turkey, Poland, Israel, Colombia). Exact list **UNVERIFIED**. The ECB Data Portal (FM dataset)
  publishes euro-area indices (EURO STOXX), not national ones; relevant only to the euro-area anchors.
- (b) FX vol scales with WS_XRU coverage (not dollarised members, not ZWL); the same model objection applies.
- The 58 rows without an ETF have no equity series under any free option; only (d) could add local indices.

## 5. Recommendation for Sam

Leave `equity_vol` blank (e): no engine reads it, and every free option is either a different series (OECD
monthly, FX-vol proxy) or carries terms at least as restrictive as Yahoo's (GOOGLEFINANCE). If the desk wants the
number back, add it to the Bloomberg/LSEG framework (d) when a licence is bought, and decide the GOOGLEFINANCE
licence for `prices.csv` first, because the same terms cover the engine's GARCH, copula, HMM and econometrics inputs.

## 6. The decision Sam needs to make

**How should the Country Profile `equity_vol` be filled from now on?**

1. **Leave it blank** (recommended): blank with its reason; no work, no licence risk.
2. **Licensed only**: blank until a Bloomberg/LSEG licence exists, then a Team A ticket adds an equity instrument
   to the EQ-A-0033 framework and serves the 10 ETFs.
3. **Official monthly index vol**: a Team A ticket serves a new, differently defined series from OECD MEI share
   prices for 5 of the 10 equity countries (Japan, South Korea, India, Brazil, China); the other 5 stay blank.
4. **GOOGLEFINANCE workbook**: compute it from `prices.csv` for all 10, accepting Google's terms ("not for trading
   purposes", not for professional use), the same call as for `prices.csv` itself.

## Pages read

- FRED, Nikkei 225: https://fred.stlouisfed.org/series/nikkei225
- FRED legal: https://fred.stlouisfed.org/legal/
- FRED, OECD share prices Korea: https://fred.stlouisfed.org/series/SPASTT01KRM661N ; India:
  https://fred.stlouisfed.org/series/SPASTT01INM657N ; search results listing Brazil (SPASTT01BRM661N), China
  (SPASTT01CNM661N), Colombia (COLSPASTT01GPM)
- OECD terms and conditions: https://t4.oecd.org/termsandconditions
- Google Docs Editors Help, GOOGLEFINANCE: https://support.google.com/docs/answer/3093281
- NSE Non-Display Policy: https://nsearchives.nseindia.com/web/sites/default/files/inline-files/Non_Display_Policy.pdf
- Search results only (pages not opened): SBP statistical bulletin Capital Market tables
  (https://www.sbp.org.pk/reports/stat_reviews/Bulletin/2020/Mar/CapitalMarket.docx), RBI annual report appendix
  "Trends in domestic stock indices", ECB Data Portal FM dataset (https://data.ecb.europa.eu/data/datasets/fm/data-information)
