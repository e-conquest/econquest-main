# Runbook: wide hazard predictor panel and missing-predictor map (EQ-A-0140)

AGENT-03 (Team A), 2026-10-26. Feeds Team B's EQ-B-0140 refit rehearsal. Code:
`econquest/ingestion/hazard_panel_wide.py`. Tests: `tests/test_hazard_panel_wide_a140.py` (16).

## What it is

The widest country-year predictor panel that can be built from **shared, recorded, non-WEO data already on disk**,
with the same default label as Team B's refit. A missing-predictor map goes with it, listing for each country-year
which predictors exist, which are missing and which source would fill each gap (WEO gaps are listed separately).
Nothing is fetched and no value is invented. Values are read from recorded files and are only transformed with Team
B's layer-1 transforms or aggregated to calendar years.

The WEO history (2007-2024) is still deferred by Sam (EQ-A-0087). The five WEO columns are present but empty until
it lands. They then fill point in time with no code change, and the refit is one command (see "When WEO lands").

## Build (cloud or Mac, no network, about 5 s)

From the econquest folder: `sources` lists which inputs are on disk (read-only); `build` uses `--as-of 2026-10-23`
by default. (No trailing `#` comments in these blocks: interactive zsh passes them as arguments unless
INTERACTIVE_COMMENTS is set.)

```zsh
python -m econquest.ingestion.hazard_panel_wide sources
python -m econquest.ingestion.hazard_panel_wide build
```

Output: `panel: 5,887 rows, 159 countries, 1980-2024, 166 events, 26 predictors (21 non-WEO), non-WEO cell
coverage 18.1%, WEO not landed`. Exit codes: 0 ok, 2 input error (missing file or licence row), 4 `--refit` without WEO (refit not run).

Files in `data/panel/hazard_panel_wide/`. The whole folder is **internal only**: licence row `hazard_panel_wide`,
client_output restricted. It is kept out of data/mvp by `mvp_dataset.EXCLUDE_DIRS`, and out of release zips by
HO-20261026-A-C-014 to C/AGENT-10. Rebuild it at any time with the command above; it is never hand-edited.

| File | Content |
|---|---|
| `panel.csv` | iso, year, 26 predictors, event, ever_defaulted, n_present: one row per country-year at risk |
| `columns.csv` | per predictor: source file + sha256, series, transform, aggregation, lag, licence rows, client_output, internal_only, point_in_time, weo_fill, fill_group, fill_source, economies, first/last year, rows present, coverage, events covered |
| `missing_map.csv` | per country-year: n_present, n_missing, n_weo_fillable, present, not_applicable, fill_weo, fill_wb_pull, fill_bis_pull, fill_gpr_file, fill_no_source (semicolon lists of predictor names) |
| `manifest.json` | as_of, lag, event rule + raw CRAG hash, counts, events per label year, coverage, input hashes, WEO route, licence, command |

## Inputs and provenance (all recorded, none fetched)

| Source | File | Licence row(s) | Columns |
|---|---|---|---|
| World Bank panel history (Sam's upload, 0.5.0) | `team/inbox/pull-20261025T121034Z/worldbank_history.csv` | worldbank_ids, worldbank_wdi + imf_via_wdi, worldbank_wgi | stfx_debt_reserves, reserves_months_imports, pitf_instability |
| World Bank universe pull (pull pack step 4) | `team/inbox/pull-20261025T013150Z/raw_worldbank.csv` | worldbank_wdi (+ imf_via_wdi for IMF-compiled codes), worldbank_wgi, worldbank_ids | wb_current_account, wb_real_growth, wb_inflation_log, wb_rule_of_law, wb_control_corruption, wb_regulatory_quality, ext_debt_exports, exports_gdp, fuel_exports_share, metals_exports_share, npl_ratio, youth_unemployment |
| BIS, recorded vintage | `data/live/vintages/2026-10-25T170547Z-67dffc57/raw_bis.csv` | bis | bis_credit_gap (Q4 of the year), bis_reer_change (y/y % of the annual mean), bis_policy_rate (annual mean) |
| Caldara-Iacoviello GPR | `data/gpr_monthly.csv` | gpr | gpr_country (annual mean of GPRC_<iso>) |
| BoC-BoE CRAG | `data/panel/sovereign_defaults_crag.csv` (+ raw `staging/crag/DEBT_2026.csv` for the floor) | crag | event, ever_defaulted, crag_prior_spells, crag_years_since_default |
| IMF WEO (not landed) | see "When WEO lands" | imf_weo | debt_gdp, primary_deficit, current_account, real_growth, inflation_log |

Not used, and why:
- `data/panel/hazard_panel.csv` and `data/live/raw_weo.csv` are WEO (latest vintage, 15 to 18 desk economies, not
  point in time).
- Cruces-Trebesch is not dropped (`data/panel/cruces_trebesch_haircuts.csv` is absent, EQ-A-0098).
- The data/live World Bank files only hold a subset of the universe pull's series and economies.
- IDS debt service `DT.TDS.DPPG.CD` is a USD level with no scale series on disk, and runs to 2032 (projections).

Licences: every column maps to register rows (`column_licences`). The build stops when a row is missing.
IMF-compiled WDI codes (`client_safe_route.D3_CODES`: FI.RES.TOTL.MO, BN.CAB.XOKA.GD.ZS, FP.CPI.TOTL.ZG,
FB.AST.NPER.ZS) also carry imf_via_wdi, so they are restricted, and so are the WEO columns. The other columns are
client-allowed on their own rows, but the panel file as a whole stays internal.

## Event definition and count

- **Rule.** crag_v1: BoC-BoE CRAG, FC bank loans + FC bonds + LC debt in default above USD 10m in that year, with a
  2-year cure. The rule is built by Team B's `hazard_events.build_events(data, as_of, resolve(data, "crag"))`, the
  same call the refit makes, with raw file sha256 7b6e696aa9b943a6 checked.
- **Label.** Row (iso, t) has `event = 1` when a spell starts in t+1. Rows inside a spell (including the cure years)
  are not at risk and are not in the file.
- **Rows.** Every ISO3 economy in the CRAG universe (159), for years 1980 up to the last labelled year at as_of
  2026-10-23 (2024, so labels run 1981-2025).
- **Count.** 166 events. Label years 2008-2023 hold 48, which is what a WEO-PIT refit starting 2007 can see.
  Per-year counts are in `manifest.json`.
- **Check.** The label equals Team B's `wb_interim_panel` label on every shared row (tested). On the history3 set the
  panel gives 2,098 rows, 105 economies and 44 events, against B's 2,110 / 106 / 44 (B does not restrict rows to the
  CRAG universe years).

## Coverage and main gaps (as_of 2026-10-23)

| Predictor group | Economies | Rows (of 5,887) | Years |
|---|---|---|---|
| crag_prior_spells | 159 | 100% | 1980-2024 |
| reserves_months_imports | 140 | 71% | 1981-2024 |
| stfx_debt_reserves (IDS: low and middle income only) | 111 | 57% | 1981-2024 |
| pitf_instability (WGI from 1996, no 1997/1999) | 156 | 57% | 1997-2024 |
| WB interim set (CA, growth, CPI, WGI scores, IDS ext debt, exports, NPL, youth unemployment) | 53-144 | 4-9% | mostly 2021-2024 |
| BIS (3 series), GPR | 6-8 | 2-3% | desk only |
| WEO five | 0 | 0% | not landed |

Non-WEO cell coverage is 18.1% (14.4% with the WEO columns).

1. **WEO history.** Debt/GDP and the primary balance have no non-WEO source on disk. This is the gap B-0140 needs
   closed for the pre-registered WEO spec. `fill_weo` lists it on every row.
2. **The World Bank universe pull covers only the last six years.** A full-history pull
   (`panel_history --wb-set interim`, 2000-2025) would fill `fill_wb_pull` (51,616 cells).
3. **BIS and GPR are recorded for the desk only** (`fill_bis_pull`, `fill_gpr_file`).
4. **Selection on outcome.** Restricted to the CRAG universe, 61.6% of panel economies ever defaulted, above B's 0.55
   preflight (`not_selected_on_outcome`). A real WEO history brings about 190 economies. The non-CRAG ones enter as
   zeros, which is an assumption (`default_panel.panel_coverage` reports it as zeros_not_covered_by_crag). Team B
   should expect this preflight to decide on the economy set.
5. The best non-WEO set that is not 2020s-only (reserves + instability + CRAG history) has 2,777 rows, 136 economies
   and 53 events.

## When WEO lands: one command

Put the WEO history in any one of these places. The first found wins, and only local files are read:

1. `data/panel/weo_history.csv`, the output of `python -m econquest.ingestion.panel_history --out data/panel --sources weo`
   on the Mac (docs/runbooks/A-full-panel-fetch.md), or a path given with `--weo-history`;
2. the WEO vintage archive `data/panel/weo_vintages/<YYYY-MM>/weo_long.csv` (A-weo-vintages.md);
3. hand-saved IMF "all countries" files, `data/panel/staging/weo_cache/weo_<YYYY-MM>.xls` (one per release, e.g.
   `weo_2007-10.xls`, `weo_2011-09.xls`; `python -m econquest.ingestion.panel_history --manual-list` prints every name).

Then run:

```zsh
python -m econquest.ingestion.hazard_panel_wide build --refit --author Sam
```

This rebuilds the panel with the five WEO columns filled point in time. It uses Team B's
`hazard_panel.panel_from_long` with lag 1 and only releases published by the end of year t, and drops anything
published after as_of. For routes 2 and 3 it writes `hazard_panel_wide/weo_history_assembled.csv` and records it (file, sha256, bytes) under
`weo_assembled` in `manifest.json`. It then runs
`python -m econquest.validation.hazard_refit --data data --as-of 2026-10-23 --events crag --weo-history <that file>
--author Sam` and exits with the refit's code (0 cleared, 1 not cleared, 2 input error, 3 preflight failed). Exit 4 is this
module's own: `--refit` found no WEO history, so no refit ran. Add
`--refit-out <folder>` to choose the refit's output folder. The refit itself is Team B's, and fitted mode is Tier 1.

Rehearsed on a scratch copy of data/ with SYNTHETIC WEO release files in `staging/weo_cache`. The command ran the
refit end to end (153 economies, 36 events, PREFLIGHT_FAILED on the synthetic pit_start and on the selection
share). The AUC on random data means nothing.

## API note for Team B (B-0140)

```python
import pandas as pd
panel = pd.read_csv("data/panel/hazard_panel_wide/panel.csv")            # internal only
cols = pd.read_csv("data/panel/hazard_panel_wide/columns.csv").set_index("column")
# or rebuild in memory, without writing:
from econquest.ingestion.hazard_panel_wide import build
r = build(as_of="2026-10-23", write=False)       # r["panel"], r["columns"], r["missing_map"], r["manifest"]
spec = ["stfx_debt_reserves", "reserves_months_imports", "pitf_instability"]   # e.g. history3
fit_rows = panel.dropna(subset=spec)             # then validation.hazard_panel.fit_and_validate(fit_rows, spec)
```

- **Keys.** `iso` (ISO3), `year` (row t). Predictors are period t-1 values (lag 1). The CRAG features use only spells
  started by t.
- **Labels.** `event` (0/1: a crag_v1 spell starts in t+1) and `ever_defaulted` (bool, any crag_v1 spell at as_of).
  `n_present` counts non-empty predictors, excluding crag_years_since_default.
- **Names.** Predictor names and transforms equal `hazard_panel.PANEL_FEATURES` (debt_gdp ... pitf_instability) and
  `hazard_refit.WB_INTERIM_FEATURES` (wb_*). Pre-registered specs therefore select columns by their existing names.
  The new columns are candidates only and are not pre-registered.
- **Missing values.** Empty means missing. crag_years_since_default is empty when the economy has no earlier spell;
  the map lists this under not_applicable, not as a gap.
- **Point in time.** Only the WEO and CRAG columns are point in time. The World Bank, BIS and GPR columns are the
  latest published values, so they include revisions (`columns.csv` point_in_time).
- **Event count.** 166 (rows 1980-2024). Label years 2008-2023 hold 48. The gate needs at least 30 events in the
  fitted panel after the spec's dropna.

## Checks

```zsh
python -m pytest -q tests/test_hazard_panel_wide_a140.py
python -m econquest.ingestion.mvp_dataset verify
python -m econquest.ingestion.licences check
python team/teamctl.py check --ticket EQ-A-0140
```

`mvp_dataset verify` stays ok with dataset_sha256 d3564255....

The same ticket also fixed SEC-A-009 items in `panel_history.py` (AGENT-09):
- L5: server Content-Type and Location headers are sanitised before they reach the unit error or the diagnostics file.
- I3: `_http_fetch` requests only www.imf.org or imf.org.
- I4: `weo_route_diagnostics.jsonl` rotates to `.1` above 5 MB.
