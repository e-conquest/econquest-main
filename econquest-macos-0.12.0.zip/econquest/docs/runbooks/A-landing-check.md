# Runbook: pull landing check (what Sam sends back after a Mac pull, and what Team A runs)

Ticket EQ-A-0061. Owner: Team A, AGENT-06. Operators: Sam (sending), Team A (checking). Written 2026-10-24 from
`econquest/ingestion/landing.py`. The pull itself is `docs/runbooks/A-mac-pull-pack.md` (`econquest mac-pull run`).

## Purpose

After `econquest mac-pull run`, Team A checks what came back before anything moves. The check
re-verifies every step from the files on disk (vintage hashes, build hashes, run manifests, restricted-source cells,
mapping QA, Team B's nowcast validator). It does not take the pack's own verdicts as evidence. It writes the
missing-cell report on feed-eligible cells and states, for each Blocked Team A ticket (EQ-A-0008, 0015, 0016, 0026),
whether the evidence unblocks it, quoting the checks. It never moves a ticket: AGENT-08 does that.

## Part 1 (Sam): what to send back

After every `econquest mac-pull run` (or `econquest mac-pull report`), these three files are in
`~/econquest/data/live/pullpack/`:

| File | Why |
|---|---|
| `report.json` | Step statuses, counts, vintage and run ids, file paths the check looks up |
| `state.json` | The same per step, plus the record a resume needs (artifacts); the check prefers it |
| `pullpack.log` | Timings and tracebacks for any failed step |

Send those three. **Do not send tokens or credentials.** The pack never writes the UCDP token, API keys or passwords
into these files, but check before sending:

```bash
cd ~/econquest/data/live/pullpack
grep -iE "token|api_?key|passw|secret|bearer" report.json state.json pullpack.log   # expect no output
```

If that prints anything, do not send the files; tell AGENT-08 instead. Never send `~/.zshrc`, environment dumps,
Keychain exports or `.env` files.

The three files tell Team A what happened. To **unblock** a ticket, Team A also needs the data the files name, because
the check re-verifies from disk:

- The whole `data/` folder: send the latest nightly backup (`econquest backup --list`, then the newest
  `<dest>/<date>/econquest-<ts>.tar.gz` and its `.manifest.json`; `docs/runbooks/A-restore.md`). The backup holds
  `data/live/pullpack/` too, so the three files above come with it.
- Step 2 (`panel_history`) needs `data/panel/staging/<run id>/manifest.json`. The backup has it. If you upload
  `data/panel` by hand instead, include that one file even when leaving out `staging/weo_cache`.
- Step 4 (`universe`) wrote its staged copy outside `data/` (default `~/econquest-universe-<UTC stamp>`, the path is
  in `report.json` under the universe step's `artifacts.stage_dir`). The backup does not hold it. Zip it and send it:
  `cd ~ && zip -r econquest-universe.zip econquest-universe-<stamp>`.

## Part 2 (Team A): what we run

Restore or unpack into a scratch folder, never over the project's own `data/`:

```bash
econquest backup --verify-only <archive>                       # re-hash the archive Sam sent
python -c "from econquest.ops.backup import restore; restore('<archive>', '/tmp/landing')"   # verifies, extracts, re-hashes
# or unpack a hand upload so that /tmp/landing/data/countries.csv exists
python -m econquest.ingestion.landing check --data /tmp/landing/data \
    [--report path/to/report.json] [--state path/to/state.json] [--stage-dir /tmp/landing/econquest-universe-<stamp>] [--json]
```

- `--report` / `--state`: when Sam sent the files separately. Without `--state`, `state.json` next to `--report` is
  used, else `<data>/live/pullpack/state.json`.
- `--stage-dir`: the unzipped universe folder (Mac paths in `state.json` do not exist here). Paths that live inside
  `data/` are found automatically (`data/market_history/builds/<v>/prices.csv` on the Mac ->
  `<--data>/market_history/builds/<v>/prices.csv`).
- Output (default `<data>/live/landing/`, or `--out DIR`): `landing_report.md`, `landing_report.json`,
  `missing_cells_feed_eligible.csv` and `missing_cells_by_country.csv` (`universe.missing_cell_report`, EQ-A-0055
  metric: share of feed-eligible cells live, target 60%), and when they ran `crag_comparison.csv` and
  `gdelt_mapping_qa.csv`.

With only the three files and no data, the check still reads them: every step the report calls done then fails
re-verification (nothing on disk) and the run exits 1. That is the expected answer to "can we unblock from the report
alone": no.

### What each step must show

| Step | Re-verified from disk |
|---|---|
| fx | vintage hash (`feeds.verify_vintage`), feeds ok, raw BIS/ECB kept, BIS-vs-ECB cross-check, `audit.restricted_source_cells` = 0 |
| fx_history | build `prices.csv` sha256 = provenance sidecar; columns exactly the 17 FX names; no ETF column; raw vintage verifies and is the sidecar's |
| panel_history | run manifest complete, every unit ok, final files at the run's sha256, panel vintage hash, WEO vintage column; row and country counts |
| crag | episode file at the import's sha256 and in its panel vintage; every episode with an ISO3 code and a source; no name left without an ISO code; `compare_panels` and `panel_coverage` outputs present and equal to a fresh run |
| universe | staged vintage verifies, pack's missing-cell report exists, fresh report covers every staged country (60% target shown, not required) |
| ucdp / gdelt | vintage indexed and at its manifest sha256; mapping QA (`events.mapping_qa`: GDELT unmapped share at or below 2%; UCDP countries all in the universe) |
| nowcast | vintage at its content hash; `data/live/nowcast_inputs.csv`, if present, passes `engine.nowcast validate` |

### Exit codes

- **0**: every step re-verified.
- **2**: partial. A step was not landed (skipped, pending), is missing from the report, or fails re-verification
  while the pack also said it was not done (for example fx held with restricted cells left). Also **not uploaded**
  (EQ-A-0070): when none of the pack's recorded files is under `--data` (only report.json and state.json were sent),
  the check is "away from the Mac" and a step reported done or held whose files are absent is "not uploaded", not a
  failure. Ask Sam for that step's files; a contradiction is only reported once some of the pack's files are here.
  A ticket already Done on the board shows "already Done on the board".
- **1**: error. Nothing to read, an unreadable file or unknown schema, or the report says a step is done and
  verified while the files fail ("REPORT SAYS DONE, DISK FAILS"). Treat that as tampered or incomplete: ask Sam for
  the backup again, do not unblock.

### Blocked tickets

`landing_report.md` has one section per ticket: verdict (`evidence unblocks it` / `still blocked`), the board row,
the last `blocked` reason from `team/logs/A.jsonl`, the quoted checks, what it is waiting on, and information checks
still open (for EQ-A-0026 the 60% feed-eligible target). The step mapping is `pullpack.BLOCKED_TICKETS`:

| Ticket | Needs |
|---|---|
| EQ-A-0008 | crag |
| EQ-A-0015 | panel_history |
| EQ-A-0016 | panel_history and crag, and at least 60 countries in the panel history |
| EQ-A-0026 | universe |

AGENT-08 moves a ticket out of Blocked only from a landing report with exit 0 or 2 whose ticket section says
`evidence unblocks it`, and quotes that section in the log.

## If something goes wrong

- `no pull has landed`: the files are not where the check looked; pass `--report` / `--state`.
- `staged data folder on disk` failing: unzip the universe folder and pass `--stage-dir`.
- `history run manifest exists` failing: `data/panel/staging/<run id>/manifest.json` was left out of the upload.
- `audit.restricted_source_cells is 0` failing: fx cells still carry Yahoo-era values; Sam reviews and applies the
  held fx3m cells (`docs/runbooks/A-daily-record.md`), reruns `econquest mac-pull run --apply-fx`, sends again.
