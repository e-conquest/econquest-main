# Research QA gate (EQ-C-0163)

Every country note, scenario brief, weekly brief and trade-ideas page is checked before it goes out. The gate lives
in `econquest/ops/research_qa.py`. It is **on by default** and only refuses; it never edits a product.

## What it checks
1. **Numbers match the cited run.** VaR / ES / EL / L-VaR / liquidity cost (`summary.metrics`), country 12-month
   default PDs (`country[].pd_default`), scenario losses (the stressed column of a brief and the weekly brief's stress
   rows, against that stress run's archived record), book limits, warning levels and limit utilisation
   (`data/limits.json`, utilisation = run metric / limit) and trade-idea signal strengths. The rounding tolerance is
   half a unit of the last digit printed (66.2 covers 66.15 to 66.25; 6.59% covers 6.585% to 6.595%). JSON
   manifests carry full values and must match within 1e-9 relative. A product that quotes figures from a run the
   gate cannot find fails ("cannot verify").
2. **No stale data.** The cited run may be at most `alerts.stale_days` (data/assumptions.json, 45) older than the
   product's date (file-name date, the weekly brief's requested as-of, or the archive period). Live inputs at the
   run's model date are checked with the freshness SLA (`data/live/freshness_sla.csv`) and the audit-trail retrieval
   age. Cells the quality gate holds are ignored. Any other stale cell for a country the product covers fails, unless
   the product discloses it in its Input caveats. A disclosed cell is listed as a flag and does not block.
3. **Products agree.** Two products for the same run must not quote different values for the same measure and
   subject. The gate compares the files being checked with each other, and with the published editorial items
   (at publish) or the latest archived versions (at archive add / correct).

## Where it refuses
- `econquest editorial publish ITEM`: refuses with `not published: research QA refused ...`.
- `econquest archive add` / `archive add --from-pack` / `archive correct`: refuses with `not archived: research QA refused ...`.

Each refusal names the figure, the value quoted and where (section, row, column), the expected value with its
tolerance, and the source (for example `run 20261026T004819-base country[Argentina].pd_default`).

## Running it by hand
```
econquest research-qa                                   # published items and latest archived versions under --out
econquest research-qa --path outputs/reports/mvp/notes  # a folder or file (repeatable)
econquest research-qa --run 20261026T004819-base --path FILE   # the product must cite this run
econquest research-qa --path FILE --json                # machine-readable; exit 1 on any failure
```

## When it refuses
Rebuild the product from the run it cites. Do not hand-edit numbers. If the run moved on, build the product again from
the new run. If an input is stale, refresh the data, or make sure the product's Input caveats disclose it. The gate has
no CLI switch to turn it off.

## Demo row M24
`research_qa.demo_research_qa(out_dir, data_dir=None, outputs_dir=None)` works offline on `data/mvp/data` in temporary
folders. It makes a small run and one country note that passes, then refuses an altered copy (PD tile moved by 1 pp)
in the gate and at `archive add`. It writes `<out_dir>/research_qa/` and never reads the repository's `outputs/`.
EQ-C-0166 wires it into the demo.
