# Runbook: nowcast inputs feed (data/live/nowcast_inputs.csv)

Ticket EQ-A-0057, answering Team B's handoff HO-20261024-B-A-001 (EQ-B-0071). Owner: Team A. Operator: Sam, on the
Mac. Code: `econquest/ingestion/nowcast_feed.py`. Tests: `tests/test_nowcast_feed.py` (synthetic data only).
Contract: `docs/validation/nowcast.md`, section "Input contract" (Team B).

**Written offline.** This cloud cannot reach `api.imf.org`, `sdmx.oecd.org` or `stats.bis.org`. Every dataflow,
key and code in the series map is UNVERIFIED, and no value exists until a real pull on the Mac. Nothing in
`nowcast_inputs.csv` is ever typed in by hand.

## What it does

| Piece | Where | Rule |
|---|---|---|
| Names | `python -m econquest.engine.nowcast names` | The 25 names. VEN, ZWE, BLZ, ZMB and SEN get CPI and trade only |
| Series | `data/live/nowcast_series_map.csv` | One row per (source, series): flow, key, filters, transform, priority, `est_lag_days`, `verified` |
| Sources | IMF SDMX 3.0, OECD Data Explorer SDMX, BIS SDMX | The `official/` adapters' transport and parser. A row whose dimensions differ from the request is refused |
| Transform | `nowcast_feed.yoy` | % y/y from index or level values in the same vintage (t over t-12 months, t over t-4 quarters). UNEMP is a level |
| Archive | `data/live/nowcast_vintages/<UTC ts>-<hash8>/` | Every fetch: `raw_<source>.csv` (with the licence), `transformed.csv`, `fetch.json`. Read-only, never overwritten |
| Release dates | `nowcast_feed.replay` | See below |
| Inputs | `data/live/nowcast_inputs.csv` | Append-only. Verified map rows only. It must pass Team B's validator before it is written |

Series: required GDP_YOY (Q), CPI_YOY, IP_YOY, EXP_YOY, IMP_YOY and CREDIT_YOY. Optional RETAIL_YOY, UNEMP, PPI_YOY and
CORE_CPI_YOY. PMI_MFG is left out because no licence is held, and the map refuses a PMI_MFG row.

**release_date rules**, replayed over the archive in fetch order:
- `official`: the publisher's release date, used when an adapter delivers one. None of the SDMX adapters does today.
- `estimated_lag`: history that the first fetch of a (country, series) finds. These sources keep only the latest
  vintage, so the date is set to period end plus the map row's `est_lag_days` (the publisher's usual lag). It is
  used only when that date falls before the fetch date. First-release scoring of this history means nothing.
- `fetched`: the fetch date. It covers a new period in a later fetch, a changed value (a revision gets its own row,
  and the old row stays), and a value whose estimated date would not fall before the fetch.
- An unchanged value adds no row. Two fetches on the same UTC date: the later one is that day's view.

**Licence.** IMF rows carry `IMF: internal research use only (Sam 2026-10-24 ...)` in the `licence` column of the raw
tables and of `nowcast_inputs.csv`, and `audit.client_output_reason` keeps them out of client output. BIS and OECD
rows carry their (unverified) terms. The nowcast module is internal research and off by default.

**Precedence.** When more than one source serves a series for a country:
- The lowest `priority` number wins. CPI: BIS, then OECD, then IMF. Other series: OECD, then IMF.
- After that, a series keeps the source it started with in `nowcast_inputs.csv`.

## Status of the map today (2026-10-24)

- **Configured (UNVERIFIED):** `bis_cpi`, `oecd_cpi`, `imf_cpi`, `oecd_core_cpi`, `imf_exp`, `imf_imp`.
- **Codes unknown, never requested:** GDP_YOY (`oecd_gdp`, `imf_gdp`), IP_YOY, CREDIT_YOY, RETAIL_YOY, UNEMP and
  PPI_YOY. **Three required series (GDP, IP, credit) have no code yet.** The first Mac session has to find them
  (step 2).
- **Verified:** none. Until a row is verified, a fetch archives that row's values but does not merge them.

## National sources (EQ-A-0119, 2026-10-25)

Code: `econquest/ingestion/nowcast_national.py`. Tests: `tests/test_nowcast_national.py`, on fixtures in
`tests/fixtures/nowcast_national/`. The fixtures copy each API's documented layout but hold SYNTHETIC values. They are
not recordings, because this cloud cannot reach the hosts.

These are free official sources with no key. Each serves one country:

| Source | Name | Host | Rows in the default map (codes UNVERIFIED) |
|---|---|---|---|
| `bcb_sgs` | BRA | api.bcb.gov.br | `bcb_cpi` 13522 (published y/y), `bcb_ip` 21859, `bcb_credit` 20539, `bcb_unemp` 24369; `bcb_gdp` code unknown |
| `bcrp` | PER | estadisticas.bcrp.gob.pe | `bcrp_cpi` PN01273PM (published y/y); `bcrp_credit`, `bcrp_ip` codes unknown |
| `datos_ar` | ARG | apis.datos.gob.ar | `ar_cpi` 148.3_INIVELNAL_DICI_M_26; `ar_ip`, `ar_gdp` ids unknown |
| `dosm` | MYS | api.data.gov.my | `dosm_cpi` cpi_headline / index / division=overall, `dosm_unemp` lfs_month / u_rate; `dosm_ip` unknown |

- **Map columns.** `filters` holds the codes: `SERIES=code`, or for OpenDOSM `DATASET=id;VALUE=field;dim=code`. `key`
  stays empty. A blank `filters` means the row is never requested. The new transform `yoy_published` keeps a series
  that the publisher already gives as % y/y.
- **Precedence.** Every national row ranks after the existing BIS / OECD / IMF rows of its series, so it only fills a
  gap. Changing that is a precedence decision (`map-set --priority`), and it is not made here.
- **Licence.** Rows carry `national nowcast <source>: ... internal research use only`. The register rows
  `nowcast_<source>` in `data/licences.csv` keep them internal (client restricted, validator UNVERIFIED) until the
  terms are read. The source column starts with `national: `.
- **The shared map is unchanged (17 rows).** Its file is part of the data hash, so the new rows go in only on the
  Mac, together with step 2:
```
python -m econquest.ingestion.nowcast_feed plan --add-defaults
```
  This appends only the missing default rows, all with verified=no. Existing rows are never changed.
- **Not added, and why.** The ECB publishes euro-area series only, and none of the 25 names is in the euro area.
  Banxico, BCCh and BoK ECOS need a registered token or user, which can be added later through the keychain as
  `official.central_banks` does. INEGI, e-Stat and BPS are keyed. The other names have no documented machine API
  (`official.central_banks._MANUAL_ONLY`).
- **Probe on the Mac.** After `plan --add-defaults`, run `fetch --sources bcb_sgs,bcrp,datos_ar,dosm --names BRA,PER,ARG,MYS`
  and then `merge --include-unverified --out outputs/nowcast/trial_inputs.csv`. Check two or three periods of each row
  against the publisher's release, then `map-set ROW --verified yes --by Sam --evidence "..."` (steps 4 and 5).

## On the Mac

From the econquest folder, with the venv active (`docs/runbooks/A-fetch-on-mac.md`, "Setup").

**1. Plan (offline, writes nothing except the map if it is missing).**
```
python -m econquest.ingestion.nowcast_feed plan --write-map
```

**2. Find the unknown codes (network).** Save each dataflow structure and read the dimension ids and codes. For the
IMF, use the existing helpers in `official/imf.py`:
```
python -m econquest.ingestion.official.imf structure QNEA --out outputs/imf_structure
python -m econquest.ingestion.official.imf structure IMTS --out outputs/imf_structure
python -m econquest.ingestion.official.imf structure CPI  --out outputs/imf_structure
python -m econquest.ingestion.official.imf sample IMTS --iso BRA --filter INDICATOR=XG_FOB_USD --filter COUNTERPART_COUNTRY=G001 --filter FREQUENCY=M
```
For the OECD, open the dataflow in the OECD Data Explorer and copy the SDMX key from "Developer API". For BIS, the
long CPI series is at `https://stats.bis.org/api/v1/data/WS_LONG_CPI/M.BR.628/all?format=csv`. Put each code you
find into the map. A code change resets `verified` to no:
```
python -m econquest.ingestion.nowcast_feed map-set imf_gdp --flow QNEA --filters "INDICATOR=...;PRICE_TYPE=...;FREQUENCY=Q"
python -m econquest.ingestion.nowcast_feed map-set oecd_ip --flow "OECD.SDD.STES,DSD_STES@DF_INDSERV,4.1" --key "{area}.M...." --filters "FREQ=M;MEASURE=..."
```
OECD and BIS rows need a `--key` containing `{area}`. IMF rows use `--filters` only.

**3. Fetch (network, about 1 to 5 minutes).** Every source host is probed first. If none answers, the fetch stops
and writes nothing. Each fetch is archived, then verified rows are merged:
```
python -m econquest.ingestion.nowcast_feed fetch
```
Use `--sources bis,imf` to limit the sources and `--names BRA,COL` to limit the names.

**4. Check what came back, then verify (offline).**
```
python -m econquest.ingestion.nowcast_feed merge --include-unverified --out outputs/nowcast/trial_inputs.csv
python -m econquest.ingestion.nowcast_feed status
```
For each map row, check the trial file against the publisher's own release for two or three names: the latest
y/y and one older month. The national statistics office's press release is good enough. Then mark the row verified:
```
python -m econquest.ingestion.nowcast_feed map-set bis_cpi --verified yes --by Sam --evidence "WS_LONG_CPI M.BR.628 vs IBGE IPCA Sep-2026 y/y"
```
While you are there, check `est_lag_days` against the publisher's calendar (`map-set ROW --lag-days N`). **Fix the
lags before the first merge.** A lag changed afterwards adds duplicate history rows with new dates (the old rows
stay, because the file is append-only).

**5. Merge into the live file (offline).** This replays every archived vintage, so a row verified today also brings
in what earlier fetches saw, with their own dates:
```
python -m econquest.ingestion.nowcast_feed merge
python -m econquest.engine.nowcast validate --inputs data/live/nowcast_inputs.csv
python -m econquest.ingestion.nowcast_feed status
```
`status` lists, for each name and series, the periods held, whether the history rule is met (36 months, or 13
quarters for GDP), the release_date_basis counts, and what the latest vintage holds.

**6. Send back** `data/live/nowcast_inputs.csv`, `data/live/nowcast_series_map.csv`, the new folders under
`data/live/nowcast_vintages/` and the `status` output. Repeat step 3 monthly, or after each major release. Every
fetch adds real vintages, and first-release scoring starts from the first live fetch.

## When something fails

| Message | Meaning | Action |
|---|---|---|
| `refused: offline: no source host answered ...; nothing written` | Every probe failed (proxy, DNS) | Check the network and rerun. Nothing was written |
| `refused: no source returned a row; nothing written` | The hosts answered but every request failed | Read the reasons. A 404 usually means a wrong flow or key |
| `unexpected DIM=... answer refused` in the failures | The publisher returned another series than the one asked for | Fix the filters with `map-set` |
| `vintage ... archived, but the merge ... stopped` | A key already holds a different value, or the contract check failed | Nothing was written to the inputs file. Send the message and the vintage to Team A |
| `no rows eligible` | Nothing is verified yet | Steps 4 and 5 |

## Not done here

- `pullpack.py` has no `nowcast` step yet: the module was owned by another ticket when this was written. The hook for
  it is described in the EQ-A-0057 report.
- National statistics offices and central banks would give `official` release dates and longer, first-release
  history. EQ-A-0050's `official/central_banks.py` could feed this map once it exists.
- PMI_MFG needs a licence decision by Sam.
