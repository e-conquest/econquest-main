# Decision pack: client mode (yes / no / later)

Ticket EQ-C-0094 (Team C, AGENT-02), PI-8, 2026-10-25. For Sam's decision card. This is a description of the repo
and a checklist, **not legal advice and not a licence opinion**. Client mode is off, and nothing in this ticket
changes `data/research.json`, the licence register, a licence or a credential.

Evidence: `econquest client-pack` writes the INTERNAL pack to `outputs/client_pack/` (`pack.md`, `pack.json`,
`numbers.csv`, `blockers.csv`, `manifest.json`). It holds the full client-check table, Team B's numbers, the build
scope, the entitlement and disclaimer text, the checklist for counsel and all blockers with owners. The pack is
internal: its "today" numbers use IMF (EXC-003) and theratesapi.com (EXC-005) data.

## Question

Should econquest research go to outside recipients (client mode), and if so, when?

## Facts

- **client-check, 2026-10-25: 2 pass, 11 fail, 3 hard blockers** (`imf` 482 cells, `restricted` 17 Yahoo cells,
  `licence_register`). Exit 1. The passes are `acled` (off) and `disclaimer_core`.
- **Team B's client-safe run (EQ-B-0089, as_of 2026-10-23, 100,000 paths)** swaps 177 IMF, Yahoo and EXC-005
  cells and drops 6 FX columns. The portfolio barely moves:

  | Metric ($mm) | Internal | Client-safe | Change | Paired SE |
  |---|---:|---:|---:|---:|
  | VaR99 | 58.19 | 58.93 | +0.74 (+1.3%) | 0.23 |
  | ES99 | 78.72 | 79.42 | +0.70 (+0.9%) | 0.09 |
  | EL | 0.88 | 0.86 | -0.02 (-2.4%) | |
  | L-VaR99 | 63.47 | 64.21 | +0.74 (+1.2%) | |

  Stress ES99 moves at most 1.3%. Most of the rise comes from EXC-005 FX through the copula, not from IMF data.
- **Country level is weaker.** DSA signal 26 is not computed for any of the 18 countries, and signal 1 is blank for
  9 (indicator 1.1 has no cleared source). Country PDs rest on older analyst seeds in place of WEO. Zimbabwe's
  default PD rises 11.2 pp, and Team B attributes that to seed quality, not to risk.
- **Team B's copy and the licence enforcement do not agree.** `presentation/licences.evaluate` withholds 492 cells
  today. Team B replaced 177: it keeps 305 seed cells whose series cite IMF, and Yahoo `equity_vol` (10 cells).
  So the numbers above are not yet the numbers of a build that enforcement would let out. Client-pack reports this
  as the hard blocker `client_safe_rule_gap`.
- **Licences.** Every third-party row in `data/licences.csv` is UNVERIFIED except ucdp, vdem, aqueduct and ciesin
  (allowed), and gti and undrr (barred). Adjustments are the desk's own. `client_ok` is not trusted until the register is under `econquest change`
  (SEC-C-015 I3, R44), and it is not under change control today.
- **Controls already built, all off:** watermark ("Prepared for <recipient> on <date>. Not for onward
  distribution."), entitlements (`research.json`, 0 recipients), the IMF guard and licence guard in
  `client-package` and `distribute`, the core disclaimer, and the attribution block. The client disclaimer is empty.
  There is no named compliance approver, and self-sign is allowed.
- **People.** There is one operator. No approver is independent of the author. Program board PI9-ALL plans
  "licensed data live, second analyst" (calendar-gated, 2027).
- EQ-C-0083 (docs/research/client-readiness.md section 5) recommended staying internal.

## Options

**(a) Yes, after named blockers.** Sam approves client mode now, to take effect once these are cleared, in this order:
1. A compliance adviser is engaged and gives a written scope opinion (Sam).
2. IMF: either written permission for client use, or WEO replaced by cleared feeds (Team A) and validated (Team B).
3. The 17 Yahoo fx3m cells are cleared by the official FX fetch on the Mac (Team A).
4. One client-output rule covering seed cells and equity_vol, agreed by Team A, B and C, with Team B's comparison
   rerun on it.
5. Licence texts filed and verified for every source left in client products (Team A, Sam).
6. `data/licences.csv` put under `econquest change` (Team C, R44).
7. A named compliance approver who is not the author, the client disclaimer, an independence policy and a
   conflicts register (Sam, adviser).
8. A governed recipient register and entitlements (new Team C ticket, then Sam).
9. `client-check` exits 0, then Sam applies the `research.json` change.

Cost: the most work, and the result is a client product whose country views rest on seeds and which has no DSA
signal, unless the IMF permission is obtained. Single-operator independence remains a gap until a second person
joins.

**(b) No: internal research only.** The decision is recorded, and the client code stays built and off. There is no
further work on recipients, the adviser or licences for client use. Cost: it closes a path that the portfolio-level
result shows is feasible, and reopening it later means a new decision.

**(c) Later: revisit at PI-9 with licensed data.** Stay internal now. Revisit when licensed data is live and a
second analyst is in place (PI9-ALL). Meanwhile, do only the steps that are worth doing for internal work anyway:
R44, the client-output rule gap and the Team B rerun, licence text verification, and Team A's official FX fetch.
Optionally, a first scoping conversation with an adviser. Cost: there are no client products before PI-9.

## Recommendation: (c) later, at PI-9 with licensed data

Reasons:
1. **The blockers are not engineering.** The four hard blockers are IMF permission, licence verification and the
   register's governance, and the rule gap. The rest needs an adviser, a named independent approver and
   recipients. None of these can be closed by the team alone, and the independence gap only closes with a second
   person, which is planned for PI-9.
2. **The client-safe product is not yet one we would want to send.** Portfolio numbers hold (about +1%), but the
   country views lose signal 26 and signal 1 and rest on seeds that Team B calls a stopgap. Licensed data at PI-9 is
   the realistic fix.
3. **Saying (b) "no" now discards a cheap option.** The controls are built and off, and the portfolio result shows
   a client product is feasible.
4. **The interim steps of (c) are no-regret.** R44, the rule gap, licence verification and the FX fetch also make
   internal output and the validator evidence more accurate.

Sam's call. Licences, the adviser and the `research.json` change are his, and no agent can make them.

## Decision

Sam, 2026-10-25 11:29Z (decision card in the Team C thread): **(c) later, at PI-9 with licensed data.** Client mode stays off (`research.json` mode internal). In the meantime the no-regret steps go ahead: put `data/licences.csv` under `econquest change` (R44), close the client-safe rule gap with Team B (HO-20261025-C-B-002), verify licences (Team A), and revisit at PI-9 planning.
