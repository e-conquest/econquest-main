# Research product line: internal mode today, and what client mode would require

Ticket EQ-C-0075 (Team C). Written 2026-10-24 for Sam's decision on the program board item "Internal vs client".
**Client mode is off.** Nothing in this document changes that. It lists what would have to exist before Sam could
reasonably approve it.

## 1. What exists now (internal mode)

| Product | Command | Source of every number | Cadence (data/publication_calendar.json) |
|---|---|---|---|
| Weekly macro, sovereign and geopolitical brief | `econquest weekly-brief --as-of D [--pdf]` | Archived base run at or before D, the run about a week earlier, matched stress-`<key>` runs, `data/limits.json`, UCDP/GDELT files, `outputs/idea_log.csv` | weekly |
| Country notes | `econquest notes [--pdf]` | Latest archived run and output files | monthly |
| Scenario briefs | `econquest briefs [--pdf]` | Stress runs, `stress.json`, `reverse_stress.json` | monthly |
| Trade-idea review | `econquest ideas report` (Team B log) | `outputs/idea_log.csv` | quarterly |

Controls already in force for every product:

- **Stamps.** Each product carries the run_id, as-of date, data_hash, code_hash and run_hash. In the weekly brief every
  table row that holds numbers carries `data-run-id` / `data-data-hash`. The `.json` next to the brief repeats every
  number with its stamp. Nothing is estimated in the presentation layer, and no text is generated from free text.
- **Editorial ledger** (`econquest editorial`). Products go draft, then four-eyes review, then the compliance checklist
  (disclaimer, sources, Input caveats, conflicts declaration, compliance sign-off by an approver from
  `data/compliance.json`), then an immutable published copy with a manifest. Corrections and withdrawals are ledger
  rows. `weekly_brief` is an editorial kind.
- **Disclaimers.** `report.DISCLAIMER` (use restriction 6.1, governed core) is on every product. Above it sits the
  configurable research block from `data/research.json`. In internal mode the block reads "INTERNAL RESEARCH. Internal
  research, not investment advice, not for distribution."
- **Distribution** (`econquest distribute`). It is a dry run unless `--send`, and new addresses must be confirmed once.
  **In internal mode it refuses every address outside `internal_domains` / `internal_addresses` in
  `data/research.json`.** The shipped allow-list is empty, so nothing is sent until an allow-list change is approved.
- **Change control.** `data/research.json` is governed by `econquest change`. A change that touches `/mode` is Tier 1.
  A change that sets `mode` to `client` cannot be approved, or applied, unless the approval is signed by Sam. A hand
  edit to `client` has no effect: the products and `distribute` stay in internal mode and report the drift, because
  client mode is honoured only when the file's sha256 is the one written by Sam's approved change.

## 2. What client mode would additionally require

Switching the flag is the last step, not the first. Each item below needs an owner and evidence before Sam approves
the `research.json` change.

### 2.1 Compliance review

- A named compliance function (person or firm) with authority over external research, recorded in
  `data/compliance.json`. At present the approver list is empty and self-sign is allowed under single-operator mode.
  Client products would need `allow_self_sign: false` and an approver who is not the author.
- A regulatory scope opinion for the jurisdictions of the recipients. Investment research or a marketing
  communication? Does it fall under MiFID II research rules, FCA COBS 12, or SEC/FINRA research analyst rules (FINRA
  2241/2242) if any recipient is a US person? Is the publisher authorised or exempt?
- Client disclaimer text (`disclaimer.client`) approved by compliance: nature of the research, the model's paper-mode
  and seed-input limitations (use restriction 6.1), no offer or recommendation, the jurisdiction, past performance
  for the trade-idea track record.
- A pre-publication review standard: which sections may leave the desk. The trade-idea log is Tier 3 and illustrative
  (GOV-032), and PD/VaR figures are not to be quoted as model outputs under restriction 6.1. A record of the review
  for each item, which is the existing checklist row extended with a "client release" item.
- The model-risk position: Team B's independent validation of the figures that would be shown (layer 1 mode, the
  forecast record of at least 250 days, benchmark scoring). Today the policy forbids quoting them outside the desk.

### 2.2 Research independence

- A written independence policy. Who may see a product before publication? Is the author separate from any trading
  or sales interest? May anyone outside research change a conclusion?
- Separation between the trade ideas and any book that trades them. Ideas would be published only after (or at the
  same time as) any internal use, so there is no front-running.
- A record that conclusions come from the stored model runs (already enforced: stamps, no free-text generation),
  plus a log of any analyst override and its reason.
- A process for complaints and corrections visible to clients. The editorial `correct` / `withdraw` rows exist, but
  there is no client notice for them.

### 2.3 Conflicts disclosure

- The author's conflicts declaration exists in the checklist. Client mode would need a standard disclosure block on
  the product: positions held by the author or the firm in the instruments or countries covered, compensation links,
  and relationships with covered sovereigns or issuers.
- A firm-level conflicts register that compliance checks against at sign-off, and a rule for when a conflict blocks
  publication rather than being disclosed.
- Disclosure of the trade-idea methodology and of the hit-rate track record's limitations (sample size, unmarked
  ideas, P&L excluding carry and costs), shown with every idea.

### 2.4 Recipient onboarding

- A recipient register to replace the bare subscriber list. For each recipient: legal entity, contact,
  jurisdiction, client categorisation (professional or eligible counterparty; no retail), the date of agreement to the
  terms of use, who onboarded them, and an offboarding date. Kept under change control like `research.json`.
- Terms of use and a confidentiality and redistribution clause, accepted before first delivery. The existing confirm
  step (EQ-C-0051) would check against the register, not only against the subscriber request.
- Data-protection basis for holding recipient addresses (GDPR/UK GDPR if applicable), a retention period, and an
  unsubscribe path in every message.
- Delivery controls: the archive link must not be open to the internet without authentication (today it is a
  `file://` path or a configured https base URL with no access control). Per-recipient access logging, and expiry of
  links for offboarded recipients.
- Licensing of the inputs shown to clients. Vendor data (Bloomberg/LSEG, off by default), UCDP/GDELT terms and any
  restricted-source cell (SEC-A-006, already refused for workbook writes) must allow external redistribution. Data
  that may not be redistributed would have to be removed from client products.

## 2.5 Already built for client mode, and OFF (EQ-C-0082)

- **Client packaging.** `econquest client-package ITEM --recipient ADDR --date D` writes a watermarked copy of a
  published item ("Prepared for <recipient> on <date>", as an overlay and a recipient line). Code:
  `econquest/presentation/client_package.py`.
- **Entitlements.** `entitlements` in `data/research.json` maps each recipient to the product kinds they may receive.
  It is changed through `econquest change`. In client mode, `distribute` also refuses any recipient who is not
  entitled to the kind.
- **IMF guard.** Sam 2026-10-24 12:38Z: IMF data is for internal research use only. Client packaging and client-mode
  `distribute` both refuse a product when either of these holds:
  - any applied input cell carries IMF or WEO-derived data (`ingestion.audit.client_restricted_cells`);
  - a product file names IMF or WEO.
  Separately, `research.effective_mode` stays internal while any such cell is applied (EQ-C-0080). Today's desk
  applies WEO cells, so client output would be refused even if client mode were approved. The country notes' DSA
  sections and their sources name WEO. A client product line therefore needs a non-IMF source for those inputs, or
  IMF's written permission.
- **Still OFF.** All of this is refused while the research mode is internal, which is the default.

## 3. How the switch would be made (once section 2 is done)

1. Compliance approves `disclaimer.client` and the recipient register. The register is a new governed file (a new ticket).
2. Someone proposes the change: `econquest change propose research.json --set '/mode="client"' --set '/disclaimer/client="..."' --author <name> --reason "<board decision ref>"`.
3. Sam approves it: `econquest change approve <id> --approver Sam`. In single-operator mode Sam may approve his own
   proposal only with `--self-approved --exc EXC-nnn`. Any other approver is refused.
4. `econquest change apply <id>`. Then check `econquest calendar` ("Research mode: client") and run
   `econquest distribute send` as a dry run before any `--send`.
5. To revert, propose `/mode="internal"`. Any edit outside the tool also reverts to internal automatically.

Until then the decision stays open on the program board, and the code keeps internal mode as both the default and the
fail-safe.
