# Client readiness: what client mode would need

Ticket EQ-C-0083 (Team C, AGENT-09), PI-7, 2026-10-24. This is a checklist and a description of the repo, **not legal
advice and not a licence opinion**. It follows docs/research/product-line.md (EQ-C-0075), which describes the products
and the switch. This document lists the requirements one by one, the data licences per source, and how
`econquest client-check` tests each one against the repo.

**Sam needs a compliance adviser before any client decision.** Wherever this document says "the adviser decides", it
means the question needs a qualified person in the jurisdictions concerned. Nothing here states what any rule
requires, whether a licence or exemption is needed, or whether a text is adequate.

Client mode is off. Nothing in this ticket changes `data/research.json`, a licence, or a credential.

## 1. The checker

```
econquest client-check          # PASS / FAIL per requirement; exit 1 while anything fails
econquest client-check --json   # the same as JSON: {"ready": false, "checks": [...]}
```

It reads only: no file is written, nothing is fetched, and it is not in the operator action log. A PASS means the repo
holds the record the requirement names. It does not mean the record is adequate. `FAIL*` marks a hard blocker.

Result on the repo data, 2026-10-24: **2 pass, 10 fail. Exit 1, as expected.**

| id | Requirement | Today | What would make it pass |
|---|---|---|---|
| `mode` | Client mode approved by Sam and applied (`research.json` through `econquest change`) | FAIL: internal | Section 3 of product-line.md, last of all |
| `imf` | **Hard blocker:** no applied cell carries IMF / WEO data | FAIL*: 482 cells | Section 4 |
| `restricted` | No applied cell from Yahoo or a non-commercial or personal licence | FAIL*: 17 cells | Team A's `audit restricted` list cleared |
| `licences` | Every licence behind product data verified from its text and allowing client use | FAIL: BIS, IMF, World Bank, Yahoo to verify; IMF and Yahoo not for clients | Section 3 |
| `acled` | ACLED (non-commercial) not feeding products | PASS: off | Stay off until a corporate licence is recorded |
| `disclaimer_core` | Core disclaimer (`report.DISCLAIMER`, restriction 6.1) on every product | PASS | (already in force) |
| `disclaimer_client` | Client disclaimer approved by compliance and applied | FAIL: empty | Adviser-approved text through `econquest change` |
| `allow_list` | Internal allow-list approved (who is internal, as distinct from a client) | FAIL: empty | `change propose research.json --set /internal_domains=[...]` |
| `entitlements` | `research.json` entitlements cover every subscriber in `distribution.json` | FAIL: none | Entitlements per onboarded recipient |
| `recipients` | Governed recipient register | FAIL: none | New ticket: a `recipients.json` under change control |
| `compliance` | Named compliance approver, self-sign off, `compliance.json` governed | FAIL | Approver named, `allow_self_sign: false`, through `econquest change` |
| `adviser` | Adviser records: regulatory scope opinion, independence policy, conflicts register, record-keeping policy | FAIL: no record | New ticket: a governed record that points to the adviser's documents |

A check that cannot run fails. It does not pass.

## 2. Requirements

### 2.1 Disclaimers

- The core text (`report.DISCLAIMER`, use restriction 6.1) stays on every product. The research block from
  `research.json` sits above it.
- Client text (`disclaimer.client`): the adviser drafts or approves it. Topics to put to the adviser: the nature of the
  research, model and seed-input limitations, no offer or recommendation, who it is for, past performance, data
  attributions that the licences require (Section 3).
- Attribution lines that a source requires (for example citation clauses) belong in the product sources section. The
  wording depends on licence texts that are not in the repo yet.

### 2.2 Research regulation (plain terms, for the adviser)

Whether sending this research to outside recipients is regulated depends on things the repo does not settle. These
are the questions to put to a compliance adviser. This document does not answer them.

- **What the output is.** Is it investment research, a marketing communication, general market commentary, or
  something else? Each may be treated differently. The trade ideas are the part most likely to matter.
- **Who sends it and from where.** The jurisdiction of the publisher, and whether the publisher holds, needs, or is
  exempt from an authorisation or licence for this activity.
- **Who receives it and where.** Recipient jurisdictions and categories (professional or not). Rules can differ by
  recipient country, and some recipients may make an exemption available or unavailable.
- **Paid or free, and linked to any trading or advisory business.** This can change how the output is classed.
- **What follows from the answers:** required disclosures, pre-publication review, record keeping, and any
  registration or notification.

Product-line.md section 2.1 names some regimes as examples of what to ask about. Those names are prompts for the
adviser, not conclusions.

### 2.3 Conflicts and independence

- A written independence policy: who may see a product before release, and who may change a conclusion. The author
  must be separate from any trading interest. Ideas are not used internally ahead of recipients.
- A conflicts register (author and firm positions, compensation links, relationships with covered sovereigns), checked
  at sign-off, with a rule for when a conflict blocks publication rather than being disclosed.
- Already in force: every number is stamped to a stored run, and no text is generated from free text. The editorial
  checklist already includes a conflicts declaration and a compliance sign-off by an approver from `compliance.json`.
  Today that approver list is empty, and self-sign is allowed under single-operator mode. Client mode would need a
  named approver who is not the author.

### 2.4 Recipient onboarding

- A governed recipient register: legal entity, contact, jurisdiction, category, terms of use accepted (date),
  onboarded by, offboarding date. It does not exist yet, which makes it a new ticket.
- Entitlements: `research.json` `entitlements` (recipient to product kinds, EQ-C-0082). `client-package` and
  `distribute` already refuse a recipient who is not entitled.
- Terms of use with a confidentiality and redistribution clause. Our licences may require that clause (Section 3).
  The basis for holding addresses, a retention period, and an unsubscribe path: the adviser decides what applies.
- Delivery: no unauthenticated archive link, and per-recipient access logging (product-line.md 2.4).

### 2.5 Record keeping

What already exists: the editorial ledger (draft, review, checklist, publish, correct, withdraw; hash-chained, with
immutable published copies and manifests), the distribution ledger (who was sent what, and when), the approvals log
for governed files, the operator action log, and the run archive. All of these are append-only and can be verified.

Open questions for the adviser: retention period, whether recipient-level delivery records must be kept, and whether
communications with recipients must be recorded. The off-site copy of the ledgers is still Sam's decision D4 (keyed
heads are built but switched off).

## 3. Data licences per source

**No licence text is stored in the repo.** What the repo holds is licence tags on the data, runbook notes, and two
decisions by Sam. So no source can be marked "verified from the licence text in the repo". Every source is
**to verify**: file the licence text (or a dated copy) in the repo, have someone read it against client use, then
change that source's `status` in `econquest/ops/client_check.py` `LICENCES`, citing the file. Escalate every licence
question to Sam. An agent never decides one.

| Source | Terms as the repo records them | Where recorded | Client use | Status |
|---|---|---|---|---|
| IMF (WEO, SDMX, imf-reader) | Internal research use only (Sam 2026-10-24 12:38Z, EXC-003). External validator data room under NDA only (Sam 15:20Z). Commercial reuse and bulk download need IMF permission | `official/__init__.py` `IMF_LICENCE`; A-coverage-plan.md | **No** (Sam's decision) | to verify (decision binding regardless) |
| World Bank (WDI, IDS) | "Mostly CC BY 4.0, per dataset" | A-coverage-plan.md row 2 | To verify per dataset | to verify |
| BIS (policy rate, REER, credit gap, XRU) | Reuse with attribution, per the runbook | A-market-data.md; A-official-fx.md | To verify | to verify |
| ECB (EXR) | Free reuse with attribution, per the runbook | A-official-fx.md | To verify | to verify |
| OECD | "Believed CC BY 4.0 (unverified)" | `official/__init__.py` | To verify | to verify |
| Eurostat | "Free reuse with attribution (unverified)" | `official/__init__.py` | To verify | to verify |
| UCDP | CC BY 4.0, cite UCDP (API token needed) | `events/ucdp.py`; A-spike-event-feeds.md | To verify | to verify |
| GDELT | Use with citation and link (read 2026-10-23, "not re-checked") | `events/gdelt.py` | To verify | to verify |
| ACLED | **Non-commercial** free tier. Corporate licence needed (EULA 1.2, 3.1 as quoted in the spike) | A-spike-event-feeds.md; `events/acled.py` (off) | **No** without a corporate licence | to verify (tier terms) |
| Central banks (BCB, Banxico, BCRA, BoK ECOS, BCCh, BCRP, BNM) | Each "terms UNVERIFIED". Team A recommends treating them like IMF until checked | `official/central_banks.py` `APIS`; A-central-bank-adapters.md section 6 | To verify per bank | to verify |
| Yahoo Finance | Personal, non-commercial use only. Removed (EQ-A-0040), but 17 applied cells remain | `feeds.py`; `audit.restricted_source_cells` | **No** | to verify |
| FRED | Public-domain series; FRED terms apply | A-market-data.md | To verify | to verify |
| Vendors (Bloomberg, LSEG) | Entitlement scope `desk-internal` or `redistribution` (`vendor_licences.json`). Off | `vendors/base.py`; A-licensed-vendors.md | Only with `redistribution` scope | none held |
| Seed and hand-entered | The desk's own estimates and entries | `audit_trail.csv` | No third-party licence. Independence and quality review still apply | n/a |

The checker reads source labels from `data/audit_trail.csv` and `data/live/provenance.csv`. A label that is not in
the register fails as untagged. `econquest dsa` values count as their inputs (IMF, World Bank).

## 4. Hard blocker: IMF data (EQ-C-0080)

Under EQ-C-0080 (AGENT-01), client mode stays internal **even after Sam approves it** while any applied cell is
flagged by Team A's IMF/WEO check (`python -m econquest.ingestion.audit client`), or while that check cannot be read.
Products are built from all applied cells, so the cells cannot be filtered one by one. **482 cells are flagged
today.** `client-check` reports this as `FAIL* imf`.

Sam's options:

1. **Replace** the IMF/WEO inputs that client products use with non-IMF sources. Those sources' licences must
   themselves be verified (Section 3), and the change would need Team B's validation.
2. **Get an IMF licence or written permission** for client use (copyright@imf.org, per the coverage plan), filed in
   the repo.
3. **Stay internal.**

**Review of the EQ-C-0080 change (does it fail closed?).** Mostly yes. `effective_mode` and
`client_package.imf_problems` treat an exception from the check as "held". There was one gap: the check finds IMF
cells through their provenance records (`audit_trail.csv`, `live/provenance.csv`, the vintages). If those files were
missing, empty or unreadable, it would have found no cells and let client mode through, with IMF values still
applied. **Fixed under this ticket:** `research.imf_evidence_problem` refuses unless `audit_trail.csv` is a regular
file with the required columns and at least one row, whenever `indicators.csv` or `countries.csv` exist.
`research.client_restricted_cells` raises in that case, so the callers fail closed. `imf_problems` now goes through
it. Tests are in `tests/test_client_check.py`. Still open, and Team A's to decide: a value matched only within the
rounding tolerance, or a hand edit of an IMF value, is no longer tied to IMF.

## 5. Recommendation for Sam

**Stay internal.** The internal product line works and its controls are in force. Client mode fails on two hard
blockers (482 IMF cells, 17 Yahoo cells) and has no compliance adviser, no recipient register and no verified
licence text for any source.

Conditions for going client, in order:

1. Engage a compliance adviser. Get a written scope opinion: is a licence or exemption needed, and which disclosures
   and records follow.
2. Resolve IMF (Section 4) and clear the Yahoo cells.
3. File the licence texts of every source left in client products, and mark each one verified.
4. Name a compliance approver and turn self-sign off. Approve the client disclaimer, the independence policy and the
   conflicts register.
5. Build the governed recipient register (new ticket), then onboard recipients with entitlements.
6. Run `econquest client-check` until it exits 0, then make the `research.json` change, which only Sam can approve.

## 6. Client mode sandbox (EQ-C-0145)

The sandbox rehearses a client delivery end to end on shared data without a client, an email or a licence decision.
Client mode stays off. The code is `econquest/ops/client_outbox.py`, the tests are in `tests/test_client_outbox.py`,
and the security note is `team/security/SEC-C-021.md`.

```
econquest client-outbox build  --sandbox [--entitlements FILE] [--run NAME] [--date D] [--demo-baseline]
econquest client-outbox send   --sandbox --run NAME [--recipient ADDR ...]
econquest client-outbox verify [--run NAME]                 # reads only; exit 1 on a problem
econquest client-outbox reset  --sandbox [--run NAME]       # removes sandbox runs only
```

- **Test entitlements.** The file lists synthetic clients (`TEST-...` ids), their products (`country_inputs`,
  `licence_summary`), their countries and their recipients. Recipients must be reserved test addresses: example.com
  and its subdomains, `*.test` or `*.invalid`. One real-looking address, an unknown key or a non-`TEST-` id refuses
  the whole file. The sample ships as `docs/research/client-sandbox-entitlements.sample.json`, the same as the
  built-in default. The test allow-list is exactly the recipients named in the file, and the build keeps a hashed
  copy of the file.
- **Pack.** The pack goes through the existing licence rules (`presentation/licences.safe_evaluate`). Every cell that
  enforcement lists as internal-only, and every cell without a provenance record, is withheld; the value is not
  written to the file. Pages carry the attribution lines. The build refuses if the register state is drift, missing,
  symlink or chain_broken, or if the evaluation is incomplete.
- **DEMO baseline.** `--demo-baseline` opens the DEMO licence profile (EQ-C-0123) for that build only. It is accepted
  only here. Every page says "DEMO licence baseline: not Sam's approval". Outside the sandbox the DEMO profile is
  still refused by every client path.
- **Watermark.** Every page carries "SANDBOX - NOT FOR CLIENTS" in its title, a meta tag, a fixed diagonal overlay, a
  top bar and the footer. Every sent copy also carries a recipient line, plus a per-recipient sandbox id in the page
  and in an `eq-watermark-id` meta tag.
- **Distribution is a file copy.** Each recipient's copy goes to `<home>/outputs/client-outbox/<run>/<recipient>/`
  with a `manifest.json` (sha256 per file). `run.json` records the sha256 of each manifest. `verify` checks every hash
  and watermark, and reports unlisted files and symlinks. The module has no mail or network code.
- **Real use is always refused here.** Without `--sandbox`, or for an address that is not a reserved test address,
  the command refuses and names the go-live gate (`presentation/client_build.gate`: research.json mode client through
  Sam's signed `econquest change`, and licences that allow it). After a go-live, real deliveries still go only through
  `econquest client-export` (EQ-C-0107). The sandbox never writes research.json, the register, approvals or a
  credential.
- **Demo row M14 (EQ-C-0148).** It calls `client_outbox.demo_sandbox(data_dir, out_dir, entitlements=None, now=None)`.
  That builds, sends and verifies one run (on the DEMO baseline when no real baseline exists), and checks four
  refusals: real use, a non-test recipient, a recipient not on the allow-list, and DEMO outside the sandbox. It
  returns `ok` only if all of them hold.
