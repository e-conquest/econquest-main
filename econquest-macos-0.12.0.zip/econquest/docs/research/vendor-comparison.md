# Licensed market data: vendor comparison (link)

Placed by Team C (EQ-C-0114, HO-20261025-A-C-016). The page itself is Team A's EQ-A-0097 vendor comparison for Sam
and lives, with its citations and estimates, at **[`docs/runbooks/A-vendor-comparison.md`](../runbooks/A-vendor-comparison.md)**.
It is linked here, not copied, so there is one version to keep current: Team A edits it there.

Status: a proposal for Sam's decision (through AGENT-08). Nothing in it is bought, configured or enabled; no vendor
publishes a price (every cost is a labelled third-party ESTIMATE); coverage and licence tiers are UNVERIFIED until Sam
or counsel reads an order form.

Related, in this folder and Team A's:
- `docs/runbooks/A-licensed-vendors.md`: the Bloomberg/LSEG adapter framework (EQ-A-0033).
- `econquest vendor check bloomberg|lseg`: read-only readiness check, everything off (EQ-C-0108).
- `data/licences.csv`: the licence register; vendor rows change only through `econquest change` (EQ-C-0106).
- `docs/research/client-readiness.md` and `client-mode-decision-pack.md`: what client mode would need.
