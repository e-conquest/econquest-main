# Client-mode decision pack (pointer)

The decision pack for Sam's client-mode decision (yes / no / later) is Team C's
[docs/research/client-mode-decision-pack.md](../../research/client-mode-decision-pack.md) (EQ-C-0094). This file only
points to it (HO-20261025-C-B-002); the effect of client-safe inputs on the model is in
[docs/validation/client-safe-run.md](../../validation/client-safe-run.md) (EQ-B-0089, EQ-B-0096).
