# Mac-pass card set: D1 (EL options) and D2 (1.8, 1.5, 2.11 first values) (EQ-B-0113, 2026-10-25)

Team B AGENT-05. **Ready to sign during the first Mac pass** (`team/first-mac-pass.md` section B, D1 and D2). Nothing
here is posted as a card and nothing is applied. Sam picks one option per card. The command under each card carries
out the choice.

**Basis for every number.**
- The 0.7.0 shared data and settings, as_of 2026-10-23, 20,000 requested paths. Changes are made on in-memory
  copies; nothing under `data/` is written.
- The "today" row reproduces the 0.7.0 20k reference exactly: VaR99 66.956, ES99 89.000, EL 4.099, L-VaR99 72.238 $mm.
- Limits: VaR99 95, ES99 115, L-VaR99 100, EL 5 $mm. The warning level is 80%.
- Runner: `EQ-B-0113_effects.py` (EQ-B-0113 log entry).

| Card | Question | Recommended | Effect of the recommendation (20k, $mm) |
|---|---|---|---|
| D1 | EL is in the warning band (4.10 of 5). What changes? | (a) Keep, with an owner note | none; EL stays at 82% (warning) |
| D2.1 | 1.8 default record, first values | (a) as served since 2026-10-26: Zimbabwe 1 to 2, Argentina 3 to 4 (rule 16 point 3a) | none (0.000 on every metric) |
| D2.2 | 1.5 FC share of government debt | (a) Approve the rule; first values come back if they move more than 20 points | none today (held until the IDS pull) |
| D2.3 | 2.11 export concentration, first values | (a) Release the six commodity-exporter values after the pull confirms the series | VaR99 +0.094, ES99 +0.149, EL +0.014, L-VaR99 +0.094 |
| D2 together | Recommended D2 choices together | | VaR99 67.050 (+0.094), ES99 89.149 (+0.149), EL 4.113 (+0.014), L-VaR99 72.332 (+0.094); EL 82% |

---

## D1. EL in the warning band

**Question.** Book EL is 4.10 $mm against a 5 $mm limit: 82%, above the 80% warning level. Keep it, change the book,
change the measurement, or raise the limit?

**Why it is there.**
- Since 0.6.0, a bond earns no spread income on the paths where it defaults.
- P17, the 5 $mm long Venezuela Eurobond, carries 4.67 $mm of EL. Venezuela's PD is 0.99 and P17's mean LGD is at the
  95% cap.
- The rest of the book together is -0.57 $mm.
- 0.7.0 (official fx3m) added 0.02 $mm.

**Options:**
- **(a) Keep, with an owner note on P17. Recommended.** No change, so EL stays at 4.10 (82%, warning).
- **(b) Cut P17 to 2.5 $mm (a desk trade).** EL 1.76 (35%), VaR99 -2.35, ES99 -2.37.
- **(c) Remove the Merton uplift for names already in default, applied when the verified haircut fit lands
  (EQ-B-0099).** EL 2.90 (58%), VaR99 -1.12, ES99 -1.20.
- **(d) Raise the EL limit to 6 $mm.** EL use 68%, and no model number moves.

**Why (a).**
- The warning has one known cause, and it measures a position the book already holds.
- (b) is the only option that changes risk. It is a desk question about Venezuela, not a model choice.
- (c) changes the measurement on haircut evidence that is still unverified: the Cruces-Trebesch file is only on the
  Mac.
- (d) raises the yardstick to fit a better measurement, which is the pattern the PI-6 limit pack argued against.

| Option | VaR99 | ES99 | EL | L-VaR99 | P17 EL | P17 mean LGD | EL use | ES99 use |
|---|---|---|---|---|---|---|---|---|
| (a) keep (today) | 66.96 | 89.00 | 4.10 | 72.24 | 4.67 | 95% | **82% (warning)** | 77% |
| (b) P17 cut to 2.5 $mm | 64.61 | 86.63 | 1.76 | 69.70 | 2.34 | 95% | 35% | 75% |
| (b') P17 exited | 62.03 | 83.18 | -0.57 | 66.94 | 0 | n/a | -11% | 72% |
| (c) no uplift for names in default | 65.83 | 87.80 | 2.90 | 71.11 | 3.47 | 70.8% | 58% | 76% |
| (c') LGD cap 75% | 63.76 | 85.12 | 2.68 | 69.04 | 3.68 | 75% | 54% | 74% |
| (c'') LGD cap 60% | 60.05 | 81.45 | 1.55 | 65.34 | 2.94 | 60% | 31% | 71% |
| (d) EL limit 6 $mm | 66.96 | 89.00 | 4.10 | 72.24 | 4.67 | 95% | 68% | 77% |
| (d') EL limit 7 $mm | 66.96 | 89.00 | 4.10 | 72.24 | 4.67 | 95% | 59% | 77% |

Every option keeps VaR99, ES99 and L-VaR99 in the pass band. These numbers are B-0105's table restated on 0.7.0;
every row moves by less than 0.05 $mm.

**What each choice does.**

| Choice | Action | Route |
|---|---|---|
| (a) | The owner writes a note on the EL warning (P17, the 0.6.0 measurement). | none |
| (b) | Desk trade on P17. Optionally, an issuer limit for names in default. | Book change. A limit goes through `econquest change propose limits ...`, which Sam approves. |
| (c) | `econquest change propose assumptions --set /layer4/merton/uplift_in_default=false --allow-new-keys --author "Team B AGENT-05" --reason "D1 (c)"`, proposed only after EQ-B-0099's verified fit. The code is in the engine and off by default. | Tier 1 (`layer4`) |
| (d) | `econquest change propose limits --set /book/expected_loss_mm=6 ...` | Limit change, which Sam approves |

---

## D2.1. 1.8 default record: first values

**Rule.** Indicator-rules section 16, `crag_v1`:
- It counts CRAG spells overlapping 2006-2025, on default years only (`end_spell`).
- Overlapping and adjacent spells are merged into one episode.
- JPN, KOR and SGP are not served, so their seeds stay.

Team A's values (`data/mvp/gate_report.json`, all held for Tier 1 sign-off) change two seeds:
- Argentina 3 to 1.
- Zimbabwe 1 to 2.

Belize 4, Venezuela 1 and Zambia 1 are unchanged, and every other served name stays at 0.

**The catch.**
- CRAG has Argentina in default through the whole window, so `crag_v1` merges everything into one spell, which
  counts as 1.
- The rulebook asks for "restructurings or defaults". Inside that spell Argentina had the 2010 exchange, the 2014
  default and the 2020 restructuring, which is what the seed of 3 reflects.
- Rule 16 point 3 does not count restructurings inside a spell, because CRAG has no restructuring dates. For Argentina
  that understates the record, and it lowers Argentina's PD.

**Options:**
- **(a) Approve both values as the rule gives them.** Argentina's PD falls 0.57 pp (6.61% to 6.04%) and its composite
  2.4 points. VaR99 -0.010, ES99 -0.054, EL -0.029.
- **(b) Approve Zimbabwe 1 to 2; Argentina stays at 3 as a labelled reviewer hold. Recommended.** No metric moves.
- **(c) Keep both seeds.** No metric moves.

**Why (b).** The Zimbabwe value is right and harmless: its 1.8 score rises 50 to 75, but pillar 1 stays at 90, so
nothing passes through. Keeping Argentina at 3 is the prudent reading of the rulebook until a restructuring-date source
exists. Team B will amend rule 16 point 3 for countries that stay in default through the window (EQ-B-0127). No
grade changes under any option.

| Option | VaR99 | ES99 | EL | L-VaR99 | PD moves |
|---|---|---|---|---|---|
| today | 66.956 | 89.000 | 4.099 | 72.238 | |
| Argentina 3 to 1 only | 66.946 (-0.010) | 88.946 (-0.054) | 4.070 (-0.029) | 72.228 (-0.010) | ARG -0.568 pp |
| Zimbabwe 1 to 2 only | 66.956 (0) | 89.000 (0) | 4.099 (0) | 72.238 (0) | none |
| (a) both | 66.946 (-0.010) | 88.946 (-0.054) | 4.070 (-0.029) | 72.228 (-0.010) | ARG -0.568 pp |

**Addendum (EQ-B-0127, 2026-10-26).** Rule 16 now has point 3a (indicator-rules section 16): new defaults inside
one episode are dated from CRAG's own annual arrears, and no restructuring list is used. Under 3a Argentina's served
value is 4 (2001-2025 episode plus 2014, 2019 and 2023), not 1. It scores 100, like the seed of 3 (t100 = 3), so
nothing moves. If the method is approved, the D2.1 Argentina value becomes 4 with no effect, and (b)'s reviewer hold
is no longer needed. The 2023 year is flagged for the reviewer. Zimbabwe 1 to 2 is unchanged. Still a Tier 1 first-value batch.

**Commands** (on the vintage that holds the cells):
- (a): `econquest review approve Inputs 1.8 Argentina Inputs 1.8 Zimbabwe --author Sam --self-approved --note "D2.1 (a)"`
- (b): `econquest review approve Inputs 1.8 Zimbabwe --author Sam --self-approved --note "D2.1 (b)"`, then
  `econquest review approve Inputs 1.8 Argentina --decision hold --author Sam --note "D2.1 (b): CRAG merges ARG's 2010/2014/2020 events into one spell"`
- (a) or (b): finish with `econquest review apply`.

**Update (2026-10-26, Team A EQ-A-0130).** Team A has wired rule 16 point 3a into data/mvp (9cbe721d). The held
values Sam will see are now **Argentina 3 to 4** and Zimbabwe 1 to 2, not Argentina 3 to 1. Argentina 4 scores 100,
like the seed of 3, so no metric moves (20k base 66.55 / 88.44 / 4.00 / 71.83 on data/mvp before and after).
**New recommendation: (a), approve both values as served**; the (b) reviewer hold and the 3 to 1 row above are
superseded. Command: `econquest review approve Inputs 1.8 Argentina Inputs 1.8 Zimbabwe --author Sam --self-approved
--note "D2.1 (a), rule 16 point 3a"`, then `econquest review apply`. The 2023 year is still flagged for the reviewer.

---

## D2.2. 1.5 foreign-currency share of government debt

**Rule** (indicator-rules section 18, approved with changes):
- 1.5 = IDS PPG external debt stock / (WEO general-government gross debt % of GDP x GDP), same year, for the 13 IDS
  names (VNM PHL CHN IND PAK BLZ BRA ARG COL NGA SEN ZMB ZWE).
- A value below 0 or above 100 is held, never capped.
- A year more than 3 years before the as_of year is held as stale.
- A first value more than 20 points from the seed is held for Team B review.
- MYS, SGP, JPN, KOR and VEN stay manual.

**Today the cells are held.** DT.DOD.DPPG.CD has not been confirmed on any pull, so no first values exist until the
Mac pull (first-mac-pass step 12).

**Options:**
- **(a) Approve the rule now. Recommended.** First values within 20 points of seed release through the gate after the
  pull. Any name further off comes back to Team B, and then to Sam, with its effect. No effect today.
- **(b) Wait.** No rule sign-off until the first values exist; then a new card with the real effect. No effect today.
- **(c) Do not use the proxy.** 1.5 stays manual for all 18 names. No effect.

**Why (a).** The proxy measures external, not foreign-currency, debt. The 20-point hold catches exactly the names where
that difference matters, so (a) saves Sam a second card for the names that agree with their seed.

**Sensitivity** (all 13 IDS names moved together):

| 1.5 on the 13 IDS names | VaR99 | ES99 | EL | L-VaR99 |
|---|---|---|---|---|
| today (seeds) | 66.956 | 89.000 | 4.099 | 72.238 |
| seeds - 10 points | 65.280 (-1.676) | 87.205 (-1.795) | 3.815 (-0.284) | 70.562 (-1.676) |
| seeds + 10 points | 67.214 (+0.258) | 89.225 (+0.225) | 4.156 (+0.057) | 72.496 (+0.258) |

**PD change per 10 points of 1.5:**

| Senegal | Pakistan | Argentina | Zambia | Nigeria | Belize | Colombia | Brazil | Others |
|---|---|---|---|---|---|---|---|---|
| 0.16 pp | 0.13 pp | 0.11 pp | 0.09 pp | 0.06 pp | 0.06 pp | 0.02 pp | 0.01 pp | under 0.01 pp |

No grade changes. The loss moves are not symmetric: most of the downside comes through severity and the stress-path
FX revaluation, not through PD.

**Commands.**
- (a): nothing now. After the pull, `econquest review list --pending` shows the 1.5 cells. Approve those within 20
  points with `review approve Inputs 1.5 <country> ... --author Sam --self-approved`, then `review apply`.
- (c): `review approve ... --decision reject`.

---

## D2.3. 2.11 export concentration: first values

**Rule** (indicator-rules section 15). Each country uses its latest WDI year with all five groups:
1. If the groups cover less than 75% of exports, the cell is held.
2. If manufactures is the largest group, the cell is blank and the seed stays.
3. Otherwise the value is the largest commodity group.

Under this rule:
- Six cells move: Belize 95.34, Brazil 40.73, Colombia 34.90, Nigeria 85.90, Senegal 32.71, Zambia 72.99.
- Argentina and Zimbabwe are held by the coverage floor, and Venezuela is held as stale.
- The nine manufacturers keep their seeds.

Today every 2.11 cell is also held as "unverified" (series codes not yet confirmed on a live pull), so release follows
the Mac pull.

**Options:**
- **(a) Release the six values on the first pull that confirms the series codes. Recommended.** VaR99 +0.094,
  ES99 +0.149, EL +0.014, L-VaR99 +0.094. EL stays at 82%.
- **(b) Release the six now, without waiting for the series-code check.** Same effect, but on series not yet confirmed
  live.
- **(c) Keep all seeds.** No effect.

**Why (a).** The rule keeps the indicator only where the WDI groups measure what the rulebook asks, so it beats both
Team A's raw proxy and the seeds. Waiting for the code check costs nothing, because the values come in the same pull.

**Effect per cell** (one at a time, then together):

| 2.11 cell | Seed to value | VaR99 | ES99 | EL | L-VaR99 | PD move |
|---|---|---|---|---|---|---|
| Belize | 50 to 95.34 | +0.001 | +0.000 | +0.002 | +0.001 | +0.067 pp |
| Brazil | 15 to 40.73 | +0.094 | +0.160 | +0.005 | +0.094 | +0.018 pp |
| Colombia | 40 to 34.90 | 0 | -0.012 | -0.001 | 0 | -0.004 pp |
| Nigeria | 85 to 85.90 | 0 | 0 | 0 | 0 | none (scores 100 either way) |
| Senegal | 25 to 32.71 | +0.001 | +0.001 | +0.009 | +0.001 | +0.114 pp |
| Zambia | 75 to 72.99 | -0.000 | -0.000 | -0.001 | -0.000 | -0.009 pp |
| **(a) all six** | | **+0.094** | **+0.149** | **+0.014** | **+0.094** | as above |

- Brazil carries the VaR99 and ES99 move. 2.11 also feeds the stress-path export shock and the commodity signal, so
  its effect is larger than the 0.018 pp PD change.
- No grade changes.

**Command** (on the post-pull vintage):
`econquest review approve Inputs 2.11 Belize Inputs 2.11 Brazil Inputs 2.11 Colombia Inputs 2.11 Nigeria Inputs 2.11 Senegal Inputs 2.11 Zambia --author Sam --self-approved --note "D2.3 (a)"`,
then `econquest review apply`. Leave the other twelve 2.11 cells on seed.

---

## D2 together

| D2 set | VaR99 | ES99 | EL | L-VaR99 | EL use |
|---|---|---|---|---|---|
| today | 66.956 | 89.000 | 4.099 | 72.238 | 82% |
| **Recommended: 1.8 Zimbabwe + 2.11 six (1.5 none yet)** | **67.050 (+0.094)** | **89.149 (+0.149)** | **4.113 (+0.014)** | **72.332 (+0.094)** | **82%** |
| As proposed: 1.8 both + 2.11 six | 67.012 (+0.056) | 89.101 (+0.101) | 4.084 (-0.015) | 72.294 (+0.056) | 82% |

- The D2 choices are independent of D1. With D1 (a), EL stays in the warning band under every D2 option.
- Each row is its own run, not a sum of the per-item rows.
- 1.5 adds nothing until its first values exist (D2.2).
- Each D2 choice is reversible: revert the cells to seed.
- Licences: CRAG (BoC-BoE, open), WDI (open), IDS (open) and WEO. A 1.5 value carries a WEO input, so it is
  `imf_derived` and restricted from client output.
