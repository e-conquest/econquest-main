# Decision pack (PARKED, Tier 1): refit of the restructuring haircut model on Cruces-Trebesch (EQ-B-0104)

Team B AGENT-02, 2026-10-25. Status: **parked**. No card for Sam until every MVP row passes (PI-10 rule). Nothing here
changes a setting, an engine default or a published number. The restructuring module is off by default and outside the
base run, so the base (0.6.0) is unaffected whichever option is chosen.

This pack quotes **no value from the Cruces-Trebesch (CT) workbook**. Its licence is UNVERIFIED (licence register row
`cruces_trebesch_haircuts`: no terms found, internal use yes, client output restricted), so the workbook and anything
read from it stay off the shared folder. Counts of cases and the typed-in comparison are in Team A's runbook
`docs/runbooks/A-haircuts.md` (sections 4 to 6, provisional). The effect table below is filled only when Team A
promotes the file on the shared side after AGENT-08 says go.

## Where things stand

- `engine/restructuring.py` fits the haircut on 17 exchanges typed from memory (`REFERENCE_RESTRUCTURINGS`), labelled
  UNVERIFIED in every output. `haircut_source` switches to `data/panel/cruces_trebesch_haircuts.csv` when that file
  exists. It marks the calibration verified only when the file is real, the licence register row matches it
  (internal_use yes) and a provenance sidecar holds the file's sha256.
- Team A's adapter (`ingestion/research/haircuts.py`, EQ-A-0098) writes that file in the contract of A-haircuts.md
  section 4. Team B confirms the contract (HO-20261025-A-B-007, accepted by B/AGENT-02). `layer4_severity.HAIRCUT_COLUMNS` and
  `restructuring.load_ct_haircuts` both read `debt_restructured_mm`; tests use synthetic rows only.
- The typed-in comparison (A-haircuts.md section 6, provisional): about half of the 17 typed rows have a CT case, and
  every typed range that has one contains the CT value; the rest are after CT's end year or out of its scope (the list
  and the two-case ties are in section 6).
- The current regression needs debt/GDP at default. CT carries none, the adapter fills it only from a named source,
  and the hazard panel has no rows for the years before CT exchanges (default years are not in the panel). So a
  debt/GDP regression on CT is not possible today; `haircut_source` falls back to the typed table and says why.

## Questions for Sam (Tier 1)

### Q1. Bank cases or bond cases only?

CT covers restructurings with foreign banks (mostly 1980s-1990s London Club and Brady deals) and bond exchanges
(mostly from 1998). The book holds Eurobonds and CDS.

- (a) **Bond only.** Same instrument as the book. Few cases.
- (b) All cases, with a bank/bond indicator in the fit. More data; bank deals differ in creditor structure.
- (c) All cases pooled. Most data; mixes instruments.

Recommendation: (a) for the central haircut, with (b) reported as a sensitivity.

### Q2. Window and weights

- (a) Bond era only (exchange year 1998 onward). (b) Full CT window. (c) Full window with weights falling with age.
- Weights: equal per exchange (recommended), or by debt restructured (`debt_restructured_mm`). Debt weights let one
  or two very large exchanges dominate the mean.

Recommendation: (a) with equal weights; debt-weighted mean reported next to it.

### Q3. Exchanges after CT's end year

CT stops before the 2020-2024 wave (Argentina and Ecuador 2020, Zambia, Sri Lanka, Ghana and Ukraine 2024, Belize 2021).

- (a) Keep the typed-in ranges for those exchanges, labelled UNVERIFIED, beside CT. The calibration stays unverified.
- (b) CT only until the 200-year dataset (Meyer, Reinhart and Trebesch) is available; its file and terms are UNVERIFIED and
  it would need its own adapter.
- (c) Type the post-2013 cases from official exchange documents (finance ministry offer memoranda, IMF programme reviews),
  each with its document reference, as a separate sourced table.

Recommendation: (c) as the next step, (a) until then.

### Q4. Debt/GDP rule (and whether to keep a regression at all)

- (a) Drop the regression: central haircut = empirical distribution of bond-exchange SZ haircuts (mean, sd, quantiles),
  with the judgement rating and reserves add-ons kept and labelled. No debt/GDP needed.
- (b) Keep the debt/GDP regression with a sourced debt series at the year before the exchange: IMF Historical Public
  Debt Database (internal only, EXC-003), WDI GC.DOD.TOTL.GD.ZS (central government; gaps for the 1980s and 1990s) or
  Reinhart-Rogoff (terms to check). The adapter uses year-1 only; `restructuring.ct_reference` also tries the exchange
  year. One rule for both is needed (recommended: year-1 only).
- (c) (a) now, (b) when a sourced debt table is in the shared folder.

Recommendation: (c).

## Effect table (to fill on the shared side when the file is promoted)

Restructuring stress, as_of 2026-10-23, top-PD names with bonds, 100,000 paths. Today (typed-in, UNVERIFIED): book
restructuring loss 13.40 $mm (range 7.77-19.02) against a model default loss of 29.69 $mm (0.5.0 base; to be rerun on
0.6.0).

| Option set | central haircut | book restructuring loss | low / high | VaR99 / ES99 with restructuring severity |
|---|---|---|---|---|
| typed-in (today) | name-specific, 0.32-0.62 | 13.40 | 7.77 / 19.02 | rerun on 0.6.0 |
| Q1a + Q2a + Q4a | to fill | to fill | to fill | to fill |
| Q1b + Q2b + Q4a | to fill | to fill | to fill | to fill |
| Q4b (if a debt table exists) | to fill | to fill | to fill | to fill |

## Steps once decided

1. Team A promotes `data/panel/cruces_trebesch_haircuts.csv` + sidecar (A-haircuts.md, AGENT-08 go).
2. Team B adds the chosen filter (debt_type, window) and, for Q4a, an empirical-distribution model to
   `restructuring.py` behind a setting read with a default (off), with tests on synthetic rows.
3. Rerun the restructuring headline at 100k on the current base, fill the table, update
   docs/validation/restructuring.md. The UNVERIFIED label goes only if every figure used comes from a registered,
   hashed file.
