# Decision pack: distressed LGD cap in layer 4 (EQ-B-0097, 2026-10-25)

Team B AGENT-05. All numbers: release 0.5.0 base (FX-only official prices), as_of 2026-10-23, 100,000 paths
requested, seed 7, temporary settings copies only. No setting or engine default was changed.

## Question

Should a distressed sovereign's expected loss given default stay capped at 95%, or be capped lower?

## Why it matters

The mean LGD of a hard-currency bond or CDS is `market.lgd_hard` 60% x the regime multiplier (1.02 Calm, 1.09
Stressed, 1.18 Crisis) plus the Merton uplift (`layer4.merton.lgd_per_sigma` 0.10 per sigma of distance to distress
below 2.0), clipped to 5-95% (`layer4_severity.LGD_BOUNDS`). For four positions the sum reaches or nears the cap:

| Position | Name | Regime | 60% x mult | Merton uplift | Sum | Mean LGD used |
|---|---|---|---|---|---|---|
| P17 Eurobond, 5 $mm long | Venezuela (in default) | Crisis | 70.8% | 72.9 pp | 143.7% | **95%** (capped) |
| P14 Eurobond, 15 $mm long | Argentina | Stressed | 65.5% | 34.0 pp | 99.5% | **95%** (capped) |
| P15 CDS protection, 10 $mm | Argentina | Stressed | 65.5% | 34.0 pp | 99.5% | **95%** (capped) |
| P20 Eurobond, 8 $mm long | Senegal | Crisis | 70.8% | 24.8 pp | 95.6% | **95%** (capped) |
| P10 Eurobond, 10 $mm long | Pakistan | Stressed | 65.5% | 27.6 pp | 93.1% | 93.1% |

Published sovereign bond exchanges imply market haircuts of about 20-70%, mostly 30-60% (17 exchanges in
`docs/validation/restructuring.md`, e.g. Ecuador 2020 25-40%, Sri Lanka 2024 30-45%, Greece 2012 60-70%). **Those
reference figures were typed from the literature and are unverified until EQ-B-0099** refits the haircuts. The
Venezuela uplift is also odd on its own terms: the name is already in default (PD 0.99), and the uplift then adds
73 pp on top of the Crisis multiplier.

## Options

- **(a) Keep** the 95% cap. Today.
- **(b) Cap the mean LGD at 75%** for every hard-currency bond and CDS (`layer4.lgd_cap` 0.75). Moves P10, P14, P15,
  P17 and P20.
- **(c) No Merton uplift for a name already in default** (`layer4.merton.uplift_in_default` false). Only Venezuela
  (P17) moves: 95% to 70.8%.

## Effect (100,000 paths, as_of 2026-10-23)

Book limits: VaR99 95, ES99 115, L-VaR99 100, EL 5 $mm. The second block assumes pack 2 option (c), zero spread
income on default paths, because with today's income treatment a lower LGD makes EL negative.

| Option | Income on default paths | VaR99 | ES99 | EL | L-VaR99 | VaR99 use | ES99 use | Stress ES99 A | FED22 | MACRO_WAR_ASIA | Scenarios with ES99 > 115 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| (a) keep (today) | kept | 58.19 | 78.72 | 0.88 | 63.47 | 61% | 68% | 131.4 | 147.6 | 149.1 | 14 of 17 |
| (b) cap 75% | kept | 54.56 (-6.2%) | 74.82 (-5.0%) | **-0.54** | 59.84 | 57% | 65% | 126.0 | 142.4 | 143.8 | 14 of 17 |
| (c) no uplift in default | kept | 57.15 (-1.8%) | 77.54 (-1.5%) | **-0.32** | 62.43 | 60% | 67% | 130.2 | 146.4 | 147.9 | 14 of 17 |
| (a) keep | zero | 62.97 | 83.58 | 4.09 | 68.25 | 66% | 73% | 139.1 | 155.9 | 158.9 | 14 of 17 |
| (b) cap 75% | zero | 59.12 (-6.1%) | 79.65 (-4.7%) | 2.67 | 64.40 | 62% | 69% | 133.6 | 150.7 | 153.5 | 14 of 17 |
| (c) no uplift in default | zero | 61.76 (-1.9%) | 82.40 (-1.4%) | 2.89 | 67.04 | 65% | 72% | 137.9 | 154.7 | 157.7 | 14 of 17 |

Changes in brackets are against (a) in the same block. A negative EL means the book is expected to make money over
the year after defaults; it comes from spread income counted on default paths (pack 2), not from the LGD itself.

## Recommendation: (a), keep the 95% cap for now; decide again with EQ-B-0099

The case for a lower cap rests on haircut figures that are not verified yet, and both alternatives lower every
risk number. (b) is a judgement number (75%) that would replace another judgement number (95%). (c) is the more
targeted fix, and it is defensible: a name in default has a market price that already reflects recovery, and the
Merton uplift is a distance-to-distress signal for names not yet in default. But it moves one 5 $mm position
by -1.9% VaR99. Team B suggests: keep (a) now, decide pack 2 first, and bring (b) and (c) back with EQ-B-0099's
verified haircut fit, which will give a data-based cap or a fitted distressed LGD instead.

## What each option means

| Option | Change | Tier |
|---|---|---|
| (a) | None | n/a |
| (b) | Code: `expected_lgd` takes a `cap`, and `haircut_distribution` passes `layer4.lgd_cap` (default none = today's 0.95; diff in `B-0097-engine-options.diff`, layer4 hunks). Then `econquest change propose` on `data/assumptions.json`: `/layer4/lgd_cap` = 0.75 (new key, `--allow-new-keys`) | 1 (`layer4` section) |
| (c) | Code: `build_positions` reads `layer4.merton.uplift_in_default` (default true = today) and drops the uplift for a country with `default` true (layer6 hunks 2 and 3; layer6 is a shared file, AGENT-08 applies). Then propose `/layer4/merton/uplift_in_default` = false (new key) | 1 (`layer4` section) |

With the keys absent the base is bit-identical (checked at 20,000 paths). Equity expropriation severities have their
own 95% cap inside `gpd_severity` and are not part of this decision.

## Draft card

**Question:** Should distressed bond LGDs stay capped at 95%, or lower?

**Options:**
1. Keep 95% (recommended for now): no change; decide again with the verified haircut fit (EQ-B-0099).
2. Cap at 75%: VaR99 -6.1%, ES99 -4.7% (with zero income on default paths).
3. No Merton uplift for names in default: only Venezuela moves; VaR99 -1.9%.

**Context:** Hard-currency LGD is 60% x regime multiplier + Merton uplift, capped at 95%. Venezuela, Argentina
(bond and CDS) and Senegal sit at the cap; Pakistan at 93%. Published bond exchanges imply about 30-60% haircuts,
but those reference figures are unverified until EQ-B-0099. Venezuela is already in default and still gets a 73 pp
uplift. Both alternatives lower every risk number. If spread income stays on default paths (pack 2), a lower LGD
makes EL negative, so decide that card first. Tier 1 (layer4). 100k paths, as_of 2026-10-23.
