# Parked decision pack: EL in the warning band (EQ-B-0105, 2026-10-25)

Team B AGENT-05. **Parked: not a card.** It is written for later, when Sam is ready (PI-10 rule: no decisions asked of
Sam until the MVP rows pass). Nothing here changes a setting, a limit or a position. The MVP runs on the approved
0.6.0 settings (CHG-20261025T131946Z-40d55f).

All numbers: 0.6.0 base, as_of 2026-10-23, 20,000 requested paths, seed 7, temporary copies of the settings and the
book. The "keep" row equals the 20k reference (66.95418376040001 / 88.96422619307229 / 4.081232295575317 /
72.23568958711236). Option (c) runs use the EQ-B-0097 option code, off by default.

## Question

Book expected loss (EL) is 4.08 $mm against a 5 $mm limit: 82%, above the 80% warning level. What, if anything,
should change?

## Why it is in the warning band

Since 0.6.0 a bond earns no spread income on the paths where it defaults (pack B-0097 2, approved). That exposed
one position:

- **P17, Venezuela Eurobond, 5 $mm long.** Venezuela is in default (PD 0.99, Crisis regime). Its mean LGD is at the
  95% cap: 60% x 1.18 Crisis multiplier = 70.8%, plus a 72.9 pp Merton uplift.
- P17 alone carries **4.67 $mm** of EL. The rest of the book together is **-0.59 $mm**: spread income on the
  surviving paths is larger than the expected default loss of the other positions.
- So the warning is one name. It is a measurement of a position the book already holds, not a new trade.

## Options

- **(a) Keep as is.** Leave the limit, the model and the book. The warning stays; the owner writes a note that it
  comes from P17 and the 0.6.0 measurement change.
- **(b) Cap the Venezuela position.** A desk action: cut P17 to 2.5 $mm, or exit it. Could be written as an issuer
  limit for names in default (for example 2.5 $mm notional) in `limits.json`.
- **(c) Cap the distressed LGD, once the haircuts are verified.** Pack B-0097 3 (parked until EQ-B-0099 verifies the
  haircut reference table). Three forms are shown: no Merton uplift for a name already in default
  (`layer4.merton.uplift_in_default` false), or a mean-LGD cap of 75% or 60% (`layer4.lgd_cap`). The 60% is the top
  of the 30-60% range that published exchanges imply. Those reference figures are **unverified** until EQ-B-0099.
- **(d) Raise the EL limit.** 5 to 6 $mm (EL use 68%) or 7 $mm (58%). No model number changes.

## Effect (20,000 paths, as_of 2026-10-23)

Limits: VaR99 95, ES99 115, L-VaR99 100, EL 5 $mm; warning at 80%.

| Option | VaR99 | ES99 | EL | L-VaR99 | P17 EL | P17 mean LGD | EL use | ES99 use |
|---|---|---|---|---|---|---|---|---|
| (a) keep (today) | 66.95 | 88.96 | 4.08 | 72.24 | 4.67 | 95% | **82% (warning)** | 77% |
| (b) P17 cut to 2.5 $mm | 64.61 | 86.60 | 1.75 | 69.70 | 2.34 | 95% | 35% | 75% |
| (b) P17 exited | 61.96 | 83.12 | -0.59 | 66.87 | 0 | n/a | -12% | 72% |
| (c) no uplift for names in default | 65.83 | 87.77 | 2.88 | 71.11 | 3.47 | 70.8% | 58% | 76% |
| (c) LGD cap 75% | 63.74 | 85.08 | 2.66 | 69.02 | 3.68 | 75% | 53% | 74% |
| (c) LGD cap 60% | 60.01 | 81.42 | 1.54 | 65.29 | 2.94 | 60% | 31% | 71% |
| (d) EL limit 6 $mm | 66.95 | 88.96 | 4.08 | 72.24 | 4.67 | 95% | 68% | 77% |
| (d) EL limit 7 $mm | 66.95 | 88.96 | 4.08 | 72.24 | 4.67 | 95% | 58% | 77% |

Every option keeps VaR99, ES99 and L-VaR99 in the pass band. A negative EL (P17 exited) means the rest of the book is
expected to earn more spread income than it loses to defaults over the year.

## Assessment

- **(a)** is honest and costs nothing. The warning band exists to make the owner look, and the cause is known. A
  warning is not a breach. The risk: a standing warning that everyone learns to ignore.
- **(b)** is the only option that changes the risk rather than the measurement. It is a trading decision for the desk,
  not a model choice. Cutting to 2.5 $mm takes EL to 35%.
- **(c)** changes the measurement on evidence that is not verified yet. "No uplift in default" is the most targeted:
  a defaulted bond's price already reflects expected recovery, and the Merton uplift is a distance-to-distress
  signal meant for names not yet in default. It should come back with EQ-B-0099's verified haircut fit, not before.
- **(d)** moves the yardstick to fit the measurement. The 5 $mm EL limit was set when the model netted default loss
  against income it would not get (before 0.6.0), so a restatement has some basis. But it was signed by Sam
  (PI-6 pack 1, GOV-041), and raising a limit because a better model measures more is the pattern that pack argued
  against.

## Team B view (for later, not a card)

Keep (a) now, with an owner note on P17. Bring (c) "no uplift for names in default" back with EQ-B-0099. Treat (b) as a
desk question about Venezuela, separate from the model. Do not raise the limit (d).

## What each option means

| Option | Change | Tier / route |
|---|---|---|
| (a) | Owner note on the EL warning (P17, 0.6.0 measurement change) | none |
| (b) | Desk trade on P17; optionally an issuer limit for names in default in `data/limits.json` | limit change: `econquest change propose` on `limits.json`, Sam approves |
| (c) | `econquest change propose` on `data/assumptions.json`: `/layer4/merton/uplift_in_default` false, or `/layer4/lgd_cap` 0.75 / 0.60 (new keys, `--allow-new-keys`; code already in the engine, off by default) | Tier 1 (`layer4`), after EQ-B-0099 |
| (d) | `econquest change propose` on `data/limits.json`: `/book/expected_loss_mm` 6 or 7 | limit change, Sam approves |

Reproduce: the runner is in the EQ-B-0105 log entry (20k, as_of 2026-10-23; book copies with P17 at 2.5 and removed).
