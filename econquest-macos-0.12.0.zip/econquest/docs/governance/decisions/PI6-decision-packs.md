# PI-6 decision packs for Sam (EQ-B-0069, 2026-10-24)

There are three decisions. Each has one page: the question, the facts, the options and Team B's recommendation.
All numbers come from the 0.2.1 base `20261024T111621-base` (as_of 2026-10-23, 100,000 paths requested).

---

## 1. ES99 limit band

**Question.** Should the book limits stay at VaR99 95, ES99 115 and L-VaR99 100 $mm, with the warning at 80%?
The alternative is to rescale them for the 0.2.1 model change.

**Facts.**
- Book ES99 utilisation by release:

  | Release | ES99 ($mm) | Utilisation | Band |
  |---|---|---|---|
  | 0.1.3 | 83.0 | 72% | pass |
  | 0.1.4 | 96.5 | 84% | warning |
  | 0.1.5 / 0.2.0 | 95.4 | 83% | warning |
  | 0.2.1 | 89.3 | 78% | pass |

  The 0.2.1 headroom to the 80% warning level is 2.7 $mm, which is about 8 Monte Carlo SE (SE 0.33).
- **The drop in 0.2.1 is a measurement change, not a change in risk.** The book did not change. The model
  stopped counting default losses twice (GOV-047). VaR99 went 73.1 to 67.4 and L-VaR99 went 78.4 to 72.7.
- **Stress ES99 is far above the limit in 7 of 10 scenarios:** 143 to 162, against a limit of 115.
- Limits are owner-set and not yet signed (GOV-041). A pre-trade check at 20,000 paths has a 2 SE of about 1.6 $mm ES99.

**Options.**
- **(a) Keep 95 / 115 / 100 and the 80% warning.** This accepts that the same book now uses less of its limit.
  Tail appetite in dollars stays the same, and the model now measures the tail more accurately.
- **(b) Rescale by the model change** to VaR99 88, ES99 108 and L-VaR99 93. Utilisation is unchanged, so ES99
  stays at 83%, in the warning band. This keeps appetite fixed relative to the old measure, which double-counted
  default losses.
- **(c) Keep the limits and lower the warning level to 75%.** ES99 becomes a warning again. This keeps the earlier
  behaviour without restating the limits.

**Decided 2026-10-24 12:38Z: (a).** limits.json is baselined with Sam as approver (sha256 19a0158c…, chain ok); GOV-041 resolved.

**Recommendation: (a).** The old measure overstated the tail by a known amount. Rescaling the limits to that
error would carry it forward. Sign the limits as they stand (this closes GOV-041) and record in the limit file
that utilisation fell because of CHG-20261024T111531Z-dd6de0, not because of trading. Any limit change goes
through `econquest change` on `limits.json`.

---

## 2. Layer 1 calibration set

**Question.** Should layer 1 calibrate only on the 18 desk names (`layer1.calibration_universe`)? Today it
calibrates on every country in the universe.

**Facts.**
- **Today this changes nothing.** The shipped universe is the 18 desk names. At 20,000 paths, VaR99 is
  67.2808 both ways, and the largest PD difference is 0.0.
- **When the universe is promoted to the approved 88 countries, it matters.** On the 88-country scratch copy,
  the default calibration (over every country) moved desk PDs by up to 11 pp (Zimbabwe), driven by
  placeholder ratings on the new names. Pinned to the 18 desk names, desk PDs were bit-identical
  (EQ-B-0034, `docs/validation/scorecard.md`).
- Calibration is cross-sectional, so adding countries changes desk PDs even when no position changes.
- **The change is already proposed:** CHG-20261024T122445Z-5753a1 (Tier 1, adds the 18 names).

**Options.**
- **(a) Pin to the 18 desk names now.** Approve CHG-20261024T122445Z-5753a1. Promotion then cannot move desk
  PDs through calibration. Widening the set later is its own decision, once ratings and data for the new names
  are real.
- **(b) Leave it unpinned.** Promotion recalibrates on all 88, and desk PDs move with the new names' data quality.
- **(c) Decide at promotion time.** Leave it unpinned for now and take the decision when the 88-country data is real.

**Decided 2026-10-24 12:38Z: (a).** CHG-20261024T122445Z-5753a1 is approved and applied (chain ok); VaR99 at 20,000 paths is 67.2808 before and after.

**Recommendation: (a).** It is free today, and it removes an 11 pp risk from the promotion step. To approve:
`econquest change approve CHG-20261024T122445Z-5753a1 --approver Sam`, then `econquest change apply CHG-20261024T122445Z-5753a1`.
Team B can do both after you choose it on the card.

---

## 3. EXC-001 (single-operator approvals)

**Question.** How should single-person approvals be covered from now on?

**Facts.**
- **What EXC-001 covers today:** Sam may self-approve two data-gate actions, releasing held cells and
  `fetch --apply --force`.
  - Compensating controls: a `self_approved` flag on each ledger row, approvals bound to the vintage they
    release, pre-apply snapshots, and each use counted in revalidation.
  - Expiry: when a second approver is named, or 2027-01-22, whichever is first.
- **Scope mismatch.** `change-control.md` (line 10) and `model-risk-policy.md` (line 79) also cite
  `--self-approved --exc EXC-001` for Tier 1 parameter changes. EXC-001's text does not cover parameter changes.
  - No self-approved parameter change has been used so far. Every Tier 1 change was approved as "Sam" from a
    decision card, which is still one person deciding.
- The 0.1.5 notes also ask for a dedicated EXC id before the first compliance self-sign (Team C).

**Options.**
- **(a) Log EXC-002** for single-operator approval of Tier 1 model and limit changes, with its own controls:
  - the decision card or message is cited in the change record;
  - the independent validator reviews every self-approved change at the next validation cycle;
  - expiry is the same as EXC-001.

  Keep EXC-001 as written, and point the two documents at EXC-002 for parameter changes. Give compliance
  self-sign its own id (EXC-003) when Team C needs it.
- **(b) Widen EXC-001** to cover data-gate, parameter and limit approvals in one exception. This is simpler, but
  one exception then covers different risks.
- **(c) Name a second approver now**, for example the external validator under the engagement pack or a
  colleague. This ends the need for an exception, but depends on someone being available.

**Decided 2026-10-24 12:31Z: (a).** EXC-002 is logged in issues-log.md, and change-control.md and model-risk-policy.md now cite it.

**Recommendation: (a).** Separate exceptions keep the audit trail clear about what was self-approved and why.
Team B drafts the EXC-002 row and fixes the two documents' references when you choose it. The expiry date
(2027-01-22) is the natural point to revisit (c).
