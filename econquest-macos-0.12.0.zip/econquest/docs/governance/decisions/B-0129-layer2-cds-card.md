# Tier 1 card: layer 2 reads vendor CDS curves (`probability.market_term`) (EQ-B-0129, 2026-10-26)

Team B AGENT-05. **Parked.** Not posted and not proposed, and nothing is applied. It is ready to sign once D5 in
`team/first-mac-pass.md` section B has given a desk seat, and once Team A has approved the licence register row for
that vendor. Until both have happened, the only right answer is (a). The lead adds the card to `team/when-sam-is-ready.md`.

**Every number below is a FIXTURE effect.** The curves are synthetic vendor-shaped quotes from
`tests/fixtures/market/vendor_cds_layer2_fixture.csv`, covering 7 countries. They are not market data. They show
the mechanism, and the size it can have. They are not the effect the real curves will have. Before signing, the
card is re-run on the first real snapshots (see "Before signing").

**How the numbers were made.**
- Basis: the 0.7.0 shared data and settings, as_of 2026-10-23.
- Command: `python -m econquest.validation.layer2_cds_e2e --paths 20000` (and `--paths 100000`).
- What it runs: the whole pipeline on a temporary copy of `data/`. The fixture is saved into that copy's market
  store and read back through `store.gated_market_history` and `cds_curves`, then layer 2, then layers 3 to 6.
- The fixture licence id is approved only in a temporary copy of the register.
- The "today" rows reproduce the 0.7.0 base exactly. The shared data hash, 308b73ca9e257627, is the same before and
  after the run.

## Question

Should layer 2's market term read the vendor's CDS curves instead of the Country Profile `spread`, for countries
whose curve passes every guard? Countries without a usable curve keep the profile spread.

## Options

- **(a) Keep the profile spread (today). Recommended until there is a licence and a real snapshot.** No change.
- **(b) CDS curves, 5-year par spread.** Set `probability.market_term = {"source": "cds_curves"}`. The curve's 5y
  spread replaces the profile spread in the same `spread / LGD / k` formula. Recommended once (b) has been re-run on
  real curves and the gaps below are closed.
- **(c) CDS curves, 1-year hazard.** Set `{"source": "cds_curves", "measure": "hazard_1y"}`. The curve's 1-year
  risk-neutral hazard replaces `spread / LGD`. Curve shape and quote recovery then matter.

## Effect on the fixture ($mm; limits VaR99 95, ES99 115, L-VaR99 100, EL 5)

| Option | Paths | VaR99 | ES99 | EL | L-VaR99 | EL use |
|---|---|---|---|---|---|---|
| (a) today | 20k | 66.956 | 89.000 | 4.099 | 72.238 | 82% (warning) |
| (b) 5y spread | 20k | 67.196 (+0.240) | 89.256 (+0.256) | 4.154 (+0.055) | 72.478 (+0.240) | 83% (warning) |
| (c) 1y hazard | 20k | 66.801 (-0.155) | 88.297 (-0.703) | 4.284 (+0.185) | 72.083 (-0.155) | 86% (warning) |
| (a) today | 100k | 66.780 | 88.482 | 4.104 | 72.062 | 82% (warning) |
| (b) 5y spread | 100k | 67.021 (+0.241) | 88.721 (+0.240) | 4.160 (+0.057) | 72.303 (+0.241) | 83% (warning) |
| (c) 1y hazard | 100k | 66.461 (-0.319) | 87.873 (-0.608) | 4.288 (+0.184) | 71.742 (-0.319) | 86% (warning) |

PD moves, in percentage points, for the 7 fixture countries (100k). Each of the other 11 countries moves 0.000.

| Country | Profile bp | Fixture 5y bp | PD today | (b) | (c) | Move (b) | Move (c) |
|---|---|---|---|---|---|---|---|
| Vietnam | 100 | 110 | 0.36% | 0.38% | 0.28% | +0.02 | -0.08 |
| Philippines | 65 | 70 | 0.35% | 0.37% | 0.26% | +0.01 | -0.09 |
| Brazil | 160 | 180 | 1.12% | 1.19% | 0.84% | +0.07 | -0.28 |
| Pakistan | 450 | 480 | 8.11% | 8.36% | 10.02% | +0.26 | +1.92 |
| Argentina (fixture recovery 0.25) | 650 | 700 | 6.61% | 6.86% | 7.68% | +0.25 | +1.07 |
| Nigeria | 400 | 420 | 3.99% | 4.08% | 3.44% | +0.10 | -0.54 |
| Zambia | 450 | 460 | 4.66% | 4.71% | 4.99% | +0.05 | +0.34 |

**What the fixture shows.**
- (b) passes the 5y spread difference through `w_m` 0.5, so each PD moves in proportion to that difference.
- (c) also responds to curve shape:
  - upward curves (VNM, PHL, BRA, NGA) give a lower 1-year PD;
  - inverted curves (PAK, ARG, ZMB) give a higher one;
  - a quote recovery below 0.40 (ARG) raises the hazard.
- Book VaR99 and ES99 can therefore move either way under (c).

## Guards, each run end to end on the same copy

| Guard | Case | Result |
|---|---|---|
| Switch off | Store present, shipped settings | Identical to the base (the store is not read) |
| Licence row | (b) setting with the shipped register: the bloomberg row's terms_verified is UNVERIFIED | 0 curves used ("licence not approved"); identical to the base |
| Synthetic marker | The exact live setting (b) with the fixture licence approved | 0 fixture curves used ("synthetic or unverifiable curve"); identical to the base |
| Staleness | `max_age_days` 0 against a curve 1 day old | 0 curves used; identical to the base |
| Point in time | A revised capture (+200 bp) saved 2026-10-24 | Not seen at as_of 2026-10-23; identical to (b) |
| Point in time | First capture saved after the as_of date | The run stops (FileNotFoundError); no silent fallback |
| Market gate | A next-day VNM capture with a 5y jump (110 to 900 bp, non-monotone curve) | The gate holds it and the VNM series is dropped whole; VNM uses the profile spread; the issue is reported |
| publish_guard | Country table under (b) (licence scope desk-internal) | Refused for all 7 countries; the base table passes |

All 9 checks pass at 20k and at 100k. The checks are also tests (`tests/test_layer2_cds_e2e.py`).

## Going live is config only

The guards above are all built and tested, and nothing in the code changes. Going live takes two config steps and
no code:
1. **Team A, through `econquest change`:** the register row of the contracted vendor in `data/licences.csv` gets
   `terms_verified` "yes", once the contract has been read. Mac step 5 baselines the register first.
   `client_output` stays "barred" until there is a redistribution licence.
2. **Sam, this card:**
   `econquest change propose assumptions.json --set '/probability/market_term={"source": "cds_curves"}' --allow-new-keys --author "Team B AGENT-05" --reason "B-0129 option (b)" --tier 1`,
   then approve and apply.

Test `test_going_live_is_config_only` shows this:
- Curves with no SYNTHETIC/FIXTURE/TEST marker, kept in a temporary store, are refused under the exact live setting
  while the shipped register is in force.
- After the one-field register change, the same curves are used for all 7 countries.
- The change touches nothing else, and `publish_guard` still refuses desk-internal values.

The fixture cases differ from the live setting only in `allow_synthetic` (`live_config_diff`). That switch is
test-only and defaults to false.

The desk callers now pass the data folder, so they keep working with the switch on (EQ-B-0129):
- the daily record;
- the monitoring challengers;
- the pre-trade check;
- attribution and what-if;
- the restructuring stress.

`econquest run` and the reverse stress already did.

## Before signing (open items)

- **Re-run on real curves.** Run `layer2_cds_e2e` against the first real snapshot. The harness has to be pointed at
  the real store instead of the fixture; that switch is not yet built, a small follow-up. Replace the tables above
  with the result.
- **Team C (HO-20261026-B-C-006, EQ-B-0129):**
  - `cli.cmd_limits` passes `market_dir=args.data` to `pretrade_check`;
  - `presentation/api.py` and `country_note.py` pass `market_dir`;
  - `publish` calls `publish_guard`.
- **Fail closed by design.** With the switch on, these callers stop rather than read vendor data or seed spreads:
  `replicate`, `research_effect`, `hazard_refit`, `activation`, `client_safe`, `_rerun_worker` and
  `licensed_readiness`. Two consequences:
  - The replication pins must be restated with the switch on (the 0.x release note that ships the change).
  - The client-safe run keeps `source "profile"`.
- **Known limits** (`docs/validation/licensed-data-readiness.md` section 3):
  - Stress shocks on `countries.spread` do not reach layer 2 for countries that use a curve.
  - Layers 3 and 6, the DSA and restructuring keep reading the profile spread.

## Recommendation

**(a) now.** (b) once a real snapshot has been re-run and the Team C items are closed: it is the smaller and more
predictable change, and the same `spread / LGD / k` formula is used. (c) is a model choice to make on real curves.
It needs evidence that the 1-year hazard is a better guide than the 5y spread for a 12-month PD.
