# Tier 1 card: approved analyst overlay entries move the risk numbers (EQ-B-0138, 2026-10-26)

Team B AGENT-07. **Parked.** Not posted, not proposed, nothing applied. The overlay ships as a display-only research
view, off by default (`econquest/validation/analyst_overlay.py`, method `docs/validation/analyst-overlay.md`). This
card is what Sam would sign if approved overlay deltas were ever to feed the final pillar scores, and so the PDs,
VaR, ES, EL and limits. The lead adds it to `team/when-sam-is-ready.md`; it is not part of the first Mac pass.

**Every overlay number below is a SYNTHETIC effect.** The entries are the demo's SYNTHETIC sample and the two cap
bounds, not anyone's judgement. They show the mechanism and the largest size the caps allow.

**How the numbers were made.** `python -m econquest.validation.analyst_overlay effect --paths 20000` (and
`--paths 100000`): 0.7.0 shared data and settings, as_of 2026-10-23; SYNTHETIC entries are added and approved
(four-eyes) in a temporary marked sandbox ledger, the capped deltas (5.0 points per pillar; GROSS country cap: the sum
over pillars of |weight x delta| at most 2.0 composite points) from `overlay_rows` are added to the "Analyst adjustment" rows
of `adjustments.csv` in a temporary copy of `data/` (the same arithmetic as a hook on the final pillar: added before
the 0..100 clip and the override floors), and the whole pipeline runs. A copy with no overlay reproduces the base
exactly. The shared data hash, 308b73ca9e257627, is the same before and after.

## Decision (first-mac-pass section B terms)

| # | Choice | Recommendation | Tag |
|---|---|---|---|
| D-B0138 | Analyst overlay into the risk numbers: (a) keep it a display-only view beside the model (today), or (b) add approved, unexpired overlay deltas to the final pillar scores in the base run | (a), until a second approver exists and a track record of overlay calls is kept | optional |

## Options

- **(a) Display only (today). Recommended.** No change. Rows show model value, overlay delta and overlaid value apart.
- **(b) Wire into the base.** A switch `scorecard.analyst_overlay` (off) read by `score_universe`: for each country,
  the capped deltas of the active, approved, non-synthetic entries as of the run date are added to the final pillar
  with the analyst adjustment. The run would stamp the ledger head (seq:hash) and the entry ids it used, so a run is
  reproducible from the ledger.

## Effect ($mm; limits VaR99 95, ES99 115, L-VaR99 100, EL 5)

| Case | Paths | VaR99 | ES99 | EL | L-VaR99 | EL use |
|---|---|---|---|---|---|---|
| (a) today | 20k | 66.956 | 89.000 | 4.099 | 72.238 | 82% (warning) |
| (b) SYNTHETIC demo sample (6 entries, BRA PAK VNM) | 20k | 67.016 (+0.060) | 89.081 (+0.081) | 4.142 (+0.044) | 72.298 (+0.060) | 83% (warning) |
| (b) cap bound +2 notches everywhere | 20k | 68.305 (+1.349) | 90.524 (+1.524) | 4.378 (+0.279) | 73.586 (+1.349) | 88% (warning) |
| (b) cap bound -2 notches everywhere | 20k | 65.977 (-0.979) | 87.536 (-1.464) | 3.842 (-0.257) | 71.259 (-0.979) | 77% |
| (a) today | 100k | 66.780 | 88.482 | 4.104 | 72.062 | 82% (warning) |
| (b) SYNTHETIC demo sample | 100k | 66.844 (+0.064) | 88.576 (+0.094) | 4.151 (+0.047) | 72.126 (+0.064) | 83% (warning) |
| (b) cap bound +2 | 100k | 68.242 (+1.462) | 89.891 (+1.409) | 4.383 (+0.279) | 73.523 (+1.462) | 88% (warning) |
| (b) cap bound -2 | 100k | 65.543 (-1.237) | 87.100 (-1.381) | 3.845 (-0.258) | 70.825 (-1.237) | 77% |

The table was re-run after the lead's gross-cap decision (AGENT-06 review L3) and is unchanged: in the same-sign
rows gross equals net, and the demo sample is under the cap. With the same-sign notch on every pillar of every name,
the book moves by about +1.5 / -1.2 VaR99 and +0.28 / -0.26 EL; no limit is crossed and EL stays inside its warning
band at the upper bound. The gross cap holds every name's composite move to 2.0 points whatever the mix, but a
mixed-sign set reaches the PDs and the book through different channels, so these two rows are the same-sign
bounds, not a proven bound for every combination. Per-country PD moves are not
tabulated here; the effect runner can add them before signing.

## Before signing (b)

1. A second approver is named (`docs/governance/second-approver.md`) and Team C has added an "overlay" named-user
   scope so approvals are signed; or Sam logs the exception below and accepts self-approved entries in the base.
2. The hook is built as a Tier 1 change with its own tests (off = bit-identical; synthetic entries refused; the run
   stamps the ledger head), and the effect is re-run on the real entries then in the ledger.
3. Some months of overlay calls kept as a display view, scored against what followed, so the notch size has evidence.

## Proposed exception row (Sam's decision, not logged)

Overlay self-approval is refused today because no EXC row names `overlay approve`. If Sam wants single-operator use
of the display view before a second approver exists, the row Team B would add to `docs/governance/issues-log.md`
(next free id at the time; EXC-006 today):

| Id | Date | Restriction or control | What was done | Approved by | Compensating control | Expires |
|---|---|---|---|---|---|---|
| EXC-006 | (decision date) | Four-eyes rule on analyst overlay entries (`overlay approve`, docs/validation/analyst-overlay.md section 4): the approver must not be the author | Single-operator mode: Sam may approve an overlay entry he wrote with `approve_entry(..., exc_id="EXC-006")`; display view only, never the risk numbers. Kept apart from EXC-002 and EXC-004 so overlay approvals stay separate in the audit trail. Raised by Team B (EQ-B-0138) | Sam, decision card (date) | Each self-approval is stored with self_approved yes and the EXC id in the hash-chained overlay ledger and shown on every display row; `verify --expect-head` against a head recorded outside the folder; every use listed for the independent validator and counted as a governance exception in the revalidation routine | When a second approver is named (docs/governance/second-approver.md), or 2027-01-22, whichever is first |
