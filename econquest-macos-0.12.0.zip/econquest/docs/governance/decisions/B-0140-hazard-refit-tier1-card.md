# Tier 1 card: layer-1 hazard model, paper or fitted, after the pre-registered refit rehearsal (EQ-B-0140, 2026-10-26)

Team B AGENT-03. **Parked.** Not posted, not proposed, nothing applied. The lead adds it to
`team/when-sam-is-ready.md`; it belongs with D11 (WEO history) and is not part of the first Mac pass.

**Recommendation: Layer 1 stays `paper_standardized`.** No pre-registered specification passed. Nothing for Sam to
sign today; the card says what he would sign, and when.

## How the numbers were made

- Pre-registration PR-1, `docs/validation/hazard-refit-preregistration.md` (sha256 `fca3df7934e0c35f`), written and
  checkpointed before any fit (team log, EQ-B-0140). Four specifications, one time split, one gate, no search.
- `python -m econquest.validation.hazard_rehearsal --as-of 2026-10-23` on Team A's panel
  `data/panel/hazard_panel_wide/panel.csv` (EQ-A-0140, internal only, sha256 `391932094d99d2d0`): 5,887 at-risk
  country-years, 159 CRAG economies, 166 crag_v1 starts. Panel preflight all pass (manifest as_of, crag_v1 rule and
  raw CRAG hash, lag 1, one row per country-year, every label re-derived from `hazard_events.build_events`).
- One Firth logit fit on label years up to 2007, scored once on label years 2008-2023. Report:
  `outputs/hazard_refit/2026-10-23-rehearsal/rehearsal-report.md`.

## Gate verdict per specification

Gate: test events >= 30, OOS AUC >= 0.75, OOS Brier below the trailing base rate (training event rate). Preflight
adds: >= 10 training events, >= 60 economies, ever-defaulted share of the fitted sample < 0.55.

| Spec | Predictors | Verdict | Test events | OOS AUC | OOS Brier vs trailing base | Ever-defaulted share | Rolling-origin AUC (info) |
|---|---|---|---|---|---|---|---|
| S1 paper | debt_gdp, primary_deficit, stfx_debt_reserves, reserves_months_imports, pitf_instability | NOT RUN: WEO columns empty | | | | | |
| S2 wb_only | stfx_debt_reserves, reserves_months_imports, pitf_instability | PREFLIGHT_FAILED; gate FAIL (AUC) | 30 (pass) | 0.663 (FAIL) | 0.01970 vs 0.02035 (pass) | 0.644 (FAIL) | 0.634 |
| S3 wb_crag_history | S2 + crag_prior_spells | PREFLIGHT_FAILED; gate FAIL (AUC) | 30 (pass) | 0.698 (FAIL) | 0.01966 vs 0.02035 (pass) | 0.644 (FAIL) | 0.671 |
| S4 full | WEO five + S3 | NOT RUN: WEO columns empty | | | | | |

S2 and S3 share one sample after the complete-case rule: 1,941 rows, 104 economies; training 493 rows, 87
economies, 14 events (label years 1998-2007, because the WGI instability series starts in 1996); test 1,448 rows,
30 events. Base rates: training 2.84%, test 2.07%; the whole panel 2.82% (118 training and 48 test events before
complete cases). Both fits are well calibrated in the large (mean predicted 2.36% and 2.55% against 2.07% observed)
but rank too weakly: the coefficients are small against their standard errors except reserves in months of imports
(-0.96 and -1.03, s.e. about 0.6), and the instability sign is the wrong way round (-0.17, -0.20, not significant).

## Effect

**None.** No specification passed, so no effect run was made and the base is untouched (20k 66.95612571109443 /
89.00003057231508 / 4.098636048964449 / 72.23763153780678; replicate PASS 141 FAIL 0 after this ticket).

Even a pass of S2 or S3 would not move a number. Fitted mode refuses World Bank features and crag_prior_spells at run
time (no run-time source aligned with the panel, EQ-B-0029), so the run would fall back to paper. The effect runner
checks this mechanically at 1,000 paths in its test: before equals after. Such a pass could only support storing the
coefficients.

## Decision (first-mac-pass section B terms)

| # | Choice | Recommendation | Tag |
|---|---|---|---|
| D-B0140 | Layer-1 hazard: (a) keep `paper_standardized` (today), or (b) switch to fitted on a pre-registered specification that passed the gate | (a): no pre-registered specification passed (S2 AUC 0.663, S3 0.698, both selected on outcome; S1 and S4 wait for the WEO history, D11). Re-decide only after `hazard_panel_wide build --refit` and a rehearsal rerun | optional |

## What Sam would approve, and the command (only if a rerun passes)

Nothing today. When the WEO history lands (D11), Team A's one command fills the five WEO columns, and the same
rehearsal runs S1 and S4 unchanged (PR-1 is not edited):

```zsh
python -m econquest.ingestion.hazard_panel_wide build --refit --author Sam
python -m econquest.validation.hazard_rehearsal --as-of 2026-10-23
```

The `build --refit` step also runs the older `hazard_refit --events crag` fit and drafts its own propose command; that
fit is not pre-registered, so its output is not PR-1 evidence and only the rehearsal rerun decides.

If S1 or S4 then passes (the first in the order S1, S4), Team B fills this card from `rehearsal-report.json`: the
effect table (VaR99, ES99, EL, L-VaR99 at 20,000 paths, before must equal the base; and the 18 desk PDs before,
after and the fit's raw PD) from the runner's effect run on a temporary copy of data/, and writes the patch from the
passing block (`hazard_rehearsal.block_for`, dry-validated with `hazard_refit.validate_patch`). Sam would then
approve one Tier 1 change, `layer1.mode` to `fitted` with the passing block as `layer1_fitted`:

```zsh
econquest change propose assumptions.json --patch-file layer1_fitted_patch.json --tier 1 --allow-new-keys \
  --allow-type-change --author '<NAME>' --reason 'EQ-B-0140: pre-registered spec <S1|S4> passed (OOS AUC <x>, <n> test events, Brier <b> < <b0>)'
econquest change approve <CHG-id> --approver "Sam"     # not the author
econquest change apply <CHG-id>
```

Rollback: set `layer1.mode` back to `paper_standardized` (the paper block is kept).

## Open items and gaps

1. **WEO history (D11).** S1 and S4 cannot run without it; debt/GDP and the primary balance have no non-WEO source.
2. **Selection on outcome.** In the CRAG universe the ever-defaulted share is 0.616 (0.644 in the S2/S3 sample),
   above 0.55. A WEO history of about 190 economies adds never-defaulters; whether they enter as non-events is Team
   A's assumption (`zeros_not_covered_by_crag`) and needs Sam's acceptance before a pass can count.
3. **Thin training window** for the World Bank sets: 14 events in 1998-2007 (WGI starts 1996). A full-history
   World Bank pull (`panel_history --wb-set interim`) fills only the 2000s, not earlier years.
4. **Not point in time.** The World Bank columns are latest values with revisions; only the WEO and CRAG columns are
   point in time. A pass of S2 or S3 would be weaker evidence and would only support storing coefficients.
5. **Run-time alignment.** crag_prior_spells and the three World Bank predictors have no run-time source in the
   engine, and S1 and S4 contain them too. A pass of S1 or S4 therefore also needs an engine change (run-time World
   Bank and CRAG-history inputs with the panel definitions, Team B ticket) before the switch takes effect; until
   then the run falls back to paper. The runner says so in its decision line.
6. Any change to the specifications, split or gate is a new pre-registration (PR-2). Results on data already seen
   are exploratory and cannot pass.
