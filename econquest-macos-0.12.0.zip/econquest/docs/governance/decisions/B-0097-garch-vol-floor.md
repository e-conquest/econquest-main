# Decision pack: floor on GARCH FX vols (EQ-B-0097, 2026-10-25)

Team B AGENT-05. All numbers: release 0.5.0 base (FX-only official prices), as_of 2026-10-23, 100,000 paths
requested, seed 7, temporary settings copies only. No setting or engine default was changed.

## Question

Should the Monte Carlo's GARCH FX vols be allowed to fall below the regime vols, or should they have a floor?

## Why it matters

Since Sam's FX GARCH Tier 1 approval (inventory 10a), six FX legs take a GARCH 12-month vol. On official fixings
every one of them is below its regime value: USDPHP 5.4 (Float 12), USDCNY 2.6 (Managed 7), USDMYR 5.6 (Float 12),
USDSGD 3.8 (Managed 7), USDBRL 11.7 (Float 12), USDCOP 11.4 (Float 12). So GARCH lowers book VaR99 by about 14%
against regime vols (dossier `garch-dcc-tier1.md` 11.5). The one-day backtests pass, but nothing tests the 12-month
horizon, and a low measured vol in a managed currency is not low risk (limitation 6). A floor limits how far a
calm sample can pull the tail down.

## Options

- **(a) No floor.** Today. GARCH vols are used as fitted.
- **(b) Floor at 0.75 x regime vol.** PHP and MYR go to 9.0, SGD to 5.25, CNY to 5.25 (inside the CNY and SGD
  local-bond legs too). BRL and COP are above the floor and do not move.
- **(c) Floor at 1.0 x regime vol.** Every GARCH leg goes up to its regime value (GARCH can only raise a vol).
  Today every leg is below its regime value, so the book is then the same as `vol_source` regime (identical at
  20,000 paths, dossier 11.5).

## Effect (100,000 paths, as_of 2026-10-23)

Book limits: VaR99 95, ES99 115, L-VaR99 100, EL 5 $mm.

| Option | VaR99 | ES99 | EL | L-VaR99 | VaR99 use | ES99 use | L-VaR99 use | Stress ES99 A | FED22 | MACRO_WAR_ASIA | Scenarios with ES99 > 115 |
|---|---|---|---|---|---|---|---|---|---|---|---|
| (a) none (today) | 58.19 | 78.72 | 0.88 | 63.47 | 61% | 68% | 63% | 131.4 | 147.6 | 149.1 | 14 of 17 |
| (b) 0.75 x regime | 62.19 (+6.9%) | 83.58 (+6.2%) | 0.88 | 67.47 | 65% | 73% | 67% | 138.4 | 153.5 | 155.9 | 14 of 17 |
| (c) 1.0 x regime | 66.07 (+13.6%) | 88.13 (+12.0%) | 0.87 | 71.36 | 70% | 77% | 71% | 144.6 | 158.6 | 161.5 | 14 of 17 |

All options stay below the 80% warning band. The stress ES99 of 14 of 17 scenarios is above the 115 limit under every
option (the same 14).

## Recommendation: (b), floor at 0.75 x regime

The backtests support the GARCH dynamics at one day, so the GARCH vol should still set the leg (unlike (c), which
undoes the Tier 1 model for every leg). But the Monte Carlo uses a 12-month vol that is not tested, on a three-year
sample of smooth official fixings, and two of the six legs are managed currencies at 2.6% and 3.8%. A floor at 0.75 x
regime keeps GARCH in charge where it is close to the regime view (BRL, COP) and stops the calm-sample legs from
undercutting it by more than a quarter. Cost: +6.9% VaR99, +6.2% ES99; utilisation stays below 75%.

## What each option means

| Option | Change | Tier |
|---|---|---|
| (a) | None | n/a |
| (b) | Code: `garch_vol_table` applies `monte_carlo.garch_vol.floor_rel` (default none, bit-identical; diff in `B-0097-engine-options.diff`, layer6 hunk 2; layer6 is a shared file, AGENT-08 applies). Then `econquest change propose` on `data/assumptions.json`: `/monte_carlo/garch_vol/floor_rel` = 0.75 (new key, `--allow-new-keys`) | 1 (`monte_carlo` section; model inventory 10a) |
| (c) | Same, with 1.0 | 1 |

The floor uses the governed (unstressed) regime vols as its reference, the same anchor stress scenarios use, so a
scenario that doubles `market.fx_vol.Float` doubles a floored vol too.

## Draft card

**Question:** Should GARCH FX vols have a floor under the regime vols?

**Options:**
1. No floor (today): VaR99 58.2, ES99 78.7; GARCH vols used as fitted.
2. Floor 0.75 x regime (recommended): VaR99 62.2 (+6.9%), ES99 83.6 (+6.2%).
3. Floor 1.0 x regime: VaR99 66.1 (+13.6%), ES99 88.1 (+12.0%); GARCH can only raise vols.

**Context:** Six FX legs use GARCH 12-month vols, and all six are below their regime values on official fixings
(PHP 5.4 vs 12, CNY 2.6 vs 7, SGD 3.8 vs 7). One-day backtests pass, but the 12-month horizon is untested and two
legs are managed currencies. A 0.75 floor lifts PHP, MYR, CNY and SGD, leaves BRL and COP. All options stay under
80% limit use. Tier 1: new key monte_carlo.garch_vol.floor_rel plus a small code change, base bit-identical without
it. 100k paths, as_of 2026-10-23.
