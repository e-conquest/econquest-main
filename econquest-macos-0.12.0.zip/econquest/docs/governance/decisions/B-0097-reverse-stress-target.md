# Decision pack: which limit reverse stress searches for (EQ-B-0097, 2026-10-25)

Team B AGENT-05. All numbers: release 0.5.0 base (FX-only official prices), as_of 2026-10-23, seed 7. Single
factors at 100,000 paths requested, scenarios at 20,000 (each search is 8 to 16 runs). No setting or engine default
was changed.

## Question

Should reverse stress keep searching for the shock that breaks VaR99, or search for ES99, or report both?

## Why it matters

`econquest reverse-stress` (`--measure`, default `var99_mm`) finds the smallest shock that breaks one book limit. On
the 0.5.0 base the VaR99 limit cannot be reached by a sovereign spread shock alone: VaR99 peaks at 94.6 $mm near
+1,125 bp, against a limit of 95, and then falls as default paths swap market loss for LGD. A 50 bp scan confirms
the search grid is not missing a breach (EQ-B-0088). The ES99 limit (115) breaks at +844 bp. So the default report
says "no breach up to +3,000 bp" for spreads while the ES99 limit is broken at a quarter of that. ES99 is the
limit Sam signed with the 80% warning band (PI-6 pack 1), and it is the measure every stress table reports.

## Options

- **(a) Keep VaR99** as the default target. Today.
- **(b) Switch the default to ES99.**
- **(c) Report both** VaR99 and ES99 in one run (and L-VaR99, which is also a book limit; see below).

## Effect

No model number changes under any option: it is a reporting choice. Base (all options): VaR99 58.19 (61% of 95),
ES99 78.72 (68% of 115), EL 0.88 (18% of 5), L-VaR99 63.47 (63% of 100). Stress ES99: A 131.4, FED22 147.6,
MACRO_WAR_ASIA 149.1; 14 of 17 scenarios above 115.

What changes is what the reverse-stress report says.

Single factors (100,000 paths; smallest move that breaks the limit):

| Factor | VaR99 (limit 95) | ES99 (limit 115) | L-VaR99 (limit 100) |
|---|---|---|---|
| Sovereign spreads | **no breach to +3,000 bp** (peak 94.6 at +1,125) | +844 bp | +938 bp |
| EM currencies (3-month depreciation) | 30% | 16% | 18% |
| Hard-currency LGD | no breach to +35 pp | no breach | no breach |
| Default PD multiplier | 6.2 x | 6.8 x | 6.2 x |
| Global copula loading | no breach to +0.75 (peak 89.9) | +0.47 | no breach (peak 95.2) |
| Rating notches | no breach (see the note below) | no breach | no breach |

Scenarios (20,000 paths; scale of the scenario at which the limit breaks, 1.0 = the scenario as defined):

| Scenario | VaR99 | ES99 | L-VaR99 |
|---|---|---|---|
| A | 0.75 | 0.50 | 0.63 |
| FED22 | 0.50 | 0.47 | 0.50 |
| MACRO_WAR_ASIA | 0.53 | 0.44 | 0.50 |
| GFC08 | 0.28 | 0.25 | 0.25 |
| C | 2.47 | 2.09 | 1.91 |
| MACRO_CHINA | 1.03 | 0.69 | 0.97 |
| B, DOWNGRADE | no breach to 4.0 | no breach to 4.0 | no breach to 4.0 |

ES99 breaks first in 14 of the 15 scenarios that breach (tied with L-VaR99 in GFC08), L-VaR99 in scenario C. VaR99 is never the first limit to
break, and two single factors (spreads, loading) breach ES99 but never VaR99.

Note, found while running this: the "rating notches" single factor (`stress.SINGLE_FACTORS["downgrade"]`, `value:
1`) **upgrades** every sovereign (Vietnam BB+ to BBB- at one notch; VaR99 falls to 56.3 and 52.7 at 1 and 3
notches). The ladder's downgrade direction is negative (scenario DOWNGRADE uses -2). It should be `value: -1`. This
is a bug in a shared file, reported to AGENT-08, not part of this decision.

## Recommendation: (c), report both VaR99 and ES99 (and L-VaR99)

Each limit is a limit, so the report should say which one breaks first and at what size. ES99 is the binding one
for almost every shock and the one stress tables report, so it must be in the report. Dropping VaR99 (b) would hide
the fact that VaR99 is not reachable by spreads alone, which is itself useful (it shows the default/LGD trade-off).
Adding L-VaR99 costs one more search and catches scenario C.

## What each option means

| Option | Change | Tier |
|---|---|---|
| (a) | None | n/a |
| (b) | `econquest/cli.py` reverse-stress: `--measure` default `es99_mm` (Team C file: handoff from Team B) | 2 (stress tool; no model number changes) |
| (c) | `econquest/cli.py`: `--measure` takes several values, default `var99_mm es99_mm lvar99_mm`; one result block per measure, and a summary line "first limit to break: ..." (Team C file: handoff). `stress.reverse_stress` already takes any book measure; no engine change | 2 |

No `econquest change` proposal: no governed setting is involved.

## Draft card

**Question:** Should reverse stress search for the VaR99 breach, ES99, or both?

**Options:**
1. Keep VaR99 (today): spreads report "no breach to +3,000 bp".
2. Switch to ES99: spreads breach at +844 bp; VaR99 no longer reported.
3. Report VaR99, ES99 and L-VaR99 (recommended): shows which limit breaks first.

**Context:** Reverse stress finds the smallest shock that breaks a book limit, today VaR99 only. On the 0.5.0
base, VaR99 peaks at 94.6 (limit 95) under a spread shock and then falls, so the report says "no breach" while ES99
breaks at +844 bp. ES99 breaks first (or tied) in 14 of 15 breaching scenarios, L-VaR99 in scenario C. No model number changes:
this is a report setting in the CLI (Team C), Tier 2.
