# Decision pack: spread income on default paths (EQ-B-0097, 2026-10-25)

Team B AGENT-05. All numbers: release 0.5.0 base (FX-only official prices), as_of 2026-10-23, 100,000 paths
requested, seed 7, temporary settings copies only. No setting or engine default was changed.

## Question

Should a bond or CDS position still earn its full year of spread income on a path where the sovereign defaults?

## Why it matters

Layer 6 adds each position's one-year spread income ("carry") to every path
(`layer6_montecarlo.py`: `carry_mm` set in `build_positions`, added in `simulate` as `L = nn * s * L + carry_mm`).
A long Eurobond earns `notional x spread`, a CDS buyer pays it. The default leg then takes the LGD on top, but the
income is never stopped. On a default path the holder in fact stops receiving coupons at default.

The largest case is Venezuela (P17): 5 $mm long, PD 0.99 (in default), spread income 3.0 $mm a year. The model
books that 3.0 $mm on 99% of paths. That one position is about 2.97 of the 3.21 $mm EL change below. It also makes
EL go negative when the LGD is lowered (pack `B-0097-distressed-lgd-cap.md`): income counted on default paths
then outweighs the default loss.

The model has no default time inside the year: a path either defaults within the horizon or not. So "pro rata to
the default date" can only be an assumption (option b), not a model output.

## Options

- **(a) Keep.** Today: full spread income on every path.
- **(b) Half on default paths.** Income to a default time spread evenly over the year (on average half a year).
  An assumption, since the model draws no default date.
- **(c) Zero on default paths.** No spread income on a path where that position's default leg is hit. Survivors
  keep the full year.

## Effect (100,000 paths, as_of 2026-10-23)

Book limits: VaR99 95, ES99 115, L-VaR99 100, EL 5 $mm.

| Option | VaR99 | ES99 | EL | L-VaR99 | VaR99 use | ES99 use | L-VaR99 use | EL use | Stress ES99 A | FED22 | MACRO_WAR_ASIA | Scenarios with ES99 > 115 |
|---|---|---|---|---|---|---|---|---|---|---|---|---|
| (a) keep (today) | 58.19 | 78.72 | 0.88 | 63.47 | 61% | 68% | 63% | 18% | 131.4 | 147.6 | 149.1 | 14 of 17 |
| (b) half | 60.60 (+4.1%) | 81.15 (+3.1%) | 2.48 | 65.88 | 64% | 71% | 66% | 50% | 135.2 | 151.8 | 154.0 | 14 of 17 |
| (c) zero | 62.97 (+8.2%) | 83.58 (+6.2%) | 4.09 | 68.25 | 66% | 73% | 68% | **82%** | 139.1 | 155.9 | 158.9 | 14 of 17 |

Under (c) the EL limit (5 $mm) moves into the 80% warning band. That is the Venezuela position: an expected
default loss the model has so far netted against income it would not receive.

## Recommendation: (c), zero income on default paths

It removes a known bias (income counted after default) rather than adding an assumption. The model has no default
date, so (b) would need one. The EL warning it triggers is real
information about the Venezuela position (PD 0.99, 3.0 $mm of spread income), not a side effect. Sam may want to
decide (c) first and then look at pack 3 (LGD cap), because with income kept on default paths a lower LGD makes EL
negative.

## What each option means

| Option | Change | Tier |
|---|---|---|
| (a) | None | n/a |
| (b), (c) | Code: `monte_carlo.carry_on_default` ("keep" default, "half", "zero"), read by `layer6_montecarlo.carry_on_default`; in `simulate` the carry of a position is scaled by `1 - share x default-paths` on its default ("beta") leg (diff in `B-0097-engine-options.diff`, layer6 hunks 1, 4 to 6; shared file, AGENT-08 applies; with the key absent the base is bit-identical, checked at 20,000 paths). Then `econquest change propose` on `data/assumptions.json`: `/monte_carlo/carry_on_default` = "zero" (or "half"), new key, `--allow-new-keys` | 1 (`monte_carlo` section; layer 6) |

Release note: restates EL and VaR99 for the same book; the EL warning is a measurement change, not a trade.

## Draft card

**Question:** Should bonds stop earning spread income on paths where they default?

**Options:**
1. Keep (today): EL 0.88, VaR99 58.2; income counted after default.
2. Half on default paths: EL 2.48, VaR99 60.6 (+4.1%); assumes mid-year default.
3. Zero on default paths (recommended): EL 4.09 (82% of limit, warning), VaR99 63.0 (+8.2%).

**Context:** Layer 6 adds a full year of spread income to every path, including paths where the issuer defaults.
Venezuela (5 $mm long, PD 0.99, 3.0 $mm income) is most of the effect: the model books income it would not get.
The model draws no default date, so "half" is an assumption; "zero" removes the bias. Under zero, EL reaches 82%
of its 5 $mm limit (warning band) and ES99 rises 6.2%. Tier 1: new key monte_carlo.carry_on_default plus a small
code change, base bit-identical without it. Decide before the LGD cap card: with income kept, a lower LGD makes EL
negative. 100k paths, as_of 2026-10-23.
