# Second approver: onboarding a second analyst for four-eyes (gap E5)

Ticket EQ-C-0078 (Team C); placed here by Team B (HO-20261024-C-B-003). Team C's working copy is team/runbooks/C-second-approver.md. Code: `econquest/ops/identity.py`,
`econquest/ops/approvals.py`, registry `data/users.json`.

## Where we are today

Sam is the only operator. Every change to `assumptions.json`, `limits.json`, `compliance.json`, `research.json` and now
`users.json` goes through `econquest change`, and Sam approves his own proposals under single-operator mode:
`--self-approved --exc EXC-nnn`, with the EXC listed in `docs/governance/issues-log.md`. The approvals ledger
(`data/approvals/log.jsonl`) is hash-chained.

The groundwork described here is **off**. `data/users.json` lists only Sam (no key) with `four_eyes: "off"`, so nothing
changes: approvals work exactly as before, old ledgers verify unchanged, and unsigned rows keep their old fields.

## What the groundwork adds

| Piece | What it does |
|---|---|
| `data/users.json` | Registry of named users: `id`, `name`, `role` (owner, analyst, validator), `key_fingerprint`, `previous_fingerprints`, `active`; plus `four_eyes` (off or enforce) and `enforced_from`. It is a governed file (Tier 2), changed only by `econquest change propose users.json`. |
| Per-user key | A secret of at least 32 characters per user, kept in the macOS Keychain (service `econquest-signing`, account = user id) or in `$ECONQUEST_SIGNING_KEY_<ID>`. It never goes in a file or the repo. The registry keeps only its fingerprint. |
| Signed approval | `econquest change approve CHG-... --as <id>` adds `approver_id`, `key_fp` and `signature` (HMAC-SHA256 over the change id, file, hashes, approver, self-approval flag and EXC) to the log row. |
| Verification | `econquest users verify` and `econquest change verify` check every signed row: the user is registered, the fingerprint is theirs, the approver name matches, and the HMAC verifies when the key is on this machine. Once four-eyes is enforced they also check that every approval since `enforced_from` is signed, not self-approved, and by someone other than the proposer. |
| Enforcement | Only with `four_eyes: "enforce"` **and** at least two active users. Then `change approve` refuses an approval without `--as`, a self-approval, and an approver who is also the proposer. |

**Why HMAC and not public-key signatures.** The `cryptography` package is not in `requirements-lock.txt`, and adding a
dependency is a separate decision (AGENT-10 lock, AGENT-09 review, Sam). An HMAC can only be checked where the
signer's key is present. On any other machine verification still checks the registry, the fingerprint and the
four-eyes rules, and reports the signature as "not checkable here". Anyone holding a key can sign with it, so this
gives attribution against someone editing the shared folder, not proof against the key holder. To upgrade to ed25519
later, add `cryptography` to the lock and switch the fingerprint and signature functions in `identity.py`. The row
fields stay the same.

## Onboarding steps (Sam, when the second analyst joins)

Example: analyst Ana Lima, id `ana`.

1. **Ana creates her key on her own login.** Do not share it, and do not put it in a shell history or a file:
   ```
   openssl rand -hex 32                                   # copy the output
   security add-generic-password -s econquest-signing -a ana -w   # paste it at the prompt
   econquest users fingerprint --id ana                   # prints hmac-sha256:<32 hex>; the secret is never printed
   ```
   Ana sends Sam the fingerprint, which is not secret.
2. **Sam enrols his own key** in the same way (`-a sam`, `econquest users fingerprint --id sam`).
3. **Register Ana (Sam is still the only active user, so this is a self-approval under an EXC):**
   ```
   econquest change propose users.json --allow-new-keys --author Sam --reason "onboard Ana Lima (second analyst)" \
     --set '/users/0/key_fingerprint="hmac-sha256:<sam fp>"' \
     --set '/users/-={"id":"ana","name":"Ana Lima","role":"analyst","key_fingerprint":"hmac-sha256:<ana fp>","previous_fingerprints":[],"active":true}'
   econquest change approve CHG-... --self-approved --exc EXC-nnn   # no --as yet: Sam's fingerprint lands with this change
   econquest change apply CHG-... --actor Sam
   econquest users list                                   # two active users; four_eyes still off
   ```
4. **Try it while still off:** Ana approves one of Sam's proposals with `--as ana`, and `econquest users verify` shows
   one signed row checked (on Ana's login) or not checkable here (on Sam's).
5. **Switch enforcement on.** This is a governance change that Ana, as the second user, approves:
   ```
   econquest change propose users.json --author Sam --reason "enforce four-eyes by named users" \
     --set '/four_eyes="enforce"' --set '/enforced_from="<UTC now, e.g. 2026-11-02T00:00:00Z>"'
   econquest change approve CHG-... --as ana               # on Ana's login
   econquest change apply CHG-... --actor Sam
   ```
   From `enforced_from` onwards every approval needs `--as`, self-approval is refused, and the approver must be a
   different registered user from the proposer. Rows before `enforced_from` (Sam's EXC self-approvals) are the legacy
   period and still pass.
6. **Close the single-operator exception.** Mark the EXC in `docs/governance/issues-log.md` as superseded from
   `enforced_from` (Team B), and note the change in the next release note.

## Running it

- **Key rotation:** create a new key, move the old fingerprint into `previous_fingerprints` and set the new one, through `econquest change propose users.json`. Old signed rows keep verifying against the old fingerprint.
- **Leaver:** set `active: false` through a change. If that leaves one active user, enforcement lapses and the EXC path is needed again; reopen the exception.
- **Checks to run:** `econquest change verify` (chain, drift and signatures; exit 1 on a problem) and `econquest users verify`.
- **What stays Sam's decision:** switching `four_eyes` to enforce, adding the `cryptography` dependency, and any other change to who may approve.
