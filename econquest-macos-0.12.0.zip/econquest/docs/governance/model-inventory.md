# Model inventory

Date: 2026-10-23; refreshed 2026-10-25 to release 0.7.0 (EQ-B-0121, AGENT-07): rows 17 to 27 added, rows 3, 7, 9,
10a and 12 brought up to date, component detail 6 to 9 and 14 restated on the 0.7.0 base; 2026-10-26 rows 28 to 31
and details 17 to 20 added for the PI-13 components (EQ-B-0139, AGENT-05); rows 32 to 35 and details 21 to 24 for the
PI-14 components (EQ-B-0144, AGENT-05); 2026-10-27 rows 36 to 40 and details 25 to 29 for the PI-15 assistant components (EQ-B-0149, AGENT-05). Static facts below; live facts (mode, uplift switch, archived runs, hashes, evidence sizes) come
from `python -m econquest governance` (`inventory_status()` in `econquest/validation/governance.py`). Tiers follow
`model-risk-policy.md` section 2: Tier 1 sets a number that is reported or limit-tested (PD, VaR, ES, L-VaR,
expected loss, limit verdict); Tier 2 conditions a Tier 1 number or produces a decision input (regime, stress,
signal, alert, benchmark, GARCH VaR in the forecast record); Tier 3 is research or illustration that no reported
number depends on. "Paper-mode" means parameters are the paper's or the workbook's judgement values; "fitted" means
estimated on data in this repository. Owner is Sam for every component (model owner and, until roadmap 4.5 is
filled, acting approver) and the development owner is Team B (AGENT-08 signs release notes for the team, policy section 3); "desk" marks the components whose inputs are analyst-maintained files.

## Summary table

| # | Component | Code | Tier | Calibration | Last validation document | Frequency |
|---|---|---|---|---|---|---|
| 1 | Scorecard (7 pillars, 83 indicators) | `econquest/scorecard/scoring.py` | 1 | Paper-mode (workbook thresholds and weights); ~85% of indicator values seed estimates | `docs/validation/scorecard.md` | Quarterly; on any `rulebook.csv` or `assumptions.json` `scorecard` change |
| 2 | Layer 1 hazard | `econquest/engine/layer1_hazard.py`, `econquest/validation/hazard_panel.py` | 1 | Paper-mode (`layer1.mode` = `paper_standardized`); pilot fit stored under `layer1_fitted`, gate not cleared | `hazard-layer1.md`, `hazard-fit-report.md` | Quarterly `fit-hazard`; on new default episode or WEO vintage |
| 3 | Layer 2 Bayesian update and prediction-market prior | `econquest/engine/layer2_bayesian.py` (`posterior`, `default_contract_prior`, `blend_with_market`) | 1 | Paper-mode (`w_s 0.04`, `w_m 0.5`, `w_t 0.25`, `w_fx 0.1`, `tau_model 1`, `reference_oi_k 500`); since 0.1.3 `risk_premium_ratio 2.0` and Peg/Dollarized FX weight 0 (Sam, CHG-20261023T163209Z-b3f8bd); since 0.2.1 the placeholder market prior is off (`prediction_markets.use_market_prior` false, VF-013, CHG-20261024T111531Z-dd6de0) | `bayesian-layer2.md` | Quarterly; on benchmark scoring once available |
| 4 | Layer 3 regimes (rules, transition matrix, multipliers, HMM) | `econquest/engine/layer3_regime.py` | 2 | Paper-mode (rules 400/1000 bps, 5/15% FX, -10% reserves; matrix from the paper); HMM implemented, not fitted on real data | `regime-layer3.md` | Quarterly; on any `regime_rules`, `regime` or `transition_matrix` change |
| 5 | Layer 4 severity (Beta haircuts, Merton DD, GPD tails, multipliers) | `econquest/engine/layer4_severity.py`, `build_positions` in `layer6_montecarlo.py` | 1 | Paper-mode (`lgd_hard 60`, `lgd_local 35`, `lgd_sd 0.15`, `gpd_xi 0.25`, Merton `apply_uplift true`); nothing fitted to restructuring data | `severity-layer4.md` | Quarterly; on any `market` or `layer4` key change |
| 6 | Layer 5 Student-t copula and liquidity cost | `econquest/engine/layer5_copula.py` | 1 | Estimated loadings since 0.1.4 (`copula.source` estimated: Calm global and regional loadings fitted from weekly returns, judgement regime steps over the 0.15 anchor; countries without a series keep 0.15/0.25/0.35, regional 0.10); df 5 calm / 4 stressed judgement; liquidity spreads by asset class) | `copula-montecarlo-layers5-6.md` | Quarterly; on any `regime.*.global_loading`, `monte_carlo.df_*` or `liquidity` change |
| 7 | Layer 6 Monte Carlo (VaR/ES, L-VaR, contributions) | `econquest/engine/layer6_montecarlo.py` | 1 | GARCH 12-month FX vols since 0.1.4 (`monte_carlo.vol_source` garch; regime `fx_vol` 12/7/2/0 as fallbacks and for pegs; equity legs on judgement `equity_vol` since EQ-A-0054; `local_rate_vol 1.5`); GARCH vols floored at 0.75 x regime vol and no carry income on default paths since 0.6.0 (CHG-20261025T131946Z-40d55f); default loss `default_spread_overlap` lgd_only since 0.2.1 (GOV-047); 100,000 scrambled-Sobol paths, seed 7 | `copula-montecarlo-layers5-6.md` | Every release (seed-stability check); quarterly sensitivities |
| 8 | Liquidity-adjusted VaR | `liquidity_cost` in `layer5_copula.py`, applied in `layer6_montecarlo.py` | 1 | Paper-mode (`liquidity.by_asset` spreads, `regime_mult` 1/2/4, `T0_days 1`) | `copula-montecarlo-layers5-6.md` section 6.3 | Quarterly |
| 9 | Stress scenario library and reverse stress | `econquest/engine/stress.py`, `data/scenarios.json` | 2 | Data-driven: 18 scenarios in `scenarios.json` (paper A, B, C; ASIA97, GFC08, TAPER13, COVID20, FED22; TAIWAN, HORMUZ, TARIFF, CHINA_HL, DOWNGRADE; four MACRO_* compiled by row 21; EMDEF_BRA, labelled "not run: no BIS CBS exposures"). Historical ones are stylised reconstructions. Reverse stress scans an 8-step grid, then bisects (VF-018). The research scenario TOT_OIL (row 29) is in the code library `engine.stress.RESEARCH_LIBRARY`, not in `scenarios.json`, so the 18 and the frozen MVP set are unchanged | `stress-scenarios.md` | Every release (`run --stress`, `reverse-stress`); scenario library review yearly |
| 10a | GARCH(1,1)-t 12-month FX marginals for the Monte Carlo | `econquest/engine/garch.py` (`mc_vols`, `garch11_fit`, `_returns`, `clean_bad_ticks`), `layer6_montecarlo.garch_vol_table` | 1 | Fitted (maximum likelihood on daily official FX rates, BIS WS_XRU / ECB EXR, release 0.5.0; 6 legs on 2026-10-23: USDPHP, USDCNY, USDMYR, USDSGD, USDBRL, USDCOP); Tier 1 by Sam's decision card 2026-10-25 02:06Z (VF-001 closed); floor 0.75 x regime vol (0.6.0); fallbacks: pegs, administered list, persistence >= 0.995 (USDJPY, USDINR today), < 250 returns; equity legs on judgement `market.equity_vol` | `garch-dcc.md`, `dossier/garch-dcc-tier1.md` (section 11) | Every release (`garch_backtests.py --only sensitivity`); quarterly backtests and stability |
| 10b | GARCH one-day VaR/ES, DCC(1,1), vol-target scalar, options check | `econquest/engine/garch.py` (`run_garch`, `dcc_fit`) | 2 | Fitted on the same prices; FX DCC adds nothing over constant correlation (within 0.01) | `garch-dcc.md`, `dossier/garch-dcc-tier1.md` | Daily refit inside `record`; quarterly |
| 11 | Econometrics toolkit (ten tables) | `econquest/engine/econometrics.py` | 3 | Fitted on the same prices; interpolated p-values; feeds no risk number | `econometrics-toolkit.md` | Yearly, or when the Market History tab changes source |
| 12 | CDS pricer, CDS curves and bond relative value | `econquest/engine/cds.py`, `cds_curves.py`, `bond_rv.py` | 2 | Fitted per quote when quotes exist; `data/cds_quotes.csv` has 0 rows today, so the component is dormant | `cds-curves-and-rv.md` (curves and bond RV); no validation document for the single-quote pricer yet (GOV-040) | On first quotes: write validation doc; then quarterly |
| 13 | PD benchmarks | `econquest/validation/benchmarks.py` | 2 | Not a model: a scoring harness (Brier, log loss, AUC per source); one snapshot of 18 rows, scoring from 2027-10-23 | `README.md` section "PD benchmarks"; `tests/test_benchmarks.py` | Daily snapshot; quarterly review of `score_sources` |
| 14 | Limits and pre-trade check | `econquest/engine/limits.py`, `data/limits.json` | 1 | Judgement limits (book VaR99 95, ES99 115, L-VaR99 100, EL 5 $mm; country default 45, Venezuela 10, Zimbabwe 5; warning level 0.8) | `README.md` section "Limits"; `tests/test_limits.py` (5 tests) | On any `limits.json` change (approver sign-off); yearly limit review |
| 15 | Alerts | `econquest/validation/alerts.py` | 2 | Thresholds in `assumptions.json` `alerts` (`pd_change_pp 2`, `pd_level 0.25`, `var_change_pct 10`, `stale_days 45`; signal threshold 60) | `README.md` section "Daily risk report and alerts"; `tests/test_report_alerts.py` | Yearly threshold review; on every false-negative found |
| 16 | Signals, trade activation, dashboard, GPR uplift, Kelly stakes | `econquest/engine/signals.py`, `econquest/engine/gpr.py`, `arbitrage_scan` in `layer2_bayesian.py` | 2 (signals, GPR) / 3 (Kelly stakes) | Paper-mode port of workbook formulas; never backtested; stakes on placeholder prices | `signals-trades.md`, `gpr-and-prediction-markets.md` | Quarterly once signal values are archived per run (GOV-030) |
| 17 | DSA and signal 26 "Debt above IMF benchmark (DSA)" | `econquest/engine/dsa.py` (`dsa_signal_hook`), `data/dsa_inputs.csv` | 2 (signal on, display only); 1 if the PD overlay is switched on | Paper method on WEO history and projections (EXC-003, internal only); signal on since CHG-20261024T165855Z-06438f; `pd_overlay_enabled` off until backtested against defaults; Venezuela has no WEO debt series | `dsa.md`, `dossier/switch-on-dsa-gpr.md` | Quarterly; before any overlay switch-on (Tier 1 change) |
| 18 | Event stress index (layer 2 text term) | `econquest/engine/event_index.py` | 3 while off; 1 when switched on | Built (EQ-B-0033); `probability.text_index.source` none, so `w_t` is inert (GOV-014); waits on UCDP/GDELT data | `event-index.md` | On switch-on (Tier 1 change through `econquest change`) |
| 19 | Nowcast (GDP and CPI bridge equations) | `econquest/engine/nowcast.py` | 3 | Research; fitted per country on monthly official indicators when present; feeds no PD, scorecard or Monte Carlo; ships off (no `outputs/nowcast/`) | `nowcast.md` | Yearly |
| 20 | Shadow ratings | `econquest/engine/shadow_ratings.py` | 3 | Read-only analytics: PD mapped to the rating scale through `ratings_pd`; feeds no PD, loss or limit; scheduled job `shadow_ratings` (not installed until Mac step 11) | `shadow-ratings.md` | Yearly; on any `ratings_pd` change |
| 21 | Global macro scenario engine | `econquest/engine/macro_scenarios.py` | 2 | Six global drivers compiled into ordinary `stress.py` shock lists (MACRO_FED, MACRO_CHINA, MACRO_OIL, MACRO_WAR_ASIA); driver sizes are judgement | `macro-scenarios.md` | With the scenario library (row 9) |
| 22 | Restructuring scenarios and haircut model | `econquest/engine/restructuring.py` | 3 (off by default) | Haircut model on CRAG default spells (no haircut values; Cruces-Trebesch licence unverified, its values not used); not called by `run_pipeline`; Layer 4 LGD unchanged (refit plan B-0104 parked) | `restructuring.md` | When a haircut source becomes usable; any `market.lgd_hard` move is Tier 1 |
| 23 | Client-safe run | `econquest/validation/client_safe.py`, with Team A's route (`ingestion/official/client_safe_route.py`) | Control tool (its output is a Tier 2 decision input for client mode) | Reruns the engine on a copy of the data with internal-only inputs (EXC-003, EXC-005, GOOGLEFINANCE) replaced or withheld; 0.7.0 gap over house VaR99 +9.2%, ES99 +5.9% | `client-safe-run.md` | At each client-mode decision (D3 to D6) |
| 24 | Model monitoring | `econquest/validation/monitoring.py` | Control tool | PD and metric drift, input PSI, stability, champion/challenger; last run 2026-10-24 (schedule not installed) | `monitoring.md` | Weekly once scheduled (`model_monitoring` job) |
| 25 | Calendar-gated formal tests and interim backtest | `econquest/validation/calendar_tests.py`, `econquest/ops/interim_backtest.py` | Control tool | 250-day VaR/ES backtest from 2027-07-14 and 12-month benchmark scoring from 2027-10-23, both conditional on the record and snapshots accruing; interim report 60 clean days, 1 exception | `calendar-gated-tests.md`, `forecast-record.md` | Daily once scheduled |
| 26 | MVP research pack and numbers sign-off | `econquest/validation/mvp_pack.py`, `econquest/validation/mvp_signoff.py` | Control tool (the pack is internal research under restriction 6.1) | Pack built from one base + stress run and checked number by number; sign-off checks base, PDs, limits, stress, reverse stress and replication on the frozen `data/mvp` | `mvp-research-pack.md`, `mvp-numbers-signoff.md` | At each pack rebuild or dataset freeze |
| 27 | Pre-trade what-if and risk attribution | `econquest/engine/limits.py` (`pretrade_check`); attribution EQ-B-0114 in progress | 1 (limit verdicts, advisory under 6.8) | Reruns the pipeline with and without the proposed position on common random numbers at 20,000 paths; marginal and component ES being added (EQ-B-0114) | `README.md` section "Limits"; EQ-B-0114 note when done | On any `limits.json` change; with EQ-B-0114 |
| 28 | Sovereign depth views (reserve adequacy, gross financing need, maturity wall, IMF programme probability `imfprog_v1`) | `econquest/rules/sovereign.py`, `econquest/validation/depth_views.py` (schema eq-depth-views/1) | 3 (display only; no switch, nothing in the run path reads it) | Research: IMF ARA and GFN on WEO and `dsa_inputs.csv`; `imfprog_v1` is a fixed judgement logistic, nothing fitted; not independently validated | `indicator-rules.md` section 22 | With each M19 page release; before any use outside display |
| 29 | Macro depth views (FX valuation, policy-rate path, terms of trade) and the TOT_OIL research scenario | `econquest/rules/macro.py`, `econquest/validation/macro_depth.py`, `{"target": "tot"}` and `RESEARCH_LIBRARY` in `econquest/engine/stress.py` | 3 (display and research stress library only); 2 if TOT_OIL joins `scenarios.json` | Judgement: REER against own history, a BEER with fixed elasticities, an official-FX REER proxy, a Taylor rule with judgement parameters, a ToT channel with judgement pass-through; nothing fitted; not independently validated | `indicator-rules.md` section 23 | With the scenario library (row 9); before TOT_OIL moves into `scenarios.json` |
| 30 | Text stress index and early-warning signal (`tsi_lex_v1`) | `econquest/rules/text.py`, `econquest/validation/text_index.py` | 3 (off: `text_index.enabled` absent) | Judgement English lexicon, equal document weights; corpus empty until the Mac pull; backtest not run; not independently validated. Separate from the layer 2 event index (row 18) | `text-stress-index.md`, `indicator-rules.md` section 24 | At switch-on (evidence E1 to E8); then quarterly |
| 31 | Analyst overlay (notched pillar views with four-eyes ledger) | `econquest/validation/analyst_overlay.py` | 3 while off (`research.analyst_overlay.enabled` false); 1 if wired into the scorecard (card B-0138, parked) | Judgement caps (2.5 points a notch, 5.0 a pillar, 2.0 composite a country), not calibrated; display rows only; not independently validated | `analyst-overlay.md` | Before switch-on; yearly cap review once analyst calls are recorded |
| 32 | Backtest explainer, rolling backtests by country and factor, P&L attribution | `econquest/validation/backtest_explainer.py` (schema eq-backtest-explainer/1) | Control tool (read-only; INTERIM below 250 clean days) | Euler allocation of the one-day GARCH-DCC VaR, the `portfolio_risk` principle in closed form; nothing fitted beyond the record's own GARCH-DCC; reconstructs each day from today's inputs because the record stores book totals only; not independently validated | `backtest-explainer.md` | With each record review; formal tests from 2027-07-14 |
| 33 | Validator replication kit | `econquest/validation/validator_kit.py` (schema eq-validator-kit/1), on `validation/replicate.py` | Control tool | Verifies the data room and the code hash first, reruns every pin from the room's inputs by exact hash, reports PASS / DRIFT / FAIL / NOT RUN; DEMO room 42 PASS / 135 NOT RUN of 177 | `validator-replication-kit.md` | Each data room sent; each release |
| 34 | Layer-1 hazard refit rehearsal (pre-registration PR-1) | `econquest/validation/hazard_rehearsal.py` | Control tool for row 2 (decides nothing; Layer 1 stays `paper_standardized`) | Four pre-registered Firth logit specifications, one time split, one gate; S2 and S3 failed (AUC 0.663, 0.698; selected on outcome), S1 and S4 not run (WEO columns empty) | `hazard-refit-preregistration.md`, `decisions/B-0140-hazard-refit-tier1-card.md` | After the WEO history (D11) and `hazard_panel_wide build --refit` |
| 35 | Conflict escalation model (`esc_ladder_v1`) and display-only GPR / PD link | `econquest/rules/escalation.py`, `econquest/validation/escalation.py` (schema eq-escalation/1) | 3 (off: `escalation.enabled` absent) | Judgement a priori monthly transition matrix with fixed modulation; nothing fitted; no real event vintage, no UCDP; backtest not run; not independently validated | `conflict-escalation.md`, `indicator-rules.md` section 25 | At switch-on (evidence E1 to E8) |
| 36 | Assistant tool registry (read-only tools the LLM may call) | `econquest/validation/assistant_tools.py` (schema eq-assistant-tools/1, format frozen, sha256 f5ad1d21) | Control tool (read-only; the model never computes a risk figure) | Nothing of its own: every number is a row from an existing desk tool on a pinned run or a Team A context chunk, with a citation and the most restrictive licence class; not independently validated | `assistant-tools.md` | When a wrapped tool or the row format changes (new frozen hash); each release |
| 37 | Assistant QA gate (every number cited, slot rendering, refusals) | `econquest/validation/assistant_qa.py` (schema eq-assistant-qa/2) | Control tool (fail closed; the control on what the assistant shows) | Rule-based: slot grammar, measure, sign, source-name and injection scans on judgement lists, nothing calibrated; stated limits (GOV-060); not independently validated | `assistant-qa-gate.md` | Each release; eval rerun on every rule change |
| 38 | Assistant evaluation set, pass bar and scorer | `econquest/validation/assistant_eval.py`, `assistant_eval_build.py`, `docs/validation/assistant-eval/eval-set-v1.json` (eq-assistant-eval/1) | Control tool (decides switch-on evidence; decides nothing at run time) | Set v1 176 items (sha256 171e552e...bf55); pass bar v2 P1-P20 written and hashed before scoring (0d430bc1...45ba); oracle PASS, stub FAIL as expected; the real model is not scored | `assistant-eval.md` | Before switch-on; at every model tag, weights, prompt, gate or registry change |
| 39 | Assistant-drafted research notes (analyst edits and signs) | `econquest/validation/assistant_drafts.py` (schema eq-assistant-drafts/1) | 3, presentation only (off with the assistant); internal only today | Nothing calibrated: figures are gate-rendered slots; a draft is an archive version marked DRAFT (model-assisted, not validated); one named analyst signs and the sign step re-gates the text; 68 stub-only tests; Done after three review rounds (AGENT-06); not independently validated | `assistant-drafts.md` | Each release; with the gate (row 37) and on any archive format change |
| 40 | Assistant model (LLM; default Gemma 4 on Ollama on loopback) | Team C `econquest/assistant/` (provider, config, licence gate; EQ-C-0170, EQ-C-0171); runtime record via B-0147 scorer and B-0148 drafts | 3, presentation only (off: `assistant.json` `enabled` not true); never computes a risk number | Third-party weights, nothing fitted here; temperature 0; licence row `model_gemma_4` UNVERIFIED until Sam approves; optional Claude API backend allowed by Sam (D25) but off (Keychain key `econquest-anthropic` + `allow_external` true; refused for client scope); not scored on the eval set (row 38) yet | `assistant-eval.md`, `docs/runbooks/C-assistant-runtime.md` | Scored before switch-on; rescored on every model tag, weights digest, system prompt, gate or registry change |

Backtests (`econquest/validation/backtests.py`) and the forecast record (`validation/record.py`) are control
tools rather than models and are listed in `revalidation-routine.md`; the data pipeline (`ingestion/`,
`versioning.py`) is covered by `data-pipeline.md` and the issues log.

## Component detail

### 1. Scorecard

- Purpose: 83 indicators scored 0 to 100 by threshold interpolation into seven pillars, a composite and a grade;
  the composite feeds layer 2 (`w_s` per point above `score_centre 45.8`) and pillar 4 feeds layer 1 as the PITF
  instability proxy.
- Inputs: `data/rulebook.csv`, `data/indicators.csv` (1,494 cells, 224 live), `data/countries.csv`,
  `data/adjustments.csv`; `assumptions.json` keys `scorecard`, `floors`, `boom_trigger`, `stress_path`.
- Outputs: pillar and composite scores, grade, drivers; workbook tabs Base/Stress/Indicator Scores, Pillar Scores.
- Known limitations (from `scorecard.md`): inputs mostly seed estimates; thresholds not calibrated to outcomes;
  worst-indicator blend discontinuous in weights; one fixed stress path for all countries; floors can dominate
  (Venezuela 84.3 with four floors); momentum signal dead (`prior` empty); blanks silently dropped; exports used as
  the import proxy.
- Evidence: `tests/test_panoptix.py::test_scorecard_matches_workbook` (0.1 point tolerance against
  `workbook_reference.json`).

### 2. Layer 1 hazard

- Purpose: 12-month default hazard from six predictors; reconciled with the rating-implied challenger in log-odds
  at `hazard_weight 0.5`.
- Inputs: Country Profile fields (debt/GDP, ST FX debt/reserves, reserves, primary-balance gap, pillar 4, commodity
  gap), `ratings_pd` table; `layer1_paper_coefficients`, `layer1.feature_scale`.
- Outputs: `pd_hazard_l1`, `pd_rating`, `pd_model`; Risk Engine rows R31-R33.
- Calibration: paper coefficients on standardised predictors with location and scale fitted to the rating PDs.
  Pilot Firth fit on 421 country-years, 9 events: in-sample AUC 0.882, OOS AUC 0.780, OOS Brier 0.0320 vs base
  0.0232. Gate for `--apply`: AUC >= 0.75 (`hazard_panel.GATE_MIN_AUC`), events >= 30, Brier strictly below the trailing base rate; not cleared.
- Known limitations (`hazard-layer1.md`): cannot disagree with ratings in level; location-scale dominated by the
  two SD sovereigns; rating table has no vintage; Zimbabwe hazard 0.7% vs rating 60%; commodity feature pushes
  Senegal and Zimbabwe down by 2.3 log-odds; no OOS test in the live pipeline.

### 3. Layer 2 Bayesian update

- Purpose: logit(p_post) = logit(p_model) + w_s (S - 45.8) + w_m z_cds + w_fx z_fx + w_t z_tsi, then a
  precision-weighted blend with the default-contract prior.
- Inputs: spreads (hand-entered, Country Profile), FX 3-month change, text stress index (zero everywhere),
  `data/prediction_markets.csv` (18 contracts, illustrative prices, no `slug`/`ticker`).
- Outputs: `pd_default` (final PD), `pm_default`, `tau_market`.
- Known limitations (`bayesian-layer2.md`): market term dominates (z_cds 0.80 to 3.45 for every country; since
  0.1.3 a single literature-based risk-premium ratio of 2, not estimated); contract horizon now follows the run's
  `as_of` (GOV-012 resolved); text term inert; `w_fx` on realised depreciation, applied to pegs too; `tau` values are not
  measured precisions; `pd_market` cap 0.95 binds for Venezuela.

### 4. Layer 3 regimes

- Purpose: Calm/Stressed/Crisis per country from spread, 3-month depreciation and reserve loss; 12-month
  transition-weighted PD and LGD multipliers (Calm 1.0/1.0, Stressed 1.25/1.1, Crisis 1.6/1.25); global regime
  when >= 50% of countries are not Calm (today 8 of 18, below the switch).
- Known limitations (`regime-layer3.md`): three threshold inputs, two hand-entered; global switch is a cliff
  (VaR99 66.0 to 74.8 $mm when `global_stress_share` is 0.4); transition matrix not estimated and not rescaled to
  horizon; no regime switching inside paths; reserves rule absent from Crisis; HMM tested on synthetic data only;
  `scenario_override` changes multipliers but not inputs.

### 5. Layer 4 severity

- Purpose: stochastic LGD and haircuts (Beta around `lgd_hard`/`lgd_local`, regime-scaled), Merton distance to
  distress adding an LGD uplift for Eurobond and CDS positions, GPD tails for expropriation and political-violence
  losses, sector and location multipliers for equities.
- Status after 2026-10-23 fixes: uplift reaches the simulation (`expected_lgd`, clipped 0.05 to 0.95); GPD scale
  root-found so the clipped mean equals target; `beta_params` rescales a and b jointly near the cap. Effect at
  20,000 paths: VaR99 65.98 to 68.75 $mm, ES99 87.05 to 88.75, expected loss 0.24 to 1.91 $mm (Venezuela LGD 0.71 to
  0.95).
- Known limitations (`severity-layer4.md`): multipliers reach only the two equity positions (18 $mm); `lgd_sd 0.15`
  common to all classes; FX transfer loss deterministic (15% for the pegs Belize and Senegal); `lgd_hard` capped
  at 0.95 (binds in scenario B); Merton proxy sensitive to the barrier floor.

### 6 to 8. Layers 5 and 6, liquidity

- Purpose: one-factor-per-block Student-t copula (global, regional, idiosyncratic), 100,000 scrambled-Sobol paths,
  VaR/ES at 95 and 99, ES 97.5, L-VaR, position and country contributions.
- Outputs on the 0.7.0 release base (shared `data/`, as_of 2026-10-23, 100,000 requested = 131,072 Sobol paths,
  seed 7, frozen 0.5.0 official FX-only prices; release note `releases/0.7.0-2026-10-25-base.md`, replicate R48-R51):
  VaR99 66.78, ES99 88.48, EL 4.10 (82% of the 5 $mm limit, warning band), L-VaR99 72.06 $mm. The MVP desk base on
  the frozen `data/mvp` dataset (e60bbc7c...c888, run 20261025T183022-base) is 66.21 / 87.91 / 4.01 / 71.49
  (`docs/validation/mvp-numbers-signoff.md`). Earlier bases (0.1.4: 74.35 / 96.48 / 0.45; 0.2.1, 0.3.0, 0.5.0,
  0.6.0) are in their release notes; the main moves were the default-loss fix and prior off (0.2.1), the INDA
  repair (0.3.0), official FX-only prices (0.5.0) and no carry on default paths with the GARCH floor (0.6.0, which
  moved EL from about 0.9 to about 4.1 $mm).
- Known limitations (`copula-montecarlo-layers5-6.md`): the tail is a market-volatility tail (default risk under
  20% of ES99); since 0.1.4 FX and equity vols are GARCH 12-month forecasts (EWY 42.8%) with regime fallbacks for
  pegs and missing series, and Calm loadings are estimated, regime step-ups and df judgement; one latent variable
  per country for market and events; liquidity cost deterministic and additive; 71 Sobol dimensions; CDS leg
  simplified; positions static for 12 months; the batch-means Monte Carlo SE is conservative for scrambled Sobol
  (16-seed sd 0.27 VaR99, 0.25 ES99 at the production count).
- Evidence: `test_monte_carlo_metrics_consistent`, `test_sobol_is_reproducible`,
  `test_tail_dependence_positive_and_gaussian_limit`, `test_mc_error_*` (EQ-B-0054); Monte Carlo SE carried in
  every run's metrics (`var99_se_mm`, `es99_se_mm`, `lvar99_se_mm` and 95% bands).

### 9. Stress scenarios

- Outputs on 0.7.0 (as_of 2026-10-23, 100,000 requested each; `releases/0.7.0-2026-10-25-base.md`): stress ES99
  from 94.47 (DOWNGRADE) to 180.63 (GFC08); A 146.60 (+65.7% on base ES99); 14 of 17 run scenarios above the 115 $mm
  ES99 limit (B, C and DOWNGRADE below). EMDEF_BRA is a labelled gap (no BIS CBS exposures).
- Known limitations (`stress-scenarios.md`): A is a regime and dependence shock (paper reports +18.4%); B is an LGD
  statement; C reaches equities only through location; response step-like at regime cliffs; sizes are data in
  `scenarios.json` but judgement; rate level and contagion channels built, partly (GOV-027).

### 10. GARCH and DCC

- Purpose: conditional volatility and correlation for the FX and ETF legs; one-day 99% VaR/ES for the forecast
  record; vol-target scalar (`target_vol 0.1`, cap 2); Black-Scholes check.
- Known limitations (`garch-dcc.md`): three years of data, no standard errors; administered rates (USDVES, USDNGN,
  USDARS, USDPKR, USDBZD) give near-unit persistence; FX and equity blocks combined at zero correlation; 9 of 24
  positions marked, local bonds as currency only.
- Since 0.1.4 the 12-month marginals (10a) set the FX vols of the Monte Carlo and are Tier 1 (VF-001, EQ-B-0068,
  EQ-B-0088, approved by Sam on a decision card 2026-10-25 02:06Z). Evidence on the official FX-only history (release 0.5.0, as_of 2026-10-23):
  one-day VaR99 out of sample, 12 tails of the 6 FX MC legs Green 11 / Yellow 1 / Red 0, pooled exceedances 1.02%
  (EWMA 1.80%); 12-month vols stable within 1.2 points across 500-return windows. Every GARCH leg is below its regime
  vol: GARCH lowers VaR99 by 13.9% against regime vols (floor question open). USDJPY and USDINR fall back on the
  persistence gate. Equity legs on judgement since EQ-A-0054. Conditions: independent validation before external
  use; use restrictions G1, G3 to G6 in `dossier/garch-dcc-tier1.md`.

### 11. Econometrics toolkit

- Purpose: ten research tables (stationarity and variance race, cointegration, SVAR, Kalman betas, regimes, risk
  premia, EVT, copulas, forecast panel, event study); the Student-t copula preferred over Clayton in 13 of 13 pairs
  is the only data-based support for the layer 5 choice.
- Known limitations (`econometrics-toolkit.md`): three years and one macro cycle; interpolated p-values; no credit
  series; administered currencies not excluded; forecast R-squared dominated by between-series levels; Markov
  switching from one start and one seed; code constants not in `assumptions.json`.

### 12. CDS pricer

- Purpose: bootstrapped piecewise-constant hazards from par spreads, CDS-implied 12-month and 5-year PD,
  model-fair spread, rich/cheap read. Settings `cds` (`recovery 0.4`, `risk_free 0.04`, quarterly).
- Status: `data/cds_quotes.csv` is empty; nothing downstream (benchmarks `pd_cds`, relative value) is populated.
  No validation document exists; `tests/test_cds.py` covers the arithmetic. A validation document is required
  before the first quotes are used (GOV-040).

### 13. PD benchmarks

- Purpose: standing comparison of the model PD with hazard-only, rating-implied, spread-implied, CDS-implied and
  prediction-market probabilities; `outcomes` and `score_sources` give Brier, log loss and AUC per source once
  snapshots are 12 months old; `disagreement_table` ranks today's gaps.
- Status: 18 rows dated 2026-10-23 in `data/benchmarks.csv`; scoring block empty until 2027-10-23; outcome
  labels depend on `data/panel/sovereign_defaults.csv`, compiled from memory with a stated +/-1 year uncertainty.

### 14. Limits

- Purpose: grade the book against `data/limits.json` (book, country, asset class, issuer, concentration, Crisis
  share); `pretrade_check` reruns the pipeline with and without a proposed position on common random numbers and
  returns accept/flag/refuse.
- Status at 0.7.0: 71 rows; book VaR99 70%, ES99 77%, L-VaR99 72% of limit, EL 82% (warning band, decision D1).
  The limits are judgement values; Sam signed them as approver on 2026-10-24 (`econquest change baseline limits.json`,
  GOV-041 resolved). Single-operator: no approver other than the owner exists yet (EXC-002, GOV-042).

### 15. Alerts

- Purpose: regime flips, PD moves >= 2 pp (critical at 4 pp), PD level crossings at 25%, signal crossings at 60,
  trades starting or stopping, VaR99/ES99 moves >= 10%, backtest failures and Basel Yellow/Red, quality-gate
  holds, missing and failed feeds. Delivery to webhook and SMTP.
- Status on `20261023T111315-base`: 0 critical, 2 warning (quality holds: Nigeria exports latest period 1960,
  Venezuela reserves 2017), 1 info (110 input cells on seed).

### 16. Signals, trades, GPR, Kelly

- Purpose: 25 signals, 26 playbook trades with conviction and sizing (`risk_budget_mm 10`, regime scalar), dashboard
  reads; GPR uplift on indicator 4.10 (percentile 90/97, z 1.5/2.5); Kelly stakes at 25% fraction on a 500k
  bankroll.
- Known limitations (`signals-trades.md`, `gpr-and-prediction-markets.md`): no signal tested against outcomes;
  conviction reflects signal construction (binary 100s); signals 15 and 19 report `w_m`; signal 25 and all stakes
  rest on placeholder prices and the run date; GPR covers 11 of 18 countries; the non-default contract curve is
  uncalibrated; Kelly has no uncertainty on p.

### 17 to 20. PI-13 components (rows 28 to 31)

Common to all four: owner Sam (model owner and acting approver); development owner Team B. Status today off or
display only. Validation status **not independently validated**: each has its author's tests and documentation, and
some have AGENT-09 hand-off reviews, but none has had a review under policy section 4. No reported number depends on any of them.
The 20k base is bit-identical with and without them (66.95612571109443 / 89.00003057231508 / 4.098636048964449 /
72.23763153780678) and replication is PASS 141. Licence classes follow `ingestion.licences` (C14 `client_output`):
any row that reads IMF WEO (EXC-003) or theratesapi.com FX (EXC-005) is restricted and internal only.

#### 17. Sovereign depth views (row 28)

- Development owner: Team B, AGENT-03 (EQ-B-0136). Tier 3; display only, no switch.
- Purpose: M19 rows for reserve adequacy (IMF ARA, and a non-IMF ARA), gross financing need by year, the maturity
  wall and refinancing risk, and the research IMF programme probability `imfprog_v1`. Plug-in point for the macro
  views (row 29) through `validation.macro_depth.depth_rows`.
- Inputs and licence class: WEO and `data/dsa_inputs.csv` (restricted, EXC-003); World Bank WDI and IDS and the
  CRAG register (allowed from a `data/live` vintage, restricted when read from a `team/inbox` research pull, which is
  every such row today, B-B-011); `countries.csv`, `indicators.csv` and agency ratings (restricted, no register row).
  IMF-compiled WDI series follow Sam's decision D3.
- Known limitations: `imfprog_v1` is a fixed logistic with judgement weights, nothing fitted; there is no IMF
  programme episode file, so the proxy backtest targets CRAG default starts rather than programmes; no Eurobond-level
  maturity schedule; the non-IMF ARA is held everywhere (no broad money, no IIP other liabilities); the IDS
  debt-service schedule exists only in an inbox pull, so line 1.2 and the wall are refused at the base `as_of`; GFN
  and the desk ARA cover only the 18 desk names.
- Switch-on evidence needed (for any use beyond display): an IMF programme episode file (MONA) and a backtest of
  `imfprog_v1` against programme starts; the IDS schedule and the ARA inputs in a `data/live` vintage; an independent
  review under policy section 4; a Tier 1 card with an effect table before any view fills a scorecard cell.

#### 18. Macro depth views and TOT_OIL (row 29)

- Development owner: Team B, AGENT-05 (EQ-B-0137). Tier 3; display views and the research stress library only.
- Purpose: FX valuation (REER misalignment against own 10-year history, a simple BEER, an official-FX REER proxy
  where BIS has no REER), the policy-rate path (current rate, recent changes, a Taylor-type implied path with a
  neutral rate from the country's own ex-post real rate) and a commodity terms-of-trade channel. `TOT_OIL` (oil
  -35%) runs only through `research_scenarios()`; it is not in `data/scenarios.json`, the stress run or the MVP set.
- Inputs and licence class: BIS REER, policy rates and CPI, World Bank WDI (allowed); WEO (restricted, EXC-003);
  theratesapi.com FX for the proxy (restricted, EXC-005; proxy and BEER rows for VNM, PAK, BLZ, VEN, NGA, ZMB name
  EXC-005 in the route, B-B-012). 18 desk names, 517 rows at as_of 2026-10-23.
- Known limitations: BEER elasticities fixed (0.5 / 0.1 / 0.4), not fitted; the proxy is bilateral against the USD
  with a fixed 2.5% US inflation and about 36 months of history; ZWE not available; Taylor parameters and the
  inflation-target table are judgement, with one growth-gap proxy for the output gap; SGP, BLZ, SEN and ZWE are not
  applicable for the rate path; the ToT channel uses gross fuel exports, is one-sided (no importer gain) and its
  pass-through and reserve-financing shares are judgement; a missing population year is a hold.
- Switch-on evidence needed: for the views, an independent review and a fitted or literature-sourced BEER; for
  TOT_OIL to enter `scenarios.json` (Tier 2), an `econquest change` on the library with the MVP sign-off set and the
  data-drift pins re-baselined, a validation note in `stress-scenarios.md` and the effect table (5k: VaR99 69.67,
  ES99 93.80, EL 3.87, L-VaR99 74.95).

#### 19. Text stress index (row 30)

- Development owner: Team B, AGENT-02 (EQ-B-0135). Tier 3; off (`text_index.enabled` absent from
  `assumptions.json`); nothing in the run path imports it. Not the layer 2 event index (row 18).
- Purpose: dictionary topic and tone scores per document, a 90-day country index by month end on the knowledge
  basis, and an early-warning state against the country's own 36-month history (`tsi_lex_v1`).
- Inputs and licence class: central bank and IMF texts from the Mac pull (`text_cb_<iso3>`, `text_imf`,
  `text_corpus_store`); every row is restricted and `client_safe_rows()` drops them. SYNTHETIC stores only in tests
  and the demo.
- Known limitations: English-only lexicon (VNM, BRA, ARG, COL, VEN and SEN central bank texts not scored); judgement
  terms and equal document weights; the corpus is empty, so the backtest reports "not run: corpus empty"; CRAG
  crag_v1 has only 4 desk-name episodes in 2016-2026 against a bar of 5; the knowledge basis has no history beyond a
  one-off pull.
- Switch-on evidence needed: E1 to E8 in `text-stress-index.md` section 3 (clean corpus, 5 scored years, backtest
  passing `SWITCH_ON_BAR`, published-basis replay, licence check, language coverage, independent review, change
  record). Feeding any risk number is a separate Tier 1 card.

#### 20. Analyst overlay (row 31)

- Development owner: Team B, AGENT-07 (B-B-009). Tier 3 while off; Tier 1 if wired into the scorecard (the B-0138
  card is parked, option (a) display only recommended).
- Purpose: analysts' notched pillar views shown next to the model values with caps, expiry, a hash-chained ledger
  and four-eyes approval. Display rows only; overlaid PD and VaR are not computed in the view.
- Inputs and licence class: the overlay ledger in the shared folder (internal desk input, restricted), the model
  values of a given run or `outputs/run_latest.json` (read only).
- Known limitations: notch size and caps are judgement, not calibrated against any record of analyst calls;
  self-asserted names (no "overlay" named-user scope yet, Team C); no EXC row for an `overlay approve` self-approval;
  no CLI (`econquest overlay`, Team C); deltas are additive on the final pillar and ignore floors and trigger add-ons;
  one open entry per cell; the ledger head is not recorded outside the shared folder.
- Switch-on evidence needed: named-user signing for the overlay and the CLI (Team C); a ledger head held outside the
  shared folder; an independent review; for scorecard wiring, the B-0138 Tier 1 card with its effect table (cap
  bound +2 notches: VaR99 +1.35, ES99 +1.52 at 20k) approved through `econquest change`.

### 21 to 24. PI-14 components (rows 32 to 35)

Common to all four: owner Sam (model owner and acting approver); development owner Team B. Status: control tools
(rows 32 to 34) or off (row 35). None is independently validated under policy section 4, and no reported number
depends on any of them: the 20k base is bit-identical with and without them (66.95612571109443 /
89.00003057231508 / 4.098636048964449 / 72.23763153780678) and replication is PASS 141.

#### 21. Backtest explainer (row 32)

- Development owner: Team B, AGENT-07 (EQ-B-0141). Read-only control tool; not called by the pipeline.
- Purpose: which country and factor drove each VaR99 exception of the forecast record (Euler components of the
  one-day GARCH-DCC VaR and ES), rolling 20- and 250-day backtests by country and factor, and P&L attribution of the
  recorded losses to today's factor moves. Every figure is INTERIM below 250 clean tested days.
- Inputs and licence class: `data/forecast_record.csv`, `data/market_history/prices.csv` (official FX; EXC-005 for
  five columns), `portfolio.csv`, `countries.csv`; the restricted GOOGLEFINANCE archive is never read.
- Known limitations: the record stores book totals only (no per-position marks, no GARCH-DCC state), so each day is
  reconstructed from today's inputs; the only exception (2026-09-23, loss 1.5606 against VaR99 1.5369) does not
  reconcile on today's prices (0.2362 against 0.8802; not an exception there); all 60 rows were marked on the retired
  GOOGLEFINANCE-era prices (with EWY), so 0 of 60 days reproduce and today's moves explain about 5% of the recorded
  variance; the equity block is empty on official prices; no `prices.csv` vintages; 60 days give no power.
- Evidence needed before it explains a formal result: per-position marks and the forecast state stored on every
  record row (`record.py` and contract C8, with Team C); Sam's decision whether the interim record stays valid or
  restarts on official FX; an independent review.

#### 22. Validator replication kit (row 33)

- Development owner: Team B, AGENT-05 (EQ-B-0143). Control tool for the independent validation (GOV-042).
- Purpose: one command that verifies the data room (Team A's verifier, manifest_sha256 sent separately) and the
  code hash, refusing on mismatch, then reruns every pinned result (replicate R01-R51, D, B, H, S, G; the
  bit-identical 20k base; the PI-12/13 demos) from the room's inputs only, offline and writing only under `--out`.
- Inputs and licence class: the room's files taken by exact versioning hash only (a redacted or later copy is never
  substituted); code-tree inputs only as `data_room_list` admits them (byte-identical copies of withheld files are
  excluded too). Evidence and inputs under `--out` are NDA only (EXC-003, EXC-005).
- Known limitations: on Team A's DEMO room 42 PASS, 0 DRIFT, 0 FAIL, 135 NOT RUN of 177 (no release
  `countries.csv`, `rulebook.csv` withheld, HO-20261026-B-A-011); 93 checks (R01-R47, D01-D16, G01-G06) can never be
  rerun by an outside validator under the licence filter (GOOGLEFINANCE-era prices, Yahoo-era 0.6.0 Country
  Profile); H21-H25 wait for Sam's decision on `panel/sovereign_defaults.csv`; the calendar rehearsal's scheduled leg
  is outside the kit. On a complete internal room: 176 PASS, 1 NOT RUN.
- Evidence needed: a validator room that carries the release inputs; the kit run by the validator.

#### 23. Hazard refit rehearsal (row 34)

- Development owner: Team B, AGENT-03 (EQ-B-0140). Decides nothing: Layer 1 stays `paper_standardized`.
- Purpose: run only the pre-registered specifications of PR-1 (written and checkpointed before any fit) on Team A's
  A-0140 panel with one time split (train to label year 2007, test 2008-2023) and one gate (>= 30 test events, OOS
  AUC >= 0.75, Brier below the trailing base rate), with preflight checks including selection on outcome.
- Inputs and licence class: `data/panel/hazard_panel_wide/panel.csv` (internal only; CRAG allowed, World Bank allowed,
  WEO columns restricted EXC-003 once filled).
- Known limitations: no specification passed (S2 AUC 0.663, S3 0.698; both preflight-failed on selection on outcome,
  ever-defaulted share 0.644 against the 0.55 bar; 0.616 in the CRAG universe); S1 and S4 not run (WEO columns
  empty, D11); 14 training events; World Bank columns not point in time; no run-time source for crag_prior_spells or
  the World Bank predictors.
- Evidence needed for a switch: WEO history (D11), a pass of S1 or S4 unchanged under PR-1, Sam's acceptance of
  never-defaulters as non-events, the engine's run-time inputs, then the B-0140 Tier 1 card with its effect table.

#### 24. Conflict escalation model (row 35)

- Development owner: Team B, AGENT-02 (EQ-B-0142). Tier 3; off (`escalation.enabled` absent); nothing in the run
  path imports it. The GPR / PD link is display only, computed on a temporary copy of the universe.
- Purpose: a five-rung ladder per desk name (calm, tension, violent unrest, armed conflict, war) from GDELT media z
  and UCDP fatalities, with 3- and 12-month probabilities of a move up from an a priori transition matrix scaled by
  GDELT pressure and the 6.9 violence trend (`esc_ladder_v1`).
- Inputs and licence class: Team A's unified event API (GDELT, UCDP); every row restricted, `client_ok` False.
- Known limitations: transition matrix and modulation are judgement, nothing estimated; no event vintage on the cloud
  disk, three legacy GDELT pulls on the Mac (rungs 0-1 only), no UCDP (token not set), so armed conflict and war are
  not observable and states are lower bounds; the backtest cannot run; the knowledge record builds up only from the
  first pull.
- Switch-on evidence needed: E1 to E8 in `conflict-escalation.md` section 5 (UCDP and GDELT category vintages,
  knowledge-basis backtest passing the bar, licence read, PD link and code review, change record). Any feed into PDs
  or stress is a separate Tier 1 card.

### 25 to 29. PI-15 components (rows 36 to 40)

Common to all five: owner Sam (model owner and acting approver); development owner Team B for rows 36 to 39 and Team
C for the runtime of row 40. The assistant explains the desk and drafts text; it never computes a PD, a loss, a limit
or a score, and nothing in `econquest run` imports any of these modules. It ships off, and everything it shows carries
the label "model-assisted, not validated". None is independently validated under policy section 4. No reported number
depends on them: the 20k base is bit-identical with and without them (66.95612571109443 / 89.00003057231508 /
4.098636048964449 / 72.23763153780678) and replication is PASS 141 (AGENT-06 recheck of EQ-B-0145, 2026-10-27).

#### 25. Assistant tool registry (row 36)

- Development owner: Team B, AGENT-05 (EQ-B-0145). Read-only; reviewed by AGENT-06 (PASS, after HO-20261027-B-B-011,
  -013 and -017).
- Purpose: the allow-list of seven tools the model may call (what_if, attribution, heatmap_drivers, event_lookup,
  archive_search, depth_views, backtest_explainer), with strict JSON schemas, OpenAI-style function definitions
  (`tool_manifest()`), an explicit session `as_of` and pinned run ids, time and size limits, and deterministic results.
  For 0.12.0 only event_lookup, archive_search and depth_views are offered to the model (lead decision on
  HO-20261027-C-B-001); the run tools and backtest_explainer wait for a read-only loader of a stored, hashed run.
  Every number is a row value with a citation {run_id, file, row, as_of, licence_class}; `model_view` shows the model
  the slot to write, never the digit. No writes, no settings changes, never `econquest change`.
- Inputs and licence class: pinned runs (restricted, EXC-003), Team A context chunks (A-0143/A-0144; allowed only when
  the chunk is client_ok and the client build is returning it), the calendar and the archive. A result carries its
  most restrictive class (C14), fail closed. Proposed contract row C19 to Team C (HO-20261027-B-C-002).
- Known limitations: archive_search goes through Team A's `build_archive`, which reads the archive through
  presentation code (exception documented; non-presentation reader asked in HO-20261027-B-A-002); depth_views
  writes a temporary folder in the system temp folder for its builders; `pin_base_run` stamps the run through
  `versioning.stamp` (calls uname); a timed-out tool thread cannot be stopped, only discarded (stale-thread guard);
  the tools answer only what the wrapped desk tools compute.
- Evidence needed before switch-on: the B-0147 score of the real model on this frozen format (row 38); the archive
  reader without presentation; an independent review.

#### 26. Assistant QA gate (row 37)

- Development owner: Team B, AGENT-07 (EQ-B-0146). Pure functions; reviewed by AGENT-06 (PASS, HO-20261027-B-B-015,
  after B-B-016 and B-B-018).
- Purpose: every answer or draft passes the gate before anyone sees it. The model writes `{{cite_id.field}}` slots and
  `[cite:id]` markers; the gate checks each slot against the rows and chunks it was given, renders the figure with its
  own label, checks measure names, signs, restricted source names and injection phrases, and refuses (fail closed) or
  shows the text with a Figures list.
- Inputs and licence class: the tool rows and chunks of the prompt only; reuses `client_safe_pack`
  RESTRICTED_SOURCE_TEXT, FACT_EXEMPT and the restricted-name patterns, and `house_view` stances and PD caps.
- Known limitations (gate doc, Limits): paraphrased injection is caught only for listed phrases; oblique names of
  restricted sources ("the Fund's flagship outlook") and phonetic or oblique measure names ("Vee-a-R") are not read;
  cross-sentence valence ("The desk lost money on it.") and a relabel in a later sentence without a back-reference
  opener pass; two figures after one measure name pass; wording that misleads without a number is an accepted limit
  (HO-20261027-B-B-010); negation is not read and ordinary number words ("estimate one", "third-party",
  "percentage") refuse, so fail-closed false refusals have a cost (P19 bar 0.02); it cannot judge whether the model
  chose the right field. The gate has been run on the oracle and the stub only; Gemma 4 is unscored.
- Evidence needed: the real model's P19 (false refusals) and the injection and client lines on set v2 (row 38); an
  independent review of the pattern lists.

#### 27. Assistant evaluation set and scorer (row 38)

- Development owner: Team B, AGENT-02 (EQ-B-0147, Done). Consumers: this inventory, Team C C-0170, C-0173, C-0174.
- Purpose: 176 desk questions with expected citations and refusals (client scope, injection, out of scope, invented
  numbers, multi-step, unit and sign, long context, arithmetic), frozen on the 20k base pinned as
  `base-20k-2026-10-23`; a pass bar written and hashed before any scoring (v1 d3e23f9d...95d2, v2 in force
  0d430bc1...45ba, lines P1-P20, P19 false refusals at most 0.02, P20 provenance); the scorer refuses if the bar text
  no longer has its logged hash. The set is pinned by sha256 (`PINNED_SETS`); any other file gives an UNPINNED
  report that never reads as PASS. A hedged refusal that still delivers is scored as answered.
- Inputs and licence class: the pinned run (restricted, EXC-003), Team A chunks, the frozen tools format; no network
  in tests, no model in tests.
- Known limitations: the oracle passes every line (so the bar is reachable), which proves the scorer, set and gate,
  not a model; the stub fails as expected (no tool calls in model mode; in host mode it cannot refuse an invented
  number); Gemma 4 on Ollama has not been scored; Team C's openai_compat request sends no seed (HO-20261027-B-C-003),
  so a scored run cannot yet be repeated exactly; set v2 with Team A's SYNTHETIC injection (89) and benign (56)
  corpora is not built.
- Evidence needed before switch-on: a PASS on pass bar v2 by the real model with its tag, weights digest, system
  prompt sha256 and seed recorded (row 40), repeated twice; set v2.

#### 28. Assistant-drafted research notes (row 39)

- Development owner: Team B, AGENT-03 (EQ-B-0148, Done after three AGENT-06 review rounds). Tests:
  `tests/test_assistant_drafts.py`, 68 tests on a deterministic stub provider, no network, no model.
- Purpose: the model drafts a note from tool rows and chunks; every figure is a gate-rendered slot. A passing draft is
  saved as a new archive item version (`...-assistant-draft-<as_of>`) marked DRAFT (model-assisted, not validated),
  internal only; a refused draft writes nothing to the archive, only an audit row with hashes. One named human analyst
  edits and signs; the sign step re-runs the gate on the stored context. A figure typed by hand goes only through
  `[[analyst-entered: ... | source: ...]]`, is shown as analyst-entered and is never client-facing. An overlay score
  or stance change goes only through the analyst overlay's four-eyes (row 31). The audit log is hash-chained.
- Inputs and licence class: as rows 36 and 37. `release_check` returns client only when client mode is on (Sam's
  decision, off), the version is signed, labelled client-safe, has no analyst-entered figure, is not SYNTHETIC and
  passes the gate for a client; today a Markdown archive version is always internal-only, so every note stays
  internal.
- Known limitations: stance has no ledger of its own (it goes through an overlay entry, which the house view does
  not read); the weights digest and seed are host-supplied (`ModelInfo`, row 40); the archive API lives in
  presentation and is injected; the manifest has no draft status, so Team A's `build_archive` must skip unsigned
  drafts (HO-20261027-B-A-003); Team C still has to wire its surfaces (C-0172) to this API in place of its own draft
  store (HO-20261027-B-C-005); signing is not bound to the user's key. Also (draft doc Limits): the host must
  pass the real data folder: with an empty or wrong one, ops.identity gives the single-operator default and
  four-eyes is off; the audit chain has no key (dropping trailing rows that name no version and rewriting the
  head, or recomputing the whole chain, still passes verify); names are self-asserted: under four-eyes a
  registered user may sign with a model-family word in the name, never with the draft's own model name.
- Evidence needed before switch-on: the two handoffs closed; a scored draft run on the real model
  with its run record (row 40); an independent review.

#### 29. Assistant model (row 40)

- Development owner: Team C for the provider and runtime (EQ-C-0170 provider interface, EQ-C-0171 self-hosted runtime
  and licence gate); Team B for the scoring (row 38) and this record. Tier 3, presentation only: it explains and
  drafts; it never computes a risk number, and every number it shows comes through the gate (row 37) from a cited row.
- Default: Gemma 4 on Ollama on loopback (`backend` openai_compat, `base_url` http://127.0.0.1:11434/v1, a local tag
  such as `gemma4:12b`; `*-cloud` tags are refused as an external send), temperature 0. Off unless `assistant.json`
  sets `"enabled": true`. The optional Claude API backend is allowed by Sam (decision D25, 2026-10-27) but ships
  off: it needs the Keychain key `econquest-anthropic` and `allow_external` true in `assistant.json`, sends prompts off
  the machine, and is always refused for client-scope material. Its runs are recorded and scored like the default.
- Recorded at run time, for every scored run and every saved draft: model tag, weights digest (the Ollama model id),
  system prompt sha256, seed and tool mode (model or host). Gaps: the openai_compat request sends no seed today
  (HO-20261027-B-C-003); the weights digest is supplied by the host (`ModelInfo`), not read back from Ollama.
- Licence: register row `model_gemma_4` (Apache-2.0 per Team C) is UNVERIFIED until Sam approves; until then the
  C-0171 licence gate refuses to start the provider.
- Known limitations: not scored on the real model (only the oracle and the stub); behaviour on paraphrased injection
  and false refusals unknown; third-party weights, no training data review.
- Evidence needed before switch-on: Sam's approval of the licence row; a pass bar v2 PASS on set v2 with the run
  record above; the seed sent; an independent review; a change record for the switch-on.

## Calibration status at a glance

| Status | Components |
|---|---|
| Fitted on real data | GARCH 12-month FX vols (10a, Tier 1), GARCH/DCC (10b), Calm copula loadings (6), econometrics (11), nowcast (19, research) |
| Fitted but not in use (gate not cleared) | Layer 1 `layer1_fitted` (2) |
| Paper-mode, in production | Scorecard (1), layer 1 live path (2), layer 2 (3), layer 3 (4), layer 4 (5), layer 5 (6), layer 6 (7), liquidity (8), stress (9), signals (16) |
| Judgement thresholds | Limits (14), alerts (15) |
| Dormant for lack of data | CDS pricer (12), benchmark scoring (13), event stress index (18), restructuring haircuts (22) |
| Display or research only | DSA signal 26 (17), shadow ratings (20), sovereign depth views (28), macro depth and TOT_OIL (29) |
| Off by switch, not independently validated | Text stress index (30), analyst overlay (31), conflict escalation (35), assistant draft notes (39), assistant model (40, not scored) |
| Control tools | Client-safe run (23), monitoring (24), calendar-gated tests (25), MVP pack and sign-off (26), backtest explainer (32), validator replication kit (33), hazard refit rehearsal (34), assistant tool registry (36), assistant QA gate (37), assistant evaluation set (38) |

Changes: 2026-10-23 first version. 2026-10-25 refreshed to 0.7.0 (EQ-B-0121): rows 17-27 added; rows 3, 7, 9, 10a
and 12 and details 6-9 and 14 updated; VF-001 closed. 2026-10-26 (EQ-B-0139): rows 28-31 and details 17-20 for the
PI-13 components; row 9 notes TOT_OIL is outside `scenarios.json`. 2026-10-26 (EQ-B-0144): rows 32-35 and details
21-24 for the PI-14 components (GOV-055 to GOV-058). 2026-10-27 (EQ-B-0149): rows 36-40 and details 25-29 for
the PI-15 assistant components (GOV-059 to GOV-063); row 39 and detail 28 filled when EQ-B-0148
reached review.
