# Model-risk self-assessment (SR 11-7 style)

Date: 2026-10-25. Ticket EQ-B-0116 (PI-11). Author: Team B AGENT-07. Model state: release 0.7.0, as_of 2026-10-23.
Addendum 2026-10-26 (EQ-B-0139, AGENT-05): the four PI-13 components are added to the inventory (rows 28 to 31) and
to sections 1 and 10 and the gap list (G-10). No status in the summary table changes.
Addendum 2026-10-26 (EQ-B-0144, AGENT-05): the four PI-14 components are added the same way (rows 32 to 35, G-11,
GOV-055 to GOV-058). No status in the summary table changes.
Addendum 2026-10-27 (EQ-B-0149, AGENT-05): the five PI-15 assistant components are added the same way (rows 36 to
40, G-12, GOV-059 to GOV-063). No status in the summary table changes.
- Release base (shared `data/`, 100,000 requested paths): VaR99 66.78, ES99 88.48, EL 4.10 (82% of 5, warning),
  L-VaR99 72.06 $mm.
- MVP desk base (`data/mvp` e60bbc7c…c888, run 20261025T183022-base): 66.21 / 87.91 / 4.01 / 71.49.

**This is a self-assessment, not an independent validation.** The author is on the team that built the model
(policy principle 4; GOV-042 open). It checks the governance pack against an SR 11-7 style checklist. It finds gaps
and turns real gaps into tickets. It changes no model number, parameter, data file or restriction.

A two-page summary for the validator is in
[`../validation/engagement/self-assessment-summary.md`](../validation/engagement/self-assessment-summary.md).

**Status scale:**
- **Met:** the control exists, is current and has evidence.
- **Partly met:** the control exists, but it is stale or incomplete.
- **Not met:** the control is missing or not operating.
- **Not yet testable:** the evidence cannot exist before a calendar date.

## Summary

| # | Area | Status | Main gaps | Remediation |
|---|---|---|---|---|
| 1 | Model inventory and tiers | Partly met | Inventory at 0.1.4; about 11 components built since are missing; VF-001 still open | EQ-B-0121 |
| 2 | Development documentation | Partly met | Dossiers and sensitivity tables at 0.1.5; governance README and change control quote 0.1.0-era runs; CDS pricer has no validation document (dormant) | EQ-B-0122, EQ-B-0126; GOV-040 |
| 3 | Conceptual soundness | Partly met | Most Tier 1 parameters are judgement; Layer 1 refit not cleared; the tail is set by dependence judgement | Existing: GOV-006/013/018/019/021/024, EQ-B-0117, D11 |
| 4 | Data quality | Partly met | 16% of Inputs cells live; 396 hand-entered cells unattested; licence register not baselined; gate holds pending | Mac pass steps 5, 8, 10, 12; GOV-010/036 |
| 5 | Ongoing monitoring and outcomes analysis | **Not met** (built, not operating) | Forecast record stopped 2026-10-21 (60 backfilled rows); one benchmark snapshot and no job to add more; monitoring last run 2026-10-24 | EQ-B-0125; Team C handoff; Mac step 11 |
| 6 | Benchmarking | Partly met / not yet testable | No outcome scoring before 2027-10-23; CDS-implied PD empty; scoring would rest on one snapshot | EQ-B-0125; GOV-040 |
| 7 | Independent validation | **Not met** | No validator (GOV-042); engagement pack at 0.1.5; data-room licence filter not defined | D8; EQ-B-0126 |
| 8 | Governance and change control | Partly met | Single operator (EXC-001/002/004, expiring 2027-01-22); no archived base run since 2026-10-24 18:00; change log stale; policy silent on method rules and Tier 1 data batches | EQ-B-0122, EQ-B-0123; D8 |
| 9 | Use restrictions | Partly met | Licence restrictions that bind client output (EXC-003, EXC-005, GOOGLEFINANCE, Cruces-Trebesch) are not in policy section 6; 6.1 and 6.8 text stale | EQ-B-0122 |
| 10 | Limitations | Met, refresh due | Issues log dated 2026-10-23 with stale statuses; new limitations (EL band, client-safe gap, two bases) not logged as GOV items | EQ-B-0124 |

## 1. Model inventory and tiers

**Expectation:** a complete, current inventory with each model's purpose, use, owner, tier, validation status and
limitations.

**Evidence:**
- [model-inventory.md](model-inventory.md): 16 components at this assessment's date, with tier, calibration, last
  validation document and frequency. Since EQ-B-0121 it has 31 summary rows on the 0.7.0 base; rows 28 to 31
  (EQ-B-0139) are the PI-13 components: sovereign depth views (`rules/sovereign.py`, `validation/depth_views.py`,
  `imfprog_v1`), macro depth views and the TOT_OIL research scenario (`rules/macro.py`,
  `validation/macro_depth.py`), the text stress index (`rules/text.py`, `validation/text_index.py`, `tsi_lex_v1`)
  and the analyst overlay (`validation/analyst_overlay.py`). All four are Tier 3, off or display only, and not
  independently validated. Rows 32 to 35 (EQ-B-0144) are the PI-14 components: the backtest explainer
  (`validation/backtest_explainer.py`), the validator replication kit (`validation/validator_kit.py`), the layer-1
  hazard refit rehearsal (`validation/hazard_rehearsal.py`, PR-1) and the conflict escalation model
  (`rules/escalation.py`, `validation/escalation.py`, `esc_ladder_v1`, off). The first three are control tools; none
  is independently validated.
- [model-risk-policy.md](model-risk-policy.md) section 2: the tier rules.
- `inventory_status()` in `econquest/validation/governance.py`: the live facts.
- Row 10a (GARCH 12-month FX marginals) is Tier 1 since Sam's card of 2026-10-25 02:06Z.

**Gaps:**
- **G-01.** The inventory is dated 2026-10-23 and quotes the 0.1.4 base (74.35 / 96.48). Components built since
  are missing:
  - DSA and signal 26 (switched on for display, CHG-20261024T165855Z-06438f; PD overlay off);
  - the macro scenarios and EMDEF_BRA in the stress library;
  - shadow ratings (a scheduled job);
  - nowcast;
  - restructuring and haircut fit;
  - event index (off, Tier 1 when switched on);
  - the client-safe run;
  - model monitoring;
  - calendar-gated tests;
  - the MVP research pack and sign-off;
  - the pre-trade what-if (EQ-B-0114, in progress).

  VF-001 is still Open in [findings-tracker.csv](../validation/findings-tracker.csv), although row 10a is now Tier 1.
- **G-10 (2026-10-26).** The four PI-13 components (inventory rows 28 to 31) have only their authors' tests and
  documents. None is independently validated, and each has a stated switch-on evidence list (inventory details 17
  to 20). Nothing reported depends on them today, so the gap matters only at switch-on or wiring.
- **G-11 (2026-10-26).** The four PI-14 components (inventory rows 32 to 35, details 21 to 24) are not independently
  validated. Two limit evidence the validator relies on: the forecast record cannot explain its one exception from
  recorded inputs (GOV-055), and on the DEMO data room the replication kit reruns 42 of 177 checks, with 93 never
  rerunnable by an outsider under the licence filter (GOV-056). The hazard rehearsal passed no specification, so
  Layer 1 stays paper (GOV-057); the escalation model is off without UCDP (GOV-058).
- **G-12 (2026-10-27).** The five PI-15 assistant components (inventory rows 36 to 40, details 25 to 29: tool
  registry, QA gate, evaluation set, draft notes, the assistant model) are not independently validated. The model
  (default Gemma 4 on Ollama) has not been scored on the evaluation set, only the oracle and the stub; its licence
  row is UNVERIFIED; the seed is not sent, so a run cannot yet be repeated from its record (GOV-061, GOV-063). The
  QA gate is the control on what is shown and has stated limits (GOV-060). The assistant is Tier 3, ships off and
  never computes a risk number, so the gap matters at switch-on.

**Remediation:** EQ-B-0121; G-10 inventory entries EQ-B-0139, review at switch-on (GOV-051 to GOV-054); G-11
inventory entries EQ-B-0144 (GOV-055 to GOV-058); G-12 inventory entries EQ-B-0149 (GOV-059 to GOV-063),
score of the real model before switch-on.

## 2. Development documentation

**Expectation:** documentation detailed enough that a party unfamiliar with the model can understand its design,
theory, data, limitations and use.

**Evidence:**
- One validation document per component in [`docs/validation/`](../validation/README.md), with the 11-step review
  checklist.
- The SR 11-7 style dossier ([dossier/README.md](../validation/dossier/README.md)): parts 1 and 2, nine layer
  dossiers, sensitivity tables and the use-restriction review.
- Release notes 0.1.1 to 0.7.0 with base restatements ([releases/](releases/)).
- Method rules in [indicator-rules.md](../validation/indicator-rules.md) and data limits in
  [data-limitations.md](../validation/data-limitations.md).
- The MVP sign-off: [mvp-numbers-signoff.md](../validation/mvp-numbers-signoff.md).

**Gaps:**
- **G-08.** The dossier, the sensitivity tables and the engagement pack describe 0.1.5. The sensitivity headline
  base is 73.00 at 32,768 paths, against 66.78 today. Five releases of changes have not been carried into the layer
  dossiers.
- **G-03.** [README.md](README.md), [change-control.md](change-control.md) and
  [revalidation-routine.md](revalidation-routine.md) still quote "currently 0.1.0" and reference base
  20261023T111315-base (68.02 / 86.92 / 1.87).
- The CDS pricer has no validation document (GOV-040). It is dormant and blocked by restriction 6.7, so this is
  accepted until quotes exist.

**Remediation:** EQ-B-0126 (G-08), EQ-B-0122 (G-03).

## 3. Conceptual soundness

**Expectation:** design and theory are justified, calibration is supported by data, and the model's sensitivity
to its key assumptions is known.

**Evidence:**
- Each dossier labels its evidence as fitted, judgement or synthetic.
- Fitted on real data: GARCH 12-month FX vols (Tier 1, official FX-only history) and the Calm copula loadings.
- Judgement: layer 1 coefficients (`paper_standardized`), layer 2 weights, regime rules and transition matrix,
  LGD means and spread, copula nu, scenario sizes, limits.
- Sensitivity tables show the tail is set by dependence, not by PDs or LGDs:
  - the global switch at 0.4 moves VaR99 by +15%;
  - the loadings move it by -13%;
  - nu moves ES99 by -13%.
- The Layer 1 refit on the World Bank panel did not clear the gate: AUC 0.613 on the current list and 0.597 on
  crag_v1, against a bar of 0.75 (EQ-B-0104; [hazard-refit-wb-interim.md](../validation/hazard-refit-wb-interim.md)).
- Shared base and MVP base are reconciled cell by cell (sign-off section 4).

**Gaps:** these are covered by existing items, so no new ticket. All are data-gated:
- GOV-006 and GOV-007 (Layer 1), with EQ-B-0117 and D11;
- GOV-013 (layer 2 market term);
- GOV-018 and GOV-019 (regime cliff and matrix);
- GOV-021 (nu);
- GOV-024 (LGD; refit plan B-0104 parked, no Cruces-Trebesch values usable);
- GOV-026 (scenario sizes).

The self-assessment agrees with the dossier: no Tier 1 number is yet estimated on outcome data.

## 4. Data quality

**Expectation:** data are suitable for the model: relevant, accurate and complete, with lineage, quality checks and
a record of known gaps.

**Evidence:**
- Quality gate and review ledger (`data/live/review.csv`, `review_ledger.csv`).
- Per-cell provenance and an audit trail (`data/audit_trail.csv`, 1,980 rows).
- Licence tags with a client-output check (`audit.client_output_reason`, `econquest/ops/licence_rule.py`).
- The frozen MVP dataset with its sha256 and cell-level diffs between freezes (sign-off section 1a).

**Coverage on shared data** (from the audit trail):

| Table | Live | Seed or held |
|---|---|---|
| Inputs (1,494 cells) | 245 | 1,249 |
| Country Profile | 71 | 19 |

There are also 396 hand-entered cells marked UNATTESTED: 378 in adjustments and 18 in prediction markets.

**Gaps (none of them new Team B work):**
- live coverage (GOV-010, GOV-036);
- attestation of the hand-entered cells (Mac step 10);
- the gate holds (Mac step 8);
- the licence register is not baselined, so client-safe runs need `--allow-unapproved-register` (Mac step 5);
- the parked pulls, BIS CBS and WB broad money (Mac step 12);
- GOV-044's status is out of date: CRAG defaults are now in `data/panel/` (logged under EQ-B-0124).

## 5. Ongoing monitoring and outcomes analysis

**Expectation:**
- Monitoring is in place and operating, with process verification, benchmarking and outcomes analysis
  (backtesting).
- Thresholds trigger action.

**Evidence the controls are built:**
- [monitoring.md](../validation/monitoring.md) and `validation/monitoring.py` cover PD and metric drift, input PSI,
  stability, champion/challenger and the review calendar.
- `econquest/ops/schedule.py` defines daily `record`, daily `morning` run and report, and weekly
  `model_monitoring`.
- [calendar-gated-tests.md](../validation/calendar-gated-tests.md) gives the 250-day VaR/ES test (gate 2027-07-14)
  and the 12-month benchmark scoring (gate 2027-10-23).
- An interim backtest report exists (60 clean days, 1 exception).
- The idea log holds 71 open ideas.

**Evidence the controls are not operating:**
- Monitoring last ran 2026-10-24 12:53. Its window ends at 20261024T124804-base. It raised 36 red and 10 amber
  alerts, most of them drift explained by recorded changes.
- `data/forecast_record.csv` has 60 rows, all backfilled with the current book. The last row is dated 2026-10-21.
- The schedule is not installed (Mac step 11).
- The 120-month backtest is synthetic (restriction 6.3).
- 69 of the 71 ideas are unmarked.

**Gaps:**
- **G-06. Outcomes evidence is not accruing.**
  - The 250-day gate date assumes a row every weekday from 2026-07-30. Each weekday without a record row moves the
    first possible formal test later.
  - The first window would be about a quarter backfill (disclosed by the test, but still backfill).
  - First-mac-pass section C says the test "runs automatically from 2027-07-14". That is true of the job, not of
    the evidence.
- **G-07. Benchmark history is one snapshot** (2026-10-23, 18 rows). No scheduled job takes another. The 12-month
  scoring on 2027-10-23 would rest on 18 observations of one date.
- **Monitoring alerts mix two kinds of drift:** drift explained by a recorded change id, and unexplained drift. So
  red alerts carry little signal.

**Remediation:**
- EQ-B-0125 (Team B part).
- A handoff to Team C for a monthly benchmark snapshot job: `econquest/ops/schedule.py` is Team C's file. EQ-B-0125
  writes the spec.
- Mac step 11 installs the schedule.

## 6. Benchmarking

**Expectation:** model outputs are compared with alternative models and external data, and the differences are
explained.

**Evidence:**
- The PD benchmark harness ([benchmarks.md](../validation/benchmarks.md)) compares hazard, rating-implied and
  spread-implied PDs, CDS (empty) and the prediction-market PD (prior off).
- The rating-implied challenger inside Layer 1.
- The monitoring champion/challenger table.
- The independent recomputation (`validation/replicate.py`, PASS 141 on release inputs).
- The client-safe comparison against the house run ([client-safe-run.md](../validation/client-safe-run.md)).
- The econometrics toolkit (Student-t copula preferred).

**Gaps:**
- G-07, as above.
- CDS-implied PD is empty (GOV-040).
- No outcome-based score exists before 2027-10-23 (not yet testable).

**Remediation:** EQ-B-0125.

## 7. Independent validation

**Expectation:** validation by staff or a third party with the competence and independence to challenge the model,
with findings tracked to closure.

**Evidence:**
- The validator engagement pack ([engagement/](../validation/engagement/README.md)): RFP, scope, 25 questions and
  timeline.
- The replication pack and the findings workflow ([findings-workflow.md](../validation/findings-workflow.md)), with
  a hash-chained log and four-eyes closure.
- Disclosure of EXC-003/EXC-005 data to a validator under NDA, approved by Sam.
- Internal second-line style reviews by agents (MVP sign-off, editorial review, security passes). These are not
  independent.

**Gaps:**
- **No validator is appointed.** GOV-042 is open, and every Tier 1 sign-off is owner-only. This is decision D8 in
  [first-mac-pass.md](../../team/first-mac-pass.md).
- **G-09.**
  - The engagement pack is at 0.1.5, and its freshness note asks for a refresh after any release.
  - The pack's own note says the shareability of third-party data was "not checked".
  - No data-room file list with a licence filter exists. It must exclude GOOGLEFINANCE files and the
    Cruces-Trebesch workbook, and admit EXC-003/005 data only under NDA.

**Remediation:** EQ-B-0126 makes the pack ready for D8 without asking Sam anything.

## 8. Governance and change control

**Expectation:** policies, roles and responsibilities; change control with approvals; an inventory of changes; and
records that tie every reported number to its code and data.

**Evidence:**
- Parameter and limit files change only through `econquest change`, with a hash-chained `data/approvals/log.jsonl`.
  The log holds 7 Tier 1 changes (all approved by Sam) and 1 baseline (limits.json, GOV-041). Drift is checked by
  `change verify`.
- Release notes and package notes run from 0.1.1 to 0.7.0, with `RELEASE-HASHES.json`.
- Agent edits are checkpointed (`teamctl checkpoint`).
- Decision packs are in [decisions/](decisions/).
- Second-approver onboarding is in [second-approver.md](second-approver.md) (`data/users.json`: four_eyes off,
  one user).

**Gaps:**
- **Single operator.**
  - EXC-001, EXC-002 and EXC-004 cover self-approval and expire 2027-01-22 unless renewed.
  - This needs D8 or a named second approver, which is Sam's choice. No new ticket.
- **G-04. Records.**
  - No base run has been archived in `outputs/store` since 20261024T180018-base. The 0.5.0, 0.6.0 and 0.7.0 bases
    exist only as release-note figures and replication pins. Policy principle 2 requires a run id for every
    reported number; VF-014 and VF-017 are open.
  - The MVP base is archived, but only in the pack store (`outputs/reports/mvp/store`).
  - [change-log.md](change-log.md) was generated 2026-10-24 01:17 from 70 runs. The store now holds 159.
- **G-02 (governance part). The policy does not say who approves some kinds of change:**
  - Tier 2 method rules (indicator-rules 16-18, decided by the Team B lead in 0.7.0);
  - Tier 1 data batches (first values of 1.8, 1.5, 2.11, held for D2);
  - and its roles table has no place for the agent teams that develop and review.

  The 0.7.0 note signs "Owner: Team B AGENT-08", while the policy names Sam as owner.

**Remediation:** EQ-B-0123 (G-04), EQ-B-0122 (G-02).

## 9. Use restrictions

**Expectation:** model use is consistent with its limitations, with restrictions stated, enforced and reviewed.

**Evidence:**
- Policy section 6 holds restrictions 6.1 to 6.9. The [use-restrictions review](../validation/dossier/use-restrictions-review.md)
  recommends keeping all of them.
- The research pack carries "INTERNAL RESEARCH" and "not investment advice". These are checked by
  `mvp_pack check` and the editorial review (0001-0096).
- The prediction-market prior is off (VF-013).
- The client-safe route and the licence rule are enforced in code. The 0.7.0 EQ-B-0106 run shows client-safe
  VaR99 +9.2% against house.

**Gaps:**
- **G-02 (restrictions part).** Section 6 does not list the restrictions that actually bind client output today:
  - EXC-003 (IMF data internal only);
  - EXC-005 (theratesapi VES/NGN/PKR/VND/ZMW internal only);
  - GOOGLEFINANCE files restricted;
  - Cruces-Trebesch licence unverified.

  These live only in the issues log and in code.
- 6.8 still says the limits are unsigned, although GOV-041 was resolved 2026-10-24.
- The counts in 6.1 date from 2026-10-23.

**Remediation:** EQ-B-0122. The text is reworded only; no restriction is lifted. Lifting stays with Sam and the
validator.

## 10. Limitations

**Expectation:** known limitations are documented, tracked and reflected in how outputs are used and labelled.

**Evidence:**
- [issues-log.md](issues-log.md): GOV-001 to GOV-047 and EXC-001 to EXC-005 at this assessment's date; GOV-048
  to GOV-050 since (EQ-B-0124) and GOV-051 to GOV-054 for the limitations of the PI-13 components (EQ-B-0139):
  sovereign depth views, macro depth and TOT_OIL, text stress index, analyst overlay; GOV-055 to GOV-058 for the
  PI-14 components (EQ-B-0144): backtest explainer, validator replication kit, hazard refit rehearsal, conflict
  escalation; GOV-059 to GOV-063 for the PI-15 assistant components (EQ-B-0149): tool registry, QA gate,
  evaluation set, draft notes, assistant model.
- [findings-tracker.csv](../validation/findings-tracker.csv): VF-001 to VF-019, hash-chained.
- Section 5 of the MVP sign-off.
- The labelled gaps: EMDEF_BRA is "not run: no BIS CBS exposures".
- Every validation document ends with its own limitations.

**Gaps:**
- **G-05.** The issues log is dated 2026-10-23, and the governance README says "GOV-001 to GOV-045".
  - **Stale statuses:**
    - GOV-006 (WB refit not cleared);
    - GOV-027 (EMDEF_BRA);
    - GOV-044 (CRAG now present).
  - **Limitations that are not GOV items:**
    - EL sits in the warning band (80-82% of 5) while EL is a net-of-carry figure (VF-011, D1);
    - the client-safe gap;
    - the two bases (shared and MVP).
  - **Findings still open after the cause was fixed:**
    - VF-001 (row 10a is now Tier 1);
    - VF-008 (`tests/test_layer3_regime.py` now exists).
  - **Errata:** VF-015 and VF-016 are open, and the 0.7.0 note says "75 DRIFT" for the MVP replication (79 since
    R48-R51).

**Remediation:** EQ-B-0124. Closures go through `findings close` by a closer with no conflict. No agent closes a
finding under EXC-004.

## Gap list

| Gap | Area | Severity | Gap | Ticket or route |
|---|---|---|---|---|
| G-01 | 1 | High | Inventory stale (0.1.4) and incomplete (about 11 components missing); VF-001 open | EQ-B-0121 (PI-11, AGENT-05) |
| G-02 | 8, 9 | High | Policy v1: licence restrictions not in section 6; 6.1 and 6.8 stale; no class for method rules or Tier 1 data batches; agent roles undefined | EQ-B-0122 (PI-11, AGENT-05) |
| G-03 | 2 | Medium | Governance README, change control and revalidation quote 0.1.0 and the 68.02 reference run | EQ-B-0122 |
| G-04 | 8 | High | No archived base run since 2026-10-24 18:00; release bases are pins only; change log stale (70 of 159 runs) | EQ-B-0123 (PI-11, AGENT-08, with EQ-B-0118 and Team C on code_hash) |
| G-05 | 10 | Medium | Issues log and tracker statuses stale; new limitations not logged; errata | EQ-B-0124 (PI-11, AGENT-05) |
| G-06 | 5 | High | Forecast record stopped 2026-10-21 (60 backfilled rows); 250-day date and section C wording assume daily rows | EQ-B-0125 (PI-12, AGENT-05); Mac step 11 |
| G-07 | 5, 6 | High | One benchmark snapshot and no scheduled job; monitoring alerts mix explained and unexplained drift | EQ-B-0125; handoff to Team C (schedule.py) |
| G-08 | 2 | Medium | Dossier, sensitivity tables and engagement pack at 0.1.5 | EQ-B-0126 (PI-12, AGENT-07) |
| G-09 | 7 | Medium | No data-room file list with a licence filter for the validator | EQ-B-0126 |
| G-10 | 1, 7, 10 | Low | PI-13 components (inventory rows 28 to 31) not independently validated; switch-on evidence open | EQ-B-0139 (inventory, done); GOV-051 to GOV-054 |
| G-11 | 1, 5, 7, 10 | Medium | PI-14 components (inventory rows 32 to 35) not independently validated; record cannot explain its exception; DEMO room reruns 42 of 177 checks (93 never rerunnable by an outsider); Layer 1 refit passed nothing; escalation off without UCDP | EQ-B-0144 (inventory, done); GOV-055 to GOV-058; HO-20261026-B-A-011 |
| G-12 | 1, 3, 7, 9, 10 | Medium | PI-15 assistant components (inventory rows 36 to 40) not independently validated; real model (Gemma 4) not scored; model licence row UNVERIFIED; seed not sent; QA gate limits (paraphrased injection, oblique names, cross-sentence valence) | EQ-B-0149 (inventory, done); GOV-059 to GOV-063; HO-20261027-B-C-003 |
| — | 7, 8 | High | No independent validator; single-operator exceptions expire 2027-01-22 | Sam: D8 (existing); GOV-042 |
| — | 3 | High | Tier 1 calibration mostly judgement; Layer 1 refit not cleared | Existing GOV items, EQ-B-0117, D11 |
| — | 4 | High | Live coverage 16%; 396 unattested cells; licence register not baselined | Mac pass steps 5, 8, 10, 12; Team A |

## Method and limits of this assessment

- Read from the governance pack, the dossiers and the logs on the shared folder as of 2026-10-25. Also used: the
  run store (159 runs), the approvals log (22 events), the forecast record, the benchmark history and the
  monitoring outputs.
- Nothing was rerun, so the statuses rest on the recorded evidence. No GOV or VF status was changed: the
  proposals are in EQ-B-0124.
- SR 11-7 is used as a checklist only. The desk is not a regulated bank, and the assessment claims no compliance.

## Remediation status (2026-10-26)

| Gap | Ticket | Status |
|---|---|---|
| G-01 | EQ-B-0121 | Done: inventory refreshed to 0.7.0, rows 17 to 27 added; VF-001 resolved in the register (Sam's card 2026-10-25 02:06Z) |
| G-02, G-03 | EQ-B-0122 | Done, pending Sam: policy version 2 (licence restrictions 6.10 to 6.14, restated 6.1, 6.4, 6.6, 6.8, roles, change classes). New decision rights are marked [pending D12]; HO-20261025-B-C-019 asks Team C to add D12 to first-mac-pass section B. Change control, revalidation routine and governance README now quote 0.7.0 |
| G-04 | EQ-B-0123 | Done: 0.7.0 base archived as `20261025T235026-base` with the 0.7.0 package code (code_hash 6f600301e4928edb, data_hash 308b73ca9e257627), bit-identical to pins R48-R51. 0.5.0 and 0.6.0 are archived as labelled reconstructed entries, bit-identical to pins R40-R47. Change log regenerated (162 runs) |
| G-05 | EQ-B-0124 | Done: GOV-006, GOV-027 and GOV-044 updated; GOV-048 to GOV-050 added; VF-008 (3 new tests), VF-015 and VF-016 resolved; 0.7.0 note erratum (79 DRIFT). Findings log head 24:0d298b422bd2... |
| G-06 | EQ-B-0125 | Record rules done (HO-20261025-A-B-019): past rows never rewritten, lagging prices marked or excluded; daily rows wait for Mac step 11 |
| G-07 | EQ-B-0125 | Team B part done: `validation/benchmark_job.py` (monthly snapshot, due once per calendar month, append-only, drift classed explained / as-of only / unexplained by recorded change id) and `validation/drift_cause.py` (the same classes on monitoring drift alerts). Simulated on a copy of the shared data: 2026-11-02 appends 18 rows, 6 moved countries all explained; base unchanged. Schedule entry with Team C (HO-20261026-B-C-003); Mac step 11 installs it |
| G-08, G-09 | EQ-B-0126 | Open (PI-12) |
| G-10 | EQ-B-0139 | Inventory part done: rows 28 to 31 and details 17 to 20, GOV-051 to GOV-054 logged. Validation stays open until a component asks to switch on |
| G-11 | EQ-B-0144 | Inventory part done: rows 32 to 35 and details 21 to 24, GOV-055 to GOV-058 logged. Open: record inputs (GOV-055), validator room inputs (GOV-056, HO-20261026-B-A-011), D11 (GOV-057), UCDP (GOV-058) |
| G-12 | EQ-B-0149 | Inventory part done (2026-10-27): rows 36 to 40 and details 25 to 29, GOV-059 to GOV-063 logged; row 39 filled from EQ-B-0148 (Done). Open: score the real model (GOV-061), licence row and seed (GOV-063), gate limits (GOV-060), draft wiring (GOV-062, HO-20261027-B-C-005, HO-20261027-B-A-003) |
