# Usability task script for Sam (PI-5, EQ-C-0063)

About 45 minutes on your own Mac, alone, with the release that includes EQ-C-0063 (the release after 0.1.5).
Do the five tasks in order, without asking anyone and without reading code. The README and `--help` are
allowed: using them is normal and worth noting. Then fill in `sus-questionnaire.md`.

This is how the real SUS score is produced. The figure in `usability-pass-PI4.md` section 7 is the reviewer's
estimate, not a user score. Your answers replace it.

## Before you start (2 minutes)

- Use a normal working day's data. Nothing in this script writes the live workbook unless you choose to in task 3.
- Keep a terminal and the GUI (`econquest gui`) open.
- For each task, write down three things in the table at the end: minutes taken, where you got stuck (if anywhere),
  and whether you finished.

## Task 1: daily run, record and report (W1)

1. `econquest run --stress --backtest`
2. From the **last line only**, write down VaR99, ES99 and expected loss with their units.
3. Look at the run-gate warning: it should be **one line** with the count and `econquest attest --list`.
   Note whether it is clear what to do about it.
4. `econquest record`, then `econquest report`. Open `outputs/reports/latest.html`.

Done when: you have the three numbers and the report is open.

## Task 2: fetch live data and decide on held cells (W2)

1. `econquest fetch` (on the Mac this reaches the IMF, World Bank and BIS). If the network is off, it should stop
   within seconds with one line per feed.
2. `econquest review list --pending`: how many cells are held?
3. Decide them in one command, for example
   `econquest review decide --all-pending --decision hold --author Sam --self-approved --note "PI-5 usability test"`
   (choose `apply` or `reject` instead if that is the right call for the data).
4. `econquest fetch --apply`.

Done when: `review list --pending` shows no held cell without a decision.

## Task 3: build and preview the workbook plan (W3)

1. GUI, Data & jobs: click **Save publish plan (no write)**.
2. `econquest publish-preview --baseline <previous plan or a batchGet of the live tabs>` (see README "Republish
   preview" for the baseline).
3. Optional: publish for real with `econquest publish --write` (Keychain token). Only if you would do it today anyway.

Done when: the preview shows the changes you expect.

## Task 4: publish one country note through editorial (W4)

1. `econquest notes --country Argentina` (or any country). Note the file name it prints.
2. `econquest editorial draft --file outputs/notes/country-note-<country>-<as_of>.html ...`
3. `econquest editorial review ...`, then `econquest editorial checklist <id> --show`.
4. `econquest editorial checklist ...` with every restriction `--show` listed, then `editorial publish` and
   `editorial verify`.

Note whether you knew which `--exc` id to use for a compliance self-sign. (Known gap U13: there is no issues-log entry
for it yet.)

Done when: `editorial verify` passes.

## Task 5: install and upgrade (W5)

1. `bash install.sh --help`: read the upgrade rules.
2. Run the new release's `install.sh` (`install.command` in Finder works too). This is also the first time the venv
   and pip steps are run on a Mac (U18): note anything pip prints.
3. `econquest --version`.

Done when: the version is the new release and `econquest run` works.

## GUI extras (2 minutes, optional)

- Trade ideas tab: does the text make clear which run opened the newest ideas, against the run chip at the top?
- Data & jobs: **Trade-idea report (read only)** and **Update trade-idea log from the latest run**. Do they do what
  the label says?

## Your notes

| Task | Minutes | Stuck where (or "no") | Finished (y/n) |
|---|---|---|---|
| 1 daily run |  |  |  |
| 2 fetch and held cells |  |  |  |
| 3 workbook plan |  |  |  |
| 4 country note |  |  |  |
| 5 install and upgrade |  |  |  |

## Then

Fill in `sus-questionnaire.md` straight away, with your first reaction to each statement. Send the table above and
the ten answers to AGENT-08 (or paste them into the Team C thread). AGENT-07 records them as "Sam's SUS score, <date>,
<release>" next to the estimate, and compares the two.
