# Usability pass, PI-4 (EQ-C-0048)

Author: C/AGENT-07, 2026-10-23. Release under test: econquest 0.1.4 plus the EQ-C-0047 work, on a temp copy of
`data/` and `outputs/`. Everything ran offline: HTTP(S) proxies pointed at a closed port, no Sheets token in the
environment, and the installer ran into a temp `HOME` with `ECONQUEST_INSTALL_SKIP_VENV=1`. Nothing wrote to the live
workbook. No test needed a network call.

This is an **expert walkthrough** (scripted task tests by the agent that owns the views), not a test with users.
The SUS figure in section 4 is an **estimate, not a user score**. Sam's score comes from `sus-questionnaire.md`.

## 1. The five workflows, and why these

| # | Workflow | Why it is in the top five |
|---|---|---|
| W1 | Daily run, record and report (`run`, `record`, `report`) | It runs every business day: `schedule install` sets the morning run and report at 07:00 and the record at 18:20 (C10 scheduled task). Sam reads its output first. |
| W2 | Fetch live data and decide on held cells (`fetch`, `review list/decide`, `fetch --apply`) | It is the only route for new inputs into `data/`, it involves a four-eyes decision, and it is the most error-prone (README "Quality gate", `docs/runbooks/A-fetch-on-mac.md`). |
| W3 | Republish the workbook (`publish --dry-run`, `publish-preview`, `publish --write`) | The workbook is the desk's view (C11), and a wrong write affects every formula Sam keeps. Covered in `docs/runbooks/A-publish.md` and the GUI's Publish button. |
| W4 | Publish a country note through editorial (`notes`, `editorial draft/review/checklist/publish/verify`) | It is the external product, with compliance sign-off (EQ-C-0036/0040/0041) and distribution (EQ-C-0045). It has the most steps. |
| W5 | Install and upgrade (`install.sh` / `install.command`) | Every release goes through it (0.1.4 shipped today), and if it fails nothing else works. Sam does it alone on the Mac. |

Not in the top five: change control (`change`, a few times a quarter), attest (bundled into W1's warning), backup and
restore drill (scheduled), GARCH/econ/limits (single commands with good help text).

## 2. Findings by workflow

Counts are for the walk **before** the fixes. Steps = commands or GUI actions to finish the task on the happy path.
Errors = a step that failed when the documented example was followed. Unclear = a message that does not say what to do
next, or contradicts another. Dead end = the program gives no route to the next step. Missing help = an option or
command with no help text.

| Workflow | Steps | Errors | Unclear | Dead ends | Missing help |
|---|---|---|---|---|---|
| W1 daily run, record, report | 3 | 0 | 3 | 0 | 0 |
| W2 fetch and held cells | 5 | 1 | 2 | 1 | 0 |
| W3 republish the workbook | 5 | 0 | 2 | 1 | 6 |
| W4 country note through editorial | 7 | 4 | 3 | 1 | 0 |
| W5 install and upgrade | 4 | 0 | 2 | 1 | 2 |
| GUI (across tabs) | n/a | 0 | 3 | 0 | 0 |
| **Total** | **24** | **5** | **15** | **4** | **8** |

### Details, with status

| Id | Workflow | Finding | Kind | Status |
|---|---|---|---|---|
| U01 | W1 | `run` prints a 60-line JSON summary with 15-digit floats and no units. VaR99/ES99 are buried mid-screen; the last line is only "Outputs in ...". | unclear | **Fixed**: the last line is now `Run <id> as of <date>: VaR99 74.67 $mm, ES99 95.50 $mm, expected loss 0.46 $mm, L-VaR99 79.95 $mm; global regime Calm; 2,048 paths.` The JSON is unchanged for scripts. |
| U02 | W1 | The run-gate warning (four lines about 396 unattested cells) prints on every command, so it trains Sam to ignore stderr. | unclear | **Fixed in PI-5** (EQ-C-0063): policy unchanged (warn on runs, block Sheets writes); a warning is now one line, `warning: 396 hand-entered cell(s) not attested; run continues (run gate 'warn'). List and fix: econquest attest --list`. A block keeps the full message. |
| U03 | W1 | `record` on 2026-10-23 records 2026-10-21 (the last complete Market History day) and does not say why the date differs. | unclear | Open, Team B (HO-20261023-C-B-010 accepted, EQ-B-0056 in progress on 2026-10-24). Follow-up: add "last complete trading day in Market History" to the `[record]` line. |
| U04 | W2 | `fetch` with no network ran for more than 400 s (stopped by timeout) and printed the same proxy error about 20 times per feed on one ~3 KB line. There is no quick "no network" check. | error | **Fixed by Team A** (EQ-A-0037, HO-20261023-C-A-008): one probe per host; offline `fetch` takes about 4.5 s with one line per feed. |
| U05 | W2 | `review list` said "No review decisions recorded." while 26 cells were held. From the CLI, Sam could not see which cells needed a decision without opening `data/live/review.csv`. | dead end | **Fixed**: `review list` now adds "26 cell(s) held by the quality gate have no decision yet: econquest review list --pending". The new `--pending` lists them (seed, live value, reason) and prints the `review decide` template. |
| U06 | W2 | `review decide` for a held cell needs `--gate-status hold --live VALUE` copied by hand. | unclear | **Fixed** (EQ-C-0052): `review decide --all-pending` or `--cell TABLE KEY COUNTRY` (repeated) decides several held cells at once, live value and gate status taken from review.csv; four-eyes per cell, one ledger row and one action-log row per cell. |
| U07 | W3 | `publish --dry-run` printed "Dry run: ... (pass --write to write the workbook)" and then a second "Dry run: plan saved only ..." line. | unclear | **Fixed**: one "Dry run" line; stdout says "Plan saved. Apply it with any Sheets client ..., or preview it first with `econquest publish-preview`." |
| U08 | W3 | `publish-preview --help`: six of seven options (`--baseline`, `--plan`, `--tolerance`, `--large`, `--dest`, `--spreadsheet-id`) had no help. | missing help | **Fixed**: help with defaults for all of them. |
| U09 | W3 | GUI: the only publish button needs a token ("Paste a Google Sheets OAuth token first."), so Sam could not build or preview the plan from the GUI. | dead end | **Fixed**: "Save publish plan (no write)" button (`publish --dry-run`, no token). The token message now points to it. |
| U10 | W3 | Getting the live baseline for `publish-preview` means fetching `--urls` with a token outside the program. | unclear | Not fixed, by design (the program never reads the workbook). Documented in README "Republish preview". |
| U11 | W4 | README example `--file outputs/notes/argentina.html` does not exist. `notes` writes `country-note-argentina-<as_of>.html` and prints only the folder. | error, dead end | **Fixed** in README: a `notes --country` step and the real file name. |
| U12 | W4 | `editorial review` without `--self-reviewed` fails with "needs an reviewer other than the author ... pass self_reviewed=True": a Python parameter name and a typo, not the CLI flag. | error, unclear | **Fixed** (EQ-C-0052): editorial and compliance messages name `--self-reviewed`, `--conflicts`, `--acknowledge`, `--compliance-approve`, `--self-signed`, `--exc`, `--by`; "a reviewer". |
| U13 | W4 | Compliance self-sign without `--exc` is refused (correct, EQ-C-0041), but nothing says which EXC id applies. The only entry, EXC-001, covers the data quality gate. | error, unclear | Not fixed: needs a governance entry (Team B, issues log) for compliance self-sign. |
| U14 | W4 | README showed `--acknowledge 6.2`, but a seed-data note flags 6.1, 6.2 and 6.3. A refused checklist call records nothing, so every flag has to be repeated. | error | **Fixed** in README: acknowledge every restriction `checklist --show` lists; a refused call records nothing. |
| U15 | W5 | `bash install.sh --help` (or any typo, such as `--upgrade`) ran a full install or upgrade. | dead end | **Fixed**: `--help`/`-h` prints usage and the upgrade rules; an unknown option stops with "nothing was changed". |
| U16 | W5 | The installer's final "Try:" list suggested the deprecated `publish --token ...` (token in shell history). | unclear | **Fixed**: `run`, `review list --pending`, `publish --dry-run`, `publish --write` (Keychain), and one upgrade line. |
| U17 | W5 | The README had no upgrade instructions, and there was no `econquest --version` to check which release is installed. | missing help | **Fixed**: README "Upgrade" paragraph; `econquest --version`; `--data`/`--out` help shows their defaults. |
| U18 | W5 | pip and venv steps not exercised (need PyPI). | n/a | Static review only. |
| U19 | GUI | Trade ideas tab: "Latest run 20261023T163707" next to a run chip showing 20261023T205447 looked like a stale view. | unclear | **Fixed**: "Newest ideas opened by run ... (the run chip above is the latest model run)". |
| U20 | GUI | Pre-trade check shows the saved `pretrade.json` result (Argentina) under a form set to Vietnam, with nothing saying it is an old result. The verdict and reasons went into the page unescaped. | unclear, security | **Fixed**: labelled "Last saved check (outputs/pretrade.json) ...", verdict and reasons escaped. |
| U21 | GUI | Limit reasons read "book book es99_mm ...". | unclear | Open, Team B (HO-20261023-C-B-010, EQ-B-0056 in progress). Still visible in the PI-5 screenshot of Data & jobs. |
| U22 | GUI | No buttons for `ideas log` / `ideas mark`. | unclear | **Fixed in PI-5** (EQ-C-0063), read-only actions only: Data & jobs buttons "Trade-idea report (read only)" and "Update trade-idea log from the latest run". `ideas` is in `ALLOWED_CMDS` but `GUI_SUBCMDS` allows only `report` and `log`; `ideas mark` stays CLI-only. AGENT-09 review in parallel. |

Environment note: twice during the walk, `python -m econquest` failed with "No module named econquest" while the
network mount dropped its working directory ("getcwd: cannot access parent directories"). A rerun worked. This
is the shared mount, not a product issue, and it does not happen on the Mac install.

## 3. Fixes made (Team C files only)

| Fix | Files | Test (`tests/test_usability_fixes.py`) |
|---|---|---|
| Run headline with units as the last line (U01) | `presentation/dashboard.py` (`run_headline`), `cli.py` `cmd_run` | `test_run_headline_leads_with_decision_numbers_and_units`, `test_run_prints_headline_last` |
| `review list` pending hint and `--pending` (U05, U06) | `cli.py` `cmd_review`, `_review_pending`, parser | `test_review_list_points_at_held_cells_without_decision`, `test_review_list_without_review_file_is_unchanged`, `test_review_list_help_mentions_pending` |
| One dry-run message (U07) | `cli.py` `cmd_publish` | `test_publish_dry_run_says_dry_run_once` |
| `publish-preview` help (U08) | `cli.py` parser | `test_publish_preview_options_have_help` |
| `--version`, `--data`/`--out` help (U17) | `cli.py` `main` | `test_version_flag_and_folder_help` |
| GUI dry-run publish button and token hint (U09) | `static/gui.html` | `test_gui_has_dry_run_publish_button_without_token` |
| GUI pre-trade label and escaping (U20) | `static/gui.html` | `test_gui_pretrade_verdict_escaped_and_labelled_as_saved` |
| GUI Trade ideas run label (U19) | `static/gui.html` | `test_gui_ideas_run_label_is_not_confused_with_the_run_chip` |
| `install.sh --help`, unknown options, next steps (U15, U16) | `install.sh` | `test_install_help_and_unknown_option_change_nothing`, `test_install_next_steps_do_not_suggest_the_deprecated_token_flag` |
| README: editorial example, acknowledge rule, upgrade, `--pending`, GUI tabs, `distribute --confirm-new` (U11, U14, U17) | `README.md` | documentation |

No fix changes a default or what a command computes or writes. The run's JSON, the plan files and the exit codes
are unchanged. The new output is one extra line or an opt-in flag.

Screenshots: `docs/gui-trade-ideas.png` (EQ-C-0047, owed) and `docs/gui-data-jobs.png` (the new button), headless
Chromium against the GUI on the temp copy.

## 4. SUS: expert heuristic estimate (estimate, not a user score)

This is the reviewer's guess at how Sam, a single expert operator who wrote the requirements and works in the
terminal, would answer after doing the five tasks on the fixed build. It is not a measurement and must not be
reported as Sam's SUS score.

| # | Statement (shortened) | Estimated answer (1-5) | Contribution | Reasoning |
|---|---|---|---|---|
| 1 | would like to use frequently | 4 | 3 | It is the desk's daily engine and runs on a schedule. Frequency is built in. |
| 2 | unnecessarily complex | 3 | 2 | 40 subcommands, four-eyes ledgers, a run gate, EXC ids. Most of it is required by governance, but it feels heavy for one person. |
| 3 | easy to use | 3 | 2 | The daily path (W1) is easy; W2 and W4 still need copied values, repeated flags and governance ids. |
| 4 | need a technical person | 3 | 2 | Keychain tokens, launchd, `change` proposals and the batchGet baseline are technical. The help text is good, but U04 (offline fetch) and U13 (which EXC id) would send Sam to ask. |
| 5 | functions well integrated | 4 | 3 | GUI, CLI, workbook plans and the ledgers share run ids, dry-runs and the same files. |
| 6 | too much inconsistency | 2 | 3 | Mostly consistent flags (`--write`, `--dry-run`, `--author/--approver`). The editorial messages using Python names (U12) are the main exception. |
| 7 | most people learn quickly | 2 | 1 | Domain-heavy (VaR, ES, copulas) and governance-heavy. A new analyst needs the README and runbooks. |
| 8 | very cumbersome | 3 | 2 | W4 is 7 commands with every checklist flag repeated after a refusal; W2 is one `decide` per held cell (26 today). |
| 9 | felt very confident | 4 | 3 | Dry-runs everywhere, `verify` on every ledger, backups and restore drill, and the run headline. Little fear of breaking the workbook. |
| 10 | needed to learn a lot first | 4 | 1 | Tokens, attestations, change control, editorial and the run gate all have to be learned before the first clean publish. |

**Estimated SUS = 2.5 x (3+2+2+2+3+3+1+2+3+1) = 2.5 x 22 = 55** (plausible range 50 to 62 for this respondent).
Before the fixes the same reasoning gives about 50 (items 3, 4 and 9 one point worse).

The ticket's target is "above 70". By this estimate it is **not met**. The items that hold the score down are
2, 4, 8 and 10, the governance flows. The best next steps, all outside this ticket:

- U12: editorial messages with CLI flags (AGENT-06);
- U13: an issues-log exception for compliance self-sign (Team B);
- U04: a fast offline check in fetch (Team A);
- U06: a batch decision for held cells (`review decide --from-pending`).

Sam's own answers on `sus-questionnaire.md` replace this estimate.

## 5. Tasks to try (for Sam's questionnaire)

PI-5: use `sam-task-script-PI5.md` instead; it updates these tasks for the PI-5 fixes and adds a notes table.

1. Run the daily model and read VaR99, ES99 and EL from the last line: `econquest run --stress --backtest`.
2. After `econquest fetch`, find the held cells and decide one: `econquest review list --pending`, then `review decide ...`.
3. Build and preview the workbook plan without writing: GUI Data & jobs > "Save publish plan (no write)", then `econquest publish-preview --baseline outputs/publish_plan.json` on the previous plan.
4. Publish one country note: `notes --country X`, `editorial draft`, `review`, `checklist --show`, `checklist ...`, `publish`, `verify`.
5. Upgrade: `bash install.sh --help`, then run the new release's `install.sh`, then `econquest --version`.

## 6. Not fixed, and who owns it

| Id | Owner | Ask |
|---|---|---|
| U02 | Sam (attest) | Message fixed in PI-5; the warning goes away only when the 396 cells are attested (`econquest attest`) |
| U03 | Team B (record) | Say "last complete trading day in Market History" in the `[record]` line |
| U04 | Team A (feeds) | Done (EQ-A-0037) |
| U06 | Team C | Done (EQ-C-0052: `review decide --all-pending` / `--cell`) |
| U10 | n/a | By design: the program never reads the live workbook |
| U12 | AGENT-06 (editorial) | Done (EQ-C-0052) |
| U13 | Team B (governance) | Issues-log exception for compliance self-sign, named in the message |
| U18 | AGENT-10 | Exercise venv and pip on the Mac at the next release |
| U21 | Team B (limits) | "book book" in limit reasons |
| U22 | AGENT-09 / AGENT-07 | Done as read-only actions (EQ-C-0063); AGENT-09 reviewing the allowlist change |
| — | AGENT-07 (EQ-C-0047 review) | Done (EQ-C-0063): A2 now says "Newest ideas opened by run ... (the latest model run can be newer)" |

## 7. PI-5 follow-up (EQ-C-0063)

Author: C/AGENT-07, 2026-10-24. Same method as above: expert walkthrough on a temp copy of `data/` and `outputs/`,
offline, no Sheets token, nothing written to the live workbook.

### 7.1 Fixes in this ticket (Team C files only)

| Id | Fix | Files | Tests |
|---|---|---|---|
| U02 | Warn-mode run-gate message is one line: count, what happens, `econquest attest --list`. Policy unchanged (`RUN_GATE_DEFAULT`: warn on runs and plan-only writers, block every Sheets write; exit codes the same). A block still prints the full message (per file, `attest` commands, policy key, `--allow-unattested`). Checked on the temp copy: four stderr lines became `warning: 396 hand-entered cell(s) not attested; monitor continues (run gate 'warn'). List and fix: econquest attest --list`. | `cli.py` (`_gate_warning`, `run_gate`), README "Run gate" | `test_run_gate.py::test_warn_path_prints_counts_and_fix_and_continues` (exact line), `::test_block_message_keeps_the_full_fix`, and the 39 other run-gate tests unchanged |
| U22 | GUI buttons for `ideas report` and `ideas log` (Data & jobs). `ideas` is added to `ALLOWED_CMDS` with `GUI_SUBCMDS = {"ideas": ("report", "log")}`: the first argument after the GUI's flag stripping must be one of them, so `ideas mark`, an empty call or a reordered call is refused before any job starts. The usual stripping applies (`--write`, `--token-file`, `--allow-unattested` and their prefixes are dropped), `ideas` is not a writer so a token never reaches the job, and neither subcommand writes `data/` or the workbook (`log` writes `outputs/idea_log.csv`, as `run` already does from the GUI). The Trade ideas tab names the buttons and says marking stays on the CLI. | `presentation/gui.py`, `static/gui.html` | `test_usability_fixes.py::test_gui_ideas_job_runs_read_only_subcommands_with_flags_stripped` (5 cases), `::test_gui_ideas_job_refuses_mark_and_anything_but_report_or_log` (7 cases), `::test_gui_has_ideas_buttons_for_report_and_log_only` |
| EQ-C-0047 note | Workbook 'Trade Ideas' A2: "Latest run X." became "Newest ideas opened by run X (the latest model run can be newer).", the same meaning as the GUI's U19 fix. Text only; the tab's ranges (A1:A3, A5:G(6+Q)) and C11 are unchanged. | `presentation/sheets_publish.py` (`ideas_plan`) | `test_usability_fixes.py::test_workbook_ideas_note_says_newest_ideas_not_latest_run` |

Also checked on the live GUI (temp copy): `POST /api/job {"cmd": "ideas", "args": ["mark"]}` returns
`{"error": "ideas: the GUI runs only ideas report or ideas log"}`; `["report"]` runs and prints the idea report in the
job log. Screenshots refreshed with headless Chromium: `docs/gui-data-jobs.png` (the two new buttons) and
`docs/gui-trade-ideas.png` (the tab's new refresh hint).

### 7.2 Status of every finding after PI-5

| Status | Ids |
|---|---|
| Fixed | U01, U02, U04 (Team A), U05, U06, U07, U08, U09, U11, U12, U14, U15, U16, U17, U19, U20, U22, and the workbook "Latest run" note |
| Open, another team | U03 and U21 (Team B, HO-20261023-C-B-010 accepted, EQ-B-0056 in progress), U13 (Team B governance: no issues-log exception for the compliance self-sign yet; Sam to approve one) |
| Open, needs Sam's Mac | U18 (venv and pip at install; part of task 5 in `sam-task-script-PI5.md`) |
| By design | U10 (the program never reads the live workbook) |

No Team C finding is left open.

### 7.3 SUS: expert heuristic estimate after PI-5 (estimate, not a user score)

Same respondent model as section 4: Sam, a single expert operator who wrote the requirements, doing the five tasks
on the PI-5 build. This is the reviewer's guess, not a measurement, and must not be reported as Sam's score.

| # | Statement (shortened) | PI-4 | PI-5 | Contribution | Reasoning |
|---|---|---|---|---|---|
| 1 | would like to use frequently | 4 | 4 | 3 | Unchanged: the daily engine, on a schedule. |
| 2 | unnecessarily complex | 3 | 3 | 2 | Unchanged: the governance steps (four-eyes, run gate, EXC ids, editorial checklist) are all still there, by policy. |
| 3 | easy to use | 3 | 4 | 3 | W2 no longer needs a copied value per cell (U06, one `decide --all-pending`), editorial errors name the flag to pass (U12), and the run gate is one line. W4 is still seven commands. The least certain move: 3 is also plausible. |
| 4 | need a technical person | 3 | 3 | 2 | U04 removes one reason to ask (offline fetch now fails in seconds), but U13 (which EXC id for a compliance self-sign) still has no answer in the program, and Keychain, launchd and the batchGet baseline are unchanged. |
| 5 | functions well integrated | 4 | 4 | 3 | Slightly better (ideas from the GUI, workbook and GUI say the same about the idea run), not enough for a 5. |
| 6 | too much inconsistency | 2 | 2 | 3 | The main inconsistency (U12) is gone. "book book" (U21) and the record date (U03) remain, so not 1. |
| 7 | most people learn quickly | 2 | 2 | 1 | Unchanged: domain- and governance-heavy. |
| 8 | very cumbersome | 3 | 2 | 3 | The two biggest chores went: 26 `decide` calls became one, and a 400 s offline fetch became about 4.5 s. The four-line warning on every command is one line. W4's repeated checklist flags remain. |
| 9 | felt very confident | 4 | 4 | 3 | Unchanged: dry-runs, `verify`, backups; read-only GUI ideas buttons add no risk. |
| 10 | needed to learn a lot first | 4 | 4 | 1 | Unchanged: tokens, attestation, change control and editorial still have to be learned before the first clean publish. |

**Estimated SUS = 2.5 x (3+2+3+2+3+3+1+3+3+1) = 2.5 x 24 = 60** (plausible range 55 to 65), up from 55.

The target "above 70" is **still not met** by this estimate. Items 2, 7 and 10 are structural: they come from the
governance and the domain, which are requirements, and no message fix moves them. Reaching 70 would take about four
more points, most likely from:

- item 4: a governed exception for the compliance self-sign named in the refusal (U13, Team B and Sam);
- item 8 and 3: a W4 checklist that keeps the acknowledgements of a refused call, or one `editorial` command that
  runs review, checklist and publish in order (a new Team C ticket, AGENT-06);
- item 6: U03 and U21 (Team B, in progress).

Sam's own answers (`sam-task-script-PI5.md`, then `sus-questionnaire.md`) replace this estimate.
