# System Usability Scale (SUS): questionnaire for Sam

EQ-C-0048, EQ-C-0063. Fill this in **after** doing the five tasks in `sam-task-script-PI5.md` on your own Mac,
without help. Answer with your first reaction, and answer every item. If an item does not apply, mark 3.
This gives the real user score. The expert estimate in the usability pass is only a guess at it.

Date: ____________  Release (`econquest --version` or the zip name): ____________  Tasks done (1-5): ____________

Mark one box per row: 1 = strongly disagree, 5 = strongly agree.

| # | Statement | 1 | 2 | 3 | 4 | 5 |
|---|---|---|---|---|---|---|
| 1 | I think that I would like to use EconQuest frequently. | ☐ | ☐ | ☐ | ☐ | ☐ |
| 2 | I found EconQuest unnecessarily complex. | ☐ | ☐ | ☐ | ☐ | ☐ |
| 3 | I thought EconQuest was easy to use. | ☐ | ☐ | ☐ | ☐ | ☐ |
| 4 | I think that I would need the support of a technical person to be able to use EconQuest. | ☐ | ☐ | ☐ | ☐ | ☐ |
| 5 | I found the various functions in EconQuest were well integrated. | ☐ | ☐ | ☐ | ☐ | ☐ |
| 6 | I thought there was too much inconsistency in EconQuest. | ☐ | ☐ | ☐ | ☐ | ☐ |
| 7 | I would imagine that most people would learn to use EconQuest very quickly. | ☐ | ☐ | ☐ | ☐ | ☐ |
| 8 | I found EconQuest very cumbersome to use. | ☐ | ☐ | ☐ | ☐ | ☐ |
| 9 | I felt very confident using EconQuest. | ☐ | ☐ | ☐ | ☐ | ☐ |
| 10 | I needed to learn a lot of things before I could get going with EconQuest. | ☐ | ☐ | ☐ | ☐ | ☐ |

Optional: the one thing that slowed you down most: ________________________________________________

## Scoring (Brooke, 1996)

With r1..r10 the answers (1-5):

- odd items (1, 3, 5, 7, 9, positive statements): contribution = r - 1
- even items (2, 4, 6, 8, 10, negative statements): contribution = 5 - r
- **SUS = 2.5 x (sum of the ten contributions)**, from 0 to 100

```
SUS = 2.5 * ((r1-1) + (5-r2) + (r3-1) + (5-r4) + (r5-1) + (5-r6) + (r7-1) + (5-r8) + (r9-1) + (5-r10))
```

Reading the score: it is not a percentage. 68 is about the average across published studies, and above 70 is
"good" (Bangor, Kortum and Miller, 2008). EQ-C-0048's target is above 70. With one respondent the score is one
person's view: report it as Sam's score on that date and release, not as a population mean. Compare it with the
next pass on the same five tasks.

Worked example: answers 4, 2, 4, 2, 4, 2, 3, 2, 4, 3 give contributions 3, 3, 3, 3, 3, 3, 2, 3, 3, 2 = 28, so SUS = 70.
