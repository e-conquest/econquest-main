# EconQuest: roadmap to institutional grade

Written 2026-10-23. Status today: a complete model pipeline (scorecard, hazard model, Bayesian blend, Student-t copula Monte Carlo, stress, backtests), a GARCH/DCC layer, a ten-toolkit econometrics module, a Google Sheets view, a local GUI, tests, and a one-command installer. What it runs on is mostly seed estimates, a sample book and a synthetic P&L history. That is the gap: an institution would accept the methods but not the inputs, the evidence, or the controls.

The work splits into four tracks. Items marked **you** need something only you can supply (data, accounts, decisions, money). Items marked **build** are code I can write once the inputs exist. Rough effort is in working days for the build side.

## Track 1: Real data with provenance (the gate for everything else)

| # | Item | Who | Effort | Done when |
|---|------|-----|--------|-----------|
| 1.1 | Run `econquest fetch --apply` on your Mac and upload `data/live` plus the updated `indicators.csv` and `countries.csv` | you | 10 min | **Done 2026-10-23: first pull applied (298 cells), 4 held on seed.** Every IMF, World Bank and BIS indicator on Inputs shows a source and a pull date instead of a seed estimate |
| 1.2 | Point-in-time storage: keep every pull as a dated vintage, never overwrite | build | 2 | **Done 2026-10-23: data/live/vintages/<date>/.** A run can be reproduced with the data that existed on any past date |
| 1.3 | Market data: sovereign CDS curves, local yield curves, Eurobond prices, FX forwards, EMBI spreads | you | licence | Requires Bloomberg, LSEG/Refinitiv or at least a CDS vendor. Google Finance covers spot FX and ETFs only. Country Profile P10-P11 and the market signal in the PD blend stay hand-entered until then |
| 1.4 | Event data: ACLED account (free for research), GDELT, UCDP | you + build | 2 | Indicators 4.1, 6.4, 6.9 refresh automatically; the layer-2 text stress index stops being zero |
| 1.5 | Data-quality gates: unit checks, stale-data flags, outlier screens, missing-country report on every pull | build | 2 | **Done 2026-10-23: quality_gate, review.csv.** A pull that changes any input by more than a set threshold is held for review, not applied |
| 1.6 | Audit trail: source, URL, vintage, transform and analyst override on every input cell and in the run archive | build | 2 | **Done 2026-10-23: `econquest audit`, data/audit_trail.csv, Audit Trail tab, GUI table.** Any number in a report can be traced to its origin in one step |

## Track 2: Evidence that the model works

| # | Item | Who | Effort | Done when |
|---|------|-----|--------|-----------|
| 2.1 | Real P&L history: daily marked positions from your custodian or broker, or at least a real position file | you | your data | `backtest_history.csv` is real; Kupiec, Christoffersen and Acerbi-Szekely run on it |
| 2.2 | Daily forecast record: a scheduled run that stores each day's VaR/ES and marks the book against Market History prices | build | 1 | **Done 2026-10-23: econquest record, Forecast Record tab, 60-day backfill.** A forecast-versus-outcome record accumulates from the day it starts; after 250 trading days the Basel traffic-light test is meaningful |
| 2.3 | Recalibrate the hazard model on a real sovereign default panel (Reinhart-Rogoff, Moody's/S&P default histories, Bank of Canada-Bank of England database) instead of the paper's illustrative coefficients | build | 4 | **Pipeline done 2026-10-23: `econquest fit-hazard`, data/panel/, docs/validation/hazard-fit-report.md. Pilot on the 18-country vintage (9 events) did not clear the gate; the full-panel fit needs `--fetch` on Sam's Mac.** Out-of-sample AUC and calibration plots on 1980-2025 defaults are in the validation report |
| 2.4 | Model validation document per model: purpose, assumptions, data, estimation, limitations, sensitivity, benchmarks | build | 3 | **Done 2026-10-23: docs/validation/ (14 documents and an index with a review checklist).** A reviewer can challenge each model from the document alone |
| 2.5 | Parameter and change log, version pinning of data and code per run | build | 1 | **Done 2026-10-23: versioning.py, econquest runs.** Every run record names the code version, data vintages and assumption file hash |
| 2.6 | Benchmarks: compare model PDs to rating-implied, CDS-implied and prediction-market probabilities over time, with Brier scores. **Done 2026-10-23**: `econquest benchmark`, data/benchmarks.csv, PD Benchmarks tab; scoring starts when snapshots are 12 months old | build | 2 | A standing table shows which source predicted best and where the model disagrees |

## Track 3: Sovereign analytics a desk expects

| # | Item | Who | Effort | Done when |
|---|------|-----|--------|-----------|
| 3.1 | Stochastic debt sustainability analysis: debt path fan charts from shocks to growth, rates, primary balance and FX, per country | build | 4 | A DSA tab with 5-year fan charts and the probability that debt exceeds a threshold |
| 3.2 | Reserve adequacy and external financing gap: IMF ARA metric, gross financing needs, rollover risk | build | 2 | Feeds the liquidity pillar with computed rather than entered values |
| 3.3 | CDS-implied PD term structure with recovery assumptions, and bond-level relative value against model PD | build (needs 1.3) | 3 | **Code done 2026-10-23: engine/cds.py, `econquest cds`, data/cds_quotes.csv (empty until quotes are entered or a feed is licensed).** Each Eurobond position has a model-fair spread and a rich/cheap reading |
| 3.4 | Named scenario library with transmission channels (Taiwan blockade, Hormuz closure, US tariff shock, commodity crash, China hard landing), reverse stress tests, contagion through BIS bilateral exposures and trade links. **Done 2026-10-23** except BIS contagion: data/scenarios.json (paper A, B, C; ASIA97, GFC08, TAPER13, COVID20, FED22; TAIWAN, HORMUZ, TARIFF, CHINA_HL, DOWNGRADE), `econquest stress`, `econquest reverse-stress` | build | 4 | Scenarios are documented, reproducible and sized against the real book |
| 3.5 | Text pipeline over central bank statements, IMF Article IVs, rating actions and local press, producing the text stress index and early-warning topics | build | 5 | Layer-2 text index is live and backtested as a leading signal |

## Track 4: Controls and operations

| # | Item | Who | Effort | Done when |
|---|------|-----|--------|-----------|
| 4.1 | Limits: country, issuer, VaR, ES, liquidity, concentration; pre-trade check of a proposed position against them. **Done 2026-10-23**: `econquest limits [--propose]`, data/limits.json, GUI card | build | 2 | The GUI refuses or flags a trade that breaches a limit |
| 4.2 | Daily risk report generated from the run (PDF or doc): positions, VaR/ES, regime changes, signal crossings, data issues. **Done 2026-10-23**: `econquest report` (self-contained HTML + Markdown, outputs/reports) | build | 2 | A report lands every morning without anyone running anything |
| 4.3 | Alerts when a regime flips, a signal crosses threshold or a backtest fails. **Done 2026-10-23**: `econquest alerts`, webhook (Slack/Teams) and SMTP delivery | build | 1 | Email or message alert within minutes of the run |
| 4.4 | Access control and sign-off: who can change assumptions, who approves a model change, four-eyes on overrides | you + build | 1 | Overrides carry an author and an approver |
| 4.5 | Independent review: a second person (or an external validator) reads the validation documents and reruns the tests | you | people | Review findings are logged and closed |
| 4.6 | Service reliability: scheduled runs on a server rather than a laptop, monitoring, backups of data vintages and run archives | you + build | 2 | A missed run is noticed the same day |

## What cannot be bought with code

- **Licensed market data (1.3).** Without CDS and bond prices, the market leg of the PD blend and all relative-value work stay approximate. This is the single largest difference between this desk and a bank's.
- **Track record (2.1, 2.2).** Credibility comes from forecasts compared with outcomes over time. Starting the daily record now is the cheapest high-value step; nothing can shortcut the calendar.
- **People (4.5).** Institutional grade means someone other than the author has challenged the models. The documents in 2.4 make that review possible; the review itself needs a reviewer.

## Suggested order

1. This week: 1.1, 2.2, 2.5, 1.5 (real inputs, a record that starts accumulating, reproducible runs, guarded pulls).
2. Done 2026-10-23: validation-review fixes (Merton uplift simulated, GPD mean, scenario B LGD, multipliers), 2.6 benchmarks, 4.1 limits, 4.2 report, 4.3 alerts.
3. Done 2026-10-23 (sprint 3): 3.4 scenario library and reverse stress (BIS contagion still open), model governance pack (docs/governance, `econquest governance`).
4. Next: run the full hazard panel on the Mac (2.3); 3.1 DSA and 3.2 reserve adequacy; HMM regime fitting; text stress index; BIS contagion; real P&L into the backtests; schedule `run && report && benchmark` on the Mac.
4. When data licences exist: 1.3 and 3.3. In parallel, 1.4 and 3.5 for the text and event layer.

Build effort across all tracks is about 45 working days of code, excluding items that wait on licences or people.
