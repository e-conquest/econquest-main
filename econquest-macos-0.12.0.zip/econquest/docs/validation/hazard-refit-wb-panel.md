# Hazard refit on the wider World Bank panel: runner and report (EQ-B-0117)

Team B AGENT-03, 2026-10-25. Code: `econquest/validation/hazard_wb_refit.py`. Tests:
`tests/test_hazard_wb_refit.py`. Earlier checks on narrower data: `hazard-refit-wb-interim.md`.

The real run waits for the Mac-pass pull: `team/first-mac-pass.md` step 12 (`econquest mac-pull run`), which writes
`data/panel/wb_interim/worldbank_history.csv` (pull pack step 2w: current account, real growth, CPI, WGI rule of law
score, IDS external debt / exports, short-term debt / reserves; 2000-2025; every economy) and
`data/panel/worldbank_history.csv` (step 2: short-term debt / reserves, reserves in months of imports, PV.EST).
Nothing in this runner asks Sam for anything; it runs after the pull is uploaded.

## One command

```bash
.venv/bin/python -m econquest.validation.hazard_wb_refit --as-of 2026-10-23
echo "exit code: $?"
```

It writes only under `outputs/hazard-refit/<as_of>-wb-panel/`: `wb-panel-report.md` / `.json`, one folder per case
with its gate report, and `inputs/worldbank_panel_merged.csv`. Options: `--wb-file` (repeatable) to use other
files, `--wb-previous` to measure revisions against an older pull, `--min-amount-musd` / `--cure-years` (crag_v1
by default), `--min-economies` (default 150), `--out`.

| Exit | Outcome | Meaning |
|---|---|---|
| 0 | CLEARED | The primary case passed the gate. A parked Tier 1 pack is written. Nothing is proposed. |
| 1 | NOT CLEARED | Right panel, the primary case failed. Layer 1 stays `paper_standardized`; add one line to `hazard-layer1.md`. |
| 3 | PREFLIGHT FAILED | The files are not the panel the primary case needs (step 12 not complete). |
| 2 | INPUT ERROR | No World Bank panel file found. |

## What it does

1. **Merge** the two step-12 files. For a cell in both, the step-2w file wins.
2. **Preflight** on the primary feature set, per feature:
   - the series is present;
   - it covers at least 150 economies;
   - the first year with values for half of them is 2005 or earlier (crag_v1 needs labels from about 2008 for 30
     or more starts);
   - WGI scale: `.SC` series must be the 0-100 score, `.EST` series the -2.5..2.5 estimate.
3. **Cases.** Fixed before any data is seen, so the decision cannot be picked from the best-looking run.

   | Case | Events | Features | Role |
   |---|---|---|---|
   | `crag__interim` | crag_v1 | current account % GDP, real growth, CPI (log), WGI rule of law score | **primary: decides** |
   | `current__interim` | current list | same | reference |
   | `crag__core_plus` | crag_v1 | primary + reserves in months of imports + short-term debt / reserves | sensitivity |
   | `crag__history3` | crag_v1 | short-term debt / reserves, reserves months, PV.EST | sensitivity (the set already tested) |

   Each case is `hazard_refit.run_wb_interim`: lag 1, rows inside a spell dropped, Firth logit, rolling-origin
   out-of-sample test, the gate (OOS AUC at least 0.75, at least 30 starts, OOS Brier below the trailing base).
   A case whose series are not in the files is reported as "not run" with the missing codes.
4. **If the primary case clears**, it writes a parked Tier 1 pack:
   - `tier1-pack-parked.md`: numbers, sensitivities, limits, the propose command for later, and a decision line in
     the format of first-mac-pass.md section B;
   - `layer1_fitted_coefficients_only_patch.json`, dry-validated on a scratch copy of `assumptions.json`.

   The patch stores the coefficients under a new key, `layer1_fitted_wb`, and changes no run. Fitted mode refuses
   World Bank features at run time (EQ-B-0029). A mode switch therefore needs an engine change first: a run-time
   World Bank source aligned with these definitions. The pack lists that change and the effect table it would
   then need. It also gives `pd_fit_raw` for each desk name, which is what the fit says, not a model PD.

## Run on the data held today (2026-10-25)

`--wb-file team/inbox/pull-20261025T121034Z/worldbank_history.csv` (the three-series file; the step-2w file does not
exist yet). Output: `outputs/hazard-refit/2026-10-23-wb-panel-current-data/`.

| Case | Outcome |
|---|---|
| crag__interim (primary) | not run: BN.CAB.XOKA.GD.ZS, NY.GDP.MKTP.KD.ZG, FP.CPI.TOTL.ZG, GOV_WGI_RL.SC missing |
| current__interim, crag__core_plus | not run: same series missing |
| crag__history3 | NOT CLEARED: 44 events, OOS AUC 0.597 (same as `hazard-refit-wb-interim.md`) |
| **overall** | **PREFLIGHT FAILED (exit 3)**: the 12 primary-set rows (present, economies, history for 4 features) fail |

So Layer 1 stays paper. The SYNTHETIC tests show the other paths:
- a panel with signal clears and writes the parked pack, and the data folder is unchanged;
- a panel without signal is NOT CLEARED, and any stale pack is removed;
- a 0-100 series fed as an estimate fails preflight on scale, and so does a thin universe.

## Limits

- Not point in time: World Bank values carry later revisions; `--wb-previous` measures them when two pulls exist.
- No fiscal predictors (government debt, primary balance) without the WEO history (D11, deferred).
- crag_v1 keeps Argentina and Ecuador in one long spell (`hazard-panel-crag.md` J4).
