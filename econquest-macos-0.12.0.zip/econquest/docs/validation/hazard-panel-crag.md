# Default events for the hazard refit: mapping the BoC-BoE (CRAG) panel

Ticket EQ-B-0087 (Team B, AGENT-03), 2026-10-25. Closes EQ-B-0020 only when the real refit runs on Sam's Mac.
Inputs: `data/panel/sovereign_defaults_crag.csv` (210 spells, 99 countries, panel vintage
`2026-10-24T190434Z-03d9c4c4`, HO-20261024-A-B-014), the raw file `data/panel/staging/crag/DEBT_2026.csv`, the
current list `data/panel/sovereign_defaults.csv` (108 spells, memory-compiled) and Team A's comparison
`data/panel/staging/crag/comparison.md`.
Code: `econquest/validation/hazard_events.py`; runner option in `econquest/validation/hazard_refit.py`; tests
`tests/test_hazard_events.py`.

Nothing here changes a model number. The refit default stays the current file until Sam approves the swap
(Tier 1; draft card in `hazard-refit-crag-tier1-card.md`).

## 1. What the hazard model needs from an episode list

The refit labels country-year row (iso, t) with 1 when a default spell **starts** in t+1. Rows inside a spell are
dropped (the country is not at risk). Predictors are lagged one year and point in time. So the model needs, per
country, the years in default and which of those years are new starts. Spell length matters only through the
at-risk set.

## 2. What CRAG records

BoC-BoE records, per country and year, the stock of debt in default (USD millions) by creditor. Team A's import
(`ingestion.default_panel.import_crag`) keeps a year as "in default" when FC bank loans + FC bonds + LC debt in
default is above 0. Official creditors (IMF, World Bank, Paris Club, China, other official), fiscal or domestic
arrears and supplier credit do not count. A spell is a run of such years. Spells ending in 1980 or later are kept
with their true start year.

## 3. The recommended event definition ("crag_v1")

| Element | Rule | Setting |
|---|---|---|
| Source | `sovereign_defaults_crag.csv` (Team A's import, unchanged) | `source: "crag"` |
| Creditors | FC bank loans + FC bonds + LC debt. Official-only and fiscal arrears are not defaults. | Team A's scope, unchanged |
| Size | A year counts only when that year's in-scope amount is above USD 10m. Spells are rebuilt from the raw file year by year with Team A's importer (`min_amount`). | `min_amount_musd: 10` |
| New event | A spell is a new event only after at least 2 clean years since the last spell ended. The first year after a spell is not at risk; a spell that starts in it continues the old one. | `cure_years: 2` |
| Overlaps | Overlapping or adjacent spells of one country are merged. | always |
| Start year | The first year of the merged spell. Row t is labelled by a start in t+1. | always |
| Point in time | At as_of, spells starting after as_of's year are dropped and end years after it are cut to it. Nothing after as_of decides a label, a floor or a cure window. | always |

Applied at as_of 2026-10-23 this gives 179 spells (from 210) and **48 event starts in 2008-2025**, against 53 for
the plain CRAG file and 27 for the current list.

## 4. Judgement calls

Each of these is a choice, not a fact. The reasons and the alternatives are below so Sam and the validator can
disagree with any one.

**J1. Creditor scope: private and local-currency debt only.** Kept from Team A. A country that is in arrears
only to official creditors (typical for HIPC cases in the 1990s) is not in default for this model. This matches
what the desk prices: losses to private bondholders and lenders. Alternative: add Paris Club arrears; it would add
many low-income events with weak links to market prices.

**J2. A USD 10m floor, applied per year.** CRAG records any amount, including arrears of a few hundred thousand
dollars (Senegal 2021, USD 0.2m; Cameroon 2019, USD 0.3m). These look like reporting residue, not defaults. The
floor is tested on each year's own amount, so it never uses a later year (a floor on the spell's peak would).
The count of events is stable across floors, so the exact value matters little:

| Floor (USD m) | Starts 2008-2025, cure 1 | Starts 2008-2025, cure 2 |
|---|---|---|
| 0 | 53 | 48 |
| 1 | 51 | 46 |
| 10 (recommended) | 51 | **48** |
| 25 | 51 | 48 |
| 50 | 49 | 46 |
| 100 | 44 | 43 |

Weaknesses: an absolute floor is large for a micro-state and tiny for a large one. A floor as a share of GDP would
be better but needs point-in-time GDP from the WEO history, which has not landed; revisit after the real refit.
The floor can also split a spell: Zimbabwe 2006 (USD 287m) and 2007 (USD 7m) become one spell in 2006, so the 2009
spell (USD 31.5m) is a new event two clean years later.

**J3. A 2-year cure window.** In annual arrears data, one clean year often reflects when a settlement was booked,
not a real exit from distress. With cure 2, a re-entry after one clean year is the same episode (Serbia 2009,
Gabon 2018, St Kitts 2016, Zimbabwe 2009 before the floor, Liberia 2009). The year right after a spell is dropped
from the at-risk set. This uses only the end year of a spell that has ended, so it is point in time. Cure 3 would
leave 41 events.

**J4. Re-defaults inside an ongoing spell are not events.** CRAG keeps Argentina in default from 2001 to 2025
(holdout arrears) and Ecuador from 2008 to 2025, so Argentina 2014, Argentina 2020 and Ecuador 2020 are not new
starts, and both countries are outside the at-risk set for the whole 2007-2025 panel. The raw amounts show jumps
that look like new defaults (Argentina 2014, 2019, 2020, 2023; Ecuador 2020; Puerto Rico 2016; Venezuela 2017:
in-scope amount at least tripled and up by at least USD 1bn). They are not used: the row before a jump is inside a
spell, so labelling it would mean keeping only the in-default rows that precede a jump, which selects on the
outcome. Fixing this properly needs a different model (a "residual default" state at risk of a new default). For
the desk this is the biggest cost of the swap: Argentina loses its two recent events and drops out of the fit.

**J5. Restructurings count as defaults when CRAG records the debt in default.** Distressed exchanges are in CRAG
in the year of the exchange (Greece 2012, Cyprus 2013, Jamaica 2010 and 2013, Uruguay 2003). They are kept as
events. A pre-emptive operation that CRAG does not record is not an event in either list.

**J6. Successor and dissolved states (Team A's decision, kept).** The USSR/Russia series is mapped to RUS
(1960-2000 spell, then 2022); Yugoslavia and Czechoslovakia are not imported. The point-in-time panel starts in
2007, so this only changes the ever-defaulted count, not any label.

**J7. Left-censored spells.** A spell ongoing at the panel start (North Korea, Sudan, Argentina, Ecuador from 2008,
Eritrea from 2012) keeps the country out of the at-risk set until it ends. That is correct for a hazard of new
default; it does shrink the panel.

**J8. One CRAG vintage.** The 2026 edition is used for every as_of. Earlier editions may have dated some arrears
differently. This is a revision risk on the labels, not a look-ahead in the predictors, and it is the same for
the current list. Saved panel vintages (`data/panel/vintages/`) allow a later edition to be compared.

**J9. Zeros outside CRAG's coverage.** CRAG covers 166 economies; most advanced economies are not in it. In the
refit they appear only through the WEO history and count as never defaulted. That is true for them in this period
and keeps the ever-defaulted share near 0.49 (95 of 194 in the dry run, below the 0.55 preflight limit). Team A's
`panel_coverage` reports these zeros (`zeros_not_covered_by_crag`) when the history lands.

## 5. Reconciliation with the current list

From Team A's comparison (spells paired when their years overlap or lie within one year):

| | All years | Starts in 2008-2025 (refit window) |
|---|---|---|
| identical start and end | 46 | 13 |
| paired, years differ | 48 | 11 |
| current list only | 14 | 5: ARG 2014, ARG 2020, CIV 2011, ECU 2020, LAO 2022 |
| CRAG only | 116 | 29 |

What drives the differences:

- **CRAG only (116).** 27 countries are not in the current list at all (micro-states, Puerto Rico, North Korea,
  South Sudan, Eritrea, Chad, Mali and others). Most of the rest are short local-currency or bank-loan arrears the
  hand list never had. In the window, 29 extra starts; the floor and cure window remove 6 of them (CMR 2019,
  GAB 2018, KNA 2016, LBR 2016 moved to 2019, SEN 2021, SRB 2009).
- **Years differ (48).** Median start shift 0. The large shifts are before the window (Russia -31 from the USSR
  series, Dominican Republic -7, Liberia +9). In the window: Belize 2017 becomes 2016 and 2020 becomes 2021,
  Venezuela 2017 becomes 2016, Mozambique 2016 becomes 2015, Zimbabwe 2000 becomes 2009 (CRAG splits the spell).
  Several end years move by many years (Argentina 2005 to 2025, Ecuador 2009 to 2025, Peru 1997 to 2022): see J4.
- **Current list only (14).** Five are absorbed by longer CRAG spells (Argentina 2014 and 2020, Ecuador 2020,
  Russia 1998, Pakistan 1999: J4). Six have no CRAG spell at all for that country (Egypt 1984, Haiti 1982, Laos
  2022, Somalia 1981, Myanmar 2002, and Kenya 1994 against CRAG's 1990). Côte d'Ivoire 2011 and Dominican
  Republic 2005 fall inside longer CRAG spells (2000-2015, 1975-2005). Algeria 1991-1996 has CRAG spells only from
  1998. Laos 2022 is the only one in the window
  without a CRAG counterpart; its arrears are mostly to China and other official lenders (J1).

Event starts per year, all countries in each file, as known at as_of 2026-10-23:

| Start year | 08 | 09 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 | 25 | Total |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| current list | 2 | 0 | 1 | 0 | 2 | 2 | 1 | 1 | 2 | 2 | 1 | 0 | 6 | 0 | 6 | 1 | 0 | 0 | 27 |
| CRAG as imported | 3 | 3 | 2 | 2 | 3 | 3 | 1 | 4 | 6 | 2 | 4 | 1 | 4 | 3 | 10 | 2 | 0 | 0 | 53 |
| CRAG, crag_v1 | 3 | 2 | 2 | 2 | 3 | 3 | 1 | 4 | 4 | 2 | 3 | 1 | 4 | 2 | 10 | 2 | 0 | 0 | 48 |

19 starts are the same (iso and year) in the current list and crag_v1. With the current list the gate's 30-event
minimum cannot be met in a 2007+ point-in-time panel (27 starts before any loss to missing predictors), and the
list fails the `episodes_sourced` preflight check anyway. So the refit can only clear on CRAG.

Desk countries in the window: current list ARG 2014, ARG 2020, BLZ 2012, BLZ 2017, BLZ 2020, VEN 2017, ZMB 2020
(7); crag_v1 BLZ 2012, BLZ 2016, BLZ 2021, VEN 2016, ZMB 2020, ZWE 2009 (6).

## 6. Recommendation

Use CRAG with crag_v1 (USD 10m floor per year, 2-year cure window, point in time at as_of) as the event source
for the refit, and keep J4 as a stated limitation of the model (Argentina and Ecuador are outside the at-risk set
in 2007-2025). Reconsider the floor as a share of GDP once the WEO history lands. Ask Team A for no change to the
import: the floor and cure window are applied in the refit, so `sovereign_defaults_crag.csv` stays as imported
(min_amount 0).

Until Sam approves, the refit default stays the current file (`--events current`). Pass `--events crag` to run on
CRAG; see `hazard-refit-runbook.md`.

## 7. How the option works

| Way to choose | Effect |
|---|---|
| nothing (shipped) | `current`: `sovereign_defaults.csv`, no floor, cure 1 (the file as it is, overlaps merged) |
| `--events crag` / `run_refit(events_source="crag")` | crag_v1; `--min-amount-musd`, `--cure-years` override it |
| `layer1.refit_events` in assumptions.json (absent today) | the same as the arguments, e.g. `{"source": "crag", "min_amount_musd": 10, "cure_years": 2}`; arguments win |
| `--defaults <file>` without `--events` | that file as it is, no rule (the EQ-B-0067 behaviour; the activation pack uses this) |

The floor needs `data/panel/staging/crag/DEBT_2026.csv` and refuses a raw file whose sha256 differs from the one
named in the episode file's `source` column. The gate report states the rule used and the spells before and after
it. The setting is read only by the refit; no engine code reads it, so the base run is unchanged.
