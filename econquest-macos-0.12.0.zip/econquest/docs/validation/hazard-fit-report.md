# Hazard model recalibration report

Generated 2026-10-23 10:10 by `econquest fit-hazard`.

Updated 2026-10-23 by EQ-B-0054 (VF-005), checked by `python -m econquest.validation.replicate`
(checks H01-H25, all PASS): the body below is the fit on the stored panel `data/panel/hazard_panel.csv`
(421 rows), which today's code reproduces except the out-of-sample base-rate benchmark, changed by
EQ-B-0006 to the training-window event rate (base Brier 0.0232 -> 0.0234, base log loss 0.1125 ->
0.1166; corrected in place below). Rebuilding the panel from the raw inputs with today's builder
(predictor lag 1) gives 391 rows; see "Rebuilt panel" at the end. Conclusion unchanged: the gate is
not cleared (9 events against 30 required) and the model does not beat the base rate out of sample.

## Panel

- Country-years at risk: 421; default starts (12-month-ahead events): 9; countries: 15; years 1980-2025.
- default_episodes: sovereign_defaults.csv (108 spells, 76 countries)
- weo_history: raw_weo.csv (18 economies, 1980-2031)
- worldbank_history: none (World Bank features not available)
- Event rows (country, year of the predictors; default starts the next year): ARG 2000, ARG 2013, ARG 2019, BLZ 2005, BLZ 2011, BLZ 2016, BLZ 2019, PAK 1997, ZMB 2019

## Coefficients (Firth penalized logit on standardized predictors)

| predictor | centre | spread | coefficient | s.e. | z |
|---|---|---|---|---|---|
| intercept | | | -4.501 | 0.529 | -8.52 |
| debt_gdp | 62.96 | 41.53 | 0.057 | 0.291 | 0.20 |
| primary_deficit | 1.03 | 3.20 | -0.483 | 0.321 | -1.50 |
| current_account | -0.29 | 5.02 | -0.975 | 0.351 | -2.77 |
| real_growth | 4.38 | 3.40 | -1.050 | 0.307 | -3.42 |
| inflation_log | 6.15 | 9.18 | 0.085 | 0.167 | 0.51 |

A coefficient is the change in the log-odds of a default starting within 12 months for a one-standard-deviation move in the predictor. Base rate: 2.14% of country-years.

## In-sample fit

- AUC 0.882; Brier 0.0207 against 0.0209 for the base rate; log loss 0.0849 against 0.1034.

## Out-of-sample test (rolling origin: fit on years before T, score year T)

- Years 2014-2025: 168 country-years, 4 events. AUC 0.780; Brier 0.0320 against 0.0234 for the base rate; log loss 0.1242 against 0.1166 (training-window event rate per origin, EQ-B-0006).

### Calibration by decile of predicted probability (out of sample)

| decile | n | predicted | observed | events |
|---|---|---|---|---|
| 1 | 34 | 0.30% | 0.00% | 0 |
| 2 | 33 | 0.65% | 0.00% | 0 |
| 3 | 34 | 1.49% | 2.94% | 1 |
| 4 | 33 | 2.86% | 3.03% | 1 |
| 5 | 34 | 16.97% | 5.88% | 2 |

### Out-of-sample years

| year | n | events | mean predicted |
|---|---|---|---|
| 2014 | 14 | 0 | 2.09% |
| 2015 | 14 | 0 | 4.05% |
| 2016 | 14 | 1 | 3.97% |
| 2017 | 14 | 0 | 1.61% |
| 2018 | 15 | 0 | 3.70% |
| 2019 | 15 | 3 | 2.33% |
| 2020 | 12 | 0 | 21.28% |
| 2021 | 13 | 0 | 1.29% |
| 2022 | 14 | 0 | 2.36% |
| 2023 | 14 | 0 | 8.21% |
| 2024 | 14 | 0 | 3.54% |
| 2025 | 15 | 0 | 1.96% |

## Reading the result

- An AUC of 0.5 is no discrimination; above 0.75 is good for annual sovereign default prediction in the literature (Manasse-Roubini, Savona-Vezzoli report 0.75-0.85 in sample).
- The Brier score and log loss should beat the base-rate benchmark; if they do not, the model ranks countries but is miscalibrated.
- Calibration deciles compare predicted and observed default frequencies; observed should rise with predicted and sit near it.
- Pilot panels built from the 18-country live vintage are too thin for production use; the full panel needs `--fetch`.

## Rebuilt panel (today's builder, EQ-B-0054)

`refit_from_files(data, out, as_of="2026-10-23")` on `sovereign_defaults.csv` + `raw_weo.csv`, last
label year 2025 (rows 1981-2024), predictors from year t-1, latest-vintage values (no `vintage`
column, so revision look-ahead remains):

- Country-years at risk: 391; default starts: 9; countries: 15.
- Coefficients: intercept -4.372, debt_gdp -0.020, primary_deficit -0.357, current_account -1.080,
  real_growth -0.953, inflation_log 0.036 (s.e. 0.22 to 0.35).
- In sample: AUC 0.850; Brier 0.0218 against 0.0225; log loss 0.0911 against 0.1096.
- Out of sample 2014-2024: 152 country-years, 4 events. AUC 0.789; Brier 0.0361 against 0.0258 for
  the base rate; log loss 0.1336 against 0.1263.
- Gate: NOT CLEARED (oos AUC 0.789 >= 0.75 pass; events 9 >= 30 FAIL; oos Brier 0.0361 < 0.0258 FAIL).
