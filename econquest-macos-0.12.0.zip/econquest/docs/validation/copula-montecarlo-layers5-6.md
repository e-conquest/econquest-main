# Model validation: Layers 5 and 6, Student-t copula and Monte Carlo loss engine

Date: 2026-10-23. Code: `econquest/engine/layer5_copula.py` (`factor_loadings`,
`correlation_matrix`, `tail_dependence`, `degrees_of_freedom`, `liquidity_cost`) and
`econquest/engine/layer6_montecarlo.py` (`build_positions`, `simulate`, `loss_histogram`).
Parameters: `data/assumptions.json` keys `regime` (loadings), `monte_carlo`, `market`, `liquidity`.
Status: the dependence structure is a one-factor-per-block construction with judgement loadings; the
simulation is deterministic given the seed and verified for internal consistency. Since 0.1.4
(CHG-20261023T190523Z-b96d25) both data options are on by default: GARCH 12-month FX and equity
marginals (`monte_carlo.vol_source` garch, EQ-B-0035) and price-estimated Calm loadings
(`copula.source` estimated, EQ-B-0036; `nu` stays judgement); change record below. Every run now
publishes a Monte Carlo standard error and 95% band for VaR99, ES99 and L-VaR99 (EQ-B-0054, VF-004). 2026-10-23 EQ-B-0007 (Tier 1 code change, owner + approver
signature pending, independent review pending): Sobol runs now use a whole power-of-two block (100,000
requested -> 131,072 simulated); see "Change record" below. Characterisation tests:
`tests/test_layer6_montecarlo.py`.

## Purpose

Layer 5 defines the joint distribution of country shocks: a latent Student-t variable per country
built from a global factor, a regional factor (Asia, LatAm, Africa) and an idiosyncratic shock, with
loadings that rise with the country's regime and with the global regime. Layer 6 simulates the book
over 12 months: the latent variable drives the market move of every position and, through quantile
thresholds, the discrete default, transfer, expropriation and political-violence events whose
severities come from Layer 4. It reports VaR and ES at 95 and 99 percent, ES 97.5 (FRTB), liquidity
cost and liquidity-adjusted VaR, and contributions by position and country.

## Where it sits in the pipeline

Last compute step of `run_pipeline`: `loadings = L5.factor_loadings(...)`, `corr =
L5.correlation_matrix(...)`, `positions = L6.build_positions(u, country, settings, mults, df)`, `mc
= L6.simulate(...)`. Inputs are the country table (PDs, regime, `lgd_mult`), the regime-dependent
degrees of freedom and the portfolio. Output `MCResult` is archived with its paths, feeds the
dashboard, the stress comparison and the forecast record's 12-month columns.

## Assumptions

1. Latent variable: `X_i = (g_i Z_g + r_i Z_{R(i)} + e_i eps_i) / sqrt(W / nu)` with `Z_g`, `Z_R`,
   `eps_i` standard normal, `W ~ chi-square(nu)` shared by all countries on a path, `g_i^2 =
   global_loading(regime_i) * mult`, `r_i^2 = regional_loading 0.1`, `e_i^2 = 1 - g_i^2 - r_i^2`.
   This is a Student-t copula with `nu` degrees of freedom and implied correlation `R_ij = sqrt(g_i
   g_j) + 1[same region] sqrt(r_i r_j)` (`correlation_matrix` writes it this way with `g`, `r` the
   squared loadings from `assumptions.json`).
2. Loadings: `global_loading` 0.15 Calm, 0.25 Stressed, 0.35 Crisis; times `global_loading_mult 1.5`
   when the global regime is Stressed; capped at `1 - r - 0.05`.
3. Degrees of freedom: `df_calm 5`, `df_stressed 4`, chosen by the global regime (section 3.5 of the
   paper).
4. Market move per position: `L = -z * vol / 100` where `z` is the latent variable rescaled to unit
   variance (`latent / sqrt(nu / (nu - 2))`) and `vol` is a 12-month volatility in percent: FX
   `fx_vol` by regime (Float 12, Managed 7, Peg 2, Dollarized 0); local bond `duration *
   local_rate_vol 1.5 + fx_vol`; Eurobond `duration * spread * spread_vol_rel 40 / 1e4`; equity
   `equity_vol 25`; CDS protection minus the Eurobond expression. All capped at `vol_cap 60`.
5. Events: event A fires when `X_i < t_nu^{-1}(pA)`, event B when `X_i < t_nu^{-1}(pB)`, so defaults
   happen in the lower tail of the same latent variable that drives the market move. Severities are
   drawn from the position's own Sobol dimensions (two per position). Long positions have the total
   loss capped at the notional.
6. Carry: Eurobond and local bond long positions earn `notional * spread / 1e4` (a negative loss);
   CDS protection pays it.
7. Quasi-Monte Carlo: scrambled Sobol (`scipy.stats.qmc.Sobol`, `random_base2(m)` with
   `2^m = sobol_path_count(paths)`, the smallest power of two at or above the requested count; every
   point of the block is used, so 100,000 requested gives 131,072 paths and 20,000 gives 32,768;
   `metrics.paths` is the simulated count and `metrics.paths_requested` the request; before EQ-B-0007
   the 2^m draw was truncated to `paths`, which loses the balance of the block), dimensions `1 + regions + 1 + countries + 2 * positions` = 1 + 3
   + 1 + 18 + 48 = 71. Seed 7.
8. Liquidity cost (section 6.3): per position `0.5 * notional * regime_mult * (spread_mean + z_99
   spread_sd) * sqrt(horizon_days / T0_days 1) / 100` with asset-class parameters (FX 0.05/0.05/1
   day; local bond 0.5/0.4/3; Eurobond 0.75/0.6/3; equity 0.2/0.15/2; CDS 1.0/0.8/5) and
   `regime_mult` 1, 2, 4. It is a deterministic add-on: `lvar99 = var99 + liquidity_cost99`.
9. Metrics: VaR as empirical quantiles of the path losses; ES as the mean of losses at or above the
   VaR; `es975_frtb` the mean above the 97.5 percent quantile; contributions as the mean position
   loss on paths in the 99 percent tail.

## Data

The portfolio (24 positions, 309 $mm gross, 239 $mm net long), the country table, `countries.csv`
for `region`, `fxregime`, `spread`, `stress_depreciation`. Regions: 9 Asia, 5 LatAm, 4 Africa. No
market data enters the dependence structure: the loadings, the volatilities and the degrees of
freedom are parameters. The GARCH-DCC layer (see `garch-dcc.md`) estimates daily correlations from
three years of prices but is not connected to the copula.

## Estimation or calibration

None. Loadings, `nu`, volatilities and liquidity parameters come from the workbook's Assumptions
tab. The regression tests check that the liquidity cost matches the workbook (5.28 $mm, within 0.05)
and that VaR99 lies within 0.6 to 1.6 times the workbook's 59.3 $mm.

## Outputs and how they are used

Current 0.1.4 base (as_of 2026-10-23, 100,000 requested = 131,072 Sobol paths, seed 7; replicate
R01-R04): VaR99 74.35 (SE 0.40), ES99 96.48 (SE 0.45), EL 0.45, L-VaR99 79.63 $mm. The paragraphs
below describe the pre-GOV-001 run and are kept as the record of that review.

Base run, 2026-10-23, 100,000 paths (production), calm global regime, `nu 5`: expected loss 0.22
$mm, VaR95 36.9, VaR99 66.1, ES95 54.9, ES99 85.3, ES97.5 67.6, liquidity cost 5.28, L-VaR99 71.3,
L-ES99 90.6, ES99 as a share of gross 27.6 percent, probability of losing more than 10 percent of
gross 7.2 percent. Mean implied latent correlation 0.239; tail dependence at that correlation and
`nu 5` is 0.103 (Gaussian equivalent 0). Loss quantiles at 20,000 paths: median -1.5, 90 percent
25.5, 99.5 percent 80.3, 99.9 percent 113.7 $mm.

Largest 99 percent tail contributions (20,000 paths): Brazil local bond P12 12.0 $mm (13.8 percent
of ES99), Argentina Eurobond P14 8.2, South Korea equity P07 6.8, India local bond P08 6.6, China
local bond P03 6.4, Singapore local bond P05 6.3, Philippines FX P02 5.8, Colombia local bond P16
5.7. By country: Brazil 15.4, Singapore 9.3, Philippines 7.4, South Korea 6.8, China 6.4; Japan's
short FX position contributes -2.75 (a hedge in the tail).

Consumers: dashboard tiles and loss histogram, `outputs/positions.csv`, `contributions.csv`,
`latent_correlation.csv`, the SQLite store and `.npz` path archive, the stress comparison, the
workbook's Portfolio VaR and MC tabs, the forecast record (`var99_12m`, `es99_12m`).

## Limitations and known gaps

- The tail is a market-volatility tail, not a default tail. The top eight contributors are
  investment-grade and BB local bonds, an equity and an FX position; their default probabilities are
  below 2 percent. Local-bond volatility (`duration * 1.5 + fx_vol`, 13 to 19.5 percent for the
  book) and FX volatility (12 percent for floats) set the 99 percent loss. Sovereign default risk,
  which the first four layers are about, contributes mainly through Argentina, Senegal, Pakistan and
  Venezuela, together under 20 percent of ES99.
- Volatilities are 12-month parameters by regime, not estimates. The GARCH layer's annualised
  conditional volatilities on 2026-10-22 are 7.1 percent for USDPHP, 5.2 for USDJPY, 11.6 for
  USDBRL, 45 for EWY (South Korea equity) against the 12 percent float FX and 25 percent equity
  assumptions; EWY's realised volatility is nearly double the assumption. Nothing links the two
  layers.
- One latent variable per country drives both the market move and every event, with a fixed
  threshold mapping. A sovereign default therefore always coincides with a bad market draw, and the
  market move scale is the same on default and non-default paths.
- The global regime switch (`nu` 5 to 4 and loadings times 1.5) is a cliff at 50 percent of
  countries not Calm; see `regime-layer3.md`.
- Loadings are the same within a regime for every country; there is no country-specific beta to the
  global factor and the regional block structure ignores trade or financial links (roadmap 3.4).
- Liquidity cost is deterministic and additive; it does not vary across paths or interact with the
  loss distribution, so L-VaR and L-ES are shifts, not quantiles of a liquidity-adjusted loss.
- Sobol dimension count (71) exceeds the range where scrambled Sobol gives its strongest advantage;
  the seed sensitivities below show VaR99 stable to within 1 percent and ES99 within 4 percent at
  20,000 paths.
- The CDS protection leg is modelled as the negative of a Eurobond with a Beta "gain" on default and
  a positive carry; basis, counterparty and roll are ignored.
- Positions are held fixed for 12 months; no rebalancing, limits or stop-loss.

## Sensitivity

20,000 Sobol paths unless stated; production uses 100,000. The table predates EQ-B-0007: a 20,000-path
request now simulates 32,768 paths and 100,000 simulates 131,072, so the table is to be recomputed in
the release that ships the change (change-control step 4). PDs are unchanged in all rows. It also
predates GOV-001..005, 0.1.3 and 0.1.4. Current values of the two rows the review checklist re-runs
(20,000 requested, as_of 2026-10-23; `python -m econquest.validation.replicate`, checks D12/D13/D15/D16):
`df_calm 30` VaR99 69.16 on the 0.1.4 assumptions and 58.52 on the 0.1.3 settings
(`vol_source regime`, `copula.source judgement`); `regime.Calm.global_loading 0.30` 81.26 and 72.69.

| Variant | VaR99 $mm | ES99 $mm | L-VaR99 $mm | ES97.5 $mm |
|---|---|---|---|---|
| Base, 20,000 paths, seed 7 | 65.98 | 87.05 | 71.26 | 68.53 |
| Same, 100,000 paths | 66.07 | 85.30 | 71.35 | 67.62 |
| Seed 8 | 65.46 | 86.33 | 70.74 | |
| Seed 9 | 65.74 | 83.80 | 71.02 | |
| Pseudo-random instead of Sobol | 66.73 | 87.10 | 72.01 | |
| `df_calm 3` | 66.76 | 91.45 | 72.04 | |
| `df_calm 4` | 67.31 | 89.28 | 72.59 | |
| `df_calm 8` | 65.10 | 82.29 | 70.38 | |
| `df_calm 30` (near Gaussian) | 60.53 | 73.21 | 65.81 | |
| `regime.Calm.global_loading 0.05` | 59.65 | 75.69 | 64.93 | |
| `regime.Calm.global_loading 0.30` | 74.71 | 99.41 | 79.99 | |
| `regime.Calm.global_loading 0.45` | 83.03 | 110.71 | 88.31 | |
| `regional_loading 0` | 60.94 | 81.41 | 66.22 | |
| `regional_loading 0.25` | 71.41 | 92.71 | 76.69 | |
| Global regime Stressed (`global_stress_share 0.4`) | 74.84 | 100.18 | 80.12 | |
| `fx_vol.Float 18` (from 12) | 70.60 | 91.23 | 75.88 | |
| `local_rate_vol 2.5` (from 1.5) | 70.41 | 91.83 | 75.70 | |
| `spread_vol_rel 60` (from 40) | 67.63 | 88.23 | 72.91 | |
| `equity_vol 35` (from 25) | 68.02 | 88.86 | 73.31 | |
| `vol_cap 40` (from 60) | 65.31 | 86.72 | 70.59 | |
| Liquidity `regime_mult` all 1 | 65.98 | 87.05 | 69.29 | |
| Liquidity `spread_mean` doubled | 65.98 | 87.05 | 73.11 | |

Tail dependence of the t copula (`tail_dependence(rho, nu)`): at rho 0.25, nu 3: 0.196; nu 4: 0.144;
nu 5: 0.107; nu 8: 0.045; nu 30: 0.0002. At rho 0.4: 0.261, 0.203, 0.160, 0.081, 0.001.

Reading: the Calm global loading is the dominant parameter (0.05 to 0.45 moves VaR99 by 40 percent),
followed by the degrees of freedom for ES (nu 3 to 30 moves ES99 by 25 percent while VaR99 moves 10
percent) and the FX and local-rate volatilities. Monte Carlo error at 20,000 paths is about 1
percent on VaR99 and up to 4 percent on ES99 (seed 9), so differences below 1 $mm in the other
validation documents are within noise unless stated otherwise. Sobol versus pseudo-random differ by
1 percent on VaR99 at this path count.

## Benchmarks and evidence

- Internal consistency tests pass: VaR95 < VaR99 < ES99, `lvar99 = var99 + liquidity_cost99`,
  liquidity cost 5.28 within 0.05 of the workbook, Sobol reproducibility, tail dependence positive
  and zero in the Gaussian limit.
- Workbook comparison on the seed snapshot (README, 100,000 paths): program VaR99 65.9 and ES99 85.2
  vs workbook 59.3 and 76.9 $mm, liquidity cost identical. The program's tail is 10 to 11 percent
  heavier, consistent with the lower PDs of the workbook being replaced by Layer 1 and 2 PDs and
  with the regime-dependent loadings.
- Data-driven correlation benchmark: the DCC layer on three years of daily prices gives an average
  one-step-ahead FX correlation of 0.089 across 17 pairs (0.17 across the 9 FX positions actually
  held) and 0.364 across 10 ETFs. The copula's implied latent correlation averages 0.239, between
  the two, but it is a 12-month correlation of country-level shocks and the comparison is loose. The
  econometrics copula table (Table 8) finds Student-t preferred to Clayton on all 13 pairs tested,
  with `nu` between 5 and 50 and lower-tail dependence 0 to 0.22 for daily losses, so a t copula
  with nu around 5 is not contradicted by the daily data for the most correlated equity pairs, and
  is heavier-tailed than the FX pairs (nu 8 to 30).
- Backtest evidence: on the 120-month synthetic history the VaR99 fails Kupiec (4 exceedances vs 1.2
  expected, p 0.043) and the ES fails Acerbi-Szekely (Z2 -2.66); see
  `backtests-and-forecast-record.md`. That history is itself drawn from the simulation and scaled,
  so it is an exercise, not evidence.

## Open items for review

1. Replace the regime-level volatilities with estimates (the GARCH layer already produces them) or
   document why fixed 12-month parameters are preferred; EWY at 45 percent realised vs 25 assumed is
   the clearest gap.
2. Decide whether the global factor loading should be country-specific (for example from the DCC
   correlation or from a factor model on the ETF and FX returns).
3. Review the single-latent-variable design: defaults always coincide with bad market draws, which
   may overstate joint losses on paths where a sovereign defaults, and understate market losses
   without default.
4. Quantify Monte Carlo error in every published number (the seed runs suggest about 1 percent on
   VaR99 and 2 to 4 percent on ES99 at 20,000 paths). Partly done 2026-10-23 (EQ-B-0007, change
   record below): at the production count the seed-to-seed standard deviation over ten seeds is 0.53
   percent on VaR99 and 0.36 percent on ES99 (131,072 paths); the five-seed range is 1.8 percent on
   VaR99, above the 1 percent target, which needs about 2^18 paths. Done 2026-10-23 (EQ-B-0054,
   VF-004): every run carries a batch-means SE and 95% band for VaR99, ES99 and L-VaR99 (change
   record below). Still open: show the band next to the limit verdicts in the report (Team C).
5. Consider a path-dependent liquidity cost or at least report L-VaR as a separate line rather than
   a sum.
6. Confirm the 71-dimension Sobol setup is acceptable or move the severity draws to pseudo-random
   dimensions.

## Change record

### 2026-10-23 EQ-B-0007: whole Sobol blocks instead of a truncated 2^17 draw

Defect: `_draw_uniforms` drew `2^ceil(log2 n)` scrambled Sobol points and kept the first `n` (131,072 drawn,
100,000 kept in production). A scrambled Sobol sequence is balanced (every elementary interval of volume
2^-m holds the same number of points) only for whole 2^m blocks; the first 100,000 points are not. Fix:
the Sobol branch rounds the requested count up to the next power of two and keeps every point
(`sobol_path_count`); `_draw_uniforms` refuses a count that is not a power of two. The pseudo-random
branch (`use_sobol false`) is unchanged. Classification: Tier 1 model change (layer 6 sets VaR, ES and EL;
`model-risk-policy.md` section 2): owner + approver (Sam) signatures and independent review required
before release.

Measured on the frozen layer-6 inputs (`tests/fixtures/layer6_inputs.json`, captured from the pipeline on
`tests/seed_data`, seed assumptions, `nu 5`), Python 3.13.17, numpy 2.5.3, scipy 1.18.1, 4-core x86_64
cloud container; times are medians of three runs.

| Measure, seed 7 | Before (100,000 of 2^17) | After (131,072) | Change |
|---|---|---|---|
| VaR99 $mm | 67.779 | 67.861 | +0.12% |
| ES99 $mm | 86.967 | 86.844 | -0.14% |
| ES97.5 $mm | 69.846 | 69.861 | +0.02% |
| VaR95 $mm | 40.280 | 40.332 | +0.13% |
| Expected loss $mm | 2.0285 | 2.0301 | +0.08% |
| L-VaR99 $mm | 73.060 | 73.143 | +0.11% |
| Layer 6 time (pipeline on seed data) | 3.49 s | 4.61 s | +32% |
| Full pipeline time | 4.00 s | 5.12 s | +1.1 s per run (base and each stress run) |
| Peak RSS (pipeline process) | 398 MB | 453 MB | +55 MB |
| 20,000 requested, VaR99 / ES99 | 68.124 / 88.590 (20,000) | 67.918 / 87.525 (32,768) | -0.30% / -1.20% |

Seed stability at the production count (VaR99 and ES99 across seeds; target: five-seed VaR99 range under
1 percent):

| Variant | Seeds | VaR99 mean / sd | VaR99 range | ES99 mean / sd | ES99 range |
|---|---|---|---|---|---|
| Before: 100,000 of 2^17 | 1-5 | 67.75 / 0.51 | 1.90% | 87.12 | 1.13% |
| After: 131,072 | 1-5 | 67.72 / 0.50 | 1.78% | 87.06 | 0.98% |
| Before: 100,000 of 2^17 | 1-10 | 67.79 / 0.39 (0.57%) | 1.90% | 86.95 / 0.37 (0.42%) | 1.18% |
| After: 131,072 | 1-10 | 67.79 / 0.36 (0.53%) | 1.77% | 86.89 / 0.31 (0.36%) | 1.16% |
| 2^18 = 262,144 (not adopted) | 1-10 | 67.81 / 0.23 (0.34%) | 0.96% | 87.04 / 0.22 (0.25%) | 0.76% |
| 2^16 = 65,536 (not adopted) | 1-5 | 67.83 / 0.52 | 2.04% | 87.09 | 0.81% |
| Pseudo-random, 100,000 | 1-5 | 67.47 / 0.89 | 3.33% | 86.54 | 2.35% |

Reading: every move is inside one seed-to-seed standard deviation, so the fix changes the published
numbers by noise, not by bias. The fix buys little on VaR99 (sd 0.57 to 0.53 percent, no more than the 31
percent extra paths alone would give): with 71 dimensions and discontinuous default indicators, Sobol's
advantage over pseudo-random is about a factor of 1.8 in standard deviation at this count. The 1 percent five-seed target is met at 2^18 paths (about 2x the layer-6 time
of 2^17), not at 2^17. Characterisation pins before and after are in `tests/test_layer6_montecarlo.py`
(`PINS_TRUNCATED`, `PINS_BALANCED`). Two thirds of layer-6 time is `scipy.stats.beta.ppf` in
`layer4_severity.sample_haircut`, so a faster Beta inverse is the way to afford 2^18.

### 2026-10-23 EQ-B-0035: GARCH volatilities as an option for the market marginals (GOV-020)

`monte_carlo.vol_source` `"regime"` (default) or `"garch"`; method, fallbacks (administered quotes,
persistence >= 0.995, pegs, no series) and the per-position vols are in `garch-dcc.md`, section "Monte
Carlo marginals". The default is bit-identical: same losses array, PDs and metrics as before the change
(`test_vol_source_default_is_regime_and_bit_identical`, and a full-pipeline comparison at 32,768 and
131,072 paths). Not switched on. Tier 1 if adopted (moves VaR, ES and EL; GARCH layer moves to Tier 1).

Book effect, as_of 2026-10-23, seed 7, data/ (0.1.3 assumptions):

| Measure | Regime (default) | GARCH | Change |
|---|---|---|---|
| VaR99, 131,072 paths | 63.98 | 63.79 | -0.3% |
| ES99 | 83.02 | 81.96 | -1.3% |
| ES97.5 | 65.89 | 65.53 | -0.6% |
| VaR95 | 36.12 | 36.51 | +1.1% |
| Expected loss | 0.529 | 0.457 | -13.6% |
| L-VaR99 | 69.26 | 69.08 | -0.3% |
| PDs | | | none move |
| Seeds 1-5, 32,768 paths: paired change VaR99 / ES99 / EL | | | -0.13 (sd 0.65) / -1.06 (sd 0.07) / -0.072 (sd 0.001) |

Reading: the book number barely moves because the changes offset. EWY rises from 25 to 42.8 percent
(South Korea equity tail contribution 6.3 to 9.6 $mm), while the Asian currencies fall (MYR 12 to 6.2,
PHP and JPY 12 to 8.5, SGD 7 to 4.3, CNY leg of the China local bond 13 to 9.6; their tail
contributions fall by 0.9 to 1.4 $mm each). The VaR99 change is inside Monte Carlo noise; the ES99 and
EL changes are systematic. The EL fall is the EWY position: a long position's loss is capped at
notional, and at 43 percent vol the cap binds on more paths (-0.071 of the -0.072). Runtime: about 7 s
more on the first run of a process (ten GARCH fits), nothing afterwards (fits cached; stress runs
reuse them); default path unchanged.

### 2026-10-23 EQ-B-0036: estimated t-copula as an option (GOV-021)

`copula.source` `"judgement"` (default) or `"estimated"` (`layer5_copula.fit_t_copula`,
`estimated_copula`). Data: weekly (Friday) log returns from data/market_history/prices.csv, 157 weeks
from 2023-10-27 to 2026-10-23. Country shock = mean of the standardised local-currency return and the
standardised ETF return, where they exist; FX is left out for administered quotes (GOV-034) and pegs.
Pakistan, Belize, Venezuela, Nigeria, Senegal (only an administered or pegged quote) and Zimbabwe (no
series) keep the judgement loadings; Africa's regional loading (Zambia only) is not identified and
stays 0.1. Estimator: joint maximum likelihood of the layer-5 structure (one global loading per
country, one regional loading per region, nu) on rank pseudo-observations, started from a least-squares
fit to the Kendall-tau correlation; 90 percent intervals from a moving-block bootstrap (8-week blocks,
200 replicates, seed 7). What stays judgement: the regime step-ups on the global loading (+0.10
Stressed, +0.20 Crisis) and the 1.5x global-stress multiplier. nu is estimated only with
`copula.nu_source "estimated"` (default `"judgement"`: estimated loadings, nu 5 / 4); with the estimate,
a stressed global regime uses nu minus 1, floored at 3. Default is bit-identical (`test_judgement_default_is_unchanged_and_source_validated`).

Fitted against judgement (squared loadings, as in `assumptions.json`):

| Parameter | Judgement | Estimate | 90% bootstrap interval |
|---|---|---|---|
| nu | 5 (calm) | 30.0 | 15.0 to 60 (upper bound of the search) |
| Global loading, Calm level: Singapore | 0.15 | 0.81 | 0.69 to 0.89 |
| Japan / South Korea / Malaysia | 0.15 | 0.53 / 0.51 / 0.51 | 0.37-0.65 / 0.36-0.65 / 0.32-0.66 |
| Brazil / Philippines / China | 0.15 | 0.39 / 0.34 / 0.31 | 0.30-0.51 / 0.13-0.54 / 0.20-0.46 |
| Colombia / India / Vietnam / Argentina | 0.15 | 0.16 / 0.12 / 0.12 / 0.11 | 0.06-0.31 / 0.03-0.26 / 0.03-0.27 / 0.03-0.22 |
| Zambia | 0.15 (Stressed 0.25) | 0.00 | 0.00 to 0.02 |
| Regional loading Asia / LatAm | 0.10 / 0.10 | 0.06 / 0.18 | 0.00-0.17 / 0.09-0.26 |
| Mean pairwise correlation, estimated countries | 0.24 (book, all 18) | 0.30 | 0.27 to 0.34 |

Book effect, production count, seed 7:

| Variant | VaR99 | ES99 | EL | Mean latent corr |
|---|---|---|---|---|
| Judgement (default) | 63.98 | 83.02 | 0.529 | 0.239 |
| Estimated loadings and nu (`nu_source estimated`) | 68.59 (+7.2%) | 84.87 (+2.2%) | 0.605 | 0.335 |
| Estimated loadings, judgement nu 5 (`copula.source estimated` alone) | 74.70 (+16.8%) | 98.34 (+18.5%) | 0.525 | 0.335 |
| Judgement loadings, estimated nu 30 | 58.22 (-9.0%) | 70.63 (-14.9%) | 0.606 | 0.239 |
| GARCH vols + estimated loadings and nu + hmm regime | 87.88 (+37.4%) | 108.35 (+30.5%) | 0.690 | 0.503 |

Seeds 1-5 at 32,768 paths, loadings and nu estimated: estimated minus judgement VaR99 +4.9 (sd 1.0), ES99 +1.9 (sd 0.9). No PD
moves. Runtime: about 8 s for the first fit in a process, cached afterwards.

Reading: the two estimated pieces pull in opposite directions. Market data say the Asian block is much
more correlated than the judgement 0.15 (Singapore 0.81), which raises VaR99 by 17 percent; and weekly
returns look close to Gaussian in the joint tail (nu 30), which cuts ES99 by 15 percent. The nu
estimate is the weak part: weekly co-movement over three mostly calm years is not the 12-month joint
default tail the copula has to describe, the likelihood is flat above nu 15 (profile log-likelihood
304.7 at 15, 306.5 at 30, 305.6 at 60 against 270.8 at 5), and the bootstrap interval runs into the
search bound. The loadings measure the dollar and global-equity factor, not sovereign credit linkage,
and say nothing about the six countries that drive the default tail (they keep judgement).

Recommendation for both options: do not switch either on as a whole. GARCH vols move VaR99 by noise and
ES99 by 1 percent today, so adopting them is low risk but buys little; if Sam wants market-consistent
marginals, adopt `vol_source garch` with the documented fallbacks and the Tier move for the GARCH layer.
For the copula, the defensible use is the estimated loadings with judgement nu (`copula.source
estimated`, `nu_source` left at judgement), a 17 percent VaR99 and 18 percent ES99 increase; the
estimated nu (`nu_source estimated`) should not be used.

**Estimated copula, point in time and single-country regions (review, 2026-10-23).** `estimated_copula(u, as_of)` fits on
price weeks dated on or before `as_of` (test `tests/test_market_fit_as_of.py`). A region with one estimated country
(Africa: only Zambia has a series) gets no fitted regional loading; the simulation keeps the judgement
`regime.regional_loading` 0.1 for it. That is not a double count: the fit had no regional peer to load on, so the 0.1 is
the judgement link to the non-estimated names of the region.

### 2026-10-23 EQ-B-0044: deterministic rate level shock (GOV-027, stress only)

`build_positions` reads an optional portfolio column `rate_shock_bp`, written only by a stress scenario's
`rates` shock (`engine/stress.py`, leg "local" -> Local bond, "hard" -> Eurobond), and stores
`rate_shock_bp` and `rate_mtm_pct = duration_yrs * rate_shock_bp / 100` on those positions (0 on every other
class). `simulate` adds `rate_mtm_pct / 100` to the position's per-path loss fraction before the direction
sign, the carry and the long-loss cap, so a long bond loses `notional * duration * dy / 1e4` on every path
where the cap does not bind. Without the column nothing is added and the positions table has no new
columns: base runs are bit-identical (losses SHA-256 equal at 20,000 requested paths; layer-6 pins
unchanged). Tests: `test_rate_shock_absent_adds_nothing`, `test_rate_shock_is_duration_times_dy_on_every_path`,
`test_rates_scenario_shock_reaches_layer6_by_leg`. Book numbers and the FED22 / TAPER13 proposal are in
`stress-scenarios.md`. Tier 2 (stress result); no default number moves.

### 2026-10-23 EQ-B-0047: GARCH stress anchor from the unstressed governed vols (review Low)

`build_positions` scaled the GARCH vol by `market` value / `GARCH_ANCHOR`, a constant equal to the 2026-10-23
`market.fx_vol` and `equity_vol`. A later `econquest change` to those keys would have rescaled every GARCH vol in
the base run without anyone touching layer 6. Now `garch_anchor(settings)` returns `monte_carlo.garch_vol.anchor`
when set, else the run's own `market` vols (ratio exactly 1 in a base run); `stress.apply_shocks` writes the
pre-patch values to that key whenever a scenario patches `market.fx_vol.*` or `market.equity_vol` (and leaves a
governed anchor alone). Base and all 13 available scenarios are bit-identical at 20,000 requested paths (losses
SHA-256 equal; ASIA97 and TAIWAN are the two that patch the vols). `GARCH_ANCHOR` stays one release, unused.
Tests: `test_vol_source_garch_keeps_stress_shocks_as_ratios` (now through `apply_shocks`) and
`test_garch_anchor_follows_governed_market_vols` (fails on the old code: a governed Float 15 / equity 30 scaled the
GARCH vols by 15/12 and 30/25). Stress runs that patch vols now carry the anchor in their stamped settings.

### 2026-10-23 EQ-B-0054: Monte Carlo error published with VaR99, ES99 and L-VaR99 (VF-004)

`layer6_montecarlo.mc_error`, called at the end of `simulate`, adds new metric keys only:
`var99_se_mm`, `es99_se_mm`, `lvar99_se_mm`, the 95% bands `var99_ci95_lo_mm` / `_hi_mm`,
`es99_ci95_lo_mm` / `_hi_mm`, `lvar99_ci95_lo_mm` / `_hi_mm`, and `mc_error_batches`,
`mc_error_batch_paths`. Every existing metric is bit-identical (20,000 requested, as_of 2026-10-23:
VaR99 74.2474, ES99 96.6153, EL 0.46273 before and after; `tests/test_layer6_montecarlo.py`).
Batch count `monte_carlo.mc_error_batches` (code default 32, not in `assumptions.json`).

Method: batch means. The loss vector, in simulation order, is cut into 32 contiguous blocks of equal
size (4,096 paths at the production count, 1,024 at 32,768); each block of a scrambled Sobol
sequence is itself a balanced 2^m block. VaR99 and ES99 are estimated per block, SE = sd(block
estimates) / sqrt(32), band = full-sample estimate +/- t(0.975, 31) x SE. L-VaR99 adds a
deterministic liquidity cost, so its SE is the VaR99 SE.

Limitation for scrambled Sobol: the blocks share one scramble, so they are not independent
replicates, and each block carries the small-sample bias of a 99% quantile on 4,096 paths. The
batch SE is the error of a plain Monte Carlo estimator of the same size; the full Sobol set is more
accurate than that, so the published SE is conservative. The randomised-QMC check (16 independently
seeded runs, sd of the estimate) gives the smaller figure below; it costs 16 full simulations, so it
is a validation check, not a per-run output.

| 0.1.4 base, as_of 2026-10-23 | VaR99 | SE (batch) | 95% band | seed sd (16 seeds) | ES99 | SE (batch) | 95% band | seed sd |
|---|---|---|---|---|---|---|---|---|
| 131,072 paths (100,000 requested) | 74.35 | 0.40 (0.54%) | 73.53-75.17 | 0.27 | 96.48 | 0.45 (0.46%) | 95.57-97.39 | 0.25 |
| 32,768 paths (20,000 requested) | 74.25 | 0.74 (1.0%) | 72.74-75.76 | 0.62 | 96.62 | 0.97 (1.0%) | 94.64-98.59 | 0.42 |

Limit reading: L-VaR99 is 79.63 $mm against the 80 $mm warning level (0.8 x the 100 limit), a margin
of 0.37 $mm, which is 0.92 batch SE (1.4 seed sd). The 95% band for L-VaR99 is 78.82-80.45, which
contains 80: the "under the warning band" verdict is inside simulation noise and should be reported
as "at the warning band". The other two verdicts are robust: ES99 (84% of its 115 limit) is 4.48
$mm, 10 SE, above its 92 warning level; VaR99 (78% of 95) is 1.65 $mm, 4.1 SE, below its 76 level.

### 2026-10-24 EQ-B-0063: bounded market move and the Eurobond default / spread overlap (GOV-047, RCA-B-004)

Two settings in `layer6_montecarlo.simulate`, both off by default (bit-identical: base at 20,000
requested, as_of 2026-10-23, VaR99 72.99996, ES99 95.67995, EL 0.471282, same loss-vector hash before
and after; layer 6 pins at rtol 1e-9). Neither is in `assumptions.json` yet; switching either on is a
Tier 1 change (it moves VaR, ES and EL).

**`monte_carlo.market_move`**: "linear" (today) or "lognormal". Lognormal takes the price return
R = exp(sigma zn - sigma^2/2) - 1 with sigma = signed vol / 100 and zn = Phi^-1(F_t,nu(latent)), the
normal score of the same latent. Ranks are unchanged, so the copula dependence and the joint law with
the event thresholds are unchanged. E[R] = 0 exactly and R > -100%. The normal score is needed: E[exp(s T)]
is infinite for a Student t, so exp of the t latent itself has no mean. The cost is that the market-move
marginal is lognormal, not scaled t. By leg:
- FX legs: the FX return is lognormal. Peg (2%) and Dollarized (0%) are almost unchanged. The T&C jump
  (stress depreciation + convertibility haircut) is still added.
- Local bonds: the combined rates + FX vol (duration x local_rate_vol + fx_vol) drives one lognormal
  price. The default LGD and T&C depreciation jumps are still added, so the cap can still bind (residual
  relief 0.014).
- Equity: lognormal at 25%. The GPD expropriation / PV jumps are added, so equity carries most of the
  residual relief (0.12).
- Shorts: a short loses +R, which is right-skewed and unbounded. The mean is unchanged, but at the same
  sigma the short's tail is heavier than under linear (99th percentile at sigma 60%: 2.37 vs 1.40 x
  notional). There are no shorts above 12% vol in the book.
- CDS protection: the vol is negative, so R rises when the latent falls (protection gains). The MTM loss
  is bounded at 100% of notional, which is still loose: the real bound is the protection's PV.
- Scenario rate shock (`rate_mtm_pct`): still a deterministic additive mark.
- Most of the VaR/ES fall comes from the convexity at high vol: Eurobond spread vols reach the 60%
  `vol_cap`, where the linear model loses 140% of notional at the 1% point and the lognormal loses 79%.
  Control run with the normal score kept linear: VaR99 72.13, ES99 92.29, so the switch from a t to a
  normal marginal accounts for about 1.0 VaR / 3.1 ES, and the lognormal shape for the remaining 5.2 / 6.1.

**`monte_carlo.default_spread_overlap`**: "additive" (today: LGD added to the spread move on a default
path), "lgd_only" or "compound". It applies to Eurobonds and CDS protection.
- "lgd_only" is recovery of face. On a default path the Eurobond loses its LGD draw and nothing else
  (spread and scenario rate marks dropped), and the CDS pays its LGD draw.
- "compound" is recovery of market value, for the Eurobond only: m + (1 - m) LGD, the pre-default
  mark-down plus LGD on what is left. CDS settles on face, so under "compound" it behaves as under
  "lgd_only".
- Survivor re-centring: default paths are bad-z paths. Dropping their market loss would leave the
  survivors with a mean gain, which is a new EL credit of about 1.0 $mm on this book (seen in a
  development run). The survivors' move is therefore shifted by w E[m 1{default}] / (1 - p), closed
  form in `default_path_move`, with w = 1 for lgd_only and E[LGD] for compound. Under compound the
  term is E[min(m, 1) 1{default}], because the 100% clip is what the default path removes. The uncapped
  EL stays at PD x LGD - carry. Review fix, 2026-10-24: the first version used the unclipped E[m] under
  compound and over-shifted when m > 1 near the 60% vol cap. Uncapped EL was 1.609 vs 1.523 at 20k; it
  is now 1.521. The lgd_only and lognormal rows are bit-identical before and after the fix.
- Scenario rate mark (`rate_mtm_pct`, rm): deterministic, so it is not re-centred. A defaulted bond is
  a par claim, so dropping the mark on default paths is real. Under a rates stress it lowers the mean
  loss by about p x rm (lgd_only) or p x E[LGD] x rm (compound). Base runs carry no rm.

Evidence (`run_pipeline`, as_of 2026-10-23, 100,000 requested = 131,072 Sobol paths, seed 7, $mm, batch SE):

| run | VaR99 (SE) | ES99 (SE) | EL | L-VaR99 | EL uncapped | cap relief | layer 6 s |
|---|---|---|---|---|---|---|---|
| today | 73.11 (0.31) | 95.41 (0.36) | 0.456 | 78.39 | 1.512 | 1.056 | 0.66 |
| lognormal only | 66.89 (0.26) | 86.16 (0.32) | 0.922 | 72.17 | 1.510 | 0.588 | 1.47 |
| lgd_only only | 68.14 (0.27) | 89.78 (0.35) | 1.194 | 73.42 | 1.512 | 0.318 | 0.66 |
| both (lognormal + lgd_only) | 62.35 (0.25) | 80.93 (0.31) | 1.374 | 67.63 | 1.510 | 0.136 | 1.47 |
| compound only | 70.27 (0.28) | 92.90 (0.35) | 1.167 | 75.55 | 1.512 | 0.345 | |
| lognormal + compound | 63.15 (0.25) | 82.17 (0.32) | 1.374 | 68.43 | 1.511 | 0.136 | |

Cap relief by class: today, Eurobond 0.74, equity 0.23, local bond 0.09. Under both: Eurobond 0,
equity 0.12, local bond 0.014. The L-VaR99 SE equals the VaR99 SE. Layer 6 time is the median of three
warm runs; the extra time is the normal-score transform.

Standard stresses, ES99 at 100,000 requested (the change against base in brackets):

| scenario | today | both | both vs today |
|---|---|---|---|
| A | 155.43 (+62.9%) | 131.71 (+62.7%) | -15.3% |
| B | 102.05 (+7.0%) | 88.85 (+9.8%) | -12.9% |
| C | 114.30 (+19.8%) | 96.94 (+19.8%) | -15.2% |
| DOWNGRADE | 100.94 (+5.8%) | 84.81 (+4.8%) | -16.0% |
| TAIWAN | 164.85 (+72.8%) | 139.97 (+73.0%) | -15.1% |
| HORMUZ | 166.81 (+74.8%) | 141.07 (+74.3%) | -15.4% |
| TARIFF | 154.84 (+62.3%) | 131.49 (+62.5%) | -15.1% |
| CHINA_HL | 165.06 (+73.0%) | 139.56 (+72.5%) | -15.4% |

Regression tests (`tests/test_layer6_montecarlo.py`):
- explicit default values are bit-identical to no key, and unknown values raise;
- the normal score is finite, monotone and odd;
- the lognormal loss is mean-zero and below 1;
- `default_path_move` matches numerical integration, with and without the 100% clip;
- under each option, compound + linear included, the uncapped EL holds within MC error while the cap relief falls;
- under lgd_only, Eurobond and CDS default paths settle at LGD, the survivors shift by a constant, and
  Eurobonds never reach the cap;
- compound equals m + (1 - m) LGD;
- under both options the cap-relief rise for nu 5 -> 4 is less than half of today's.

Open: the residual relief from equity and local-bond jumps added on top of a bad market move. A
multiplicative composition (1 - (1 + R) prod(1 - sev)) would remove it. That is a further Tier 1 choice,
not built.
