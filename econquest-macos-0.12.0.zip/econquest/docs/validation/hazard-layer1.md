# Model validation: Layer 1 discrete-time hazard

Date: 2026-10-23. Code: `econquest/engine/layer1_hazard.py`. Parameters: `data/assumptions.json`
keys `layer1_paper_coefficients`, `layer1`, `ratings_pd`. Status: the coefficients are the paper's
illustrations applied to standardized predictors and calibrated in location and scale to the rating
prior; they are not estimated on default data. Recalibration on a real default panel is reported
separately in [hazard-fit-report.md](hazard-fit-report.md).

## Purpose

Layer 1 produces the base 12-month sovereign default probability per country, `pd_model`, before any
market, text or prediction-market information is added. It follows section 3.1 of the paper: a
logistic hazard on six macro-fiscal and political predictors, with a monotone challenger model (the
paper names LightGBM; here the rating-implied PD) reconciled in log-odds space.

## Where it sits in the pipeline

`run_pipeline` calls `L1.run_layer1(u, settings, sc.pillar_aggregated.loc[4])` right after the
scorecard. The output column `pd_model` is the prior that `L2.posterior` updates; `pd_hazard` and
`pd_rating` are carried into the country table and the workbook's Risk Engine rows R31 to R33 for
inspection.

## Assumptions

1. Default within 12 months is a Bernoulli event with probability `expit(intercept + sum_j beta_j
   z_j)` where `z_j` is a standardized predictor.
2. The six predictors (`FEATURES`) and how `build_features` constructs them:
   - `debt_gdp`: indicator 1.3 (percent of GDP).
   - `stfx_debt_reserves`: indicator 2.9 (short-term external debt, percent of reserves).
   - `reserves_months_imports`: `reserves / exports * 12` from the Country Profile, both in percent
     of GDP, so exports proxy imports.
   - `primary_deficit_gap`: minus indicator 1.6 (the primary balance gap, so a positive value is a
     deficit relative to the debt-stabilising balance). The separate `primary_deficit` column (a level, used
     only by a fitted model) is minus WEO GGXONLB_NGDP for year `as_of.year - predictor_lag`.
   - `pitf_instability`: pillar 4 aggregate divided by 25, rescaling the 0 to 100 pillar to the 0 to
     4 PITF range.
   - `commodity_export_shock`: `commgap / 10`, the main export's price gap to its 10-year average in
     tens of percent, positive is favourable.
3. Standardization uses fixed centres and spreads from `layer1.feature_scale` (not sample moments):
   debt 70 and 45; short-term debt 50 and 30; reserves months 6 and 4; deficit gap 1 and 2; PITF 1.5
   and 1; commodity shock 0 and 2.
4. The coefficient vector is the paper's table 7.1 (`layer1_paper_coefficients`): intercept -4.8512,
   debt 0.0382, short-term debt 0.0415, reserves -0.312, deficit gap 0.1854, PITF 0.421, commodity
   shock -0.2241. Only the signs and relative sizes are used; see Estimation.
5. The challenger is `RatingChallenger`, a lookup from the agency rating to a 12-month PD
   (`ratings_pd`): AAA 0.0001, BBB 0.0019, BB 0.0065, B- 0.05, CCC+ 0.12, CCC 0.20, CC 0.35, SD and
   D 0.60.
6. Reconciliation: `logit(pd_model) = w logit(pd_hazard) + (1 - w) logit(pd_rating)` with
   `layer1.hazard_weight 0.5`.

## Data

Inputs are the indicator table and the Country Profile described in `scorecard.md`. For this layer
specifically: 1.3 and 1.6 come from the IMF WEO live feed for most countries after the 2026-10-23
pull, 2.9 from World Bank IDS where available, reserves and exports from World Bank WDI, the
commodity gap and the pillar 4 levels are analyst estimates. The ratings in `countries.csv` are
entered by hand. Current feature values range widely: debt/GDP from 28 (Vietnam) to 199 (Japan);
short-term debt/reserves 20 to 100; reserves months 0.6 (Zimbabwe) to 16.9 (Japan); deficit gap -7.8
(Zambia, a surplus relative to stabilising) to +5 (Venezuela); PITF 0.48 (Belize) to 3.0
(Venezuela); commodity shock -1.5 to +6.0 (Senegal and Zimbabwe at 60 percent above average).

There is no default panel in the repository. `fit_firth` and `econquest fit-hazard --panel` exist
but have never been run on real data inside this project; the recalibration work and its evidence
live in [hazard-fit-report.md](hazard-fit-report.md).

## Estimation or calibration

`HazardModel.from_settings` in mode `paper_standardized` with `calibrate_to =
rating_prior_location_scale`:

1. Compute the linear index `idx = -4.8512 + sum beta_j z_j` on standardized features.
2. Regress `logit(pd_rating)` on `idx` by least squares (`np.polyfit`, one point per country in the run, 18 today) to get slope `b`
   and intercept `a`. Floor `b` at 0.25 so the paper's signs are never flipped and at least a
   quarter of the spread survives.
3. Multiply every coefficient by `b` and set the intercept to `a + b * (-4.8512)`.

On 2026-10-23 the fit gives slope 1.711 and intercept -4.019, so the effective coefficients are debt
0.0654, short-term debt 0.0710, reserves -0.534, deficit gap 0.317, PITF 0.720, commodity shock
-0.383 per standard unit. The resulting `pd_hazard` ranges from 0.10 percent (Japan) to 19.6 percent
(Venezuela); Zambia 0.2 percent, Zimbabwe 0.7 percent, Senegal 1.3 percent, Argentina 0.9 percent,
Pakistan 1.1 percent.

Why this and not the raw coefficients: as the README notes, the paper's raw-unit coefficients do not
reproduce its own case study (they give a 96 percent hazard where the paper reports 8.4 percent).
The `l1_raw_units_uncalibrated` run below shows what the raw coefficients would do here.

The alternative `calibrate_to = median_rating_prior` shifts only the intercept so the median hazard
equals the median rating PD.

Fitted mode (`layer1.mode = "fitted"`, not active; switching is Tier 1 and needs Sam). Updated 2026-10-23 under
EQ-B-0013, EQ-B-0015 and EQ-B-0020:

- Predictor alignment (EQ-B-0013). The panel is built with `predictor_lag` 1: row t uses year t-1 values to
  predict a default starting in t+1. At run time `run_layer1` takes every WEO-sourced feature of the fitted block
  (`debt_gdp`, `primary_deficit`, `current_account`, `real_growth`, `inflation_log`) from the loaded WEO history
  for year `as_of.year - predictor_lag`, with the panel's transforms, instead of from the indicator table. The lag
  is read from `layer1_fitted.predictor_lag` (written by `FitResult.fitted_block`). A block without the key is
  read as lag 1 and `attrs["model"]["predictor_lag_source"]` says "assumed". The block in `assumptions.json` was
  fitted at lag 0 (contemporaneous, before EQ-B-0006: `data/panel/hazard_panel.csv` row ARG 1998 carries 1998 WEO
  debt) and since 2026-10-23 says so with `"predictor_lag": 0`, so layer 1 aligns it correctly; it should still be
  replaced by a lag-1 refit before any fitted switch.
  World Bank-sourced features (`stfx_debt_reserves`, `reserves_months_imports`, `pitf_instability`) are still
  built from the indicator table and Country Profile with definitions that differ from the panel's (WGI PV.EST
  rescaled to 0-4 against pillar 4 / 25; WDI months of imports against reserves / exports x 12; WDI
  DT.DOD.DSTC.IR.ZS against indicator 2.9). Since EQ-B-0029 a fitted block that lists any of them, or any feature
  that is not a hazard_panel feature, is refused for the whole run like a missing WEO input (GOV-046): the run
  uses `paper_standardized`, `attrs["model"]["fitted_fallback"]` says why and `attrs["model"]["fitted_unaligned"]`
  lists each feature with the panel series and the run-time substitute (`unaligned_fitted_features`). The shipped
  block is WEO-only and is not affected; paper mode never consults the check. Aligning them needs World Bank
  history in the Universe (the loader reads only `raw_weo.csv`, and `raw_worldbank.csv` has none of the three
  series): handed to Team A, see open item 7.
- No wrong-unit fallback (GOV-046). If any fitted predictor is missing for that year (no WEO history loaded, or
  a country without a value), the fitted model is refused for the whole run. The run uses `paper_standardized`
  for every country, `attrs["model"]["fitted_fallback"]` names the missing inputs and a `RuntimeWarning` is
  raised. Minus indicator 1.6, a gap rather than a level, is never fed to a fitted model. A fallback was chosen
  over an exception because it keeps the validated production model running and flags the change, instead of
  stopping the daily run. Per-country mixing of two models was rejected. With the 2026-10-23 live vintage,
  lag 1 would refuse: Venezuela has no 2025 WEO debt and Singapore has no 2025 primary balance.
- Default episodes (EQ-B-0015). `hazard_panel.load_crag` reads the CRAG database through Team A's
  `ingestion.default_panel.import_crag`. It accepts the 2026 long layout (xlsx or Valet DEBT_2026 CSV), the older
  wide layout, a DataFrame, or an already converted episode CSV. ISO3 codes come from the file or a name lookup;
  unmapped names raise. The old `name[:3]` guess (Zambia -> "ZAM") is removed. `load_events` dispatches for
  `fit-hazard --defaults`, and `load_crag_workbook` is a deprecated wrapper.
- Point-in-time rules (EQ-B-0031, HO-20261023-A-B-007). With a `vintage` column, row t uses the latest release
  published by the end of year t; same-year releases are ordered by full date with a stable sort, so October
  beats April deterministically. WEO history reaches back to 2007-10, so rows before the first release take the
  earliest release by default (`pre_first_release="earliest"`, revisions embedded) and the report states the
  window: rows from `pit_from` are point-in-time, earlier rows are "partial-pre-<first release>". This keeps the
  1980s-1990s defaults needed for the 30-event gate; the out-of-sample window (2014 onward) is fully
  point-in-time. `"drop"` starts the panel at the first release instead. World Bank features have no vintages
  (wbgapi serves the current database only), so a fit that includes them reports `point_in_time: partial`; that
  is accepted until EQ-B-0029 decides whether they stay in the fitted feature set.
- Gate (EQ-B-0020). `hazard_panel.gate_check` requires OOS AUC >= 0.75 (`GATE_MIN_AUC`; governance status uses it since EQ-B-0028; `fit-hazard --apply` still uses
  0.70 and `<=` until Team C lands HO-20261023-B-C-008), at least 30 events, and an OOS Brier score strictly below the trailing training-window
  base rate. `refit_from_files` runs panel, fit, validation, gate and report end to end and writes only under
  its output folder. The 2026-10-23 pilot run (`outputs/hazard_refit/`) used `sovereign_defaults.csv` and
  `raw_weo.csv` at lag 1: 391 country-years, 9 events, 15 countries, 1981-2024. OOS 2014-2024 covered 152 rows
  and 4 events, with AUC 0.789 (pass, but on 4 events), Brier 0.0361 against 0.0258 for the trailing base rate
  (fail), and 9 events against the required 30 (fail). The gate is not cleared. The production refit needs the
  full WEO panel and vintages (Team A EQ-A-0015/0016).

Firth estimation: `fit_firth` implements the penalized score `X'(y - p + h(1/2 - p))` with the
hat-matrix diagonal `h`, Fisher scoring with a pseudo-inverse, 50 iterations, tolerance 1e-8.
`test_firth_recovers_signs` checks it on 2,000 simulated rows. `fit_hazard_from_panel` expects
columns named as `FEATURES` plus `event`, returns raw-unit coefficients (`scale = None`).

## Outputs and how they are used

Per country: the six features, `pd_hazard`, `pd_rating`, `pd_model`, and `attrs["model"]` with
coefficients, intercept, scale and calibration. Base run `pd_model` (percent): Singapore 0.09, Japan
0.07, South Korea 0.18, China 0.23, Malaysia 0.34, Philippines 0.36, India 0.34, Vietnam 0.58,
Brazil 1.05, Colombia 0.90, Nigeria 1.55, Zambia 1.75, Argentina 2.13, Belize 2.26, Pakistan 2.34,
Senegal 4.02, Zimbabwe 9.56, Venezuela 37.7.

`pd_model` is the Layer 2 prior. It also enters the arbitrage scan for sovereign-default contracts
and the market-complacency signal through `pd_default`.

## Limitations and known gaps

- Interim refit on shared World Bank data (EQ-B-0104, 2026-10-25): NOT CLEARED. OOS AUC 0.597 on crag_v1 (44 events) and 0.613 on the current list (32 events), against 0.75; Brier equal to the trailing base. Layer 1 stays `paper_standardized`. Details: `hazard-refit-wb-interim.md`.

- The coefficients are illustrations from the paper, not estimates. The location and scale come from
  ratings, so the hazard inherits the agencies' view and cannot disagree with them in level, only in
  cross-section through the six predictors.
- The calibration is cross-sectional (EQ-B-0034): the location-scale fit (and the `median_rating_prior` and
  fitted-mode intercept shifts) uses every country in the run, so adding countries moves every country's hazard
  PD even when no input changes. On a synthetic 70-country universe (perturbed copies of the 18, 2026-10-23,
  20,000 requested paths) the slope moved from 1.711 to 1.881 and the intercept from -4.019 to -4.094; the 18 desk
  countries' `pd_default` moved by up to 144 bp (Zimbabwe 78.4 to 77.0 percent; median 1.8 bp) and EL on the
  unchanged book from 0.53 to 0.45 mm. Expanding the universe is therefore a Tier 1 change through layer 1 alone.
  `layer1.calibration_universe` (a list of names or ISO3 codes; absent or null = every country, today's behaviour
  exactly) pins the calibration set: with it set to the 18, the 18 countries' layer 1 and layer 2 outputs are
  bit-identical at 70 countries (`tests/test_scale_n_countries.py`). The choice of calibration set for the 70+
  universe (desk 18, all rated countries, or EM only) is Sam's.
- With 18 countries and two defaulted sovereigns rated SD (both mapped to 0.60), the location-scale
  fit is heavily influenced by Venezuela and Zimbabwe. Zimbabwe's hazard (0.7 percent) is far below
  its rating PD (60 percent) because its debt/GDP (33.5) and deficit gap are benign in the data; the
  reconciliation at `w = 0.5` lands at 9.6 percent. This is the clearest case of the hazard
  disagreeing with the rating.
- The rating prior itself is a hand-entered table with no vintage or source; the SD/D value of 0.60
  is a judgement.
- `reserves_months_imports` uses exports for imports; for Singapore (exports 178 percent of GDP) the
  ratio is not a months-of-imports measure in any usual sense.
- The pillar 4 aggregate used as PITF depends on analyst level entries and on the scorecard's
  worst-indicator blend, so scorecard discretion leaks into the hazard.
- The commodity-shock feature is favourable for Senegal and Zimbabwe (+6 standard units each, driven
  by `commgap 60`), which pushes their hazards down by `0.383 * 6 = 2.3` log-odds. A reviewer should
  check whether a 60 percent price gap is right for both.
- There is no out-of-sample test, AUC, calibration plot or confidence interval in the live pipeline.
  Those belong to the recalibration report.

## Sensitivity

Runs at 20,000 Sobol paths. The hazard weight and calibration mode change PDs directly; the book
effect is muted because Venezuela is at the 99 percent cap in every variant and most tail risk comes
from market moves.

| Variant | VaR99 $mm | ES99 $mm | Mean PD | Argentina | Pakistan | Senegal | Zambia | Zimbabwe |
|---|---|---|---|---|---|---|---|---|
| Base (`hazard_weight 0.5`) | 65.98 | 87.05 | 0.1387 | 0.119 | 0.115 | 0.239 | 0.066 | 0.784 |
| `hazard_weight 0` (rating only) | 67.42 | 86.99 | 0.1688 | 0.154 | 0.154 | 0.367 | 0.159 | 0.990 |
| `hazard_weight 0.25` | 67.17 | 87.18 | 0.1584 | 0.135 | 0.133 | 0.298 | 0.103 | 0.990 |
| `hazard_weight 0.75` | 65.32 | 86.90 | 0.1192 | 0.104 | 0.098 | 0.190 | 0.042 | 0.549 |
| `hazard_weight 1` (hazard only) | 64.85 | 86.93 | 0.1031 | 0.091 | 0.084 | 0.150 | 0.026 | 0.348 |
| `calibrate_to median_rating_prior` | 65.41 | 86.06 | 0.1342 | 0.112 | 0.105 | 0.216 | 0.069 | 0.757 |
| Raw-unit paper coefficients, no calibration | 71.39 | 91.55 | 0.1853 | 0.235 | 0.210 | 0.535 | 0.122 | 0.990 |

Reading: the final `pd_default` for the frontier names moves by a factor of about 1.7 between the
two extremes of `hazard_weight`, and Zimbabwe's by a factor of 2.8. The raw paper coefficients
overstate PDs across the board (Senegal 54 percent), which is why they are not used as printed. The
book VaR is insensitive (plus or minus 2 percent) because it is dominated by market volatility in
the local-bond and FX legs rather than by default events.

## Benchmarks and evidence

- Internal consistency: `test_probabilities_are_bounded_and_ordered` requires Venezuela > Argentina
  > Brazil > Singapore on `pd_default`, which holds.
- Rating prior comparison (base run): `pd_model` is below the rating PD for every country rated B-
  or worse (Pakistan 2.3 vs 5 percent, Argentina 2.1 vs 5, Senegal 4.0 vs 12, Zambia 1.8 vs 12,
  Zimbabwe 9.6 vs 60, Venezuela 37.7 vs 60) and above it for the investment-grade names (Singapore
  0.09 vs 0.01, China 0.23 vs 0.05). The hazard therefore compresses the cross-section relative to
  the agencies. Whether that is a feature of the predictors or of the location-scale fit is a
  question for the recalibration report.
- Market comparison: `pd_market = spread / 1e4 / 0.6` is above `pd_model` for all 18 countries
  (`z_cds` is positive everywhere, from 0.80 to 3.45 log-odds), so the market term in Layer 2 always
  raises the PD. A base prior that is uniformly below spread-implied PDs is plausible (spreads carry
  a risk premium) but has not been tested.
- Recalibration on a real default panel, with out-of-sample AUC and calibration plots, is the
  subject of [hazard-fit-report.md](hazard-fit-report.md); the roadmap target (item 2.3) is 1980 to
  2025 defaults.

## Open items for review

1. Replace the location-scale fit with Firth estimates from the default panel once
   [hazard-fit-report.md](hazard-fit-report.md) is accepted, and set `layer1.mode` accordingly.
2. Decide the hazard weight on evidence (Brier score of `pd_hazard` vs `pd_rating` on the panel)
   rather than the current 0.5.
3. Review the rating-to-PD table: source, horizon (12-month), treatment of SD/D at 0.60 and of CCC-
   at 0.27.
4. Check the `commgap` entries of 60 percent for Senegal and Zimbabwe, which cut their hazards by
   2.3 log-odds.
5. Add imports to the Country Profile so `reserves_months_imports` is what its name says.
6. Document how the pillar 4 to PITF rescaling (divide by 25) was chosen.
7. Before any fitted switch: refit so the block carries `predictor_lag`, and either restrict it to WEO features or
   give the World Bank-sourced features run-time values with the panel's definitions and lag. EQ-B-0029 (2026-10-23):
   fitted mode now refuses a block with unaligned features, so a WB-feature fit cannot run on substitutes.
   Recommendation: keep the fitted feature set WEO-only for the first fitted switch; add the WB features only after
   Team A loads World Bank history (DT.DOD.DSTC.IR.ZS, FI.RES.TOTL.MO, PV.EST, by year) into the Universe and
   layer 1 sources them like the WEO ones (follow-up ticket). WB data has no vintages, so the fit would stay
   `point_in_time: partial`.
8. GOV-046 is addressed in code (fitted mode refuses missing or substituted inputs). Close it in the issues log
   after review.
9. Choose the layer 1 calibration set for the expanded universe (`layer1.calibration_universe`, EQ-B-0034): the
   location-scale fit is cross-sectional, so the 70+ list moves every PD unless the set is pinned.
