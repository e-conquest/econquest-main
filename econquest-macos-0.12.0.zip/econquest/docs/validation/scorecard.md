# Model validation: 83-indicator scorecard

Date: 2026-10-23. Code: `econquest/scorecard/scoring.py`. Parameters: `data/assumptions.json` keys
`scorecard`, `floors`, `boom_trigger`, `stress_path`. Inputs: `data/rulebook.csv`,
`data/indicators.csv`, `data/countries.csv`, `data/adjustments.csv`. Status: method reproduced from
the workbook and regression-tested against it; most indicator values are seed estimates.

## Purpose

The scorecard turns 83 raw indicators per country into seven pillar scores (0 to 100, higher is
riskier), a composite score and a 1 to 10 grade. It is the paper's Appendix A rulebook and the
workbook's Indicator Scores, Pillar Scores and Dashboard tabs. Downstream it provides: the scorecard
deviation term in the Layer 2 log-odds update (`composite - score_centre`), the pillar 4 aggregate
that becomes the PITF instability predictor in Layer 1, the peril drivers (pillars 2, 3, 4 and 6 and
indicators 2.7 and 4.10) that feed the transfer, expropriation, political-violence and sanctions
probabilities, and most of the 25 trading signals.

## Where it sits in the pipeline

`run_pipeline` first lets `engine/gpr.py` overwrite indicator 4.10 with the GPR-uplifted level, then
calls `score_universe(u, settings)`. Everything after that (Layers 1 to 6, signals, arbitrage) reads
from the returned `Scorecard` object. Nothing in the scorecard depends on later layers, so it can be
validated in isolation with `score_universe` alone.

## Assumptions

1. Each numeric indicator maps to a 0 to 100 score by straight-line interpolation between five
   threshold points `t0, t25, t50, t75, t100` (`interp_score`). Direction is carried by the ordering
   of the thresholds (increasing or decreasing). Values beyond `t0` or `t100` are clamped by
   `np.interp`.
2. Indicator 5.13 (real policy rate) is two-sided: the score is the larger of the high-side and
   low-side interpolations (`low0..low100` columns). It is the only two-sided indicator in the
   rulebook.
3. Level indicators (type `Level 0-4`, 37 of 83) score `clip(x, 0, 4) * 25`.
4. Eight stress-path indicators (1.3, 1.4, 1.6, 1.7, 2.1, 2.8, 5.5, 5.6; `stress_path = Y` in the
   rulebook) are scored twice, on the baseline value and on a combined-shock value built by
   `stress_inputs`, and the worse score is kept (`np.fmax`). The shock is: depreciation `dep_float
   20`, `dep_managed 15`, `dep_peg 0` percent; `growth_shock -2` points; `rate_shock 2` points on
   `repricing_share 0.25` of debt; `pb_loss_per_pp 0.3` of primary balance per point of growth lost;
   export shock `commodity_shock -30`, `tourism_shock -25`, `manufacturing_shock -10` percent on the
   main export; `inflation_passthrough 0.3` of the depreciation. Reserves (2.1) only fall for Peg
   and Dollarized regimes.
5. Pillar aggregate = `(1 - worst_blend) * weighted average + worst_blend * worst indicator`, with
   `worst_blend 0.2`. Only indicators with weight at least `min_weight_worst 0.1` are eligible for
   the worst term (fix 1 of the methodology). Missing indicator values are dropped from both terms
   and the weights renormalised.
6. Final pillar = aggregate + trigger add-ons (capped at `trigger_cap 15`, `trigger_cap_p7 10` for
   pillar 7) + analyst adjustment (clipped to plus or minus `max_analyst_adj 10`), clamped to 0 to
   100, then floored at the override floor implied by the country flags.
7. The boom trigger adds `boom_trigger.points 10` to pillar 3 when the main export price is at least
   `price_above_avg 25` percent above its 10-year average and the pillar 1 aggregate is at least
   `pillar1_at_least 60` (both conditions, fix 5).
8. Override floors (`floors`): default flag -> pillar 1 at 90; external arrears, parallel-rate
   premium at least 100 percent or indicator 2.7 at level 4 -> pillar 2 at 85; expropriation flag ->
   pillar 3 at 80; coup flag 85 or no-pay flag 90 on pillar 4; inflation 5.5 at least 100 percent ->
   pillar 5 at 90, bank-crisis flag 85; armed conflict 6.1 at level 3 or more -> pillar 6 at 85,
   emergency flag 70; disaster flag -> pillar 7 at 80.
9. Composite = sum of final pillars times pillar weights (0.25, 0.20, 0.15, 0.15, 0.10, 0.10, 0.05).
   Small states (population below `small_state_pop_below 1.5` million or 1-in-100 disaster loss 7.2
   at least `small_state_tail_loss_at_least 25` percent of GDP) use the small-state weights (0.224,
   0.179, 0.134, 0.134, 0.089, 0.089, 0.15), which move 10 points of weight to the climate pillar.
   Belize is the only small state in the snapshot.
10. Grade = `min(10, int(composite // 10) + 1)`.

The thresholds, weights and the choice of 83 indicators are the analyst's rulebook. They are
judgement, not estimates: no threshold has been fitted to default outcomes.

## Data

- `rulebook.csv`: 83 rows, 7 pillars (9, 12, 10, 11, 14, 14, 13 indicators), weights sum to 1.0
  within each pillar (checked by `Universe.validate`). 46 numeric and 37 level indicators. The `api`
  column marks 25 indicators as Manual and the rest as scripted or planned feeds.
- `indicators.csv`: 83 x 18 raw values. After the 2026-10-23 live pull (`econquest fetch --apply`),
  the audit trail (`data/audit_trail.csv`) classifies the 1,494 Inputs cells as: 224 from a live
  feed (IMF WEO, World Bank, BIS), 1,170 seed estimates, 100 seed estimates where the feed returned
  nothing. So about 85 percent of the scorecard inputs are still analyst or model-assistant
  estimates dated October 2026. In the current run 14 indicator cells are blank and score NaN
  (dropped from the pillar average).
- `countries.csv`: flags (`default`, `extarrears`, `exprop`, `coup`, `nopay`, `bankcrisis`,
  `emergency`, `disaster`), parallel-rate premium, population, exports, reserves, FX regime, export
  type and commodity price gap, which drive floors, small-state status and the stress path. Flags
  set today: Venezuela default and external arrears, Zimbabwe default and external arrears; no other
  flag is on.
- `adjustments.csv`: trigger inputs and analyst adjustments. All analyst adjustments are zero in the
  snapshot; the only non-zero trigger is the boom trigger (computed, not entered) on Senegal, Zambia
  and Zimbabwe (commodity gap 60, 35 and 60 percent with pillar 1 aggregate above 60).

## Estimation or calibration

There is no statistical estimation. The scorecard is a deterministic transformation and its only
"calibration" is the regression test `tests/test_panoptix.py::test_scorecard_matches_workbook`,
which runs `score_universe` on the October 2026 seed snapshot (`tests/seed_data/`) and requires the
composite to agree with the workbook within 0.15 points, each final pillar within 0.1 points and the
grades exactly. The README states the agreement as "to 0.1 points".

Because `data/` now holds live values for 224 cells, the composite computed today differs from
`data/workbook_reference.json`: today's base run gives Vietnam 28.8 (reference 29.1), Pakistan 66.5
(66.9), Argentina 56.2 (56.4), Senegal 56.5 (56.5), Zimbabwe 74.5 (75.0), Venezuela 84.3 (84.5). The
regression test therefore points at the frozen seed folder, not at `data/`.

## Outputs and how they are used

`Scorecard` dataclass: `indicator_scores` (worse of base and stress), `base_scores`,
`stress_scores`, `pillar_wavg`, `pillar_worst`, `pillar_aggregated`, `pillar_final`, `triggers`,
`floors`, `weights`, `composite`, `grade`, `small_state`, plus `drivers()` for the peril curves.

Base run on 2026-10-23 (composite, grade): Singapore 21.2 (3), South Korea 21.1 (3), Japan 23.1 (3),
Vietnam 28.8 (3), Malaysia 30.5 (4), India 36.2 (4), Philippines 36.8 (4), China 39.9 (4), Colombia
41.5 (5), Brazil 43.2 (5), Belize 48.9 (5), Zambia 50.9 (6), Argentina 56.2 (6), Senegal 56.5 (6),
Nigeria 57.0 (6), Pakistan 66.5 (7), Zimbabwe 74.5 (8), Venezuela 84.3 (9).

Floors active today: Venezuela pillars 1, 2, 3, 5 (90, 85, 80, 90); Zimbabwe pillars 1 and 2 (90,
85); Pakistan and Nigeria pillar 6 at 85 (armed conflict level 3 or more). The stress path changes
107 of the 1,494 indicator scores (the worse score is the stressed one).

Consumers: Layer 1 (`pillar_aggregated.loc[4] / 25` as PITF), Layer 2 (`composite - 45.8`), peril
PDs (`drivers()`), `signals.py` (indicator and pillar scores for 20 of the 25 signals), the
Dashboard, the arbitrage scan (indicator and pillar scores mapped through `logistic_curve` for
non-default contracts), and the workbook tabs Base/Stress/Indicator Scores and Pillar Scores.

## Limitations and known gaps

- Inputs are mostly seed estimates (about 85 percent of cells). A reviewer should treat pillar
  levels as provisional until items 1.3 and 1.4 of the roadmap (market and event data) land. The
  scores are only as good as the entered levels for the 37 level indicators, which have no feed.
- Thresholds are not calibrated to outcomes. There is no evidence in the repository that a composite
  of 60 corresponds to any particular default frequency; the link to probability is made in Layer 2
  with a single slope `w_s 0.04` per point.
- The worst-indicator blend makes the pillar discontinuous in the weights: an indicator just below
  `min_weight_worst` is excluded from the worst term. Pillars 5, 6 and 7 have nine, nine and eight
  indicators with weight 0.05, so their worst term is driven by five or six indicators only.
- The stress path is a single fixed shock set applied to every country; it does not depend on the
  regime or on the scenario (scenarios A to C change inputs and parameters separately in
  `engine/stress.py`).
- Floors are binary overrides and can dominate: Venezuela's composite is 84.3 with four pillars
  floored. With all floors removed (`floors_off` run) the mean 12-month default PD falls from 13.9
  to 13.2 percent and Zimbabwe's PD from 78 to 68 percent; VaR is unchanged because Venezuela is
  already at the 99 percent PD cap.
- The momentum signal (signal 17) needs the `prior` column of `countries.csv`, which is empty, so it
  is zero everywhere.
- Missing values are silently dropped and the weights renormalised; a pillar with many blanks is
  scored on the remaining indicators without any flag to the user.
- The reserves-in-months-of-imports feature in Layer 1 and the stress path both use exports as the
  import proxy (imports are not in the snapshot).
- A country with no scored indicator in a pillar (a newly onboarded country whose inputs are still blank) stops
  the run with a `ValueError` naming the country and pillar (EQ-B-0034); before, numpy raised a zero-size `max`
  error that named neither.

## Scaling to N countries (EQ-B-0034, 2026-10-23)

- The scorecard has no cross-sectional step: every number for a country depends only on that country's inputs,
  the rulebook and the settings. `tests/test_scale_n_countries.py` checks that the 18 seed countries' composites are
  bit-identical when 52 synthetic countries are added.
- No country list, count, region map or fixed-size array is hard-coded in `scorecard/scoring.py`; everything
  iterates over `u.names`. The workbook reference (`data/workbook_reference.json`, 18 countries) is used only by the
  regression test on the frozen seed folder.
- `score_indicators` is vectorised across countries (the same `np.interp` call per indicator, so the same numbers;
  `test_vectorised_score_indicators_matches_per_cell` compares it with the old per-cell loop on blanks, numbers
  stored as text, two-sided extremes and the stressed inputs). Scorecard time (cumulative timer with GPR) went from
  0.38 s to 0.15-0.25 s at 18 countries and from 0.88 s to 0.28 s at 70.
- Indicator 4.10 (GPR uplift, `engine/gpr.py`): a country row with a blank `gpr_analyst_410` used to get
  `min(4.0, nan) = 4.0`, the worst level, silently. It now takes the indicator table's 4.10 and is missing
  (NaN, renormalised away like any blank) when that is blank too. No change for the 18 countries, whose two
  columns agree.
- The test universe is synthetic: perturbed copies of the seed countries under user-assigned ISO codes (XAA...),
  never real data. Team A's 88-row proposal (`data/panel/universe_proposal.csv`, EQ-A-0025) replaces it once Sam
  approves it and EQ-A-0026 fills the inputs.

## Country readiness (EQ-B-0045, 2026-10-23)

Answer to HO-20261023-A-B-008 (88-country universe, approved by Sam). Code: `econquest/scorecard/readiness.py`;
tests: `tests/test_scorecard_readiness.py`.

**What happened before.** On Team A's staged 88-country folder (70 new countries with blank seed rows), the run
stopped in the scorecard with a partial list ("no scored indicator in 490 pillar(s)", first 20 only). With the
indicator cells filled by placeholders it then hit a `KeyError` (no `adjustments.csv` column for the new
countries), and with that filled too **it completed silently**: every new country had NaN `pd_hazard_l1`,
`pd_rating`, `pd_default`, `el_default`, `pd_any` and DD (NaN drops out of sums and means), a Calm regime
(`float(nan) >= threshold` is False), the stress-path score silently dropped (blank exports/reserves), no pillar 2
floor (blank `parallel`), and a blank `fxregime` would have taken the peg depreciation (0%) in the stress path.

**What happens now.** `score_universe` calls `require_ready(u, settings)` before anything else, so the base run,
every stress scenario and the pre-trade check stop with `UniverseNotReady` (a `ValueError`) listing, per
country, every missing required field in one message. `check_readiness(u, settings).to_frame()` gives the same
list as rows (country, field, kind, blocking) for `cells_to_fill.csv`. The check only reads; the shipped 18
countries pass it and their results are bit-identical (VaR99 64.2337, ES99 83.6673, EL 0.53438 at 20,000 paths,
as_of 2026-10-23, before and after; SHA-256 of the country table and loss vector unchanged).

### Required before promotion (blocking)

| Field | Why the engine needs it | Blocking |
|---|---|---|
| `iso`, `region` | layer 1 WEO join and event index; layer 5/6 regional factor and scenario region filters | yes |
| `rating` (a key of `ratings_pd`, S&P scale) | layer 1 RatingChallenger and calibration target, layer 2 exempt ratings, stress rating ladder, signal 16 | yes |
| `spread` (bp) | layer 2 market-implied PD, layer 3 rule regime, layer 6 credit vol and carry, spread shocks | yes |
| `fxregime` (Float, Managed, Peg, Dollarized) | stress-path depreciation, layer 2 FX weight, layer 6 FX vol | yes |
| `fx3m`, `res3m` | layer 2 FX term; layer 3 rule regime (Stressed and Crisis tests) | yes |
| `textz` | layer 2 text term (0 = no text signal) | yes |
| `pop` | small-state weight set | yes |
| `exports`, `reserves` | layer 1 reserves cover, layer 4 Merton DD, stress-path export and reserve shocks | yes |
| `exptype`, `commgap` | stress-path shock type, commodity scenarios; layer 1 commodity shock, pillar 3 boom trigger | yes |
| `parallel` | pillar 2 override floor | yes |
| Yes/No flags `default`, `extarrears`, `exprop`, `coup`, `nopay`, `bankcrisis`, `emergency`, `disaster` | override floors, Crisis regime, signal 16. The loader reads a blank as No; blocking once Team A reports blanks (HO-20261023-B-A-007) | yes |
| `stress_depreciation` | layer 6 FX and local-bond loss on a transfer-and-convertibility event | yes, if the country has positions |
| Indicators 1.3, 1.6, 2.8, 2.9, 5.5, 5.6 | layer 1 hazard features | yes |
| Indicators 1.5, 5.12 | layer 4 Merton DD; 1.5 also the stress-path FX revaluation | yes |
| Indicators 1.4, 1.7, 2.1, 2.11 | stress path (a blank silently keeps the baseline score) | yes |
| Indicators 2.7, 6.1, 7.2 | pillar 2 and 6 floors, sanctions peril; small-state test | yes |
| Indicator 4.10 (or `gpr_analyst_410`) | sanctions peril and GPR | yes |
| Every pillar 1-7 | at least one scored indicator | yes |
| `elmonths`, `gpr_series`, `gpr_analyst_410`, `etf`, `currency` | signal 8; GPR uplift; HMM, GARCH, estimated copula (country left out) | no (advisory) |
| Indicators 1.1, 1.2, 2.5, 2.6, 2.12, 4.5, 5.1, 5.3, 5.10, 5.13 | dashboard signals only | no (advisory) |
| Any other indicator | pillar weights are renormalised over the indicators that have a value; coverage is reported | no (advisory) |
| Instrument flags (`CDS`, `Eurobond`, `FX`, ...), `policy`, `election`, `mainexp` | playbook instrument availability; descriptive | no |

**Documented fallback.** A country with no `adjustments.csv` column, or a blank cell, gets no analyst adjustment and
no trigger input (0). This is what an empty adjustment means; the 18 countries have no blanks, so nothing changes.

### Other findings on the 88-country folder (placeholder-filled scratch copy, not data)

- **Layer 1 calibration is cross-sectional.** With ratings filled for the new countries, the default calibration
  (`calibrate_to: median_rating_prior` over every country) moved the desk countries' PDs by up to 11 pp (Zimbabwe,
  placeholder ratings). With `layer1.calibration_universe` pinned to the 18 desk names (EQ-B-0034, a no-op today)
  the desk PDs were bit-identical. Which set to calibrate on after promotion is a Tier 1 decision for Sam.
- **Monte Carlo noise from the universe size.** Even with identical desk PDs and no positions on new names,
  VaR99 moved 64.23 -> 64.17 and ES99 83.67 -> 83.17 at 20,000 paths, because each extra country and region adds
  Sobol dimensions. It is sampling noise, not a model change, but run-to-run comparisons across a universe change
  must say so.
- **Regions.** Layers 5 and 6 build one factor per distinct `region` with the single `regime.regional_loading`, so
  Europe, Middle East and North America work without code changes (6 regions, North America has 2 countries).
  The scenario library's `region_in`/`region_not_in: ["Asia"]` filters (and the legacy `region != "Asia"` code
  scenarios in `engine/stress.py`) now treat US, Germany and other DM anchors like non-Asian EM (for example,
  spreads x1.5 in the Fed scenario), and the Hormuz closure has no Middle East filter: scenario tier filter,
  EQ-B-0043. The global regime share (`share_not_calm`) is taken over the whole universe: EQ-B-0042.
- **Limits and playbook.** `limits.json` country limits use `default` for any name and rows exist only for countries
  with positions, so they scale; the playbook thresholds are signal strengths, not per-country. No change needed.
- **Runtime.** At 88 countries (24 positions) a base run takes 1.9 s at 20,000 paths (layer 6 1.2 s) against 0.55 s at
  18; with one placeholder position per new country (94 positions) 2.1-2.3 s; at 100,000 paths 7.4 s (layer 6 6.6 s)
  against 1.0 s at 18. The readiness check costs 0.03 s at 18 and 0.10 s at 88.
- Hazard and PD calibration on the wider set waits on the CRAG import (EQ-A-0016).

## Sensitivity

Runs at 20,000 Sobol paths (production uses 100,000; the 20,000-path base gives VaR99 65.98 and ES99
87.05 $mm against 66.07 and 85.30 at 100,000). Mean PD is the average 12-month `pd_default` over the
18 countries.

| Variant | VaR99 $mm | ES99 $mm | Mean PD | Argentina PD | Pakistan PD | Senegal PD |
|---|---|---|---|---|---|---|
| Base (`worst_blend 0.2`) | 65.98 | 87.05 | 0.1387 | 0.119 | 0.115 | 0.239 |
| `worst_blend 0` (weighted average only) | 62.81 | 82.84 | 0.1260 | 0.099 | 0.091 | 0.198 |
| `worst_blend 0.4` | 70.70 | 91.51 | 0.1519 | 0.142 | 0.144 | 0.287 |
| `min_weight_worst 0` (all indicators eligible) | 67.27 | 88.07 | 0.1407 | 0.118 | 0.114 | 0.253 |
| All floors set to 0 | 65.98 | 86.75 | 0.1322 | 0.119 | 0.105 | 0.239 |
| Stress path off (all shocks 0) | 65.41 | 86.24 | 0.1364 | 0.116 | 0.111 | 0.232 |
| Stress path depreciation doubled (40/30) | 66.04 | 87.16 | 0.1392 | 0.121 | 0.116 | 0.239 |

Reading: the worst-indicator blend is the most consequential scorecard parameter; moving it from 0
to 0.4 moves VaR99 by 12 percent and the mean PD by 2.6 points, all through the Layer 2 score term
and the peril drivers. The stress path and the floors matter for individual countries but little for
the book. Note that these sensitivities act only through `w_s` and the peril curves; they do not
change the market or hazard terms.

## Benchmarks and evidence

- Workbook reproduction: `test_scorecard_matches_workbook` (composite within 0.15, pillars within
  0.1, grades exact) passes on the seed snapshot. That is a test that the code reproduces the
  spreadsheet, not that the spreadsheet is right.
- No outcome-based evidence exists: there is no history of composites against later defaults or
  spread moves. Roadmap item 2.6 (Brier scores of model PDs against ratings, CDS and prediction
  markets) would be the first such benchmark. The scoring framework now exists
  (`score_benchmarks`, EQ-B-0022, method in `benchmarks.md`); the first snapshot matures on 2027-10-23.
- The composite correlates with the rating prior in the expected direction (the three Crisis
  countries, both SD ratings, have the three highest composites), but that is partly circular
  because floors and flags are set by the same analyst who knows the ratings.

## Open items for review

1. Confirm that a worst-indicator blend of 0.2 and eligibility weight 0.1 are what the methodology
   intends; the sensitivity above shows they are the dominant discretionary parameters.
2. Decide whether blanks should fail a run or at least be reported in the diagnostics (today 14
   blank cells are dropped silently).
3. Fill the `prior` column so the momentum signal works, or remove signal 17 from the dashboard.
4. Add an outcome benchmark once a default panel exists (roadmap 2.3): the composite at year t
   against default in t+1 for the 18 countries over 2000 to 2025.
5. Record who entered each level indicator and when; the audit trail says "seed estimate
   (analyst/Claude, Oct 2026)" for 1,270 cells without an author.
