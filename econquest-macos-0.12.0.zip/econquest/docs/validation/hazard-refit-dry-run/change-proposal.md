> **SYNTHETIC DRY RUN: DO NOT PROPOSE.** This pack was written from invented data to prove the chain.

# Tier 1 change pack: layer-1 hazard refit (2026-10-23)

Pre-drafted by `econquest.validation.hazard_refit` (EQ-B-0067). Not proposed. The gate cleared; Sam reviews the numbers below and, if he agrees, runs one of the commands. A proposal changes nothing until it is approved (four-eyes, Tier 1, validator) and applied (`docs/governance/change-control.md`).

## Numbers to review

| figure | value | gate |
|---|---|---|
| OOS AUC | 0.834 | >= 0.75 |
| default starts in the panel | 49 | >= 30 |
| OOS Brier vs trailing base | 0.0387 vs 0.0483 | below |
| OOS events / country-years | 30 / 593 | |
| countries (ever defaulted) | 72 (35) | >= 60, share < 0.55 |
| predictor_lag, point in time | 1, all features | 1, all features |
| fitted mode runs at as_of (VF-012) | False | True to switch the mode |

## Commands (pick one; replace the author)

### layer1_fitted_patch.json: coefficients and layer1.mode = fitted

```
econquest change propose assumptions.json --patch-file <out>/layer1_fitted_patch.json --tier 1 --allow-new-keys --allow-type-change --author '<YOUR NAME>' --reason 'SYNTHETIC DRY RUN, DO NOT PROPOSE: EQ-B-0020 hazard refit (EQ-B-0067): OOS AUC 0.834, 49 events, OOS Brier 0.0387 < trailing base 0.0483; predictor_lag 1, point-in-time 2007-2024, as_of 2026-10-23'
```

Dry-validated on a scratch copy of assumptions.json: tier 1 (inferred 1), validator needed True, 55 diff entries.

### layer1_fitted_coefficients_only_patch.json (recommended): coefficients only; layer1.mode stays paper_standardized (no effect on runs until a later mode switch)

```
econquest change propose assumptions.json --patch-file <out>/layer1_fitted_coefficients_only_patch.json --tier 1 --allow-new-keys --allow-type-change --author '<YOUR NAME>' --reason 'SYNTHETIC DRY RUN, DO NOT PROPOSE: EQ-B-0020 hazard refit (EQ-B-0067): OOS AUC 0.834, 49 events, OOS Brier 0.0387 < trailing base 0.0483; predictor_lag 1, point-in-time 2007-2024, as_of 2026-10-23'
```

Dry-validated on a scratch copy of assumptions.json: tier 1 (inferred 1), validator needed False, 54 diff entries.

## Expected effect

Filled by the refit run when `--effect-paths` > 0 (default 20,000; base settings vs this fit at the same as_of and seed). Blank cells mean the run was skipped: fill them from two 20,000-path runs before proposing.

| measure | before (shipped) | after (this fit) | change |
|---|---|---|---|
| VaR99 (20,000 paths) | 69.03 | 69.03 | +0.00 |
| ES99 (20,000 paths) | 91.21 | 91.21 | +0.00 |
| EL (20,000 paths) | 0.80 | 0.80 | +0.00 |
| L-VaR99 (20,000 paths) | 74.32 | 74.32 | +0.00 |

pd_fit_raw: this fit's 12-month hazard PD on the desk's lag-1 WEO inputs, before the rating reconciliation.

| country | layer-1 hazard PD before | after | pd_default before | after | pd_fit_raw |
|---|---|---|---|---|---|
| Vietnam | 0.81% | 0.81% | 0.36% | 0.36% | 0.05% |
| Philippines | 0.97% | 0.97% | 0.36% | 0.36% | 1.89% |
| China | 1.07% | 1.07% | 0.28% | 0.28% | 6.94% |
| Malaysia | 1.26% | 1.26% | 0.20% | 0.20% | 0.97% |
| Singapore | 0.78% | 0.78% | 0.04% | 0.04% | missing input |
| Japan | 0.10% | 0.10% | 0.04% | 0.04% | 38.42% |
| South Korea | 1.12% | 1.12% | 0.06% | 0.06% | 1.03% |
| India | 0.60% | 0.60% | 0.33% | 0.33% | 1.37% |
| Pakistan | 1.08% | 1.08% | 8.04% | 8.04% | 0.86% |
| Belize | 1.00% | 1.00% | 4.86% | 4.86% | 1.24% |
| Brazil | 1.68% | 1.68% | 1.12% | 1.12% | 6.95% |
| Argentina | 0.89% | 0.89% | 6.60% | 6.60% | 42.59% |
| Colombia | 1.25% | 1.25% | 1.09% | 1.09% | 6.90% |
| Venezuela | 19.60% | 19.60% | 99.00% | 99.00% | missing input |
| Nigeria | 0.80% | 0.80% | 3.88% | 3.88% | 1.87% |
| Senegal | 1.27% | 1.27% | 13.34% | 13.34% | 4.47% |
| Zambia | 0.23% | 0.23% | 4.53% | 4.53% | 8.81% |
| Zimbabwe | 0.74% | 0.74% | 78.40% | 78.40% | 57.62% |

Note: with the mode switch the run would fall back to paper mode: fitted model refused: predictors missing for year 2025 (as_of minus predictor_lag 1): debt_gdp: Venezuela; primary_deficit: Singapore; ran paper_standardized instead (GOV-046)

## After approval

1. `econquest change approve <CHG-id> --approver <NAME>` (not the author), then `econquest change apply <CHG-id>`.
2. Team B copies `hazard-fit-report-refit.md` over `docs/validation/hazard-fit-report.md` (generated file; EQ-B-0020) and closes VF-012 if fitted mode runs.
3. Base run and replication (`python -m econquest.validation.replicate`) with the new base figures in the release note.
