> **SYNTHETIC DRY RUN.** Invented economies and defaults; not a model result.

# Hazard model recalibration report

Generated 2026-10-24 12:49 by `econquest.validation.hazard_refit`.

## Panel

- Country-years at risk: 1,212; default starts (12-month-ahead events): 49; countries: 72; years 2007-2024.
- default_episodes: sovereign_defaults_crag.csv (55 spells to 2026, 35 countries)
- weo_history: weo_history.csv (72 economies; releases 2007-10 to 2025-10, none after as_of 2026-10-23)
- worldbank_history: not used (no vintages; refused at run time, EQ-B-0029)
- point_in_time: all features; rows 2007-2024, rows before the first release dropped
- label_years: 2007-2024 (row t labelled by a default start in t+1; last label year 2025)
- inputs_sha256: {'defaults': 'bc2fac3ec155bec2', 'weo_history': 'd08f26f9a2557954', 'universe': '7d7244819cbc6bbe'}
- refit: econquest.validation.hazard_refit as_of 2026-10-23 (SYNTHETIC)
- Event rows (country, row year t; predictors from year t-1; default starts in t+1): QAC 2011, QAC 2016, QAF 2009, QAI 2023, QAL 2014, QAN 2012, QAO 2019, QAQ 2020, QAR 2011, QAS 2016, QAV 2007, QAV 2018, QAV 2023, QAW 2019, QAX 2015, QAX 2017, QAX 2020, QAX 2024, QAZ 2007, QAZ 2013, QAZ 2018, QBD 2022, QBF 2017, QBF 2022, QBF 2024, QBN 2007, QBN 2021, QBO 2009, QBP 2011, QBS 2021, QBU 2007, QBU 2018, QBU 2021, QBV 2024, QBY 2024, QBZ 2024, QCC 2012, QCD 2016, QCE 2015, QCF 2013, QCF 2017, QCF 2022, QCJ 2016, QCL 2014, QCP 2012, QCR 2012, QCT 2016, QCT 2022, QCT 2024

## Coefficients (Firth penalized logit on standardized predictors)

| predictor | centre | spread | coefficient | s.e. | z |
|---|---|---|---|---|---|
| intercept | | | -4.251 | 0.282 | -15.07 |
| debt_gdp | 51.74 | 21.52 | 0.593 | 0.209 | 2.83 |
| primary_deficit | 0.01 | 2.24 | 0.703 | 0.193 | 3.65 |
| current_account | -1.20 | 3.02 | -0.436 | 0.182 | -2.40 |
| real_growth | 3.12 | 2.28 | -0.577 | 0.167 | -3.46 |
| inflation_log | 4.81 | 2.73 | 0.357 | 0.122 | 2.92 |

A coefficient is the change in the log-odds of a default starting within 12 months for a one-standard-deviation move in the predictor. Base rate: 4.04% of country-years.

## In-sample fit

- AUC 0.861; Brier 0.0323 against 0.0388 for the base rate; log loss 0.1267 against 0.1693.

## Out-of-sample test (rolling origin: fit on years before T, score year T)

- Years 2016-2024: 593 country-years, 30 events. AUC 0.834; Brier 0.0387 against 0.0483 for the base rate; log loss 0.1551 against 0.2035.
- Base-rate benchmark: each origin's training-window event rate (not the test years' own mean).
- Predictors lagged 1 year(s) behind the row year t (a start in t+1 is predicted with information available at t); point-in-time vintages: all features.

### Calibration by decile of predicted probability (out of sample, 10 equal-count bins)

| decile | n | predicted | observed | events |
|---|---|---|---|---|
| 1 | 60 | 0.03% | 0.00% | 0 |
| 2 | 59 | 0.13% | 0.00% | 0 |
| 3 | 59 | 0.28% | 0.00% | 0 |
| 4 | 59 | 0.49% | 3.39% | 2 |
| 5 | 60 | 0.85% | 3.33% | 2 |
| 6 | 59 | 1.38% | 1.69% | 1 |
| 7 | 59 | 2.24% | 3.39% | 2 |
| 8 | 59 | 3.56% | 6.78% | 4 |
| 9 | 59 | 6.47% | 5.08% | 3 |
| 10 | 60 | 22.12% | 26.67% | 16 |

### Out-of-sample years

| year | n | events | mean predicted | training base rate |
|---|---|---|---|---|
| 2016 | 68 | 5 | 2.95% | 3.07% |
| 2017 | 65 | 3 | 3.52% | 3.49% |
| 2018 | 64 | 3 | 3.09% | 3.59% |
| 2019 | 63 | 2 | 2.47% | 3.68% |
| 2020 | 67 | 2 | 4.54% | 3.64% |
| 2021 | 67 | 3 | 3.77% | 3.59% |
| 2022 | 67 | 4 | 3.81% | 3.65% |
| 2023 | 65 | 2 | 4.19% | 3.80% |
| 2024 | 67 | 6 | 5.54% | 3.76% |

## Fitted-mode gate

Result: **cleared**. A fitted switch is a Tier 1 model change and needs Sam's approval even when cleared.

| check | value | rule | threshold | result |
|---|---|---|---|---|
| oos_auc | 0.8340 | >= | 0.7500 | pass |
| events | 49 | >= | 30 | pass |
| oos_brier_vs_trailing_base | 0.0387 | < | 0.0483 | pass |

## Reading the result

- An AUC of 0.5 is no discrimination; above 0.75 is good for annual sovereign default prediction in the literature (Manasse-Roubini, Savona-Vezzoli report 0.75-0.85 in sample).
- The Brier score and log loss should beat the base-rate benchmark; if they do not, the model ranks countries but is miscalibrated.
- Calibration bins compare predicted and observed default frequencies; observed should rise with predicted and sit near it.
- SYNTHETIC DATA: invented economies and defaults for a dry run; these figures say nothing about the model.
- Gate: CLEARED (oos_auc 0.8340 >= 0.7500: pass; events 49 >= 30: pass; oos_brier_vs_trailing_base 0.0387 < 0.0483: pass).
- Refit outcome: CLEARED.
