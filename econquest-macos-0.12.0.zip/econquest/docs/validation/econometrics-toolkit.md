# Model validation: econometrics toolkit (ten tables)

Date: 2026-10-23. Code: `econquest/engine/econometrics.py` (`run_econometrics`, `workflow_table`,
`cointegration_table`, `svar_table`, `kalman_table`, `regime_table`, `fama_macbeth`, `evt_table`,
`copula_table`, `forecast_comparison`, `event_study`, with the primitives `adf_test`, `kpss_test`,
`ols_hac`, `benjamini_hochberg`, `diebold_mariano`, `engle_granger`, `johansen`, `var_fit`,
`svar_irf`, `kalman_beta`, `markov_switching`, `threshold_ar`, `gpd_tail`, `t_copula_fit`,
`clayton_fit`). Entry point: `python -m econquest econ`. Data: `data/market_history/prices.csv`
(Google Finance daily closes 2023-10-18 to 2026-10-22, 1,097 rows, 29 tickers, of which 27 are
modelled plus EEM as the market factor), `data/gpr_monthly.csv`, the Randori composite. Parameters:
`data/assumptions.json` key `garch.risk_free 0.04` is the only setting the toolkit reads; everything
else is a code default. Status: real data, standard methods, but three years of daily history and
hand-tabulated critical values; the outputs are desk research tables, not inputs to the risk engine.

## Purpose

The toolkit answers the questions a quantitative reviewer asks of the market data before trusting
the GARCH-DCC layer and the copula engine: are the series stationary in returns and not in prices;
is there volatility clustering that a GARCH baseline removes; does GARCH forecast variance better
than naive alternatives out of sample; are there cointegrated pairs worth trading; how does an
emerging-market shock propagate; are hedge ratios stable; do the series switch regimes; are there
priced risk premia; how heavy are the tails and do EVT and Student-t agree; are joint losses
tail-dependent, and is a Student-t copula justified over a Clayton; which predictors forecast
realised volatility; and do country equity ETFs sell off around currency shocks. The ten tables are
written to the workbook's Econometrics tab (`outputs/econometrics/econ_plan.json`) and to
`outputs/econometrics/*.csv`.

## Where it sits in the pipeline

Off the main path. `run_econometrics(u, prices, garch_result, settings, gpr, composite)` needs the
GARCH result (`garch-dcc.md`) for the series list, loss signs and standardised residuals, and it
needs the Randori composite only as a characteristic in the Fama-MacBeth second pass. Nothing in
Layers 1 to 6, the stress scenarios, the signals or the forecast record reads its outputs. Its
evidential role is to support two modelling choices made elsewhere: the Student-t copula in Layer 5
(Table 8) and the GARCH(1,1)-t variance model in the forecast record (Tables 1 and 9). Run time
measured in this validation: 186.7 seconds for the full set on 27 series.

## Assumptions

Common to all tables: daily log returns from business-daily prices after `clean_bad_ticks` (which
removed 4 ticks from USDARS, 1 USDBRL, 4 USDCNY, 2 USDINR, 2 USDNGN, 1 USDPHP, 6 USDPKR and 3 USDVES
in this run); FX quoted as local currency per USD so a rise is a depreciation; HAC (Newey-West)
standard errors with the automatic lag `floor(4 (n/100)^(2/9))` in `ols_hac`; Benjamini-Hochberg
false-discovery control at 5 percent across the 27 series wherever a test is repeated per series.

Table by table:

1. Workflow (`workflow_table`): ADF with constant and BIC lag choice up to `12 (n/100)^0.25`; KPSS
   level test with Bartlett long-run variance and lag `4 (n/100)^0.25`; AR order by BIC up to 5;
   Ljung-Box and ARCH-LM on the AR residuals; GARCH(1,1)-t from `garch.garch11_fit`; Ljung-Box on
   squared standardised residuals; out-of-sample one-day variance race over the last 250 days with
   GARCH refit every 50 days (`variance_horse_race`), QLIKE loss, competitors EWMA(0.94), rolling
   60-day and constant variance; Diebold-Mariano test with HAC variance of the loss differential.
2. Cointegration (`cointegration_table`): pairs within region (FX and equity) plus all equity ETFs,
   restricted to tickers whose log price fails ADF at 5 percent (26 of 27); Engle-Granger residual
   ADF against the two-variable constant-case table; Johansen trace with one lagged difference and
   Osterwald-Lenum 95 and 99 percent critical values (15.49 and 19.94 for k = 2 at rank 0); VECM
   adjustment coefficients and AR(1) half-life of the spread; read "Cointegrated (both tests)" needs
   Engle-Granger significant after BH and Johansen rank at least 1.
3. SVAR (`svar_table`): VAR(1) on 786 common days, Cholesky identification in the order EEM, USDJPY,
   USDKRW, USDINR, USDBRL, MCHI, EWY, EWZ, INDA; one-standard-deviation structural shocks; impulse
   responses to horizon 10 and forecast-error variance decomposition at horizon 10.
4. Kalman betas (`kalman_beta`): local-level (random-walk) beta with the signal-to-noise ratio q
   chosen by maximum likelihood over a grid from 1e-7 to larger values; ETFs on EEM, currencies on
   the equal-weight basket of eight liquid USD/EM pairs.
5. Regimes (`markov_switching`, `threshold_ar`): two-state Gaussian Markov switching fitted by EM
   through the Layer 3 `GaussianHMM` (300 iterations, seed 7), states reordered by variance,
   filtered probability of the turbulent state on the last day; TAR(1) with the threshold on the
   lagged absolute return chosen on a 25-point quantile grid between the 30th and 90th percentiles
   by residual sum of squares, Sup-F reported without Hansen bootstrap critical values; TAR blanked
   when more than 20 percent of returns are exactly zero.
6. Risk premia (`fama_macbeth`): weekly (Friday) excess returns of the 10 country ETFs over
   `risk_free / 52`, factors EEM excess return and the FX basket; first-pass full-sample betas,
   second-pass weekly cross-sectional regressions including the composite score divided by 10 as a
   characteristic, HAC t-statistics on the time series of premia; GMM two-step with HAC weighting on
   the pricing-error moments and Hansen J.
7. EVT (`gpd_tail`): GPD fitted by maximum likelihood to the GARCH-standardised losses above their
   90th percentile (79 exceedances per series out of 786); VaR and ES at 99 and 99.9 percent
   compared with the Student-t quantile from the GARCH fit; 10-day 99.9 percent VaR in $mm by
   square-root-of-time on the portfolio exposure.
8. Copulas (`copula_table`): pseudo-observations from ranks; Student-t copula with rho from
   Kendall's tau (`rho = sin(pi tau / 2)`) and nu by profile likelihood on a grid; Clayton by
   maximum likelihood; lower-tail dependence for both; empirical 5 percent joint-loss frequency; AIC
   comparison. Pairs: the eight most correlated ETF pairs by standardised residual correlation plus
   five fixed currency pairs.
9. Forecasts (`build_vol_panel`, `forecast_comparison`): pooled daily panel of all 27 series; target
   log realised volatility over the next 21 days; 12 predictors (realised vol 5, 21, 63 days, mean
   absolute return 21, GARCH conditional vol, momentum 21 and 63, EEM realised vol and momentum 21,
   FX-basket realised vol 21, last GPR monthly change, an FX indicator); split 270 calendar days
   before the last date (2025-12-27); OLS, ridge (CV alpha), lasso (CV), 3-factor PCA regression,
   random forest of 200 trees, against two single-predictor baselines.
10. Event study (`event_study`): events are one-day depreciations above 3 robust standard deviations
    (1.4826 x median absolute deviation) at least 21 trading days apart; market model on EEM
    estimated over days -250 to -21; cumulative abnormal returns over windows [0,0], [0,1], [0,5],
    [0,20] with a t-statistic from the cross-sectional standard deviation of the CARs.

## Data

- 27 series: 17 currencies (USDVND, USDPHP, USDCNY, USDMYR, USDSGD, USDJPY, USDKRW, USDINR, USDPKR,
  USDBZD, USDBRL, USDARS, USDCOP, USDVES, USDNGN, USDXOF, USDZMW) and 10 country ETFs (VNM, EPHE,
  MCHI, EWM, EWS, EWJ, EWY, INDA, EWZ, ARGT), plus EEM. Zimbabwe and Senegal have no modelled series
  of their own beyond USDXOF for Senegal; Zambia's USDZMW and Venezuela's USDVES are thin.
- 786 common business days after alignment (1,097 calendar rows in the file), that is three years.
  Weekly panel for the premia: 158 weeks.
- Pegged or managed currencies (USDVND 9.4 percent zero returns, USDBZD, USDXOF to the euro, USDNGN
  and USDVES with administered steps) violate the continuous-return assumptions of most of the
  tables; the code blanks the TAR for series with more than 20 percent zero returns but runs
  everything else on them.
- GPR monthly index (global series) converted to a month-end change and merged forward into the
  daily panel for Table 9.

## Estimation or calibration

Every parameter is estimated by least squares, maximum likelihood, EM or cross-validation inside the
table; there are no calibrated or hand-set model parameters. The approximations that matter for
inference are:

- ADF, Engle-Granger and KPSS p-values are not computed from response surfaces. `_interp_p`
  interpolates between nine tabulated asymptotic quantiles (ADF tau_mu: -3.43, -3.12, -2.86, -2.57,
  -1.57, -0.44, -0.07, 0.23, 0.60 at p 0.01 to 0.99; Engle-Granger two-variable: -3.90 to 0.20;
  KPSS: 0.347, 0.463, 0.574, 0.739 at p 0.10, 0.05, 0.025, 0.01) on the probit scale and
  extrapolates linearly beyond the ends. Between the tabulated points the error is modest (a few
  hundredths in p); in the far tail the extrapolation is crude, so the ADF p-values of 1e-136
  printed for returns mean only "far below 0.01". Finite-sample critical values for n = 786 differ
  slightly from the asymptotic ones.
- Johansen critical values are the Osterwald-Lenum constant-case table for k - r up to 4 at 95 and
  99 percent only; no p-value is produced, just the rank.
- The Student-t copula's nu is on a grid and the Clayton's theta by bounded optimisation; the t
  copula uses the Kendall inversion for rho rather than full maximum likelihood.
- The Sup-F in the TAR has no valid asymptotic distribution under the null (the threshold is a
  nuisance parameter); the workbook note says "above about 12" as a rule of thumb.
- The Markov-switching model reuses the Layer 3 HMM code, which has no standard errors;
  `p_turbulent_now` is a filtered probability from point estimates.
- Three years of data: 786 daily observations give adequate power for stationarity and ARCH tests,
  marginal power for cointegration (a half-life of 30 days is estimated from about 25 independent
  cycles), and almost none for the risk premia (158 weeks) or the 99.9 percent tail (79 exceedances
  above the 90th percentile).

## Outputs and how they are used

The run made in this validation (186.7 s) reproduced the archived `outputs/econometrics/*.csv`
(prices to 2026-10-22, same `forecast_split` 2025-12-27 and the same removed ticks). Headline
results by table:

| Table | Result |
|---|---|
| 1 Workflow | 27 of 27 return series reject a unit root after BH; 26 of 27 log prices fail to reject (USDVES is the exception); ARCH present after BH in 25 of 27; GARCH persistence median 0.909 (0.53 for INDA to 0.999 for USDVES and USDNGN); Student-t df 2.5 to 7.9; 1 series fails the Ljung-Box test on squared standardised residuals. Out-of-sample best by QLIKE: GARCH 11, EWMA 8, constant 6, rolling-60 2; Diebold-Mariano p below 0.05 in 4 series, all against GARCH (EWY t 3.68, USDNGN 3.22, USDXOF 2.49, USDPKR 2.05). |
| 2 Cointegration | 90 pairs; 73 "No long-run relationship", 17 "Weak evidence (one test)", 0 "Cointegrated (both tests)" after BH. Lowest Engle-Granger p: USDJPY/USDPKR 0.023 (Johansen rank 2, which signals a stationary pair rather than cointegration), EWJ/EWY 0.040, INDA/EWZ 0.044. |
| 3 SVAR | A one-SD EEM shock (1.25 percent) moves USDKRW -0.28, USDBRL -0.39, USDJPY -0.08, USDINR -0.08 percent (appreciations), MCHI +1.12, EWY +2.07, EWZ +0.87, INDA +0.48 percent on the day; EEM explains 73 percent of EWY's 10-day variance, 46 percent of MCHI, 22 percent of USDBRL, 20 percent of USDKRW, 2 percent of USDJPY. A yen shock explains 12 percent of USDKRW. Responses after day 0 are small and mostly reversing. |
| 4 Kalman | ETF betas to EEM: EWY 1.75 today (1.57 a year ago), MCHI 0.81 (0.99), EWJ 0.69, EWZ 0.67, ARGT 0.69, the Asian small markets 0.37 to 0.51. Signal-to-noise q at the grid floor (1e-7, constant beta) for VNM, EWJ and most currencies; 1e-2 for the drifting ones. FX betas to the basket: USDPHP 0.87, USDMYR 0.53, USDCNY 0.22, USDVND 0.07. |
| 5 Regimes | `p_turbulent_now` is 0.999 for EWY, 0.74 for USDXOF, 0.42 for USDINR, below 0.09 for the other 24 series; EWY's turbulent state has a 76-day expected duration and a 26 percent historical share. TAR Sup-F is below 6 everywhere (max 5.57 for EWJ), so no threshold effect at the rule-of-thumb level. |
| 6a Fama-MacBeth | Weekly premia: EEM 0.27 percent (t 0.93), FX basket 0.00 (t 0.02), composite per 10 points 0.02 percent (t 0.23), intercept -0.07 (t -0.23). Cross-sectional R-squared of average returns on betas 0.33. Nothing is significant. |
| 6b GMM | EEM premium 0.20 percent per week (t 1.16), FX 0.01 (t 0.06); Hansen J 7.77 on 8 moments, p 0.457. |
| 7 EVT | GPD shape xi median 0.149, range -0.109 (USDMYR) to 0.581; 5 of 27 negative (bounded tail estimate); EVT and Student-t 99 percent one-day VaR agree within about 10 percent (USDVND 0.30 vs 0.28 percent, MCHI 3.71 vs 4.04); at 99.9 percent EVT is above the t for heavy-tailed series (VNM 7.7 vs 6.6) and below it for light ones (USDPHP 1.6 vs 2.1). |
| 8 Copulas | 13 pairs, Student-t preferred by AIC in all 13; nu median 10 (5 for EWS/EWZ, 6 MCHI/EWS, 8 for EWJ/EWY, EWS/EWY and USDSGD/USDJPY; 50 for EWJ/INDA). Lower-tail dependence of the t copula 0.00 to 0.22 (USDSGD/USDJPY 0.22, EWS/EWZ 0.18, MCHI/EWS 0.16, EWJ/EWY 0.15); the Clayton implies 0.14 to 0.52 and overstates the empirical 5 percent joint-loss frequency (0.13 to 0.48). |
| 9 Forecasts | Out-of-sample R-squared on log 21-day realised vol (5,210 test rows): lasso 0.798 (8 predictors kept), PCA-3 0.793, ridge 0.792, OLS 0.792, GARCH-only 0.787, random forest 0.775, naive last-21-day vol 0.765. In-sample: random forest 0.917, the linear models 0.78. Lasso standardised coefficients: `garch_vol` 0.51, `rv63` 0.17, `is_fx` -0.08, `rv21` 0.06; random-forest importance `garch_vol` 0.39, `absr_mean21` 0.23, `rv63` 0.20. |
| 10 Events | 4 to 12 currency shocks per country (thresholds 0.27 percent for USDCNY to 1.89 percent for USDBRL). Day-0 CAR negative for 9 of 10 ETFs: EWZ -2.6 percent (t -2.6), VNM -2.5 (t -1.6), EWY -1.5 (t -2.0), ARGT -1.0 (t -2.2), INDA -0.6 (t -3.5), EPHE -0.5 (t -2.4), EWM -0.6 (t -2.1); EWJ +0.5 (t 1.4). The [0,20] CARs are not significant anywhere. |

Uses: the Econometrics tab of the workbook and the desk's judgement. Table 8 is cited in
`copula-montecarlo-layers5-6.md` as evidence for the Student-t copula; Tables 1 and 9 support using
the GARCH conditional volatility as the forecast in the record (`backtests-and-forecast-record.md`).

## Limitations and known gaps

- Three years of daily data. Every long-horizon conclusion (cointegration, risk premia, 99.9 percent
  tails, 20-day event windows) is underpowered, and the sample covers one macro cycle (2023 to 2026)
  with no emerging-market crisis of the kind the first four layers model.
- Interpolated and asymptotic p-values (see above). A reviewer who needs an exact p-value for a
  borderline case should recompute it with MacKinnon response surfaces; borderline cases in this run
  are the three "Weak evidence" pairs with Engle-Granger p between 0.02 and 0.045.
- The 27 series are currencies and equity ETFs. There is no sovereign spread, CDS or Eurobond price
  series, so the toolkit says nothing about the credit instruments that carry most of the book's
  default risk.
- Managed currencies and administered steps (USDNGN persistence 0.9987, USDVES 0.9988, USDXOF a euro
  peg) make GARCH persistence near 1 and the EVT shapes unreliable for those series; the code does
  not exclude them from Tables 1, 7 and 8.
- The forecast panel pools 27 heterogeneous series with one FX dummy; the out-of-sample R-squared is
  dominated by between-series level differences (a volatile ETF versus a pegged currency), which any
  volatility measure explains. The gain from the lasso over the naive baseline (0.798 vs 0.765) is
  the within-series information.
- The random forest is run with 200 trees and default depth; its in-sample 0.917 versus
  out-of-sample 0.775 is reported honestly but no tuning or purged cross-validation was attempted.
- The Markov-switching fit uses a seed (7) and EM from one start; the EWY result (p_turbulent 0.999)
  should be checked against other seeds and against the `n_iter` setting before it is used as a
  signal. Not done here.
- Fama-MacBeth with 10 assets and two factors plus a characteristic is close to the limit of what a
  cross-section can bear; the composite's premium (t 0.23) is uninformative, not negative evidence.
- SVAR identification by Cholesky ordering is an assumption, not a test; placing EEM first imposes
  that nothing else moves EEM on the day, which is the usual convention but not evidence.
- The Kalman q grid starts at 1e-7 and many series sit at the floor, which means "constant beta" is
  the chosen model; the grid upper end and the likelihood surface were not inspected.
- The toolkit reads only `garch.risk_free` from the settings; the threshold quantile (0.90), the
  k_sigma (3.0), the forecast split (270 days), the refit frequency (50 days) and the race window
  (250 days) are code constants that cannot be varied from `assumptions.json`.

## Sensitivity

The full toolkit takes about three minutes, so the sensitivities below were not swept as the Monte
Carlo was. What was verified in this validation:

- Reproducibility: a fresh `run_econometrics` on the same prices reproduced every archived summary
  (27 stationary return series, 25 ARCH, out-of-sample best 11/8/6/2, 90 pairs with 73/17/0 reads, J
  7.77 with p 0.457, xi median 0.149, 13 of 13 Student-t). The toolkit is deterministic given the
  data and the HMM seed.
- Scale of the main judgement calls, inferred from the table definitions rather than recomputed:
  - Cointegration reads depend on the BH correction across 90 pairs. Without it, the three pairs
    with Engle-Granger p below 0.05 would be "Weak evidence" either way because their Johansen rank
    is 0 or 2, so the headline "no cointegrated pair" does not depend on the FDR choice.
  - The EVT threshold at the 90th percentile leaves 79 exceedances; moving to the 95th would halve
    that and widen the xi range considerably (standard error of xi with 40 points is roughly 0.2).
    The 99 percent VaR comparison with the t quantile is robust to this; the 99.9 percent comparison
    is not.
  - The event-study threshold of 3 robust SDs gives 4 to 12 events per country; at 2.5 SDs the
    counts would rise and the day-0 t-statistics would likely fall as smaller shocks dilute the
    mean.
  - The forecast split at 270 calendar days before the end gives 5,210 test rows (about 28 percent
    of the panel); an earlier split would raise test size but shorten training below two years.
- GARCH-related sensitivities that bear on Table 1 (t versus normal innovations, variance targeting)
  are in `garch-dcc.md`.

## Benchmarks and evidence

- Unit tests in `tests/test_econometrics.py` (5 tests) check each primitive on synthetic data: ADF
  and KPSS classify a random walk and white noise correctly; BH picks the right discoveries; HAC
  widens standard errors under autocorrelated errors and the AR fit recovers a 0.6 coefficient;
  Engle-Granger and Johansen find a built-in cointegrating relation (beta 0.8) and reject a spurious
  one; the VAR recovers a 0.5 coefficient with positive impulse response and FEVD share; the Kalman
  beta tracks a drifting beta; Markov switching separates a 2-to-1 volatility ratio; the GPD xi
  lands in 0.05 to 0.6; the t copula recovers rho 0.6 with nu at most 10 and beats the Clayton by
  AIC; the event study detects four injected drops. All pass.
- Literature benchmarks the results agree with: daily FX and equity returns are stationary with
  strong ARCH; GARCH(1,1) beats EWMA for most series but not all (the horse race is mixed, as in
  Hansen and Lunde's comparisons); EM equity ETF betas to EEM near 1 for Korea and China and below
  0.5 for small Asian markets are in line with published factor loadings; Student-t copulas
  dominating Clayton on equity index pairs is the usual finding; GPD shapes between 0.1 and 0.3 for
  daily financial losses are the textbook range.
- The one result that reads as surprising is Table 5's `p_turbulent_now` of 0.999 for EWY alongside
  a Table 1 Diebold-Mariano rejection of GARCH in favour of EWMA for the same series and a Kalman
  beta that has risen from 1.57 to 1.75. The three tables are consistent with one another (Korean
  equities in late 2026 are in an unusual high-volatility, high-beta episode in the data), but the
  point should be confirmed on the price series before it is used.
- No external replication of the tables (for example against statsmodels or arch) was performed
  because those packages are not installed; the hand-written ADF, KPSS and Johansen implementations
  are validated only by the synthetic tests above.

## Open items for review

1. Replace the interpolated ADF, Engle-Granger and KPSS p-values with MacKinnon response-surface
   p-values, or at least print the critical values alongside so the reader sees when a result is
   borderline.
2. Exclude or flag managed and pegged currencies (zero-return share above 10 percent, or persistence
   above 0.995) from Tables 1, 7 and 8, as the TAR already does.
3. Expose the toolkit constants (EVT threshold quantile, event k_sigma, forecast split, refit
   frequency, race window, HMM seed and iterations) in `assumptions.json` under an `econometrics`
   key.
4. Re-run the Markov-switching fit for EWY with several seeds and report the spread of
   `p_turbulent_now`.
5. Cross-check at least the ADF, Johansen and GPD primitives against a reference implementation once
   statsmodels or arch is available in the environment.
6. Add sovereign spread or CDS series to the price file so the cointegration, SVAR and event-study
   tables can include the credit legs.
7. State in the workbook note that the toolkit is research output and feeds no risk number, so that
   a reader does not take Table 9 or Table 8 as the model's own calibration.
8. Record the run time and the data range in `econ_plan.json` (the range is there; the run time is
   not) so slow or truncated runs are visible.
