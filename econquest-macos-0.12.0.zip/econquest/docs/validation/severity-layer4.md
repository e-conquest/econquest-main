# Model validation: Layer 4 loss severity

Date: 2026-10-23. Code: `econquest/engine/layer4_severity.py` (`beta_params`,
`haircut_distribution`, `sample_haircut`, `gpd_severity`, `merton_distance_to_distress`,
`position_multipliers`) and the position builder in `layer6_montecarlo.py::build_positions`.
Parameters: `data/assumptions.json` keys `market` (LGDs, haircuts), `layer4`, `sector_multipliers`,
`location_multipliers`, `regime` (LGD multipliers). Status: the severity means are the workbook's
fixed percentages (Cruces-Trebesch style means), made stochastic with a Beta or GPD; none is fitted
to restructuring data in this repository.

## Purpose

Layer 4 gives each event type a loss-given-event distribution: restructuring haircuts for defaults
(Beta), fixed haircuts for transfer-and-convertibility events, Generalized Pareto tails for
expropriation and political-violence losses on equities, a Merton distance-to-distress diagnostic
per sovereign, and sector and location multipliers that scale the expropriation and
political-violence probabilities of individual positions. It follows section 3.4 of the paper.

## Where it sits in the pipeline

`run_pipeline` computes `merton_distance_to_distress` and `position_multipliers` after Layer 2, then
`build_positions` (Layer 6) attaches to each position its event probabilities, loss sizes and
severity kind (`beta`, `gpd`, `fixed`), and `simulate` draws the severities from Sobol uniforms with
`sample_haircut` and `gpd_severity`.

## Assumptions

1. Hard-currency default LGD mean `market.lgd_hard 60` percent (Eurobond long positions, and the
   gain on CDS protection); local-currency default LGD mean `market.lgd_local 35` percent (local
   bonds). Each is scaled by the regime `lgd_mult` (1.0195, 1.0925, 1.18 expected under the
   transition matrix) and capped at 0.95.
2. Haircut distribution: `Beta(a, b)` with that mean and `layer4.lgd_sd 0.15`; `beta_params` clips
   the mean to [0.02, 0.98], caps the standard deviation at 95 percent of the binomial maximum and
   floors `a` and `b` at 0.5. For mean 0.60: a 5.80, b 3.87; for mean 0.708 (Crisis): a 5.80, b
   2.39; for mean 0.35: a 3.19, b 5.92.
3. Transfer-and-convertibility loss on FX positions: the country's `stress_depreciation` (15 or 20
   percent, 0 for Belize and Senegal pegs) plus `convertibility_haircut 15` percent, fixed. On local
   bonds the second event (kind B) is a transfer event with loss equal to `stress_depreciation`,
   fixed.
4. Equity expropriation loss: GPD with mean `equity_exprop_haircut 70` percent times `lgd_mult`,
   capped at 0.95; equity political-violence loss: GPD with mean `equity_pv_haircut 25` percent
   times `lgd_mult`. `gpd_severity` uses shape `layer4.gpd_xi 0.25` and scale `sigma = mean * (1 -
   xi)` so that the untruncated GPD mean equals the target; the draw is then clipped to [0, 1].
5. Merton distance to distress: `DD = [ln(V_A / D_B) + (mu - sigma^2 / 2) T] / (sigma sqrt T)` with
   `V_A = reserves + exports` (percent of GDP, floored at 1), `D_B = short-term external debt (2.9,
   percent of reserves) / 100 * reserves + 0.5 * debt * FX share` (floored at 1), `sigma =
   asset_vol_base 0.12 + growth volatility 5.12 / 100`, `drift 0.02`, `horizon_years 1`. `pd_merton
   = Phi(-DD)`; `lgd_uplift = lgd_per_sigma 0.1 * max(0, dd_reference 2.0 - DD)`.
6. Sector multipliers on expropriation PD for equities (Mining, oil and gas 1.5; Infrastructure and
   utilities 1.3; Financials 1.0; Manufacturing and services 0.7; Diversified index 1.0) and
   location multipliers on political-violence PD for equities (Nearby calm 0.7; National average
   1.0; High activity 1.5; Active warzone 2.0). Missing sector or location means 1.0.

## Data

- `portfolio.csv`: 24 positions, 309 $mm gross. Asset classes: 11 Eurobond, 7 FX, 6 local bond, 2
  equity (South Korea EWY 15 $mm, Zimbabwe 3 $mm) and 1 CDS protection (Argentina). The `sector` and
  `location` columns are empty for every position, so every multiplier is 1.0 in the base run.
- Severity inputs from the indicator table and the Country Profile (reserves, exports, 1.3, 1.5,
  2.9, 5.12, `stress_depreciation`). Reserves and exports are live from the World Bank for most
  countries; 1.5 (FX share of debt) and 5.12 are partly seed estimates.
- No recovery or haircut dataset is in the repository. The 60 and 35 percent means are the
  workbook's values; the README attributes them to Cruces-Trebesch by asset class but no table or
  citation is stored.

## Estimation or calibration

In production, none: means, dispersion, GPD shape and the Merton parameters are judgement
(`layer4.lgd_source` absent, read as "judgement"). The machinery to fit the haircut Beta now exists
(next section) but has only been run on a synthetic fixture.

## Haircut fit to restructuring data (EQ-B-0037, GOV-024): built, waiting on Sam's download

Status: **the real fit is waiting on Sam's download of the Cruces-Trebesch dataset.** Nothing below
uses real haircut data; every number in this section comes from
`tests/fixtures/haircuts_synthetic.csv`, which is drawn from Betas with arbitrary parameters.

- `load_haircuts(path)` reads CSV or XLSX and normalises to `country, year, haircut_sz,
  haircut_market, debt_restructured_mm, instrument_class, regime` (haircuts as shares; percent
  values divided by 100). A missing file raises `FileNotFoundError` with the download instruction;
  a file without country, year or SZ haircut raises `ValueError` listing the columns found.
- Assumed columns (matched without case or punctuation; the published headers have not been seen
  here, so a mismatch needs one alias in `HAIRCUT_COLUMNS`): `Country`; `Year` (or a date of
  exchange, whose year is kept); `Haircut (SZ)`, the Sturzenegger-Zettelmeyer preferred haircut, the
  column fitted; `Market haircut`; `Debt restructured (USD m)`, used for a debt-weighted mean
  (diagnostic only). Two econquest extensions are optional: `instrument_class` (`hard`, `local`;
  default `hard`, since Cruces-Trebesch covers external debt to foreign private creditors) and
  `regime` (Calm, Stressed, Crisis; not in the published file).
- `fit_beta_mom` (method of moments) and `fit_beta_mle` (scipy maximum likelihood on [0, 1], values
  clipped to [1e-4, 1 - 1e-4], started from the moments). `fit_haircuts` fits each instrument class,
  and each (class, regime) group with at least `min_n` 15 rows, and reports a Kolmogorov-Smirnov p.
  Tests recover known Beta parameters within 6 percent from 20,000 draws.
- `fitted_lgd_block(fit, settings, method)` builds the proposed `layer4.fitted_lgd` block: per
  class the fitted mean and sd, n, and `judgement_mean` (the `market.lgd_*` it replaces). Regime
  fits are reported as `implied_lgd_mult` (regime mean / pooled mean) for comparison with
  `regime.*.lgd_mult`; they are not applied.
- `layer4.lgd_source`: "judgement" (default, bit-identical: seeded base and scenarios A, B and C
  give the same position-loss matrix hash before and after the change) or "fitted".
  `effective_severity(settings)` then moves `market.lgd_hard` / `lgd_local` by `100 * fitted mean
  - judgement_mean` (so scenario B's +18 points stays on top of the fit), clipped to [5, 95], and
  `haircut_distribution` uses the class's fitted sd instead of `lgd_sd`. A class with no fit
  (local debt, which Cruces-Trebesch does not cover) keeps its judgement mean and `lgd_sd`.
  Turning it on is a Tier 1 change; it is not wired into `run_pipeline` yet (one-line edit proposed).

Effect on the synthetic fixture (20,000 requested, 32,768 Sobol paths, as of 2026-10-23; PDs
unchanged, runtime about 2 s per run either way):

| Run | Hard mean / sd | Local mean / sd | VaR99 $mm | ES99 $mm | EL $mm |
|---|---|---|---|---|---|
| Judgement (default) | 0.60 / 0.15 | 0.35 / 0.15 | 64.23 | 83.67 | 0.53 |
| Fitted, MLE (synthetic) | 0.458 / 0.232 | 0.314 / 0.138 | 61.77 | 80.88 | 0.15 |
| Fitted, MoM (synthetic) | 0.449 / 0.227 | 0.313 / 0.142 | 61.61 | 80.70 | 0.13 |

These numbers say only that the switch works and moves the book in the expected direction for a
lower, wider haircut distribution; they are not evidence about real haircuts.


`test_monte_carlo_metrics_consistent` only checks ordering of VaR and ES and the liquidity cost
against the workbook.

## Outputs and how they are used

Per country: `DD`, `pd_merton`, `lgd_uplift`, `lgd_hard_expected`, `el_default = pd_default *
lgd_hard_expected`. Base run: DD ranges from -5.3 (Venezuela, `pd_merton` 1.0) and -1.4 (Argentina,
0.92), -0.76 (Pakistan, 0.78), -0.48 (Senegal, 0.68) to +17 (Vietnam); `lgd_uplift` 0.73 for
Venezuela, 0.34 Argentina, 0.28 Pakistan, 0.25 Senegal, 0 for countries with DD above 2.
`lgd_hard_expected` is 0.612 (Calm), 0.656 (Stressed), 0.708 (Crisis), with no uplift because
`layer4.merton.apply_uplift` defaults to 0 and is not in `assumptions.json`.

Per position (`build_positions`): `pA, lossA_pct, kindA, pB, lossB_pct, kindB, lgd_mult`. Examples:
Argentina Eurobond P14 `pA 0.119`, Beta haircut mean `0.6 * 1.0925 = 0.656`; Brazil local bond P12
`pA 0.016` Beta mean `0.35 * 1.0195 = 0.357` and `pB 0.006` fixed 20 percent; South Korea equity P07
`pA 0.002` GPD mean 0.714 and `pB 0.005` GPD mean 0.255.

## Limitations and known gaps

- Resolved 2026-10-23: the GPD mean is now preserved after clipping. `gpd_scale` root-finds the
  scale so that E[min(Y,1)] equals the target haircut (`gpd_clipped_mean` is the closed form); a
  parametrised test checks 200,000 draws land within 0.01 of targets 0.25 to 0.90 across xi 0.1 to 0.5.
  Before the fix a 0.70 target realised 0.48. Impact on the current book is small (two equity positions).
- Resolved 2026-10-23: the Merton uplift now reaches the simulation. `build_positions` carries the
  country's `lgd_uplift` for Eurobond and CDS-protection positions and `haircut_distribution` adds it
  to the Beta mean through `expected_lgd` (clipped to 0.05-0.95), so the simulated mean equals the
  reported `lgd_hard_expected`. `layer4.merton.apply_uplift` is now an explicit key (true by default).
  A side fix: `beta_params` floored a and b independently, which at a mean of 0.95 realised 0.68; it
  now rescales both parameters together so means near the cap are honoured. Base-run VaR99 rose from
  65.98 to 68.75 $mm and ES99 from 87.05 to 88.75 $mm at 20,000 paths; expected loss from 0.24 to
  1.91 $mm, mostly Venezuela (PD 0.99, LGD 0.71 to 0.95).
- Sector and location multipliers apply only to equity positions (`pd_ex` for the sector, `pd_pv`
  for the location). The two equity positions carry 18 $mm, so `sector_all_mining` and
  `location_all_warzone` move VaR99 by 0.03 and 0.06 $mm. Eurobond and local-bond positions are not
  exposed to expropriation or political violence in the loss model at all.
- Beta dispersion `lgd_sd 0.15` is common to all asset classes and regimes; restructuring haircut
  data show a much wider spread (Cruces and Trebesch report haircuts from under 10 to over 90
  percent).
- The transfer loss on FX positions is deterministic (`stress_depreciation + 15`), and Belize and
  Senegal, both pegs, carry a transfer loss of 15 percent only (zero stress depreciation).
- `lgd_hard` is capped at 0.95 before the Beta is built; in scenario B the cap binds for the
  Stressed and Crisis countries.
- The Merton proxy uses exports as a liquid asset and half of FX debt plus short-term external debt
  as the barrier; DD is very sensitive to `D_B` being floored at 1 for countries with tiny FX debt
  shares.

## Sensitivity

20,000 Sobol paths; production 100,000. PDs are unchanged by every variant in this table.

| Variant | VaR99 $mm | ES99 $mm | Expected loss $mm |
|---|---|---|---|
| Base (`lgd_hard 60, lgd_local 35, lgd_sd 0.15, gpd_xi 0.25`) | 65.98 | 87.05 | 0.24 |
| `lgd_hard 45` | 61.73 | 82.43 | -1.39 |
| `lgd_hard 75` | 69.49 | 90.21 | 1.51 |
| `lgd_local 25` | 64.87 | 85.94 | 0.20 |
| `lgd_local 45` | 66.85 | 87.82 | 0.28 |
| `lgd_sd 0.05` | 66.87 | 87.32 | 0.31 |
| `lgd_sd 0.30` | 64.17 | 85.20 | -0.37 |
| `gpd_xi 0.10` | 66.01 | 87.08 | 0.25 |
| `gpd_xi 0.50` | 65.69 | 86.97 | 0.23 |
| `regime.Crisis.lgd_mult 1.5` | 66.91 | 87.81 | 0.85 |
| `layer4.merton.apply_uplift 1` | 65.98 | 87.05 | 0.24 (identical: the uplift does not reach the simulation) |
| All positions sector "Mining, oil and gas" | 66.01 | 87.16 | 0.31 |
| All positions location "Active warzone" | 66.04 | 87.27 | 0.26 |

Reading: the hard-currency LGD is the only severity parameter that moves the book by more than 2
percent (a 15-point change in LGD moves VaR99 by about 6 percent and ES99 by about 4 percent). The
Beta dispersion has a counter-intuitive sign (wider dispersion lowers VaR) because with a mean of
0.66 a wider Beta puts more mass below the mean and the cap at 1 limits the upside. The GPD shape is
immaterial on this book. The negative expected losses in some variants are the carry on Eurobonds
and local bonds exceeding expected default losses.

Closed-form check of the GPD clipping (200,001-point inverse-CDF grid, `xi 0.25`): target mean 0.25
gives realised 0.230; target 0.50 gives 0.392; target 0.70 gives 0.482; target 0.95 gives 0.565.

## Benchmarks and evidence

- The README compares the program's tail to the workbook's: VaR99 65.9 vs 59.3 $mm and ES99 85.2 vs
  76.9 (100,000 paths, seed snapshot), attributing about 10 percent of the difference to stochastic
  severities replacing fixed percentages. The `lgd_sd 0.05` run (close to fixed severities) gives
  VaR99 66.9, so on today's data the stochastic severity is not what makes the tail heavier than the
  workbook; the Layer 1 and 2 PDs and the copula are.
- No comparison to realised sovereign haircuts has been made. The Cruces-Trebesch database (1970 to
  2013, about 180 restructurings) and the Asonuma-Trebesch updates are the natural benchmark for the
  60 percent mean and 0.15 dispersion.
- No evidence on expropriation or political-violence severities exists in the repository.

## Open items for review

1. Done (GOV-002, resolved 2026-10-23; `test_gpd_clipped_mean_hits_target`). Fix or document the GPD clipping so the realised mean matches the target (for example, solve for
   the scale after truncation, or use a Beta for haircuts above 50 percent).
2. Done (GOV-001, resolved 2026-10-23; `test_merton_uplift_reaches_simulation`). Decide whether the Merton uplift should reach the simulation; if it should, `build_positions`
   must read `lgd_hard_expected` per country. If not, remove `apply_uplift` from scenario B's
   description.
3. Fill the `sector` and `location` columns of `portfolio.csv`, or state that the multipliers are
   not in use.
4. Benchmark the Beta mean and dispersion against the Cruces-Trebesch haircut distribution by region
   and era, and consider asset-class and regime-specific dispersion. Fit code and the
   `layer4.lgd_source` switch built (EQ-B-0037); waiting on Sam's download, then a Tier 1 decision.
5. Store the source of the 60 and 35 percent LGD means and of the 70 and 25 percent equity haircuts.
6. Review the Merton balance-sheet proxy (exports as liquid assets, half of FX debt as barrier) or
   drop `pd_merton` from the published Risk Engine rows if it is not used.
