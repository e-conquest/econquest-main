# Licensed-data readiness: model inputs and the switches that change their source

Date: 2026-10-25. Ticket: EQ-B-0100 (Team B, AGENT-01). Unblocks the code half of EQ-B-0050.
Related: `docs/runbooks/A-licensed-vendors.md` (Team A vendor adapters, EQ-A-0033, off until a licence exists),
`docs/runbooks/A-market-data.md` (market store and gate), `cds-curves-and-rv.md` (EQ-B-0048/0049/0056),
`bayesian-layer2.md`, `client-safe-run.md` (EQ-B-0089/0096).

**Status: nothing here is switched on.** No licence is configured. `data/assumptions.json` is unchanged: every new
setting below is read with a code default that reproduces today's run (20,000-path base check identical before and
after this ticket). Turning any switch on with real data is a Tier 1 change for Sam. This note does not propose one.

## 1. How licensed data reaches the model

1. A Bloomberg or LSEG adapter pulls rows in Team A's `MARKET_COLUMNS` contract. Each row carries
   `licence = "<vendor>:<licence_id> (<scope>)"`, scope `desk-internal` or `redistribution`.
2. `pull_to_store` saves them as a snapshot under `<data>/live/market/snapshots/` and runs the market gate.
3. Team B code reads the store point in time with `market_history(data_dir, asof=D)`. CDS rows go through
   `cds_curves.curves_from_market` (derived rows dropped, newest capture per date wins, no fallback to seed spreads).

The CSV-export path (`econquest market import`) writes the same store, so the switches below work the same with a
vendor CSV export as with an API pull.

## 2. Input inventory

"Switch" is the setting that changes the source. "None" means a code or data change is still needed.

| # | Input | Used by | Current source | Licensed replacement | Switch |
|---|---|---|---|---|---|
| 1 | Sovereign spread for the layer-2 market term (`z_cds`) | Layer 2 | Country Profile `spread` (`data/countries.csv`, analyst seed, no audit-trail source) | CDS curve from the market store: par spread at `tenor_y`, or the 1-year hazard | `probability.market_term.source` `"profile"` (default) / `"cds_curves"` (this ticket) |
| 2 | Market spread for bond relative value | `bond_rv` (diagnostic) | Country Profile `spread` | CDS curve par spread at the bond duration | `bond_rv.enabled` (default false) and `bond_rv.use_cds_curves` (default true), EQ-B-0056 |
| 3 | Sovereign spread for regime rules (`regime_rules.stressed_spread` 400, `crisis_spread` 1000) | Layer 3 | Country Profile `spread` | Vendor 5y CDS or EMBI spread | None. Needs either a Team A feed that writes `countries.spread` from the store, or a layer-3 hook |
| 4 | Sovereign spread for Eurobond/CDS mark-to-market and spread vol | Layer 6 | Country Profile `spread` | As 3 | None (as 3) |
| 5 | Spread for the DSA default interest rate and restructuring | `dsa.py`, `restructuring.py` | Country Profile `spread` | As 3 | None (as 3) |
| 6 | CDS quotes for `engine/cds.py` (single-curve pricer, `econquest cds`) | CLI / views | `data/cds_quotes.csv` (hand-entered, empty) | Team A's `to_cds_quotes` export from the store | None in Team B code; the file is filled by Team A's export |
| 7 | CDS recovery | CDS curves | Quote row `recovery` when present, else `cds.recovery` 0.40 | Vendor recovery field (`field = recovery` rows) | None: used automatically when the rows exist |
| 8 | Discount curve for CDS stripping | CDS curves | Flat `cds.risk_free` 0.04 | Vendor OIS/swap curve (`ois`, `swap` instruments in the store) | None. `cds_curves.curves(..., discount_curve=)` accepts a curve, but no setting reads one from the store |
| 9 | Upfront CDS quotes | CDS curves | Not available | Vendor `upfront_pct` rows | None. `MARKET_COLUMNS` has no running coupon, so upfront rows are dropped and reported (Team A schema gap) |
| 10 | FX 3-month change `fx3m` | Layer 2 (`z_fx`), layer 3 | Official BIS/ECB series; Yahoo values still in `countries.csv` (barred); theratesapi.com for VND, PKR, VES, NGN, ZMW (EXC-005) | Vendor `fx_spot` history | None. Team A feed (`ingestion.feeds`) decides the source |
| 11 | FX price history `market_history/prices.csv` | GARCH vols, HMM, estimated copula | BIS WS_XRU, ECB EXR, official parity; theratesapi.com columns under EXC-005 | Vendor `fx_spot` history (`adapter.history`) | None. The price-history build (Team A) has no vendor source |
| 12 | Equity / ETF series | GARCH equity vol, copula | None in `prices.csv` today; judgement `market.equity_vol` | Vendor equity index history | None |
| 13 | Sovereign ratings | Layer 1 rating PD, SD/D exemptions | Country Profile `rating` (analyst seed) | Vendor rating fields | None |
| 14 | Prediction-market prices | Layer 2 prior | `data/prediction_markets.csv` (hand-entered) | Not a Bloomberg/LSEG product | Not applicable |
| 15 | Macro indicators (WEO, WDI, BIS, ...) and GPR | Scorecard, layer 1, DSA | Public and IMF feeds (IMF is EXC-003) | Not in the vendor adapters' scope | Not applicable |

## 3. Layer 2 on CDS curves (row 1): what is built

Code: `econquest/engine/layer2_bayesian.py` (`MARKET_TERM_DEFAULTS`, `market_term_params`,
`market_term_from_curves`, `posterior(..., market_dir=None)`). Tests: `tests/test_layer2_market_term.py` (on the
fixture). Fixture: `tests/fixtures/market/vendor_cds_layer2_fixture.csv`. Effect script:
`python -m econquest.validation.licensed_readiness`.

Setting `probability.market_term` (not in `assumptions.json`):

| Key | Default | Meaning |
|---|---|---|
| `source` | `"profile"` | `"cds_curves"` reads curves from the market store at the run's as-of date |
| `measure` | `"spread"` | Par spread at `tenor_y`, through the same `spread / LGD / k` as today. `"hazard_1y"`: the curve's 1-year risk-neutral hazard replaces `spread / LGD`, using the quote's recovery and the curve shape |
| `tenor_y` | `cds.reference_tenor_y` (5) | Tenor for `measure "spread"` |
| `allow_synthetic` | false (must be a real true/false) | A curve with a SYNTHETIC, FIXTURE, FAKE or TEST marker in its source, licence, vendor tickers or snapshot-manifest provenance is never used |
| `max_age_days` | 7 (finite number >= 0) | A curve dated more than this before the as-of date is not used |
| `fallback` | `"profile"` | A country without a usable curve keeps its profile spread. `"error"` stops the run instead |

Every value is checked strictly: unknown keys, strings where a bool or number is expected, NaN or infinite numbers
and values outside the lists above stop the run.

**Licence allow-list (review fix).** Removing the word SYNTHETIC is not enough to get a curve used. A curve is used
only when (a) its licence tag has the vendor form `<bloomberg|lseg>:<licence_id> (<desk-internal|redistribution>)`,
(b) its source is that vendor, and (c) the licence register row that matches the licence tag
(`licences.licence_for(licence=...)`, most restrictive row) has a `source_id` starting with the vendor slug,
`internal_use` "yes" and `terms_verified` "yes" (`layer2_bayesian.licence_approved`). Team A added `bloomberg` and
`lseg` rows on 2026-10-25 (EQ-A-0093) with `terms_verified` UNVERIFIED and `client_output` barred, so **no curve
can be used today**, with or without `allow_synthetic`. Tests and the fixture script use a temporary register copy
in which a test-only row approves the fixture licence id `SYNTHETIC-FIXTURE-0001` and nothing else
(`licensed_readiness.write_fixture_register`).

Consistency with the 0.1.3 risk premium: both measures divide by `probability.risk_premium_ratio` (2.0; 1 for SD/D).
With `measure "spread"`, `bond_rv.fair_bp` is still the exact inverse of layer 2's physical PD on the same curve
spread (test `test_spread_measure_is_inverted_by_bond_rv`).

When on, the posterior frame gains `market_spread_bp`, `hazard_1y_rn`, `spread_equiv_bp`, `market_source`,
`market_licence`, `market_as_of`, `market_snapshot_id`, `market_term_reason`. When off, the frame is unchanged.

Fail-closed behaviour: `source "cds_curves"` with no market folder raises; no snapshot saved by the as-of date raises
`FileNotFoundError`. Neither falls back to seed spreads silently.

### Pipeline wiring (applied)

`run_pipeline` passes `market_dir` to `posterior` (AGENT-08, 2026-10-25). With the switch on, the country table
gains `market_spread_bp`, `spread_equiv_bp`, `hazard_1y_rn`, `market_source`, `market_licence`, `market_as_of`,
`market_snapshot_id` and `market_term_reason`; `RunResult.diagnostics["market_term"]` keeps the curve issues and the
fallback count, and a `RuntimeWarning` gives the number of countries that fell back to the profile spread. With the
switch off none of these appear. The CLI passes `market_dir=args.data`. `stress.reverse_stress` and
`single_factor_reverse` take `market_dir` and pass it to every run.

### Callers that do not pass `market_dir` (gaps)

With the switch on, each of these stops with "needs a market data folder" (fail closed, never seed spreads):

| Caller | Owner |
|---|---|
| `cli.py` reverse stress (`run_pipeline` rs-base, `reverse_stress`, `single_factor_reverse`, lines ~239-257) | Team C |
| `cli.py` `limits --propose` (now only needs to pass `market_dir=args.data`: `pretrade_check` takes it since EQ-B-0129) | Team C |
| `presentation/api.py` workbench, `presentation/country_note.py` | Team C |
| `validation/replicate.py`, `activation.py`, `hazard_refit.py`, `research_effect.py`, `_rerun_worker.py`, `licensed_readiness.py` (fail closed by design: pinned replays) | Team B |
| `validation/client_safe.py` (keeps `source "profile"`) | Team B, AGENT-07 (EQ-B-0096) |

Wired by EQ-B-0129 (no-op with the switch off; base unchanged): `record.take_record` (daily record), `monitoring`
champion/challenger, `limits.pretrade_check(market_dir=)`, `portfolio_risk.attribution / whatif / whatif_many
(market_dir=)` and its command line, `restructuring.run_restructuring_stress`.

### Publish guard

`layer2_bayesian.publish_guard(country, register=None)` raises `ValueError` when any non-blank `market_licence` is
not a vendor tag with scope `(redistribution)` whose register row says `client_output` "allowed". A table without
the column (switch off) passes. Today it refuses every vendor value, because the `bloomberg` and `lseg` rows say
barred. `publish` (cli.py, Team C) does not call it yet.

### Known limits

- Stress shocks on `countries.spread` (stress.py, macro scenarios, contagion) do not reach layer 2 for countries that
  use a curve: the curve value replaces the shocked profile value. They still reach layers 3 and 6. Before the switch
  is used for stress runs, stress.py (shared file) needs to pass the shock as a delta, for example a
  `spread_shock_bp` column that layer 2 adds to the curve value. Not built.
- Only layer 2 and bond RV read curves. Layers 3 and 6, the DSA and restructuring keep the profile spread (rows 3-5).
  Switching layer 2 alone makes the market term and the regime rules read different spreads.
- CDS conventions are simplified (no IMM dates, flat 4% discounting, see `cds-curves-and-rv.md`).
- Untested on real vendor data: the adapters' wire formats are untested against a terminal (Team A runbook).

### Effect on the FIXTURE (not real numbers)

**FIXTURE: synthetic vendor-shaped CDS quotes, not market data.** Base run 2026-10-23, shipped settings; curves for
7 countries from the fixture (snapshot saved 2026-10-22, fixture licence approved only in a temporary register copy), all other countries fall back to the profile spread and do
not change. One derived COL row in the fixture is excluded and reported. Layer 1, scorecard, prediction-market prior
and regime multiplier held at the base run. PDs in percent.

| Country | Profile bp | Fixture 5y bp | Market phys PD: today / spread / hazard_1y | pd_default: today / spread / hazard_1y |
|---|---|---|---|---|
| Vietnam | 100 | 110 | 0.83 / 0.92 / 0.50 | 0.36 / 0.38 / 0.28 |
| Philippines | 65 | 70 | 0.54 / 0.58 / 0.29 | 0.36 / 0.37 / 0.26 |
| Brazil | 160 | 180 | 1.33 / 1.50 / 0.75 | 1.12 / 1.19 / 0.84 |
| Pakistan | 450 | 480 | 3.75 / 4.00 / 5.81 | 8.04 / 8.30 / 9.95 |
| Argentina (fixture recovery 0.25) | 650 | 700 | 5.42 / 5.83 / 7.30 | 6.60 / 6.85 / 7.66 |
| Nigeria | 400 | 420 | 3.33 / 3.50 / 2.49 | 3.88 / 3.98 / 3.36 |
| Zambia | 450 | 460 | 3.75 / 3.83 / 4.31 | 4.53 / 4.58 / 4.86 |

What the fixture shows about the mechanism, not about the market: with `measure "spread"` the change is the 5y
spread difference passed through `w_m` 0.5. With `measure "hazard_1y"` the curve shape matters: upward curves
(VNM, PHL, BRA, NGA) give a lower 1-year PD than the 5y spread, inverted curves (PAK, ARG, ZMB) a higher one, and a
quote recovery below 0.40 raises the hazard (ARG). Which measure to use is a model decision for when real curves exist.

### End to end on the fixture (EQ-B-0129)

`python -m econquest.validation.layer2_cds_e2e [--paths 20000]` runs the whole pipeline (not layer 2 alone) on a
temporary copy of `data/` with the fixture saved into its market store, read through `store.gated_market_history`,
`cds_curves` and `probability.market_term`, and reports VaR99, ES99, EL and L-VaR99 against the base plus the PD move
per country, with one case per guard (licence row, synthetic marker, staleness, point in time twice, market gate,
publish_guard, switch off with a store present, shared data hash unchanged). FIXTURE effect at 20k: 5y spread VaR99
+0.240, ES99 +0.256, EL +0.055, L-VaR99 +0.240 $mm; 1y hazard -0.155 / -0.703 / +0.185 / -0.155. All 9 checks pass at
20k and 100k. Tier 1 card (parked): `docs/governance/decisions/B-0129-layer2-cds-card.md`. Tests:
`tests/test_layer2_cds_e2e.py`, including `test_going_live_is_config_only` (the register row's terms_verified set
to yes plus `{"source": "cds_curves"}` is all it takes for unmarked curves to be used).

## 4. What the client-safe run would need to read

`econquest/validation/client_safe.py` is owned by AGENT-07 (EQ-B-0096). It is not changed here. Facts for that work:

1. **Licence tag per row.** Vendor rows carry `licence = "<vendor>:<licence_id> (<scope>)"`. Desk-internal rows must
   not reach client output (`A-licensed-vendors.md` section 6). There is no publish-time scope check yet.
2. **Register gap (Team A).** `data/licences.csv` now has `bloomberg` and `lseg` rows (licence `^bloomberg:` /
   `^lseg:`, client_output barred). No row has a `match_path` for `live/market/snapshots/` or
   `market/cds_snapshots.csv`, and the client-safe copy drops files by path only, so today a vendor store would be
   copied into the client-safe data folder unchanged. Team A would need path rows for the store.
3. **Per-country tag in the run.** With the switch on, the country table carries
   `market_licence` and `market_source`. A client-safe check can refuse or replace any country whose
   `market_licence` ends in `(desk-internal)`.
4. **Settings the client-safe variant would set.** `probability.market_term.source "profile"` and
   `bond_rv.use_cds_curves false` give today's profile-spread numbers for every country, or keep `"cds_curves"` only
   for rows with a `redistribution` scope (needs a scope filter in `market_term_from_curves`, not built).
5. **Current behaviour is fail-closed.** `client_safe` calls `run_pipeline` without `market_dir`. If the shipped
   settings had `source "cds_curves"`, layer 2 would raise rather than use vendor data or silently use seed spreads.
   `publish_guard` (section 3) is the check a client-facing writer can call on the country table.

## 5. Ready now / needs a licence

Ready (code, off by default, tested on the fixture): layer 2 on CDS curves (row 1); bond RV on CDS curves (row 2);
quote recovery (row 7); point-in-time, derived-row, synthetic and staleness guards.

Needs a licence and Sam's decisions: a register row with `terms_verified` yes (Team A, after the contract is read);
a configured entitlement and verified ticker map (Team A runbook sections 2-3);
the first supervised dry run; real snapshots in the store; then the Tier 1 change card for `probability.market_term`
with its effect on the real base. Needs code before it could be switched: `market_dir` in the callers listed in section 3; the stress delta
hook; the `publish_guard` call in publish (Team C); rows 3-5, 8, 9 and 10-13; the register rows and client-safe scope handling in section 4.
