# MVP numbers sign-off (EQ-B-0111, MVP rows M3 and M4)

Date: 2026-10-26. AGENT-07. Status: **signed off on the current MVP dataset** (`data/mvp/data`, Team A EQ-A-0110,
rebuilt 2026-10-26 00:18Z, dataset sha256 `6a301188...2d63`, vintage 2026-10-25T130355Z-aac8592d), model date as_of
2026-10-23; pack run 20261026T004819-base (pack data hash `47fe75fcf5941be4`). The earlier freezes `12d8b7b3...`,
`f11cf78a...` and `e60bbc7c...` were signed off too, and all give bit-identical numbers: base 66.21 / 87.91 / 4.01 /
71.49 (section 1a).
Every check passes; the known limitations below hold.

Code: `econquest/validation/mvp_signoff.py`. Tests: `tests/test_mvp_signoff.py` (checks on synthetic numbers and
tiny folders; one 2,048-path run on a temporary copy of the shared data).
Reports (internal): `outputs/mvp-signoff/2026-10-23/` (MVP dataset `6a301188`, with `dataset-moves/`; the earlier
freezes are kept in `2026-10-23-mvp-freeze-12d8b7b3/`, `-f11cf78a/` and `-e60bbc7c/`) and
`outputs/mvp-signoff/2026-10-23-shared-data/` (shared `data/`, the 0.6.0 base). Each folder has `signoff.md` and
`.json`, and CSVs for the checks, PDs, limits, stress, stress limit flags and reverse stress, plus the replication table.

```
python -m econquest.validation.mvp_signoff --as-of 2026-10-23 --data data/mvp/data --reference none --allow-drift
python -m econquest.validation.mvp_signoff --as-of 2026-10-23              # shared data, against the 0.6.0 base
```

About 12 minutes each: base 100,000 paths twice (reproducibility), 17 scenarios at 100,000, reverse stress at 20,000
(69 searches), full replication.

## 1. What is checked

| Check | Row | MVP dataset | Shared data |
|---|---|---|---|
| M3.1 base metrics finite, ES99 >= VaR99 >= 0, EL >= 0 | M3 | PASS | PASS |
| M3.2 base reproduces bit for bit (same inputs, as_of, paths) | M3 | PASS | PASS |
| M3.3 base equals the 0.6.0 release reference (to 2 decimals at 100k; exact at 20k) | M3 | n/a (different data, section 4) | PASS |
| M3.4 default PDs for the 18 desk names, in [0, 1], PD any peril >= PD default | M3 | PASS | PASS |
| M3.5 limit status follows limits.json (utilisation = value / limit; warning 80%, breach 100%) | M3 | PASS (71 limits) | PASS |
| M3.6 limit status of the base | M3 | EL warning 80.1% | EL warning 82% |
| M3.7 replication, 0 FAIL | M3 | PASS: 64 PASS, 77 DRIFT, 2 INFO (with `--allow-drift`) | PASS: 137 PASS, 2 INFO |
| M4.1 every scenario ran or is a labelled gap (an unlabelled one fails) | M4 | PASS: 17 of 18; EMDEF_BRA labelled gap | PASS |
| M4.2 stressed metrics finite, ES99 >= VaR99 | M4 | PASS | PASS |
| M4.3 limit breaches flagged per scenario | M4 | 17 of 17 breach at least one limit | same |
| M4.4 reverse stress on VaR99, ES99, L-VaR99 for 17 scenarios and 6 factors | M4 | PASS (69 records) | PASS |
| M4.5 reverse stress agrees with the library (breach at scale 1 <=> breach scale <= 1) | M4 | PASS | PASS |

Also checked by hand: the MVP base, PDs, composites, regimes and the 12 stressed ES99 values equal the research pack
run (EQ-B-0110; first run 20261025T164946-base, rebuilt runs 20261025T175202-base, 20261025T183022-base and 20261026T004819-base, `outputs/reports/mvp/`) to 1e-15.
So the pack, the sign-off and `econquest run` agree.

Replication on the MVP dataset: the release and docs checks (R01-R47, D01-D16) compare the numbers written in the
release notes with a recomputation. Those numbers belong to the release inputs, and the MVP dataset changes
countries.csv and indicators.csv, so they cannot match. `--allow-drift` marks those 77 as DRIFT on `6a301188`
(79 on `e60bbc7c`, 75 before pins R48-R51 joined; R48-R51 are the 0.7.0 shared base, 66.78 / 88.48 / 4.10 / 72.06,
which is not the MVP base; R09 and D14 pass since the drift reference became release 0.7.0). The other checks
(backtest, hazard, scorecard, GARCH and the release checks that do not depend on the changed inputs: 64) PASS. The
release itself replicates on its own inputs (shared data: PASS 141, 0 FAIL).

## 1a. Why the re-freeze gives bit-identical numbers

The 17:39Z re-freeze (`f11cf78a...`) reproduces the first freeze (`12d8b7b3...`) bit for bit:
- base 66.21 / 87.91 / 4.01 / 71.49;
- all 18 PDs;
- the 17 stressed runs;
- all 69 reverse-stress breach scales.

`dataset_diff` between the two copies (`outputs/mvp-signoff/2026-10-23/dataset-moves/refreeze-diff-*.json`) finds
**0 changed cells** in countries.csv and indicators.csv, the only files the model reads values from. **fx3m is
identical in all 18 countries**, at full precision. Five files changed, all records or governance, none of them a
model input:
- `audit_trail.csv`, `live/provenance.csv`, `live/review.csv`, `live/live_profile.csv`: the 17 fx3m records. They
  said "yfinance (Yahoo Finance)" with Yahoo values (e.g. Argentina 2.552, Belize 1.464); they now name the official
  values the cells already held.
- `licences.csv`: Team A's attribution fix (4 rows: the IMF and World Bank attribution texts without template
  placeholders).

The cause, as the coordinator guessed: the first freeze already took fx3m from Sam's full-fetch vintage
(2026-10-25T130355Z-aac8592d, `team/inbox/pull-20261025-fullfetch/review.csv`). 17 cells are official FX and 1 is a
seed (Zimbabwe 8.0). Section 4 counted those 17 among the 56 moved cells. EQ-A-0112's apply changed the provenance
records the re-freeze copies, not the values the first freeze had already taken. The shared data/ took a different
route: it now holds EQ-A-0112's values, which differ from the MVP's for Pakistan (0.5 vs -0.32), Malaysia (-1 vs
-0.15), Colombia (-1 vs -1.58) and Senegal (0 vs 1.64), and match to rounding elsewhere. So the current shared base
(66.78 / 88.48 / 4.10 / 72.06 at 100k) is not the MVP base; section 4 explains the MVP against the 0.6.0 shared data
(before EQ-A-0112).

**Rebuild `e60bbc7c...` (18:25Z) against `f11cf78a...`.** Again bit-identical: base, 18 PDs, 17 stressed runs, 71
limits, stress limit flags and 69 reverse-stress scales are byte-identical files (`pds.csv`, `stress.csv`,
`limits.csv`, `stress_limits.csv`, `reverse_stress.csv`). `dataset_diff`
(`dataset-moves/refreeze-diff-f11cf78a-to-e60bbc7c.json`) finds **0 changed cells** and changed files only among the
records: `audit_trail.csv`, `live/provenance.csv`, `live/review.csv` (plus the top-level `provenance.csv` and
`manifest.json`). In the top-level provenance, 32 cells are relabelled live -> seed ("value in place before vintage
2026-10-25T130355Z-aac8592d ... kept because the new pull is missing"; mostly 2.1 and 6.2) with the same values.
The manifest's live counts fall accordingly (indicators 284 -> 254, countries 76 -> 74). Only the replication counts
move (75 -> 79 DRIFT, above), from a new release note, not from the data.

**Rebuild `6a301188...` (2026-10-26 00:18Z).** Again bit-identical: base, 18 PDs, 17 stressed runs, 71 limits, stress
limit flags and 69 reverse-stress scales are byte-identical files to the `e60bbc7c` run. Against the intermediate
freeze `86db5f1e...` (2026-10-25 23:42Z) `dataset_diff` finds **0 changed cells**; only `licences.csv` changed (new
licence-register rows: nowcast national sources, COW contiguity, IMF-via-WDI terms), which is not a model input
(`dataset-moves/refreeze-diff-86db5f1e-to-6a301188.json`). Replication now reads 64 PASS, 77 DRIFT, 0 FAIL: the drift
reference moved from release 0.6.0 to 0.7.0 (`inputs/0.7.0/RELEASE-HASHES.json`), so R09 and D14 now pass; no
number moved.

## 2. Results on the MVP dataset ($mm, 131,072 Sobol paths)

| | VaR99 | ES99 | EL | L-VaR99 |
|---|---:|---:|---:|---:|
| MVP dataset | 66.21 | 87.91 | 4.01 | 71.49 |
| Shared data (0.6.0 base) | 66.70 | 88.43 | 4.08 | 71.99 |
| Limit | 95 | 115 | 5 | 100 |
| Utilisation (MVP) | 70% pass | 76% pass | **80.1% warning** | 71% pass |

Default PDs (12 months, %) and regimes: no regime changes between the two datasets.

| Country | MVP | Shared | Change (pp) | Regime |
|---|---:|---:|---:|---|
| Venezuela | 99.00 (cap) | 99.00 | 0.00 | Crisis |
| Zimbabwe | 78.25 | 78.40 | -0.15 | Crisis |
| Senegal | 13.21 | 13.34 | -0.13 | Crisis |
| Pakistan | 7.96 | 8.04 | -0.08 | Stressed |
| Argentina | 6.59 | 6.60 | -0.01 | Stressed |
| Belize | 4.73 | 4.86 | -0.13 | Stressed |
| Zambia | 4.70 | 4.53 | +0.18 | Stressed |
| Nigeria | 3.92 | 3.88 | +0.04 | Stressed |
| Brazil | 1.13 | 1.12 | +0.01 | Calm |
| Colombia | 1.08 | 1.09 | -0.01 | Calm |
| Vietnam, Philippines, India, China, Malaysia | 0.20 to 0.36 | same to 0.01 | | Calm |
| South Korea, Japan, Singapore | 0.04 to 0.06 | same | | Calm |

Stress library (MVP, 100,000 paths). Book limit status is given for VaR / ES / EL / L-VaR (p pass, w warning,
B breach):

| Scenario | VaR99 | ES99 | EL | L-VaR99 | Book | Other breaches |
|---|---:|---:|---:|---:|---|---|
| A Hawkish Fed +200 bps | 113.21 | 146.60 | 6.38 | 122.71 | B B B B | Crisis-regime share |
| B 30% commodity collapse | 73.71 | 95.65 | 5.40 | 78.99 | p w B p | |
| C Strait of Malacca blockade | 81.16 | 106.87 | 5.16 | 90.00 | w w B w | |
| ASIA97 | 132.30 | 154.91 | 6.51 | 141.95 | B B B B | Crisis-regime share |
| GFC08 | 158.87 | 180.65 | 6.30 | 184.75 | B B B B | Crisis-regime share |
| TAPER13 | 121.19 | 152.19 | 11.99 | 130.15 | B B B B | Crisis-regime share |
| COVID20 | 134.70 | 161.53 | 9.16 | 148.89 | B B B B | Crisis-regime share |
| FED22 | 133.10 | 161.05 | 21.12 | 141.84 | B B B B | Crisis-regime share |
| DOWNGRADE | 72.59 | 93.89 | 5.62 | 77.88 | p w B p | |
| TAIWAN | 123.43 | 151.02 | 5.18 | 133.41 | B B B B | |
| HORMUZ | 118.39 | 149.34 | 4.83 | 124.94 | B B w B | |
| TARIFF | 112.51 | 141.04 | 4.06 | 119.07 | B B w B | |
| CHINA_HL | 120.15 | 152.05 | 5.69 | 127.50 | B B B B | |
| MACRO_FED | 126.56 | 156.58 | 12.19 | 136.77 | B B B B | Crisis-regime share |
| MACRO_CHINA | 105.12 | 136.10 | 3.72 | 112.01 | B B p B | |
| MACRO_OIL | 108.45 | 138.44 | 6.12 | 114.88 | B B B B | |
| MACRO_WAR_ASIA | 136.88 | 164.80 | 5.53 | 148.74 | B B B B | Crisis-regime share |

EMDEF_BRA (Brazil default with BIS contagion): **not run: no BIS CBS exposures.** Team A confirms that no BIS CBS
exposure file exists anywhere; the pull is parked on `team/when-sam-is-ready.md`. The sign-off counts it as a
labelled gap (`mvp_signoff.LABELLED_GAPS`), not a failure. A scenario that cannot run for any other reason fails M4.1.

Reverse stress (MVP, 20,000 paths): the smallest scenario scale, or single-factor move, that breaches each book limit.
ES99 breaches first everywhere except MACRO_OIL, where all three breach at the same scale.

| Scenario / factor | VaR99 | ES99 | L-VaR99 |
|---|---:|---:|---:|
| A | 0.53 | 0.31 | 0.50 |
| B | none up to 4x | none | none |
| C | 1.81 | 1.41 | 1.50 |
| ASIA97 | 0.38 | 0.19 | 0.38 |
| GFC08 | 0.22 | 0.13 | 0.19 |
| TAPER13 | 0.44 | 0.34 | 0.44 |
| COVID20 | 0.28 | 0.19 | 0.25 |
| FED22 | 0.38 | 0.25 | 0.38 |
| DOWNGRADE | 2.47 | 1.66 | 2.28 |
| TAIWAN | 0.44 | 0.25 | 0.38 |
| HORMUZ | 0.53 | 0.34 | 0.50 |
| TARIFF | 0.56 | 0.31 | 0.53 |
| CHINA_HL | 0.47 | 0.28 | 0.44 |
| MACRO_FED | 0.38 | 0.25 | 0.38 |
| MACRO_CHINA | 0.59 | 0.44 | 0.56 |
| MACRO_OIL | 0.63 | 0.63 | 0.63 |
| MACRO_WAR_ASIA | 0.38 | 0.22 | 0.38 |
| Spreads (bp) | 563 | 375 | 375 |
| EM FX (% depreciation) | 16.3 | 7.5 | 16.3 |
| Default PD multiplier (x) | 4.19 | 4.09 | 4.09 |
| Copula loading (added) | 0.46 | 0.31 | 0.45 |
| Hard-currency LGD (pp) | none up to 35 | none | none |
| Downgrade (notches) | none up to 6 | none | none |

## 3. Limit flags (not defects)

- **Base:** EL is in the warning band, 4.01 of 5.0 (80.1%; shared data 4.08, 82%). Venezuela alone contributes
  4.67 $mm of EL (its PD is at the 99% cap). The other 17 names together contribute -0.67, net carry gains. Every
  other book and position limit passes.
- **Stress:** every scenario breaches at least one limit. B and DOWNGRADE breach EL only; 13 of 17 breach VaR99,
  ES99 and L-VaR99.

## 4. MVP dataset against the shared data: every move explained

`dataset_diff` (in the report's `dataset-moves/`) shows that only `countries.csv` and `indicators.csv` change,
in 281 cells. The files the MVP dataset leaves out are: raw BIS and Yahoo pulls, the 2026-10-23 vintage copy, the
GOOGLEFINANCE archive, the FX builds and the repairs. Deleting them from the shared data changes no metric (checked:
0.0000 on all four).

The 281 cells fall into two groups:
- **Precision only (225 cells, 16 items).** The same values, written with more digits by the MVP builder, differ by
  at most 0.06% (median 0). The items are 1.3, 1.6, 1.7, 2.8, 2.10, 2.12, 5.5, 5.6, 5.10, 5.12, 5.13, 5.14, 6.2, and
  countries.csv exports, pop and reserves. Each moves the base by less than 0.0005 $mm.
- **New values from Sam's full fetch (vintage 2026-10-25T130355Z-aac8592d, `team/inbox/pull-20261025-fullfetch`),
  56 cells, 4 items:**

| Item | Cells | What changes | VaR99 | ES99 | EL |
|---|---:|---|---:|---:|---:|
| 2.9 short-term external debt, % of net reserves | 8 | Pakistan 80 to 52, Belize 20 to 2.6, Brazil 20 to 25.6 | -0.36 | -0.49 | -0.075 |
| 3.4 3-year change in WGI composite | 13 | WGI changes from the vintage (e.g. Zambia +3 to +0.6, Philippines 0 to +3.4) | -0.11 | -0.06 | -0.019 |
| 3.5 WGI composite percentile | 18 | WGI from the vintage (e.g. Belize 30 to 40, Nigeria 15 to 21, Pakistan 22 to 16) | -0.11 | -0.01 | +0.003 |
| fx3m (3-month FX move) | 17 | official FX from the fresh vintage (e.g. Senegal 4.45 to 1.64, Belize 1.46 to 0) | +0.00 | +0.04 | +0.006 |

Each row is one item swapped alone into the shared data, at 20,000 paths. Together they move the base by VaR99
-0.40, ES99 -0.52, EL -0.083, L-VaR99 -0.40 at 20k. At 100k the move is -0.49 / -0.52 / -0.08 / -0.50. The parts
interact (VaR99 parts sum to -0.58), because the 99% quantile moves between paths. The PD moves in section 2 follow
from the same cells: Belize and Pakistan from 2.9 and 3.5, Zambia from 3.4, Senegal from fx3m.

## 5. Known limitations

1. **Seeds.** Most inputs are still seed estimates (analyst/Claude, Oct 2026):
   - countries.csv: 644 of 720 cells.
   - indicators.csv: 1,210 of 1,494 cells.

   The gate passes with 0 unexplained holds: 105 held, 196 missing, and 49 seed cells blank. Seed values are
   labelled in the provenance (`data/mvp/provenance.csv`), but the PDs rest largely on them.
2. **EL warning band.** The base EL sits at 80.1% of its limit (shared data 82%), so it is in the warning band
   before any stress. It comes almost entirely from Venezuela, whose default PD is at the engine's 99% cap, so a
   smaller Venezuela position or a different cap moves it directly. EQ-B-0105 has the options note (parked).
3. **Paper Layer 1.**
   - The hazard layer uses the paper's table 7.1 coefficients in mode `paper_standardized`, rescaled each run to the
     rating prior (`calibrate_to = rating_prior_location_scale`, hazard_weight 0.5).
   - They have never been fitted on a default panel inside this project (docs/validation/hazard-layer1.md); the
     CRAG and WB refits are dry runs.
   - Layer 1 PDs are therefore the rating prior reshaped by the paper's signs, not an estimated hazard.
4. **PD cap.** Venezuela's PD is at the 0.99 cap in the base and in every scenario. Zimbabwe reaches the cap in
   at least scenarios A, DOWNGRADE, CHINA_HL and MACRO_WAR_ASIA (research-pack notes). Changes at the cap read 0.
5. **Replication on the MVP dataset is a drift run.** The release and docs checks cannot match changed inputs (77
   DRIFT). The release record replicates only on the shared data.
6. **EMDEF_BRA: not run, no BIS CBS exposures** (labelled gap; pull parked for Sam's Mac pass). Scenario briefs in the research pack cover the 12
   non-historical scenarios; the 5 historical ones are in this library only.
7. **Copula and volatility on partial price history.** There are no ETF series for 10 names, so the estimated copula
   uses their FX moves and keeps judgement loadings for 7. South Korea equity keeps the judgement `market.equity_vol`.
8. **Monte Carlo error.**
   - Base 95% bands are about ±0.5 $mm on VaR99 and ±1 on ES99 (weekly brief).
   - Reverse stress runs at 20,000 paths with bisection tolerance 0.05 of scale, so breach scales are good to about
     ±0.05x.
   - A breach within 2% of a limit can flip between path counts.
9. **No breach found** for scenario B (up to 4x), hard-currency LGD (+35 pp) or downgrades (6 notches): the book is
   not sensitive enough to these alone within the searched range.
10. **Licence register not approved** (status no_baseline, R44). The outputs are internal research only, and client
    output stays refused (docs/validation/client-safe-run.md).
