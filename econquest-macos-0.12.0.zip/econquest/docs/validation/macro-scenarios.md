# Model validation: global macro scenario engine

Date: 2026-10-24. Ticket: EQ-B-0082 (AGENT-05). Code: `econquest/engine/macro_scenarios.py`. Tests:
`tests/test_macro_scenarios.py`. Status: built. The stress.py hook is applied (AGENT-08, 2026-10-24): a scenario shock
`{"target": "macro", ...}` is expanded in `apply_shocks`. No shipped scenario uses it yet; the scenarios.json
entries below wait for Sam's approval. The 0.3.0 base is unchanged (20,000-path check
before and after: VaR99 69.03387805642626, ES99 91.20694811981282, EL 0.8046426805768283, L-VaR99 74.31538388313861).

## Purpose

The hand-built scenarios in `data/scenarios.json` set shocks by region, rating or export type. They do not say
why Brazil moves more than Malaysia, and they do not extend to new countries. This engine starts from six global
drivers, passes them through each country's trade, financial and commodity exposures, and writes the result as an
ordinary stress.py shock list. Stress then runs exactly as today. Because the shocks are computed per country, the
same scenario covers the 88-country proposal once it is promoted.

## Drivers

| Driver | Unit |
|---|---|
| `us_rate_bp` | US policy rate change, bp |
| `usd_pct` | USD broad index change, % (+ = stronger dollar) |
| `china_gdp_pp` | China real GDP growth change, pp (- = slowdown) |
| `oil_pct` | oil price change, % |
| `conflict` | regional conflict intensity, 0 to 1, with `conflict_region` and `conflict_epicentre` (ISO3) |
| `vix_pts` | global risk appetite, change in VIX points (+ = risk-off) |

All zero means no shock: `compile_shocks` returns an empty list.

## Propagation

For each country, all terms are linear in the drivers, so a scenario at twice the size gives twice the moves
(apart from rounding, the optional notch rule and the location flag).

- Partner growth. US, EU and China growth changes come from the drivers (`g_*` coefficients).
- Trade. Growth hit = sum over US, China, EU of (exports to partner, % of GDP) x partner import elasticity (2) x
  partner growth change.
- Commodity. Prices: oil = `oil_pct`; metals and agriculture move with China growth and the dollar; gold with VIX
  and the dollar. Terms of trade (% of GDP) = net oil exports x oil change + non-oil commodity exports x
  main-commodity change. Commodity exporters' commodity gap moves by 0.67 x the main commodity's price change.
- Financial. A level beta (spread / 300 bp, clipped to 0.25-2) scales the Fed, VIX and dollar terms, so a 600 bp
  name moves about twice as much as a 300 bp name. The dollar term grows with the FX share of government debt
  (indicator 1.5). DM anchors take no EM risk premium.
- Spread change = financial + trade (growth loss) + commodity (terms-of-trade loss; gains tighten at a third of
  the rate) + conflict + China's own move.
- FX change (3-month depreciation) = regime pass-through (Float 1, Managed 0.6, Peg 0.15) x (dollar + rating
  risk multiplier x (Fed + VIX) - terms of trade + conflict); China's own CNY move feeds Asian currencies at 0.3.
  The pressure a peg or managed float does not let through shows up as a reserve loss (`res3m`, indicator 2.1).
- Conflict. Proximity: epicentre 1, same region 0.6, other regions 0.25, DM anchors 0. It moves spreads, FX, text
  stress, the current account, pillar 5 and 6 trigger add-ons (proximity 0.5 and above), the portfolio location
  flag ("High activity", intensity 0.5 and above) and the regional copula loading.
- Indicators moved: 5.6 growth, 2.8 current account, 5.5 inflation (oil and FX pass-through), 1.3 debt/GDP
  (revaluation of FX debt: x (1 + FX share x depreciation)), 2.1 reserves.
- Settings: global copula loading, regional loading, liquidity spreads, equity vol, local-rate vol. Rates: the
  `rates` target moves Eurobond (UST) and local yields by half the Fed move (plus oil on local yields).
- Rating notches: off by default, because none of A, CHINA_HL, HORMUZ or TAIWAN notches. With `notch_rule=True`,
  one notch down per 200 bp of spread change, at most 3 (calibrated to DOWNGRADE).
- BIS common creditors. China's slowdown and the conflict epicentre each become a stress.py `contagion` shock
  (origin China, up to +30 bp per pp of slowdown / +150 bp at full conflict, to the most exposed peer). They are
  emitted only when `data/live/raw_bis_cbs.csv` exists. It does not exist yet (Team A handoff, EQ-B-0037), so the
  runs below have no contagion leg; the test runs it on the SYNTHETIC fixture `tests/fixtures/bis_cbs_synthetic.csv`.

## Data and coefficients

The repo has no bilateral trade data, no BIS banking statistics and no commodity-export breakdown (checked:
`data/`, `data/panel/`, `data/live/`; `raw_bis.csv` holds only EER, credit gap and policy rate). The exposure table
`EXPOSURE_CSV` (88 rows, one per ISO3 of `data/panel/universe_proposal.csv`) is therefore **judgement**: approximate
magnitudes from memory of IMF Direction of Trade Statistics and UN Comtrade around 2023, rounded, not fetched.
Columns: goods exports to the US, China and EU-27 (% of GDP; EU members include intra-EU trade), net oil and gas
exports (% of GDP), main non-oil commodity class and non-oil commodity exports (% of GDP). It should be replaced by
IMF DOTS and Comtrade pulls on Sam's Mac. An ISO3 not in the table gets regional defaults, with the oil or
commodity class read from the `mainexp` text. FX share of debt comes from indicator 1.5 when present, else a tier
default. Every coefficient is in `COEF` with its unit and source:

| Coefficient | Value | Unit | Source |
|---|---:|---|---|
| `g_us_per_100bp` | -0.4 | pp US growth per +100 bp | judgement; FRB/US-style policy multiplier, 1-2 year horizon |
| `g_us_per_vix` | -0.03 | pp per VIX point | judgement |
| `g_us_per_10pct_oil` | -0.1 | pp per +10% oil | judgement; IMF WEO rule of thumb for an oil-importing large economy |
| `g_eu_per_100bp` | -0.2 | pp EU growth per +100 bp Fed | judgement |
| `g_eu_per_vix` | -0.03 | pp per VIX point | judgement |
| `g_eu_per_10pct_oil` | -0.15 | pp per +10% oil | judgement; EU is a larger net importer than the US |
| `g_eu_per_china_pp` | 0.15 | pp EU growth per pp China growth | judgement |
| `g_cn_per_10pct_oil` | -0.05 | pp per +10% oil | judgement |
| `partner_import_elasticity` | 2 | % partner imports per 1% partner GDP | judgement; trade income elasticities 1.5-2.5 in the literature |
| `metals_per_china_pp` | 10 | % metals price per pp China growth | judgement; CHINA_HL: China -3 pp ~ commodities -30% |
| `ags_per_china_pp` | 4 | % agricultural price per pp China growth | judgement |
| `commod_per_usd` | -0.5 | % non-oil commodity price per +1% USD | judgement; dollar-commodity elasticity |
| `gold_per_vix` | 0.6 | % gold price per VIX point | judgement; safe-haven bid |
| `commgap_pass` | 0.67 | commodity gap points per 1% main-commodity price | judgement; HORMUZ: oil +60% -> commgap +40 |
| `growth_per_tot` | 0.25 | pp growth per 1% of GDP terms-of-trade gain | judgement |
| `home_china` | 1 | pp China growth per pp driver | definition |
| `level_ref_bp` | 300 | bp spread at which the level beta is 1 | judgement; spread changes scale with the level |
| `level_beta_min` | 0.25 | floor on the level beta | judgement |
| `level_beta_max` | 2 | cap on the level beta | judgement; keeps defaulted names (VEN 6000 bp) from tripling every shock |
| `s_per_100bp` | 50 | bp per +100 bp Fed at beta 1 | judgement; scenario A gives +280 bp to HY at +200 bp with risk-off |
| `s_per_vix` | 6 | bp per VIX point at beta 1 | judgement; TAPER13 / FED22 EMBI moves vs VIX |
| `s_per_usd_at_fxd50` | 8 | bp per +1% USD at 50% FX debt, beta 1 | judgement |
| `s_per_growth_pp` | 40 | bp per pp external growth loss at beta 1 | judgement |
| `s_per_tot_pct` | 15 | bp per 1% of GDP terms-of-trade loss at beta 1 | judgement; HORMUZ importers +150 bp |
| `s_per_tot_gain` | 5 | bp tightening per 1% of GDP terms-of-trade gain at beta 1 | judgement; windfalls tighten less than losses widen (HORMUZ exporters still +50 bp) |
| `s_conflict` | 300 | bp at conflict 1 and proximity 1 | judgement; TAIWAN: Asia +250 bp |
| `s_home_china_per_pp` | 50 | bp China spread per pp slowdown | judgement; CHINA_HL: China +150 bp for -3 pp |
| `fx_per_usd` | 1 | % per +1% USD | definition (bilateral vs USD) before regime pass-through |
| `fx_per_100bp` | 1 | % per +100 bp Fed at risk multiplier 1 | judgement |
| `fx_per_vix` | 0.15 | % per VIX point | judgement |
| `fx_per_tot_pct` | 0.5 | % per 1% of GDP terms-of-trade loss | judgement |
| `fx_conflict` | 10 | % at conflict 1, proximity 1 | judgement; TAIWAN: Asian floats -12% |
| `fx_home_china_per_pp` | 5 | % CNY per pp slowdown | judgement; CHINA_HL: CNY -15% for -3 pp |
| `fx_asia_cny_beta` | 0.3 | Asian FX move per 1% CNY move | judgement; regional CNY beta 0.3-0.5 |
| `res_absorb` | 0.5 | res3m % loss per % of unpassed FX pressure | judgement; pegs and managed floats spend reserves |
| `ca_conflict` | -4 | pp of GDP current account at conflict 1, proximity 1 | judgement; TAIWAN -5, HORMUZ -4 |
| `infl_per_oil_importer` | 0.03 | pp inflation per 1% oil, net importers | judgement; EM headline pass-through 0.02-0.05 |
| `infl_per_oil_exporter` | 0.01 | pp inflation per 1% oil, net exporters | judgement |
| `infl_per_fx` | 0.2 | pp inflation per 1% depreciation | judgement; EM FX pass-through ~0.2 |
| `t_per_vix` | 0.05 | z per VIX point | judgement; scenario A +1.0 |
| `t_per_100bp` | 0.125 | z per +100 bp Fed | judgement; scenario A +1.0 |
| `t_conflict` | 4 | z at conflict 1, proximity 1 | judgement; TAIWAN Asia +4 |
| `trig5_conflict` | 15 | pillar 5 points at conflict 1, proximity 1 (proximity >= 0.5) | judgement; TAIWAN |
| `trig6_conflict` | 20 | pillar 6 points at conflict 1, proximity 1 (proximity >= 0.5) | judgement; TAIWAN |
| `gl_per_vix` | 0.01 | global copula loading per VIX point | judgement; A +0.25, TAIWAN +0.15 |
| `gl_per_100bp` | 0.05 | global loading per +100 bp Fed | judgement |
| `gl_per_china_pp` | 0.03 | global loading per pp China slowdown | judgement; CHINA_HL +0.2 |
| `gl_per_10pct_oil` | 0.01 | global loading per +10% oil (rises only) | judgement; HORMUZ +0.15 |
| `gl_max` | 0.9 | cap on global loading | as in scenarios.json |
| `rl_conflict` | 0.25 | regional loading at conflict 1 | judgement; TAIWAN +0.25 |
| `rl_max` | 0.6 | cap on regional loading | as in scenarios.json |
| `liq_per_vix` | 0.04 | x liquidity spread_mean per VIX point | judgement; GFC08 x3 at VIX about +50 |
| `liq_conflict` | 0.25 | x liquidity spread_mean at conflict 1 | judgement |
| `eqvol_per_vix` | 1 | equity vol points per VIX point | judgement |
| `lrvol_per_100bp` | 0.25 | x local rate vol per +100 bp Fed | judgement |
| `lrvol_per_10pct_oil` | 0.1 | x local rate vol per +10% oil (rises only) | judgement; HORMUZ x2 |
| `hard_rate_per_bp` | 0.5 | bp UST level per bp Fed | judgement; 10y moves about half the policy rate |
| `local_rate_per_bp` | 0.5 | bp EM local yields per bp Fed | judgement; TAPER13 / FED22 |
| `local_rate_per_10pct_oil` | 5 | bp local yields per +10% oil (rises only) | judgement |
| `notch_bp` | 200 | bp of spread change per notch down | judgement; DOWNGRADE gives -2 sub-IG in a broad cycle |
| `notch_max` | 3 | max notches | judgement |
| `bis_china_per_pp` | 30 | bp to the most exposed common-creditor peer per pp China slowdown | judgement |
| `bis_conflict` | 150 | bp to the most exposed peer of the epicentre at conflict 1 | judgement |

## Presets

| Preset | Drivers | Closest hand-built |
|---|---|---|
| FED_SHOCK | Fed +200 bp, USD +8%, VIX +12 | A (Hawkish Fed +200 bp) |
| CHINA_SLOWDOWN | China -3 pp, oil -20%, USD +3%, VIX +10 | CHINA_HL |
| OIL_SPIKE | oil +60%, VIX +8, USD +2%, Fed +25 bp, China -0.5 pp | HORMUZ |
| REGIONAL_WAR | conflict 1 in Asia (centre China), VIX +15, oil +15%, USD +4%, China -2 pp | TAIWAN |

The secondary drivers in each preset are judgement (sources in `PRESETS`). They are there because the events do
not come alone: a Fed shock comes with a stronger dollar and risk-off, a war with an oil and VIX move.

## Results on the shipped 18 names, 100,000 paths, as_of 2026-10-23

Base: VaR99 69.13, ES99 90.72, L-VaR99 74.42, EL 0.80 $mm (identical to the 0.3.0 reference). Stress runs use the
same seed and path count.

| Scenario | Shocks | VaR99 | ES99 | ES99 vs base | L-VaR99 | EL | Calm / Stressed / Crisis |
|---|---:|---:|---:|---:|---:|---:|---|
| FED_SHOCK | 108 | 122.87 | 153.10 | +68.8% | 132.78 | 8.12 | 2 / 10 / 6 |
| A | 8 | 112.33 | 145.44 | +60.3% | 121.44 | 2.38 | 1 / 10 / 7 |
| CHINA_SLOWDOWN | 124 | 105.27 | 137.02 | +51.0% | 112.15 | 0.03 | 7 / 7 / 4 |
| CHINA_HL | 13 | 122.06 | 153.67 | +69.4% | 129.41 | 1.99 | 1 / 13 / 4 |
| OIL_SPIKE | 124 | 109.30 | 139.52 | +53.8% | 115.40 | 2.54 | 9 / 6 / 3 |
| HORMUZ | 10 | 125.32 | 155.69 | +71.6% | 131.86 | 1.43 | 4 / 11 / 3 |
| REGIONAL_WAR | 131 | 134.58 | 161.19 | +77.7% | 146.44 | 1.49 | 1 / 10 / 7 |
| TAIWAN | 14 | 123.16 | 152.01 | +67.6% | 133.15 | 1.64 | 3 / 12 / 3 |

ES99 differences (preset minus hand-built): FED +7.7, CHINA -16.7, OIL -16.2, WAR +9.2 $mm.

### Why they differ (20,000-path decompositions)

- FED_SHOCK vs A (+7.7). About 3.5 comes from the rates leg: FED_SHOCK moves UST and local yields +100 bp, A has
  no yield shock (A plus the same rates leg: 145.6 -> 149.1; FED_SHOCK without it: 153.2 -> 150.0). The rest is the
  level beta: names above 300 bp take +310 to +580 bp (A: +280 flat). The rates leg is also why EL rises to 8.1:
  it is a deterministic mark-to-market loss on every path.
- CHINA_SLOWDOWN vs CHINA_HL (-16.7). CHINA_HL gives every floating and managed currency -12%, every investment-grade
  name +80 bp and every country +1.5 text stress. The drivers give Asian IG names +15 to +29 bp (China +165), currencies -4 to
  -8%, and +0.5 text stress. Putting the hand-built FX, spread and text shocks into the preset closes 14.4 of the
  17.0 gap at 20k paths (137.4 -> 151.7 vs 154.4). CHINA_HL's trigger add-ons are worth about 2; its China
  bank-crisis flag has no driver equivalent.
- OIL_SPIKE vs HORMUZ (-16.2). Same pattern. HORMUZ gives every non-commodity name +150 bp and -8% FX, IG Asia
  included, and +2 text stress everywhere. The drivers make IG Asian importers move +23 to +46 bp, because their
  oil bill is 2-5% of GDP and their level beta is at the 0.25 floor. Swapping in the hand-built FX, spread and
  text shocks gives 155.4 vs 155.9. The pillar 5 trigger is worth 0.4.
- REGIONAL_WAR vs TAIWAN (+9.2). The conflict channel alone gives 121.3, below TAIWAN; adding VIX +15 gives 145.4,
  and oil, dollar and China growth bring it to 161.8. TAIWAN gives non-Asian names +80 bp flat; the preset's risk-off
  hits high-spread names through the level beta (Zambia +446, Argentina +362) and China's slowdown hits copper.

Reading: the presets put more of the shock on high-spread and exposed names, and less on investment-grade Asia, than
the hand-built scenarios. On this book that lowers ES99 for the China and oil events and raises it for the Fed and
war events. Neither set is estimated. The level beta follows a documented regularity (EM spread changes scale with
the spread level); the flat hand-built shocks are simpler and more conservative for IG names. Which is closer to
history should be tested against TAPER13, FED22 and COVID20 market moves when the driver history is available.

## Severity scale and validation (review fixes, AGENT-04 / AGENT-09)

- Scale. `apply_shocks(..., scale=k)` on a `{"target": "macro"}` shock compiles the drivers x k, not the scale-1
  shocks x k. The compiled shocks carry the tag `macro_prescaled` and are applied at scale 1; other shocks in the
  same scenario keep the ordinary scaling and their order (`apply_with_prescaled` applies consecutive runs in turn).
  Before the fix, the conflict gate (intensity 0.5 and above) and the "High activity" `set` ignored the scale:
  REGIONAL_WAR at scale 0.25 flagged 12 positions, so reverse stress saw the whole step change at its first grid
  point. Now the flag appears from scale 0.5. Notches are rounded from the scaled spread move: FED_SHOCK with the
  notch rule at scale 3 moved ratings up to 5 notches before, now at most 3 (`notch_max`).
- `macro_scenario(...)` now returns a Scenario holding the one macro shock, so it goes through the same hook.
- Mixed scenarios, `settings` shocks on one key. A macro shock and a plain `settings` shock on the same key add up
  (an `add` adds to the other's result, a `mul` multiplies it), because compiled macro shocks are applied in a run
  of their own and the next run starts from the stressed settings. Two plain `settings` shocks on one key in the
  same run: the last one wins (each starts from the unstressed value), as before. The same holds for two macro
  shocks next to each other (one run). No shipped scenario mixes them.
- `macro_prescaled` is internal. A shock in scenarios.json, or passed to `apply_shocks`, that carries the key is
  refused with a ValueError (before EQ-B-0082 fix 2 it was applied at scale 1, ignoring the severity scale).
- Validation. `load_scenarios` (and `apply_shocks` at run time) raise a ValueError naming the scenario for an
  unknown or null preset, both or neither of `preset` / `drivers`, an unknown key, a driver that is not a finite
  number (strings, booleans, JSON NaN / Infinity), a driver outside its plausible range (below), a conflict region
  or epicentre that is not a string, and a `notch_rule` that is not a JSON boolean (`"false"` used to switch the
  rule on).
- Driver bounds (`DRIVER_BOUNDS`, inclusive). Generous: several times the largest historical move, so they stop
  typos and absurd values (oil_pct 1e308 gave infinite spreads), not severe scenarios.

  | Driver | Range | Largest historical move (approximate) |
  |---|---|---|
  | us_rate_bp | -2000 to 2000 | about +1,000 bp in a year (1979-81) |
  | usd_pct | -60 to 60 | about +/-20% a year (1985, 2014-15) |
  | china_gdp_pp | -40 to 40 | about -27 pp (1961); 2020 Q1 -6.8% y/y |
  | oil_pct | -100 to 1000 | +300% (1973-74), -75% (2008) |
  | conflict | 0 to 1 | an intensity |
  | vix_pts | -100 to 250 | about +70 points (12 to 82.7, 2020) |

  Scaled drivers (drivers x severity scale, which may pass the input range) are only checked against 10 x the
  largest bound magnitude of each driver (`SCALED_DRIVER_LIMIT`).

## Brief generator

`brief_table(drivers, countries, indicators, title=...)` returns a markdown table, worst spread move first: spread
(bp), FX (% weaker), growth (pp), commodity gap and the main channel, with a line saying the coefficients are
judgement. Scenario briefs are Team C's (`presentation/scenario_brief.py`); it can embed the table (handoff).

## Additions for AGENT-08 (items 1 and 2 applied 2026-10-24 and since changed to pass `scale`; item 3 awaits Sam)

1. `econquest/engine/stress.py`, `apply_shocks`, right after `shocks = expand_gpr_shocks(shocks, s, base_dir)`:

   ```python
       from .macro_scenarios import expand_macro_shocks
       shocks = expand_macro_shocks(shocks, u, base_dir)      # {"target": "macro"} -> ordinary shocks (EQ-B-0082)
   ```

2. `stress.py`, `summarise_shocks`: add `"macro": f"macro drivers {sh.get('preset') or sh.get('drivers')}"` to the
   `tgt` dict and `elif t == "macro": txt = f"{tgt} x{scale:.3g}"` before the `op == "add"` branch (without it a
   macro shock raises KeyError in the reverse-stress report).
3. `data/scenarios.json` (optional, changes the stress library outputs, not the base):

   ```json
   {"key": "MACRO_FED", "name": "Macro: Fed +200 bp, dollar and risk-off", "kind": "hypothetical", "source": "EQ-B-0082 driver preset FED_SHOCK (judgement coefficients)", "description": "Fed +200 bp, USD +8%, VIX +12 propagated per country through trade, financial and commodity exposures.", "shocks": [{"target": "macro", "preset": "FED_SHOCK"}]},
   {"key": "MACRO_CHINA", "name": "Macro: China slowdown", "kind": "hypothetical", "source": "EQ-B-0082 driver preset CHINA_SLOWDOWN (judgement coefficients)", "description": "China growth -3 pp, oil -20%, USD +3%, VIX +10 propagated per country.", "shocks": [{"target": "macro", "preset": "CHINA_SLOWDOWN"}]},
   {"key": "MACRO_OIL", "name": "Macro: oil +60%", "kind": "hypothetical", "source": "EQ-B-0082 driver preset OIL_SPIKE (judgement coefficients)", "description": "Oil +60%, VIX +8, USD +2%, Fed +25 bp, China -0.5 pp propagated per country.", "shocks": [{"target": "macro", "preset": "OIL_SPIKE"}]},
   {"key": "MACRO_WAR_ASIA", "name": "Macro: regional war in Asia", "kind": "hypothetical", "source": "EQ-B-0082 driver preset REGIONAL_WAR (judgement coefficients)", "description": "Conflict intensity 1 in Asia centred on China, VIX +15, oil +15%, USD +4%, China -2 pp propagated per country.", "shocks": [{"target": "macro", "preset": "REGIONAL_WAR"}]}
   ```

   Custom drivers: `{"target": "macro", "drivers": {"us_rate_bp": 100, "vix_pts": 5}, "notch_rule": false}`.

## Tests (`tests/test_macro_scenarios.py`, 41 tests)

Zero drivers give `[]` and an unchanged universe and settings; every preset compiles to a list `apply_shocks` accepts,
and the applied spread and FX moves equal the propagated ones; spread and FX moves, loading and equity vol are
monotone in driver severity and in the stress scale, and never change sign; the notch rule is off by default and
monotone when on; a SYNTHETIC 88-country universe (proposal names, random spreads and indicators) is covered
with every country taking its own move; a Middle East war, an unknown ISO3 and a table without an `iso` column
work; BIS contagion appears only when the exposure file exists (SYNTHETIC fixture); the `expand_macro_shocks` hook;
the brief table; every coefficient has a unit and source, and the exposure table matches the proposal's 88 ISO3.
Review fixes: the hook equals compiling drivers x scale (six scales); the "High activity" flag is off below 0.5 and
never shrinks; reverse stress with a stub metric breaches at scale 0.5 with a monotone path; notches at scale 3 match
the scaled spread and stay within 3; fifteen bad macro shocks are rejected at load and at run time.

## Limitations

- All coefficients and the exposure table are judgement. Nothing is estimated. The exposure table should be
  replaced by IMF DOTS / UN Comtrade data and the coefficients fitted on episode data (Fed 2013 and 2022, China 2015,
  oil 2022).
- One period, linear, no feedback: growth does not feed back into spreads beyond one step, and nothing is
  path-dependent.
- No BIS leg in the results above (no banking data in the repo yet).
- Country shocks are additive on the countries table. A country with no spread yet (the 70 staged names) keeps a
  blank spread; the move is still computed from the tier default level and shows in the brief.
