# Conflict escalation model: switch-on dossier (EQ-B-0142, PI-14)

Status: **OFF (Tier 3 research view).** Written 2026-10-26 by Team B AGENT-02. Method: `indicator-rules.md` section 25.
Code: `econquest/rules/escalation.py` (method `esc_ladder_v1`), `econquest/validation/escalation.py` (schema
`eq-escalation/1`). Tests: `tests/test_escalation_b142.py` (SYNTHETIC stores in tmp_path only). Data: Team A EQ-A-0139
unified event API (HO-20261026-A-B-015, `docs/runbooks/A-event-taxonomy.md` section 6).

## 1. What ships today

| Piece | State |
|---|---|
| Escalation rows | Built and tested. A five-rung ladder per desk name and anchor month (calm, tension, violent unrest, armed conflict, war) from GDELT media z and UCDP fatalities. Probabilities of a move up within 3 and 12 months come from an a priori monthly transition matrix, scaled by GDELT pressure and the 6.9 violence trend. Nothing is estimated |
| GPR / PD link | Display only. It shows the implied GPR shock and the PD that the existing GPR channel (4.10 uplift) gives under it. Both are computed on a temporary copy of the universe; the base run and every risk number are unchanged |
| Backtest harness | Built and tested on SYNTHETIC stores. It has two bases: knowledge (strict vintage time) and replay (secondary evidence). `capabilities()` says what can and cannot run. Today nothing can run: no event vintage is on the cloud disk, the Mac has three legacy GDELT pulls, and UCDP is missing |
| Real event data | The cloud disk is empty. Sam's Mac has three legacy GDELT vintages (protest and verbal_conflict only, about a week each). UCDP was never pulled because the token is not set (first-mac-pass A13) |
| Switch | `escalation.enabled` in `data/assumptions.json`. The key is absent, so the switch is off |
| Demo | `demo_escalation(out_dir, as_of)` reports the real capabilities. It then runs the method, the SYNTHETIC backtest and the PD link on a SYNTHETIC sandbox under `out_dir/escalation/`, and labels every row and file SYNTHETIC |

**No effect while off.**
- No module in engine, scorecard, presentation, ops, persistence, ingestion or the CLI imports
  `validation.escalation`. Team C's demo probe in `ops/demo.py` is the one exception, limited to `demo_escalation`,
  `switch_state`, `client_safe_rows` and constants (test `test_nothing_in_the_run_path_imports_the_escalation_model`).
- `run()` returns status `off` and reads and writes nothing.
- The PD link never writes to the universe it is given (test `test_pd_link_is_display_only_and_leaves_the_universe`;
  the demo also checks a fingerprint before and after).
- The 20k base was checked identical before and after the change: 66.95612571109443 / 89.00003057231508 /
  4.098636048964449 / 72.23763153780678.

**Even when on, it stays off the risk numbers.** Switching on lets `run()` and `python -m
econquest.validation.escalation run --as-of D --out outputs` write the internal research rows and the display-only PD
link to `outputs/escalation/`. Nothing feeds the scorecard, PDs, Monte Carlo, limits or publish. Feeding escalation
into a PD or a stress shock would be a separate Tier 1 card with an effect table.

## 2. Commands

```
python -m econquest.validation.escalation status
python -m econquest.validation.escalation capabilities --as-of 2026-10-23
python -m econquest.validation.escalation backtest --as-of 2026-11-30
python -m econquest.validation.escalation backtest --as-of 2026-11-30 --basis replay
python -m econquest.validation.escalation demo --out outputs --as-of 2026-10-23
```

Every command except `status` needs `--as-of`. No date is taken from the clock.

## 3. The a priori transition matrix (`rules.escalation.BASE_P`)

These are monthly probabilities, with rows "from" and columns "to". They are judgement and are not estimated. The
direct calm-to-armed-conflict entry is 0.0015 a month (about 1.8% a year on its own); with the paths through tension
and unrest, the chain's p_armed_12m from calm is 3.4%. The mean spells are about 20 months calm, 4 months
of tension, 5 months of unrest, 14 months of armed conflict and 25 months of war. Tension and unrest are short
because they are media z spikes against the country's own two-year base.

| from \ to | 0 calm | 1 tension | 2 unrest | 3 armed | 4 war | p_up 3m | p_up 12m | p_armed 12m |
|---|---|---|---|---|---|---|---|---|
| 0 calm | 0.9503 | 0.0400 | 0.0080 | 0.0015 | 0.0002 | 0.142 | 0.458 | 0.034 |
| 1 tension | 0.2000 | 0.7455 | 0.0500 | 0.0040 | 0.0005 | 0.131 | 0.291 | 0.059 |
| 2 unrest | 0.0400 | 0.1200 | 0.8130 | 0.0250 | 0.0020 | 0.069 | 0.159 | 0.159 |
| 3 armed conflict | 0.0050 | 0.0100 | 0.0400 | 0.9300 | 0.0150 | 0.042 | 0.129 | blank |
| 4 war | 0 | 0 | 0 | 0.0400 | 0.9600 | 0 | 0 | blank |

The fixed parameters are:
- the hazard multiplier M = min(4, exp(0.30 x pressure) x trend), with pressure the largest positive GDELT z at or
  above the current rung and trend = sqrt(6.9) clipped to [0.75, 2.0];
- the rung thresholds: GDELT z >= 2, UCDP 25 and 1000 fatalities over 12 months;
- 1.0 GPR sd per rung for the display link.

A calm country's p_up_12m (0.46) is mostly the chance of a tension spike (a GDELT z of 2 or more); p_armed_12m shows the
part that reaches armed conflict.

## 4. Pre-registered refit (written before any real data is seen; not run)

The model ships with fixed parameters. A refit is allowed only on real data, never on fixtures. It must use exactly
this specification, written on 2026-10-26 before any UCDP or GDELT category history was available.

| # | Item | Specification |
|---|---|---|
| P1 | Data | UCDP GED and Candidate monthly vintages, plus GDELT vintages saved with `--categories`, for every universe country. Unified API, `combine="by_source"`. States are classified by section 25 rules 1-3 unchanged |
| P2 | Time split | Fit on anchor months 2010-01 to 2019-12. Test on 2020-01 to 2025-12. The basis is replay, because the knowledge basis has no history before the first pull. The test window is never read while fitting |
| P3 | Estimator | (a) Transition matrix: monthly transition counts in the fit window plus a Dirichlet prior of 24 pseudo-months per row spread as BASE_P; the posterior mean is used. (b) BETA_PRESSURE: chosen from {0, 0.15, 0.30, 0.45, 0.60} by the fit-window log score of the 12-month outcome. Nothing else is fitted |
| P4 | Gate | On the test window, at 12 months: at least 20 events in at least 5 countries, AUC >= 0.70, and Brier skill above 0 against both BASE_P and the a priori model as shipped. If it passes, the refit replaces BASE_P through `econquest change` (Tier 3) with this table attached |
| P5 | One shot | The specification is run once. A change after the test window has been seen voids the refit, and the model stays a priori |

## 5. Evidence needed before the switch goes on

All of these must hold. AGENT-08 (Team B) collects them, and an independent reviewer (four-eyes, not the author)
signs.

| # | Evidence | Bar | Who |
|---|---|---|---|
| E1 | UCDP pulled | UCDP token in the Keychain and a UCDP vintage stored (first-mac-pass A13). `capabilities()` shows "rungs 3-4" can run | Sam (Mac), Team A |
| E2 | GDELT category vintages | GDELT pulled with `--categories` for at least 13 months, so rung 2 and the media z are observable. Legacy vintages see rungs 0-1 only | Team A |
| E3 | Backtest, knowledge basis | `backtest()` with `passes_bar` true (`SWITCH_ON_BAR`): at least 20 events at 12 months in at least 5 countries, AUC >= 0.70, Brier skill above 0 against the prior chain, UCDP present. This needs about 12 months of vintages saved after the first pull | Team B |
| E4 | Replay basis | `--basis replay`, shown next to E3 as secondary evidence only. It never sets `passes_bar`. It is the only evidence before the knowledge record exists | Team B, reviewer |
| E5 | Licence | The register's gdelt and ucdp rows (CC BY 4.0, GDELT terms, `terms_verified` yes; first-mac-pass D4) are read by Sam. Rows stay internal: `client_ok` is False for every row, and `client_safe_rows()` returns nothing. A client view would be a separate decision | Sam |
| E6 | PD link review | The reviewer reruns the PD link for 3 desk names by hand: the shocked CI series, the 4.10 uplift and the PD. They confirm that the base run is unchanged (20k pins) | Reviewer |
| E7 | Review | An independent reviewer reads `rules/escalation.py`, reruns `tests/test_escalation_b142.py` and the backtest, and checks the states of 10 country-months by hand. Findings are logged and closed | Reviewer (4.5) |
| E8 | Change record | The switch goes on through `econquest change` with an author and an approver (Tier 3 research view). The base stays bit-identical (20k check) | Sam, AGENT-08 |

**Known limits.**
- Without UCDP, armed conflict and war are not observable, so the state is a lower bound (status `partial`). Escalation
  into armed conflict cannot be labelled.
- Legacy GDELT shows only protest and verbal_conflict.
- A first pull stores the whole history on one day, so the strict knowledge record builds up only from then on (as for
  the text index).

## 6. Parked card for first-mac-pass section B (for the lead; not posted)

> | D-next | Conflict escalation model (EQ-B-0142, docs/validation/conflict-escalation.md): keep it off; pull UCDP (A13 token) and GDELT with `--categories` in the Mac pass so the ladder can see armed conflict, then decide switch-on on evidence E1-E8; a refit only by the pre-registered split (section 4); the GPR/PD link stays display only | Keep off until UCDP is pulled and 12 months of category vintages exist; no PD feed | optional |

Signing terms: the switch stays off, so no risk number moves. Switching on later is a Tier 3 `econquest change` on
`assumptions.json` `escalation.enabled`, with evidence E1-E8 attached. There is no effect table because the base does
not move. Any feed into PDs or stress would be a new Tier 1 card with an effect table.

## 7. Output schema `eq-escalation/1`

**Escalation rows** (`ESC_COLUMNS`). There is one row per desk name at as_of.

| Column | Meaning |
|---|---|
| country, iso | Desk name (countries.csv) and ISO3 |
| as_of, anchor_month, data_month | Knowledge cut; last complete month at as_of; newest month the state read |
| basis | `knowledge` for real runs, `replay` only in the labelled backtest |
| state, state_name | 0 calm, 1 tension, 2 violent_unrest, 3 armed_conflict, 4 war (blank when not classified) |
| state_max_observable, state_basis | Highest rung the data can show (4 UCDP, 2 GDELT categories, 1 legacy GDELT); the rule that set the state |
| z_verbal_conflict, z_protest, z_coercion, z_armed_conflict_media, z_violence_against_civilians_media | GDELT media z at the data month (blank when not scored) |
| ucdp_fatalities_12m | UCDP fatalities, armed_conflict plus violence_against_civilians, over the 12 months (UCDP only) |
| violence_trend_6_9, trend_factor | 6.9 ratio (section 7) and sqrt of it clipped to [0.75, 2] (1 when blank) |
| pressure, hazard_mult | Largest positive GDELT z at or above the rung; M = min(4, exp(0.30 pressure) x trend) |
| p_up_3m, p_up_12m | Probability of being above the current state at some month within 3 or 12 months |
| p_armed_12m | The same for state 3 or higher; blank at state 3 and above |
| p_up_12m_prior | p_up_12m on the unmodulated matrix |
| expected_jump, gpr_shock_sd_if_up, gpr_shock_sd_expected | Expected rungs gained on a move up; implied GPR shock in sd (1 sd per rung); p_up_12m times that shock |
| status | `value`, `partial` (rungs above the observable max unseen; lower bound), `insufficient`, `stale` or `empty` |
| method, sources | `esc_ladder_v1`; sources read (gdelt, ucdp) |
| licence_class, client_ok, synthetic, note | Licence class (section 25 rule 9); always False; SYNTHETIC fixture flag; reasons and labels |

**PD link rows** (`PD_LINK_COLUMNS`, display only). There is one row per escalation row with a probability.

| Column | Meaning |
|---|---|
| gpr_channel, gpr_series | `ci` (the country has a Caldara-Iacoviello series) or `none` (no GPR channel, so no PD effect) |
| p_up_12m, gpr_shock_sd_if_up | From the escalation row |
| z_base, z_if_up, percentile_base, percentile_if_up | run_gpr statistics on the base and the shocked temporary copy |
| uplift_base, uplift_if_up, final_410_base, final_410_if_up | The 4.10 uplift (0, 1 or 2) and the 4.10 value |
| pd_default_base, pd_default_if_up, pd_default_expected, d_pd_default_bp | Base PD, PD under the shock, the p_up_12m mixture, and the difference in bp |
| pd_any_base, pd_any_if_up | Any-peril PD (the sanctions peril also reads 4.10) |
| display_only, licence_class, client_ok, synthetic, note | Always True; at least restricted; always False; fixture flag; notes |
