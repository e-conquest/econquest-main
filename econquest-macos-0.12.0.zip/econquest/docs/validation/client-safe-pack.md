# Client-safe research pack (EQ-B-0130)

`econquest/validation/client_safe_pack.py` builds the MVP research pack (notes, scenario briefs, weekly brief, trade
ideas, house view; [mvp-research-pack.md](mvp-research-pack.md)) from a client-safe dataset. It runs the same checks
as the house pack plus client-safe checks, and writes a side-by-side gap report against the house pack.

Client mode stays off. research.json is the house file, mode internal, and every product keeps the INTERNAL RESEARCH
banner. The packs are client-safe drafts for review, not client output. The house pack (outputs/reports/mvp), the
house base and data/mvp are only read.

## Commands

```
# Team A's dataset (EQ-A-0124): one working copy per D3 answer
python -m econquest.ingestion.client_safe_dataset verify --d3 both
python -m econquest.validation.client_safe_pack stage --variant outputs/client_safe_dataset/d3_yes
python -m econquest.validation.client_safe_pack stage --variant outputs/client_safe_dataset/d3_no
python -m econquest.validation.client_safe_pack build --data outputs/client-safe-data/d3_yes/data \
    --out outputs/reports/client-safe/d3_yes --house outputs/reports/mvp --as-of 2026-10-23 --allow-unapproved-register
python -m econquest.validation.client_safe_pack build --data outputs/client-safe-data/d3_no/data \
    --out outputs/reports/client-safe/d3_no --house outputs/reports/mvp --as-of 2026-10-23 --allow-unapproved-register
python -m econquest.validation.client_safe_pack gap-variants --house outputs/reports/mvp \
    --pack d3_yes=outputs/reports/client-safe/d3_yes --pack d3_no=outputs/reports/client-safe/d3_no
python -m econquest.validation.client_safe_pack check --out outputs/reports/client-safe/d3_yes --allow-unapproved-register

# before A-0124 landed: interim copy from data/mvp made by validation/client_safe.py (internal only)
python -m econquest.validation.client_safe_pack prepare --from data/mvp/data --as-of 2026-10-23 --allow-unapproved-register
```

`--allow-unapproved-register` is needed while data/licences.csv has no approved version (Sam's R44 baseline). It marks
everything built as internal analysis.

## Dataset

Team A's variants (outputs/client_safe_dataset/d3_yes and d3_no, HO-20261026-A-B-005) are the output of
`client_safe.build_client_safe_copy`, with every withheld cell removed or replaced and the restricted files left out.
That is enough for the engine run, but the products need three more things. `stage` adds them to a working copy and
leaves Team A's folder untouched:

- **Licence register.** The variant's simulated register (`licences_d3_yes.csv` / `licences_d3_no.csv`) becomes the
  copy's licences.csv, so the attribution and enforcement follow that D3 answer.
- **Desk configuration.** The house `desk_config` files are copied back: research.json, compliance.json, users.json,
  distribution.json, publication_calendar.json, resilience.json and approvals/. They hold no third-party values.
- **Audit trail.** The house audit_trail.csv is copied without the rows of withheld cells. Replaced cells have no
  audit row, so their sources are not attributed. Team A's provenance.csv carries those cells' labels (open item).
- **Desk text.** `rewrite_client_text` rewrites the restricted source names in the copy's playbook.csv and
  scenarios.json (CLIENT_TEXT_REWRITES):
  - T18 "Cruces-Trebesch haircuts" becomes "historical restructuring haircuts";
  - T12 "near ACLED hot spots" becomes "near political-violence hot spots";
  - "IMF WEO ..." and "IEA/IMF range" in the scenario sources are reworded;
  - "IMF DOTS" in the propagated-scenario descriptions is reworded.

  Only free text may change. The rewrite is refused, and the file left as it was, if the table or JSON shape, a key,
  a non-string value or a number inside a changed string would change. Each change is listed in the marker under
  `text_rewrites`.
- **Marker.** `client_safe.json` is written with the variant, the D3 answer, Team A's dataset_sha256 and the counts.

The DSA reads IMF WEO, so a client-safe folder has no WEO pull and `mvp_pack.run_inputs` skips the DSA there
(`has_weo_pull`). The notes and briefs show the DSA as not available.

**Run folder.** The engine's DSA hook reads `dsa.data_dir` ("data") and `dsa.inputs_path` ("data/dsa_inputs.csv")
relative to the current directory. A client-safe run started from the repo root therefore computed signal 26 from
the shared data/ IMF WEO, and the house and client values were the same. `build_client_pack` now runs every
subcommand from the dataset root (`mvp_pack.build_pack(run_cwd=...)`, with the repo on PYTHONPATH), so "data" there
is the client-safe copy. The house pack is built without run_cwd and is unchanged. The check fails a run that carries
signal 26 when its folder has no WEO pull.

**Placeholder debt / GDP.** Team A writes a judgement placeholder for a withheld Inputs 1.3: the rulebook midpoint
t50 (60.0) before Update 4, the worst score t100 (100.0) since (`stress_placeholders`). In a folder with the marker, `house_view` blanks debt_gdp for those names in house_view.json and peers.csv, and adds the warning
"placeholder (withheld: licence): debt / GDP left blank". The record lists them under `placeholders.debt_gdp`. The
stance does not change. A house folder has no marker, and nothing changes there.

## Checks (`check_client_pack`)

The pack must pass every `mvp_pack.check_pack` check (stamps, numbers equal to the run, house view, disclaimer,
licence block), plus the following.

| Check | Rule |
|---|---|
| Dataset | `client_safe.json` present; `client_safe.withheld_cells` and `ops.licence_rule.evaluate` find 0 internal-only cells; every source in use is client_ok=yes with attribution text; no file in the folder belongs to an IMF, EXC-005 or Yahoo register row; prices.csv has none of the EXC-005 columns; no audit row names an IMF series in series / transform (`imf_series_cells`). |
| Provenance | No countries.csv / indicators.csv cell equals (1e-6 relative) a provenance record (live/provenance.csv and its vintages, source and shared folder) whose source or series the register keeps out of client output (`restricted_by_provenance`). This finds EXC-005 fx3m cells whose audit row only says "econquest full fetch". |
| Run | The run carries no DSA signal 26 when the folder has no WEO pull (`dsa_signal_problems`). |
| Label | Every HTML product has `data-client-safe="draft"` and the text "CLIENT-SAFE DRAFT". The notes and briefs manifests carry `client_safe`. Team C renders these (HO-20261026-B-C-005). |
| Attribution | Every product's licence block has attribution lines, no internal-only list, and no line from a restricted register row. A source whose data file the folder holds and the product names (`file_sources_in_use`, for example gpr_monthly.csv for the Caldara-Iacoviello GPR) has its attribution line. |
| Restricted sources | No product names WEO, World Economic Outlook, an IMF data series, theratesapi, Yahoo or GOOGLEFINANCE, or the name of any register row that is not allowed (`restricted_name_patterns`: each row's match_source, plus short names such as ACLED, GOCI, WJP, ND-GAIN, Global Terrorism Index, IPC phase, Cruces-Trebesch). An institutional fact ("IMF programme", "IMF review", "IMF deal", "IMF board", "IMF staff-level") is allowed. |
| Restricted values | A country's note never shows, at 1 or 2 decimals, the house value of one of that country's withheld cells (only values of 10 or more, and only where the client-safe value differs). |

Register problems that only Sam can clear are listed as information, not problems: no approved register (R44), and
the register not under change control. Client output stays refused until then.

## Gap report

Each pack has `gap/gap.json`, `gap.md` and `gap.csv`. `gap-variants` writes one report for both D3 answers to
outputs/reports/client-safe/gap/. It covers:

- base metrics (EL, VaR95/99, ES95/99, liquidity cost, L-VaR99);
- PD, composite and regime per name;
- house stance changes;
- trade ideas that drop, are added or flip (alignment or house stance), or whose strength moves by more than 5 points.

The house numbers use IMF (EXC-003) and theratesapi.com (EXC-005) data, so the gap report is INTERNAL and never part
of a product. A client-safe pack is client-safe only when its own check passes. The variant report lists each pack's
check status (PASS, FAIL or not checked, from its client_check.json for the same run) and whether every pack was
built on the same code hash.

## Results, 2026-10-26 (as of 2026-10-23, 131,072 paths)

**Current: final build after AGENT-07's review (HO-20261026-B-B-004, F1 to F4) and Team C's EQ-C-0153
(HO-20261026-B-C-010).** Both packs were built once, on code hash 5ee8b3563b8a2b7a, from Team A's Update 4 variants (HO-20261026-A-B-005 / -A-B-008):

- d3_yes: sha 19bdc818, 524 cells withheld;
- d3_no: sha 8e7a8979, 555 cells withheld.

The variants have:

- the stressed fx3m placeholder (30.0) for the five EXC-005 currencies (Vietnam, Pakistan, Venezuela, Nigeria and
  Zambia; Belize, a USD peg, is not withheld);
- the rulebook worst score t100 for required cells with no cleared value (5.5 at the hyperinflation floor);
- 0.5% of GDP for reserves;
- the 39 unmatched full-fetch records (2.9, 3.4, 3.5) failing closed.

The numbers are much higher than the house because the placeholders are stressed by design (client-safe-run.md
sections 3a to 3c). They are research drafts, not a client-safe view of the house risk.

| | house (run 20261026T004819) | d3_yes (run 20261026T094259) | d3_no (run 20261026T094548) |
|---|---:|---:|---:|
| VaR99 / ES99 / EL / L-VaR99 ($mm) | 66.21 / 87.91 / 4.01 / 71.49 | 112.92 / 133.24 / 12.11 / 120.09 | 115.04 / 135.65 / 12.37 / 122.21 |
| house stance changes | | 2 (Vietnam Constructive -> Defensive, Brazil Defensive -> Neutral) | 2 (the same) |
| ideas dropped / added / flipped / strength moves | | 25 / 48 / 6 / 19 | 26 / 47 / 7 / 16 |

`client_safe_pack check` PASSES on both packs: 0 problems, 34 HTML files labelled and attributed. Team C's EQ-C-0153
added:
- the GPR (Caldara-Iacoviello) and CRAG attribution lines;
- generic indicator labels in client-safe mode;
- "withheld: licence" and "placeholder (withheld: licence)" in the data coverage;
- "withheld: licence" for placeholder debt in the peer table.

The information lines are Sam-gated only: the register is not approved, and the variant is internal only. There are no dataset problems, no value leaks and no signal 26. Two value-scan coincidences are listed for review:
Malaysia's pillar score 69.2 and Singapore's composite 47.3 in South Korea's peer table. Each pack has drafts
ed-20261026-0001..0032 in its own ledger, sent to AGENT-07 for re-review in HO-20261026-B-B-005.

D3 "no" against "yes": the book is higher under "no" (EL 12.37 against 12.11, VaR99 115.04 against 112.92). Seven
names have a lower PD under "no": Argentina, Vietnam, Malaysia, Pakistan, Zimbabwe, Belize and South Korea. The largest
falls are Argentina (11.89% against 15.48%, -23.2%) and Zimbabwe (85.46% against 96.24%, -11.2%). gap.md lists every
such name with both PDs and the relative change (`d3_no_lower_names`).

**Known effect: layer 1 universe calibration, accepted for internal draft 2026-10-26, not cleared for client output.**
This is the same mechanism as the earlier build, now larger with the t100 placeholders. The coordinator accepted it as
a Tier 2 decision by the Team B lead because:
- both packs are internal (client mode off);
- the book EL and VaR99 are higher under d3_no.

The code is unchanged. The fix question (holding layer 1 calibration at the house fit in client-safe runs, a Tier 1
method change) is parked for Sam's client go-live.

### Earlier build (superseded; Team A shas c0c1e963 / d96e27ac)


Team A rebuilt the variants under the reopened EQ-A-0124:

- d3_yes: sha c0c1e963, 480 cells withheld;
- d3_no: sha d96e27ac, 483 cells withheld.

The withheld cells now include every WEO cell found through `transform` (HO-20261026-B-A-005) and indicator 1.6. The
reserves placeholder is 0.5% of GDP, the stressed end (AGENT-06; client-safe-run.md section 3a). Team C's EQ-C-0151
added the CLIENT-SAFE DRAFT label, the manifest `client_safe` entry and the DSA line "n/a: DSA not available in the
client-safe dataset".

`client_safe_pack check` passes on both packs. Its only information lines are Sam-gated: the register is not approved,
and the variant is internal only. All 34 HTML files are labelled and attributed, and 60 withheld cells were scanned.

| | house (run 20261026T004819) | d3_yes (run 20261026T072912) | d3_no (run 20261026T073930) |
|---|---:|---:|---:|
| VaR99 / ES99 / EL / L-VaR99 ($mm) | 66.21 / 87.91 / 4.01 / 71.49 | 72.53 / 93.48 / 4.02 / 77.82 | 72.52 / 93.41 / 4.16 / 77.81 |
| house stance changes | | 2 (Japan Neutral -> Constructive, Brazil Defensive -> Neutral) | 2 (the same) |
| ideas dropped / added / flipped / strength moves | | 24 / 10 / 10 / 10 | 24 / 10 / 10 / 10 |

D3 "no" against "yes":

- **Expected loss** is higher (4.16 against 4.02 $mm), and Senegal's PD is higher (12.60% against 9.62%) because its
  reserves are now the 0.5 placeholder.
- **Zimbabwe and Venezuela** are about the same (Venezuela is at the 99% cap).
- **The other 15 names** are 1 to 5% lower in relative terms (for example Argentina 9.39% against 9.52%).

**Known effect (accepted by the coordinator, 2026-10-26).** Under D3 "no", the book's expected loss (4.16 against
4.02 $mm) and the names with the reserves placeholder (Senegal 12.60% against 9.62%; Zimbabwe 89.79% against 89.78%;
Venezuela at the 99% cap in both) are at or above D3 "yes". This is the property the placeholder rule needs. The
other 15 names come out 1 to 5% lower in relative terms (for example Argentina 9.39% against 9.52%, Pakistan 8.14%
against 8.29%). This is documented engine behaviour, not a placeholder that flatters: layer 1 calibrates the whole
universe to rating priors, so a higher hazard for one name moves the others slightly down. The old 15% placeholder
showed the same mechanism in the other direction. No change to the engine or the placeholder follows from it.

The full tables are in outputs/reports/client-safe/gap/gap.md (internal). Each pack has 32 editorial drafts in its own
ledger (ed-20261026-0001..0032), sent for review to AGENT-07 in HO-20261026-B-B-004.
