# Model validation: Layer 2 Bayesian log-odds update

Date: 2026-10-23. Code: `econquest/engine/layer2_bayesian.py` (`posterior`, `market_implied_pd`,
`default_contract_prior`, `blend_with_market`). Parameters: `data/assumptions.json` keys
`probability` and `prediction_markets`. Status: formula follows the paper's section 3.2; all weights
are judgement, the text signal is zero everywhere and the prediction-market prices are illustrative
placeholders. EQ-B-0021 (2026-10-23) added a risk-premium adjustment on the spread-implied PD (GOV-013) and a
per-regime weight on the FX term (GOV-015). Sam approved values on 2026-10-23 (Tier 1, change
CHG-20261023T163209Z-b3f8bd, release 0.1.3): `risk_premium_ratio 2.0` (SD/D exempt), `w_fx_regime_scale` Peg and
Dollarized 0.0 (Float, Managed, default 1.0); `w_m` unchanged at 0.5. Independent review pending.

## Purpose

Layer 2 updates the Layer 1 prior with four observable signals (scorecard deviation, market-implied
PD gap, 3-month depreciation and a text stress index) in log-odds space, and then blends the result
with the 12-month-equivalent probability implied by sovereign-default prediction-market contracts,
weighting the contract by its open interest. The output `pd_final` is, after the regime multiplier,
the 12-month default probability used in the Monte Carlo and the dashboard.

## Where it sits in the pipeline

`run_pipeline`: `post = L2.posterior(u, settings, l1["pd_model"], sc.composite)`, then `prior =
L2.default_contract_prior(u, settings)`, then `p_final = L2.blend_with_market(post, prior,
settings)`. The country table gets `pd_final` and `pd_default = min(0.99, pd_final * pd_mult)` with
`pd_mult` from Layer 3. `pd_model` (the column, not the Layer 1 output) is `pd_post * pd_mult`, the
regime-adjusted PD before the market prior, used for the `pm_gap_pp` diagnostic.

## Assumptions

1. Posterior log-odds: `logit(p_post) = logit(p_model) + w_s (S - S_bar) + w_m z_cds + w_fx z_fx +
   w_t z_tsi` with `score_centre 45.8`, `w_s 0.04` per composite point, `w_m 0.5`, `w_fx 0.1`, `w_t
   0.25`.
2. `z_cds = logit(pd_market) - logit(p_model)`, where `pd_market = clip(spread_bps / 1e4 /
   lgd_market_implied, 1e-4, 0.95)` with `lgd_market_implied 0.6`. This is the constant-hazard
   approximation PD = spread / LGD. Because `z_cds` is a log-odds gap, `w_m = 0.5` places the
   posterior halfway between model and market in log-odds before the other terms.
2b. Risk-premium adjustment (EQ-B-0021, GOV-013). `pd_market` above is a risk-neutral PD: spreads pay
   for expected loss and for bearing default risk. The market term now uses `pd_market_phys =
   clip((spread / 1e4 / lgd_market_implied) / risk_premium_ratio, 1e-4, 0.95)`, i.e. the risk-neutral
   default intensity divided by the ratio of risk-neutral to physical intensity, and `z_cds =
   logit(pd_market_phys) - logit(p_model)`. The ratio divides the uncapped intensity (Venezuela: 1.0 / 2
   = 0.5, not 0.95 / 2). Countries rated in `risk_premium_exempt_ratings` (`["SD", "D"]`) keep ratio 1:
   once a sovereign is in default the spread prices recovery, not the likelihood of default.
   `pd_market` (risk-neutral) is still returned and is what the PD Benchmarks tab calls "spread-implied";
   `pd_market_phys` is a new column of `posterior()` (also in the run's country table). `risk_premium_ratio 1.0` means no adjustment; the shipped value is 2.0 (0.1.3).
   Value range: the literature finds risk-neutral default intensities well above physical ones. For
   corporates, Driessen (2005, RFS) estimates an average ratio near 2; Berndt, Douglas, Duffie, Ferguson
   and Schranz (2005; 2018 update) find CDS-implied to EDF ratios that average around 2 and swing widely
   over time; Hull, Predescu and White (2005) find ratios that fall with credit quality, large for
   investment grade and roughly 1.5 to 3 for single-B and below. For EM sovereigns, Remolona, Scatigna and Wu
   (2008, Journal of Fixed Income) attribute most of the spread to the risk premium rather than expected
   loss. A ratio of roughly 1.5 to 3 for the high-yield sovereigns that drive this book is a
   literature-based judgement, not an estimate from econquest data; the citations are from memory and
   were not re-checked offline. A single ratio understates the adjustment for investment-grade names and
   may overstate it for near-default names; a rating-bucketed ratio is the obvious refinement once
   licensed CDS and outcome data exist.
3. `z_fx = fx3m / 5`, the 3-month depreciation in 5-point units, standing in for the FX implied-vol
   skew the paper uses. EQ-B-0021 (GOV-015): the term is `w_fx * w_fx_regime_scale[fxregime] * z_fx`,
   with `fxregime` from `countries.csv` (snapshot values Float, Managed, Peg; the scorecard also knows
   Dollarized) and `w_fx_regime_scale.default` for any regime not listed. Default 1.0 for every regime (no
   change). Rationale for a lower peg weight: under a hard peg the 3-month move against the dollar is the
   anchor currency's move (Senegal's XOF moves with EUR/USD, +4.5 percent in the snapshot), not a
   depreciation the sovereign chose or suffered; for dollarised economies there is no own currency. Stress
   on a peg shows up in reserves (`res3m`), the parallel premium and the spread, which are already in the
   scorecard and the market term. Managed regimes keep weight 1: their realised moves are policy signals.
4. `z_tsi = textz` from the Country Profile, a text stress index z-score. It is 0 for all 18
   countries in the snapshot. EQ-B-0033 (GOV-014): with `probability.text_index.source "events"` the term
   becomes `textz + event index`, a per-country UCDP/GDELT stress z-score against the country's own
   trailing five years, point in time (`engine/event_index.py`; method, weights, backtest harness and
   fixture effect in `event-index.md`). The default `source "none"` keeps `z_tsi = textz` bit for bit;
   `posterior` also returns `z_event` (0 when off) and `event_flag` (`off`, `ok`, `partial`,
   `insufficient`, `missing`).
5. Prediction-market prior: for each sovereign-default contract with a price, `p12 = 1 - (1 -
   price)^(12 / months)` converts the price over the contract horizon to a 12-month probability
   under a constant hazard (`to_12m`); months are computed from today's date to the resolution date,
   floored at 0.5. Contracts on the same country are averaged by open interest. `tau_market =
   tau_market_max * min(1, oi / reference_oi_k)` with `tau_market_max 1.0` and `reference_oi_k 500`.
6. Blend: `logit(p_final) = (tau_model logit(p_post) + tau_market logit(pm_default)) / (tau_model +
   tau_market)`, `tau_model 1.0`. Countries without a contract keep `p_post`. The switch
   `use_market_prior true` enables the blend.

## Data

- `spread` (bps), `fx3m` (percent), `textz` from `countries.csv`. Spreads are hand-entered
  (Venezuela 6000, Zimbabwe 3000, Senegal 1200, Argentina and Belize 650, Pakistan and Zambia 450,
  Nigeria 400, Colombia 220, Brazil 160, Vietnam 100, others 15 to 70). The roadmap (item 1.3) notes
  that CDS and EMBI spreads need a licensed source; today they are analyst estimates with no
  vintage. `fx3m` was live from Yahoo Finance in the 2026-10-23 pull; from the next pull it comes from BIS WS_XRU / ECB EXR reference rates (EQ-A-0040, same definition) (South Korea -10.2, Venezuela
  +20.1, Zambia +8.4, Zimbabwe +8.0).
- `textz` is zero everywhere, so `w_t` has no effect (confirmed: the `prob_w_t_0` and `prob_w_t_0.5`
  runs reproduce the base exactly). The event index (EQ-B-0033) is built and off; it waits on the Team A
  UCDP and GDELT adapters (EQ-A-0022, EQ-A-0023, contract HO-20261023-B-A-004). Its only evidence so far
  is a synthetic fixture (see `event-index.md`).
- `prediction_markets.csv`: 18 contracts, five on sovereign default (Argentina PM01 price 0.18 OI
  250k, Pakistan PM08 0.12 OI 90k, Senegal PM10 0.40 OI 45k, Zambia PM11 0.10 OI 30k). The README
  states the prices are illustrative placeholders; `--live-markets` fetches Polymarket and Kalshi
  only when the contracts carry a slug or ticker, which they do not.

## Estimation or calibration

None. Every weight in `probability` and `prediction_markets` is a judgement carried over from the
workbook's Assumptions tab. The paper gives the functional form but no fitted values for these
weights. The constant-hazard conversion and the open-interest scaling of `tau_market` are modelling
conventions, not estimates.

## Outputs and how they are used

Base run (2026-10-23), selected countries, percent:

| Country | pd_model (L1) | pd_market | z_cds | score_dev | pd_post | pm_default | tau | pd_final | pd_default |
|---|---|---|---|---|---|---|---|---|---|
| Argentina | 2.13 | 10.8 | 1.72 | +10.4 | 7.58 | 15.4 | 0.50 | 9.67 | 11.9 |
| Pakistan | 2.34 | 7.5 | 1.22 | +20.7 | 9.18 | 10.2 | 0.18 | 9.34 | 11.5 |
| Senegal | 4.02 | 20.0 | 1.79 | +10.7 | 14.6 | 52.7 | 0.09 | 16.7 | 23.9 |
| Zambia | 1.75 | 7.5 | 1.52 | +5.1 | 5.23 | 8.5 | 0.06 | 5.38 | 6.6 |
| Zimbabwe | 9.56 | 50.0 | 2.25 | +28.7 | 54.6 | none | 0 | 54.6 | 78.4 |
| Venezuela | 37.7 | 95.0 | 3.45 | +38.5 | 95.9 | none | 0 | 95.9 | 99.0 |
| Brazil | 1.05 | 2.67 | 0.95 | -2.6 | 1.49 | none | 0 | 1.49 | 1.56 |
| Singapore | 0.09 | 0.25 | 1.04 | -24.6 | 0.05 | none | 0 | 0.05 | 0.06 |

`pd_final` drives `pd_default`, the expected loss `el_default`, the Monte Carlo default thresholds
for Eurobond, local-bond and CDS positions, signals 15, 16 and 19, and the arbitrage pricing of
sovereign-default contracts.

## Limitations and known gaps

- The market term dominates. `z_cds` is positive for every country (0.80 to 3.45), so with `w_m =
  0.5` the update always raises PDs, by 0.4 to 1.7 log-odds. Half of the final PD is therefore the
  hand-entered spread divided by an assumed 60 percent LGD. There is no risk-premium adjustment:
  spread-implied PDs are known to overstate physical PDs, often by a factor of two or more for
  investment-grade sovereigns.
- The contract horizon depends on the run date. `default_contract_prior` and `arbitrage_scan` use
  `pd.Timestamp.today()`, so the same data produce different `pm_default`, `pd_final` and edges on
  different days (Senegal PM10: 0.40 over 8.2 months gives 52.6 percent; the same price over 7
  months would give 58.3 percent). Two runs with identical code and data hashes can disagree, which
  weakens the versioning guarantee in `versioning.py`.
- Prediction-market prices are placeholders, so `pm_default`, `tau_market` and everything in the
  arbitrage table are illustrations.
- The text index is zero for all countries; the fourth signal is inert until roadmap item 1.4 or 3.5
  delivers it.
- `w_fx` applies to realised depreciation, not to the implied-vol skew the paper specifies. Pegs and
  dollarised regimes can now be down-weighted (`w_fx_regime_scale`, EQ-B-0021) but the shipped weight is
  still 1.0 pending Sam's decision.
- The risk-premium ratio is a single number for all non-defaulted names (default 1.0, no adjustment); it
  is judgement from the literature, not estimated.
- The blend is a precision-weighted average, but neither `tau_model` nor `tau_market` is a measured
  precision. With `reference_oi_k 500` no contract in the file reaches full weight (the largest
  default contract has 250k).
- `pd_market` is capped at 0.95, so Venezuela's 6000 bps maps to 0.95 and the cap, not the spread,
  sets its posterior.

## Sensitivity

20,000 Sobol paths; production uses 100,000. PDs are 12-month `pd_default` after the regime
multiplier.

| Variant | VaR99 $mm | ES99 $mm | Mean PD | Argentina | Pakistan | Senegal | Zambia | Zimbabwe |
|---|---|---|---|---|---|---|---|---|
| Base (`w_s 0.04, w_m 0.5, w_fx 0.1, LGD 0.6`) | 65.98 | 87.05 | 0.1387 | 0.119 | 0.115 | 0.239 | 0.066 | 0.784 |
| `w_m 0` (no market term) | 60.20 | 80.68 | 0.0986 | 0.070 | 0.071 | 0.116 | 0.033 | 0.404 |
| `w_m 0.25` | 62.75 | 83.77 | 0.1167 | 0.091 | 0.091 | 0.168 | 0.047 | 0.584 |
| `w_m 1` (market replaces model) | 72.76 | 93.24 | 0.1833 | 0.196 | 0.181 | 0.448 | 0.128 | 0.990 |
| `w_s 0` | 65.16 | 87.21 | 0.1078 | 0.092 | 0.060 | 0.171 | 0.055 | 0.396 |
| `w_s 0.02` | 65.60 | 86.90 | 0.1221 | 0.105 | 0.083 | 0.203 | 0.060 | 0.580 |
| `w_s 0.08` | 67.17 | 86.80 | 0.1645 | 0.152 | 0.211 | 0.328 | 0.079 | 0.990 |
| `w_fx 0` | 65.66 | 86.97 | 0.1340 | 0.115 | 0.115 | 0.223 | 0.057 | 0.727 |
| `w_fx 0.3` | 66.22 | 87.01 | 0.1482 | 0.126 | 0.115 | 0.274 | 0.089 | 0.895 |
| `w_t 0` or `0.5` | 65.98 | 87.05 | 0.1387 | unchanged (textz is 0 everywhere) | | | | |
| `lgd_market_implied 0.4` | 67.91 | 88.73 | 0.1574 | 0.137 | 0.136 | 0.293 | 0.081 | 0.970 |
| `lgd_market_implied 0.8` | 64.94 | 85.64 | 0.1287 | 0.108 | 0.102 | 0.209 | 0.058 | 0.693 |
| `use_market_prior false` | 65.98 | 86.91 | 0.1354 | 0.093 | 0.113 | 0.210 | 0.064 | 0.784 |
| `tau_market_max 3` | 66.18 | 87.36 | 0.1433 | 0.144 | 0.117 | 0.292 | 0.069 | 0.784 |
| `reference_oi_k 100` | 66.22 | 87.49 | 0.1455 | 0.134 | 0.119 | 0.337 | 0.072 | 0.784 |

Reading: `w_m` is the single most important probability parameter in the program; from 0 to 1 it
moves the mean PD from 9.9 to 18.3 percent and VaR99 by 21 percent. `w_s` matters most for Pakistan
(composite 66.5, 20.7 points above centre). The prediction-market prior changes Argentina and
Senegal by 2 to 3 points at current open interest and would matter more if `reference_oi_k` were
lowered. The book tail is less sensitive than the PDs because Venezuela is capped and market moves
dominate the tail.

### EQ-B-0021 recalibration evidence (2026-10-23)

`run_pipeline(paths=20000, as_of="2026-10-23")` (Sobol rounds to 32,768 paths), `settings.copy_with`,
current tree. `pd_default` in percent, after the regime multiplier; "mean dlogodds" is the mean change of
`logodds_post` across the 18 countries against the base. EL is the Monte Carlo mean loss of the whole book
(market P&L included), so it can be negative.

| Variant | VaR99 $mm | ES99 $mm | EL $mm | Mean PD | Mean dlogodds | Largest PD moves (pp, from base) |
|---|---|---|---|---|---|---|
| Base (`w_m 0.5`, ratio 1, FX scale 1) | 68.54 | 87.42 | 1.855 | 0.1384 | 0 | - |
| `w_m 0.35` | 65.95 | 85.60 | 1.072 | 0.1248 | -0.222 | Zimbabwe 78.4->66.3, Senegal 23.6->19.1, Argentina 11.9->10.2, Pakistan 11.5->9.9, Belize 7.1->5.6 |
| `w_m 0.25` | 64.43 | 84.15 | 0.623 | 0.1165 | -0.369 | Zimbabwe 78.4->58.4, Senegal 23.6->16.6, Argentina 11.9->9.2, Pakistan 11.5->9.0, Belize 7.1->4.8 |
| `w_m 0.05` (rating-anchored, see below) | 61.48 | 81.56 | -0.119 | 0.1017 | -0.665 | Zimbabwe 78.4->43.7, Senegal 23.6->12.3, Argentina 11.9->7.4, Pakistan 11.5->7.5, Belize 7.1->3.5 |
| `w_m 0` | 61.27 | 80.88 | -0.262 | 0.0985 | -0.739 | Zimbabwe 78.4->40.4, Senegal 23.6->11.4, Argentina 11.9->7.0, Pakistan 11.5->7.1, Belize 7.1->3.2 |
| `risk_premium_ratio 1.5` | 66.23 | 85.50 | 1.088 | 0.1318 | -0.188 | Senegal 23.6->19.5, Pakistan 11.5->9.7, Argentina 11.9->10.4, Belize 7.1->5.8, Zambia 6.6->5.4 |
| `risk_premium_ratio 2` | 64.29 | 83.73 | 0.629 | 0.1278 | -0.320 | Senegal 23.6->17.1, Pakistan 11.5->8.6, Argentina 11.9->9.5, Belize 7.1->5.0, Zambia 6.6->4.8 |
| `risk_premium_ratio 3` | 62.16 | 81.87 | 0.095 | 0.1231 | -0.504 | Senegal 23.6->14.3, Pakistan 11.5->7.3, Argentina 11.9->8.3, Belize 7.1->4.1, Zambia 6.6->3.9 |
| FX scale Peg/Dollarized 0 | 68.22 | 87.33 | 1.720 | 0.1374 | -0.007 | Senegal 23.6->22.0, Belize 7.1->7.0, others unchanged |
| ratio 2 + Peg 0 | 64.23 | 83.67 | 0.534 | 0.1271 | -0.326 | Senegal 23.6->15.9, Pakistan 11.5->8.6, Argentina 11.9->9.5, Belize 7.1->4.9, Zambia 6.6->4.8 |
| `w_m 0.35` + ratio 2 + Peg 0 | 63.13 | 82.71 | 0.236 | 0.1177 | -0.452 | Zimbabwe 78.4->66.3, Senegal 23.6->14.1, Pakistan 11.5->8.1, Argentina 11.9->8.7, Belize 7.1->4.3 |

Venezuela stays at 99.0 in every variant (cap). Zimbabwe (SD) is untouched by the risk-premium ratio
because defaulted names are exempt; it moves only with `w_m`.

Can `w_m` be estimated offline? Not from outcomes. The hazard panel (`data/panel/hazard_panel.csv`) has
no spread column, `data/cds_quotes.csv` is empty, and `data/benchmarks.csv` holds one date with no
resolved 12-month outcome, so there is no spread-and-outcome sample to fit a weight on. The only number
available is a rating-anchored calibration: the `w_m` that brings `logodds_post` closest (least squares
in log-odds) to the rating-implied PD across the 16 non-defaulted countries, holding the other terms
fixed. It is 0.054 with a 95 percent country-bootstrap interval of -0.25 to 0.31 (5,000 resamples, seed
20261023). It is not an estimate of the market signal's information content: the rating PD already makes
up half of the Layer 1 prior (`hazard_weight 0.5`), so the calibration partly asks the posterior to
return to its own input, and a rating is a slower signal than a spread by construction. Read it only as
"rating-consistent PDs need almost no market weight"; the interval covers both 0 and 0.25 and is no
evidence for any value in that range over another.

## Benchmarks and evidence

- `test_market_prior_blend_direction` checks that `pd_final` lies between `pd_post` and `pm_default`
  for priced countries; it passes.
- Workbook comparison on the seed snapshot (`workbook_reference.json`): the workbook's `pd_default`
  for Senegal was 34.5 percent after a 52 percent prediction-market prior at full weight; the
  program weights that contract at tau 0.09 and gets 16.7 percent before and 23.9 percent after the
  regime multiplier (README quotes 18 percent on the seed data). The two disagree by design.
- No benchmark against outcomes exists. Roadmap item 2.6 (Brier scores of model, rating, CDS-implied
  and prediction-market PDs over time) is the intended evidence; today the only comparable series is
  the 60-day forecast record of market VaR, which does not test PDs.
- The posterior's relation to the market: `pd_default` is above `pd_market` for Pakistan (11.5 vs
  7.5), Argentina (11.9 vs 10.8), Senegal (23.9 vs 20.0) and Zimbabwe (78.4 vs 50.0), and below it
  for the investment-grade names. That pattern is what signal 15 (market complacency) reports; it is
  a consequence of the weights, not evidence.

## Open items for review

1. Decide `w_m` on evidence (EQ-B-0021 table above; `w_m` is not estimable offline), and decide the
   value of `risk_premium_ratio` (2.0 since 0.1.3, literature-based judgement) against Brier scores once
   licensed CDS data and benchmark scoring exist (first maturity 2027-10-23). A rating-bucketed ratio is the next refinement.
2. Fix the run-date dependence: record the as-of date in the run and compute contract horizons from
   it, so versioned runs are reproducible.
3. Replace the placeholder contract prices or set `use_market_prior false` until live prices exist;
   today the blend adds illustration to a model output.
4. Source and date the spreads in `countries.csv`; they carry half the weight of every PD.
5. Decide the `w_fx_regime_scale` values for Peg and Dollarized (mechanism in place since EQ-B-0021,
   default 1.0; proposed 0).
6. Wire the text stress index (roadmap 1.4 / 3.5) or drop `w_t` from the documentation of live
   behaviour. EQ-B-0033: the event index is wired behind `probability.text_index.source` (default
   `none`); switching it on is a Tier 1 decision for Sam once the real backtest in `event-index.md` has run.

## Market term from CDS curves (EQ-B-0100, for EQ-B-0050; off by default)

`probability.market_term.source` (code default `"profile"`, not in `assumptions.json`) selects where `z_cds` gets its
spread. `"cds_curves"` reads the CDS curve from Team A's market store point in time at the run's as-of date (licensed
vendor pulls or CSV exports) and uses either the par spread at `tenor_y` (`measure "spread"`, same spread / LGD / k
mapping, so `bond_rv.fair_bp` stays its inverse) or the curve's 1-year risk-neutral hazard (`measure "hazard_1y"`),
both divided by `risk_premium_ratio`. Countries without a usable curve keep the profile spread (reported per row).
Tested only on a SYNTHETIC fixture; no curve can be used until the licence register approves a vendor row. Settings, fail-closed rules, limits, the fixture effect table,
pipeline wiring, licence allow-list and publish guard: `licensed-data-readiness.md`. Switching it on with real data is a Tier 1 change.
