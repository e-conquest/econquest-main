# Portfolio risk analytics: attribution, marginal and component VaR / ES, what-if

Date: 2026-10-25. Ticket EQ-B-0114 (AGENT-02). Code: `econquest/engine/portfolio_risk.py`; the per-position loss
function `position_path_loss` and `simulate(legs=True)` in `econquest/engine/layer6_montecarlo.py`.
Tests: `tests/test_portfolio_risk.py`.

Nothing here runs in `econquest run`, writes data/ or changes a parameter. The base run is the pipeline's own, and
its numbers are unchanged. The 20,000-path base gives 66.95612571109443 / 89.00003057231508 / 4.098636048964449 /
72.23763153780678 before and after the change, and the 32,768 x 24 position-loss matrix is bit-identical.

## Commands

```
python -m econquest.engine.portfolio_risk attribution --data data --as-of 2026-10-23 [--paths N] [--out outputs/...]
python -m econquest.engine.portfolio_risk whatif --data data --as-of 2026-10-23 --country Brazil --instrument Eurobond \
    --direction Long --size 10 [--duration 5] [--paths N] [--limits FILE] [--out outputs/...]
```

`--instrument` takes an asset class (FX, Local bond, Eurobond, Equity, CDS protection; "CDS" and "Local" are
accepted; "Bond" alone is refused, since it could be either bond type). `--size` is the notional in $mm; 0 gives the base back. `--out` must be under outputs/ and receives
`attribution.json` or `whatif.json`. `portfolio_risk.main(argv)` is the entry point for an `econquest whatif` /
`econquest attribution` command. Team C owns the CLI and GUI (handoff HO-20261025-B-C-018).

## Method

**Component ES99.** The component of position i is E[L_i | L >= VaR99]: the mean of its path loss over the tail
paths that define ES99, the same set `simulate` uses. The components sum to ES99 exactly, up to float rounding. They
equal the run's existing `tail_contribution_99_mm`.

**Marginal ES99.** Every position's path loss is positively homogeneous in its notional: the market move, jump legs,
carry and long-loss cap all scale with it. So the Euler allocation holds, and the marginal ES99 per $1mm of notional is
component / notional. The same holds for VaR99.

**Component VaR99.** E[L_i | L = VaR99] is estimated on the paths whose loss rank lies within +-h of the VaR99 rank,
with h = max(50, 0.1% of the paths), narrowed so the band stays symmetric near the end of a small sample. The
components are then scaled so they sum to VaR99 exactly. The unscaled sum and the scale factor are reported as a
check: at 131,072 paths the band has 264 paths and the scale is 0.9986.

**Factors.** Factors are risk types:
- **market:** the market move (spread, rates, FX, equity), including a scenario rate shock.
- **default:** the default leg of Eurobonds, local bonds and CDS.
- **transfer_convertibility:** the transfer and convertibility leg.
- **expropriation** and **political_violence:** the two Equity jump legs.
- **carry.**
- **long_cap:** the long-loss cap, which is always <= 0.

The split is sequential on each path: market move first, then each jump leg's change to the path, then carry, then
the cap. So it is exact, with factors summing to the position loss within 1e-13 $mm. Where a default settles over the
mark (Eurobond / CDS, EQ-B-0063), the default leg carries the difference between the settlement and the mark it
replaces. That is a convention of the order, not a second estimate.

The factor split comes from re-simulating the base run with `simulate(legs=True)`: same country table, positions,
loadings, df, seed and path count. The attribution refuses to run unless the re-simulated path losses are
bit-identical to the run's.

**What-if.** The proposed position goes through the same `build_positions` and `position_path_loss` code as a
book position:
- It is priced on the base run's own paths (its country's latent paths) and added to the base path losses.
- Its own severity draws come from a fixed-seed generator, `default_rng([seed, 114])`.
- "Before" is the base run itself, so a zero-size trade gives the base numbers exactly, and the change is the trade's
  effect with no re-sampling noise.

The existing `limits.pretrade_check` appends the position and reruns the pipeline. That shifts the Sobol columns
of every position, so its before/after difference carries simulation noise. It is left unchanged.

The output gives:
- EL, VaR95/99, ES95/99, liquidity cost and L-VaR99, before and after.
- The first-order (Euler) estimate of the change: the trade's mean loss on the base tail or VaR band.
- The trade's own PD, volatility, carry, liquidity cost and factor legs.
- `check_book`'s limit table before and after, with usage of the four book limits.
- A verdict: accept, flag (a warning level crossed) or refuse (a breach). A limit already above its warning level
  before the trade is reported with "(already ... before the trade)".

**Several trades at once (HO-20261025-C-B-008).** `whatif(u, s, [trade, ...], limits)`, or `whatif_many`, prices
every trade on the base run's paths. Trade k gets its own severity draws, `default_rng([seed, 114, k])`. The first trade
keeps the single-trade draws `[seed, 114]`, so a one-trade list returns exactly the single-trade result. After
losses = base losses + every trade's path loss; liquidity cost and gross notional add up; the limits are graded on the
after book. Per trade it reports:
- **Marginal VaR99 / ES99 / L-VaR99:** the after book minus the after book without that trade. The book without it
  is rebuilt as base + the other trades, so for a single trade the marginal is exactly the change.
- **Euler component ES99 and VaR99:** on the after book's tail and VaR band; all positions' components sum to the
  after ES99 / VaR99.
- **Its share of ES99, EL, first-order estimates on the base tail, PD, volatility, carry, liquidity cost and draw seed.**

A list of zero-size trades, or an empty list, gives the base exactly. Before this change, Team C's `presentation.whatif`
priced every trade of a multi-trade what-if with the same draws, so their severities were perfectly correlated. With one
draw per trade, multi-trade numbers differ from that by design; single-trade numbers do not change.

## Results on the shared data (as_of 2026-10-23, 131,072 paths; synthetic and seed inputs, see input caveats)

The base reproduces the release numbers: VaR99 66.78, ES99 88.48, EL 4.10, L-VaR99 72.06 $mm.

ES99 by factor:

| factor | component ES99 $mm | share |
|---|---|---|
| market | 62.37 | 70.5% |
| default | 22.18 | 25.1% |
| transfer_convertibility | 10.04 | 11.3% |
| expropriation | 3.00 | 3.4% |
| political_violence | 1.50 | 1.7% |
| carry | -1.97 | -2.2% |
| long_cap | -8.62 | -9.7% |

Largest ES99 contributions by country, in $mm (marginal ES99 per $1mm of notional in brackets):
- Brazil 16.96 (0.49)
- Singapore 12.50 (0.36)
- South Korea 8.94 (0.60)
- China 6.89
- Pakistan 6.52

Japan is a hedge at -4.86. Venezuela has the highest marginal ES99, 0.94 per $1mm: its PD is at the engine cap.

What-ifs:

| trade | EL | VaR99 | ES99 | L-VaR99 | ES99 first order | verdict |
|---|---|---|---|---|---|---|
| Long 0 Eurobond Brazil | +0.000 | +0.000 | +0.000 | +0.000 | +0.000 | flag (EL already 82% of limit) |
| Long 10 Eurobond Brazil | -0.089 | +1.968 | +3.143 | +2.154 | +2.971 | refuse: Brazil gross notional 45 = limit |
| Long 10 CDS protection Brazil | +0.089 | -1.390 | -2.829 | -1.071 | -2.971 | refuse: same country limit (protection counts as gross) |
| Long 10 Eurobond Venezuela | +9.344 | +9.467 | +9.425 | +10.210 | +9.368 | refuse: EL 13.45 vs 5 and Venezuela gross 15 vs 10 |

## Limits of the method

- Component VaR is a kernel estimate. At 4,096 paths the band has about 80 paths, and the scale factor moves by a
  few percent between seeds. Use the default 100,000 paths for anything quoted.
- The factor split is order-dependent where legs interact (settlement over the mark, the long cap). Its total, and
  the position and country components, are not.
- The what-if prices one trade at a time on fixed base paths. Two trades are not additive in VaR or ES.
- Country gross notional counts CDS protection as gross (limits.check_book), so a hedge can breach a country limit.
  That is the limit rule as written, not an estimate.
