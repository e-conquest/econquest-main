# Fitted HMM regimes vs the rule regimes

Method `hmm`; fitted: True; scenario override: Model.
Sample: 17 countries, 2635 country-weeks, weeks 2023-11-10 to 2026-10-23 (155 weeks); log-likelihood -10368.0; ETF columns imputed with the weekly cross-sectional mean for 47 percent of country-weeks.

## Transition matrices

Fitted weekly matrix (rows: from Calm, Stressed, Crisis):

| From \ To | Calm | Stressed | Crisis |
|---|---|---|---|
| Calm | 0.956 | 0.041 | 0.003 |
| Stressed | 0.044 | 0.944 | 0.011 |
| Crisis | 0.007 | 0.041 | 0.952 |

Fitted 12-month matrix (weekly matrix to the 52nd power):

| From \ To | Calm | Stressed | Crisis |
|---|---|---|---|
| Calm | 0.462 | 0.424 | 0.114 |
| Stressed | 0.446 | 0.429 | 0.125 |
| Crisis | 0.398 | 0.424 | 0.178 |

Assumptions.json 12-month matrix:

| From \ To | Calm | Stressed | Crisis |
|---|---|---|---|
| Calm | 0.850 | 0.120 | 0.030 |
| Stressed | 0.300 | 0.550 | 0.150 |
| Crisis | 0.100 | 0.300 | 0.600 |

## State means (original units)

| State | dep_4w | fxvol_4w | etf_4w | etfvol_4w |
|---|---|---|---|---|
| Calm | 0.10 | 3.46 | 1.24 | 19.21 |
| Stressed | -0.08 | 9.47 | 1.54 | 24.24 |
| Crisis | 5.30 | 21.63 | 0.75 | 24.03 |

## Today's regimes

Agreement rate rule vs HMM over the fitted countries: 58.8 percent. HMM counts: {'Calm': 8, 'Stressed': 5, 'Crisis': 4}.

| Country | Rule | HMM | Chosen | p_calm | p_stressed | p_crisis | weeks in state | dep 4w % | FX vol 4w % |
|---|---|---|---|---|---|---|---|---|---|
| Vietnam | Calm | Calm | Calm | 1.00 | 0.00 | 0.00 | 77 | -0.51 | 1.53 |
| Philippines | Calm | Calm | Calm | 1.00 | 0.00 | 0.00 | 6 | 1.59 | 4.16 |
| China | Calm | Calm | Calm | 1.00 | 0.00 | 0.00 | 77 | -0.49 | 0.93 |
| Malaysia | Calm | Calm | Calm | 1.00 | 0.00 | 0.00 | 17 | -0.04 | 1.55 |
| Singapore | Calm | Calm | Calm | 1.00 | 0.00 | 0.00 | 74 | -0.20 | 2.23 |
| Japan | Calm | Calm | Calm | 0.99 | 0.01 | 0.00 | 2 | -0.42 | 4.25 |
| South Korea | Calm | Stressed | Stressed | 0.00 | 1.00 | 0.00 | 56 | -2.98 | 7.84 |
| India | Calm | Stressed | Stressed | 0.13 | 0.87 | 0.00 | 2 | -1.92 | 7.25 |
| Pakistan | Stressed | Crisis | Crisis | 0.00 | 0.00 | 1.00 | 7 | 3.11 | 29.52 |
| Belize | Stressed | Stressed | Stressed | 0.00 | 0.98 | 0.02 | 1 | 3.21 | 11.52 |
| Brazil | Calm | Stressed | Stressed | 0.00 | 0.99 | 0.01 | 77 | -3.22 | 17.25 |
| Argentina | Stressed | Calm | Calm | 0.99 | 0.01 | 0.00 | 15 | 0.39 | 4.59 |
| Colombia | Calm | Crisis | Crisis | 0.00 | 0.02 | 0.98 | 21 | -5.58 | 14.63 |
| Venezuela | Crisis | Crisis | Crisis | 0.00 | 0.13 | 0.86 | 107 | 3.34 | 3.43 |
| Nigeria | Stressed | Calm | Calm | 1.00 | 0.00 | 0.00 | 25 | 0.50 | 3.22 |
| Senegal | Crisis | Crisis | Crisis | 0.00 | 0.00 | 1.00 | 19 | 4.33 | 26.67 |
| Zambia | Stressed | Stressed | Stressed | 0.00 | 0.95 | 0.05 | 32 | 6.37 | 12.16 |
| Zimbabwe | Crisis | n/a | Crisis |  |  |  |  |  |  |

## Fallback to the rule regime

- Zimbabwe: no FX series and no ETF in prices.csv

## Book risk by regime method

| Method | VaR99 $mm | ES99 $mm | Global regime | Not calm |
|---|---|---|---|---|
| rules | 63.98 | 83.02 | Calm | 0.44 |
| hmm | 80.98 | 105.19 | Stressed | 0.56 |
| blend | 82.18 | 106.31 | Stressed | 0.67 |

Regenerated 2026-10-23 for EQ-B-0036 with `regime_hmm.hmm_report` on the 0.1.3 assumptions (production
count, 131,072 Sobol paths, seed 7, as_of 2026-10-23); the previous version predated the Layer 2
recalibration (rules VaR99 68.75). The option is `regime.method` (rules default, hmm, blend) and
`transition_matrix.source` (assumptions default, hmm); decision evidence in `regime-layer3.md`, section
"EQ-B-0036".
