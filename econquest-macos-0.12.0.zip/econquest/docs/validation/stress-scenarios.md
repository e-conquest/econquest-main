# Model validation: stress scenarios

Date: 2026-10-23. Code: `econquest/engine/stress.py` (`scenario_a`, `scenario_b`, `scenario_c`,
`SCENARIOS`, `compare`) and the stress-path shock in
`econquest/scorecard/scoring.py::stress_inputs`. Parameters: hard-coded shock sizes in `stress.py`;
`data/assumptions.json` key `stress_path` for the scorecard shock. Status: three named scenarios
from section 9 of the paper, implemented as data and parameter patches. Updated 2026-10-23
(EQ-B-0054, VF-002): sizes are data in `data/scenarios.json` (13 scenarios, incl. historical
reconstructions) and a reverse stress search exists (`reverse-stress`); see model-inventory
component 9. On 0.1.4 scenario A moves ES99 by +61.2% (release note; replicate R10).

## Purpose

Stress testing answers "what does the book lose if a named macro or geopolitical event happens", by
re-running the whole pipeline on a modified universe and parameter set and comparing VaR, ES,
liquidity cost, regimes, PDs and LGDs against the base run. Scenarios: A, a hawkish Fed (+200 bps);
B, a 30 percent commodity price collapse; C, a Strait of Malacca blockade.

## Where it sits in the pipeline

`cli.py::cmd_run --stress` and `cmd_stress` call `SCENARIOS[k].apply(u, s)` to get a cloned universe
and patched settings, then `run_pipeline(u2, s2, label="stress-K", paths=args.stress_paths)` with
`--stress-paths` defaulting to the base run's path count since 2026-10-23 (previously 50,000 against 100,000), then `compare(base, stressed)`. Results
go to `outputs/stress.json`, the dashboard and the workbook's Stress Inputs tab. There is also a
second, unrelated use of the word stress: the scorecard's stress path (`stress_inputs`) applies a
fixed combined shock to eight indicators in every run, base or scenario, and keeps the worse score
(documented in `scorecard.md`).

## Assumptions

Scenario A (`scenario_a`, "Hawkish Fed +200 bps"): spreads at or above 300 bps widen by 280 bps;
spreads below 300 outside Asia widen by 50 percent; 3-month depreciation rises by 18 points for
ratings B, B-, CCC+, CCC, SD and 12 points otherwise; text index +1; debt/GDP (1.3) scaled by `1 +
0.4 * FX share / 100`; global loadings +0.25 in every regime (capped at 0.9); regional loading cut
to 0.05. The depreciation shock pushes every non-SD country past the 5 percent Stressed threshold
and the B-rated names past 15 percent into Crisis.

Scenario B (`scenario_b`, "30 percent commodity collapse"): for commodity exporters (`exptype ==
Commodity`: Brazil, Argentina, Colombia, Venezuela, Nigeria, Senegal, Zambia, Zimbabwe) the
commodity gap falls 30 points, the primary balance gap (1.6) worsens by 4 points of GDP, reserves
(2.1) fall 20 percent, the current account (2.8) worsens by 4 points; trigger add-ons of +18 on
pillars 2 and 5 for those countries with `trigger_cap` raised to 18; `dd_reference` +1.8 sigma and
`apply_uplift 1` on the Merton LGD; `market.lgd_hard` +18 points (from 60 to 78 percent, capped at 95; before 2026-10-23 it was scaled by 58/40 to 87).

Scenario C (`scenario_c`, "Strait of Malacca blockade"): text index +3.5 for Asia and +1 elsewhere;
all spreads times 1.3; every position's location set to "Active warzone" (political-violence PD
times 2 on equities); Calm global loading +0.15; liquidity `spread_mean` doubled and `spread_sd`
times 1.5 for every asset class.

`compare` reports base and stressed `var99_mm`, `es99_mm`, `es975_frtb_mm`, `lvar99_mm`,
`liquidity_cost99_mm`, `expected_loss_mm` with percent changes, regime counts, the share of
countries moving to Crisis, and mean changes in `pd_default` and `lgd_hard_expected`.

## Data

Scenarios act on `countries.csv` (spread, fx3m, textz, commgap), `indicators.csv` (1.3, 1.6, 2.1,
2.8), `adjustments.csv` (trigger rows) and `portfolio.csv` (location). All sizes are literals in
`stress.py` with the paper's section numbers in the docstrings; they are not in `assumptions.json`
and are not stamped in the run's `settings` record except through the patched values.

## Estimation or calibration

None. The shocks are narrative sizes from the paper. Their mapping into the program (which
indicators, how much, which parameter patch) is the implementer's judgement.

## Outputs and how they are used

Archived production run (`outputs/stress.json`, base 100,000 paths, scenarios 50,000, data of
2026-10-23):

| Scenario | VaR99 change | ES99 change | ES97.5 change | L-VaR99 change | Liquidity cost change | Countries to Crisis | Mean PD change (pp) | Mean LGD change (pp) |
|---|---|---|---|---|---|---|---|---|
| A Hawkish Fed | +87.9% | +85.2% | +88.1% | +86.7% | +72.5% | 4 of 18 (22%) | +5.5 | +3.4 |
| B Commodity collapse | +3.8% | +4.6% | +5.5% | +3.5% | 0% | 0 | +1.7 | +27.5 |
| C Malacca blockade | +24.3% | +24.1% | +24.5% | +27.5% | +67.5% | 0 | +3.2 | 0 |

Re-run in this validation at 20,000 paths (base VaR99 65.98, ES99 87.05, L-VaR99 71.26 $mm): A gives
123.7 / 158.1 / 132.8 (+87.5, +81.6, +86.4 percent), with 10 countries Stressed, 7 Crisis, 1 Calm,
global regime Stressed (`nu` 4), Argentina PD 22.8 percent, Pakistan 25.9, Senegal 41.0; B gives
69.4 / 91.1 / 74.7 (+5.2, +4.6, +4.9 percent) with `lgd_hard_expected` 0.887 for Calm and 0.95 (the
cap) for Stressed and Crisis countries; C gives 81.8 / 107.1 / 90.7 (+24.0, +23.0, +27.2 percent),
liquidity cost +67.5 percent, Pakistan PD 24.1 percent (text index +3.5 at `w_t 0.25`).

The README quotes the paper's figures for comparison: +18.4 percent for A and +24.6 percent
liquidation cost for C.

## Scenario library and reverse stress (added 2026-10-23, roadmap 3.4)

Scenarios moved out of code into `data/scenarios.json`, read by `load_scenarios` in `engine/stress.py`.
A scenario is a list of shocks on the countries table (add, multiply, set, or move a rating by
notches), on indicator rows, on trigger add-ons, on the portfolio and on dotted settings keys (with
`*` wildcards and caps), each with an optional `where` filter on any countries.csv column. The
paper's A, B and C were translated into this grammar; `tests/test_scenarios.py` checks that they
reproduce the previous code scenarios to the cell. Six more were added: ASIA97, GFC08, TAPER13,
COVID20, FED22 (approximate reconstructions of market moves, sourced in the file) and DOWNGRADE.
Every scenario takes a severity scale; `econquest stress --scale 0.5` runs the library at half size.

Results at 20,000 paths on the sample book (base VaR99 68.7, ES99 88.7 $mm), scale 1:

| Scenario | VaR99 | ES99 | L-VaR99 | VaR99 change | Moved to Crisis |
|---|---:|---:|---:|---:|---:|
| A Hawkish Fed | 123.2 | 156.9 | 132.3 | +79% | 22% |
| B Commodity collapse | 74.7 | 94.8 | 80.0 | +9% | 0% |
| C Malacca blockade | 84.3 | 108.5 | 93.1 | +23% | 0% |
| ASIA97 | 153.0 | 173.9 | 162.6 | +123% | 50% |
| GFC08 | 181.2 | 197.4 | 207.1 | +164% | 56% |
| TAPER13 | 122.2 | 152.8 | 131.5 | +78% | 22% |
| COVID20 | 145.1 | 171.4 | 158.9 | +111% | 22% |
| FED22 | 132.8 | 161.4 | 141.6 | +93% | 17% |
| DOWNGRADE | 73.4 | 93.4 | 78.7 | +7% | 0% |

`reverse_stress` bisects the severity scale (same seed and path count on every run) to the point
where a book limit in `data/limits.json` breaks, and `single_factor_reverse` does the same for one
factor at a time. Against the VaR99 limit of 95 $mm:

| Reverse stress | Breaks the VaR99 limit at |
|---|---|
| GFC08 | 16% of the 2008 moves |
| COVID20 | 22% of the 2020 moves |
| ASIA97 | 25% of the 1997-98 moves |
| TAPER13 | 41% of the 2013 moves |
| A Hawkish Fed, FED22 | 44% of the scenario |
| C Malacca | 1.6x the scenario |
| DOWNGRADE | 2.75x (about 5 notches sub-IG) |
| B Commodity | no breach up to 4x |
| Sovereign spreads alone | +375 bp across the book |
| EM currencies alone | 16% depreciation (floats and managed) |
| Global copula loading | +0.33 |
| Default PD multiplier | 4.5x |
| Hard-currency LGD alone | no breach up to +35 pp |
| Downgrades alone | no breach up to 6 notches |

Reading: the book's tail is a spread and currency book, not a default book. A quarter of the 1997 or
2008 moves breaches the VaR limit, while LGD, downgrades and the commodity scenario cannot breach it
on their own. The commodity scenario at 4x not breaching is a statement about the sample book
(69 $mm in commodity exporters) rather than about the scenario. Outputs: `outputs/scenario_library.csv`,
`outputs/reverse_stress.json` and `.csv`; the GUI's Data & jobs page shows both tables.

Limitations: historical scenarios are stylised (one shock per market variable, no term structure,
no path dependence) and the bisection assumes the measure rises with the scale, which holds with
common random numbers but can be violated where spreads hit the hard-currency price floor (VaR99 at
+3,000 bp was lower than at +1,500 bp); the reported breach scale is then the first bracket found.

## BIS common-creditor contagion (EQ-B-0037, GOV-027): built, waiting on BIS banking data

A new shock target, `contagion`, spreads a credit shock in one country to the others in proportion
to the foreign bank creditors they share with it. With `C[k, x]` the claims of reporting banking
system k on country x (BIS consolidated banking statistics) and `s[k|x] = C[k, x] / sum_k C[k, x]`,
the receiver weight is the common-lender index `w_i = sum_k s[k|o] s[k|i]` (0 to 1), divided by the
largest receiver weight when `normalise` is "max" (the default, so the most exposed peer takes the
full shock). A receiver gets `value * scale * w_i` on the shocked column (add) or
`1 + (value - 1) * scale * w_i` (mul); the origin is shocked separately with ordinary country
shocks. The channel is a spread and currency shock; PDs move through Layer 2 (market-implied PD)
and the regime rules, not through a direct PD uplift. Countries missing from the exposure file get 0.

Exposure path (EQ-B-0047, AGENT-09 Low): `exposures` must be a path relative to the scenarios.json folder and
must resolve inside it; absolute paths, `..` and symlinks out are refused with a ValueError, and a file without
the needed columns is reported by its column count, not its header row. `load_bilateral_exposures` called
directly from Python still takes any path. Test: `test_exposures_path_confined_to_data_dir_and_header_not_echoed`.

Data: `data/live/raw_bis.csv` has only `EER_REAL_BROAD`, `CREDIT_GAP` and `POLICY_RATE` for 10
countries; it holds no banking statistics. `load_bilateral_exposures` therefore reads a file Team A
has been asked to add, `data/live/raw_bis_cbs.csv` (handoff under EQ-B-0037), in either the
normalised form `creditor_iso2, debtor_iso3, period, claims_usd_mn` or the raw BIS SDMX CSV
(`L_REP_CTY, L_CP_COUNTRY, TIME_PERIOD, OBS_VALUE`, filtered to `L_POSITION` C and `L_MEASURE` S;
aggregate reporters such as 5A dropped; latest period unless the shock names one). Until it exists,
`load_scenarios` leaves the scenario out (`stress.UNAVAILABLE` gives the reason), so `run --stress`,
`stress` and `reverse-stress` are unchanged.

New scenario `EMDEF_BRA` (hypothetical): Brazil defaults (default flag, rating SD, spread +1,500
bp, BRL -25 percent); contagion of up to +400 bp on spreads and up to 8 percent on floating and
managed currencies; no loading or regime patch. Run against the SYNTHETIC fixture
`tests/fixtures/bis_cbs_synthetic.csv` (made-up creditors XA to XF), 20,000 requested paths:

| Run | VaR99 $mm | ES99 $mm | L-VaR99 change | Regimes (Calm/Stressed/Crisis) |
|---|---|---|---|---|
| Base | 64.23 | 83.67 | | 10 / 5 / 3 |
| Brazil origin shocks only | 81.33 | 104.86 | | |
| EMDEF_BRA (synthetic exposures) | 88.48 (+37.8%) | 112.35 (+34.3%) | +38.5% | 7 / 5 / 6 |

Mean PD +4.2 pp; Brazil +48.9 pp, then Zimbabwe +6.8, Argentina +5.4, Belize +3.0, Pakistan +2.9.
With synthetic weights the contagion leg adds about 7.5 $mm of ES99 to the origin shock; the split
will change with real BIS data. Expected loss falls (-0.12 vs 2.04 $mm for the origin alone)
because wider spreads raise the carry in the loss model with no mark-to-market loss from the
widening itself, a property of the Monte Carlo, not of the channel.

Rates and duration (GOV-027, second half): added by EQ-B-0044, next section.

## Rate level shock on local bonds and Eurobonds (EQ-B-0044, GOV-027, added 2026-10-23)

Before, a scenario could only widen local-bond volatility (`market.local_rate_vol`); no shock moved the
yield level, so the local-bond leg (the largest tail contributor) and the Eurobonds' rate duration never took
a rates loss. New shock target:

    {"target": "rates", "leg": "local" | "hard", "value": 100, "where": {...}}

`value` is a yield change in bp (op add only; scaled as value * scale; several shocks on a position add).
Leg "local" reprices Local bond positions, leg "hard" Eurobond positions (the US Treasury level under a USD
bond; spread moves keep their existing channel). `apply_shocks` writes `rate_shock_bp` on the matching
positions of the cloned portfolio; `layer6_montecarlo.build_positions` turns it into
`rate_mtm_pct = duration_yrs * rate_shock_bp / 100` and `simulate` adds that loss (percent of notional) on
every path before the direction sign and the long-loss cap. First order only: no convexity, no carry
change from the higher yield, no term structure, and no PD move (a market move, like the spread shocks).
CDS, FX and equity positions are not repriced. Base runs have no `rate_shock_bp` column and are
bit-identical (base and all 13 available scenarios: same paths x positions loss matrix SHA-256 at 20,000
requested paths, as_of 2026-10-23).

Book sensitivity (data/, assumptions 0.1.4, 20,000 requested / 32,768 Sobol paths): +100 bp moves the
sample book by 8.83 $mm deterministically (local bonds 430 $mm-years of duration x notional, 4.30 $mm;
Eurobonds 453, 4.53 $mm).

| Run | VaR99 | ES99 | EL | L-VaR99 |
|---|---:|---:|---:|---:|
| Base | 74.25 | 96.62 | 0.46 | 79.53 |
| Base + local and hard +100 bp | 81.25 | 103.22 | 9.06 | 86.53 |
| FED22 (unchanged) | 136.16 | 168.67 | 0.23 | 144.91 |
| FED22 + local +100 bp | 139.90 | 170.91 | 4.49 | 148.64 |
| FED22 + hard +100 bp | 138.35 | 170.43 | 4.39 | 147.09 |
| FED22 + both +100 bp | 141.89 (+4.2%) | 172.67 (+2.4%) | 8.65 | 150.63 |
| FED22 + both +200 bp | 147.28 (+8.2%) | 176.34 (+4.5%) | 17.02 | 156.02 |
| TAPER13 (unchanged) | 129.83 | 161.79 | 0.10 | 139.16 |
| TAPER13 + both +100 bp | 135.36 (+4.3%) | 166.23 (+2.7%) | 8.60 | 144.69 |
| TAPER13 + both +200 bp | 141.05 (+8.6%) | 170.36 (+5.3%) | 17.06 | 150.39 |

The tail moves by less than the deterministic 8.83 $mm per 100 bp (VaR99 +5.5 to +7.0) because on tail
paths several long bonds are already at the notional loss cap or defaulted. EL takes almost the whole
amount.

Proposal, not applied (changing an existing scenario's numbers is a Tier 2 parameter change for the owner
and approver): append to FED22 and TAPER13 `{"target": "rates", "leg": "hard", "value": H}` and
`{"target": "rates", "leg": "local", "value": L}`, with H and L set by Sam from the episode (2022 and
May-September 2013 10-year Treasury and local-currency index yield changes); the per-100 bp rows above
scale linearly in the deterministic term. scenarios.json is unchanged by this ticket.

## Tier filters for the 88-country universe (EQ-B-0043, added 2026-10-23)

Problem: in the approved 88-country universe (data/panel/universe_proposal.csv) the seven DM anchors
(United States, Germany, United Kingdom, France, Italy, Canada, Australia) matched EM-shaped filters:
`region_not_in: ["Asia"]` (A's x1.5 spread shock, ASIA97's and TAIWAN's +150 / +80 bp on non-Asian EM),
`region_in: ["Asia"]` (Australia took ASIA97's 35 percent depreciation, reserve loss and triggers), and the
`fxregime_in: ["Float", ...]` currency shocks (all seven anchors are Float). The legacy code scenario A in
stress.py had the same `region != "Asia"` rule. HORMUZ had no Middle East filter, so Gulf exporters behind
the strait would have taken the oil windfall (+40 commodity gap) and the exporters' mild +50 bp.

Change: `where` accepts `tier_in` / `tier_not_in` / `tier_eq` (desk_current, EM, frontier, DM_anchor; any
other value is refused). `country_tiers` reads tier from a `tier` column on the countries table when one
exists and is filled; otherwise (today: the Country Profile has no tier column, handoff
HO-20261023-B-A-008 to Team A) from universe_proposal.csv by ISO3; a country in neither is "unknown",
which fails `tier_in` and passes `tier_not_in`. scenarios.json: `tier_not_in: ["DM_anchor"]` added to every
country, indicator and trigger shock that has a region filter (except the text index `textz`, a global news
measure, and the portfolio location) and to every EM currency (`fx3m`) shock selected by FX regime or rating
(A, ASIA97, GFC08, TAPER13, COVID20, FED22, TAIWAN, HORMUZ, TARIFF, CHINA_HL). Legacy `_legacy_a` applies
the same rule. HORMUZ: the commodity windfall and the +50 bp exporter spread now carry
`region_not_in: ["Middle East"]`, and a new shock gives Middle East commodity exporters the importers' +150 bp
(same size, no new number); the importers' +150 bp and 8 percent depreciation exclude DM anchors.

Evidence that the 18-country numbers do not move (all 18 desk countries are tier desk_current): 20,000
requested paths (32,768 Sobol), as_of 2026-10-23, assumptions 0.1.4 (GARCH vols, estimated copula).
"Same losses" compares the SHA-256 of the paths x positions loss matrix.

| Run | VaR99 | ES99 before | ES99 after | Same losses |
|---|---:|---:|---:|---|
| base | 74.2474 | 96.6153 | 96.6153 | yes |
| A | 121.6861 | 155.7533 | 155.7533 | yes |
| B | 82.2315 | 103.2249 | 103.2249 | yes |
| C | 88.1980 | 114.8618 | 114.8618 | yes |
| ASIA97 | 149.1359 | 173.7939 | 173.7939 | yes |
| GFC08 | 164.7089 | 187.1340 | 187.1340 | yes |
| TAPER13 | 129.8314 | 161.7949 | 161.7949 | yes |
| COVID20 | 140.4787 | 168.0226 | 168.0226 | yes |
| FED22 | 136.1648 | 168.6737 | 168.6737 | yes |
| DOWNGRADE | 80.3038 | 101.7863 | 101.7863 | yes |
| TAIWAN | 133.9371 | 165.1872 | 165.1872 | yes |
| HORMUZ | 134.8662 | 167.2056 | 167.2056 | yes |
| TARIFF | 124.0588 | 154.7876 | 154.7876 | yes |
| CHINA_HL | 132.1937 | 165.5731 | 165.5731 | yes |

EMDEF_BRA is left out by `load_scenarios` until data/live/raw_bis_cbs.csv exists; its shocks are
country-named or contagion shocks, none of which was edited. `test_tier_clauses_do_not_change_the_18_country_scenarios`
pins the no-op cell by cell for every scenario.

Not changed, for a scenario-design decision once the 88 go live: shocks selected only by rating bucket
(GFC08, COVID20, TAPER13 investment-grade spread widening, DOWNGRADE's one-notch IG cut) and unfiltered
shocks (C's x1.3 spreads, the global text index) still reach DM anchors. Italy and France in 2011 argue for
keeping some of them; the anchors' spreads are still blank in staging.

## Limitations and known gaps

- Scenario A is a regime and dependence shock more than a rate shock. Decomposition (20,000 paths):
  the data patches alone (spreads, FX, debt, text) give ES99 +42 percent; adding the loading patch
  brings it to +82 percent. Most of the loading effect comes from the global regime flipping to
  Stressed (`nu` 4, loadings times 1.5 on top of the +0.25). The paper's +18.4 percent is a quarter
  of the program's result; the scenario is far harsher than the paper's.
- Scenario B is mostly an LGD statement. It moves VaR by 4 to 5 percent while raising the expected
  hard-currency haircut by 27 points, because the commodity exporters hold 69 $mm of the 309 $mm
  book and their PDs rise by 1.7 points on average. Fixed 2026-10-23: the scenario now adds the
  paper's 18 points (40 to 58 percent) to the base LGD, giving 78 percent rather than the 87 percent
  the old 58/40 scaling produced; the docstring and the parameter agree.
- Scenario C's location shock reaches only the two equity positions (location multipliers apply to
  `pd_pv` on equities only), and its text shock acts through `w_t` on 9 Asian countries. Most of C's
  +24 percent on ES99 comes from spreads times 1.3 (regime and PD changes: Pakistan to 24 percent,
  Philippines PD 1.3 percent) and the +0.15 Calm loading; the liquidity patch adds 3.6 $mm to L-VaR
  but nothing to VaR (`scenario_C_no_liq_patch` has the same VaR99 81.81 and L-VaR99 87.09 vs
  90.65).
- Half-size scenario A (hand-built in this validation: +140 bps, half the FX shock, half the loading
  change) still gives ES99 +52 percent, so the result is not linear in the shock: the regime cliffs
  (country regimes at 5 and 15 percent depreciation; global regime at 50 percent of countries) make
  the response step-like.
- Sizes are hard-coded. A reviewer cannot change "+280 bps" without editing code, and the stamped
  run settings do not record the scenario definition beyond the label.
- Fixed 2026-10-23: scenario runs now default to the base run's path count, so the earlier 1 to 2
  percent of Monte Carlo noise from mismatched counts (50,000 vs 100,000) is gone.
- No reverse stress test exists (roadmap item 3.4 lists it as future work): there is no search for
  the smallest shock that breaches a loss limit, and no limits exist yet (roadmap 4.1).
- No shipped scenario touches the local-bond leg directly (duration or local rates), which is the largest
  tail contributor in the base run; A affects it only through FX depreciation and loadings. The `rates`
  shock (EQ-B-0044) makes it possible; sizes for FED22 / TAPER13 await Sam.
- Transmission channels: the BIS common-creditor channel exists as a shock (above) but waits on
  real BIS consolidated banking data; trade links are not modelled; otherwise countries move
  together only through the common loading shift.

## Sensitivity

Changes vs the 20,000-path base (VaR99 65.98, ES99 87.05, L-VaR99 71.26 $mm):

| Run | VaR99 | ES99 | L-VaR99 | Regimes (Calm/Stressed/Crisis) | Global regime |
|---|---|---|---|---|---|
| A as coded | +87.5% | +81.6% | +86.4% | 1 / 10 / 7 | Stressed, nu 4 |
| A data patches only (no loading change) | +48.1% | +42.3% | +50.0% | 1 / 10 / 7 | Stressed, nu 4 |
| A at half size (spreads +140, FX +6/+9, text +0.5, loadings +0.125) | +55.7% | +52.1% | +53.0% | 6 / 8 / 4 | Stressed, nu 4 |
| B as coded | +5.2% | +4.6% | +4.9% | 10 / 5 / 3 | Calm |
| C as coded | +24.0% | +23.0% | +27.2% | 10 / 5 / 3 | Calm |
| C without the liquidity patch | +24.0% | +23.0% | +22.2% | 10 / 5 / 3 | Calm |
| Override "All stressed" (regimes only) | +29.2% | +32.1% | +29.7% | 0 / 15 / 3 | Stressed |
| Override "All crisis" (regimes only) | +54.9% | +53.6% | +62.0% | 0 / 0 / 18 | Stressed |

Related single-parameter sensitivities are in `copula-montecarlo-layers5-6.md` (loadings, `nu`,
volatilities) and `regime-layer3.md` (regime thresholds and overrides). Scenario A's result is
bounded below by "A data only" (+42 percent on ES99) and sits above the "All stressed" override (+32
percent) because it also raises loadings and moves seven countries to Crisis.

## Benchmarks and evidence

- `test_stress_scenarios_raise_tail_risk` checks that every scenario raises ES99 and that C raises
  the liquidity cost by more than 50 percent; it passes.
- The paper's published results (+18.4 percent ES for A, +24.6 percent liquidation cost for C) are
  the only external benchmark. The program reproduces the direction and the liquidity result for C
  (+67.5 percent, larger than the paper), and is about four times the paper on A. The README
  acknowledges that the scenario sizes are parameters in `engine/stress.py`.
- No historical episode has been replayed (for example, the 2013 taper tantrum or the 2022 Fed cycle
  on the same book) to test whether scenario A's spread and FX sizes are consistent with a 200 bps
  shock.

## Open items for review

1. Move the scenario sizes into `assumptions.json` (or a scenario file) so they are stamped with
   each run and can be changed without code edits.
2. Reconcile scenario A with the paper: either document why the program's +85 percent is right for
   this book or scale the shock (the data-only variant at +42 percent and the half-size variant at
   +52 percent bracket plausible alternatives).
3. Fix the scenario B docstring or the LGD scaling (60 to 87 percent vs the stated 40 to 58).
4. Run scenarios and base at the same path count, or report the Monte Carlo error alongside the
   change.
5. Add a reverse stress test once limits exist (roadmap 3.4 and 4.1): the smallest uniform loading
   or spread shock that takes ES99 to the limit.
6. Add a local-rates scenario; the local-bond leg is the largest tail contributor and no scenario
   stresses it directly.
7. Calibrate at least scenario A against a historical episode.

**Rates in FED22 and TAPER13 (0.1.5).** Sam set the sizes on 2026-10-23: FED22 +200 bp and TAPER13 +100 bp on local and hard-currency yields. Each is a duration × Δy mark-to-market loss (EQ-B-0044). At 100,000 requested paths, ES99 is FED22 176.26 (+84.7%) and TAPER13 166.05 (+74.0%), against base 95.4. GOV-027's duration half is closed by this; contagion still waits on BIS CBS.
