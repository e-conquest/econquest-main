# Interim hazard refit on World Bank-only predictors (EQ-B-0098)

Team B AGENT-03, 2026-10-25, as_of 2026-10-23. The WEO history stays deferred (EQ-A-0087).

**Question.** Can a hazard refit with World Bank predictors only (WDI, WGI, IDS) clear the gate (OOS AUC at least
0.75, at least 30 default starts, OOS Brier below the trailing base) on crag_v1 or on the current list?

**Answer: no, on either list** (and still no on the three-series history Sam uploaded later; see the follow-up section at the end). The World Bank data in the shared folders covers only 2020-2025. The panel has
4 events on the current list and 6 on crag_v1, so the out-of-sample test cannot run. **Recommendation: stay in
paper mode** (`layer1.mode` stays `paper_standardized`). There is no Tier 1 card, and no desk-PD or 100k-base
effect to report.

## Data used (nothing fetched)

| File | Economies | Years |
|---|---|---|
| `team/inbox/pull-20261025T013150Z/raw_worldbank.csv` (pull pack step 4, universe; Sam's Mac 2026-10-25) | 88 (WGI 216) | 2020-2025 for nearly every series |
| `data/live/raw_worldbank.csv` and `data/live/vintages/2026-10-23/raw_worldbank.csv` | 18 desk | 2020-2025 (IDS debt service 1970-2032) |
| `data/panel/` | none | no World Bank history file |

Both pulls ask the API for the most recent six years: each economy has a median of 6 years per series. Earlier
years exist for one or two economies only. `hazard_panel.fetch_worldbank_history` (the full-history fetch, now
through Team A's `worldbank_series_fetcher`, EQ-B-0095) has not been run on the Mac.

## Gate report

Features (lag 1): current account % GDP (BN.CAB.XOKA.GD.ZS), real GDP growth (NY.GDP.MKTP.KD.ZG), CPI inflation
in log points (FP.CPI.TOTL.ZG), WGI rule of law (GOV_WGI_RL.SC). IDS debt ratios cover only 57-60 economies from
2016-2019, so they would cut the panel further and are left out.

| | current list | CRAG, crag_v1 |
|---|---|---|
| country-years at risk / countries | 312 / 83 | 288 / 79 |
| rows (row t predicts a start in t+1) | 2021-2024 | 2021-2024 |
| default starts in the panel (gate: 30 or more) | 4 (2022: 3, 2023: 1): FAIL | 6 (2022: 5, 2023: 1): FAIL |
| OOS AUC (gate: 0.75 or more) | n/a: no origin has 5 training events: FAIL | nan: test years have no events: FAIL |
| OOS Brier vs trailing base | n/a: FAIL | 0.0077 vs 0.0012: FAIL |
| outcome | NOT CLEARED | NOT CLEARED |

The full reports are `gate-report-wb-interim.md` / `.json`, written by the command below. They are not stored
here because they only repeat this table.

## What is missing, exactly

1. **Years.** The panel needs predictor values from 2013 at the latest, for every economy, for every feature.
   On crag_v1 the starts in 2015-2025 add up to 32 (2015: 4, 2016: 4, 2017: 2, 2018: 3, 2019: 1, 2020: 4,
   2021: 2, 2022: 10, 2023: 2). That is just over 30 before any loss to missing values, and the rolling
   out-of-sample test then has very few years. A usable request is 2000-2025.
2. **Economies.** About 190 (the WEO list), not 88. With fewer economies the starts fall below 30 and the
   ever-defaulted share rises toward the 0.55 preflight limit.
3. **The current list cannot clear in any window from 2007.** It has 27 starts in 2008-2025 in total, and it has
   no source per episode.
4. **Point in time.** World Bank files have no vintages. A refit on them would use today's revised values for every
   past year. That is not point in time, so this check never writes a change pack.

## Revisions (World Bank values are not point in time)

The two pulls in the repo are two days apart (2026-10-23 and 2026-10-25). In the series both hold (GDP, reserves,
exports, unemployment, population, NPLs, homicides, external debt/exports: 78-108 cells each) no value changed.
IDS debt service (DT.TDS.DPPG.CD) differs in 95% of cells. That comes from Team A's change in how IDS is fetched
(world counterpart rows, HO-20261024-A-B-013), not from data revisions. None of the four interim features appears
in both pulls, so their revisions cannot be measured yet. Known sources of revision that two pulls this close cannot
show: annual WDI national-accounts revisions, and the WGI scores, which are re-estimated across all years in each
release. To measure them, keep each future pull (`--wb-previous` compares two).

## How to run it

```bash
.venv/bin/python -m econquest.validation.hazard_refit --as-of 2026-10-23 --events crag \
  --wb-interim team/inbox/pull-20261025T013150Z/raw_worldbank.csv \
  --wb-previous data/live/vintages/2026-10-23/raw_worldbank.csv --out outputs/hazard-refit/2026-10-23-wb-interim
```

`--events current` runs the current list. The option writes only the two report files under `--out`. It never
writes a change pack, `data/` or `assumptions.json`, and changes no default. Exit code 0 means cleared, 1 means not
cleared or not fittable, 2 means an input error. Code: `hazard_refit.run_wb_interim`, `wb_interim_panel`,
`wb_coverage`, `wb_revisions`. Tests: `tests/test_hazard_wb_interim.py` (SYNTHETIC data).

## If Sam wants another try before the WEO history

Run the World Bank history fetch for 2000-2025 for all economies on the Mac (`fetch_worldbank_history`, or Team
A's panel-history World Bank units), save it as a dated file and rerun the command above on it. Even if it then
clears, the panel would not be point in time and would lack the fiscal predictors (debt, primary balance). Treat
it as a benchmark for the WEO refit, not as a basis for fitted mode.

## Follow-up: the three-series World Bank history (2026-10-25)

Sam uploaded the 0.5.0 World Bank panel history: `team/inbox/pull-20261025T121034Z/worldbank_history.csv` (216
economies). It holds three series only, not the interim set (current account, growth, CPI and rule of law come
with EQ-A-0094):

| Feature (layer-1 name) | Series | Economies | Years | Transform |
|---|---|---|---|---|
| stfx_debt_reserves | DT.DOD.DSTC.IR.ZS, short-term external debt % reserves (IDS) | 113 | 1980-2024 | level |
| reserves_months_imports | FI.RES.TOTL.MO, reserves in months of imports | 179 | 1980-2025 | level |
| pitf_instability | PV.EST, WGI political stability | 216 | 1996-2025 (1996, 1998, 2000, then yearly) | wgi_to_pitf |

**PV.EST scale checked.** Values run from -3.05 to 1.76, with mean 0.00 and sd 1.00. That is the WGI estimate
scale, not a 0-100 score, so the layer-1 transform `(2.5 - v) / 1.25`, clipped to 0..4, applies. The run refuses
a WGI series whose absolute values exceed 5 (`check_wgi_scale`). The file marks PV.EST as served by the WGI
database-3 route `GOV_WGI_PV.EST`, "presumed same estimate", UNVERIFIED. The scale is consistent with that.

Setup: lag 1, as_of 2026-10-23, rows 1997-2024, not point in time (no vintages). The panel needs all three series,
so it is limited to the 106 economies with IDS short-term debt. Most advanced economies are not in it. There are
no rows 1998 and 2000, because WGI has no 1997 or 1999 values.

| | current list | CRAG, crag_v1 |
|---|---|---|
| country-years at risk / countries | 2,266 / 106 | 2,110 / 106 |
| default starts (gate: 30 or more) | 32: pass | 44: pass |
| OOS AUC, rolling origin 2012-2024 (gate: 0.75 or more) | 0.613 (20 OOS events, 1,237 rows): **FAIL** | 0.597 (25 OOS events, 1,173 rows): **FAIL** |
| OOS Brier vs trailing base | 0.01591 vs 0.01594: pass (by 0.2%) | 0.020884 vs 0.020887: pass (by 0.02%) |
| in-sample AUC | 0.722 | 0.680 |
| coefficients (s.e.) | ST debt/reserves 0.239 (0.095), reserves months -0.469 (0.301), instability 0.006 (0.176) | 0.161 (0.070), -0.414 (0.228), 0.006 (0.151) |
| outcome | NOT CLEARED | NOT CLEARED |

The current list also fails the refit's `episodes_sourced` preflight check. That check is not part of this
interim gate.

Reading:

- Both lists now have enough events, but the out-of-sample AUC is about 0.60, far below 0.75. The Brier score is
  only equal to the base rate: the model adds no measurable skill over the trailing default rate.
- Short-term debt to reserves carries most of the signal, and low reserves point the right way. Political
  stability adds nothing (coefficient about 0).
- The values are revised, not point in time, so these AUCs are if anything optimistic.

**Recommendation unchanged: stay paper.** `layer1.mode` stays `paper_standardized`. There is no Tier 1 card, and no
desk-PD or base effect to report. When the interim set (EQ-A-0094) lands, rerun with `--wb-features interim`.
A fit with the fiscal WEO predictors (EQ-A-0087) remains the route to fitted mode.

Reports: `outputs/hazard-refit/2026-10-23-wb-history3-current/` and `.../2026-10-23-wb-history3-crag/`
(`gate-report-wb-interim.md` / `.json`). Command:

```bash
.venv/bin/python -m econquest.validation.hazard_refit --as-of 2026-10-23 --events crag --wb-features history3 \
  --wb-interim team/inbox/pull-20261025T121034Z/worldbank_history.csv --out outputs/hazard-refit/2026-10-23-wb-history3-crag
```

## PI-10 rerun (EQ-B-0104, 2026-10-25)

No wider World Bank pull has landed: EQ-A-0094 (current account, growth, CPI, rule of law, broad money) still waits
on an upload. The only multi-year file is still `team/inbox/pull-20261025T121034Z/worldbank_history.csv`. Rerun
with today's code, as_of 2026-10-23, history3 features, results identical to the follow-up section: current list
32 events, OOS AUC 0.613; crag_v1 44 events, OOS AUC 0.597 (bar 0.75); OOS Brier equal to the trailing base
(0.01591 vs 0.01594; 0.020884 vs 0.020887). **NOT CLEARED: Layer 1 stays paper; no Tier 1 pack.** Reports:
`outputs/hazard-refit/2026-10-23-wb-history3-{current,crag}-pi10/`.
