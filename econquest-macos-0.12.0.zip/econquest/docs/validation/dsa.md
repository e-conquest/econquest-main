# Model validation: debt sustainability analysis (DSA)

Status on 2026-10-24 (EQ-B-0070): built and tested; **off by default**. Nothing in this document moves a base
number. The 0.2.1 base (VaR99 67.39, ES99 89.29, EL 0.80, L-VaR99 72.67) is unchanged; a 20,000-path run at
as_of 2026-10-23 gives the same metrics to the last digit before and after, with and without the proposed hook
applied while it is switched off.

## Purpose

Show, per country, where public debt is heading over five years and how uncertain that is, and turn it into one
number that can be read next to the PD. The module has two parts in `econquest/engine/dsa.py`:

- The existing part (roadmap 3.1, 3.2): `dsa_table`, `stochastic_dsa`, reserve adequacy (IMF ARA) and the
  scorecard feeds 1.1, 1.2, 2.1 (`outputs/dsa.csv`, `dsa_fan.csv`, `dsa_scorecard_feeds.csv`). Unchanged by
  EQ-B-0070 (its outputs were hashed before and after the refactor and are identical).
- The EQ-B-0070 part: correlated shocks to growth, rates, primary balance and FX; a gross financing need (GFN) path;
  a per-country DSA signal; an output for country notes; and two pipeline hooks that are off.

## Where it sits in the pipeline

Today the new part is not called by `run_pipeline`. It runs as library functions:

```
weo, src = dsa.load_weo_as_of("data", as_of)                    # latest WEO pull dated <= as_of
run = dsa.run_dsa_paths(u, settings, weo, inputs=dsa.load_dsa_inputs("data/dsa_inputs.csv"), as_of=as_of)
sig = dsa.dsa_signal(run, settings)                             # or dsa.dsa_signal_table(...) in one call
dsa.write_dsa_paths(run, sig, "outputs")                        # dsa_paths.csv, dsa_signal.csv, dsa_paths_meta.json
```

The proposed hook (appendix) calls `dsa.dsa_signal_hook(u, settings)` after `pd_default` is set, passes the
table to `compute_signals` as signal 26 when `dsa.signal_enabled` is true, and passes it to `dsa.pd_overlay`,
which changes `pd_default` only when `dsa.pd_overlay_enabled` is true and `dsa.pd_logit_weight` is not zero.

Downstream: country notes (Team C) can read `outputs/dsa_paths.csv` and `outputs/dsa_signal.csv`. Today they
read the older `dsa.csv` and `dsa_fan.csv`, which keep their shape.

## Assumptions

Debt dynamics, in % of GDP, one year at a time (`debt_step`):

    d(t+1) = d(t) x (1 + a x dep) x (1 + r) / (1 + g) - pb + sfa

with r the effective nominal interest rate (WEO interest / last year's debt ratio, as `debt_history` defines it),
g nominal GDP growth, a the FX share of debt (indicator 1.5), dep the depreciation of the local currency against
the US$, pb the primary balance and sfa the stock-flow adjustment. With r = g, pb = 0, dep = 0, sfa = 0 the ratio
does not move (tested).

GFN (`gfn_step`) = r x d(t)(1 + a x dep) + d(t)(1 + a x dep) / average maturity - pb. Amortisation is the stock over
the average maturity in `data/dsa_inputs.csv`, as in the existing `gfn_pct_gdp`. The first-year baseline GFN is
within 0.5 pp of the existing `gfn_pct_gdp` for 14 of 17 countries; the gaps are Singapore (27.6 vs 17.0: WEO has
no interest data, so the spread-based default rate is used), Argentina (13.3 vs 11.0) and Zambia (16.0 vs 15.4),
both from revaluing the FX share.

Baseline: WEO projections for g, r, pb; expected depreciation is inflation minus 2.5% (US), floored at 0; the
baseline sfa is the residual that makes the model path equal the WEO debt projection (shared with the existing
fan through `_baseline_components`).

Shocks (`simulate_dsa`): four correlated shocks (g, r, pb, fx), AR(1) with persistence 0.5, 0.5, 0.5 and 0 (FX
shocks iid). r is floored at 0, g and dep at -50%, debt at [0, 400]. No separate stock-flow shock (the existing
fan has one; it is left out here so the fan reflects the four named drivers).

Covariance (`shock_covariance`), in order of preference:

1. own history: annual shocks over the 25 years to year0 (first differences of g, r, pb; depreciation less its
   window mean; winsorised at 2.5/97.5%), when at least 8 complete years exist;
2. regional pool: the same shocks pooled over the region's countries that have their own history (at least 16
   country-years);
3. regional default, judgement, not fitted: sd of (g, r, pb, fx) Asia (0.04, 0.008, 1.5, 0.06), LatAm and Africa
   (0.08, 0.015, 2.0, 0.15), other (0.06, 0.012, 1.8, 0.10); correlation g-r -0.1, g-pb +0.3, g-fx -0.3,
   r-fx +0.3, pb-fx -0.1, r-pb 0.

Every sd is capped (g 15 pp, r 3 pp, pb 4 pp, fx 35%), correlations kept, and the matrix made positive semi-definite.

Signal (`dsa_signal`): P(debt above the threshold in the final year), P(GFN above the threshold in any year), and
`dsa_score` = 100 x the larger. Thresholds are the IMF MAC DSA (2013) high-scrutiny benchmarks: emerging markets
70% debt / 15% GFN; advanced economies 85% / 20% (`advanced_economies`: Japan, Singapore, South Korea).

Settings (`settings["dsa"]`, none in `data/assumptions.json` today; code defaults in `DSA_DEFAULTS`):
`signal_enabled false`, `pd_overlay_enabled false`, `pd_logit_weight 0.0`, `debt_threshold 70`,
`gfn_threshold 15`, `debt_threshold_advanced 85`, `gfn_threshold_advanced 20`, `advanced_economies [...]`,
`paths 10000`, `seed 7`, `horizon 5`, `default_maturity_yrs 7`, `inputs_path null`, `data_dir "data"`.

PD overlay (`pd_overlay`): logit(pd) + pd_logit_weight x (dsa_score - 50) / 50, capped at 0.99. A score of 50 leaves
the PD alone: a score of exactly 50, a PD of 0 or a country without a DSA row passes through unchanged.
Weight 0 is a no-op. Signal 26 is NaN (not 0) for a country without a DSA row (Venezuela).

## Data

- WEO: `data/live/vintages/2026-10-23/raw_weo.csv` (18 countries, 1980-2031, 10 series). `load_weo_as_of` picks
  the latest vintage dated on or before as_of, else `data/live/raw_weo.csv` if `feeds.json` says it was retrieved
  on or before as_of, else it refuses. It tags the frame with the pull date (`attrs["retrieved"]`); the pipeline
  hook uses the same loader. Before the EQ-B-0070 review the hook read `Universe.weo_raw`
  (`data/live/raw_weo.csv`, retrieved 2026-10-23) whatever the as_of.
- FX history: implied by WEO, NGDP (local currency) / NGDPD (US$). No separate FX file.
- `data/dsa_inputs.csv`: average maturity per country (analyst estimates, "Claude estimate 2024-25").
- Indicator 1.5 (FX share of debt) from `data/indicators.csv`, mostly seed values.
- Venezuela has no WEO debt series and gets no row. Singapore has no WEO interest data, so its own-history
  window is empty and it uses the Asia pool.

## Estimation or calibration

Only the shock covariance is estimated, by sample covariance on each country's own history (16 of 17 countries;
Singapore uses the Asia pool of 180 country-years). Median sd across countries: g 5.2 pp, r 0.8 pp, pb 1.9 pp,
fx 6.6%. Argentina and Zimbabwe hit the g and fx caps; Belize (peg) has an fx sd of 0.1%. The regional defaults,
persistence, caps and thresholds are judgement. Nothing is fitted to default outcomes; the signal has no backtest.

## Outputs and how they are used

As of 2026-10-23 (year0 2025, 10,000 paths, seed 7; written to `outputs/`):

| Country | Debt now | Median 2030 | P90 2030 | P(debt > thr) | Peak GFN baseline | P(GFN > thr) | Score |
|---|---|---|---|---|---|---|---|
| Brazil | 93.3 | 105.0 | 131.4 | 0.98 | 21.5 | 1.00 | 100 |
| China | 98.6 | 119.6 | 144.3 | 1.00 | 24.6 | 1.00 | 100 |
| Japan | 204.8 | 190.5 | 218.8 | 1.00 | 24.8 | 1.00 | 100 |
| Singapore | 165.7 | 169.1 | 210.2 | 1.00 | 28.1 | 1.00 | 100 |
| Senegal | 127.7 | 99.1 | 122.5 | 0.98 | 20.3 | 1.00 | 99.7 |
| Pakistan | 72.8 | 59.7 | 72.7 | 0.15 | 15.7 | 0.81 | 80.8 |
| India | 84.3 | 77.4 | 93.4 | 0.74 | 14.5 | 0.64 | 73.8 |
| Zambia | 100.6 | 61.2 | 98.6 | 0.37 | 16.0 | 0.69 | 68.8 |
| Belize | 66.9 | 66.3 | 93.7 | 0.43 | 8.6 | 0.03 | 42.5 |
| Malaysia | 70.5 | 66.0 | 91.8 | 0.41 | 12.3 | 0.13 | 40.9 |
| Colombia | 59.9 | 65.9 | 85.4 | 0.38 | 13.0 | 0.23 | 38.3 |
| Argentina | 80.1 | 54.1 | 97.5 | 0.29 | 13.3 | 0.36 | 35.9 |
| Philippines | 59.1 | 58.5 | 72.6 | 0.14 | 10.8 | 0.01 | 14.3 |
| Nigeria | 36.1 | 32.0 | 55.4 | 0.03 | 7.3 | 0.06 | 5.7 |
| Zimbabwe | 38.0 | 24.6 | 47.7 | 0.02 | 2.7 | 0.00 | 1.8 |
| Vietnam | 30.5 | 24.2 | 38.7 | 0.00 | 5.0 | 0.00 | 0.1 |
| South Korea | 52.4 | 49.1 | 57.3 | 0.00 | 6.5 | 0.00 | 0.0 |

The 10-90 band of 2030 debt is 16 to 74 pp wide (median 43 pp).

**Contract for country notes (Team C, proposed C13; schema `eq-dsa-paths/1`):**

- `outputs/dsa_paths.csv`, one row per country and year (year0+1 .. year0+5): `country, iso, year, debt_weo,
  debt_baseline, debt_p10, debt_p25, debt_p50, debt_p75, debt_p90, gfn_baseline, gfn_p10, gfn_p25, gfn_p50, gfn_p75,
  gfn_p90, g_baseline, r_baseline, pb_baseline, fx_dep_baseline, sfa_baseline`. Debt, GFN, pb, sfa in % of GDP;
  g, r, fx_dep in %.
- `outputs/dsa_signal.csv`, one row per country: `country, iso, as_of, year0, debt_now, debt_p50_end,
  debt_p90_end, debt_threshold, p_debt_above_threshold, gfn_baseline_peak, gfn_p90_peak, gfn_threshold,
  p_gfn_above_threshold, dsa_score, r_minus_g_baseline, fx_share, cov_source, n_hist`. Probabilities 0-1; score
  0-100, higher is worse.
- `outputs/dsa_paths_meta.json`: as_of, year0, horizon, paths, seed, percentiles, the WEO file used, per-country
  covariance source and shock sds, and the two column lists.
- Written only by `dsa.write_dsa_paths(run, signal, out_dir)`. The `debt_*` columns map to the existing
  `svg_fan` inputs as debt_pNN -> pNN and debt_weo -> baseline_weo.

## Limitations and known gaps

- Levels drive the score. Japan and Singapore score 100 even on the advanced-economy thresholds. Singapore's gross
  debt funds CPF assets, not deficits; Japan's is held at home. The score says "above the benchmark", not "near
  default". Read it with the reserve and market columns.
- The r used is interest over last year's debt ratio and the equation divides by (1 + g); this understates
  interest slightly. The baseline sfa absorbs the gap, so the baseline still follows WEO, but shocked paths carry it.
- FX history is implied from WEO annual GDP in two currencies; it misses intra-year moves and redenominations.
- The FX share (1.5) and maturities are seed or analyst values, so the FX channel and GFN are only as good as them.
- Expected depreciation from the inflation differential is wrong for pegs (Belize, Senegal) in a crisis year.
- No contingent liabilities, no debt-limiting feedback (a higher rate does not raise the spread), no fiscal
  reaction function, no stock-flow shock.
- The signal has no track record. It has not been compared with defaults or with the PD.
- The pipeline hook reads the WEO through `load_weo_as_of(dsa.data_dir, as_of)` (default `data`, relative to the
  working directory), not `Universe.weo_raw`, whose pull date is unknown. Before the first pull (2026-10-23) it warns
  and returns no signal. `run_dsa_paths` refuses a frame tagged with a later pull date and warns on an untagged one.

- 1.2 (PPG external debt service over 24 months, % of reserves) needs one World total per year from World Bank IDS
  `DT.TDS.DPPG.CD`. The IDS API returns one row per creditor (counterpart area). EQ-B-0084 (HO-20261024-A-B-012):
  when the World Bank frame has a counterpart column (`counterpart`, `counterpart_area`, ...; any case) only the
  World rows (`WLD`, `World`, `1W`, `W00`) are used. Without that column, any year with more than one row is refused:
  1.2 is NaN, no feed row is written, and the reason goes to `table.attrs["fx_debt_service_notes"]` and to
  `dsa_diagnostics.json` (`fx_debt_service_note`). The old rule ("max if it is at least 60% of the sum, else the sum")
  is gone: with the all-creditors row present it took the sum and double counted; without it, it could take one
  creditor as the total. The 30%-of-max incomplete-year rule is kept. On the 2026-10-23 pull (no counterpart column,
  up to 35 rows a year) 1.2 is refused for all 13 countries with IDS data until Team A's WorldBankFeed fix
  (EQ-A-0062) lands. Signal 26 and the base do not use 1.2.

## Sensitivity

At 10,000 paths, changing the seed moves no score by more than 1.0. Debt threshold 60 instead of 70: mean score
53.1 -> 60.9, countries at 50 or more 8 -> 11. Threshold 80: 48.8, 8 countries. GFN threshold 20 instead of 15:
46.6, 6 countries. With the hook on (signal and overlay, weight 0.5, maturity default 7 for all countries since no
inputs path), the 20,000-path base moved to VaR99 69.06, ES99 91.62, EL 1.36; this is an illustration only.

## Benchmarks and evidence

The method follows the IMF market-access-country DSA (2013 guidance; 2021 revision for the fan): baseline from the
WEO, stochastic fan from joint historical shocks, GFN and debt benchmarks. No IMF fan was compared number by number.

## Open items for review

1. AGENT-08: apply the hook in the appendix (pipeline.py, signals.py) if wanted; it is a no-op while off.
2. Sam (Tier 1, before enabling): whether the score may move PDs (`pd_overlay_enabled`, `pd_logit_weight`), and
   whether signal 26 should join the dashboard risk keys. No change has been proposed through `econquest change`.
3. Team C: switch the country-note fan to `dsa_paths.csv` and show the GFN band and the score (contract above).
4. Set `dsa.inputs_path` to `data/dsa_inputs.csv` when the hook is enabled, or the pipeline uses a 7-year maturity
   for every country.
5. Backtest the score against the default panel (`validation/hazard_panel`) before giving it any PD weight.
6. Add CLI output (`econquest dsa` writing `dsa_paths.csv`); cli.py is Team C's.

## Change record

2026-10-24, EQ-B-0070 (AGENT-03). New: `debt_step`, `gfn_step`, `fx_depreciation`, `shock_history`,
`shock_covariance`, `default_cov`, `simulate_dsa`, `run_dsa_paths`, `dsa_signal`, `dsa_signal_table`,
`dsa_signal_hook`, `pd_overlay`, `load_weo_as_of`, `write_dsa_paths`. Refactor: the baseline block of
`stochastic_dsa` moved to `_baseline_components` (outputs hashed identical). Tests: `tests/test_dsa_paths.py`.

2026-10-24, EQ-B-0070 review (AGENT-09). The hook no longer reads `Universe.weo_raw` (look-ahead at an early
as_of) and uses `load_weo_as_of`; `run_dsa_paths` refuses a later pull; signal 26 is NaN without a DSA row
(`signals.py`, one line); `pd_overlay` passes a neutral score or a zero PD through unchanged; written CSV text
cells go through `_csv_safe`. Regression tests added. With the DSA hooks stubbed out the 20k base equals the run
with them in place, so these changes move no base number.

2026-10-24, EQ-B-0084 (AGENT-03, HO-20261024-A-B-012). `ppg_debt_service_detail` (new) and `ppg_debt_service_24m`
keep only World rows when a counterpart column exists and otherwise refuse multi-row years; the max/sum heuristic
is removed. Tests: `tests/test_dsa_ids_creditor.py` (synthetic); `test_dsa_feed_provenance.py` now expects no 1.2
from the shipped pull. Base numbers unchanged.

## Appendix: pipeline hook (applied by AGENT-08 2026-10-24, off by default)

Tested on a copy of the package: 20,000-path base identical with the hook off; `tests/test_signals.py`,
`test_signals_persist.py`, `test_dsa_paths.py` pass on the patched copy.

```diff
--- a/econquest/engine/pipeline.py
+++ b/econquest/engine/pipeline.py
@@ -14,10 +14,11 @@
 from ..scorecard import score_universe, Scorecard
 from .common import logistic_curve
 from .gpr import run_gpr
-from .signals import SIGNAL_NAMES, compute_signals, trade_activation, dashboard_table
+from .signals import SIGNAL_NAMES, OPTIONAL_SIGNAL_NAMES, compute_signals, trade_activation, dashboard_table
 from . import layer1_hazard as L1, layer2_bayesian as L2, layer3_regime as L3, layer4_severity as L4, layer5_copula as L5, layer6_montecarlo as L6
 from . import regime_hmm as RH
 from . import bond_rv as BRV
+from . import dsa as DSA
 
 
 @dataclass
@@ -69,7 +70,7 @@
                 "dashboard": None if self.dashboard is None else self.dashboard.reset_index().to_dict(orient="records"),
                 "gpr_global": self.gpr_global,
                 # additive (contract C5, EQ-B-0030): names for the store's signals table, pillar scores for country notes
-                "signal_names": None if self.signals is None else {int(k): SIGNAL_NAMES[int(k)] for k in self.signals.index},
+                "signal_names": None if self.signals is None else {int(k): SIGNAL_NAMES.get(int(k)) or OPTIONAL_SIGNAL_NAMES.get(int(k), f"signal {k}") for k in self.signals.index},
                 "pillars": self.scorecard.pillar_final.to_dict()}                      # {country: {pillar: score}}
 
 
@@ -133,6 +134,10 @@
     country["pm_default"] = prior["pm_default"]; country["tau_market"] = prior["tau_market"]
     country["pd_final"] = p_final
     country["pd_default"] = np.minimum(0.99, p_final * mult["pd_mult"])
+    # EQ-B-0070, off by default: DSA signal table (dsa.signal_enabled) and optional PD overlay (dsa.pd_overlay_enabled,
+    # dsa.pd_logit_weight); pd_overlay returns the same Series when off
+    dsa_sig = DSA.dsa_signal_hook(u, settings)
+    country["pd_default"] = DSA.pd_overlay(country["pd_default"], dsa_sig, settings)
     country["pd_model"] = np.minimum(0.99, post["pd_post"] * mult["pd_mult"])          # before the market prior, regime-adjusted
     country["pm_gap_pp"] = (country["pd_model"] - country["pm_default"]) * 100
     for peril, key in (("Transfer and convertibility", "pd_tc"), ("Expropriation", "pd_ex"), ("Political violence", "pd_pv"), ("Sanctions", "pd_sa")):
@@ -167,7 +172,8 @@
     # Signals, playbook activation, dashboard
     signals = activation = dash = None
     if gpr_country is not None and u.playbook is not None:
-        signals = compute_signals(u, settings, sc, country, gpr_country, gpr_global, arb)
+        signals = compute_signals(u, settings, sc, country, gpr_country, gpr_global, arb,
+                                  dsa=dsa_sig if settings.get("dsa", "signal_enabled", default=False) else None)
         activation = trade_activation(u, u.playbook, signals)
         dash = dashboard_table(u, settings, country, signals, activation, u.playbook, gpr_country, arb)
     timings["signals"] = time.perf_counter() - t
@@ -176,6 +182,7 @@
     diagnostics = {"global_regime": gstate, "degrees_of_freedom": df, "share_not_calm": float((regime != "Calm").mean()),
                    "global_stress_weight": gweight, "global_share": L3.global_share(regime, settings),
                    "bond_rv": None if bond_rv_tbl is None else bond_rv_tbl.to_dict("records"),
+                   "dsa_signal": None if dsa_sig is None else dsa_sig.to_dict("records"),
                    "mean_latent_correlation": float(corr.to_numpy()[off].mean()),
                    "tail_dependence_at_mean_corr": L5.tail_dependence(float(corr.to_numpy()[off].mean()), df),
                    "tail_dependence_gaussian_equivalent": 0.0, "scenario_override": settings.scenario_override,
--- a/econquest/engine/signals.py
+++ b/econquest/engine/signals.py
@@ -12,6 +12,7 @@
                 15: "Market complacency", 16: "Distress and restructuring", 17: "Deteriorating momentum", 18: "Official backstop stress",
                 19: "Market overpricing risk", 20: "Benign carry", 21: "Low-risk calm market", 22: "Geopolitical risk spike (GPR)",
                 23: "Global geopolitical risk-off (GPR)", 24: "GPR headline spike in a low-exposure calm market", 25: "Prediction market gap"}
+OPTIONAL_SIGNAL_NAMES = {26: "Debt sustainability (DSA)"}   # EQ-B-0070: row present only when a DSA table is passed
 INSTRUMENT_FIELD = {"CDS": "CDS", "Eurobond": "Eurobond", "FX": "FX", "FX options": "FX options", "Local rates": "Local rates", "Equity": "Equity"}
 RULE2_OPS = {"<": np.less, "<=": np.less_equal, ">": np.greater, ">=": np.greater_equal}
 DEFAULT_COMPLACENCY_SCALE_LOG2 = 0.4 / np.arctanh(0.4)   # 0.944: 70/30 crossing at ratio 2**0.4 = 1.32x, as in the old linear form
@@ -39,13 +40,14 @@
 
 
 def compute_signals(u: Universe, settings: Settings, sc, country: pd.DataFrame, gpr_country: pd.DataFrame, gpr_global: dict,
-                    arbitrage: pd.DataFrame) -> pd.DataFrame:
+                    arbitrage: pd.DataFrame, dsa: pd.DataFrame | None = None) -> pd.DataFrame:
     sg = settings["signals"]; pr = settings["probability"]; pm = settings["prediction_markets"]
     cscale = float(settings.get("signals", "complacency_scale_log2", default=DEFAULT_COMPLACENCY_SCALE_LOG2))
     s = sc.indicator_scores; pf = sc.pillar_final
     prof = u.countries.set_index("country").loc[u.names]
     ind = u.indicators.set_index("id")
-    out = pd.DataFrame(index=list(SIGNAL_NAMES), columns=u.names, dtype=float)
+    out = pd.DataFrame(index=list(SIGNAL_NAMES) + ([26] if dsa is not None else []), columns=u.names, dtype=float)
+    dsa_score = None if dsa is None else dsa.set_index("country")["dsa_score"]   # EQ-B-0070 signal 26, 0-100
     best_edge = arbitrage.groupby("country")["net_edge_pp"].max() if len(arbitrage) else pd.Series(dtype=float)
     for c in u.names:
         comp = float(country.at[c, "composite"]); regime = country.at[c, "regime"]
@@ -69,6 +71,8 @@
         v[24] = v[22] if (regime == "Calm" and v[14] < 50) else 0.0
         edge = best_edge.get(c, np.nan)
         v[25] = 0.0 if pd.isna(edge) else min(100.0, max(0.0, 50 + edge * 10 / pm["min_net_edge_pp"]))
+        if dsa_score is not None:
+            v[26] = float(dsa_score.get(c, 0.0))
         for k, val in v.items():
             out.at[k, c] = float(val)
     return out
```
