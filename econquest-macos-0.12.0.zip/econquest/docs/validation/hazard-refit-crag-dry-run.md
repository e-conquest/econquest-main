# Hazard refit dry run: current vs CRAG default events (EQ-B-0087)

2026-10-25, as_of 2026-10-23. Figures in `hazard-refit-crag-dry-run.json`. Event definitions: see
`hazard-panel-crag.md`.

**This is a dry run.** The vintaged WEO history (`data/panel/weo_history.csv`) has not landed (the IMF downloads
failed on Sam's Mac; Team A is moving to IMF SDMX). No AUC or Brier below is a model result.

- **D1** uses real predictors, but only what is in the repo: `data/live/raw_weo.csv` (18 desk economies, latest
  WEO, **not point in time**), rows 1981-2024, lag 1.
- **D2** runs the full refit chain (`hazard_refit.run_refit`) on a **SYNTHETIC** vintaged WEO history (values
  invented by `make_synthetic_panel`, re-keyed to 198 real ISO codes: the built-in economy list plus CRAG's
  universe). The predictors are unrelated to the defaults, so only the event counts, the preflight checks and the
  chain are meaningful. Rows 2007-2024, labels 2008-2025.

## Event starts per year

All countries in each file, as known at as_of:

| Start year | 08 | 09 | 10 | 11 | 12 | 13 | 14 | 15 | 16 | 17 | 18 | 19 | 20 | 21 | 22 | 23 | 24 | 25 | Total |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| current list | 2 | 0 | 1 | 0 | 2 | 2 | 1 | 1 | 2 | 2 | 1 | 0 | 6 | 0 | 6 | 1 | 0 | 0 | 27 |
| CRAG as imported | 3 | 3 | 2 | 2 | 3 | 3 | 1 | 4 | 6 | 2 | 4 | 1 | 4 | 3 | 10 | 2 | 0 | 0 | 53 |
| CRAG, crag_v1 | 3 | 2 | 2 | 2 | 3 | 3 | 1 | 4 | 4 | 2 | 3 | 1 | 4 | 2 | 10 | 2 | 0 | 0 | 48 |

In the D2 panel (countries with a WEO row) the counts per label year are the same as these: every country with a
start has a row.

## D2: full chain, SYNTHETIC predictors

| | current (default) | CRAG, crag_v1 (`--events crag`) |
|---|---|---|
| outcome | PREFLIGHT FAILED | NOT CLEARED |
| failing preflight | episodes_sourced (memory list has no source) | none |
| country-years at risk / countries | 3,390 / 193 | 3,187 / 194 |
| ever defaulted (share) | 71 (0.37) | 95 (0.49, limit 0.55) |
| events (gate: 30 or more) | 27: FAIL | 48: pass |
| OOS AUC (gate 0.75) | 0.441 (SYNTHETIC) | 0.524 (SYNTHETIC) |
| OOS Brier vs trailing base | 0.0095 vs 0.0094 (SYNTHETIC) | 0.0151 vs 0.0151 (SYNTHETIC) |
| event rule in the report | current: floor 0, cure 1; 108 spells, 105 after merging | crag: floor USD 10m, cure 2; 210 spells, 208 after the floor, 179 after the rule |

AUC near 0.5 is what invented predictors should give: the chain does not manufacture signal. Two facts carry over
to the real run. The current list cannot pass the event count or the sourcing check. CRAG with crag_v1 passes both
and every other preflight check; the ever-defaulted share (0.49) is close to the 0.55 limit, so a WEO history with
fewer than about 173 economies would fail `not_selected_on_outcome` (a first try on CRAG's own universe, 159
economies in the panel, gave 0.60 and failed).

## D1: real desk predictors, not point in time

| | current | CRAG as imported | CRAG, crag_v1 |
|---|---|---|---|
| rows / events / countries | 391 / 9 / 15 | 372 / 11 / 16 | 365 / 10 / 16 |
| OOS AUC (OOS events) | 0.789 (4) | 0.428 (6) | 0.474 (5) |
| OOS Brier vs trailing base | 0.036 vs 0.026 | 0.330 vs 0.024 | 0.309 vs 0.020 |
| gate | NOT CLEARED (events, Brier) | NOT CLEARED (all three) | NOT CLEARED (all three) |

With 4 to 6 out-of-sample events these numbers are noise, and the predictors carry revisions (not point in time).
The desk alone can never meet the 30-event gate; that is why the refit needs the full panel. The CRAG Brier is far
above the base rate because the small fit separates a few events (unstable coefficients), not because CRAG labels
are worse. Do not read a model comparison into D1.

## How it was run

On a local copy of the repo: `hazard_events.build_events` for the counts; D1 with `hazard_panel.panel_from_long` +
`fit_and_validate` + `gate_check`; D2 with `run_refit(data, "2026-10-23", out, weo_history=<synthetic, real ISO>,
events_source="current" | "crag", effect_paths=0, check_runtime=False)`. Script: `EQ-B-0087_dryrun.py` in AGENT-03's
scratch folder (not shipped). The real run is in `hazard-refit-runbook.md`.
