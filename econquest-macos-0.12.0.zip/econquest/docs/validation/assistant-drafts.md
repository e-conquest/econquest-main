# Assistant-drafted research notes (`eq-assistant-drafts/1`)

Date: 2026-10-27. Ticket EQ-B-0148 (AGENT-03), PI-15. Code: `econquest/validation/assistant_drafts.py`.
Tests: `tests/test_assistant_drafts.py` (deterministic stub provider, no network, no model). Depends on the QA gate
(EQ-B-0146, `assistant_qa`, schema `eq-assistant-qa/2`), the tool registry (EQ-B-0145, `assistant_tools`), Team A's
context chunks (EQ-A-0143), Team C's provider (EQ-C-0170) and research archive (EQ-C-0154), and the analyst overlay
(EQ-B-0138). Team C owns the CLI and the editor (EQ-C-0172); the API is handed to them in the B-0148 handoff.

The model drafts a note; an analyst edits and signs it. The model never writes a number: every figure in a draft
is a slot `{{cite_id.field}}` that the QA gate renders from a tool row or context chunk. Nothing here runs in
`econquest run`, and nothing feeds a PD, a loss, a limit or the scorecard. The base run is unchanged: at 20,000 paths
it gives 66.95612571109443 / 89.00003057231508 / 4.098636048964449 / 72.23763153780678, and replicate gives PASS 141.

## How the host uses it

```python
from econquest.presentation import archive as A          # the host (Team C) imports presentation, not validation
from econquest.validation import assistant_drafts as D
from econquest.validation import assistant_tools as AT

arc = D.ArchiveAPI(A, out_dir="outputs", data_dir="data")
ctx = AT.ToolContext(data_dir="data", as_of="2026-10-23"); ctx.pin_run(run, universe, settings)   # host pins the run
rows = D.tool_rows(ctx, [("attribution", {"run_id": run.run_id, "as_of": "2026-10-23", "by": "country"})])
chunks = build_context("data", kinds=["archive", "run_output"], country="BRA", as_of="2026-10-23")  # Team A
model = D.ModelInfo(name="gemma4:12b", weights_digest="sha256:...", seed=7, backend="openai_compat", temperature=0.0)
r = D.create_draft(provider, archive=arc, product="country_note", subject="Brazil", run=D.RunStamp.of(ctx.runs[run.run_id]),
                   model=model, tool_results=rows, chunks=chunks, as_of="2026-10-23", at="2026-10-23T12:00:00Z",
                   requested_by="Alice Analyst")
# r["status"] "saved" -> r["text"] is the rendered draft; "refused" -> r["text"] is the gate's refusal text
src = D.editable_text(arc, r["item_id"])                 # the slot text the analyst edits
D.edit_draft(arc, r["item_id"], new_src, by="Alice Analyst", at="2026-10-23T13:00:00Z", reason="tightened summary")
D.sign_draft(arc, r["item_id"], by="Alice Analyst", at="2026-10-23T14:00:00Z", data_dir="data")
D.release_check(arc, r["item_id"], client_mode=False, at="2026-10-23T15:00:00Z")   # {"audience": "internal", ...}
D.list_drafts(arc); D.load_draft(arc, item_id, version=None); D.audit_trail("outputs", item_id); D.verify("outputs", arc)
```

`draft_note(complete, *, country, product="country_note", chunks, tool_results=(), section=None) -> str` is the same
prompt for a host that gates and stores the text itself (the signature Team C assumed in HO-20261027-C-B-001; the
module is `assistant_drafts`, plural). `complete(messages) -> str` is the host's buffered provider call.

All functions are plain functions. Every step returns a dict (`status`, `ok`, `item_id`, `version`, `text`, ...) or
raises `DraftError` with a message that is safe to show (no model text).

## 1. Draft

- Products: `country_note` (sections Summary, What drives the risk, House view, What to watch) and `weekly_brief`
  (one section: `section` is one of book, limits, pd_movers, score_movers, regime, events, stress, house_view, ideas,
  the weekly brief manifest's sections).
- Inputs: the pinned run's stamp (`RunStamp` run_id, as_of, code_hash, data_hash; from a PinnedRun, a RunResult or a
  run summary), the tool results (B-0145 `call_tool` results; refused or error results are dropped) and the context
  chunks (A-0143 `Chunk` objects or dicts). Chunks of earlier assistant drafts (source id containing
  `-assistant-draft-`) are dropped, so a model draft is never context for another draft.
- The prompt: system prompt with the slot rules of the gate (HO-20261027-B-C-001 points 12 and 18), the task and the
  section headings, each chunk and each tool result as `assistant_tools.model_view` shows it (numbers only as the
  slot to write, with what the gate will show). `provider.complete(messages, max_tokens=, temperature=)` is called
  once; the reply is buffered.
- Refused before the model is called (`DraftError`): no explicit `as_of` or `at`, a run after `as_of`, any row or
  chunk dated after `as_of` (point in time), no context, a `ModelInfo` without name, weights digest or integer seed,
  a requester who is not a named person, SYNTHETIC outside pytest or a marked sandbox, a step dated before the last
  audit row.

## 2. Gate; refused drafts are not saved

The reply goes through `assistant_qa.check_draft` against exactly the rows and chunks in the prompt (the JSON copies
that are stored with the draft, so the gate at edit and sign time sees the same inputs). Also refused:
`model_analyst_marker` (the model wrote the analyst-entered marker) and `model_mismatch` (the provider reports a model
name other than `ModelInfo.name`). A refused draft writes nothing to the archive; the audit trail gets a
`draft_refused` row with the codes, the model record, the prompt and reply sha256 and the run id, never the text.
The caller gets the gate's refusal text.

## 3. A passing draft is a new archive version

Item id: `<product>-<subject>-assistant-draft-<as_of>`, e.g. `country_note-brazil-assistant-draft-2026-10-23`
(`weekly_brief-weekly-pd-movers-assistant-draft-2026-10-23`). It is a separate archive item from the published
note, so a draft is never the latest version of a published note. The first version is `archive.add`, every later
one `archive.correct`; earlier versions are never touched. Each version holds:

| File | Content |
|---|---|
| `note.md` | Header (title, `Status: DRAFT (model-assisted, not validated). Internal only.`, run, as_of, model, weights digest, seed, prompt sha256; on a signed version the sign line) and the gate's rendered text: label line, body with slots rendered, Figures list, Analyst-entered figures (if any), Citations. The archive adds its disclosure block |
| `draft.json` | The record: `schema`, `item_id`, `version`, `parent_version`, `status` DRAFT or SIGNED, `label` "model-assisted, not validated", `draft_kind`, `section`, `subject`, `country`, `as_of`, `run` {run_id, as_of, code_hash, data_hash}, `model` {name, reported_name, weights_digest, seed, backend, temperature, prompt_sha256, reply_sha256, provider}, `author` (model or analyst, with requester / editor and time), `source_text` (the slot text), `rendered_sha256`, `figures` (the gate's Figures lines), `analyst_entered`, `qa` (verdict, codes, reasons, citations), `context` (tool results, chunks, overlay entries), `overlay_entries`, `changes`, `signed`, `synthetic`, `audience` "internal" |

The archive licence label is always `internal-only`. The archive's research QA gate (EQ-C-0163) runs on every
version, as on any archived product. `draft.json` is read back from the version folder and checked against the
manifest's sha256 before use.

## 4. Edit and sign

**Edit** (`edit_draft`): the analyst edits the slot text (`editable_text`). The edit is gated against the stored
context like a draft; a refused edit is not saved (audit `edit_refused` with the text's sha256). A number typed by
hand is refused (`model_number`) unless it is

- a slot of a row or chunk in the context, or
- marked `[[analyst-entered: <text> | source: <citation>]]` (source at least 3 characters, at most 20 per version).
  It is shown as `<text> (analyst-entered; source: <citation>)` and listed under "Analyst-entered figures" (not
  checked by the QA gate). Only an edit can carry the marker.

Every saved edit is a new DRAFT version (audit `edit_saved`); editing a SIGNED note makes a new DRAFT that must be
signed again. The editor is a named person (below), never the model.

**Sign** (`sign_draft`): writes a SIGNED version of the latest DRAFT version. Refused (audit `sign_refused`) when:

- the signer is not a named person (review HO-20261027-B-B-020 D3, fail closed): fewer than two name words of
  letters only, control or markup characters, or longer than 120 characters; or the name, casefolded with accents folded (NFKD,
  combining marks removed: Gémma and Ġemma read as gemma, José García still signs; review B-B-021 R2) and every
  non-letter removed (a name with letters outside the Latin script after that step is refused unless the signer is
  a registered user) ("G e m m a", "Gemma4", "Claudebot" all become one letter string), contains a model or vendor
  family (`MODEL_FAMILIES`: gemma, claude, gpt, chatgpt, llama, qwen, mistral, deepseek, copilot, gemini, openai,
  anthropic, ollama, vllm, assistant, llm); or a name word is phi, bot, ai, model, stub, system, auto, automatic or
  econquest (`MODEL_TOKENS`, "A.I." counts as ai; the short families phi, bot and ai are whole words only, so Sophie,
  Philip and Abbott pass); or the letters contain the draft's own model name or backend, or
  any letter run of three or more of it (gemma from gemma4:12b). The model never signs. The same rule applies to
  `requested_by` and to an editor;
- users.json four-eyes cannot be checked: `sign_draft` uses its `data_dir` argument, else the ArchiveAPI's
  `data_dir`; with neither, or when users.json cannot be read, it refuses (D1). When four-eyes is enforced
  (`ops.identity.enforced` on the governed registry), the signer must be a registered active user (the user id is
  recorded). **Lead decision (2026-10-27):** a person registered as active in users.json may sign even when
  the name trips the family or token check (Gemma Smith, Claude Martin). Two things still refuse them: the name
  containing the draft's own model name or backend (Gemma Smith cannot sign a gemma4:12b draft), and not being
  registered (an unregistered or inactive name gets the strict rule). The override is for signing only;
  `requested_by` and editors always get the strict rule;
- the latest version is already SIGNED;
- the gate on the latest version is not `pass` (removals such as an unsupported house stance must be edited out);
- the note changes an overlay score or a stance without the overlay's four-eyes (next paragraph).

One analyst signs a draft; the signer may be the analyst who edited it.

**Overlay and stance.** A note changes an overlay score or a stance when its text (everything but slots, including
the text and the source of every analyst-entered marker, review D2) names an overlay or notches (any case), or names a house stance (Defensive, Neutral, Constructive, in any case:
"defensive" and "DEFENSIVE" count, review HO-20261027-B-B-021 R1) that no row or chunk in its context states (`change_claims`). Such a note is signed only when every change is an analyst-overlay entry
(EQ-B-0138) declared on an edit (`overlay_entries=["OVL-0001"]`, with `overlay_root` and `overlay_enabled`) and, at
signing, *active* in the overlay ledger for the note's country: added by its author with `add_entry` and approved by
someone else with `approve_entry` (author != approver, or the logged EXC path). The overlay's four-eyes is applied by
the overlay module itself, unchanged; signing never adds, approves or changes an overlay entry. While the overlay is
off, no declared entry can be found, so such a note cannot be signed (fail closed). Declared entries are citable in
the note (`[cite:OVL-0001]`, labels only: the gate shows no overlay number).

## 5. Release: internal unless client mode and licences allow

`release_check` returns `audience` "client" only when all hold: client mode on (the host passes
`presentation.research.effective_mode(...) == "client"`; client mode is off and is Sam's decision), the latest
version is SIGNED, its archive licence label is `client-safe`, it has no analyst-entered figure, it is not SYNTHETIC,
and the gate passes with `audience="client"` on the stored context (every row and chunk licence-allowed, A-0144 /
C14). Today a Markdown archive version is always `internal-only`, so every signed note stays internal. Each check is
logged (`release_checked`).

## 6. Audit trail

`<out>/assistant_drafts/audit.jsonl` and `audit.head.json`: one row per step (`draft_saved`, `draft_refused`,
`edit_saved`, `edit_refused`, `signed`, `sign_refused`, `release_checked`) with seq, at, as_of, item_id, version,
actor and detail (codes, hashes, model record, archive ref; never model text). Hash chain as the overlay ledger and
ops/approvals (row_hash = sha256(prev_hash + canonical row)); a row is refused when the chain or head fails or when
its time is before the last row. `verify(out, archive)` checks the chain and head, and that every archive version of
a draft item has its saved / signed row and every such row names an archived version.

## Rules that hold throughout

- **No clock.** `as_of` (YYYY-MM-DD) and `at` (UTC `YYYY-MM-DDTHH:MM:SSZ`, also the archive's `now`) are explicit on
  every call.
- **SYNTHETIC** (`synthetic=True`, or SYNTHETIC in the run id or anywhere in the context) is refused outside pytest
  and a marked sandbox (`mark_sandbox`, `.assistant-drafts-sandbox`); the repo's own outputs/ is never allowed under
  pytest. The flag is kept in the record and in the title and note.
- **Writes.** Only through the archive API and under `<out>/assistant_drafts/` (the audit log and a staging folder
  that is emptied after each archive call). `out` must be the repo's outputs/ (or below it) or outside the repo.
- **Layering.** The module imports validation, ingestion.ledger and (lazily) ops.identity and assistant_tools; never
  presentation or the assistant package (a test checks `sys.modules`). The host passes Team C's archive module to
  `ArchiveAPI`.

## Limits (review HO-20261027-B-B-020)

- **L1, no key on the audit chain.** The chain is the overlay ledger's scheme (sha256 chain plus a head file, no
  keyed seal). Someone with write access can drop trailing rows that name no archive version (sign_refused,
  release_checked, edit_refused, draft_refused) and rewrite the head, or recompute the whole chain with a changed
  actor, and `verify` still passes; only rows naming a version are cross-checked against the archive. A keyed head
  (as ops/ledger_key does for the archive) is a later change.
- **L2, "under pytest" is an environment variable.** SYNTHETIC is allowed when PYTEST_CURRENT_TEST is set (the same
  signal as the other validation modules), so setting it by hand allows SYNTHETIC outside the repo; never in the
  repo's own outputs/, which needs a marked sandbox.
- **L3, removed sentences stay in the record.** A `pass_with_removals` draft or edit is saved with its full slot text
  in draft.json `source_text`, including the sentences the gate removed from the shown text (internal only). Signing
  needs `pass`, so they must be edited out before a note is signed.
- **The signer-name check is lexical.** It folds case and accents, and refuses letters outside the Latin script
  (Coptic or Cyrillic look-alikes) unless the signer is a registered user, but it cannot see spelled-out names ("Chat
  Gee Pee Tee"); it guards against accidents and lazy evasion, not a determined impostor. Registered users
  (users.json) are the stronger control.
- **Single-operator default.** An empty or wrong data folder (no users.json there) gives ops.identity's default
  registry, four-eyes off, so any strict-rule name signs. The host must pass the real data folder.
- **Signer-name rule refuses some real names.** Unregistered people whose name contains a long family string (Gemma,
  Claude, Mistral, ...) cannot sign under that spelling; registered active users can (lead decision, section 4).
  Editing and requesting a draft keep the strict rule for everyone.

## Gaps and open items

1. **Archive entry point lives in presentation.** `econquest.presentation.archive` is the only archive API, so this
   module takes it as an injected object (`ArchiveAPI`) and reads `draft.json` from the version folder by the
   documented layout (checked against the manifest sha256). Asked of Team C in the B-0148 handoff: a
   non-presentation entry point (e.g. `econquest.ops.archive` or `econquest.archive`) with a `read_file(out, id,
   version, name)`, or an agreed adapter. Same gap as HO-20261027-B-A-002 (archive reader for A-0143).
2. **No status in the archive.** The archive manifest has no draft/signed status, so the status is in `draft.json`
   and the item id carries `-assistant-draft-`. Archive search (C-0154) and A-0143 `build_archive` will list draft
   items until they filter them; this module drops them from its own context. Asked of Team C (search, GUI) and Team
   A (build_archive): skip items whose id contains `-assistant-draft-` unless SIGNED, or a status field in the
   manifest. v2+ of a draft item carries the archive's "Corrected on" banner, which here means "new draft version".
3. **Team C's own draft store.** `econquest/assistant/drafts.py` (C-0172) keeps drafts under
   `outputs/assistant/drafts/` and only signed notes in the archive. The PI-15 brief says drafts are archive
   versions; Team C to switch `make_draft` / `save_edit` / `sign` to this API or say why not (handoff).
4. **Weights digest and seed** come from the host (`ModelInfo`); the source of truth is the B-0149 inventory row
   (AGENT-08). The stub has no weights; tests use a fixed digest.
5. **Key-bound signing.** Under enforced four-eyes the signer must be a registered active user, but the sign is not
   bound to the user's key (`--as`); Team C's SEC-C-027 refuses signing outright in that case until it lands.
6. **Research QA on Markdown.** The archive's research QA gate checks HTML tiles and tables, not Markdown sentences;
   the figures in a draft are checked by check_draft instead.
7. **Stance changes** have no ledger of their own; they go through an overlay entry for the country (pillar scores),
   which the house view does not read. A stance mechanism with four-eyes is a later decision (Team B, house view).
