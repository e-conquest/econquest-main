# Model validation: CDS term structure and Eurobond relative value

Date: 2026-10-23; updated 2026-10-24 for EQ-B-0056 (market-store input). Tickets: EQ-B-0048 (curves), EQ-B-0049
(relative value), EQ-B-0056 (Team A market store). Code:
`econquest/engine/cds_curves.py` (`SNAPSHOT_COLUMNS`, `validate_snapshots`, `snapshot_as_of`,
`bootstrap_curve`, `curves`, `par_spread_at`) and `econquest/engine/bond_rv.py` (`fair_spread_bp`,
`country_rv`, `position_rv`, `rv_signal`). Both reuse the leg pricer of `engine/cds.py` (roadmap 3.3).
Parameters read: `cds` (recovery 0.40, risk_free 0.04, frequency 4, reference_tenor_y 5),
`probability.risk_premium_ratio` (2.0) and `risk_premium_exempt_ratings` (SD, D), `market.spread_vol_rel`
(40). Proposed new block `bond_rv` (not in `assumptions.json`; code defaults below reproduce today's run).
Status: diagnostic only. Since EQ-B-0056 `run_pipeline(..., market_dir=<data folder>)` computes the RV table through
`bond_rv.country_rv_pit` when `bond_rv.enabled` is true (default false); without `market_dir` the market spread is
the Country Profile's. No PD, VaR, ES, EL, trade or size changes.
**No real CDS quotes exist in the repository**: `data/cds_quotes.csv` is empty and every curve number
here comes from the SYNTHETIC fixture `tests/fixtures/cds/cds_snapshots_synthetic.csv` (fictional iso3
codes XAA-XDD, source "SYNTHETIC test fixture (not market data)").

## Purpose

1. Replace the single hand-entered spread per country with a risk-neutral hazard curve bootstrapped from a
   point-in-time CDS snapshot (several tenors, par or upfront quotes), giving hazard by tenor, survival and
   risk-neutral 1y and 5y PDs, with diagnostics instead of crashes on bad curves.
2. Read each Eurobond (and CDS) position as rich or cheap against a model-fair spread built from the
   engine's own PD and LGD plus the 0.1.3 default risk premium.

## Curve model (EQ-B-0048)

Reduced form, piecewise-constant forward hazard on (T_{i-1}, T_i], the last hazard extended beyond the
last tenor, interest rates independent of default. ISDA-style simplifications:

| Item | Choice | ISDA standard model |
|---|---|---|
| Premium schedule | regular grid of 1/`cds.frequency` (quarterly), from t=0, no stub | IMM dates, short first stub |
| Day count | year fraction 1/freq | ACT/360 |
| Default timing | mid-period; accrued premium paid on default (half period) | continuous, exact accrual |
| Discounting | flat continuous `cds.risk_free` 0.04, or a supplied zero curve (callable or (t, zero) points, linear, flat at ends) | ISDA swap curve |
| Recovery | quote row `recovery`, else `cds.recovery` 0.40 (reported in `recovery_source`) | 0.40 senior / 0.25 for some EM |
| Upfront | buyer pays `value`% upfront + `running_bp`; solved directly | same |

Recovery: the CDS-pricing convention (`cds.recovery`) is used, not Layer 4's expected LGD, because a quote
is stripped with the recovery the market quotes against; Layer 4's `lgd_hard_expected` is a physical loss
forecast. Today they agree for Calm names (1 - market.lgd_hard/100 = 0.40) but not for Stressed/Crisis names.

Bootstrap: each forward hazard is solved by Brent on [-2, 25] so that the quoted tenor reprices
(premium - protection [+ upfront] = 0), given the hazards already fitted. Diagnostics (column `flags`, never
an exception):

- `negative_forward_hazard_<T>y`: the solution is < 0 (survival would have to rise: a static arbitrage).
  The used hazard is floored at 0, the raw value is kept in `hazard_fwd_raw`, and the floor's cost is shown in
  `reprice_error_bp` (later tenors are fitted on the floored curve).
- `no_root_<T>y`: no hazard in the bracket reprices the quote (closest end taken).
- `inverted_curve` (informational, normal for distressed names), `single_tenor_flat_curve`,
  `upfront_converted`, `duplicate_tenor` (last row kept).
- `validate_snapshots` drops unusable rows (unknown quote_type, non-CDS, missing value/tenor, upfront without a
  coupon, recovery outside [0,1)) and lists them in `issues`; missing required columns raise.

Point in time: per country, only rows with `as_of <= run as-of` and `vintage <= run as-of` are read; the
latest market date wins, then the latest vintage seen in the snapshot, then `snapshot_id`, so one curve comes
from one capture. Within that snapshot each tenor keeps its latest-vintage row known by the as-of date (review
fix: a snapshot whose rows were loaded at different vintages keeps all its tenors). Superseded rows and tenors
visible only at a later vintage are listed in `issues`. Duplicate tenors in the curve keep the last row in input
order (stable sort).
The as-of date comes from the argument or `settings["as_of"]`; with neither the call raises (GOV-012).

Input since EQ-B-0056: Team A's market store (`econquest.ingestion.market`, rows in `MARKET_COLUMNS`, saved under
`<data_dir>/live/market/snapshots`). `cds_curves.curves_from_market(data_dir, as_of)` reads
`market_history(data_dir, "cds", asof=D)`, drops rows with `derived` true and reports them in `issues` (computed
values are indicative, never dealer quotes; HO-20261023-A-B-011), converts the rest with Team A's
`to_cds_snapshots` (`market_snapshots`) into the internal `SNAPSHOT_COLUMNS` frame, and bootstraps with `curves`.
Per (iso3, as_of) the newest capture wins: store snapshot ids rank by their save-time prefix, and older captures
of the same date are ignored whole and listed in `issues` (HO-20261023-A-B-012). No saved snapshot by the as-of
date raises `FileNotFoundError`; there is no fallback to the seed spreads. `bond_rv.country_rv_pit` uses these
curves for the market spread and carries the curve issues in `attrs["issues"]`.

`SNAPSHOT_COLUMNS` (snapshot_id, as_of, iso3, instrument, tenor_y, quote_type (par_spread | upfront), value
(bp | points), running_bp, currency, doc_clause, recovery, source, licence, vintage) is now the internal frame the
bootstrap takes, not a file schema; `validate_snapshots` and the hand checks below still apply to it.

### Hand checks (all synthetic)

| Case | Expected | Engine |
|---|---|---|
| Flat 300 bp, R 0.40, r 4%, quarterly (XAA) | lambda ~ s/(1-R) = 0.0500 | 0.049753 flat on all tenors; PD 1y 4.854%, PD 5y cum 22.024% = 1 - e^{-5 lambda} |
| Flat 100 / 500 (R 0.25) / 1000 bp | within 2% of s/(1-R) | pass (test_flat_spread_matches_credit_triangle) |
| Upward 100-250 bp (XBB), blank recovery | reprices every tenor | max error < 1e-6 bp; recovery_source cds.recovery |
| Inverted 3000 -> 750 bp, R 0.25 (XCC) | negative forwards at 3y, 5y, 7y | flagged; raw -0.043, -0.052, -0.002; used 0; reprice error 99.7 / 156.5 / 4.4 bp |
| 5y upfront for 100 bp coupon priced off a flat 500 bp curve | bootstraps back to 500 bp | 500.000 bp, same hazard to 1e-8 |
| Later snapshot (2026-10-30) and late vintage (2026-10-25) | ignored at as_of 2026-10-23 | SYN-XAA-1 used |

The gap between 0.04975 and 0.0500 is the accrual-on-default and discrete-premium effect, as expected.

## Relative value (EQ-B-0049)

Review fix (AGENT-08, 2026-10-23): the fair spread is the exact inverse of Layer 2's `pd_market_phys`.
`fair = 1e4 x p x LGD x k`, `EL = 1e4 x p x LGD`, `fair - EL` = risk premium, with p = run `pd_default`
(Layer 1/2 after the market blend and regime multiplier, an annual PD), LGD = `probability.lgd_market_implied`
(0.6, Layer 2's LGD), k = `risk_premium_ratio` (1 for SD/D). Layer 2 reads spread/LGD/k as an annual PD, so
`physical_pd(fair_bp, lgd_market_implied, k) = p` exactly (test_inverse_of_layer2_physical_pd,
test_country_rv_inverts_layer2_by_default). Over a bond duration D the annualised PD 1 - (1 - P_D)^(1/D), with
P_D = to_horizon(p, 12D), equals p under the engine's constant hazard. Options, not default: `bond_rv.lgd_source
"layer4"` (Layer 4 `lgd_hard_expected`, includes regime and Merton uplift) and `bond_rv.fair_form "intensity"`
(h = -ln(1-p) instead of p; +12% at p 0.20: 2678 vs 2400 bp at LGD 0.6, k 2). The first version used both
(intensity and Layer 4 LGD), which overstated HY fair spreads (Pakistan z -6.8, now -3.2).
Market = par spread at D off the country's CDS curve when one exists, else the Country Profile spread.
`gap_bp = market - fair` (+ cheap, - rich).

Dispersion for the z-score: `z = gap_bp / (market.spread_vol_rel/100 x market_bp)`, i.e. the gap in units of
the one-year spread move that Layer 6 already assumes for the same bond. Chosen because (a) there is no
history of model-fair spreads, so no time-series dispersion of the gap exists; (b) a cross-sectional
dispersion mixes model error with value and changes with the universe (it is reported as `z_xs`, a robust
median/MAD z of log(market/fair), for comparison); (c) it uses a governed parameter. Read band |z| >= 1
(`bond_rv.z_band`). Distressed names (rating SD/D or pd_12m >= 0.5) trade on price and recovery: z blank.

### Today's table (run 2026-10-23, profile spreads, 5y, no CDS curves)

| Country | PD 12m | fair bp | market bp | gap bp | z | read |
|---|---|---|---|---|---|---|
| Vietnam | 0.36% | 43 | 100 | +57 | +1.41 | cheap |
| Philippines | 0.36% | 43 | 65 | +22 | +0.86 | in line |
| China | 0.28% | 34 | 60 | +26 | +1.08 | cheap |
| Malaysia | 0.20% | 24 | 45 | +21 | +1.16 | cheap |
| Singapore | 0.04% | 5 | 15 | +10 | +1.70 | cheap |
| Japan | 0.04% | 5 | 20 | +15 | +1.86 | cheap |
| South Korea | 0.06% | 7 | 25 | +18 | +1.77 | cheap |
| India | 0.33% | 39 | 70 | +31 | +1.11 | cheap |
| Pakistan | 8.61% | 1033 | 450 | -583 | -3.24 | rich |
| Belize | 4.86% | 583 | 650 | +67 | +0.26 | in line |
| Brazil | 1.12% | 135 | 160 | +25 | +0.39 | in line |
| Argentina | 9.48% | 1138 | 650 | -488 | -1.88 | rich |
| Colombia | 1.09% | 130 | 220 | +90 | +1.02 | cheap |
| Venezuela | 99.0% | 5940 | 6000 | (+60) | n/a | distressed |
| Nigeria | 3.88% | 466 | 400 | -66 | -0.41 | in line |
| Senegal | 15.9% | 1911 | 1200 | -711 | -1.48 | rich |
| Zambia | 4.75% | 570 | 450 | -120 | -0.67 | in line |
| Zimbabwe | 78.4% | 4704 | 3000 | (-1704) | n/a | distressed |

LGD 0.6 for every row (Layer 2's), k 2 except SD (1).

Positions (portfolio.csv): long Eurobonds in Pakistan (P10), Argentina (P14) and Senegal (P20) read rich
(unfavourable); Vietnam (P01) cheap (favourable); Belize, Nigeria, Zambia, Philippines neutral; the Argentina CDS
protection (P15) favourable; Venezuela n/a.

## Proposed signal and playbook rows (not wired)

`rv_signal`: s26 "Bond cheap vs model" = 50 + 50 tanh(z / c), c = `signal_z_at_70` / atanh(0.4), so z = +1
scores 70; s27 "Bond rich vs model" = 100 - s26; distressed 50. Returns an empty frame unless
`bond_rv.enabled` is true. Proposed `data/playbook.csv` rows (same columns as today):

```
T27,Buy Eurobond cheap to model,26,70,,,,Eurobond,Relative value,Sovereign credit,"Buy the 5Y Eurobond; size to the risk budget, hedge rates",Model-fair spread at least 1 spread-vol below market (z >= 1),"z back inside 0.25, or PD/LGD inputs revised",3-6 months,Model PD error; liquidity; CDS-bond basis
T28,Underweight Eurobond rich to model,27,70,,,,Eurobond,Relative value,Sovereign credit,Reduce long or buy 5Y CDS protection against it,Market spread at least 1 spread-vol below model-fair (z <= -1),"z back inside -0.25, or PD/LGD inputs revised",3-6 months,Regime overlay overstates PD; negative carry
```

Wiring needs `signals.compute_signals` keys 26/27 and SIGNAL_NAMES entries (Team B) and the pipeline edit in
the EQ-B-0049 report; both wait for Sam's decision on `bond_rv.enabled`.

## Limitations

- No real quotes: curve code is validated only on synthetic and hand-computable cases.
- Self-reference: `pd_default` already contains the market spread (Layer 2 `w_m` 0.5), so gaps understate the
  model/market disagreement. `bond_rv.pd_column` can point at `pd_model_l1`; with it no country reads rich and
  CHN, JPN, IND, BLZ, ARG, COL, NGA, SEN, ZMB read cheap.
- The HY "rich" reads come mostly from the regime multiplier (Pakistan L1 2.3% -> 8.6%), then doubled by k = 2.
  Applying the risk premium on top of a stressed PD may double count stress. With `lgd_source "layer4"` (Merton
  uplift, 0.93-0.95) the same three names read rich, with larger gaps.
- IG names read cheap because the engine's IG PDs (0.04-0.4%) are well below spread-implied ones; spreads also
  price liquidity and other non-default premia that the model ignores.
- Constant hazard: duration does not change the fair spread until Layer 1 gives a term structure.
- CDS-bond basis, bond price/coupon and recovery-of-face vs market value are ignored.

## Sensitivity (count cheap / in line / rich, 16 non-distressed)

| risk_premium_ratio | cheap | in line | rich | rich names |
|---|---|---|---|---|
| 1.0 | 12 | 4 | 0 | none |
| 1.5 | 9 | 6 | 1 | PAK |
| 2.0 (0.1.3) | 8 | 5 | 3 | PAK, ARG, SEN |
| 3.0 | 3 | 8 | 5 | + NGA, ZMB |

## Proposed assumptions keys (Tier 3 now; Tier 1 if `enabled` ever drives trades)

`bond_rv`: `enabled` false, `pd_column` "pd_default", `fair_form` "layer2_inverse", `lgd_source`
"market_implied", `z_band` 1.0, `distress_pd` 0.5, `signal_z_at_70` 1.0, `use_cds_curves` true. No snapshot path key is needed: the
store location is `market_dir` / `<data_dir>/live/market/snapshots`.

## Open items for review

1. Real quotes: the store wiring is done (EQ-B-0056; handoffs HO-20261023-A-B-010/011/012); no real CDS capture exists
   in the repository yet, so every number above is still synthetic. Licence and source per row stay required (6.7).
2. Decide whether the RV PD should be pre-market (`pd_model_l1`/`pd_model`) to avoid self-reference.
3. Decide whether k applies to regime-stressed PDs or to a through-the-cycle PD.
4. Team C (EQ-C-0046, HO-20261023-B-C-014): views over outputs/bond_rv.csv, bond_rv_positions.csv, cds_curves.csv.
