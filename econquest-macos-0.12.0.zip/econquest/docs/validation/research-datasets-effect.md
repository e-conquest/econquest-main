# Research datasets: effect on the desk scorecard (EQ-B-0101)

Owner: Team B (AGENT-06 stand-in). Date: 2026-10-25. Status: the script is built and has been run on the inputs
that exist now. No research rows exist yet, so the full effect cannot be computed. Nothing was applied, and nothing
under data/ was written.

## 1. Result

- **No raw research-adapter rows exist.** `data/panel/research/` holds only its README. No adapter output is in
  `outputs/`, `data/panel/staging/` or the two Sam pulls in `team/inbox/`. Each of the eight built adapters
  (vdem, wjp, coups, goci, ndgain, epr, aqueduct, unhcr) reports "no file" on load. The downloads are Mac-side
  (EQ-A-0067 wave 2).
- So, today, **no desk cell changes from seed under the section 13 rules.** The 100k base is unchanged:
  VaR99 58.19, ES99 78.72, EL 0.88, L-VaR99 63.47 (rerun 2026-10-25, as_of 2026-10-23).
- The one input that exists is the WDI Gini (SI.POV.GINI) in Sam's 0.4.2 pull. It is half of the 6.10 rule. Section
  2 shows what it gives on its own. Under the rule these cells are held ("EPR missing"), so they do not release.

## 2. Partial preview: 6.10 from the Gini alone (held; not a rule outcome)

Gini level per section 3 (latest year from as_of year - 10 to as_of year - 1). Section 3 says that when one part
is missing the cell is written and **held**. The EPR part will raise some of these (CHN, IND, NGA, PAK have large
excluded groups), so the Gini-only levels understate. Shown only for scale.

| Country | Seed | Gini level (year) | Score seed -> Gini only |
|---|---|---|---|
| Philippines | 2 | 1 (2023) | 50 -> 25 |
| China | 3 | 1 (2022) | 75 -> 25 |
| India | 2 | 0 (2023) | 50 -> 0 |
| Pakistan | 2 | 0 (2024) | 50 -> 0 |
| Belize | 2 | 1 (2018) | 50 -> 25 |
| Argentina | 1 | 2 (2024) | 25 -> 50 |
| Nigeria | 2 | 0 (2022) | 50 -> 0 |
| Zambia | 4 | 3 (2022) | 100 -> 75 |
| Zimbabwe | 2 | 3 (2019) | 50 -> 75 |
| VNM, MYS, JPN, KOR, BRA, COL, SEN | | same as seed | no change |

Singapore and Venezuela have no Gini within 10 years (blank).

If all these held cells were released anyway (100k paths): VaR99 58.19 -> 58.18, ES99 78.72 -> 78.72, EL 0.88 ->
0.88, L-VaR99 63.47 -> 63.46. The largest PD moves are Zimbabwe +0.14 pp (78.54%) and Argentina +0.03 pp. No
grade changes. Pakistan and Nigeria do not move: their pillar 6 is set by other indicators or a floor. This
scenario breaks the rule, so it is not proposed.

## 3. The effect script (ready for when rows land)

`econquest/validation/research_effect.py` (Team B). It:

1. loads each adapter from its drop-in folder with `fetch=False` (`collect_rows`), or reads a CSV of rows (`--rows`);
2. applies the rules (`rule_cells`), one status per desk cell:
   - `value`: replaces the seed once released;
   - `hold`: a value is computed but a hold applies;
   - `blank`: no value.

   The rules applied:
   - 3.6 and 3.7: as published, with the staleness holds;
   - 4.3: section 1 and 13.2, held without `v2cacamps_osp`;
   - 4.4: the 13.3 annual fallback;
   - 6.7 and 7.11: as published, held when the data year is more than 3 years before the as_of year (no written
     rule; Team B default);
   - 6.10: section 3 and the 13.4 interim rule (Gini from `--worldbank`);
   - 7.12: section 5 and 13.6;
   - 2.11: section 15 (`_export_concentration`: coverage floor first, then the manufactures blank, then the
     commodity maximum, then staleness), from `--worldbank`.

   Point in time (`point_in_time`): a row is used only when its release is published on or before as_of. The
   date comes from a `published` column, or a YYYY-MM-DD date in `vintage`. Without one, a cautious default from
   the data year y applies:
   - V-Dem: 31 March y+1.
   - WJP: 31 December y+1.
   - Coups: 31 December y, so a coup in the as_of year counts only from a dated file.
   - GOCI: 31 December y.
   - ND-GAIN and EPR: 31 December y+1.
   - Aqueduct 4.0: 31 August 2023. A newer release needs its own date.
   - WDI (Gini, export groups): 30 June y+1.

   6.12 is not computed, since it needs the UCDP token and the neighbour list;
3. scores seed against new for every non-blank cell (`cell_table`);
4. runs the pipeline three times on in-memory copies of the Universe: base, "released" (value cells) and "with
   holds" (value and hold cells). It writes composite, grade and PD per country, and VaR/ES/EL/L-VaR, to
   `--out`: a folder under outputs/ only (`activation.resolve_out_dir`), default
   `outputs/research_effect/<as_of>`.

Run on the Mac once files are in `data/panel/research/<key>/`:

```
python -m econquest.validation.research_effect --data data --as-of 2026-10-23 --paths 100000 \
    --worldbank team/inbox/pull-20261025T013150Z/raw_worldbank.csv --out outputs/research_effect
```

Tests: `tests/test_research_effect.py` (10 tests, SYNTHETIC rows). They cover the 2.11, 4.3, 4.4, 6.10 and 7.12
rules, the staleness and publication-date cuts, the `--out` restriction, and that `data/indicators.csv` is not
written.

Adapter changes the rules need (Team A files, not edited here; from section 13):
- vdem: add `v2cacamps_osp` and `v2lgbicam`.
- coups: add the attempt month.
- epr: emit 0.0 for all-IRRELEVANT years, and a `discriminated_pop_share`.
- unhcr: add the origin country.
- aqueduct: change the year stamp to 2019.
- wjp: take the first year of a two-year label.

Until then the script holds 4.3, and gives the cautious annual reading for 4.4.

## 4. Draft Tier 1 card (not posted; AGENT-08 posts it to Sam)

Two batches move desk PDs once released. Each is a Tier 1 scorecard data change. Neither is applied.

**Card A: 2.11 export concentration, WDI commodity groups (indicator-rules.md section 15).**
- Change: six desk cells move from seed to the WDI value: Belize 95.34, Brazil 40.73, Colombia 34.90, Nigeria
  85.90, Senegal 32.71, Zambia 72.99. Nine manufacturers stay on seed (blank). Argentina, Zimbabwe and Venezuela
  are held.
- Effect, 100k paths, as_of 2026-10-23, computed by `research_effect` (scenario "released"; the 2.11 cells are
  the only released cells today): VaR99 58.19 -> 58.53 (+0.35), ES99 78.72 -> 78.95 (+0.23), EL 0.880 ->
  0.897, L-VaR99 63.47 -> 63.81 (+0.35).
- PD moves: Senegal 13.34% -> 13.46%, Belize 4.86% -> 4.93%, Brazil 1.12% -> 1.14%; Colombia and Zambia lower by
  under 0.01 pp. No grade changes.
- Why: Team A's proxy reverses the indicator for manufacturers. The rule keeps it only where it measures what the
  rulebook asks.
- Licence: WDI (open). Reversible: revert the cells to seed.
- Ask: approve the rule for Team A to code, with the values going through the normal gate review.

**Card B: research-dataset cells (sections 13.1-13.7).**
- Effect: not computable until the files land on the Mac. Run the script above, paste its `effect.md` table here,
  and post with the composite, grade and PD changes per desk country.
- Sign-off points named in section 13: 3.6 no-legislature value, 4.4 annual fallback, 6.10 interim EPR level,
  7.12 category -1.
- Licences: V-Dem CC BY-SA, ShareAlike question open for Sam. Aqueduct CC BY. WJP, Powell-Thyne, GOCI, ND-GAIN and
  EPR are internal research only and kept out of client output.

## 5. PI-10 rerun on the 0.6.0 base (EQ-B-0104, 2026-10-25)

- **Research rows: still none.** All eight adapters report "no file". `data/panel/research/` holds only its
  README, and there is no `data/live/raw_research.csv`. So **no research cell changes from seed**, and the research
  datasets have no effect on the 0.6.0 base.
- Rerun at 20k paths, as_of 2026-10-23, inputs as before (Gini and export groups from Sam's 0.4.2 pull). Base
  reproduced exactly: VaR99 66.954, ES99 88.964, EL 4.081, L-VaR99 72.236.
- The only released cells are the 2.11 cells of card A (section 15, a WDI rule, not a research dataset):

| Run | VaR99 | ES99 | EL | L-VaR99 |
|---|---|---|---|---|
| 0.6.0 base | 66.954 | 88.964 | 4.081 | 72.236 |
| 2.11 released (card A) | 67.049 | 89.113 | 4.096 | 72.331 |
| with holds (adds Gini-only 6.10 and held 2.11) | 67.017 | 89.116 | 4.096 | 72.299 |

  PD moves (card A): Senegal +0.114 pp (13.46%), Belize +0.067 pp, Brazil +0.019 pp, Zambia -0.008 pp,
  Colombia -0.004 pp. No grade changes.
- Card A stays parked under the PI-10 rule (no cards to Sam until the MVP passes). It goes in the decision pack.

