# Assistant tool contracts (`eq-assistant-tools/1`)

Date: 2026-10-27. Ticket EQ-B-0145 (AGENT-05), PI-15. Code: `econquest/validation/assistant_tools.py`.
Tests: `tests/test_assistant_tools.py` (no network, no model). Handoffs: HO-20261027-B-B-001 (citation format, with
AGENT-07 / EQ-B-0146), HO-20261027-A-B-001 (Team A context chunks, EQ-A-0143), the contract handoff to Team C
(EQ-C-0170 provider).

The assistant explains the desk. It never computes a risk number. Every number in an answer comes from a tool row
or a context chunk, and each one carries a citation. This module is the registry of tools the model may call. Each
tool is read-only, takes typed inputs and calls existing Team B or Team A code. Nothing here runs in `econquest run`,
writes to the repository, data/ or outputs/, changes a setting or calls `econquest change`. The base run is
unchanged: at 20,000 paths it gives
66.95612571109443 / 89.00003057231508 / 4.098636048964449 / 72.23763153780678, and replicate gives PASS 141.

## How Team C's provider uses it

```python
from econquest.validation import assistant_tools as AT

ctx = AT.ToolContext(data_dir="data", as_of="2026-10-23")     # fixed by the host; the model never names a path
AT.pin_base_run(ctx, "data", as_of="2026-10-23")              # or ctx.pin_run(run, universe, settings, limits)
tools = AT.tool_manifest()                                    # OpenAI-style: [{"type": "function", "function": {...}}]
# ... the model replies with tool_calls [{name, arguments}] ...
res = AT.call_tool(name, arguments, ctx, client_scope=(surface == "client"))
messages.append({"role": "tool", "tool_call_id": call_id, "content": json.dumps(AT.model_view(res))})
# after the final answer: AGENT-07's gate gets the full results
check_answer(answer, tool_results=[res, ...], chunks=..., audience=...)
```

- `call_tool` never raises for what the model sent. It returns `status` ok | refused | unavailable | timeout | error
  with a `reason`, and `rows` is empty unless the status is ok.
- `arguments` may be a dict or the JSON string the endpoint returns.
- `client_scope` is set by the host surface. It is not in any schema, so the model cannot change it.
- Recommended cap: `MAX_TOOL_CALLS_PER_ANSWER` = 6 calls per question. Team C enforces it in the loop.

## Tools

| Tool | Wraps | Inputs (required in bold) | Rows |
|---|---|---|---|
| `what_if` | `engine.portfolio_risk.whatif_many` on the pinned run's stored paths | **run_id**, **as_of**, **country** ISO3, **instrument** (FX, Local bond, Eurobond, Equity, CDS protection), **size_mm** 0 to 250, direction (Long, Short; default Long), duration_yrs 0.25 to 30, extra_trades (optional, up to 4 more trades with the same fields) | `book/<metric>`: before_mm, after_mm, change_mm, first_order_change_mm, for EL, VaR95/99, ES95/99, liquidity cost, L-VaR99, gross notional. `trade/<id>`: marginal and component VaR/ES/L-VaR, share_of_es99, EL, pd_default, market_vol_pct, carry, liquidity cost, size. `limit/<measure>`: value, limit, utilisation, status. `verdict`, with the reasons as text |
| `attribution` | `engine.portfolio_risk.attribution` (cached per run) | **run_id**, **as_of**, **by** (position, country, region, asset_class, factor, country_factor), country, top_n (1 to 50, default 10) | `book` (run metrics), then the largest component ES99 first: notional, EL, component VaR99/ES99, marginal per $1mm, share_of_es99 |
| `heatmap_drivers` | the run's `Scorecard` and country table | **run_id**, **as_of**, country, top_n (1 to 20, default 5), limit | `<ISO>/pillars`: pillar 1 to 7 scores, composite, grade, pd_default. With a country, also `<ISO>/perils` (Risk Engine peril points) and `<ISO>/indicator/<id>` (the highest indicator scores, with raw value, name and unit) |
| `event_lookup` | Team A `build_context(kinds=["calendar"])` or `["events"]` (A-0143) | **as_of**, **source** (calendar, unified), country, kind (one calendar kind), start, end, limit | One row per chunk, with the chunk text (already fenced by A-0145) and its source_id as file#row |
| `archive_search` | Team A `build_context(kinds=["archive"])` | **as_of**, **query** (2 to 200 characters), country, limit (1 to 20, default 5) | The chunks that match the most query words first (ties by chunk_id), with match_terms and the text |
| `depth_views` | `validation.depth_views.depth_views` (C17) | **as_of**, country, view, limit | One row per depth row. The value has its unit (pct for "% of ...", fraction for "probability"); a hold or refused row carries its status and note, and no value |
| `backtest_explainer` | `validation.backtest_explainer.run_explainer` (C18; INTERIM) | **as_of**, **table** (exceptions, rolling, pnl), level, country, limit | One row per explainer row. Numeric columns are values, the rest are labels; each row is labelled INTERIM |

Limits:
- MAX_TRADES 5, MAX_TRADE_MM 250, MAX_ROWS 200 and MAX_RESULT_BYTES 512,000; a larger result is refused with "narrow
  the query".
- Each tool has a wall-clock budget: what_if 180 s, attribution 600 s, depth_views 120 s, backtest_explainer 300 s,
  the others 30 to 60 s. The host can lower them with `ToolContext.time_limits`. A call over budget returns
  `timeout`. Python cannot stop a running thread, so the timed-out work carries on in a daemon thread until it
  finishes. While it runs, the context refuses every further call ("an earlier call timed out and is still
  running"), so timed-out work never piles up. A host that needs a hard stop runs the registry in a worker process.
- The registry (`TOOLS`) is a read-only mapping. A name that is not in it is refused: the registry has no
  `econquest_change`, no shell and no file reader.

## Inputs

The schemas are kept small and flat so that a small local model (Sam's likely default is Gemma on Ollama) calls
them reliably:
- at most 5 required fields and 8 properties per tool;
- enums instead of free text;
- descriptions of at most 120 characters per tool and 40 per field;
- one optional nested field (what_if `extra_trades`).

A test enforces these limits.

Each schema is a JSON Schema object with `additionalProperties: false` at every level. `validate_args` refuses all
of the following before any code runs:
- unknown fields (for example `data_dir` or `path`) and missing required fields;
- wrong types (a boolean is never a number) and NaN or infinite numbers;
- values out of range, and arrays that are too long or too short;
- strings that break their pattern;
- dates that do not exist (2026-02-30);
- duplicate keys in a JSON argument string, where a plain parse would let the last value win.

`as_of` is required on every tool. There is no clock.

**Session as_of** (HO-20261027-B-B-011 T2):
- The host sets `ToolContext.as_of`. If it is unset, the first `pin_run` sets it to that run's as_of.
- Every tool refuses an as_of later than the session's, so no data tool can answer with facts known after the pinned
  run (no look-ahead).
- A context with no session as_of refuses every call.
- `pin_run` refuses a run dated after the session.

Run tools also need `run_id`, which must be a run the host pinned with that same as_of (`ToolContext.pin_run`
refuses a run without an explicit `settings["as_of"]`). "latest"
works only when the host pinned it (`pin_run(..., latest=True)`), and the citation still names the real run id.
Countries are ISO3 codes.

## Result and citation format (agreed with AGENT-07, HO-20261027-B-B-001)

```json
{"schema": "eq-assistant-tools/1", "tool": "what_if", "ok": true, "status": "ok", "reason": "",
 "args": {...}, "client_scope": false, "licence_class": "restricted", "row_count": 14, "dropped_rows": 0,
 "label": "tool output (econquest); quoted by the model, never computed by it", "result_sha256": "...",
 "rows": [{"cite_id": "what_if#cb6f9c8a:2", "tool": "what_if", "run_id": "20261027T104516-assistant-base",
           "file": "engine.portfolio_risk.whatif_many", "row": "book/var95_mm", "as_of": "2026-10-23",
           "licence_class": "restricted", "licence_ids": [], "trust": "econquest",
           "values": {"after_mm": {"value": <float>, "unit": "mm"}, ...}, "labels": {"measure": "var95_mm"},
           "citation": {"cite_id": "...", "tool": "...", "run_id": "...", "file": "...", "row": "...",
                        "as_of": "...", "licence_class": "..."}}]}
```

Field rules:
- **cite_id**: `<tool>#<8 hex of sha256(tool, args, client_scope)>:<n>`. It is unique within a request and across
  calls with different arguments, and the same call always gives the same id. Ids contain no dot, so they fit the
  gate's slot grammar `{{<cite_id>.<field>}}`.
- **run_id**: the pinned run for the run tools, and "" for rows from data (events, archive, depth views, backtest).
- **file**: the source file or tool function. For a chunk it is the part of its source_id before "#".
- **row**: the row key. For a chunk it is the part of its source_id after "#".
- **as_of**: the date the fact is true for. For a chunk this is its as_of; the query date is in
  `labels.known_as_of`.
- **values**: `{name: {value, unit}}` at full precision, with units from fraction, pct, pp, bp, mm, count, date and
  plain. PDs, shares and utilisation are fractions; $mm figures are mm. A NaN is never sent: the field is named in
  `labels.no_value`.
- **text**: chunk text, or the what-if reasons. Numbers in it are read by the gate as printed.
- `citation_problems(row)` lists what a row lacks, and `cited_numbers(result)` flattens every number with its
  cite_id.
- The model gets `model_view(result)` (below). The gate gets the full result.

**Event rows.** event_lookup calendar rows carry the event amount as a row value named after the kind, e.g.
`external_debt_service_amount_mm`, with unit mm (amount_usd / 1e6, a unit change only). It comes from Team A's
`calendar.query.events` at the same as_of. The labels add `event_kind`, `event_date`, `event_date_end` and
`due_year`.

## Frozen format (HO-20261027-B-B-017)

The row format is frozen under the one schema version `eq-assistant-tools/1`. `format_spec()` lists the result keys
(`RESULT_KEYS`), row keys (`ROW_KEYS`), citation fields, value keys, units, licence classes, statuses, the
model_view keys and the full tool manifest. `format_sha256()` must equal `FROZEN_FORMATS["eq-assistant-tools/1"]`
(`f5ad1d21...0850`). A test fails if any key is added, removed or renamed, or a tool input changes, without a new
SCHEMA and its own FROZEN_FORMATS entry. It also checks that real results carry exactly these keys.

## Slots: what the model sees and writes (lead decision; AGENT-07's gate `eq-assistant-qa/2`)

The model never writes a number. It writes a slot naming a cited field, and the gate's `render_answer` fills the slot
with the canonical label, sign, unit, run id and as_of. `model_view(result)` shows, per row:
- `cite`: the text-citation marker `[cite:<cite_id>]`, for a statement that has no figure;
- `slots`: `{field: {"shows": <the gate's own rendering, render_value>, "write": "{{<cite_id>.<field>}}"}}`, for
  every numeric value, every label or date that holds a digit, as_of and run_id. For example
  `es99_after_mm: {"shows": "ES99 after <value> $mm", "write": "{{<cite_id>.es99_after_mm}}"}`;
- `labels`: only labels without digits (plain words the model may use);
- `text`: chunk or row text with each number replaced by its slot (`{{<cite_id>.t1}}`, `.t2`, ...), numbered in the
  gate's own order.

**Every numeric field names its measure** (HO-20261027-B-B-011 T1). The gate's label comes from the field name, so
no field is generic. Examples by tool:
- what_if book rows: `var99_before_mm`, `var99_after_mm`, `var99_change_mm`, `var99_first_order_change_mm`, and
  `expected_loss_before_mm` for EL;
- what_if limit rows: `var99_book_mm`, `var99_limit_mm`, `var99_limit_utilisation`;
- what_if trade rows: `trade_notional_mm`, `trade_duration_yrs`;
- depth rows: the metric name, e.g. `reserves_pct_ara`;
- heatmap rows: `fiscal_and_debt_pillar_score`, and `<indicator slug>_score` / `<indicator slug>_input`;
- backtest rows: `days_in_window`, `expected_exceptions`, `exception_count`, `loss_rank`, and so on.

A test checks that no field of any tool is one of the generic names (value, score, before_mm, limit_mm, n, ...). It
also checks that every what_if book and limit field has the measure of its row.

The rendering comes from `assistant_qa.normalise_sources` and `render_value`, the same functions the gate runs, so
what the model is shown is what the answer will say. Chunk ids, source ids, provenance and timestamps stay in the
citation and are left out of the view.

Text slots t1..tn use the gate's own extractor and skip rule (HO-20261027-B-B-013): dates and exempt numbers
(confidence levels such as 99%, years, horizons, list markers) stay as printed and are not slots. Every other number
becomes its slot. Each numeric field's label is the gate's own `value_label`, and a test checks that it is never
empty or generic. Fail-safe case (T5): if the counts ever disagree, the view keeps the text with its digits. A model
that copies them fails the gate's no-digit rule and the answer is refused. This fails closed, at the cost of a
refusal.

**One marker for each job (agreed with AGENT-07 and proposed to Team C):**
- every figure is a slot `{{<cite_id>.<field>}}`;
- every text claim without a figure is `[cite:<id>]`, where id is a tool row's cite_id or a context chunk's
  chunk_id;
- `[chunk:<id>]` is read as a legacy alias until Team C's answer.py switches over.

**Determinism.** The same arguments on the same context give the same rows, in the same order, with the same cite
ids and the same `result_sha256`.
- Both hashes are computed over a canonical serialisation: sorted keys, no NaN, and no clock-stamped id. Every
  pinned run id or alias in it is replaced by the run's content fingerprint (`PinnedRun.fingerprint`: sha256 of its
  as_of, seed, path count and stored path losses). So two builds on the same inputs agree byte for byte, while the
  rows still cite the real run_id (HO-20261027-B-B-017).
- `ToolContext` makes `data_dir` and `outputs_dir` absolute when it is created, and `pin_base_run` resolves its
  folder too. A relative path therefore still finds the licence register, and client scope never depends on the
  working directory. Results hold nothing time-dependent. The wall-clock budget is measured but never
reported.

## Licence and client scope

- `licence_class` takes the C14 client_output values allowed, restricted and barred. A missing or unknown class is
  restricted (fail closed). A result carries the most restrictive class of its rows.
- Run-derived rows (what_if, attribution, heatmap_drivers) are restricted. The base run reads IMF WEO and Article IV
  values, which are internal (EXC-003). A host may pin a client-safe run with `licence_class="allowed"`.
- Chunk rows are allowed only when the chunk's A-0144 scope is client_ok. With `client_scope=True` they must also be
  returned by `build_context(scope="client")`, so both of Team A's answers must agree.
- Depth-view rows keep their own licence class. Backtest-explainer rows are restricted (record and market prices).
- With `client_scope=True` only allowed rows are returned. The rest are dropped and counted in `dropped_rows`. If
  rows matched but none is allowed, the call is refused ("client scope: all N row(s) are internal-only, restricted
  or barred") and no content is returned. `limit` applies after the filter.

## Tests

`tests/test_assistant_tools.py` (62 tests, about 15 s) covers:
- **Manifest:** its shape, small flat schemas, strict schemas and vocabularies that match `config.ASSET_CLASSES`, the calendar KINDS,
  the depth views, the backtest LEVELS and the licence classes.
- **Static read-only check:** no shell, network, file-write or presentation imports, and the allow-list cannot be
  mutated.
- **Refusals:** unknown tools; unknown, nested or path fields; wrong types; NaN; size and count limits; bad dates;
  "latest"; bad JSON; unpinned runs and an as_of mismatch.
- **Run tools on a 4,096-path base:** the what-if numbers equal `whatif_many`, a zero size gives the base, attribution
  components sum to ES99, and heatmap scores equal the scorecard.
- **Citation completeness and determinism.**
- **Client scope:** run tools refuse unless the run is client-safe; chunks, depth and backtest rows are dropped and
  the call is refused when nothing is left; both A-0144 answers must agree; the limit applies after the filter.
- **Errors and limits:** timeout, backend errors, oversized results, and a missing data folder (reported as
  unavailable).
- **Integration:** Team A's real `build_context` on the shared data.
- **Review fixes (HO-20261027-B-B-011):** no generic field names; a future as_of is refused by every data tool; the
  session as_of bounds pinned runs; duplicate JSON keys are refused; a timed-out call blocks further calls.
- **Reproducibility, paths, events, freeze (HO-20261027-B-B-017):** a twin run with another run_id gives the same
  hashes and cite ids; a relative data_dir drops the same restricted rows as an absolute one, with no register
  warning; the event amount is a slottable value; the format is frozen.
- **Slots:** an answer written only with model_view's slots passes AGENT-07's `check_answer` and renders exactly
  what the view showed, for both tool values and chunk-text numbers.

## Exceptions to "read-only, no side effects" (HO-20261027-B-B-011 T3, T4)

- **archive_search and presentation.** Validation never imports presentation, and a static test checks this
  module. At run time, though, Team A's `build_context(kinds=["archive"])` (EQ-A-0143 `build_archive`) runs
  `from econquest.presentation import archive` to read Team C's archive index. After an archive_search call,
  `econquest.presentation.*` is in `sys.modules`. This is a recorded exception. Team A has been asked
  (HO-20261027-B-A-002) for an archive reader that does not import presentation; the exception ends when that lands.
- **depth_views temp files.** The C17 backend (`default_panel.import_crag`) writes a temporary folder in the system
  temp directory and deletes it. Nothing is written under the repository, data/ or outputs/.
- **pin_base_run process call.** `pin_base_run` stamps the run through `versioning.stamp`, which runs `uname -p`
  via `platform`. It is a host helper, not a tool the model can call.

## Open items

- Team C wires the tool loop into `econquest/assistant` (EQ-C-0170/0172). Today the provider's `complete()` has no
  `tools` argument, and answer.py still cites `[chunk:<id>]` and checks numbers verbatim. Slots and `[cite:<id>]`
  replace both (HO-20261027-B-C-002).
- The escalation and text-index tools ("when switched on" in the brief) are not in this version. Adding a tool is a
  new manifest entry under the same schema id; changing a field means `eq-assistant-tools/2`.
- The proposed contracts.md row (C19) is in the Team C handoff.
