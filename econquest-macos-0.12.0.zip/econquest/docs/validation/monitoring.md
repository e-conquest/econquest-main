# Ongoing model monitoring

Date: 2026-10-24. Ticket EQ-B-0074. Owner: Team B, AGENT-05. Code: `econquest/validation/monitoring.py`.
Tests: `tests/test_monitoring.py` (16 tests, all on SYNTHETIC archives, indicator tables and inventory).
Tier: 2 control tool. It reads the run archive and the data, and runs the pipeline in memory for the
champion/challenger table. It archives nothing, edits no data file and changes no setting. No other module
imports it, so it cannot move the base. The 20,000-path check (as_of 2026-10-23) was identical before and after the
first build: VaR99 67.2808, ES99 89.6091, EL 0.8088, L-VaR99 72.5623. Later on 2026-10-24, `data/assumptions.json`
changed outside this ticket (`layer1.calibration_universe` was added at 12:38). The 20,000-path base is now VaR99
69.0339, ES99 91.2069, EL 0.8046, L-VaR99 74.3154.

## How to run

    python -m econquest.validation.monitoring                 # writes outputs/monitoring/
    python -m econquest.validation.monitoring --no-challengers --as-of 2026-10-23 --window 30
    python -m econquest.validation.monitoring --deliver --fail-on-red

`--as-of` defaults to the as_of of the latest archived base run. Runs dated after it are left out. With an empty
archive `--as-of` is required: the job stops with an error and never falls back to the wall clock. The value is
normalised to YYYY-MM-DD with `pd.Timestamp`, and anything that does not parse is refused (it becomes a file name).
Text cells in the CSV outputs go through `idea_log._csv_safe`, so a cell starting with = + - @ cannot run as a
spreadsheet formula. `--deliver` sends the alerts through `alerts.deliver_alerts` (webhook and SMTP from the
environment). It is off by default. `--fail-on-red` makes the exit code 2 when any red alert is raised; without it
the job exits 0 whenever it completes. `--challengers-json` replaces the default challenger list with a file of the
form `{"name": {"dotted.key": value}}`.

Outputs in `outputs/monitoring/`: `summary.md`, `monitoring_alerts.json` (alerts.py format plus `level`),
`drift_pd.csv`, `drift_metrics.csv`, `input_psi.csv`, `stability.csv`, `champion_challenger.csv`,
`review_calendar.csv`, `review_calendar.md`, and `indicator_snapshots/<as_of>.csv`, a copy of
`data/indicators.csv` that the next run compares against.

## What it checks

All thresholds are in one dict, `THRESHOLDS`, at the top of the module. Amber and red are inclusive lower bounds on
the absolute value. Red alerts carry severity "critical" and amber "warning", as in `alerts.py`.

| Check | Measure | Amber | Red |
|---|---|---|---|
| PD drift, consecutive base runs | change in `pd_default`, pp | 1 | 2 |
| PD drift over the window | latest minus first run, pp | 2 | 4 |
| VaR99, ES99, L-VaR99 drift | delta / sqrt(SE_prev^2 + SE_cur^2) | 2 SE | 3 SE |
| Expected loss drift | percent (no SE is archived for EL) | 10% | 25% |
| Input drift | PSI per input | 0.10 | 0.25 |
| Stability (same settings and data hash) | move in combined SEs | 2 SE | 3 SE |
| Challenger vs champion | delta / champion SE (label only) | 2 SE | 3 SE |
| Annual review | days to due | within 60 days | overdue |

Each pair of runs carries `settings_same` (a SHA-256 over the settings JSON without `as_of`), `data_same` and
`code_same` (the hashes from `versioning.py`), and `changed`, which lists what moved. A drift alert on a pair with a
settings change should match a row in `change-control.md`. A drift alert with the same settings hash comes from data
or code.

Stability: `stability.csv` lists the pairs with the same settings hash and the same data hash. The k x SE defect
rule applies only when settings, data, code and as_of are all equal (`checked` yes). There, a move above 3 SE is red
(amber above 2) and is a defect signal. When the path count is also the same, the engine is deterministic (seeded
Sobol), so any move above 1e-9 is red ("not reproducible"). A pair that differs in code or as_of is not tested: it
has no level, and `explained_by` names what changed (code, as_of or both).

Drift z: the denominator sqrt(SE_prev^2 + SE_cur^2) treats the two runs as independent. Archived runs share the seed
(common random numbers), so when the inputs are close the true SE of the difference is smaller. The z-score then
understates the move. Read it as an approximate and conservative measure: it gives fewer alerts, not more.

Monte Carlo SE: `var99_se_mm`, `es99_se_mm` and `lvar99_se_mm` from the run's metrics. Runs archived before
EQ-B-0054 have no SE. They get a fallback, 0.55% of VaR99 and L-VaR99 and 0.50% of ES99 at 131,072 paths, scaled by
sqrt(131072 / paths). These numbers come from the 0.1.4 base (0.40 / 74.35 and 0.45 / 96.48). Such rows show
`se_source` "fallback".

PSI: each input is a cross-section over the countries. The reference cross-section is cut into 5 quantile bins,
and shares are floored at 1e-4. The inputs are the seven pillar scores and eight country-profile inputs from the
archive (spread, composite, debt/GDP, ST FX debt/reserves, reserves in months of imports, primary-balance gap,
PITF instability, commodity shock), plus the 83 rows of `indicators.csv` against the last snapshot. The data date is the latest `retrieved` date in
`data/live/provenance.csv` or the latest folder in `data/live/vintages/`. When as_of is before that date, or the date
is unknown, the job saves no snapshot and runs no indicator PSI. `summary.md` and `monitoring_alerts.json`
(`indicator_psi`) say why. A backdated run therefore never labels today's data with an earlier date. With 18
countries PSI is coarse. Measured on random 18-country cross-sections: one country moving one bin gives 0.028 to
0.035; three countries give a median of 0.095; five give 0.16 to 0.34 (10th to 90th percentile). So amber (0.10)
means about three countries changed bin and red (0.25) about five, or fewer countries moving several bins. The
thresholds stay as they are. Read amber as "look at the input".
The archive inputs are mostly the result of transforms, so a red PSI on them can come from a code change as well as
a data change.

## Explained and unexplained drift (EQ-B-0125)

Each `pd_drift` and `metric_drift` alert carries `drift_class`, `change_ids` and `unexplained_parts`
(`econquest/validation/drift_cause.py`, `tag_alerts`). The window of a pair is (previous run `created_at`, run
`created_at`]. A part that changed (settings, data or code hash) is explained by a recorded id dated in it:
settings by an approvals-log `apply` on assumptions.json, limits.json or scenarios.json; data by any `apply`, or a
data vintage in `data/live/vintages/index.csv` (the data hash also covers the settings files); code by a release
note in `docs/governance/releases/`. `explained` needs an id for every changed part; `as-of only` means only the
as-of date differs; anything else is `unexplained`, including a move with nothing changed. `summary.md` counts the
three classes and each alert line shows its class and ids. On the shared archive (as of 2026-10-25, no
challengers): 41 drift alerts, 37 explained and 4 unexplained (the 2026-10-23 09:03 to 11:13 pair: a settings change
before the approvals log starts at 16:32). The monthly view on the benchmark history is
`econquest/validation/benchmark_job.py` ([benchmarks.md](benchmarks.md)). Data refreshes that write no approvals row
and no vintage (the daily event panel update, for example) count as unexplained: that is the signal to look.

## Champion and challengers

The champion is `data/assumptions.json` as shipped. Each challenger is a patch made with `Settings.copy_with`, run
at 20,000 requested paths (32,768 Sobol) on the same as_of and universe. The fixed seed gives common random numbers,
so the deltas measure the option, not noise. The SE columns only give a sense of size.

Result on 2026-10-24, rerun after the review fixes on the current `assumptions.json` (real data, as_of 2026-10-23, $mm):

| Model | Patch | VaR99 | ES99 | EL | L-VaR99 | dVaR99 | dES99 | dEL | dVaR99 / SE | dES99 / SE |
|---|---|---|---|---|---|---|---|---|---|---|
| champion | shipped settings | 69.03 | 91.21 | 0.80 | 74.32 | 0 | 0 | 0 | 0 | 0 |
| vol_source_regime | `monte_carlo.vol_source=regime` | 69.64 | 93.17 | 0.87 | 74.92 | +0.60 | +1.96 | +0.07 | +0.8 | +2.1 |
| copula_judgement | `copula.source=judgement` | 58.73 | 76.65 | 0.80 | 64.01 | -10.31 | -14.56 | -0.00 | -13.8 | -15.3 |
| market_move_lognormal | `monte_carlo.market_move=lognormal` | 63.17 | 81.97 | 0.98 | 68.45 | -5.86 | -9.24 | +0.18 | -7.8 | -9.7 |
| overlap_additive | `monte_carlo.default_spread_overlap=additive` | 73.81 | 96.54 | 0.12 | 79.09 | +4.77 | +5.33 | -0.68 | +6.4 | +5.6 |

None of the challengers moves a PD (they act on the market and dependence layers). The run takes about 20 seconds.

## Result on the archive today

Rerun 2026-10-24 after the review fixes. 18 base runs (2026-10-20 to 2026-10-24, as_of up to 2026-10-23) gave 36 red
and 10 amber alerts. All of them are on pairs where the data hash, the settings hash or both changed. These are
the release steps from 0.1.2 to 0.2.1, the 2026-10-23 live pull, and run `20261024T124804-base`, which was archived
after `layer1.calibration_universe` was added to `assumptions.json` at 12:38. None is unexplained drift. Five pairs
have the same settings and data hash. All five differ in code, so the defect rule does not apply to any of them
(they reproduce VaR99, ES99 and L-VaR99 exactly anyway). Stability defects: 0. The four red PSI rows are the primary-balance
gap and reserves in months of imports after the 2026-10-23 WEO pull. The annual review calendar has 16 components,
each last reviewed 2026-10-23 and due 2027-10-23. No review is due within 60 days.

## Review calendar

`review_calendar` reads the summary table of `docs/governance/model-inventory.md`. Last review is the latest date
on the header line ("Date:", "Generated", "Regenerated", "Sample") of the component's validation document(s). When
the inventory points to the repository `README.md` or a document has no date line, the inventory date is used and
`last_review_source` says so. The owner is the one named in the inventory preamble. Next due is last review plus
one year. Tier 1 and 2 components also need the quarterly revalidation in `revalidation-routine.md`. The calendar
tracks the annual review only and names that cadence in `policy_cadence`.

## Limitations

- The archive keeps no raw indicators, so indicator-level PSI starts from the first snapshot this job saves.
  The first run has no indicator PSI.
- PSI on 18 countries is noisy (see above). It is a pointer, not a test.
- The fallback SE for old archives is an approximation, and the batch-means SE is conservative for scrambled Sobol
  (see `copula-montecarlo-layers5-6.md`).
- PD drift has no SE: PDs do not depend on the simulation.
- The challenger list is fixed in code. A new option has to be added to `CHALLENGERS` or passed with
  `--challengers-json`.
