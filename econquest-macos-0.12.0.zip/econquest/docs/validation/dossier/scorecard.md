# Dossier: scorecard (83 indicators, 7 pillars)

Tier 1. Code: `econquest/scorecard/scoring.py` (`score_universe`), `scorecard/readiness.py`. Parameters:
`assumptions.json` `scorecard`, `floors`, `boom_trigger`, `stress_path`; `data/rulebook.csv`. Source document:
`docs/validation/scorecard.md`. Evidence class: method replicated; inputs mostly judgement (seed estimates).

## Purpose and use
Scores 83 raw indicators per country 0 to 100 by threshold interpolation, aggregates to seven pillars, a
composite and a 1 to 10 grade. Feeds layer 2 (`w_s` x (composite - 45.8)), layer 1 (pillar 4 as the PITF
instability proxy), the peril PDs (pillar drivers) and the signals. Reported on the dashboard and the workbook.

## Conceptual soundness
The workbook's Appendix A rulebook, ported. Thresholds and weights are expert judgement, not calibrated to
default outcomes (GOV-011). The worst-indicator blend (0.2) and floors make the composite discontinuous in its
inputs and let floors dominate (Venezuela). Reasonable as a structured expert score; not a probability model.

## Data
`indicators.csv` 1,494 cells; 224 live (15%), the rest seed estimates from "analyst/Claude, Oct 2026" with no
individual author (GOV-010, GOV-036, GOV-039). Reserves cover uses exports as the import proxy (GOV-009).
Since EQ-B-0045 a readiness gate stops a run with missing required fields (88-country work).

## Implementation
Vectorised in EQ-B-0034, regression-tested against the workbook (`tests/test_panoptix.py`,
`test_scorecard_matches_workbook`: composite within 0.15, pillars within 0.1, grades exact). Readiness has its
own tests. Blank cells are dropped from pillar averages (scorecard.md open item 2).

## Outcomes analysis
None against outcomes: no default panel links composite to default frequency. The replication reproduces the
workbook on the seed snapshot (checks S01 to S03: composite max gap 0.079, pillar max gap 0.05, 18/18 grades).
That proves the port, not the model.

## Limitations
Seed inputs; uncalibrated thresholds; discontinuity from the worst-indicator blend; one fixed stress path for all
countries; momentum signal dead because the `prior` composite is empty (GOV-031).

## Sensitivity (release 0.1.5, recomputed)
Recomputed for EQ-B-0057 on release 0.1.5 settings and the data in `data/` on 2026-10-24 (as_of 2026-10-23, 20,000 requested = 32,768 Sobol paths, seed 7). Base: VaR99 73.00 ±0.69, ES99 95.68 ±0.82, EL 0.471 $mm (± is the batch-means SE, `var99_se_mm` / `es99_se_mm`). n.s. = within 2 SE of base. Full table: [sensitivity-tables.md](sensitivity-tables.md).

The scorecard has no parameter read through `Settings.copy_with` that changes VaR. Its weight in the PDs is
`probability.w_s` (layer 2 table): ±0.01 moves Zimbabwe's PD ±10 pp and EL ±0.3 $mm, VaR99 and ES99 n.s. The
validator step 3 below (perturb `worst_blend`) remains the scorecard's own sensitivity test.

## Use-restriction status
Covered by 6.1 (seed inputs, 15% live coverage).

## Open findings
GOV-009, GOV-010 (High), GOV-011, GOV-036 (High), GOV-039. No new finding.

## Independent validator should re-perform
1. Recompute 10 indicator scores by hand from `rulebook.csv` thresholds for two countries (one floor-bound, one
   not) and compare with `Scorecard.indicator_scores`.
2. Sample 20 live cells against the vintage folder `data/live/vintages/<date>/` and the source API, and 20 seed
   cells against any public source; record the error rate.
3. Perturb `scorecard.worst_blend` and the eligibility weight by +/-50% and report composite rank changes.
4. Once a panel exists: composite at t against default in t+1 (AUC, calibration).

## Part 3: status at 0.8.0 (EQ-B-0126, 2026-10-26)

Brings this dossier from 0.1.5 to releases 0.7.0 and 0.8.0. The 0.8.0 base is the 0.7.0 base (no model change in 0.8.0): shared data, as_of 2026-10-23, 100k VaR99 66.78, ES99 88.48, EL 4.10, L-VaR99 72.06 $mm. Sensitivity rows are from the regenerated [sensitivity-tables.md](sensitivity-tables.md) (20,000 paths, base VaR99 66.96 ±0.83, ES99 89.00 ±1.03, bit-identical to the release 20k base). The sections above describe 0.1.4/0.1.5 and are kept as written.

**Changes since 0.1.5.** No change to the scorecard method, thresholds or weights. Data and rules only:
- Pakistan and Argentina 1.2 double count removed (0.6.0, Team A batch; VaR99 -0.11, no grade change).
- Tier 2 method rules decided by the Team B lead in `docs/validation/indicator-rules.md` sections 12 to 21: 1.8 (16),
  2.1 non-IMF route for client output (17), 1.5 (18), 6.1 and 6.9 (19), QEDS 2.9/2.10 (20) and 2.2 (21), 3.6 rule
  13.1 and the 3.7 publication default (13.7). The first values that replace seeds are Tier 1 data batches parked for
  Sam (first-mac-pass D2 and the D-items).
- IMF-sourced cells are internal only (policy 6.10, EXC-003). The client-safe run (inventory row 23) replaces them; on
  0.7.0 data client-safe VaR99 is +9.2% over house, mostly the 2.1 placeholder (GOV-049).

**Sensitivity (current base).** `w_s` 0.03 / 0.05 per point: VaR99 -0.3% / +0.5% (n.s.), EL -0.30 / +0.35 $mm,
Zimbabwe PD -10.3 / +10.0 pp. The composite moves single PDs a lot and the tail hardly at all, as at 0.1.5.

**Use restrictions.** 6.1 (no external PD) and, new in policy v2, 6.10 (IMF internal only) and 6.14 (client
output only from the client-safe run).

**Open findings.** GOV-009, GOV-010, GOV-011, GOV-036, GOV-037, GOV-039 (unchanged); GOV-049 (client-safe gap).
