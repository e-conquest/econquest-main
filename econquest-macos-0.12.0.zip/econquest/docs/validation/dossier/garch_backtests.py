"""Evidence for the GARCH/DCC Tier 1 dossier (EQ-B-0068, VF-001): backtests, parameter stability, book sensitivity.

    python docs/validation/dossier/garch_backtests.py                 # all three parts, writes CSVs next to this file
    python docs/validation/dossier/garch_backtests.py --only backtest,stability --out /tmp/x

Data: data/market_history (via load_universe) cut at AS_OF with `garch.prices_as_of`; no later row is read.
Same preprocessing as production (`garch._mc_returns`: bad-tick cleaning, business days; `garch._returns`).

1. backtest: per series, one-day VaR99/ES99 out of sample, expanding window from 500 returns, refit every 21
   (`econquest.validation.garch_backtest.rolling_var_backtest`); both tails; Kupiec, Christoffersen, Acerbi-Szekely Z2,
   Basel zone; EWMA(0.94) Gaussian benchmark on the same days; 21-day cumulative-variance z on non-overlapping blocks.
2. stability: 500-return rolling windows every 63 returns: persistence, nu, 12-month MC vol per series; DCC a, b per
   block (FX 17 pairs, equity 10 ETFs) on each window's standardized residuals.
3. sensitivity: run_pipeline at 20,000 requested paths, as_of AS_OF, one GARCH choice at a time (common random numbers).
   Noise in a change is the paired batch-means SE (`paired_se`: 32 batches, the cut of `mc_error`, on the per-batch
   difference variant - base); "n.s." when |change| < 2 x that paired SE. Each run's own SE is kept in the CSV.

Bad-tick cleaning uses the next day's return to spot a reversal and is run once on the whole cut sample, as in
production; that is a one-day look-ahead inside the backtest for the few cleaned days (listed in garch-dcc.md).
Runtime: about 6 minutes.
"""
from __future__ import annotations

import argparse
import sys
import time
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from econquest.config import Settings  # noqa: E402
from econquest.engine import garch as G  # noqa: E402
from econquest.engine.pipeline import run_pipeline  # noqa: E402
from econquest.ingestion import load_universe  # noqa: E402
from econquest.validation import garch_backtest as GB  # noqa: E402

AS_OF = "2026-10-23"
PATHS = 20_000
MC_BATCHES = 32           # metrics["mc_error_batches"] at 32,768 paths
HERE = Path(__file__).resolve().parent


def series_list(u) -> list[tuple[str, str, str]]:
    """(country, kind, ticker) for the 27 series run_garch fits, in its order."""
    cty = u.countries.set_index("country")
    out = []
    for c in u.names:
        ccy = str(cty.at[c, "currency"]) if pd.notna(cty.at[c, "currency"]) else ""
        etf = str(cty.at[c, "etf"]) if pd.notna(cty.at[c, "etf"]) else ""
        for kind, t in (("FX", f"USD{ccy}" if ccy else ""), ("Equity", etf)):
            if t:
                out.append((c, kind, t))
    return out


def returns_table(u) -> pd.DataFrame:
    return G._mc_returns(G.prices_as_of(u.prices, AS_OF))


def mc_legs(u, s) -> set[str]:
    """Tickers whose GARCH 12-month vol the base Monte Carlo uses (positions.vol_from garch:*)."""
    from econquest.engine.layer6_montecarlo import garch_vol_table
    t = garch_vol_table(u, s.copy_with(as_of=AS_OF))
    return set(t.loc[np.isfinite(t["vol_pct"].astype(float)), "ticker"])


def part_backtest(u, rets, used) -> pd.DataFrame:
    rows = []
    for c, kind, t in series_list(u):
        if t not in rets.columns:
            continue
        r = G._returns(rets[t])
        if len(r) < 520:
            continue
        d, blocks = GB.rolling_var_backtest(r)
        e = GB.ewma_var_backtest(r)
        ms = GB.multi_step_summary(blocks)
        for side in ("long", "short"):
            g = GB.summarize(d, side); b = GB.summarize(e, side)
            rows.append({"country": c, "kind": kind, "ticker": t, "mc_leg": t in used, "administered": t in G.ADMINISTERED,
                         "side": side, "first_test": d["date"].iloc[0].date().isoformat(), "last_test": d["date"].iloc[-1].date().isoformat(),
                         **{f"garch_{k}": v for k, v in g.items()}, **{f"ewma_{k}": v for k, v in b.items() if k != "n"},
                         **{f"h21_{k}": v for k, v in ms.items()}})
    return pd.DataFrame(rows)


def part_stability(u, rets, used) -> tuple[pd.DataFrame, pd.DataFrame]:
    rows, std = [], {}
    for c, kind, t in series_list(u):
        if t not in rets.columns:
            continue
        r = G._returns(rets[t])
        if len(r) < 500:                   # e.g. USDBZD on official rates: a flat 2.00 peg has no returns (EQ-B-0088)
            continue
        p = GB.rolling_params(r)
        for i, w in p.iterrows():
            std.setdefault((kind, i), {})[t] = w["std_resid"]
            rows.append({"country": c, "kind": kind, "ticker": t, "mc_leg": t in used, "administered": t in G.ADMINISTERED,
                         "window": i, "end": w["end"].date().isoformat(),
                         **{k: w[k] for k in ("alpha", "beta", "persistence", "half_life_days", "nu", "mc_vol_12m_pct", "long_run_vol_pct")}})
    st = pd.DataFrame(rows)
    dcc_rows = []
    n_win = int(st["window"].max()) + 1
    for kind in ("FX", "Equity"):
        for i in range(n_win):
            Z = pd.DataFrame(std.get((kind, i), {})).dropna()
            if Z.shape[1] < 2 or len(Z) < 100:
                continue
            f = G.dcc_fit(Z)
            dcc_rows.append({"block": kind, "window": i, "end": Z.index[-1].date().isoformat(), "series": Z.shape[1], "obs": len(Z),
                             "a": f.a, "b": f.b, "a_plus_b": f.a + f.b, "avg_corr_next": f.avg_corr(f.R_next),
                             "avg_corr_uncond": f.avg_corr(f.R_uncond)})
    return st, pd.DataFrame(dcc_rows)


def _run(u, s):
    from econquest.engine.layer6_montecarlo import garch_vol_table, vol_source
    res = run_pipeline(u, s, paths=PATHS, as_of=AS_OF)
    m = res.metrics
    out = {k: float(m[k]) for k in ("var99_mm", "es99_mm", "expected_loss_mm", "lvar99_mm", "var99_se_mm", "es99_se_mm")}
    out["_losses"] = np.asarray(res.mc.losses, dtype=float)
    if vol_source(s) == "garch":
        t = garch_vol_table(u, s.copy_with(as_of=AS_OF))
        out["garch_vols_pct"] = "; ".join(f"{r.ticker} {r.vol_pct:.1f}" for r in t.itertuples() if np.isfinite(r.vol_pct))
    return out


ETF_COLUMNS = ("VNM", "EPHE", "MCHI", "EWM", "EWS", "EWJ", "EWY", "INDA", "EWZ", "ARGT", "GXG", "EEM")


def price_variants(u) -> dict:
    """Universe copies with a different price table (diagnostics only; data/ is not touched).
    fx_only: every ETF column removed, as after EQ-A-0054. (The INDA repair variant was dropped once Team A
    repaired prices.csv under EQ-A-0056.)"""
    import dataclasses
    return {"fx_only": dataclasses.replace(u, prices=u.prices.drop(columns=[c for c in ETF_COLUMNS if c in u.prices.columns]))}


def part_copula(u) -> pd.DataFrame:
    """Estimated Calm loadings (squared global, regional) for the base prices and the two price variants."""
    from econquest.engine import layer5_copula as L5
    rows = []
    for name, uu in (("base", u), ("fx_only", price_variants(u)["fx_only"])):
        f = L5.estimated_copula(uu, AS_OF)
        for c, v in f.global_loading.items():
            rows.append({"prices": name, "level": "global", "name": c, "loading_sq": float(v)})
        for rg, v in f.regional_loading.items():
            rows.append({"prices": name, "level": "regional", "name": rg, "loading_sq": float(v)})
        for c, why in f.left_out.items():
            rows.append({"prices": name, "level": "left_out", "name": c, "loading_sq": np.nan, "reason": why})
        rows.append({"prices": name, "level": "nu", "name": "nu", "loading_sq": float(f.nu)})
    return pd.DataFrame(rows)


def batch_estimates(losses: np.ndarray, batches: int, alpha: float = 0.99) -> tuple[np.ndarray, np.ndarray]:
    """VaR and ES per contiguous batch, the same cut as `layer6_montecarlo.mc_error`."""
    b = len(losses) // batches
    blocks = losses[:batches * b].reshape(batches, b)
    v = np.quantile(blocks, alpha, axis=1)
    e = np.array([blk[blk >= q].mean() for blk, q in zip(blocks, v)])
    return v, e


def paired_se(base: np.ndarray, var: np.ndarray, batches: int = 32) -> tuple[float, float]:
    """Batch-means SE of the change in VaR99 and ES99 between two runs on the same random numbers: the sd over
    batches of (variant batch estimate - base batch estimate) / sqrt(batches). Common random numbers make this much
    smaller than either run's own SE."""
    vb, eb = batch_estimates(base, batches); vv, ev = batch_estimates(var, batches)
    k = len(vb)
    return float(np.std(vv - vb, ddof=1) / np.sqrt(k)), float(np.std(ev - eb, ddof=1) / np.sqrt(k))


def part_sensitivity(u, s) -> pd.DataFrame:
    mk = s["market"]
    cty = u.countries.set_index("country")

    def regime_vol(country, kind):
        return float(mk["equity_vol"]) if kind == "Equity" else float(mk["fx_vol"].get(cty.at[country, "fxregime"], mk["fx_vol"]["Managed"]))

    variants = [
        ("base", "release settings (garch, full sample, Student-t)", {}, {}),
        ("check", "variant code, default options (must equal base)", {}, {"refit": True}),
        ("vol_source", "monte_carlo.vol_source regime", {"monte_carlo.vol_source": "regime"}, None),
        ("window", "estimation window last 500 returns (~2 years)", {}, {"window": 500}),
        ("window", "estimation window last 250 returns (~1 year)", {}, {"window": 250}),
        ("distribution", "Gaussian innovations", {}, {"dist": "normal"}),
        ("floor/cap", "floor at regime vol (GARCH may only raise)", {}, {"floor_rel": 1.0, "regime_vol": regime_vol}),
        ("floor/cap", "cap at regime vol (GARCH may only lower)", {}, {"cap_rel": 1.0, "regime_vol": regime_vol}),
        ("floor/cap", "floor at 0.75 x regime vol", {}, {"floor_rel": 0.75, "regime_vol": regime_vol}),
        ("floor/cap", "market.vol_cap 40 (base 60)", {"market.vol_cap": 40.0}, None),
        ("fallback", "garch_vol.persistence_max 0.999 (base 0.995)", {"monte_carlo.garch_vol.persistence_max": 0.999}, None),
        ("fallback", "garch_vol.persistence_max 0.99", {"monte_carlo.garch_vol.persistence_max": 0.99}, None),
        ("fallback", "garch_vol.administered empty (USDNGN then fails the persistence gate)", {"monte_carlo.garch_vol.administered": []}, None),
        ("copula", "copula.source judgement (base estimated)", {"copula.source": "judgement"}, None),
        ("data", "FX-only prices: ETF columns removed (EQ-A-0054 target state)", {}, "fx_only"),
    ]
    rows = []
    base = None
    for group, label, patch, kw in variants:
        t0 = time.perf_counter()
        ss = s.copy_with(**patch) if patch else s
        if isinstance(kw, str):
            m = _run(price_variants(u)[kw], ss)
        elif kw:
            with GB.garch_variant(**kw):
                m = _run(u, ss)
        else:
            m = _run(u, ss)
        if base is None:
            base = m
        losses = m.pop("_losses")
        if base is m:
            base_losses = losses
        if len(losses) == len(base_losses):
            se_v, se_e = paired_se(base_losses, losses, int(MC_BATCHES))
        else:
            se_v, se_e = float("nan"), float("nan")
        rows.append({"group": group, "variant": label, **m, "d_var99_paired_se_mm": se_v, "d_es99_paired_se_mm": se_e,
                     "d_var99_pct": (m["var99_mm"] / base["var99_mm"] - 1) * 100, "d_es99_pct": (m["es99_mm"] / base["es99_mm"] - 1) * 100,
                     "d_el_mm": m["expected_loss_mm"] - base["expected_loss_mm"],
                     "var99_ns": bool(abs(m["var99_mm"] - base["var99_mm"]) <= 2 * se_v) if np.isfinite(se_v) else None,
                     "es99_ns": bool(abs(m["es99_mm"] - base["es99_mm"]) <= 2 * se_e) if np.isfinite(se_e) else None,
                     "seconds": round(time.perf_counter() - t0, 1)})
        print(f"  {label}: VaR99 {m['var99_mm']:.3f} ES99 {m['es99_mm']:.3f}", flush=True)
    return pd.DataFrame(rows)


def main(argv=None):
    ap = argparse.ArgumentParser()
    ap.add_argument("--data", default=str(ROOT / "data"))
    ap.add_argument("--out", default=str(HERE))
    ap.add_argument("--only", default="backtest,stability,copula,sensitivity")
    a = ap.parse_args(argv)
    warnings.filterwarnings("ignore")
    out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    parts = set(a.only.split(","))
    u = load_universe(a.data); s = Settings.load(Path(a.data) / "assumptions.json")
    rets = returns_table(u)
    assert rets.index.max() <= pd.Timestamp(AS_OF)
    used = mc_legs(u, s)
    if "backtest" in parts:
        t0 = time.perf_counter(); bt = part_backtest(u, rets, used)
        bt.to_csv(out / "garch-tier1-backtests.csv", index=False, float_format="%.6g")
        print(f"backtest: {len(bt)} rows, {time.perf_counter() - t0:.0f} s")
    if "stability" in parts:
        t0 = time.perf_counter(); st, dcc = part_stability(u, rets, used)
        st.to_csv(out / "garch-tier1-stability.csv", index=False, float_format="%.6g")
        dcc.to_csv(out / "garch-tier1-dcc.csv", index=False, float_format="%.6g")
        print(f"stability: {len(st)} rows, dcc {len(dcc)} rows, {time.perf_counter() - t0:.0f} s")
    if "copula" in parts:
        part_copula(u).to_csv(out / "garch-tier1-copula.csv", index=False, float_format="%.6g")
        print("copula: written")
    if "sensitivity" in parts:
        t0 = time.perf_counter(); se = part_sensitivity(u, s)
        se.to_csv(out / "garch-tier1-sensitivity.csv", index=False, float_format="%.6g")
        print(f"sensitivity: {len(se)} rows, {time.perf_counter() - t0:.0f} s")


if __name__ == "__main__":
    main()
