# Validation dossier, part 1 (SR 11-7 style)

Date: 2026-10-23. Ticket EQ-B-0051 (GOV-042). Written by Team B AGENT-02 from the validation documents in
`docs/validation/`, the governance files (`model-inventory.md`, `model-risk-policy.md`, `issues-log.md`, releases
0.1.1 to 0.1.4) and a reading of the code on this date. Model state: release 0.1.4 (`monte_carlo.vol_source`
garch, `copula.source` estimated, `layer1.mode` paper_standardized).

**Part 2 (2026-10-24, EQ-B-0057, Team B AGENT-05)** brings every layer dossier to release **0.1.5** (no
`assumptions.json` change since 0.1.4; new options all off; FED22/TAPER13 rate shocks) and adds to each a recomputed
sensitivity section and a use-restriction status. The use-restriction review for Sam and the validator is
[use-restrictions-review.md](use-restrictions-review.md) (EQ-B-0059).

**Part 3 (2026-10-26, EQ-B-0126, Team B AGENT-07)** brings every layer dossier to releases **0.7.0 and 0.8.0**
(the 0.8.0 base is the 0.7.0 base: shared data, as_of 2026-10-23, 100k VaR99 66.78, ES99 88.48, EL 4.10, L-VaR99
72.06 $mm). Each layer file ends with a "Part 3: status at 0.8.0" section: changes since 0.1.5, the regenerated
sensitivity on the current base, use restrictions under policy v2 (6.1 to 6.14) and open findings. The sensitivity
tables are regenerated (see below), the register gains GOV-047 to GOV-050, and the validator's file list with its
licence filter is [../engagement/data-room-files.md](../engagement/data-room-files.md).

**This is not an independent validation.** The author belongs to the team that built the model, so the dossier
is the pack an independent validator would start from (policy principle 4; GOV-042 stays open). Every section
says what the evidence is: *fitted* (estimated on real data in this repository), *judgement* (paper, workbook or
analyst values), or *synthetic* (made-up or model-drawn data, GOV-028).

## Files

| Layer | Dossier | Tier | Evidence class today | Main open findings |
|---|---|---|---|---|
| Scorecard | [scorecard.md](scorecard.md) | 1 | Method replicated against the workbook; inputs ~85% seed | GOV-010, GOV-011, GOV-036 |
| Layer 1 hazard | [layer1-hazard.md](layer1-hazard.md) | 1 | Judgement coefficients; pilot fit thin (9 events) | GOV-006, GOV-007, VF-005 |
| Layer 2 Bayesian | [layer2-bayesian.md](layer2-bayesian.md) | 1 | Judgement weights; placeholder market prior | GOV-013, GOV-016 |
| Layer 3 regimes | [layer3-regimes.md](layer3-regimes.md) | 2 | Judgement rules and matrix; HMM fitted, not adopted | GOV-018, GOV-019 |
| Layer 4 severity | [layer4-severity.md](layer4-severity.md) | 1 | Judgement means; fit code waits on data | GOV-024, GOV-025 |
| Layer 5 copula | [layer5-copula.md](layer5-copula.md) | 1 | Loadings fitted (0.1.4); nu and regime steps judgement | GOV-021, VF-001 |
| Layer 6 Monte Carlo | [layer6-montecarlo.md](layer6-montecarlo.md) | 1 | Simulation verified; GARCH vols fitted (0.1.4) | GOV-020, GOV-023, VF-004 |
| Stress | [stress.md](stress.md) | 2 | Judgement shocks; stylised history | GOV-026, GOV-027 |
| Signals | [signals.md](signals.md) | 2 / 3 | Judgement rules; never backtested | GOV-016, GOV-031 |

Findings: [findings-register.csv](findings-register.csv). One row per GOV issue that bears on a layer (text stays
in `issues-log.md`; the register cross-references it) plus new findings `VF-001` to `VF-010` found while writing
this pack, each with its evidence.

## Replication

`python -m econquest.validation.replicate --data data --out outputs/replication` recomputes, from public
functions and the stored inputs, every number in the 0.1.4 release note and the key numbers of the validation
documents (121 checks), and writes `replication.csv` and `replication.md`. It reads no archived run. `--quick`
runs at 20,000 requested paths with loose tolerances (tests: `tests/test_replicate.py`).

Result on 2026-10-23 (full mode, 84 s): **104 PASS, 15 STALE, 2 INFO, 0 FAIL**. At 0.8.0 (part 3): **141 PASS, 2 INFO, 0 FAIL** on the shared data (release note 0.8.0, lead rerun on a fresh local copy); pins R48-R51 hold the 0.7.0 base and older pins run on their frozen inputs (`docs/governance/releases/inputs/`).

- Release 0.1.4: all 29 numbers reproduce (base VaR99 74.351, ES99 96.480, EL 0.453, L-VaR99 79.633 at 131,072
  paths; all 8 stress ES99s and changes; limit utilisations; fitted loadings; EWY GARCH vol; no PD moves).
- Validation documents: the 0.1.3 base, GARCH-only, estimated-copula, HMM, cliff, layer 2 sensitivity rows, the
  20,000-path default-is-identical figures (64.2337 / 83.6673 / 0.53438), both backtests, the stored-panel hazard
  fit, the workbook scorecard and regimes, and the GARCH medians all reproduce.
- STALE (document predates a recorded change; recomputed value in the table): README checklist steps 2 and 4,
  inventory components 6 to 9, policy restriction 6.6, and the hazard-fit report (benchmarks after EQ-B-0006,
  panel after the predictor-lag change). See VF-002 and VF-005.
- INFO: `code_hash` and `data_hash` differ from the release run: code edited since, and `data/scenarios.json`
  changed after the release (VF-003). The numbers still reproduce.

## Sensitivity tables (part 2, regenerated in part 3)

[sensitivity-tables.md](sensitivity-tables.md) (and `.csv`) is generated, not written: every row is
`run_pipeline(u, s.copy_with(**patch), paths=20000, as_of="2026-10-23")` on the current `data/` folder against a
base run made the same way, one parameter at a time, with the Monte Carlo SE of each run (`var99_se_mm`,
`es99_se_mm`). A change within 2 SE of base is marked n.s. Rerun from the repository root (about 40 s):

    python docs/validation/dossier/sensitivity_tables.py
    python docs/validation/dossier/sensitivity_tables.py --out /tmp/sens --only layer3,stress   # subset, elsewhere

The tables move when `data/` moves (prices are appended daily). The 2026-10-26 refresh (EQ-B-0126) used prices
through 2026-10-23 and gives a base bit-identical to the 0.7.0 / 0.8.0 release base at 20k; the script prints that
check in the header.
To check against the frozen release inputs instead, use `replicate.py` above.

Part 3 headline on the current base (econquest 0.8.0, data_hash 308b73ca9e257627; base VaR99 66.96 ±0.83, ES99
89.00 ±1.03, EL 4.099 $mm at 20,000 requested / 32,768 Sobol paths, bit-identical to the release 20k base
66.95612571109443):

| Rank | Parameter | Effect | Dossier |
|---|---|---|---|
| 1 | Global switch threshold `global_stress_share` 0.5 to 0.4 | VaR99 +12.4%, ES99 +13.5% | layer 3 |
| 2 | Copula loadings `copula.source` estimated to judgement | VaR99 -8.3%, ES99 -10.7% | layer 5 |
| 3 | nu (`df_calm` 5 to 30, = estimated nu) | VaR99 -7.9%, ES99 -14.5%; nu 3: ES99 +5.1% | layer 5 |
| 4 | Merton uplift off (`layer4.merton.apply_uplift` false) | VaR99 -6.7%, ES99 -5.9%, EL -1.78 $mm | layer 4 |
| 5 | Regime vols instead of GARCH (`monte_carlo.vol_source` regime) | VaR99 +6.2%, ES99 +5.0% | layer 6 |
| 6 | `risk_premium_ratio` 2 to 3 | VaR99 -2.8%, ES99 -2.5% | layer 2 |
| — | Layer 1 weight and fitted mode, `w_m`, `w_s`, Crisis multiplier, LGD sd, path count, seed | n.s. on VaR99/ES99 | 1, 2, 3, 4, 6 |

The tail is still set by dependence (layer 3 switch, layer 5 loadings and nu). Since 0.6.0 the EL levers are the
PD side (hazard weight ±0.6 to 0.8 $mm) and the Merton uplift (-1.78 $mm), which matters for the EL warning band
(GOV-048). Fitted layer 1 now runs at the current as_of (VF-012 rule) and moves PDs by up to 3.2 pp with VaR99 n.s.

Part 2 headline (0.1.5, superseded; base VaR99 73.00 ±0.69, ES99 95.68 ±0.82, EL 0.471 $mm at 32,768 paths):

| Rank | Parameter | Effect | Dossier |
|---|---|---|---|
| 1 | Global switch threshold `global_stress_share` 0.5 to 0.4 (one more non-Calm country) | VaR99 +15.4%, ES99 +17.0% | layer 3 |
| 2 | Copula loadings `copula.source` estimated to judgement | VaR99 -12.9%, ES99 -13.8% | layer 5 |
| 3 | nu (`df_calm` 5 to 30, = estimated nu) | VaR99 -6.3%, ES99 -12.7%; nu 3: ES99 +4.4% | layer 5 |
| 4 | Logistic global switch (option, off) | VaR99 +4.7%, ES99 +4.5% | layer 3 |
| 5 | `risk_premium_ratio` 2 to 3 | VaR99 -3.8%, ES99 -2.2% | layer 2 |
| — | Layer 4 LGD means and sd, `w_s`, `hazard_weight`, Crisis multiplier, path count, seed | all n.s. on VaR99/ES99 | 1, 2, 3, 4, 6 |

The tail is set by dependence (layer 3 switch, layer 5 loadings and nu), not by PDs or LGDs. PD-side parameters
move individual PDs a lot (Zimbabwe up to ±23 pp) and EL by 50 to 300%, but VaR99 and ES99 by under 4%. New
findings from part 2: VF-011 (EL is net of carry and changes sign), VF-012 (fitted layer 1 cannot run at a
current-year as_of), VF-013 (placeholder prediction-market prices reach reported PDs).

## How to use this pack (validator)

1. Run the replication in full mode and file the table with the review.
2. For each layer, re-perform the steps in its "Independent validator should re-perform" section. They are
   chosen to test the claims the model's numbers depend on most, not to repeat the unit tests.
3. Mark each register row accepted, rejected or re-graded; raise new rows as `GOV-` issues.
4. Rerun `sensitivity_tables.py` and compare with the committed tables; then read
   [use-restrictions-review.md](use-restrictions-review.md) and sign or reject each recommendation.
