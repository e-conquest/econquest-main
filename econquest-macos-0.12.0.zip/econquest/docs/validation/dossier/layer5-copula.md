# Dossier: layer 5 Student-t copula and liquidity cost

Tier 1. Code: `econquest/engine/layer5_copula.py` (`factor_loadings`, `estimated_copula`, `fit_t_copula`,
`correlation_matrix`, `degrees_of_freedom`, `tail_dependence`, `liquidity_cost`). Parameters: `regime.*`
loadings, `copula`, `monte_carlo.df_*`, `liquidity`. Source: `copula-montecarlo-layers5-6.md`. Evidence class:
global and regional Calm loadings fitted on weekly returns (since 0.1.4); nu, regime steps and the 1.5x global
multiplier judgement; liquidity judgement.

## Purpose and use
One-factor-per-block t copula (global, regional, idiosyncratic) that drives every position's market move and
event in layer 6. Sets the book's tail dependence; with nu and the Calm loading it is one of the three parameters
the tail numbers depend on most (validation README, cross-cutting findings).

## Conceptual soundness
The block structure is parsimonious and standard. Since 0.1.4 the Calm global loading per country comes from a
t-copula maximum-likelihood fit on 157 weekly returns (Singapore 0.81, Korea 0.51, Malaysia 0.51 against the
judgement 0.15); the fit measures dollar and equity co-movement, not credit linkage, and six countries that drive
the default tail have no usable series and keep judgement. The estimated nu (30) was rejected (flat likelihood);
nu stays 5/4. The regime step is measured from the 0.15 judgement anchor (release 0.1.4 defect fix for
scenario C).

## Data
`data/market_history/prices.csv`, weekly Fridays 2023-10-27 to 2026-10-23, cut at the run's as_of (EQ-B-0036
review fix). Pegged and administered quotes excluded (GOV-034).

## Implementation
Fit cached per as_of; falls back to judgement with a warning when no price history exists. Tests:
`tests/test_layer5_copula.py` (4), `test_market_fit_as_of.py` (4).

## Outcomes analysis
Replication R25 to R27 reproduce the fitted loadings; D01 to D04 reproduce the four copula variants (mean latent
correlation 0.239 judgement, 0.335 estimated). There is no out-of-sample test of joint default or joint large loss
frequencies; the econometrics Table 8 preference for t over Clayton (13 of 13 pairs) is the only other data support.

## Limitations
Weekly co-movement over three calm years is not 12-month joint default risk; judgement nu sets the tail; no trade
or financial links; liquidity cost deterministic and additive (GOV-022).

## Sensitivity (release 0.1.5, recomputed)
Recomputed for EQ-B-0057 on release 0.1.5 settings and the data in `data/` on 2026-10-24 (as_of 2026-10-23, 20,000 requested = 32,768 Sobol paths, seed 7). Base: VaR99 73.00 ±0.69, ES99 95.68 ±0.82, EL 0.471 $mm (± is the batch-means SE, `var99_se_mm` / `es99_se_mm`). n.s. = within 2 SE of base. Full table: [sensitivity-tables.md](sensitivity-tables.md#layer-5-copula).

| Change | VaR99 | ES99 | EL | nu |
|---|---|---|---|---|
| `copula.source` judgement (base estimated) | **-12.9%** | **-13.8%** | 0.00 | 5 |
| `copula.nu_source` estimated (nu 30.0) | **-6.3%** | **-12.7%** | +0.10 | 30 |
| `df_calm` 3 (base 5) | +0.1% n.s. | **+4.4%** | -0.02 | 3 |
| `df_calm` 8 | **-3.5%** | **-5.2%** | +0.05 | 8 |
| `df_calm` 30 | **-6.3%** | **-12.7%** | +0.10 | 30 |

The source of the loadings is the largest sensitivity: the price-fitted loadings add 9.4 $mm VaR99 and 13.2 $mm ES99
over judgement. nu is the main ES driver. The estimated nu (30.0) gives exactly the `df_calm 30` row, and its
profile likelihood is flat from 20 to 60 (298.47 at 30, 297.85 at 20, 297.86 at 60), so the data cannot choose a
nu above 15. Judgement nu 5 still carries the tail (known; `copula-montecarlo-layers5-6.md`). The loadings were
refitted on today's prices (Singapore 0.81 to 0.87, release note 0.1.5).

## Use-restriction status
Covered by 6.1. VF-001 (GARCH/DCC still Tier 2 while it sets Tier 1 inputs) remains for Sam.

## Open findings
GOV-021 (mitigated), GOV-022, GOV-034; VF-001 (the price-fitted copula and GARCH inputs now set Tier 1 numbers but
the GARCH layer is still inventoried Tier 2).

## Independent validator should re-perform
1. Refit `fit_t_copula` with a different start and a 26-week block bootstrap; confirm the Singapore and Korea
   loadings and intervals.
2. Fit the same structure on 2008-2012 or 2020 weekly data if obtainable, to see stressed-period loadings.
3. Rerun the book at nu 4, 5, 8 with estimated loadings and report ES99 (the judgement parameter now carrying the tail).

## Part 3: status at 0.8.0 (EQ-B-0126, 2026-10-26)

Brings this dossier from 0.1.5 to releases 0.7.0 and 0.8.0. The 0.8.0 base is the 0.7.0 base (no model change in 0.8.0): shared data, as_of 2026-10-23, 100k VaR99 66.78, ES99 88.48, EL 4.10, L-VaR99 72.06 $mm. Sensitivity rows are from the regenerated [sensitivity-tables.md](sensitivity-tables.md) (20,000 paths, base VaR99 66.96 ±0.83, ES99 89.00 ±1.03, bit-identical to the release 20k base). The sections above describe 0.1.4/0.1.5 and are kept as written.

**Changes since 0.1.5.**
- 51 bad INDA prices repaired (0.3.0, VF-019): the copula read them as huge India returns.
- Official FX-only prices (0.5.0, Sam's PI-7 decision; official fx3m in 0.7.0). There are no ETF series now. The
  estimated loadings use FX moves only for ten countries, and seven keep judgement loadings (Argentina, Belize,
  Nigeria, Pakistan, Senegal, Venezuela, Zimbabwe; run warning EQ-B-0077).
- VF-001 resolved: the FX GARCH marginals are Tier 1 (inventory row 10a), DCC stays Tier 2 (10b).

**Sensitivity (current base).**
- Judgement loadings: VaR99 -8.3%, ES99 -10.7%.
- `nu_source` estimated, the same as nu 30: VaR99 -7.9%, ES99 -14.5%.
- nu 3: ES99 +5.1%. nu 8: ES99 -5.6%.
Dependence is still where the tail is set.

**Use restrictions.** 6.11 (the theratesapi FX columns VES, NGN, PKR, VND and ZMW are internal only; under EXC-005
they enter the price history that the loadings are fitted on).

**Open findings.** GOV-021 (mitigated 0.1.4), GOV-022, GOV-034.
