# Dossier: signals, trade activation, GPR uplift, prediction-market stakes

Tier 2 (signals, GPR) and Tier 3 (Kelly stakes). Code: `econquest/engine/signals.py` (`compute_signals`,
`trade_activation`, `dashboard_table`), `engine/gpr.py`, `layer2_bayesian.arbitrage_scan`,
`validation/idea_log.py`. Parameters: `signals`, `gpr`, `prediction_markets`; `data/playbook.csv`. Sources:
`signals-trades.md`, `gpr-and-prediction-markets.md`. Evidence class: judgement rules; GPR on real
Caldara-Iacoviello data; prediction-market prices placeholders.

## Purpose and use
25 signals on a 0 to 100 scale per country, 26 playbook trades with conviction and sizing, dashboard reads; GPR
uplift on indicator 4.10; Kelly stakes on contract divergences. Decision support only (restriction 6.5); no
signal feeds VaR or ES (the portfolio comes from `portfolio.csv`).

## Conceptual soundness
Faithful port of the workbook rules with two documented changes (EQ-B-0008). Conviction reflects signal
construction (binary 100s), and signals 15 and 19 restate the layer 2 market weight rather than an independent
view. Kelly ignores uncertainty on p and uses placeholder prices (GOV-016).

## Data
GPR covers 11 of 18 countries (GOV-033); `prior` composite empty, so signal 17 is dead (GOV-031); 18 typed
contract prices.

## Implementation
Signals and activation stored per run (GOV-030 resolved); trade-idea log with daily marks (EQ-B-0038). Tests:
`tests/test_signals.py` (8), `test_signals_persist.py`, `test_idea_log.py`. No workbook regression test for the
signal tables (signals-trades.md open item 2).

## Outcomes analysis
None yet: no idea has closed; 11 of 75 ideas are markable (FX and equity). Signals have never been tested against
outcomes. The replication does not cover signals: no signal number is in the release note.

## Limitations
Untested rules; dead and saturated signals; stakes on placeholders; sizing ignores MC risk and limits (GOV-032).

## Sensitivity (release 0.1.5, recomputed)
Recomputed for EQ-B-0057 on release 0.1.5 settings and the data in `data/` on 2026-10-24 (as_of 2026-10-23, 20,000 requested = 32,768 Sobol paths, seed 7). Base: VaR99 73.00 ±0.69, ES99 95.68 ±0.82, EL 0.471 $mm (± is the batch-means SE, `var99_se_mm` / `es99_se_mm`). n.s. = within 2 SE of base. Full table: [sensitivity-tables.md](sensitivity-tables.md).

Signals feed no VaR, ES or EL (the book is `portfolio.csv`), so no Monte Carlo sensitivity applies. The
prediction-market prior that the signals use also feeds reported PDs (layer 2 table, VF-013).

## Use-restriction status
**6.2 conditional, 6.5 keep.** See [use-restrictions-review.md](use-restrictions-review.md).

## Open findings
GOV-016 (High), GOV-017, GOV-031, GOV-032, GOV-033; VF-013 (layer 2 channel of the placeholder prices).

## Independent validator should re-perform
1. Recompute three signals and one trade activation by hand for one country from the run's country table.
2. After four quarters of idea-log marks: hit rate and P&L by strategy against a random-entry benchmark.
3. Confirm the dashboard labels every prediction-market figure as illustrative while GOV-016 is open.

## Part 3: status at 0.8.0 (EQ-B-0126, 2026-10-26)

Brings this dossier from 0.1.5 to releases 0.7.0 and 0.8.0. The 0.8.0 base is the 0.7.0 base (no model change in 0.8.0): shared data, as_of 2026-10-23, 100k VaR99 66.78, ES99 88.48, EL 4.10, L-VaR99 72.06 $mm. Sensitivity rows are from the regenerated [sensitivity-tables.md](sensitivity-tables.md) (20,000 paths, base VaR99 66.96 ±0.83, ES99 89.00 ±1.03, bit-identical to the release 20k base). The sections above describe 0.1.4/0.1.5 and are kept as written.

**Changes since 0.1.5.**
- DSA signal 26 "Debt above IMF benchmark (DSA)" is on, display only (0.4.0). It uses IMF inputs, so it is internal
  (6.10), and it drops out of the client-safe run.
- The DSA PD overlay stays off.
- Event GPR stays "ci".
- House view (0.8.0): one judgement stance per country, no model number.
- Daily idea marks: a past row is never rewritten (EQ-B-0125).
- The 12-month idea scoring is due from 2027-10-23 and gives "review" only. There is no pass/fail rule (Sam's
  call, parked as card C in `docs/validation/calendar-test-rehearsal.md`). The rehearsal also found that the rolling
  window never scores the first cohort (RF-4).

**Sensitivity.** None in the tables (signals feed no VaR or ES).

**Use restrictions.** 6.5; 6.10 for signal 26.

**Open findings.** GOV-016, GOV-017, GOV-031, GOV-033.
