# Dossier: layer 3 regimes

Tier 2 (conditions Tier 1 numbers through PD and LGD multipliers, loadings and nu). Code:
`econquest/engine/layer3_regime.py` (`rule_regime`, `transition_matrix`, `regime_multipliers`, `global_regime`),
`econquest/engine/regime_hmm.py`. Parameters: `regime_rules`, `regime`, `transition_matrix`,
`monte_carlo.global_stress_share`. Sources: `regime-layer3.md`, `hmm-regime-report.md`. Evidence class: judgement
rules and matrix; the HMM is fitted on real weekly data but not adopted. State: release 0.1.5. EQ-B-0042 shipped
`regime.global_set` and `regime.global_switch` logistic, both off ("all", "step"); defaults bit-identical.

## Purpose and use
Calm / Stressed / Crisis per country from spread, 3-month depreciation and reserve loss; transition-weighted
12-month PD and LGD multipliers; a global regime (Stressed when at least half the countries are not Calm) that
selects copula nu and multiplies loadings by 1.5.

## Conceptual soundness
Rule thresholds (400/1000 bp, 5/15% FX, -10% reserves) are the paper's. The global switch is a cliff: VaR99 moves
by about 14% when it trips, with no PD change (GOV-018). The 12-month matrix is the paper's starting point, not
estimated and not rescaled to the horizon (GOV-019). No regime switching inside a path.

## Data
Two of three inputs hand-entered (spread, reserve change). HMM: 17 countries, 155 weeks of market history, no
Zimbabwe series.

## Implementation
Tests: workbook regimes on the seed snapshot (`test_panoptix.py::test_regimes_match_workbook`),
`tests/test_regime_hmm.py` (4). No module-named test file for `layer3_regime.py` (VF-008).

## Outcomes analysis
No regime classification has been checked against dated crisis episodes. Replication: S04 (18/18 workbook
regimes), D06 (hmm 80.98 / 105.19 / 0.622) and D07 (cliff reference at `global_stress_share 0.4`: 73.23 / 96.21
/ 0.508) reproduce, so the documented size of the cliff is confirmed: on the 0.1.3 settings, tripping the switch
adds 9.3 $mm (+14%) to VaR99 with no PD change. Today 8 of 18 countries are not Calm; one more trips it.

## Limitations
Hand-entered inputs decide regimes; cliff; unestimated matrix; HMM fitted on three mostly calm years; fitted
12-month matrix close to stationary in every row (forgets the start state).

## Sensitivity (release 0.1.5, recomputed)
Recomputed for EQ-B-0057 on release 0.1.5 settings and the data in `data/` on 2026-10-24 (as_of 2026-10-23, 20,000 requested = 32,768 Sobol paths, seed 7). Base: VaR99 73.00 ±0.69, ES99 95.68 ±0.82, EL 0.471 $mm (± is the batch-means SE, `var99_se_mm` / `es99_se_mm`). n.s. = within 2 SE of base. Full table: [sensitivity-tables.md](sensitivity-tables.md#layer-3-regimes).

| Change | VaR99 | ES99 | EL | Global state (weight) |
|---|---|---|---|---|
| `global_stress_share` 0.4 (base 0.5) | **+15.4%** | **+17.0%** | -0.04 | Stressed (1) |
| `global_stress_share` 0.6 | 0.0% n.s. | 0.0% n.s. | 0.00 | Calm (0) |
| `global_switch` logistic, width 0.05 | **+4.7%** | **+4.5%** | -0.01 | Calm (0.25) |
| `global_switch` logistic, width 0.10 | **+6.8%** | **+6.4%** | -0.02 | Calm (0.37) |
| logistic 0.05 and share 0.4 | **+11.4%** | **+12.3%** | -0.04 | Stressed (0.71) |
| `regime.Crisis.pd_mult` 1.4 / 1.8 (base 1.6) | -0.4% / +0.2% n.s. | -0.3% / +0.2% n.s. | ∓0.16 | ZWE ∓6.6 pp, SEN ∓1.3 pp |
| `transition_matrix.use` false | -0.3% n.s. | -0.4% n.s. | +0.18 | ZWE +9.0 pp, SEN +1.8 pp |

The global switch is the largest single sensitivity in the model after the copula source. Today 8 of 18 countries
are not Calm (share 0.444); one more country trips the step and adds about 11 $mm VaR99 and 16 $mm ES99 with no
PD change (GOV-018, now on 0.1.5 data). The logistic option removes the cliff but costs +4.7% today because the
share is already close to the threshold. PD multipliers and the transition matrix move PDs and EL, not the tail.
EL falls when the state turns Stressed (EQ-B-0053).

## Use-restriction status
Drives restriction 6.6 (scenario A is mostly this switch). No restriction is specific to layer 3.

## Open findings
GOV-018 (option built in 0.1.5, not adopted), GOV-019; VF-008 (test gap).

## Independent validator should re-perform
1. Classify the 18 countries by hand at two past dates (for example 2018-08 Argentina/Turkey, 2022-03) with the
   rules and compare with what desk risk managers called them.
2. Re-run D07 at `global_stress_share` 0.40, 0.45, 0.50, 0.55 and plot VaR99 against the share (shape of the cliff).
3. Check that the PD multipliers are the matrix-weighted average stated in `regime-layer3.md` for one country.

## Part 3: status at 0.8.0 (EQ-B-0126, 2026-10-26)

Brings this dossier from 0.1.5 to releases 0.7.0 and 0.8.0. The 0.8.0 base is the 0.7.0 base (no model change in 0.8.0): shared data, as_of 2026-10-23, 100k VaR99 66.78, ES99 88.48, EL 4.10, L-VaR99 72.06 $mm. Sensitivity rows are from the regenerated [sensitivity-tables.md](sensitivity-tables.md) (20,000 paths, base VaR99 66.96 ±0.83, ES99 89.00 ±1.03, bit-identical to the release 20k base). The sections above describe 0.1.4/0.1.5 and are kept as written.

**Changes since 0.1.5.**
- One tier lookup for layer 3 and stress (`engine/tiers.py`, 0.2.0).
- Boundary, scenario-override and transition-weighted multiplier tests in `tests/test_layer3_regime.py` (VF-008
  resolved, 2026-10-25).
- No rule, threshold or matrix change. The logistic switch is still built and off (GOV-018).

**Sensitivity (current base).** The cliff is still the largest single lever on the tail.
- `global_stress_share` 0.4: VaR99 +12.4%, ES99 +13.5% (0.1.5: +15.4%, +17.0%). The share of non-Calm countries is
  0.444, so a 0.4 threshold flips the global state.
- Share 0.6: no change.
- Logistic switch, width 0.05 / 0.10: VaR99 +2.2% (n.s.) / +4.1%. With share 0.4: +9.2%.
- Crisis `pd_mult` 1.4 / 1.8 and switching the transition matrix off: n.s. on VaR99, Zimbabwe ±6.6 / +9.0 pp.

**Use restrictions.** Drives 6.6 (scenario A). No restriction is specific to layer 3.

**Open findings.** GOV-018, GOV-019.
