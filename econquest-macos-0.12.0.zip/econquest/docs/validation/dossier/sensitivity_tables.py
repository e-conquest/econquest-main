"""Recompute the one-at-a-time sensitivity tables of the validation dossier (EQ-B-0057, part 2).

Every row is a fresh `run_pipeline(u, s.copy_with(**patch), paths=20000, as_of=AS_OF)` on the current
`data/` folder and `data/assumptions.json` (the released settings: 0.1.5 when written, 0.8.0 at the EQ-B-0126 refresh), compared with a base run made the same way.
Nothing is read from the run archive. Same seed and Sobol sequence for every run (common random numbers).

    python docs/validation/dossier/sensitivity_tables.py                       # writes the .md and .csv next to it
    python docs/validation/dossier/sensitivity_tables.py --out /tmp/sens --only layer2,stress

Significance. A change is marked "n.s." (not significant) when |delta| < 2 x SE, with SE the larger of the base
and variant batch-means SE (`var99_se_mm` / `es99_se_mm`, VF-004). Because every run shares the seed, the true
error of a difference is smaller than that, so the rule is conservative: "n.s." means "cannot be told from
simulation noise at this path count", not "zero". EL has no SE key; its rows carry the change only.

Runtime: about 2 minutes for every table (each run about 1 s at 32,768 Sobol paths after the first).
"""
from __future__ import annotations

import argparse
import dataclasses
import hashlib
import sys
import time
import warnings
from pathlib import Path

import pandas as pd

ROOT = Path(__file__).resolve().parents[3]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from econquest import __version__  # noqa: E402
from econquest.config import Settings  # noqa: E402
from econquest.engine.pipeline import run_pipeline  # noqa: E402
from econquest.engine.stress import load_scenarios  # noqa: E402
from econquest.ingestion.loaders import load_universe  # noqa: E402

AS_OF = "2026-10-23"
PATHS = 20_000
RELEASE_BASE_20K = 66.95612571109443   # 0.7.0 / 0.8.0 release base VaR99 at 20k paths (release notes)
HERE = Path(__file__).resolve().parent

# (group, parameter shown, setting shown, patch dict). Base values are read from assumptions.json at run time.
VARIANTS: list[tuple[str, str, str, dict]] = [
    ("layer1", "layer1.hazard_weight", "0.25", {"layer1.hazard_weight": 0.25}),
    ("layer1", "layer1.hazard_weight", "0.75", {"layer1.hazard_weight": 0.75}),
    ("layer1", "layer1.mode", "fitted (pilot fit, gate not cleared)", {"layer1.mode": "fitted"}),
    ("layer2", "probability.risk_premium_ratio", "1.5", {"probability.risk_premium_ratio": 1.5}),
    ("layer2", "probability.risk_premium_ratio", "3.0", {"probability.risk_premium_ratio": 3.0}),
    ("layer2", "probability.w_m", "0.35", {"probability.w_m": 0.35}),
    ("layer2", "probability.w_m", "0.65", {"probability.w_m": 0.65}),
    ("layer2", "probability.w_s (scorecard weight)", "0.03", {"probability.w_s": 0.03}),
    ("layer2", "probability.w_s (scorecard weight)", "0.05", {"probability.w_s": 0.05}),
    ("layer2", "prediction_markets.use_market_prior", "false", {"prediction_markets.use_market_prior": False}),
    ("layer3", "monte_carlo.global_stress_share", "0.4", {"monte_carlo.global_stress_share": 0.4}),
    ("layer3", "monte_carlo.global_stress_share", "0.6", {"monte_carlo.global_stress_share": 0.6}),
    ("layer3", "regime.global_switch", "logistic, width 0.05", {"regime.global_switch": "logistic"}),
    ("layer3", "regime.global_switch", "logistic, width 0.10", {"regime.global_switch": "logistic", "regime.global_switch_width": 0.10}),
    ("layer3", "regime.global_switch + share", "logistic 0.05, share 0.4", {"regime.global_switch": "logistic", "monte_carlo.global_stress_share": 0.4}),
    ("layer3", "regime.Crisis.pd_mult", "1.4", {"regime.Crisis.pd_mult": 1.4}),
    ("layer3", "regime.Crisis.pd_mult", "1.8", {"regime.Crisis.pd_mult": 1.8}),
    ("layer3", "transition_matrix.use", "false", {"transition_matrix.use": False}),
    ("layer4", "layer4.lgd_sd", "0.10", {"layer4.lgd_sd": 0.10}),
    ("layer4", "layer4.lgd_sd", "0.20", {"layer4.lgd_sd": 0.20}),
    ("layer4", "market.lgd_hard", "50", {"market.lgd_hard": 50.0}),
    ("layer4", "market.lgd_hard", "70", {"market.lgd_hard": 70.0}),
    ("layer4", "market.lgd_local", "25", {"market.lgd_local": 25.0}),
    ("layer4", "market.lgd_local", "45", {"market.lgd_local": 45.0}),
    ("layer4", "layer4.merton.apply_uplift", "false", {"layer4.merton.apply_uplift": False}),
    ("layer5", "copula.source (loadings)", "judgement", {"copula.source": "judgement"}),
    ("layer5", "copula.nu_source", "estimated", {"copula.nu_source": "estimated"}),
    ("layer5", "monte_carlo.df_calm (nu)", "3", {"monte_carlo.df_calm": 3.0}),
    ("layer5", "monte_carlo.df_calm (nu)", "8", {"monte_carlo.df_calm": 8.0}),
    ("layer5", "monte_carlo.df_calm (nu)", "30", {"monte_carlo.df_calm": 30.0}),
    ("layer6", "monte_carlo.vol_source", "regime", {"monte_carlo.vol_source": "regime"}),
    ("layer6", "market.spread_vol_rel", "30", {"market.spread_vol_rel": 30.0}),
    ("layer6", "market.spread_vol_rel", "50", {"market.spread_vol_rel": 50.0}),
]
# Path count and seed are run settings, not parameters (policy section 4); shown for convergence.
PATH_ROWS = [10_000, 50_000, 100_000]
SEED_ROWS = [11, 13]
# Stress severity scale: each scenario at these scales, compared with the same scenario at scale 1.
STRESS_SCENARIOS = ["A", "FED22"]
STRESS_SCALES = [0.5, 1.5]
GROUPS = ("layer1", "layer2", "layer3", "layer4", "layer5", "layer6", "stress")


def _sig(delta: float, se: float) -> str:
    return "n.s." if abs(delta) < 2 * se else "sig."


def _top_pd(base_c: pd.DataFrame, var_c: pd.DataFrame, n: int = 3) -> str:
    d = (var_c["pd_default"] - base_c["pd_default"]).reindex(base_c.index) * 100
    d = d[d.abs() >= 0.005].reindex(d.abs().sort_values(ascending=False).index).dropna().head(n)
    if d.empty:
        return "none"
    return ", ".join(f"{base_c.at[c, 'iso']} {v:+.2f}" for c, v in d.items())


def _row(group, param, setting, base, res, note="", ref=None) -> dict:
    ref = ref or base
    bm, m = ref.metrics, res.metrics
    out = {"group": group, "parameter": param, "setting": setting, "paths": m["paths"],
           "global_regime": res.diagnostics["global_regime"], "global_weight": round(float(res.diagnostics["global_stress_weight"]), 3),
           "df": round(float(res.diagnostics["degrees_of_freedom"]), 2)}
    for key, short, sek in (("var99_mm", "var99", "var99_se_mm"), ("es99_mm", "es99", "es99_se_mm")):
        se = max(bm[sek], m[sek])
        out[short] = round(m[key], 2); out[short + "_se"] = round(m[sek], 2)
        out["d_" + short] = round(m[key] - bm[key], 2); out["d_" + short + "_pct"] = round(100 * (m[key] / bm[key] - 1), 1)
        out[short + "_sig"] = _sig(m[key] - bm[key], se)
    out["el"] = round(m["expected_loss_mm"], 3); out["d_el"] = round(m["expected_loss_mm"] - bm["expected_loss_mm"], 3)
    out["mean_pd_pp"] = round(100 * res.country["pd_default"].mean(), 2)
    out["d_mean_pd_pp"] = round(100 * (res.country["pd_default"].mean() - ref.country["pd_default"].mean()), 2)
    out["top_pd_moves_pp"] = _top_pd(ref.country, res.country)
    out["note"] = note
    return out


def _fmt_table(df: pd.DataFrame, ref_label: str) -> str:
    cols = ["Parameter", "Setting", "VaR99", "dVaR99 (%)", "ES99", "dES99 (%)", "EL", "dEL", "Global (w)", "Top PD moves (pp)"]
    lines = ["| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
    for _, r in df.iterrows():
        dv = f"{r['d_var99']:+.2f} ({r['d_var99_pct']:+.1f}%)" + (" n.s." if r["var99_sig"] == "n.s." else "")
        de = f"{r['d_es99']:+.2f} ({r['d_es99_pct']:+.1f}%)" + (" n.s." if r["es99_sig"] == "n.s." else "")
        lines.append(f"| {r['parameter']} | {r['setting']} | {r['var99']:.2f} ±{r['var99_se']:.2f} | {dv} | {r['es99']:.2f} ±{r['es99_se']:.2f} | {de} | "
                     f"{r['el']:.3f} | {r['d_el']:+.3f} | {r['global_regime']} ({r['global_weight']:g}) | {r['top_pd_moves_pp']} |")
    return "\n".join(lines) + f"\n\nDeltas against {ref_label}. ± is the run's batch-means SE.\n"


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(description=__doc__.splitlines()[0])
    ap.add_argument("--data", default=str(ROOT / "data"))
    ap.add_argument("--out", default=str(HERE))
    ap.add_argument("--only", default=",".join(GROUPS), help="comma list of groups: " + ",".join(GROUPS))
    a = ap.parse_args(argv)
    only = [g.strip() for g in a.only.split(",") if g.strip()]
    data = Path(a.data); out = Path(a.out); out.mkdir(parents=True, exist_ok=True)
    t0 = time.time()
    u = load_universe(data)
    s = Settings.load(data / "assumptions.json")
    base = run_pipeline(u, s, label="base", paths=PATHS, as_of=AS_OF)
    v = base.provenance.get("versions") or {}
    prices = data / "market_history" / "prices.csv"
    last_px = pd.read_csv(prices, usecols=["date"])["date"].max() if prices.exists() else "n/a"
    rows = [_row("base", "base (assumptions.json)", "as released", base, base)]
    for g, p, setting, patch in VARIANTS:
        if g not in only:
            continue
        try:
            with warnings.catch_warnings(record=True) as caught:
                warnings.simplefilter("always")
                r = run_pipeline(u, s.copy_with(**patch), label="sens", paths=PATHS, as_of=AS_OF)
            fell_back = [str(w.message) for w in caught if "ran paper_standardized instead" in str(w.message)]
            rows.append(_row(g, p, setting, base, r, note=("fallback: " + fell_back[0]) if fell_back else ""))
        except Exception as e:  # an option that cannot run on today's data is reported, not hidden
            rows.append({"group": g, "parameter": p, "setting": setting, "note": f"not run: {type(e).__name__}: {e}"})
    if "layer6" in only:
        for n in PATH_ROWS:
            rows.append(_row("layer6", "paths (run setting)", f"{n:,} requested", base, run_pipeline(u, s, label="sens", paths=n, as_of=AS_OF)))
        for sd in SEED_ROWS:
            rows.append(_row("layer6", "seed (run setting)", str(sd), base, run_pipeline(u, dataclasses.replace(s, seed=sd), label="sens", paths=PATHS, as_of=AS_OF)))
    stress_ref = {}
    if "stress" in only:
        scen = load_scenarios(data / "scenarios.json")
        for k in STRESS_SCENARIOS:
            if k not in scen:
                continue
            u1, s1 = scen[k].apply(u, s, scale=1.0)
            r1 = run_pipeline(u1, s1, label=f"stress-{k}", paths=PATHS, as_of=AS_OF)
            stress_ref[k] = r1
            rows.append({**_row("stress", f"scenario {k} scale", "1.0 (vs base)", base, r1), "note": "deltas vs base"})
            for sc in STRESS_SCALES:
                u2, s2 = scen[k].apply(u, s, scale=sc)
                r2 = run_pipeline(u2, s2, label=f"stress-{k}", paths=PATHS, as_of=AS_OF)
                rows.append({**_row("stress", f"scenario {k} scale", f"{sc} (vs scale 1)", base, r2, ref=r1), "note": f"deltas vs {k} at scale 1"})
    df = pd.DataFrame(rows)
    df.to_csv(out / "sensitivity-tables.csv", index=False)
    bm = base.metrics
    head = [
        f"# Sensitivity tables, econquest {__version__} on the current base (generated)",
        "",
        "Generated by `python docs/validation/dossier/sensitivity_tables.py` (EQ-B-0057; refreshed EQ-B-0126). Do not hand-edit: "
        "rerun the script.",
        "",
        f"- Model: econquest {__version__}, `data/assumptions.json` as found (code_hash {v.get('code_hash')}, data_hash {v.get('data_hash')}).",
        f"- as_of {AS_OF}; {PATHS:,} requested paths ({bm['paths']:,} Sobol), seed {s.seed}; prices through {last_px}.",
        f"- Base: VaR99 {bm['var99_mm']:.2f} ±{bm['var99_se_mm']:.2f}, ES99 {bm['es99_mm']:.2f} ±{bm['es99_se_mm']:.2f}, EL {bm['expected_loss_mm']:.3f} $mm; "
        f"global regime {base.diagnostics['global_regime']} (share not calm {base.diagnostics['share_not_calm']:.3f}), nu {base.diagnostics['degrees_of_freedom']:g}.",
        f"- Base check: VaR99 {bm['var99_mm']!r} at {PATHS:,} paths; the release base at 20k is {RELEASE_BASE_20K!r} "
        f"({'identical' if bm['var99_mm'] == RELEASE_BASE_20K else 'DIFFERENT: the data or code moved since the release'}).",
        "- One parameter at a time through `Settings.copy_with`; every other key at its released value. Same seed for all runs.",
        "- `n.s.`: |delta| < 2 x max(base SE, variant SE). Conservative under common random numbers (see the script docstring).",
        "- Top PD moves: the three largest changes in `pd_default` (percentage points, ISO3).",
        "",
    ]
    body = []
    titles = {"layer1": "Layer 1 hazard", "layer2": "Layer 2 Bayesian (and scorecard weight)", "layer3": "Layer 3 regimes",
              "layer4": "Layer 4 severity", "layer5": "Layer 5 copula", "layer6": "Layer 6 Monte Carlo",
              "stress": "Stress severity scale"}
    for g in GROUPS:
        if g not in only:
            continue
        sub = df[df["group"] == g]
        body.append(f"## {titles[g]}\n")
        ok = sub[sub["note"].fillna("").str.startswith("not run") == False]  # noqa: E712
        if g == "stress":
            for k in STRESS_SCENARIOS:
                kk = ok[ok["parameter"] == f"scenario {k} scale"]
                if len(kk):
                    body.append(_fmt_table(kk.iloc[:1], "the base run"))
                    body.append(_fmt_table(kk.iloc[1:], f"scenario {k} at scale 1"))
        else:
            body.append(_fmt_table(ok, "the base run"))
        for _, r in sub[sub["note"].fillna("").str.startswith("fallback")].iterrows():
            body.append(f"- {r['parameter']} = {r['setting']}: the option did not take effect ({r['note'][10:]}).\n")
        for _, r in sub[sub["note"].fillna("").str.startswith("not run")].iterrows():
            body.append(f"- {r['parameter']} = {r['setting']}: {r['note']}\n")
    md = "\n".join(head + body)
    (out / "sensitivity-tables.md").write_text(md)
    print(f"wrote {out / 'sensitivity-tables.md'} and .csv ({len(df)} rows, {time.time() - t0:.0f} s); "
          f"md sha256 {hashlib.sha256(md.encode()).hexdigest()[:16]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
