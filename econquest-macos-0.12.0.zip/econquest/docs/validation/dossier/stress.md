# Dossier: stress scenarios and reverse stress

Tier 2. Code: `econquest/engine/stress.py` (`load_scenarios`, `apply_shocks`, `Scenario.apply`, `compare`,
`reverse_stress`, `single_factor_reverse`); `data/scenarios.json`; scorecard `stress_inputs`. Source:
`stress-scenarios.md`. Evidence class: judgement shock sizes; historical scenarios are stylised reconstructions,
not calibrated replays; BIS contagion only on a synthetic fixture. State: release 0.1.5: tier filters (EQ-B-0043), rate shocks in FED22
(+200 bp) and TAPER13 (+100 bp) approved by Sam, contagion path confined to the scenarios folder (EQ-B-0047).

## Purpose and use
Re-runs the whole pipeline on a shocked universe and parameter set and compares VaR, ES, L-VaR, regimes, PDs
and LGDs with base. Reported in the release note, dashboard, briefs, and reverse stress against book limits.

## Conceptual soundness
Full revaluation through every layer is the right design. Scenario A (+61.2% ES99 in 0.1.4) is mostly a regime
and dependence shock through the global switch, far above the paper's +18.4% (GOV-026, restriction 6.6). B is
mainly an LGD statement (+18 pp, GOV-003 fixed). Responses are step-like at regime cliffs. Rate-level shocks exist
since 0.1.5, first order in duration only (no convexity, carry or PD move); contagion channel off until BIS data.

## Data
`data/scenarios.json` (governed; in `data_hash` since GOV-043). Shocks reference country table fields.

## Implementation
Data-driven grammar since 2026-10-23 (sizes no longer hard-coded; the `stress-scenarios.md` header was refreshed in
EQ-B-0054 and the GOV-026 text in EQ-B-0057). Stress runs use the base path count (GOV-004). Tests: `tests/test_scenarios.py`,
`test_contagion.py`, `test_scenario_brief.py`.

## Outcomes analysis
No scenario has been back-tested against a realised episode. Replication R09 to R24 reproduce all eight 0.1.4
stress ES99s and changes; D14 shows the policy text (+80%) is stale against +61.2%.

## Limitations
Judgement sizes; A dominated by the global cliff; rate shock first order only; contagion synthetic; historical scenarios are
reconstructions.

## Sensitivity (release 0.1.5, recomputed)
Recomputed for EQ-B-0057 on release 0.1.5 settings and the data in `data/` on 2026-10-24 (as_of 2026-10-23, 20,000 requested = 32,768 Sobol paths, seed 7). Base: VaR99 73.00 ±0.69, ES99 95.68 ±0.82, EL 0.471 $mm (± is the batch-means SE, `var99_se_mm` / `es99_se_mm`). n.s. = within 2 SE of base. Full table: [sensitivity-tables.md](sensitivity-tables.md#stress-severity-scale).

| Scenario at scale | VaR99 | ES99 | EL | Largest PD moves (pp) |
|---|---|---|---|---|
| A, 1.0 vs base | 123.30 (+68.9%) | 155.78 (+62.8%) | 1.50 | ZWE +20.6, PAK +11.1, ARG +8.8 |
| A, 0.5 vs A at 1.0 | -10.6% | -10.1% | -0.84 | ZWE -8.4, PAK -7.5, ARG -6.0 |
| A, 1.5 vs A at 1.0 | +10.8% | +9.5% | +1.30 | PAK +6.7, NGA +6.4, ZMB +4.9 |
| FED22, 1.0 vs base | 146.89 (+101.2%) | 176.58 (+84.6%) | 17.02 | ZWE +20.6, PAK +11.8, ARG +10.2 |
| FED22, 0.5 vs FED22 at 1.0 | -19.3% | -16.1% | -8.56 | ZWE -7.6, ARG -6.9, PAK -6.8 |
| FED22, 1.5 vs FED22 at 1.0 | +22.2% | +10.7% | +9.55 | PAK +13.1, NGA +8.1, ZMB +6.2 |

All significant. Scenario A at half severity still keeps 74% of its ES99 uplift (140.1 against base 95.7),
because the global state is Stressed at every scale: the A result is mostly the regime switch, not the shock size.
That confirms the reason given for restriction 6.6. FED22's EL of 17 $mm is the deterministic duration
mark-to-market of the +200 bp rate shock (EQ-B-0044), applied on every path. It is linear in scale.

## Use-restriction status
**6.6 conditional** (see [use-restrictions-review.md](use-restrictions-review.md)): sizes are now parameters in
`scenarios.json`; the library is not validated.

## Open findings
GOV-026, GOV-027; VF-002 (stale text), VF-003 (scenario file changed after release), VF-010 resolved in
EQ-B-0047 (0.1.5).

## Independent validator should re-perform
1. Run scenario A with only the data patches, then add the loading patch (decomposition in `stress-scenarios.md`)
   and confirm the global-regime share of the move.
2. Replay one historical scenario (TAPER13 or COVID20) against realised spread and FX moves for the 18 countries.
3. Run `econquest reverse-stress` at 131,072 paths and check the bisection result is stable to one seed sd.

## Part 3: status at 0.8.0 (EQ-B-0126, 2026-10-26)

Brings this dossier from 0.1.5 to releases 0.7.0 and 0.8.0. The 0.8.0 base is the 0.7.0 base (no model change in 0.8.0): shared data, as_of 2026-10-23, 100k VaR99 66.78, ES99 88.48, EL 4.10, L-VaR99 72.06 $mm. Sensitivity rows are from the regenerated [sensitivity-tables.md](sensitivity-tables.md) (20,000 paths, base VaR99 66.96 ±0.83, ES99 89.00 ±1.03, bit-identical to the release 20k base). The sections above describe 0.1.4/0.1.5 and are kept as written.

**Changes since 0.1.5.**
- Reverse stress scans a grid before bisecting (0.2.1, VF-018) and reports VaR99, ES99 and L-VaR99 breach points
  together (0.6.0).
- Four MACRO_ scenarios from the macro scenario engine (0.4.0, judgement exposures).
- The single-factor "downgrade" sign fixed (0.6.0).
- Restructuring scenarios (0.5.0).
- MVP: 16 of 17 scenarios run. EMDEF_BRA is labelled "not run: no BIS CBS exposures". 69 reverse-stress searches;
  ES99 breaches first, except MACRO_OIL.

**Sensitivity (current base).**
- Scenario A against base: VaR99 +68.9%, ES99 +65.4%. Severity scale 0.5 / 1.5 against scale 1: -14.8% / +10.9%.
- FED22: VaR99 +100.7%, ES99 +81.7%; scale 0.5 / 1.5: -21.8% / +21.8%.
- Both are concave above scale 1 in ES.

**Use restrictions.** 6.6 (scenario A is reported with its note against the paper's figure).

**Open findings.** GOV-026, GOV-027.
