# Dossier: GARCH/DCC promotion to Tier 1 (VF-001)

Date: 2026-10-24. Ticket EQ-B-0068. Written by Team B AGENT-05. Model state: release 0.2.1 settings
(`monte_carlo.vol_source` garch, `copula.source` estimated), as_of 2026-10-23, prices up to that date only.
Regenerated at 12:55Z on `prices.csv` after Team A's INDA repair (EQ-A-0056, VF-019; section 5.3).
Code: `econquest/engine/garch.py` (read only), `econquest/engine/layer6_montecarlo.py::garch_vol_table`.
Evidence script: [garch_backtests.py](garch_backtests.py), library `econquest/validation/garch_backtest.py`,
tests `tests/test_garch_backtests.py` (synthetic data). Outputs next to this file:
`garch-tier1-backtests.csv`, `garch-tier1-stability.csv`, `garch-tier1-dcc.csv`, `garch-tier1-copula.csv`,
`garch-tier1-sensitivity.csv`.

**This is not an independent validation.** The author is on the team that built the model (policy principle 4).

**Data source warning.** Every number in this dossier is computed on `data/market_history/prices.csv`, which is
GOOGLEFINANCE data exported through the Sheets API (EQ-A-0051). Google's terms rule out that use (section 4.1).
On 2026-10-24 Sam decided to rebuild the file from official BIS/ECB FX rates and drop the ETF columns
(EQ-A-0054). The results here are **interim evidence, GOOGLEFINANCE-sourced**. They must be rerun on the official
history before the Tier 1 sign-off (section 8).

**Update 2026-10-25 (EQ-B-0088).** The rerun on the official FX-only history Sam applied on 2026-10-25 is in
**section 11**. It supersedes sections 2 to 4 for the Tier 1 decision; those sections are kept as the PI-6 record.
Section 9 now carries the edits on the official evidence.

## 1. What is being promoted, and why

Policy section 2: a component moves up a tier when its output feeds a Tier 1 number. Since 0.1.4 two price-fitted
pieces feed the Monte Carlo (VaR, ES, L-VaR, EL; limit-tested):

| Piece | Code | Feeds | Tier today |
|---|---|---|---|
| GARCH(1,1)-t 12-month vols | `garch.mc_vols` via `garch_vol_table` | Market vol of 8 legs (FX, local-bond currency leg, EWY) | Row 10, Tier 2 (VF-001) |
| Estimated t-copula loadings | `layer5_copula.estimated_copula` | Calm global and regional loadings of 12 countries | Row 6, Tier 1 already |
| DCC(1,1) correlations | `garch.dcc_fit` | Forecast-record one-day VaR, GARCH tab | Tier 2; **no Tier 1 number uses it** |
| One-day GARCH VaR, vol scalar, options check | `garch.run_garch` | Forecast record, GARCH tab | Tier 2 |

So the part that must move is the 12-month marginal (`mc_vols`). The Monte Carlo's dependence comes from the
estimated copula on weekly returns, not from DCC. DCC stays a Tier 2 forecast-record tool. Its stability is still
reported in section 3, as the ticket asks.

GARCH legs on 2026-10-23 (12-month vol, percent): USDPHP 8.5, USDCNY 3.6, USDMYR 6.2, USDSGD 4.3, USDJPY 8.5,
EWY 42.1, USDBRL 13.1, USDCOP 12.6. Fallbacks to the regime value: USDINR (persistence 0.996), USDNGN
(administered), pegs, Zimbabwe (no series).

## 2. Out-of-sample VaR backtests (GOOGLEFINANCE-sourced, interim)

Method. One-day VaR99 and ES99 per series. Fit on the first 500 returns, then refit every 21 returns on all
earlier returns (expanding window). Between refits the variance recursion runs on with fixed parameters. No
forecast uses a return on or after its own day (test `test_backtest_has_no_look_ahead`). Test days: 2025-09-18
to 2026-10-23, 287 per series (286 for INDA and USDVES). Both tails are tested: "long" is the loss of a long
position, "short" of a short. Kupiec (unconditional coverage), Christoffersen (conditional coverage),
Acerbi-Szekely Z2 for ES (fails below -0.7), and the Basel zone scaled to n by the binomial probability.
Benchmark: EWMA(0.94), Gaussian, on the same days. The 21-day check is the z of each non-overlapping 21-day
block return against the GARCH cumulative 21-day variance; mean z² should be 1.

The bad-tick filter looks one day ahead and runs once on the whole sample, as in production. That is a one-day
look-ahead on the few cleaned days (`garch-dcc.md`, section Data).

### Monte Carlo legs (8 series, 287 days, 2.9 exceedances expected per tail)

| Series | Long: exc / Kupiec p / zone | Short: exc / Kupiec p / zone | Christoffersen cc p (min) | EWMA zones (L / S) | 21d mean z² |
|---|---|---|---|---|---|
| USDPHP | 3 / 0.94 / Green | 2 / 0.59 / Green | 0.85 | Green / Yellow | 0.43 |
| USDCNY | 4 / 0.53 / Green | 4 / 0.53 / Green | 0.77 | **Red** / Green | 0.52 |
| USDMYR | 3 / 0.94 / Green | 3 / 0.94 / Green | 0.97 | Yellow / Green | 0.97 |
| USDSGD | 2 / 0.59 / Green | 1 / 0.20 / Green | 0.44 | Yellow / Green | 0.74 |
| USDJPY | 6 / 0.11 / Yellow | 2 / 0.59 / Green | 0.07 | Yellow / Green | 1.28 |
| EWY | 5 / 0.25 / Green | **10 / 0.001 / Yellow** | **0.003** | Green / Yellow | 1.54 |
| USDBRL | 1 / 0.20 / Green | 5 / 0.25 / Green | 0.44 | Green / Yellow | 0.49 |
| USDCOP | 4 / 0.53 / Green | 6 / 0.11 / Yellow | 0.24 | Yellow / Yellow | 0.77 |

The book is long EWY (P07), so its loss tail is the "long" side: 5 exceedances, Green, Z2 -1.18 (ES fails the
-0.7 line). The short side (large up-moves) has 10 exceedances and fails Kupiec and Christoffersen.

### Pooled results

| Set | Tails | Test days | GARCH exc (rate) | Expected | Binomial p | Zones G / Y / R | Kupiec p < 0.05 | EWMA exc (rate) | EWMA zones G / Y / R |
|---|---|---|---|---|---|---|---|---|---|
| MC legs | 16 | 4,592 | 61 (1.33%) | 45.9 | 0.03 | 13 / 3 / 0 | 1 | 98 (2.13%) | 7 / 8 / 1 |
| FX, not administered | 24 | 6,888 | 86 (1.25%) | 68.9 | 0.045 | 19 / 5 / 0 | 2 | 143 (2.08%) | 10 / 13 / 1 |
| All except administered | 44 | 12,626 | 162 (1.28%) | 126.3 | 0.002 | 35 / 9 / 0 | 8 | 250 (1.98%) | 18 / 25 / 1 |
| All 27 series | 54 | 15,494 | 211 (1.36%) | 154.9 | | 40 / 13 / 1 | 12 | 311 (2.01%) | 23 / 28 / 3 |

Pooled p-values treat the series as independent, which they are not; read them as indicative.

Reading. GARCH-t is clearly better than EWMA on every set (about 1.3% against 2.0% exceedances). It still runs
slightly hot: about 1.3% exceedances against 1% at the 99% level, so one-day VaR99 is roughly a 98.7% quantile.
Of the 6 equity Kupiec rejections, 3 are zero exceedances (MCHI short, EWS short, ARGT long, too
conservative) and 3 are too many (EPHE short, EWJ long, EWY short). The 21-day cumulative variance is too high
for most series (median mean z² 0.75 on the MC legs: the forecast vol is about 13% above realised). EWY (1.54)
and USDJPY (1.28) go the other way. With 13 blocks per series this is weak evidence. **Nothing here tests the
12-month horizon the Monte Carlo uses.** Three years of data hold no non-overlapping 12-month windows to test.

The one Red tail is USDVES short (administered, already excluded from the MC). Before Team A's repair, INDA was Red
on both tails because of the bad rows (section 5.3); on the repaired column it is Green on both (3 and 4 exceedances).

## 3. Parameter stability (rolling 500-return windows)

Six windows of 500 returns, ending 2025-09-17, 2025-12-15, 2026-03-12, 2026-06-09, 2026-09-04 and 2026-10-23.
Each window is a full refit. The 12-month vol is the `mc_vols` number that window would give.

| MC leg | Persistence min to max | Windows at or above 0.995 | nu min to max | 12-month vol min to max (%) |
|---|---|---|---|---|
| USDPHP | 0.33 to 0.91 | 0 | 3.6 to 3.9 | 8.4 to 9.8 |
| USDCNY | 0.92 to 0.97 | 0 | **2.5 to 2.8** | 2.7 to 4.1 |
| USDMYR | 0.81 to 0.96 | 0 | 3.5 to 4.6 | 6.0 to 7.0 |
| USDSGD | 0.95 to 0.99 | 0 | 5.5 to 6.6 | 4.2 to 5.0 |
| USDJPY | 0.93 to **1.000** | **2** | 4.3 to 6.0 | 5.8 to 10.2 |
| EWY | **0.46 to 0.99** | 0 | 5.9 to 7.4 | **24.2 to 46.3** |
| USDBRL | 0.50 to 0.65 | 0 | 3.7 to 5.0 | 13.8 to 14.2 |
| USDCOP | 0.65 to 0.77 | 0 | 5.9 to 6.9 | 12.2 to 12.9 |

Off the MC: USDINR crosses 0.995 in 2 windows (it already falls back today); INDA (repaired) 0.14 to 0.98. USDJPY would have fallen back in 2
windows, so its leg switches between 8.5 (GARCH) and 12 (regime) with the window. EWY is the main instability:
its 12-month vol almost doubles across windows (the 2025 windows give 24 to 26, near the regime value 25). USDCNY's
nu is close to the 2.05 bound, so its variance is barely finite and VaR rests on a thin-tailed scale.

DCC (`garch-tier1-dcc.csv`):

| Block | a | b | a + b | Average correlation, next day / unconditional |
|---|---|---|---|---|
| FX (17 pairs) | 0.012 to 0.016 | **0.00 to 0.45** | 0.01 to 0.46 | 0.086 to 0.102 / 0.087 to 0.100 |
| Equity (10 ETFs) | 0.007 to 0.013 | 0.86 to 0.94 | 0.86 to 0.95 | 0.34 to 0.40 / 0.36 to 0.39 |

The FX DCC is not identified: `a` is about 0.01, `b` jumps between 0 and 0.45, and the conditional correlation
equals the unconditional one within 0.003. For FX, DCC adds nothing over a constant correlation. The equity block is
stable and slow, as `garch-dcc.md` reported. Neither block feeds the Monte Carlo.

## 4. Sensitivity of book VaR99 / ES99 to the GARCH choices

`run_pipeline(u, s, paths=20000, as_of="2026-10-23")` (32,768 Sobol paths, seed 7), one change at a time. Every
run uses the same random numbers. Base: VaR99 69.03, ES99 91.21, EL 0.805, L-VaR99 74.32 $mm. The base moved from
67.28 / 89.61 when Team A repaired INDA (section 5.3); nothing in this ticket moves it.

Noise in a change. Because the runs share random numbers, the noise in a change is not either run's own SE
(0.70 to 0.78 $mm on VaR99). It is measured here as a **paired SE**: cut both loss vectors into the 32 batches
`mc_error` uses, take the change in VaR99 (ES99) batch by batch, and divide the sd of those 32 changes by sqrt(32)
(`paired_se` in the script; columns `d_var99_paired_se_mm`, `d_es99_paired_se_mm`). Bold = the change is more
than 2 paired SE. The batches share one Sobol scramble, so the paired SE is a guide, not an exact error. A change
can be clearly non-zero and still small: read the size, not only the bold.

The window, distribution and floor/cap rows swap `garch.mc_vols` for `garch_backtest.mc_vols_variant` inside the
run only. The "variant code" row checks that the swap with default options gives the base exactly.

| Choice | Variant | VaR99 (paired SE) | ES99 (paired SE) | EL $mm | Legs that move (12-month vol %) |
|---|---|---|---|---|---|
| check | variant code, default options | 69.03 (0.0%) | 91.21 (0.0%) | 0.805 | none |
| source | `vol_source` regime | 69.64 (+0.9%, 0.33) | **93.17 (+2.1%, 0.16)** | 0.872 | all 8 back to regime |
| window | last 500 returns (~2 y) | **70.01 (+1.4%, 0.10)** | **92.15 (+1.0%, 0.05)** | 0.768 | EWY 46.3, USDPHP 9.7, USDINR in at 5.9 |
| window | last 250 returns (~1 y) | 69.33 (+0.4%, 0.18) | **90.86 (-0.4%, 0.08)** | 0.670 | EWY 56.3, USDCNY 2.1, USDINR in at 6.7 |
| distribution | Gaussian innovations | **68.54 (-0.7%, 0.03)** | **90.65 (-0.6%, 0.01)** | 0.805 | USDJPY 9.3, small elsewhere |
| floor/cap | floor at regime vol | **73.92 (+7.1%, 0.17)** | **96.82 (+6.2%, 0.11)** | 0.796 | FX legs up to 12 / 7 |
| floor/cap | floor at 0.75 x regime | **71.05 (+2.9%, 0.08)** | **93.64 (+2.7%, 0.05)** | 0.802 | FX legs up to 9.0 / 5.2 |
| floor/cap | cap at regime vol | **65.63 (-4.9%, 0.28)** | **87.58 (-4.0%, 0.10)** | 0.880 | EWY 25, USDBRL and USDCOP 12 |
| floor/cap | `market.vol_cap` 40 (base 60) | **68.81 (-0.3%, 0.04)** | **90.97 (-0.3%, 0.01)** | 0.817 | none (caps the non-GARCH legs) |
| fallback | `persistence_max` 0.999 | **68.94 (-0.1%, 0.03)** | **91.13 (-0.1%, 0.01)** | 0.807 | USDINR in at 5.7 |
| fallback | `persistence_max` 0.99 | **66.28 (-4.0%, 0.28)** | **88.25 (-3.2%, 0.09)** | 0.871 | EWY out (0.990), back to 25 |
| fallback | `administered` empty | 69.03 (0.0%) | 91.21 (0.0%) | 0.805 | none: USDNGN then fails persistence |
| copula | `copula.source` judgement | **58.73 (-14.9%, 0.70)** | **76.65 (-16.0%, 0.55)** | 0.803 | none |
| data | FX only (ETF columns removed) | **62.92 (-8.9%, 0.47)** | **83.49 (-8.5%, 0.43)** | 0.872 | EWY back to 25; copula refit on FX |

Reading. With common random numbers almost every change is measurable, so the useful question is size. The GARCH
estimation choices are small: Gaussian innovations, the 0.999 gate and either shorter window move VaR99 and ES99 by
1.4% or less. The book result rests on three things: **EWY's 12-month vol** (the persistence gate at 0.99 or a cap at
25 removes 4 to 5% of VaR99), **whether low GARCH FX vols may undercut the regime values** (a floor adds 3 to 7%),
and the **estimated copula** (15 to 16%, the largest single input). GARCH against regime vols nets out small
(ES99 +2.1% under regime, VaR99 within noise) only because EWY going up and the FX legs going down offset each other.

## 5. Data source (high severity)

### 5.1 GOOGLEFINANCE licence (EQ-A-0051, decided EQ-A-0054)

`prices.csv` is GOOGLEFINANCE data pulled through the Sheets API. Google's terms rule out trading, advice and
professional financial use, and rule out that export route. A Tier 1 model cannot rest on data it may not use.
**Tier 1 promotion assumes a licensed or official price source.** Sam decided on 2026-10-24 (12:31Z, relayed by
AGENT-08) to rebuild the file from BIS/ECB daily official FX rates and drop the ETF columns (Team A, EQ-A-0054).
The live file stays as it is until the pull on Sam's Mac. Until then every number in sections 2 to 4 is labelled
"GOOGLEFINANCE-sourced, interim".

What changes on official rates. Reference fixings, not closes: ECB rates are set once a day at 14:15 CET. Fixings
give lower one-day vols and different bad-tick behaviour, and the tests above must be rerun. Team A must confirm
coverage for all 17 pairs: the ECB list does not carry every currency in the book (for example COP and VND), and
BIS coverage and lag must be checked per pair. Administered pairs stay administered whatever the source.

### 5.2 What the target state (FX only) loses

From `garch-tier1-copula.csv` and the "FX only" row above. These are still GOOGLEFINANCE FX quotes, so they show
the direction, not the final numbers.

- **GARCH series lost:** VNM, EPHE, MCHI, EWM, EWS, EWJ, EWY, INDA, EWZ, ARGT (10 country ETFs; GXG and EEM are in the
  file but unused by the model). The equity DCC block goes, so does the equity half of the forecast-record VaR and the
  Black-Scholes check.
- **Monte Carlo legs:** only EWY (P07, 15 $mm long) is a GARCH equity leg. It returns to `market.equity_vol` 25
  (judgement) from 42.1. P22 Zimbabwe equity is already on judgement. The 7 FX GARCH legs stay.
- **Estimated copula:** country shocks become FX-only. Argentina leaves the estimated set (USDARS is administered,
  ARGT was its only series) and returns to judgement loadings. The other loadings fall where the ETF carried the
  co-movement:

| Squared Calm global loading | Today (INDA repaired) | FX only |
|---|---|---|
| Singapore | 0.752 | 0.874 |
| Brazil | 0.411 | 0.287 |
| Japan | 0.473 | 0.353 |
| South Korea | 0.452 | 0.492 |
| Malaysia | 0.447 | 0.338 |
| Philippines | 0.287 | 0.154 |
| China | 0.268 | 0.232 |
| India | 0.192 | 0.085 |
| Colombia | 0.183 | 0.088 |
| Argentina | 0.117 | judgement |
| Vietnam | 0.082 | 0.078 |
| Zambia | 0.000 | 0.000 |
| Regional Asia / LatAm | 0.121 / 0.161 | 0.076 / 0.336 |
| Estimated nu (not used; judgement 5 / 4) | 30 | 20 |

  Net book effect on today's quotes: VaR99 -8.9%, ES99 -8.5% (EWY vol and loadings together). The equity
  factors for the 10 ETF countries go back to judgement, as Sam decided.

### 5.3 INDA column defect (VF-019, repaired by Team A under EQ-A-0056)

Found while writing this dossier. `prices.csv` INDA had 51 rows (2026-03-03 to 2026-10-22) at 661 to 681, about 13
times the ETF price, interleaved with good rows. `clean_bad_ticks` could not remove them because they are not
one-day reversals. `garch.load_prices` (GARCH tab, forecast record) overlays `inda.csv`, but `load_universe`
(pipeline: `mc_vols`, estimated copula) read `prices.csv` only. The copula therefore saw India's shock dominated by
these jumps, and because the fit is joint every loading moved (India 0.077 before, 0.192 after). Team A repaired the
column from `inda.csv` at 12:43Z (audit `data/market_history/repairs/inda_repair_EQ-A-0056.csv`). The 20,000-path base went
from VaR99 67.28 / ES99 89.61 / EL 0.809 / L-VaR99 72.56 to 69.03 / 91.21 / 0.805 / 74.32. **The 0.2.1 release
numbers were computed on the bad column and need restating** (AGENT-08, EQ-B-0076). This dossier now uses the
repaired file throughout.

## 6. Limitations

1. **Data licence** (5.1, high). Interim evidence only, until the official FX history is in and the tests are rerun.
2. **No test at the 12-month horizon.** The one-day and 21-day tests check the variance dynamics, not the 12-month
   number the Monte Carlo uses. That number is mostly the long-run variance (half-lives 1 to 70 days), i.e. a
   three-year average vol with a little conditioning on today.
3. **Three years of data, one calm cycle.** No standard errors on alpha, beta, nu (GOV-034 item 1). Persistence and
   EWY's 12-month vol are unstable across windows (section 3).
4. **One-day VaR99 runs slightly hot** (1.25 to 1.33% exceedances pooled), and EWY's ES fails Z2.
5. **Gate switching.** The 0.995 persistence gate makes legs jump between GARCH and regime vols (USDJPY, USDINR,
   EWY at a 0.99 gate). This is a step-like response to a small parameter change.
6. **Low FX vols are used as they come.** Managed and quasi-pegged pairs (USDCNY 3.6, USDSGD 4.3) get very low
   vols. A floor at the regime value would add 7% to VaR99. Low measured vol in a managed currency is not low risk
   (`garch-dcc.md`).
7. **USDCNY nu near the bound** (2.5 to 2.8): finite variance but a fragile tail scale.
8. **DCC FX is not identified** (b 0 to 0.45). DCC does not feed the Monte Carlo.
9. **Bad-tick cleaning** uses a one-day reversal rule and misses multi-day level errors (INDA, 5.3, now repaired
   in the data but not caught by the code).
10. The estimation choices that matter are code constants in `garch.py` (full sample, Student-t, 250-return
    minimum, the administered list default). Only `monte_carlo.garch_vol.*` overrides go through `econquest change`.

## 7. Use restrictions proposed

| # | Restriction | Lifted when |
|---|---|---|
| G1 | GARCH 12-month vols feed the Monte Carlo only for floating and managed FX pairs whose quote is not administered, with the existing fallbacks (pegs, administered list, persistence 0.995, 250 returns) | Never lifted; a change is a Tier 1 change |
| G2 | Until EQ-A-0054 is in, every VaR/ES/L-VaR run with `vol_source` garch or `copula.source` estimated is labelled "market inputs GOOGLEFINANCE-sourced, interim" and is not used outside the desk (adds to 6.1) | Official FX history in, backtests rerun (section 8). **Met 2026-10-25 (section 11); G2 lapses** |
| G3 | No GARCH vol for equity legs after EQ-A-0054; EWY and the equity factors use judgement | A licensed equity price source and a new dossier section |
| G4 | DCC correlations are not used in any Tier 1 number; the forecast-record VaR keeps restriction 6.9 | A design decision to use DCC in the Monte Carlo, with its own validation |
| G5 | Changes to `garch.py` that touch `mc_vols`, `garch11_fit`, `_returns`, `clean_bad_ticks` or `_mc_returns` are Tier 1 code changes: owner + approver, with the section 4 table rerun | n/a |

## 8. Recommendation

1. **Classify the GARCH 12-month marginal (`garch.mc_vols` for FX) as Tier 1, on official data.** (2026-10-25:
   conditions (a) to (c) are met, section 11.6; (d) stays open.) Conditions:
   (a) EQ-A-0054 lands the BIS/ECB FX history; (b) `python docs/validation/dossier/garch_backtests.py` is rerun on it,
   and the 8 MC legs show no Red zone and no pooled exceedance rate above 1.5% at the one-day 99% level; (c) section 4
   is rerun and Sam reviews the base move from the FX-only change; (d) independent validation before any external
   use (policy section 2, Tier 1).
2. **Keep DCC, the one-day GARCH VaR, the vol scalar and the options check at Tier 2.** Split inventory row 10 so
   the tier follows the use. DCC adds nothing for FX (section 3) and feeds no Tier 1 number.
3. **Interim, until the conditions hold:** the GARCH marginals already set Tier 1 numbers, so policy section 2
   treats them as Tier 1 now. Record row 10a as "Tier 1, pending official data" with restriction G2. The interim
   backtests support the model (Green or Yellow on all 16 MC-leg tails, clearly better than EWMA).
4. **Decisions for Sam beyond the tier:** a floor on GARCH FX vols (limitation 6: 0.75 x regime adds 2.9% VaR99;
   1.0 x adds 7.1%); EWY becomes moot after EQ-A-0054; GOV-034 item 1 (standard errors) stays open.
5. **Restate the 0.2.1 base after the INDA repair** (5.3), and add a multi-day level check to the price loader
   (Team A) so a mixed listing is caught next time.

## 9. Change request for Sam

Tier is not a setting. `econquest change propose` covers the governed files (`assumptions.json`, `limits.json`,
`compliance.json`) only, and no key holds a model tier. `ops/approvals.py` maps assumptions sections to approval tiers:
`garch` is Tier 2 there, which is right because the `garch` keys (`target_vol`, `scalar_cap`, `risk_free`,
`confidence`) only drive the Tier 2 uses. The Monte Carlo overrides sit under `monte_carlo.garch_vol` and are
already Tier 1. So no `econquest change` proposal is made. The change is a document edit, and **no model number
changes**: the model already runs `monte_carlo.vol_source` "garch" (section 11.6). **Approved by Sam on a decision card, 2026-10-25 02:06Z ("Approve Tier 1")**; AGENT-08 applied edits 1 to 4 and G6
the same day. The floor question stays open.

Revised 2026-10-25 (EQ-B-0088) on the official FX-only evidence of section 11. The PI-6 version proposed
"Tier 1 (pending official data)" and an interim GOOGLEFINANCE label (G2); both are dropped: the official history is
in and the backtests pass.

### Proposed edit 1: `docs/governance/model-inventory.md`, summary table row 10

Replace row 10 with two rows:

```
| 10a | GARCH(1,1)-t 12-month FX marginals for the Monte Carlo | `econquest/engine/garch.py` (`mc_vols`, `garch11_fit`, `_returns`, `clean_bad_ticks`), `layer6_montecarlo.garch_vol_table` | 1 | Fitted (maximum likelihood on daily official FX rates, BIS WS_XRU / ECB EXR, release 0.5.0; 6 legs on 2026-10-23: USDPHP, USDCNY, USDMYR, USDSGD, USDBRL, USDCOP); fallbacks: pegs, administered list, persistence >= 0.995 (USDJPY, USDINR today), < 250 returns; equity legs on judgement `market.equity_vol` | `garch-dcc.md`, `dossier/garch-dcc-tier1.md` (section 11) | Every release (`garch_backtests.py --only sensitivity`); quarterly backtests and stability |
| 10b | GARCH one-day VaR/ES, DCC(1,1), vol-target scalar, options check | `econquest/engine/garch.py` (`run_garch`, `dcc_fit`) | 2 | Fitted on the same prices; FX DCC adds nothing over constant correlation (within 0.01) | `garch-dcc.md`, `dossier/garch-dcc-tier1.md` | Daily refit inside `record`; quarterly |
```

### Proposed edit 2: `model-inventory.md`, section "10. GARCH and DCC"

Replace the last limitation bullet ("... not connected to the Monte Carlo volatilities.") with:

```
- Since 0.1.4 the 12-month marginals (10a) set the FX vols of the Monte Carlo and are Tier 1 (VF-001, EQ-B-0068,
  EQ-B-0088, approved by Sam on <date>). Evidence on the official FX-only history (release 0.5.0, as_of 2026-10-23):
  one-day VaR99 out of sample, 12 tails of the 6 FX MC legs Green 11 / Yellow 1 / Red 0, pooled exceedances 1.02%
  (EWMA 1.80%); 12-month vols stable within 1.2 points across 500-return windows. Every GARCH leg is below its regime
  vol: GARCH lowers VaR99 by 13.9% against regime vols (floor question open). USDJPY and USDINR fall back on the
  persistence gate. Equity legs on judgement since EQ-A-0054. Conditions: independent validation before external
  use; use restrictions G1, G3 to G6 in `dossier/garch-dcc-tier1.md`.
```

### Proposed edit 3: `docs/governance/model-risk-policy.md`, section 2 table

Tier 1 "Components today": add "GARCH 12-month FX marginals (inventory 10a)". Tier 2: change "GARCH/DCC" to "GARCH
one-day VaR and DCC (inventory 10b)". No new section 6 restriction: the PI-6 interim label (G2) is no longer needed.

### Proposed edit 4: `findings-register.csv` and `issues-log.md`

VF-001: "Proposed for closure on Sam's approval of edits 1 to 3 (EQ-B-0068, EQ-B-0088)". GOV-034: add "USDBZD is
quoted flat at 2.00 on official rates (no returns); USDARS is the only Red tail on official data (already
administered); USDZMW and USDVND are not administered but fail the 21-day check (section 11.3), restriction G6".

### Restriction G6 (new, with this change)

| # | Restriction | Lifted when |
|---|---|---|
| G6 | A GARCH 12-month vol for USDZMW or USDVND (21-day mean z² 4.78 and 1.83, section 11.3) is not used in the Monte Carlo without a floor at the regime value. Neither is a leg today | A refit on a longer official history passes the 21-day check |

### Card text for Sam (draft)

> **FX GARCH marginals to Tier 1 (VF-001, EQ-B-0068 / EQ-B-0088).** The Monte Carlo already uses GARCH 12-month
> vols for 6 FX legs (PHP, CNY, MYR, SGD, BRL, COP). On the official FX-only history you applied today, their one-day
> VaR99 backtests show no Red (11 Green, 1 Yellow of 12 tails) and 1.02% pooled exceedances, against 1.80% for EWMA.
> This approves a classification only: inventory row 10 splits into 10a (Tier 1) and 10b (Tier 2, DCC and the
> one-day VaR). **No number changes** (base VaR99 58.19 / ES99 78.72 stays). Independent validation is still needed
> before external use. Separate, open question: every GARCH FX vol is below its regime value, so GARCH lowers VaR99
> by 13.9%; a floor at 0.75 x regime would add 7.2%.
>
> Options: (1) Approve edits 1 to 4 and G6 (recommended). (2) Approve and also ask for a floor change proposal.
> (3) Keep Tier 2 wording until independent validation.

## 10. How to reproduce

```
python docs/validation/dossier/garch_backtests.py                        # about 6 minutes, writes the CSVs here
python docs/validation/dossier/garch_backtests.py --only sensitivity     # about 1 minute
python -m pytest -q tests/test_garch_backtests.py                        # synthetic data
```

20,000-path base before and after this work (no engine or settings change from this ticket): VaR99 67.2808,
ES99 89.6091, EL 0.80882, L-VaR99 72.5623, identical to every digit on the pre-repair data. After Team A's INDA
repair (EQ-A-0056) the base is VaR99 69.034, ES99 91.207, EL 0.805, L-VaR99 74.315; that move is the data repair,
not this ticket.

## 11. Rerun on official FX-only history (2026-10-25)

Ticket EQ-B-0088, Team B AGENT-05. Prices: the official FX-only `data/market_history/prices.csv` that Sam applied on
2026-10-25 (sha256 `4eaa006b...`, the same file as the frozen `docs/governance/releases/inputs/0.5.0/prices.csv`).
Sources per column (`prices.provenance.json`): BIS WS_XRU, ECB EXR, XOF as the EUR peg times the ECB EUR rate, and
theratesapi.com (a mirror of Banca d'Italia rates) for **VND, PKR, BZD, VES, NGN and ZMW**. Those six columns are
internal research use only (EXC-005). No ETF columns. Same method, test days and code as sections 2 and 3
(`econquest/validation/garch_dossier.py`, parts backtest and stability), as_of 2026-10-23. Outputs next to this file:
`garch-tier1-fxonly-backtests.csv`, `garch-tier1-fxonly-stability.csv`, `garch-tier1-fxonly-dcc.csv`,
`garch-tier1-fxonly-sensitivity.csv`. The PI-6 CSVs (`garch-tier1-*.csv`, GOOGLEFINANCE-era) are kept for comparison.

Administered quotes (GOV-034, `garch.ADMINISTERED`): USDVES, USDNGN, USDARS, USDPKR, USDBZD. They never feed the
Monte Carlo. USDBZD is quoted flat at 2.00 on every official date, so it has no returns: it drops out of both parts
(sections 2 and 3 had 27 series, this rerun has 16 FX series). `part_stability` failed on it; EQ-B-0088 added a skip
for series shorter than one window (test `test_part_stability_skips_flat_peg`, synthetic).

This is still not an independent validation (policy principle 4).

### 11.1 Monte Carlo legs on the official history

Six FX legs take a GARCH 12-month vol on 2026-10-23. **USDJPY no longer does**: on official fixings its persistence is
0.9995, above the 0.995 gate, so it falls back to the regime value (Float, 12%). USDINR still falls back (0.9976).
EWY is gone with the ETF columns (judgement `market.equity_vol` 25). USDNGN stays administered.

| Leg | PI-6 12-month vol % (GOOGLEFINANCE) | Official 12-month vol % | Persistence | nu | Regime vol % |
|---|---|---|---|---|---|
| USDPHP | 8.5 | 5.4 | 0.949 | 6.7 | 12 (Float) |
| USDCNY | 3.6 | 2.6 | 0.968 | 3.1 | 7 (Managed) |
| USDMYR | 6.2 | 5.6 | 0.962 | 3.8 | 12 (Float) |
| USDSGD | 4.3 | 3.8 | 0.991 | 4.6 | 7 (Managed) |
| USDBRL | 13.1 | 11.7 | 0.581 | 5.3 | 12 (Float) |
| USDCOP | 12.6 | 11.4 | 0.914 | 6.8 | 12 (Float) |
| USDJPY | 8.5 | fallback 12 (persistence 0.9995) | | | 12 (Float) |
| EWY | 42.1 | judgement 25 (no ETF prices) | | | 25 |

Every GARCH FX leg is now below its regime value. Official fixings are smoother than GOOGLEFINANCE closes.

One-day VaR99, out of sample, 287 test days per series (2025-09-18 to 2026-10-23), 2.9 exceedances expected per
tail. Cells: exceedances / Kupiec p / zone.

| Leg | PI-6 long | PI-6 short | Official long | Official short | Christoffersen cc p (min) | Z2 (min) | EWMA zones (L / S) | 21d mean z² (PI-6 / official) |
|---|---|---|---|---|---|---|---|---|
| USDPHP | 3 / 0.94 / Green | 2 / 0.59 / Green | 4 / 0.53 / Green | 3 / 0.94 / Green | 0.77 | -0.42 | Yellow / Green | 0.43 / 0.95 |
| USDCNY | 4 / 0.53 / Green | 4 / 0.53 / Green | 6 / 0.11 / Yellow | 2 / 0.59 / Green | 0.24 | -0.65 | Yellow / Green | 0.52 / 0.93 |
| USDMYR | 3 / 0.94 / Green | 3 / 0.94 / Green | 3 / 0.94 / Green | 3 / 0.94 / Green | 0.97 | 0.04 | Yellow / Green | 0.97 / 1.18 |
| USDSGD | 2 / 0.59 / Green | 1 / 0.20 / Green | 2 / 0.59 / Green | 0 / 0.02 / Green | 0.06 | 0.36 | Yellow / Green | 0.74 / 0.69 |
| USDBRL | 1 / 0.20 / Green | 5 / 0.25 / Green | 1 / 0.20 / Green | 3 / 0.94 / Green | 0.44 | 0.06 | Green / Green | 0.49 / 0.51 |
| USDCOP | 4 / 0.53 / Green | 6 / 0.11 / Yellow | 4 / 0.53 / Green | 4 / 0.53 / Green | 0.77 | -0.58 | Green / Yellow | 0.77 / 0.98 |

No Red. One Yellow (USDCNY long, 6 exceedances, Kupiec p 0.11, not rejected). One Kupiec rejection: USDSGD short
with 0 exceedances (too conservative, p 0.016). No ES Z2 below -0.7 on any MC leg. The 21-day cumulative variance is
closer to calibrated than on PI-6 data (median mean z² 0.94 against 0.75).

### 11.2 Pooled results

| Set | Prices | Tails | Test days | GARCH exc (rate) | Expected | Binomial p | Zones G / Y / R | Kupiec p < 0.05 | EWMA exc (rate) | EWMA zones G / Y / R |
|---|---|---|---|---|---|---|---|---|---|---|
| MC legs | PI-6 (8 legs incl. EWY) | 16 | 4,592 | 61 (1.33%) | 45.9 | 0.03 | 13 / 3 / 0 | 1 | 98 (2.13%) | 7 / 8 / 1 |
| FX MC legs | PI-6 (7 legs incl. JPY) | 14 | 4,018 | 46 (1.14%) | 40.2 | 0.34 | 12 / 2 / 0 | 0 | 87 (2.17%) | 6 / 7 / 1 |
| FX MC legs | **official (6 legs)** | 12 | 3,444 | **35 (1.02%)** | 34.4 | 0.86 | **11 / 1 / 0** | 1 | 62 (1.80%) | 7 / 5 / 0 |
| FX, not administered | PI-6 | 24 | 6,888 | 86 (1.25%) | 68.9 | 0.045 | 19 / 5 / 0 | 2 | 143 (2.08%) | 10 / 13 / 1 |
| FX, not administered | official | 24 | 6,888 | 71 (1.03%) | 68.9 | 0.76 | 21 / 3 / 0 | 3 | 127 (1.84%) | 14 / 9 / 1 |
| All FX series | official (16; BZD has no returns) | 32 | 9,184 | 114 (1.24%) | 91.8 | 0.02 | 25 / 6 / 1 | 7 | 168 (1.83%) | 18 / 13 / 1 |

Pooled p-values treat the series as independent; read them as indicative.

Reading. On official rates the one-day VaR99 of the FX legs is on target: 1.02% exceedances against 1% expected,
where PI-6 ran hot at 1.14 to 1.33%. GARCH-t still beats EWMA on every set (1.0% against 1.8%). The only Red tail is
USDARS long (15 exceedances, Z2 -5.05): administered, already excluded. The 12-month horizon is still untested
(limitation 2).

### 11.3 Currencies off the Monte Carlo: VND, XOF, ZMW, and the others

None of these feeds a Tier 1 number today: the Vietnam, Senegal and Zambia positions take no FX GARCH vol. The
EXC-005 rows are internal research only; do not copy them into client output.

| Series | Source | 12-month vol % | Persistence | Long | Short | 21d mean z² | Rolling 12-month vol % |
|---|---|---|---|---|---|---|---|
| USDVND (Managed band) | theratesapi, EXC-005 | 1.8 | 0.961 | 3 / 0.94 / Green | 2 / 0.59 / Green (cc p 0.018) | **1.83** | 1.7 to 2.2 |
| USDXOF (EUR peg) | ECB EUR x peg | 6.3 | 0.986 | 1 / 0.20 / Green | 1 / 0.20 / Green | 1.10 | 6.4 to 7.2 |
| USDZMW (Float) | theratesapi, EXC-005 | 12.6 | 0.821 | **9 / 0.004 / Yellow** (Z2 -1.59) | 0 / 0.02 / Green | **4.78** | 10.5 to 13.7 |
| USDKRW (Float) | BIS | 8.8 | 0.625 | 6 / 0.11 / Yellow | 1 / 0.20 / Green | 1.31 | 8.3 to 9.2 |
| USDJPY (Float) | BIS | fallback | 0.9995 | 5 / 0.25 / Green | 1 / 0.20 / Green | 0.83 | 7.1 to 10.5; 3 of 6 windows >= 0.995 |
| USDINR (Managed) | BIS | fallback | 0.9976 | 4 / 0.53 / Green | 3 / 0.94 / Green | 1.00 | 3.1 to 6.9; 2 of 6 windows >= 0.995 |
| USDARS (administered) | BIS | admin | | **15 / 0.000 / Red** | 8 / 0.01 / Yellow | 1.75 | |
| USDVES (administered) | theratesapi, EXC-005 | admin | | 0 / 0.02 / Green | 8 / 0.01 / Yellow | **18.7** | |
| USDNGN (administered) | theratesapi, EXC-005 | admin | | 6 / 0.11 / Yellow | 2 / 0.59 / Green | 0.42 | |
| USDPKR (administered) | theratesapi, EXC-005 | admin | | 3 / 0.94 / Green | 1 / 0.20 / Green | 0.93 | |

- **USDVND.** The one-day test passes (Green both tails, EWMA is Red on the long tail). The 1.8% vol is the managed
  band: small daily moves. But the 21-day variance is too low (mean z² 1.83: 21-day moves are about 1.35 times the
  forecast), and the short-tail exceedances cluster (Christoffersen cc p 0.018). Low measured vol in a managed
  currency is not low risk (limitation 6). VND is not an administered quote in the GOV-034 sense (it trades within a
  band around a published central rate), so it should not join the list. If a Vietnam FX leg ever takes a GARCH vol,
  it should take the regime value (Managed 7%) as a floor.
- **USDXOF.** Behaves: it is EUR/USD through the peg, so 6.3% is the euro's vol. The MC treats Senegal as a Peg and
  never uses this number.
- **USDZMW.** Fails the 21-day check badly (mean z² 4.78) and has 9 long-tail exceedances (Kupiec p 0.004,
  Christoffersen cc p 0.011, Z2 -1.59): the kwacha moves in multi-day steps that a GARCH(1,1) does not anticipate.
  It is Yellow, not Red. It is a floating, market-determined rate, so it is not "administered" either. Recommendation:
  keep it off the administered list, but do not use its GARCH vol in the Monte Carlo without a floor at the regime
  value (Float 12%); this matches restriction G1 and adds G6 (section 9). Its source is the EXC-005 mirror, which adds data
  risk.
- **USDARS** is the only Red tail of the whole set, and it is already administered. Nothing new needs to join the
  administered list.
- **USDJPY** is a gate-switching case (limitation 5): 3 of 6 rolling windows at or above 0.995. On the base it uses the
  regime 12%.

### 11.4 Stability and DCC on the official history

| MC leg | Persistence min to max (PI-6 / official) | Windows >= 0.995 | nu min to max (official) | 12-month vol min to max % (PI-6 / official) |
|---|---|---|---|---|
| USDPHP | 0.33-0.91 / 0.78-0.96 | 0 | 6.5 to 7.9 | 8.4-9.8 / 5.4-5.9 |
| USDCNY | 0.92-0.97 / 0.90-0.98 | 0 | **2.9 to 3.5** | 2.7-4.1 / 2.1-3.0 |
| USDMYR | 0.81-0.96 / 0.88-0.95 | 0 | 3.6 to 4.1 | 6.0-7.0 / 5.3-6.5 |
| USDSGD | 0.95-0.99 / 0.68-0.99 | 0 | 4.5 to 5.2 | 4.2-5.0 / 3.6-4.6 |
| USDBRL | 0.50-0.65 / 0.40-0.60 | 0 | 4.3 to 6.2 | 13.8-14.2 / 11.8-12.6 |
| USDCOP | 0.65-0.77 / 0.84-0.92 | 0 | 6.0 to 11.3 | 12.2-12.9 / 10.8-11.3 |

The six legs are stable: no window crosses the gate, and the 12-month vol moves by at most 1.2 points across windows
(PI-6: EWY moved by 22 points). USDCNY's nu is less close to the 2.05 bound than on PI-6 data (2.9 to 3.5).

FX DCC (16 series, 6 windows): a 0.008 to 0.012, b 0.84 to 0.92, average next-day correlation 0.142 to 0.164 against
an unconditional 0.144 to 0.158. On official data `b` is identified (PI-6: 0 to 0.45), but the conditional
correlation still stays within 0.01 of the unconditional one. DCC still feeds no Tier 1 number; it stays Tier 2.

### 11.5 Book sensitivity on the official history (20,000 requested paths, as_of 2026-10-23)

Base: VaR99 58.30, ES99 79.27, EL 0.878, L-VaR99 63.58 $mm (the 0.5.0 base at 20,000 paths). Paired SE in brackets,
method as section 4. From `garch-tier1-fxonly-sensitivity.csv`.

| Choice | Variant | VaR99 | ES99 | Legs that move |
|---|---|---|---|---|
| check | variant code, default options | 58.30 (0.0%) | 79.27 (0.0%) | none |
| source | `vol_source` regime | **66.40 (+13.9%, 0.28)** | **88.65 (+11.8%, 0.16)** | all 6 up to regime |
| window | last 500 returns | 57.82 (-0.8%, 0.06) | 78.74 (-0.7%, 0.02) | small |
| window | last 250 returns | 60.43 (+3.7%, 0.18) | 81.48 (+2.8%, 0.10) | |
| distribution | Gaussian innovations | 59.00 (+1.2%, 0.08) | 80.04 (+1.0%, 0.04) | |
| floor/cap | floor at regime vol | 66.40 (+13.9%) | 88.65 (+11.8%) | same as regime: every leg is below it |
| floor/cap | floor at 0.75 x regime | **62.52 (+7.2%, 0.16)** | **84.14 (+6.1%, 0.09)** | PHP, CNY, MYR, SGD to 0.75 x regime |
| floor/cap | cap at regime vol | 58.30 (0.0%) | 79.27 (0.0%) | none |
| fallback | `persistence_max` 0.999 | 58.14 (-0.3%, 0.06) | 79.13 (-0.2%, 0.03) | USDINR in |
| fallback | `persistence_max` 0.99 | **61.23 (+5.0%, 0.11)** | **82.37 (+3.9%, 0.05)** | USDSGD out (0.991) |
| fallback | `administered` empty | 57.41 (-1.5%, 0.12) | 78.12 (-1.5%, 0.06) | USDNGN in at 27.7 (persistence 0.9950, just under the gate) |
| copula | `copula.source` judgement | **53.79 (-7.7%, 0.46)** | **71.05 (-10.4%, 0.52)** | none |

Reading. On official data GARCH lowers the book: VaR99 is 13.9% below the regime-vol run, because every GARCH FX leg
is below its regime value and EWY no longer offsets it. This makes the floor question (section 8, item 4) larger
than on PI-6 data: a floor at 0.75 x regime adds 7.2% to VaR99 (PI-6: 2.9%), a floor at regime adds 13.9% (PI-6:
7.1%). USDSGD sits just under the gate (0.991): a 0.99 gate would add 5.0%. The estimation choices (window,
distribution) stay small. The FX-only proxy of section 5.2 (VaR99 -8.9% from the 0.3.0 base) understated the real
move: the 0.5.0 base is 58.19 against 69.13 (-15.8%, 100,000 paths). The extra move comes with the lower official
FX vols and the copula refit on official rates; it is not decomposed here.

### 11.6 Conclusion

Condition 8.1(a) is met (official history applied, 0.5.0). Condition 8.1(b) is met: no Red zone on the 12 tails of
the 6 FX MC legs, pooled exceedance rate 1.02% (limit 1.5%), clearly better than EWMA (1.80%). Condition 8.1(c): the
base move was applied by Sam as release 0.5.0, and the sensitivity table is rerun above. Condition 8.1(d),
independent validation, stays open and gates external use. **The FX GARCH 12-month marginals can be classified Tier
1 without the "pending official data" qualifier.** DCC, the one-day GARCH VaR, the vol scalar and the options check
stay Tier 2.

**No model number changes.** The model already runs `monte_carlo.vol_source` "garch" (`data/assumptions.json`), and a
tier is a document classification, not a setting. The 20,000-path base was VaR99 58.29825662621968, ES99
79.27208399332699, EL 0.8781214705231672, L-VaR99 63.57976245293203 before and after this ticket.

Open for Sam, unchanged in kind but larger in size: a floor on low GARCH FX vols (limitation 6; +7.2% VaR99 at 0.75 x
regime). GOV-034 item 1 (standard errors) stays open.

### 11.7 Reproduce

```
python -c "from pathlib import Path; from econquest.validation.activation import garch_rerun; garch_rerun(Path('data'), '2026-10-23', Path('outputs/eq-b-0088'))"
python docs/validation/dossier/garch_backtests.py --only sensitivity --out outputs/eq-b-0088/sens
python -m pytest -q tests/test_garch_backtests.py
```

The activation pack's item d (`python -m econquest.validation.activation --as-of 2026-10-23 --only garch`) runs the
same code, but needs a staged build under `data/market_history/builds/`; after `apply` the history is in `prices.csv`
itself, so the call above runs `garch_rerun` on `data/` directly. Backtest about 2 minutes, stability about 1 minute,
sensitivity about 1 minute.
