# FX-only prices.csv: engine behaviour, classification and effect (EQ-B-0077)

Status: **approved by Sam 2026-10-24 16:17Z** (decision card "Approve, then apply on the Mac"), on the PROXY effect below (VaR99 69.13 -> 62.33, ES99 90.72 -> 83.15, EL 0.80 -> 0.87, L-VaR99 74.42 -> 67.61; Tier 1). Team A may tell Sam to run `apply` after the staged build. The activation pack (`econquest.validation.activation`, EQ-B-0079) reruns this table on the staged file; if any base metric differs from the PROXY by more than 5%, Team B goes back to Sam before the next release restates the base. Originally drafted 2026-10-24. Owner: Team B (AGENT-05). Handoff: HO-20261024-A-B-004 (Team A,
EQ-A-0054). All numbers below are a **PROXY**: today's `prices.csv` (sha256 e568019e..., the 0.3.0 input) with the
12 ETF columns dropped, so the FX values are still GOOGLEFINANCE closes, not BIS/ECB reference rates. The real
numbers come from the first staged build on Sam's Mac and must replace this table before `apply`.

## 1. What changes

Sam decided at 12:31Z to rebuild `data/market_history/prices.csv` from official BIS/ECB FX only. After
`python -m econquest.ingestion.market_history apply` the file has `date` and the 17 FX columns. VNM, EPHE, MCHI,
EWM, EWS, EWJ, EWY, INDA, EWZ, ARGT, GXG and EEM go, and `inda.csv` moves to `archive/`. Rows are trading days only;
gaps stay NaN; USDBZD may be empty.

The shipped settings read this file in two Tier 1 places: `monte_carlo.vol_source` "garch" (Monte Carlo
marginals) and `copula.source` "estimated" (layer 5 loadings).

## 2. Engine behaviour on FX-only prices

With the ETF columns present nothing changes: the 20,000-path base (as_of 2026-10-23) is VaR99 69.03387805642626,
ES99 91.20694811981282, EL 0.8046426805768283, L-VaR99 74.31538388313861 before and after the code change, and
every other float metric is equal.

| Reader | On FX-only prices | Where the fallback shows |
|---|---|---|
| `garch.run_garch` | Fits the FX series only. The Equity block (equity DCC, equity portfolio VaR, options check) is empty. No KeyError when no series fits at all. | `notes["equity_fallback"]` {country: reason}; RuntimeWarning |
| `garch.mc_vols`, Monte Carlo marginals | Equity legs keep the judgement `market.equity_vol` (25), the documented regime path. FX legs keep their GARCH vols. Today only P07 (EWY, South Korea) changes: 42.06 to 25.0. P22 (Zimbabwe) was already on judgement. | `reason` "EWY not in prices.csv (FX-only price history): judgement market.equity_vol"; position `vol_from` "regime (...)"; RuntimeWarning |
| Estimated copula (layer 5) | Fits on the FX component of each country shock. Countries whose only usable series was the ETF keep the judgement loadings (Argentina: USDARS is administered). See section 3. | `CopulaFit.components`, `left_out`, `etf_missing`; `copula_diagnostics()`; RuntimeWarning |
| HMM regimes (`regime.method` hmm or blend; shipped: rules) | Fits on `dep_4w` and `fxvol_4w` only, because with no ETF anywhere the ETF features cannot be imputed. Before the change the imputed ETF columns were all NaN. | `info["features"]`, `info["etf_feature"]`; `hmm_report` says so; RuntimeWarning |
| Econometrics toolkit (Tier 3) | Skips the SVAR (EEM-first ordering), Kalman betas on EEM, Fama-MacBeth and GMM premia, equity copula pairs and the event study. The forecast panel drops its two EEM predictors. FX tables run. Before the change it stopped on the missing EEM. | `notes["skipped"]` {table: reason}; log line; RuntimeWarning |
| `validation/record.py` | Marks FX and local-bond positions; equity positions are not marked. GARCH-DCC one-day VaR covers the FX block only. | `marked_positions` and `marked_notional_mm` columns (unchanged code) |
| `validation/idea_log.py` | Equity ideas are logged unmarked. | `unmarked_reason` "ticker ... not in market history" (unchanged code) |
| `validation/_rerun_worker.py` | Runs any price file it is given, including FX-only. | unchanged code |
| `scorecard/readiness.py` | Does not read prices. The `etf` advisory text now says the field only matters while prices.csv has ETF columns. | readiness table |
| `validation/replicate.py` | Older checks keep their frozen 0.1.4, 0.2.1 and 0.3.0 price files. R28 ("EWY 12-month GARCH vol", P07) and G01-G06 switch to the frozen 0.1.4 file only when the price history in use has no EWY column (a present but broken EWY is checked as it is). No FX-only check is added yet. | the check's note in replication.md; log line |

No fallback reads data after `as_of`: the tests add absurd rows after as_of and the metrics do not move.

## 3. Copula choice: estimated on FX only

Choice: keep `copula.source` "estimated" and let the fit run on the FX moves. Countries with no usable FX series
keep the judgement loadings, as they do today.

Why:
- The layer 5 latent is one stress factor per country. It drives FX, local bonds, Eurobonds, CDS and equity alike.
  It is not an equity factor, so there are no "equity-only loadings" to fall back for, except for countries whose
  only series was the ETF. That is Argentina, and it falls back to judgement automatically.
- The FX history still identifies the factor for 11 floating or managed currencies over 157 weeks.
- Switching every country to the judgement copula is a change of `copula.source`, a Tier 1 parameter. It moves
  the base twice as much (section 5, last row). It stays available to Sam as that switch.

What is lost: the equity co-movement in the loadings. Eight of the eleven estimated Calm global loadings fall
(largest: Philippines 0.287 to 0.154, India 0.192 to 0.085, Brazil 0.411 to 0.287), Singapore and South Korea
rise, Zambia stays at 0 (squared loadings; dossier `garch-dcc-tier1.md` section 5.2). Estimated nu stays unused (judgement 5 / 4).

## 4. Classification: Tier 1 model change

Per `docs/governance/model-risk-policy.md` sections 2 and 4 and `change-control.md`:

1. A new `prices.csv` is nominally an input change. This one is not a routine vintage: it changes the source
   (reference fixings, not closes) and the schema (12 columns removed). It is not a quality-gated refresh.
2. The file feeds Tier 1 numbers in the shipped settings. `monte_carlo.vol_source` is "garch" (GARCH vols replace
   `market.fx_vol` and `market.equity_vol`, GOV-020) and `copula.source` is "estimated" (layer 5). The policy puts
   any component that feeds a Tier 1 number in Tier 1.
3. It changes how a Tier 1 parameter is set, not only its data: the equity marginal moves from a GARCH estimate to
   the judgement `market.equity_vol`, and Argentina moves from estimated to judgement loadings.
4. The effect is material: VaR99 -9.8% (about 20 SE) and ES99 -8.3% on the proxy, just under the 10%
   `alerts.var_change_pct` threshold. The official fixings will move FX vols and DCC again.
5. The engine code change in this ticket is a model change too (it touches `engine/`), but it is default-identical
   on today's file.

Tier 2 and 3 parts: GARCH-DCC VaR in the forecast record loses its equity half (Tier 2); HMM (shipped method rules)
and econometrics are Tier 3.

Sign-off: owner + approver (Sam) + validator; "independent review pending" while GOV-042 is open. No
`assumptions.json` key changes, so there is no `econquest change propose`; the approval is Sam's sign-off of this
note before `apply`.

## 5b. Effect on the second staged build (EQ-B-0093, 2026-10-25)

Build `2026-10-25T000005Z-d1f504f1` (prices.csv sha256 4eaa006b...; 1,100 rows, 2023-10-18 to 2026-10-23; 0
disagreements). It fills the 7 columns that were empty in 5a: VND, PKR, BZD, VES, NGN and ZMW from theratesapi.com
(EXC-005), XOF from the peg times ECB EUR/USD. Same method as 5a. Raw output: `fx-only-real-2/`.

| Metric ($mm) | 0.3.0 | Proxy (approved) | Build 1 (5a) | Build 2 | SE | Build 2 vs proxy |
|---|---|---|---|---|---|---|
| VaR99 | 69.13 | 62.33 | 59.64 | 58.19 | 0.28 | -6.6% |
| ES99 | 90.72 | 83.15 | 80.28 | 78.72 | 0.45 | -5.3% |
| EL | 0.80 | 0.87 | 0.88 | 0.88 | | +1.1% |
| L-VaR99 | 74.42 | 67.61 | 64.92 | 63.47 | 0.28 | -6.1% |

VaR99, ES99 and L-VaR99 are more than 5% below the approved proxy, so this goes back to Sam (status-line rule).
**Decided 2026-10-25 00:12Z: Sam accepted these numbers and approved `apply` of build `2026-10-25T000005Z-d1f504f1` (decision card "Accept and apply"). The next release restates the base at about VaR99 58.2, ES99 78.7.**
Stress ES99: A 131.4, B 85.9, C 95.2, DOWNGRADE 82.3, TAIWAN 137.0, HORMUZ 138.4, TARIFF 127.9, CHINA_HL 137.9,
FED22 147.6, TAPER13 140.5.

Why it fell further than build 1. VES, NGN, PKR and BZD stay on judgement volatility (GOV-034 administered list), so
their new history does not change the risk. The movers are the three fitted ones (12-month GARCH volatility):
USDVND 1.8% (managed band, fitted like USDCNY at 2.6%), USDXOF 6.3% (the EUR/USD move behind the peg) and USDZMW
12.6%. Each replaces a judgement volatility, and the copula now sees their moves. 20,000-path paired check:
build 1 59.95 / 80.78; build 2 58.30 / 79.27; build 2 with VND on judgement 58.85 / 79.69; with VND, ZMW and XOF on
judgement 59.45 / 80.39. Most of the gap to the proxy was already there in build 1 (the proxy used GOOGLEFINANCE FX
closes); the new columns add about -2.5%.

## 5a. Effect on the real staged build (EQ-B-0085, 2026-10-24 20:45Z)

Sam's staged build `2026-10-24T183253Z-c75d167d` (official BIS/ECB; prices.csv sha256 b1f788a4...; 1,091 rows,
2023-10-24 to 2026-10-20; 0 BIS/ECB disagreements). Activation pack `--only fx`, 100,000 requested paths (131,072
Sobol), as_of 2026-10-23, shipped settings, paired with today's data. Raw output: `fx-only-real/`.

| Metric ($mm) | 0.3.0 | Proxy (approved) | Real build | SE | Real vs proxy |
|---|---|---|---|---|---|
| VaR99 | 69.13 | 62.33 | 59.64 | 0.26 | -4.3% |
| ES99 | 90.72 | 83.15 | 80.28 | 0.43 | -3.5% |
| EL | 0.80 | 0.87 | 0.88 | | +1.1% |
| L-VaR99 | 74.42 | 67.61 | 64.92 | 0.26 | -4.0% |

Every base metric is within the 5% band of the approved proxy, so the approval stands and `apply` may proceed
(rule in the status line). Stress ES99 on the real build: A 133.0, B 87.8, C 96.8, DOWNGRADE 84.1, TAIWAN 139.9,
HORMUZ 140.5, TARIFF 130.1, CHINA_HL 140.1, FED22 149.5, TAPER13 142.3.

Why the real build is lower than the proxy: 7 FX columns are empty because neither BIS WS_XRU nor ECB EXR serves
them (USDVND, USDPKR, USDBZD, USDVES, USDNGN, USDXOF, USDZMW; USDARS 720 and USDCOP 1,089 values). In the proxy those
columns still held GOOGLEFINANCE closes. Now the GARCH marginal for those FX legs reports "no series" and the leg
keeps its regime (judgement) volatility, and those currencies have no FX moves in the estimated copula. This is a
limitation, not a gain in safety: Team A's theratesapi.com route (EXC-005, fx3m only today) does not yet give a
price history. A history for these currencies would restore data-driven vols and should be rerun through this table.

## 5. Effect table (PROXY, for the decision note)

Base, 100,000 requested (131,072 Sobol paths), as_of 2026-10-23, shipped settings. SE is the batch-means Monte Carlo
error (`mc_error`, 32 batches). "Today" reproduces the 0.3.0 base.

| Metric ($mm) | Today (with ETFs, 0.3.0) | FX-only PROXY | SE (proxy) | Change |
|---|---|---|---|---|
| VaR99 | 69.13 | 62.33 | 0.21 | -9.8% |
| ES99 | 90.72 | 83.15 | 0.38 | -8.3% |
| EL | 0.80 | 0.87 | | +8.8% |
| L-VaR99 | 74.42 | 67.61 | 0.21 | -9.1% |

EL rises because P07 (EWY, long) goes from a 42% to a 25% vol. The long-loss cap truncates less of a narrower loss
tail, so the capped mean loss is higher (`long_cap_relief_mm`, EQ-B-0053). PDs do not move.

Stress ES99 ($mm), same settings, 100,000 requested:

| Scenario | Today (0.3.0) | FX-only PROXY | SE (proxy) | Change vs proxy base | Change vs today |
|---|---|---|---|---|---|
| A | 145.4 | 137.4 | 0.43 | +65.3% | -5.5% |
| B | 98.2 | 90.6 | 0.41 | +9.0% | -7.8% |
| C | 107.7 | 99.9 | 0.36 | +20.2% | -7.2% |
| DOWNGRADE | 94.5 | 87.0 | 0.38 | +4.6% | -8.0% |
| TAIWAN | 152.0 | 143.8 | 0.40 | +73.0% | -5.4% |
| HORMUZ | 155.7 | 144.3 | 0.35 | +73.5% | -7.3% |
| TARIFF | 143.6 | 133.9 | 0.35 | +61.0% | -6.8% |
| CHINA_HL | 153.7 | 142.9 | 0.32 | +71.9% | -7.0% |
| FED22 | 162.1 | 151.6 | 0.29 | +82.3% | -6.5% |
| TAPER13 | 155.0 | 144.8 | 0.36 | +74.1% | -6.6% |

For comparison only (not proposed): FX-only with `copula.source` "judgement" gives VaR99 55.96, ES99 73.54,
EL 0.87, L-VaR99 61.24 (-19.1% / -18.9% against today).

Limits (115 ES99, 95 VaR99): the proxy ES99 is 72.3% of its limit (today 78.9%).

## 6. Tests

`tests/test_fx_only_prices.py` (SYNTHETIC frames from today's file): 17-column frame and an official-like variant
(no weekend rows, about 3% NaN cells, 12 empty holiday rows, USDBZD empty, no carry-over). The pipeline runs end to
end on both with finite metrics and SEs; equity legs carry the judgement vol and the reason; rows after as_of change
nothing; GARCH, `mc_vols`, the copula, the HMM, econometrics, record, idea log, readiness, the rerun worker and the
replication fallback each have a test. Today's file raises no EQ-B-0077 warning.

## 7. Before `apply` (Sam's Mac)

1. Run Team A's staged build (`data/market_history/builds/<vintage>/`).
2. Rerun this effect table on the staged file: `run_pipeline` at 100,000 paths, as_of 2026-10-23, base and the ten
   scenarios, with `u.prices` read from the staged `prices.csv`; replace section 5.
3. `python -m econquest.validation.replicate` on the live data: every check keeps its frozen price file.
4. TODO (after Sam's first official pull): add FX-only reference checks to `validation/replicate.py` with their own
   frozen copy of the official `prices.csv` (base VaR99/ES99/EL/L-VaR99, the ten stress ES99s, the FX-only loadings
   and the G-group series count on FX only).
5. Done 16:17Z: Sam signed this note. Team B sets the handoff response with the Tier and the numbers; then Team A tells Sam to
   run `apply`. After `apply`, the next release note restates the base.

## 8. Presentation follow-ups (Team C, via AGENT-08)

- `econquest/presentation/econ_publish.py`: Table 3 note reads `svar_meta['lags']`, `['obs']`, `['order']`, and
  Tables 6a/6b read `premia_meta['N']`, `['T']`, `['J']`, `['J_p']`; on FX-only these are absent and the meta holds
  `skipped`. Tables 4 (EEM betas), 9 (note says 12 predictors incl. EEM; now 10) and 10 (event study) need the
  reason from `notes["skipped"]` instead of an empty table.
- `econquest/presentation/static/gui.html` (line ~508): the default series selection includes EEM, EWZ and MCHI.
- `econquest/presentation/garch_publish.py`: handles a missing equity DCC and empty options already; Tables C and E
  should print `notes["equity_fallback"]` so the reader sees why they are empty.
