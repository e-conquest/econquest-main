# Switch-on dossier: DSA signal, DSA PD overlay, event GPR

Date: 2026-10-24. Ticket EQ-B-0080. Written by Team B AGENT-03. **This is not an independent validation**: the
author is on the team that built these models (policy principle 4).

Three settings shipped off. Each would be a Tier 1 change. Sam decides; the commands at the end of each section
were drafts for him.

## Decisions (Sam, 2026-10-24)

| setting | decision | change | effect |
|---|---|---|---|
| (a) `dsa.signal_enabled` | Switched on, display only, with `inputs_path` `data/dsa_inputs.csv` (card 16:57Z) | CHG-20261024T165855Z-06438f, applied | Signal 26, now labelled "Debt above IMF benchmark (DSA)" (dsa.py, signals.py). No PD, VaR or ES moves; 20,000-path base bit-identical. |
| (b) `dsa.pd_overlay_enabled` | Kept off until the score is backtested against defaults (card 16:57Z) | none | none |
| (c) `gpr.source` | Stays `ci`. No card was posted: there is no event data, so switching would change nothing | none | none |

Related (VF-012, not in this dossier): `layer1.missing_input_rule` "carry_forward_k" with `layer1.missing_input_k` 2,
CHG-20261024T165907Z-d4aff0, applied. Inert while `layer1.mode` is paper_standardized.

The sections below are the evidence as written before the decisions.

Run used for every number: `run_pipeline(u, s, paths=100000, as_of="2026-10-23")`, settings `data/assumptions.json`
(0.3.0), same seed in every run, so differences between runs are mostly not Monte Carlo noise (the VaR99 standard
error of one run is about 0.33 at 100,000 paths). PDs are `pd_default` (after layer 2 and regimes), in percent.
Script: `EQ-B-0080_effects.py` in the AGENT-03 scratch folder; the rows below are copied from its output.

Base at 100,000 paths: VaR99 69.13, ES99 90.72, EL 0.80, L-VaR99 74.42 ($mm). Matches the 0.3.0 release.

## (a) `dsa.signal_enabled`

**What it does.** Runs the stochastic DSA (`engine/dsa.py`, `dsa_signal_hook`) in every pipeline run and adds
signal 26 "Debt above IMF benchmark (DSA)" (renamed from "Debt sustainability (DSA)" when switched on; 0 to 100, higher is worse) to the signal table, the dashboard and the run
diagnostics. It does not touch any PD. Signal 26 is not in the playbook, so no trade activation changes.

**Evidence today (real data).** Runs on the real WEO pull of 2026-10-23 (`data/live/vintages/2026-10-23/`, read
point in time by `load_weo_as_of`). 17 of 18 countries get a score; Venezuela has no WEO debt series and gets NaN.
Scores: China, Brazil, Japan, Singapore 100; Senegal 99.7; Pakistan 80.8; India 73.8; Zambia 68.8; Belize 42.5;
Malaysia 40.9; Colombia 38.3; Argentina 35.9; Philippines 14.3; Nigeria 5.7; Zimbabwe 1.8; Vietnam 0.1;
South Korea 0. No backtest against defaults (`dsa.md`, open item 5).

**Effect (100,000 paths).**

| run | VaR99 | ES99 | EL | L-VaR99 | PDs | activation |
|---|---|---|---|---|---|---|
| base | 69.13 | 90.72 | 0.80 | 74.42 | - | - |
| signal on | 69.13 | 90.72 | 0.80 | 74.42 | none move | identical |

**Risks.** The score is driven by debt levels. Japan and Singapore show 100 on the dashboard although neither is
near default (Singapore's debt funds CPF assets; Japan's is held at home). Readers may take 100 as "near default".
The hook reads `dsa.data_dir` relative to the working directory (default `data`): run from the econquest folder,
or it warns and shows no signal. Without `dsa.inputs_path` every country gets a 7-year maturity.

**Recommendation.** Switch on, with `inputs_path` set. It moves no number. The dashboard and notes should say that
the score measures "above the IMF benchmark", not default risk.

```bash
econquest change propose assumptions.json --set '/dsa={"signal_enabled": true, "inputs_path": "data/dsa_inputs.csv"}' --tier 1 --allow-new-keys --author '<YOUR NAME>' --reason 'EQ-B-0080: switch on DSA signal 26 (display only, no PD, VaR or ES change at 100k, as_of 2026-10-23)'
```

**Card for Sam.**
- Question: Switch on the DSA signal (display only)?
- Options:
  1. Switch on with the maturity file. Signal 26 appears on the dashboard and in notes; no PD, VaR or ES moves.
  2. Keep off. Nothing changes; the DSA stays a library and country-note tool.
  3. Switch on and ask Team C to add it to the dashboard risk keys. Same numbers; more visible, also the level bias.
- Recommended: 1. It moves no number, and the score is readable next to the PD once labelled as a benchmark test.

## (b) `dsa.pd_overlay_enabled` with `dsa.pd_logit_weight`

**What it does.** `logit(pd_default) + w x (dsa_score - 50) / 50`, capped at 0.99. A score above 50 raises the PD,
a score below 50 lowers it. With w 0.5 a score of 100 adds 0.5 to the log-odds (about x1.6 for a small PD).

**Evidence today (real data, no backtest).** Same scores as (a). The score has never been compared with defaults or
with the PD. The weights 0.25 and 0.5 are judgement.

**Effect on the portfolio (100,000 paths, as_of 2026-10-23).** "excl JP/SG" leaves Japan and Singapore out of the
overlay; "raise-only" treats scores below 50 as 50, so the overlay can only raise a PD. Both use the settings
`dsa.overlay_exclude` and `dsa.overlay_raise_only` (off by default, added in this ticket); the settings reproduce
the script's PDs to 1e-16.

| run | VaR99 | ES99 | EL | L-VaR99 |
|---|---|---|---|---|
| base | 69.13 | 90.72 | 0.80 | 74.42 |
| w 0.25, as built | 69.97 | 91.31 | 1.12 | 75.25 |
| w 0.5, as built | 70.80 | 92.05 | 1.52 | 76.08 |
| w 0.25, excl JP/SG | 69.97 | 91.26 | 1.12 | 75.25 |
| w 0.5, excl JP/SG | 70.80 | 91.95 | 1.52 | 76.08 |
| w 0.25, excl JP/SG, raise-only | 70.44 | 91.83 | 1.21 | 75.72 |
| w 0.5, excl JP/SG, raise-only | 71.84 | 93.08 | 1.68 | 77.12 |

**PDs per country (pd_default, %).**

| country | score | base | w 0.25 | w 0.5 | w 0.25 raise-only excl JP/SG | w 0.5 raise-only excl JP/SG |
|---|---|---|---|---|---|---|
| Vietnam | 0.1 | 0.36 | 0.28 | 0.22 | 0.36 | 0.36 |
| Philippines | 14.3 | 0.36 | 0.30 | 0.25 | 0.36 | 0.36 |
| China | 100 | 0.28 | 0.36 | 0.47 | 0.36 | 0.47 |
| Malaysia | 40.9 | 0.20 | 0.19 | 0.18 | 0.20 | 0.20 |
| Singapore | 100 | 0.04 | 0.05 | 0.07 | 0.04 | 0.04 |
| Japan | 100 | 0.04 | 0.05 | 0.07 | 0.04 | 0.04 |
| South Korea | 0.0 | 0.06 | 0.05 | 0.04 | 0.06 | 0.06 |
| India | 73.8 | 0.33 | 0.37 | 0.41 | 0.37 | 0.41 |
| Pakistan | 80.8 | 8.04 | 9.25 | 10.63 | 9.25 | 10.63 |
| Belize | 42.5 | 4.86 | 4.69 | 4.53 | 4.86 | 4.86 |
| Brazil | 100 | 1.12 | 1.44 | 1.84 | 1.44 | 1.84 |
| Argentina | 35.9 | 6.60 | 6.18 | 5.78 | 6.60 | 6.60 |
| Colombia | 38.3 | 1.09 | 1.03 | 0.97 | 1.09 | 1.09 |
| Venezuela | none | 99.00 | 99.00 | 99.00 | 99.00 | 99.00 |
| Nigeria | 5.7 | 3.88 | 3.14 | 2.53 | 3.88 | 3.88 |
| Senegal | 99.7 | 13.34 | 16.49 | 20.19 | 16.49 | 20.19 |
| Zambia | 68.8 | 4.53 | 4.95 | 5.41 | 4.95 | 5.41 |
| Zimbabwe | 1.8 | 78.40 | 74.04 | 69.15 | 78.40 | 78.40 |

Who moves most (as built, w 0.5): Zimbabwe -9.2 pp, Senegal +6.9 pp, Pakistan +2.6 pp, Nigeria -1.4 pp,
Zambia +0.9 pp, Argentina -0.8 pp, Brazil +0.7 pp. At w 0.25 the moves are about half.

**Japan and Singapore.** They already use the advanced-economy thresholds (debt 85%, GFN 20%) and still score
100, because their debt (205% and 166% of GDP) and GFN are far above any benchmark. So the advanced thresholds do
not fix this; exclusion does. In money it is small here (their PDs go from 0.04% to 0.07% at w 0.5; ES99 -0.10 when
excluded), but a doubling of PD on level alone is wrong in direction for these two.

**Risks.**
- No backtest. The score has never been tested against defaults.
- Two-sided as built. Low scores cut PDs. Zimbabwe (in arrears) scores 1.8 because inflation and revaluation shrink
  its debt ratio, so the overlay cuts its PD by 4 to 9 pp. Nigeria and Argentina also fall. This is the main reason
  not to switch on as built.
- Level bias (Japan, Singapore, also China and Brazil at 100).
- Double counting: debt level already enters the scorecard (pillar 1) and layer 1.
- EL is net of carry (VF-011), so its rise mixes PD and carry effects.

**Recommendation.** Keep off until the score is backtested against the default panel (`dsa.md` item 5). If Sam
wants it before then: w 0.25, raise-only, Japan and Singapore excluded (VaR99 +1.31, ES99 +1.11, EL +0.41;
Senegal +3.1 pp, Pakistan +1.2 pp move most).

The two options are in `engine/dsa.py` (`DSA_DEFAULTS`, `pd_overlay`; tests `tests/test_dsa_overlay_options.py`).
Off by default; the 20,000-path base is bit-identical with them in place.

Command (after (a) is applied, so `/dsa` exists):

```bash
econquest change propose assumptions.json --set '/dsa/pd_overlay_enabled=true' --set '/dsa/pd_logit_weight=0.25' --set '/dsa/overlay_raise_only=true' --set '/dsa/overlay_exclude=["Japan", "Singapore"]' --tier 1 --allow-new-keys --author '<YOUR NAME>' --reason 'EQ-B-0080: DSA PD overlay w 0.25, raise-only, Japan and Singapore excluded; 100k as_of 2026-10-23 VaR99 69.13 -> 70.44, ES99 90.72 -> 91.83, EL 0.80 -> 1.21; no backtest'
```

**Card for Sam.**
- Question: Let the DSA score move PDs?
- Options:
  1. Keep off until backtested. No change; Team B backtests the score on the default panel first.
  2. Weight 0.25, raise-only, Japan and Singapore out. VaR99 69.13 to 70.44, ES99 90.72 to 91.83; Senegal +3.1 pp, Pakistan +1.2 pp.
  3. Weight 0.5 as built. VaR99 to 70.80, ES99 to 92.05; Senegal +6.9 pp, but Zimbabwe -9.2 pp and Nigeria -1.4 pp.
- Recommended: 1. The score has no track record, and as built it lowers PDs for Zimbabwe and Nigeria.

## (c) `gpr.source` "events" or "blend"

**What it does.** Indicator 4.10 and the GPR signals use a country score built from UCDP and GDELT events instead
of (`events`) or mixed 50/50 with (`blend`) the Caldara-Iacoviello (CI) series (`gpr-events.md`). Through 4.10 it
moves pillar 4, the composite and the PDs. Seven countries with no CI series (Singapore, Pakistan, Belize, Nigeria,
Senegal, Zambia, Zimbabwe) would get a GPR uplift for the first time.

**Evidence today.** None on real data. The code is tested on SYNTHETIC fixtures only. There is no event table in
the repo (`data/live/events/events_long.csv` is missing; the UCDP and GDELT pulls wait on Sam's Mac and a UCDP
token) and no sovereign spread history to backtest against (`data/cds_quotes.csv` is empty).

**Effect (100,000 paths).** Today both values warn ("no event table") and keep CI, so the numbers are identical:

| run | VaR99 | ES99 | EL | L-VaR99 | PDs |
|---|---|---|---|---|---|
| base | 69.13 | 90.72 | 0.80 | 74.42 | - |
| events | 69.13 | 90.72 | 0.80 | 74.42 | none move |
| blend | 69.13 | 90.72 | 0.80 | 74.42 | none move |

The real effect waits for data. No proxy is given: the only one would come from the synthetic fixture, which says
nothing about these countries.

**Risks.** Weights and windows are judgement. The newest month is GDELT only (revised when UCDP arrives). GDELT
coverage drifts with the media. On synthetic episodes the score is coincident, not leading, for sudden outbreaks.
`stress._clone` drops the event table, so stressed runs silently use CI (edit listed in `gpr-events.md`).

**Recommendation.** Keep `ci`. After the pulls and a spread history land: rerun the episode backtest and this
table on real data; switch to `blend` only if the score is at least coincident with spread moves and quiet on calm
countries.

```bash
econquest change propose assumptions.json --set '/gpr/source="blend"' --set '/gpr/blend_weight_events=0.5' --tier 1 --allow-new-keys --author '<YOUR NAME>' --reason 'EQ-B-0072/EQ-B-0080: event GPR blend 0.5 after real UCDP/GDELT pulls and backtest; effect table <rerun on real data>'
```

**Card for Sam.**
- Question: When should event-based GPR feed indicator 4.10?
- Options:
  1. Keep CI until real data and a backtest exist. No change; rerun this dossier after the pulls and a spread history land.
  2. Blend 50/50 once the pulls land. Seven uncovered countries get a GPR uplift; effect on PDs, VaR, ES not yet known.
  3. Events only once the pulls land. Drops CI where both exist; largest change, least tested.
- Recommended: 1. Today there is no event data, so switching changes nothing, and no real evidence supports it yet.
