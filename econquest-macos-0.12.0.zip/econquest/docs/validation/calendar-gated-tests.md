# Model validation: calendar-gated formal tests

Date: 2026-10-25 (EQ-B-0091). Code: `econquest/validation/calendar_tests.py`. Tests:
`tests/test_calendar_tests.py` (synthetic records, snapshots and idea logs). Tier 3: read-only, not
called by the pipeline, no reported base number reads it.

Two formal tests can only run once enough calendar time has passed. The code for both is built now,
so on the gate date it runs as written. Before the gate it returns `NOT_DUE` and computes nothing.

| Test | Function | Gate | Data requirement |
|---|---|---|---|
| 250-day VaR / ES backtest | `run_var_backtest(record, as_of)` | 2027-07-14 | 250 clean tested days in `data/forecast_record.csv` |
| 12-month benchmark and trade-idea scoring | `run_benchmark_scoring(benchmarks, events, as_of, rating_actions, idea_log)` | 2027-10-23 | snapshot rows in `data/benchmarks.csv` at least 12 months old |

The gate dates are the evidence monitor's earliest test dates (`evidence_monitor.py`, EQ-B-0061):
the 250th weekday of the record from 2026-07-30, and the first 12-month maturity of the 2026-10-23
snapshot. They are fixed in the module (`VAR_GATE`, `BENCHMARK_GATE`). The interim monthly scorecard
(`forecast_scorecard.py`, [forecast-record.md](forecast-record.md)) is unchanged.

## Status of a result

| Status | When | What is computed |
|---|---|---|
| `NOT_DUE` | as_of before the gate | nothing; the row gives the days left and the progress |
| `INSUFFICIENT_DATA` | gate passed, requirement not met | nothing; CLI exit code 3 |
| `DRY_RUN` | `force_dry_run=True` (`--force-dry-run`) | everything, on what exists. Every row is labelled, for example "DRY RUN, 60 days < 250, not a test result" |
| `TEST_RESULT` | gate passed and requirement met | everything |

A dry run is a check that the code runs on today's data. It is never a test result and is not to be
quoted. Its files carry `_dry_run` in the name.

## Point in time

`as_of` is required. The clock is never read. Record rows count only when dated and recorded
(`recorded_at`) on or before as_of. Snapshots, default starts, rating actions and idea marks count
only when dated on or before as_of. An idea whose latest mark is after as_of cannot be replayed (the
log keeps one mark) and is left out and counted.

## VaR / ES backtest

Clean days: rows with loss, VaR and ES present, finite, VaR > 0 and ES >= VaR. The test uses the
trailing 250 clean days to as_of (the Basel window). Backfilled rows count, as in the evidence monitor;
their number is reported.

- Kupiec POF: LR_uc on the exception count, chi2(1) (`backtests.kupiec`).
- Christoffersen: LR_ind from the 2x2 transition counts, chi2(1); LR_cc = LR_uc + LR_ind, chi2(2)
  (`backtests.christoffersen`).
- Basel traffic light: Green 0-4, Yellow 5-9, Red 10+ exceptions in 250 days, with the plus factor
  (0.40, 0.50, 0.65, 0.75, 0.85 for 5-9; 1.00 in Red).
- Acerbi-Szekely Z2 = 1 - sum(L I / ES) / (T (1 - alpha)). Expected 0; negative when ES is too low.
  The p-value is simulated (2,000 draws, seed 91): each day's loss is drawn from a Student-t scaled to
  that day's VaR, with the degrees of freedom implied by that day's ES/VaR ratio. The null therefore
  matches both forecast numbers. The fixed -0.7 threshold is shown for reference.
- McNeil-Frey: on exception days, r = (L - ES) / sigma, with sigma implied by VaR and ES. H0 mean 0,
  H1 mean > 0 (ES too low). One-sided p from a centred bootstrap of the t-statistic (5,000 resamples,
  seed 91). Needs at least 2 exceptions.

Verdict: Pass when Kupiec p, Christoffersen cc p, Z2 p and McNeil-Frey p (when computable) are all
at least 0.05. This is stricter on ES than `backtests.backtest_history`, which uses Z2 > -0.7.

Hand checks in the tests: 5 exceptions in 250 days with one pair of consecutive exceptions gives
LR_uc 1.956810 (p 0.161855), transitions n00 240, n01 4, n10 4, n11 1, LR_ind 3.153989, LR_cc p
0.077661, Yellow, plus factor 0.40. Zero exceptions gives LR_uc = -500 ln 0.99 = 5.025168 (Kupiec
rejects). 4 consecutive exceptions fail independence (p < 0.001). 9 and 10 exceptions give Yellow
(0.85) and Red.

## 12-month benchmark and trade-idea scoring

- PD sources (model, hazard layer, rating-implied, spread-implied, CDS, prediction market): Brier, log
  score, AUC, Brier skill and the clustered Diebold-Mariano comparison against the model, on matured
  snapshot rows (`benchmarks.score_benchmarks`). Labelled underpowered below 10 default events.
- Rating actions (`data/rating_actions.csv`, optional): was the model on the side of each move, as in
  the scorecard (`forecast_scorecard.rating_section`).
- Trade ideas opened in the 12 months to as_of (`outputs/idea_log.csv`): hit rate of closed, marked
  ideas with a one-sided binomial test against 0.5; P&L gross, an assumed round-trip cost (FX 20 bps,
  Equity 10 bps of notional; the log has no cost), net P&L and gross P&L / cost. The cost table can be
  set with `calendar_tests.idea_cost_bps` in settings; there is no such key in assumptions.json, so the
  code default applies. Labelled underpowered below 20 closed ideas. CDS, Eurobond, local-rates and
  other unmarked ideas are not scored.

In a dry run with no matured row, the PD part uses the interim elapsed-time scoring of the scorecard
(`forecast_scorecard.interim_outcomes`) so the code path runs.

## Entry point for the scheduled job

`formal_verdicts(as_of, data_dir="data", out_dir="outputs") -> list[dict]`, one dict per test id of
`ops/calendar_jobs.py`: `{"test", "status", "detail", "n"}`, status `gated`, `pass`, `fail` or
`review`. While gated, `n` is the record's clean days (VaR), the snapshot rows (PD) and the ideas logged
(ideas). VaR gives pass or fail (review when the gate has passed without 250 days). The PD benchmark
and the idea test always give `review`: no pass/fail rule is set for them. The PD detail says whether
the model's Brier is worse than the rating-implied one (the revalidation trigger). Answers
HO-20261025-C-B-001.

## Run

```
python -m econquest.validation.calendar_tests --as-of 2026-10-25                    # NOT_DUE for both
python -m econquest.validation.calendar_tests --as-of 2026-10-25 --force-dry-run    # dry run
python -m econquest.validation.calendar_tests --as-of 2027-07-14 --test var --out outputs/calendar_tests
```

Writes `<out>/calendar_tests_<as_of>[_dry_run].csv` and `.md`. The default `<out>` is the repo's
`outputs/calendar_tests`. `--out` must resolve to a subfolder of the repo's `outputs/` (checked by
`activation.resolve_out_dir`, whatever the current folder); `outputs/` itself is refused.
Exit codes: 0 (result, not due or dry run), 3 (gate passed, data short), 1 (error).

## Interim reports (EQ-B-0107)

Between now and the formal dates, `interim_report(as_of, data_dir="data", out_dir="outputs")` gives a
monthly look at what has accumulated. It is for Team C's interim backtest page (EQ-C-0118). Every row,
file and JSON field is labelled INTERIM, not a formal test result. That stays true after the formal
dates; the formal results come only from `run_var_backtest`, `run_benchmark_scoring` and
`formal_verdicts`.

- VaR: exceptions per calendar month over the whole clean record to as_of, with tested days, the
  expected count, the largest loss / VaR and the exception dates. Running total: tested days,
  exceptions against the two-sided 95% binomial band, Kupiec p on all days so far (low power below
  250 days) and the Basel zone scaled to the current n.
- Benchmarks: the 12-month scores on matured rows; while none has matured, the elapsed-time interim
  Brier, log score and AUC of the scorecard. Rating actions as in the formal scoring.
- Trade ideas: hit rate of closed, marked ideas, binomial p against 0.5, and P&L gross, assumed cost
  and net, for ideas opened in the 12 months to as_of.
- Progress to each formal date: days left, clean days (of 250), matured rows, ideas logged.

Files: `<out_dir>/calendar_tests/interim/interim_<as_of>.csv`, `.md`, `.json`, and
`interim_latest.json` (the same JSON, for the page). The returned dict has the keys `as_of`, `kind`
("INTERIM"), `label`, `formal`, `var` (with `months` and `zone_scaled`, the Basel zone scaled to n),
`benchmark`, `ideas`, `verdicts`, `table` and `paths`. `verdicts` (HO-20261025-C-B-004) gives one interim
reading per test, each starting "INTERIM" and at most 120 characters. For VaR it is the binomial band and the
scaled zone, never pass or fail. For the PD benchmark and the ideas it says there is no interim verdict:
no pass/fail rule is set for them; that is Sam's call.
`write=False` returns it without writing. Point in time like the formal tests; no clock read; nothing
fetched.

CLI: `python -m econquest.validation.calendar_tests --as-of 2026-10-25 --interim` writes to
`outputs/calendar_tests/interim/` (or `<--out>/interim/`).

Interim on 2026-10-25: 60 clean days, 1 exception (2026-09-23) against 0.6 expected, inside the band
0 to 2; by month 0 (Jul, 2 days), 0 (Aug, 21), 1 (Sep, 22), 0 (Oct, 15). No benchmark row matured;
73 ideas logged, 1 closed. Underpowered, INTERIM.

## Dry run on 2026-10-25 (not a test result)

VaR: 60 clean days (59 backfilled), 1 exception against 0.6 expected, Kupiec p 0.64, Christoffersen
cc p 0.88, Z2 -0.27 (simulated p 0.45), McNeil-Frey not computable (1 exception). Benchmarks: 18
snapshot rows, none matured; interim Brier only, 0 default events. Ideas: 73 logged, 9 marked, 1
closed. All of this is underpowered and labelled DRY RUN.

## Limits

- 250 days give little power: Kupiec cannot tell a 1% from a 2% exception rate with confidence.
- The ES p-values assume a Student-t shape matched to each day's VaR and ES; that is the GARCH-DCC
  assumption of the record itself.
- The record marks FX, local-bond and equity positions only; Eurobonds are not in the daily loss.
- No pass/fail rule exists for PD or idea scores; Sam reviews them.
