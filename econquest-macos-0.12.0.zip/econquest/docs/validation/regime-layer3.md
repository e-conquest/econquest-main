# Model validation: Layer 3 regime dynamics

Date: 2026-10-23. Code: `econquest/engine/layer3_regime.py` (`rule_regime`, `transition_matrix`,
`regime_multipliers`, `global_regime`, `GaussianHMM`). Parameters: `data/assumptions.json` keys
`regime_rules`, `regime`, `transition_matrix`, `monte_carlo.global_stress_share`. Status: the
operational regime is rule-based on three hand-entered market variables; the transition matrix is
the paper's starting point and is not estimated. A pooled 3-state HMM fitted on weekly market
history (`regime_hmm.py`) is available as an option (`regime.method` hmm | blend, `transition_matrix.source`
hmm), default off; evidence for the decision in section "EQ-B-0036" below.

## Purpose

Layer 3 assigns each country a regime (Calm, Stressed, Crisis) and converts it into expected
12-month multipliers on default probability and loss severity, plus a global regime that selects the
copula degrees of freedom and scales the global factor loading. It implements section 3.3 of the
paper.

## Where it sits in the pipeline

`run_pipeline` computes `regime = L3.rule_regime(u, settings)`, `mult =
L3.regime_multipliers(regime, settings)` and `gstate = L3.global_regime(regime, settings)` before
Layer 2, because the multipliers are applied to the Layer 2 posterior (`pd_default = min(0.99,
pd_final * pd_mult)`), to the peril PDs, to the hard-currency LGD (`lgd_hard_expected = min(0.95,
0.6 * lgd_mult)`), to the Beta haircut means in Layer 4, to the factor loadings in Layer 5 and to
the liquidity multipliers. `gstate` sets `df` (5 calm, 4 stressed) and the `global_loading_mult
1.5`.

## Assumptions

1. Rule-based regime (`rule_regime`): Crisis if the country is flagged in default, or spread at
   least `crisis_spread 1000` bps, or 3-month depreciation at least `crisis_fx3m 15` percent.
   Otherwise Stressed if spread at least `stressed_spread 400`, or depreciation at least
   `stressed_fx3m 5`, or 3-month reserve change at or below `stressed_res3m -10` percent. Otherwise
   Calm. Reserves do not enter the Crisis rule.
2. The settings override `scenario_override` can force "All crisis" (every country Crisis) or "All
   stressed" (every non-Crisis country Stressed).
3. Transition matrix (12-month, rows normalised): from Calm (0.85, 0.12, 0.03), from Stressed (0.30,
   0.55, 0.15), from Crisis (0.10, 0.30, 0.60). `transition_matrix.use true` means the multipliers
   are the expected value over the destination regime, `P[current] . multipliers`; with `use false`
   the current regime's multipliers apply directly.
4. Regime multipliers: `pd_mult` 1.0, 1.25, 1.6 and `lgd_mult` 1.0, 1.1, 1.25 for Calm, Stressed,
   Crisis; `global_loading` 0.15, 0.25, 0.35; `regional_loading 0.1` for all. Expected multipliers
   under the transition matrix are therefore `pd_mult` 1.048, 1.2275, 1.435 and `lgd_mult` 1.0195,
   1.0925, 1.18, and `p_crisis_12m` 0.03, 0.15, 0.60.
5. Global regime: Stressed if the share of countries not Calm is at least `global_stress_share 0.5`,
   else Calm. Today 8 of 18 (44 percent) are not Calm, so the global regime is Calm.
6. HMM option: `GaussianHMM` is a 3-state Gaussian hidden Markov model with diagonal covariances, EM
   (Baum-Welch) with k-means initialisation, Viterbi decoding and state relabelling by mean spread.
   `transition_matrix_12m` raises the monthly matrix to the 12th power. It is run from `econquest
   hmm --series file.csv`, and by the pipeline through `regime_hmm.hmm_regimes` when `regime.method`
   is hmm or blend (default rules: the pipeline then never fits it).

## Data

`spread`, `fx3m`, `res3m` and the `default` flag in `countries.csv`. Spreads and 3-month reserve
changes are hand-entered seed values; `fx3m` is live (Yahoo Finance in the 2026-10-23 pull; BIS WS_XRU / ECB EXR reference rates from the next pull, EQ-A-0040). Regimes today: Crisis for
Venezuela (default, 6000 bps, +20 percent), Zimbabwe (default, 3000 bps), Senegal (1200 bps);
Stressed for Pakistan (450), Belize (650), Argentina (650), Nigeria (400), Zambia (450, +8.4
percent); Calm for the other ten. No country is Stressed through the reserve rule alone. These
regimes match `workbook_reference.json` exactly (`test_regimes_match_workbook`).

There is no monthly history of spreads, depreciation and reserves in the repository.
`data/market_history/prices.csv` holds three years of daily FX and ETF prices but no spreads or
reserves; the HMM option is fitted on weekly features built from it (4-week depreciation and FX
volatility, 4-week ETF return and volatility), so its states are market-turbulence states, not the
spread-depreciation-reserves states of the rule.

## Estimation or calibration

None in the live pipeline. The thresholds and the transition matrix are the paper's values as
entered in the workbook. The HMM is tested on 600 simulated months
(`test_hmm_recovers_three_regimes`: decoding accuracy above 85 percent, `A[0,0] > 0.8`) and the CLI
demo uses 240 simulated months with a known transition matrix. No fit to real sovereign data has
been done.

## Outputs and how they are used

Per country: `regime`, `pd_mult`, `lgd_mult`, `p_crisis_12m`. Diagnostics: `global_regime`,
`degrees_of_freedom`, `share_not_calm 0.444`, per-country `loadings`.

Where each output lands: `pd_mult` scales `pd_final` and the four peril PDs; `lgd_mult` scales the
Beta haircut mean (`min(0.95, base * lgd_mult)`) and the GPD severity mean for equities; `regime`
selects the global loading and the liquidity multiplier (1, 2, 4 for Calm, Stressed, Crisis); the
global regime selects `df` and multiplies all global loadings by 1.5 when Stressed; `p_crisis_12m`
is reported only.

## Limitations and known gaps

- Three inputs, all thresholds. Two of the three inputs are hand-entered. A change in a single
  spread entry can move a country one regime and change its PD multiplier by 17 percent (1.048 to
  1.2275) and its liquidity cost by a factor of two.
- The global switch is a cliff. If one more country leaves Calm, the share reaches 0.5, `df` drops
  from 5 to 4 and every global loading rises by half. The `global_stress_share 0.4` run below shows
  the jump: VaR99 from 66.0 to 74.8 $mm (+13 percent) with no change in any PD.
  EQ-B-0042 adds an optional logistic switch (`regime.global_switch`, default `step`) and a configurable
  country set for the share (`regime.global_set`, default `all`); see section "EQ-B-0042" below.
- The transition matrix is not estimated and cannot be checked here. The 12-month matrix is used as
  if it applied to the exact horizon of the run (`horizon_months 12` is a setting but the matrix is
  never re-scaled).
- The regime enters the loss model only through multipliers and loadings; there is no
  regime-switching inside the Monte Carlo paths (the regime is fixed for the 12-month horizon on
  every path).
- `res3m` is in the Stressed rule but not the Crisis rule, so a country losing 30 percent of
  reserves in a quarter with a tight spread is only Stressed.
- The HMM uses diagonal covariances and a single series ordering (state 0 has the lowest mean
  spread); with real data the three states may not separate on spread alone.
- `scenario_override` changes the regime but not the inputs that caused it, so "All crisis" raises
  multipliers and liquidity costs while leaving spreads and PD posteriors as in the base run.

## Sensitivity

20,000 Sobol paths; production 100,000.

| Variant | VaR99 $mm | ES99 $mm | L-VaR99 $mm | Mean PD | Argentina PD | Zimbabwe PD |
|---|---|---|---|---|---|---|
| Base | 65.98 | 87.05 | 71.26 | 0.1387 | 0.119 | 0.784 |
| `transition_matrix.use false` (current-regime multipliers) | 66.28 | 86.85 | 71.56 | 0.1455 | 0.121 | 0.874 |
| `regime.Crisis.pd_mult 2.0` (from 1.6) | 66.45 | 87.44 | 71.74 | 0.1494 | 0.124 | 0.915 |
| `regime.Stressed.pd_mult 1.0` (from 1.25) | 65.50 | 86.07 | 70.79 | 0.1330 | 0.105 | 0.743 |
| From Calm row (0.95, 0.04, 0.01) | 65.53 | 86.55 | 70.81 | 0.1386 | 0.119 | 0.784 |
| From Calm row (0.70, 0.20, 0.10) | 66.17 | 87.83 | 71.45 | 0.1389 | 0.119 | 0.784 |
| `stressed_spread 300` | 65.98 | 87.05 | 71.26 | 0.1387 | no country has a spread in 300 to 400 | |
| `crisis_spread 600` (Argentina, Belize to Crisis) | 66.67 | 87.85 | 73.33 | 0.1405 | 0.139 | 0.784 |
| `global_stress_share 0.4` (global regime flips to Stressed, df 4) | 74.84 | 100.18 | 80.12 | 0.1387 | 0.119 | 0.784 |
| Override "All stressed" | 85.27 | 114.97 | 92.39 | 0.1392 | 0.119 | 0.784 |
| Override "All crisis" | 102.20 | 133.71 | 115.43 | 0.1438 | 0.139 | 0.784 |
| `regime.Crisis.lgd_mult 1.5` (from 1.25) | 66.91 | 87.81 | 72.19 | 0.1387 | 0.119 | 0.784 |

Reading: the regime layer's effect on the book comes almost entirely through the factor loadings and
the copula degrees of freedom (the global switch and the overrides), not through the PD and LGD
multipliers, which move VaR by at most 1 percent. The overrides are useful as bounding cases: with
every country in Crisis the book's ES99 is 54 percent above base.

## Benchmarks and evidence

- `test_regimes_match_workbook` and `test_transition_weighted_multipliers` (Vietnam `pd_mult` equals
  `0.85 + 0.12 * 1.25 + 0.03 * 1.6`) pass.
- `test_hmm_recovers_three_regimes` passes on simulated data with a known matrix; this is a test of
  the EM code, not of the regimes of real sovereigns.
- The econometrics toolkit (Table 5, `markov_switching` in `econometrics.py`) fits a 2-state
  Gaussian regime model to each FX pair and ETF return series using the same `GaussianHMM` class. On
  the 2026-10-22 prices the filtered probability of the turbulent state is below 0.1 for all 27
  series, consistent with the Calm global regime, but that is a daily volatility regime, not the
  spread-depreciation-reserves regime of this layer.
- No evidence exists on the transition matrix. A monthly panel of spreads and reserves for the 18
  countries (EMBI or CDS, IMF IRFCL) would allow `econquest hmm --series` to produce an empirical
  matrix.

## Open items for review

1. Decide whether the global regime should be a smooth function of the share of stressed countries
   rather than a cliff at 0.5; the cliff moves VaR by 13 percent (16 percent on release 0.1.4). Option
   built in EQ-B-0042 (`regime.global_switch logistic`), default off; decision with Sam.
2. Source `spread` and `res3m` with a vintage; they decide the regime.
3. Build the monthly history needed to estimate the transition matrix and run the HMM on real data;
   until then label the matrix as the paper's prior in every output.
4. Consider adding reserves to the Crisis rule, or document why it is excluded.
5. Consider regime switching inside the simulation horizon (a path-dependent regime) or document why
   a fixed regime over 12 months is acceptable.

## EQ-B-0036: HMM regimes as an option beside the rule regime (GOV-018, GOV-019)

The option already exists in code and is not switched on: `regime.method` `"rules"` (default), `"hmm"`
(fitted regime per country, rule regime where a country has no series) or `"blend"` (the more severe of
the two); `transition_matrix.source` `"assumptions"` (default) or `"hmm"` (fitted 12-month matrix in the
multipliers). No second key (`regime.source`) was added: it would duplicate `regime.method`. Defaults
reproduce today's numbers exactly (`test_pipeline_hmm_method_runs_and_rules_unchanged`). The fit is
deterministic (same regimes and matrix on refit) and takes about 2 seconds per run; it is not cached.

Fit (full table in `hmm-regime-report.md`): 17 countries, 2,635 country-weeks, 155 weeks from
2023-11-10 to 2026-10-23; Zimbabwe has no series and keeps the rule regime. Fitted against judgement:

| Quantity | Judgement (assumptions.json) | Fitted HMM |
|---|---|---|
| 12-month stay probability Calm / Stressed / Crisis | 0.85 / 0.55 / 0.60 | 0.46 / 0.43 / 0.18 |
| 12-month P(Crisis) from Calm / Stressed / Crisis | 0.03 / 0.15 / 0.60 | 0.11 / 0.13 / 0.18 |
| Weekly stay probability | n/a | 0.956 / 0.944 / 0.952 (half-lives 15, 12, 14 weeks) |
| Countries not Calm today | 8 of 18 (0.44) | 10 of 18 (0.56) |

Regimes that change under hmm: South Korea, India, Brazil Calm to Stressed; Colombia Calm to Crisis;
Pakistan Stressed to Crisis; Argentina and Nigeria Stressed to Calm. Agreement with the rule 58.8
percent. The fitted 12-month matrix is close to the stationary distribution in every row (the weekly
matrix to the 52nd power forgets the start state), so `transition_matrix.source hmm` makes the
multipliers nearly the same for every regime.

Book effect, production count (131,072 Sobol paths, seed 7, as_of 2026-10-23):

| Variant | VaR99 | ES99 | EL | Global regime, nu |
|---|---|---|---|---|
| Rules (default) | 63.98 | 83.02 | 0.529 | Calm, 5 |
| hmm | 80.98 (+26.6%) | 105.19 (+26.7%) | 0.622 | Stressed, 4 |
| hmm with the global regime held Calm (`global_stress_share 0.6`) | 69.35 (+8.4%) | 89.93 (+8.3%) | 0.651 | Calm, 5 |
| blend | 82.18 (+28.5%) | 106.31 (+28.1%) | 0.718 | Stressed, 4 |
| hmm + fitted matrix (32,768 paths) | 80.22 vs 64.23 | 105.41 vs 83.67 | 0.289 vs 0.534 | Stressed, 4 |
| Rules, `global_stress_share 0.4` (cliff reference) | 73.23 | 96.21 | 0.508 | Stressed, 4 |

Seeds 1 to 5 at 32,768 paths: hmm minus rules VaR99 +16.9 (sd 1.2), ES99 +22.3 (sd 0.4). Two thirds of
the hmm move is the global-regime cliff (GOV-018): 10 of 18 countries not Calm crosses 0.5, which sets
nu 4 and multiplies every global loading by 1.5; the regime changes alone add 8 percent. Largest PD
moves under hmm: Pakistan 8.6 to 10.1 percent (Crisis), Argentina 9.5 to 8.1 (Calm), Nigeria 3.9 to 3.3,
Colombia 1.1 to 1.5. With the fitted matrix Zimbabwe falls from 78.4 to 66.3 percent and EL halves,
because the fitted matrix sends Crisis countries back to Calm with probability 0.40 in a year.

Assessment: the HMM states are market-turbulence states on three years of weekly FX and ETF data, not
the spread-depreciation-reserves states of the rule, and the 12-month matrix from 155 weeks is not a
usable estimate of annual regime persistence. Recommendation: keep `rules`; publish the hmm regime as a
diagnostic next to the rule regime (it already lands in `country.regime_hmm`); do not use the fitted
matrix. Fix the global cliff (GOV-018) before any regime source is changed, since the cliff, not the
regimes, carries most of the VaR effect.

## EQ-B-0042: country set for the global share and a smooth global switch (GOV-018)

Code: `layer3_regime.global_set`, `global_share`, `global_stress_weight`, `global_regime`,
`blended_factor_loadings`, `blended_degrees_of_freedom`; tests `tests/test_layer3_regime.py`.

- `regime.global_set` (default `"all"`): the countries the share of not-Calm countries is computed over.
  `"all"` is the old rule bit for bit. A list of country names or ISO3 codes (codes resolved through
  `data/panel/universe_proposal.csv`, or `regime.global_set_proposal`), or `{"tiers": [...]}` /
  `{"exclude_tiers": [...]}` over the proposal tiers `desk_current`, `EM`, `frontier`, `DM_anchor`. List
  members not in the run are skipped; an unknown name or tier, or a set with no country of the run, raises.
  `{"exclude_tiers": ["DM_anchor"]}` keeps the seven Calm DM anchors of the 88-country universe (US, DE, GB,
  FR, IT, CA, AU) from diluting the trigger: with n countries not Calm the share is n/81 instead of n/88.
- `regime.global_switch` (default `"step"`): `"step"` gives a Stressed weight of 1 when the share reaches
  `monte_carlo.global_stress_share`, else 0 (today). `"logistic"` gives w = 1 / (1 + exp(-(share -
  threshold) / width)), `regime.global_switch_width` default 0.05, so w = 0.5 at the threshold. Layer 5
  inputs are the convex blend: loadings (1 - w) Calm table + w Stressed table (each exactly
  `factor_loadings`, so the blend stays under the cap g <= 1 - r - 0.05), nu (1 - w) nu_calm + w nu_stressed
  (fractional nu is fine in `stats.t` and `stats.chi2`). The `global_regime` label stays "Stressed" iff
  w >= 0.5, the same label as the step rule, so reports and alerts do not change meaning. No PD or LGD moves.
- Wiring needs a two-line `pipeline.py` change (proposed to AGENT-08; tests apply it by proxy and check
  the default stays bit-identical): `df` and `loadings` come from the blend helpers with
  `gweight = L3.global_stress_weight(regime, settings)`, and `global_stress_weight` / `global_share`
  join the diagnostics. `layer5_copula.py` is unchanged.

Evidence, 18-country desk book, release 0.1.4 settings (GARCH vols, estimated copula), `paths=20000`
(32,768 Sobol), seed 7, as_of 2026-10-23. Share not Calm 8/18 = 0.444.

| Variant | VaR99 $mm | ES99 $mm | EL $mm | nu | w |
|---|---|---|---|---|---|
| Before (code before EQ-B-0042) | 74.25 | 96.62 | 0.463 | 5 | n/a |
| After, defaults (`all`, `step`) | 74.25 | 96.62 | 0.463 | 5 | 0 (losses bit-identical) |
| `logistic`, width 0.05 | 77.35 (+4.2%) | 100.81 (+4.3%) | 0.455 | 4.75 | 0.25 |
| `logistic`, width 0.025 | 75.66 (+1.9%) | 98.24 | 0.463 | 4.90 | 0.10 |
| `logistic`, width 0.10 | 78.72 (+6.0%) | 102.55 | 0.446 | 4.64 | 0.36 |
| `step`, threshold 0.4 (cliff reference) | 86.01 (+15.8%) | 112.31 | 0.426 | 4 | 1 |
| `regime.method hmm`, step (share 0.556) | 94.33 | 122.16 | 0.563 | 4 | 1 |
| `regime.method hmm`, logistic 0.05 | 90.22 | 117.50 | 0.568 | 4.25 | 0.75 |

VaR99 response to `monte_carlo.global_stress_share` (step against logistic, width 0.05):

| Threshold | 0.300 | 0.350 | 0.400 | 0.425 | 0.450 | 0.475 | 0.500 | 0.550 | 0.600 |
|---|---|---|---|---|---|---|---|---|---|
| step | 86.01 | 86.01 | 86.01 | 86.01 | 74.25 | 74.25 | 74.25 | 74.25 | 74.25 |
| logistic | 85.17 | 84.67 | 83.25 | 81.61 | 79.86 | 78.52 | 77.35 | 75.73 | 74.85 |

The step moves VaR99 by 11.8 $mm between 0.425 and 0.45; the logistic moves at most 1.8 $mm per 0.025 of
threshold and converges to the step values in both tails. Runtime: the blend calls `factor_loadings` twice,
+23 ms on a warm run of about 0.6 s; nothing on the default path.

88-country universe: the staged copy (`python -m econquest.ingestion.universe stage`) cannot run the
pipeline yet: 70 of 88 countries have no rating, spread, fx3m or res3m, so `require_ready` stops the
scorecard and no regime can be computed for them. The global-set mechanism is tested on the 88 proposal
names with synthetic regime labels only; no 88-country VaR is reported. Note that `rule_regime` would label
a country with a blank spread and fx3m Calm (NaN comparisons are false), so a partly filled universe would
dilute the share further; the readiness gate is what prevents that today.

Assessment: both options are Tier 1 if switched on (the logistic moves VaR99 +4.2 percent at today's share;
`exclude_tiers` changes the trigger once DM anchors are in the run). Recommendation for Sam: adopt
`logistic` with width 0.05 together with the 88-country universe, and `exclude_tiers ["DM_anchor"]` when
the anchors enter the book, so the VaR stops jumping by 16 percent when one country changes regime; keep
`step` until then if a one-off +4 percent move at today's share is not acceptable.
