# Model validation: GPR uplift and signals; prediction-market cross-check and Kelly stakes

Date: 2026-10-23. Code: `econquest/engine/gpr.py` (`_stats`, `run_gpr`) and
`econquest/engine/layer2_bayesian.py` (`default_contract_prior`, `blend_with_market`,
`arbitrage_scan`). Data: `data/gpr_monthly.csv`, `data/prediction_markets.csv`, Country Profile
columns `gpr_series`, `gpr_analyst_410`. Parameters: `data/assumptions.json` keys `gpr` and
`prediction_markets`. Status: GPR logic ported from the workbook on real Caldara-Iacoviello data to
2026-09; prediction-market prices are illustrative placeholders, so every arbitrage number is an
illustration.

## Purpose

Two independent external cross-checks on the scorecard and the model PDs. The GPR block uses the
Caldara-Iacoviello Geopolitical Risk index (global, threats, acts and country series) to uplift
indicator 4.10 when a country's news-based geopolitical risk is unusually high, and to produce a 0
to 100 GPR signal per country and for the world. The prediction-market block converts contract
prices into probabilities, blends the sovereign-default contracts into the model PD (documented in
`bayesian-layer2.md`), prices every contract against the model and sizes a fractional-Kelly stake.

## Where it sits in the pipeline

GPR runs first in `run_pipeline`, before the scorecard, because it changes an input:
`ind.loc["4.10"] = final_410`. The GPR signal then feeds signals 22, 23 and 24 and the dashboard's
GPR read. The arbitrage scan runs after the Monte Carlo (`L2.arbitrage_scan(u, settings, country,
sc)`) and feeds signal 25, the dashboard's prediction-market read, `outputs/arbitrage.csv` and the
workbook's Prediction Markets tab.

## Assumptions

GPR (`_stats`, `run_gpr`), with `window_months 3`:

1. `recent` = mean of the last 3 months of the series; `mean5y` and `sd5y` from the last 60 months;
   `z = (recent - mean5y) / sd5y`; `percentile` = share of the last 120 months at or below `recent`;
   `momentum` = recent / mean of the 12 months before the window.
2. Uplift on the analyst's 4.10 level (`use_uplift true`): +2 if percentile at least
   `uplift2_percentile 97` and z at least `uplift2_z 2.5`; else +1 if percentile at least
   `uplift1_percentile 90` or z at least `uplift1_z 1.5`; capped at level 4.
3. GPR signal = `signal_weight_percentile 0.5` x percentile + 0.5 x clip(50 + 25 z, 0, 100),
   rounded. Same formula for the global GPR series; the global block also reports the
   threats-to-acts ratio GPRT / GPRA over the window.
4. Countries without a `gpr_series` column (Singapore, Pakistan, Belize, Nigeria, Senegal, Zambia,
   Zimbabwe) get no uplift and a signal of 0.

Prediction markets (`prediction_markets`):

5. Contract probability over its horizon: for sovereign-default contracts `p12 = country.pd_model`
   (the regime-adjusted posterior before the market prior, to avoid using the contract to price
   itself), for the other drivers a logistic curve on the mapped indicator or pillar score,
   `logistic_curve(score, signal_base_prob 0.1, signal_slope 0.5)` = `expit(logit(0.1) + 0.5 (score
   - 50) / 10)`; converted to the contract horizon by `to_horizon` (constant hazard). `DRIVER_MAP`
   sends "Sanctions" to `pd_sa`, "Political instability" to pillar 4, "Devaluation pressure" to
   pillar 2, GPR spikes and "Sanctions and geopolitics" to indicator 4.10, "Official backstop
   stress" to 2.6, "Inflation pressure" to 5.5, "Growth slowdown" to 5.6, "Climate and disaster" to
   pillar 7, "Security and violence" to pillar 6.
6. Side: Buy Yes if the model probability exceeds the price, else Buy No. Gross edge = |p - price| x
   100; net edge = gross minus `round_trip_cost_pp 3`.
7. Kelly fraction on the chosen side with net odds `b = (1 - cost) / cost`: `kelly = max(0,
   (win_prob b - (1 - win_prob)) / b)`; stake = `min(kelly x kelly_fraction 0.25 x bankroll_k 500,
   max_share_oi 0.2 x open interest)`, rounded, only if net edge at least `min_net_edge_pp 10` and
   open interest at least `min_oi_k 20`. `divergence_flag` when the gap is at least
   `divergence_flag_pp 15`.
8. Default-contract prior for Layer 2: `to_12m(price, months)`, open-interest weighting, `tau_market
   = tau_market_max 1 x min(1, oi / reference_oi_k 500)`.

## Data

- `gpr_monthly.csv`: 249 months (2006-01 to 2026-09), columns GPR, GPRT, GPRA and 11 country series
  (ARG, BRA, CHN, COL, IND, JPN, KOR, MYS, PHL, VEN, VNM). This is published data from
  matteoiacoviello.com; the file carries no retrieval date and is not part of the live fetch. Latest
  month 2026-09; GPR recent 146.6 vs 5-year mean 144.5, z 0.04, percentile 85, momentum 0.86,
  threats/acts 1.11, global signal 68.
- `prediction_markets.csv`: 18 contracts (14 Polymarket, 4 Kalshi), resolution dates 2026-12-31 to
  2027-12-31, prices 0.08 to 0.45, open interest 25k to 1,200k. The README states the prices are
  illustrative placeholders. `--live-markets` would call the Polymarket Gamma and Kalshi v2
  adapters, but the file has no `slug` or `ticker` column, so live prices cannot be fetched yet.

## Estimation or calibration

None. The uplift thresholds, signal weights, the logistic peril curve (10 percent at a score of 50,
times about 1.65 per 10 points) and the Kelly parameters are judgement. The constant-hazard horizon
conversion is a convention.

## Outputs and how they are used

GPR, base run: no country receives an uplift today (all `uplift 0`, `final_410 = analyst_410`); the
highest z is the Philippines at 1.04 (percentile 88, signal 82), then Argentina 0.47 (percentile 82,
signal 72), Venezuela (86, 69), India (81, 68), China (79, 67), Vietnam (78, 66). The
`gpr_uplift_off` run therefore reproduces the base run exactly. The dashboard reads "GPR hotter than
the composite score" for eight covered countries because their GPR signals exceed their composites by 27 to 45
points.

Arbitrage, base run (horizons from 2026-10-23): 11 of 18 contracts clear the 10-point net edge and
the 20k open-interest floor and receive a stake; total stake 358k against a 500k bankroll; 9
divergence flags. Largest stakes: Venezuela political instability PM02 80k (model 5.9 vs price 22,
Buy No), China tariffs PM04 60k (13.2 vs 45, Buy No), Argentina devaluation PM18 44k (20.9 vs 35,
Buy No), Japan growth PM13 40k (53.0 vs 25, Buy Yes), China Taiwan PM05 33k (32.2 vs 8, Buy Yes,
expected profit 87k). Sovereign-default contracts: Argentina PM01 Buy No with net edge 4.1 (no
stake), Pakistan PM08 and Zambia PM11 negative net edge, Senegal PM10 Buy No with net edge 22 and a
9k stake (model 14.8 vs price 40 over 8.2 months).

## Limitations and known gaps

- Every arbitrage output is built on placeholder prices. The 358k of stakes, the 217k of "expected
  profit" and the 9 divergence flags describe the model's disagreement with numbers an analyst
  typed, not with a market.
- The run-date dependence: contract months are computed from `pd.Timestamp.today()`, so
  `model_p_res`, edges and stakes change daily with no change in data or code. Argentina PM01 has
  14.2 months to resolution today; in three months the same price will imply a different 12-month
  probability.
- Non-default contracts are priced by a logistic curve on a score. The China Taiwan contract (PM05)
  is priced from indicator 4.10 at level 3 (score 75), giving 27.9 percent over 12 months and 32
  percent to resolution, against a market price of 8 percent; the same curve gives every contract
  mapped to 4.10 the same 27.9 percent for every country at level 3 (China, India, Pakistan). The
  curve has not been calibrated to any event frequency.
- The contract wording and the model peril differ (the playbook warns of this in T26). "Maduro
  ceases to be president" is priced off pillar 4; "IMF review delayed" off indicator 2.6; "IPCA
  above 5 percent" off the inflation score. None of these is a probability the model was built to
  produce.
- Kelly sizing assumes the model probability is right. A 25 percent fraction and the open-interest
  cap limit the damage but the sizing has no uncertainty on `p`.
- GPR covers 11 of the 18 countries. Six frontier names (Pakistan, Nigeria, Senegal, Zambia,
  Zimbabwe, Belize) and Singapore have no series, so the GPR signal and uplift are structurally zero
  for the countries with the highest default risk.
- The GPR uplift adds integer levels to a 0 to 4 indicator with weight 0.05 in pillar 4; even a +2
  uplift moves pillar 4 by at most 2.5 points and the composite by 0.4.
- The 120-month percentile and 60-month z use the series as stored; no vintage control, and the file
  is not refreshed by `fetch`.

## Sensitivity

GPR: `gpr.window_months 6` instead of 3 changes `final_410` for no country and moves the mean PD
from 0.1387 to 0.1386 (20,000 paths, VaR99 unchanged at 65.98 $mm). `use_uplift false` reproduces
the base exactly because no uplift is active. The uplift and signal thresholds were not swept
further because they do not bind on current data; a reviewer should test them on a month with a
spike (for example 2022-03 or 2025 episodes in the file).

Prediction markets, Kelly sizing (2,000 paths; stakes do not depend on the paths). Number of
contracts staked, total stake and sum of `expected_profit_k`:

| `kelly_fraction` \ `min_net_edge_pp` | 5 | 10 (base) | 15 |
|---|---|---|---|
| 0.10 | 14 staked, 258k, 124k | 11, 225k, 119k | 8, 156k, 107k |
| 0.25 (base) | 14, 407k, 223k | 11, 358k, 217k | 8, 222k, 194k |
| 0.50 | 14, 440k, 311k | 11, 391k, 304k | 8, 255k, 281k |

The open-interest cap (20 percent) binds on most contracts, which is why doubling the Kelly fraction
adds only 9 percent to the total stake.

Effect of the default-contract prior on the model PD (from `bayesian-layer2.md`): `use_market_prior
false` lowers Argentina's `pd_default` from 11.9 to 9.3 percent and Senegal's from 23.9 to 21.0;
`tau_market_max 3` raises them to 14.4 and 29.2; `reference_oi_k 100` to 13.4 and 33.7. VaR99 moves
by less than 0.4 percent in all three.

## Benchmarks and evidence

- `test_arbitrage_sizing_rules` checks the sizing constraints (no stake below the edge floor, stake
  within the open-interest cap, valid sides); it passes.
- GPR: the data are real and public (Caldara and Iacoviello, 2022, American Economic Review). The
  GARCH layer's Table F fits a GARCH(1,1)-t to the monthly log changes of each GPR series: the
  global GPR has alpha 0.23, beta 0, long-run monthly volatility 20.5 percent and conditional
  volatility 22.5 percent, with an ARCH-LM p-value of 0.18 on returns, so there is little evidence
  of volatility clustering in the global series at monthly frequency; several country series (ARG,
  IND, JPN, VNM) have degenerate Student-t fits (`nu` above 1e6, that is Gaussian) and the country
  series are noisy (long-run volatility 35 to 97 percent per month).
- Prediction markets: no benchmark is possible until live prices and resolutions are recorded.
  Roadmap item 2.6 (Brier scores of model vs market vs rating PDs) is the intended evidence, and
  item 3.5 (text pipeline) the intended replacement for the inert text index.
- Internal consistency: the model-minus-market gaps are large and one-directional for the GPR-driven
  contracts (model above the market for Taiwan, below for the Philippines-China incident), which
  points at the logistic curve rather than at the markets.

## Open items for review

1. Replace the placeholder prices with live Polymarket and Kalshi quotes (add `slug` and `ticker`
   columns) or mark the Prediction Markets tab as illustrative in the workbook note.
2. Fix the run-date dependence by recording an as-of date in the run and using it for horizons.
3. Calibrate or at least sanity-check the logistic peril curve (10 percent at score 50, slope 0.5
   per 10 points) against event frequencies; today it prices geopolitical, inflation and growth
   contracts alike.
4. Decide whether GPR coverage gaps should be filled with a regional GPR proxy for the seven
   uncovered countries.
5. Add the GPR file to the fetch and vintage process with a retrieval date.
6. Store resolutions of the contracts as they happen and compute Brier scores for the model, the
   market and the rating prior (roadmap 2.6).
