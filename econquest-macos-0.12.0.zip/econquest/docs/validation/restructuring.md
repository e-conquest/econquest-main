# Restructuring scenarios: haircut model, NPV loss per bond, path stress

Date: 2026-10-25. Ticket EQ-B-0090 (AGENT-02). Code: `econquest/engine/restructuring.py` (`fit_haircut_model`,
`crag_default_duration`, `restructuring_npv`, `path_for_haircut`, `restructuring_table`, `stressed_positions`,
`rerun_layer6`, `run_restructuring_stress`). Tests: `tests/test_restructuring.py`. Parameter keys: none in
`data/assumptions.json`; every constant is a module constant (listed in section 3). Status: research tool,
off by default. `run_pipeline` does not call it, and the base run is bit-identical (section 9).

## 1. Purpose

Layer 4 gives a defaulted Eurobond a loss of `market.lgd_hard` (60%) times the regime LGD multiplier plus
the Merton uplift, capped at 95%. That is one number per name with no link to how sovereign defaults
actually end. Most end in a bond exchange: a face cut, a coupon cut and a maturity extension, valued at an
exit yield. This module:

1. predicts a market haircut for a name from a few drivers, calibrated on published restructurings;
2. turns the haircut into an explicit restructuring path and values a bond through it (NPV loss vs par
   and vs today's market price);
3. for the riskiest names in the base run, books the restructuring loss in place of the model's default
   loss and reports the book loss per name, the total, and the Layer 6 tail metrics with that severity.

## 2. Where it sits

Standalone. It reads the base run and changes nothing in it.

```
python -m econquest.engine.restructuring --as-of 2026-10-23 [--names auto|ARG,PAK,...] [--top 5]
       [--paths 20000] [--exit-yield 0.10] [--imf ARG:1,PAK:1] [--no-mc] [--write] [--out outputs/...]
```

`--write` saves `restructuring.json` in `outputs/restructuring/<as_of>/`; `--out` picks another folder under
outputs/ and anything else is refused.

Steps: `run_pipeline(u, s, paths, as_of)` -> names by `pd_default` -> `fit_haircut_model` on the reference
table up to the as-of year -> CRAG delay -> per position `bond_from_position`, `path_for_haircut`,
`restructuring_npv` -> per-name totals -> `stressed_positions` + `rerun_layer6` (Layer 6 on the base run's
inputs, same Sobol paths and PDs, only the default severity of the selected Eurobond and CDS positions
replaced).

`--names auto` takes the top `--top` names by `pd_default` among names that hold a Eurobond or CDS
protection position; a higher-PD name without one (today Zimbabwe, equity only) is listed as skipped.
FX, local bond and equity positions of the selected names keep the model's loss.

No stress.py hook is needed. The runner re-simulates Layer 6 directly.

## 3. Assumptions

Haircut model (shares of the old claim):

    h = a + b_debt x (debt/GDP - 90)/10 + b_imf x IMF + reserves add-on + rating add-on,   clipped to [5%, 95%]
    low / high = h -/+ max(weighted residual sd, 8 pp)

* `debt/GDP` is indicator 1.3 for the name. `IMF` is the programme flag; for current names it is unknown
  unless given with `--imf`, and then the table's weighted share (0.80) is used.
* Reserves add-on (judgement): +1 pp per 10 points of usable reserves (indicator 2.1, % of IMF ARA) below
  100, capped at +/-5 pp.
* Rating add-on (judgement, pp): SD/D +5, CC/C +4, CCC +2, B 0, BB -3, BBB- and above -5.

Path and pricing (judgement, recent practice):

| constant | value | meaning |
|---|---|---|
| `EXIT_YIELD` | 10% | exit yield; the rate at which recent haircuts are usually quoted |
| `BASE_RATE` | 4% | USD risk-free level; a constant, not market data |
| `ISSUE_SPREAD_CAP_BP` | 600 | assumed coupon = 4% + min(spread, 600 bp) (bonds were issued at tighter spreads) |
| `PDI_SHARE` | 0.5 | share of past-due coupons capitalised into the new claim |
| `PATH_SHAPE` | face 60%, coupon 70%, +10 years at intensity 1 | the path is scaled linearly by one intensity |
| `CRAG_SINCE` | 2000 | CRAG bond-default spells used for the delay |

The portfolio has notional and duration only. A bond's coupon is the assumed issue coupon and its maturity
is the one whose modified duration at that coupon equals `duration_yrs`. Its market price today is at
4% + spread. Optional portfolio columns `coupon_pct` and `maturity_yrs` would replace both assumptions
(Team A owns `data/portfolio.csv`; no change requested).

Definitions (face 100, annual compounding, semi-annual coupons):

* old claim at exit = past-due coupons and principal at face + remaining flows discounted at the exit yield;
* new bond = (1 - face cut) x (100 + PDI share x past-due coupons), coupon x (1 - coupon cut), final
  maturity = remaining old maturity + extension, bullet (amortisation is an option);
* SZ haircut = 1 - PV(new) / PV(old claim) (Sturzenegger-Zettelmeyer);
* market haircut = 1 - PV(new) / 100 (Cruces-Trebesch H_M);
* value today = PV(new) / 1.10^delay; loss vs par = 100 - value today; loss vs market = price today - value today.

The predicted haircut is read as the SZ haircut. `path_for_haircut` solves for the intensity that gives it.
The loss booked in the stress is loss vs par at the default date, the same basis as the model's LGD.

## 4. Data

* **CRAG** (`data/panel/sovereign_defaults_crag.csv`, BoC-BoE 2026, 210 spells, 99 countries, Team A
  EQ-A-0008). Columns: iso, country, start, end, creditors, note (peak amount in default), source. **It has
  no haircut or recovery data.** It is used for the time in default only.
* **Reference table** (`REFERENCE_RESTRUCTURINGS` in the module; `data/` is Team A's, so it is a module
  constant). The runner's console header and JSON label say: reference haircuts typed from memory, UNVERIFIED
  until the Cruces-Trebesch dataset replaces them (GOV-024). Each row has an approximate settlement month
  (`settled`); a row is used only when the last day of that month is on or before as_of. 17 bond exchanges with a market haircut range. The figures were typed in from the literature
  as remembered. **They were not checked against the sources in this environment (no network).** That is
  why each row is a range with a confidence flag. Debt/GDP is approximate, rounded to 5 points.

| country | year | haircut range | face cut | debt/GDP (approx.) | IMF | delay (y) | confidence | source |
|---|---|---|---|---|---|---|---|---|
| Argentina | 2020 | 40-55% | ~2% | 90 | no | 0.4 | medium | FST21; MoF |
| Ecuador | 2020 | 25-40% | ~9% | 60 | yes | 0.2 | medium | FST21; MoF |
| Zambia | 2024 | 30-50% | ~18% | 125 | yes | 3.6 | low | MoF; IMF |
| Sri Lanka | 2024 | 30-45% | ~27% | 115 | yes | 2.7 | medium | MoF; IMF |
| Ghana | 2024 | 35-50% | ~37% | 90 | yes | 1.8 | medium | MoF; IMF |
| Ukraine | 2024 | 30-45% | ~37% | 85 | yes | 2.1 | low | MoF; IMF |
| Ukraine | 2015 | 20-30% | 20% | 70 | yes | 0 | medium | FST21; MoF |
| Greece | 2012 | 60-70% | 53.5% | 165 | yes | 0 | high | ZTG13; CT13 |
| Argentina | 2005 | 70-80% | n/a | 140 | yes | 3.3 | medium | SZ08; CT13 |
| Ecuador | 2000 | 30-45% | n/a | 95 | yes | 0.9 | medium | SZ08; CT13 |
| Uruguay | 2003 | 5-20% | 0 | 90 | yes | 0 | medium | SZ08; CT13 |
| Russia | 2000 | 45-60% | n/a | 90 | yes | 1.5 | low | SZ08; CT13 |
| Pakistan | 1999 | 10-25% | 0 | 80 | yes | 0.3 | low | SZ08; CT13 |
| Belize | 2007 | 20-30% | n/a | 90 | no | 0 | medium | CT13 |
| Belize | 2021 | 40-50% | ~45% | 125 | no | 0.3 | medium | MoF (buyback at 55 cents) |
| Jamaica | 2010 | 10-20% | 0 | 140 | yes | 0 | medium | CT13 |
| Cote d'Ivoire | 2010 | 50-60% | n/a | 65 | yes | 10 | low | CT13 |

Sources:
* CT13: Cruces, J. and Trebesch, C. (2013), "Sovereign Defaults: The Price of Haircuts", *American Economic
  Journal: Macroeconomics* 5(3), 85-117.
* SZ08: Sturzenegger, F. and Zettelmeyer, J. (2008), "Haircuts: Estimating investor losses in sovereign debt
  restructurings, 1998-2005", *Journal of International Money and Finance* 27(5), 780-805.
* ZTG13: Zettelmeyer, J., Trebesch, C. and Gulati, M. (2013), "The Greek debt restructuring: an autopsy",
  *Economic Policy* 28(75), 513-563.
* FST21: Fang, C., Schumacher, J. and Trebesch, C. (2021), "Restructuring Sovereign Bonds: Holdouts, Haircuts
  and the Effectiveness of CACs", *IMF Economic Review* 69, 155-196.
* MoF / IMF: the debtor's exchange announcements and offer documents, and IMF programme reviews (DSA annexes).

When the Cruces-Trebesch dataset is downloaded (GOV-024, `layer4_severity.load_haircuts`), it should replace
this table. The fit function takes any frame with `haircut_mid`, `debt_gdp`, `imf` and `confidence`.

### Cruces-Trebesch refit path (EQ-B-0099, built; waiting on the data)

Team A is importing the Cruces-Trebesch haircut dataset under EQ-A-0098. As of 2026-10-25 it is not in the
repository, so every number in this document still comes from the typed-in table and stays labelled UNVERIFIED.
The refit is ready and switches on by itself when the file appears:

* `load_ct_haircuts(path)` reads CSV or XLSX. Column names follow `layer4_severity.HAIRCUT_COLUMNS` plus
  `CT_EXTRA_COLUMNS` (ISO3, settlement date or year + month, debt/GDP, IMF flag, face value reduction, debt type).
  A row with only a year counts from 31 December of that year. Haircuts above 1 are read as percent.
* `haircut_source` uses `<data>/panel/cruces_trebesch_haircuts.csv` (or `--haircut-file`) when it exists, keeping
  rows settled on or before as_of. Debt/GDP comes from the file, else `panel/hazard_panel.csv` at the year before
  the exchange (15 countries only), else the row is left out of the fit. The IMF term is fitted only when the file
  has a flag; otherwise it is dropped.
* The typed-in table is the fallback only. The runner falls back to it, labelled UNVERIFIED with the reason, when
  the file is missing, rejected (a haircut outside [-100, 100], or debt/GDP below 5, which looks like a share), or
  leaves fewer than 3 rows with debt/GDP settled on or before as_of. The run does not abort.
* The calibration counts as verified only when all three checks pass: the file name does not say "synthetic"; the
  licence register (data/licences.csv) has the `cruces_trebesch_haircuts` row matching the file's path with
  internal_use "yes"; and a `cruces_trebesch_haircuts.provenance.json` sidecar holds a sha256 equal to the file's.
  Rows and debt/GDP are not checked against the published paper; the checks only tie the figures to a registered,
  hashed file. The label states the rows used, the rows dropped for missing debt/GDP and the register's licence
  terms status (UNVERIFIED today: no terms found, client output restricted). A failed check is named in the label.
* `compare_with_ct` uses only CT rows settled on or before as_of.
* `compare_with_ct` lists each typed-in row against CT (same ISO3, year within one): match (CT SZ haircut inside
  the typed range), mismatch (with the gap in pp) or missing. The runner prints the counts and puts the full
  table in the JSON.
* Tests use a SYNTHETIC CT-style file (invented numbers). They cover the loader, the as-of filter by settlement
  date, the debt/GDP lookup, the fit without an IMF column, the comparison statuses and the labels. The fit on
  the typed-in table is unchanged.

## 5. Estimation and calibration

**Haircut.** Weighted least squares of the range midpoint on (debt/GDP - 90)/10 and the IMF flag. Weights
are by confidence: high 1.0, medium 0.6, low 0.3. Only rows up to the as-of year are used. As of 2026-10-23
(n = 17):

| term | estimate | s.e. |
|---|---|---|
| intercept (debt 90, no IMF) | 0.358 | 0.093 |
| per 10 pp debt/GDP | +0.028 | 0.013 |
| IMF programme | -0.005 | 0.102 |
| weighted residual sd | 0.167 | |

Debt/GDP has the expected sign (t about 2.2). The IMF term is noise: the table has three no-IMF rows. It is
kept because the ticket asks for it, but it moves nothing. The residual sd (17 pp) is the honest width of
the model, and it sets the low/high band.

**Delay.** CRAG spells with bonds in default, starting 2000 to the as-of year: 48 spells, 38 completed,
10 open at the last data year (2025) and treated as censored. A spell start..end counts as end - start +
0.5 years. Completed median 1.5 years (IQR 0.5-3.25). Kaplan-Meier median 1.5 years, which is used. From
1990 the KM median is 2.5 years (58 spells). CRAG counts a spell open while any bond debt is in default,
holdouts included (Argentina 2001-2025, Ecuador 2008-2025), so long spells overstate the time to the main
exchange. The reference table's delays have median 0.4 years and mean 1.6 years (five pre-emptive exchanges at 0).

**Path.** Not fitted. One intensity scales face cut, coupon cut and extension together. Recent deals mix
these very differently: Argentina 2020 had almost no face cut, Ghana and Ukraine 2024 about 37%.

## 6. Outputs today (as_of 2026-10-23, 100,000 paths; a stress result, not a base number)

Haircut and path per bond (delay 1.5 years, exit yield 10%):

| name | position | PD | model LGD | SZ haircut | face / coupon cut / ext. | value today | loss vs par | loss vs market |
|---|---|---|---|---|---|---|---|---|
| Venezuela | P17 Eurobond 5 | 0.990 | 95% | 62% | 36% / 42% / 6.0y | 39.0 | 61.0 | -18.3 (price 20.8) |
| Senegal | P20 Eurobond 8 | 0.133 | 95% | 47% | 29% / 34% / 4.8y | 54.1 | 45.9 | 23.9 |
| Pakistan | P10 Eurobond 10 | 0.080 | 93% | 35% | 21% / 24% / 3.5y | 63.5 | 36.5 | 38.9 |
| Argentina | P14 Eurobond 15 | 0.066 | 95% | 35% | 18% / 21% / 3.0y | 68.0 | 32.0 | 33.9 |
| Argentina | P15 CDS protection 10 | 0.066 | 95% | 35% | (reference bond) | 67.0 | 33.0 | 33.7 |
| Belize | P11 Eurobond 5 | 0.049 | 66% | 32% | 18% / 21% / 3.1y | 69.6 | 30.4 | 32.0 |

Book loss if the name restructures (US$ mm; CDS protection is a gain, so negative):

| name | notional | model default loss | restructuring loss (central) | low | high |
|---|---|---|---|---|---|
| Venezuela | 5 | 4.75 | 3.05 | 2.18 | 3.92 |
| Senegal | 8 | 7.60 | 3.67 | 2.30 | 5.04 |
| Pakistan | 10 | 9.31 | 3.65 | 2.03 | 5.28 |
| Argentina (bond 15, CDS 10) | 25 | 4.75 | 1.50 | 0.61 | 2.40 |
| Belize | 5 | 3.28 | 1.52 | 0.66 | 2.38 |
| **Total** | 53 | **29.69** | **13.40** | **7.77** | **19.02** |

Against today's market prices the restructuring loss is 8.20 (Venezuela's bond trades below its
restructured value, a gain of 0.91).

Layer 6 with the restructuring severity for these six positions (100,000 requested, as_of 2026-10-23):

| metric | base (0.5.0) | restructuring severity |
|---|---|---|
| VaR99 | 58.19 | 48.59 |
| ES99 | 78.72 | 67.68 |
| EL | 0.88 | -2.08 |
| L-VaR99 | 63.47 | 53.87 |

Why EL turns negative (not a sign error). The change in EL, -2.96, equals the sum over the six positions of
PD x (restructuring loss - model default loss): Venezuela 0.99 x (3.05 - 4.75) = -1.68, Senegal -0.52, Pakistan
-0.46, Argentina -0.21, Belize -0.09. It goes below zero because Layer 6 credits a full year of spread income
(`carry_mm`, `layer6_montecarlo.build_positions`) on every path, default paths included. Venezuela alone carries
6,000 bp on 5 $mm, about 3.0 $mm of income, at PD 0.99. With the model LGD its default loss (4.70) outweighs that
income; with the restructured value (39, above its market price of 20.8) the default loss (3.02) about cancels
it. The rest of the book already has carry above expected loss (base EL without Venezuela is -0.82).

| EL ($mm, 100k) | base | restructuring severity |
|---|---|---|
| as simulated | 0.88 | -2.08 |
| without spread income on each position's default paths | 4.09 | 1.12 |
| with Venezuela's position left out | -0.82 | -2.10 |

The second row (`el_breakdown`) is the like-for-like credit view. On it the restructuring severity lowers EL by
2.96, the same amount, but EL stays positive. Whether Layer 6 should credit a year of carry on default paths is a
Layer 6 question, outside this ticket (open item 5).

Reading: for these names the model's LGD sits at or near the 95% cap. It is 60% x the regime multiplier
(1.09-1.18) plus a Merton uplift of up to 0.73. Published recent exchanges imply a loss vs par of about
30-60%, with the high band at 50-78%. On these terms the model's default loss is about twice the
restructuring loss, and even the high band (19.0) is below it (29.7). The model is conservative here. That
is not a reason to change it: the comparison rests on a typed-in table and judgement path terms (sections
4 and 7). Any change to `market.lgd_hard` or the Merton uplift is Tier 1 and goes to Sam.

## 7. Limitations

1. The reference figures are from memory of the literature and were not checked against the sources here.
   They are ranges, and some (Zambia, Ukraine 2024, Russia, Pakistan, Cote d'Ivoire) are low confidence.
2. 17 rows and two fitted drivers. Residual sd 17 pp. The IMF term is not identified.
3. Reserves and rating add-ons are judgement, not fitted.
4. Coupon and maturity are inferred from duration and spread with assumed rules. A distressed bond's real
   coupon and maturity can differ a lot.
5. One path shape for every name. Real deals differ in mix (face vs coupon vs maturity), state-contingent
   instruments (GDP warrants, VRIs) and PDI treatment.
6. CDS protection is valued as par minus the restructured value of a reference bond. Auction, deliverable
   and succession effects are ignored.
7. The CRAG delay includes holdout tails and is in calendar years. The exit yield (10%) and base rate (4%)
   are constants.
8. Only Eurobond and CDS positions are restructured. Local-currency debt restructurings (in CRAG, e.g.
   Ghana 2023) are out of scope; local bonds keep `market.lgd_local`.
9. The Layer 6 re-run keeps the base PDs. This is "default ends in this exchange", not a PD stress.

## 8. Sensitivity (computed, as_of 2026-10-23, Layer 6 not re-run)

| change | total restructuring loss (central / low / high) |
|---|---|
| exit yield 8% | 11.21 / 4.93 / 17.49 |
| exit yield 10% (central) | 13.40 / 7.77 / 19.02 |
| exit yield 12% | 15.24 / 10.17 / 20.32 |

With a fixed SZ haircut, a higher exit yield lowers the value of the new bond and of the delay, so the loss
vs par rises. Inferred, not run: a longer delay (2.5 years, the CRAG KM median from 1990) raises the loss
through discounting and unpaid PDI; PDI share 1.0 lowers it.

## 9. Evidence

* `tests/test_restructuring.py` (41 tests, 14 of them for the Cruces-Trebesch path on SYNTHETIC files). Synthetic fixtures for the fit (exact slope recovery), the
  Kaplan-Meier median, the CRAG as-of truncation, bond arithmetic (par price, duration round trip), the
  NPV identities (identity path: SZ 0; face cut at par: SZ = face cut; delay with full PDI: SZ 0; no PDI:
  SZ = arrears / (100 + arrears)), path monotonicity and target hit, name selection, the position table and
  the severity replacement. On repository data: the CRAG file has no haircut column, and
  `rerun_layer6` with unchanged positions reproduces the base run exactly (2,048 paths). Review fixes: the
  reference table is filtered by settlement month (an exchange later in the as-of month or year is left out);
  `--out` is refused outside outputs/ (`activation.resolve_out_dir`); the console header and the JSON label say the
  reference haircuts are unverified; `el_breakdown` removes carry on default paths exactly for bond income.
* Base unchanged: 20,000-path check before and after, VaR99 58.29825662621968, ES99 79.27208399332699,
  EL 0.8781214705231672, L-VaR99 63.57976245293203 (identical to the reference). The 100,000-path base from
  the runner is 58.19 / 78.72 / 0.88 / 63.47. Replication PASS 133, FAIL 0.
* `pipeline.py` does not import the module (tested).

## 10. Open items

1. When Team A lands the Cruces-Trebesch file (EQ-A-0098), refit, review the `compare_with_ct` mismatches, rerun
   the 100k headline and update this document (EQ-B-0099). The code path is built and tested on synthetic data.
2. Ask Team A for `coupon_pct` and `maturity_yrs` in `data/portfolio.csv` so bonds are not inferred from
   duration.
3. Fit the delay on months, not calendar years, once a dated exchange list exists. Separate holdout tails
   from the main exchange.
4. Decide (Sam, Tier 1) whether the Layer 4 LGD for distressed names should move toward the restructuring
   evidence. The Merton uplift takes most of them to the 95% cap.
5. Layer 6 credits a full year of spread income on default paths (`carry_mm` on every path). For a name at
   6,000 bp and PD 0.99 that is about 3 $mm on 5 $mm. Review whether carry should stop at default.
6. Add a local-currency restructuring path (Ghana 2023, Sri Lanka 2023 domestic) if local bonds of
   high-PD names enter the book.
