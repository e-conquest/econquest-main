# Model validation: shadow sovereign ratings

Date: 2026-10-24. Ticket: EQ-B-0081. Code: `econquest/engine/shadow_ratings.py`. Tests:
`tests/test_shadow_ratings.py`. Outputs: `outputs/shadow_ratings.csv` and `.md`. Status: analytics for the country
notes. Nothing here feeds a PD, a loss, a limit or a signal. Off the pipeline: it reads archived runs.

## What it does

For each desk name it puts a rating on the model's 1-year PD and compares it with the agency rating.

1. **PD-implied (shadow) rating.** `pd_default` (the PD the Monte Carlo uses) and `pd_model` (the posterior before
   the prediction-market prior) are both mapped to the S&P scale through `ratings_pd`, the same PD-by-rating table
   layer 1's `RatingChallenger` uses. `pd_hazard_l1` (the hazard alone) is mapped too, for information.
2. **Scorecard-implied rating.** Least squares of the agency notch on the composite score, predicted leave-one-out.
3. **Gap and flags.** `gap_notches = shadow notch - agency notch`. Positive means the shadow is worse than the
   agency. Gap of +2 or more: `downgrade_risk`. Gap of -2 or less: `upgrade_candidate`.
   `flag_confirmed_by_pd_model` says whether the `pd_model` shadow passes the same test. A name the agency rates
   SD or D is never flagged (flag `none`, not confirmed): its rating is a default event, so a lower PD is not an
   upgrade call.
4. **Momentum.** Shadow notch now minus the shadow notch in the earliest archived base run whose as_of is in
   `[D - 90 days, D]`. +1 or more: `momentum_down`; -1 or less: `momentum_up`. `momentum_cause` says whether
   settings, data or code differ between the two runs.
5. **Migration.** Count matrices of shadow ratings between consecutive archived runs, and between the last run of
   each as_of date. A reference long-run agency 1-year transition matrix is shown beside them.

## Notch boundaries

Ratings are ordered by their `ratings_pd` value. `D` has the same PD as `SD` (0.60) and is dropped, so the scale
is AAA ... CC, SD: 21 notches, index 0 (AAA) to 20 (SD). The boundary between adjacent notches is the geometric
midpoint of their table PDs, `sqrt(pd_k * pd_k+1)`, the midpoint in log-PD. A PD exactly on a boundary takes the
worse notch. SD is open-ended above `sqrt(0.35 * 0.60) = 0.458`; a shadow SD means a default-level PD, not a
default event. An agency `D` is placed on the SD notch.

| Notch | Rating | Table PD | PD from | PD below |
|---|---|---|---|---|
| 0 | AAA | 0.0001 | 0 | 0.00014 |
| 3 | AA- | 0.0004 | 0.00035 | 0.00045 |
| 6 | A- | 0.0009 | 0.00079 | 0.00108 |
| 9 | BBB- | 0.0028 | 0.00231 | 0.00343 |
| 12 | BB- | 0.0100 | 0.00806 | 0.01342 |
| 15 | B- | 0.0500 | 0.0387 | 0.0775 |
| 19 | CC | 0.35 | 0.307 | 0.458 |
| 20 | SD | 0.60 | 0.458 | none |

The full 21-row table is in `outputs/shadow_ratings.md` and `boundaries_table()`.

The table is steep at the top: from AAA to A- each notch is 1 to 2 basis points of PD. A few basis points of
model PD move an investment-grade name by a notch. Below BB the notches are wide.

## Scorecard-implied rating

Method: ordinary least squares of agency notch on composite score, on the names not rated SD or D (16 today).
Each name's value is predicted from a fit that leaves that name out. SD/D names are predicted from the fit on
the others (their composites carry override floors). The result is rounded and clipped to AAA ... CC, so the
scorecard never gives SD.

Today: slope 0.338 notches per composite point, R2 0.78, leave-one-out RMSE 2.8 notches. Two parameters on 16
points is a rough ordering, nothing more. An error of about 3 notches is typical, so a scorecard gap of 2 is not
a signal. No flag uses the scorecard rating. An ordered logit was not used: with up to 16 categories and 16
names it cannot be estimated sensibly.

## Why the gaps are damped

The shadow PD is not independent of the agency rating:

- layer 1 reconciles the hazard with the rating-implied PD 50/50 in log-odds (`layer1.hazard_weight 0.5`);
- the hazard is calibrated to the rating prior (`calibrate_to rating_prior_location_scale`).

So about half of the shadow PD is the agency rating itself. A 2-notch gap is a strong disagreement. The same
calibration compresses the hazard toward the middle of the scale (every non-default name has `pd_hazard_l1`
between 0.1 and 1.7 percent today), which pushes high-grade names down and low-grade names up.

## Today's result (as_of 2026-10-23, run 20261024T150359-base)

Names with a gap of 2 or more notches (all `downgrade_risk`, all confirmed by `pd_model`, which equals
`pd_default` today because no default contract moves the market prior):

| Country | Agency | pd_default | Shadow | Gap |
|---|---|---|---|---|
| China | A+ | 0.28% | BBB- | +5 |
| Philippines | BBB+ | 0.36% | BB+ | +3 |
| Singapore | AAA | 0.04% | AA- | +3 |
| South Korea | AA | 0.06% | A | +3 |
| Malaysia | A- | 0.20% | BBB | +2 |

No name is 2 or more notches above its agency rating. Zambia (CCC+, shadow B-) and Japan (A+, shadow AA-) are 1
notch above. Venezuela and Zimbabwe are SD on both.

Read this with the steep top of the scale in mind. The five flags are all investment-grade Asian names, where one
notch is a few basis points of PD. The model's PD for them sits 3 to 23 basis points above the agency rating's table PD. Part of
that is the hazard compression described above and the regime multiplier, not a credit view. The flags say: the
model charges these names more PD than their rating implies. That matters for the loss numbers, so the notes
should show it. It is not, on its own, a downgrade call.

Momentum: 19 archived base runs have as_of on or before 2026-10-23 (two dates: 2026-10-20 and 2026-10-23). Ten
names moved one or two notches since the first run (20261020T025839-base), but settings, data and code all
changed between those runs. Every momentum flag today is a model revision, not news. The note text says so.

## Migration

Run-to-run (19 runs, 324 country transitions): 19 moves off the diagonal, none larger than two notches. Last run per as_of date (2 runs, 18 transitions): 10 moves. These are counts, not probabilities. They
cover four days of model development, not a year of ratings. They cannot be compared with the reference matrix
until many months of runs on a stable model exist.

## Reference long-run agency 1-year transition matrix

`REFERENCE_TRANSITION` in the module: rating-category level (AAA, AA, A, BBB, BB, B, CCC/C to SD/D), percent,
rows sum to 100, withdrawn ratings removed. Source: S&P Global Ratings, "Default, Transition, and Recovery: 2023
Annual Sovereign Default And Rating Transition Study" (2024), table of sovereign foreign-currency average one-year
transition rates since 1975.

**The values are approximate.** They are rounded judgement values with the published table's shape (diagonals of
86 to 97 percent, defaults only from BB down, about 2 percent from B and about 30 percent from CCC/C). They were
not transcribed from the publication. Check them against the published table before quoting any number. The
matrix is shown for context only; no number uses it.

## Settings

All optional, read with defaults (no `assumptions.json` key needed): `shadow_ratings.gap_notches` (2),
`shadow_ratings.momentum_notches` (1), `shadow_ratings.lookback_days` (90).

## Point in time

`build(as_of)` reads `outputs/store/archive/*-base.json` through `validation.monitoring.load_archive` and keeps only
runs with as_of on or before D. Runs written before the as_of field existed fall back to their creation date,
which is never earlier than their data. Runs are ordered by (as_of, creation time, run_id). The current table is
the run with the latest as_of on or before D (the latest created among runs of that date). A back-fill run created
later for an earlier as_of is not the current run, and momentum and migration follow as_of order. The table's
`as_of` column is the current run's as_of; the requested date is in the .md title. Tests write a later synthetic
run with very different PDs and check it is never read at the earlier date.

Paths: the run_id read from an archived JSON must be a plain name (no `/`, `\`, `..`) and must resolve inside the
archive folder, else `build` stops with ValueError. The CLI `--out` must be inside `outputs/`.

## Country-note extract (EQ-B-0086, HO-20261024-C-B-004)

The same CLI also writes `outputs/shadow_rating.csv` for the country notes (presentation/note_v2.py): one row per
country, columns `country, iso, as_of, shadow_rating, agency_rating, notch_gap, run_id`. `notch_gap` is
`gap_notches` (shadow notch minus agency notch on `pd_default`; positive = shadow worse), a whole number, blank when
either rating is unknown. `as_of` is the as_of of the archived run the PDs come from. No new number: it is a column
subset of `shadow_ratings.csv`. Test: `tests/test_shadow_rating_note.py` (synthetic archived runs).

## Tests

`tests/test_shadow_ratings.py`, 23 tests. Synthetic: scale and boundary rules, D to SD, gap sign and flags,
settings default, leave-one-out fit, no look-ahead for momentum and migration, look-back window, per-as_of
migration, CLI output through `_csv_safe`, reference rows sum to 100. Shipped archive: contract columns, no run
after as_of read, no run found before the first archive date. Review fixes (synthetic): as_of ordering with a
back-fill run, SD/D names never flagged, unsafe run_id refused, `--out` outside `outputs/` refused.

## Limitations

- About half the shadow PD is the agency rating (see above); the shadow is not an independent rating.
- The `ratings_pd` table is a Tier 1 judgement table, not fitted to sovereign default history. The shadow scale
  inherits it.
- 18 names, 2 archive dates. Migration and momentum statistics are not meaningful yet.
- The reference transition matrix is approximate.
