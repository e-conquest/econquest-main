# MVP research pack (MVP row M5)

Date: 2026-10-25. Ticket EQ-B-0110 (AGENT-02; editorial review AGENT-07). Code: `econquest/validation/mvp_pack.py`
(`build_pack`, `check_pack`). Tests: `tests/test_mvp_pack.py`. Generators: Team C's, run through the `econquest` CLI
(`notes`, `briefs`, `weekly-brief`, `editorial draft`); not changed by Team B. Validation code never imports
`presentation` (tests/test_benchmarks.py::test_no_validation_module_imports_presentation).

## What it is

One research pack for the 18 desk names, built from one run on Team A's MVP dataset (`data/mvp/data`, EQ-A-0110),
as_of 2026-10-23:

| product | generator | files |
|---|---|---|
| 18 country notes | `econquest notes --country <run countries> --dest <out>/notes` | `notes/country-note-<name>-2026-10-23.html`, `country-notes.json`, `index.html` |
| scenario briefs (one per stress scenario run) | `econquest briefs --dest <out>/briefs` | `briefs/scenario-brief-<key>-2026-10-23.html`, `scenario-briefs.json` |
| weekly brief | `econquest weekly-brief --as-of 2026-10-23 --dest <out>/weekly-brief` | `weekly-brief/weekly-brief-2026-10-23.html` + `.json` manifest |
| trade ideas | `econquest ideas page --as-of 2026-10-23 --dest <out>/trade-ideas` (EQ-C-0138) | `trade-ideas/trade-ideas-2026-10-23.html`, `trade-ideas.json` |

Every product carries the research block (INTERNAL RESEARCH banner and the "Sources and licences" attribution block
from the licence register), the input caveats, the sources list, the disclaimer and the run stamps (run_id, as_of,
data_hash, code_hash, run_hash). mvp_pack formats nothing itself. Since EQ-C-0138, the trade-ideas page is Team C's
`econquest ideas page`, and its numbers are the run's activation table. Each row shows the trade's own minimum signal from the playbook (`min_strength`, e.g. 50 for T06, 60 for T01), not one
blanket threshold. When T01 (buy CDS protection: weak fiscal fundamentals) and T17 (sell protection or buy bonds:
market PD at least 1.3x model PD) activate on the same name, a line under the table says why both can hold: T17 is a
market-PD-versus-model-PD view, not a call that the credit is sound. Both fixes were approved by AGENT-07 on mvp_pack's own
page (draft ed-20261025-0064). mvp_pack keeps `pair_notes` only as the reference wording that Team C's test compares
against.

To rebuild only the trade-ideas page (`econquest ideas page`) from the run already in the folder (no engine run, other
products and their drafts untouched; one new draft; recorded in pack.json under `trade_ideas_rebuilds`):

```
python -m econquest.validation.mvp_pack ideas --data data/mvp/data --out outputs/reports/mvp --as-of 2026-10-23
```

**House view (EQ-B-0115, HO-20261025-B-B-002).**
- **Inputs:** after the run, the build also writes the country event GPR (`python -m econquest.engine.gpr_store --as-of --data --out <pack>`, gpr_country.csv). It runs the nowcast (`python -m econquest.engine.nowcast run`, log in `<pack>/nowcast/`) only when the data folder has `live/nowcast_inputs.csv`. data/mvp has none today, so the house view records the nowcast as absent and pack.json says why.
- **Build:** it then calls `house_view.build_house_view(<pack>, <data>)`, which writes house_view.json / .csv, peers.csv and shadow_rating.csv into the pack. This happens before the notes, briefs, weekly brief and trade-ideas page.
- **Trade-ideas rows:** Team C's page reads house_view.json and puts `house_stance` and `alignment` on every activation. Counter-view and two-way rows are labelled "Counter-view to house stance X" / "Two-way". The notes and the weekly brief show the house view when its run_id matches. On the 2026-10-23 MVP run that is 10 rows: T17 for Belize, Brazil, Argentina and Nigeria; T19 for Brazil; T15 and T20 for India; T06, T17 and T19 for Colombia.
- **Check:** `check_pack` appends `house_view.house_view_problems` (prefixed "house view:") and keeps its `not_wired` list in check.json as information. A pack built before this change has no house_view.json, so its check fails until it is rebuilt.

`--skip-run` and `ideas` reuse the run already in the folder, so both first compare the data folder's data_hash now
(`econquest.versioning.stamp`, the hash a run stamps) with the run's, and refuse with exit 2 if it moved: a
rebuild on changed data must be a full one.



## How it is built

```
python -m econquest.validation.mvp_pack build --data data/mvp/data --out outputs/reports/mvp --as-of 2026-10-23
python -m econquest.validation.mvp_pack check --out outputs/reports/mvp
```

`build` runs `econquest run --stress --as-of 2026-10-23` into the pack folder (100,000 paths; all non-historical
scenarios), then `econquest dsa --as-of` (DSA fan for the notes) and `econquest reverse-stress --as-of
--scenarios-only` (the briefs' limit distance; `--as-of` added by Team C, HO-20261025-B-C-010). The reverse stress uses its own base run at 20,000 paths, as the command does. `--skip-run`
rebuilds the products from the run already in the folder. Drafts are registered in the editorial ledger
(`outputs/reports/mvp/editorial/ledger.jsonl`, the editorial review log), author AGENT-02. The trade-ideas page is
registered as a draft too (one item, 31 + 1 = 32 drafts per build). Editorial has no "trade_ideas" kind yet, so it is filed under
"weekly_brief" with the title "Trade ideas <as_of> (playbook activations)"; `ideas_kind()` switches to "trade_ideas"
when Team C adds it (HO-20261025-B-C-011).

## The consistency check

`check_pack` compares the pack with `run_latest.json` and `stress.json` in the same folder and fails on any difference:
stamps (run_id, as_of, data_hash) on every item; one note per run country with pd_default, composite and regime equal
to the run and the PD tile showing the run's PD; one brief per stress scenario, matched to a stored stress run of this
base run, showing the stressed VaR99, ES99 and EL of stress.json; the weekly brief's book metrics equal the run's; the
trade-ideas activations equal the run's activation table; every HTML file carries the run_id, the disclaimer and the
licence attribution block without template placeholders. A note's PD tile matches ">99.00%<" or
">99.00% (engine cap)<" for a PD at the engine's 99% cap, the label Team C added (HO-20261025-B-C-011). The disclaimer test looks for an element of class
"disclaimer" that makes both required statements ("not investment advice" and "Nothing here is an offer, a
recommendation or an instruction to trade"); the check keeps its own list rather than Team C's constant. The result is written to `check.json`.

## Status (2026-10-25)

- Run 20261025T164946-base on data/mvp/data: VaR99 66.21, ES99 87.91, EL 4.01, L-VaR99 71.49 $mm (131,072 Sobol
  paths). This is the MVP dataset's run, not the 0.6.0 base on data/ (66.70 / 88.43 / 4.08 / 71.99).
- 18 notes, 12 scenario briefs, the weekly brief and 71 trade activations. The check passes on numbers and stamps.
- Open: the licence register's attribution lines for IMF and World Bank sources hold template text ("<link to the
  dataset>"), so the check flags every product until Team A fills them (HO-20261025-B-A-003). Editorial review by
  AGENT-07 is pending. The weekly brief has no reference run (first run in the pack), so week-on-week changes are
  "not available". Bond RV and CDS curves are not produced by the run, so those note sections say so.
