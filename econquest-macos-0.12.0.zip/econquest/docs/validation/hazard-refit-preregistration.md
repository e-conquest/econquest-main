# Pre-registration: layer-1 hazard refit rehearsal on the A-0140 panel (EQ-B-0140)

Team B AGENT-03, 2026-10-26, version **PR-1**. Written and checkpointed (`teamctl checkpoint --ticket EQ-B-0140`)
**before any model was fitted on the panel**. What was known when it was written: Team A's handoff
HO-20261026-A-B-016 and runbook `docs/runbooks/A-hazard-panel.md` (row, economy and event counts, coverage by
predictor, the 0.616 ever-defaulted share of the CRAG universe). No AUC, Brier score or coefficient from this panel
had been computed by anyone.

The rehearsal runner (`python -m econquest.validation.hazard_rehearsal`) fits only what is written here. Its
constants (`SPECS`, `SPLIT`, `GATE`, `PREFLIGHT`) are tested against this file (`tests/test_hazard_rehearsal.py`),
and every report records this file's sha256. **No specification search beyond this list.** Any change (another
predictor set, split, threshold, transform, event rule, bin rule or sample rule) is a new dated version PR-2 with
its reason, written before it is run; PR-1 results stay in the record, and runs of PR-2 on data already seen under
PR-1 are labelled exploratory and cannot pass.

## 1. Data

- Panel: `data/panel/hazard_panel_wide/panel.csv` (EQ-A-0140, internal only), as_of **2026-10-23**, read as it is
  (no rebuild, no edit). Its `manifest.json` must carry the same as_of, lag 1 and the crag_v1 rule.
- Keys: `iso` (ISO3, CRAG-universe economies only, no aggregates), `year` = row year t.
- Predictors: the panel's columns, already lagged one year (period t-1 values) and transformed with the layer-1
  transforms (`hazard_panel.PANEL_FEATURES`, `hazard_refit.WB_INTERIM_FEATURES`). No further transforms, no
  winsorising, no interactions, no extra lags or leads.

## 2. Event definition

- **crag_v1 starts**: BoC-BoE CRAG 2026 (raw `DEBT_2026.csv`, sha256 `7b6e696aa9b943a6...`), FC bank loans + FC
  bonds + LC debt in default above USD 10m in the year, 2-year cure (`hazard_events.RECOMMENDED_RULE`).
- Row (iso, t) has `event = 1` when a crag_v1 spell starts in t+1 (the **label year**). Rows inside a spell and its
  cure years are not at risk (not in the panel).
- Preflight re-derives the label from `hazard_events.build_events` at as_of and requires an exact match.

## 3. Sample rules (selection on outcome)

61.6% of the CRAG-universe economies have ever defaulted. The panel is selected on the outcome through CRAG's own
coverage (economies with no CRAG record are absent, not zeros). The rules that follow from that:

1. Every at-risk country-year of every panel economy is in the sample; economies are **never** dropped or kept
   because they defaulted or did not. Complete cases on the specification's own predictors only (no imputation).
2. **No country fixed effects**, no country-specific intercepts, no region dummies, no reweighting by outcome.
3. `ever_defaulted`, `crag_years_since_default`, `n_present` and any column that uses information after row year t
   are **never predictors**. `crag_prior_spells` counts only spells started by t (point in time).
4. Base rates are reported with every result: training event rate, test event rate, ever-defaulted share of the
   fitted sample.
5. Preflight check `not_selected_on_outcome`: the ever-defaulted share of the specification's fitted sample
   (training plus test rows) must be **below 0.55** (`hazard_refit.MAX_EVER_DEFAULTED_SHARE`, HO-20261023-B-A-002).
   A specification that fails it cannot pass, whatever its gate figures; its figures are reported for information.

## 4. Out-of-sample split (time based, one fit)

| Part | Label years (t+1) | Row years (t) | Use |
|---|---|---|---|
| Training | up to 2007 | up to 2006 | one Firth logit fit, predictors standardised on the training rows |
| Test | 2008 to 2023 | 2007 to 2022 | scored once with the training fit; never used for fitting or standardising |
| Not used | 2024 to 2025 | 2023 to 2024 | outside the pre-registered window |

Reported, never deciding: the rolling-origin figures of `hazard_panel.fit_and_validate` (fit on row years before T,
score T) for row years 2007 to 2022, so the result can be compared with the earlier gate reports.

## 5. Specifications (the whole list)

| Id | Name | Predictors (panel columns) | Runs now? |
|---|---|---|---|
| S1 | paper | debt_gdp, primary_deficit, stfx_debt_reserves, reserves_months_imports, pitf_instability | no: WEO columns empty |
| S2 | wb_only | stfx_debt_reserves, reserves_months_imports, pitf_instability | yes |
| S3 | wb_crag_history | stfx_debt_reserves, reserves_months_imports, pitf_instability, crag_prior_spells | yes |
| S4 | full | debt_gdp, primary_deficit, current_account, real_growth, inflation_log, stfx_debt_reserves, reserves_months_imports, pitf_instability, crag_prior_spells | no: WEO columns empty |

- **S1** is the paper's layer-1 predictor set (`layer1_paper_coefficients`) in its panel names: primary_deficit
  stands in for primary_deficit_gap, and commodity_export_shock has no panel column, so it is left out.
- **S2** is the non-WEO part of S1, all from the World Bank (the 0.5.0 history3 set).
- **S3** is S2 plus the CRAG default history count.
- **S4** is the five WEO predictors of the current `layer1_fitted` list plus S3.
- A specification whose predictors include a column that is empty in the panel is reported **NOT RUN: WEO columns
  empty** (or the empty column's name). S1 and S4 run, unchanged, after `hazard_panel_wide build --refit` fills the
  WEO columns; this file is not edited for that.
- The other panel columns (WB interim set, BIS, GPR, IDS ratios, NPL, youth unemployment) are not specified and are
  not fitted. Their coverage is mostly 2021 to 2024, which leaves no training rows.

## 6. Metrics and the gate

On the test rows, with the training fit:

| Gate check | Rule |
|---|---|
| test events (crag_v1 starts in label years 2008 to 2023, after the complete-case rule) | >= 30 |
| OOS AUC (Mann-Whitney, ties half) | >= 0.75 |
| OOS Brier score | below the Brier score of the trailing base rate (the training event rate as a constant forecast) |

Also reported, not deciding: log loss against the trailing base rate, calibration in equal-count bins of the
predicted probability (bins = min(10, max(2, test rows // 30)), the `hazard_panel` rule), calibration in the large
(mean predicted against observed), coefficients with Firth standard errors, training events (preflight floor below).

## 7. Preflight (hard checks; any failure means the specification cannot pass)

| Check | Rule |
|---|---|
| manifest_as_of | panel manifest as_of equals the run's as_of |
| event_rule | manifest rule is crag (10, 2) and the raw CRAG sha256 matches |
| predictor_lag | manifest lag is 1 |
| labels_match_crag_v1 | every panel label equals the label from `hazard_events.build_events` at as_of |
| unique_rows | one row per (iso, year) |
| training_events | at least 10 events in the training rows of the specification |
| economies | at least 60 economies in the fitted sample (`hazard_refit.MIN_COUNTRIES`) |
| not_selected_on_outcome | ever-defaulted share of the fitted sample below 0.55 |

Reported, not deciding: point in time per predictor (World Bank columns are latest values, revisions included; only
the WEO and CRAG columns are point in time).

## 8. What counts as a pass, and the decision

- A specification **PASSES** when every preflight check and every gate check passes. Verdicts: PASS, FAIL (gate),
  PREFLIGHT_FAILED (a preflight check failed; the gate is shown for information), NOT RUN.
- **Layer 1 stays `paper_standardized` unless a pre-registered specification passes.** The rehearsal never proposes
  or applies a change.
- If more than one passes, the candidate is the first passing one in the order **S1, S4, S3, S2** (theory first, then
  the full set, then the smaller sets), never the one with the best figures.
- A pass of S2 or S3 (World Bank columns, not point in time, refused by fitted mode at run time, EQ-B-0029) can only
  support a coefficients-only Tier 1 card. A `layer1.mode` switch needs a pass of S1 or S4 on the WEO-filled panel.

## 9. Effect table (only when a specification passes)

On a temporary copy of `data/` (the shared folder is never written), with `hazard_refit.runtime_effect` at 20,000
paths and as_of 2026-10-23: VaR99, ES99, EL and L-VaR99 before and after, and for the 18 desk names the layer-1
hazard PD and pd_default before and after plus the fit's raw PD on each name's latest panel row. The "before" run
must reproduce the base exactly (20k 66.95612571109443 / 89.00003057231508 / 4.098636048964449 / 72.23763153780678);
otherwise the effect is reported as invalid. When nothing passes, no effect run is made.

## 10. Outputs

`outputs/hazard_refit/<as_of>-rehearsal/`: `rehearsal-report.md`, `rehearsal-report.json` and, per run
specification, the test-row predictions. Nothing is written elsewhere; no fetch, no clock (as_of is explicit).
