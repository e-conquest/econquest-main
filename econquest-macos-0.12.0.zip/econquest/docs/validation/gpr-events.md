# Event-based country GPR (UCDP/GDELT), GPR stress shock and episode backtest

Ticket EQ-B-0072. Owner: Team B, AGENT-03. Date: 2026-10-24. Code: `econquest/engine/gpr.py` (everything below
`EQ-B-0072` in the file); reuses `econquest/engine/event_index.py` (input contract, point-in-time rule, source
precedence). Tests: `tests/test_gpr_events.py` (17 tests). Fixture: `tests/fixtures/gpr_episode_fixture.py`.
Tier: 1 when switched on (it can move indicator 4.10, so pillar 4, the composite and the PDs); shipped **off**.

> **Evidence status.** No real UCDP or GDELT data is in the repo yet: the first pulls wait on Sam's Mac
> (UCDP token). There is also no sovereign spread history in the repo (`data/cds_quotes.csv` is empty;
> `data/market_history/` holds FX and ETF closes from 2023-10-18). So:
> - every event-score result below is from a **SYNTHETIC** fixture and shows only that the code works;
> - the elasticities are **SYNTHETIC** and must not be used in a scenario;
> - the one real-data check (Caldara-Iacoviello country GPR against FX and ETF moves, 2023-11 to 2026-10)
>   finds no usable relation.

## What was built

1. **Country GPR score from events** (`event_gpr_scores`, `event_gpr_stats`, `gpr_event_history`).
2. **Option `gpr.source`** in `run_gpr`: `"ci"` (default, today), `"events"`, `"blend"`. No pipeline edit is
   needed: `run_gpr` reads `u.events` and `settings["as_of"]`.
3. **Elasticity** of spreads and PDs to a GPR shock (`estimate_gpr_elasticities`), stored as a JSON record and
   turned into ordinary stress shocks (`gpr_shock_ops`, `expand_gpr_shocks`).
4. **Backtest** harness on episodes (`episode_backtest`) and lead-lag (`lead_lag`, a wrapper on
   `event_index.spread_lead_lag`); `ci_gpr_history` puts the Caldara-Iacoviello (CI) series in the same shape.

## 1. The score

Input: Team A's long table (`data/live/events/events_long.csv`, loaded as `Universe.events`; contract
HO-20261023-B-A-004, see `event-index.md`). ACLED is not used (no licence).

| component | source | series | monthly value | sign | weight |
|---|---|---|---|---|---|
| `fatalities` | UCDP (GED, else candidate) | fatalities | log1p(rate per 30.4 days) | + | 0.30 |
| `conflict_events` | UCDP | events | log1p(rate) | + | 0.20 |
| `media_events` | GDELT | material-conflict events | log1p(rate) | + | 0.20 |
| `tone` | GDELT | tone_mean | event-weighted mean | - | 0.30 |
| `goldstein` | GDELT | goldstein_mean | event-weighted mean | - | 0 (available) |

Steps, at a given `as_of`:

1. **Point in time.** Only rows with `vintage <= as_of` (capture date) and period end `<= as_of` (event date);
   the latest vintage on or before `as_of` wins; final GED beats candidate for a month
   (`event_index.point_in_time`, `_component_frame`).
2. **Monthly values** per calendar month. A month counts once at least half its days are covered, so a
   GDELT month counts from mid-month.
3. **Own-history z.** Each month's value against the country's previous 60 months:
   `z = sign * (x - mean) / max(sd, 0.25)`, clipped at +-4, scored once 24 base months exist.
4. **Score** = weighted mean of the component z's present in that month; needs at least half the weight.
5. **Alignment** (`gpr.events.align`). `calendar` (default): month k is the as-of month minus k for every
   component. UCDP candidate data comes out about 25 days after month end, so the newest scored month is
   nearly always GDELT only (coverage 0.5, flag `partial`) and is revised when UCDP arrives. `edge`: each
   component's own newest month is month 0 (the `event_index` rule). On the synthetic episodes `edge` mixes a
   month-old UCDP reading with current GDELT and alerts later (table in section 4), so `calendar` is the default.
6. **Uplift statistics.** `event_gpr_stats` runs the existing `_stats` (3-month mean, z against 60 months,
   percentile in 120 months) on the score series. The uplift and signal rules and thresholds are unchanged.
   `momentum` is set to NaN: a ratio of z-score means has no meaning.

Flags: `ok`, `partial`, `insufficient` (no month with a score inside `max_staleness_months` 3), `missing` (no
rows). Fewer than 24 scored months gives no z, so no uplift.

## 2. Option `gpr.source` (off by default)

| value | effect on indicator 4.10 and the GPR signal |
|---|---|
| `ci` (default; also when the key is absent) | Today's code path, unchanged. |
| `events` | z, percentile, uplift and signal from the event score. A country with no usable score keeps CI. |
| `blend` | z and percentile = (1 - b) CI + b events, b = `gpr.blend_weight_events` (0.5). A country that has only one of the two uses that one. |

Under `events` or `blend`, the seven countries with no CI series (Singapore, Pakistan, Belize, Nigeria, Senegal,
Zambia, Zimbabwe) get an uplift and a signal for the first time. The table gains columns `z_ci`,
`percentile_ci`, `event_score`, `z_events`, `percentile_events`, `event_flag`, `event_coverage` and
`gpr_source_used`, but only under a non-default source. Downstream code reads only `final_410`, `signal` and
`covered`. With no event table, the run warns and keeps CI.

Proposed keys (not in `data/assumptions.json`; the code defaults reproduce today):

```json
"gpr": {..., "source": "ci", "blend_weight_events": 0.5,
        "events": {"align": "calendar", "base_months": 60, "min_base_months": 24, "std_floor": 0.25, "clip": 4.0,
                   "min_month_coverage": 0.5, "max_staleness_months": 3, "min_coverage": 0.5,
                   "history_months": 120, "min_series_months": 24,
                   "weights": {"fatalities": 0.30, "conflict_events": 0.20, "media_events": 0.20,
                               "tone": 0.30, "goldstein": 0.0}}}
```

The weights are judgement, not fitted. Fatalities and tone get the most weight: fatalities are the least
media-dependent measure, and tone carries the direction of coverage.

## 3. Scenario linkage: elasticity and the GPR stress shock

`estimate_gpr_elasticities(hist, spreads, horizon_steps=3)` works on a monthly grid. It regresses the change in
f(spread) over 3 months on the change in score over the same 3 months. It uses non-overlapping samples,
country fixed effects and country-clustered standard errors. It also reports a lead version: the change over
the next 3 months on the change over the past 3. Three transforms:

- `spread_log`: log spread. Beta is the proportional widening per 1 sd of score.
- `spread_bp`: spread in bp.
- `pd_logit`: logit of the layer-2 physical PD implied by the spread, `spread / 1e4 / lgd / ratio`. This is
  the same formula as `layer2_bayesian.physical_pd`, so the PD elasticity is consistent with layer 2.

A PD history independent of spreads does not exist in the repo, so the PD elasticity is market-implied.

`elasticity_record` stores the contemporaneous betas as JSON (`write_gpr_elasticity`). A stress shock

```json
{"target": "gpr", "shock_sd": 2.0, "where": {...}, "pd_channel": "market" | "full", "spread_mode": "mul" | "add",
 "elasticity_file": "live/gpr_elasticity.json"}
```

is expanded by `expand_gpr_shocks` into standard shocks:

- `spread` x exp(spread_log_beta x shock_sd) (or + spread_bp_beta x shock_sd bp with `spread_mode` `add`).
- With `pd_channel` `full` only: `textz` + (1 - w_m) x pd_logit_beta x shock_sd / w_t.

Layer 2 already moves the PD through the spread with weight `w_m` 0.5. The `full` term adds the remainder, so
the log-odds move by about pd_logit_beta x shock_sd in total. With `market`, the PD moves only through the
spread. The scenario `scale` applies as for any add or mul shock. An inline `"elasticity": {...}` is accepted
instead of a file. The file path must stay inside the data folder (the same rule as contagion exposures).

### Synthetic elasticities (SYNTHETIC, do not use)

From the episode fixture (8 countries, monthly 2019 to 2024, 184 non-overlapping 3-month changes):

| transform | planted: beta (clustered se) | planted: lead beta | null fixture: beta |
|---|---|---|---|
| spread_log | 0.082 (0.011) | 0.026 (0.021) | 0.003 (0.004) |
| spread_bp | 48.5 bp (13.1) | 15.4 (14.3) | 0.6 (1.6) |
| pd_logit | 0.091 (0.009) | 0.029 (0.023) | 0.003 (0.004) |

The estimator finds the planted response, finds nothing on the null fixture, and recovers an exact planted
beta of 0.10 (to within 0.01) in `test_elasticity_recovers_planted_beta`.

### What the shock does (SYNTHETIC elasticity, real book)

`run_pipeline(paths=20000, as_of="2026-10-23")` after `apply_shocks(expand_gpr_shocks(...))`, using the
synthetic record above (spread x1.178 and textz +0.366 at +2 sd). This shows the size of the mechanism only.
All numbers in this table are from before Team A's INDA price repair (12:43Z, 2026-10-24), which moved the base.

| run | VaR99 $mm | ES99 $mm | EL $mm | largest PD moves (pp) |
|---|---|---|---|---|
| base | 67.28 | 89.61 | 0.809 | none |
| +2 sd Asia, market | 67.43 | 89.94 | 0.709 | PAK +0.67, VNM +0.03, PHL +0.03 |
| +2 sd Asia, full | 67.90 | 90.27 | 0.792 | PAK +1.43, VNM +0.07, PHL +0.07 |
| +2 sd all, full | 68.01 | 90.65 | 0.100 | ZWE +9.47, SEN +2.39, PAK +1.43, ARG +1.21 |

EL falls as spreads widen. That comes from how the book reprices, not from the GPR code, and was not
investigated here. Zimbabwe moves most because a log-odds shift is largest near PD 0.78 (as in `event-index.md`).

## 4. Backtest on past episodes

### Synthetic episodes (SYNTHETIC)

`tests/fixtures/gpr_episode_fixture.py` re-creates five episodes with made-up event data (`synthetic_events`)
and made-up weekly spreads. Only the outbreak dates are real. Russia gets a smaller event build-up from
November 2021 and a 120 bp spread precursor from mid-January 2022. Each spread path widens a few days to a
month after its outbreak. Scores are taken on the 1st and 17th of each month, 2019 to 2024, point in time on
each date. An alert is a score of at least 1.5. A move is a widening of at least 100 bp against the level
6 months before the outbreak.

| episode (outbreak) | alert | spread move | lead (days) | verdict, calendar | verdict, edge |
|---|---|---|---|---|---|
| Russia-Ukraine (2022-02-24) | 2021-11-17 | 2022-02-11 | 86 | led (by the planted build-up) | coincident (+10) |
| Israel-Gaza (2023-10-07) | 2023-10-17 | none >= 100 bp (max +45 bp) | - | no move | no move |
| Ethiopia (2020-11-04) | 2020-11-17 | 2020-12-18 | 31 | led | led (+31) |
| Myanmar (2021-02-01) | 2021-02-17 | 2021-02-26 | 9 | coincident | lagged (-34) |
| Sudan (2023-04-15) | 2023-04-17 | 2023-05-05 | 18 | coincident | coincident (+4) |

With a relative move rule (30 percent) Israel becomes coincident (+17 days). At a 2.5 threshold the calendar
score is still coincident or better in the four episodes with a move, and the edge score lags in all four. On the
null fixture (no spread jumps) every episode is "no move", and the three calm controls never reach 1.5.
Pooled lead-lag (monthly dates, widening >= 100 bp): AUC 0.97 at +30 days and 0.79 at +91 days on the planted
fixture. On the null fixture there are too few widenings to score.

Reading:

- The design reacts within the outbreak month, because GDELT is daily and counts from mid-month. It can lead
  spreads only when conflict builds up in the event data before the market moves, as in the planted Russia
  path.
- For a sudden outbreak (Israel, Myanmar, Sudan) it is at best coincident. Markets reprice in days; the score
  updates twice a month at most.
- Every number here describes the fixture's design. None is evidence about the real world.

### Real data in the repo: CI country GPR against FX and ETF moves

The CI country series are real (11 countries). The FX and ETF closes are real but start 2023-10-18, so
Russia-Ukraine (2022), Israel-Gaza (October 2023), Ethiopia (2020), Myanmar (2021) and Sudan (April 2023) all
fall before the market history. None of these five countries is in the CI country file or in the universe.
There is no spread history. As a proxy, `ci_gpr_history` z (dated the 1st of the following month; the file
carries no vintages, so this is not strictly point in time) is set against USD FX levels and inverse ETF
prices, 2023-11 to 2026-10, 396 country-months:

| level series | horizon | beta per 1 sd (clustered t) | lead beta (t) |
|---|---|---|---|
| FX, log | 1 month | 0.001 (0.35) | 0.002 (1.23) |
| FX, log | 3 months | 0.004 (0.75) | 0.000 (-0.01) |
| FX excl. Venezuela, log | 3 months | -0.000 (-0.02) | 0.003 (0.57) |
| 1 / ETF, log | 1 month | 0.040 (1.79) | 0.022 (0.92) |
| 1 / ETF, log | 3 months | 0.050 (1.19) | -0.052 (-0.77) |

None is significant at 5 percent. The pooled FX lead-lag correlation (0.24 to 0.31 at every horizon) comes from
Venezuela's steady depreciation alongside its high GPR, not from timing: without Venezuela it is -0.03 to 0.02
(widening AUC 0.49 to 0.52). The two largest CI spikes in the
window behave the same way. India (May 2025, z 2.5 from the June print) had no INR move of 2 percent; its ETF
had already fallen before the spike. Venezuela (December 2025 to April 2026, z up to 3.9) cannot be separated
from the bolivar's continuous depreciation. Conclusion: the repo has no history that can show whether
geopolitical risk leads sovereign spreads.

## Determinism, point in time, base run

- The code reads no wall clock and draws no random numbers. `as_of` comes from `settings["as_of"]` (GOV-012).
  The history functions rebuild the score per date from rows knowable on that date.
- Base check, `run_pipeline(paths=20000, as_of="2026-10-23")`, before and after this ticket's code: VaR99 67.2808,
  ES99 89.6091, EL 0.8088, L-VaR99 72.5623, with the same loss-vector hash. Bit-identical. These base numbers are
  from before Team A's INDA price repair (12:43Z, 2026-10-24), which moved the base. The check was not rerun on
  the repaired data; the default `run_gpr` path has no code change from this ticket.
- The elasticity is point in time as well (AGENT-04 review, Low). `estimate_gpr_elasticit(y|ies)(..., as_of=)`
  drops score and level rows dated after `as_of` and records `data_end`. `elasticity_record` refuses an `as_of`
  earlier than `data_end`. `expand_gpr_shocks` refuses a file record whose `as_of` is after the run date
  (`as_of=` argument, else `settings["as_of"]`), refuses a file record with no `as_of`, and refuses any file
  record when no run date is known. `gpr_missing_data(..., as_of=)` lists such records as unavailable. An inline
  elasticity is checked only if it carries an `as_of`. Tests: `test_estimate_as_of_drops_later_data` and
  `test_elasticity_record_after_run_as_of_is_refused`.

## Limitations

- No real event data and no spread history yet. Weights, windows and thresholds are judgement.
- The newest month is GDELT only under `calendar`. Its z is compared with a history that is mostly UCDP plus
  GDELT. On the synthetic controls this did not raise false alerts (0 of 432 control dates at z >= 1.5), but
  real GDELT, whose coverage drifts with the media, may differ.
- UCDP counts only lethal organised violence. GDELT `events` is material-conflict events only, while tone
  covers all root events. Threats that never turn violent (most of what CI measures as GPR "threats") reach
  the score only through GDELT tone and volume.
- Under `blend`, `recent`, `mean5y`, `sd5y` and `momentum` stay CI's while z and percentile are blended.
- Market-implied PD elasticity only; no independent PD history.
- `stress._clone` drops `Universe.events` (and `wb_raw`). A stressed run with `gpr.source` `events` or
  `probability.text_index.source` `events` falls back silently. See the requested edit below.

## Local-currency spread history (EQ-A-0063): decision (EQ-B-0086, HO-20261024-A-B-009)

Team A's free spread history (`econquest.ingestion.spreads`, proposed contract C14) has `local_minus_ust` rows
only: local-currency 10-year yield minus the US 10-year yield. That gap holds the expected depreciation and the
inflation differential as well as default risk, and it can be negative (Japan). It is not a credit spread.
Planned coverage is 4 of 18 desk names (JPN, KOR, IND, COL), all series codes are UNVERIFIED, and the OECD-on-FRED
legs are restricted (internal only).

- Layer 2 (`countries.spread`, `z_cds`): **not used.** Layer 2 turns the spread into a PD as spread / LGD. A
  local-currency spread would read the FX and inflation premium as default risk. Layer 2 keeps CDS/EMBI spreads.
- GPR elasticities and the GPR2SD stress record: **not used.** The record (`elasticity_record`) is applied to
  `countries.spread`, a credit spread, and `estimate_gpr_elasticities` also fits log and logit-PD transforms, which
  drop or clip negative values and read the spread as a PD. An elasticity measured on a local-currency spread is in
  other units.
- Research diagnostic only: `estimate_gpr_elasticity(hist, levels, transform="bp", as_of=...)` on rows with
  `leg == "local"` and `verified == "yes"` may be run by hand to look at levels and changes. Its output is internal
  (restricted rows), labelled `local_minus_ust`, and is not written to `live/gpr_elasticity.json`.
- Revisit only after (1) Sam's Mac pull verifies the codes, and (2) a backtest on the spread history shows the
  series moves with credit events (for example the episode harness in section 4) rather than with FX and inflation.
- No reader is written and C14 is not needed by Team B now. A licensed hard-currency series (EMBI or vendor,
  EQ-A-0033) is what layer 2 and the elasticity record need; that is Sam's decision through AGENT-08.

## Per-country GPR output (EQ-B-0086, HO-20261024-C-B-004)

`python -m econquest.engine.gpr_store --as-of D` writes `outputs/gpr_country.csv` for the country notes: country,
iso, event_score, z_events, percentile_events, gpr_source_used, as_of, gpr_source. It runs `run_gpr` on the same
inputs as the pipeline (deterministic, no clock). Under the default `gpr.source` "ci" the event columns are shown
for information only (blank without an event table) and `gpr_source_used` is "ci" or "none". The pipeline does not
call it; the base run is unchanged. Tests: `tests/test_gpr_store.py` (synthetic events).

## For AGENT-08 (edits outside this ticket's files)

1. `econquest/engine/stress.py`, `_clone`: carry the event table, so stressed runs see it:
   `return dataclasses.replace(u, countries=u.countries.copy(), indicators=u.indicators.copy(), rulebook=u.rulebook.copy(), adjustments=u.adjustments.copy(), portfolio=u.portfolio.copy(), markets=u.markets.copy(), provenance=dict(u.provenance))`
   (needs `import dataclasses`).
2. `stress.py`, `apply_shocks`: first statement of the body:
   `from .gpr import expand_gpr_shocks; shocks = expand_gpr_shocks(shocks, s, base_dir)`.
3. `stress.py`, `Scenario.missing_data`: append `+ gpr_missing_data(self.shocks, self.base_dir)` (import from
   `.gpr`), so a GPR scenario without its elasticity file is listed in `UNAVAILABLE` rather than failing.
   Where a run date is at hand, pass it (`as_of=`) so a record fitted after it is listed too.
3a. The run date must be in the settings when a scenario is applied. `cli.py` (Team C) calls `sc.apply(u, s)`
   before `run_pipeline(..., as_of=as_of)` sets it, so a file-based GPR scenario would be refused with "no run
   as_of". Before the stress loop and the single-scenario command:
   `s = s.copy_with(as_of=resolve_as_of(as_of))` (`resolve_as_of` from `econquest.engine.pipeline`).
   `reverse_stress` and `single_factor_reverse` take `s` from their callers, so the same fix covers them.
4. `stress.py`, `summarise_shocks`: add `"gpr": f"GPR shock {sh.get('shock_sd')} sd ({sh.get('pd_channel', 'market')} PD channel)"`
   to the target map and `elif t == "gpr": txt = f"{tgt} x{scale:.3g}"` before the `op` branches. Add a
   `{"target": "gpr", ...}` line to the module docstring.
5. `data/scenarios.json`, once a real `data/live/gpr_elasticity.json` exists (until then load_scenarios leaves
   it out):
   `{"key": "GPR2SD", "name": "Geopolitical risk shock +2 sd", "kind": "hypothetical", "source": "EQ-B-0072 event GPR elasticity", "description": "Event GPR score up 2 trailing sd in every country; spreads scale by the estimated elasticity, PDs through layer 2 (full channel).", "shocks": [{"target": "gpr", "shock_sd": 2.0, "elasticity_file": "live/gpr_elasticity.json", "pd_channel": "full"}]}`

No pipeline edit is needed for `gpr.source`.

## On Sam's Mac (after the first UCDP and GDELT pulls)

1. Run the pulls in `docs/runbooks/A-event-feeds.md`, sections 1, 2 and 4. GDELT history from 2015 or earlier
   is needed for 2 base years plus a test window.
2. Score history: `h = gpr_event_history(u.events, pd.date_range("2019-01-01", as_of, freq="MS"), isos=...)`.
3. A sovereign spread history (EMBI or 5-year CDS, `iso, date, value`) from a licensed vendor (Team A market
   importers). Without one, the elasticity and the backtest cannot be run on real data.
4. `est = estimate_gpr_elasticities(h, spreads, as_of=as_of)`, then
   `write_gpr_elasticity("data/live/gpr_elasticity.json", elasticity_record(est, as_of, "<vendor + vintage>", False))`.
   Run `episode_backtest` on the real episodes in the universe, and bring the before/after table to Sam
   before any `gpr.source` change (Tier 1).

## Recommendation

Keep `gpr.source "ci"`. Once real event data and a spread history exist, rerun section 4 on them.

- Switch to `blend` only if the event score is at least coincident with spread moves on real episodes and
  adds little noise on calm countries.
- Weigh the main gain: an uplift for the seven frontier countries that CI does not cover.
