# Model validation: forecast record and interim monthly scorecard

Date: 2026-10-24 (EQ-B-0073). Code: `econquest/validation/forecast_scorecard.py`. Reads:
`data/forecast_record.csv` (`record.py`), `data/benchmarks.csv` (`benchmarks.py`),
`data/panel/sovereign_defaults.csv`, `outputs/idea_log.csv`, and, when present, `data/weo_benchmark.csv`
and `data/rating_actions.csv`. Writes: `outputs/forecast_scorecard.csv` and `.md`, and a monthly copy in
`outputs/forecast_scorecard/<YYYY-MM>.csv` and `.md`. Tier 3: read-only, not called by the pipeline, no
reported base number reads it.

The tests behind the record (Kupiec, Christoffersen, Z2, Basel zone) and how the record is built are in
[backtests-and-forecast-record.md](backtests-and-forecast-record.md). The 12-month PD scoring is in
[benchmarks.md](benchmarks.md). This page covers what can be said before those tests have enough data.

## Purpose

The daily record job (weekdays 18:20 New York) appends one row per trading day. The formal tests need
250 tested days (VaR) and 12-month-old snapshots (PDs). Until then, Sam still wants a monthly look at
the record. The scorecard gives that look with each number labelled for what it is: interim, and
usually underpowered. Formal results stay hidden until their calendar gate opens.

## Run

```
python -m econquest.validation.forecast_scorecard --as-of 2026-10-30
python -m econquest.validation.forecast_scorecard --as-of 2026-10-30 --no-archive   # latest files only
```

`--as-of` is required. Nothing reads the wall clock. Run it after the last record job of the month.
It is not scheduled; adding it to the `record` job or a monthly job is a Team C change (`ops/schedule.py`).

## Calendar gates

The gates come from the evidence monitor (`evidence_monitor.evidence_table`, EQ-B-0061), so the
scorecard and `outputs/evidence_monitor.csv` agree. As of 2026-10-23:

| Test | Progress | Earliest test date |
|---|---|---|
| VaR record (`var_record_250d`) | 60 of 250 tested days | 2027-07-14 |
| 12-month PD benchmark (`benchmark_12m`) | first snapshot 2026-10-23 | 2027-10-23 |
| Trade-idea quarters (`idea_quarters_4q`) | 0 of 4 quarters | 2027-10-23 |

A formal section is filled only when the evidence monitor says "testable". The VaR date moves later if
record days are missed. Before the gate, the formal section has one row with status `gated`.

## What each section computes

1. **VaR99 exceptions (interim).** Tested days are record rows with loss, VaR and ES. An exception is
   `loss > var`. The count is compared with the two-sided 95% band of Binomial(n, 0.01) at the current
   n (`binomial_band`). At n = 60 the band is 0 to 2; at n = 250 it is 0 to 6. Also shown: expected
   count, exception rate, largest loss / VaR, the split between backfilled and daily rows, and a count
   per calendar month. Label `underpowered` below 250 tested days.
2. **VaR backtests (formal).** `backtests.backtest_history` on all tested days to as_of, after the gate.
3. **Interim Brier of PDs.** For each country, take the earliest benchmark snapshot dated in the 12
   months before as_of (one row per country, so windows do not overlap). Skip rows already in default
   (`benchmarks.in_spell`). Scale each 12-month PD to the time elapsed under a constant hazard:
   `1 - (1 - p)^(months / 12)`. The outcome is 1 if a default start falls after the snapshot date and
   on or before as_of. Brier = mean squared difference, per PD source. Label `underpowered` below 10
   realised default starts. With zero events the Brier is just the mean squared PD and says nothing
   about skill.
4. **PD scoring (formal).** `benchmarks.score_benchmarks` 12-month rows, after the gate.
5. **Model against IMF WEO.** Pairs of a model forecast and a WEO forecast of the same series, country
   and period, scored on the released outcome: RMSE of each, their ratio (below 1: model closer) and the
   share of pairs where the model is closer. Label `underpowered` below 30 pairs.
6. **Model against rating actions.** For each upgrade or downgrade, the latest model snapshot of that
   country dated before the action. A hit is the model PD above the rating-implied PD before a
   downgrade (or default), below it before an upgrade. The spread-implied PD is scored the same way as
   the market benchmark. Label `underpowered` below 20 actions.

When `data/weo_benchmark.csv` or `data/rating_actions.csv` is absent or empty, the section has one row
with status and label `no benchmark input`. Nothing is estimated or filled in.

## Point in time

Each number uses only data known on or before as_of:

- record rows dated on or before as_of and recorded (`recorded_at`, including `backfill <time>`) on or
  before it;
- benchmark snapshots dated on or before as_of (the interim Brier uses only snapshots dated before it);
- default starts dated on or before as_of (with only a start year, 1 July of that year);
- WEO pairs where the model forecast date, the WEO vintage and the outcome release are all on or before
  as_of, and both forecasts were made before the release (otherwise the row is not a forecast);
- rating actions dated on or before as_of.

A test adds rows dated or recorded after as_of to every input and checks the scorecard is unchanged.

## Input contracts (for Team A or Sam)

`data/weo_benchmark.csv`, one row per forecast pair:

| Column | Meaning |
|---|---|
| iso, series, period | country, WEO series code (for example `NGDP_RPCH`), target year |
| model_forecast, model_made_on | the model's forecast and the date it was made |
| weo_forecast, weo_vintage | the WEO forecast and its publication date |
| actual, actual_released_on | the outcome and the date it was first published (blank until then) |

`data/rating_actions.csv`, one row per action: `date, iso, agency, action, from_rating, to_rating`.
`action` is `upgrade`, `downgrade` or `default`; other values (for example `affirm`, `outlook`) are kept
but not scored.

Neither file exists yet. Building them needs WEO vintages and an agency action feed, which run on
Sam's Mac. The engine does not yet store dated macro forecasts of its own; until it does, the WEO
section will show `no benchmark input`.

## Output contract (for Team C)

`outputs/forecast_scorecard.csv`, long format, one row per metric:

| Column | Meaning |
|---|---|
| as_of | the scorecard date (YYYY-MM-DD) |
| section | `gate`, `var_interim`, `var_month`, `var_formal`, `pd_interim`, `pd_formal`, `weo_benchmark`, `rating_actions` |
| item | what is measured: `var99_1d`, a month `YYYY-MM`, a PD source (`pd_model`...), a WEO series, `all`, `downgrades`, `upgrades`, or the evidence name for `gate` |
| metric | for example `exceptions`, `band_low`, `band_high`, `brier`, `rmse_ratio_model_to_weo`, `hit_rate_pd_model`, `formal tests`, `progress` |
| value | number, blank when there is none |
| unit | `days`, `share`, `ratio`, `probability`, or the evidence unit for `gate` |
| n | sample size; for `gate` rows, the required amount |
| status | short text: `inside band` / `above band` / `below band`, `gated`, `scored`, `no benchmark input`, the evidence status, the Basel zone... |
| label | `underpowered`, `interim`, `formal`, `no benchmark input`, or `formal gated` / `formal reported` on gate rows |
| gate_date | earliest formal test date for the section, blank when not gated |
| note | one line of plain text |

Render rule: show `label` next to every value. Do not show a `formal` value when the matching gate row
says `formal gated` (the scorecard never writes one). `outputs/forecast_scorecard.md` is the same table
as readable sections.

## Result as of 2026-10-23 (real record, not synthetic)

- Gates: VaR 60 of 250 tested days, earliest 2027-07-14; benchmark and ideas, earliest 2027-10-23.
- VaR99: 1 exception in 60 tested days (2026-09-23), expected 0.6, band 0 to 2: inside band,
  underpowered. 59 of the 60 rows are a backfill; 1 was taken by the daily job. Largest loss was 1.02
  times that day's VaR.
- Interim Brier: no snapshot dated before 2026-10-23, so none. From as_of 2026-10-24 there are 16
  countries (Venezuela and Zimbabwe are in default and excluded) with 0 events: underpowered.
- WEO and rating actions: no benchmark input.

## Limitations

- Every interim figure is underpowered for months. A 1-in-100 VaR needs about 250 days to separate a
  good model from a bad one; 16 countries over 12 months will see few or no default starts.
- The interim Brier assumes a constant hazard within the year. Default starts dated only by year are
  placed on 1 July, which can move an event across as_of.
- The record marks FX, local-bond and equity positions only; the scorecard inherits that (see
  backtests-and-forecast-record.md).
- The rating-action hit rate only checks direction against the rating-implied PD, not timing or size.
