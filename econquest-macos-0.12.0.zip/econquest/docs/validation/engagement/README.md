# Validator engagement pack

Date: 2026-10-24, refreshed 2026-10-26 for releases 0.7.0 and 0.8.0 (EQ-B-0126). Ticket EQ-B-0060 (GOV-042, roadmap 4.5). Prepared by Team B for the model owner to send to
candidate independent validators. The pack names no firm and quotes no fees; the owner chooses the firm.

| File | Purpose | Send to candidates? |
|---|---|---|
| [scope.md](scope.md) | What the model is and how it is used; inventory by tier; what is in and out of scope; the validation standard; deliverables; available evidence and its quality (synthetic, placeholder, judgement) | Yes, with the RFP |
| [questions.md](questions.md) | 27 questions from the open GOV and VF findings and use restrictions 6.1 to 6.14, each with the file to start from | Yes, with the RFP |
| [timeline.md](timeline.md) | Two-stage plan with phase durations, dependencies, calendar-gated tests (2027) and what the owner must provide | Yes, with the RFP |
| [rfp.md](rfp.md) | Request-for-proposal text with placeholders `[DATE]`, `[NAME/EMAIL]`, `[ORGANISATION]`, `[PERIOD]`, `[WEIGHT]` | Yes: it is the cover document |
| [self-assessment-summary.md](self-assessment-summary.md) | The model team's own summary of strengths and known weaknesses | After the NDA |
| [data-room-files.md](data-room-files.md), [data-room-files.csv](data-room-files.csv) | Generated file list for the data room with the licence filter: what is admitted, admitted under NDA only (EXC-003, EXC-005), admitted with cells blanked, or excluded, with the reason; paths, sizes and sha256 only, no data values | After the NDA (the list itself carries no restricted value) |

**Before sending, the owner should:**

1. Fill in the placeholders in `rfp.md`, including the evaluation weights and the cooling-off period.
2. Build the data-room snapshot from `data-room-files.csv` only (rerun `python -m econquest.validation.data_room_list` first). It excludes the GOOGLEFINANCE files, the GARCH Tier 1 statistics computed on them (`garch-tier1-*.csv`; the official FX-only rerun `garch-tier1-fxonly-*.csv` is admitted under NDA instead), Yahoo-era files and the Cruces-Trebesch workbook, and admits EXC-003 (IMF) and EXC-005 (theratesapi VES/NGN/PKR/VND/ZMW) data under the NDA only. Three register entries with validator_nda UNVERIFIED (`data/benchmarks.csv`, `data/panel/sovereign_defaults.csv`, `data/panel/universe_staging/`) are withheld until the owner decides whether they may be shared.
3. Decide whether the validator will also act as approver of record (policy section 3).

**The validator's starting point after the NDA:**

- `docs/validation/dossier/README.md`;
- `docs/validation/README.md`, which holds the 11-step review checklist;
- `python -m econquest.validation.validator_kit run --room <room> --out <dir> --release <version> --expect-manifest-sha256 <hex> --expect-code-hash <hex>` (EQ-B-0143): verifies the room and the code, reruns every pinned result from the room's inputs and reports PASS / DRIFT / FAIL / NOT RUN per check; runbook [../validator-replication-kit.md](../validator-replication-kit.md);
- `python -m econquest.validation.replicate --data data --out <dir>`.

**Freshness.** Figures are as of release 0.8.0, whose base is the 0.7.0 base (2026-10-26; dossier part 3, sensitivity
tables regenerated on the current base). If a release is made before the data room opens, refresh `scope.md` section 1,
the dossier part 3 sections, the findings register status cells and the data-room file list.
