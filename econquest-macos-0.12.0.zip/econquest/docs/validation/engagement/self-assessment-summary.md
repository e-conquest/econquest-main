# Model-risk self-assessment: summary for the validator

Date: 2026-10-25. Ticket EQ-B-0116. Written by the development side (Team B), so it is **not independent**. Full
assessment: [`docs/governance/model-risk-self-assessment.md`](../../governance/model-risk-self-assessment.md). The
data room is under NDA. IMF-derived values (EXC-003) and the theratesapi FX columns (EXC-005) may be shown to the
validator for this validation only. GOOGLEFINANCE files and the Cruces-Trebesch workbook are not in scope.

## The model in one paragraph

`econquest` is a sovereign tail-risk engine: 18 countries, 83 indicators and a 24-position book.

1. A scorecard (7 pillars) feeds a 12-month default PD built from a hazard layer (paper coefficients), a Bayesian
   market update and Calm/Stressed/Crisis regimes.
2. A severity layer (Beta LGD, Merton uplift, GPD tails) and a Student-t copula feed a 100,000-path Sobol Monte
   Carlo.
3. The Monte Carlo produces VaR, ES, L-VaR and EL, which are tested against owner-set limits.
4. A stress library (17 scenarios) and reverse stress sit on top.
5. Signals and a playbook produce internal trade ideas.

Release 0.7.0, as_of 2026-10-23:

| Base | VaR99 | ES99 | EL (limit 5) | L-VaR99 |
|---|---|---|---|---|
| Shared data (release) | 66.78 | 88.48 | 4.10 (82%, warning) | 72.06 |
| MVP desk dataset (e60bbc7c…c888) | 66.21 | 87.91 | 4.01 (80.1%, warning) | 71.49 |

Use today is **internal research only** (restriction 6.1). No PD, VaR or ES figure is quoted externally.

## Status against the checklist

| Area | Status | In one line |
|---|---|---|
| Inventory and tiers | Partly met | 16 components tiered; the inventory is at 0.1.4 and misses about 11 newer components (EQ-B-0121) |
| Development documentation | Partly met | One validation document per component, plus an SR 11-7 dossier; the dossier and sensitivities are at 0.1.5 (EQ-B-0126) |
| Conceptual soundness | Partly met | Only the GARCH FX vols and Calm copula loadings are fitted; Layer 1 refit not cleared (AUC 0.61 against 0.75); the tail is set by dependence judgement |
| Data quality | Partly met | Cell-level lineage, quality gate and licence tags; 16% of Inputs cells live; 396 hand-entered cells unattested |
| Monitoring and outcomes | **Not met** | Built (drift, PSI, challengers, gated backtests) but not operating: the forecast record stopped 2026-10-21; one benchmark snapshot (EQ-B-0125) |
| Benchmarking | Partly met / not yet testable | Rating, spread and hazard challengers and an independent recomputation (PASS 141); outcome scoring from 2027-10-23 |
| Independent validation | **Not met** | No validator (GOV-042); engagement pack and NDA data rules ready; pack refresh to 0.7.0 is EQ-B-0126 |
| Governance and change control | Partly met | Hash-chained approvals (7 Tier 1 changes, all approved by the owner as sole operator); no base run archived since 2026-10-24 (EQ-B-0123) |
| Use restrictions | Partly met | Nine restrictions, enforced in the research pack and client-safe code; the licence restrictions are not yet in the policy (EQ-B-0122) |
| Limitations | Met, refresh due | 47 GOV issues, 5 exceptions and 19 VF findings; statuses to refresh (EQ-B-0124) |

## What we think matters most

1. **The tail is a dependence tail.** The base is most sensitive to these judgement parameters, ranked:
   - the global regime switch (one more non-Calm country: VaR99 +15%);
   - the copula loadings (about -13%);
   - nu (ES99 about -13%).

   PD and LGD parameters move single PDs a lot but VaR99 and ES99 by less than 4%. See
   `dossier/sensitivity-tables.md` (0.1.5; to be regenerated).
2. **PDs are not estimated on outcomes.**
   - Layer 1 uses the paper's coefficients.
   - The rating table and the layer 2 weights are judgement.
   - The refit on the World Bank panel failed its gate.
3. **EL is in the warning band and is a net figure.** EL includes carry. It sits at 80-82% of its limit, mostly
   because of one Venezuela position (VF-011, decision D1).
4. **No outcome evidence yet.**
   - The long backtest is synthetic.
   - The forecast record is 60 backfilled days and has stopped.
   - PD scoring cannot start before 2027-10-23.
5. **Single operator.** Every Tier 1 approval and every finding closure is by the owner under logged exceptions,
   which expire 2027-01-22.

## Suggested order of work for the validator

1. Run the replication:
   `python -m econquest.validation.replicate --data data --out <dir>`
   It should give 141 PASS on release inputs.
2. Run the MVP sign-off:
   `python -m econquest.validation.mvp_signoff --as-of 2026-10-23 --data data/mvp/data --reference none --allow-drift`
   It should be bit-identical to 66.21 / 87.91 / 4.01 / 71.49.
3. Re-perform the steps in the "independent validator should re-perform" section of each layer dossier, starting
   with layer 3 (regime switch), layer 5 (copula) and layer 1 (hazard).
4. Grade the findings register (GOV and VF rows) and the use-restriction review.
5. Review the approvals log (`econquest change verify`) and the exception list (EXC-001 to EXC-005).

## Open decisions held for the owner (first Mac pass, section B)

| Decision | What it is |
|---|---|
| D1 | EL warning band options |
| D2 | First values for indicators 1.8, 1.5 and 2.11 |
| D3 to D7 | Client-mode prerequisites |
| D8 | Appoint the external validator |
| D11 | WEO history and full hazard refit |

No restriction can be lifted until D8 and the outcome evidence exist.
