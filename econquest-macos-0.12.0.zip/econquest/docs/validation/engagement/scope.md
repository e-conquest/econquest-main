# Independent validation of econquest: scope

Date: 2026-10-24. Ticket EQ-B-0060 (GOV-042, roadmap 4.5). **Refreshed 2026-10-26 (EQ-B-0126) to releases 0.7.0
and 0.8.0**: sections 1, 2, 4 and 5. Prepared by Team B (model team) for the model owner
to share with candidate validators. Facts are taken from the repository on this date. Anything not checked for
this pack is marked **[unverified]**.

## 1. The model and its use

econquest is a sovereign tail-risk and geopolitical risk engine written in Python (about 98,000 lines in the
`econquest` package on 2026-10-26). It scores 18 countries and simulates a 24-position, 309 $mm notional book of sovereign
exposures: Eurobonds, local bonds, CDS, FX and equity ETFs. The main outputs are:

- a 12-month default probability (PD) per country;
- portfolio VaR, ES and liquidity-adjusted VaR (L-VaR) at 95/99 percent, expected loss, and contributions;
- stress and reverse-stress results;
- limit verdicts and a pre-trade check;
- regimes, signals and trade ideas, and alerts.

Results are published to a Google Sheets workbook, which is a view only. Every reported number must reproduce
from a run id, with code, data and settings hashes stamped in the run archive (`model-risk-policy.md` section 1).

**Use today.** The model is used internally by a one-person desk. The model owner (Sam) is also the acting
approver. Use restrictions 6.1 to 6.14 in `docs/governance/model-risk-policy.md` (version 2) are in force; 6.10 to 6.14
are the licence restrictions (IMF data internal only under EXC-003, the theratesapi FX columns internal only under
EXC-005, GOOGLEFINANCE files restricted, the Cruces-Trebesch workbook never in the shared folder, client output only
from the client-safe run). In particular, no
PD, VaR, ES or L-VaR is quoted externally (6.1). The validation is wanted so that the owner can decide which
restrictions can be lifted, and so that sign-offs no longer read "owner-approved, independent review pending"
(policy principle 4, GOV-042).

**Releases in scope.** 0.1.1 to 0.8.0, dated 2026-10-23 to 2026-10-26. The release notes are in
`docs/governance/releases/` (model notes, `-base` restatements and `-package` notes).

| Release | Main change | Tests at release |
|---|---|---|
| 0.1.1 | Sobol path block 2^17, `as_of` fixed per run, signal 15/19 formula | 322 passed |
| 0.1.2 | Package and platform batch (see `0.1.2-…-package.md`; no model note) | 659 passed, 2 skipped |
| 0.1.3 | Layer 2 risk-premium ratio 2.0, no FX term for pegs (Tier 1, `CHG-20261023T163209Z-b3f8bd`) | 660 passed, 2 skipped |
| 0.1.4 | GARCH 12-month vols in the Monte Carlo, estimated copula loadings (Tier 1, `CHG-20261023T190523Z-b96d25`) | 1,184 passed, 5 skipped |
| 0.1.5 | Rate shocks in FED22/TAPER13 (Tier 2); off-by-default options; validation pack part 1 | 1,637 passed, 5 skipped |
| 0.2.0 | Validation pack part 2, second-line archive replication, evidence clock; options off | 1,868 passed, 5 skipped |
| 0.2.1 | Tier 1: default-loss fix (`default_spread_overlap` lgd_only) and prediction-market prior off (`CHG-20261024T111531Z-dd6de0`) | full suite |
| 0.3.0 | INDA price repair (VF-019); calibration universe pinned; limits signed; DSA, GPR, nowcast, monitoring built off | 2,392 passed |
| 0.4.0 | FX-only official prices approved; DSA signal 26 on (display); missing-input rule; MACRO_ scenarios | 2,856 passed |
| 0.5.0 | Base restated on official FX-only prices; FX GARCH marginals Tier 1 (VF-001); calendar-gated tests | 3,489 passed |
| 0.6.0 | Tier 1: no carry on default paths, GARCH vol floor 0.75 x regime (`CHG-20261025T131946Z-40d55f`); EL in the warning band | 3,886 passed |
| 0.7.0 | Official fx3m (EXC-005 FX); MVP on shared data; method rules 16 to 18 (Tier 2) | 4,137 passed (before fixes) |
| 0.8.0 | No model change; attribution and what-if, house view, governance (policy v2 pending D12), self-assessment | 4,688 passed, 21 skipped |

The current base is the 0.7.0 one, unchanged in 0.8.0: shared data, as_of 2026-10-23, run `20261025T235026-base`,
131,072 Sobol paths: VaR99 66.78, ES99 88.48, EL 4.10 (82% of its 5 $mm limit, warning band) and L-VaR99 72.06 $mm.
A second, MVP desk base on the frozen `data/mvp` dataset reads 66.21 / 87.91 / 4.01 / 71.49 (GOV-050). The figures
are internal and depend on seed and judgement inputs; see section 5.

## 2. Model inventory by tier

The tiers are defined in `model-risk-policy.md` section 2. The component rows are in
`docs/governance/model-inventory.md`.

| Tier | Components | In scope |
|---|---|---|
| **1**: sets a reported or limit-tested number | 1 Scorecard; 2 Layer 1 hazard; 3 Layer 2 Bayesian update; 5 Layer 4 severity; 6 Layer 5 copula; 7 Layer 6 Monte Carlo; 8 L-VaR; 10a GARCH 12-month FX marginals (Tier 1 since 0.5.0, VF-001 resolved); 14 Limits and pre-trade check; 27 Pre-trade what-if and attribution | **Full**: conceptual soundness, implementation, outcomes analysis where data allow, use-restriction opinion |
| **2**: conditions a Tier 1 number or a decision | 4 Layer 3 regimes; 9 Stress and reverse stress; 10b GARCH one-day VaR and DCC; 12 CDS pricer and curves; 13 PD benchmarks; 15 Alerts; 16 Signals and GPR; 17 DSA signal 26 (display only); 21 Macro scenario engine | **Full** for 4, 9 and 10b. **Design and monitoring only** for 13, 15, 16, 17 and 21. **Design review only** for 12: no licensed curve, `data/cds_quotes.csv` has 0 rows |
| **3**: research or illustration | 11 Econometrics toolkit; 18 Event stress index (off); 19 Nowcast; 20 Shadow ratings; 22 Restructuring scenarios (off); Kelly stakes; HMM demo | Out of scope, except toolkit Table 8 (copula family choice), the data support for layer 5 |
| **Control tools** (no model number) | 23 Client-safe run; 24 Model monitoring; 25 Calendar-gated formal tests and interim backtest; 26 MVP pack and numbers sign-off | Implementation and design; 23 is the input for any client-mode decision (GOV-049) |

**Also in scope:**

- **Controls:** the run archive and versioning (`econquest/versioning.py`); change control (`econquest change`, `docs/governance/change-control.md`); the data quality gate; the revalidation routine (`docs/governance/revalidation-routine.md`).
- **The two backtest tools** (`econquest/validation/backtests.py`, `validation/record.py`): implementation only (see section 5).

**Out of scope:**

- the Google Sheets workbook formulas (a view);
- the GUI and report rendering;
- installer and operations scripts;
- data-feed connectivity. The cloud build cannot reach IMF, World Bank, BIS or ECB; live fetches run on the owner's machine.

**Off by default.** Options that are built but switched off are in scope as design only, unless the owner asks
for an opinion on adopting one:

- fitted layer 1 (`layer1.mode` fitted);
- HMM regimes;
- the logistic global switch;
- fitted LGD;
- BIS contagion;
- the event stress index;
- bond RV;
- CDS curves.

## 3. Validation standard

The standard is US SR 11-7 / OCC 2011-12 or an equivalent the validator proposes, such as UK PRA SS1/23
principles. The validator should state which standard applies. The three elements are:

1. **Conceptual soundness.** Is the model form fit for purpose? Are the assumptions and judgement values
   reasonable? Are the data adequate? Are the limitations disclosed?
2. **Ongoing monitoring.** Do the revalidation routine, thresholds, alerts, change control and versioning
   detect a model that has stopped working? Process verification includes reproducing the reported numbers from
   the code.
3. **Outcomes analysis.** Backtests, benchmarking against rating-, spread- and market-implied PDs, and the
   forecast record. Some of this cannot be performed before 2027 (`timeline.md`). The validator should say what
   can be concluded now and what must wait.

## 4. Deliverables requested

1. **A validation report** covering each in-scope component, with the validator's assessment under each of the
   three elements.
2. **Findings by severity,** with evidence and a recommended remediation for each. A finding is either:
   - one of the 69 rows in `docs/validation/dossier/findings-register.csv` (GOV-001 to GOV-050 bearing on a
     layer, VF-001 to VF-019), marked accepted, rejected or re-graded; or
   - a new finding.

   The model team's own scale is High, Medium or Low, as defined in `docs/governance/issues-log.md`. The
   validator may use its own scale if it maps it to that one.
3. **A use-restriction opinion.** For each of restrictions 6.1 to 6.9, the validator should say whether it can
   be lifted, narrowed or must stay, and on what conditions. Restrictions 6.10 to 6.14 are licence terms, not model
   judgements: the validator is asked only whether they are applied (the client-safe run, the data-room filter).
4. **A tiering opinion,** which can be short: whether the tier assignments in the inventory are right (in
   particular the 10a / 10b split and the control-tool rows 23 to 26).
5. **Re-validation scope** for the calendar-gated outcomes tests in 2027, including an opinion on the acceptance
   rule of the formal VaR test (the rehearsal found that a correct forecast fails it 22-25% of the time,
   `docs/validation/calendar-test-rehearsal.md` RF-2) and on pass/fail rules for the PD benchmark and idea scoring,
   which do not exist yet.

## 5. Evidence available, and its quality

| Evidence | Where | Note |
|---|---|---|
| Validation documents (one per component, common ten-heading template, 11-step review checklist) | `docs/validation/*.md`, `docs/validation/README.md` | Written by the model team |
| Validation dossier parts 1 to 3 (one file per layer, with "independent validator should re-perform" steps) | `docs/validation/dossier/` | Written by the model team: part 1 (0.1.4, EQ-B-0051), part 2 (0.1.5, EQ-B-0057) and part 3 (0.7.0 / 0.8.0, EQ-B-0126), each layer ending with its part 3 status |
| Sensitivity tables, regenerated on the current base | `docs/validation/dossier/sensitivity-tables.md` (.csv), `sensitivity_tables.py` | 45 one-at-a-time rows at 20,000 paths; base bit-identical to the release 20k base |
| Findings register: 69 rows (GOV-001 to GOV-050 bearing on a layer, VF-001 to VF-019) | `docs/validation/dossier/findings-register.csv`, `econquest.validation.findings` (hash-chained tracker) | VF status cells are current as of 2026-10-25 (VF-001, VF-008, VF-015, VF-016 resolved) |
| Issues log and exceptions (GOV-001 to GOV-050, EXC-001 to EXC-005) | `docs/governance/issues-log.md` | |
| Model-risk self-assessment (SR 11-7 style, gaps G-01 to G-09) | `docs/governance/model-risk-self-assessment.md`, `self-assessment-summary.md` | Written by the model team (EQ-B-0116) |
| Replication script: recomputes the release numbers and the key numbers in the validation documents from public functions and frozen inputs, without reading archived runs | `econquest/validation/replicate.py`; `python -m econquest.validation.replicate --data data --out <dir>` | 141 PASS, 2 INFO, 0 FAIL at 0.8.0 (lead rerun on a fresh local copy) |
| Test suite | `tests/` (313 files) | 4,688 passed, 21 skipped at 0.8.0 |
| Run archive, change records, approvals chain | `outputs/store/` (0.7.0 base archived on the package code hash; 0.5.0 and 0.6.0 bases as labelled reconstructed entries), `data/approvals/log.jsonl`, `docs/governance/change-log.md` | Not in the data-room file list: delivered through Team C's evidence bundle |
| Frozen release inputs | `docs/governance/releases/inputs/<version>/` | GOOGLEFINANCE-era price files (0.1.4, 0.2.1, 0.3.0) and the Yahoo-era 0.6.0 countries.csv are excluded from the room (data-room-files.md); RELEASE-HASHES.json per release (VF-003 open) |
| Data-room file list with licence filter | `docs/validation/engagement/data-room-files.md` (.csv), `python -m econquest.validation.data_room_list` | Paths, sizes, sha256 and reasons only, no values |

**Synthetic, placeholder or judgement inputs.** The validator should not treat these as evidence:

- **Synthetic:**
  - the 120-month backtest history `data/backtest_history.csv` is drawn from the model itself (GOV-028, restriction 6.3);
  - the HMM recovery test is synthetic (GOV-019);
  - the CDS curve fixtures are synthetic (EQ-B-0048), and so are the vendor-curve rehearsal (EQ-B-0129) and the
    calendar test rehearsal (EQ-B-0131).
- **Placeholder:** all 18 prediction-market prices (GOV-016, restriction 6.2). Since 0.2.1 they no longer reach any
  PD (`use_market_prior` false).
- **Seed estimates:**
  - a large share of indicator cells (about 85 percent at 0.1.5, 224 of 1,494 live; the live share has grown with
    Team A's batches and is reported by `ingestion.limitations`, not restated here **[unverified today]**) (GOV-010,
    GOV-036);
  - spreads, ratings and several regime inputs are hand-entered.
- **Compiled from memory:** the sovereign default list `data/panel/sovereign_defaults.csv` (±1 year, GOV-044). It labels the benchmark outcomes; the hazard refit can use CRAG events instead (`--events crag`). The restructuring haircut table is typed in from memory and labelled UNVERIFIED (GOV-024).
- **Judgement:**
  - layer 1 coefficients (paper-mode; the pilot fit did not clear its gate, GOV-006);
  - the layer 2 weights and the risk-premium ratio 2.0 (GOV-013);
  - the regime rules and transition matrix (GOV-018, GOV-019);
  - the LGD means and dispersion (GOV-024);
  - the copula tail df and regime steps (GOV-021);
  - the stress sizes (GOV-026);
  - the limits (GOV-041).
- **Underpowered:** the forecast record has 60 backfilled rows (GOV-029, restriction 6.4).
- **Fitted on real data:** GARCH/DCC and the copula loadings on the official FX-only price history (BIS/ECB, plus
  the theratesapi mirror columns under EXC-005) since 0.5.0, and the econometrics toolkit. No ETF series remain, so
  equity legs use judgement vols.
