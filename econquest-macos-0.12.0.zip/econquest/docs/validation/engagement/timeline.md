# Engagement timeline (proposed)

Date: 2026-10-24, refreshed 2026-10-26 for releases 0.7.0 and 0.8.0 (EQ-B-0126). Ticket EQ-B-0060. The durations below are the model team's planning estimates, not quotes from
any validator. A candidate should replace them with its own plan in its proposal.

## Two stages

The engagement has two stages because some outcomes tests cannot be done before 2027:

- **Stage 1 (now):** conceptual soundness, implementation and process verification, and the outcomes analysis
  that today's data allow.
- **Stage 2 (Q4 2027):** a targeted follow-up on the calendar-gated tests.

## Stage 1 phases

| Phase | Weeks | Starts after | Work | Owner side provides |
|---|---|---|---|---|
| 0. Selection and contract | 2-4 | RFP sent | Proposals, clarification questions, conflict checks, NDA, engagement letter | RFP (`rfp.md`), questions deadline, a decision |
| 1. Kickoff | 1 | Contract signed | Agree scope, standard, severity scale and materiality; walk through the model; confirm the data room list | A named contact; a 2-hour walkthrough |
| 2. Data room | 1-2 | Kickoff | Validator gets a read-only snapshot and confirms it can run the suite and `replicate.py` in its own environment | Snapshot (see below), environment notes, data-licence confirmations |
| 3. Fieldwork | 6-8 | Data room confirmed | Replication; review of each in-scope component against the dossier's re-perform steps; questions A-F; challenge sessions | Answers to written questions within 5 working days (the policy's owner duty) |
| 4. Draft report | 2 | Fieldwork | Draft findings by severity, use-restriction opinion | — |
| 5. Management response | 2 | Draft | Owner accepts or disputes each finding, with an owner and target for each; findings logged as GOV issues | Written responses |
| 6. Final report | 1 | Responses | Final report and sign-off scope; the validator countersigns or declines the open "independent review pending" sign-offs | — |

The Stage 1 critical path is about 13 to 16 weeks from contract to final report. If a contract were signed in
late November 2026, the final report would fall around March 2027. That date is illustrative only.

## Dependencies

| Dependency | Effect if missing | Status | Who |
|---|---|---|---|
| Hazard refit on the full default panel (`fit-hazard --fetch`, CRAG workbook replacing the memory-compiled list) | Layer 1 can be judged only as paper-mode. Restriction 6.1 cannot be assessed for lifting | Pipeline built; one-command World Bank refit (`validation/hazard_wb_refit.py`, 0.8.0). No refit has cleared the gate (World Bank refits OOS AUC 0.60 to 0.61). The CRAG-event refit is deferred with the WEO history (GOV-006, GOV-044) | Sam |
| Real CDS quotes or another spread feed (roadmap 1.3, needs a data licence) | The CDS pricer stays design-only. The layer 2 market term rests on hand-entered spreads | Vendor CDS curves can feed the market term since 0.6.0, but the switch is off: no vendor licence is approved, and synthetic or fixture curves are refused (GOV-040, 6.7) | Sam (licence) |
| Restructuring haircut dataset for the LGD fit | Severity is assessed on judgement means only | Fit code built (EQ-B-0037); refit path for the Cruces-Trebesch workbook (0.6.0). The workbook's licence is UNVERIFIED, so it is never in the shared folder or the data room (6.13, GOV-024) | Sam (licence) |
| Real P&L history (roadmap 2.1) | No meaningful VaR backtest. The synthetic one stays excluded (6.3) | Not started (GOV-028). The daily forecast record holds 60 of 250 rows; first formal VaR test date 2027-07-14 | Sam |
| Better live input coverage (roadmap 1.3, 1.4) | Scorecard and regime findings stay conditional on seed inputs | 224 of 1,494 cells live at 0.1.5; the share has grown with Team A's batches and is reported by `ingestion.limitations` (GOV-010, GOV-036) | Sam |

Stage 1 can start without any of these. The report should state which conclusions are conditional on each one.
If the hazard refit happens during fieldwork, the validator should agree a cut-off date for the model state it
reviews.

## Calendar-gated tests (Stage 2)

These cannot be done before 2027:

| Test | Earliest | Source |
|---|---|---|
| First quarterly revalidation under the routine | 2027-01-23 | `docs/governance/revalidation-routine.md` |
| PD benchmark scoring (Brier, log loss, AUC against 12-month outcomes; model compared with rating, spread and market PDs) | 2027-10-23 | `econquest/validation/benchmarks.py`; snapshots dated 2026-10-23 |
| Forecast record at 250 daily rows (formal VaR test: Kupiec, Christoffersen cc, Z2 and McNeil-Frey; Basel zone reported) | 2027-07-14, if `record` runs every business day (60 rows on 2026-10-26) | GOV-029, restriction 6.4; acceptance rule open, `docs/validation/calendar-test-rehearsal.md` RF-2 |
| Signal hit rates over four quarters | about 2027-10, counting from when signals were first archived per run (0.1.2) | Restriction 6.5 |

A Stage 2 follow-up of about 3 to 4 weeks after 2027-10-23 would cover these tests and the first year's
revalidation records.

## What the owner (Sam) must provide

1. **A single named contact,** with time for the kickoff, challenge sessions and the 5-day written-answer turnaround.
2. **Access.** A read-only snapshot of the files admitted by `data-room-files.md` (code, `data/`, `docs/`, `tests/`, scripts), checked against its sha256 column, plus the run archive under `outputs/store/` delivered through Team C's evidence bundle. The snapshot must carry the release hash manifests (`RELEASE-HASHES.json`), because the folder is not under version control (VF-003). Also view-only access to the workbook, if the validator wants it.
3. **Environment notes.** The Python version and dependencies, and the fact that live fetches (IMF, World Bank, BIS, market prices) run on the owner's machine, not in the snapshot.
4. **Data licences.** The data room is filtered by `data-room-files.md` (EQ-B-0126): GOOGLEFINANCE files, Yahoo-era files and the Cruces-Trebesch workbook are excluded; IMF data (EXC-003) and the theratesapi FX columns VES/NGN/PKR/VND/ZMW (EXC-005) are admitted under NDA only and labelled. Files whose register row says validator_nda UNVERIFIED (`data/benchmarks.csv`, `data/panel/sovereign_defaults.csv`, `data/panel/universe_staging/`) are withheld until the owner decides. Any vendor data added later needs its own register row.
5. **Decisions before kickoff:**
   - which standard to name;
   - whether off-by-default options are in scope for an adoption opinion;
   - whether the validator also becomes the approver of record, or reviews only. Policy section 3 allows either a head of risk or the validator to be the approver.
