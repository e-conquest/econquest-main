# Tier 1 card (pre-draft, NOT proposed): default-event panel for the hazard refit to BoC-BoE (CRAG)

Pre-drafted by Team B AGENT-03 under EQ-B-0087, 2026-10-25. **Nothing has been proposed.**

> **Status: deferred to PI-9.** Sam deferred the WEO history pull to PI-9 (EQ-A-0087). The real refit cannot run
> until `data/panel/weo_history.csv` lands, so this card waits too. Do not propose it in PI-8.

This text waits for the real refit on Sam's Mac. Team B fills the bracketed figures from
`outputs/hazard-refit/2026-10-23-crag/gate-report.json` and proposes only after Sam has read the numbers.

---

**Change.** Make the BoC-BoE Sovereign Default Database 2026 (CRAG) the default-event source of the layer-1 hazard
refit, with the crag_v1 event rule. One new key in `assumptions.json`:

```json
"layer1": { "refit_events": { "source": "crag", "min_amount_musd": 10, "cure_years": 2 } }
```

**What it changes.** Only which episodes `econquest.validation.hazard_refit` uses when no `--events` is given. No
engine code reads the key, so no run, VaR, ES, EL or PD changes when it is applied. The hazard coefficients and
`layer1.mode` are a separate Tier 1 change (the refit's change pack). Dry-validated on a scratch copy: tier 1,
validator flag not set by the tool, 1 diff entry (`/layer1/refit_events`).

**Why.**

- The current list (`sovereign_defaults.csv`) was compiled from memory, has no source per episode and fails the
  refit's `episodes_sourced` preflight check (GOV-044). It has 27 default starts in 2008-2025, below the gate's 30.
- CRAG is the published BoC-BoE database (Valet export DEBT_2026, sha256 `7b6e696a...`), imported by Team A with a
  source and vintage on every row (210 spells, 99 countries; panel vintage `2026-10-24T190434Z-03d9c4c4`).
- Under crag_v1 it has 48 starts in 2008-2025 and, in the SYNTHETIC dry run, passes every preflight check.

**The event rule (crag_v1), and the judgement calls.** Full reasons in `docs/validation/hazard-panel-crag.md`.

- Defaults are arrears on FC bank loans, FC bonds and LC debt. Official-only arrears do not count.
- A year counts only when its own in-scope amount is above USD 10m (drops sub-USD-1m arrears such as Senegal 2021,
  Cameroon 2019). Results are stable for floors from 1 to 25.
- A new event needs at least 2 clean years after the last spell (one clean year is treated as the same episode).
- Point in time: at as_of, later starts are dropped and later end years are cut.
- Known cost: CRAG keeps Argentina (2001-2025) and Ecuador (2008-2025) continuously in default, so Argentina 2014,
  Argentina 2020 and Ecuador 2020 are not events and both countries leave the at-risk set for 2007-2025. Desk
  events in the window: 7 on the current list, 6 on crag_v1.

**Reconciliation with the current list.** 46 spells identical, 48 with different years, 14 only in the current
list (5 absorbed by longer CRAG spells, 6 with no CRAG spell, Laos 2022 the only one in the refit window), 116 only
in CRAG (27 countries not in the current list; 29 starts in the window, 6 removed by the floor and cure rule).

**Evidence from the real refit (to fill).**

| | current list | CRAG, crag_v1 |
|---|---|---|
| outcome | [PREFLIGHT FAILED expected] | [ ] |
| countries / ever-defaulted share | [ ] | [ ] (limit < 0.55) |
| default starts in the panel | [ ] | [ ] (gate >= 30) |
| OOS AUC | [ ] | [ ] (gate >= 0.75) |
| OOS Brier vs trailing base | [ ] | [ ] |
| CRAG as imported (floor 0, cure 1), OOS AUC / events | | [ ] |

**Risks.** The floor is absolute, not relative to GDP (revisit once the WEO history has GDP). One CRAG vintage
(2026) is used for every as_of. The ever-defaulted share sits near the preflight limit; a WEO history with fewer
than about 173 economies would fail it. The terms of use for BoC-BoE data (https://www.bankofcanada.ca/terms/)
are not yet confirmed for the data room (data/panel/README.md).

**Rollback.** Remove `/layer1/refit_events` (or set `"source": "current"`). Nothing else depends on it.

**Command (for Team B or Sam to run after reading the numbers; replace the author):**

```bash
econquest change propose assumptions.json --set '/layer1/refit_events={"source": "crag", "min_amount_musd": 10, "cure_years": 2}' --tier 1 --allow-new-keys --author '<NAME>' --reason 'EQ-B-0087: hazard refit default events from BoC-BoE (CRAG) 2026 with crag_v1 (USD 10m floor per year, 2-year cure); see docs/validation/hazard-panel-crag.md'
```

Approval: `econquest change approve <CHG-id> --approver "Sam"` (not the author), then `econquest change apply
<CHG-id>`. Team A's swap of `sovereign_defaults.csv` itself (EQ-A-0008 part 2) is not needed for this change.
