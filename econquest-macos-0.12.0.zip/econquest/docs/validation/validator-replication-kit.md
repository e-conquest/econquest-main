# Validator replication kit: runbook (EQ-B-0143, PI-14)

For an independent validator who receives the econquest code package and a data room, and has never seen the code.
One command checks that what you received is what was sent, reruns every pinned model result from the data room's
inputs, and tells you, check by check, whether it reproduces.

Code: `econquest/validation/validator_kit.py` (it reuses `validation.replicate`, Team A's data-room verifier, the
licence filter of `validation.data_room_list` and the drift classifier `validation.drift_cause`). Tests:
`tests/test_validator_kit.py`.

## 1. What you need

| Item | Where it comes from |
|---|---|
| The code package (econquest, with `docs/`, `tests/`) installed with `pip install -e .` or unzipped | the model owner |
| The data room folder (`MANIFEST.json`, `README.md`, `verify.py`, `data/`, `limitations/`) | the model owner (Team A builds it, `python -m econquest.ingestion.dataroom build`) |
| The room's `manifest_sha256` (64 hex) | sent to you **separately** from the room |
| The code hash of the package (16 hex) | sent to you **separately** from the package |
| The release whose numbers you are checking, e.g. `0.10.0` | the engagement letter / release note |

No network is needed or used. Python 3.10 to 3.13 with the packages of `requirements-lock.txt`.

## 2. The command

```
python -m econquest.validation.validator_kit run \
    --room /path/to/2026-10-26T062415Z-DEMO \
    --out  /path/to/kit-run-1 \
    --release 0.10.0 \
    --expect-manifest-sha256 <the 64-hex value sent to you> \
    --expect-code-hash <the 16-hex value sent to you>
```

Every argument is required: the kit never guesses a date, a release or a hash. `--out` must be a new folder outside
the room and outside the code tree, or under the code tree's `outputs/` (never the code tree's root, a folder
that contains it, or any other folder in it; the rule of EQ-B-0138).

Other commands:

```
python -m econquest.validation.validator_kit list        # every unit: what it proves, what it needs
python -m econquest.validation.validator_kit code-hash   # the code hash of the installation you run
```

Exit codes: `0` no FAIL (only PASS, DRIFT or NOT RUN), `1` at least one FAIL, `3` REFUSED (verification failed;
nothing was run), `2` usage error.

## 3. What happens, in order

1. **Verification first.** The room is verified with the same code its own `verify.py` runs (every file's sha256
   and size, missing / extra / changed files, `manifest_sha256` and `content_sha256` recomputed, the integrity anchors
   of each store) and the recomputed `manifest_sha256` must equal the value you received. The code hash of the
   installation must equal the value you received. If either fails, the report says **REFUSED** and nothing runs.
2. **Inputs from the room only.** The release's input list is
   `docs/governance/releases/inputs/<release>/RELEASE-HASHES.json`. Each input is taken from the room only when a room
   file has exactly that hash; it is copied to `<out>/work/data/`. A redacted copy (restricted cells blanked) or a
   later copy is **never** used in its place: the input is reported missing, with the room's own reason. Files no
   release hash covers (the forecast record, the workbook reference, the licence register, the live and panel
   vintages) are used as the room has them and are labelled *unpinned*.
3. **Code-tree inputs follow the licence filter.** Some checks read frozen files shipped with the code (release price
   histories, the 0.6.0 Country Profile, seed data, a CDS fixture). With the default `--code-inputs validator`, a
   file that `validation.data_room_list` excludes from the validator room, or whose content equals a file the room
   withheld or redacted, is not used, and the checks that need it are NOT RUN. (`--code-inputs all` is for the
   model owner's internal check only.)
4. **Rerun, offline, writing only under `--out`.** Connections to any non-loopback address and name lookups (DNS)
   other than `localhost` are refused for the whole run; the working directory and the temporary directory are inside `--out`; no bytecode is written. The code
   tree and the room are snapshotted before and after, and the room is verified again at the end. The report's
   *Guards* section shows the result.
5. **Compare and report.** `<out>/report.md` (read this) and `<out>/report.json` (the same as data).

## 4. Reading the report

| Status | Meaning | What to do |
|---|---|---|
| PASS | Recomputed from the room's inputs and equal to the pin within the stated tolerance. A bit-identical pin (the 20,000-path base) has tolerance 0 | Nothing |
| DRIFT | Moved from the pin for a recorded reason: a document value known to predate a recorded change (replicate STALE, inside its drift band), or a difference inside the 0.1% platform allowance. The cause column names the change ids found in the room's approvals log and vintages and the code's release notes (`drift_cause`) | Confirm the named change explains the move |
| FAIL | Outside the tolerance with no recorded reason | A finding: report it |
| NOT RUN | An input the check needs is not available to you; the reason says which (withheld or redacted by the room, excluded by the licence filter, not in this room) | Not a pass. Ask the model owner for the input, or record the gap |

The report has, in this order: the counts; what was verified; every input with its status and room source; the
provenance against the pinned release (code hash and data hash then and now, the recorded changes in between); one
section per unit with **what it proves**, the **command to rerun only that unit**, **where its evidence is**, and one
row per check (pin, recomputed value, tolerance, cause or reason, the document the pin comes from); the guards.

## 5. The units

| Unit | Checks | What it proves | Needs |
|---|---|---|---|
| `base_20k` | 4 | The current code on the release inputs gives the published base bit-identically (VaR99 66.95612571109443, ES99 89.00003057231508, EL 4.098636048964449, L-VaR99 72.23763153780678; as_of 2026-10-23, 20,000 requested paths) | every release input the base reads |
| `release_base` | R48-R51 | The 0.7.0 base table at 100,000 paths (66.78 / 88.48 / 4.10 / 72.06) | the same, plus the frozen 0.5.0 prices (admitted under NDA, EXC-005) |
| `release_history` | R01-R47 (R30-R31 are information) | The 0.1.4 to 0.6.0 release tables | frozen 0.1.4 / 0.2.1 / 0.3.0 prices and the 0.6.0 Country Profile: **excluded** from the validator room (GOOGLEFINANCE terms; Yahoo-era fx3m) |
| `docs` | D01-D16 (42) | The numbers quoted in the validation documents | frozen 0.1.4 prices and the 0.6.0 Country Profile (excluded) |
| `backtest` | B01-B15 | Kupiec, Christoffersen, Z2, Basel zone, verdict | `backtest_history.csv`, the forecast record |
| `hazard_stored` | H01-H20 | The layer-1 logit refit on the stored panel | `panel/hazard_panel.csv` |
| `hazard_rebuilt` | H21-H25 | The panel rebuilt from the raw WEO file and the default-episode list | `panel/sovereign_defaults.csv` (validator_nda UNVERIFIED: withheld until the model owner decides) |
| `scorecard` | S01-S04 | Scorecard and regimes equal the original workbook on the seed snapshot | `tests/seed_data/` and the workbook reference |
| `garch` | G01-G06 | GARCH and DCC refits of garch-dcc.md | frozen 0.1.4 prices and INDA overlay (excluded) |
| `depth_views` | 6 | Depth views build at 2026-10-26 from the room's vintages, schema eq-depth-views/1, all four sovereign views | the base inputs, `dsa_inputs.csv`, the room's vintages |
| `text_index_demo` | 4 | The text stress index method on its SYNTHETIC sandbox (ZMB warns, SGP calm, switch off) | `assumptions.json` |
| `overlay_demo` | 3 | The analyst overlay on the base run in a SYNTHETIC sandbox (9 rows, 7 entries, four-eyes, caps, ledger) | the base inputs |
| `calendar_rehearsal` | 4 | The 2027 calendar-gated tests on SYNTHETIC records (49 hand checks, 10 job runs). The scheduled-job leg starts a subprocess and is NOT RUN inside the kit; run `python -m econquest.validation.calendar_rehearsal --out DIR` for it | nothing from the room |
| `layer2_cds_e2e` | 15 | Layer 2 on FIXTURE vendor CDS curves end to end: switch off equals the 20k base exactly, nine guards hold, 7 curves used when on | the base inputs, the CDS fixture |

**Rerun one unit:** add `--only UNIT` (comma list allowed) with a new `--out`; the exact command is printed under each
unit in the report. The replicate units can also be run on the assembled inputs directly:
`python -m econquest.validation.replicate --data <out>/work/data --out DIR --only GROUP`.

## 6. Where the evidence lives

| Path under `--out` | What | Licence |
|---|---|---|
| `report.md`, `report.json` | The report (schema `eq-validator-kit/1`) | Model results only; no input data value is copied into it |
| `evidence/base_20k/run.json` | The base run's metrics and version stamps | NDA only |
| `evidence/depth_views/` | depth_views.csv / .json, programme_backtest_proxy.csv | NDA only (IMF-derived rows, EXC-003) |
| `evidence/text_index/` | SYNTHETIC index rows and the sandbox corpus | SYNTHETIC |
| `evidence/analyst_overlay/` | SYNTHETIC overlay sandbox (ledger, rows, entries, audit) | SYNTHETIC entries on the base run's model values (NDA) |
| `evidence/calendar_rehearsal/` | rehearsal.json, checks.csv, job_sequence.csv, rehearsal.md | SYNTHETIC |
| `evidence/layer2_cds_e2e/layer2_cds_e2e.json` | Effect table and guards | FIXTURE on the base inputs (NDA) |
| `work/data/` | The inputs as assembled from the room | NDA only (EXC-003 IMF, EXC-005 theratesapi) |

Everything under `evidence/` and `work/` is for validating this model under the NDA only: do not reuse, republish or
pass it on, and never put it into client-facing material.

## 7. Result on Team A's DEMO room (2026-10-26T062415Z-DEMO, local copy, 2026-10-26)

Command as in section 2 with `--release 0.10.0`, the room's manifest_sha256
`5a9ee799c92c1a9eb23e2b62df73d7e45846b839d2ce29e1779f9cb032e03c18` and the local code hash.

| PASS | DRIFT | FAIL | NOT RUN | of |
|---:|---:|---:|---:|---:|
| 42 | 0 | 0 | 135 | 177 |

Verified first: room VERIFIED against the manifest_sha256 sent separately (155 files, 12 withheld, 18 redacted, 0
anchors failed); code hash matched. Guards: 0 network attempts, no write outside `--out`, room verified again after.
PASS: `backtest` 15, `hazard_stored` 20, `text_index_demo` 4, `calendar_rehearsal` 3. Runtime about a minute.

What stops the rest (each is a NOT RUN reason in the report, not a failure of the model):

| Unit(s) | NOT RUN because |
|---|---|
| `base_20k`, `release_base`, `depth_views`, `overlay_demo`, `layer2_cds_e2e` (32 checks) | the room has no copy of the release `countries.csv` (its copies are the 0.7.0-apply snapshot, with 5 Yahoo-era fx3m cells blanked, and the pre-apply backup) and withholds `rulebook.csv` (rows naming a restricted source in a CSV with no blankable value column, SEC-A-006 M2). The base run cannot load without either |
| `release_history`, `docs`, `garch` (93 checks) | they rest on the frozen 0.1.4 GOOGLEFINANCE price history and INDA overlay and on the Yahoo-era 0.6.0 Country Profile, which the licence filter excludes from the validator room |
| `hazard_rebuilt` (5) | `panel/sovereign_defaults.csv` is withheld (register row validator_nda UNVERIFIED: the model owner has not decided) |
| `scorecard` (4) | `tests/seed_data/rulebook.csv` is byte-identical to the `rulebook.csv` the room withholds, so it is not passed on: `data_room_list` excludes such copies (EQ-B-0143, lead decision) and the kit refuses them too. S01-S04 run once the room may carry `rulebook.csv` (HO-20261026-B-A-011) |
| `calendar_rehearsal` scheduled leg (1) | runs a subprocess; outside the kit's in-process guards by design |

On a complete internal room (built locally by the model owner's side with every input included, scratch only, never
shared) the kit gives PASS 176, DRIFT 0, FAIL 0, NOT RUN 1 (the scheduled leg): the 141 replicate checks, the bit-identical 20k base and the 31 component checks; with `--code-inputs validator` on the same room it gives PASS 83, NOT RUN 94 (the 93 checks on excluded inputs and the scheduled leg):
that second line is the most an outside validator can reproduce today under the licence filter.

## 8. For the model owner (before sending)

- Send the `manifest_sha256` and the code hash by a different channel from the room and the package.
- Build the room with the release's inputs in it (see the open items of EQ-B-0143: today's DEMO room has neither the
  release `countries.csv` nor `rulebook.csv`, so the pipeline units cannot run).
- Decide `panel/sovereign_defaults.csv` (validator_nda UNVERIFIED): until then H21-H25 are NOT RUN.
- The older release tables, the document numbers and the GARCH refits rest on GOOGLEFINANCE-era and Yahoo-era inputs
  that the licence filter excludes: an outside validator cannot rerun them, and the report says so check by check.
