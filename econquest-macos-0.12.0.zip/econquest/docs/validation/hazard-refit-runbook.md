# Runbook: hazard refit after the full-panel pull (Sam's Mac)

Ticket EQ-B-0067 (unblocks EQ-B-0014 and EQ-B-0020; VF-012). Owner: Team B, AGENT-05. Operator: Sam.
Written 2026-10-24. Tool: `econquest/validation/hazard_refit.py` (tests: `tests/test_hazard_refit.py`).

This page should live at `docs/runbooks/B-hazard-refit.md`. That folder has no Team B ownership row yet
(`team/ownership.csv` covers `docs/runbooks/A-*` only), so it is kept here until Team C adds one.

## What it does

One command takes the landed panel to a gate result:

1. Reads `data/panel/weo_history.csv` (vintaged WEO history) and the default episodes: by default the current
   list `data/panel/sovereign_defaults.csv`; with `--events crag` the CRAG file `data/panel/sovereign_defaults_crag.csv`
   under the crag_v1 event rule (EQ-B-0087, `hazard-panel-crag.md`). Nothing published after `--as-of` is read.
2. Builds the balanced, point-in-time panel: every economy in the history (not only the desk), predictors lagged
   one year, each value from the latest WEO release published by the end of the row year, rows from 2007.
3. Checks the panel (preflight), fits the Firth logit, runs the rolling out-of-sample test and applies the gate:
   OOS AUC at least 0.75, at least 30 default starts, OOS Brier below the trailing base rate.
4. Checks whether fitted mode would run on the desk data at as_of (VF-012), and runs the pipeline before and after
   (20,000 paths) for the expected-effect table.
5. Writes `gate-report.md` and `gate-report.json`. Only if the gate clears, it also writes `change-proposal.md`
   and two patch files with the exact `econquest change propose` commands.

It never proposes, approves or applies a change, and never writes `data/assumptions.json` or `docs/`.
The shipped hazard coefficients stay as they are until a proposal is approved and applied.

A dry run on a SYNTHETIC full panel (72 invented economies, releases 2007-10 to 2025-10, 49 default starts) is in
`docs/validation/hazard-refit-dry-run/`. Its figures test the chain only; they say nothing about the model.

## Steps, in order

Run from `~/econquest`. Keep every log.

**0. Smoke test (about a minute, no network).** Checks the install before the long pull.

```bash
.venv/bin/python -m econquest.validation.hazard_refit --as-of 2026-10-23 --synthetic-dry-run --effect-paths 0
echo "exit code: $?"
```

Expect `SYNTHETIC outcome: CLEARED (exit 0)`. Anything else: stop and send the output to Team B.
The output goes to `outputs/hazard-refit/2026-10-23-synthetic/`. Delete that folder afterwards if you like.

**1. Pull the history.** `docs/runbooks/A-full-panel-fetch.md` steps 0 to 2b. It must end with exit code 0
(`complete: run <id>`).

**2. Import CRAG and review.** Same runbook, steps 3 and 4. Note `checks` in `outputs/panel-coverage-<date>.json`.

**3. Run the refit.** Since EQ-B-0087 the exact sequence is in "CRAG default events (EQ-B-0087)" below: run it
instead of the single command here. Without `--events crag` the refit uses the current list and stops at
PREFLIGHT FAILED (episodes_sourced).

```bash
caffeinate -i .venv/bin/python -m econquest.validation.hazard_refit --as-of 2026-10-23 2>&1 | tee outputs/hazard-refit-$(date +%Y%m%d-%H%M).log
echo "exit code: ${PIPESTATUS[0]}"
```

Use the as_of of the current base run (2026-10-23 for 0.2.1), so the effect table compares with the release
figures. A later date is fine; nothing published after it is read. The run should take a few minutes (estimate:
the synthetic dry run with both 20,000-path pipeline runs took under a minute in the cloud). Output: `outputs/hazard-refit/<as_of>/`.

Do not use `econquest fit-hazard --build-panel` for this decision. It overwrites
`docs/validation/hazard-fit-report.md`, keeps pre-2007 rows built from the earliest release (not point in time) and
has no preflight checks. The refit tool writes only under `outputs/`.

**4. Read the outcome.** The last lines of the log and the top of `gate-report.md` say which of these it is.

| Exit | Outcome | What it means | What to do |
|---|---|---|---|
| 0 | CLEARED | The panel passed every preflight check and the fit passed the gate. `change-proposal.md` is written. | Step 5. |
| 1 | NOT CLEARED | Right panel, but the fit failed at least one gate check (the table shows by how much). No change pack. | Nothing to propose. Layer 1 stays in paper mode and restriction 6.1 stays. Upload (step 6); Team B reviews under EQ-B-0020. |
| 3 | PREFLIGHT FAILED | The panel is not the one the gate is for. Fit and gate figures are shown for information only. No change pack. | Fix the input named in the failing row (table below) and rerun step 3. |
| 2 | INPUT ERROR | A file is missing or unreadable (message on screen). Nothing was fitted. | Usually step 1 or 2 did not finish. Rerun it. |

Preflight rows and their usual fix:

| Failing row | Usual cause | Fix |
|---|---|---|
| weo_vintaged, point_in_time | `weo_history.csv` has no `vintage` column (an old one-shot fetch) | Redo step 1 with `panel_history` |
| pit_start | first WEO release later than 2007 | Check `--list-vintages`; tell Team B which releases are missing |
| balanced_countries (fewer than 60) | history pull incomplete, or CRAG names unmapped | Check the coverage JSON; redo step 1 or fix `crag_iso_map.csv` |
| not_selected_on_outcome (share 0.55 or more) | only defaulters in the history | Same as above |
| episodes_sourced | the memory-compiled `sovereign_defaults.csv` was used (the default until the CRAG swap is approved) | Pass `--events crag` (EQ-B-0087) |
| predictor_lag | should not happen (lag is fixed at 1) | Tell Team B |

**5. If CLEARED: review the numbers.** Open `outputs/hazard-refit/<as_of>/change-proposal.md`. Check:

- OOS AUC, events and Brier against the gate (the first table).
- The row "fitted mode runs at as_of (VF-012)". If it says False, the fitted model would be refused on today's
  desk data and every run would fall back to paper mode. The pack then recommends the coefficients-only command
  (stores the fit, mode stays paper; no change to any run). The mode switch waits until the missing WEO values
  exist, or until you decide how to handle them (see "Known issue" below).
- The expected-effect table: VaR99, ES99, EL and L-VaR99 before and after at 20,000 paths, and per-country PDs,
  including `pd_fit_raw` (what the fit says on each desk country's own inputs).

Nothing is proposed yet. If you agree, either run the recommended command yourself (put your name after
`--author`; a Tier 1 change then needs a different approver, or a self-approval under an EXC id), or upload the
folder (step 6) and Team B proposes it and you approve it:

```bash
econquest change show <CHG-id>
econquest change approve <CHG-id> --approver "Sam"
econquest change apply <CHG-id>
```

After apply, Team B copies `hazard-fit-report-refit.md` over `docs/validation/hazard-fit-report.md`, reruns the base
and replication, and updates VF-012 and restriction 6.1.

**6. Upload.**

```bash
cd ~/econquest && zip -r ~/Desktop/econquest-hazard-refit-$(date +%Y%m%d).zip outputs/hazard-refit/2026-10-23 outputs/hazard-refit-*.log outputs/panel-coverage-*.json
```

Upload the zip to the Claude project files next to `econquest/`.

## Known issue: VF-012 is not closed by a lag-1 refit alone

The dry run checked the desk data as it is today (`data/live`). With predictor_lag 1 at as_of 2026-10-23, the
fitted model needs 2025 WEO values. Two are missing: debt for Venezuela and the primary balance for Singapore. So
even a fit that clears the gate would fall back to paper mode at run time. Options for Sam (a decision, not made
here): wait for a WEO release that has them; accept fallback and store the coefficients only; or switch on the
missing-input rule below (a model change, Tier 1, with its own review).

### Missing-input rule (EQ-B-0080, off by default)

`econquest/engine/layer1_hazard.py`, `fill_missing_inputs`; tests `tests/test_layer1_missing_input.py`.

| Setting | Default | Values |
|---|---|---|
| `layer1.missing_input_rule` | `"paper"` | `"paper"`: today's behaviour, one gap sends the whole run to paper mode. `"carry_forward_k"`: per country, carry the same WEO series from an earlier year. `"impute_peer"`: per country, the median of the same rating band (at least 3 peers). |
| `layer1.missing_input_k` | 2 | carry_forward_k only: how many years back to look (predictor year - 1 down to predictor year - k) |
| `layer1.missing_input_data_dir` | `"data"` | where the dated WEO pulls are |

Rules:

1. Only fitted mode with missing WEO inputs is affected. Unaligned World Bank features are still refused for the
   whole run (EQ-B-0029).
2. Point in time. The rule reads only the latest WEO pull dated on or before as_of (`dsa.load_weo_as_of`), never
   `Universe.weo_raw`. A vintaged frame keeps only releases dated on or before as_of. Carry-forward reads only
   earlier periods, never a projection for a later year. With no dated pull, the rule does not run and the whole
   run falls back as today, with the reason in the warning.
3. A country with an input still missing gets the rating-implied PD as its hazard PD, for that country only. It is
   left out of the intercept calibration. Every other country keeps the fitted model.
4. The record is in `layer1_model["missing_inputs"]`: gaps, how each was filled, the rating-fallback countries,
   and the share of countries affected.

On the desk data at as_of 2026-10-23 with `carry_forward_k`, k 2:

| Fit | Gaps | Filled | Rating-implied PD | Share affected |
|---|---|---|---|---|
| shipped fit, predictor_lag 0 (year 2026) | Venezuela, Senegal, Singapore | Senegal (all five inputs from 2025), Venezuela primary balance | Venezuela (no WEO debt series in any year), Singapore (no WEO primary balance in any year) | 3 of 18 (16.7%); 2 of 18 (11.1%) on rating PD |
| SYNTHETIC dry-run fit, lag 1 (year 2025) | Venezuela debt, Singapore primary balance | none | Venezuela, Singapore | 2 of 18 (11.1%) |

So carry-forward alone cannot close VF-012 for these two countries: their series are absent in every year. The
per-country rating fallback is what lets fitted mode run. `impute_peer` fills Venezuela's debt from three C-band
peers (Senegal, Zambia, Zimbabwe), which says little about Venezuela; it is offered but not recommended.
With the default `"paper"` the 20,000-path base is bit-identical (same loss-vector hash).

Switching it on is a Tier 1 change, together with the mode switch, after a refit clears the gate:

```bash
econquest change propose assumptions.json --set '/layer1/missing_input_rule="carry_forward_k"' --set '/layer1/missing_input_k=2' --tier 1 --allow-new-keys --author '<YOUR NAME>' --reason 'VF-012: per-country missing-input rule for fitted layer 1 (EQ-B-0080)'
```

## Options

| Flag | Default | Use |
|---|---|---|
| `--as-of` | required | model date |
| `--data` | `data` | folder with `panel/` and `assumptions.json` |
| `--out` | `outputs/hazard-refit/<as_of>` | output folder |
| `--events` | `layer1.refit_events` in assumptions.json, else `current` | `current` (`sovereign_defaults.csv`) or `crag` (`sovereign_defaults_crag.csv` with crag_v1) |
| `--min-amount-musd`, `--cure-years` | 10, 2 | crag only: the event rule (`hazard-panel-crag.md`) |
| `--crag-raw` | `data/panel/staging/crag/DEBT_2026.csv` | crag only: raw BoC-BoE file for the floor; must be the file the episode list names |
| `--defaults`, `--weo-history` | the file of `--events`, `weo_history.csv` | other landed files; `--defaults` without `--events` is read as it is, no event rule |
| `--effect-paths` | 20000 | 0 skips the two pipeline runs (layer 1 is still checked) |
| `--min-auc`, `--min-events`, `--min-countries` | 0.75, 30, 60 | gate and preflight thresholds; change only with Team B |
| `--worldbank-history` | not used | World Bank features have no vintages and are refused at run time (EQ-B-0029) |
| `--author` | `<YOUR NAME>` | name written into the drafted command |
| `--synthetic-dry-run` | off | SYNTHETIC panel, step 0 |

## CRAG default events (EQ-B-0087): exact sequence on Sam's Mac

Added 2026-10-25 by AGENT-03. Run this once `data/panel/weo_history.csv` has landed (Team A's IMF SDMX pull,
then `A-full-panel-fetch.md` steps 0 to 2b). The CRAG file is already in the repo. Why the event rule is what it is:
`hazard-panel-crag.md`. The dry run (SYNTHETIC predictors): `hazard-refit-crag-dry-run.md`.

```bash
cd ~/econquest

# 0. Smoke test (no network, about a minute). Expect "SYNTHETIC outcome: CLEARED (exit 0)".
.venv/bin/python -m econquest.validation.hazard_refit --as-of 2026-10-23 --synthetic-dry-run --effect-paths 0

# 1. The WEO history is there and vintaged: the header must contain "vintage".
head -1 data/panel/weo_history.csv

# 2. The CRAG files are the reviewed ones. Expect 37a05934978c395f... and 7b6e696aa9b943a6...
shasum -a 256 data/panel/sovereign_defaults_crag.csv data/panel/staging/crag/DEBT_2026.csv

# 3. Reference run on the current list. Expect PREFLIGHT FAILED (exit 3): episodes_sourced, and fewer than 30 events.
caffeinate -i .venv/bin/python -m econquest.validation.hazard_refit --as-of 2026-10-23 --events current \
  --effect-paths 0 --out outputs/hazard-refit/2026-10-23-current 2>&1 | tee outputs/hazard-refit-current-$(date +%Y%m%d-%H%M).log
echo "exit code: ${PIPESTATUS[0]}"

# 4. The candidate: CRAG with crag_v1 (USD 10m floor, 2-year cure), 20,000-path effect runs.
caffeinate -i .venv/bin/python -m econquest.validation.hazard_refit --as-of 2026-10-23 --events crag \
  --out outputs/hazard-refit/2026-10-23-crag 2>&1 | tee outputs/hazard-refit-crag-$(date +%Y%m%d-%H%M).log
echo "exit code: ${PIPESTATUS[0]}"

# 5. Sensitivity: CRAG as imported (no floor, cure 1). No effect runs.
caffeinate -i .venv/bin/python -m econquest.validation.hazard_refit --as-of 2026-10-23 --events crag \
  --min-amount-musd 0 --cure-years 1 --effect-paths 0 --out outputs/hazard-refit/2026-10-23-crag-plain 2>&1 \
  | tee outputs/hazard-refit-crag-plain-$(date +%Y%m%d-%H%M).log

# 6. Upload everything.
zip -r ~/Desktop/econquest-hazard-refit-crag-$(date +%Y%m%d).zip outputs/hazard-refit/2026-10-23-current \
  outputs/hazard-refit/2026-10-23-crag outputs/hazard-refit/2026-10-23-crag-plain outputs/hazard-refit-*.log
```

Each `gate-report.md` has a line "Default events (EQ-B-0087)" with the rule and the spell counts, and
`gate-report.json` has `event_starts_per_year` and `panel_events_per_label_year`. Read step 4 as in "4. Read the
outcome" above. Two more things to check in step 4:

- `not_selected_on_outcome`: CRAG makes about half the economies "ever defaulted" (0.49 in the dry run, limit
  0.55). If it fails, the history has too few economies (fewer than about 173); tell Team A.
- `balanced_countries` and Team A's coverage block: spells with no WEO history (micro-states, North Korea) drop out.

Nothing is proposed by these runs. Two separate Tier 1 decisions follow if step 4 clears:

1. The event source: `layer1.refit_events` = crag_v1 (card text pre-drafted in `hazard-refit-crag-tier1-card.md`).
   It changes no run by itself; it makes CRAG the refit default.
2. The coefficients (and the mode switch): the change pack in `outputs/hazard-refit/2026-10-23-crag/`.

Send the zip to Team B either way. A NOT CLEARED result on CRAG keeps layer 1 in paper mode.
