# Analyst-judgement overlay (EQ-B-0138, PI-13)

Date: 2026-10-26. Team B AGENT-07. Code: `econquest/validation/analyst_overlay.py`. Tests:
`tests/test_analyst_overlay.py` (52). Parked Tier 1 card for wiring it into the risk numbers:
`docs/governance/decisions/B-0138-overlay-tier1-card.md`.

**Status: research view, OFF by default, off the risk numbers.** While off, no function reads or writes anything,
no ledger file exists, and the base is bit-identical: 20k 66.95612571109443 / 89.00003057231508 / 4.098636048964449 /
72.23763153780678, replication PASS 141 FAIL 0 (local copy, 2026-10-26, before and after the module was added).
Every number in this document that involves an overlay entry comes from SYNTHETIC entries.

## 1. Purpose

Analysts often know something the 83 indicators do not yet carry: a budget vote that has not reached the fiscal
data, a programme review that slipped, security incidents ahead of the event index. The overlay records that
judgement in a structured, bounded and audited form, one score per country and pillar, and shows it **beside** the
model output: model value, overlay delta and overlaid value in separate columns, with the author and the approver.
It never replaces the model value, and nothing in the engine reads it.

It is not the scorecard's existing analyst adjustment (`data/adjustments.csv`, block "Analyst adjustment", capped by
`scorecard.max_analyst_adj` 10). That is a Team A attested model input, already inside the model value the overlay
shows, and the overlay does not change it.

## 2. Where it sits in the pipeline

Nowhere in `run_pipeline`. It reads a finished run dict (`RunResult.to_dict()` or `outputs/run_latest.json`: the
`pillars` block, the `country` composites and the scorecard weights in `settings`) and its own ledger, and returns
rows. Consumers: Team C's pages (handoff EQ-B-0138 to C/AGENT-08). No module under `engine/`, `scorecard/`,
`ingestion/`, `persistence/` or `rules/` imports it (a test checks this). It imports nothing from `presentation`.

| Function | Returns |
|---|---|
| `overlay_rows(run, root, as_of, enabled=False)` | display rows, `OVERLAY_COLUMNS`; one `pillar` row per active entry and one `composite` row per country |
| `overlay_entries(root, as_of, enabled=False)` | every entry and its status (pending, active, expired, withdrawn), `ENTRY_COLUMNS` |
| `overlay_audit(root, enabled=False)` | every ledger event with its hashes, `AUDIT_COLUMNS` |
| `build_overlay(run, root, as_of, enabled=False)` | the three lists, `verify` and an info line; off: empty lists and "off" |
| `add_entry`, `approve_entry`, `withdraw_entry` | the ledger row written (refused while off) |
| `verify(root, expect_head=None)` | chain, head file and an optional head recorded outside the folder |
| `demo_overlay(out_dir, run=None)` | `{"ok", "problems", "paths", ...}`, SYNTHETIC, in a marked sandbox `<out_dir>/analyst_overlay/`; out_dir under `outputs/` or outside the repo |
| `assert_internal(rows, audience)` | refuses any audience but internal |

The switch: `enabled=True` on the call, or the settings key `research.analyst_overlay.enabled` set to exactly `true`.
The key is absent from `data/assumptions.json`; adding it would go through `econquest change` and does not by itself
touch any risk number (section 7).

## 3. Assumptions

| Item | Value | Why |
|---|---|---|
| Score | whole notches in -2, -1, +1, +2 (0 is no entry) | Coarse on purpose: a judgement, not a second model |
| Direction | positive = more risk than the model sees | Pillar scores are risk scores, 0-100, higher is riskier |
| Notch size | 2.5 pillar points | A quarter of the scorecard's analyst adjustment cap (10) per notch |
| Pillar cap | 5.0 points (2 notches); overlaid pillar clamped to 0..100 (`cap` "bounds") | Half the in-model analyst adjustment cap |
| Country cap | GROSS: the sum over pillars of \|weight x delta\| is at most 2.0 composite points; above it every pillar delta of the country scales by the same factor (`cap` "country"). The net composite delta is then at most 2.0 too | Bounds piling notches on one name, including offsetting +2 / -2 entries (lead decision, AGENT-06 review L3) |
| Composite weights | the run's standard or small-state pillar weights, whichever reproduces the run's composite | Same weights as the model |
| Expiry | required; after the entry date and at most 92 days later | One revalidation quarter; stale judgement drops out |
| Reason | required, at least 20 characters, formula-neutralised | The audit trail must say what the model misses |
| One open entry per cell | a pending or active entry blocks a new one for the same country and pillar | Withdraw first; no silent stacking |

All values are judgement and are constants in the module (Team B method rule; changing them is a code change with
tests, Tier 2 under policy v2 while the overlay stays off the risk numbers).

## 4. Data, ledger and four-eyes

**Ledger.** `docs/validation/overlay-log.jsonl` and `overlay-head.json` (created only by the first switched-on add;
neither exists today). Same scheme as the findings log and the approvals log: `seq` from 1, `prev_hash`,
`row_hash = sha256(prev_hash + canonical row)`. Append-only events: `add`, `approve`, `withdraw`. Every call takes
`as_of`; no wall clock; an event dated before the last one is refused. The chain is unkeyed, so
`verify(expect_head="SEQ:HASH")` against a head recorded outside the folder is what catches a full rewrite.

**Four-eyes.** `approve_entry` refuses an approver who is the author on either of two keys: `ingestion.ledger.person_key`
(case, spaces, leading apostrophe, zero-width characters and look-alike letters ignored) or the stricter `overlay_key`
(AGENT-06 review M1): leading formula and quote characters dropped, trailing bracketed suffixes dropped, then letters
and digits only, split into name tokens and sorted. So "alice.smith", "alice-smith", "Smith, Alice",
"Alice Smith (desk)", "=Alice Smith" and "ALICE  SMITH [B]" are all refused against "Alice Smith". **Initials are a
judgement left open:** "A. Smith" is not matched to "Alice Smith", because matching on initials would also refuse
two different people who share a surname and an initial. Names stay self-asserted until signing covers the overlay.

**Single-operator path.** Explicit and logged, like EXC-004 for `findings close`: a self-approval needs `exc_id`
naming an EXC row of `docs/governance/issues-log.md` whose text names `overlay approve`, with a start date on or
before `as_of` and an expiry date on or after it. EXC-002 (model and limit changes) and EXC-004 (findings) do not
qualify. **No such row exists today, so every self-approval is refused** until Sam logs one; the proposed row is in
the Tier 1 card. An approval under it is stored with `self_approved` "yes" and the EXC id, and both appear on every
display row.

**Named users.** With `data/users.json` four_eyes enforced (`ops.identity.enforced`: "enforce" and two or more active
users), author and approver must both be registered active users with different ids, and self-approval is refused
outright. Approvals are not yet HMAC-signed: `identity.SCOPES` has no "overlay" scope. **Open, waiting on Team C**
(HO-20261026-B-C-014; AGENT-06 review L5): until the scope exists, the enforced path refuses every overlay
self-approval, EXC or not.

**SYNTHETIC entries** (AGENT-06 review M2). `add_entry(synthetic=True)` and every view (`overlay_rows`,
`overlay_entries`, `overlay_audit`, `build_overlay`) are refused unless the ledger root is a marked sandbox
(`mark_sandbox`: a `.overlay-sandbox` file with the sandbox text, written only by `demo_overlay` and the effect
runner) or the call runs under pytest (`PYTEST_CURRENT_TEST`, the text_index guard style). The repo root, `data/`
and `docs/` can never be a sandbox, so the real ledger refuses SYNTHETIC entries even in tests. There is no caller
switch: the old `allow_synthetic` keyword is gone.

**Output paths** (review L4). `demo_overlay(out_dir)`, `demo --out` and `effect --json` accept a path under
`outputs/` or outside the repo; anywhere else in the repo (data/, docs/, code) is refused, in the spirit of
`activation.resolve_out_dir`.

## 5. Estimation or calibration

None. Caps and notch size are judgement (section 3).

## 6. Outputs and how they are used

Rows for Team C's pages, internal only (`audience` "internal" and an INTERNAL label on every row; client mode stays
off). Each row carries `model_value`, `overlay_delta`, `overlaid_value`, `cap`, `entry_id`, `author`, `approver`,
`approved_on`, `self_approved`, `exc_id`, `reason`, `entered_on`, `expires`, `synthetic`, and the run's `run_id` and
`data_hash`. The composite row's delta is the weighted (net) sum of its pillar deltas after the caps.

Demo (`demo_overlay(out_dir)`): six SYNTHETIC entries on Brazil, Pakistan and Vietnam, one self-approved under a
SYNTHETIC sandbox exception (EXC-990, only in the sandbox issues log), one pending entry whose self-approval without
an EXC is refused, two refused bad entries; 12 checks, 9 rows, 7 entries. It writes only under
`<out_dir>/analyst_overlay/`: `overlay_rows.csv`, `overlay_rows.json`, `overlay_entries.csv`, `overlay_audit.csv`,
`demo_summary.json`, the sandbox ledger and the sandbox issues log. Model values come from the given run, else
`outputs/run_latest.json` (read only), else a SYNTHETIC stub.

## 7. Limitations and known gaps

- Judgement, self-asserted names: `person_key` and `overlay_key` stop accidental or lazy self-approval (punctuation,
  word order, suffixes), not a determined one with an unrelated alias, until named-user signing covers the overlay
  (Team C scope, open).
- No CLI yet: `econquest overlay add/approve/list/verify` is asked of Team C (the CLI is theirs).
- The overlay is a view: a page showing overlaid values next to PDs could be read as a model change. Every row is
  labelled, and the overlaid PD and VaR are deliberately not computed in the view; only the parked card shows them.
- Pillar deltas are additive on the final pillar; they ignore the override floors (a floored pillar may show an
  overlaid value below its floor) and interactions with the trigger add-ons.
- Notch size and caps are not calibrated against any record of analyst calls (there is none yet).
- One open entry per cell: no blending of several analysts' scores.
- The ledger lives in the shared folder; a head recorded outside it is needed for tamper evidence (section 4).

## 8. Sensitivity

`python -m econquest.validation.analyst_overlay effect [--paths 20000]` on temporary data copies, the overlay deltas
added to the final pillar (the parked hook). The shared data hash 308b73ca9e257627 is the same before and after.
SYNTHETIC entries. The cap-bound rows put the largest same-sign notch on every pillar of every name. Under the gross
cap no set of entries can give a name a composite move above 2.0 points, but a mixed-sign set (for example +2 on
the fiscal pillar and -2 on the climate pillar) reaches the PDs and the book through different channels, so its
book effect is not proven to lie inside these two rows; they are the same-sign bounds, not a proof for every mix.

| Case (as_of 2026-10-23) | Paths | VaR99 | ES99 | EL | L-VaR99 |
|---|---|---|---|---|---|
| Base (overlay off), and the copy with no overlay | 20k | 66.956 | 89.000 | 4.099 | 72.238 |
| SYNTHETIC demo sample | 20k | 67.016 (+0.060) | 89.081 (+0.081) | 4.142 (+0.044) | 72.298 (+0.060) |
| Cap bound +2 notches everywhere | 20k | 68.305 (+1.349) | 90.524 (+1.524) | 4.378 (+0.279) | 73.586 (+1.349) |
| Cap bound -2 notches everywhere | 20k | 65.977 (-0.979) | 87.536 (-1.464) | 3.842 (-0.257) | 71.259 (-0.979) |
| Base, and the copy with no overlay | 100k | 66.780 | 88.482 | 4.104 | 72.062 |
| SYNTHETIC demo sample | 100k | 66.844 (+0.064) | 88.576 (+0.094) | 4.151 (+0.047) | 72.126 (+0.064) |
| Cap bound +2 | 100k | 68.242 (+1.462) | 89.891 (+1.409) | 4.383 (+0.279) | 73.523 (+1.462) |
| Cap bound -2 | 100k | 65.543 (-1.237) | 87.100 (-1.381) | 3.845 (-0.258) | 70.825 (-1.237) |

## 9. Benchmarks and evidence

`tests/test_analyst_overlay.py`: off by default (no reads, no writes, refusals, shipped settings off), no engine
import and no presentation import, four-eyes with `person_key` and `overlay_key` variants (punctuation, word order, suffix, formula lead), the EXC path (absent, wrong scope, expired,
not yet started, no expiry date), users.json enforcement, entry rules, one open entry per cell and withdrawal, rows
apart and the run dict unchanged, the gross country cap (offsetting entries), the 0..100 bounds, expiry, synthetic refusal outside a marked sandbox
or pytest (all four views, and the repo-root ledger even in tests), output-path limits, internal audience,
chain edit / cut / backdating / expect_head, and the demo sandbox (shared data hash unchanged).

## 10. Open items

- Sam: log an EXC row naming `overlay approve` (proposed in the card) before any single-operator use.
- Team C: CLI subcommands, an "overlay" named-user scope, and the page (handoff EQ-B-0138).
- Lead (EQ-B-0139): model inventory entry.
- Wiring into the risk numbers: Tier 1, parked card.
