# Event stress index (layer-2 text term)

Ticket EQ-B-0033 (Story 5, GOV-014). Owner: Team B, AGENT-05. Date: 2026-10-23. Tier: 1 when switched on
(it moves `pd_post` and so every PD, VaR, ES and EL downstream); shipped **off** (`source "none"`).
Code: `econquest/engine/event_index.py`; wiring: `econquest/engine/layer2_bayesian.py::posterior`.
Tests: `tests/test_event_index.py`.

> **Evidence status.** Everything quantitative below comes from a **synthetic fixture**
> (`tests/fixtures/event_fixture.py`, provenance `SYNTHETIC fixture EQ-B-0033 - not UCDP/GDELT data`).
> It shows that the code does what this page says and that the backtest harness can find a planted lead
> and finds none in a null fixture. It is **not** evidence that UCDP or GDELT lead sovereign defaults or
> spread widening. That evidence waits on the Team A adapters (EQ-A-0022 UCDP, EQ-A-0023 GDELT) and on
> at least six years of dated history per country pulled on Sam's Mac.

## Purpose

Layer 2 adds `w_t * z_tsi` to the log-odds (`w_t 0.25`). Until now `z_tsi = textz` from `countries.csv`,
which is 0 for every country, so the term only moved under scenario shocks (GOV-014). This index gives
the term a data source: organised violence (UCDP) and media-coded conflict events (GDELT), each measured
against the country's own trailing history.

## Input contract (HO-20261023-B-A-004)

One long table, `data/live/events/events_long.csv`, loaded by Team A into `Universe.events`:

| column | meaning |
|---|---|
| `iso` | ISO3 |
| `source` | `ucdp_ged` (final), `ucdp_candidate` (monthly candidate), `gdelt` |
| `series` | `events`, `fatalities`, `goldstein_mean`, `tone_mean` |
| `freq` | `D`, `M`, `A`; `period` is the period start |
| `value` | count, or event-weighted mean for Goldstein and tone |
| `vintage` | date the row became available (never the event date) |
| `provenance` | optional citation (UCDP CC BY 4.0 and GDELT both require one) |

Covered country-periods carry explicit zero counts. A missing row means "not covered or not yet
released" and is treated as missing, never as calm.

One frequency per source and country-month (EQ-B-0047, review Low): within a component the preferred source
(GED before candidate) takes a country-month whole, whatever the frequencies, and a source that sends both
daily and monthly rows for the same country-month is refused with a ValueError naming the rows. Before, the
dedupe keyed on (iso, period) and removed only the day-1 daily row, so the rest of the month was counted
twice. Daily and monthly rows of one source in different months are accepted. Test:
`test_mixed_daily_and_monthly_rows_rejected_or_ranked`; the synthetic fixture results are unchanged.

## Method

1. **Point in time.** At `as_of` use rows with `vintage <= as_of` and period end `<= as_of`; for a revised
   row the latest vintage on or before `as_of` wins. Final GED rows beat candidate rows for the same month.
   Annual rows are split into twelve months (counts / 12). The module never reads the clock and draws no
   random numbers.
2. **Components** (sign: + means more stress):

   | component | source | series | transform | sign | weight |
   |---|---|---|---|---|---|
   | `fatalities` | UCDP (GED, else candidate) | fatalities | log1p(rate per 30.4 days) | + | 0.35 |
   | `conflict_events` | UCDP | events | log1p(rate) | + | 0.15 |
   | `media_events` | GDELT | events | log1p(rate) | + | 0.10 |
   | `goldstein` | GDELT | goldstein_mean | event-weighted mean | - | 0.20 |
   | `tone` | GDELT | tone_mean | event-weighted mean | - | 0.20 |

   Rationale: fatalities are the hardest, least media-dependent signal and get the largest weight; GDELT
   event volume follows media attention, so its count gets the smallest; Goldstein and tone carry the
   direction of coverage. The weights are judgement, not fitted, and are the first thing a real backtest
   should test.
3. **Windows.** Non-overlapping 91-day blocks ending on each component's data edge for that country (the
   last day its rows cover). UCDP candidate data runs about a month behind GDELT, so the two sources are
   compared on their own latest quarter. A component whose edge is more than 92 days before `as_of` is not
   scored (stale). A window needs at least half its days covered.
4. **Standardise.** `z = sign * (x_0 - mean(x_1..x_20)) / max(sd(x_1..x_20), 0.25)`, clipped to +-4. Twenty
   trailing windows is about five years; a component needs at least eight (about two years).
5. **Combine.** `index = sum(w_i z_i) / sum(w_i)` over the components present. Coverage is the present
   weight share. Flags: `ok` (all components), `partial` (coverage >= 0.3), `insufficient` (coverage < 0.3:
   index 0), `missing` (no rows for the country: index 0). `posterior` returns `z_event` and `event_flag`.
6. **Layer 2.** `source "none"`: `z_tsi = textz` exactly (today). `source "events"`: `z_tsi = textz + index`,
   so scenario shocks to `textz` (`stress.py`) still add on top.

## Parameters (proposed `probability.text_index`, not yet in `data/assumptions.json`)

Code defaults reproduce today's behaviour; the shipped file has no `text_index` block.

```json
"text_index": {"source": "none", "window_days": 91, "history_windows": 20, "min_history": 8,
               "min_window_coverage": 0.5, "max_staleness_days": 92, "std_floor": 0.25, "clip": 4.0,
               "min_coverage": 0.3,
               "weights": {"fatalities": 0.35, "conflict_events": 0.15, "media_events": 0.10,
                           "goldstein": 0.20, "tone": 0.20}}
```

## Backtest harness

- `index_history(events, dates)` rebuilds the index point in time at each date.
- `default_lead_auc(hist, defaults)` scores the index against default starts in (d, d+a..b months]
  windows (0-6, 6-12, 0-12, 12-24) and a lagging window (d-12m, d]. `defaults` is
  `data/panel/sovereign_defaults.csv` (year-only starts dated 1 July, the benchmarks convention) or a
  hazard panel (`iso, year, event`). Country-dates inside a spell and rows flagged missing/insufficient are
  excluded. A leading signal scores higher ahead than behind.
- `spread_lead_lag(hist, spreads)` correlates the index with spread changes over -91, -30, +30, +91, +182
  days and gives the AUC for widening of at least 50 bp. `data/market_history/` holds FX and ETF closes but
  no spread history today; the function takes any `iso, date, value` series (an FX level gives
  depreciation).

### Results on the synthetic fixture (`tests/test_event_index.py::_backtest`)

12 synthetic countries, quarterly dates 2020-2024, 5-month shocks; in the planted fixture half the shocks
are followed by a default start 6 months after the shock begins. Observations are overlapping
country-quarters, so the event counts are not independent defaults (6 defaults in each fixture).

| window | planted AUC (n / events) | null AUC (n / events) |
|---|---|---|
| +0..+6m | 0.953 (223 / 12) | 0.445 (228 / 11) |
| +6..+12m | 0.538 (223 / 12) | 0.366 (228 / 8) |
| +0..+12m | 0.760 (223 / 24) | 0.408 (228 / 19) |
| +12..+24m | 0.593 (223 / 20) | 0.548 (228 / 16) |
| -12..0m (lagging) | 0.360 (223 / 7) | 0.390 (228 / 10) |

Spread lead-lag (planted fixture; spreads widen 150 bp, persistently, 60 days after each shock starts):

| horizon | corr | AUC widen >= 50 bp (widenings) |
|---|---|---|
| -91 d | 0.583 | 0.771 (22) |
| -30 d | 0.263 | 0.981 (5) |
| +30 d | 0.165 | 0.909 (5) |
| +91 d | 0.093 | 0.716 (22) |
| +182 d | 0.021 | 0.628 (42) |

Reading: the harness recovers a lead exactly as long as the planted one (high at 0-6 months, fading after,
low on the lagging side) and gives no signal on the null fixture. These numbers validate the harness, not
the index.

## Effect on the fixture (Tier 1 evidence for Sam)

`run_pipeline(u, s, paths=20000, as_of="2026-10-23")` (Sobol 32,768 paths) on the real 18-country universe,
with synthetic events for the 18 real ISO codes (seed 21) injected into layer 2. Runtime about 2 s per
run either way; the index itself takes about 0.3 s.

| run | VaR99 $mm | ES99 $mm | EL $mm | largest PD moves (pp) |
|---|---|---|---|---|
| off (shipped) | 64.23 | 83.67 | 0.534 | none |
| on, no planted shocks (noise only) | 64.44 | 83.99 | 0.500 | ZWE +4.48 (z 0.51), SEN -0.31, ZMB -0.29, COL +0.23 |
| on, shocks PAK, NGA, COL (0.5) | 66.65 | 85.53 | 1.495 | PAK +8.20 (z 3.51), NGA +3.65 (z 2.77), ZWE +1.18, BLZ -1.04, COL +0.56 |

Pure noise gives a mean |z| of 0.3 and moves Zimbabwe's PD by 4.5 pp, because a log-odds shift of 0.13 is
large near PD 0.78. Before the index is switched on, Sam should consider a dead-band (for example |z| < 1
gives 0) or a lower `w_t`, judged on the real backtest.

## Limitations

- No real data yet; weights and windows are judgement.
- UCDP counts only lethal organised violence (no protests); GDELT volume follows media attention and
  changes with source coverage over time, which the own-history z-score only partly absorbs.
- With 18 countries and few defaults, a real AUC will have wide intervals; the gate in
  `validation.hazard_panel.gate_check` (AUC >= 0.75, >= 30 events) is the bar to aim for.
- Additive on `textz`: if an analyst ever enters a non-zero `textz`, it stacks with the index.

## Recommendation

Keep `source "none"`. After the adapters deliver history: run `default_lead_auc` on
`sovereign_defaults.csv` and `spread_lead_lag` on a spread history, decide the dead-band and `w_t`, and
bring the before/after table above, rerun on real data, to Sam as a Tier 1 change.
