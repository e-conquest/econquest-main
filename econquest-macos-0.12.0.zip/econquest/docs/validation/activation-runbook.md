# Runbook: activation pack after the real-data pull (Sam's Mac)

Ticket EQ-B-0079. Owner: Team B (AGENT-05). Operator: Sam. Written 2026-10-24.
Tool: `econquest/validation/activation.py` (tests: `tests/test_activation.py`, SYNTHETIC and PROXY inputs).

## The command

After your pull (full panel, CRAG import, Team A's staged FX build), from `~/econquest`:

```bash
caffeinate -i .venv/bin/python -m econquest.validation.activation --as-of 2026-10-23 2>&1 | tee outputs/activation-$(date +%Y%m%d-%H%M).log
echo "exit code: ${PIPESTATUS[0]}"
```

Use the as_of of the current base (2026-10-23 for 0.3.0), so the tables compare with the release figures.
It takes about 5 minutes (the cloud dry run took 4 min 40 s: 2 min for the FX runs and the refit, 4 min for the
GARCH backtests and stability). Output: `outputs/activation/<as_of>/`. Open `decision-note.md` there.

It finds the newest build under `data/market_history/builds/` by itself. To use another one, add
`--staged-build data/market_history/builds/<vintage id>`.

## What it does

In order, without changing any file in `data/` or `docs/`:

| Step | What | Uses |
|---|---|---|
| a | Preflight: lists what has landed (panel, CRAG, staged FX build, today's prices, UCDP, GDELT, nowcast inputs) | |
| b | Hazard refit: gate report, and the change pack if the gate clears | `validation/hazard_refit.py` (EQ-B-0067) |
| c | FX-only rerun: base at 100,000 paths and the ten stress scenarios on the staged prices, in a temporary copy of `data/` | engine FX-only path (EQ-B-0077) |
| d | GARCH backtests and stability on the staged FX history | `econquest/validation/garch_dossier.py` (same logic as `docs/validation/dossier/garch_backtests.py`) |
| e | `decision-note.md`: one effect table per decision, with the exact commands | |

Step c runs each case twice on the same random numbers: once on today's data, once on the staged prices. So the
change has its own standard error (paired SE), which is much smaller than either run's SE. The 0.3.0 release
figures are shown next to them.

Nothing is proposed, approved or applied. The note drafts the commands; you run them.

## Exit codes and step status

| Exit | Meaning | What to do |
|---|---|---|
| 0 | Every step ran or was skipped for a missing input. | Read `decision-note.md`. |
| 1 | At least one step FAILED (an error, not a missing input). The other steps still ran. | Upload the folder and the log; Team B looks at the `traceback` in `activation.json`. |

Each step shows one status in the log and in the note:

| Status | Meaning |
|---|---|
| RAN | The step ran. For the refit, the outcome follows: CLEARED, NOT_CLEARED or PREFLIGHT_FAILED (see `hazard-refit-runbook.md` step 4). |
| SKIPPED | An input is missing; the reason names it. Not an error. Land the input and rerun. |
| FAILED | The step stopped with an error. Not your fault; send it to Team B. |

Preflight rows that skip a step:

| Row | Skips | Usual fix |
|---|---|---|
| panel_weo_history | b | `docs/runbooks/A-full-panel-fetch.md` steps 0 to 2b |
| panel_default_events | b | The refit's default-event file (EQ-B-0087): `layer1.refit_events` in assumptions.json picks it; absent, the current list `sovereign_defaults.csv`, which runs but stops at PREFLIGHT FAILED (episodes_sourced). For CRAG, the CRAG import (same runbook, step 3) and an approved `layer1.refit_events` (`hazard-refit-crag-tier1-card.md`) |
| staged_fx_build | c, d | `python -m econquest.ingestion.market_history build` (pull pack step 1b). "not usable" means the build changed after it was made (sha256), holds ETF columns, or has no row by as_of |

UCDP, GDELT, events_long, nowcast_inputs and panel_crag_episodes are reported only. No step here needs them.

## The three decisions in the note

**Item c: apply Team A's official FX build** (Tier 1 model change; `dossier/fx-only-prices.md`). The table shows
VaR99, ES99, EL and L-VaR99 and the ten stress ES99s before and after, with SEs. If you sign
`fx-only-prices.md`, Team B sets the handoff response, then run the commands in the note:

```bash
python -m econquest.ingestion.market_history apply --vintage <vintage id>
python -m econquest.ingestion.market_history restricted          # expect 0 files, exit 0
python -m econquest.validation.replicate
python -m econquest.validation.activation --freeze-official-prices data/market_history/prices.csv
```

The last command freezes the official file to `docs/governance/releases/inputs/<next>/prices.csv` (next minor
version, 0.4.0 after 0.3.0; `--release X.Y.Z` to choose, exactly three numbers). It refuses a file with ETF
columns, a file with no `prices.provenance.json` next to it, a sidecar whose schema or sha256 does not match, a
sidecar labelled PROXY or SYNTHETIC, or an existing target. Only Team A's official build passes. Team B then adds the FX-only replication checks on that frozen copy.

**Item b: hazard refit change pack** (Tier 1). Same content as `hazard-refit-runbook.md` step 5: the gate, whether
fitted mode runs at as_of (VF-012) and the before/after table, with the `econquest change propose` commands when
CLEARED. The before/after table is on today's prices. If you apply item c first, rerun this pack before proposing.

**Item d: FX GARCH 12-month marginals to Tier 1.** A document edit to `model-inventory.md` and
`model-risk-policy.md` (`dossier/garch-dcc-tier1.md` section 9), not a settings change. The note shows the backtests
on the staged prices against the dossier's GOOGLEFINANCE-era results, and the inventory text with the new figures
filled in. You sign it; Team B makes the edits.

## Dry run (PROXY and SYNTHETIC, cloud, 2026-10-24)

Staged build: today's `prices.csv` (sha256 e568019e..., the 0.3.0 input) minus the 12 ETF columns, labelled PROXY.
The FX values are still GOOGLEFINANCE closes, not BIS/ECB rates. Panel: `hazard_refit.make_synthetic_panel`
(72 invented economies). These numbers test the chain. They are not the decision numbers.

| Metric ($mm), 100,000 paths | 0.3.0 | Today | FX-only PROXY | SE | Change | Paired SE |
|---|---|---|---|---|---|---|
| VaR99 | 69.13 | 69.13 | 62.33 | 0.21 | -6.81 (-9.8%) | 0.34 |
| ES99 | 90.72 | 90.72 | 83.15 | 0.38 | -7.57 (-8.3%) | 0.20 |
| EL | 0.80 | 0.80 | 0.87 | | +0.07 | |
| L-VaR99 | 74.42 | 74.42 | 67.61 | 0.21 | -6.81 (-9.1%) | 0.34 |

Stress ES99 fell by 7.5 to 11.4 $mm in every scenario (paired SE 0.18 to 0.27). These match
`fx-only-prices.md` section 5. The GARCH backtests on the PROXY are identical to the dossier's FX results, as they
must be (same FX values). The SYNTHETIC refit CLEARED and, as on the real desk data, fitted mode would fall back
(VF-012: Venezuela debt and Singapore primary balance missing for 2025).

## Safety checks (AGENT-04 and AGENT-09 review)

- `--out` must resolve (symlinks followed) to a folder inside `outputs/`. An absolute path elsewhere, a `../`
  that leaves `outputs/`, `data/` or `docs/` is refused with exit 2 and nothing is written.
- `--freeze-official-prices` needs the official sidecar, as described under item c.
- Step d no longer executes `docs/validation/dossier/garch_backtests.py`. Running a file from `docs/` meant that
  anyone who can edit documents could change code the pack runs. The backtest and stability logic now lives in the
  package module `econquest/validation/garch_dossier.py`, which goes through code review like the rest of the
  engine. The docs script still exists for the dossier commands in `garch-dcc-tier1.md`; a test checks that both
  give the same results until the script becomes a thin wrapper around the module.

## Options

| Flag | Default | Use |
|---|---|---|
| `--as-of` | required | model date; nothing after it is read |
| `--staged-build` | newest under `data/market_history/builds/` | build folder or its prices.csv |
| `--out` | `outputs/activation/<as_of>` | output folder; must be inside `outputs/` (anything else is refused, exit 2) |
| `--panel` | `data/panel` | folder with `weo_history.csv` and `sovereign_defaults_crag.csv` |
| `--paths` | 100000 | FX-only base and stress runs |
| `--effect-paths` | 20000 | the refit's before/after runs (0 skips them) |
| `--only` | hazard,fx,garch | run a subset |
| `--no-stability` | off | skip the GARCH rolling windows (saves about 2 minutes) |
| `--author` | `<YOUR NAME>` | name in the drafted propose commands |
| `--freeze-official-prices FILE` | | only the frozen-price step, then exit |
| `--release` | next minor | version folder for the frozen prices |

## Upload

```bash
cd ~/econquest && zip -r ~/Desktop/econquest-activation-$(date +%Y%m%d).zip outputs/activation/2026-10-23 outputs/activation-*.log
```
