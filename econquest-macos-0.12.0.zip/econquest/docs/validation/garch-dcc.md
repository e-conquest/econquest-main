# Model validation: GARCH(1,1)-t, DCC and the volatility layer

Date: 2026-10-23. Code: `econquest/engine/garch.py` (`garch11_fit`, `arch_lm_test`, `ljung_box`,
`t_quantile`, `t_es`, `dcc_fit`, `black_scholes`, `implied_vol`, `vol_target_scalar`,
`clean_bad_ticks`, `run_garch`). Data: `data/market_history/prices.csv` (three years of daily Google
Finance closes, 17 USD pairs, 12 ETFs and EEM) and `data/gpr_monthly.csv`. Parameters:
`data/assumptions.json` key `garch` (`target_vol 0.1`, `scalar_cap 2.0`, `risk_free 0.04`,
`confidence [0.99]`). Status: estimated on real prices by maximum likelihood; the only fitted layer
in the program; run in this validation in 64 seconds.

## Purpose

The GARCH layer gives the desk a market-risk view of the FX and equity book at daily frequency:
conditional volatility per series, multi-step forecasts, Student-t VaR and ES at 99 percent for 1
and 10 days, DCC time-varying correlations across the FX pairs and across the ETFs, a GARCH-DCC book
VaR, a vol-target position scalar, Black-Scholes put fair values at the GARCH forecast volatility,
and a GARCH fit on the monthly GPR series. It also produces the next-day VaR/ES stored in the daily
forecast record.

## Where it sits in the pipeline

Separate from `run_pipeline`. Entry points: `econquest garch` (tables and the GARCH tab plan),
`econquest record` (next-day book VaR/ES via `run_garch`, and `_portfolio_var` for the backfill),
`econquest publish` (GARCH tab), and the econometrics toolkit, which reuses `garch11_fit`, the tests
and the cleaning functions. By default the 12-month Monte Carlo does not use any GARCH output; with
`monte_carlo.vol_source "garch"` (EQ-B-0035, off by default, Tier 1 if switched on) `garch.mc_vols`
supplies the FX and equity volatilities of layer 6 (section "Monte Carlo marginals" below). If that
setting is adopted this layer feeds a Tier 1 number and moves to Tier 1 (model-risk-policy section 2).

## Assumptions

1. Returns: log returns of daily closes after `clean_bad_ticks` (a one-day log return beyond 12
   robust standard deviations that reverses the next day is treated as a quote error, dropped and
   forward-filled) and `_business_daily` (calendar days forward-filled, weekends dropped). For
   pegged pairs where more than half of the returns are zero, the zero-return days are dropped
   (`_returns`).
2. GARCH(1,1) with constant mean and Student-t innovations: `sigma2_t = omega + alpha e_{t-1}^2 +
   beta sigma2_{t-1}`, `omega = sample variance x (1 - alpha - beta)` (variance targeting),
   persistence `alpha + beta` bounded below 0.9995, `nu > 2.05`. Maximum likelihood by Nelder-Mead
   from four starting points; `converged` reports the optimiser's flag.
3. Forecasts: the variance recursion from the last observation, reverting to the long-run variance
   at rate `alpha + beta`; cumulative variance over 10, 21 and 63 days; annualisation with 252 days.
4. VaR and ES: `t_quantile(0.99, nu)` and `t_es(0.99, nu)` for a unit-variance Student-t times the
   forecast standard deviation.
5. DCC(1,1) (Engle 2002) on the standardized residuals with correlation targeting: `Q_t = (1 - a -
   b) Qbar + a z z' + b Q_{t-1}`, `a + b < 0.999`, two blocks (17 FX pairs; 10 ETFs), Nelder-Mead
   from three starts; `R_next` is the one-step-ahead correlation.
6. Book VaR: exposures from `portfolio.csv` (FX and unhedged local bonds carry the currency; equity
   uses the ETF proxy; Eurobonds and CDS are excluded), one-day and ten-day standard deviations
   times `R_next`, quantile with the median `nu` of the block; FX and equity blocks combined as the
   square root of the sum of squares (zero correlation between the blocks). Loss sign convention: a
   long local-currency position loses when the USD quote rises.
7. Vol-target scalar = `min(cap 2.0, max(0.1, target_vol 0.10 / annualised 21-day forecast vol))`.
8. Options: ATM 63-day put per ETF at the GARCH 63-day forecast volatility and at 60-day realised
   volatility, risk-free 4 percent; implied volatility by Brent's method when a market quote is
   supplied.
9. GPR volatility: the same GARCH(1,1)-t on monthly log changes of each GPR series with at least 60
   observations.

## Data

`prices.csv` has 1,097 daily rows from 2023-10-18 to 2026-10-22; 786 business-day returns per series
after cleaning. Bad ticks removed: USDPKR 6, USDARS 4, USDCNY 4, USDVES 3, USDINR 2, USDNGN 2,
USDBRL 1, USDPHP 1. Twenty-seven series are fitted (17 FX, 10 ETFs; Belize, Colombia, Pakistan,
Venezuela, Nigeria, Senegal, Zambia and Zimbabwe have no ETF in the file, and Zimbabwe no FX pair).
The data are Google Finance quotes exported from the workbook's Market History tab, not a licensed
feed; the README notes that Eurobond and CDS positions have no daily price.

## Estimation or calibration

Maximum likelihood per series, then two-stage DCC. Results on 2026-10-22 (run in this validation):

- Persistence median 0.909, range 0.53 (INDA) to 0.999 (USDVES, USDNGN); half-lives from 1.1 days
  (INDA) to 580 days (USDVES). Student-t `nu` median 4.20, range 2.29 (USDNGN) to 7.89 (EPHE). All
  27 fits report `converged true`.
- Diagnostics: ARCH-LM on returns rejects no-ARCH (p below 0.05) for 24 of 27 series, so GARCH is
  warranted almost everywhere; the Ljung-Box test on squared standardized residuals rejects adequacy
  for 3 series (USDVND, USDPKR, USDVES), all managed or administered currencies with step-like
  moves. The GARCH tab prints these as columns R to T.
- DCC FX block: `a 0.010`, `b 0.630`, average one-step correlation 0.089 (unconditional 0.090)
  across 17 pairs; the correlation is low and nearly static. DCC equity block: `a 0.0097`, `b
  0.942`, average correlation 0.364 (unconditional 0.373); the usual slow-moving equity correlation.
- Book VaR (FX block, 9 positions, 175 $mm gross): one-day VaR99 1.00 $mm, ten-day 3.51, one-day
  ES99 1.38; undiversified one-day VaR99 1.82, so diversification across the FX legs removes 45
  percent. Equity block (EWY, 15 $mm): one-day VaR99 1.19, ten-day 3.72. Total one-day VaR99 1.55
  $mm, ten-day 5.12, one-day ES99 2.04.
- Vol-target scalars: 5 of 27 at the 2.0 cap (USDVND, USDCNY, USDSGD, USDBZD, USDVES), 14 below 1;
  the equity ETFs are all below 1 (EWY 0.21 at 48 percent forecast vol).
- Options: GARCH 63-day forecast vol above 60-day realised for 8 of 10 ETFs; largest gaps MCHI (25.7
  vs 15.6 percent, put fair value +76 percent), ARGT (31.1 vs 22.0), VNM (24.2 vs 18.6); below
  realised for EWY and EWZ. No market quotes supplied, so implied volatility and the
  GARCH-minus-implied spread are blank.
- GPR: global GPR alpha 0.23, beta 0.00, long-run monthly volatility 20.5 percent, conditional 22.5
  percent, ARCH-LM p 0.18; several country series give Gaussian limits (`nu` above 1e6) and
  persistence from 0.09 (IND) to 0.73 (MYS).

The archived `outputs/garch/series.csv` produced earlier on 2026-10-23 holds the same parameters.

## Outputs and how they are used

`GarchResult`: `series` (one row per ticker with parameters, diagnostics, forecasts, VaR, exposures,
scalars), `dcc_fx`, `dcc_eq`, `portfolio`, `options`, `macro`, `vol_history`, `fits`. Written to
`outputs/garch/*.csv`, the GARCH tab (Tables A to F), the GUI Volatility page, and the forecast
record (`var_next`, `es_next`).

## Limitations and known gaps

- Three years of data. 786 observations is adequate for GARCH(1,1) parameters but thin for `nu`
  (standard errors are not computed) and for the 99 percent quantile; the half-sample refits below
  show VaR99 moving by 5 to 11 percent.
- Google Finance quotes are not a trading book's marks: stale and administered rates (USDVES,
  USDNGN, USDARS, USDPKR, USDBZD) show up as near-unit persistence, very low `nu` or fat zero-return
  clusters; the bad-tick rule removes some quote errors but cannot make an official rate a market
  price.
- No standard errors or confidence intervals are reported for any parameter, and the `converged`
  flag is Nelder-Mead's, which is weak evidence of a global optimum (four starts mitigate this).
- The FX and equity blocks are combined with zero correlation between them; the econometrics SVAR
  shows EEM shocks move USDKRW and USDBRL (impact responses -0.28 and -0.39 percent per
  one-standard-deviation EEM shock), so the block independence understates book VaR when the equity
  leg is larger.
- Only 9 of 24 positions are marked (FX and local bonds via the currency, one equity). Local bonds
  are treated as pure currency exposure, ignoring duration; Eurobonds and CDS are excluded.
- The vol-target scalar is a position multiplier without a limit framework; the cap at 2 binds for
  the pegged and managed currencies where low measured volatility is not low risk.
- The Black-Scholes check assumes a lognormal ETF with GARCH volatility and no skew; without market
  quotes it compares two of the model's own numbers.
- `clean_bad_ticks` uses a reversal test that cannot distinguish a genuine one-day spike that
  reverses (for example a devaluation partially walked back) from a quote error.
- By default the GARCH layer is not connected to the Monte Carlo volatilities (12 percent float FX,
  25 percent equity in `assumptions.json`); EWY's conditional volatility is 45 percent against the 25
  percent assumption. EQ-B-0035 adds the connection as an option (below), not switched on.

## Sensitivity

Computed in this validation on the 2026-10-22 prices.

FX book one-day VaR99 (9 positions, median `nu` 4.14), $mm:

| Variant | VaR99 1d $mm |
|---|---|
| Base: Student-t, DCC one-step correlation | 0.997 |
| Unconditional correlation instead of DCC | 0.998 |
| Zero correlation across pairs | 0.810 |
| Gaussian quantile, DCC correlation | 0.877 |
| Student-t `nu 3` | 0.988 |
| Student-t `nu 10` | 0.932 |
| Undiversified (sum of absolute exposures) | 1.821 |
| ES99 1d, base | 1.376 |

DCC versus unconditional correlation makes no difference today because `a` is 0.01 in both blocks
(the correlation barely moves). The Student-t quantile is 14 percent above the Gaussian at `nu` 4.1;
the quantile of a unit-variance t is non-monotone in `nu` near 3 to 4 at the 99 percent level, which
is why `nu 3` gives a slightly lower VaR than `nu 4.1`.

Student-t versus normal and half-sample stability (single series):

| Series | `nu` (t) | Persistence t / normal | Log-likelihood t / normal | VaR99 1d t / normal (%) | VaR99 1d t, second half of sample only (%) |
|---|---|---|---|---|---|
| USDBRL | 4.35 | 0.605 / 0.556 | 2739.6 / 2702.6 | 1.91 / 1.60 | 1.82 |
| EWY | 6.37 | 0.990 / 0.990 | 1977.0 / 1961.6 | 7.91 / 7.21 | 8.24 |
| USDJPY | 4.14 | 0.984 / 0.820 | 2988.6 / 2938.2 | 0.84 / 1.05 | 0.74 |

The Student-t improves the log-likelihood by 15 to 50 points in every case (one extra parameter), so
the t innovation is strongly supported. For USDJPY the normal fit has much lower persistence and a
higher VaR; the two models disagree on the current state, not only on the tail shape.

Vol-target scalar, mean over 27 series and number at the cap:

| `target_vol` \ `scalar_cap` | 1.5 | 2.0 (base) | 3.0 |
|---|---|---|---|
| 0.05 | mean 0.62, 3 at cap | 0.66, 1 | 0.67, 0 |
| 0.10 (base) | 0.96, 8 | 1.07, 5 | 1.24, 3 |
| 0.15 | 1.14, 13 | 1.35, 10 | 1.61, 5 |

At the base settings 14 series would be scaled below 1 (the equities and the floating EM pairs) and
5 at the cap (pegs and managed pairs).

## Benchmarks and evidence

- Unit tests: `test_garch_recovers_parameters` (simulated GARCH, parameters recovered),
  `test_quantiles_and_options`, `test_dcc_tracks_correlation_regimes` (simulated correlation shift),
  `test_bad_tick_cleaning`, `test_run_garch_on_snapshot`.
- Out-of-sample forecast evidence from the econometrics toolkit (Table 1, `variance_horse_race`):
  over the last 250 days with GARCH refit every 50 days, GARCH has the best QLIKE on 15 of 27
  series, EWMA(0.94) on 5, rolling 60-day on 4 and the constant variance on 3 (archived
  `outputs/econometrics/workflow.csv`; the Diebold-Mariano test of GARCH against EWMA is not
  significant at 5 percent for any single series). GARCH is the best or close to the best, which
  supports using it, but it is not uniformly better than EWMA.
- Forecast record (60 backfilled trading days, 2026-07-30 to 2026-10-21, GARCH-DCC refit every 21
  days without look-ahead): 1 exceedance of the one-day VaR99 against 0.6 expected, Kupiec p 0.64,
  Christoffersen conditional coverage p 0.88, Acerbi-Szekely Z2 -0.27 (pass), Basel zone Green; mean
  VaR99 1.72 $mm, mean absolute realised loss 0.56 $mm, largest loss 1.56 $mm. Sixty days is far too
  short for a verdict (the Basel test is meaningful from 250), and the record marks only the 13
  positions with daily prices (210 $mm).
- EVT comparison (Table 7): the GPD tail on standardized losses gives one-day VaR99 within 10
  percent of the Student-t VaR99 for most series, and the tail index `1 / xi` is 3 to 5 for the FX
  pairs with positive `xi`, consistent with `nu` around 4.

## Open items for review

1. Add standard errors (numerical Hessian or bootstrap) for `alpha`, `beta`, `nu` and the DCC
   parameters, and report them in Table A.
2. Decide how to treat administered and pegged currencies (USDVES, USDNGN, USDARS, USDPKR, USDBZD):
   exclude from the DCC block, use a jump model, or flag their VaR as unreliable.
3. Connect the GARCH volatilities to the Monte Carlo market volatilities, or document the deliberate
   separation (daily market risk vs 12-month scenario risk). Option built 2026-10-23 (EQ-B-0035,
   `monte_carlo.vol_source`), default off; decision with Sam.
4. Model the correlation between the FX and equity blocks (one joint DCC or a factor) instead of
   combining them with zero correlation.
5. Add duration to the local-bond marks in the forecast record and the book VaR; today they are
   currency-only.
6. Obtain option quotes (even indicative) so the implied-vol comparison in Table E is a real check.
7. Keep the daily record running; the Basel traffic light needs 250 days and the first 60 are clean.

## Monte Carlo marginals (EQ-B-0035, GOV-020, GOV-034)

Option `monte_carlo.vol_source`: `"regime"` (default, today's numbers bit for bit) or `"garch"`. Code:
`garch.mc_vols`, `layer6_montecarlo.garch_vol_table` and `build_positions`. Not switched on.

- 12-month volatility per leg = `sqrt(sum of the GARCH(1,1)-t daily variance forecasts for t+1 ... t+252) x
  100` (`horizon_days` = 21 x `horizon_months`), from today's conditional variance reverting to the long-run
  variance at rate `alpha + beta`. Same preprocessing and fit as `run_garch` (bad-tick cleaning, business
  days, zero-return filter), so the numbers agree with the GARCH tab. Fits are cached on the return data,
  so the stress runs reuse them.
- Legs: FX positions and the currency leg of local bonds take the `USD<ccy>` forecast
  (`duration x local_rate_vol` is kept for the rate leg); equity positions take the country ETF.
  Eurobond and CDS vols (spread-based) are unchanged.
- Fallback to the regime parameter, with the reason in `positions.vol_from` and
  `positions.attrs["garch_vols"]`: no series or fewer than 250 returns; administered quote
  (`USDVES, USDNGN, USDARS, USDPKR, USDBZD`, GOV-034); persistence `alpha + beta >= 0.995` (half-life above
  138 trading days, where the long-run variance is not identified); FX regime Peg or Dollarized (the MC's
  peg logic, 2 / 0 percent plus the transfer-and-convertibility jump, is kept).
- Stress scenarios: under `"garch"` the vol is `garch_vol x (market value in the run / anchor)`, with the
  anchor equal to the unstressed governed `market.fx_vol` and `market.equity_vol`: a scenario that patches them
  records the pre-patch values in `monte_carlo.garch_vol.anchor`, a run without that key anchors to its own
  values (ratio 1), and an anchor set in assumptions.json wins (`layer6_montecarlo.garch_anchor`, EQ-B-0047;
  until then the anchor was the hard-coded `GARCH_ANCHOR`), so a scenario that doubles `fx_vol.Float` doubles the
  GARCH vol of a floating currency, and `equity_vol set 55` scales EWY by 2.2 (then the 60 percent cap).

Volatilities used on 2026-10-23 (prices to 2026-10-22), percent:

| Position | Leg | Regime | GARCH | Change | Note |
|---|---|---|---|---|---|
| P07 South Korea equity | EWY | 25.0 | 42.8 | +17.8 | persistence 0.99, conditional 45.3 |
| P04 Malaysia FX | USDMYR | 12.0 | 6.2 | -5.8 | |
| P06 Japan FX (short) | USDJPY | 12.0 | 8.5 | -3.5 | |
| P02 Philippines FX | USDPHP | 12.0 | 8.6 | -3.4 | |
| P03 China local bond | USDCNY | 13.0 | 9.6 | -3.4 | 4y x 1.5 + 3.6 |
| P05 / P23 Singapore local bond / FX | USDSGD | 14.5 / 7.0 | 11.8 / 4.3 | -2.7 | |
| P12 / P13 Brazil local bond / FX | USDBRL | 16.5 / 12.0 | 17.6 / 13.1 | +1.1 | |
| P16 Colombia local bond | USDCOP | 19.5 | 20.2 | +0.7 | |
| P08 / P09 India local bond / FX | USDINR | 14.5 / 7.0 | kept | 0 | persistence 0.9961 >= 0.995 (GARCH 6.0) |
| P19 Nigeria FX (short) | USDNGN | 12.0 | kept | 0 | administered (GARCH 12.5, persistence 0.9986) |
| P22 Zimbabwe equity | none | 25.0 | kept | 0 | no series |

Book effect: `copula-montecarlo-layers5-6.md`, change record EQ-B-0035. Limitations of this option:
three years of daily data for a 12-month number; the 12-month forecast is mostly the long-run variance
(half-lives 1.4 to 70 days), so it is a 3-year average volatility with a small conditioning on today; the
administered and near-unit-persistence fallbacks keep judgement numbers for India and Nigeria; GARCH
standard errors are still not computed (GOV-034 item 1).

**Point in time (review fix, 2026-10-23).** Under `monte_carlo.vol_source` "garch", `garch_vol_table` fits on the price
rows dated on or before the run's `as_of` (`garch.prices_as_of`), so a replay or backtest never uses later prices. Test:
`tests/test_market_fit_as_of.py`. Fixed (EQ-B-0047): the stress rescaling anchor was the hard-coded 2026-10-23
value of `market.fx_vol` / `equity_vol` (`GARCH_ANCHOR`), so a later governed change to those keys would have rescaled
every GARCH vol silently. It is now the run's unstressed value (see the stress bullet above); bit-identical today.
