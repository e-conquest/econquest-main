# Text stress index: switch-on dossier (EQ-B-0135, PI-13, roadmap 3.5)

Status: **OFF (Tier 3 research view).** Written 2026-10-26 by Team B AGENT-02. Method: `indicator-rules.md` section 24.
Code: `econquest/rules/text.py` (method `tsi_lex_v1`), `econquest/validation/text_index.py` (schema `eq-text-index/1`).
Tests: `tests/test_text_index_b135.py` (SYNTHETIC stores in tmp_path only). Corpus: Team A EQ-A-0131
(HO-20261026-A-B-012, `docs/runbooks/A-text-corpus.md`).

## 1. What ships today

| Piece | State |
|---|---|
| Index and signal | Built and tested: dictionary topic and tone scoring per document, 90-day country index by month-end on the knowledge basis, early-warning state against the country's own 36-month history |
| Backtest harness | Built and tested on CRAG crag_v1 episodes. On today's corpus it reports `not run: corpus empty`. On SYNTHETIC stores it runs in tests only (`allow_synthetic=True` raises outside pytest) |
| Real corpus | Empty until Sam's Mac pull (A-sam-ready item 18). Every document will be client-restricted |
| Switch | `text_index.enabled` in `data/assumptions.json`. The key is absent, so the switch is off |
| M17 demo | `demo_text_index(out_dir)` runs the method on a SYNTHETIC sandbox store under `out_dir/text_index/` and labels every row and file SYNTHETIC. It reads and writes nothing else |

**No effect while off.** No module in engine, scorecard, presentation, ops, persistence, ingestion or the CLI imports
`validation.text_index` (test `test_nothing_in_the_run_path_imports_the_text_index`). `run()` returns status `off` and
reads and writes nothing. The 20k base was checked identical before and after the change: 66.95612571109443 /
89.00003057231508 / 4.098636048964449 / 72.23763153780678.

**Even when on, it stays off the risk numbers.** Switching on lets `run()` and `python -m econquest.validation.text_index
run --out outputs` write the internal research rows (`outputs/text_index/`). Nothing feeds the scorecard, PDs, Monte
Carlo, limits or publish. Feeding the index into any risk number would be a separate Tier 1 card with an effect table.

## 2. Commands (after the Mac pull)

```
python -m econquest.validation.text_index status --as-of 2026-11-30
python -m econquest.validation.text_index backtest --as-of 2026-11-30
python -m econquest.validation.text_index backtest --as-of 2026-11-30 --basis published
python -m econquest.validation.text_index demo --out outputs --real-as-of 2026-11-30
```

`run` and `backtest` require `--as-of`; no date is taken from the clock (AGENT-09 review HO-20261026-B-B-016 F1). The
demo's dates are fixed defaults for the demo only: sandbox 2020-12-31, real-corpus state line 2026-10-26 unless
`--real-as-of` / `real_as_of` is given.

## 3. Evidence needed before the switch goes on

All of these must hold. AGENT-08 (Team B) collects them, and an independent reviewer (four-eyes, not the author)
signs.

| # | Evidence | Bar | Who |
|---|---|---|---|
| E1 | Corpus pulled and clean | `python -m econquest.ingestion.text verify` clean; each source used is `layout_verified=True` after its dry run (Team A runbook section 3) | Sam (Mac), Team A |
| E2 | Corpus depth | At least 5 scored years per desk name before the first test year. The runbook's `--max-docs 50` per source gives about one to four years of releases, which is too shallow. Archive or listing pages back to 2015 are needed (Team A follow-up) | Team A |
| E3 | Backtest on the knowledge basis | `backtest()` with `passes_bar` true: at least 5 episodes, AUC >= 0.70, hit rate >= 0.60 (warning within 24 months before the start year), median lead >= 3 months, false-alarm rate <= 0.25 (`SWITCH_ON_BAR`) | Team B |
| E4 | Published-basis replay | `--basis published`, shown next to E3 as secondary evidence only. It never sets `passes_bar`. The reviewer reads it for revision effects (version 1 compared with later versions) | Team B, reviewer |
| E5 | Licence check | Sam reads the terms of each `text_cb_<iso3>` row and `text_imf`, and `text_corpus_store` keeps internal use = yes. Client output stays restricted: rows carry `licence_class` and `client_safe_rows()` drops them. A client view needs `client_output=allowed` on every document row and on the store row | Sam |
| E6 | Language coverage | Today's lexicon is English only. VNM (vi), BRA (pt), ARG, COL and VEN (es) and SEN (fr) central bank texts are not scored, so these names rely on IMF texts. Either reviewed lexicons for those languages, or the view states the gap for each name | Team B, reviewer |
| E7 | Review | An independent reviewer reads the lexicon (`rules/text.py`), reruns `tests/test_text_index_b135.py` and the backtest, and checks 20 scored documents by hand against `score_document`. Findings are logged and closed | Reviewer (4.5) |
| E8 | Change record | The switch goes on through `econquest change` with an author and an approver (Tier 3 research view). The base stays bit-identical (20k check) | Sam, AGENT-08 |

**Known limit of E3 (Sam's decision).** CRAG crag_v1 has only four desk-name episode starts in 2016-2026: BLZ 2016,
VEN 2016, ZMB 2020 and BLZ 2021. ARG and ZWE are in continuous spells. The 5-episode bar therefore cannot be met with
CRAG alone. Sam needs to choose one of these:

- (a) add a second event set that is already in the folder or that Team A builds: IMF programme requests from the
  event calendar (EQ-A-0132, empty until the Mac pass), or large FX depreciation episodes from the price history;
- (b) extend the corpus beyond the 18 desk names;
- (c) accept a case-study review of the four episodes instead of the AUC bar.

**Known limit of the knowledge basis.** A first pull retrieves the whole archive on one day, so a strict knowledge-time
replay of any earlier date sees nothing (`not run: no point-in-time history on the knowledge basis`). A strict
backtest record builds up only from the first pull onward. The published basis replays the archive as first stored,
which is why E4 is secondary evidence.

## 4. Parked card for first-mac-pass section B (for the lead; not posted)

> | D-next | Text stress index (EQ-B-0135, roadmap 3.5): keep it off until the Mac pull and the evidence in docs/validation/text-stress-index.md section 3; choose the episode set for the backtest bar (a) add IMF programme requests or FX depreciation episodes, (b) widen the corpus, (c) case-study review of the 4 CRAG desk-name episodes; and read the central bank and IMF text terms (client output stays restricted) | Keep off; (a) once the event calendar has IMF review and programme dates; terms read in the D4 licence batch | optional |

Signing terms: the switch stays off, so no risk number moves. Switching on later is a Tier 3 `econquest change` on
`assumptions.json` `text_index.enabled`, with evidence E1-E8 attached. There is no effect table because the base does
not move.

## 5. Output schema `eq-text-index/1`

One row per desk name and date (month-end, plus the as_of date). The columns are `TEXT_COLUMNS`:

| Column | Meaning |
|---|---|
| country, iso | Desk name (data/countries.csv) and ISO3 |
| date, as_of | The date the value refers to. as_of is the knowledge cut, which equals date |
| basis | `knowledge` (real runs). `published` only in the labelled replay |
| window_days | 90 |
| n_docs, n_scored, n_tokens | Documents in the window, documents scored (English, at least 50 words), and the words they contain |
| stress_index | Mean document stress, per 1000 words: tone_net_pk + 2 x severe_pk |
| tone_net_pk, severe_pk | Net negative tone and distress-term rate, per 1000 words |
| topic_{fiscal,external,banking,inflation,imf_programme,distress}_pk | Topic term rates, per 1000 words |
| z_level, delta_3m, dz_3m, hist_n | Level z against the own 36-month history, the 3-month change and its z, and the number of history points |
| signal | `warning`, `watch`, `normal`, `no_history` or `insufficient` |
| status | `value`, `insufficient` (fewer than 2 scored documents) or `empty` |
| method | `tsi_lex_v1` |
| licence_class | The most restrictive client_output of the documents' register rows and `text_corpus_store`: `allowed`, `restricted` or `barred`. It is `restricted` when no document was read |
| client_ok | True only when licence_class is allowed, every document is client_ok and the row is not synthetic. It is False for every row today |
| synthetic | True only for SYNTHETIC sandbox or test stores. The note column then starts with the SYNTHETIC label |
| sources, note | Corpus registry keys used, and the reasons documents were not scored |
