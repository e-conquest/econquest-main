# Client-safe run (EQ-B-0089, EQ-B-0096, EQ-B-0106)

Status: analysis for Sam's open decision on client mode. Nothing here changes the engine, settings or data. Latest
results (section 4, EQ-B-0106): the current shared data (0.6.0 code, Team A's 17:06Z fx3m apply EQ-A-0112 included)
at as_of 2026-10-23, 100,000 requested paths, with Team A's client-safe source route (EQ-A-0106). They are not
synthetic.

Code: `econquest/validation/client_safe.py`. Tests: `tests/test_client_safe.py` (rule and fallbacks on synthetic
fixtures; the paired run on a temporary copy of the shipped data at 4,096 paths).
Report: `outputs/client-safe-comparison/2026-10-23/` (route on `data/live`) and
`outputs/client-safe-comparison/2026-10-23-route-sam-wb-pull/` (route on Sam's recorded World Bank pull) (`client-safe.md`, `.json`, metrics, countries, inputs and
signals CSVs). **The report is internal.** It compares against today's run, whose numbers use EXC-003 / EXC-005 data;
every file says so on its first line (the CSVs as a `#` comment; the json in `classification`). The inputs file lists
which cells were replaced and their cleared new values, never the restricted values themselves.

## 1. Question

What would the model say if it used only what licence enforcement lets out to a client?

## 2. Method

1. **One rule (EQ-B-0096, HO-20261025-C-B-002).** The cells left out are exactly the cells Team C's licence
   enforcement withholds: `presentation.licences.evaluate(data)["internal_only"]` (EQ-C-0093), which reads Team A's
   register `data/licences.csv` (EQ-A-0076). `client_safe.withheld_cells` is the one call. It refuses whatever Team
   C refuses (second review of EQ-B-0096): a register that did not load, an incomplete evaluation, any evaluate
   problem other than the change-control note, `register_mismatch` (SEC-C-017), and a register that drifted from the
   approved version (`ops.licence_gov`, R44). The approved register (Sam's baseline snapshot) decides cells and
   files alike. **Today the shared register has no approved version yet (status `no_baseline`)**, so a plain run
   refuses; `--allow-unapproved-register` accepts that one state (never drift or a mismatch) for internal analysis,
   uses `data/licences.csv` as it stands, and puts a WARNING on the report's first lines. The run below used it. On the shipped data enforcement withholds 492 cells
   and the copy changes all 492 (`cells_changed` = `cells_withheld_by_enforcement` = 492; a test checks that the two
   lists are equal).
2. **IMF-citing seeds are withheld.** 305 seed cells have an audit-trail series that cites IMF ("intended: IMF
   Article IV ..."). Under the conservative rule a seed copied from WEO is IMF-derived, so they are withheld, and no
   analyst seed is used as a fallback for any indicator cell. (The first run, EQ-B-0089, kept them and changed 177
   cells.)
3. **Files** are decided by `file_decision` on the approved register (evaluate covers cells, not files): a file
   whose register row is not client-allowed is left out. It is an allow-list: a file with **no** register row is left
   out and reported (`files_left_out_unregistered`), except the two cell-governed tables (`countries.csv`,
   `indicators.csv`) and the desk's configuration (`assumptions.json`, `limits.json`, `scenarios.json`,
   `rulebook.csv`, `portfolio.csv`, `playbook.csv`, `panel/universe_proposal.csv`). At the 100k run below 52 files
   had no register row and were left out that way (audit trail, live pull logs, approvals, panel research files and
   others). Team A has since registered all of them (`desk_config`, `live_pipeline_mixed`, `desk_metadata`, all
   restricted), so they are still left out, now under their own rows; removing them changes no number (the "Other
   only" run below). `prices.csv` is cut per column from its sidecar's EXC-005 list; a
   missing list stops the run.
4. **Fallbacks read only what the copy keeps.** The 2.1 recompute needs `dsa_inputs.csv` (short-term debt, broad
   money, other liabilities). That file is restricted (EXC-003: its estimates come from IMF Article IV), so 2.1 reads
   neither it nor the World Bank file and takes the placeholder; a test spies on file reads to check this.
5. **A temporary copy.** `build_client_safe_copy` copies the data folder and replaces every withheld cell there.
   `data/` is only read.
6. **Paired runs.** The base and the 14 stress scenarios of the 0.5.0 record run on today's data and on the copy,
   with the same random numbers; the paired batch-means SE of each change is reported. Data-folder settings
   (`dsa.data_dir`, `dsa.inputs_path`, `layer1.missing_input_data_dir`) point at the folder each run uses.
7. **Decomposition.** One extra base run per component (IMF, EXC-005, Yahoo, other). The parts interact.

Reproduce:

```
python -m econquest.validation.client_safe --as-of 2026-10-23 --allow-unapproved-register     # about 2 minutes
python -m econquest.validation.client_safe --as-of 2026-10-23 --allow-unapproved-register --components imf --scenarios none
```

`--out` must resolve under `outputs/` (default `outputs/client-safe-comparison/<as_of>`). Once Sam baselines the
register, drop `--allow-unapproved-register`.

## 3. What is withheld and what replaces it

Fallbacks, first that applies (`plan_replacements`):

| Fallback | Used for | Cells |
|---|---|---:|
| World Bank GDP / population | 5.14 GDP per person | 18 |
| fx3m stressed placeholder, 30 (section 3b; EQ-B-0130 replaced the analyst seed; the only official series is theratesapi.com, EXC-005) | fx3m Vietnam, Pakistan, Venezuela, Nigeria, Zambia | 5 |
| (before EQ-A-0112) official fx3m from cleared `prices.csv` columns, or 0 for the Belize USD peg | fx3m (Yahoo) | 0 now (12 before): Team A's official fx3m apply removed the Yahoo values |
| **Team A's client-safe source route (EQ-A-0106)**, on cells still blank or on the placeholder: the first cleared, verified non-IMF source | 2.11 (WDI TX.VAL.*.ZS.UN, Comtrade via WITS) for BLZ, BRA, COL, NGA, SEN, ZMB | 0 on `data/live`; 6 with Sam's pull |
| Judgement `market.equity_vol` from the settings (25; the engine already uses it; `countries.csv` has no equity_vol column, so nothing changes) | equity_vol (Yahoo, current pull) | 10 |
| Judgement placeholder: rulebook worst score t100 (scores 100; section 3c; t50 before EQ-B-0130): the scorecard refuses a blank *required* input | 1.3, 1.4, 1.6, 1.7, 2.1, 2.7, 2.8, 5.5, 5.6, 5.12 (18 each); 2.11 (18, or 12 with Sam's pull) | 198 (192) |
| Blank: the scorecard drops the indicator from its pillar average; signals that read it go blank | 1.1, 2.2-2.6, 3.8, 5.1, 5.2, 5.4, 5.8, 7.13 (18 each); 1.2 (5), 2.12 (8), 5.9 (9), 5.10 (3), 5.13 (8) | 249 |

Withheld today: 480 cells, 465 IMF (`imf_weo` 133, `imf_derived` 332, 305 of them seeds) and 15 Yahoo (10 equity_vol
from the current pull, 5 fx3m). Before EQ-A-0112: 492 (27 Yahoo).
EXC-005 price columns dropped: USDVND, USDPKR, USDBZD, USDVES, USDNGN, USDZMW. Files left out: raw WEO pulls, raw
Yahoo, the GOOGLEFINANCE archive and repairs, the theratesapi build copy, FRED-OECD spread metadata, `fx_manual.csv`,
`dsa_inputs.csv` and `panel/hazard_panel.csv` (register rows, restricted), plus the 52 files with no register row.

Kept as allowed by the register: World Bank WDI/IDS, BIS, ECB, official parities, seeds that cite no IMF source,
analyst adjustments, CDS quotes, prediction markets, GPR. ACLED, UCDP and GDELT feed nothing today.

## 3a. Reserves placeholder at the stressed end (EQ-B-0130)

Sam's D3 "no" withholds Country Profile reserves (% of GDP). Readiness refuses a blank, so the plan writes a
judgement placeholder, `RESERVES_PLACEHOLDER_PCT_GDP`.

**Rule.** A placeholder for a missing value must never make a country look safer than its data would. So the
placeholder sits at the stressed end:
- a fixed **0.5% of GDP**, the same for every country;
- below every reserves value in the shipped universe (`data/` and `data/mvp`);
- read from no country's data. A statistic of the cleared values (such as their 25th percentile) is not used:
  under a full D3 "no" no reserves value is cleared;
- above 0, because the peg reserve-erosion step divides by it.

**Why it changed.** EQ-B-0128 used 15% of GDP, near the universe median. On AGENT-02's client-safe pack this
lowered every PD under D3 "no". Two effects:
- withheld names with low reserves were raised to 15, so their own PD fell;
- layer 1 calibrates its index to the rating priors across the universe (location and scale), so one name's
  input moves every name's PD.

**Trace (internal copies only, 20,000 paths).** Portfolio expected loss and VaR99, $mm:

| Universe | Data | Placeholder 15 | Placeholder 0.5 |
|---|---:|---:|---:|
| Client-safe pack (`data/mvp` variant, 3 names withheld), as_of 2026-10-25 | 3.74 / 73.05 | 2.74 / 68.03 | 3.83 / 73.15 |
| Shipped data, all 18 names on the placeholder, as_of 2026-10-23 | 4.10 / 66.96 | 1.58 / 54.32 | 4.11 / 67.17 |

- At 15, pd_default fell for every name except Venezuela (capped at 0.99), by about 10% to 80%.
- At 0.5, the portfolio numbers are at or above the data's. A single name's pd_default can still move down by
  up to 7%, through the calibration. That limit is not a property of the placeholder.

**Test** (`tests/test_client_safe_b130.py`, temporary copies of the shipped data):
- the placeholder is above 0 and below every shipped value;
- with every name on the placeholder, expected loss and VaR99 are not below the data's;
- every pd_default is at least 90% of the data's (the calibration tolerance);
- the old value 15 fails these checks.

The house base does not use the placeholder and is unchanged. A cleared national central-bank series can replace
the placeholder later.

## 3b. fx3m placeholder at the stressed end (EQ-B-0130)

fx3m is the 3-month currency move, in % depreciation (up is adverse). The EXC-005 currencies (VND, PKR, VES, NGN,
ZMW) have no cleared official series. If BIS, ECB or an official parity gives no value, the cell needs a
placeholder:
- a blank fails readiness (fx3m is a required profile field);
- the engine reads fx3m in three places, and each gets worse as fx3m rises:
  - the layer 2 FX term (fx3m / 5, weighted by regime);
  - the layer 3 rule regime (Stressed at 5 or more, Crisis at 15 or more);
  - the stress add-ons;
- so 0 ("no move") or an analyst seed can make a name look safer than its data.

**Rule.** `FX3M_PLACEHOLDER_PCT` = **30**:
- twice the shipped `regime_rules.crisis_fx3m`, and above every shipped fx3m value;
- the same for every name, read from no country's data;
- it puts the name in the Crisis regime.

Order in `plan_replacements`: official fx3m (BIS / ECB / parity, 0 for a USD hard peg), else this placeholder. The
earlier analyst-seed and 0.0 fallbacks are removed. Team A's client-safe datasets use the same constant
(HO-20261026-B-A-006).

**Trace (internal copies only, 20,000 paths, the five names replaced).** Portfolio expected loss and VaR99, $mm:

| Universe | Data | Placeholder 0 | Placeholder 30 |
|---|---:|---:|---:|
| Shipped data, as_of 2026-10-23 | 4.10 / 66.96 | 4.06 / 66.91 | 5.53 / 83.15 |
| Client-safe pack (`data/mvp` d3_no variant), as_of 2026-10-25 | 2.74 / 68.03 | 2.72 / 68.02 | 3.50 / 84.67 |

- At 0, one name's pd_default fell by 17%, and EL fell.
- At 30, every replaced name's pd_default is at or above its data value (Venezuela stays at the 0.99 cap). The
  other names do not move: the FX term is per name, with no universe calibration.

**Test** (`tests/test_client_safe_b130_fx.py`, temporary copies of the shipped data):
- the placeholder is at least twice crisis_fx3m and above every shipped value;
- a blank fails readiness;
- with the five names on the placeholder, no pd_default, EL or VaR99 is below the data's, and the five are in
  Crisis;
- the old value 0 fails these checks.

The house base does not use the placeholder and is unchanged.

## 3c. Required-indicator placeholder at the stressed end (EQ-B-0130)

The scorecard refuses a blank required input. Some required indicators have no cleared value in client mode:
1.3, 1.4, 1.6, 1.7, 2.1, 2.7, 2.8, 2.11, 5.5, 5.6 and 5.12, for all 18 names (198 cells). These cells used the
rulebook midpoint t50, which scores 50.

**t50 can improve a name.** Scores run from 0 (safe) to 100 (worst). Any name whose data scores above 50 looks safer
at t50. An internal trace on the shipped data found 55 of the 198 cells in that position. Also, a floor reads the
raw 5.5 value: at or above the hyperinflation threshold, pillar 5 is floored. The t50 value drops that floor.

**Rule.** The rulebook's worst score, **t100** (score 100), the same for every name and read from no country's data.
Where a pillar floor reads the raw value above t100, the placeholder is at least the floor's threshold
(`FLOOR_THRESHOLDS`: 5.5 takes `floors.p5_hyperinflation_threshold`, so every name gets the hyperinflation floor).
The seed is not used: under the conservative rule a seed that cites IMF is IMF-derived, and "the worse of t50 and
the seed" would show the seed whenever it is worse.

**Order.** The plan first marks these cells "judgement placeholder: rulebook midpoint t50" (`MIDPOINT_KIND`).
Team A's route replaces cells on that marker with a cleared non-IMF value where one exists. Then
`stress_placeholders` turns every cell still on the marker into t100 (fallback
"judgement placeholder: rulebook worst score t100"). `plan_replacements(route=False)` returns the plan before both
steps. A caller that runs the route itself must call `stress_placeholders` after it (HO-20261026-B-A-007).

**Trace (internal copies only, shipped data, 20,000 paths, as_of 2026-10-23).** All 198 cells replaced:

| | Data | t50 | Rule (t100, 5.5 floor) |
|---|---:|---:|---:|
| Expected loss, $mm | 4.10 | 4.15 | 8.87 |
| VaR99, $mm | 66.96 | 68.95 | 90.98 |
| Names with a lower pd_default than the data | - | 7 (down to 0.69x) | 0 |
| Names with a lower composite than the data | - | 5 (down to -4.3) | 0 |

The rule is harsh by design: client-safe numbers read high while these inputs have no cleared source. Each cleared
source that lands (Team A's route) replaces a placeholder.

**Test** (`tests/test_client_safe_b130_t100.py`, temporary copies of the shipped data):
- no cell is left on the midpoint, and every placeholder scores 100;
- every 5.5 placeholder is at or above the hyperinflation threshold;
- EL and VaR99 are not below the data's, no composite falls, and every pd_default is at least 90% of the data's
  (the calibration tolerance);
- the midpoint t50 fails these checks.

The house base does not use the placeholder and is unchanged.

## 4. Results, EQ-B-0106: Team A's non-IMF route (100,000 requested paths, as_of 2026-10-23)

**Base compared against:** the current shared data, including Team A's 17:06Z fx3m apply (EQ-A-0112). At 100k it is
VaR99 66.78, ES99 88.48, EL 4.10, L-VaR99 72.06. At 20k it is 66.95612571109443 / 89.00003057231508 /
4.098636048964449 / 72.23763153780678, matching the coordinator's figures; AGENT-05 is restating it. This is not
the 0.6.0 record (66.70 / 88.43 / 4.08 / 71.99): only the fx3m apply moved it.

Register `no_baseline`, run with `--allow-unapproved-register`. Every withheld cell is changed: `cells_changed` =
withheld = 480. Team A's route is wired into `plan_replacements` (HO-20261025-A-B-014 item 1). It changes only cells
still blank or on the placeholder, and labels the rest "no free non-IMF substitute (EQ-A-0106): ...".

Two runs:
- **Route on `data/live`.** This is what A-0106 ships today. The landed World Bank file has 9 series, none of them the
  route's, so the route clears **0** cells; only the labels change.
- **Route on Sam's recorded World Bank pull** (`--route-wb team/inbox/pull-20261025T013150Z/raw_worldbank.csv`). That
  pull is in the shared folder but not yet landed in `data/live`. The route clears **6** cells: 2.11 export
  concentration for Belize, Brazil, Colombia, Nigeria, Senegal and Zambia.

| Metric ($mm) | House (today) | Client-safe, route on data/live | Gap | Client-safe, route on Sam's pull | Gap | Paired SE |
|---|---:|---:|---:|---:|---:|---:|
| VaR99 | 66.78 | 72.95 | +6.16 (+9.2%) | 72.66 | +5.87 (+8.8%) | 0.27 |
| ES99 | 88.48 | 93.75 | +5.26 (+5.9%) | 93.43 | +4.95 (+5.6%) | 0.20 |
| EL | 4.10 | 4.19 | +0.08 (+2.0%) | 4.13 | +0.03 (+0.7%) | |
| L-VaR99 | 72.06 | 78.23 | +6.16 (+8.6%) | 77.94 | +5.87 (+8.2%) | |

Stress ES99 gap (client-safe minus house, $mm): from +2.15 (TARIFF) to +8.54 (B) on `data/live`, and from +1.67 to
+8.43 with Sam's pull. All 14 scenarios are higher.

**Drivers of the gap** (each component alone, base, data/live; with Sam's pull in brackets):

| Component | Cells | VaR99 | ES99 | EL |
|---|---:|---:|---:|---:|
| IMF (465 cells) | 465 | +5.09 (+4.99) | +3.92 (+3.62) | +0.10 (+0.05) |
| EXC-005 price columns (VND, PKR, BZD, VES, NGN, ZMW) | 5 fx3m cells + 6 columns | +0.76 | +1.17 | -0.02 |
| Yahoo (10 equity_vol, no column in the data) | 10 | 0.00 | 0.00 | 0.00 |
| Other (files with restricted register rows; unregistered snapshot files) | 0 | 0.00 | 0.00 | 0.00 |

1. **2.1 reserves adequacy at the placeholder (100% of ARA for all 18)** is nearly all of the IMF part. The
   EQ-B-0096 20k check: putting today's 2.1 back takes VaR99 from 64.07 to 58.16 on the IMF-only copy. A-0106 has no
   cleared 2.1. Its rule-17 route (EQ-B-0104, `validation/nonimf_ara.py`) is **conditional**: WDI reserves and
   broad money are IMF IFS, IIP sources are UNVERIFIED, and there are no official net reserves for PAK, ARG, VEN or
   NGA. So 2.1 stays on the placeholder until Sam rules on IMF-compiled WDI.
2. **The other 9 placeholder indicators** (1.3, 1.4, 1.6, 1.7, 2.7, 2.8, 5.5, 5.6, 5.12) score every country at 50.
   That pulls low-risk names up and high-risk names down (Senegal PD 13.3 to 10.0).
3. **The EXC-005 FX columns** add about 1.2 $mm of ES99.
4. **The 6 route cells** (2.11) close 0.29 of the VaR99 gap, 0.31 of ES99 and 0.05 of EL.

Country default PDs (%), largest moves, route on data/live (Sam's pull in brackets): Zimbabwe 78.40 to 89.96,
Senegal 13.34 to 9.99 (9.21), Argentina 6.61 to 9.61, Pakistan 8.11 to 9.64, Zambia 4.66 to 5.28 (5.44), Belize 4.86
to 5.25 (5.60), Nigeria 3.99 to 4.19 (4.43). No regime changes. As before, signals 1, 4, 7 and 18 go blank and 26 is
not computed; 5 and 6 fire for 12 countries on the midpoint. 34 playbook activations change (32 with Sam's pull).

**Still placeholders or blank after A-0106** (465 IMF cells; with Sam's pull, 18 cleared + 6 route = 24 cleared):

| State | Indicators (cells) | Why (A-0106 runbook) |
|---|---|---|
| Placeholder t50 (192) | 1.3, 1.7 (UNVERIFIED national/OECD only; WDI is IMF GFS); 1.4, 1.6 (IMF only); 2.1 (rule 17 conditional, see above); 2.7 (FATF re-entry not done); 2.8, 5.5 (conditional: IMF BOP/IFS in WDI); 5.6 (forecasts: WB GEP / OECD EO UNVERIFIED); 5.12 (built, but the pull has 6 years and the rule needs 8: next pull) (18 each); 2.11 (12: ARG, ZWE below 75% coverage, VEN stale, 9 manufacturers blanked by rule 2.11) | no free, verified, non-IMF source in recorded data |
| Blank (249) | 1.1, 2.2, 2.3, 2.4, 2.5, 2.6, 3.8, 5.1, 5.2, 5.4, 5.8, 7.13 (18 each); 5.9 (9), 2.12 (8), 5.13 (8, conditional), 1.2 (5), 5.10 (3) | only IMF, or national/BIS/FSB sources with no adapter, or licences unknown |
| Cleared (24) | 5.14 (18, Team B's WB recompute); 2.11 (6, route, Sam's pull) | |

Team A projects 42 cleared after the next pull (5.12 with 20 years of WDI growth) and up to 80 if Sam clears the
IMF-compiled WDI series (2.8, 5.5, 5.13, and 2.1 through rule 17). **Projection only, not run.**

**Definition (HO-20261025-A-B-014 item 2, 5.12).** The client-safe 5.12 takes the SD of WDI real growth to the last
actual year, not WEO to year t including the projection. It is the same formula and does not apply until the next
pull. The handoff is addressed to B/AGENT-08 to accept; AGENT-07 sees no objection, because a projection is IMF
content in any case.

## 4a. Earlier result: EQ-B-0096 second review (before EQ-A-0112 and A-0106)

Run after the second review of EQ-B-0096 (register `no_baseline`, `--allow-unapproved-register`). Portfolio, $mm.
"Today" equals the 0.5.0 base exactly (that data state; superseded by section 4). The last two columns are the earlier runs: EQ-B-0096 first pass (2.1 from
`dsa_inputs.csv`, now withheld) and EQ-B-0089 (177 cells, seeds kept).

| Metric | Today | Client-safe | Change | Paired SE | EQ-B-0096 first pass | EQ-B-0089 |
|---|---:|---:|---:|---:|---:|---:|
| VaR99 | 58.19 | 64.27 | +6.09 (+10.5%) | 0.27 | 61.11 | 58.93 |
| ES99 | 78.72 | 83.93 | +5.21 (+6.6%) | 0.18 | 80.09 | 79.42 |
| EL | 0.88 | 0.96 | +0.08 (+9.5%) | | 0.74 | 0.86 |
| L-VaR99 | 63.47 | 69.55 | +6.09 (+9.6%) | | 66.39 | 64.21 |

**Why it moved from the first pass: indicator 2.1.** With `dsa_inputs.csv` withheld, 2.1 (reserves, % of the IMF
ARA metric) sits at the rulebook midpoint, 100, for all 18 countries, where today's values run from 15.5 (Zimbabwe)
to 300 (Japan); Singapore, Japan, India, the Philippines, Brazil and Colombia lose most of their reserve cushion in
the stress path. A 20k check (the IMF-only copy with today's 2.1 put back) gives VaR99 58.16 and ES99 78.14 against
64.07 and 83.17 with the placeholder: the 2.1 placeholder accounts for nearly all of the change.

Stress ES99, $mm (paired SE 0.18 to 0.29):

| Scenario | Today | Client-safe | Change |
|---|---:|---:|---:|
| A | 131.40 | 137.62 | +6.22 |
| B | 85.87 | 94.11 | +8.24 |
| C | 95.19 | 100.70 | +5.52 |
| DOWNGRADE | 82.32 | 87.49 | +5.18 |
| TAIWAN | 136.98 | 142.98 | +6.00 |
| HORMUZ | 138.35 | 144.34 | +5.99 |
| TARIFF | 127.91 | 130.25 | +2.34 |
| CHINA_HL | 137.93 | 140.93 | +3.00 |
| FED22 | 147.60 | 149.90 | +2.30 |
| TAPER13 | 140.54 | 146.36 | +5.82 |
| MACRO_FED | 140.79 | 144.78 | +3.99 |
| MACRO_CHINA | 122.72 | 127.37 | +4.65 |
| MACRO_OIL | 125.20 | 130.85 | +5.65 |
| MACRO_WAR_ASIA | 149.15 | 154.39 | +5.24 |

Decomposition of the base change (each component alone):

| Component | VaR99 | ES99 | EL |
|---|---:|---:|---:|
| IMF only (465 cells, raw WEO, `dsa_inputs.csv`) | +5.11 | +3.93 | +0.11 |
| EXC-005 only (6 price columns) | +1.02 | +1.13 | 0.00 |
| Yahoo only (27 cells) | -0.09 | -0.06 | -0.02 |
| Other only (incl. the 52 unregistered files) | 0.00 | 0.00 | 0.00 |

Country default PDs (%), largest moves:

| Country | Today | Client-safe | Change (pp) |
|---|---:|---:|---:|
| Zimbabwe | 78.40 | 89.96 | +11.56 |
| Senegal | 13.34 | 9.99 | -3.36 |
| Argentina | 6.60 | 9.39 | +2.79 |
| Pakistan | 8.04 | 9.72 | +1.68 |
| Nigeria | 3.88 | 4.53 | +0.65 |
| Belize | 4.86 | 5.25 | +0.39 |
| Vietnam | 0.36 | 0.58 | +0.22 |
| Zambia | 4.53 | 4.32 | -0.20 |

No regime changes. Composite scores move by up to about 9 points (Vietnam 29.0 to 38.3): the rulebook midpoints pull
low-risk countries towards 50 on the macro indicators.

Signals and notes (base run):

- Signal 26 (DSA, "IMF benchmark") is not computed for any country (no WEO pull).
- Signals 1 (debt payment wall), 4 (devaluation pressure), 7 (banking stress) and 18 (official backstop stress)
  become blank for all 18 countries: each reads an indicator that is now blank.
- Signals 5 (inflation) and 6 (growth slowdown) start firing for 12 countries each: the midpoint (inflation 10%,
  growth 2%) plus the stress-path shock scores above the firing threshold (60).
- 34 playbook activations change (full list in the report).

## 5. What it means for the client-mode decision (Sam's)

1. **Under the conservative rule the model cannot give clients country numbers that mean much.** 465 cells are IMF
   or IMF-derived. With no cleared replacement, 11 required indicators (2.1 included) sit at the rulebook midpoint for every country
   and 17 more are fully or partly blank. The country scores then reflect "no information", not the countries.
2. **Portfolio numbers rise by 7 to 11%.** VaR99 +10.5%, ES99 +6.6%, EL +9.5%; stress ES99 +2.3 to +8.2 $mm.
   Nearly all of it is the 2.1 placeholder (reserves at 100% of ARA everywhere); the EXC-005 FX columns add about
   1 $mm of ES99. A cleared 2.1 needs World Bank short-term external debt (DT.DOD.DSTC.CD) and broad money
   (FM.LBL.BMNY.GD.ZS), which the current World Bank pull does not fetch (Team A), plus other liabilities.
3. **Signals are not client-ready:** 26 is gone, 1, 4, 7 and 18 are blank, and 5 and 6 fire on the midpoint.
4. **Paths open to Sam** (no recommendation here):
   - IMF permission (Team C's C-0083): client output equals desk output.
   - Cleared replacements: World Bank WDI history covers debt, current account, inflation, growth and GDP per head,
     but not WEO projections (5.6 is year t+1) or general-government primary balances; the 305 seeds need sourced,
     non-IMF values. This needs Team A feeds and a Team B review of each.
   - Client output at portfolio level only, with country drivers and signals kept internal.
5. **Desk issue found on the way.** `countries.csv` fx3m still holds Yahoo values for 17 countries, which are barred
   from desk numbers. Team A's official FX fetch on the Mac replaces them.

## 6. Limitations

- One as_of date and one data state (0.5.0 base).
- The rulebook midpoint is a judgement placeholder for required inputs, not data.
- 5.14 uses the latest World Bank year on or before as_of. 2.1 is a placeholder (see 4).
- The licence register has no approved version yet; this run is labelled as such and clears nothing for clients.
- The register's licence texts are mostly UNVERIFIED. "Allowed" means allowed by the register.
- Monte Carlo noise: paired SEs 0.03 to 0.31 $mm.
- Register gaps: none left. The 52 files with no row at the 100k run (listed in the report's manifest,
  `files_left_out_unregistered`) now have Team A rows, all restricted; the copy leaves out the same files.
