# House view: one stance per country for every product (EQ-B-0115)

Team B AGENT-03, 2026-10-25. Code: `econquest/validation/house_view.py`. Tests: `tests/test_house_view.py`.

The country notes, the weekly brief and the trade-ideas page must say the same thing about a country. The house view
is that one thing. It is built once per run, written next to the run, and every product reads it. No product
derives its own stance. Nothing here feeds a PD, a loss or a limit, and nothing in `data/` is written.

## Commands

```bash
python -m econquest.validation.house_view build --out outputs/reports/mvp --data data
python -m econquest.validation.house_view check --out outputs/reports/mvp --data data   # exit 1 on a problem
```

`build` runs after the run and its research inputs (DSA, nowcast, GPR) and before the products. `check` runs after
the products. Exit 2 means there is no run in `--out`.

## What build writes (in the run folder)

| File | Content |
|---|---|
| `house_view.json` | schema `eq-house-view/1`: run_id, as_of, data_hash, run_hash, the rules, a hash of each input, one record per country |
| `house_view.csv` | the same, one flat row per country |
| `peers.csv` | each country against its three nearest names by composite score: PD, composite, spread, debt, stance |
| `shadow_rating.csv`, `shadow_ratings.csv` | `engine/shadow_ratings.py` on this run (the country-note v2 input), only when the folder has none for this run |

Each country record holds: stance, risk level, trend, a one-sentence rationale, the reasons and warnings behind
it, regime, PD, market PD and how it compares with the model, DSA fan summary, shadow rating, GPR, the latest
nowcast per target, peers, and the active ideas with their alignment.

## Inputs

All from the run folder, all cut at the run's as-of date. An absent input is recorded as `absent`, and its fields
are null.

- `run_latest.json`: country rows, dashboard GPR fields, playbook activations, stamps.
- `dsa_signal.csv`: debt now, median and p90 at the horizon end, P(debt above the DSA threshold).
- `nowcast/*.csv`: engine.nowcast log rows with as_of on or before the run's.
- `gpr_country.csv`: country event GPR rows with the run's as_of; otherwise the run's dashboard GPR.
- `store/archive/*-base.json`: archived runs for shadow-rating momentum, as_of on or before the run's.
- `data/playbook.csv`: the stance of each trade.

## Rules

Fixed in `RULES`. They are research labels, not model parameters.

| Field | Rule |
|---|---|
| **Defensive** | regime Crisis or Stressed, or 1-year PD at least 3%, or PD at least 1% with P(debt above DSA threshold) at least 50% |
| **Constructive** | regime Calm, PD below 1%, and no warning |
| **Neutral** | everything else |
| Warnings | P(debt above DSA threshold) at least 25%; shadow rating `downgrade_risk` or `momentum_down`; DSA median debt path up 5pp of GDP or more; GPR at least 40 points hotter than the composite; a negative real-growth nowcast |
| Risk level | In default (agency SD/D); High (Crisis or PD at least 10%); Elevated (Stressed or PD at least 3%); Moderate (PD at least 1%); Low |
| Trend | DSA median path up or down 5pp, shadow momentum, negative growth nowcast: deteriorating, improving or stable |
| Market vs model | market PD / model PD at least 1.5: market wider; at most 1/1.5: market tighter; else in line |

Idea alignment, from the playbook stance of each active idea:

| House stance | Risk-off idea | Risk-on idea | Hedge, Event, Relative value |
|---|---|---|---|
| Defensive | aligned | **counter-view** | neutral |
| Constructive | **counter-view** | aligned | neutral |
| Neutral | **two-way** if the name also has a Risk-on idea, else neutral | **two-way** if it also has a Risk-off idea, else neutral | neutral |

A counter-view or two-way idea may still be shown. It must be labelled as such, next to the house stance.

## What check flags

- The house view is missing, carries another run's stamps, does not cover the run's countries, or is stale (a
  rebuild from the same inputs differs).
- Country notes: regime or PD differs from the house view; a `house_stance` differs.
- Weekly brief: a pd_movers row's regime or PD differs; a `house_view` section row's stance differs.
- Trade ideas: a counter-view or two-way idea without `house_stance` and `alignment` equal to the house view's; any
  `house_stance` that differs.

- Capped PDs:
  - A PD at the engine cap (`engine.common.PD_CAP_12M`, 0.99, the cap in engine/pipeline.py) must never be shown bare.
  - `pd_capped` in house_view.json and in peers.csv (`pd_capped`, `peer_pd_capped`) must match the cap test.
  - The rationale, reasons and warnings must write a capped PD as "99.00% (engine cap)".
  - Each note's house-view block and peer table must carry "(engine cap)" after a percent at the cap.
  - A test keeps the constant equal to the pipeline's cap.

A product that does not yet carry the house fields is listed under "not wired". That is information, not a problem.
An unlabelled counter-view or two-way idea is always a problem.

## Result on the MVP pack (run 20261025T183022-base, as of 2026-10-23)

Built on a local copy of `outputs/reports/mvp`. The shared pack was not written.

| Stance | Countries |
|---|---|
| Constructive (1) | Vietnam |
| Neutral (8) | Philippines, China, Malaysia, Singapore, Japan, South Korea, India, Colombia |
| Defensive (9) | Pakistan, Belize, Brazil, Argentina, Venezuela, Nigeria, Senegal, Zambia, Zimbabwe |

The check finds 10 unlabelled ideas (exit 1):

- counter-view, Risk-on under Defensive: T17 for Belize, Brazil, Argentina and Nigeria; T19 for Brazil;
- two-way: India T15 and T20; Colombia T06, T17 and T19.

Notes and the weekly brief agree with the house view on regime and PD. None of the three products carries the house
fields yet, so all three are "not wired". The handoffs in the next section ask for them.

## Who does what

- **Team B, AGENT-02 (mvp_pack), HO-20261025-B-B-002:**
  - run `house_view build` after the inputs and before the products;
  - add `house_stance` and `alignment` to trade-ideas.json and the trade-ideas page, which mvp_pack still formats;
  - call `house_view_problems` from `check_pack`.
- **Team C (presentation), HO-20261025-B-C-017:**
  - the country note shows the house view block and the peer table;
  - the notes manifest carries `house_stance`;
  - the weekly brief gets a house-view table and a `house_view` manifest section;
  - a future trade-ideas page generator carries the counter-view label.

## Limits

- The rules are judgement thresholds. They have not been back-tested. Changing them changes labels, not numbers.
- With few archived runs, shadow momentum is mostly code and data revisions (see `engine/shadow_ratings.py`).
- The DSA threshold is a gross-debt threshold. High-debt advanced economies (Japan, Singapore) sit above it in most
  paths, so they get a warning and cannot be Constructive.
- No nowcast or country event GPR file is in the MVP pack today. Those fields are null and were not used.
