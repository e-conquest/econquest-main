# Calendar test rehearsal (EQ-B-0131, 2026-10-26)

**SYNTHETIC data only. Nothing here is a test result.** This page records a rehearsal of the 2027 formal tests. The
tests are the 250-day VaR backtest from 2027-07-14, plus the 12-month PD benchmark and trade-idea scoring from
2027-10-23. The rehearsal runs on a simulated record, simulated snapshots and outcomes, and a simulated idea log, all
in a temporary home. It uses the real entry points with no code changed:

- Team B's `validation.calendar_tests.formal_verdicts`.
- Team C's `ops.calendar_jobs.run`, with the real evidence monitor and the real formal source; nothing is injected.
- The scheduled job itself: `ops.schedule.DEFAULT_JOBS["calendar_tests"]` resolved by `schedule.resolve_steps` and
  run by `ops.jobs.run_job`, as a subprocess, with `{as_of}` filled in New York time.

Every statistic is checked against a hand calculation written out in the test file, not against the module's own
helpers. The shared `data/forecast_record.csv`, `data/benchmarks.csv`, `outputs/idea_log.csv`,
`outputs/calendar_tests.json`, `outputs/alerts.json` and the incident log are hashed before and after the run, and the
hashes match. The base is untouched: no model code, data or parameter changed.

Code: `econquest/validation/calendar_rehearsal.py`, which holds the simulated world, the hand calculations and the
demo entry point described below. Tests: `tests/test_calendar_rehearsal.py` (15 tests, about 15 s). Run them with
`python -m pytest -q tests/test_calendar_rehearsal.py`. Rerun the whole rehearsal with
`python -m econquest.validation.calendar_rehearsal --out <dir>` (about 8 s).

## The simulated world

| Input | How it is built | Why |
|---|---|---|
| Forecast record | Weekdays from 2026-07-30, as the real record runs. VaR is 1.00 to 1.25 in a 10-day cycle. ES = VaR x 1.32319, the Student-t (5) ES/VaR ratio at 99%, so the ES tests read nu = 5 back. Losses are 0.35 VaR x sin(0.7 t), never an exception, except on the chosen days, where L = ES + e sigma (sigma is the t5 scale implied by that day's VaR). | The 250th weekday from 2026-07-30 is the gate, 2027-07-14 |
| Record timing | Row D is written at 22:25Z on the next weekday. The real record's first daily row (2026-10-21) was written on 2026-10-23 at 22:25Z. The home holds only the rows written before 08:30 New York on the run date, which is when the job runs. | Point in time as the job sees it |
| Pass world | 3 exceptions, on days 40, 130 and 210, with residuals e of -0.4, 0.1 and 0.2. A fourth, on day 290 (2027-09-09), enters the October windows. | A record that should pass |
| Fail world | 8 exceptions: a run of three (days 20 to 22) and five singles, with e from 0.8 to 1.6. | VaR and ES both too low |
| Benchmark snapshots | 18 sovereigns on 2026-10-23, the same count and date as the real first snapshot. S18 is already in default. A second snapshot on 2027-01-22 is still pending at the gate. Model PD 0.01 to 0.17; rating-implied 0.02 to 0.10. | Defaults start inside the 12 months for S03 (2027-09-30) and S16 (2027-02-15) |
| Idea log | First cohort as in the real log: logged 2026-10-23 and entered 2026-10-21/22 (4 FX, 2 Equity, 1 unmarkable CDS). Then 22 ideas entered monthly from 2026-11-16: 20 close (12 winners) and 2 stay open, plus 1 unmarkable CDS. Notional is 10 (FX) or 5 (Equity) $mm. The latest mark is the previous weekday's close. | Hit rate 12/20 by construction |

## VaR backtest: hand values against the module

Both worlds are run at 08:30 on 2027-07-16, on the window 2026-07-30 to 2027-07-14 (250 days).

| Statistic | Hand formula | Pass world: hand | Pass world: module | Fail world: hand | Fail world: module |
|---|---|---|---|---|---|
| Exceptions x | count of L > VaR | 3 | 3 | 8 | 8 |
| Kupiec LR_uc | -2 ln[(1-p)^(n-x) p^x] + 2 ln[(1-x/n)^(n-x) (x/n)^x] | 0.094940 | 0.094940 | 7.733551 | 7.733551 |
| Kupiec p | chi2(1) | 0.7580 | 0.7580 | 0.0054 | 0.0054 |
| Transitions n00/n01/n10/n11 | counted from the exception days | 243/3/3/0 | 243/3/3/0 | 235/6/6/2 | 235/6/6/2 |
| Christoffersen LR_ind | -2 [ln L(pi) - ln L(pi01, pi11)] | 0.073173 | 0.073173 | 5.585177 | 5.585177 |
| Christoffersen cc p | chi2(2) on LR_uc + LR_ind | 0.9194 | 0.9194 | 0.0013 | 0.0013 |
| Basel zone, plus factor | 250-day table | Green, 0.00 | Green, 0.00 | Yellow, 0.75 | Yellow, 0.75 |
| Acerbi-Szekely Z2 | 1 - sum(L/ES on exceptions) / (T (1 - alpha)) | -0.188402 | -0.188402 | -3.278625 | -3.278625 |
| Z2 p | independent Monte Carlo, 20,000 t5 records (module: 2,000, seed 91) | 0.342 | 0.347 | 0.0001 | 0.0005 |
| McNeil-Frey mean residual, t | mean e; mean / (sd / sqrt k) | -0.0333, -0.1796 | -0.0333, -0.1796 | 1.1625, 12.318 | 1.1625, 12.318 |
| McNeil-Frey p | independent centred bootstrap, 20,000 draws (module: 5,000, seed 91) | 0.664 | 0.661 | 0.0000 | 0.0000 |
| Verdict | all four p >= 0.05 | Pass | Pass | Fail | Fail |

The closed-form statistics agree to 1e-10. The simulated p-values agree within Monte Carlo error (tolerance 0.03 in
the tests). Through `formal_verdicts` (reading the CSV), the pass world gives `pass` with the detail "3 exceptions in
250 days; Kupiec p 0.758; Christoffersen cc p 0.919; Basel Green; Z2 -0.188 (p 0.346); McNeil-Frey p 0.667". The fail
world gives `fail`, with Basel Yellow.

## 12-month benchmark and idea scoring: hand values against the module

Run on 2027-10-26 in the temp home.

| Statistic | Hand | Module |
|---|---|---|
| Matured, eligible rows | 17 (18 minus S18, in a default spell; the 2027-01-22 snapshot is pending) | 17 |
| Model Brier | mean (p - y)^2 = 0.105794 | 0.105794 |
| Rating-implied Brier | 0.107141 | 0.107141 |
| Model Brier skill | 1 - Brier / (ybar (1 - ybar)) = -0.0192 | -0.0192 |
| Model log score | -mean[y ln p + (1-y) ln(1-p)] = 0.397783 | 0.397783 |
| Model AUC | Mann-Whitney, ties half = 0.5333 | 0.5333 |
| Rating minus model Brier | 0.001347 | 0.001347 |
| DM p | not tested: 17 paired rows < 30 | NaN |
| Ideas in the 12-month window | the 22 ideas entered after 2026-10-26; the first cohort is out | 22 marked, 1 unmarked |
| Hit rate, closed ideas | 12 / 20 = 0.60 | 0.60 (n 20) |
| Binomial p vs 0.5 | P(X >= 12 \| 20, 0.5) = 0.2517 | 0.2517 |
| P&L gross, cost, net ($mm) | 1.125, 0.275 (FX 20 bp, Equity 10 bp of notional), 0.850 | 1.125, 0.275, 0.850 |

`formal_verdicts` gives `review` for both:

- Benchmark: "model Brier 0.1058, rating-implied 0.1071 (DM p nan); model Brier not worse than rating-implied; no
  pass/fail rule set".
- Ideas: "hit rate 0.60 (binomial p vs 0.5 0.252); P&L net of assumed cost 0.85 $mm; no pass/fail rule set".

## The daily job around the two formal dates

`ops.calendar_jobs.run` ran in one temp home, with the files rewritten for each run date as they would stand at 08:30
New York. The state file carries over from one run to the next. Rerun on 2026-10-26 with Team C's grace window
(EQ-C-0147, HO-20261026-C-B-001), which addresses RF-3: on a formal date and the next 3 weekdays, a test whose data
is not yet complete is "due" with `grace` true, a warning row but never a new alert.

| Run date | VaR | Benchmark | Ideas | Exit | New alerts | Why |
|---|---|---|---|---|---|---|
| 2027-07-13 | not due | not due | not due | 0 | none | before the date |
| 2027-07-14 (gate) | due (grace to 07-19) | not due | not due | 0 | none | 248 rows written by 08:30 (RF-3, addressed by the grace window) |
| 2027-07-15 | due (grace) | not due | not due | 0 | none | 249 rows; still in grace |
| 2027-07-16 | passed | not due | not due | 0 | none | 250 rows; `formal_verdicts` ran |
| 2027-10-22 | passed | not due | not due | 0 | none | trailing window 2026-11-05 to 2027-10-20, 3 exceptions |
| 2027-10-23 (Sat, gate) | passed | review | due (grace to 10-28) | 2 | benchmark | no idea mark yet reaches 12 months from the first log date (RF-3); the benchmark alert is its move to review |
| 2027-10-25 (Mon) | passed | review | due (grace) | 0 | none | the latest mark is still Friday 22 Oct; still in grace |
| 2027-10-26 | passed | review | review | 2 | ideas | Monday's mark reaches 12 months |

The other job checks:

- The fail world on 2027-07-16 and 2027-07-19 gives `failed` and exit 2 both days. It opens one S2 incident (actor
  "calendar_tests job") and does not open a duplicate on the second day.
- The `calendar_` rows in `outputs/alerts.json` are replaced on each run.
- With same-day recording (no lag), the gate-day run still sees only 249 rows. It reports due in grace ("data not yet
  complete", grace to 2027-07-19) on 2027-07-14 and passed on 2027-07-15.
- The scheduled job, run by `jobs.run_job` with the clock fixed at 08:30 New York on 2027-07-16, exits 0. It writes
  `outputs/calendar_tests.json` (formal path `formal_verdicts`, statuses passed / not due / not due) and records the
  run in `outputs/jobs`. The fail world exits 2.

The job stamps `generated_at` and the incident times with the clock. Those are operations times, not model numbers.
The statistics read only `as_of`.

## Findings

**RF-1: McNeil-Frey is degenerate at two exceptions (Team B, `calendar_tests.mcneil_frey`).**
- With k = 2, every centred bootstrap draw has t = 0: equal draws have zero spread and unequal draws have zero mean.
  So p is 0 whenever the mean residual is above 0, and 1 otherwise.
- The verdict then turns on the sign of a two-point mean. Two exceptions is the most likely count in 250 days at 99%
  (probability 0.26).
- In the rehearsal, the July pass world seen in October (k = 2, Kupiec p 0.74, Z2 p 0.56) fails on McNeil-Frey
  alone. The test `test_finding_mcneil_frey_bootstrap_is_degenerate_at_two_exceptions` pins this.
- At k = 3 the bootstrap has 10 distinct resamples. The p moves in the third decimal between the in-memory frame and
  the CSV round trip (0.661 against 0.667).

**RF-2: a correct forecast fails the formal VaR verdict about one time in four or five.** 2,000 records were
simulated with the forecast exactly right (t5 losses scaled to each day's VaR). The current rule (Kupiec,
Christoffersen cc, Z2 and McNeil-Frey all at p >= 0.05) failed 24.7% of them in one run and 21.5% in a second run with
another seed (Monte Carlo SE about 1%), against a 5% intent. The failures come
from three sources:

- k = 0: two-sided Kupiec rejects zero exceptions (8% of records). The Basel zone is Green.
- k = 2: the McNeil-Frey effect of RF-1, failing 42% of those records.
- Four tests combined at 5% each.

Size and power of the current rule and some variants. Each column is the share of simulated 250-day records
that get a Fail (scratch simulation, synthetic, verdict recomputed from the module's own p-values; the current-rule
column matches the module's verdict on every record):

| Rule | Correct forecast (2,000 records): false Fail | Vol 25% above forecast (1,000): Fail | VaR right, tail t3 (ES too low) (1,000): Fail |
|---|---|---|---|
| Current: all four tests at 5% | 21.5% | 48.1% | 31.5% |
| McNeil-Frey only from 5 exceptions | 12.0% | 45.3% | 17.4% |
| Same, and Kupiec rejects only too many exceptions | **3.3%** | **44.8%** | **10.2%** |
| Same, each test at 5%/4 (Bonferroni) | 1.0% | 24.5% | 3.8% |
| Basel Red zone only (10+ exceptions) | 0.1% | 3.3% | 0.0% |

The third row keeps almost all the power against a VaR that is too low and brings the false-Fail rate under 5%. It
loses power against a heavier tail with the right VaR, which 250 days can barely detect anyway.

**RF-3: the job raised "overdue" on both formal dates before the data can exist (Team C, `ops/calendar_jobs.py`).
Addressed 2026-10-26 by the grace window (EQ-C-0147, lead decision); the table above is the rerun. As found:**
- VaR: 2027-07-14 is the date of the 250th row, but that row is written that evening or later. So the 08:30 run on
  the gate date always sees 249 rows or fewer. It raises an "overdue" alert (exit 2) and then passes quietly one or
  two days later. Passed is not an alerting status, so no message follows the alert.
- Ideas: 2027-10-23 is a Saturday, and the 12-month mark falls on a weekend. The job reports ideas overdue from 23 to
  25 October, then review from the 26th.
- Suggested change for Team C, not made here: treat the evidence monitor's "overdue" as "due" for a grace of a few
  weekdays after the formal date (the recording lag), or move each formal date to the first weekday after the data
  completes.

**RF-4: the rolling 12-month idea window never scores the first cohort (Team B, `_idea_rows`).**
- Ideas count when they were opened in the 12 months to as_of, strictly after as_of minus 12 months.
- The real first cohort was entered 2026-10-21/22. On and after 2027-10-22 it is outside the window, so the first
  formal idea scoring never includes it.
- Whether the first formal scoring should cover everything since the log began is part of the idea rule (parked
  below).

**RF-5: the first real benchmark result will be underpowered, and the detail says "DM p nan" (Team B, cosmetic).**
- The real first snapshot has 18 rows on one date. That is below 30 paired rows, so the DM comparison is not tested,
  and there are fewer than 10 events.
- The detail should say "DM not tested (17 paired rows < 30)" rather than "nan".

**RF-6: holidays count as record days.** The real record has 60 rows for the 60 weekdays from 2026-07-30 to
2026-10-21, Labor Day included, so the simulated weekday calendar matches. A missed weekday moves the 250th day later.
The job then reports due in the grace window (3 weekdays) and overdue after it until that day, which is the intended
behaviour.

Follow-ups:
- EQ-B-0133 (AGENT-05): RF-1 and RF-5. The RF-1 fix changes the verdict rule, so it waits on card A.
- HO-20261026-B-C-007 (Team C, AGENT-08): RF-3, and the interface for the rehearsal page. RF-3 is addressed by the
  grace window (EQ-C-0147); the rehearsal's expected statuses were updated under HO-20261026-C-B-001.

## Pass/fail rules and who decides them

| Test | Rule today | Status |
|---|---|---|
| 250-day VaR | Pass when Kupiec p, Christoffersen cc p, Z2 p and McNeil-Frey p are all >= 0.05 (EQ-B-0091, Team B). The Basel zone is reported, not used. | A Team B rule with no recorded sign-off. RF-1 and RF-2 show it fails a correct model 22-25% of the time. Choosing the acceptance standard for the formal test is Sam's call, as model owner. Card A below. |
| 12-month PD benchmark | None: always "review". The detail flags a model Brier worse than the rating-implied one (the revalidation trigger). | Sam's call. Parked (card B). |
| Trade-idea scoring | None: always "review" (hit rate, binomial p, P&L net of assumed cost). | Sam's call. Parked (card C); includes RF-4. |

Draft cards in first-mac-pass.md terms. The lead numbers them and adds them to `team/when-sam-is-ready.md`; they are
not posted.

| # | Choice | Recommendation | Tag |
|---|---|---|---|
| A | Formal VaR acceptance rule: keep all four tests at 5% (a correct model fails 22-25% of the time), or use McNeil-Frey only from 5 exceptions and Kupiec rejecting only too many exceptions | The variant: same tests, false-fail rate down to about 3% (power against a VaR 25% too low: 45% against 48%); Basel zone shown alongside | core |
| B | PD benchmark pass/fail: none (Sam reviews the scores), or Fail when the model Brier is worse than the rating-implied one with DM p < 0.05 (needs 30 paired rows in 5 countries, not reachable on the first 18-row snapshot) | Review only for the first cycle; set the rule once 30 paired rows have matured | core |
| C | Idea pass/fail: none (Sam reviews), or Fail when the hit rate's binomial p vs 0.5 is >= 0.05 and P&L net of assumed cost is <= 0, on at least 20 closed ideas; and whether the first scoring covers all ideas since the log began (RF-4) | Review only for the first cycle; score from the log's start on the first formal date | optional |

## Demo entry point and output files (for Team C, C-0147, demo row M16)

`econquest.validation.calendar_rehearsal.demo_calendar_rehearsal(out_dir, scheduled=True)` runs the whole rehearsal in
a temporary home and deletes the home afterwards. It writes four files at fixed paths under
`<out_dir>/calendar_rehearsal/`:

| File | Content |
|---|---|
| `rehearsal.json` | The returned dict as strict JSON (NaN written as null). Keys: `kind` ("REHEARSAL"), `label`, `schema_version` (1), `ok`, `problems`, `paths`, `summary`, `checks`, `job_sequence`, `scheduled`, `findings`, `entry_point_exits`, `shared_untouched` |
| `checks.csv` | One row per hand check: `section, world, run_date, statistic, hand, module, tolerance, ok, note` (49 rows) |
| `job_sequence.csv` | One row per job run: `run_date, world, var, benchmark, ideas, exit, new_alerts, expected_var, expected_benchmark, expected_ideas, expected_exit, expected_new_alerts, ok, why` (10 rows) |
| `rehearsal.md` | A short page labelled SYNTHETIC REHEARSAL |

The function returns `{"ok": bool, "problems": [str], "paths": {...}, "summary": {checks, checks_ok, sequence,
sequence_ok, scheduled, scheduled_ok}, ...}`. A check or job run that differs from its hand value or expected status is
a line in `problems`; the function does not raise on one. It does raise if `out_dir` is under the repo's `data/`.
`scheduled=False` skips the subprocess run of the scheduled job. The schema is in the module as `SCHEMA`,
`CHECK_COLUMNS` and `SEQUENCE_COLUMNS`.

Exit codes of the entry points (`ENTRY_POINT_EXITS` in the module):

| Entry point | Exit codes |
|---|---|
| `python -m econquest.ops.calendar_jobs run` (the job) | 0 nothing new; **2 alert**: a status change into due, overdue, review or failed, or any failed test (health step code `calendar_test_alert`); a grace-window due is not an alert; 1 error |
| `ops.jobs.run_job` for the scheduled `calendar_tests` | The step's code (0, 2 or 1); 75 if the previous run still holds the lock; 127 if the step could not start |
| `python -m econquest.validation.calendar_tests` | 0 result, not due or dry run; 3 gate passed but data short; 1 error |
| `python -m econquest.validation.calendar_rehearsal` | 0 rehearsal ok; 1 problems or error |
| `formal_verdicts` | No exit code: status gated, pass, fail or review per test |

## Not rehearsed

- Live email: it stays a dry run by design.
- The readiness page view: covered by `tests/test_calendar_jobs.py`.
- Real data.
- The interim monthly alert: it ran inside `run` in the temp home, but the rehearsal makes no assertion on it.
