# Model validation: backtest explainer, rolling backtests by country and factor, P&L attribution

Date: 2026-10-26 (EQ-B-0141, PI-14). Code: `econquest/validation/backtest_explainer.py`. Tests:
`tests/test_backtest_explainer.py`. Reads `data/forecast_record.csv` (`record.py`),
`data/market_history/prices.csv` (through `garch.load_prices`, which never reads `archive/`),
`data/portfolio.csv`, `data/countries.csv` and `data/assumptions.json`. Writes only under the output folder
you give it. Tier 3: read-only. It is not called by the pipeline, so no base number moves.

Every number here is **INTERIM** while the record has fewer than 250 clean tested days (formal VaR test from
2027-07-14, [calendar-gated-tests.md](calendar-gated-tests.md)). None of it is a formal test result.

## Run

```
python -m econquest.validation.backtest_explainer --as-of 2026-10-26 --out outputs/backtest_explainer [--step 21]
```

```python
from econquest.validation.backtest_explainer import demo_backtest_explainer
r = demo_backtest_explainer("outputs/backtest_explainer", "2026-10-26")   # {"ok", "problems", "paths", "summary", "gaps", "checks", "pnl_summary"}
```

`as_of` is required. The clock is never read and nothing is fetched. Only record rows dated **and** recorded on
or before as_of count (`forecast_scorecard.record_as_of`), and only prices dated on or before as_of are used.
`out_dir` must be under the repo's `outputs/` or outside the repo. The demo writes
`<out_dir>/backtest_explainer/` with `exceptions.csv`, `rolling.csv`, `pnl_attribution.csv`,
`backtest_explainer.json` (schema `eq-backtest-explainer/1`) and `backtest_explainer.md`. A run takes about
one minute: four GARCH-DCC fits at about 20 s each with `--step 21`.

Plain row functions for Team C: `exception_rows(record, u, settings, prices, as_of)` returns `(rows, checks)`,
`rolling_rows(...)` returns rows, `pnl_attribution_rows(record, u, prices, as_of)` returns `(rows, summary)`,
and `run_explainer(...)` returns all three on shared fits. The columns are `EXCEPTION_COLUMNS`,
`ROLLING_COLUMNS` and `PNL_COLUMNS`.

## What is recorded and what is not

A record row stores the book totals only: `loss`, `var`, `es`, `var_next`, `es_next`, the 12-month MC
VaR/ES (on daily rows only), `marked_positions`, `marked_notional_mm`, `marks`, `code_hash`, `data_hash` and
`recorded_at`. **It does not store the day's per-position marks or the GARCH-DCC state** (fits, filtered
variances, DCC correlation). So no day's run inputs are recorded. The explainer says so on every row
(`inputs_status` starts `not_recorded_`). It then **reconstructs** the day from today's engine-readable
inputs:

- the realised loss per position, from `prices.csv` with the record's own marking rules (`record.realised_loss`:
  stale up to 5 weekdays, then excluded, catch-up on the first price again). The position losses add up to
  `realised_loss` bit for bit (checked);
- the forecast made on the previous trading day: GARCH-DCC fitted on prices up to a fit date and filtered
  forward to that day (`record._portfolio_var`, reproduced to 0.0 difference, checked). With `step` = 21
  (the default) the model is refitted every 21 record days, which is `backfill_record`'s scheme. With
  `step` = 1 it is refitted every day.

`inputs_status` takes one of three values:

| inputs_status | Meaning |
|---|---|
| `not_recorded_reconstructed_reconciled` | The reconstruction reproduces the recorded loss and VaR within 1e-6 $mm. The rows explain the recorded exception. |
| `not_recorded_reconstruction_unreconciled` | The reconstruction does not reproduce the record. The rows describe the day on today's inputs, not the recorded exception. A `residual` row (recorded minus reconstructed) carries the difference, so the rows still add up to the recorded numbers. |
| `not_recorded_no_prices` | `prices.csv` has no row for the day. Nothing is attributed. |

## Method

**Exceptions.** These are the clean tested days (`calendar_tests.clean_days`: finite loss, VaR > 0, ES >= VaR,
point in time) where recorded loss > recorded VaR99. This is the same set the INTERIM report counts.

**Realised side.** `loss_D = sum_i w_i log(P_D / P_prev)`, where `w_i = notional x direction sign x loss
sign` (`record.book_weights`). The sum runs over positions, so country, asset-class and factor losses are
exact sums.

**Forecast side: Euler allocation, the same principle as `portfolio_risk`.** The one-day VaR is
`V = sqrt(V_FX^2 + V_EQ^2)` with `V_k = q_k sqrt(w_k' Sigma_k w_k)`. Here `Sigma_k = s s' o R_next` is built
from the filtered one-day vols and the DCC correlation, and `q_k` is the unit-variance Student-t quantile at
the block's median nu. `V` is homogeneous of degree one in the weights, so the Euler components add up to it
exactly:

    marginal m_t = dV/dw_t = (V_k / V) q_k (Sigma_k w)_t / sqrt(w' Sigma_k w)
    component of position i on ticker t = w_i m_t

ES works the same way with the ES quantile. `portfolio_risk.euler_components` estimates the same allocation
(E[L_i | L = VaR]) from Monte Carlo paths. For an elliptical block the closed form equals it. The test
`test_euler_components_agree_with_portfolio_risk_monte_carlo` simulates 400,000 multivariate-t paths and
checks the two agree within Monte Carlo error. The checks in every run are: components sum to the VaR and ES
(< 1e-9 $mm), country and factor sums equal the VaR, the totals equal `_portfolio_var`, and the position
losses equal `realised_loss`. A failure is a problem (`ok` False).

**Levels.** The levels are `book`, `residual`, `position`, `country`, `asset_class`, `factor` (a
`prices.csv` ticker, which is the risk factor the record marks) and `factor_type` (FX, Equity). For each
item the rows give its realised loss, its component VaR99 and ES99, its *excess* (realised loss minus
component VaR) and its rank by excess. The item with the largest positive excess drove the breach beyond its
forecast share. Exposure is the net loss weight in $mm, except on the book row, where it is gross.

The 12-month Monte Carlo attribution (`portfolio_risk.attribution`) is the wrong horizon for a one-day
exception, so it is not used. Only one record row (2026-10-21, not an exception) has a 12-month run, and its
inputs are not stored either.

**Rolling backtests.** Windows trail up to 20 and up to 250 clean days back from each tested day. The
250-day window grows with the record until the record is 250 days long. Rows: book `recorded` (the record's
own loss and VaR), book `reconstructed`, each country, and each factor. Country and factor forecasts are the
reconstructed **standalone** VaR99 of that sub-book on the same blocks. Euler components are not VaRs and
are not backtested. Statistics: exceptions, expected count, rate, Kupiec POF (`backtests.kupiec`) LR and p,
the two-sided 95% binomial band, and the largest loss / VaR. Label: INTERIM below 250 clean days; after that,
"DIAGNOSTIC, not the formal test".

**P&L attribution.** For each record day: explained = sum over factors of exposure x realised log move on
today's `prices.csv`, and unexplained = recorded loss - explained. Factor rows add up to the explained loss
exactly. The summary gives the share of variance explained `1 - var(unexplained) / var(recorded)`, the
correlation, the largest unexplained day and the number of days reconciled.

## Guards

- **Real record only in real runs.** The demo reads `<repo>/data/forecast_record.csv`. Any other `data_dir`
  is refused unless running under pytest or inside a calendar rehearsal temp home (`eq-calendar-rehearsal-*`).
  A record carrying the `SYNTHETIC` marker (in `code_hash`, `marks` or `recorded_at`, or
  `record.attrs["synthetic"]`) is refused outside pytest and that sandbox (`SyntheticRefused`).
- Validation never imports presentation (checked by a test).
- The restricted GOOGLEFINANCE archive (`data/market_history/archive/`) is never read.

## Result on the real record, as of 2026-10-26

There are 60 clean tested days (2026-07-30 to 2026-10-21) and 1 VaR99 exception, on **2026-09-23**:
recorded loss 1.5606 $mm against VaR99 1.5369 $mm (1.015 x VaR; ES 2.0502).

**The day's inputs are not recorded, and the reconstruction does not reconcile.** On today's `prices.csv`,
the 2026-09-23 loss is 0.2362 $mm and the VaR99 for it (made 2026-09-22, fit 2026-08-27) is 0.8802 $mm. The
gaps are +1.3244 $mm on loss and +0.6567 $mm on VaR. On today's inputs the day is **not** an exception
(0.27 x VaR). The cause is the price source. The record was backfilled on 2026-10-23 from the
GOOGLEFINANCE-era `prices.csv`: 17 FX columns plus 12 country ETFs, 13 positions marked, 210 $mm. Since
EQ-A-0054 (Sam, 2026-10-24) `prices.csv` is official FX only. The ETFs were dropped, so P07 South Korea
equity (EWY, 15 $mm, marked in the record) can no longer be marked, and the FX closes differ. P22 Zimbabwe
equity has no ETF and was never marked. Only 12 positions (195 $mm) are marked today. The GOOGLEFINANCE copy that could reproduce the row is restricted (audit only, never a model
input), so it is not used.

What the reconstruction shows for 2026-09-23 (the FX book on official closes), ranked by excess:

| Country (factor) | Realised loss | Component VaR99 | Excess |
|---|---|---|---|
| Nigeria (USDNGN, short) | 0.0076 | 0.0023 | +0.0053 |
| China (USDCNY) | 0.0218 | 0.0214 | +0.0004 |
| India (USDINR, net long 10) | 0.0153 | 0.0187 | -0.0035 |
| Singapore (USDSGD) | 0.0992 | 0.1113 | -0.0121 |
| Brazil (USDBRL) | 0.0624 | 0.4661 | -0.4036 |

Eight of the nine FX countries lost on the day; Japan (short JPY) gained 0.094. None lost much more than its
forecast share, and Brazil, the largest
VaR component (53%), lost far less than its share. **The recorded breach (1.32 $mm more than today's FX
marks) therefore came from what today's inputs cannot see: the South Korea equity leg (EWY) and/or the
GOOGLEFINANCE FX closes.** The split between the two cannot be made without the day's marks.

Rolling, reconstructed (INTERIM, 60 days): the recorded book has 1 exception (Kupiec p 0.64, inside the band
0 to 2). The reconstructed book has 0. Japan / USDJPY (short JPY 20) has 3 exceptions (2026-07-31,
2026-08-03, 2026-09-03; Kupiec p 0.026, above the band), Colombia / USDCOP 1 and India / USDINR 1. On 60
days this is an early signal on the JPY leg, not a test result.

P&L attribution: 0 of 60 record days are reproduced by today's prices. Today's FX moves explain about 5% of
the variance of the recorded losses (correlation 0.30). The largest unexplained loss is 2.06 $mm, on
2026-07-30. This is in line with the finding above: **the 60-day record and today's engine inputs disagree,
so the interim record no longer describes the current inputs.**

## Limitations and open items

1. **Per-day inputs are not recorded.** The record needs per-position marks (ticker, prices T-1 and T, mark
   status) and the forecast state (per-ticker one-day sigma, nu, the DCC correlation used, fit date) for
   every row. Then an exception can be explained from recorded inputs, not reconstructed. This is a change
   to `record.py` (Team B) and the record contract (C8, with Team C). It is proposed, not made: the record
   format is shared.
2. **The record's price source is retired.** All 60 rows were marked on GOOGLEFINANCE-era prices. Whether
   the interim record stays valid evidence, or restarts on official FX once the Mac `market_history apply`
   has run (which would move the 2027-07-14 gate), is Sam's call (governance, Tier 1 implications for the
   record clock).
3. The equity leg P07 (EWY) cannot be marked on official prices (no free official ETF source), and P22 has no
   ETF at all. The equity block of the one-day VaR is empty today.
4. The reconstruction uses today's `portfolio.csv`. The backfill also assumed the book unchanged since July.
5. There are no `prices.csv` vintages. Prices are filtered by date, but a later revision of an old price is
   not point in time.
6. With 60 days, nothing here has power. Country and factor windows repeat the book's sample. Exceptions on
   correlated factors are not independent tests.
