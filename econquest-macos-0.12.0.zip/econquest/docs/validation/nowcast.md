# Macro nowcasting: quarterly GDP and CPI from monthly indicators

Date: 2026-10-24. Ticket EQ-B-0071. Code: `econquest/engine/nowcast.py`. Tests: `tests/test_nowcast.py`.

Status: research module, off by default. It feeds no PD, no scorecard cell and no Monte Carlo number;
`pipeline.py` does not import it. All results below are on SYNTHETIC data. No real input file exists yet:
Team A has no monthly CPI, industrial production or trade feed today (their feeds are WEO and World Bank
annual, BIS quarterly and monthly REER, ECB and Yahoo FX).

## What it does

For each country and each target (real GDP growth, CPI inflation), at a given as-of date:

1. **Point in time.** `pit_view(inputs, as_of)` keeps only rows with `release_date <= as_of`, and for each
   (country, series, period) the latest of those releases. No function reads the wall clock.
2. **Target quarters.** Every quarter after the last released target quarter, up to the quarter that contains
   as_of (at most three). The current quarter is labelled `nowcast`; earlier unreleased quarters are
   `backcast1`, `backcast2`.
3. **Ragged edge.** Each monthly indicator is extended to the last month of the last target quarter by an
   AR(p) forecast, p <= 3 chosen by BIC (`econometrics.ar_fit_bic`), fitted on its own point-in-time history.
   Interior gaps are interpolated. An indicator is dropped if it has fewer than 36 months or its last
   observation is more than 6 months before the first target quarter.
4. **Quarterly aggregation.** Monthly values are averaged within the quarter.
5. **Bridge.** OLS of the quarterly target on a constant, its own first lag and either
   - `bridge`: the quarterly means of the indicators (if fewer than 4 x parameters quarters are available,
     the average of one-indicator bridges is used instead and recorded as `bridge_pooled`), or
   - `pca`: the first k principal components (default k = 1) of the standardised monthly panel, averaged to
     quarters (a static factor; recorded as `pca1`).
   At least 12 training quarters are required. A second target quarter uses the first one's nowcast as its lag.
6. **Benchmark.** A naive AR(p), p <= 2 by BIC, on the target's own point-in-time quarterly history.

Which indicators each target uses is set by the series block: GDP uses the activity, external and financial
blocks; CPI uses the prices block. The CPI target is the quarterly mean of monthly `CPI_YOY`.

## Error tracking against first releases

- `run_nowcasts` returns one row per country, target and quarter with `as_of`, the nowcast, the AR benchmark,
  the indicators used, the average number of months observed in the quarter (real releases only; interpolated
  or AR-filled months do not count), the training length and a hash of the point-in-time inputs.
- `append_log` writes them to `outputs/nowcast/nowcast_log.csv`. A row with the same
  (as_of, iso3, target, quarter, method) is never overwritten: the log records what was said on the day.
  Every write goes through `write_log`, which prefixes text cells starting with = + - @ with an apostrophe
  (`validation.idea_log._csv_safe`), so a spreadsheet never runs them as formulas.
- `score_log(log, inputs, as_of)` fills `first_release`, `first_release_date`, `error = nowcast - first
  release`, `ar_error` and `scored_on` once the first release is dated on or before the scoring as_of. It never
  scores against a revision. A first release dated on or before the nowcast's own as_of is not used, and the
  row's `score_note` says why.
- First release of GDP is the earliest row for the quarter. First release of CPI is the mean of the three
  months' earliest rows, dated at the last of the three.
- `error_summary(log, by=...)` gives n, RMSE, AR RMSE, relative RMSE, MAE, bias and a Diebold-Mariano test on
  squared errors (needs 30 or more scored rows).

Command line (no cli.py change):

```
python -m econquest.engine.nowcast names    [--data data] [--n 25]
python -m econquest.engine.nowcast validate --inputs data/live/nowcast_inputs.csv
python -m econquest.engine.nowcast run      --inputs data/live/nowcast_inputs.csv --as-of 2026-10-23 [--method bridge|pca] [--names top]
python -m econquest.engine.nowcast score    --inputs data/live/nowcast_inputs.csv --as-of 2026-11-30
python -m econquest.engine.nowcast summary
```

## Coverage: the top-25 names

`top_names(data_dir, n=25, as_of)` applies this rule:

1. Every country in `data/portfolio.csv`, ranked by gross notional (sum of |notional_mm| over its positions),
   ties broken by name. Today that is 18 countries, Brazil and Singapore first (35mm each), Zimbabwe last (3mm).
2. The remaining places are filled from `data/panel/universe_proposal.csv` rows with `tier = EM` and
   `embi_member = Y` that are not in the book, ranked by WEO nominal GDP in USD (`NGDPD`, latest year before the
   as-of year) where available, otherwise in proposal file order.
3. The WEO file is the pull as of the run date: `data/live/vintages/<date>/raw_weo.csv` for the latest date on or
   before as_of. With no such vintage, no WEO ranking is used (proposal order). Only a call without as_of uses
   the current pull `data/live/raw_weo.csv`. The `basis` column names the WEO file used.

Today WEO is pulled only for the 18 desk countries, so the 7 fill names come out in file order: Indonesia,
Mexico, Chile, Peru, Uruguay, Panama, Dominican Republic. Once Team A's universe staging pulls WEO for the
proposal countries on Sam's Mac, pass that `raw_weo.csv` and the fill ranks by GDP (it would then likely pick
Mexico, Indonesia, Turkey, Saudi Arabia, Poland and others). The proposal itself is still a draft for Sam.

## Input contract

One long CSV, default path `data/live/nowcast_inputs.csv` (Team A writes it; never hand-edited). One row per
country, series, period and release (vintage). `validate_inputs` enforces it; `read_inputs` refuses a file that
fails.

| Column | Required | Format | Meaning |
|---|---|---|---|
| iso3 | yes | ISO 3166 alpha-3 | Country |
| series | yes | code from the table below | What is measured |
| freq | yes | `M` or `Q` | Must match the code's frequency |
| period | yes | `YYYY-MM` (M) or `YYYY-Qn` (Q) | Reference period |
| value | yes | number | In the code's unit (already transformed; see below) |
| release_date | yes | `YYYY-MM-DD` | Date this value became public. Must be after the end of `period` |
| source | yes | text | Publisher and dataset, e.g. `IBGE SIDRA 5932` |
| release_date_basis | no | `official`, `fetched`, `estimated_lag` | How release_date was set |
| unit, notes | no | text | Free text |

Rules:

- **Vintages.** When a value is revised, add a new row with the new `release_date`; never overwrite the old
  row. The earliest row per (iso3, series, period) is the first release; the latest row on or before as_of is
  what the model sees.
- **release_date.** Use the official release date when the publisher gives a calendar or a release timestamp
  (`official`). Otherwise use the date of the fetch that first saw the value (`fetched`). For history pulled
  from a source that holds only the latest vintage, set period end plus the publisher's usual lag and mark it
  `estimated_lag`: the model then runs pseudo-real-time on revised data, and first-release scoring of that
  history is not meaningful. Real first-release scoring starts with the first live fetch.
- **Transforms.** Send year-on-year % changes for the `_YOY` codes (computed by Team A from the index levels
  of the same vintage), levels for `PMI_MFG` and `UNEMP`. Not seasonally adjusted is fine for y/y rates.
- **History.** At least 36 months for each monthly series and 13 quarters of GDP; 10 years or more preferred.
- `iso3` must be three capital letters; `series` must match `^[A-Z][A-Z0-9_]{0,31}$` and be a known code.
- No duplicate (iso3, series, period, release_date) with different values. No row released on or before the
  end of its own period.

Series codes (`nowcast.SERIES`):

| Code | Freq | Block | Unit | Definition |
|---|---|---|---|---|
| GDP_YOY | Q | target | % y/y | Real GDP |
| CPI_YOY | M | prices | % y/y | Headline CPI (also defines the CPI target) |
| CORE_CPI_YOY | M | prices | % y/y | Core CPI, national definition |
| PPI_YOY | M | prices | % y/y | Producer or wholesale prices |
| IP_YOY | M | activity | % y/y | Industrial (or manufacturing) production volume |
| RETAIL_YOY | M | activity | % y/y | Retail sales volume |
| PMI_MFG | M | activity | index | Manufacturing PMI (licensed; only if the licence allows) |
| UNEMP | M | activity | % | Unemployment rate |
| EXP_YOY | M | external | % y/y | Merchandise exports, USD |
| IMP_YOY | M | external | % y/y | Merchandise imports, USD |
| CREDIT_YOY | M | financial | % y/y | Bank credit to the private sector |

An example file is `tests/fixtures/nowcast_input_example.csv` (SYNTHETIC, country code AAA).

## Results on synthetic data

Data-generating process (`tests/test_nowcast.py::synthetic_inputs`): a monthly AR(1) factor (0.85) drives
IP, exports and retail sales with noise; GDP y/y = 3 + 1.2 x quarterly mean of the factor + noise; CPI y/y is
4 plus an AR(1) (0.92). Release lags: CPI 12 days, PPI 15, exports 20, IP 40, retail 45, GDP 50. First
releases of GDP, IP and CPI carry noise and are revised later. Two countries, as-of dates on the 15th of each
month from January 2019 to December 2025, scored against first releases as of 2026-10-01.

| Target | Horizon | n | RMSE bridge | RMSE AR | Relative | RMSE pca1 | Relative |
|---|---|---|---|---|---|---|---|
| GDP | backcast1 | 110 | 0.54 | 1.64 | 0.33 | 0.55 | 0.34 |
| GDP | nowcast | 166 | 1.45 | 1.90 | 0.77 | 1.46 | 0.77 |
| CPI | nowcast | 166 | 0.39 | 0.58 | 0.67 | 0.36 | 0.63 |

Diebold-Mariano p < 0.01 in every row. The GDP nowcast gain is smaller because early in a quarter few or no
months are observed and the AR fill carries the forecast. These numbers show the code does what it should when
the model is right; they say nothing about accuracy on real data.

Tests also check: no look-ahead (rewriting every row released after as_of, or adding a vintage one day after
it, leaves the nowcast bit-identical; changing a row released before as_of changes it); scoring uses the first
release, not the revision, and waits for the release date; the log is append-only; short histories are skipped
with a reason; the top-25 rule; the module never reads the clock and the pipeline does not import it.

## Limitations

- No real data yet. The input file depends on a new Team A feed (handoff to be raised by AGENT-08).
- Bridge equations with y/y rates; no seasonal adjustment, no mixed-frequency state-space model (a proper
  dynamic factor model with the Kalman filter is a possible next step if the bridge proves useful).
- Small samples: a frontier country with 12 to 20 quarters of GDP will usually fall back to `bridge_pooled`.
- Several frontier names (Venezuela, Zimbabwe, Belize, Zambia) publish few or irregular monthly activity
  series; expect CPI-only coverage for them.
- Free sources mostly keep only the latest vintage, so first-release evaluation of history needs a vintage
  archive (OECD revisions database, ALFRED where available) or starts from the first live fetch.

## Change control

New module, off by default, no parameter in `data/assumptions.json`. Any later use of a nowcast in a risk
number (for example as a growth input to the hazard model or DSA) is a model change and goes through
`econquest change propose`.
