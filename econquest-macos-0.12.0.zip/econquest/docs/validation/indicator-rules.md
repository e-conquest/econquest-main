# Indicator mapping rules for Team A (HO-20261024-A-B-006)

Owner: Team B (AGENT-03, EQ-B-0078). Date: 2026-10-24. Status: published rules; no cell is filled by this document.

## What this document is

Team A has, or can fetch, raw inputs for eleven items whose scorecard cell needs a mapping rule: a formula, or
thresholds for level 0-4. This document gives one rule per item, precise enough to code without judgement.

- These rules change no shipped number. They tell Team A how to fill cells that are empty today (or carry a seed).
- Every cell filled by a rule passes Team A's ingestion quality gate before it goes live. Rule cells are held
  (`unverified`) until the source is verified on Sam's Mac, as for every other new adapter.
- **A promoted cell moves scorecard and PD numbers.** A level or value that replaces a seed changes the indicator
  score, then the pillar score (weighted average blended with the worst indicator), the composite and the grade,
  and through the scorecard the layer-1 hazard PD and the portfolio VaR/ES/EL. **The batch effect (old vs new
  scores, pillars, PDs and portfolio metrics) will be shown to Sam before any batch is applied.**
- Machine-readable copy: not written. `data/panel/` is owned by Team A (`teamctl owner data/panel/` gives team A,
  AGENT-06), so `data/panel/indicator_rules.json` is for Team A to write from this document if they want one.

### Licence clearance before any fetch

Items marked **[licence: Sam]** use research datasets that need Sam's licence clearance before anything is
fetched: V-Dem (4.3), Powell-Thyne (4.4), EPR (6.10), UCDP (6.9, 6.12), UNHCR (6.12), IPC (6.11), Aqueduct
(7.12). The neighbour list for 6.12 uses the Correlates of War Direct Contiguity file (research data, free with
citation, terms unverified); add it to the same clearance. World Bank (WDI Gini, Pink Sheet, population) and BIS
are covered by the existing feeds. IMF data (5.4, 5.9, 5.13) is for internal research only (Sam, 2026-10-24) and is
restricted for client output.

### Common conventions

- Point in time: use only observations dated on or before `as_of`, and only releases published on or before
  `as_of`. Never read the wall clock.
- Level indicators score `level x 25` (scoring.py). Numeric indicators score by straight-line interpolation between
  the rulebook thresholds `t0..t100` (and `low0..low100` for two-sided 5.13), clipped to 0-100.
- "Hold" means the gate keeps the cell out of `indicators.csv` with the stated reason, and the seed stays.
- "Blank" means no value is written; the cell stays as today (seed) with an `unserved.csv` reason.
- Every rule cell records in its provenance series the rule id (for example `rule 4.3 v1`) and the inputs used.

## Summary table

| Item | Id | Source series | Rule type | Window | Staleness limit | Licence |
|---|---|---|---|---|---|---|
| 1 | 4.3 | V-Dem v2x_regime, v2cacamps_osp | level map | latest year | data year >= as_of year - 2 | Sam |
| 2 | 4.4 | Powell-Thyne coup file | level by recency | 50 years | file updated <= 365 days | Sam |
| 3 | 6.10 | WDI SI.POV.GINI; EPR Core + ACD2EPR | max of two levels | latest | Gini 10 years; EPR 6 years | Sam (EPR) |
| 4 | 6.12 | COW contiguity + unions; UCDP GED; UNHCR; WDI pop | max of components | 12 months | data end <= 183 days | Sam |
| 5 | 7.12 | Aqueduct 4.0 country baseline water stress | score bands | static | latest release | Sam |
| 6 | 5.4 | IMF MFS private credit, IMF CPI, Pink Sheet | correlation | 40 quarters | last quarter <= 275 days | IMF internal |
| 7 | 6.9 | UCDP GED (proxy for ACLED) | ratio with floor | 12 vs prior 60 months | data end <= 92 days | Sam |
| 8 | 6.11 | IPC / Cadre Harmonise; WDI pop; WB income group | share, structural 0 | latest analysis | validity end <= 365 days | Sam |
| 9 | 5.13 | own policy rate; else anchor rate (BIS) | anchor proxy | latest | 30 days (daily) | BIS/IMF |
| 10 | 5.9 | IMF MFS private credit / WEO NGDP | approved with conditions | 40-quarter minimum | 275 days | IMF internal |
| 11 | 2.12, 5.9, 5.13 | BIS, IMF | precedence change | - | BIS_STALE_DAYS | - |
| 12 | 5.9, 2.12 | WDI FS.AST.PRVT.GD.ZS, PX.REX.REER (third source) | approved with changes | 15 years (5.9); 10 years, 8 needed (2.12) | latest year >= as_of year - 2 | IMF internal |
| 13 | 3.6, 3.7, 4.3, 4.4, 6.10, 6.12, 7.12 | research adapters (EQ-A-0067) | rules on the adapters' inputs | see 13 | see 13 | see 13 |

## 1. 4.3 Regime type and factionalism [licence: Sam]

Rulebook: level 0-4; guide "0 full democracy | 1 stable full autocracy | 2 partial autocracy | 3 partial
democracy | 4 partial democracy with polarized, exclusionary factions"; api "V-Dem dataset (v2x_regime, v2cacamps)".

Source: V-Dem Country-Year Core dataset. `v2x_regime` (Regimes of the World, Luhrmann et al. 2018: 0 closed
autocracy, 1 electoral autocracy, 2 electoral democracy, 3 liberal democracy). `v2cacamps_osp` (political
polarization on the original 0-4 scale; 0 "not at all", 4 "yes, to a large extent"; higher is more polarized).

Rule, for the latest country-year Y in the release:

| v2x_regime in Y | Base level |
|---|---|
| 3 liberal democracy | 0 |
| 0 closed autocracy, and v2x_regime = 0 in every year Y-4..Y | 1 |
| 0 closed autocracy, with any other category in Y-4..Y | 2 |
| 1 electoral autocracy | 2 |
| 2 electoral democracy | 3 |

Polarization override, when `v2cacamps_osp >= 3.0` in Y ("yes, to a noticeable extent" or more): liberal democracy
-> 3; electoral democracy -> 4. Autocracies are unchanged (the guide's level 4 is a democracy with exclusionary
factions; autocracy is already scored by regime type).

Window: latest year in the release; Y-4..Y for the stability test. Staleness: hold when Y < as_of year - 2 (V-Dem
publishes in March with data to the previous year, so Y = as_of year - 1 is normal and one missed release is
allowed). Edge cases: country missing from V-Dem: blank. `v2cacamps_osp` missing but v2x_regime present: write the
base level and hold for review. Do not substitute the latent-scale `v2cacamps` for `_osp` (the scales differ).

## 2. 4.4 Coups and irregular transfer of power [licence: Sam]

Rulebook guide: "0 no attempt in 50 years | 1 last attempt >20 years ago | 2 attempt within 20 years or military
active in politics | 3 attempt within 5 years or coup in a neighbor within 3 years | 4 successful coup within 5 years
or military government".

Source: Powell and Thyne (2011) global coups file: country, date, `coup` (1 failed, 2 successful). Months are counted
from the event date to `as_of`; events after `as_of` are ignored.

Rule (first match wins):

| Condition | Level |
|---|---|
| successful coup within 60 months | 4 |
| any attempt within 60 months | 3 |
| any attempt in a 6.12 neighbour within 36 months | 3 |
| any attempt within 240 months | 2 |
| any attempt within 600 months | 1 |
| none within 600 months | 0 |

Window: 50 years (600 months). Staleness: hold when the file's last update is more than 365 days before `as_of`.
Edge cases: zero attempts is a valid 0 for any state in the file's coverage (all states since 1950). States
independent for less than 50 years: count from independence; no attempt gives 0. "Military government" and
"military active in politics" are not in the file: they are not coded mechanically; the desk raises the level
through `data/adjustments.csv` with a reason.

## 3. 6.10 Inequality and excluded groups [licence: Sam for EPR; WDI is covered]

Rulebook guide: "0 Gini <35, no excluded groups | 1 Gini 35-40 | 2 Gini ~45 or large group excluded | 3 Gini ~50 or
excluded groups with active grievances | 4 Gini >=55 or excluded groups >20% in open conflict".

Sources: WDI `SI.POV.GINI` (0-100) from `raw_worldbank.csv`. ETH Ethnic Power Relations (EPR Core): group size
(share of population) and status; excluded = `powerless`, `discriminated` or `self-exclusion`. ACD2EPR links groups to
UCDP armed conflicts.

Gini level: below 35 -> 0; 35 to below 40 -> 1; 40 to below 47.5 -> 2; 47.5 to below 55 -> 3; 55 or more -> 4.
(Bands centre on the guide's 45 and 50; 55 is the guide's own cut.)

EPR level (latest EPR year E), first match wins:

| Condition | Level |
|---|---|
| excluded share > 20% and an excluded group in an active ACD2EPR conflict in E | 4 |
| a `discriminated` group >= 5%, or an excluded group with an ACD2EPR conflict in E-4..E | 3 |
| excluded share >= 10% | 2 |
| excluded share >= 1% | 1 |
| excluded share < 1%, or no politically relevant groups | 0 |

Cell = max(Gini level, EPR level).

Maximum Gini age: use the latest Gini with period >= as_of year - 10; older values are not used. Reason: most EM
surveys run every 3-6 years, Gini moves a few points per decade, and the bands are 5 points wide; the general
World Bank 3-year rule would blank most of the universe. Values older than 5 years are flagged `aged` in the
provenance series (informational). EPR staleness: E >= as_of year - 6 (EPR status changes rarely; releases are
about every two years). Edge cases: one part missing (for example Gini in several Gulf states): write the other part's
level and hold for review. Both missing: blank. A state outside EPR's coverage counts as EPR missing, not as 0.
Income- and consumption-based Ginis are used as published (no adjustment).

## 4. 6.12 Spillover from neighbours [licence: Sam]

Rulebook guide: "Neighbors = states sharing a land or maritime border, or members of the same monetary or trade
union; not the wider regional bloc. 0 none in conflict | 1 neighbor in minor conflict | 2 neighbor at war or
refugees >1% of population | 3 cross-border attacks | 4 active cross-border war".

Neighbour list (Team A builds `data/panel/neighbours.csv`: `iso3, neighbour_iso3, basis, source`):

- Land or sea: Correlates of War Direct Contiguity v3.2, latest year, `conttype` 1 (land) to 5 (up to 400 miles of
  water; two 200-mile EEZs can meet across 400 miles, so this is the maritime-border proxy).
- Unions: members of the same monetary union (euro area, WAEMU, CEMAC, ECCU) or customs union (EU, EAEU, SACU, GCC,
  Mercosur, EAC). Free-trade areas and wider regional blocs do not count.
- Symmetric: if A lists B, B lists A. Changes to the list go through Team A review.

Components, over the 12 months ending at `as_of` (UCDP GED annual plus GED Candidate; `best` fatalities):

| Component | Level |
|---|---|
| interstate dyad including this government, >= 1,000 fatalities in window; or >= 1,000 fatalities on this territory in events where side_a or side_b is another state's government | 4 |
| any GED event on this territory where side_a or side_b is another state's government; or an interstate dyad including this government with >= 25 fatalities | 3 |
| any neighbour with >= 1,000 state-based (`type_of_violence` = 1) fatalities on its territory | 2 |
| refugees and asylum-seekers from neighbours hosted here (UNHCR, latest figure <= as_of) > 1% of WDI SP.POP.TOTL | 2 |
| any neighbour with 25 to 999 state-based fatalities on its territory | 1 |
| none of the above | 0 |

Cell = highest level reached. Staleness: hold when the last month covered by UCDP ends more than 183 days before
`as_of`, or the UNHCR figure is more than 18 months old. Edge cases: no neighbours (isolated islands): conflict parts
are 0, which is valid. No UNHCR row for the host: 0 refugees (UNHCR tables omit zeros). Population missing: compute
the other components and hold.

## 5. 7.12 Water stress [licence: Sam]

Rulebook guide: "0 low | 1 low-medium | 2 medium-high | 3 high | 4 extremely high". Source: WRI Aqueduct 4.0 country
rankings, baseline water stress (`bws`), all sectors, score 0-5. Aqueduct's own bands are used as they are:

| bws score | Aqueduct category (withdrawals / supply) | Level |
|---|---|---|
| 0 to < 1 | Low (< 10%) | 0 |
| 1 to < 2 | Low-medium (10-20%) | 1 |
| 2 to < 3 | Medium-high (20-40%) | 2 |
| 3 to < 4 | High (40-80%) | 3 |
| 4 to 5 | Extremely high (> 80%) | 4 |

Edge cases: "Arid and low water use": level 4 (structurally scarce supply; check the score the release gives it and
hold the first run for review). No data (-9999) or country absent: blank. Window: static; staleness: use the latest
Aqueduct release published on or before `as_of`; no age limit until a newer release exists.

## 6. 5.4 Commodity link [IMF internal research]

Rulebook: numeric correlation, thresholds 0.1 / 0.25 / 0.4 / 0.55 / 0.7 (higher is riskier).

Formula: Pearson correlation, over the last 40 quarters with both series, of
- real private credit growth: y/y log change of end-quarter IMF MFS ODC claims on the private sector (LCU) deflated by
  the IMF CPI index; and
- main export price growth: y/y log change of the quarterly average Pink Sheet price (nominal US$) mapped from
  `countries.csv` `mainexp`.

Contemporaneous (no lag search; y/y changes already span four quarters). At least 28 paired quarters, else blank.

Mapping `mainexp` -> Pink Sheet series (verify the column header in the fetched file; a composite is the equal-weight
average of the members' y/y log changes):

| mainexp | Pink Sheet series |
|---|---|
| Crude oil | Crude oil, average |
| Copper | Copper |
| Gold | Gold |
| Soy complex | Soybeans; Soybean meal; Soybean oil |
| Soybeans, iron ore, oil | Soybeans; Iron ore, cfr spot; Crude oil, average |
| Gold and oil | Gold; Crude oil, average |
| Natural gas / LNG | Natural gas index |
| Coal | Coal, Australian |
| Cocoa / Coffee / Cotton / Sugar / Palm oil | Cocoa; Coffee, Arabica and Robusta (average); Cotton, A Index; Sugar, world; Palm oil |
| Aluminium / Nickel / Zinc / Iron ore | Aluminum; Nickel; Zinc; Iron ore, cfr spot |

A `mainexp` not in this table: blank, and Team A asks Team B to add the row (no guessed mapping).

Manufacturing, services and tourism exporters (`exptype` not `Commodity`): write 0.0, with provenance `rule 5.4:
non-commodity exporter (structural 0)`. The channel the indicator measures (a credit cycle driven by one export
price) does not exist for them; 0.0 scores 0, as the seed does today (0.05-0.1). Cross-check: if WDI fuel plus ores
and metals exceed 40% of merchandise exports while `exptype` is not Commodity, hold for review.

Staleness: hold when the last paired quarter ends more than 275 days before `as_of` (the BIS quarterly rule).

## 7. 6.9 Political violence trend, zero base [licence: Sam]

Rulebook: ratio, thresholds 0.8 / 1.0 / 1.5 / 2.0 / 3.0. Source: UCDP GED plus Candidate events (all violence types),
a proxy for ACLED (UCDP covers organised violence only, not protests or riots; say so in the provenance series).

Let N12 = events in the 12 months ending at `as_of`; B = events per year in the 60 months before those 12 (months
13-72 back; non-overlapping, so the ratio measures a trend).

| Case | Value |
|---|---|
| B >= 5 | N12 / B |
| B < 5 and N12 < 5 | 0.8 (no material violence; scores 0) |
| B < 5 and N12 >= 5 | N12 / 5 |

Values are capped at 10.0. The floor of 5 events a year is the materiality level: below it, a ratio of small counts
is noise, and 0/0 is undefined. Staleness: hold when the last month covered ends more than 92 days before `as_of`.
Edge case: country absent from GED: 0 events (GED covers all states), value 0.8.

## 8. 6.11 Population in IPC phase 3+ [licence: Sam]

Rulebook: %, thresholds 2 / 5 / 10 / 20 / 30. Source: IPC API analyses, including Cadre Harmonise (the IPC-compatible
system used in West Africa and the Sahel, for example Nigeria and Senegal).

- Analysis exists: value = people in phase 3+ / WDI SP.POP.TOTL x 100 (national population, so partial-area
  analyses are not inflated). Use the latest analysis published on or before `as_of`; take the projected figure if
  `as_of` is inside the projection period, else the current figure.
- No analysis in the last 36 months and WB income group high or upper-middle: 0.0 (structural zero: these countries
  are outside the IPC system because crisis-level food insecurity is not a national issue there).
- No analysis and income group low or lower-middle: blank (no proxy), reason `no IPC/CH analysis`.

Staleness: hold when the analysis validity end (projection end, else current-period end) is more than 365 days
before `as_of`.

## 9. 5.13 Real policy rate for dollarised and hard-peg economies

Rulebook: two-sided; high side 4 / 6 / 8 / 10 / 12, low side 0 / -1.5 / -3 / -5 / -8 (0 to +4 scores 0).

- Own policy rate from any source (BIS, IMF, verified national): normal rule, rate minus WEO PCPIPCH.
- No own rate, and the economy uses another currency as legal tender or has a currency board / hard peg: use the
  anchor central bank's policy rate (BIS CBPOL, latest observation <= as_of) minus domestic WEO PCPIPCH. Provenance
  `rule 5.13: anchor rate <US|XM>`. Monetary conditions are imported, so the anchor rate minus domestic inflation is
  the real rate the economy faces.
- Anchors: Ecuador, El Salvador, Panama -> US; Montenegro -> euro area (XM). Any other hard peg is added only when
  Team A names its anchor from the IMF AREAER; until then blank.
- Soft pegs and exchange-rate-targeting regimes with no rate in any source (for example Singapore): blank.
- Never 0: a 0 claims a real rate in the neutral band and hides a negative real rate.

Staleness: anchor rate 30 days (BIS daily rule); CPI as WEO (214 days).

## 10. 5.9 Credit gap for non-BIS economies: approved with conditions [IMF internal research]

Decision: the BIS method on IMF credit and WEO GDP is **approved**, under these conditions.

1. Credit: IMF MFS ODC claims on the private sector, end-quarter, LCU. This is bank credit, narrower than the BIS
   total credit series. The provenance series says `bank-credit gap (IMF), not BIS total credit`.
2. GDP: WEO NGDP (LCU, annual). Four-quarter sum for quarter k of year Y: NGDP(Y-1) x (4-k)/4 + NGDP(Y) x k/4.
   Years after `as_of` are never used.
3. Ratio = 100 x credit / GDP. Trend: one-sided HP filter, lambda 400,000: the trend at t is the last point of a
   two-sided HP filter on the ratio from the first observation to t (the BIS / Basel CCyB method). Gap = ratio -
   trend, in pp of GDP. The rulebook thresholds (2 / 5 / 10 / 15) follow the Basel CCyB guide (buffer from 2 pp to
   10 pp).
4. At least 40 quarters of ratio up to t, else blank (the one-sided trend is unreliable on short samples).
5. A q/q credit change above 20% or a series break flagged by the IMF: hold for review.
6. Before the first apply, Team A runs the method on the BIS economies and reports the median |IMF gap - BIS gap|.
   If it exceeds 5 pp, Team B reviews the method before any IMF gap goes live.

Known limits: in fast-deepening emerging markets the HP gap tends to be positive for long periods (financial
deepening reads as a boom). No adjustment is applied; the limit goes in the cell's note. Staleness: last quarter no
more than 275 days before `as_of`.

## 11. Precedence BIS > IMF: changed to source precedence with a staleness override

Current rule (official/precedence.py): BIS first, then IMF, by source, never by freshness; a stale BIS value is held,
not replaced.

Recommended rule:

1. BIS has a value within its staleness limit (`BIS_STALE_DAYS`: daily 30, monthly 92, quarterly 275): BIS is used,
   whatever IMF says (as today; the `bis_imf_cross` check stays).
2. BIS is stale, and IMF has an observation that is newer than the BIS one and within the same limit for its own
   frequency: IMF is used. Provenance note `fallback: BIS stale since <date>`. The first switch of a cell is held for
   review; the cross-check is skipped (the two values are for different dates).
3. Both stale: hold, as today.
4. Return to BIS as soon as BIS is fresh again.
5. 5.9 only: rule 2 applies only after the 5.9 IMF method passes condition 6 above; until then 5.9 keeps the
   source-only rule.

Why: BIS stays first because its series are harmonised across countries, and switching sources whenever IMF is a
day newer would make cells flip between definitions. But holding a stale BIS value indefinitely keeps a wrong number in
place: the Argentina BIS policy rate has had no observation since 2025-07-10 (470 days at 2026-10-23), in a period
when the actual rate moved by tens of points. A fresh value from a second official source is better than a held stale
one. The staleness limits already exist and are gate rules, so the override needs no new parameter.

This is a change to Team A's code (`precedence.choose` needs the observation dates); Team A implements it.

## 12. WDI third-source fallbacks for 5.9 and 2.12 (HO-20261024-A-B-011, EQ-B-0086): approved with changes

Team A's `official/wdi_extra.py` (EQ-A-0062) fills 5.9 and 2.12 from annual World Bank WDI history only when BIS
and the IMF have no value. Reviewed: `wdi_extra_transforms`, `one_sided_gap`, `hp_trend`, `_consecutive_tail`,
`wdi_gate_rows` and tests/test_wdi_extra.py. Both series codes stay UNVERIFIED until Sam's Mac pull; approval of the
method does not release a value before then.

What was checked. The transforms use only years up to the `year` passed in. The credit trend at t is the last point
of a two-sided HP filter on data up to t (one-sided, no later year). The REER window ends at the latest year. A
year with two rows is refused, not picked. These are point in time for a live cell. The WDI series are the latest
revised vintage, so a historical replay must read the dated copy in data/live/vintages, never a fresh pull; the
fetch's default `year` (today) is right for a live pull only, and a replay must pass the as_of year.

### 5.9 credit gap from FS.AST.PRVT.GD.ZS: approved with changes

- Lambda 1,562.5 (400,000 / 4^4, the Ravn-Uhlig annual equivalent of the BIS quarterly lambda): approved.
- At least 15 consecutive annual observations up to t: approved (section 10 asks 10 years of quarters; 15 annual
  points is the stricter count). `CREDIT_MIN_TREND_YEARS` is defined but not used; use it or remove it.
- Change 1, break hold (as section 10 condition 5): hold the cell (check `break`) when, in the run used, the ratio
  moves by more than 10 pp of GDP or by more than 50% of its previous level between two consecutive years. GDP
  rebasings, redenominations and hyperinflation (Nigeria, Zambia, Zimbabwe, Venezuela are on the fill list) make
  such steps, and an HP gap reads a step as a boom or a bust.
- Change 2, staleness: hold when the latest year is more than 2 years before the as_of year (the gate default of 3
  is too loose for a gap).
- Change 3, licence: the series is IMF IFS credit over GDP. Treat it as IMF internal and restricted for client
  output, like PX.REX.REER and the section 10 IMF gap.
- Change 4, label: FS.AST.PRVT.GD.ZS is domestic credit to the private sector (banks and other financial
  corporations), not bank credit only. Provenance: `rule 5.9 WDI v1: domestic private credit gap (WDI/IFS, annual),
  not BIS total credit`; drop "method pending Team B".
- Change 5, comparison before the first release (as section 10 condition 6): Team A runs the WDI method on the desk
  names that have a BIS gap and reports the median |WDI gap - BIS gap| (BIS Q4 value for the same year). Above
  5 pp, Team B reviews before any WDI gap goes live.
- Known limit, as section 10: financial deepening reads as a positive gap.

### 2.12 REER vs 10-year mean from PX.REX.REER: approved with one change

- Latest annual REER against the mean of the last 10 years (latest included), at least 8 present: approved. It is
  coarser than the BIS monthly rule; the provenance says so already.
- Change: staleness. Hold when the latest year is more than 2 years before the as_of year (default 3 is too loose;
  a 3-year-old annual average says little about today's valuation).
- Range bounds [-80, 300] and the IMF restriction as built: approved.

Team A adds "5.9" and "2.12" to `wdi_extra.METHOD_APPROVED` under a ticket only together with the changes above.
A promoted cell moves the scorecard (both have weight 0.05); the batch effect goes to Sam before any apply.

## 13. Research-adapter inputs (HO-20261025-A-B-002, EQ-B-0095): rules and one rejection

Team A's adapters in `econquest/ingestion/research/` (EQ-A-0067) emit raw `kind=input` rows. This section says how
each input becomes a cell. Sections 1-5 stay the level rules; this section fits them to what the adapters emit, and
names the adapter changes Team A needs first. No rule here fills a cell by itself: every cell passes Team A's gate,
held `unverified` until the file layout is checked on Sam's Mac.

Point-in-time rule for all items below. A row's `year` is the year the data describes. A release may be used only
for an `as_of` on or after its publication date. A replay reads the release that was published on the `as_of`
date (the dated file in the drop-in folder, by its `vintage`), never a later file.

**Needs Sam's sign-off at first values (normal gate review, as in section 12):** 3.6 (13.1), 4.4 year-only
recency (13.3), 6.10 without the conflict parts (13.4), 7.12 category -1 (13.6). These are judgement choices that
can move desk scores. The batch effect goes to Sam before any apply.

### 13.1 3.6 with no legislature: approved, with a changed value

Rulebook 3.6: "Courts and legislature constrain the executive", mean of `v2x_jucon` and `v2xlg_legcon`. V-Dem sets
`v2xlg_legcon` missing when the country has no legislature. Using `v2x_jucon` alone is **rejected**: it reads "no
legislature" as "the legislature constrains as much as the courts", a better score for a weaker check.

Rule: when V-Dem codes no legislature (`v2lgbicam` = 0) in the year, the legislative part is 0 (no constraint),
so 3.6 = `v2x_jucon` / 2. Provenance `rule 3.6 v1: no legislature, legislative constraint 0`. In any other case a
missing `v2xlg_legcon` or `v2x_jucon` leaves the cell blank, as today.

Team A: add `v2lgbicam` to `vdem.COLS` as an input. Effect: none of the 18 desk countries is expected to lack a
legislature (V-Dem coverage UNVERIFIED), so no desk cell is expected to move; any cell this rule fills is shown in
the batch effect. Sam's sign-off at first values.

Coded in `validation/research_effect._constraints` (EQ-B-0119, HO-20261025-A-B-012). It reads the adapter's
`jucon_half_no_legislature` row when that row is newer than the mean row, or when there is no mean row. The cell
is always held, rule `rule 3.6 v1: no legislature, legislative constraint 0`, and marked stale when the year is
before the as_of year - 2.

### 13.2 4.3 regime type: section 1 confirmed; the adapter must emit `v2cacamps_osp`

Section 1 is the rule. The adapter emits `v2cacamps`, the measurement-model (latent) scale. The section 1 cut
(`>= 3.0`, "yes, to a noticeable extent") is on the original 0-4 scale, `v2cacamps_osp`. A cut on the latent scale
is **rejected**: it has no fixed meaning across releases.

Team A: emit `v2cacamps_osp` as the 4.3 polarisation input. Until it is there, section 1's edge case applies: write
the base level from `v2x_regime` and hold for review. Data year Y as in section 1 (V-Dem vN is published in March
with data to the previous year; usable from its publication date). Staleness as section 1 (hold when Y < as_of
year - 2). Mechanical; no extra sign-off beyond section 1.

### 13.3 4.4 coups: section 2 confirmed; month needed, year-only fallback

Section 2 counts months from the event date. The adapter emits annual counts (`coup_attempts`, `coup_successes`)
and drops the month and day that the file has.

Rule, preferred: Team A emits the year and month of each attempt (for example `coup_attempt_month` = YYYYMM, value 1
for failed, 2 for successful) and section 2 is applied as written, with the event dated the last day of its month.
Events after `as_of` are ignored.

Fallback, while only annual counts exist: an event in year Y counts as Y-12-31. Then "within 60 months" is Y >= as_of
year - 5; 36 months is Y >= as_of year - 3; 240 months is Y >= as_of year - 20; 600 months is Y >= as_of year - 50.
This can count an event as up to 11 months more recent than it was, so a level can come out one step higher than
with dates (the cautious side). Events in the `as_of` year are used only from a file published on or before
`as_of`. Provenance `rule 4.4 v1: annual counts (month not used)`. Sam's sign-off at first values for the fallback.

Other points:
- A country with no row in the file: 0 only when the adapter wrote explicit zero rows for it (it does so only when
  every name in the file mapped to ISO3); otherwise blank.
- The neighbour condition (level 3) needs `data/panel/neighbours.csv` (section 4). Until it exists, the condition is
  skipped and the provenance says `neighbour coups not checked`; the cell is held for review when a 6.12 neighbour
  is known to have had an attempt within 36 months.
- "Military government" stays a desk adjustment, as in section 2.

### 13.4 6.10 EPR share: 0-1 fraction confirmed; interim level without the conflict parts

Confirmed: `excluded_pop_share` stays a 0-1 fraction. It is never stored as a percent. Section 3's cuts read as
fractions: 20% = 0.20, 10% = 0.10, 1% = 0.01, 5% = 0.05. A share above 1.0 (beyond rounding) is refused, as the
adapter does.

Two adapter changes:
- Country-years whose groups are all IRRELEVANT: emit 0.0 (section 3: "no politically relevant groups" is level 0).
  Today they are skipped and would read as "EPR missing". STATE COLLAPSE years stay skipped (blank).
- Emit `discriminated_pop_share` too (the summed size of DISCRIMINATED groups), for section 3's level 3 test.

Interim rule until ACD2EPR (the conflict link) is built: EPR level = 3 if `discriminated_pop_share` >= 0.05; else 2
if `excluded_pop_share` >= 0.10; else 1 if >= 0.01; else 0. Level 4 and the conflict half of level 3 need ACD2EPR
and are not coded. Hold the cell for review when `excluded_pop_share` > 0.20 (it could be a 4). Cell = max(Gini
level, EPR level), as section 3. Provenance `rule 6.10 v1: EPR without ACD2EPR conflict test`.

Data year E = the EPR spell year. EPR 2021 (published 2021-06-08) covers to 2021; staleness as section 3 (E >=
as_of year - 6), so it ages out for `as_of` in 2028. Sam's sign-off at first values: the interim level can
understate a country with excluded groups in open conflict.

### 13.5 6.12 refugees: rule as section 4, with the UNHCR input adapted

The UNHCR adapter emits refugees and asylum-seekers hosted from all origins. Section 4 counts those from
neighbours only. Rule:
- hosted total (refugees + asylum-seekers) <= 1% of WDI SP.POP.TOTL: the refugee part is 0. This is exact, since
  the neighbours' share cannot exceed the total.
- hosted total > 1%: the refugee part needs the origin split. Team A adds country of origin (`coo`) to the UNHCR
  request; until then the cell is held for review when this part would set the level.

Data year: a UNHCR year-end figure for year Y is used only from 30 June Y+1 (the Global Trends release is in June).
Staleness as section 4 (18 months). 6.12 stays blocked anyway on the UCDP token and `neighbours.csv`.

### 13.6 7.12 Aqueduct: score bands; category -1; year stamp

- Level from `bws_score` by the section 5 bands. `bws_cat` is a check: when it is 0-4 and differs from the score
  band, hold.
- Category -1 (arid and low water use): level 4, as section 5, whatever the score; hold the first run for review.
  Reason: supply is structurally scarce, and the rulebook guide has no "not applicable". Sam's sign-off at first
  values: this sets the highest level for countries whose current withdrawals are low.
- No data (-9999) or country absent: blank.
- Year stamp: **rejected** as the release year 2023. Under the point-in-time rule the row's year is the last year
  the baseline describes, 2019 (Aqueduct 4.0 baseline 1979-2019; Team A confirms from the technical note,
  doi 10.46830/writn.23.00061), and the release is usable only from its publication date (August 2023; exact date
  UNVERIFIED, Team A records it). 7.12 is static: no year-age limit (section 5); the gate must not apply its
  general year staleness to 7.12. A newer Aqueduct release replaces it from its own publication date.

### 13.7 3.7 WJP two-year labels: first year, usable from publication

A two-year label such as "2017-2018" is **rejected** as its last year. WJP collected that edition's data in the
first year and published it early in the second (2017-2018: published January 2018). Rule: data year = the first
year of the label. Single-year labels keep their label year.

An edition may be used only from its publication date. Team A records each edition's publication date (WJP release
notes) in the adapter. Without a recorded date the edition is usable from 31 December of the label's last year (the
cautious default). Staleness: hold when the data year < as_of year - 2, as for V-Dem. Mechanical; no sign-off.

Code (EQ-B-0128, HO-20261025-A-B-018): `rules.research.point_in_time` applies this default. A single-year label Y is
usable from 31 December Y. A two-year label is usable from 31 December of its last year, which the adapter gives as
the `edition_last_year` row (same country and data year). A recorded `published` date always wins.

## 14. 2.2 when DT.AMT.PNGB.CD is missing (Team A question 2026-10-25, EQ-A-0086, EQ-B-0103)

2.2 is the gross external financing need over reserves: (-CA + short-term debt DT.DOD.DSTC.CD + public and publicly
guaranteed amortisation DT.AMT.DPPG.CD + private non-guaranteed amortisation DT.AMT.PNGB.CD) / FI.RES.TOTL.CD. A
missing term set to 0 makes the need smaller, so a blanket zero is not conservative and is rejected.

Rule, per country and year t (the latest year with an actual, not projected, DPPG and DSTC value):
1. **Actual PNGB for t:** use it.
2. **No PNGB for t, but an actual PNGB value in t-1 or t-2:** carry the latest one forward (same k = 2 as
   `layer1.missing_input_rule`). The cell note says "PNGB carried from <year>".
3. **Country reports no private non-guaranteed debt:** IDS has no actual DT.DOD.DPNG.CD (PNG debt stock) value above 0
   in t-5..t. Then PNGB counts as 0, because there is no such debt to amortise. The cell note says "PNGB 0: no PNG debt
   reported". Team A adds DT.DOD.DPNG.CD to the IDS pull for this test (stock only, not used anywhere else).
4. **Otherwise** (the country has PNG debt but no recent amortisation figure): the cell stays missing and is held,
   with reason "PNGB missing". It is not filled from projections.

Projected years (after the latest actual year) are never used for any term, as EQ-A-0086 already does.
Expect most of the ~19 countries to fall under 3 (small or frontier economies whose IDS file has no PNG block).
Mechanical; no sign-off. If more than 5 desk countries land in rule 4, Team B reviews before publish.

## 15. 2.11 export concentration from the WDI groups (HO-20261025-A-B-005, EQ-B-0101): option (b), changed

Rulebook 2.11: "largest commodity or sector, % of exports", thresholds 20/35/50/65/80, weight 0.05. Team A's proxy is
the largest of five WDI merchandise groups, TX.VAL.{FUEL,MMTL,FOOD,AGRI,MANF}.ZS.UN, latest year with all five.
Numbers below are from Sam's 0.4.2 pull (`team/inbox/pull-20261025T013150Z/raw_worldbank.csv`, 88 countries).

Option (c), the proxy as built, is **rejected**: manufactures are one group, so diversified manufacturers read as
concentrated (CHN 90.5, KOR 88.0, JPN 80.6). Option (a) is not needed for commodity exporters, where the groups
measure what the rulebook asks.

Plain option (b), max(FUEL, MMTL, FOOD, AGRI) for every country, is **also rejected** for manufacturers. It gives
them their small commodity share (CHN 2.3, JPN 3.6, PHL 10.8, PAK 18.2), which scores 0. But WDI cannot tell
whether a manufacturer depends on one sector. The Philippines' seed of 55 reflects electronics; (b) would score it 0.
That is the same error as (c), in the other direction.

Rule, per country, on the latest year with all five groups. Point in time: WDI year y is used only from 30 June
y+1. Staleness as Team A's gate: hold when the year is more than 3 years before the as_of year. Coded in
`validation/research_effect._export_concentration`.
1. **Coverage floor.** If the five groups sum to less than **75%** of merchandise exports, hold the cell
   (reason `2.11: groups cover <sum>% of exports; gold or unclassified exports not measured`). The seed stays. A
   reviewer may release it with max(commodity max, 100 - sum) when the country's main export (`countries.csv`
   `mainexp`) is gold; otherwise it stays held.
2. **Manufactures largest.** If MANF is the largest of the five groups: blank, reason `2.11: manufactures are the
   largest group; the sector split needs Comtrade HS chapters`. The seed stays.
3. **Otherwise** the value is max(FUEL, MMTL, FOOD, AGRI). Provenance `rule 2.11 WDI v1: largest SITC commodity
   group`. A commodity group is broader than one commodity (FOOD covers soy, meat and coffee together), so the value
   can read high; the note says so.

Why 75%, not the suggested 80%: the sums have a gap between 72.5 (ARG) and 76.8 (ALB). Below 75 are the gold or
unclassified cases SUR 7.2, GHA 36.9, UZB 56.2, RWA 59.4, ZWE 66.0, and ARG 72.5. At 80 the floor would also catch
ALB 76.8 and GBR 79.7, which are diversified manufacturers, not gold exporters. The next country above them is NAM
at 81.8, so 75 and 80 hold the same commodity exporters. The floor runs before step 2, so UZB, whose largest
classified group is MANF and whose gap is gold, is held, not blanked. ARG is held because 27.5% of its exports are
unclassified. That gap is not gold (ARG's main export is soy), so the reviewer checks it.

Desk effect (as_of 2026-10-23; the gate's `change` check will hold most of these for review first):

| Country | Seed | Rule | Value (year, group) | Score seed -> new |
|---|---|---|---|---|
| Belize | 50 | 3 | 95.34 (2025, FOOD) | 50.0 -> 100.0 |
| Brazil | 15 | 3 | 40.73 (2025, FOOD) | 0.0 -> 34.6 |
| Colombia | 40 | 3 | 34.90 (2025, FUEL) | 33.3 -> 24.8 |
| Nigeria | 85 | 3 | 85.90 (2025, FUEL) | 100.0 -> 100.0 |
| Senegal | 25 | 3 | 32.71 (2024, FUEL) | 8.3 -> 21.2 |
| Zambia | 75 | 3 | 72.99 (2024, MMTL) | 91.7 -> 88.3 |
| Argentina, Zimbabwe | 25, 50 | 1 (hold) | sums 72.5, 66.0 | seed stays |
| Venezuela | 85 | stale (2013) | hold | seed stays |
| VNM, PHL, CHN, MYS, SGP, JPN, KOR, IND, PAK | | 2 (blank) | | seeds stay |

100k paths, as_of 2026-10-23, the six step-3 desk values only: VaR99 58.19 -> 58.53, ES99 78.72 -> 78.95, EL 0.880
-> 0.897, L-VaR99 63.47 -> 63.81. PD moves: Senegal 13.34% -> 13.46%, Belize 4.86% -> 4.93%, Brazil 1.12% ->
1.14%; Colombia and Zambia down by less than 0.01 pp; no grade changes. 2.11 also feeds the stress-path export shock
(scoring.stress_inputs) and the commodity signal (signals.py), so the move is larger than the composite change.
Releasing these cells moves desk PDs: a Tier 1 batch for Sam (draft card in
docs/validation/research-datasets-effect.md section 4). Sam's sign-off at first values.

## 16. 1.8 default record from the CRAG spells (HO-20261025-A-B-006, EQ-B-0104)

Rulebook 1.8 is "restructurings or defaults, past 20 years". Team A counts it from
`data/panel/sovereign_defaults_crag.csv` (`ingestion/crag_count.py`). The rule:

1. **Window.** 20 calendar years ending in the as-of year minus 1, both ends included (as_of 2026-10-23 gives
   2006-2025). CRAG is annual and the as-of year is never complete. If the file's last year is earlier than the
   window end, the count uses what the file has and the cell carries `crag_last_year` so the gate can see it is short;
   the window does not move back.
2. **Which spells.** Overlap: an episode counts if any of its default years falls in the window. A country in default
   all through the window (Argentina) has a default record; start-only would score it 0, which is wrong for the
   indicator's purpose.
3. **Episodes.** Use the hazard event rule `crag_v1` (`validation/hazard_events.py` RECOMMENDED_RULE: USD 10m floor,
   cure 2 years, overlapping and adjacent spells merged, point in time), so 1.8 and the hazard events count the same
   episodes. One merged spell is one episode however long it is. Restructurings inside one spell do not count
   again: CRAG has no restructuring dates, and counting them would need a source we do not hold. Amended by 3a.

   **3a. New defaults inside one episode (EQ-B-0127, 2026-10-26; method proposal, first values parked under D2.1).**
   The dated source is CRAG itself: the annual in-scope arrears (FC bank loans + FC bonds + LC debt, USD m) in the
   raw BoC-BoE file `panel/staging/crag/DEBT_2026.csv`, which are the amounts the crag_v1 spells are built from
   (licence row `crag`: terms verified, client output allowed). No restructuring list is read: Cruces-Trebesch is
   licence UNVERIFIED and stays on the Mac, and `sovereign_defaults.csv` is memory-compiled (third_party_unverified).
   Inside an episode that overlaps the window, a year y in the window adds one event when:
   - the year before was still in default (arrears above the crag_v1 floor, USD 10m), so a restart that crag_v1
     merged through the cure years is not counted twice;
   - arrears had first been cut to at most half of the episode's running peak (a restructuring or settlement);
   - arrears then at least doubled year on year, by at least USD 10m;
   - y is more than 2 years after the previous counted year (a multi-year build-up is one event).

   Code: `econquest/rules/hazard.py` `REDEFAULT_RULE`, `redefault_years` (pure, C15) and
   `econquest/validation/crag_redefaults.py` (`annual_in_scope`, `count_with_redefaults`, `desk_table`). Tests:
   `tests/test_crag_redefaults.py` (SYNTHETIC Valet fixture). Desk values at as_of 2026-10-23: only Argentina changes,
   1 -> 4 (the 2001-2025 episode plus 2014, 2019 and 2023; 2020 is the same build-up as 2019). The seed is 3, and the
   rulebook's t100 is 3, so 4 and 3 both score 100: no score, PD or book number moves against today. Every other desk
   name keeps its crag_v1 count (BLZ 4, ZWE 2, VEN 1, ZMB 1, the rest 0). Across the 99 CRAG countries with an
   episode, only ARG, ECU (2020) and KNA (2014) gain a year. The years are the same for cut shares 0.33 to 0.67, rise
   multiples 1.5 to 3 and merge gaps 1 to 3. The 2023 Argentina year (bond arrears 987 -> 22,647 $m in CRAG) is
   flagged for the reviewer: CRAG records it, and its cause is not checked here.
4. **Creditors.** All CRAG classes (bank loans, bonds, local-currency debt). Official and IMF arrears are not in the
   file; the note says so.
5. **Outside coverage.** Countries not in `sovereign_defaults_crag_universe.csv` (JPN, KOR, SGP), or whose coverage
   starts after the window start, are not served: the seed stays, labelled, never a 0.
6. **Tier.** The method is set here (Team B). The first values replace seeds and move desk PDs (for example ARG
   3 -> 1), so they are a Tier 1 data batch: Team A runs them through the quality gate and the MVP dataset, and Sam's
   sign-off of the first values goes on the when-Sam-is-ready list. Team A reports the 18 desk values under this rule
   in the gate report; Team B adds the effect table to the parked decision pack.

7. **Consistency with `hazard_events` (checked by AGENT-03, EQ-B-0104).** The rule matches the hazard events with
   one condition. `hazard_events.apply_cure` extends a spell's `end` by the cure years (the year after a spell is
   not at risk), and those are not default years. The overlap test must use `end_spell`; use
   `hazard_events.episodes_in_window(events, first, last)`, which does. Testing `end` would add Venezuela 2002-2005
   (end_spell 2005, cure year 2006) and Nigeria 2004-2005 to the 2006-2025 window. Desk values at as_of 2026-10-23
   under crag_v1 with end_spell: BLZ 4, ZWE 2, ARG 1, VEN 1, ZMB 1, every other desk name 0 (JPN, KOR, SGP not
   served). Against the imported file, only Senegal changes, from 1 to 0: its 2021-2022 arrears are USD 0.2-0.3m,
   below the floor. `ingestion/crag_count.py` (Team A) reads the episode file's `start`/`end` and does not yet apply
   crag_v1. Team A should feed it `build_events(...)` output and test `end_spell`, or call `episodes_in_window`.
   Tests: `tests/test_hazard_events.py::test_episodes_in_window_uses_default_years_not_cure_years` and
   `test_rule_18_desk_counts_under_crag_v1`.

## 17. 2.1 reserves % of ARA from non-IMF sources, for client output (EQ-B-0104, with Team A EQ-A-0106)

2.1 is usable reserves as a % of the IMF ARA metric, weight 0.15. The desk value comes from `engine.dsa.reserve_adequacy`
on `dsa_inputs.csv`, whose short-term debt, broad money and other liabilities are estimates from IMF Article IV
(EXC-003, restricted). For client output 2.1 is today the rulebook midpoint placeholder (100) for every country
(docs/validation/client-safe-run.md section 4). This section gives a non-IMF route. Team A wires the sources under
EQ-A-0106. Reference code: `validation/nonimf_ara.py` (`ara_wb_cells`).

**Formula.** Unchanged: the ARA weights and regime mapping of `engine.dsa` (fixed: 0.30 short-term debt, 0.20 other
liabilities, 0.10 broad money, 0.10 exports; floating: 0.30, 0.15, 0.05, 0.05; managed: the average). Only the
sources change:

| Input | Non-IMF source | In the shared data? |
|---|---|---|
| Reserves | WDI FI.RES.TOTL.CD | yes (0.4.2 pull; not for WAEMU members such as Senegal) |
| GDP | WDI NY.GDP.MKTP.CD | yes |
| Exports | WDI NE.EXP.GNFS.ZS x GDP | yes (Nigeria's latest year is 1960: stale) |
| Short-term external debt | IDS DT.DOD.DSTC.CD (World counterpart) | yes for 13 of 18; not for MYS, KOR, VEN (not IDS reporters), SGP, JPN |
| Broad money | WDI FM.LBL.BMNY.GD.ZS x GDP | **no**: never pulled, code UNVERIFIED (Mac pull, when-Sam-is-ready) |
| Other liabilities | national central-bank IIP, portfolio liabilities, US$ bn | **no**: no free cross-country non-IMF series; Team A lists per-country national sources under EQ-A-0106 |
| Usable share | national net-reserves figure (after swaps and pledges) | no; desk shares below 1 for PAK 0.9, ARG 0.5, VEN 0.8, NGA 0.7 |

**Rule, per country.** Point in time: a WDI year y is used from 30 June y+1. Staleness: hold when the oldest input year
is more than 3 years before the as_of year.
1. ARA not applicable (reserve-currency issuers, `ara_applicable = no`: SGP, JPN): keep the analyst's value. It is a
   judgement, not IMF data. Team A moves the flag out of the restricted `dsa_inputs.csv`.
2. No national reserves or GDP series (currency-union members, such as Senegal in WAEMU): blank. The client
   placeholder stays.
3. Any input missing: hold, naming it. **Dropping other liabilities is rejected.** On the desk inputs its term is 6%
   to 51% of the metric (median about 30%). Leaving it out would double some ratios: Colombia 149 -> 303,
   Nigeria 156 -> 277. Broad money is 8% to 77% of the metric and cannot be dropped either.
4. Reserves encumbered (the desk applies a usable share below 1): hold until a national net-reserves figure exists.
   A share of 1 would overstate adequacy.
5. Otherwise: usable reserves / ARA x 100.

**Today.** No client cell can be filled. Broad money and other liabilities are missing for all 18 desk names, so 16 are
held, Senegal is blank and SGP and JPN keep their values. Client 2.1 stays at the placeholder until the broad-money pull
lands and Team A has national IIP figures.

**Effect estimate (INTERNAL).** 20k paths, as_of 2026-10-23, against the 0.6.0 base. Broad money, other liabilities
and usable shares are taken from `dsa_inputs.csv` as stand-ins, so this measures what the World Bank reserves, GDP,
exports and short-term debt change on the desk. It is not a client run. 12 desk cells would get a value:

| Country | Desk 2.1 | Rule value | Score seed -> new |
|---|---|---|---|
| Vietnam | 82.1 | 77.7 | 67.9 -> 72.3 |
| Philippines | 160.0 | 256.2 | 0 -> 0 |
| China | 84.9 | 86.0 | 65.1 -> 64.0 |
| India | 166.4 | 163.8 | 0 -> 0 |
| Pakistan | 40.0 | 106.8 | 100 -> 43.2 |
| Belize | 60.0 | 108.9 | 90 -> 41.1 |
| Brazil | 149.6 | 147.0 | 0.4 -> 3.0 |
| Argentina | 44.3 | 44.7 | 100 -> 100 |
| Colombia | 143.1 | 148.8 | 6.9 -> 1.2 |
| Zambia | 70.0 | 166.7 | 80 -> 0 |
| Zimbabwe | 15.5 | 18.4 | 100 -> 100 |

Malaysia, South Korea and Venezuela are held for short-term debt, and Nigeria is held because its exports are stale.

Portfolio (released cells): VaR99 66.954 -> 66.796, ES99 88.964 -> 88.756, EL 4.081 -> 4.010, L-VaR99 72.236 ->
72.077. PD moves: Zambia 4.53% -> 4.04% (grade 6 -> 5), Pakistan 8.04% -> 7.64%, Belize 4.86% -> 4.71%, Vietnam
+0.004 pp, Colombia -0.006 pp, China -0.0003 pp.

The large cell moves (Pakistan, Belize, Zambia) come from the desk 2.1 values, which do not follow the desk's own
formula. With the same desk inputs the formula gives Pakistan 107 against a desk value of 40, and Zambia 167
against 70. That is a desk-data question, not a source question. It goes to the desk review with this rule.

**Status.** For the desk, replacing 2.1 values is a Tier 1 change. It is **parked**: decision pack only, no card,
and not applied. For client output, the rule replaces a placeholder and moves no desk number. It still waits for
the two missing inputs.

## 18. 1.5 foreign-currency share of government debt from IDS PPG / WEO (HO-20261025-A-B-008, EQ-B-0104): approved with changes

1.5 is "foreign-currency share of government debt" (% of debt; scored 20 -> 0, 35 -> 25, 50 -> 50, 65 -> 75, 80 -> 100;
weight 0.1 in pillar 1, 0.025 of the composite). OECD and Eurostat serve none of the 18 desk names. Team A's proxy
(`ingestion/official/ids_fc_debt.py`, EQ-A-0096):

    1.5 = DT.DOD.DPPG.CD (IDS PPG external debt stock, US$, World counterpart)
          / (WEO GGXWDG_NGDP / 100 x NGDPD x 1e9) x 100, same year Y = latest year <= as_of with both

It serves the 13 IDS names: VNM PHL CHN IND PAK BLZ BRA ARG COL NGA SEN ZMB ZWE. MYS, SGP, JPN, KOR and VEN stay
manual.

**Decision: approve with changes.**

1. **Formula, pairing and staleness as built.** Same year for both terms. Y is the last actual IDS year, and WEO
   projection years are never paired with it. Held when Y is more than 3 years before the as_of year (the World Bank
   rule of `official.gate`).
2. **Range hold as built.** A ratio below 0 or above 100 is held, never capped. A value above 100 means the two
   sources disagree on coverage, and a cap would hide that.
3. **New: seed-divergence hold.** On the first value for a name, the cell is held for Team B review when it differs
   from the current value in `indicators.csv` by more than 20 points. Reason: "1.5 proxy vs seed". The proxy
   measures external debt, not foreign-currency debt:
   - it overstates the FC share where non-residents hold much local-currency government debt;
   - it understates it where residents hold much FX government debt (dollarised economies).
   A 20-point gap moves the indicator score by about 33 points, so it should be read before it moves PDs. After
   review, Team B either clears the hold or lists the name below as "not used".
4. **Names where it is not used:** none yet. Decided after the first values under 3.
5. **Denominator:** WEO general-government gross debt, as built. Central-government debt is not in any feed we
   hold.
6. **Client output:** restricted, as built (the value carries a WEO input: `imf_derived`).
7. **Note text:** each cell says "proxy: IDS PPG external / WEO GG debt, year Y; external, not foreign-currency".

**Effect on the desk values today: none.** DT.DOD.DPPG.CD is UNVERIFIED: no uploaded pull has it. So every cell
would be held by `unverified`, and no seed changes. The effect cannot be computed from data yet. What a change
would do, at as_of 2026-10-23, 20,000 paths, on a scratch copy of `data/`, 1.5 moved for all 13 IDS names at once:

| 1.5 on the 13 IDS names | VaR99 | ES99 | EL | L-VaR99 |
|---|---|---|---|---|
| base (0.6.0 seeds) | 66.95 | 88.96 | 4.081 | 72.24 |
| seeds - 10 points | 65.22 (-1.73) | 87.17 (-1.80) | 3.797 (-0.284) | 70.51 (-1.73) |
| seeds + 10 points | 67.21 (+0.26) | 89.18 (+0.21) | 4.134 (+0.053) | 72.49 (+0.26) |

Default PDs move the same way up and down, by up to 0.16 percentage points per 10 points of 1.5:

| Name | Senegal | Pakistan | Argentina | Zambia | Nigeria | Belize | Colombia | others |
|---|---|---|---|---|---|---|---|---|
| PD change per 10 points (pp) | 0.16 | 0.13 | 0.11 | 0.09 | 0.06 | 0.06 | 0.02 | 0.01 or less |

The loss figures are not symmetric while the PDs are. So most of the downside move comes through severity and the
stress-path FX revaluation (1.5 also drives layer 4, `dsa.py` and the stress paths), not through PDs.

Current seeds and their scores, which are the values the proxy would replace:

| | VNM | PHL | CHN | IND | PAK | BLZ | BRA | ARG | COL | NGA | SEN | ZMB | ZWE |
|---|---|---|---|---|---|---|---|---|---|---|---|---|---|
| seed (%) | 35.0 | 31.0 | 2.0 | 5.0 | 38.0 | 63.8 | 4.0 | 60.0 | 35.0 | 45.0 | 70.0 | 60.0 | 80.0 |
| score | 25.0 | 18.3 | 0 | 0 | 30.0 | 73.0 | 0 | 66.7 | 25.0 | 41.7 | 83.3 | 66.7 | 100 |

**Tier.** Approving the method is Team B's decision (this section): Team A adds "1.5" to
`ids_fc_debt.METHOD_APPROVED` and the seed-divergence hold under its ticket. The first values that replace seeds
move desk PDs and the base, so they are a **parked Tier 1 data batch**. Team A runs them through the quality gate.
Team B adds the real effect table (this table's layout, with the actual values) to a parked decision pack. The batch
goes on the when-Sam-is-ready list through the lead. Nothing changes before then.

## 19. 6.1 armed conflict and 6.9 floor from UCDP monthly rows (HO-20261025-A-B-013 (a), EQ-B-0119)

Input: UCDP monthly rows (`events.base.EVENT_COLUMNS`, metrics `fatalities_*` and `events_*`). They come from the
API adapter or from Team A's token-free GED CSV adapter (`research/ucdp_ged.py`); both give the same rows. Coded in
`validation/research_effect.rule_cells(..., events=...)`. Without `events` no 6.1 or 6.9 cell is produced.

Point in time, for both indicators:
- Only months that ended on or before as_of are used.
- When rows carry `retrieved_utc`, only rows retrieved on or before as_of are used.
- If a month has several vintages, the latest one retrieved by as_of wins.
- The window ends at the last complete month before as_of, or at the last month UCDP covers if that is earlier.
- Every month in the window must be covered; otherwise the cell is blank. Inside its coverage UCDP zero-fills
  months with no fatal event.

### 19.1 6.1 level rule

Rulebook: "0 none | 1 <25 battle deaths | 2 25-999 | 3 1,000+ contained to a region | 4 1,000+ and spreading, or
territory lost".

- **Battle deaths:** UCDP best-estimate fatalities of state-based (type 1) and non-state (type 2) violence on the
  territory, `fatalities_state_based + fatalities_non_state`, summed over the 12-month window.
- **Excluded:** one-sided violence (type 3, violence against civilians). It is not combat between armed parties,
  and 6.9 counts it through UCDP's total event count.
- **Why non-state counts:** the indicator is armed conflict on the national territory, whoever fights.
  Cartel, militia and communal conflicts (Colombia, Nigeria, Mexico-type cases) are UCDP non-state conflicts with
  battle-type deaths.

| Battle deaths in 12 months | Level | Status |
|---|---|---|
| 0 | 0 | mechanical |
| 1-24 | 1 | mechanical |
| 25-999 | 2 | mechanical |
| 1,000 or more | 3 | **held**: the analyst confirms 3 (contained to a region) or sets 4 |

**Level 4 is never set mechanically.** "Spreading or territory lost" needs a judgement on geography and control
that monthly national counts cannot make. The analyst sets 4 through `data/adjustments.csv` with a reason, as for
4.4's "military government". Level 3 is written as the candidate and held, so a 1,000+ country is never released
without that review.

**Staleness:** hold when the window's last month ended more than **183 days** before as_of, the 6.12 limit. The
annual GED file ends in December, so on its own it goes stale from early July; the Candidate monthly file keeps
6.1 live. 183 days rather than 6.9's 92, because the 6.1 bands are wide (25 to 999 is one level) and a level rarely
moves within a quarter.

### 19.2 6.9: section 7 wins (floor 5 events a year, cap 10)

Team A's candidate code (`events/indicators.py`) floors the base at 1 event a year. That is replaced by section 7:
- N12 = events in the 12 months to the window end;
- B = events per year over the 60 months before them;
- B >= 5: N12 / B;
- B < 5 and N12 < 5: 0.8;
- B < 5 and N12 >= 5: N12 / 5;
- the result is capped at 10.

Why: with a floor of 1, a country going from 0 or 1 events a year to 3 scores a ratio of 3.0, the top of the 6.9
scale. That is noise in small counts, not a trend. Below 5 events a year the ratio is not material, which is the
section 7 reasoning.

Staleness: 92 days, as section 7. UCDP stays labelled a PROXY for ACLED (organised violence only).

Team A aligns `events/indicators.py` (Team A file; not edited here).

### 19.3 Effect

Not computable today. The shared folder has no UCDP rows: no event vintage, no GED CSV and no Candidate CSV. Run
`research_effect` with the rows once the GED CSV lands on the Mac pass.

What to expect from the desk seeds:
- 6.1 seeds are 0 to 3. Pakistan and Nigeria (3) would be held at the 1,000+ review. The Philippines, India and
  Colombia (2) need 25-999 deaths in the window to stay at 2.
- 6.9 seeds are 0.8 to 1.5.

First values that change seeds are a **parked D-item**. Proposed wording for first-mac-pass.md section B, for the
lead to add: "6.1 and 6.9 first values from UCDP (indicator-rules 19): approve the batch with its effect table
(Tier 1 data batch)".

## 20. QEDS proxy for 2.9 and 2.10 on MYS, SGP, JPN, KOR (HO-20261025-A-B-013 (b), EQ-B-0119): approved with changes

Team A's `official/qeds.py`. 2.9 and 2.10 come from IDS for the other 14 desk names. IDS covers low- and
middle-income economies only.

**2.9: approved as built.** Short-term gross external debt (QEDS, all sectors, Q4 of year Y) / WDI FI.RES.TOTL.CD
(Y) x 100. IDS DT.DOD.DSTC.IR.ZS has the same numerator (short-term by original maturity) and the same denominator
(total reserves including gold), so the four names sit on the IDS basis. QEDS is residence-based and IDS is a
debtor reporting system, so the two are close, not equal; the provenance says so.

**2.10: changed. Use the IDS denominator.**
- IDS DT.DOD.DECT.EX.ZS divides by exports of goods, services **and primary income**. The rulebook's short label
  says "exports of goods and services", but its api column names DT.DOD.DECT.EX.ZS, and the 14 IDS names are
  scored on that basis.
- Primary income is large for these four (Japan especially). Goods and services alone would put them on a
  different, higher basis than the other names.
- Rule: QEDS gross external debt Q4(Y) / WDI BX.GSR.TOTL.CD (Y) x 100. BX.GSR.TOTL.CD is exports of goods,
  services and primary income, BoP, US$; it is the IDS denominator.
- BX.GSR.TOTL.CD is not in any pull: add it to the Mac probe list (code UNVERIFIED). Without it the cell is held,
  with no goods-and-services fallback.

**Changed: which names.**
- Apply the proxy to **Malaysia and South Korea**.
- **Hold Singapore and Japan** for the analyst. Their seeds stay:
  - Singapore is a financial centre. Its gross external debt is mostly bank liabilities matched by external
    assets, so gross debt over reserves or exports measures the banking system, not sovereign transfer risk. It
    would score 100 on both.
  - Japan's external debt is mainly in its own reserve currency.
  - Section 17 already treats both as cases where reserve adequacy does not apply. The same reasoning holds here.
- Year Y, the Q4 stock pairing and 3-year staleness: approved as built.

**Licence:** QEDS counts as IMF-upstream (restricted for client output) until AGENT-09 or Sam rules. That is
first-mac-pass D4.

**Approval path:** adding "2.9" and "2.10" to `qeds.METHOD_APPROVED` is a Tier 1 change. It is not applied here.

**Effect:** not computable. No QEDS rows and no BX.GSR.TOTL.CD are in the shared data. Seeds today:
- 2.9: Malaysia 90, South Korea 35 (Singapore 50 and Japan 30 stay);
- 2.10: Malaysia 110, South Korea 60.

First values that change seeds are a **parked D-item**. Proposed wording for first-mac-pass.md section B: "2.9 and
2.10 first values for Malaysia and South Korea from QEDS (indicator-rules 20), with the effect table; needs D4 for
client use".

## 21. QEDS proxy for 2.2 and the COW neighbour list for 6.12 (HO-20261025-A-B-017, EQ-B-0128)

### 21.1 2.2 on Malaysia and South Korea: approved with changes

Team A's `official/qeds.py`, key "2.2":

2.2 = (-WDI BN.CAB.XOKA.GD.ZS / 100 x NY.GDP.MKTP.CD + QEDS short-term debt by remaining maturity, Q4 of Y)
/ WDI FI.RES.TOTL.CD (Y) x 100.

**Approved: the formula.**
- Section 14 builds 2.2 for IDS names as (-CA + short-term debt DSTC + PPG and PNG amortisation) / reserves.
- Debt by remaining maturity is short-term debt by original maturity plus long-term debt due within 12 months. It
  already holds the amortisation terms, so adding them would count them twice. No separate term is right.
- The section 14 terms use principal paid in year t. Remaining maturity uses debt due in the next 12 months. Both
  measure debt that falls due within a year. The two are close, not equal; the provenance says "proxy".
- A current-account surplus makes -CA negative, and the value can fall below 0. Section 14 does the same, and a
  low value scores 100. RANGE (-500, 2000) covers it.
- Same denominator as section 14 (FI.RES.TOTL.CD, total reserves including gold). Same year Y for every term.

**Changed: which names.** As section 20, apply it to **Malaysia and South Korea** only. **Hold Singapore and
Japan** for the analyst; their seeds stay. Singapore's gross short-term debt is mostly bank liabilities matched by
assets. Japan's debt is mainly in its own reserve currency. `QEDS_ISOS` and `ANALYST_HELD` already do this.

**Changed: no fallback.**
- If QEDS has no all-sectors remaining-maturity value for Q4 of Y, hold the cell. Do not use short-term debt by
  original maturity instead: it leaves out long-term debt due within a year, so the need would read smaller.
- The QEDS code (`DT.DOD.DECT.CD.SR.US`) is a placeholder. The Mac probe must confirm it before any value counts.

**Licence.** BN.CAB.XOKA.GD.ZS and FI.RES.TOTL.CD are IMF-compiled series in WDI (Sam decision D3). QEDS is
first-mac-pass D4. Internal use is fine. A 2.2 value from this route may reach client output only when D3 is "yes"
and D4 clears QEDS. Until then the client-safe plan withholds it.

**Approval path:** adding "2.2" to `qeds.METHOD_APPROVED` is a Tier 1 change. It is not applied here.

**Effect:** not computable. The shared data has no QEDS rows. Seeds today: Malaysia 60, South Korea 40 (Singapore 5
and Japan 5 stay). First values are a **parked D-item**. Proposed wording for first-mac-pass.md section B: "2.2 first
values for Malaysia and South Korea from QEDS (indicator-rules 21), with the effect table; needs D3 and D4 for client
use".

### 21.2 COW neighbour list for 6.12: approved with two changes

Team A's `research/cow_contiguity.py` builds `data/panel/neighbours.csv`. Checked against section 4.

**Approved as built:**
- COW Direct Contiguity, latest year in the file, `conttype` 1 to 5. The closest contiguity type is kept per pair.
- Unions: only the ten unions section 4 names are accepted. Membership comes only from an operator `unions.csv`
  with a source on every row. Nothing is invented.
- The list is symmetric whatever the file holds. Self-pairs are dropped.
- COW codes go to ISO3 through the state name, never from memory. The step is off by default (`build --write`).

**Change 1: a dropped neighbour must hold, not lower, the cell.**
- Today a COW code or state name the ISO helpers do not know is dropped, and only the notes say so.
- A missing neighbour can only lower 6.12. That is not conservative.
- Rule: if a dropped code is contiguous with a desk name in the year used, that desk name's 6.12 is held with reason
  "neighbour unmapped: <code>". The builder must name the desk names affected, not only the codes.
- Names to check on the probe: Taiwan, North Korea, Myanmar, Laos, Timor-Leste ("East Timor" in COW), Serbia
  ("Yugoslavia", code 345).

**Change 2: tell "no neighbours" from "not in the file".**
- Section 4 says a country with no neighbours scores 0 on the conflict parts. With no row, the rule cannot tell an
  island with no neighbours from a country missing from COW.
- Rule: the builder writes one row `iso3, "", "none", source` for each mapped state with no neighbour. A desk name
  with no row at all is held with reason "not in neighbour list".

**Licence:** COW data are free with citation; terms UNVERIFIED (Sam). 6.12 stays NOT_COMPUTED in `rule_cells`
until the UCDP inputs and this list exist. Effect: not computable; no list in the shared data.

## 22. Sovereign depth views: ARA, gross financing need, maturity wall, IMF programme probability (EQ-B-0136, PI-13)

Owner: Team B (AGENT-03). Date: 2026-10-26. Status: research views, **display only**. Nothing in this section fills a
scorecard cell, moves a PD or feeds the Monte Carlo. The base run reads no part of it: base 20k 66.95612571109443 /
89.00003057231508 / 4.098636048964449 / 72.23763153780678 before and after; replication PASS 141. Code:
`econquest/rules/sovereign.py` (pure rules), `econquest/validation/depth_views.py` (rows for Team C's M19 page and the
C-0156 heatmap; the macro views of section 23 plug in through `validation.macro_depth.depth_rows`). Tests:
`tests/test_rules_sovereign.py`, `tests/test_depth_views.py`.

**Rows (schema `eq-depth-views/1`).** One dict per country x view x metric x year, with the columns `country, iso,
view, metric, year, value, unit, as_of, source, licence_class, status, route, note`:
- `year` is None for a point value.
- `value` is None unless `status` is `value`.
- `status` is one of:
  - `value`;
  - `hold`: an input is present but unusable or missing, and the note says which;
  - `not_available`: there is nothing in the shared folder;
  - `refused`: a rule refuses the input.
- `licence_class` is the most restrictive C14 `client_output` class of the inputs read. A file with no register row
  counts as `restricted`.
- `route` names the method. Every IMF-sourced route says "EXC-003 ... INTERNAL".

Entry points:
- `depth_views(data_dir, as_of)` returns the rows.
- `demo_depth_views(out_dir)` writes `depth_views.csv`, `depth_views.json` (with meta and backtests) and
  `programme_backtest_proxy.csv` under `<out_dir>/depth_views/`, and returns `{ok, problems, paths, ...}`.
- `python -m econquest.validation.depth_views --as-of D --out DIR` does the same from the command line.

**Point in time.**
- WEO and World Bank files come from the latest `data/live/vintages/<date>` folder dated on or before `as_of`.
- Team A's Mac pull-pack files are used only when their own retrieved date (`state.json` or `report.md`) is on or
  before `as_of`:
  - the universe pull `team/inbox/pull-20261025T013150Z/raw_worldbank.csv` (88 names);
  - the panel history `team/inbox/pull-20261025T121034Z/worldbank_history.csv`.
- Each World Bank series of a country is taken from one file only: the pull-pack file first, then the vintage. This
  way, per-creditor rows and World totals are never mixed.
- A WDI year y counts from 30 June y+1. It is stale (treated as missing) when it is more than 3 years before the
  `as_of` year.
- **Ungated research pulls (HO-20261026-B-B-011, lead decision).** The two `team/inbox` files have not been through
  Team A's ingestion quality gate. Every row whose `source` cites one of them gets the route label "research pull, not
  through the quality gate" and is `licence_class` `restricted`, whatever the register class of the series. So none of
  them can reach client output (`depth_views.gate_ungated`, tested). At 2026-10-26 this covers about 3,100 rows: the
  maturity wall, the programme model and the non-IMF ARA. The desk ARA reads reserves from the `data/live` vintage
  only.
- At the base `as_of` 2026-10-23 both pull-pack files are later than `as_of` and are not read. The demo uses
  `DEMO_AS_OF` 2026-10-26.

### 22.1 Reserve adequacy, IMF ARA (view `reserve_adequacy`)

Formula: the ARA metric of `engine.dsa` (weights in `rules.sovereign.ARA_WEIGHTS`, pinned equal to
`engine.dsa.ARA_WEIGHTS`).
- Fixed regimes: 0.30 short-term debt + 0.20 other liabilities + 0.10 broad money + 0.10 exports.
- Floating regimes: 0.30 / 0.15 / 0.05 / 0.05.
- Managed regimes: the average of the two.
- Usable reserves / ARA x 100. Band: below (< 100), adequate (100-150), ample (> 150), the IMF ARA guidance.

Two routes, shown side by side:
1. **Desk route (INTERNAL, EXC-003).** `dsa_inputs.csv` gives short-term debt, broad money, other liabilities and the
   usable share. These are estimates from IMF Article IV. They are combined with WDI reserves (the latest year in the
   vintage, as the desk), WEO NGDPD for the base year and the profile exports. This reproduces
   `engine.dsa.dsa_table` `reserves_pct_ara` to 1e-12 (test).
   - Metrics: `reserves_pct_ara`, `ara_metric_usd_bn`, `usable_reserves_usd_bn`, `score_2_1` (rulebook 2.1
     thresholds, display only), `share_<term>` (each term's share of the metric).
   - `desk_value_2_1` is the value the engine scores, shown for comparison.
   - SGP and JPN (`ara_applicable = no`) are `not_available`: 2.1 is the analyst's judgement value for them.
2. **Non-IMF route (section 17, `validation.nonimf_ara.ara_wb_cells`).** Metric `reserves_pct_ara_nonimf` for the desk
   and the wider universe. Today every cell is `hold`: broad money and other liabilities are in no pull. Senegal and
   other currency-union members are `not_available`.

The wider universe (70 names in `panel/universe_staging/countries.csv`) has no `dsa_inputs.csv` row and no WEO pull,
so the desk route is `not_available` for those names.

Today (desk route): the formula and the desk 2.1 values differ for PHL (258 vs 160), PAK (106 vs 40), BLZ (93 vs 60),
NGA (155 vs 90) and ZMB (163 vs 70). This is the desk-data question already raised in section 17. The other names
match.

### 22.2 Gross financing need by year (view `gross_financing_need`)

GFN_t = overall deficit_t + amortisation_t, in % of GDP, general government:
- the overall deficit is -GGXCNL_NGDP;
- the primary deficit (-GGXONLB_NGDP) and interest (primary minus overall balance) are shown as well;
- amortisation_t = debt_{t-1} (GGXWDG_NGDP) / average maturity. The maturity comes from `dsa_inputs.csv`, or is 7
  years when a name has no row (as `dsa_table`).

This amortisation is a modelled flat profile for all public debt (domestic and external), not a schedule.

The view covers the years base year .. base year + 5. Years from the `as_of` year on are labelled "WEO projection".
- Point metrics:
  - `gfn_next_year_pct_gdp`: equal to `dsa_table` `gfn_pct_gdp`, the scorecard 1.4 basis (test);
  - `score_1_4`: rulebook 1.4 thresholds 5/10/15/20/25;
  - `gfn_peak_pct_gdp`, with the peak year.
- Senegal has no WEO projection after 2025. Its next-year value uses the 2025 balance, as `dsa_table` does, and the
  note says so. Its by-year rows after 2025 are `hold`.
- Licence: WEO and `dsa_inputs.csv`, so `restricted` (INTERNAL).
- The wider universe is `not_available`: there is no WEO pull for those names.

### 22.3 Maturity wall and refinancing risk (view `maturity_wall`)

**External PPG wall.** World Bank IDS projections, by year from the `as_of` year to `as_of` + 6:
- principal DT.AMT.DPPG.CD and debt service DT.TDS.DPPG.CD;
- `principal_usd_bn`, `principal_pct_gdp`, `principal_pct_reserves` and `debt_service_pct_reserves`, against the
  latest point-in-time WDI GDP and reserves, held flat ("% of latest");
- `refinancing_level` 0-3 from annual debt service % of reserves: < 12.5 low, 12.5-25 moderate, 25-50 high, >= 50
  very high. These are judgement bands at the per-year pace of the 1.2 thresholds (10/25/50/75/100 over 24 months);
- `wall_peak_principal_pct_reserves`, with the peak year;
- `debt_service_24m_pct_reserves` from `rules.dsa.ppg_debt_service_detail`, the 1.2 rule; the note carries the 1.2
  score.

**Refusal rule (C15).** A year with more than one row and no counterpart column is per-creditor data, and the series
is `refused`. Summing the rows could double count. This is the case for DT.TDS.DPPG.CD in `data/live` (13 names,
about 6 rows per year).

**Results.**
- At `as_of` 2026-10-23: no wall value. The IDS principal schedule exists only in the 2026-10-25 universe pull.
- At 2026-10-26: 60 names have a wall. The desk names with one are VNM, PHL, CHN, IND, PAK, BLZ, BRA, ARG, COL, NGA,
  ZMB and ZWE.
  - Peak principal (% of reserves): ZWE 83.5 (2027), PAK 30.9 (2027), ZMB 29.1 (2027), BLZ 21.2 (2032).
  - 24-month debt service (% of reserves): ZWE 182, ZMB 74, PAK 66, BLZ 49.
  - Senegal is `hold`: it has no national reserves series (WAEMU).
  - MYS, SGP, JPN, KOR and VEN are `not_available`: they are not IDS reporters.

**Eurobond schedule: not available.** The shared folder has no bond-level maturity data (prospectus or vendor data,
D5). Every desk name carries a `eurobond_schedule` row with status `not_available`. The IDS wall is all external PPG
debt, of which Eurobonds are a part.

### 22.4 IMF programme probability, research model `imfprog_v1` (view `imf_programme`)

This is a transparent scored rule mapped to a probability by a **fixed logistic**. Nothing is fitted: the shared data
holds no programme-episode file. It is labelled `research model` on every row.

| Component | Input (public unless marked) | Points |
|---|---|---|
| `reserve_cover_months` | WDI FI.RES.TOTL.MO, reserves in months of imports | < 3: 2; 3-6: 1; >= 6: 0 |
| `st_debt_pct_reserves` | WDI DT.DOD.DSTC.IR.ZS | < 50: 0; 50-100: 1; >= 100: 2 |
| `ext_debt_service_pct_reserves` | IDS DT.TDS.DPPG.CD, first projection year in `as_of`..`as_of`+1, % of WDI reserves | < 10: 0; 10-25: 1; 25-50: 2; >= 50: 3 |
| `ext_debt_pct_exports` | IDS DT.DOD.DECT.EX.ZS | < 100: 0; 100-200: 1; >= 200: 2 |
| `default_record` | CRAG crag_v1 episodes (`hazard_events.build_events`) | 3 in default in the last data year; 2 ended within 5 years; 1 within 15; else 0 |
| `rating_notch` (desk, internal) | `countries.csv` rating | BBB- or better 0; BB 1; B 2; CCC+ or below / SD / D 3 |
| `spread_bp` (desk, internal) | `countries.csv` spread | < 400: 0; 400-700: 1; 700-1000: 2; >= 1000: 3 |

**Probability.** p = 1 / (1 + exp(-(-3.5 + 0.6 x 10 x points / max points))), over the next 12 months.
- Missing components drop out of the points and of the maximum.
- `p_programme_12m` uses the five public components (maximum 12) and needs at least 3 of them; otherwise it is
  `hold`.
- `p_programme_12m_desk` adds rating and spread (maximum 18), needs at least 4 components, and is `restricted`.
- The anchors are a priori: 0 points gives about 3%, half the points about 38%, all points about 92%.
- The component directions follow the literature on the determinants of IMF arrangements:
  - Knight and Santaella (1997) and Joyce (1992): reserve cover, external debt and debt service;
  - Conway (1994): prior participation and market access;
  - Reinhart and Rogoff (2009): default history.
- The cut-offs are conventional thresholds: 3 months of import cover; Greenspan-Guidotti for short-term debt against
  reserves; the order of magnitude of the IMF-WB LIC DSF thresholds for debt to exports; 1,000 bp distress spreads;
  sub-investment-grade ratings.
- These are not coefficients taken from a paper. The papers were not available offline, so the citations support the
  direction of each effect only. Each row also lists every input and its points (`input_<c>`, `points_<c>`).

**Today (`as_of` 2026-10-26).**

| Name | Public p | Desk p | 2.6 level (analyst, comparator) |
|---|---|---|---|
| Zimbabwe | 0.88 | 0.90 | 3 |
| Argentina | 0.73 | 0.62 | 3 |
| Zambia | 0.62 | 0.62 | 1 |
| Pakistan | 0.38 | 0.38 | 3 |
| Belize | 0.18 | 0.24 | 2 |
| Nigeria | 0.12 | 0.18 | 2 |
| Colombia | 0.12 | 0.10 | 2 |
| Vietnam | 0.08 | 0.08 | 2 |
| Brazil, Philippines | 0.05 | 0.06, 0.04 | 2 |
| China, India | 0.03 | 0.03 | 0, 1 |
| Senegal | hold | 0.70 | 4 |
| Malaysia | hold | 0.05 | 2 |
| SGP, JPN, KOR, VEN | hold | hold | 0, 0, 1, 4 |

**Concordance with 2.6.** Rank correlation with the analyst's 2.6 backstop level: 0.68 for the public model (12 names)
and 0.70 for the desk model (14 names). This is a sanity check, not a backtest: 2.6 is judgement and is not an input.
Zambia scores high while 2.6 is 1 (programme on track), as expected for a country inside a programme. The model gives
the probability of being under an arrangement, which includes continuing ones.

**Backtest.**
- **On programme episodes: not available.** The shared data has no IMF programme history. The schema is ready:
  `data/panel/imf_programmes.csv` with columns `iso,start,facility,source`, from the MONA / lending-arrangements
  history. `rules.sovereign.programme_backtest` scores it once the file exists (Brier, rank AUC, hit and false-alarm
  rates at 0.5).
- **Proxy backtest (labelled proxy).**
  - Method: a point-in-time replay on 1 January of each year 2016-2025, using the public components that have
    history (import cover, short-term debt % reserves, external debt % exports, default record). The IDS
    debt-service projection has no history and is left out.
  - Target: **new CRAG default starts, not programme approvals.** Country-years already in default are dropped.
  - Result at `as_of` 2026-10-26: 232 country-years, 52 names, 8 starts (base rate 3.4%); rank AUC 0.85, Brier 0.056;
    hit rate at p >= 0.5 1/8, false alarms 0.9%.
  - At the base `as_of` the panel has 31 country-years and no start, so AUC is not defined.
  - Caveats: the World Bank values are as revised in the 2026 pull, not as first published; the sample is small.

### 22.5 Licence

| Rows | licence_class today | Why |
|---|---|---|
| Desk ARA, GFN | restricted (INTERNAL) | WEO and `dsa_inputs.csv` (EXC-003) |
| Non-IMF ARA, maturity wall, public programme model | allowed from a `data/live` vintage; **restricted** when a row reads a `team/inbox` research pull (every such row today, B-B-011) | World Bank WDI/IDS and CRAG register rows. FI.RES.TOTL.CD, FI.RES.TOTL.MO and DT.DOD.DSTC.IR.ZS are IMF-compiled WDI series (D3): the class follows the register, so Sam's D3 "no" turns these rows restricted with no code change |
| Desk programme model, `eurobond_schedule`, `desk_value_2_1`, `analyst_backstop_2_6` | restricted | `countries.csv` / `indicators.csv` have no register row; ratings are agency data |

### 22.6 Gaps (for the lead and Sam; nothing fetched)

1. No IMF programme episode file. It is needed for a real backtest and for a fitted model. Proposed source: IMF MONA /
   lending arrangements history (IMF licence, internal).
2. No Eurobond-level maturity schedule (bond prospectuses or vendor data, D5).
3. The IDS World-total debt service and principal schedule exist only in Team A's 2026-10-25 universe pull, not in
   `data/live`. Its DT.TDS.DPPG.CD is per creditor with no counterpart column (EQ-A-0062 fix), so 1.2 and the wall stay
   refused at the base `as_of`.
4. Broad money (FM.LBL.BMNY.GD.ZS) and national IIP other liabilities are missing, so the non-IMF ARA is held
   everywhere (section 17).
5. No WEO pull for the 70 wider-universe names. GFN and the desk ARA cover only the 18 desk names.
6. FI.RES.TOTL.MO and DT.DOD.DSTC.IR.ZS come from the 2026-10-25 panel-history pull. They are not in a `data/live`
   vintage.

## 23. Macro depth views and the commodity terms-of-trade stress channel (EQ-B-0137, PI-13)

Owner: Team B (AGENT-05). Date: 2026-10-26. Status: research views, **display and research stress library only**. No rule
here fills a scorecard cell or moves the base: the base run reads no part of this section (base 20k 66.95612571109443
/ 89.00003057231508 / 4.098636048964449 / 72.23763153780678 before and after; replication PASS 141). Code:
`econquest/rules/macro.py` (pure rules), `econquest/validation/macro_depth.py` (M19 rows, plug-in of
`validation.depth_views`, schema eq-depth-views/1, section 22), `engine/stress.py` (`{"target": "tot"}`), scenario
`TOT_OIL` in the research stress library `engine.stress.RESEARCH_LIBRARY` (code, not `data/scenarios.json`). Tests: `tests/test_macro_depth.py`, `tests/test_tot_scenario.py`.

Common rules: point in time at `as_of` (BIS monthly data usable from month end + 20 days; WEO, World Bank and BIS
read from the latest `data/live/vintages/<date>` folder dated on or before `as_of`, else the live file when
`feeds.json` was retrieved on or before it). A missing input gives `hold` (input present but unusable) or
`not_available` (nothing in the shared folder); nothing is fetched. `licence_class` is the most restrictive C14
client_output class of the inputs (`ingestion.licences`): BIS and World Bank `allowed`; IMF WEO (EXC-003) and
theratesapi.com FX (EXC-005) `restricted`. Every row that reads WEO is INTERNAL and its route says so.

### 23.1 FX valuation (view `fx_valuation`)

**REER misalignment against own history.** Series: BIS real broad effective exchange rate (`EER_REAL_BROAD`,
monthly; PHL, CHN, MYS, SGP, JPN, KOR, IND, BRA, ARG, COL). Over the last 120 usable months (60 needed):

- `reer_gap_pct` = last / mean - 1, in % (the 2.12 BIS formula; + = stronger than its 10-year average);
- `reer_z` = (ln last - mean ln) / sd ln (ddof 1);
- `reer_index`, `reer_months`.

**Official-FX proxy (labelled PROXY).** Where the folder has no REER (VNM, PAK, BLZ, VEN, NGA, SEN, ZMB): monthly
mean of the official FX in `market_history/prices.csv` (complete usable months), inverted to USD per unit, times
domestic / US price levels. Domestic prices come from WEO `PCPIPCH` (annual, spread evenly over the months; the
series stops where a year is missing). US prices grow at a fixed 2.5% a year (judgement: there is no US CPI in the
folder). The index is rebased to 100 at the first month. The gap and z use the same formula over the available
months (24 needed; the price history starts 2023-10, so about 36). It is bilateral against the USD, not effective,
and it is restricted (EXC-005 FX for VND, PKR, BZD, VES, NGN, ZMW; WEO for all). The route of those rows, and of their BEER rows, names EXC-005 next to EXC-003 (HO-20261026-B-B-012). ZWE: no official FX column, so
`not_available`.

**Simple BEER (fixed specification, nothing fitted).** In deviations from the window mean, over the same years as the
REER window (10 for BIS names, 3 for the proxy):

    fitted_gap = 0.5 x gap_productivity + 0.1 x gap_nfa + 0.4 x gap_tot
    beer_misalignment_pct = reer_gap_pct - fitted_gap      (+ = overvalued against fundamentals)

| Term | Proxy in the shared folder | Elasticity (range in the literature) |
|---|---|---|
| productivity | running sum of real GDP growth (WEO `NGDP_RPCH`) minus population growth (WDI `SP.POP.TOTL` when both years are there, else WEO-implied NGDPD / NGDPDPC; a year with neither makes the term and the BEER `hold`, never 0%), relative to the panel median; last minus window mean, % | 0.5 (0.2-0.7, Balassa-Samuelson) |
| NFA | running sum of the current account (WEO `BCA_NGDPD`); last minus window mean, pp of GDP; no valuation effects | 0.1 (0.03-0.15) |
| terms of trade | commodity exporters only: `commgap` (main export price gap, %) x indicator 2.11 / 100; 0 for other exporters | 0.4 (0.2-0.6) |

All three inputs read WEO, so every BEER row is restricted. The elasticities are research values, labelled
`research model`. They are not estimates and are not a fair-value call.

### 23.2 Policy-rate path (view `policy_rate_path`)

- **Current rate and recent change**: BIS `POLICY_RATE` (daily). `policy_rate`, `change_3m_pp`, `change_12m_pp`, and
  in the note the date of the last change. When the last observation is more than 30 days before `as_of` (the BIS
  daily rule; ARG ends 2025-07-10), these rows are `hold`. Without a BIS series, the rate is taken from
  `countries.csv` `policy` (with its provenance), and the changes are `not_available`.
- **Taylor-type rule (research model, judgement parameters)**: i* = r* + pi + 0.5 (pi - pi*) + 0.5 gap.
  - pi is WEO `PCPIPCH` for the `as_of` year.
  - pi* comes from the desk table `rules.macro.INFLATION_TARGETS` (stated central-bank targets, band mid-points); the
    default is 3.0% (judgement) when there is no point target.
  - gap is a growth-gap proxy: WEO real growth in the `as_of` year minus its mean over the previous 10 years, leaving
    out 2020-21 (as 5.12).
  - r* is the own 10-year mean ex-post real policy rate (BIS annual mean minus WEO inflation, 5 years needed),
    clipped to [0.5, 5]; otherwise 1.5% (judgement).
- **Implied path**: partial adjustment from the current rate, i_q = 0.75 i_(q-1) + 0.25 i*, for q = 1..4
  (`path_q1..path_q4`). `taylor_gap_pp` = current - i*.
- **Not computed (`hold`)**:
  - SGP: exchange-rate-centred policy.
  - BLZ: USD peg.
  - SEN: WAEMU union rate.
  - ZWE: multi-currency economy.
  - Inflation above 100% (VEN).
  - No WEO inflation.
  - Too little growth history.
  - The path also needs a fresh current rate.

The path is a rule-implied reference, not a forecast of the central bank.

### 23.3 Commodity terms-of-trade shock channel (research stress library only; view `terms_of_trade`)

New shock target `{"target": "tot", "commodity": "oil", "price_change_pct": -35, "exposure": "7.10", "where": {...}}`.
`stress.apply_shocks` expands it, before the GPR and macro expansions, into ordinary per-country shocks at scale 1
(`where iso_in`). The severity scale then applies to them as to any add / mul shock. Scenario `TOT_OIL` (oil -35%)
is the only user. It is kind `research` and sits in `engine.stress.RESEARCH_LIBRARY` (same grammar as
`data/scenarios.json`, loaded by `stress.research_scenarios()`), not in `data/scenarios.json`. So the shared data, its
data hash, the release-input check (`replicate.data_drift`), and the frozen MVP stress and sign-off set (17 run + EMDEF_BRA)
stay as recorded. Runs that use it are fingerprinted by the code hash. `econquest stress` does not list it; moving it
into `data/scenarios.json` is a release decision (0.10.0). Exposure: indicator 7.10 (fuel share of exports, %) x `countries.csv` `exports` (% of GDP).
Default scope: `exptype` Commodity. The channel is one-sided: refiners and importers (MYS, SGP, IND, KOR) take no
gain and no loss.

| Step | Rule (L = ToT loss, % of GDP) | Parameter (judgement) |
|---|---|---|
| loss | L = min(10, abs(dP)/100 x exposure/100 x exports) | cap 10% of GDP |
| FX | fx3m += pass x 2.0 x L | pass: Float 1, Managed 0.5, Peg 0 |
| reserves | d = -min(50, phi x L / reserves % GDP x 100); res3m += d; 2.1 x= 1 + d/100 | phi: Float 0.25, Managed 0.5, Peg 0.75 |
| spread | spread += 40 x beta x L bp, beta = clip(spread / 300, 0.25, 2) | level beta as engine.macro_scenarios |

At scale 1:

| Name | L (% of GDP) | fx3m (pp) | res3m (%) | Spread (bp) |
|---|---|---|---|---|
| NGA | 4.5 | +8.9 | -7.1 | +238 |
| VEN | 4.7 | +4.7 | -50 (cap) | +375 |
| COL | 2.6 | +5.2 | -4.6 | +77 |
| SEN | 2.3 | 0 | -14.2 | +182 |
| BRA | 0.9 | +1.9 | -1.5 | +20 |
| ARG | 0.5 | +0.5 | -4.5 | +44 |
| ZWE | 0.3 | +0.3 | -16.7 | +25 |
| ZMB | 0.1 | +0.2 | -0.2 | +7 |

Book effect (20,000 requested paths, as_of 2026-10-23): VaR99 68.0, ES99 89.9, EL 3.84, L-VaR99 73.3 against the base
66.96 / 89.00 / 4.10 / 72.24. At scale 2: VaR99 80.8, ES99 105.9. EL falls slightly because the book is short NGN (P19)
and the expected FX drift of the short leg outweighs the higher PDs (NGA 4.0% -> 6.1%, COL 1.1% -> 1.4%). The 18
existing scenarios give bit-identical results before and after (5,000-path check), and so does the base. `data/scenarios.json` is byte-identical.

`terms_of_trade` rows: `exposure_pct`, `exports_pct_gdp`, `tot_loss_pct_gdp`, `d_fx3m_pct`, `d_res3m_pct`,
`res_factor_2_1`, `d_spread_bp` of TOT_OIL at scale 1, from the same function the stress engine uses
(`stress.tot_table`).

**Limitations:**
- Gross fuel exports, not net. Refiners are kept out by the scope rule, not by data.
- No import side, no fiscal channel, no second-round growth effect.
- The pass-through and spread coefficients are judgement anchored on the 2014-16 oil episode, not estimated.
- A broader commodity shock can use `"exposure": "2.11"` (largest commodity share) with its own `where`. Only oil is in
  the library.

## 24. Text stress index and early-warning signal (EQ-B-0135, PI-13, roadmap 3.5)

**Off (Tier 3 research view).** Nothing in the run path reads the index. The switch is `text_index.enabled` in
`assumptions.json`, and the key is absent, so it is off. Switch-on evidence: `docs/validation/text-stress-index.md`.
This new top-level `text_index` key is separate from the existing `probability.text_index` block, which configures
the EQ-B-0033 event stress index (engine/event_index.py, source "none") and is not read here.
Rules: `econquest/rules/text.py` (`tsi_lex_v1`, numpy only). Pipeline: `econquest/validation/text_index.py`, schema
`eq-text-index/1`. Corpus: Team A EQ-A-0131 (`corpus.documents`, HO-20261026-A-B-012).

1. **Documents.** Central bank and IMF texts for a desk name from `corpus.documents(iso, since, as_of=t,
   basis="knowledge")`. A document counts at date t only when it was published and retrieved by t, in the version the
   corpus held at t. The window covers the 90 calendar days ending on t (`since` = t - 89 days). An IMF release that
   names two desk names counts for both.
2. **Scoring (dictionary, no fitted or downloaded model).** Text is split into sentences (. ! ? ; or a line break)
   and then into lower-case words. A term is a word, a stem ending in `*` (prefix match) or a phrase. Phrases never
   cross a sentence end.
   - Tone: NEGATIVE (44 terms, for example pressure*, deteriorat*, vulnerab*, outflow*) and POSITIVE (29 terms, for
     example stable, resilien*, improv*, robust*). A negator (not, no, never, without, nor, neither) among the three
     words before a tone term in the same sentence flips its sign.
   - Topics, counted without negation: fiscal, external, banking, inflation, imf_programme, and distress (the severe
     topic: default*, restructur*, arrears, haircut*, capital control*, moratori*, debt treatment, and so on).
   - Per document: tone_net_pk = 1000 x (negative - positive) / words; severe_pk = 1000 x distress hits / words;
     doc stress = tone_net_pk + 2 x severe_pk.
   - Documents not scored: those under 50 words, and those in a language without a lexicon. Only English has one
     today; vi, pt, es and fr texts are listed in the row's note.
3. **Index.** stress_index(iso, t) is the equal-weight mean doc stress over the scored documents in the window. It
   needs at least 2 scored documents; otherwise status is `insufficient` (NaN). The topic rates are averaged the same
   way. Each value is computed at every month-end, plus the as_of date.
4. **Early-warning signal.** The history is the index values at the month-ends in the 36 months before t (never t
   itself), with at least 12 needed (otherwise `no_history`). Let sd be the history's standard deviation, floored at
   0.5. Then z = (level - mean) / sd and dz_3m = (level - level about 3 months earlier) / sd.
   - **warning**: z >= 2.0, or z >= 1.0 with dz_3m >= 1.5.
   - **watch**: z >= 1.0 or dz_3m >= 1.0.
   - **normal**: otherwise.
5. **Backtest** (`backtest(data_dir, as_of)`, basis knowledge).
   - Episodes: CRAG crag_v1 (`hazard_events.build_events`, source crag, min 10 USD m, cure 2 years), desk names only,
     as known at as_of.
   - Panel: one row per desk name and year Y. A row is at risk unless the name was in a spell in Y-1. Label 1 when an
     episode starts in Y or Y+1. The score is the highest month-end z in Y-1, all of which is known by 31 December
     Y-1.
   - Metrics: AUC (Mann-Whitney, ties one half); hit rate (a warning in the 24 months before 1 January of the start
     year, since CRAG dates are years); median lead in months; false-alarm rate (a warning in Y-1 on a label-0 row).
   - Bar (`SWITCH_ON_BAR`): at least 5 episodes, AUC >= 0.70, hit rate >= 0.60, median lead >= 3 months,
     false-alarm rate <= 0.25.
   - Status values: `not run: corpus empty` on today's empty corpus. `not run: no point-in-time history on the
     knowledge basis` when nothing was retrieved before the past dates, which is the case after a one-off archive
     pull. `run: below evidence bar (n events < 5)` when fewer than 5 episodes are scored.
   - `--basis published` replays the archive as first stored. It is labelled as secondary evidence and never passes
     the bar.
6. **Synthetic data.** `build_index`, `run` and `backtest` refuse a synthetic store. `allow_synthetic=True` raises
   outside pytest, except that `build_index` accepts the demo's own sandbox (marker file plus a private flag).
   `run` and `backtest` need an explicit as_of; nothing takes a date from the clock. The M17 demo (`demo_text_index(out_dir)`) builds a deterministic SYNTHETIC sandbox store
   under `out_dir/text_index/synthetic_corpus/`: ZMB stress ramps from 2018-07 to 2019-12, while NGA and SGP stay
   calm. The demo writes `text_index_SYNTHETIC.csv` and `.json`, both labelled SYNTHETIC. It never runs the backtest
   on the sandbox.
7. **Licence.** licence_class is the most restrictive data/licences.csv client_output among the documents' rows
   (`text_cb_<iso3>`, `text_imf`) and `text_corpus_store`. An unknown row counts as barred, and a row with no
   documents is restricted. client_ok needs allowed on all of them, client_ok on every document and a non-synthetic
   row. Today every row is restricted, and `client_safe_rows()` returns nothing.

Limits:

- English lexicon only.
- Equal document weights: a central bank release and an IMF page count the same.
- No translation.
- The lexicon is judgement, and no term weight is estimated.
- CRAG gives 4 desk-name episode starts in 2016-2026 (BLZ 2016, VEN 2016, ZMB 2020, BLZ 2021), below the 5-episode
  bar. Sam's choice is in the dossier, section 3.

## 25. Conflict escalation model and display-only GPR / PD link (EQ-B-0142, PI-14)

**Off (Tier 3 research view).** Nothing in the run path reads the model. The switch is `escalation.enabled` in
`assumptions.json`, and the key is absent, so it is off. Switch-on evidence: `docs/validation/conflict-escalation.md`.
Rules: `econquest/rules/escalation.py` (`esc_ladder_v1`, numpy and pandas only). Pipeline:
`econquest/validation/escalation.py`, schema `eq-escalation/1`. Data: Team A's unified event API (EQ-A-0139,
HO-20261026-A-B-015), monthly, `combine="by_source"`. Nothing in the method is estimated.

1. **Inputs, point in time.** At as_of the model reads only vintages saved by as_of (a date is the end of that UTC
   day) and periods starting by it. The anchor month is the last complete month at as_of (`rules.research.
   last_complete_month`). A series may end at most 2 months before the anchor month; an older one is not used.
   GDELT and UCDP are never added: each GDELT category is its own series, and UCDP fatalities are summed only within
   UCDP (armed_conflict plus violence_against_civilians).
2. **GDELT media z.** For each GDELT category (verbal_conflict, protest, coercion, armed_conflict,
   violence_against_civilians) and month: x = log1p(events per covered day x 30.4375). A month with days_covered below
   50% of its days is a partial month and is not scored. z = (x - mean) / max(sd, 0.25) over the 24 months before
   it, at least 12 of them scored; z is clipped to [-4, 4].
3. **Ladder.** The first rule that holds, top down:
   - 4 war: UCDP fatalities in the 12 months to the latest UCDP month (all 12 present) >= 1000.
   - 3 armed conflict: the same sum >= 25.
   - 2 violent unrest: a GDELT z >= 2 in coercion, armed_conflict or violence_against_civilians, or UCDP
     fatalities 1 to 24.
   - 1 tension: a GDELT z >= 2 in protest or verbal_conflict.
   - 0 calm: none of these on the rungs the data can see.
   `state_max_observable` is 4 with a 12-month UCDP window, 2 with GDELT category vintages, 1 with legacy GDELT only
   (protest and verbal_conflict) and 0 with nothing scored. Below 4 the state is a lower bound and the status is
   `partial`.
4. **Transitions.** A monthly 5 x 5 a priori matrix (`rules.escalation.BASE_P`; values and reasons in the dossier,
   section 3). For a country, every upward entry is multiplied by M = min(4, exp(0.30 x pressure) x trend):
   - pressure is the largest positive GDELT z among the categories at or above the current rung, capped at 4;
   - trend = sqrt(6.9 violence trend ratio) clipped to [0.75, 2.0], using `rules.research.violence_trend_ratio` on
     UCDP events (section 7). It is 1 without a full 72-month UCDP window or when 6.9 is stale.
   A row whose moves would pass 0.98 has its upward entries scaled back.
5. **Escalation probabilities.** p_up_3m and p_up_12m are the probabilities of being above the current state at some
   month in the next 3 or 12 months (first passage, with the states above absorbing). p_armed_12m is the same for
   state 3 or higher, blank at state 3 and above. p_up_12m_prior is p_up_12m on the unmodulated matrix (M = 1).
6. **Display-only GPR / PD link.**
   - expected_jump is the expected number of rungs gained on a one-month move up.
   - gpr_shock_sd_if_up = 1.0 sd per rung x expected_jump; gpr_shock_sd_expected = p_up_12m x gpr_shock_sd_if_up.
   - The PD the existing GPR channel gives: on a temporary copy of the universe, the country's Caldara-Iacoviello
     series has its last `gpr.window_months` months raised by gpr_shock_sd_if_up x its trailing 5-year sd. The
     unchanged engine then runs on that copy: run_gpr, the 4.10 uplift, the scorecard and the PDs, at 1,024 paths,
     since the PDs do not depend on the path count.
   - Where the 4.10 uplift does not change, the PD equals the base by construction and no second run is made.
   - A country without a CI series has no channel (`gpr_channel` none), so its PD does not move. Under
     `gpr.source` events or blend the link is not run.
   - pd_default_expected = pd_base + p_up_12m x (pd_if_up - pd_base).
   - Nothing feeds back into the base run, the PDs, Monte Carlo, limits or publish.
7. **Backtest** (`backtest(data_dir, as_of, basis)`).
   - Test dates are the month-ends from the first saved vintage to as_of minus 3 months.
   - Knowledge basis: rows at t read the vintages saved by t.
   - Replay basis: rows at t read the periods ending at least a month before t, from the vintages held at as_of. It is
     labelled secondary evidence and never passes the bar.
   - Outcome: the state path after the anchor of t, classified from the vintages held at as_of. A row is testable
     when its state is below the highest observable rung.
   - Metrics for 3 and 12 months: rows, events, Brier of the model and of the prior chain, Brier skill, AUC, and the
     false-alarm rate (warning = M >= 1.5 on a label-0 row).
   - Episodes are moves up in the outcome path. An episode is a hit when a warning came in the 12 months before it.
   - Bar (`SWITCH_ON_BAR`): at least 20 events at 12 months in at least 5 countries, AUC >= 0.70, Brier skill above 0,
     UCDP present (rungs 3-4 labelled), knowledge basis, real data.
   - `capabilities(data_dir, as_of)` lists what can and cannot run. Today nothing can: there is no event vintage on
     the cloud disk, the Mac has three legacy GDELT pulls of about a week each, and UCDP was never pulled.
8. **Synthetic data.** `build` and `backtest` refuse event rows whose provenance or licence says SYNTHETIC, and `run`
   always refuses them. `allow_synthetic=True` raises outside pytest, except on the demo's own sandbox (marker file
   plus a private flag). The demo (`demo_escalation(out_dir, as_of)`) writes a deterministic SYNTHETIC store under
   `out_dir/escalation/synthetic_data/`:
   - PHL ramps from calm to armed conflict over two years;
   - NGA holds a steady armed conflict;
   - SGP stays calm.
   The demo writes `escalation_SYNTHETIC.csv`, `escalation_pd_link_SYNTHETIC.csv` and `.json`, every row labelled
   SYNTHETIC. Every entry point needs an explicit as_of.
9. **Licence.** licence_class is the most restrictive `data/licences.csv` client_output of the sources read (gdelt,
   ucdp). A source without a register row counts as barred, a row with no source read is restricted, and a SYNTHETIC
   row is barred. Every row is internal only (client_ok False), so `client_safe_rows()` returns nothing. PD link rows
   are at least restricted, because the PDs read the run's internal inputs (IMF EXC-003).

Limits:

- The transition matrix, the thresholds, the 0.30 pressure weight and the 1 sd per rung are judgement. A refit
  waits for real data and the pre-registered split in the dossier, section 4.
- GDELT counts are media-coded and are not normalised for total media volume.
- Legacy GDELT vintages see rungs 0-1 only.
- Without UCDP, armed conflict and war cannot be seen or labelled, so the state is a lower bound.
- The PD link moves PDs only through the 4.10 uplift steps (0, 1, 2), so many shocks give no PD change.
