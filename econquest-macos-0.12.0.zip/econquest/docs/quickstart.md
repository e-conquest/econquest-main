# econquest quickstart (for Sam)

**Not yet.** Do nothing on this page until the program lead tells you the MVP is reached, that is, every row
M1-M10 in `team/mvp-checklist.md` passes (the status block at its end, written by `econquest demo`, says
"MVP reached"). Until then there is nothing for you to do.

## 1. Install (from Downloads)

1. Double-click `econquest-macos.zip` in Downloads. It unzips to a folder called `econquest`.
2. In that folder, double-click `install.command`. A Terminal window opens and installs into `~/econquest`.
   A reinstall backs up `data/` and `outputs/` to `~/econquest-backups/` first and never overwrites your data.
3. When it says "Finished", close the window and open a new Terminal window.

Check it worked:

    econquest --version

## 2. First run

    econquest run --stress

This is the base run plus the stress library on the shipped data: VaR99, ES99, expected loss, L-VaR99, a PD for
each desk name and the limit status. It writes `~/econquest/outputs/run_latest.json` and the dashboard.

## 3. Open the GUI

    econquest gui

Your browser opens http://127.0.0.1:8765 (this Mac only; nothing is reachable from the network). The tabs show the
run, results, notes and open items. The **Readiness** tab has the MVP card. Stop the GUI with Ctrl-C.

## 4. The workbook (xlsx)

    econquest export xlsx --check

Writes `~/econquest/outputs/workbook/econquest-<date>.xlsx` in the Risk Desk Sheet layout and checks every
number against the run (exit 1 on any mismatch). Nothing is sent to Google.

## 5. The research pack

    cd ~/econquest && .venv/bin/python -m econquest.validation.mvp_pack build --as-of 2026-10-23
    cd ~/econquest && .venv/bin/python -m econquest.validation.mvp_pack check

Country notes for the 18 desk names, scenario briefs, trade ideas and the weekly brief, under
`~/econquest/outputs/reports/mvp/`. Each carries the disclaimer and licence attribution. The check fails if any
number differs from the run. The GUI shows the pack too.

## 6. What DEMO means on the evidence bundle

    econquest evidence --as-of 2026-10-23 --demo-baseline

An evidence bundle named `evidence-<date>-DEMO.zip` was built on a **DEMO licence baseline**: the team approved
the current licence register as a stand-in so governance could be proven end to end. It is **not** your approval.
Client output stays refused while anything is DEMO. Your own licence approval is a later step, listed in
`team/when-sam-is-ready.md`; it is not part of the MVP.

## 7. Beyond the MVP (MVP+ rows M11-M27)

`econquest demo` also reports MVP+ rows after M1-M10, under their own heading; they never decide "MVP reached".
Rows M21-M27 (EQ-C-0166, EQ-C-0174) need nothing from M2-M10, so they can be run on their own:

    econquest demo --only M21-M24
    econquest demo --fast --only M25-M27      # the desk assistant, offline with the stub (about 40 seconds)

- M21 real-data day rehearsal: `econquest rehearse --quick` on copies (data/ is never written). Upgrade rows use the
  shipped zips in the folder of the zip being tested (or `--rehearse-zips DIR`); a missing zip is listed, not failed.
- M22 backtest explainer: `econquest backtest-explain --as-of 2026-10-23` (about a minute). It writes the INTERIM page
  section (also on the GUI Readiness tab). A day the reconstruction does not reproduce, such as 2026-09-23, is shown
  as "reconstruction, does not explain the recorded loss".
- M23 validator replication kit (Team B, in review) on a fresh DEMO data room; a tampered room is refused.
- M24 research QA gate: a good note passes, an altered copy is refused.
- M25 assistant answer: `econquest assistant ask` with the stub backend on a demo home of its own. The model writes
  slots such as {{r1.var99_mm}}, never digits; the QA gate fills them from the cited rows and shows a Figures list
  and the citations. A typed number is refused.
- M26 assistant refusals: a client-scope question sees no internal material; an injected text asking for a tool
  outside the allow-list, or echoing a fence marker, is refused and never shown.
- M27 assistant draft: `econquest assistant draft --country ARG --by NAME`, then `edit --reason`, then
  `sign --by NAME` (the CLI only; the GUI cannot sign) into the research archive. The research QA gate passes and
  `econquest assistant drafts --verify` checks the audit chain. The assistant stays off on your desk until you
  switch it on in assistant.json.

## 8. Where help lives

- `econquest --help`, and `econquest <command> --help` for any command.
- `econquest open-items`: what is waiting on you, in plain English (also the GUI's Open items tab).
- `README.md` in `~/econquest`, and the runbooks in `~/econquest/docs/runbooks/`.
- Anything that needs your Mac, your keys or a decision is listed in `team/when-sam-is-ready.md`.
