"""`<home>/assistant.json`: the assistant's runtime settings (EQ-C-0170, EQ-C-0171).

The assistant ships OFF. With no assistant.json, or with `enabled` anything but a JSON true, every entry point says
"assistant off" and nothing is sent anywhere. The file sits next to ops.json in the install folder (ECONQUEST_HOME,
the parent of --out). It holds no secret: the Claude API key, when Sam ever allows that backend, comes from the macOS
Keychain or the server's environment (provider.anthropic_key), never from this file.

    {"enabled": true, "backend": "openai_compat", "base_url": "http://127.0.0.1:11434/v1",
     "model": "qwen2.5:7b-instruct", "licence_source_id": "model_qwen2_5"}

Keys (anything else is a problem, so a typo never silently does nothing):
  enabled            JSON true turns the assistant on (default false)
  backend            openai_compat (default: Ollama or vLLM, self-hosted) | anthropic (optional, external) | stub
  base_url           OpenAI-style endpoint ending in /v1 (default http://127.0.0.1:11434/v1, Ollama on this machine)
  allow_hosts        extra host names allowed for base_url besides loopback (127.0.0.1, localhost, ::1), e.g. the
                     server option's private model host; nothing else is ever contacted by openai_compat
  model              model id as the server names it (openai_compat; required)
  licence_source_id  the data/licences.csv row for that model (optional; otherwise matched by match_series)
  anthropic_model    Claude model id for the anthropic backend (default claude-opus-5-5)
  allow_external     JSON true lets the anthropic backend send prompts off this machine (default false)
  timeout_s          per request, 1..600 (default 60)
  max_response_bytes response size cap, 1 KB..16 MB (default 2 MB)
  max_tokens         answer length cap, 16..8192 (default 800)
  temperature        0..2 (default 0; the anthropic backend never sends it: API version 2026-10-21 rejects it)
  strict             kept for old files and ignored (EQ-C-0176): Team B's slot gate decides every answer; the
                     free-text number check it switched on is retired
  tools              how tools are offered (EQ-C-0176): auto (default: the native `tools` field on openai_compat and
                     anthropic, the TOOL_CALL text protocol when the server refuses it and on the stub) | native |
                     text | off
  weights_digest     the model's weights digest for the record (Ollama `ollama show --modelfile` digest; required to
                     save a draft, EQ-B-0148; the stub has its own)
  seed               integer sampling seed, sent to openai_compat (Ollama and vLLM read `seed`) and recorded with
                     every answer and draft; null (default) sends none, and a draft then refuses
"""
from __future__ import annotations

import json
from pathlib import Path

CONFIG_NAME = "assistant.json"
BACKENDS = ("openai_compat", "anthropic", "stub")
TOOL_MODES = ("auto", "native", "text", "off")
DEFAULT_BACKEND = "openai_compat"
DEFAULT_BASE_URL = "http://127.0.0.1:11434/v1"
DEFAULT_ANTHROPIC_MODEL = "claude-opus-5-5"
RUNBOOK = "docs/runbooks/C-assistant-runtime.md"
MAX_CONFIG_BYTES = 64 * 1024

DEFAULTS: dict = {
    "enabled": False,
    "backend": DEFAULT_BACKEND,
    "base_url": DEFAULT_BASE_URL,
    "allow_hosts": [],
    "model": "",
    "licence_source_id": "",
    "anthropic_model": DEFAULT_ANTHROPIC_MODEL,
    "allow_external": False,
    "timeout_s": 60,
    "max_response_bytes": 2_000_000,
    "max_tokens": 800,
    "temperature": 0.0,
    "strict": True,
    "tools": "auto",
    "weights_digest": "",
    "seed": None,
}
_RANGES = {"timeout_s": (1, 600), "max_response_bytes": (1024, 16 * 1024 * 1024), "max_tokens": (16, 8192),
           "temperature": (0.0, 2.0)}
_BOOLS = ("enabled", "allow_external", "strict")
_STRS = ("backend", "base_url", "model", "licence_source_id", "anthropic_model", "tools", "weights_digest")


def path(home) -> Path:
    return Path(home) / CONFIG_NAME


def off_text(cfg: dict | None = None) -> str:
    """The one plain line every entry point prints while the assistant is off."""
    why = (cfg or {}).get("_off_reason") or f"no {CONFIG_NAME} in the install folder"
    return f"assistant off: {why}. It ships off; to switch it on see {RUNBOOK}."


def load(home) -> dict:
    """DEFAULTS, then <home>/assistant.json. Never raises: problems go to cfg["_problems"] and leave the assistant
    off. cfg["_present"] says whether the file exists; cfg["_off_reason"] is set while it is off."""
    cfg = {k: (list(v) if isinstance(v, list) else v) for k, v in DEFAULTS.items()}
    cfg.update(_present=False, _problems=[], _off_reason="")
    p = path(home)
    if p.is_symlink():
        cfg["_problems"].append(f"{CONFIG_NAME} is a symlink (refused)")
    elif p.is_file():
        cfg["_present"] = True
        try:
            raw = p.read_bytes()
            if len(raw) > MAX_CONFIG_BYTES:
                raise ValueError(f"larger than {MAX_CONFIG_BYTES} bytes")
            data = json.loads(raw.decode("utf-8"))
            if not isinstance(data, dict):
                raise ValueError("not a JSON object")
        except (OSError, ValueError) as e:
            cfg["_problems"].append(f"{CONFIG_NAME} unreadable ({type(e).__name__}: {e})")
            data = {}
        for k, v in data.items():
            if k.startswith("_") or k not in DEFAULTS:
                cfg["_problems"].append(f"{CONFIG_NAME}: unknown key {k!r}")
                continue
            cfg[k] = v
        cfg["_problems"].extend(validate(cfg))
    if not cfg["_present"]:
        cfg["_off_reason"] = f"no {CONFIG_NAME} in the install folder"
    elif cfg["_problems"]:
        cfg["_off_reason"] = f"{CONFIG_NAME} has problems ({'; '.join(cfg['_problems'][:3])})"
    elif cfg["enabled"] is not True:
        cfg["_off_reason"] = f"{CONFIG_NAME} does not set \"enabled\": true"
    if cfg["_off_reason"]:
        cfg["enabled"] = False
    return cfg


def validate(cfg: dict) -> list[str]:
    """Shape problems of a settings dict (types and ranges; host and licence rules are checked where they apply)."""
    out = []
    for k in _BOOLS:
        if not isinstance(cfg.get(k), bool):
            out.append(f"{k} must be true or false")
    for k in _STRS:
        if not isinstance(cfg.get(k), str):
            out.append(f"{k} must be a string")
    if cfg.get("backend") not in BACKENDS:
        out.append(f"backend must be one of {', '.join(BACKENDS)}")
    if cfg.get("tools") not in TOOL_MODES:
        out.append(f"tools must be one of {', '.join(TOOL_MODES)}")
    seed = cfg.get("seed")
    if seed is not None and (isinstance(seed, bool) or not isinstance(seed, int) or not 0 <= seed < 2 ** 63):
        out.append("seed must be null or a whole number from 0")
    hosts = cfg.get("allow_hosts")
    if not isinstance(hosts, list) or not all(isinstance(h, str) and h.strip() and "/" not in h for h in hosts):
        out.append("allow_hosts must be a list of host names (no scheme or path)")
    for k, (lo, hi) in _RANGES.items():
        v = cfg.get(k)
        if isinstance(v, bool) or not isinstance(v, (int, float)) or not lo <= v <= hi:
            out.append(f"{k} must be a number from {lo} to {hi}")
    return out
