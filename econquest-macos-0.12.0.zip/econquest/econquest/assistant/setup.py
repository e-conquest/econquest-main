"""`econquest assistant setup --check [--probe]` (EQ-C-0171): validate <home>/assistant.json and say what is missing.

Without --probe nothing touches the network: the check reads assistant.json, the host rule, the model licence gate
(data/licences.csv through licence_gov) and, for the anthropic backend, whether a key is present (presence only).
--probe additionally asks the configured self-hosted server for GET <base_url>/models (loopback or allow_hosts only,
no proxy, no redirect, same timeout and size cap) and reports whether the model is served. The anthropic backend is
never probed: that would be an external send.
"""
from __future__ import annotations

import json
import time
import urllib.error
import urllib.parse
import urllib.request

from . import config as _config
from . import provider as _p
from .licence import model_licence


def probe_models(cfg: dict) -> tuple[bool, str]:
    """GET <base_url>/models on the self-hosted server; (ok, message). Only after host_problem passes."""
    prob = _p.host_problem(cfg["base_url"], cfg.get("allow_hosts") or ())
    if prob:
        return False, prob
    url = str(cfg["base_url"]).rstrip("/") + "/models"
    host = urllib.parse.urlsplit(url).hostname
    req = urllib.request.Request(url, method="GET", headers={"Accept": "application/json"})
    try:
        with _p._open(req, float(cfg["timeout_s"]), local=True) as resp:
            raw = _p.read_capped(resp, int(cfg["max_response_bytes"]), time.monotonic() + float(cfg["timeout_s"]))
    except urllib.error.HTTPError as e:
        return False, f"probe: HTTP {e.code} from {host}"
    except (urllib.error.URLError, OSError, TimeoutError) as e:
        return False, f"probe: cannot reach {host} ({type(getattr(e, 'reason', e)).__name__})"
    if len(raw) > int(cfg["max_response_bytes"]):
        return False, "probe: reply larger than max_response_bytes"
    try:
        d = json.loads(raw.decode("utf-8"))
        ids = [str(m.get("id")) for m in d.get("data") or [] if isinstance(m, dict)]
    except (ValueError, AttributeError):
        return False, f"probe: {host} did not answer with an OpenAI-style model list"
    if cfg["model"] in ids:
        return True, f"probe: {host} serves {cfg['model']}"
    return False, f"probe: {host} answers but does not list {cfg['model']!r} (served: {', '.join(ids[:8]) or 'none'})"


def check(home, data_dir, *, probe: bool = False) -> dict:
    """{"ok", "state" (off | on | problems), "backend", "lines", "missing", "problems"}; never raises."""
    cfg = _config.load(home)
    lines, missing, problems = [], [], list(cfg["_problems"])
    out = {"ok": False, "state": "off", "backend": cfg["backend"], "lines": lines, "missing": missing,
           "problems": problems, "config": str(_config.path(home))}
    if not cfg["_present"]:
        lines.append(_config.off_text(cfg))
        missing.append(f"{_config.CONFIG_NAME} in the install folder with \"enabled\": true, a backend and a model "
                       f"(see {_config.RUNBOOK})")
        out["ok"] = True                                    # off is a valid, safe state
        return out
    b = cfg["backend"]
    lines.append(f"{_config.CONFIG_NAME}: found; backend {b}; enabled {cfg['enabled'] is True}")
    if b == "openai_compat":
        if not cfg["model"]:
            missing.append("model (the id the Ollama or vLLM server serves, e.g. qwen2.5:7b-instruct)")
        hp = _p.host_problem(cfg["base_url"], cfg.get("allow_hosts") or ())
        if hp:
            problems.append(hp)
        else:
            lines.append(f"base_url {cfg['base_url']}: host allowed")
        if cfg["model"]:
            gate = model_licence(cfg, data_dir)
            (lines if gate["ok"] else problems).append(gate["message"])
        if probe and not problems and cfg["model"]:
            ok, msg = probe_models(cfg)
            (lines if ok else problems).append(msg)
        elif not probe:
            lines.append("server not contacted (add --probe to ask it for its model list)")
    elif b == "anthropic":
        lines.append(f"model {cfg['anthropic_model']} (Claude Messages API, an external send)")
        if cfg["allow_external"] is not True:
            missing.append("\"allow_external\": true (Sam's decision: Claude API key yes/no, team/when-sam-is-ready.md)")
        if not _p.key_present():
            missing.append(f"a Claude API key: macOS Keychain item {_p.KEYCHAIN_SERVICE!r}, or ${_p.KEY_ENV} on the "
                           "server (never in a file)")
        lines.append("client-scope material is always refused for this backend")
        if probe:
            lines.append("probe not run: the anthropic backend is external")
    elif b == "stub":
        lines.append("stub backend: deterministic answers from the context, no model, no network")
    if cfg["enabled"] is not True and not cfg["_problems"]:
        missing.append("\"enabled\": true")
    only_off = missing == ["\"enabled\": true"]           # complete but switched off: a valid state
    out["ok"] = not problems and (not missing or only_off)
    out["state"] = "problems" if not out["ok"] else ("on" if cfg["enabled"] else "off")
    return out
