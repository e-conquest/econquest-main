"""LLM assistant layer (PI-15, EQ-C-0170/0171). It explains the desk from cited context and never computes a risk
number; it never runs the engine. It ships OFF until <home>/assistant.json switches it on; the default backend is a
self-hosted open-source model behind an OpenAI-style endpoint (Ollama or vLLM). Runbook:
docs/runbooks/C-assistant-runtime.md."""
from .provider import (AnthropicProvider, AssistantError, AssistantOff, OpenAICompatProvider, Provider, Refused,
                       Reply, StubProvider, make_provider)

__all__ = ["AnthropicProvider", "AssistantError", "AssistantOff", "OpenAICompatProvider", "Provider", "Refused",
           "Reply", "StubProvider", "make_provider"]
