"""`econquest assistant ...` (EQ-C-0170, EQ-C-0171), registered in ops/commands.py.

    econquest assistant status [--json]                         on or off, backend, model, host, licence gate
    econquest assistant ask "question" [--country X] [--json]   an answer with [cite:<id>] citations, or a refusal
    econquest assistant setup --check [--probe] [--json]        validate assistant.json; --probe asks the server

    econquest assistant ask "question" [--retry] [--client]     EQ-C-0172: gated by Team B's QA gate; one retry
    econquest assistant draft --country X --by NAME [--json]    model-assisted draft, gated, archived as DRAFT
    econquest assistant edit ID --file F --by NAME --reason WHY an analyst's edit of the slot text, a new DRAFT
    econquest assistant drafts [--json] [--verify]              the drafts and their state; --verify the audit chain
    econquest assistant sign ID --by NAME                       sign: a SIGNED archive version (research QA gate runs)

Off until <home>/assistant.json switches it on: every command then says "assistant off" plainly. `ask` exit codes:
0 answered, 1 refused or error, 3 off. Every answer passes Team B's slot gate (EQ-C-0176: only
validation.assistant_qa.render_answer's text is printed: the label line, the answer with its slots rendered, the
Figures list and the citations); a refused answer prints the refusal, never the model's text. When the gate
refuses, `ask` offers one retry (a y/N prompt on a terminal, or --retry beforehand), never more. Each request appends
one line to <outputs>/logs/assistant.jsonl: time, surface, backend, model, status, verdict, prompt/reply/shown-text
sha256, token counts, the tool mode, the model's weights digest, seed and system prompt sha256, and the gate's
res.to_dict() with the answer's text replaced by hashes (never the text, never a key). Drafts:
econquest/assistant/drafts.py over Team B's validation.assistant_drafts (EQ-B-0148), in the research archive.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import sys
from pathlib import Path

from . import config as _config

EXIT_OFF = 3
LOG_REL = Path("logs") / "assistant.jsonl"


def _print_json(d) -> None:
    print(json.dumps(d, indent=2, sort_keys=True, default=str))


def status(home, data_dir) -> dict:
    from .licence import model_licence
    from .provider import host_problem
    cfg = _config.load(home)
    d = {"enabled": bool(cfg["enabled"]), "backend": cfg["backend"], "config": str(_config.path(home)),
         "present": cfg["_present"], "problems": cfg["_problems"], "message": ""}
    if not cfg["enabled"]:
        d["message"] = _config.off_text(cfg)
        return d
    if cfg["backend"] == "openai_compat":
        d.update(model=cfg["model"], base_url=cfg["base_url"],
                 host=host_problem(cfg["base_url"], cfg.get("allow_hosts") or ()) or "allowed")
        gate = model_licence(cfg, data_dir)
        d.update(licence_ok=gate["ok"], licence=gate["message"])
        d["message"] = (f"assistant on: openai_compat {cfg['model']} at {cfg['base_url']}; "
                        f"{'licence ok' if gate['ok'] else 'REFUSED: ' + gate['message']}")
    elif cfg["backend"] == "anthropic":
        d.update(model=cfg["anthropic_model"], allow_external=cfg["allow_external"])
        d["message"] = (f"assistant on: anthropic {cfg['anthropic_model']} (external send "
                        f"{'allowed by assistant.json' if cfg['allow_external'] is True else 'NOT allowed: refused'}; "
                        "client-scope material always refused)")
    else:
        d["message"] = "assistant on: stub backend (deterministic, offline)"
    return d


def log_request(out_dir, res: dict, surface: str = "cli") -> None:
    """One hash-only line per request (EQ-C-0170; EQ-C-0172 adds the gate's verdict and res.to_dict() with text
    hashed). Never the question, the answer or a key."""
    if res.get("status") == "off":
        return
    row = {"ts_utc": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), "surface": surface,
           "backend": res.get("backend"), "model": res.get("model"), "status": res.get("status"),
           "verdict": res.get("verdict", ""), "audience": res.get("audience", "internal"), "attempt": res.get("attempt", 1),
           "prompt_sha256": res.get("prompt_sha256"), "reply_sha256": res.get("reply_sha256"),
           "shown_sha256": hashlib.sha256(str(res.get("text") or "").encode("utf-8")).hexdigest(),
           "usage": res.get("usage"), "chunks": res.get("chunks"), "citations": len(res.get("citations") or []),
           "tool_calls": res.get("tool_calls", 0), "tool_rows": res.get("tool_rows", 0),
           "tool_mode": res.get("tool_mode", ""), "weights_digest": res.get("weights_digest", ""),
           "seed": res.get("seed"), "system_prompt_sha256": res.get("system_prompt_sha256", ""), "qa": res.get("qa")}
    p = Path(out_dir) / LOG_REL
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        fd = os.open(p, os.O_WRONLY | os.O_APPEND | os.O_CREAT | getattr(os, "O_NOFOLLOW", 0), 0o600)
        with os.fdopen(fd, "a", encoding="utf-8") as f:
            f.write(json.dumps(row, sort_keys=True, default=str) + "\n")
    except OSError:
        pass                                                # the hash log is best effort; the answer is not


_log = log_request


def _print_ask(a, res) -> None:
    if a.json:
        _print_json({k: v for k, v in res.items() if k != "qa"} | {"qa_verdict": res.get("verdict")})
    elif res["ok"]:
        print(res["text"])
        if res["status"] == "flagged":
            print(f"[QA gate removed parts: {'; '.join(res['flags'])}]")
        print(f"(backend {res['backend']}, model {res['model']}, verdict {res['verdict']}, "
              f"cited {len(res['citations'])} source(s))")
    else:
        print(res["text"] or res["message"], file=sys.stderr if res["status"] != "off" else sys.stdout)


def _ask(a, home, data_dir, out_dir) -> int:
    from .answer import ask
    from .surfaces import audience_for
    aud = "client" if a.client else audience_for(data_dir)
    res = ask(a.question, home=home, data_dir=data_dir, out_dir=out_dir, country=a.country, audience=aud)
    log_request(out_dir, res)
    if res.get("retry_allowed"):
        again = a.retry
        if not again and not a.json and sys.stdin.isatty():
            _print_ask(a, res)
            try:
                again = input("The QA gate withheld the answer. Ask once more? [y/N] ").strip().lower() in ("y", "yes")
            except EOFError:
                again = False
            if not again:
                return 1
        if again:
            res = ask(a.question, home=home, data_dir=data_dir, out_dir=out_dir, country=a.country, audience=aud,
                      retry_codes=res["retry_codes"])
            log_request(out_dir, res)
    _print_ask(a, res)
    return 0 if res["ok"] else (EXIT_OFF if res["status"] == "off" else 1)


def _drafts(a, home, data_dir, out_dir) -> int:
    from . import drafts as D
    act = a.assistant_cmd
    try:
        if act == "draft":
            res = D.make_draft(a.country, home=home, data_dir=data_dir, out_dir=out_dir, product=a.product, by=a.by)
            log_request(out_dir, res, surface="cli-draft")
            if a.json:
                _print_json({k: v for k, v in res.items() if k != "qa"})
            else:
                print(res["text"] if res["ok"] else (res["text"] or res["message"]),
                      file=sys.stdout if res["ok"] or res["status"] == "off" else sys.stderr)
                if res["ok"]:
                    print(res["message"])
            return 0 if res["ok"] else (EXIT_OFF if res["status"] == "off" else 1)
        if act == "drafts":
            rows = D.list_drafts(out_dir, data_dir)
            ver = D.verify(out_dir, data_dir) if a.verify else None
            if a.json:
                _print_json({"drafts": rows, "verify": ver} if ver is not None else rows)
            else:
                for r in rows:
                    signed = f" signed by {r['signed'].get('by')}" if r.get("signed") else ""
                    print(f"{r['id']:<60} v{r['version']} {r['state']:<6} run {r['run_id']}{signed}  ({r['label']})")
                if not rows:
                    print("No assistant drafts (econquest assistant draft --country X --by NAME).")
                if ver is not None:
                    print(f"drafts audit: {'verifies' if ver['ok'] else 'BROKEN'} ({ver['rows']} rows)"
                          + "".join(f"\n  {e}" for e in ver["errors"][:10]))
            return 0 if ver is None or ver["ok"] else 1
        if act == "edit":
            try:
                text = Path(a.file).read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError) as e:
                print(f"cannot read --file ({type(e).__name__})", file=sys.stderr)
                return 1
            r = D.save_edit(out_dir, a.id, text, by=a.by, reason=a.reason, data_dir=data_dir)
            if r["status"] == "refused":
                print(r["text"], file=sys.stderr)
                print(f"not saved: {r['id']} stays at v{r['version']}", file=sys.stderr)
                return 1
            print(f"{r['status']}: {r['id']} v{r['version']}")
            return 0
        if act == "sign":
            r = D.sign(out_dir, a.id, by=a.by, data_dir=data_dir)
            s = r["archive"]
            print(f"signed {r['id']} v{r['version']} by {s['by']} (reviewed v{s['reviewed_version']}): archive "
                  f"{s['archive_ref']}")
            return 0
    except D.DraftError as e:
        print(str(e), file=sys.stderr)
        return 1
    return 2


def cmd(a, home) -> int:
    data_dir, out_dir = Path(a.data), Path(a.out)
    act = a.assistant_cmd
    if act == "status":
        d = status(home, data_dir)
        _print_json(d) if a.json else print(d["message"])
        return 0
    if act == "ask":
        return _ask(a, home, data_dir, out_dir)
    if act in ("draft", "drafts", "edit", "sign"):
        return _drafts(a, home, data_dir, out_dir)
    if act == "setup":
        if not a.check:
            print("econquest assistant setup takes --check (validate assistant.json) and optional --probe; it never "
                  f"writes the file. How to write it: {_config.RUNBOOK}")
            return 2
        from .setup import check
        r = check(home, data_dir, probe=a.probe)
        if a.json:
            _print_json(r)
        else:
            for line in r["lines"]:
                print(line)
            for m in r["missing"]:
                print(f"missing: {m}")
            for p in r["problems"]:
                print(f"problem: {p}")
            print(f"assistant setup check: {'ok' if r['ok'] else 'NOT ok'} (state {r['state']})")
        return 0 if r["ok"] else 1
    return 2


def register(sub, home_fn) -> None:
    p = sub.add_parser("assistant", help="LLM desk assistant, OFF until <home>/assistant.json (EQ-C-0170/0171): explains "
                                         "the desk from cited context and never computes a risk number; default backend "
                                         "a self-hosted open-source model (Ollama or vLLM)")
    s = p.add_subparsers(dest="assistant_cmd", required=True)
    st = s.add_parser("status", help="on or off, backend, model, host and licence gate (no network)")
    st.add_argument("--json", action="store_true")
    ak = s.add_parser("ask", help="ask a question; the model writes figures as slots and the QA gate renders them from "
                                  "the cited rows (any other number refuses); exit 0 answered, 1 refused, 3 off")
    ak.add_argument("question")
    ak.add_argument("--country", help="country name or ISO3 to focus the context on")
    ak.add_argument("--json", action="store_true")
    ak.add_argument("--retry", action="store_true", help="if the QA gate withholds the answer, ask once more (never more)")
    ak.add_argument("--client", action="store_true", help="gate as a client-facing answer (client_ok context only)")
    dr = s.add_parser("draft", help="a model-assisted draft note through Team B's slot gate (check_draft), archived as "
                                    "a DRAFT version labelled 'model-assisted, not validated' (EQ-C-0172, EQ-C-0176)")
    dr.add_argument("--country", required=True, help="desk country name or ISO3")
    dr.add_argument("--by", required=True, help="the analyst who asks for the draft (a named person)")
    dr.add_argument("--product", default="country_note", choices=["country_note"])
    dr.add_argument("--json", action="store_true")
    ed = s.add_parser("edit", help="save an analyst's edit of a draft's slot text as its next DRAFT version (gated; "
                                   "a refused edit is not saved)")
    ed.add_argument("id")
    ed.add_argument("--file", required=True, help="the edited slot text (UTF-8; figures as {{id.field}} slots or "
                                                  "[[analyst-entered: TEXT | source: CITATION]])")
    ed.add_argument("--by", required=True, help="the analyst's name")
    ed.add_argument("--reason", required=True, help="why the draft was edited (kept in the record)")
    ls = s.add_parser("drafts", help="list the assistant drafts and their state")
    ls.add_argument("--json", action="store_true")
    ls.add_argument("--verify", action="store_true", help="also verify the drafts audit chain against the archive")
    sg = s.add_parser("sign", help="sign the latest draft version through the research archive (the research QA gate "
                                   "runs; a refused figure is not signed)")
    sg.add_argument("id")
    sg.add_argument("--by", required=True, help="the analyst who signs")
    se = s.add_parser("setup", help="--check validates assistant.json and reports what is missing (no network unless "
                                    "--probe)")
    se.add_argument("--check", action="store_true", help="validate assistant.json (it is never written by econquest)")
    se.add_argument("--probe", action="store_true", help="also ask the self-hosted server for its model list")
    se.add_argument("--json", action="store_true")

    def _fn(a):
        code = cmd(a, home_fn(a))
        if code:
            sys.exit(code)
    p.set_defaults(fn=_fn)
