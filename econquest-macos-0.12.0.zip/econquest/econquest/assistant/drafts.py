"""Model-assisted draft notes (EQ-C-0172; EQ-C-0176 moves them onto Team B's drafts API): draft, edit, sign.

    econquest assistant draft --country X --by NAME [--json]        a gated draft, archived as a DRAFT version
    econquest assistant edit ID --file F --by NAME --reason WHY     an analyst's edit as a new DRAFT version
    econquest assistant drafts [--json] [--verify]                  the drafts, their state; --verify checks the chain
    econquest assistant sign ID --by NAME                           sign: a SIGNED archive version (CLI only, M7)

EQ-C-0176 (HO-20261027-B-C-005): this module is the host of `econquest.validation.assistant_drafts` (schema
`eq-assistant-drafts/1`, plural module name). Drafts are research archive (EQ-C-0154) versions of their own item
`<product>-<subject>-assistant-draft-<as_of>`: v1 DRAFT from the model, every edit a new DRAFT, the sign a SIGNED
version; the archive's research QA gate runs on each. Team B's module gates every step with the slot gate
(check_draft) against the context stored with the draft: the model's slot text, never the rendered text, so the
dates in a rendered citation list can no longer refuse a sign (the C-0172 defect). A refused draft or edit writes
nothing to the archive. Its audit chain is <out>/assistant_drafts/audit.jsonl. Archive list and search show a draft
item only in its SIGNED versions (presentation.archive), and no draft is ever the model's context (answer.get_context,
wiring.tool_rows).

What this host adds:
- the context: get_context (internal scope), the run stamp from <out>/run_latest.json, the model record (ModelInfo:
  the configured model, assistant.json weights_digest and seed; the stub's own), and an explicit request time (Team
  B reads no clock);
- the real data folder: `ArchiveAPI(presentation.archive, out_dir, data_dir=<data>)`, so users.json four-eyes is
  checked on the governed registry (HO-20261027-B-C-005 ask 5);
- SEC-C-027 L5, kept: while users.json enforces four-eyes, or cannot be read, sign refuses (no `--as` key binding
  yet); signing stays CLI-only (M7): the GUI's draft API refuses "sign" with the command to run;
- fence escaping of an analyst's edit (L8) before it is gated and stored.
"""
from __future__ import annotations

import datetime as dt
import json
import re
from pathlib import Path

from . import config as _config

DRAFT_PRODUCTS = ("country_note",)
MAX_DRAFT_CHARS = 20_000
ID_TAG = "-assistant-draft-"
_ID_RE = re.compile(r"^[a-z_]+-[a-z0-9-]{1,80}-assistant-draft-\d{4}-\d{2}-\d{2}$")
QUESTION = "{country} risk drivers country note"


class DraftError(ValueError):
    """A draft request the host refuses; the message is safe to print (no path, no model text)."""


def _B():
    from ..validation import assistant_drafts as B
    return B


def _ts(now=None) -> str:
    return (now or dt.datetime.now(dt.timezone.utc)).strftime("%Y-%m-%dT%H:%M:%SZ")


def _check_id(draft_id) -> str:
    """A draft item id, the whole string (SEC-C-027 L6: no trailing newline, never a path)."""
    s = str(draft_id or "")
    if "\n" in s or not _ID_RE.match(s) or s.split("-", 1)[0] not in DRAFT_PRODUCTS:
        raise DraftError("not a draft id (<product>-<subject>-assistant-draft-<YYYY-MM-DD>; econquest assistant drafts)")
    return s


def archive(out_dir, data_dir=None):
    """Team B's ArchiveAPI over Team C's research archive, bound to the out folder and the real data folder."""
    from ..presentation import archive as A
    B = _B()
    try:
        return B.ArchiveAPI(A, out_dir, data_dir=Path(data_dir) if data_dir is not None else None)
    except B.DraftError as e:
        raise DraftError(str(e)) from None


def _call(fn, *a, **k):
    B = _B()
    try:
        return fn(*a, **k)
    except B.DraftError as e:
        raise DraftError(str(e)) from None


def _run_stamp(out_dir) -> dict:
    try:
        s = (json.loads((Path(out_dir) / "run_latest.json").read_text(encoding="utf-8")) or {}).get("summary") or {}
    except (OSError, ValueError, AttributeError):
        s = {}
    v = s.get("versions") if isinstance(s.get("versions"), dict) else {}
    if not s.get("run_id") or not s.get("as_of"):
        raise DraftError("no run to draft from: run `econquest run` (or `econquest morning`) first")
    code = s.get("code_hash") or v.get("code_hash")
    if not code:
        from ..versioning import code_hash
        code = code_hash()
    return {"run_id": str(s["run_id"]), "as_of": str(s["as_of"])[:10], "code_hash": str(code),
            "data_hash": str(s.get("data_hash") or v.get("data_hash") or "")}


def model_info(cfg: dict, prov):
    """ModelInfo for the record (B-0149 inventory row 40): the model name, the weights digest and the seed from
    assistant.json (the stub has its own); a missing digest or seed refuses the draft (Team B)."""
    from .provider import STUB_MODEL, STUB_WEIGHTS
    B = _B()
    backend = str(cfg.get("backend") or getattr(prov, "name", "") or "")
    if backend == "stub" or getattr(prov, "name", "") == "stub":      # the stub (or a test's stand-in for it)
        return B.ModelInfo(name=str(getattr(prov, "model", "") or STUB_MODEL),
                           weights_digest=cfg.get("weights_digest") or STUB_WEIGHTS,
                           seed=cfg.get("seed") if isinstance(cfg.get("seed"), int) else 0, backend="stub",
                           temperature=float(cfg.get("temperature") or 0.0))
    name = cfg.get("anthropic_model") if backend == "anthropic" else cfg.get("model")
    return B.ModelInfo(name=str(getattr(prov, "model", "") or name or ""), weights_digest=str(cfg.get("weights_digest") or ""),
                       seed=cfg.get("seed"), backend=backend, temperature=float(cfg.get("temperature") or 0.0))


class _Recording:
    """The configured provider, recording the prompt and reply hashes for the request log (never the text)."""

    def __init__(self, prov, res: dict):
        self.prov, self.res, self.name = prov, res, getattr(prov, "name", "")

    def complete(self, messages, *, max_tokens, temperature, stop=None):
        from .provider import prompt_hash, sha256_text
        r = self.prov.complete(messages, max_tokens=max_tokens, temperature=temperature)
        self.res.update(model=r.model, prompt_sha256=prompt_hash(messages), reply_sha256=sha256_text(r.text),
                        usage=dict(r.usage))
        return r


def make_draft(country: str, *, home, data_dir, out_dir, by, product: str = "country_note", cfg: dict | None = None,
               provider=None, context_provider=None, now=None) -> dict:
    """Draft, gate (check_draft), archive as v1 DRAFT (create_draft). {"status": off | refused | error | saved, "ok",
    "id", "version", "text", "message", "verdict", "codes", "figures", "qa", "backend", "model", "weights_digest",
    "seed", "prompt_sha256", "reply_sha256"}; "text" is the rendered draft or the gate's refusal."""
    from .answer import get_context
    from .provider import AssistantError, AssistantOff, Refused, make_provider
    cfg = _config.load(home) if cfg is None else cfg
    res = {"status": "off", "ok": False, "id": "", "version": 0, "text": "", "message": "", "verdict": "", "codes": [],
           "figures": [], "qa": None, "backend": cfg.get("backend"), "model": "", "weights_digest": "", "seed": None,
           "prompt_sha256": "", "reply_sha256": "", "usage": {}, "audience": "internal", "surface": "draft",
           "drafter": "EQ-B-0148 create_draft"}

    def stop(status, msg):
        res.update(status=status, message=msg, text=msg)
        return res
    if not cfg.get("enabled"):
        return stop("off", _config.off_text(cfg))
    if product not in DRAFT_PRODUCTS:
        return stop("refused", f"--product must be one of {', '.join(DRAFT_PRODUCTS)}")
    country = " ".join(str(country or "").split())
    if not country or len(country) > 60:
        return stop("refused", "--country must name a desk country (name or ISO3)")
    try:
        stamp = _run_stamp(out_dir)
    except DraftError as e:
        return stop("refused", str(e))
    B = _B()
    try:
        prov = provider or make_provider(cfg, data_dir=data_dir, scope="internal")
        chunks = get_context(data_dir=data_dir, out_dir=out_dir, question=QUESTION.format(country=country),
                             country=country, scope="internal", context_provider=context_provider)
        # point in time (Team B refuses context dated after the draft's as_of): a later row, such as a scheduled
        # event or a data row newer than the run, is left out of the draft's context rather than refusing the draft
        chunks = [c for c in chunks if str(getattr(c, "as_of", "") or "")[:10] <= stamp["as_of"]]
        if not chunks:
            return stop("refused", f"no context for {country} dated on or before {stamp['as_of']}: nothing to draft from")
        mi = model_info(cfg, prov)
        res.update(weights_digest=mi.weights_digest, seed=mi.seed)
        code = next((getattr(c, "country", "") for c in chunks if getattr(c, "country", "")), "") or country
        subject = _country_name(data_dir, code) or country
        r = B.create_draft(_Recording(prov, res), archive=archive(out_dir, data_dir), product=product, subject=subject,
                           run=B.RunStamp(**stamp), model=mi, chunks=chunks, as_of=stamp["as_of"], at=_ts(now),
                           requested_by=by, max_tokens=int(cfg.get("max_tokens") or B.MAX_TOKENS))
    except AssistantOff as e:
        return stop("off", str(e))
    except Refused as e:
        return stop("refused", f"assistant refused: {e}")
    except AssistantError as e:
        return stop("error", f"assistant error: {e}")
    except (B.DraftError, DraftError) as e:
        return stop("refused", f"not drafted: {e}")
    from .wiring import escape_fence
    res.update(verdict=r["verdict"], codes=r["codes"], figures=r["figures"], text=escape_fence(r["text"]),
               qa={"verdict": r["verdict"], "codes": r["codes"], "figures": len(r["figures"])})
    if not r["ok"]:
        res.update(status="refused", message=res["text"])
        return res
    res.update(status="saved", ok=True, id=r["item_id"], version=r["version"],
               message=f"draft {r['item_id']} v{r['version']} archived as DRAFT (model-assisted, not validated); "
                       f"edit it, then `econquest assistant sign {r['item_id']} --by NAME`")
    return res


def _country_name(data_dir, code: str) -> str:
    """A desk name for an ISO3 code or a name from countries.csv; "" when unknown."""
    import csv
    try:
        with open(Path(data_dir) / "countries.csv", newline="", encoding="utf-8") as f:
            for r in csv.DictReader(f):
                name, iso = str(r.get("country") or ""), str(r.get("iso") or "")
                if code and (code.upper() == iso.upper() or code.casefold() == name.casefold()):
                    return name
    except (OSError, csv.Error, UnicodeDecodeError):
        pass
    return ""


def load(out_dir, draft_id, data_dir=None) -> dict:
    """{"id", "version", "state", "label", "text" (the slot text an analyst edits), "figures", "signed", "record"} of
    the latest version. DraftError when there is no such draft (or its draft.json does not match the manifest)."""
    did = _check_id(draft_id)
    rec = _call(_B().load_draft, archive(out_dir, data_dir), did)
    return {"id": did, "version": rec["version"], "state": str(rec["status"]).lower(), "label": rec["label"],
            "text": rec["source_text"], "figures": rec.get("figures") or [], "signed": rec.get("signed"), "record": rec}


def list_drafts(out_dir, data_dir=None) -> list[dict]:
    return [{"id": r["item_id"], "version": r["version"], "state": str(r["status"]).lower(), "label": r["label"],
             "subject": r["subject"], "as_of": r["as_of"], "run_id": r["run_id"], "model": r["model"],
             "signed": r.get("signed")} for r in _call(_B().list_drafts, archive(out_dir, data_dir))]


def save_edit(out_dir, draft_id, text, *, by, reason, data_dir=None, now=None) -> dict:
    """An analyst's edit of the slot text as the next DRAFT version (edit_draft). The text is fence-escaped first
    (SEC-C-027 L8; no NFKC: the analyst's characters stay as typed, the gate normalises). A refused edit is not saved:
    {"status": "refused", "text": the gate's refusal}; else {"status": "saved" | "unchanged", "id", "version", "text"}."""
    from .wiring import escape_fence
    did = _check_id(draft_id)
    if not isinstance(text, str) or not text.strip():
        raise DraftError("the edited text is empty")
    if len(text) > MAX_DRAFT_CHARS:
        raise DraftError(f"the edited text is longer than {MAX_DRAFT_CHARS} characters")
    text = escape_fence(text.replace("\r\n", "\n").replace("\r", "\n"), normalise=False)
    r = _call(_B().edit_draft, archive(out_dir, data_dir), did, text, by=by, at=_ts(now), reason=reason)
    return {"status": r["status"], "ok": bool(r["ok"]), "id": did, "version": r["version"],
            "text": escape_fence(r.get("text") or ""), "codes": r.get("codes") or []}


def _four_eyes_closed(data_dir) -> None:
    """SEC-C-027 (EQ-C-0173) L5, kept by HO-20261027-B-C-005 ask 4: signing names a person, so it follows the
    identity rules of every other sign-off (ops/identity.py). While four-eyes is off (one operator) `--by NAME` is
    the record. Once users.json enforces four-eyes, a sign must be bound to a registered user's key; `assistant sign`
    has no `--as` yet, so it refuses (fail closed). An unreadable users.json refuses too; no data folder refuses."""
    if data_dir is None:
        raise DraftError("not signed: no data folder, so users.json four-eyes cannot be checked")
    from ..ops import identity as I
    try:
        on = I.enforced(I.governed_registry(data_dir))
    except (I.IdentityError, OSError, ValueError) as e:
        raise DraftError(f"not signed: users.json cannot be read ({type(e).__name__}); fix it with econquest change") from None
    if on:
        raise DraftError("not signed: four-eyes is enforced (users.json) and assistant sign is not yet bound to a "
                         "registered user's key (--as); sign once that lands (SEC-C-027)")


def _overlay(data_dir) -> tuple[Path, bool]:
    """The analyst overlay ledger root and its switch (research.analyst_overlay.enabled; off when unreadable)."""
    from ..presentation.overlay_view import root_for, switch_on
    try:
        from ..config import Settings
        settings = Settings.load(Path(data_dir) / "assumptions.json")
    except Exception:                                       # noqa: BLE001 - an unreadable switch is off
        settings = None
    return root_for(data_dir), switch_on(settings)


def sign(out_dir, draft_id, *, by, data_dir, now=None) -> dict:
    """Sign the latest DRAFT version (sign_draft): re-gated on its slot text against the stored context, a named
    person, the real data folder's users.json, overlay changes backed by active entries; then a SIGNED archive
    version (the research QA gate runs). {"status": "signed", "id", "version", "archive": {by, utc, archive_ref,
    ...}}; DraftError on any refusal. CLI only (SEC-C-027 M7)."""
    did = _check_id(draft_id)
    _four_eyes_closed(data_dir)
    arc = archive(out_dir, data_dir)
    root, on = _overlay(data_dir)
    r = _call(_B().sign_draft, arc, did, by=by, at=_ts(now), data_dir=Path(data_dir), overlay_root=root,
              overlay_enabled=on)
    it = arc.m.items(arc.out_dir).get(did) or {}
    ref = f"{it.get('product') or did.split('-', 1)[0]}/{did}/v{r['version']}"
    return {"status": "signed", "id": did, "version": r["version"],
            "archive": {"by": r["signed"]["by"], "utc": r["signed"]["at"], "reviewed_version": r["signed"]["reviewed_version"],
                        "archive_ref": ref, "archive_version": r["version"], "archive_status": "signed"}}


def verify(out_dir, data_dir=None) -> dict:
    """Team B's verify: the drafts audit chain and head, and every archive version of a draft item against it."""
    return _call(_B().verify, out_dir, archive=archive(out_dir, data_dir))
