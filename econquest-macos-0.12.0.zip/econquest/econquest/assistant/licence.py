"""Model licence gate (EQ-C-0171): a self-hosted model is used only when the licence register allows commercial use.

The register is Team A's data/licences.csv (contract C14), read through Team C's licence_gov reader: the approved
version when there is one (approved_bytes), otherwise the file itself (internal use only warns while there is no
baseline, as for every other internal reader). Team C never edits the register.

A model row is found by `licence_source_id` from assistant.json (exact source_id) or else as the first row whose
source_id starts with "model_" and whose match_series regex matches the model id (case-insensitive search). It
passes only when terms_verified is yes, commercial is yes and internal_use is yes. Anything else, a missing row, or
an unreadable register refuses, and the message names the row Team A would add.
"""
from __future__ import annotations

import re
from pathlib import Path

MODEL_PREFIX = "model_"
REGISTER = "licences.csv"
HANDOFF_NOTE = "Team A (A/AGENT-04) adds tighten-only model rows; Team C never edits the register"


def suggested_source_id(model: str) -> str:
    base = re.split(r"[:@]", str(model or "").strip().lower().rsplit("/", 1)[-1])[0]
    slug = re.sub(r"[^a-z0-9]+", "_", base).strip("_") or "name"
    return MODEL_PREFIX + slug


def _rows(data_dir) -> tuple[list[dict] | None, str]:
    from ..ops import licence_gov as gov
    d = Path(data_dir)
    try:
        st = gov.state(d)
        raw = gov.approved_bytes(d, st)
        where = "approved register"
        if raw is None:
            p = d / REGISTER
            if p.is_symlink() or not p.is_file():
                return None, f"data/{REGISTER} not found"
            raw, where = p.read_bytes(), f"data/{REGISTER} (no approved version yet: {st['status']})"
        return gov.parse(raw), where
    except Exception as e:                                   # noqa: BLE001 - fail closed with a reason
        return None, f"data/{REGISTER} unreadable ({type(e).__name__})"


def find_row(rows: list[dict], model: str, source_id: str = "") -> dict | None:
    if source_id:
        return next((r for r in rows if r.get("source_id") == source_id), None)
    for r in rows:
        sid, pat = r.get("source_id", ""), r.get("match_series", "")
        if not sid.startswith(MODEL_PREFIX) or not pat:
            continue
        try:
            if re.search(pat, model, flags=re.IGNORECASE):
                return r
        except re.error:
            continue
    return None


def allows_commercial(row: dict) -> tuple[bool, str]:
    bad = [f"{k} is {row.get(k) or 'blank'!r}" for k in ("terms_verified", "commercial", "internal_use")
           if (row.get(k) or "").strip() != "yes"]
    return (not bad, "; ".join(bad))


def model_licence(cfg: dict, data_dir) -> dict:
    """{"ok", "message", "row" (source_id or ""), "register" (which copy was read)}. Never raises."""
    model = str(cfg.get("model") or "").strip()
    want = str(cfg.get("licence_source_id") or "").strip()
    if not model:
        return {"ok": False, "row": "", "register": "", "message": "assistant.json sets no model, so no licence row "
                "can be checked"}
    if re.search(r"(^|[:\-])cloud$", model.lower()):      # lead review: Ollama ":cloud" / "-cloud" tags run off the machine
        return {"ok": False, "row": "", "register": "", "message": (
            f"model {model!r} is an Ollama cloud tag: it sends prompts off this machine, so it is an external send, "
            "not a self-hosted model; refused (use a local tag such as gemma4:12b)")}
    if data_dir is None:
        return {"ok": False, "row": "", "register": "", "message": "no data folder, so the licence register cannot "
                "be read (refused)"}
    rows, where = _rows(data_dir)
    if rows is None:
        return {"ok": False, "row": "", "register": where, "message": f"model licence gate: {where}; refused"}
    row = find_row(rows, model, want)
    if row is None:
        sid = want or suggested_source_id(model)
        return {"ok": False, "row": "", "register": where, "message": (
            f"model licence gate: no row for model {model!r} in data/{REGISTER}. Needed: a row source_id {sid} "
            f"whose match_series matches {model!r}, licence_text naming the licence (e.g. Apache-2.0), "
            f"terms_verified yes, commercial yes, internal_use yes ({HANDOFF_NOTE}); the provider will not start")}
    ok, why = allows_commercial(row)
    if not ok:
        return {"ok": False, "row": row["source_id"], "register": where, "message": (
            f"model licence gate: row {row['source_id']} does not allow commercial use ({why}); the provider will "
            "not start")}
    return {"ok": True, "row": row["source_id"], "register": where,
            "message": f"model licence row {row['source_id']}: {row.get('licence_text') or row.get('name')}"}
