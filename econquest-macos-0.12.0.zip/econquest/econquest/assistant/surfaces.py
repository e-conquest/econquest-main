"""Assistant surfaces (EQ-C-0172): the GUI chat panel and draft editor API, and the morning "In plain words" section.

Every surface goes through answer.ask / answer.gate_text, so every text it shows is Team B's render_answer output
(EQ-C-0176: slots rendered by the gate, with its Figures list and citations; or its refusal) with fence markers escaped, the reply is buffered (never streamed), and each request is logged hash-only
with res.to_dict() (cli.log_request). The surfaces say "assistant off" plainly while <home>/assistant.json is absent
or off; the morning section is then left out of the payload entirely.

Audience: "client" when research.json client mode is in effect (presentation.research.effective_mode, which fails
closed to internal), else "internal" (the GUI and the CLI are internal desk tools).

    api_ask(home, data_dir, out_dir, body)    -> (code, payload)   POST /api/assistant/ask
    api_draft(home, data_dir, out_dir, body)  -> (code, payload)   POST /api/assistant/draft (create|load|save|sign|list)
    plain_words(rep, data_dir, out_dir)       -> dict | None       morning section; None while off or with no run
"""
from __future__ import annotations

import re
from pathlib import Path

from . import config as _config

MAX_ASK_BODY_BYTES = 16 * 1024
MAX_DRAFT_BODY_BYTES = 128 * 1024
COUNTRY_RE = re.compile(r"^[\w .'()-]{1,60}$")
PLAIN_QUESTION = "In plain words, what drives today's desk view?"
PLAIN_NOTE = ("Explain for a reader who is not a risk specialist, in three to five short sentences. Write each figure as "
              "its slot from the context, with its [cite:ID].")
DRAFT_ACTIONS = ("create", "load", "save", "sign", "list")


def audience_for(data_dir) -> str:
    try:
        from ..presentation.research import effective_mode
        return "client" if effective_mode(data_dir).get("mode") == "client" else "internal"
    except Exception:                                       # noqa: BLE001 - unreadable config: internal is the closed side
        return "internal"


def _public(res: dict) -> dict:
    """What a page may receive: the gated text and citation fields, never the model's raw text or the qa detail."""
    return {"enabled": res.get("status") != "off", "status": res.get("status"), "ok": bool(res.get("ok")),
            "verdict": res.get("verdict", ""), "text": res.get("text", ""), "audience": res.get("audience", "internal"),
            "sources": [{k: str(s.get(k) or "") for k in ("cite_id", "source_id", "row", "as_of", "provenance")}
                        for s in res.get("sources") or []],
            "retry_allowed": bool(res.get("retry_allowed")), "retry_codes": list(res.get("retry_codes") or []),
            "attempt": res.get("attempt", 1), "backend": res.get("backend"), "model": res.get("model", "")}


def api_ask(home, data_dir, out_dir, body) -> tuple[int, dict]:
    from .answer import MAX_QUESTION_CHARS, ask
    from .cli import log_request
    if not isinstance(body, dict):
        return 400, {"error": "body must be a JSON object"}
    cfg = _config.load(home)
    if not cfg.get("enabled"):
        return 200, {"enabled": False, "status": "off", "ok": False, "text": _config.off_text(cfg), "sources": [],
                     "retry_allowed": False, "retry_codes": []}
    q = body.get("question")
    if not isinstance(q, str) or not q.strip() or len(q) > MAX_QUESTION_CHARS:
        return 400, {"error": f"question must be text of 1 to {MAX_QUESTION_CHARS} characters"}
    country = body.get("country") or None
    if country is not None and (not isinstance(country, str) or not COUNTRY_RE.match(country)):
        return 400, {"error": "country must be a desk country name or ISO3 code"}
    retry = body.get("retry_codes")
    if retry is not None and (not isinstance(retry, list) or len(retry) > 20 or not all(isinstance(c, str) for c in retry)):
        return 400, {"error": "retry_codes must be a list of refusal codes"}
    res = ask(q, home=home, data_dir=data_dir, out_dir=out_dir, country=country, cfg=cfg,
              audience=audience_for(data_dir), retry_codes=retry)
    log_request(out_dir, res, surface="gui")
    return 200, _public(res)


def api_draft(home, data_dir, out_dir, body) -> tuple[int, dict]:
    from . import drafts as D
    from .cli import log_request
    if not isinstance(body, dict) or body.get("action") not in DRAFT_ACTIONS:
        return 400, {"error": f"action must be one of {', '.join(DRAFT_ACTIONS)}"}
    cfg = _config.load(home)
    act = body["action"]
    if act == "create" and not cfg.get("enabled"):
        return 200, {"enabled": False, "status": "off", "text": _config.off_text(cfg)}
    try:
        if act == "list":
            return 200, {"enabled": bool(cfg.get("enabled")), "drafts": D.list_drafts(out_dir, data_dir),
                         "message": "" if cfg.get("enabled") else _config.off_text(cfg)}
        if act == "create":
            country = body.get("country")
            if not isinstance(country, str) or not COUNTRY_RE.match(country):
                return 400, {"error": "country must be a desk country name or ISO3 code"}
            if not isinstance(body.get("by"), str) or not body["by"].strip():
                return 400, {"error": "by must name the analyst who asks for the draft"}
            res = D.make_draft(country, home=home, data_dir=data_dir, out_dir=out_dir, cfg=cfg, by=body["by"])
            log_request(out_dir, res, surface="gui-draft")
            return 200, {"enabled": True, "status": res["status"], "ok": res["ok"], "id": res["id"],
                         "version": res["version"], "text": res["text"], "message": res["message"] if res["ok"] else "",
                         "source": D.load(out_dir, res["id"], data_dir)["text"] if res["ok"] else ""}
        did = body.get("id")
        if not isinstance(did, str):
            return 400, {"error": "id is required"}
        if act == "load":
            cur = D.load(out_dir, did, data_dir)
            return 200, {"id": cur["id"], "state": cur["state"], "label": cur["label"], "version": cur["version"],
                         "text": cur["text"], "signed": cur.get("signed")}
        by = body.get("by")
        if act == "save":                                   # the slot text; a refused edit is not saved
            text, reason = body.get("text"), body.get("reason")
            if not isinstance(by, str) or not isinstance(reason, str):
                return 400, {"error": "save needs by (the analyst's name) and reason (why the draft was edited)"}
            return 200, D.save_edit(out_dir, did, text, by=by, reason=reason, data_dir=data_dir)
        # SEC-C-027 (EQ-C-0173): the GUI never signs. A sign names a person, and the page can only send a typed name;
        # every other identity-bearing action (overlay approve, review approve, change apply) is CLI-only, where
        # four-eyes and users.json apply. The research QA gate and the archive chain run in the CLI sign.
        return 403, {"error": "signing is not done from the GUI: run `econquest assistant sign "
                              f"{D._check_id(did)} --by NAME` (the research QA gate and the archive run there)",
                     "sign_command": f"econquest assistant sign {D._check_id(did)} --by NAME"}
    except D.DraftError as e:
        return 400, {"error": str(e)}


# ---------------------------------------------------------------- morning: In plain words
def _f(v):
    return v if isinstance(v, (int, float)) and not isinstance(v, bool) and v == v else None


def morning_chunks(rep: dict) -> list:
    """Context chunks made only from the morning payload's own figures (one sentence each, printed as
    `econquest morning` prints them). The model sees nothing else, so every number it may quote is the morning's."""
    from .answer import ContextChunk, chunk_id
    r = rep.get("run") or {}
    rid, as_of = str(r.get("run_id") or ""), str(r.get("as_of") or rep.get("as_of") or "")
    prov = f"econquest morning payload, run {rid} (as of {as_of})"
    out = []

    def add(key, text):
        sid = f"morning#{key}"
        out.append(ContextChunk(chunk_id=chunk_id(sid, text), kind="morning", source_id=sid, country="", as_of=as_of,
                                published_utc="", retrieved_utc="", text=text, licence_ids=("econquest_derived",),
                                scope="internal", trust="econquest", provenance=prov))
    add("run", f"Today's view uses run {rid} as of {as_of}, global regime {r.get('global_regime') or 'n/a'}"
               + ("" if r.get("fresh") else ", and the run is stale") + ".")
    for x in (rep.get("limits") or {}).get("rows") or []:
        v, lim, u = _f(x.get("value")), _f(x.get("limit")), _f(x.get("utilisation"))
        if v is None or lim is None or u is None:
            continue
        add(f"limits/{x.get('measure') or x.get('label')}", f"{x.get('label')} is {v:,.2f} $mm against a limit of "
            f"{lim:,.1f} $mm, {u * 100:.1f}% used, light {x.get('light')}.")
    ch = rep.get("changes") or {}
    p = rep.get("previous") or {}
    for m in ch.get("metrics") or []:
        cur, d = _f(m.get("current")), _f(m.get("delta"))
        if cur is not None and d is not None and p.get("run_id"):
            add(f"changes/{m.get('measure') or m.get('label')}", f"{m.get('label')} moved by {d:+,.2f} $mm to {cur:,.2f} $mm "
                f"since run {p.get('run_id')}.")
    for x in (ch.get("pd_movers") or [])[:5]:
        a, b, d = _f(x.get("pd_previous")), _f(x.get("pd_current")), _f(x.get("delta_pp"))
        if None not in (a, b, d):
            add(f"pd_movers/{x.get('country')}", f"{x.get('country')} 12-month PD moved from {a * 100:.2f}% to "
                f"{b * 100:.2f}% ({d:+.2f} pp).")
    for i, x in enumerate((ch.get("regime_changes") or [])[:5]):
        if x.get("message"):
            add(f"regime_changes/{i}", " ".join(str(x["message"]).split()).rstrip(".") + ".")
    al = rep.get("alerts") or {}
    c = al.get("counts") or {}
    add("alerts", f"Today there are {int(c.get('critical') or 0)} critical, {int(c.get('warning') or 0)} warning and "
                  f"{int(c.get('info') or 0)} info alerts.")
    return out


def plain_words(rep: dict, data_dir, out_dir, *, home=None, provider=None) -> dict | None:
    """The "In plain words" section: None while the assistant is off or there is no run (the section is left out);
    else {"status", "ok", "verdict", "text", "sources", "backend", "model", "label"}, gated, numbers only from the
    morning payload."""
    from .answer import build_messages, gate_text
    from .cli import log_request
    from .provider import AssistantError, make_provider, prompt_hash, sha256_text
    home = Path(out_dir).expanduser().resolve().parent if home is None else Path(home)
    cfg = _config.load(home)
    if not cfg.get("enabled") or rep.get("status") == "no_run" or not (rep.get("run") or {}).get("run_id"):
        return None
    audience = audience_for(data_dir)
    if audience == "client":       # SEC-C-027: the morning chunks are internal; a client surface never sends them
        return {"status": "refused", "ok": False, "verdict": "", "sources": [], "backend": cfg.get("backend"),
                "model": "", "label": "model-assisted, not validated",
                "text": "In plain words is not offered in client mode: the morning figures are internal-only."}
    res = {"status": "error", "ok": False, "verdict": "", "text": "", "sources": [], "backend": cfg.get("backend"),
           "model": "", "audience": audience, "attempt": 1, "prompt_sha256": "", "reply_sha256": "", "chunks": 0}
    chunks = morning_chunks(rep)
    res["chunks"] = len(chunks)
    try:
        prov = provider or make_provider(cfg, data_dir=data_dir, scope=audience)
        msgs = build_messages(PLAIN_QUESTION, chunks)
        msgs[0] = {"role": "system", "content": msgs[0]["content"] + " " + PLAIN_NOTE}
        res["prompt_sha256"] = prompt_hash(msgs)
        r = prov.complete(msgs, max_tokens=cfg["max_tokens"], temperature=cfg["temperature"])
        res.update(model=r.model, reply_sha256=sha256_text(r.text))
        res.update(gate_text(r.text, chunks, (), audience=audience, data_dir=data_dir, strict=cfg.get("strict", True)))
    except AssistantError as e:
        res.update(status="error" if type(e).__name__ == "AssistantError" else "refused", text=f"assistant: {e}")
    log_request(out_dir, res, surface="morning")
    return {"status": res["status"], "ok": bool(res.get("ok")), "verdict": res.get("verdict", ""), "text": res["text"],
            "sources": _public(res)["sources"], "backend": res["backend"], "model": res["model"],
            "label": "model-assisted, not validated"}


def plain_words_lines(sec: dict) -> list[str]:
    return ["In plain words (assistant, model-assisted, not validated):"] + \
        [f"  {ln}" if ln else "" for ln in str(sec.get("text") or "").splitlines()]
