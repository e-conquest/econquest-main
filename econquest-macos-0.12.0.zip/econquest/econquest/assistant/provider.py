"""Model-provider interface for the assistant (EQ-C-0170).

    provider.complete(messages, *, max_tokens, temperature, stop=None, tools=None)
        -> Reply(text, model, usage, finish_reason, tool_calls)

EQ-C-0176: `tools` is an OpenAI-style function list (wiring.native_tools: Team B's tool_manifest filtered to the
host's three tools). openai_compat sends it as the native `tools` field and reads `message.tool_calls`; anthropic
maps each entry to {name, description, input_schema} and reads `tool_use` blocks; both feed results back from
role "tool" messages (tool_call_id, content). A server that refuses the field raises ToolsUnsupported, and the caller
falls back to the TOOL_CALL text protocol (wiring.tool_prompt). The stub answers in slots, never in digits.

Three backends, all stdlib (no new dependency):
- openai_compat (default): an OpenAI-style POST <base_url>/chat/completions, which Ollama and vLLM both serve. Only
  loopback hosts (127.0.0.1, localhost, ::1) unless assistant.json lists the host in allow_hosts (e.g. the server
  option's private model host). No proxy is ever used and redirects are refused, so a prompt cannot leave for a host
  that was not allowed. Timeout and response-size cap from assistant.json.
- anthropic (optional): the Claude Messages API over HTTPS. It is an external send: refused unless assistant.json sets
  allow_external true, and refused for client-scope material whatever the config says (CLIENT_EXTERNAL_ALLOWED).
  The key comes from the macOS Keychain (`security find-generic-password -s econquest-anthropic -w`, read from stdout)
  or, on the server or in a container, from $ECONQUEST_ANTHROPIC_KEY; it is never put in argv, a log or a file.
- stub: deterministic, no network. It answers from the context lines and tool rows in the prompt, writing each
  figure as the slot {{<id>.<field>}} the line carries (HO-20261027-B-C-001 point 13) and citing [cite:<id>].

Logging (logger "econquest.assistant"): backend, model, sha256 of the prompt and of the reply, token counts. Never the
prompt, the reply or any key material.
"""
from __future__ import annotations

import hashlib
import ipaddress
import json
import logging
import os
import re
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass, field
from typing import Protocol

from . import config as _config

log = logging.getLogger("econquest.assistant")

LOOPBACK_HOSTS = frozenset({"127.0.0.1", "localhost", "::1"})
ANTHROPIC_URL = "https://api.anthropic.com/v1/messages"
ANTHROPIC_VERSION = "2026-10-21"
KEYCHAIN_SERVICE = "econquest-anthropic"
KEY_ENV = "ECONQUEST_ANTHROPIC_KEY"
CLIENT_EXTERNAL_ALLOWED = False       # client-scope material never goes to an external model until Sam decides
CITE_FMT = "[cite:{}]"
CITE_RE = re.compile(r"\[(?:chunk|cite):([0-9a-f]{16})\]")                  # [chunk:] is the legacy alias (B-C-002 ask 5)
CONTEXT_LINE_RE = re.compile(r"^\[(?:chunk|cite):([0-9a-f]{16})\] (.*)$")
TOOL_CALL_ID_RE = re.compile(r"^[A-Za-z0-9_.:-]{1,80}$")


class AssistantError(Exception):
    """The provider could not answer; the message is safe to print (no prompt, no key)."""


class AssistantOff(AssistantError):
    """The assistant is not switched on."""


class Refused(AssistantError):
    """A rule refused the request before anything was sent (external send, host, licence)."""


class ToolsUnsupported(AssistantError):
    """The server refused the native `tools` field (HTTP 400 with tools): the caller uses the text protocol."""


@dataclass(frozen=True)
class Reply:
    text: str
    model: str
    usage: dict = field(default_factory=dict)       # {"prompt_tokens": int, "completion_tokens": int}
    finish_reason: str = ""
    tool_calls: tuple = ()                          # ({"id", "name", "arguments": JSON text or dict}, ...) native only


class Provider(Protocol):
    name: str

    def complete(self, messages: list[dict], *, max_tokens: int, temperature: float,
                 stop: list[str] | None = None, tools: list | None = None) -> Reply: ...


# ---------------------------------------------------------------- shared helpers
def sha256_text(s: str) -> str:
    return hashlib.sha256(s.encode("utf-8")).hexdigest()


def prompt_hash(messages: list[dict]) -> str:
    return sha256_text(json.dumps(messages, sort_keys=True, ensure_ascii=False))


def _log_reply(backend: str, messages: list[dict], r: Reply) -> None:
    log.info("assistant backend=%s model=%s prompt_sha256=%s reply_sha256=%s prompt_tokens=%s completion_tokens=%s "
             "finish=%s", backend, r.model, prompt_hash(messages), sha256_text(r.text),
             r.usage.get("prompt_tokens"), r.usage.get("completion_tokens"), r.finish_reason)


def _check_messages(messages) -> None:
    """{'role': system|user|assistant|tool, 'content': str}; an assistant message may carry `tool_calls` (OpenAI
    shape), a tool message names its `tool_call_id`."""
    if not isinstance(messages, list) or not messages:
        raise AssistantError("messages must be a non-empty list")
    for m in messages:
        if not isinstance(m, dict) or m.get("role") not in ("system", "user", "assistant", "tool") \
                or not isinstance(m.get("content"), str):
            raise AssistantError("each message is {'role': system|user|assistant|tool, 'content': str}")
        if m["role"] == "tool" and not TOOL_CALL_ID_RE.match(str(m.get("tool_call_id") or "")):
            raise AssistantError("a tool message needs its tool_call_id")
        if "tool_calls" in m and (m["role"] != "assistant" or not isinstance(m["tool_calls"], list)):
            raise AssistantError("only an assistant message carries tool_calls (a list)")


def _call_id(v, i: int) -> str:
    v = str(v or "")
    return v if TOOL_CALL_ID_RE.match(v) else f"call_{i + 1}"


def args_dict(arguments) -> dict:
    """A tool call's arguments as a dict (JSON text parsed; anything else {}): for the anthropic `input` field."""
    if isinstance(arguments, dict):
        return arguments
    try:
        d = json.loads(arguments) if isinstance(arguments, str) else None
    except (ValueError, RecursionError):
        d = None
    return d if isinstance(d, dict) else {}


PRIVATE_SUFFIXES = (".local", ".internal", ".lan", ".home.arpa", ".localdomain", ".intranet", ".corp")


def private_host_name(host: str) -> bool:
    """True for a private, loopback or link-local IP literal (not a global one, not 0.0.0.0 / multicast), a
    single-label name (a container or LAN name such as "ollama") or a name under PRIVATE_SUFFIXES."""
    h = str(host or "").strip().lower().strip("[]")
    try:
        ip = ipaddress.ip_address(h)
    except ValueError:
        ip = None
    if ip is not None:
        ip = getattr(ip, "ipv4_mapped", None) or ip
        return (ip.is_private or ip.is_loopback or ip.is_link_local) and not (ip.is_unspecified or ip.is_multicast)
    if not h or h.endswith(".") or not re.fullmatch(r"[a-z0-9](?:[a-z0-9.-]{0,251}[a-z0-9])?", h) or ".." in h:
        return False
    if re.fullmatch(r"[0-9.]+|0x[0-9a-f.x]+", h):        # decimal / hex IPv4 spellings are not names
        return False
    return "." not in h or h.endswith(PRIVATE_SUFFIXES)


def host_problem(url: str, allow_hosts=()) -> str | None:
    """Why `url` may not be contacted by openai_compat (None when it may): http(s) only, no user info, query or
    fragment, and the host is loopback or listed exactly in allow_hosts."""
    try:
        u = urllib.parse.urlsplit(str(url))
        _ = u.port                                      # raises on a bad port
    except ValueError as e:
        return f"base_url is not a URL ({e})"
    if u.scheme not in ("http", "https"):
        return "base_url must start with http:// or https://"
    if u.username or u.password or "@" in u.netloc:
        return "base_url must not carry a user name or password"
    if u.query or u.fragment:
        return "base_url must not have a query or fragment"
    host = (u.hostname or "").lower()
    if not host:
        return "base_url has no host"
    if host in LOOPBACK_HOSTS:
        return None
    try:
        if ipaddress.ip_address(host).is_loopback:
            return None
    except ValueError:
        pass
    allowed = {str(h).strip().lower().strip("[]") for h in allow_hosts or ()}
    if host in allowed:
        if not private_host_name(host):                 # SEC-C-027: allow_hosts is for a private model host only
            return (f"host {host} is listed in allow_hosts but is not a private host: allow_hosts takes a private or "
                    f"link-local IP address, a single-label name or a name ending in {', '.join(PRIVATE_SUFFIXES)}; "
                    "a public host would be an external send (only the anthropic backend, with allow_external)")
        return None
    return (f"host {host} is not loopback and not in assistant.json allow_hosts; only 127.0.0.1, localhost and ::1 "
            "are allowed by default")


class _NoRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise urllib.error.HTTPError(req.full_url, code, "redirect refused", headers, fp)


def _open(req: urllib.request.Request, timeout: float, *, local: bool):
    """Open `req` with redirects refused; `local` also bypasses every proxy (a self-hosted model call never goes
    through one). Tests replace this function."""
    handlers = [_NoRedirect()]
    if local:
        handlers.append(urllib.request.ProxyHandler({}))
    return urllib.request.build_opener(*handlers).open(req, timeout=timeout)


def read_capped(resp, cap: int, deadline: float) -> bytes:
    """At most cap + 1 bytes of `resp`, read in pieces (read1 when the response has it: one socket read per call, so a
    server that drips bytes cannot hold one read open), refused with TimeoutError past `deadline` (time.monotonic):
    timeout_s is a total for the reply, not only a per-socket-read timeout (EQ-C-0173, SEC-C-027)."""
    rd = getattr(resp, "read1", None) or resp.read
    buf = bytearray()
    while len(buf) <= cap:
        if time.monotonic() > deadline:
            raise TimeoutError("reply took longer than timeout_s")
        b = rd(min(64 * 1024, cap + 1 - len(buf)))
        if not b:
            break
        buf += b
    return bytes(buf)


def _post_json(url: str, body: dict, headers: dict, *, timeout: float, cap: int, local: bool) -> dict:
    data = json.dumps(body).encode("utf-8")
    req = urllib.request.Request(url, data=data, method="POST",
                                 headers={"Content-Type": "application/json", "Accept": "application/json", **headers})
    host = urllib.parse.urlsplit(url).hostname or "?"
    deadline = time.monotonic() + timeout
    try:
        with _open(req, timeout, local=local) as resp:
            raw = read_capped(resp, cap, deadline)
    except urllib.error.HTTPError as e:
        err = AssistantError(f"HTTP {e.code} from {host}")
        err.http_status = e.code
        raise err from None
    except (urllib.error.URLError, OSError, TimeoutError) as e:
        reason = getattr(e, "reason", e)
        raise AssistantError(f"cannot reach {host} ({type(reason).__name__})") from None
    if len(raw) > cap:
        raise AssistantError(f"reply from {host} is larger than the {cap}-byte cap (max_response_bytes)")
    try:
        out = json.loads(raw.decode("utf-8"))
    except ValueError:
        raise AssistantError(f"reply from {host} is not JSON") from None
    if not isinstance(out, dict):
        raise AssistantError(f"reply from {host} is not a JSON object")
    return out


def _int(v) -> int | None:
    return v if isinstance(v, int) and not isinstance(v, bool) and v >= 0 else None


# ---------------------------------------------------------------- openai_compat (default)
class OpenAICompatProvider:
    """OpenAI-style /v1/chat/completions on a self-hosted server (Ollama, vLLM)."""
    name = "openai_compat"

    native_tools = True

    def __init__(self, base_url: str, model: str, *, allow_hosts=(), timeout_s: float = 60,
                 max_response_bytes: int = 2_000_000, seed: int | None = None):
        p = host_problem(base_url, allow_hosts)
        if p:
            raise Refused(p)
        if not model:
            raise Refused("assistant.json sets no model for the openai_compat backend")
        self.url = str(base_url).rstrip("/") + "/chat/completions"
        self.model, self.timeout, self.cap = model, float(timeout_s), int(max_response_bytes)
        self.seed = seed if isinstance(seed, int) and not isinstance(seed, bool) else None

    def complete(self, messages, *, max_tokens, temperature, stop=None, tools=None) -> Reply:
        _check_messages(messages)
        body = {"model": self.model, "messages": messages, "max_tokens": int(max_tokens),
                "temperature": float(temperature), "stream": False}
        if self.seed is not None:                           # Ollama and vLLM read `seed` (HO-20261027-B-C-004 ask 3)
            body["seed"] = self.seed
        if stop:
            body["stop"] = list(stop)
        if tools:
            body["tools"] = list(tools)
        try:
            d = _post_json(self.url, body, {}, timeout=self.timeout, cap=self.cap, local=True)
        except AssistantError as e:
            if tools and getattr(e, "http_status", None) in (400, 422):   # e.g. Ollama: "does not support tools"
                raise ToolsUnsupported(f"{e}: the server refused the tools field") from None
            raise
        try:
            ch = d["choices"][0]
            msg = ch["message"]
            text = msg.get("content")
        except (KeyError, IndexError, TypeError, AttributeError):
            raise AssistantError("reply has no choices[0].message") from None
        calls = []
        for i, c in enumerate(msg.get("tool_calls") or [] if isinstance(msg.get("tool_calls") or [], list) else []):
            fn = c.get("function") if isinstance(c, dict) and isinstance(c.get("function"), dict) else {}
            name = fn.get("name") if isinstance(fn.get("name"), str) else ""
            args = fn.get("arguments") if isinstance(fn.get("arguments"), (str, dict)) else {}
            calls.append({"id": _call_id(c.get("id") if isinstance(c, dict) else "", i), "name": name, "arguments": args})
        if text is None and calls:
            text = ""
        if not isinstance(text, str):
            raise AssistantError("reply content is not text")
        u = d.get("usage") if isinstance(d.get("usage"), dict) else {}
        r = Reply(text=text, model=str(d.get("model") or self.model),
                  usage={"prompt_tokens": _int(u.get("prompt_tokens")),
                         "completion_tokens": _int(u.get("completion_tokens"))},
                  finish_reason=str(ch.get("finish_reason") or ""), tool_calls=tuple(calls))
        _log_reply(self.name, messages, r)
        return r


# ---------------------------------------------------------------- anthropic (optional, external)
def anthropic_key(*, platform: str | None = None, env=None, run=subprocess.run) -> str | None:
    """The Claude API key: macOS Keychain (the secret arrives on stdout, never argv), else $ECONQUEST_ANTHROPIC_KEY.
    None when there is none. Never logged."""
    platform = platform or sys.platform
    env = os.environ if env is None else env
    key = None
    if platform == "darwin":
        try:
            r = run(["security", "find-generic-password", "-s", KEYCHAIN_SERVICE, "-w"],
                    capture_output=True, text=True, timeout=10)
            key = r.stdout.strip() if r.returncode == 0 else None
        except (OSError, subprocess.SubprocessError):
            key = None
    else:
        key = (env.get(KEY_ENV) or "").strip() or None
    if key and (len(key) > 512 or any(c.isspace() or not c.isprintable() for c in key)):
        return None
    return key or None


def key_present(*, platform: str | None = None, env=None, run=subprocess.run) -> bool:
    """Presence only (setup --check): on macOS asks the Keychain whether the item exists without reading it."""
    platform = platform or sys.platform
    env = os.environ if env is None else env
    if platform == "darwin":
        try:
            r = run(["security", "find-generic-password", "-s", KEYCHAIN_SERVICE],
                    capture_output=True, text=True, timeout=10)
            return r.returncode == 0
        except (OSError, subprocess.SubprocessError):
            return False
    return bool((env.get(KEY_ENV) or "").strip())


class AnthropicProvider:
    """Claude Messages API (POST /v1/messages). Only built through make_provider, which applies the external-send
    gates. `temperature` is accepted for the protocol and not sent (API version 2026-10-21 rejects it)."""
    name = "anthropic"

    def __init__(self, model: str = _config.DEFAULT_ANTHROPIC_MODEL, *, key_fn=anthropic_key, timeout_s: float = 60,
                 max_response_bytes: int = 2_000_000):
        self.model, self._key_fn = model or _config.DEFAULT_ANTHROPIC_MODEL, key_fn
        self.timeout, self.cap = float(timeout_s), int(max_response_bytes)

    native_tools = True

    def complete(self, messages, *, max_tokens, temperature, stop=None, tools=None) -> Reply:
        _check_messages(messages)
        key = self._key_fn()
        if not key:
            raise Refused(f"no Claude API key: macOS Keychain item {KEYCHAIN_SERVICE!r}, or ${KEY_ENV} on the server")
        system = "\n\n".join(m["content"] for m in messages if m["role"] == "system")
        body = {"model": self.model, "max_tokens": int(max_tokens), "messages": anthropic_messages(messages)}
        if system:
            body["system"] = system
        if stop:
            body["stop_sequences"] = list(stop)
        if tools:
            body["tools"] = anthropic_tools(tools)
        try:
            d = _post_json(ANTHROPIC_URL, body, {"x-api-key": key, "anthropic-version": ANTHROPIC_VERSION},
                           timeout=self.timeout, cap=self.cap, local=False)
        finally:
            key = None                                      # SEC-C-027: not left in a traceback frame on failure
        if d.get("stop_reason") == "refusal":             # lead review: a declined request is a refusal, never an answer
            det = d.get("stop_details") if isinstance(d.get("stop_details"), dict) else {}
            raise Refused(f"Claude declined the request (category {det.get('category') or 'not given'})")
        content = d.get("content")
        if not isinstance(content, list):
            raise AssistantError("Claude reply has no content list")
        text = "".join(b.get("text", "") for b in content if isinstance(b, dict) and b.get("type") == "text"
                       and isinstance(b.get("text", ""), str))
        calls = tuple({"id": _call_id(b.get("id"), i), "name": b.get("name") if isinstance(b.get("name"), str) else "",
                       "arguments": b.get("input") if isinstance(b.get("input"), dict) else {}}
                      for i, b in enumerate(x for x in content if isinstance(x, dict) and x.get("type") == "tool_use"))
        u = d.get("usage") if isinstance(d.get("usage"), dict) else {}
        r = Reply(text=text, model=str(d.get("model") or self.model),
                  usage={"prompt_tokens": _int(u.get("input_tokens")), "completion_tokens": _int(u.get("output_tokens"))},
                  finish_reason=str(d.get("stop_reason") or ""), tool_calls=calls)
        _log_reply(self.name, messages, r)
        return r


def anthropic_tools(tools) -> list[dict]:
    """OpenAI-style function entries ({"type": "function", "function": {...}} or the bare function) as Claude tools:
    {name, description, input_schema: parameters} (HO-20261027-B-C-002 ask 1)."""
    out = []
    for t in tools or ():
        f = t.get("function", t) if isinstance(t, dict) else {}
        if isinstance(f, dict) and isinstance(f.get("name"), str):
            out.append({"name": f["name"], "description": str(f.get("description") or ""),
                        "input_schema": f.get("parameters") or {"type": "object", "properties": {}}})
    return out


def anthropic_messages(messages) -> list[dict]:
    """The neutral (OpenAI-shaped) history as Messages API turns: an assistant message's tool_calls become tool_use
    blocks, consecutive tool messages become one user turn of tool_result blocks. System messages go in `system`."""
    out: list[dict] = []
    for m in messages:
        if m["role"] == "system":
            continue
        if m["role"] == "tool":
            block = {"type": "tool_result", "tool_use_id": m["tool_call_id"], "content": m["content"]}
            last = out[-1] if out else None
            if last and last["role"] == "user" and isinstance(last["content"], list) \
                    and all(b.get("type") == "tool_result" for b in last["content"]):
                last["content"].append(block)
            else:
                out.append({"role": "user", "content": [block]})
        elif m["role"] == "assistant" and m.get("tool_calls"):
            blocks = [{"type": "text", "text": m["content"]}] if m["content"] else []
            for i, c in enumerate(m["tool_calls"]):
                fn = c.get("function") if isinstance(c.get("function"), dict) else c
                blocks.append({"type": "tool_use", "id": _call_id(c.get("id"), i), "name": str(fn.get("name") or ""),
                               "input": args_dict(fn.get("arguments"))})
            out.append({"role": "assistant", "content": blocks})
        else:
            out.append({"role": m["role"], "content": m["content"]})
    return out


# ---------------------------------------------------------------- stub (deterministic, offline)
_WORD = re.compile(r"[a-z0-9]+")
STUB_MODEL = "stub-deterministic-1"
STUB_WEIGHTS = "stub:deterministic-1"                # the stub has no weights; this names it in draft records
STUB_PICK = 3
STUB_MAX_SLOTS = 4
_SENT_SPLIT = re.compile(r"(?<=[.!?])\s+")
_SLOT = re.compile(r"\{\{\s*[A-Za-z0-9_.:/#@-]+?\.[A-Za-z_][A-Za-z0-9_]*\s*\}\}")
_CTX_LINE = re.compile(r"^\[(chunk|cite):([0-9a-f]{16})\] (.*)$")
_VIEW_CITE = re.compile(r"^\[cite:([^\]]{1,200})\]$")


def _numeric(text: str) -> bool:
    """Whether text holds anything the QA gate reads as a number (its own rule when it can be loaded)."""
    try:
        from ..validation.assistant_qa import _MODEL_NUMERIC as rx
    except ImportError:                                 # the gate refuses the answer anyway
        rx = re.compile(r"\d|%")
    return bool(rx.search(text))


def _figure_slots(text: str) -> list[str]:
    """The slots of a line that hold figures (a date or run id slot is not a figure the stub quotes)."""
    return [x for x in _SLOT.findall(str(text or "")) if not re.search(r"\.(?:as_of|run_id)\s*\}\}$", x)]


def _view_rows(text: str) -> list[dict]:
    """Rows of the model_view JSON in a message: a whole view ({"rows": [...]}) or one view row ({"cite": ...})."""
    out = []
    for line in str(text or "").splitlines():
        line = line.strip()
        if not line.startswith("{"):
            continue
        try:
            d = json.loads(line)
        except (ValueError, RecursionError):
            continue
        rows = d.get("rows") if isinstance(d, dict) and isinstance(d.get("rows"), list) else [d] if isinstance(d, dict) else []
        out += [r for r in rows if isinstance(r, dict) and isinstance(r.get("cite"), str) and _VIEW_CITE.match(r["cite"])]
    return out


class StubProvider:
    """Deterministic answers for tests and the demo (EQ-C-0176: slots, never digits; HO-20261027-B-C-001 point 13).

    Sources it reads: the `[cite:<id>] text` (or legacy `[chunk:<id>]`) context lines of the last user message, and
    the model_view rows of tool results (role "tool" messages, or JSON lines in a user message, as in Team B's draft
    prompt). It picks up to three whose words best overlap the QUESTION (or TASK) line, ties in prompt order, and for
    each one writes:
    - the source text with its citation, when the text has nothing numeric outside its slots (the gate's own rule);
    - else its slots, joined by semicolons: `{{<id>.t1}}; {{<id>.t2}} [cite:<id>].` (at most four);
    - else a citation only: `The desk's data has a note on this [cite:<id>].`
    `tool_calls` scripts one round of tool requests (name, arguments): native when `tools` is passed, else TOOL_CALL
    lines; once tool results are in the messages it answers. The same messages always give the same reply."""
    name = "stub"
    native_tools = False                                # the stub reads the text protocol unless asked natively

    def __init__(self, tool_calls=None):
        self.script = [(str(n), dict(a or {})) for n, a in (tool_calls or ())]

    def _sources(self, messages) -> tuple[list[tuple[str, str, str, list[str]]], str]:
        user = next((m["content"] for m in reversed(messages) if m["role"] == "user"), "")
        srcs, question = [], ""
        for line in user.splitlines():
            m = _CTX_LINE.match(line)
            if m:
                srcs.append((m.group(2), m.group(1), m.group(3), _figure_slots(m.group(3))))
            elif line.startswith(("QUESTION: ", "TASK: ")) and not question:
                question = line.split(": ", 1)[1]
        views = [r for m in messages if m["role"] == "tool" for r in _view_rows(m["content"])] + _view_rows(user)
        for r in views:
            cid = _VIEW_CITE.match(r["cite"]).group(1)
            text = " ".join(str(r.get("text") or "").split())
            slots = [v["write"] for k, v in (r.get("slots") or {}).items()
                     if k not in ("as_of", "run_id") and isinstance(v, dict) and isinstance(v.get("write"), str)]
            srcs.append((cid, "cite", text or " ".join(str(x) for x in (r.get("labels") or {}).values()),
                         list(dict.fromkeys(slots + _figure_slots(text)))))
        return srcs, question

    def _answer(self, messages) -> str:
        srcs, question = self._sources(messages)
        if not srcs:
            return "The context holds nothing on this, so there is no answer from the desk's data."
        q = set(_WORD.findall(question.lower()))
        scored = sorted(enumerate(srcs), key=lambda t: (-len(q & set(_WORD.findall(t[1][2].lower()))), t[0]))
        parts = []
        for _, (cid, marker, text, slots) in scored[:STUB_PICK]:
            tag = f"[{marker}:{cid}]"
            bare = _SLOT.sub(" ", text)
            if text.strip() and not _numeric(bare) and re.search(r"[A-Za-z]", bare):
                parts.append(" ".join(f"{s} {tag}" for s in _SENT_SPLIT.split(text.strip()) if s))
            elif slots:
                parts.append("; ".join(slots[:STUB_MAX_SLOTS]) + f" {tag}.")
            else:
                parts.append(f"The desk's data has a note on this {tag}.")
        first = parts[0]
        lead = "" if first.startswith("The desk's data has") else "From the desk's data: "
        return lead + " ".join(parts)

    def complete(self, messages, *, max_tokens, temperature, stop=None, tools=None) -> Reply:
        _check_messages(messages)
        answered = any(m["role"] == "tool" or m["content"].startswith("TOOL RESULTS") for m in messages)
        calls = ()
        if self.script and not answered:
            if tools:
                calls = tuple({"id": f"stub_call_{i + 1}", "name": n, "arguments": json.dumps(a, sort_keys=True)}
                              for i, (n, a) in enumerate(self.script))
                text = ""
            else:
                text = "\n".join("TOOL_CALL " + json.dumps({"name": n, "arguments": a}, sort_keys=True) for n, a in self.script)
        else:
            text = self._answer(messages)
        words = text.split()
        if len(words) > max_tokens:
            text, finish = " ".join(words[:int(max_tokens)]), "length"
        else:
            finish = "tool_calls" if calls else "stop"
        for s in stop or ():
            if s and s in text:
                text, finish = text.split(s, 1)[0], "stop"
        r = Reply(text=text, model=STUB_MODEL,
                  usage={"prompt_tokens": sum(len(m["content"].split()) for m in messages),
                         "completion_tokens": len(text.split())},
                  finish_reason=finish, tool_calls=calls)
        _log_reply(self.name, messages, r)
        return r


# ---------------------------------------------------------------- factory with the gates
def make_provider(cfg: dict, *, data_dir=None, scope: str = "internal") -> Provider:
    """The configured provider, after every gate: off -> AssistantOff; anthropic without allow_external, or for
    client scope -> Refused; openai_compat whose model has no commercial-use licence row -> Refused; a host outside
    loopback / allow_hosts -> Refused. Nothing is sent by this function."""
    if not cfg.get("enabled"):
        raise AssistantOff(_config.off_text(cfg))
    backend = cfg.get("backend")
    if backend == "stub":
        return StubProvider()
    if backend == "anthropic":
        if scope == "client" and not CLIENT_EXTERNAL_ALLOWED:
            raise Refused("the anthropic backend is an external send and is refused for client-scope material")
        if cfg.get("allow_external") is not True:
            raise Refused("the anthropic backend is an external send: assistant.json must set \"allow_external\": "
                          "true (Sam's decision, team/when-sam-is-ready.md)")
        return AnthropicProvider(cfg.get("anthropic_model") or _config.DEFAULT_ANTHROPIC_MODEL,
                                 timeout_s=cfg["timeout_s"], max_response_bytes=cfg["max_response_bytes"])
    if backend == "openai_compat":
        from .licence import model_licence
        gate = model_licence(cfg, data_dir)
        if not gate["ok"]:
            raise Refused(gate["message"])
        return OpenAICompatProvider(cfg["base_url"], cfg["model"], allow_hosts=cfg.get("allow_hosts") or (),
                                    timeout_s=cfg["timeout_s"], max_response_bytes=cfg["max_response_bytes"],
                                    seed=cfg.get("seed"))
    raise Refused(f"unknown backend {backend!r}")
