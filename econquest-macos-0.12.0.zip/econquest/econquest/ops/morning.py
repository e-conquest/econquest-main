"""`econquest morning` (EQ-C-0132): the daily desk workflow on one screen.

    econquest morning [--as-of D] [--run | --no-run] [--json]

1. The base run: reuse the newest archived base run when it is for the target date (--as-of, else settings as_of, else
   today) and the data on disk still hash to the run's data_hash; otherwise run `econquest run --as-of D` (the same
   command as by hand, through main(), so the run gate and the action log apply). --run always runs, --no-run never
   does (the newest base run is shown, with why it is stale).
2. Then one summary, built by collect() below. The GUI Home tab (GET /api/morning) calls the same collect() with
   run=False, so the CLI and the page cannot diverge:
     limits      VaR99, ES99, expected loss, L-VaR99 against data/limits.json (presentation.mc_band.book_limit_verdicts:
                 pass / warning / breach, the warning level and the 95% MC band), as green / amber / red lights
     changes     since the previous stored base run (presentation.report.previous_run): metric deltas, the biggest PD
                 movers, regime changes, data changes (the runs' provenance data_files diff, and files changed on disk
                 since the run) and gate holds (data/live/review.csv; "new" against the hold snapshot of the previous run)
     alerts      validation.alerts.detect_alerts on the same two runs (read only: nothing is delivered or written)
     notes       the research pack (presentation.notes_view): the weekly brief and the newest notes, paths under --out
     open_items  ops.open_items.collect, shortened to one line and one command per item
   No model number is recomputed: every figure comes from the archived runs.

Writes (CLI only): the run, when one is needed, and <out>/morning/holds-<run_id>.json, the held cells for that run, so
the next morning can name the holds that are new. The API never writes. Paths in the payload are relative to --out.

--json prints the payload with SCHEMA below; its top-level keys are stable (EQ-C-0136 demo row M11):
schema, generated_utc, as_of, status, run, previous, limits, changes, alerts, notes, open_items, events, message;
plus plain_words (EQ-C-0172) only while the LLM assistant is switched on: the day's drivers in plain words, gated.
     events      upcoming events (EQ-C-0155): presentation.calendar_view.morning_section on Team A's calendar, the next
                 90 days from the target date (ALERT_FIELDS only) plus the event alerts (importance 2+, next 30 days)
"""
from __future__ import annotations

import datetime as dt
import json
import os
import re
import subprocess
import sys
from pathlib import Path

SCHEMA = "econquest-morning/1"
KEYS = ("schema", "generated_utc", "as_of", "status", "run", "previous", "limits", "changes", "alerts", "notes",
        "open_items", "events", "message")
METRICS = (("var99_mm", "VaR 99%"), ("es99_mm", "ES 99%"), ("expected_loss_mm", "Expected loss"), ("lvar99_mm", "L-VaR 99%"))
LIGHT = {"pass": "green", "warning": "amber", "breach": "red"}
REVIEW_REL = "live/review.csv"
HOLDS_DIR = "morning"
PD_MOVERS = 5
ALERT_ROWS = 10
NOTE_ROWS = 5
SUMMARY_CHARS = 160
PACKAGE_ROOT = Path(__file__).resolve().parents[2]
_DATE_RE = re.compile(r"(\d{4}-\d{2}-\d{2})")


def _num(v):
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    return x if x == x and abs(x) != float("inf") else None


def _short(text, n: int = SUMMARY_CHARS) -> str:
    from .next_steps import scrub
    t = scrub(text, PACKAGE_ROOT)
    return t if len(t) <= n else t[: n - 1].rstrip() + "…"


def target_as_of(data_dir, as_of=None) -> str:
    """--as-of, else settings as_of, else today: the same rule as `econquest run` (engine.pipeline.resolve_as_of)."""
    from ..config import Settings
    from ..engine.pipeline import resolve_as_of
    if as_of:
        return resolve_as_of(as_of)
    try:
        s = Settings.load(Path(data_dir) / "assumptions.json")
        return resolve_as_of(s.get("as_of"))
    except (OSError, ValueError, KeyError):
        return resolve_as_of(None)


def _versions(run: dict) -> dict:
    s = run.get("summary") or {}
    pv = (run.get("provenance") or {}).get("versions") or {}
    return {**{k: v for k, v in pv.items() if k != "data_files"}, **(s.get("versions") or {})}


def _data_files(run: dict | None) -> dict:
    return dict(((run or {}).get("provenance") or {}).get("versions", {}).get("data_files") or {})


def latest_base(store) -> dict | None:
    try:
        return store.latest("base")
    except FileNotFoundError:
        return None


def freshness(run: dict | None, data_dir, as_of: str, disk: dict | None = None) -> dict:
    """Whether `run` can stand for `as_of`: {"fresh": bool, "reasons": [...], "disk_changed": [files]}. Fresh means the
    run is for that date and the data files on disk still hash as the run saw them (versioning.data_hashes)."""
    if run is None:
        return {"fresh": False, "reasons": ["no archived base run"], "disk_changed": []}
    from ..versioning import code_hash, data_hashes
    disk = data_hashes(data_dir) if disk is None else disk
    s = run.get("summary") or {}
    v = _versions(run)
    files = _data_files(run)
    reasons = []
    if s.get("as_of") != as_of:
        reasons.append(f"run is for {s.get('as_of') or 'no date'}, not {as_of}")
    changed = sorted(k for k in set(files) | set(disk) if files.get(k) != disk.get(k)) if files else []
    if changed:
        reasons.append(f"{len(changed)} data file(s) changed on disk since the run")
    elif not files and v.get("data_hash"):
        from ..versioning import _combine
        if _combine(disk) != v.get("data_hash"):
            reasons.append("data on disk differ from the run's data_hash")
    out = {"fresh": not reasons, "reasons": reasons, "disk_changed": changed}
    if v.get("code_hash") and v.get("code_hash") != code_hash():
        out["code_note"] = "the code changed since this run (same data and date: rerun with --run to restamp it)"
    return out


def run_base(data_dir, out_dir, as_of: str, log=None) -> tuple[int, str]:
    """`econquest --data D --out O run --as-of A` in a child process (main(): run gate, action log). Returns
    (exit code, last output line)."""
    argv = [sys.executable, "-m", "econquest", "--data", str(data_dir), "--out", str(out_dir), "run", "--as-of", as_of]
    env = dict(os.environ)
    env["PYTHONPATH"] = str(PACKAGE_ROOT) + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
    p = subprocess.run(argv, capture_output=True, text=True, cwd=str(PACKAGE_ROOT), env=env)
    out = [x for x in p.stdout.splitlines() if x.strip()]       # the run's headline is its last stdout line
    err = [x for x in p.stderr.splitlines() if x.strip()]
    last = (out[-1] if out else "") if p.returncode == 0 else (err[-1] if err else out[-1] if out else "")
    if log:
        log(f"[morning] econquest run --as-of {as_of}: exit {p.returncode}")
    return p.returncode, last


# ---------------------------------------------------------------- sections
def limits_section(run: dict, data_dir) -> dict:
    from ..presentation.mc_band import book_limit_verdicts, load_book_limits
    lim = load_book_limits(data_dir)
    m = (run.get("summary") or {}).get("metrics") or {}
    rows = []
    for r in book_limit_verdicts(m, lim):
        rows.append({k: r[k] for k in ("measure", "label", "value", "limit", "warning_mm", "utilisation", "status",
                                       "band_lo", "band_hi", "within_mc_error", "mc_note")} | {"light": LIGHT[r["status"]]})
    order = {"pass": 0, "warning": 1, "breach": 2}
    worst = max((r["status"] for r in rows), key=order.get, default=None)
    return {"available": lim is not None, "warning_level": (lim or {}).get("warning_level"), "rows": rows,
            "worst": worst, "light": LIGHT.get(worst) if worst else None}


def _metric_deltas(cur: dict, prev: dict | None) -> list[dict]:
    m1 = (cur.get("summary") or {}).get("metrics") or {}
    m0 = ((prev or {}).get("summary") or {}).get("metrics") or {}
    out = []
    for k, label in METRICS:
        a, b = _num(m1.get(k)), _num(m0.get(k))
        d = None if a is None or b is None else a - b
        out.append({"measure": k, "label": label, "current": a, "previous": b, "delta": d,
                    "delta_pct": None if d is None or not b else d / abs(b) * 100})
    return out


def _pd_movers(cur: dict, prev: dict | None) -> list[dict]:
    if prev is None:
        return []
    from ..validation.alerts import normalise_run
    c1, c0 = normalise_run(cur)["country"], normalise_run(prev)["country"]
    rows = []
    for c, r in c1.items():
        p1, p0 = _num(r.get("pd_default")), _num((c0.get(c) or {}).get("pd_default"))
        if p1 is None or p0 is None:
            continue
        rows.append({"country": c, "pd_previous": p0, "pd_current": p1, "delta_pp": (p1 - p0) * 100,
                     "regime": r.get("regime"), "regime_previous": (c0.get(c) or {}).get("regime")})
    rows.sort(key=lambda x: (-abs(x["delta_pp"]), x["country"]))
    return [r for r in rows if abs(r["delta_pp"]) > 0][:PD_MOVERS]


def _data_changes(cur: dict, prev: dict | None, fresh: dict) -> dict:
    f1, f0 = _data_files(cur), _data_files(prev)
    v1, v0 = _versions(cur), _versions(prev or {}) if prev else {}
    if prev is None:
        return {"compared": False, "changed": [], "added": [], "removed": [], "data_hash": v1.get("data_hash"),
                "data_hash_previous": None, "on_disk_since_run": fresh.get("disk_changed", [])}
    return {"compared": bool(f1 and f0),
            "changed": sorted(k for k in set(f1) & set(f0) if f1[k] != f0[k]),
            "added": sorted(set(f1) - set(f0)), "removed": sorted(set(f0) - set(f1)),
            "data_hash": v1.get("data_hash"), "data_hash_previous": v0.get("data_hash"),
            "on_disk_since_run": fresh.get("disk_changed", [])}


def held_cells(data_dir) -> list[dict] | None:
    """Cells the quality gate holds now (data/live/review.csv status hold), as {table, key, country, reason}; None
    when there is no review.csv."""
    from ..validation.alerts import load_data_issues
    review, _ = load_data_issues(data_dir)
    if review is None or "status" not in review.columns:
        return None
    held = review[review["status"].astype(str).str.lower() == "hold"]
    return [{"table": str(r.get("table", "")), "key": str(r.get("key", "")), "country": str(r.get("country", "")),
             "reason": _short(r.get("reason", ""), 120)} for _, r in held.iterrows()]


def _cell_id(c: dict) -> str:
    return f"{c['table']}|{c['key']}|{c['country']}"


def _holds_snapshot(out_dir, run_id) -> list[str] | None:
    if not run_id:
        return None
    p = Path(out_dir) / HOLDS_DIR / f"holds-{run_id}.json"
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
        return [str(x) for x in d.get("held") or []]
    except (OSError, ValueError, AttributeError):
        return None


def save_holds_snapshot(out_dir, run_id, held: list[dict] | None) -> str | None:
    """CLI only: <out>/morning/holds-<run_id>.json, written once per run (a later morning keeps the first).
    Written atomically (EQ-C-0164): a killed or out-of-space morning never leaves a torn snapshot that every later
    morning would keep; an existing snapshot that does not parse is replaced."""
    if not run_id or held is None or not re.match(r"^[A-Za-z0-9_.-]+$", str(run_id)):
        return None
    d = Path(out_dir) / HOLDS_DIR
    p = d / f"holds-{run_id}.json"
    if p.exists() and _holds_snapshot(out_dir, run_id) is not None:
        return None
    from .backup import atomic_write_text
    d.mkdir(parents=True, exist_ok=True)
    atomic_write_text(p, json.dumps({"run_id": run_id, "saved_utc": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
                                     "held": sorted(_cell_id(c) for c in held)}, indent=1))
    return str(p)


def _gate_holds(data_dir, out_dir, prev: dict | None, held: list[dict] | None) -> dict:
    if held is None:
        return {"available": False, "held": 0, "new": [], "new_count": 0, "cleared_count": 0,
                "note": "no data/live/review.csv: no live pull has been gated"}
    from ..versioning import data_file_hash
    pid = ((prev or {}).get("summary") or {}).get("run_id")
    snap = _holds_snapshot(out_dir, pid)
    now = {_cell_id(c): c for c in held}
    if snap is not None:
        new = [now[k] for k in sorted(set(now) - set(snap))]
        return {"available": True, "held": len(held), "new": new[:20], "new_count": len(new),
                "cleared_count": len(set(snap) - set(now)), "note": f"against the holds saved for run {pid}"}
    if prev is not None and _data_files(prev).get(REVIEW_REL) and _data_files(prev).get(REVIEW_REL) == data_file_hash(data_dir, REVIEW_REL):
        return {"available": True, "held": len(held), "new": [], "new_count": 0, "cleared_count": 0,
                "note": "review.csv unchanged since the previous run: no new hold"}
    return {"available": True, "held": len(held), "new": [], "new_count": None, "cleared_count": None,
            "note": "no hold snapshot for the previous run and review.csv changed: new holds cannot be told apart"
                    if prev is not None else "no previous run to compare with"}


def changes_section(cur: dict, prev: dict | None, data_dir, out_dir, fresh: dict, alerts: list[dict], held) -> dict:
    g1 = (cur.get("summary") or {}).get("global_regime")
    g0 = ((prev or {}).get("summary") or {}).get("global_regime") if prev else None
    regimes = [{"scope": a.get("scope"), "country": a.get("country"), "from": a.get("threshold"), "to": a.get("value"),
                "severity": a.get("severity"), "message": a.get("message")} for a in alerts if a.get("kind") == "regime_flip"]
    return {"compared": prev is not None, "metrics": _metric_deltas(cur, prev), "pd_movers": _pd_movers(cur, prev),
            "global_regime": {"current": g1, "previous": g0}, "regime_changes": regimes,
            "data": _data_changes(cur, prev, fresh), "gate_holds": _gate_holds(data_dir, out_dir, prev, held)}


def alerts_list(cur: dict, prev: dict | None, data_dir) -> list[dict]:
    """validation.alerts.detect_alerts for the two runs, the forecast record and the data layer. Nothing delivered."""
    from ..config import Settings
    from ..validation.alerts import detect_alerts, load_data_issues
    from ..validation.record import load_record
    s = Settings.load(Path(data_dir) / "assumptions.json")
    review, feeds = load_data_issues(data_dir)
    rec = Path(data_dir) / "forecast_record.csv"
    return detect_alerts(cur, prev, load_record(rec) if rec.exists() else None, s, review=review, feeds=feeds)


def alerts_section(alerts: list[dict]) -> dict:
    counts = {k: sum(1 for a in alerts if a.get("severity") == k) for k in ("critical", "warning", "info")}
    shown = [a for a in alerts if a.get("kind") != "quality_hold"]   # holds are counted under changes.gate_holds
    return {"total": len(alerts), "counts": counts, "quality_holds": len(alerts) - len(shown),
            "items": [{"severity": a.get("severity"), "kind": a.get("kind"), "scope": a.get("scope"),
                       "country": a.get("country"), "message": _short(a.get("message"), 200)} for a in shown[:ALERT_ROWS]],
            "more": max(0, len(shown) - ALERT_ROWS)}


def notes_section(out_dir) -> dict:
    """The weekly brief and the newest notes of the research pack (notes_view's own index; ids, never paths, link
    to the GUI's Notes tab; `path` is relative to --out)."""
    from ..presentation import notes_view as NV
    try:
        head, entries = NV._index(out_dir)
    except Exception as e:                               # noqa: BLE001 - shown as unknown
        return {"status": "unknown", "message": f"research pack could not be read ({type(e).__name__})", "pack": {},
                "brief": None, "items": [], "total": 0}
    out = Path(out_dir).resolve()
    rows = []
    for e in entries.values():
        p = e.get("_path")
        try:
            rel = Path(p).resolve().relative_to(out).as_posix() if p else ""
            mtime = Path(p).stat().st_mtime if p else 0.0
        except (OSError, ValueError):
            rel, mtime = "", 0.0
        m = _DATE_RE.search(e.get("file") or "")
        rows.append({"id": e["id"], "kind": e["kind"], "kind_label": e["kind_label"], "title": e["title"],
                     "state": e.get("state"), "file": e.get("file"), "path": rel,
                     "date": m.group(1) if m else (head.get("pack") or {}).get("as_of"), "_mtime": mtime})
    rank = {"weekly_brief": 0, "trade_ideas": 1}
    rows.sort(key=lambda r: (r["date"] or "", r["_mtime"], -rank.get(r["kind"], 9)), reverse=True)
    for r in rows:
        r.pop("_mtime")
    brief = next((r for r in rows if r["kind"] == "weekly_brief"), None)
    items = [r for r in rows if r is not brief][:NOTE_ROWS]
    return {"status": head.get("status"), "message": head.get("message"), "pack": head.get("pack") or {},
            "brief": brief, "items": items, "total": len(rows)}


def open_items_section(data_dir, out_dir) -> dict:
    from .open_items import collect as oi_collect
    try:
        rep = oi_collect(data_dir, out_dir=out_dir)
    except Exception as e:                               # noqa: BLE001
        return {"open": None, "unknown": None, "items": [], "message": f"open items could not be read ({type(e).__name__})"}
    items = []
    for it in rep.get("items") or []:
        if it.get("status") == "clear":
            continue
        parked = it.get("kind") == "mac_pulls"           # PI-10/11: no Mac step until the MVP (team/when-sam-is-ready.md)
        items.append({"kind": it.get("kind"), "title": it.get("title"), "status": it.get("status"), "count": it.get("count"),
                      "summary": _short(it.get("summary")), "command": "" if parked else _short((it.get("commands") or [""])[0], 200),
                      "parked": parked})
    return {"open": rep.get("open"), "unknown": rep.get("unknown"), "items": items,
            "message": f"{rep.get('open')} open, {rep.get('unknown')} unreadable"}


def events_section(data_dir, as_of: str) -> dict:
    """Upcoming events from Team A's calendar (EQ-C-0155), `today` = the morning's target date. Never raises."""
    from ..presentation.calendar_view import morning_section
    return morning_section(data_dir, as_of)


# ---------------------------------------------------------------- the payload
def collect(data_dir, out_dir, as_of: str | None = None, run_info: dict | None = None, now: dt.datetime | None = None) -> dict:
    """The morning payload (SCHEMA; KEYS stable). Reads only. `run_info` is what the CLI did about the run
    ({"action": "ran" | "reused" | "not_run" | "failed", "message"}); the API passes None (action "shown")."""
    from ..persistence import Store
    from ..presentation.report import previous_run
    from ..versioning import data_hashes
    a = target_as_of(data_dir, as_of)
    ts = (now or dt.datetime.now(dt.timezone.utc)).strftime("%Y-%m-%dT%H:%M:%SZ")
    store = Store(Path(out_dir) / "store")
    cur = latest_base(store)
    info = dict(run_info or {"action": "shown", "message": "newest archived base run (the page never runs the model)"})
    base = {"schema": SCHEMA, "generated_utc": ts, "as_of": a}
    if cur is None:
        return base | {"status": "no_run", "run": info | {"run_id": None, "fresh": False, "reasons": ["no archived base run"]},
                       "previous": None, "limits": {"available": False, "rows": [], "worst": None, "light": None},
                       "changes": {"compared": False, "metrics": [], "pd_movers": [], "global_regime": {}, "regime_changes": [],
                                   "data": {}, "gate_holds": {}},
                       "alerts": {"total": 0, "counts": {}, "quality_holds": 0, "items": [], "more": 0},
                       "notes": notes_section(out_dir), "open_items": open_items_section(data_dir, out_dir),
                       "events": events_section(data_dir, a),
                       "message": "No archived base run: run `econquest morning --run` (or `econquest run`)."}
    prev = previous_run(store, cur)
    fr = freshness(cur, data_dir, a, data_hashes(data_dir))
    s = cur.get("summary") or {}
    v = _versions(cur)
    run = info | {"run_id": s.get("run_id"), "as_of": s.get("as_of"), "created_at": s.get("created_at"),
                  "label": s.get("label"), "code_hash": v.get("code_hash"), "data_hash": v.get("data_hash"),
                  "run_hash": v.get("run_hash"), "paths": (s.get("metrics") or {}).get("paths"),
                  "global_regime": s.get("global_regime"), "fresh": fr["fresh"], "reasons": fr["reasons"],
                  "code_note": fr.get("code_note", "")}
    ps = (prev or {}).get("summary") or {}
    previous = {"run_id": ps.get("run_id"), "as_of": ps.get("as_of"), "created_at": ps.get("created_at")} if prev else None
    alerts = alerts_list(cur, prev, data_dir)
    held = held_cells(data_dir)
    from ..presentation.dashboard import run_headline
    from ..presentation.mc_band import load_book_limits
    rep = base | {"status": "ok" if fr["fresh"] else "stale", "run": run, "previous": previous,
                  "limits": limits_section(cur, data_dir),
                  "changes": changes_section(cur, prev, data_dir, out_dir, fr, alerts, held),
                  "alerts": alerts_section(alerts), "notes": notes_section(out_dir),
                  "open_items": open_items_section(data_dir, out_dir), "events": events_section(data_dir, a),
                  "message": _short(run_headline(s, limits=load_book_limits(data_dir)), 400)}
    pw = plain_words_section(rep, data_dir, out_dir)
    if pw is not None:                                   # EQ-C-0172: left out entirely while the assistant is off
        rep["plain_words"] = pw
    return rep


def plain_words_section(rep: dict, data_dir, out_dir) -> dict | None:
    """EQ-C-0172 "In plain words": the assistant explains the day's drivers from this payload's own figures, through
    Team B's QA gate (assistant/surfaces.plain_words). None while the assistant is off (the key is then absent, so
    KEYS above stay the payload's keys) or when it fails; never raises, never runs the model engine."""
    try:
        from ..assistant.surfaces import plain_words
        return plain_words(rep, data_dir, out_dir)
    except Exception as e:                               # noqa: BLE001 - the morning view stands without the section
        return {"status": "error", "ok": False, "verdict": "", "text": f"In plain words unavailable ({type(e).__name__}).",
                "sources": [], "label": "model-assisted, not validated"}


# ---------------------------------------------------------------- text
def _mm(v, d=2) -> str:
    return "n/a" if v is None else f"{v:,.{d}f}"


def _signed(v, d=2, suffix="") -> str:
    return "n/a" if v is None else f"{v:+,.{d}f}{suffix}"


def render_text(rep: dict, out_dir=None) -> str:
    L = []
    r = rep["run"]
    L.append(f"econquest morning, as of {rep['as_of']} ({rep['generated_utc']})")
    L.append(f"Run {r.get('run_id') or 'none'} [{r.get('action')}] as of {r.get('as_of') or 'n/a'}, created {r.get('created_at') or 'n/a'}"
             + ("" if r.get("fresh") else f"; STALE: {'; '.join(r.get('reasons') or [])}"))
    if r.get("message") and r.get("action") not in ("shown",):
        L.append(f"  {_short(r['message'], 200)}")
    if r.get("code_note"):
        L.append(f"  note: {r['code_note']}")
    if rep["status"] == "no_run":
        L.append(rep["message"])
    lim = rep["limits"]
    if lim.get("rows"):
        L.append("")
        L.append(f"Limits (warning at {_mm(lim.get('warning_level'), 2)} of limit), $mm:")
        for x in lim["rows"]:
            band = f" band {_mm(x['band_lo'])}-{_mm(x['band_hi'])}" if x.get("band_lo") is not None else ""
            L.append(f"  [{x['light'].upper():5s}] {x['label']:14s} {_mm(x['value']):>9s} / {_mm(x['limit'], 1):>7s} "
                     f"({x['utilisation'] * 100:5.1f}%, warn {_mm(x['warning_mm'], 1)}){band}"
                     + (f"  ! {x['mc_note']}" if x.get("within_mc_error") else ""))
    elif rep["status"] != "no_run":
        L.append("Limits: data/limits.json not found or unreadable")
    ch = rep["changes"]
    if rep["status"] != "no_run":
        p = rep.get("previous")
        L.append("")
        L.append(f"Since {p['run_id']} (as of {p['as_of']}):" if p else "Since: no previous base run")
        if p:
            L.append("  " + "; ".join(f"{m['label']} {_mm(m['current'])} ({_signed(m['delta'])})" for m in ch["metrics"]))
            g = ch["global_regime"]
            L.append(f"  global regime {g.get('previous')} -> {g.get('current')}" if g.get("previous") != g.get("current")
                     else f"  global regime {g.get('current')} (unchanged)")
            if ch["pd_movers"]:
                L.append("  PD movers: " + "; ".join(f"{x['country']} {x['pd_previous'] * 100:.2f}% -> {x['pd_current'] * 100:.2f}% "
                                                    f"({x['delta_pp']:+.2f} pp)" for x in ch["pd_movers"]))
            else:
                L.append("  PD movers: none")
            L.append("  regime changes: " + ("; ".join(x["message"] for x in ch["regime_changes"]) if ch["regime_changes"] else "none"))
            d = ch["data"]
            moved = d.get("changed", []) + [f"+{x}" for x in d.get("added", [])] + [f"-{x}" for x in d.get("removed", [])]
            L.append("  data changes: " + (", ".join(moved) if moved else "none" if d.get("compared") else "not recorded on one of the runs"))
        d = ch.get("data") or {}
        if d.get("on_disk_since_run"):
            L.append("  data on disk changed since this run: " + ", ".join(d["on_disk_since_run"][:12])
                     + (" ..." if len(d["on_disk_since_run"]) > 12 else ""))
        gh = ch.get("gate_holds") or {}
        if gh.get("available"):
            nc = gh.get("new_count")
            L.append(f"  gate holds: {gh['held']} held, " + (f"{nc} new, {gh.get('cleared_count')} cleared" if nc is not None else "new unknown")
                     + f" ({gh.get('note')})")
            for c in gh.get("new") or []:
                L.append(f"    new hold: {c['table']} {c['key']} {c['country']}: {c['reason']}")
        elif gh:
            L.append(f"  gate holds: {gh.get('note')}")
    al = rep["alerts"]
    if rep["status"] != "no_run":
        c = al.get("counts") or {}
        L.append("")
        L.append(f"Alerts: {c.get('critical', 0)} critical, {c.get('warning', 0)} warning, {c.get('info', 0)} info"
                 + (f" ({al['quality_holds']} quality holds counted above)" if al.get("quality_holds") else ""))
        for a in al["items"]:
            L.append(f"  [{str(a['severity']).upper():8s}] {a['message']}")
        if al.get("more"):
            L.append(f"  ... {al['more']} more: econquest alerts")
    n = rep["notes"]
    L.append("")
    L.append(f"Research: {n.get('message')}")
    base = Path(out_dir) if out_dir else None
    for x in ([n["brief"]] if n.get("brief") else []) + list(n.get("items") or []):
        where = str(base / x["path"]) if base and x.get("path") else x.get("path") or x.get("file")
        L.append(f"  {x['kind_label']}: {x['title']} ({x.get('state') or 'not registered'}) {where}")
    oi = rep["open_items"]
    L.append("")
    L.append(f"Open items: {oi.get('message')}")
    for it in oi.get("items") or []:
        L.append(f"  [{str(it['status']).upper()}{' parked' if it.get('parked') else ''}] {it['title']}: {it['summary']}"
                 + (f"  ->  {it['command']}" if it.get("command") else ""))
    if rep.get("events"):
        from ..presentation.calendar_view import morning_lines
        L.append("")
        L += morning_lines(rep["events"])
    if rep.get("plain_words"):                           # EQ-C-0172: only present while the assistant is on
        from ..assistant.surfaces import plain_words_lines
        L.append("")
        L += plain_words_lines(rep["plain_words"])
    if rep["status"] != "no_run":
        L.append("")
        L.append(rep["message"])
    return "\n".join(L) + "\n"


# ---------------------------------------------------------------- CLI
def morning(data_dir, out_dir, as_of=None, run: bool | None = None, log=None, runner=None) -> dict:
    """CLI flow: decide about the run (run None = when needed, True = always, False = never), then collect()."""
    from ..persistence import Store
    from ..versioning import data_hashes
    a = target_as_of(data_dir, as_of)
    cur = latest_base(Store(Path(out_dir) / "store"))
    fr = freshness(cur, data_dir, a, data_hashes(data_dir))
    need = run is True or (run is None and not fr["fresh"])
    if need:
        code, last = (runner or run_base)(data_dir, out_dir, a, log=log)
        info = {"action": "ran" if code == 0 else "failed",
                "message": last if code == 0 else f"econquest run exited {code}: {last}"}
    elif fr["fresh"]:
        info = {"action": "reused", "message": "today's base run is current (same date and data)"}
    else:
        info = {"action": "not_run", "message": "--no-run: showing the newest base run; " + "; ".join(fr["reasons"])}
    rep = collect(data_dir, out_dir, a, run_info=info)
    if rep["run"].get("run_id"):
        try:
            save_holds_snapshot(out_dir, rep["run"]["run_id"], held_cells(data_dir))
        except OSError as e:                             # EQ-C-0164: e.g. ENOSPC; the view stands, the snapshot is retried next time
            from .backup import io_message
            (log or (lambda m: print(m, file=sys.stderr)))(f"[morning] {io_message(e, 'gate-hold snapshot not saved')}")
    return rep


def cmd_morning(args) -> None:
    run = True if args.run else False if args.no_run else None
    err = (lambda m: print(m, file=sys.stderr)) if args.json else print
    rep = morning(args.data, args.out, as_of=args.as_of, run=run, log=err)
    if args.json:
        print(json.dumps(rep, indent=1, default=str))
    else:
        print(render_text(rep, out_dir=args.out), end="")
    if rep["run"].get("action") == "failed" or rep["status"] == "no_run":
        sys.exit(1)


def register(sub) -> None:
    mo = sub.add_parser("morning", help="the daily desk view on one screen: reuse or make today's base run, then limits with "
                        "traffic lights, changes since the previous run (metrics, PD movers, regimes, data files, gate holds), "
                        "alerts, the newest research notes and the open items (EQ-C-0132; the GUI Home tab shows the same)")
    from ..cli import _as_of_arg
    mo.add_argument("--as-of", type=_as_of_arg, help="target date YYYY-MM-DD (default: settings as_of, else today)")
    g = mo.add_mutually_exclusive_group()
    g.add_argument("--run", action="store_true", help="always make a new base run first")
    g.add_argument("--no-run", action="store_true", help="never run: show the newest base run, stale or not")
    mo.add_argument("--json", action="store_true", help=f"print the payload as JSON ({SCHEMA}; stable top-level keys)")
    mo.set_defaults(fn=cmd_morning)
