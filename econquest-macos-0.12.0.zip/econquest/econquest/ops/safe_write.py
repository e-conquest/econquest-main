"""Atomic file writes that never follow a planted temp-file symlink (SEC-C-017 L6, SEC-C-018 L6; EQ-C-0165).

    write_atomic(path, data)    bytes to <dir>/.<name>.<random>.tmp, created O_CREAT|O_EXCL|O_NOFOLLOW, then os.replace

The temp name is random per call, and exclusive create refuses any file or link already at that name, so a symlink
planted under outputs/ cannot redirect the write outside the folder. The final os.replace swaps the directory entry
itself (it does not write through a symlink at `path`).
"""
from __future__ import annotations

import os
import secrets
from pathlib import Path

_FLAGS = os.O_WRONLY | os.O_CREAT | os.O_EXCL | getattr(os, "O_NOFOLLOW", 0) | getattr(os, "O_BINARY", 0)


def write_atomic(path, data: bytes | str, mode: int = 0o644) -> Path:
    path = Path(path)
    if isinstance(data, str):
        data = data.encode("utf-8")
    tmp = path.with_name(f".{path.name}.{secrets.token_hex(6)}.tmp")
    fd = os.open(tmp, _FLAGS, mode)
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise
    return path
