"""Plain-English messages for the most common econquest failures (EQ-C-0135).

One central map: each failure has an id, a one-line plain explanation, the exact next command and a docs link.
The CLI's top-level handler (econquest/cli.py main) calls ``hint_for_exit`` on every refusal (SystemExit with a
message) and prints the plain-English block above the original message; the exit code is never changed. For an
uncaught exception on a real command line (``main()`` with no argv) ``friendly_exception`` prints the block instead
of a traceback and exits 1 (ECONQUEST_DEBUG=1 keeps the traceback). ``econquest explain <id>`` prints one entry,
``econquest explain`` lists them all.

Read only: nothing here writes a file, reaches the network or changes a setting. Next commands are ones that run in
the cloud on shared data, offline; a step that is Sam's decision says so and points at team/when-sam-is-ready.md.
"""
from __future__ import annotations

import errno
import os
import re
import sys
from dataclasses import dataclass

@dataclass(frozen=True)
class Failure:
    id: str
    title: str
    plain: str             # one line, no jargon
    next_cmd: str          # the exact next command to type
    docs: str              # repo-relative docs link
    patterns: tuple = ()   # regexes matched against "<ExceptionType>: <message>"
    errnos: tuple = ()     # OSError errno values


FAILURES: tuple[Failure, ...] = (
    Failure("no-stored-run", "No saved model run",
            "There is no saved model run yet, so there is nothing to report, publish or compare.",
            "econquest run", "docs/quickstart.md#2-first-run",
            (r"No base run archived", r"is not archived in", r"No (stored|archived) run", r"no runs? (in|archived)",
             r"No such file.*run_latest\.json", r"No trade-idea log in")),
    Failure("licence-baseline-missing", "Licence register has no approved version",
            "The licence register (data/licences.csv) has never been approved, so client output and the evidence "
            "build stay switched off; internal use still works.",
            "econquest client-check", "docs/runbooks/A-licence-register.md",
            (r"has no approved version yet", r"no real baseline", r"licence register .*invalid",
             r"LicenceTableError", r"RegisterError")),
    Failure("demo-baseline-open", "A DEMO licence profile is open",
            "A DEMO licence baseline is only a rehearsal, not Sam's approval, so workbook writes and client output "
            "are refused while it is open.",
            "econquest client-check", "docs/quickstart.md#6-what-demo-means-on-the-evidence-bundle",
            (r"DEMO baseline: not Sam's approval", r"DEMO profile")),
    Failure("ledger-chain-broken", "A hash-chained log does not verify",
            "One of the tamper-evident logs (review ledger, action log or approvals log) no longer checks out, so "
            "econquest refuses to write on top of it.",
            "econquest review verify", "docs/runbooks/A-restore.md",
            (r"hash chain broken", r"LedgerChainError", r"approvals log does not verify", r"chain_broken",
             r"prev_hash", r"row_hash mismatch")),
    Failure("review-ledger-missing", "The review ledger is missing",
            "The review ledger (data/live/review_ledger.csv) that records who accepted each fetched value is "
            "missing although earlier fetches exist, so nothing is applied.",
            "econquest review verify", "docs/runbooks/A-data-ops.md",
            (r"review ledger missing", r"LedgerMissingError")),
    Failure("run-gate-blocked", "Run gate: unattested hand-entered cells",
            "Some hand-typed inputs (CDS quotes, adjustments, manual FX) have not been attested, and this command "
            "is set to stop until they are.",
            "econquest open-items", "docs/runbooks/A-market-data.md",
            (r"run gate: blocked", r"unattested hand-entered cells", r"RunGateBlocked")),
    Failure("stale-data", "Live data is out of date",
            "The newest data pull is older than the allowed age (7 days by default), so figures may be out of date; "
            "the run still uses the last saved vintage.",
            "econquest health", "docs/runbooks/A-data-ops.md",
            (r"stale_feed", r"\bstale (data|feed|vintage|pull)", r"(data|feed|pull|vintage)s? (is|are) stale",
             r"live pull .*older than")),
    Failure("port-in-use", "The GUI port is already taken",
            "Another program (often an earlier econquest gui) is already using that port on this computer.",
            "econquest gui --port 8766", "docs/quickstart.md#3-open-the-gui",
            (r"Address already in use", r"only one usage of each socket address"),
            (errno.EADDRINUSE,)),
    Failure("unzipped-tree", "Running from the unzipped download",
            "This is the unzipped release folder, which has no data/ folder of its own; install it first and run "
            "econquest from the install.",
            "bash install.sh", "docs/quickstart.md#1-install-from-downloads",
            (r"is an unzipped econquest release", r"release-data/ and no data/")),
    Failure("missing-token", "No Google Sheets token for --write",
            "Writing to the live workbook needs a Sheets token, and none was found; the Sheets credential is Sam's "
            "(team/when-sam-is-ready.md). A dry run or an xlsx export needs no token.",
            "econquest publish --dry-run", "docs/runbooks/A-publish.md",
            (r"--write needs a Sheets token", r"cannot read --token-file", r"--token-file .* is empty")),
    Failure("offline-fetch", "No network for a live fetch",
            "This computer cannot reach the data sources (IMF, World Bank, BIS, ECB); the cloud works offline from "
            "the saved vintages, and live pulls are parked for Sam's Mac.",
            "econquest run", "docs/runbooks/A-fetch-on-mac.md",
            (r"URLError", r"Name or service not known", r"Temporary failure in name resolution", r"Network is unreachable",
             r"nodename nor servname", r"getaddrinfo failed", r"Tunnel connection failed", r"Max retries exceeded",
             r"ConnectionError", r"Connection refused", r"timed out"),
            (errno.ENETUNREACH, errno.EHOSTUNREACH, errno.ECONNREFUSED)),
    Failure("no-price-history", "No market price history",
            "The market price file (data/market_history/prices.csv) is missing, so GARCH, the daily record and the "
            "trade-idea P&L cannot run.",
            "econquest health", "docs/runbooks/A-official-fx.md",
            (r"No price history", r"No such file.*market_history/prices\.csv")),
)
BY_ID = {f.id: f for f in FAILURES}


def _text(exc) -> str:
    if isinstance(exc, SystemExit):
        return f"{type(exc).__name__}: {exc.code if not isinstance(exc.code, int) else getattr(exc, 'reason', '')}"
    return f"{type(exc).__name__}: {exc}"


def classify(exc) -> Failure | None:
    """The Failure an exception (or a refusal message string) matches, or None. First match in FAILURES order."""
    if isinstance(exc, str):
        text, eno = exc, None
    else:
        text = _text(exc)
        eno = getattr(exc, "errno", None)
        if eno is None and isinstance(getattr(exc, "reason", None), OSError):   # urllib URLError wraps the OSError
            eno = exc.reason.errno
    for f in FAILURES:
        if eno is not None and eno in f.errnos:
            return f
        if any(re.search(p, text) for p in f.patterns):
            return f
    return None


def render(f: Failure) -> str:
    return (f"econquest [{f.id}] {f.plain}\n"
            f"  Next: {f.next_cmd}\n"
            f"  More: {f.docs}  (econquest explain {f.id})")


def _enabled() -> bool:
    return os.environ.get("ECONQUEST_PLAIN_ERRORS", "1") != "0"


def hint_for_exit(e: SystemExit, stream=None) -> Failure | None:
    """Print the plain-English block for a refusal (SystemExit with a message, or RunGateBlocked) to stderr.
    The SystemExit itself is left untouched, so its message and exit code are exactly as before."""
    if not _enabled() or (e.code is None or (isinstance(e.code, int) and not hasattr(e, "reason"))):
        return None
    f = classify(e)
    if f:
        print(render(f), file=stream or sys.stderr)
    return f


def friendly_exception(e: BaseException, stream=None) -> None:
    """For an uncaught exception on a real command line: print the plain-English block plus the one-line original
    error and raise SystemExit(1) (the exit code an uncaught exception gives) instead of showing a traceback.
    Returns normally (the caller re-raises, keeping the traceback) when the failure is not in the map, when
    ECONQUEST_DEBUG=1, or for KeyboardInterrupt."""
    if isinstance(e, (KeyboardInterrupt, SystemExit)) or os.environ.get("ECONQUEST_DEBUG") == "1" or not _enabled():
        return
    f = classify(e)
    if not f:
        return
    s = stream or sys.stderr
    print(render(f), file=s)
    print(f"  (original error: {type(e).__name__}: {' '.join(str(e).split())[:300]}; ECONQUEST_DEBUG=1 shows the traceback)",
          file=s)
    raise SystemExit(1) from None


def explain(fid: str | None = None) -> tuple[int, str]:
    if not fid:
        lines = ["Common econquest failures (econquest explain <id> for one):"]
        lines += [f"  {f.id:<26} {f.title}" for f in FAILURES]
        return 0, "\n".join(lines)
    f = BY_ID.get(fid.strip().lower())
    if not f:
        return 2, f"unknown failure id {fid!r}; known: {', '.join(BY_ID)}"
    return 0, "\n".join([f"{f.id}: {f.title}", "", f.plain, "", f"Next: {f.next_cmd}", f"Docs: {f.docs}"])


def cmd_explain(args) -> None:
    code, text = explain(getattr(args, "failure_id", None))
    print(text, file=sys.stdout if code == 0 else sys.stderr)
    if code:
        raise SystemExit(code)


def register(sub) -> None:
    p = sub.add_parser("explain", help="plain-English explanation, next command and docs link for a common failure id "
                                       "(the [id] printed with an error); no id lists them all (EQ-C-0135)")
    p.add_argument("failure_id", nargs="?", help="e.g. no-stored-run, port-in-use, offline-fetch")
    p.set_defaults(fn=cmd_explain)
