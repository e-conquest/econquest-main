"""Keyed ledger heads (EQ-C-0076, threat model T11, decision D4 in team/security/D4-keyed-ledgers.md). OFF by default.

The hash-chained ledgers (change approvals, action log, deliveries, editorial) prove internal consistency only: whoever
can write the folder can rewrite the rows and the head together. With this option on, every append also writes a seal
next to the ledger, an HMAC-SHA256 over the ledger name and its last (seq, row_hash), and verify checks it. Since each
row_hash covers every row before it, the seal covers the whole chain; forging it needs the key.

- Switch: `"ledger_keyed_heads": true` in `<home>/ops.json` (home = $ECONQUEST_HOME, else the source checkout). Any
  other value, a missing or unreadable ops.json means off, and then nothing here reads a key, writes a file or adds a
  verify error: the ledgers behave exactly as without this module.
- Key: $ECONQUEST_LEDGER_KEY, else the macOS Keychain item `econquest-ledger-key`
  (`security find-generic-password -s econquest-ledger-key -w`). Never from argv or a file. At least 32 characters
  (e.g. `openssl rand -hex 32`). The seal stores a key id (an HMAC of a fixed label), never the key.
- Losing the key while the option is on makes every verify fail, and the approvals and editorial ledgers then refuse
  new entries. Back the key up before turning the option on (D4 note).

Seal files: `<approvals>/head.hmac.json`, `actions.head.hmac.json` beside the action log,
`store/deliveries.head.hmac.json`, `editorial/ledger.head.hmac.json`,
`store/client_deliveries.head.hmac.json` (EQ-C-0107). Every verify problem starts with PREFIX.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import os
import tempfile
from pathlib import Path

ENV = "ECONQUEST_LEDGER_KEY"
SERVICE = "econquest-ledger-key"
CONFIG_KEY = "ledger_keyed_heads"
MIN_KEY_LEN = 32
VERSION = 1
PREFIX = "keyed head: "
SEAL_NAMES = {"approvals": "head.hmac.json", "actions": "actions.head.hmac.json",
              "deliveries": "deliveries.head.hmac.json", "editorial": "ledger.head.hmac.json",
              "client_deliveries": "client_deliveries.head.hmac.json",       # EQ-C-0107 (SEC-C-018)
              "archive": "index.head.hmac.json"}                             # EQ-C-0154 research archive


class LedgerKeyError(ValueError):
    """The key is unusable (too short)."""


def home_dir(home=None) -> Path:
    return Path(home) if home else Path(os.environ.get("ECONQUEST_HOME") or Path(__file__).resolve().parents[2])


def config_state(home=None) -> tuple[bool, str]:
    """(enabled, where it was decided). Only a JSON object with ledger_keyed_heads exactly true enables it."""
    p = home_dir(home) / "ops.json"
    if not p.exists():
        return False, f"{p} absent (off by default)"
    try:
        cfg = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        return False, f"{p} unreadable ({type(e).__name__}): off"
    if isinstance(cfg, dict) and cfg.get(CONFIG_KEY) is True:
        return True, f"{p} {CONFIG_KEY}: true"
    return False, f"{p} has no {CONFIG_KEY}: true (off)"


def enabled(home=None) -> bool:
    return config_state(home)[0]


def _keychain_key() -> str | None:
    import shutil
    import subprocess
    exe = shutil.which("security")
    if not exe:
        return None
    try:
        r = subprocess.run([exe, "find-generic-password", "-s", SERVICE, "-w"], capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.SubprocessError):
        return None
    k = (r.stdout or "").strip()
    return k if r.returncode == 0 and k else None


def key_source() -> tuple[bytes | None, str]:
    """(key, where it came from). Raises LedgerKeyError for a key that is present but too short."""
    raw, src = os.environ.get(ENV, "").strip(), f"${ENV}"
    if not raw:
        raw, src = (_keychain_key() or ""), f"Keychain item '{SERVICE}'"
    if not raw:
        return None, "none"
    if len(raw) < MIN_KEY_LEN:
        raise LedgerKeyError(f"the ledger key from {src} is shorter than {MIN_KEY_LEN} characters")
    return raw.encode("utf-8"), src


def key_id(key: bytes) -> str:
    return hmac.new(key, b"econquest-ledger-key-id/v1", hashlib.sha256).hexdigest()[:16]


def head_mac(key: bytes, ledger: str, seq: int, row_hash: str) -> str:
    msg = f"econquest-ledger-head/v{VERSION}\n{ledger}\n{int(seq)}\n{row_hash}".encode("utf-8")
    return hmac.new(key, msg, hashlib.sha256).hexdigest()


def _atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


def write_seal(ledger: str, path, seq: int, row_hash: str, key: bytes) -> dict:
    doc = {"v": VERSION, "ledger": ledger, "seq": int(seq), "row_hash": str(row_hash), "key_id": key_id(key),
           "hmac": head_mac(key, ledger, seq, row_hash)}
    _atomic_write(Path(path), (json.dumps(doc) + "\n").encode())
    return doc


def seal(ledger: str, path, seq: int, row_hash: str, home=None) -> dict | None:
    """Called after every append (under the ledger's lock). Off, or no usable key: does nothing (verify then reports
    the missing seal). Never raises: the append it follows has already happened."""
    if not enabled(home):
        return None
    try:
        key, _ = key_source()
    except LedgerKeyError:
        return None
    if key is None:
        return None
    try:
        return write_seal(ledger, path, seq, row_hash, key)
    except OSError:
        return None


def check(ledger: str, path, seq: int, row_hash: str, home=None) -> list[str]:
    """Verify problems for one ledger whose last row is (seq, row_hash); seq 0 means empty. [] when off."""
    if not enabled(home):
        return []
    try:
        key, _ = key_source()
    except LedgerKeyError as e:
        return [PREFIX + f"{ledger}: {e}"]
    if key is None:
        return [PREFIX + f"{ledger}: keyed heads are on ({CONFIG_KEY} in ops.json) but no key: set ${ENV} or add the "
                f"Keychain item '{SERVICE}' (econquest ledger-key init)"]
    p = Path(path)
    if not p.exists():
        return [] if int(seq or 0) == 0 else [PREFIX + f"{ledger}: seal {p.name} missing (written before the option "
                                                        "was on? run econquest ledger-key seal; or removed)"]
    try:
        doc = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return [PREFIX + f"{ledger}: seal {p.name} is not JSON"]
    if not isinstance(doc, dict):
        return [PREFIX + f"{ledger}: seal {p.name} is not a JSON object"]
    errs = []
    if doc.get("ledger") != ledger:
        errs.append(PREFIX + f"{ledger}: seal {p.name} is for ledger {doc.get('ledger')!r}")
    if doc.get("key_id") != key_id(key):
        errs.append(PREFIX + f"{ledger}: seal made with a different key (key id {doc.get('key_id')!r})")
    elif not hmac.compare_digest(str(doc.get("hmac", "")),
                                 head_mac(key, ledger, doc.get("seq") if isinstance(doc.get("seq"), int) else -1,
                                          str(doc.get("row_hash", "")))):
        errs.append(PREFIX + f"{ledger}: seal HMAC does not match (seal edited or forged)")
    if (doc.get("seq"), doc.get("row_hash")) != (int(seq or 0), row_hash):
        errs.append(PREFIX + f"{ledger}: seal names seq {doc.get('seq')} but the ledger ends at seq {seq} "
                    "(rows or head rewritten without the key, or an older seal restored)")
    return errs


def init_instructions() -> str:
    """What Sam runs to create and back up the key, and to switch the option on. Prints, never generates or stores."""
    return "\n".join([
        "Keyed ledger heads are OFF until you do all of the following (decision D4, team/security/D4-keyed-ledgers.md).",
        "1. Create the key in your login Keychain. The command asks for the password; paste the output of",
        "   `openssl rand -hex 32` (at least 32 characters):",
        f"     security add-generic-password -s {SERVICE} -a \"$USER\" -w",
        "2. Back it up before going further: losing it makes every ledger verify fail. Copy it into the desk password",
        "   manager (or print it once, offline):",
        f"     security find-generic-password -s {SERVICE} -w",
        f"3. Switch the option on: add \"{CONFIG_KEY}\": true to <home>/ops.json ({home_dir() / 'ops.json'}).",
        "4. Seal the current heads of the ledgers that verify: econquest ledger-key seal",
        "5. Check: econquest ledger-key status, and econquest log verify / change verify.",
        f"Scheduled jobs and other machines need the same key (${ENV} or the Keychain item); it is never read from argv",
        "or from a file in the project.",
    ])
