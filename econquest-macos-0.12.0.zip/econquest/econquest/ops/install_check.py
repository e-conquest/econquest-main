"""Install-integrity warnings for `econquest next` (top lines) and `econquest health --daily` (EQ-C-0112).

Sam's 0.5.0 Mac showed 17 restricted Yahoo-era fx3m cells he had already replaced: ~/econquest had been replaced by
a fresh copy of the release, whose data/ seed files reset his applied live data, and no backup existed. From 0.6.0
the release ships its seed data as release-data/ with release-data/SEED-HASHES.json (scripts/build_release.py:
sha256 of every seed file and the shipped vintage ids), install.sh copies release-data/ into the install and writes
.econquest-installed. This module reads only and reports:

  (a) running_elsewhere  the data folder in use is not <install>/data, or the package is not under <install>, while
                         the folder in use is an unzipped release (it has release-data/ or RELEASE-MANIFEST.txt): a
                         Downloads copy. <install> = $ECONQUEST_HOME, else ~/econquest.
  (b) no_backup          for the installed folder (<install>/data, or a folder with the install marker): neither an
                         installer backup ($ECONQUEST_BACKUP_DIR or ~/econquest-backups, <UTC time>/ folders) nor a
                         nightly archive ($ECONQUEST_BACKUP_DEST or ~/econquest-backups/nightly) exists.
  (c) seed_reset         data/live/live_inputs.csv, indicators.csv or countries.csv is byte-identical to the shipped
                         seed while vintages the release did not ship exist: "re-apply your latest vintage", with the
                         review commands (Team A, docs/runbooks/A-fetch-on-mac.md) and the newest pre-apply snapshot.
  (d) fresh_over_deleted data/live/vintages holds only the shipped vintages plus at most one more, while
                         data/live/review_ledger.csv or data/approvals/log.jsonl names vintage ids not on disk.

(c) and (d) need release-data/SEED-HASHES.json next to data/ (an install from 0.6.0 on); without it they stay silent.
Every command printed is a real subcommand (tests/test_install_check.py parses each one with the CLI's argparse).
"""
from __future__ import annotations

import csv
import datetime as dt
import hashlib
import json
import os
import re
import shlex
from pathlib import Path

SEED_DIR = "release-data"
SEED_HASHES = "SEED-HASHES.json"
MARKER = ".econquest-installed"
WATCHED = ("live/live_inputs.csv", "indicators.csv", "countries.csv")
PACKAGE_ROOT = Path(__file__).resolve().parents[2]
# SEC-C-018: whole-name patterns. A vintage id is printed inside a shell command, so a folder or ledger value such as
# "2026-10-25; curl ... | sh" must never pass for one (feeds.save_vintage writes <YYYY-MM-DD>T<HHMMSS>Z-<hash8>, legacy
# ids are a date). An installer backup is <UTC time>[-pid]/ holding data/ or outputs/ (install.sh backup_now).
_UTC_DIR = re.compile(r"^\d{8}T\d{6}Z(?:-\d+)?\Z")
_VID = re.compile(r"^(\d{4}-\d{2}-\d{2})(?:T(\d{6})Z-[0-9a-f]{8})?\Z")
_SAFE_NAME = re.compile(r"^[A-Za-z0-9._-]+\Z")


def _sha(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _tilde(p: Path, user_home: Path) -> str:
    try:
        return "~/" + Path(p).resolve().relative_to(Path(user_home).resolve()).as_posix()
    except ValueError:
        return str(p)


def _sh(p: Path, user_home: Path) -> str:
    """A path for a printed shell command: ~/ kept outside the quotes so the shell still expands it, the rest quoted
    (SEC-C-018: "~/Downloads/econquest 9" must stay one argument)."""
    t = _tilde(p, user_home)
    return "~/" + shlex.quote(t[2:]) if t.startswith("~/") else shlex.quote(t)


def _same(a: Path, b: Path) -> bool:
    try:
        return Path(a).resolve() == Path(b).resolve()
    except OSError:
        return False


def _under(p: Path, root: Path) -> bool:
    try:
        Path(p).resolve().relative_to(Path(root).resolve())
        return True
    except ValueError:
        return False


def load_seed(root: Path) -> dict | None:
    p = Path(root) / SEED_DIR / SEED_HASHES
    try:
        m = json.loads(p.read_text())
    except (OSError, ValueError):
        return None
    return m if isinstance(m, dict) and isinstance(m.get("files"), dict) else None


def vintage_time(vid: str) -> dt.datetime | None:
    m = _VID.match(vid)
    if not m:
        return None
    try:
        day = dt.date.fromisoformat(m.group(1))
        if m.group(2):
            t = m.group(2)
            return dt.datetime(day.year, day.month, day.day, int(t[:2]), int(t[2:4]), int(t[4:]), tzinfo=dt.timezone.utc)
        return dt.datetime(day.year, day.month, day.day, 23, 59, 59, tzinfo=dt.timezone.utc)
    except ValueError:                                   # 2026-13-45 or T256100Z: not a time
        return None


def vintages_on_disk(data_dir: Path) -> list[str]:
    root = Path(data_dir) / "live" / "vintages"
    if not root.is_dir():
        return []
    return sorted(p.name for p in root.iterdir() if p.is_dir() and _VID.match(p.name))


def referenced_vintages(data_dir: Path) -> set[str]:
    """Vintage ids named by the review ledger (vintage_id) and the approvals log (any "vintage"/"vintage_id" field)."""
    out: set[str] = set()
    led = Path(data_dir) / "live" / "review_ledger.csv"
    if led.is_file():
        with open(led, newline="", encoding="utf-8") as f:
            for row in csv.DictReader(f):
                v = str(row.get("vintage_id") or "").lstrip("'").strip()
                if v:
                    out.add(v)
    log = Path(data_dir) / "approvals" / "log.jsonl"
    if log.is_file():
        for line in log.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                rec = json.loads(line)
            except ValueError:
                continue
            stack = [rec]
            while stack:
                x = stack.pop()
                if isinstance(x, dict):
                    for k, v in x.items():
                        if k in ("vintage", "vintage_id") and isinstance(v, str) and _VID.match(v):
                            out.add(v)
                        elif isinstance(v, (dict, list)):
                            stack.append(v)
                elif isinstance(x, list):
                    stack.extend(x)
    return {v for v in out if _VID.match(v)}


def has_backup(env: dict, user_home: Path) -> bool:
    inst = Path(env.get("ECONQUEST_BACKUP_DIR") or Path(user_home) / "econquest-backups").expanduser()
    if inst.is_dir() and any(d.is_dir() and _UTC_DIR.match(d.name) and ((d / "data").is_dir() or (d / "outputs").is_dir())
                             for d in inst.iterdir()):
        return True
    nightly = Path(env.get("ECONQUEST_BACKUP_DEST") or Path(user_home) / "econquest-backups" / "nightly").expanduser()
    if nightly.is_dir() and any(d.is_dir() and any(d.glob("econquest-*.tar.gz")) for d in nightly.iterdir()):
        return True
    return False


def backup_command(home: Path, user_home: Path, expected: Path | None = None) -> str:
    """`econquest backup --verify` (the installed launcher sets ECONQUEST_HOME); for another folder, --out names it
    (ops.commands._home is the parent of --out). SEC-C-018: not `python -m ...`, which on a Mac is either missing or
    a Python without econquest."""
    if expected is not None and _same(home, expected):
        return "econquest backup --verify"
    return f"econquest --out {_sh(Path(home) / 'outputs', user_home)} backup --verify"


def _w(wid: str, message: str, commands=(), **extra) -> dict:
    return {"id": wid, "message": message, "commands": list(commands), **extra}


def install_warnings(data_dir, env: dict | None = None, user_home=None, package_root=None) -> list[dict]:
    """Every install warning that applies, as {id, message, commands}. Reads only; never raises for a bad file."""
    env = dict(os.environ if env is None else env)
    user_home = Path(user_home or Path.home())
    data_dir = Path(data_dir)
    root = data_dir.parent
    pkg = Path(package_root or PACKAGE_ROOT)
    expected = Path(env.get("ECONQUEST_HOME") or user_home / "econquest").expanduser()
    out: list[dict] = []

    # (a) a Downloads copy: the folder in use is an unzipped release, but not the install
    def is_release_copy(p: Path) -> bool:
        return (p / SEED_DIR).is_dir() or (p / "RELEASE-MANIFEST.txt").is_file()
    wrong_data = not _same(data_dir, expected / "data")
    wrong_pkg = not _under(pkg, expected)
    if (wrong_data and is_release_copy(root)) or (wrong_pkg and is_release_copy(pkg)):
        where = [f"data folder {data_dir}" if wrong_data else "", f"program {pkg}" if wrong_pkg else ""]
        out.append(_w("running_elsewhere",
                      f"econquest is running from a copy that is not your install ({' and '.join(w for w in where if w)}; "
                      f"the install is {_tilde(expected, user_home)}): this looks like the unzipped release in Downloads. "
                      f"Run install.command from it, then use the `econquest` command (which runs from {_tilde(expected, user_home)}).",
                      [f"econquest --data {_sh(expected / 'data', user_home)} next"]))

    installed = _same(data_dir, expected / "data") or (root / MARKER).is_file()
    # (b) no backup of the installed folder
    if installed and not has_backup(env, user_home):
        out.append(_w("no_backup",
                      "no backup of this install exists (none in ~/econquest-backups/<UTC time>/ nor in "
                      f"{_tilde(Path(env.get('ECONQUEST_BACKUP_DEST') or user_home / 'econquest-backups' / 'nightly'), user_home)}): "
                      "make one now, then install the nightly job",
                      [backup_command(root, user_home, expected), "econquest schedule install --load"]))

    seed = load_seed(root)
    if seed is None:
        return out
    shipped = {str(v) for v in seed.get("vintages") or []}
    on_disk = vintages_on_disk(data_dir)
    own = [v for v in on_disk if v not in shipped]

    # (c) applied data reset to the seed while own vintages exist
    same = []
    for rel in WATCHED:
        p = data_dir / rel
        want = seed["files"].get(rel)
        try:
            if want and p.is_file() and _sha(p) == want:
                same.append(rel)
        except OSError:
            continue
    if same and own:
        latest = own[-1]
        reset_at = max((data_dir / r).stat().st_ctime for r in same)
        vt = vintage_time(latest)
        cmds = []
        after = vt is not None and vt.timestamp() > reset_at
        if after:
            cmds.append(f"econquest review list --pending --vintage {latest}")
        cmds += [f"econquest review apply --vintage {latest} --dry-run", f"econquest review apply --vintage {latest}"]
        snaps = sorted(p.name for p in (data_dir / "live" / "snapshots").glob("*-pre-apply") if p.is_dir() and _SAFE_NAME.match(p.name)) \
            if (data_dir / "live" / "snapshots").is_dir() else []
        msg = (f"your applied live data looks reset to the release seed; re-apply your latest vintage ({latest}). "
               f"{', '.join('data/' + r for r in same)} {'is' if len(same) == 1 else 'are'} identical to the "
               f"{seed.get('version') or 'release'} seed while {len(own)} vintage(s) of your own exist.")
        if after:
            msg += (f" {latest} was fetched after the reset, so its holds were computed against seed values: "
                    "review its held cells first.")
        msg += (f" Pre-apply copies of indicators.csv and countries.csv: data/live/snapshots/{snaps[-1]}/ (newest of {len(snaps)})."
                if snaps else " No data/live/snapshots/<ts>-pre-apply/ folder is left to restore from.")
        out.append(_w("seed_reset", msg, cmds, files=same, vintage=latest, fetched_after_reset=after))

    # (d) a fresh copy over a deleted folder: vintages the ledger or approvals log name are gone
    refs = referenced_vintages(data_dir)
    missing = sorted(refs - set(on_disk))
    if len(own) <= 1 and missing:
        out.append(_w("fresh_over_deleted",
                      "this install looks fresh over a deleted folder; older vintages and applied data are gone; take a "
                      f"backup now ({len(missing)} vintage id(s) named in review_ledger.csv or the approvals log are not "
                      f"in data/live/vintages/, e.g. {', '.join(missing[:3])}). Restore older data from ~/econquest-backups "
                      "if any copy exists.",
                      [backup_command(root, user_home, expected)], missing_vintages=missing))
    return out


def safe_warnings(data_dir, **kw) -> list[dict]:
    try:
        return install_warnings(data_dir, **kw)
    except Exception as e:                               # noqa: BLE001 - a check never hides the caller's report
        return [_w("install_check_error", f"install check could not run ({type(e).__name__})")]


def lines(warns: list[dict]) -> list[str]:
    out = []
    for w in warns:
        out.append(f"WARNING: {w['message']}")
        out += [f"  $ {c}" for c in w["commands"]]
    return out


def unzipped_release_problem(data_dir, package_root=None) -> str | None:
    """SEC-C-018 (EQ-C-0112): the message when the CLI runs straight from an unzipped release (it has release-data/
    and no data/), e.g. `python -m econquest run` in ~/Downloads/econquest; None otherwise. A source checkout (no
    release-data/) and any existing data folder pass."""
    pkg = Path(package_root or PACKAGE_ROOT)
    d = Path(data_dir).expanduser()
    if d.is_dir() or not (pkg / SEED_DIR).is_dir():
        return None
    return (f"{d} does not exist: {pkg} is an unzipped econquest release, which ships its seed data as {SEED_DIR}/ and "
            "has no data/ folder. Install it first (double-click install.command, or: bash install.sh) and then use "
            "the `econquest` command, which runs from your install (~/econquest); or pass --data <your data folder>. "
            "Nothing was changed.")
