"""`econquest mac-pull` (EQ-C-0073): Sam's one command for every pull that only his Mac can run. It wraps Team A's
pull pack (econquest.ingestion.pullpack, contract HO-20261024-A-C-008) through its public entry points only: plan,
run, status, report, exit_code and PackOptions. Nothing here re-implements a step or reads state keys outside the
contract.

    econquest mac-pull [plan]           # preflight, the default: changes nothing, no network
    econquest mac-pull run [--steps a,b] [--redo STEP|all] [--apply-fx] [--crag-xlsx PATH] ...
    econquest mac-pull status           # one line per step
    econquest mac-pull report           # writes data/live/pullpack/report.md + report.json, prints the plain summary

Exit codes pass through from the pack: 0 every selected step done, 2 something skipped / held / not yet run,
1 a step failed or a usage error. `plan` exits 0, or 1 when this Python is too old to run the pack.

Preflight checks: Python 3.12 or newer; free disk against the pack's own per-step estimates; which steps are done;
the UCDP token by environment-variable name or Keychain item name only (its value is never read here); network
reachability is NOT tested: the pack probes each host on the Mac just before its step, so the preflight lists the
hosts and says "will be checked on your Mac".
"""
from __future__ import annotations

import json
import re
import sys
from pathlib import Path

MIN_PYTHON = (3, 12)
EXIT_DONE, EXIT_FAILED, EXIT_INCOMPLETE = 0, 1, 2      # same values as pullpack (checked by tests)
RUN = "econquest mac-pull run"
WORDS = {"done": "done", "held": "held (needs your decision)", "skipped": "skipped", "failed": "FAILED",
         "pending": "not run yet", "running": "interrupted"}


def _pack():
    from ..ingestion import pullpack
    return pullpack


def _human(n) -> str:
    n = float(n or 0)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024 or unit == "TB":
            return f"{n:.0f} {unit}" if unit == "B" else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"


_CTRL = re.compile(r"[\x00-\x08\x0b-\x1f\x7f-\x9f]")


def _ours(text: str) -> str:
    """The pack's own command lines, rewritten to this command (same functions underneath). Control characters are
    dropped first: reasons can carry upstream error text, and an escape sequence must not reach the terminal
    (SEC-C-011 I1)."""
    t = _CTRL.sub("", str(text or ""))
    for old in ("python -m econquest.ingestion.pullpack run", "pullpack run"):
        t = t.replace(old, RUN)
    return t.replace("python -m econquest.ingestion.pullpack report", "econquest mac-pull report")


def python_check(version=None) -> dict:
    v = tuple((version or sys.version_info)[:3])
    ok = v[:2] >= MIN_PYTHON
    return {"ok": ok, "version": ".".join(str(x) for x in v),
            "detail": "" if ok else f"econquest needs Python {MIN_PYTHON[0]}.{MIN_PYTHON[1]} or newer; rerun install.sh "
                                    "(it installs a current Python with Homebrew)"}


def preflight(data_dir, opts=None, steps=None, redo=(), env=None, version=None) -> dict:
    """Everything `plan` shows, as a dict. Reads only: pullpack.plan (no network, writes nothing), the Python version,
    the UCDP token by name (ops.open_items.ucdp_token_state: env name present / Keychain item exists)."""
    from .open_items import ucdp_token_state
    pk = _pack()
    rows = pk.plan(data_dir, opts, steps, redo)
    tok = ucdp_token_state(Path(data_dir), env)
    todo = [r for r in rows if r["action"] in ("run", "resume")]
    hosts = sorted({h for r in todo for g in r.get("hosts") or [] for h in g})
    return {"python": python_check(version), "steps": rows, "token": tok,
            "done": [r["id"] for r in rows if r["action"].startswith("skip: done")],
            "to_run": [r["id"] for r in todo], "skipped": [r["id"] for r in rows if r["action"].startswith("skip:")
                                                           and not r["action"].startswith("skip: done")],
            "disk_needed_bytes": sum(int(r["estimate_bytes"]) for r in todo),
            "disk_short": [r["id"] for r in rows if not r["disk_ok"]],
            "network": {"hosts": hosts, "status": "will be checked on your Mac",
                        "detail": "this preflight sends nothing; the pack probes each host just before its step and "
                                  "skips the step with the reason if a host does not answer"}}


def preflight_text(p: dict) -> str:
    L = ["Mac pull preflight (nothing was changed or fetched)", ""]
    py = p["python"]
    L.append(f"Python {py['version']}: " + ("ok" if py["ok"] else f"TOO OLD. {py['detail']}"))
    tok = p["token"]
    if tok["configured"]:
        where = f"${tok['env_name']} is set" if tok["in_env"] else "Keychain item econquest-ucdp found"
        L.append(f"UCDP token: present ({where}; value not read)." + ("" if tok["in_env"] else
                 f" Before the run: export {tok['env_name']}=\"$(security find-generic-password -s econquest-ucdp -w)\""))
    else:
        L.append(f"UCDP token: not found (${tok['env_name']} not set"
                 + (", no Keychain item econquest-ucdp" if tok["keychain"] is False else
                    ", Keychain not checked here" if tok["keychain"] is None else "") + "). The UCDP step will be skipped.")
    L.append(f"Network: {len(p['network']['hosts'])} host(s) {p['network']['status']} ({p['network']['detail']}).")
    L.append(f"Disk: the steps to run need about {_human(p['disk_needed_bytes'])} (the pack's estimates; GDELT is 5-15 GB "
             "for a full year, so pull it in short ranges)."
             + (f" Not enough free space for: {', '.join(p['disk_short'])}." if p["disk_short"] else ""))
    L += ["", "Steps:"]
    for r in p["steps"]:
        a = r["action"]
        what = ("already done" if a.startswith("skip: done") else "will resume" if a == "resume" else
                "will run" if a == "run" else "will be skipped: " + a[len("skip: "):])
        L.append(f"  {r['number']:>2} {r['title']} ({r['id']}): {what}. Expected {r['expected_time']}, "
                 f"disk {_human(r['estimate_bytes'])} of {_human(r['free_bytes'])} free.")
    L.append("")
    if not py["ok"]:
        L.append("Next: fix Python first (bash install.sh), then: econquest mac-pull")
    elif p["to_run"]:
        L.append(f"Next: {RUN}    # runs {', '.join(p['to_run'])}; rerun it to resume after a stop")
    else:
        L.append("Next: nothing to run. econquest mac-pull report   # the summary to send back")
    return "\n".join(L) + "\n"


def summary_text(rep: dict, md_rel: str | None = None) -> str:
    """Plain-English report from pullpack's report dict: what was pulled, held, failed, skipped, and the next commands."""
    steps = rep.get("steps") or []
    by = {s: [x for x in steps if x.get("status") == s] for s in ("done", "held", "failed", "skipped", "pending", "running")}
    L = [f"Mac pull report: {sum(len(v) for v in by.values())} steps, {len(by['done'])} done, {len(by['held'])} held, "
         f"{len(by['failed'])} failed, {len(by['skipped'])} skipped, {len(by['pending']) + len(by['running'])} not finished.", ""]
    if by["done"]:
        L.append("Pulled:")
        for x in by["done"]:
            vint = ", ".join(f"{k} {v}" for k, v in (x.get("vintages") or {}).items() if v)
            L.append(f"  - {x['title']}" + (f" (vintage {vint})" if vint else ""))
    for status, head in (("held", "Held for your decision:"), ("failed", "Failed:"), ("skipped", "Skipped:")):
        if by[status]:
            L.append(head)
            for x in by[status]:
                L.append(f"  - {x['title']}: {_ours(x.get('reason') or 'no reason recorded')}"
                         + (f" ({len(x['held'])} cell(s))" if x.get("held") else ""))
    L += ["", "Next:"]
    nxt = [_ours(a) for a in rep.get("sam_next") or []]
    nxt += [f"{RUN} --steps {x['id']}    # retry the failed step" for x in by["failed"]]
    L += [f"  - {a}" for a in nxt] or ["  - Nothing: every step is done."]
    if md_rel:
        L += ["", f"Full report: {md_rel} (send it back with report.json)."]
    return _CTRL.sub("", "\n".join(L)) + "\n"


def status_text(state: dict) -> str:
    L = []
    for sid in state.get("order") or []:
        x = state["steps"].get(sid, {})
        st = x.get("status", "pending")
        L.append(f"{x.get('number', ''):>2} {x.get('title', sid)} ({sid}): {WORDS.get(st, st)}"
                 + (f" at {x['finished_utc']}" if x.get("finished_utc") and st != "pending" else "")
                 + (f" - {_ours(x['reason'])}" if x.get("reason") else ""))
    return _CTRL.sub("", "\n".join(L)) + "\n"


def _opts(a):
    pk = _pack()
    kw = {"apply_fx": bool(getattr(a, "apply_fx", False))}
    for k in ("crag_xlsx", "universe_dest", "ucdp_end", "gdelt_start", "gdelt_end"):
        if getattr(a, k, None):
            kw[k] = getattr(a, k)
    if getattr(a, "ucdp_start", None):
        kw["ucdp_start"] = a.ucdp_start
    if getattr(a, "gdelt_days", None):
        kw["gdelt_days"] = a.gdelt_days
    return pk.PackOptions(**kw)


def _steps(a):
    return [s.strip() for s in a.steps.split(",") if s.strip()] if getattr(a, "steps", None) else None


def _rel(path, data_dir) -> str:
    try:
        return str(Path(path).resolve().relative_to(Path(data_dir).resolve().parent))
    except ValueError:
        return Path(path).name


def cmd_mac_pull(a) -> None:
    pk = _pack()
    d = Path(a.data)
    problem = pk.data_folder_problem(d)              # EQ-C-0168: names the ~/Downloads release-data/ copy
    if problem:
        print(f"mac-pull: {problem}", file=sys.stderr)
        raise SystemExit(EXIT_FAILED)
    cmd = a.mp_cmd or "plan"
    steps = _steps(a)
    try:
        if cmd == "plan":
            p = preflight(d, _opts(a), steps, a.redo or ())
            print(json.dumps(p, indent=1, default=str) if a.json else preflight_text(p), end="" if not a.json else "\n")
            raise SystemExit(EXIT_DONE if p["python"]["ok"] else EXIT_FAILED)
        if cmd == "run":
            py = python_check()
            if not py["ok"]:
                print(f"mac-pull: {py['detail']}", file=sys.stderr)
                raise SystemExit(EXIT_FAILED)
            st = pk.run(d, _opts(a), steps, a.redo or (), out=print)
            r = pk.report(d)
            print()
            print(summary_text(r["report"], _rel(r["md"], d)), end="")
            raise SystemExit(pk.exit_code(st, steps))
        if cmd == "status":
            st = pk.status(d)
            print(json.dumps(st, indent=1, default=str) if a.json else status_text(st), end="" if not a.json else "\n")
            raise SystemExit(pk.exit_code(st, steps))
        r = pk.report(d)
        print(json.dumps(r["report"], indent=1, default=str) if a.json else summary_text(r["report"], _rel(r["md"], d)),
              end="" if not a.json else "\n")
        raise SystemExit(int(r["exit_code"]))
    except pk.UsageError as e:
        print(f"mac-pull: {e}", file=sys.stderr)
        raise SystemExit(EXIT_FAILED) from None


def _step_ids() -> list[str]:
    """Step ids in run order from Team A's pack (default_steps, so a new step such as nowcast shows up without a
    change here; HO-20261024-A-C-015). Falls back to STEP_IDS, then to nothing, when the pack cannot be imported."""
    try:
        pk = _pack()
        try:
            return [s.id for s in pk.default_steps()]
        except Exception:                                # noqa: BLE001 - help text only
            return list(pk.STEP_IDS)
    except Exception:                                    # noqa: BLE001
        return []


def register(sub) -> None:
    mp = sub.add_parser("mac-pull", help="every pull that only the Mac can run (official FX, panel history, BoC-BoE, 88 countries, "
                        "UCDP, GDELT, nowcast inputs, research file drops) as one resumable sequence: plan (default, preflight, changes nothing), run, status, report")
    mp.add_argument("mp_cmd", nargs="?", choices=("plan", "run", "status", "report"), default="plan")
    mp.add_argument("--steps", help=f"comma list of steps ({', '.join(_step_ids())}; default all)")
    mp.add_argument("--redo", action="append", default=[], metavar="STEP", help="run STEP again although done ('all' for every step)")
    mp.add_argument("--apply-fx", action="store_true", help="run: apply the official FX vintage after its verify passes (never forced)")
    mp.add_argument("--crag-xlsx", help="BoC-BoE workbook (default ~/Downloads/BoC-BoE-Database-2026.xlsx)")
    mp.add_argument("--universe-dest", help="staged folder for the 88-country fetch (default ~/econquest-universe-<ts>)")
    mp.add_argument("--ucdp-start"); mp.add_argument("--ucdp-end")
    mp.add_argument("--gdelt-start"); mp.add_argument("--gdelt-end"); mp.add_argument("--gdelt-days", type=int)
    mp.add_argument("--json", action="store_true", help="plan, status, report: print JSON")
    mp.set_defaults(fn=cmd_mac_pull)
