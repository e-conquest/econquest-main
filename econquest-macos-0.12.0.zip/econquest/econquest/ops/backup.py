"""Nightly backup, verify, restore and the restore drill (EQ-C-0022).

What is backed up: all of <home>/data (inputs, data/live incl. vintages/, snapshots/ and review_ledger.csv,
forecast_record.csv, benchmarks.csv, market_history/) and the run store <home>/outputs/store (econquest.sqlite,
panoptix.sqlite, archive/ with run JSONs and loss paths), and the model monitoring outputs <home>/outputs/monitoring
(indicator_snapshots/ is the PSI reference the next monitoring run compares against; HO-20261024-B-C-007). SQLite files are copied with the sqlite3 backup API so a
job writing at the same time cannot leave a torn copy. Symlinks are followed: the archive holds files, not links.

Where: $ECONQUEST_BACKUP_DEST, else ~/econquest-backups/nightly. Point ECONQUEST_BACKUP_DEST at an iCloud Drive,
Dropbox or external-drive folder to get the copy off the Mac's disk. Each backup is

    <dest>/<UTC date>/econquest-<UTC ts>.tar.gz          the archive; MANIFEST.json inside lists sha256 per file
    <dest>/<UTC date>/econquest-<UTC ts>.manifest.json   the same manifest plus the archive's own sha256

Retention (only folders named YYYY-MM-DD under <dest> are ever deleted): the 14 newest daily folders, plus the newest
folder of each of the 8 most recent ISO weeks not already covered by those 14.

verify: archive sha256 equals the sidecar's, every member's sha256 equals the manifest, no file missing or extra.
restore(backup, target): verifies, extracts regular files only (no absolute paths, no "..", no links) into an empty
target, and re-hashes every restored file.

File modes (HO-20261024-A-C-006, SEC-A-006 L7): manifest format 2 records each file's permission bits ("mode") and
restore re-applies them. Vintage and replay-snapshot trees (READ_ONLY_PREFIXES, threat model T4) are restored
read-only whatever the backup says: files 0444, the directories below each prefix 0555. A format 1 backup (no
modes) restores those trees read-only and every other file with the default mode. restore_drill: restore the latest backup into a temp dir, smoke check
(load_universe on the restored data/, open the restored store and load its latest run, data_hash equals the one
recorded at backup time), time it against the RTO and measure the backup's age against the RPO (data/resilience.json
targets, default RTO 1 h and RPO 24 h, team/runbooks/C-incident.md; EQ-C-0077), write outputs/logs/restore-drill-<ts>.json
and append one line to outputs/logs/restore-drills.jsonl (the drill history).

Drill measures: duration_seconds (restore + verify + smoke, i.e. time back to a working copy) against rto_hours ->
within_rto (also the legacy within_target / target_hours); backup_age_hours (drill time - the manifest's created_at,
the data that would be lost restoring now) against rpo_hours -> within_rpo; newest_data_at / data_age_hours (the newest
base run or forecast-record row inside the restored copy). `ok` needs the restore, the smoke check and the RTO; a
missed RPO is reported (targets_met false) but does not fail the drill, which tests restorability, not backup freshness
(the daily monitor's backup line covers that).

Hardening (EQ-C-0164, docs/runbooks/C-chaos-and-perf.md): outputs/archive (the research archive and its hash-chained
index, EQ-C-0154) is backed up too. A backup is written as <archive>.partial, its sidecar manifest is written
atomically (temp + os.replace) BEFORE the archive is renamed into place, so a killed or out-of-space backup never
leaves a listed archive without its manifest; on any write error (ENOSPC included) the partial files are removed and
BackupError says what happened. A clock that went back (now earlier than the newest backup's stamp) still writes the
backup but skips retention, so the newest copy is never pruned as "old". The drill's reports are written atomically,
and its smoke check also verifies the restored review ledger and archive index hash chains.
"""
from __future__ import annotations
import argparse
import datetime as dt
import errno
import hashlib
import io
import json
import os
import re
import shutil
import sqlite3
import stat
import sys
import tarfile
import tempfile
import time
from pathlib import Path, PurePosixPath

SOURCES = ("data", "outputs/store", "outputs/monitoring",   # monitoring: indicator_snapshots/ is the PSI reference (HO-20261024-B-C-007)
           "outputs/archive")                           # research archive + hash-chained index (EQ-C-0154; EQ-C-0164)
SKIP_NAMES = {"__pycache__", ".DS_Store"}
DAY_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
MANIFEST_NAME = "MANIFEST.json"
KEEP_DAILY, KEEP_WEEKLY = 14, 8
DRILL_TARGET_HOURS = 1.0                               # default RTO when data/resilience.json is absent (4 h before EQ-C-0077)
MANIFEST_FORMAT = 2                                   # 2: files[rel]["mode"] (EQ-C-0070); 1: no modes
READ_ONLY_PREFIXES = ("data/live/vintages", "data/live/snapshots", "data/panel/vintages", "data/live/market/snapshots")
READ_ONLY_FILE_MODE, READ_ONLY_DIR_MODE = 0o444, 0o555
CLOCK_SKEW_TOLERANCE = dt.timedelta(minutes=10)         # EQ-C-0164: now this far before the newest backup = clock went back
_STAMP_RE = re.compile(r"^econquest-(\d{8}T\d{6}Z)")


class BackupError(RuntimeError):
    pass


def io_message(e: OSError, what: str) -> str:
    """One clear line for a write failure (EQ-C-0164); ENOSPC is named as a full disk."""
    where = f" ({e.filename})" if getattr(e, "filename", None) else ""
    if getattr(e, "errno", None) == errno.ENOSPC:
        return f"{what}: disk full (ENOSPC){where}; nothing half-written was kept. Free space and rerun"
    return f"{what}: {type(e).__name__}: {e.strerror or e}{where}"


def atomic_write_text(path: Path, text: str) -> None:
    """Write text to path through a temp file in the same folder + fsync + os.replace (EQ-C-0164): a reader sees the old
    file or the whole new one, never a torn one. The temp file is removed on any failure."""
    path = Path(path)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text); f.flush(); os.fsync(f.fileno())
        os.replace(tmp, path)
    except BaseException:
        try:
            os.unlink(tmp)
        except OSError:
            pass
        raise


def _stamp_of(arch: Path) -> dt.datetime | None:
    m = _STAMP_RE.match(arch.name)
    try:
        return dt.datetime.strptime(m.group(1), "%Y%m%dT%H%M%SZ").replace(tzinfo=dt.timezone.utc) if m else None
    except ValueError:
        return None


def default_dest(env: dict | None = None) -> Path:
    env = os.environ if env is None else env
    return Path(env.get("ECONQUEST_BACKUP_DEST") or Path.home() / "econquest-backups" / "nightly").expanduser()


def _sha256_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _iter_files(root: Path):
    """Regular files under root, following symlinks (a symlinked data/ is backed up as files)."""
    for dirpath, dirnames, filenames in os.walk(root, followlinks=True):
        dirnames[:] = sorted(d for d in dirnames if d not in SKIP_NAMES)
        for fn in sorted(filenames):
            if fn in SKIP_NAMES or fn.endswith((".pyc", "-journal", "-wal", "-shm")):
                continue
            p = Path(dirpath) / fn
            if p.is_file():
                yield p


def _is_sqlite(p: Path) -> bool:
    if p.suffix not in (".sqlite", ".sqlite3", ".db"):
        return False
    with open(p, "rb") as f:
        return f.read(16) == b"SQLite format 3\x00"


def _sqlite_snapshot(src: Path, dst: Path) -> None:
    s = sqlite3.connect(f"file:{src}?mode=ro", uri=True)
    d = sqlite3.connect(dst)
    try:
        s.backup(d)
    finally:
        d.close(); s.close()


def create_backup(home: str | Path, dest: str | Path | None = None, now: dt.datetime | None = None, prune: bool = True,
                  keep_daily: int = KEEP_DAILY, keep_weekly: int = KEEP_WEEKLY, verify_after: bool = False, log=print) -> dict:
    """Write one backup of SOURCES (data/, outputs/store, outputs/monitoring). Returns {archive, manifest, files, bytes, pruned, verify}."""
    home = Path(home).expanduser()
    dest = Path(dest).expanduser() if dest else default_dest()
    now = (now or dt.datetime.now(dt.timezone.utc)).astimezone(dt.timezone.utc)
    if not (home / "data").is_dir():
        raise BackupError(f"{home / 'data'} not found: nothing to back up")
    rdest = dest.resolve()
    for src in SOURCES:                                   # a dest inside a source would back up (and prune) itself
        if rdest == (home / src).resolve() or (home / src).resolve() in rdest.parents:
            raise BackupError(f"backup destination {dest} is inside {home / src}; choose a folder outside {', '.join(SOURCES)}")
    try:
        prior = [s for s in (_stamp_of(a) for a in list_backups(dest)) if s]
    except OSError:
        prior = []
    newest = max(prior, default=None)
    skew = bool(newest and now < newest - CLOCK_SKEW_TOLERANCE)
    if skew:
        log(f"[backup] WARNING clock skew: now {now.isoformat(timespec='seconds')} is before the newest backup "
            f"({newest.isoformat(timespec='seconds')}); the backup is written but retention is skipped (check the clock)")
    try:
        day = dest / now.strftime("%Y-%m-%d"); day.mkdir(parents=True, exist_ok=True)
    except OSError as e:
        raise BackupError(io_message(e, "backup")) from e
    stem = f"econquest-{now.strftime('%Y%m%dT%H%M%SZ')}"
    arch = day / f"{stem}.tar.gz"
    n = 1
    while arch.exists():
        n += 1; arch = day / f"{stem}-{n}.tar.gz"
    partial = arch.with_name(arch.name + ".partial")
    mpath = arch.with_name(arch.name[:-len(".tar.gz")] + ".manifest.json")
    t0 = time.monotonic()
    try:
        manifest, dh, side = _write_archive(home, partial, arch, mpath, now, log)
        partial.replace(arch)                           # last: a listed archive always has its manifest
    except BaseException as e:
        for p in (partial, mpath):
            try:
                p.unlink()
            except OSError:
                pass
        if isinstance(e, OSError):
            raise BackupError(io_message(e, "backup")) from e
        raise
    log(f"[backup] {arch} ({manifest['file_count']} files, {side['archive_bytes'] / 1e6:.1f} MB compressed, {time.monotonic() - t0:.1f}s)")
    out = {"archive": str(arch), "manifest": str(mpath), "files": manifest["file_count"], "bytes": manifest["bytes"],
           "data_hash": dh, "pruned": [], "verify": None, "clock_skew": skew}
    if verify_after:
        out["verify"] = verify(arch, log=log)
    if prune and not skew:
        out["pruned"] = prune_backups(dest, keep_daily, keep_weekly, log=log)
    return out


def _write_archive(home: Path, partial: Path, arch: Path, mpath: Path, now: dt.datetime, log) -> tuple[dict, str | None, dict]:
    """Write the tar.gz to `partial` and the sidecar manifest (atomically) to `mpath`. Returns (manifest, data_hash, side)."""
    files: dict[str, dict] = {}
    with tempfile.TemporaryDirectory(prefix="econquest-backup-") as td, tarfile.open(partial, "w:gz", compresslevel=6) as tar:
        for src in SOURCES:
            root = home / src
            if not root.exists():
                log(f"[backup] {root} not found: skipped")
                continue
            for p in _iter_files(root):
                rel = (PurePosixPath(src) / p.relative_to(root).as_posix()).as_posix()
                real = p
                if _is_sqlite(p):
                    real = Path(td) / f"snap-{len(files)}.sqlite"; _sqlite_snapshot(p, real)
                data = real.read_bytes()                # files are small (largest a few MB); hash exactly what is archived
                digest = hashlib.sha256(data).hexdigest()
                st = p.stat()
                mode = stat.S_IMODE(st.st_mode) & 0o777          # permission bits only (no setuid/setgid/sticky)
                ti = tarfile.TarInfo(rel); ti.size = len(data); ti.mtime = int(st.st_mtime); ti.mode = mode
                tar.addfile(ti, io.BytesIO(data))
                files[rel] = {"sha256": digest, "size": len(data), "mode": f"{mode:04o}"}
        try:
            from ..versioning import data_hash
            dh = data_hash(home / "data")
        except Exception as e:                          # never fail a backup on the hash
            dh = None; log(f"[backup] data_hash not computed: {e}")
        try:
            from .. import __version__ as ver
        except ImportError:
            ver = None
        manifest = {"format": MANIFEST_FORMAT, "created_at": now.isoformat(timespec="seconds"), "home": str(home), "sources": list(SOURCES),
                    "econquest_version": ver, "data_hash": dh, "file_count": len(files),
                    "bytes": sum(f["size"] for f in files.values()), "files": files}
        mb = json.dumps(manifest, indent=1, sort_keys=True).encode()
        ti = tarfile.TarInfo(MANIFEST_NAME); ti.size = len(mb); ti.mtime = int(now.timestamp()); ti.mode = 0o644
        tar.addfile(ti, io.BytesIO(mb))
    side = {**manifest, "archive": arch.name, "archive_sha256": _sha256_file(partial), "archive_bytes": partial.stat().st_size}
    atomic_write_text(mpath, json.dumps(side, indent=1, sort_keys=True))
    return manifest, dh, side


def select_retained(days: list[dt.date], keep_daily: int = KEEP_DAILY, keep_weekly: int = KEEP_WEEKLY) -> set[dt.date]:
    """The newest keep_daily days, plus the newest day of each of the keep_weekly most recent ISO weeks that have no day
    among those kept as daily."""
    ds = sorted(set(days), reverse=True)
    keep = set(ds[:keep_daily])
    covered = {d.isocalendar()[:2] for d in keep}
    weeks: list[dt.date] = []
    seen: set = set()
    for d in ds[keep_daily:]:
        wk = d.isocalendar()[:2]
        if wk in covered or wk in seen:
            continue
        seen.add(wk); weeks.append(d)
        if len(weeks) >= keep_weekly:
            break
    return keep | set(weeks)


def prune_backups(dest: str | Path, keep_daily: int = KEEP_DAILY, keep_weekly: int = KEEP_WEEKLY, log=print) -> list[str]:
    dest = Path(dest)
    days = {}
    for p in dest.iterdir() if dest.exists() else []:
        # Only day folders this tool wrote (they hold an econquest-*.manifest.json), never a symlink: a dest pointed at
        # the wrong folder (e.g. data/live/vintages, whose legacy ids are dates) must not lose it (AGENT-09 review).
        if p.is_dir() and not p.is_symlink() and DAY_RE.match(p.name) and any(p.glob("econquest-*.manifest.json")):
            try:
                days[dt.date.fromisoformat(p.name)] = p
            except ValueError:
                continue
    keep = select_retained(list(days), keep_daily, keep_weekly)
    removed = []
    for d, p in sorted(days.items()):
        if d not in keep:
            shutil.rmtree(p); removed.append(str(p))
    if removed:
        log(f"[backup] retention removed {len(removed)} folder(s): {', '.join(Path(r).name for r in removed)}")
    return removed


def list_backups(dest: str | Path | None = None) -> list[Path]:
    """Archives under dest, oldest first."""
    dest = Path(dest).expanduser() if dest else default_dest()
    if not dest.exists():
        return []
    return sorted((a for d in dest.iterdir() if d.is_dir() and DAY_RE.match(d.name) for a in d.glob("econquest-*.tar.gz")),
                  key=lambda a: a.name)


def _resolve(backup: str | Path) -> tuple[Path, Path]:
    b = Path(backup).expanduser()
    if b.is_dir():
        found = sorted(b.glob("econquest-*.tar.gz")) or (list_backups(b)[-1:] if list_backups(b) else [])
        if not found:
            raise BackupError(f"no econquest-*.tar.gz in {b}")
        b = found[-1]
    if b.name.endswith(".manifest.json"):
        b = b.with_name(b.name[:-len(".manifest.json")] + ".tar.gz")
    m = b.with_name(b.name[:-len(".tar.gz")] + ".manifest.json")
    if not b.exists():
        raise BackupError(f"{b} not found")
    if not m.exists():
        raise BackupError(f"manifest {m} not found")
    return b, m


def _safe_name(name: str) -> bool:
    p = PurePosixPath(name)
    return bool(name) and not p.is_absolute() and ".." not in p.parts and "\\" not in name and ":" not in p.parts[0]


def _read_only_path(rel: str) -> bool:
    return any(rel.startswith(p + "/") for p in READ_ONLY_PREFIXES)


def restored_mode(rel: str, entry: dict) -> int | None:
    """The mode a restored file gets: read-only under READ_ONLY_PREFIXES, else the recorded mode (format 2), else None
    (format 1: leave the default)."""
    rec = entry.get("mode")
    mode = None
    if isinstance(rec, str) and re.fullmatch(r"0?[0-7]{3}", rec):
        mode = (int(rec, 8) & 0o777) | 0o400         # the owner can always read it back (re-hash)
    if _read_only_path(rel):
        return READ_ONLY_FILE_MODE if mode is None else mode & READ_ONLY_FILE_MODE
    return mode


def _read_only_dirs(root: Path, rels) -> list[Path]:
    """The directories strictly below each READ_ONLY_PREFIX that hold a restored file, deepest first (the prefix
    itself stays writable, so new vintages can be added)."""
    dirs = set()
    for rel in rels:
        for pre in READ_ONLY_PREFIXES:
            if rel.startswith(pre + "/"):
                parts = PurePosixPath(rel[len(pre) + 1:]).parts[:-1]
                for i in range(1, len(parts) + 1):
                    dirs.add(PurePosixPath(pre, *parts[:i]).as_posix())
    return [root / d for d in sorted(dirs, key=lambda d: (-d.count("/"), d))]


def _rmtree(path: Path) -> None:
    """shutil.rmtree for a tree with read-only directories (a restored vintage tree is 0555): make every directory
    owner-writable first, then delete. Symlinks are never followed."""
    for dirpath, dirnames, _ in os.walk(path):
        for d in dirnames:
            q = os.path.join(dirpath, d)
            if not os.path.islink(q):
                try:
                    os.chmod(q, 0o700)
                except OSError:
                    pass
    shutil.rmtree(path, ignore_errors=True)


def _walk_archive(arch: Path, manifest: dict, sink=None) -> list[str]:
    """Hash every member against the manifest; with `sink(rel, fileobj_bytes)` also write them. Returns errors."""
    errors, seen = [], set()
    files = manifest.get("files", {})
    with tarfile.open(arch, "r:gz") as tar:
        for ti in tar:
            if ti.name == MANIFEST_NAME:
                continue
            if not ti.isfile():
                errors.append(f"{ti.name}: not a regular file (refused)"); continue
            if not _safe_name(ti.name) or not any(ti.name == s or ti.name.startswith(s + "/") for s in SOURCES):
                errors.append(f"{ti.name}: unsafe or unexpected path (refused)"); continue
            exp = files.get(ti.name)
            if exp is None:
                errors.append(f"{ti.name}: not in the manifest"); continue
            data = tar.extractfile(ti).read()
            seen.add(ti.name)
            if hashlib.sha256(data).hexdigest() != exp["sha256"]:
                errors.append(f"{ti.name}: sha256 mismatch"); continue
            if sink:
                sink(ti.name, data)
    errors += [f"{rel}: missing from the archive" for rel in sorted(set(files) - seen)]
    return errors


def verify(backup: str | Path, log=print) -> dict:
    """Check the archive hash and every file hash. Returns {ok, archive, files, errors}."""
    arch, mpath = _resolve(backup)
    try:
        side = json.loads(mpath.read_text())
        if not isinstance(side, dict):
            raise ValueError("not a JSON object")
    except (OSError, ValueError) as e:
        log(f"[backup] verify {arch.name}: FAILED (manifest {mpath.name} unreadable: {type(e).__name__})")
        return {"ok": False, "archive": str(arch), "files": 0, "errors": [f"manifest {mpath.name} unreadable or truncated: {e}"]}
    errors = []
    if _sha256_file(arch) != side.get("archive_sha256"):
        errors.append("archive sha256 differs from the manifest (file changed or truncated)")
    try:
        with tarfile.open(arch, "r:gz") as tar:
            inner = json.loads(tar.extractfile(MANIFEST_NAME).read())
        if inner.get("files") != side.get("files"):
            errors.append("MANIFEST.json inside the archive differs from the sidecar manifest")
        errors += _walk_archive(arch, side)
    except (tarfile.TarError, OSError, KeyError, EOFError, json.JSONDecodeError) as e:
        errors.append(f"archive unreadable: {e}")
    ok = not errors
    log(f"[backup] verify {arch.name}: {'OK' if ok else 'FAILED'} ({side.get('file_count')} files)" + ("" if ok else "\n  " + "\n  ".join(errors[:20])))
    return {"ok": ok, "archive": str(arch), "files": side.get("file_count"), "errors": errors}


def restore(backup: str | Path, target_dir: str | Path, log=print) -> dict:
    """Verify, then extract into target_dir (must be empty or absent) and re-hash every restored file."""
    arch, mpath = _resolve(backup)
    target = Path(target_dir).expanduser()
    if target.exists() and any(target.iterdir()):
        raise BackupError(f"{target} is not empty: restore only into an empty folder, then copy back by hand (A-restore.md)")
    v = verify(arch, log=log)
    if not v["ok"]:
        return {"ok": False, "target": str(target), "files": 0, "errors": v["errors"], "archive": str(arch)}
    side = json.loads(mpath.read_text())
    target.mkdir(parents=True, exist_ok=True)
    root = target.resolve()

    def sink(rel: str, data: bytes):
        out = (root / rel).resolve()
        if root not in out.parents:
            raise BackupError(f"{rel} escapes {root}")
        out.parent.mkdir(parents=True, exist_ok=True)
        out.write_bytes(data)
        mode = restored_mode(rel, side["files"].get(rel, {}))
        if mode is not None:
            os.chmod(out, mode)

    errors = _walk_archive(arch, side, sink)
    for d in _read_only_dirs(root, side["files"]):              # after every file is written: deepest first
        if d.is_dir() and not d.is_symlink():
            os.chmod(d, READ_ONLY_DIR_MODE)
    for rel, f in side["files"].items():                          # re-hash what landed on disk
        p = root / rel
        if not p.exists() or _sha256_file(p) != f["sha256"]:
            errors.append(f"{rel}: restored file missing or hash differs")
    ok = not errors
    log(f"[restore] {arch.name} -> {target}: {'OK' if ok else 'FAILED'} ({len(side['files'])} files)")
    return {"ok": ok, "target": str(target), "files": len(side["files"]), "errors": errors, "archive": str(arch),
            "data_hash": side.get("data_hash")}


def smoke_check(target: str | Path, expected_data_hash: str | None = None) -> dict:
    """load_universe on the restored data/ and open the restored run store."""
    target = Path(target)
    out: dict = {"ok": True, "errors": []}
    try:
        from ..ingestion import load_universe
        u = load_universe(target / "data")
        probs = u.validate()
        out["countries"] = len(u.names); out["positions"] = len(u.portfolio)
        if probs:
            out["errors"].append(f"universe validation: {probs}")
    except Exception as e:
        out["errors"].append(f"load_universe failed: {type(e).__name__}: {e}")
    store_dir = target / "outputs" / "store"
    if (store_dir / "econquest.sqlite").exists():
        try:
            from ..persistence import Store
            s = Store(store_dir)
            runs = s.runs(limit=1)
            out["runs_in_store"] = len(s.runs(limit=100000))
            if runs:
                out["latest_run"] = runs[0]["run_id"]
                s.load(runs[0]["run_id"])
        except Exception as e:
            out["errors"].append(f"store failed: {type(e).__name__}: {e}")
    else:
        out["runs_in_store"] = 0; out["note"] = "no run store in the backup"
    out["ledger_problems"] = []
    out["ledgers"] = _ledger_checks(target, out["ledger_problems"])
    if expected_data_hash:
        try:
            from ..versioning import data_hash
            out["data_hash"] = data_hash(target / "data")
            if out["data_hash"] != expected_data_hash:
                out["errors"].append(f"data_hash {out['data_hash']} differs from the backup's {expected_data_hash}")
        except Exception as e:
            out["errors"].append(f"data_hash failed: {e}")
    out["ok"] = not out["errors"]
    return out


def _ledger_checks(target: Path, errors: list[str]) -> dict:
    """EQ-C-0164: verify the restored copy's hash-chained ledgers (review ledger, research archive index) and append any
    break to `errors`. Reported by the drill as ledgers_ok / ledger_problems: a faithful restore of a ledger that was
    already broken when backed up is still a working restore, so this does not fail the drill; it says whether the
    backup is a clean recovery point for the ledgers. An absent ledger is "absent"."""
    res: dict = {}
    if (target / "data" / "live" / "review_ledger.csv").is_file():
        try:
            from ..ingestion.ledger import verify_ledger
            st = verify_ledger(target / "data")
            res["review_ledger"] = "ok" if st["ok"] else "broken"
            if not st["ok"]:
                errors.append("restored data/live/review_ledger.csv hash chain is broken: " + "; ".join(st["problems"][:3]))
        except Exception as e:                          # noqa: BLE001 - a crash in the verifier is a failed check
            res["review_ledger"] = "error"; errors.append(f"review ledger verify failed: {type(e).__name__}: {e}")
    else:
        res["review_ledger"] = "absent"
    if (target / "outputs" / "archive" / "index.jsonl").is_file():
        try:
            from ..presentation import archive as _arch
            v = _arch.verify(target / "outputs")
            res["archive_index"] = "ok" if v["ok"] else "broken"
            if not v["ok"]:
                errors.append("restored outputs/archive index fails verification: " + "; ".join(v["errors"][:3]))
        except Exception as e:                          # noqa: BLE001
            res["archive_index"] = "error"; errors.append(f"archive verify failed: {type(e).__name__}: {e}")
    else:
        res["archive_index"] = "absent"
    return res


def drill_targets(home: Path) -> dict:
    """{"rto_hours", "rpo_hours"} from <home>/data/resilience.json (EQ-C-0077); defaults 1 h and 24 h. A config that does
    not load falls back to the defaults and says so (the drill must still run)."""
    from .monitor import DEFAULTS, ResilienceConfigError, load_resilience
    try:
        t = load_resilience(Path(home) / "data")["targets"]
        return {"rto_hours": t["rto_hours"], "rpo_hours": t["rpo_hours"], "source": "data/resilience.json"}
    except (ResilienceConfigError, OSError) as e:
        return {**DEFAULTS["targets"], "source": f"defaults ({type(e).__name__})"}


def _newest_data(root: Path) -> dt.datetime | None:
    """The newest base-run created_at or forecast-record recorded_at inside a restored copy (None when neither)."""
    from .health import _record_times, _store_times
    ts = _record_times(root / "data") + _store_times(root / "outputs")
    return max(ts) if ts else None


def _hours(a: dt.datetime, b: dt.datetime | None) -> float | None:
    return None if b is None else round((a - b).total_seconds() / 3600, 3)


def restore_drill(home: str | Path, backup: str | Path | None = None, dest: str | Path | None = None, keep: bool = False,
                  target_hours: float | None = None, now: dt.datetime | None = None, log=print,
                  rpo_hours: float | None = None) -> dict:
    """Restore the latest (or given) backup into a temp folder, verify every hash, smoke check, time it against the
    RTO, measure the backup's age against the RPO, and write outputs/logs/restore-drill-<ts>.json,
    outputs/restore_drill.json and a line of outputs/logs/restore-drills.jsonl. target_hours / rpo_hours override the
    data/resilience.json targets."""
    home = Path(home).expanduser()
    now = (now or dt.datetime.now(dt.timezone.utc)).astimezone(dt.timezone.utc)
    tg = drill_targets(home)
    target_hours = float(tg["rto_hours"] if target_hours is None else target_hours)
    rpo_hours = float(tg["rpo_hours"] if rpo_hours is None else rpo_hours)
    if backup is None:
        found = list_backups(dest)
        if not found:
            raise BackupError(f"no backup found under {Path(dest).expanduser() if dest else default_dest()}")
        backup = found[-1]
    t0 = time.monotonic()
    td = Path(tempfile.mkdtemp(prefix="econquest-drill-"))
    try:
        try:
            r = restore(backup, td / "restore", log=log)
        except OSError as e:                            # EQ-C-0164: e.g. ENOSPC while extracting: a failed drill, not a crash
            msg = io_message(e, "restore")
            log(f"[restore] FAILED: {msg}")
            try:
                arch = str(_resolve(backup)[0])
            except BackupError:
                arch = str(backup)
            r = {"ok": False, "target": str(td / "restore"), "files": 0, "errors": [msg], "archive": arch}
        t_restore = time.monotonic() - t0
        smoke = smoke_check(td / "restore", r.get("data_hash")) if r["ok"] else {"ok": False, "errors": ["skipped: restore failed"]}
        secs = time.monotonic() - t0
        newest = _newest_data(td / "restore") if r["ok"] else None
    finally:
        if not keep:
            _rmtree(td)                                 # the restored vintage tree is read-only
    rep = {"drill_at": now.isoformat(timespec="seconds"), "backup": r["archive"], "files": r["files"],
           "restore_ok": r["ok"], "restore_errors": r["errors"][:50], "smoke": smoke, "restore_seconds": round(t_restore, 2),
           "duration_seconds": round(secs, 2), "target_hours": target_hours, "within_target": secs < target_hours * 3600,
           "kept_at": str(td / "restore") if keep else None}
    created = None
    try:
        side = json.loads(_resolve(r["archive"])[1].read_text())
        created = dt.datetime.fromisoformat(str(side["created_at"]).replace("Z", "+00:00"))
        created = created if created.tzinfo else created.replace(tzinfo=dt.timezone.utc)
    except (BackupError, OSError, ValueError, KeyError, TypeError):
        pass
    age = _hours(now, created)
    rep.update(rto_hours=target_hours, rpo_hours=rpo_hours, targets_source=tg["source"], within_rto=rep["within_target"],
               backup_created_at=created.isoformat(timespec="seconds") if created else None, backup_age_hours=age,
               within_rpo=age is not None and age <= rpo_hours,
               newest_data_at=newest.isoformat(timespec="seconds") if newest else None, data_age_hours=_hours(now, newest))
    rep["targets_met"] = bool(rep["within_rto"] and rep["within_rpo"])
    rep["ledgers"] = smoke.get("ledgers") or {}
    rep["ledger_problems"] = list(smoke.get("ledger_problems") or [])
    rep["ledgers_ok"] = bool(r["ok"]) and not rep["ledger_problems"]
    rep["ok"] = bool(r["ok"] and smoke["ok"] and rep["within_target"])
    logs = home / "outputs" / "logs"
    p = logs / f"restore-drill-{now.strftime('%Y%m%dT%H%M%SZ')}.json"
    hist = {k: rep[k] for k in ("drill_at", "backup", "ok", "duration_seconds", "rto_hours", "within_rto", "backup_age_hours",
                                "rpo_hours", "within_rpo", "data_age_hours", "files")}
    try:                                                # EQ-C-0164: atomic reports; a full disk is a clear BackupError
        logs.mkdir(parents=True, exist_ok=True)
        atomic_write_text(p, json.dumps(rep, indent=1, default=str))
        atomic_write_text(home / "outputs" / "restore_drill.json", json.dumps(rep, indent=1, default=str))
        with open(logs / "restore-drills.jsonl", "a", encoding="utf-8") as f:
            f.write(json.dumps(hist, default=str) + "\n")
    except OSError as e:
        raise BackupError(io_message(e, f"restore drill {'PASSED' if rep['ok'] else 'FAILED'} but its report was not written")) from e
    rep["report"] = str(p)
    log(f"[drill] {'PASS' if rep['ok'] else 'FAIL'}: {r['files']} files restored and verified in {secs:.1f}s "
        f"(RTO {target_hours:g} h: {'met' if rep['within_rto'] else 'MISSED'}); backup age "
        f"{'unknown' if age is None else f'{age:.1f} h'} (RPO {rpo_hours:g} h: {'met' if rep['within_rpo'] else 'MISSED'}); "
        f"smoke {'ok' if smoke['ok'] else smoke['errors']}; ledgers "
        f"{'ok' if rep['ledgers_ok'] else 'NOT CLEAN: ' + '; '.join(rep['ledger_problems'][:2])}; report {p}")
    return rep


def add_backup_arguments(ap: argparse.ArgumentParser) -> None:
    ap.add_argument("--dest", help="backup folder (default $ECONQUEST_BACKUP_DEST, else ~/econquest-backups/nightly)")
    ap.add_argument("--verify", action="store_true", help="verify the new backup after writing it (exit 1 if it fails)")
    ap.add_argument("--verify-only", metavar="BACKUP", help="verify an existing backup (archive, manifest or day folder) and exit")
    ap.add_argument("--no-prune", action="store_true", help="do not apply retention (14 daily + 8 weekly)")
    ap.add_argument("--list", action="store_true", help="list backups and exit")


def add_drill_arguments(ap: argparse.ArgumentParser) -> None:
    ap.add_argument("--dest", help="backup folder to take the latest backup from")
    ap.add_argument("--backup", help="a specific backup (archive, manifest or day folder)")
    ap.add_argument("--keep", action="store_true", help="keep the restored copy (path printed) instead of deleting it")


def backup_from_args(args, home) -> int:
    if args.list:
        for a in list_backups(args.dest):
            print(f"{a}  {a.stat().st_size / 1e6:.1f} MB")
        return 0
    if args.verify_only:
        return 0 if verify(args.verify_only)["ok"] else 1
    r = create_backup(home, args.dest, prune=not args.no_prune, verify_after=args.verify)
    return 1 if args.verify and not r["verify"]["ok"] else 0


def drill_from_args(args, home) -> int:
    return 0 if restore_drill(home, backup=args.backup, dest=args.dest, keep=args.keep)["ok"] else 1


def main(argv=None) -> int:
    argv = list(sys.argv[1:] if argv is None else argv)
    drill = bool(argv) and argv[0] == "drill"
    ap = argparse.ArgumentParser(prog="python -m econquest.ops.backup" + (" drill" if drill else ""),
                                 description="restore drill" if drill else "nightly backup of data/, outputs/store and outputs/monitoring")
    ap.add_argument("--home", default=os.environ.get("ECONQUEST_HOME", str(Path.home() / "econquest")))
    (add_drill_arguments if drill else add_backup_arguments)(ap)
    args = ap.parse_args(argv[1:] if drill else argv)
    try:
        return (drill_from_args if drill else backup_from_args)(args, Path(args.home))
    except BackupError as e:
        print(f"[backup] error: {e}", file=sys.stderr)
        return 2


if __name__ == "__main__":
    sys.exit(main())
