"""D4 switch path for keyed ledger heads (EQ-C-0084, team/runbooks/C-ledger-key.md): the escrow check and the drill.

    econquest ledger-key escrow-check   read the BACKUP copy of the key from a hidden prompt (or one line of stdin),
                                        never from argv; compare its key id with the live key and check every existing
                                        seal with it. Prints key ids and per-ledger results only, never the key.
    econquest ledger-key drill [--keep] run the whole switch path on a temp copy of the four ledgers with a temp key
                                        that lives only in this process: off baseline, create key, back it up, escrow
                                        check, switch on, first seal, verify, append, tamper detected, key lost,
                                        recovered from the backup copy, rolled back to off. Exit 1 if any step fails.

The drill never reads the real Keychain, never writes <home>/ops.json, and never touches the real ledgers (it copies
them). It writes its report (no key) to <out>/logs/ledger-key-drill-<ts>.json.
"""
from __future__ import annotations

import contextlib
import datetime as dt
import hmac
import json
import os
import secrets
import shutil
import sys
import tempfile
from pathlib import Path
from types import SimpleNamespace

from . import ledger_key as LK
from .approvals import GENESIS, row_hash


def validate_seal_with(key: bytes, ledger: str, path: Path, tip: dict) -> str:
    """"ok", "no seal" or the problem, checking one seal with `key` (independent of the switch and the live key)."""
    p = Path(path)
    if not p.exists():
        return "no seal"
    try:
        doc = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return "seal is not JSON"
    if not isinstance(doc, dict) or doc.get("ledger") != ledger:
        return "seal is not for this ledger"
    if doc.get("key_id") != LK.key_id(key):
        return f"seal key id {doc.get('key_id')} differs from this copy's {LK.key_id(key)}"
    seq = doc.get("seq") if isinstance(doc.get("seq"), int) else -1
    if not hmac.compare_digest(str(doc.get("hmac", "")), LK.head_mac(key, ledger, seq, str(doc.get("row_hash", "")))):
        return "HMAC does not match with this copy"
    if (seq, doc.get("row_hash")) != (int(tip.get("seq") or 0), tip.get("row_hash")):
        return f"seal names seq {seq} but the ledger ends at seq {tip.get('seq')}"
    return "ok"


def escrow_check(args, backup_key: str) -> int:
    """Check the backup copy: same key id as the live key (when one is available) and every existing seal validates."""
    from ..cli import _keyed_ledgers
    b = backup_key.strip()
    if len(b) < LK.MIN_KEY_LEN:
        print(f"escrow check: FAIL: the backup copy is shorter than {LK.MIN_KEY_LEN} characters")
        return 1
    bk = b.encode("utf-8")
    bad, proven = 0, False
    try:
        live, src = LK.key_source()
    except LK.LedgerKeyError as e:
        live, src = None, f"unusable ({e})"
    print(f"backup copy key id {LK.key_id(bk)}")
    if live is None:
        print(f"live key: none ({src}); nothing to compare with")
    elif LK.key_id(live) == LK.key_id(bk):
        proven = True
        print(f"live key ({src}) key id {LK.key_id(live)}: matches")
    else:
        bad += 1; print(f"live key ({src}) key id {LK.key_id(live)}: DIFFERS from the backup copy")
    for name, sp, _verify, tip, _lock in _keyed_ledgers(args):
        st = validate_seal_with(bk, name, sp, tip())
        bad += st not in ("ok", "no seal")
        proven = proven or st == "ok"
        print(f"  {name:<11} {st}")
    if not bad and not proven:
        print("escrow check: INCONCLUSIVE: no live key and no seal to check the copy against (create the Keychain item first)")
        return 1
    print("escrow check: " + ("PASS" if not bad else "FAIL"))
    return 1 if bad else 0


def read_backup_key(stream=None) -> str:
    """Hidden prompt on a terminal, else one line of stdin. Never argv."""
    stream = stream or sys.stdin
    if stream.isatty():
        import getpass
        return getpass.getpass("Paste the BACKUP copy of the ledger key (hidden): ")
    return stream.readline()


# ---------------------------------------------------------------- drill
@contextlib.contextmanager
def _sandbox(home: Path, key: str | None):
    """ECONQUEST_HOME -> the temp home, the ledger key only in this process's env, the real Keychain never read."""
    saved = {k: os.environ.get(k) for k in ("ECONQUEST_HOME", LK.ENV, "ECONQUEST_ACTION_LOG")}
    saved_kc = LK._keychain_key
    os.environ["ECONQUEST_HOME"] = str(home)
    os.environ.pop("ECONQUEST_ACTION_LOG", None)
    LK._keychain_key = lambda: None
    try:
        yield
    finally:
        LK._keychain_key = saved_kc
        for k, v in saved.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v


def _copy_ledgers(data_dir: Path, out_dir: Path, act_dir: Path, tmp: Path) -> SimpleNamespace:
    from . import actionlog as AL
    from ..presentation import editorial as E
    t = SimpleNamespace(data=str(tmp / "data"), out=str(tmp / "outputs"))
    (tmp / "data").mkdir(parents=True); (tmp / "outputs" / "store").mkdir(parents=True)
    if (data_dir / "approvals").is_dir():
        shutil.copytree(data_dir / "approvals", tmp / "data" / "approvals",
                        ignore=shutil.ignore_patterns(".lock", "*.hmac.json"))
    srcs = [AL.log_path(act_dir), AL.log_path(act_dir).with_name(AL.HEAD_NAME)]
    srcs += [p for p in (out_dir / "store").glob("deliveries.*") if not p.name.endswith(".hmac.json")]
    for p in srcs:
        if p.is_file():
            shutil.copy2(p, tmp / "outputs" / "store" / p.name)
    ed = E.ledger_path(out_dir).parent
    if ed.is_dir():
        (tmp / "outputs" / ed.name).mkdir(parents=True, exist_ok=True)
        for p in ed.glob("ledger*"):
            if p.is_file() and not p.name.endswith(".hmac.json"):
                shutil.copy2(p, tmp / "outputs" / ed.name / p.name)
    return t


def _verify_all(t) -> dict[str, list[str]]:
    from ..cli import _keyed_ledgers
    return {name: list(verify()) for name, _sp, verify, _tip, _lock in _keyed_ledgers(t)}


def _seal(t, reseal=False) -> tuple[bool, str]:
    from ..cli import cmd_ledger_key
    import io
    buf = io.StringIO()
    try:
        with contextlib.redirect_stdout(buf):
            cmd_ledger_key(SimpleNamespace(lk_cmd="seal", data=t.data, out=t.out, reseal=reseal))
        return True, buf.getvalue().strip().replace("\n", "; ")
    except SystemExit as e:
        return False, f"{buf.getvalue().strip()} {e}".strip()


def drill(data_dir, out_dir, act_dir=None, keep: bool = False, now: dt.datetime | None = None, log=print) -> dict:
    """Run the switch path on a temp copy. Returns {"ok", "steps": [{step, ok, detail}], "tmp"}."""
    from . import actionlog as AL
    data_dir, out_dir = Path(data_dir), Path(out_dir)
    act_dir = Path(act_dir) if act_dir else out_dir
    now = now or dt.datetime.now(dt.timezone.utc)
    tmp = Path(tempfile.mkdtemp(prefix="econquest-ledger-key-drill-"))
    steps: list[dict] = []

    def step(name, ok, detail=""):
        steps.append({"step": name, "ok": bool(ok), "detail": detail})
        log(f"{'PASS' if ok else 'FAIL'}  {name:<22} {detail}")
        return ok

    def keyed(errs):
        return {n: [e for e in es if e.startswith(LK.PREFIX)] for n, es in errs.items()}

    try:
        t = _copy_ledgers(data_dir, out_dir, act_dir, tmp)
        home = tmp
        with _sandbox(home, None):
            errs = _verify_all(t)
            if not step("1 off: chains verify", not any(errs.values()),
                        "; ".join(f"{n}: {e[0]}" for n, e in errs.items() if e) or "all four verify unkeyed (option off)"):
                raise RuntimeError("fix the chains first (econquest change verify / log verify)")
            key = secrets.token_hex(32)                        # temp key, this process only, never printed
            os.environ[LK.ENV] = key
            step("2 create key", LK.key_source()[0] is not None, f"temp key in the process env, key id {LK.key_id(key.encode())}")
            backup = str(key)                                  # the "password manager" copy
            step("3 back up key", LK.key_id(backup.encode()) == LK.key_id(key.encode()), "backup copy has the same key id")
            (home / "ops.json").write_text(json.dumps({LK.CONFIG_KEY: True}))
            on = keyed(_verify_all(t))
            nonempty = [n for n, *_ in _ledgers_with_rows(t)]
            step("4 switch on", LK.enabled() and all(on[n] for n in nonempty),
                 f"ops.json {LK.CONFIG_KEY}: true; unsealed ledgers now fail verify: {', '.join(nonempty) or 'none (all empty)'}")
            ok, detail = _seal(t)
            step("5 first seal", ok, detail)
            errs = _verify_all(t)
            step("6 verify", not any(errs.values()), "all ledgers verify with their seals" if not any(errs.values()) else str(errs))
            AL.append(t.out, "ledger-key drill", {"step": 7}, actor="drill", actor_source="flag")
            errs = _verify_all(t)
            step("7 append re-seals", not any(errs.values()) and AL.seal_path(t.out).exists(),
                 f"action log at seq {AL.read(t.out)[-1]['seq']}, seal moved with it")
            p, hp = AL.log_path(t.out), AL.head_path(t.out)
            orig, orig_head = p.read_bytes(), hp.read_bytes()
            rows = AL.read(t.out); rows[-1]["command"] = "forged"; prev = rows[-2]["row_hash"] if len(rows) > 1 else GENESIS
            rows[-1]["row_hash"] = row_hash(prev, rows[-1])
            p.write_text("".join(json.dumps(r, ensure_ascii=False) + "\n" for r in rows))
            hp.write_text(json.dumps({"seq": rows[-1]["seq"], "row_hash": rows[-1]["row_hash"]}) + "\n")
            k = keyed(_verify_all(t))
            step("8 rewrite detected", bool(k["actions"]), "rewritten row + head pass the unkeyed chain but fail the seal")
            p.write_bytes(orig); hp.write_bytes(orig_head)
            results = {n: validate_seal_with(backup.encode(), n, sp, tip()) for n, sp, _v, tip, _l in _all(t)}
            step("9 escrow check", all(v in ("ok", "no seal") for v in results.values()) and "ok" in results.values(),
                 "backup copy validates " + ", ".join(f"{n}={v}" for n, v in results.items()))
            os.environ.pop(LK.ENV)
            lost = keyed(_verify_all(t))
            step("10 key lost", all(lost.values()), "every ledger fails verify without the key")
            os.environ[LK.ENV] = backup
            errs = _verify_all(t)
            step("11 recover from backup", not any(errs.values()), "backup copy restored: all ledgers verify again")
            (home / "ops.json").write_text(json.dumps({LK.CONFIG_KEY: False}))
            os.environ.pop(LK.ENV)
            errs = _verify_all(t)
            step("12 roll back to off", not LK.enabled() and not any(errs.values()),
                 "ops.json false, no key: chains verify unkeyed as before")
    except Exception as e:                                     # noqa: BLE001 - a crash is a failed drill
        step("drill aborted", False, f"{type(e).__name__}: {e}")
    finally:
        if not keep:
            shutil.rmtree(tmp, ignore_errors=True)
    rep = {"drill_at": now.astimezone(dt.timezone.utc).isoformat(timespec="seconds"), "ok": all(s["ok"] for s in steps) and len(steps) == 12,
           "steps": steps, "tmp": str(tmp) if keep else None}
    try:
        logs = out_dir / "logs"; logs.mkdir(parents=True, exist_ok=True)
        (logs / f"ledger-key-drill-{now.strftime('%Y%m%dT%H%M%SZ')}.json").write_text(json.dumps(rep, indent=1))
    except OSError:
        pass
    log(f"ledger-key drill: {'PASS' if rep['ok'] else 'FAIL'} ({sum(s['ok'] for s in steps)}/{len(steps)} steps); real ledgers and ops.json untouched")
    return rep


def _all(t):
    from ..cli import _keyed_ledgers
    return _keyed_ledgers(t)


def _ledgers_with_rows(t):
    return [x for x in _all(t) if int(x[3]().get("seq") or 0) > 0]
