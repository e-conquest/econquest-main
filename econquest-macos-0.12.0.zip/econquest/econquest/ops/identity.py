"""Named users and per-user signing keys for four-eyes approvals (EQ-C-0078, gap E5).

Today one operator (Sam) self-approves under an EXC exception. This module is the groundwork for a second analyst:
it stays off, and nothing changes, while data/users.json is absent, has `four_eyes: "off"`, or lists fewer than two
active users. How to onboard someone: team/runbooks/C-second-approver.md (proposed for docs/governance/second-approver.md).

Registry `data/users.json`, governed by `econquest change` like compliance.json (Tier 2; absent = single operator):

    {"four_eyes": "off" | "enforce", "enforced_from": "" | "<UTC ISO time>",
     "users": [{"id": "sam", "name": "Sam", "role": "owner" | "analyst" | "validator",
                "key_fingerprint": "" | "hmac-sha256:<32 hex>", "previous_fingerprints": [...], "active": true}]}

Signing: `cryptography` is not in requirements-lock.txt, so there are no public-key signatures. Each user has a secret
of at least 32 characters in $ECONQUEST_SIGNING_KEY_<ID> (id upper-cased, "-" -> "_") or the macOS Keychain item
service `econquest-signing`, account <id>. The registry holds only its fingerprint, sha256("econquest-signing-key-v1\\0"
+ secret), truncated to 32 hex characters and prefixed "hmac-sha256:". An approval signed with `--as <id>` adds three
fields to its log row: approver_id, key_fp and signature = HMAC-SHA256(secret, payload). The payload is
"econquest-approval-v1\\n" plus the canonical JSON of {event, id, file, base_sha256, new_sha256, approver,
self_approved, exc_id, approver_id, key_fp} as stored in the row (after formula neutralising). Rows without these fields (every row written before this) are unchanged and still verify.

What an HMAC proves, and what it does not: the signature can be checked only where the signer's secret is available.
Elsewhere `verify_signatures` checks the fingerprint, the registry and the four-eyes rules, and counts the signature
as "unchecked". Anyone who holds the secret can sign, so it gives attribution against someone who edits the shared
folder, not non-repudiation against the key holder. Moving to ed25519 needs the `cryptography` dependency, which is
Sam's call (AGENT-10 lock, AGENT-09 review).

Enforcement (`enforced`): four_eyes "enforce" and at least two active users. Then an approval needs `--as` (signed by a
registered active user whose fingerprint matches), self-approval is refused, and the approver's id must differ from
the proposer's (the proposal author is matched to a user by id or name, with person_key rules). `verify_signatures`
applies the same rules to approve rows logged at or after `enforced_from`. Earlier rows are legacy single-operator
rows and pass.

Second-analyst readiness (EQ-C-0109). Enforcement also covers the data-gate and findings sign-offs: `review approve`,
`review decide --decision apply`, `attest` (scope "review"/"attest", wired in cli.py) and `findings close` (scope
"findings", Team B calls `prepare_signoff`/`record_signoff`). Their signed rows go to the hash-chained
`data/approvals/signoffs.jsonl` (the Team A ledgers keep their shape). Under enforcement a self-approval (approver =
author) is allowed only when users.json lists a named, unexpired exception for that scope:

    "self_approval_exceptions": [{"exc": "EXC-002", "scopes": ["change"], "expires": "2027-01-22"}, ...]

and the EXC row is in docs/governance/issues-log.md (when that file is there). The list is absent by default, so once
enforcement is on every self-approval is refused until Sam adds one through `econquest change`. With four_eyes "off"
nothing here runs unless `--as` is given.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import hmac
import json
import os
import re
from pathlib import Path

REGISTRY_NAME = "users.json"
ROLES = ("owner", "analyst", "validator")
MODES = ("off", "enforce")
ID_RE = re.compile(r"[a-z][a-z0-9_-]{1,31}")
FP_RE = re.compile(r"hmac-sha256:[0-9a-f]{32}")
KEYCHAIN_SERVICE = "econquest-signing"
ENV_PREFIX = "ECONQUEST_SIGNING_KEY_"
MIN_SECRET = 32
SIG_FIELDS = ("approver_id", "key_fp", "signature")
PAYLOAD_PREFIX = "econquest-approval-v1\n"
SCOPES = ("change", "review", "attest", "findings", "overlay")   # EQ-C-0109; "overlay": econquest overlay approve (EQ-C-0161)
EXC_RE = re.compile(r"EXC-\d{3,}")
DATE_RE = re.compile(r"\d{4}-\d{2}-\d{2}")
SIGNOFF_LOG = "signoffs.jsonl"
GENESIS = "0" * 64


class IdentityError(ValueError):
    """Invalid registry, unknown or inactive user, missing or wrong key, or a four-eyes violation."""


def _pk(s) -> str:
    from ..ingestion.ledger import person_key
    return person_key(s or "")


# ---------------------------------------------------------------- registry
def validate_registry(doc, where: str = REGISTRY_NAME) -> dict:
    """Normalised registry {"four_eyes", "enforced_from", "users": {id: user}}; IdentityError when invalid."""
    if not isinstance(doc, dict):
        raise IdentityError(f"{where}: expected a JSON object")
    mode = doc.get("four_eyes", "off")
    if mode not in MODES:
        raise IdentityError(f"{where}: four_eyes must be one of {MODES}, got {mode!r}")
    ef = str(doc.get("enforced_from") or "")
    if ef:
        try:
            dt.datetime.fromisoformat(ef.replace("Z", "+00:00"))
        except ValueError:
            raise IdentityError(f"{where}: enforced_from must be an ISO time, got {ef!r}") from None
    if mode == "enforce" and not ef:
        raise IdentityError(f"{where}: four_eyes enforce needs enforced_from (rows before it are legacy single-operator)")
    users, names = {}, set()
    lst = doc.get("users", [])
    if not isinstance(lst, list):
        raise IdentityError(f"{where}: users must be a list")
    for u in lst:
        if not isinstance(u, dict):
            raise IdentityError(f"{where}: each user must be an object")
        uid, name = str(u.get("id", "")), str(u.get("name", "")).strip()
        if not ID_RE.fullmatch(uid):
            raise IdentityError(f"{where}: user id {uid!r} must be 2-32 of a-z, 0-9, '_', '-' starting with a letter")
        if uid in users:
            raise IdentityError(f"{where}: duplicate user id {uid}")
        if not _pk(name) or len(name) > 80:
            raise IdentityError(f"{where}: user {uid} needs a name (at most 80 characters)")
        if _pk(name) in names or _pk(uid) in names:
            raise IdentityError(f"{where}: user {uid}: name {name!r} matches another user (person_key)")
        names |= {_pk(name), _pk(uid)}
        if u.get("role") not in ROLES:
            raise IdentityError(f"{where}: user {uid} role must be one of {ROLES}")
        if not isinstance(u.get("active", True), bool):
            raise IdentityError(f"{where}: user {uid} active must be true or false")
        fp = str(u.get("key_fingerprint") or "")
        prev = u.get("previous_fingerprints") or []
        if (fp and not FP_RE.fullmatch(fp)) or not isinstance(prev, list) or any(not FP_RE.fullmatch(str(p)) for p in prev):
            raise IdentityError(f"{where}: user {uid} key fingerprints must look like hmac-sha256:<32 hex>")
        users[uid] = {"id": uid, "name": name, "role": u["role"], "active": u.get("active", True),
                      "key_fingerprint": fp, "previous_fingerprints": [str(p) for p in prev]}
    return {"four_eyes": mode, "enforced_from": ef, "users": users,
            "exceptions": _validate_exceptions(doc.get("self_approval_exceptions", []), where)}


def _validate_exceptions(lst, where: str) -> list[dict]:
    """users.json self_approval_exceptions (EQ-C-0109): [{"exc": "EXC-nnn", "scopes": [...], "expires": "YYYY-MM-DD"}]."""
    if not isinstance(lst, list):
        raise IdentityError(f"{where}: self_approval_exceptions must be a list")
    out = []
    for e in lst:
        if not isinstance(e, dict):
            raise IdentityError(f"{where}: each self_approval_exceptions entry must be an object")
        exc, scopes, exp = str(e.get("exc", "")), e.get("scopes"), str(e.get("expires", ""))
        if not EXC_RE.fullmatch(exc):
            raise IdentityError(f"{where}: self_approval_exceptions exc must look like EXC-nnn, got {exc!r}")
        if not isinstance(scopes, list) or not scopes or any(s not in SCOPES for s in scopes):
            raise IdentityError(f"{where}: {exc} scopes must be a non-empty list of {SCOPES}")
        try:
            if not DATE_RE.fullmatch(exp):
                raise ValueError
            dt.date.fromisoformat(exp)
        except ValueError:
            raise IdentityError(f"{where}: {exc} needs expires as YYYY-MM-DD (an exception without an expiry is refused)") from None
        out.append({"exc": exc, "scopes": list(scopes), "expires": exp})
    return out


def load_registry(data_dir) -> dict:
    """data/users.json normalised; absent -> no users, four_eyes off (single-operator mode, as before)."""
    p = Path(data_dir) / REGISTRY_NAME
    if not p.exists():
        return {"four_eyes": "off", "enforced_from": "", "users": {}, "exceptions": [], "source": "default"}
    try:
        doc = json.loads(p.read_text(encoding="utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise IdentityError(f"{p}: not valid JSON ({e})") from None
    return {**validate_registry(doc, str(p)), "source": str(p)}


def governed_registry(data_dir) -> dict:
    """The registry that approvals may trust (SEC-C-012 M1). users.json counts only as the bytes last written by an
    `econquest change` apply (or a baseline with a second sign-off) while the approvals chain verifies:
    - absent and never applied, never applied (hand-made), or only baselined by one person: the single-operator
      default (no users, four_eyes off), so a hand-made file cannot register a key for someone else;
    - drifted from, or deleted after, the applied version: IdentityError (fail closed), so deleting users.json or
      setting four_eyes "off" by hand cannot switch enforcement off.
    Recovery from drift: restore the file, or `econquest change baseline users.json` with a second sign-off."""
    from . import approvals as ap
    reg = load_registry(data_dir)
    st = ap.file_status(data_dir, REGISTRY_NAME)
    if not st["chain_ok"]:
        raise IdentityError("the approvals log does not verify, so users.json cannot be trusted")
    default = {"four_eyes": "off", "enforced_from": "", "users": {}, "exceptions": []}
    if st["status"] in ("default", "no_baseline"):
        return {**default, "source": f"default (users.json {'absent' if st['status'] == 'default' else 'never applied through econquest change'})"}
    if st["status"] != "ok":
        raise IdentityError(f"users.json is {st['status']} since the version applied through econquest change "
                            f"({st['last_event']} {st['last_id'] or ''} at {st['last_ts_utc'][:19]}); approvals are refused "
                            "until it is restored or re-accepted with `econquest change baseline users.json` and a second sign-off")
    rows = ap.read_log(data_dir)
    last = ap._last_applied(rows, REGISTRY_NAME) or {}
    if last.get("event") == "baseline" and not str(last.get("approver") or "").strip():
        return {**default, "source": "default (users.json only baselined by one person)"}
    if last.get("event") == "baseline":                  # EQ-C-0109: under enforcement a baseline is a signed sign-off too
        before = applied_registry(data_dir, rows)
        if enforced(before) and str(last.get("ts_utc", "")) >= _ts_key(before["enforced_from"]):
            problem = baseline_problem(before, last, data_dir)
            if problem:
                raise IdentityError(f"users.json was baselined at seq {last.get('seq')} without a valid named-user "
                                    f"sign-off while four-eyes is enforced ({problem}); approvals are refused until it is "
                                    "restored")
    return reg


def applied_registry(data_dir, rows=None) -> dict:
    """The registry as the last users.json `change apply` wrote it (from its proposal text); the single-operator
    default when users.json was never applied. Used to judge a baseline of a drifted users.json (EQ-C-0109)."""
    from . import approvals as ap
    rows = ap.read_log(data_dir) if rows is None else rows
    last = next((r for r in reversed(rows) if r.get("file") == REGISTRY_NAME and r.get("event") == "apply"), None)
    if last is None:
        return {"four_eyes": "off", "enforced_from": "", "users": {}, "exceptions": []}
    try:
        return validate_registry(json.loads(ap.load_proposal(data_dir, last["id"])["new_text"]))
    except (ap.ApprovalError, ValueError, KeyError) as e:
        raise IdentityError(f"cannot read the last applied users.json ({e})") from None


def trusted_registry(data_dir) -> dict:
    """governed_registry, or, while users.json itself has drifted, the last applied one (so accepting that drift is
    judged by the rules in force before the hand edit)."""
    try:
        return governed_registry(data_dir)
    except IdentityError:
        from . import approvals as ap
        st = ap.file_status(data_dir, REGISTRY_NAME)
        if not st["chain_ok"]:
            raise
        return applied_registry(data_dir)


def baseline_problem(reg: dict, row: dict, data_dir=None) -> str | None:
    """Why a baseline row logged under enforcement is not a valid named-user sign-off (None when it is)."""
    if not row.get("approver_id"):
        return "not signed"
    actor = user_for(reg, row.get("actor"))
    if row.get("self_approved") == "yes":
        if actor is None or actor["id"] != row.get("approver_id"):
            return "self-approval not signed by the actor"
        return self_approval_problem(reg, "change", row.get("exc_id"), row.get("ts_utc"), data_dir)
    if actor is not None and actor["id"] == row.get("approver_id"):
        return "approver is the actor"
    u = reg["users"].get(str(row.get("approver_id")))
    if u is None or not u["active"]:
        return "approver is not an active registered user"
    st = check_signature(row, reg)
    return None if st in ("ok", "unchecked") else st


def owner_user(data_dir, owner_name: str) -> dict | None:
    """The governed registry's user for `owner_name` when that user has an enrolled key, else None (then the owner's
    decision is checked by name only, which is self-asserted: SEC-C-011 L2)."""
    u = user_for(governed_registry(data_dir), owner_name)
    return u if u and u["key_fingerprint"] else None


def active_users(reg: dict) -> list[dict]:
    return [u for u in reg["users"].values() if u["active"]]


def enforced(reg: dict) -> bool:
    """Four-eyes by named users is enforced only with four_eyes "enforce" and two or more active users."""
    return reg["four_eyes"] == "enforce" and len(active_users(reg)) >= 2


def user_for(reg: dict, who) -> dict | None:
    """The user whose id or name matches `who` (person_key: case, whitespace, NFKC, zero-width ignored)."""
    k = _pk(who)
    if not k:
        return None
    return next((u for u in reg["users"].values() if k in (_pk(u["id"]), _pk(u["name"]))), None)


def _day(ts) -> dt.date:
    """The UTC date of a log ts_utc / ISO time / datetime; today (UTC) when empty."""
    if not ts:
        return dt.datetime.now(dt.timezone.utc).date()
    if isinstance(ts, dt.datetime):
        return (ts.astimezone(dt.timezone.utc) if ts.tzinfo else ts).date()
    return dt.date.fromisoformat(str(ts)[:10])


def self_approval_problem(reg: dict, scope: str, exc_id, when=None, data_dir=None) -> str | None:
    """None when users.json lists exc_id for `scope`, unexpired on `when` (UTC date), and the issues log (when present)
    lists it; else why a self-approval under enforcement is refused (EQ-C-0109)."""
    exc = str(exc_id or "").strip()
    if not exc:
        return (f"four-eyes is enforced: self-approval is not allowed without a named exception (--exc EXC-nnn) that users.json "
                f"self_approval_exceptions lists for {scope!r}; otherwise a second registered user approves")
    e = next((x for x in reg.get("exceptions", []) if x["exc"] == exc and scope in x["scopes"]), None)
    if e is None:
        return f"four-eyes is enforced: self-approval is not allowed: {exc} is not a self_approval_exceptions entry for {scope!r} in users.json"
    day = _day(when)
    if day > dt.date.fromisoformat(e["expires"]):
        return f"four-eyes is enforced: self-approval is not allowed: {exc} expired on {e['expires']} (users.json self_approval_exceptions)"
    if data_dir is not None:
        from .approvals import exc_logged
        if exc_logged(data_dir, exc) is False:
            return f"four-eyes is enforced: self-approval is not allowed: {exc} is not listed in docs/governance/issues-log.md"
    return None


# ---------------------------------------------------------------- keys and signatures
def env_name(user_id: str) -> str:
    return ENV_PREFIX + user_id.upper().replace("-", "_")


def _keychain(service: str, account: str) -> str | None:
    """macOS Keychain generic password (service, account); any failure -> None. Fixed argv, no shell."""
    import shutil
    import subprocess  # nosec B404: only the fixed Keychain lookup below
    exe = shutil.which("security")
    if not exe:
        return None
    try:
        r = subprocess.run([exe, "find-generic-password", "-s", service, "-a", account, "-w"], capture_output=True,
                           text=True, timeout=10)  # nosec B603
    except (OSError, subprocess.SubprocessError):
        return None
    s = (r.stdout or "").strip()
    return s if r.returncode == 0 and s else None


def secret_for(user_id: str, env: dict | None = None, keychain=None) -> str | None:
    """The user's signing secret from $ECONQUEST_SIGNING_KEY_<ID>, else the Keychain; None when neither has it."""
    env = os.environ if env is None else env
    s = (env.get(env_name(user_id)) or "").strip()
    if not s:
        s = ((keychain or _keychain)(KEYCHAIN_SERVICE, user_id) or "").strip()
    return s or None


def fingerprint(secret: str) -> str:
    return "hmac-sha256:" + hashlib.sha256(b"econquest-signing-key-v1\0" + secret.encode("utf-8")).hexdigest()[:32]


def payload(fields: dict) -> bytes:
    keep = {k: str(fields.get(k) or "") for k in ("event", "id", "file", "base_sha256", "new_sha256", "approver",
                                                   "self_approved", "exc_id", "approver_id", "key_fp")}
    return (PAYLOAD_PREFIX + json.dumps(keep, sort_keys=True, separators=(",", ":"))).encode("utf-8")


def sign(user: dict, fields: dict, env: dict | None = None, keychain=None) -> dict:
    """{approver_id, key_fp, signature} for an approval row by `user` (must be active, with a matching key)."""
    if not user["active"]:
        raise IdentityError(f"user {user['id']} is not active")
    if not user["key_fingerprint"]:
        raise IdentityError(f"user {user['id']} has no key_fingerprint in users.json (enrol a key first)")
    secret = secret_for(user["id"], env, keychain)
    if not secret:
        raise IdentityError(f"no signing key for {user['id']}: set ${env_name(user['id'])} or the Keychain item "
                            f"service {KEYCHAIN_SERVICE}, account {user['id']}")
    if len(secret) < MIN_SECRET:
        raise IdentityError(f"signing key for {user['id']} is shorter than {MIN_SECRET} characters")
    fp = fingerprint(secret)
    if fp != user["key_fingerprint"]:
        raise IdentityError(f"signing key for {user['id']} does not match its registered fingerprint")
    out = {"approver_id": user["id"], "key_fp": fp}
    out["signature"] = hmac.new(secret.encode("utf-8"), payload({**fields, **out}), hashlib.sha256).hexdigest()
    return out


def check_signature(row: dict, reg: dict, env: dict | None = None, keychain=None) -> str:
    """"ok", "unchecked" (secret not available here) or an error message, for a row that carries SIG_FIELDS."""
    uid = str(row.get("approver_id") or "")
    u = reg["users"].get(uid)
    if u is None:
        return f"approver_id {uid!r} is not in users.json"
    fp = str(row.get("key_fp") or "")
    if fp not in {u["key_fingerprint"], *u["previous_fingerprints"]} or not fp:
        return f"key_fp of {uid} is not a fingerprint registered for that user"
    if _pk(row.get("approver")) not in (_pk(u["name"]), _pk(u["id"])):
        return f"approver {row.get('approver')!r} is not the name of {uid}"
    secret = secret_for(uid, env, keychain)
    if not secret or fingerprint(secret) != fp:
        return "unchecked"
    exp = hmac.new(secret.encode("utf-8"), payload(row), hashlib.sha256).hexdigest()
    return "ok" if hmac.compare_digest(exp, str(row.get("signature") or "")) else "signature does not verify (row or key changed)"


# ---------------------------------------------------------------- approval hooks (ops/approvals.py)
def resolve_approver(data_dir, prop: dict, approver, approver_id, self_approved: bool, exc_id=None,
                     now=None, reg: dict | None = None) -> tuple[str | None, dict | None]:
    """(approver name to pass to the four-eyes rule, the signing user or None). Four-eyes off or a single operator:
    without approver_id nothing changes. Enforced: approver_id is required, the approver must differ from the proposer,
    and a self-approval (signed by the proposer) needs a named, unexpired users.json exception for "change" (EQ-C-0109)."""
    reg = governed_registry(data_dir) if reg is None else reg
    on = enforced(reg)
    if not approver_id:
        if on:
            raise IdentityError("four-eyes is enforced (users.json, two or more active users): approve with --as <user id>, "
                                "signed with that user's key")
        return approver, None
    user = reg["users"].get(str(approver_id))
    if user is None:
        raise IdentityError(f"--as {approver_id!r}: no such user in users.json")
    if not user["active"]:
        raise IdentityError(f"--as {user['id']}: user is not active (offboarded)")
    if approver and _pk(approver) not in (_pk(user["name"]), _pk(user["id"])):
        raise IdentityError(f"--approver {approver!r} is not the name of user {user['id']} ({user['name']})")
    proposer = user_for(reg, prop.get("author"))
    if on:
        if proposer is None:
            raise IdentityError(f"four-eyes is enforced: the author {prop.get('author')!r} is not a registered user")
        if self_approved:
            problem = self_approval_problem(reg, "change", exc_id, now, data_dir)
            if problem:
                raise IdentityError(problem)
        elif proposer["id"] == user["id"]:
            raise IdentityError(f"four-eyes is enforced: {user['id']} proposed this change and cannot approve it "
                                "(a second registered user approves, or --self-approved under a named EXC)")
    if self_approved and (proposer is None or proposer["id"] != user["id"]):
        raise IdentityError(f"--self-approved with --as {user['id']}: the author {prop.get('author')!r} is not {user['id']}")
    return user["name"], user


def verify_signatures(data_dir, rows: list[dict] | None = None, env: dict | None = None, keychain=None) -> dict:
    """Signature and four-eyes check over the approvals log. Returns {"ok", "signed", "checked", "unchecked",
    "enforced", "errors"}. Without users.json and without signed rows this is trivially ok (legacy ledgers)."""
    from .approvals import read_log
    rows = read_log(data_dir) if rows is None else rows
    errors, signed, checked, unchecked = [], 0, 0, 0
    try:
        reg = governed_registry(data_dir)
    except IdentityError as e:
        return {"ok": False, "signed": 0, "checked": 0, "unchecked": 0, "enforced": False, "errors": [str(e)]}
    on = enforced(reg)
    since = reg["enforced_from"]
    authors = {r.get("id"): r.get("actor") for r in rows if r.get("event") == "propose"}
    for r in rows:
        if r.get("event") not in ("approve", "baseline"):
            continue
        where = f"seq {r.get('seq')} ({r.get('event')} {r.get('id') or r.get('file')})"
        if any(r.get(k) for k in SIG_FIELDS):
            signed += 1
            st = check_signature(r, reg, env, keychain)
            if st == "ok":
                checked += 1
            elif st == "unchecked":
                unchecked += 1
            else:
                errors.append(f"{where}: {st}")
        if on and r.get("event") == "approve" and str(r.get("ts_utc", "")) >= _ts_key(since):
            proposer = user_for(reg, authors.get(r.get("id")))
            if not r.get("approver_id"):
                errors.append(f"{where}: unsigned approval while four-eyes is enforced")
            elif r.get("self_approved") == "yes":
                problem = self_approval_problem(reg, "change", r.get("exc_id"), r.get("ts_utc"))
                if problem or proposer is None or proposer["id"] != r.get("approver_id"):
                    errors.append(f"{where}: self-approval while four-eyes is enforced ({problem or 'not signed by the proposer'})")
            elif proposer is None or proposer["id"] == r.get("approver_id"):
                errors.append(f"{where}: approver {r.get('approver_id')} is the proposer (or the proposer is not registered)")
    so = verify_signoffs(data_dir, reg, env, keychain)
    signed, checked, unchecked = signed + so["signed"], checked + so["checked"], unchecked + so["unchecked"]
    errors += so["errors"]
    return {"ok": not errors, "signed": signed, "checked": checked, "unchecked": unchecked, "enforced": on, "errors": errors}


def check_apply(data_dir, prop: dict, row: dict, env: dict | None = None, keychain=None, proposed_utc: str = "",
                now=None) -> None:
    """SEC-C-012 R27: before `apply` writes, re-check the approve row against the governed registry, so a row written
    straight into the (unkeyed) ledger cannot be applied. Not enforced, or an approval logged before enforced_from:
    nothing to check. Enforced: the row must be signed by a registered user other than the proposer, not a
    self-approval, and its signature must not fail (it may be "unchecked" where the signer's key is not present: the
    HMAC limit; D4 keyed heads close that gap). An untrustworthy registry fails closed (IdentityError)."""
    reg = governed_registry(data_dir)
    if not enforced(reg):
        return
    ts, prop_ts = str(row.get("ts_utc", "")), str(proposed_utc or "")
    if prop_ts and ts < prop_ts:                     # SEC-C-014 L3: a backdated row (the ledger has no time check)
        raise IdentityError("the approval is dated before its proposal: not a genuine approve row")
    if max(ts, prop_ts) < _ts_key(reg["enforced_from"]):
        return
    if not row.get("approver_id"):
        raise IdentityError("four-eyes is enforced but the approval is not signed (approve again with --as)")
    proposer = user_for(reg, prop.get("author"))
    if row.get("self_approved") == "yes":                 # EQ-C-0109: only under a named, unexpired EXC, by the proposer
        problem = self_approval_problem(reg, "change", row.get("exc_id"), now, data_dir)
        if problem:
            raise IdentityError(f"the approval is a self-approval: {problem}")
        if proposer is None or proposer["id"] != row.get("approver_id"):
            raise IdentityError("the self-approval is not signed by the proposer")
    elif proposer is None or proposer["id"] == row.get("approver_id"):
        raise IdentityError(f"four-eyes is enforced: approver {row.get('approver_id')} is the proposer, or the proposer "
                            "is not a registered user")
    u = reg["users"].get(str(row.get("approver_id")))
    if u is None or not u["active"]:
        raise IdentityError(f"approver {row.get('approver_id')} is not an active registered user")
    st = check_signature(row, reg, env, keychain)
    if st not in ("ok", "unchecked"):
        raise IdentityError(f"approval signature: {st}")


def _ts_key(iso: str) -> str:
    """enforced_from in the log's ts_utc format (YYYY-MM-DDTHH:MM:SS.ffffffZ) so strings compare in time order."""
    t = dt.datetime.fromisoformat(iso.replace("Z", "+00:00"))
    t = t.replace(tzinfo=dt.timezone.utc) if t.tzinfo is None else t.astimezone(dt.timezone.utc)
    return t.strftime("%Y-%m-%dT%H:%M:%S.%fZ")


# ---------------------------------------------------------------- sign-offs outside `change` (EQ-C-0109)
def signoff_path(data_dir) -> Path:
    return Path(data_dir) / "approvals" / SIGNOFF_LOG


def subject_sha256(subject) -> str:
    """sha256 of the canonical JSON of what is signed off (cells, finding id and evidence, ...)."""
    return hashlib.sha256(json.dumps(subject, sort_keys=True, separators=(",", ":"), default=str).encode("utf-8")).hexdigest()


def prepare_signoff(data_dir, scope: str, author, approver=None, approver_id=None, self_approved: bool = False,
                    exc_id=None, subject=None, conflicts=(), env: dict | None = None, keychain=None, now=None) -> dict | None:
    """Four-eyes by named users for a sign-off outside `econquest change`: scope "review" (review approve / decide
    apply), "attest", "findings" (findings close; `conflicts` = owner, planners, evidence actors) or "overlay"
    (econquest overlay approve; author = the entry's author, EQ-C-0161).

    Four-eyes off (or fewer than two active users) and no approver_id: None, nothing changes. Otherwise returns the
    signed row (not yet written: call record_signoff after the sign-off itself succeeded). Enforced: approver_id is
    required, the author must be a registered user, the approver must not be the author (or any of `conflicts`), and
    a self-approval needs a named, unexpired users.json exception for `scope`. The returned "approver" is the
    registered user's name, to pass on to the ledger that records the sign-off."""
    if scope not in SCOPES or scope == "change":
        raise IdentityError(f"unknown sign-off scope {scope!r}")
    reg = governed_registry(data_dir)
    on = enforced(reg)
    if not approver_id:
        if on:
            raise IdentityError(f"four-eyes is enforced (users.json): sign this {scope} with --as <user id>, using that "
                                "user's key")
        return None
    user = reg["users"].get(str(approver_id))
    if user is None:
        raise IdentityError(f"--as {approver_id!r}: no such user in users.json")
    if not user["active"]:
        raise IdentityError(f"--as {user['id']}: user is not active (offboarded)")
    if approver and not self_approved and _pk(approver) not in (_pk(user["name"]), _pk(user["id"])):
        raise IdentityError(f"--approver {approver!r} is not the name of user {user['id']} ({user['name']})")
    au = user_for(reg, author)
    involved = {x["id"] for x in (user_for(reg, c) for c in [author, *conflicts]) if x}
    is_self = bool(self_approved) or user["id"] in involved
    if on and au is None:
        raise IdentityError(f"four-eyes is enforced: the author {author!r} is not a registered user")
    if self_approved and (au is None or au["id"] != user["id"]):
        raise IdentityError(f"--self-approved with --as {user['id']}: the author {author!r} is not {user['id']}")
    if on and is_self:
        if not self_approved and user["id"] in involved:
            raise IdentityError(f"four-eyes is enforced: {user['id']} is the author (or owner, planner or evidence "
                                f"provider) and cannot approve; a second registered user approves, or --self-approved "
                                "under a named EXC")
        problem = self_approval_problem(reg, scope, exc_id, now, data_dir)
        if problem:
            raise IdentityError(problem)
    exc = str(exc_id or "").strip() if is_self else ""
    if exc and not EXC_RE.fullmatch(exc):
        raise IdentityError(f"exception id must look like EXC-nnn, got {exc_id!r}")
    t = now or dt.datetime.now(dt.timezone.utc)
    row = {"ts_utc": t.astimezone(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ"), "event": scope,
           "id": subject_sha256(subject), "file": scope, "base_sha256": "", "new_sha256": "",
           "actor": str(author or "").strip(), "approver": user["name"], "self_approved": "yes" if is_self else "",
           "exc_id": exc, "enforced": "yes" if on else ""}
    row.update(sign(user, row, env, keychain))
    return row


def record_signoff(data_dir, row: dict) -> dict:
    """Append a prepare_signoff row to data/approvals/signoffs.jsonl (seq, prev_hash, row_hash chain)."""
    from . import approvals as ap
    with ap._locked(data_dir):
        rows = read_signoffs(data_dir)
        prev = rows[-1]["row_hash"] if rows else GENESIS
        out = {**row, "seq": len(rows) + 1, "prev_hash": prev}
        out["row_hash"] = hashlib.sha256((prev + json.dumps(out, sort_keys=True, separators=(",", ":"))).encode("utf-8")).hexdigest()
        p = signoff_path(data_dir)
        p.parent.mkdir(parents=True, exist_ok=True)
        with open(p, "a", encoding="utf-8") as f:
            f.write(json.dumps(out, sort_keys=True, separators=(",", ":")) + "\n")
            f.flush(); os.fsync(f.fileno())
    return out


class Signoff:
    """One named-user sign-off around a ledger write: the constructor runs every check (refusal before anything is
    written); `approver` is what to pass to the ledger; record(subject) signs what was written and logs it. With
    four-eyes off and no approver_id it is inactive and changes nothing."""

    def __init__(self, data_dir, scope, author, approver=None, approver_id=None, self_approved=False, exc_id=None,
                 conflicts=(), env=None, keychain=None):
        self._kw = dict(scope=scope, author=author, approver=approver, approver_id=approver_id,
                        self_approved=self_approved, exc_id=exc_id, conflicts=tuple(conflicts), env=env, keychain=keychain)
        self.data_dir = data_dir
        row = prepare_signoff(data_dir, subject=None, **self._kw)
        self.active = row is not None
        self.approver = row["approver"] if row and not self_approved else approver
        self.row = row

    def record(self, subject) -> dict | None:
        if not self.active:
            return None
        self.row = record_signoff(self.data_dir, prepare_signoff(self.data_dir, subject=subject, **self._kw))
        return self.row


def cli_signoff(data_dir, args, scope: str, author=None) -> Signoff:
    """Signoff from argparse args (--approver, --as, --self-approved, --exc); SystemExit with the reason on refusal."""
    try:
        return Signoff(data_dir, scope, args.author if author is None else author, getattr(args, "approver", None),
                       getattr(args, "approver_id", None), bool(getattr(args, "self_approved", False)),
                       getattr(args, "exc", None))
    except IdentityError as e:
        raise SystemExit(f"{scope}: {e}") from None


def read_signoffs(data_dir) -> list[dict]:
    p = signoff_path(data_dir)
    if not p.exists():
        return []
    try:
        return [json.loads(line) for line in p.read_text(encoding="utf-8").splitlines() if line.strip()]
    except json.JSONDecodeError as e:
        raise IdentityError(f"{p}: not valid JSON lines ({e})") from None


def verify_signoffs(data_dir, reg: dict, env: dict | None = None, keychain=None) -> dict:
    """Chain and signatures of data/approvals/signoffs.jsonl; absent = trivially ok."""
    errors, signed, checked, unchecked = [], 0, 0, 0
    try:
        rows = read_signoffs(data_dir)
    except IdentityError as e:
        return {"signed": 0, "checked": 0, "unchecked": 0, "errors": [str(e)]}
    prev = GENESIS
    for i, r in enumerate(rows, 1):
        where = f"signoffs seq {r.get('seq')} ({r.get('event')})"
        body = {k: v for k, v in r.items() if k != "row_hash"}
        h = hashlib.sha256((prev + json.dumps(body, sort_keys=True, separators=(",", ":"))).encode("utf-8")).hexdigest()
        if r.get("seq") != i or r.get("prev_hash") != prev or r.get("row_hash") != h:
            errors.append(f"{where}: hash chain broken (row edited, deleted, inserted or reordered)")
        prev = str(r.get("row_hash") or "")
        signed += 1
        st = check_signature(r, reg, env, keychain)
        if st == "ok":
            checked += 1
        elif st == "unchecked":
            unchecked += 1
        else:
            errors.append(f"{where}: {st}")
        if r.get("self_approved") == "yes" and r.get("enforced") == "yes":
            problem = self_approval_problem(reg, str(r.get("event")), r.get("exc_id"), r.get("ts_utc"))
            if problem:
                errors.append(f"{where}: {problem}")
    return {"signed": signed, "checked": checked, "unchecked": unchecked, "errors": errors}


# ---------------------------------------------------------------- onboarding helper (EQ-C-0084), print only
def plan_change(data_dir, kind: str, user_id: str, name: str | None = None, role: str = "analyst",
                new_fp: str | None = None, author: str = "Sam", exc: str = "EXC-nnn") -> dict:
    """What an onboard / offboard / rotate needs, without writing anything: {"sets": {pointer: value}, "allow_new_keys",
    "new_doc", "keychain": [...], "approve": str, "warnings": [...]}. The would-be users.json is validated, so the
    printed proposal is one `econquest change propose` accepts."""
    import copy as _copy
    if not ID_RE.fullmatch(user_id or ""):
        raise IdentityError(f"not a user id: {user_id!r} (2-32 of a-z, 0-9, '_', '-', starting with a letter)")
    if new_fp is not None and not FP_RE.fullmatch(new_fp):
        raise IdentityError("fingerprint must look like hmac-sha256:<32 hex> (econquest users fingerprint --id ID)")
    p = Path(data_dir) / REGISTRY_NAME
    doc = json.loads(p.read_text(encoding="utf-8")) if p.exists() else {"four_eyes": "off", "enforced_from": "", "users": []}
    validate_registry(doc, str(p))
    users = doc.get("users", [])
    idx = next((i for i, u in enumerate(users) if u.get("id") == user_id), None)
    fp = new_fp or "hmac-sha256:<32 hex from step 2>"
    sets, allow_new, warnings = {}, False, []
    keychain = []
    if kind in ("onboard", "rotate"):
        keychain = [f"# on {user_id}'s own macOS login; the key never goes on a command line, in a file or in e-mail",
                    "openssl rand -hex 32                                   # copy the output",
                    f"security add-generic-password -U -s {KEYCHAIN_SERVICE} -a {user_id} -w"
                    "   # paste it at the hidden prompt",
                    f"econquest users fingerprint --id {user_id}             # send this fingerprint (not secret) to {author}"]
    if kind == "onboard":
        if idx is not None:
            raise IdentityError(f"{user_id} is already registered (rotate or offboard instead)")
        entry = {"id": user_id, "name": str(name or "").strip(), "role": role, "key_fingerprint": fp,
                 "previous_fingerprints": [], "active": True}
        sets["/users/-"] = entry; allow_new = True
    else:
        if idx is None:
            raise IdentityError(f"{user_id} is not in users.json")
        if kind == "offboard":
            sets[f"/users/{idx}/active"] = False
            keychain = [f"security delete-generic-password -s {KEYCHAIN_SERVICE} -a {user_id}   # on {user_id}'s login, after the change is applied"]
        else:
            old = users[idx].get("key_fingerprint") or ""
            prev = list(users[idx].get("previous_fingerprints") or []) + ([old] if old else [])
            sets[f"/users/{idx}/previous_fingerprints"] = prev
            allow_new = "previous_fingerprints" not in users[idx]
            sets[f"/users/{idx}/key_fingerprint"] = fp
    new = _copy.deepcopy(doc)
    nu = new.setdefault("users", [])
    if kind == "onboard":
        nu.append(_copy.deepcopy(sets["/users/-"]))
    else:
        for ptr, v in sets.items():
            nu[idx][ptr.rsplit("/", 1)[1]] = _copy.deepcopy(v)
    check = _copy.deepcopy(new)
    if new_fp is None and kind in ("onboard", "rotate"):        # validate with a well-formed stand-in
        for u in check["users"]:
            if u.get("key_fingerprint") == fp:
                u["key_fingerprint"] = "hmac-sha256:" + "0" * 32
    validate_registry(check, "the proposed users.json")
    try:
        gov = governed_registry(data_dir)
        on = enforced(gov)
    except IdentityError as e:
        gov, on = None, False
        warnings.append(f"the governed registry cannot be trusted right now ({e}); fix that before proposing")
    if on:
        au = user_for(gov, author)
        others = [u["id"] for u in active_users(gov) if (au is None or u["id"] != au["id"])
                  and not (kind in ("offboard", "rotate") and u["id"] == user_id)]     # EQ-C-0109: never the subject
        if others:
            approve = f"econquest change approve CHG-... --as {others[0]}   # a second registered user, on their login"
        else:
            approve = (f"econquest change approve CHG-... --as {au['id'] if au else '<author id>'} --self-approved --exc EXC-nnn"
                       "   # only under a named, unexpired users.json self_approval_exceptions entry for change")
            warnings.append(f"no active user other than {author} and {user_id} can approve: have {user_id} propose it "
                            f"(--author {user_id}) and {author} approve with --as, or self-approve under a named EXC")
        after = validate_registry(check)
        if kind == "offboard" and len(active_users(after)) < 2:
            warnings.append("after this change fewer than two users are active: four-eyes enforcement lapses and the "
                            "single-operator EXC path is needed again (reopen the exception)")
    else:
        approve = f"econquest change approve CHG-... --self-approved --exc {exc}   # four-eyes not enforced yet (single operator)"
    if kind == "rotate" and on and (user_for(gov, author) or {}).get("id") != user_id:
        warnings.append(f"under four-eyes {user_id} should propose the rotation of their own key (--author {user_id}) "
                        "and another registered user approve it, so the key holder never approves their own key")
    if new_fp is None and kind in ("onboard", "rotate"):
        warnings.append("fingerprint not given: replace the placeholder with the output of step 2 before running the proposal")
    return {"sets": sets, "allow_new_keys": allow_new, "new_doc": new, "keychain": keychain, "approve": approve,
            "warnings": warnings, "author": author}


def plan_lines(data_dir, args) -> list[str]:
    import shlex
    plan = plan_change(data_dir, args.users_cmd, args.id, getattr(args, "name", None), getattr(args, "role", "analyst"),
                       getattr(args, "fingerprint", None), args.author, args.exc)
    reason = {"onboard": f"onboard {getattr(args, 'name', '') or args.id} ({args.id})", "offboard": f"offboard {args.id}",
              "rotate": f"rotate the signing key of {args.id}"}[args.users_cmd]
    sets = " \\\n    ".join("--set " + shlex.quote(f"{k}={json.dumps(v, separators=(',', ':'))}") for k, v in plan["sets"].items())
    out = [f"DRY RUN: users {args.users_cmd} --id {args.id}. Nothing was written; run these yourself, in order.", ""]
    n = 1
    if plan["keychain"] and args.users_cmd != "offboard":
        out += [f"Step {n}-{n + 1}: key and fingerprint"] + ["  " + c for c in plan["keychain"]] + [""]
        n += 2
    out += [f"Step {n}: propose the users.json change",
            f"  econquest change propose users.json{' --allow-new-keys' if plan['allow_new_keys'] else ''} --author {shlex.quote(plan['author'])} "
            f"--reason {shlex.quote(reason)} \\\n    {sets}",
            f"Step {n + 1}: approve", "  " + plan["approve"],
            f"Step {n + 2}: apply and check", f"  econquest change apply CHG-... --actor {shlex.quote(plan['author'])}",
            "  econquest users list && econquest users verify && econquest change verify"]
    if args.users_cmd == "offboard":
        out += [f"Step {n + 3}: remove the key", "  " + plan["keychain"][0]]
    if args.users_cmd == "rotate":
        out += [f"Step {n + 3}: approvals signed with the old key keep verifying through previous_fingerprints; new ones "
                "sign with the key from step 1 (it replaced the old Keychain item, -U)"]
    out += [""] + [f"WARNING: {w}" for w in plan["warnings"]]
    return out


# ---------------------------------------------------------------- CLI: econquest users list|fingerprint|verify
def add_arguments(ap) -> None:
    sub = ap.add_subparsers(dest="users_cmd", required=True)
    sub.add_parser("list", help="registered users, roles, active flag, whether a key is enrolled, and the four-eyes mode")
    fp = sub.add_parser("fingerprint", help="print the key fingerprint for a user's secret ($ECONQUEST_SIGNING_KEY_<ID> or "
                                            "Keychain econquest-signing/<id>) to put in users.json; never prints the secret")
    fp.add_argument("--id", required=True)
    sub.add_parser("verify", help="check signed approval rows and the four-eyes rules against users.json; exit 1 on a problem")
    for name, h in (("onboard", "print the Keychain commands and the exact users.json change proposal to register a new user"),
                    ("offboard", "print the change proposal that deactivates a user (rows they signed keep verifying)"),
                    ("rotate", "print the commands to rotate a user's key (old fingerprint kept in previous_fingerprints)")):
        c = sub.add_parser(name, help=h + "; --dry-run only: nothing is written (EQ-C-0084)")
        c.add_argument("--id", required=True)
        c.add_argument("--dry-run", action="store_true", required=True, help="required: print, never write")
        c.add_argument("--author", default="Sam", help="who proposes the change (default Sam)")
        c.add_argument("--exc", default="EXC-nnn", help="the single-operator exception id used while four-eyes is not enforced")
        if name == "onboard":
            c.add_argument("--name", required=True); c.add_argument("--role", choices=ROLES, default="analyst")
        if name in ("onboard", "rotate"):
            c.add_argument("--fingerprint", help="the user's (new) fingerprint from `econquest users fingerprint --id ID`; "
                                                 "omitted: a placeholder is printed")


def run_from_args(args, data_dir) -> int:
    import sys
    try:
        if args.users_cmd == "fingerprint":
            if not ID_RE.fullmatch(args.id):
                raise IdentityError(f"not a user id: {args.id!r}")
            s = secret_for(args.id)
            if not s:
                raise IdentityError(f"no secret for {args.id}: set ${env_name(args.id)} or the Keychain item service "
                                    f"{KEYCHAIN_SERVICE}, account {args.id}")
            if len(s) < MIN_SECRET:
                raise IdentityError(f"the secret is shorter than {MIN_SECRET} characters (use openssl rand -hex 32)")
            print(fingerprint(s))
            return 0
        if args.users_cmd in ("onboard", "offboard", "rotate"):
            for line in plan_lines(data_dir, args):
                print(line)
            return 0
        reg = load_registry(data_dir)
        if args.users_cmd == "list":
            gov = governed_registry(data_dir)                 # what approvals use (SEC-C-012 M1)
            print(f"four_eyes: {gov['four_eyes']} ({'ENFORCED' if enforced(gov) else 'not enforced: single-operator rules apply'})"
                  f"; source {gov.get('source', reg['source'])}")
            if gov.get("source", "").startswith("default") and reg["users"]:
                print(f"  note: {reg['source']} is not used for approvals until it is applied through econquest change")
            for u in reg["users"].values():
                print(f"  {u['id']:<12} {u['name']:<20} {u['role']:<9} {'active' if u['active'] else 'inactive':<8} "
                      f"{'key enrolled' if u['key_fingerprint'] else 'no key'}")
            return 0
        v = verify_signatures(data_dir)
        print(f"signatures: {'ok' if v['ok'] else 'PROBLEMS'} ({v['signed']} signed rows: {v['checked']} checked, "
              f"{v['unchecked']} not checkable here); four-eyes {'enforced' if v['enforced'] else 'not enforced'}")
        for e in v["errors"]:
            print("  " + e)
        return 0 if v["ok"] else 1
    except IdentityError as e:
        print(f"users: {e}", file=sys.stderr)
        return 2
