"""Evidence bundle for an independent validator (EQ-C-0060, PI-5, roadmap 4.5).

    econquest evidence --as-of 2026-10-23 [--out DIR] [--quick] [--tests-from FILE]   build one archive
    econquest evidence verify ARCHIVE.zip                                            recheck it offline

One zip, `outputs/evidence/evidence-<as_of>.zip` by default, with one top folder `evidence-<as_of>/`:

    README.md                  what is inside and how to check it (for the validator)
    EVIDENCE-MANIFEST.json     sha256 and size of every other file, build-time results of every check
    docs/                      docs/governance/, docs/validation/ (incl. the dossier), docs/institutional-roadmap.md
    runs/index.json            each stored run for the as-of date: label, created_at, versions stamp (code_hash,
                               data_hash, per-file data hashes, run_hash) and the recomputation of both hashes
    runs/<run_id>.json         the stored run results, byte for byte from <out>/store/archive (loss paths left out)
    inputs/data/...            the data files data_hash covers today (versioning.data_files)
    hashes/current-stamp.json  versioning.stamp(data, as_of) at build time; per run, which inputs changed since
    tests/                     junit.xml (or the --tests-from file as given) and summary.json (pass/fail counts)
    replication/               replication.csv, replication.md, summary.json (validation.replicate, frozen prices)
    chains/                    copies of the approval, action, editorial and delivery hash chains, laid out as
                               data/ and outputs/ so the same verifiers run on them; verify.json (build-time result)
    dataroom/                  dossier-manifest.json (docs/validation/dossier); team-a/: Team A's data room for the
                               date (econquest.dataroom/1, EQ-A-0041), byte for byte: --data-room, else
                               <outputs>/dataroom/<as_of>/, else built into a temp folder that is deleted (EQ-C-0069)
    release/                   RELEASE-MANIFEST.txt, RELEASE-HASHES.json, RELEASE-REPLICATION.md and release.json
                               (zip name and SHA-256) from the release zip, when present

Deterministic: the bytes are a function of the inputs only. The zip is written by scripts/build_release.py's writer
(sorted entries, one timestamp from SOURCE_DATE_EPOCH or 1980-01-01, fixed modes, deflate 9); nothing in the manifest
carries a wall-clock time or an absolute path. A live pytest run or replication writes its own timings into
junit.xml and replication.md, so for byte-identical rebuilds pass --tests-from and --replication-from.

Never included: build_release's exclusions (SECRET_GLOBS credential files, __pycache__, .DS_Store ...), the loss-path
archives (*_paths.npz), the SQLite store itself (runs are exported as their archived JSON), and subscriber addresses.
data/distribution.json is shipped only as chains/distribution.redacted.json, and every e-mail address in a chain file
(the delivery log's recipients, an address named in the action log) is replaced by `[redacted:recipient-N]`, numbered
in order of first appearance. A redacted chain no longer recomputes its row hashes, so offline `verify` checks its
linkage (seq, prev_hash, head) and reports the full recomputation done at build time; unredacted chains are fully
recomputed offline with the same functions `econquest change verify`, `log verify`, `editorial verify` and
`distribute verify` use.

SEC-C-008: every entry also passes a content check. A file holding the value of a known credential (ECONQUEST_* secret
variables in the environment or <home>/.ops.env) is left out, or masked as `[redacted:secret]` in a chain; an input
file holding one stops the build. Addresses are replaced in every text file outside inputs/data/ and the data room
(counts per file in the manifest; the room is copied unchanged and a credential in it stops the build), and distribution.json loses URL credentials and query strings. `verify` refuses duplicate entry names,
checks every chain present (declared or not), and uses the linkage check only for a chain that carries a redaction.
"""
from __future__ import annotations

import contextlib
import csv
import datetime as dt
import hashlib
import importlib.util
import io
import json
import os
import re
import shutil
import sqlite3
import stat
import subprocess
import sys
import tempfile
import time
import zipfile
from pathlib import Path

FORMAT = "econquest-evidence/1"
MANIFEST = "EVIDENCE-MANIFEST.json"
README = "README.md"
DOC_PATHS = ("docs/governance", "docs/validation", "docs/institutional-roadmap.md")
DOSSIER = "docs/validation/dossier"
RELEASE_FILES = ("RELEASE-MANIFEST.txt", "RELEASE-HASHES.json", "RELEASE-REPLICATION.md")
EMAIL_RE = re.compile(r"[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?(?:\.[A-Za-z0-9-]+)+")
PACKAGE_PARENT = Path(__file__).resolve().parents[2]
DEMO_SUFFIX = "-DEMO"            # EQ-C-0123: a bundle on the DEMO licence baseline (ops/demo_baseline.py)


class EvidenceError(Exception):
    pass


# ------------------------------------------------------------------------------------------------ shared helpers
_BR = None


def build_release():
    """scripts/build_release.py, loaded by path (it is a script, not a module): its zip writer, exclusions and
    SECRET_GLOBS are reused, not copied."""
    global _BR
    if _BR is None:
        cands = [PACKAGE_PARENT / "scripts" / "build_release.py"]
        if os.environ.get("ECONQUEST_HOME"):
            cands.append(Path(os.environ["ECONQUEST_HOME"]) / "scripts" / "build_release.py")
        for p in cands:
            if p.is_file():
                spec = importlib.util.spec_from_file_location("econquest_build_release", p)
                mod = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(mod)
                _BR = mod
                break
        else:
            raise EvidenceError(f"scripts/build_release.py not found (looked in {', '.join(map(str, cands))})")
    return _BR


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def _json(obj) -> bytes:
    return (json.dumps(obj, indent=1, sort_keys=True, ensure_ascii=False, default=str) + "\n").encode()


def check_as_of(text: str) -> str:
    try:
        return dt.date.fromisoformat(str(text)).isoformat()
    except ValueError:
        raise EvidenceError(f"--as-of must be a date YYYY-MM-DD, got {text!r}") from None


class Redactor:
    """Replaces e-mail addresses by `[redacted:recipient-N]`, the same N for the same address (case-insensitive)."""

    def __init__(self):
        self.map: dict[str, str] = {}

    def __call__(self, text: str) -> tuple[str, int]:
        n = 0

        def sub(m):
            nonlocal n
            n += 1
            key = m.group(0).lower()
            if key not in self.map:
                self.map[key] = f"recipient-{len(self.map) + 1}"
            return f"[redacted:{self.map[key]}]"
        return EMAIL_RE.sub(sub, text), n


SECRET_MARK = "[redacted:secret]"
SECRET_ENV_EXTRA = ("ECONQUEST_LSEG_APP_KEY", "ECONQUEST_LSEG_PASSWORD", "ECONQUEST_LSEG_USERNAME", "ECONQUEST_BPIPE_APP_NAME")
URL_SECRET_RE = re.compile(r"(?P<scheme>[A-Za-z][A-Za-z0-9+.-]*://)(?:[^/@\s\"']*@)?(?P<rest>[^?#\s\"']*)(?:[?#][^\s\"']*)?")


def secret_values(*env_files: Path) -> dict[str, str]:
    """value -> name of every credential this build can know about (SEC-C-008): ECONQUEST_* variables whose name looks
    like a secret (actionlog.SECRET_KEY_RE, the vendor keys) in the environment and in <home>/.ops.env. Values shorter
    than 6 characters are ignored (they would match by chance). The Keychain is not read."""
    from .actionlog import SECRET_KEY_RE
    pairs = [(k, v) for k, v in os.environ.items()]
    for f in env_files:
        try:
            for line in Path(f).read_text(encoding="utf-8").splitlines():
                k, sep, v = line.strip().removeprefix("export ").partition("=")
                if sep and not k.startswith("#"):
                    pairs.append((k.strip(), v.strip().strip("'\"")))
        except (OSError, UnicodeDecodeError):
            continue
    return {v: k for k, v in pairs if v and len(v) >= 6 and k.startswith("ECONQUEST_")
            and (SECRET_KEY_RE.search(k) or k in SECRET_ENV_EXTRA)}


def _scrub_urls(text: str) -> str:
    """Drops user:password@ and the query/fragment (signatures, tokens) from every URL; keeps scheme, host and path."""
    return URL_SECRET_RE.sub(lambda m: m.group("scheme") + m.group("rest"), text)


@contextlib.contextmanager
def _no_action_log_override():
    """actionlog.log_path honours $ECONQUEST_ACTION_LOG; checking a copied chain must read the copy."""
    from . import actionlog
    old = os.environ.pop(actionlog.LOG_ENV, None)
    try:
        yield
    finally:
        if old is not None:
            os.environ[actionlog.LOG_ENV] = old


# ------------------------------------------------------------------------------------------------ tests
def parse_test_results(data: bytes) -> dict:
    """Counts from a pytest junit XML file, or from pytest's text summary line ("1637 passed, 5 skipped in 90s")."""
    text = data.decode("utf-8", "replace")
    if text.lstrip().startswith("<"):
        from defusedxml import ElementTree as ET   # an external file: no entity expansion
        try:
            root = ET.fromstring(data)
        except ET.ParseError as e:
            raise EvidenceError(f"test results are not valid junit XML: {e}") from None
        suites = [root] if root.tag == "testsuite" else root.findall("testsuite")
        if not suites:
            raise EvidenceError("junit XML has no <testsuite>")
        n = {k: sum(int(s.get(k, 0) or 0) for s in suites) for k in ("tests", "failures", "errors", "skipped")}
        res = {"format": "junit", "tests": n["tests"], "failed": n["failures"], "errors": n["errors"], "skipped": n["skipped"],
               "passed": n["tests"] - n["failures"] - n["errors"] - n["skipped"]}
    else:
        lines = [ln for ln in text.splitlines() if re.search(r"\d+ (passed|failed)", ln)]
        if not lines:
            raise EvidenceError("test results: neither junit XML nor a pytest summary line ('N passed ...')")
        got = {w: int(c) for c, w in re.findall(r"(\d+) (passed|failed|skipped|errors?|xfailed|xpassed)", lines[-1])}
        res = {"format": "pytest-summary", "passed": got.get("passed", 0), "failed": got.get("failed", 0),
               "errors": got.get("error", 0) + got.get("errors", 0), "skipped": got.get("skipped", 0)}
        res["tests"] = res["passed"] + res["failed"] + res["errors"] + res["skipped"]
    res["status"] = "pass" if res["tests"] and not (res["failed"] or res["errors"]) else "fail"
    return res


def run_pytest(root: Path, junit: Path, log=print) -> int:
    """The full suite with a junit report (tests may monkeypatch this)."""
    log(f"[evidence] running the test suite in {root} (pass --tests-from FILE to skip) ...")
    cmd = [sys.executable, "-m", "pytest", "-q", "-p", "no:cacheprovider", f"--junitxml={junit}", "tests"]
    return subprocess.run(cmd, cwd=str(root), stdout=subprocess.DEVNULL, check=False).returncode  # nosec B603 - fixed argv


def run_replication(data_dir: Path, out: Path, quick: bool, log=print) -> dict:
    """validation.replicate against the frozen release prices (its default); tests may monkeypatch this."""
    from ..validation import replicate as R
    res = R.replicate(data_dir, out, quick=quick, log=lambda *_: None)
    return {"counts": {k: int(v) for k, v in res["counts"].items()}, "stale": list(res.get("stale") or []),
            "prices": "frozen release prices (" + Path(R.FROZEN_PRICES).relative_to(PACKAGE_PARENT).as_posix() + ")"
            if Path(R.FROZEN_PRICES).is_file() else "data/market_history/prices.csv (frozen copy missing)"}


def _replication_counts(csv_bytes: bytes) -> dict:
    rows = list(csv.DictReader(io.StringIO(csv_bytes.decode("utf-8"))))
    counts: dict[str, int] = {}
    for r in rows:
        counts[r.get("status", "")] = counts.get(r.get("status", ""), 0) + 1
    return counts


# ------------------------------------------------------------------------------------------------ chains
def _chain_specs(data_dir: Path, out_dir: Path) -> dict:
    """name -> (list of (archive path, source path)), the source chosen as the live tools read it."""
    from ..presentation import editorial
    from . import actionlog, approvals, distribute
    al = actionlog.log_path(out_dir)
    specs = {
        "approvals": [("chains/data/approvals/log.jsonl", approvals.log_path(data_dir)),
                      ("chains/data/approvals/head.json", approvals.head_path(data_dir))],
        "actions": [("chains/outputs/store/actions.jsonl", al), ("chains/outputs/store/actions.head.json", actionlog.head_path(out_dir))],
        "editorial": [("chains/outputs/editorial/ledger.jsonl", editorial.ledger_path(out_dir))],
        "deliveries": [("chains/outputs/store/deliveries.jsonl", distribute.log_path(out_dir)),
                       ("chains/outputs/store/deliveries.head.json", distribute.head_path(out_dir))],
    }
    pdir = approvals.approvals_dir(data_dir) / "proposals"
    if pdir.is_dir():
        specs["approvals"] += [(f"chains/data/approvals/proposals/{p.name}", p) for p in sorted(pdir.iterdir()) if p.is_file()]
    proot = editorial.published_root(out_dir)
    if proot.is_dir():
        for p in sorted(proot.rglob("*")):
            if p.is_file() and not p.is_symlink():
                specs["editorial"].append((f"chains/outputs/published/{p.relative_to(proot).as_posix()}", p))
    return specs


def _run_verifiers(data_root: Path, out_root: Path) -> dict:
    """The live tools' own checks. Returns name -> {"ok", "rows", "errors"}."""
    from ..presentation import editorial
    from . import actionlog, approvals, distribute
    res = {}
    v = approvals.verify_chain(data_root); res["approvals"] = {"ok": v["ok"], "rows": v["rows"], "errors": v["errors"]}
    with _no_action_log_override():
        v = actionlog.verify(out_root)
    res["actions"] = {"ok": v["ok"], "rows": v["rows"], "errors": v["errors"]}
    v = editorial.verify_published(out_root)
    res["editorial"] = {"ok": v["ok"], "rows": len(editorial.read_ledger(out_root)) if editorial.ledger_path(out_root).exists() else 0,
                        "published_checked": v.get("checked"), "errors": v["problems"]}
    v = distribute.verify(out_root); res["deliveries"] = {"ok": v["ok"], "rows": v["rows"], "errors": v["errors"]}
    return res


def _linkage(log_text: str, head_text: str | None) -> tuple[int, list[str]]:
    """seq 1..n, prev_hash = previous row_hash, head names the last row; row hashes are not recomputed."""
    genesis = "0" * 64
    errors, prev, n = [], genesis, 0
    for i, line in enumerate(log_text.splitlines(), 1):
        if not line.strip():
            continue
        try:
            r = json.loads(line)
        except json.JSONDecodeError:
            errors.append(f"line {i}: not JSON"); prev = None; continue
        n += 1
        if r.get("seq") != n:
            errors.append(f"line {i}: seq {r.get('seq')} where {n} expected")
        if prev is not None and r.get("prev_hash") != prev:
            errors.append(f"line {i}: prev_hash does not match the previous row")
        prev = r.get("row_hash")
    if head_text is not None:
        try:
            head = json.loads(head_text)
        except json.JSONDecodeError:
            head = None; errors.append("head is not JSON")
        if isinstance(head, dict) and (head.get("seq"), head.get("row_hash")) != ((n, prev) if n else (0, genesis)):
            errors.append(f"head names seq {head.get('seq')} but the log ends at seq {n}")
    return n, errors


# ------------------------------------------------------------------------------------------------ runs
def stored_runs(out_dir: Path, as_of: str, label: str | None = None) -> list[dict]:
    """Rows of <out>/store/econquest.sqlite whose as-of date is as_of, oldest first, opened read-only."""
    db = Path(out_dir) / "store" / "econquest.sqlite"
    if not db.is_file():
        return []
    # as_uri() percent-encodes the path: a raw '#' or '?' in it (a folder "Desk #2") would cut the URI there, drop
    # mode=ro and create an empty database outside --out (SEC-C-008)
    con = sqlite3.connect(db.resolve().as_uri() + "?mode=ro", uri=True)
    try:
        rows = con.execute("SELECT run_id, created_at, label, settings, summary FROM runs ORDER BY created_at, run_id").fetchall()
    except sqlite3.Error as e:
        raise EvidenceError(f"cannot read the run store {db.name}: {e}") from None
    finally:
        con.close()
    out = []
    for run_id, created, lab, settings, summary in rows:
        s, st = json.loads(summary or "{}") or {}, json.loads(settings or "null") or {}
        if (s.get("as_of") or st.get("as_of")) == as_of and (label is None or lab == label):
            out.append({"run_id": run_id, "created_at": created, "label": lab, "summary": s})
    return out


def _run_checks(versions: dict, current: dict) -> dict:
    from .. import versioning as V
    files = versions.get("data_files") or {}
    chk = {"code_hash_equals_current": versions.get("code_hash") == current.get("code_hash"),
           "data_hash_equals_current": versions.get("data_hash") == current.get("data_hash")}
    if files:
        chk["data_hash_recomputes"] = V._combine(files) == versions.get("data_hash")
        cur = current.get("data_files") or {}
        chk["inputs_changed_since_run"] = sorted(k for k in set(files) | set(cur) if files.get(k) != cur.get(k))
    if versions.get("run_hash"):
        chk["run_hash_recomputes"] = V.run_hash(versions.get("code_hash", ""), versions.get("data_hash", ""), versions.get("as_of"),
                                                vintage_id=versions.get("vintage_id"), inputs_hash=versions.get("inputs_hash")) == versions["run_hash"]
    return chk


# ------------------------------------------------------------------------------------------------ build
def default_archive(out_dir, as_of: str, demo: bool = False) -> Path:
    return Path(out_dir) / "evidence" / f"evidence-{as_of}{DEMO_SUFFIX if demo else ''}.zip"


def _find_release(root: Path, release_zip) -> tuple[dict[str, bytes], dict]:
    files: dict[str, bytes] = {}
    if release_zip:
        z = Path(release_zip)
        if not z.is_file():
            raise EvidenceError(f"--release-zip {z} not found")
    else:
        if all((root / n).is_file() for n in RELEASE_FILES[:1]):          # an unzipped install carries them at the top
            for n in RELEASE_FILES:
                if (root / n).is_file():
                    files[f"release/{n}"] = (root / n).read_bytes()
            return files, {"source": "install folder", "files": sorted(files)}
        z = root.parent / "econquest-macos.zip"
        if not z.is_file():
            return {}, {"source": None, "note": "no release zip or RELEASE-MANIFEST.txt found; pass --release-zip"}
    with zipfile.ZipFile(z) as zf:
        names = set(zf.namelist())
        for n in RELEASE_FILES:
            hit = next((m for m in sorted(names) if m == n or m.endswith("/" + n) and m.count("/") == 1), None)
            if hit:
                files[f"release/{n}"] = zf.read(hit)
    digest = build_release().sha256_file(z)
    side = z.with_name(z.name + ".sha256")
    info = {"source": "release zip", "zip": z.name, "sha256": digest, "files": sorted(files)}
    if side.is_file():
        info["sidecar_sha256_matches"] = side.read_text().split()[:1] == [digest]
    return files, info


def _room_report(rv: dict) -> dict:
    """The parts of verify_data_room's result kept in our manifest (no absolute path: `room` is left out)."""
    return {"ok": bool(rv.get("ok")), "files": rv.get("files"), "missing": rv.get("missing"), "extra": rv.get("extra"),
            "changed": rv.get("changed"), "unsafe": rv.get("unsafe"), "manifest_hash_ok": rv.get("manifest_hash_ok"),
            "content_sha256_ok": rv.get("content_sha256_ok"), "anchor_failures": rv.get("anchor_failures"),
            "anchor_warnings": rv.get("anchor_warnings"),
            "anchors": [{k: a.get(k) for k in ("kind", "path", "status", "detail")} for a in rv.get("anchors") or []],
            "error": rv.get("error", "")}


def _room_problems(rv: dict) -> list[str]:
    if rv.get("error"):
        return [rv["error"]]
    out = [f"missing {p}" for p in rv.get("missing") or []] + [f"extra {p}" for p in rv.get("extra") or []]
    out += [f"changed {c['path']} ({', '.join(c['differs'])})" for c in rv.get("changed") or []]
    out += [f"unsafe path {p}" for p in rv.get("unsafe") or []]
    out += [] if rv.get("manifest_hash_ok") else ["manifest_sha256 does not recompute"]
    out += [] if rv.get("content_sha256_ok") else ["content_sha256 does not recompute"]
    out += [f"anchor {a['kind']} {a['path']} failed: {a.get('detail', '')}" for a in rv.get("anchors") or [] if a.get("status") == "failed"]
    return out or ["not verified"]


def _verify_room_bytes(files: dict[str, bytes]) -> dict:
    """Team A's verify_data_room on exactly these bytes, written to a fresh temp folder (removed afterwards)."""
    from ..ingestion.dataroom import verify_data_room
    from ..ingestion.dataroom_verify import safe_rel
    tmp = Path(tempfile.mkdtemp(prefix="econquest-evidence-room-"))
    try:
        for rel, b in files.items():
            if not safe_rel(rel):
                return {"ok": False, "error": f"unsafe path {rel!r} in the data room"}
            t = tmp / "room" / rel
            t.parent.mkdir(parents=True, exist_ok=True)
            t.write_bytes(b)
        (tmp / "room").mkdir(exist_ok=True)
        return verify_data_room(tmp / "room")
    except OSError as e:
        return {"ok": False, "error": f"data room cannot be extracted ({type(e).__name__})"}
    finally:
        shutil.rmtree(tmp, ignore_errors=True)


def _data_room(data_dir: Path, out_dir: Path, as_of: str, data_room) -> tuple[dict[str, bytes], str]:
    """Team A's data room for as_of (contract econquest.dataroom/1, HO-20261024-A-C-001), as {path: bytes} read once,
    and how it was found. In order: --data-room PATH; an existing <outputs>/dataroom/<as_of>/ (default_room_dir);
    otherwise build_data_room into a fresh temp folder outside data_dir and <outputs>, read and deleted again, so the
    bundle never writes a room into the real outputs (`python -m econquest.ingestion.dataroom build` keeps one)."""
    from ..ingestion import dataroom as DR

    def read(room: Path) -> dict[str, bytes]:
        if not (room / DR.MANIFEST_NAME).is_file():
            raise EvidenceError(f"{room.name} is not a data room (no {DR.MANIFEST_NAME})")
        files = {}
        for q in sorted(room.rglob("*")):
            if q.is_symlink():
                raise EvidenceError(f"data room {room.name}: {q.relative_to(room).as_posix()} is a symlink")
            if q.is_file():
                files[q.relative_to(room).as_posix()] = q.read_bytes()
        return files

    if data_room:
        p = Path(data_room)
        if not p.is_dir():
            raise EvidenceError(f"--data-room {p} is not a folder (a data room is the folder `dataroom build` writes)")
        return read(p), "--data-room"
    default = DR.default_room_dir(as_of, out_dir)
    if default.is_dir() and any(default.iterdir()):
        return read(default), "existing <outputs>/dataroom/<as_of>"
    tmp = Path(tempfile.mkdtemp(prefix="econquest-evidence-build-room-"))
    try:
        t, d = tmp.resolve(), data_dir.resolve()
        if t == d or d in t.parents or out_dir.resolve() in t.parents:
            raise EvidenceError(f"the temp folder {tmp} is inside --data or --out; set TMPDIR elsewhere")
        try:   # built_utc fixed at the cutoff: the room's bytes, and so the bundle's, depend on the data only
            DR.build_data_room(data_dir, as_of, tmp / "room", now=DR.cutoff_of(as_of)[1])
        except Exception as e:                       # any failure in Team A's build (SEC-C-009 R15) is a clean refusal
            raise EvidenceError(f"building the data room for {as_of} failed ({type(e).__name__}): {e}") from None
        return read(tmp / "room"), "built for this bundle (temporary, not kept)"
    finally:
        for q in [tmp, *tmp.rglob("*")]:
            with contextlib.suppress(OSError):
                q.chmod(0o755 if q.is_dir() else 0o644)
        shutil.rmtree(tmp, ignore_errors=True)


def build(as_of: str, data_dir, out_dir, root=None, dest=None, quick: bool = False, tests_from=None, replication_from=None,
          release_zip=None, data_room=None, label: str | None = None, log=print, demo_baseline: bool = False) -> dict:
    """Build the archive. The data room is --data-room, else <out>/dataroom/<as_of>/, else built in a temp folder. Returns {"archive", "sha256", "files", "bytes", "seconds", "manifest"}.
    EQ-C-0123: demo_baseline=True (--demo-baseline) builds on the DEMO licence baseline (ops/demo_baseline.active, never
    Sam's approval): evidence-<as_of>-DEMO/, manifest profile=demo and demo_baseline, README banner. Default unchanged.
    EQ-C-0106 (R44): refused unless data/licences.csv is the approved register (presentation.licences.register_mismatch);
    the build runs with Team A's resolver pointed at that approved version (ops/licence_gov.enforce_approved), so
    require_register and the data-room withholding read only it."""
    from .licence_gov import enforce_approved
    kw = dict(root=root, dest=dest, quick=quick, tests_from=tests_from, replication_from=replication_from,
              release_zip=release_zip, data_room=data_room, label=label, log=log)
    if demo_baseline:
        from .demo_baseline import active
        with active(data_dir, out_dir) as rec, enforce_approved(data_dir):
            return _build(as_of, data_dir, out_dir, demo=rec, **kw)
    with enforce_approved(data_dir):
        return _build(as_of, data_dir, out_dir, **kw)


def _build(as_of: str, data_dir, out_dir, root=None, dest=None, quick: bool = False, tests_from=None,
           replication_from=None, release_zip=None, data_room=None, label: str | None = None, log=print,
           demo: dict | None = None) -> dict:
    t0 = time.perf_counter()
    BR = build_release()
    from .. import __version__
    from .. import versioning as V
    as_of = check_as_of(as_of)
    # HO-20261025-A-C-008 (SEC-A-010 L3): a register that exists but is invalid would make steps 2-3 withhold every
    # file without saying why; refuse the build up front with Team A's text. A missing register builds as before
    # (old rules only); the EQ-C-0097/0099 withholding of restricted files below is unchanged.
    from ..ingestion.licences import RegisterError, require_register
    try:
        require_register()
    except RegisterError as e:
        raise EvidenceError(str(e)) from None
    data_dir, out_dir = Path(data_dir), Path(out_dir)
    # SEC-C-017 M1: the bundle shows <data>/licences.csv (step 8c) but withholds files by Team A's register
    # ($ECONQUEST_LICENCE_REGISTER or the package copy); refuse when the two differ, so a weaker register never
    # decides what the validator receives.
    from ..presentation.licences import register_mismatch
    if demo is not None:                                  # EQ-C-0123: only the DEMO state, opened by build(), is accepted
        from .licence_gov import DEMO_STATE, state
        if state(data_dir)["status"] != DEMO_STATE:
            raise EvidenceError("refusing to build: the DEMO licence baseline is not in effect (EQ-C-0123)")
    if (why := register_mismatch(data_dir, allow_demo=demo is not None)):
        raise EvidenceError(f"refusing to build: {why}")
    root = Path(root) if root else PACKAGE_PARENT
    dest = Path(dest) if dest else default_archive(out_dir, as_of, demo is not None)
    top = f"evidence-{as_of}{DEMO_SUFFIX if demo is not None else ''}"
    entries: dict[str, bytes] = {}
    modes: dict[str, int] = {}
    excluded: list[str] = []
    sections: dict[str, dict] = {}
    redact = Redactor()
    secrets = secret_values(root / ".ops.env", out_dir.parent / ".ops.env")
    secret_bytes = [(v.encode("utf-8"), k) for v, k in sorted(secrets.items(), key=lambda kv: -len(kv[0]))]
    redacted_files: dict[str, int] = {}

    def add(arc: str, data: bytes, origin: str | None = None, redact_text: bool = True) -> None:
        """Every entry passes here (SEC-C-008): a secret-looking name is left out; a file holding the value of a known
        credential is left out (an input file stops the build, as data_hash covers it); e-mail addresses in any text
        file outside inputs/data/ are replaced, and the count is recorded."""
        if BR.is_secret(arc.rsplit("/", 1)[-1]):
            excluded.append(origin or arc); return
        hit = next((k for v, k in secret_bytes if v in data), None)
        if hit:
            if arc.startswith("inputs/"):
                raise EvidenceError(f"{origin or arc} contains the value of ${hit}; remove it before building the evidence bundle")
            excluded.append(f"{origin or arc} (contains the value of ${hit})"); return
        if redact_text and not arc.startswith("inputs/"):
            try:
                text = data.decode("utf-8")
            except UnicodeDecodeError:
                text = None
            if text is not None:
                text, n = redact(text)
                if n:
                    data, redacted_files[arc] = text.encode("utf-8"), n
        entries[arc] = data

    # 1. stored runs
    runs = stored_runs(out_dir, as_of, label)
    if not runs:
        raise EvidenceError(f"no stored run for as_of {as_of}{' label ' + label if label else ''} in {out_dir / 'store'}; "
                            f"run `econquest run --as-of {as_of}` first")
    current = V.stamp(data_dir, as_of)
    index = []
    for r in runs:
        p = out_dir / "store" / "archive" / f"{r['run_id']}.json"
        item = {"run_id": r["run_id"], "label": r["label"], "created_at": r["created_at"], "as_of": as_of}
        versions = r["summary"].get("versions") or {}
        if p.is_file():
            raw = p.read_bytes()
            add(f"runs/{r['run_id']}.json", raw)
            if f"runs/{r['run_id']}.json" in entries:
                item["file"] = f"runs/{r['run_id']}.json"
            else:
                item["archive_problem"] = "archived JSON left out (holds a credential value)"
            try:
                versions = (json.loads(raw).get("provenance") or {}).get("versions") or versions
            except json.JSONDecodeError:
                item["archive_problem"] = "archived JSON does not parse"
        else:
            item["archive_problem"] = "archived JSON missing; only the store row is available"
        item["versions"] = versions
        item["metrics"] = r["summary"].get("metrics") or {}
        item["checks"] = _run_checks(versions, current)
        index.append(item)
    entries["runs/index.json"] = _json({"as_of": as_of, "runs": index})
    sections["runs"] = {"count": len(index), "labels": sorted({i["label"] for i in index}),
                        "code_hashes": sorted({i["versions"].get("code_hash") for i in index if i["versions"].get("code_hash")}),
                        "data_hashes": sorted({i["versions"].get("data_hash") for i in index if i["versions"].get("data_hash")}),
                        "loss_paths": "not included (*_paths.npz; regenerate with econquest run)"}

    # 2. current inputs and stamp; a licence-restricted data file (dataroom.restricted_reason: raw_yahoo.csv, raw
    # theratesapi responses ...) is withheld and listed with its sha256, so data_hash still recomputes (HO-20261025-A-C-002)
    from ..ingestion.dataroom import restricted_reason
    held_inputs: list[dict] = []
    for rel in V.data_files(data_dir):
        body = (data_dir / rel).read_bytes()
        why = restricted_reason(f"data/{rel}", body)
        if why:
            held_inputs.append({"path": f"data/{rel}", "size": len(body), "sha256": sha256_bytes(body), "reason": why})
            continue
        add(f"inputs/data/{rel}", body, origin=f"data/{rel}")
    entries["hashes/current-stamp.json"] = _json(current)
    sections["inputs"] = {"files": len(current.get("data_files") or {}), "data_hash": current.get("data_hash"),
                          "code_hash": current.get("code_hash"), "code_version": __version__, "withheld": held_inputs}

    # 3. docs; a licence-restricted file (dataroom.restricted_reason, e.g. GOOGLEFINANCE-era frozen prices under
    # releases/inputs/<v>/) is withheld and listed with its path, size, sha256 and reason (HO-20261025-A-C-001)
    ndocs = 0
    withheld: list[dict] = []
    for rel in DOC_PATHS:
        p = root / rel
        paths = [p] if p.is_file() else sorted(q for q in p.rglob("*") if q.is_file()) if p.is_dir() else []
        for q in paths:
            r2 = q.relative_to(root).as_posix()
            if q.is_symlink():
                continue
            if BR.excluded(r2, False):
                if BR.is_secret(q.name):
                    excluded.append(r2)
                continue
            body = q.read_bytes()
            why = restricted_reason(r2, body)
            if why:
                withheld.append({"path": r2, "size": len(body), "sha256": sha256_bytes(body), "reason": why})
                continue
            add(r2, body); ndocs += 1
    sections["docs"] = {"files": ndocs, "paths": list(DOC_PATHS), "withheld": withheld}

    # 4. dossier / data room manifest
    dossier = root / DOSSIER
    dfiles = [{"path": q.relative_to(root).as_posix(), "sha256": sha256_bytes(q.read_bytes()), "size": q.stat().st_size}
              for q in sorted(dossier.rglob("*")) if q.is_file() and not BR.excluded(q.relative_to(root).as_posix(), False)] \
        if dossier.is_dir() else []
    reg = dossier / "findings-register.csv"
    findings = {}
    if reg.is_file():
        for row in csv.DictReader(io.StringIO(reg.read_text(encoding="utf-8"))):
            st = re.sub(r"\s*\(?\d{4}-\d{2}-\d{2}.*$", "", (row.get("status") or "").strip()) or "unknown"   # "Resolved 2026-10-23"
            findings[st] = findings.get(st, 0) + 1
    # Team A's room is copied byte for byte: no address redaction (Team A redacts at source, EQ-A-0044, and a
    # rewrite would make its verify.py report the file changed). A secret-looking name or a credential value in it
    # stops the build instead, since it cannot be masked (SEC-C-008 R6, EQ-C-0069).
    from ..ingestion.dataroom_verify import SCHEMA as ROOM_SCHEMA
    room_files, room_how = _data_room(data_dir, out_dir, as_of, data_room)
    for rel, b in room_files.items():
        if BR.is_secret(rel.rsplit("/", 1)[-1]):
            raise EvidenceError(f"data room file {rel} has a secret-looking name; it is copied unchanged, so rebuild the room without it")
        hit = next((k for v, k in secret_bytes if v in b), None)
        if hit:
            raise EvidenceError(f"data room file {rel} contains the value of ${hit}; it is copied unchanged, so remove it at "
                                "source and rebuild the room")
    rv = _verify_room_bytes(room_files)                 # exactly the bytes that are packed
    if not rv.get("ok"):
        raise EvidenceError(f"the data room ({room_how}) fails Team A's verify: " + "; ".join(_room_problems(rv)[:10]))
    try:
        rman = json.loads(room_files["MANIFEST.json"])
    except (KeyError, json.JSONDecodeError):
        raise EvidenceError("the data room's MANIFEST.json does not parse") from None
    if rman.get("schema") != ROOM_SCHEMA:
        raise EvidenceError(f"the data room's schema is {rman.get('schema')!r}, not {ROOM_SCHEMA}")
    if str(rman.get("as_of")) != as_of:
        raise EvidenceError(f"the data room is for as_of {rman.get('as_of')!r}, not {as_of}")
    addresses = {}
    for rel, b in room_files.items():
        entries[f"dataroom/team-a/{rel}"] = b
        try:
            n = len(EMAIL_RE.findall(b.decode("utf-8")))
        except UnicodeDecodeError:
            n = 0
        if n:
            addresses[rel] = n
    room_info = {"found": True, "contract": ROOM_SCHEMA, "path": "dataroom/team-a/", "source": room_how,
                 "as_of": rman.get("as_of"), "cutoff_utc": rman.get("cutoff_utc"),
                 "manifest_sha256": rman.get("manifest_sha256"), "content_sha256": rman.get("content_sha256"),
                 "totals": rman.get("totals"), "verify_at_build": _room_report(rv),
                 "copied_unchanged": True, "addresses_seen_not_redacted": addresses,
                 "note": "Team A's validator data room (EQ-A-0041): per-as-of export of vintages, provenance, review "
                         "ledger, approvals and hashes, copied byte for byte; check it with `python -I verify.py` inside it"}
    entries["dataroom/dossier-manifest.json"] = _json({"dossier": DOSSIER, "files": dfiles, "findings_by_status": findings,
                                                       "team_a_data_room": room_info})
    sections["dataroom"] = {"dossier_files": len(dfiles), "findings_by_status": findings, "team_a_data_room": room_info["found"]}
    data_room_manifest = {k: room_info[k] for k in ("contract", "path", "source", "as_of", "cutoff_utc", "manifest_sha256",
                                                    "content_sha256", "totals", "addresses_seen_not_redacted")}
    data_room_manifest["verify"] = {k: room_info["verify_at_build"][k] for k in ("ok", "files", "manifest_hash_ok", "content_sha256_ok",
                                                                                "anchor_failures", "anchor_warnings", "anchors")}

    # 5. release manifest
    rfiles, rinfo = _find_release(root, release_zip)
    for k, v in rfiles.items():
        add(k, v)
    if rinfo.get("source"):
        entries["release/release.json"] = _json(rinfo)
    sections["release"] = rinfo

    # 6. hash chains (build-time verification on the live files, then redacted copies)
    built_verify = _run_verifiers(data_dir, out_dir)
    chains = {}
    for name, files in _chain_specs(data_dir, out_dir).items():
        nred, present = 0, []
        for arc, src in files:
            src = Path(src)
            if not src.is_file():
                continue
            raw = src.read_bytes()
            if src.suffix in (".jsonl", ".json") or arc.endswith((".jsonl", ".json")):
                for v, _k in secret_bytes:             # a credential in an old row (written before masking): masked here
                    if v in raw:
                        nred += raw.count(v); raw = raw.replace(v, SECRET_MARK.encode())
                text, n = redact(raw.decode("utf-8"))
                if n:
                    raw, nred = text.encode("utf-8"), nred + n
            add(arc, raw, redact_text=False)
            if arc in entries:
                present.append(arc)
            if arc.startswith("chains/outputs/published/"):        # read-only published copies stay read-only
                modes[arc] = 0o100444 if _read_only(src) else 0o100644
        chains[name] = dict(built_verify[name], files=len(present), redacted=nred, offline_check="linkage" if nred else "full")
    proot = editorial_root(out_dir)
    if proot.is_dir():
        for d in sorted(q for q in proot.rglob("*") if q.is_dir() and not q.is_symlink()):
            modes[f"chains/outputs/published/{d.relative_to(proot).as_posix()}/"] = 0o40555 if _read_only(d) else 0o40755
    dist = data_dir / "distribution.json"
    if dist.is_file():
        try:
            cfg = json.loads(dist.read_text(encoding="utf-8"))
            subs = cfg.get("subscribers") if isinstance(cfg.get("subscribers"), dict) else {}
            cfg["subscribers"] = {k: [redact(str(a))[0] for a in (v or [])] for k, v in sorted(subs.items())}
            # every other key too (reply-to, cc lists, a signed archive_base_url): addresses and URL credentials out (SEC-C-008)
            text = redact(_scrub_urls(_json(cfg).decode("utf-8")))[0]
            for v, _k in secret_bytes:
                text = text.replace(v.decode("utf-8"), SECRET_MARK)
            entries["chains/distribution.redacted.json"] = text.encode("utf-8")
        except (json.JSONDecodeError, AttributeError):
            excluded.append("data/distribution.json (unreadable)")
    entries["chains/verify.json"] = _json(chains)
    sections["chains"] = {k: {"ok": v["ok"], "rows": v["rows"], "offline_check": v["offline_check"]} for k, v in chains.items()}

    # 7. tests
    if tests_from:
        tf = Path(tests_from)
        if not tf.is_file():
            raise EvidenceError(f"--tests-from {tf} not found")
        tbytes = tf.read_bytes()
        tsum = parse_test_results(tbytes)
        tsum["source"] = f"--tests-from {tf.name}"
    else:
        with tempfile.TemporaryDirectory() as td:
            junit = Path(td) / "junit.xml"
            if not (root / "tests").is_dir():
                raise EvidenceError(f"no tests/ under {root}; pass --tests-from FILE")
            code = run_pytest(root, junit, log=log)
            if not junit.is_file():
                raise EvidenceError(f"pytest wrote no junit report (exit {code})")
            tbytes = junit.read_bytes()
        tsum = parse_test_results(tbytes)
        tsum["source"] = "pytest run during the build"; tsum["exit_code"] = code
    tname = "tests/junit.xml" if tsum["format"] == "junit" else "tests/pytest-summary.txt"
    add(tname, tbytes)
    if tname in entries:
        tsum["file"] = tname
    entries["tests/summary.json"] = _json(tsum)
    sections["tests"] = {k: tsum[k] for k in ("status", "tests", "passed", "failed", "errors", "skipped", "source")}

    # 8. replication
    if replication_from:
        rd = Path(replication_from)
        if not (rd / "replication.csv").is_file():
            raise EvidenceError(f"--replication-from {rd}: replication.csv not found")
        rcsv = (rd / "replication.csv").read_bytes()
        rmd = (rd / "replication.md").read_bytes() if (rd / "replication.md").is_file() else b""
        rsum = {"counts": _replication_counts(rcsv), "source": f"--replication-from {rd.name}"}
    else:
        log(f"[evidence] replication ({'quick' if quick else 'full'} mode) ...")
        with tempfile.TemporaryDirectory() as td:
            rsum = run_replication(data_dir, Path(td), quick, log=log)
            rcsv = (Path(td) / "replication.csv").read_bytes()
            rmd = (Path(td) / "replication.md").read_bytes() if (Path(td) / "replication.md").is_file() else b""
        rsum["source"] = f"validation.replicate ({'quick' if quick else 'full'} mode) during the build"
    rsum["quick"] = bool(quick) if not replication_from else None
    rsum["status"] = "fail" if rsum["counts"].get("FAIL") else "pass"
    add("replication/replication.csv", rcsv)
    if rmd:
        add("replication/replication.md", rmd)
    entries["replication/summary.json"] = _json(rsum)
    sections["replication"] = {k: rsum.get(k) for k in ("status", "counts", "source", "prices", "quick")}

    # 8b. target-state scorecard (EQ-C-0061), scored from the same evidence; stamped with as_of so rebuilds stay identical
    try:
        import datetime as _dt
        from ..presentation.targets import target_scorecard, to_markdown
        import pandas as pd
        rtab = pd.read_csv(io.BytesIO(rcsv), dtype=str, keep_default_na=False) if rcsv else None   # the replication bundled here
        tdf = target_scorecard(data_dir, out_dir, root=root, tests_file=tests_from, replication_table=rtab)
        add("targets/targets.csv", tdf.to_csv(index=False).encode())
        add("targets/targets.md", to_markdown(tdf, now=_dt.datetime.fromisoformat(as_of)).encode())
        sections["targets"] = {"rows": len(tdf), "met": {str(k): int(v) for k, v in tdf["met"].value_counts().items()}}
    except Exception as e:                                  # the scorecard is a summary; its failure must not stop the bundle
        sections["targets"] = {"error": f"{type(e).__name__}"}      # the message may carry an absolute path

    # 8c. licences (EQ-C-0093): attribution per source used and the internal-only content of the bundled inputs, from
    # Team A's licence register (presentation/licences.py). The validator works under NDA (EXC-003), so internal-only
    # content is labelled here, not withheld; a missing register is stated, never hidden.
    from ..presentation import licences as LIC
    lev = LIC.safe_evaluate(data_dir)
    lsum = LIC.summary(lev)
    add("licences/licences.json", _json(lsum))
    add("licences/ATTRIBUTION.md", ("# Sources and licences\n\n" + "\n".join(f"- {x}" for x in lev["attribution"])
                                    + "\n\n## Internal-only content (not for client output)\n\n"
                                    + ("\n".join(f"- {x}" for x in LIC.internal_labels(lev)) or "- none") + "\n").encode())
    sections["licences"] = {"register_ok": lev["register"]["ok"], "register_problem": lev["register"]["problem"],
                            "sources": len(lev["attribution"]), "internal_only_cells": len(lev["internal_only"]),
                            "client_ok": lev["client_ok"]}
    demo_info = None
    if demo is not None:                                  # EQ-C-0123: the DEMO record ships with the bundle
        demo_info = {k: demo[k] for k in ("profile", "approver", "not_sams_approval", "banner", "register_sha256",
                                          "created_utc", "ticket")}
        add("licences/DEMO-BASELINE.json", _json(demo_info))

    # 9. README and manifest
    redactions = {"data/distribution.json": "shipped as chains/distribution.redacted.json, addresses and URL credentials replaced",
                  "e-mail addresses in chain files": f"{len(redact.map)} distinct address(es) replaced by [redacted:recipient-N]",
                  "e-mail addresses in other files": {k: v for k, v in sorted(redacted_files.items())},
                  "data room": "dataroom/team-a/ copied unchanged (Team A redacts at source, EQ-A-0044); addresses seen there are "
                               "counted in data_room.addresses_seen_not_redacted; a credential value in it stops the build",
                  "credential values": f"{len(secrets)} known value(s) checked; any found in a chain replaced by {SECRET_MARK}, "
                                       "any other file holding one left out"}
    entries[README] = readme(as_of, sections, chains, redactions, excluded, demo=demo_info).encode()
    files = [{"path": k, "sha256": sha256_bytes(v), "size": len(v)} for k, v in sorted(entries.items())]
    manifest = {"format": FORMAT, "ticket": "EQ-C-0060", "as_of": as_of, "top": top, "code_version": __version__,
                "built_with": {"code_hash": current.get("code_hash"), "python": current.get("python")},
                "sections": sections, "chains": chains, "data_room": data_room_manifest, "redactions": redactions, "excluded_secret_like": sorted(set(excluded)),
                "files": files}
    if demo_info is not None:
        manifest.update(profile=demo_info["profile"], demo_baseline=demo_info)
    mbytes = _json(manifest)

    # 10. zip (build_release's writer: sorted, fixed timestamp and modes)
    names: dict[str, object] = {f"{top}/{k}": v for k, v in entries.items()}
    names[f"{top}/{MANIFEST}"] = mbytes
    dirs = {f"{top}/"}
    for n in list(names):
        parts = n.split("/")[:-1]
        for i in range(1, len(parts) + 1):
            dirs.add("/".join(parts[:i]) + "/")
    zmodes = {f"{top}/{k}": v for k, v in modes.items()}

    def mode(name, src):
        return zmodes.get(name) or BR.default_mode(name, src)
    dest.parent.mkdir(parents=True, exist_ok=True)
    digest = BR.write_zip(dest, [(d, None) for d in dirs] + list(names.items()), mode=mode)
    dest.with_name(dest.name + ".sha256").write_text(f"{digest}  {dest.name}\n")
    return {"archive": str(dest), "sha256": digest, "files": len(files) + 1, "bytes": dest.stat().st_size,
            "seconds": time.perf_counter() - t0, "manifest": manifest}


def _read_only(p: Path) -> bool:
    return not stat.S_IMODE(p.stat().st_mode) & 0o222


def editorial_root(out_dir) -> Path:
    from ..presentation import editorial
    return editorial.published_root(out_dir)


def readme(as_of: str, sections: dict, chains: dict, redactions: dict, excluded: list[str], demo: dict | None = None) -> str:
    t, r = sections["tests"], sections["replication"]
    ch = "\n".join(f"| {k} | {'ok' if v['ok'] else 'BROKEN'} | {v['rows']} | {v['offline_check']} |" for k, v in sorted(chains.items()))
    banner = "" if demo is None else (
        f"# {demo['banner']}\n\nThis bundle was built on the DEMO licence profile (EQ-C-0123): data/licences.csv "
        f"(sha256 {demo['register_sha256']}) was approved by the fixed label '{demo['approver']}', not by Sam, outside "
        "the change chain. It proves the mechanics only and is not evidence of an approved licence register.\n\n")
    return banner + f"""# EconQuest evidence bundle, as of {as_of}

Built by `econquest evidence --as-of {as_of}` (ticket EQ-C-0060) for an independent validator (roadmap 4.5,
policy principle 4). Everything here is a copy; nothing in it is needed to run econquest.

## Check it first

1. Compare the archive's SHA-256 with the one sent to you separately (the `.sha256` file beside the zip, or the
   release note): `shasum -a 256 evidence-{as_of}.zip`.
2. `econquest evidence verify evidence-{as_of}.zip` (offline): rechecks the sha256 of every file against
   `EVIDENCE-MANIFEST.json`, refuses extra or missing files and secret-looking names, recomputes the hash chains,
   the run hashes and the data hash, and recounts the test results. Exit 0 means all of that holds.
3. Team A's data room is in `dataroom/team-a/` exactly as Team A built it; step 2 already verified it with the
   installed econquest code. Run its own `python3 -I dataroom/team-a/verify.py` (standard library only, exit 0 =
   verified) only after step 2 passed with no warning about verify.py, since that script ships inside the archive;
   its manifest_sha256 is in `EVIDENCE-MANIFEST.json` (`data_room`).
4. Without econquest: every file's sha256 is in `EVIDENCE-MANIFEST.json` (`files`), e.g.
   `python3 -c "import json,hashlib,sys;m=json.load(open('EVIDENCE-MANIFEST.json'));print(all(hashlib.sha256(open(f['path'],'rb').read()).hexdigest()==f['sha256'] for f in m['files']))"`
   from inside the unzipped folder.

The manifest proves the files are the ones that were packed; the hash chains prove the logs are internally
consistent. Someone who rewrites a file, its log and the manifest together can forge both, which is why the zip's
SHA-256 has to reach you by another route.

## What is inside

| Folder | Content |
|---|---|
| `docs/` | governance and validation documents, incl. the validation dossier ({sections['dataroom']['dossier_files']} files) |
| `runs/` | {sections['runs']['count']} stored run(s) for {as_of} ({', '.join(sections['runs']['labels'])}); `index.json` has each run's versions stamp and hash rechecks |
| `inputs/data/` | the {sections['inputs']['files']} data files data_hash covers today (data_hash {sections['inputs']['data_hash']}) |
| `hashes/` | `current-stamp.json`: code_hash {sections['inputs']['code_hash']}, data_hash, per-file hashes at build time |
| `tests/` | test results: {t['tests']} tests, {t['passed']} passed, {t['failed']} failed, {t['errors']} errors, {t['skipped']} skipped ({t['source']}) |
| `replication/` | independent replication: {', '.join(f'{k} {v}' for k, v in sorted((r['counts'] or {}).items()))} ({r['source']}) |
| `chains/` | approval, action, editorial and delivery hash chains, `verify.json` (build-time result) |
| `dataroom/` | `dossier-manifest.json`; `team-a/`: Team A's data room for {as_of}, copied unchanged (verify.py inside) |
| `release/` | release manifest and hashes: {sections['release'].get('zip') or sections['release'].get('source') or 'none found'} |

## Hash chains at build time

| Chain | Result | Rows | Offline check |
|---|---|---|---|
{ch}

"full" means `verify` recomputes every row hash with the same code `econquest change verify`, `log verify`,
`editorial verify` and `distribute verify` use. "linkage" means addresses were redacted from that chain, so
offline `verify` checks seq, prev_hash and head, and the row-hash recomputation is the build-time result above.

## Licences

- Licences (EQ-C-0093): `licences/ATTRIBUTION.md` has the attribution line of every source used and labels the
  {sections.get('licences', {}).get('internal_only_cells', 0)} internal-only cell(s) (IMF under NDA, EXC-003; not for onward or client use);
  licence register {'loaded' if sections.get('licences', {}).get('register_ok') else 'MISSING or invalid: ' + str(sections.get('licences', {}).get('register_problem'))}.

## Left out on purpose

- Credentials of any kind (release build exclusions: .env, *.token, *.pem, *.key, client_secret*.json ...)
  {('; skipped here: ' + ', '.join(sorted(set(excluded)))) if excluded else ''}
- Licence-restricted documents: {(', '.join(w['path'] for w in sections['docs'].get('withheld') or []) or 'none')}; each is listed with its sha256 and reason under `sections.docs.withheld` in the manifest.
- Licence-restricted data files: {(', '.join(w['path'] for w in sections['inputs'].get('withheld') or []) or 'none')}; listed with their sha256 under `sections.inputs.withheld`, so `verify` still recomputes data_hash.
- Subscriber e-mail addresses: {redactions['data/distribution.json']}; {redactions['e-mail addresses in chain files']}.
- Monte Carlo loss paths (`*_paths.npz`) and the SQLite store: rerun `econquest run --as-of {as_of}` to regenerate.

## How to use it

Start with `docs/validation/dossier/README.md` and its findings register; rerun the replication
(`python -m econquest.validation.replicate --data data`) and the tests (`python -m pytest -q tests`) on the release
code, and compare with `replication/` and `tests/`. Raise findings as GOV- issues.
"""


# ------------------------------------------------------------------------------------------------ verify
def _safe_name(n: str, top: str) -> bool:
    return n.startswith(top + "/") and not n.startswith("/") and ".." not in n.split("/") and "\\" not in n


def _verify_packed_room(room: dict[str, bytes], dm, bundle_version=None) -> dict:
    """verify_data_room on the room as packed, plus: the manifest names it, and its manifest_sha256 / content_sha256
    are the ones recorded at build time (a room swapped for another valid room fails here).
    The room's verify.py is never run here (verify_data_room is this installation's dataroom_verify). The README tells
    a validator to run it, though, so it is compared with this installation's copy (SEC-C-009): a forger who re-signs
    the room and our manifest could otherwise ship code there. A difference is an error when the bundle was built
    with this econquest version (the build copies that file byte for byte), else a warning."""
    from .. import __version__
    from ..ingestion.dataroom import VERIFY_SOURCE
    if not isinstance(dm, dict):
        return {"ok": False, "errors": ["dataroom/team-a/ is in the archive but the manifest's data_room omits it"]}
    if not room:
        return {"ok": False, "errors": ["the manifest names a data room but dataroom/team-a/ is empty"]}
    rv = _verify_room_bytes(room)
    errs = [] if rv.get("ok") else _room_problems(rv)
    warnings = []
    try:
        rman = json.loads(room.get("MANIFEST.json", b""))
    except ValueError:                                  # JSONDecodeError, or bytes that are not UTF-8
        rman = {}
    if not isinstance(rman, dict):
        rman = {}
    for k in ("manifest_sha256", "content_sha256"):
        if rman.get(k) != dm.get(k):
            errs.append(f"{k} {rman.get(k)} is not the {dm.get(k)} recorded at build time")
    if not (dm.get("verify") or {}).get("ok"):
        errs.append("not verified at build time")
    script = room.get("verify.py")
    same = script is not None and script == VERIFY_SOURCE.read_bytes()
    if script is not None and not same:
        msg = ("verify.py is not this installation's econquest/ingestion/dataroom_verify.py: do not run it; "
               "rely on `econquest evidence verify`")
        (errs if bundle_version == __version__ else warnings).append(
            msg if bundle_version == __version__ else f"{msg} (bundle built with econquest {bundle_version}, this is {__version__})")
    return {"ok": not errs, "errors": errs, "warnings": warnings, "manifest_sha256": rman.get("manifest_sha256"),
            "files": rv.get("files"), "anchor_failures": rv.get("anchor_failures"), "anchor_warnings": rv.get("anchor_warnings"),
            "verify_py_matches_installed": same if script is not None else None}


def _check_profile(res: dict, man: dict, top: str, blobs: dict, errors: list[str]) -> None:
    """res["profile"] ("standard" | "demo"), and for a DEMO bundle res["demo"] and res["warnings"]. A bundle whose DEMO
    marks disagree (a manifest without profile=demo but a -DEMO folder, the DEMO record or the README banner, or a
    demo_baseline whose approver is not the fixed DEMO label) is an error: the marking cannot be stripped quietly."""
    from .demo_baseline import APPROVER, BANNER, PROFILE
    prof = man.get("profile") or "standard"
    res["profile"] = prof
    marks = {"folder": top.endswith(DEMO_SUFFIX), "record": "licences/DEMO-BASELINE.json" in blobs,
             "readme": blobs.get(README, b"").startswith(f"# {BANNER}".encode()),
             "licences": BANNER.encode() in blobs.get("licences/licences.json", b"")}
    if prof == PROFILE:
        dm = man.get("demo_baseline") if isinstance(man.get("demo_baseline"), dict) else {}
        res["demo"] = {"approver": dm.get("approver"), "register_sha256": dm.get("register_sha256"),
                       "created_utc": dm.get("created_utc"), "not_sams_approval": True}
        res.setdefault("warnings", []).append(f"{BANNER}: built on the DEMO licence profile (EQ-C-0123); not "
                                              "evidence of an approved licence register")
        if dm.get("approver") != APPROVER or dm.get("not_sams_approval") is not True:
            errors.append(f"profile demo: demo_baseline must name the approver {APPROVER!r} and not_sams_approval")
        missing = [k for k, v in marks.items() if not v]
        if missing:
            errors.append(f"profile demo: DEMO marks missing ({', '.join(missing)})")
    elif prof != "standard":
        errors.append(f"unknown profile {prof!r}")
    elif any(marks.values()):
        errors.append("DEMO marks present (" + ", ".join(k for k, v in marks.items() if v) + ") but the manifest has no "
                      "profile=demo: the DEMO marking was stripped")


def verify(archive) -> dict:
    """Offline recheck of an evidence archive. Returns {"ok", "integrity_ok", "chains_ok", "files_checked", "errors",
    "chains", "data_room", "as_of", "sha256"}."""
    BR = build_release()
    from .. import versioning as V
    archive = Path(archive)
    errors: list[str] = []
    res = {"archive": str(archive), "sha256": BR.sha256_file(archive) if archive.is_file() else None, "errors": errors, "chains": {}}
    try:
        zf = zipfile.ZipFile(archive)
    except (OSError, zipfile.BadZipFile) as e:
        errors.append(f"not a readable zip: {e}")
        return dict(res, ok=False, integrity_ok=False, chains_ok=False, files_checked=0)
    with zf:
        infos = zf.infolist()
        tops = {i.filename.split("/", 1)[0] for i in infos}
        if len(tops) != 1:
            errors.append(f"expected one top folder, found {sorted(tops)}")
            return dict(res, ok=False, integrity_ok=False, chains_ok=False, files_checked=0)
        top = tops.pop()
        seen: set[str] = set()
        for i in infos:
            if i.filename in seen:                     # readers differ on which copy they show (SEC-C-008)
                errors.append(f"duplicate entry name {i.filename!r}")
            seen.add(i.filename)
            if not _safe_name(i.filename, top) and i.filename != top + "/":
                errors.append(f"unsafe entry name {i.filename!r}")
            if stat.S_ISLNK(i.external_attr >> 16):
                errors.append(f"symlink entry {i.filename}")
        try:
            man = json.loads(zf.read(f"{top}/{MANIFEST}"))
        except (KeyError, json.JSONDecodeError) as e:
            errors.append(f"{MANIFEST} missing or not JSON: {e}")
            return dict(res, ok=False, integrity_ok=False, chains_ok=False, files_checked=0)
        res["as_of"] = man.get("as_of")
        listed = {f["path"]: f for f in man.get("files", [])}
        actual = {i.filename[len(top) + 1:]: i for i in infos if not i.is_dir() and i.filename != f"{top}/{MANIFEST}"}
        for p in sorted(set(actual) - set(listed)):
            errors.append(f"{p}: in the archive but not in the manifest")
        for p in sorted(set(listed) - set(actual)):
            errors.append(f"{p}: in the manifest but missing from the archive")
        blobs = {}
        for p in sorted(set(actual) & set(listed)):
            b = zf.read(actual[p]); blobs[p] = b
            if sha256_bytes(b) != listed[p]["sha256"] or len(b) != listed[p]["size"]:
                errors.append(f"{p}: sha256 differs from the manifest (tampered)")
            if BR.is_secret(p.rsplit("/", 1)[-1]):
                errors.append(f"{p}: secret-looking file name")
        side = archive.with_name(archive.name + ".sha256")
        if side.is_file() and side.read_text().split()[:1] != [res["sha256"]]:
            errors.append(f"{side.name} does not match the archive's SHA-256")
        integrity_ok = not errors
        _check_profile(res, man, top, blobs, errors)       # EQ-C-0123: DEMO bundles are reported, never passed as real

        # derived checks on the (hash-checked) contents
        def j(p):
            try:
                return json.loads(blobs[p]) if p in blobs else None
            except json.JSONDecodeError:
                errors.append(f"{p}: not JSON"); return None
        idx = j("runs/index.json") or {}
        for r in idx.get("runs", []):
            v = r.get("versions") or {}
            if r.get("file"):
                rv = ((j(r["file"]) or {}).get("provenance") or {}).get("versions")
                if rv is not None and rv != v:
                    errors.append(f"runs/index.json: {r['run_id']} versions differ from {r['file']}")
            if v.get("data_files") and V._combine(v["data_files"]) != v.get("data_hash"):
                errors.append(f"run {r['run_id']}: data_hash does not recompute from its per-file hashes")
            if v.get("run_hash") and V.run_hash(v.get("code_hash", ""), v.get("data_hash", ""), v.get("as_of"), vintage_id=v.get("vintage_id"),
                                                inputs_hash=v.get("inputs_hash")) != v["run_hash"]:
                errors.append(f"run {r['run_id']}: run_hash does not recompute")
        cur = j("hashes/current-stamp.json") or {}
        def _data_h(rel, b):                                  # as data_hash counts it (EQ-C-0130: canonical review.csv view)
            view = V.CANONICAL_VIEWS.get(rel)
            body = view(b) if view else None
            return sha256_bytes(b if body is None else body)[:16]
        got = {p[len("inputs/data/"):]: _data_h(p[len("inputs/data/"):], b) for p, b in blobs.items() if p.startswith("inputs/data/")}
        for w in ((man.get("sections") or {}).get("inputs") or {}).get("withheld") or []:   # listed, not shipped
            rel = str(w.get("path", ""))[len("data/"):]
            if rel in got:
                errors.append(f"inputs/data/{rel}: listed as withheld but shipped")
            got[rel] = str(w.get("sha256", ""))[:16]
        if cur.get("data_files") is not None and got != cur["data_files"]:
            errors.append("inputs/data/ does not match hashes/current-stamp.json data_files")
        if cur.get("data_files") and V._combine(cur["data_files"]) != cur.get("data_hash"):
            errors.append("hashes/current-stamp.json: data_hash does not recompute")
        ts = j("tests/summary.json")
        if ts and ts.get("file") in blobs:
            again = parse_test_results(blobs[ts["file"]])
            if any(again[k] != ts.get(k) for k in ("tests", "passed", "failed", "errors", "skipped")):
                errors.append("tests/summary.json counts differ from the stored test results")
        rs = j("replication/summary.json")
        if rs and "replication/replication.csv" in blobs and _replication_counts(blobs["replication/replication.csv"]) != rs.get("counts"):
            errors.append("replication/summary.json counts differ from replication.csv")

        # Team A's data room: its own verify on the extracted dataroom/team-a/, and its hashes against our manifest
        room = {p[len("dataroom/team-a/"):]: b for p, b in blobs.items() if p.startswith("dataroom/team-a/")}
        dm = man.get("data_room")
        if dm is not None or room:
            res["data_room"] = _verify_packed_room(room, dm, man.get("code_version"))
            errors.extend(f"data room: {e}" for e in res["data_room"]["errors"])

        # chains: extract chains/ and run the live tools' verifiers (full) or the linkage check (redacted chains)
        built = man.get("chains") or {}
        tmp = Path(tempfile.mkdtemp(prefix="econquest-evidence-"))
        try:
            ro_dirs = []
            for i in sorted(infos, key=lambda x: x.filename):
                rel = i.filename[len(top) + 1:]
                if not rel.startswith("chains/") or not _safe_name(i.filename, top):
                    continue
                target = tmp / rel
                m = stat.S_IMODE(i.external_attr >> 16) & 0o777              # no setuid/setgid/sticky from the archive
                try:
                    if i.is_dir():
                        target.mkdir(parents=True, exist_ok=True)
                        if m and not m & 0o222:
                            ro_dirs.append((target, m))
                    else:
                        target.parent.mkdir(parents=True, exist_ok=True)
                        target.write_bytes(zf.read(i))
                        if m:
                            target.chmod(m)
                except OSError as e:                   # a file and a folder of the same name, a duplicate: a refusal
                    errors.append(f"{rel}: cannot be extracted ({type(e).__name__})")
            for d, m in sorted(ro_dirs, key=lambda x: -len(x[0].parts)):
                d.chmod(m)
            full = _run_verifiers(tmp / "chains" / "data", tmp / "chains" / "outputs")
            texts = {"approvals": ("chains/data/approvals/log.jsonl", "chains/data/approvals/head.json"),
                     "actions": ("chains/outputs/store/actions.jsonl", "chains/outputs/store/actions.head.json"),
                     "editorial": ("chains/outputs/editorial/ledger.jsonl", None),
                     "deliveries": ("chains/outputs/store/deliveries.jsonl", "chains/outputs/store/deliveries.head.json")}
            # every chain in the archive is checked, declared or not, and a chain is checked by linkage only when its
            # log really carries a redaction: the manifest alone cannot downgrade a full recomputation (SEC-C-008)
            declared = dict(built)
            for name, (lp, _hp) in texts.items():
                if lp in blobs and name not in declared:
                    declared[name] = {"rows": None, "undeclared": True}
            for name, b in sorted(declared.items()):
                lp = texts.get(name, (None, None))[0]
                redacted = b"[redacted:" in blobs.get(lp, b"")
                if b.get("offline_check") == "linkage" and redacted:
                    lp, hp = texts.get(name, (None, None))
                    n, errs = _linkage(blobs.get(lp, b"").decode("utf-8"), blobs[hp].decode("utf-8") if hp in blobs else None)
                    out = {"ok": not errs and bool(b.get("ok")), "rows": n, "errors": errs + ([] if b.get("ok") else ["broken at build time"]),
                           "check": "linkage (redacted; row hashes recomputed at build time: " + ("ok" if b.get("ok") else "BROKEN") + ")"}
                else:
                    f = full.get(name) or {"ok": False, "rows": 0, "errors": ["no verifier"]}
                    out = {"ok": f["ok"], "rows": f["rows"], "errors": f["errors"], "check": "full"}
                    if b.get("undeclared"):
                        out["ok"] = False; out["errors"] = out["errors"] + ["chain files present but the manifest's chains omit it"]
                    elif f["rows"] != b.get("rows"):
                        out["ok"] = False; out["errors"] = out["errors"] + [f"{f['rows']} rows, the manifest says {b.get('rows')}"]
                res["chains"][name] = out
        finally:
            for p in [tmp, *tmp.rglob("*")]:
                with contextlib.suppress(OSError):
                    p.chmod(0o755 if p.is_dir() else 0o644)
            shutil.rmtree(tmp, ignore_errors=True)
    chains_ok = all(c["ok"] for c in res["chains"].values())
    for k, c in res["chains"].items():
        if not c["ok"]:
            errors.extend(f"chain {k}: {e}" for e in (c["errors"] or ["failed"]))
    res.update(ok=not errors, integrity_ok=integrity_ok, chains_ok=chains_ok, files_checked=len(set(actual) & set(listed)))
    return res


# ------------------------------------------------------------------------------------------------ CLI
def add_arguments(ap) -> None:
    ap.add_argument("action", nargs="?", choices=["build", "verify"], default="build",
                    help="build (default) an archive for --as-of, or verify ARCHIVE")
    ap.add_argument("archive", nargs="?", help="verify: the evidence zip to recheck")
    ap.add_argument("--as-of", dest="evidence_as_of", help="as-of date YYYY-MM-DD of the stored runs to package")
    ap.add_argument("--out", dest="evidence_out", help="folder for the archive (default <outputs>/evidence) or a .zip path")
    ap.add_argument("--quick", action="store_true", help="quick replication (20,000 requested paths, loose tolerance)")
    ap.add_argument("--tests-from", help="use this pytest junit XML (or text summary) instead of running the full suite")
    ap.add_argument("--replication-from", help="use this folder's replication.csv/.md instead of rerunning the replication")
    ap.add_argument("--release-zip", help="release zip whose RELEASE-MANIFEST.txt to include (default: ../econquest-macos.zip if present)")
    ap.add_argument("--data-room", help="Team A's data room folder for the date (default: <outputs>/dataroom/<as_of> if built, "
                    "else one is built in a temp folder for this bundle and not kept)")
    ap.add_argument("--label", help="only stored runs with this label (default: every run for the date)")
    ap.add_argument("--root", help="econquest folder holding docs/, tests/ and scripts/ (default: this checkout)")
    ap.add_argument("--demo-baseline", action="store_true",
                    help="DEMO only (EQ-C-0123): build on a DEMO licence baseline while Sam has not approved the first "
                         "one; the bundle is marked DEMO (profile=demo) and is never Sam's approval")


def run_from_args(args, default_home=None) -> int:
    try:
        if args.action == "verify":
            if not args.archive:
                raise EvidenceError("evidence verify needs the archive path")
            r = verify(args.archive)
            print(f"{r['archive']}: {'ok' if r['ok'] else 'FAILED'}  ({r.get('files_checked', 0)} files, sha256 {r.get('sha256')})")
            if r.get("profile") == "demo":                 # EQ-C-0123
                print(f"  profile demo: {_demo_banner()} (approver {(r.get('demo') or {}).get('approver')})")
            for k, c in sorted(r["chains"].items()):
                print(f"  chain {k}: {'ok' if c['ok'] else 'BROKEN'} ({c['rows']} rows, {c['check']})")
            if r.get("data_room"):
                d = r["data_room"]
                print(f"  data room: {'verified' if d['ok'] else 'FAILED'} (Team A verify, {d.get('files')} files, "
                      f"manifest_sha256 {d.get('manifest_sha256')})")
                for w in d.get("warnings") or []:
                    print("  warning: data room: " + w)
            for e in r["errors"]:
                print("  " + e)
            return 0 if r["ok"] else 1
        if args.archive:
            raise EvidenceError(f"unexpected argument {args.archive!r} (did you mean `evidence verify {args.archive}`?)")
        if not args.evidence_as_of:
            raise EvidenceError("evidence needs --as-of YYYY-MM-DD")
        as_of = check_as_of(args.evidence_as_of)
        dest = None
        if args.evidence_out:
            o = Path(args.evidence_out)
            dest = o if o.suffix == ".zip" else o / f"evidence-{as_of}.zip"
        root = Path(args.root) if args.root else (Path(default_home) if default_home and (Path(default_home) / "docs").is_dir() else PACKAGE_PARENT)
        demo = bool(getattr(args, "demo_baseline", False))
        if demo and dest is not None and not dest.stem.endswith(DEMO_SUFFIX):
            dest = dest.with_name(dest.stem + DEMO_SUFFIX + dest.suffix)
        r = build(as_of, args.data, args.out, root=root, dest=dest, quick=args.quick, tests_from=args.tests_from,
                  replication_from=args.replication_from, release_zip=args.release_zip, data_room=args.data_room, label=args.label,
                  demo_baseline=demo)
        if demo:
            print(f"{_demo_banner()}: evidence built on the DEMO licence profile (approver 'DEMO (not Sam)', EQ-C-0123)")
        s = r["manifest"]["sections"]
        print(f"{r['sha256']}  {r['archive']}  ({r['files']} files, {r['bytes'] / 1e6:.1f} MB, {r['seconds']:.0f} s)")
        print(f"  runs {s['runs']['count']}; tests {s['tests']['status']} ({s['tests']['passed']} passed, {s['tests']['failed']} failed, "
              f"{s['tests']['skipped']} skipped); replication {s['replication']['status']} "
              f"({', '.join(f'{k} {v}' for k, v in sorted(s['replication']['counts'].items()))}); chains "
              + ", ".join(f"{k} {'ok' if v['ok'] else 'BROKEN'}" for k, v in sorted(s["chains"].items())))
        return 0
    except EvidenceError as e:
        print(f"[evidence] error: {e}", file=sys.stderr)
        return 2
    except RuntimeError as e:                              # EQ-C-0123: demo_baseline.DemoBaselineError
        from .demo_baseline import DemoBaselineError
        if not isinstance(e, DemoBaselineError):
            raise
        print(f"[evidence] error: {e}", file=sys.stderr)
        return 2


def _demo_banner() -> str:
    from .licence_gov import DEMO_BANNER
    return DEMO_BANNER
