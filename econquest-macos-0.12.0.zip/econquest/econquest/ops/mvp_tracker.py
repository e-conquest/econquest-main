"""MVP tracker (EQ-C-0124): the latest `econquest demo` result, row by row (M1-M10), in two places.

  team/mvp-checklist.md   a status block between BEGIN and END below. Only that block is ever replaced; the rest of the
                          file is the program lead's and is kept byte for byte. With no markers yet, the block is
                          appended at the end. A file with a broken marker pair is left alone (the reason is returned).
  GUI readiness tab       the "MVP" card, from mvp_status(out_dir), read through presentation.readiness (read only).

MVP+ (EQ-C-0136, EQ-C-0148, EQ-C-0158, EQ-C-0166, EQ-C-0174): demo.json "plus_rows" (M11 morning, M12 what-if, M13 research v2,
M14 client sandbox, M15 vendor simulation, M16 calendar rehearsal, M17 text index, M18 events view, M19 depth views and
heatmap, M20 research archive, M21 real-data day rehearsal, M22 backtest explainer, M23 validator replication kit, M24
research QA, M25 assistant answer, M26 assistant refusals, M27 assistant draft to the archive) are shown under their own "MVP+" heading inside the block and as summarise()["plus"] on the card, labelled
with the row range the run has (M11-M13 for a run before EQ-C-0148). "MVP reached" stays M1-M10 only. A partial run
(`econquest demo --only ...`, demo.json "only" set, EQ-C-0166) is never taken as the latest demo.

`econquest demo` calls update_checklist() after a real run only (ops/demo.py: at least one step really ran through
Demo.sh, not a stub, and not --no-tracker). Nothing here runs a step or touches the network.
"""
from __future__ import annotations

import json
import os
import tempfile
from pathlib import Path

TICKET = "EQ-C-0124"
BEGIN = "<!-- mvp-status:begin -->"
END = "<!-- mvp-status:end -->"
CHECKLIST = Path("team") / "mvp-checklist.md"
REASON_MAX = 300


def _cell(v, limit: int = 0) -> str:
    s = " ".join(str(v if v is not None else "").split())
    s = s.replace("<!--", "<! --").replace("-->", "-- >").replace("|", "\\|")
    return s[: limit - 3] + "..." if limit and len(s) > limit else s


def _rel(p: Path, root: Path | None) -> str:
    p = Path(p)
    if root is not None:
        try:
            return p.resolve().relative_to(Path(root).resolve()).as_posix()
        except ValueError:
            pass
    return p.as_posix()


def root_relative(text: str, root) -> str:
    """EQ-C-0168: absolute paths under the repo root in free text (a demo summary "... -> /abs/outputs/demo/<UTC>/demo.md",
    a reason) are shown relative to it, so the readiness report and the checklist never carry this machine's path."""
    text = str(text or "")
    if root is None:
        return text
    for r in {str(Path(root)), str(Path(root).resolve())}:
        if r not in ("", "/", "."):
            text = text.replace(r.rstrip("/") + "/", "")
    return text


def evidence_path(evidence: str, demo_dir: str) -> str:
    """A row's evidence as a path a reader can open: demo-relative names (evidence/..., logs/...) are put under the
    run folder; anything else (a --tests-from path, a note) is kept as written."""
    ev = str(evidence or "")
    parts = []
    for e in ev.split("; "):
        parts.append(f"{demo_dir}/{e}" if demo_dir and (e.startswith("evidence/") or e.startswith("logs/")) else e)
    return "; ".join(parts)


def summarise(doc: dict, demo_json: str, root=None) -> dict:
    """The tracker payload of one demo.json: {"run_utc", "mode", "summary", "path", "counts", "rows"[{id, title,
    status, reason, evidence, run_utc}], "all_pass"}. With root, paths under it in the text are made relative."""
    demo_dir = str(Path(demo_json).parent.as_posix())
    rows = []
    for r in doc.get("rows") or []:
        rows.append({"id": str(r.get("id", "")), "title": str(r.get("title", "")), "status": str(r.get("status", "")),
                     "reason": root_relative(" ".join(str(r.get("reason", "")).split()), root),
                     "evidence": root_relative(evidence_path(r.get("evidence", ""), demo_dir), root),
                     "run_utc": str(doc.get("started_utc", ""))})
    counts = {s: sum(r["status"] == s for r in rows) for s in ("pass", "pending", "fail")}
    return {"run_utc": str(doc.get("started_utc", "")), "mode": str(doc.get("mode", "")), "network": str(doc.get("network", "")),
            "summary": root_relative(doc.get("summary", ""), root), "path": Path(demo_json).as_posix(), "counts": counts,
            "rows": rows, "all_pass": bool(rows) and counts["pass"] == len(rows), "plus": summarise_plus(doc, demo_dir, root)}


def summarise_plus(doc: dict, demo_dir: str, root=None) -> dict:
    """The MVP+ rows (M11-M27, EQ-C-0136/C-0148/C-0158/C-0166/C-0174) of one demo.json: {"rows", "counts", "all_pass", "summary", "range",
    "ticket"}; no rows when the run predates them. Never folded into the MVP counts."""
    from .demo import plus_range
    rows = [{"id": str(r.get("id", "")), "title": str(r.get("title", "")), "status": str(r.get("status", "")),
             "reason": root_relative(" ".join(str(r.get("reason", "")).split()), root),
             "evidence": root_relative(evidence_path(r.get("evidence", ""), demo_dir), root),
             "run_utc": str(doc.get("started_utc", ""))} for r in doc.get("plus_rows") or [] if isinstance(r, dict)]
    counts = {s: sum(r["status"] == s for r in rows) for s in ("pass", "pending", "fail")}
    return {"rows": rows, "counts": counts, "all_pass": bool(rows) and counts["pass"] == len(rows),
            "summary": root_relative(doc.get("plus_summary", ""), root), "range": plus_range(rows),
            "ticket": str(doc.get("plus_ticket") or "EQ-C-0136")}


def render_block(info: dict) -> str:
    """The marked block (BEGIN ... END), plain Markdown, no trailing newline."""
    c = info["counts"]
    L = [BEGIN, "", f"### Latest `econquest demo` result (written by the demo, {TICKET}; do not edit inside this block)", "",
         f"Run {_cell(info['run_utc'])}, mode {_cell(info['mode'])}: {c['pass']}/{len(info['rows'])} pass, "
         f"{c['pending']} pending, {c['fail']} fail. Results: `{_cell(info['path'])}`.",
         "MVP reached." if info["all_pass"] else "MVP not reached yet: nothing for Sam to do.", "",
         "| # | Status | Reason | Evidence | Run (UTC) |", "|---|---|---|---|---|"]
    L += [f"| {_cell(r['id'])} | {_cell(r['status'])} | {_cell(r['reason'], REASON_MAX)} | {_cell(r['evidence'], 200)} | {_cell(r['run_utc'])} |"
          for r in info["rows"]]
    plus = info.get("plus") or {}
    if plus.get("rows"):                                 # EQ-C-0136: its own heading, after the MVP rows
        pc = plus["counts"]
        L += ["", "#### MVP+", "",
              f"Beyond the MVP ({_cell(plus.get('range') or 'M11-M13')}, {_cell(plus.get('ticket') or 'EQ-C-0136')}): {pc['pass']}/{len(plus['rows'])} pass, {pc['pending']} pending, "
              f"{pc['fail']} fail. Not part of \"MVP reached\".", "",
              "| # | Status | Reason | Evidence | Run (UTC) |", "|---|---|---|---|---|"]
        L += [f"| {_cell(r['id'])} | {_cell(r['status'])} | {_cell(r['reason'], REASON_MAX)} | {_cell(r['evidence'], 200)} | {_cell(r['run_utc'])} |"
              for r in plus["rows"]]
    L += ["", END]
    return "\n".join(L)


def splice(text: str, block: str) -> tuple[str | None, str]:
    """(new text, how) with only the marked block replaced, or (None, why) when the markers are broken."""
    nb, ne = text.count(BEGIN), text.count(END)
    if nb == 0 and ne == 0:
        sep = "" if text.endswith("\n\n") else ("\n" if text.endswith("\n") else "\n\n")
        return text + sep + block + "\n", "appended"
    if nb != 1 or ne != 1 or text.index(BEGIN) > text.index(END):
        return None, f"markers broken ({nb} begin, {ne} end): left unchanged"
    i, j = text.index(BEGIN), text.index(END) + len(END)
    return text[:i] + block + text[j:], "replaced"


def update_checklist(checklist: Path, doc: dict, demo_json: Path, root: Path | None = None) -> tuple[bool, str]:
    """Write the latest result into the checklist's marked block. (written, message). Never creates the file."""
    checklist = Path(checklist)
    if not checklist.is_file():
        return False, f"tracker: {checklist} not found, not written"
    text = checklist.read_text(encoding="utf-8")
    new, how = splice(text, render_block(summarise(doc, _rel(demo_json, root), root)))
    if new is None:
        return False, f"tracker: {checklist.name} {how}"
    if new == text:
        return False, f"tracker: {checklist.name} already current"
    fd, tmp = tempfile.mkstemp(prefix=".mvp-checklist.", dir=str(checklist.parent))
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(new)
        os.replace(tmp, checklist)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise
    return True, f"tracker: {checklist.name} status block {how}"


def latest_demo(out_dir) -> tuple[dict, Path] | tuple[None, None]:
    """The newest demo.json under <out>/demo/<UTC>/ from a real run (real_run not false); (None, None) if none."""
    base = Path(out_dir) / "demo"
    if not base.is_dir():
        return None, None
    for d in sorted((p for p in base.iterdir() if p.is_dir()), key=lambda p: p.name, reverse=True):
        f = d / "demo.json"
        try:
            doc = json.loads(f.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if isinstance(doc, dict) and doc.get("rows") and doc.get("real_run") is not False and not doc.get("only"):
            return doc, f
    return None, None


def mvp_status(out_dir, root=None) -> dict:
    """GUI payload for the readiness tab's MVP card: summarise() plus "status" ok|none and a "message"."""
    doc, f = latest_demo(out_dir)
    if doc is None:
        return {"status": "none", "rows": [], "command": "econquest demo --fast",
                "message": "No econquest demo run yet: the MVP card fills in after the first run."}
    base = root if root is not None else Path(out_dir).resolve().parent
    info = summarise(doc, _rel(f, base), base)
    c = info["counts"]
    info |= {"status": "ok", "command": "econquest demo",
             "message": f"MVP {'reached' if info['all_pass'] else 'not reached yet'}: {c['pass']}/{len(info['rows'])} pass, "
                        f"{c['pending']} pending, {c['fail']} fail (run {info['run_utc']}, mode {info['mode']})."}
    plus = info["plus"]
    if plus["rows"]:
        pc = plus["counts"]
        plus["message"] = (f"MVP+ ({plus.get('range') or 'M11-M13'}, not part of the MVP): {pc['pass']}/{len(plus['rows'])} pass, {pc['pending']} pending, "
                           f"{pc['fail']} fail.")
    else:
        plus["message"] = "MVP+ rows (M11-M27) appear after the next econquest demo run."
    return info
