"""Weekly operations report (EQ-C-0110): one INTERNAL page on how the week went on Sam's Mac.

    econquest ops-report --week [--as-of YYYY-MM-DD] [--json]
    python -m econquest.ops.ops_report --home <home> --as-of <run date>        (the ops_report job, Mondays 07:30 NY)

The window is the 7 days before the report: ending now, or at the end of --as-of (in the schedule's time zone) when
that date is before today. Sections, each read from files that already exist (a source that cannot be read shows
"unknown" with the error type, never a traceback):

  runs          runs archived in outputs/store (read only): base runs with VaR99 / ES99 / EL in $mm and the move against
                the base run before each; other labels (stress, ...) counted
  jobs          outputs/logs/jobs/history.jsonl: per job ok / failed / skipped runs, and every scheduled slot in the window
                whose deadline has passed: ok, late, failed, skipped or missed (the record job also counts a forecast
                record row, the morning job a base run in the store, as health.py does). Slots before the install
                (outputs/logs/schedule.json installed_at) are not judged
  gate          the review ledger (data/live/review_ledger.csv, Team A): holds and rejects decided, held cells released
                (apply on a gate-held cell), attestations; held cells still waiting (open items)
  alerts        outputs/health.json (open alerts; first seen this week), outputs/alerts.json rows by severity, alerts
                cleared since the previous ops report, incidents opened, closed and still open (ops/incidents.py)
  calendar      the calendar-gated formal tests (ops.calendar_jobs.page_status): "143 of 250 tested days recorded"
  freshness     Team A's freshness SLA (ingestion.freshness.check_freshness) at the report date
  open_items    the operator's open items (ops.open_items.collect): how many kinds are open
  schedule      schedule.check: expected jobs against the plists in ~/Library/LaunchAgents (macOS only)

Writes outputs/reports/ops/ops-week-<as_of>.html, .md and .json (the JSON lets the next report say which alerts
cleared). Every value is escaped (HTML entities in the page, markdown metacharacters in the .md). INTERNAL: no
client output, nothing sent, nothing published. Exit 0, or 1 when the report cannot be written.
"""
from __future__ import annotations

import argparse
import datetime as dt
import html
import json
import os
import re
import sqlite3
import sys
from pathlib import Path

DAYS = 7
REPORT_DIR = Path("reports") / "ops"              # under outputs/
EARLY_MINUTES = 120                               # a run up to 2 h before its slot counts (as health.evidence_since)
METRICS = (("var99_mm", "VaR99"), ("es99_mm", "ES99"), ("expected_loss_mm", "EL"))
HAND_TABLES = {"adjustments", "cds_quotes", "prediction_markets", "fx_manual"}
ROW_LIMIT = 40
INTERNAL = "INTERNAL: operations report for the desk and the team; not for clients or publication."


# ---------------------------------------------------------------- helpers
def _parse(ts) -> dt.datetime | None:
    from .health import _parse as p
    return p(ts)


def _iso(t: dt.datetime | None) -> str:
    return t.astimezone(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ") if t else ""


def _zone(tz: str):
    from zoneinfo import ZoneInfo
    return ZoneInfo(tz)


def _num(v):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    return None if f != f else f


def _unknown(e: BaseException) -> dict:
    return {"status": "unknown", "error": type(e).__name__}


def _read_json(p: Path):
    try:
        return json.loads(p.read_text(encoding="utf-8")) if p.is_file() else None
    except (OSError, ValueError):
        return None


def window(as_of, now: dt.datetime, tz: str, days: int = DAYS) -> tuple[dt.datetime, dt.datetime, str]:
    """(start, end) in UTC and the report date. The end is now, or the end of `as_of` in tz when that day is over."""
    z = _zone(tz)
    today = now.astimezone(z).date()
    day = dt.date.fromisoformat(str(as_of)[:10]) if as_of else today
    end = now if day >= today else dt.datetime.combine(day + dt.timedelta(days=1), dt.time(0, 0), tzinfo=z)
    end = end.astimezone(dt.timezone.utc)
    return end - dt.timedelta(days=days), end, day.isoformat()


def _in(t, start, end) -> bool:
    return t is not None and start <= t < end


# ---------------------------------------------------------------- sections
def runs_section(out_dir: Path, start, end) -> dict:
    db = out_dir / "store" / "econquest.sqlite"
    if not db.is_file():
        return {"status": "none", "base": [], "other": {}, "moves": 0, "note": "no run store (outputs/store) yet"}
    with sqlite3.connect(f"file:{db}?mode=ro", uri=True) as c:          # read only: never create or migrate the store
        rows = c.execute("SELECT run_id, created_at, label, summary FROM runs ORDER BY created_at").fetchall()
    prev, base, other = None, [], {}
    for run_id, created, label, summ in rows:
        t = _parse(created)
        try:
            s = json.loads(summ) if summ else {}
        except ValueError:
            s = {}
        m = (s.get("metrics") or {}) if isinstance(s, dict) else {}
        if label != "base":
            if _in(t, start, end):
                other[str(label)] = other.get(str(label), 0) + 1
            continue
        vals = {k: _num(m.get(k)) for k, _ in METRICS}
        if _in(t, start, end):
            r = {"run_id": run_id, "created_utc": _iso(t), "as_of": str(s.get("as_of") or "")}
            moved = False
            for k, _ in METRICS:
                r[k] = vals[k]
                pv = prev.get(k) if prev else None
                d = None if vals[k] is None or pv is None else vals[k] - pv
                r["d_" + k] = d
                moved = moved or (d is not None and abs(d) > 1e-9)
            r["moved"] = moved
            r["prev_run_id"] = prev.get("run_id") if prev else ""
            base.append(r)
        prev = {**vals, "run_id": run_id}
    return {"status": "ok", "base": base, "other": other, "moves": sum(1 for r in base if r["moved"]),
            "latest": base[-1] if base else None}


def _history(out_dir: Path) -> list[dict]:
    p = out_dir / "logs" / "jobs" / "history.jsonl"
    rows = []
    if p.is_file():
        for line in p.read_text(encoding="utf-8", errors="replace").splitlines():
            try:
                r = json.loads(line)
            except ValueError:
                continue
            if isinstance(r, dict):
                r["_t"] = _parse(r.get("at") or r.get("ended_at"))
                rows.append(r)
    return rows


def _slot_status(name, job, slot, hist, extra_times) -> tuple[str, str]:
    lo, hi = slot - dt.timedelta(minutes=EARLY_MINUTES), slot + dt.timedelta(hours=24)
    deadline = slot + dt.timedelta(minutes=int(job.get("max_minutes", 30)))
    ends = [h for h in hist if h.get("job") == name and h.get("event") in ("end", "skipped") and _in(h["_t"], lo, hi)]
    ok = sorted(h["_t"] for h in ends if h.get("status") == "ok")
    ev = sorted(t for t in extra_times if _in(t, lo, hi))
    first = min(ok[:1] + ev[:1], default=None)
    if first is not None:
        return ("late", f"done {_iso(first)}, after the deadline") if first > deadline else ("ok", f"done {_iso(first)}")
    if any(h.get("event") == "end" for h in ends):
        e = [h for h in ends if h.get("event") == "end"][-1]
        return "failed", f"exit {e.get('exit_code')} at {_iso(e['_t'])}"
    if ends:
        return "skipped", "skipped: the previous run was still going"
    return "missed", "no run recorded for this slot"


def jobs_section(home: Path, data_dir: Path, out_dir: Path, start, end, tz: str) -> dict:
    from . import health, schedule
    sched = _read_json(out_dir / "logs" / "schedule.json")
    installed = isinstance(sched, dict) and sched.get("status") == "installed"
    jobs = (sched.get("jobs") if installed else None) or schedule.load_config(home)["jobs"]
    grace = int((sched or {}).get("grace_minutes", 15)) if installed else 15
    holidays = {dt.date.fromisoformat(h) for h in ((sched or {}).get("holidays") or []) if isinstance(h, str)}
    inst_at = _parse((sched or {}).get("installed_at")) if installed else None
    hist = _history(out_dir)
    z = _zone(tz)
    extra = {"forecast_record": health._record_times(data_dir), "store_run": health._store_times(out_dir)}
    per, slots = {}, []
    for name, job in jobs.items():
        if not isinstance(job, dict):
            continue
        ends = [h for h in hist if h.get("job") == name and h.get("event") in ("end", "skipped") and _in(h["_t"], start, end)]
        per[name] = {"runs": len(ends), "ok": sum(h.get("status") == "ok" for h in ends),
                     "failed": sum(h.get("event") == "end" and h.get("status") != "ok" for h in ends),
                     "skipped": sum(h.get("event") == "skipped" for h in ends), "missed": 0, "late": 0}
        if not installed or job.get("interval_minutes") or "hour" not in job:
            continue
        d, last = start.astimezone(z).date(), end.astimezone(z).date()
        while d <= last:
            run_day = (d.day == int(job["day"])) if job.get("day") is not None else \
                health.is_run_day(d, job.get("weekdays", schedule.ALL_DAYS), holidays)
            slot = dt.datetime.combine(d, dt.time(int(job["hour"]), int(job["minute"])), tzinfo=z).astimezone(dt.timezone.utc)
            due = slot + dt.timedelta(minutes=int(job.get("max_minutes", 30)) + grace)
            d += dt.timedelta(days=1)
            if not run_day or slot < start or due > end or (inst_at and slot < inst_at):
                continue
            st, detail = _slot_status(name, job, slot, hist, extra.get(job.get("evidence"), []))
            slots.append({"job": name, "slot": f"{slot.astimezone(z):%a %Y-%m-%d %H:%M} {tz}", "status": st, "detail": detail})
            if st in ("missed", "late"):
                per[name][st] += 1
    bad = [s for s in slots if s["status"] != "ok"]
    return {"status": "ok" if installed else "not_installed", "jobs": per, "slots": slots, "problems": bad,
            "missed": sum(s["status"] == "missed" for s in slots), "failed": sum(s["status"] == "failed" for s in slots),
            "note": "" if installed else "schedule not installed (no outputs/logs/schedule.json): slots not judged"}


def gate_section(data_dir: Path, start, end) -> dict:
    from ..ingestion.ledger import read_ledger
    led = read_ledger(data_dir)
    holds, releases, attest = [], [], 0
    for r in led.to_dict("records"):
        if not _in(_parse(r.get("ts_utc")), start, end):
            continue
        dec, gs = str(r.get("decision") or ""), str(r.get("gate_status") or "")
        row = {"ts_utc": r.get("ts_utc"), "table": r.get("table"), "key": r.get("key"), "country": r.get("country"),
               "decision": dec, "author": r.get("author"), "approver": r.get("approver")}
        if dec in ("hold", "reject"):
            holds.append(row)
        elif dec == "apply" and gs == "hold":
            releases.append(row)
        elif dec == "apply" and r.get("table") in HAND_TABLES:
            attest += 1
    return {"status": "ok", "holds": holds, "releases": releases, "attestations": attest}


def _alert_key(a: dict) -> str:
    return a.get("key") or "|".join(str(a.get(k) or "") for k in ("kind", "scope", "country"))


def alerts_section(out_dir: Path, start, end, prev_report: dict | None) -> dict:
    from . import incidents
    h = _read_json(out_dir / "health.json") or {}
    h_alerts = [a for a in (h.get("alerts") or []) if isinstance(a, dict)]
    first = h.get("alerted") or {}
    new = [a for a in h_alerts if _in(_parse(first.get(a.get("key"))), start, end)]
    aj = _read_json(out_dir / "alerts.json") or {}
    aj_rows = [a for a in (aj.get("alerts") or []) if isinstance(a, dict)] if isinstance(aj, dict) else []
    by_sev = {s: sum(1 for a in aj_rows + h_alerts if a.get("severity") == s) for s in ("critical", "warning", "info")}
    current = {_alert_key(a): {"severity": a.get("severity"), "kind": a.get("kind"), "message": a.get("message")}
               for a in aj_rows + h_alerts}
    prev = (prev_report or {}).get("alerts", {}).get("current") or {}
    cleared = [{"key": k, **(v if isinstance(v, dict) else {})} for k, v in prev.items() if k not in current]
    inc = incidents.incidents(out_dir)
    opened = [i for i in inc.values() if _in(_parse(i.get("opened_utc")), start, end)]
    closed = [i for i in inc.values() if i.get("closed") and _in(_parse((i.get("entries") or [{}])[-1].get("ts_utc")), start, end)]
    still = [i for i in inc.values() if not i.get("closed")]
    slim = lambda i: {"id": i["id"], "severity": i.get("severity"), "opened_utc": i.get("opened_utc"),  # noqa: E731
                      "last_phase": i.get("last_phase"), "summary": ((i.get("entries") or [{}])[0]).get("summary")}
    return {"status": "ok", "open": len(current), "by_severity": by_sev, "current": current,
            "new_health": [{"severity": a.get("severity"), "kind": a.get("kind"), "message": a.get("message")} for a in new],
            "cleared": cleared, "previous_report": (prev_report or {}).get("as_of"),
            "incidents": {"opened": [slim(i) for i in opened], "closed": [slim(i) for i in closed],
                          "open": [slim(i) for i in still]}}


def calendar_section(data_dir: Path, out_dir: Path, as_of: str) -> dict:
    from .calendar_jobs import page_status
    p = page_status(data_dir, out_dir, as_of)
    rows = [{"test": r["test"], "status": r["status_text"], "progress": r["progress_text"], "formal_date": r["formal_date"],
             "days_left": r["days_left"]} for r in p.get("rows") or []]
    var = next((r for r in p.get("rows") or [] if r["test"] == "var_backtest_250d"), None)
    head = (f"{var['progress']} of {var['required']} days" if var and var.get("progress") is not None else "progress unknown")
    return {"status": p.get("status"), "message": p.get("message"), "headline": head, "rows": rows,
            "last_job": p.get("last_job") or {}}


def freshness_section(data_dir: Path, as_of: str) -> dict:
    from ..ingestion import freshness as F
    res = F.check_freshness(data_dir, as_of=as_of)
    s = F.summary(res, F.breaches(res))
    return {"status": "breach" if s["failing"] else "ok", "ref_date": s["ref_date"], "cells_checked": s["cells_checked"],
            "by_status": s["by_status"], "failing": s["failing"], "failing_by_series": s["failing_by_series"][:ROW_LIMIT]}


def open_items_section(data_dir: Path, out_dir: Path, now) -> dict:
    from . import open_items
    rep = open_items.collect(data_dir, now=now, out_dir=out_dir)
    items = [{"kind": i["kind"], "title": i["title"], "count": i["count"], "summary": i["summary"]}
             for i in rep["items"] if i["status"] == "open"]
    review = next((i for i in rep["items"] if i["kind"] == "review"), {})
    return {"status": "open" if rep["open"] else "clear", "open": rep["open"], "unknown": rep["unknown"], "items": items,
            "held_cells_pending": review.get("count")}


def schedule_section(home: Path, launch_agents=None) -> dict:
    from . import schedule
    la = Path(launch_agents) if launch_agents else schedule.launch_agents_dir()
    if la is None:
        return {"status": "not_checked", "note": "not macOS: no LaunchAgents folder to compare (run on the Mac)"}
    r = schedule.check(home, launch_agents=la, log=lambda *_: None)
    rows = [{"job": n, "state": v["state"], "detail": v["detail"]} for n, v in r["jobs"].items()]
    rows += [{"job": u["label"], "state": u["state"], "detail": u["detail"]} for u in r["unexpected"]]
    return {"status": r["status"], "counts": r["counts"], "rows": rows,
            "launch_agents": r["launch_agents"].replace(str(Path.home()), "~")}


# ---------------------------------------------------------------- build
def _previous(dest: Path, as_of: str) -> dict | None:
    best = None
    for p in sorted(dest.glob("ops-week-*.json")) if dest.is_dir() else []:
        a = p.stem[len("ops-week-"):]
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", a) and a < as_of:
            best = p
    return _read_json(best) if best else None


def build(home, data_dir=None, out_dir=None, as_of=None, now: dt.datetime | None = None, launch_agents=None) -> dict:
    """Every section of the weekly report. Reads only."""
    from . import schedule
    home = Path(home)
    data_dir = Path(data_dir) if data_dir else home / "data"
    out_dir = Path(out_dir) if out_dir else home / "outputs"
    now = (now or dt.datetime.now(dt.timezone.utc)).astimezone(dt.timezone.utc)
    sched = _read_json(out_dir / "logs" / "schedule.json") or {}
    tz = (sched.get("tz") if isinstance(sched, dict) else None) or schedule.load_config(home).get("tz", schedule.DEFAULT_TZ)
    start, end, day = window(as_of, now, tz)
    prev = _previous(out_dir / REPORT_DIR, day)
    rep = {"title": "EconQuest weekly operations report", "classification": "INTERNAL", "as_of": day, "tz": tz,
           "window_start_utc": _iso(start), "window_end_utc": _iso(end), "generated_utc": _iso(now)}
    sections = {"runs": lambda: runs_section(out_dir, start, end),
                "jobs": lambda: jobs_section(home, data_dir, out_dir, start, end, tz),
                "gate": lambda: gate_section(data_dir, start, end),
                "alerts": lambda: alerts_section(out_dir, start, end, prev),
                "calendar": lambda: calendar_section(data_dir, out_dir, day),
                "freshness": lambda: freshness_section(data_dir, day),
                "open_items": lambda: open_items_section(data_dir, out_dir, now),
                "schedule": lambda: schedule_section(home, launch_agents)}
    for k, fn in sections.items():
        try:
            rep[k] = fn()
        except (Exception, SystemExit) as e:             # noqa: BLE001 - one bad source never hides the rest
            rep[k] = _unknown(e)
    rep["headline"] = headline(rep)
    return rep


def _mm(v) -> str:
    return "n/a" if v is None else f"{v:,.2f}"


def _dmm(v) -> str:
    return "" if v is None else f"{v:+,.2f}"


def headline(rep: dict) -> list[str]:
    """The decision lines at the top: risk numbers first, then what needs action."""
    L = []
    r = rep.get("runs") or {}
    lt = r.get("latest")
    if lt:
        L.append(f"Latest base run {lt['run_id']}: VaR99 ${_mm(lt['var99_mm'])}mm ({_dmm(lt['d_var99_mm']) or 'no prior'}), "
                 f"ES99 ${_mm(lt['es99_mm'])}mm ({_dmm(lt['d_es99_mm']) or 'no prior'}), "
                 f"EL ${_mm(lt['expected_loss_mm'])}mm ({_dmm(lt['d_expected_loss_mm']) or 'no prior'}); "
                 f"{len(r['base'])} base runs this week, {r['moves']} with a move")
    elif r.get("status") in ("ok", "none"):
        L.append("No base run archived this week")
    j = rep.get("jobs") or {}
    if j.get("status") == "ok":
        L.append(f"Scheduled slots: {len(j['slots'])} due, {j['missed']} missed, {j['failed']} failed")
    elif j.get("status") == "not_installed":
        L.append("Scheduled jobs: schedule not installed")
    g = rep.get("gate") or {}
    if g.get("status") == "ok":
        L.append(f"Gate: {len(g['holds'])} holds/rejects, {len(g['releases'])} releases this week")
    a = rep.get("alerts") or {}
    if a.get("status") == "ok":
        L.append(f"Alerts open: {a['open']} ({a['by_severity']['critical']} critical); incidents opened "
                 f"{len(a['incidents']['opened'])}, closed {len(a['incidents']['closed'])}, open {len(a['incidents']['open'])}")
    c = rep.get("calendar") or {}
    if c.get("headline"):
        L.append(f"Calendar tests: 250-day VaR backtest {c['headline']}")
    f = rep.get("freshness") or {}
    if f.get("status") in ("ok", "breach"):
        L.append(f"Freshness SLA: {f['failing']} breaching cells of {f['cells_checked']} checked")
    o = rep.get("open_items") or {}
    if "open" in o:
        L.append(f"Open items: {o['open']} kinds open")
    s = rep.get("schedule") or {}
    if s.get("counts"):
        k = s["counts"]
        L.append(f"Installed jobs: {k['ok']} ok, {k['missing']} missing, {k['stale']} stale")
    for k in ("runs", "jobs", "gate", "alerts", "calendar", "freshness", "open_items", "schedule"):
        if (rep.get(k) or {}).get("status") == "unknown":
            L.append(f"{k}: could not be read ({rep[k].get('error')})")
    return L


# ---------------------------------------------------------------- tables (shared by both renderers)
def tables(rep: dict) -> list[tuple[str, str, list[str], list[list]]]:
    """(section title, note, headers, rows) in the order shown."""
    out = []
    r = rep.get("runs") or {}
    out.append(("Runs (base numbers in $mm; move = change against the base run before)",
                r.get("note") or ("other runs: " + ", ".join(f"{k} {v}" for k, v in sorted(r.get("other", {}).items()))
                                  if r.get("other") else ""),
                ["run_id", "created (UTC)", "as of", "VaR99 $mm", "move", "ES99 $mm", "move", "EL $mm", "move"],
                [[b["run_id"], b["created_utc"], b["as_of"], _mm(b["var99_mm"]), _dmm(b["d_var99_mm"]), _mm(b["es99_mm"]),
                  _dmm(b["d_es99_mm"]), _mm(b["expected_loss_mm"]), _dmm(b["d_expected_loss_mm"])]
                 for b in r.get("base") or []]))
    j = rep.get("jobs") or {}
    out.append(("Job outcomes", j.get("note", ""), ["job", "runs", "ok", "failed", "skipped", "missed slots", "late slots"],
                [[n, v["runs"], v["ok"], v["failed"], v["skipped"], v["missed"], v["late"]] for n, v in (j.get("jobs") or {}).items()]))
    out.append(("Slots not done on time", "" if j.get("problems") else "none",
                ["job", "slot", "status", "detail"],
                [[s["job"], s["slot"], s["status"], s["detail"]] for s in (j.get("problems") or [])[:ROW_LIMIT]]))
    g = rep.get("gate") or {}
    gl = [[x["ts_utc"], "hold" if x["decision"] == "hold" else x["decision"], x["table"], x["key"], x["country"], x["author"]]
          for x in g.get("holds") or []]
    gl += [[x["ts_utc"], "release", x["table"], x["key"], x["country"], f"{x['author']} / {x['approver']}"]
           for x in g.get("releases") or []]
    out.append(("Gate holds and releases", f"attestations this week: {g.get('attestations', 0)}; held cells still waiting: "
                f"{(rep.get('open_items') or {}).get('held_cells_pending', 'n/a')}",
                ["when (UTC)", "action", "table", "key", "country", "by"], sorted(gl)[:ROW_LIMIT]))
    a = rep.get("alerts") or {}
    al = [["new", x["severity"], x["kind"], x["message"]] for x in a.get("new_health") or []]
    al += [["cleared", x.get("severity"), x.get("kind"), x.get("message")] for x in a.get("cleared") or []]
    al += [["open", v["severity"], v["kind"], v["message"]] for v in (a.get("current") or {}).values()]
    out.append(("Alerts", f"cleared is against the previous report ({a.get('previous_report') or 'none'})",
                ["state", "severity", "kind", "message"], al[:ROW_LIMIT]))
    inc = a.get("incidents") or {}
    il = [[st, i["id"], i["severity"], i["opened_utc"], i["last_phase"], i["summary"]]
          for st in ("opened", "closed", "open") for i in inc.get(st) or []]
    out.append(("Incidents", "", ["state", "id", "severity", "opened (UTC)", "last phase", "summary"], il[:ROW_LIMIT]))
    c = rep.get("calendar") or {}
    out.append(("Calendar-gated formal tests", c.get("message", ""), ["test", "status", "progress", "formal date", "days left"],
                [[x["test"], x["status"], x["progress"], x["formal_date"], x["days_left"]] for x in c.get("rows") or []]))
    f = rep.get("freshness") or {}
    out.append(("Data freshness (Team A SLA)",
                f"reference {f.get('ref_date', '')}; by status: " + ", ".join(f"{k} {v}" for k, v in (f.get("by_status") or {}).items()),
                ["table", "series", "severity", "cells breaching"],
                [[x.get("table"), x.get("key"), x.get("severity"), x.get("cells")] for x in f.get("failing_by_series") or []]))
    o = rep.get("open_items") or {}
    out.append(("Open items", f"{o.get('open', 'n/a')} kinds open, {o.get('unknown', 'n/a')} unreadable (econquest open-items)",
                ["kind", "count", "summary"], [[x["title"], x["count"], x["summary"]] for x in o.get("items") or []]))
    s = rep.get("schedule") or {}
    out.append(("Installed jobs (econquest schedule check)", s.get("note") or f"folder {s.get('launch_agents', '')}",
                ["job", "state", "detail"], [[x["job"], x["state"], x["detail"]] for x in s.get("rows") or []]))
    for k in ("runs", "jobs", "gate", "alerts", "calendar", "freshness", "open_items", "schedule"):
        if (rep.get(k) or {}).get("status") == "unknown":
            out.append((f"{k}: could not be read", rep[k].get("error", ""), [], []))
    return out


# ---------------------------------------------------------------- renderers
_MD_SPECIAL = re.compile(r"([\\`*_{}\[\]()#+!|~])")


def md(v) -> str:
    """One markdown table cell: one line, HTML characters as entities, markdown metacharacters escaped."""
    t = " ".join(str("" if v is None else v).split())
    t = t.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")
    return _MD_SPECIAL.sub(r"\\\1", t)


def h(v) -> str:
    return html.escape(str("" if v is None else v), quote=True)


def render_md(rep: dict) -> str:
    L = [f"# {md(rep['title'])}", "", f"**{md(INTERNAL)}**", "",
         f"Week to {md(rep['as_of'])} ({md(rep['window_start_utc'])} to {md(rep['window_end_utc'])}, times in UTC; "
         f"schedule time zone {md(rep['tz'])}). Generated {md(rep['generated_utc'])}.", "", "## Summary", ""]
    L += [f"- {md(x)}" for x in rep["headline"]] + [""]
    for title, note, heads, rows in tables(rep):
        L += [f"## {md(title)}", ""]
        if note:
            L += [md(note), ""]
        if heads and rows:
            L += ["| " + " | ".join(md(x) for x in heads) + " |", "|" + "---|" * len(heads)]
            L += ["| " + " | ".join(md(x) for x in r) + " |" for r in rows]
            L.append("")
        elif heads:
            L += ["None this week.", ""]
    return "\n".join(L).rstrip() + "\n"


CSS = """:root{--bg:#fff;--fg:#1b1f24;--mut:#57606a;--line:#d0d7de;--band:#fff8c5}
@media (prefers-color-scheme:dark){:root{--bg:#0d1117;--fg:#e6edf3;--mut:#9da7b3;--line:#30363d;--band:#3b2e00}}
body{background:var(--bg);color:var(--fg);font:14px/1.45 -apple-system,Segoe UI,Helvetica,Arial,sans-serif;margin:0 auto;
max-width:1100px;padding:16px}h1{font-size:22px}h2{font-size:16px;margin-top:28px}.band{background:var(--band);padding:8px 12px;
border:1px solid var(--line);font-weight:600}.mut{color:var(--mut)}table{border-collapse:collapse;width:100%;display:block;
overflow-x:auto}th,td{border:1px solid var(--line);padding:4px 8px;text-align:left;vertical-align:top}td.n{text-align:right;
font-variant-numeric:tabular-nums}"""
_NUMERIC = re.compile(r"^[+-]?[\d,]+(\.\d+)?$")


def render_html(rep: dict) -> str:
    P = ["<!doctype html>", '<html lang="en"><head><meta charset="utf-8">',
         '<meta name="viewport" content="width=device-width,initial-scale=1">', '<meta name="robots" content="noindex">',
         f"<title>Ops report {h(rep['as_of'])}</title><style>{CSS}</style></head><body>",
         f'<p class="band">{h(INTERNAL)}</p>', f"<h1>{h(rep['title'])}</h1>",
         f'<p class="mut">Week to {h(rep["as_of"])} ({h(rep["window_start_utc"])} to {h(rep["window_end_utc"])}, times in UTC; '
         f'schedule time zone {h(rep["tz"])}). Generated {h(rep["generated_utc"])}.</p>', "<h2>Summary</h2><ul>"]
    P += [f"<li>{h(x)}</li>" for x in rep["headline"]] + ["</ul>"]
    for title, note, heads, rows in tables(rep):
        P.append(f"<h2>{h(title)}</h2>")
        if note:
            P.append(f'<p class="mut">{h(note)}</p>')
        if heads and rows:
            P.append("<table><thead><tr>" + "".join(f'<th scope="col">{h(x)}</th>' for x in heads) + "</tr></thead><tbody>")
            for r in rows:
                P.append("<tr>" + "".join(f'<td class="n">{h(x)}</td>' if _NUMERIC.match(str(x)) else f"<td>{h(x)}</td>"
                                          for x in r) + "</tr>")
            P.append("</tbody></table>")
        elif heads:
            P.append("<p>None this week.</p>")
    P.append("</body></html>")
    return "\n".join(P) + "\n"


def _atomic(p: Path, text: str) -> None:
    from .safe_write import write_atomic                 # SEC-C-018 L6 (EQ-C-0165): no planted .tmp symlink is followed
    write_atomic(p, text)


def write(rep: dict, out_dir) -> dict:
    dest = Path(out_dir) / REPORT_DIR
    dest.mkdir(parents=True, exist_ok=True)
    stem = f"ops-week-{rep['as_of']}"
    paths = {"html": dest / f"{stem}.html", "md": dest / f"{stem}.md", "json": dest / f"{stem}.json"}
    from ..presentation.csp import harden
    _atomic(paths["html"], harden(render_html(rep)))                                # EQ-C-0165 meta CSP
    _atomic(paths["md"], render_md(rep))
    _atomic(paths["json"], json.dumps(rep, indent=1, default=str))
    return {k: str(v) for k, v in paths.items()}


# ---------------------------------------------------------------- CLI
def add_arguments(ap: argparse.ArgumentParser) -> None:
    ap.add_argument("--week", action="store_true", help="the last 7 days (the only window; kept explicit for the schedule)")
    ap.add_argument("--as-of", help="report date YYYY-MM-DD (default today in the schedule's time zone)")
    ap.add_argument("--json", action="store_true", help="also print the report as JSON")
    ap.add_argument("--launch-agents", help="plist folder for the schedule check (default ~/Library/LaunchAgents on macOS)")


def run_from_args(args, home, data_dir=None, out_dir=None, now=None, log=print) -> int:
    home = Path(home)
    out_dir = Path(out_dir) if out_dir else home / "outputs"
    try:
        if args.as_of:
            dt.date.fromisoformat(args.as_of)
    except ValueError:
        log(f"[ops-report] --as-of must be YYYY-MM-DD, got {args.as_of!r}")
        return 1
    rep = build(home, data_dir, out_dir, args.as_of, now, getattr(args, "launch_agents", None))
    try:
        paths = write(rep, out_dir)
    except OSError as e:
        log(f"[ops-report] not written: {type(e).__name__}")
        return 1
    for x in rep["headline"]:
        log(f"[ops-report] {x}")
    log(f"[ops-report] INTERNAL report written: {paths['html']} and {paths['md']}")
    if getattr(args, "json", False):
        log(json.dumps(rep, indent=1, default=str))
    return 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ops.ops_report", description=__doc__.splitlines()[0])
    ap.add_argument("--home", default=os.environ.get("ECONQUEST_HOME", str(Path.home() / "econquest")))
    add_arguments(ap)
    a = ap.parse_args(argv)
    home = Path(a.home)
    return run_from_args(a, home, home / "data", home / "outputs")


if __name__ == "__main__":
    sys.exit(main())
