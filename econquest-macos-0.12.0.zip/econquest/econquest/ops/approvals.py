"""Change approvals for data/assumptions.json, data/limits.json and data/compliance.json (EQ-C-0023, roadmap 4.4,
model-risk-policy s.4-5; compliance.json since EQ-C-0040, SEC-C-004 R1; research.json since EQ-C-0075: the research
product mode, Tier 1 when it touches /mode, and a change that sets mode "client" is approved and applied only with an
approval signed by Sam, presentation.research.DECISION_OWNER).

A change goes propose -> approve (or reject) -> apply. Nothing but `apply` writes the governed files, and it writes
exactly the bytes that were proposed and approved, only while the file still has the sha256 the proposal was based on.

Records under `<data_dir>/approvals/`:
- `proposals/<id>.json`: one file per proposal, written once (id, file, base_sha256, new_sha256, diff, author, reason,
  tier, created_utc and the full new text). Its sha256 is logged, so editing it afterwards is detected.
- `log.jsonl`: every event (propose, approve, reject, apply, baseline) as one JSON row in a hash chain: `seq` counts
  from 1, `prev_hash` is the previous row's `row_hash` (64 zeros for the first) and
  `row_hash = sha256(prev_hash + canonical row)`, the canonical row being the row without `row_hash` as JSON with
  sorted keys and no spaces. `verify_chain` detects any edited, deleted, inserted or reordered row.
- `head.json`: seq and row_hash of the last row, rewritten on every append, so truncating the tail is detected too.
  The chain proves internal consistency only: someone who rewrites the log, the head and the proposals together can
  forge it; copy `head.json` into the release note to anchor it outside the folder.

Four-eyes uses Team A's rules (`econquest.ingestion.ledger.check_approval`, `person_key`: NFKC, zero-width and other
Unicode format characters removed, whitespace stripped, casefolded). Single-operator mode (Sam, 2026-10-23) needs
`self_approved=True` and an exception id `EXC-nnn` from docs/governance/issues-log.md; it is stored as approver =
author, self_approved "yes" and the EXC id, for every tier. Named users (EQ-C-0078, ops/identity.py): data/users.json
(governed here, Tier 2) registers users and key fingerprints; `approve(..., approver_id=)` signs the row (extra fields
approver_id, key_fp, signature, present only on signed rows, so older rows keep their shape and hashes), and once
users.json enforces four-eyes with two or more active users an unsigned approval is refused, and a self approval too
unless it is signed by the author under a named, unexpired users.json exception for "change" (EQ-C-0109).

Tiers (policy s.2 and s.4): any limits.json change is "limit" (approver signs; the owner cannot raise a limit on
himself); compliance.json (who may sign off research products) is Tier 2, owner + approver; assumptions.json keys map to Tier 1 or 2 by section (unknown sections are Tier 1); `monte_carlo.paths` and
`monte_carlo.seed` alone are "run" settings. A proposal takes the highest tier among its changed keys; an explicit
tier may raise it but not lower it. `layer1.mode` also needs the validator (restriction 6.1), shown as
"independent review pending".

`detect_unapproved` compares each governed file's current sha256 with the last one this tool applied (or
baselined) and reports drift, i.e. a hand edit outside the tool (also `fit-hazard --apply`, which writes
assumptions.json directly). Text fields are neutralised against spreadsheet formula injection
(`common_format.escape_formula`) before they are stored and hashed.
"""
from __future__ import annotations

import contextlib
import copy
import datetime as dt
import hashlib
import json
import os
import re
import secrets
import tempfile
from pathlib import Path

from ..common_format import escape_formula
from ..ingestion.ledger import check_approval, clean_person, person_key
from . import ledger_key

try:                                    # POSIX only; elsewhere events are unlocked
    import fcntl
except ImportError:                     # pragma: no cover
    fcntl = None

FILES = ("assumptions.json", "limits.json", "compliance.json", "research.json", "users.json", "licences.csv")
OPTIONAL_FILES = frozenset({"compliance.json", "research.json", "users.json", "licences.csv"})          # absent and never applied = built-in default, not "missing"
# EQ-C-0106 (SEC-C-015 R44): Team A's licence register (contract C14), the one CSV governed here, by ops/licence_gov.py.
# A patch is {"/<source_id>/<column>": "text"} or {"/<source_id>": {row}} (allow_new_keys), or the whole new file with
# replace=True; it is proposed only against the approved version; tighten-only is Tier 2 with the ordinary rules, a
# loosening is Tier 1 and needs Sam's sign-off, and so does every baseline. apply/baseline keep the approved bytes.
LICENCE_REGISTER = "licences.csv"
TIERS = ("limit", "1", "2", "3", "run")                 # most to least demanding
_RANK = {"limit": 4, "1": 3, "2": 2, "3": 1, "run": 0}
TIER2_SECTIONS = frozenset({"regime", "regime_rules", "transition_matrix", "stress_path", "gpr", "signals", "garch",
                            "cds", "alerts"})
TIER1_SECTIONS = frozenset({"scorecard", "probability", "ratings_pd", "floors", "market", "monte_carlo", "layer1",
                            "layer1_paper_coefficients", "layer1_fitted", "layer4", "liquidity", "perils",
                            "sector_multipliers", "location_multipliers", "boom_trigger", "prediction_markets"})
RUN_SETTINGS = frozenset({"/monte_carlo/paths", "/monte_carlo/seed"})
VALIDATOR_KEYS = frozenset({"/layer1/mode"})
EVENTS = ("propose", "approve", "reject", "apply", "baseline")
LOG_FIELDS = ["seq", "ts_utc", "event", "id", "file", "tier", "actor", "approver", "self_approved", "exc_id",
              "base_sha256", "new_sha256", "file_sha256", "proposal_sha256", "note", "prev_hash", "row_hash"]
_TEXT_FIELDS = ("actor", "approver", "exc_id", "note")
SIG_FIELDS = ("approver_id", "key_fp", "signature")      # EQ-C-0078: only on rows signed with --as (ops/identity.py)
GENESIS = "0" * 64
EXC_RE = re.compile(r"EXC-\d{3,}")
ID_RE = re.compile(r"CHG-\d{8}T\d{6}Z-[0-9a-f]{6}")


class ApprovalError(ValueError):
    """A refused propose/approve/reject/apply/baseline."""


# ---------------------------------------------------------------- paths, hashing, io

def approvals_dir(data_dir) -> Path:
    return Path(data_dir) / "approvals"


def log_path(data_dir) -> Path:
    return approvals_dir(data_dir) / "log.jsonl"


def head_path(data_dir) -> Path:
    return approvals_dir(data_dir) / "head.json"


def seal_path(data_dir) -> Path:
    """Keyed-head seal, written only when ledger_keyed_heads is on (EQ-C-0076, ops/ledger_key.py)."""
    return approvals_dir(data_dir) / ledger_key.SEAL_NAMES["approvals"]


def proposal_path(data_dir, change_id: str) -> Path:
    return approvals_dir(data_dir) / "proposals" / f"{_check_id(change_id)}.json"


def _check_id(change_id) -> str:
    s = str(change_id or "").strip()
    if not ID_RE.fullmatch(s):
        raise ApprovalError(f"not a change id: {change_id!r} (expected CHG-YYYYMMDDTHHMMSSZ-xxxxxx)")
    return s


def _file_name(file) -> str:
    name = Path(str(file)).name
    if name not in FILES:
        raise ApprovalError(f"only {', '.join(FILES)} are governed by change approvals, got {file!r}")
    return name


def sha256_bytes(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def file_sha256(path) -> str | None:
    p = Path(path)
    return sha256_bytes(p.read_bytes()) if p.exists() else None


def _ts(now: dt.datetime | None) -> str:
    now = now or dt.datetime.now(dt.timezone.utc)
    now = now.replace(tzinfo=dt.timezone.utc) if now.tzinfo is None else now.astimezone(dt.timezone.utc)
    return now.strftime("%Y-%m-%dT%H:%M:%S.%fZ")


def serialise(doc) -> str:
    """The text apply writes: 2-space indent, UTF-8, trailing newline; NaN/inf refused (not valid JSON)."""
    try:
        return json.dumps(doc, indent=2, ensure_ascii=False, allow_nan=False) + "\n"
    except (TypeError, ValueError) as e:
        raise ApprovalError(f"result is not valid JSON: {e}") from None


def _atomic_write(path: Path, data: bytes, exclusive: bool = False) -> None:
    """Write via a temp file in the same folder and os.replace (keeps the old file's mode; no hard links, which some
    network mounts lack). exclusive: refuse if the target exists."""
    path.parent.mkdir(parents=True, exist_ok=True)
    if exclusive and path.exists():
        raise ApprovalError(f"{path.name} already exists")
    mode = path.stat().st_mode & 0o777 if path.exists() else 0o644
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.chmod(tmp, mode)
        if exclusive and path.exists():  # callers hold _locked, so this re-check closes the window
            raise ApprovalError(f"{path.name} already exists")
        os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


@contextlib.contextmanager
def _locked(data_dir):
    """Exclusive lock over the approvals folder for one read-check-append (POSIX flock)."""
    d = approvals_dir(data_dir); d.mkdir(parents=True, exist_ok=True)
    with open(d / ".lock", "a") as f:
        if fcntl is not None:
            fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            if fcntl is not None:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)


# ---------------------------------------------------------------- hash-chained log

def canonical(row: dict) -> str:
    return json.dumps({k: v for k, v in row.items() if k != "row_hash"}, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False)


def row_hash(prev_hash: str, row: dict) -> str:
    return sha256_bytes((prev_hash + canonical(row)).encode("utf-8"))


def read_log(data_dir) -> list[dict]:
    """Every log row in file order (unparseable lines raise ApprovalError; use verify_chain to diagnose)."""
    p = log_path(data_dir)
    if not p.exists():
        return []
    rows = []
    for i, line in enumerate(p.read_text(encoding="utf-8").splitlines(), 1):
        if not line.strip():
            continue
        try:
            rows.append(json.loads(line))
        except json.JSONDecodeError:
            raise ApprovalError(f"log.jsonl line {i} is not JSON") from None
    return rows


def _append_event(data_dir, event: str, now=None, **fields) -> dict:
    """Append one event (caller holds _locked). Text fields are formula-neutralised before hashing."""
    rows = read_log(data_dir)
    prev = rows[-1]["row_hash"] if rows else GENESIS
    row = {c: "" for c in LOG_FIELDS}
    row.update({k: ("" if v is None else v) for k, v in fields.items() if k in LOG_FIELDS})
    for c in _TEXT_FIELDS:
        row[c] = escape_formula(str(row[c]))
    row.update({k: str(fields[k]) for k in SIG_FIELDS if fields.get(k)})    # absent on unsigned rows: old shape kept
    row.update(seq=len(rows) + 1, ts_utc=_ts(now), event=event, prev_hash=prev)
    row["row_hash"] = row_hash(prev, row)
    p = log_path(data_dir); p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n"); f.flush(); os.fsync(f.fileno())
    _atomic_write(head_path(data_dir), (json.dumps({"seq": row["seq"], "row_hash": row["row_hash"]}) + "\n").encode())
    ledger_key.seal("approvals", seal_path(data_dir), row["seq"], row["row_hash"])     # no-op unless on (EQ-C-0076)
    return row


def verify_chain(data_dir) -> dict:
    """Check the log: every row parses, seq runs 1..n, each prev_hash is the previous row_hash, each row_hash
    recomputes, head.json names the last row, and every proposal file still has the sha256 its propose event logged.
    Returns {"ok", "rows", "head", "errors": [...]}."""
    errors, rows = [], []
    p = log_path(data_dir)
    lines = p.read_text(encoding="utf-8").splitlines() if p.exists() else []
    prev = GENESIS
    for i, line in enumerate(lines, 1):
        if not line.strip():
            errors.append(f"line {i}: blank line"); continue
        try:
            r = json.loads(line)
        except json.JSONDecodeError:
            errors.append(f"line {i}: not JSON"); prev = None; continue
        if r.get("seq") != len(rows) + 1:
            errors.append(f"line {i}: seq {r.get('seq')} where {len(rows) + 1} expected (row deleted, inserted or moved)")
        if prev is not None and r.get("prev_hash") != prev:
            errors.append(f"line {i}: prev_hash does not match the previous row (row deleted, inserted or moved)")
        if r.get("row_hash") != row_hash(str(r.get("prev_hash", "")), r):
            errors.append(f"line {i}: row_hash does not recompute (row edited)")
        prev = r.get("row_hash")
        rows.append(r)
    head = None
    hp = head_path(data_dir)
    if hp.exists():
        try:
            head = json.loads(hp.read_text())
        except json.JSONDecodeError:
            errors.append("head.json is not JSON")
    if rows and head is None and not hp.exists():
        errors.append("head.json missing")
    if isinstance(head, dict):
        last = rows[-1] if rows else {"seq": 0, "row_hash": GENESIS}
        if head.get("seq") != last.get("seq") or head.get("row_hash") != last.get("row_hash"):
            errors.append(f"head.json names seq {head.get('seq')} but the log ends at seq {last.get('seq')} "
                          "(rows removed from or added to the end)")
    tip = rows[-1] if rows else {"seq": 0, "row_hash": GENESIS}
    errors += ledger_key.check("approvals", seal_path(data_dir), tip.get("seq") or 0, tip.get("row_hash"))   # [] when off
    for r in rows:
        if r.get("event") == "propose" and ID_RE.fullmatch(str(r.get("id", ""))):
            pp = proposal_path(data_dir, r["id"])
            if file_sha256(pp) != r.get("proposal_sha256"):
                errors.append(f"proposal {r['id']}: file {'missing' if not pp.exists() else 'changed'} since it was logged")
    return {"ok": not errors, "rows": len(rows), "head": head, "errors": errors}


def _require_chain(data_dir) -> list[dict]:
    v = verify_chain(data_dir)
    if not v["ok"]:
        raise ApprovalError("approvals log failed verification, refusing: " + "; ".join(v["errors"][:5]))
    return read_log(data_dir)


# ---------------------------------------------------------------- JSON pointer patching and diff

def _pointer(path: str) -> list[str]:
    if not isinstance(path, str) or not path.startswith("/"):
        raise ApprovalError(f"key path must be a JSON pointer starting with '/', got {path!r}")
    return [s.replace("~1", "/").replace("~0", "~") for s in path[1:].split("/")]


def _escape_seg(s) -> str:
    return str(s).replace("~", "~0").replace("/", "~1")


def _kind(v) -> str:
    if v is None:
        return "null"
    if isinstance(v, bool):
        return "bool"
    if isinstance(v, (int, float)):
        return "number"
    return {str: "string", dict: "object", list: "array"}.get(type(v), type(v).__name__)


def apply_patch(doc, patch: dict, allow_new_keys: bool = False):
    """Copy of doc with each {json_pointer: new_value} set. Every parent must exist; the last segment must exist
    unless allow_new_keys (an array index '-' appends)."""
    if not isinstance(patch, dict) or not patch:
        raise ApprovalError("patch must be a non-empty {json_pointer: new value} mapping")
    out = copy.deepcopy(doc)
    for path, value in patch.items():
        segs = _pointer(path)
        if segs == [""]:
            raise ApprovalError("the empty pointer would replace the whole file; pass replace=True instead")
        node = out
        for depth, seg in enumerate(segs):
            last = depth == len(segs) - 1
            where = "/" + "/".join(_escape_seg(s) for s in segs[:depth + 1])
            if isinstance(node, dict):
                if seg not in node and not (last and allow_new_keys):
                    raise ApprovalError(f"{where}: key does not exist" + (" (pass allow_new_keys to add it)" if last else ""))
                if last:
                    node[seg] = copy.deepcopy(value)
                else:
                    node = node[seg]
            elif isinstance(node, list):
                if seg == "-" and last and allow_new_keys:
                    node.append(copy.deepcopy(value)); continue
                if not (seg.isascii() and seg.isdigit()) or int(seg) >= len(node):   # "²", "١" are isdigit()
                    raise ApprovalError(f"{where}: no such array index")
                if last:
                    node[int(seg)] = copy.deepcopy(value)
                else:
                    node = node[int(seg)]
            else:
                raise ApprovalError(f"{where}: parent is a {_kind(node)}, not an object or array")
    return out


def diff_docs(old, new, path: str = "") -> list[dict]:
    """Leaf-level changes [{path, op (change|add|remove), old, new}]; arrays of different length are one change."""
    if isinstance(old, dict) and isinstance(new, dict):
        out = []
        for k in old:
            p = f"{path}/{_escape_seg(k)}"
            out += diff_docs(old[k], new[k], p) if k in new else [{"path": p, "op": "remove", "old": old[k], "new": None}]
        out += [{"path": f"{path}/{_escape_seg(k)}", "op": "add", "old": None, "new": new[k]} for k in new if k not in old]
        return out
    if isinstance(old, list) and isinstance(new, list) and len(old) == len(new):
        return [c for i, (a, b) in enumerate(zip(old, new)) for c in diff_docs(a, b, f"{path}/{i}")]
    if _kind(old) == _kind(new) and old == new:
        return []
    return [{"path": path or "/", "op": "change", "old": old, "new": new}]


def infer_tier(file: str, diff: list[dict]) -> tuple[str, bool]:
    """(tier, needs_validator) for a diff of `file` (model-risk-policy s.2 and s.4)."""
    if _file_name(file) == "limits.json":
        return "limit", False
    if _file_name(file) in ("compliance.json", "users.json"):   # controls, not model parameters: owner + approver
        return "2", False
    if _file_name(file) == "research.json":               # EQ-C-0075: the client-mode switch is Sam's decision (Tier 1)
        return ("1" if any(c["path"] in ("/", "/mode") for c in diff) else "2"), False
    best, validator = "run", False
    for c in diff:
        p = c["path"]
        top = _pointer(p)[0] if p != "/" else ""
        if p in RUN_SETTINGS:
            t = "run"
        elif top in TIER2_SECTIONS:
            t = "2"
        else:                                     # TIER1_SECTIONS and anything unknown
            t = "1"
        validator = validator or p in VALIDATOR_KEYS or p == "/layer1"
        best = t if _RANK[t] > _RANK[best] else best
    return best, validator


# ---------------------------------------------------------------- state

def _events_by_id(rows) -> dict[str, list[dict]]:
    out: dict[str, list[dict]] = {}
    for r in rows:
        if r.get("id"):
            out.setdefault(r["id"], []).append(r)
    return out


def _status(events: list[dict]) -> str:
    st = "unknown"
    for e in events:
        st = {"propose": "proposed", "approve": "approved", "reject": "rejected", "apply": "applied"}.get(e["event"], st)
    return st


def load_proposal(data_dir, change_id: str) -> dict:
    p = proposal_path(data_dir, change_id)
    if not p.exists():
        raise ApprovalError(f"no proposal {change_id}")
    return json.loads(p.read_text(encoding="utf-8"))


# ---------------------------------------------------------------- public API

def propose(data_dir, file, patch, author, reason, tier=None, replace: bool = False, allow_new_keys: bool = False,
            allow_type_change: bool = False, now: dt.datetime | None = None) -> dict:
    """Record a proposed change to data/<file> and return the proposal. `patch` is {json_pointer: new value}
    (e.g. {"/layer4/lgd_sd": 0.12}) or, with replace=True, the whole new document. Keys must exist (adding them, or
    removing them in a replacement, needs allow_new_keys); a value may not change JSON type without
    allow_type_change; the result must be valid JSON (no NaN/inf). The tier is inferred; an explicit `tier` may raise
    it, not lower it. The governed file is not touched."""
    name = _file_name(file)
    author, reason = clean_person(author), str(reason or "").strip()
    if not person_key(author):
        raise ApprovalError("author is required")
    if not reason:
        raise ApprovalError("reason is required")
    target = Path(data_dir) / name
    if not target.exists():
        raise ApprovalError(f"{target} does not exist")
    base_bytes = target.read_bytes()
    if name == LICENCE_REGISTER:                        # EQ-C-0106: the CSV register (ops/licence_gov.py)
        return _propose_register(data_dir, base_bytes, patch, author, reason, tier, replace, allow_new_keys, now)
    try:
        old = json.loads(base_bytes.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise ApprovalError(f"{name} is not valid JSON now ({e}); repair it before proposing") from None
    if replace:
        if isinstance(patch, (str, bytes)):
            try:
                patch = json.loads(patch)
            except json.JSONDecodeError as e:
                raise ApprovalError(f"replacement is not valid JSON: {e}") from None
        new = copy.deepcopy(patch)
    else:
        new = apply_patch(old, patch, allow_new_keys=allow_new_keys)
    new_text = serialise(new)
    new = json.loads(new_text)                    # exactly what will be written
    diff = diff_docs(old, new)
    if not diff:
        raise ApprovalError("the change leaves the file's content unchanged")
    if not isinstance(new, dict) or not isinstance(old, dict):
        raise ApprovalError("the file must stay a JSON object")
    if name == "research.json":                         # EQ-C-0075: refuse an invalid product-line config
        from ..presentation.research import ResearchConfigError, validate_config as _vr
        try:
            _vr(new, name)
        except ResearchConfigError as e:
            raise ApprovalError(str(e)) from None
    if name == "users.json":                            # EQ-C-0078: refuse a registry that approvals would then reject
        from .identity import IdentityError, _ts_key, validate_registry
        try:
            nreg = validate_registry(new, name)
        except IdentityError as e:
            raise ApprovalError(str(e)) from None
        was = old if isinstance(old, dict) else {}       # EQ-C-0109: a past enforced_from would flag legacy approvals
        if nreg["four_eyes"] == "enforce" and (was.get("four_eyes") != "enforce" or was.get("enforced_from") != new.get("enforced_from")):
            last = max((r.get("ts_utc", "") for r in read_log(data_dir) if r.get("event") in ("approve", "baseline")), default="")
            if last and _ts_key(nreg["enforced_from"]) <= last:
                raise ApprovalError(f"enforced_from {nreg['enforced_from']} is not after the last logged approval ({last[:19]}Z): "
                                    "rows before it would count as unsigned under enforcement; use the current UTC time "
                                    "(date -u +%Y-%m-%dT%H:%M:%SZ)")
    if name == "compliance.json":                       # refuse a config that sign-off would then reject
        from ..presentation.compliance import ComplianceError, validate_config
        try:
            validate_config(new, name)
        except ComplianceError as e:
            raise ApprovalError(str(e)) from None
    structural = [c["path"] for c in diff if c["op"] in ("add", "remove")]
    if structural and not allow_new_keys:
        raise ApprovalError(f"adds or removes keys {structural[:5]}; pass allow_new_keys to allow that")
    retyped = [c["path"] for c in diff if c["op"] == "change" and _kind(c["old"]) != _kind(c["new"])]
    if retyped and not allow_type_change:
        raise ApprovalError(f"changes the JSON type of {retyped[:5]}; pass allow_type_change to allow that")
    inferred, needs_validator = infer_tier(name, diff)
    if tier is None or str(tier).strip() == "":
        tier = inferred
    else:
        tier = str(tier).strip().lower().removeprefix("tier").strip()
        if tier not in TIERS:
            raise ApprovalError(f"tier must be one of {TIERS}, got {tier!r}")
        if _RANK[tier] < _RANK[inferred]:
            raise ApprovalError(f"tier {tier} is below the inferred tier {inferred} for these keys; a tier can only be raised")
    with _locked(data_dir):
        _require_chain(data_dir)
        ts = _ts(now)
        change_id = f"CHG-{ts[:4]}{ts[5:7]}{ts[8:10]}T{ts[11:13]}{ts[14:16]}{ts[17:19]}Z-{secrets.token_hex(3)}"
        prop = {"id": change_id, "file": name, "base_sha256": sha256_bytes(base_bytes),
                "new_sha256": sha256_bytes(new_text.encode("utf-8")), "diff": diff,
                "author": escape_formula(author), "reason": escape_formula(reason), "tier": tier,
                "tier_inferred": inferred, "needs_validator": needs_validator, "created_utc": ts, "new_text": new_text}
        pbytes = (json.dumps(prop, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
        _atomic_write(proposal_path(data_dir, change_id), pbytes, exclusive=True)
        _append_event(data_dir, "propose", now=now, id=change_id, file=name, tier=tier, actor=author,
                      base_sha256=prop["base_sha256"], new_sha256=prop["new_sha256"],
                      proposal_sha256=sha256_bytes(pbytes), note=reason)
    return prop


# ---------------------------------------------------------------- EQ-C-0106: the licence register (CSV)
def _register_classes(base_bytes: bytes, new_text: str) -> tuple[dict, dict, dict]:
    """(old doc, new doc, licence_gov.classify) for a licences.csv change; ApprovalError when either side is invalid."""
    from . import licence_gov as G
    try:
        old = G.doc(G.parse(base_bytes, f"data/{LICENCE_REGISTER}"))
        new = G.doc(G.parse(new_text.encode("utf-8"), f"proposed {LICENCE_REGISTER}"))
    except G.LicenceGovError as e:
        raise ApprovalError(str(e)) from None
    return old, new, G.classify(old, new)


def _propose_register(data_dir, base_bytes, patch, author, reason, tier, replace, allow_new_keys, now) -> dict:
    """A licences.csv proposal: only against the approved register (drift or no baseline refuses), validated by Team
    A's rules, classified tighten-only (Tier 2) or loosening (Tier 1, Sam's sign-off: _require_licence_owner)."""
    from . import licence_gov as G
    st = G.state(data_dir)
    if st["status"] != "ok":
        raise ApprovalError(f"{LICENCE_REGISTER}: a change is proposed only against the approved register: "
                            f"{G.problem(data_dir, st)}")
    if replace:
        new_text = patch.decode("utf-8") if isinstance(patch, bytes) else patch
        if not isinstance(new_text, str):
            raise ApprovalError(f"{LICENCE_REGISTER}: replace=True takes the whole new CSV text")
    else:
        try:
            old_doc = G.doc(G.parse(base_bytes, f"data/{LICENCE_REGISTER}"))
            new_text = G.text_of(apply_patch(old_doc, patch, allow_new_keys=allow_new_keys))
        except G.LicenceGovError as e:
            raise ApprovalError(str(e)) from None
    if new_text.encode("utf-8") == base_bytes:
        raise ApprovalError("the change leaves the file's content unchanged")
    old_doc, new_doc, cls = _register_classes(base_bytes, new_text)
    diff = diff_docs(old_doc, new_doc)
    if not diff and not cls["neutral"]:
        raise ApprovalError("the change leaves the register's rows unchanged (only the formatting differs)")
    structural = [c["path"] for c in diff if c["op"] in ("add", "remove")]
    if structural and not allow_new_keys:
        raise ApprovalError(f"adds or removes rows or columns {structural[:5]}; pass allow_new_keys to allow that")
    inferred = "1" if cls["loosen"] else "2"
    if tier is None or str(tier).strip() == "":
        tier = inferred
    else:
        tier = str(tier).strip().lower().removeprefix("tier").strip()
        if tier not in TIERS or _RANK[tier] < _RANK[inferred]:
            raise ApprovalError(f"tier {tier!r} is not one of {TIERS} at or above the inferred tier {inferred}")
    with _locked(data_dir):
        _require_chain(data_dir)
        ts = _ts(now)
        change_id = f"CHG-{ts[:4]}{ts[5:7]}{ts[8:10]}T{ts[11:13]}{ts[14:16]}{ts[17:19]}Z-{secrets.token_hex(3)}"
        prop = {"id": change_id, "file": LICENCE_REGISTER, "base_sha256": sha256_bytes(base_bytes),
                "new_sha256": sha256_bytes(new_text.encode("utf-8")), "diff": diff,
                "author": escape_formula(author), "reason": escape_formula(reason), "tier": tier,
                "tier_inferred": inferred, "needs_validator": False, "loosens": cls["loosen"],
                "tightens": cls["tighten"], "neutral": cls["neutral"], "needs_owner": bool(cls["loosen"]),
                "created_utc": ts, "new_text": new_text}
        pbytes = (json.dumps(prop, indent=2, ensure_ascii=False) + "\n").encode("utf-8")
        _atomic_write(proposal_path(data_dir, change_id), pbytes, exclusive=True)
        _append_event(data_dir, "propose", now=now, id=change_id, file=LICENCE_REGISTER, tier=tier, actor=author,
                      base_sha256=prop["base_sha256"], new_sha256=prop["new_sha256"],
                      proposal_sha256=sha256_bytes(pbytes), note=reason)
    return prop


def _require_licence_owner(prop: dict, approver, flag, exc, what: str, data_dir, signer_id=None,
                           row: dict | None = None) -> None:
    """A licences.csv change that loosens the register is Sam's decision (licences are Sam's call, CLAUDE.md rule 5):
    the approver must be presentation.research.DECISION_OWNER, a self-approval must cite an EXC that is a row of
    docs/governance/issues-log.md, and once Sam has an enrolled key the approval must be signed with it. A change that
    only tightens the register passes (ordinary four-eyes or EXC rules)."""
    if prop.get("file") != LICENCE_REGISTER or not prop.get("loosens"):
        return
    from ..presentation.research import DECISION_OWNER
    first = "; ".join(map(str, prop["loosens"][:3]))
    if person_key(approver or "") != person_key(DECISION_OWNER):
        raise ApprovalError(f"{what}: this change loosens the licence register ({first}); only {DECISION_OWNER} may "
                            f"approve it: four-eyes with --approver {DECISION_OWNER}, or {DECISION_OWNER} "
                            "--self-approved with a named --exc EXC-nnn from docs/governance/issues-log.md. A change "
                            f"that only tightens the register needs no sign-off from {DECISION_OWNER}. Got {approver!r}")
    if flag == "yes" and exc_logged(data_dir, exc) is not True:
        raise ApprovalError(f"{what}: a self-approved loosening needs a named exception: {exc or '(none)'} is not a row "
                            "of docs/governance/issues-log.md")
    from . import identity
    try:
        owner = identity.owner_user(data_dir, DECISION_OWNER)
        problem = owner_signature_problem(data_dir, owner, signer_id, row) if owner else None
    except identity.IdentityError as e:
        problem = str(e)
    if problem:
        raise ApprovalError(f"{what}: licence register loosening: {problem}")


def _signoff(author, approver, self_approved, exc_id, what: str, data_dir=None) -> tuple[str, str, str, str]:
    """(author, approver, self_flag, exc_id) after the four-eyes rule; self-approval needs an EXC-nnn id."""
    try:
        author, approver, flag = check_approval(author, approver, self_approved)
    except ValueError as e:
        raise ApprovalError(f"{what}: {e} together with an exception id (EXC-nnn)") from None
    return author, approver, flag, check_exc(flag, exc_id, what)


def sets_client_mode(prop: dict) -> bool:
    """The proposal writes research.json with mode "client" (EQ-C-0075)."""
    if prop.get("file") != "research.json":
        return False
    try:
        return json.loads(prop.get("new_text") or "{}").get("mode") == "client"
    except (ValueError, AttributeError):
        return True                              # unreadable: treat as the restricted case


def _require_decision_owner(prop: dict, approver, what: str, data_dir=None, signer_id=None, row: dict | None = None) -> None:
    """Client mode (research.json mode "client") is Sam's decision (program board "Internal vs client"): only an
    approval signed by presentation.research.DECISION_OWNER may approve or apply it (EQ-C-0075). Once Sam has an
    enrolled key in the governed users.json, the approval must also be signed with it (`--as`), so typing
    `--approver Sam` is not enough (SEC-C-011 L2)."""
    if not sets_client_mode(prop):
        return
    from ..presentation.research import DECISION_OWNER
    if person_key(approver or "") != person_key(DECISION_OWNER):
        raise ApprovalError(f"{what}: research.json client mode is {DECISION_OWNER}'s decision (program board \"Internal vs client\"); it needs an approval signed by {DECISION_OWNER}, got {approver!r}. Internal mode stays in force.")
    if data_dir is None:
        return
    from . import identity
    try:
        owner = identity.owner_user(data_dir, DECISION_OWNER)
        problem = owner_signature_problem(data_dir, owner, signer_id, row) if owner else None
    except identity.IdentityError as e:
        problem = str(e)
    if problem:
        raise ApprovalError(f"{what}: research.json client mode: {problem}. Internal mode stays in force.")


def owner_signature_problem(data_dir, owner: dict, signer_id=None, row: dict | None = None) -> str | None:
    """Why an approval does not carry the owner's signature (None when it does). With `row`, the logged approve row is
    checked (approver_id and HMAC where the key is available); else the id that is about to sign."""
    from . import identity
    if row is None:
        return None if signer_id == owner["id"] else f"{owner['name']} has an enrolled key: approve with --as {owner['id']}"
    if row.get("approver_id") != owner["id"]:
        return f"the approval is not signed by {owner['id']}"
    st = identity.check_signature(row, identity.governed_registry(data_dir))
    return None if st in ("ok", "unchecked") else st


def check_exc(flag: str, exc_id, what: str, kind: str = "self-approval") -> str:
    """The EXC-nnn id after the single-operator rule: required when flag is "yes", well-formed when given at all.
    Shared by change approve/baseline and the compliance self-sign (EQ-C-0041)."""
    exc = str(exc_id or "").strip()
    if flag == "yes":
        if not EXC_RE.fullmatch(exc):
            raise ApprovalError(f"{what}: a {kind} (single-operator mode) needs an exception id EXC-nnn from "
                                f"docs/governance/issues-log.md (--exc EXC-nnn), got {exc_id!r}")
    elif exc and not EXC_RE.fullmatch(exc):
        raise ApprovalError(f"{what}: exception id must look like EXC-nnn, got {exc_id!r}")
    return exc


def exc_logged(data_dir, exc_id: str) -> bool | None:
    """True/False when docs/governance/issues-log.md (next to data/) lists exc_id as a table row id; None when the
    issues log is not there."""
    p = Path(data_dir).resolve().parent / "docs" / "governance" / "issues-log.md"
    if not p.exists() or not exc_id:
        return None
    return re.search(rf"^\|\s*{re.escape(exc_id)}\s*\|", p.read_text(encoding="utf-8"), re.M) is not None


def approve(data_dir, change_id, approver=None, self_approved: bool = False, exc_id=None, note: str = "",
            now: dt.datetime | None = None, approver_id: str | None = None, env: dict | None = None) -> dict:
    """Approve a proposed change. Four-eyes: the approver must differ from the author (ledger.person_key: case,
    whitespace, NFKC and zero-width characters ignored). Single-operator mode needs self_approved=True and
    exc_id 'EXC-nnn'; it is stored as approver = author, self_approved 'yes'. approver_id (`--as`, EQ-C-0078) signs
    the row with that registered user's key (ops/identity.py); it is required, and self-approval refused, once
    data/users.json enforces four-eyes with two or more active users. Returns the log row."""
    from . import identity
    change_id = _check_id(change_id)
    with _locked(data_dir):
        rows = _require_chain(data_dir)
        prop = load_proposal(data_dir, change_id)
        st = _status(_events_by_id(rows).get(change_id, []))
        if st != "proposed":
            raise ApprovalError(f"{change_id} is {st}, only a proposed change can be approved")
        try:
            approver, signer = identity.resolve_approver(data_dir, prop, approver, approver_id, self_approved, exc_id, now)
        except identity.IdentityError as e:
            raise ApprovalError(f"approving {change_id}: {e}") from None
        _, appr, flag, exc = _signoff(prop["author"], approver, self_approved, exc_id, f"approving {change_id}")
        _require_decision_owner(prop, appr, f"approving {change_id}", data_dir, signer["id"] if signer else None)
        _require_licence_owner(prop, appr, flag, exc, f"approving {change_id}", data_dir,
                               signer["id"] if signer else None)            # EQ-C-0106: loosening is Sam's
        extra = ""
        if flag == "yes":
            logged = exc_logged(data_dir, exc)
            extra = {True: "", False: f" [{exc} not yet in issues-log.md]", None: ""}[logged]
        if prop.get("needs_validator"):
            extra += " [independent review pending]"
        fields = dict(id=change_id, file=prop["file"], tier=prop["tier"], actor=appr, approver=appr, self_approved=flag,
                      exc_id=exc, base_sha256=prop["base_sha256"], new_sha256=prop["new_sha256"],
                      note=(str(note or "").strip() + extra).strip())
        if signer is not None:                         # sign exactly what the row will store
            stored = {**fields, "event": "approve", "approver": escape_formula(str(appr)), "exc_id": escape_formula(str(exc))}
            try:
                fields.update(identity.sign(signer, stored, env))
            except identity.IdentityError as e:
                raise ApprovalError(f"approving {change_id}: {e}") from None
        return _append_event(data_dir, "approve", now=now, **fields)


def reject(data_dir, change_id, by, reason: str = "", now: dt.datetime | None = None) -> dict:
    """Reject (or, by the author, withdraw) a proposed or approved change that was not applied."""
    change_id = _check_id(change_id)
    by = clean_person(by)
    if not person_key(by):
        raise ApprovalError("reject needs who rejects (by)")
    with _locked(data_dir):
        rows = _require_chain(data_dir)
        prop = load_proposal(data_dir, change_id)
        st = _status(_events_by_id(rows).get(change_id, []))
        if st not in ("proposed", "approved"):
            raise ApprovalError(f"{change_id} is {st}, cannot reject it")
        return _append_event(data_dir, "reject", now=now, id=change_id, file=prop["file"], tier=prop["tier"],
                             actor=by, base_sha256=prop["base_sha256"], new_sha256=prop["new_sha256"],
                             note=str(reason or "").strip())


def apply(data_dir, change_id, actor=None, now: dt.datetime | None = None) -> dict:
    """Write an approved change. Refused when it is not approved, when the governed file's sha256 is no longer the
    proposal's base (stale: re-propose), when the proposal file or log was tampered with. Writes atomically (temp file
    + rename) and logs the applied sha256. Returns the log row."""
    change_id = _check_id(change_id)
    with _locked(data_dir):
        rows = _require_chain(data_dir)
        prop = load_proposal(data_dir, change_id)
        st = _status(_events_by_id(rows).get(change_id, []))
        if st != "approved":
            raise ApprovalError(f"{change_id} is {st}; only an approved change can be applied")
        appr_rows = [e for e in _events_by_id(rows).get(change_id, []) if e["event"] == "approve"]
        _require_decision_owner(prop, appr_rows[-1].get("approver") if appr_rows else "", f"applying {change_id}", data_dir,
                                row=appr_rows[-1] if appr_rows else {})
        from . import identity                       # SEC-C-012 R27: apply re-checks the four-eyes rules (EQ-C-0084)
        try:
            proposed = [e.get("ts_utc", "") for e in _events_by_id(rows).get(change_id, []) if e["event"] == "propose"]
            identity.check_apply(data_dir, prop, appr_rows[-1] if appr_rows else {},
                                 proposed_utc=proposed[0] if proposed else "", now=now)    # SEC-C-014 L3
        except identity.IdentityError as e:
            raise ApprovalError(f"applying {change_id}: {e}") from None
        data = prop["new_text"].encode("utf-8")
        if sha256_bytes(data) != prop["new_sha256"]:
            raise ApprovalError(f"{change_id}: proposal text does not match its new_sha256")
        target = Path(data_dir) / _file_name(prop["file"])
        cur = file_sha256(target)
        if cur != prop["base_sha256"]:
            raise ApprovalError(f"{change_id} is stale: {prop['file']} has sha256 {str(cur)[:12]}... but the proposal was "
                                f"made against {prop['base_sha256'][:12]}...; reject it and propose again")
        if prop["file"] == LICENCE_REGISTER:          # EQ-C-0106: re-classify from the bytes about to be replaced
            if target.is_symlink():
                raise ApprovalError(f"applying {change_id}: data/{LICENCE_REGISTER} is a symlink (refused)")
            _, _, cls = _register_classes(target.read_bytes(), prop["new_text"])
            if cls["loosen"] and not prop.get("loosens"):
                raise ApprovalError(f"applying {change_id}: the change loosens the licence register but its proposal "
                                    "does not say so; propose it again")
            a = appr_rows[-1] if appr_rows else {}
            _require_licence_owner({**prop, "loosens": cls["loosen"] or prop.get("loosens")}, a.get("approver"),
                                   a.get("self_approved"), a.get("exc_id"), f"applying {change_id}", data_dir, row=a)
        _atomic_write(target, data)
        applied = file_sha256(target)
        if prop["file"] == LICENCE_REGISTER:          # the approved register enforcement reads (ops/licence_gov.py)
            from .licence_gov import save_snapshot
            save_snapshot(data_dir, data)
        return _append_event(data_dir, "apply", now=now, id=change_id, file=prop["file"], tier=prop["tier"],
                             actor=clean_person(actor) or "", base_sha256=prop["base_sha256"],
                             new_sha256=prop["new_sha256"], file_sha256=applied)


def _last_applied(rows, name: str) -> dict | None:
    last = None
    for r in rows:
        if r.get("file") == name and r.get("event") in ("apply", "baseline"):
            last = r
    return last


def baseline(data_dir, file, actor, reason, approver=None, self_approved: bool = False, exc_id=None,
             now: dt.datetime | None = None, approver_id: str | None = None, env: dict | None = None) -> dict:
    """Record the governed file's current sha256 as accepted, so detect_unapproved can start (first use) or accept a
    hand edit it reported (re-baseline). The first baseline of a file needs only the actor; accepting drift is a
    sign-off and follows the approve rules (approver other than the actor, or self_approved with EXC-nnn)."""
    name = _file_name(file)
    actor, reason = clean_person(actor), str(reason or "").strip()
    if not person_key(actor) or not reason:
        raise ApprovalError("baseline needs an actor and a reason")
    if name == LICENCE_REGISTER:                        # EQ-C-0106: every register baseline is Sam's sign-off
        return _baseline_register(data_dir, actor, reason, approver, self_approved, exc_id, now, approver_id, env)
    with _locked(data_dir):
        rows = _require_chain(data_dir)
        cur = file_sha256(Path(data_dir) / name)
        if cur is None:
            raise ApprovalError(f"{name} does not exist")
        prev = _last_applied(rows, name)
        appr, flag, exc = "", "", ""
        if prev is not None:
            if prev.get("file_sha256") == cur:
                raise ApprovalError(f"{name} already matches the last applied sha256; nothing to baseline")
            from . import identity                   # EQ-C-0109: under enforcement accepting drift is a signed sign-off
            signer = None
            try:
                reg = identity.trusted_registry(data_dir)
                if approver_id or identity.enforced(reg):
                    approver, signer = identity.resolve_approver(data_dir, {"author": actor}, approver, approver_id,
                                                                 self_approved, exc_id, now, reg=reg)
            except identity.IdentityError as e:
                raise ApprovalError(f"accepting drift in {name}: {e}") from None
            _, appr, flag, exc = _signoff(actor, approver, self_approved, exc_id, f"accepting drift in {name}")
        fields = dict(file=name, tier="limit" if name == "limits.json" else "", actor=actor, approver=appr,
                      self_approved=flag, exc_id=exc, base_sha256=(prev or {}).get("file_sha256", ""), file_sha256=cur,
                      note=reason)
        if prev is not None and signer is not None:
            stored = {**fields, "event": "baseline", "id": "", "new_sha256": "", "approver": escape_formula(str(appr)),
                      "exc_id": escape_formula(str(exc))}
            try:
                fields.update(identity.sign(signer, stored, env))
            except identity.IdentityError as e:
                raise ApprovalError(f"accepting drift in {name}: {e}") from None
        return _append_event(data_dir, "baseline", now=now, **fields)


def _baseline_register(data_dir, actor, reason, approver, self_approved, exc_id, now, approver_id, env) -> dict:
    """EQ-C-0106: every licences.csv baseline (the first one, and accepting drift) is Sam's sign-off: approver Sam
    (four-eyes) or Sam self-approved under an EXC listed in issues-log.md, signed with Sam's key (--as) once one is
    enrolled. The register must pass Team A's validator; its bytes are kept as the approved register."""
    from . import identity
    from . import licence_gov as G
    from ..presentation.research import DECISION_OWNER
    target = Path(data_dir) / LICENCE_REGISTER
    if target.is_symlink() or not target.is_file():
        raise ApprovalError(f"data/{LICENCE_REGISTER} is missing or not a regular file")
    with _locked(data_dir):
        rows = _require_chain(data_dir)
        data = target.read_bytes()
        cur = sha256_bytes(data)
        try:
            G.parse(data, f"data/{LICENCE_REGISTER}")
        except G.LicenceGovError as e:
            raise ApprovalError(f"baselining {LICENCE_REGISTER}: the register is invalid, refusing: {e}") from None
        prev = _last_applied(rows, LICENCE_REGISTER)
        if prev is not None and prev.get("file_sha256") == cur:
            raise ApprovalError(f"{LICENCE_REGISTER} already matches the last applied sha256; nothing to baseline")
        what = f"{'accepting drift in' if prev else 'first baseline of'} {LICENCE_REGISTER}"
        try:                                           # SEC-C-018 M2 (EQ-C-0109): enforced four-eyes applies here too
            reg = identity.governed_registry(data_dir)
            on = identity.enforced(reg)
            if on:
                approver, _ = identity.resolve_approver(data_dir, {"author": actor}, approver, approver_id,
                                                        self_approved, exc_id, now, reg=reg)
        except identity.IdentityError as e:
            raise ApprovalError(f"{what}: {e}") from None
        _, appr, flag, exc = _signoff(actor, approver, self_approved, exc_id, what)
        if person_key(appr) != person_key(DECISION_OWNER):
            raise ApprovalError(f"{what}: the approved licence register is {DECISION_OWNER}'s sign-off (R44): "
                                f"--approver {DECISION_OWNER}, or --actor {DECISION_OWNER} --self-approved with a named "
                                f"--exc EXC-nnn; got approver {appr!r}. Command: {G.FIRST_BASELINE_CMD}")
        if flag == "yes" and exc_logged(data_dir, exc) is not True:
            raise ApprovalError(f"{what}: {exc} is not a row of docs/governance/issues-log.md (a named exception is needed)")
        fields = dict(file=LICENCE_REGISTER, tier="1", actor=actor, approver=appr, self_approved=flag, exc_id=exc,
                      base_sha256=(prev or {}).get("file_sha256", ""), new_sha256=cur, file_sha256=cur, note=reason)
        try:
            owner = identity.owner_user(data_dir, DECISION_OWNER)
        except identity.IdentityError as e:
            raise ApprovalError(f"{what}: {e}") from None
        if owner is None and on:                       # SEC-C-018 M2: under enforcement a typed name is not a sign-off
            raise ApprovalError(f"{what}: four-eyes is enforced (users.json): {DECISION_OWNER} needs an enrolled key in "
                                "the governed users.json and signs this baseline with --as")
        if owner is not None:                          # Sam has an enrolled key: the baseline carries his signature
            if approver_id != owner["id"]:
                raise ApprovalError(f"{what}: {DECISION_OWNER} has an enrolled key: baseline with --as {owner['id']}")
            stored = {**fields, "event": "baseline", "id": "", "approver": escape_formula(str(appr)),
                      "exc_id": escape_formula(str(exc))}
            try:
                fields.update(identity.sign(owner, stored, env))
            except identity.IdentityError as e:
                raise ApprovalError(f"{what}: {e}") from None
        elif approver_id:
            raise ApprovalError(f"{what}: --as {approver_id}: {DECISION_OWNER} has no enrolled key in the governed users.json")
        row = _append_event(data_dir, "baseline", now=now, **fields)
        G.save_snapshot(data_dir, data)
        return row


def list_changes(data_dir, status: str | None = None) -> list[dict]:
    """One summary row per proposal, oldest first: id, file, tier, author, created_utc, status, changes, reason."""
    rows = read_log(data_dir)
    out = []
    for cid, evs in _events_by_id(rows).items():
        p0 = next((e for e in evs if e["event"] == "propose"), None)
        if p0 is None:
            continue
        st = _status(evs)
        if status and st != status:
            continue
        try:
            n = len(load_proposal(data_dir, cid)["diff"])
        except (ApprovalError, OSError, ValueError, KeyError):
            n = None
        out.append({"id": cid, "file": p0["file"], "tier": p0["tier"], "author": p0["actor"],
                    "created_utc": p0["ts_utc"], "status": st, "changes": n, "reason": p0["note"]})
    return out


def show(data_dir, change_id) -> dict:
    """The proposal (without new_text) with its status and events."""
    change_id = _check_id(change_id)
    prop = load_proposal(data_dir, change_id)
    evs = _events_by_id(read_log(data_dir)).get(change_id, [])
    out = {k: v for k, v in prop.items() if k != "new_text"}
    out["status"] = _status(evs)
    out["events"] = [{k: e.get(k, "") for k in ("seq", "ts_utc", "event", "actor", "approver", "self_approved",
                                                "exc_id", "file_sha256", "note")} for e in evs]
    return out


def _file_state(data_dir, rows, name: str) -> dict:
    cur = file_sha256(Path(data_dir) / name)
    last = _last_applied(rows, name)
    exp = (last or {}).get("file_sha256") or None
    st = ("default" if name in OPTIONAL_FILES and exp is None else "missing") if cur is None else \
        ("no_baseline" if exp is None else ("ok" if cur == exp else "drift"))
    return {"file": name, "status": st, "current_sha256": cur, "approved_sha256": exp,
            "last_event": (last or {}).get("event", ""), "last_id": (last or {}).get("id", ""),
            "last_ts_utc": (last or {}).get("ts_utc", "")}


def file_status(data_dir, file) -> dict:
    """detect_unapproved for one governed file, plus "chain_ok"; a log that does not verify gives chain_ok False."""
    name = _file_name(file)
    v = verify_chain(data_dir)
    try:
        rows = read_log(data_dir)
    except ApprovalError:
        rows = []
    return {**_file_state(data_dir, rows, name), "chain_ok": v["ok"], "chain_errors": v["errors"][:5]}


def detect_unapproved(data_dir) -> dict:
    """Drift check for health/governance: per governed file, current sha256 vs the last one applied or baselined
    through this tool. Status ok, drift (edited outside the tool), no_baseline (tool never used on it), missing, or
    default (an optional file, compliance.json, absent and never applied: the built-in default applies).
    Returns {"ok": no drift and chain verifies, "chain_ok", "files": [...]}."""
    v = verify_chain(data_dir)
    try:
        rows = read_log(data_dir)
    except ApprovalError:
        rows = []
    files = [_file_state(data_dir, rows, name) for name in FILES]
    return {"ok": v["ok"] and not any(f["status"] in ("drift", "missing") for f in files), "chain_ok": v["ok"],
            "files": files}
