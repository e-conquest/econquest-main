"""Calendar-gated formal tests as a scheduled job (EQ-C-0095): the `calendar_tests` job (schedule.py, daily 08:30 New
York) checks every test that only becomes possible with calendar time, and says so on the readiness page.

    python -m econquest.ops.calendar_jobs run    --home <home> --as-of YYYY-MM-DD   (the job; writes and alerts)
    python -m econquest.ops.calendar_jobs status --home <home> [--as-of YYYY-MM-DD] [--json]   (read only)

Tests (TESTS; formal dates from docs/validation/forecast-record.md, gates from Team B's evidence monitor EQ-B-0061):

    var_backtest_250d   250-day VaR99 backtest: Kupiec, Christoffersen, Acerbi-Szekely Z2, Basel zone     2027-07-14
    benchmark_12m       12-month PD benchmark scoring: Brier, log loss, AUC per source                     2027-10-23
    idea_quarters_4q    trade-idea hit rate over four quarters of daily marks                              2027-10-23

Every day the job runs the cheap progress check only (validation.evidence_monitor.evidence_table: "143 of 250 tested
days"). Before the formal date the status is "not_due" ("not due, N days left") and no formal test runs. From the
formal date the job calls Team B's entry point validation.calendar_tests.formal_verdicts(as_of, data_dir, out_dir)
(EQ-B-0091, HO-20261025-C-B-001), at most once per run:

    overdue      the grace window has ended but the evidence monitor does not say "testable" (the record or marks
                 stopped), or formal_verdicts says the VaR gate passed without 250 clean days
    passed       formal_verdicts gave "pass" (VaR: Kupiec, Christoffersen cc, Z2, McNeil-Frey all >= 0.05)
    failed       formal_verdicts gave "fail"
    review       formal_verdicts gave "review": the PD benchmark and the idea quarters always do, because their
                 pass/fail rule is a Tier 1 choice Sam has not made; Sam reviews the scores
    due          the date has arrived and the evidence is there, but the entry point gave no verdict for the test,
                 still says "gated", or raised: Sam is told it is due

Grace window (RF-3, lead decision EQ-C-0147): the 08:30 run on a formal date cannot see that day's row (it is written
that evening or later), and a formal date can fall on a weekend. So on the formal date and for the next GRACE_WEEKDAYS
(3) weekdays, counted from the first weekday on or after the formal date (2027-10-23, a Saturday, counts from Monday
10-25 and ends Thursday 10-28; 2027-07-14 ends Monday 07-19), a test whose data is not yet complete is "due" with
"grace": true, not "overdue". A grace "due" is a row in alerts.json but not a new alert: it never makes the job exit 2
and sends no email. The day after the window the same test becomes "overdue", which is a new alert (exit 2).

Fallback: if formal_verdicts cannot be imported, the job reads Team B's forecast_scorecard sections as EQ-C-0095 did
(var_formal Pass/Fail, pd_formal "review", ideas "due"). Every row and the state file say which path ran
("formal_path": "formal_verdicts" or "forecast_scorecard"). No statistic is computed here.

Alert path (the same as ops/monitor.py): every test that is overdue, due, review or failed is a row of kind
"calendar_<test>" in outputs/alerts.json (the previous calendar_ rows are replaced, the run's and the monitor's rows
stay); a status change into one of those (a grace "due" excepted), and every failed test, makes the job exit 2, which health.py reports as
the step code "calendar_test_alert". A failed test opens an incident (ops/incidents.py, S2, actor "calendar_tests
job") once per failure: the job first looks for an open incident from this actor for the same test in the incident
log itself, so a lost or malformed outputs/calendar_tests.json never opens a duplicate (SEC-C-016 L5). Email follows data/resilience.json routing.email and is only ever a dry run:
outputs/logs/calendar-alert-email-dryrun.json, written on a status change only; nothing is sent.

State: outputs/calendar_tests.json (the latest statuses, and per test the status, since when and the incident id).
Exit codes: 0 nothing new, 2 a new alert or a failed test, 1 error. Tier 3: no reported number reads this.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import sys
from pathlib import Path

JOB = "calendar_tests"
STATE_NAME = "calendar_tests.json"
DRYRUN_NAME = "calendar-alert-email-dryrun.json"
ALERT_PREFIX = "calendar_"
ACTOR = "calendar_tests job"
EXIT_ALERT = 2
GRACE_WEEKDAYS = 3                         # RF-3: weekdays of grace after the first weekday on or after the formal date

# test id -> evidence-monitor row, formal date, title, the Team B forecast_scorecard section read only on the fallback
# path (None: no scorecard section), and where the method is written up. formal_verdicts uses the same ids and dates.
TESTS: dict[str, dict] = {
    "var_backtest_250d": {"evidence": "var_record_250d", "formal_date": "2027-07-14", "section": "var_formal",
                          "title": "250-day VaR99 backtest (Kupiec, Christoffersen, Z2, Basel zone)",
                          "doc": "docs/validation/forecast-record.md"},
    "benchmark_12m": {"evidence": "benchmark_12m", "formal_date": "2027-10-23", "section": "pd_formal",
                      "title": "12-month PD benchmark scoring (Brier, log loss, AUC)", "doc": "docs/validation/benchmarks.md"},
    "idea_quarters_4q": {"evidence": "idea_quarters_4q", "formal_date": "2027-10-23", "section": None,
                         "title": "Trade-idea hit rate over four quarters", "doc": "docs/validation/signals-trades.md"},
}
STATUSES = ("not_due", "overdue", "due", "review", "passed", "failed")
ALERTING = ("overdue", "due", "review", "failed")
SEVERITY = {"failed": "critical", "overdue": "warning", "due": "warning", "review": "warning"}
STATUS_TEXT = {"not_due": "not due", "overdue": "overdue", "due": "due", "review": "ran, review",
               "passed": "passed", "failed": "failed"}
PATH_VERDICTS = "formal_verdicts"          # Team B's validation.calendar_tests.formal_verdicts (EQ-B-0091)
PATH_SCORECARD = "forecast_scorecard"      # fallback: forecast_scorecard section rows (EQ-C-0095)


def _date(v) -> dt.date:
    if isinstance(v, dt.datetime):
        return v.date()
    if isinstance(v, dt.date):
        return v
    if not v or not isinstance(v, str):
        raise ValueError("as_of is required (YYYY-MM-DD)")
    return dt.date.fromisoformat(v.strip()[:10])


def _iso(t: dt.datetime) -> str:
    return t.astimezone(dt.timezone.utc).isoformat(timespec="seconds")


def _int(v):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    return None if f != f else int(f)


def grace_end(formal_date) -> dt.date:
    """Last day of the grace window: the first weekday on or after the formal date, plus GRACE_WEEKDAYS weekdays."""
    d = _date(formal_date)
    while d.weekday() >= 5:
        d += dt.timedelta(days=1)
    n = 0
    while n < GRACE_WEEKDAYS:
        d += dt.timedelta(days=1)
        n += d.weekday() < 5
    return d


def progress_text(ev: dict) -> str:
    """"143 of 250 tested days recorded" from an evidence-monitor row."""
    if not ev:
        return "progress unknown (no evidence-monitor row)"
    return f"{_int(ev.get('progress'))} of {_int(ev.get('required'))} {ev.get('unit')} recorded"


def _verdict_outcome(tid: str, verdicts: list[dict]) -> tuple[str, str]:
    """Status and detail from formal_verdicts' {"test", "status", "detail", "n"} dicts."""
    v = next((d for d in verdicts if isinstance(d, dict) and d.get("test") == tid), None)
    if v is None:
        return "due", "formal_verdicts gave no verdict for this test"
    st, detail, n = str(v.get("status") or ""), str(v.get("detail") or "")[:400], _int(v.get("n"))
    if st == "pass":
        return "passed", f"verdict Pass on {n}: {detail}"
    if st == "fail":
        return "failed", f"verdict Fail on {n}: {detail}"
    if st == "review" and tid == "var_backtest_250d":
        return "overdue", f"gate passed but the data is short (n {n}): {detail}"
    if st == "review":
        return "review", f"Sam reviews, no pass/fail rule set (Tier 1, Sam's call): {detail}"
    if st == "gated":
        return "due", f"Team B's gate still says not due: {detail}"
    return "due", f"formal_verdicts status {st[:40]!r} not understood: {detail}"


def _formal_outcome(test: dict, rows: list[dict]) -> tuple[str, str]:
    """Fallback: status and detail from Team B's formal section rows (forecast_scorecard SCORECARD_COLUMNS)."""
    if test["section"] is None:
        return "due", (f"no formal entry point on the fallback path (formal_verdicts not importable); review it by hand "
                       f"({test['doc']})")
    sec = [r for r in rows if r.get("section") == test["section"] and r.get("status") != "gated"]
    if not sec:
        return "due", "the formal section gave no result rows; run the forecast scorecard and check its gate rows"
    if test["section"] == "var_formal":
        verdicts = {str(r.get("status")) for r in sec if r.get("metric") != "basel_zone"}
        zone = next((str(r.get("status")) for r in sec if r.get("metric") == "basel_zone"), "")
        vals = ", ".join(f"{r['metric']} {float(r['value']):.3f}" for r in sec
                         if r.get("metric") != "basel_zone" and _int(r.get("value")) is not None)
        n = next((_int(r.get("n")) for r in sec), None)
        verdict = "Fail" if "Fail" in verdicts else ("Pass" if verdicts == {"Pass"} else "")
        if not verdict:
            return "due", f"formal VaR rows without a Pass/Fail verdict ({', '.join(sorted(verdicts))})"
        return ("passed" if verdict == "Pass" else "failed"), f"verdict {verdict} on {n} days; {vals}; Basel zone {zone}"
    scored = [r for r in sec if str(r.get("status")) == "scored"]
    if not scored:
        return "due", "formal scores not scorable yet: " + "; ".join(sorted({str(r.get('status')) for r in sec}))[:200]
    body = "; ".join(f"{r['item']} Brier {float(r['value']):.4f} (n {_int(r.get('n'))})" for r in scored
                     if _int(r.get("value")) is not None)
    return "review", f"scored, no pass/fail rule from Team B yet: {body}"


def evaluate(as_of, evidence_rows: dict[str, dict], formal_rows=None, tests: dict | None = None) -> list[dict]:
    """One status row per test. `evidence_rows` maps evidence-monitor row names to rows (evidence_table records).
    `formal_rows`: None (do not run formal tests: read-only callers) or a callable, called at most once and only when a
    test is due, returning (path, rows): PATH_VERDICTS with formal_verdicts dicts, or PATH_SCORECARD with forecast
    scorecard rows. A plain list is read as scorecard rows. Pure apart from that callable."""
    t = _date(as_of)
    tests = tests or TESTS
    cache: dict = {}
    out = []
    for tid, test in tests.items():
        ev = evidence_rows.get(test["evidence"]) or {}
        fd = _date(test["formal_date"])
        days_left = (fd - t).days
        ge = grace_end(fd)
        in_grace = days_left <= 0 and t <= ge
        grace_note = f"; grace to {ge} while the data completes (overdue from {ge + dt.timedelta(days=1)})"
        prog = progress_text(ev)
        ev_status = ev.get("status") or "unknown"
        row = {"test": tid, "title": test["title"], "evidence": test["evidence"], "formal_date": fd.isoformat(),
               "days_left": days_left, "progress": _int(ev.get("progress")), "required": _int(ev.get("required")),
               "unit": ev.get("unit"), "progress_text": prog, "evidence_status": ev_status,
               "earliest_test_date": ev.get("earliest_test_date") or "", "doc": test["doc"], "result": "",
               "grace_end": ge.isoformat(), "grace": False}
        if days_left > 0:
            st = "not_due"
            text = f"not due, {days_left} days left ({prog}; formal from {fd})"
            if ev_status == "testable":
                text += "; the evidence is already testable, the monthly forecast scorecard reports it"
        elif ev_status != "testable" and in_grace:
            st, row["grace"] = "due", True
            text = (f"due since {fd}, data not yet complete: {prog}, evidence monitor says {ev_status}{grace_note}")
        elif ev_status != "testable":
            st = "overdue"
            text = (f"formal date {fd} has arrived but the evidence is short: {prog}, evidence monitor says {ev_status}"
                    f" (earliest test date {row['earliest_test_date'] or 'unknown'})")
        elif formal_rows is None:
            st = "due"
            text = f"due since {fd}: {prog}; the {JOB} job runs the formal test"
        else:
            if "rows" not in cache:
                got = formal_rows()
                cache["path"], cache["rows"] = got if isinstance(got, tuple) else (PATH_SCORECARD, got)
                cache["rows"] = list(cache["rows"] or [])
            if cache["path"] == PATH_VERDICTS:
                st, res = _verdict_outcome(tid, cache["rows"])
            elif cache["path"] == PATH_SCORECARD:
                st, res = _formal_outcome(test, cache["rows"])
            else:
                st, res = "due", f"the formal test did not run: {cache['path']}"
            if st == "overdue" and in_grace:             # gate passed but the data is short: still in grace
                st, row["grace"], res = "due", True, res + grace_note
            row["result"], row["formal_path"] = res, cache["path"]
            text = f"formal test ran on {t} ({cache['path']}): {res}" if st != "due" else f"due since {fd}: {res}"
        out.append(row | {"status": st, "status_text": STATUS_TEXT[st], "text": text})
    return out


def _evidence_rows(as_of, data_dir, out_dir) -> dict[str, dict]:
    from ..validation import evidence_monitor as EM
    table = EM.evidence_monitor(_date(as_of).isoformat(), data_dir=data_dir, out_dir=out_dir)
    return {r["evidence"]: r for r in table.to_dict(orient="records")}


def _scorecard_rows(as_of, data_dir, out_dir):
    def fn():
        from ..validation.forecast_scorecard import scorecard_from_files
        return PATH_SCORECARD, scorecard_from_files(_date(as_of).isoformat(), data_dir, out_dir).to_dict(orient="records")
    return fn


def _formal_source(as_of, data_dir, out_dir, log=print):
    """The formal-result callable for `evaluate`: Team B's formal_verdicts; the scorecard rows only if it cannot be
    imported. A formal_verdicts error is not a fallback: it is reported as "due" with the error type."""
    def fn():
        try:
            from ..validation.calendar_tests import formal_verdicts
        except ImportError as e:                         # incl. the name missing from the module
            log(f"[calendar] formal_verdicts not importable ({type(e).__name__}); fallback {PATH_SCORECARD}")
            return _scorecard_rows(as_of, data_dir, out_dir)()
        try:
            return PATH_VERDICTS, formal_verdicts(_date(as_of).isoformat(), data_dir=str(data_dir), out_dir=str(out_dir))
        except Exception as e:                           # noqa: BLE001 - alerts as due; never a silent pass
            return f"{PATH_VERDICTS} raised {type(e).__name__}; run python -m econquest.validation.calendar_tests " \
                   f"--as-of {_date(as_of).isoformat()} by hand", []
    return fn


def _open_incident(out_dir, tid: str, log=print) -> str | None:
    """Id of the newest open incident this job opened for test `tid`, from the incident log itself (SEC-C-016 L5)."""
    from . import incidents
    try:
        found = incidents.incidents(out_dir)
    except Exception as e:                               # noqa: BLE001 - fall back to the state file's id
        log(f"[calendar] incident log not readable ({type(e).__name__}); using the state file only")
        return None
    mark = f"calendar test {tid} failed"
    for iid, inc in reversed(list(found.items())):
        first = (inc.get("entries") or [{}])[0]
        if not inc.get("closed") and first.get("actor") == ACTOR and str(first.get("summary") or "").startswith(mark):
            return iid
    return None


def load_state(out_dir) -> dict:
    p = Path(out_dir) / STATE_NAME
    try:
        d = json.loads(p.read_text())
        return d if isinstance(d, dict) else {}
    except (OSError, json.JSONDecodeError):
        return {}


def alert_rows(rows: list[dict]) -> list[dict]:
    """alerts.json rows (the shape monitor._alerts writes) for every alerting test."""
    return [{"severity": SEVERITY[r["status"]], "kind": ALERT_PREFIX + r["test"], "scope": "validation", "country": None,
             "message": f"{r['title']}: {r['text']}", "value": r["status"], "threshold": r["formal_date"]}
            for r in rows if r["status"] in ALERTING]


def _email_dry_run(changed: list[dict], cfg: dict, out_dir: Path, now: dt.datetime) -> str:
    em = cfg["routing"]["email"]
    if not em["enabled"]:
        return "off"
    if not changed:
        return "nothing new to send"
    if any(r["status"] == "failed" for r in changed):
        level = "FAIL"
    else:
        level = "WARN"
    if level == "WARN" and em["min_status"] == "FAIL":
        return f"nothing to send (WARN only, min_status {em['min_status']})"
    if not em["dry_run"]:
        return ("refused: live alert email is not enabled in this build (dry_run must stay true; sending is Sam's "
                "decision, through econquest distribute)")
    if not em["to"]:
        return "dry run: no recipients in routing.email.to"
    from ..validation.alerts import digest
    from .distribute import header_safe
    alerts = alert_rows(changed)
    msg = {"generated_at": _iso(now), "dry_run": True, "to": em["to"], "sent": False,
           "subject": header_safe(f"EconQuest calendar tests: {len(alerts)} new ({level})", "subject"),
           "body": digest(alerts, "calendar-tests")}
    logs = out_dir / "logs"; logs.mkdir(parents=True, exist_ok=True)
    (logs / DRYRUN_NAME).write_text(json.dumps(msg, indent=1))
    return f"dry run: would email {len(em['to'])} recipient(s); message in {logs / DRYRUN_NAME} (nothing sent)"


def run(home, as_of, now: dt.datetime | None = None, log=print, formal_rows=None, evidence_rows: dict | None = None,
        interim_report_fn=None) -> dict:
    """The scheduled job: evaluate, route alerts, write outputs/calendar_tests.json. Returns the report with "exit".
    Also refreshes Team B's INTERIM report and raises the monthly interim alert (ops/interim_backtest.job_step, EQ-C-0118;
    `interim_report_fn` replaces Team B's interim_report in tests); that alert never changes the exit code."""
    from . import incidents
    from .monitor import load_resilience, merge_alerts_json
    home = Path(home)
    data_dir, out_dir = home / "data", home / "outputs"
    now = (now or dt.datetime.now(dt.timezone.utc)).astimezone(dt.timezone.utc)
    a = _date(as_of).isoformat()
    ev = evidence_rows if evidence_rows is not None else _evidence_rows(a, data_dir, out_dir)
    rows = evaluate(a, ev, formal_rows or _formal_source(a, data_dir, out_dir, log))
    prev = load_state(out_dir).get("history")
    prev = prev if isinstance(prev, dict) else {}       # a malformed history is treated as lost (SEC-C-016 L5)
    history, changed = {}, []
    for r in rows:
        p = prev.get(r["test"])
        p = p if isinstance(p, dict) else {}
        same = p.get("status") == r["status"] and bool(p.get("grace")) == bool(r.get("grace"))
        h = {"status": r["status"], "since": p.get("since") if same and p.get("since") else a,
             "incident_id": p.get("incident_id") if same else None, "grace": bool(r.get("grace"))}
        if not same and r["status"] in ALERTING and not r.get("grace"):     # a grace "due" is never a new alert
            changed.append(r)
        if r["status"] == "failed":
            h["incident_id"] = _open_incident(out_dir, r["test"], log) or h["incident_id"]
        if r["status"] == "failed" and not h["incident_id"]:
            try:
                e = incidents.log_entry(out_dir, "detect", f"calendar test {r['test']} failed on {a}: {r['result']}"[:500],
                                        ACTOR, severity="S2", now=now)
                h["incident_id"] = e["args"]["incident_id"]
            except Exception as e:                       # noqa: BLE001 - the alert row still carries the failure
                log(f"[calendar] incident not opened ({type(e).__name__}); the alert row stands")
        r["since"] = h["since"]; r["incident_id"] = h["incident_id"]
        history[r["test"]] = h
    cfg = load_resilience(data_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    routing = {"local": [str(out_dir / STATE_NAME)]}
    if cfg["routing"]["local"]["alerts_json"]:
        routing["local"].append(merge_alerts_json(out_dir, alert_rows(rows), now, prefix=ALERT_PREFIX))
    routing["email"] = _email_dry_run(changed, cfg, out_dir, now)
    try:                                                 # EQ-C-0118: INTERIM report refresh + monthly interim alert
        from .interim_backtest import job_step
        interim = job_step(home, a, now, log, report_fn=interim_report_fn,
                           alerts_json=bool(cfg["routing"]["local"]["alerts_json"]))
    except Exception as e:                               # noqa: BLE001 - never breaks the formal job
        interim = {"new": False, "message": f"interim step failed ({type(e).__name__})"}
    code = EXIT_ALERT if changed or any(r["status"] == "failed" for r in rows) else 0
    paths = sorted({r["formal_path"] for r in rows if r.get("formal_path")})
    rep = {"generated_at": _iso(now), "as_of": a, "job": JOB, "formal_path": ", ".join(paths) or None,
           "tests": rows, "history": history,
           "new_alerts": [r["test"] for r in changed], "routing": routing, "interim_alert": interim, "exit": code}
    p = out_dir / STATE_NAME
    tmp = p.with_name("." + STATE_NAME + ".tmp"); tmp.write_text(json.dumps(rep, indent=1, default=str)); tmp.replace(p)
    for r in rows:
        log(f"[calendar] {r['test']:<18} {r['status_text']:<11} {r['text']}")
    log(f"[calendar] formal path: {rep['formal_path'] or 'none (no test due)'}; new alerts: "
        f"{', '.join(rep['new_alerts']) or 'none'}; email: {routing['email']}")
    return rep


def page_status(data_dir, out_dir, as_of=None) -> dict:
    """Read-only payload for the readiness page and open items: today's statuses from the evidence monitor (no formal
    run), with the formal result of the job's last run on the same as_of when there is one. Never writes."""
    from ..presentation.evidence_view import default_as_of
    a = default_as_of(data_dir, as_of)
    base = {"as_of": a, "job": JOB, "command": f"python -m econquest.ops.calendar_jobs status --as-of {a}"}
    try:
        rows = evaluate(a, _evidence_rows(a, data_dir, out_dir), None)
    except Exception as e:                               # noqa: BLE001 - shown as unknown, never a path
        return base | {"status": "unknown", "rows": [], "message": f"Calendar tests could not be read ({type(e).__name__})."}
    st = load_state(out_dir)
    last = {r.get("test"): r for r in st.get("tests") or [] if isinstance(r, dict)}
    for r in rows:
        lr = last.get(r["test"]) or {}
        if st.get("as_of") == a and r["status"] == "due" and lr.get("status") in ("passed", "failed", "review", "due",
                                                                                  "overdue"):
            r.update({k: lr.get(k) for k in ("status", "status_text", "text", "result", "formal_path")})
        r["incident_id"] = ((st.get("history") or {}).get(r["test"]) or {}).get("incident_id")
    job = {}
    try:
        from .jobs import last_runs
        lj = last_runs(Path(out_dir).parent).get(JOB) or {}
        job = {"last_status": lj.get("status"), "last_exit": lj.get("exit_code"), "last_end": lj.get("ended_at")}
    except Exception:                                    # noqa: BLE001
        job = {}
    n = {s: sum(1 for r in rows if r["status"] == s) for s in STATUSES}
    msg = f"{len(rows)} calendar-gated formal tests as of {a}: " + ", ".join(
        f"{n[s]} {STATUS_TEXT[s]}" for s in STATUSES if n[s]) + "."
    return base | {"status": "open" if any(r["status"] in ALERTING for r in rows) else "clear", "rows": rows,
                   "counts": n, "message": msg, "last_job": job, "last_run_as_of": st.get("as_of")}


def status_text(p: dict) -> str:
    L = [p.get("message", "")]
    for r in p.get("rows") or []:
        L.append(f"  {r['test']:<18} {r['status_text']:<11} {r['text']}")
    j = p.get("last_job") or {}
    L.append(f"  job {JOB}: last run {j.get('last_status') or 'never'}" +
             (f", exit {j.get('last_exit')} at {j.get('last_end')}" if j.get("last_end") else ""))
    return "\n".join(L) + "\n"


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ops.calendar_jobs", description=__doc__.splitlines()[0])
    ap.add_argument("action", choices=["run", "status"])
    ap.add_argument("--home", default=os.environ.get("ECONQUEST_HOME", "."))
    ap.add_argument("--as-of", help="YYYY-MM-DD (run: required; status: default the settings as_of, else today)")
    ap.add_argument("--json", action="store_true")
    a = ap.parse_args(argv)
    home = Path(a.home)
    try:
        if a.action == "run":
            if not a.as_of:
                ap.error("run needs --as-of (the job passes {as_of})")
            rep = run(home, a.as_of, log=(lambda *_: None) if a.json else print)
            if a.json:
                print(json.dumps(rep, indent=1, default=str))
            return rep["exit"]
        p = page_status(home / "data", home / "outputs", a.as_of)
        print(json.dumps(p, indent=1, default=str) if a.json else status_text(p), end="" if not a.json else "\n")
        return 0
    except (OSError, ValueError) as e:
        print(f"[calendar] error: {type(e).__name__}: {e}", file=sys.stderr)
        return 1


if __name__ == "__main__":
    sys.exit(main())
