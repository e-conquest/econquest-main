"""`econquest first-pass` (EQ-C-0134): the first Mac pass of team/first-mac-pass.md, one step at a time, with a check
after each step and one upload bundle at the end.

    econquest first-pass                     # where you are: the steps checked so far and the next one in full
    econquest first-pass --status [--json]   # every step: pass / fail / skipped / not checked, as recorded
    econquest first-pass --next              # the next step: what to do, the exact command, how it is checked
    econquest first-pass --check STEP        # check one step (a number from section A, or `all`) and record it
    econquest first-pass --skip STEP --reason "..."   # leave out an optional step (tag optional only)
    econquest first-pass bundle [--dest DIR] [--no-backup]   # the one upload zip of what the teams asked for

The steps are read from team/first-mac-pass.md on disk (the program lead's file; this module never writes it): the
install's copy first, then this source tree's. Each row of its section A table is matched to a check by a phrase that
must still appear in the row (CHECKS below). A row the phrase no longer matches has no automatic check: it is shown as
"no check" and can be confirmed by hand with --check STEP --confirm.

Nothing here runs a step that changes data, approvals, the schedule or a credential. Those steps are printed for Sam
to run. Steps that only read (the zip's sha256, `econquest next`, the review ledger verify) are run by their own
check, because the check is the step. Every check reads only, through the existing commands' functions:
backup.verify and monitor.check_backup (backup --verify / health --daily), next_steps.collect (next),
licence_gov.state (change verify, R44), evidence.verify, ingestion.ledger.verify_ledger (review verify),
the review pending list (review list --pending), ledger.legacy_reset(dry_run=True), open_items.select_unattested,
schedule.check and the ops.json switch (schedule check), open_items.ucdp_token_state (presence only; the token is never
read) and crag_update's run records.

Progress is kept in <home>/first-pass.json (home = the install folder, the parent of --out): per step the result, the
UTC time and one-line reasons. It never holds a secret: reasons are scrubbed one-liners (no local paths, no values
from the environment), and the token check records presence only.

`bundle` writes <out>/first-pass/first-pass-<UTC stamp>.zip with exactly the files the teams asked for: the "send
back" of team/first-mac-pass.md step 15 and Team A's docs/runbooks/A-mac-pull-pack.md ("What to send back", the 0.6.0
order's section A and B lists, the WEO probe list) and A-landing-check.md part 1 (the newest nightly backup and its
manifest). FIRST-PASS-MANIFEST.json inside the zip (and next to it) lists every file with its sha256 and who asked for
it, every asked-for file that is missing, and every file left out and why. Left out always: credential files
(scripts/build_release.py SECRET_GLOBS, reused), symlinks, anything outside the install or the backup folder, a file
whose bytes hold a credential value from the environment or <home>/.ops.env (evidence.secret_values, reused), the
pull pack files when Team A's token check (A-landing-check.md: token|api_key|passw|secret|bearer) matches, and a backup
whose archive lists a credential file. The Keychain is never read.

Exit codes: 0 done (every step passed or skipped; bundle complete), 2 something left (a step not passed; a required
file missing from the bundle), 1 an error (no data folder, the doc not found, a bad step number).
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import os
import re
import sys
import tarfile
from pathlib import Path
from types import SimpleNamespace

from .next_steps import scrub

FORMAT = "econquest-first-pass/1"
BUNDLE_FORMAT = "econquest-first-pass-bundle/1"
STATE_NAME = "first-pass.json"
DOC = Path("team") / "first-mac-pass.md"
PACKAGE_ROOT = Path(__file__).resolve().parents[2]
MANIFEST_NAME = "FIRST-PASS-MANIFEST.json"
BUNDLE_TOP = "econquest-first-pass"
EXIT_DONE, EXIT_ERROR, EXIT_LEFT = 0, 1, 2
RESULTS = ("pass", "fail", "skipped", "confirmed")
MAX_SCAN = 64 * 2 ** 20                     # bytes read per file for the credential-value scan
# A-landing-check.md part 1: "grep -iE "token|api_?key|passw|secret|bearer" report.json state.json pullpack.log"
LANDING_TOKEN_RE = re.compile(rb"token|api_?key|passw|secret|bearer", re.I)
LANDING_TOKEN_FILES = ("data/live/pullpack/report.json", "data/live/pullpack/state.json", "data/live/pullpack/pullpack.log")
_RUN_DIR = re.compile(r"^\d{8}T\d{6}Z(?:-\d+)?$")
_DATE_DIR = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_SHA_RE = re.compile(r"\b[0-9a-f]{64}\b")
_VERSION_RE = re.compile(r"^# .*?\b(\d+\.\d+\.\d+)\b", re.M)


def _now(now=None) -> str:
    return (now or dt.datetime.now(dt.timezone.utc)).strftime("%Y-%m-%dT%H:%M:%SZ")


def _sha_file(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _quiet(*_a, **_k) -> None:
    return None


# ---------------------------------------------------------------- the doc
class DocError(Exception):
    pass


def find_doc(home: Path) -> Path:
    for root in (Path(home), PACKAGE_ROOT):
        p = root / DOC
        if p.is_file():
            return p
    raise DocError(f"{DOC.as_posix()} not found in the install or the source tree")


def _cells(line: str) -> list[str]:
    parts = [c.strip() for c in line.strip().strip("|").split("|")]
    if len(parts) < 4:
        return []
    return [parts[0], parts[1], "|".join(parts[2:-1]).strip(), parts[-1]]


def parse_doc(text: str) -> dict:
    """{"version", "steps": [{"n", "what", "command", "tags", "optional"}]} from section A's table."""
    m = re.search(r"^## A\..*?$(.*?)(?=^## |\Z)", text, re.M | re.S)
    if not m:
        raise DocError("first-mac-pass.md has no '## A.' steps section")
    steps = []
    for line in m.group(1).splitlines():
        c = _cells(line) if line.lstrip().startswith("|") else []
        if not c or not c[0].isdigit():
            continue
        tags = [t.strip() for t in c[3].replace("*", "").split(",") if t.strip()]
        steps.append({"n": int(c[0]), "what": c[1], "command": c[2], "tags": tags, "optional": tags == ["optional"]})
    if not steps:
        raise DocError("first-mac-pass.md section A has no numbered steps")
    v = _VERSION_RE.search(text)
    return {"version": v.group(1) if v else "", "steps": steps}


def load_doc(home: Path) -> dict:
    p = find_doc(home)
    raw = p.read_bytes()
    doc = parse_doc(raw.decode("utf-8"))
    doc.update(sha256=hashlib.sha256(raw).hexdigest(), path=p)
    for s in doc["steps"]:
        spec = match_check(s)
        s.update(check=spec["name"] if spec else None, runs_itself=bool(spec and spec["read_only"]),
                 how=spec["how"] if spec else "no automatic check for this row (the doc changed): confirm it by hand")
    return doc


# ---------------------------------------------------------------- context
class Ctx:
    """What a check reads. home = install folder; user_home = the person's home (Downloads, backups, LaunchAgents)."""

    def __init__(self, data_dir, out_dir, home, env=None, user_home=None, now=None, zip_path=None, launch_agents=None):
        self.d = Path(data_dir)
        self.out = Path(out_dir)
        self.home = Path(home)
        self.env = dict(os.environ if env is None else env)
        self.user_home = Path(user_home or Path.home())
        self.now = now or dt.datetime.now(dt.timezone.utc)
        self.zip = Path(zip_path).expanduser() if zip_path else self.user_home / "Downloads" / "econquest-macos.zip"
        self.launch_agents = Path(launch_agents) if launch_agents else self.user_home / "Library" / "LaunchAgents"
        self.doc = None
        self.state = None

    def backup_dest(self) -> Path:
        return Path(self.env.get("ECONQUEST_BACKUP_DEST") or self.user_home / "econquest-backups" / "nightly").expanduser()


def _r(ok: bool, *detail) -> dict:
    return {"result": "pass" if ok else "fail", "detail": [str(d) for d in detail if d]}


# ---------------------------------------------------------------- checks (each reads only)
def check_zip(c: Ctx, step: dict) -> dict:
    want = _SHA_RE.findall(step["command"])
    if not want:
        return _r(False, "the doc's step gives no sha256 to compare with")
    if not c.zip.is_file():
        return _r(False, f"{c.zip.name} not found in Downloads (or --zip PATH)")
    got = _sha_file(c.zip)
    return _r(got == want[0], f"sha256 {got[:12]}... " + ("matches the doc" if got == want[0] else
                                                          f"differs from the doc's {want[0][:12]}...: download it again"))


def check_install(c: Ctx, step: dict) -> dict:
    from .. import __version__
    from .install_check import MARKER, safe_warnings
    out, ok = [], True
    if not (c.home / MARKER).is_file():
        ok = False; out.append("no install marker: install.command has not run in this folder")
    if not (c.d / "countries.csv").is_file():
        ok = False; out.append("no data/countries.csv in the install")
    want = (c.doc or {}).get("version") or ""
    if want and want != __version__:
        ok = False; out.append(f"installed {__version__}, the doc is for {want}")
    else:
        out.append(f"econquest {__version__} installed")
    for w in safe_warnings(c.d, env=c.env, user_home=c.user_home):
        if w["id"] == "no_backup":
            out.append("no backup yet (step 3 checks it)")
        else:
            ok = False; out.append(w["message"])
    return _r(ok, *out)


def check_backup(c: Ctx, step: dict) -> dict:
    from . import backup as B
    from .monitor import check_backup as mon_backup, load_resilience
    try:
        cfg = load_resilience(c.d)
    except Exception as e:                               # noqa: BLE001 - a bad resilience file is a failed check
        return _r(False, f"data/resilience.json unreadable ({type(e).__name__})")
    line = mon_backup(c.backup_dest(), c.now, cfg)
    if line["status"] == "FAIL" or not line.get("archive"):
        return _r(False, f"health: {line['detail']}")
    v = B.verify(line["archive"], log=_quiet)
    return _r(v["ok"] and line["status"] == "OK", f"health: backup {line['status']}, {line['detail']}",
              f"backup verify: {'ok' if v['ok'] else 'FAILED: ' + '; '.join(v['errors'][:2])}")


def check_next(c: Ctx, step: dict) -> dict:
    from .next_steps import collect
    rep = collect(c.d, c.out, env=c.env, home=c.user_home, now=c.now)
    nxt = f"next is step {rep['next']}" if rep["next"] else ("waiting: " + "; ".join(rep["waiting"]) if rep["waiting"]
                                                             else "all done")
    return _r(True, f"econquest next: {rep['done']} of {rep['total']} pull steps done, {nxt} (step 12 runs them)")


def check_licence(c: Ctx, step: dict) -> dict:
    from .licence_gov import DEMO_STATE, problem, state
    st = state(c.d)
    if st["status"] == "ok":
        return _r(True, f"licence register approved (sha256 {str(st['approved_sha256'])[:12]}..., "
                        f"{st['last_event']} {st['last_ts_utc'][:19]})", "change verify: approvals chain ok")
    if st["status"] == DEMO_STATE:
        return _r(False, "only the DEMO baseline is open (not Sam's approval): run the step's command")
    return _r(False, f"licence register {st['status']}: {problem(c.d, st)}")


def check_evidence(c: Ctx, step: dict) -> dict:
    from .evidence import DEMO_SUFFIX, verify
    zips = sorted(p for p in (c.out / "evidence").glob("evidence-*.zip") if not p.stem.endswith(DEMO_SUFFIX)) \
        if (c.out / "evidence").is_dir() else []
    if not zips:
        demo = (c.out / "evidence").is_dir() and any((c.out / "evidence").glob(f"evidence-*{DEMO_SUFFIX}.zip"))
        return _r(False, "no real evidence bundle yet" + (" (only a DEMO one, which is not Sam's approval)" if demo else ""))
    v = verify(zips[-1])
    return _r(bool(v.get("ok")), f"{zips[-1].name}: evidence verify " + ("ok" if v.get("ok") else
                                  "FAILED: " + "; ".join(str(e) for e in (v.get("errors") or [])[:2])))


def check_ledger(c: Ctx, step: dict) -> dict:
    from ..ingestion.ledger import verify_ledger
    v = verify_ledger(c.d)
    if not v["ok"]:
        return _r(False, "review verify: " + "; ".join(str(p) for p in v["problems"][:3]) + " (RESULT: not ok)")
    return _r(True, f"review verify: {v['rows']} rows ({v['chained']} chained, {v['legacy_unchained']} legacy unchained), "
                    "RESULT: ok" if v.get("exists") else "review verify: no review ledger yet, RESULT: ok")


def check_review(c: Ctx, step: dict) -> dict:
    from ..cli import _review_pending
    from ..ingestion.ledger import load_decisions, verify_ledger
    if not (c.d / "live" / "review.csv").is_file():
        return _r(False, "no data/live/review.csv: no fetch has run here yet")
    v = verify_ledger(c.d)
    if not v["ok"]:
        return _r(False, "the review ledger does not verify (step 7)")
    n = len(_review_pending(c.d, load_decisions(c.d), SimpleNamespace()))
    return _r(n == 0, "every held cell has a decision; finish with `econquest review apply`" if n == 0 else
              f"{n} held cell(s) still have no decision: econquest review list --pending")


def check_legacy(c: Ctx, step: dict) -> dict:
    from ..ingestion.ledger import legacy_reset
    n = len(legacy_reset(c.d, author="first-pass check", dry_run=True))
    return _r(n == 0, "no held cell rests on an imported legacy decision" if n == 0 else
              f"{n} held cell(s) still rest on an imported legacy decision (author unknown)")


def check_attest(c: Ctx, step: dict) -> dict:
    from .open_items import select_unattested
    n = len(select_unattested(c.d))
    return _r(n == 0, "every hand-entered cell is attested" if n == 0 else
              f"{n} hand-entered cell(s) not attested: econquest open-items")


def check_schedule(c: Ctx, step: dict) -> dict:
    from . import schedule as S
    try:
        cfg = S.load_config(c.home)
    except (OSError, ValueError) as e:
        return _r(False, f"ops.json unreadable ({type(e).__name__})")
    on = S.record_apply_prices(cfg)
    rep = S.check(c.home, cfg, log=_quiet, launch_agents=c.launch_agents)
    n = rep["counts"]
    return _r(on and rep["status"] == "ok",
              "ops.json record_job_apply_prices is " + ("true" if on else "not true (set it to true)"),
              f"schedule check: {n['ok']} ok, {n['missing']} missing, {n['stale']} stale")


def check_pulls(c: Ctx, step: dict) -> dict:
    from .next_steps import collect
    rep = collect(c.d, c.out, env=c.env, home=c.user_home, now=c.now)
    panel = next((s for s in rep["steps"] if s["id"] == "panel"), {})
    probe = (c.home / "outputs" / "wb_probe" / "probes.json").is_file()
    report = (c.d / "live" / "pullpack" / "report.json").is_file()
    ok = panel.get("state") == "done" and probe and report
    return _r(ok, f"next: panel step {panel.get('state', 'unknown')}",
              "World Bank probe " + ("saved" if probe else "not saved (outputs/wb_probe/probes.json)"),
              "pull pack report " + ("saved" if report else "not saved (data/live/pullpack/report.json)"),
              f"econquest next: {rep['done']} of {rep['total']} done")


def check_ucdp(c: Ctx, step: dict) -> dict:
    from .open_items import ucdp_token_state
    tok = ucdp_token_state(c.d, env=c.env)              # presence only: the value is never read
    ged = c.d / "panel" / "research" / "ucdp_ged"
    files = sorted(ged.glob("*.csv")) if ged.is_dir() else []
    return _r(tok["configured"] and bool(files), "UCDP token " + ("configured" if tok["configured"] else
              "not found (Keychain item econquest-ucdp)"), f"{len(files)} UCDP GED CSV file(s) in data/panel/research/ucdp_ged/")


def check_crag(c: Ctx, step: dict) -> dict:
    runs = c.d / "panel" / "staging" / "crag" / "updates"
    seen = applied = 0
    for p in sorted(runs.glob("*/crag_update.json")) if runs.is_dir() else []:
        try:
            st = json.loads(p.read_text(encoding="utf-8")).get("status")
        except (OSError, ValueError, AttributeError):
            continue
        seen += 1
        applied += st == "applied"
    if applied:
        return _r(True, f"crag update applied ({applied} applied of {seen} run(s))")
    return _r(False, f"{seen} crag update dry run(s), none applied" if seen else "no crag update run yet")


def check_bundle(c: Ctx, step: dict) -> dict:
    b = (c.state or {}).get("bundle") or {}
    p = c.out / "first-pass" / str(b.get("name") or "")
    if not b.get("name") or not p.is_file():
        return _r(False, "no bundle yet: econquest first-pass bundle")
    if _sha_file(p) != b.get("sha256"):
        return _r(False, f"{p.name} changed since it was built: build it again")
    return _r(bool(b.get("complete")), f"{p.name}: {b.get('files')} files, sha256 {str(b['sha256'])[:12]}..."
              + ("" if b.get("complete") else f"; missing: {', '.join(b.get('missing') or [])}"),
              "drag it into the Claude project files")


# name, phrase that must appear in the row (what + command), read-only (the check runs the step), how it is checked
CHECKS = (
    ("zip", "shasum", True, check_zip, "first-pass computes the zip's sha256 and compares it with the doc"),
    ("install", "install.command", False, check_install, "install marker, installed version = the doc's, install warnings"),
    ("backup", "backup --verify", False, check_backup, "health's backup line (age) and backup verify of the newest archive"),
    ("next", "econquest next", True, check_next, "first-pass runs `econquest next` (reads only)"),
    ("licence", "change baseline licences.csv", False, check_licence, "licence register state is ok (change verify, R44)"),
    ("evidence", "econquest evidence", False, check_evidence, "evidence verify of the newest non-DEMO bundle"),
    ("ledger", "ledger verify", True, check_ledger, "first-pass runs the review ledger verify (reads only)"),
    ("review", "review list --pending", False, check_review, "review verify ok and no held cell without a decision"),
    ("legacy", "legacy-reset", False, check_legacy, "legacy-reset dry run finds 0 cells"),
    ("attest", "attest", False, check_attest, "0 unattested hand-entered cells"),
    ("schedule", "record_job_apply_prices", False, check_schedule, "ops.json switch true and schedule check ok"),
    ("pulls", "next --run", False, check_pulls, "next's panel step done, World Bank probe and pull report saved"),
    ("ucdp", "UCDP", False, check_ucdp, "UCDP token present (never read) and GED CSVs in place"),
    ("crag", "crag update", False, check_crag, "a crag update run with status applied"),
    ("bundle", "Upload for the teams", False, check_bundle, "the bundle first-pass built is complete and unchanged"),
)
_BY_NAME = {n: {"name": n, "phrase": ph, "read_only": ro, "fn": fn, "how": how} for n, ph, ro, fn, how in CHECKS}


def match_check(step: dict) -> dict | None:
    """The check for a doc row: the first CHECKS entry whose phrase is in the row (its own position first)."""
    text = f"{step['what']} {step['command']}"
    order = list(_BY_NAME.values())
    i = step["n"] - 1
    if 0 <= i < len(order):
        order = [order[i]] + order[:i] + order[i + 1:]
    return next((spec for spec in order if spec["phrase"] in text), None)


# ---------------------------------------------------------------- state file
def state_path(home: Path) -> Path:
    return Path(home) / STATE_NAME


def load_state(home: Path) -> dict:
    p = state_path(home)
    try:
        st = json.loads(p.read_text(encoding="utf-8")) if p.is_file() and p.stat().st_size < 2 ** 20 else {}
    except (OSError, ValueError):
        st = {}
    if not isinstance(st, dict) or st.get("format") != FORMAT:
        st = {}
    st.setdefault("format", FORMAT)
    st["steps"] = {k: v for k, v in (st.get("steps") or {}).items() if isinstance(v, dict) and v.get("result") in RESULTS}
    return st


def save_state(home: Path, st: dict) -> None:
    p = state_path(home)
    tmp = p.with_name(p.name + ".part")
    tmp.write_text(json.dumps(st, indent=1, sort_keys=True) + "\n", encoding="utf-8")
    os.replace(tmp, p)


def _record(c: Ctx, step: dict, res: dict) -> dict:
    row = {"result": res["result"], "checked_utc": _now(c.now), "check": step.get("check") or "",
           "detail": [scrub(d, c.home)[:300] for d in res["detail"]][:6], "doc_sha256": c.doc["sha256"]}
    c.state["steps"][str(step["n"])] = row
    c.state.update(doc_sha256=c.doc["sha256"], updated_utc=row["checked_utc"])
    return row


def run_check(c: Ctx, step: dict) -> dict:
    spec = _BY_NAME.get(step.get("check") or "")
    if spec is None:
        return {"result": "fail", "detail": ["no automatic check for this row: confirm it with --check N --confirm"]}
    try:
        return spec["fn"](c, step)
    except (Exception, SystemExit) as e:                 # noqa: BLE001 - a crashing check is a failed check, never a crash
        return {"result": "fail", "detail": [f"the check could not run ({type(e).__name__})"]}


# ---------------------------------------------------------------- report
def status_of(st: dict, step: dict, doc_sha: str) -> str:
    row = st["steps"].get(str(step["n"]))
    return row["result"] if row else "not checked"


def next_step(doc: dict, st: dict) -> dict | None:
    return next((s for s in doc["steps"] if status_of(st, s, doc["sha256"]) not in ("pass", "skipped", "confirmed")), None)


def report(c: Ctx) -> dict:
    steps = []
    for s in c.doc["steps"]:
        row = c.state["steps"].get(str(s["n"])) or {}
        steps.append({"n": s["n"], "what": s["what"], "command": s["command"], "tags": s["tags"], "check": s["check"],
                      "runs_itself": s["runs_itself"], "how": s["how"], "status": row.get("result", "not checked"),
                      "checked_utc": row.get("checked_utc", ""), "detail": row.get("detail", []),
                      "doc_changed": bool(row) and row.get("doc_sha256") != c.doc["sha256"]})
    nxt = next_step(c.doc, c.state)
    done = sum(s["status"] in ("pass", "skipped", "confirmed") for s in steps)
    return {"generated_utc": _now(c.now), "doc": DOC.as_posix(), "doc_sha256": c.doc["sha256"], "version": c.doc["version"],
            "done": done, "total": len(steps), "next": nxt["n"] if nxt else None, "steps": steps,
            "bundle": c.state.get("bundle") or {}, "state_file": STATE_NAME}


MARK = {"pass": "[pass]   ", "fail": "[FAIL]   ", "skipped": "[skipped]", "confirmed": "[ok, by hand]",
        "not checked": "[ ]      "}


def _cmd_lines(s: dict) -> list[str]:
    cmds = re.findall(r"`([^`]+)`", s["command"])
    return [f"      $ {x}" for x in cmds] or [f"      {s['command']}"]


def render_step(s: dict) -> list[str]:
    L = [f"Step {s['n']} ({', '.join(s['tags'])}): {re.sub(r'`', '', s['what'])}", "  Command:"] + _cmd_lines(s)
    if s["runs_itself"]:
        L.append(f"  It only reads, so the check runs it: econquest first-pass --check {s['n']}")
    else:
        L.append(f"  Run it yourself, then: econquest first-pass --check {s['n']}")
    L.append(f"  Checked by: {s['how']}")
    if s["tags"] == ["optional"]:
        L.append(f"  Optional: econquest first-pass --skip {s['n']} --reason \"...\" leaves it out")
    for d in s["detail"]:
        L.append(f"  last check: {d}")
    return L


def render_status(rep: dict) -> str:
    L = [f"First Mac pass ({rep['doc']}, {rep['version']}): {rep['done']} of {rep['total']} steps done."
         + (f" Next: step {rep['next']}." if rep["next"] else " All done.")]
    for s in rep["steps"]:
        L.append(f"{MARK.get(s['status'], s['status'])} {s['n']:>2}  {re.sub(r'`', '', s['what'])}"
                 + (f"  ({s['checked_utc']})" if s["checked_utc"] else "")
                 + ("  [the doc changed since]" if s["doc_changed"] else ""))
        if s["status"] == "fail":
            L += [f"              {d}" for d in s["detail"]]
    return "\n".join(L) + "\n"


def render_next(rep: dict) -> str:
    s = next((x for x in rep["steps"] if x["n"] == rep["next"]), None)
    if s is None:
        return "First Mac pass: every step is done. The decisions are in section B of team/first-mac-pass.md.\n"
    return "\n".join(render_step(s)) + "\n"


# ---------------------------------------------------------------- bundle
def _br():
    from .evidence import build_release
    return build_release()


def _newest_run_file(base: Path, name: str, pattern=_RUN_DIR) -> list[Path]:
    runs = sorted(p for p in base.iterdir() if p.is_dir() and pattern.match(p.name) and (p / name).is_file()) \
        if base.is_dir() else []
    return [runs[-1] / name] if runs else []


MPP = "docs/runbooks/A-mac-pull-pack.md"
ASKED = (   # (label, how to find the files under the install, asked by, required)
    ("data/live/review.csv", lambda h: [h / "data/live/review.csv"], "team/first-mac-pass.md step 15", True),
    ("data/live/pullpack/report.json", lambda h: [h / "data/live/pullpack/report.json"],
     f"team/first-mac-pass.md step 15; {MPP} What to send back", True),
    ("data/live/pullpack/pullpack.log", lambda h: [h / "data/live/pullpack/pullpack.log"],
     f"team/first-mac-pass.md step 15; {MPP} What to send back", True),
    ("data/live/pullpack/report.md", lambda h: [h / "data/live/pullpack/report.md"], f"{MPP} What to send back", True),
    ("data/live/pullpack/state.json", lambda h: [h / "data/live/pullpack/state.json"], f"{MPP} What to send back", True),
    ("data/panel/staging/<newest run>/manifest.json", lambda h: _newest_run_file(h / "data/panel/staging", "manifest.json"),
     f"{MPP} What to send back (without staging/weo_cache)", False),
    ("outputs/wb_probe/ (probes.json, probe.json, codes/)",
     lambda h: sorted(p for p in (h / "outputs/wb_probe").rglob("*") if p.is_file()) if (h / "outputs/wb_probe").is_dir() else [],
     f"{MPP} 0.6.0 Mac order A, Send back", False),
    ("data/panel/wb_interim/worldbank_history.csv", lambda h: [h / "data/panel/wb_interim/worldbank_history.csv"],
     f"{MPP} 0.6.0 Mac order A, Send back", False),
    ("data/panel/wb_interim/staging/<newest run>/manifest.json",
     lambda h: _newest_run_file(h / "data/panel/wb_interim/staging", "manifest.json", re.compile(r".+")),
     f"{MPP} 0.6.0 Mac order A, Send back", False),
    ("outputs/restructuring/<newest date>/restructuring.json",
     lambda h: _newest_run_file(h / "outputs/restructuring", "restructuring.json", _DATE_DIR),
     f"{MPP} 0.6.0 Mac order B, Send back", False),
    ("outputs/weo_api_probe/ (probe.json, weo_dataflows.csv, weo_api_samples.csv)",
     lambda h: [h / "outputs/weo_api_probe" / n for n in ("probe.json", "weo_dataflows.csv", "weo_api_samples.csv")],
     f"{MPP} IMF API probe, Send back (WEO is deferred: only if it ran)", False),
    ("data/panel/staging/weo_cache/weo_route_diagnostics.jsonl",
     lambda h: [h / "data/panel/staging/weo_cache/weo_route_diagnostics.jsonl"],
     f"{MPP} IMF API probe, Send back (WEO is deferred: only if it ran)", False),
)
BACKUP_ASK = "docs/runbooks/A-landing-check.md part 1 (the newest nightly backup and its manifest)"


def _inside(p: Path, root: Path) -> bool:
    try:
        p.resolve().relative_to(root.resolve())
        return True
    except (ValueError, OSError):
        return False


def _secret_values(c: Ctx) -> set[bytes]:
    from .evidence import secret_values
    from .open_items import ucdp_token_state
    vals = {v.encode() for v in secret_values(c.home / ".ops.env")}
    try:                                                 # the UCDP token variable, if it is set in this environment
        name = ucdp_token_state(c.d, env={})["env_name"]
        if len(c.env.get(name, "")) >= 6:
            vals.add(c.env[name].encode())
    except Exception:                                    # noqa: BLE001 - the default list still applies
        pass
    return vals


def _holds_secret(p: Path, values: set[bytes]) -> bool:
    if not values:
        return False
    with open(p, "rb") as f:
        body = f.read(MAX_SCAN)
    return any(v in body for v in values)


def _backup_files(c: Ctx) -> tuple[list[tuple[str, Path]], list[dict], list[dict]]:
    from . import backup as B
    found = B.list_backups(c.backup_dest())
    if not found:
        return [], [{"path": "nightly backup", "asked_by": BACKUP_ASK, "required": False}], []
    arch = found[-1]
    side = arch.with_name(arch.name[:-len(".tar.gz")] + ".manifest.json")
    br = _br()
    try:
        with tarfile.open(arch, "r:gz") as tar:
            bad = [m.name for m in tar.getmembers() if br.is_secret(Path(m.name).name)]
    except (tarfile.TarError, OSError, EOFError):
        return [], [], [{"path": f"backup/{arch.name}", "reason": "backup archive unreadable"}]
    if bad:
        return [], [], [{"path": f"backup/{arch.name}", "reason": f"the archive lists {len(bad)} credential file(s)"}]
    if not B.verify(arch, log=_quiet)["ok"]:
        return [], [], [{"path": f"backup/{arch.name}", "reason": "backup verify failed"}]
    return [(f"backup/{arch.name}", arch), (f"backup/{side.name}", side)], [], []


def build_bundle(c: Ctx, dest=None, with_backup: bool = True) -> dict:
    br = _br()
    values = _secret_values(c)
    files, missing, excluded, seen = [], [], [], set()
    for label, find, asked, required in ASKED:
        got = []
        for p in find(c.home):
            rel = p.relative_to(c.home).as_posix() if _inside(p, c.home) else p.name
            if rel in seen or not (p.is_file() or p.is_symlink()):
                continue
            seen.add(rel)
            why = ("symlink" if p.is_symlink() else "outside the install" if not _inside(p, c.home)
                   else "credential file name (build_release SECRET_GLOBS)" if br.is_secret(p.name)
                   else "holds a credential value" if _holds_secret(p, values)
                   else "Team A's token check matched (A-landing-check.md): tell the program lead, do not send it"
                   if rel in LANDING_TOKEN_FILES and LANDING_TOKEN_RE.search(p.read_bytes()[:MAX_SCAN]) else "")
            if why:
                excluded.append({"path": rel, "reason": why})
                continue
            got.append(rel)
            files.append({"path": rel, "src": p, "asked_by": asked})
        if not got:
            missing.append({"path": label, "asked_by": asked, "required": required})
    if with_backup:
        bf, bm, bx = _backup_files(c)
        files += [{"path": rel, "src": p, "asked_by": BACKUP_ASK} for rel, p in bf]
        missing += bm
        excluded += bx
    for f in files:
        f["sha256"], f["bytes"] = _sha_file(f["src"]), f["src"].stat().st_size
    req_missing = [m["path"] for m in missing if m["required"]]
    stamp = c.now.strftime("%Y%m%dT%H%M%SZ")
    from .. import __version__
    manifest = {"format": BUNDLE_FORMAT, "created_utc": _now(c.now), "version": __version__,
                "doc": DOC.as_posix(), "doc_sha256": c.doc["sha256"], "complete": not req_missing,
                "files": [{k: f[k] for k in ("path", "sha256", "bytes", "asked_by")} for f in sorted(files, key=lambda f: f["path"])],
                "missing": missing, "excluded": excluded,
                "never_included": "credential files (SECRET_GLOBS), tokens, the Keychain, .env/.ops.env, symlinks"}
    mbytes = (json.dumps(manifest, indent=1, sort_keys=True) + "\n").encode()
    out_dir = Path(dest) if dest else c.out / "first-pass"
    out_dir.mkdir(parents=True, exist_ok=True)
    zp = out_dir / f"first-pass-{stamp}.zip"
    entries = [(f"{BUNDLE_TOP}/{f['path']}", f["src"]) for f in files] + [(f"{BUNDLE_TOP}/{MANIFEST_NAME}", mbytes)]
    sha = br.write_zip(zp, entries)
    (out_dir / f"{zp.name}.manifest.json").write_bytes(mbytes)
    (out_dir / f"{zp.name}.sha256").write_text(f"{sha}  {zp.name}\n", encoding="utf-8")
    info = {"name": zp.name, "sha256": sha, "files": len(files), "complete": not req_missing, "missing": req_missing,
            "excluded": len(excluded), "built_utc": _now(c.now), "dest_default": dest is None}
    return {"zip": zp, "manifest": manifest, "info": info}


# ---------------------------------------------------------------- CLI
def _ctx(args) -> Ctx:
    out = Path(args.out).expanduser()
    home = out.resolve().parent
    c = Ctx(args.data, out, home, zip_path=getattr(args, "zip", None))
    c.doc = load_doc(home)
    c.state = load_state(home)
    return c


def _step(c: Ctx, n) -> dict:
    try:
        k = int(n)
    except (TypeError, ValueError):
        raise SystemExit(f"first-pass: STEP must be a step number from section A or `all`, not {n!r}") from None
    s = next((x for x in c.doc["steps"] if x["n"] == k), None)
    if s is None:
        raise SystemExit(f"first-pass: no step {k} in {DOC.as_posix()} (steps 1-{len(c.doc['steps'])})")
    return s


def cmd_first_pass(args) -> None:
    if not (Path(args.data) / "countries.csv").is_file():
        print(f"first-pass: {args.data} is not an econquest data folder (no countries.csv)", file=sys.stderr)
        raise SystemExit(EXIT_ERROR)
    try:
        c = _ctx(args)
    except DocError as e:
        print(f"first-pass: {e}", file=sys.stderr)
        raise SystemExit(EXIT_ERROR) from None
    flags = [f for f in ("status", "next", "check", "skip") if getattr(args, f)]
    if len(flags) > 1 or (args.action and flags):
        print("first-pass: give one of --status, --next, --check, --skip or bundle", file=sys.stderr)
        raise SystemExit(EXIT_ERROR)
    if args.confirm and not args.check:
        print("first-pass: --confirm goes with --check STEP", file=sys.stderr)
        raise SystemExit(EXIT_ERROR)
    if args.action == "bundle":
        b = build_bundle(c, args.dest, with_backup=not args.no_backup)
        if not args.dest:
            c.state["bundle"] = b["info"]
            save_state(c.home, c.state)
        m = b["manifest"]
        print(f"first-pass bundle: {scrub(b['zip'], c.home)}\n  sha256 {b['info']['sha256']}\n  {len(m['files'])} files, "
              f"{len(m['missing'])} asked-for item(s) not on disk, {len(m['excluded'])} left out; manifest {MANIFEST_NAME}")
        for x in m["missing"]:
            print(f"  missing{' (required)' if x['required'] else ''}: {x['path']}  [{x['asked_by']}]")
        for x in m["excluded"]:
            print(f"  left out: {x['path']}: {x['reason']}")
        print("  Upload this one zip to the Claude project files." if m["complete"] else
              "  Not complete: a required file is missing (above).")
        raise SystemExit(EXIT_DONE if m["complete"] else EXIT_LEFT)
    if args.skip:
        s = _step(c, args.skip)
        if not s["optional"]:
            print(f"first-pass: step {s['n']} is tagged {', '.join(s['tags'])}; only optional steps can be skipped",
                  file=sys.stderr)
            raise SystemExit(EXIT_ERROR)
        if not (args.reason or "").strip():
            print("first-pass: --skip needs --reason", file=sys.stderr)
            raise SystemExit(EXIT_ERROR)
        _record(c, s, {"result": "skipped", "detail": [f"skipped: {args.reason.strip()}"]})
        save_state(c.home, c.state)
    elif args.check:
        targets = c.doc["steps"] if str(args.check).lower() == "all" else [_step(c, args.check)]
        if args.confirm:
            if len(targets) != 1 or targets[0]["check"]:
                print("first-pass: --confirm is only for a step that has no automatic check", file=sys.stderr)
                raise SystemExit(EXIT_ERROR)
            _record(c, targets[0], {"result": "confirmed", "detail": ["confirmed by hand"]})
        else:
            for s in targets:
                prev = c.state["steps"].get(str(s["n"]), {}).get("result")
                if prev in ("skipped", "confirmed") and len(targets) > 1:
                    continue
                res = run_check(c, s)
                row = _record(c, s, res)
                print(f"step {s['n']}: {row['result'].upper()}" + "".join(f"\n  {d}" for d in row["detail"]))
        save_state(c.home, c.state)
        rep = report(c)
        print()
        print(render_next(rep) if rep["next"] else "Every step is done: econquest first-pass bundle, then step 15.", end="")
        failed = any(c.state["steps"].get(str(s["n"]), {}).get("result") == "fail" for s in targets)
        raise SystemExit(EXIT_LEFT if failed else EXIT_DONE)
    rep = report(c)
    if args.json:
        print(json.dumps(rep, indent=1, default=str))
    elif args.next:
        print(render_next(rep), end="")
    elif args.status or args.skip:
        print(render_status(rep), end="")
    else:
        print(render_status(rep))
        print(render_next(rep), end="")
    raise SystemExit(EXIT_DONE if rep["next"] is None else EXIT_LEFT)


def register(sub) -> None:
    fp = sub.add_parser("first-pass", help="the first Mac pass (team/first-mac-pass.md) step by step: what to do, the exact "
                        "command, a check after each step (progress in <home>/first-pass.json), and `bundle`: one upload zip "
                        "of the files the teams asked for, with a sha256 manifest; never runs a step that changes data")
    fp.add_argument("action", nargs="?", choices=["bundle"], help="bundle: build the upload zip")
    fp.add_argument("--status", action="store_true", help="every step and its recorded result")
    fp.add_argument("--next", action="store_true", help="the next step in full")
    fp.add_argument("--check", metavar="STEP", help="check a step (number, or `all`) and record the result")
    fp.add_argument("--confirm", action="store_true", help="with --check: confirm by hand a step that has no automatic check")
    fp.add_argument("--skip", metavar="STEP", help="leave out an optional step (needs --reason)")
    fp.add_argument("--reason", help="why an optional step is skipped")
    fp.add_argument("--zip", metavar="PATH", help="step 1: the downloaded zip (default ~/Downloads/econquest-macos.zip)")
    fp.add_argument("--json", action="store_true", help="print the steps as JSON")
    fp.add_argument("--dest", metavar="DIR", help="bundle: folder for the zip (default <out>/first-pass; not recorded)")
    fp.add_argument("--no-backup", action="store_true", help="bundle: leave out the nightly backup")
    fp.set_defaults(fn=cmd_first_pass)
