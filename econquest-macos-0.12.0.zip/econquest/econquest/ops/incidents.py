"""Incident log (EQ-C-0077, team/runbooks/C-incident.md) kept in the existing hash-chained action log.

    econquest incident log detect --summary "morning run missing" [--severity S1|S2|S3] --actor NAME
                                                              -> opens INC-<UTC date>-<n> and prints its id
    econquest incident log triage|contain|restore|record --id INC-... --summary "..." --actor NAME
    econquest incident list [--id INC-...] [--open]

Each entry is one row of outputs/store/actions.jsonl (ops/actionlog.py) with command "incident <phase>" and args
{incident_id, phase, severity, summary}: append-only, hash-chained, backed up with the store and checked by
`econquest log verify` and the daily monitor (chain:actions). Phase `record` closes the incident; nothing is ever
edited or deleted (a correction is a later row). Text is length-limited and must not hold secrets (the action log
masks secret-looking option names, not free text).
"""
from __future__ import annotations

import datetime as dt
import os
import re
import sys

PHASES = ("detect", "triage", "contain", "restore", "record")
SEVERITIES = ("S1", "S2", "S3")
ID_RE = re.compile(r"INC-\d{8}-\d{2,}")
PREFIX = "incident "
# credentials in the environment are masked if pasted into a summary (as cli.main masks them in every other row)
SECRET_ENVS = ("ECONQUEST_SHEETS_TOKEN", "ECONQUEST_SMTP_PASSWORD", "ECONQUEST_ALERT_WEBHOOK", "ECONQUEST_LEDGER_KEY",
               "UCDP_API_TOKEN")


class IncidentError(ValueError):
    pass


def _rows(out_dir) -> list[dict]:
    from .actionlog import read
    return [r for r in read(out_dir) if str(r.get("command", "")).startswith(PREFIX)]


def incidents(out_dir) -> dict[str, dict]:
    """{incident_id: {id, severity, opened_utc, last_phase, closed, entries: [...]}} in log order."""
    out: dict[str, dict] = {}
    for r in _rows(out_dir):
        a = r.get("args") or {}
        iid = a.get("incident_id")
        if not iid:
            continue
        inc = out.setdefault(iid, {"id": iid, "severity": a.get("severity"), "opened_utc": r.get("ts_utc"), "entries": []})
        inc["severity"] = a.get("severity") or inc["severity"]
        inc["last_phase"] = a.get("phase")
        inc["closed"] = a.get("phase") == "record"
        inc["entries"].append({"seq": r.get("seq"), "ts_utc": r.get("ts_utc"), "phase": a.get("phase"),
                               "actor": r.get("actor"), "summary": a.get("summary")})
    return out


def log_entry(out_dir, phase: str, summary: str, actor: str, incident_id: str | None = None, severity: str | None = None,
              now: dt.datetime | None = None) -> dict:
    """Append one incident entry. `detect` without an id opens a new incident; every other phase needs an open one."""
    from .actionlog import append
    if phase not in PHASES:
        raise IncidentError(f"phase must be one of {', '.join(PHASES)}")
    summary, actor = str(summary or "").strip(), str(actor or "").strip()
    if not summary or len(summary) > 500:
        raise IncidentError("summary is required (at most 500 characters)")
    if not actor:
        raise IncidentError("actor is required (who is doing this)")
    if severity is not None and severity not in SEVERITIES:
        raise IncidentError(f"severity must be one of {', '.join(SEVERITIES)}")
    known = incidents(out_dir)
    if incident_id is None:
        if phase != "detect":
            raise IncidentError(f"{phase} needs --id of an open incident (detect opens one)")
        now = now or dt.datetime.now(dt.timezone.utc)
        day = now.astimezone(dt.timezone.utc).strftime("%Y%m%d")
        n = 1 + sum(1 for i in known if i.startswith(f"INC-{day}-"))
        incident_id = f"INC-{day}-{n:02d}"
        severity = severity or "S2"
    else:
        if not ID_RE.fullmatch(incident_id):
            raise IncidentError(f"not an incident id: {incident_id!r} (INC-YYYYMMDD-nn)")
        if incident_id not in known:
            raise IncidentError(f"no incident {incident_id} in the log")
        if known[incident_id].get("closed"):
            raise IncidentError(f"{incident_id} is closed (recorded); open a new incident with detect")
    args = {"incident_id": incident_id, "phase": phase, "severity": severity or known.get(incident_id, {}).get("severity"),
            "summary": summary}
    secrets = [v for v in (os.environ.get(k, "").strip() for k in SECRET_ENVS) if len(v) >= 8]   # SEC-C-012 I1
    return append(out_dir, PREFIX + phase, args, actor=actor, actor_source="flag", now=now, secrets=secrets)


def add_arguments(ap) -> None:
    sub = ap.add_subparsers(dest="incident_cmd", required=True)
    lg = sub.add_parser("log", help="append one incident entry (detect opens a new incident; record closes it)")
    lg.add_argument("phase", choices=PHASES)
    lg.add_argument("--id", dest="incident_id", help="INC-YYYYMMDD-nn (not for a new detect)")
    lg.add_argument("--summary", required=True)
    lg.add_argument("--severity", choices=SEVERITIES, help="S1 desk cannot work, S2 degraded, S3 minor (default S2 on detect)")
    lg.add_argument("--actor", required=True)
    ls = sub.add_parser("list", help="incidents and their entries")
    ls.add_argument("--id", dest="incident_id"); ls.add_argument("--open", action="store_true", help="only incidents not yet recorded")


def run_from_args(args, out_dir) -> int:
    try:
        if args.incident_cmd == "log":
            r = log_entry(out_dir, args.phase, args.summary, args.actor, args.incident_id, args.severity)
            a = r["args"]
            print(f"{a['incident_id']} {a['phase']} ({a['severity']}) logged as action-log seq {r['seq']}")
            return 0
        inc = incidents(out_dir)
        for i in inc.values():
            if (args.incident_id and i["id"] != args.incident_id) or (args.open and i.get("closed")):
                continue
            print(f"{i['id']}  {i['severity']}  {'closed' if i.get('closed') else 'open: ' + str(i.get('last_phase'))}  opened {i['opened_utc'][:19]}")
            for e in i["entries"]:
                print(f"    {str(e['ts_utc'])[:19]}  {e['phase']:<8} {e['actor']}: {e['summary']}")
        if not inc:
            print("No incidents logged.")
        return 0
    except IncidentError as e:
        print(f"incident: {e}", file=sys.stderr)
        return 2
