"""Wrapper every scheduled job runs through (EQ-C-0021).

    python -m econquest.ops.jobs --home ~/econquest --job record --step '["/path/econquest","record"]' [--step ...]

Runs the steps in order in <home> (stops at the first non-zero exit) and records the job in outputs/logs/jobs/:

    <job>.last.json   the latest run: status (running / ok / failed / skipped), started_at, ended_at, exit_code, steps
    history.jsonl     one line per start and one per end, for every job

With --keep-going every step runs even after a failure, and the job's exit code is the worst one: any code other
than 0 and 2 (the first such) over 2 (a reported breach) over 0 (HO-20261024-A-C-012, the data_ops job).

A step argument holding "{as_of}" gets the run date (YYYY-MM-DD in --tz, default the Mac's local zone) at start, so
a monthly job such as the forecast scorecard passes its own date (HO-20261024-B-C-006).

The health check reads <job>.last.json to flag a failed or hung job. A second start while the first still runs
(lock file with a live pid) is recorded as skipped with exit code 75 and does not run the steps.

Alert settings (ECONQUEST_ALERT_WEBHOOK, ECONQUEST_SMTP_*) are not in the plists. When <home>/.ops.env exists and is
readable by its owner only (chmod 600), its KEY=VALUE lines are added to the environment of the steps.

Hardening (EQ-C-0164, docs/runbooks/C-chaos-and-perf.md):
  clock guard   a start whose clock reads more than CLOCK_SKEW_TOLERANCE (10 min) BEFORE the newest started_at/ended_at
                recorded in any <job>.last.json is refused: status failed, reason "clock_skew", exit EXIT_CLOCK (78),
                no step runs (a calendar job would otherwise run for a past or future date and every "since" and
                freshness check after it would be wrong). health.py reports it as a clock_skew alert. After checking
                the clock, --allow-clock-skew (or ECONQUEST_ALLOW_CLOCK_SKEW=1) runs once anyway.
  durations     "seconds" is the wall-clock difference, or the monotonic elapsed time when the wall clock went back
                during the job (then "clock_skew": true): never negative.
  full disk     a failure to write last.json/history.jsonl (ENOSPC included) is logged in one line, the lock is still
                removed, and a job that otherwise succeeded exits EXIT_IO (74): an unrecorded run is not an ok run.
"""
from __future__ import annotations
import argparse
import datetime as dt
import json
import os
import signal
import stat
import subprocess
import sys
import time
from pathlib import Path

EXIT_OVERLAP = 75
EXIT_IO = 74                                            # EX_IOERR: the run could not be recorded (EQ-C-0164)
EXIT_CLOCK = 78                                         # EX_CONFIG: refused, the clock is behind the job record (EQ-C-0164)
CLOCK_SKEW_TOLERANCE = dt.timedelta(minutes=10)
ALLOW_SKEW_ENV = "ECONQUEST_ALLOW_CLOCK_SKEW"
AS_OF = "{as_of}"


def jobs_dir(home: str | Path) -> Path:
    return Path(home) / "outputs" / "logs" / "jobs"


def _now() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def _iso(t: dt.datetime) -> str:
    return t.astimezone(dt.timezone.utc).isoformat(timespec="seconds")


def load_env_file(path: Path, log=print) -> dict:
    """KEY=VALUE lines (no shell expansion). Refused when group or others can read the file."""
    if not path.exists():
        return {}
    if path.stat().st_mode & (stat.S_IRWXG | stat.S_IRWXO):
        log(f"[job] {path} ignored: readable by group/others; run chmod 600 {path}")
        return {}
    env = {}
    for line in path.read_text().splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        k, v = line.split("=", 1)
        k = k.strip().removeprefix("export ").strip()
        env[k] = v.strip().strip('"').strip("'")
    return env


def _pid_alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
    except ProcessLookupError:
        return False
    except PermissionError:
        return True
    return True


def _write_last(d: Path, job: str, rec: dict) -> None:
    tmp = d / f".{job}.last.json.tmp"
    tmp.write_text(json.dumps(rec, indent=1)); tmp.replace(d / f"{job}.last.json")


def _history(d: Path, rec: dict) -> None:
    with open(d / "history.jsonl", "a") as f:
        f.write(json.dumps(rec) + "\n")


def newest_recorded(home: str | Path) -> dt.datetime | None:
    """The newest started_at / ended_at in any <job>.last.json (unreadable files are skipped)."""
    best = None
    for rec in last_runs(home).values():
        for k in ("started_at", "ended_at"):
            try:
                t = dt.datetime.fromisoformat(str(rec.get(k)).replace("Z", "+00:00"))
            except (TypeError, ValueError):
                continue
            t = t if t.tzinfo else t.replace(tzinfo=dt.timezone.utc)
            best = t if best is None or t > best else best
    return best


def clock_problem(home: str | Path, now: dt.datetime, tolerance: dt.timedelta = CLOCK_SKEW_TOLERANCE) -> str | None:
    """A message when `now` is more than `tolerance` before the newest recorded job time (the clock went back, or an
    earlier run's clock was ahead); None when the clock is consistent with the job record."""
    newest = newest_recorded(home)
    if newest is not None and now < newest - tolerance:
        return (f"clock skew: the system clock reads {_iso(now)}, {(newest - now).total_seconds() / 60:.0f} min before the "
                f"newest recorded job time {_iso(newest)} (outputs/logs/jobs/*.last.json). Nothing was run. Check the "
                f"clock (date -u); then rerun with --allow-clock-skew or {ALLOW_SKEW_ENV}=1")
    return None


def fill_as_of(steps: list[list[str]], when: dt.datetime, tz: str | None = None) -> list[list[str]]:
    """Replace {as_of} in every step argument by the date of `when` in `tz` (default: the local zone)."""
    if not any(AS_OF in a for s in steps for a in s):
        return steps
    if tz:
        from zoneinfo import ZoneInfo
        day = when.astimezone(ZoneInfo(tz)).date()
    else:
        day = when.astimezone().date()
    return [[a.replace(AS_OF, day.isoformat()) for a in s] for s in steps]


def run_job(job: str, steps: list[list[str]], home: str | Path, runner=subprocess.run, clock=_now, env: dict | None = None,
            log=print, tz: str | None = None, keep_going: bool = False, allow_clock_skew: bool | None = None) -> int:
    """Run `steps` for `job`, recording start, end and exit code. Returns the job's exit code."""
    home = Path(home)
    d = jobs_dir(home); d.mkdir(parents=True, exist_ok=True)
    lock = d / f"{job}.lock"
    if lock.exists():
        try:
            pid = int(lock.read_text().strip() or 0)
        except ValueError:
            pid = 0
        if pid and pid != os.getpid() and _pid_alive(pid):
            t = clock()
            rec = {"job": job, "status": "skipped", "reason": f"previous run (pid {pid}) still running", "started_at": _iso(t),
                   "ended_at": _iso(t), "exit_code": EXIT_OVERLAP, "pid": os.getpid()}
            _history(d, {"event": "skipped", **rec}); log(f"[job] {job} skipped: pid {pid} still running")
            return EXIT_OVERLAP                       # last.json keeps the running job's record
    if allow_clock_skew is None:
        allow_clock_skew = os.environ.get(ALLOW_SKEW_ENV) == "1"
    t = start = clock()
    skew = None if allow_clock_skew else clock_problem(home, t)
    if skew:
        rec = {"job": job, "status": "failed", "reason": "clock_skew", "message": skew, "started_at": _iso(t),
               "ended_at": _iso(t), "exit_code": EXIT_CLOCK, "pid": os.getpid(), "steps": []}
        try:
            _write_last(d, job, rec); _history(d, {"event": "refused", **{k: rec[k] for k in ("job", "reason", "started_at", "exit_code")}})
        except OSError as e:
            log(f"[job] {job}: refusal not recorded: {type(e).__name__}: {e}")
        log(f"[job] {job} refused: {skew}")
        return EXIT_CLOCK
    try:
        lock.write_text(str(os.getpid()))
    except OSError as e:
        log(f"[job] {job} not started: cannot write the lock file ({type(e).__name__}: {e}); disk full?")
        return EXIT_IO
    run_env = dict(os.environ if env is None else env)
    run_env.setdefault("ECONQUEST_HOME", str(home))
    run_env.update(load_env_file(home / ".ops.env", log))
    m0 = time.monotonic()
    steps = fill_as_of(steps, start, tz)
    rec = {"job": job, "status": "running", "started_at": _iso(start), "ended_at": None, "exit_code": None, "pid": os.getpid(),
           "host": os.uname().nodename if hasattr(os, "uname") else None, "steps": []}
    try:
        _write_last(d, job, rec); _history(d, {"event": "start", "job": job, "at": rec["started_at"], "pid": rec["pid"]})
    except OSError as e:                                # EQ-C-0164: an unrecordable run does not start
        log(f"[job] {job} not started: cannot record the start ({type(e).__name__}: {e}); disk full?")
        _drop_tmp(d, job)
        with _suppress_oserror():
            lock.unlink()
        return EXIT_IO
    log(f"[job] {job} started {rec['started_at']} ({len(steps)} steps)")
    code = 0
    try:
        for argv in steps:
            t0 = time.monotonic()
            try:
                rc = runner(argv, cwd=str(home), env=run_env).returncode
            except (OSError, subprocess.SubprocessError) as e:
                log(f"[job] {job}: could not start {argv[0]}: {e}"); rc = 127
            rec["steps"].append({"argv0": Path(argv[0]).name, "args": argv[1:3] if argv[0].endswith("bash") else argv[1:],
                                 "exit_code": rc, "seconds": round(time.monotonic() - t0, 1)})
            if rc != 0:
                if not keep_going:
                    code = rc
                    break
                if code in (0, 2):                          # worst wins: an error (1, 127, ...) over a breach (2)
                    code = rc if code == 0 or rc != 2 else code
    except BaseException as e:                          # KeyboardInterrupt / SIGTERM from launchd
        code = 130 if isinstance(e, KeyboardInterrupt) else (e.code if isinstance(e, SystemExit) and isinstance(e.code, int) else 1)
        raise
    finally:
        end = clock()
        wall = (end - start).total_seconds()
        rec.update({"status": "ok" if code == 0 else "failed", "ended_at": _iso(end), "exit_code": code,
                    "seconds": round(wall if wall >= 0 else time.monotonic() - m0, 1)})
        if wall < 0:                                    # the wall clock went back during the job (EQ-C-0164)
            rec["clock_skew"] = True
        try:
            _write_last(d, job, rec)
            _history(d, {"event": "end", "job": job, "at": rec["ended_at"], "exit_code": code, "status": rec["status"]})
        except OSError as e:                            # EQ-C-0164: say so, release the lock, never report ok
            log(f"[job] {job}: end not recorded ({type(e).__name__}: {e}); disk full? last.json may still say running")
            _drop_tmp(d, job)
            if code == 0:
                code = EXIT_IO
        with _suppress_oserror():
            lock.unlink()
        log(f"[job] {job} {rec['status']} exit {code} at {rec['ended_at']}")
    return code


class _suppress_oserror:
    def __enter__(self):
        return self

    def __exit__(self, et, e, tb):
        return et is not None and issubclass(et, OSError)


def _drop_tmp(d: Path, job: str) -> None:
    with _suppress_oserror():
        (d / f".{job}.last.json.tmp").unlink()


def last_runs(home: str | Path) -> dict[str, dict]:
    d = jobs_dir(home)
    out = {}
    for f in sorted(d.glob("*.last.json")) if d.exists() else []:
        try:
            out[f.name[:-len(".last.json")]] = json.loads(f.read_text())
        except (OSError, json.JSONDecodeError):
            continue
    return out


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ops.jobs", description="run a scheduled econquest job and record its exit code")
    ap.add_argument("--home", default=os.environ.get("ECONQUEST_HOME", str(Path.home() / "econquest")))
    ap.add_argument("--job", required=True)
    ap.add_argument("--step", action="append", required=True, help="one step as a JSON argv list (repeatable, run in order)")
    ap.add_argument("--keep-going", action="store_true", help="run every step; exit with the worst code (errors over 2 over 0)")
    ap.add_argument("--tz", help="time zone of the run date that fills {as_of} (default: the Mac's local zone)")
    ap.add_argument("--allow-clock-skew", action="store_true",
                    help=f"run even when the clock is behind the job record (after checking it; or {ALLOW_SKEW_ENV}=1)")
    args = ap.parse_args(argv)
    signal.signal(signal.SIGTERM, lambda *_: sys.exit(143))     # launchd stops jobs with SIGTERM: still record the end
    steps = [json.loads(s) for s in args.step]
    if not all(isinstance(s, list) and s and all(isinstance(a, str) for a in s) for s in steps):
        ap.error("each --step must be a non-empty JSON list of strings")
    return run_job(args.job, steps, args.home, tz=args.tz, keep_going=args.keep_going,
                   allow_clock_skew=True if args.allow_clock_skew else None)


if __name__ == "__main__":
    sys.exit(main())
