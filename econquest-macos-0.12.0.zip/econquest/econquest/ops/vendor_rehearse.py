"""Vendor operations rehearsal on Team A's simulator (EQ-C-0146, HO-20261026-A-C-003). EVERY VALUE IS SIMULATED.

    econquest vendor rehearse [--out DIR] [--json]

One command, no licence, no vendor, no network, nothing for Sam to run:
  1. Team A's go-live dry run (ingestion/market/vendors/vendor_sim_dryrun.dry_run, EQ-A-0123) in a sandbox folder
     OUTSIDE the econquest folder: SIMULATED fixtures served through the real Bloomberg and LSEG adapters, gated
     captures, the snapshot store, gated history and layer-2 readiness (its 7 steps, each a row below).
  2. Team C's vendor operations (ops/vendor_ops.py, EQ-C-0117) on that sandbox:
       snapshots   the scheduled job body (run_snapshots --save) with the sandbox register held in memory; every saved
                   row SIMULATED; and the REAL job on the desk data folder still says "off: no licensed vendor";
       usage log   one hash-chained row per vendor, each tagged with the SIMULATED entitlement; the chain verifies;
       audit       the entitlement audit: desk-internal yes, client and validator no, 0 problem findings; the real
                   audit on the desk data folder still allows nobody;
       golive      the runbook's go-live checklist (docs/runbooks/A-licensed-go-live.md steps 2 to 7) in simulation;
       guards      the defence-in-depth hooks (refuse_simulated below) refuse a SIMULATED snapshot on every path;
       desk        the desk data and outputs folders are byte-for-byte unchanged (size + mtime of every file).
Prints one PASS/FAIL table, every row labelled SIMULATED, and writes rehearsal.md / rehearsal.json into the sandbox.
Exit 0 when every row passes, 1 otherwise, including a refused --out (Team A's vendor_sim_guard refuses any folder
inside the econquest folder or holding desk data files) and a non-zero dry run.

Nothing here widens the sandbox rule: there is no setting or environment variable. The in-memory register that
vendor_ops accepts for the rehearsal is refused by vendor_ops for any folder that is not a SIMULATED sandbox. The real
vendor jobs stay off: no licence row, no schedule entry, no entitlement is written or changed.

refuse_simulated(frame, where) is the hook Team C's output paths call (HO-20261026-A-C-003 ask 2): sheets_publish
.full_plan (Sheets publish), xlsx_export.export, client_build (client export and client workbook), client_outbox.build
and scripts/build_release.py (market seed files). It maps the layer-2 columns market_licence / market_source onto the
guard's licence / source columns and calls vendor_sim_guard.assert_no_simulated.

demo_vendor_sim(out_dir=None) -> {"ok", "steps", "problems"} is demo row M15 (EQ-C-0148).
"""
from __future__ import annotations

import dataclasses
import datetime as dt
import json
import os
import sys
import tempfile
from pathlib import Path

TICKET = "EQ-C-0146"
HANDOFF = "HO-20261026-A-C-003"
LABEL = "SIMULATED"
REPORT_MD, REPORT_JSON = "rehearsal.md", "rehearsal.json"
OUTPUTS = "outputs"                      # Team C's outputs folder inside the sandbox (usage log, audit report)
GUARD_COLUMNS = ("licence", "source", "vendor_ticker")
BANNER = (f"{LABEL} REHEARSAL ({TICKET}). Every value is {LABEL}: synthetic, from Team A's vendor simulator "
          "(EQ-A-0123). NOT market data, no vendor and no licence involved. The real vendor jobs stay off.")


# ---------------------------------------------------------------- defence-in-depth hook (ask 2)
def market_frame(df):
    """The guard's view of a market-derived frame: licence / source / vendor_ticker, each joined with its layer-2
    market_<name> column when present (country tables carry market_licence and market_source)."""
    import pandas as pd
    cols = {}
    for c in GUARD_COLUMNS:
        parts = [df[k].fillna("").astype(str) for k in (c, f"market_{c}") if k in df.columns]
        if parts:
            s = parts[0]
            for p in parts[1:]:
                s = s + " " + p
            cols[c] = s
    return pd.DataFrame(cols, index=df.index)


def refuse_simulated(df, where: str) -> None:
    """Raise vendor_sim_guard.SimulatedDataError when any row of `df` carries the SIMULATED label (no-op on None or
    an empty frame). Called before a market-derived frame leaves on a release, publish or client-output path."""
    if df is None or not len(df):
        return
    from ..ingestion.market import vendor_sim_guard as SG
    SG.assert_no_simulated(market_frame(df), where)


def refuse_simulated_run(out_dir, where: str) -> None:
    """refuse_simulated on the country table of <out_dir>/run_latest.json (the run client outputs are built from);
    nothing to check when the file is missing or has no country rows."""
    import pandas as pd
    try:
        doc = json.loads((Path(out_dir) / "run_latest.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return
    rows = doc.get("country") if isinstance(doc, dict) else None
    if isinstance(rows, list) and rows:
        refuse_simulated(pd.DataFrame([r for r in rows if isinstance(r, dict)]), where)


# ---------------------------------------------------------------- the rehearsal
@dataclasses.dataclass
class Row:
    area: str
    check: str
    ok: bool
    detail: str = ""

    def as_dict(self) -> dict:
        return {"area": self.area, "check": self.check, "result": "PASS" if self.ok else "FAIL", "label": LABEL,
                "detail": self.detail}


def _inside(p: Path, root: Path) -> bool:
    try:
        p.resolve().relative_to(root.resolve())
        return True
    except ValueError:
        return False


def fingerprint(*roots) -> dict[str, tuple[int, int]]:
    """{path: (size, mtime_ns)} for every file under each root (symlinks not followed). Missing roots give nothing."""
    out = {}
    for r in roots:
        r = Path(r)
        if not r.is_dir():
            continue
        for d, _dn, fn in os.walk(r):
            for f in fn:
                p = Path(d) / f
                try:
                    st = p.lstat()
                except OSError:
                    continue
                out[str(p)] = (st.st_size, st.st_mtime_ns)
    return out


def _diff(before: dict, after: dict) -> list[str]:
    ch = [f"changed {k}" for k in before if k in after and before[k] != after[k]]
    return ch + [f"removed {k}" for k in before if k not in after] + [f"added {k}" for k in after if k not in before]


def refused(out, data_dir, outputs_dir) -> str:
    """'' when `out` may hold the rehearsal sandbox, else why not (Team A's guard first, then the desk folders)."""
    from ..ingestion.market import vendor_sim_guard as SG
    why = SG.location_problem(out)
    if why:
        return why
    for d in (data_dir, outputs_dir):
        if _inside(Path(out), Path(d)):
            return f"{out} is inside the desk folder {d}"
    return ""


def rehearse(out=None, *, data_dir=None, outputs_dir=None, seed=None, as_of=None, days=None, dry_run=None,
             now: dt.datetime | None = None) -> dict:
    """Run the rehearsal (module docstring). Returns {"ok", "exit", "out", "label", "rows", "problems",
    "report_md", "report_json"}. `dry_run` replaces Team A's dry_run (tests); everything else is the real code."""
    from ..ingestion.market import vendor_sim_guard as SG
    from ..ingestion.market.vendors import vendor_sim as VS
    from ..ingestion.market.vendors import vendor_sim_dryrun as VD
    data_dir = Path(data_dir) if data_dir is not None else VS.REPO_DATA
    outputs_dir = Path(outputs_dir) if outputs_dir is not None else SG.REPO_ROOT / "outputs"
    seed = VS.DEFAULT_SEED if seed is None else int(seed)
    as_of = as_of or VS.DEFAULT_AS_OF
    days = VS.DEFAULT_DAYS if days is None else int(days)
    res = {"ok": False, "exit": 1, "out": None, "label": LABEL, "banner": BANNER, "ticket": TICKET, "rows": [],
           "problems": [], "report_md": None, "report_json": None}
    if out is not None:
        why = refused(out, data_dir, outputs_dir)
        if not why:
            try:
                SG.make_sandbox(out, seed=seed)                  # Team A's guard: refuses before creating anything
            except SG.SimulatedDataError as e:
                why = str(e)
        if why:
            res["problems"] = [f"--out refused: {why}"]
            res["out"] = str(out)
            return res
        out = Path(out)
    else:
        out = Path(tempfile.mkdtemp(prefix="econquest-rehearse-"))
        why = refused(out, data_dir, outputs_dir)
        if why:                                                  # e.g. TMPDIR inside the econquest folder
            res["problems"] = [f"temporary folder refused: {why}"]
            res["out"] = str(out)
            return res
    res["out"] = str(out)
    rows: list[Row] = []
    before = fingerprint(data_dir, outputs_dir)

    # 1. Team A's dry run
    dr = (dry_run or VD.dry_run)(out, seed=seed, as_of=as_of, days=days, data_dir=data_dir)
    for s in dr.steps:
        rows.append(Row("dry run (Team A)", s.name, bool(s.ok), "; ".join(s.problems)[:300] or "pass"))
    rows.append(Row("dry run (Team A)", "exit code", bool(dr.ok), f"vendor_sim_dryrun exit {0 if dr.ok else 1}"))
    if dr.ok:
        try:
            rows += _vendor_ops(out, data_dir, dr)
        except Exception as e:                                   # noqa: BLE001 - a crashed check is a FAIL row
            rows.append(Row("vendor ops (Team C)", "rehearsal", False, f"{type(e).__name__}: {str(e)[:300]}"))
    else:
        rows.append(Row("vendor ops (Team C)", "snapshots / usage / audit / golive", False,
                        "not run: Team A's dry run failed"))
    after = fingerprint(data_dir, outputs_dir)
    d = _diff(before, after)
    rows.append(Row("desk untouched", f"{Path(data_dir).name}/ and {Path(outputs_dir).name}/ unchanged", not d,
                    f"{len(before)} files, no change" if not d else "; ".join(d[:5])))
    res["rows"] = [r.as_dict() for r in rows]
    res["problems"] = [f"{r.area}: {r.check}: {r.detail}" for r in rows if not r.ok]
    res["ok"] = bool(rows) and all(r.ok for r in rows)
    res["exit"] = 0 if res["ok"] else 1
    if SG.is_sandbox(out):
        res["report_json"], res["report_md"] = _write_report(out, res, now)
    return res


def _vendor_ops(out: Path, data_dir: Path, dr) -> list[Row]:
    """Team C's vendor operations on the sandbox, plus the real-switch checks on the desk data folder."""
    import pandas as pd

    from ..ingestion import licences as LIC
    from ..ingestion.market import vendor_sim_guard as SG
    from ..ingestion.market.store import list_market_snapshots, read_market_snapshot
    from ..ingestion.market.vendors import golive as G
    from ..ingestion.market.vendors import vendor_sim as VS
    from ..ingestion.market.vendors import vendor_sim_dryrun as VD
    from . import schedule as SCH
    from . import vendor_ops as O
    rows: list[Row] = []
    steps = {s.name: s for s in dr.steps}
    sim_days = (steps.get("generate").detail or {}).get("days") or []
    day = sim_days[-1]
    now = dt.datetime.fromisoformat(f"{day}T22:00:00+00:00")
    vendors = tuple(sorted({p.name for p in (out / "fixtures").iterdir() if p.is_dir()}))
    reg = LIC.load_register(out / VD.REGISTER_FILE)
    outs = out / OUTPUTS

    def factory(v, _d):
        return VS.sim_adapter(out / "fixtures" / v, out, now=now)[0]

    # snapshots job (sandbox)
    known = set(list_market_snapshots(out)["snapshot_id"])
    log: list[str] = []
    job = O.run_snapshots(out, outs, as_of=day, save=True, adapter_factory=factory, register=reg, log=log.append)
    saved = [v for v in job["vendors"] if v.get("result") == "saved"]
    rows.append(Row("snapshots", f"{O.JOB_NAME} --save on the sandbox", job["state"] == "on" and job["exit"] == 0
                    and len(saved) == len(vendors), "; ".join(f"{v['vendor']} {v.get('result')} {v.get('rows', 0)} rows"
                                                               for v in job["vendors"])))
    new = [s for s in list_market_snapshots(out)["snapshot_id"] if s not in known]
    lab = []
    for sid in new:
        q = read_market_snapshot(out, sid, verify=True)
        man = json.loads((out / "live" / "market" / "snapshots" / sid / "manifest.json").read_text(encoding="utf-8"))
        lab.append(bool(len(q)) and bool(SG.simulated_mask(q).all()) and SG.provenance_is_simulated(man.get("provenance")))
    rows.append(Row("snapshots", "saved snapshots verify, every row and manifest SIMULATED",
                    len(new) == len(vendors) and all(lab), f"{len(new)} new snapshots in the sandbox store"))
    if O.eligibility(data_dir)["eligible"]:                  # never run the real job with --save on desk data
        rows.append(Row("snapshots", "the REAL job on desk data stays off", False, "a licence row allows a vendor"))
    else:
        real = O.run_snapshots(data_dir, out / "real-job-off", as_of=day, save=False, log=lambda *_: None)
        rows.append(Row("snapshots", "the REAL job on desk data stays off", real["state"] == "off"
                        and real["exit"] == 0 and not (out / "real-job-off").exists(), real.get("message", "")[:200]))
    try:
        O.eligibility(data_dir, reg)
        sandbox_only = False
    except O.VendorOpsError:
        sandbox_only = True
    rows.append(Row("snapshots", "the in-memory register is refused for desk data", sandbox_only,
                    "vendor_ops refuses it outside a SIMULATED sandbox"))

    # usage log
    v = O.verify_usage(outs)
    use = O.read_usage(outs)
    tags_ok = all(SG.is_simulated_text(u.get("licence")) for u in use) and \
        sorted(u.get("vendor") for u in use) == sorted(vendors)
    rows.append(Row("usage log", "one SIMULATED-tagged row per vendor, chain verifies", v["ok"] and tags_ok
                    and all(u.get("purpose") == "snapshot" for u in use),
                    f"{v['rows']} rows, verifies {v['ok']}; licences {sorted({u.get('licence') for u in use})}"))
    rows.append(Row("usage log", "every usage output inside the sandbox",
                    all(_inside(Path(u.get("output", "")), out) for u in use), str(outs / "store" / O.USAGE_NAME)))

    # entitlement audit
    a = O.audit(out, outs, adapter_factory=factory, today=now.date(), register=reg, now=now)
    aud = {x["vendor"]: x["audiences"] for x in a["vendors"]}
    rows.append(Row("audit", "0 problem findings", a["problems"] == 0,
                    "; ".join(f["what"] for f in a["findings"])[:300] or "no findings"))
    rows.append(Row("audit", "desk-internal yes; client and validator no", all(
        aud[x]["desk_internal"]["allowed"] and not aud[x]["client"]["allowed"] and not aud[x]["validator"]["allowed"]
        for x in vendors), ", ".join(f"{x}: internal {aud[x]['desk_internal']['allowed']}" for x in vendors)))
    rows.append(Row("audit", "report written inside the sandbox", bool(a.get("paths"))
                    and all(_inside(Path(p), out) for p in a["paths"]), ", ".join(Path(p).name for p in a.get("paths", []))))
    ra = O.audit(data_dir, outs / "real-audit", write=False)
    rows.append(Row("audit", "the REAL audit on desk data allows no vendor", not any(
        x["audiences"]["desk_internal"]["allowed"] or x["audiences"]["client"]["allowed"] for x in ra["vendors"]),
        f"register {ra['register']}"))

    # go-live checklist (docs/runbooks/A-licensed-go-live.md steps 2-7), in simulation
    u = G.desk_universe(data_dir)
    shipped = LIC.load_register(LIC.DEFAULT_REGISTER)
    for x in vendors:
        ad = factory(x, out)
        st = ad.licence_state()
        rows.append(Row("golive", f"step 2 entitlement usable ({x})", bool(st.usable),
                        st.entitlement.tag if st.entitlement else "; ".join(st.problems)[:200]))
        ver = G.verify_ticker_map(ad.ticker_map(), x, u)
        rows.append(Row("golive", f"step 3 ticker map verified ({x})", bool(ver["ok"]),
                        f"{ver['verified']} verified rows" + (f"; {ver['problems'][:3]}" if ver["problems"] else "")))
        tag = f"{x}:{VS.LICENCE_IDS[x]} (desk-internal)"
        ok_s, why_s = G.register_verdict(tag, x, reg)
        ok_r, why_r = G.register_verdict(tag, x, shipped)
        rows.append(Row("golive", f"step 4 register: sandbox approves, shipped refuses ({x})", ok_s and not ok_r,
                        f"sandbox: {why_s}; shipped: {why_r}"[:300]))
    rows.append(Row("golive", "step 5 first gated capture (Team A gate + store)",
                    all(steps[k].ok for k in ("gate", "store")) and len(saved) == len(vendors),
                    f"{(steps['gate'].detail or {}).get('saved')} rows saved by capture; canary held"))
    frag = [G.schedule_fragment(x) for x in vendors]
    js = O.job_status(data_dir)
    rows.append(Row("golive", "step 6 schedule fragment valid; real job not installed",
                    all(f.get("jobs") for f in frag) and O.JOB_NAME not in SCH.DEFAULT_JOBS
                    and not any(k in SCH.DEFAULT_JOBS for f in frag for k in f["jobs"]) and js["state"] == "off",
                    js["summary"][:200]))
    rows.append(Row("golive", "step 7 layer 2 readiness (default refuses, sandbox register uses)",
                    steps["readiness"].ok, "; ".join(steps["readiness"].problems)[:200] or "pass"))

    # defence-in-depth hooks
    q = read_market_snapshot(out, new[0]) if new else pd.DataFrame()
    country = pd.DataFrame({"market_licence": [str(q["licence"].iloc[0]) if len(q) else ""],
                            "market_source": ["CDS curve spread 5y"]})
    hooks = {"release": q, "Sheets publish (full_plan)": country, "xlsx export": country, "client_build": country,
             "client_outbox": q}
    for where, frame in hooks.items():
        try:
            refuse_simulated(frame, where)
            ok = False
        except SG.SimulatedDataError:
            ok = True
        rows.append(Row("guards", f"{where} refuses a SIMULATED frame", ok and len(frame) > 0,
                        "SimulatedDataError" if ok else "not refused"))
    return rows


# ---------------------------------------------------------------- output
def table(res: dict) -> str:
    L = [BANNER, "", "| Area | Check | Result | Label | Detail |", "|---|---|---|---|---|"]
    for r in res["rows"]:
        L.append(f"| {r['area']} | {r['check']} | {r['result']} | {r['label']} | "
                 + str(r["detail"]).replace("|", "/").replace("\n", " ")[:220] + " |")
    L += ["", f"{LABEL} rehearsal: **{'PASS' if res['ok'] else 'FAIL'}** "
              f"({sum(r['result'] == 'PASS' for r in res['rows'])}/{len(res['rows'])} rows). Sandbox: `{res['out']}`."]
    return "\n".join(L)


def _write_report(out: Path, res: dict, now) -> tuple[str, str]:
    now = now or dt.datetime.now(dt.timezone.utc)
    doc = {**{k: v for k, v in res.items() if k not in ("report_md", "report_json")},
           "generated_utc": now.strftime("%Y-%m-%dT%H:%M:%SZ"), "handoff": HANDOFF}
    pj, pm = out / REPORT_JSON, out / REPORT_MD
    pj.write_text(json.dumps(doc, indent=1, default=str) + "\n", encoding="utf-8")
    pm.write_text(f"# {LABEL} vendor operations rehearsal ({TICKET})\n\n" + table(res) + "\n", encoding="utf-8")
    return str(pj), str(pm)


def demo_vendor_sim(out_dir=None, *, data_dir=None, outputs_dir=None) -> dict:
    """Demo row M15 (EQ-C-0148): the rehearsal as {"ok", "steps", "problems"}; steps are the table rows. `econquest
    demo` passes its own home's data/ and outputs/ so the desk-untouched row never sees other sessions' writes."""
    try:
        r = rehearse(out_dir, data_dir=data_dir, outputs_dir=outputs_dir)
    except Exception as e:                                        # noqa: BLE001 - the demo reports, never crashes
        return {"ok": False, "steps": [], "problems": [f"rehearsal crashed: {type(e).__name__}: {str(e)[:300]}"]}
    return {"ok": bool(r["ok"]), "steps": r["rows"], "problems": list(r["problems"])}


# ---------------------------------------------------------------- command line (`econquest vendor rehearse`)
def add_cli(vds) -> None:
    v = vds.add_parser("rehearse", help=f"{LABEL} vendor operations rehearsal ({TICKET}): Team A's go-live dry run on the "
                       "vendor simulator in a sandbox outside the econquest folder, then the snapshots job, usage log, "
                       "entitlement audit and go-live checklist on it; one PASS/FAIL table; the real vendor jobs stay off")
    v.add_argument("--out", dest="rehearse_out", metavar="DIR",
                   help="sandbox folder outside the econquest folder (default: a new temporary folder); refused, exit 1, "
                        "otherwise")
    v.add_argument("--json", dest="rehearse_json", action="store_true", help="print the result as JSON")


def run_cli(args) -> int:
    r = rehearse(getattr(args, "rehearse_out", None), data_dir=args.data, outputs_dir=args.out)
    if getattr(args, "rehearse_json", False):
        print(json.dumps(r, indent=1, default=str))
    elif r["rows"]:
        print(table(r))
        if r["report_md"]:
            print(f"report: {r['report_md']} ({r['report_json']})")
    else:
        print(f"vendor rehearse: {'; '.join(r['problems'])}", file=sys.stderr)
    return int(r["exit"])
