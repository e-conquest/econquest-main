"""Client mode go-live gate (EQ-C-0116): `econquest client-check --go-live [--json]`. INTERNAL. Reads only.

Lists every blocker to switching client mode on, each with its id, owners (Sam / Team A / Team B / Team C / counsel),
current state, evidence path and what clears it. It adds no rule of its own: the rows come from the existing checks:

    ops/client_check.collect        every failing client-check row (mode, IMF cells, non-commercial cells, licences,
                                    licence register, ACLED, disclaimers, allow-list, entitlements, recipients,
                                    compliance approver, adviser records)
    ops/client_pack.blockers        Team B's comparison, the client-safe rule gap and the pack's extra blockers
                                    (second analyst = independent approver, seeds, register regex, workbook policy ...)
    ops/licence_gov.state           the licence register baseline: only Sam's real approved version clears it. A DEMO
                                    baseline (EQ-C-0123, ops/demo_baseline) is always a blocker: "register baseline is
                                    DEMO, not Sam's"; with no approved version the blocker is "no real baseline"
    data/licences.csv (C14)         IMF permission (imf_* rows not client_output=allowed) and non-commercial sources
                                    in use (rows with commercial != yes that presentation/licences.evaluate counts)
    ops/client_decision             Sam's recorded decision (later, PI-9) until a new decision is recorded
    presentation/client_build.gate  the gate client builds use; a cross-check, so the gate never passes while it refuses
    ops/client_distribution.verify  the client delivery log must verify

NOTHING HERE SWITCHES CLIENT MODE ON. It writes only <out>/client_pack/golive.json, golive.md and golive-card.md, and
never research.json, the register, approvals or the action log. Exit 0 only when there are no blockers (not expected
while client mode is off). The decision card text (golive-card.md, docs/research/client-mode-golive-card.md) is
prepared, never posted: the lead decides when it goes out, and under Sam's MVP rule (2026-10-25 16:36Z) not before the
MVP (team/mvp-checklist.md) is reached.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import re
from pathlib import Path

TICKET = "EQ-C-0116"
OWNERS = ("Sam", "Team A", "Team B", "Team C", "counsel")
JSON_NAME, MD_NAME, CARD_NAME = "golive.json", "golive.md", "golive-card.md"
CARD_DOC = "docs/research/client-mode-golive-card.md"
NOTICE = ("INTERNAL - client mode go-live gate (EQ-C-0116). Not for clients; a checklist from repo state, not legal "
          "advice. Nothing here switches client mode on.")
MVP_LINE = ("NOT POSTED. Under Sam's MVP rule (2026-10-25 16:36Z) this card waits until the MVP is reached "
            "(team/mvp-checklist.md); the program lead decides when it goes out.")
DEMO_TEXT = "register baseline is DEMO, not Sam's"

# Evidence path and owners per client-check / client-pack id. "clears" falls back to client_pack.CHECK_OWNERS /
# the pack's next_step; only rows whose pack text names a Mac step are reworded (PI-10 MVP rule).
META = {
    "mode": (("Sam",), "data/research.json",
             "Last step only: Sam approves research.json mode client through `econquest change`, after every other "
             "blocker is cleared"),
    "imf": (("Sam", "Team A", "Team B"), "data/audit_trail.csv (`python -m econquest.ingestion.audit client`)", None),
    "restricted": (("Team A",), "data/audit_trail.csv (`python -m econquest.ingestion.audit restricted`)",
                   "Official FX feed replaces the Yahoo fx3m cells (with the parked live pull, team/when-sam-is-ready.md)"),
    "licences": (("Team A", "Sam"), "data/licences.csv (terms_verified, client_output)", None),
    "licence_register": (("Team C", "Team A"), "data/licences.csv; econquest/presentation/licences.py", None),
    "acled": (("Sam",), "data/live/events/feeds.json", None),
    "disclaimer_core": (("Team C",), "econquest/presentation/report.py (DISCLAIMER)", None),
    "disclaimer_client": (("counsel", "Sam"), "data/research.json (disclaimer.client)", None),
    "allow_list": (("Sam",), "data/research.json (internal_domains, internal_addresses)", None),
    "entitlements": (("Sam",), "data/research.json (entitlements); data/distribution.json (subscribers)", None),
    "recipients": (("Team C", "Sam"), "data/recipients.json (not present)", None),
    "compliance": (("Sam",), "data/compliance.json", None),
    "adviser": (("counsel", "Sam"), "data/client_readiness.json (not present)", None),
    "client_safe_comparison": (("Team B",), "outputs/client-safe-comparison/<as_of>/", None),
    "client_safe_rule_gap": (("Team B", "Team C", "Team A"), "outputs/client-safe-comparison/<as_of>/client-safe.json; "
                             "presentation/licences.evaluate", None),
    "second_analyst": (("Sam",), "team/board/program.csv PI9-ALL; data/compliance.json", None),
}


def owners_of(text: str) -> list[str]:
    """Owner text (client_pack style, e.g. 'Sam (licence) + Team A (feeds)') -> names from OWNERS."""
    t = str(text or "")
    out = [o for o in ("Sam", "Team A", "Team B", "Team C") if re.search(rf"\b{o}\b", t)]
    if re.search(r"counsel|adviser|advisor", t, re.IGNORECASE):
        out.append("counsel")
    return out or ["Team C"]


def _row(bid, what, owners, state, evidence, clears, source, hard=True) -> dict:
    return {"id": bid, "blocker": what, "owner": list(owners), "state": state, "evidence": evidence, "clears": clears,
            "source": source, "hard": bool(hard)}


def demo_marker(data_dir, outputs_dir=None) -> dict | None:
    """The DEMO licence baseline (EQ-C-0123) if one is in view: the profile open in this thread (licence_gov state
    "demo"), open anywhere in this process (demo_active), or a DEMO record left under <out>/demo/licence-baseline/.
    None when nothing marks a DEMO baseline. Never raises."""
    from . import licence_gov as G
    demo_state = getattr(G, "DEMO_STATE", "demo")
    try:
        st = G.state(data_dir)
        if st.get("status") == demo_state or st.get("demo"):
            return {"how": "licence_gov.state is demo (DEMO profile open in this thread)", "path": None}
    except Exception:                                           # noqa: BLE001 - the baseline row reports it
        pass
    try:
        if getattr(G, "demo_active", lambda: False)():
            return {"how": "the DEMO profile is open in this process (licence_gov.demo_active)", "path": None}
    except Exception:                                           # noqa: BLE001
        pass
    if outputs_dir is not None:
        try:
            from . import demo_baseline as DB
            store = DB.store_dir(outputs_dir)
            rec = DB.load(store)
            raw = None
            if rec is None and (store / DB.RECORD).is_file():          # malformed leftover: still DEMO, never Sam's
                raw = str(store / DB.RECORD)
            if rec is not None or raw:
                return {"how": "a DEMO baseline record is on disk (ops/demo_baseline)", "path": raw or str(store / DB.RECORD)}
        except Exception:                                       # noqa: BLE001 - module not there: no marker
            pass
    return None


def baseline_row(data_dir, outputs_dir=None, demo: dict | None = None) -> dict | None:
    """The licence register baseline blocker, or None when Sam's real approved version is in force and no DEMO marker
    is in view. `demo` is a marker the caller saw itself (client-check --go-live --demo-baseline)."""
    from . import licence_gov as G
    evidence = "data/approvals/log.jsonl (licences.csv apply / baseline rows)"
    clears = ("Sam's own first approved baseline of data/licences.csv through `econquest change` (parked until the MVP, "
              "team/when-sam-is-ready.md). A DEMO baseline never clears it")
    demo = demo or demo_marker(data_dir, outputs_dir)
    if demo:
        return _row("licence_baseline", "Licence register baseline approved by Sam (R44, EQ-C-0106)", ("Sam",),
                    f"{DEMO_TEXT}: {demo['how']}; " + getattr(G, "DEMO_BANNER", "DEMO baseline: not Sam's approval"),
                    evidence + (f"; {demo['path']}" if demo["path"] else ""), clears, "ops/licence_gov + EQ-C-0123")
    try:
        st = G.state(data_dir)
    except Exception as e:                                      # noqa: BLE001 - cannot tell: blocker
        return _row("licence_baseline", "Licence register baseline approved by Sam", ("Sam",),
                    f"could not be checked ({type(e).__name__})", evidence, clears, "ops/licence_gov")
    s = st.get("status")
    if s in G.TRUSTED:
        return None
    if s in ("no_baseline", "default"):
        state = ("no real baseline: data/licences.csv has no approved version (no DEMO baseline in view either)"
                 if s == "no_baseline" else "no real baseline: there is no data/licences.csv")
    else:
        state = f"status {s}: " + (G.problem(data_dir, st) or "")
    return _row("licence_baseline", "Licence register baseline approved by Sam (R44, EQ-C-0106)", ("Sam",),
                state[:400], evidence, clears, "ops/licence_gov")


def register_rows(data_dir, ev: dict) -> list[dict]:
    """IMF permission and non-commercial sources in use, read from Team A's register (C14) and the licence evaluation."""
    from ..ingestion import licences as A
    out = []
    try:
        reg = A.load_register(Path(data_dir) / "licences.csv")
    except Exception as e:                                      # noqa: BLE001 - nothing is allowed
        return [_row("imf_permission", "IMF permission for client use", ("Sam", "counsel"),
                     f"licence register could not be read ({type(e).__name__})", "data/licences.csv",
                     "A readable register", "data/licences.csv")]
    imf = [r for r in reg if r["source_id"].startswith("imf") and r["client_output"] != "allowed"]
    if imf:
        out.append(_row("imf_permission", "IMF permission for client use (EXC-003 covers internal use only)", ("Sam", "counsel"),
                        "; ".join(f"{r['source_id']} client_output={r['client_output']}" + (f" ({r['exc_id']})" if r["exc_id"] else "")
                                  for r in imf),
                        "data/licences.csv (imf_* rows); docs/governance/issues-log.md EXC-003",
                        "IMF written permission for client use filed and the rows set to allowed through `econquest change` "
                        "by Sam, or no IMF-derived cell left in client output", "data/licences.csv"))
    used = {s.get("source_id"): s.get("cells", 0) for s in ev.get("sources") or [] if s.get("source_id")}
    nc = [r for r in reg if r["source_id"] in used and r["commercial"] != "yes"]
    if nc:
        out.append(_row("non_commercial_sources", "No source in use whose register row is not cleared for commercial use",
                        ("Team A", "Sam"),
                        f"{len(nc)} sources in use with commercial != yes: "
                        + ", ".join(f"{r['source_id']} ({r['commercial']}, {used[r['source_id']]} cells)" for r in nc[:10])
                        + (f" and {len(nc) - 10} more" if len(nc) > 10 else ""),
                        "data/licences.csv (commercial); presentation/licences.evaluate",
                        "Licence text verified as allowing commercial use (commercial=yes), or the source dropped from client "
                        "output", "data/licences.csv"))
    return out


def decision_row(dec: dict) -> dict | None:
    d = (dec or {}).get("decision") or {}
    if d.get("choice") in ("yes", "go-live"):
        return None
    return _row("sam_decision", "Sam's recorded decision allows client mode", ("Sam",),
                f"recorded {d.get('decided_utc', '?')}: client mode {d.get('choice', 'not decided')} (revisit {d.get('revisit', '?')})",
                d.get("doc") or "docs/research/client-mode-decision-pack.md",
                "A new recorded decision by Sam to go live (this card, after the MVP)", "ops/client_decision")


def code_gate_rows(data_dir, outputs_dir) -> tuple[list[dict], dict]:
    from . import client_distribution as CD
    rows, info = [], {}
    try:
        v = CD.verify(outputs_dir)
    except Exception as e:                                      # noqa: BLE001
        v = {"ok": False, "errors": [f"{type(e).__name__}"]}
    info["client_distribution_log"] = {"ok": v["ok"], "errors": v.get("errors", [])[:3]}
    if not v["ok"]:
        rows.append(_row("client_distribution_log", "Client delivery log verifies (EQ-C-0107)", ("Team C",),
                         "; ".join(v.get("errors", [])[:3]), "outputs/store/client_deliveries.jsonl",
                         "Restore the log so `client-export --verify-log` passes", "ops/client_distribution.verify"))
    try:
        from ..presentation.client_build import gate
        g = gate(data_dir)
        info["client_build_gate"] = {"ok": g["ok"], "problems": g["problems"][:6]}
    except Exception as e:                                      # noqa: BLE001
        info["client_build_gate"] = {"ok": False, "problems": [f"could not be checked ({type(e).__name__})"]}
    return rows, info


def _demo_open_result(data_dir, outputs_dir, demo, now) -> dict:
    """Inside an open DEMO profile client-pack refuses (EQ-C-0123), so the gate fails closed: the DEMO blocker plus
    a row saying the other checks were not run."""
    rows = [baseline_row(data_dir, outputs_dir, demo),
            _row("golive_incomplete", "Every go-live check ran", ("Team C",),
                 "not run: the DEMO licence profile is open in this process and client-pack refuses inside it",
                 "econquest/ops/client_pack.py (collect_pack)", "Run `econquest client-check --go-live` outside the DEMO profile",
                 "ops/client_golive")]
    return _result(data_dir, rows, "unknown", "not run (DEMO profile open)", {}, None, now)


def _result(data_dir, rows, mode, check_summary, gates, decision, now) -> dict:
    for r in rows:
        r["owner"] = [o for o in OWNERS if o in r["owner"]] or ["Team C"]
    now = now or dt.datetime.now(dt.timezone.utc)
    return {"notice": NOTICE, "ticket": TICKET, "generated": now.strftime("%Y-%m-%dT%H:%M:%SZ"), "data_dir": str(data_dir),
            "mode": mode, "ready": not rows, "count": len(rows), "hard": sum(r["hard"] for r in rows),
            "blockers": rows, "code_gates": gates, "decision": decision, "client_check": check_summary}


def collect(data_dir, outputs_dir, now: dt.datetime | None = None, demo: dict | None = None) -> dict:
    """{"ticket", "generated", "mode", "ready", "blockers": [rows], "count", "hard", "code_gates", "decision"}.
    Never changes anything."""
    from ..presentation.licences import safe_evaluate
    from . import licence_gov as G
    from .client_pack import CHECK_OWNERS, collect_pack
    if getattr(G, "demo_active", lambda: False)():
        return _demo_open_result(data_dir, outputs_dir, demo or demo_marker(data_dir, outputs_dir), now)
    p = collect_pack(data_dir, outputs_dir)
    rows: list[dict] = []
    b = baseline_row(data_dir, outputs_dir, demo)
    if b:
        rows.append(b)
    for x in p["blockers"]:
        owners, evidence, clears = META.get(x["id"], (None, None, None))
        rows.append(_row(x["id"], x["blocker"], owners or owners_of(x["owner"]), x.get("detail") or f"open ({x['source']})",
                         evidence or x["source"], clears or x.get("next_step") or CHECK_OWNERS.get(x["id"], ("", ""))[1],
                         x["source"], x["hard"]))
    rows += register_rows(data_dir, safe_evaluate(data_dir))
    d = decision_row(p.get("decision"))
    if d:
        rows.append(d)
    extra, gates = code_gate_rows(data_dir, outputs_dir)
    rows += extra
    if not gates["client_build_gate"]["ok"] and not rows:
        rows.append(_row("client_build_gate", "Client build gate (presentation/client_build.gate) allows a build", ("Team C",),
                         "; ".join(gates["client_build_gate"]["problems"]), "econquest/presentation/client_build.py",
                         "Whatever the gate names", "presentation/client_build.gate"))
    return _result(data_dir, rows, p["texts"]["mode"], p["check_summary"], gates, (p.get("decision") or {}).get("decision"), now)


def _esc(s) -> str:
    """Markdown cell text. Quoted check text that names a Mac step is shortened: under the PI-10 MVP rule the card
    never asks Sam for a Mac step (the step itself is parked in team/when-sam-is-ready.md)."""
    t = re.sub(r"\s+on the Mac\b", "", str(s if s is not None else ""))
    return t.replace("|", "\\|").replace("\n", " ")


def table(g: dict) -> list[str]:
    L = ["| # | id | Blocker | Owner | Current state | Evidence | What clears it |", "|---:|---|---|---|---|---|---|"]
    L += [f"| {i} | `{r['id']}`{' *' if r['hard'] else ''} | {_esc(r['blocker'])} | {', '.join(r['owner'])} | "
          f"{_esc(str(r['state'])[:220])} | {_esc(r['evidence'])} | {_esc(r['clears'])} |" for i, r in enumerate(g["blockers"], 1)]
    return L


def render_md(g: dict) -> str:
    L = [f"**{NOTICE}**", "", f"# Client mode go-live gate ({TICKET})", "",
         f"Built {g['generated']} from `{g['data_dir']}`. Research mode: **{g['mode']}** (unchanged by this command). "
         f"client-check: {g['client_check']}", "",
         f"**{g['count']} blockers ({g['hard']} hard, marked *).** " + ("Go-live gate: PASS (Sam decides)." if g["ready"]
                                                                       else "Go-live gate: BLOCKED. Client mode stays off."), ""]
    L += table(g)
    return "\n".join(L) + "\n"


def render_card(g: dict) -> str:
    """The decision card text for Sam (prepared, never posted by this code)."""
    ids = ", ".join(f"`{r['id']}`" for r in g["blockers"]) or "none"
    L = [f"> **{MVP_LINE}**", "", "# Decision card (draft): client mode go-live", "",
         f"Ticket {TICKET}. Prepared from `econquest client-check --go-live` at {g['generated']}. INTERNAL; a checklist, "
         "not legal advice. Client mode is off and nothing here changes it.", "",
         "## Question", "", "Should client mode be switched on now, and if not, which blockers do you want worked first?", "",
         "## Facts", "",
         f"- The go-live gate lists **{g['count']} blockers ({g['hard']} hard)**: {ids}.",
         f"- Your recorded decision: {((g.get('decision') or {}).get('text')) or 'none'}",
         "- A DEMO licence baseline (EQ-C-0123) is shared-data evidence only and always counts as a blocker: only your own "
         "baseline clears `licence_baseline`.", "",
         "## Options", "",
         "**(a) Stay internal; revisit after the MVP, once licensed data is in place.** No change. The team keeps clearing the Team A / B / C rows.", "",
         "**(b) Go live once the gate exits 0.** You approve in principle now; the switch is still your `econquest change` on "
         "research.json, and only after every row below is cleared, counsel's included.", "",
         "**(c) Stop client work.** Record internal-only; the client code stays built and off.", "",
         "## Recommendation: (a) stay internal, revisit after the MVP with licensed data", "",
         "The rows that remain are yours or counsel's (licence baseline, IMF permission, adviser, disclaimer, independent "
         "approver, recipients) or wait on licensed data. None can be cleared by the team alone. Your call.", "",
         "## Blockers", ""]
    L += table(g)
    return "\n".join(L) + "\n"


def write(g: dict, outputs_dir) -> dict:
    from .client_pack import PACK_DIR, ClientPackError, _write
    out = Path(outputs_dir) / PACK_DIR
    if out.is_symlink() or (out.exists() and not out.is_dir()):
        raise ClientPackError(f"{out} is a symlink or not a folder: go-live report not written")
    out.mkdir(parents=True, exist_ok=True)
    files = {}
    for name, data in ((JSON_NAME, json.dumps(g, indent=1, default=str)), (MD_NAME, render_md(g)), (CARD_NAME, render_card(g))):
        b = data.encode("utf-8")
        if (out / name).is_symlink():
            raise ClientPackError(f"{out / name} is a symlink: not written")
        _write(out / name, b)
        files[name] = hashlib.sha256(b).hexdigest()
    return {"dir": str(out), "files": files}


def cmd(args, demo: dict | None = None) -> None:
    g = collect(args.data, args.out, demo=demo)
    res = write(g, args.out)
    if getattr(args, "json", False):
        print(json.dumps({"ready": g["ready"], "count": g["count"], "hard": g["hard"], "mode": g["mode"], "dir": res["dir"],
                          "blockers": [{k: r[k] for k in ("id", "owner", "hard")} for r in g["blockers"]]}, indent=1))
    else:
        print(NOTICE)
        for r in g["blockers"]:
            print(f"BLOCK{'*' if r['hard'] else ' '} {r['id']:26} [{', '.join(r['owner'])}] {str(r['state'])[:160]}")
        print(f"{g['count']} blockers ({g['hard']} hard). " + ("Go-live gate passes: Sam decides." if g["ready"] else
              f"Client mode stays {g['mode']}.") + f" Written to {res['dir']} ({', '.join(res['files'])}); card not posted.")
    if not g["ready"]:
        raise SystemExit(1)
