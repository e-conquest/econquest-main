"""INTERIM backtest page and monthly interim alert for the readiness view (EQ-C-0118).

Team B's interim report (validation.calendar_tests.interim_report, EQ-B-0107) is the only source of every number here;
nothing is computed in this module. It shows, clearly labelled INTERIM and never as the formal test:

    VaR99      exceptions so far against the expected count and Team B's two-sided 95% binomial band, the Basel
               traffic-light zone scaled to the current n, clean days collected against 250, days to the formal
               250-day test (2027-07-14)
    benchmark  snapshot rows and matured rows, the basis of the interim Brier scores, days to 12-month scoring (2027-10-23)
    ideas      ideas logged, closed and marked, hit rate and P&L net of assumed cost

Files read (written by Team B's code): outputs/calendar_tests/interim/interim_<as_of>.json (or interim_latest.json) and,
for the Basel zone, which the JSON does not carry, the same day's interim_<as_of>.csv row basel_zone_scaled
(HO-20261025-C-B-004 asks Team B to put it, and an explicit interim verdict, in the JSON).

    page(data_dir, out_dir, as_of)                read only: the readiness payload "interim_backtest" (GET /api/readiness),
                                                  with "explainer": Team B's backtest explainer section (EQ-C-0166, C18;
                                                  presentation/backtest_explainer_view.py), read from its files only
    job_step(home, as_of, now, log)               called by the calendar_tests job (ops/calendar_jobs.run) every run:
                                                  refreshes Team B's interim report, and on the first run of each
                                                  month raises one alert summarising it

Monthly alert: a row of kind "interim_backtest_monthly" in outputs/alerts.json through monitor.merge_alerts_json (the
same path as the calendar_ and ops_ rows), severity info (warning when Team B's band says "above band"). It is
composed once per calendar month of the job's as_of and kept in outputs/interim_backtest_alert.json; later runs in the
same month merge the same stored row again (so a daily report rewriting alerts.json does not lose it) and never raise a
second one. A month earlier than the last one raised is never raised. No email is sent or drafted; the job's exit code
is not changed by this alert. Tier 3, off the pipeline.
"""
from __future__ import annotations

import csv
import datetime as dt
import json
import re
from pathlib import Path

REL = "calendar_tests/interim"                 # under outputs/, Team B's write_interim folder
STATE_NAME = "interim_backtest_alert.json"
ALERT_KIND = "interim_backtest_monthly"
ALERT_PREFIX = "interim_backtest"
LABEL = "INTERIM, not the formal test"
MAX_BYTES = 2_000_000
_NAME = re.compile(r"^interim_(\d{4}-\d{2}-\d{2})\.json$")
TESTS = ("var_backtest_250d", "benchmark_12m", "idea_quarters_4q")


def _num(v):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    return None if f != f else f


def _int(v):
    f = _num(v)
    return None if f is None else int(f)


def _date(v) -> dt.date | None:
    try:
        return dt.date.fromisoformat(str(v).strip()[:10])
    except (TypeError, ValueError):
        return None


def _read_json(p: Path):
    try:
        if not p.is_file() or p.stat().st_size > MAX_BYTES:
            return None
        d = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return d if isinstance(d, dict) and d.get("kind") == "INTERIM" else None


def load_report(out_dir, as_of=None) -> dict | None:
    """Team B's newest interim report dated on or before as_of (any date when as_of is None), else None."""
    folder = Path(out_dir) / REL
    cut = _date(as_of) if as_of else None
    best = None
    try:
        names = sorted(p.name for p in folder.iterdir()) if folder.is_dir() else []
    except OSError:
        names = []
    for n in names:
        m = _NAME.match(n)
        d = _date(m.group(1)) if m else None
        if d and (cut is None or d <= cut) and (best is None or d > best[0]):
            best = (d, n)
    rep = _read_json(folder / best[1]) if best else None
    if rep is None:
        latest = _read_json(folder / "interim_latest.json")
        d = _date((latest or {}).get("as_of"))
        if latest and d and (cut is None or d <= cut):
            rep = latest
    return rep


def zone_from_csv(out_dir, as_of) -> str | None:
    """The scaled Basel zone Team B writes as the status of row var_to_date / basel_zone_scaled in interim_<as_of>.csv."""
    if not _date(as_of):
        return None
    p = Path(out_dir) / REL / f"interim_{_date(as_of).isoformat()}.csv"
    try:
        if not p.is_file() or p.stat().st_size > MAX_BYTES:
            return None
        with open(p, newline="", encoding="utf-8") as f:
            for r in csv.DictReader(f):
                if r.get("section") == "var_to_date" and r.get("metric") == "basel_zone_scaled":
                    z = str(r.get("status") or "").strip()
                    return z[:20] or None
    except (OSError, csv.Error):
        return None
    return None


def summarise(rep: dict, zone: str | None) -> dict:
    """The page sections from Team B's report dict. Missing fields stay None and are listed, never filled in."""
    f = rep.get("formal") if isinstance(rep.get("formal"), dict) else {}
    v = rep.get("var") if isinstance(rep.get("var"), dict) else {}
    b = rep.get("benchmark") if isinstance(rep.get("benchmark"), dict) else {}
    i = rep.get("ideas") if isinstance(rep.get("ideas"), dict) else {}
    fv, fb, fi = (f.get(t) if isinstance(f.get(t), dict) else {} for t in TESTS)
    z = v.get("zone_scaled") or v.get("basel_zone_scaled") or zone
    missing = [] if z else ["var zone (Basel zone scaled to n)"]
    tb = rep.get("verdicts") if isinstance(rep.get("verdicts"), dict) else {}
    if not tb:
        missing.append("interim verdict per test")
    months = [{"month": str(m.get("month") or "")[:7], "days": _int(m.get("days")), "exceptions": _int(m.get("exceptions"))}
              for m in (v.get("months") or []) if isinstance(m, dict)]
    brier = b.get("brier") if isinstance(b.get("brier"), dict) else {}
    var = {"days_collected": _int(v.get("tested_days")), "days_required": _int(fv.get("required")),
           "exceptions": _int(v.get("exceptions")), "expected": _num(v.get("expected")),
           "band": (str(v["band"])[:20] if v.get("band") else None), "zone": (str(z)[:20] if z else None),
           "zone_basis": "binomial cdf at the current n; the Basel table applies only at 250 days",
           "kupiec_p_interim": _num(v.get("kupiec_p_interim")), "formal_date": fv.get("formal_date"),
           "days_to_formal": _int(fv.get("days_to_formal")), "months": months}
    bench = {"snapshot_rows": _int(b.get("snapshot_rows")), "matured_rows": _int(b.get("matured_rows")),
             "basis": str(b.get("basis") or "")[:120], "brier_model": _num(brier.get("pd_model")),
             "brier_rating": _num(brier.get("pd_rating")), "formal_date": fb.get("formal_date"),
             "days_to_formal": _int(fb.get("days_to_formal"))}
    ideas = {"logged": _int(i.get("logged")), "closed_marked": _int(i.get("closed_marked")), "hit_rate": _num(i.get("hit_rate")),
             "pnl_net_mm": _num(i.get("pnl_net_mm")), "formal_date": fi.get("formal_date"),
             "days_to_formal": _int(fi.get("days_to_formal"))}
    tb = {t: str(tb[t])[:120] for t in TESTS if tb.get(t)}
    return {"var": var, "benchmark": bench, "ideas": ideas, "missing_fields": missing, "team_b_verdicts": tb}


def _f(v, fmt="{:.2f}", none="n/a"):
    return none if v is None else fmt.format(v)


def verdict_rows(s: dict) -> list[dict]:
    """The latest interim readings per test, in Team B's words (band and zone are Team B's classifications)."""
    v, b, i = s["var"], s["benchmark"], s["ideas"]
    vr = (f"{_f(v['exceptions'], '{}')} exceptions in {_f(v['days_collected'], '{}')} of {_f(v['days_required'], '{}')} clean days "
          f"against {_f(v['expected'])} expected ({v['band'] or 'band not given'}); zone {v['zone'] or 'not given'} (scaled to n); "
          f"Kupiec p {_f(v['kupiec_p_interim'])}, low power below 250 days")
    br = (f"{_f(b['matured_rows'], '{}')} of {_f(b['snapshot_rows'], '{}')} snapshot rows matured; {b['basis'] or 'basis not given'}; "
          f"interim Brier model {_f(b['brier_model'], '{:.3g}')}, rating-implied {_f(b['brier_rating'], '{:.3g}')}")
    ir = (f"{_f(i['logged'], '{}')} ideas logged, {_f(i['closed_marked'], '{}')} closed and marked; hit rate {_f(i['hit_rate'])}; "
          f"P&L net of assumed cost {_f(i['pnl_net_mm'])} $mm")
    no = "none in Team B's interim report"
    tb = s.get("team_b_verdicts") or {}
    return [{"test": "var_backtest_250d", "formal_date": v["formal_date"], "days_to_formal": v["days_to_formal"],
             "verdict": tb.get("var_backtest_250d") or v["band"] or no, "reading": vr},
            {"test": "benchmark_12m", "formal_date": b["formal_date"], "days_to_formal": b["days_to_formal"],
             "verdict": tb.get("benchmark_12m") or no, "reading": br},
            {"test": "idea_quarters_4q", "formal_date": i["formal_date"], "days_to_formal": i["days_to_formal"],
             "verdict": tb.get("idea_quarters_4q") or no, "reading": ir}]


def load_state(out_dir) -> dict:
    d = _read_plain(Path(out_dir) / STATE_NAME)
    return d if isinstance(d, dict) else {}


def _read_plain(p: Path):
    try:
        if not p.is_file() or p.stat().st_size > MAX_BYTES:
            return None
        return json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


def _explainer(out_dir) -> dict:
    """EQ-C-0166: the backtest explainer section (presentation.backtest_explainer_view, Team B's EQ-B-0141 files under
    <out>/backtest_explainer/, contract C18). Read only; never runs the explainer (about a minute, never on a GET)."""
    try:
        from ..presentation.backtest_explainer_view import explainer_page
        return explainer_page(out_dir)
    except Exception as e:                               # noqa: BLE001 - shown as unreadable
        return {"kind": "INTERIM", "status": "unreadable", "exceptions": [], "gaps": [],
                "message": f"Backtest explainer could not be read ({type(e).__name__})."}


def page(data_dir, out_dir, as_of=None) -> dict:
    """Read-only payload for the readiness view. Never writes, never computes a statistic, no absolute path."""
    cmd = "python -m econquest.validation.calendar_tests --as-of " + (str(as_of) if _date(as_of) else "YYYY-MM-DD") + " --interim"
    base = {"kind": "INTERIM", "label": LABEL, "source": f"outputs/{REL}/interim_<as_of>.json (Team B, EQ-B-0107)",
            "command": cmd, "monthly_alert": _alert_public(load_state(out_dir)), "explainer": _explainer(out_dir)}
    rep = load_report(out_dir, as_of)
    if rep is None:
        return base | {"status": "missing", "report_as_of": None, "verdicts": [],
                       "message": "INTERIM: no interim backtest report yet; the calendar_tests job writes one each run."}
    ra = _date(rep.get("as_of"))
    s = summarise(rep, zone_from_csv(out_dir, rep.get("as_of")))
    v = s["var"]
    stale = (_date(as_of) - ra).days if (_date(as_of) and ra) else None
    msg = (f"INTERIM, not the formal test (report as of {ra}): VaR99 {_f(v['exceptions'], '{}')} exceptions against "
           f"{_f(v['expected'])} expected, {v['band'] or 'band not given'}, zone {v['zone'] or 'not given'}; "
           f"{_f(v['days_collected'], '{}')} of {_f(v['days_required'], '{}')} clean days.")
    return base | s | {"status": "ok", "report_as_of": ra.isoformat() if ra else None, "stale_days": stale,
                       "verdicts": verdict_rows(s), "message": msg}


def _alert_public(st: dict) -> dict:
    a = st.get("alert") if isinstance(st.get("alert"), dict) else {}
    return {"month": st.get("month"), "raised_at": st.get("raised_at"), "as_of": st.get("as_of"),
            "message": a.get("message"), "severity": a.get("severity")}


def alert_row(rep: dict, zone: str | None, month: str) -> dict:
    s = summarise(rep, zone)
    v, b, i = s["var"], s["benchmark"], s["ideas"]
    msg = (f"INTERIM backtest, {month} (not the formal test; report as of {rep.get('as_of')}): VaR99 "
           f"{_f(v['exceptions'], '{}')} exceptions in {_f(v['days_collected'], '{}')} of {_f(v['days_required'], '{}')} clean days "
           f"against {_f(v['expected'])} expected, {v['band'] or 'band not given'}, zone {v['zone'] or 'not given'} (scaled); "
           f"formal 250-day test from {v['formal_date']} ({_f(v['days_to_formal'], '{}')} days). Benchmarks: "
           f"{_f(b['matured_rows'], '{}')} of {_f(b['snapshot_rows'], '{}')} snapshot rows matured; formal 12-month scoring from "
           f"{b['formal_date']}. Ideas: {_f(i['logged'], '{}')} logged, {_f(i['closed_marked'], '{}')} closed.")
    return {"severity": "warning" if v["band"] == "above band" else "info", "kind": ALERT_KIND, "scope": "validation",
            "country": None, "message": msg[:900], "value": v["band"] or "INTERIM", "threshold": v["formal_date"]}


def _team_b_report(as_of, data_dir, out_dir):
    from ..validation.calendar_tests import interim_report
    return interim_report(as_of, data_dir=str(data_dir), out_dir=str(out_dir), write=True)


def job_step(home, as_of, now: dt.datetime, log=print, report_fn=None, alerts_json: bool = True) -> dict:
    """Refresh Team B's interim report, then raise the month's interim alert once. Never raises; never emails."""
    from .monitor import merge_alerts_json
    home = Path(home); data_dir, out_dir = home / "data", home / "outputs"
    a = _date(as_of)
    if a is None:
        return {"month": None, "new": False, "message": "no as_of"}
    month = a.strftime("%Y-%m")
    rep = None
    try:
        rep = (report_fn or _team_b_report)(a.isoformat(), data_dir, out_dir)
    except Exception as e:                               # noqa: BLE001 - the last report on disk is used
        log(f"[interim] Team B interim_report failed ({type(e).__name__}); using the last report on disk")
    if not isinstance(rep, dict) or rep.get("kind") != "INTERIM":
        rep = load_report(out_dir, a.isoformat())
    st = load_state(out_dir)
    raised = [m for m in (st.get("months") or []) if isinstance(m, str)]
    new = False
    has_data = bool(rep) and bool(_int((rep.get("var") or {}).get("tested_days")))
    if month not in raised and (not raised or month > max(raised)) and has_data:
        row = alert_row(rep, zone_from_csv(out_dir, rep.get("as_of")), month)
        st = {"month": month, "as_of": a.isoformat(), "raised_at": now.astimezone(dt.timezone.utc).isoformat(timespec="seconds"),
              "alert": row, "months": sorted(set(raised) | {month})}
        out_dir.mkdir(parents=True, exist_ok=True)
        p = out_dir / STATE_NAME
        tmp = p.with_name("." + STATE_NAME + ".tmp"); tmp.write_text(json.dumps(st, indent=1)); tmp.replace(p)
        new = True
    cur = st.get("alert") if st.get("month") == month and isinstance(st.get("alert"), dict) else None
    if alerts_json and cur:
        try:
            merge_alerts_json(out_dir, [cur], now, prefix=ALERT_PREFIX)
        except Exception as e:                           # noqa: BLE001 - the state file still holds the alert
            log(f"[interim] alerts.json not updated ({type(e).__name__})")
    msg = ("raised the " + month + " interim alert" if new else
           ("the " + month + " interim alert was already raised" if cur else
            "no interim alert (no clean tested day in Team B's interim report)" if not has_data else
            "no interim alert for an earlier month"))
    log(f"[interim] {msg}; email: none (interim alerts are never emailed)")
    return {"month": month, "new": new, "message": msg, "report_as_of": (rep or {}).get("as_of")}
