"""Vendor onboarding wizard (EQ-C-0108): `econquest vendor check <vendor>` and the GUI card "Licensed vendor
onboarding", for the day a Bloomberg or LSEG market-data licence arrives (Team A's adapter framework,
econquest/ingestion/market/vendors/, runbook docs/runbooks/A-licensed-vendors.md).

Four steps, in order, each "done", "todo", "waiting" or "problem" with the command that moves it on:
1. Credentials and entitlement, by PRESENCE ONLY. Each credential the adapter reads is looked up in the environment,
   then the OS keychain, and only "present (environment)", "present (keychain)" or "absent" is kept: no value is
   printed, logged, returned or compared with anything. The licence entitlement (a contract record, not a credential)
   comes from Team A's licence gate (licence_state: package, licence ok / expired / not configured).
2. The licence scope row in data/licences.csv, through the governed path of EQ-C-0106 (`econquest change`): the
   approved register must hold a row matching this vendor's rows (source = the vendor slug, licence tag
   "<vendor>:<licence_id> (<scope>)"). Without one the wizard prints, and with propose_row records, a TIGHT row
   (client_output barred, validator_nda UNVERIFIED, terms UNVERIFIED): a tighten-only proposal that still needs an
   approval and an apply. Loosening it (client output, the validator room) is Sam's sign-off.
3. Ticker verification, without a session: every requested identifier is resolved through the ticker map
   (adapter.plan), and a fixture CSV of what the terminal showed (vendor_ticker plus any of iso, currency, tenor_y,
   doc_clause, instrument, unit) is compared with the map rows. The map itself is never changed here.
4. A first gated snapshot, DRY RUN ONLY: with dry_run_pull, pipeline.pull_to_store(..., dry_run=True) pulls and gates
   in memory and saves nothing. Without it nothing is requested and the command is shown. There is no non-dry path.

Everything stays off: nothing here enables an adapter, writes an entitlement, edits the ticker map or saves a
snapshot. Licence decisions are Sam's.
"""
from __future__ import annotations

import csv
import datetime as dt
import importlib
import io
import json
import os
import re
from pathlib import Path

TICKET = "EQ-C-0108"
RUNBOOK = "docs/runbooks/A-licensed-vendors.md"
VENDORS = ("bloomberg", "lseg")
STATES = ("done", "todo", "waiting", "problem")
FIXTURE_FIELDS = ("instrument", "iso", "currency", "tenor_y", "doc_clause", "unit")
MAX_FIXTURE_BYTES = 1_000_000
MAX_FIXTURE_ROWS = 500
MAX_TICKERS = 20
SAFE_TEXT = re.compile(r"[^\x20-\x7e]")


class VendorCheckError(ValueError):
    """Bad wizard input (unknown vendor, unreadable fixture, too many tickers)."""


def _clip(s, n: int = 160) -> str:
    return SAFE_TEXT.sub("?", str(s if s is not None else ""))[:n]


# ---------------------------------------------------------------- step 1: credentials (presence only)
def credential_specs(vendor: str, env) -> list[dict]:
    """[{name, needed, why, keyring_service}] for the credentials the adapter reads (names only)."""
    if vendor == "lseg":
        from ..ingestion.market.vendors import lseg as M
        platform = str(env.get(M.ENV_SESSION, "") or "desktop").strip().casefold() == "platform"
        return [{"name": M.ENV_APP_KEY, "needed": True, "why": "LSEG app key", "keyring_service": M.KEYRING_SERVICE},
                {"name": M.ENV_USER, "needed": platform, "why": "platform session only", "keyring_service": M.KEYRING_SERVICE},
                {"name": M.ENV_PASSWORD, "needed": platform, "why": "platform session only",
                 "keyring_service": M.KEYRING_SERVICE}]
    from ..ingestion.market.vendors import bloomberg as M
    bpipe = bool(str(env.get(M.ENV_BPIPE_HOST, "") or "").strip())
    return [{"name": M.ENV_BPIPE_APP, "needed": bpipe,
             "why": "B-PIPE application name (Desktop API: the Terminal login is the entitlement)", "keyring_service": None}]


def _keyring_has(service: str, account: str) -> bool:
    try:
        keyring = importlib.import_module("keyring")
    except ImportError:
        return False
    try:
        return bool(str(keyring.get_password(service, account) or "").strip())
    except Exception:                                   # noqa: BLE001 - any backend failure means "absent"
        return False


def presence(name: str, env, keyring_service: str | None, keychain=None) -> str:
    """'environment', 'keychain' or 'absent'. The value is only tested for being non-empty, never kept."""
    if str(env.get(name, "") or "").strip():
        return "environment"
    if keyring_service:
        has = keychain(keyring_service, name) if keychain is not None else _keyring_has(keyring_service, name)
        if has:
            return "keychain"
    return "absent"


def _step_credentials(vendor, adapter, env, keychain) -> dict:
    rows, missing = [], []
    for s in credential_specs(vendor, env):
        where = presence(s["name"], env, s["keyring_service"], keychain)
        rows.append({"credential": s["name"], "needed": "yes" if s["needed"] else "no", "status":
                     "absent" if where == "absent" else f"present ({where})", "why": s["why"]})
        if s["needed"] and where == "absent":
            missing.append(s)
    st = adapter.licence_state()
    ent = st.entitlement
    lic = {"package": st.package, "package_ok": st.package_ok, "licence": st.licence,
           "licence_id": ent.licence_id if ent else "", "scope": ent.scope if ent else "",
           "expiry": ent.expiry.isoformat() if ent else ""}
    detail = [f"package {st.package}: {'importable' if st.package_ok else 'not installed'}; licence entitlement: "
              f"{st.licence}" + (f" ({ent.licence_id}, {ent.scope}, expires {ent.expiry.isoformat()})" if ent else "")]
    detail += [_clip(p, 300) for p in st.problems]
    cmds = []
    for s in missing:
        if s["keyring_service"]:
            cmds.append(f"python -c \"import keyring, getpass; keyring.set_password('{s['keyring_service']}', "
                        f"'{s['name']}', getpass.getpass('{s['name']}: '))\"")
        else:
            cmds.append(f"export {s['name']}=<value from the vendor onboarding>   # environment only, never a file")
    if ent is None:
        cmds.append(f"export ECONQUEST_VENDOR_LICENCE_{vendor.upper()}='licence_id=<contract ref>;holder=<desk>;"
                    "scope=desk-internal;expiry=YYYY-MM-DD'   # Sam's licence decision")
    state = "done" if (not missing and st.usable) else "todo"
    return {"n": 1, "title": "Credentials (presence only) and licence entitlement", "state": state, "detail": detail,
            "rows": rows, "licence": lic, "commands": cmds}


# ---------------------------------------------------------------- step 2: licence scope row (governed)
def proposed_row(vendor: str, display: str, licence_id: str = "", scope: str = "desk-internal") -> dict:
    """The tight register row the wizard proposes for a vendor (allows nothing new: a tighten-only change)."""
    from ..ingestion.licences import REGISTER_COLUMNS
    row = {c: "" for c in REGISTER_COLUMNS if c != "source_id"}
    lid = licence_id or "<licence id>"
    row.update(name=f"{display} market data (licensed vendor adapter, {TICKET})", match_source=f"^{vendor}$",
               match_licence=f"^{vendor}:",
               licence_text=f"{display} data licence {lid} ({scope}): contract terms UNVERIFIED until Sam files them; "
                            "desk-internal unless a redistribution licence is recorded (EQ-A-0033)",
               terms_verified="UNVERIFIED", commercial="unknown", internal_use="yes", client_output="barred",
               validator_nda="UNVERIFIED",
               notes=f"Proposed by econquest vendor check ({TICKET}); client output or the validator room is a "
                     "decision for Sam (a loosening through econquest change)")
    return row


def register_patch_commands(vendor: str, ent) -> list[str]:
    """HO-20261025-A-C-023: the go-live kit's path for a vendor whose register row already exists (EQ-A-0093): write
    the patch for ONE signed licence (golive register-patch), then propose it through econquest change (Sam approves:
    it loosens the row)."""
    lid = (ent.licence_id if ent is not None and ent.licence_id else "<licence id>")
    scope = ent.scope if ent is not None and ent.scope else "desk-internal"
    patch = f"{vendor}-register-patch.json"
    return [f"econquest vendor golive register-patch --vendor {vendor} --licence-id {lid} --scope {scope} "
            f"--terms-url <terms url> --terms-read <YYYY-MM-DD> --clause \"<quoted clause>\" "
            f"--licence-text \"<licence text>\" --out {patch}",
            f"econquest change propose licences.csv --patch-file {patch} --author \"<your name>\" "
            f"--reason \"{vendor} licence {lid} (EQ-A-0107)\"",
            "econquest change approve <CHG id> --approver <second person>", "econquest change apply <CHG id>"]


def _row_exists(vendor: str, rows: list[dict], data_dir) -> bool:
    """A register row for this vendor already exists (approved register, or data/licences.csv as shipped)."""
    if any(str(r.get("source_id", "")) == vendor for r in rows):
        return True
    try:
        from ..ingestion import licences as A
        return any(str(r.get("source_id", "")) == vendor for r in A.load_register(A.register_path(data_dir=data_dir)))
    except Exception:                                   # noqa: BLE001 - no readable shipped register: propose a row
        return False


def _step_register(vendor, adapter, data_dir, propose_row: bool, author) -> dict:
    from . import licence_gov as G
    from ..ingestion import licences as A
    st = G.state(data_dir)
    out = {"n": 2, "title": "Licence scope row in data/licences.csv (econquest change)", "detail": [], "commands": [],
           "row": None, "proposal": None}
    if st["status"] != "ok":
        out.update(state="waiting", detail=[_clip(G.problem(data_dir, st) or st["status"], 600)],
                   commands=[G.FIRST_BASELINE_CMD] if st["status"] == "no_baseline" else ["econquest change verify"])
        return out
    try:
        rows = G.parse(G.approved_bytes(data_dir, st) or b"", "approved data/licences.csv")
    except G.LicenceGovError as e:
        out.update(state="problem", detail=[_clip(e, 400)])
        return out
    ent = adapter.licence_state().entitlement
    tag = ent.tag if ent else f"{vendor}:<licence id> (desk-internal)"
    hit = A.licence_for(source=vendor, licence=tag, register=rows)
    if hit:
        keep = ("source_id", "terms_verified", "internal_use", "client_output", "validator_nda", "exc_id")
        out["row"] = {k: hit.get(k, "") for k in keep}
        out["detail"].append("approved register row " + ", ".join(f"{k}={hit.get(k, '')}" for k in keep[1:]))
        if ent is not None and ent.scope == "desk-internal" and hit.get("client_output") == "allowed":
            out.update(state="problem")
            out["detail"].append("the entitlement is desk-internal but the row allows client output: tighten the row "
                                 f"(econquest change propose licences.csv --set '/{hit['source_id']}/client_output=\"barred\"')")
        else:
            out["state"] = "done"
        if str(hit.get("terms_verified", "")).strip().lower() != "yes":     # HO-20261025-A-C-023: tight row exists
            out["detail"].append("the row is the tight placeholder (terms not verified): after the licence is signed, "
                                 "turn it into an approved row with the go-live kit (docs/runbooks/A-licensed-go-live.md step 4)")
            out["commands"] = register_patch_commands(vendor, ent)
        return out
    if not propose_row and _row_exists(vendor, rows, data_dir):         # HO-20261025-A-C-023: never a second row
        out.update(state="todo", commands=register_patch_commands(vendor, ent))
        out["detail"].append(f"data/licences.csv already has a {vendor} row (EQ-A-0093) but it does not match licence "
                             f"{tag!r} in the approved register: patch that row for the signed licence with the go-live kit "
                             "(docs/runbooks/A-licensed-go-live.md step 4) instead of adding a new one")
        return out
    row = proposed_row(vendor, adapter.display or vendor, ent.licence_id if ent else "", ent.scope if ent else "desk-internal")
    arg = json.dumps(row, separators=(",", ":"))
    cmd = (f"econquest change propose licences.csv --set '/{vendor}={arg}' --allow-new-keys "
           f"--author \"<your name>\" --reason \"{vendor} licence row ({TICKET})\"")
    out.update(state="todo", commands=[cmd, "econquest change approve <CHG id> --approver <second person>",
                                       "econquest change apply <CHG id>"])
    out["detail"].append(f"no row in the approved register matches source {vendor!r} / licence {tag!r}: vendor rows would "
                         "be unregistered (internal-only for client output). The proposed row allows nothing new "
                         "(client_output barred, validator_nda UNVERIFIED): a tighten-only change")
    if propose_row:
        from . import approvals as ap
        if not str(author or "").strip():
            raise VendorCheckError("--propose-row needs --author")
        try:
            p = ap.propose(data_dir, "licences.csv", {f"/{vendor}": row}, author, f"{vendor} licence row ({TICKET})",
                           allow_new_keys=True)
        except ap.ApprovalError as e:
            out.update(state="problem")
            out["detail"].append(_clip(f"proposal refused: {e}", 400))
            return out
        out["proposal"] = {"id": p["id"], "tier": p["tier"], "loosens": p["loosens"]}
        out["detail"].append(f"recorded proposal {p['id']} (tier {p['tier']}); it changes nothing until approved and applied")
        out["commands"] = [f"econquest change show {p['id']}", f"econquest change approve {p['id']} --approver <second person>",
                           f"econquest change apply {p['id']}"]
    return out


# ---------------------------------------------------------------- step 3: tickers
def read_fixture(path) -> list[dict]:
    """Rows of a fixture CSV (vendor_ticker plus optional FIXTURE_FIELDS): what the terminal showed for each id."""
    p = Path(path)
    if p.is_symlink() or not p.is_file():
        raise VendorCheckError("fixture is missing or not a regular file")
    raw = p.read_bytes()
    if len(raw) > MAX_FIXTURE_BYTES:
        raise VendorCheckError(f"fixture is larger than {MAX_FIXTURE_BYTES} bytes")
    try:
        rd = csv.DictReader(io.StringIO(raw.decode("utf-8-sig"), newline=""))
        cols = [str(c).strip() for c in rd.fieldnames or []]
        recs = list(rd)
    except (UnicodeDecodeError, csv.Error) as e:
        raise VendorCheckError(f"fixture is not a UTF-8 CSV ({type(e).__name__})") from None
    if "vendor_ticker" not in cols:
        raise VendorCheckError("fixture needs a vendor_ticker column")
    if len(recs) > MAX_FIXTURE_ROWS:
        raise VendorCheckError(f"fixture has more than {MAX_FIXTURE_ROWS} rows")
    return [{str(k).strip(): str(v or "").strip() for k, v in r.items() if k is not None} for r in recs]


def _norm_id(s) -> str:
    """Identifier key as the ticker map compares them (whitespace collapsed, case folded)."""
    return " ".join(str(s).split()).casefold()


def _same(field: str, a: str, b: str) -> bool:
    if field == "tenor_y":
        try:
            return float(a) == float(b)
        except ValueError:
            return False
    return a.strip().casefold() == b.strip().casefold()


def _step_tickers(vendor, adapter, tickers, fixture) -> dict:
    from ..ingestion.market.vendors import VendorRequestError
    from ..ingestion.market.schema import MarketDataError
    out = {"n": 3, "title": "Ticker verification (ticker map, no session)", "detail": [], "commands": [], "rows": []}
    try:
        m = adapter.ticker_map()
    except (VendorRequestError, MarketDataError, OSError) as e:
        out.update(state="todo", detail=[_clip(e, 300)],
                   commands=["python -c \"from econquest.ingestion.market import importers; importers.ensure_ticker_map('data')\""])
        return out
    verified = int((m["status"].str.casefold() == "verified").sum())
    out["detail"].append(f"{len(m)} {vendor} rows in the ticker map, {verified} verified")
    problems = []
    for t in list(tickers or [])[:MAX_TICKERS]:
        try:
            items = adapter.plan([t])
            out["rows"].append({"ticker": _clip(t, 60), "check": "plan", "result": f"ok ({len(items)} field(s))"})
        except VendorRequestError as e:
            problems.append(t)
            out["rows"].append({"ticker": _clip(t, 60), "check": "plan", "result": _clip(e, 240)})
    if fixture:
        by = {_norm_id(r.vendor_ticker): r for r in m.itertuples(index=False)}
        for f in fixture:
            t = f.get("vendor_ticker", "")
            r = by.get(_norm_id(t))
            if r is None:
                problems.append(t)
                out["rows"].append({"ticker": _clip(t, 60), "check": "fixture", "result": "no ticker map row"})
                continue
            diff = [f"{k}: map {getattr(r, k)!r} vs fixture {f[k]!r}" for k in FIXTURE_FIELDS
                    if f.get(k) and not _same(k, str(getattr(r, k)), f[k])]
            if diff:
                problems.append(t)
            out["rows"].append({"ticker": _clip(t, 60), "check": "fixture",
                                "result": _clip("; ".join(diff), 240) if diff else
                                f"matches the map (status {r.status or 'blank'})"})
    if problems:
        out["state"] = "problem"
        out["detail"].append("fix the ticker map rows above against the terminal (runbook section 3); the map is never "
                             "changed here")
    elif tickers or fixture:
        out["state"] = "done"
    else:
        out["state"] = "todo"
        out["detail"].append("name the identifiers to check: --ticker T (repeat) and/or --fixture FILE")
    return out


# ---------------------------------------------------------------- step 4: dry-run snapshot
def _step_dry_run(vendor, adapter, data_dir, tickers, as_of, dry_run_pull: bool, ready: bool) -> dict:
    out = {"n": 4, "title": "First gated snapshot (dry run only: nothing saved)", "detail": [], "commands": [],
           "result": None}
    t = " ".join(f"--ticker '{_clip(x, 60)}'" for x in list(tickers or [])[:MAX_TICKERS]) or "--ticker <verified id>"
    cmd = f"econquest vendor check {vendor} {t} --as-of {as_of or '<last business day>'} --dry-run-pull"
    if not ready:
        out.update(state="waiting", detail=["waits on steps 1 and 3 (a usable licence and verified tickers)"],
                   commands=[cmd])
        return out
    if not dry_run_pull:
        out.update(state="todo", detail=["opens a vendor session on this machine, pulls and gates in memory; saves "
                                          "nothing. Compare every value with the terminal screen (runbook section 5)"],
                   commands=[cmd])
        return out
    from ..ingestion.market import MarketDataError
    from ..ingestion.market.vendors import VendorConnectionError, VendorNotLicensed, VendorRequestError
    from ..ingestion.market.vendors import pipeline
    try:
        res = pipeline.pull_to_store(adapter, data_dir, list(tickers), as_of=as_of, dry_run=True)
    except (VendorNotLicensed, VendorRequestError, VendorConnectionError, MarketDataError, OSError) as e:
        out.update(state="problem", detail=[_clip(e, 400)])
        return out
    if not res.dry_run or res.snapshot is not None:              # defence: never a saved snapshot from here
        raise VendorCheckError("dry run expected; refusing")
    held = int((res.review["status"] != "ok").sum()) if len(res.review) and "status" in res.review else 0
    out["result"] = {"summary": _clip(res.summary(), 300), "rows": int(len(res.rows)), "held": held,
                     "vendor_errors": len(res.vendor_errors)}
    out["detail"].append(_clip(res.summary(), 300))
    out["state"] = "done" if len(res.rows) and not res.vendor_errors else "problem"
    out["commands"] = [f"econquest vendor pull {vendor} {t} --as-of {as_of or '<date>'}   # only after the values "
                       "match the terminal; Sam's call"]
    return out


# ---------------------------------------------------------------- the wizard
def collect(data_dir, vendor: str, tickers=None, fixture=None, as_of=None, dry_run_pull: bool = False,
            propose_row: bool = False, author=None, env=None, keychain=None, module=None, mapping=None,
            today: dt.date | None = None) -> dict:
    """The four steps for `vendor`. Opens no session unless dry_run_pull (and then only a dry run). `fixture` is a path
    or rows from read_fixture. env / keychain / module / mapping / today are for tests."""
    from ..ingestion.market.vendors import get_adapter
    if vendor not in VENDORS:
        raise VendorCheckError(f"vendor must be one of {', '.join(VENDORS)}")
    tickers = [str(t).strip() for t in (tickers or []) if str(t).strip()]
    if len(tickers) > MAX_TICKERS:
        raise VendorCheckError(f"at most {MAX_TICKERS} tickers")
    if fixture is not None and not isinstance(fixture, list):
        fixture = read_fixture(fixture)
    env = os.environ if env is None else env
    d = Path(data_dir)
    kw = {"data_dir": d, "env": env, "today": today}
    if module is not None:
        kw["module"] = module
    if mapping is not None:
        kw["mapping"] = mapping
    adapter = get_adapter(vendor, **kw)
    s1 = _step_credentials(vendor, adapter, env, keychain)
    s2 = _step_register(vendor, adapter, d, propose_row, author)
    s3 = _step_tickers(vendor, adapter, tickers, fixture)
    s4 = _step_dry_run(vendor, adapter, d, tickers, as_of, dry_run_pull,
                       ready=s1["state"] == "done" and s3["state"] == "done" and bool(tickers))
    steps = [s1, s2, s3, s4]
    return {"ticket": TICKET, "vendor": vendor, "runbook": RUNBOOK,
            "generated_utc": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "done": sum(s["state"] == "done" for s in steps), "total": len(steps),
            "session_opened": bool(dry_run_pull and s4.get("result") is not None),
            "note": "Paid roadmap feature, off by default. Credentials are checked by presence only; nothing is enabled, "
                    "no entitlement is written, the ticker map is not changed, and no snapshot is saved.",
            "steps": steps}


def render(rep: dict) -> str:
    mark = {"done": "[x]", "todo": "[ ]", "waiting": "[.]", "problem": "[!]"}
    L = [f"Vendor onboarding check: {rep['vendor']} ({rep['done']}/{rep['total']} done; {TICKET}, runbook {RUNBOOK})",
         rep["note"], ""]
    for s in rep["steps"]:
        L.append(f"{mark.get(s['state'], '[?]')} {s['n']}. {s['title']}: {s['state']}")
        for r in s.get("rows") or []:
            L.append("      " + "  ".join(f"{k}={v}" for k, v in r.items()))
        L += [f"      {x}" for x in s.get("detail") or []]
        L += [f"      $ {c}" for c in s.get("commands") or []]
    return "\n".join(L)


def run_from_args(args) -> int:
    """`econquest vendor check`: prints the wizard (text or --json); exit 0 when every step is done, else 1."""
    try:
        rep = collect(args.data, args.vendor, tickers=args.ticker, fixture=args.fixture, as_of=args.asof,
                      dry_run_pull=args.dry_run_pull, propose_row=args.propose_row, author=args.author)
    except VendorCheckError as e:
        print(f"vendor check: {e}")
        return 2
    print(json.dumps(rep, indent=1, default=str) if args.json else render(rep))
    return 0 if rep["done"] == rep["total"] else 1
