"""Client mode SANDBOX (EQ-C-0145, SEC-C-021): a test outbox, never a delivery. Client mode itself stays OFF (Sam's
decision 2026-10-25 11:29Z: client mode later; docs/research/client-mode-decision-pack.md).

    econquest client-outbox build  --sandbox [--entitlements F] [--run NAME] [--date D] [--demo-baseline] [--json]
    econquest client-outbox send   --sandbox --run NAME [--recipient ADDR ...] [--json]
    econquest client-outbox verify [--run NAME] [--json]                       reads only; exit 1 on any problem
    econquest client-outbox reset  --sandbox [--run NAME] [--json]             deletes sandbox runs only

What it does, all under <out>/client-outbox/<run>/ (by default <home>/outputs/client-outbox/):
- reads a TEST entitlements file (synthetic client ids TEST-..., allowed products and countries, recipients on reserved
  test addresses only: example.com and its subdomains, *.test, *.invalid). With no --entitlements the built-in SAMPLE
  is used (also shipped as docs/research/client-sandbox-entitlements.sample.json). Anything else refuses the file;
- build: one pack per test client through the existing licence rules (presentation/licences.safe_evaluate): every
  cell that enforcement lists as internal-only, and every cell with no provenance record, is withheld ("fails closed");
  pages carry the attribution lines. The licence baseline may be Sam's real one, none yet, or the DEMO baseline
  (--demo-baseline, ops/demo_baseline.active); a DEMO baseline is accepted ONLY here, in the sandbox, and is printed on
  every page. Drift, a missing or symlinked register, a broken chain or an incomplete evaluation refuse the build;
- send: "distribution" = files on disk. For each allow-listed recipient (the entitlements file is the allow-list) the
  client's pages are copied to <run>/<recipient>/ with a per-recipient sandbox id, plus manifest.json (sha256 per
  file); run.json records each manifest's sha256. Every page carries "SANDBOX - NOT FOR CLIENTS" (title, meta, fixed
  overlay, top bar, recipient line, footer) and the recipient's sandbox id;
- verify: every hash, every watermark, no unlisted file, no symlink;
- reset: removes sandbox runs (run.json says sandbox) and nothing else.

Refusals (SandboxError; nothing is written): no --sandbox flag (real use), a recipient that is not a reserved test
address or not on the allow-list, a DEMO profile outside the sandbox. REAL USE IS ALWAYS REFUSED HERE: until Sam's
signed go-live (research.json mode client through `econquest change`, presentation/client_build.gate) the reason is the
gate's; after it, real deliveries still go only through `econquest client-export` (EQ-C-0107). This module changes no
setting, licence, approval or credential, and has no mail or network code at all (no smtplib, socket, urllib, http):
tests/test_client_outbox.py checks its imports.
"""
from __future__ import annotations

import contextlib
import csv
import datetime as dt
import hashlib
import html as _h
import json
import re
import shutil
from pathlib import Path

TICKET = "EQ-C-0145"
BANNER = "SANDBOX - NOT FOR CLIENTS"
OUTBOX = "client-outbox"
BUILD_DIR = "_build"
RUN_FILE, MANIFEST, ENT_FILE = "run.json", "manifest.json", "entitlements.json"
ENT_FORMAT = "econquest-client-sandbox-entitlements/1"
RUN_FORMAT = "econquest-client-sandbox-run/1"
MAX_ENT_BYTES = 256_000
MAX_CLIENTS, MAX_RECIPIENTS, MAX_COUNTRIES = 50, 10, 40
SANDBOX_STATES = ("ok", "demo", "no_baseline")      # licence_gov.state statuses the sandbox builds on
PRODUCTS = {"country_inputs": "Country inputs page (one per entitled country), licence-withheld cells blanked",
            "licence_summary": "Licence summary: baseline, sources, attribution, why real client use is refused"}
CLIENT_ID_RE = re.compile(r"TEST-[A-Z0-9][A-Z0-9-]{0,31}")
LABEL_RE = re.compile(r"[A-Za-z0-9 ._()-]{0,60}")
RUN_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{0,47}")
ADDR_RE = re.compile(r"[a-z0-9](?:[a-z0-9._+-]{0,62}[a-z0-9])?@(?:[a-z0-9](?:[a-z0-9-]{0,61}[a-z0-9])?\.)+[a-z]{2,63}")
RESERVED = "example.com, its subdomains, *.test or *.invalid (RFC 2606 / RFC 6761)"
PLACEHOLDER = "<!-- eq-sandbox-recipient -->"
META_SBX = f'<meta name="eq-sandbox" content="{BANNER}">'

SAMPLE = {
    "format": ENT_FORMAT, "sandbox": True, "synthetic": True,
    "note": ("SAMPLE ONLY (EQ-C-0145). Synthetic test clients on reserved test addresses (RFC 2606 / RFC 6761). No real "
             "client, person or address. Sandbox only: real recipients are refused until Sam's signed go-live."),
    "clients": [
        {"client_id": "TEST-CLIENT-001", "label": "Synthetic test client A",
         "recipients": ["analyst-a@client-a.example.com", "pm-a@client-a.example.com"],
         "products": ["country_inputs", "licence_summary"], "countries": ["Brazil", "Vietnam", "Singapore"]},
        {"client_id": "TEST-CLIENT-002", "label": "Synthetic test client B",
         "recipients": ["research@client-b.test"], "products": ["licence_summary"], "countries": ["Japan"]},
        {"client_id": "TEST-CLIENT-003", "label": "Synthetic test client C",
         "recipients": ["desk@client-c.invalid"], "products": ["country_inputs"], "countries": ["Nigeria", "Zambia"]},
    ],
}


class SandboxError(ValueError):
    """A refused sandbox action (real use, a non-test recipient, a bad entitlements file, an unsafe folder ...)."""


# ---------------------------------------------------------------- addresses, entitlements
def is_test_address(addr) -> bool:
    """True only for a plain ASCII address on a reserved test domain (example.com and subdomains, *.test, *.invalid)."""
    if not isinstance(addr, str) or addr != addr.strip() or not ADDR_RE.fullmatch(addr.casefold()) or ".." in addr:
        return False
    dom = addr.casefold().rsplit("@", 1)[1]
    return dom == "example.com" or dom.endswith((".example.com", ".test", ".invalid"))


def check_test_address(addr, what: str = "recipient") -> str:
    if not is_test_address(addr):
        raise SandboxError(f"{what} {str(addr)[:80]!r} is not a reserved test address ({RESERVED}): real recipients are "
                           "refused until Sam's signed go-live, and even then only through `econquest client-export`")
    return addr.casefold()


def parse_entitlements(raw: bytes, where: str = "entitlements") -> dict:
    """Validate a test entitlements file; SandboxError on anything that is not clearly synthetic test data."""
    if len(raw) > MAX_ENT_BYTES:
        raise SandboxError(f"{where} is larger than {MAX_ENT_BYTES} bytes")
    try:
        doc = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, ValueError) as e:
        raise SandboxError(f"{where} is not UTF-8 JSON ({type(e).__name__})") from None
    if not isinstance(doc, dict) or set(doc) - {"format", "sandbox", "synthetic", "note", "clients"}:
        raise SandboxError(f"{where}: unknown or missing top-level keys (format, sandbox, synthetic, note, clients)")
    if doc.get("format") != ENT_FORMAT or doc.get("sandbox") is not True or doc.get("synthetic") is not True:
        raise SandboxError(f"{where} must say format {ENT_FORMAT}, sandbox true and synthetic true")
    clients = doc.get("clients")
    if not isinstance(clients, list) or not 1 <= len(clients) <= MAX_CLIENTS:
        raise SandboxError(f"{where}: clients must be a list of 1 to {MAX_CLIENTS} test clients")
    seen_ids, seen_addr, out = set(), {}, []
    for i, c in enumerate(clients):
        w = f"{where} clients[{i}]"
        if not isinstance(c, dict) or set(c) - {"client_id", "label", "recipients", "products", "countries"}:
            raise SandboxError(f"{w}: unknown keys (client_id, label, recipients, products, countries)")
        cid = c.get("client_id")
        if not isinstance(cid, str) or not CLIENT_ID_RE.fullmatch(cid):
            raise SandboxError(f"{w}: client_id must be a synthetic id TEST-... (A-Z, 0-9, -)")
        if cid in seen_ids:
            raise SandboxError(f"{w}: duplicate client_id {cid}")
        seen_ids.add(cid)
        label = c.get("label", "")
        if not isinstance(label, str) or not LABEL_RE.fullmatch(label):
            raise SandboxError(f"{w}: label must be plain text (letters, digits, space . _ ( ) -), at most 60 characters")
        rc = c.get("recipients")
        if not isinstance(rc, list) or not 1 <= len(rc) <= MAX_RECIPIENTS:
            raise SandboxError(f"{w}: recipients must be 1 to {MAX_RECIPIENTS} test addresses")
        rcpts = []
        for a in rc:
            a = check_test_address(a, f"{w} recipient")
            if a in seen_addr:
                raise SandboxError(f"{w}: {a} is already a recipient of {seen_addr[a]}")
            seen_addr[a] = cid
            rcpts.append(a)
        prods = c.get("products")
        if not isinstance(prods, list) or not prods or any(p not in PRODUCTS for p in prods) or len(set(prods)) != len(prods):
            raise SandboxError(f"{w}: products must be a non-empty list from {sorted(PRODUCTS)}")
        cts = c.get("countries")
        if (not isinstance(cts, list) or not 1 <= len(cts) <= MAX_COUNTRIES or len(set(cts)) != len(cts)
                or not all(isinstance(x, str) and 0 < len(x) <= 60 for x in cts)):
            raise SandboxError(f"{w}: countries must be 1 to {MAX_COUNTRIES} distinct country names or ISO3 codes")
        out.append({"client_id": cid, "label": label, "recipients": rcpts, "products": list(prods), "countries": list(cts)})
    return {"format": ENT_FORMAT, "sandbox": True, "synthetic": True, "note": str(doc.get("note", ""))[:400], "clients": out}


def load_entitlements(path=None) -> tuple[dict, bytes]:
    """(entitlements, canonical bytes). path None: the built-in SAMPLE."""
    if path is None:
        raw = json.dumps(SAMPLE, indent=1).encode("utf-8")
        return parse_entitlements(raw, "built-in SAMPLE"), raw
    p = Path(path)
    if p.is_symlink() or not p.is_file():
        raise SandboxError(f"entitlements file {p} is missing or a symlink")
    if p.stat().st_size > MAX_ENT_BYTES:
        raise SandboxError(f"entitlements file {p} is larger than {MAX_ENT_BYTES} bytes")
    raw = p.read_bytes()
    return parse_entitlements(raw, p.name), raw


def allow_list(ent: dict) -> dict[str, str]:
    """{recipient: client_id}: the test allow-list is exactly the recipients in the entitlements file."""
    return {a: c["client_id"] for c in ent["clients"] for a in c["recipients"]}


# ---------------------------------------------------------------- refusals
def real_use_refusal(data_dir, what: str = "client-outbox") -> str:
    """Why `what` refuses real (non-sandbox) use. Always a reason: before Sam's signed go-live it is the client build
    gate's; after it, real deliveries go only through `econquest client-export`."""
    from . import licence_gov as G
    why = G.demo_refusal(f"{what} outside the sandbox")
    if why:
        return why
    try:
        from ..presentation.client_build import gate
        g = gate(data_dir)
    except Exception as e:                                      # noqa: BLE001 - cannot tell: refused
        g = {"ok": False, "problems": [f"the client build gate could not be checked ({type(e).__name__})"]}
    if not g["ok"]:
        return (f"{what} refused for real use: there is no signed go-live. " + "; ".join(g["problems"][:4])
                + ". Real client use needs Sam's signed go-live through `econquest change` (team/when-sam-is-ready.md); "
                "pass --sandbox for the test outbox (synthetic clients, reserved test addresses only)")
    return (f"{what} refused for real use: it is a sandbox and never delivers to real clients. With client mode on, real "
            "deliveries go through `econquest client-export` (EQ-C-0107); pass --sandbox for the test outbox")


def _require_sandbox(sandbox: bool, data_dir, what: str) -> None:
    if sandbox is not True:
        raise SandboxError(real_use_refusal(data_dir, what))


# ---------------------------------------------------------------- folders and files
def outbox_dir(outputs_dir) -> Path:
    return Path(outputs_dir) / OUTBOX


def _safe_dir(p: Path, what: str) -> Path:
    if p.is_symlink() or (p.exists() and not p.is_dir()):
        raise SandboxError(f"{what} {p} is a symlink or not a folder: refused")
    return p


def _run_dir(outputs_dir, run: str) -> Path:
    if not isinstance(run, str) or not RUN_RE.fullmatch(run):
        raise SandboxError("run name must be 1-48 characters: letters, digits, _ and - (not starting with _ or -)")
    box = _safe_dir(outbox_dir(outputs_dir), "outbox")
    return _safe_dir(box / run, "run folder")


def _sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def _write_new(p: Path, data: bytes) -> dict:
    if p.exists() or p.is_symlink():
        raise SandboxError(f"{p} already exists: refused (reset the run first)")
    with open(p, "xb") as f:                                    # exclusive create: never follows or overwrites
        f.write(data)
    return {"name": p.name, "sha256": _sha(data), "bytes": len(data)}


def _write_json(p: Path, doc: dict) -> bytes:
    if p.is_symlink():
        raise SandboxError(f"{p} is a symlink: refused")
    b = (json.dumps(doc, indent=1, sort_keys=True) + "\n").encode("utf-8")
    tmp = p.with_name(f".{p.name}.tmp")
    if tmp.is_symlink():
        tmp.unlink()
    tmp.write_bytes(b)
    tmp.replace(p)
    return b


def _read_json(p: Path, what: str) -> tuple[dict, bytes]:
    if p.is_symlink() or not p.is_file():
        raise SandboxError(f"{what} {p.name} is missing or a symlink")
    b = p.read_bytes()
    try:
        d = json.loads(b.decode("utf-8"))
    except (UnicodeDecodeError, ValueError):
        raise SandboxError(f"{what} {p.name} is not readable JSON") from None
    if not isinstance(d, dict):
        raise SandboxError(f"{what} {p.name} is not a JSON object")
    return d, b


def _load_run(rd: Path) -> tuple[dict, bytes]:
    d, b = _read_json(rd / RUN_FILE, "run record")
    if d.get("format") != RUN_FORMAT or d.get("sandbox") is not True:
        raise SandboxError(f"{rd.name}/{RUN_FILE} is not a sandbox run record")
    return d, b


# ---------------------------------------------------------------- data and licence rules
def _indicators(data_dir) -> tuple[list[dict], list[str]]:
    p = Path(data_dir) / "indicators.csv"
    if p.is_symlink() or not p.is_file():
        raise SandboxError("data/indicators.csv is missing or a symlink: nothing to build")
    with open(p, encoding="utf-8", newline="") as f:
        rows = list(csv.DictReader(f))
    cols = [c for c in (rows[0].keys() if rows else []) if c not in ("id", "pillar", "indicator", "unit")]
    return rows, cols


def _iso_names(data_dir) -> dict[str, str]:
    p = Path(data_dir) / "countries.csv"
    if p.is_symlink() or not p.is_file():
        return {}
    with open(p, encoding="utf-8", newline="") as f:
        return {r.get("iso", "").upper(): r.get("country", "") for r in csv.DictReader(f) if r.get("iso")}


def _provenance_keys(data_dir) -> set[tuple[str, str, str]]:
    p = Path(data_dir) / "audit_trail.csv"
    if p.is_symlink() or not p.is_file():
        return set()
    with open(p, encoding="utf-8", newline="") as f:
        return {(r.get("table", ""), str(r.get("key", "")), r.get("country", "")) for r in csv.DictReader(f)}


def _no_simulated(outputs_dir, data_dir) -> None:
    """EQ-C-0146 (HO-20261026-A-C-003): SandboxError when the input provenance (data/audit_trail.csv) or the latest run's
    country table (run_latest.json) carries a SIMULATED value from Team A's vendor simulator."""
    import pandas as pd

    from ..ingestion.market.vendor_sim_guard import SimulatedDataError
    from .vendor_rehearse import refuse_simulated, refuse_simulated_run
    p = Path(data_dir) / "audit_trail.csv"
    try:
        if p.is_file() and not p.is_symlink():
            refuse_simulated(pd.read_csv(p, dtype=str, keep_default_na=False), "client_outbox build (provenance)")
        refuse_simulated_run(outputs_dir, "client_outbox build (run)")
    except SimulatedDataError as e:
        raise SandboxError(str(e)) from None


def licence_view(data_dir) -> dict:
    """The licence state the sandbox builds on: {"status", "demo", "ev", "withheld": set, "refusals": [str]}.
    SandboxError when the sandbox must refuse too (register seen != approved, chain broken, evaluation incomplete)."""
    from ..presentation.licences import refusals, safe_evaluate
    from . import licence_gov as G
    st = G.state(data_dir)
    if st["status"] not in SANDBOX_STATES:
        raise SandboxError(f"licence register state {st['status']}: the sandbox refuses too (" + (G.problem(data_dir, st) or
                           "the register in use is not the approved one") + ")")
    ev = safe_evaluate(data_dir)
    if not ev.get("complete") or not (ev.get("register") or {}).get("ok"):
        raise SandboxError("licence evaluation incomplete, so withheld cells cannot be told apart; the sandbox refuses too "
                           "(fails closed): " + "; ".join((ev.get("reader_problems") or ev.get("problems") or ["unknown"])[:2]))
    withheld = {(c["table"], str(c["key"]), c["country"]) for c in ev.get("internal_only") or []}
    return {"status": st["status"], "demo": st["status"] == G.DEMO_STATE, "ev": ev, "withheld": withheld,
            "refusals": refusals(ev, limit=4)}


# ---------------------------------------------------------------- pages
_CSS = ("body{font-family:Helvetica,Arial,sans-serif;margin:0;color:#111;background:#fff}"
        "main{padding:16px 24px 64px}table{border-collapse:collapse}td,th{border:1px solid #bbb;padding:3px 8px;"
        "font-size:13px;text-align:left}td.n{text-align:right}td.w{color:#777;font-style:italic}"
        ".eq-sbx-bar{background:#b00020;color:#fff;font-weight:bold;padding:6px 24px;font-size:13px}"
        ".eq-sbx-recipient{background:#fde7ea;color:#600;padding:6px 24px;font-size:13px;border-bottom:2px solid #b00020}"
        ".eq-sbx-overlay{position:fixed;inset:0;display:flex;align-items:center;justify-content:center;"
        "pointer-events:none;z-index:9999}.eq-sbx-overlay span{transform:rotate(-30deg);font-size:64px;font-weight:bold;"
        "color:rgba(176,0,32,.16);white-space:nowrap}"
        "footer.eq-sbx-bar{position:fixed;bottom:0;left:0;right:0}"
        "@media print{.eq-sbx-overlay,footer.eq-sbx-bar{position:fixed}}")


def _page(title: str, client: dict, body: str, lv: dict, run: str, date: str) -> str:
    e = _h.escape
    base = "DEMO licence baseline: not Sam's approval" if lv["demo"] else f"licence baseline: {lv['status']}"
    bar = (f"{BANNER}. Synthetic test client {e(client['client_id'])}, sandbox run {e(run)}, {e(date)}. {e(base)}. "
           "Not a client product; never sent.")
    attrib = "".join(f"<li>{e(a)}</li>" for a in lv["ev"].get("attribution") or [])
    from ..presentation.csp import harden       # EQ-C-0165: meta CSP, hash-only styles (the watermark adds no style)
    return harden("<!doctype html><html lang=\"en\"><head><meta charset=\"utf-8\">"
            f"<title>{BANNER} | {e(title)}</title>{META_SBX}<meta name=\"robots\" content=\"noindex\">"
            f"<style>{_CSS}</style></head><body>"
            f"<div class=\"eq-sbx-overlay\" aria-hidden=\"true\"><span>{BANNER}</span></div>"
            f"<div class=\"eq-sbx-bar\" role=\"note\">{bar}</div>{PLACEHOLDER}"
            f"<main><h1>{e(title)}</h1>{body}<h2>Sources and attribution</h2><ul>{attrib}</ul></main>"
            f"<footer class=\"eq-sbx-bar\">{BANNER} &middot; {e(client['client_id'])} &middot; {PLACEHOLDER}</footer>"
            "</body></html>")


def _country_page(name: str, rows: list[dict], prov: set, lv: dict) -> tuple[str, int, int]:
    e = _h.escape
    shown = withheld = 0
    trs = []
    for r in rows:
        k = ("Inputs", str(r.get("id", "")), name)
        v = str(r.get(name, "")).strip()
        if k in lv["withheld"] or k not in prov or not v:
            withheld += 1
            why = "withheld: internal-only licence" if k in lv["withheld"] else "withheld: no provenance record"
            cell = f"<td class=\"w\">{why}</td>"
        else:
            shown += 1
            cell = f"<td class=\"n\">{e(v)}</td>"
        trs.append(f"<tr><td>{e(str(r.get('id', '')))}</td><td>{e(str(r.get('indicator', '')))}</td>"
                   f"<td>{e(str(r.get('unit', '')))}</td>{cell}</tr>")
    body = (f"<p>{shown} cells shown, {withheld} withheld under the licence rules (presentation/licences). "
            "Withheld values are not in this file.</p><table><tr><th>id</th><th>indicator</th><th>unit</th><th>value</th></tr>"
            + "".join(trs) + "</table>")
    return body, shown, withheld


def _summary_page(lv: dict, real_refusal: str) -> str:
    e = _h.escape
    ev = lv["ev"]
    srcs = "".join(f"<tr><td>{e(s['source_id'])}</td><td>{e(str(s['licence'])[:200])}</td><td class=\"n\">{int(s['cells'])}"
                   f"</td><td>{'yes' if s['client_ok'] else 'no'}</td></tr>" for s in ev.get("sources") or [])
    refs = "".join(f"<li>{e(r[:300])}</li>" for r in lv["refusals"])
    base = "DEMO (not Sam): DEMO baseline: not Sam's approval" if lv["demo"] else lv["status"]
    return (f"<p>Licence baseline: <b>{e(base)}</b>. "
            f"{len(ev.get('internal_only') or [])} internal-only cells are withheld from every sandbox page.</p>"
            f"<h2>Why real client use is refused</h2><p>{e(real_refusal[:600])}</p><ul>{refs}</ul>"
            "<h2>Sources in use</h2><table><tr><th>source</th><th>licence</th><th>cells</th><th>register client_ok</th></tr>"
            f"{srcs}</table>")


def _slug(s: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", s.casefold()).strip("-")[:40] or "x"


def sandbox_id(recipient: str, run: str, date: str) -> str:
    """Per-recipient trace id (client_package.watermark_id recipe, 16 hex) printed on every page of that copy."""
    from ..presentation.client_package import watermark_id
    return watermark_id(recipient, date, f"sandbox:{run}", "client-outbox")


# ---------------------------------------------------------------- build / send / verify / reset
def build(outputs_dir, data_dir, sandbox: bool = False, entitlements=None, run: str | None = None,
          date: dt.date | None = None, demo_baseline: bool = False, now: dt.datetime | None = None) -> dict:
    """Build every test client's pack under <out>/client-outbox/<run>/_build/<client_id>/. Refuses without sandbox=True.
    demo_baseline=True opens the DEMO licence profile for this build only (temp store, deleted after)."""
    _require_sandbox(sandbox, data_dir, "client-outbox build")
    ent, raw = load_entitlements(entitlements)
    now = now or dt.datetime.now(dt.timezone.utc)
    run = run or "sbx-" + now.strftime("%Y%m%dT%H%M%SZ")
    day = (date or now.date()).isoformat()
    rd = _run_dir(outputs_dir, run)
    if rd.exists():
        raise SandboxError(f"sandbox run {run} already exists: pick another --run or reset it")
    rows, cols = _indicators(data_dir)
    iso = _iso_names(data_dir)
    for c in ent["clients"]:                                    # every check before anything is written
        c["countries"] = [x if x in cols else iso.get(x.upper(), x) for x in c["countries"]]
        bad = [x for x in c["countries"] if x not in cols]
        if bad:
            raise SandboxError(f"{c['client_id']}: countries not in data/indicators.csv: {', '.join(bad[:5])}")
    ctx = contextlib.nullcontext(None)
    if demo_baseline:
        from . import demo_baseline as DB
        ctx = DB.active(data_dir, None, now=now)
    refusal = real_use_refusal(data_dir, "client mode")       # outside the DEMO profile: the gate's own reason
    try:
        with ctx:
            lv = licence_view(data_dir)
            if demo_baseline and not lv["demo"]:
                raise SandboxError("--demo-baseline was asked for but the DEMO baseline did not take effect")
            prov = _provenance_keys(data_dir)
            _no_simulated(outputs_dir, data_dir)                # EQ-C-0146: before any page is built or written
            pages: dict[str, dict[str, tuple[str, dict]]] = {}
            for c in ent["clients"]:
                out = pages.setdefault(c["client_id"], {})
                if "country_inputs" in c["products"]:
                    for name in c["countries"]:
                        body, shown, wh = _country_page(name, rows, prov, lv)
                        out[f"country-{_slug(name)}.html"] = (_page(f"{name}: inputs (sandbox)", c, body, lv, run, day),
                                                               {"country": name, "shown": shown, "withheld": wh})
                if "licence_summary" in c["products"]:
                    out["licence-summary.html"] = (_page("Licence summary (sandbox)", c, _summary_page(lv, refusal), lv,
                                                         run, day), {})
    except Exception as e:
        from . import demo_baseline as DB
        if isinstance(e, DB.DemoBaselineError):
            raise SandboxError(f"--demo-baseline refused: {e}") from None
        raise
    rd.mkdir(parents=True)
    ent_info = _write_new(rd / ENT_FILE, raw)
    bd = rd / BUILD_DIR
    bd.mkdir()
    built = {}
    for cid, files in pages.items():
        cd = bd / cid
        cd.mkdir()
        built[cid] = [dict(_write_new(cd / n, t.encode("utf-8")), **meta) for n, (t, meta) in sorted(files.items())]
    doc = {"format": RUN_FORMAT, "ticket": TICKET, "sandbox": True, "banner": BANNER, "run": run, "date": day,
           "created_utc": now.strftime("%Y-%m-%dT%H:%M:%SZ"), "data_dir": str(Path(data_dir)),
           "entitlements_sha256": ent_info["sha256"], "allow_list": allow_list(ent),
           "licence": {"baseline": lv["status"], "demo": lv["demo"], "withheld_cells": len(lv["withheld"]),
                       "client_ok": bool(lv["ev"].get("client_ok"))},
           "real_use": refusal, "build": built, "sends": {}}
    _write_json(rd / RUN_FILE, doc)
    return {"run": run, "dir": str(rd), "clients": len(built), "pages": sum(len(v) for v in built.values()),
            "licence": doc["licence"], "allow_list": doc["allow_list"]}


def send(outputs_dir, data_dir, run: str, sandbox: bool = False, recipients: list[str] | None = None,
         now: dt.datetime | None = None) -> dict:
    """Copy each allow-listed recipient's pages to <run>/<recipient>/ with a per-recipient id and a manifest. Nothing
    leaves the machine. recipients None: everyone on the allow-list not yet sent."""
    _require_sandbox(sandbox, data_dir, "client-outbox send")
    rd = _run_dir(outputs_dir, run)
    if not rd.is_dir():
        raise SandboxError(f"sandbox run {run} does not exist: run `client-outbox build --sandbox` first")
    doc, _ = _load_run(rd)
    _, eraw = _read_json(rd / ENT_FILE, "entitlements copy")
    if _sha(eraw) != doc.get("entitlements_sha256"):
        raise SandboxError(f"{run}/{ENT_FILE} does not match run.json: refused")
    ent = parse_entitlements(eraw, f"{run}/{ENT_FILE}")
    allowed = allow_list(ent)
    if recipients:
        want = []
        for a in recipients:
            a = check_test_address(a)
            if a not in allowed:
                raise SandboxError(f"{a} is not on this run's test allow-list ({len(allowed)} recipients in {ENT_FILE})")
            want.append(a)
    else:
        want = [a for a in allowed if a not in doc["sends"]]
    if not want:
        raise SandboxError(f"nothing to send: every allow-listed recipient of {run} already has a copy")
    for a in want:
        if a in doc["sends"] or (rd / a).exists() or (rd / a).is_symlink():
            raise SandboxError(f"{a} already has a copy in {run}: refused (reset the run to resend)")
        if not doc["build"].get(allowed[a]):
            raise SandboxError(f"{a}: client {allowed[a]} has no built pages in {run}")
    src_bytes = {}                                              # verify the build before copying any of it
    for a in want:
        cid = allowed[a]
        for f in doc["build"][cid]:
            p = rd / BUILD_DIR / cid / f["name"]
            b = p.read_bytes() if p.is_file() and not p.is_symlink() else None
            if b is None or _sha(b) != f["sha256"]:
                raise SandboxError(f"build page {cid}/{f['name']} is missing or changed since the build: refused")
            src_bytes[(cid, f["name"])] = b
    now = now or dt.datetime.now(dt.timezone.utc)
    done = {}
    for a in want:
        cid = allowed[a]
        sid = sandbox_id(a, run, doc["date"])
        line = (f"<div class=\"eq-sbx-recipient\" role=\"note\">{BANNER}. Test copy for {_h.escape(a)} (test allow-list), "
                f"client {cid}, sandbox id {sid}. Not for onward distribution.</div>")
        d = rd / a
        d.mkdir()
        files = []
        for f in doc["build"][cid]:
            t = src_bytes[(cid, f["name"])].decode("utf-8")
            t = t.replace("</head>", f"<meta name=\"eq-watermark-id\" content=\"{sid}\"></head>", 1)
            t = t.replace(PLACEHOLDER, line, 1).replace(PLACEHOLDER, f"{_h.escape(a)} &middot; sandbox id {sid}", 1)
            files.append(_write_new(d / f["name"], t.encode("utf-8")))
        man = {"format": RUN_FORMAT, "ticket": TICKET, "sandbox": True, "banner": BANNER, "run": run, "recipient": a,
               "client_id": cid, "sandbox_id": sid, "date": doc["date"], "sent_utc": now.strftime("%Y-%m-%dT%H:%M:%SZ"),
               "transport": "local outbox file copy only (no email, no network)", "files": files}
        mb = (json.dumps(man, indent=1, sort_keys=True) + "\n").encode("utf-8")
        _write_new(d / MANIFEST, mb)
        done[a] = {"client_id": cid, "sandbox_id": sid, "manifest_sha256": _sha(mb), "files": len(files),
                   "sent_utc": man["sent_utc"]}
    doc["sends"].update(done)
    _write_json(rd / RUN_FILE, doc)
    return {"run": run, "dir": str(rd), "sent": done}


def _page_problems(name: str, text: str, sid: str | None) -> list[str]:
    out = []
    if META_SBX not in text or f"<title>{BANNER}" not in text or "class=\"eq-sbx-overlay\"" not in text:
        out.append(f"{name}: the {BANNER} watermark is missing")
    if PLACEHOLDER not in text and sid is None:
        out.append(f"{name}: build copy without its recipient placeholder")
    if sid is not None and (f"content=\"{sid}\"" not in text or text.count(f"sandbox id {sid}") < 2 or PLACEHOLDER in text):
        out.append(f"{name}: the per-recipient sandbox id {sid} is missing")
    return out


def verify_run(rd: Path) -> list[str]:
    probs: list[str] = []
    try:
        doc, _ = _load_run(rd)
    except SandboxError as e:
        return [f"{rd.name}: {e}"]
    try:
        _, eraw = _read_json(rd / ENT_FILE, "entitlements copy")
        if _sha(eraw) != doc.get("entitlements_sha256"):
            probs.append(f"{rd.name}/{ENT_FILE}: sha256 does not match run.json")
    except SandboxError as e:
        probs.append(f"{rd.name}: {e}")
    expected = {RUN_FILE, ENT_FILE, BUILD_DIR, *doc.get("sends", {})}
    probs += [f"{rd.name}/{p.name}: not listed in run.json" for p in sorted(rd.iterdir())
              if p.name not in expected and not p.name.startswith(".")]

    def check_dir(d: Path, files: list[dict], sid: str | None, extra=()) -> None:
        if d.is_symlink() or not d.is_dir():
            probs.append(f"{d.relative_to(rd.parent)}: missing or a symlink")
            return
        names = {f["name"] for f in files} | set(extra)
        for p in sorted(d.iterdir()):
            if p.name not in names:
                probs.append(f"{p.relative_to(rd.parent)}: not in the manifest")
        for f in files:
            p = d / f["name"]
            b = p.read_bytes() if p.is_file() and not p.is_symlink() else None
            if b is None:
                probs.append(f"{p.relative_to(rd.parent)}: missing or a symlink")
            elif _sha(b) != f["sha256"]:
                probs.append(f"{p.relative_to(rd.parent)}: sha256 does not match")
            elif p.suffix == ".html":
                probs.extend(f"{rd.name}/{x}" for x in _page_problems(str(p.relative_to(rd)), b.decode("utf-8", "replace"), sid))

    bd = rd / BUILD_DIR
    for cid, files in (doc.get("build") or {}).items():
        check_dir(bd / cid, files, None)
    if bd.is_dir() and not bd.is_symlink():
        probs += [f"{rd.name}/{BUILD_DIR}/{p.name}: not in run.json" for p in bd.iterdir() if p.name not in doc.get("build", {})]
    for a, s in (doc.get("sends") or {}).items():
        d = rd / a
        try:
            man, mb = _read_json(d / MANIFEST, f"{a} manifest")
        except SandboxError as e:
            probs.append(f"{rd.name}/{a}: {e}")
            continue
        if _sha(mb) != s.get("manifest_sha256"):
            probs.append(f"{rd.name}/{a}/{MANIFEST}: sha256 does not match run.json")
        if man.get("recipient") != a or man.get("sandbox_id") != s.get("sandbox_id") or man.get("sandbox") is not True:
            probs.append(f"{rd.name}/{a}/{MANIFEST}: recipient, sandbox id or sandbox flag does not match run.json")
        if not is_test_address(a):
            probs.append(f"{rd.name}/{a}: not a reserved test address")
        check_dir(d, man.get("files") or [], s.get("sandbox_id") or "-", extra=(MANIFEST,))
    return probs


def verify(outputs_dir, run: str | None = None) -> dict:
    """{"ok", "runs", "problems"}. Reads only."""
    box = outbox_dir(outputs_dir)
    if box.is_symlink():
        return {"ok": False, "runs": [], "problems": [f"{box} is a symlink"]}
    if run is not None:
        rd = _run_dir(outputs_dir, run)
        if not rd.is_dir():
            return {"ok": False, "runs": [], "problems": [f"sandbox run {run} does not exist"]}
        runs = [rd]
    else:
        runs = sorted(p for p in box.iterdir() if p.is_dir() or p.is_symlink()) if box.is_dir() else []
    probs = []
    for rd in runs:
        probs += [f"{rd.name}: is a symlink"] if rd.is_symlink() else verify_run(rd)
    return {"ok": not probs, "runs": [r.name for r in runs], "problems": probs}


def reset(outputs_dir, data_dir, sandbox: bool = False, run: str | None = None) -> dict:
    """Delete sandbox runs (run.json format and sandbox true); anything else in the outbox is left and reported."""
    _require_sandbox(sandbox, data_dir, "client-outbox reset")
    box = _safe_dir(outbox_dir(outputs_dir), "outbox")
    if not box.is_dir():
        return {"removed": [], "kept": []}
    targets = [_run_dir(outputs_dir, run)] if run else sorted(box.iterdir())
    removed, kept = [], []
    for rd in targets:
        if rd.is_symlink() or not rd.is_dir():
            kept.append(rd.name)
            continue
        try:
            _load_run(rd)
        except SandboxError:
            kept.append(rd.name)
            continue
        shutil.rmtree(rd)
        removed.append(rd.name)
    return {"removed": removed, "kept": kept}


# ---------------------------------------------------------------- demo row (EQ-C-0148, MVP M14)
def demo_sandbox(data_dir, out_dir, entitlements=None, now: dt.datetime | None = None) -> dict:
    """Build, send and verify a sandbox run, and prove the refusals. The DEMO baseline is used when no real baseline
    exists. {"ok", "run", "dir", "baseline", "pages", "recipients", "verify", "refusals", "problems"}."""
    from . import licence_gov as G
    res = {"ok": False, "run": None, "dir": None, "baseline": None, "pages": 0, "recipients": 0, "verify": None,
           "refusals": {}, "problems": []}
    demo = G.state(data_dir)["status"] == "no_baseline"
    try:
        b = build(out_dir, data_dir, sandbox=True, entitlements=entitlements, demo_baseline=demo, now=now)
        s = send(out_dir, data_dir, b["run"], sandbox=True, now=now)
    except SandboxError as e:
        res["problems"].append(str(e))
        return res
    v = verify(out_dir, b["run"])
    res.update(run=b["run"], dir=b["dir"], baseline=b["licence"]["baseline"], pages=b["pages"], recipients=len(s["sent"]),
               verify=v)
    res["problems"] += v["problems"]
    checks = {"real_use": lambda: build(out_dir, data_dir, sandbox=False, entitlements=entitlements),
              "non_test_recipient": lambda: send(out_dir, data_dir, b["run"], sandbox=True, recipients=["someone@gmail.com"]),
              "not_on_allow_list": lambda: send(out_dir, data_dir, b["run"], sandbox=True, recipients=["stranger@example.com"])}
    for k, fn in checks.items():
        try:
            fn()
            res["problems"].append(f"{k}: was NOT refused")
        except SandboxError as e:
            res["refusals"][k] = str(e)[:300]
    if demo:
        from . import demo_baseline as DB
        try:
            with DB.active(data_dir, None, now=now):
                res["refusals"]["demo_outside_sandbox"] = real_use_refusal(data_dir, "client-outbox")[:300]
        except DB.DemoBaselineError as e:
            res["problems"].append(f"demo_outside_sandbox: could not be checked ({e})")
    res["ok"] = not res["problems"] and v["ok"]
    return res


# ---------------------------------------------------------------- CLI
def cmd_client_outbox(args) -> None:
    c = args.outbox_cmd
    try:
        if c == "build":
            day = dt.date.fromisoformat(args.date) if args.date else None
            r = build(args.out, args.data, sandbox=args.sandbox, entitlements=args.entitlements, run=args.run, date=day,
                      demo_baseline=args.demo_baseline)
            msg = (f"{BANNER}: sandbox run {r['run']} built ({r['clients']} test clients, {r['pages']} pages, licence "
                   f"baseline {r['licence']['baseline']}, {r['licence']['withheld_cells']} cells withheld) in {r['dir']}. "
                   f"Next: econquest client-outbox send --sandbox --run {r['run']}")
        elif c == "send":
            r = send(args.out, args.data, args.run, sandbox=args.sandbox, recipients=args.recipient)
            msg = (f"{BANNER}: {len(r['sent'])} test recipients written to the local outbox {r['dir']} (no email, nothing "
                   "left this machine)")
        elif c == "verify":
            r = verify(args.out, args.run)
            msg = (f"client outbox: {len(r['runs'])} sandbox runs, " + ("all hashes and watermarks verify" if r["ok"] else
                   f"{len(r['problems'])} PROBLEMS:\n  " + "\n  ".join(r["problems"][:20])))
        else:
            r = reset(args.out, args.data, sandbox=args.sandbox, run=args.run)
            msg = f"client outbox: removed {len(r['removed'])} sandbox runs" + (
                f"; left {len(r['kept'])} entries that are not sandbox runs: {', '.join(r['kept'][:10])}" if r["kept"] else "")
    except ValueError as e:                                     # SandboxError, a bad date
        raise SystemExit(f"client-outbox: {e}") from None
    print(json.dumps(r, indent=1, default=str) if args.json else msg)
    if c == "verify" and not r["ok"]:
        raise SystemExit(1)


def register(sub) -> None:
    """client-outbox, added by cli.main."""
    p = sub.add_parser("client-outbox", help="client mode SANDBOX (EQ-C-0145): watermarked test packs for synthetic clients "
                       "written to a local outbox (<out>/client-outbox/); never email, never real clients; refuses without "
                       "--sandbox until Sam's signed go-live, and real deliveries stay with client-export")
    s = p.add_subparsers(dest="outbox_cmd", required=True)
    b = s.add_parser("build", help="build every test client's pack through the licence rules")
    b.add_argument("--entitlements", metavar="FILE", help="test entitlements JSON (default: the built-in SAMPLE)")
    b.add_argument("--run", metavar="NAME", help="run name (default sbx-<UTC time>)")
    b.add_argument("--date", metavar="YYYY-MM-DD")
    b.add_argument("--demo-baseline", action="store_true", help="build on the DEMO licence baseline (sandbox only; never Sam's)")
    sd = s.add_parser("send", help="write each allow-listed test recipient's copy and manifest to the local outbox")
    sd.add_argument("--run", metavar="NAME", required=True)
    sd.add_argument("--recipient", metavar="ADDR", action="append", help="only these allow-listed test addresses (repeat)")
    v = s.add_parser("verify", help="check every hash and watermark in the outbox; exit 1 on a problem (reads only)")
    v.add_argument("--run", metavar="NAME")
    r = s.add_parser("reset", help="delete sandbox runs (only folders whose run.json says sandbox)")
    r.add_argument("--run", metavar="NAME")
    for x in (b, sd, r):
        x.add_argument("--sandbox", action="store_true", help="required: this is the test sandbox (synthetic clients, "
                       "reserved test addresses); without it the command refuses (real use)")
    for x in (b, sd, v, r):
        x.add_argument("--json", action="store_true")
    p.set_defaults(fn=cmd_client_outbox)
