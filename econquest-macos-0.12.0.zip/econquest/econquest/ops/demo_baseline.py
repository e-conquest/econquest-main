"""DEMO licence baseline profile (EQ-C-0123, SEC-C-019, MVP checklist M8). NEVER Sam's approval.

Until Sam approves the first licence register baseline (R44, ops/licence_gov.FIRST_BASELINE_CMD, his key), the
evidence build and client-check refuse. To prove governance end to end in the cloud before that, the DEMO profile
approves the current data/licences.csv as a baseline that is marked DEMO everywhere:

    econquest evidence --as-of D --demo-baseline         evidence-<D>-DEMO.zip, manifest profile=demo
    econquest client-check --demo-baseline               the checklist on the demo register; never "ready"
    demo_evidence(data_dir, out_dir=None, ...)           for `econquest demo` (EQ-C-0121): build + verify

Opt-in is a per-invocation flag (and an explicit Python call), never an environment variable: a flag is not inherited
by child processes, launchd jobs or a shell profile, and shows in the command line and the action log.

What the profile is and is not:
- The approver is the fixed label APPROVER ("DEMO (not Sam)"); nobody can choose it. The record and its register copy
  live under <outputs>/demo/licence-baseline/ (or a temp folder that is deleted), never under data/ (so never in
  data/approvals/registers/ or the change chain); a store inside the data folder is refused.
- It applies only while there is no real approved version (licence_gov status no_baseline). A real baseline, drift,
  a missing or symlinked register, or a broken approvals chain refuses the profile: it cannot paper over any of them.
- It is in effect only inside `active()`, only in the thread that opened it (licence_gov.demo_override); there the
  register state is "demo", which every client path refuses through licence_gov.problem (client_ok False,
  register_governed False). While any thread has it open, client builds, client distribution, client-pack and
  workbook writes refuse outright (licence_gov.refuse_demo). `econquest change verify` never reads it.
- Only the evidence build accepts it (register_mismatch(allow_demo=True)); the bundle says so in its folder name, the
  manifest (profile, demo_baseline), README and summary, and `evidence verify` reports it and fails a bundle whose
  DEMO marking was stripped.
"""
from __future__ import annotations

import contextlib
import datetime as dt
import json
import shutil
import tempfile
from pathlib import Path

from . import licence_gov as G

TICKET = "EQ-C-0123"
PROFILE = "demo"
APPROVER = "DEMO (not Sam)"
BANNER = G.DEMO_BANNER
STORE = Path("demo") / "licence-baseline"
RECORD = "DEMO-BASELINE.json"
FORMAT = "econquest-demo-baseline/1"


class DemoBaselineError(RuntimeError):
    """The DEMO profile cannot apply here (a real baseline exists, the chain is broken, an unsafe store, ...)."""


def store_dir(out_dir) -> Path:
    return Path(out_dir) / STORE


def _inside(child: Path, parent: Path) -> bool:
    try:
        child.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


def create(data_dir, store, now: dt.datetime | None = None) -> dict:
    """Approve the current data/licences.csv as a DEMO baseline in `store` (a folder outside data_dir). Returns the
    record. Writes nothing under data_dir and nothing to the approvals log."""
    d, store = Path(data_dir), Path(store)
    if _inside(store, d):
        raise DemoBaselineError("the DEMO baseline store must be outside the data folder (never data/approvals/)")
    st = G.state(d)
    if st["status"] != "no_baseline":
        why = {"ok": "a real approved licence register exists: use it, the DEMO profile is not needed",
               "default": f"there is no data/{G.REGISTER} to approve"}.get(st["status"]) or G.problem(d, st)
        raise DemoBaselineError(f"DEMO baseline refused (status {st['status']}): {why}")
    p = d / G.REGISTER
    raw = p.read_bytes()
    try:
        G.parse(raw, f"data/{G.REGISTER}")
    except G.LicenceGovError as e:
        raise DemoBaselineError(f"DEMO baseline refused: the register is invalid: {e}") from None
    sha = G.sha256(raw)
    if store.is_symlink() or (store.exists() and not store.is_dir()):
        raise DemoBaselineError("the DEMO baseline store is a symlink or not a folder")
    store.mkdir(parents=True, exist_ok=True)
    snap = store / f"licences-{sha}.csv"
    if snap.is_symlink():
        snap.unlink()
    snap.write_bytes(raw)
    now = now or dt.datetime.now(dt.timezone.utc)
    rec = {"format": FORMAT, "ticket": TICKET, "profile": PROFILE, "approver": APPROVER, "not_sams_approval": True,
           "banner": BANNER, "file": G.REGISTER, "register_sha256": sha, "snapshot": snap.name,
           "created_utc": now.strftime("%Y-%m-%dT%H:%M:%SZ"),
           "note": "approves nothing for client output; Sam's first baseline is still needed (" + G.FIRST_BASELINE_CMD + ")"}
    tmp = store / f".{RECORD}.tmp"
    tmp.write_text(json.dumps(rec, indent=1) + "\n", encoding="utf-8")
    tmp.replace(store / RECORD)
    return rec


def load(store) -> dict | None:
    """The record in `store` when it is a well-formed DEMO record whose register copy still hashes, else None."""
    store = Path(store)
    try:
        rec = json.loads((store / RECORD).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    if not isinstance(rec, dict) or rec.get("profile") != PROFILE or rec.get("approver") != APPROVER:
        return None
    snap = store / str(rec.get("snapshot", ""))
    if snap.parent != store or snap.is_symlink() or not snap.is_file() or G.sha256(snap.read_bytes()) != rec.get("register_sha256"):
        return None
    return rec


@contextlib.contextmanager
def active(data_dir, out_dir=None, now: dt.datetime | None = None):
    """Open the DEMO profile for data_dir in this thread. The record goes to <out_dir>/demo/licence-baseline/, or to a
    temp folder deleted on exit when out_dir is None. Yields the record (plus "store")."""
    tmp = None
    if out_dir is None:
        tmp = Path(tempfile.mkdtemp(prefix="econquest-demo-baseline-"))
        store = tmp
    else:
        store = store_dir(out_dir)
    try:
        rec = create(data_dir, store, now=now)
        ov = {"data_dir": str(Path(data_dir).resolve()), "sha256": rec["register_sha256"],
              "snapshot": str((store / rec["snapshot"]).resolve()), "created_utc": rec["created_utc"]}
        with G._demo_open(ov):
            st = G.state(data_dir)
            if st["status"] != G.DEMO_STATE or st["approved_path"] is None:
                raise DemoBaselineError(f"DEMO baseline did not take effect (status {st['status']})")
            yield dict(rec, store=str(store))
    finally:
        if tmp is not None:
            shutil.rmtree(tmp, ignore_errors=True)


def demo_evidence(data_dir, out_dir=None, as_of: str | None = None, root=None, tests_from=None, replication_from=None,
                  quick: bool = True, log=print) -> dict:
    """Build and verify the evidence bundle on the DEMO baseline (EQ-C-0121 `econquest demo`, checklist M8).

    out_dir None: a fresh temp outputs folder (kept; its path is returned). as_of None: today (UTC). Returns
    {"ok", "profile", "banner", "archive", "sha256", "out_dir", "verify", "real_baseline", "problems"}; ok is True only
    when the build succeeded, evidence.verify passed and the bundle says profile=demo. Build failures come back as
    ok False with the reason in problems; DemoBaselineError when the profile cannot apply at all."""
    from . import evidence as EV
    data_dir = Path(data_dir).absolute()                       # the replication resolves paths from the data folder
    out = Path(out_dir) if out_dir is not None else Path(tempfile.mkdtemp(prefix="econquest-demo-outputs-"))
    as_of = as_of or dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d")
    res = {"ok": False, "profile": PROFILE, "banner": BANNER, "archive": None, "sha256": None, "out_dir": str(out),
           "verify": None, "real_baseline": None, "problems": []}
    try:
        b = EV.build(as_of, data_dir, out, root=root, quick=quick, tests_from=tests_from,
                     replication_from=replication_from, demo_baseline=True, log=log)
    except EV.EvidenceError as e:
        res["problems"].append(str(e))
    else:
        v = EV.verify(b["archive"])
        res.update(archive=b["archive"], sha256=b["sha256"], verify=v)
        if v.get("profile") != PROFILE:
            res["problems"].append("the bundle is not marked profile=demo")
        res["problems"] += list(v.get("errors") or [])
        res["ok"] = bool(v.get("ok")) and v.get("profile") == PROFILE
    res["real_baseline"] = G.state(data_dir)["status"]           # outside the profile: still no real baseline
    return res
