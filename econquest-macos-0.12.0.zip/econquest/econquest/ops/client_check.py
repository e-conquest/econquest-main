"""Client-readiness check (EQ-C-0083): `econquest client-check [--json]`. Reads only; exit 1 while anything is missing.

Prints PASS / FAIL per requirement of docs/research/client-readiness.md, from repo state only. It is a checklist, not
legal advice and not a licence opinion: a PASS means the repo holds the record the requirement names, not that the
record is adequate. Whether a licence, a regulatory exemption or a disclaimer is good enough is for Sam and a
compliance adviser. Client mode stays Sam's decision (research.json through `econquest change`); this command never
changes it, writes nothing, fetches nothing and is not in the operator action log (cli.action_label returns None).

Failing today is expected: client mode is off, nobody is onboarded, and 482 applied cells carry IMF / WEO data.
"""
from __future__ import annotations

import json
import re
from pathlib import Path

VERIFIED = "verified from the licence text in the repo"      # register terms_verified=yes (HO-20261025-A-C-007)
TO_VERIFY = "to verify"

# Per-source terms (HO-20261025-A-C-007): generated from Team A's licence register (data/licences.csv, contract C14,
# econquest.ingestion.licences.load_register), no longer kept by hand here. One entry per register row, keyed by
# source_id (a row without match_source never matches a label, but DERIVED can name it). status is VERIFIED only for
# terms_verified=yes (Team A quoted the licence text); client is "no" unless client_output=allowed with
# internal_use=yes, else "yes" (verified) or TO_VERIFY.
# Fails closed: a missing or invalid register raises LicenceTableError, so the licences check FAILs (never PASS) and
# `LICENCES` cannot be read. Licences are Sam's call; this code never changes the register.
REGISTER_TICKET = "EQ-A-0076"


class LicenceTableError(RuntimeError):
    """Team A's licence register is missing or invalid: no licence table, so the licence checks fail closed."""


_TABLE: dict = {}


def licence_table(path=None) -> dict[str, dict]:
    """{source_id: {"name", "match", "status", "client", "terms", "where", "exc_id"}} from load_register(path),
    cached on the register file's path, size and mtime. LicenceTableError when the register is missing or invalid."""
    from ..ingestion import licences as A
    rp = A.register_path(path)
    why = A.register_problem(path)
    if why:
        raise LicenceTableError(f"licence register {why} ({REGISTER_TICKET}); licence checks fail closed")
    try:
        st = rp.stat()
        key = (str(rp.resolve()), st.st_size, st.st_mtime_ns)
    except OSError as e:
        raise LicenceTableError(f"licence register {rp} cannot be read ({type(e).__name__})") from None
    if key not in _TABLE:
        try:
            rows = A.load_register(path)
        except (A.RegisterError, OSError, UnicodeDecodeError) as e:
            raise LicenceTableError(f"licence register invalid: {e}") from None
        if not rows:
            raise LicenceTableError(f"licence register {rp} has no rows ({REGISTER_TICKET}); licence checks fail closed")
        table = {}
        for r in rows:
            verified = r["terms_verified"] == "yes"
            ok = r["client_output"] == "allowed" and r["internal_use"] == "yes"
            table[r["source_id"]] = {
                "name": r["name"], "match": r["match_source"], "rx": re.compile(r["match_source"], re.IGNORECASE) if r["match_source"] else None,
                "status": VERIFIED if verified else TO_VERIFY,
                "client": ("yes" if verified else TO_VERIFY) if ok else "no",
                "terms": r["licence_text"] or r["name"], "where": f"data/licences.csv ({r['source_id']})",
                "exc_id": r["exc_id"]}
        _TABLE.clear()
        _TABLE[key] = table
    return _TABLE[key]


def __getattr__(name):
    """`client_check.LICENCES` is the register-generated table (read on access: a missing or invalid register
    raises LicenceTableError instead of returning stale terms)."""
    if name == "LICENCES":
        return {k: {f: v for f, v in e.items() if f != "rx"} for k, e in licence_table().items()}
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")


# sources that are not a licensed dataset: the desk's own estimates and entries (still subject to independence review)
OWN = re.compile(r"seed estimate|hand-entered|^manual|analyst", re.IGNORECASE)
DERIVED = {re.compile(r"econquest dsa", re.IGNORECASE): ("imf_derived", "worldbank_wdi")}    # inherits its inputs' terms

IMF_OPTIONS = ("replace the IMF / WEO inputs of client products with non-IMF sources; get IMF licence or written "
               "permission for client use; or stay internal")


def _check(rid: str, requirement: str, ok: bool, detail: str, blocker: bool = False) -> dict:
    return {"id": rid, "requirement": requirement, "ok": bool(ok), "blocker": blocker, "detail": detail}


def _guard(rid: str, requirement: str, fn, blocker: bool = False) -> dict:
    try:
        return fn()
    except Exception as e:                                       # noqa: BLE001 - cannot tell: fail
        return _check(rid, requirement, False, f"could not be checked ({type(e).__name__}: {e})", blocker)


def sources_in_use(data_dir) -> list[str]:
    """Distinct source labels of the applied cells and the current pull (audit_trail.csv, live/provenance.csv)."""
    import pandas as pd
    d = Path(data_dir)
    out: set[str] = set()
    for p in (d / "audit_trail.csv", d / "live" / "provenance.csv"):
        if p.is_file() and not p.is_symlink():
            df = pd.read_csv(p, dtype=str, keep_default_na=False, usecols=lambda c: c == "source")
            if "source" in df:
                out |= {s.strip() for s in df["source"] if s.strip()}
    return sorted(out)


def licence_of(source: str, table: dict | None = None) -> list[str]:
    """Register source_ids a source label falls under, most restrictive first in file order ([] = the desk's own
    entry that no register row covers; ['?'] = not in the register). A register row wins over OWN (hand-entered FX
    is restricted in the register); DERIVED adds the input licences a computed value inherits. LicenceTableError
    when the register is missing or invalid."""
    t = licence_table() if table is None else table
    for rx, names in DERIVED.items():
        if rx.search(source):
            got = [n for n in names if n in t]
            if got:
                return got
    hits = [n for n, e in t.items() if e["rx"] is not None and e["rx"].search(source)]   # path-only rows: never
    if hits:
        return hits
    return [] if OWN.search(source) else ["?"]


def collect(data_dir) -> list[dict]:
    """The checklist rows. EQ-C-0106 (R44): run with Team A's resolver pointed at the approved licence register
    (ops/licence_gov.enforce_approved), so licence_table, LICENCES and the register row read only that version."""
    from .licence_gov import enforce_approved
    with enforce_approved(data_dir):
        return _collect(data_dir)


def _collect(data_dir) -> list[dict]:
    from ..presentation import compliance as C
    from ..presentation import research as R
    from ..presentation.report import DISCLAIMER
    from . import approvals as ap
    d = Path(data_dir)
    rows: list[dict] = []

    def mode():
        st = R.effective_mode(d)
        why = "; ".join(st["problems"]) or f"research.json says {st['requested']}"
        return _check("mode", "Client mode approved by Sam and applied (research.json via econquest change)",
                      st["mode"] == "client", f"effective mode {st['mode']}: {why}")
    rows.append(_guard("mode", "Client mode approved by Sam", mode))

    def imf():
        n = len(R.client_restricted_cells(d))
        return _check("imf", "HARD BLOCKER: no applied cell carries IMF / WEO data (EQ-C-0080: products use all cells)",
                      n == 0, f"{n} applied cells flagged by `python -m econquest.ingestion.audit client`; options for "
                      f"Sam: {IMF_OPTIONS}", blocker=True)
    rows.append(_guard("imf", "HARD BLOCKER: no IMF / WEO cells", imf, blocker=True))

    def restricted():
        from ..ingestion import audit
        n = len(audit.restricted_source_cells(d))
        return _check("restricted", "No applied cell from Yahoo or a non-commercial / personal licence", n == 0,
                      f"{n} cells (`python -m econquest.ingestion.audit restricted`)", blocker=True)
    rows.append(_guard("restricted", "No non-commercial cells", restricted, blocker=True))

    def licences():
        table = licence_table()                       # HO-20261025-A-C-007: from the register; missing/invalid -> FAIL
        used: dict[str, list[str]] = {}
        for s in sources_in_use(d):
            for name in licence_of(s, table):
                used.setdefault(name, []).append(s)
        untagged = used.pop("?", [])
        unverified = sorted(n for n in used if table[n]["status"] != VERIFIED)
        no_client = sorted(n for n in used if table[n]["client"] == "no")
        parts = [f"sources used: {', '.join(sorted(used)) or 'none'}"]
        if unverified:
            parts.append(f"{TO_VERIFY}: {', '.join(unverified)}")
        if no_client:
            parts.append(f"not for client use: {', '.join(no_client)}")
        if untagged:
            parts.append(f"not in the licence register: {untagged[:5]}")
        return _check("licences", "Every licence behind product data verified from its text and allowing client use",
                      not (unverified or no_client or untagged), "; ".join(parts))
    rows.append(_guard("licences", "Licences verified", licences))

    def lic_register():                               # EQ-C-0093: Team A's per-dataset register, as products enforce it
        from ..presentation.licences import evaluate, refusals
        ev = evaluate(d)
        why = refusals(ev, limit=4)
        return _check("licence_register", "HARD BLOCKER: Team A licence register (data/licences.csv, EQ-A-0076) present, "
                      "governed, and allowing every source in use (presentation/licences.py)", ev["client_ok"],
                      "; ".join(why) if why else f"{ev['register']['rows']} register rows; every source in use is client_ok",
                      blocker=True)
    rows.append(_guard("licence_register", "HARD BLOCKER: licence register", lic_register, blocker=True))

    def acled():
        from ..ingestion.events.base import is_enabled, load_event_config
        on = is_enabled(load_event_config(d).get("acled", {}))
        return _check("acled", "ACLED (non-commercial free tier) not feeding products", not on,
                      "ACLED enabled in data/live/events/feeds.json: needs a corporate licence before client use" if on
                      else "ACLED off")
    rows.append(_guard("acled", "ACLED off", acled))

    def core():
        ok = "not investment advice" in DISCLAIMER.casefold()
        return _check("disclaimer_core", "Core disclaimer (report.DISCLAIMER, restriction 6.1) on every product", ok,
                      "present" if ok else "missing 'not investment advice'")
    rows.append(_guard("disclaimer_core", "Core disclaimer", core))

    def client_text():
        cfg = R.load_config(d)
        st = ap.file_status(d, R.CONFIG_NAME)
        text = (cfg.get("disclaimer") or {}).get("client", "")
        ok = bool(text.strip()) and st["status"] == "ok" and st["chain_ok"]
        return _check("disclaimer_client", "Client disclaimer approved by compliance and applied via econquest change",
                      ok, f"disclaimer.client {'set' if text.strip() else 'empty'}; research.json {st['status']}")
    rows.append(_guard("disclaimer_client", "Client disclaimer", client_text))

    def allow_list():
        cfg = R.effective_mode(d)["config"]
        n = len(cfg.get("internal_domains") or []) + len(cfg.get("internal_addresses") or [])
        return _check("allow_list", "Internal allow-list approved (who counts as internal, separate from clients)",
                      n > 0, f"{n} domains / addresses in effect")
    rows.append(_guard("allow_list", "Allow-list", allow_list))

    def entitlements():
        cfg = R.effective_mode(d)["config"]
        ent = cfg.get("entitlements") or {}
        subs = {}
        p = d / "distribution.json"
        if p.is_file():
            subs = (json.loads(p.read_text(encoding="utf-8")) or {}).get("subscribers") or {}
        gaps = sorted(f"{a} -> {k}" for k, lst in subs.items() for a in lst or []
                      if k not in ent.get(str(a).strip().casefold(), []))
        ok = bool(ent) and not gaps
        return _check("entitlements", "Recipient entitlements configured (research.json entitlements) for every subscriber",
                      ok, f"{len(ent)} recipients entitled" + (f"; not entitled: {gaps[:5]}" if gaps else ""))
    rows.append(_guard("entitlements", "Entitlements", entitlements))

    def register():
        gov = "recipients.json" in ap.FILES and (d / "recipients.json").is_file()
        return _check("recipients", "Governed recipient register (entity, jurisdiction, category, terms accepted, onboarded by)",
                      gov, "present and governed" if gov else "no governed recipients.json (new ticket; docs/research/product-line.md 2.4)")
    rows.append(_guard("recipients", "Recipient register", register))

    def compliance():
        cfg = C.load_config(d)
        ok = bool(cfg["approvers"]) and cfg["allow_self_sign"] is False and cfg.get("status") == "ok"
        return _check("compliance", "Named compliance approver, self-sign off, compliance.json governed", ok,
                      f"approvers {len(cfg['approvers'])}, allow_self_sign {cfg['allow_self_sign']}, status {cfg.get('status')}")
    rows.append(_guard("compliance", "Compliance approver", compliance))

    def adviser():
        gov = "client_readiness.json" in ap.FILES and (d / "client_readiness.json").is_file()
        return _check("adviser", "Compliance adviser records: regulatory scope opinion, independence policy, conflicts "
                      "register, record-keeping policy", gov,
                      "recorded" if gov else "no governed record in the repo; Sam needs a compliance adviser (not checkable here)")
    rows.append(_guard("adviser", "Adviser records", adviser))
    return rows


def render(rows: list[dict]) -> str:
    lines = ["Client-readiness check (EQ-C-0083). A checklist from repo state, not legal advice."]
    for r in rows:
        tag = "PASS" if r["ok"] else ("FAIL*" if r["blocker"] else "FAIL")
        lines.append(f"{tag:5}  {r['id']:17} {r['requirement']}\n       {r['detail']}")
    bad = [r for r in rows if not r["ok"]]
    lines.append(f"{len(rows) - len(bad)} pass, {len(bad)} fail (* hard blocker). "
                 + ("Not ready for client mode: stay internal." if bad else "All records present: Sam decides."))
    return "\n".join(lines) + "\n"


def demo_row(rec: dict) -> dict:
    """EQ-C-0123: the hard-blocker row of a --demo-baseline run (a DEMO baseline is never Sam's approval)."""
    from .licence_gov import DEMO_BANNER
    return _check("demo_baseline", f"HARD BLOCKER: {DEMO_BANNER}", False,
                  f"the licence checks below ran on a DEMO baseline of data/licences.csv (sha256 "
                  f"{rec['register_sha256'][:12]}..., approver {rec['approver']!r}, EQ-C-0123); client output stays "
                  "refused until Sam approves the first real baseline", blocker=True)


def cmd_client_check(args) -> None:
    demo = bool(getattr(args, "demo_baseline", False))
    if getattr(args, "go_live", False):                 # EQ-C-0116: go-live gate (ops/client_golive); a DEMO baseline is a blocker
        from .client_golive import cmd as golive
        if not demo:
            return golive(args)
        from .demo_baseline import DemoBaselineError, active
        try:
            with active(args.data) as rec:              # the gate itself runs after the profile closes (client-pack refuses inside)
                demo_seen = {"how": f"client-check --demo-baseline opened a DEMO profile (approver {rec.get('approver')!r})",
                             "path": None}
        except DemoBaselineError as e:
            raise SystemExit(f"client-check --go-live --demo-baseline: {e}") from None
        return golive(args, demo=demo_seen)
    if demo:                                          # EQ-C-0123: temp DEMO store, deleted afterwards; never ready
        from .demo_baseline import DemoBaselineError, active
        try:
            with active(args.data) as rec:
                rows = [demo_row(rec)] + collect(args.data)
        except DemoBaselineError as e:
            raise SystemExit(f"client-check --demo-baseline: {e}") from None
    else:
        rows = collect(args.data)
    from .client_decision import lines, status         # EQ-C-0105: Sam's decision (later, PI-9) and the no-regret items
    dec = status(args.data, getattr(args, "out", None))
    if args.json:
        doc = {"ready": all(r["ok"] for r in rows), "checks": rows, "decision": dec}
        if demo:
            from .licence_gov import DEMO_BANNER
            doc.update(profile="demo", banner=DEMO_BANNER)
        print(json.dumps(doc, indent=1))
    else:
        if demo:
            from .licence_gov import DEMO_BANNER
            print(f"{DEMO_BANNER} (client-check --demo-baseline, EQ-C-0123)")
        print(render(rows), end="")
        print("\n".join(lines(dec)))
    if not all(r["ok"] for r in rows):
        raise SystemExit(1)


def register(sub) -> None:
    """client-check, added by cli.main."""
    p = sub.add_parser("client-check", help="client-readiness checklist (docs/research/client-readiness.md): PASS/FAIL per "
                       "requirement from repo state; reads only; exit 1 while anything is missing (not legal advice)")
    p.add_argument("--json", action="store_true", help="print the checks as JSON")
    p.add_argument("--demo-baseline", action="store_true",
                   help="DEMO only (EQ-C-0123): run the licence checks on a DEMO baseline of data/licences.csv (temp, "
                        "deleted after); adds a hard blocker, never 'ready', never Sam's approval")
    p.add_argument("--go-live", action="store_true",
                   help="go-live gate (EQ-C-0116): every blocker to switching client mode on with owner, state, evidence and "
                        "what clears it; writes <out>/client_pack/golive.json, golive.md, golive-card.md; changes nothing "
                        "else; exit 0 only with no blockers")
    p.set_defaults(fn=cmd_client_check)
