"""Research QA gate (EQ-C-0163, PI-14, demo row M24): automated checks that a research product quotes its run.

Three checks, run on every research note, scenario brief, weekly brief and trade-ideas page (HTML, plus the JSON
manifests the generators write next to them):

1. numbers   every figure the product quotes for a known measure equals the run it cites, within the rounding
             tolerance: half a unit of the last digit printed (66.2 covers 66.15..66.25; 6.59% covers 6.585%..6.595%),
             and 1e-9 relative for JSON manifests, which carry the full value. Measures: book VaR / ES / EL / L-VaR /
             liquidity cost (summary.metrics), country 12-month default PD (country[].pd_default), scenario losses
             (the stressed column of a scenario brief and each row of the weekly brief's stress table, against that
             stress run's own archived record), book limits, warning levels and limit utilisation (data/limits.json
             book section, utilisation = run metric / limit, as mc_band.book_limit_verdicts) and trade-idea signal
             strengths (run activation table). A product with quoted figures whose run cannot be found fails
             ("cannot verify"); a product with no recognised figure passes the number check with 0 checked.
2. freshness the cited run against the product's own date (file name date, the weekly brief's requested as-of, or the
             archive period): older than alerts.stale_days of data/assumptions.json (45 days) fails. The live
             inputs at the run's model date: the freshness SLA (ingestion.freshness.check_freshness, the pull or the
             run's vintage) and the audit-trail retrieval age (report.stale_inputs, the same stale_days). A breach on a
             cell the quality gate holds is not used by the engine and is ignored; any other breach for a country the
             product covers (a country note: its country; other products: every country) fails unless the product
             discloses it in its Input caveats ("<key> (stale ..." or a "Stale inputs" section naming the key), in
             which case it is listed as a flag. Freshness is skipped, and says so, when the data folder has no pull.
3. agreement products for the same run must quote the same value for the same measure and subject (two notes giving
             Argentina two different PDs for one run fail, whichever is right). Compared within the files checked and
             against peers: the published editorial items (publish) or the latest archived versions (archive add).

The gate is ON by default and only refuses: editorial.publish and archive.add / archive.correct call `gate()` and
refuse with the first failing figures (which number, what was quoted, what was expected and where it came from). It
never edits a product. `qa=False` exists for tests of other behaviour only; no CLI flag turns it off.

    econquest research-qa [--run RUN] [--path FILE|DIR ...] [--json]     exit 1 when any check fails

With no --path: the published editorial items and the latest archived versions under --out. --run (a run id or a
run JSON file) checks every product against that run: a product citing another run fails.

demo_research_qa(out_dir, data_dir=None, outputs_dir=None): demo row M24 (EQ-C-0166 wires it). Offline on
data/mvp/data in temporary folders: a small run, one country note that passes, an altered copy whose PD tile was
changed refused by the gate and by `archive add`. Never reads the repository's outputs/ folder.
"""
from __future__ import annotations

import datetime as dt
import html as _h
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
from collections import Counter
from html.parser import HTMLParser
from pathlib import Path

TICKET = "EQ-C-0163"
SCHEMA = "eq-research-qa/1"
DEMO_ROW = "M24"
DEFAULT_STALE_DAYS = 45
JSON_REL_TOL = 1e-9
TOLERANCE_TEXT = ("half a unit of the last digit printed (percent figures in percentage points); 1e-9 relative for "
                  "JSON manifests")
MAX_REFUSAL_LINES = 6
RUN_ID_RE = re.compile(r"\b\d{8}T\d{6}-[A-Za-z0-9_-]{1,80}")
_RUN_ID_FULL = re.compile(r"^\d{8}T\d{6}-[A-Za-z0-9_.-]{1,80}$")
_DATE_RE = re.compile(r"(\d{4}-\d{2}-\d{2})")
_NUM_RE = re.compile(r"^\s*([+\-−]?)(\d{1,3}(?:,\d{3})+|\d+)(?:\.(\d+))?\s*(%)?")
TEXT_SUFFIXES = (".html", ".htm")

# measure labels as the products print them (normalised: lower case, no "$mm" unit) -> run summary.metrics key
METRIC_LABELS = {
    "var 99%": "var99_mm", "var99": "var99_mm", "var 95%": "var95_mm",
    "es 99%": "es99_mm", "es99": "es99_mm", "es 95%": "es95_mm", "es 97.5% (frtb)": "es975_frtb_mm", "es 97.5%": "es975_frtb_mm",
    "liquidity-adjusted var 99%": "lvar99_mm", "l-var 99%": "lvar99_mm", "l-var99": "lvar99_mm", "lvar 99%": "lvar99_mm",
    "liquidity-adjusted es 99%": "les99_mm", "l-es 99%": "les99_mm",
    "expected loss": "expected_loss_mm", "el": "expected_loss_mm", "liquidity cost 99%": "liquidity_cost99_mm",
}
METRIC_NAMES = {"var99_mm": "VaR 99%", "var95_mm": "VaR 95%", "es99_mm": "ES 99%", "es95_mm": "ES 95%",
                "es975_frtb_mm": "ES 97.5% (FRTB)", "lvar99_mm": "L-VaR 99%", "les99_mm": "L-ES 99%",
                "expected_loss_mm": "Expected loss", "liquidity_cost99_mm": "Liquidity cost 99%"}
BASE_COLS = ("this run", "now", "value", "base", "current", "run")
REF_COLS = ("reference run", "reference")
LIMIT_COLS = ("limit", "book limit")
WARN_COLS = ("warning", "warning level")
KIND_PREFIX = (("country-note-", "country_note"), ("scenario-brief-", "scenario_brief"), ("weekly-brief-", "weekly_brief"),
               ("trade-ideas-", "trade_ideas"), ("daily-report", "daily_report"), ("weekly-monitor", "weekly_monitor"))


class ResearchQAError(ValueError):
    """A research product failed the QA gate; the message names the failing figures."""


# ---------------------------------------------------------------- parsing
def _norm(s) -> str:
    s = " ".join(_h.unescape(str(s or "")).replace("−", "-").split()).lower()
    s = re.sub(r"\s*\(\$mm\)\s*", " ", s)
    s = re.sub(r"\s*\$mm\b", "", s)
    return s.strip()


class _Doc(HTMLParser):
    """Headings, tables (header, rows with their attributes), KPI tiles, the meta stamp line, 'Source:' lines and the
    plain text of a generated product. Text inside script, style and svg is ignored."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.text: list[str] = []
        self.heading = ""
        self.h1 = ""
        self.sub = ""
        self.src = ""
        self.tables: list[dict] = []
        self.kpis: list[dict] = []
        self.meta: list[str] = []
        self.run_attrs: list[str] = []
        self._skip = 0
        self._divs: list[str | None] = []
        self._buf: dict[str, list[str]] = {}
        self._table = None
        self._row = None
        self._kpi = None

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        cls = (a.get("class") or "").split()
        if tag in ("script", "style", "svg"):
            self._skip += 1
            return
        if tag in ("h1", "h2", "h3"):
            self._buf["h"] = []
        elif tag == "p" and "src" in cls:
            self._buf["src"] = []
        elif tag == "table":
            self._table = {"heading": self.heading, "src": self.src, "rows": []}
            self.tables.append(self._table)
        elif tag == "tr" and self._table is not None:
            self._row = {"attrs": a, "cells": []}
            self._table["rows"].append(self._row)
            if a.get("data-run-id"):
                self.run_attrs.append(a["data-run-id"])
        elif tag in ("td", "th") and self._row is not None:
            self._row["cells"].append([tag, ""])
            self._buf["cell"] = []
        elif tag == "div":
            role = None
            if "kpi" in cls:
                role = "kpi"; self._kpi = {"v": "", "l": ""}
            elif self._kpi is not None and cls[:1] in (["v"], ["l"]):
                role = cls[0]; self._buf[role] = []
            elif "meta" in cls:
                role = "meta"
            elif "sub" in cls:
                role = "sub"; self._buf["sub"] = []
            self._divs.append(role)
        elif tag == "span" and self._divs and "meta" in self._divs:
            self._buf["span"] = []

    def handle_endtag(self, tag):
        if tag in ("script", "style", "svg"):
            self._skip = max(0, self._skip - 1)
            return
        if tag in ("h1", "h2", "h3") and "h" in self._buf:
            t = " ".join("".join(self._buf.pop("h")).split())
            self.heading = t
            if tag == "h1" and not self.h1:
                self.h1 = t
        elif tag == "p" and "src" in self._buf:
            self.src = " ".join("".join(self._buf.pop("src")).split())
        elif tag == "table":
            self._table = None; self._row = None
        elif tag == "tr":
            self._row = None
        elif tag in ("td", "th") and "cell" in self._buf and self._row is not None and self._row["cells"]:
            self._row["cells"][-1][1] = " ".join("".join(self._buf.pop("cell")).split())
        elif tag == "span" and "span" in self._buf:
            self.meta.append(" ".join("".join(self._buf.pop("span")).split()))
        elif tag == "div" and self._divs:
            role = self._divs.pop()
            if role in ("v", "l") and self._kpi is not None and role in self._buf:
                self._kpi[role] = " ".join("".join(self._buf.pop(role)).split())
            elif role == "kpi" and self._kpi is not None:
                self.kpis.append({**self._kpi, "heading": self.heading}); self._kpi = None
            elif role == "sub" and "sub" in self._buf and not self.sub:
                self.sub = " ".join("".join(self._buf.pop("sub")).split())

    def handle_data(self, data):
        if self._skip:
            return
        self.text.append(data)
        for b in self._buf.values():
            b.append(data)


def parse_number(text) -> dict | None:
    """{"value", "decimals", "pct"} of a printed figure ('6.59%', '1,234.5', '+52.2', '99.00% (engine cap)',
    '56.3 / grade 6'), or None ('', 'n/a', words)."""
    m = _NUM_RE.match(str(text or ""))
    if not m:
        return None
    sign, whole, frac, pct = m.groups()
    v = float(whole.replace(",", "") + ("." + frac if frac else ""))
    return {"value": -v if sign in ("-", "−") else v, "decimals": len(frac or ""), "pct": bool(pct)}


def _kind_of(name: str, kind: str | None, doc: _Doc | None = None) -> str:
    if kind:
        return kind
    n = Path(name).name.lower()
    for pre, k in KIND_PREFIX:
        if n.startswith(pre):
            return k
    sub = (doc.sub if doc else "").lower()
    for word, k in (("country risk note", "country_note"), ("scenario brief", "scenario_brief"), ("weekly brief", "weekly_brief")):
        if word in sub:
            return k
    return "other"


def _meta_runs(doc: _Doc) -> dict:
    out = {}
    for s in doc.meta:
        m = re.match(r"^(Run|Stress run|Reference run|As of)\s+(\S+)", s)
        if m:
            out.setdefault(m.group(1).lower(), m.group(2))
    return out


def _src_runs(src: str) -> dict:
    out = {}
    for label, key in (("reference run", "reference"), ("base run", "base"), ("run", "base")):
        m = re.search(rf"(?:^|\|\s*|Source:\s*){label}\s+({RUN_ID_RE.pattern})", src, re.I)
        if m and key not in out:
            out[key] = m.group(1)
    return out


# ---------------------------------------------------------------- claims
def _claim(file, where, metric, subject, run_id, role, num: dict | None, printed, scale=1.0, exact=False) -> dict | None:
    if num is None:
        return None
    v = num["value"] / scale
    tol = (JSON_REL_TOL * max(1.0, abs(v))) if exact else (0.5 * 10 ** -num["decimals"]) / scale + 1e-12
    return {"file": file, "where": where, "metric": metric, "subject": subject, "run_id": run_id, "role": role,
            "value": v, "lo": v - tol, "hi": v + tol, "tol": tol, "printed": str(printed), "pct": scale == 100.0,
            "decimals": None if exact else num["decimals"]}


def _pct_num(text):
    n = parse_number(text)
    return n if n and n["pct"] else None


def _is_pd_col(h: str) -> bool:
    return h.startswith("default pd") or h in ("pd", "pd 12m", "pd, 12 months", "12-month pd")


def html_claims(name: str, text: str, kind: str | None = None) -> tuple[list[dict], dict]:
    """(claims, info) of one HTML product. info: kind, country, runs {base, stress, reference}, text (plain)."""
    doc = _Doc()
    try:
        doc.feed(text); doc.close()
    except Exception:                                          # noqa: BLE001 - a malformed file: no claims, reported by info
        pass
    kind = _kind_of(name, kind, doc)
    meta = _meta_runs(doc)
    base = meta.get("run")
    if not base:
        plain_runs = [r for r in doc.run_attrs if "-stress-" not in r]
        base = Counter(plain_runs).most_common(1)[0][0] if plain_runs else None
    if not base:
        m = re.search(rf"(?:Stamped: run|Base run|Run)\s+({RUN_ID_RE.pattern})", " ".join(doc.text))
        base = m.group(1) if m else None
    runs = {"base": base, "stress": meta.get("stress run"), "reference": meta.get("reference run")}
    country = doc.h1.strip() if kind == "country_note" and doc.h1 else None
    claims: list[dict] = []
    add = claims.append

    for k in doc.kpis:                                         # headline tiles: the note's own PD
        lab = _norm(k["l"])
        if country and _is_pd_col(lab):
            c = _claim(name, f"headline tile '{k['l']}'", "pd_default", country, base, "base", _pct_num(k["v"]), k["v"], 100.0)
            c and add(c)

    for t in doc.tables:
        rows = t["rows"]
        if not rows:
            continue
        hdr = rows[0]["cells"] if all(c[0] == "th" for c in rows[0]["cells"]) else []
        cols = [_norm(c[1]) for c in hdr]
        body = rows[1:] if hdr else rows
        srun = _src_runs(t["src"])
        t_base = srun.get("base") or base
        t_ref = srun.get("reference") or runs["reference"]
        heading = t["heading"]
        h_low = heading.lower()
        ci = cols.index("country") if "country" in cols else None
        ti = cols.index("trade") if "trade" in cols else None
        for r in body:
            cells = [c[1] for c in r["cells"]]
            if not cells:
                continue
            row_run = r["attrs"].get("data-run-id") or next((c for c in cells if _RUN_ID_FULL.match(c or "")), None)
            label = cells[0]
            metric = METRIC_LABELS.get(_norm(label))
            where0 = f"section '{heading}', row '{label}'"
            if metric:                                         # measure rows: columns say which run or limit
                rb = row_run if row_run and "-stress-" not in row_run else t_base
                for j, h in enumerate(cols[1:len(cells)], start=1):
                    v, where = cells[j], f"{where0}, column '{hdr[j][1]}'"
                    num = parse_number(v)
                    if num is None:
                        continue
                    if h in BASE_COLS and not num["pct"]:
                        c = _claim(name, where, metric, "book", row_run or rb, "base", num, v)
                    elif h == "stressed" and runs["stress"] and not num["pct"]:
                        c = _claim(name, where, metric, "book", runs["stress"], "stress", num, v)
                    elif h in REF_COLS and t_ref and not num["pct"]:
                        c = _claim(name, where, metric, "book", t_ref, "reference", num, v)
                    elif h in LIMIT_COLS and not num["pct"]:
                        c = _claim(name, where, "limit:" + metric, "book", rb, "limit", num, v)
                    elif h in WARN_COLS and not num["pct"]:
                        c = _claim(name, where, "warning:" + metric, "book", rb, "limit", num, v)
                    elif h == "utilisation" and num["pct"]:
                        lim = next((parse_number(cells[i]) for i, x in enumerate(cols) if x in LIMIT_COLS and i < len(cells)), None)
                        c = _claim(name, where, "utilisation:" + metric, "book", rb, "base", num, v, 100.0)
                        if c and lim:
                            c["row_limit"] = lim["value"]
                    else:
                        c = None
                    c and add(c)
                continue
            if row_run:                                        # one run per row, measures in the columns (stress table)
                for j, h in enumerate(cols[:len(cells)]):
                    m2 = METRIC_LABELS.get(h)
                    num = parse_number(cells[j]) if m2 else None
                    if m2 and num and not num["pct"]:
                        c = _claim(name, f"section '{heading}', row '{label}', column '{hdr[j][1]}'", m2, "book", row_run,
                                   "stress" if "-stress-" in row_run else "base", num, cells[j])
                        c and add(c)
            subj = cells[ci] if ci is not None and ci < len(cells) else country
            if not subj:
                continue
            for j, h in enumerate(cols[:len(cells)]):
                v, where = cells[j], f"section '{heading}', row '{label}', column '{hdr[j][1]}'"
                c = None
                if _is_pd_col(h) and "change" not in h:
                    if "stress" in h:
                        c = runs["stress"] and _claim(name, where, "pd_default", subj, runs["stress"], "stress", _pct_num(v), v, 100.0)
                    elif ci is not None or kind == "country_note":
                        rid = row_run if row_run and "-stress-" not in row_run else t_base
                        c = _claim(name, where, "pd_default", subj, rid, "base", _pct_num(v), v, 100.0)
                elif h == "stressed" and j > 0 and _is_pd_col(cols[j - 1]) and runs["stress"] and ci is not None:
                    c = _claim(name, where, "pd_default", subj, runs["stress"], "stress", _pct_num(v), v, 100.0)
                elif ci is not None and "default pd" in h_low and h in ("this run", "now"):
                    c = _claim(name, where, "pd_default", subj, row_run or t_base, "base", _pct_num(v), v, 100.0)
                elif ci is not None and "default pd" in h_low and h in REF_COLS and t_ref:
                    c = _claim(name, where, "pd_default", subj, t_ref, "reference", _pct_num(v), v, 100.0)
                elif ti is not None and h in ("signal strength", "strength") and ti < len(cells):
                    num = parse_number(v)
                    c = num and not num["pct"] and _claim(name, where, "activation:" + cells[ti], subj, row_run or t_base,
                                                          "base", num, v)
                c and add(c)
    info = {"kind": kind, "country": country, "runs": runs, "text": " ".join(" ".join(doc.text).split()),
            "dates": _DATE_RE.findall(Path(name).name)}
    return claims, info


def json_claims(name: str, data) -> tuple[list[dict], dict]:
    """Claims from the generators' JSON manifests: weekly brief, country-notes.json, trade-ideas.json. Others: none."""
    claims: list[dict] = []
    info = {"kind": "json", "country": None, "runs": {}, "text": "", "dates": _DATE_RE.findall(Path(name).name)}
    if not isinstance(data, dict):
        return claims, info

    def ex(where, metric, subj, rid, role, v):
        try:
            x = float(v)
        except (TypeError, ValueError):
            return
        if math.isfinite(x) and rid:
            claims.append(_claim(name, where, metric, subj, rid, role, {"value": x, "decimals": 0, "pct": False}, v, exact=True))

    secs = data.get("sections")
    if data.get("kind") == "weekly_brief" and isinstance(secs, dict):
        st, rst = data.get("stamps") or {}, data.get("reference_stamps") or {}
        rid, ref = st.get("run_id"), rst.get("run_id")
        info.update(kind="weekly_brief", runs={"base": rid, "reference": ref})
        if data.get("as_of_requested"):
            info["dates"].append(str(data["as_of_requested"])[:10])
        for k, v in ((secs.get("book") or {}).get("metrics") or {}).items():
            if isinstance(v, dict):
                ex(f"JSON sections.book.metrics.{k}.now", k, "book", rid, "base", v.get("now"))
                ex(f"JSON sections.book.metrics.{k}.reference", k, "book", ref, "reference", v.get("reference"))
        for r in (secs.get("limits") or {}).get("rows") or []:
            m = r.get("measure")
            if m:
                ex(f"JSON sections.limits {m}.value", m, "book", rid, "base", r.get("value"))
                ex(f"JSON sections.limits {m}.limit", "limit:" + m, "book", rid, "limit", r.get("limit"))
                ex(f"JSON sections.limits {m}.utilisation", "utilisation:" + m, "book", rid, "base", r.get("utilisation"))
        for r in (secs.get("pd_movers") or {}).get("rows") or []:
            ex(f"JSON sections.pd_movers {r.get('country')}.now", "pd_default", r.get("country"), rid, "base", r.get("now"))
            ex(f"JSON sections.pd_movers {r.get('country')}.prev", "pd_default", r.get("country"), ref, "reference", r.get("prev"))
        for r in (secs.get("stress") or {}).get("rows") or []:
            for m in ("var99_mm", "es99_mm", "expected_loss_mm"):
                ex(f"JSON sections.stress {r.get('scenario')}.{m}", m, "book", r.get("run_id"), "stress", r.get(m))
    elif data.get("kind") in ("country_note", "country_notes") and isinstance(data.get("items"), list):
        info["runs"] = {"base": data.get("run_id")}
        for it in data["items"]:
            if isinstance(it, dict):
                ex(f"JSON items[{it.get('country')}].pd_default", "pd_default", it.get("country"), it.get("run_id"), "base",
                   it.get("pd_default"))
    elif isinstance(data.get("activations"), list):
        info.update(kind="trade_ideas", runs={"base": data.get("run_id")})
        for a in data["activations"]:
            if isinstance(a, dict):
                ex(f"JSON activations[{a.get('trade')}, {a.get('country')}].strength", "activation:" + str(a.get("trade")),
                   a.get("country"), data.get("run_id"), "base", a.get("strength"))
    return [c for c in claims if c], info


# ---------------------------------------------------------------- runs, limits, expected values
class Runs:
    """Archived runs by id: explicit run dicts first, then <dir>/store/archive/<id>.json and <dir>/run_latest.json in
    the search folders (the outputs folder and every folder above a checked file)."""

    def __init__(self, dirs=(), runs=()):
        self.dirs: list[Path] = []
        self.cache: dict[str, dict | None] = {}
        self.where: dict[str, str] = {}
        for d in dirs:
            self.add_dir(d)
        for r in runs:
            self.add_run(r)

    def add_dir(self, d) -> None:
        if d is None:
            return
        p = Path(d)
        if p not in self.dirs:
            self.dirs.append(p)

    def add_run(self, run: dict, where: str = "given") -> str | None:
        rid = _rid(run)
        if rid:
            self.cache[rid] = run; self.where[rid] = where
        return rid

    def get(self, rid) -> dict | None:
        if not rid or not _RUN_ID_FULL.match(str(rid)) or ".." in str(rid):
            return None
        if rid in self.cache:
            return self.cache[rid]
        found = None
        for d in self.dirs:
            for p in (d / "store" / "archive" / f"{rid}.json", d / "run_latest.json"):
                try:
                    if p.is_file():
                        r = json.loads(p.read_text(encoding="utf-8"))
                        if _rid(r) == rid:
                            found = r; self.where[rid] = str(p); break
                except (OSError, ValueError):
                    continue
            if found:
                break
        self.cache[rid] = found
        return found


def _rid(run) -> str | None:
    if not isinstance(run, dict):
        return None
    return (run.get("summary") or {}).get("run_id") or run.get("run_id")


def run_as_of(run: dict) -> str | None:
    s = run.get("summary") or {}
    st = run.get("settings") if isinstance(run.get("settings"), dict) else {}
    v = s.get("versions") or {}
    for x in (st.get("as_of"), s.get("as_of"), v.get("as_of"), (s.get("created_at") or "")[:10]):
        if x:
            return str(x)[:10]
    return None


def _limits(data_dir) -> tuple[dict | None, str]:
    if data_dir is None:
        return None, ""
    from ..presentation.mc_band import load_book_limits
    p = Path(data_dir) / "limits.json"
    return load_book_limits(data_dir), str(p)


def expected(c: dict, run: dict, limits: dict | None, limits_src: str) -> tuple[float | None, str]:
    """(value, source) of what claim `c` should equal, or (None, why)."""
    rid = _rid(run)
    m, subj = c["metric"], c["subject"]
    mets = (run.get("summary") or {}).get("metrics") or {}
    if m == "pd_default":
        row = next((r for r in run.get("country") or [] if str(r.get("country")) == str(subj)), None)
        if row is None:
            return None, f"run {rid} has no country {subj!r}"
        return _f(row.get("pd_default")), f"run {rid} country[{subj}].pd_default"
    if m.startswith("activation:"):
        trade = m.split(":", 1)[1]
        row = next((a for a in run.get("activation") or [] if str(a.get("trade")) == trade), None)
        if row is None or subj not in row:
            return None, f"run {rid} has no activation {trade} for {subj}"
        return _f(row.get(subj)), f"run {rid} activation[{trade}].{subj}"
    if m.startswith(("limit:", "warning:", "utilisation:")):
        kind, key = m.split(":", 1)
        lim = _f(((limits or {}).get("book") or {}).get(key)) if limits else None
        lsrc = f"{limits_src} book.{key}"
        if lim is None and kind == "utilisation" and c.get("row_limit"):
            lim, lsrc = float(c["row_limit"]), "the limit quoted in the same row"
        if lim is None:
            return None, f"no book limit for {key} (data/limits.json)"
        if kind == "limit":
            return lim, lsrc
        if kind == "warning":
            wl = float((limits or {}).get("warning_level", 0.8))
            return wl * lim, f"{limits_src} warning_level {wl:g} x book.{key}"
        v = _f(mets.get(key))
        if v is None or lim <= 0:
            return None, f"run {rid} has no {key}"
        return v / lim, f"run {rid} summary.metrics.{key} / {lsrc}"
    if m in mets:
        return _f(mets.get(m)), f"run {rid} summary.metrics.{m}"
    return None, f"run {rid} has no summary.metrics.{m}"


def _f(v) -> float | None:
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    return x if math.isfinite(x) else None


def _label(c: dict) -> str:
    m = c["metric"]
    if m == "pd_default":
        return f"default PD of {c['subject']}"
    if m.startswith("activation:"):
        return f"signal strength {m.split(':', 1)[1]} {c['subject']}"
    for pre, word in (("limit:", "limit"), ("warning:", "warning level"), ("utilisation:", "limit utilisation")):
        if m.startswith(pre):
            return f"{METRIC_NAMES.get(m[len(pre):], m[len(pre):])} {word}"
    return METRIC_NAMES.get(m, m)


def _fmt(c: dict, v: float) -> str:
    if c["pct"]:
        d = c["decimals"] if c["decimals"] is not None else 4
        return f"{v * 100:,.{d}f}%"
    d = c["decimals"] if c["decimals"] is not None else 6
    return f"{v:,.{d}f}"


def _tol_text(c: dict) -> str:
    return (f"{c['tol'] * 100:.2g} pp" if c["pct"] else f"{c['tol']:.2g}") if c["decimals"] is not None else "1e-9 relative"


# ---------------------------------------------------------------- freshness
def stale_days(data_dir) -> int:
    try:
        a = json.loads((Path(data_dir) / "assumptions.json").read_text(encoding="utf-8"))
        return int((a.get("alerts") or {}).get("stale_days", DEFAULT_STALE_DAYS))
    except (OSError, ValueError, TypeError, AttributeError):
        return DEFAULT_STALE_DAYS


_FRESH_CACHE: dict = {}


def stale_cells(data_dir, as_of: str, vintage: str | None = None) -> tuple[list[dict], str]:
    """Live cells older than their freshness threshold at `as_of` that the engine uses (not held by the gate):
    [{table, key, country, detail, rule}], plus a note ('' or why the SLA check could not run)."""
    d = Path(data_dir)
    key = (str(d.resolve()), as_of, vintage)
    if key in _FRESH_CACHE:
        return _FRESH_CACHE[key]
    out, note = [], ""
    try:
        from ..ingestion.freshness import check_freshness
        vint = vintage if vintage and (d / "live" / "vintages" / str(vintage)).is_dir() else None
        res = check_freshness(d, as_of=as_of, vintage=vint)
        for r in res.to_dict("records"):
            if r.get("status") == "breach" and str(r.get("gate_status") or "").lower() != "hold":
                out.append({"table": r["table"], "key": str(r["key"]), "country": r.get("country") or "",
                            "detail": f"{r.get('detail') or ''}".strip(),
                            "rule": f"freshness SLA {r.get('max_age_days')} days ({r.get('frequency')}; data/live/freshness_sla.csv)"})
    except Exception as e:                                      # noqa: BLE001 - no pull here: said, never a silent pass
        note = f"freshness SLA not checked ({type(e).__name__}: {str(e)[:120]})"
    try:
        from ..presentation.report import stale_inputs
        sd = stale_days(d)
        st = stale_inputs(d, sd, today=dt.date.fromisoformat(as_of))
        for r in ([] if st is None else st.to_dict("records")):
            out.append({"table": str(r["table"]), "key": str(r["key"]), "country": str(r.get("country") or ""),
                        "detail": f"retrieved {r.get('retrieved')}, {r.get('age_days')} days before {as_of}",
                        "rule": f"alerts.stale_days {sd} (data/assumptions.json, audit trail)"})
    except Exception as e:                                      # noqa: BLE001
        note = (note + "; " if note else "") + f"audit-trail staleness not checked ({type(e).__name__})"
    _FRESH_CACHE[key] = (out, note)
    return out, note


def _disclosed(text: str, key: str) -> bool:
    if f"{key} (stale" in text:
        return True
    low = text.lower()
    i = low.find("stale inputs")
    return i >= 0 and re.search(rf"(?<![\w.]){re.escape(key)}(?![\w])", text[i:i + 20000]) is not None


# ---------------------------------------------------------------- the check
def _read(f) -> tuple[str, str | bytes]:
    if isinstance(f, (tuple, list)):
        return str(f[0]), f[1]
    p = Path(f)
    return p.name, p.read_bytes()


def _problem(check, file, message, **kw) -> dict:
    return {"check": check, "file": file, "message": message, **kw}


def check_files(files, *, outputs_dir=None, data_dir=None, run=None, run_id=None, kind=None, as_of=None,
                peers=(), search_dirs=()) -> dict:
    """Check one product (or a set). files: paths or (name, bytes). run: a run dict (or a run id / JSON path) every
    product must cite; run_id: the run the caller registered the product for. peers: claims of other products
    (peer_claims_*) for the agreement check. as_of: the product's own date (archive period). Never raises on content."""
    runs = Runs([outputs_dir, *search_dirs])
    for f in files:
        if not isinstance(f, (tuple, list)):
            for parent in list(Path(f).resolve().parents)[:6]:
                runs.add_dir(parent)
    want = None
    if isinstance(run, dict):
        want = runs.add_run(run)
    elif run:
        p = Path(str(run))
        if p.suffix == ".json" and p.is_file():
            want = runs.add_run(json.loads(p.read_text(encoding="utf-8")), str(p))
        else:
            want = str(run)
    want = want or run_id
    limits, limits_src = _limits(data_dir)
    per_file, problems, flags, all_claims, notes = [], [], [], [], []
    for f in files:
        try:
            name, raw = _read(f)
        except OSError as e:
            problems.append(_problem("read", str(f), f"{f}: cannot be read ({type(e).__name__})"))
            continue
        fp: list[dict] = []
        ff: list[dict] = []
        suffix = Path(name).suffix.lower()
        if suffix in TEXT_SUFFIXES:
            text = raw.decode("utf-8", errors="replace") if isinstance(raw, bytes) else raw
            claims, info = html_claims(name, text, kind)
        elif suffix == ".json":
            try:
                claims, info = json_claims(name, json.loads(raw))
            except ValueError:
                claims, info = [], {"kind": "json", "runs": {}, "text": "", "dates": [], "country": None}
        else:
            continue
        cited = info["runs"].get("base")
        if want and cited and cited != want:
            fp.append(_problem("stamp", name, f"{name}: cites run {cited}, but it is checked as a product of run {want}",
                               quoted=cited, expected=want, source="the run the product was registered or checked for"))
        checked = 0
        for c in claims:
            all_claims.append(c)
            r = runs.get(c["run_id"]) if c["run_id"] else None
            if r is None:
                fp.append(_problem("number", name, f"{name}: {_label(c)} quoted {c['printed']} in {c['where']}; cannot "
                                   f"verify: run {c['run_id'] or '(none cited)'} not found (store/archive or run_latest.json)",
                                   metric=c["metric"], subject=c["subject"], quoted=c["printed"], expected=None,
                                   source=f"run {c['run_id']}"))
                continue
            v, src = expected(c, r, limits, limits_src)
            if v is None:
                if c["metric"].startswith(("limit:", "warning:")) and not limits:
                    continue                                   # no limits file: nothing to compare the level with
                fp.append(_problem("number", name, f"{name}: {_label(c)} quoted {c['printed']} in {c['where']}; "
                                   f"cannot verify: {src}", metric=c["metric"], subject=c["subject"], quoted=c["printed"],
                                   expected=None, source=src))
                continue
            checked += 1
            if not (c["lo"] - 1e-12 <= v <= c["hi"] + 1e-12):
                fp.append(_problem("number", name, f"{name}: {_label(c)} quoted {c['printed']} in {c['where']}; expected "
                                   f"{_fmt(c, v)} (tolerance ±{_tol_text(c)}) from {src}", metric=c["metric"],
                                   subject=c["subject"], quoted=c["printed"], expected=v, source=src, where=c["where"]))
        # freshness: the cited run against the product's date, the live inputs at the run's model date
        base_run = runs.get(cited) if cited else (runs.get(want) if want else None)
        if base_run is not None:
            r_as_of = run_as_of(base_run)
            dates = [x for x in [*info.get("dates", []), str(as_of)[:10] if as_of else None] if x]
            ref = max(dates) if dates else None
            sd = stale_days(data_dir) if data_dir is not None else DEFAULT_STALE_DAYS
            try:
                age = (dt.date.fromisoformat(ref) - dt.date.fromisoformat(r_as_of)).days if ref and r_as_of else None
            except ValueError:
                age = None
            if age is not None and age > sd:
                fp.append(_problem("stale", name, f"{name}: cites run {_rid(base_run)} as of {r_as_of}, {age} days before "
                                   f"the product's date {ref} (limit {sd} days, data/assumptions.json alerts.stale_days)",
                                   quoted=r_as_of, expected=f"a run as of {ref} or at most {sd} days earlier",
                                   source="data/assumptions.json alerts.stale_days"))
            if data_dir is not None and r_as_of and (Path(data_dir) / "live").is_dir():
                vint = ((base_run.get("summary") or {}).get("versions") or {}).get("vintage_id")
                cells, note = stale_cells(data_dir, r_as_of, vint)
                if note:
                    notes.append(note)
                scope = {info["country"]} if info.get("country") else None
                for s in cells:
                    if scope and s["country"] and s["country"] not in scope:
                        continue
                    what = f"{s['table']} {s['key']} {s['country']}".strip()
                    msg = f"{name}: input {what} is stale at the run's model date {r_as_of}: {s['detail']} ({s['rule']})"
                    if info.get("text") and _disclosed(info["text"], s["key"]):
                        ff.append(_problem("stale", name, msg + "; disclosed in the product's input caveats", source=s["rule"]))
                    elif suffix in TEXT_SUFFIXES:
                        fp.append(_problem("stale", name, msg + "; the product does not disclose it", quoted=what,
                                           expected=f"fresh within {s['rule']}", source=s["rule"]))
        per_file.append({"file": name, "kind": info["kind"], "run_id": cited, "claims": len(claims), "checked": checked,
                         "ok": not fp, "problems": [p["message"] for p in fp], "flags": [p["message"] for p in ff]})
        problems += fp; flags += ff
    problems += agreement(all_claims, peers)
    return {"schema": SCHEMA, "ticket": TICKET, "ok": not problems, "files": per_file, "problems": problems,
            "flags": flags, "notes": sorted(set(notes)), "claims": len(all_claims),
            "checked": sum(x["checked"] for x in per_file), "tolerance": TOLERANCE_TEXT, "run": want,
            "runs_found": {k: runs.where.get(k) for k, v in runs.cache.items() if v is not None}}


def agreement(claims: list[dict], peers=()) -> list[dict]:
    """Products for one run must quote one value per measure and subject (intervals of the rounding must overlap)."""
    groups: dict[tuple, list[dict]] = {}
    for c in [*claims, *[{**p, "peer": True} for p in peers]]:
        if c.get("run_id"):
            groups.setdefault((c["run_id"], c["metric"], str(c["subject"])), []).append(c)
    out = []
    for (rid, _m, _s), cs in sorted(groups.items()):
        if not any(not c.get("peer") for c in cs):
            continue
        lo = max(cs, key=lambda c: c["lo"]); hi = min(cs, key=lambda c: c["hi"])
        if lo["lo"] > hi["hi"] + 1e-12 and (not lo.get("peer") or not hi.get("peer")):
            a, b = (hi, lo) if not hi.get("peer") else (lo, hi)
            out.append(_problem("agreement", a["file"], f"{a['file']}: {_label(a)} for run {rid} quoted {a['printed']} in "
                                f"{a['where']}, but {'published/archived ' if b.get('peer') else ''}{b['file']} quotes "
                                f"{b['printed']} in {b['where']} (products for the same run must agree)",
                                metric=a["metric"], subject=a["subject"], quoted=a["printed"], expected=b["printed"],
                                source=f"{b['file']} ({b['where']})"))
    return out


def refusal_text(result: dict, limit: int = MAX_REFUSAL_LINES) -> str:
    ps = result["problems"]
    head = f"research QA refused ({len(ps)} failed check(s), {result['checked']} of {result['claims']} figures verified): "
    more = f"; ... and {len(ps) - limit} more (econquest research-qa --path FILE)" if len(ps) > limit else ""
    return head + "; ".join(p["message"] for p in ps[:limit]) + more


def gate(files, **kw) -> dict:
    """check_files, raising ResearchQAError(refusal_text) when any check fails."""
    r = check_files(files, **kw)
    if not r["ok"]:
        raise ResearchQAError(refusal_text(r))
    return r


# ---------------------------------------------------------------- peers and file collection
def _claims_of(paths) -> list[dict]:
    out = []
    for p in paths:
        p = Path(p)
        try:
            if p.suffix.lower() in TEXT_SUFFIXES:
                out += html_claims(p.name, p.read_text(encoding="utf-8", errors="replace"))[0]
            elif p.suffix.lower() == ".json":
                out += json_claims(p.name, json.loads(p.read_text(encoding="utf-8")))[0]
        except (OSError, ValueError):
            continue
    return out


def published_files(outputs_dir, exclude=()) -> list[Path]:
    """Files of the editorial items in state published (withdrawn and corrected items are left out)."""
    from ..presentation import editorial as E
    out = []
    try:
        items = E.list_items(outputs_dir, state="published")
    except Exception:                                          # noqa: BLE001 - no or unreadable ledger: no peers
        return out
    for it in items:
        if it.get("item_id") in set(exclude or ()) or not it.get("published_dir"):
            continue
        d = Path(outputs_dir) / it["published_dir"]
        out += [p for p in sorted(d.glob("*")) if p.is_file() and p.name != "manifest.json"]
    return out


def archive_files(out_dir, exclude=()) -> list[Path]:
    """Files of the latest version of every archived item."""
    from ..presentation import archive as A
    out = []
    try:
        its = A.items(out_dir)
    except Exception:                                          # noqa: BLE001
        return out
    root = A.archive_root(out_dir)
    for iid, it in its.items():
        if iid in set(exclude or ()) or not it.get("versions"):
            continue
        last = it["versions"][-1]
        d = root / str(it.get("product")) / iid / f"v{last['version']}"
        out += [d / f["name"] for f in last.get("files") or [] if (d / f["name"]).is_file()]
    return out


def peer_claims(paths) -> list[dict]:
    return _claims_of(paths)


def collect(paths) -> list[Path]:
    """HTML products and known JSON manifests under the given files/folders; archive version folders: latest only."""
    out: list[Path] = []
    for p in paths:
        p = Path(p)
        if p.is_file():
            out.append(p); continue
        if not p.is_dir():
            continue
        found = sorted(x for x in p.rglob("*") if x.is_file() and x.suffix.lower() in (*TEXT_SUFFIXES, ".json")
                       and x.name not in ("manifest.json", "pack.json", "check.json") and not x.name.startswith("index"))
        latest: dict[Path, int] = {}
        for x in found:
            m = re.match(r"^v(\d+)$", x.parent.name)
            if m:
                latest[x.parent.parent] = max(latest.get(x.parent.parent, 0), int(m.group(1)))
        for x in found:
            m = re.match(r"^v(\d+)$", x.parent.name)
            if m and int(m.group(1)) != latest[x.parent.parent]:
                continue
            out.append(x)
    return out


# ---------------------------------------------------------------- CLI
def default_paths(outputs_dir) -> list[Path]:
    return published_files(outputs_dir) + archive_files(outputs_dir)


def cmd_research_qa(args) -> None:
    out = Path(args.out)
    paths = collect(args.path) if args.path else default_paths(out)
    if args.path and not paths:
        raise SystemExit(f"research-qa: no HTML or JSON product under {', '.join(args.path)}")
    r = check_files(paths, outputs_dir=out, data_dir=Path(args.data), run=args.run)
    if args.json:
        print(json.dumps(r, indent=1, default=str))
    else:
        print(f"research QA: {len(r['files'])} file(s), {r['checked']} of {r['claims']} quoted figures verified against "
              f"their runs; tolerance {TOLERANCE_TEXT}")
        for f in r["files"]:
            print(f"  {'ok  ' if f['ok'] else 'FAIL'} {f['file']} ({f['kind']}, run {f['run_id'] or '-'}): "
                  f"{f['checked']}/{f['claims']} figures")
        for p in r["problems"]:
            print(f"  FAIL [{p['check']}] {p['message']}")
        for p in r["flags"]:
            print(f"  flag [{p['check']}] {p['message']}")
        for n in r["notes"]:
            print(f"  note: {n}")
        print("research QA: " + ("pass" if r["ok"] else f"FAILED ({len(r['problems'])} problem(s))"))
    sys.exit(0 if r["ok"] else 1)


def register(sub) -> None:
    p = sub.add_parser("research-qa", help="research QA gate (EQ-C-0163): every figure in notes, briefs and trade ideas "
                                           "equals the run it cites, no stale data, products for one run agree; exit 1 on failure")
    p.add_argument("--run", help="run id or run JSON file every product must cite and is checked against")
    p.add_argument("--path", action="append", help="product file or folder (repeatable; default: published and archived items)")
    p.add_argument("--json", action="store_true", help="machine-readable result")
    p.set_defaults(fn=cmd_research_qa)


# ---------------------------------------------------------------- demo row M24 (EQ-C-0166 wires it)
def _pkg_root() -> Path:
    return Path(__file__).resolve().parents[2]


def _cli(data: Path, out: Path, *argv, timeout=600) -> subprocess.CompletedProcess:
    env = {**os.environ, "PYTHONPATH": os.pathsep.join([str(_pkg_root()), os.environ.get("PYTHONPATH", "")]).rstrip(os.pathsep)}
    return subprocess.run([sys.executable, "-m", "econquest", "--data", str(data), "--out", str(out), *argv],
                          capture_output=True, text=True, timeout=timeout, cwd=str(out.parent), env=env)


def demo_research_qa(out_dir, *, data_dir=None, outputs_dir=None, as_of=None, country=None, paths: int = 4096) -> dict:
    """Demo row M24: one country note that passes the gate, and an altered copy (its PD tile moved by 1 pp) refused by
    the gate and by `archive add`. data_dir: default data/mvp/data (copied to a temp home). outputs_dir: an outputs
    folder that already holds a run (run_latest.json + store) to reuse; default a temp folder with a small run
    (`econquest run --paths 4096`). Writes <out_dir>/research_qa/ (the two notes, report.json). Never reads the
    repository's outputs/. {"ok", "problems", "summary", ...}; never raises on a failed check."""
    out_dir = Path(out_dir)
    dest = out_dir / "research_qa"
    problems: list[str] = []
    info: dict = {"row": DEMO_ROW, "ticket": TICKET}
    src_data = Path(data_dir) if data_dir else _pkg_root() / "data" / "mvp" / "data"
    try:
        if not (src_data / "countries.csv").is_file():
            return {"ok": False, "problems": [f"no data folder at {src_data}"], "summary": "M24 research QA: no data"}
        if as_of is None:
            try:
                as_of = json.loads((src_data.parent / "manifest.json").read_text(encoding="utf-8")).get("as_of")
            except (OSError, ValueError):
                as_of = None
            as_of = as_of or "2026-10-23"
        with tempfile.TemporaryDirectory(prefix="eq-m24-") as tmp:
            home = Path(tmp)
            data = home / "data"
            shutil.copytree(src_data, data)
            out = Path(outputs_dir) if outputs_dir else home / "outputs"
            out.mkdir(parents=True, exist_ok=True)
            if not (out / "run_latest.json").is_file():
                p = _cli(data, out, "run", "--paths", str(paths), "--no-paths", "--as-of", str(as_of))
                if p.returncode != 0:
                    return {"ok": False, "problems": [f"econquest run failed: {(p.stderr or p.stdout)[-300:]}"],
                            "summary": "M24 research QA: the run did not complete"}
            run = json.loads((out / "run_latest.json").read_text(encoding="utf-8"))
            rid = _rid(run)
            names = [r.get("country") for r in run.get("country") or []]
            country = country or ("Argentina" if "Argentina" in names else names[0])
            notes = home / "notes"
            p = _cli(data, out, "notes", "--country", country, "--dest", str(notes))
            html = sorted(notes.glob("country-note-*.html"))
            if p.returncode != 0 or not html:
                return {"ok": False, "problems": [f"econquest notes failed: {(p.stderr or p.stdout)[-300:]}"],
                        "summary": "M24 research QA: the note was not built"}
            good = html[0]
            dest.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(good, dest / good.name)
            ok_r = check_files([good, notes / "country-notes.json"], outputs_dir=out, data_dir=data, run_id=rid)
            info["passing"] = {"file": good.name, "ok": ok_r["ok"], "checked": ok_r["checked"], "claims": ok_r["claims"],
                               "flags": len(ok_r["flags"]), "notes": ok_r["notes"]}
            if not ok_r["ok"]:
                problems += [f"the unaltered note failed: {x['message']}" for x in ok_r["problems"][:5]]
            if ok_r["checked"] == 0:
                problems.append("the unaltered note quoted no figure the gate could verify")
            # the altered copy: the PD tile moved by +1.00 pp
            pd = next((r.get("pd_default") for r in run["country"] if r.get("country") == country), None)
            text = good.read_text(encoding="utf-8")
            shown = f"{pd * 100:.2f}%"
            wrong = f"{pd * 100 + 1.0:.2f}%"
            if f">{shown}<" not in text:
                problems.append(f"the note does not show the PD tile {shown}")
            bad_dir = home / "altered"; bad_dir.mkdir()
            bad = bad_dir / good.name
            bad.write_text(text.replace(f">{shown}<", f">{wrong}<", 1), encoding="utf-8")
            shutil.copyfile(bad, dest / f"altered-{good.name}")
            bad_r = check_files([bad], outputs_dir=out, data_dir=data, run_id=rid)
            pd_fail = [x for x in bad_r["problems"] if x.get("metric") == "pd_default"]
            info["refused"] = {"file": bad.name, "ok": bad_r["ok"], "problems": [x["message"] for x in bad_r["problems"][:5]]}
            if bad_r["ok"] or not pd_fail:
                problems.append("the altered note was not refused on its PD")
            elif not (wrong in pd_fail[0]["message"] and shown in pd_fail[0]["message"] and "pd_default" in pd_fail[0]["message"]):
                problems.append(f"the refusal does not name the quoted value, the expected value and its source: {pd_fail[0]['message']}")
            # archive add: the good note is archived, the altered copy is refused (number and agreement)
            from ..presentation import archive as A
            arch_out = home / "archive_home" / "outputs"; arch_out.mkdir(parents=True)
            stamps = {"period": as_of, "by": "econquest demo (M24)", "country": country, "subject": country,
                      "run_id": rid, "code_hash": ((run.get("summary") or {}).get("versions") or {}).get("code_hash") or "demo"}
            added = A.add(arch_out, "country_note", [good], search_dirs=[out], data_dir=data, **stamps)
            info["archived"] = added["ref"]
            try:
                A.add(arch_out, "country_note", [bad], search_dirs=[out], data_dir=data, **{**stamps, "subject": f"{country} copy"})
                problems.append("archive add accepted the altered note")
                info["archive_refusal"] = None
            except A.ArchiveError as e:
                info["archive_refusal"] = str(e)[:600]
                if "research QA refused" not in str(e) or wrong not in str(e):
                    problems.append(f"the archive refusal did not come from the research QA gate: {str(e)[:200]}")
            agree = check_files([bad], outputs_dir=out, data_dir=data, run_id=rid, peers=peer_claims(archive_files(arch_out)))
            info["agreement_refusal"] = [x["message"] for x in agree["problems"] if x["check"] == "agreement"][:2]
            if not info["agreement_refusal"]:
                problems.append("the altered note was not refused for disagreeing with the archived note")
            report = {"schema": SCHEMA, "row": DEMO_ROW, "run_id": rid, "as_of": as_of, "country": country,
                      "passing": ok_r, "refused": bad_r}
            (dest / "report.json").write_text(json.dumps(report, indent=1, default=str) + "\n", encoding="utf-8")
            info["paths"] = {"dir": str(dest), "report": str(dest / "report.json")}
            summary = (f"M24 research QA: {good.name} passes ({ok_r['checked']} of {ok_r['claims']} figures verified "
                       f"against run {rid}); the altered copy (PD {shown} -> {wrong}) is refused"
                       + (" by the gate and by archive add" if info.get("archive_refusal") else "")
                       + (f"; {len(problems)} problems" if problems else ""))
    except Exception as e:                                      # noqa: BLE001 - reported, never a silent pass
        problems.append(f"demo_research_qa raised {type(e).__name__}: {str(e)[:300]}")
        summary = f"M24 research QA: did not complete ({type(e).__name__})"
    return {"ok": not problems, "problems": problems, "summary": summary, **info}
