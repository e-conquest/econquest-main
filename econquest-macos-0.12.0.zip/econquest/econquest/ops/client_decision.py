"""Sam's client-mode decision and its no-regret items (EQ-C-0105). Read-only; shown by the readiness page
(presentation/readiness.py, GUI Readiness tab), `econquest client-pack` (ops/client_pack.py) and `econquest client-check`.

Sam chose option (c) on 2026-10-25 at 11:29Z (decision card in the Team C thread, recorded by EQ-C-0104 at the end of
docs/research/client-mode-decision-pack.md): client mode LATER, revisited at PI-9 with licensed data. research.json
stays internal. The no-regret items go ahead meanwhile; `status` scores each from repo state, so the pages show
progress without anyone editing this file:

    R44                    data/licences.csv under `econquest change` (EQ-C-0106, Team C)
    client_safe_rule_gap   Team B's client-safe copy replaces 177 cells, enforcement withholds 492 (Team B, PI-9)
    licence_verification   licence texts filed and terms_verified=yes per source (Team A, EQ-A-0076)

Nothing here changes the mode: this module only reports. A new decision is a new record (decision doc + this table).
"""
from __future__ import annotations

from pathlib import Path

TICKET = "EQ-C-0105"
DECISION_DOC = "docs/research/client-mode-decision-pack.md"
DECISION = {
    "by": "Sam", "decided_utc": "2026-10-25T11:29Z", "date": "2026-10-25", "option": "c", "choice": "later",
    "text": "Client mode later: revisit at PI-9 with licensed data. Client mode stays off (research.json mode internal).",
    "revisit": "PI-9 planning", "recorded_by": "EQ-C-0104", "doc": DECISION_DOC,
    "doc_marker": "Sam, 2026-10-25 11:29Z",
}
# Recorded numbers (EQ-C-0094 pack, HO-20261025-C-B-002); `status` also reports the live numbers when it can read them.
GAP_RECORDED = {"team_b_cells": 177, "enforced_cells": 492}
NO_REGRET = (
    {"id": "R44", "what": "Licence register data/licences.csv under change control (econquest change: four-eyes or EXC, "
     "tighten-only, drift check)", "owner": "Team C", "ref": "EQ-C-0106"},
    {"id": "client_safe_rule_gap", "what": "Client-safe rule gap: Team B's client-safe copy replaces 177 cells while licence "
     "enforcement withholds 492; one client-output rule, then Team B reruns the comparison", "owner": "Team B (PI-9)",
     "ref": "HO-20261025-C-B-002"},
    {"id": "licence_verification", "what": "Licence verification: each source's licence text filed and terms_verified=yes "
     "in data/licences.csv", "owner": "Team A", "ref": "EQ-A-0076"},
)


def _r44(d: Path) -> tuple[str, str]:
    from ..presentation.licences import REGISTER_NAME, register_governed
    from . import approvals as ap
    if REGISTER_NAME not in ap.FILES:
        return "open", "data/licences.csv is not a governed file yet (ops/approvals.FILES)"
    if register_governed(d):
        return "done", "data/licences.csv is governed and its current bytes were applied through econquest change"
    return "open", "data/licences.csv is a governed file but its current bytes are not the last applied change"


def _gap(d: Path, outputs_dir) -> tuple[str, str]:
    rec = f"recorded {GAP_RECORDED['team_b_cells']} vs {GAP_RECORDED['enforced_cells']} cells"
    if outputs_dir is None:
        return "open", rec
    from ..presentation.licences import internal_groups, safe_evaluate
    from .client_pack import find_comparison, read_comparison
    cmp = read_comparison(find_comparison(outputs_dir))
    changed = (cmp.get("manifest") or {}).get("cells_changed")
    enforced = sum(len(g["countries"]) for g in internal_groups(safe_evaluate(d)))
    if not cmp.get("ok") or not isinstance(changed, int):
        return "open", f"{rec}; Team B's comparison not readable now"
    state = "open" if enforced > changed else "done"
    return state, f"{rec}; now Team B {changed}, enforcement {enforced}"


def _verification(d: Path) -> tuple[str, str]:
    from ..ingestion import licences as A
    rows = A.load_register(d / "licences.csv")
    if not rows:
        return "open", "no licence register rows (data/licences.csv missing or empty): nothing verified"
    todo = sorted(r["source_id"] for r in rows if r["terms_verified"] != "yes")
    if not todo:
        return "done", f"all {len(rows)} register rows terms_verified=yes"
    return "open", f"{len(rows) - len(todo)} of {len(rows)} rows verified; to verify: {', '.join(todo[:8])}" + \
        (f" and {len(todo) - 8} more" if len(todo) > 8 else "")


def status(data_dir, outputs_dir=None, root=None) -> dict:
    """{"decision": DECISION + {"recorded": bool}, "no_regret": [item + {"status": done|open|unknown, "detail"}],
    "summary": one line}. Never raises; a check that cannot run says "unknown"."""
    d = Path(data_dir)
    rt = Path(root) if root is not None else d.resolve().parent
    try:
        doc = (rt / DECISION_DOC).read_text(encoding="utf-8")
        recorded = DECISION["doc_marker"] in doc
    except OSError:
        recorded = False
    items = []
    for it, fn in zip(NO_REGRET, (lambda: _r44(d), lambda: _gap(d, outputs_dir), lambda: _verification(d))):
        try:
            st, detail = fn()
        except Exception as e:                                # noqa: BLE001 - shown as unknown
            st, detail = "unknown", f"could not be checked ({type(e).__name__})"
        items.append({**it, "status": st, "detail": detail})
    dec = {**DECISION, "recorded": recorded}
    done = sum(i["status"] == "done" for i in items)
    summary = (f"Sam decided {dec['decided_utc']}: client mode {dec['choice']}, revisit at {dec['revisit']} with licensed "
               f"data; client mode stays off. No-regret items: {done} of {len(items)} done.")
    return {"ticket": TICKET, "decision": dec, "no_regret": items, "summary": summary}


def lines(st: dict) -> list[str]:
    """Plain-text lines for the CLI outputs."""
    out = [st["summary"] + ("" if st["decision"]["recorded"] else f" (decision line not found in {DECISION_DOC})")]
    out += [f"    [{i['status']}] {i['id']} ({i['owner']}, {i['ref']}): {i['what']}. {i['detail']}." for i in st["no_regret"]]
    return out
