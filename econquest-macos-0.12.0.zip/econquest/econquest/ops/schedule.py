"""Scheduled jobs on Sam's Mac (EQ-C-0021): launchd plists in ~/Library/LaunchAgents/com.econquest.<job>.plist.

Jobs (times are in `tz`, default America/New_York; change them in <home>/ops.json or with the CLI flags):

    record   weekdays 18:20  `econquest record`, then `python -m econquest.ingestion.market_history build --start
                             2023-10-18` (official BIS/ECB FX history, staged only: no --apply until Team B accepts
                             HO-20261024-A-B-004; HO-20261024-A-C-009). The GOOGLEFINANCE path (Sheets API export of the
                             Market History tab + `econquest prices --sheet-json`) is retired (EQ-A-0054).
                             (docs/runbooks/A-daily-record.md)
    morning  weekdays 07:00  `econquest run` then `econquest report`
    monitor  Mondays  07:45  `econquest monitor` (weekly risk monitor)
    model_monitoring  Mondays 08:15  `python -m econquest.validation.monitoring --root <home>` (EQ-B-0074,
                             HO-20261024-B-C-007); missed-run evidence: mtime of outputs/monitoring/monitoring_alerts.json
    forecast_scorecard  day 2 of each month 08:45  `python -m econquest.validation.forecast_scorecard --as-of <run date>`
                             (EQ-B-0073, HO-20261024-B-C-006)
    calendar_tests  daily 08:30  `python -m econquest.ops.calendar_jobs run --home <home> --as-of <run date>`
                             (EQ-C-0095): progress of the calendar-gated formal tests (250-day VaR backtest from
                             2027-07-14, 12-month benchmark and trade-idea scoring from 2027-10-23); "not due, N days
                             left" before the date, Team B's formal_verdicts (EQ-C-0100) or a "due" alert after it; exit 2 = new alert
    data_ops daily    06:30  `python -m econquest.ingestion.events.incremental run --source all --json`, then
                             `python -m econquest.ingestion.freshness check --json` (EQ-A-0052, HO-20261024-A-C-012),
                             then `python -m econquest.ingestion.freshness prices --json` (the record's input
                             data/market_history/prices.csv against the 30-day official FX SLA, EQ-A-0119,
                             HO-20261025-A-C-028; read only). Every step always runs (keep_going); the job exits with
                             the worst code (1 over 2 over 0) and health reports each step (a breach is a warning). UCDP_API_TOKEN comes from the environment, else the Keychain
                             item econquest-ucdp, read by the step's own shell at run time: never argv, never the plist.
    shadow_ratings  weekdays 09:00  `python -m econquest.engine.shadow_ratings --as-of <run date>` after the morning run
                             (EQ-B-0081, HO-20261024-B-C-012): outputs/shadow_ratings.csv/.md (flag + note, never a
                             rating action)
    benchmark_snapshot  weekdays 09:30  `python -m econquest.validation.benchmark_job --home <home> --as-of <run date>`
                             (EQ-B-0125, HO-20261026-B-C-003, gap G-07): the monthly benchmark snapshot; it self-gates,
                             so the first weekday run in a month appends the snapshot to data/benchmarks.csv and
                             outputs/benchmarks/<YYYY-MM>/ and later runs log "not due" (exit 0, a normal run); a Mac off
                             on the 1st catches up on the next weekday. Exit 2 = written with unexplained drift (alert),
                             1 = error (health reports both)
    dq_report  day 1 of each month 07:30  `python -m econquest.ingestion.dq_report build --as-of <run date>`: the data
                             quality report for the month before the run date (EQ-A-0065, HO-20261024-A-C-018);
                             outputs/dq/<YYYY-MM>/; exit 2 = findings, 1 = error (health reports both)
    ops_report  Mondays 07:30  `python -m econquest.ops.ops_report --home <home> --as-of <run date>` (EQ-C-0110):
                             INTERNAL weekly operations report for the 7 days before the run (runs and base-number
                             moves, job outcomes incl. missed runs, gate holds/releases, alerts and incidents, calendar
                             test progress, freshness SLA, open items, this check) in outputs/reports/ops/
    backup   daily    23:30  `python -m econquest.ops.backup --verify` (EQ-C-0022)
    health   every 15 minutes `python -m econquest.ops.health`

Placeholders in steps: {home}, {launcher}, {python} and {spreadsheet_id} are filled at install time; {as_of} is filled
by the job wrapper (jobs.py) at run time with the run date in the schedule's tz, so a plist never carries a fixed date.
A job with "day" (1-28) runs monthly on that day of the month instead of on "weekdays".

Every job runs through the wrapper `python -m econquest.ops.jobs` (jobs.py), which records start, end and exit code
in outputs/logs/ so the health check can see failures. stdout/stderr go to outputs/logs/<job>.out.log / .err.log.

Time zone assumption: launchd's StartCalendarInterval uses the Mac's local clock. Sam is in New York (the record
runbook's 6:20pm New York), so the default assumes the Mac runs on America/New_York and writes the times unchanged.
If the Mac's local zone differs, `install` converts each time to the local clock for today's offsets and prints a
warning: the conversion is then wrong after a DST change in either zone, so reinstall at each change.

`check` (EQ-C-0110) reads only: it compares every expected job (the config above, with the same paths and flags as
install) with ~/Library/LaunchAgents/com.econquest.<job>.plist and reports each as ok, missing (no plist) or stale
(the plist differs from what install would write now: rerun `econquest schedule install --load`); any other
com.econquest.*.plist there is "unexpected". It never runs launchctl, so it says what is on disk, not what launchd
loaded (`launchctl print gui/$UID/com.econquest.<job>` tells that). A plist that differs only because a newer
release added steps to its job (EQ-C-0144) is still counted stale, with reason "older_release", shown as "update" and
worded as a normal upgrade (install updates it); a missing job while others are installed has reason "new_job".

`install` and `uninstall` only write or remove plist files and print the `launchctl` commands; they run launchctl
only with load=True (`--load`) on macOS. Plists never contain a token or password: no job calls the Sheets API
(the Market History export was retired with the GOOGLEFINANCE prices, EQ-A-0054), and jobs.py loads alert settings
from <home>/.ops.env (chmod 600) when present.
"""
from __future__ import annotations
import argparse
import copy
import datetime as dt
import json
import os
import plistlib
import re
import shlex
import subprocess
import sys
from pathlib import Path

LABEL_PREFIX = "com.econquest."
DEFAULT_TZ = "America/New_York"
SPREADSHEET_ID = "1w4OLCkv4EvDFgaO6MBOipAuY2fjAlCQJ-OjtmHJshQY"     # the Risk Desk workbook (cli.py record default)
WEEKDAYS = [1, 2, 3, 4, 5]                                          # launchd Weekday: 0/7 Sunday, 1 Monday ... 6 Saturday
ALL_DAYS = [0, 1, 2, 3, 4, 5, 6]

AS_OF = "{as_of}"                                                   # run-time placeholder, filled by jobs.py
UCDP_KEYCHAIN_SERVICE = "econquest-ucdp"                            # as docs/runbooks/A-event-feeds.md and open_items
# Daily incremental events step (HO-20261024-A-C-012). bash -c with the python path as $0 (no quoting of paths); the
# token goes from the Keychain into the environment of the exec'd python only, never onto a command line.
INCREMENTAL_SCRIPT = (
    'set -uo pipefail\n'
    'if [ -z "${UCDP_API_TOKEN:-}" ] && command -v security >/dev/null 2>&1; then\n'
    '  UCDP_API_TOKEN="$(security find-generic-password -s ' + UCDP_KEYCHAIN_SERVICE + ' -w 2>/dev/null || true)"\n'
    'fi\n'
    'if [ -n "${UCDP_API_TOKEN:-}" ]; then export UCDP_API_TOKEN; else unset UCDP_API_TOKEN; fi\n'
    'exec "$0" -m econquest.ingestion.events.incremental run --source all --json --data "$ECONQUEST_HOME/data"\n'
)
FX_HISTORY_START = "2023-10-18"     # fixed start: the history grows like before, not a rolling window (HO-20261024-A-C-009)
# Official FX history build (EQ-A-0054). Default: staged only, after record, so a BIS/ECB outage cannot stop the
# forecast record. ops.json "record_job_apply_prices": true (off by default; EQ-C-0086) switches the record job to
# build --apply FIRST, then record, with keep_going so a failed build still lets record run and the job exits with the
# worst code. Turn it on only after Sam's first manual `market_history apply` and Team B's dossier section 7 checks
# (docs/validation/dossier/fx-only-prices.md; team/runbooks/C-schedule.md).
FX_HISTORY_STEP = ["{python}", "-m", "econquest.ingestion.market_history", "--data", "{home}/data", "build",
                   "--start", FX_HISTORY_START]
RECORD_APPLY_KEY = "record_job_apply_prices"
RECORD_STEP = ["{launcher}", "record"]

# EQ-A-0119 / HO-20261025-A-C-028: last priced date of each prices.csv column vs the fx3m SLA, plus record_date
FRESHNESS_PRICES_STEP = ["{python}", "-m", "econquest.ingestion.freshness", "prices", "--json", "--data", "{home}/data"]

DEFAULT_JOBS: dict[str, dict] = {
    "record": {"hour": 18, "minute": 20, "weekdays": WEEKDAYS, "max_minutes": 30, "evidence": "forecast_record",
               "steps": [RECORD_STEP, FX_HISTORY_STEP]},
    "morning": {"hour": 7, "minute": 0, "weekdays": WEEKDAYS, "max_minutes": 90, "evidence": "store_run",
                "steps": [["{launcher}", "run"], ["{launcher}", "report"]]},
    "monitor": {"hour": 7, "minute": 45, "weekdays": [1], "max_minutes": 30, "evidence": "job",
                "steps": [["{launcher}", "monitor"]]},
    "model_monitoring": {"hour": 8, "minute": 15, "weekdays": [1], "max_minutes": 20, "evidence": "monitoring_alerts",
                         "steps": [["{python}", "-m", "econquest.validation.monitoring", "--root", "{home}"]]},
    "forecast_scorecard": {"day": 2, "hour": 8, "minute": 45, "max_minutes": 20, "evidence": "job",
                           "steps": [["{python}", "-m", "econquest.validation.forecast_scorecard", "--as-of", AS_OF,
                                      "--data-dir", "{home}/data", "--out-dir", "{home}/outputs"]]},
    "calendar_tests": {"hour": 8, "minute": 30, "weekdays": ALL_DAYS, "max_minutes": 10, "evidence": "job",
                       "steps": [["{python}", "-m", "econquest.ops.calendar_jobs", "run", "--home", "{home}", "--as-of", AS_OF]]},
    "data_ops": {"hour": 6, "minute": 30, "weekdays": ALL_DAYS, "max_minutes": 45, "evidence": "job", "keep_going": True,
                 "steps": [["/bin/bash", "-c", INCREMENTAL_SCRIPT, "{python}"],
                           ["{python}", "-m", "econquest.ingestion.freshness", "check", "--json", "--data", "{home}/data"],
                           FRESHNESS_PRICES_STEP]},
    "shadow_ratings": {"hour": 9, "minute": 0, "weekdays": WEEKDAYS, "max_minutes": 15, "evidence": "job",
                       "steps": [["{python}", "-m", "econquest.engine.shadow_ratings", "--as-of", AS_OF,
                                  "--archive", "{home}/outputs/store/archive", "--data", "{home}/data", "--out", "{home}/outputs"]]},
    "benchmark_snapshot": {"hour": 9, "minute": 30, "weekdays": WEEKDAYS, "max_minutes": 20, "evidence": "job",
                           "steps": [["{python}", "-m", "econquest.validation.benchmark_job", "--home", "{home}",
                                      "--as-of", AS_OF]]},
    "dq_report": {"day": 1, "hour": 7, "minute": 30, "max_minutes": 10, "evidence": "job",
                  "steps": [["{python}", "-m", "econquest.ingestion.dq_report", "build", "--data", "{home}/data", "--as-of", AS_OF]]},
    "ops_report": {"hour": 7, "minute": 30, "weekdays": [1], "max_minutes": 15, "evidence": "job",
                   "steps": [["{python}", "-m", "econquest.ops.ops_report", "--home", "{home}", "--as-of", AS_OF]]},
    "backup": {"hour": 23, "minute": 30, "weekdays": ALL_DAYS, "max_minutes": 60, "evidence": "job",
               "steps": [["{python}", "-m", "econquest.ops.backup", "--home", "{home}", "--verify"]]},
    "health": {"interval_minutes": 15, "max_minutes": 5, "evidence": None,
               "steps": [["{python}", "-m", "econquest.ops.health", "--home", "{home}"]]},
}

DEFAULT_CONFIG = {"tz": DEFAULT_TZ, "grace_minutes": 15, "stale_feed_days": 7, "holidays": [],
                  "spreadsheet_id": SPREADSHEET_ID, RECORD_APPLY_KEY: False, "jobs": DEFAULT_JOBS}


def record_apply_prices(cfg: dict) -> bool:
    """The ops.json switch, strictly boolean: only a JSON true turns the scheduled prices apply on."""
    return (cfg or {}).get(RECORD_APPLY_KEY) is True


def record_mode(cfg: dict) -> str:
    return ("apply: market_history build --apply, then record (build failure does not stop record)" if record_apply_prices(cfg)
            else "staged: record, then market_history build without --apply (prices.csv unchanged)")


def effective_job(name: str, job: dict, cfg: dict) -> dict:
    """The job as installed. With the switch on, the default record job becomes [build --apply, record] + keep_going.
    A record job whose steps were customised in ops.json is left as written."""
    if name != "record" or not record_apply_prices(cfg) or job.get("steps") != DEFAULT_JOBS["record"]["steps"]:
        return job
    return {**job, "keep_going": True, "steps": [FX_HISTORY_STEP + ["--apply"], RECORD_STEP]}


def _merge(base: dict, over: dict) -> dict:
    out = copy.deepcopy(base)
    for k, v in (over or {}).items():
        out[k] = _merge(out[k], v) if isinstance(v, dict) and isinstance(out.get(k), dict) else copy.deepcopy(v)
    return out


def load_config(home: str | Path, overrides: dict | None = None) -> dict:
    """Defaults, then <home>/ops.json (Sam's local settings, optional), then `overrides`."""
    cfg = copy.deepcopy(DEFAULT_CONFIG)
    p = Path(home) / "ops.json"
    if p.exists():
        cfg = _merge(cfg, json.loads(p.read_text()))
    return _merge(cfg, overrides or {})


def paths(home: str | Path, launcher: str | Path | None = None, python: str | Path | None = None,
          launch_agents: str | Path | None = None) -> dict:
    """Absolute paths the plists use. The launcher is the one install.sh writes ($HOME/.local/bin/econquest)."""
    home = Path(home).expanduser().resolve()
    return {"home": home,
            "launcher": Path(launcher).expanduser() if launcher else Path.home() / ".local" / "bin" / "econquest",
            "python": Path(python).expanduser() if python else home / ".venv" / "bin" / "python",
            "logs": home / "outputs" / "logs",
            "launch_agents": Path(launch_agents).expanduser() if launch_agents else Path.home() / "Library" / "LaunchAgents"}


def resolve_steps(job: dict, p: dict, cfg: dict) -> list[list[str]]:
    sid = str(cfg.get("spreadsheet_id", SPREADSHEET_ID))
    if not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", sid):        # spliced into the record job's bash -c script (AGENT-09 review)
        raise ValueError(f"spreadsheet_id in ops.json must be letters, digits, '-' or '_', got {sid!r}")
    sub = {"home": str(p["home"]), "launcher": str(p["launcher"]), "python": str(p["python"]), "spreadsheet_id": sid}
    def fill(a: str) -> str:                       # plain replace ({as_of} is left for jobs.py at run time)
        for k, v in sub.items():
            a = a.replace("{" + k + "}", v)
        return a
    return [[fill(a) for a in step] for step in job["steps"]]


def to_local(hour: int, minute: int, weekdays: list[int], tz: str, local_tz=None, on: dt.date | None = None) -> tuple[int, int, list[int], bool]:
    """Convert a wall-clock time in `tz` to the Mac's local clock for the offsets on date `on`.
    Returns (hour, minute, weekdays, converted). Weekdays shift when the conversion crosses midnight."""
    from zoneinfo import ZoneInfo
    on = on or dt.date.today()
    src = dt.datetime.combine(on, dt.time(hour, minute), tzinfo=ZoneInfo(tz))
    local_tz = local_tz or dt.datetime.now().astimezone().tzinfo
    loc = src.astimezone(local_tz)
    if loc.utcoffset() == src.utcoffset():
        return hour, minute, list(weekdays), False
    shift = (loc.date() - src.date()).days
    return loc.hour, loc.minute, sorted({(d + shift) % 7 for d in weekdays}), True


def plist_for(name: str, job: dict, p: dict, cfg: dict, local_tz=None, on: dt.date | None = None) -> tuple[dict, list[str]]:
    """The launchd plist dict for one job, and any warnings."""
    warnings: list[str] = []
    job = effective_job(name, job, cfg)
    steps = resolve_steps(job, p, cfg)
    args = [str(p["python"]), "-m", "econquest.ops.jobs", "--home", str(p["home"]), "--job", name]
    for s in steps:
        args += ["--step", json.dumps(s)]
    if any(AS_OF in a for s in steps for a in s):          # jobs.py fills {as_of} with the run date in this tz
        args += ["--tz", str(cfg.get("tz", DEFAULT_TZ))]
    if job.get("keep_going"):                              # run every step; exit with the worst code (jobs.py)
        args += ["--keep-going"]
    env = {"ECONQUEST_HOME": str(p["home"]),
           "PATH": f"{p['launcher'].parent}:/opt/homebrew/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin:/sbin"}
    if os.environ.get("ECONQUEST_BACKUP_DEST") and name == "backup":
        env["ECONQUEST_BACKUP_DEST"] = os.environ["ECONQUEST_BACKUP_DEST"]
    pl = {"Label": LABEL_PREFIX + name, "ProgramArguments": args, "WorkingDirectory": str(p["home"]),
          "EnvironmentVariables": env, "RunAtLoad": False, "ProcessType": "Background",
          "StandardOutPath": str(p["logs"] / f"{name}.out.log"), "StandardErrorPath": str(p["logs"] / f"{name}.err.log")}
    if job.get("interval_minutes"):
        pl["StartInterval"] = int(job["interval_minutes"]) * 60
    elif job.get("day") is not None:                       # monthly job: launchd Day of month (1-28 so every month has it)
        day = int(job["day"])
        if not 1 <= day <= 28:
            raise ValueError(f"{name}: day must be 1-28, got {day}")
        h, m, days, conv = to_local(int(job["hour"]), int(job["minute"]), [0], cfg.get("tz", DEFAULT_TZ), local_tz, on)
        shift = {0: 0, 1: 1, 6: -1}[days[0]]
        day = min(28, max(1, day + shift))
        if conv:
            warnings.append(f"{name}: day {job['day']} {job['hour']:02d}:{job['minute']:02d} {cfg.get('tz')} written as day {day} "
                            f"{h:02d}:{m:02d} Mac local time; reinstall after a DST change")
        pl["StartCalendarInterval"] = {"Day": day, "Hour": h, "Minute": m}
    else:
        h, m, days, conv = to_local(int(job["hour"]), int(job["minute"]), job.get("weekdays", ALL_DAYS), cfg.get("tz", DEFAULT_TZ), local_tz, on)
        if conv:
            warnings.append(f"{name}: {job['hour']:02d}:{job['minute']:02d} {cfg.get('tz')} written as {h:02d}:{m:02d} Mac local time; "
                            "reinstall after a DST change")
        if sorted(days) == ALL_DAYS:
            pl["StartCalendarInterval"] = {"Hour": h, "Minute": m}
        else:
            pl["StartCalendarInterval"] = [{"Weekday": d, "Hour": h, "Minute": m} for d in days]
    return pl, warnings


def plist_path(p: dict, name: str) -> Path:
    return p["launch_agents"] / f"{LABEL_PREFIX}{name}.plist"


def launchctl_commands(p: dict, names: list[str], action: str) -> list[str]:
    out = []
    for n in names:
        f = shlex.quote(str(plist_path(p, n)))
        if action == "install":
            out += [f"launchctl bootout gui/$UID/{LABEL_PREFIX}{n} 2>/dev/null || true", f"launchctl bootstrap gui/$UID {f}"]
        else:
            out.append(f"launchctl bootout gui/$UID/{LABEL_PREFIX}{n}")
    return out


def _run_launchctl(cmds: list[str], log) -> None:
    if sys.platform != "darwin":
        log("[schedule] --load ignored: launchctl runs on macOS only. Commands not run.")
        return
    uid = str(os.getuid())
    for c in cmds:
        argv = shlex.split(c.replace("$UID", uid).replace(" 2>/dev/null || true", ""))
        r = subprocess.run(argv, capture_output=True, text=True)
        log(f"[schedule] {' '.join(argv)} -> exit {r.returncode} {r.stderr.strip()}")


def install(home: str | Path, cfg: dict | None = None, jobs: list[str] | None = None, load: bool = False, now: dt.datetime | None = None,
            local_tz=None, log=print, **path_kw) -> dict:
    """Write the plists (backing up a different existing one to <plist>.bak-<ts>), write outputs/logs/schedule.json
    (what the health check expects) and print the launchctl commands. Runs launchctl only with load=True on macOS."""
    p = paths(home, **path_kw)
    cfg = cfg or load_config(p["home"])
    now = now or dt.datetime.now(dt.timezone.utc)
    names = jobs or list(cfg["jobs"])
    p["launch_agents"].mkdir(parents=True, exist_ok=True); p["logs"].mkdir(parents=True, exist_ok=True)
    written, warnings = [], []
    for n in names:
        pl, w = plist_for(n, cfg["jobs"][n], p, cfg, local_tz, now.date())
        warnings += w
        f = plist_path(p, n); data = plistlib.dumps(pl)
        if f.exists() and f.read_bytes() != data:
            bak = f.with_name(f.name + f".bak-{now.strftime('%Y%m%dT%H%M%SZ')}")
            bak.write_bytes(f.read_bytes()); log(f"[schedule] existing {f} saved as {bak}")
        f.write_bytes(data); written.append(str(f))
    for w in warnings:
        log(f"[schedule] WARNING {w}")
    if not p["launcher"].exists():
        log(f"[schedule] WARNING launcher {p['launcher']} not found: run install.sh first")
    rec_path = p["logs"] / "schedule.json"
    rec = json.loads(rec_path.read_text()) if rec_path.exists() else {}
    rec.update({"installed_at": rec.get("installed_at") if rec.get("status") == "installed" else now.isoformat(timespec="seconds"),
                "updated_at": now.isoformat(timespec="seconds"), "status": "installed", "tz": cfg.get("tz", DEFAULT_TZ),
                "grace_minutes": cfg.get("grace_minutes", 15), "stale_feed_days": cfg.get("stale_feed_days", 7),
                "holidays": cfg.get("holidays", []), "plists": written,
                "jobs": {n: {k: v for k, v in effective_job(n, cfg["jobs"][n], cfg).items() if k != "steps"} for n in names}})
    if "record" in names:
        rec.update({RECORD_APPLY_KEY: record_apply_prices(cfg), "record_mode": record_mode(cfg)})
    rec_path.write_text(json.dumps(rec, indent=1))
    cmds = launchctl_commands(p, names, "install")
    log("[schedule] wrote " + ", ".join(written))
    if "record" in names:
        log(f"[schedule] record job prices mode: {record_mode(cfg)} (ops.json {RECORD_APPLY_KEY})")
    log("[schedule] load them with:\n  " + "\n  ".join(cmds))
    log("[schedule] the Mac must be awake: e.g. sudo pmset repeat wakeorpoweron MTWRF 06:55:00 (launchd runs a calendar job "
        "missed during sleep once on wake)")
    if load:
        _run_launchctl(cmds, log)
    return {"plists": written, "commands": cmds, "warnings": warnings, "schedule": str(rec_path)}


def uninstall(home: str | Path, jobs: list[str] | None = None, load: bool = False, now: dt.datetime | None = None, log=print, **path_kw) -> dict:
    """Print the bootout commands (run them with load=True on macOS), then remove the com.econquest.<job> plists."""
    p = paths(home, **path_kw)
    now = now or dt.datetime.now(dt.timezone.utc)
    names = jobs or list(DEFAULT_JOBS)
    cmds = launchctl_commands(p, names, "uninstall")
    log("[schedule] unload with:\n  " + "\n  ".join(cmds))
    if load:
        _run_launchctl(cmds, log)
    removed = []
    for n in names:
        f = plist_path(p, n)
        if f.exists():
            f.unlink(); removed.append(str(f))
    rec_path = p["logs"] / "schedule.json"
    if rec_path.exists():
        rec = json.loads(rec_path.read_text())
        left = {k: v for k, v in rec.get("jobs", {}).items() if k not in names}
        rec.update({"jobs": left, "status": "installed" if left else "uninstalled", "updated_at": now.isoformat(timespec="seconds")})
        rec_path.write_text(json.dumps(rec, indent=1))
    log("[schedule] removed " + (", ".join(removed) or "nothing (no plists found)"))
    return {"removed": removed, "commands": cmds}


def show(home: str | Path, cfg: dict | None = None, log=print, **path_kw) -> dict:
    p = paths(home, **path_kw)
    cfg = cfg or load_config(p["home"])
    rows = {}
    for n, j in cfg["jobs"].items():
        f = plist_path(p, n)
        when = f"every {j['interval_minutes']} min" if j.get("interval_minutes") else \
            f"{j['hour']:02d}:{j['minute']:02d} {cfg.get('tz')} on day {j['day']} monthly" if j.get("day") is not None else \
            f"{j['hour']:02d}:{j['minute']:02d} {cfg.get('tz')} on {','.join('SMTWTFS'[d] for d in j.get('weekdays', ALL_DAYS))}"
        last = p["logs"] / "jobs" / f"{n}.last.json"
        lj = json.loads(last.read_text()) if last.exists() else {}
        rows[n] = {"when": when, "plist": str(f), "installed": f.exists(), "last_status": lj.get("status"),
                   "last_exit": lj.get("exit_code"), "last_end": lj.get("ended_at")}
        log(f"{n:8s} {when:38s} {'installed' if f.exists() else 'not installed':14s} last: {lj.get('status', '-')} "
            f"exit {lj.get('exit_code', '-')} {lj.get('ended_at') or ''}")
    log(f"record job prices mode: {record_mode(cfg)} (ops.json {RECORD_APPLY_KEY}; reinstall after a change)")
    rows["_record_mode"] = {"apply_prices": record_apply_prices(cfg), "mode": record_mode(cfg)}
    if "vendor_snapshots" not in cfg["jobs"]:          # EQ-C-0117: listed as off; never installed or checked from here
        from .vendor_ops import show_lines
        lines, row = show_lines(p["home"], cfg)
        for line in lines:
            log(line)
        rows["_vendor_snapshots"] = row
    return rows


CHECK_STATES = ("ok", "missing", "stale", "unexpected")
INSTALL_HINT = "econquest schedule install --load"


def launch_agents_dir() -> Path | None:
    """The folder launchd reads on this machine, or None off macOS (nothing can be installed there). Read-only callers
    (open items, next, the ops report) use this; tests replace it so the real folder is never read (tests/conftest.py)."""
    return Path.home() / "Library" / "LaunchAgents" if sys.platform == "darwin" else None


def _differs(got: dict, exp: dict) -> list[str]:
    keys = sorted(set(got) | set(exp))
    return [k for k in keys if got.get(k) != exp.get(k)]


def _added_steps(got: dict, exp: dict, diff: list[str]) -> list[str] | None:
    """EQ-C-0144: the steps a newer release added to a job, when that is the only difference (the plist's own arguments
    are all still there, in order, and what is missing is only `--step <json>` pairs, plus `--keep-going` or `--tz <zone>`
    that come with them). Returns the added steps' module or program names, or None for any other difference."""
    if diff != ["ProgramArguments"]:
        return None
    g, e = got.get("ProgramArguments"), exp.get("ProgramArguments")
    if not (isinstance(g, list) and isinstance(e, list)) or len(g) >= len(e):
        return None
    left, i = [], 0
    for tok in e:
        if i < len(g) and g[i] == tok:
            i += 1
        else:
            left.append(tok)
    if i != len(g):
        return None
    added, k = [], 0
    while k < len(left):
        if left[k] in ("--step", "--tz") and k + 1 < len(left):
            if left[k] == "--step":
                try:
                    st = json.loads(left[k + 1])
                except ValueError:
                    return None
                mod = next((st[j + 1] for j, a in enumerate(st[:-1]) if a == "-m"), None) if isinstance(st, list) else None
                added.append(str(mod or (st[0] if isinstance(st, list) and st else "step")))
            k += 2
        elif left[k] == "--keep-going":
            k += 1
        else:
            return None
    return added or None


def check(home: str | Path, cfg: dict | None = None, jobs: list[str] | None = None, local_tz=None, on: dt.date | None = None,
          log=print, **path_kw) -> dict:
    """Compare the expected jobs with the plists in the LaunchAgents folder. Reads only; never runs launchctl.
    {"launch_agents", "status": "ok"|"attention", "counts", "jobs": {name: {"state", "label", "detail"}}, "unexpected"}."""
    p = paths(home, **path_kw)
    cfg = cfg or load_config(p["home"])
    names = jobs or list(cfg["jobs"])
    rows: dict[str, dict] = {}
    any_installed = any(plist_path(p, n).is_file() for n in names)
    for n in names:
        f = plist_path(p, n)
        label = LABEL_PREFIX + n
        if not f.is_file():
            rows[n] = ({"state": "missing", "label": label, "reason": "new_job",
                        "detail": f"not installed yet; if the schedule was installed before this release, this job is new: "
                                  f"{INSTALL_HINT} adds it"} if any_installed else
                       {"state": "missing", "label": label, "detail": f"no {f.name}: run {INSTALL_HINT}"})
            continue
        try:
            exp, _ = plist_for(n, cfg["jobs"][n], p, cfg, local_tz, on)
        except (KeyError, ValueError) as e:
            rows[n] = {"state": "stale", "label": label, "detail": f"expected plist not buildable ({type(e).__name__})"}
            continue
        try:
            got = plistlib.loads(f.read_bytes())
        except Exception as e:                           # noqa: BLE001 - a broken plist is stale, never a crash
            rows[n] = {"state": "stale", "label": label, "detail": f"plist unreadable ({type(e).__name__}): run {INSTALL_HINT}"}
            continue
        got = got if isinstance(got, dict) else {}
        diff = _differs(got, exp)
        added = _added_steps(got, exp, diff) if diff else None
        if not diff:
            rows[n] = {"state": "ok", "label": label, "detail": "plist matches what install writes"}
        elif added:                                      # EQ-C-0144: an older release's plist, not a fault
            rows[n] = {"state": "stale", "label": label, "reason": "older_release",
                       "detail": f"written by an earlier release; this release adds {len(added)} step(s) "
                                 f"({', '.join(added)}): {INSTALL_HINT} updates it"}
        else:
            rows[n] = {"state": "stale", "label": label,
                       "detail": f"plist differs ({', '.join(diff[:6])}): run {INSTALL_HINT}"}
    extra = []
    if p["launch_agents"].is_dir():
        for f in sorted(p["launch_agents"].glob(LABEL_PREFIX + "*.plist")):
            n = f.name[len(LABEL_PREFIX):-len(".plist")]
            if n not in names and n not in cfg["jobs"]:
                extra.append({"state": "unexpected", "label": LABEL_PREFIX + n,
                              "detail": "not a job in the schedule (left over? econquest schedule uninstall does not remove it)"})
    counts = {s: sum(1 for r in rows.values() if r["state"] == s) for s in CHECK_STATES[:3]} | {"unexpected": len(extra)}
    rep = {"launch_agents": str(p["launch_agents"]), "status": "ok" if counts["missing"] == counts["stale"] == 0 else "attention",
           "counts": counts, "jobs": rows, "unexpected": extra}
    for n, r in rows.items():
        shown = {"older_release": "update", "new_job": "new"}.get(r.get("reason", ""), r["state"])
        log(f"{n:18s} {shown:8s} {r['detail']}")
    for r in extra:
        log(f"{r['label']:18s} unexpected {r['detail']}")
    log(f"schedule check: {counts['ok']} ok, {counts['missing']} missing, {counts['stale']} stale, {counts['unexpected']} "
        f"unexpected in {p['launch_agents']} (plist files only; launchctl not run)")
    upd = [n for n, r in rows.items() if r.get("reason") in ("older_release", "new_job")]
    if upd and len(upd) == counts["missing"] + counts["stale"]:
        log(f"schedule check: nothing is broken: {', '.join(upd)} only need the newer release's jobs or steps; "
            f"{INSTALL_HINT} updates them")
    elif upd:
        log(f"schedule check: {', '.join(upd)} only need the newer release's jobs or steps ({INSTALL_HINT} updates them)")
    return rep


def job_installed(name: str, home: str | Path | None = None, launch_agents: str | Path | None = None) -> bool | None:
    """Is com.econquest.<name>.plist in the LaunchAgents folder? None when there is none to check (not macOS)."""
    la = Path(launch_agents) if launch_agents else launch_agents_dir()
    if la is None:
        return None
    return (la / f"{LABEL_PREFIX}{name}.plist").is_file()


def _time_arg(s: str) -> tuple[int, int]:
    h, m = s.split(":")
    h, m = int(h), int(m)
    if not (0 <= h < 24 and 0 <= m < 60):
        raise argparse.ArgumentTypeError(f"bad time {s}: use HH:MM")
    return h, m


def add_arguments(ap: argparse.ArgumentParser) -> None:
    ap.add_argument("action", choices=["install", "uninstall", "show", "check"],
                    help="check: compare the expected jobs with the plists in ~/Library/LaunchAgents (ok/missing/stale; reads only)")
    ap.add_argument("--job", action="append", choices=list(DEFAULT_JOBS), help="only this job (repeatable; default all)")
    ap.add_argument("--load", action="store_true", help="also run launchctl bootstrap/bootout (macOS only)")
    ap.add_argument("--tz", help=f"time zone the job times are in (default {DEFAULT_TZ})")
    for j in ("record", "morning", "monitor", "backup"):
        ap.add_argument(f"--{j}-time", type=_time_arg, metavar="HH:MM", help=f"{j} job time (default {DEFAULT_JOBS[j]['hour']:02d}:{DEFAULT_JOBS[j]['minute']:02d})")
    ap.add_argument("--launcher", help="econquest launcher (default ~/.local/bin/econquest, written by install.sh)")
    ap.add_argument("--python", help="venv python (default <home>/.venv/bin/python)")
    ap.add_argument("--launch-agents", help="plist folder (default ~/Library/LaunchAgents)")


def run_from_args(args, home: str | Path, log=print) -> dict:
    over: dict = {"jobs": {}}
    if args.tz:
        over["tz"] = args.tz
    for j in ("record", "morning", "monitor", "backup"):
        t = getattr(args, f"{j}_time")
        if t:
            over["jobs"][j] = {"hour": t[0], "minute": t[1]}
    kw = {"launcher": args.launcher, "python": args.python, "launch_agents": args.launch_agents}
    if args.action == "install":
        return install(home, load_config(home, over), jobs=args.job, load=args.load, log=log, **kw)
    if args.action == "uninstall":
        return uninstall(home, jobs=args.job, load=args.load, log=log, **kw)
    if args.action == "check":
        return check(home, load_config(home, over), jobs=args.job, log=log, **kw)
    return show(home, load_config(home, over), log=log, **kw)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ops.schedule", description="launchd jobs for econquest on macOS")
    ap.add_argument("--home", default=os.environ.get("ECONQUEST_HOME", str(Path.home() / "econquest")))
    add_arguments(ap)
    args = ap.parse_args(argv)
    r = run_from_args(args, args.home)
    return 1 if args.action == "check" and r.get("status") != "ok" else 0


if __name__ == "__main__":
    sys.exit(main())
