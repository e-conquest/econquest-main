"""`econquest demo` (EQ-C-0121): the scripted end-to-end MVP acceptance run (team/mvp-checklist.md, rows M1-M10).

    econquest demo [--fast] [--zip PATH] [--tests-from JUNIT] [--as-of 2026-10-23] [--paths 20000] [--rs-paths 5000]
                   [--full-replication] [--keep] [--dest DIR] [--no-tracker]

After a real run it writes the status block of team/mvp-checklist.md (ops/mvp_tracker.py, EQ-C-0124); --no-tracker
or a stubbed run (Demo.sh replaced, as in the tests) leaves the checklist alone.

It runs in the cloud, offline, on shared data, and never touches the caller's data/: everything happens in a temp
home (HOME and ECONQUEST_HOME both point into it), so no launchd job, Keychain item, shell profile or backup outside
it is ever written.

  M1  build the release zip from the current tree (scripts/build_release.py; or --zip PATH), unzip it and install it
      with install.sh into the temp home (ECONQUEST_INSTALL_NO_PROMPT=1, ECONQUEST_NO_PROFILE=1). The hash-locked pip
      step needs PyPI, so it is skipped (ECONQUEST_INSTALL_SKIP_VENV=1) and the installed program runs on this
      interpreter's packages; the reason line says so, with any version that differs from requirements-lock.txt.
      `--fast` skips the zip and runs the tree's code: M1 is then "pending (fast mode)".
      Data (HO-20261025-A-C-025): M2-M10 run on Team A's frozen MVP dataset, never on the shared data/ folder:
      ingestion.mvp_dataset.materialize copies data/mvp/data (of the installed home, else of the tree) after checking
      its hashes, labels, 0 unexplained and 0 restricted-source cells; an MvpError fails the demo, it never falls back.
      `--data DIR` runs on a copy of DIR instead. demo.json "dataset" records the source, build time and sha256.
  M2  Team A's ledger (ingestion.ledger.effective_holds) and audit trail (ingestion.audit.build_audit_trail) on the
      demo data: every held or missing cell must stay on a labelled seed value (origin "seed ...", a value).
      A-0110 owns making it pass; the demo only reports.
  M3  run --as-of D --stress: run_latest.json has VaR99, ES99, EL, L-VaR99, a PD for each of the 18 desk names and
      the book-limit status (presentation.mc_band.book_limit_verdicts); replicate passes (--quick unless
      --full-replication). Two bases (HO-20261025-C-B-006, Team B option 1), each figure with its path count:
        Release base (shared data)   replicate runs on the release inputs: a copy of the tree's data/ (install mode:
                                     the installed release data), never the MVP copy; checks R01-R51 and the docs
                                     numbers; demo.json "release_base" says how the inputs compare with
                                     docs/governance/releases/inputs/<version>/RELEASE-HASHES.json.
        MVP desk base (data/mvp ID)  the desk's run on the MVP data, checked by Team B's validation.mvp_signoff
                                     (EQ-B-0111; replication skipped there, no release reference): demo.json
                                     "mvp_desk_base" has its verdict, figures, paths and as_of. Team B's own sign-off
                                     is at 100,000 requested (131,072 simulated) paths; the demo uses --paths.
  M4  the stress library (stress.json) and reverse-stress (reverse_stress.json) with limit breaches flagged; reverse
      stress searches scenarios A, B, C and every single factor (--rs-full: the whole library, about 15 min more).
  M5  Team B's research pack (validation.mvp_pack build + check_pack under <out>/reports/mvp of the temp home): notes
      for the 18 names, scenario briefs, trade ideas and the weekly brief, each equal to its run and carrying the
      disclaimer and the licence attribution (B-0110 owns the content: report only).
  M6  EQ-C-0122's presentation.xlsx_export.export(check=True); pending while it has not landed.
  M7  the GUI on 127.0.0.1 and a random port: run, results, notes and open-items routes, loopback-only bind, the
      Host / token / Origin / content-type guard and the security headers; then it is stopped. Notes (EQ-C-0127):
      /api/notes lists the M5 pack with a note for each desk name, one note opens with its disclaimer and licence
      attribution, and the notes routes refuse a request without the token and an id that is not in the index.
  M8  change verify, the review ledger's hash chain (ingestion.ledger verify, HO-20261025-A-C-024), and EQ-C-0123's ops.demo_baseline.demo_evidence on the DEMO licence baseline (never Sam's
      approval); pending while it has not landed or without --tests-from (the demo does not rerun the full suite).
  M9  the daily jobs in simulation through ops.jobs: record --dry-run --no-mc, backup and restore-drill into the temp
      home, then health --daily. No schedule is installed and nothing is sent.
  M10 --tests-from (junit XML or a pytest text summary) with 0 failures, replication passing, docs/quickstart.md.

MVP+ (EQ-C-0136): rows M11-M13, kept apart from M1-M10 ("MVP reached", the summary line and the exit code are M1-M10
only); demo.json "plus_rows" and "plus_summary", a "MVP+" table in demo.md and in the tracker block. They run after M10:
  M11 `econquest morning --json` in the demo home (econquest-morning/1): status ok, the four limit measures each with a
      light, run.action ran or reused, notes listed; then GET /api/morning (with the token) in the GUI probe equals that
      payload apart from generated_utc, run.action and run.message (what the CLI did about the run), and is refused
      without the token.
  M12 `econquest whatif --trade "<country> <instrument> 10 buy" --json` (eq-whatif/1, mode full) on the first desk
      position's country and instrument: booked false, metrics.before equal to the M3 base run (same date, same paths),
      delta finite, limits.status_after present, and data/portfolio.csv, run_latest.json and every store/ file
      byte-identical before and after; then POST /api/whatif (with the token) in the GUI probe, the same no-write check,
      and the same POST without the token refused.
  M13 research v2 (Team B EQ-B-0115, house view): validation.house_view check on the M5 pack (<out>/reports/mvp),
      building house_view.json there first when mvp_pack has not (HO-20261025-B-B-002). A problem fails the row; only
      "not wired" products (HO-20261025-B-C-017, Team C) leave it pending; "pending: Team B research v2 not landed"
      when the module is not there.
MVP+ (EQ-C-0148): rows M14-M16, the same way (plus_rows), after M13, each on the demo's own home (never the shared
outputs/), "pending: ... not landed" when the installed code predates them:
  M14 client sandbox: ops.client_outbox.demo_sandbox(<home>/data, <home>/outputs) (build, send, verify, refusals) with
      $ECONQUEST_ACTION_LOG pinned to <home>/outputs/store/actions.jsonl; then `econquest client-outbox build` without
      --sandbox must be refused and its error row must land in that demo-home action log.
  M15 vendor simulation: ops.vendor_rehearse.demo_vendor_sim on a SIMULATED sandbox under <dest>/sandbox/vendor-sim
      (under the temp folder when dest is inside the tree: the guard refuses repo paths), its "desk untouched" row
      checked on the demo home's data/ and outputs/ (so other sessions writing the shared outputs cannot break it).
  M16 calendar rehearsal: presentation.rehearsal_view.demo_calendar_page(<home>/outputs), which runs Team B's
      validation.calendar_rehearsal.demo_calendar_rehearsal; any problem fails the row with its reason (until Team B
      lands HO-20261026-C-B-001 the job SEQUENCE rows after the RF-3 grace window are such problems).
MVP+ (EQ-C-0158): rows M17-M20, the same way, after M16, on the demo home (installed code in zip mode); "pending: not
landed" when the module, or the installed demo's probe, is not there:
  M17 text stress index: Team B's validation.text_index.demo_text_index(<home>/outputs, data_dir=<home>/data,
      real_as_of=<demo as_of>) (HO-20261026-B-C-015): ok, its SYNTHETIC banner (label) and real_backtest.status shown as
      given; switch_state(<home>/data) must be off and run() is never called. Client safety: client_safe_rows keeps no
      row, no client-facing module imports the index, no file under <home>/outputs outside text_index/ carries one.
  M18 event calendar: presentation.calendar_view.demo_events_view(<home>/data, <home>/outputs/events_view) (EQ-C-0155);
      an empty type whose adapter answers is "no events yet, adapter ok".
  M19 depth views and heatmap: demo_depth_page(<home>/outputs) then demo_heatmap(<home>/outputs), data_dir=<home>/data,
      from the presentation module that defines demo_depth_page (EQ-C-0156, presentation.heatmap, found by its source).
  M20 research archive: presentation.archive.demo_archive(<home>/outputs, limit=5) (EQ-C-0154) on the M5 pack.
MVP+ (EQ-C-0166): rows M21-M24, the same way, after M20. None reads the shared outputs/ (the frozen release tree has
none) and each writes only under the demo home or dest; "pending: not landed" when the installed code predates it:
  M21 real-data day rehearsal: `econquest rehearse --out <dest>/rehearsal --quick` (ops/rehearse.py over Team A's
      ingestion.rehearsal, EQ-C-0168, docs/runbooks/A-real-data-day.md) on a full release data folder with data/mvp
      (install mode: the installed release data; --fast: a copy of the tree's data/), TMPDIR in the temp folder.
      --rehearse-full drops --quick. --zips: --rehearse-zips DIR, else $ECONQUEST_DEMO_ZIPS, else (install mode) the
      folder holding the zip under test, which is also --current; --fast without either runs no upgrade rows. PASS =
      exit 0; missing upgrade zips are listed (Team A's rehearsal reports them), never a failure.
  M22 backtest explainer: presentation.backtest_explainer_view.demo_explainer_page(<home>/outputs, as_of, data_dir,
      step=21), which runs Team B's validation.backtest_explainer.demo_backtest_explainer (EQ-B-0141, about a minute;
      HO-20261026-B-C-018) and renders the INTERIM page section; data_dir is the program's own data/ (Team B reads the
      real record only: the demo home's in install mode, the tree's, read only, in --fast). PASS = ok and the page shows
      2026-09-23 as not reconciled ("reconstruction, does not explain the recorded loss"). Never on the record job.
  M23 validator replication kit (Team B EQ-B-0143, in Team B review; no demo function in a handoff): a fresh DEMO data
      room built with Team A's ingestion.dataroom.build_data_room(<the M21 data>, 2026-10-26, licence_baseline="demo",
      include_mvp=True) under <home>/outputs/validator_kit/room (about 100 s), then `validator_kit run` (main(argv))
      with that room's manifest_sha256 and this installation's code hash: PASS = exit 0, FAIL 0, at least one PASS,
      no network, no write outside --out, room re-verified; and a copy with one byte appended to a room file is
      REFUSED (exit 3). Only report.md / report.json are kept as evidence (the room and work/ are NDA-only).
  M24 research QA: ops.research_qa.demo_research_qa(<home>/outputs, data_dir=<home>/data, outputs_dir=<home>/outputs)
      (EQ-C-0163): the good note passes the gate, the altered copy is refused.
MVP+ (EQ-C-0174): rows M25-M27, the desk assistant (EQ-C-0176, Team B's slot gate eq-assistant-qa/2), offline with
the stub backend and scripted models on a demo home of their own (econquest.assistant.demo_rows), under
<home>/outputs/assistant_demo (a copy of <home>/data, assistant.json with the stub on, a 4096-path run):
  M25 an answer with citations: Team B's reference answer renders exactly (HO-20261027-B-C-001 point 17), a typed
      number is refused; `econquest assistant ask` gives slots rendered by the gate, a Figures list and citations,
      and the request log holds hashes only.
  M26 refusals: a client-scope request gets client_ok context only and an internal citation is refused; an injected
      chunk asking for tools outside the allow-list and echoing a fence marker: the tools are refused, the marker is
      never shown.
  M27 a draft created, edited and signed through the CLI (`assistant draft`, `edit --reason`, `sign --by`) into the
      archive with the real data folder, the research QA gate passing on the signed version, `drafts --verify` ok.
  `--only M21-M27` (or a comma list of them) runs M1 (install) and just those rows: M2-M10 are not run, the exit code
  is M1 plus the chosen rows, and the tracker in team/mvp-checklist.md is not written.

Network: every step runs in a private network namespace (unshare -rn, loopback only) when the kernel allows it, and
always under a socket guard (a sitecustomize that refuses any non-loopback connect). Writes
<out>/demo/<UTC>/demo.json, demo.md, logs/ and evidence/; prints one summary line; exit 0 only when every row passes.
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import math
import os
import re
import shutil
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from urllib.parse import quote

TICKET = "EQ-C-0121"
SCHEMA = "eq-demo/1"
AS_OF = "2026-10-23"
DESK_NAMES = 18
RS_SCENARIOS = ("A", "B", "C")      # the paper's three; --rs-full searches the whole library (about 15 min more)
JSON_MARK = "ECONQUEST-DEMO-JSON:"
STATUSES = ("pass", "fail", "pending")
CRITERIA = [
    ("M1", "Install from the zip into an empty home and start, with no network"),
    ("M2", "One complete offline dataset passes the quality gate (gaps on labelled seed values)"),
    ("M3", "Base run: VaR99, ES99, EL, L-VaR99, PDs for the 18 desk names, limit status; replication passes"),
    ("M4", "Stress library and reverse stress with limit breaches flagged"),
    ("M5", "Research pack with disclaimers and licence attribution"),
    ("M6", "Local xlsx workbook with the same numbers as the run"),
    ("M7", "GUI on loopback: run, results, notes, open items; security holds"),
    ("M8", "Change chain verifies; evidence bundle on the DEMO licence baseline"),
    ("M9", "Daily jobs (health, record) in simulation"),
    ("M10", "Full test suite and replication with 0 failures; quickstart"),
]
PLUS_TICKET = "EQ-C-0136, EQ-C-0148, EQ-C-0158, EQ-C-0166, EQ-C-0174"
PLUS_CRITERIA = [                   # MVP+: reported beside M1-M10, never part of "MVP reached" or the exit code
    ("M11", "Morning view: econquest morning ok, a light per limit, notes listed; GUI /api/morning equals it"),
    ("M12", "What-if trade: nothing booked, before equals the base run, limits after; GUI POST /api/whatif guarded"),
    ("M13", "Research v2 (Team B house view, EQ-B-0115): house_view check on the research pack"),
    ("M14", "Client sandbox: test packs to the local outbox verify, real use refused, logged in the demo home only"),
    ("M15", "Vendor simulation: dry run and vendor ops on a SIMULATED sandbox, desk folders untouched"),
    ("M16", "Calendar rehearsal (Team B demo_calendar_rehearsal): job sequence as expected, page renders"),
    ("M17", "Text stress index (Team B, SYNTHETIC sandbox): switch off, real backtest status shown, no client rows"),
    ("M18", "Event calendar view: every type has events or 'no events yet, adapter ok'; morning section renders"),
    ("M19", "Depth views and country risk heatmap (EQ-C-0156) render on the demo home"),
    ("M20", "Research archive: archive, correct, search and verify on the research pack; tamper detected"),
    ("M21", "Real-data day rehearsal (Team A): replay and failure-mode rows pass; upgrade zips run or listed as missing"),
    ("M22", "Backtest explainer (Team B, INTERIM) on the backtest page; 2026-09-23 shown as not reconciled"),
    ("M23", "Validator replication kit (Team B) on a fresh DEMO data room: FAIL 0; a tampered room refused"),
    ("M24", "Research QA gate: the good note passes, the altered note is refused"),
    ("M25", "Assistant answer (stub): slots rendered by the QA gate with figures and citations; the reference renders exactly"),
    ("M26", "Assistant refusals: client request sees no internal material; injected off-list tool and fence marker refused"),
    ("M27", "Assistant draft: created, edited, signed via the CLI into the archive; research QA passes; audit verifies"),
]
PLUS_TICKETS = {"M11": "EQ-C-0136", "M12": "EQ-C-0136", "M13": "EQ-C-0136", "M14": "EQ-C-0148", "M15": "EQ-C-0148",
                "M16": "EQ-C-0148", "M17": "EQ-C-0158", "M18": "EQ-C-0158", "M19": "EQ-C-0158", "M20": "EQ-C-0158",
                "M21": "EQ-C-0166", "M22": "EQ-C-0166", "M23": "EQ-C-0166", "M24": "EQ-C-0166",
                "M25": "EQ-C-0174", "M26": "EQ-C-0174", "M27": "EQ-C-0174"}
CALENDAR_HANDOFF = "HO-20261026-C-B-001"     # Team B: new SEQUENCE rows after the RF-3 grace window (EQ-C-0147)
MORNING_SCHEMA = "econquest-morning/1"
MORNING_KEYS = ("schema", "generated_utc", "as_of", "status", "run", "previous", "limits", "changes", "alerts", "notes",
                "open_items", "message")
MORNING_IGNORE = ("generated_utc", "run.action", "run.message")      # what the CLI did about the run; the API only shows
WHATIF_SCHEMA = "eq-whatif/1"
BASE_METRICS = ("var99_mm", "es99_mm", "expected_loss_mm", "lvar99_mm")
LIGHTS = ("green", "amber", "red")
SECRET_ENV = ("ECONQUEST_SHEETS_TOKEN", "ECONQUEST_SMTP_HOST", "ECONQUEST_SMTP_PORT", "ECONQUEST_SMTP_USER",
              "ECONQUEST_SMTP_PASSWORD", "ECONQUEST_SMTP_FROM", "ECONQUEST_SMTP_TO", "ECONQUEST_ALERT_WEBHOOK",
              "UCDP_TOKEN", "ECONQUEST_UCDP_TOKEN")
PROXY_ENV = ("HTTP_PROXY", "HTTPS_PROXY", "ALL_PROXY", "http_proxy", "https_proxy", "all_proxy", "NO_PROXY", "no_proxy")

# Loaded as sitecustomize in every demo subprocess (ECONQUEST_DEMO_OFFLINE=1): inside `unshare -rn` it brings the
# loopback interface up (a new namespace starts with lo down), and it refuses every connect to a non-loopback address.
GUARD = r'''
import os, socket
if os.environ.get("ECONQUEST_DEMO_OFFLINE") == "1":
    try:
        import fcntl, struct
        _s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        _f = struct.unpack("16sH14s", fcntl.ioctl(_s, 0x8913, struct.pack("16sH14s", b"lo", 0, b"\0" * 14)))[1]
        if not _f & 1:
            fcntl.ioctl(_s, 0x8914, struct.pack("16sH14s", b"lo", _f | 1, b"\0" * 14))
        _s.close()
    except Exception:
        pass
    import ipaddress as _ip

    def _local(addr):
        try:
            host = addr[0] if isinstance(addr, tuple) else addr
            if isinstance(host, bytes):
                host = host.decode()
            if host == "localhost":
                return True
            return _ip.ip_address(str(host).split("%")[0]).is_loopback
        except Exception:
            return False

    _connect, _connect_ex = socket.socket.connect, socket.socket.connect_ex

    def connect(self, addr):
        if self.family in (socket.AF_INET, socket.AF_INET6) and not _local(addr):
            raise OSError(101, "econquest demo: network disabled (offline run)")
        return _connect(self, addr)

    def connect_ex(self, addr):
        if self.family in (socket.AF_INET, socket.AF_INET6) and not _local(addr):
            return 101
        return _connect_ex(self, addr)

    socket.socket.connect, socket.socket.connect_ex = connect, connect_ex
'''


# ---------------------------------------------------------------- small helpers
def utc_stamp(now: dt.datetime | None = None) -> str:
    return (now or dt.datetime.now(dt.timezone.utc)).strftime("%Y%m%dT%H%M%SZ")


def _finite(v) -> bool:
    try:
        return math.isfinite(float(v))
    except (TypeError, ValueError):
        return False


def row(cid: str, status: str, evidence: str, reason: str, seconds: float = 0.0) -> dict:
    assert status in STATUSES, status
    title = dict(CRITERIA + PLUS_CRITERIA)[cid]
    return {"id": cid, "title": title, "status": status, "evidence": evidence, "reason": " ".join(str(reason).split()),
            "seconds": round(float(seconds), 1)}


def combine(parts: list[tuple[str, str]]) -> tuple[str, str]:
    """(status, reason) from (status, text) parts: any fail -> fail, else any pending -> pending, else pass. The
    reason lists the failing (or pending) parts first, then the rest."""
    st = "fail" if any(s == "fail" for s, _ in parts) else "pending" if any(s == "pending" for s, _ in parts) else "pass"
    first = [t for s, t in parts if s == st] if st != "pass" else []
    rest = [t for s, t in parts if t not in first]
    return st, "; ".join(first + rest)


def summary_line(rows: list[dict], seconds: float, md_path) -> str:
    n = {s: sum(r["status"] == s for r in rows) for s in STATUSES}
    bad = [r["id"] for r in rows if r["status"] != "pass"]
    return (f"econquest demo: {n['pass']}/{len(rows)} pass, {n['pending']} pending, {n['fail']} fail"
            + (f" (not passing: {', '.join(bad)})" if bad else "") + f" in {seconds:.0f}s -> {md_path}")


def plus_range(rows: list[dict]) -> str:
    """'M11-M16' (the first and last MVP+ row id), 'M11' for one row, 'M11-M13' for a run that has none."""
    ids = sorted({str(r.get("id", "")) for r in rows if re.fullmatch(r"M\d+", str(r.get("id", "")))}, key=lambda c: int(c[1:]))
    return "M11-M13" if not ids else ids[0] if len(ids) == 1 else f"{ids[0]}-{ids[-1]}"


def plus_line(rows: list[dict]) -> str:
    """One line for the MVP+ rows (M11-M27), never folded into the MVP summary."""
    n = {s: sum(r["status"] == s for r in rows) for s in STATUSES}
    bad = [r["id"] for r in rows if r["status"] != "pass"]
    return (f"MVP+ ({plus_range(rows)}, not part of MVP reached): {n['pass']}/{len(rows)} pass, {n['pending']} pending, {n['fail']} fail"
            + (f" (not passing: {', '.join(bad)})" if bad else ""))


def json_payload(text: str):
    """The first JSON object printed on a step's stdout (the part before the stderr marker of Demo.sh)."""
    body = str(text or "").split("\n--- stderr ---\n")[0]
    starts = ([0] if body.startswith("{") else []) + [m.start() + 1 for m in re.finditer(r"\n\{", body)]
    for i in starts:
        try:
            return json.JSONDecoder().raw_decode(body[i:])[0]
        except ValueError:
            continue
    raise ValueError("no JSON object on stdout")


def json_diff(a, b, ignore=(), path: str = "") -> list[str]:
    """Dotted paths where two JSON values differ (NaN equals NaN), skipping the dotted paths in `ignore`."""
    if path in ignore:
        return []
    if isinstance(a, dict) and isinstance(b, dict):
        out = []
        for k in sorted(set(a) | set(b), key=str):
            p = f"{path}.{k}" if path else str(k)
            if p in ignore:
                continue
            out += [p] if (k in a) != (k in b) else json_diff(a[k], b[k], ignore, p)
        return out
    if isinstance(a, list) and isinstance(b, list):
        if len(a) != len(b):
            return [f"{path} (length {len(a)} != {len(b)})"]
        return [d for i, (x, y) in enumerate(zip(a, b)) for d in json_diff(x, y, ignore, f"{path}[{i}]")]
    if a == b or (isinstance(a, float) and isinstance(b, float) and math.isnan(a) and math.isnan(b)):
        return []
    return [path or "(top)"]


def state_hashes(data, out) -> dict:
    """sha256 of the files a what-if must never write: data/portfolio.csv, outputs/run_latest.json, outputs/store/**."""
    import hashlib
    files = [Path(data) / "portfolio.csv", Path(out) / "run_latest.json"]
    st = Path(out) / "store"
    if st.is_dir():
        files += sorted(p for p in st.rglob("*") if p.is_file())
    return {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in files if p.is_file()}


def hash_change(h0: dict, h1: dict) -> str:
    """'' when equal, else what changed (counts and the first names)."""
    if h0 == h1:
        return ""
    ch = sorted(k for k in set(h0) & set(h1) if h0[k] != h1[k])
    add, rem = sorted(set(h1) - set(h0)), sorted(set(h0) - set(h1))
    names = ", ".join(Path(k).name for k in (ch + add + rem)[:3])
    return f"{len(ch)} changed, {len(add)} added, {len(rem)} removed ({names})"


def check_morning(rep: dict) -> list[str]:
    """M11 problems in an `econquest morning --json` payload ([] = pass)."""
    probs = []
    if rep.get("schema") != MORNING_SCHEMA:
        probs.append(f"schema {rep.get('schema')!r} != {MORNING_SCHEMA}")
    miss = [k for k in MORNING_KEYS if k not in rep]
    if miss:
        probs.append(f"keys missing: {', '.join(miss)}")
    run = rep.get("run") or {}
    if rep.get("status") != "ok":
        probs.append(f"status {rep.get('status')!r}, not ok" + (f" ({'; '.join(map(str, run.get('reasons') or []))})" if run.get("reasons") else ""))
    lit = {r.get("measure"): r.get("light") for r in (rep.get("limits") or {}).get("rows") or [] if isinstance(r, dict)}
    nolight = [m for m in BASE_METRICS if lit.get(m) not in LIGHTS]
    if nolight:
        probs.append(f"no limit light for {', '.join(nolight)}")
    if run.get("action") not in ("ran", "reused"):
        probs.append(f"run.action {run.get('action')!r}, not ran or reused")
    notes = rep.get("notes") or {}
    if not (notes.get("items") or notes.get("brief")):
        probs.append("no research notes listed" + (f" ({notes.get('message')})" if notes.get("message") else ""))
    return probs


def morning_text(rep: dict) -> str:
    run, notes = rep.get("run") or {}, rep.get("notes") or {}
    lights = ", ".join(f"{r.get('measure')} {r.get('light')}" for r in (rep.get("limits") or {}).get("rows") or [])
    n = len(notes.get("items") or []) + (1 if notes.get("brief") else 0)
    return (f"morning --json status {rep.get('status')}, as_of {rep.get('as_of')}, run {run.get('action')} {run.get('run_id')}; "
            f"limits {lights}; {n} notes listed (of {notes.get('total')})")


def check_whatif(rep: dict, base: dict) -> list[str]:
    """M12 problems in an eq-whatif/1 payload against the M3 base run {"metrics", "paths"} ([] = pass)."""
    probs = []
    if rep.get("schema") != WHATIF_SCHEMA:
        probs.append(f"schema {rep.get('schema')!r} != {WHATIF_SCHEMA}")
    if rep.get("booked") is not False:
        probs.append(f"booked is {rep.get('booked')!r}, not false")
    if rep.get("mode") != "full":
        probs.append(f"mode {rep.get('mode')!r}, not full (the default)")
    m = rep.get("metrics") or {}
    bef, bm = m.get("before") or {}, (base or {}).get("metrics") or {}
    off = [f"{k} {bef.get(k)} vs {bm.get(k)}" for k in BASE_METRICS
           if not (_finite(bef.get(k)) and _finite(bm.get(k))
                   and abs(float(bef[k]) - float(bm[k])) <= 1e-6 * max(1.0, abs(float(bm[k]))))]
    if off:
        probs.append("metrics.before differs from the base run: " + "; ".join(off[:2]))
    if (base or {}).get("paths") and rep.get("paths") != base["paths"]:
        probs.append(f"paths {rep.get('paths')} != base run {base['paths']}")
    delta = m.get("delta") or {}
    bad = [k for k, v in delta.items() if not _finite(v)]
    if not delta or bad:
        probs.append("delta missing" if not delta else f"delta not finite: {', '.join(bad)}")
    if (rep.get("limits") or {}).get("status_after") not in ("pass", "warning", "breach"):
        probs.append("limits.status_after missing")
    return probs


def whatif_text(rep: dict) -> str:
    m, L = rep.get("metrics") or {}, rep.get("limits") or {}
    t = (rep.get("trades") or [{}])[0]
    d = (m.get("delta") or {})
    return (f"whatif {t.get('country')} {t.get('instrument')} {t.get('notional_mm')} {t.get('side')}: booked "
            f"{str(rep.get('booked')).lower()}, mode {rep.get('mode')}, {rep.get('paths')} paths; before = base run "
            f"(VaR99 {_num_txt((m.get('before') or {}).get('var99_mm')).lstrip('+')}); delta VaR99 {_num_txt(d.get('var99_mm'))}, "
            f"ES99 {_num_txt(d.get('es99_mm'))} $mm; limits {L.get('status_before')} -> {L.get('status_after')} ({L.get('verdict')})")


def _num_txt(v) -> str:
    return f"{float(v):+.2f}" if _finite(v) else "n/a"


def exit_code(rows: list[dict]) -> int:
    return 0 if rows and all(r["status"] == "pass" for r in rows) else 1


def parse_tests(path) -> dict:
    """Totals from a pytest junit XML file or a pytest text summary ("3928 passed, 2 skipped in 812s").
    Returns {"tests", "failures", "errors", "skipped", "source"}; raises ValueError when nothing can be read."""
    p = Path(path)
    text = p.read_text(encoding="utf-8", errors="replace")
    if text.lstrip().startswith("<"):
        try:
            import defusedxml.ElementTree as ET      # the repo ships defusedxml; the stdlib parser is the fallback
        except ImportError:                          # pragma: no cover
            import xml.etree.ElementTree as ET       # noqa: S405 - a junit file the operator chose
        root = ET.fromstring(text)
        suites = [root] if root.tag == "testsuite" else list(root.iter("testsuite"))
        if not suites:
            raise ValueError(f"{p.name}: no <testsuite> element")
        tot = {k: sum(int(float(s.get(k, 0) or 0)) for s in suites) for k in ("tests", "failures", "errors", "skipped")}
        return {**tot, "source": "junit"}
    tail = "\n".join(text.strip().splitlines()[-5:])
    got = {k: int(v) for v, k in re.findall(r"(\d+) (passed|failed|errors?|skipped|xfailed|xpassed)", tail)}
    if not got:
        raise ValueError(f"{p.name}: no pytest summary line found")
    fails = got.get("failed", 0)
    errs = got.get("error", 0) + got.get("errors", 0)
    tests = sum(got.values())
    return {"tests": tests, "failures": fails, "errors": errs, "skipped": got.get("skipped", 0), "source": "text"}


def lock_differences(lock: Path, limit: int = 8) -> list[str]:
    """Packages pinned in requirements-lock.txt whose installed version here differs (or that are missing)."""
    from importlib import metadata
    out = []
    if not lock.is_file():
        return ["requirements-lock.txt missing"]
    for line in lock.read_text().splitlines():
        m = re.match(r"^([A-Za-z0-9_.\-]+)==([^\s;\\]+)", line.strip())
        if not m:
            continue
        name, want = m.groups()
        try:
            have = metadata.version(name)
        except metadata.PackageNotFoundError:
            have = None
        if have != want:
            out.append(f"{name} {have or 'missing'} (lock {want})")
    return out[:limit] + ([f"... {len(out) - limit} more"] if len(out) > limit else [])


# ---------------------------------------------------------------- probes (run inside the demo's home, offline)
def probe_offline(**_) -> dict:
    """A connect to a public address must fail."""
    import socket
    try:
        socket.create_connection(("1.1.1.1", 443), timeout=3).close()
        return {"ok": False, "reason": "a connect to 1.1.1.1:443 succeeded: the run is not offline"}
    except OSError as e:
        return {"ok": True, "reason": f"connect to 1.1.1.1:443 refused ({e.__class__.__name__}: {str(e)[:60]})"}


def probe_gate(data: str, **_) -> dict:
    """M2 through Team A's API: effective holds (ledger) plus missing cells, each matched to its audit-trail row. A hold is
    explained when that row is on a labelled seed value (origin starting 'seed', a finite value)."""
    import pandas as pd
    from ..ingestion import audit, ledger
    d = Path(data)
    rev_p = d / "live" / "review.csv"
    if rev_p.is_file():
        rev, source = pd.read_csv(rev_p, dtype=str, keep_default_na=False), "data/live/review.csv"
    else:                   # a fresh install ships no review.csv (SEC-C-018): the gate review of the latest vintage
        from ..ingestion import feeds
        try:
            vid, _rep, rev = feeds.load_vintage(d)
        except (OSError, ValueError) as e:
            return {"ok": False, "reason": f"no gate report: data/live/review.csv missing and no readable vintage ({type(e).__name__}: {str(e)[:120]})"}
        rev = rev.astype(str).replace({"nan": ""})
        source = f"vintage {vid} review (load_vintage)"
    holds = ledger.effective_holds(rev, ledger.load_decisions(d))
    missing = {(r.table, str(r.key), r.country) for r in rev.itertuples(index=False) if r.status == "missing"}
    trail = audit.build_audit_trail(d)
    at = {(str(r.table), str(r.key), str(r.country)): r for r in trail.itertuples(index=False)}
    cells = sorted(holds | missing)
    unexplained = []
    for c in cells:
        r = at.get(c)
        if r is None or not str(getattr(r, "origin", "") or "").startswith("seed") or not _finite(getattr(r, "value", None)):
            unexplained.append({"table": c[0], "key": c[1], "country": c[2],
                                "origin": "" if r is None else str(getattr(r, "origin", "")),
                                "why": "no audit-trail row" if r is None else
                                "not on a labelled seed value" if not str(getattr(r, "origin", "")).startswith("seed")
                                else "seed value missing"})
    counts = rev["status"].value_counts().to_dict()
    groups: dict[str, int] = {}
    for u in unexplained:
        k = f"{u['table']} {u['key']} ({u['why']})"
        groups[k] = groups.get(k, 0) + 1
    detail = ", ".join(f"{k} x{n}" for k, n in sorted(groups.items(), key=lambda kv: -kv[1])[:3])
    return {"ok": not unexplained, "source": source, "review_rows": len(rev), "status_counts": counts, "holds": len(holds),
            "missing": len(missing), "checked": len(cells), "unexplained": len(unexplained),
            "unexplained_cells": unexplained[:50],
            "reason": f"{source}: {len(cells)} held/missing cells ({len(holds)} held, {len(missing)} missing), "
                      f"{len(unexplained)} unexplained (not on a labelled seed value)" + (f": {detail}" if detail else "")
                      + " (A-0110 owns the fix)"}


def probe_run(data: str, out: str, as_of: str = AS_OF, **_) -> dict:
    """M3/M4 checks on run_latest.json, stress.json and reverse_stress.json."""
    from ..presentation.mc_band import book_limit_verdicts, load_book_limits
    o = Path(out)
    probs, m4 = [], []
    try:
        run = json.loads((o / "run_latest.json").read_text())
    except (OSError, ValueError) as e:
        return {"ok": False, "m4_ok": False, "reason": f"run_latest.json unreadable ({type(e).__name__})", "m4_reason": "no run"}
    summ = run.get("summary") or {}
    met = summ.get("metrics") or {}
    if str(summ.get("as_of", ""))[:10] != as_of:
        probs.append(f"as_of {summ.get('as_of')} != {as_of}")
    need = ("var99_mm", "es99_mm", "expected_loss_mm", "lvar99_mm")
    probs += [f"{k} missing or not finite" for k in need if not _finite(met.get(k))]
    countries = [c for c in run.get("country") or [] if isinstance(c, dict)]
    names = [c.get("country") for c in countries]
    bad_pd = [c.get("country") for c in countries
              if not (_finite(c.get("pd_default")) and 0 <= float(c["pd_default"]) <= 1)]
    if len(set(names)) != DESK_NAMES:
        probs.append(f"{len(set(names))} desk names, expected {DESK_NAMES}")
    if bad_pd:
        probs.append(f"no valid pd_default for {', '.join(map(str, bad_pd[:5]))}")
    limits = load_book_limits(data)
    verdicts = book_limit_verdicts(met, limits)
    if not verdicts:
        probs.append("no book-limit status (data/limits.json)")
    lim_txt = ", ".join(f"{v['measure']} {v['status']}" for v in verdicts)
    # M4: stress library with limits applied to each stressed metric, reverse stress with first breach flagged
    stress_breaches = {}
    try:
        stress = json.loads((o / "stress.json").read_text())
        for k, v in (stress or {}).items():
            comp = v.get("comparison") or {}
            sm = {mk: (comp.get(mk) or {}).get("stress") for mk in need}
            stress_breaches[k] = [x["measure"] for x in book_limit_verdicts(sm, limits) if x["status"] == "breach"]
        if not stress:
            m4.append("stress.json has no scenario")
    except (OSError, ValueError, AttributeError) as e:
        m4.append(f"stress.json unreadable ({type(e).__name__})")
    rs_first = 0
    try:
        rs = json.loads((o / "reverse_stress.json").read_text())
        summ_rs = rs.get("summary") or []
        if not summ_rs or not (rs.get("scenarios") or rs.get("factors")):
            m4.append("reverse_stress.json has no scenario or factor result")
        if any("first_breach" not in r for r in summ_rs):
            m4.append("reverse stress rows without the first-breach flag")
        rs_first = sum(bool(r.get("first_breach")) for r in summ_rs)
        rs_n = len(summ_rs)
    except (OSError, ValueError, AttributeError) as e:
        m4.append(f"reverse_stress.json unreadable ({type(e).__name__})")
        rs_n = 0
    n_br = sum(bool(b) for b in stress_breaches.values())
    return {"ok": not probs, "problems": probs, "metrics": {k: met.get(k) for k in need}, "paths": met.get("paths"),
            "run_id": summ.get("run_id"), "as_of": summ.get("as_of"), "desk_names": len(set(names)), "limits": verdicts,
            "stress_breaches": stress_breaches, "m4_ok": not m4, "m4_problems": m4,
            "reason": ("; ".join(probs) + "; " if probs else "") +
                      f"VaR99 {float(met.get('var99_mm', 'nan')):.2f}, ES99 {float(met.get('es99_mm', 'nan')):.2f}, "
                      f"EL {float(met.get('expected_loss_mm', 'nan')):.2f}, L-VaR99 {float(met.get('lvar99_mm', 'nan')):.2f} $mm, "
                      f"{len(set(names))} PDs, limits: {lim_txt or 'none'}",
            "m4_reason": ("; ".join(m4) + "; " if m4 else "") +
                         f"{len(stress_breaches)} stress scenarios, {n_br} breach a book limit; reverse stress "
                         f"{rs_n} rows, {rs_first} with a first breach flagged"}


def probe_research(data: str, out: str, **_) -> dict:
    """M5: the products exist and every HTML/Markdown file carries the disclaimer and the licence block."""
    from ..presentation.compliance import has_disclaimer
    from ..presentation.licences import LICENCE_MARKER
    o = Path(out)
    kinds = {"country notes": (o / "notes", ("*.html",)), "scenario briefs": (o / "briefs", ("*.html",)),
             "trade ideas": (o, ("idea_report.md",)), "weekly brief": (o / "weekly-brief", ("*.html",))}
    found, probs = {}, []
    for kind, (folder, globs) in kinds.items():
        files = sorted({f for g in globs for f in folder.glob(g) if f.is_file()}) if folder.is_dir() else []
        if kind == "country notes":
            files = [f for f in files if f.name != "index.html"]
        found[kind] = len(files)
        if not files:
            probs.append(f"{kind}: none built")
            continue
        no_disc = [f.name for f in files if not has_disclaimer(f.read_text(encoding="utf-8", errors="replace"))]
        no_lic = [f.name for f in files if LICENCE_MARKER not in f.read_text(encoding="utf-8", errors="replace")
                  and "Sources and licences" not in f.read_text(encoding="utf-8", errors="replace")]
        if no_disc:
            probs.append(f"{kind}: {len(no_disc)} without the disclaimer ({', '.join(no_disc[:2])})")
        if no_lic:
            probs.append(f"{kind}: {len(no_lic)} without licence attribution ({', '.join(no_lic[:2])})")
    if found.get("country notes", 0) and found["country notes"] < DESK_NAMES:
        probs.append(f"country notes: {found['country notes']} of {DESK_NAMES}")
    return {"ok": not probs, "found": found, "problems": probs,
            "reason": ("; ".join(probs) + "; " if probs else "") + ", ".join(f"{k} {v}" for k, v in found.items())}


def _demo_run(data: str, as_of: str, paths: int):
    """The demo's base run again (same settings, date and path count as `run`; the seed is fixed in assumptions.json)."""
    from ..config import Settings
    from ..engine import run_pipeline
    from ..ingestion import load_universe
    s = Settings.load(Path(data) / "assumptions.json", paths=paths or None)
    u = load_universe(data)
    return run_pipeline(u, s, label="base", as_of=as_of, market_dir=data), u, s


def probe_pack(data: str, out: str, as_of: str = AS_OF, paths: int = 0, **_) -> dict:
    """M5 through Team B's own pack builder and check (validation.mvp_pack, EQ-B-0110): build the pack under
    <out>/reports/mvp from its own base + stress run (same date and paths; dsa and reverse stress skipped), then
    check_pack. Falls back to probe_research on the plain product commands when the module is not there."""
    try:
        from ..validation import mvp_pack as MP
    except ImportError:
        r = probe_research(data=data, out=out)
        return {**r, "reason": "validation.mvp_pack not available, own check: " + r["reason"], "fallback": True}
    root = Path(out).resolve()
    dest = root / "reports" / "mvp"
    pack = MP.build_pack(data, dest, as_of, paths=paths or None, stress_paths=paths or None, register=True,
                         log=lambda *a, **k: print(*a, file=sys.stderr), outputs_root=root, inputs=False)
    res = MP.check_pack(dest)
    (dest / "check.json").write_text(json.dumps(res, indent=1, default=str), encoding="utf-8")
    probs = res.get("problems") or []
    groups: dict[str, int] = {}
    for x in probs:
        k = re.sub(r"^[^:]*: ", "", str(x))[:90]
        groups[k] = groups.get(k, 0) + 1
    detail = "; ".join(f"{k} x{n}" for k, n in sorted(groups.items(), key=lambda kv: -kv[1])[:2])
    return {"ok": bool(res.get("ok")), "problems": probs[:50], "checked": res.get("checked"),
            "built": {k: pack.get(k) for k in ("country_notes", "scenario_briefs", "activations", "run_id")},
            "reason": (f"mvp_pack check FAIL, {len(probs)} problems: {detail}; " if probs else "mvp_pack check PASS; ")
                      + f"{pack.get('country_notes')} country notes, {pack.get('scenario_briefs')} scenario briefs, "
                        f"weekly brief, {pack.get('activations')} trade-idea activations, "
                        f"{(res.get('checked') or {}).get('html_files', '?')} HTML files checked"}


def probe_xlsx(data: str, out: str, as_of: str = AS_OF, paths: int = 0, **_) -> dict:
    """M6: EQ-C-0122's export with its numbers check, once it has landed. The run is rebuilt with the demo's own path
    count and date (same seed), so the workbook is compared against the run_latest.json the demo just wrote."""
    try:
        from ..presentation import xlsx_export as X
        export = X.export
    except (ImportError, AttributeError):
        return {"pending": True, "reason": "C-0122 not landed (econquest.presentation.xlsx_export.export)"}
    res, u, s = _demo_run(data, as_of, paths)
    r = export(out_dir=out, data_dir=data, result=res, universe=u, settings=s, garch=False, econ=False, check=True)
    p = r.get("path")
    return {"ok": bool(r.get("ok")), "path": p, "checked": r.get("checked"), "mismatches": (r.get("mismatches") or [])[:20],
            "problems": (r.get("problems") or [])[:20],
            "reason": f"{Path(p).name if p else 'no workbook'}: {r.get('checked', 0)} numbers checked, "
                      f"{len(r.get('mismatches') or [])} mismatches" + (f"; {'; '.join(r['problems'][:2])}" if r.get("problems") else "")
                      + " (GARCH/Econometrics tabs skipped for speed)"}


def probe_evidence(data: str, out: str, root: str = "", as_of: str = AS_OF, tests_from: str = "", **_) -> dict:
    """M8 second half: EQ-C-0123's evidence bundle on the DEMO licence baseline."""
    try:
        from .demo_baseline import DemoBaselineError, demo_evidence
    except ImportError:
        return {"pending": True, "reason": "C-0123 not landed (econquest.ops.demo_baseline.demo_evidence)"}
    if not tests_from:
        return {"pending": True, "reason": "evidence bundle needs --tests-from (the demo does not rerun the full suite)"}
    rep = Path(out) / "replication"
    try:
        r = demo_evidence(data, out_dir=out, as_of=as_of, root=root or None, tests_from=tests_from,   # out: the demo's stored runs
                          replication_from=str(rep) if (rep / "replication.csv").is_file() else None, quick=True,
                          log=lambda *a, **k: print(*a, file=sys.stderr))
    except DemoBaselineError as e:
        return {"ok": False, "reason": f"demo baseline refused: {e}"}
    v = r.get("verify") or {}
    return {"ok": bool(r.get("ok")) and r.get("profile") == "demo", "banner": r.get("banner"), "profile": r.get("profile"),
            "sha256": r.get("sha256"), "archive": Path(str(r.get("archive") or "")).name, "real_baseline": r.get("real_baseline"),
            "problems": (r.get("problems") or [])[:20], "verify_ok": v.get("ok"),
            "reason": f"{r.get('banner') or 'DEMO baseline'}: evidence {'verify ok' if v.get('ok') else 'verify FAILED'}"
                      + (f"; {'; '.join(r['problems'][:2])}" if r.get("problems") else "")}


def _http(port: int, method: str, path: str, host: str | None = None, body: dict | None = None,
          headers: dict | None = None, timeout: float = 30.0):
    import http.client
    c = http.client.HTTPConnection("127.0.0.1", port, timeout=timeout)
    h = {"Host": host or f"127.0.0.1:{port}", **(headers or {})}
    data = json.dumps(body).encode() if body is not None else None
    if data is not None:
        h.setdefault("Content-Type", "application/json")
    c.request(method, path, body=data, headers=h)
    r = c.getresponse()
    payload = r.read()
    out = (r.status, {k.lower(): v for k, v in r.getheaders()}, payload)
    c.close()
    return out


def _listen_addresses(port: int) -> list[str]:
    """Local addresses listening on port (Linux /proc/net/tcp, tcp6); [] when it cannot be read."""
    out = []
    for f, v6 in (("/proc/net/tcp", False), ("/proc/net/tcp6", True)):
        try:
            lines = Path(f).read_text().splitlines()[1:]
        except OSError:
            continue
        for ln in lines:
            parts = ln.split()
            if len(parts) < 4 or parts[3] != "0A":            # LISTEN
                continue
            addr, p = parts[1].split(":")
            if int(p, 16) != port:
                continue
            if v6:
                out.append("::1" if addr == "00000000000000000000000001000000" else addr)
            else:
                out.append(".".join(str(int(addr[i:i + 2], 16)) for i in (6, 4, 2, 0)))
    return out


def probe_gui(data: str, out: str, **_) -> dict:
    """M7: start `econquest gui` on 127.0.0.1 and a free port, smoke and security checks, stop it."""
    import socket
    s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
    checks: dict[str, tuple[bool, str]] = {}
    base = [sys.executable, "-m", "econquest", "--data", data, "--out", out, "gui", "--no-browser"]
    bad = subprocess.run(base + ["--host", "0.0.0.0", "--port", str(port)], capture_output=True, text=True, timeout=120)
    checks["refuses 0.0.0.0"] = (bad.returncode != 0 and "loopback" in (bad.stderr + bad.stdout),
                                 f"exit {bad.returncode}")
    proc = subprocess.Popen(base + ["--host", "127.0.0.1", "--port", str(port)], stdout=subprocess.PIPE,
                            stderr=subprocess.STDOUT, text=True)
    try:
        t0 = time.time()
        while True:
            try:
                socket.create_connection(("127.0.0.1", port), timeout=1).close()
                break
            except OSError:
                if proc.poll() is not None or time.time() - t0 > 180:
                    tail = (proc.stdout.read() if proc.stdout else "")[-400:]
                    return {"ok": False, "port": port, "reason": f"GUI did not start (exit {proc.poll()}): {tail.strip()[-200:]}"}
                time.sleep(0.3)
        started = round(time.time() - t0, 1)
        addrs = _listen_addresses(port)
        checks["binds 127.0.0.1 only"] = (bool(addrs) and all(a in ("127.0.0.1", "::1") for a in addrs),
                                          ",".join(addrs) or "listen table unreadable")
        st, hd, page = _http(port, "GET", "/")
        m = re.search(rb'name="econquest-token" content="([^"]+)"', page)
        token = m.group(1).decode() if m else ""
        checks["page"] = (st == 200 and bool(token), f"GET / {st}")
        st, hd, body = _http(port, "GET", "/api/run/latest")
        try:
            latest = json.loads(body)
        except ValueError:
            latest = {}
        checks["run: latest"] = (st == 200 and len(latest.get("country") or []) == DESK_NAMES, f"GET /api/run/latest {st}")
        hdr_ok = (hd.get("x-content-type-options") == "nosniff" and hd.get("x-frame-options") == "DENY"
                  and hd.get("cache-control") == "no-store" and "access-control-allow-origin" not in hd)
        checks["security headers"] = (hdr_ok, "nosniff, DENY, no-store, no CORS" if hdr_ok else f"got {hd}")
        auth = {"X-EconQuest-Token": token}
        st, _, body = _http(port, "POST", "/api/job", body={"cmd": "scenarios", "args": []}, headers=auth)
        job_ok, job_txt = False, f"POST /api/job {st}"
        if st == 200:
            jid = json.loads(body).get("id")
            t1 = time.time()
            while time.time() - t1 < 180:
                st2, _, b2 = _http(port, "GET", f"/api/job/{jid}")
                j = json.loads(b2) if st2 == 200 else {}
                if j.get("status") in ("done", "failed"):
                    job_ok, job_txt = j["status"] == "done", f"job scenarios {j['status']}"
                    break
                time.sleep(0.5)
            else:
                job_txt = "job scenarios did not finish"
        checks["run: job"] = (job_ok, job_txt)
        for name, path in (("results: countries", "/api/countries"), ("results: portfolio", "/api/portfolio"),
                           ("results: table", "/api/table/country_risk"), ("open items", "/api/open-items")):
            st, _, body = _http(port, "GET", path, timeout=120)
            checks[name] = (st == 200 and len(body) > 2, f"GET {path} {st}")
        st, _, nb = _http(port, "GET", "/api/notes", headers=auth, timeout=120)     # EQ-C-0127: token-guarded read
        try:
            nidx = json.loads(nb) if st == 200 else {}
        except ValueError:
            nidx = {}
        nlist = [n for n in nidx.get("notes") or [] if isinstance(n, dict)]
        cn = sum(1 for n in nlist if n.get("kind") == "country_note")
        checks["notes"] = (st == 200 and cn == DESK_NAMES,
                           f"GET /api/notes {st}: {len(nlist)} notes, {cn} country notes of {DESK_NAMES}"
                           + (f" ({nidx.get('status')}: {nidx.get('message')})" if st == 200 and not nlist else ""))
        if nlist:
            first = nlist[0]
            st, _, ob = _http(port, "GET", "/api/notes/" + quote(str(first.get("id")), safe=""), headers=auth, timeout=120)
            try:
                one = json.loads(ob) if st == 200 else {}
            except ValueError:
                one = {}
            ok1 = st == 200 and bool(one.get("blocks")) and bool(one.get("disclaimer_ok")) and bool(one.get("attribution_ok"))
            checks["notes: one note"] = (ok1, f"GET /api/notes/{first.get('id')} {st}: {len(one.get('blocks') or [])} blocks, "
                                              f"disclaimer {'yes' if one.get('disclaimer_ok') else 'NO'}, "
                                              f"licence attribution {'yes' if one.get('attribution_ok') else 'NO'}")
        else:
            checks["notes: one note"] = (False, "no note in /api/notes to open")
        st, _, _b = _http(port, "GET", "/api/notes")
        checks["notes: token guard"] = (st == 403, f"GET /api/notes without token -> {st}")
        st, _, _b = _http(port, "GET", "/api/notes/..%2Fpack.json", headers=auth)
        checks["notes: no path lookup"] = (st == 404, f"GET /api/notes/..%2Fpack.json -> {st}")
        st, _, _b = _http(port, "GET", "/api/status", host="evil.example")
        checks["Host guard"] = (st == 403, f"Host evil.example -> {st}")
        st, _, _b = _http(port, "POST", "/api/job", body={"cmd": "scenarios"})
        checks["token guard"] = (st == 403, f"POST without token -> {st}")
        st, _, _b = _http(port, "POST", "/api/job", body={"cmd": "scenarios"}, headers={**auth, "Origin": "http://evil.example"})
        checks["Origin guard"] = (st == 403, f"cross-origin POST -> {st}")
        st, _, _b = _http(port, "POST", "/api/job", body={"cmd": "scenarios"}, headers={**auth, "Content-Type": "text/plain"})
        checks["content-type guard"] = (st == 403, f"text/plain POST -> {st}")
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=15)
        except subprocess.TimeoutExpired:
            proc.kill(); proc.wait(timeout=5)
    failed = [k for k, (ok, _t) in checks.items() if not ok]
    return {"ok": not failed, "port": port, "started_s": started, "stopped": proc.returncode is not None,
            "checks": {k: {"ok": ok, "detail": t} for k, (ok, t) in checks.items()},
            "reason": (f"failed: {'; '.join(f'{k} ({checks[k][1]})' for k in failed)}; " if failed else "")
                      + f"{len(checks) - len(failed)}/{len(checks)} checks ok on 127.0.0.1:{port}, stopped"}


def probe_signoff(data: str, out: str, as_of: str = AS_OF, paths: int = 0, rs_paths: int = 0, rs_full: bool = False,
                  **_) -> dict:
    """M3: Team B's MVP numbers sign-off (validation.mvp_signoff, EQ-B-0111) on the demo's MVP data, at the demo's
    path counts; replication is skipped (it runs on the release inputs) and no release reference is compared (the MVP
    data are not the release's). Writes <out>/mvp-signoff/."""
    from ..validation import mvp_signoff as MS
    p = int(paths or 20000)
    res = MS.signoff(data, as_of, paths=p, rs_paths=int(rs_paths or 5000), replicate="skip", reference=None, rerun=True,
                     scenarios=None if rs_full else list(RS_SCENARIOS), log=lambda *a, **k: print(*a, file=sys.stderr))
    files = MS.write_report(res, Path(out) / "mvp-signoff")
    fails = [f"{c.get('id')}: {str(c.get('check', ''))[:80]} {str(c.get('detail', ''))[:60]}".strip()
             for c in res["checks"] if c.get("status") == "FAIL"]
    counts: dict[str, int] = {}
    for c in res["checks"]:
        counts[c["status"]] = counts.get(c["status"], 0) + 1
    base = {k: res["base"].get(k) for k in ("var99_mm", "es99_mm", "expected_loss_mm", "lvar99_mm")}
    return {"ok": res["verdict"] == "SIGNED OFF", "verdict": res["verdict"], "as_of": res["as_of"], "data": str(data),
            "paths": res["paths"], "stress_paths": res["stress_paths"], "rs_paths": res["rs_paths"], "base": base,
            "counts": counts, "fails": fails[:10], "files": files,
            "reason": f"mvp_signoff {res['verdict']} ({', '.join(f'{k} {v}' for k, v in sorted(counts.items()))}) at "
                      f"{res['paths']:,} requested paths, as_of {res['as_of']}: " + fig_text(base)
                      + (f"; FAIL {'; '.join(fails[:2])}" if fails else "")}


def fig_text(m: dict) -> str:
    return ", ".join(f"{lab} {m[k]:.2f}" for lab, k in (("VaR99", "var99_mm"), ("ES99", "es99_mm"), ("EL", "expected_loss_mm"),
                                                         ("L-VaR99", "lvar99_mm")) if _finite(m.get(k))) + " $mm"


RELEASE_BASE_IDS = {"var99_mm": "R48", "es99_mm": "R49", "expected_loss_mm": "R50", "lvar99_mm": "R51"}   # 0.7.0 base


def release_base_summary(rep_dir: Path, data: Path, quick: bool) -> dict:
    """demo.json "release_base" from replicate's own files (replication.csv, summary.json): counts, how the inputs
    compare with RELEASE-HASHES.json, the R01-R51 pins and the release base figures (reported at the documented
    paths, recomputed at the replication's)."""
    import csv
    out = {"label": "Release base (shared data)", "data": str(data), "replication": "quick" if quick else "full",
           "recomputed_paths": 20000 if quick else 100000}
    try:
        s = json.loads((rep_dir / "summary.json").read_text())
        out.update(counts=s.get("counts") or {}, pins_release=s.get("release"), drift=s.get("drift"))
    except (OSError, ValueError):
        out.update(counts={}, drift=None)
    try:
        with open(rep_dir / "replication.csv", newline="") as f:
            rows = list(csv.DictReader(f))
    except OSError:
        rows = []
    r_rows = [x for x in rows if re.fullmatch(r"R\d\d", x.get("id", "")) and 1 <= int(x["id"][1:]) <= 51]
    out["pins"] = {"ids": "R01-R51", "checked": len(r_rows),
                   "status": {k: sum(1 for x in r_rows if x["status"] == k) for k in sorted({x["status"] for x in r_rows})}}
    by = {x["id"]: x for x in rows}
    figs = {}
    for k, cid in RELEASE_BASE_IDS.items():
        x = by.get(cid)
        if x:
            m = re.search(r"([\d,]+) requested", x.get("quantity", ""))
            figs[k] = {"id": cid, "status": x["status"], "reported": float(x["reported"]) if x["reported"] else None,
                       "reported_paths": int(m.group(1).replace(",", "")) if m else None,
                       "recomputed": float(x["recomputed"]) if x["recomputed"] else None,
                       "recomputed_paths": out["recomputed_paths"], "source": x.get("source", "")}
    out["figures"] = figs
    d = out.get("drift")
    out["pins_text"] = ("inputs equal the RELEASE-HASHES.json pins" if not d else
                        f"inputs differ from the {d.get('release')} RELEASE-HASHES.json pins in {len(d.get('files') or [])} "
                        f"file(s): {', '.join((d.get('files') or [])[:4])}")
    return out


def probe_research_v2(data: str, out: str, **_) -> dict:
    """M13 (EQ-C-0136): Team B's research v2 check (validation.house_view, EQ-B-0115) on the M5 pack in
    <out>/reports/mvp. house_view.json is built there first when the pack has none (mvp_pack wiring, HO-20261025-B-B-002).
    status: fail on any problem, pending when only products are "not wired" (HO-20261025-B-C-017), else pass."""
    try:
        from ..validation import house_view as HV
        check, build = HV.house_view_problems, HV.build_house_view
    except (ImportError, AttributeError):
        return {"status": "pending", "pending": True, "reason": "pending: Team B research v2 not landed (econquest.validation.house_view)"}
    pack = Path(out).resolve() / "reports" / "mvp"
    if not (pack / "run_latest.json").is_file():
        return {"status": "fail", "ok": False, "reason": "no research pack run in reports/mvp (M5 built none): nothing to check"}
    built = ""
    if not (pack / HV.FILE).is_file():
        build(pack, data)
        built = f"{HV.FILE} built by the demo (the pack has none yet: HO-20261025-B-B-002); "
    hv = json.loads((pack / HV.FILE).read_text(encoding="utf-8"))
    res = check(pack, data)
    probs, nw = [str(x) for x in res.get("problems") or []], [str(x) for x in res.get("not_wired") or []]
    status = "fail" if probs else "pending" if nw else "pass"
    counts = ", ".join(f"{k} {v}" for k, v in (hv.get("counts") or {}).items())
    ck = res.get("checked") or {}
    head = (f"house_view check FAIL, {len(probs)} problems: {'; '.join(probs[:2])}" if probs else
            "house_view check: no problem, not wired: " + "; ".join(nw[:3]) if nw else "house_view check PASS")
    return {"status": status, "ok": status == "pass", "pending": status == "pending", "problems": probs[:50], "not_wired": nw,
            "checked": ck, "counts": hv.get("counts"), "run_id": res.get("run_id") or hv.get("run_id"), "built_by_demo": bool(built),
            "reason": f"{built}{head}; house view {hv.get('run_id')}: {counts}; checked {ck.get('notes', 0)} notes, "
                      f"{ck.get('weekly_rows', 0)} weekly-brief rows, {ck.get('activations', 0)} trade-idea activations "
                      f"({ck.get('counter_view', 0)} counter-view or two-way) (EQ-B-0115, Team B owns the check)"}


def probe_gui_plus(data: str, out: str, **_) -> dict:
    """M11/M12 GUI half (EQ-C-0136): start `econquest gui` on 127.0.0.1, GET /api/morning with the token (must equal the
    CLI payload in $ECONQUEST_DEMO_MORNING_JSON apart from MORNING_IGNORE) and without it (403), POST /api/whatif with
    the token (the trade in $ECONQUEST_DEMO_WHATIF_TRADE; nothing written) and without it (403); then stop it."""
    import socket
    s = socket.socket(); s.bind(("127.0.0.1", 0)); port = s.getsockname()[1]; s.close()
    argv = [sys.executable, "-m", "econquest", "--data", data, "--out", out, "gui", "--no-browser", "--host", "127.0.0.1",
            "--port", str(port)]
    c11: dict[str, tuple[bool, str]] = {}
    c12: dict[str, tuple[bool, str]] = {}
    proc = subprocess.Popen(argv, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, text=True)
    try:
        t0 = time.time()
        while True:
            try:
                socket.create_connection(("127.0.0.1", port), timeout=1).close()
                break
            except OSError:
                if proc.poll() is not None or time.time() - t0 > 180:
                    tail = (proc.stdout.read() if proc.stdout else "")[-200:]
                    why = f"GUI did not start (exit {proc.poll()}): {tail.strip()}"
                    return {"ok": False, "reason": why, "m11": {"ok": False, "reason": why}, "m12": {"ok": False, "reason": why}}
                time.sleep(0.3)
        st, _h, page = _http(port, "GET", "/")
        m = re.search(rb'name="econquest-token" content="([^"]+)"', page)
        auth = {"X-EconQuest-Token": m.group(1).decode() if m else ""}
        # M11: the Home tab's payload
        try:
            cli = json.loads(Path(os.environ.get("ECONQUEST_DEMO_MORNING_JSON", "")).read_text(encoding="utf-8"))
        except (OSError, ValueError):
            cli = None
        st, _h, b = _http(port, "GET", "/api/morning", headers=auth, timeout=300)
        try:
            api = json.loads(b) if st == 200 else {}
        except ValueError:
            api = {}
        c11["GET /api/morning"] = (st == 200 and api.get("schema") == MORNING_SCHEMA and not api.get("error"),
                                   f"GET /api/morning {st}" + (f": {api.get('error')}" if api.get("error") else ""))
        if cli:
            d = json_diff(cli, api, MORNING_IGNORE)
            c11["equals the CLI payload"] = (not d, f"equal apart from {', '.join(MORNING_IGNORE)}" if not d else
                                             f"{len(d)} fields differ: {', '.join(d[:4])}")
        else:
            c11["equals the CLI payload"] = (False, "no CLI morning payload to compare (M11 CLI step gave none)")
        st, _h, _b = _http(port, "GET", "/api/morning")
        c11["token guard"] = (st == 403, f"GET /api/morning without token -> {st}")
        # M12: the what-if route, in memory only
        try:
            trade = json.loads(os.environ.get("ECONQUEST_DEMO_WHATIF_TRADE", ""))
        except ValueError:
            trade = {"country": "Brazil", "instrument": "Eurobond", "notional_mm": 10, "side": "buy"}
        body = {"trades": [trade], "paths": 5000}
        h0 = state_hashes(data, out)
        st, _h, b = _http(port, "POST", "/api/whatif", body=body, headers=auth, timeout=900)
        try:
            w = json.loads(b)
        except ValueError:
            w = {}
        ok = (st == 200 and w.get("schema") == WHATIF_SCHEMA and w.get("booked") is False
              and (w.get("limits") or {}).get("status_after") in ("pass", "warning", "breach")
              and all(_finite(v) for v in ((w.get("metrics") or {}).get("delta") or {"x": None}).values()))
        c12["POST /api/whatif"] = (ok, f"POST /api/whatif {st}: booked {str(w.get('booked')).lower()}, mode {w.get('mode')}, "
                                       f"{w.get('paths')} paths, limits after {(w.get('limits') or {}).get('status_after')}"
                                   + (f" ({w.get('error')})" if w.get("error") else ""))
        ch = hash_change(h0, state_hashes(data, out))
        c12["nothing written"] = (not ch, "positions/store files byte-identical" if not ch else f"files changed: {ch}")
        st, _h, _b = _http(port, "POST", "/api/whatif", body=body)
        c12["token guard"] = (st == 403, f"POST /api/whatif without token -> {st}")
    finally:
        proc.terminate()
        try:
            proc.wait(timeout=15)
        except subprocess.TimeoutExpired:
            proc.kill(); proc.wait(timeout=5)

    def part(c):
        bad = [k for k, (ok_, _t) in c.items() if not ok_]
        return {"ok": bool(c) and not bad, "checks": {k: {"ok": o, "detail": t} for k, (o, t) in c.items()},
                "reason": (f"failed: {'; '.join(f'{k} ({c[k][1]})' for k in bad)}; " if bad else "")
                          + f"{len(c) - len(bad)}/{len(c)} GUI checks ok on 127.0.0.1:{port}: " + "; ".join(t for _o, t in c.values())}
    r11, r12 = part(c11), part(c12)
    return {"ok": r11["ok"] and r12["ok"], "port": port, "stopped": proc.returncode is not None, "m11": r11, "m12": r12,
            "reason": f"M11 {r11['reason']} | M12 {r12['reason']}"}


def _inside(p, root) -> bool:
    try:
        Path(p).resolve().relative_to(Path(root).resolve())
        return True
    except ValueError:
        return False


def probe_client_sandbox(data: str, out: str, **_) -> dict:
    """M14 (EQ-C-0148): ops.client_outbox.demo_sandbox on the demo home (build, send, verify and the refusals). The
    operator action log ($ECONQUEST_ACTION_LOG, set by the demo) and the outbox must both be inside <out>."""
    try:
        from .client_outbox import demo_sandbox
        from . import actionlog
    except ImportError:
        return {"status": "pending", "pending": True, "reason": "pending: client sandbox not landed (econquest.ops.client_outbox.demo_sandbox)"}
    outp, datap = Path(out).resolve(), Path(data).resolve()
    alog = actionlog.log_path(outp)
    problems = [] if _inside(alog, outp) else [f"action log {alog} is outside the demo home {outp}"]
    r = demo_sandbox(datap, outp)
    if r.get("dir") and not _inside(r["dir"], outp):
        problems.append(f"outbox {r['dir']} is outside the demo home {outp}")
    problems += [str(x) for x in r.get("problems") or []]
    ok = bool(r.get("ok")) and not problems
    v = r.get("verify") or {}
    refusals = sorted((r.get("refusals") or {}).keys())
    text = (f"sandbox run {r.get('run')}: {r.get('pages', 0)} pages, {r.get('recipients', 0)} test recipients, licence baseline "
            f"{r.get('baseline')}, verify {'ok' if v.get('ok') else 'FAILED'}; refused: {', '.join(refusals) or 'none'}")
    return {"status": "pass" if ok else "fail", "ok": ok, "run": r.get("run"), "dir": r.get("dir"), "baseline": r.get("baseline"),
            "pages": r.get("pages"), "recipients": r.get("recipients"), "refusals": r.get("refusals") or {},
            "action_log": str(alog), "problems": problems[:30],
            "reason": (f"FAIL, {len(problems)} problems: {'; '.join(problems[:3])}; " if problems else "") + text}


def probe_vendor_sim(data: str, out: str, **_) -> dict:
    """M15 (EQ-C-0148): ops.vendor_rehearse.demo_vendor_sim on the sandbox in $ECONQUEST_DEMO_VENDOR_SANDBOX (outside the
    tree), with its desk-untouched check on the demo home's data/ and outputs/."""
    try:
        from .vendor_rehearse import demo_vendor_sim
    except ImportError:
        return {"status": "pending", "pending": True, "reason": "pending: vendor rehearsal not landed (econquest.ops.vendor_rehearse.demo_vendor_sim)"}
    import inspect
    sbx = os.environ.get("ECONQUEST_DEMO_VENDOR_SANDBOX") or None
    if "data_dir" in inspect.signature(demo_vendor_sim).parameters:
        r = demo_vendor_sim(sbx, data_dir=data, outputs_dir=out)
        desk = "the demo home's data/ and outputs/"
    else:                                   # an installed release older than the kwargs: its repo root IS the demo home
        r = demo_vendor_sim(sbx)
        desk = "the installed home's data/ and outputs/"
    steps = [s for s in r.get("steps") or [] if isinstance(s, dict)]
    n_ok = sum(1 for s in steps if s.get("result") == "PASS")
    untouched = next((s for s in steps if s.get("area") == "desk untouched"), None)
    probs = [str(x) for x in r.get("problems") or []]
    ok = bool(r.get("ok")) and bool(steps) and not probs
    ut = (f"desk untouched ({desk}): {'yes' if untouched.get('result') == 'PASS' else 'NO'}, {untouched.get('detail')}" if untouched
          else "no desk-untouched row")
    return {"status": "pass" if ok else "fail", "ok": ok, "sandbox": sbx, "steps": steps, "problems": probs[:30],
            "reason": (f"FAIL, {len(probs)} problems: {'; '.join(probs[:3])}; " if probs else "")
                      + f"SIMULATED vendor rehearsal {n_ok}/{len(steps)} rows pass in sandbox {sbx}; {ut}"}


def probe_calendar(data: str, out: str, **_) -> dict:
    """M16 (EQ-C-0148): presentation.rehearsal_view.demo_calendar_page(<out>) (Team B's demo_calendar_rehearsal plus the
    page check). Any problem fails the row with its reason; job SEQUENCE problems name Team B's open handoff."""
    try:
        from ..presentation.rehearsal_view import demo_calendar_page
    except ImportError:
        return {"status": "pending", "pending": True, "reason": "pending: calendar rehearsal page not landed (econquest.presentation.rehearsal_view)"}
    r = demo_calendar_page(Path(out).resolve())
    probs = [str(x) for x in r.get("problems") or []]
    seq = [x for x in probs if x.startswith("rehearsal: job ")]
    ok = bool(r.get("ok")) and not probs
    why = ""
    if probs:
        why = f"FAIL, {len(probs)} problems"
        if seq:
            why += (f" ({len(seq)} job sequence rows differ: Team B's {CALENDAR_HANDOFF}, new SEQUENCE rows after the RF-3 "
                    "grace window, not landed yet)")
        why += ": " + "; ".join(probs[:2]) + "; "
    return {"status": "pass" if ok else "fail", "ok": ok, "problems": probs[:30], "sequence_problems": len(seq),
            "summary": r.get("summary"), "reason": why + str(r.get("summary") or "")}


# ------------------------------------------------ MVP+ M17-M20 (EQ-C-0158)
TEXT_INDEX_HANDOFF = "HO-20261026-B-C-015"
# client-facing code: none of it may import Team B's text index (the demo itself, ops/demo.py, is not client output)
CLIENT_CODE = ("presentation", "ops", "persistence", "ingestion", "cli.py")
TEXT_INDEX_IMPORT = re.compile(r"validation\.text_index|validation\s+import[^\n]*\btext_index\b|from\s+\.text_index\b")
TEXT_INDEX_MARKS = ("eq-text-index/1", "text_index_SYNTHETIC")
CLIENT_SCAN_SUFFIXES = (".json", ".jsonl", ".csv", ".html", ".htm", ".md", ".txt", ".xml", ".eml")


def _text_index_importers(pkg_root: Path) -> list[str]:
    """Client-facing source files (CLIENT_CODE under the econquest package actually imported) naming the text index."""
    hits = []
    for part in CLIENT_CODE:
        p = pkg_root / part
        files = [p] if p.is_file() else sorted(p.rglob("*.py")) if p.is_dir() else []
        for f in files:
            if f.name == "demo.py" and f.parent.name == "ops":
                continue
            try:
                if TEXT_INDEX_IMPORT.search(f.read_text(encoding="utf-8", errors="replace")):
                    hits.append(f.relative_to(pkg_root).as_posix())
            except OSError:
                pass
    return hits


def _text_index_leaks(out: Path) -> list[str]:
    """Files under the demo home's outputs/ (client outbox, research and client-safe packs, publish payloads) other than
    the M17 folder itself that carry an eq-text-index row or file name."""
    leaks = []
    own = out / "text_index"
    for f in sorted(out.rglob("*")):
        if not f.is_file() or f.suffix.lower() not in CLIENT_SCAN_SUFFIXES or _inside(f, own):
            continue
        try:
            if f.stat().st_size > 20_000_000:
                continue
            t = f.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        if any(m in t for m in TEXT_INDEX_MARKS):
            leaks.append(f.relative_to(out).as_posix())
    return leaks


def probe_text_index(data: str, out: str, as_of: str = AS_OF, **_) -> dict:
    """M17 (EQ-C-0158, HO-20261026-B-C-015): Team B's validation.text_index.demo_text_index(<out>, data_dir=<data>,
    real_as_of=<demo as_of>) on the demo home. The SYNTHETIC banner and real_backtest.status are shown as given; the
    switch must be off (switch_state) and run() is never called. Client safety: client_safe_rows keeps none of the
    rows, no client-facing module imports the index, and no file under <out> outside text_index/ carries a row."""
    try:
        from ..validation import text_index as TI
        demo_text_index, switch_state, client_safe_rows = TI.demo_text_index, TI.switch_state, TI.client_safe_rows
    except (ImportError, AttributeError):
        return {"status": "pending", "pending": True,
                "reason": "pending: not landed (econquest.validation.text_index.demo_text_index, Team B EQ-B-0135)"}
    outp, datap = Path(out).resolve(), Path(data).resolve()
    problems: list[str] = []
    sw = switch_state(datap)
    if sw.get("enabled"):
        problems.append(f"text index switch is ON in the demo home (from {sw.get('from')}); M17 expects it off")
    r = demo_text_index(outp, data_dir=datap, real_as_of=as_of)
    problems += [str(x) for x in r.get("problems") or []]
    paths = {k: v for k, v in (r.get("paths") or {}).items() if v}
    problems += [f"{k} {v} is outside {outp / 'text_index'}" for k, v in paths.items() if not _inside(v, outp / "text_index")]
    rows = []
    try:
        rows = json.loads(Path(paths["json"]).read_text(encoding="utf-8")).get("rows") or [] if paths.get("json") else []
    except (OSError, ValueError) as e:
        problems.append(f"index JSON unreadable: {e}")
    safe = client_safe_rows(rows)
    if safe:
        problems.append(f"client_safe_rows kept {len(safe)} of {len(rows)} rows (expected none)")
    importers = _text_index_importers(Path(TI.__file__).resolve().parents[1])
    problems += [f"client-facing code imports the text index: {f}" for f in importers[:5]]
    leaks = _text_index_leaks(outp)
    problems += [f"text-index content in client/pack output: {f}" for f in leaks[:5]]
    if (r.get("switch") or {}).get("enabled") is not False:
        problems.append(f"demo_text_index reports switch {r.get('switch')}")
    ok = bool(r.get("ok")) and not problems
    label = str(r.get("label") or "")
    bt = str((r.get("real_backtest") or {}).get("status") or "")
    s = r.get("summary") or {}
    text = (f"{label}; {s.get('rows', 0)} synthetic rows ({', '.join(s.get('countries') or [])}), first warning "
            f"{s.get('first_warning')}; switch {'on' if sw.get('enabled') else 'off'} ({sw.get('from')}); real backtest: {bt}; "
            f"client safe: {len(safe)} of {len(rows)} rows, {len(importers)} client modules import it, {len(leaks)} leaks")
    return {"status": "pass" if ok else "fail", "ok": ok, "label": label, "real_backtest": r.get("real_backtest"),
            "switch": sw, "summary": s, "paths": paths, "client_safe_rows": len(safe), "rows": len(rows),
            "importers": importers, "leaks": leaks[:30], "problems": problems[:30],
            "reason": (f"FAIL, {len(problems)} problems: {'; '.join(problems[:3])}; " if problems else "") + text}


def probe_events(data: str, out: str, **_) -> dict:
    """M18 (EQ-C-0158): presentation.calendar_view.demo_events_view(<data>, <out>/events_view) (EQ-C-0155). An empty
    type whose adapter answers counts as "no events yet, adapter ok"."""
    try:
        from ..presentation.calendar_view import demo_events_view
    except ImportError:
        return {"status": "pending", "pending": True,
                "reason": "pending: not landed (econquest.presentation.calendar_view.demo_events_view, EQ-C-0155)"}
    r = demo_events_view(Path(data).resolve(), Path(out).resolve() / "events_view")
    probs = [str(x) for x in r.get("problems") or []]
    ok = bool(r.get("ok")) and not probs
    return {"status": "pass" if ok else "fail", "ok": ok, "types": r.get("types") or {}, "problems": probs[:30],
            "evidence": r.get("evidence"),
            "reason": (f"FAIL, {len(probs)} problems: {'; '.join(probs[:3])}; " if probs else "") + str(r.get("summary") or "")}


def _find_demo_depth() -> tuple[object | None, str]:
    """The econquest.presentation module that defines demo_depth_page (EQ-C-0156), found by its source, or None."""
    import importlib
    pres = Path(__file__).resolve().parents[1] / "presentation"
    for f in sorted(pres.glob("*.py")):
        try:
            if "def demo_depth_page" in f.read_text(encoding="utf-8", errors="replace"):
                return importlib.import_module(f"econquest.presentation.{f.stem}"), f.stem
        except (OSError, ImportError):
            continue
    return None, ""


def _part(name: str, r) -> tuple[str, str, list[str]]:
    r = r if isinstance(r, dict) else {"ok": bool(r)}
    probs = [str(x) for x in r.get("problems") or []]
    ok = bool(r.get("ok")) and not probs
    return ("pass" if ok else "fail",
            f"{name}: " + (f"FAIL, {len(probs)} problems: {'; '.join(probs[:2])}; " if probs else "")
            + str(r.get("summary") or ("ok" if ok else "not ok")), probs)


def probe_depth(data: str, out: str, **_) -> dict:
    """M19 (EQ-C-0158): demo_depth_page(<out>) then demo_heatmap(<out>) from the presentation module EQ-C-0156 adds
    (presentation.heatmap), each given data_dir=<data> when it takes one, so neither reads the shared data/."""
    import inspect
    mod, name = _find_demo_depth()
    if mod is None or not hasattr(mod, "demo_depth_page"):
        return {"status": "pending", "pending": True,
                "reason": "pending: not landed (econquest.presentation.*.demo_depth_page / demo_heatmap, EQ-C-0156)"}
    outp = Path(out).resolve()
    parts, probs = [], []
    for fn in ("demo_depth_page", "demo_heatmap"):
        f = getattr(mod, fn, None)
        if f is None:
            parts.append(("pending", f"{fn}: pending: not landed in econquest.presentation.{name}"))
            continue
        try:
            kw = {"data_dir": str(Path(data).resolve())} if data and "data_dir" in inspect.signature(f).parameters else {}
            st, txt, p = _part(fn, f(outp, **kw))
        except Exception as e:                              # noqa: BLE001 - reported as a failed part
            st, txt, p = "fail", f"{fn} raised {type(e).__name__}: {str(e)[:200]}", [f"{fn} raised {type(e).__name__}"]
        parts.append((st, txt))
        probs += p
    st, why = combine(parts)
    return {"status": st, "ok": st == "pass", "pending": st == "pending", "module": f"econquest.presentation.{name}",
            "problems": probs[:30], "reason": why}


def probe_archive(data: str, out: str, **_) -> dict:
    """M20 (EQ-C-0158): presentation.archive.demo_archive(<out>, limit=5) (EQ-C-0154) on the demo home's research pack
    (<out>/reports/mvp, built by M5); it writes only <out>/archive and a temp folder."""
    try:
        from ..presentation.archive import demo_archive
    except ImportError:
        return {"status": "pending", "pending": True,
                "reason": "pending: not landed (econquest.presentation.archive.demo_archive, EQ-C-0154)"}
    r = demo_archive(Path(out).resolve(), pack_dir=None, limit=5)
    probs = [str(x) for x in r.get("problems") or []]
    ok = bool(r.get("ok")) and not probs
    return {"status": "pass" if ok else "fail", "ok": ok, "problems": probs[:30],
            **{k: r.get(k) for k in ("archived", "corrected", "verify", "tamper_detected", "backend", "search_hits") if k in r},
            "reason": (f"FAIL, {len(probs)} problems: {'; '.join(probs[:3])}; " if probs else "") + str(r.get("summary") or "")}


# ------------------------------------------------ MVP+ M21-M24 (EQ-C-0166)
ONLY_ROWS = ("M21", "M22", "M23", "M24", "M25", "M26", "M27")   # --only: rows that need nothing from M2-M10
PLUS3_PROBES = (("M22", "backtest_explainer"), ("M23", "validator_kit"), ("M24", "research_qa"))
PLUS4_PROBES = (("M25", "assistant_answer"), ("M26", "assistant_refusal"), ("M27", "assistant_draft"))   # EQ-C-0174
ZIPS_ENV = "ECONQUEST_DEMO_ZIPS"                    # M21: folder of shipped zips (else the zip under test's folder)
EXPLAINER_DATA_ENV = "ECONQUEST_DEMO_EXPLAINER_DATA"
KIT_DATA_ENV = "ECONQUEST_DEMO_KIT_DATA"
SHARED_TREE_ENV = "ECONQUEST_DEMO_SHARED_TREE"     # --fast: the code tree is the shared one other sessions write
KIT_ROOM_AS_OF = "2026-10-26"                       # the 0.10.0 release day, the date of Team A's DEMO room (B-A-011)
KIT_DIR = "validator_kit"
EXPLAINER_HANDOFF = "HO-20261026-B-C-018"
KIT_REVIEW = "HO-20261026-B-B-019"


def probe_backtest_explainer(data: str, out: str, as_of: str = AS_OF, **_) -> dict:
    """M22 (EQ-C-0166): presentation.backtest_explainer_view.demo_explainer_page(<out>, as_of, data_dir, step=21), which
    runs Team B's demo_backtest_explainer (about a minute) and renders the INTERIM page section. data_dir is
    $ECONQUEST_DEMO_EXPLAINER_DATA (the program's own data/: Team B reads the real record only), else <data>."""
    try:
        from ..presentation.backtest_explainer_view import demo_explainer_page
        from ..validation import backtest_explainer  # noqa: F401 - Team B's module must be there too
    except ImportError:
        return {"status": "pending", "pending": True,
                "reason": "pending: not landed (econquest.validation.backtest_explainer, Team B EQ-B-0141, or "
                          "presentation.backtest_explainer_view, EQ-C-0166)"}
    d = Path(os.environ.get(EXPLAINER_DATA_ENV) or data).resolve()
    r = demo_explainer_page(Path(out).resolve(), as_of, data_dir=str(d), step=21)
    if r.get("pending"):
        return {"status": "pending", "pending": True, "reason": str(r.get("summary") or "pending: not landed")}
    probs = [str(x) for x in r.get("problems") or []]
    ok = bool(r.get("ok")) and not probs
    return {"status": "pass" if ok else "fail", "ok": ok, "problems": probs[:30], "exceptions": r.get("exceptions"),
            "unreconciled": r.get("unreconciled"), "gaps": r.get("gaps"), "data_dir": str(d),
            "reason": (f"FAIL, {len(probs)} problems: {'; '.join(probs[:3])}; " if probs else "") + str(r.get("summary") or "")
                      + f" ({EXPLAINER_HANDOFF}; data {d.parent.name}/{d.name}, read only)"}


def _kit_report(path: Path) -> dict:
    try:
        return json.loads(Path(path).read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {}


def _tamper_target(manifest: dict) -> str:
    """The room file the tamper check appends one byte to: the first data/*.csv listed, else the first data/ file."""
    paths = sorted(str(f.get("path")) for f in manifest.get("files") or [] if str(f.get("path", "")).startswith("data/"))
    return next((p for p in paths if p.endswith(".csv")), paths[0] if paths else "README.md")


def probe_validator_kit(data: str, out: str, **_) -> dict:
    """M23 (EQ-C-0166): Team B's validator replication kit (EQ-B-0143, in Team B review) on a fresh DEMO data room.
    The room is built with Team A's build_data_room($ECONQUEST_DEMO_KIT_DATA or <data>, KIT_ROOM_AS_OF,
    licence_baseline="demo", include_mvp=True) under <out>/validator_kit/room; the kit runs through its CLI
    (validator_kit.main) on it, then on a copy with one byte appended to a room file, which must be REFUSED (exit 3)."""
    try:
        from ..validation import validator_kit as VK
        from ..ingestion.dataroom import build_data_room
        from ..versioning import code_hash
        from .. import __version__
    except ImportError:
        return {"status": "pending", "pending": True,
                "reason": "pending: not landed (econquest.validation.validator_kit, Team B EQ-B-0143, or "
                          "ingestion.dataroom.build_data_room)"}
    src = Path(os.environ.get(KIT_DATA_ENV) or data).resolve()
    base = Path(out).resolve() / KIT_DIR
    shutil.rmtree(base, ignore_errors=True)
    room, kit, troom, tkit = base / "room", base / "kit", base / "room-tampered", base / "kit-tampered"
    t0 = time.time()
    m = build_data_room(src, KIT_ROOM_AS_OF, room, licence_baseline="demo", include_mvp=True)
    built = time.time() - t0
    sha, ch = m["manifest_sha256"], code_hash()
    common = ["--release", __version__, "--expect-manifest-sha256", sha, "--expect-code-hash", ch]
    rc = VK.main(["run", "--room", str(room), "--out", str(kit), *common])
    rep = _kit_report(kit / "report.json")
    shutil.copytree(room, troom)
    victim = _tamper_target(m)
    with open(troom / victim, "ab") as f:
        f.write(b"\n")
    rc2 = VK.main(["run", "--room", str(troom), "--out", str(tkit), *common])
    rep2 = _kit_report(tkit / "report.json")
    c = rep.get("counts") or {}
    g = rep.get("guards") or {}
    shared = bool(os.environ.get(SHARED_TREE_ENV))
    writes = list(g.get("writes_outside_out") or [])
    problems = []
    if rc != 0 or rep.get("status") != "RUN":
        problems.append(f"kit exit {rc}, status {rep.get('status')}: " + "; ".join(str(x) for x in (rep.get("problems") or [])[:2]))
    if c.get("FAIL"):
        problems.append(f"kit FAIL {c.get('FAIL')}")
    if not c.get("PASS"):
        problems.append("kit reproduced no check (PASS 0)")
    if g.get("network_refused"):
        problems.append(f"kit tried the network: {', '.join(map(str, g['network_refused'][:3]))}")
    if rep.get("status") == "RUN" and not g.get("room_after_ok"):
        problems.append("the room did not re-verify after the kit run")
    if writes and not shared:
        problems.append(f"kit wrote outside --out: {', '.join(writes[:3])}")
    refused = rc2 == VK.EXIT_REFUSED and rep2.get("status") == "REFUSED"
    if not refused:
        problems.append(f"the tampered copy was NOT refused (exit {rc2}, status {rep2.get('status')})")
    why2 = "; ".join(str(x) for x in (rep2.get("problems") or [])[:1])
    text = (f"fresh DEMO data room as of {KIT_ROOM_AS_OF} from {src.name}/ ({m['totals']['files']} files, manifest_sha256 "
            f"{sha[:12]}, built in {built:.0f}s); validator_kit run --release {__version__}: PASS {c.get('PASS', 0)}, DRIFT "
            f"{c.get('DRIFT', 0)}, FAIL {c.get('FAIL', 0)}, NOT RUN {c.get('NOT RUN', 0)} (exit {rc}); network refused "
            f"{len(g.get('network_refused') or [])}, writes outside --out {len(writes)}"
            + (" (shared tree in --fast: other sessions write it; reported, not failed)" if writes and shared else "")
            + f", room re-verified {'ok' if g.get('room_after_ok') else 'NO'}; tampered copy (1 byte appended to {victim}): "
            + (f"REFUSED exit {rc2} ({why2})" if refused else f"NOT refused, exit {rc2}")
            + f"; EQ-B-0143 still in Team B review ({KIT_REVIEW})")
    ok = not problems
    return {"status": "pass" if ok else "fail", "ok": ok, "problems": problems[:30], "counts": c, "guards": g,
            "manifest_sha256": sha, "code_hash": ch, "release": __version__, "tampered_file": victim,
            "tampered_exit": rc2, "exit": rc, "paths": {"kit": str(kit), "kit_tampered": str(tkit)},
            "reason": (f"FAIL, {len(problems)} problems: {'; '.join(problems[:3])}; " if problems else "") + text}


def probe_research_qa(data: str, out: str, as_of: str = AS_OF, **_) -> dict:
    """M24 (EQ-C-0166): ops.research_qa.demo_research_qa(<out>, data_dir=<data>, outputs_dir=<out>) (EQ-C-0163): the
    good note passes the gate and the altered note is refused. It reuses the demo home's run; never the shared outputs/."""
    try:
        from .research_qa import demo_research_qa
    except ImportError:
        return {"status": "pending", "pending": True,
                "reason": "pending: not landed (econquest.ops.research_qa.demo_research_qa, EQ-C-0163)"}
    outp = Path(out).resolve()
    r = demo_research_qa(outp, data_dir=Path(data).resolve(), outputs_dir=outp, as_of=as_of)
    probs = [str(x) for x in r.get("problems") or []]
    ok = bool(r.get("ok")) and not probs
    return {"status": "pass" if ok else "fail", "ok": ok, "problems": probs[:30],
            **{k: r.get(k) for k in ("passing", "refused", "archived", "archive_refusal", "agreement_refusal") if k in r},
            "reason": (f"FAIL, {len(probs)} problems: {'; '.join(probs[:3])}; " if probs else "") + str(r.get("summary") or "")}


def _assistant_probe(row: str, fn_name: str, data: str, out: str, as_of: str) -> dict:
    """M25-M27 (EQ-C-0174): econquest.assistant.demo_rows.<fn_name>(<out>, <data>) on <out>/assistant_demo (stub only)."""
    try:
        from ..assistant import demo_rows
        from ..validation import assistant_drafts, assistant_qa  # noqa: F401 - Team B's modules must be there too
        fn = getattr(demo_rows, fn_name)
    except (ImportError, AttributeError):
        return {"status": "pending", "pending": True,
                "reason": f"pending: not landed (econquest.assistant.demo_rows.{fn_name}, EQ-C-0174, or Team B's "
                          "validation.assistant_qa / assistant_drafts)"}
    r = fn(Path(out).resolve(), Path(data).resolve() if data else None, as_of=as_of)
    probs = [str(x) for x in r.get("problems") or []]
    ok = bool(r.get("ok")) and not probs
    return {**{k: v for k, v in r.items() if k not in ("ok", "problems", "summary")}, "status": "pass" if ok else "fail",
            "ok": ok, "problems": probs[:30], "reason": str(r.get("summary") or f"{row}: no summary")}


def probe_assistant_answer(data: str, out: str, as_of: str = AS_OF, **_) -> dict:
    return _assistant_probe("M25", "demo_answer", data, out, as_of)


def probe_assistant_refusal(data: str, out: str, as_of: str = AS_OF, **_) -> dict:
    return _assistant_probe("M26", "demo_refusals", data, out, as_of)


def probe_assistant_draft(data: str, out: str, as_of: str = AS_OF, **_) -> dict:
    return _assistant_probe("M27", "demo_draft", data, out, as_of)


PROBES = {"offline": probe_offline, "gate": probe_gate, "run": probe_run, "research": probe_research, "pack": probe_pack,
          "xlsx": probe_xlsx, "evidence": probe_evidence, "gui": probe_gui, "signoff": probe_signoff,
          "research_v2": probe_research_v2, "gui_plus": probe_gui_plus, "client_sandbox": probe_client_sandbox,
          "vendor_sim": probe_vendor_sim, "calendar": probe_calendar, "text_index": probe_text_index,
          "events": probe_events, "depth": probe_depth, "archive": probe_archive,
          "backtest_explainer": probe_backtest_explainer, "validator_kit": probe_validator_kit,
          "research_qa": probe_research_qa, "assistant_answer": probe_assistant_answer,
          "assistant_refusal": probe_assistant_refusal, "assistant_draft": probe_assistant_draft}
PLUS2_PROBES = (("M17", "text_index"), ("M18", "events"), ("M19", "depth"), ("M20", "archive"))


def probe_main(argv: list[str]) -> int:
    """python -m econquest.ops.demo probe NAME --data D --out O [--root R] [--as-of D] [--tests-from F]: one JSON line."""
    ap = argparse.ArgumentParser(prog="python -m econquest.ops.demo probe")
    ap.add_argument("name", choices=sorted(PROBES))
    ap.add_argument("--data", default=""); ap.add_argument("--out", default=""); ap.add_argument("--root", default="")
    ap.add_argument("--as-of", dest="as_of", default=AS_OF); ap.add_argument("--tests-from", dest="tests_from", default="")
    ap.add_argument("--paths", type=int, default=0)
    ap.add_argument("--rs-paths", dest="rs_paths", type=int, default=0); ap.add_argument("--rs-full", dest="rs_full", action="store_true")
    a = ap.parse_args(argv)
    try:
        r = PROBES[a.name](data=a.data, out=a.out, root=a.root, as_of=a.as_of, tests_from=a.tests_from, paths=a.paths,
                           rs_paths=a.rs_paths, rs_full=a.rs_full)
    except Exception as e:                                  # noqa: BLE001 - reported as a failed probe, never a traceback row
        r = {"ok": False, "reason": f"probe {a.name} raised {type(e).__name__}: {str(e)[:200]}"}
    print(JSON_MARK + json.dumps(r, default=str))
    return 0


# ---------------------------------------------------------------- the run
def netns_available() -> bool:
    if not shutil.which("unshare"):
        return False
    try:
        return subprocess.run(["unshare", "-rn", "true"], capture_output=True, timeout=10).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


class Demo:
    def __init__(self, tree: Path, dest: Path, *, fast: bool = False, zip_path: str | None = None,
                 tests_from: str | None = None, as_of: str = AS_OF, paths: int | None = 20000, rs_paths: int = 5000,
                 quick: bool = True, keep: bool = False, netns: bool | None = None, rs_full: bool = False, log=print,
                 data_src: str | None = None, only: set | None = None, rehearse_zips: str | None = None,
                 rehearse_full: bool = False):
        self.tree, self.dest = Path(tree).resolve(), Path(dest)
        self.data_src = str(Path(data_src).resolve()) if data_src else None    # --data: a copy of DIR instead of the MVP
        self.dataset: dict = {}                                                  # demo.json "dataset" (A-C-025)
        self.release_data: Path | None = None        # C-B-006: replication runs on the release inputs, never the MVP copy
        self.release_base: dict = {}
        self.mvp_desk_base: dict = {}
        self.fast, self.zip_path, self.tests_from = fast, zip_path, tests_from
        self.as_of, self.paths, self.rs_paths, self.quick, self.keep, self.log = as_of, paths, rs_paths, quick, keep, log
        self.netns = netns_available() if netns is None else netns
        self.rs_full = rs_full
        self.only = set(only) if only else None            # EQ-C-0166 --only: M1 plus these MVP+ rows (ONLY_ROWS)
        self.rehearse_zips, self.rehearse_full = rehearse_zips, rehearse_full     # M21
        self.zip_under_test: Path | None = None             # M21: --zips default (its folder) and --current
        self.steps: list[dict] = []
        self.rows: list[dict] = []
        self.plus_rows: list[dict] = []                     # MVP+ M11-M27 (EQ-C-0136, C-0148, C-0158, C-0166, C-0174), never in self.rows
        self.base_run: dict = {}                            # M3's base run figures, for the M12 what-if "before"
        self.real_steps = 0                                 # steps really run by Demo.sh (a stubbed sh leaves 0): EQ-C-0124
        self.tmp = Path(tempfile.mkdtemp(prefix="econquest-demo-"))
        self.home = self.tmp / "home"                       # $HOME for every step
        self.target = self.home / "econquest"               # ECONQUEST_HOME
        self.code_root = self.tree
        self.guard_dir = self.tmp / "guard"
        (self.dest / "logs").mkdir(parents=True, exist_ok=True)
        (self.dest / "evidence").mkdir(parents=True, exist_ok=True)
        self.guard_dir.mkdir(parents=True, exist_ok=True)
        (self.guard_dir / "sitecustomize.py").write_text(GUARD)
        self.home.mkdir(parents=True, exist_ok=True)

    @property
    def data(self) -> Path:
        return self.target / "data"

    @property
    def out(self) -> Path:
        return self.target / "outputs"

    @property
    def network(self) -> str:
        return ("private network namespace (unshare -rn, loopback only) + socket guard" if self.netns
                else "socket guard (non-loopback connect refused)")

    def env(self, extra: dict | None = None) -> dict:
        e = {k: v for k, v in os.environ.items() if k not in SECRET_ENV and k not in PROXY_ENV and not k.startswith("PYTEST")}
        e.update({"HOME": str(self.home), "ECONQUEST_HOME": str(self.target), "ECONQUEST_DEMO_OFFLINE": "1",
                  "PYTHONPATH": os.pathsep.join([str(self.guard_dir), str(self.code_root)]),
                  "PYTHONDONTWRITEBYTECODE": "1", "PYTHONUNBUFFERED": "1", "MPLBACKEND": "Agg",
                  "ECONQUEST_BACKUP_DEST": str(self.home / "econquest-backups" / "nightly"),
                  "ECONQUEST_BACKUP_DIR": str(self.home / "econquest-backups"), "ECONQUEST_NO_PROFILE": "1",
                  "ECONQUEST_INSTALL_NO_PROMPT": "1", "NO_PROXY": "*", "no_proxy": "*"})
        e.update(extra or {})
        return e

    def sh(self, name: str, argv: list[str], *, cwd: Path | None = None, timeout: int = 1800, env: dict | None = None) -> dict:
        """Run one step offline; log to logs/<name>.log; record its time."""
        cmd = (["unshare", "-rn"] if self.netns else []) + [str(a) for a in argv]
        t0 = time.time()
        log = self.dest / "logs" / f"{name}.log"
        self.real_steps += 1
        try:
            p = subprocess.run(cmd, cwd=str(cwd or self.target if (cwd or self.target).exists() else self.tmp),
                               env=self.env(env), capture_output=True, text=True, timeout=timeout)
            rc, text = p.returncode, (p.stdout or "") + ("\n--- stderr ---\n" + p.stderr if p.stderr else "")
        except subprocess.TimeoutExpired as e:
            rc, text = 124, f"timeout after {timeout}s\n{(e.stdout or '')!s}"
        secs = time.time() - t0
        log.write_text(f"$ {' '.join(cmd)}\n{text}")
        rec = {"name": name, "rc": rc, "seconds": round(secs, 1), "log": f"logs/{name}.log", "text": text}
        self.steps.append({k: v for k, v in rec.items() if k != "text"})
        self.log(f"  {name}: exit {rc} ({secs:.1f}s)")
        return rec

    def eq(self, name: str, *args: str, timeout: int = 1800) -> dict:
        return self.sh(name, [sys.executable, "-m", "econquest", "--data", str(self.data), "--out", str(self.out), *args],
                       timeout=timeout)

    def probe(self, name: str, timeout: int = 1800, **kw) -> tuple[dict, dict]:
        argv = [sys.executable, "-m", "econquest.ops.demo", "probe", name, "--data", str(self.data), "--out", str(self.out),
                "--root", str(kw.get("root") or self.code_root), "--as-of", self.as_of, "--paths", str(self.paths or 0)]
        if kw.get("tests_from"):
            argv += ["--tests-from", str(kw["tests_from"])]
        if name == "signoff":
            argv += ["--rs-paths", str(self.rs_paths)] + (["--rs-full"] if self.rs_full else [])
        env = dict(kw.get("env") or {})
        if not (Path(self.code_root) / "econquest" / "ops" / "demo.py").is_file():   # a --zip older than the demo
            env["PYTHONPATH"] = os.pathsep.join([str(self.guard_dir), str(self.tree)])
        rec = self.sh(f"probe-{name}", argv, timeout=timeout, env=env or None)
        res = {"ok": False, "reason": f"probe {name} gave no result (exit {rec['rc']}, see {rec['log']})"}
        for line in reversed(rec["text"].splitlines()):
            if line.startswith(JSON_MARK):
                res = json.loads(line[len(JSON_MARK):])
                break
        (self.dest / "evidence" / f"{name}.json").write_text(json.dumps(res, indent=1, default=str))
        return res, rec

    def keep_file(self, src: Path, name: str | None = None) -> str:
        """Copy an output into evidence/ (the temp home is removed at the end); the evidence path, or the missing name."""
        if src.is_file():
            dst = self.dest / "evidence" / (name or src.name)
            shutil.copy2(src, dst)
            return f"evidence/{dst.name}"
        return f"(missing {src.name})"

    def add(self, cid: str, status: str, evidence: str, reason: str, steps: list[dict]) -> None:
        self.rows.append(row(cid, status, evidence, reason, sum(s.get("seconds", 0) for s in steps)))
        self.log(f"{cid} {status}: {self.rows[-1]['reason'][:160]}")

    def add_plus(self, cid: str, status: str, evidence: str, reason: str, steps: list[dict]) -> None:
        """An MVP+ row (M11-M27): kept in self.plus_rows, never in the M1-M10 rows."""
        self.plus_rows.append(row(cid, status, evidence, reason, sum(s.get("seconds", 0) for s in steps)))
        self.log(f"{cid} (MVP+) {status}: {self.plus_rows[-1]['reason'][:160]}")

    # -------------------------------------------------- data (HO-20261025-A-C-025)
    def place_data(self, dest: Path, mvp_roots: list[Path]) -> dict:
        """Write the demo's data directory at `dest` (must not exist): a copy of --data DIR, or Team A's verified MVP
        dataset (ingestion.mvp_dataset.materialize) from the first root in `mvp_roots` that has data/mvp/. Raises
        (MvpError, OSError) instead of falling back to the shared data/."""
        if self.data_src:
            src = Path(self.data_src)
            if not src.is_dir():
                raise RuntimeError(f"--data {src} is not a folder")
            shutil.copytree(src, dest, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
            return {"source": "override", "path": str(src), "build_id": None, "dataset_sha256": None,
                    "label": f"copy of --data {src}"}
        from ..ingestion import mvp_dataset
        root = next((Path(r) for r in mvp_roots if (mvp_dataset.mvp_dir(Path(r)) / "manifest.json").is_file()), Path(mvp_roots[-1]))
        mvp_dataset.materialize(dest, root=root)            # verifies first; MvpError, never a fallback
        m = json.loads((mvp_dataset.mvp_dir(root) / "manifest.json").read_text(encoding="utf-8"))
        where = "installed home" if Path(root) == self.target else "tree"
        return {"source": "mvp", "path": str(mvp_dataset.mvp_dir(root)), "from": where, "build_id": m.get("built_utc"),
                "dataset_sha256": m.get("dataset_sha256"), "vintage_id": m.get("vintage_id"), "as_of": m.get("as_of"),
                "schema": m.get("schema"),
                "label": f"MVP dataset data/mvp ({where}) built {m.get('built_utc')}, sha256 {str(m.get('dataset_sha256'))[:12]}"}

    # -------------------------------------------------- M1
    def install(self) -> None:
        steps = []
        if self.fast:
            t0 = time.time()
            self.target.mkdir(parents=True, exist_ok=True)
            self.dataset = self.place_data(self.data, [self.tree])
            self.release_data = self.tmp / "release-data"        # C-B-006: the shared data/ (release inputs), a copy
            shutil.copytree(self.tree / "data", self.release_data, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "mvp"))
            self.out.mkdir(exist_ok=True)
            self.steps.append({"name": "copy-data", "rc": 0, "seconds": round(time.time() - t0, 1), "log": ""})
            off, rec = self.probe("offline")
            steps.append(rec)
            self.add("M1", "pending", "logs/probe-offline.log",
                     f"pending (fast mode): ran from the tree on the {self.dataset['label']}, no zip or install; network: {self.network}, {off.get('reason')}",
                     steps)
            return
        parts = []
        zp = Path(self.zip_path) if self.zip_path else self.tmp / "econquest-demo.zip"
        if not self.zip_path:
            rec = self.sh("build-zip", [sys.executable, str(self.tree / "scripts" / "build_release.py"), str(zp),
                                        "--source", str(self.tree)], cwd=self.tmp, timeout=1800)
            steps.append(rec)
            if rec["rc"]:
                self.add("M1", "fail", rec["log"], f"build_release.py exit {rec['rc']}", steps)
                raise RuntimeError("no release zip")
        self.zip_under_test = zp
        import zipfile
        unz = self.tmp / "unzipped"
        t0 = time.time()
        with zipfile.ZipFile(zp) as z:
            for n in z.namelist():
                if n.startswith("/") or ".." in Path(n).parts:
                    raise RuntimeError(f"unsafe path in {zp.name}: {n!r}")
            z.extractall(unz)
        src = unz / "econquest"
        for f in ("install.sh", "install.command"):
            if (src / f).exists():
                (src / f).chmod(0o755)
        self.steps.append({"name": "unzip", "rc": 0, "seconds": round(time.time() - t0, 1), "log": ""})
        # SEC-C-018 M8: the unzipped tree must refuse to run
        refuse = self.sh("unzipped-refuses", [sys.executable, "-m", "econquest", "runs"], cwd=src,
                         env={"PYTHONPATH": os.pathsep.join([str(self.guard_dir), str(src)]), "ECONQUEST_HOME": str(src)})
        steps.append(refuse)
        parts.append(("pass" if refuse["rc"] and "unzipped econquest release" in refuse["text"] else "fail",
                      "unzipped tree refuses to run" if refuse["rc"] else "unzipped tree ran (SEC-C-018 M8 broken)"))
        rec = self.sh("install", ["bash", str(src / "install.sh")], cwd=src, timeout=1800,
                      env={"ECONQUEST_INSTALL_SKIP_VENV": "1", "PYTHONPATH": str(self.guard_dir)})
        steps.append(rec)
        ok = rec["rc"] == 0 and (self.target / ".econquest-installed").is_file() and self.data.is_dir()
        parts.append(("pass" if ok else "fail", f"install.sh exit {rec['rc']}" + ("" if ok else " (no marker or data/)")))
        if ok:                                              # A-C-025: the installed seed data/ is set aside for the MVP data
            t0 = time.time()
            staged = self.tmp / "demo-data"
            self.dataset = self.place_data(staged, [self.target, self.tree])
            shutil.move(str(self.data), str(self.tmp / "installed-data"))
            self.release_data = self.tmp / "installed-data"      # C-B-006: the installed release data
            shutil.move(str(staged), str(self.data))
            self.steps.append({"name": "place-data", "rc": 0, "seconds": round(time.time() - t0, 1), "log": ""})
            parts.append(("pass", f"data: {self.dataset['label']}"))
        self.code_root = self.target
        self.out.mkdir(parents=True, exist_ok=True)
        start = self.sh("start", [sys.executable, "-m", "econquest", "--version"])
        helps = self.sh("start-help", [sys.executable, "-m", "econquest", "--help"])
        steps += [start, helps]
        parts.append(("pass" if start["rc"] == 0 and helps["rc"] == 0 else "fail",
                      f"started: {start['text'].strip().splitlines()[0] if start['text'].strip() else 'no output'}"))
        off, orec = self.probe("offline")
        steps.append(orec)
        parts.append(("pass" if off.get("ok") else "fail", f"network: {self.network}"))
        diffs = lock_differences(self.target / "requirements-lock.txt")
        parts.append(("pass", "pip step skipped offline (ECONQUEST_INSTALL_SKIP_VENV=1), packages from this Python"
                      + (f"; differs from the lock: {', '.join(diffs[:3])}" if diffs else "; all lock pins match")))
        st, why = combine(parts)
        self.add("M1", st, rec["log"], f"{zp.name}: {why}", steps)

    # -------------------------------------------------- M2-M10
    def run_all(self) -> None:
        self.log(f"econquest demo ({'fast' if self.fast else 'install'} mode), as of {self.as_of}; network: {self.network}")
        try:
            self.install()
        except Exception as e:                          # noqa: BLE001 - the rest is reported as not run
            if not any(r["id"] == "M1" for r in self.rows):
                self.add("M1", "fail", "logs/", f"install failed: {type(e).__name__}: {e}", [])
            for cid, _t in CRITERIA[1:] if not self.only else ():
                self.add(cid, "fail", "", "not run: M1 install failed", [])
            for cid, _t in PLUS_CRITERIA:
                if not self.only or cid in self.only:
                    self.add_plus(cid, "fail", "", "not run: M1 install failed", [])
            return
        if self.only:                                   # EQ-C-0166: M1 and the chosen M21-M27 rows only
            self.plus_blocks(((self.run_plus_day, tuple(c for c in ONLY_ROWS if c in self.only)),))
            return
        # M2
        g, grec = self.probe("gate")
        self.add("M2", "pass" if g.get("ok") else "fail", "evidence/gate.json",
                 g.get("reason", "") + (f"; data: {self.dataset['label']}" if self.dataset else ""), [grec])
        # M3 / M4
        pa = ["--paths", str(self.paths), "--stress-paths", str(self.paths)] if self.paths else []
        run = self.eq("run", "run", "--as-of", self.as_of, "--stress", "--no-paths", *pa)
        rs_scope = [] if self.rs_full else ["--scenario", *RS_SCENARIOS]
        rs = self.eq("reverse-stress", "reverse-stress", "--as-of", self.as_of, "--paths", str(self.rs_paths), *rs_scope)
        rel = self.release_data or self.data
        rep = self.sh("replicate", [sys.executable, "-m", "econquest", "--data", str(rel), "--out", str(self.out), "replicate",
                                    *(["--quick"] if self.quick else []), "--out", str(self.out / "replication")])
        r, prec = self.probe("run")
        self.base_run = {"metrics": r.get("metrics") or {}, "paths": r.get("paths"), "run_id": r.get("run_id")}
        so, srec = self.probe("signoff")
        for f in ("run_latest.json", "stress.json", "reverse_stress.json"):
            self.keep_file(self.out / f)
        rep_ev = self.keep_file(self.out / "replication" / "replication.md")
        rep_counts = {}
        try:
            rep_counts = json.loads((self.out / "replication" / "summary.json").read_text()).get("counts") or {}
        except (OSError, ValueError):
            pass
        self.release_base = release_base_summary(self.out / "replication", rel, self.quick)
        self.replication = (rep["rc"] == 0, f"Release base (shared data): replication {'--quick' if self.quick else 'full'} "
                            + (", ".join(f"{k} {v}" for k, v in sorted(rep_counts.items())) or f"exit {rep['rc']}")
                            + f" on the release inputs, R01-R51 {self.release_base['pins']['status']}; {self.release_base['pins_text']}")
        paths_txt = f"{self.paths:,} requested paths" if self.paths else "engine default paths"
        mvp_lab = f"MVP desk base (data/mvp {self.dataset.get('build_id')})" if self.dataset.get("source") == "mvp" else \
            f"desk base ({self.dataset.get('label', 'demo data')})"
        self.mvp_desk_base = {"label": mvp_lab, "run_paths": self.paths, **{k: so.get(k) for k in (
            "verdict", "as_of", "data", "paths", "stress_paths", "rs_paths", "base", "counts", "fails")},
            "evidence": "evidence/mvp-signoff/"}
        sdir = self.out / "mvp-signoff"
        if sdir.is_dir():
            shutil.copytree(sdir, self.dest / "evidence" / "mvp-signoff", dirs_exist_ok=True)
        st, why = combine([("pass" if run["rc"] == 0 else "fail", f"run exit {run['rc']}"),
                           ("pass" if r.get("ok") else "fail", f"{mvp_lab}, {paths_txt}: " + r.get("reason", "")),
                           ("pass" if so.get("ok") else "fail", f"{mvp_lab}: " + so.get("reason", "")),
                           ("pass" if self.replication[0] else "fail", self.replication[1])])
        self.add("M3", st, "evidence/run_latest.json; evidence/signoff.json; evidence/mvp-signoff/signoff.md; " + rep_ev, why,
                 [run, rep, prec, srec])
        st, why = combine([("pass" if run["rc"] == 0 else "fail", "stress library run" if run["rc"] == 0 else f"run --stress exit {run['rc']}"),
                           ("pass" if rs["rc"] == 0 else "fail", f"reverse-stress {self.rs_paths:,} paths, " + ("whole library" if self.rs_full else f"scenarios {' '.join(RS_SCENARIOS)} + all single factors") + f" exit {rs['rc']}"),
                           ("pass" if r.get("m4_ok") else "fail", r.get("m4_reason", ""))])
        self.add("M4", st, "evidence/stress.json; evidence/reverse_stress.json", why, [rs])
        # M5
        res, rrec = self.probe("pack")
        self.keep_file(self.out / "reports" / "mvp" / "check.json", "mvp_pack_check.json")
        self.add("M5", "pass" if res.get("ok") else "fail", "evidence/pack.json; evidence/mvp_pack_check.json",
                 res.get("reason", "") + " (B-0110 owns the content)", [rrec])
        # M6
        x, xrec = self.probe("xlsx")
        self.add("M6", "pending" if x.get("pending") else "pass" if x.get("ok") else "fail", "evidence/xlsx.json",
                 x.get("reason", ""), [xrec])
        # M7
        gui, gr = self.probe("gui", timeout=900)
        self.add("M7", "pass" if gui.get("ok") else "fail", "evidence/gui.json", gui.get("reason", ""), [gr])
        # M8
        ch = self.eq("change-verify", "change", "verify")
        lg = self.sh("review-ledger-verify", [sys.executable, "-m", "econquest.ingestion.ledger", "verify", "--data", str(self.data), "--json"])
        lgv = ledger_verify_part(lg)
        self.keep_file(self.dest / "logs" / "review-ledger-verify.log", "review_ledger_verify.log")
        ev, erec = self.probe("evidence", tests_from=self.tests_from)
        st, why = combine([("pass" if ch["rc"] == 0 else "fail", f"change verify exit {ch['rc']}"), lgv,
                           ("pending" if ev.get("pending") else "pass" if ev.get("ok") else "fail", ev.get("reason", ""))])
        self.add("M8", st, f"{ch['log']}; {lg['log']}; evidence/evidence.json", why, [ch, lg, erec])
        # M9: the day's jobs through the scheduled-job wrapper, in the temp home (no launchd, nothing sent)
        jobs = []
        for job, args in (("record", ["record", "--dry-run", "--no-mc"]), ("backup", ["backup", "--verify"]),
                          ("restore_drill", ["restore-drill"])):
            jobs.append(self.sh(f"job-{job}", [sys.executable, "-m", "econquest.ops.jobs", "--home", str(self.target),
                                               "--job", job, "--step", json.dumps([sys.executable, "-m", "econquest", *args])]))
        hd = self.eq("health-daily", "health", "--daily", "--no-deliver", "--backup-dest", str(self.home / "econquest-backups" / "nightly"))
        mon = {}
        try:
            mon = json.loads((self.out / "ops_monitor.json").read_text())
        except (OSError, ValueError):
            pass
        self.keep_file(self.out / "ops_monitor.json")
        lines = [f"{c.get('check')} {c.get('status')}" for c in mon.get("checks") or []]
        fails = [c for c in mon.get("checks") or [] if c.get("status") == "FAIL"]
        # EQ-C-0167: the record job here is a dry run and writes no row, so after the day's record slot (18:20 New York)
        # health --daily reports the missing row. That one FAIL is the simulation, not a fault; any other FAIL still fails.
        dry = [c for c in fails if c.get("check") == "record" and "no forecast record row" in str(c.get("detail", ""))]
        fails = [c for c in fails if c not in dry]
        hd_ok = hd["rc"] == 0 or (bool(dry) and not fails and bool(mon))
        jbad = [j["name"] for j in jobs if j["rc"]]
        st, why = combine([("fail" if jbad else "pass", f"jobs failed: {', '.join(jbad)}" if jbad else "record (dry run), backup, restore-drill jobs ok"),
                           ("pass" if hd_ok else "fail", f"health --daily {mon.get('status', 'exit ' + str(hd['rc']))}"
                            + (" (record slot passed: the dry-run record writes no row, expected in simulation)" if dry and hd_ok else "")
                            + (f" ({'; '.join(str(c.get('check')) + ': ' + str(c.get('detail', ''))[:80] for c in fails[:2])})" if fails else "")
                            + (f": {', '.join(lines)}" if lines and not fails else ""))])
        self.add("M9", st, "evidence/ops_monitor.json", why, jobs + [hd])
        # M10
        parts = []
        if self.tests_from:
            try:
                t = parse_tests(self.tests_from)
                n_bad = t["failures"] + t["errors"]
                parts.append(("pass" if t["tests"] and not n_bad else "fail",
                              f"suite {t['tests']} tests, {t['failures']} failed, {t['errors']} errors ({Path(self.tests_from).name})"))
            except (OSError, ValueError) as e:
                parts.append(("fail", f"--tests-from unreadable: {e}"))
        else:
            parts.append(("pending", "no --tests-from: suite log not given (the lead runs the full suite from a local copy)"))
        parts.append(("pass" if self.replication[0] else "fail", self.replication[1]))
        qs = self.tree / "docs" / "quickstart.md"
        parts.append(("pass", "docs/quickstart.md present") if qs.is_file() else ("pending", "docs/quickstart.md missing (C-0124)"))
        st, why = combine(parts)
        self.add("M10", st, (str(self.tests_from) if self.tests_from else "--tests-from") + "; docs/quickstart.md", why, [])
        # MVP+ (EQ-C-0136, EQ-C-0148): after M10, so nothing in M1-M10 sees the morning's run or the house-view files
        self.plus_blocks(((self.run_plus, ("M11", "M12", "M13")), (self.run_plus_ops, ("M14", "M15", "M16")),
                          (self.run_plus_views, tuple(c for c, _p in PLUS2_PROBES)), (self.run_plus_day, ONLY_ROWS)))

    def plus_blocks(self, blocks) -> None:
        for block, ids in blocks:
            try:
                block()
            except Exception as e:                      # noqa: BLE001 - an MVP+ crash never costs an MVP row
                done = {r["id"] for r in self.plus_rows}
                for cid in ids:
                    if cid not in done:
                        self.add_plus(cid, "fail", "logs/", f"MVP+ block raised {type(e).__name__}: {str(e)[:200]}", [])

    # -------------------------------------------------- MVP+ M11-M13 (EQ-C-0136)
    def desk_trade(self) -> dict:
        """The M12 trade: 10 $mm buy in the first desk position's country and instrument (data/portfolio.csv)."""
        import csv
        try:
            with open(self.data / "portfolio.csv", newline="", encoding="utf-8") as f:
                first = next(csv.DictReader(f))
            c, i = str(first.get("country") or "").strip(), str(first.get("asset_class") or "").strip()
            if c and i:
                return {"country": c, "instrument": i, "notional_mm": 10, "side": "buy"}
        except (OSError, StopIteration, ValueError):
            pass
        return {"country": "Brazil", "instrument": "Eurobond", "notional_mm": 10, "side": "buy"}

    def run_plus(self) -> None:
        ev = self.dest / "evidence"
        # M12 CLI: the what-if, with the positions/store files hashed around it
        trade = self.desk_trade()
        text = f"{trade['country']} {trade['instrument']} {trade['notional_mm']} {trade['side']}"
        h0 = state_hashes(self.data, self.out)
        wi = self.eq("whatif", "whatif", "--trade", text, "--as-of", self.as_of,
                     "--paths", str(self.paths or 100000), "--json")             # the M3 run's date and requested paths
        ch = hash_change(h0, state_hashes(self.data, self.out))
        try:
            wrep = json_payload(wi["text"])
        except ValueError:
            wrep = {}
        (ev / "whatif.json").write_text(json.dumps(wrep, indent=1, default=str))
        w_probs = check_whatif(wrep, self.base_run) if wrep else [f"no {WHATIF_SCHEMA} JSON on stdout"]
        # M13: Team B's research v2 check on the M5 pack (before the morning, whose notes list reads that pack)
        rv, rvrec = self.probe("research_v2")
        # M11 CLI: the morning view (runs today's base run when the stored one is not for today)
        mo = self.eq("morning", "morning", "--json")
        try:
            mrep = json_payload(mo["text"])
        except ValueError:
            mrep = {}
        mpath = self.tmp / "morning-cli.json"
        mpath.write_text(json.dumps(mrep, default=str), encoding="utf-8")
        (ev / "morning.json").write_text(json.dumps(mrep, indent=1, default=str))
        m_probs = check_morning(mrep) if mrep else [f"no {MORNING_SCHEMA} JSON on stdout"]
        # the GUI half of M11 and M12
        gp, grec = self.probe("gui_plus", timeout=1800, env={"ECONQUEST_DEMO_MORNING_JSON": str(mpath),
                                                             "ECONQUEST_DEMO_WHATIF_TRADE": json.dumps(trade)})
        g11 = gp.get("m11") or {"ok": False, "reason": "GUI probe gave no M11 result: " + str(gp.get("reason", ""))[:160]}
        g12 = gp.get("m12") or {"ok": False, "reason": "GUI probe gave no M12 result: " + str(gp.get("reason", ""))[:160]}
        st, why = combine([("pass" if mo["rc"] == 0 else "fail", f"morning --json exit {mo['rc']}"),
                           ("fail", "; ".join(m_probs)) if m_probs else ("pass", morning_text(mrep)),
                           ("pass" if g11.get("ok") else "fail", "GUI " + str(g11.get("reason", "")))])
        self.add_plus("M11", st, f"evidence/morning.json; evidence/gui_plus.json; {mo['log']}", why, [mo, grec])
        st, why = combine([("pass" if wi["rc"] == 0 else "fail", f"whatif --json exit {wi['rc']}"),
                           ("fail", "; ".join(w_probs)) if w_probs else ("pass", whatif_text(wrep)),
                           ("fail", f"files changed by the what-if: {ch}") if ch else
                           ("pass", "data/portfolio.csv, run_latest.json and store/ byte-identical before and after"),
                           ("pass" if g12.get("ok") else "fail", "GUI " + str(g12.get("reason", "")))])
        self.add_plus("M12", st, f"evidence/whatif.json; evidence/gui_plus.json; {wi['log']}", why, [wi])
        rst = rv.get("status") if rv.get("status") in STATUSES else "pass" if rv.get("ok") else "fail"
        self.add_plus("M13", rst, "evidence/research_v2.json", rv.get("reason", ""), [rvrec])

    # -------------------------------------------------- MVP+ M14-M16 (EQ-C-0148)
    def vendor_sandbox(self) -> Path:
        """M15's sandbox: <dest>/sandbox/vendor-sim, or under the temp folder when dest is inside the tree or the
        installed home (Team A's guard refuses repo paths)."""
        if not (_inside(self.dest, self.tree) or _inside(self.dest, self.target)):
            p = self.dest / "sandbox" / "vendor-sim"
        else:
            p = self.tmp / "vendor-sim"
        return p if not p.exists() else p.with_name(f"{p.name}-{utc_stamp()}")

    def run_plus_ops(self) -> None:
        ev = self.dest / "evidence"
        # M14: the client sandbox, every write (outbox and action log) inside the demo home
        alog = self.out / "store" / "actions.jsonl"
        env = {"ECONQUEST_ACTION_LOG": str(alog)}
        n0 = len(_jsonl(alog))
        cs, csrec = self.probe("client_sandbox", timeout=900, env=env)
        if cs.get("pending"):
            self.add_plus("M14", "pending", "evidence/client_sandbox.json", cs.get("reason", ""), [csrec])
        else:
            n1 = len(_jsonl(alog))
            ref = self.sh("client-outbox-refusal", [sys.executable, "-m", "econquest", "--data", str(self.data), "--out",
                                                    str(self.out), "client-outbox", "build"], timeout=600, env=env)
            new = _jsonl(alog)[n1:]
            logged = [r for r in new if r.get("command") == "client-outbox build" and r.get("outcome") == "error"]
            self.keep_file(alog, "client_sandbox_actions.jsonl")
            st, why = combine([("pass" if cs.get("ok") else "fail", cs.get("reason", "")),
                               ("pass" if ref["rc"] and "refused" in ref["text"] else "fail",
                                f"client-outbox build without --sandbox: exit {ref['rc']}" + (", refused" if "refused" in ref["text"] else ", NOT refused")),
                               ("pass" if logged else "fail",
                                f"refusal logged in the demo home's store ({len(new)} new rows in outputs/store/actions.jsonl, "
                                f"{n1 - n0} from demo_sandbox)" if logged else
                                f"no client-outbox build error row in the demo home's {alog.name} ({len(new)} new rows)")])
            self.add_plus("M14", st, f"evidence/client_sandbox.json; evidence/client_sandbox_actions.jsonl; {ref['log']}", why,
                          [csrec, ref])
        # M15: the vendor simulation on a sandbox outside the tree, desk check on the demo home
        sbx = self.vendor_sandbox()
        vs, vsrec = self.probe("vendor_sim", timeout=1200, env={"ECONQUEST_DEMO_VENDOR_SANDBOX": str(sbx)})
        reps = sorted(sbx.glob("*.md")) if _inside(sbx, self.dest) else []
        evid = "evidence/vendor_sim.json" + "".join(f"; {r.relative_to(self.dest).as_posix()}" for r in reps[:1])
        self.add_plus("M15", vs.get("status") if vs.get("status") in STATUSES else "pass" if vs.get("ok") else "fail", evid,
                      vs.get("reason", ""), [vsrec])
        # M16: Team B's calendar rehearsal and its page, written under the demo home's outputs/
        ca, carec = self.probe("calendar", timeout=1200)
        cdir = self.out / "calendar_rehearsal"
        if cdir.is_dir():
            shutil.copytree(cdir, ev / "calendar_rehearsal", dirs_exist_ok=True)
        self.add_plus("M16", ca.get("status") if ca.get("status") in STATUSES else "pass" if ca.get("ok") else "fail",
                      "evidence/calendar.json; evidence/calendar_rehearsal/", ca.get("reason", ""), [carec])

    # -------------------------------------------------- MVP+ M17-M20 (EQ-C-0158)
    def run_plus_views(self) -> None:
        """M17 text index, M18 events view, M19 depth views and heatmap, M20 research archive: each probe on the demo
        home (<home>/data, <home>/outputs), with the installed code in zip mode. Code that predates a row (no module,
        or an installed demo.py without the probe) leaves it "pending: not landed"."""
        ev = self.dest / "evidence"
        keep = {"text_index": ("text_index",), "events": ("events_view",), "depth": ("depth_views", "heatmap")}
        # (the archive's 0555 version folders stay in the temp home; evidence/archive.json has its summary)
        for cid, name in PLUS2_PROBES:
            res, rec = self.probe(name, timeout=1200)
            if "status" not in res and "invalid choice" in rec.get("text", ""):
                res = {"status": "pending", "pending": True,
                       "reason": f"pending: not landed (the installed code's demo has no {name} probe)"}
                (ev / f"{name}.json").write_text(json.dumps(res, indent=1))
            st = res.get("status") if res.get("status") in STATUSES else "pass" if res.get("ok") else "fail"
            evid = f"evidence/{name}.json"
            for sub in keep.get(name, ()) if st != "pending" else ():
                if (self.out / sub).is_dir():
                    shutil.copytree(self.out / sub, ev / sub, dirs_exist_ok=True, ignore=shutil.ignore_patterns("synthetic_corpus"))
                    evid += f"; evidence/{sub}/"
            self.add_plus(cid, st, evid, res.get("reason", ""), [rec])

    # -------------------------------------------------- MVP+ M21-M24 (EQ-C-0166)
    def full_data(self) -> Path:
        """M21 and M23's data: a full release data folder with data/mvp. Install mode: the installed release data
        (it has mvp/); --fast: a copy of that folder (the tree's data/ without mvp/) plus the tree's data/mvp."""
        rel = self.release_data
        if rel is not None and (Path(rel) / "mvp" / "manifest.json").is_file():
            return Path(rel)
        dst = self.tmp / "full-data"
        if not dst.exists():
            src = Path(rel) if rel is not None and Path(rel).is_dir() else self.tree / "data"
            ign = shutil.ignore_patterns("__pycache__", "*.pyc")
            shutil.copytree(src, dst, ignore=ign, symlinks=False)
            mvp = self.tree / "data" / "mvp"
            if mvp.is_dir() and not (dst / "mvp").exists():
                shutil.copytree(mvp, dst / "mvp", ignore=ign)
        return dst

    def rehearse_source(self) -> tuple[Path | None, Path | None, str]:
        """M21's (--zips folder, --current zip, where the folder came from)."""
        cur = self.zip_under_test if self.zip_under_test is not None and Path(self.zip_under_test).is_file() else None
        if self.rehearse_zips:
            return Path(self.rehearse_zips), cur, "--rehearse-zips"
        if os.environ.get(ZIPS_ENV):
            return Path(os.environ[ZIPS_ENV]), cur, f"${ZIPS_ENV}"
        if cur is not None:
            return cur.parent, cur, "the folder of the zip under test"
        return None, None, f"no zips folder (--fast: pass --rehearse-zips DIR or set ${ZIPS_ENV})"

    def run_rehearsal(self) -> None:
        """M21: `econquest rehearse --out <dest>/rehearsal [--quick] [--zips DIR --current ZIP]` with the installed code
        (the tree's in --fast) on full_data(); PASS = exit 0. Missing upgrade zips are listed, never failed."""
        out = self.dest / "rehearsal"
        if out.exists():
            shutil.rmtree(out, ignore_errors=True)
        zips, cur, where = self.rehearse_source()
        data = self.full_data()
        argv = [sys.executable, "-m", "econquest", "--data", str(data), "--out", str(self.out), "rehearse", "--out", str(out)]
        argv += [] if self.rehearse_full else ["--quick"]
        if zips is not None:
            argv += ["--zips", str(zips)] + (["--current", str(cur)] if cur is not None else [])
        tmpd = self.tmp / "rehearsal-tmp"
        tmpd.mkdir(parents=True, exist_ok=True)
        rec = self.sh("rehearse", argv, timeout=3600, env={"TMPDIR": str(tmpd), "TMP": str(tmpd), "TEMP": str(tmpd)})
        text = rec.get("text", "")
        if rec["rc"] and "invalid choice: 'rehearse'" in text:
            self.add_plus("M21", "pending", rec["log"], "pending: not landed (the installed code has no econquest rehearse, "
                          "EQ-C-0168)", [rec])
            return
        rep = _kit_report(out / "rehearsal.json")
        line = str(rep.get("summary") or "").replace("[rehearsal] ", "")
        if not line:
            line = next((ln.replace("[rehearsal] ", "") for ln in reversed(text.splitlines()) if "M21" in ln),
                        "no rehearsal.json written")
        up = rep.get("upgrades") if isinstance(rep.get("upgrades"), dict) else None
        if zips is not None:
            found = ", ".join(up.get("found") or []) if up else "?"
            missing = ", ".join(up.get("missing") or []) if up else "?"
            ztxt = (f"zips folder {zips} ({where}): upgrade zips found {found or 'none'}, missing {missing or 'none'}"
                    + (" (listed by Team A's rehearsal, not a failure)" if up and up.get("missing") else ""))
        else:
            try:
                from ..ingestion.rehearsal import SHIPPED
                shipped = ", ".join(SHIPPED)
            except (ImportError, AttributeError):
                shipped = "every shipped zip"
            ztxt = f"upgrade rows not run: {where}; upgrade zips missing: {shipped} (not a failure)"
        mode = "full" if self.rehearse_full else "--quick"
        st = "pass" if rec["rc"] == 0 else "fail"
        why = (f"rehearse {mode} exit {rec['rc']}: {line}; {ztxt}; data {data.name}/ (with mvp/), copies only")
        evid = (f"{(out / 'rehearsal.md').relative_to(self.dest).as_posix()}; " if (out / "rehearsal.md").is_file() else "") + rec["log"]
        self.add_plus("M21", st, evid, why, [rec])

    def run_plus_day(self) -> None:
        """M21 rehearsal, M22 backtest explainer, M23 validator kit, M24 research QA, M25-M27 the desk assistant (each
        on the demo home or dest)."""
        sel = self.only or set(ONLY_ROWS)
        if "M21" in sel:
            self.run_rehearsal()
        ev = self.dest / "evidence"
        envs = {"backtest_explainer": {EXPLAINER_DATA_ENV: str(self.tree / "data" if self.fast else self.data)},
                "validator_kit": {KIT_DATA_ENV: str(self.full_data()) if "M23" in sel else "",
                                  **({SHARED_TREE_ENV: "1"} if self.fast else {})}}
        keep = {"backtest_explainer": (("backtest_explainer_view", None), ("backtest_explainer", None)),
                "validator_kit": ((f"{KIT_DIR}/kit", ("report.md", "report.json")),
                                  (f"{KIT_DIR}/kit-tampered", ("report.md", "report.json"))),
                "research_qa": (("research_qa", None),),
                **{n: (("assistant_demo/report", None),) for _c, n in PLUS4_PROBES}}
        for cid, name in PLUS3_PROBES + PLUS4_PROBES:
            if cid not in sel:
                continue
            res, rec = self.probe(name, timeout=3600, env=envs.get(name))
            if "status" not in res and "invalid choice" in rec.get("text", ""):
                res = {"status": "pending", "pending": True,
                       "reason": f"pending: not landed (the installed code's demo has no {name} probe)"}
                (ev / f"{name}.json").write_text(json.dumps(res, indent=1))
            st = res.get("status") if res.get("status") in STATUSES else "pass" if res.get("ok") else "fail"
            evid = f"evidence/{name}.json"
            for sub, files in keep.get(name, ()) if st != "pending" else ():
                src = self.out / sub
                if not src.is_dir():
                    continue
                dst = ev / sub
                if files is None:
                    shutil.copytree(src, dst, dirs_exist_ok=True)
                else:                                   # the kit: reports only (room and work/ are NDA-only)
                    dst.mkdir(parents=True, exist_ok=True)
                    for f in files:
                        if (src / f).is_file():
                            shutil.copy2(src / f, dst / f)
                evid += f"; evidence/{sub}/"
            self.add_plus(cid, st, evid, res.get("reason", ""), [rec])

    def finish(self, started: dt.datetime, seconds: float) -> tuple[Path, Path, str]:
        order = {c: i for i, (c, _t) in enumerate(CRITERIA + PLUS_CRITERIA)}
        self.rows.sort(key=lambda r: order[r["id"]])
        self.plus_rows.sort(key=lambda r: order[r["id"]])
        md = self.dest / "demo.md"
        line = summary_line(self.rows, seconds, md)
        if self.only:
            line = f"econquest demo --only {','.join(sorted(self.only, key=lambda c: int(c[1:])))} (M2-M10 not run): " + line[len("econquest demo: "):]
        doc = {"schema": SCHEMA, "ticket": TICKET, "mode": "fast" if self.fast else "install", "as_of": self.as_of,
               "started_utc": started.strftime("%Y-%m-%dT%H:%M:%SZ"), "seconds": round(seconds, 1),
               "network": self.network, "paths": self.paths, "reverse_stress_paths": self.rs_paths, "reverse_stress_scope": "full" if self.rs_full else list(RS_SCENARIOS),
               "replication": "quick" if self.quick else "full", "tests_from": self.tests_from,
               "zip": self.zip_path or ("" if self.fast else "built from the tree"),
               "dataset": self.dataset or None,
               "release_base": self.release_base or None, "mvp_desk_base": self.mvp_desk_base or None,
               "rows": self.rows, "steps": self.steps, "summary": line, "exit_code": self.exit_code(),
               "only": sorted(self.only, key=lambda c: int(c[1:])) if self.only else None,
               "plus_ticket": PLUS_TICKET, "plus_rows": self.plus_rows,
               "plus_summary": plus_line(self.plus_rows) if self.plus_rows else "",
               "real_run": self.real_steps > 0}
        (self.dest / "demo.json").write_text(json.dumps(doc, indent=1, default=str) + "\n")
        md.write_text(render_md(doc))
        return self.dest / "demo.json", md, line

    def exit_code(self) -> int:
        """M1-M10 only; with --only: M1 not failed and every chosen MVP+ row passing."""
        if not self.only:
            return exit_code(self.rows)
        m1 = [r for r in self.rows if r["id"] == "M1"]
        chosen = [r for r in self.plus_rows if r["id"] in self.only]
        return 0 if m1 and m1[0]["status"] != "fail" and chosen and all(r["status"] == "pass" for r in chosen) else 1

    def cleanup(self) -> None:
        if self.keep:
            self.log(f"temp home kept: {self.tmp}")
        else:
            for d, _dirs, _files in os.walk(self.tmp):     # M20: the archive's version folders are 0555
                try:
                    os.chmod(d, 0o700)
                except OSError:
                    pass
            shutil.rmtree(self.tmp, ignore_errors=True)


def _jsonl(path: Path) -> list[dict]:
    """The JSON rows of a .jsonl file ([] when missing; unreadable lines skipped)."""
    try:
        lines = Path(path).read_text(encoding="utf-8").splitlines()
    except OSError:
        return []
    out = []
    for ln in lines:
        try:
            r = json.loads(ln)
        except ValueError:
            continue
        if isinstance(r, dict):
            out.append(r)
    return out


def ledger_verify_part(rec: dict) -> tuple[str, str]:
    """M8 part from `python -m econquest.ingestion.ledger verify --json` (HO-20261025-A-C-024): pass when the review
    ledger's chain is intact (no ledger is intact: 0 rows), fail on a break or no result."""
    text = rec.get("text", "")
    try:
        st = json.loads(text[text.index("{"):text.rindex("}") + 1])
    except ValueError:
        return "fail", f"review ledger verify gave no result (exit {rec.get('rc')})"
    if st.get("ok") and rec.get("rc") == 0:
        return "pass", (f"review ledger chain verifies ({st.get('rows', 0)} rows, {st.get('chained', 0)} chained)"
                        if st.get("exists") else "review ledger: none yet (0 rows), ok")
    return "fail", "review ledger BROKEN: " + "; ".join(str(x) for x in (st.get("problems") or [])[:2])


def _num_cell(v) -> str:
    return f"{v:.2f}" if _finite(v) else "-"


def base_sections(doc: dict) -> list[str]:
    """demo.md: the two bases side by side, each figure with its path count (C-B-006)."""
    L = []
    rb, mb = doc.get("release_base"), doc.get("mvp_desk_base")
    names = (("VaR99", "var99_mm"), ("ES99", "es99_mm"), ("EL", "expected_loss_mm"), ("L-VaR99", "lvar99_mm"))
    if rb:
        L += ["", f"## {rb['label']}", "", f"Data {rb.get('data')}; {rb.get('pins_text')}; replication {rb.get('replication')}: "
              + ", ".join(f"{k} {v}" for k, v in sorted((rb.get("counts") or {}).items())) + f"; R01-R51 {rb['pins']['status']}.", "",
              "| Metric ($mm) | Check | Documented | Paths (documented) | Recomputed | Paths (recomputed) | Status |",
              "|---|---|---|---|---|---|---|"]
        for lab, k in names:
            f = (rb.get("figures") or {}).get(k)
            if f:
                rp = f"{f['reported_paths']:,} requested" if f.get("reported_paths") else "-"
                L.append(f"| {lab} | {f['id']} | {_num_cell(f['reported'])} | {rp} | "
                         f"{_num_cell(f['recomputed'])} | {f['recomputed_paths']:,} requested | {f['status']} |")
    if mb:
        b = mb.get("base") or {}
        L += ["", f"## {mb['label']}", "", f"Team B mvp_signoff (EQ-B-0111): **{mb.get('verdict')}**, as_of {mb.get('as_of')}, "
              f"{mb.get('paths') or 0:,} requested paths (stress {mb.get('stress_paths') or 0:,}, reverse stress "
              f"{mb.get('rs_paths') or 0:,}); data {mb.get('data')}. Team B's own sign-off is at 100,000 requested "
              "(131,072 simulated) paths, so figures here differ by Monte Carlo error.", "",
              "| Metric ($mm) | Value | Paths |", "|---|---|---|"]
        L += [f"| {lab} | {_num_cell(b.get(k))} | {mb.get('paths') or 0:,} requested |" for lab, k in names]
    return L


def _md_cell(v) -> str:
    return str(v).replace("|", "\\|").replace("\n", " ")


def render_md(doc: dict) -> str:
    L = [f"# econquest demo: MVP acceptance ({doc['ticket']})", "",
         f"Mode **{doc['mode']}**, as of {doc['as_of']}, started {doc['started_utc']}, {doc['seconds']:.0f}s. "
         f"Network: {doc['network']}. Paths: {doc['paths'] or 'engine default'}; reverse stress {doc['reverse_stress_paths']}; "
         f"replication {doc['replication']}.",
         *([f"Data: {doc['dataset'].get('label')}."] if doc.get("dataset") else []), "", f"**{doc['summary']}**", "",
         "| # | Criterion | Status | Evidence | Reason | s |", "|---|---|---|---|---|---|"]
    L += [f"| {r['id']} | {_md_cell(r['title'])} | {r['status']} | {_md_cell(r['evidence'])} | {_md_cell(r['reason'])} | {r['seconds']:.0f} |"
          for r in doc["rows"]]
    if doc.get("plus_rows"):                            # EQ-C-0136, EQ-C-0148: beside the MVP, never part of it
        L += ["", f"## MVP+ ({plus_range(doc['plus_rows'])}, {doc.get('plus_ticket', PLUS_TICKET)}): not part of \"MVP reached\"", "",
              f"**{doc.get('plus_summary', '')}**", "",
              "| # | Criterion | Status | Evidence | Reason | s |", "|---|---|---|---|---|---|"]
        L += [f"| {r['id']} | {_md_cell(r['title'])} | {r['status']} | {_md_cell(r['evidence'])} | {_md_cell(r['reason'])} | {r['seconds']:.0f} |"
              for r in doc["plus_rows"]]
    L += base_sections(doc)
    L += ["", "## Steps", "", "| Step | Exit | s | Log |", "|---|---|---|---|"]
    L += [f"| {s['name']} | {s['rc']} | {s['seconds']:.1f} | {s['log']} |" for s in doc["steps"]]
    L += ["", "Checklist: team/mvp-checklist.md. Evidence files are copies under evidence/; the temp home is removed.", ""]
    return "\n".join(L)


def run_demo(args, tree: Path | None = None, log=print) -> int:
    tree = Path(tree or Path(__file__).resolve().parents[2])
    started = dt.datetime.now(dt.timezone.utc)
    dest = Path(args.dest) if getattr(args, "dest", None) else Path(args.out) / "demo" / utc_stamp(started)
    if getattr(args, "tests_from", None) and not Path(args.tests_from).is_file():
        raise SystemExit(f"demo: --tests-from {args.tests_from} is not a file")
    if getattr(args, "zip", None) and not Path(args.zip).is_file():
        raise SystemExit(f"demo: --zip {args.zip} is not a file")
    if getattr(args, "demo_data", None) and not Path(args.demo_data).is_dir():
        raise SystemExit(f"demo: --data {args.demo_data} is not a folder")
    only = parse_only(getattr(args, "only", None))
    d = Demo(tree, dest, fast=args.fast, zip_path=args.zip, tests_from=str(Path(args.tests_from).resolve()) if args.tests_from else None,
             as_of=args.as_of, paths=args.paths or None, rs_paths=args.rs_paths, quick=not args.full_replication,
             keep=args.keep, rs_full=getattr(args, "rs_full", False), log=log, data_src=getattr(args, "demo_data", None),
             only=only, rehearse_zips=getattr(args, "rehearse_zips", None), rehearse_full=getattr(args, "rehearse_full", False))
    t0 = time.time()
    try:
        d.run_all()
    finally:
        d.cleanup()
    j, _md, line = d.finish(started, time.time() - t0)
    print(line)
    if d.plus_rows:
        print(plus_line(d.plus_rows))
    log("tracker: skipped (--only run: M2-M10 not run)" if only else
        tracker_update(d, j, tree, no_tracker=getattr(args, "no_tracker", False)))
    return d.exit_code()


def parse_only(text) -> set | None:
    """--only "M21-M27" or "M21,M23": the chosen rows (ONLY_ROWS only); None when not given."""
    if not text:
        return None
    ids: set = set()
    for part in str(text).replace(" ", "").split(","):
        m = re.fullmatch(r"M(\d+)(?:-M?(\d+))?", part, flags=re.I)
        if not m:
            raise SystemExit(f"demo: --only {text!r}: use row ids like M21-M27 or M21,M23")
        a, b = int(m.group(1)), int(m.group(2) or m.group(1))
        ids |= {f"M{i}" for i in range(min(a, b), max(a, b) + 1)}
    bad = sorted(ids - set(ONLY_ROWS), key=lambda c: int(c[1:]))
    if bad:
        raise SystemExit(f"demo: --only {', '.join(bad)}: only {', '.join(ONLY_ROWS)} run without M2-M10")
    return ids


def tracker_update(d: "Demo", demo_json: Path, tree: Path, *, no_tracker: bool = False) -> str:
    """EQ-C-0124: write the status block of <tree>/team/mvp-checklist.md, from a real run only. Skipped with
    --no-tracker, when no step really ran (Demo.sh stubbed: a test), or under pytest on the package's own tree."""
    if no_tracker:
        return "tracker: skipped (--no-tracker)"
    if d.real_steps <= 0:
        return "tracker: skipped (no step really ran: stubbed run)"
    if os.environ.get("PYTEST_CURRENT_TEST") and Path(tree).resolve() == Path(__file__).resolve().parents[2]:
        return "tracker: skipped (test run on the package tree)"
    from .mvp_tracker import CHECKLIST, update_checklist
    doc = json.loads(Path(demo_json).read_text(encoding="utf-8"))
    try:
        return update_checklist(Path(tree) / CHECKLIST, doc, Path(demo_json), root=Path(tree))[1]
    except OSError as e:
        return f"tracker: not written ({type(e).__name__}: {e})"


def cmd_demo(args) -> None:
    code = run_demo(args)
    if code:
        sys.exit(code)


def register(sub) -> None:
    """`econquest demo`, added by cli.main (EQ-C-0121)."""
    p = sub.add_parser("demo", help="MVP acceptance run (team/mvp-checklist.md M1-M10): build the zip, install it into a temp home "
                       "offline, run, stress, reverse stress, replication, research pack, xlsx, GUI smoke, change verify and "
                       "evidence, daily jobs in simulation; writes <out>/demo/<UTC>/demo.json and demo.md; exit 0 only when every row passes. "
                       "MVP+ rows M11-M13 (morning, what-if, research v2; EQ-C-0136) and M14-M16 (client sandbox, vendor simulation, "
                       "calendar rehearsal; EQ-C-0148), M17-M20 (text index, events view, depth views and heatmap, research "
                       "archive; EQ-C-0158) and M21-M24 (real-data day rehearsal, backtest explainer, validator replication "
                       "kit, research QA; EQ-C-0166) and M25-M27 (assistant answer, refusals, draft to archive; "
                       "EQ-C-0174) are reported beside them, never in the exit code")
    p.add_argument("--fast", action="store_true", help="skip the zip and install: run the tree's code on the MVP dataset (M1 pending)")
    p.add_argument("--data", dest="demo_data", metavar="DIR",
                   help="run M2-M10 on a copy of DIR instead of Team A's MVP dataset data/mvp (default; HO-20261025-A-C-025)")
    p.add_argument("--zip", help="install this release zip instead of building one from the tree")
    p.add_argument("--tests-from", help="pytest junit XML or text summary of the full suite (M10, and the M8 evidence bundle)")
    p.add_argument("--as-of", default=AS_OF, help=f"model date of the run (default {AS_OF})")
    p.add_argument("--paths", type=int, default=20000, help="requested Monte Carlo paths for the base and stress runs (default 20000; 0 = engine default)")
    p.add_argument("--rs-paths", type=int, default=5000, help="paths per reverse-stress run (default 5000)")
    p.add_argument("--rs-full", action="store_true", help="reverse stress over the whole scenario library (default: A, B, C and every single factor)")
    p.add_argument("--full-replication", action="store_true", help="full replication instead of replicate --quick")
    p.add_argument("--keep", action="store_true", help="keep the temp home (path printed)")
    p.add_argument("--dest", help="folder for demo.json, demo.md, logs/ and evidence/ (default <out>/demo/<UTC>)")
    p.add_argument("--only", metavar="ROWS",
                   help="run M1 (install) and only these MVP+ rows: M21-M27 or a comma list of them (EQ-C-0166, "
                        "EQ-C-0174); M2-M10 "
                        "are not run, the exit code is M1 plus these rows, and the tracker is not written")
    p.add_argument("--rehearse-zips", metavar="DIR",
                   help=f"M21: folder of shipped econquest-macos-<v>.zip files for the upgrade rows (default ${ZIPS_ENV}, "
                        "else the folder holding the zip under test; none in --fast)")
    p.add_argument("--rehearse-full", action="store_true", help="M21: run the rehearsal without --quick (about 50 s more)")
    p.add_argument("--no-tracker", action="store_true",
                   help="do not write the status block in team/mvp-checklist.md (for tests; a stubbed run never writes it)")
    p.set_defaults(fn=cmd_demo)


if __name__ == "__main__":
    if len(sys.argv) > 1 and sys.argv[1] == "probe":
        sys.exit(probe_main(sys.argv[2:]))
    print("usage: econquest demo [...] (python -m econquest.ops.demo probe NAME is internal)", file=sys.stderr)
    sys.exit(2)
