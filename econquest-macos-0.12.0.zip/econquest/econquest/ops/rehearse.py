"""`econquest rehearse`: the real-data day rehearsal, demo row M21 (EQ-C-0168, HO-20261026-A-C-016).

    econquest rehearse [--zips DIR] [--current ZIP] [--quick] [--keep] [--json] [--out DIR]

A thin wrapper over Team A's econquest.ingestion.rehearsal.main (EQ-A-0138, runbook docs/runbooks/A-real-data-day.md).
The rehearsal works on copies in a temporary folder and never writes data/ or data/mvp (its row Z1 re-hashes them),
so there is no run gate. The top-level --data is the folder it copies. The report (rehearsal.json with every row,
rehearsal.md with the table and the M21 line) is written by rehearsal.main's own --out, which this command always
passes: <outputs>/rehearsal/<UTC time>/ unless --out DIR is given. Exit code: the rehearsal's (0 = M21 PASS).
"""
from __future__ import annotations

import datetime as dt
import sys
from pathlib import Path

TICKET = "EQ-C-0168"


def default_out(outputs: str | Path, now: dt.datetime | None = None) -> Path:
    """<outputs>/rehearsal/<UTC time>/, with -2, -3 ... when a folder of that second already holds a report."""
    stamp = (now or dt.datetime.now(dt.timezone.utc)).strftime("%Y%m%dT%H%M%SZ")
    base = Path(outputs).expanduser() / "rehearsal" / stamp
    d, n = base, 1
    while d.exists() and any(d.iterdir()):
        n += 1
        d = base.with_name(f"{stamp}-{n}")
    return d


def rehearsal_argv(a, now: dt.datetime | None = None) -> list[str]:
    out = Path(a.rehearse_out).expanduser() if a.rehearse_out else default_out(a.out, now)
    argv = ["run", "--data", str(a.data), "--out", str(out)]
    if a.zips:
        argv += ["--zips", a.zips]
    if a.current:
        argv += ["--current", a.current]
    return argv + ["--quick"] * bool(a.quick) + ["--keep"] * bool(a.keep) + ["--json"] * bool(a.json)


def run_from_args(a) -> int:
    from ..ingestion.rehearsal import main
    return int(main(rehearsal_argv(a)) or 0)


def register(sub) -> None:
    p = sub.add_parser("rehearse", help="real-data day rehearsal (demo row M21, Team A's econquest.ingestion.rehearsal): "
                                        "replays the recorded pulls and SYNTHETIC failure modes, and with --zips the "
                                        "upgrade from every shipped zip, on copies; never writes data/ or data/mvp; "
                                        "report in --out (default <outputs>/rehearsal/<UTC>/); exit 0 = M21 PASS")
    p.add_argument("--zips", help="folder with the shipped econquest-macos-<v>.zip files (and .sha256): run the upgrade rows")
    p.add_argument("--current", help="release zip of the current tree (default: built with scripts/build_release.py)")
    p.add_argument("--quick", action="store_true", help="leave out the two rows that rebuild data/mvp on a copy")
    p.add_argument("--keep", action="store_true", help="keep the rehearsal's temporary folder (its path is printed)")
    p.add_argument("--json", action="store_true", help="also print the rows as JSON at the end (always in rehearsal.json)")
    p.add_argument("--out", dest="rehearse_out", metavar="DIR",
                   help="folder for rehearsal.json and rehearsal.md (default <outputs>/rehearsal/<UTC time>/)")

    def _fn(a):
        code = run_from_args(a)
        if code:
            sys.exit(code)
    p.set_defaults(fn=_fn)
