"""Sam's open items (EQ-C-0074): one list of everything waiting on the operator, read from the ledgers that already
exist. Nothing here creates a store; the only write is a batch attestation, which goes into Team A's review ledger
(data/live/review_ledger.csv, ingestion.ledger) and is recorded in the action log by cli.main like every attest.

    econquest open-items [--json]          (alias: econquest todo)
    econquest attest --dry-run [--file F] [--country C] [--group G] [--pillar N] [--key K] [--all-files]
    econquest attest ... --author NAME (--approver OTHER | --self-approved) --confirm [--expect N]
    econquest exc next | exc draft --author NAME --scope TEXT --reason TEXT [--controls TEXT] [--expires TEXT]

Kinds, in the order printed (each item names the exact command that clears it):
  attest      hand-entered cells whose current content is not attested (ingestion.ledger.unattested_cells)
  restricted  applied cells from a restricted source (ingestion.audit.restricted_source_cells, SEC-A-006 M1)
  approvals   change proposals waiting for approval or apply, drift and chain state (ops.approvals)
  review      cells held by the quality gate with no decision yet (as `review list --pending`)
  exc         whether a dedicated compliance EXC id exists besides EXC-001 (docs/governance/issues-log.md)
  mac_pulls   pulls that only run on the Mac: presence of their output files and of the UCDP token, never its value
  decisions   open decisions recorded in docs: ACLED licence, vendor licences, decision packs
  calendar    research products due or overdue (presentation.research.calendar_status, EQ-C-0075)
  readiness   target-state rows not met and what each needs (presentation.readiness, EQ-C-0081)
  formal_tests calendar-gated formal tests due, overdue, to review or failed (ops.calendar_jobs, EQ-C-0095); also open
              when the calendar_tests job's plist is not in ~/Library/LaunchAgents on the Mac (EQ-C-0110)

Every source is read in its own try block: a source that cannot be read gives status "unknown" with the error type,
never a traceback, and never a local absolute path (the GUI route returns this dict as JSON).
The issues log is Team B's file (team/ownership.csv: docs/governance/*), so `exc draft` prints the row to add and
never writes it.
"""
from __future__ import annotations

import csv
import datetime as dt
import fnmatch
import hashlib
import inspect
import json
import os
import re
import shlex
import subprocess
import sys
from pathlib import Path
from types import SimpleNamespace

KINDS = ("attest", "restricted", "approvals", "review", "exc", "mac_pulls", "decisions", "calendar", "readiness",
         "formal_tests")
TITLES = {"attest": "Unattested hand-entered cells", "restricted": "Restricted-source cells (Yahoo)",
          "approvals": "Change approvals", "review": "Held review cells", "exc": "Compliance exception id",
          "mac_pulls": "Mac pulls not done yet", "decisions": "Open decisions (licences, decision packs)",
          "calendar": "Research products due or overdue",
          "readiness": "Desk readiness: targets not met",
          "formal_tests": "Calendar-gated formal tests due or failed"}
ROW_LIMIT = 60
ISSUES_LOG = Path("docs") / "governance" / "issues-log.md"
DECISIONS_DIR = Path("docs") / "governance" / "decisions"
EXC_ROW_RE = re.compile(r"^\|\s*(EXC-(\d{3,}))\s*\|(.*)$", re.M)
EXC_COLUMNS = ("Id", "Date", "Restriction or control", "What was done", "Approved by", "Compensating control", "Expires")
UCDP_KEYCHAIN_SERVICE = "econquest-ucdp"
ISSUES_LOG_OWNER = "B"          # team/ownership.csv docs/governance/* (checked by tests/test_open_items.py)


def _root(data_dir) -> Path:
    """The install folder that holds data/ and docs/ (as ops.approvals.exc_logged)."""
    return Path(data_dir).resolve().parent


def _q(v) -> str:
    return shlex.quote(str(v))


def _item(kind: str, status: str, count, summary: str, commands=(), rows=(), source: str = "") -> dict:
    rows = list(rows)
    return {"kind": kind, "title": TITLES[kind], "status": status, "count": count, "summary": summary,
            "commands": list(commands), "rows": rows[:ROW_LIMIT], "rows_total": len(rows), "source": source}


def _unknown(kind: str, e: BaseException, source: str) -> dict:
    return _item(kind, "unknown", None, f"could not read {source}: {type(e).__name__}", source=source)


# ---------------------------------------------------------------- batch attestation (cells, filters, write)
def _group_of(cell: dict) -> tuple[str, str]:
    """(indicator group, pillar) of a hand-entered cell: adjustments keys are 'block|pillar'; other files have none."""
    if cell.get("table") == "adjustments":
        block, _, pillar = str(cell.get("key", "")).partition("|")
        return block, pillar
    return "", ""


def _match(cell: dict, country=None, group=None, pillar=None, key=None) -> bool:
    g, p = _group_of(cell)
    return ((country is None or str(cell.get("country", "")).casefold() == str(country).casefold())
            and (group is None or g.casefold() == str(group).casefold())
            and (pillar is None or p == str(pillar).strip())
            and (key is None or str(cell.get("key", "")) == str(key)))


def select_unattested(data_dir, files=None, country=None, group=None, pillar=None, key=None) -> list[dict]:
    """The unattested hand-entered cells of `files` (default every hand-entered file) that match every filter given.
    country and group compare case-insensitively; group is the adjustments block ('Override floor'), pillar its
    pillar number, key the exact ledger key. A group or pillar filter implies the adjustments file."""
    from ..ingestion.ledger import unattested_cells
    if (group is not None or pillar is not None) and files and any(Path(str(f)).stem != "adjustments" for f in files):
        raise ValueError("--group and --pillar apply to the adjustments file only")
    if (group is not None or pillar is not None) and not files:
        files = ["adjustments"]
    cells = unattested_cells(Path(data_dir), list(files) if files else None)
    return [c for c in cells if _match(c, country, group, pillar, key)]


def batch_summary(cells: list[dict]) -> dict:
    """Counts of a selection by file, by (file, group) and by country."""
    by_file, by_group, by_country = {}, {}, {}
    for c in cells:
        by_file[c["table"]] = by_file.get(c["table"], 0) + 1
        g = _group_of(c)[0] or c["table"]
        by_group[f"{c['table']}: {g}"] = by_group.get(f"{c['table']}: {g}", 0) + 1
        by_country[c["country"]] = by_country.get(c["country"], 0) + 1
    return {"total": len(cells), "by_file": dict(sorted(by_file.items())), "by_group": dict(sorted(by_group.items())),
            "by_country": dict(sorted(by_country.items()))}


def selection_digest(cells: list[dict]) -> str:
    """16 hex characters naming exactly which cells, with which content, a selection holds (SEC-C-011 L1): the dry run
    prints it and `--confirm --expect-digest H` refuses unless the selection is still that same set. A count alone
    (--expect N) passes when one cell drops out and another, never shown, comes in."""
    lines = sorted(f"{c['table']}\x1f{c['key']}\x1f{c['country']}\x1f{c['content_sha256']}" for c in cells)
    return hashlib.sha256("\n".join(lines).encode("utf-8")).hexdigest()[:16]


def _ledger_supports_only() -> bool:
    from ..ingestion.ledger import attest_cells
    return "only" in inspect.signature(attest_cells).parameters


def attest_batch(data_dir, author, approver=None, self_approved: bool = False, note: str = "", files=None,
                 country=None, group=None, pillar=None, key=None, expect: int | None = None,
                 now: dt.datetime | None = None, digest: str | None = None) -> list[dict]:
    """Attest the selected unattested cells in the review ledger, all or nothing: four-eyes is checked (ledger
    check_approval, ValueError) and the selection recomputed from the files as they are now before anything is
    written; with `expect` the write is refused unless exactly that many cells are still selected (so a confirm
    writes what its dry run showed). Rows are the ones ingestion.ledger.attest_cells writes (decision apply, live =
    value, content_sha256, author, approver, self_approved flag, note), appended through the ledger's own locked
    append with its formula-injection guard. Uses attest_cells(only=...) when Team A's ledger offers it."""
    from ..ingestion import ledger as L
    author, approver, flag = L.check_approval(author, approver, self_approved)
    cells = select_unattested(data_dir, files, country, group, pillar, key)
    if expect is not None and len(cells) != int(expect):
        raise ValueError(f"--expect {expect}: the selection now has {len(cells)} unattested cell(s); rerun --dry-run")
    if digest is not None and selection_digest(cells) != str(digest).strip().lower():
        raise ValueError(f"--expect-digest {digest}: the selection is no longer the set of cells the dry run showed "
                         f"(now {len(cells)} cell(s), digest {selection_digest(cells)}); rerun --dry-run")
    if not cells:
        return []
    d = Path(data_dir)
    if _ledger_supports_only():                          # Team A's public subset API (HO to Team A, EQ-C-0074)
        out = []
        for name in sorted({c["table"] for c in cells}):
            only = {(c["key"], c["country"]) for c in cells if c["table"] == name}
            out += L.attest_cells(d, name, author, approver=approver, self_approved=self_approved, note=note,
                                  only=only, now=now)
        return out
    ts = L._ts(now)
    rows = [{"ts_utc": ts, "vintage_id": "", "table": c["table"], "key": c["key"], "country": c["country"],
             "gate_status": "", "live": L._attest_live(c["value"]), "decision": "apply", "author": author,
             "approver": approver, "note": (note or L.ATTEST_NOTE), "self_approved": flag,
             "content_sha256": c["content_sha256"]} for c in cells]
    L._append(d, rows)                                   # one locked append: every row or none
    return rows


def batch_command(args_like: dict, confirm: bool) -> str:
    """The command line for a selection: the dry run, or the confirm that writes exactly what the dry run showed."""
    parts = ["econquest", "attest"]
    for f in args_like.get("files") or []:
        parts += ["--file", f]
    for flag in ("country", "group", "pillar", "key"):
        if args_like.get(flag) is not None:
            parts += [f"--{flag}", _q(args_like[flag])]
    if args_like.get("all_files"):
        parts.append("--all-files")
    if not confirm:
        return " ".join(parts + ["--dry-run"])
    n, h = args_like.get("expect"), args_like.get("digest")
    return " ".join(parts + ["--author", "NAME", "--self-approved", "--confirm"] + (["--expect", str(n)] if n is not None else [])
                    + (["--expect-digest", str(h)] if h else []))


# ---------------------------------------------------------------- open items, one collector per kind
def _attest_item(d: Path) -> dict:
    from ..ingestion.ledger import unattested_cells
    cells = unattested_cells(d)
    if not cells:
        return _item("attest", "clear", 0, "All hand-entered cells are attested.", ["econquest attest --list"],
                     source="data/live/review_ledger.csv")
    s = batch_summary(cells)
    per = ", ".join(f"{k} {v}" for k, v in s["by_file"].items())
    cmds = ["econquest attest --list"]
    for grp, n in s["by_group"].items():
        table, _, g = grp.partition(": ")
        sel = {"files": [table]} | ({"group": g} if table == "adjustments" else {})
        cmds.append(f"{batch_command(sel, False)}    # {n} cells")
    cmds.append(batch_command({"all_files": True, "expect": s["total"]}, True) + "    # after checking the dry runs")
    rows = [{"file": c["table"], "key": c["key"], "country": c["country"], "label": c.get("label", ""),
             "value": c["value"]} for c in cells]
    return _item("attest", "open", s["total"], f"{s['total']} hand-entered cells are not attested ({per}). "
                 "publish --write stays blocked until they are (run gate). Attest in batches: dry run first, then "
                 "--confirm with your name.", cmds, rows, "data/live/review_ledger.csv")


def _restricted_item(d: Path) -> dict:
    from ..ingestion.audit import restricted_source_cells
    cells = restricted_source_cells(d)
    check = "python -m econquest.ingestion.audit restricted"
    if cells is None or cells.empty:
        return _item("restricted", "clear", 0, "No applied cell holds a restricted-source value.", [check],
                     source="data/live/provenance.csv")
    keys = ", ".join(f"{t} {k}: {n}" for (t, k), n in cells.groupby(["table", "key"]).size().items())
    rows = [{"table": r.table, "key": r.key, "country": r.country, "value": float(r.value), "source": r.source,
             "series": r.series} for r in cells.itertuples(index=False)]
    return _item("restricted", "open", len(cells), f"{len(cells)} applied cells hold Yahoo / restricted values ({keys}). "
                 "They block every workbook write. Replace them with the official FX pull on the Mac "
                 "(docs/runbooks/A-official-fx.md), then check.",
                 ["econquest fetch --only fx --apply    # on the Mac", check], rows, "data/live/provenance.csv")


def _approvals_item(d: Path) -> dict:
    from . import approvals as ap
    rows, cmds = [], []
    for c in ap.list_changes(d):
        if c["status"] == "proposed":
            rows.append({k: c[k] for k in ("id", "file", "tier", "author", "status", "reason")})
            cmds += [f"econquest change show {c['id']}",
                     f"econquest change approve {c['id']} --approver NAME    # or --self-approved --exc EXC-nnn",
                     f"econquest change reject {c['id']} --by NAME --reason TEXT"]
        elif c["status"] == "approved":
            rows.append({k: c[k] for k in ("id", "file", "tier", "author", "status", "reason")})
            cmds.append(f"econquest change apply {c['id']} --actor NAME")
    det = ap.detect_unapproved(d)
    drift = [f for f in det["files"] if f["status"] in ("drift", "missing")]
    for f in drift:
        rows.append({"id": "", "file": f["file"], "tier": "", "author": "", "status": f["status"],
                     "reason": "edited outside econquest change" if f["status"] == "drift" else "file missing"})
    if drift or not det["chain_ok"]:
        cmds.append("econquest change verify")
        cmds += [f"econquest change baseline {f['file']} --actor NAME --reason TEXT --approver OTHER" for f in drift
                 if f["status"] == "drift"]
    if not det["chain_ok"]:
        rows.append({"id": "", "file": "data/approvals/log.jsonl", "tier": "", "author": "", "status": "chain broken",
                     "reason": "the hash chain does not verify"})
    n = len(rows)
    if not n:
        return _item("approvals", "clear", 0, "No change waiting for approval or apply; no drift; chain verifies.",
                     ["econquest change list"], source="data/approvals/log.jsonl")
    pend = sum(r["status"] == "proposed" for r in rows); appr = sum(r["status"] == "approved" for r in rows)
    return _item("approvals", "open", n, f"{pend} proposal(s) waiting for approval, {appr} approved and not applied, "
                 f"{len(drift)} governed file(s) drifted{'' if det['chain_ok'] else ', approvals chain broken'}.",
                 ["econquest change list"] + cmds, rows, "data/approvals/log.jsonl")


def _review_item(d: Path) -> dict:
    from ..cli import _review_pending                    # the exact rule `review list --pending` uses
    from ..ingestion.ledger import load_decisions
    pend = _review_pending(d, load_decisions(d), SimpleNamespace(country=None, table=None))
    if not len(pend):
        return _item("review", "clear", 0, "No held cell is waiting for a decision.", ["econquest review list --pending"],
                     source="data/live/review.csv")
    rows = pend.astype(str).to_dict("records")
    return _item("review", "open", len(rows), f"{len(rows)} cell(s) held by the quality gate have no decision yet.",
                 ["econquest review list --pending",
                  "econquest review decide --all-pending --decision apply|hold|reject --author NAME --self-approved"],
                 rows, "data/live/review.csv")


def exc_rows(root: Path) -> list[dict]:
    """EXC rows of the issues log: id, number, text (the rest of the row). [] when the log is absent."""
    p = Path(root) / ISSUES_LOG
    if not p.is_file():
        return []
    return [{"id": m.group(1), "n": int(m.group(2)), "text": m.group(3)} for m in EXC_ROW_RE.finditer(p.read_text(encoding="utf-8"))]


def _restriction(row: dict) -> str:
    """The "Restriction or control" column of an EXC row (the cell after the date; escaped pipes kept)."""
    parts = re.split(r"(?<!\\)\|", row["text"])
    return parts[1].strip() if len(parts) > 1 else ""


def proposed_exc_ids(root: Path) -> list[str]:
    """EXC ids that docs/governance/decisions/*.md mention but the issues log does not list (proposed, not logged)."""
    logged = {r["id"] for r in exc_rows(root)}
    found = set()
    dd = Path(root) / DECISIONS_DIR
    if dd.is_dir():
        for f in sorted(dd.glob("*.md")):
            found |= set(re.findall(r"EXC-\d{3,}", f.read_text(encoding="utf-8")))
    return sorted(found - logged)


def _exc_item(d: Path) -> dict:
    root = _root(d)
    if not (root / ISSUES_LOG).is_file():
        return _item("exc", "unknown", None, f"{ISSUES_LOG} not found next to the data folder.", source=str(ISSUES_LOG))
    rows = exc_rows(root)
    # dedicated = the row's "Restriction or control" column names compliance (EXC-002 only says compliance self-sign
    # "gets its own id when needed" in its rationale, which is not a compliance exception)
    comp = [r for r in rows if r["id"] != "EXC-001" and "compliance" in _restriction(r).casefold()]
    table = [{"id": r["id"], "covers": _restriction(r)[:160]} for r in rows]
    if comp:
        return _item("exc", "clear", 0, f"Dedicated compliance exception logged: {', '.join(r['id'] for r in comp)}.",
                     rows=table, source=str(ISSUES_LOG))
    prop = proposed_exc_ids(root)
    note = f" Proposed in the PI-6 decision packs, not logged: {', '.join(prop)}." if prop else ""
    return _item("exc", "open", 1, "Logged: " + (", ".join(r["id"] for r in rows) or "no EXC id") + "; none of them is "
                 "a dedicated compliance exception for the first compliance self-sign (0.1.5 release notes)." + note +
                 " The issues log is Team B's file: draft the row, then paste it or hand it to Team B.",
                 ["econquest exc next",
                  "econquest exc draft --author Sam --scope 'Compliance self-sign in single-operator mode' "
                  "--reason TEXT --controls TEXT --expires 2027-01-22"], table, str(ISSUES_LOG))


def _keychain_has(service: str) -> bool | None:
    """macOS only: whether a Keychain item exists. `security find-generic-password -s S` without -w/-g prints the
    item's attributes, never the secret; output is discarded. None off macOS or when the check cannot run."""
    if sys.platform != "darwin":
        return None
    try:
        r = subprocess.run(["security", "find-generic-password", "-s", service], stdout=subprocess.DEVNULL,
                           stderr=subprocess.DEVNULL, timeout=5, check=False)
    except (OSError, subprocess.SubprocessError):
        return None
    return r.returncode == 0


def ucdp_token_state(d: Path, env=None) -> dict:
    """Whether a UCDP token is configured: the env variable named by the event config (presence only: its value is
    never read) or a Keychain item econquest-ucdp (macOS, existence only)."""
    env = os.environ if env is None else env
    name = "UCDP_API_TOKEN"
    try:
        from ..ingestion.events.base import load_event_config
        name = str(load_event_config(d).get("ucdp", {}).get("token_env") or name)
    except Exception:                                    # noqa: BLE001 - keep the default name
        pass
    if not re.fullmatch(r"[A-Z_][A-Z0-9_]{0,63}", name):  # SEC-C-016 L2 (EQ-C-0165): the name is pasted into a shell
        name = "UCDP_API_TOKEN"                          # `export NAME=...` line; anything else falls back
    in_env = name in env
    kc = None if in_env else _keychain_has(UCDP_KEYCHAIN_SERVICE)
    return {"env_name": name, "in_env": in_env, "keychain": kc, "configured": bool(in_env or kc)}


MAC_PULLS = (   # (name, files under data/ that exist once the pull is done, command, runbook)
    ("Panel history (WEO 39 releases, World Bank)", ("panel/weo_history.csv", "panel/worldbank_history.csv"),
     "caffeinate -i .venv/bin/python -m econquest.ingestion.panel_history --out data/panel", "docs/runbooks/A-full-panel-fetch.md step 2"),
    ("BoC-BoE (CRAG) default database import", ("panel/sovereign_defaults_crag.csv",),
     "import_crag of ~/Downloads/BoC-BoE-Database-2026.xlsx (the one-liner in docs/runbooks/A-full-panel-fetch.md step 3)",
     "docs/runbooks/A-full-panel-fetch.md step 3"),
    ("UCDP first pull", ("live/events/ucdp/vintages/index.csv",),
     'export UCDP_API_TOKEN="$(security find-generic-password -s econquest-ucdp -w)"; python -m econquest.ingestion.events.ucdp '
     '--start 2019-01-01 --end "$(date -u +%F)"; unset UCDP_API_TOKEN', "docs/runbooks/A-event-feeds.md section 1"),
    ("GDELT first pull", ("live/events/gdelt/vintages/index.csv",),
     "python -m econquest.ingestion.events.gdelt (see the runbook for --start/--end)", "docs/runbooks/A-event-feeds.md section 2"),
)


PACK_FILES = {"panel_history": MAC_PULLS[0][1], "crag": MAC_PULLS[1][1], "ucdp": MAC_PULLS[2][1], "gdelt": MAC_PULLS[3][1]}


def _pack_rows(d: Path) -> tuple[list[dict], list[str]] | None:
    """Rows from Team A's pull pack state (pullpack.status, read only; EQ-C-0073): a step is done when the pack
    recorded it done, or (pulled by hand from the runbooks) its output files exist. None when the pack is not there."""
    try:
        from ..ingestion import pullpack
        st = pullpack.status(d)
    except Exception:                                    # noqa: BLE001 - fall back to file presence
        return None
    rows, cmds = [], []
    for sid in st.get("order") or []:
        r = st["steps"].get(sid, {})
        files = PACK_FILES.get(sid, ())
        by_files = bool(files) and all((d / f).is_file() for f in files)
        done = r.get("status") == "done" or by_files
        rows.append({"pull": f"{r.get('number', '')} {r.get('title', sid)}".strip(), "done": "yes" if done else "no",
                     "missing": "" if done else (r.get("status", "pending") + (f": {r['reason']}" if r.get("reason") else "")),
                     "runbook": "docs/runbooks/A-mac-pull-pack.md"})
        if not done:
            cmds.append(sid)
    if cmds:                                             # one resumable run covers every step not done
        cmds = ["econquest mac-pull    # preflight first: changes nothing",
                f"econquest mac-pull run    # not done: {', '.join(cmds)}; rerun to resume"]
    return rows, cmds


def _mac_item(d: Path, env=None) -> dict:
    pack = _pack_rows(d)
    rows, cmds = pack if pack is not None else ([], [])
    for name, files, cmd, runbook in (() if pack is not None else MAC_PULLS):
        missing = [f for f in files if not (d / f).is_file()]
        rows.append({"pull": name, "done": "yes" if not missing else "no", "missing": ", ".join(f"data/{f}" for f in missing),
                     "runbook": runbook})
        if missing:
            cmds.append(f"{cmd}    # {name}")
    tok =ucdp_token_state(d, env)
    rows.append({"pull": "UCDP API token", "done": "yes" if tok["configured"] else "no",
                 "missing": "" if tok["configured"] else f"${tok['env_name']} not set and no Keychain item {UCDP_KEYCHAIN_SERVICE}"
                 + ("" if tok["keychain"] is not None else " (Keychain not checked off the Mac)"),
                 "runbook": "docs/runbooks/A-event-feeds.md section 1"})
    if not tok["configured"]:
        cmds.insert(0, f"security add-generic-password -s {UCDP_KEYCHAIN_SERVICE} -a \"$USER\" -w    "
                       "# after UCDP emails the token (prompts; never paste it into a file)")
    n = sum(r["done"] == "no" for r in rows)
    return _item("mac_pulls", "open" if n else "clear", n,
                 f"{n} Mac step(s) not done yet ("
                 + ("pull pack state and output files" if pack is not None else "file presence only") + "; no secret read)."
                 if n else "Every Mac pull has its output.",
                 cmds, rows, "data/live/pullpack/state.json" if pack is not None else "data/panel, data/live/events")


# A pack records its outcome on a line of its own, e.g. "**Decided 2026-10-24 12:38Z: (a).** ..." (today's Team B
# format) or "Status: decided 2026-10-24T12:38Z (Sam)"; bold markers optional, case-insensitive.
DECIDED_RE = re.compile(r"^[ \t>*_-]*(?:status:\s*)?decided[:\s]+(\d{4}-\d{2}-\d{2})(?:[T ](\d{2}:\d{2})Z?)?", re.I | re.M)


def _pack_evidence(para: str, root: Path, d: Path | None) -> tuple[list[str], list[str]]:
    """Cheap cross-checks of what a decided paragraph cites: change ids in the approvals ledger (approved or
    applied), EXC ids in the issues log, and "<file>.json ... baselined" in the approvals drift check."""
    ok, bad = [], []
    if d is not None:
        try:
            from . import approvals as ap
            chg = {c["id"]: c["status"] for c in ap.list_changes(d)}
            for cid in sorted(set(re.findall(r"CHG-\d{8}T\d{6}Z-[0-9a-f]{6}", para))):
                st = chg.get(cid)
                (ok if st in ("approved", "applied") else bad).append(f"{cid} {st or 'not in the approvals ledger'}")
            if re.search(r"baselin", para, re.I):
                files = {f["file"]: f for f in ap.detect_unapproved(d)["files"]}
                for name in sorted(set(re.findall(r"\b(\w+\.json)\b", para)) & set(files)):
                    f = files[name]
                    good = f["status"] == "ok" and f["last_event"] in ("baseline", "apply")
                    (ok if good else bad).append(f"{name} {'baselined' if good else f['status']}")
        except Exception as e:                           # noqa: BLE001 - evidence not readable: say so, keep the marker
            bad.append(f"approvals not readable ({type(e).__name__})")
    logged = {r["id"] for r in exc_rows(root)}
    for exc in sorted(set(re.findall(r"EXC-\d{3,}", para))):
        (ok if exc in logged else bad).append(f"{exc} {'logged' if exc in logged else 'not in the issues log'}")
    return ok, bad


def _decision_packs(root: Path, d: Path | None = None) -> list[dict]:
    """One row per "## n. Title" section of docs/governance/decisions/*.md. open "no" when the section has a decided
    marker and every cited piece of evidence checks out; "check" when the marker is there but evidence does not."""
    out = []
    dd = root / DECISIONS_DIR
    if not dd.is_dir():
        return out
    for f in sorted(dd.glob("*.md")):
        text = f.read_text(encoding="utf-8")
        for m in re.finditer(r"^## (\d+)\.\s*(.+?)\s*$(.*?)(?=^## |\Z)", text, re.M | re.S):
            body = m.group(3)
            q = re.search(r"\*\*Question\.\*\*\s*(.+?)(?:\n\n|$)", body, re.S)
            dec = DECIDED_RE.search(body)
            row = {"decision": f"{f.stem} {m.group(1)}: {m.group(2)}", "open": "yes",
                   "question": " ".join((q.group(1) if q else "").split())[:240], "doc": f"{DECISIONS_DIR}/{f.name}",
                   "decided": "", "evidence": ""}
            if dec:
                para = body[dec.start():].split("\n\n", 1)[0]
                ok, bad = _pack_evidence(para, root, d)
                row["decided"] = dec.group(1) + (f" {dec.group(2)}Z" if dec.group(2) else "")
                row["evidence"] = "; ".join(ok + [f"NOT CONFIRMED: {b}" for b in bad]) or (
                    "marker only: no CHG, EXC or baseline cited to cross-check")          # SEC-C-014 L1: say so
                row["open"] = "check" if bad else "no"
            out.append(row)
    return out


def _decisions_item(d: Path) -> dict:
    rows, cmds = [], []
    try:
        from ..ingestion.events.base import load_event_config
        ac = load_event_config(d).get("acled", {})
        on = bool(ac.get("enabled")) and str(ac.get("licence", "none")).strip().lower() not in ("", "none")
        rows.append({"decision": "ACLED corporate licence", "open": "no" if on else "yes",
                     "question": "Buy an ACLED corporate licence? The free/research tier does not cover the desk (EULA 1.2).",
                     "doc": "docs/runbooks/A-event-feeds.md section 3"})
        if not on:
            cmds.append("Decision only (Sam): if bought, set data/live/events/feeds.json acled.enabled true and licence "
                        "'<name, tier, reference>' (docs/runbooks/A-event-feeds.md section 3)")
    except Exception as e:                               # noqa: BLE001
        rows.append({"decision": "ACLED corporate licence", "open": "unknown", "question": type(e).__name__,
                     "doc": "docs/runbooks/A-event-feeds.md section 3"})
    try:
        from ..ingestion.market.vendors import vendor_status
        st = vendor_status(d)
        usable = [r.vendor for r in st.itertuples(index=False) if r.usable]
        rows.append({"decision": "Market-data vendor licence (Bloomberg / LSEG)", "open": "no" if usable else "yes",
                     "question": "Licence a vendor for CDS / FX / curves? Paid roadmap feature, off by default."
                     + (f" Usable: {', '.join(usable)}." if usable else " None configured."),
                     "doc": "docs/runbooks/A-licensed-vendors.md"})
        if not usable:
            cmds.append("econquest vendor status    # decision only (Sam): entitlement per docs/runbooks/A-licensed-vendors.md section 2")
    except Exception as e:                               # noqa: BLE001
        rows.append({"decision": "Market-data vendor licence", "open": "unknown", "question": type(e).__name__,
                     "doc": "docs/runbooks/A-licensed-vendors.md"})
    packs = _decision_packs(_root(d), d)
    rows += packs
    if any(p["open"] == "check" for p in packs):
        cmds.append("econquest change list    # a decided pack cites evidence that does not check out (see its row)")
    if any(p["open"] == "yes" for p in packs):
        cmds.append("Read the decision packs and answer the cards: " + ", ".join(sorted({p["doc"] for p in packs if p["open"] == "yes"})))
    rows = [{"decision": "", "open": "", "question": "", "doc": "", "decided": "", "evidence": ""} | r for r in rows]
    n = sum(r["open"] in ("yes", "check") for r in rows)
    return _item("decisions", "open" if n else "clear", n, f"{n} decision(s) recorded in docs are still open." if n
                 else "No open decision found in the docs.", cmds, rows, "docs/")


def _calendar_item(d: Path, out_dir=None, today=None) -> dict:
    """Products of the publication calendar (data/publication_calendar.json) whose slot is due or overdue at today
    (UTC), from Team C's research.calendar_status over the editorial ledger in outputs/."""
    from ..presentation.research import calendar_status
    today = today or dt.datetime.now(dt.timezone.utc).date()
    out = Path(out_dir) if out_dir is not None else d.parent / "outputs"
    rows = [r for r in calendar_status(d, out, today) if r.get("status") in ("overdue", "due")]
    rows.sort(key=lambda r: (r["status"] != "overdue", -int(r.get("days_overdue") or 0)))
    cmds = []
    for r in rows:
        c = str(r.get("command") or "")
        slot = str(r.get("slot_due") or today)
        c = re.sub(r"(--as-of) D\b", rf"\1 {slot}", c)
        cmds.append(f"{c}    # {r['title']} ({r['status']}, slot {slot})" if c else f"# {r['title']}: no command in the calendar")
    table = [{"product": r["title"], "status": r["status"], "slot_due": str(r.get("slot_due") or ""),
              "days_overdue": int(r.get("days_overdue") or 0), "last_published": str(r.get("last_published") or "never")}
             for r in rows]
    if not rows:
        return _item("calendar", "clear", 0, f"No research product is due or overdue on {today}.",
                     ["econquest calendar --as-of " + str(today)], source="data/publication_calendar.json")
    n_over = sum(r["status"] == "overdue" for r in rows)
    return _item("calendar", "open", len(rows), f"{n_over} overdue and {len(rows) - n_over} due research product(s) on {today}.",
                 cmds + ["econquest calendar --as-of " + str(today)], table, "data/publication_calendar.json")


def _readiness_item(d: Path, out_dir=None) -> dict:
    """Target-state rows not met (presentation.readiness over targets.target_scorecard) with their first need."""
    from ..presentation.readiness import readiness
    rep = readiness(d, Path(out_dir) if out_dir is not None else d.parent / "outputs")
    bad = [r for r in rep["rows"] if r["met"] != "yes"]
    rows = [{"id": r["id"], "met": r["met"], "target": r["target"], "needs": (r["needs"][0]["text"] if r["needs"] else "")}
            for r in bad]
    cmds, seen = [], set()
    for r in bad:
        for n in r["needs"]:
            c = n["command"]
            if c and c.startswith("econquest") and c not in seen:
                seen.add(c); cmds.append(c)
    cmds = ["econquest targets --explain"] + cmds[:8]
    if not bad:
        return _item("readiness", "clear", 0, rep["message"], cmds, source="outputs/targets")
    return _item("readiness", "open", len(bad), rep["message"] + " Each row below names what it needs.", cmds, rows,
                 "outputs/targets")


def _formal_tests_item(d: Path, out_dir=None) -> dict:
    """Calendar-gated formal tests (ops.calendar_jobs.page_status, read only) that are due, overdue, to review or failed."""
    from .calendar_jobs import ALERTING, page_status
    p = page_status(d, Path(out_dir) if out_dir is not None else d.parent / "outputs")
    if p.get("status") == "unknown":
        raise RuntimeError(p.get("message"))
    bad = [r for r in p["rows"] if r["status"] in ALERTING]
    rows = [{"test": r["test"], "status": r["status_text"], "formal_date": r["formal_date"], "detail": r["text"]} for r in bad]
    cmds = [p["command"]]
    msg = calendar_job_notice(d.resolve().parent)
    if msg:                                              # EQ-C-0110: the job that runs these tests is not installed
        from .schedule import INSTALL_HINT
        rows.insert(0, {"test": "calendar_tests job", "status": "not installed", "formal_date": "", "detail": msg})
        return _item("formal_tests", "open", len(rows), msg + " " + p["message"], [INSTALL_HINT] + cmds, rows,
                     "outputs/calendar_tests.json")
    if not bad:
        nxt = min(p["rows"], key=lambda r: r["days_left"]) if p["rows"] else None
        return _item("formal_tests", "clear", 0, p["message"] + (f" Next: {nxt['test']}, {nxt['text']}." if nxt else ""),
                     cmds, source="outputs/calendar_tests.json")
    return _item("formal_tests", "open", len(bad), p["message"], cmds, rows, "outputs/calendar_tests.json")


def calendar_job_notice(home=None, launch_agents=None) -> str:
    """The line open items and `econquest next` show when the calendar_tests plist is missing on the Mac; '' when it is
    installed or there is nothing to check (not macOS). Reads only."""
    from .schedule import INSTALL_HINT, job_installed
    try:
        ok = job_installed("calendar_tests", home, launch_agents)
    except OSError:
        return ""
    return f"calendar_tests job not installed: run `{INSTALL_HINT}`" if ok is False else ""


COLLECTORS = {"attest": (_attest_item, "data/live/review_ledger.csv"), "restricted": (_restricted_item, "provenance"),
              "approvals": (_approvals_item, "data/approvals"), "review": (_review_item, "data/live/review.csv"),
              "exc": (_exc_item, str(ISSUES_LOG)), "mac_pulls": (_mac_item, "data/"), "decisions": (_decisions_item, "docs/"),
              "calendar": (_calendar_item, "data/publication_calendar.json"),
              "readiness": (_readiness_item, "target scorecard"),
              "formal_tests": (_formal_tests_item, "outputs/calendar_tests.json")}


def collect(data_dir, env=None, now: dt.datetime | None = None, out_dir=None) -> dict:
    """Every open item. Reads only. {"generated_utc", "open": n kinds open, "items": [one dict per KINDS entry]}."""
    d = Path(data_dir)
    items = []
    for kind in KINDS:
        fn, src = COLLECTORS[kind]
        try:
            items.append(fn(d, env) if kind == "mac_pulls" else fn(d, out_dir, (now.date() if now else None))
                         if kind == "calendar" else fn(d, out_dir) if kind in ("readiness", "formal_tests") else fn(d))
        except (Exception, SystemExit) as e:             # noqa: BLE001 - one bad source never hides the rest
            items.append(_unknown(kind, e, src))         # (review refuses a bad review.csv with SystemExit)
    ts = (now or dt.datetime.now(dt.timezone.utc)).strftime("%Y-%m-%dT%H:%M:%SZ")
    return {"generated_utc": ts, "open": sum(i["status"] == "open" for i in items),
            "unknown": sum(i["status"] == "unknown" for i in items), "items": items}


def render_text(rep: dict, rows: int = 5) -> str:
    """Short plain-English list grouped by kind, each with the commands that clear it."""
    mark = {"open": "[OPEN]", "clear": "[ok]  ", "unknown": "[??]  "}
    lines = [f"Open items for the operator ({rep['open']} open, {rep['unknown']} unreadable) at {rep['generated_utc']}", ""]
    for it in rep["items"]:
        cnt = "" if it["count"] in (None, 0) else f" ({it['count']})"
        lines.append(f"{mark.get(it['status'], it['status'])} {it['title']}{cnt}")
        lines.append(f"    {it['summary']}")
        if it["status"] == "open":
            for r in it["rows"][:rows]:
                lines.append("      - " + "  ".join(f"{v}" for v in r.values() if v not in ("", None)))
            if it["rows_total"] > rows:
                lines.append(f"      ... and {it['rows_total'] - rows} more (--json for all)")
            for c in it["commands"]:
                lines.append(f"    $ {c}")
        lines.append("")
    return "\n".join(lines).rstrip() + "\n"


# ---------------------------------------------------------------- EXC helper (print only: the log is Team B's)
def owner_of(root: Path, rel: str) -> str | None:
    """Team owning `rel` per team/ownership.csv (most specific pattern wins); None when the file is absent."""
    p = Path(root) / "team" / "ownership.csv"
    if not p.is_file():
        return None
    best = None
    with open(p, newline="", encoding="utf-8") as f:
        for r in csv.DictReader(f):
            pat = r.get("pattern") or ""
            if fnmatch.fnmatch(rel, pat) and (best is None or len(pat) > len(best[0])):
                best = (pat, r.get("team") or "")
    return best[1] if best else None


def next_exc_id(root: Path) -> str:
    rows = exc_rows(root)
    return f"EXC-{max([r['n'] for r in rows] or [0]) + 1:03d}"


def _cell(text) -> str:
    t = " ".join(str(text or "").split())                # one line: a newline would end the table row
    return t.replace("\\", "\\\\").replace("|", "\\|")


def exc_row(exc_id: str, author: str, scope: str, reason: str, controls: str = "", expires: str = "",
            today: dt.date | None = None) -> str:
    """One row of the issues-log Exceptions table (columns EXC_COLUMNS)."""
    from ..ingestion.ledger import clean_person
    author = clean_person(author)
    if not author.strip():
        raise ValueError("--author is required")
    if not str(scope or "").strip() or not str(reason or "").strip():
        raise ValueError("--scope and --reason are required")
    if not re.fullmatch(r"EXC-\d{3,}", exc_id):
        raise ValueError(f"exception id must look like EXC-nnn, got {exc_id!r}")
    day = (today or dt.datetime.now(dt.timezone.utc).date()).isoformat()
    cells = [exc_id, day, scope, reason, f"{author}, {day}", controls or "To be agreed by Sam", expires or "To be set by Sam"]
    return "| " + " | ".join(_cell(c) for c in cells) + " |"


def cmd_exc(args) -> None:
    root = _root(args.data)
    rows = exc_rows(root)
    if not (root / ISSUES_LOG).is_file():
        raise SystemExit(f"exc: {ISSUES_LOG} not found next to {args.data}")
    nxt = next_exc_id(root)
    prop = proposed_exc_ids(root)
    if args.exc_cmd == "next":
        print(f"Logged: {', '.join(r['id'] for r in rows) or 'none'}. Next free id: {nxt}.")
        if prop:
            print(f"Proposed in docs/governance/decisions but not logged: {', '.join(prop)} (pick with exc draft --id).")
        return
    exc_id = args.id or nxt
    if exc_id in {r["id"] for r in rows}:
        raise SystemExit(f"exc: {exc_id} is already in {ISSUES_LOG}; next free id is {nxt}")
    try:
        row = exc_row(exc_id, args.author, args.scope, args.reason, args.controls or "", args.expires or "")
    except ValueError as e:
        raise SystemExit(f"exc: {e}") from None
    owner = owner_of(root, str(ISSUES_LOG)) or ISSUES_LOG_OWNER     # an install without team/ keeps the known owner
    who = f"Team {owner}"
    print(f"Add this row at the end of the Exceptions table in {ISSUES_LOG} (owned by {who}; this command never writes it):")
    print()
    print(row)
    print()
    print(f"Then use it: econquest change approve CHG-... --self-approved --exc {exc_id}  (or the compliance self-sign).")
    if prop and exc_id not in prop:
        print(f"Note: {', '.join(prop)} are proposed in docs/governance/decisions; check you are not taking a reserved id.")


def cmd_open_items(args) -> None:
    rep = collect(args.data, out_dir=getattr(args, "out", None))
    if args.json:
        print(json.dumps(rep, indent=1, default=str))
    else:
        print(render_text(rep, rows=args.rows), end="")


def register(sub) -> None:
    """open-items (alias todo) and exc, added by cli.main."""
    oi = sub.add_parser("open-items", aliases=["todo"], help="everything waiting on the operator (unattested cells, restricted "
                        "cells, approvals, held review cells, compliance EXC, Mac pulls, open decisions) with the command that clears each; reads only")
    oi.add_argument("--json", action="store_true", help="print the full list as JSON")
    oi.add_argument("--rows", type=int, default=5, help="example rows per item in the text list (default 5)")
    oi.set_defaults(fn=cmd_open_items)
    ex = sub.add_parser("exc", help="exception ids (EXC-nnn) of docs/governance/issues-log.md: next free id, or draft a row to add (prints only; the log is Team B's)")
    exs = ex.add_subparsers(dest="exc_cmd", required=True)
    exs.add_parser("next", help="the logged EXC ids and the next free one")
    dr = exs.add_parser("draft", help="print a properly formatted Exceptions-table row (next free id, today, author, scope, reason)")
    dr.add_argument("--author", required=True); dr.add_argument("--scope", required=True, help="the restriction or control the exception covers")
    dr.add_argument("--reason", required=True, help="what is done instead, and why"); dr.add_argument("--controls", help="compensating controls")
    dr.add_argument("--expires", help="expiry, e.g. 2027-01-22 or 'when a second approver is named'")
    dr.add_argument("--id", help="a specific free id (e.g. one proposed in a decision pack); default the next free one")
    ex.set_defaults(fn=cmd_exc)
