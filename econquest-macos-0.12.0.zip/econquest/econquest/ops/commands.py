"""CLI subcommands for the ops modules (EQ-C-0021, EQ-C-0022). econquest/cli.py adds them with

    from .ops.commands import register as register_ops
    register_ops(sub, HOME_DIR)

    econquest schedule install|uninstall|show|check [--job J] [--load] [--tz TZ] [--record-time HH:MM] ...
                                                     (check: ok/missing/stale per job, exit 1 unless all ok; EQ-C-0110)
    econquest ops-report --week [--as-of D] [--json]  INTERNAL weekly operations report, outputs/reports/ops/ (EQ-C-0110)
    econquest health [--no-deliver] [--stale-days N] [--strict]
    econquest backup [--verify] [--verify-only BACKUP] [--dest DIR] [--no-prune] [--list]
    econquest restore-drill [--backup BACKUP] [--dest DIR] [--keep]
    econquest distribute queue|send|status|verify   (EQ-C-0045; send is a dry run unless --send)
    econquest incident log PHASE --summary S --actor NAME [--id INC-..] | incident list   (EQ-C-0077)
    econquest users list | fingerprint --id ID | verify                                   (EQ-C-0078)
    econquest evidence --as-of D [--out DIR] [--quick] [--tests-from FILE] | evidence verify ZIP   (EQ-C-0060)
    econquest weekly-brief --as-of D [--pdf] [--dest DIR] | econquest calendar [--as-of D] [--json] (EQ-C-0075)
    econquest events [--days N] [--country C] [--type T] [--min-importance N] [--alerts] [--client] [--json]
                                                     event calendar view and alerts (EQ-C-0155, presentation/calendar_view.py)
    econquest heatmap [--country C] [--client] [--run-id ID] [--depth] [--build-depth] [--json] [--html OUT]
                                                     country risk heatmap and M19 depth page (EQ-C-0156, presentation/heatmap.py)
    econquest server check|plan|selftest|run   server deployment option, off by default (EQ-C-0157, deploy/server/)
    econquest rehearse [--zips DIR] [--current ZIP] [--quick] [--keep] [--json] [--out DIR]   real-data day rehearsal
                                                     (M21) on copies; read-only on data/ (EQ-C-0168, ops/rehearse.py)
    econquest backtest-explain --as-of D [--out DIR] [--step N]   INTERIM backtest explainer (Team B EQ-B-0141) and its
                                                     page section (M22, EQ-C-0166, presentation/backtest_explainer_view.py)
    econquest research-qa [--run RUN] [--path FILE|DIR] [--json]   research QA gate: figures vs the cited run, stale data,
                                                     agreement between products; exit 1 on failure (EQ-C-0163, ops/research_qa.py)
    econquest assistant status|ask "Q" [--country X] [--json]|setup --check [--probe]   LLM desk assistant, OFF until
                                                     <home>/assistant.json (EQ-C-0170/0171, econquest/assistant/)
    econquest assistant draft --country X | edit ID --file F --by N | drafts | sign ID --by N   model-assisted drafts,
                                                     QA-gated, signed through the archive (EQ-C-0172, assistant/drafts.py)
    econquest overlay add|approve|withdraw|list|verify   INTERNAL analyst overlay over Team B's analyst_overlay, off by
                                                     default (EQ-C-0161, HO-20261026-B-C-014, presentation/overlay_view.py)

The top-level --data / --out are honoured by health; schedule, backup and restore-drill work on the install folder
(the parent of --out, i.e. ECONQUEST_HOME), because they cover data/ and outputs/ together.
"""
from __future__ import annotations
import sys
from pathlib import Path


def _home(args, default_home) -> Path:
    out = getattr(args, "out", None)
    return Path(out).expanduser().resolve().parent if out else Path(default_home)


def register(sub, default_home) -> None:
    from . import backup, distribute, health, schedule

    def _exit(code: int) -> None:
        if code:
            sys.exit(code)

    sc = sub.add_parser("schedule", help="launchd jobs on macOS (record 18:20 NY weekdays, morning run+report, Monday monitor, nightly backup, 15-min health): install, uninstall, show, or check what is installed")
    schedule.add_arguments(sc)

    def _schedule(a):
        r = schedule.run_from_args(a, _home(a, default_home))
        if a.action == "check" and r.get("status") != "ok":
            sys.exit(1)
    sc.set_defaults(fn=_schedule)

    from . import ops_report
    orp = sub.add_parser("ops-report", help="INTERNAL weekly operations report (last 7 days: runs and base-number moves, job outcomes and "
                                            "missed runs, gate holds and releases, alerts and incidents, calendar test progress, "
                                            "freshness SLA, open items, schedule check): HTML + markdown in outputs/reports/ops/")
    ops_report.add_arguments(orp)
    orp.set_defaults(fn=lambda a: _exit(ops_report.run_from_args(a, _home(a, default_home), a.data, a.out)))

    he = sub.add_parser("health", help="missed scheduled runs, stale live feeds and failed jobs; writes outputs/health.json and delivers new alerts; "
                                       "--daily: run monitor with OK/WARN/FAIL lines (EQ-C-0077)")
    health.add_arguments(he)
    he.set_defaults(fn=lambda a: _exit(health.run_from_args(a, a.data, a.out)))

    bk = sub.add_parser("backup", help="tar.gz of data/ and outputs/store with a sha256 manifest to $ECONQUEST_BACKUP_DEST (default ~/econquest-backups/nightly/<UTC date>/); keeps 14 daily + 8 weekly")
    backup.add_backup_arguments(bk)
    bk.set_defaults(fn=lambda a: _exit(_guard(backup.backup_from_args, a, _home(a, default_home))))

    rd = sub.add_parser("restore-drill", help="restore the latest backup into a temp folder, verify every hash, smoke check, time it against the RTO and the backup's age against the RPO (data/resilience.json, default 1 h / 24 h); writes outputs/logs/restore-drill-<ts>.json and restore-drills.jsonl")
    backup.add_drill_arguments(rd)
    rd.set_defaults(fn=lambda a: _exit(_guard(backup.drill_from_args, a, _home(a, default_home))))

    di = sub.add_parser("distribute", help="email published products to their subscribers (data/distribution.json) with an archive link: "
                                           "queue, send (dry run unless --send), status (latency p95), verify the delivery log")
    distribute.add_arguments(di)
    di.set_defaults(fn=lambda a: _exit(distribute.run_from_args(a)))

    from . import incidents
    inc = sub.add_parser("incident", help="incident log (detect, triage, contain, restore, record) in the hash-chained action log; "
                                          "runbook team/runbooks/C-incident.md (EQ-C-0077)")
    incidents.add_arguments(inc)

    def _incident(a):
        from ..cli import action_out
        _exit(incidents.run_from_args(a, action_out(a)))
    inc.set_defaults(fn=_incident)

    from ..presentation import research_commands
    research_commands.register(sub)       # weekly-brief, calendar (EQ-C-0075)

    from ..presentation import archive_commands
    archive_commands.register(sub)        # archive add|correct|list|show|search|verify (EQ-C-0154)

    from . import research_qa
    research_qa.register(sub)             # research-qa: figures vs the cited run, stale data, agreement (EQ-C-0163)

    from ..presentation import calendar_view
    calendar_view.register(sub)           # events: the event calendar and its alerts (EQ-C-0155); not `calendar`

    from ..presentation import heatmap
    heatmap.register(sub)                 # heatmap: country risk heatmap, drill-down and the M19 depth page (EQ-C-0156)

    from . import rehearse
    rehearse.register(sub)                # rehearse: real-data day rehearsal M21 over Team A's rehearsal.main (EQ-C-0168)
    from ..presentation import backtest_explainer_view
    backtest_explainer_view.register(sub)  # backtest-explain: INTERIM backtest explainer + page, M22 (EQ-C-0166, C18)

    from ..presentation import overlay_view
    overlay_view.register(sub)            # overlay add|approve|withdraw|list|verify: INTERNAL analyst overlay (EQ-C-0161)

    from ..assistant import cli as assistant_cli
    assistant_cli.register(sub, lambda a: _home(a, default_home))  # assistant status|ask|setup, OFF (EQ-C-0170/0171)

    from . import identity
    us = sub.add_parser("users", help="named users for four-eyes approvals (data/users.json, EQ-C-0078): list, fingerprint "
                                      "(of a user's signing secret, for enrolment), verify (signed approval rows); off until a "
                                      "second analyst is registered")
    identity.add_arguments(us)
    us.set_defaults(fn=lambda a: _exit(identity.run_from_args(a, a.data)))

    from . import evidence
    ev = sub.add_parser("evidence", help="one verifiable zip for an independent validator: governance and validation docs, the stored runs "
                                         "for --as-of with their hashes, test results, replication, hash chains, dossier and release "
                                         "manifests (outputs/evidence/evidence-<as_of>.zip); `evidence verify ZIP` rechecks it offline")
    evidence.add_arguments(ev)
    ev.set_defaults(fn=lambda a: _exit(evidence.run_from_args(a, default_home)))

    from . import server
    sv = sub.add_parser("server", help="server deployment option, OFF by default (EQ-C-0157, deploy/server/): check readiness, plan "
                                       "what runs when, selftest a compressed day in a temp home, run the scheduler "
                                       f"(only with {server.ENABLE_ENV}=1)")
    server.add_arguments(sv)
    sv.set_defaults(fn=lambda a: _exit(server.run_from_args(a, _home(a, default_home), Path(a.data))))


def _guard(fn, args, home) -> int:
    from .backup import BackupError
    try:
        return fn(args, home)
    except BackupError as e:
        print(f"[backup] error: {e}", file=sys.stderr)
        return 2
