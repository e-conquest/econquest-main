"""Client distribution log (EQ-C-0107): one hash-chained row per client delivery built by presentation/client_build.py.
BUILT BUT OFF: rows are written only by client_build, which refuses unless client mode is approved and licences allow
client output (client_build.gate). Today nothing writes here.

    <out>/store/client_deliveries.jsonl       rows, append-only
    <out>/store/client_deliveries.head.json   {"seq", "row_hash"} of the last row (catches rows cut from the end)
    <out>/store/client_deliveries.head.hmac.json   keyed-head seal, only when ledger_keyed_heads is on (ops/ledger_key.py)

Same chain as the delivery log (ops/distribute.py) and the change-approval log: approvals.row_hash over the canonical
row, prev_hash = the previous row_hash (GENESIS first), seq 1..n. A broken chain refuses every new client delivery.
Fields: seq, ts_utc, event (client_export | client_workbook), item_id, kind, recipient, actor, files [{name, sha256,
watermark_id}], dir (relative to <out>), approval_id (Sam's research.json change), research_sha256, licences_sha256,
note, prev_hash, row_hash. Rows hold hashes and ids only, never page content.
"""
from __future__ import annotations

import contextlib
import json
import os
from pathlib import Path

from . import ledger_key
from .approvals import GENESIS, _atomic_write, _ts, row_hash

try:
    import fcntl
except ImportError:                                     # pragma: no cover - Windows
    fcntl = None

TICKET = "EQ-C-0107"
LOG_NAME = "client_deliveries.jsonl"
HEAD_NAME = "client_deliveries.head.json"
EVENTS = ("client_export", "client_workbook")
FIELDS = ("seq", "ts_utc", "event", "item_id", "kind", "recipient", "actor", "files", "dir", "approval_id",
          "research_sha256", "licences_sha256", "note", "prev_hash", "row_hash")


class ClientLogError(RuntimeError):
    """The client distribution log does not verify, or a row is invalid: nothing is appended."""


def log_path(out_dir) -> Path:
    return Path(out_dir) / "store" / LOG_NAME


def head_path(out_dir) -> Path:
    return Path(out_dir) / "store" / HEAD_NAME


def seal_path(out_dir) -> Path:
    """Keyed-head seal, written and checked only when ledger_keyed_heads is on (EQ-C-0076, SEC-C-018)."""
    return Path(out_dir) / "store" / ledger_key.SEAL_NAMES["client_deliveries"]


@contextlib.contextmanager
def locked(out_dir):
    p = log_path(out_dir)
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p.with_name(".client_deliveries.lock"), "a") as f:
        if fcntl is not None:
            fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            if fcntl is not None:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)


def read_log(out_dir) -> list[dict]:
    p = log_path(out_dir)
    if not p.exists():
        return []
    rows = []
    for line in p.read_text(encoding="utf-8").splitlines():
        if line.strip():
            try:
                r = json.loads(line)
            except json.JSONDecodeError:
                r = {}
            rows.append(r if isinstance(r, dict) else {})
    return rows


def verify(out_dir) -> dict:
    """seq runs 1..n, each prev_hash is the previous row_hash, each row_hash recomputes, the head names the last row."""
    p, hp = log_path(out_dir), head_path(out_dir)
    errors, rows, prev = [], [], GENESIS
    if p.is_symlink() or hp.is_symlink():
        return {"ok": False, "rows": 0, "errors": ["client distribution log or head is a symlink"], "path": LOG_NAME}
    for i, line in enumerate(p.read_text(encoding="utf-8").splitlines() if p.exists() else [], 1):
        try:
            r = json.loads(line)
        except json.JSONDecodeError:
            errors.append(f"line {i}: not JSON"); prev = None; continue
        if not isinstance(r, dict):
            errors.append(f"line {i}: not a JSON object"); prev = None; continue
        if r.get("seq") != len(rows) + 1:
            errors.append(f"line {i}: seq {r.get('seq')} where {len(rows) + 1} expected (row deleted, inserted or moved)")
        if prev is not None and r.get("prev_hash") != prev:
            errors.append(f"line {i}: prev_hash does not match the previous row")
        if r.get("row_hash") != row_hash(str(r.get("prev_hash", "")), r):
            errors.append(f"line {i}: row_hash does not recompute (row edited)")
        prev = r.get("row_hash"); rows.append(r)
    last = rows[-1] if rows else {"seq": 0, "row_hash": GENESIS}
    if hp.exists():
        try:
            head = json.loads(hp.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            head = None; errors.append(f"{HEAD_NAME} is not JSON")
        if isinstance(head, dict) and (head.get("seq"), head.get("row_hash")) != (last.get("seq"), last.get("row_hash")):
            errors.append(f"{HEAD_NAME} names seq {head.get('seq')} but the log ends at seq {last.get('seq')}")
    elif rows:
        errors.append(f"{HEAD_NAME} missing (rows removed from the end?)")
    errors += ledger_key.check("client_deliveries", seal_path(out_dir), last.get("seq") or 0, last.get("row_hash"))
    return {"ok": not errors, "rows": len(rows), "errors": errors, "path": LOG_NAME}


def append(out_dir, event: str, now=None, **fields) -> dict:
    """Verify the chain, then append one row (under the lock). ClientLogError on a broken chain or unknown event."""
    if event not in EVENTS:
        raise ClientLogError(f"event must be one of {EVENTS}")
    from .licence_gov import demo_refusal
    if (why := demo_refusal("client distribution")):     # EQ-C-0123: never on a DEMO licence baseline
        raise ClientLogError(why)
    with locked(out_dir):
        v = verify(out_dir)
        if not v["ok"]:
            raise ClientLogError("client distribution log failed verification, refusing: " + "; ".join(v["errors"][:3]))
        rows = read_log(out_dir)
        row = {c: "" for c in FIELDS}
        row.update({k: ("" if v is None else v) for k, v in fields.items() if k in FIELDS and k not in ("seq", "prev_hash", "row_hash")})
        row.update(seq=len(rows) + 1, ts_utc=_ts(now), event=event, prev_hash=rows[-1].get("row_hash", "") if rows else GENESIS)
        row["row_hash"] = row_hash(row["prev_hash"], row)
        with open(log_path(out_dir), "a", encoding="utf-8") as f:
            f.write(json.dumps(row, ensure_ascii=False) + "\n"); f.flush(); os.fsync(f.fileno())
        _atomic_write(head_path(out_dir), (json.dumps({"seq": row["seq"], "row_hash": row["row_hash"]}) + "\n").encode())
        ledger_key.seal("client_deliveries", seal_path(out_dir), row["seq"], row["row_hash"])   # no-op unless on
    return row
