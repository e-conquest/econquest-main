"""Daily run monitor (EQ-C-0077): `econquest health --daily`.

One pass over what a desk day depends on, printed as OK / WARN / FAIL lines, written to outputs/ops_monitor.json (the
GUI serves it at /api/json/ops_monitor) and routed by data/resilience.json. Exit code 1 when any line is FAIL.

    run        the latest business day's base run is archived in outputs/store (the morning job's slot, weekdays 07:00
               New York + 90 min, from ops.json / schedule defaults; holidays from ops.json)       missing -> FAIL
    record     data/forecast_record.csv has a row recorded for the latest business day's record slot (18:20 + 30 min)
                                                                                                   missing -> FAIL
    backup     the newest backup under $ECONQUEST_BACKUP_DEST (or --backup-dest): sidecar manifest readable, archive
               present with the size the manifest records; age <= monitor.backup_max_age_hours OK, <= 2 x RPO WARN,
               older or none FAIL
    drill      outputs/restore_drill.json: last drill passed (else FAIL), within the RTO and no older than
               monitor.drill_max_age_days (else WARN); none recorded WARN
    chains     hash chains verify: data/approvals/log.jsonl (missing or empty WARN, broken FAIL), the action log
               (outputs/store/actions.jsonl, which also holds the incident log), the delivery log, the editorial
               ledger and the review ledger data/live/review_ledger.csv (ingestion.ledger.verify_ledger, HO-20261025-
               A-C-024; legacy unchained rows are notes) (broken FAIL; not yet written OK)
    disk       free space on the volume holding outputs/: < disk_fail_free_gb FAIL; < disk_warn_free_gb or
               < disk_warn_free_pct % WARN

Routing (data/resilience.json "routing"): local outputs always (ops_monitor.json; with local.alerts_json the WARN/FAIL
lines are also merged into outputs/alerts.json as kind "ops_<check>" rows, replacing the previous monitor's rows and
keeping the run's own alerts). Email is off by default; when enabled it is a dry run that writes the message it would
send to outputs/logs/ops-alert-email-dryrun.json (recipients checked with the distribute address rules). This build
never sends: dry_run false is reported as refused. Live sending stays with `econquest distribute` and is Sam's call.
"""
from __future__ import annotations

import copy
import datetime as dt
import json
import math
import os
import shutil
from pathlib import Path

STATUSES = ("OK", "WARN", "FAIL")
_RANK = {s: i for i, s in enumerate(STATUSES)}
CONFIG_NAME = "resilience.json"
DEFAULTS = {
    "targets": {"rpo_hours": 24.0, "rto_hours": 1.0},
    "monitor": {"backup_max_age_hours": 26.0, "drill_max_age_days": 8.0, "disk_warn_free_gb": 5.0,
                "disk_fail_free_gb": 1.0, "disk_warn_free_pct": 10.0},
    "routing": {"local": {"alerts_json": True},
                "email": {"enabled": False, "dry_run": True, "to": [], "min_status": "FAIL"}},
}
REPORT_NAME = "ops_monitor.json"
DRYRUN_NAME = "ops-alert-email-dryrun.json"


class ResilienceConfigError(ValueError):
    """data/resilience.json is not valid."""


def _num(v, what: str) -> float:
    if isinstance(v, bool) or not isinstance(v, (int, float)) or not math.isfinite(v) or v < 0:
        raise ResilienceConfigError(f"{CONFIG_NAME}: {what} must be a finite number >= 0, got {v!r}")
    return float(v)


def load_resilience(data_dir) -> dict:
    """Defaults, overlaid with data/resilience.json when present (unknown keys ignored, "_doc" allowed). Raises
    ResilienceConfigError on a wrong type, so a typo cannot silently switch a check off."""
    cfg = copy.deepcopy(DEFAULTS)
    p = Path(data_dir) / CONFIG_NAME
    cfg["source"] = "default"
    if not p.exists():
        return cfg
    try:
        doc = json.loads(p.read_text(encoding="utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise ResilienceConfigError(f"{p}: not valid JSON ({e})") from None
    if not isinstance(doc, dict):
        raise ResilienceConfigError(f"{p}: expected a JSON object")
    cfg["source"] = str(p)
    for sec in ("targets", "monitor"):
        for k, v in (doc.get(sec) or {}).items():
            if k in cfg[sec]:
                cfg[sec][k] = _num(v, f"{sec}.{k}")
    if cfg["targets"]["rto_hours"] <= 0 or cfg["targets"]["rpo_hours"] <= 0:
        raise ResilienceConfigError(f"{p}: targets.rto_hours and targets.rpo_hours must be > 0")
    r = doc.get("routing") or {}
    loc = r.get("local") or {}
    if "alerts_json" in loc:
        if not isinstance(loc["alerts_json"], bool):
            raise ResilienceConfigError(f"{p}: routing.local.alerts_json must be true or false")
        cfg["routing"]["local"]["alerts_json"] = loc["alerts_json"]
    em = r.get("email") or {}
    for k in ("enabled", "dry_run"):
        if k in em:
            if not isinstance(em[k], bool):
                raise ResilienceConfigError(f"{p}: routing.email.{k} must be true or false")
            cfg["routing"]["email"][k] = em[k]
    if "min_status" in em:
        if em["min_status"] not in ("WARN", "FAIL"):
            raise ResilienceConfigError(f"{p}: routing.email.min_status must be WARN or FAIL")
        cfg["routing"]["email"]["min_status"] = em["min_status"]
    if "to" in em:
        from .distribute import DistributionError, check_address
        if not isinstance(em["to"], list):
            raise ResilienceConfigError(f"{p}: routing.email.to must be a list of addresses")
        try:
            cfg["routing"]["email"]["to"] = [check_address(a, "routing.email.to entry") for a in em["to"]]
        except DistributionError as e:
            raise ResilienceConfigError(f"{p}: {e}") from None
    return cfg


def _line(check: str, status: str, detail: str, **extra) -> dict:
    return {"check": check, "status": status, "detail": detail, **extra}


def _iso(t: dt.datetime | None) -> str | None:
    return t.astimezone(dt.timezone.utc).isoformat(timespec="seconds") if t else None


# ---------------------------------------------------------------- checks
def _slot_check(check: str, job_name: str, evidence: str, sched_cfg: dict, now: dt.datetime, data_dir: Path,
                out_dir: Path) -> dict:
    """run / record: was the latest due slot of the job done (health.evidence_since, same rule as missed_run)."""
    from . import health as H
    job = (sched_cfg.get("jobs") or {}).get(job_name)
    if not job or "hour" not in job:
        return _line(check, "WARN", f"no {job_name} job in the schedule config (ops.json): nothing to check against")
    tz = sched_cfg.get("tz") or "America/New_York"
    grace = int(sched_cfg.get("grace_minutes", 15))
    holidays = {dt.date.fromisoformat(h) for h in sched_cfg.get("holidays", [])}
    due = H.latest_due_slot(job, now, tz, grace, holidays)
    if due is None:
        return _line(check, "WARN", f"no {job_name} slot due in the last 10 days")
    slot, deadline = due
    ok, detail = H.evidence_since(evidence, job_name, slot, data_dir, out_dir, {})
    day = slot.astimezone(H._zone(tz)).date()
    return _line(check, "OK" if ok else "FAIL", f"{detail} (expected for {day.isoformat()}, due {_iso(deadline)})",
                 expected_day=day.isoformat())


def check_backup(dest, now: dt.datetime, cfg: dict) -> dict:
    from . import backup as B
    found = B.list_backups(dest)
    rpo = cfg["targets"]["rpo_hours"]
    if not found:
        return _line("backup", "FAIL", f"no backup under {B.default_dest() if dest is None else dest}")
    arch = found[-1]
    side = arch.with_name(arch.name[:-len(".tar.gz")] + ".manifest.json")
    try:
        m = json.loads(side.read_text())
        created = dt.datetime.fromisoformat(str(m["created_at"]).replace("Z", "+00:00"))
        created = created if created.tzinfo else created.replace(tzinfo=dt.timezone.utc)
    except (OSError, ValueError, KeyError, TypeError) as e:
        return _line("backup", "FAIL", f"{arch.name}: manifest unreadable ({type(e).__name__})")
    if m.get("archive_bytes") is not None and arch.stat().st_size != m.get("archive_bytes"):
        return _line("backup", "FAIL", f"{arch.name}: archive is {arch.stat().st_size} bytes, the manifest says "
                                       f"{m.get('archive_bytes')} (truncated or replaced; econquest backup --verify-only)")
    age = (now - created).total_seconds() / 3600
    st = "OK" if age <= cfg["monitor"]["backup_max_age_hours"] else ("WARN" if age <= 2 * rpo else "FAIL")
    return _line("backup", st, f"{arch.name}: {m.get('file_count')} files, {age:.1f} h old (RPO {rpo:g} h)",
                 age_hours=round(age, 2), archive=str(arch))


def check_drill(out_dir: Path, now: dt.datetime, cfg: dict) -> dict:
    p = out_dir / "restore_drill.json"
    if not p.exists():
        return _line("drill", "WARN", "no restore drill recorded (econquest restore-drill)")
    try:
        d = json.loads(p.read_text())
        at = dt.datetime.fromisoformat(str(d["drill_at"]).replace("Z", "+00:00"))
        at = at if at.tzinfo else at.replace(tzinfo=dt.timezone.utc)
    except (OSError, ValueError, KeyError, TypeError) as e:
        return _line("drill", "WARN", f"restore_drill.json unreadable ({type(e).__name__})")
    rto = cfg["targets"]["rto_hours"]
    secs = float(d.get("duration_seconds") or 0)
    days = (now - at).total_seconds() / 86400
    if not (d.get("restore_ok") and (d.get("smoke") or {}).get("ok")):
        return _line("drill", "FAIL", f"last drill {_iso(at)} failed: restore or smoke check did not pass")
    st = "OK"
    notes = []
    if secs > rto * 3600:
        st = "WARN"; notes.append(f"over the RTO {rto:g} h")
    if days > cfg["monitor"]["drill_max_age_days"]:
        st = "WARN"; notes.append(f"older than {cfg['monitor']['drill_max_age_days']:g} days")
    return _line("drill", st, f"last drill {_iso(at)} restored {d.get('files')} files in {secs:.0f} s" +
                 (f" ({'; '.join(notes)})" if notes else ""), age_days=round(days, 2))


def check_chains(data_dir: Path, out_dir: Path) -> list[dict]:
    from . import actionlog, approvals, distribute
    from ..presentation import editorial
    out = []
    p = approvals.log_path(data_dir)
    try:
        empty = not p.read_text(encoding="utf-8").strip()
    except FileNotFoundError:
        empty = None
    if empty is None or empty:
        out.append(_line("chain:approvals", "WARN", f"{p.name} is {'missing' if empty is None else 'empty'}: the governed files "
                                                    "read as never governed (restore data/approvals/ from the backup)"))
    else:
        v = approvals.verify_chain(data_dir)
        out.append(_line("chain:approvals", "OK" if v["ok"] else "FAIL",
                         f"{v['rows']} rows verify" if v["ok"] else "; ".join(v["errors"][:3])))
    for name, fn in (("chain:actions", lambda: actionlog.verify(out_dir)), ("chain:deliveries", lambda: distribute.verify(out_dir))):
        try:
            v = fn()
            out.append(_line(name, "OK" if v["ok"] else "FAIL",
                             (f"{v['rows']} rows verify" if v["rows"] else "no rows yet") if v["ok"] else "; ".join(v["errors"][:3])))
        except Exception as e:                       # noqa: BLE001 - a crash in a verifier is itself a FAIL
            out.append(_line(name, "FAIL", f"verify failed: {type(e).__name__}"))
    try:
        probs = editorial.verify_chain(out_dir)
        out.append(_line("chain:editorial", "FAIL" if probs else "OK", "; ".join(probs[:3]) if probs else "verifies (or not yet written)"))
    except Exception as e:                           # noqa: BLE001
        out.append(_line("chain:editorial", "FAIL", f"verify failed: {type(e).__name__}"))
    try:                                             # HO-20261025-A-C-024: Team A's review ledger chain (EQ-A-0103)
        from ..ingestion import ledger
        v = ledger.verify_ledger(data_dir)
        notes = "; ".join(str(n) for n in (v.get("notes") or [])[:2])
        detail = (f"{v['rows']} rows ({v['chained']} chained, {v['legacy_unchained']} legacy unchained) verify" if v.get("exists")
                  else "no review ledger yet") + (f"; note: {notes}" if notes else "")
        out.append(_line("chain:review", "OK" if v["ok"] else "FAIL", detail if v["ok"] else "; ".join(v["problems"][:3])))
    except Exception as e:                           # noqa: BLE001 - a crash in a verifier is itself a FAIL
        out.append(_line("chain:review", "FAIL", f"verify failed: {type(e).__name__}"))
    return out


def check_disk(path: Path, cfg: dict, usage=shutil.disk_usage) -> dict:
    m = cfg["monitor"]
    p = Path(path)
    while not p.exists() and p != p.parent:
        p = p.parent
    u = usage(p)
    free_gb, pct = u.free / 1e9, 100.0 * u.free / u.total if u.total else 0.0
    st = "FAIL" if free_gb < m["disk_fail_free_gb"] else ("WARN" if free_gb < m["disk_warn_free_gb"] or pct < m["disk_warn_free_pct"] else "OK")
    return _line("disk", st, f"{free_gb:.1f} GB free ({pct:.0f} %) on the volume of {p}", free_gb=round(free_gb, 2),
                 free_pct=round(pct, 1))


# ---------------------------------------------------------------- routing
def _alerts(checks: list[dict]) -> list[dict]:
    return [{"severity": "critical" if c["status"] == "FAIL" else "warning", "kind": "ops_" + c["check"].replace(":", "_"),
             "scope": "ops", "country": None, "message": f"{c['check']}: {c['detail']}", "value": c["status"],
             "threshold": None} for c in checks if c["status"] != "OK"]


def merge_alerts_json(out_dir: Path, alerts: list[dict], now: dt.datetime, prefix: str = "ops_") -> str:
    """Replace the previous rows of kind `prefix`* (default the monitor's ops_*) in outputs/alerts.json with these; every
    other row stays (the run's alerts, and the calendar_tests job's calendar_* rows, EQ-C-0095)."""
    p = out_dir / "alerts.json"
    doc = {}
    if p.exists():
        try:
            doc = json.loads(p.read_text())
        except (OSError, json.JSONDecodeError):
            doc = {}
    doc = doc if isinstance(doc, dict) else {}
    keep = [a for a in (doc.get("alerts") or []) if isinstance(a, dict) and not str(a.get("kind", "")).startswith(prefix)]
    allr = keep + alerts
    doc.setdefault("generated_at", _iso(now)); doc.setdefault("run_id", None)
    doc.update(alerts=allr, counts={s: sum(1 for a in allr if a.get("severity") == s) for s in ("critical", "warning", "info")},
               **{("ops_monitor_at" if prefix == "ops_" else prefix + "at"): _iso(now)})
    tmp = p.with_name(".alerts.json.tmp"); tmp.write_text(json.dumps(doc, indent=1, default=str)); tmp.replace(p)
    return str(p)


def route(report: dict, cfg: dict, out_dir: Path, now: dt.datetime) -> dict:
    """Local outputs always; email only as a dry run (never sends)."""
    alerts = _alerts(report["checks"])
    res = {"local": [str(out_dir / REPORT_NAME)], "email": "off"}
    if cfg["routing"]["local"]["alerts_json"]:
        res["local"].append(merge_alerts_json(out_dir, alerts, now))
    em = cfg["routing"]["email"]
    if not em["enabled"]:
        return res
    if _RANK[report["status"]] < _RANK[em["min_status"]]:
        res["email"] = f"nothing to send (status {report['status']}, min_status {em['min_status']})"
    elif not em["dry_run"]:
        res["email"] = ("refused: live alert email is not enabled in this build (dry_run must stay true; sending is "
                        "Sam's decision, through econquest distribute)")
    elif not em["to"]:
        res["email"] = "dry run: no recipients in routing.email.to"
    else:
        from ..validation.alerts import digest
        from .distribute import header_safe
        subject = header_safe(f"EconQuest ops monitor: {report['status']} ({len(alerts)} lines)", "subject")
        msg = {"generated_at": _iso(now), "dry_run": True, "to": em["to"], "subject": subject,
               "body": digest(alerts, "ops-monitor"), "sent": False}
        logs = out_dir / "logs"; logs.mkdir(parents=True, exist_ok=True)
        (logs / DRYRUN_NAME).write_text(json.dumps(msg, indent=1))
        res["email"] = f"dry run: would email {len(em['to'])} recipient(s); message in {logs / DRYRUN_NAME} (nothing sent)"
    return res


def check_install(data_dir: Path, env: dict | None = None, user_home=None) -> list[dict]:
    """EQ-C-0112: one WARN line per install warning (Downloads copy, no backup, data reset to the seed, fresh copy over a
    deleted folder), with the command to run; no line at all when the install looks right."""
    from .install_check import safe_warnings
    return [_line("install", "WARN", w["message"] + "".join(f" | $ {c}" for c in w["commands"]), warning=w["id"],
                  commands=w["commands"]) for w in safe_warnings(data_dir, env=env, user_home=user_home)]


# ---------------------------------------------------------------- entry points
def daily_monitor(data_dir, out_dir, now: dt.datetime | None = None, backup_dest=None, usage=shutil.disk_usage,
                  write: bool = True) -> dict:
    data_dir, out_dir = Path(data_dir), Path(out_dir)
    now = (now or dt.datetime.now(dt.timezone.utc)).astimezone(dt.timezone.utc)
    from . import schedule as S
    cfg = load_resilience(data_dir)
    sched_cfg = S.load_config(out_dir.parent)
    checks = [_slot_check("run", "morning", "store_run", sched_cfg, now, data_dir, out_dir),
              _slot_check("record", "record", "forecast_record", sched_cfg, now, data_dir, out_dir),
              check_backup(backup_dest, now, cfg), check_drill(out_dir, now, cfg),
              *check_chains(data_dir, out_dir), check_disk(out_dir, cfg, usage)]
    checks += check_install(data_dir)
    worst = max((c["status"] for c in checks), key=_RANK.__getitem__)
    report = {"generated_at": _iso(now), "status": worst, "targets": cfg["targets"], "config": cfg["source"], "checks": checks}
    if write:
        out_dir.mkdir(parents=True, exist_ok=True)
        report["routing"] = route(report, cfg, out_dir, now)
        p = out_dir / REPORT_NAME
        tmp = p.with_name("." + REPORT_NAME + ".tmp"); tmp.write_text(json.dumps(report, indent=1, default=str)); tmp.replace(p)
    return report


def format_lines(report: dict) -> list[str]:
    lines = [f"{c['status']:<5} {c['check']:<17} {c['detail']}" for c in report["checks"]]
    lines.append(f"{report['status']:<5} {'overall':<17} RPO {report['targets']['rpo_hours']:g} h, RTO {report['targets']['rto_hours']:g} h")
    for k, v in (report.get("routing") or {}).items():
        lines.append(f"{'':5} route:{k:<11} {', '.join(v) if isinstance(v, list) else v}")
    return lines


def run_from_args(args, data_dir, out_dir) -> int:
    try:
        r = daily_monitor(data_dir, out_dir, backup_dest=getattr(args, "backup_dest", None) or os.environ.get("ECONQUEST_BACKUP_DEST") or None)
    except ResilienceConfigError as e:
        print(f"FAIL  config            {e}")
        return 1
    for line in format_lines(r):
        print(line)
    return 1 if r["status"] == "FAIL" else 0
