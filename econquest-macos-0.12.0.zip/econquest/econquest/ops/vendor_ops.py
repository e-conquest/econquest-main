"""Licensed data operations (EQ-C-0117): scheduled vendor snapshots, entitlement audit and the vendor usage log.

ALL OFF until a licence row allows them. Turning any of it on is Sam's licence decision, never an agent's.

1. Scheduled vendor snapshots (job `vendor_snapshots`, JOB below). For each vendor (bloomberg, lseg) whose row in the
   APPROVED licence register (ops/licence_gov.py, `econquest change`) says terms_verified "yes" and internal_use "yes",
   the job takes a snapshot of the vendor's verified ticker-map rows through Team A's adapter
   (ingestion/market/vendors/pipeline.pull_to_store; runbook docs/runbooks/A-licensed-vendors.md). The adapter keeps
   its own licence gate (package + unexpired entitlement), so both must hold. With no such row, which is the case
   today (both rows say terms_verified UNVERIFIED), it prints "off: no licensed vendor" and does nothing: no adapter
   is built, no session opened, nothing written. Without --save every pull is a dry run (gated in memory, nothing
   saved). The job is NOT in schedule.DEFAULT_JOBS: `econquest schedule install` never writes its plist and
   `schedule check` never expects one; `schedule show` lists it as off (schedule.show -> show_lines). Adding it to
   ops.json "jobs" is part of Sam's licence decision (team/runbooks/C-vendor-ops.md).
2. Entitlement audit (`econquest vendor audit`): who (desk users in data/users.json, client subscribers in
   data/distribution.json, the NDA validator room) and which outputs (desk-internal versus client) may see each
   vendor's data, checked against the approved register and Team B's publish_guard (engine/layer2_bayesian.py), plus
   the vendor data actually stored (market snapshot index) or carried by outputs/run_latest.json, and the usage log.
   Writes outputs/reports/vendor/vendor-audit-<YYYYMMDD>.md and .json. Reads only; changes nothing.
3. Usage log: one JSON row per vendor-data read or use (vendor, dataset, purpose, output, actor, licence tag) in
   <out>/store/vendor_usage.jsonl, hash-chained like the operator action log (ops/actionlog.py) with the
   change-approval helpers (prev_hash / row_hash, a head file beside it). Append-only: verify() catches an edited,
   inserted, moved or removed row. outputs/store is covered by the nightly backup. No credential ever reaches it:
   only vendor slugs, dataset labels, purposes, output paths and the entitlement tag (a contract reference).

Never fetches in the cloud: tests use a fake vendor module and fixtures, and the snapshot path only ever runs for an
approved, terms-verified row, which no register holds today.

Rehearsal (EQ-C-0146, ops/vendor_rehearse.py, `econquest vendor rehearse`): eligibility, run_snapshots, job_status and
audit take an in-memory `register` (rows) ONLY for a SIMULATED sandbox data folder (Team A's vendor_sim_guard rule:
marker, outside the econquest folder, no desk data files); any other folder raises VendorOpsError. There is no setting
or environment variable for it, and the real job on data/ never sees it.
"""
from __future__ import annotations

import argparse
import contextlib
import datetime as dt
import json
import os
import re
import sys
from pathlib import Path

from .approvals import GENESIS, _atomic_write, _ts, row_hash

try:
    import fcntl
except ImportError:                                     # pragma: no cover - Windows
    fcntl = None

TICKET = "EQ-C-0117"
VENDORS = ("bloomberg", "lseg")
JOB_NAME = "vendor_snapshots"
OFF = "off: no licensed vendor"
DECISION = "turning this on is Sam's licence decision (team/runbooks/C-vendor-ops.md)"
# The job as it would be installed: weekdays 18:45 New York, after the record job. Not in schedule.DEFAULT_JOBS.
JOB = {"hour": 18, "minute": 45, "weekdays": [1, 2, 3, 4, 5], "max_minutes": 20, "evidence": "job", "off": True,
       "steps": [["{python}", "-m", "econquest.ops.vendor_ops", "snapshot", "--home", "{home}", "--as-of", "{as_of}",
                  "--save"]]}
USAGE_NAME = "vendor_usage.jsonl"
USAGE_HEAD = "vendor_usage.head.json"
PURPOSES = ("snapshot", "dry_run", "internal_output", "client_output", "validator", "audit", "other")
CLIENT_PURPOSES = ("client_output",)
USAGE_FIELDS = ("seq", "ts_utc", "vendor", "dataset", "purpose", "output", "actor", "licence", "detail", "prev_hash",
                "row_hash")
INTERNAL_OUTPUTS = ("econquest run / report (internal)", "GUI and local API", "ops and monitoring reports")
CLIENT_OUTPUTS = ("Sheets publish", "client-pack / client-export", "distribute (subscribers)", "client country notes")
VENDOR_RE = re.compile(r"[a-z][a-z0-9_-]{0,31}")
_CTRL = re.compile(r"[\x00-\x1f\x7f\x85  ]")


class VendorOpsError(ValueError):
    """Bad input to the usage log or the job."""


SANDBOX_REGISTER = "SIMULATED sandbox register (EQ-C-0146 rehearsal; not an approval)"


def _sandbox_only(data_dir) -> None:
    """EQ-C-0146: an in-memory register is taken only for a SIMULATED sandbox data folder (vendor_sim_guard)."""
    from ..ingestion.market import vendor_sim_guard as SG
    why = SG.sandbox_problem(data_dir)
    if why:
        raise VendorOpsError(f"an in-memory licence register is accepted only for a {SG.LABEL} sandbox data folder: {why}")


def _clip(s, n: int = 300) -> str:
    return _CTRL.sub(" ", str(s if s is not None else ""))[:n]


def _home_dirs(home) -> tuple[Path, Path]:
    h = Path(home)
    return h / "data", h / "outputs"


# ---------------------------------------------------------------- licence rows: the switch
def eligibility(data_dir, register: list[dict] | None = None) -> dict:
    """{"register": governance status, "vendors": [{vendor, eligible, reason, row}], "eligible": [slugs], "state"}.
    A vendor is eligible only when the APPROVED register (status "ok"; never drift, demo or no baseline) has a row for
    it with terms_verified "yes" and internal_use "yes". Never raises, except VendorOpsError when `register` (the
    EQ-C-0146 rehearsal's in-memory rows) is given for a folder that is not a SIMULATED sandbox."""
    from . import licence_gov as G
    from ..ingestion import licences as A
    d = Path(data_dir)
    if register is not None:
        _sandbox_only(d)
        st = {"status": SANDBOX_REGISTER}
    else:
        st = G.state(d)
    out = {"register": st["status"], "vendors": [], "eligible": []}
    rows = [dict(r) for r in register] if register is not None else None
    if st["status"] == "ok":
        try:
            rows = G.parse(G.approved_bytes(d, st) or b"", "approved data/licences.csv")
        except G.LicenceGovError as e:
            out["register"] = f"unreadable ({_clip(e, 120)})"
    for v in VENDORS:
        rec = {"vendor": v, "eligible": False, "row": None}
        if rows is None:
            rec["reason"] = (f"licence register has no trusted approved version (status {out['register']}); "
                             "vendor operations stay off")
        else:
            hit = A.licence_for(source=v, licence=f"{v}:licence (desk-internal)", register=rows)
            if not hit:
                rec["reason"] = "no row for this vendor in the approved register"
            else:
                keep = ("source_id", "terms_verified", "commercial", "internal_use", "client_output", "validator_nda")
                rec["row"] = {k: str(hit.get(k, "")) for k in keep}
                if hit.get("terms_verified") != "yes":
                    rec["reason"] = f"row {hit.get('source_id')}: terms_verified {hit.get('terms_verified') or 'blank'}"
                elif hit.get("internal_use") != "yes":
                    rec["reason"] = f"row {hit.get('source_id')}: internal_use {hit.get('internal_use') or 'blank'}"
                else:
                    rec.update(eligible=True, reason=f"row {hit.get('source_id')}: terms verified, internal use yes")
        out["vendors"].append(rec)
        if rec["eligible"]:
            out["eligible"].append(v)
    out["state"] = "on" if out["eligible"] else "off"
    return out


def job_status(data_dir, register: list[dict] | None = None) -> dict:
    """The one-line state `schedule show` prints for the job."""
    e = eligibility(data_dir, register)
    if not e["eligible"]:
        return {"state": "off", "summary": f"{OFF} (" + "; ".join(f"{r['vendor']}: {r['reason']}" for r in e["vendors"])
                + ")", "eligible": []}
    return {"state": "licensed", "summary": "licence row allows " + ", ".join(e["eligible"])
            + "; still not installed: add it to ops.json jobs (" + DECISION + ")", "eligible": e["eligible"]}


def show_lines(home, cfg: dict | None = None) -> tuple[list[str], dict]:
    """Lines and row for `schedule show`. Reads only; the installed schedule is never touched."""
    st = job_status(Path(home) / "data")
    installed = JOB_NAME in ((cfg or {}).get("jobs") or {})
    when = f"{JOB['hour']:02d}:{JOB['minute']:02d} {(cfg or {}).get('tz', 'America/New_York')} on MTWTF"
    line = (f"{JOB_NAME:8s} {when:38s} {'in ops.json' if installed else 'off':14s} {st['summary']}")
    return [line], {"when": when, "off": not installed, "state": st["state"], "summary": st["summary"],
                    "in_schedule": installed}


# ---------------------------------------------------------------- usage log (append-only, hash-chained)
def usage_path(out_dir) -> Path:
    return Path(out_dir) / "store" / USAGE_NAME


def _head_path(out_dir) -> Path:
    return usage_path(out_dir).with_name(USAGE_HEAD)


@contextlib.contextmanager
def _locked(out_dir):
    p = usage_path(out_dir)
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p.with_name(".vendor_usage.lock"), "a") as f:
        if fcntl is not None:
            fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            if fcntl is not None:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)


def _rows(p: Path) -> list[dict]:
    out = []
    if p.exists():
        for line in p.read_text(encoding="utf-8").splitlines():
            if line.strip():
                try:
                    out.append(json.loads(line))
                except json.JSONDecodeError:
                    out.append({})
    return out


def record_use(out_dir, vendor: str, dataset: str, purpose: str, output: str = "", actor: str = "", licence: str = "",
               detail: str = "", now=None) -> dict:
    """Append one usage row. purpose is one of PURPOSES. Refuses (VendorOpsError) a bad vendor slug or purpose."""
    vendor = str(vendor or "").strip().casefold()
    if not VENDOR_RE.fullmatch(vendor):
        raise VendorOpsError("vendor must be a lower-case slug such as bloomberg or lseg")
    if purpose not in PURPOSES:
        raise VendorOpsError(f"purpose must be one of {', '.join(PURPOSES)}")
    if not str(dataset or "").strip():
        raise VendorOpsError("dataset is required")
    with _locked(out_dir):
        p = usage_path(out_dir)
        rows = _rows(p)
        last = next((r for r in reversed(rows) if r.get("row_hash")), None)
        prev = last["row_hash"] if last else GENESIS
        row = {"seq": len(rows) + 1, "ts_utc": _ts(now), "vendor": vendor, "dataset": _clip(dataset, 200),
               "purpose": purpose, "output": _clip(output, 300), "actor": _clip(actor, 80) or os.environ.get("USER", ""),
               "licence": _clip(licence, 120), "detail": _clip(detail, 500), "prev_hash": prev}
        row["row_hash"] = row_hash(prev, row)
        with open(p, "a", encoding="utf-8") as f:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")
            f.flush()
            os.fsync(f.fileno())
        _atomic_write(_head_path(out_dir), (json.dumps({"seq": row["seq"], "row_hash": row["row_hash"]}) + "\n").encode())
        return row


def read_usage(out_dir) -> list[dict]:
    return [r for r in _rows(usage_path(out_dir)) if r]


def verify_usage(out_dir) -> dict:
    """seq 1..n, each prev_hash = previous row_hash, each row_hash recomputes, the head names the last row."""
    p = usage_path(out_dir)
    errors, rows, prev = [], [], GENESIS
    lines = p.read_text(encoding="utf-8").splitlines() if p.exists() else []
    for i, line in enumerate(lines, 1):
        try:
            r = json.loads(line)
        except json.JSONDecodeError:
            errors.append(f"line {i}: not JSON")
            prev = None
            continue
        if r.get("seq") != len(rows) + 1:
            errors.append(f"line {i}: seq {r.get('seq')} where {len(rows) + 1} expected (row deleted, inserted or moved)")
        if prev is not None and r.get("prev_hash") != prev:
            errors.append(f"line {i}: prev_hash does not match the previous row")
        if r.get("row_hash") != row_hash(str(r.get("prev_hash", "")), r):
            errors.append(f"line {i}: row_hash does not recompute (row edited)")
        prev = r.get("row_hash")
        rows.append(r)
    hp = _head_path(out_dir)
    head = None
    if hp.exists():
        try:
            head = json.loads(hp.read_text())
        except json.JSONDecodeError:
            errors.append(f"{USAGE_HEAD} is not JSON")
    elif rows:
        errors.append(f"{USAGE_HEAD} missing")
    if isinstance(head, dict):
        last = rows[-1] if rows else {"seq": 0, "row_hash": GENESIS}
        if head.get("seq") != last.get("seq") or head.get("row_hash") != last.get("row_hash"):
            errors.append(f"{USAGE_HEAD} names seq {head.get('seq')} but the log ends at seq {last.get('seq')} "
                          "(rows removed from or added to the end)")
    return {"ok": not errors, "rows": len(rows), "errors": errors, "path": str(p)}


# ---------------------------------------------------------------- 1. the scheduled snapshot job
def _adapter(vendor, data_dir, factory, env, today):
    if factory is not None:
        return factory(vendor, data_dir)
    from ..ingestion.market.vendors import get_adapter
    kw = {"data_dir": Path(data_dir)}
    if env is not None:
        kw["env"] = env
    if today is not None:
        kw["today"] = today
    return get_adapter(vendor, **kw)


def run_snapshots(data_dir, out_dir, as_of=None, save: bool = False, adapter_factory=None, env=None, today=None,
                  actor: str = "", log=print, register: list[dict] | None = None) -> dict:
    """The job body. Off (no adapter built, nothing written) unless a vendor is eligible. Returns
    {"state", "vendors": [{vendor, result, ...}], "exit"}; exit 0 off or all ok, 1 when an eligible vendor failed.
    `register`: the EQ-C-0146 rehearsal only (a SIMULATED sandbox data folder; VendorOpsError anywhere else)."""
    data_dir, out_dir = Path(data_dir), Path(out_dir)
    e = eligibility(data_dir, register)
    if not e["eligible"]:
        msg = f"{JOB_NAME}: {OFF}; nothing requested, nothing written ({DECISION})"
        log(msg)
        return {"state": "off", "message": msg, "vendors": e["vendors"], "exit": 0}
    from ..ingestion.market import MarketDataError
    from ..ingestion.market.vendors import VendorConnectionError, VendorNotLicensed, VendorRequestError
    from ..ingestion.market.vendors.pipeline import pull_to_store
    done, rc = [], 0
    for v in e["eligible"]:
        rec = {"vendor": v}
        try:
            a = _adapter(v, data_dir, adapter_factory, env, today)
            st = a.licence_state()
            if not st.usable:
                rec.update(result="skipped", why="adapter licence gate: " + _clip(" | ".join(st.problems), 400))
                rc = 1
                done.append(rec)
                log(f"{JOB_NAME}: {v} skipped: {rec['why']}")
                continue
            m = a.ticker_map()
            tickers = [t for t, s in zip(m["vendor_ticker"], m["status"]) if str(s).casefold() == "verified"]
            if not tickers:
                rec.update(result="skipped", why="no verified ticker-map rows for this vendor (runbook section 3)")
                done.append(rec)
                log(f"{JOB_NAME}: {v} skipped: {rec['why']}")
                continue
            res = pull_to_store(a, data_dir, tickers, as_of=as_of, dry_run=not save)
            snap = getattr(res, "snapshot", None)
            out = str(snap) if (save and snap is not None) else "(dry run: nothing saved)"
            rec.update(result="saved" if save and snap is not None else "dry_run", rows=int(len(res.rows)),
                       tickers=len(tickers), output=out, summary=_clip(res.summary(), 300))
            record_use(out_dir, v, f"market snapshot ({len(tickers)} verified tickers, as of {as_of or 'latest'})",
                       "snapshot" if save else "dry_run", out, actor=actor or JOB_NAME,
                       licence=st.entitlement.tag if st.entitlement else "", detail=rec["summary"])
            log(f"{JOB_NAME}: {v} {rec['result']}: {rec['summary']}")
        except (VendorNotLicensed, VendorRequestError, VendorConnectionError, MarketDataError, OSError) as ex:
            rec.update(result="error", why=_clip(ex, 400))
            rc = 1
            log(f"{JOB_NAME}: {v} error: {rec['why']}")
        done.append(rec)
    return {"state": "on", "vendors": done, "exit": rc}


# ---------------------------------------------------------------- 2. entitlement audit
def _client_cleared(tag: str, rows) -> tuple[bool, str]:
    """Team B's publish_guard on a one-row table carrying `tag`: (cleared, reason)."""
    import pandas as pd
    from ..engine.layer2_bayesian import publish_guard
    try:
        publish_guard(pd.DataFrame({"market_licence": [tag]}, index=["probe"]), register=rows)
    except ValueError as e:
        return False, _clip(e, 300)
    return True, "publish_guard passes"


def _users(data_dir) -> list[str]:
    try:
        doc = json.loads((Path(data_dir) / "users.json").read_text(encoding="utf-8"))
        return [f"{u.get('id')} ({u.get('role')})" for u in doc.get("users", []) if u.get("active")]
    except (OSError, ValueError, AttributeError):
        return []


def _subscribers(data_dir) -> dict:
    try:
        doc = json.loads((Path(data_dir) / "distribution.json").read_text(encoding="utf-8"))
        return {k: len(v or []) for k, v in (doc.get("subscribers") or {}).items()}
    except (OSError, ValueError, AttributeError):
        return {}


def _stored(data_dir) -> dict:
    try:
        from ..ingestion.market.store import list_market_snapshots
        ix = list_market_snapshots(Path(data_dir))
    except Exception:                                    # noqa: BLE001 - an unreadable index is reported, not fatal
        return {v: {"snapshots": None, "last": ""} for v in VENDORS}
    out = {}
    for v in VENDORS:
        hit = ix[ix["sources"].astype(str).str.contains(rf"\b{v}\b", regex=True)] if len(ix) else ix
        out[v] = {"snapshots": int(len(hit)), "last": str(hit["saved_utc"].iloc[-1]) if len(hit) else ""}
    return out


def _run_tags(out_dir) -> list[str]:
    try:
        doc = json.loads((Path(out_dir) / "run_latest.json").read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return []
    rows = doc.get("country") if isinstance(doc, dict) else None
    tags = {str(r.get("market_licence") or "").strip() for r in rows or [] if isinstance(r, dict)}
    return sorted(t for t in tags if t)


def audit(data_dir, out_dir, now: dt.datetime | None = None, adapter_factory=None, env=None, today=None,
          write: bool = True, report_dir=None, register: list[dict] | None = None) -> dict:
    """The entitlement audit. Reads only, except the report files (and one 'audit' usage row only when vendor data
    is present). Returns the report dict with 'paths' when written. `register`: the EQ-C-0146 rehearsal only (a
    SIMULATED sandbox data folder; VendorOpsError anywhere else)."""
    from . import licence_gov as G
    data_dir, outs = Path(data_dir), Path(out_dir)
    report_dir = Path(report_dir) if report_dir else outs / "reports" / "vendor"
    now = now or dt.datetime.now(dt.timezone.utc)
    e = eligibility(data_dir, register)
    st = {"status": SANDBOX_REGISTER} if register is not None else G.state(data_dir)
    rows = [dict(r) for r in register] if register is not None else None
    if st["status"] == "ok":
        try:
            rows = G.parse(G.approved_bytes(data_dir, st) or b"", "approved data/licences.csv")
        except G.LicenceGovError:
            rows = None
    stored = _stored(data_dir)
    usage = read_usage(outs)
    chain = verify_usage(outs)
    run_tags = _run_tags(outs)
    users, subs = _users(data_dir), _subscribers(data_dir)
    findings, vendors = [], []
    for rec in e["vendors"]:
        v = rec["vendor"]
        ent = {"configured": False, "usable": False, "scope": "", "expiry": "", "licence_id": "", "problems": []}
        try:
            a = _adapter(v, data_dir, adapter_factory, env, today)
            ls = a.licence_state()
            en = ls.entitlement
            ent = {"configured": en is not None, "usable": bool(ls.usable), "scope": en.scope if en else "",
                   "expiry": en.expiry.isoformat() if en else "", "licence_id": en.licence_id if en else "",
                   "problems": [_clip(p, 200) for p in ls.problems]}
        except Exception as ex:                          # noqa: BLE001 - the audit reports, never crashes
            ent["problems"] = [f"adapter not built ({type(ex).__name__})"]
        row = rec["row"] or {}
        tag = f"{v}:{ent['licence_id'] or 'none'} ({ent['scope'] or 'desk-internal'})"
        internal_ok = rec["eligible"] and ent["usable"]
        if rows is not None:
            client_ok, client_why = _client_cleared(tag, rows)
        else:
            client_ok, client_why = False, f"no trusted approved register (status {st['status']})"
        client_ok = client_ok and internal_ok
        validator_ok = internal_ok and row.get("validator_nda") == "allowed" and ent["scope"] == "redistribution"
        aud = {"desk_internal": {"allowed": internal_ok, "who": users, "outputs": list(INTERNAL_OUTPUTS),
                                 "why": rec["reason"] if not rec["eligible"] else
                                 ("entitlement usable" if ent["usable"] else "adapter licence gate: " +
                                  "; ".join(ent["problems"]) or "not usable")},
               "client": {"allowed": client_ok, "who": {k: n for k, n in subs.items()}, "outputs": list(CLIENT_OUTPUTS),
                          "why": client_why if internal_ok or rows is None else
                          f"desk-internal use not cleared ({rec['reason']}); {client_why}"},
               "validator": {"allowed": validator_ok, "who": ["NDA validator room"],
                             "why": f"validator_nda {row.get('validator_nda') or 'n/a'}, scope {ent['scope'] or 'none'}"}}
        used = [u for u in usage if u.get("vendor") == v]
        n_stored = stored[v]["snapshots"]
        carried = [t for t in run_tags if t.startswith(f"{v}:")]
        if (n_stored or carried or used) and not rec["eligible"]:
            findings.append({"severity": "problem", "vendor": v, "what": f"{v} data present ({n_stored or 0} stored "
                             f"snapshots, {len(carried)} run_latest tags, {len(used)} usage rows) but the approved "
                             f"register does not allow it: {rec['reason']}"})
        if ent["scope"] == "desk-internal" and row.get("client_output") == "allowed":
            findings.append({"severity": "problem", "vendor": v, "what": "entitlement is desk-internal but the register "
                             "row allows client output: tighten the row (econquest change)"})
        for u in used:
            if u.get("purpose") in CLIENT_PURPOSES and not client_ok:
                findings.append({"severity": "problem", "vendor": v, "what": f"usage row {u.get('seq')} sent {v} data "
                                 f"to a client output ({_clip(u.get('output'), 120)}) without client clearance"})
            if u.get("purpose") == "validator" and not validator_ok:
                findings.append({"severity": "problem", "vendor": v, "what": f"usage row {u.get('seq')} gave {v} data "
                                 "to the validator room without clearance"})
        for t in carried:
            ok, why = _client_cleared(t, rows) if rows is not None else (False, "no approved register")
            if not ok:
                findings.append({"severity": "info", "vendor": v, "what": f"outputs/run_latest.json carries {t}: "
                                 "publish and client outputs refuse this run (publish_guard)"})
        vendors.append({"vendor": v, "eligible": rec["eligible"], "reason": rec["reason"], "row": row,
                        "entitlement": ent, "audiences": aud, "stored": stored[v], "run_latest_tags": carried,
                        "usage_rows": len(used)})
    if not chain["ok"]:
        findings.append({"severity": "problem", "vendor": "", "what": "vendor usage log does not verify: "
                         + "; ".join(chain["errors"][:3])})
    rep = {"ticket": TICKET, "generated_utc": now.strftime("%Y-%m-%dT%H:%M:%SZ"), "register": st["status"],
           "job": job_status(data_dir, register), "vendors": vendors, "usage_log": {k: chain[k] for k in ("ok", "rows", "path")},
           "findings": findings, "problems": sum(f["severity"] == "problem" for f in findings),
           "note": "INTERNAL. Reads only: no adapter session, no register change, no entitlement written. Every "
                   "permission here comes from the approved licence register and Team B's publish_guard; loosening "
                   "any of it is Sam's licence decision."}
    if write:
        report_dir.mkdir(parents=True, exist_ok=True)
        stem = report_dir / f"vendor-audit-{now.strftime('%Y%m%d')}"
        md, js = stem.with_suffix(".md"), stem.with_suffix(".json")
        _atomic_write(js, (json.dumps(rep, indent=1, default=str) + "\n").encode())
        _atomic_write(md, render_audit(rep).encode())
        rep["paths"] = [str(md), str(js)]
    return rep


def _yn(b) -> str:
    return "yes" if b else "no"


def render_audit(rep: dict) -> str:
    L = [f"# Vendor entitlement audit ({rep['generated_utc']}, {TICKET})", "", rep["note"], "",
         f"- Licence register: {rep['register']}", f"- Scheduled snapshots ({JOB_NAME}): {rep['job']['summary']}",
         f"- Usage log: {rep['usage_log']['rows']} rows, verifies: {_yn(rep['usage_log']['ok'])}", "",
         "| Vendor | Register row | Entitlement | Desk-internal | Client | Validator | Stored snapshots | Usage rows |",
         "|---|---|---|---|---|---|---|---|"]
    for v in rep["vendors"]:
        r, en, a = v["row"], v["entitlement"], v["audiences"]
        rowtxt = (f"terms {r.get('terms_verified')}, internal {r.get('internal_use')}, client {r.get('client_output')}"
                  if r else "none")
        entx = f"{en['scope']} to {en['expiry']}" if en["configured"] else "not configured"
        L.append(f"| {v['vendor']} | {rowtxt} | {entx} | {_yn(a['desk_internal']['allowed'])} | "
                 f"{_yn(a['client']['allowed'])} | {_yn(a['validator']['allowed'])} | {v['stored']['snapshots']} | "
                 f"{v['usage_rows']} |")
    L += ["", "## Who and which outputs", ""]
    for v in rep["vendors"]:
        a = v["audiences"]
        L.append(f"### {v['vendor']}")
        L.append(f"- Desk-internal ({_yn(a['desk_internal']['allowed'])}): users {', '.join(a['desk_internal']['who']) or 'none'}; "
                 f"outputs {', '.join(a['desk_internal']['outputs'])}. Why: {a['desk_internal']['why']}")
        subs = ", ".join(f"{k} {n}" for k, n in a["client"]["who"].items()) or "none"
        L.append(f"- Client ({_yn(a['client']['allowed'])}): subscribers {subs}; outputs {', '.join(a['client']['outputs'])}. "
                 f"Why: {a['client']['why']}")
        L.append(f"- Validator room ({_yn(a['validator']['allowed'])}): {a['validator']['why']}")
        L.append("")
    L += ["## Findings", ""]
    L += [f"- [{f['severity']}] {f['what']}" for f in rep["findings"]] or ["- none"]
    return "\n".join(L) + "\n"


# ---------------------------------------------------------------- command line
def add_cli(vds) -> None:
    """Subcommands under `econquest vendor` (cli.py): audit, usage, snapshots."""
    v = vds.add_parser("audit", help=f"entitlement audit ({TICKET}): who and which outputs (desk-internal vs client) may "
                       "see each vendor's data, checked against the approved licence register and publish_guard; "
                       "writes outputs/reports/vendor/vendor-audit-<date>.md/.json; exit 1 on a problem finding")
    v.add_argument("--report-dir", help="report folder (default <out>/reports/vendor)")
    v.add_argument("--json", action="store_true")
    v = vds.add_parser("usage", help=f"vendor-data usage log ({TICKET}, outputs/store/vendor_usage.jsonl): show the "
                       "last rows, --verify the hash chain, or --record a use")
    v.add_argument("--verify", action="store_true"); v.add_argument("--tail", type=int, default=20)
    v.add_argument("--record", action="store_true", help="append a row (needs --vendor, --dataset, --purpose)")
    v.add_argument("--vendor", dest="usage_vendor"); v.add_argument("--dataset")
    v.add_argument("--purpose", choices=PURPOSES); v.add_argument("--output", default="")
    v.add_argument("--actor", default="")
    v = vds.add_parser("snapshots", help=f"the scheduled vendor snapshot job ({JOB_NAME}, {TICKET}): OFF until an "
                       "approved licence row has terms_verified yes; dry run unless --save")
    v.add_argument("--as-of", "--asof", dest="asof"); v.add_argument("--save", action="store_true",
                                                                     help="save snapshots (job only; Sam's licence call)")
    v.add_argument("--status", action="store_true", help="print the job state only")
    from .vendor_rehearse import add_cli as _rehearse_cli      # EQ-C-0146: SIMULATED rehearsal on Team A's simulator
    _rehearse_cli(vds)


def run_cli(args) -> int:
    """`econquest vendor audit|usage|snapshots|rehearse` (cli.cmd_vendor), on the top-level --data and --out folders."""
    data_dir, out_dir = Path(args.data), Path(args.out)
    c = args.vendor_cmd
    if c == "rehearse":                                    # EQ-C-0146: sandbox outside the econquest folder only
        from .vendor_rehearse import run_cli as _rehearse
        return _rehearse(args)
    if c == "audit":
        rep = audit(data_dir, out_dir, report_dir=args.report_dir)
        print(json.dumps(rep, indent=1, default=str) if args.json else render_audit(rep))
        if rep.get("paths"):
            print("wrote " + ", ".join(rep["paths"]))
        return 1 if rep["problems"] else 0
    if c == "usage":
        if args.record:
            try:
                r = record_use(out_dir, args.usage_vendor, args.dataset, args.purpose, args.output, args.actor)
            except VendorOpsError as e:
                print(f"vendor usage: {e}", file=sys.stderr)
                return 2
            print(f"recorded usage row {r['seq']}")
            return 0
        if args.verify:
            v = verify_usage(out_dir)
            print(f"vendor usage log {v['path']}: {v['rows']} rows, " + ("verifies" if v["ok"] else "BROKEN"))
            for e in v["errors"]:
                print("  " + e)
            return 0 if v["ok"] else 1
        for r in read_usage(out_dir)[-max(args.tail, 0):] if args.tail else read_usage(out_dir):
            print(f"{r.get('seq'):>5}  {str(r.get('ts_utc'))[:19]}  {r.get('vendor')}  {r.get('purpose')}  "
                  f"{r.get('dataset')}  -> {r.get('output') or '-'}")
        return 0
    if args.status:
        s = job_status(data_dir)
        print(f"{JOB_NAME}: {s['summary']}")
        return 0
    return run_snapshots(data_dir, out_dir, as_of=args.asof, save=args.save)["exit"]


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ops.vendor_ops", description=__doc__.splitlines()[0])
    ap.add_argument("action", choices=["snapshot", "status", "audit"])
    ap.add_argument("--home", default=os.environ.get("ECONQUEST_HOME", str(Path.home() / "econquest")))
    ap.add_argument("--as-of", dest="asof"); ap.add_argument("--save", action="store_true")
    a = ap.parse_args(argv)
    if a.action == "status":
        print(f"{JOB_NAME}: {job_status(Path(a.home) / 'data')['summary']}")
        return 0
    if a.action == "audit":
        return 1 if audit(*_home_dirs(a.home))["problems"] else 0
    return run_snapshots(*_home_dirs(a.home), as_of=a.asof, save=a.save)["exit"]


if __name__ == "__main__":
    sys.exit(main())
