"""Health check (EQ-C-0021), run every 15 minutes by launchd: writes outputs/health.json and sends new alerts through
validation.alerts.deliver_alerts (webhook / email when configured).

Checks
  missed_run   For each scheduled job, the latest slot whose deadline has passed: slot time (in the schedule's tz,
               default America/New_York) + the job's max_minutes = deadline; flagged once deadline + grace (15 min)
               has passed without evidence. Weekday jobs count business days only: Monday to Friday, minus the
               optional `holidays` list (no exchange holiday calendar is built in). Evidence:
                 record   a row in data/forecast_record.csv recorded at or after the slot (recorded_at, "backfill" rows
                          too) - the run is archived in the forecast record
                 morning  a run in outputs/store (label base) created at or after the slot - archived in the run store
                 model_monitoring  outputs/monitoring/monitoring_alerts.json modified at or after the slot
                          (EVIDENCE_FILES; HO-20261024-B-C-007)
                 others   outputs/logs/jobs/<job>.last.json ended ok at or after the slot
               Monthly jobs ("day": 1-28) are due on that day of the month only (lookback 31 days).
               Slots before the schedule was installed (outputs/logs/schedule.json installed_at) are not checked, and
               with no schedule.json this check reports "not installed" and raises nothing.
  stale_feed   The newest live pull (data/live/feeds.json "retrieved", or the newest data/live/vintages/<date...>
               folder) is older than stale_feed_days (default 7); a feed whose status is not "ok"; no pull at all.
  job_failed   <job>.last.json has a non-zero exit code; job_hung: status running for more than 2 x max_minutes.
               Steps with a known exit-code contract (STEP_CODES; the data_ops job, HO-20261024-A-C-012) are reported
               per step instead: events_mapping_breach / freshness_breach (exit 2), events_incremental_error /
               freshness_error (any other non-zero code). The SLA check is per series and country; it complements
               stale_feed, which looks at the whole pull. The data_ops prices step (freshness prices, EQ-A-0119,
               HO-20261025-A-C-028) reports freshness_prices (exit 2: a prices.csv column older than the 30-day
               official FX SLA) or freshness_prices_error. A breach is a warning, never a stop. Breaches are standing
               (STANDING_KINDS): the shared data's freshness check exits 2 every day from the cells in
               docs/runbooks/A-sam-ready.md item 13, so the alert key has no run time: it is delivered once and stays
               listed until a run is clear (a breach that comes back is sent again). Errors are sent for every run.
  record_mode  which prices mode the record job is installed in (ops.json record_job_apply_prices: staged by
               default, apply when true; pending_reinstall when ops.json changed since install). Information only.
  approvals_log  data/approvals/log.jsonl is missing or has no rows (EQ-C-0050, SEC-C-005 R1). Unconditional on
               purpose: the release ships a non-empty log (the baselines), so a missing or empty one means data/approvals/
               was deleted or never installed, and every governed file (assumptions, limits, compliance) then reads as
               never governed. Comparing assumptions.json with a "shipped default" would need a reference copy that the
               same deletion can remove, and it misses the compliance.json case R1 is about.
  review_ledger  Team A's ingestion.ledger.verify_ledger on data/live/review_ledger.csv (EQ-A-0103, HO-20261025-A-C-024):
               a broken hash chain is a critical alert and makes `econquest health` exit 1 (with or without --strict);
               its notes (legacy unchained rows written before 0.6.0, no ledger yet) are printed as information. A
               missing ledger is not a failure. `health --daily` checks it too (monitor chain:review).
  vendor_capture_*  licensed go-live capture jobs (EQ-A-0107, HO-20261025-A-C-023; only when ops.json adds one): job
               evidence like any other job; exit 2 = nothing passed the gates, other non-zero = refused; the newest
               data/live/market/snapshots/golive/<stamp>-<vendor>/report.json gives the saved / held counts.
  clock_skew   (EQ-C-0164) a job the wrapper refused because the clock read earlier than the job record (jobs.py clock
               guard, exit 78) is a critical alert; a started_at / ended_at in any <job>.last.json more than 10 minutes
               AFTER now (the clock went back, or ran ahead earlier) is a warning: until it is fixed a hung job cannot
               be told from a running one and missed-run evidence can be wrong.
  calendar_event  Team A's event calendar (EQ-C-0155, presentation.calendar_view.alert_rows): an event at or above
               importance event_alert_min_importance (ops.json, default 2) whose period overlaps the next
               event_alert_days (default 30) days from today (UTC). Importance 3 is a warning, 2 is info. One key per
               event and date (calendar_event:<event_id>:<date>): sent once, listed while it stays in the window, sent
               again only when the event is re-dated. Rows carry ALERT_FIELDS only. Today's World Bank debt-service rows
               are importance 1 and never alert at the default threshold. An unreadable calendar is a check row
               (status error), never an alert.

Alerts use the validation.alerts dict shape (severity, kind, scope, country, message, value, threshold). An alert is
delivered once: health.json keeps the keys already sent, and a key that clears and comes back is sent again.
"""
from __future__ import annotations
import argparse
import datetime as dt
import json
import os
import sys
from pathlib import Path

import pandas as pd

from . import schedule as _schedule
from .jobs import last_runs

SEV = {"record": "critical", "morning": "critical"}
# step marker (module in the step's argv) -> exit code -> (kind, what it means); "error" = any other non-zero code
STEP_CODES = {
    "econquest.ingestion.events.incremental": {
        2: ("events_mapping_breach", "UCDP/GDELT country-mapping QA breach: unmapped share above threshold (GDELT vintage "
                                     "saved, UCDP pull refused)"),
        "error": ("events_incremental_error", "incremental UCDP/GDELT pull failed (token missing, incomplete GDELT day, "
                                              "lock busy or no stored vintage)")},
    "econquest.ops.calendar_jobs": {                        # calendar-gated formal tests (EQ-C-0095)
        2: ("calendar_test_alert", "a calendar-gated formal test is due, overdue, needs review or failed; see "
                                   "outputs/calendar_tests.json and the Readiness tab"),
        "error": ("calendar_test_error", "calendar tests job could not read the evidence monitor or the forecast scorecard")},
    "econquest.ingestion.dq_report": {                      # monthly DQ report (EQ-A-0065, HO-20261024-A-C-018)
        2: ("dq_report_findings", "monthly data quality report has findings (staleness breach, incident, coverage below the "
                                  "60% feed-eligible target, or no pull in the month); see outputs/dq/<month>/dq_report.md"),
        "error": ("dq_report_error", "monthly data quality report could not read an input or failed; the report names the "
                                     "section under Errors")},
    "econquest.validation.benchmark_job": {                 # monthly benchmark snapshot (EQ-B-0125, HO-20261026-B-C-003)
        2: ("benchmark_unexplained_drift", "monthly benchmark snapshot written with unexplained drift against the "
                                           "previous snapshot (no recorded change id); see "
                                           "outputs/benchmarks/<month>/drift.md"),
        "error": ("benchmark_snapshot_error", "monthly benchmark snapshot job failed (input or pipeline error); see "
                                              "outputs/logs/benchmark_snapshot.err.log")},
    "econquest.ingestion.market.vendors.golive": {          # licensed go-live capture (EQ-A-0107, HO-20261025-A-C-023)
        2: ("vendor_capture_nothing_saved", "licensed vendor capture: nothing passed the gates, no snapshot saved; held rows "
                                            "and the reasons are in data/live/market/snapshots/golive/<stamp>-<vendor>/"),
        "error": ("vendor_capture_refused", "licensed vendor capture refused (licence gate, register row not approved, "
                                            "ticker map or session error)")},
    # before the generic freshness marker: the first marker found in the step's args wins
    "econquest.ingestion.freshness prices": {             # record input prices.csv (EQ-A-0119, HO-20261025-A-C-028)
        2: ("freshness_prices", "official FX prices for the record (data/market_history/prices.csv) older than the "
                                "30-day SLA in one or more columns; record still runs; see `python -m "
                                "econquest.ingestion.freshness prices`"),
        "error": ("freshness_prices_error", "prices freshness check could not run (no data/market_history/prices.csv "
                                            "or no fx3m row in data/live/freshness_sla.csv)")},
    "econquest.ingestion.freshness": {
        2: ("freshness_breach", "freshness SLA breached for one or more series (data/live/freshness_sla.csv)"),
        "error": ("freshness_error", "freshness check could not run (no pull or no SLA file)")},
}
# breaches that persist from day to day until someone acts: one alert key per job and kind, not per run
STANDING_KINDS = {
    "freshness_breach": "standing: the shared data breaches every day until Sam reviews the cells in "
                        "docs/runbooks/A-sam-ready.md item 13; sent once, listed until clear; the SLA is not loosened",
    "freshness_prices": "sent once, listed until clear",
}


def step_alerts(name: str, lj: dict) -> list[dict]:
    """Per-step alerts for a finished job whose steps have a known exit-code contract (STEP_CODES)."""
    out = []
    for i, st in enumerate(lj.get("steps") or []):
        code = st.get("exit_code")
        text = " ".join(map(str, st.get("args") or []))
        meaning = next((m for marker, m in STEP_CODES.items() if marker in text), None)
        if meaning is None or code in (0, None):
            continue
        kind, what = meaning.get(code) or meaning["error"]
        standing = STANDING_KINDS.get(kind)
        out.append(_alert("warning", kind, name, f"Scheduled {name} job step {i + 1}: {what}; exit {code} at {lj.get('ended_at')} "
                          f"(details in outputs/logs/{name}.out.log)" + (f" [{standing}]" if standing else ""), value=code,
                          key=f"{kind}:{name}" if standing else f"{kind}:{name}:{lj.get('ended_at')}"))
    return out


EVIDENCE_FILES = {"monitoring_alerts": "monitoring/monitoring_alerts.json"}     # evidence kind -> file under outputs/


def _alert(severity, kind, scope, message, value=None, threshold=None, key=None) -> dict:
    return {"severity": severity, "kind": kind, "scope": scope, "country": None, "message": message, "value": value,
            "threshold": threshold, "key": key or f"{kind}:{scope}"}


def _parse(ts) -> dt.datetime | None:
    if ts is None or (isinstance(ts, float) and ts != ts):
        return None
    s = str(ts).strip().removeprefix("backfill").strip()
    try:
        t = dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
    except ValueError:
        return None
    return t if t.tzinfo else t.replace(tzinfo=dt.timezone.utc)


def _zone(tz: str):
    from zoneinfo import ZoneInfo
    return ZoneInfo(tz)


def is_run_day(d: dt.date, weekdays: list[int], holidays: set[dt.date]) -> bool:
    """launchd weekday numbers (0/7 Sunday ... 6 Saturday). Weekday-only jobs also skip `holidays`."""
    lw = (d.isoweekday() % 7)                                 # Monday 1 ... Saturday 6, Sunday 0
    if lw not in {w % 7 for w in weekdays}:
        return False
    return not (set(weekdays) <= set(range(1, 6)) and d in holidays)


def latest_due_slot(job: dict, now: dt.datetime, tz: str, grace_minutes: int, holidays: set[dt.date], lookback_days: int = 10):
    """(slot, deadline) of the newest slot whose deadline + grace has passed, in UTC; None if none in the lookback."""
    z = _zone(tz)
    local_now = now.astimezone(z)
    monthly = job.get("day") is not None
    for back in range((max(lookback_days, 31) if monthly else lookback_days) + 1):
        d = local_now.date() - dt.timedelta(days=back)
        if monthly:
            if d.day != int(job["day"]):
                continue
        elif not is_run_day(d, job.get("weekdays", _schedule.ALL_DAYS), holidays):
            continue
        slot = dt.datetime.combine(d, dt.time(int(job["hour"]), int(job["minute"])), tzinfo=z)
        deadline = slot + dt.timedelta(minutes=int(job.get("max_minutes", 30)))
        if deadline + dt.timedelta(minutes=grace_minutes) <= local_now:
            return slot.astimezone(dt.timezone.utc), deadline.astimezone(dt.timezone.utc)
    return None


def _record_times(data_dir: Path) -> list[dt.datetime]:
    p = data_dir / "forecast_record.csv"
    if not p.exists():
        return []
    try:
        df = pd.read_csv(p, usecols=["recorded_at"])
    except (ValueError, pd.errors.EmptyDataError):
        return []
    return [t for t in (_parse(v) for v in df["recorded_at"]) if t]


def _store_times(out_dir: Path, label: str = "base") -> list[dt.datetime]:
    db = out_dir / "store" / "econquest.sqlite"
    if not db.exists():
        return []
    import sqlite3
    with sqlite3.connect(f"file:{db}?mode=ro", uri=True) as c:          # read only: never create or migrate the store
        rows = c.execute("SELECT created_at FROM runs WHERE label=? ORDER BY created_at DESC LIMIT 50", (label,)).fetchall()
    return [t for t in (_parse(r[0]) for r in rows) if t]


def evidence_since(kind: str | None, name: str, slot: dt.datetime, data_dir: Path, out_dir: Path, last: dict,
                   early_minutes: int = 120) -> tuple[bool, str]:
    """Was the job's slot done? Runs started up to early_minutes before the slot count (a manual run just before)."""
    since = slot - dt.timedelta(minutes=early_minutes)
    if kind == "forecast_record":
        ts = [t for t in _record_times(data_dir) if t >= since]
        return bool(ts), (f"forecast record row recorded {max(ts).isoformat(timespec='seconds')}" if ts else "no forecast record row since the slot")
    if kind == "store_run":
        ts = [t for t in _store_times(out_dir) if t >= since]
        return bool(ts), (f"base run archived {max(ts).isoformat(timespec='seconds')}" if ts else "no base run archived in outputs/store since the slot")
    if kind in EVIDENCE_FILES:
        f = out_dir / EVIDENCE_FILES[kind]
        mt = dt.datetime.fromtimestamp(f.stat().st_mtime, dt.timezone.utc) if f.exists() else None
        ok = mt is not None and mt >= since
        return ok, (f"outputs/{EVIDENCE_FILES[kind]} written {mt.isoformat(timespec='seconds')}" if ok else
                    f"outputs/{EVIDENCE_FILES[kind]} not written since the slot" + (f" (last {mt.isoformat(timespec='seconds')})" if mt else " (missing)"))
    lj = last.get(name) or {}
    end = _parse(lj.get("ended_at"))
    ok = lj.get("status") == "ok" and end is not None and end >= since
    return ok, (f"job ended ok {lj.get('ended_at')}" if ok else f"no successful {name} job since the slot (last: {lj.get('status', 'none')} {lj.get('ended_at') or ''})".strip())


def check_missed(sched: dict | None, now: dt.datetime, data_dir: Path, out_dir: Path, last: dict) -> tuple[list[dict], list[dict]]:
    checks, alerts = [], []
    if not sched or sched.get("status") != "installed":
        return [{"check": "missed_run", "status": "skipped", "detail": "schedule not installed (no outputs/logs/schedule.json)"}], []
    tz = sched.get("tz", _schedule.DEFAULT_TZ); grace = int(sched.get("grace_minutes", 15))
    holidays = {dt.date.fromisoformat(h) for h in sched.get("holidays", [])}
    installed = _parse(sched.get("installed_at"))
    for name, job in sched.get("jobs", {}).items():
        if job.get("interval_minutes") or "hour" not in job:
            continue
        due = latest_due_slot(job, now, tz, grace, holidays)
        if due is None or (installed and due[0] < installed):
            checks.append({"check": "missed_run", "job": name, "status": "ok", "detail": "no slot due since install"})
            continue
        slot, deadline = due
        ok, detail = evidence_since(job.get("evidence"), name, slot, data_dir, out_dir, last)
        lj = last.get(name) or {}
        ended = _parse(lj.get("ended_at"))
        failed = not ok and lj.get("status") == "failed" and ended is not None and ended >= slot - dt.timedelta(minutes=120)
        checks.append({"check": "missed_run", "job": name, "status": "ok" if ok else ("failed" if failed else "missed"),
                       "slot": slot.isoformat(), "deadline": deadline.isoformat(), "detail": detail})
        if not ok and not failed:                         # a run that started and failed is reported once, as job_failed
            local = slot.astimezone(_zone(tz))
            alerts.append(_alert(SEV.get(name, "warning"), "missed_run", name,
                                 f"Scheduled {name} job for {local:%a %Y-%m-%d %H:%M} {tz} has no result by its deadline "
                                 f"{deadline.astimezone(_zone(tz)):%H:%M} + {grace} min: {detail}",
                                 value=detail, threshold=deadline.isoformat(), key=f"missed_run:{name}:{slot.isoformat()}"))
    return checks, alerts


def feed_age(data_dir: Path) -> tuple[dt.date | None, dict]:
    live = data_dir / "live"
    dates, status = [], {}
    f = live / "feeds.json"
    if f.exists():
        try:
            j = json.loads(f.read_text())
            status = j.get("feeds", {}) if isinstance(j, dict) else {}
            if j.get("retrieved"):
                dates.append(dt.date.fromisoformat(str(j["retrieved"])[:10]))
        except (ValueError, json.JSONDecodeError):
            pass
    vd = live / "vintages"
    if vd.exists():
        for p in vd.iterdir():
            try:
                dates.append(dt.date.fromisoformat(p.name[:10]))
            except ValueError:
                continue
    return (max(dates) if dates else None), status


def check_feeds(data_dir: Path, now: dt.datetime, stale_days: int, tz: str) -> tuple[list[dict], list[dict]]:
    newest, status = feed_age(data_dir)
    today = now.astimezone(_zone(tz)).date()
    alerts = []
    if newest is None:
        alerts.append(_alert("warning", "stale_feed", "data", "No live pull recorded (no data/live/feeds.json or vintages)", key="stale_feed:none"))
        checks = [{"check": "stale_feed", "status": "stale", "detail": "no live pull recorded"}]
    else:
        age = (today - newest).days
        stale = age > stale_days
        checks = [{"check": "stale_feed", "status": "stale" if stale else "ok", "newest_pull": newest.isoformat(), "age_days": age,
                   "threshold_days": stale_days}]
        if stale:
            alerts.append(_alert("warning", "stale_feed", "data", f"Live inputs are {age} days old (last pull {newest}; limit {stale_days} days): run econquest fetch",
                                 value=age, threshold=stale_days, key=f"stale_feed:{newest.isoformat()}"))
    for name, st in (status or {}).items():
        if not str(st).lower().startswith("ok"):
            alerts.append(_alert("warning", "feed_failure", "data", f"Feed {name} failed on the last pull: {st}", value=str(st),
                                 key=f"feed_failure:{name}:{newest}"))
            checks.append({"check": "feed_status", "feed": name, "status": "failed", "detail": str(st)})
    return checks, alerts


def check_jobs(last: dict, sched: dict | None, now: dt.datetime) -> tuple[list[dict], list[dict]]:
    checks, alerts = [], []
    jobs_cfg = (sched or {}).get("jobs") or _schedule.DEFAULT_JOBS
    for name, lj in sorted(last.items()):
        status, code = lj.get("status"), lj.get("exit_code")
        if lj.get("reason") == "clock_skew":                # EQ-C-0164: refused by the jobs.py clock guard
            checks.append({"check": "job", "job": name, "status": "clock_skew", "exit_code": code, "ended_at": lj.get("ended_at")})
            alerts.append(_alert("critical", "clock_skew", name, f"Scheduled job {name} was refused at {lj.get('started_at')}: "
                                 f"{str(lj.get('message') or 'the clock is behind the job record')[:300]}", value=code,
                                 key=f"clock_skew:{name}:{lj.get('started_at')}"))
            continue
        if status == "failed" or (status in ("ok", "failed") and code not in (0, None)):
            checks.append({"check": "job", "job": name, "status": "failed", "exit_code": code, "ended_at": lj.get("ended_at")})
            per_step = step_alerts(name, lj)
            if per_step:
                alerts += per_step
                continue
            alerts.append(_alert("critical", "job_failed", name, f"Scheduled job {name} failed with exit code {code} at {lj.get('ended_at')} "
                                 f"(log outputs/logs/{name}.err.log)", value=code, key=f"job_failed:{name}:{lj.get('ended_at')}"))
        elif status == "running":
            started = _parse(lj.get("started_at"))
            limit = 2 * int((jobs_cfg.get(name) or {}).get("max_minutes", 60))
            if started and now - started > dt.timedelta(minutes=limit):
                checks.append({"check": "job", "job": name, "status": "hung", "started_at": lj.get("started_at")})
                alerts.append(_alert("warning", "job_hung", name, f"Scheduled job {name} started {lj.get('started_at')} and has not ended "
                                     f"after {limit} min (stopped or still running)", key=f"job_hung:{name}:{lj.get('started_at')}"))
            else:
                checks.append({"check": "job", "job": name, "status": "running", "started_at": lj.get("started_at")})
        else:
            checks.append({"check": "job", "job": name, "status": status or "unknown", "exit_code": code, "ended_at": lj.get("ended_at")})
    return checks, alerts


CLOCK_SKEW_MINUTES = 10


def check_clock(last: dict, now: dt.datetime) -> tuple[list[dict], list[dict]]:
    """EQ-C-0164: job times recorded in the future (more than CLOCK_SKEW_MINUTES after now) mean the clock went back."""
    ahead = []
    for name, lj in sorted(last.items()):
        for k in ("started_at", "ended_at"):
            t = _parse(lj.get(k))
            if t and t - now > dt.timedelta(minutes=CLOCK_SKEW_MINUTES):
                ahead.append((name, k, lj.get(k)))
    if not ahead:
        return [{"check": "clock", "status": "ok"}], []
    name, k, ts = ahead[0]
    return ([{"check": "clock", "status": "skew", "ahead": [f"{n}.{kk}={v}" for n, kk, v in ahead][:10]}],
            [_alert("warning", "clock_skew", "clock", f"{len(ahead)} recorded job time(s) are after now "
                    f"({now.isoformat(timespec='seconds')}), e.g. {name} {k} {ts}: the system clock went back or ran ahead. "
                    "Check the clock (date -u); scheduled jobs refuse to start until it is consistent "
                    "(docs/runbooks/C-chaos-and-perf.md)", value=len(ahead), key=f"clock_skew:clock:{ts}")])


def check_record_mode(sched: dict | None, cfg: dict) -> tuple[list[dict], list[dict]]:
    """Which prices mode the scheduled record job runs in (EQ-C-0086): 'staged' (default) or 'apply' (ops.json
    record_job_apply_prices true). Reports the installed mode and flags an ops.json change not yet reinstalled."""
    installed = (sched or {}).get(_schedule.RECORD_APPLY_KEY)
    wanted = _schedule.record_apply_prices(cfg)
    if installed is None:
        return [{"check": "record_mode", "status": "skipped" if not sched else "ok",
                 "mode": "apply" if wanted else "staged", "detail": "installed schedule does not record the mode; "
                 + _schedule.record_mode(cfg)}], []
    c = {"check": "record_mode", "status": "ok" if installed == wanted else "pending_reinstall",
         "mode": "apply" if installed else "staged", "detail": (sched or {}).get("record_mode") or ""}
    if installed != wanted:
        c["detail"] += f"; ops.json now says {'apply' if wanted else 'staged'}: run `econquest schedule install` to take effect"
    return [c], []


def check_approvals_log(data_dir: Path) -> tuple[list[dict], list[dict]]:
    """approvals_log check (see the module docstring): warning when data/approvals/log.jsonl is missing or empty."""
    p = data_dir / "approvals" / "log.jsonl"
    try:
        empty = not p.read_text(encoding="utf-8", errors="replace").strip()
        state = "empty" if empty else "ok"
    except FileNotFoundError:
        state = "missing"
    except OSError as e:
        state = f"unreadable ({type(e).__name__})"
    if state == "ok":
        return [{"check": "approvals_log", "status": "ok"}], []
    return [{"check": "approvals_log", "status": state.split()[0], "detail": str(p)}], [
        _alert("warning", "approvals_log", "data",
               f"data/approvals/log.jsonl is {state}: the change-approval record of assumptions.json, limits.json and "
               "compliance.json is gone, so those files read as never governed (restore data/approvals/ from the backup; "
               "econquest change verify)", value=state, key=f"approvals_log:{state.split()[0]}")]


def check_review_ledger(data_dir: Path) -> tuple[list[dict], list[dict]]:
    """review_ledger check (HO-20261025-A-C-024): Team A's verify_ledger; broken chain -> critical, notes -> info."""
    from ..ingestion import ledger
    try:
        st = ledger.verify_ledger(Path(data_dir))
    except Exception as e:                                  # noqa: BLE001 - a crash in the verifier is itself a break
        st = {"ok": False, "exists": True, "rows": 0, "problems": [f"verify failed: {type(e).__name__}: {e}"], "notes": []}
    c = {"check": "review_ledger", "status": "ok" if st["ok"] else "broken", "exists": bool(st.get("exists")),
         "rows": st.get("rows", 0), "chained": st.get("chained", 0), "legacy_unchained": st.get("legacy_unchained", 0),
         "problems": list(st.get("problems") or []), "notes": list(st.get("notes") or [])}
    if st["ok"]:
        return [c], []
    return [c], [_alert("critical", "review_ledger", "data",
                        "data/live/review_ledger.csv hash chain is BROKEN (a chained row was edited, deleted, inserted or "
                        "reordered): " + "; ".join(c["problems"][:3]) + " (restore data/live/ from the backup; "
                        "econquest review verify)", value=len(c["problems"]),
                        key=f"review_ledger:{st.get('head', {}).get('row_hash', '')}:{len(c['problems'])}")]


def check_calendar_events(data_dir: Path, now: dt.datetime, cfg: dict | None = None) -> tuple[list[dict], list[dict]]:
    """calendar_event check (EQ-C-0155): events at or above the importance threshold within the window."""
    from ..presentation import calendar_view as CV
    cfg = cfg or {}
    try:
        days = int(cfg.get("event_alert_days", CV.ALERT_DAYS))
        mi = int(cfg.get("event_alert_min_importance", CV.ALERT_MIN_IMPORTANCE))
    except (TypeError, ValueError):
        days, mi = CV.ALERT_DAYS, CV.ALERT_MIN_IMPORTANCE
    today = now.astimezone(dt.timezone.utc).date() if now.tzinfo else now.date()
    try:
        rows = CV.alert_rows(data_dir, today=today, days=days, min_importance=mi)
    except Exception as e:                                  # noqa: BLE001 - reported as a check row, not an alert
        return [{"check": "calendar_events", "status": "error", "detail": f"calendar unreadable ({type(e).__name__})",
                 "window_days": days, "min_importance": mi}], []
    alerts = []
    for r in rows:
        when = "under way" if r["days_until"] == 0 else f"in {r['days_until']} days"
        alerts.append(_alert("warning" if r["importance"] >= 3 else "info", "calendar_event", r["iso3"],
                             f"{r['iso3']} {r['kind_label']} on {r['date']} ({when}): {r['title']} [importance "
                             f"{r['importance']}, {r['status']}; source {r['source_id']}; client {r['client_output']}]",
                             value=r["importance"], threshold=mi, key=f"calendar_event:{r['event_id']}:{r['date']}")
                      | {"country": r["iso3"]})
    return [{"check": "calendar_events", "status": "alert" if alerts else "ok", "window_days": days,
             "min_importance": mi, "alerting": len(alerts)}], alerts


def vendor_capture_reports(data_dir: Path, last: dict) -> list[dict]:
    """Info rows for vendor_capture_* jobs that have run (HO-20261025-A-C-023): the newest golive report per vendor."""
    out = []
    base = Path(data_dir) / "live" / "market" / "snapshots" / "golive"
    for name in sorted(n for n in last if n.startswith("vendor_capture_")):
        vendor = name[len("vendor_capture_"):]
        reps = sorted(base.glob(f"*-{vendor}*/report.json")) if base.is_dir() else []
        row = {"check": "vendor_capture", "job": name, "status": "info"}
        if not reps:
            row["detail"] = "no go-live report yet"
        else:
            try:
                j = json.loads(reps[-1].read_text(encoding="utf-8"))
                row.update({"report": str(reps[-1].parent.name), "saved": j.get("saved"), "held": j.get("held"),
                            "holds": (j.get("holds") or [])[:5], "requested_close": j.get("requested_close")})
                row["detail"] = f"{j.get('requested_close')}: {j.get('saved')} saved, {j.get('held')} held"
            except (OSError, ValueError) as e:
                row["detail"] = f"report unreadable ({type(e).__name__})"
        out.append(row)
    return out


def run_health(data_dir: str | Path, out_dir: str | Path, now: dt.datetime | None = None, deliver: bool = True, env: dict | None = None,
               stale_days: int | None = None, log=print, deliver_fn=None) -> dict:
    """Run every check, write outputs/health.json, deliver alerts not sent before. Returns the health dict."""
    data_dir, out_dir = Path(data_dir), Path(out_dir)
    now = now or dt.datetime.now(dt.timezone.utc)
    home = out_dir.parent
    sp = out_dir / "logs" / "schedule.json"
    sched = json.loads(sp.read_text()) if sp.exists() else None
    cfg = _schedule.load_config(home)
    tz = (sched or {}).get("tz") or cfg.get("tz", _schedule.DEFAULT_TZ)
    stale = int(stale_days if stale_days is not None else (sched or {}).get("stale_feed_days", cfg.get("stale_feed_days", 7)))
    last = last_runs(home)
    checks, alerts = [], []
    for c, a in (check_missed(sched, now, data_dir, out_dir, last), check_feeds(data_dir, now, stale, tz), check_jobs(last, sched, now),
                 check_approvals_log(data_dir), check_record_mode(sched, cfg), check_review_ledger(data_dir),
                 check_calendar_events(data_dir, now, cfg), check_clock(last, now)):
        checks += c; alerts += a
    checks += vendor_capture_reports(data_dir, last)
    hp = out_dir / "health.json"
    prev = {}
    if hp.exists():
        try:
            prev = json.loads(hp.read_text()).get("alerted", {})
        except (OSError, json.JSONDecodeError):
            prev = {}
    new = [a for a in alerts if a["key"] not in prev]
    alerted = {a["key"]: prev.get(a["key"], now.isoformat(timespec="seconds")) for a in alerts}
    worst = min((["critical", "warning", "info"].index(a["severity"]) for a in alerts), default=None)
    delivery = None
    if new and deliver:
        if deliver_fn is None:
            from ..validation.alerts import deliver_alerts as deliver_fn
        # out_dir=None: do not overwrite the run's outputs/alerts.json; health.json holds these alerts
        delivery = deliver_fn([{k: v for k, v in a.items() if k != "key"} for a in new], {}, env, out_dir=None, run_id="health", log=log)
        if any(str((delivery or {}).get(k, "")).startswith("error") for k in ("webhook", "email")):
            alerted = {k: v for k, v in alerted.items() if k in prev}      # failed delivery: send these again next check
        try:                                                # EQ-C-0045: delivery latency (econquest distribute status)
            from .distribute import log_alert_delivery
            log_alert_delivery(out_dir, new, delivery, now=now)
        except Exception as e:                              # noqa: BLE001 - never fail the health check on the log
            log(f"[health] delivery log not written: {type(e).__name__}")
    result = {"generated_at": now.isoformat(timespec="seconds"), "status": "ok" if worst is None else ["critical", "warning", "info"][worst],
              "tz": tz, "schedule": (sched or {}).get("status", "not installed"), "checks": checks, "alerts": alerts,
              "new_alerts": len(new), "delivery": delivery, "alerted": alerted}
    out_dir.mkdir(parents=True, exist_ok=True)
    tmp = out_dir / ".health.json.tmp"; tmp.write_text(json.dumps(result, indent=1, default=str)); tmp.replace(hp)
    log(f"[health] {result['status']}: {len(alerts)} alerts ({len(new)} new) -> {hp}")
    for a in alerts:
        log(f"  [{a['severity'].upper():8s}] {a['kind']:12s} {a['message']}")
    for c in checks:
        if c.get("check") == "review_ledger":
            for n in c.get("notes") or []:
                log(f"  [INFO    ] review_ledger {n}")
    return result


def ledger_broken(result: dict) -> bool:
    """True when the review ledger check found a broken chain (health exits 1, HO-20261025-A-C-024)."""
    return any(c.get("check") == "review_ledger" and c.get("status") == "broken" for c in result.get("checks") or [])


def add_arguments(ap: argparse.ArgumentParser) -> None:
    ap.add_argument("--no-deliver", action="store_true", help="write health.json only; no webhook or email")
    ap.add_argument("--stale-days", type=int, help="live inputs older than this are stale (default 7, or ops.json stale_feed_days)")
    ap.add_argument("--strict", action="store_true", help="exit 1 when any critical alert is open")
    ap.add_argument("--daily", action="store_true", help="daily run monitor (EQ-C-0077): latest business day's run, forecast "
                    "record, backup and restore drill fresh, hash chains verify, disk space; OK/WARN/FAIL lines, exit 1 on FAIL; "
                    "writes outputs/ops_monitor.json and routes per data/resilience.json (email off, dry run only)")
    ap.add_argument("--backup-dest", help="with --daily: backup folder to check (default $ECONQUEST_BACKUP_DEST, else ~/econquest-backups/nightly)")


def run_from_args(args, data_dir, out_dir) -> int:
    if getattr(args, "daily", False):
        from . import monitor
        return monitor.run_from_args(args, data_dir, out_dir)
    r = run_health(data_dir, out_dir, deliver=not args.no_deliver, stale_days=args.stale_days)
    if ledger_broken(r):
        return 1
    return 1 if args.strict and r["status"] == "critical" else 0


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ops.health", description="econquest scheduled-job and feed health check")
    ap.add_argument("--home", default=os.environ.get("ECONQUEST_HOME", str(Path.home() / "econquest")))
    add_arguments(ap)
    args = ap.parse_args(argv)
    home = Path(args.home)
    return run_from_args(args, home / "data", home / "outputs")


if __name__ == "__main__":
    sys.exit(main())
