"""Performance budget for the full daily cycle (EQ-C-0164, docs/runbooks/C-chaos-and-perf.md).

    econquest perf-budget [--json] [--budget FILE] [--as-of D] [--paths N] [--steps a,b] [--keep]
    econquest perf-budget --measure [--runs 3]        (re-baseline: writes the budget file)

What is timed: the job sequence that `econquest morning` and the scheduled daily jobs (ops/schedule.DEFAULT_JOBS) run,
offline, on a fresh temporary home whose data/ is Team A's frozen MVP dataset (ingestion.mvp_dataset.materialize of
data/mvp). Each step is the same command line the job runs, in a child process, timed with the monotonic clock:

    run               morning job step 1   econquest run --as-of D
    report            morning job step 2   econquest report
    morning           desk view            econquest morning --no-run --as-of D --json
    record            record job           econquest record --dry-run (plan only: never Sheets)
    freshness_check   data_ops step 2      python -m econquest.ingestion.freshness check --json
    freshness_prices  data_ops step 3      python -m econquest.ingestion.freshness prices --json
    calendar_tests    calendar_tests job   python -m econquest.ops.calendar_jobs run --as-of D
    benchmark_snapshot benchmark job       python -m econquest.validation.benchmark_job --as-of D
    health            health job           python -m econquest.ops.health --no-deliver
    backup            backup job           python -m econquest.ops.backup --verify (temp destination)
    restore_drill     restore drill        python -m econquest.ops.backup drill (from that temp destination)

Not timed (NOT_COVERED): the data_ops incremental events pull (network), shadow_ratings (its --out must be inside the
repository's outputs/, which this check never touches), and the weekly and monthly jobs. Nothing reads or writes the
repository's outputs/ or the shared data/: every path is under the temporary home, removed afterwards (--keep keeps it).

Budget file (team/perf/daily-cycle-budget.json, schema eq-perf-budget/1): per step the measured seconds (median of
--runs cycles) and budget_s = ceil(median x FACTOR (1.5) + HEADROOM_S (2 s)); total_budget_s is their sum. The check
fails (exit 1) when a step exceeds its budget, a step fails (an exit code outside its OK_CODES), times out, or has no
budget; exit 2 when the cycle cannot be set up (no data/mvp, no budget file). --paths N runs the model with N paths
instead of the settings (a quicker check; budgets are for the full run, so a smaller run only has more room).
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import math
import os
import platform
import statistics
import subprocess
import sys
import tempfile
import time
from pathlib import Path

SCHEMA = "eq-perf-budget/1"
CHECK_SCHEMA = "eq-perf-budget-check/1"
TICKET = "EQ-C-0164"
PACKAGE_ROOT = Path(__file__).resolve().parents[2]
BUDGET_REL = "team/perf/daily-cycle-budget.json"
FACTOR = 1.5
HEADROOM_S = 2.0
DEFAULT_RUNS = 3
STEP_TIMEOUT_FLOOR_S = 600

_EQ = ["{python}", "-m", "econquest", "--data", "{data}", "--out", "{out}"]
# (name, what, argv template, exit codes that mean "ran": 2 is a reported breach / alert / drift, not a failure)
STEPS: tuple[tuple[str, str, list[str], tuple[int, ...]], ...] = (
    ("run", "morning job step 1: econquest run", _EQ + ["run", "--as-of", "{as_of}"], (0,)),
    ("report", "morning job step 2: econquest report", _EQ + ["report"], (0,)),
    ("morning", "econquest morning --no-run --json (desk view)", _EQ + ["morning", "--no-run", "--as-of", "{as_of}", "--json"], (0,)),
    ("record", "record job: econquest record --dry-run (plan only)", _EQ + ["record", "--dry-run"], (0,)),
    ("freshness_check", "data_ops step 2: freshness check", ["{python}", "-m", "econquest.ingestion.freshness", "check", "--json",
                                                          "--data", "{data}"], (0, 2)),
    ("freshness_prices", "data_ops step 3: freshness prices", ["{python}", "-m", "econquest.ingestion.freshness", "prices",
                                                            "--json", "--data", "{data}"], (0, 2)),
    ("calendar_tests", "calendar_tests job", ["{python}", "-m", "econquest.ops.calendar_jobs", "run", "--home", "{home}",
                                              "--as-of", "{as_of}"], (0, 2)),
    ("benchmark_snapshot", "benchmark_snapshot job", ["{python}", "-m", "econquest.validation.benchmark_job", "--home", "{home}",
                                                      "--as-of", "{as_of}"], (0, 2)),
    ("health", "health job (no delivery)", ["{python}", "-m", "econquest.ops.health", "--home", "{home}", "--no-deliver"], (0,)),
    ("backup", "backup job: backup --verify (temp destination)", ["{python}", "-m", "econquest.ops.backup", "--home", "{home}",
                                                                  "--verify", "--no-prune", "--dest", "{dest}"], (0,)),
    ("restore_drill", "restore drill from that backup", ["{python}", "-m", "econquest.ops.backup", "drill", "--home", "{home}",
                                                         "--dest", "{dest}"], (0,)),
)
STEP_NAMES = tuple(s[0] for s in STEPS)
NOT_COVERED = {
    "data_ops incremental events": "network pull (UCDP/ACLED/GDELT); offline cloud cannot reach it",
    "shadow_ratings": "its --out must be inside the repository outputs/, which this check never touches",
    "monitor, model_monitoring, ops_report, forecast_scorecard, dq_report": "weekly or monthly, not in the daily cycle",
}


class PerfBudgetError(RuntimeError):
    """The cycle could not be set up (no MVP dataset, unreadable budget file)."""


def budget_for(median_s: float, factor: float = FACTOR, headroom_s: float = HEADROOM_S) -> int:
    """Whole seconds: ceil(measured x factor + headroom)."""
    return int(math.ceil(float(median_s) * factor + headroom_s))


def budget_path(root: Path | None = None) -> Path:
    return Path(root or PACKAGE_ROOT) / BUDGET_REL


def load_budget(path: Path | None = None) -> dict:
    p = Path(path) if path else budget_path()
    try:
        b = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        raise PerfBudgetError(f"budget file {p} unreadable ({type(e).__name__}): run `econquest perf-budget --measure`") from e
    if not isinstance(b, dict) or b.get("schema") != SCHEMA or not isinstance(b.get("steps"), dict):
        raise PerfBudgetError(f"budget file {p} is not {SCHEMA}")
    return b


def mvp_as_of(root: Path | None = None) -> str:
    from ..ingestion import mvp_dataset
    m = json.loads((mvp_dataset.mvp_dir(Path(root or PACKAGE_ROOT)) / "manifest.json").read_text(encoding="utf-8"))
    return str(m["as_of"])


def setup_home(base: Path, root: Path | None = None) -> Path:
    """<base>/home with data/ = a writable copy of the verified MVP dataset (never the shared data/)."""
    from ..ingestion import mvp_dataset
    home = Path(base) / "home"
    home.mkdir(parents=True)
    try:
        mvp_dataset.materialize(home / "data", root=Path(root or PACKAGE_ROOT))
    except Exception as e:                              # noqa: BLE001 - MvpError, OSError: the cycle cannot run
        raise PerfBudgetError(f"MVP dataset not materialised ({type(e).__name__}: {e})") from e
    return home


def child_env(home: Path, dest: Path) -> dict:
    """The parent's environment without any ECONQUEST_* setting (no real home, backup folder, webhook, SMTP or token
    reaches a step), plus the temp home and backup folder, and the package on PYTHONPATH."""
    env = {k: v for k, v in os.environ.items() if not k.startswith("ECONQUEST_")}
    env.update(ECONQUEST_HOME=str(home), ECONQUEST_BACKUP_DEST=str(dest))
    env["PYTHONPATH"] = str(PACKAGE_ROOT) + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
    return env


def step_argv(template: list[str], home: Path, dest: Path, as_of: str, paths: int | None = None, name: str = "") -> list[str]:
    fill = {"{python}": sys.executable, "{home}": str(home), "{data}": str(home / "data"), "{out}": str(home / "outputs"),
            "{dest}": str(dest), "{as_of}": as_of}
    argv = [fill.get(a, a) for a in template]
    if name == "run" and paths:
        argv += ["--paths", str(int(paths))]
    return argv


def _default_runner(argv, cwd, env, timeout):
    return subprocess.run(argv, cwd=cwd, env=env, capture_output=True, text=True, timeout=timeout)


def _tail(text) -> str:
    lines = [x for x in str(text or "").splitlines() if x.strip()]
    return lines[-1][:300] if lines else ""


def run_cycle(home: Path, dest: Path, as_of: str, steps=None, paths: int | None = None, runner=None, budgets: dict | None = None,
              log=None) -> list[dict]:
    """Run the steps in order on `home`; returns one row per step {step, what, seconds, exit_code, ran, message}."""
    runner = runner or _default_runner
    env = child_env(home, dest)
    rows = []
    for name, what, template, ok_codes in STEPS:
        if steps and name not in steps:
            continue
        argv = step_argv(template, home, dest, as_of, paths, name)
        b = ((budgets or {}).get(name) or {}).get("budget_s")
        timeout = max(STEP_TIMEOUT_FLOOR_S, 4 * float(b)) if b else STEP_TIMEOUT_FLOOR_S * 3
        t0 = time.monotonic()
        try:
            p = runner(argv, str(home), env, timeout)
            code, msg = int(p.returncode), _tail(p.stdout if p.returncode in ok_codes else (p.stderr or p.stdout))
        except subprocess.TimeoutExpired:
            code, msg = None, f"timed out after {timeout:.0f} s"
        except OSError as e:
            code, msg = 127, f"could not start: {type(e).__name__}: {e}"
        secs = round(time.monotonic() - t0, 2)
        rows.append({"step": name, "what": what, "seconds": secs, "exit_code": code, "ran": code in ok_codes, "message": msg})
        if log:
            log(f"[perf] {name:<18} {secs:7.2f} s  exit {code}")
    return rows


def evaluate(rows: list[dict], budget: dict) -> dict:
    """Compare a cycle with the budget. {ok, steps: [...+budget_s, status], total_s, total_budget_s, problems}."""
    steps, problems = [], []
    bsteps = budget.get("steps") or {}
    for r in rows:
        b = (bsteps.get(r["step"]) or {}).get("budget_s")
        if not r["ran"]:
            status = "timeout" if r["exit_code"] is None else "failed"
            problems.append(f"{r['step']}: {status} (exit {r['exit_code']}): {r['message']}")
        elif b is None:
            status = "no_budget"
            problems.append(f"{r['step']}: no budget in the budget file (re-measure with --measure)")
        elif r["seconds"] > float(b):
            status = "over"
            problems.append(f"{r['step']}: {r['seconds']:.2f} s over its budget of {float(b):g} s")
        else:
            status = "ok"
        steps.append({**r, "budget_s": b, "status": status,
                      "headroom_s": None if b is None else round(float(b) - r["seconds"], 2)})
    total = round(sum(r["seconds"] for r in rows), 2)
    tb = sum(float((bsteps.get(r["step"]) or {}).get("budget_s") or 0) for r in rows)
    return {"ok": not problems, "steps": steps, "total_s": total, "total_budget_s": tb, "problems": problems}


def _fresh_base(prefix: str = "econquest-perf-") -> Path:
    return Path(tempfile.mkdtemp(prefix=prefix))


def _remove(base: Path) -> None:
    from .backup import _rmtree
    _rmtree(base)


def check(budget_file: Path | None = None, as_of: str | None = None, paths: int | None = None, steps=None, keep: bool = False,
          runner=None, root: Path | None = None, log=None) -> dict:
    """One timed cycle against the budget file. Returns the CHECK_SCHEMA payload ("exit" 0 ok, 1 over or failed)."""
    budget = load_budget(budget_file)
    as_of = as_of or budget.get("as_of") or mvp_as_of(root)
    base = _fresh_base()
    try:
        t0 = time.monotonic()
        home = setup_home(base, root)
        setup_s = round(time.monotonic() - t0, 2)
        rows = run_cycle(home, base / "backups", as_of, steps=steps, paths=paths, runner=runner,
                         budgets=budget.get("steps"), log=log)
    finally:
        if not keep:
            _remove(base)
    ev = evaluate(rows, budget)
    return {"schema": CHECK_SCHEMA, "ticket": TICKET, "generated_utc": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "as_of": as_of, "paths": paths, "setup_s": setup_s, "budget_file": str(budget_file or BUDGET_REL),
            "kept_at": str(base) if keep else None, "not_covered": NOT_COVERED, **ev, "exit": 0 if ev["ok"] else 1}


def _versions() -> dict:
    try:
        import numpy
        npv = numpy.__version__
    except ImportError:                                 # pragma: no cover
        npv = None
    return {"machine": f"{platform.system()} {platform.machine()}, {os.cpu_count()} CPUs", "python": platform.python_version(),
            "numpy": npv}


def measure(runs: int = DEFAULT_RUNS, as_of: str | None = None, paths: int | None = None, out: Path | None = None,
            runner=None, root: Path | None = None, log=None, factor: float = FACTOR, headroom_s: float = HEADROOM_S) -> dict:
    """Run `runs` full cycles on fresh homes and write the budget file (median per step x factor + headroom)."""
    as_of = as_of or mvp_as_of(root)
    samples: dict[str, list[float]] = {}
    what = {s[0]: s[1] for s in STEPS}
    for i in range(max(1, int(runs))):
        base = _fresh_base()
        try:
            home = setup_home(base, root)
            rows = run_cycle(home, base / "backups", as_of, paths=paths, runner=runner, log=log)
        finally:
            _remove(base)
        bad = [r for r in rows if not r["ran"]]
        if bad:
            raise PerfBudgetError("cycle %d: %s" % (i + 1, "; ".join(f"{r['step']} exit {r['exit_code']}: {r['message']}" for r in bad)))
        for r in rows:
            samples.setdefault(r["step"], []).append(r["seconds"])
    steps = {}
    for name in STEP_NAMES:
        if name in samples:
            med = round(statistics.median(samples[name]), 2)
            steps[name] = {"what": what[name], "measured_s": samples[name], "median_s": med,
                           "budget_s": budget_for(med, factor, headroom_s)}
    try:
        from ..ingestion import mvp_dataset
        ds = json.loads((mvp_dataset.mvp_dir(Path(root or PACKAGE_ROOT)) / "manifest.json").read_text()).get("dataset_sha256")
    except (OSError, ValueError):
        ds = None
    doc = {"schema": SCHEMA, "ticket": TICKET, "as_of": as_of,
           "rule": f"budget_s = ceil(median measured seconds x {factor:g} + {headroom_s:g} s headroom); total = sum of steps",
           "factor": factor, "headroom_s": headroom_s,
           "measured": {"utc": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"), "runs": max(1, int(runs)),
                        "paths": paths, "dataset": "data/mvp", "dataset_sha256": ds, "clock": "time.monotonic, child process",
                        **_versions()},
           "steps": steps, "total_budget_s": sum(s["budget_s"] for s in steps.values()), "not_covered": NOT_COVERED}
    p = Path(out) if out else budget_path(root)
    from .backup import atomic_write_text
    p.parent.mkdir(parents=True, exist_ok=True)
    atomic_write_text(p, json.dumps(doc, indent=1) + "\n")
    doc["path"] = str(p)
    return doc


def render_text(rep: dict) -> str:
    lines = [f"perf-budget {'PASS' if rep['ok'] else 'FAIL'}: daily cycle on data/mvp as of {rep['as_of']}"
             + (f", {rep['paths']} paths" if rep.get("paths") else "") + f" (setup {rep['setup_s']:.1f} s, not budgeted)"]
    for s in rep["steps"]:
        b = "-" if s["budget_s"] is None else f"{float(s['budget_s']):g}"
        lines.append(f"  {s['status'].upper():<9} {s['step']:<18} {s['seconds']:7.2f} s / {b:>4} s  {s['what']}")
    lines.append(f"  total {rep['total_s']:.1f} s of {rep['total_budget_s']:g} s budgeted")
    lines += [f"  problem: {p}" for p in rep["problems"]]
    lines.append("  not timed: " + "; ".join(f"{k} ({v})" for k, v in rep["not_covered"].items()))
    return "\n".join(lines) + "\n"


def add_arguments(ap: argparse.ArgumentParser) -> None:
    ap.add_argument("--json", action="store_true", help=f"print the result as JSON ({CHECK_SCHEMA})")
    ap.add_argument("--budget", type=Path, help=f"budget file (default {BUDGET_REL})")
    ap.add_argument("--as-of", help="model date for the cycle (default: the budget file's, else data/mvp's as_of)")
    ap.add_argument("--paths", type=int, help="run the model with N paths (a quicker check; default the settings)")
    ap.add_argument("--steps", help=f"comma-separated subset of: {','.join(STEP_NAMES)}")
    ap.add_argument("--keep", action="store_true", help="keep the temporary home (path printed)")
    ap.add_argument("--measure", action="store_true", help="re-baseline: run --runs cycles and write the budget file")
    ap.add_argument("--runs", type=int, default=DEFAULT_RUNS, help=f"cycles for --measure (median; default {DEFAULT_RUNS})")


def run_from_args(args) -> int:
    err = (lambda m: print(m, file=sys.stderr))
    steps = [s.strip() for s in args.steps.split(",") if s.strip()] if args.steps else None
    unknown = sorted(set(steps or []) - set(STEP_NAMES))
    if unknown:
        err(f"[perf] unknown step(s): {', '.join(unknown)} (known: {', '.join(STEP_NAMES)})")
        return 2
    try:
        if args.measure:
            doc = measure(args.runs, as_of=args.as_of, paths=args.paths, out=args.budget, log=err)
            print(json.dumps(doc, indent=1) if args.json else
                  f"budget written to {doc['path']}: " + ", ".join(f"{k} {v['budget_s']} s" for k, v in doc["steps"].items()))
            return 0
        rep = check(args.budget, as_of=args.as_of, paths=args.paths, steps=steps, keep=args.keep, log=err)
    except PerfBudgetError as e:
        err(f"[perf] error: {e}")
        return 2
    print(json.dumps(rep, indent=1) if args.json else render_text(rep), end="" if not args.json else "\n")
    return rep["exit"]


def register(sub) -> None:
    pb = sub.add_parser("perf-budget", help="time the full daily cycle (run, report, morning, record, freshness, calendar tests, "
                        "benchmark, health, backup, restore drill) on data/mvp offline in a temp home against per-step budgets "
                        f"({BUDGET_REL}); exit 1 when a step is over budget or fails (EQ-C-0164)")
    add_arguments(pb)
    pb.set_defaults(fn=lambda a: sys.exit(run_from_args(a)))


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ops.perf_budget", description=__doc__.split("\n")[0])
    add_arguments(ap)
    return run_from_args(ap.parse_args(argv))


if __name__ == "__main__":
    sys.exit(main())
