"""Client-readiness pack (EQ-C-0094): `econquest client-pack [--comparison DIR] [--json]`. INTERNAL.

Builds one folder, <out>/client_pack/, for Sam's client-mode decision (yes / no / later,
docs/research/client-mode-decision-pack.md). It holds:

    pack.md        the whole pack, readable on its own (every file starts with NOTICE)
    pack.json      the same content as data
    numbers.csv    client-safe against internal numbers, copied from Team B's report (EQ-B-0089), never recomputed
    blockers.csv   every open blocker with its owner
    manifest.json  sha256 of each file above and of every input file read

Sections: (0) Sam's decision, 2026-10-25 11:29Z: later, at PI-9 with licensed data, and the live status of its no-regret
items (ops/client_decision.py, EQ-C-0105); (1) the `econquest client-check` result (ops/client_check.collect); (2) Team B's client-safe comparison,
read from outputs/client-safe-comparison/<as_of>/ (client-safe-metrics.csv, client-safe-signals.csv, client-safe.json
manifest); (3) what a client-safe build would contain and withhold, from Team A's licence register (data/licences.csv,
contract C14) and presentation/licences.evaluate; (4) entitlement, watermark, disclaimer and attribution text as the
code holds it today; (5) a research-regulation checklist for counsel (questions, not legal advice); (6) open blockers
and owners.

NOTHING HERE SWITCHES CLIENT MODE ON. The command reads data/ and writes only under <out>/client_pack/. It never
writes research.json, the licence register, approvals or the action log, fetches nothing and sends nothing. The pack
itself is internal: it quotes "today" numbers that use IMF (EXC-003) and theratesapi.com (EXC-005) data.
"""
from __future__ import annotations

import csv
import datetime as dt
import hashlib
import io
import json
import re
from collections import Counter
from pathlib import Path

TICKET = "EQ-C-0094"
PACK_DIR = "client_pack"
COMPARISON_DIR = "client-safe-comparison"
NOTICE = ("INTERNAL - client-readiness pack for Sam's client-mode decision (EQ-C-0094). Not for clients. Quotes numbers "
          "built on IMF (EXC-003) and theratesapi.com (EXC-005) data. A checklist, not legal advice; nothing here "
          "switches client mode on.")
TEAM_B_MARKER = "INTERNAL"                    # first line of every Team B client-safe file (validation/client_safe.INTERNAL_NOTICE)
MAX_JSON_BYTES = 20_000_000
DECISION_DOC = "docs/research/client-mode-decision-pack.md"

# Owner and next step for each failing client-check row (ops/client_check.collect ids).
CHECK_OWNERS = {
    "mode": ("Sam", "Last step only: an `econquest change` on data/research.json approved by Sam, after every other row passes"),
    "imf": ("Sam (licence) + Team A (feeds) + Team B (validation)",
            "IMF written permission for client use, or replace WEO inputs with cleared feeds (Team A) reviewed by Team B, or stay internal"),
    "restricted": ("Team A", "Official FX fetch on the Mac (`econquest fetch --only fx --apply`) replaces the 17 Yahoo fx3m cells"),
    "licences": ("Team A (register) + Sam (licence decisions)", "File each licence text and set terms_verified=yes per source in data/licences.csv"),
    "licence_register": ("Team C (R44) + Team A", "Put data/licences.csv under `econquest change` (SEC-C-015 R44) and clear its internal-only rows"),
    "acled": ("Sam", "Corporate ACLED licence before ACLED feeds any product"),
    "disclaimer_core": ("Team C", "Restore report.DISCLAIMER"),
    "disclaimer_client": ("Sam + compliance adviser", "Adviser-approved client disclaimer applied through `econquest change`"),
    "allow_list": ("Sam", "Approve internal_domains / internal_addresses through `econquest change`"),
    "entitlements": ("Sam (after onboarding)", "research.json entitlements per onboarded recipient"),
    "recipients": ("Team C (new ticket)", "Governed recipients.json register (entity, jurisdiction, category, terms accepted)"),
    "compliance": ("Sam", "Name a compliance approver who is not the author; allow_self_sign false"),
    "adviser": ("Sam", "Engage a compliance adviser; file scope opinion, independence policy, conflicts register, record-keeping policy"),
}

# Blockers that client-check does not test, each with its source in the repo.
EXTRA_BLOCKERS = (
    ("signals_no_cleared_source", "DSA signal 26 and signal 1 (indicator 1.1) have no cleared substitute", "Team A (feed) + Team B (review)",
     "docs/validation/client-safe-run.md 5.4", "A cleared debt-service source for 1.1 and a non-WEO DSA benchmark, or keep both internal"),
    ("seed_fallback_quality", "Client-safe country PDs rest on older analyst seeds in place of WEO (Zimbabwe default PD +11.2 pp)", "Team A + Team B",
     "docs/validation/client-safe-run.md 5.2", "A cleared macro source (e.g. World Bank WDI) replacing the seeds, validated by Team B"),
    ("seeds_track_imf", "Seed cells that track IMF figures (the strict audit would restrict them)", "Sam (licence question)",
     "docs/validation/client-safe-run.md 5.3", "Decide whether estimates that track IMF figures may go to clients"),
    ("hazard_panel_register", "panel/hazard_panel.csv (built from WEO) has no licence register row", "Team A",
     "docs/validation/client-safe-run.md 6", "Add a register row (HO-20261025-B-A-001)"),
    ("register_regex_dos", "Team A's register loader compiles match regexes with no backtracking check (Team C's rule "
     "refuses nested repeats since EQ-C-0165)", "Team A",
     "team/security/SEC-C-015.md L1, SEC-C-016.md L1 (R42), SEC-C-026", "Call ops.licence_rule.redos_problem in ingestion.licences"),
    ("cells_without_record", "Applied cells with no provenance record are not counted by enforcement", "Team A",
     "team/security/SEC-C-015.md L2 (R43)", "Coverage check: every applied cell has a provenance record"),
    ("exc005_validator", "Whether EXC-005 (theratesapi.com) covers the external validator is not recorded", "Sam",
     "team/security/SEC-C-015.md I2", "Record the decision on the EXC-005 row"),
    ("workbook_policy", "Nothing technical stops the internal Risk Desk workbook being shared outside the desk", "Sam (policy)",
     "team/security/SEC-C-015.md I1", "Written sharing policy for the workbook"),
    ("second_analyst", "Single operator: no approver independent of the author", "Sam (hire, PI-9)",
     "team/board/program.csv PI9-ALL; docs/research/client-readiness.md 2.3", "A second analyst or an outside reviewer as compliance approver"),
)

# Research-regulation checklist for counsel: questions and the repo's evidence. Not legal advice; no answers given.
CHECKLIST = (
    ("Classification", [
        ("Is each product (daily report, weekly monitor, country note, scenario brief, trade ideas) investment research, a "
         "marketing communication, general market commentary or something else, in each jurisdiction concerned?",
         "docs/research/product-line.md 2.1; trade ideas are the part most likely to matter"),
        ("Does the publisher need, hold or qualify for an exemption from an authorisation for this activity?", "none recorded"),
        ("Do recipient categories (professional or not) and countries change the answer?", "no recipient register yet"),
        ("Does being paid or free, or any link to trading or advice, change the classification?", "not decided"),
    ]),
    ("Disclaimers", [
        ("Is the core disclaimer (report.DISCLAIMER, restriction 6.1) adequate for client output, or does it need changes?", "section 4 of this pack"),
        ("What must the client disclaimer (research.json disclaimer.client, empty today) say: nature of research, model and "
         "seed limits, no offer or recommendation, intended audience, past performance?", "docs/research/client-readiness.md 2.1"),
        ("Which attribution lines do the source licences require, and are the register's attribution_text values enough?", "section 4 attribution"),
        ("Is the watermark and 'Not for onward distribution' line adequate as a redistribution control?", "section 4 watermark"),
    ]),
    ("Conflicts and independence", [
        ("Is a written independence policy needed (who may see a product before release, who may change a conclusion)?", "none filed"),
        ("What must a conflicts register record (author and firm positions, compensation, relationships with covered sovereigns)?", "none filed"),
        ("When must a conflict block publication rather than be disclosed?", "editorial checklist has a conflicts declaration"),
        ("Is a named approver who is not the author required? (today: no approver, self-sign allowed)", "data/compliance.json"),
    ]),
    ("Record keeping", [
        ("What retention period applies to products, drafts, approvals and delivery records?", "ledgers are append-only, no retention rule"),
        ("Must recipient-level delivery and access be logged?", "distribution ledger records sends; no per-recipient access log"),
        ("Must communications with recipients be recorded?", "not recorded"),
        ("Is an off-site copy of the ledgers needed? (decision D4, keyed heads built but off)", "econquest ledger-key status"),
    ]),
    ("Distribution and data", [
        ("What onboarding record is required per recipient (entity, jurisdiction, category, terms accepted)?", "recipients.json does not exist"),
        ("What does each source licence allow for client output, and must its text be filed?", "data/licences.csv terms_verified"),
        ("What personal-data basis, retention and unsubscribe path apply to recipient addresses?", "data/distribution.json"),
    ]),
)


class ClientPackError(RuntimeError):
    """The pack cannot be built (unsafe output folder)."""


def _sha(p: Path) -> str | None:
    try:
        return hashlib.sha256(p.read_bytes()).hexdigest()
    except OSError:
        return None


def _csv_rows(p: Path) -> list[dict]:
    """Rows of a Team B CSV, skipping its leading '# INTERNAL ...' comment line."""
    text = p.read_text(encoding="utf-8")
    lines = [ln for ln in text.splitlines() if not ln.startswith("#")]
    return list(csv.DictReader(io.StringIO("\n".join(lines))))


def find_comparison(outputs_dir, explicit=None) -> Path | None:
    """Team B's report folder: `explicit`, else the latest outputs/client-safe-comparison/<as_of>/ holding the metrics CSV."""
    if explicit:
        p = Path(explicit)
        return p if p.is_dir() else None
    root = Path(outputs_dir) / COMPARISON_DIR
    if not root.is_dir():
        return None
    cands = sorted(d for d in root.iterdir() if d.is_dir() and not d.is_symlink() and (d / "client-safe-metrics.csv").is_file())
    return cands[-1] if cands else None


def read_comparison(folder: Path | None) -> dict:
    """Team B's numbers as stored. {"ok", "problem", "dir", "as_of", "paths", "notice", "metrics", "signals",
    "manifest", "dsa_signal", "files"}. Values are copied, never recomputed; a file without Team B's INTERNAL first
    line is refused."""
    out: dict = {"ok": False, "problem": None, "dir": str(folder) if folder else None, "metrics": [], "signals": [],
                 "manifest": {}, "files": {}}
    if folder is None:
        out["problem"] = ("Team B's client-safe comparison not found under outputs/client-safe-comparison/ "
                          "(`python -m econquest.validation.client_safe --as-of <date>`, EQ-B-0089)")
        return out
    try:
        mp = folder / "client-safe-metrics.csv"
        first = mp.read_text(encoding="utf-8").splitlines()[0] if mp.is_file() else ""
        if TEAM_B_MARKER not in first:
            out["problem"] = f"{mp} has no Team B INTERNAL first line: not read"
            return out
        out["notice"] = first.lstrip("# ").strip()
        out["metrics"] = _csv_rows(mp)
        out["files"]["client-safe-metrics.csv"] = _sha(mp)
        sp = folder / "client-safe-signals.csv"
        if sp.is_file():
            c = Counter((r.get("signal", ""), r.get("name", ""), r.get("kind", "")) for r in _csv_rows(sp))
            out["signals"] = [{"signal": s, "name": n, "kind": k, "countries": v} for (s, n, k), v in
                              sorted(c.items(), key=lambda kv: (int(kv[0][0]) if kv[0][0].isdigit() else 999, kv[0][2]))]
            out["files"]["client-safe-signals.csv"] = _sha(sp)
        jp = folder / "client-safe.json"
        if jp.is_file() and jp.stat().st_size <= MAX_JSON_BYTES:
            j = json.loads(jp.read_text(encoding="utf-8"))
            m = j.get("manifest") or {}
            out["manifest"] = {"cells_changed": m.get("cells_changed"), "cells_blank": m.get("cells_blank"),
                               "price_columns_dropped": m.get("price_columns_dropped") or [],
                               "files_left_out": len(m.get("files_left_out") or []),
                               "strict_audit_flags_kept": m.get("strict_audit_flags_kept"),
                               "components": m.get("components") or []}
            out["as_of"], out["paths"], out["dsa_signal"] = j.get("as_of"), j.get("paths"), j.get("dsa_signal")
            out["files"]["client-safe.json"] = _sha(jp)
        out["as_of"] = out.get("as_of") or folder.name
        out["ok"] = bool(out["metrics"])
        if not out["ok"]:
            out["problem"] = f"{mp} has no rows"
    except (OSError, ValueError, csv.Error, UnicodeDecodeError, IndexError) as e:
        out["ok"], out["problem"] = False, f"Team B's report could not be read ({type(e).__name__}: {e})"
    return out


def build_scope(data_dir, ev: dict, cmp: dict) -> dict:
    """What a client-safe build would contain and withhold, from Team A's register (C14) and the licence evaluation."""
    from ..ingestion import licences as A
    reg = Path(data_dir) / "licences.csv"
    groups: dict[str, list[dict]] = {"allowed": [], "restricted": [], "barred": []}
    problem = None
    try:
        for r in A.load_register(reg):
            groups.setdefault(r["client_output"], []).append(
                {"source_id": r["source_id"], "name": r["name"], "terms_verified": r["terms_verified"], "exc_id": r["exc_id"]})
    except Exception as e:                                    # noqa: BLE001 - shown in the pack; nothing is allowed
        problem = f"licence register could not be read ({type(e).__name__}): every source is withheld"
    used = {s["source_id"]: s.get("cells", 0) for s in ev.get("sources") or []}
    from ..presentation.licences import internal_groups
    withheld_cols = [{"source_id": g["source_id"], "table": g["table"], "key": g["key"], "cells": len(g["countries"])}
                     for g in internal_groups(ev)]
    m = cmp.get("manifest") or {}
    outputs_withheld = [f"Signal {s['signal']} '{s['name']}': {s['kind']} for {s['countries']} countries"
                        for s in cmp.get("signals") or [] if s["kind"] in ("signal not computed", "became blank")]
    if m.get("price_columns_dropped"):
        outputs_withheld.append("FX price columns dropped (EXC-005): " + ", ".join(m["price_columns_dropped"]))
    return {"register_problem": problem, "by_client_output": groups, "used_cells": used, "withheld_columns": withheld_cols,
            "outputs_withheld": outputs_withheld,
            "contains": ["Portfolio VaR99, ES99, EL and L-VaR99 and the 14 stress ES99 on cleared inputs (section 2)",
                         "Country PDs, regimes and signals recomputed on the cleared copy (seeds in place of WEO)",
                         "Sources the register marks client_output=allowed (terms mostly UNVERIFIED: 'allowed by the register', not checked by counsel)",
                         "The desk's own seed estimates and adjustments (no third-party licence; see seeds_track_imf)",
                         "Every page: research block, core disclaimer, Sources and licences block, per-recipient watermark"],
            "withholds": ["Every cell whose register row is restricted or barred (IMF/WEO, WEO-derived, theratesapi.com, Yahoo, "
                          "GOOGLEFINANCE, ACLED, hand FX, national central banks not cleared)",
                          "The raw files those rows tag (live/raw_weo.csv, raw_yahoo.csv, market_history archives)",
                          *outputs_withheld]}


def texts(data_dir, ev: dict) -> dict:
    """Entitlement, watermark, disclaimer and attribution text exactly as the code holds it today."""
    from ..presentation import research as R
    from ..presentation.client_package import watermark_html
    from ..presentation.report import DISCLAIMER
    st = R.effective_mode(data_dir)
    cfg = st["config"]
    ent = cfg.get("entitlements") or {}
    subs = {}
    p = Path(data_dir) / "distribution.json"
    try:
        subs = (json.loads(p.read_text(encoding="utf-8")) or {}).get("subscribers") or {} if p.is_file() else {}
    except (OSError, ValueError):
        subs = {}
    mark = watermark_html("<html><head></head><body></body></html>", "RECIPIENT", "YYYY-MM-DD")
    m = re.search(r"<div class='eq-recipient'[^>]*>(.*?)</div>", mark)
    return {"mode": st["mode"], "requested": st["requested"], "mode_problems": st["problems"],
            "core_disclaimer": DISCLAIMER, "banner": R.BANNER,
            "disclaimer_internal": (cfg.get("disclaimer") or {}).get("internal", ""),
            "disclaimer_client": (cfg.get("disclaimer") or {}).get("client", ""),
            "watermark": m.group(1) if m else "Prepared for RECIPIENT on YYYY-MM-DD. Not for onward distribution.",
            "entitled_recipients": len(ent), "entitled_kinds": sorted({k for v in ent.values() for k in (v or [])}),
            "subscribers_per_kind": {k: len(v or []) for k, v in subs.items()},
            "entitlement_rule": ("client-package and distribute refuse any recipient not listed in research.json "
                                 "`entitlements` (recipient -> [product kinds]); the file changes only through `econquest change` "
                                 "and is read only in client mode"),
            "attribution": list(ev.get("attribution") or [])}


def blockers(checks: list[dict], cmp: dict, scope: dict | None = None) -> list[dict]:
    out = []
    for c in checks:
        if c["ok"]:
            continue
        owner, step = CHECK_OWNERS.get(c["id"], ("Team C", "see client-check"))
        out.append({"id": c["id"], "hard": bool(c["blocker"]), "blocker": c["requirement"], "owner": owner,
                    "source": "econquest client-check", "next_step": step, "detail": c["detail"][:400]})
    if not cmp.get("ok"):
        out.append({"id": "client_safe_comparison", "hard": True, "blocker": "Team B's client-safe comparison is missing or unreadable",
                    "owner": "Team B", "source": "EQ-B-0089", "next_step": "Rerun validation/client_safe", "detail": cmp.get("problem") or ""})
    enforced = sum(w["cells"] for w in (scope or {}).get("withheld_columns") or [])
    changed = (cmp.get("manifest") or {}).get("cells_changed")
    if cmp.get("ok") and isinstance(changed, int) and enforced > changed:
        out.append({"id": "client_safe_rule_gap", "hard": True,
                    "blocker": "Team B's client-safe copy is not what licence enforcement would let out: it replaces fewer cells "
                               "than presentation/licences.evaluate withholds (seed cells whose series cite IMF; Yahoo equity_vol)",
                    "owner": "Team B + Team C + Team A", "source": "EQ-B-0089 manifest vs EQ-C-0093 evaluate",
                    "next_step": "Agree one client-output rule (seed cells, equity_vol), then rerun the comparison on it",
                    "detail": f"Team B replaced {changed} cells; enforcement withholds {enforced} cells today"})
    for bid, what, owner, src, step in EXTRA_BLOCKERS:
        detail = ""
        if bid == "seeds_track_imf" and (cmp.get("manifest") or {}).get("strict_audit_flags_kept") is not None:
            detail = f"{cmp['manifest']['strict_audit_flags_kept']} seed cells (Team B manifest strict_audit_flags_kept)"
        out.append({"id": bid, "hard": False, "blocker": what, "owner": owner, "source": src, "next_step": step, "detail": detail})
    return out


def _md_escape(s) -> str:
    return str(s if s is not None else "").replace("|", "\\|").replace("\n", " ")


def _num(s, nd=2) -> str:
    try:
        return f"{float(s):.{nd}f}"
    except (TypeError, ValueError):
        return str(s or "")


def _decision_md(st: dict | None) -> list[str]:
    """EQ-C-0105: Sam's decision (2026-10-25 11:29Z, later at PI-9) and the no-regret items, live status."""
    if not st or not st.get("decision"):
        return []
    d = st["decision"]
    L = ["## 0. Sam's decision", "", f"**{_md_escape(d['text'])}** Decided by {d['by']} on {d['decided_utc']} (option "
         f"({d['option']}), recorded by {d['recorded_by']} in `{d['doc']}`" + ("" if d["recorded"] else "; decision line not found") + ").", "",
         _md_escape(st["summary"]), "", "| Item | What | Owner | Ref | Status | Detail |", "|---|---|---|---|---|---|"]
    L += [f"| `{i['id']}` | {_md_escape(i['what'])} | {_md_escape(i['owner'])} | {i['ref']} | {i['status']} | {_md_escape(i['detail'])} |"
          for i in st["no_regret"]]
    return L + [""]


def render_md(p: dict) -> str:
    cmp, sc, tx = p["comparison"], p["scope"], p["texts"]
    L = [f"**{NOTICE}**", "", f"# Client-readiness pack ({TICKET})", "",
         f"Built {p['generated']} UTC (generation time, not a model date) from `{p['data_dir']}`. Decision document: "
         f"`{DECISION_DOC}`. Effective research mode: **{tx['mode']}** (unchanged by this command).", ""]
    L += _decision_md(p.get("decision"))
    L += ["## 1. client-check result", "",
          f"{p['check_summary']}", "", "| Result | id | Requirement | Detail |", "|---|---|---|---|"]
    for c in p["checks"]:
        tag = "PASS" if c["ok"] else ("FAIL*" if c["blocker"] else "FAIL")
        L.append(f"| {tag} | `{c['id']}` | {_md_escape(c['requirement'])} | {_md_escape(c['detail'][:300])} |")
    L += ["", "## 2. Client-safe against internal numbers (Team B, EQ-B-0089)", ""]
    if not cmp["ok"]:
        L += [f"Not available: {cmp['problem']}", ""]
    else:
        L += [f"Copied from `{cmp['dir']}` (as_of {cmp.get('as_of')}, {cmp.get('paths')} requested paths), not recomputed. "
              f"Team B's label: _{_md_escape(cmp.get('notice'))}_", "",
              "| Run | Metric | Internal (today) | Client-safe | Change | Change % | Paired SE |", "|---|---|---:|---:|---:|---:|---:|"]
        for r in cmp["metrics"]:
            L.append(f"| {_md_escape(r.get('run'))} | {_md_escape(r.get('metric'))} | {_num(r.get('today'))} | {_num(r.get('client_safe'))} | "
                     f"{_num(r.get('change'))} | {_num(r.get('change_pct'), 1)} | {_num(r.get('paired_se'))} |")
        m = cmp["manifest"]
        L += ["", f"Cells replaced or blanked: {m.get('cells_changed')} ({m.get('cells_blank')} blank); price columns dropped: "
              f"{', '.join(m.get('price_columns_dropped') or []) or 'none'}; files left out: {m.get('files_left_out')}; DSA signal computed "
              f"today {(cmp.get('dsa_signal') or {}).get('today')}, client-safe {(cmp.get('dsa_signal') or {}).get('client_safe')}.", "",
              "| Signal | Name | Change | Countries |", "|---:|---|---|---:|"]
        L += [f"| {s['signal']} | {_md_escape(s['name'])} | {s['kind']} | {s['countries']} |" for s in cmp["signals"]]
        L += ["", "Changes under about 0.3 $mm are Monte Carlo noise (paired SE 0.07 to 0.23). Full report: "
              "`docs/validation/client-safe-run.md`."]
    L += ["", "## 3. What a client-safe build would contain and withhold", "", "**Contains**", ""]
    L += [f"- {x}" for x in sc["contains"]]
    L += ["", "**Withholds**", ""] + [f"- {_md_escape(x)}" for x in sc["withholds"]]
    if sc["register_problem"]:
        L += ["", f"Register: {sc['register_problem']}"]
    L += ["", "Register rows by client_output (data/licences.csv, contract C14):", "", "| client_output | Sources (terms_verified) |", "|---|---|"]
    for k, rows in sc["by_client_output"].items():
        L.append(f"| {k} | " + ", ".join(f"{r['source_id']} ({r['terms_verified']})" for r in rows) + " |")
    if sc["withheld_columns"]:
        L += ["", "Internal-only columns in today's data (presentation/licences.evaluate):", "", "| Source | Table | Key | Cells |", "|---|---|---|---:|"]
        L += [f"| {w['source_id']} | {w['table']} | {w['key']} | {w['cells']} |" for w in sc["withheld_columns"]]
    L += ["", "## 4. Entitlements, watermark and disclaimers (as the code holds them today)", "",
          f"- Entitlement rule: {tx['entitlement_rule']}.",
          f"- Entitled recipients: {tx['entitled_recipients']}; subscribers per kind (counts only): "
          + (", ".join(f"{k} {v}" for k, v in tx["subscribers_per_kind"].items()) or "none") + ".",
          f"- Watermark on every client page: \"{_md_escape(tx['watermark'])}\" plus a diagonal overlay (client_package.watermark_html).",
          f"- Banner: internal \"{tx['banner'].get('internal')}\", client \"{tx['banner'].get('client')}\".",
          f"- Research block, internal text: \"{_md_escape(tx['disclaimer_internal'])}\"",
          f"- Research block, client text: \"{_md_escape(tx['disclaimer_client'])}\"" + (" (empty: the adviser drafts or approves it)" if not tx["disclaimer_client"].strip() else ""),
          f"- Core disclaimer on every product (report.DISCLAIMER, restriction 6.1): \"{_md_escape(tx['core_disclaimer'])}\"",
          "", "Attribution lines printed today (Sources and licences block):", ""]
    L += [f"- {_md_escape(a)}" for a in tx["attribution"]] or ["- none"]
    L += ["", "## 5. Research-regulation checklist for counsel", "",
          "Questions to put to a qualified compliance adviser in each jurisdiction concerned. This is a checklist, not legal "
          "advice: it states no rule and answers none of the questions.", ""]
    for head, items in CHECKLIST:
        L += [f"**{head}**", ""] + [f"- [ ] {q} _(repo: {ev})_" for q, ev in items] + [""]
    L += ["## 6. Open blockers and owners", "", "| id | Hard | Blocker | Owner | Next step | Source |", "|---|---|---|---|---|---|"]
    L += [f"| `{b['id']}` | {'yes' if b['hard'] else ''} | {_md_escape(b['blocker'])}{(' (' + _md_escape(b['detail'][:160]) + ')') if b['detail'] and b['source'] != 'econquest client-check' else ''} | "
          f"{_md_escape(b['owner'])} | {_md_escape(b['next_step'])} | {_md_escape(b['source'])} |" for b in p["blockers"]]
    L += ["", f"{len(p['blockers'])} open blockers ({sum(b['hard'] for b in p['blockers'])} hard)."]
    return "\n".join(L) + "\n"


def collect_pack(data_dir, outputs_dir, comparison=None, now: dt.datetime | None = None) -> dict:
    from ..presentation.licences import safe_evaluate
    from .licence_gov import DemoProfileRefused, demo_refusal
    if (why := demo_refusal("client-pack")):              # EQ-C-0123: never built on a DEMO licence baseline
        raise DemoProfileRefused(why)
    from .client_check import collect
    checks = collect(data_dir)
    bad = [c for c in checks if not c["ok"]]
    cmp = read_comparison(find_comparison(outputs_dir, comparison))
    ev = safe_evaluate(data_dir)
    now = now or dt.datetime.now(dt.timezone.utc)
    p = {"notice": NOTICE, "ticket": TICKET, "generated": now.strftime("%Y-%m-%dT%H:%M:%SZ"), "data_dir": str(data_dir),
         "checks": checks, "ready": not bad,
         "check_summary": f"{len(checks) - len(bad)} pass, {len(bad)} fail ({sum(c['blocker'] for c in bad)} hard blockers). "
                          + ("Not ready for client mode." if bad else "All records present: Sam decides."),
         "comparison": cmp, "scope": build_scope(data_dir, ev, cmp), "texts": texts(data_dir, ev)}
    p["blockers"] = blockers(checks, cmp, p["scope"])
    from .client_decision import status as decision_status          # EQ-C-0105: Sam's decision and the no-regret items
    p["decision"] = decision_status(data_dir, outputs_dir)
    return p


def _write(path: Path, data: bytes) -> None:
    from .safe_write import write_atomic                 # SEC-C-017 L6 (EQ-C-0165): no planted .tmp symlink is followed
    write_atomic(path, data)


def write_pack(p: dict, outputs_dir) -> dict:
    out = Path(outputs_dir) / PACK_DIR
    if out.is_symlink() or (out.exists() and not out.is_dir()):
        raise ClientPackError(f"{out} is a symlink or not a folder: pack not written")
    out.mkdir(parents=True, exist_ok=True)
    files = {}
    md = render_md(p).encode("utf-8")
    js = json.dumps(p, indent=1, default=str).encode("utf-8")
    buf = io.StringIO()
    buf.write(f"# {NOTICE}\n")
    w = csv.writer(buf)
    w.writerow(["run", "metric", "internal_today", "client_safe", "change", "change_pct", "paired_se", "source"])
    for r in p["comparison"].get("metrics") or []:
        w.writerow([r.get("run"), r.get("metric"), r.get("today"), r.get("client_safe"), r.get("change"), r.get("change_pct"),
                    r.get("paired_se"), "Team B client-safe-metrics.csv (EQ-B-0089)"])
    nums = buf.getvalue().encode("utf-8")
    buf = io.StringIO()
    buf.write(f"# {NOTICE}\n")
    w = csv.DictWriter(buf, fieldnames=["id", "hard", "blocker", "owner", "next_step", "source", "detail"])
    w.writeheader()
    w.writerows(p["blockers"])
    blk = buf.getvalue().encode("utf-8")
    for name, data in (("pack.md", md), ("pack.json", js), ("numbers.csv", nums), ("blockers.csv", blk)):
        _write(out / name, data)
        files[name] = hashlib.sha256(data).hexdigest()
    man = {"notice": NOTICE, "ticket": TICKET, "generated": p["generated"], "files": files,
           "inputs": {**{f"client-safe-comparison/{k}": v for k, v in (p["comparison"].get("files") or {}).items()},
                      **{n: _sha(Path(p["data_dir"]) / n) for n in ("licences.csv", "research.json", "distribution.json", "compliance.json")}}}
    _write(out / "manifest.json", json.dumps(man, indent=1).encode("utf-8"))
    return {"dir": str(out), "files": files, "manifest": str(out / "manifest.json")}


def cmd_client_pack(args) -> None:
    p = collect_pack(args.data, args.out, getattr(args, "comparison", None))
    res = write_pack(p, args.out)
    if args.json:
        print(json.dumps({"dir": res["dir"], "ready": p["ready"], "mode": p["texts"]["mode"], "files": res["files"],
                          "decision": (p.get("decision") or {}).get("decision"),
                          "no_regret": [{k: i[k] for k in ("id", "status", "owner")} for i in (p.get("decision") or {}).get("no_regret") or []],
                          "blockers": [{k: b[k] for k in ("id", "hard", "owner")} for b in p["blockers"]]}, indent=1))
        return
    print(f"{NOTICE}\nClient-readiness pack written to {res['dir']} (pack.md, pack.json, numbers.csv, blockers.csv, manifest.json).")
    if p.get("decision"):
        from .client_decision import lines
        print("\n".join(lines(p["decision"])))
    print(f"client-check: {p['check_summary']}")
    cmp = p["comparison"]
    print("Team B client-safe comparison: " + (f"as_of {cmp.get('as_of')} from {cmp['dir']}" if cmp["ok"] else f"missing ({cmp['problem']})"))
    print(f"{len(p['blockers'])} open blockers ({sum(b['hard'] for b in p['blockers'])} hard). Research mode stays {p['texts']['mode']}: "
          "this command changes nothing outside the pack folder.")


def register(sub) -> None:
    """client-pack, added by cli.main."""
    p = sub.add_parser("client-pack", help="build the INTERNAL client-readiness pack under <out>/client_pack/ (client-check result, "
                       "Team B's client-safe numbers, build scope, entitlement and disclaimer text, regulation checklist for counsel, "
                       "blockers and owners); never switches client mode on (EQ-C-0094)")
    p.add_argument("--comparison", metavar="DIR", help="Team B's client-safe report folder (default: latest outputs/client-safe-comparison/<as_of>/)")
    p.add_argument("--json", action="store_true", help="print a JSON summary")
    p.set_defaults(fn=cmd_client_pack)
