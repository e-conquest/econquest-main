"""The licence enforcement rule (EQ-C-0093, moved here from presentation/licences.py by EQ-C-0113 for HO-20261025-B-C-007).

One rule, below presentation so validation/client_safe.py (Team B, EQ-B-0096) can use it without breaking the layering
rule (EQ-B-0002, tests/test_benchmarks.py::test_no_validation_module_imports_presentation). The code is the same as
before the move; presentation/licences.py re-exports every name in RULE_NAMES (same objects), so callers do not
change. The register contract, what counts as internal-only, fail-closed behaviour and the approved-register pinning
(EQ-C-0106 / R44: register_mismatch is the one resolver, evaluate runs inside licence_gov.enforce_approved with its
lock, SEC-C-017 / SEC-C-018) are described in presentation/licences.py's module docstring.

Imports nothing from presentation. Licences are Sam's call; this code never changes the register.
"""
from __future__ import annotations

import copy
import csv
import io
import re
from pathlib import Path

REGISTER_NAME = "licences.csv"
REQUIRED_COLUMNS = ("source_id", "match", "licence", "client_ok", "attribution")
OPTIONAL_COLUMNS = ("exc_id", "licence_class", "url", "notes")
MAX_BYTES = 1_000_000
MAX_ROWS = 500
MAX_MATCH = 200
MAX_TEXT = 500
SUBJECT_CHARS = 300                     # register regexes run on at most this many characters of a label
ID_RE = re.compile(r"[A-Za-z0-9][A-Za-z0-9_.-]{0,63}")
# SEC-C-016 M2: Team A shipped the register (EQ-A-0076, contract C14) with its own columns; a header carrying these is
# read through _team_a_rows. Either schema is accepted; anything else refuses the register.
TEAM_A_SIGNATURE = ("source_id", "match_source", "match_licence", "match_series", "licence_text", "internal_use",
                    "client_output", "attribution_text")
TEAM_A_MATCH = {"match_source": "source", "match_series": "series", "match_licence": "licence"}
_CTRL = re.compile("[\\x00-\\x08\\x0b-\\x1f\\x7f\\x85\\u2028\\u2029]")
INTERNAL_ONLY_RE = re.compile(r"internal (research )?use only|non-?commercial|non commercial|\bpersonal\b|\bnda\b|"
                              r"\bexc-00[35]\b", re.IGNORECASE)
# The desk's own numbers: no third-party licence (still under independence review). Hand-entered market and FX files
# are NOT own: their values come from third-party pages and need a register row.
OWN_SOURCE_RE = re.compile(r"^seed (estimate|kept)\b|^hand-entered: data/adjustments\.csv$", re.IGNORECASE)
UNREGISTERED = "unregistered"
AUDIT = "audit"
# The problem evaluate reports when client_ok=yes rows are used but the register is not under change control;
# validation/client_safe.py treats exactly this note as non-fatal (EQ-B-0096).
CHANGE_CONTROL_NOTE = "is not under change control"
# EQ-C-0151 (HO-20261026-B-C-009, SEC-C-022): free-text provenance columns that say how a value was derived, and so
# can name its upstream series (audit_trail.csv transform: "GGXWDG_NGDP, year t as delivered"). Gate state columns
# (gate_reason, decision) describe the review, not the value, and are not read here.
PROVENANCE_TEXT_COLUMNS = ("transform", "robustness_rule", "method", "derivation", "inputs", "upstream")
# IMF WEO codes: rules.hazard.WEO_CODES (Team B) is added at call time; these are the codes feeds.WEO_CODES fetches.
WEO_CODES_EXTRA = ("GGXWDG_NGDP", "GGXONLB_NGDP", "GGXCNL_NGDP", "NGDP", "NGDP_RPCH", "PCPIPCH", "BCA_NGDPD", "NGDPDPC",
                   "NGDPD", "GGR_NGDP")
PROVENANCE_TEXT_MAX = 10_000            # longer free text cannot be checked: the cell is internal-only (fail closed)
PLANNED_FEED = "planned feed:"         # seed rows: the feed planned to replace the estimate, not its input
D3_SOURCE_ID = "imf_via_wdi"            # Sam decision D3: decided by its own row on the series, never by this rule
RULE_NAMES = ("REGISTER_NAME", "REQUIRED_COLUMNS", "OPTIONAL_COLUMNS", "MAX_BYTES", "MAX_ROWS", "MAX_MATCH", "MAX_TEXT",
              "SUBJECT_CHARS", "ID_RE", "TEAM_A_SIGNATURE", "TEAM_A_MATCH", "_CTRL", "INTERNAL_ONLY_RE", "OWN_SOURCE_RE",
              "UNREGISTERED", "AUDIT", "CHANGE_CONTROL_NOTE", "EVIDENCE_COLUMNS", "LicenceRegisterError",
              "register_path", "enforced_register_path", "register_mismatch", "_clean", "parse_register",
              "_team_a_rows", "load_register", "register_governed", "match_rows", "_records", "_stat", "_CACHE",
              "evaluate", "_evaluate", "_fallback", "attribution_lines", "failure_state", "safe_evaluate",
              "imf_evidence_problem", "PROVENANCE_TEXT_COLUMNS", "WEO_CODES_EXTRA", "PROVENANCE_TEXT_MAX",
              "D3_SOURCE_ID", "PLANNED_FEED", "weo_code_re", "imf_text_hits", "redos_problem")   # EQ-C-0165




class LicenceRegisterError(ValueError):
    """The licence register is missing, unreadable or invalid (callers fail closed)."""


# ---------------------------------------------------------------- reader
def redos_problem(pat: str) -> str | None:
    """Why a register pattern could backtrack catastrophically, or None (SEC-C-015 L1, SEC-C-016 L1, R42; EQ-C-0165).
    Python's re has no time budget, so the shapes that make it exponential are refused before compiling: a repeat
    inside another unbounded repeat (`(a+)+`, `(a*b?)*`), an alternation inside an unbounded repeat (`(a|ab)+`) and
    back-references. Literal words, alternations of words, classes and single repeats (`imf|weo`, `world bank.*`,
    `\\bwb[0-9]+`) are linear and pass."""
    try:
        import re._parser as P                     # Python 3.11+
        import re._constants as K
    except ImportError:                            # pragma: no cover - older Python
        import sre_parse as P
        import sre_constants as K
    try:
        tree = P.parse(pat, re.IGNORECASE)
    except Exception:                              # noqa: BLE001 - compile() reports the error itself
        return None
    reps = tuple(x for x in (getattr(K, n, None) for n in ("MAX_REPEAT", "MIN_REPEAT", "POSSESSIVE_REPEAT")) if x)

    def walk(items, inside: bool) -> str | None:
        for op, av in items:
            if op in reps:
                lo, hi, sub = av
                unbounded = hi is K.MAXREPEAT or hi > 1
                if unbounded and inside:
                    return "a repeat inside a repeat"
                r = walk(sub, inside or unbounded)
                if r:
                    return r
            elif op is K.SUBPATTERN:
                r = walk(av[-1], inside)
                if r:
                    return r
            elif op is K.BRANCH:
                if inside:
                    return "an alternation inside a repeat"
                for b in av[1]:
                    r = walk(b, inside)
                    if r:
                        return r
            elif op in (K.GROUPREF, K.GROUPREF_EXISTS):
                return "a back-reference"
            elif op in (K.ASSERT, K.ASSERT_NOT):
                r = walk(av[1], inside)
                if r:
                    return r
        return None
    return walk(tree, False)


def register_path(data_dir) -> Path:
    return Path(data_dir) / REGISTER_NAME


def enforced_register_path() -> Path:
    """The register Team A's hooks enforce (audit.client_output_reason, dataroom.restricted_reason, client_check,
    evidence require_register): $ECONQUEST_LICENCE_REGISTER, else the package data/licences.csv."""
    from ..ingestion import licences as A
    return A.register_path()


def register_mismatch(data_dir, allow_demo: bool = False) -> str | None:
    """SEC-C-017 M1 and EQ-C-0106 (R44): the one resolver behind "which register". The register that decides is the
    approved one (the version last applied or baselined through `econquest change`, ops/licence_gov.py). A reason (no
    local paths) when it cannot decide: no approved version yet, data/licences.csv drifted from it (or was deleted or
    symlinked), the approvals log does not verify, or the register Team A's resolver names outside the pin
    ($ECONQUEST_LICENCE_REGISTER, else the package copy) is not byte-identical to it. Callers fail closed for client
    output and the evidence build; internal products only carry the reason as a label. None when they all agree, or
    when there is no register and never was an approved one (every source is then internal-only here).
    EQ-C-0123: a DEMO baseline (ops/demo_baseline.py) is a reason too; only the evidence build passes allow_demo=True,
    and then the shown / enforced comparison below still applies."""
    from ..ops import licence_gov as G
    shown = register_path(data_dir)
    st = G.state(data_dir)
    if st["status"] == "default":
        return None
    if not (allow_demo and st["status"] == G.DEMO_STATE) and (why := G.problem(data_dir, st)):
        return why
    enforced = G.outside_register_path()
    where = "$ECONQUEST_LICENCE_REGISTER" if G.outside_env() else "the package data/licences.csv"
    try:
        if enforced.exists() and shown.resolve() == enforced.resolve():
            return None
        if not enforced.is_file():
            return (f"data/{REGISTER_NAME} is shown but the register Team A's checks enforce ({where}) is missing, so "
                    "they run on the old rules only (SEC-C-017)")
        a, b = shown.stat().st_size, enforced.stat().st_size
        if a == b and a <= 4 * MAX_BYTES and shown.read_bytes() == enforced.read_bytes():
            return None
    except OSError as e:
        return f"data/{REGISTER_NAME} could not be compared with {where} ({type(e).__name__}) (SEC-C-017)"
    return (f"data/{REGISTER_NAME} differs from the register Team A's checks enforce ({where}): one register must "
            "decide both what is shown and what is enforced; make them the same file (SEC-C-017)")


def _clean(v, where: str, limit: int = MAX_TEXT, allow_empty: bool = True) -> str:
    s = str(v if v is not None else "").strip()
    if _CTRL.search(s) or "\n" in s or "\r" in s:
        raise LicenceRegisterError(f"{where} contains a control character or line break")
    if len(s) > limit:
        raise LicenceRegisterError(f"{where} is longer than {limit} characters")
    if not s and not allow_empty:
        raise LicenceRegisterError(f"{where} must not be empty")
    return s


def parse_register(raw: bytes, where: str = REGISTER_NAME) -> list[dict]:
    """Validated register rows (see the module docstring), or LicenceRegisterError."""
    if len(raw) > MAX_BYTES:
        raise LicenceRegisterError(f"{where} is larger than {MAX_BYTES} bytes")
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError:
        raise LicenceRegisterError(f"{where} is not UTF-8") from None
    rd = csv.DictReader(io.StringIO(text, newline=""))
    try:
        cols = [c.strip() for c in (rd.fieldnames or [])]
        team_a = all(c in cols for c in TEAM_A_SIGNATURE)
        missing = [] if team_a else [c for c in REQUIRED_COLUMNS if c not in cols]
        if missing:
            raise LicenceRegisterError(f"{where} lacks columns {missing} (needs {', '.join(REQUIRED_COLUMNS)}, or Team A's "
                                       f"C14 columns {', '.join(TEAM_A_SIGNATURE)})")
        recs = list(rd)
    except csv.Error as e:
        raise LicenceRegisterError(f"{where} is not valid CSV ({e})") from None
    if len(recs) > MAX_ROWS:
        raise LicenceRegisterError(f"{where} has more than {MAX_ROWS} rows")
    if team_a:
        return _team_a_rows(recs, where)
    rows, seen = [], set()
    for i, r in enumerate(recs, start=2):
        r = {str(k).strip(): v for k, v in r.items() if k is not None}
        w = f"{where} line {i}"
        sid = _clean(r.get("source_id"), f"{w} source_id", 64, False)
        if not ID_RE.fullmatch(sid) or sid.casefold() in seen or sid in (UNREGISTERED, AUDIT):
            raise LicenceRegisterError(f"{w}: source_id must be unique and match {ID_RE.pattern}, got {sid!r}")
        seen.add(sid.casefold())
        pat = _clean(r.get("match"), f"{w} match", MAX_MATCH, False)
        why = redos_problem(pat)
        if why:
            raise LicenceRegisterError(f"{w}: match {pat!r} could backtrack without bound ({why}); use words, | and classes")
        try:
            rx = re.compile(pat, re.IGNORECASE)
        except re.error as e:
            raise LicenceRegisterError(f"{w}: match is not a valid regex ({e})") from None
        if rx.search(""):
            raise LicenceRegisterError(f"{w}: match {pat!r} matches the empty string (it would match every source)")
        lic = _clean(r.get("licence"), f"{w} licence", MAX_TEXT, False)
        ok = _clean(r.get("client_ok"), f"{w} client_ok", 8, False).casefold()
        if ok not in ("yes", "no"):
            raise LicenceRegisterError(f"{w}: client_ok must be yes or no, got {ok!r}")
        attr = _clean(r.get("attribution"), f"{w} attribution")
        if ok == "yes" and not attr:
            raise LicenceRegisterError(f"{w}: attribution is required when client_ok is yes")
        if ok == "yes" and INTERNAL_ONLY_RE.search(lic):
            raise LicenceRegisterError(f"{w}: licence {lic[:80]!r} names an internal-only term but client_ok is yes")
        row = {"source_id": sid, "match": pat, "rx": rx, "licence": lic, "client_ok": ok == "yes", "attribution": attr}
        for c in OPTIONAL_COLUMNS:
            row[c] = _clean(r.get(c), f"{w} {c}")
        rows.append(row)
    return rows


def _team_a_rows(recs: list[dict], where: str) -> list[dict]:
    """SEC-C-016 M2: Team A's register as EQ-A-0076 shipped it (contract C14: match_source / match_licence /
    match_series regexes, licence_text, client_output allowed|restricted|barred, attribution_text). Team A's validator
    (ingestion.licences) checks ids, vocabularies and regexes; Team C's caps (control characters, MAX_MATCH, no
    empty-string match) are added here. Mapping, never looser than Team A: client_ok only for client_output=allowed
    with internal_use=yes and no internal-only term in the licence text; restricted and barred are client_ok=no.
    match_path rows apply to files, not to cell records, so they never match a record here."""
    from ..ingestion import licences as A
    rows_a = []
    for r in recs:
        r = {str(k).strip(): v for k, v in r.items() if k is not None}
        rows_a.append({c: str(r.get(c) or "").strip() for c in A.REGISTER_COLUMNS})
    try:
        A.validate_register(rows_a, where)                   # public since EQ-A-0076 (HO-20261025-A-C-009)
    except Exception as e:                                   # noqa: BLE001 - Team A's check refused it: fail closed
        raise LicenceRegisterError(str(e) if isinstance(e, ValueError) else f"{where}: check failed ({type(e).__name__})") from None
    out = []
    for i, r in enumerate(rows_a, start=2):
        w = f"{where} line {i}"
        sid = r["source_id"]
        if sid in (UNREGISTERED, AUDIT) or not ID_RE.fullmatch(sid):
            raise LicenceRegisterError(f"{w}: source_id {sid!r} is reserved or invalid")
        for c in A.REGISTER_COLUMNS:
            _clean(r[c], f"{w} {c}", 10_000)                  # control characters / line breaks refuse the register
        fields = {}
        for col, subj in TEAM_A_MATCH.items():
            pat = r.get(col, "")
            if not pat:
                continue
            _clean(pat, f"{w} {col}", MAX_MATCH, False)
            why = redos_problem(pat)
            if why:
                raise LicenceRegisterError(f"{w}: {col} {pat!r} could backtrack without bound ({why}); "
                                           "use words, | and classes")
            rx = re.compile(pat, re.IGNORECASE)
            if rx.search(""):
                raise LicenceRegisterError(f"{w}: {col} {pat!r} matches the empty string (it would match every record)")
            fields[subj] = rx
        lic = (r["licence_text"] or r["name"] or sid)[:MAX_TEXT]
        ok = r["client_output"] == "allowed" and r["internal_use"] == "yes" and not INTERNAL_ONLY_RE.search(lic)
        out.append({"source_id": sid, "match": "; ".join(f"{c}={r[c]}" for c in TEAM_A_MATCH if r.get(c)), "rx": None,
                    "fields": fields, "licence": lic, "client_ok": ok, "attribution": r["attribution_text"][:MAX_TEXT],
                    "exc_id": r["exc_id"], "licence_class": r["client_output"], "url": r["url"][:MAX_TEXT],
                    "notes": r["notes"][:MAX_TEXT], "terms_verified": r["terms_verified"]})
    return out


def load_register(data_dir) -> list[dict]:
    """The register rows, or LicenceRegisterError (missing, symlink, not a file, too large, invalid). EQ-C-0106: the
    approved register's bytes when there is one (also while data/licences.csv drifted from it, or was deleted:
    register_mismatch then refuses client output); data/licences.csv itself only before a first approval."""
    try:
        from ..ops import licence_gov as G
        approved = G.approved_bytes(data_dir)
    except Exception:                                  # noqa: BLE001 - cannot tell: the current file, as before
        approved = None
    if approved is not None:
        return parse_register(approved, f"data/{REGISTER_NAME}")
    p = register_path(data_dir)
    if p.is_symlink():
        raise LicenceRegisterError(f"data/{REGISTER_NAME} is a symlink (refused)")
    if not p.is_file():
        raise LicenceRegisterError(f"data/{REGISTER_NAME} is missing (Team A licence register, EQ-A-0076)")
    try:
        raw = p.read_bytes()
    except OSError as e:
        raise LicenceRegisterError(f"data/{REGISTER_NAME} cannot be read ({type(e).__name__})") from None
    return parse_register(raw, f"data/{REGISTER_NAME}")


def register_governed(data_dir) -> bool:
    """True only when the register is a governed file (ops.approvals.FILES) whose current bytes are the approved
    version (last applied or baselined through `econquest change`) and the approvals chain verifies (EQ-C-0106)."""
    try:
        from ..ops import approvals as ap
        from ..ops import licence_gov as G
        if REGISTER_NAME not in ap.FILES:
            return False
        st = G.state(data_dir)
        return bool(st.get("chain_ok")) and st.get("status") == "ok"
    except Exception:                                  # noqa: BLE001 - cannot tell: not governed
        return False


def match_rows(rows: list[dict], source="", series="", licence="") -> list[dict]:
    """Register rows whose `match` finds the source, series or licence text (each cut to SUBJECT_CHARS)."""
    subj = {k: str(x or "")[:SUBJECT_CHARS] for k, x in (("source", source), ("series", series), ("licence", licence))}
    out = []
    for r in rows:
        f = r.get("fields")
        if f is not None:                                    # Team A schema: each regex searches its own field
            hit = any(subj[k] and rx.search(subj[k]) for k, rx in f.items())
        else:
            hit = any(s and r["rx"].search(s) for s in subj.values())
        if hit:
            out.append(r)
    return out


def weo_code_re() -> re.Pattern:
    """IMF WEO series codes (rules.hazard.WEO_CODES and WEO_CODES_EXTRA) as whole words, any case."""
    try:
        from ..rules.hazard import WEO_CODES
    except Exception:                                        # noqa: BLE001 - the built-in list still applies
        WEO_CODES = []
    codes = sorted(set(WEO_CODES) | set(WEO_CODES_EXTRA), key=len, reverse=True)
    return re.compile(r"\b(" + "|".join(re.escape(c) for c in codes) + r")\b", re.IGNORECASE)


def imf_text_hits(rows: list[dict], rec: dict, code_re: re.Pattern | None = None) -> tuple[list[dict], str | None]:
    """EQ-C-0151 (SEC-C-022): fail closed on an IMF / WEO input that the source and series columns do not name.

    Reads the record's source, series and free-text provenance (PROVENANCE_TEXT_COLUMNS, e.g. transform). Returns
    (register rows, reason): the register's IMF rows (source_id imf*, except the D3 row) whose source or series regex
    finds the free text; and, when any column names an IMF WEO code (weo_code_re) and no IMF row matched, the
    imf_derived row (else the first IMF row), so the register decides: a row with client_ok=yes allows the cell,
    any other answer keeps it internal-only. reason is set when the cell must be internal-only and no register row
    can say so (a WEO code but no IMF row; free text too long to check). The D3 row (imf_via_wdi) keeps its own
    semantics: it is matched on the series only, as before."""
    code_re = code_re or weo_code_re()
    texts = [(c, str(rec.get("text", {}).get(c) or "")) for c in PROVENANCE_TEXT_COLUMNS]
    texts = [(c, t) for c, t in texts if t]
    if OWN_SOURCE_RE.search(str(rec.get("source", ""))):
        # A seed estimate's transform may name the feed that is planned to replace it ("planned feed: IMF IFS API ...",
        # 5.11): that is not the value's input. Only that exact prefix is skipped, and only for the desk's own labels.
        texts = [(c, t) for c, t in texts if not t.lstrip().casefold().startswith(PLANNED_FEED)]
    long = [c for c, t in texts if len(t) > PROVENANCE_TEXT_MAX]
    if long:
        return [], f"provenance {long[0]} text is longer than {PROVENANCE_TEXT_MAX} characters and cannot be checked"
    imf = [r for r in rows if r["source_id"].casefold().startswith("imf") and r["source_id"] != D3_SOURCE_ID]
    out = []
    for r in imf:
        f = r.get("fields")
        rxs = [f[k] for k in ("source", "series") if k in f] if f is not None else [r["rx"]]
        if any(rx.search(t[:SUBJECT_CHARS]) for rx in rxs for _, t in texts):
            out.append(r)
    code = None
    for col, t in [("source", rec.get("source", "")), ("series", rec.get("series", ""))] + texts:
        m = code_re.search(str(t)[:PROVENANCE_TEXT_MAX])
        if m:
            code = (col, m.group(1).upper())
            break
    if code and not out:
        fall = [r for r in imf if r["source_id"] == "imf_derived"] or imf[:1]
        if not fall:
            return [], f"provenance {code[0]} names IMF WEO code {code[1]} and no IMF row of the licence register covers it"
        out = fall
    return out, None


# ---------------------------------------------------------------- records
def _records(data_dir) -> list[dict]:
    """Provenance records of the applied cells (audit_trail.csv) and the current pull (live/provenance.csv)."""
    import pandas as pd
    d = Path(data_dir)
    out = []
    for p, what in ((d / "audit_trail.csv", "applied"), (d / "live" / "provenance.csv", "current pull")):
        if p.is_symlink() or not p.is_file():
            continue
        df = pd.read_csv(p, dtype=str, keep_default_na=False)
        lic = next((c for c in df.columns if c.strip().lower() in ("licence", "license", "licences", "licenses")), None)
        txt = {c.strip().lower(): c for c in df.columns if c.strip().lower() in PROVENANCE_TEXT_COLUMNS}
        for r in df.to_dict("records"):
            out.append({"table": r.get("table", ""), "key": str(r.get("key", "")), "country": r.get("country", ""),
                        "source": str(r.get("source", "")).strip(), "series": str(r.get("series", "")),
                        "licence": str(r.get(lic, "")) if lic else "", "from": what,
                        "text": {k: str(r.get(c, "")) for k, c in txt.items()}})     # EQ-C-0151
    return out


def _stat(p: Path):
    try:
        s = p.lstat()
        return (s.st_mtime_ns, s.st_size, p.is_symlink())
    except OSError:
        return None


_CACHE: dict = {}


def evaluate(data_dir) -> dict:
    """Licence state of the data folder (cached on the stat of the files it reads; a copy is returned):

    {"register": {"ok", "rows", "governed", "problem"}, "complete": bool, "problems": [str],
     "sources": [{"source_id", "licence", "client_ok", "attribution", "labels", "cells"}],
     "internal_only": [{"table", "key", "country", "source", "source_id", "licence", "reason", "from"}],
     "attribution": [str], "client_ok": bool}

    client_ok is True only when the register loaded, the evaluation completed, no record is internal-only, and no used
    source relies on client_ok=yes of an ungoverned register. Never raises."""
    from ..ops import licence_gov as G
    d = Path(data_dir)
    enf = G.outside_register_path()                     # SEC-C-016 L6 / SEC-C-017: Team A's register is in the key
    ov = G.demo_override(d)                             # EQ-C-0123: a DEMO result is never served outside it
    key = (str(d.resolve()), str(enf), _stat(enf), _stat(d / "approvals" / "head.json"),     # EQ-C-0106: approvals
           ("demo", ov["sha256"], ov["snapshot"]) if ov else None,
           *(_stat(d / n) for n in (REGISTER_NAME, "audit_trail.csv", "live/provenance.csv",
                                    "indicators.csv", "countries.csv", "panel/cb_series_verified.csv")))
    if key not in _CACHE:
        if len(_CACHE) > 16:
            _CACHE.clear()
        with G.enforce_approved(d):                     # EQ-C-0106: Team A's hooks read only the approved register
            _CACHE[key] = _evaluate(d)
    return copy.deepcopy(_CACHE[key])


def _evaluate(d: Path) -> dict:
    problems: list[str] = []
    reg = {"ok": False, "rows": 0, "governed": False, "problem": None}
    try:
        rows = load_register(d)
        reg.update(ok=True, rows=len(rows), governed=register_governed(d))
    except LicenceRegisterError as e:
        rows = []
        reg["problem"] = str(e)
        problems.append(f"licence register: {e}; every source is treated as internal-only")
    try:
        mm = register_mismatch(d)                            # SEC-C-017 M1: shown != enforced -> refuse client output
    except Exception as e:                                   # noqa: BLE001 - cannot tell: fail closed
        mm = f"licence registers could not be compared ({type(e).__name__})"
    reader_mm = None                                         # EQ-C-0140: reader products get plain text, no command
    if mm:
        reg["problem"] = reg["problem"] or mm
        problems.append(f"licence register: {mm}")
        try:
            from ..ops import licence_gov as G
            rp = G.reader_problem(d)
        except Exception:                                    # noqa: BLE001 - the generic sentence below
            rp = None
        rp = rp or ("the register shown and the register enforced could not be confirmed as the same approved version, "
                    "so this content is internal only and cannot go to clients")
        reader_mm = (len(problems) - 1, f"licence register: {rp}")
    complete = True
    recs: list[dict] = []
    try:
        why = imf_evidence_problem(d)                         # SEC-C-014 M1: no evidence -> cannot tell -> refuse
        if why:
            complete = False
            problems.append(f"provenance evidence: {why}")
        recs = _records(d)
    except Exception as e:                                   # noqa: BLE001 - cannot tell: fail closed
        complete = False
        problems.append(f"provenance records could not be read ({type(e).__name__})")
    try:
        from ..ingestion import audit
        try:
            nat_ok = audit.national_licence_ok(d)
        except Exception:                                    # noqa: BLE001 - cannot tell: nothing cleared
            nat_ok = set()
    except Exception as e:                                   # noqa: BLE001
        audit = None
        complete = False
        problems.append(f"ingestion.audit unavailable ({type(e).__name__})")

    sources: dict[str, dict] = {}
    internal: dict[tuple, dict] = {}
    trusted_yes_needed = False
    code_re = weo_code_re()                                  # EQ-C-0151

    def src(sid, licence, ok, attribution):
        return sources.setdefault(sid, {"source_id": sid, "licence": licence, "client_ok": ok,
                                        "attribution": attribution, "labels": [], "cells": 0})

    for r in recs:
        label = r["source"]
        if not label:
            hits, own = [], False
        else:
            own = bool(OWN_SOURCE_RE.search(label))
            hits = match_rows(rows, label, r["series"], r["licence"])
        # EQ-C-0151 (SEC-C-022): an IMF / WEO input named only in the free-text provenance (transform) or by its WEO
        # code is caught here, whatever the source label says; the register's IMF rows decide.
        extra, text_why = imf_text_hits(rows, r, code_re)
        hits = hits + [h for h in extra if h not in hits]
        why = None
        if audit is not None:
            try:
                why = audit.client_output_reason(label, r["licence"], r["series"], national_ok=nat_ok, data_dir=d)
            except Exception as e:                           # noqa: BLE001
                why = f"audit check failed ({type(e).__name__})"
        fb = ("desk estimate", "the desk's own estimate") if own else _fallback(label)
        restrict = None
        if why:
            restrict = (hits[0]["source_id"] if hits else fb[0], hits[0]["licence"] if hits else why, why)
        if restrict is None and text_why:
            restrict = ("imf_derived", "IMF terms (EXC-003): internal use only", text_why)
        if restrict is None:
            for h in extra:
                if not h["client_ok"]:
                    restrict = (h["source_id"], h["licence"], f"licence register: client_ok=no ({h['source_id']}); the "
                                "provenance names an IMF / WEO input (EQ-C-0151)")
                    break
        if own and not hits:
            if restrict is None:
                continue                                     # the desk's own number: no third-party licence
        for h in hits:
            s = src(h["source_id"], h["licence"], h["client_ok"], h["attribution"])
            s["cells"] += 1
            if label not in s["labels"] and len(s["labels"]) < 10:
                s["labels"].append(label)
            if not h["client_ok"] and restrict is None:
                restrict = (h["source_id"], h["licence"], f"licence register: client_ok=no ({h['source_id']})")
            if h["client_ok"]:
                trusted_yes_needed = True
        if not hits and not own:
            if reg["ok"]:
                sid, lic = UNREGISTERED, "not in the licence register"
            else:
                sid, lic = fb[0], f"{fb[1]} (licence register missing, EQ-A-0076)"
            s = src(sid, lic, False, "")
            s["cells"] += 1
            if (label or "(empty source)") not in s["labels"] and len(s["labels"]) < 10:
                s["labels"].append(label or "(empty source)")
            if restrict is None:
                restrict = (sid, lic, ("source not in the licence register" if reg["ok"] else "licence register missing")
                            + (f": {label[:80]!r}" if label else ": provenance row has no source"))
        if restrict:
            k = (r["table"], r["key"], r["country"], label)
            internal.setdefault(k, {"table": r["table"], "key": r["key"], "country": r["country"], "source": label,
                                    "source_id": restrict[0], "licence": restrict[1], "reason": restrict[2],
                                    "from": r["from"]})
    if trusted_yes_needed and not reg["governed"]:
        problems.append(f"data/{REGISTER_NAME} {CHANGE_CONTROL_NOTE} (econquest change): its client_ok=yes rows "
                        "are not trusted for client output (Sam's decision)")
    srcs = sorted(sources.values(), key=lambda s: (-s["cells"], s["source_id"]))
    reader = list(problems)
    if reader_mm:
        reader[reader_mm[0]] = reader_mm[1]
    return {"register": reg, "complete": complete, "problems": problems, "reader_problems": reader, "sources": srcs,
            "internal_only": sorted(internal.values(), key=lambda c: (c["source_id"], c["table"], c["key"], c["country"])),
            "attribution": attribution_lines(srcs),
            "client_ok": bool(reg["ok"] and complete and not internal and not problems)}


def _fallback(label: str) -> tuple[str, str]:
    """(name, terms) for a source label from ops/client_check.licence_table (generated from Team A's register,
    HO-20261025-A-C-007), for the label of an audit restriction: the name groups labels (imf-reader -> imf_weo).
    While the register is missing or invalid the table raises, so the label itself is used."""
    try:
        from ..ops.client_check import licence_of, licence_table
        table = licence_table()
        names = [n for n in licence_of(label, table) if n != "?"]
    except Exception:                                        # noqa: BLE001
        table, names = {}, []
    if names:
        return names[0], table[names[0]]["terms"]
    return (label[:60] or "no source"), "licence not recorded"


def attribution_lines(sources: list[dict]) -> list[str]:
    """One line per source used: the register's attribution text, else source id and licence."""
    out = []
    for s in sources:
        if s["attribution"]:
            line = s["attribution"]
        elif s["source_id"] == UNREGISTERED:
            line = f"Unregistered sources ({', '.join(s['labels'][:3])}): licence not recorded, internal use only"
        else:
            line = f"{s['source_id']}: {s['licence']}"
        if line not in out:
            out.append(line)
    return out


def failure_state(why: str) -> dict:
    """The state evaluate returns when it could not run at all: nothing allowed for clients."""
    return {"register": {"ok": False, "rows": 0, "governed": False, "problem": why}, "complete": False,
            "problems": [why], "sources": [], "internal_only": [], "attribution": [], "client_ok": False}


def safe_evaluate(data_dir) -> dict:
    try:
        return evaluate(data_dir)
    except Exception as e:                                   # noqa: BLE001 - cannot tell: fail closed
        return failure_state(f"licence check failed ({type(e).__name__})")


# ---------------------------------------------------------------- provenance evidence (was presentation/research.py)
EVIDENCE_COLUMNS = ("table", "key", "country", "value", "source")


def imf_evidence_problem(data_dir) -> str | None:
    """None when the IMF client-output check has its evidence: no applied cells (no indicators.csv / countries.csv), or
    data/audit_trail.csv is a regular file with EVIDENCE_COLUMNS and at least one row. Otherwise why not."""
    d = Path(data_dir)
    applied = [n for n in ("indicators.csv", "countries.csv") if (d / n).exists() or (d / n).is_symlink()]
    if not applied:
        return None
    p = d / "audit_trail.csv"
    if p.is_symlink() or not p.is_file():
        return (f"data/audit_trail.csv is missing (or a symlink) while {' and '.join(applied)} hold applied cells: "
                "the IMF client-output check cannot tie cells to sources")
    try:
        import pandas as pd
        head = pd.read_csv(p, dtype=str, keep_default_na=False, nrows=1)
    except (ValueError, OSError) as e:
        return f"data/audit_trail.csv cannot be read ({type(e).__name__}): the IMF client-output check cannot run"
    missing = [c for c in EVIDENCE_COLUMNS if c not in head.columns]
    if missing:
        return f"data/audit_trail.csv lacks columns {missing}: the IMF client-output check cannot run"
    if head.empty:
        return "data/audit_trail.csv has no rows while cells are applied: the IMF client-output check cannot run"
    return None
