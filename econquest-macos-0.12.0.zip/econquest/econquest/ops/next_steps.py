"""`econquest next` (EQ-C-0092): the Mac pass of the installed release in order, one step at a time, resumable.

    econquest next [--json]                      # read only: every step done / next / waiting, and the next command
    econquest next --run                         # run the one next step, only when it is safe (no apply, no hold release)
    econquest next --run --apply-fx              # ... and allow the next step to be the official FX apply
    econquest next --run --apply-prices          # ... and allow the next step to be `market_history apply`
    econquest next --state PATH [--report PATH]  # read an uploaded state.json / report.json (e.g. team/inbox/pull-...);
                                                 # read only: refused with --run (SEC-C-016 M1)

The order is Team A's (docs/governance/releases/0.4.2-2026-10-24-package.md "Mac steps", docs/runbooks/A-mac-pull-pack.md,
docs/runbooks/A-official-fx.md):

  1 probe   theratesapi.com probe               python -m econquest.ingestion.official.theratesapi --probe
  2 fx      official FX fetch, then --apply-fx through the pull pack
  3 holds   release the MYR/COL holds and any change-holds: review approve, then review apply
  4 prices  market_history build -> Team B's dossier section 7 recheck -> market_history apply
  5 panel   while WEO is deferred (EQ-A-0087; state.json panel_history.artifacts.deferred, or the installed pack's
            PANEL_DEFERRED when no 0.5.0 run is on disk): World Bank PV.EST probe, then the pack rerun
            `pullpack run --panel-sources worldbank --redo universe` (A-mac-pull-pack.md "0.5.0 Mac order", EQ-C-0103);
            with WEO in the sources: IMF WEO API probe, then the rerun (manual list if WEO releases stay missing)
  6 attest  batch attestation of the hand-entered cells
  7 prereq  UCDP token (Keychain) and the BoC-BoE (CRAG) workbook

State comes from files on disk only, never from memory of what was typed: the pull pack's state.json / report.json
(through Team A's ingestion.landing.load_pack: size-bounded, schema-checked), the saved vintages and the review ledger
(ingestion.feeds.vintage_review), the installed prices.csv and its builds (ingestion.market_history), the IMF probe
folder, the attestation ledger and UCDP token presence (ops.open_items; the token value is never read). Each step is
judged on its own, so a pass done partly or out of order (FX-only prices applied 2026-10-25 00:19Z before the FX apply
and the holds) shows the done steps as done and points at the first one that is not.

States: done; next (the first step Sam can act on); todo (Sam can act, after the next one); waiting (on Team B, Team A,
UCDP, or an earlier step: named in waiting_on); unknown (a source could not be read: the error type, never a path).

`--run` runs only the step marked next, and only if that step's command is safe: a probe, a fetch or build that
stages without applying, a resumable pack run that applies nothing. The FX apply needs --apply-fx and the prices apply
needs --apply-prices as well (and the prices apply is offered only after Team B's recheck is on disk). Releasing holds,
attesting and storing the UCDP token are never run from here: they need Sam's name or a secret prompt. Each --run is
appended to <out>/next/runs.jsonl (step, command, exit code) and to the operator action log by cli.main.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import re
import shlex
import shutil
import subprocess
import sys
from pathlib import Path

from .macpull import RUN as MAC_RUN, _CTRL

STEPS = (
    ("probe", "theratesapi.com probe"),
    ("fx", "Official FX: fetch, then apply through the pull pack"),
    ("holds", "Release the gate holds (MYR/COL and any change-holds)"),
    ("prices", "FX-only prices: build, Team B section 7 recheck, apply"),
    ("panel", "Panel history: probe, then rerun the pack"),
    ("attest", "Batch attestation of hand-entered cells"),
    ("prereq", "UCDP token and BoC-BoE (CRAG) workbook"),
)
STATES = ("done", "next", "todo", "waiting", "unknown")
EXIT_DONE, EXIT_ERROR, EXIT_LEFT = 0, 1, 2
RUNS_FILE = Path("next") / "runs.jsonl"            # under --out
PROBE_DIR = Path("outputs") / "weo_api_probe"      # panel_history --probe-out default (A-mac-pull-pack.md)
DOSSIER = Path("docs") / "validation" / "dossier" / "fx-only-prices.md"
THERATES_EXC = "EXC-005"
MAX_JSON = 4 * 2 ** 20
TS_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$")

PROBE_CMD = "python -m econquest.ingestion.official.theratesapi --probe"
FX_RUN = f"{MAC_RUN} --steps fx"
FX_REDO = f"{MAC_RUN} --steps fx --redo fx"
FX_APPLY = f"{MAC_RUN} --steps fx --apply-fx"
MH = "python -m econquest.ingestion.market_history"
WEO_PROBE = "python -m econquest.ingestion.panel_history --probe-weo-api --probe-out outputs/weo_api_probe"
PACK_REDO_UNIVERSE = f"caffeinate -i {MAC_RUN} --redo universe"
MANUAL_LIST = "python -m econquest.ingestion.panel_history --out data/panel --manual-list"
# 0.5.0 Mac order while WEO is deferred (HO-20261025-A-C-013, HO-20261025-A-C-011; EQ-C-0103)
WEO_TICKET = "EQ-A-0087"
WB_PROBE_DIR = Path("outputs") / "wb_probe"        # panel_history --probe-wb-out default
WB_PROBE = "python -m econquest.ingestion.panel_history --probe-wb PV.EST"
PACK_WB_REDO_UNIVERSE = "caffeinate -i python -m econquest.ingestion.pullpack run --panel-sources worldbank --redo universe"


# ---------------------------------------------------------------- small helpers
def _now(now=None) -> str:
    return (now or dt.datetime.now(dt.timezone.utc)).strftime("%Y-%m-%dT%H:%M:%SZ")


def _ts(v) -> str:
    """A pack timestamp, or '' when it is not one (state.json is untrusted input)."""
    s = str(v or "")
    return s if TS_RE.match(s) else ""


def _q(v) -> str:
    return shlex.quote(str(v))


_HOME_RE = re.compile(r"(?:/Users|/home)/[^/\s'\"]+")


def scrub(text, root: Path | None = None) -> str:
    """One line, no control characters (SEC-C-011 I1), no local absolute path (the GUI returns this as JSON)."""
    t = _CTRL.sub("", re.sub(r"[\t\r\n]+", " ", str(text or ""))).strip()
    for p, rep in ((str(root) if root else "", "."), (str(Path.home()), "~")):
        if p and len(p) > 1:
            t = t.replace(p, rep)
    return _HOME_RE.sub("~", t)


def _read_json(p: Path) -> dict | None:
    try:
        if not p.is_file() or p.stat().st_size > MAX_JSON:
            return None
        obj = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError, RecursionError):
        return None
    return obj if isinstance(obj, dict) else None


def _sha(p: Path) -> str:
    return hashlib.sha256(p.read_bytes()).hexdigest()


def _step(sid: str, state: str, detail=(), commands=(), waiting_on: str = "", run=None, evidence=()) -> dict:
    """run: None, or {"kind": "safe"|"apply-fx"|"apply-prices", "command": the printed command it runs}."""
    n = [s for s, _ in STEPS].index(sid) + 1
    return {"n": n, "id": sid, "title": dict(STEPS)[sid], "state": state, "waiting_on": waiting_on,
            "detail": [d for d in detail if d], "commands": list(commands), "run": run, "evidence": list(evidence)}


class Ctx:
    """Everything a step reads, gathered once. Nothing here writes."""

    def __init__(self, data_dir, out_dir=None, state=None, report=None, env=None, home=None, now=None):
        self.d = Path(data_dir)
        self.root = self.d.resolve().parent
        self.out = Path(out_dir) if out_dir else self.root / "outputs"
        self.env = env
        self.home = Path(home) if home else Path.home()
        self.now = now
        self.records, self.pack_note, self.pack_error = {}, "", ""
        try:
            from ..ingestion.landing import LandingError, load_pack
            try:
                pk = load_pack(self.d, report, state)
                self.records = {k: v for k, v in pk["records"].items() if isinstance(v, dict)}
                self.pack_note = "; ".join(pk.get("notes") or [])
            except LandingError as e:
                msg = str(e)
                if msg.startswith("no pull has landed"):
                    self.pack_note = "the pull pack has not run here yet (no state.json or report.json)"
                else:
                    self.pack_error = scrub(msg, self.root)
        except Exception as e:                           # noqa: BLE001 - one unreadable source never hides the rest
            self.pack_error = f"pull pack state unreadable ({type(e).__name__})"
        self.runs = self._runs()

    def rec(self, sid: str) -> dict:
        return self.records.get(sid) or {}

    def art(self, sid: str) -> dict:
        a = self.rec(sid).get("artifacts")
        return a if isinstance(a, dict) else {}

    def _runs(self) -> list[dict]:
        p = self.out / RUNS_FILE
        rows = []
        try:
            for line in p.read_text(encoding="utf-8").splitlines()[-500:] if p.is_file() else []:
                try:
                    r = json.loads(line)
                except ValueError:
                    continue
                if isinstance(r, dict):
                    rows.append(r)
        except OSError:
            pass
        return rows


def _verified(rec: dict) -> bool:
    v = rec.get("verify")
    return rec.get("status") == "done" and isinstance(v, dict) and bool(v.get("passed"))


# ---------------------------------------------------------------- 1 probe
def _sidecars(c: Ctx) -> list[tuple[str, dict]]:
    mh = c.d / "market_history"
    out = [("installed", _read_json(mh / "prices.provenance.json") or {})]
    for p in sorted((mh / "builds").glob("*/prices.provenance.json")) if (mh / "builds").is_dir() else []:
        out.append((p.parent.name, _read_json(p) or {}))
    return out


def step_probe(c: Ctx) -> dict:
    ok_runs = [r for r in c.runs if r.get("step") == "probe" and r.get("exit_code") in (0, 2)]
    if ok_runs:
        r = ok_runs[-1]
        return _step("probe", "done", [f"probe answered at {_ts(r.get('ts_utc')) or 'an unrecorded time'} (exit "
                                       f"{r.get('exit_code')}: 0 all five currencies, 2 some missing); send Team A the output"],
                     evidence=["outputs/next/runs.jsonl"])
    raw = c.d / "live" / "raw_theratesapi_fx.csv"
    if raw.is_file():
        return _step("probe", "done", ["a fetch already used theratesapi.com on this machine (data/live/raw_theratesapi_fx.csv): "
                                       "the mirror answers; the probe adds nothing the fetch did not check"],
                     evidence=["data/live/raw_theratesapi_fx.csv"])
    for name, meta in _sidecars(c):
        cols = ((meta.get("exceptions") or {}).get(THERATES_EXC) or {}).get("columns") if isinstance(meta.get("exceptions"), dict) else None
        if cols:
            where = "the installed prices.csv" if name == "installed" else f"build {name}"
            return _step("probe", "done", [f"theratesapi.com served {where} ({', '.join(map(str, cols[:6]))}; {THERATES_EXC}): the mirror "
                                           "answers from this machine. Run the probe anyway if Team A asks for its output."],
                         evidence=["data/market_history/prices.provenance.json" if name == "installed"
                                   else f"data/market_history/builds/{name}/prices.provenance.json"])
    return _step("probe", "todo", ["one GET of https://theratesapi.com/api/latest; prints VES, NGN, PKR, VND, ZMW per USD and "
                                   "writes nothing. Exit 0 all five there, 2 some missing, 1 request failed. Send Team A the output."],
                 [PROBE_CMD], run={"kind": "safe", "command": PROBE_CMD})


# ---------------------------------------------------------------- 2 fx
def fx_applied(c: Ctx) -> bool:
    r, a = c.rec("fx"), c.art("fx")
    return r.get("status") == "done" or (a.get("apply_pending") is False and isinstance(a.get("applied"), dict))


def step_fx(c: Ctx) -> dict:
    if c.pack_error:
        return _step("fx", "unknown", [c.pack_error])
    r, a = c.rec("fx"), c.art("fx")
    feeds = a.get("feeds") if isinstance(a.get("feeds"), dict) else {}
    vid = scrub(a.get("vintage_id") or "", c.root)
    st = str(r.get("status") or "pending")
    has_tr = "theratesapi_fx" in feeds
    feed_line = ("feeds: " + "; ".join(f"{scrub(k)} {scrub(v)}" for k, v in sorted(feeds.items()))) if feeds else ""
    why_pack = ("The pack applies only a vintage it fetched itself (a held fx step reuses its vintage, no refetch), so "
                "the fetch for this step runs inside the pack: it runs the same feeds as `econquest fetch --only fx` "
                "(A-official-fx.md), theratesapi_fx included. If the new source misbehaves, the release note's fallback "
                "is `econquest fetch --only bis_xru,ecb_exr`; ask Team A before applying that way.")
    ev = ["data/live/pullpack/state.json"]
    if fx_applied(c):
        cnt = r.get("counts") if isinstance(r.get("counts"), dict) else {}
        if has_tr:
            return _step("fx", "done", [f"vintage {vid} applied through the pack ({_ts(r.get('finished_utc'))})", feed_line,
                                        f"restricted-source cells after the apply: {cnt.get('restricted_source_cells', '?')} "
                                        "(the MYR/COL holds keep theirs until step 3)"], evidence=ev)
        return _step("fx", "todo", [f"vintage {vid} was applied, but it was fetched before the theratesapi_fx feed (0.4.2): "
                                    "VES, NGN, PKR, VND and ZMW are not in it. Fetch again (no apply), check, then apply.",
                                    feed_line, why_pack], [FX_REDO, FX_APPLY + "    # after the checklist and a BRL/USD spot-check"],
                     run={"kind": "safe", "command": FX_REDO}, evidence=ev)
    if st == "held" and a.get("apply_pending") and vid and isinstance(r.get("verify"), dict) and r["verify"].get("passed"):
        if has_tr:
            return _step("fx", "todo", [f"vintage {vid} fetched and verified ({_ts(r.get('finished_utc'))}), held for --apply-fx", feed_line,
                                        "Before applying: read the FX checklist (`econquest mac-pull report`), spot-check one rate "
                                        "(e.g. BRL/USD) against the central bank's page. Held cells stay held."],
                         ["econquest mac-pull report    # the FX checklist and BIS-vs-ECB cross-check", FX_APPLY],
                         run={"kind": "apply-fx", "command": FX_APPLY}, evidence=ev)
        return _step("fx", "todo", [f"the pack's held vintage {vid} ({_ts(r.get('finished_utc'))}) was fetched before the "
                                    "theratesapi_fx feed (0.4.2): applying it now would leave VES, NGN, PKR, VND and ZMW out. "
                                    "Fetch again inside the pack (no apply), then apply that vintage.", feed_line, why_pack],
                     [FX_REDO, FX_APPLY + "    # after the checklist and a BRL/USD spot-check"],
                     run={"kind": "safe", "command": FX_REDO}, evidence=ev)
    reason = scrub(r.get("reason") or "", c.root)
    if st == "held":
        return _step("fx", "todo", [f"held: {reason or 'no reason recorded'}", "Send report.md to Team A, then fetch again."],
                     [FX_REDO], run={"kind": "safe", "command": FX_REDO}, evidence=ev)
    what = {"pending": "not run yet", "running": "interrupted; rerun to resume", "failed": f"failed: {reason}",
            "skipped": f"skipped: {reason}"}.get(st, st)
    return _step("fx", "todo", [f"fx step {what}", c.pack_note if st == "pending" else "", why_pack],
                 [FX_RUN, FX_APPLY + "    # after the checklist and a BRL/USD spot-check"],
                 run={"kind": "safe", "command": FX_RUN}, evidence=ev if c.records else [])


# ---------------------------------------------------------------- 3 holds
def _cell_value(c: Ctx, table: str, key: str, country: str):
    """The value applied in countries.csv (Country Profile) or indicators.csv (Inputs), or None."""
    import pandas as pd
    try:
        if table == "Country Profile":
            df = pd.read_csv(c.d / "countries.csv", dtype=str, keep_default_na=False)
            row = df[df["country"] == country]
            return float(row.iloc[0][key]) if len(row) and key in df.columns and row.iloc[0][key] != "" else None
        if table == "Inputs":
            df = pd.read_csv(c.d / "indicators.csv", dtype=str, keep_default_na=False)
            row = df[df["id"].astype(str) == str(key)]
            return float(row.iloc[0][country]) if len(row) and country in df.columns and row.iloc[0][country] != "" else None
    except (OSError, ValueError, KeyError, IndexError):
        return None
    return None


def _same(a, b) -> bool:
    try:
        a, b = float(a), float(b)
    except (TypeError, ValueError):
        return False
    return abs(a - b) <= 1e-6 * max(1.0, abs(a), abs(b))


def step_holds(c: Ctx) -> dict:
    if not fx_applied(c):
        return _step("holds", "waiting", ["the MYR/COL holds (and any change-holds) are in the FX vintage step 2 applies; "
                                          "they are decided against that vintage"], waiting_on="step 2 (FX apply)")
    from ..ingestion.audit import restricted_source_cells
    from ..ingestion.feeds import latest_vintage, vintage_review
    try:
        vid = latest_vintage(c.d)
        rv = vintage_review(c.d, vid)
    except Exception as e:                               # noqa: BLE001 - a vintage that does not verify is reported
        return _step("holds", "unknown", [f"could not read the latest vintage's review ({type(e).__name__})"])
    pack_vid = str(c.art("fx").get("vintage_id") or "")
    note = (f"the newest vintage is {vid}, not the pack's {scrub(pack_vid)}: decisions bind to the newest one"
            if pack_vid and pack_vid != vid else "")
    held = rv[(rv["status"] == "hold") & (rv["effective"] == "held")]
    released = rv[rv["effective"] == "released"]
    not_applied = [r for r in released.itertuples(index=False)
                   if not _same(_cell_value(c, r.table, str(r.key), r.country), r.live)]
    cells = [f"{r.table} {r.key} {r.country}: {scrub(r.reason)}" for r in held.itertuples(index=False)]
    if len(held):
        triples = " ".join(f"{_q(r.table)} {_q(r.key)} {_q(r.country)}" for r in held.itertuples(index=False))
        return _step("holds", "todo", [f"{len(held)} held cell(s) in vintage {vid} with no approved apply bound to it:", *cells[:20],
                                       note, "Use --approver OTHER for four-eyes instead of --self-approved; "
                                       "--decision hold keeps a cell on seed."],
                     [f"econquest review list --pending --vintage {vid}",
                      f"econquest review approve {triples} --author NAME --self-approved --vintage {vid}",
                      f"econquest review apply --vintage {vid} --dry-run", f"econquest review apply --vintage {vid}"],
                     evidence=["data/live/review_ledger.csv", f"data/live/vintages/{vid}/review.csv"])
    if not_applied:
        return _step("holds", "todo", [f"{len(not_applied)} cell(s) approved for vintage {vid} but not applied yet:",
                                       *[f"{r.table} {r.key} {r.country}" for r in not_applied[:20]], note],
                     [f"econquest review apply --vintage {vid} --dry-run", f"econquest review apply --vintage {vid}"],
                     evidence=["data/live/review_ledger.csv"])
    rc = restricted_source_cells(c.d)
    n = 0 if rc is None else len(rc)
    if n:
        which = ", ".join(f"{r.key} {r.country}" for r in rc.head(10).itertuples(index=False))
        return _step("holds", "waiting", [f"no hold left in vintage {vid}, but {n} applied cell(s) still hold restricted-source "
                                          f"values ({which}): send the list to Team A (A-official-fx.md)", note],
                     ["python -m econquest.ingestion.audit restricted"], waiting_on="Team A (restricted cells left)")
    return _step("holds", "done", [f"no held cell waiting in vintage {vid}; {len(released)} released and applied; "
                                   "0 restricted-source cells", note, "Then: `econquest audit` rewrites data/audit_trail.csv."],
                 evidence=["data/live/review_ledger.csv"])


# ---------------------------------------------------------------- 4 prices
def _valid_builds(c: Ctx) -> list[str]:
    """Build folders whose prices.csv matches their own sidecar's sha256, oldest first (folder names sort by time)."""
    from ..ingestion.market_history import SCHEMA, VINTAGE_ID_RE
    b = c.d / "market_history" / "builds"
    out = []
    for p in sorted(b.iterdir()) if b.is_dir() else []:
        meta = _read_json(p / "prices.provenance.json")
        if not (VINTAGE_ID_RE.fullmatch(p.name) and meta and meta.get("schema") == SCHEMA and (p / "prices.csv").is_file()):
            continue
        try:
            if meta.get("sha256") == _sha(p / "prices.csv"):
                out.append(p.name)
        except OSError:
            continue
    return out


def dossier_recheck(root: Path, build_id: str) -> str:
    """Team B's dossier section 7 recheck of build_id, from docs/validation/dossier/fx-only-prices.md: 'approved' (the
    section that names the build has a Decided line approving apply, or says the approval stands and apply may
    proceed), 'needs Sam' (it says the result goes back to Sam and no decision is recorded), 'rechecked' (named, no
    verdict line), '' (not named: the recheck is not on disk)."""
    try:
        text = (root / DOSSIER).read_text(encoding="utf-8")
    except (OSError, UnicodeDecodeError):
        return ""
    if not build_id or build_id not in text:
        return ""
    secs = re.split(r"(?m)^(?=## )", text)
    sec = " ".join(s for s in secs if build_id in s)
    flat = " ".join(sec.split())
    negated = re.search(r"\bnot approved\b|\bdo not apply\b|\bdon't apply\b|\bnot to apply\b|\brejected\b", flat, re.I)
    if not negated and (re.search(r"decided[^.]*approved[^.]*apply", flat, re.I)         # SEC-C-016 L3 (EQ-C-0165)
                        or re.search(r"approval stands and `?apply`? may proceed", flat, re.I)):
        return "approved"
    if re.search(r"back to Sam", flat, re.I):
        return "needs Sam"
    return "rechecked"


def step_prices(c: Ctx) -> dict:
    from ..ingestion.market_history import restricted_market_files
    mh = c.d / "market_history"
    try:
        bad = restricted_market_files(c.d)
    except Exception as e:                               # noqa: BLE001
        return _step("prices", "unknown", [f"could not check data/market_history ({type(e).__name__})"])
    builds = _valid_builds(c)
    live = mh / "prices.csv"
    side = _read_json(mh / "prices.provenance.json") or {}
    if live.is_file() and not len(bad) and side.get("vintage_id"):
        vid = scrub(side.get("vintage_id"))
        newer = [b for b in builds if b > vid]
        return _step("prices", "done", [f"installed: official FX-only build {vid} (prices.csv sha256 {str(side.get('sha256'))[:12]}..."
                                        + (f", applied {_ts(side.get('applied_utc'))}" if _ts(side.get("applied_utc")) else "") + ")",
                                        "0 engine-readable GOOGLEFINANCE-era files; the old ones are in data/market_history/archive/",
                                        (f"newer staged build(s) {', '.join(newer[-3:])} (the record job stages one each weekday): "
                                         "installing one is a new Team B recheck, not part of this pass") if newer else ""],
                     ["python -m econquest.ingestion.market_history restricted    # prints 0 ... and exits 0"],
                     evidence=["data/market_history/prices.provenance.json"])
    restricted = [f"{r.path}: {r.reason}" for r in bad.itertuples(index=False)][:5]
    if not builds:
        return _step("prices", "todo", ["no verified build under data/market_history/builds/: build one (stages only; prices.csv "
                                        "unchanged), then send the build folder to Team B for the section 7 rerun", *restricted],
                     [f"{MH} build"], run={"kind": "safe", "command": f"{MH} build"})
    b = builds[-1]
    rc = dossier_recheck(c.root, b)
    ev = [f"data/market_history/builds/{b}/", str(DOSSIER)]
    if not rc:
        return _step("prices", "waiting", [f"staged build {b} is not in Team B's dossier yet: send data/market_history/builds/{b}/ "
                                           "and the pull report to Team B (dossier section 7: effect table and replicate rerun on "
                                           "the staged file). Then `econquest next` shows the apply.", *restricted],
                     waiting_on="Team B section 7 recheck", evidence=ev)
    if rc == "needs Sam":
        return _step("prices", "waiting", [f"Team B rechecked build {b}: a base number is more than 5% off the approved proxy, so "
                                           "it goes back to you (Team B's decision card). The apply is offered after your "
                                           "decision is recorded in the dossier."], waiting_on="Sam's decision on Team B's card",
                     evidence=ev)
    cmd = f"{MH} apply --vintage {b}"
    return _step("prices", "todo", [f"Team B's section 7 recheck of build {b} is in the dossier ({rc}). Apply checks the vintage "
                                    "and build hashes, archives the GOOGLEFINANCE-era files and replaces prices.csv. Send the "
                                    "apply output back with the report.", *restricted],
                 [cmd, f"{MH} restricted    # must print 0 ... and exit 0"], run={"kind": "apply-prices", "command": cmd},
                 evidence=ev)


# ---------------------------------------------------------------- 5 panel
def weo_deferred(c: Ctx) -> str:
    """The WEO deferral ticket when step 2 runs World Bank only, else ''. state.json wins: artifacts.deferred['weo']
    (Team A, EQ-A-0079), or artifacts.sources naming weo (a full-sources run: not deferred). With no such record (a
    0.4.2 state, or no pack run yet) the installed pack's PANEL_DEFERRED decides, as that is what the next run does."""
    a = c.art("panel_history")
    dfr = a.get("deferred")
    if isinstance(dfr, dict) and "weo" in dfr:
        t = str(dfr.get("weo") or "")
        return t if re.fullmatch(r"EQ-[A-C]-\d{4}", t) else WEO_TICKET
    src = a.get("sources")
    if isinstance(src, list) and "weo" in src:
        return ""
    try:
        from ..ingestion.pullpack import PANEL_DEFERRED
    except Exception:                                    # noqa: BLE001 - an older pack has no deferral
        return ""
    t = str(PANEL_DEFERRED.get("weo") or "") if isinstance(PANEL_DEFERRED, dict) else ""
    return (t if re.fullmatch(r"EQ-[A-C]-\d{4}", t) else WEO_TICKET) if t else ""


def _step_panel_wb(c: Ctx, ticket: str) -> dict:
    """Step 5 while WEO is deferred: no IMF probe and no manual list; done on the World Bank part."""
    ph, uni = c.rec("panel_history"), c.rec("universe")
    deferred_line = f"WEO deferred ({ticket})"
    sends = ("Send back with report.md and report.json: outputs/wb_probe/probe.json, data/live/raw_worldbank.csv and "
             "data/live/review.csv (A-mac-pull-pack.md, '0.5.0 Mac order').")
    if _verified(ph):
        u = (f"universe rerun {_ts(uni.get('finished_utc'))}" if uni.get("status") == "done"
             and _ts(uni.get("finished_utc")) >= _ts(ph.get("finished_utc")) else
             "universe not rerun since (the next pack run with --redo universe does it)")
        return _step("panel", "done", [f"panel_history World Bank part done and verified ({_ts(ph.get('finished_utc'))}); {u}",
                                       deferred_line + ": EQ-A-0015/0016 stay waiting on it", sends],
                     evidence=["data/live/pullpack/state.json"] + (["outputs/wb_probe/probe.json"]
                                                                    if (c.root / WB_PROBE_DIR / "probe.json").is_file() else []))
    pj = _read_json(c.root / WB_PROBE_DIR / "probe.json")
    if pj is None:
        return _step("panel", "todo", ["1. probe the World Bank PV.EST routes (outputs/wb_probe/probe.json; exit 0 a route "
                                       "works, 1 none did; send the file back either way)",
                                       "2. then rerun the pack, World Bank only, with --redo universe (30-120 min: mains power)",
                                       deferred_line + ": no IMF probe or WEO manual list is needed"],
                     [WB_PROBE, PACK_WB_REDO_UNIVERSE], run={"kind": "safe", "command": WB_PROBE})
    pts = _ts(pj.get("utc"))
    works = pj.get("works") if isinstance(pj.get("works"), list) else []
    probe_line = (f"World Bank PV.EST probe at {pts or 'an unrecorded time'}: "
                  + (f"{len(works)} route(s) worked" if works else "no route worked (send probe.json to Team A)"))
    ph_st = str(ph.get("status") or "pending")
    reason = scrub(ph.get("reason") or "", c.root)
    status = {"pending": "not run", "running": "interrupted", "failed": f"failed: {reason[:200]}",
              "skipped": f"skipped: {reason[:200]}", "held": f"held: {reason[:200]}",
              "done": "done but not verified"}.get(ph_st, ph_st)
    return _step("panel", "todo", [probe_line, f"panel_history {status}", deferred_line,
                                   "The rerun runs step 2 for the World Bank part (only the missing units) and reruns step 4 "
                                   "universe; done steps are skipped and fx stays held until --apply-fx. 30-120 min: mains power.",
                                   sends], [PACK_WB_REDO_UNIVERSE], run={"kind": "safe", "command": PACK_WB_REDO_UNIVERSE},
                 evidence=["outputs/wb_probe/probe.json"])


def step_panel(c: Ctx) -> dict:
    if c.pack_error:
        return _step("panel", "unknown", [c.pack_error])
    ticket = weo_deferred(c)
    if ticket:
        return _step_panel_wb(c, ticket)
    pj = _read_json(c.root / PROBE_DIR / "probe.json")
    ph, uni = c.rec("panel_history"), c.rec("universe")
    sends = ("Send back with report.md and report.json: outputs/weo_api_probe/, "
             "data/panel/staging/weo_cache/weo_route_diagnostics.jsonl, data/panel/staging/<run>/manifest.json "
             "(A-mac-pull-pack.md, 'Next run after the 2026-10-24 pull').")
    if pj is None:
        return _step("panel", "todo", ["1. probe the IMF API (one catalogue request and up to 3 samples, about 1 min; exit 0 WEO "
                                       "dataflows listed, 1 says why; send the folder back either way)",
                                       "2. then rerun the pack with --redo universe"],
                     [WEO_PROBE, PACK_REDO_UNIVERSE], run={"kind": "safe", "command": WEO_PROBE})
    pts = _ts(pj.get("created_utc"))
    probe_line = f"IMF API probe {scrub(pj.get('status'))} at {pts or 'an unrecorded time'} (outputs/weo_api_probe/)"
    ph_st = str(ph.get("status") or "pending")
    uni_after = bool(pts) and _ts(uni.get("finished_utc")) > pts and uni.get("status") == "done"
    if _verified(ph) and uni_after:
        return _step("panel", "done", [probe_line, f"panel_history done and verified ({_ts(ph.get('finished_utc'))}); universe "
                                       f"rerun {_ts(uni.get('finished_utc'))}", sends],
                     evidence=["outputs/weo_api_probe/probe.json", "data/live/pullpack/state.json"])
    rerun_after = bool(pts) and _ts(ph.get("started_utc")) > pts
    reason = scrub(ph.get("reason") or "", c.root)
    if rerun_after and ph_st == "failed" and "weo/" in reason:
        return _step("panel", "todo", [probe_line, f"the rerun after the probe still misses WEO releases: {reason[:300]}",
                                       "Print the manual list (no network): per release the file name, folder and IMF page. Save "
                                       "each tab-delimited 'all countries' file under the printed name (not .xlsx), then rerun.",
                                       sends], [MANUAL_LIST, PACK_REDO_UNIVERSE],
                     run={"kind": "safe", "command": MANUAL_LIST}, evidence=["data/live/pullpack/state.json"])
    status = {"pending": "not run", "running": "interrupted", "failed": f"failed: {reason[:200]}",
              "skipped": f"skipped: {reason[:200]}", "held": f"held: {reason[:200]}"}.get(ph_st, ph_st)
    return _step("panel", "todo", [probe_line, f"panel_history {status}" + ("" if rerun_after else " (before the probe)"),
                                   "The rerun resumes the panel history run (only the missing units) and reruns step 4 universe; "
                                   "done steps are skipped and fx stays held until --apply-fx. 30-120 min: mains power.", sends],
                 [PACK_REDO_UNIVERSE], run={"kind": "safe", "command": PACK_REDO_UNIVERSE},
                 evidence=["outputs/weo_api_probe/probe.json"])


# ---------------------------------------------------------------- 6 attest
def step_attest(c: Ctx) -> dict:
    from .open_items import _attest_item
    try:
        it = _attest_item(c.d)
    except (Exception, SystemExit) as e:                 # noqa: BLE001
        return _step("attest", "unknown", [f"could not read the attestation ledger ({type(e).__name__})"])
    if it["status"] == "clear":
        return _step("attest", "done", [it["summary"]], evidence=[it["source"]])
    return _step("attest", "todo", [it["summary"], "Each batch: dry run first, then --confirm with your name and the count and "
                                    "digest the dry run printed. Not run from here: it needs your name."],
                 it["commands"], evidence=[it["source"]])


# ---------------------------------------------------------------- 7 prereq
def step_prereq(c: Ctx) -> dict:
    from ..ingestion.pullpack import CRAG_FILE, CRAG_URL
    from .open_items import UCDP_KEYCHAIN_SERVICE, ucdp_token_state
    lines, cmds, run = [], [], None
    states = []
    ucdp, crag = c.rec("ucdp"), c.rec("crag")
    tok = ucdp_token_state(c.d, c.env)
    if ucdp.get("status") == "done":
        states.append("done"); lines.append(f"UCDP: pulled ({_ts(ucdp.get('finished_utc'))})")
    elif tok["configured"]:
        states.append("todo")
        lines.append("UCDP: token present (" + (f"${tok['env_name']} set" if tok["in_env"] else "Keychain item found") +
                     "; value not read); pull it with the pack (the token goes in the environment, never on the command line)")
        cmds.append(f'export {tok["env_name"]}="$(security find-generic-password -s {UCDP_KEYCHAIN_SERVICE} -w)"; '
                    f'{MAC_RUN} --steps ucdp; unset {tok["env_name"]}')
    else:
        states.append("waiting")
        lines.append("UCDP: no token (free, by email, 3-5 working days); request it if not done, then store it in the Keychain "
                     "(the command prompts; never paste it into a file)"
                     + ("" if tok["keychain"] is not None else ". Keychain not checked off the Mac"))
        cmds.append(f'security add-generic-password -s {UCDP_KEYCHAIN_SERVICE} -a "$USER" -w')
    xlsx = c.home / "Downloads" / CRAG_FILE
    if crag.get("status") == "done" or (c.d / "panel" / "sovereign_defaults_crag.csv").is_file():
        states.append("done"); lines.append("BoC-BoE (CRAG): imported (data/panel/sovereign_defaults_crag.csv)")
    elif xlsx.is_file():
        states.append("todo"); lines.append(f"BoC-BoE (CRAG): workbook found at ~/Downloads/{CRAG_FILE}; import it with the pack")
        cmds.append(f"{MAC_RUN} --steps crag"); run = {"kind": "safe", "command": f"{MAC_RUN} --steps crag"}
    else:
        states.append("todo")
        lines.append(f"BoC-BoE (CRAG): download {CRAG_URL} to ~/Downloads/{CRAG_FILE} (browser), then import it with the pack")
        cmds.append(f"{MAC_RUN} --steps crag    # after the download")
    st = "done" if all(s == "done" for s in states) else "todo" if "todo" in states else "waiting"
    return _step("prereq", st, lines, cmds if st != "done" else [], waiting_on="UCDP's token email" if st == "waiting" else "",
                 run=run if st == "todo" else None)


COLLECT = {"probe": step_probe, "fx": step_fx, "holds": step_holds, "prices": step_prices, "panel": step_panel,
           "attest": step_attest, "prereq": step_prereq}


def collect(data_dir, out_dir=None, state=None, report=None, env=None, home=None, now=None) -> dict:
    """Every step of the Mac pass with its state, and which one is next. Reads only."""
    c = Ctx(data_dir, out_dir, state, report, env, home, now)
    steps = []
    for sid, _ in STEPS:
        try:
            s = COLLECT[sid](c)
        except (Exception, SystemExit) as e:             # noqa: BLE001 - one bad source never hides the rest
            s = _step(sid, "unknown", [f"could not be checked ({type(e).__name__})"])
        s["detail"] = [scrub(x, c.root) for x in s["detail"]]
        s["commands"] = [scrub(x, c.root) for x in s["commands"]]
        steps.append(s)
    nxt = next((s for s in steps if s["state"] == "todo"), None)
    if nxt:
        nxt["state"] = "next"
    done = sum(s["state"] == "done" for s in steps)
    notices = []
    try:                                                 # EQ-C-0110: the calendar_tests job must be installed on the Mac
        from .open_items import calendar_job_notice
        notices = [n for n in [calendar_job_notice(c.root)] if n]
    except Exception:                                    # noqa: BLE001 - a notice never hides the steps
        notices = []
    from .install_check import safe_warnings          # EQ-C-0112: reset / Downloads copy / no backup / deleted folder
    iw = safe_warnings(c.d, env=env, user_home=home)
    mo = mac_order([c.root])
    return {"generated_utc": _now(now), "done": done, "total": len(steps), "next": nxt["n"] if nxt else None,
            "waiting": [f"step {s['n']}: {s['waiting_on']}" for s in steps if s["state"] == "waiting"],
            "pack": scrub(c.pack_error or c.pack_note, c.root), "steps": steps, "notices": notices,
            "install_warnings": iw, "mac_order": mo["line"], "version": mo["version"], "mac_order_section": mo["order"],
            "parked": MVP_PARKED_LINE, "first_pass": FIRST_PASS_LINE}


# EQ-C-0114 / EQ-C-0115: the Mac order is Team A's runbook section "## <version> Mac order". Nothing here names a version:
# the installed version is econquest.__version__ and the section is the one for that version in the runbook on disk, or
# the newest one there when this version has none (so the header never points at a release that is not installed).
MAC_RUNBOOK = "docs/runbooks/A-mac-pull-pack.md"
_ORDER_HEAD = re.compile(r"^## (\d+(?:\.\d+)+) Mac order\b", re.M)
# Sam's rule (2026-10-25 16:36Z, PI-10): no Mac steps from Sam until the MVP exists
MVP_PARKED_LINE = ("Parked: the Mac pass waits until the MVP is reached (team/mvp-checklist.md); nothing here is for "
                   "Sam to run before then.")
# EQ-C-0134: the whole first pass (team/first-mac-pass.md) is walked by `econquest first-pass`; these steps are its step 12
FIRST_PASS_LINE = ("Whole first pass: econquest first-pass --next (team/first-mac-pass.md, a check after each step, then "
                   "one upload bundle); the steps below are its step 12, the pulls.")


def _vkey(v: str) -> tuple:
    return tuple(int(x) for x in v.split("."))


def mac_order(roots=None) -> dict:
    """{"version": installed, "order": runbook section version or None, "line": header line}. Reads the runbook under the
    first root that has it (the install, then this source tree); never raises."""
    from .. import __version__
    order = None
    for r in [*(roots or []), Path(__file__).resolve().parents[2]]:
        try:
            found = _ORDER_HEAD.findall((Path(r) / MAC_RUNBOOK).read_text(encoding="utf-8"))
        except (OSError, ValueError):
            continue
        if found:
            order = __version__ if __version__ in found else max(found, key=_vkey)
            break
    if order:
        line = f'{__version__} install: run {MAC_RUNBOOK} section "{order} Mac order" first, in its order.'
    else:
        line = f"{__version__} install: no Mac order section found in {MAC_RUNBOOK}."
    return {"version": __version__, "order": order, "line": line}


MAC_ORDER_LINE = mac_order()["line"]

MARK = {"done": "[done]   ", "next": "[NEXT]   ", "todo": "[todo]   ", "waiting": "[waiting]", "unknown": "[??]     "}


def _label(rep: dict) -> str:
    """'econquest 0.8.0; runbook order 0.6.0' from the report (EQ-C-0144: the installed version and the runbook's Mac
    order section, named apart so two version numbers side by side do not read as one); falls back to the installed
    version for an older report."""
    v = rep.get("version") or mac_order()["version"]
    sec = rep.get("mac_order_section")
    return f"econquest {v}; runbook order {sec}" if sec else f"econquest {v}"


def render_text(rep: dict) -> str:
    from .install_check import lines as _iw_lines      # EQ-C-0112: install warnings are the top lines
    top = _iw_lines(rep.get("install_warnings") or [])
    L = top + ([""] if top else []) + [f"Mac pass ({_label(rep)}), checked {rep['generated_utc']}: {rep['done']} of {rep['total']} done. "
         + (f"Next: step {rep['next']}." if rep["next"] else "Nothing for you to run now." if rep["waiting"] else "All done."),
         rep.get("mac_order") or MAC_ORDER_LINE, rep.get("parked") or MVP_PARKED_LINE,
         rep.get("first_pass") or FIRST_PASS_LINE, ""]
    for n in rep.get("notices") or []:                   # EQ-C-0110: shown first, outside the numbered steps
        L[-1:-1] = [f"Schedule: {n}"]
    for s in rep["steps"]:
        head = f"{MARK.get(s['state'], s['state'])} {s['n']}  {s['title']}"
        if s["state"] == "waiting":
            head += f": waiting on {s['waiting_on']}"
        L.append(head)
        for d in s["detail"]:
            L.append(f"              {d}")
        if s["state"] in ("next", "todo", "waiting"):
            for cmd in s["commands"]:
                L.append(f"              $ {cmd}")
        if s["state"] == "next" and s.get("run"):
            k = s["run"]["kind"]
            L.append("              (econquest next --run runs the first command"
                     + ("" if k == "safe" else f" only with --{k}: it applies") + ")")
        elif s["state"] == "next":
            L.append("              (not run by `next --run`: it needs your name, a browser or a secret prompt)")
        L.append("")
    if rep.get("pack"):
        L.append(f"Pull pack: {rep['pack']}")
    return "\n".join(L).rstrip() + "\n"


# ---------------------------------------------------------------- --run (one step)
def argv_for(command: str, data_dir: Path, out_dir: Path) -> list[str]:
    """The argv that runs a printed command on this machine: `python -m X` -> this interpreter; `econquest ...` -> this
    interpreter's econquest with the same --data/--out; data/... and outputs/... paths -> under this install; a leading
    `caffeinate -i` kept only where caffeinate exists (macOS). Only the commands this module prints are accepted."""
    parts = shlex.split(command.split("    #", 1)[0])
    pre = []
    if parts[:2] == ["caffeinate", "-i"]:
        parts = parts[2:]
        pre = ["caffeinate", "-i"] if shutil.which("caffeinate") else []
    root = Path(data_dir).resolve().parent
    fix = [str(root / p) if p.startswith(("data/", "outputs/")) else p for p in parts]
    if fix[:2] == ["python", "-m"] and len(fix) > 2 and fix[2].startswith("econquest."):
        mod = fix[2]
        rest = fix[3:]
        if mod in ("econquest.ingestion.market_history", "econquest.ingestion.pullpack"):
            rest = ["--data", str(data_dir), *rest]
        return pre + [sys.executable, "-m", mod, *rest]
    if fix[:1] == ["econquest"]:
        return pre + [sys.executable, "-m", "econquest", "--data", str(data_dir), "--out", str(out_dir), *fix[1:]]
    raise ValueError(f"not a command next --run can run: {command}")


def _record_run(out_dir: Path, step: dict, command: str, code: int, now=None) -> None:
    p = Path(out_dir) / RUNS_FILE
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "a", encoding="utf-8") as f:
        f.write(json.dumps({"ts_utc": _now(now), "step": step["id"], "n": step["n"], "command": command,
                            "exit_code": int(code)}, sort_keys=True) + "\n")


def run_next(rep: dict, data_dir, out_dir, apply_fx: bool = False, apply_prices: bool = False, runner=None) -> tuple[int, str]:
    """Run the step marked next if allowed. Returns (exit code, message). runner(argv, cwd) -> exit code (tests)."""
    s = next((x for x in rep["steps"] if x["state"] == "next"), None)
    if s is None:
        return EXIT_DONE if not rep["waiting"] else EXIT_LEFT, ("nothing to run: " + ("; ".join(rep["waiting"]) if rep["waiting"] else "every step is done"))
    spec = s.get("run")
    if not spec:
        return EXIT_LEFT, f"step {s['n']} is not run from here (it needs your name, a browser or a secret prompt): run it yourself"
    kind, cmd = spec["kind"], spec["command"]
    flags = {"apply-fx": apply_fx, "apply-prices": apply_prices}
    if kind != "safe" and not flags.get(kind):
        return EXIT_LEFT, f"step {s['n']} applies ({cmd}); nothing run. Check it, then: econquest next --run --{kind}"
    stray = [f"--{k}" for k, v in flags.items() if v and k != kind]
    if stray:
        return EXIT_LEFT, f"{' '.join(stray)} given but step {s['n']} is not that apply; nothing run"
    argv = argv_for(cmd, Path(data_dir), Path(out_dir))
    root = Path(data_dir).resolve().parent
    print(f"next --run: step {s['n']}: {cmd}", flush=True)
    if runner is None:
        code = subprocess.run(argv, cwd=str(root), check=False).returncode
    else:
        code = runner(argv, root)
    _record_run(Path(out_dir), s, cmd, code)
    return code, f"step {s['n']} exited {code}"


def cmd_next(args) -> None:
    d = Path(args.data)
    if not (d / "countries.csv").is_file():
        print(f"next: {d} is not an econquest data folder (no countries.csv); run from the econquest folder", file=sys.stderr)
        raise SystemExit(EXIT_ERROR)
    if (args.apply_fx or args.apply_prices) and not args.run:
        print("next: --apply-fx / --apply-prices only make sense with --run", file=sys.stderr)
        raise SystemExit(EXIT_ERROR)
    if args.run and (args.state or args.report):
        # SEC-C-016 M1: an uploaded state.json / report.json is untrusted and describes another machine's pack; letting
        # it pick which step runs here (e.g. an FX apply of this machine's held vintage) is refused. Read it without --run.
        print("next: --run reads only this machine's own pull pack state; drop --state / --report to run a step",
              file=sys.stderr)
        raise SystemExit(EXIT_ERROR)
    out = Path(args.out)
    rep = collect(d, out, args.state, args.report)
    if args.run:
        code, msg = run_next(rep, d, out, args.apply_fx, args.apply_prices)
        print(f"next --run: {msg}", file=sys.stderr if code else sys.stdout)
        rep = collect(d, out, args.state, args.report)
        print()
        print(render_text(rep), end="")
        raise SystemExit(code if code else (EXIT_DONE if rep["done"] == rep["total"] else EXIT_LEFT))
    print(json.dumps(rep, indent=1, default=str) if args.json else render_text(rep), end="\n" if args.json else "")
    raise SystemExit(EXIT_DONE if rep["done"] == rep["total"] else EXIT_LEFT)


def register(sub) -> None:
    nx = sub.add_parser("next", help="the Mac pass in order (theratesapi probe, FX fetch and apply, holds, FX-only prices, panel "
                        "history, attest, UCDP/CRAG): done / next / waiting per step and the exact next command; reads only "
                        "unless --run")
    nx.add_argument("--json", action="store_true", help="print the steps as JSON")
    nx.add_argument("--run", action="store_true", help="run the one next step if it is safe (probe, fetch or build without "
                    "apply, resumable pack run); never releases holds or attests")
    nx.add_argument("--apply-fx", action="store_true", help="with --run: allow the next step to be the official FX apply")
    nx.add_argument("--apply-prices", action="store_true", help="with --run: allow the next step to be market_history apply "
                    "(offered only once Team B's section 7 recheck is in the dossier)")
    nx.add_argument("--state", metavar="PATH", help="pull pack state.json to read (default data/live/pullpack/state.json)")
    nx.add_argument("--report", metavar="PATH", help="pull pack report.json to read (default next to --state)")
    nx.set_defaults(fn=cmd_next)
