"""The licence register under change control (EQ-C-0106, SEC-C-015 R44).

`data/licences.csv` (Team A's register, contract C14) is a governed file of `econquest change` (ops.approvals.FILES),
like assumptions.json and limits.json: propose -> approve -> apply, a hash-chained log, `change verify` and baselines.

The approved register is the version last applied or baselined through `econquest change`. Its sha256 is the log row's
file_sha256, and its bytes are kept content-addressed at `data/approvals/registers/licences-<sha256>.csv` (a copy is
trusted only while its bytes still hash to its name). Enforcement reads only that version:
- presentation/licences.py (`load_register`, `register_mismatch`, `register_governed`) reads the approved bytes;
- `enforce_approved(data_dir)` points Team A's resolver (ingestion.licences.register_path, $ECONQUEST_LICENCE_REGISTER)
  at the approved copy while presentation.licences.evaluate, ops/client_check.collect and the evidence build run, so
  Team A's audit / data-room hooks, `client_check.licence_table` and `require_register` read it too.

Drift check: when data/licences.csv is not byte-identical to the approved version (hand edit, deleted, symlink), or
there is no approved version yet, or the approvals log does not verify, client output and the evidence build are
refused (`problem`); internal mode only warns, and labels from the approved register when there is one. A data folder
with no register that never had an approved one keeps the old behaviour (client output refused by
presentation/licences.py, evidence built on the old rules: HO-20261025-A-C-008).

Tighten-only: a change that only makes the register stricter (client_output allowed -> restricted -> barred,
validator_nda allowed -> UNVERIFIED -> barred, internal_use yes -> no, terms_verified yes -> not yes, commercial
towards no, a new row that allows nothing, or name / url / notes) follows the ordinary approve rules. Anything else is
a loosening and is approved only by Sam (presentation.research.DECISION_OWNER): four-eyes with Sam as the approver, or
Sam self-approved under a named exception (an EXC-nnn row of docs/governance/issues-log.md). Loosening includes
client_output or validator_nda towards allowed, a removed row, a changed match rule, licence_text, attribution_text
or exc_id, and a new row that allows client output or the validator room. The first baseline is Sam's sign-off too.
"""
from __future__ import annotations

import contextlib
import csv
import hashlib
import io
import os
import threading
from pathlib import Path

REGISTER = "licences.csv"
TICKET = "EQ-C-0106"
SNAPSHOTS = "registers"
# Rank of each permission value: higher is more permissive. A change to a higher rank loosens the register.
PERMISSIVE = {"terms_verified": {"yes": 1, "UNVERIFIED": 0, "no": 0},
              "commercial": {"yes": 2, "unknown": 1, "no": 0},
              "internal_use": {"yes": 1, "no": 0},
              "client_output": {"allowed": 2, "restricted": 1, "barred": 0},
              "validator_nda": {"allowed": 2, "UNVERIFIED": 1, "barred": 0}}
# descriptive only, never read by an enforcement rule; terms_url / terms_read_utc / clause are Team A's evidence of the
# terms read (EQ-A-0093): the permission they support is terms_verified, which is ranked above
NEUTRAL = frozenset({"name", "url", "notes", "terms_url", "terms_read_utc", "clause"})
FIRST_BASELINE_CMD = ('python -m econquest change baseline licences.csv --actor "Team A AGENT-06" --approver Sam '
                      '--reason "R44: first approved licence register (EQ-C-0106)"')
TRUSTED = ("ok",)
APPROVED_STATES = ("ok", "drift", "missing", "symlink")  # an approved version exists (enforcement reads it)
# EQ-C-0123 (SEC-C-019): the DEMO profile (ops/demo_baseline.py). "demo" is a state of its own, never in TRUSTED or
# APPROVED_STATES, so every check that wants "ok" (client output, register_governed, change propose, vendor-check)
# refuses it; only enforce_approved / approved_bytes read its bytes, and only the evidence build accepts it, by name.
DEMO_STATE = "demo"
DEMO_BANNER = "DEMO baseline: not Sam's approval"
_DEMO = threading.local()                                   # per thread: only the caller that opened the profile
_DEMO_COUNT = [0]                                           # per process: any open profile refuses client writes


class LicenceGovError(ValueError):
    """A register that cannot be governed: invalid, not Team A's C14 columns, or a value that is not text."""


def columns() -> list[str]:
    """Every register column, in Team A's order (C14 plus the optional evidence columns, EQ-A-0093)."""
    from ..ingestion import licences as A
    return list(A.REGISTER_COLUMNS)


def required_columns() -> list[str]:
    from ..ingestion import licences as A
    return list(getattr(A, "REQUIRED_COLUMNS", A.REGISTER_COLUMNS))


def sha256(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


# ---------------------------------------------------------------- parse, serialise, classify
def parse(raw: bytes, where: str = f"data/{REGISTER}") -> list[dict]:
    """Rows (C14 columns, text) of a register that passes Team C's caps and Team A's validator
    (ops.licence_rule.parse_register -> ingestion.licences.validate_register). LicenceGovError otherwise."""
    from .licence_rule import LicenceRegisterError, parse_register
    try:
        parse_register(raw, where)
    except LicenceRegisterError as e:
        raise LicenceGovError(str(e)) from None
    rd = csv.DictReader(io.StringIO(raw.decode("utf-8-sig"), newline=""))
    cols = columns()
    have = [str(c).strip() for c in rd.fieldnames or []]
    missing = [c for c in required_columns() if c not in have]
    if missing:
        raise LicenceGovError(f"{where}: a governed register has Team A's C14 columns; missing {missing}")
    out = []
    for r in rd:
        r = {str(k).strip(): v for k, v in r.items() if k is not None}
        out.append({c: str(r.get(c) or "").strip() for c in cols})
    return out


def doc(rows: list[dict]) -> dict:
    """{source_id: {column: value}} in file order (what `econquest change` patches and diffs)."""
    return {r["source_id"]: {c: r[c] for c in columns() if c != "source_id"} for r in rows}


def text_of(d: dict) -> str:
    """CSV text of a {source_id: row} document: C14 header, rows in order, minimal quoting, '\\n' line ends.
    The header is columns(), so patch mode always writes the three evidence columns (terms_url, terms_read_utc, clause;
    empty when absent), also for a 16-column C14 copy (HO-20261025-A-C-015). A replace=True proposal keeps its own text."""
    cols = columns()
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(cols)
    for sid, row in d.items():
        if not isinstance(row, dict):
            raise LicenceGovError(f"/{sid}: a register row is an object of column values")
        extra = [k for k in row if k not in cols or k == "source_id"]
        if extra:
            raise LicenceGovError(f"/{sid}: unknown columns {extra[:5]}")
        bad = [k for k, v in row.items() if not isinstance(v, str)]
        if bad:
            raise LicenceGovError(f"/{sid}: register values are text (quote them as JSON strings): {bad[:5]}")
        w.writerow([sid] + [row.get(c, "") for c in cols[1:]])
    return buf.getvalue()


def classify(old: dict, new: dict) -> dict:
    """{"loosen": [...], "tighten": [...], "neutral": [...]}: what a change from `old` to `new` ({source_id: row})
    does to the register. Anything not known to be stricter or descriptive is a loosening."""
    out = {"loosen": [], "tighten": [], "neutral": []}
    for sid in old:
        if sid not in new:
            out["loosen"].append(f"{sid}: row removed (its records lose this restriction)")
    for sid, row in new.items():
        if sid not in old:
            opens = [f"{c}={row.get(c)}" for c in ("client_output", "validator_nda", "terms_verified", "commercial")
                     if PERMISSIVE[c].get(row.get(c, ""), 0) == max(PERMISSIVE[c].values())]
            (out["loosen"] if opens else out["tighten"]).append(
                f"{sid}: new row" + (f" allowing {', '.join(opens)}" if opens else " that allows nothing new"))
            continue
        for c, v in row.items():
            was = old[sid].get(c, "")
            if v == was:
                continue
            what = f"{sid}.{c}: {was!r} -> {v!r}"
            if c in PERMISSIVE:
                a, b = PERMISSIVE[c].get(was, 99), PERMISSIVE[c].get(v, 99)
                out["loosen" if b > a else "tighten" if b < a else "neutral"].append(what)
            elif c in NEUTRAL:
                out["neutral"].append(what)
            else:                                    # match rules, licence / attribution text, exc_id
                out["loosen"].append(what)
    common_old = [s for s in old if s in new]
    common_new = [s for s in new if s in old]
    if common_old != common_new:
        out["neutral"].append("row order changed")
    return out


# ---------------------------------------------------------------- the approved register
def snapshot_path(data_dir, sha: str) -> Path:
    from .approvals import approvals_dir
    return approvals_dir(data_dir) / SNAPSHOTS / f"licences-{sha}.csv"


def save_snapshot(data_dir, data: bytes) -> Path:
    """Keep the approved bytes (idempotent). Called by approvals.apply / baseline under the approvals lock."""
    from .approvals import _atomic_write, file_sha256
    p = snapshot_path(data_dir, sha256(data))
    if not (p.is_file() and not p.is_symlink() and file_sha256(p) == sha256(data)):
        if p.is_symlink():
            p.unlink()
        _atomic_write(p, data)
    return p


def _read_regular(p: Path) -> bytes | None:
    if p.is_symlink() or not p.is_file():
        return None
    try:
        return p.read_bytes()
    except OSError:
        return None


def state(data_dir) -> dict:
    """The register's governance state:
    {"status": ok | no_baseline | drift | missing | symlink | default | chain_broken, "current_sha256",
     "approved_sha256", "approved_path" (a file whose bytes hash to approved_sha256, or None), "last_event", "last_id",
     "last_ts_utc", "chain_ok"}. Never raises."""
    from . import approvals as ap
    d = Path(data_dir)
    p = d / REGISTER
    out = {"status": "default", "current_sha256": None, "approved_sha256": None, "approved_path": None,
           "last_event": "", "last_id": "", "last_ts_utc": "", "chain_ok": False}
    try:
        v = ap.verify_chain(d)
        rows = ap.read_log(d) if v["ok"] else []
    except Exception:                                    # noqa: BLE001 - cannot tell: untrusted
        v, rows = {"ok": False}, []
    out["chain_ok"] = bool(v["ok"])
    cur = _read_regular(p)
    out["current_sha256"] = sha256(cur) if cur is not None else None
    if not v["ok"]:
        out["status"] = "chain_broken"
        return out
    last = ap._last_applied(rows, REGISTER) or {}
    appr = last.get("file_sha256") or None
    out.update(approved_sha256=appr, last_event=last.get("event", ""), last_id=last.get("id", ""),
               last_ts_utc=last.get("ts_utc", ""))
    if appr:
        snap = snapshot_path(d, appr)
        sb = _read_regular(snap)
        if sb is not None and sha256(sb) == appr:
            out["approved_path"] = snap
        elif cur is not None and out["current_sha256"] == appr:
            out["approved_path"] = p
    if p.is_symlink():
        out["status"] = "symlink" if appr else "no_baseline"
    elif cur is None:
        out["status"] = "missing" if appr else ("default" if not p.exists() else "no_baseline")
    elif not appr:
        out["status"] = "no_baseline"
    else:
        out["status"] = "ok" if out["current_sha256"] == appr else "drift"
    ov = demo_override(d)
    if ov and out["status"] == "no_baseline" and not p.is_symlink() and out["current_sha256"] == ov["sha256"]:
        snap = Path(ov["snapshot"])                          # EQ-C-0123: only in the thread that opened the profile
        sb = _read_regular(snap)
        out.update(status=DEMO_STATE, approved_sha256=ov["sha256"], last_event="demo-baseline", last_id="DEMO",
                   last_ts_utc=str(ov.get("created_utc", "")), demo=True,
                   approved_path=snap if sb is not None and sha256(sb) == ov["sha256"] else None)
    return out


# ---------------------------------------------------------------- EQ-C-0123: the DEMO profile (never Sam's approval)
def demo_override(data_dir) -> dict | None:
    """The DEMO profile this thread opened for data_dir (ops/demo_baseline.active), or None. Other threads and other
    processes never see it."""
    ov = getattr(_DEMO, "override", None)
    if not ov:
        return None
    try:
        return ov if Path(data_dir).resolve() == Path(ov["data_dir"]).resolve() else None
    except OSError:
        return None


def demo_active() -> bool:
    """True while any thread of this process has the DEMO profile open."""
    with _PIN_LOCK:
        return _DEMO_COUNT[0] > 0


def demo_refusal(what: str) -> str | None:
    """Why `what` (a client output or a workbook write) is refused while the DEMO profile is open, else None."""
    if not demo_active():
        return None
    return (f"{what} refused: the DEMO licence profile is open in this process ({DEMO_BANNER}). A demo baseline never "
            "allows client output, client distribution or a workbook write (EQ-C-0123, SEC-C-019)")


class DemoProfileRefused(RuntimeError):
    """A client output or workbook write attempted while the DEMO profile is open."""


def refuse_demo(what: str) -> None:
    if (why := demo_refusal(what)):
        raise DemoProfileRefused(why)


@contextlib.contextmanager
def _demo_open(override: dict):
    """Used only by ops/demo_baseline.active: open the DEMO profile in this thread (not nestable)."""
    if getattr(_DEMO, "override", None):
        raise RuntimeError("the DEMO licence profile is already open in this thread")
    _DEMO.override = dict(override)
    with _PIN_LOCK:
        _DEMO_COUNT[0] += 1
    try:
        yield
    finally:
        _DEMO.override = None
        with _PIN_LOCK:
            _DEMO_COUNT[0] -= 1


def approved_bytes(data_dir, st: dict | None = None) -> bytes | None:
    """The approved register's bytes (hash re-checked), or None when there is no trusted approved version."""
    st = state(data_dir) if st is None else st
    if st["status"] not in APPROVED_STATES + (DEMO_STATE,) or not st["approved_path"]:
        return None
    b = _read_regular(Path(st["approved_path"]))
    return b if b is not None and sha256(b) == st["approved_sha256"] else None


def problem(data_dir=None, st: dict | None = None) -> str | None:
    """Why client output and the evidence build must refuse (None when the register is the approved version, or when
    there is no register and never was one). The text names no local path."""
    st = state(data_dir) if st is None else st
    s = st["status"]
    tail = " (R44 / SEC-C-017: one approved register, EQ-C-0106)"
    if s in ("ok", "default"):
        return None
    if s == DEMO_STATE:
        return (f"{DEMO_BANNER}: data/{REGISTER} is approved only by the DEMO profile (approver 'DEMO (not Sam)', "
                "EQ-C-0123); there is still no real approved version, so client output, client distribution and "
                "workbook writes are refused" + tail)
    if s == "no_baseline":
        return (f"data/{REGISTER} has no approved version yet: client output and the evidence build are refused and "
                f"internal use only warns, until Sam approves the first baseline on the Mac: {FIRST_BASELINE_CMD}" + tail)
    if s == "chain_broken":
        return ("the approvals log does not verify (econquest change verify), so no approved licence register can be "
                "trusted: client output and the evidence build are refused" + tail)
    appr = str(st["approved_sha256"] or "")[:12]
    if s == "drift":
        return (f"data/{REGISTER} (sha256 {str(st['current_sha256'])[:12]}...) differs from the approved register "
                f"(sha256 {appr}...): it was changed outside econquest change. Client output and the evidence build "
                "are refused; internal products use the approved register. Restore the approved version, or propose "
                f"the edit: econquest change propose {REGISTER} --replace-file <edited copy> ..." + tail)
    if s == "missing":
        return (f"data/{REGISTER} is missing but an approved version (sha256 {appr}...) exists: client output and the "
                "evidence build are refused; restore it" + tail)
    return f"data/{REGISTER} is a symlink (refused); restore the approved version (sha256 {appr}...)" + tail


def reader_problem(data_dir=None, st: dict | None = None) -> str | None:
    """EQ-C-0140: the same condition as `problem`, as one plain sentence for reader products (country notes, weekly
    brief, trade ideas page, scenario briefs, risk monitor, report): no command, no Mac step, no local path. The CLI,
    operator outputs, client-check, vendor, golive and approvals keep `problem` (with FIRST_BASELINE_CMD)."""
    st = state(data_dir) if st is None else st
    s = st["status"]
    if s in ("ok", "default"):
        return None
    if s == DEMO_STATE:
        return (f"{DEMO_BANNER}: there is no real approved version yet, so this content is internal only and cannot "
                "go to clients")
    if s == "no_baseline":
        return "no approved version yet, so this content is internal only and cannot go to clients"
    if s == "chain_broken":
        return ("the approval record could not be verified, so this content is internal only and cannot go to "
                "clients")
    if s == "drift":
        return ("the current file differs from the approved register (it was changed after its last approval); this "
                "product uses the approved version, and the content is internal only and cannot go to clients")
    return ("the approved register file is not in place; this content is internal only and cannot go to clients")


def warning(data_dir) -> str | None:
    """The internal-mode warning (same condition as `problem`)."""
    why = problem(data_dir)
    return f"WARNING licence register: {why}" if why else None


def verify_lines(data_dir) -> list[str]:
    """What `econquest change verify` prints for the register."""
    st = state(data_dir)
    s = st["status"]
    if s == "default":
        return [f"Licence register (R44): no data/{REGISTER} and none approved; client output refused, evidence on the old rules"]
    head = f"Licence register (R44): {s}; approved sha256 {st['approved_sha256'] or '-'}"
    if st["last_event"]:
        head += f" ({st['last_event']}{' ' + st['last_id'] if st['last_id'] else ''} at {st['last_ts_utc'][:19]})"
    lines = [head]
    if s == "ok":
        lines.append("  enforcement reads the approved register; client output and the evidence build may use it")
    else:
        lines.append("  " + str(problem(data_dir, st)))
    return lines


# ---------------------------------------------------------------- Team A's resolver
_PIN_LOCK = threading.RLock()
_PIN = {"depth": 0, "saved": None, "pinned": False}


def _env_name() -> str:
    from ..ingestion.licences import REGISTER_ENV
    return REGISTER_ENV


def outside_env() -> str:
    """$ECONQUEST_LICENCE_REGISTER as the operator set it ('' when unset), even inside `enforce_approved`."""
    with _PIN_LOCK:
        env = (_PIN["saved"] or "") if _PIN["pinned"] else os.environ.get(_env_name(), "")
    return str(env or "").strip()


def outside_register_path() -> Path:
    """The register Team A's resolver names outside `enforce_approved` ($ECONQUEST_LICENCE_REGISTER as the operator set
    it, else the package data/licences.csv): what SEC-C-017 compares with the approved register."""
    from ..ingestion.licences import DEFAULT_REGISTER
    env = outside_env()
    return Path(env) if env else DEFAULT_REGISTER


@contextlib.contextmanager
def enforce_approved(data_dir):
    """While inside, Team A's resolver (ingestion.licences.register_path via $ECONQUEST_LICENCE_REGISTER) names the
    approved register of data_dir, so Team A's audit / data-room hooks, client_check.licence_table and require_register
    read only it. When data_dir has no trusted approved version the variable is the operator's own value inside (client
    paths refuse through `problem`). Yields the state.

    SEC-C-018 M1: $ECONQUEST_LICENCE_REGISTER is process-global and the GUI server is threaded, so the whole body runs
    under one re-entrant lock: a concurrent caller waits and then pins its own approved version (it used to share the
    first caller's pin, so a request that started after an apply could enforce the previous register), nested calls in
    one thread pin and restore in order, and the variable is restored in `finally` on any exception. Code that reads
    the variable outside this context in another thread can still see the pin until Team A's resolver takes the path
    explicitly (HO-20261025-C-A-004)."""
    name = _env_name()
    with _PIN_LOCK:
        st = state(data_dir)
        path = (st["approved_path"] if st["status"] in APPROVED_STATES + (DEMO_STATE,)
                and approved_bytes(data_dir, st) is not None else None)
        if _PIN["depth"] == 0:
            _PIN["saved"], _PIN["pinned"] = os.environ.get(name), True
        before = os.environ.get(name)
        _set_env(name, str(path) if path is not None else _PIN["saved"])
        _PIN["depth"] += 1
        try:
            yield st
        finally:
            _PIN["depth"] -= 1
            if _PIN["depth"] == 0:
                _set_env(name, _PIN["saved"])
                _PIN["saved"], _PIN["pinned"] = None, False
            else:
                _set_env(name, before)


def _set_env(name: str, value: str | None) -> None:
    if value is None:
        os.environ.pop(name, None)
    else:
        os.environ[name] = value
