"""Server deployment option (EQ-C-0157, SEC-C-024): the scheduled jobs, backups and health check off the laptop, in a
container (deploy/server/). OFF by default: nothing here runs unless someone calls `econquest server ...`, and the
scheduler loop (`server run`) refuses to start unless ECONQUEST_SERVER_ENABLED=1. The Mac install (install.sh,
launchd plists from schedule.py) is unchanged. Whether to use it, the host and the credentials are Sam's decision.

    econquest server check [--healthcheck] [--strict] [--json]   is this install ready to run as a server? exit 1 if not.
                                                                  --healthcheck: only the scheduler heartbeat (the
                                                                  container HEALTHCHECK); --strict: also fail on a
                                                                  critical alert in outputs/health.json
    econquest server plan [--from ISO] [--days N] [--json]        what would run when (America/New_York and UTC)
    econquest server selftest [--keep] [--report PATH] [--json]   a compressed day in a temp home: every job once on a fake
                                                                  clock, the backup, the restore drill and health; the
                                                                  shared data is copied, never written
    econquest server run                                          the container's scheduler (needs ECONQUEST_SERVER_ENABLED=1)

Same jobs as launchd: the job table is schedule.load_config(home) (DEFAULT_JOBS, then <home>/ops.json) passed through
schedule.effective_job and schedule.resolve_steps, and every job runs through jobs.run_job, so outputs/logs/jobs/ and
the health check read exactly what they read on the Mac. Times are wall-clock times in the schedule's tz (default
America/New_York), as launchd fires them on a Mac in New York: weekdays use launchd numbering (0/7 Sunday ... 6
Saturday), "day" jobs run monthly, "interval_minutes" jobs run on the multiples of N minutes from local midnight. A slot
missed while the host was down runs once when the scheduler is back (launchd's behaviour on wake), not once per slot.
A job still running when its next slot comes is skipped and logged. No system cron is used.

Credentials (SEC-C-024): the macOS Keychain does not exist on a server. Every credential econquest reads already has an
environment variable (ECONQUEST_SHEETS_TOKEN, UCDP_API_TOKEN, ECONQUEST_ALERT_WEBHOOK, ECONQUEST_SMTP_PASSWORD); the
server adds a file fallback for secret mounts: when <NAME> is unset and <NAME>_FILE names a readable regular file, its
content becomes <NAME> in the environment of the job steps. Only names and sources ("env", "file", "missing") are ever
logged or reported, never a value. No scheduled job writes the workbook (the Sheets token is needed only for a manual
`--write`).
"""
from __future__ import annotations
import argparse
import datetime as dt
import importlib.util
import json
import os
import re
import shutil
import signal
import stat
import subprocess
import sys
import tempfile
import threading
import time
from pathlib import Path

from . import jobs as _jobs
from . import schedule as _schedule

ENABLE_ENV = "ECONQUEST_SERVER_ENABLED"
BACKUP_ENV = "ECONQUEST_BACKUP_DEST"
SECRET_NAMES = ("ECONQUEST_SHEETS_TOKEN", "UCDP_API_TOKEN", "ECONQUEST_ALERT_WEBHOOK", "ECONQUEST_SMTP_PASSWORD")
ALERT_ENV_PREFIXES = ("ECONQUEST_ALERT_", "ECONQUEST_SMTP_")
SECRET_FILE_MAX_BYTES = 64 * 1024
TICK_SECONDS = 30                    # the loop wakes at least this often (clock jumps, stop requests, heartbeat)
HEARTBEAT_MAX_SECONDS = 300          # healthcheck: an older heartbeat means the scheduler is stuck or gone
EXIT_DISABLED = 3
REAL_IN_SELFTEST = ("econquest.ops.backup", "econquest.ops.health")   # every other step is checked, not executed
UTC = dt.timezone.utc
_MOD_RE = re.compile(r"-m\s+([A-Za-z_][\w.]*)")


def enabled(env: dict | None = None) -> bool:
    """The switch: only ECONQUEST_SERVER_ENABLED=1 (exactly) turns the scheduler loop on."""
    return (os.environ if env is None else env).get(ENABLE_ENV, "").strip() == "1"


def _now() -> dt.datetime:
    return dt.datetime.now(UTC)


def _iso(t: dt.datetime) -> str:
    return t.astimezone(UTC).isoformat(timespec="seconds")


# ------------------------------------------------------------------ credentials (env, else <NAME>_FILE; never logged)
def load_secret_files(env: dict | None = None, names=SECRET_NAMES, log=print) -> tuple[dict, dict]:
    """Return (env, sources). For each name: an already set $NAME wins ("env"); else $NAME_FILE is read ("file");
    else "missing". A file that is not a regular file, is writable by group or others, is empty or is too large is
    "refused" with the reason. `sources` and every log line hold names and paths only, never a value."""
    out = dict(os.environ if env is None else env)
    sources: dict[str, str] = {}
    for name in names:
        if out.get(name, "").strip():
            sources[name] = "env"
            continue
        fpath = out.get(f"{name}_FILE", "").strip()
        if not fpath:
            sources[name] = "missing"
            continue
        p = Path(fpath)
        try:
            st = p.stat()
            if not stat.S_ISREG(st.st_mode):
                raise ValueError("not a regular file")
            if st.st_mode & (stat.S_IWGRP | stat.S_IWOTH):
                raise ValueError("writable by group or others")
            if st.st_size > SECRET_FILE_MAX_BYTES:
                raise ValueError("larger than 64 KB")
            val = p.read_text(encoding="utf-8").strip()
            if not val:
                raise ValueError("empty")
        except (OSError, UnicodeDecodeError, ValueError) as e:
            why = e.strerror if isinstance(e, OSError) and e.strerror else (str(e) if isinstance(e, ValueError) else type(e).__name__)
            sources[name] = f"refused: {why}"
            log(f"[server] {name}_FILE {p} not used: {why}")
            continue
        out[name] = val
        sources[name] = "file"
    return out, sources


# ------------------------------------------------------------------ job table and times
def server_paths(home: str | Path, launcher: str | Path | None = None, python: str | Path | None = None) -> dict:
    """schedule.paths for a server: the console script on PATH (or beside the interpreter) and this interpreter."""
    py = Path(python) if python else Path(sys.executable)
    if launcher is None:
        found = shutil.which("econquest")
        launcher = Path(found) if found else py.with_name("econquest")
    return _schedule.paths(home, launcher=launcher, python=py, launch_agents=Path(home) / ".no-launch-agents")


def job_table(home: str | Path, cfg: dict | None = None, **path_kw) -> tuple[dict, dict]:
    """(cfg, {job: {"job": effective job, "steps": resolved argv lists, "keep_going": bool}}), the jobs launchd installs."""
    p = server_paths(home, **path_kw)
    cfg = cfg or _schedule.load_config(p["home"])
    table = {}
    for name, job in cfg["jobs"].items():
        ej = _schedule.effective_job(name, job, cfg)
        table[name] = {"job": ej, "steps": _schedule.resolve_steps(ej, p, cfg), "keep_going": bool(ej.get("keep_going"))}
    return cfg, table


def _zone(tz: str):
    from zoneinfo import ZoneInfo
    return ZoneInfo(tz)


def _runs_on(job: dict, d: dt.date) -> bool:
    if job.get("day") is not None:
        return d.day == int(job["day"])
    days = {int(x) % 7 for x in job.get("weekdays", _schedule.ALL_DAYS)}   # launchd: 0/7 Sunday, 1 Monday ... 6 Saturday
    return (d.weekday() + 1) % 7 in days


def _times_on(job: dict, d: dt.date) -> list[tuple[int, int]]:
    if job.get("interval_minutes"):
        n = int(job["interval_minutes"])
        return [(m // 60, m % 60) for m in range(0, 1440, n)]
    return [(int(job["hour"]), int(job["minute"]))] if _runs_on(job, d) else []


def next_fire(job: dict, after: dt.datetime, tz: str = _schedule.DEFAULT_TZ) -> dt.datetime:
    """The first slot strictly after `after` (UTC), wall-clock in `tz`."""
    z = _zone(tz)
    start = after.astimezone(z).date() - dt.timedelta(days=1)
    for k in range(0, 64):
        d = start + dt.timedelta(days=k)
        for h, m in _times_on(job, d):
            t = dt.datetime.combine(d, dt.time(h, m), tzinfo=z).astimezone(UTC)
            if t > after:
                return t
    raise ValueError("job never fires (check its weekdays / day)")


def plan(home: str | Path, start: dt.datetime | None = None, days: float = 1.0, cfg: dict | None = None, **path_kw) -> list[dict]:
    """Every firing in [start, start + days), sorted: {"job", "at_utc", "at_local", "tz", "steps"}."""
    cfg, table = job_table(home, cfg, **path_kw)
    tz = cfg.get("tz", _schedule.DEFAULT_TZ)
    start = (start or _now()).astimezone(UTC)
    end = start + dt.timedelta(days=days)
    rows = []
    for name, t in table.items():
        at = next_fire(t["job"], start - dt.timedelta(microseconds=1), tz)
        while at < end:
            rows.append({"job": name, "at_utc": _iso(at), "at_local": at.astimezone(_zone(tz)).strftime("%a %Y-%m-%d %H:%M"),
                         "tz": tz, "steps": [_step_label(s) for s in t["steps"]]})
            at = next_fire(t["job"], at, tz)
    return sorted(rows, key=lambda r: (r["at_utc"], r["job"]))


def _step_module(argv: list[str]) -> str | None:
    if "-m" in argv[:-1]:
        return argv[argv.index("-m") + 1]
    m = _MOD_RE.search(argv[2]) if len(argv) > 2 and argv[1] == "-c" else None
    return m.group(1) if m else None


def _step_label(argv: list[str]) -> str:
    mod = _step_module(argv)
    return f"python -m {mod}" if mod else f"{Path(argv[0]).name} {' '.join(argv[1:2])}".strip()


# ------------------------------------------------------------------ the scheduler loop
def schedule_record(cfg: dict, now: dt.datetime, prev: dict | None = None) -> dict:
    """outputs/logs/schedule.json as install() writes it (the health check's missed-run input), runner "server"."""
    prev = prev or {}
    names = list(cfg["jobs"])
    return {**prev, "installed_at": prev.get("installed_at") if prev.get("status") == "installed" and prev.get("runner") == "server"
            else _iso(now), "updated_at": _iso(now), "status": "installed", "runner": "server", "tz": cfg.get("tz", _schedule.DEFAULT_TZ),
            "grace_minutes": cfg.get("grace_minutes", 15), "stale_feed_days": cfg.get("stale_feed_days", 7),
            "holidays": cfg.get("holidays", []), "plists": [],
            "jobs": {n: {k: v for k, v in _schedule.effective_job(n, cfg["jobs"][n], cfg).items() if k != "steps"} for n in names},
            _schedule.RECORD_APPLY_KEY: _schedule.record_apply_prices(cfg), "record_mode": _schedule.record_mode(cfg)}


def _atomic_json(path: Path, obj: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(f".{path.name}.tmp")
    tmp.write_text(json.dumps(obj, indent=1, default=str)); tmp.replace(path)


def heartbeat_path(home: str | Path) -> Path:
    return Path(home) / "outputs" / "logs" / "server" / "heartbeat.json"


class Scheduler:
    """A stdlib loop over the job table. clock/sleep/runner are injectable so tests and selftest run a fake day."""

    def __init__(self, home, cfg=None, clock=_now, sleep=None, runner=subprocess.run, env: dict | None = None, log=print,
                 threaded: bool = True, run_job=None, tick: float | None = TICK_SECONDS, **path_kw):
        self.home = Path(home)
        self.tick = tick                                        # None: sleep the whole gap (a fake clock)
        self.cfg, self.table = job_table(self.home, cfg, **path_kw)
        self.tz = self.cfg.get("tz", _schedule.DEFAULT_TZ)
        self.clock, self.runner, self.env, self.log, self.threaded = clock, runner, env, log, threaded
        self.stop = threading.Event()
        self.sleep = sleep or (lambda s: self.stop.wait(s))
        self.run_job = run_job or _jobs.run_job
        self.running: dict[str, threading.Thread] = {}
        self.fired: list[dict] = []
        self._lock = threading.Lock()

    def write_schedule(self) -> Path:
        p = self.home / "outputs" / "logs" / "schedule.json"
        prev = {}
        if p.exists():
            try:
                prev = json.loads(p.read_text())
            except (OSError, ValueError):
                prev = {}
        _atomic_json(p, schedule_record(self.cfg, self.clock(), prev))
        return p

    def heartbeat(self, now: dt.datetime, nxt: dict) -> None:
        with self._lock:
            running = sorted(n for n, t in self.running.items() if t.is_alive())
        _atomic_json(heartbeat_path(self.home), {"at": _iso(now), "pid": os.getpid(), "enabled": True, "tz": self.tz,
                                                 "running": running, "next": {n: _iso(t) for n, t in sorted(nxt.items())}})

    def _exec(self, name: str, slot: dt.datetime) -> None:
        t = self.table[name]
        rec = {"job": name, "slot": _iso(slot), "started": _iso(self.clock())}
        try:
            rec["exit_code"] = self.run_job(name, t["steps"], self.home, runner=self.runner, clock=self.clock, env=self.env,
                                            log=self.log, tz=self.tz, keep_going=t["keep_going"])
        except Exception as e:                                  # noqa: BLE001 - one job's crash never stops the loop
            rec["exit_code"] = 1; rec["error"] = type(e).__name__
            self.log(f"[server] {name} wrapper error: {type(e).__name__}")
        with self._lock:
            self.fired.append(rec)

    def start(self, name: str, slot: dt.datetime) -> None:
        with self._lock:
            busy = name in self.running and self.running[name].is_alive()
        if busy:
            self.log(f"[server] {name} slot {_iso(slot)} skipped: previous run still going")
            with self._lock:
                self.fired.append({"job": name, "slot": _iso(slot), "skipped": "still running"})
            return
        self.log(f"[server] {name} due {_iso(slot)}")
        if not self.threaded:
            self._exec(name, slot)
            return
        th = threading.Thread(target=self._exec, args=(name, slot), name=f"job-{name}", daemon=True)
        with self._lock:
            self.running[name] = th
        th.start()

    def run(self, until: dt.datetime | None = None, once_each: bool = False, max_fires: int | None = None) -> list[dict]:
        now = self.clock()
        nxt = {n: next_fire(t["job"], now, self.tz) for n, t in self.table.items()}
        last_beat = None
        fires = 0
        while nxt and not self.stop.is_set():
            name = min(nxt, key=lambda n: (nxt[n], n))
            due = nxt[name]
            if until is not None and due > until:
                break
            now = self.clock()
            if last_beat is None or (now - last_beat).total_seconds() >= (self.tick or 0):
                self.heartbeat(now, nxt); last_beat = now
            if due > now:
                gap = max(0.0, (due - now).total_seconds())
                self.sleep(gap if self.tick is None else min(self.tick, gap))
                continue
            self.start(name, due)
            fires += 1
            if once_each:
                nxt.pop(name)
            else:
                nxt[name] = next_fire(self.table[name]["job"], max(due, self.clock()), self.tz)   # missed slots: once
            if max_fires is not None and fires >= max_fires:
                break
        self.join()
        return self.fired

    def join(self, timeout: float | None = None) -> None:
        for th in list(self.running.values()):
            th.join(timeout)


def job_env(home: str | Path, base: dict | None = None, log=print) -> tuple[dict, dict]:
    env, sources = load_secret_files(base, log=log)
    env["ECONQUEST_HOME"] = str(Path(home))
    bindir = str(Path(sys.executable).parent)
    if bindir not in env.get("PATH", "").split(os.pathsep):
        env["PATH"] = bindir + os.pathsep + env.get("PATH", "/usr/bin:/bin")
    return env, sources


def serve(home: str | Path, env: dict | None = None, log=print) -> int:
    """`econquest server run`: the long-running scheduler. Refuses (exit 3) unless the switch is on."""
    base = dict(os.environ if env is None else env)
    if not enabled(base):
        log(f"[server] off: set {ENABLE_ENV}=1 to run the scheduler (the server option ships switched off; Sam decides). "
            "Nothing was run.")
        return EXIT_DISABLED
    home = Path(home)
    if not (home / "data").is_dir():
        log(f"[server] {home / 'data'} not found: mount the data volume there"); return 2
    jenv, sources = job_env(home, base, log)
    log("[server] credentials: " + ", ".join(f"{k} {v}" for k, v in sources.items()))
    if not jenv.get(BACKUP_ENV):
        log(f"[server] WARNING {BACKUP_ENV} unset: backups go to ~/econquest-backups/nightly inside the container")
    sch = Scheduler(home, env=jenv, log=log)
    for sig in (signal.SIGTERM, signal.SIGINT):
        signal.signal(sig, lambda *_: (log("[server] stop requested"), sch.stop.set()))
    log(f"[server] scheduler started: {len(sch.table)} jobs, tz {sch.tz}; schedule record {sch.write_schedule()}")
    sch.run()
    sch.join(timeout=20)
    _atomic_json(heartbeat_path(home), {"at": _iso(_now()), "pid": os.getpid(), "enabled": True, "stopped": True})
    log("[server] scheduler stopped")
    return 0


# ------------------------------------------------------------------ check / healthcheck
def _resolvable(argv0: str, env: dict) -> bool:
    p = Path(argv0)
    if p.is_absolute():
        return p.is_file() and os.access(p, os.X_OK)
    return shutil.which(argv0, path=env.get("PATH")) is not None


def _step_problems(table: dict, env: dict) -> list[str]:
    out = []
    for name, t in table.items():
        for argv in t["steps"]:
            if not _resolvable(argv[0], env):
                out.append(f"{name}: {argv[0]} not found or not executable")
            mod = _step_module(argv)
            if mod:
                try:
                    found = importlib.util.find_spec(mod) is not None
                except (ImportError, ValueError):
                    found = False
                if not found:
                    out.append(f"{name}: module {mod} not importable")
    return out


def healthcheck(home: str | Path, now: dt.datetime | None = None, strict: bool = False, env: dict | None = None) -> tuple[int, str]:
    """The container HEALTHCHECK: 0 when the switch is on and the heartbeat is fresh (and with strict, no critical alert)."""
    if not enabled(env):
        return 1, f"server off ({ENABLE_ENV} is not 1)"
    now = now or _now()
    hb = heartbeat_path(home)
    try:
        rec = json.loads(hb.read_text())
        age = (now - dt.datetime.fromisoformat(rec["at"])).total_seconds()
    except (OSError, ValueError, KeyError, TypeError):
        return 1, f"no scheduler heartbeat at {hb}"
    if rec.get("stopped"):
        return 1, "scheduler stopped"
    if age > HEARTBEAT_MAX_SECONDS:
        return 1, f"scheduler heartbeat {age:.0f}s old (max {HEARTBEAT_MAX_SECONDS}s)"
    if strict:
        try:
            st = json.loads((Path(home) / "outputs" / "health.json").read_text()).get("status")
        except (OSError, ValueError):
            st = None
        if st == "critical":
            return 1, "health.json has a critical alert"
    return 0, f"scheduler alive (heartbeat {age:.0f}s old)"


def check(home: str | Path, env: dict | None = None, now: dt.datetime | None = None, log=print, **path_kw) -> dict:
    """Read-only readiness check. {"ok", "problems", "warnings", "enabled", "credentials", "jobs"}; never prints a value."""
    home = Path(home)
    base = dict(os.environ if env is None else env)
    problems, warnings = [], []
    on = enabled(base)
    if not (home / "data").is_dir():
        problems.append(f"{home / 'data'} not found (mount the data volume)")
    else:
        for f in ("countries.csv", "indicators.csv"):
            if not (home / "data" / f).is_file():
                problems.append(f"data/{f} missing")
    out = home / "outputs"
    if out.is_dir() and not os.access(out, os.W_OK):
        problems.append(f"{out} not writable by uid {os.getuid()}")
    dest = base.get(BACKUP_ENV, "").strip()
    if not dest:
        warnings.append(f"{BACKUP_ENV} unset: backups would stay inside the container (mount a backup volume)")
    else:
        d = Path(dest).resolve()
        if any(d == (home / s).resolve() or (home / s).resolve() in d.parents for s in ("data", "outputs")):
            problems.append(f"{BACKUP_ENV} {dest} is inside data/ or outputs/")
        elif d.is_dir() and not os.access(d, os.W_OK):
            problems.append(f"{BACKUP_ENV} {dest} not writable")
    cfg, table = {}, {}
    try:
        cfg, table = job_table(home, **path_kw)
        _zone(cfg.get("tz", _schedule.DEFAULT_TZ))
    except Exception as e:                                       # noqa: BLE001 - reported, never raised
        problems.append(f"job table not buildable: {type(e).__name__}: {e}")
    jenv, sources = job_env(home, base, log=lambda *_: None)
    problems += _step_problems(table, jenv)
    for k, v in sources.items():
        if v.startswith("refused"):
            problems.append(f"{k}_FILE {v}")
    if sources.get("UCDP_API_TOKEN") == "missing":
        warnings.append("UCDP_API_TOKEN missing: the data_ops incremental UCDP pull will fail (health: events_incremental_error)")
    if hasattr(os, "getuid") and os.getuid() == 0:
        warnings.append("running as root: the image runs as the econquest user; do not override --user 0")
    hc = healthcheck(home, now=now, env=base) if on else (None, "server off")
    if on and hc[0]:
        problems.append(hc[1])
    rep = {"ok": not problems, "enabled": on, "problems": problems, "warnings": warnings, "credentials": sources,
           "tz": cfg.get("tz"), "jobs": sorted(table), "heartbeat": hc[1]}
    log(f"server option: {'ON' if on else 'off'} ({ENABLE_ENV}); home {home}; {len(table)} jobs in {cfg.get('tz')}")
    log("credentials: " + ", ".join(f"{k} {v}" for k, v in sources.items()))
    for p in problems:
        log(f"  PROBLEM {p}")
    for w in warnings:
        log(f"  warning {w}")
    log(f"server check: {'OK' if rep['ok'] else 'FAIL'} ({len(problems)} problems, {len(warnings)} warnings)")
    return rep


# ------------------------------------------------------------------ selftest
class FakeClock:
    def __init__(self, start: dt.datetime):
        self.t = start.astimezone(UTC)

    def now(self) -> dt.datetime:
        return self.t

    def sleep(self, seconds: float) -> None:
        self.t += dt.timedelta(seconds=max(seconds, 1.0))


class SelftestRunner:
    """Runs the backup and health steps for real; every other step is checked (executable, module importable) and
    recorded without running, so selftest makes no network call and never runs the model."""

    def __init__(self, real=REAL_IN_SELFTEST, timeout: int = 900):
        self.real, self.timeout, self.calls = tuple(real), timeout, []

    def __call__(self, argv, cwd=None, env=None, **kw):
        mod = _step_module(argv)
        env = env or {}
        if mod in self.real:
            r = subprocess.run(argv, cwd=cwd, env=env, capture_output=True, text=True, timeout=self.timeout)
            self.calls.append({"step": _step_label(argv), "mode": "real", "exit_code": r.returncode,
                               "tail": (r.stdout or "").strip().splitlines()[-2:] + (r.stderr or "").strip().splitlines()[-3:]})
            return subprocess.CompletedProcess(argv, r.returncode)
        why = []
        if not _resolvable(argv[0], env):
            why.append(f"{argv[0]} not found")
        if mod:
            try:
                if importlib.util.find_spec(mod) is None:
                    why.append(f"module {mod} not importable")
            except (ImportError, ValueError):
                why.append(f"module {mod} not importable")
        self.calls.append({"step": _step_label(argv), "mode": "checked", "exit_code": 127 if why else 0, "problems": why})
        return subprocess.CompletedProcess(argv, 127 if why else 0)


def _tree(root: Path) -> dict:
    out = {}
    for dp, dn, fn in os.walk(root):
        dn[:] = [d for d in dn if d != "__pycache__"]
        for f in fn:
            p = Path(dp) / f
            try:
                st = p.lstat()
            except OSError:
                continue
            out[str(p.relative_to(root))] = (st.st_size, st.st_mtime_ns)
    return out


def _clean_env(base: dict | None = None) -> dict:
    env = dict(os.environ if base is None else base)
    for k in list(env):
        if k in SECRET_NAMES or k.endswith("_FILE") or k.startswith(ALERT_ENV_PREFIXES) or k == ENABLE_ENV:
            env.pop(k)
    return env


def selftest(source_data: str | Path, keep: bool = False, start: dt.datetime | None = None, work_dir: str | Path | None = None,
             log=print) -> dict:
    """A compressed day: copy source_data into a temp home, run every job once at its next slot on a fake clock (backup
    and health for real, the rest checked), then verify the backup, run the restore drill and the health check.
    Never writes to source_data (checked: file sizes and mtimes before and after). {"ok", "problems", "summary", ...}."""
    from . import backup as _backup, health as _health
    source = Path(source_data).expanduser().resolve()
    problems: list[str] = []
    rep: dict = {"source": str(source)}
    if not (source / "countries.csv").is_file():
        return {"ok": False, "problems": [f"{source} is not a data folder (no countries.csv)"], "summary": "selftest not run"}
    before = _tree(source)
    tmp = Path(tempfile.mkdtemp(prefix="econquest-server-selftest-", dir=str(work_dir) if work_dir else None))
    home, dest = tmp / "home", tmp / "backups"
    t0 = time.monotonic()
    try:
        shutil.copytree(source, home / "data", ignore=shutil.ignore_patterns("__pycache__", ".DS_Store"))
        for d in (home / "outputs", dest):
            d.mkdir(parents=True, exist_ok=True)
        env = _clean_env()
        env.update({"ECONQUEST_HOME": str(home), BACKUP_ENV: str(dest)})
        pkg_root = str(Path(__file__).resolve().parents[2])
        env["PYTHONPATH"] = pkg_root + (os.pathsep + env["PYTHONPATH"] if env.get("PYTHONPATH") else "")
        path_kw = {}
        if not shutil.which("econquest") and not Path(sys.executable).with_name("econquest").exists():
            shim = tmp / "bin" / "econquest"; shim.parent.mkdir()
            shim.write_text(f"#!/bin/sh\nexec {sys.executable} -m econquest \"$@\"\n"); shim.chmod(0o755)
            path_kw["launcher"] = shim
            rep["launcher"] = "temp shim (no econquest console script installed: plain-process run)"
        fc = FakeClock(start or (_now() + dt.timedelta(minutes=1)).replace(second=0, microsecond=0))
        runner = SelftestRunner()
        sch = Scheduler(home, clock=fc.now, sleep=fc.sleep, runner=runner, env=env, log=lambda *_: None, threaded=False,
                        tick=None, **path_kw)
        rep["clock"] = {"start": _iso(fc.now())}
        expected = {n: next_fire(t["job"], fc.now(), sch.tz) for n, t in sch.table.items()}
        sch.write_schedule()
        fired = sch.run(once_each=True)
        rep["clock"]["end"] = _iso(fc.now())
        rows = []
        for f in fired:
            exp = expected.get(f["job"])
            last = _jobs.last_runs(home).get(f["job"], {})
            row = {"job": f["job"], "slot": f["slot"], "expected": _iso(exp) if exp else None, "exit_code": f.get("exit_code"),
                   "status": last.get("status")}
            rows.append(row)
            if row["slot"] != row["expected"]:
                problems.append(f"{f['job']} fired at {row['slot']}, expected {row['expected']}")
            if row["exit_code"] != 0:
                problems.append(f"{f['job']} exit {row['exit_code']}")
        missing = sorted(set(sch.table) - {f["job"] for f in fired})
        problems += [f"{n} never fired" for n in missing]
        rep["jobs"] = rows
        rep["steps"] = runner.calls
        for c in runner.calls:
            problems += [f"{c['step']}: {p}" for p in c.get("problems", [])]
        found = _backup.list_backups(dest)
        if not found:
            problems.append("backup job wrote no backup to the backup folder")
            rep["backup"] = None
        else:
            v = _backup.verify(found[-1], log=lambda *_: None)
            rep["backup"] = {"archive": Path(found[-1]).name, "files": v.get("files"), "ok": v["ok"]}
            if not v["ok"]:
                problems.append(f"backup verify failed: {v.get('errors', [])[:3]}")
            drill = _backup.restore_drill(home, dest=dest, log=lambda *_: None)
            rep["drill"] = {k: drill.get(k) for k in ("ok", "files", "duration_seconds", "within_rto", "within_rpo")}
            rep["drill"]["smoke_errors"] = (drill.get("smoke") or {}).get("errors", [])[:3]
            if not drill["ok"]:
                problems.append(f"restore drill failed: {rep['drill']['smoke_errors'] or drill.get('restore_errors', [])[:3]}")
        h = _health.run_health(home / "data", home / "outputs", deliver=False, log=lambda *_: None)
        rep["health"] = {"status": h["status"], "alerts": len(h["alerts"]), "kinds": sorted({a["kind"] for a in h["alerts"]})}
        if not (home / "outputs" / "health.json").is_file():
            problems.append("health.json not written")
        hc = healthcheck(home, now=fc.now(), env={ENABLE_ENV: "1"})
        rep["healthcheck"] = {"exit_code": hc[0], "message": hc[1]}
        if hc[0]:
            problems.append(f"healthcheck: {hc[1]}")
    except Exception as e:                                       # noqa: BLE001 - selftest reports, never crashes
        problems.append(f"selftest error: {type(e).__name__}: {e}")
    finally:
        rep["seconds"] = round(time.monotonic() - t0, 1)
        if keep:
            rep["kept_at"] = str(tmp)
        else:
            from .backup import _rmtree
            _rmtree(tmp)
    after = _tree(source)
    if after != before:
        changed = sorted(k for k in set(before) | set(after) if before.get(k) != after.get(k))
        problems.append(f"shared data changed: {changed[:5]}")
    rep["source_unchanged"] = after == before
    n_real = sum(1 for c in rep.get("steps", []) if c["mode"] == "real")
    rep.update(ok=not problems, problems=problems,
               summary=(f"server selftest {'PASS' if not problems else 'FAIL'}: {len(rep.get('jobs', []))} jobs fired once on a fake "
                        f"clock ({n_real} real steps: backup, health; {len(rep.get('steps', [])) - n_real} checked), backup "
                        f"{'verified' if (rep.get('backup') or {}).get('ok') else 'NOT verified'}, restore drill "
                        f"{'ok' if (rep.get('drill') or {}).get('ok') else 'FAILED'}, health {(rep.get('health') or {}).get('status')}, "
                        f"shared data {'unchanged' if rep['source_unchanged'] else 'CHANGED'}; {rep['seconds']}s"))
    log(rep["summary"])
    for p in problems:
        log(f"  PROBLEM {p}")
    return rep


def demo_server(out_dir: str | Path, data_dir: str | Path | None = None) -> dict:
    """For a possible demo row (EQ-C-0157): run selftest without docker on a copy of the data and write
    <out_dir>/server_selftest.json. Returns {"ok", "problems", "summary"}."""
    if data_dir is None:
        from ..cli import DEFAULT_DATA
        data_dir = DEFAULT_DATA
    rep = selftest(data_dir, log=lambda *_: None)
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    _atomic_json(out / "server_selftest.json", rep)
    return {"ok": bool(rep["ok"]), "problems": list(rep["problems"]), "summary": rep["summary"]}


# ------------------------------------------------------------------ CLI
def add_arguments(ap: argparse.ArgumentParser) -> None:
    sp = ap.add_subparsers(dest="server_cmd", required=True)
    c = sp.add_parser("check", help="read-only readiness check: data volume, backup volume, job steps resolvable, credentials "
                                    "(names and sources only), heartbeat when on; exit 1 on a problem")
    c.add_argument("--healthcheck", action="store_true", help="only the scheduler heartbeat (the container HEALTHCHECK)")
    c.add_argument("--strict", action="store_true", help="with --healthcheck: also fail on a critical alert in outputs/health.json")
    c.add_argument("--json", action="store_true")
    p = sp.add_parser("plan", help="what would run when: every job slot in the next --days, America/New_York and UTC")
    p.add_argument("--from", dest="start", help="start time, ISO 8601 (default now)")
    p.add_argument("--days", type=float, default=1.0, help="how far ahead (default 1)")
    p.add_argument("--json", action="store_true")
    s = sp.add_parser("selftest", help="compressed day in a temp home: every job once on a fake clock, backup, restore drill, "
                                       "health; the shared data is copied and never written")
    s.add_argument("--keep", action="store_true", help="keep the temp home (path printed)")
    s.add_argument("--report", help="also write the JSON report here")
    s.add_argument("--json", action="store_true")
    sp.add_parser("run", help=f"the scheduler loop (container entrypoint); refuses unless {ENABLE_ENV}=1")


def _parse_start(s: str | None) -> dt.datetime | None:
    if not s:
        return None
    t = dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
    return t if t.tzinfo else t.replace(tzinfo=UTC)


def run_from_args(args, home: Path, data_dir: Path) -> int:
    cmd = args.server_cmd
    if cmd == "run":
        return serve(home)
    if cmd == "check":
        if args.healthcheck:
            code, msg = healthcheck(home, strict=args.strict)
            print(json.dumps({"exit_code": code, "message": msg}) if args.json else f"server healthcheck: {msg}")
            return code
        rep = check(home, log=(lambda *_: None) if args.json else print)
        if args.json:
            print(json.dumps(rep, indent=1))
        return 0 if rep["ok"] else 1
    if cmd == "plan":
        rows = plan(home, _parse_start(args.start), args.days)
        if args.json:
            print(json.dumps(rows, indent=1))
        else:
            for r in rows:
                print(f"{r['at_local']} {r['tz']:16s} {r['at_utc']}  {r['job']:18s} {' ; '.join(r['steps'])}")
            print(f"{len(rows)} job runs in {args.days:g} day(s); jobs and times from DEFAULT_JOBS + {home / 'ops.json'} "
                  f"(the same table launchd installs); server option {'ON' if enabled() else 'off'}")
        return 0
    rep = selftest(data_dir, keep=args.keep, log=(lambda *_: None) if args.json else print)
    if args.report:
        _atomic_json(Path(args.report), rep)
    if args.json:
        print(json.dumps(rep, indent=1, default=str))
    return 0 if rep["ok"] else 1


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ops.server", description="server deployment option (off by default)")
    ap.add_argument("--home", default=os.environ.get("ECONQUEST_HOME", str(Path.home() / "econquest")))
    ap.add_argument("--data", help="data folder for selftest (default <home>/data)")
    add_arguments(ap)
    a = ap.parse_args(argv)
    home = Path(a.home)
    return run_from_args(a, home, Path(a.data) if a.data else home / "data")


if __name__ == "__main__":
    sys.exit(main())
