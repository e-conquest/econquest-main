"""Content-addressed disk cache for deterministic model fits (EQ-C-0085, PERF-C-001).

The daily chain (run --stress, record, publish plan) refits the same GARCH(1,1), DCC and t-copula models on the
same price history in separate processes. Those fits are pure functions of their inputs, so a fit can be stored
once and read back by every later process that sees the same inputs.

    from econquest.ops import fitcache
    fit = fitcache.memo("garch11", {"r": r}, {"dist": dist}, lambda: _garch11_fit(r, dist), code=(garch_module,))

Rules that keep it safe:
- Off unless a cache folder is configured (`configure(path)` or $ECONQUEST_FIT_CACHE_DIR), and $ECONQUEST_FIT_CACHE=0
  turns it off even then. Library calls and tests that configure nothing never touch the disk.
- The key is SHA-256 over the namespace, the input arrays (dtype, shape, bytes), the parameters (canonical JSON),
  the source bytes of the modules in `code`, and the Python, numpy, scipy and pandas versions. Any change to the
  data, a setting, the fitting code or the numeric stack gives a new key: an old entry is never reused for it.
- Values are stored without pickle: arrays in an .npz read with allow_pickle=False, everything else as tagged JSON.
  Only dataclasses defined in econquest.* modules are rebuilt. A value of any other type is not cached (the fit is
  returned as computed), and an unreadable or tampered entry is recomputed and rewritten.
- Floats are written with repr and arrays as raw bytes, so a value read back is bit-identical to the one computed,
  including NaN, inf and -0.0, and numpy scalar types are kept (np.float64 stays np.float64).
"""
from __future__ import annotations

import dataclasses
import hashlib
import importlib
import inspect
import io
import json
import os
import platform
import sys
import tempfile
from pathlib import Path
from typing import Any, Callable

import numpy as np
import pandas as pd

SCHEMA = "eq-fitcache/1"
ENV_DIR = "ECONQUEST_FIT_CACHE_DIR"
ENV_SWITCH = "ECONQUEST_FIT_CACHE"
_STATE: dict[str, Any] = {"dir": None}
STATS = {"hit": 0, "miss": 0, "skip": 0, "error": 0}


class Unsupported(TypeError):
    """The value has a type the cache does not store; the fit is returned uncached."""


# -------------------------------------------------------------------------------------------------- configuration
PRUNE_DAYS = 14         # entries not read or written for this long are deleted when the CLI configures the cache


def configure(path: str | Path | None, prune_days: float | None = None) -> None:
    """Set the cache folder (None turns the cache off). The CLI passes <out>/cache/fits and prune_days=PRUNE_DAYS.
    The folder is outside the nightly backup (backup.SOURCES) and can be deleted at any time."""
    _STATE["dir"] = Path(path) if path else None
    if prune_days is not None and enabled():
        prune(prune_days)


def prune(max_age_days: float) -> int:
    """Delete entries whose last use (mtime; a hit touches the file) is older than max_age_days."""
    import time
    d = cache_dir()
    cutoff, n = time.time() - max_age_days * 86400, 0
    try:                                                       # HO-B-C-016: an unreadable folder never fails the CLI
        if d is None or not d.exists():
            return 0
        entries = _entries(d, ("*.npz", "*.tmp"))
    except OSError:
        return 0
    for p in entries:
        try:
            if p.stat().st_mtime < cutoff:
                p.unlink(); n += 1
        except OSError:
            pass
    return n


def cache_dir() -> Path | None:
    if os.environ.get(ENV_SWITCH, "1").strip().lower() in ("0", "off", "false", "no"):
        return None
    if _STATE["dir"] is not None:
        return _STATE["dir"]
    env = os.environ.get(ENV_DIR, "").strip()
    return Path(env) if env else None


def enabled() -> bool:
    return cache_dir() is not None


def clear() -> int:
    """Delete every cached entry; returns the number of files removed."""
    d = cache_dir()
    if d is None or not d.exists():
        return 0
    n = 0
    for p in _entries(d, ("*.npz",)):
        p.unlink(missing_ok=True); n += 1
    return n


def _entries(d: Path, patterns) -> list[Path]:
    """Entry files one level down, never through a symlinked folder or a symlink (SEC-C-014 L6: prune and clear must
    not delete files outside the cache)."""
    if d.is_symlink():
        return []
    out = []
    for sub in d.iterdir():
        if sub.is_dir() and not sub.is_symlink():
            out += [p for pat in patterns for p in sub.glob(pat) if not p.is_symlink()]
    return out


def reset_stats() -> None:
    for k in STATS:
        STATS[k] = 0


# -------------------------------------------------------------------------------------------------- keys
def _runtime() -> str:
    import scipy
    return f"py{platform.python_version()}|np{np.__version__}|sp{scipy.__version__}|pd{pd.__version__}|{sys.byteorder}"


_CODE_FP: dict[str, str] = {}


def _code_fingerprint(code) -> str:
    h = hashlib.sha256()
    for m in code or ():
        name = m if isinstance(m, str) else m.__name__
        if name not in _CODE_FP:
            mod = importlib.import_module(name)
            src = inspect.getsourcefile(mod)
            _CODE_FP[name] = hashlib.sha256(Path(src).read_bytes()).hexdigest() if src else name
        h.update(name.encode() + b"=" + _CODE_FP[name].encode() + b";")
    return h.hexdigest()


def _hash_input(h, name: str, x) -> None:
    h.update(b"<" + name.encode() + b">")
    if isinstance(x, pd.DataFrame):
        h.update(b"df"); _hash_input(h, "columns", np.asarray(x.columns, dtype=str)); _hash_input(h, "index", x.index)
        _hash_input(h, "values", x.to_numpy())
        return
    if isinstance(x, pd.Series):
        h.update(b"s"); _hash_input(h, "index", x.index); _hash_input(h, "values", x.to_numpy())
        return
    if isinstance(x, pd.Index):
        x = np.asarray(x.astype(str) if x.dtype == object else x)
    a = np.asarray(x)
    if a.dtype == object:
        a = np.asarray(a.astype(str))
    a = np.ascontiguousarray(a)
    h.update(f"{a.dtype.str}{a.shape}".encode())
    h.update(a.tobytes())


def make_key(namespace: str, inputs: dict, params: dict | None, code=()) -> str:
    h = hashlib.sha256()
    h.update(f"{SCHEMA}|{namespace}|{_runtime()}|{_code_fingerprint(code)}|".encode())
    for k in sorted(inputs):
        _hash_input(h, k, inputs[k])
    h.update(json.dumps(params or {}, sort_keys=True, default=repr, allow_nan=True).encode())
    return h.hexdigest()


# -------------------------------------------------------------------------------------------------- encoding
class _Enc:
    def __init__(self):
        self.arrays: dict[str, np.ndarray] = {}

    def arr(self, a: np.ndarray):
        if a.dtype == object or a.dtype.kind in "OUSV":
            if a.ndim != 1:
                raise Unsupported(f"{a.ndim}-d {a.dtype} array")
            return {"__objarr": [self.enc(v) for v in a.tolist()], "dtype": a.dtype.str if a.dtype.kind in "US" else "O"}
        k = f"a{len(self.arrays)}"
        self.arrays[k] = np.ascontiguousarray(a)
        return {"__arr": k}

    def enc(self, x):
        if x is None or isinstance(x, (bool, str)) or type(x) is int:
            return x
        if type(x) is float:
            return {"__f": repr(x)}
        if isinstance(x, np.generic):
            if x.dtype.kind in "biufc":
                return {"__np": x.dtype.str, "v": self.arr(np.asarray([x]))}
            raise Unsupported(f"numpy scalar {x.dtype}")
        if isinstance(x, np.ndarray):
            return self.arr(x)
        if isinstance(x, pd.Series):
            return {"__series": self.arr(x.to_numpy()), "dtype": str(x.dtype), "index": self.enc(x.index), "name": self.enc(x.name)}
        if isinstance(x, pd.RangeIndex):
            return {"__range": [x.start, x.stop, x.step], "name": self.enc(x.name)}
        if isinstance(x, pd.DatetimeIndex):
            if x.tz is not None:
                raise Unsupported("tz-aware DatetimeIndex")
            return {"__dtindex": self.arr(x.asi8), "unit": x.unit, "freq": x.freqstr, "name": self.enc(x.name)}
        if isinstance(x, pd.Index):
            if type(x) is not pd.Index:
                raise Unsupported(type(x).__name__)
            return {"__index": self.arr(np.asarray(x.to_numpy())), "dtype": str(x.dtype), "name": self.enc(x.name)}
        if isinstance(x, pd.Timestamp):
            return {"__ts": x.isoformat()}
        if isinstance(x, dict):
            return {"__dict": [[self.enc(k), self.enc(v)] for k, v in x.items()]}
        if isinstance(x, list):
            return {"__list": [self.enc(v) for v in x]}
        if isinstance(x, tuple):
            return {"__tuple": [self.enc(v) for v in x]}
        if dataclasses.is_dataclass(x) and not isinstance(x, type):
            cls = type(x)
            if not cls.__module__.startswith("econquest."):
                raise Unsupported(f"dataclass {cls.__module__}.{cls.__qualname__}")
            return {"__dc": f"{cls.__module__}:{cls.__qualname__}",
                    "fields": {f.name: self.enc(getattr(x, f.name)) for f in dataclasses.fields(x)}}
        raise Unsupported(type(x).__name__)


def _dec(x, arrays):
    if not isinstance(x, (dict, list)):
        return x
    if isinstance(x, list):
        raise ValueError("untagged list in cache entry")
    if "__f" in x:
        return float(x["__f"])
    if "__arr" in x:
        return arrays[x["__arr"]]
    if "__objarr" in x:
        vals = [_dec(v, arrays) for v in x["__objarr"]]
        out = np.empty(len(vals), dtype=object) if x["dtype"] == "O" else np.array(vals, dtype=x["dtype"])
        if x["dtype"] == "O":
            out[:] = vals
        return out
    if "__np" in x:
        return _dec(x["v"], arrays).astype(x["__np"])[0]
    if "__series" in x:
        vals = _dec(x["__series"], arrays)
        return pd.Series(vals, index=_dec(x["index"], arrays), name=_dec(x["name"], arrays), dtype=x["dtype"], copy=False)
    if "__range" in x:
        return pd.RangeIndex(*x["__range"], name=_dec(x["name"], arrays))
    if "__dtindex" in x:
        idx = pd.DatetimeIndex(_dec(x["__dtindex"], arrays).astype(f"datetime64[{x['unit']}]"), name=_dec(x["name"], arrays))
        return pd.DatetimeIndex(idx, freq=x["freq"]) if x["freq"] else idx
    if "__index" in x:
        return pd.Index(_dec(x["__index"], arrays), dtype=x["dtype"], name=_dec(x["name"], arrays))
    if "__ts" in x:
        return pd.Timestamp(x["__ts"])
    if "__dict" in x:
        return {_hashable(_dec(k, arrays)): _dec(v, arrays) for k, v in x["__dict"]}
    if "__list" in x:
        return [_dec(v, arrays) for v in x["__list"]]
    if "__tuple" in x:
        return tuple(_dec(v, arrays) for v in x["__tuple"])
    if "__dc" in x:
        modname, qual = x["__dc"].split(":")
        # SEC-C-014 L4: never import from a cache file (econquest.__main__ runs the CLI on import): the module must be
        # an econquest.* module this process has already loaded, and no dunder or private part may be named
        if (not modname.startswith("econquest.") or modname not in sys.modules
                or any(s.startswith("_") for s in modname.split(".") + qual.split("."))):
            raise ValueError(f"refusing to rebuild {modname}.{qual}")
        cls = sys.modules[modname]
        for part in qual.split("."):
            cls = getattr(cls, part)
        if not (isinstance(cls, type) and dataclasses.is_dataclass(cls)):
            raise ValueError(f"{x['__dc']} is not a dataclass")
        vals = {k: _dec(v, arrays) for k, v in x["fields"].items()}
        init = {f.name for f in dataclasses.fields(cls) if f.init}
        obj = cls(**{k: v for k, v in vals.items() if k in init})
        for k, v in vals.items():
            if k not in init:
                object.__setattr__(obj, k, v)
        return obj
    raise ValueError(f"unknown tag in cache entry: {sorted(x)[:3]}")


def _hashable(k):
    return tuple(k) if isinstance(k, list) else k


def dumps(value, key: str = "") -> bytes:
    """Serialise `value` to .npz bytes (raises Unsupported for a type the cache does not store). `key` is recorded so a
    read can check the entry is the one its file name claims (SEC-C-014 L5)."""
    e = _Enc()
    tree = e.enc(value)
    meta = json.dumps({"schema": SCHEMA, "key": key, "tree": tree}, allow_nan=True).encode()
    buf = io.BytesIO()
    np.savez(buf, __meta__=np.frombuffer(meta, dtype=np.uint8), **e.arrays)
    return buf.getvalue()


def loads(data: bytes, key: str | None = None):
    with np.load(io.BytesIO(data), allow_pickle=False) as z:
        arrays = {k: z[k] for k in z.files if k != "__meta__"}
        meta = json.loads(z["__meta__"].tobytes().decode())
    if meta.get("schema") != SCHEMA:
        raise ValueError(f"cache schema {meta.get('schema')!r}")
    if key is not None and meta.get("key") != key:             # SEC-C-014 L5: a renamed or copied entry is a miss
        raise ValueError("cache entry was written for another key")
    return _dec(meta["tree"], arrays)


# -------------------------------------------------------------------------------------------------- memo
def _path(namespace: str, key: str) -> Path:
    safe = "".join(ch for ch in namespace if ch.isalnum() or ch in "-_") or "fit"
    return cache_dir() / safe / f"{key}.npz"


def memo(namespace: str, inputs: dict, params: dict | None, compute: Callable[[], Any], code=()):
    """compute() once per (namespace, inputs, params, code, runtime); later calls read the stored value.

    Returns exactly what compute() returned on a miss, and a bit-identical copy on a hit. With no cache folder
    configured it simply calls compute()."""
    if not enabled():
        return compute()
    try:
        key = make_key(namespace, inputs, params, code)
    except Exception:                                          # noqa: BLE001 (an input we cannot hash: no cache)
        STATS["skip"] += 1
        return compute()
    p = _path(namespace, key)
    try:
        present = p.exists()
    except OSError:                                            # HO-B-C-016: unreadable cache folder means compute
        STATS["error"] += 1
        return compute()
    if present:
        try:
            if p.is_symlink() or p.parent.is_symlink():          # SEC-C-014 L6: never read through a link
                raise ValueError("symlinked cache entry")
            value = loads(p.read_bytes(), key=key)
            STATS["hit"] += 1
            try:
                os.utime(p)                                    # last use, for prune()
            except OSError:
                pass
            return value
        except Exception:                                      # noqa: BLE001 (unreadable entry: recompute, rewrite)
            STATS["error"] += 1
    value = compute()
    STATS["miss"] += 1
    try:
        data = dumps(value, key=key)
    except Unsupported:
        STATS["skip"] += 1
        return value
    try:
        p.parent.mkdir(parents=True, exist_ok=True)
        if p.parent.is_symlink():                              # SEC-C-014 L6: do not write through a linked folder
            raise OSError("symlinked cache folder")
        fd, tmp = tempfile.mkstemp(dir=p.parent, suffix=".tmp")
        with os.fdopen(fd, "wb") as fh:
            fh.write(data)
        os.replace(tmp, p)
    except OSError:
        STATS["error"] += 1
    return value
