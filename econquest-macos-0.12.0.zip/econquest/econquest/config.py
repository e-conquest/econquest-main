"""Configuration objects. Every numeric assumption lives in data/assumptions.json so that the
workbook and the program share one parameter set; this module gives it a typed shape."""
from __future__ import annotations
import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any

REGIMES = ("Calm", "Stressed", "Crisis")
PILLARS = {1: "Fiscal and debt", 2: "External", 3: "Institutions and governance", 4: "Political and policy",
           5: "Macro and financial", 6: "Security and social", 7: "Climate and disaster"}
ASSET_CLASSES = ("FX", "Local bond", "Eurobond", "Equity", "CDS protection")


@dataclass
class Settings:
    raw: dict[str, Any]
    paths: int = 100_000
    seed: int = 7
    horizon_months: int = 12
    scenario_override: str = "Model"   # Model / All stressed / All crisis
    use_sobol: bool = True

    @classmethod
    def load(cls, path: str | Path, **overrides) -> "Settings":
        raw = json.loads(Path(path).read_text())
        mc = raw.get("monte_carlo", {})
        s = cls(raw=raw, paths=int(mc.get("paths", 100_000)), seed=int(mc.get("seed", 7)),
                scenario_override=mc.get("scenario_override", "Model"))
        for k, v in overrides.items():
            if v is not None:
                setattr(s, k, v)
        return s

    def __getitem__(self, key: str) -> Any:
        return self.raw[key]

    def get(self, *keys, default=None):
        node: Any = self.raw
        for k in keys:
            if not isinstance(node, dict) or k not in node:
                return default
            node = node[k]
        return node

    def copy_with(self, **patches) -> "Settings":
        """Deep-copy the parameter set and apply dotted-path patches, e.g. {'regime.Calm.global_loading': 0.4}."""
        import copy
        raw = copy.deepcopy(self.raw)
        for dotted, value in patches.items():
            node = raw
            parts = dotted.split(".")
            for p in parts[:-1]:
                node = node.setdefault(p, {})
            node[parts[-1]] = value
        return Settings(raw=raw, paths=self.paths, seed=self.seed, horizon_months=self.horizon_months,
                        scenario_override=self.scenario_override, use_sobol=self.use_sobol)
