"""JSON encoding for the run store (EQ-A-0002).

A local copy of the encoder the engine uses for `outputs/run_latest.json`, so `persistence` no longer
imports `engine` (layering: persistence sits below engine). It must stay byte-identical to
`econquest.engine.pipeline.dumps` for run dicts; `tests/test_store.py` pins that.
"""
from __future__ import annotations
import json
from datetime import datetime
import numpy as np
import pandas as pd


def _json_safe(o):
    if isinstance(o, (np.floating, np.integer)):
        return o.item()
    if isinstance(o, np.ndarray):
        return o.tolist()
    if isinstance(o, (pd.Timestamp, datetime)):
        return o.isoformat()
    if isinstance(o, float) and np.isnan(o):
        return None
    return str(o)


def _clean(o):
    """Replace NaN/inf floats (which json.dumps writes as bare NaN, invalid JSON for browsers) with null."""
    if isinstance(o, dict):
        return {k: _clean(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_clean(v) for v in o]
    if isinstance(o, (float, np.floating)) and not np.isfinite(o):
        return None
    return o


def dumps(obj) -> str:
    return json.dumps(_clean(obj), default=_json_safe, indent=1)
