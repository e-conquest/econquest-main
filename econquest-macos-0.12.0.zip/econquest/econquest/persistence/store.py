from __future__ import annotations
import json
import sqlite3
from collections.abc import Mapping
from pathlib import Path
import numpy as np
import pandas as pd
from .jsonio import dumps

SCHEMA = """
CREATE TABLE IF NOT EXISTS runs (run_id TEXT PRIMARY KEY, created_at TEXT, label TEXT, settings TEXT, provenance TEXT, summary TEXT);
CREATE TABLE IF NOT EXISTS country_metrics (run_id TEXT, created_at TEXT, country TEXT, metric TEXT, value REAL);
CREATE TABLE IF NOT EXISTS country_text (run_id TEXT, country TEXT, field TEXT, value TEXT);
CREATE TABLE IF NOT EXISTS portfolio_metrics (run_id TEXT, created_at TEXT, metric TEXT, value REAL);
CREATE TABLE IF NOT EXISTS position_metrics (run_id TEXT, position_id TEXT, country TEXT, asset_class TEXT, metric TEXT, value REAL);
CREATE TABLE IF NOT EXISTS arbitrage (run_id TEXT, contract_id TEXT, country TEXT, platform TEXT, side TEXT, net_edge_pp REAL, stake_k REAL, model_p_res REAL, yes_price REAL, flag INTEGER, read TEXT);
CREATE TABLE IF NOT EXISTS indicator_definitions (indicator_id TEXT PRIMARY KEY, pillar INTEGER, name TEXT, unit TEXT, weight REAL, direction REAL, thresholds TEXT);
CREATE INDEX IF NOT EXISTS ix_cm ON country_metrics (country, metric, created_at);
CREATE INDEX IF NOT EXISTS ix_pm ON portfolio_metrics (metric, created_at);
CREATE TABLE IF NOT EXISTS signals (run_id TEXT, created_at TEXT, as_of TEXT, signal_key INTEGER, signal_name TEXT,
                                    country TEXT, value REAL, PRIMARY KEY (run_id, signal_key, country));
CREATE TABLE IF NOT EXISTS activation (run_id TEXT, created_at TEXT, as_of TEXT, trade_id TEXT, country TEXT,
                                       fired INTEGER, value REAL, PRIMARY KEY (run_id, trade_id, country));
CREATE INDEX IF NOT EXISTS ix_sig ON signals (country, signal_key, created_at);
CREATE INDEX IF NOT EXISTS ix_act ON activation (country, trade_id, created_at);
"""

CHILD_TABLES = ("country_metrics", "country_text", "portfolio_metrics", "position_metrics", "arbitrage", "signals", "activation")
POSITION_METRICS = ("notional_mm", "expected_loss_mm", "tail_contribution_99_mm", "liquidity_cost_99_mm", "share_of_es99")


def _num(v) -> float | None:
    """Cell value as float, or None for a missing / NaN cell (JSON-loaded dicts carry null, live ones NaN)."""
    if v is None:
        return None
    f = float(v)
    return None if np.isnan(f) else f


def _signal_rows(d: dict, run_id: str, created_at: str, as_of, names: Mapping) -> list[tuple]:
    """One row per (signal key, country) of `d["signals"]` (records with a "key" column; GOV-030)."""
    out = []
    for rec in d.get("signals") or []:
        key = int(rec["key"])
        name = names.get(key, names.get(str(key)))
        out += [(run_id, created_at, as_of, key, name, ctry, _num(v)) for ctry, v in rec.items() if ctry != "key"]
    return out


def _activation_rows(d: dict, run_id: str, created_at: str, as_of) -> list[tuple]:
    """Every (trade, country) cell of `d["activation"]`: fired=1 with the strength, or fired=0 and NULL (GOV-030)."""
    out = []
    for rec in d.get("activation") or []:
        for ctry, v in rec.items():
            if ctry != "trade":
                x = _num(v)
                out.append((run_id, created_at, as_of, str(rec["trade"]), ctry, int(x is not None), x))
    return out


class Store:
    def __init__(self, root: str | Path):
        self.root = Path(root); self.root.mkdir(parents=True, exist_ok=True)
        self.db = self.root / "econquest.sqlite"
        self.archive = self.root / "archive"; self.archive.mkdir(exist_ok=True)
        with self._conn() as c:
            c.executescript(SCHEMA)

    def _conn(self):
        return sqlite3.connect(self.db)

    def save_rulebook(self, rulebook: pd.DataFrame):
        rows = [(r["id"], int(r["pillar"]), r["indicator"], r["unit"], float(r["weight"]), float(r["direction"]),
                 json.dumps([r[k] for k in ("t0", "t25", "t50", "t75", "t100")])) for _, r in rulebook.iterrows()]
        with self._conn() as c:
            c.executemany("INSERT OR REPLACE INTO indicator_definitions VALUES (?,?,?,?,?,?,?)", rows)

    def save_run(self, result, keep_paths: bool = True, signal_names: Mapping | None = None) -> str:
        """Store one run. `result` is a run dict in the `RunResult.to_dict()` shape (contract C5), or any
        object with a `.to_dict()` returning one (duck typed: persistence does not import engine).
        Saving the same run_id again replaces that run's rows instead of duplicating them (F8).
        The loss-path archive (`keep_paths`) needs `result.mc.losses` / `.position_losses`; a plain dict
        has no paths, so none are written for it.
        `signals` / `activation` (GOV-030) are written when the run carries them. `signal_name` comes from
        `signal_names` (key -> name, e.g. engine.signals.SIGNAL_NAMES), else from `d["signal_names"]` if the
        run dict has it, else NULL."""
        d = result.to_dict() if hasattr(result, "to_dict") else result
        if not isinstance(d, dict):
            raise TypeError(f"save_run expects a run dict or an object with .to_dict(), got {type(result).__name__}")
        s = d["summary"]
        run_id, created_at = s["run_id"], s["created_at"]
        country = pd.DataFrame(d["country"]).set_index("country") if d.get("country") else pd.DataFrame()
        # Column kinds are re-inferred from the records: a column that is entirely null (e.g. regime_hmm with the
        # HMM off) reads back as numeric, so it no longer writes "nan" rows to country_text (nothing reads them).
        contributions = pd.DataFrame(d.get("contributions") or [])
        arbitrage = d.get("arbitrage") or []
        with self._conn() as c:                                   # one transaction: commit on success, rollback on error
            for t in CHILD_TABLES:
                # B608: t is one of the module constant CHILD_TABLES, never input; run_id is a bound parameter
                c.execute(f"DELETE FROM {t} WHERE run_id=?", (run_id,))  # nosec B608
            c.execute("INSERT OR REPLACE INTO runs VALUES (?,?,?,?,?,?)",
                      (run_id, created_at, s.get("label", "base"), dumps(d.get("settings")), dumps(d.get("provenance")), dumps(s)))
            num = country.select_dtypes(include=[np.number])
            c.executemany("INSERT INTO country_metrics VALUES (?,?,?,?,?)",
                          [(run_id, created_at, ctry, m, float(v)) for ctry, row in num.iterrows() for m, v in row.items() if pd.notna(v)])
            txt = country.select_dtypes(exclude=[np.number])
            c.executemany("INSERT INTO country_text VALUES (?,?,?,?)", [(run_id, ctry, f, str(v)) for ctry, row in txt.iterrows() for f, v in row.items()])
            c.executemany("INSERT INTO portfolio_metrics VALUES (?,?,?,?)", [(run_id, created_at, k, float(v)) for k, v in (s.get("metrics") or {}).items()])
            pid_col = contributions.columns[0] if len(contributions.columns) else None   # reset_index() puts the position id first
            c.executemany("INSERT INTO position_metrics VALUES (?,?,?,?,?,?)",
                          [(run_id, row[pid_col], row["country"], row["asset_class"], m, float(row[m])) for _, row in contributions.iterrows()
                           for m in POSITION_METRICS])
            if len(arbitrage):
                c.executemany("INSERT INTO arbitrage VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                              [(run_id, a["id"], a["country"], a["platform"], a["side"], float(a["net_edge_pp"]), float(a["stake_k"]), float(a["model_p_res"]),
                                float(a["yes_price"]), int(bool(a["divergence_flag"])), a["read"]) for a in arbitrage])
            as_of = (d.get("settings") or {}).get("as_of") or s.get("as_of")
            names = signal_names if signal_names is not None else (d.get("signal_names") or {})
            c.executemany("INSERT OR REPLACE INTO signals VALUES (?,?,?,?,?,?,?)", _signal_rows(d, run_id, created_at, as_of, names))
            c.executemany("INSERT OR REPLACE INTO activation VALUES (?,?,?,?,?,?,?)", _activation_rows(d, run_id, created_at, as_of))
        (self.archive / f"{run_id}.json").write_text(dumps(d))
        mc = getattr(result, "mc", None)
        if keep_paths and mc is not None:
            np.savez_compressed(self.archive / f"{run_id}_paths.npz", losses=mc.losses.astype(np.float32), position_losses=mc.position_losses.astype(np.float32))
        return run_id

    def runs(self, limit: int = 50) -> list[dict]:
        with self._conn() as c:
            rows = c.execute("SELECT run_id, created_at, label, summary FROM runs ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
        return [{"run_id": a, "created_at": b, "label": l, "summary": json.loads(s)} for a, b, l, s in rows]

    def latest(self, label: str | None = None) -> dict | None:
        with self._conn() as c:
            # B608: built from literal fragments only; label is a bound parameter
            q = "SELECT run_id FROM runs" + (" WHERE label=?" if label else "") + " ORDER BY created_at DESC LIMIT 1"  # nosec B608
            row = c.execute(q, (label,) if label else ()).fetchone()
        return self.load(row[0]) if row else None

    def load(self, run_id: str) -> dict:
        return json.loads((self.archive / f"{run_id}.json").read_text())

    def series(self, metric: str, country: str | None = None) -> pd.DataFrame:
        """Time series of a metric across runs (the TimescaleDB query)."""
        with self._conn() as c:
            if country:
                return pd.read_sql("SELECT created_at, value FROM country_metrics WHERE metric=? AND country=? ORDER BY created_at", c, params=(metric, country))
            return pd.read_sql("SELECT created_at, value FROM portfolio_metrics WHERE metric=? ORDER BY created_at", c, params=(metric,))

    def _query(self, select: str, filters: list[tuple[str, object]], since: str | None) -> pd.DataFrame:
        """`select` plus AND-ed `col=?` filters (columns are code literals; values always bound) and created_at >= since."""
        where = [(f"{col}=?", v) for col, v in filters if v is not None]
        if since is not None:
            where.append(("created_at>=?", since))
        sql = select + (" WHERE " + " AND ".join(w for w, _ in where) if where else "")
        with self._conn() as c:
            return pd.read_sql(sql + " ORDER BY created_at, run_id", c, params=tuple(v for _, v in where))

    def signals(self, country: str | None = None, signal_key: int | None = None, since: str | None = None) -> pd.DataFrame:
        """Stored signal values across runs (GOV-030), oldest first; `since` compares to created_at (ISO text)."""
        return self._query("SELECT run_id, created_at, as_of, signal_key, signal_name, country, value FROM signals",
                           [("country", country), ("signal_key", None if signal_key is None else int(signal_key))], since)

    def activations(self, country: str | None = None, trade_id: str | None = None, since: str | None = None) -> pd.DataFrame:
        """Stored playbook activations across runs (GOV-030), fired and not fired, oldest first."""
        return self._query("SELECT run_id, created_at, as_of, trade_id, country, fired, value FROM activation",
                           [("country", country), ("trade_id", trade_id)], since)
