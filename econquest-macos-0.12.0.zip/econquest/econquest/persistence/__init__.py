"""Persistence layer (paper Appendix B.4). SQLite stands in for PostgreSQL (scorecard metadata, runs),
TimescaleDB (country and portfolio metrics by run time) and the S3 path archive (npz files)."""
from .store import Store  # noqa: F401
