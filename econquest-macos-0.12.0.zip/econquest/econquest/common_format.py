"""Neutral cell formatting shared by every layer that builds a Sheets values plan.

No imports from econquest.presentation or econquest.ingestion, so ingestion code (the audit trail) and
presentation code (the publishers) can both use it without a layering cycle.

- `cell_value(x)` (alias `_v`): JSON-safe cell value; NaN/None/inf -> '' so the cell is cleared.
- `escape_formula(x)`: a str starting with = + - @ tab or CR gets a leading single quote, so Sheets
  stores it as text under valueInputOption USER_ENTERED instead of evaluating it (formula injection,
  EQ-C-0007). Non-str values are returned unchanged; already-quoted text is left alone.
- `safe_cell(x)`: `escape_formula(cell_value(x))`, what every plan writer should put in a cell.
- `sanitize_plan(plan)`: applies `escape_formula` to every value of a {"range", "values"} plan.

The publishers build no formulas on purpose (the workbook receives values only), so there is no
formula whitelist: every text cell is escaped.
"""
from __future__ import annotations

import math

import numpy as np
import pandas as pd

FORMULA_PREFIXES = ("=", "+", "-", "@", "\t", "\r")
# Defence in depth (AGENT-09 review): also quote text whose first non-blank character is a formula prefix, or its
# full-width form (U+FF1D = U+FF0B + U+FF0D - U+FF20 @). Sheets is not known to evaluate these, but the quote only
# costs an apostrophe that Sheets strips, and other clients that apply a saved plan (or trim input) might.
_LEAD_BLANKS = " \t\r\n   　﻿"
_LOOSE_PREFIXES = FORMULA_PREFIXES[:4] + ("＝", "＋", "－", "＠")


def cell_value(x):
    """JSON-safe cell value; NaN/None -> '' so the cell is cleared."""
    if x is None:
        return ""
    if isinstance(x, (np.bool_, bool)):
        return bool(x)
    if isinstance(x, (np.integer,)):
        return int(x)
    if isinstance(x, (float, np.floating)):
        return "" if (math.isnan(x) or math.isinf(x)) else float(x)
    if isinstance(x, (pd.Timestamp,)):
        return x.strftime("%Y-%m-%d")
    return x


_v = cell_value


def escape_formula(x):
    """Prefix a text value that Sheets would parse as a formula with a single quote; other values unchanged."""
    if isinstance(x, str) and (x.startswith(FORMULA_PREFIXES) or x.lstrip(_LEAD_BLANKS).startswith(_LOOSE_PREFIXES)):
        return "'" + x
    return x


def safe_cell(x):
    return escape_formula(cell_value(x))


def sanitize_plan(plan: list[dict]) -> list[dict]:
    """Copy of a values plan with every text cell escaped (idempotent: escaped text starts with a quote)."""
    out = []
    for b in plan:
        vals = b.get("values")
        if isinstance(vals, list):
            vals = [[escape_formula(x) for x in row] if isinstance(row, (list, tuple)) else escape_formula(row) for row in vals]
        out.append({**b, "values": vals})
    return out
