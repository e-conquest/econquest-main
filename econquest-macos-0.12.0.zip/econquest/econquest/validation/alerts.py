"""Alerts (roadmap item 4.3): compare the latest run with the previous archived run and the forecast record, and
raise an alert when a regime flips, a default PD moves or crosses a level, a signal crosses its activation
threshold, VaR/ES move by more than a set share, a backtest fails or the Basel zone leaves green, or the data
layer reports a quality-gate hold or a failed feed.

`detect_alerts` accepts a full archived run dict (what `Store.load` / `RunResult.to_dict` give: a `summary` key
plus `country`, `signals`, `activation`) or a bare run summary (what `Store.runs` lists). With a bare summary
only the aggregate checks (VaR/ES, global regime, top-five default PDs) can run.

Each alert is a dict: severity ("info" / "warning" / "critical"), kind, scope (country name, "global", "book",
"backtest" or "data"), country (or None), message, value, threshold.

Thresholds live in assumptions.json under "alerts":
  pd_change_pp     default PD move between runs that raises an alert, in percentage points (default 2)
  pd_level         default PD level whose crossing (either way) raises an alert (default 0.25)
  var_change_pct   VaR99 / ES99 change between runs, in percent (default 10)
  signal_threshold activation threshold for signals; defaults to signals.threshold
  stale_days       a live input older than this many days is reported as stale (default 45; used by the report)
"""
from __future__ import annotations
import datetime as dt
import json
import math
import os
from pathlib import Path
import pandas as pd

DEFAULTS = {"pd_change_pp": 2.0, "pd_level": 0.25, "var_change_pct": 10.0, "signal_threshold": 60.0, "stale_days": 45}
SEVERITY_RANK = {"critical": 0, "warning": 1, "info": 2}
REGIME_RANK = {"Calm": 0, "Stressed": 1, "Crisis": 2}


def alert_settings(settings) -> dict:
    """Merge the defaults with assumptions.json `alerts` (settings may be a Settings, a raw dict or None)."""
    raw = settings.raw if hasattr(settings, "raw") else (settings or {})
    cfg = dict(DEFAULTS)
    sig = (raw.get("signals") or {}).get("threshold") if isinstance(raw, dict) else None
    if sig is not None:
        cfg["signal_threshold"] = float(sig)
    for k, v in ((raw.get("alerts") or {}) if isinstance(raw, dict) else {}).items():
        if k in cfg and v is not None:
            cfg[k] = float(v)
    return cfg


def _finite(v) -> bool:
    try:
        return v is not None and math.isfinite(float(v))
    except (TypeError, ValueError):
        return False


def normalise_run(run) -> dict:
    """Pull what the alerts need out of a run (full archive dict, bare summary or RunResult)."""
    if run is None:
        return {"summary": {}, "metrics": {}, "country": {}, "signals": {}, "activation": {}, "global_regime": None, "run_id": None}
    if hasattr(run, "to_dict"):
        run = run.to_dict()
    full = "summary" in run
    summary = run["summary"] if full else run
    country: dict[str, dict] = {}
    if full:
        for r in run.get("country") or []:
            country[str(r["country"])] = r
    else:
        for c, p in (summary.get("top_default_pd") or {}).items():
            country[c] = {"pd_default": p}
    signals: dict[int, dict] = {}
    for r in (run.get("signals") or []) if full else []:
        signals[int(r["key"])] = {c: v for c, v in r.items() if c != "key"}
    activation: dict[str, dict] = {}
    for r in (run.get("activation") or []) if full else []:
        activation[str(r["trade"])] = {c: v for c, v in r.items() if c != "trade"}
    return {"summary": summary, "metrics": summary.get("metrics") or {}, "country": country, "signals": signals, "activation": activation,
            "global_regime": summary.get("global_regime") or (run.get("diagnostics") or {}).get("global_regime") if full else summary.get("global_regime"),
            "run_id": summary.get("run_id"), "created_at": summary.get("created_at")}


def _alert(severity, kind, scope, message, value=None, threshold=None, country=None) -> dict:
    return {"severity": severity, "kind": kind, "scope": scope, "country": country, "message": message,
            "value": None if value is None else (float(value) if _finite(value) else value),
            "threshold": None if threshold is None else (float(threshold) if _finite(threshold) else threshold)}


def regime_alerts(cur: dict, prev: dict) -> list[dict]:
    out = []
    g0, g1 = prev.get("global_regime"), cur.get("global_regime")
    if g0 and g1 and g0 != g1:
        up = REGIME_RANK.get(g1, 0) > REGIME_RANK.get(g0, 0)
        out.append(_alert("critical" if g1 == "Crisis" else ("warning" if up else "info"), "regime_flip", "global",
                          f"Global regime moved from {g0} to {g1}", value=g1, threshold=g0))
    for c, r in cur["country"].items():
        p = prev["country"].get(c)
        r0, r1 = (p or {}).get("regime"), r.get("regime")
        if p is None or not r0 or not r1 or r0 == r1:
            continue
        up = REGIME_RANK.get(r1, 0) > REGIME_RANK.get(r0, 0)
        out.append(_alert("critical" if r1 == "Crisis" else ("warning" if up else "info"), "regime_flip", c,
                          f"{c}: regime {r0} -> {r1}", value=r1, threshold=r0, country=c))
    return out


def pd_alerts(cur: dict, prev: dict, cfg: dict) -> list[dict]:
    out = []
    pp, level = cfg["pd_change_pp"], cfg["pd_level"]
    for c, r in cur["country"].items():
        p1 = r.get("pd_default")
        p0 = (prev["country"].get(c) or {}).get("pd_default")
        if not _finite(p1) or not _finite(p0):
            continue
        move = (float(p1) - float(p0)) * 100
        if abs(move) >= pp:
            out.append(_alert("critical" if abs(move) >= 2 * pp else "warning", "pd_change", c,
                              f"{c}: 12m default PD {p0*100:.2f}% -> {p1*100:.2f}% ({move:+.2f} pp)", value=move, threshold=pp, country=c))
        if (p0 < level) != (p1 < level):
            crossed_up = p1 >= level
            out.append(_alert("critical" if crossed_up else "info", "pd_level", c,
                              f"{c}: default PD crossed {'above' if crossed_up else 'below'} {level*100:.0f}% ({p0*100:.2f}% -> {p1*100:.2f}%)",
                              value=p1, threshold=level, country=c))
    return out


def signal_alerts(cur: dict, prev: dict, cfg: dict) -> list[dict]:
    """A signal that crosses the activation threshold between runs, and a playbook trade that starts or stops firing."""
    try:
        from ..engine.signals import SIGNAL_NAMES
    except Exception:                                        # pragma: no cover
        SIGNAL_NAMES = {}
    out = []
    thr = cfg["signal_threshold"]
    for key, row in cur["signals"].items():
        before = prev["signals"].get(key)
        if before is None:
            continue
        name = SIGNAL_NAMES.get(key, f"signal {key}")
        for c, v1 in row.items():
            v0 = before.get(c)
            if not _finite(v0) or not _finite(v1):
                continue
            if (float(v0) >= thr) != (float(v1) >= thr):
                up = float(v1) >= thr
                out.append(_alert("warning" if up else "info", "signal_cross", c,
                                  f"{c}: signal {key} ({name}) {'crossed above' if up else 'fell below'} {thr:.0f} ({float(v0):.0f} -> {float(v1):.0f})",
                                  value=v1, threshold=thr, country=c))
    for trade, row in cur["activation"].items():
        before = prev["activation"].get(trade)
        if before is None:
            continue
        for c, v1 in row.items():
            on0, on1 = _finite(before.get(c)), _finite(v1)
            if on0 != on1:
                out.append(_alert("warning" if on1 else "info", "trade_activation", c,
                                  f"{c}: playbook trade {trade} {'activated' if on1 else 'deactivated'}" + (f" (strength {float(v1):.0f})" if on1 else ""),
                                  value=v1 if on1 else None, threshold=None, country=c))
    return out


def var_alerts(cur: dict, prev: dict, cfg: dict) -> list[dict]:
    out = []
    pct = cfg["var_change_pct"]
    for key, label in (("var99_mm", "VaR99"), ("es99_mm", "ES99")):
        a, b = prev["metrics"].get(key), cur["metrics"].get(key)
        if not _finite(a) or not _finite(b) or float(a) == 0:
            continue
        ch = (float(b) / float(a) - 1) * 100
        if abs(ch) >= pct:
            out.append(_alert("critical" if abs(ch) >= 2 * pct else "warning", "var_change", "book",
                              f"12m {label} {float(a):.1f} -> {float(b):.1f} $mm ({ch:+.1f}%)", value=ch, threshold=pct))
    return out


def backtest_status(record_df: pd.DataFrame | None, alpha: float = 0.99, min_rows: int = 20) -> dict | None:
    """Backtests on the forecast record, or None when the record is too short."""
    if record_df is None or len(record_df) == 0:
        return None
    from .record import record_for_backtest
    from .backtests import backtest_history
    hist = record_for_backtest(record_df) if "var_next" in record_df.columns else record_df.dropna(subset=["loss", "var", "es"])
    if len(hist) < min_rows:
        return None
    bt = backtest_history(hist, alpha=alpha)
    bt["first_date"] = str(pd.Timestamp(hist["date"].min()).date()) if "date" in hist.columns else None
    bt["last_date"] = str(pd.Timestamp(hist["date"].max()).date()) if "date" in hist.columns else None
    return bt


def backtest_alerts(bt: dict | None) -> list[dict]:
    if not bt:
        return []
    out = []
    k, c, z = bt["kupiec"], bt["christoffersen"], bt["acerbi_szekely"]
    if k["p_value"] < 0.05:
        out.append(_alert("critical", "backtest_fail", "backtest", f"Kupiec coverage test failed: {k['exceedances']} exceedances vs {k['expected']:.1f} expected over {k['n']} days (p={k['p_value']:.3f})",
                          value=k["p_value"], threshold=0.05))
    if c["p_value_cc"] < 0.05:
        out.append(_alert("critical", "backtest_fail", "backtest", f"Christoffersen conditional coverage failed (LR_cc {c['LR_cc']:.2f}, p={c['p_value_cc']:.3f})",
                          value=c["p_value_cc"], threshold=0.05))
    if not z["pass"]:
        out.append(_alert("critical", "backtest_fail", "backtest", f"Acerbi-Szekely Z2 {z['Z2']:.3f} below the critical value {z['critical']}: ES understated",
                          value=z["Z2"], threshold=z["critical"]))
    zone = bt.get("basel_zone")
    if zone in ("Yellow", "Red"):
        out.append(_alert("critical" if zone == "Red" else "warning", "basel_zone", "backtest",
                          f"Basel traffic light is {zone} ({k['exceedances']} exceedances in {k['n']} days)", value=k["exceedances"], threshold=zone))
    return out


def data_alerts(review: pd.DataFrame | None, feeds: dict | None) -> list[dict]:
    out = []
    if review is not None and len(review) and "status" in review.columns:
        held = review[review["status"].astype(str).str.lower() == "hold"]
        for _, r in held.iterrows():
            out.append(_alert("warning", "quality_hold", str(r.get("country", "data")),
                              f"Quality gate held {r.get('table', '')} {r.get('key', '')} for {r.get('country', '')}: {r.get('reason', '')} (seed {r.get('seed')}, live {r.get('live')})",
                              value=r.get("live"), threshold=r.get("seed"), country=str(r.get("country")) if pd.notna(r.get("country")) else None))
        n_missing = int((review["status"].astype(str).str.lower() == "missing").sum())
        if n_missing:
            out.append(_alert("info", "feed_missing", "data", f"{n_missing} input cells had no live value on the last pull and stay on seed estimates", value=n_missing))
    status = (feeds or {}).get("feeds", feeds) if isinstance(feeds, dict) else None
    for name, st in (status or {}).items():
        if not str(st).lower().startswith("ok"):
            out.append(_alert("critical", "feed_failure", "data", f"Feed {name} failed on the last pull: {st}", value=str(st)))
    return out


def detect_alerts(current_run_summary, previous_run_summary, record_df: pd.DataFrame | None, settings,
                  review: pd.DataFrame | None = None, feeds: dict | None = None) -> list[dict]:
    """All alerts, most severe first. `current_run_summary` / `previous_run_summary` are archived run dicts or summaries
    (previous may be None: then only the backtest and data checks run)."""
    cfg = alert_settings(settings)
    cur = normalise_run(current_run_summary); prev = normalise_run(previous_run_summary)
    out: list[dict] = []
    if previous_run_summary is not None:
        out += regime_alerts(cur, prev) + pd_alerts(cur, prev, cfg) + signal_alerts(cur, prev, cfg) + var_alerts(cur, prev, cfg)
    out += backtest_alerts(backtest_status(record_df))
    out += data_alerts(review, feeds)
    for a in out:
        a["run_id"] = cur.get("run_id"); a["previous_run_id"] = prev.get("run_id")
    out.sort(key=lambda a: (SEVERITY_RANK.get(a["severity"], 9), a["kind"], str(a["scope"])))
    return out


def load_data_issues(data_dir: str | Path) -> tuple[pd.DataFrame | None, dict | None]:
    """review.csv and feeds.json from data/live, if present."""
    live = Path(data_dir) / "live"
    review = pd.read_csv(live / "review.csv") if (live / "review.csv").exists() else None
    feeds = json.loads((live / "feeds.json").read_text()) if (live / "feeds.json").exists() else None
    return review, feeds


def digest(alerts: list[dict], run_id: str | None = None) -> str:
    counts = {s: sum(1 for a in alerts if a["severity"] == s) for s in ("critical", "warning", "info")}
    head = "EconQuest alerts" + (f" for run {run_id}" if run_id else "") + f": {counts['critical']} critical, {counts['warning']} warning, {counts['info']} info"
    if not alerts:
        return head + "\nNo alerts: no regime flip, PD or VaR move, signal crossing, backtest failure or data issue."
    lines = [head] + [f"[{a['severity'].upper():8s}] {a['kind']:16s} {a['message']}" for a in alerts]
    return "\n".join(lines)


def _webhook_payload(alerts: list[dict], text: str) -> dict:
    """One payload that both Slack (text + blocks) and Teams (text + themeColor + summary) incoming webhooks accept."""
    worst = min((SEVERITY_RANK.get(a["severity"], 2) for a in alerts), default=2)
    colour = {0: "C0392B", 1: "E67E22", 2: "2E86C1"}[worst]
    body = "\n".join(f"- *{a['severity']}* {a['message']}" for a in alerts[:40]) or "No alerts."
    return {"text": text, "summary": text.splitlines()[0], "themeColor": colour,
            "blocks": [{"type": "section", "text": {"type": "mrkdwn", "text": f"*{text.splitlines()[0]}*\n{body}"[:2900]}}]}


def check_webhook_url(url: str) -> None:
    """A webhook URL is itself a secret: accept https, or plain http only to loopback; never file:, ftp: or others
    (EQ-B-0018, SEC-C-002 #8). The error never repeats the URL."""
    from urllib.parse import urlsplit
    if any(ch.isspace() or ord(ch) < 32 or ord(ch) == 127 for ch in url.strip()):
        raise ValueError("webhook URL contains whitespace or control characters; refused")   # http.client would echo it
    parts = urlsplit(url.strip())
    if parts.scheme == "https" and parts.hostname:
        return
    if parts.scheme == "http" and parts.hostname in ("localhost", "127.0.0.1", "::1"):
        return
    raise ValueError(f"webhook URL must use https (http only to localhost); scheme {parts.scheme or 'none'!r} refused")


def post_webhook(url: str, payload: dict, timeout: float = 10.0) -> str:
    import urllib.error
    import urllib.request
    check_webhook_url(url)
    req = urllib.request.Request(url, data=json.dumps(payload).encode(), headers={"Content-Type": "application/json"}, method="POST")
    try:
        with urllib.request.urlopen(req, timeout=timeout) as resp:  # nosec B310: scheme checked by check_webhook_url
            return f"HTTP {resp.status}"
    except urllib.error.HTTPError as e:                      # report the status only, never the URL
        raise RuntimeError(f"HTTP {e.code}") from None
    except (urllib.error.URLError, OSError) as e:
        raise RuntimeError(f"webhook unreachable ({type(getattr(e, 'reason', e)).__name__})") from None
    except Exception as e:                                   # e.g. http.client.InvalidURL, whose text carries the URL
        raise RuntimeError(f"webhook request failed ({type(e).__name__})") from None


def send_email(env: dict, subject: str, text: str, html: str | None = None) -> str:
    import smtplib
    from email.message import EmailMessage
    host = env["ECONQUEST_SMTP_HOST"]; port = int(env.get("ECONQUEST_SMTP_PORT", "587"))
    user, pw = env.get("ECONQUEST_SMTP_USER"), env.get("ECONQUEST_SMTP_PASSWORD")
    sender = env.get("ECONQUEST_SMTP_FROM") or user; to = [t.strip() for t in env.get("ECONQUEST_SMTP_TO", "").split(",") if t.strip()]
    if not sender or not to:
        raise ValueError("ECONQUEST_SMTP_FROM and ECONQUEST_SMTP_TO must be set")
    msg = EmailMessage(); msg["Subject"] = subject; msg["From"] = sender; msg["To"] = ", ".join(to)
    msg.set_content(text)
    if html:
        msg.add_alternative(html, subtype="html")
    import ssl
    context = ssl.create_default_context()                   # verify the server certificate and host name
    if port == 465:
        server = smtplib.SMTP_SSL(host, port, timeout=20, context=context)
    else:
        server = smtplib.SMTP(host, port, timeout=20)
        # Fail closed (EQ-B-0009): never send credentials or mail in plaintext when STARTTLS is unavailable or fails.
        try:
            server.ehlo()
            if not server.has_extn("starttls"):
                raise smtplib.SMTPNotSupportedError(f"SMTP server {host}:{port} does not offer STARTTLS")
            server.starttls(context=context); server.ehlo()
        except (smtplib.SMTPException, ssl.SSLError, OSError, RuntimeError) as e:
            try:
                server.close()
            except Exception:
                pass
            raise ConnectionError(f"STARTTLS failed for {host}:{port}; refusing to send over plaintext: {e}") from e
    with server:
        if user and pw:
            server.login(user, pw)
        server.send_message(msg)
    return f"sent to {', '.join(to)}"


# Rows other writers own in outputs/alerts.json (ops.monitor's ops_*, ops.calendar_jobs' calendar_*, SEC-C-016): a run's
# rewrite keeps them, so they stay visible until their own job runs again.
FOREIGN_PREFIXES = ("ops_", "calendar_")


def _foreign_rows(path: Path) -> list[dict]:
    try:
        doc = json.loads(path.read_text())
    except (OSError, ValueError):
        return []
    rows = doc.get("alerts") if isinstance(doc, dict) else None
    return [a for a in (rows or []) if isinstance(a, dict) and str(a.get("kind", "")).startswith(FOREIGN_PREFIXES)]


def deliver_alerts(alerts: list[dict], settings, env: dict | None = None, out_dir: str | Path | None = None, webhook: bool = True,
                   email: bool = True, run_id: str | None = None, html: str | None = None, log=print) -> dict:
    """Write outputs/alerts.json, print the digest, and post to the webhook / send the email when the environment names
    them (ECONQUEST_ALERT_WEBHOOK; ECONQUEST_SMTP_HOST, _PORT, _USER, _PASSWORD, _FROM, _TO). Delivery failures are
    printed, never raised."""
    env = dict(os.environ if env is None else env)
    text = digest(alerts, run_id)
    status: dict = {"alerts": len(alerts), "written": None, "webhook": "skipped", "email": "skipped"}
    if out_dir is not None:
        out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
        allr = _foreign_rows(out / "alerts.json") + list(alerts)
        payload = {"generated_at": dt.datetime.now(dt.timezone.utc).isoformat(timespec="seconds"), "run_id": run_id,
                   "counts": {s: sum(1 for a in allr if a.get("severity") == s) for s in ("critical", "warning", "info")}, "alerts": allr}
        tmp = out / ".alerts.json.tmp"; tmp.write_text(json.dumps(payload, indent=1, default=str)); tmp.replace(out / "alerts.json")
        status["written"] = str(out / "alerts.json")
    log(text)
    url = env.get("ECONQUEST_ALERT_WEBHOOK")
    if webhook and url:
        try:
            status["webhook"] = post_webhook(url, _webhook_payload(alerts, text))
            log(f"[alerts] webhook: {status['webhook']}")
        except Exception as e:                               # never fail the run on delivery
            status["webhook"] = f"error: {e}"; log(f"[alerts] webhook delivery failed: {e}")
    elif webhook and not url:
        status["webhook"] = "not configured (set ECONQUEST_ALERT_WEBHOOK)"
    if email and env.get("ECONQUEST_SMTP_HOST"):
        try:
            n_crit = sum(1 for a in alerts if a["severity"] == "critical")
            subject = f"EconQuest alerts: {len(alerts)} ({n_crit} critical)" + (f" for {run_id}" if run_id else "")
            status["email"] = send_email(env, subject, text, html)
            log(f"[alerts] email: {status['email']}")
        except Exception as e:
            status["email"] = f"error: {e}"; log(f"[alerts] email delivery failed: {e}")
    elif email and not env.get("ECONQUEST_SMTP_HOST"):
        status["email"] = "not configured (set ECONQUEST_SMTP_HOST, _PORT, _USER, _PASSWORD, _FROM, _TO)"
    return status
