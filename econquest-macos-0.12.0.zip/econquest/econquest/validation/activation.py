"""Real-data activation pack (EQ-B-0079): after Sam's pull, one pass from the landed files to a decision note.

    python -m econquest.validation.activation --as-of 2026-10-23 [--staged-build PATH] [--out DIR]

It composes existing pieces; it does not re-implement them:

(a) preflight      what has landed: the full panel (data/panel/weo_history.csv, sovereign_defaults_crag.csv), Team A's
                   staged official FX build (data/market_history/builds/<vintage>/, EQ-A-0054), UCDP and GDELT event
                   vintages, the nowcast inputs. A missing piece is reported and its step is SKIPPED, not failed.
(b) hazard refit   econquest.validation.hazard_refit.run_refit (EQ-B-0067): gate report, and the change pack when the
                   gate clears. Output under <out>/hazard-refit/.
(c) FX-only rerun  the engine on the staged prices (EQ-B-0077) in a temporary copy of the data folder whose
                   market_history holds only the staged prices.csv (as `market_history apply` would leave it): the base
                   at --paths (default 100,000 requested) and the ten stress scenarios. Each is paired with the same run
                   on today's data (same random numbers), so the change has a paired batch-means SE. The 0.3.0 release
                   figures are shown as the reference.
(d) GARCH rerun    the dossier backtests (econquest/validation/garch_dossier.py, the importable form of
                   docs/validation/dossier/garch_backtests.py parts backtest and stability) on the staged FX history, compared with the GOOGLEFINANCE-era CSVs in that folder (dossier section 2 and 3).
(e) decision note  <out>/decision-note.md: one effect table per item and the exact commands. Item (c) is applying Team
                   A's build (`python -m econquest.ingestion.market_history apply`), item (b) the refit change pack,
                   item (d) the FX GARCH Tier 1 classification, a model-inventory document edit (no settings change).

Nothing here proposes, approves or applies a change. It writes only under --out (default outputs/activation/<as_of>;
it must resolve to a folder under <repo>/outputs/, anything else is refused) and temporary folders: no file in data/ or docs/ changes. No number reads the wall clock: everything is at --as-of.

`freeze_official_prices` is the frozen-price step for the new FX-only replication checks (fx-only-prices.md section 7
step 4). It writes docs/governance/releases/inputs/<next>/prices.csv from the official prices.csv. The pack does not
call it; Sam runs it after `apply` (`--freeze-official-prices`, see docs/validation/activation-runbook.md).
"""
from __future__ import annotations

import argparse
import hashlib
import json
import re
import shutil
import sys
import tempfile
import time
import traceback
import warnings
from pathlib import Path

import numpy as np
import pandas as pd
from .nocache import fit_cache_off                     # SEC-C-014 R39 (EQ-B-0084): validators refit, never read the cache

ROOT = Path(__file__).resolve().parents[2]
TICKET = "EQ-B-0079"
STATUS = ("RAN", "SKIPPED", "FAILED")
# The 0.3.0 base (docs/governance/releases/0.3.0-2026-10-24.md; brief): 100,000 requested paths, as_of 2026-10-23.
REFERENCE_VERSION = "0.3.0"
REFERENCE_AS_OF = "2026-10-23"
REFERENCE_BASE = {"var99_mm": 69.13, "es99_mm": 90.72, "expected_loss_mm": 0.80, "lvar99_mm": 74.42}
# The ten stress scenarios of the FX-only dossier (fx-only-prices.md section 5), with their 0.3.0 ES99 ($mm).
TEN_SCENARIOS = ("A", "B", "C", "DOWNGRADE", "TAIWAN", "HORMUZ", "TARIFF", "CHINA_HL", "FED22", "TAPER13")
REFERENCE_STRESS_ES99 = {"A": 145.4, "B": 98.2, "C": 107.7, "DOWNGRADE": 94.5, "TAIWAN": 152.0, "HORMUZ": 155.7,
                         "TARIFF": 143.6, "CHINA_HL": 153.7, "FED22": 162.1, "TAPER13": 155.0}
METRICS = {"var99_mm": "VaR99", "es99_mm": "ES99", "expected_loss_mm": "EL", "lvar99_mm": "L-VaR99"}
PROXY_TAG = "PROXY"
SYNTHETIC_TAG = "SYNTHETIC"
OUTPUTS_ROOT = ROOT / "outputs"
GARCH_REFERENCE = {"backtests": ROOT / "docs" / "validation" / "dossier" / "garch-tier1-backtests.csv",
                   "stability": ROOT / "docs" / "validation" / "dossier" / "garch-tier1-stability.csv",
                   "dcc": ROOT / "docs" / "validation" / "dossier" / "garch-tier1-dcc.csv"}
RELEASE_INPUTS = ROOT / "docs" / "governance" / "releases" / "inputs"
VERSION_RE = re.compile(r"(\d+)\.(\d+)\.(\d+)")       # always used with fullmatch ("0.4.0\n" is refused)


def _sha(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _item(status: str, why: str = "", **kw) -> dict:
    assert status in STATUS
    return {"status": status, "why": why, **kw}


# ================================================================================================ (a) preflight

def find_staged_build(data_dir: str | Path) -> Path | None:
    """The newest build folder under data/market_history/builds/ that holds a prices.csv (vintage ids sort by time)."""
    from ..ingestion.market_history import PRICES_NAME, VINTAGE_ID_RE
    root = Path(data_dir) / "market_history" / "builds"
    if not root.is_dir():
        return None
    ids = sorted(p for p in root.iterdir() if p.is_dir() and VINTAGE_ID_RE.fullmatch(p.name) and (p / PRICES_NAME).is_file())
    return ids[-1] if ids else None


def check_staged_build(path: str | Path, as_of: str) -> dict:
    """Read a staged build (its folder, or its prices.csv) and say whether the FX-only rerun can use it.

    `ok` False (with `why`) when: the file is missing; the sidecar's sha256 does not match prices.csv; a legacy ETF
    column is in it; a contract FX column is missing; no row on or before as_of. `label` is "official" for a Team A
    build with a matching sidecar, PROXY when the sidecar says so (`label` PROXY, as the test fixtures and the dry run
    do) or when there is no sidecar."""
    from ..ingestion.market_history import LEGACY_ETF_COLUMNS, PRICE_FX_COLUMNS, PRICES_NAME, SCHEMA, SIDECAR_NAME
    p = Path(path)
    prices = p / PRICES_NAME if p.is_dir() else p
    side_path = prices.with_name(SIDECAR_NAME)
    out = {"path": str(prices), "build": str(prices.parent), "vintage": None, "label": PROXY_TAG, "sidecar": None}
    if not prices.is_file():
        return {**out, "ok": False, "why": f"no prices.csv at {prices}"}
    sha = _sha(prices)
    out["sha256"] = sha
    side = None
    if side_path.is_file():
        try:
            side = json.loads(side_path.read_text())
        except ValueError:
            return {**out, "ok": False, "why": f"{side_path} is not JSON"}
        if not isinstance(side, dict):
            return {**out, "ok": False, "why": f"{side_path} is not a JSON object (got {type(side).__name__})"}
        out["sidecar"] = str(side_path)
        if side.get("sha256") != sha:
            return {**out, "ok": False, "why": f"sha256 of {prices.name} does not match {side_path.name} (build changed after it was made)"}
        out["vintage"] = side.get("vintage_id")
        lab = str(side.get("label", "")).upper()
        if lab in (PROXY_TAG, SYNTHETIC_TAG):
            out["label"] = PROXY_TAG
        elif side.get("schema") == SCHEMA:
            out["label"] = "official"
        out["unserved"] = list(side.get("unserved") or [])
        out["disagreement_rows"] = (side.get("disagreements") or {}).get("rows")
        out["failures"] = list(side.get("failures") or [])
    px = pd.read_csv(prices, parse_dates=["date"], index_col="date")
    etf = [c for c in px.columns if c in LEGACY_ETF_COLUMNS]
    if etf:
        return {**out, "ok": False, "why": f"ETF columns {etf} in the staged build (not an FX-only build)"}
    missing = [c for c in PRICE_FX_COLUMNS if c not in px.columns]
    if missing:
        return {**out, "ok": False, "why": f"contract FX columns missing: {missing}"}
    cut = px[px.index <= pd.Timestamp(as_of)]
    if cut.empty:
        return {**out, "ok": False, "why": f"no price row on or before as_of {as_of}"}
    empty = [c for c in PRICE_FX_COLUMNS if cut[c].isna().all()]
    out.update(ok=True, why="", rows=int(len(px)), rows_to_as_of=int(len(cut)), first=str(px.index.min().date()),
               last=str(px.index.max().date()), empty_columns=empty,
               nan_share=round(float(cut[list(PRICE_FX_COLUMNS)].isna().to_numpy().mean()), 4))
    return out


def preflight(data_dir: str | Path, as_of: str, panel_dir: str | Path | None = None,
              staged_build: str | Path | None = None) -> dict:
    """What has landed. Each row: present (bool), detail, and the step it gates (or "reported" when no step needs it)."""
    from ..ingestion.market_history import LEGACY_ETF_COLUMNS, _header, _is_official_prices
    d = Path(data_dir)
    panel = Path(panel_dir) if panel_dir else d / "panel"
    rows: dict[str, dict] = {}
    weo = panel / "weo_history.csv"
    has_vint = False
    if weo.is_file():
        has_vint = "vintage" in _header(weo)
    rows["panel_weo_history"] = {"present": weo.is_file(), "path": str(weo), "gates": "b",
                                 "detail": ("vintaged" if has_vint else "no vintage column: the refit will fail preflight")
                                 if weo.is_file() else "missing: A-full-panel-fetch.md steps 0-2b"}
    crag = panel / "sovereign_defaults_crag.csv"
    rows["panel_crag_episodes"] = {"present": crag.is_file(), "path": str(crag), "gates": "reported",
                                   "detail": "present" if crag.is_file() else "missing: A-full-panel-fetch.md step 3 (CRAG import)"}
    # EQ-B-0087: the refit's default events follow layer1.refit_events (absent: the current list)
    from . import hazard_events as he
    try:
        rule = he.resolve(d)
        ev = panel / he.FILES[rule["source"]]
        rows["panel_default_events"] = {"present": ev.is_file(), "path": str(ev), "gates": "b", "source": rule["source"],
                                        "rule": {k: rule[k] for k in he.PLAIN_RULE},
                                        "detail": (f"{rule['source']} ({rule['from']}): present" if ev.is_file()
                                                   else f"{rule['source']} ({rule['from']}): missing {ev.name}")}
    except he.EventRuleError as e:
        rows["panel_default_events"] = {"present": False, "path": "", "gates": "b", "source": None,
                                        "detail": f"layer1.refit_events refused: {e}"}
    sb = Path(staged_build) if staged_build else find_staged_build(d)
    if sb is None:
        rows["staged_fx_build"] = {"present": False, "path": str(d / "market_history" / "builds"), "gates": "c, d",
                                   "detail": "no build: python -m econquest.ingestion.market_history build (pull pack step 1b)"}
    else:
        b = check_staged_build(sb, as_of)
        rows["staged_fx_build"] = {"present": bool(b["ok"]), "path": b["path"], "gates": "c, d", "build": b,
                                   "detail": (f"{b['label']}, {b.get('rows')} rows {b.get('first')} to {b.get('last')}, "
                                              f"vintage {b.get('vintage') or 'n/a'}"
                                              + (f", empty: {', '.join(b['empty_columns'])}" if b.get("empty_columns") else ""))
                                   if b["ok"] else f"not usable: {b['why']}"}
    mh = d / "market_history"
    cur = mh / "prices.csv"
    official = _is_official_prices(mh) if cur.is_file() else False
    etf = [c for c in _header(cur) if c in LEGACY_ETF_COLUMNS] if cur.is_file() else []
    rows["current_prices"] = {"present": cur.is_file(), "path": str(cur), "gates": "c (comparison)",
                              "detail": ("official build already applied" if official else
                                         f"GOOGLEFINANCE era ({len(etf)} ETF columns)") if cur.is_file() else "missing"}
    try:
        from ..ingestion.events.base import list_event_vintages
        for src in ("ucdp", "gdelt"):
            v = list_event_vintages(d, src)
            rows[f"events_{src}"] = {"present": bool(v), "path": str(d / "live" / "events" / src / "vintages"), "gates": "reported",
                                     "detail": f"{len(v)} vintage(s), latest {v[-1]}" if v else "no vintage: A-event-feeds.md"}
    except Exception as e:  # noqa: BLE001 - reported, never fatal
        rows["events"] = {"present": False, "path": str(d / "live" / "events"), "gates": "reported", "detail": f"unreadable: {e}"}
    el = d / "live" / "events" / "events_long.csv"
    rows["events_long"] = {"present": el.is_file(), "path": str(el), "gates": "reported",
                           "detail": "present" if el.is_file() else "not exported yet (events.export.write_event_exports)"}
    nc = d / "live" / "nowcast_inputs.csv"
    n = None
    if nc.is_file():
        try:
            n = len(pd.read_csv(nc))
        except Exception:  # noqa: BLE001
            n = None
    rows["nowcast_inputs"] = {"present": nc.is_file(), "path": str(nc), "gates": "reported",
                              "detail": f"{n} rows" if n is not None else ("unreadable" if nc.is_file() else "missing: nowcast_feed pull")}
    return rows


# ================================================================================================ (b) hazard refit

@fit_cache_off()
def run_hazard_item(data_dir: str | Path, as_of: str, out: Path, pre: dict, *, panel_dir=None, effect_paths: int = 20000,
                    author: str = "<YOUR NAME>") -> dict:
    """hazard_refit.run_refit on the landed panel. Skipped when the WEO history or the default-event file is missing.

    The events follow layer1.refit_events in data_dir/assumptions.json (hazard_events.resolve; absent: the current
    list, EQ-B-0087), read from the panel folder that preflight checked."""
    from . import hazard_events as he
    from . import hazard_refit as hr
    miss = [k for k in ("panel_weo_history", "panel_default_events") if not pre[k]["present"]]
    if miss:
        return _item("SKIPPED", "; ".join(f"{k}: {pre[k]['detail']}" for k in miss))
    ev = pre["panel_default_events"]
    raw = Path(ev["path"]).parent / he.CRAG_RAW if ev["source"] == "crag" else None
    try:
        r = hr.run_refit(data_dir, as_of, out / "hazard-refit", defaults=ev["path"], events_source=ev["source"],
                         crag_raw=raw, weo_history=pre["panel_weo_history"]["path"], effect_paths=effect_paths,
                         effect_data_dir=data_dir, author=author)
    except (hr.RefitInputError, FileNotFoundError, ValueError) as e:
        return _item("FAILED", f"input error: {e}", outcome="INPUT_ERROR")
    rt = r.get("runtime") or {}
    return _item("RAN", outcome=r["outcome"], exit_code=r["exit_code"], synthetic=r["synthetic"],
                 gate_summary=r["gate_summary"], gate=r["gate"],
                 preflight_failures=[k for k, c in r["preflight"].items() if not c["pass"]],
                 panel=r["panel"], runtime_ready=rt.get("ready"), fitted_fallback=rt.get("fitted_fallback"),
                 metrics=rt.get("metrics"), runtime_error=rt.get("error"),
                 proposal={k: {"command": v["command"], "validated": v["validated"]} for k, v in (r.get("proposal") or {}).items()},
                 files=r["files"], dir=str(out / "hazard-refit"))


# ================================================================================================ (c) FX-only rerun

def staged_data_copy(data_dir: str | Path, staged_prices: str | Path, dest: str | Path) -> Path:
    """Copy data_dir to dest/data with market_history as `market_history apply` leaves it: the staged prices.csv
    (and its sidecar) only. The GOOGLEFINANCE files (prices.csv, inda.csv, archive/, repairs/) are not copied, and the
    builds/ and vintages/ folders are not needed. Returns the copy's path; data_dir is only read."""
    from ..ingestion.market_history import PRICES_NAME, SIDECAR_NAME
    src, out = Path(data_dir), Path(dest) / "data"
    shutil.copytree(src, out, ignore=lambda d, names: ["market_history"] if Path(d) == src else [])
    mh = out / "market_history"
    mh.mkdir()
    sp = Path(staged_prices)
    shutil.copyfile(sp, mh / PRICES_NAME)
    if (sp.parent / SIDECAR_NAME).is_file():
        shutil.copyfile(sp.parent / SIDECAR_NAME, mh / SIDECAR_NAME)
    return out


def _batches(n: int) -> int:
    """The batch count mc_error uses for n paths (VF-004)."""
    from ..engine.layer6_montecarlo import MC_ERROR_BATCHES, MC_ERROR_MIN_BATCH
    k = max(2, int(MC_ERROR_BATCHES))
    k = 1 << (k.bit_length() - 1)
    while k > 2 and n // k < MC_ERROR_MIN_BATCH:
        k //= 2
    return k


def paired_se(base: np.ndarray, new: np.ndarray, alpha: float = 0.99) -> dict:
    """Batch-means SE of the change in VaR99 and ES99 between two runs on the same random numbers (the cut of
    mc_error; as garch_backtests.paired_se). NaN when the loss vectors differ in length."""
    base, new = np.asarray(base, dtype=float), np.asarray(new, dtype=float)
    if len(base) != len(new) or len(base) < 4:
        return {"var99_mm": float("nan"), "es99_mm": float("nan")}
    k = _batches(len(base)); b = len(base) // k

    def est(x):
        blk = x[:k * b].reshape(k, b)
        v = np.quantile(blk, alpha, axis=1)
        return v, np.array([r[r >= q].mean() for r, q in zip(blk, v)])
    vb, eb = est(base); vn, en = est(new)
    return {"var99_mm": float(np.std(vn - vb, ddof=1) / np.sqrt(k)), "es99_mm": float(np.std(en - eb, ddof=1) / np.sqrt(k))}


def _metrics(r) -> dict:
    m = r.metrics
    out = {k: float(m[k]) for k in (*METRICS, "var99_se_mm", "es99_se_mm") if k in m}
    out["paths"] = int(m.get("paths", len(r.mc.losses)))
    return out


@fit_cache_off()
def fx_only_effect(data_dir: str | Path, staged_prices: str | Path, as_of: str, paths: int = 100_000,
                   scenarios=TEN_SCENARIOS, log=print) -> dict:
    """Base and stress runs on today's data and on a temporary copy with the staged prices, paired run by run.
    Returns {"base": row, "stress": {key: row}, "unavailable": {key: why}}; a row holds `today`, `staged` (metrics with
    SEs), `paired_se` and the 0.3.0 reference."""
    from ..config import Settings
    from ..engine.pipeline import run_pipeline
    from ..engine.stress import UNAVAILABLE, load_scenarios
    from ..ingestion import load_universe
    rows: dict = {"stress": {}, "unavailable": {}}
    with tempfile.TemporaryDirectory(prefix="eq-b-0079-fx-") as td:
        cp = staged_data_copy(data_dir, staged_prices, td)
        u0, u1 = load_universe(data_dir), load_universe(cp)
        s0 = Settings.load(Path(data_dir) / "assumptions.json").copy_with(as_of=as_of)
        s1 = Settings.load(cp / "assumptions.json").copy_with(as_of=as_of)
        sc0 = load_scenarios(Path(data_dir) / "scenarios.json")
        un0 = dict(UNAVAILABLE)
        sc1 = load_scenarios(cp / "scenarios.json")
        for key in (None, *scenarios):
            if key is not None and (key not in sc0 or key not in sc1):
                rows["unavailable"][key] = un0.get(key) or UNAVAILABLE.get(key) or "not in scenarios.json"
                continue
            t = time.perf_counter()
            with warnings.catch_warnings(record=True) as w:
                warnings.simplefilter("always")
                ua, sa = sc0[key].apply(u0, s0) if key else (u0, s0)
                ub, sb = sc1[key].apply(u1, s1) if key else (u1, s1)
                ra = run_pipeline(ua, sa, label=f"activation-today-{key or 'base'}", paths=paths, as_of=as_of)
                rb = run_pipeline(ub, sb, label=f"activation-staged-{key or 'base'}", paths=paths, as_of=as_of)
            row = {"today": _metrics(ra), "staged": _metrics(rb), "paired_se": paired_se(ra.mc.losses, rb.mc.losses),
                   "warnings": sorted({str(x.message)[:200] for x in w if "EQ-B-0077" in str(x.message)})[:6]}
            if key is None:
                row["reference"] = dict(REFERENCE_BASE)
                pos = rb.positions
                row["equity_legs_on_judgement"] = int(((pos["asset_class"] == "Equity")
                                                       & pos["vol_from"].astype(str).str.startswith("regime (")).sum())
                rows["base"] = row
            else:
                row["reference"] = {"es99_mm": REFERENCE_STRESS_ES99.get(key)}
                row["name"] = sc0[key].name
                rows["stress"][key] = row
            log(f"  {key or 'base'}: ES99 today {row['today']['es99_mm']:.2f} staged {row['staged']['es99_mm']:.2f} "
                f"({time.perf_counter() - t:.1f} s)")
    return rows


def run_fx_item(data_dir, as_of: str, out: Path, pre: dict, paths: int = 100_000, scenarios=TEN_SCENARIOS, log=print) -> dict:
    sb = pre["staged_fx_build"]
    if not sb["present"]:
        return _item("SKIPPED", f"staged FX build: {sb['detail']}")
    b = sb["build"]
    res = fx_only_effect(data_dir, b["path"], as_of, paths=paths, scenarios=scenarios, log=log)
    d = out / "fx-only"
    d.mkdir(parents=True, exist_ok=True)
    (d / "fx-only-effect.json").write_text(json.dumps(res, indent=1, default=float))
    _fx_rows(res).to_csv(d / "fx-only-effect.csv", index=False, float_format="%.6g")
    return _item("RAN", label=b["label"], build=b, paths=paths, result=res, dir=str(d))


def _fx_rows(res: dict) -> pd.DataFrame:
    rows = []
    for key, r in [("base", res.get("base"))] + list(res["stress"].items()):
        if not r:
            continue
        for m in METRICS if key == "base" else ("es99_mm",):
            ref = r["reference"].get(m)
            rows.append({"run": key, "metric": METRICS[m], "reference_030": ref, "today": r["today"][m],
                         "staged": r["staged"][m], "staged_se": r["staged"].get(m.replace("_mm", "_se_mm")) if m in ("var99_mm", "es99_mm") else None,
                         "change": r["staged"][m] - r["today"][m], "paired_se": r["paired_se"].get(m),
                         "change_pct_vs_today": (r["staged"][m] / r["today"][m] - 1) * 100 if r["today"][m] else None,
                         "change_pct_vs_030": (r["staged"][m] / ref - 1) * 100 if ref else None})
    return pd.DataFrame(rows)


# ================================================================================================ (d) GARCH rerun

def pooled_backtests(bt: pd.DataFrame) -> pd.DataFrame:
    """The pooled table of dossier section 2, from a garch-tier1-backtests.csv frame."""
    from scipy.stats import binomtest
    if bt is None or bt.empty:
        return pd.DataFrame()
    adm = bt["administered"].astype(str).str.lower().eq("true")
    mc = bt["mc_leg"].astype(str).str.lower().eq("true")
    sets = {"MC legs": mc, "FX MC legs": mc & bt["kind"].eq("FX"), "FX, not administered": bt["kind"].eq("FX") & ~adm,
            "All except administered": ~adm, "All series": pd.Series(True, index=bt.index)}
    rows = []
    for name, m in sets.items():
        x = bt[m]
        if x.empty:
            rows.append({"set": name, "tails": 0}); continue
        n, e, ew = int(x["garch_n"].sum()), int(x["garch_exceedances"].sum()), int(x["ewma_exceedances"].sum())
        z = x["garch_zone"].value_counts()
        ez = x["ewma_zone"].value_counts()
        rows.append({"set": name, "tails": int(len(x)), "series": int(x["ticker"].nunique()), "test_days": n,
                     "garch_exc": e, "garch_rate_pct": 100 * e / n, "expected": round(0.01 * n, 1),
                     "binom_p": float(binomtest(e, n, 0.01).pvalue) if n else float("nan"),
                     "zones_gyr": f"{z.get('Green', 0)} / {z.get('Yellow', 0)} / {z.get('Red', 0)}",
                     "kupiec_rejects": int((x["garch_kupiec_p"] < 0.05).sum()),
                     "ewma_exc": ew, "ewma_rate_pct": 100 * ew / n,
                     "ewma_zones_gyr": f"{ez.get('Green', 0)} / {ez.get('Yellow', 0)} / {ez.get('Red', 0)}",
                     "h21_median_mean_z2": float(x.drop_duplicates("ticker")["h21_mean_z2"].median())})
    return pd.DataFrame(rows)


@fit_cache_off()
def garch_rerun(data_copy: Path, as_of: str, out: Path, stability: bool = True, log=print) -> dict:
    """Dossier parts backtest (and stability) on the staged history, written to out/garch/."""
    from ..config import Settings
    from ..ingestion import load_universe
    from . import garch_dossier as GD                   # package code, not the docs/ script (EQ-B-0079 finding 4)
    d = out / "garch"
    d.mkdir(parents=True, exist_ok=True)
    u = load_universe(data_copy)
    s = Settings.load(data_copy / "assumptions.json")
    with warnings.catch_warnings():
        warnings.simplefilter("ignore")
        rets = GD.returns_table(u, as_of)
        if rets.index.max() > pd.Timestamp(as_of):
            raise AssertionError("look-ahead: returns after as_of")
        used = GD.mc_legs(u, s, as_of)
        t = time.perf_counter()
        bt = GD.part_backtest(u, rets, used)
        log(f"  GARCH backtest: {len(bt)} tails ({time.perf_counter() - t:.0f} s)")
        bt.to_csv(d / "garch-tier1-backtests.csv", index=False, float_format="%.6g")
        st = dcc = None
        if stability:
            t = time.perf_counter()
            st, dcc = GD.part_stability(u, rets, used)
            st.to_csv(d / "garch-tier1-stability.csv", index=False, float_format="%.6g")
            dcc.to_csv(d / "garch-tier1-dcc.csv", index=False, float_format="%.6g")
            log(f"  GARCH stability: {len(st)} rows ({time.perf_counter() - t:.0f} s)")
    return {"backtests": bt, "stability": st, "dcc": dcc, "mc_legs": sorted(used), "dir": str(d)}


def _read_ref(name: str) -> pd.DataFrame | None:
    p = GARCH_REFERENCE[name]
    return pd.read_csv(p) if p.is_file() else None


def garch_comparison(new: dict) -> dict:
    """Effect tables: pooled (today's dossier CSV against the rerun), per FX MC leg, stability ranges, FX DCC."""
    ref = _read_ref("backtests")
    pool_new, pool_ref = pooled_backtests(new["backtests"]), pooled_backtests(ref)
    legs = []
    bt = new["backtests"]
    fx_mc = sorted(set(bt.loc[bt["mc_leg"].astype(bool) & bt["kind"].eq("FX"), "ticker"])) if len(bt) else []
    for t in fx_mc:
        r = {"ticker": t}
        for tag, df in (("today", ref), ("staged", bt)):
            if df is None or t not in set(df["ticker"]):
                continue
            x = df[df["ticker"] == t].set_index("side")
            for side in ("long", "short"):
                if side in x.index:
                    r[f"{tag}_{side}"] = f"{int(x.at[side, 'garch_exceedances'])} / {float(x.at[side, 'garch_kupiec_p']):.2f} / {x.at[side, 'garch_zone']}"
        legs.append(r)
    stab = []
    st_ref, st = _read_ref("stability"), new.get("stability")
    if st is not None and len(st):
        for t in fx_mc:
            r = {"ticker": t}
            for tag, df in (("today", st_ref), ("staged", st)):
                if df is None or t not in set(df["ticker"]):
                    continue
                x = df[df["ticker"] == t]
                r[f"{tag}_persistence"] = f"{x['persistence'].min():.2f} to {x['persistence'].max():.3f}"
                r[f"{tag}_vol12m"] = f"{x['mc_vol_12m_pct'].min():.1f} to {x['mc_vol_12m_pct'].max():.1f}"
                r[f"{tag}_ge_0995"] = int((x["persistence"] >= 0.995).sum())
            stab.append(r)
    dcc = []
    dref, dnew = _read_ref("dcc"), new.get("dcc")
    for tag, df in (("today", dref), ("staged", dnew)):
        if df is not None and len(df):
            x = df[df["block"] == "FX"]
            if len(x):
                dcc.append({"prices": tag, "windows": int(len(x)), "a": f"{x['a'].min():.3f} to {x['a'].max():.3f}",
                            "b": f"{x['b'].min():.2f} to {x['b'].max():.2f}",
                            "avg_corr_next": f"{x['avg_corr_next'].min():.3f} to {x['avg_corr_next'].max():.3f}"})
    return {"pooled_today": pool_ref, "pooled_staged": pool_new, "fx_mc_legs": pd.DataFrame(legs),
            "stability": pd.DataFrame(stab), "dcc_fx": pd.DataFrame(dcc), "reference_found": ref is not None}


def run_garch_item(data_dir, as_of: str, out: Path, pre: dict, stability: bool = True, log=print) -> dict:
    sb = pre["staged_fx_build"]
    if not sb["present"]:
        return _item("SKIPPED", f"staged FX build: {sb['detail']}")
    b = sb["build"]
    with tempfile.TemporaryDirectory(prefix="eq-b-0079-garch-") as td:
        cp = staged_data_copy(data_dir, b["path"], td)
        new = garch_rerun(cp, as_of, out, stability=stability, log=log)
    cmp_ = garch_comparison(new)
    d = Path(new["dir"])
    for k in ("pooled_today", "pooled_staged", "fx_mc_legs", "stability", "dcc_fx"):
        cmp_[k].to_csv(d / f"compare-{k.replace('_', '-')}.csv", index=False, float_format="%.6g")
    return _item("RAN", label=b["label"], mc_legs=new["mc_legs"], comparison=cmp_, dir=str(d), stability=stability)


# ================================================================================================ frozen prices

def next_release_version(inputs_root: str | Path | None = None) -> str:
    """The next minor version after the highest X.Y.Z folder under docs/governance/releases/inputs/ (0.3.0 -> 0.4.0):
    applying the official FX build is a Tier 1 model change and restates the base."""
    inputs_root = RELEASE_INPUTS if inputs_root is None else inputs_root
    vs = [tuple(map(int, m.groups())) for p in Path(inputs_root).iterdir() if p.is_dir() and (m := VERSION_RE.fullmatch(p.name))]
    if not vs:
        return "0.1.0"
    a, b, _ = max(vs)
    return f"{a}.{b + 1}.0"


def freeze_official_prices(official_prices: str | Path, inputs_root: str | Path | None = None,
                           version: str | None = None) -> dict:
    """Frozen-price step for the FX-only replication checks (fx-only-prices.md section 7 step 4).

    Copies the official prices.csv byte for byte to <inputs_root>/<version>/prices.csv (version: `version`, else
    next_release_version; it must be exactly X.Y.Z). Refuses (ValueError, nothing written) when: the file has an ETF
    column or misses a contract FX column; there is no prices.provenance.json next to it, or it is not JSON, or its
    schema or sha256 does not match, or it is labelled PROXY or SYNTHETIC (as check_staged_build); the target already
    exists. The sidecar is copied too. Returns path, version and sha256 (the full hash and the 16-digit
    form RELEASE-HASHES.json uses). Not called by the activation pack: Sam runs it after `apply`."""
    from ..ingestion.market_history import LEGACY_ETF_COLUMNS, PRICE_FX_COLUMNS, SCHEMA, SIDECAR_NAME, _header
    src = Path(official_prices)
    if not src.is_file():
        raise ValueError(f"no file {src}")
    head = _header(src)
    etf = [c for c in head if c in LEGACY_ETF_COLUMNS]
    if etf:
        raise ValueError(f"{src} has ETF columns {etf}: not the official FX-only file")
    miss = [c for c in PRICE_FX_COLUMNS if c not in head]
    if miss:
        raise ValueError(f"{src} misses contract FX columns {miss}")
    sha = _sha(src)
    side = src.with_name(SIDECAR_NAME)
    if not side.is_file():
        raise ValueError(f"no {SIDECAR_NAME} next to {src}: only a Team A official build (with its sidecar) is frozen")
    try:
        meta = json.loads(side.read_text())
    except ValueError:
        raise ValueError(f"{side} is not JSON") from None
    if not isinstance(meta, dict) or meta.get("schema") != SCHEMA or meta.get("sha256") != sha:
        raise ValueError(f"{side} does not describe {src} (schema or sha256 differs)")
    lab = str(meta.get("label", "")).upper()
    if lab in (PROXY_TAG, SYNTHETIC_TAG):
        raise ValueError(f"{side} is labelled {lab}: not an official build, never frozen as release input")
    inputs_root = RELEASE_INPUTS if inputs_root is None else inputs_root   # read at call time, so tests can patch it
    version = version or next_release_version(inputs_root)
    if not isinstance(version, str) or not VERSION_RE.fullmatch(version):
        raise ValueError(f"version {version!r} is not X.Y.Z")
    dest = Path(inputs_root) / version / "prices.csv"
    if dest.exists():
        raise ValueError(f"{dest} exists; frozen inputs are never overwritten")
    dest.parent.mkdir(parents=True, exist_ok=True)
    shutil.copyfile(src, dest)
    if _sha(dest) != sha:
        dest.unlink()
        raise ValueError("copy does not match the source sha256")
    out = {"path": str(dest), "version": version, "sha256": sha, "sha256_16": sha[:16], "source": str(src),
           "vintage": meta.get("vintage_id")}
    shutil.copyfile(side, dest.with_name(SIDECAR_NAME))
    out["provenance"] = str(dest.with_name(SIDECAR_NAME))
    return out


# ================================================================================================ (e) decision note

def _f(v, nd=2, pct=False):
    if v is None or (isinstance(v, float) and not np.isfinite(v)):
        return ""
    return f"{v:+.1f}%" if pct else f"{v:.{nd}f}"


def _md_table(df: pd.DataFrame, cols: dict) -> list[str]:
    if df is None or df.empty:
        return ["(no rows)"]
    L = ["| " + " | ".join(cols.values()) + " |", "|" + "---|" * len(cols)]
    for r in df.to_dict(orient="records"):
        cells = []
        for c in cols:
            v = r.get(c)
            if isinstance(v, float):
                v = "" if not np.isfinite(v) else (f"{v:.3f}" if abs(v) < 10 else f"{v:,.1f}")
            cells.append("" if v is None else str(v))
        L.append("| " + " | ".join(cells) + " |")
    return L


def _sig(change, se):
    return "**" if se and np.isfinite(se) and abs(change) > 2 * se else ""


def render_note(r: dict) -> str:
    as_of, pre, items = r["as_of"], r["preflight"], r["items"]
    fx, hz, gc = items["c_fx_only"], items["b_hazard_refit"], items["d_garch"]
    labels = sorted({x.get("label") for x in (fx, gc) if x.get("label") == PROXY_TAG} | ({SYNTHETIC_TAG} if hz.get("synthetic") else set()))
    L = [f"# Activation decision note, as_of {as_of} ({TICKET})", ""]
    if labels:
        L += [f"> **{' and '.join(labels)} INPUTS.** " + (
            "The FX prices are a PROXY (not Team A's official build): the FX numbers test the chain, they are not the "
            "decision numbers. " if PROXY_TAG in labels else "") + (
            "The hazard panel is SYNTHETIC: invented economies; the refit numbers say nothing about the model." if SYNTHETIC_TAG in labels else ""), ""]
    L += [f"Generated by `python -m econquest.validation.activation --as-of {as_of}`. Nothing was proposed, approved or "
          "applied, and no file in data/ or docs/ changed. Three decisions follow, one effect table each. They are "
          "independent, with one interaction: the hazard effect table (item b) is on today's prices; if item c is "
          "applied first, rerun this pack before proposing item b.", "",
          "## Preflight: what has landed", "", "| Input | Present | Detail | Step |", "|---|---|---|---|"]
    for k, v in pre.items():
        L.append(f"| {k} | {'yes' if v['present'] else 'no'} | {v['detail']} | {v['gates']} |")
    L += ["", "| Step | Status | Why |", "|---|---|---|"]
    for k, v in items.items():
        L.append(f"| {k} | {v['status']}{' ' + v['outcome'] if v.get('outcome') else ''} | {v.get('why', '')} |")

    # ---- item c
    L += ["", "## Item c: apply Team A's official FX build (Tier 1 model change, fx-only-prices.md)", ""]
    if fx["status"] == "RAN":
        b, res = fx["build"], fx["result"]
        L += [f"Staged build: `{b['path']}` ({fx['label']}; sha256 {b['sha256'][:16]}; {b.get('rows')} rows to {b.get('last')}; "
              f"vintage {b.get('vintage') or 'n/a'}). Base and stress at {fx['paths']:,} requested paths "
              f"({res['base']['staged']['paths']:,} Sobol), as_of {as_of}, shipped settings, on a temporary data copy.", "",
              "Today = the same run on today's data (same random numbers). SE = the staged run's batch-means SE. Paired SE ="
              " the SE of the change (common random numbers). Bold change: more than 2 paired SE.", "",
              f"| Metric ($mm) | {REFERENCE_VERSION} release | Today | Staged FX-only | SE | Change vs today | Paired SE | % vs today | % vs {REFERENCE_VERSION} |",
              "|---|---|---|---|---|---|---|---|---|"]
        base = res["base"]
        for m, lab in METRICS.items():
            t, s_ = base["today"][m], base["staged"][m]
            se = base["staged"].get(m.replace("_mm", "_se_mm")) if m in ("var99_mm", "es99_mm") else (
                base["staged"].get("var99_se_mm") if m == "lvar99_mm" else None)
            pse = base["paired_se"].get(m if m != "lvar99_mm" else "var99_mm")
            pse = pse if m != "expected_loss_mm" else None
            ch = s_ - t
            sig = _sig(ch, pse)
            L.append(f"| {lab} | {_f(REFERENCE_BASE[m])} | {_f(t)} | {_f(s_)} | {_f(se)} | {sig}{ch:+.2f}{sig} | {_f(pse)} | "
                     f"{_f((s_ / t - 1) * 100, pct=True)} | {_f((s_ / REFERENCE_BASE[m] - 1) * 100, pct=True)} |")
        L += ["", f"Equity legs on the judgement vol after the switch: {base.get('equity_legs_on_judgement')}.", "",
              "Stress ES99 ($mm):", "",
              f"| Scenario | {REFERENCE_VERSION} release | Today | Staged | SE | Change vs today | Paired SE | Staged vs staged base |",
              "|---|---|---|---|---|---|---|---|"]
        for k, v in res["stress"].items():
            t, s_ = v["today"]["es99_mm"], v["staged"]["es99_mm"]
            ch, pse = s_ - t, v["paired_se"]["es99_mm"]
            sig = _sig(ch, pse)
            L.append(f"| {k} | {_f(v['reference']['es99_mm'], 1)} | {_f(t, 1)} | {_f(s_, 1)} | {_f(v['staged'].get('es99_se_mm'))} | "
                     f"{sig}{ch:+.1f}{sig} | {_f(pse)} | {_f((s_ / base['staged']['es99_mm'] - 1) * 100, pct=True)} |")
        for k, why in res["unavailable"].items():
            L.append(f"| {k} | | | not run: {why} | | | | |")
        vid = b.get("vintage") or "<vintage id>"
        L += ["", "Commands, after Sam signs fx-only-prices.md (Team B sets the handoff response first):", "", "```bash",
              f"python -m econquest.ingestion.market_history apply --vintage {vid}",
              "python -m econquest.ingestion.market_history restricted          # expect 0 files, exit 0",
              "python -m econquest.validation.replicate                         # older checks keep their frozen prices",
              "python -m econquest.validation.activation --freeze-official-prices data/market_history/prices.csv",
              "```", "", "The last command writes `docs/governance/releases/inputs/<next>/prices.csv` (the frozen copy for "
              "the FX-only replication checks Team B adds next). The next release note restates the base."]
    else:
        L += [f"{fx['status']}: {fx.get('why')}"]

    # ---- item b
    L += ["", "## Item b: hazard refit change pack (Tier 1, EQ-B-0067)", ""]
    if hz["status"] == "RAN":
        L += [f"Outcome: **{hz['outcome']}** (exit {hz['exit_code']}). Gate: {hz['gate_summary']}. "
              f"Panel: {hz['panel']['rows']:,} rows, {hz['panel']['events']} events, {hz['panel']['countries']} countries.",
              f"Fitted mode runs at as_of (VF-012): {hz.get('runtime_ready')}"
              + (f" ({hz['fitted_fallback']})" if hz.get("fitted_fallback") else "") + ".", ""]
        if hz.get("preflight_failures"):
            L += [f"Preflight failures: {', '.join(hz['preflight_failures'])}. See `{hz['files']['gate_report_md']}`.", ""]
        m = hz.get("metrics")
        L += ["| Measure ($mm) | Before (shipped) | After (this fit) | Change |", "|---|---|---|---|"]
        for k, lab in METRICS.items():
            if m and k in m["before"]:
                L.append(f"| {lab} ({m['paths']:,} paths) | {m['before'][k]:.2f} | {m['after'][k]:.2f} | {m['after'][k] - m['before'][k]:+.2f} |")
            else:
                L.append(f"| {lab} | | | {hz.get('runtime_error') or 'not run'} |")
        if hz.get("proposal"):
            L += ["", f"Change pack: `{hz['files'].get('change_proposal')}`. Commands (nothing is proposed yet; put your name "
                  "after --author):", "", "```bash"]
            for name, p in hz["proposal"].items():
                L += [f"# {name}: validated {p['validated'].get('ok')}, tier {p['validated'].get('tier')}", p["command"]]
            L += ["econquest change show <CHG-id>", "econquest change approve <CHG-id> --approver \"Sam\"",
                  "econquest change apply <CHG-id>", "```"]
            if hz.get("synthetic"):
                L += ["", "SYNTHETIC: do not run these commands; the pack only shows the shape."]
        else:
            L += ["", "No change pack (only written when the outcome is CLEARED). Read `gate-report.md` in "
                  f"`{hz.get('dir')}`; docs/validation/hazard-refit-runbook.md step 4 says what to do."]
    else:
        L += [f"{hz['status']}: {hz.get('why')}"]

    # ---- item d
    L += ["", "## Item d: FX GARCH 12-month marginals to Tier 1 (model-inventory edit, VF-001)", ""]
    if gc["status"] == "RAN":
        c = gc["comparison"]
        L += [f"Backtests rerun on the staged history ({gc['label']}): one-day VaR99 out of sample, expanding window from "
              "500 returns, refit every 21 (dossier garch-dcc-tier1.md section 2). Today = the GOOGLEFINANCE-era CSVs in "
              f"docs/validation/dossier/. Monte Carlo legs on the staged prices: {', '.join(gc['mc_legs']) or 'none'}.", ""]
        cols = {"set": "Set", "tails": "Tails", "test_days": "Test days", "garch_exc": "GARCH exc", "garch_rate_pct": "Rate %",
                "expected": "Expected", "binom_p": "Binomial p", "zones_gyr": "Zones G/Y/R", "kupiec_rejects": "Kupiec p<0.05",
                "ewma_rate_pct": "EWMA rate %"}
        for tag, k in (("Today (GOOGLEFINANCE, dossier)", "pooled_today"), ("Staged FX-only", "pooled_staged")):
            L += [f"{tag}:", ""] + _md_table(c[k], cols) + [""]
        L += ["FX Monte Carlo legs, exceedances / Kupiec p / zone:", ""]
        L += _md_table(c["fx_mc_legs"], {"ticker": "Series", "today_long": "Today long", "today_short": "Today short",
                                         "staged_long": "Staged long", "staged_short": "Staged short"}) + [""]
        if gc.get("stability") and len(c["stability"]):
            L += ["Rolling 500-return windows (persistence; 12-month vol %; windows at or above 0.995):", ""]
            L += _md_table(c["stability"], {"ticker": "Series", "today_persistence": "Today persistence",
                                            "staged_persistence": "Staged persistence", "today_vol12m": "Today vol",
                                            "staged_vol12m": "Staged vol", "today_ge_0995": "Today >=0.995",
                                            "staged_ge_0995": "Staged >=0.995"}) + [""]
            L += ["FX DCC:", ""] + _md_table(c["dcc_fx"], {"prices": "Prices", "windows": "Windows", "a": "a", "b": "b",
                                                            "avg_corr_next": "Avg corr next"}) + [""]
        st = c["pooled_staged"]
        fxmc = st[st["set"] == "FX MC legs"].to_dict(orient="records") if len(st) else []
        fxmc = fxmc[0] if fxmc else {}
        L += ["No settings change and no `econquest change propose`: tier is not a setting (dossier section 9). The "
              "decision is Sam's sign-off of these document edits, which Team B then makes:", "",
              "1. `docs/governance/model-inventory.md` summary row 10 -> rows 10a (Tier 1) and 10b (Tier 2), text in "
              "garch-dcc-tier1.md section 9, edit 1; drop \"pending official data\" once item c is applied.",
              "2. `model-inventory.md` section 10, last limitation bullet, with the official-data figures:", "", "```",
              "- Since 0.1.4 the 12-month marginals (10a) set the FX vols of the Monte Carlo and are Tier 1 (VF-001,",
              f"  EQ-B-0068, approved by Sam on <date>). Evidence on the official BIS/ECB FX history ({gc['label']}, as_of {as_of}):",
              f"  one-day VaR99 out of sample, {fxmc.get('tails', '?')} tails of the FX MC legs, zones G/Y/R {fxmc.get('zones_gyr', '?')},",
              f"  pooled exceedances {_f(fxmc.get('garch_rate_pct'))}% (EWMA {_f(fxmc.get('ewma_rate_pct'))}%). Equity legs on judgement",
              "  (market.equity_vol) since EQ-A-0054. Conditions: independent validation before external use; use",
              "  restrictions G1 to G5 in dossier/garch-dcc-tier1.md.", "```", "",
              "3. `model-risk-policy.md` section 2 and 6.10 (section 9, edit 3); 4. VF-001 proposed for closure (edit 4).", "",
              f"Reproduce: `python -m econquest.validation.activation --as-of {as_of} --only garch --staged-build "
              f"{Path(pre['staged_fx_build']['path']).parent}`; CSVs in `{gc['dir']}`."]
    else:
        L += [f"{gc['status']}: {gc.get('why')}"]
    return "\n".join(L) + "\n"


# ================================================================================================ the pass

ITEMS = ("hazard", "fx", "garch")


def resolve_out_dir(out_dir: str | Path | None, as_of: str, outputs_root: str | Path | None = None) -> Path:
    """The output folder, resolved (symlinks followed). Default <outputs_root>/activation/<as_of>. Refused
    (ValueError) unless it is strictly inside the resolved outputs_root (default <repo>/outputs): an absolute path
    elsewhere, a `..` that leaves it, data/, docs/ or a symlink out of it would otherwise be written over
    (EQ-B-0079 finding 1)."""
    root = Path(outputs_root if outputs_root is not None else OUTPUTS_ROOT).resolve()
    if out_dir is None or str(out_dir).strip() == "":
        return root / "activation" / as_of
    s = str(out_dir)
    if "\x00" in s:
        raise ValueError(f"--out {out_dir!r}: bad path")
    p = Path(s).expanduser()
    full = (p if p.is_absolute() else Path.cwd() / p).resolve()
    if full == root or not full.is_relative_to(root):
        raise ValueError(f"--out {out_dir!r} resolves to {full}, which is not a folder under {root}; "
                         f"the activation pack writes only under outputs/")
    return full


@fit_cache_off()
def run_activation(data_dir: str | Path, as_of: str, out_dir: str | Path | None = None, *, staged_build=None,
                   panel_dir=None, paths: int = 100_000, scenarios=TEN_SCENARIOS, effect_paths: int = 20000,
                   stability: bool = True, only=ITEMS, author: str = "<YOUR NAME>", log=print,
                   outputs_root: str | Path | None = None) -> dict:
    """(a) to (e) in order. The output folder must resolve under `outputs_root` (default <repo>/outputs; see
    resolve_out_dir; the CLI does not expose `outputs_root`). A missing input SKIPS its step; an error in one step is recorded as FAILED with the
    traceback tail and the other steps still run. Returns the dict written to <out>/activation.json."""
    as_of = pd.Timestamp(as_of).strftime("%Y-%m-%d")
    data = Path(data_dir)
    out = resolve_out_dir(out_dir, as_of, outputs_root)
    out.mkdir(parents=True, exist_ok=True)
    log(f"(a) preflight, as_of {as_of}")
    pre = preflight(data, as_of, panel_dir, staged_build)
    for k, v in pre.items():
        log(f"  {k}: {'yes' if v['present'] else 'no'} ({v['detail']})")
    items = {}
    steps = (("b_hazard_refit", "hazard", lambda: run_hazard_item(data, as_of, out, pre, panel_dir=panel_dir,
                                                                   effect_paths=effect_paths, author=author)),
             ("c_fx_only", "fx", lambda: run_fx_item(data, as_of, out, pre, paths=paths, scenarios=scenarios, log=log)),
             ("d_garch", "garch", lambda: run_garch_item(data, as_of, out, pre, stability=stability, log=log)))
    for key, name, fn in steps:
        log(f"({key[0]}) {key[2:]}")
        if name not in only:
            items[key] = _item("SKIPPED", "not selected (--only)")
        else:
            try:
                items[key] = fn()
            except Exception as e:  # noqa: BLE001 - one failed step must not stop the others
                items[key] = _item("FAILED", f"{type(e).__name__}: {str(e)[:300]}", traceback=traceback.format_exc()[-2000:])
        log(f"  {items[key]['status']}{' ' + items[key]['outcome'] if items[key].get('outcome') else ''}"
            f"{': ' + items[key]['why'] if items[key].get('why') else ''}")
    res = {"ticket": TICKET, "as_of": as_of, "out": str(out), "preflight": pre, "items": items}
    note = out / "decision-note.md"
    note.write_text(render_note(res))
    res["decision_note"] = str(note)
    res["exit_code"] = 1 if any(v["status"] == "FAILED" for v in items.values()) else 0
    (out / "activation.json").write_text(json.dumps(_jsonable(res), indent=1, default=str))
    log(f"(e) decision note: {note}")
    return res


def _jsonable(x):
    if isinstance(x, pd.DataFrame):
        return x.to_dict(orient="records")
    if isinstance(x, dict):
        return {k: _jsonable(v) for k, v in x.items()}
    if isinstance(x, (list, tuple)):
        return [_jsonable(v) for v in x]
    return x


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.validation.activation",
                                 description="Real-data activation pack (EQ-B-0079). Writes only under --out.")
    ap.add_argument("--as-of", help="model date YYYY-MM-DD (use the base run's, 2026-10-23 for 0.3.0)")
    ap.add_argument("--staged-build", help="staged FX build folder or its prices.csv (default: newest under data/market_history/builds/)")
    ap.add_argument("--out", help="output folder under outputs/ (default: outputs/activation/<as_of>); anything else is refused")
    ap.add_argument("--data", default="data")
    ap.add_argument("--panel", help="folder with weo_history.csv and sovereign_defaults_crag.csv (default: <data>/panel)")
    ap.add_argument("--paths", type=int, default=100_000, help="requested paths for the FX-only base and stress runs")
    ap.add_argument("--effect-paths", type=int, default=20000, help="paths for the hazard refit's before/after runs")
    ap.add_argument("--only", default=",".join(ITEMS), help="comma list of hazard, fx, garch (default: all)")
    ap.add_argument("--no-stability", action="store_true", help="skip the GARCH rolling-window stability part")
    ap.add_argument("--author", default="<YOUR NAME>", help="name put in the drafted propose commands (nothing is proposed)")
    ap.add_argument("--freeze-official-prices", metavar="PRICES_CSV",
                    help="only freeze this official prices.csv to docs/governance/releases/inputs/<next>/ and exit")
    ap.add_argument("--release", help="with --freeze-official-prices: the version folder (default: next minor)")
    a = ap.parse_args(argv)
    if a.freeze_official_prices:
        try:
            r = freeze_official_prices(a.freeze_official_prices, version=a.release)
        except ValueError as e:
            print(f"REFUSED: {e}", file=sys.stderr)
            return 2
        print(json.dumps(r, indent=1))
        return 0
    if not a.as_of:
        ap.error("--as-of is required")
    only = tuple(x.strip() for x in a.only.split(",") if x.strip())
    bad = [x for x in only if x not in ITEMS]
    if bad:
        ap.error(f"--only: unknown {bad}; use {ITEMS}")
    try:
        out = resolve_out_dir(a.out, pd.Timestamp(a.as_of).strftime("%Y-%m-%d"))
    except ValueError as e:
        print(f"REFUSED: {e}", file=sys.stderr)
        return 2
    r = run_activation(a.data, a.as_of, out, staged_build=a.staged_build, panel_dir=a.panel, paths=a.paths,
                       effect_paths=a.effect_paths, stability=not a.no_stability, only=only, author=a.author)
    print(f"exit {r['exit_code']}: " + ", ".join(f"{k} {v['status']}{' ' + v['outcome'] if v.get('outcome') else ''}"
                                                for k, v in r["items"].items()))
    return r["exit_code"]


if __name__ == "__main__":
    raise SystemExit(main())
