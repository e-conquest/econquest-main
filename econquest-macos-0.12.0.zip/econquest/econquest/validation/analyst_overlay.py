"""Analyst-judgement overlay (EQ-B-0138, PI-13): structured expert scores per country and pillar, shown NEXT TO the
model output, never in place of it. Method and limits: docs/validation/analyst-overlay.md. Wiring it into the risk
numbers is Tier 1 and parked: docs/governance/decisions/B-0138-overlay-tier1-card.md.

OFF BY DEFAULT. While off, nothing is read or written and every function below returns an empty, "off" answer: no
ledger file is created, the run dict is never touched, and the base numbers stay bit-identical (no engine, scorecard,
data/ or outputs/ file reads this module). The switch is `enabled=True` on each call, or the settings key
`research.analyst_overlay.enabled` (absent from data/assumptions.json, so off). Today it is switched on in tests and
in `demo_overlay` only, which runs in a sandbox under its out_dir.

Entry. One analyst score for one (country, pillar):
    notches   whole number in -2..+2, not 0. Positive = the analyst sees MORE risk than the model (pillar scores are
              risk scores, 0-100, higher is riskier). One notch = NOTCH_POINTS (2.5) pillar points.
    reason    free text, required (at least MIN_REASON characters), formula-neutralised before it is stored
    author    who scored it; approver: someone else (four-eyes)
    expires   a date after the entry date and at most MAX_DAYS (92, one revalidation quarter) later
Caps (documented in analyst-overlay.md section 3):
    per pillar   |delta| <= PILLAR_CAP_POINTS (5.0 points = 2 notches); the overlaid pillar is clamped to 0..100
    per country  GROSS sum over pillars of |weight x delta| <= COUNTRY_CAP_POINTS (2.0 composite points), so the
                 net composite delta is bounded too and offsetting +2/-2 entries cannot pile up; above it every
                 pillar delta of that country is scaled down by the same factor (capped "country")
    The existing in-model analyst adjustment (data/adjustments.csv "Analyst adjustment", scorecard.max_analyst_adj
    10) is a different, Team A attested input and is untouched; it is already inside the model value shown here.

Ledger: docs/validation/overlay-log.jsonl + overlay-head.json, the scheme of validation/findings.py and
ops/approvals.py: seq from 1, prev_hash = previous row_hash (64 zeros first), row_hash = sha256(prev_hash + canonical
row), canonical = the row without row_hash as JSON with sorted keys and no spaces. Append-only: events are add,
approve, withdraw. Unkeyed: `verify(expect_head=...)` against a head recorded outside the folder catches a rewrite.
No wall clock: every call takes as_of (YYYY-MM-DD) and an event dated before the last one is refused.

Four-eyes. approve() refuses an approver equal to the author (person_key or the stricter overlay_key:
punctuation, word order, bracketed suffixes and leading formula characters ignored), unless exc_id names an
EXC row of docs/governance/issues-log.md that names `overlay approve` in its text, starts on or before as_of and has
not expired (findings.exception_row, same rules as EXC-004 for `findings close`). No such row exists today, so a
self-approval is refused until Sam logs one (proposed text in the Tier 1 card). The row then records
self_approved "yes" and exc_id, and every view row shows them. With data/users.json four_eyes enforced
(ops.identity.enforced), the approver and the author must both be registered active users with different ids and
self-approval is refused outright: identity.SCOPES has no "overlay" scope yet (asked of Team C, EQ-B-0138 handoff).

Plain functions for Team C's pages (no presentation import here):
    overlay_rows(run, root, as_of, enabled=False)     -> list of OVERLAY_COLUMNS dicts (model, delta, overlaid apart)
    overlay_entries(root, as_of, enabled=False)       -> list of ENTRY_COLUMNS dicts (every entry and its status)
    overlay_audit(root, enabled=False)                -> list of AUDIT_COLUMNS dicts (every ledger event)
    build_overlay(run, root, as_of, enabled=False)    -> {"enabled", "schema", "rows", "entries", "audit", "verify", "info"}
    add_entry / approve_entry / withdraw_entry / verify
    demo_overlay(out_dir)                             -> {"ok", "problems", "paths", ...} (SYNTHETIC, sandboxed)
    python -m econquest.validation.analyst_overlay effect [--paths 20000]   (Tier 1 card table, temp data copy)
Every row is INTERNAL (audience "internal"); assert_internal refuses a client audience. Client mode stays off.
SYNTHETIC entries are written and read only in a marked sandbox (mark_sandbox: demo, effect) or under pytest, never
on the repo-root ledger; the views refuse a ledger that holds them anywhere else. It is not a caller option.
CLI and demo outputs go under outputs/ or outside the repo (resolve_out).
"""
from __future__ import annotations

import argparse
import contextlib
import csv
import datetime as dt
import hashlib
import io
import json
import os
import re
import tempfile
from pathlib import Path

from ..common_format import escape_formula
from ..config import PILLARS
from ..ingestion.ledger import clean_person, person_key

try:                                    # POSIX only; elsewhere appends are unlocked
    import fcntl
except ImportError:                     # pragma: no cover
    fcntl = None

TICKET = "EQ-B-0138"
SCHEMA = "eq-analyst-overlay/1"
LOG = "docs/validation/overlay-log.jsonl"
HEAD = "docs/validation/overlay-head.json"
ISSUES_LOG = "docs/governance/issues-log.md"
SETTING = ("research", "analyst_overlay", "enabled")
NOTCHES = (-2, -1, 1, 2)
NOTCH_POINTS = 2.5
PILLAR_CAP_POINTS = 5.0
COUNTRY_CAP_POINTS = 2.0
MAX_DAYS = 92
MIN_REASON = 20
MAX_TEXT = 2000
GENESIS = "0" * 64
EVENTS = ("add", "approve", "withdraw")
STATUSES = ("pending", "active", "expired", "withdrawn")
AUDIENCE = "internal"
LABEL = "INTERNAL analyst overlay: judgement shown beside the model, not model output"
SYNTHETIC = "SYNTHETIC"
EXC_SCOPE_RE = re.compile(r"\boverlay\s+approve\b", re.IGNORECASE)
DATE_RE = re.compile(r"\d{4}-\d{2}-\d{2}")
HEX64_RE = re.compile(r"[0-9a-f]{64}")
ENTRY_RE = re.compile(r"OVL-\d{4,}")
COUNTRY_RE = re.compile(r"[A-Za-z][A-Za-z .'-]{1,59}")
REPO_ROOT = Path(__file__).resolve().parents[2]
OUTPUTS_ROOT = REPO_ROOT / "outputs"
SANDBOX_MARK = ".overlay-sandbox"         # file whose first line is SANDBOX_TEXT marks a demo/effect sandbox root
SANDBOX_TEXT = "SYNTHETIC analyst-overlay sandbox (EQ-B-0138); never a real ledger"
_FORMULA_LEAD = "=+-@'\"\t\r "
_SUFFIX_RE = re.compile(r"\s*[(\[{<][^()\[\]{}<>]*[)\]}>]\s*$")
OFF_INFO = "analyst overlay is off (default): nothing read or written; the model output is unchanged"

OVERLAY_COLUMNS = ("country", "row", "pillar", "pillar_name", "model_value", "overlay_notches", "overlay_delta",
                   "overlaid_value", "cap", "entry_id", "author", "approver", "approved_on", "self_approved", "exc_id",
                   "reason", "entered_on", "expires", "synthetic", "as_of", "run_id", "data_hash", "audience", "label")
ENTRY_COLUMNS = ("entry_id", "country", "pillar", "pillar_name", "notches", "delta_points", "reason", "author",
                 "entered_on", "expires", "status", "approver", "approved_on", "self_approved", "exc_id",
                 "withdrawn_on", "withdrawn_by", "synthetic")
AUDIT_COLUMNS = ("seq", "as_of", "event", "entry_id", "actor", "detail", "prev_hash", "row_hash")


class OverlayError(ValueError):
    """A refused add/approve/withdraw, a bad date or a broken ledger."""


# ---------------------------------------------------------------- switch and small helpers

def overlay_enabled(enabled=None, settings=None) -> bool:
    """True only when the caller passes enabled=True, or (enabled None) the settings key research.analyst_overlay.enabled
    is exactly True. Absent everywhere today, so off."""
    if enabled is not None:
        return enabled is True
    if settings is None:
        return False
    get = getattr(settings, "get", None)
    v = get(*SETTING, default=False) if callable(get) and hasattr(settings, "raw") else _dig(settings, SETTING)
    return v is True


def _dig(d, keys):
    for k in keys:
        if not isinstance(d, dict) or k not in d:
            return False
        d = d[k]
    return d


def _date(s, what="as_of") -> dt.date:
    if isinstance(s, dt.date) and not isinstance(s, dt.datetime):
        return s
    t = str(s or "").strip()
    if not DATE_RE.fullmatch(t):
        raise OverlayError(f"{what} must be a date YYYY-MM-DD, got {s!r}")
    try:
        return dt.date.fromisoformat(t)
    except ValueError:
        raise OverlayError(f"{what} is not a valid date: {s!r}") from None


def _text(value, what="text") -> str:
    s = " ".join(str("" if value is None else value).split())
    if len(s) > MAX_TEXT:
        raise OverlayError(f"{what} longer than {MAX_TEXT} characters")
    return escape_formula(s)


def _sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def canonical(row: dict) -> str:
    return json.dumps({k: v for k, v in row.items() if k != "row_hash"}, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False)


def row_hash(prev_hash: str, row: dict) -> str:
    return _sha((prev_hash + canonical(row)).encode("utf-8"))


def _atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


@contextlib.contextmanager
def _locked(root):
    p = Path(root) / LOG
    p.parent.mkdir(parents=True, exist_ok=True)
    with open(p, "a", encoding="utf-8") as f:
        if fcntl is not None:
            fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            if fcntl is not None:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)


def overlay_key(name) -> str:
    """Stricter comparison key than ingestion.ledger.person_key for overlay four-eyes (AGENT-06 review M1): formula
    and quote characters in front dropped, trailing bracketed suffixes dropped ("Alice Smith (desk)"), person_key
    (NFKC, case, look-alike letters), then letters and digits only, split into tokens and sorted. So "alice.smith",
    "alice-smith", "Smith, Alice", "Alice Smith (desk)" and "=Alice Smith" all equal "Alice Smith". Initials are a
    judgement left open: "A. Smith" does NOT match "Alice Smith" (analyst-overlay.md section 4)."""
    s = clean_person(name).lstrip(_FORMULA_LEAD)
    prev = None
    while prev != s:
        prev, s = s, _SUFFIX_RE.sub("", s)
    toks = (re.sub(r"[^0-9a-z]+", "", person_key(t)) for t in re.split(r"[\W_]+", s))
    return " ".join(sorted(t for t in toks if t))


def same_person(a, b) -> bool:
    """True when either the ledger key (person_key) or the stricter overlay_key says a and b are the same person."""
    return bool(person_key(a)) and (person_key(a) == person_key(b) or (overlay_key(a) != "" and overlay_key(a) == overlay_key(b)))


def is_sandbox(root) -> bool:
    """A marked demo/effect sandbox: <root>/.overlay-sandbox holds SANDBOX_TEXT, and root is not the repo root nor
    inside its data/ or docs/."""
    try:
        r = Path(root).resolve()
        if r == REPO_ROOT or r.is_relative_to(REPO_ROOT / "data") or r.is_relative_to(REPO_ROOT / "docs"):
            return False
        return (r / SANDBOX_MARK).read_text(encoding="utf-8").splitlines()[:1] == [SANDBOX_TEXT]
    except (OSError, IndexError):
        return False


def mark_sandbox(root) -> Path:
    """Mark a fresh folder as an overlay sandbox (demo and effect only); refused for the repo root, data/ and docs/."""
    r = Path(root).resolve()
    if r == REPO_ROOT or r.is_relative_to(REPO_ROOT / "data") or r.is_relative_to(REPO_ROOT / "docs"):
        raise OverlayError(f"{r}: the repo root, data/ and docs/ can never be an overlay sandbox")
    r.mkdir(parents=True, exist_ok=True)
    (r / SANDBOX_MARK).write_text(SANDBOX_TEXT + "\n", encoding="utf-8")
    return r


def _synthetic_allowed(root) -> bool:
    """SYNTHETIC entries may be written or read only in a marked sandbox, or under pytest on a root that is not the
    repo root (AGENT-06 review M2; the text_index guard style). Not a caller option."""
    if Path(root).resolve() == REPO_ROOT:
        return False
    return is_sandbox(root) or "PYTEST_CURRENT_TEST" in os.environ


def _refuse_synthetic(root, rows) -> None:
    if any((r.get("data") or {}).get("synthetic") for r in rows if r.get("event") == "add") and not _synthetic_allowed(root):
        raise OverlayError("the overlay ledger holds SYNTHETIC entries; refused outside a marked sandbox and tests")


def resolve_out(path, what="--out") -> Path:
    """An output path for the CLI and the demo: inside <repo>/outputs/, or outside the repo; refused anywhere else in
    the repo (data/, docs/, code). Same intent as activation.resolve_out_dir (EQ-B-0079)."""
    s = str(path or "").strip()
    if not s or "\x00" in s:
        raise OverlayError(f"{what} {path!r}: bad path")
    p = Path(s).expanduser()
    full = (p if p.is_absolute() else Path.cwd() / p).resolve()
    if full.is_relative_to(REPO_ROOT) and not (full != OUTPUTS_ROOT.resolve() and full.is_relative_to(OUTPUTS_ROOT.resolve())):
        raise OverlayError(f"{what} {path!r} resolves to {full}: inside the repo only under outputs/ is allowed")
    return full


def _require_on(enabled, settings, what: str) -> None:
    if not overlay_enabled(enabled, settings):
        raise OverlayError(f"{what}: {OFF_INFO}; pass enabled=True (tests and the demo only)")


# ---------------------------------------------------------------- ledger

def _check_chain(root) -> tuple[list[dict], list[str]]:
    errors, rows = [], []
    p = Path(root) / LOG
    lines = p.read_text(encoding="utf-8").splitlines() if p.exists() else []
    prev, last = GENESIS, ""
    for i, line in enumerate(lines, 1):
        try:
            r = json.loads(line)
        except json.JSONDecodeError:
            errors.append(f"line {i}: not JSON"); prev = None; continue
        if not isinstance(r, dict):
            errors.append(f"line {i}: not an object"); prev = None; continue
        if r.get("seq") != len(rows) + 1:
            errors.append(f"line {i}: seq {r.get('seq')} where {len(rows) + 1} expected (row deleted, inserted or moved)")
        if prev is not None and r.get("prev_hash") != prev:
            errors.append(f"line {i}: prev_hash does not match the previous row (row deleted, inserted or moved)")
        if r.get("row_hash") != row_hash(str(r.get("prev_hash", "")), r):
            errors.append(f"line {i}: row_hash does not recompute (row edited)")
        if r.get("event") not in EVENTS:
            errors.append(f"line {i}: unknown event {r.get('event')!r}")
        if str(r.get("as_of", "")) < last:
            errors.append(f"line {i}: as_of {r.get('as_of')} before the previous row's {last} (backdated)")
        last = max(last, str(r.get("as_of", "")))
        prev = r.get("row_hash")
        rows.append(r)
    return rows, errors


def verify(root, expect_head=None) -> dict:
    """Chain, head file and (optionally) a head 'SEQ:HASH' recorded outside the folder. {"ok", "rows", "head", "errors"}."""
    rows, errors = _check_chain(root)
    hp = Path(root) / HEAD
    head = None
    if hp.exists():
        try:
            head = json.loads(hp.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            errors.append("overlay-head.json is not JSON")
    if rows:
        last = rows[-1]
        if not (isinstance(head, dict) and head.get("seq") == last.get("seq") and head.get("row_hash") == last.get("row_hash")):
            errors.append("overlay-head.json does not name the last row (tail cut, or head not rewritten)")
    elif head not in (None, {"seq": 0, "row_hash": GENESIS}):
        errors.append("overlay-head.json names rows but the log is empty or absent")
    if expect_head:
        m = re.fullmatch(r"\s*(\d{1,9})\s*:\s*([0-9a-fA-F]{64})\s*", str(expect_head))
        if not m:
            errors.append(f"expect_head must be SEQ:HASH, got {expect_head!r}")
        else:
            seq, h = int(m.group(1)), m.group(2).lower()
            if seq < 1 or seq > len(rows) or rows[seq - 1].get("row_hash") != h:
                errors.append(f"expected head {seq}:{h[:12]}... is not in the log (rewritten or cut)")
    return {"ok": not errors, "rows": len(rows), "head": head, "errors": errors}


def _require_chain(root) -> list[dict]:
    rows, errors = _check_chain(root)
    if errors:
        raise OverlayError("overlay ledger fails verification: " + "; ".join(errors[:5]))
    v = verify(root)
    if not v["ok"]:
        raise OverlayError("overlay ledger fails verification: " + "; ".join(v["errors"][:5]))
    return rows


def _append(root, event: str, entry_id: str, as_of: dt.date, actor: str, data: dict, rows: list[dict]) -> dict:
    if rows and str(rows[-1].get("as_of", "")) > as_of.isoformat():
        raise OverlayError(f"as_of {as_of} is before the last ledger event ({rows[-1]['as_of']}); no backdating")
    prev = rows[-1]["row_hash"] if rows else GENESIS
    row = {"seq": len(rows) + 1, "as_of": as_of.isoformat(), "event": event, "entry_id": entry_id,
           "actor": _text(clean_person(actor), "actor"), "data": data, "prev_hash": prev, "ticket": TICKET}
    row["row_hash"] = row_hash(prev, row)
    with open(Path(root) / LOG, "a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n"); f.flush(); os.fsync(f.fileno())
    rows.append(row)
    _atomic_write(Path(root) / HEAD, (json.dumps({"seq": row["seq"], "row_hash": row["row_hash"]}) + "\n").encode())
    return row


def replay(rows, as_of=None) -> dict[str, dict]:
    """Entries as of a date (events dated on or before it), with status pending / active / expired / withdrawn."""
    d = _date(as_of).isoformat() if as_of is not None else None
    out: dict[str, dict] = {}
    for r in rows:
        if d is not None and str(r.get("as_of", "")) > d:
            continue
        eid, data = r.get("entry_id"), r.get("data") or {}
        if r["event"] == "add":
            out[eid] = {"entry_id": eid, "country": data["country"], "pillar": int(data["pillar"]),
                        "pillar_name": PILLARS.get(int(data["pillar"]), ""), "notches": int(data["notches"]),
                        "delta_points": float(data["notches"]) * NOTCH_POINTS, "reason": data["reason"],
                        "author": data["author"], "entered_on": r["as_of"], "expires": data["expires"],
                        "status": "pending", "approver": "", "approved_on": "", "self_approved": "", "exc_id": "",
                        "withdrawn_on": "", "withdrawn_by": "", "synthetic": "yes" if data.get("synthetic") else ""}
        elif eid in out and r["event"] == "approve":
            out[eid].update(status="active", approver=data["approver"], approved_on=r["as_of"],
                            self_approved=data.get("self_approved", ""), exc_id=data.get("exc_id", ""))
        elif eid in out and r["event"] == "withdraw":
            out[eid].update(status="withdrawn", withdrawn_on=r["as_of"], withdrawn_by=r.get("actor", ""))
    if d is not None:
        for e in out.values():
            if e["status"] in ("pending", "active") and e["expires"] < d:
                e["status"] = "expired"
    return out


# ---------------------------------------------------------------- exception (issues-log EXC row naming `overlay approve`)

def check_exception(root, exc_id: str, as_of) -> dict:
    """Fail closed unless exc_id is an issues-log EXC row that names `overlay approve`, starts on or before as_of and
    has an expiry (earliest date in its Expires cell) on or after as_of. Same reader as findings close (EXC-004)."""
    from .findings import FindingsError, exception_row
    d = _date(as_of)
    try:
        row = exception_row(root, exc_id)
    except FindingsError as e:
        raise OverlayError(str(e)) from None
    if not EXC_SCOPE_RE.search(row["text"]):
        raise OverlayError(f"{exc_id} does not cover overlay self-approval: its row must name `overlay approve` "
                           "(analyst-overlay.md section 4); EXC-002 and EXC-004 do not")
    try:
        start = _date(row["date"], f"{exc_id} date")
    except OverlayError:
        raise OverlayError(f"{exc_id} has no valid start date ({row['date']!r})") from None
    if d < start:
        raise OverlayError(f"{exc_id} starts on {start}, after as_of {d}")
    if not row["expires"]:
        raise OverlayError(f"{exc_id} has no expiry date; an exception without one is refused")
    if d > _date(row["expires"], f"{exc_id} expiry"):
        raise OverlayError(f"{exc_id} expired on {row['expires']}")
    return row


def _named_users_problem(root, author: str, approver: str) -> str | None:
    """Under users.json enforcement: both must be registered active users with different ids. None when not enforced."""
    from ..ops import identity as ID
    try:
        reg = ID.load_registry(Path(root) / "data")
    except ID.IdentityError as e:
        return f"users.json unreadable: {e}"
    if not ID.enforced(reg):
        return None
    a, b = ID.user_for(reg, author), ID.user_for(reg, approver)
    if not a or not b or not a["active"] or not b["active"]:
        return "four-eyes is enforced (users.json): author and approver must both be registered active users"
    if a["id"] == b["id"]:
        return "four-eyes is enforced (users.json): self-approval of an overlay entry is refused (no 'overlay' scope)"
    return None


# ---------------------------------------------------------------- commands

def add_entry(root, as_of, author, country, pillar, notches, reason, expires, synthetic=False, enabled=None,
              settings=None) -> dict:
    """Log one pending overlay entry. Refused while off, on a bad value, or when the (country, pillar) already has a
    pending or active entry (withdraw it first). Returns the ledger row (data.entry_id)."""
    _require_on(enabled, settings, "add_entry")
    d = _date(as_of)
    author = clean_person(author)
    if not person_key(author):
        raise OverlayError("author is required")
    country = clean_person(country)
    if not COUNTRY_RE.fullmatch(country):
        raise OverlayError(f"country must be a country name as in the run (letters, spaces, . ' -), got {country!r}")
    if isinstance(pillar, bool) or not isinstance(pillar, int) or pillar not in PILLARS:
        raise OverlayError(f"pillar must be one of {sorted(PILLARS)}, got {pillar!r}")
    if isinstance(notches, bool) or not isinstance(notches, int) or notches not in NOTCHES:
        raise OverlayError(f"notches must be a whole number in {NOTCHES} (0 is no entry), got {notches!r}")
    reason = _text(reason, "reason")
    if len(reason) < MIN_REASON:
        raise OverlayError(f"reason is required, at least {MIN_REASON} characters (what the model misses and why)")
    exp = _date(expires, "expires")
    if exp <= d or (exp - d).days > MAX_DAYS:
        raise OverlayError(f"expires must be after {d} and at most {MAX_DAYS} days later, got {exp}")
    if synthetic and not _synthetic_allowed(root):
        raise OverlayError("synthetic=True is refused outside a marked sandbox and tests (never the real ledger)")
    with _locked(root):
        rows = _require_chain(root)
        _refuse_synthetic(root, rows)
        state = replay(rows, d)
        clash = [e["entry_id"] for e in state.values() if e["country"] == country and e["pillar"] == pillar
                 and e["status"] in ("pending", "active")]
        if clash:
            raise OverlayError(f"{country} pillar {pillar} already has entry {clash[0]} ({state[clash[0]]['status']}); "
                               "withdraw it first")
        n = sum(1 for r in rows if r["event"] == "add") + 1
        eid = f"OVL-{n:04d}"
        data = {"country": country, "pillar": pillar, "notches": notches, "reason": reason,
                "author": _text(author, "author"), "expires": exp.isoformat(), "synthetic": bool(synthetic)}
        return _append(root, "add", eid, d, author, data, rows)


def approve_entry(root, as_of, approver, entry_id, exc_id=None, note="", enabled=None, settings=None) -> dict:
    """Four-eyes approval of a pending, unexpired entry: approver differs from the author, or exc_id passes
    check_exception (single-operator path, logged self_approved "yes" with the EXC id)."""
    _require_on(enabled, settings, "approve_entry")
    d = _date(as_of)
    approver = clean_person(approver)
    if not person_key(approver):
        raise OverlayError("approver is required")
    if not ENTRY_RE.fullmatch(str(entry_id or "")):
        raise OverlayError(f"not an overlay entry id: {entry_id!r}")
    with _locked(root):
        rows = _require_chain(root)
        e = replay(rows, d).get(entry_id)
        if e is None:
            raise OverlayError(f"{entry_id} is not in the overlay ledger")
        if e["status"] != "pending":
            raise OverlayError(f"{entry_id} is {e['status']}, only a pending entry can be approved")
        _refuse_synthetic(root, rows)
        same = same_person(approver, e["author"])
        exc = ""
        if same:
            if not exc_id:
                raise OverlayError(f"approver {approver!r} is the author of {entry_id}; four-eyes needs another "
                                   "approver, or an exception id (EXC-nnn) from the issues log that names "
                                   "`overlay approve`")
            check_exception(root, exc_id, d)
            exc = exc_id
        elif exc_id:
            raise OverlayError("exc_id is only for a self-approval (approver = author)")
        problem = _named_users_problem(root, e["author"], approver)
        if problem:
            raise OverlayError(problem)
        data = {"approver": _text(approver, "approver"), "author": e["author"], "self_approved": "yes" if same else "",
                "exc_id": exc, "note": _text(note, "note")}
        return _append(root, "approve", entry_id, d, approver, data, rows)


def withdraw_entry(root, as_of, actor, entry_id, reason, enabled=None, settings=None) -> dict:
    """End a pending or active entry early (anyone may; the actor and reason are logged)."""
    _require_on(enabled, settings, "withdraw_entry")
    d = _date(as_of)
    if not person_key(actor):
        raise OverlayError("actor is required")
    reason = _text(reason, "reason")
    if not reason:
        raise OverlayError("a withdrawal needs a reason")
    with _locked(root):
        rows = _require_chain(root)
        _refuse_synthetic(root, rows)
        e = replay(rows, d).get(entry_id)
        if e is None or e["status"] not in ("pending", "active"):
            raise OverlayError(f"{entry_id} is {'absent' if e is None else e['status']}; nothing to withdraw")
        return _append(root, "withdraw", entry_id, d, actor, {"reason": reason}, rows)


# ---------------------------------------------------------------- view (rows for Team C)

def _model_pillars(run: dict) -> dict[str, dict[int, float]]:
    out = {}
    for c, ps in (run.get("pillars") or {}).items():
        out[str(c)] = {int(k): float(v) for k, v in (ps or {}).items()}
    return out


def _composites(run: dict) -> dict[str, float]:
    rows = run.get("country") or []
    return {str(r["country"]): float(r["composite"]) for r in rows if isinstance(r, dict) and "composite" in r}


def _weights(run: dict, pillars: dict[int, float], composite: float | None) -> tuple[dict[int, float], str]:
    """The pillar weight set behind this country's composite: standard or small-state, whichever reproduces it."""
    sc = ((run.get("settings") or {}).get("scorecard") or {})
    sets = [("standard", sc.get("pillar_weights")), ("small_state", sc.get("small_state_weights"))]
    best = None
    for name, w in sets:
        if not isinstance(w, dict):
            continue
        ws = {int(k): float(v) for k, v in w.items()}
        if composite is None:
            return ws, name
        err = abs(sum(ws.get(p, 0.0) * v for p, v in pillars.items()) - composite)
        if best is None or err < best[2]:
            best = (ws, name, err)
    if best is None:
        return {p: 1.0 / len(PILLARS) for p in PILLARS}, "equal (no weights in run)"
    return best[0], best[1] if best[2] < 1e-6 else f"{best[1]} (composite not reproduced, err {best[2]:.2g})"


def _stamps(run: dict) -> tuple[str, str]:
    s, p = run.get("summary") or {}, run.get("provenance") or {}
    v = p.get("versions") or {}
    return str(s.get("run_id") or run.get("run_id") or ""), str(v.get("data_hash") or "")


def overlay_rows(run: dict, root, as_of, enabled=None, settings=None) -> list[dict]:
    """Display rows: one per active entry (row "pillar") and one "composite" row per country that has any, each with
    model_value, overlay_delta and overlaid_value side by side and the author and approver. [] while off. The run dict
    is read only. A ledger with SYNTHETIC entries is refused outside a marked sandbox and tests."""
    if not overlay_enabled(enabled, settings):
        return []
    d = _date(as_of)
    rows = _require_chain(root)
    _refuse_synthetic(root, rows)
    entries = [e for e in replay(rows, d).values() if e["status"] == "active"]
    model, comp = _model_pillars(run), _composites(run)
    run_id, data_hash = _stamps(run)
    unknown = sorted({e["country"] for e in entries if e["country"] not in model})
    if unknown:
        raise OverlayError(f"overlay entries for countries not in this run: {', '.join(unknown)}")
    common = {"as_of": d.isoformat(), "run_id": run_id, "data_hash": data_hash, "audience": AUDIENCE, "label": LABEL}
    out = []
    for c in sorted({e["country"] for e in entries}):
        mine = sorted((e for e in entries if e["country"] == c), key=lambda e: e["pillar"])
        w, wname = _weights(run, model[c], comp.get(c))
        raw = {e["pillar"]: max(-PILLAR_CAP_POINTS, min(PILLAR_CAP_POINTS, e["delta_points"])) for e in mine}
        clamped = {p: dp if 0.0 <= model[c][p] + dp <= 100.0 else min(100.0, max(0.0, model[c][p] + dp)) - model[c][p]
                   for p, dp in raw.items()}       # exact delta unless a bound binds (no float-noise "bounds" flag)
        comp_delta = sum(w.get(p, 0.0) * dp for p, dp in clamped.items())
        gross = sum(abs(w.get(p, 0.0) * dp) for p, dp in clamped.items())    # >= |net|; offsetting +2/-2 bounded too
        scale = 1.0 if gross <= COUNTRY_CAP_POINTS else COUNTRY_CAP_POINTS / gross
        for e in mine:
            p = e["pillar"]
            delta = clamped[p] * scale
            cap = ",".join(x for x in ("bounds" if clamped[p] != raw[p] else "", "country" if scale < 1 else "") if x)
            out.append({**common, "country": c, "row": "pillar", "pillar": p, "pillar_name": e["pillar_name"],
                        "model_value": model[c][p], "overlay_notches": e["notches"], "overlay_delta": delta,
                        "overlaid_value": model[c][p] + delta, "cap": cap, "entry_id": e["entry_id"],
                        "author": e["author"], "approver": e["approver"], "approved_on": e["approved_on"],
                        "self_approved": e["self_approved"], "exc_id": e["exc_id"], "reason": e["reason"],
                        "entered_on": e["entered_on"], "expires": e["expires"], "synthetic": e["synthetic"]})
        if c in comp:
            cd = comp_delta * scale
            out.append({**common, "country": c, "row": "composite", "pillar": "", "pillar_name": f"composite ({wname} weights)",
                        "model_value": comp[c], "overlay_notches": "", "overlay_delta": cd, "overlaid_value": comp[c] + cd,
                        "cap": "country" if scale < 1 else "", "entry_id": ",".join(e["entry_id"] for e in mine),
                        "author": ",".join(sorted({e["author"] for e in mine})),
                        "approver": ",".join(sorted({e["approver"] for e in mine})), "approved_on": "",
                        "self_approved": "yes" if any(e["self_approved"] for e in mine) else "",
                        "exc_id": ",".join(sorted({e["exc_id"] for e in mine if e["exc_id"]})), "reason": "",
                        "entered_on": "", "expires": min(e["expires"] for e in mine),
                        "synthetic": "yes" if any(e["synthetic"] for e in mine) else ""})
    return [{k: r.get(k, "") for k in OVERLAY_COLUMNS} for r in out]


def overlay_entries(root, as_of, enabled=None, settings=None) -> list[dict]:
    """Every entry (pending, active, expired, withdrawn) as of a date; [] while off."""
    if not overlay_enabled(enabled, settings):
        return []
    rows = _require_chain(root)
    _refuse_synthetic(root, rows)
    st = replay(rows, as_of)
    return [{k: e.get(k, "") for k in ENTRY_COLUMNS} for e in sorted(st.values(), key=lambda e: e["entry_id"])]


def overlay_audit(root, enabled=None, settings=None) -> list[dict]:
    """Every ledger event in order (the audit trail); [] while off."""
    if not overlay_enabled(enabled, settings):
        return []
    rows = _require_chain(root)
    _refuse_synthetic(root, rows)
    out = []
    for r in rows:
        detail = json.dumps(r.get("data") or {}, sort_keys=True, ensure_ascii=False)
        out.append({"seq": r["seq"], "as_of": r["as_of"], "event": r["event"], "entry_id": r["entry_id"],
                    "actor": r["actor"], "detail": detail, "prev_hash": r["prev_hash"], "row_hash": r["row_hash"]})
    return out


def build_overlay(run: dict, root, as_of, enabled=None, settings=None) -> dict:
    """Everything a page needs in one dict; while off {"enabled": False, "rows": [], ..., "info": OFF_INFO}."""
    if not overlay_enabled(enabled, settings):
        return {"enabled": False, "schema": SCHEMA, "rows": [], "entries": [], "audit": [], "verify": None,
                "info": OFF_INFO, "audience": AUDIENCE}
    return {"enabled": True, "schema": SCHEMA, "audience": AUDIENCE, "label": LABEL,
            "rows": overlay_rows(run, root, as_of, True),
            "entries": overlay_entries(root, as_of, True), "audit": overlay_audit(root, True), "verify": verify(root),
            "info": f"caps: {PILLAR_CAP_POINTS} pillar points ({NOTCH_POINTS} per notch), {COUNTRY_CAP_POINTS} gross "
                    "composite points per country; model output unchanged"}


def assert_internal(rows, audience: str = AUDIENCE) -> None:
    """Refuse overlay rows for any audience other than internal (client mode stays off)."""
    if audience != AUDIENCE or any(r.get("audience") != AUDIENCE for r in rows):
        raise OverlayError("analyst overlay rows are INTERNAL only; never in a client product")


# ---------------------------------------------------------------- demo (SYNTHETIC, sandboxed)

DEMO_AS_OF = "2026-10-26"
DEMO_EXC = "EXC-990"
DEMO_ISSUES_LOG = f"""# SYNTHETIC issues log for the analyst-overlay demo (EQ-B-0138); not the governance log

## Exceptions

| Id | Date | Restriction or control | What was done | Approved by | Compensating control | Expires |
|---|---|---|---|---|---|---|
| {DEMO_EXC} | 2026-10-26 | SYNTHETIC demo only: four-eyes on `overlay approve` | SYNTHETIC: single-operator self-approval of an overlay entry | SYNTHETIC | logged self_approved yes | 2026-12-31 |
"""
DEMO_ENTRIES = (   # (country, pillar, notches, reason, author, approver, exc)
    ("Brazil", 1, 1, "SYNTHETIC demo: fiscal slippage after the budget vote is not yet in the indicators",
     "SYNTHETIC analyst A", "SYNTHETIC analyst B", None),
    ("Brazil", 4, -1, "SYNTHETIC demo: policy noise judged lower than the governance indicators imply",
     "SYNTHETIC analyst A", "SYNTHETIC analyst B", None),
    ("Pakistan", 2, 2, "SYNTHETIC demo: reserve cover thinner than the last print, programme review delayed",
     "SYNTHETIC analyst B", "SYNTHETIC analyst A", None),
    ("Pakistan", 5, 2, "SYNTHETIC demo: banking-sector stress signals ahead of the official data",
     "SYNTHETIC analyst B", "SYNTHETIC analyst A", None),
    ("Pakistan", 6, 2, "SYNTHETIC demo: security incidents rising faster than the event index shows",
     "SYNTHETIC analyst B", "SYNTHETIC analyst A", None),
    ("Vietnam", 3, -1, "SYNTHETIC demo: single-operator self-approval path under a SYNTHETIC exception",
     "SYNTHETIC analyst A", "SYNTHETIC analyst A", DEMO_EXC),
)
DEMO_FILES = {"rows": "overlay_rows.csv", "rows_json": "overlay_rows.json", "entries": "overlay_entries.csv",
              "audit": "overlay_audit.csv", "summary": "demo_summary.json", "issues_log": ISSUES_LOG, "log": LOG,
              "head": HEAD}


def _synthetic_run() -> dict:
    """A SYNTHETIC run stub (used when no run dict is given and outputs/run_latest.json is absent)."""
    std = {"1": 0.2, "2": 0.2, "3": 0.15, "4": 0.15, "5": 0.1, "6": 0.1, "7": 0.1}
    pillars = {"Brazil": {"1": 55.0, "2": 30.0, "3": 45.0, "4": 50.0, "5": 40.0, "6": 35.0, "7": 30.0},
               "Pakistan": {"1": 70.0, "2": 75.0, "3": 60.0, "4": 65.0, "5": 60.0, "6": 70.0, "7": 50.0},
               "Vietnam": {"1": 22.0, "2": 37.0, "3": 47.0, "4": 13.0, "5": 35.0, "6": 7.0, "7": 58.0}}
    country = [{"country": c, "composite": sum(std[k] * v for k, v in ps.items())} for c, ps in pillars.items()]
    return {"summary": {"run_id": "SYNTHETIC-demo-run"}, "provenance": {"versions": {"data_hash": "SYNTHETIC"}},
            "settings": {"scorecard": {"pillar_weights": std, "small_state_weights": std}},
            "pillars": pillars, "country": country}


def _write_csv(path: Path, rows: list[dict], cols) -> None:
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=list(cols), lineterminator="\n")
    w.writeheader()
    for r in rows:
        w.writerow({k: escape_formula(r.get(k, "")) if isinstance(r.get(k), str) else r.get(k, "") for k in cols})
    _atomic_write(path, buf.getvalue().encode("utf-8"))


def demo_overlay(out_dir, run: dict | None = None) -> dict:
    """SYNTHETIC end-to-end demo in a sandbox <out_dir>/analyst_overlay: a sandbox issues log with a SYNTHETIC EXC
    row, six SYNTHETIC entries (four-eyes and one self-approval under that EXC), the refusals, the rows, entries and
    audit trail, and a verify. Model values from `run`, else outputs/run_latest.json (read only), else a SYNTHETIC
    stub. Never writes outside out_dir. Returns {"ok", "problems", "paths", "rows", "run_source", "checks"}."""
    box = resolve_out(out_dir, "out_dir") / "analyst_overlay"
    if (box / LOG).exists():
        (box / LOG).unlink()
    if (box / HEAD).exists():
        (box / HEAD).unlink()
    mark_sandbox(box)
    (box / ISSUES_LOG).parent.mkdir(parents=True, exist_ok=True)
    (box / ISSUES_LOG).write_text(DEMO_ISSUES_LOG, encoding="utf-8")
    problems, checks = [], []
    source = "given"
    if run is None:
        latest = Path(__file__).resolve().parents[2] / "outputs" / "run_latest.json"
        try:
            run, source = json.loads(latest.read_text(encoding="utf-8")), "outputs/run_latest.json (read only)"
        except (OSError, json.JSONDecodeError):
            run, source = _synthetic_run(), "SYNTHETIC stub"
    before = canonical(run)

    def check(name, ok, detail=""):
        checks.append({"check": name, "pass": bool(ok), "detail": detail})
        if not ok:
            problems.append(f"{name}: {detail}")

    exp = (dt.date.fromisoformat(DEMO_AS_OF) + dt.timedelta(days=60)).isoformat()
    check("off by default: no rows", overlay_rows(run, box, DEMO_AS_OF) == [] and build_overlay(run, box, DEMO_AS_OF)["rows"] == [])
    try:
        add_entry(box, DEMO_AS_OF, "SYNTHETIC analyst A", "Brazil", 1, 1, "x" * 30, exp, synthetic=True)
        check("off by default: add refused", False, "add_entry wrote while off")
    except OverlayError:
        check("off by default: add refused", not (box / LOG).exists())
    ids = []
    for country, pillar, notches, reason, author, approver, exc in DEMO_ENTRIES:
        if country not in _model_pillars(run):
            problems.append(f"demo country {country} not in the run")
            continue
        r = add_entry(box, DEMO_AS_OF, author, country, pillar, notches, reason, exp, synthetic=True, enabled=True)
        ids.append(r["entry_id"])
        approve_entry(box, DEMO_AS_OF, approver, r["entry_id"], exc_id=exc, enabled=True)
    try:
        r = add_entry(box, DEMO_AS_OF, "SYNTHETIC analyst A", "Pakistan", 1, 1, "SYNTHETIC demo: pending, self-approve "
                      "without an exception", exp, synthetic=True, enabled=True)
        approve_entry(box, DEMO_AS_OF, "SYNTHETIC analyst A", r["entry_id"], enabled=True)
        check("four-eyes: self-approval without EXC refused", False, "approved")
    except OverlayError as e:
        check("four-eyes: self-approval without EXC refused", "four-eyes" in str(e), str(e)[:120])
    for bad, kw in (("notches 3 refused", {"notches": 3}), ("expiry beyond 92 days refused", {"expires": "2027-06-01"})):
        try:
            add_entry(box, DEMO_AS_OF, "SYNTHETIC analyst A", "Brazil", 7, kw.get("notches", 1), "SYNTHETIC demo bad "
                      "entry, must be refused", kw.get("expires", exp), synthetic=True, enabled=True)
            check(bad, False, "accepted")
        except OverlayError:
            check(bad, True)
    rows = overlay_rows(run, box, DEMO_AS_OF, enabled=True)
    entries = overlay_entries(box, DEMO_AS_OF, enabled=True)
    audit = overlay_audit(box, enabled=True)
    v = verify(box)
    check("ledger verifies", v["ok"], "; ".join(v["errors"]))
    check("run dict unchanged", canonical(run) == before)
    check("pillar caps hold", all(abs(r["overlay_delta"]) <= PILLAR_CAP_POINTS + 1e-12 for r in rows if r["row"] == "pillar"))
    check("country cap holds", all(abs(r["overlay_delta"]) <= COUNTRY_CAP_POINTS + 1e-12 for r in rows if r["row"] == "composite"))
    check("every row shows model, delta, overlaid, author and approver",
          all(r["model_value"] != "" and r["approver"] and r["author"] and
              abs(r["model_value"] + r["overlay_delta"] - r["overlaid_value"]) < 1e-9 for r in rows))
    check("all rows internal and SYNTHETIC", all(r["audience"] == AUDIENCE and r["synthetic"] == "yes" for r in rows))
    check("self-approval logged with EXC", any(r["self_approved"] == "yes" and r["exc_id"] == DEMO_EXC for r in rows))
    paths = {k: str(box / f) for k, f in DEMO_FILES.items()}
    _write_csv(box / DEMO_FILES["rows"], rows, OVERLAY_COLUMNS)
    _atomic_write(box / DEMO_FILES["rows_json"], (json.dumps({"schema": SCHEMA, "label": f"{SYNTHETIC} {LABEL}",
                                                               "rows": rows}, indent=1) + "\n").encode())
    _write_csv(box / DEMO_FILES["entries"], entries, ENTRY_COLUMNS)
    _write_csv(box / DEMO_FILES["audit"], audit, AUDIT_COLUMNS)
    res = {"ok": not problems, "problems": problems, "paths": paths, "rows": len(rows), "entries": len(entries),
           "run_source": source, "checks": checks, "head": v["head"], "label": SYNTHETIC}
    _atomic_write(box / DEMO_FILES["summary"], (json.dumps({k: res[k] for k in res if k != "paths"}, indent=1) + "\n").encode())
    return res


# ---------------------------------------------------------------- Tier 1 card: effect if it were wired (temp copy)

def _adjusted_copy(src: Path, dest: Path, deltas: dict[tuple[str, int], float]) -> Path:
    """Temp copy of data/ whose adjustments.csv "Analyst adjustment" rows carry the overlay deltas (added to what is
    there). Equivalent to the parked hook (delta added to the final pillar before clip and floors)."""
    import shutil

    import pandas as pd
    shutil.copytree(src, dest, ignore=shutil.ignore_patterns("__pycache__"))
    p = dest / "adjustments.csv"
    adj = pd.read_csv(p)
    for (c, pil), dv in deltas.items():
        m = (adj["block"] == "Analyst adjustment") & (adj["pillar"].astype(int) == pil)
        adj.loc[m, c] = adj.loc[m, c].astype(float) + dv
    adj.to_csv(p, index=False)
    return dest


def tier1_effect(data_dir="data", as_of="2026-10-23", paths=20000, log=print) -> dict:
    """Book effect of wiring three overlay sets into the final pillars (Tier 1 card): the demo's SYNTHETIC sample and
    the cap bounds (+2 / -2 notches on every pillar of every country, then the country cap). Runs on temporary copies;
    the shared data hash is checked before and after."""
    from ..config import Settings
    from ..engine.pipeline import run_pipeline
    from ..ingestion import load_universe
    from ..versioning import data_hash
    from .layer2_cds_e2e import METRICS, _metrics

    data_dir = Path(data_dir)
    h0 = data_hash(data_dir)
    s = Settings.load(data_dir / "assumptions.json")
    base = run_pipeline(load_universe(str(data_dir)), s, paths=paths, as_of=as_of)
    run = base.to_dict()
    cases = {"base (overlay off)": _metrics(base)}
    sets = {"SYNTHETIC demo sample": [(c, p, n) for c, p, n, *_ in DEMO_ENTRIES],
            "cap bound: +2 notches everywhere": [(c, p, 2) for c in run["pillars"] for p in PILLARS],
            "cap bound: -2 notches everywhere": [(c, p, -2) for c in run["pillars"] for p in PILLARS]}
    with tempfile.TemporaryDirectory(prefix="eqb0138-") as t:
        sand0 = _adjusted_copy(data_dir, Path(t) / "data-0", {})
        r0 = run_pipeline(load_universe(str(sand0)), Settings.load(sand0 / "assumptions.json"), paths=paths, as_of=as_of)
        cases["copy, no overlay (must equal base)"] = _metrics(r0)
        for name, entries in sets.items():
            box = mark_sandbox(Path(t) / f"ledger-{len(cases)}")
            exp = (dt.date.fromisoformat(as_of) + dt.timedelta(days=30)).isoformat()
            for c, p, n in entries:
                r = add_entry(box, as_of, "SYNTHETIC analyst A", c, p, n, "SYNTHETIC effect case for the Tier 1 card",
                              exp, synthetic=True, enabled=True)
                approve_entry(box, as_of, "SYNTHETIC analyst B", r["entry_id"], enabled=True)
            rows = overlay_rows(run, box, as_of, enabled=True)
            deltas = {(r["country"], int(r["pillar"])): r["overlay_delta"] for r in rows if r["row"] == "pillar"}
            sand = _adjusted_copy(data_dir, Path(t) / f"data-{len(cases)}", deltas)
            res = run_pipeline(load_universe(str(sand)), Settings.load(sand / "assumptions.json"), paths=paths, as_of=as_of)
            cases[name] = _metrics(res)
            cases[name]["max_composite_delta"] = max((abs(r["overlay_delta"]) for r in rows if r["row"] == "composite"), default=0.0)
            log(f"[{TICKET}] {name}: " + ", ".join(f"{k} {v:.4f}" for k, v in cases[name].items()))
    h1 = data_hash(data_dir)
    return {"paths": paths, "as_of": as_of, "metrics": METRICS, "cases": cases, "shared_data_hash": [h0, h1],
            "data_hash_unchanged": h0 == h1}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.validation.analyst_overlay")
    sub = ap.add_subparsers(dest="cmd", required=True)
    e = sub.add_parser("effect", help="Tier 1 card effect table on temporary data copies (SYNTHETIC entries)")
    e.add_argument("--data", default="data"); e.add_argument("--as-of", default="2026-10-23")
    e.add_argument("--paths", type=int, default=20000); e.add_argument("--json", default=None)
    d = sub.add_parser("demo", help="SYNTHETIC sandbox demo under --out")
    d.add_argument("--out", required=True)
    a = ap.parse_args(argv)
    if a.cmd == "effect":
        out = resolve_out(a.json, "--json") if a.json else None
        res = tier1_effect(a.data, a.as_of, a.paths)
        if a.json:
            out.parent.mkdir(parents=True, exist_ok=True)
            out.write_text(json.dumps(res, indent=1) + "\n", encoding="utf-8")
        return 0 if res["data_hash_unchanged"] else 1
    res = demo_overlay(resolve_out(a.out))
    print(json.dumps({k: res[k] for k in ("ok", "problems", "rows", "entries", "run_source")}, indent=1))
    return 0 if res["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
