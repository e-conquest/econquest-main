"""QA gate for the LLM assistant (EQ-B-0146, PI-15): every answer or draft the assistant produces passes this gate
before anything is shown. The model explains the desk; **it never writes a number**.

Slots (lead decision after reviews HO-20261027-B-B-002 and -006). The model writes every figure as a slot that names a
field of a row it was given: `{{r1.var99_mm}}` (cite id, a dot, field name). The gate renders each slot itself from that
row with a canonical label that states the measure, the value with its own sign and unit, and its provenance:
`VaR99 66.96 $mm (run 20261023T101500-base, as of 2026-10-23)`. Anything numeric left in the model's own text (a digit,
a number word, a roman numeral, a scale word), a direction or valence word in the same clause as a slot, an unknown
slot, injection signs or (for a client) any non-allowed source in the model's context refuses the whole answer.

    from econquest.validation.assistant_qa import check_answer, render_answer
    res = check_answer(answer_text, tool_results=rows, chunks=chunks, audience="client")
    res.verdict          # "pass" | "pass_with_removals" | "refused"
    res.cleaned_text     # what may be shown: label line, text with slots rendered, citations listed
    render_answer(...)   # the same cleaned_text (label line + the refusal text when refused)

Pure functions: deterministic, no network, no model, no file reads, no clock. Doc: docs/validation/assistant-qa-gate.md
(slot grammar, rendering, policy, limits). It reuses the research QA gate of the MVP and client-safe packs: the
restricted-source text scan and register name patterns (client_safe_pack.RESTRICTED_SOURCE_TEXT, FACT_EXEMPT,
restricted_name_patterns), the C14 licence classes and the engine's PD cap label. Validation never imports
presentation.

Inputs (agreed with B-0145 by HO-20261027-B-B-001): tool rows carry `cite_id`, `tool`, `run_id`, `file`, `row`,
`as_of`, `licence_class`, `values: {name: number | {value, unit}}` and `labels`; chunks (A-0143) carry their id, `text`,
`as_of` and their licence tag (`scope`). `[cite:ID]` / `[chunk:ID]` markers for prose claims are still read.
"""
from __future__ import annotations

import math
import re
import unicodedata
from dataclasses import asdict, dataclass, field, is_dataclass
from typing import Iterable, Mapping

from ..engine.common import at_pd_cap
from .client_safe_pack import FACT_EXEMPT, RESTRICTED_SOURCE_TEXT, restricted_name_patterns
from .house_view import STANCES

TICKET = "EQ-B-0146"
SCHEMA = "eq-assistant-qa/2"
LABEL = "model-assisted, not validated"
VERDICTS = ("pass", "pass_with_removals", "refused")
AUDIENCES = ("internal", "client")
KINDS = ("answer", "draft")
UNITS = ("fraction", "pct", "pp", "bp", "mm", "count", "date", "plain")
LICENCE_CLASSES = ("allowed", "restricted", "barred")         # C14 client_output values
REMOVED_MARKER = "[removed by QA gate: {reason}]"
REFUSAL_TEXT = ("The assistant's answer was withheld by the QA gate ({codes}). Nothing in it is shown. Read the cited "
                "run outputs directly, or ask again.")
PD_CAP_LABEL = "(engine cap)"
MAX_CHARS = 20000
MAX_REMOVED_SHARE = 0.5          # more than half of the content sentences removed -> refused
SHINGLE_WORDS = 6                # words in a row shared with a source text: an echo (injection) or a copy (client)
WORD_FRACTION_TOL = 0.02         # extract_numbers: "two thirds" within 2 points
CONFIDENCE_LEVELS = (90.0, 95.0, 97.5, 99.0, 99.5, 99.9)

REFUSE = "refuse"
REMOVE = "remove"
FLAG = "flag"
POLICY = {
    "empty": REFUSE,
    "too_long": REFUSE,
    "model_number": REFUSE,                 # a digit, number word, roman numeral or scale word outside a slot
    "bad_slot": REFUSE,                     # braces that are not a well-formed {{id.field}}
    "unknown_slot": REFUSE,                 # a slot whose cite id or field was not given to the model
    "slot_direction": REFUSE,               # a direction or valence word in the same clause as a slot
    "fabricated_citation": REFUSE,          # [cite:X] where X was not given to the model
    "fabricated_run_id": REFUSE,            # a run id in the model's text that no row carries
    "injection": REFUSE,                    # instructions, role tags, links or tool requests in the answer
    "obfuscated_text": REFUSE,              # a word mixing Latin and other letters after normalisation
    "non_latin_text": REFUSE,               # a letter or numeral of a non-Latin script in the model's text
    "unlabelled_slot": REFUSE,              # a numeric slot whose field names no measure or metric
    "slot_relabel": REFUSE,                 # the model's words name another measure than the slot's own
    "client_context": REFUSE,               # client audience: a non-allowed row or chunk was in the model's context
    "client_scope_leak": REFUSE,            # client audience: the answer copies text of a non-allowed source
    "too_many_removals": REFUSE,
    "restricted_name": REMOVE,              # client audience: the sentence names a restricted source
    "house_view_unsupported": REMOVE,       # a house stance no cited row states
    "duplicate_citation_id": FLAG,          # two given sources share an id (first kept; client: refused)
    "missing_citation_id": FLAG,            # a given row or chunk has no id (client: refused)
}

# ---------------------------------------------------------------- normalisation

_CONFUSABLES = str.maketrans({
    # Cyrillic
    "а": "a", "в": "b", "е": "e", "к": "k", "м": "m", "н": "h", "о": "o", "р": "p", "с": "c", "т": "t", "у": "y",
    "х": "x", "і": "i", "ј": "j", "ѕ": "s", "ԁ": "d", "ӏ": "l", "ү": "y", "һ": "h", "ԛ": "q", "ԝ": "w",
    "А": "A", "В": "B", "Е": "E", "К": "K", "М": "M", "Н": "H", "О": "O", "Р": "P", "С": "C", "Т": "T", "У": "Y",
    "Х": "X", "І": "I", "Ј": "J", "Ѕ": "S", "Ӏ": "I",
    # Greek
    "α": "a", "β": "b", "ε": "e", "ι": "i", "κ": "k", "ν": "v", "ο": "o", "ρ": "p", "τ": "t", "υ": "u", "χ": "x",
    "Α": "A", "Β": "B", "Ε": "E", "Ζ": "Z", "Η": "H", "Ι": "I", "Κ": "K", "Μ": "M", "Ν": "N", "Ο": "O", "Ρ": "P",
    "Τ": "T", "Υ": "Y", "Χ": "X",
    # Armenian
    "օ": "o", "ո": "n", "ս": "u", "ց": "g", "հ": "h", "ա": "w", "Ս": "U", "Օ": "O",
    # IPA, Latin extended, small capitals
    "ɑ": "a", "ɡ": "g", "ɪ": "i", "ʏ": "y", "ɴ": "n", "ʀ": "r", "ʟ": "l", "ʜ": "h", "ɢ": "g", "ʙ": "b", "ı": "i",
    "ȷ": "j", "ǀ": "l", "ɩ": "i", "ɯ": "w", "ᴀ": "a", "ᴄ": "c", "ᴅ": "d", "ᴇ": "e", "ᴏ": "o", "ᴘ": "p", "ᴛ": "t",
    "ᴜ": "u", "ᴠ": "v", "ᴡ": "w", "ᴢ": "z", "ꞵ": "b",
    # signs
    "\u2212": "-", "\u2010": "-", "\u2011": "-", "\u2012": "-", "\ufe63": "-", "\uff0d": "-",
    "\u2044": "/", "\u2215": "/", "\u066b": ".", "\u066c": ",", "\u2019": "'", "\u2018": "'",
})


def normalise_text(text: str) -> str:
    """NFKD with combining marks dropped (accents, stacked marks), then NFKC (superscripts, full-width, vulgar
    fractions as `2/3`), format characters removed, non-ASCII digits to ASCII, every space character to ' ', look-alike
    letters (Cyrillic, Greek, Armenian, IPA, small capitals) to ASCII. The gate checks and shows this text."""
    s = unicodedata.normalize("NFKD", text or "")
    s = "".join(ch for ch in s if unicodedata.category(ch) not in ("Mn", "Me"))
    s = unicodedata.normalize("NFKC", s)
    out = []
    for ch in s:
        cat = unicodedata.category(ch)
        if cat == "Cf":
            continue
        if cat == "Nd" and not ch.isascii():
            ch = str(unicodedata.digit(ch, 0))
        elif cat == "Zs":
            ch = " "
        out.append(ch)
    return "".join(out).translate(_CONFUSABLES)


_SPACED_LETTERS = re.compile(r"(?<![A-Za-z])(?:[A-Za-z][ ./\-]){2,}[A-Za-z](?![A-Za-z])\.?")


def collapse_letters(text: str) -> str:
    """Single letters separated by spaces, dots, slashes or hyphens joined into one word (W E O, W-E-O, V.a.R.,
    s/i/x/t/y, I g n o r e):
    the text the name, injection and number scans read."""
    return _SPACED_LETTERS.sub(lambda m: re.sub(r"[ ./\-]", "", m.group(0)), text or "")


# ---------------------------------------------------------------- patterns

SLOT_RX = re.compile(r"\{\{\s*(?P<cid>[A-Za-z0-9_.:/#@-]+?)\.(?P<field>[A-Za-z_][A-Za-z0-9_]*)\s*\}\}")
_CITE_RX = re.compile(r"\[(?:cite|chunk):\s*([^\]]*)\]", re.I)      # [cite:ID] (B-0145) and [chunk:ID] (C-0170)
_CITE_ID_RX = re.compile(r"^[A-Za-z0-9_.:/#@-]+$")
_RUN_ID_RX = re.compile(r"(?<![\w])\d{8}T\d{6}(?:-[A-Za-z0-9_.-]*[A-Za-z0-9_])?")
_FENCE_RX = re.compile(r"<<[^<>\n]{0,400}>>")      # <<UNTRUSTED-DATA nonce=... source="..." kind=...>> headers
_URL_RX = re.compile(r"(?:https?://|www\.)[^\s\])>\"']+", re.I)
_SLOT_MASK = "\u00a7"            # what a slot reads as in the model's text: no letter, no digit, no clause mark

# Anything numeric in the model's own text: digits, number words (cardinals, -teens, -ties, ordinals from third, -ieth),
# quantity words, scale words and unit words, and roman numerals of two or more letters in any case ("mix" excepted).
_NUMBER_WORDS = (
    r"zero|one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|"
    r"seventeen|eighteen|nineteen|twenty|thirty|forty|fourty|fifty|sixty|seventy|eighty|ninety|"
    r"teens|tens|twenties|thirties|forties|fifties|sixties|seventies|eighties|nineties|"
    r"third|fourth|fifth|sixth|seventh|eighth|ninth|tenth|eleventh|twelfth|\w+teenth|\w+ieth|hundredth|thousandth|"
    r"millionth|hundreds?|thousands?|millions?|billions?|trillions?|dozens?|grand|half|halves|halved|thirds|quarters?|"
    r"twice|thrice|double[ds]?|doubling|triple[ds]?|quadruple[ds]?|couple|pair|nil|naught|nought|zilch|umpteen\w*|"
    r"myriads?|digits?|(?:one|two|three|four|five|six|seven|eight|nine|ten|twelve|twenty|fifty|hundred|thousand|"
    r"million|many|several|multi|n|x)[- ]?fold|(?:a|one|few|several|some|many|half a)\s+(?:score|gross)|scores of|"
    r"percent|per\s?cent|percentage|percentile|permille|bps?|basis\s+points?|pp|mm|mn|mln|mio|bn|tn|lakhs?|crores?")
_ROMAN = r"(?=[mdclxvi]{2,}\b)m{0,4}(?:cm|cd|d?c{0,3})(?:xc|xl|l?x{0,3})(?:ix|iv|v?i{0,3})(?<=[mdclxvi])"
_MODEL_NUMERIC = re.compile(rf"\d|[%\u2030\u00bd\u2153\u00bc]|(?<![\w])(?:{_NUMBER_WORDS})(?![\w])|"
                            rf"(?<![\w])(?!(?:mix|dc)\b){_ROMAN}(?![\w])", re.I)
# Direction and valence words: never in the clause of a slot (the rendered value carries its own sign).
_VALENCE = re.compile(
    r"(?<![\w-])(?:loss(?:es)?|lose[sr]?|losing|lost|gain(?:s|ed|ing|er)?|profit\w*|fell|fall(?:s|en|ing)?|rose|"
    r"ris(?:e|es|en|ing)|up|down|shed\w*|worse\w*|improv\w*|deteriorat\w*|increas\w*|decreas\w*|declin\w*|drop\w*|"
    r"jump\w*|surg\w*|slump\w*|plung\w*|soar\w*|climb\w*|grew|grow\w*|shr[aiu]nk\w*|red|black|cost\w*|hits?|"
    r"give[sn]? (?:up|back)|gave (?:up|back)|giving (?:up|back)|wip\w*|negative|positive|minus|plus|higher|lower\w*|"
    r"more|less|fewer|above|below|exceed\w*|beat\w*|miss\w*|better|worse|widen\w*|tighten\w*|narrow\w*|add(?:s|ed|ing)?|"
    r"subtract\w*|cuts?|cutting|reduc\w*|rais\w*|boost\w*|dent\w*|erod\w*|slid\w*|slip\w*|tumbl\w*|rall\w*|spik\w*|"
    r"swing\w*|swung|flip\w*|deficit\w*|surplus\w*|drawdowns?|bleed\w*|bled|sank|sink\w*|sunk|underwater|"
    r"outperform\w*|underperform\w*|recover\w*|rebound\w*|accelerat\w*|decelerat\w*|expand\w*|contract\w*|"
    r"advers\w*|favou?rabl\w*|unfavou?rabl\w*|tank\w*|crash\w*|write-?downs?|written down|write-?offs?|written off|"
    r"damag\w*|hurt\w*|tolls?|haircuts?|hole|ink|windfall\w*|bonanza|blow|setback\w*|pain\w*|benefit\w*)(?![\w-])",
    re.I)
_CLAUSE_SPLIT = re.compile(r"[,;:()\[\]\u2013\u2014!?]|\.(?!\w)|\s-\s|\b(?:but|while|whereas|although|though)\b", re.I)
# Risk measures (label, field-name family): used to label slots and to mask measure names in the valence scan.
MEASURES = (
    ("lvar", r"\bl-?vars?\b|liquidity[- ]adjusted (?:var|value[- ]at[- ]risk)"),
    ("les", r"\bl-?ess?\b"),
    ("es", r"\bc-?vars?\b|\bes(?:s|es)?\b|(?:\b(?:expected|exp\.?)[- ]?)?\bshortfalls?\b"),
    ("var", r"\bvars?\b|value[- ]at[- ]risk"),
    ("el", r"(?-i:\bELs?\b)|expected[- ]loss(?:es)?"),
    ("pd", r"\bpds?\b|probabilit(?:y|ies) of default|default probabilit(?:y|ies)"),
    ("lgd", r"\blgds?\b|loss[- ]given[- ]default"),
    ("pnl", r"\bp\s?&\s?l\b|\bp/l\b|\bpnl\b|profit and loss"),
    ("limit", r"\blimit (?:usage|utili[sz]ation|use)\b|\butili[sz]ation\b"),
)
_MEASURE_RXS = tuple((k, re.compile(p, re.I)) for k, p in MEASURES)
MEASURE_LABELS = {"lvar": "L-VaR", "les": "L-ES", "es": "ES", "var": "VaR", "el": "EL", "pd": "PD", "lgd": "LGD",
                  "pnl": "P&L", "limit": "limit usage"}
_SIGNED_FIELD = re.compile(r"pnl|p_l|change|chg|delta|diff|move|stress|shift|impact|contrib", re.I)
_EXTRA_RESTRICTED = re.compile(r"(?<![\w])Y!(?:\s*Finance)?|\bYahoo\s*Finance\b", re.I)
_ABBREV = ("e.g.", "i.e.", "U.S.", "U.K.", "vs.", "approx.", "Fig.", "No.", "etc.", "cf.", "Inc.", "Ltd.", "St.")
_SENT_END = re.compile(r"[.!?](?P<cites>(?:\s*\[(?:cite|chunk):[^\]]*\])*)(?P<ws>\s+)", re.I)
_BLOCK_START = re.compile(r"^\s*(?:[-*\u2022+]\s|\d{1,3}[.)]\s|\||#)")
_DOTTED_ACRONYM = re.compile(r"(?:\b[A-Za-z]\.){2,}")
INJECTION_PATTERNS = (
    ("ignore_instructions", re.compile(r"\b(?:ignore|disregard|forget|override|bypass)\b[^.\n]{0,40}\b(?:instructions?|"
                                       r"prompts?|rules|guidelines|directives?|system message|commands?)\b", re.I)),
    ("ignore_above", re.compile(r"\b(?:ignore|disregard|forget)\s+(?:all\s+|everything\s+)?(?:of\s+)?(?:the\s+)?"
                                r"(?:above|previous|prior|preceding|earlier)\b(?!\s+(?:quarter|year|month|week|day|run|"
                                r"close|level|peak|value|figure|estimate)s?\b)", re.I)),
    ("paraphrased_override", re.compile(r"\bset aside (?:what|everything|all|anything)\b[^.\n]{0,20}\btold\b|"
                                        r"\bwhat you (?:were|have been) told\b|\bno longer bound\b", re.I)),
    ("reveal_hidden", re.compile(r"\b(?:reveal|print|show|dump|output|repeat|leak|list)\b[^.\n]{0,30}\b(?:hidden|secret|"
                                 r"system|internal|confidential)\s+(?:context|prompts?|instructions?|rules|notes?|data|"
                                 r"text)\b|\bprint everything\b", re.I)),
    ("prompt_reference", re.compile(r"\bsystem prompt\b|\bdeveloper (?:message|mode)\b|\bnew instructions\b|"
                                    r"\bjailbreak\b|\bdo anything now\b", re.I)),
    ("role_switch", re.compile(r"\byou are now\b|\bact as (?:an?|the) (?!analyst)|\bfrom now on,? you\b", re.I)),
    ("role_tag", re.compile(r"(?im)^\s*(?:system|assistant|user|tool)\s*:|<\|im_(?:start|end)\|>|\[/?INST\]|"
                            r"^\s*#{2,}\s*(?:instruction|system)")),
    ("hidden_from_user", re.compile(r"\bdo not (?:tell|mention|show|reveal)\b[^.\n]{0,30}\b(?:user|analyst|reader|"
                                    r"client|anyone)\b", re.I)),
    ("action_request", re.compile(r"\beconquest change\b|\brun (?:the following|this) (?:command|script|code)\b|"
                                  r"\bcall the [\w-]+ tool\b|\bexecute (?:the|this|following)\b|"
                                  r"\b(?:send|email|post|upload) (?:it|this|the (?:data|answer|results?|file))\b", re.I)),
    ("markup", re.compile(r"<\s*(?:script|iframe|img|object|embed)\b|!\[[^\]]*\]\(", re.I)),
)

# extract_numbers (kept for B-0147's scorer and for numbers printed in chunk text)
_MONTHS = {m: i + 1 for i, m in enumerate(("january", "february", "march", "april", "may", "june", "july", "august",
                                           "september", "october", "november", "december"))}
_MON = (r"(?P<mon>Jan(?:uary)?|Feb(?:ruary)?|Mar(?:ch)?|Apr(?:il)?|May|June?|July?|Aug(?:ust)?|Sep(?:t(?:ember)?)?|"
        r"Oct(?:ober)?|Nov(?:ember)?|Dec(?:ember)?)\.?")
_DATE_RXS = (re.compile(r"(?<![\w-])(?P<y>\d{4})-(?P<m>\d{2})-(?P<d>\d{2})(?![\w-])"),
             re.compile(rf"(?<![\w])(?P<d>\d{{1,2}})\s+{_MON},?\s+(?P<y>\d{{4}})(?![\w])", re.I),
             re.compile(rf"(?<![\w]){_MON}\s+(?P<d>\d{{1,2}}),?\s+(?P<y>\d{{4}})(?![\w])", re.I))
CURRENCY_CODES = ("USD", "EUR", "GBP", "CHF", "JPY", "CNY", "CNH", "CAD", "AUD", "NZD", "SEK", "NOK", "DKK", "BRL",
                  "MXN", "ZAR", "TRY", "INR", "KRW", "HKD", "SGD", "PLN", "HUF", "CZK", "RUB", "IDR", "COP", "CLP",
                  "PEN", "ARS", "EGP", "NGN", "SAR", "AED", "ILS", "THB", "PHP", "MYR", "TWD", "KZT", "UAH", "RON")
_CODES = "|".join(CURRENCY_CODES)
_PCT_UNIT = r"%|percentage\s+points?|per\s?cent|pp|p\.p\.|bps?|basis\s+points?|x"
_SCALE = r"thousand|million|billion|trillion|hundred|lakhs?|crores?|mln|mio|mn|mm|bn|tn|tr|k|m|b"
_CUR_SUFFIX = rf"US\s?dollars?|dollars?|euros?|pounds?|yen|{_CODES}"
_NUM_RX = re.compile(
    rf"(?P<sign>[-+])?(?P<cur>US\$|\$|€|£|¥|(?:{_CODES})\s?)?"
    r"(?P<num>\d{1,3}(?:,\d{3})+(?:\.\d+)?|\d+(?:\.\d+)?|\.\d+)(?P<exp>e[-+]?\d{1,3})?"
    rf"(?:\s?(?P<unit>{_PCT_UNIT})(?![A-Za-z])"
    rf"|\s?(?P<scale>{_SCALE})(?:\s?(?P<cur2>{_CUR_SUFFIX}))?(?![A-Za-z])"
    rf"|\s?(?P<cur3>{_CUR_SUFFIX})(?![A-Za-z]))?", re.I)
_SCALE_FACTOR = {"thousand": 1e3, "k": 1e3, "hundred": 1e2, "lakh": 1e5, "lakhs": 1e5, "crore": 1e7, "crores": 1e7,
                 "million": 1e6, "mm": 1e6, "mn": 1e6, "mln": 1e6, "mio": 1e6, "m": 1e6,
                 "billion": 1e9, "bn": 1e9, "b": 1e9, "trillion": 1e12, "tn": 1e12, "tr": 1e12}
_RANGE_GAP = re.compile(r"^\s*(?:-|\u2013|\u2014|to)\s*(?:US\$|\$|USD\s?)?$", re.I)
_BETWEEN_GAP = re.compile(r"^\s*and\s*(?:US\$|\$|USD\s?)?$", re.I)
_WORD_FRACTIONS = {"half": 0.5, "third": 1 / 3, "thirds": 1 / 3, "quarter": 0.25, "quarters": 0.25, "fifth": 0.2,
                   "fifths": 0.2, "tenth": 0.1, "tenths": 0.1}
_WORD_NUMS = {"a": 1, "an": 1, "one": 1, "two": 2, "three": 3, "four": 4, "five": 5, "six": 6, "seven": 7, "eight": 8,
              "nine": 9, "ten": 10, "eleven": 11, "twelve": 12, "fifteen": 15, "twenty": 20, "thirty": 30, "forty": 40,
              "fifty": 50, "sixty": 60, "seventy": 70, "eighty": 80, "ninety": 90, "hundred": 100}
_FRACTION_WORD_RX = re.compile(r"(?<![\w-])(?:(?P<n>one|two|three|four|a|an)[\s-]+)?(?P<d>half|thirds?|quarters?|"
                               r"fifths?|tenths?)(?![\w-])", re.I)
_NUMBER_WORD_RX = re.compile(r"(?<![\w-])(?P<w>one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|"
                             r"fifteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|hundred)\s+"
                             r"(?P<unit>per\s?cent|percentage\s+points?|basis\s+points?|million|billion)(?![\w])", re.I)
_HORIZON_AFTER = re.compile(r"^[-\s]?(?:days?|weeks?|months?|years?|yrs?|quarters?|day|month|year)(?![A-Za-z])", re.I)
_LIST_MARKER = re.compile(r"(?m)^\s*(?:[-*\u2022]\s*)?(\d{1,2})[.)]\s")
_CONFIDENCE_CONTEXT = re.compile(r"\b(?:L-?VaR|C?VaR|ES)\b|value[- ]at[- ]risk|expected shortfall|confidence", re.I)


# ---------------------------------------------------------------- data

@dataclass(frozen=True)
class Value:
    """One value a source holds: number (float, signed) or text (date or label), its unit, the decimals it was
    printed with (None for a full-precision tool value), its measure ("" for none) and, for a number printed in a source
    text, how it was printed."""
    cite_id: str
    name: str
    value: object
    unit: str
    decimals: int | None = None
    measure: str = ""
    printed: str = ""
    label: str = ""               # the canonical label shown with a number ("" for none: unlabelled_slot)


@dataclass
class Source:
    cite_id: str
    kind: str                     # "tool" | "chunk"
    tool: str = ""
    run_id: str = ""
    file: str = ""
    row: str = ""
    as_of: str = ""
    licence_class: str = "unknown"
    source_id: str = ""
    text: str = ""
    values: list = field(default_factory=list)

    def citation(self) -> dict:
        return {k: v for k, v in (("cite_id", self.cite_id), ("kind", self.kind), ("tool", self.tool),
                                  ("source_id", self.source_id), ("run_id", self.run_id), ("file", self.file),
                                  ("row", self.row), ("as_of", self.as_of), ("licence_class", self.licence_class)) if v}

    def fields(self) -> dict:
        """{field name: Value} a slot may name: the row's values and labels, numbers printed in its text (t1, t2, ...),
        and as_of / run_id."""
        out: dict = {}
        k = 0
        for v in self.values:
            if v.name == "text":
                k += 1
                out.setdefault(f"t{k}", v)
            else:
                out.setdefault(v.name, v)
        if self.run_id:
            out.setdefault("run_id", Value(self.cite_id, "run_id", self.run_id, "text"))
        return out


@dataclass
class Number:
    """A number found in text by extract_numbers. `value` is a signed float in the canonical unit (mm for USD money,
    the number itself for pct, pp, bp; a fraction for word fractions; "fx" for other currencies) or an ISO date."""
    text: str
    start: int
    end: int
    value: object
    unit: str
    decimals: int
    tol: float
    kind: str = "number"          # number | word_fraction | number_word | date
    exempt: str = ""
    status: str = ""
    detail: str = ""
    sentence: int = -1
    sign: str = ""
    measure: str = ""


@dataclass
class Slot:
    text: str
    cite_id: str
    field: str
    sentence: int = -1
    status: str = ""              # rendered | unknown
    rendered: str = ""


@dataclass
class QAResult:
    verdict: str
    cleaned_text: str
    reasons: list
    citations: list
    numbers: list
    label: str = LABEL
    audience: str = "internal"
    kind: str = "answer"
    schema: str = SCHEMA
    slots: list = field(default_factory=list)

    @property
    def ok(self) -> bool:
        return self.verdict != "refused"

    def to_dict(self) -> dict:
        d = asdict(self)
        d["numbers"] = [asdict(n) if is_dataclass(n) else n for n in self.numbers]
        d["slots"] = [asdict(s) if is_dataclass(s) else s for s in self.slots]
        return d


# ---------------------------------------------------------------- extraction (number reader for source texts and B-0147)

def _blank(text: str, spans: Iterable[tuple[int, int]], ch: str = " ") -> str:
    chars = list(text)
    for a, b in spans:
        for i in range(a, b):
            if chars[i] != "\n":
                chars[i] = ch
    return "".join(chars)


def extract_citations(text: str) -> list[str]:
    """Citation ids in `[cite:...]` (or `[chunk:...]`) markers and slots, in order (an id may repeat)."""
    out = []
    for m in re.finditer(rf"{_CITE_RX.pattern}|{SLOT_RX.pattern}", text or "", re.I):
        if m.group("cid"):
            out.append(m.group("cid"))
        else:
            out += [x.strip() for x in re.split(r"[,;]", m.group(1)) if x.strip()]
    return out


def extract_slots(text: str) -> list[tuple[int, int, str, str]]:
    """(start, end, cite id, field) of every well-formed slot."""
    return [(m.start(), m.end(), m.group("cid"), m.group("field")) for m in SLOT_RX.finditer(text or "")]


def extract_run_ids(text: str) -> list[str]:
    return [m.group(0) for m in _RUN_ID_RX.finditer(text or "")]


def _iso(y, m, d) -> str | None:
    try:
        y, m, d = int(y), int(m), int(d)
    except (TypeError, ValueError):
        return None
    if not (1 <= m <= 12 and 1 <= d <= 31 and 1800 <= y <= 2200):
        return None
    return f"{y:04d}-{m:02d}-{d:02d}"


def _month(name: str) -> int:
    n = name.lower().rstrip(".")
    return next(v for k, v in _MONTHS.items() if k.startswith(n[:3]))


def _money(cur: str | None) -> str:
    c = re.sub(r"\s+", " ", (cur or "").strip().lower())
    if not c:
        return ""
    return "usd" if c in ("$", "us$", "usd", "dollar", "dollars", "us dollar", "us dollars", "usdollar", "usdollars") \
        else "fx"


def _unit_of(unit: str | None, scale: str | None = None, cur: str | None = None) -> tuple[str, float]:
    """(canonical unit, multiplier to it) for a printed percent-type unit, a scale word and a currency."""
    u = re.sub(r"\s+", " ", (unit or "").lower())
    if u in ("%", "percent", "per cent"):
        return "pct", 1.0
    if u in ("pp", "p.p.") or u.startswith("percentage point"):
        return "pp", 1.0
    if u in ("bp", "bps") or u.startswith("basis point"):
        return "bp", 1.0
    if u == "x":
        return "plain", 1.0
    money = _money(cur)
    factor = _SCALE_FACTOR.get((scale or "").lower())
    if money == "fx":
        return "fx", (factor or 1.0) / 1e6
    if factor is None:
        return ("mm", 1e-6) if money else ("plain", 1.0)
    if money or factor >= 1e6:
        return "mm", factor / 1e6
    return "plain", factor


def extract_numbers(text: str) -> list[Number]:
    """Every number in `text` (normalised): numerals with unit, scale (any case) and currency, e-notation, ranges,
    dates, word fractions and number words with a unit. The gate itself no longer matches the model's numbers (the
    model writes slots); this reader is kept for numbers printed in chunk text (slot fields t1, t2, ...) and for
    B-0147's scorer."""
    text = text or ""
    numbers: list[Number] = []
    masked = _blank(text, [m.span() for rx in (_CITE_RX, _RUN_ID_RX, _URL_RX, SLOT_RX, _FENCE_RX)
                           for m in rx.finditer(text)])
    for rx in _DATE_RXS:
        for m in rx.finditer(masked):
            g = m.groupdict()
            iso = _iso(g["y"], g.get("m") or _month(g["mon"]), g["d"])
            if iso:
                numbers.append(Number(m.group(0), m.start(), m.end(), iso, "date", 0, 0.0, kind="date"))
        masked = _blank(masked, [(n.start, n.end) for n in numbers if n.kind == "date"])
    for m in _NUMBER_WORD_RX.finditer(masked):
        w = m.group("unit")
        unit, scale = _unit_of(None if w.lower() in ("million", "billion") else w,
                               w if w.lower() in ("million", "billion") else None)
        numbers.append(Number(m.group(0), m.start(), m.end(), float(_WORD_NUMS[m.group("w").lower()]) * scale, unit, 0,
                              0.5 * scale, kind="number_word"))
    for m in _FRACTION_WORD_RX.finditer(masked):
        before = masked[max(0, m.start() - 8):m.start()].lower()
        after = masked[m.end():m.end() + 6].lower()
        if m.group("d").lower() == "half" and (re.search(r"(?:first|second|1st|2nd)\s*$", before)
                                                or re.match(r"[\s-]*(?:year|yearly)", after)):
            continue
        if m.group("d").lower().startswith("quarter") and not m.group("n") and not re.search(r"\b(?:a|one)\s*$", before):
            continue
        if m.group("d").lower().startswith(("third", "fifth", "tenth")) and not m.group("n"):
            continue
        n = _WORD_NUMS.get((m.group("n") or "a").lower(), 1)
        numbers.append(Number(m.group(0), m.start(), m.end(), n * _WORD_FRACTIONS[m.group("d").lower()], "fraction", 0,
                              WORD_FRACTION_TOL, kind="word_fraction"))
    taken = [(n.start, n.end) for n in numbers]
    raw: list[tuple[Number, float, bool]] = []
    for m in _NUM_RX.finditer(masked):
        if any(a < m.end() and m.start() < b for a, b in taken):
            continue
        start, sign, cur = m.start(), m.group("sign"), m.group("cur")
        if sign and start > 0 and not re.match(r"[\s(~\u2248:=]", masked[start - 1]):
            sign, start = None, start + 1
        first = m.start("cur") if cur else (start if sign else m.start("num"))
        prev = masked[first - 1] if first > 0 else " "
        if cur and (prev.isalnum() or prev == "_"):          # amount_usd 742.6: the code belongs to the name
            cur, sign, start = None, None, m.start("num")
            first = start
            prev = masked[first - 1] if first > 0 else " "
        after = masked[m.end():m.end() + 1]
        if prev.isalnum() or prev in "_." or (after and (after.isalnum() or after == "_")):
            continue
        digits = m.group("num")
        unit, mult = _unit_of(m.group("unit"), m.group("scale"), cur or m.group("cur2") or m.group("cur3"))
        dec = len(digits.split(".")[1]) if "." in digits else 0
        e = int(m.group("exp")[1:]) if m.group("exp") else 0
        x = float(digits.replace(",", "")) * 10 ** e * mult
        if not sign and unit in ("mm", "fx") and prev == "(" and after == ")":
            sign = "-"
        n = Number(text[start:m.end()], start, m.end(), -x if sign == "-" else x, unit, max(0, dec - e),
                   0.5 * 10 ** -dec * 10 ** e * mult, sign=sign or "")
        raw.append((n, mult, bool(cur or m.group("cur2") or m.group("cur3"))))
    for (a, _, a_cur), (b, b_mult, _) in zip(raw, raw[1:]):
        gap = masked[a.end:b.start]
        between = _BETWEEN_GAP.match(gap) and re.search(r"between\s*(?:US\$|\$|USD\s?)?$",
                                                        masked[max(0, a.start - 12):a.start], re.I)
        if a.unit == "plain" and b.unit != "plain" and not a_cur and (_RANGE_GAP.match(gap) or between):
            a.unit, a.value, a.tol = b.unit, a.value * b_mult, a.tol * b_mult
    numbers += [n for n, _, _ in raw]
    numbers.sort(key=lambda n: n.start)
    list_markers = {m.start(1) for m in _LIST_MARKER.finditer(masked)}
    for n in numbers:
        if n.kind != "number":
            continue
        before, after = masked[max(0, n.start - 16):n.start], masked[n.end:n.end + 16]
        if n.unit == "plain" and n.decimals == 0 and "," not in n.text and float(n.value).is_integer() \
                and 1900 <= n.value <= 2100 and not n.sign and re.fullmatch(r"\d{4}", n.text):
            n.exempt = "year"
        elif n.unit == "pct" and float(n.value) in CONFIDENCE_LEVELS and _CONFIDENCE_CONTEXT.search(before + " " + after):
            n.exempt = "confidence level"
        elif n.unit == "plain" and n.decimals == 0 and _HORIZON_AFTER.match(after):
            n.exempt = "horizon"
        elif n.start in list_markers:
            n.exempt = "list marker"
    return numbers


# ---------------------------------------------------------------- measures and labels

def measure_mentions(text: str) -> list[tuple[int, int, str]]:
    """(start, end, measure) of every risk-measure name in `text`, non-overlapping, L-VaR before VaR."""
    out: list[tuple[int, int, str]] = []
    for key, rx in _MEASURE_RXS:
        for m in rx.finditer(text):
            if not any(a < m.end() and m.start() < b for a, b, _ in out):
                out.append((m.start(), m.end(), key))
    return sorted(out)


def field_measure(name: str) -> str:
    """The risk measure a field name belongs to ("" for none): var99_mm -> var, es99_mm -> es, lvar99_mm -> lvar,
    expected_loss_mm / el_mm -> el, pd_default / delta_pd -> pd, lgd -> lgd, pnl_mm -> pnl, utilisation -> limit."""
    n = str(name or "").lower()
    if "lvar" in n or "l_var" in n:
        return "lvar"
    if n.startswith("les") or "_les" in n:
        return "les"
    if "cvar" in n or n.startswith("es") or "_es" in n or "shortfall" in n:
        return "es"
    if "var" in n and "variance" not in n:
        return "var"
    if "expected_loss" in n or n == "el" or n.startswith("el_") or n.endswith("_el") or "_el_" in n or n.startswith("el9"):
        return "el"
    if n.startswith("pd") or "_pd" in n:
        return "pd"
    if "lgd" in n:
        return "lgd"
    if "pnl" in n or "p_l" in n or "p&l" in n:
        return "pnl"
    if "util" in n or "usage" in n or "limit" in n:
        return "limit"
    return ""


_UNIT_SUFFIX = re.compile(r"_(?:mm|pct|pp|bps?|frac|usd)$")
_MEASURE_TOKEN = re.compile(r"^(lvar|les|cvar|var|es|el|pd|lgd|pnl)(\d+(?:\.\d+)?)?$")


def field_label(name: str) -> str:
    """The canonical label of a field, always naming its measure: var99_mm -> "VaR99", es99_mm -> "ES99",
    expected_loss_mm -> "EL", lvar99_mm -> "L-VaR99", pd_12m -> "PD 12m", stress_pnl_mm -> "stress P&L",
    var99_change_mm -> "VaR99 change", composite -> "composite"."""
    m = field_measure(name)
    n = _UNIT_SUFFIX.sub("", str(name or "").lower()).replace("expected_loss", "el")
    toks = []
    for t in n.split("_"):
        mt = _MEASURE_TOKEN.match(t)
        key = {"cvar": "es"}.get(mt.group(1), mt.group(1)) if mt else ""
        toks.append(MEASURE_LABELS[key] + (mt.group(2) or "") if mt and key == m else t)
    label = " ".join(x for x in toks if x)
    if m and MEASURE_LABELS[m] not in label:
        label = f"{MEASURE_LABELS[m]} {label}".strip()
    return label


# Field-name words that say nothing about what a number is: a field made only of these needs a measure or metric from
# its value ({value, unit, label}) or its row (labels.measure / labels.metric), else the slot is refused.
GENERIC_FIELD_WORDS = frozenset((
    "value", "val", "values", "before", "after", "change", "chg", "delta", "diff", "first", "order", "limit", "score",
    "indicator", "amount", "level", "figure", "number", "metric", "result", "total", "sum", "x", "y", "n", "raw",
    "book", "current", "prior", "previous", "new", "old", "base", "mm", "pct", "bp", "bps", "pp", "frac", "usd", "v",
    "data", "stat", "statistic", "measure", "out", "output", "input", "est", "estimate", "fitted", "gap", "move",
    "shift", "impact", "contrib", "contribution", "share", "ratio", "rate", "count", "main", "headline", "key",
))


def _humanise(name: str) -> str:
    return " ".join(t for t in _UNIT_SUFFIX.sub("", str(name or "").lower()).split("_") if t)


def value_label(name: str, meta_label: str = "", row_measure: str = "", row_metric: str = "") -> str:
    """The label shown with a number, always saying what it is, or "" when nothing does (the slot is then refused,
    unlabelled_slot). In order: an explicit label on the value; the field name when it names a risk measure
    (field_label); the row's measure (labels.measure, a field-like key such as var99_mm) before the field's own words
    ("VaR99 limit", "EL before"); the row's metric (labels.metric, "beer fitted gap"); the field name when it is not
    made only of generic words (GENERIC_FIELD_WORDS: value, before, change, limit, score, ...)."""
    if meta_label:
        return normalise_text(str(meta_label)).strip()
    if field_measure(name) and not (row_measure and field_measure(name) == "limit"):
        return field_label(name)                   # "limit_mm" in a limit/var99_mm row is "VaR99 limit"
    words = _humanise(name).split()
    own = [w for w in words if w != "value"]
    if row_measure:
        head = field_label(row_measure) if field_measure(row_measure) else _humanise(row_measure)
        return " ".join([head] + [w for w in own if w not in _humanise(row_measure).split()]).strip()
    if row_metric:
        return " ".join([_humanise(row_metric)] + [w for w in own if w not in _humanise(row_metric).split()]).strip()
    if words and not all(w in GENERIC_FIELD_WORDS or w.isdigit() for w in words):
        return field_label(name)
    return ""


def label_measures(v: Value) -> set:
    """The measures a shown number may be called by: its own measure and every measure its label names."""
    out = {v.measure} if v.measure else set()
    text = v.printed or v.label or field_label(v.name)
    text = re.sub(r"(?<=[A-Za-z])\d+(?:\.\d+)?", "", text)                    # VaR99 -> VaR
    out |= {k for _, _, k in measure_mentions(text)}
    if re.search(r"\blimits?\b", text, re.I):
        out.add("limit")
    return out


def _fmt_plain(v: float, signed: bool) -> str:
    if float(v).is_integer() and abs(v) < 1e15:
        return f"{int(v):+,}" if signed else f"{int(v):,}"
    if abs(v) >= 1:
        return f"{v:+,.2f}" if signed else f"{v:,.2f}"
    return f"{v:+.4g}" if signed else f"{v:.4g}"


def render_value(v: Value, src: Source | None = None) -> str:
    """How the gate shows one field: label, signed value and unit, then the provenance. Units are the row's
    (B-0145 units, else the name rules): fraction as %, mm as $mm, pct %, pp, bp, count, plain, date, text."""
    if v.unit in ("date", "text"):
        return str(v.value)
    if v.printed:                                  # a number printed in a source text: its clause, as printed
        body = v.printed
    else:
        body = f"{v.label or field_label(v.name)} {number_text(v)}"
    prov = []
    if src is not None:
        if src.run_id:
            prov.append(f"run {src.run_id}")
        elif src.source_id or src.tool:
            prov.append(src.source_id or src.tool)
        if src.as_of:
            prov.append(f"as of {src.as_of}")
    return body + (f" ({', '.join(prov)})" if prov else "")


def number_text(v: Value, always_sign: bool = False) -> str:
    """The value with its unit as the gate prints it: signed for P&L / change fields (or always_sign), fraction as
    %, mm as $mm, the engine cap label for a capped PD. A number printed in a source text is returned as printed."""
    if v.printed:
        return v.printed
    x = float(v.value)
    signed = always_sign or bool(_SIGNED_FIELD.search(v.name))
    if v.unit == "mm":
        num = f"{x:+,.2f} $mm" if signed else f"{x:,.2f} $mm"
    elif v.unit == "fraction":
        num = f"{x * 100:+.2f}%" if signed else f"{x * 100:.2f}%"
    elif v.unit == "pct":
        num = f"{x:+.2f}%" if signed else f"{x:.2f}%"
    elif v.unit == "pp":
        num = f"{x:+.2f}pp"
    elif v.unit == "bp":
        num = f"{x:+,.0f}bp" if signed else f"{x:,.0f}bp"
    elif v.unit == "count":
        num = f"{x:+,.0f}" if signed else f"{x:,.0f}"
    else:
        num = _fmt_plain(x, signed)
    if v.measure == "pd" and v.unit in ("fraction", "pct") and at_pd_cap(x if v.unit == "fraction" else x / 100):
        num += f" {PD_CAP_LABEL}"
    return num


# ---------------------------------------------------------------- sources

_META = {"labels", "licence_ids", "trust", "scope", "client_scope", "status", "reason", "args", "ok", "label",
         "row_count", "dropped_rows", "result_sha256", "published_utc", "retrieved_utc", "provenance", "country",
         "cite_id", "citation_id", "id", "source_id", "chunk_id", "citation", "tool", "run_id", "file", "row", "as_of",
         "licence_class", "client_output", "licence", "license", "licence_tag", "internal_only", "text", "values",
         "rows", "schema", "kind", "title", "measure", "metric"}
_ALLOWED_TAGS = {"allowed", "client", "client_ok", "client-ok", "client_safe", "client-safe", "public", "open"}
_RESTRICTED_TAGS = {"restricted", "internal", "internal-only", "internal_only", "licensed", "non-commercial",
                    "noncommercial", "nda"}


def _licence_class(d: Mapping, register: list[dict] | None) -> str:
    """allowed | restricted | barred | unknown, from licence_class / client_output (C14 values), internal_only, a chunk
    scope (A-0144) or a licence tag; a tag the gate does not know is looked up in the register when one is given."""
    if d.get("internal_only") in (True, "yes", "true", "True", 1):
        return "restricted"
    for k in ("licence_class", "client_output"):
        v = str(d.get(k) or "").strip().lower()
        if v in LICENCE_CLASSES:
            return v
    scope = str(d.get("scope") or "").strip().lower()
    if scope in ("client_ok", "client"):
        return "allowed"
    if scope == "internal":
        return "restricted"
    tag = str(next((d.get(k) for k in ("licence_tag", "licence", "license") if d.get(k)), "") or "").strip()
    t = tag.lower()
    if t in _ALLOWED_TAGS:
        return "allowed"
    if t in _RESTRICTED_TAGS:
        return "restricted"
    if t == "barred":
        return "barred"
    if tag and register:
        from ..ingestion.licences import licence_for
        r = licence_for(licence=tag, source=tag, register=register)
        if r and str(r.get("client_output") or "") in LICENCE_CLASSES:
            return "restricted" if str(r.get("internal_use", "yes")) == "no" else str(r["client_output"])
    return "unknown"


def _unit_from_name(name: str) -> str:
    n = name.lower()
    if n.endswith("_pct") or n.endswith("pct"):
        return "pct"
    if n.endswith("_pp"):
        return "pp"
    if n.endswith("_bp") or n.endswith("_bps"):
        return "bp"
    if n.endswith("_mm"):
        return "mm"
    if n.startswith("pd") or "_pd" in n or "lgd" in n or "prob" in n or "share" in n or n.endswith("_frac") \
            or n in ("utilisation", "utilization", "var_scale", "exception_rate"):
        return "fraction"
    if n.startswith("n_") or n.endswith("_count") or n in ("paths", "count", "n"):
        return "count"
    return "plain"


def _date_text(v) -> str | None:
    s = str(v or "").strip()
    m = re.match(r"^(\d{4})-(\d{2})-(\d{2})", s)
    return _iso(*m.groups()) if m else None


def _num(v):
    if isinstance(v, bool):
        return None
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    return None if math.isnan(x) or math.isinf(x) else x


def _values_of(cid: str, d: Mapping) -> list[Value]:
    out: list[Value] = []
    vals = d.get("values")
    items = vals.items() if isinstance(vals, Mapping) else ((k, v) for k, v in d.items() if k not in _META)
    labels = d.get("labels") if isinstance(d.get("labels"), Mapping) else {}
    row_measure = str(labels.get("measure") or d.get("measure") or "")
    row_metric = str(labels.get("metric") or d.get("metric") or "")
    for name, v in items:
        unit, meta_label, meta_measure = None, "", ""
        if isinstance(v, Mapping):
            unit, meta_label = (str(v.get("unit") or "") or None), str(v.get("label") or "")
            meta_measure = str(v.get("measure") or "")
            v = v.get("value")
        x = _num(v)
        if x is not None and not isinstance(v, str):
            u = unit if unit in UNITS else _unit_from_name(str(name))
            rm = meta_measure or row_measure
            lab = value_label(str(name), meta_label, rm, "" if rm else row_metric)
            meas = field_measure(str(name)) or field_measure(rm) or field_measure(row_metric) \
                or next((k for _, _, k in measure_mentions(re.sub(r"(?<=[A-Za-z])\d+", "", lab))), "")
            out.append(Value(cid, str(name), x, u, measure=meas, label=lab))
        elif isinstance(v, str):
            iso = _date_text(v)
            out.append(Value(cid, str(name), iso or normalise_text(v), "date" if iso else "text"))
    out += [Value(cid, str(k), normalise_text(v), "text") for k, v in labels.items() if isinstance(v, str)]
    return out


_TEXT_BREAK = re.compile(r"[,;:()\[\]\u2013\u2014!?|\n]|\.(?=\s|$)|\s-\s|\b(?:and|or|but|while|whereas)\b", re.I)
_KV_LINE = re.compile(r"^[ \t]*(?P<name>[A-Za-z][A-Za-z0-9_]*)[ \t]*[:=]?[ \t]*$")
_KV_UNIT = {"mm": " $mm", "pct": "%", "pp": "pp", "bp": "bp"}
CONTEXT_WORDS_BEFORE = 6
CONTEXT_WORDS_AFTER = 4


def _text_values(cid: str, text: str) -> list[Value]:
    """Numbers printed in a source text (slot fields t1, t2, ... in order). Each is shown with its own clause as
    printed: up to six words before it (back to the clause start or the previous number) and up to four after it (to the
    clause end or the next number), so the source's own words name the figure ("gross notional $1,234.50mm", "spread
    850 bps"). Dates and exempt numbers (confidence levels, years, horizons, list markers) are not slot fields."""
    out = []
    numbers = extract_numbers(text)
    cuts = [(n.start, n.end) for n in numbers if n.kind != "date" and not n.exempt]
    for n in numbers:
        if n.kind == "date" or n.exempt:
            continue
        ls = text.rfind("\n", 0, n.start) + 1
        le = text.find("\n", n.end)
        kv = _KV_LINE.match(text[ls:n.start])
        if kv and not text[n.end: le if le >= 0 else len(text)].strip():
            name = kv.group("name")                     # var99_mm: 73.1075 -> "VaR99 73.1075 $mm" (its own name)
            low = name.lower()
            unit = " USD" if low.endswith("_usd") or low == "usd" else _KV_UNIT.get(_unit_from_name(name), "")
            label = field_label(name) if field_measure(name) else _humanise(re.sub(r"_usd$", "", name, flags=re.I))
            out.append(Value(cid, "text", n.value, n.unit, None if n.kind == "word_fraction" else n.decimals,
                             field_measure(name), printed=f"{label} {n.text}{unit}".strip()))
            continue
        head = re.match(r"^[ \t]*(?P<name>[A-Za-z][A-Za-z0-9_]*)[ \t]*:", text[ls:n.start])
        lo = max([m.end() for m in _TEXT_BREAK.finditer(text, 0, n.start)] + [e for s, e in cuts if e <= n.start] + [0])
        nxt = _TEXT_BREAK.search(text, n.end)
        hi = min([nxt.start() if nxt else len(text)] + [s for s, e in cuts if s >= n.end])
        before = text[lo:n.start].split()[-CONTEXT_WORDS_BEFORE:]
        after = text[n.end:hi].split()[:CONTEXT_WORDS_AFTER]
        shown = " ".join(before + [n.text] + after)
        mentions = measure_mentions(" ".join(before))
        meas = mentions[-1][2] if mentions else ""
        if head and "_" in head.group("name") and lo <= ls + head.end():    # top_default_pd: Venezuela 0.99 -> its name first
            name = head.group("name")
            shown = f"{field_label(name) if field_measure(name) else _humanise(name)} {shown}"
            meas = field_measure(name) or meas
        out.append(Value(cid, "text", n.value, n.unit, None if n.kind == "word_fraction" else n.decimals, meas,
                         printed=shown))
    return out


def _cite_id(d: Mapping) -> str:
    c = d.get("citation") if isinstance(d.get("citation"), Mapping) else {}
    for v in (d.get("cite_id"), d.get("citation_id"), c.get("cite_id"), c.get("id"), d.get("id"), d.get("chunk_id"),
              d.get("source_id")):
        if v not in (None, ""):
            return str(v).strip()
    return ""


def _as_mapping(o) -> Mapping | None:
    if isinstance(o, Mapping):
        return o
    if is_dataclass(o) and not isinstance(o, type):
        return asdict(o)
    if callable(getattr(o, "to_dict", None)):
        d = o.to_dict()
        return d if isinstance(d, Mapping) else None
    return None


def normalise_sources(tool_results: Iterable = (), chunks: Iterable = (), register: list[dict] | None = None,
                      every: list | None = None) -> tuple[dict, list[dict]]:
    """({cite_id: Source}, problems) from tool results (a result dict with `rows`, or rows) and context chunks.
    A row or chunk without an id cannot be cited (missing_citation_id); a repeated id keeps the first
    (duplicate_citation_id). Texts are normalised. `every`, when given, receives every source read, including those
    without an id and the shadowed duplicates (the client checks count them all)."""
    out: dict[str, Source] = {}
    problems: list[dict] = []

    def add(src: Source):
        if every is not None:
            every.append(src)
        if not src.cite_id:
            problems.append({"code": "missing_citation_id",
                             "detail": f"a {src.kind} without an id ({src.licence_class}): it cannot be cited"})
            return
        if src.cite_id in out:
            problems.append({"code": "duplicate_citation_id", "detail": src.cite_id})
            return
        out[src.cite_id] = src

    for res in tool_results or ():
        res = _as_mapping(res)
        if res is None:
            continue
        rows = res.get("rows") if isinstance(res.get("rows"), list) else [res]
        for r in rows:
            r = _as_mapping(r)
            if r is None:
                continue
            c = r.get("citation") if isinstance(r.get("citation"), Mapping) else {}
            merged = {**{k: v for k, v in res.items() if k != "rows"}, **c, **r}
            cid = _cite_id(r) or _cite_id(c)
            text = normalise_text(str(r.get("text") or ""))
            src = Source(cid, "tool", tool=str(merged.get("tool") or ""), run_id=str(merged.get("run_id") or ""),
                         file=str(merged.get("file") or ""), row=str(merged.get("row") if merged.get("row") is not None else ""),
                         as_of=str(merged.get("as_of") or ""), licence_class=_licence_class(merged, register),
                         source_id=str(merged.get("source_id") or ""), text=text)
            src.values = _values_of(cid, r) + _text_values(cid, text)
            add(src)
    for ch in chunks or ():
        ch = _as_mapping(ch)
        if ch is None:
            continue
        cid = _cite_id(ch)
        text = normalise_text(str(ch.get("text") or ""))
        src = Source(cid, "chunk", run_id=str(ch.get("run_id") or ""), file=str(ch.get("file") or ""),
                     row=str(ch.get("row") if ch.get("row") is not None else ""), as_of=str(ch.get("as_of") or ""),
                     licence_class=_licence_class(ch, register), source_id=str(ch.get("source_id") or ""), text=text)
        src.values = (_values_of(cid, ch["values"]) if isinstance(ch.get("values"), Mapping) else []) \
            + _text_values(cid, text)
        add(src)
    for s in out.values():
        iso = _date_text(s.as_of)
        if iso:
            s.values.append(Value(s.cite_id, "as_of", iso, "date"))
    return out, problems


# ---------------------------------------------------------------- sentences

def split_sentences(text: str) -> list[tuple[int, int]]:
    """(start, end) spans of the sentences of `text`. Lines are joined into a paragraph unless the line is blank, a list
    item, a table row or a heading, or the previous line ends with . ! ? : or is a table row. Inside a paragraph a
    sentence ends at . ! ? followed by space and a capital, digit, quote, bracket, brace or bullet; citation markers
    right after the full stop stay with the sentence they follow; abbreviations and dotted acronyms do not end a
    sentence. A table row is one sentence."""
    spans: list[tuple[int, int]] = []
    paras: list[tuple[int, int]] = []
    lines = [m for m in re.finditer(r"[^\n]*(?:\n|$)", text) if m.start() != m.end()]
    cur: list[int] | None = None
    prev_txt = ""
    for ln in lines:
        body = ln.group(0).rstrip("\n")
        stripped = body.strip()
        prev_end = _CITE_RX.sub("", prev_txt).rstrip()
        boundary = (cur is None or not stripped or not prev_txt.strip() or _BLOCK_START.match(body)
                    or prev_txt.lstrip().startswith("|") or prev_end.endswith((".", "!", "?", ":")))
        if boundary and cur is not None:
            paras.append((cur[0], cur[1]))
            cur = None
        if stripped:
            if cur is None:
                cur = [ln.start(), ln.start() + len(body)]
            else:
                cur[1] = ln.start() + len(body)
        prev_txt = body
    if cur is not None:
        paras.append((cur[0], cur[1]))
    for a, b in paras:
        if text[a:b].lstrip().startswith("|"):
            spans.append((a + len(text[a:b]) - len(text[a:b].lstrip()), b))
            continue
        seg_start = a
        for m in _SENT_END.finditer(text, a, b):
            nxt = text[m.end():m.end() + 1]
            if not nxt or not re.match(r"[A-Z0-9\"'(\[{*\u2022\u201c-]", nxt) \
                    or re.match(r"\[(?:cite|chunk):", text[m.end():m.end() + 7], re.I):
                continue
            head = text[seg_start:m.start() + 1]
            if any(head.endswith(x) for x in _ABBREV) or re.search(r"(?:\b[A-Za-z]\.){2,}$", head):
                continue
            spans.append((seg_start, m.start("ws")))
            seg_start = m.end()
        end = b
        while end > seg_start and text[end - 1] in " \t\r\n":
            end -= 1
        while seg_start < end and text[seg_start] in " \t\r\n":
            seg_start += 1
        if end > seg_start:
            spans.append((seg_start, end))
    return spans


def _words(s: str) -> list[str]:
    return re.findall(r"\w+", (s or "").lower())


def _shares_words(text: str, source_text: str, n: int = SHINGLE_WORDS) -> bool:
    w = _words(text)
    if len(w) < n or not source_text:
        return False
    low = " " + " ".join(_words(source_text)) + " "
    return any(" " + " ".join(w[i:i + n]) + " " in low for i in range(len(w) - n + 1))


def _injection_hits(text: str, sources: dict) -> list[tuple[str, str]]:
    hits = [(name, m.group(0)) for name, rx in INJECTION_PATTERNS for m in [rx.search(text)] if m]
    given = " ".join(s.text for s in sources.values())
    for m in _URL_RX.finditer(text):
        if m.group(0) not in given:
            hits.append(("link", m.group(0)))
    return hits


def _echo_source(sentence: str, sources: dict) -> str:
    for s in sources.values():
        if s.text and any(rx.search(s.text) for _, rx in INJECTION_PATTERNS) and _shares_words(sentence, s.text):
            return s.cite_id
    return ""


def _name_scan_text(body: str) -> str:
    """Restricted-name scan text: letters collapsed (W E O, W-E-O), dotted acronyms collapsed, hyphens between words
    read as spaces, institutional facts removed (FACT_EXEMPT)."""
    s = collapse_letters(body)
    s = _DOTTED_ACRONYM.sub(lambda m: m.group(0).replace(".", ""), s)
    s = re.sub(r"(?<=[A-Za-z])-(?=[A-Za-z])", " ", s)
    return FACT_EXEMPT.sub(" ", s)


def _mixed_script_words(text: str) -> list[str]:
    """Words that mix ASCII letters with other letters after normalisation (look-alikes the map does not know)."""
    return [w for w in re.findall(r"[^\W\d_]+", text) if any(c.isascii() for c in w) and any(not c.isascii() for c in w)]


# ---------------------------------------------------------------- the gate

def _snip(s: str, n: int = 120) -> str:
    s = " ".join(s.split())
    return s if len(s) <= n else s[:n - 3] + "..."


def _refusal(codes: list[str]) -> str:
    return REFUSAL_TEXT.format(codes=", ".join(dict.fromkeys(codes)) or "refused")


def label_text(body: str, citations: list[dict], figures: list[str] | None = None) -> str:
    """The text shown: the label line, the body, the gate's Figures list (one line per slot) and the citations."""
    lines = [LABEL, "", body.rstrip(), "", "Figures:"]
    lines += [f"- {f}" for f in figures or ()] or ["- none"]
    lines += ["", "Citations:"]
    if not citations:
        lines.append("- none")
    for c in citations:
        parts = [f"[cite:{c['cite_id']}]"] + [f"{k} {c[k]}" for k in ("tool", "source_id", "run_id", "file", "row", "as_of")
                                               if c.get(k)]
        lines.append("- " + "; ".join(parts))
    return "\n".join(lines)


def figure_line(v: Value, src: Source) -> str:
    """One line of the Figures list: full label, signed value and unit, run id, as_of and source."""
    if v.unit in ("date", "text"):
        head = f"{v.name}: {v.value}"
    elif v.printed:
        head = f"{v.printed} (as printed in the source text)"
    else:
        head = f"{v.label or field_label(v.name)}: {number_text(v, always_sign=True)}"
    where = [f"run {src.run_id}" if src.run_id else "", f"as_of {src.as_of}" if src.as_of else "",
             "source " + " ".join(x for x in (f"[cite:{src.cite_id}]", src.tool, src.source_id, src.file, src.row) if x)]
    return head + "; " + "; ".join(w for w in where if w)


_BACKREF = re.compile(r"^\s*(?:it|this|that|these|those|which|such|the (?:figure|number|value|amount|estimate|result|"
                      r"metric|measure|reading))\b", re.I)


_SPLIT_MEASURES = ((re.compile(r"value\s*@?\s*at\s*risk|value\s*@\s*risk", re.I), "value at risk"),
                   (re.compile(r"expected\s*shortfall", re.I), "expected shortfall"),
                   (re.compile(r"expected\s*loss", re.I), "expected loss"),
                   (re.compile(r"loss\s*given\s*default", re.I), "loss given default"),
                   (re.compile(r"probability\s*of\s*default", re.I), "probability of default"),
                   (re.compile(r"\bv\s*a\s*r(?=s?\b)", re.I), "VaR"))


def measure_scan_text(text: str) -> str:
    """The model's words as the measure check reads them (HO-20261027-B-B-018): letters collapsed (V.a.R, W E O),
    whitespace runs and line breaks as one space, '@' between letters as 'a' (V@R) and alone as 'at' (Value @ Risk),
    dotted acronyms joined (E.S.), split or joined names rejoined (Va R, valueatrisk, expectedshortfall)."""
    t = collapse_letters(text or "")
    t = re.sub(r"\s+", " ", t)
    t = re.sub(r"(?<=[A-Za-z])@(?=[A-Za-z])", "a", t)
    t = re.sub(r"\s@\s", " at ", t)
    t = _DOTTED_ACRONYM.sub(lambda m: m.group(0).replace(".", ""), t)
    for rx, sub in _SPLIT_MEASURES:
        t = rx.sub(sub, t)
    return t


def _named_measures(text: str) -> set:
    t = measure_scan_text(text)
    t = re.sub(r"(?<=[A-Za-z])\d+(?:\.\d+)?", "", t)
    out = {k for _, _, k in measure_mentions(t)}
    if re.search(r"\blimits?\b", t, re.I):
        out.add("limit")
    return out


def _table_header_cell(text: str, pos: int) -> str:
    """For a slot at `pos` inside a markdown table body row: the header cell of its column ("" otherwise)."""
    ls = text.rfind("\n", 0, pos) + 1
    line_end = text.find("\n", pos)
    line = text[ls: line_end if line_end >= 0 else len(text)]
    if not line.lstrip().startswith("|"):
        return ""
    start = ls
    while start > 0:
        prev_s = text.rfind("\n", 0, start - 1) + 1
        if not text[prev_s:start - 1].lstrip().startswith("|"):
            break
        start = prev_s
    if start == ls:
        return ""
    header = text[start: text.find("\n", start)]
    col = text[ls:pos].count("|") - 1
    cells = header.strip().strip("|").split("|")
    return cells[col] if 0 <= col < len(cells) else ""


def _non_latin(text: str) -> list[str]:
    """Letters and numerals of a non-Latin script (after normalisation): the desk writes English."""
    bad = []
    for ch in text:
        cat = unicodedata.category(ch)
        if ch.isascii() or not (cat.startswith("L") or cat.startswith("N")):
            continue
        if cat.startswith("L") and unicodedata.name(ch, "").startswith("LATIN"):
            continue
        bad.append(ch)
    return bad


def check_answer(answer: str, tool_results: Iterable = (), chunks: Iterable = (), audience: str = "internal",
                 register: list[dict] | None = None, kind: str = "answer") -> QAResult:
    """Gate one assistant answer or draft against the tool results and context chunks the model was given.

    The model writes figures only as slots `{{cite_id.field}}`; the gate renders them (render_value) and lists them
    under Figures. `audience` "client" refuses when any non-allowed, id-less or duplicated row or chunk was given at
    all, and also applies the restricted-name scan and the copied-text check. `register` (C14 rows, optional) adds the
    register's restricted names and resolves licence tags. Returns a QAResult whose cleaned_text is the label line, the
    normalised text with slots rendered, the Figures list and the citations; on refusal it is the label line and the refusal text."""
    if audience not in AUDIENCES:
        raise ValueError(f"audience {audience!r} not in {AUDIENCES}")
    if kind not in KINDS:
        raise ValueError(f"kind {kind!r} not in {KINDS}")
    text = normalise_text(answer if isinstance(answer, str) else "")
    every: list[Source] = []
    sources, src_problems = normalise_sources(tool_results, chunks, register, every=every)
    reasons: list[dict] = [{"code": p["code"], "action": POLICY[p["code"]], "sentence": -1, "text": "", "detail": p["detail"]}
                           for p in src_problems]
    slots: list[Slot] = []
    found: list[dict] = []

    def give(code, i=-1, s="", detail=""):
        reasons.append({"code": code, "action": POLICY[code], "sentence": i, "text": _snip(s), "detail": detail})

    def finish(cleaned: str, cites: list) -> QAResult:
        acts = {r["action"] for r in reasons}
        verdict = "refused" if REFUSE in acts else "pass_with_removals" if REMOVE in acts else "pass"
        if verdict == "refused":                   # labelled too (B-B-016 / B-B-004 item 1): every answer is
            cleaned = f"{LABEL}\n\n" + _refusal([r["code"] for r in reasons if r["action"] == REFUSE])
            cites = []
        return QAResult(verdict, cleaned, reasons, cites, found, audience=audience, kind=kind, slots=slots)

    if not text.strip():
        give("empty")
        return finish("", [])
    if len(text) > MAX_CHARS:
        give("too_long", detail=f"{len(text)} > {MAX_CHARS} characters")
        return finish("", [])
    restricted = [s for s in every if s.licence_class != "allowed"]
    if audience == "client":
        unindexed = [p for p in src_problems if p["code"] in ("missing_citation_id", "duplicate_citation_id")]
        if restricted or unindexed:
            give("client_context", detail="the model's context holds "
                 + ", ".join([f"[cite:{s.cite_id or '?'}] {s.licence_class}" for s in restricted[:6]]
                             + [f"{p['code']} {p['detail']}" for p in unindexed[:4]])
                 + " (a client surface must give the model only allowed rows and chunks, each with its own id)")
    given_runs = {s.run_id for s in every if s.run_id}
    for s in every:
        given_runs.update(extract_run_ids(s.text))
    names_rx = restricted_name_patterns(register) if register else []

    slot_spans = extract_slots(text)
    model = _blank(text, [(a, b) for a, b, _, _ in slot_spans], _SLOT_MASK)   # the model's own text
    model = _blank(model, [m.span() for m in _CITE_RX.finditer(model)])
    if _non_latin(model):
        give("non_latin_text", detail=f"letters or numerals of a non-Latin script: {_non_latin(model)[:8]}")
    spans = split_sentences(text)
    rendered: dict[int, str] = {}
    remove: dict[int, str] = {}
    content = 0
    prev_measures: set | None = None            # measures of the numeric slots of the previous sentence
    for i, (a, b) in enumerate(spans):
        sent, own = text[a:b], model[a:b]
        scan = collapse_letters(own)
        if own.strip(" \t.-*•|:"):
            content += 1
        ids = [x.strip() for m in _CITE_RX.finditer(sent) for x in re.split(r"[,;]", m.group(1)) if x.strip()]
        for x in dict.fromkeys(ids):
            if x not in sources or not _CITE_ID_RX.match(x):
                give("fabricated_citation", i, sent, f"[cite:{x}] was not given to the model")
        cited = [sources[x] for x in dict.fromkeys(ids) if x in sources]
        numeric: list[tuple[int, int, set, Slot]] = []          # (start, end, measures, slot) in sentence offsets
        for sa, sb, cid, fld in slot_spans:
            if not (a <= sa < b):
                continue
            sl = Slot(text[sa:sb], cid, fld, i)
            src = sources.get(cid)
            v = src.fields().get(fld) if src else None
            if v is None:
                sl.status = "unknown"
                give("unknown_slot", i, sent, f"{sl.text}: " + ("no row or chunk with this id was given" if src is None
                                                               else f"[cite:{cid}] has no field {fld!r}"))
            elif v.unit not in ("date", "text") and not (v.printed or v.label):
                sl.status = "unknown"
                give("unlabelled_slot", i, sent, f"{sl.text}: the field names no measure or metric (the row needs "
                                                 f"labels.measure / labels.metric or a field name that says what it is)")
            else:
                sl.status, sl.rendered = "rendered", render_value(v, src)
                rendered[sa] = sl.rendered
                cited.append(src)
                if v.unit not in ("date", "text"):
                    numeric.append((sa - a, sb - a, label_measures(v), sl))
            slots.append(sl)
        if re.search(r"[{}]", own):
            give("bad_slot", i, sent, "braces that are not a well-formed slot {{cite_id.field}}")
        toks = [m.group(0) for m in _MODEL_NUMERIC.finditer(scan)]
        if toks:
            found.extend({"text": t, "sentence": i, "status": "refused"} for t in toks)
            give("model_number", i, sent, f"numeric text outside a slot: {toks[:6]} (figures must be slots)")
        for rid in extract_run_ids(own):
            if rid not in given_runs:
                give("fabricated_run_id", i, sent, f"run id {rid} is in no tool result or chunk")
        if _SLOT_MASK in own:                                   # valence: the whole sentence of a slot
            c = collapse_letters(own)
            c = _blank(c, [(x, y) for x, y, _ in measure_mentions(c)])
            m = _VALENCE.search(c)
            if m:
                give("slot_direction", i, sent, f"{m.group(0)!r} in the sentence of a slot: the rendered value carries "
                                                f"its own sign")
        # measure consistency (slot_relabel): the words before a slot in its clause, the whole sentence, a table
        # column header and a following renaming sentence may name only the slots' own measures
        if numeric:
            allowed = set().union(*(ms for _, _, ms, _ in numeric))
            bounds = [0] + [mm.end() for mm in _CLAUSE_SPLIT.finditer(own)]
            prev_end = 0
            for sa, sb, ms, sl in numeric:
                lo = max([x for x in bounds if x <= sa] + [prev_end])
                named_before = _named_measures(own[lo:sa].replace(_SLOT_MASK, " "))
                header = _table_header_cell(model, a + sa)
                named_head = _named_measures(header) if header else set()
                bad = (named_before - ms) | (named_head - ms)
                if bad:
                    give("slot_relabel", i, sent, f"{sl.text} is {sorted(ms) or 'no risk measure'}; the text calls it "
                                                  f"{sorted(bad)}")
                prev_end = sb
            extra = _named_measures(own.replace(_SLOT_MASK, " ")) - allowed
            if extra:
                give("slot_relabel", i, sent, f"the sentence names {sorted(extra)}; its slots are {sorted(allowed) or 'no risk measure'}")
            prev_measures = allowed
        else:
            if prev_measures is not None and not any(a <= x < b for x, _, _, _ in slot_spans) and _BACKREF.match(own):
                extra = _named_measures(own) - prev_measures
                if extra:
                    give("slot_relabel", i, sent, f"renames the previous sentence's figure as {sorted(extra)}")
            if own.strip(" \t.-*•|:"):
                prev_measures = None
        hits = _injection_hits(scan, sources)
        if hits:
            echo = _echo_source(scan, sources)
            give("injection", i, sent, "; ".join(f"{k}: {_snip(t, 40)}" for k, t in hits)
                 + (f" (echoed from [cite:{echo}])" if echo else ""))
        mixed = _mixed_script_words(own)
        if mixed:
            give("obfuscated_text", i, sent, f"words mixing scripts: {mixed[:4]}")
        why = ""
        if audience == "client":
            nscan = _name_scan_text(own)
            names = sorted({m.group(0) for m in RESTRICTED_SOURCE_TEXT.finditer(nscan)}
                           | {m.group(0) for m in _EXTRA_RESTRICTED.finditer(nscan)}
                           | {f"{sid}: {m.group(0)}" for sid, rx in names_rx for m in [rx.search(nscan)] if m})
            if names:
                give("restricted_name", i, sent, f"names {names[:4]}")
                why = why or "restricted source named"
        if re.search(r"\bhouse\b", own, re.I):
            stated = " ".join([s.text for s in cited] + [str(v.value) for s in cited for v in s.values if v.unit == "text"])
            for st in STANCES:
                if re.search(rf"\b{st}\b", own) and not re.search(rf"\b{st}\b", stated, re.I):
                    give("house_view_unsupported", i, sent, f"house stance {st} is in no cited row")
                    why = why or "house view not in the cited rows"
        if why:
            remove[i] = why

    if audience == "client":                       # second line: copied text of a non-allowed source
        whole = _CITE_RX.sub(" ", model)
        for s in restricted:
            if _shares_words(whole, s.text):
                give("client_scope_leak", -1, "", f"the answer copies {SHINGLE_WORDS}+ words of [cite:{s.cite_id or '?'}]")
    if remove and (len(remove) > MAX_REMOVED_SHARE * content or len(remove) >= content):
        give("too_many_removals", detail=f"{len(remove)} of {content} sentences removed")
    out, last, used = [], 0, []
    for i, (a, b) in enumerate(spans):
        out.append(text[last:a])
        if i in remove:
            out.append(REMOVED_MARKER.format(reason=remove[i]))
        else:
            seg, pos = [], a
            for sa, sb, _, _ in slot_spans:
                if a <= sa < b:
                    seg += [text[pos:sa], rendered.get(sa, text[sa:sb])]
                    pos = sb
            seg.append(text[pos:b])
            out.append("".join(seg))
            used += [x for x in extract_citations(text[a:b]) if x in sources]
        last = b
    out.append(text[last:])
    shown_slots = [s for s in slots if not any(s.sentence == i for i in remove)]
    shown_figures = [figure_line(sources[s.cite_id].fields()[s.field], sources[s.cite_id]) for s in shown_slots
                     if s.status == "rendered"]
    cites = [sources[x].citation() for x in dict.fromkeys(used)]
    return finish(label_text("".join(out), cites, list(dict.fromkeys(shown_figures))), cites)


def render_answer(answer: str, tool_results: Iterable = (), chunks: Iterable = (), audience: str = "internal",
                  register: list[dict] | None = None, kind: str = "answer") -> str:
    """The only text a surface may show: the gate's cleaned_text (label line, slots rendered, citations), or the
    label line and the refusal text (REFUSAL_TEXT with the refusal codes) when the answer is refused."""
    return check_answer(answer, tool_results, chunks, audience=audience, register=register, kind=kind).cleaned_text


def check_draft(draft: str, tool_results: Iterable = (), chunks: Iterable = (), audience: str = "internal",
                register: list[dict] | None = None) -> QAResult:
    """check_answer for a draft note (EQ-B-0148): the same rules; the result says kind "draft"."""
    return check_answer(draft, tool_results, chunks, audience=audience, register=register, kind="draft")
