"""Backtest tooling on the daily forecast record (EQ-B-0141, PI-14): an exception explainer, rolling backtests by
country and by risk factor, and P&L attribution of the recorded losses to realised market moves.

    exception_rows(record, u, settings, prices, as_of)   -> rows (EXCEPTION_COLUMNS), one block per VaR99 exception
    rolling_rows(record, u, settings, prices, as_of)     -> rows (ROLLING_COLUMNS), book / country / factor windows
    pnl_attribution_rows(record, u, prices, as_of)       -> rows (PNL_COLUMNS), explained vs unexplained per day
    demo_backtest_explainer(out_dir, as_of, data_dir=None) -> {"ok", "problems", "paths", "summary", "gaps", ...}
    python -m econquest.validation.backtest_explainer --as-of 2026-10-26 --out outputs/backtest_explainer

Method (docs/validation/backtest-explainer.md):
  * Exceptions are the clean tested days of the record (calendar_tests.clean_days: loss, VaR > 0, ES >= VaR, dated and
    recorded on or before as_of) with recorded loss > recorded VaR99, the same set the INTERIM report counts.
  * Realised side: the loss of day D is a sum over positions, w x log(P_D / P_prev), with the record's own marking
    rules (record.realised_loss: stale, excluded, catch-up). The position losses add up to the book loss exactly.
  * Forecast side: the one-day GARCH-DCC VaR99 / ES99 made on prev for D (record._portfolio_var). It is elliptical per
    block (FX, equity) and the blocks combine as sqrt(V_FX^2 + V_EQ^2), so the Euler allocation that
    portfolio_risk.euler_components estimates from Monte Carlo paths has a closed form here: marginal
    m_t = dV/dw_t = (V_k / V) q_k (Sigma_k w)_t / sqrt(w' Sigma_k w), component of position i = w_i m_t(i). The
    components add up to the VaR exactly (to float rounding; checked). Countries, asset classes and factors are sums of
    position components, so every level adds up too.
  * Recorded or not: the record stores the book totals only (loss, var, es, var_next, es_next, code and data hash).
    It does not store the per-position marks or the GARCH-DCC state of the day, so no day's inputs are recorded. The
    explainer RECONSTRUCTS them from the current engine-readable inputs (data/market_history/prices.csv via
    garch.load_prices, data/portfolio.csv): GARCH-DCC refitted on prices up to the forecast day (refit every `step`
    record days, as backfill_record does; step=1 refits each day) and filtered forward. A day is "reconciled" only
    when the reconstruction reproduces the recorded loss and VaR within RECONCILE_TOL_MM; otherwise each block has a
    "residual" row (recorded minus reconstructed) so that the rows still add up to the recorded numbers, and the
    reconstruction is labelled as not explaining the recorded loss.
  * Rolling backtests: trailing windows of up to `window` clean days ending on each tested day. Book rows use the
    recorded loss and VaR. Country and factor rows use reconstructed losses against the reconstructed STANDALONE
    VaR99 of that country's (factor's) sub-book. Kupiec POF (backtests.kupiec) and the two-sided 95% binomial band.
    Every row is labelled INTERIM while the record has fewer than 250 clean days, and never a formal test result.
  * P&L attribution: explained = sum over risk factors (prices.csv tickers) of exposure x realised log move on the
    record day; unexplained = recorded loss - explained.

Real record only in real runs: demo_backtest_explainer reads <data_dir>/forecast_record.csv. A record carrying the
SYNTHETIC marker (in recorded_at, marks or code_hash, or record.attrs["synthetic"]), or a data_dir other than the
repo's data/, is refused unless running under pytest or inside the calendar rehearsal's temp home
(eq-calendar-rehearsal-*). as_of is required everywhere; the clock is never read; nothing is fetched; nothing is
written outside out_dir (which must be under the repo's outputs/ or outside the repo). Read-only, Tier 3: nothing in
the base run calls this module, so the base numbers are unchanged. Validation never imports presentation.
"""
from __future__ import annotations

import argparse
import json
import math
import os
import tempfile
import warnings
from pathlib import Path

import numpy as np
import pandas as pd

from . import record as R
from .backtests import kupiec
from .calendar_tests import VAR_GATE, WINDOW, _interim_label, clean_days
from .forecast_scorecard import BAND, binomial_band, record_as_of

TICKET = "EQ-B-0141"
SCHEMA = "eq-backtest-explainer/1"
ROOT = Path(__file__).resolve().parents[2]
OUTPUTS_ROOT = ROOT / "outputs"
SUBDIR = "backtest_explainer"
FILES = {"exceptions": "exceptions.csv", "rolling": "rolling.csv", "pnl": "pnl_attribution.csv",
         "json": "backtest_explainer.json", "md": "backtest_explainer.md"}
ALPHA = 0.99
STEP = 21                       # GARCH-DCC refit every 21 record days (record.backfill_record default)
RECONCILE_TOL_MM = 1e-6         # $mm: a reconstruction within this of the recorded loss and VaR is "reconciled"
SUM_TOL_MM = 1e-9               # $mm: components must add up to their total within this
ROLLING_WINDOWS = (20, WINDOW)  # trailing clean days; 250 is the formal window (expanding while the record is shorter)
SYNTHETIC_MARK = "SYNTHETIC"
REHEARSAL_PREFIX = "eq-calendar-rehearsal-"     # calendar_rehearsal.demo_calendar_rehearsal temp home
NOT_RECORDED = ("NOT RECORDED: the record holds the book totals only (loss, var, es, hashes); the day's per-position "
                "marks and GARCH-DCC state were not stored")
STATUS_RECONCILED = "not_recorded_reconstructed_reconciled"
STATUS_UNRECONCILED = "not_recorded_reconstruction_unreconciled"
STATUS_NO_PRICES = "not_recorded_no_prices"

EXCEPTION_COLUMNS = ("as_of", "date", "prev_date", "level", "item", "country", "asset_class", "factor", "factor_type",
                     "exposure_mm", "realised_loss_mm", "forecast_var99_mm", "forecast_es99_mm", "excess_over_var_mm",
                     "share_of_loss", "share_of_var", "rank", "recorded_loss_mm", "recorded_var99_mm",
                     "inputs_status", "basis", "label", "note")
ROLLING_COLUMNS = ("as_of", "end_date", "window", "group_type", "group", "n", "exceptions", "expected",
                   "exception_rate", "kupiec_lr", "kupiec_p", "band_low", "band_high", "band_status", "largest_loss_to_var",
                   "exception_dates", "basis", "label", "note")
PNL_COLUMNS = ("as_of", "date", "level", "item", "country", "factor_type", "exposure_mm", "move_log", "recorded_loss_mm",
               "explained_mm", "unexplained_mm", "explained_share", "recorded_marked_positions", "marked_positions",
               "recorded_marked_notional_mm", "marked_notional_mm", "marks", "basis", "label", "note")
LEVELS = ("book", "position", "country", "asset_class", "factor", "factor_type", "residual")


class SyntheticRefused(ValueError):
    """A SYNTHETIC record (or a non-repo data dir) outside pytest or the calendar rehearsal sandbox."""


# ---------------------------------------------------------------- guards

def _as_of(as_of) -> pd.Timestamp:
    if as_of is None or (isinstance(as_of, str) and not as_of.strip()):
        raise ValueError("as_of is required: the backtest explainer never reads the wall clock")
    return pd.Timestamp(as_of).normalize()


def _d(ts) -> str:
    return "" if ts is None or (not isinstance(ts, str) and pd.isna(ts)) else pd.Timestamp(ts).strftime("%Y-%m-%d")


def in_rehearsal_sandbox(path) -> bool:
    """True when `path` lies inside a calendar rehearsal temp home (<tempdir>/eq-calendar-rehearsal-*)."""
    try:
        p = Path(path).resolve()
        tmp = Path(tempfile.gettempdir()).resolve()
    except OSError:
        return False
    return p.is_relative_to(tmp) and any(part.startswith(REHEARSAL_PREFIX) for part in p.relative_to(tmp).parts[:1])


def synthetic_allowed(data_dir=None) -> bool:
    return "PYTEST_CURRENT_TEST" in os.environ or (data_dir is not None and in_rehearsal_sandbox(data_dir))


def is_synthetic(record: pd.DataFrame | None) -> bool:
    if record is None or not len(record):
        return False
    if record.attrs.get("synthetic"):
        return True
    for c in ("recorded_at", "marks", "code_hash"):
        if c in record.columns and record[c].astype(str).str.contains(SYNTHETIC_MARK, regex=False).any():
            return True
    return False


def check_record(record: pd.DataFrame | None, data_dir=None) -> None:
    """Refuse a SYNTHETIC record outside pytest and the calendar rehearsal sandbox (raises SyntheticRefused)."""
    if is_synthetic(record) and not synthetic_allowed(data_dir):
        raise SyntheticRefused("the record carries the SYNTHETIC marker: synthetic records are used only under pytest "
                               "or in the calendar rehearsal sandbox, never in a real run")


def resolve_out(out_dir) -> Path:
    """<out_dir>/backtest_explainer: out_dir must be strictly under the repo's outputs/ or outside the repo."""
    s = str(out_dir or "").strip()
    if not s or "\x00" in s:
        raise ValueError(f"out_dir {out_dir!r}: bad path")
    p = Path(s).expanduser()
    full = (p if p.is_absolute() else Path.cwd() / p).resolve()
    root, outs = ROOT.resolve(), OUTPUTS_ROOT.resolve()
    if full.is_relative_to(root) and not full.is_relative_to(outs):
        raise ValueError(f"out_dir {out_dir!r} resolves to {full}: inside the repo only outputs/ is allowed")
    return full / SUBDIR


# ---------------------------------------------------------------- realised side

def position_losses(u, prices: pd.DataFrame, date, stale_limit: int = R.STALE_MARK_WEEKDAYS) -> dict:
    """Per-position loss of the markable book on `date`, with record.realised_loss's marking rules, in the same order
    and arithmetic, so `loss` (the float sum in book order) equals realised_loss(u, prices, date)["loss"] exactly.
    Returns {"date", "prev_date", "loss", "positions": DataFrame, "marked_positions", "marked_notional_mm", "marks"}."""
    px = R._weekdays(prices)
    date = pd.Timestamp(date)
    cols = ["id", "country", "asset_class", "ticker", "notional_mm", "w", "move_log", "loss_mm", "mark"]
    prev_idx = px.index[px.index < date]
    if len(prev_idx) == 0 or date not in px.index:
        return {"date": date, "prev_date": None, "loss": np.nan, "positions": pd.DataFrame(columns=cols),
                "marked_positions": 0, "marked_notional_mm": 0.0, "marks": "no price row on the date" if date not in px.index else ""}
    prev = prev_idx.max()
    w = R.book_weights(u, px)
    rows, loss, n, notional, marks = [], 0.0, 0, 0.0, {}
    for r in w.itertuples():
        p1, d1 = R._last_price(px[r.ticker], date)
        p0, d0 = R._last_price(px[r.ticker], prev)
        if d1 is None or d0 is None or R._lag_weekdays(d1, date) > stale_limit:
            last = f"last {d1.date()}" if d1 is not None else "no price"
            marks[r.ticker] = f"excluded {r.ticker} ({last}, more than {stale_limit} weekdays before {date.date()})"
            rows.append({"id": r.id, "country": r.country, "asset_class": r.asset_class, "ticker": r.ticker,
                         "notional_mm": r.notional_mm, "w": r.w, "move_log": np.nan, "loss_mm": 0.0, "mark": "excluded"})
            continue
        mark = ""
        if d1 < date:
            marks[r.ticker] = f"stale {r.ticker} at {d1.date()} ({R._lag_weekdays(d1, date)} weekdays)"; mark = "stale"
        elif d0 < prev:
            marks[r.ticker] = f"catch-up {r.ticker} from {d0.date()}"; mark = "catch-up"
        mv = float(np.log(p1 / p0))
        li = r.w * mv
        loss += li; n += 1; notional += r.notional_mm
        rows.append({"id": r.id, "country": r.country, "asset_class": r.asset_class, "ticker": r.ticker,
                     "notional_mm": r.notional_mm, "w": r.w, "move_log": mv, "loss_mm": li, "mark": mark})
    return {"date": date, "prev_date": prev, "loss": loss, "positions": pd.DataFrame(rows, columns=cols),
            "marked_positions": n, "marked_notional_mm": notional, "marks": "; ".join(marks[k] for k in sorted(marks))}


def unmarkable_positions(u, prices: pd.DataFrame) -> pd.DataFrame:
    """Book positions the record cannot mark on these prices (Eurobonds and CDS by design; FX, local bonds and equity
    whose ticker is not a column of prices.csv), with the reason."""
    w = R.book_weights(u, R._weekdays(prices))
    marked = set(w["id"]) if len(w) else set()
    out = []
    for p in u.portfolio.itertuples():
        if p.id in marked:
            continue
        why = ("not marked by the record by design (no daily price)" if p.asset_class not in ("FX", "Local bond", "Equity")
               else "ticker not in prices.csv (equity ETFs dropped with the official-FX rebuild, EQ-A-0054)"
               if p.asset_class == "Equity" else "currency not in prices.csv")
        out.append({"id": p.id, "country": p.country, "asset_class": p.asset_class, "notional_mm": float(p.notional_mm), "reason": why})
    return pd.DataFrame(out, columns=["id", "country", "asset_class", "notional_mm", "reason"])


# ---------------------------------------------------------------- forecast side (Euler on GARCH-DCC)

def _cfg_alpha(settings) -> float:
    cfg = settings.raw.get("garch", {}) if settings is not None and hasattr(settings, "raw") else {}
    return float((cfg.get("confidence") or [ALPHA])[0])


def forecast_components(u, g, prices_to: pd.DataFrame, a99: float = ALPHA) -> dict:
    """The one-day VaR / ES of record._portfolio_var(u, g, prices_to), with its Euler split. Returns {"var", "es",
    "tickers": DataFrame (ticker, kind, w, sigma, nu, q, marginal_var, component_var99_mm, component_es99_mm,
    standalone_var99_mm, standalone_es99_mm), "blocks": {kind: {var, es, nu, ...}}, "cov": {kind: (tickers, Sigma)}}.
    Same arithmetic as _portfolio_var for the totals (checked against it by the caller)."""
    from ..engine.garch import _business_daily, _returns, clean_bad_ticks, t_es, t_quantile
    prices_to, _ = clean_bad_ticks(prices_to)
    prices_to = _business_daily(prices_to)
    w = R.book_weights(u, prices_to)
    empty = pd.DataFrame(columns=["ticker", "kind", "w", "sigma", "nu", "q", "marginal_var", "component_var99_mm",
                                  "component_es99_mm", "standalone_var99_mm", "standalone_es99_mm"])
    if w.empty or not g.fits:
        return {"var": np.nan, "es": np.nan, "tickers": empty, "blocks": {}, "cov": {}}
    agg = w.groupby("ticker")["w"].sum()
    out_v, out_e, blocks = 0.0, 0.0, {}
    for kind, dcc in (("FX", g.dcc_fx), ("Equity", g.dcc_eq)):
        tick = [t for t in agg.index if t in g.fits and t in (dcc.labels if dcc else []) and (t.startswith("USD") == (kind == "FX"))]
        if not tick:
            continue
        s1, nus = [], []
        for t in tick:
            f = g.fits[t]; r = _returns(prices_to[t]).to_numpy()
            n_fit = f.n; sig = f.sigma2[-1]; last_r = f.resid[-1]
            for x in r[n_fit:]:
                sig = f.omega + f.alpha * last_r ** 2 + f.beta * sig; last_r = x - f.mu
            s1.append(math.sqrt(f.omega + f.alpha * last_r ** 2 + f.beta * sig)); nus.append(f.nu)
        idx = [dcc.labels.index(t) for t in tick]; Rm = dcc.R_next[np.ix_(idx, idx)]
        wv = agg[tick].to_numpy(); s1 = np.array(s1); nu = float(np.median(nus))
        S = np.outer(s1, s1) * Rm
        v = math.sqrt(wv @ S @ wv)
        q, eq = t_quantile(a99, nu), t_es(a99, nu)
        out_v += (q * v) ** 2; out_e += (eq * v) ** 2
        blocks[kind] = {"tickers": tick, "w": wv, "sigma": s1, "Sigma": S, "v": v, "nu": nu, "q": q, "q_es": eq,
                        "var": q * v, "es": eq * v}
    V, E = math.sqrt(out_v), math.sqrt(out_e)
    rows = []
    for kind, b in blocks.items():
        Sw = b["Sigma"] @ b["w"]
        for j, t in enumerate(b["tickers"]):
            m_v = (b["var"] / V) * b["q"] * Sw[j] / b["v"] if V > 0 and b["v"] > 0 else 0.0
            m_e = (b["es"] / E) * b["q_es"] * Sw[j] / b["v"] if E > 0 and b["v"] > 0 else 0.0
            rows.append({"ticker": t, "kind": kind, "w": float(b["w"][j]), "sigma": float(b["sigma"][j]), "nu": b["nu"],
                         "q": b["q"], "marginal_var": float(m_v), "marginal_es": float(m_e),
                         "component_var99_mm": float(b["w"][j] * m_v), "component_es99_mm": float(b["w"][j] * m_e),
                         "standalone_var99_mm": float(b["q"] * abs(b["w"][j]) * b["sigma"][j]),
                         "standalone_es99_mm": float(b["q_es"] * abs(b["w"][j]) * b["sigma"][j])})
    return {"var": V, "es": E, "tickers": pd.DataFrame(rows) if rows else empty, "blocks": blocks}


def standalone_var(fc: dict, weights: dict[str, float]) -> tuple[float, float]:
    """VaR99 / ES99 of a sub-book given by ticker weights {ticker: w}, on the forecast's blocks (each block elliptical
    with its own t quantile, blocks combined as root sum of squares, the same rule as the book)."""
    v2, e2 = 0.0, 0.0
    for b in fc["blocks"].values():
        x = np.array([weights.get(t, 0.0) for t in b["tickers"]])
        if not np.any(x):
            continue
        s = math.sqrt(max(float(x @ b["Sigma"] @ x), 0.0))
        v2 += (b["q"] * s) ** 2; e2 += (b["q_es"] * s) ** 2
    return math.sqrt(v2), math.sqrt(e2)


class Reconstructor:
    """GARCH-DCC fits on the current prices, refitted every `step` forecast days from the first one asked for
    (backfill_record's scheme) and reused: forecast(prev) is the forecast made on `prev` for the next record day."""

    def __init__(self, u, settings, prices: pd.DataFrame, step: int = STEP):
        self.u, self.settings, self.step = u, settings, max(1, int(step))
        self.px = R._weekdays(prices)
        self.a99 = _cfg_alpha(settings)
        self._fits: dict[pd.Timestamp, object] = {}
        self._schedule: list[pd.Timestamp] = []
        self.checks: list[dict] = []

    def set_schedule(self, prev_dates) -> None:
        ds = sorted({pd.Timestamp(d) for d in prev_dates})
        self._schedule = ds[::self.step]

    def fit_date(self, prev) -> pd.Timestamp:
        prev = pd.Timestamp(prev)
        sch = [d for d in self._schedule if d <= prev]
        return sch[-1] if sch else prev

    def _fit(self, d: pd.Timestamp):
        if d not in self._fits:
            from ..engine.garch import run_garch
            with warnings.catch_warnings():
                warnings.simplefilter("ignore")
                self._fits[d] = run_garch(self.u, self.px.loc[:d], self.settings, None, as_of=_d(d))
        return self._fits[d]

    def forecast(self, prev) -> dict:
        prev = pd.Timestamp(prev)
        fd = self.fit_date(prev)
        g = self._fit(fd)
        pto = self.px.loc[:prev]
        fc = forecast_components(self.u, g, pto, self.a99)
        ref_v, ref_e = R._portfolio_var(self.u, g, pto, self.a99)
        fc["fit_date"] = fd
        fc["check_portfolio_var_abs_diff"] = abs(fc["var"] - ref_v) if np.isfinite(ref_v) else 0.0
        fc["check_portfolio_es_abs_diff"] = abs(fc["es"] - ref_e) if np.isfinite(ref_e) else 0.0
        return fc


# ---------------------------------------------------------------- (1) exception explainer

def exceptions(record: pd.DataFrame | None, as_of) -> pd.DataFrame:
    """Clean tested days (calendar_tests.clean_days, point in time) with recorded loss > recorded VaR99."""
    clean, _ = clean_days(record, as_of)
    return clean[clean["loss"] > clean["var"]].reset_index(drop=True)


def _x_row(t, date, prev, level, item, **kw) -> dict:
    r = {c: np.nan for c in EXCEPTION_COLUMNS}
    r.update({"as_of": _d(t), "date": _d(date), "prev_date": _d(prev), "level": level, "item": item, "country": "",
              "asset_class": "", "factor": "", "factor_type": "", "rank": np.nan, "inputs_status": "", "basis": "",
              "label": "", "note": ""})
    r.update(kw)
    return r


def explain_day(rec_row: dict, u, recon: Reconstructor, prices: pd.DataFrame, as_of) -> tuple[list[dict], dict]:
    """Rows for one record day (normally an exception): book, residual, position, country, asset_class, factor and
    factor_type levels. Returns (rows, checks)."""
    t = _as_of(as_of)
    date = pd.Timestamp(rec_row["date"])
    rl, rv = float(rec_row["loss"]), float(rec_row["var"])
    pl = position_losses(u, prices, date)
    label = _interim_label(VAR_GATE, "exception explainer; " + NOT_RECORDED.split(":")[0])
    if pl["prev_date"] is None or not np.isfinite(pl["loss"]):
        row = _x_row(t, date, None, "book", "book", realised_loss_mm=np.nan, recorded_loss_mm=rl, recorded_var99_mm=rv,
                     inputs_status=STATUS_NO_PRICES, basis="no reconstruction", label=label,
                     note=f"{NOT_RECORDED}; prices.csv has no row for {_d(date)} or before it: nothing can be attributed")
        return [row], {"date": _d(date), "status": STATUS_NO_PRICES}
    prev = pl["prev_date"]
    fc = recon.forecast(prev)
    pos = pl["positions"].copy()
    tk = fc["tickers"].set_index("ticker") if len(fc["tickers"]) else pd.DataFrame(columns=["kind", "marginal_var", "marginal_es"])
    pos["factor_type"] = [("FX" if str(x).startswith("USD") else "Equity") for x in pos["ticker"]]
    pos["in_forecast"] = pos["ticker"].isin(tk.index)
    pos["component_var99_mm"] = [w * float(tk.at[x, "marginal_var"]) if x in tk.index else 0.0 for x, w in zip(pos["ticker"], pos["w"])]
    pos["component_es99_mm"] = [w * float(tk.at[x, "marginal_es"]) if x in tk.index else 0.0 for x, w in zip(pos["ticker"], pos["w"])]
    loss_rec, var_rec = pl["loss"], fc["var"]
    gap_l, gap_v = rl - loss_rec, rv - var_rec
    reconciled = abs(gap_l) <= RECONCILE_TOL_MM and abs(gap_v) <= RECONCILE_TOL_MM
    status = STATUS_RECONCILED if reconciled else STATUS_UNRECONCILED
    basis = (f"reconstructed: current prices.csv to {_d(date)}, GARCH-DCC fit on prices to {_d(fc['fit_date'])} "
             f"filtered to {_d(prev)}; current portfolio.csv")
    expl = ("reconstruction reproduces the recorded loss and VaR: it explains the recorded exception" if reconciled else
            f"reconstruction does NOT reproduce the record (loss gap {gap_l:+.4f}, VaR gap {gap_v:+.4f} $mm): the position, "
            "country and factor rows describe the day on today's inputs, not the recorded exception; the residual rows "
            "carry the difference")
    rows = [_x_row(t, date, prev, "book", "book", exposure_mm=float(pos["w"].abs().sum()),
                   realised_loss_mm=loss_rec, forecast_var99_mm=var_rec, forecast_es99_mm=fc["es"],
                   excess_over_var_mm=loss_rec - var_rec, share_of_loss=1.0, share_of_var=1.0,
                   recorded_loss_mm=rl, recorded_var99_mm=rv, inputs_status=status, basis=basis, label=label,
                   note=f"{NOT_RECORDED}. {expl}. Recorded: loss {rl:.4f} > VaR {rv:.4f} ({rl / rv:.3f} x VaR); "
                        f"reconstructed: loss {loss_rec:.4f} vs VaR {var_rec:.4f} ("
                        + ("exception" if loss_rec > var_rec else "no exception") + " on today's inputs); "
                        f"marked {pl['marked_positions']} positions / {pl['marked_notional_mm']:.1f} $mm vs recorded "
                        f"{rec_row.get('marked_positions')} / {rec_row.get('marked_notional_mm')} $mm"
                        + (f"; marks: {pl['marks']}" if pl["marks"] else ""))]
    rows.append(_x_row(t, date, prev, "residual", "recorded minus reconstructed", realised_loss_mm=gap_l,
                       forecast_var99_mm=gap_v, excess_over_var_mm=gap_l - gap_v,
                       share_of_loss=gap_l / rl if rl else np.nan, share_of_var=gap_v / rv if rv else np.nan,
                       recorded_loss_mm=rl, recorded_var99_mm=rv, inputs_status=status, basis="recorded - reconstructed",
                       label=label, note="unexplained by the reconstruction: what the day's inputs would have to "
                                         "explain; book rows + this row = the recorded numbers"))

    def add_level(level, keys, extra=None):
        g = pos.groupby(keys, sort=False)[["w", "loss_mm", "component_var99_mm", "component_es99_mm"]].sum()
        g["excess"] = g["loss_mm"] - g["component_var99_mm"]
        g = g.sort_values("excess", ascending=False)
        for rank, (k, x) in enumerate(g.iterrows(), 1):
            kk = k if isinstance(k, tuple) else (k,)
            info = dict(zip(keys, kk))
            item = str(kk[0])
            kw = {"country": info.get("country", ""), "asset_class": info.get("asset_class", ""),
                  "factor": info.get("ticker", ""), "factor_type": info.get("factor_type", "")}
            if extra:
                kw.update(extra(info))
            sub = pos[np.logical_and.reduce([pos[c] == v for c, v in info.items()])]
            note_bits = []
            if (sub["mark"] != "").any():
                note_bits.append("marks: " + ", ".join(sorted({f"{a} {m}" for a, m in zip(sub["id"], sub["mark"]) if m})))
            if (~sub["in_forecast"]).any():
                note_bits.append("not in the forecast (no GARCH fit): " + ", ".join(sub.loc[~sub["in_forecast"], "id"]))
            rows.append(_x_row(t, date, prev, level, item, exposure_mm=float(x["w"]), realised_loss_mm=float(x["loss_mm"]),
                               forecast_var99_mm=float(x["component_var99_mm"]), forecast_es99_mm=float(x["component_es99_mm"]),
                               excess_over_var_mm=float(x["excess"]),
                               share_of_loss=float(x["loss_mm"]) / loss_rec if loss_rec else np.nan,
                               share_of_var=float(x["component_var99_mm"]) / var_rec if var_rec else np.nan,
                               rank=rank, recorded_loss_mm=rl, recorded_var99_mm=rv, inputs_status=status, basis=basis,
                               label=label, note="; ".join(note_bits), **kw))
        return g

    add_level("position", ["id", "country", "asset_class", "ticker", "factor_type"])
    gc = add_level("country", ["country"])
    add_level("asset_class", ["asset_class"])
    gf = add_level("factor", ["ticker", "factor_type"])
    add_level("factor_type", ["factor_type"])
    # checks: every level sums to the reconstructed totals; residual closes to the record
    checks = {"date": _d(date), "status": status, "fit_date": _d(fc["fit_date"]),
              "loss_sum_abs_diff_mm": abs(float(pos["loss_mm"].sum()) - loss_rec),
              "loss_vs_realised_loss_abs_diff_mm": abs(loss_rec - R.realised_loss(u, prices, date)["loss"]),
              "var_components_sum_abs_diff_mm": abs(float(pos["component_var99_mm"].sum()) - var_rec) if np.isfinite(var_rec) else 0.0,
              "es_components_sum_abs_diff_mm": abs(float(pos["component_es99_mm"].sum()) - fc["es"]) if np.isfinite(fc["es"]) else 0.0,
              "country_var_sum_abs_diff_mm": abs(float(gc["component_var99_mm"].sum()) - var_rec) if np.isfinite(var_rec) else 0.0,
              "factor_var_sum_abs_diff_mm": abs(float(gf["component_var99_mm"].sum()) - var_rec) if np.isfinite(var_rec) else 0.0,
              "portfolio_var_abs_diff_mm": fc["check_portfolio_var_abs_diff"],
              "portfolio_es_abs_diff_mm": fc["check_portfolio_es_abs_diff"],
              "loss_gap_mm": gap_l, "var_gap_mm": gap_v, "recorded_loss_mm": rl, "recorded_var99_mm": rv,
              "reconstructed_loss_mm": loss_rec, "reconstructed_var99_mm": var_rec}
    return rows, checks


def exception_rows(record: pd.DataFrame | None, u, settings, prices: pd.DataFrame, as_of, step: int = STEP,
                   recon: Reconstructor | None = None, data_dir=None) -> tuple[list[dict], list[dict]]:
    """(rows, checks) for every VaR99 exception on the record known at as_of. Each exception gets a block of rows
    (EXCEPTION_COLUMNS). With no exception, one row says so."""
    check_record(record, data_dir)
    t = _as_of(as_of)
    px = prices[pd.to_datetime(prices.index) <= t]
    exc = exceptions(record, t)
    if recon is None:
        recon = Reconstructor(u, settings, px, step)
        recon.set_schedule(_prev_dates(record, px, t))
    if not len(exc):
        clean, _ = clean_days(record, t)
        return [_x_row(t, None, None, "book", "none", label=_interim_label(VAR_GATE, f"{len(clean)} clean days"),
                       note=f"no VaR99 exception in {len(clean)} clean tested days to {_d(t)}")], []
    rows, checks = [], []
    full = record_as_of(record, t).set_index(pd.to_datetime(record_as_of(record, t)["date"]))
    for e in exc.to_dict(orient="records"):
        rr = {**full.loc[pd.Timestamp(e["date"])].to_dict(), **e} if pd.Timestamp(e["date"]) in full.index else e
        r, c = explain_day(rr, u, recon, px, t)
        rows += r; checks.append(c)
    return rows, checks


def _prev_dates(record, px: pd.DataFrame, t) -> list[pd.Timestamp]:
    clean, _ = clean_days(record, t)
    idx = R._weekdays(px).index
    out = []
    for d in pd.to_datetime(clean["date"]):
        p = idx[idx < d]
        if len(p):
            out.append(p.max())
    return out


# ---------------------------------------------------------------- (2) rolling backtests

def _roll(dates, loss, var, window, alpha=ALPHA):
    """Trailing windows of up to `window` observations ending at each index."""
    out = []
    for i in range(len(dates)):
        lo = max(0, i - window + 1)
        L, V, D = loss[lo:i + 1], var[lo:i + 1], dates[lo:i + 1]
        ok = np.isfinite(L) & np.isfinite(V) & (V > 0)
        L, V, D = L[ok], V[ok], D[ok]
        n = len(L)
        if n == 0:
            out.append(None); continue
        exc = L > V
        k = kupiec(exc, alpha)
        b_lo, b_hi = binomial_band(n, alpha, BAND)
        x = int(exc.sum())
        out.append({"end_date": dates[i], "n": n, "exceptions": x, "expected": n * (1 - alpha), "exception_rate": x / n,
                    "kupiec_lr": k["LR_uc"], "kupiec_p": k["p_value"], "band_low": b_lo, "band_high": b_hi,
                    "band_status": "inside band" if b_lo <= x <= b_hi else ("above band" if x > b_hi else "below band"),
                    "largest_loss_to_var": float(np.max(L / V)),
                    "exception_dates": ", ".join(_d(d) for d in D[exc])})
    return out


def reconstructed_panel(record: pd.DataFrame | None, u, prices: pd.DataFrame, as_of, recon: Reconstructor) -> dict:
    """Per clean record day: reconstructed position losses and forecasts. Returns {"days": [...], "country": DataFrame
    (date x country losses), "country_var", "factor", "factor_var", "book", "book_var"}."""
    t = _as_of(as_of)
    clean, _ = clean_days(record, t)
    loss_c, var_c, loss_f, var_f, book, book_v = {}, {}, {}, {}, {}, {}
    for d in pd.to_datetime(clean["date"]):
        pl = position_losses(u, prices, d)
        if pl["prev_date"] is None:
            continue
        fc = recon.forecast(pl["prev_date"])
        pos = pl["positions"]
        loss_c[d] = pos.groupby("country")["loss_mm"].sum()
        loss_f[d] = pos.groupby("ticker")["loss_mm"].sum()
        wt = pos.groupby("ticker")["w"].sum()
        tk = set(fc["tickers"]["ticker"]) if len(fc["tickers"]) else set()
        var_c[d] = pd.Series({c: standalone_var(fc, {x: float(v) for x, v in g.groupby("ticker")["w"].sum().items() if x in tk})[0]
                              for c, g in pos.groupby("country")})
        var_f[d] = pd.Series({x: standalone_var(fc, {x: float(wt[x])})[0] if x in tk else np.nan for x in wt.index})
        book[d], book_v[d] = pl["loss"], fc["var"]
    return {"country": pd.DataFrame(loss_c).T.sort_index(), "country_var": pd.DataFrame(var_c).T.sort_index(),
            "factor": pd.DataFrame(loss_f).T.sort_index(), "factor_var": pd.DataFrame(var_f).T.sort_index(),
            "book": pd.Series(book, dtype=float).sort_index(), "book_var": pd.Series(book_v, dtype=float).sort_index()}


def rolling_rows(record: pd.DataFrame | None, u, settings, prices: pd.DataFrame, as_of, windows=ROLLING_WINDOWS,
                 step: int = STEP, recon: Reconstructor | None = None, panel: dict | None = None, data_dir=None) -> list[dict]:
    """Rolling exception counts and Kupiec statistics (ROLLING_COLUMNS) for the book (recorded and reconstructed), each
    country and each risk factor, over trailing windows of up to each of `windows` clean days. INTERIM while the record
    has fewer than 250 clean days; country and factor rows are reconstructed (standalone VaR99 of the sub-book)."""
    check_record(record, data_dir)
    t = _as_of(as_of)
    px = prices[pd.to_datetime(prices.index) <= t]
    clean, _ = clean_days(record, t)
    n_all = len(clean)
    lab = _interim_label(VAR_GATE, f"{min(n_all, WINDOW)} of {WINDOW} clean days" + ("" if n_all >= WINDOW else ", underpowered")) \
        if n_all < WINDOW else "DIAGNOSTIC rolling backtest, not the formal test (calendar_tests.run_var_backtest)"
    if recon is None:
        recon = Reconstructor(u, settings, px, step)
        recon.set_schedule(_prev_dates(record, px, t))
    if panel is None:
        panel = reconstructed_panel(record, u, px, t, recon)
    rows = []

    def emit(group_type, group, dates, loss, var, basis, note=""):
        for w in windows:
            for x in _roll(np.asarray(dates), np.asarray(loss, float), np.asarray(var, float), int(w)):
                if x is None:
                    continue
                r = {c: np.nan for c in ROLLING_COLUMNS}
                r.update(x); r.update({"as_of": _d(t), "end_date": _d(x["end_date"]), "window": int(w), "group_type": group_type,
                                       "group": group, "basis": basis, "label": lab,
                                       "note": note + ("" if x["n"] >= w else f"{'; ' if note else ''}{x['n']} of {w} days in the window")})
                rows.append(r)
    if n_all:
        emit("book", "recorded", pd.to_datetime(clean["date"]).to_numpy(), clean["loss"], clean["var"],
             "recorded (data/forecast_record.csv)", "the record's own loss and VaR99")
    rb = panel["book"]
    if len(rb):
        emit("book", "reconstructed", rb.index.to_numpy(), rb.to_numpy(), panel["book_var"].reindex(rb.index).to_numpy(),
             "reconstructed on current prices.csv", "book loss and VaR99 rebuilt from today's inputs")
    for key, gt in (("country", "country"), ("factor", "factor")):
        L, V = panel[key], panel[key + "_var"]
        for col in L.columns:
            v = V[col].reindex(L.index) if col in V.columns else pd.Series(np.nan, index=L.index)
            emit(gt, col, L.index.to_numpy(), L[col].to_numpy(), v.to_numpy(),
                 "reconstructed on current prices.csv; standalone VaR99 of the sub-book",
                 "" if np.isfinite(v.to_numpy(float)).any() else "no forecast for this group (no GARCH fit)")
    return rows


# ---------------------------------------------------------------- (3) P&L attribution

def pnl_attribution_rows(record: pd.DataFrame | None, u, prices: pd.DataFrame, as_of, data_dir=None) -> tuple[list[dict], dict]:
    """Per record day known at as_of with a loss: recorded loss vs the loss explained by realised moves of the risk
    factors on current prices.csv (exposure x log move, the record's marking rules), and the unexplained remainder.
    Factor rows add up to the book's explained loss exactly. Returns (rows, summary)."""
    check_record(record, data_dir)
    t = _as_of(as_of)
    px = prices[pd.to_datetime(prices.index) <= t]
    rec = record_as_of(record, t)
    rec = rec[pd.to_numeric(rec["loss"], errors="coerce").notna()].sort_values("date")
    lab = _interim_label(VAR_GATE, "P&L attribution on the record; reconstructed on current prices.csv")
    basis = "recorded loss (data/forecast_record.csv) vs exposure x realised log move on current prices.csv"
    rows, recs, expl = [], [], []
    for x in rec.to_dict(orient="records"):
        d = pd.Timestamp(x["date"]); rl = float(x["loss"])
        pl = position_losses(u, px, d)
        e = pl["loss"] if np.isfinite(pl["loss"]) else np.nan
        un = rl - e if np.isfinite(e) else np.nan
        base = {c: np.nan for c in PNL_COLUMNS}
        base.update({"as_of": _d(t), "date": _d(d), "country": "", "factor_type": "", "basis": basis, "label": lab,
                     "recorded_marked_positions": x.get("marked_positions"), "recorded_marked_notional_mm": x.get("marked_notional_mm")})
        rows.append({**base, "level": "book", "item": "book", "recorded_loss_mm": rl, "explained_mm": e, "unexplained_mm": un,
                     "explained_share": e / rl if rl and np.isfinite(e) else np.nan,
                     "marked_positions": pl["marked_positions"], "marked_notional_mm": pl["marked_notional_mm"],
                     "marks": pl["marks"],
                     "note": "" if np.isfinite(e) else "no price row for the day on current prices.csv: nothing explained"})
        if np.isfinite(e):
            recs.append(rl); expl.append(e)
            pos = pl["positions"]
            for tick, g in pos.groupby("ticker", sort=True):
                mv = g["move_log"].dropna()
                rows.append({**base, "level": "factor", "item": tick, "country": ", ".join(sorted(set(g["country"]))),
                             "factor_type": "FX" if str(tick).startswith("USD") else "Equity",
                             "exposure_mm": float(g["w"].sum()), "move_log": float(mv.iloc[0]) if len(mv) else np.nan,
                             "explained_mm": float(g["loss_mm"].sum()), "marks": ", ".join(sorted({m for m in g["mark"] if m})),
                             "explained_share": float(g["loss_mm"].sum()) / rl if rl else np.nan})
    r, e = np.array(recs, float), np.array(expl, float)
    summary = {"days": int(len(rec)), "days_explained": int(len(r))}
    if len(r) >= 2:
        u_ = r - e
        summary.update({"sum_abs_recorded_mm": float(np.abs(r).sum()), "sum_abs_unexplained_mm": float(np.abs(u_).sum()),
                        "share_of_variance_explained": float(1 - np.var(u_) / np.var(r)) if np.var(r) > 0 else None,
                        "correlation_recorded_explained": float(np.corrcoef(r, e)[0, 1]) if np.std(e) > 0 else None,
                        "max_abs_unexplained_mm": float(np.abs(u_).max()),
                        "max_abs_unexplained_date": _d(rec.iloc[int(np.argmax(np.abs(u_)))]["date"]) if len(u_) == len(rec) else "",
                        "days_reconciled": int(np.sum(np.abs(u_) <= RECONCILE_TOL_MM))})
    return rows, summary


# ---------------------------------------------------------------- demo / runner

def _clean(v):
    if isinstance(v, dict):
        return {str(k): _clean(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [_clean(x) for x in v]
    if isinstance(v, (np.integer,)):
        return int(v)
    if isinstance(v, (float, np.floating)):
        return None if not np.isfinite(v) else float(v)
    if isinstance(v, (pd.Timestamp,)):
        return _d(v)
    if isinstance(v, np.bool_):
        return bool(v)
    return v


def _fmt(v, nd=4) -> str:
    if v is None or (isinstance(v, float) and not np.isfinite(v)):
        return ""
    return f"{v:.{nd}f}" if isinstance(v, (float, np.floating)) else str(v)


def markdown(res: dict) -> str:
    s = res["summary"]
    lines = [f"# Backtest explainer, as of {res['as_of']} (INTERIM)", "",
             f"**{res['label']}** {NOT_RECORDED}. Every attribution below is a reconstruction on today's inputs; "
             "a day counts as explained only when the reconstruction reproduces the recorded loss and VaR.", "",
             f"Record: {s.get('clean_days')} clean tested days, {s.get('exceptions')} VaR99 exception(s) "
             f"({', '.join(s.get('exception_dates', [])) or 'none'}).", ""]
    for c in res.get("checks", []):
        lines += [f"## Exception {c['date']}: {c['status']}", "",
                  f"Recorded loss {_fmt(c['recorded_loss_mm'])} vs VaR99 {_fmt(c['recorded_var99_mm'])} $mm. Reconstructed "
                  f"loss {_fmt(c['reconstructed_loss_mm'])} vs VaR99 {_fmt(c['reconstructed_var99_mm'])} $mm (gaps "
                  f"{_fmt(c['loss_gap_mm'])} / {_fmt(c['var_gap_mm'])}).", ""]
        top = [r for r in res["exception_rows"] if r["date"] == c["date"] and r["level"] in ("country", "factor") and r["rank"] in (1, 2, 3)]
        if top:
            lines += ["| Level | Item | Realised loss | Component VaR99 | Excess | Rank |", "|---|---|---|---|---|---|"]
            lines += [f"| {r['level']} | {r['item']} | {_fmt(r['realised_loss_mm'])} | {_fmt(r['forecast_var99_mm'])} | "
                      f"{_fmt(r['excess_over_var_mm'])} | {int(r['rank'])} |" for r in top]
            lines.append("")
    p = res.get("pnl_summary", {})
    lines += ["## P&L attribution", "", f"{p.get('days_explained')} of {p.get('days')} days explained on current prices; "
              f"share of variance explained {_fmt(p.get('share_of_variance_explained'), 3)}; correlation "
              f"{_fmt(p.get('correlation_recorded_explained'), 3)}; largest unexplained {_fmt(p.get('max_abs_unexplained_mm'))} "
              f"$mm on {p.get('max_abs_unexplained_date', '')}; {p.get('days_reconciled')} days reconciled.", "",
              "## Gaps", ""] + [f"- {g}" for g in res.get("gaps", [])] + ["", "INTERIM, not a formal test result.", ""]
    return "\n".join(lines)


def run_explainer(record, u, settings, prices, as_of, step: int = STEP, windows=ROLLING_WINDOWS, data_dir=None) -> dict:
    """All three outputs on one set of inputs, sharing the GARCH-DCC fits. Returns rows, checks, summaries, gaps and
    problems (broken sums or reproduction checks)."""
    check_record(record, data_dir)
    t = _as_of(as_of)
    px = prices[pd.to_datetime(prices.index) <= t]
    recon = Reconstructor(u, settings, px, step)
    recon.set_schedule(_prev_dates(record, px, t))
    x_rows, checks = exception_rows(record, u, settings, px, t, step, recon, data_dir)
    panel = reconstructed_panel(record, u, px, t, recon)
    r_rows = rolling_rows(record, u, settings, px, t, windows, step, recon, panel, data_dir)
    p_rows, p_sum = pnl_attribution_rows(record, u, px, t, data_dir)
    clean, dropped = clean_days(record, t)
    exc = exceptions(record, t)
    problems, gaps = [], []
    for c in checks:
        for k in ("loss_sum_abs_diff_mm", "var_components_sum_abs_diff_mm", "es_components_sum_abs_diff_mm",
                  "country_var_sum_abs_diff_mm", "factor_var_sum_abs_diff_mm", "portfolio_var_abs_diff_mm",
                  "portfolio_es_abs_diff_mm"):
            if c.get(k, 0.0) > SUM_TOL_MM:
                problems.append(f"{c['date']}: {k} = {c[k]:.3e} > {SUM_TOL_MM}")
        if c.get("loss_vs_realised_loss_abs_diff_mm", 0.0) != 0.0:
            problems.append(f"{c['date']}: position losses do not add up to record.realised_loss bit for bit")
        if c["status"] != STATUS_RECONCILED:
            gaps.append(f"{c['date']}: {c['status']}: recorded loss {c['recorded_loss_mm']:.4f} / VaR {c['recorded_var99_mm']:.4f} "
                        f"vs reconstructed {c.get('reconstructed_loss_mm', float('nan')):.4f} / {c.get('reconstructed_var99_mm', float('nan')):.4f} $mm")
    gaps.append(NOT_RECORDED)
    um = unmarkable_positions(u, px)
    eq = um[um["asset_class"] == "Equity"]
    if len(eq):
        gaps.append("equity positions not markable on current prices.csv: " + ", ".join(f"{a} {b}" for a, b in zip(eq["id"], eq["country"])))
    if p_sum.get("days_explained") and p_sum.get("days_reconciled", 0) < p_sum["days_explained"]:
        gaps.append(f"P&L attribution: {p_sum['days_explained'] - p_sum.get('days_reconciled', 0)} of {p_sum['days_explained']} "
                    "record days are not reproduced by today's prices.csv (the record was marked on prices that are no longer the "
                    "engine's; data_hash on the rows differs from today's)")
    if n_short := max(WINDOW - len(clean), 0):
        gaps.append(f"record has {len(clean)} clean days; {n_short} more needed for the formal 250-day test ({VAR_GATE})")
    summary = {"clean_days": int(len(clean)), "dropped_rows": int(dropped), "exceptions": int(len(exc)),
               "exception_dates": [_d(d) for d in exc["date"]], "first_day": _d(clean["date"].min()) if len(clean) else "",
               "last_day": _d(clean["date"].max()) if len(clean) else "", "exception_rows": len(x_rows),
               "rolling_rows": len(r_rows), "pnl_rows": len(p_rows), "fit_dates": [_d(d) for d in sorted(recon._fits)],
               "step": int(step), "windows": [int(w) for w in windows], "reconciled_exceptions":
               int(sum(c["status"] == STATUS_RECONCILED for c in checks)), "unmarkable_positions": um.to_dict(orient="records")}
    return {"as_of": _d(t), "schema": SCHEMA, "ticket": TICKET, "kind": "INTERIM",
            "label": _interim_label(VAR_GATE, f"{len(clean)} of {WINDOW} clean days"),
            "exception_rows": x_rows, "rolling_rows": r_rows, "pnl_rows": p_rows, "checks": checks,
            "pnl_summary": p_sum, "summary": summary, "gaps": gaps, "problems": problems}


def demo_backtest_explainer(out_dir, as_of, data_dir=None, step: int = STEP, windows=ROLLING_WINDOWS) -> dict:
    """Run the explainer on <data_dir> (default: the repo's data/, the real record) and write
    <out_dir>/backtest_explainer/{exceptions.csv, rolling.csv, pnl_attribution.csv, backtest_explainer.json,
    backtest_explainer.md}. out_dir must be under the repo's outputs/ or outside the repo. Returns {"ok", "problems",
    "paths", "as_of", "schema", "summary", "gaps", "checks", "pnl_summary"}. ok is False when a sum or reproduction
    check fails, the record is refused or a step raised; data gaps (an unreconciled day) are reported in "gaps"."""
    t = _d(_as_of(as_of))
    out = resolve_out(out_dir)
    data = Path(data_dir).resolve() if data_dir else (ROOT / "data").resolve()
    problems: list[str] = []
    res = None
    if data != (ROOT / "data").resolve() and not synthetic_allowed(data):
        problems.append(f"data_dir {data} is not the repo's data/: real runs read the real record only "
                        "(other folders only under pytest or the calendar rehearsal sandbox)")
    else:
        try:
            from ..config import Settings
            from ..engine.garch import load_prices
            from ..ingestion import load_universe
            rec = R.load_record(data / "forecast_record.csv")
            check_record(rec, data)
            u = load_universe(str(data))
            settings = Settings.load(data / "assumptions.json")
            px = load_prices(data)
            if px is None:
                raise FileNotFoundError(f"{data / 'market_history' / 'prices.csv'} missing")
            res = run_explainer(rec, u, settings, px, t, step, windows, data)
            problems += res["problems"]
        except SyntheticRefused as e:
            problems.append(str(e))
        except Exception as e:                                       # noqa: BLE001 - reported, never a silent pass
            problems.append(f"explainer raised {type(e).__name__}: {e}"[:400])
    paths: dict[str, str] = {}
    if res is not None:
        out.mkdir(parents=True, exist_ok=True)
        paths = {k: str(out / v) for k, v in FILES.items()}
        pd.DataFrame(res["exception_rows"], columns=list(EXCEPTION_COLUMNS)).to_csv(paths["exceptions"], index=False)
        pd.DataFrame(res["rolling_rows"], columns=list(ROLLING_COLUMNS)).to_csv(paths["rolling"], index=False)
        pd.DataFrame(res["pnl_rows"], columns=list(PNL_COLUMNS)).to_csv(paths["pnl"], index=False)
        meta = {k: res[k] for k in ("as_of", "schema", "ticket", "kind", "label", "summary", "checks", "pnl_summary", "gaps")}
        meta.update({"problems": problems, "columns": {"exceptions": list(EXCEPTION_COLUMNS), "rolling": list(ROLLING_COLUMNS),
                                                       "pnl": list(PNL_COLUMNS)}, "levels": list(LEVELS),
                     "statuses": [STATUS_RECONCILED, STATUS_UNRECONCILED, STATUS_NO_PRICES], "data_dir": str(data)})
        tmp = out / ("." + FILES["json"] + ".tmp")
        tmp.write_text(json.dumps(_clean(meta), indent=1, allow_nan=False))
        tmp.replace(paths["json"])
        Path(paths["md"]).write_text(markdown(res))
    return {"ok": not problems and res is not None, "problems": problems, "paths": paths, "as_of": t, "schema": SCHEMA,
            "summary": _clean(res["summary"]) if res else {}, "gaps": res["gaps"] if res else [],
            "checks": _clean(res["checks"]) if res else [], "pnl_summary": _clean(res["pnl_summary"]) if res else {}}


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.validation.backtest_explainer", description=__doc__.splitlines()[0])
    ap.add_argument("--as-of", required=True, help="YYYY-MM-DD; no record row or price dated after it is used")
    ap.add_argument("--out", default=str(OUTPUTS_ROOT), help="folder under outputs/ or outside the repo; writes <out>/backtest_explainer/")
    ap.add_argument("--step", type=int, default=STEP, help="GARCH-DCC refit every N record days (1 = each day)")
    a = ap.parse_args(argv)
    try:
        r = demo_backtest_explainer(a.out, a.as_of, step=a.step)
    except ValueError as e:
        ap.error(str(e))
    short = {k: v for k, v in r["summary"].items() if k != "unmarkable_positions"}
    print(json.dumps({"ok": r["ok"], "as_of": r["as_of"], "summary": short, "gaps": r["gaps"], "paths": r["paths"],
                      "problems": r["problems"]}, indent=1, default=str))
    return 0 if r["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
