"""Kupiec unconditional coverage, Christoffersen independence / conditional coverage,
Acerbi-Szekely Z2 for Expected Shortfall, Brier score, Basel traffic-light zone."""
from __future__ import annotations
import numpy as np
import pandas as pd
from scipy import stats
from scipy.special import xlogy


def kupiec(exceed: np.ndarray, alpha: float) -> dict:
    n = len(exceed); x = int(np.sum(exceed)); p = 1 - alpha
    # log form: raw powers underflow to 0 for long histories (EQ-B-0012); xlogy(0, 0) = 0 covers x = 0 and x = n
    phat = x / n
    lr = -2 * (xlogy(n - x, 1 - p) + xlogy(x, p) - xlogy(n - x, 1 - phat) - xlogy(x, phat))
    return {"n": n, "exceedances": x, "expected": n * p, "LR_uc": float(lr), "p_value": float(stats.chi2.sf(lr, 1))}


def christoffersen(exceed: np.ndarray, alpha: float) -> dict:
    e = np.asarray(exceed, dtype=int)
    pairs = list(zip(e[:-1], e[1:]))
    n00 = sum(1 for a, b in pairs if a == 0 and b == 0); n01 = sum(1 for a, b in pairs if a == 0 and b == 1)
    n10 = sum(1 for a, b in pairs if a == 1 and b == 0); n11 = sum(1 for a, b in pairs if a == 1 and b == 1)
    p01 = n01 / (n00 + n01) if (n00 + n01) else 0.0; p11 = n11 / (n10 + n11) if (n10 + n11) else 0.0
    pi = (n01 + n11) / max(1, len(pairs))

    def ll(p, k1, k0):
        return (k1 * np.log(p) if k1 else 0.0) + (k0 * np.log(1 - p) if k0 and p < 1 else 0.0)
    l0 = ll(pi, n01 + n11, n00 + n10); l1 = ll(p01, n01, n00) + ll(p11, n11, n10)
    lr_ind = float(max(0.0, -2 * (l0 - l1)))
    k = kupiec(exceed, alpha)
    lr_cc = k["LR_uc"] + lr_ind
    return {"n00": n00, "n01": n01, "n10": n10, "n11": n11, "p01": p01, "p11": p11, "LR_ind": lr_ind, "p_value_ind": float(stats.chi2.sf(lr_ind, 1)),
            "LR_cc": float(lr_cc), "p_value_cc": float(stats.chi2.sf(lr_cc, 2))}


def acerbi_szekely_z2(losses: np.ndarray, var: np.ndarray, es: np.ndarray, alpha: float) -> dict:
    exceed = losses > var
    n = len(losses)
    z2 = float(1 - np.sum(losses[exceed] / es[exceed]) / (n * (1 - alpha))) if n else np.nan
    return {"Z2": z2, "critical": -0.7, "pass": bool(z2 > -0.7), "es_ratio": float(np.mean(losses[exceed] / es[exceed])) if exceed.any() else np.nan}


def brier_score(prob: np.ndarray, outcome: np.ndarray) -> float:
    return float(np.mean((np.asarray(prob) - np.asarray(outcome)) ** 2))


def basel_zone(exceedances: int, n: int, alpha: float = 0.99) -> str:
    """Traffic-light zones scaled from the 250-day Basel table by the binomial cumulative probability."""
    cdf = stats.binom.cdf(exceedances, n, 1 - alpha)
    return "Green" if cdf < 0.95 else ("Yellow" if cdf < 0.9999 else "Red")


def backtest_history(history: pd.DataFrame, alpha: float = 0.99, var_col: str = "var", es_col: str = "es", loss_col: str = "loss") -> dict:
    """history: one row per period with realised loss (+ = loss) and the forecast VaR and ES for that period."""
    losses = history[loss_col].to_numpy(dtype=float); var = history[var_col].to_numpy(dtype=float); es = history[es_col].to_numpy(dtype=float)
    exceed = losses > var
    k = kupiec(exceed, alpha); c = christoffersen(exceed, alpha); z = acerbi_szekely_z2(losses, var, es, alpha)
    verdict = "Pass" if (k["p_value"] >= 0.05 and c["p_value_cc"] >= 0.05 and z["pass"]) else "Fail"
    return {"alpha": alpha, "periods": len(losses), "kupiec": k, "christoffersen": c, "acerbi_szekely": z,
            "basel_zone": basel_zone(k["exceedances"], len(losses), alpha), "verdict": verdict}


def synthetic_history(losses_mc: np.ndarray, var99_12m: float, es99_12m: float, periods: int = 120, periods_per_year: int = 12, seed: int = 11,
                      as_of=None) -> pd.DataFrame:
    """Monthly history drawn from the simulated 12-month loss distribution scaled by sqrt(1/periods_per_year),
    for exercising the backtests when no realised P&L history is loaded. The dates end at the month of `as_of`
    (VF-006: pass the run's as_of so a replay gives the same frame); without it, today (unchanged default)."""
    rng = np.random.default_rng(seed)
    scale = np.sqrt(1 / periods_per_year)
    draw = rng.choice(losses_mc, size=periods, replace=True) * scale
    end = pd.Timestamp(as_of).normalize() if as_of is not None else pd.Timestamp.today().normalize()
    dates = pd.date_range(end=end, periods=periods, freq="MS")
    return pd.DataFrame({"period": np.arange(1, periods + 1), "date": dates, "loss": draw, "var": var99_12m * scale, "es": es99_12m * scale})
