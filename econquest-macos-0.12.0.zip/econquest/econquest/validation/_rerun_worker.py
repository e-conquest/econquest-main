"""Subprocess worker for `replicate_archive --rerun` (EQ-B-0058): runs a frozen release's own engine on frozen inputs.

Run as `python -I _rerun_worker.py <spec.json>`, never imported by the econquest package. `-I` keeps the working
tree's `econquest` (and the current directory) off sys.path, so the only engine on the path is the one under
`spec["root"]` (an unzipped release). Prints one JSON object {job_id: metrics} on stdout. Writes nothing.

spec = {"root": "<unzipped release folder holding econquest/>", "data": "<data folder>",
        "jobs": [{"id": ..., "paths": 100000, "patches": {...}, "scenario": "FED22", "drop_rates": false,
                  "prices": "<optional price csv>", "prices_through": "<optional YYYY-MM-DD>", "as_of": "2026-10-23"}]}
"""
from __future__ import annotations

import json
import sys
from pathlib import Path


def _universe(data: Path, prices: str | None, through: str | None):
    import numpy as np
    import pandas as pd
    from econquest.config import Settings
    from econquest.ingestion import load_universe
    u = load_universe(data)
    if prices:
        u.prices = pd.read_csv(prices, parse_dates=["date"], index_col="date")
    px = getattr(u, "prices", None)
    if through and px is not None and len(px):
        d = pd.to_datetime(px["date"] if "date" in px.columns else px.index)
        u.prices = px[np.asarray(d <= pd.Timestamp(through))]
    return u, Settings.load(data / "assumptions.json")


def run_jobs(spec: dict) -> dict:
    root = Path(spec["root"]).resolve()
    sys.path.insert(0, str(root))
    import econquest
    if Path(econquest.__file__).resolve().parents[1] != root:          # the frozen engine, not the working tree
        raise SystemExit(f"wrong engine on path: {econquest.__file__}")
    from econquest.engine.pipeline import run_pipeline
    from econquest.engine.stress import Scenario, load_scenarios
    data = Path(spec["data"]).resolve()
    out = {"_engine": {"version": econquest.__version__, "file": econquest.__file__}}
    for job in spec["jobs"]:
        if job.get("count_scenarios"):
            out[job["id"]] = {"loadable_scenarios": float(len(load_scenarios(data / "scenarios.json")))}
            continue
        u, s = _universe(data, job.get("prices"), job.get("prices_through"))
        if job.get("patches"):
            s = s.copy_with(**job["patches"])
        if job.get("scenario"):
            sc = load_scenarios(data / "scenarios.json")[job["scenario"]]
            if job.get("drop_rates"):
                sc = Scenario(sc.key, sc.name, sc.description, [x for x in sc.shocks if x.get("target") != "rates"],
                              sc.source, sc.kind, base_dir=sc.base_dir)
            u, s = sc.apply(u, s)
        r = run_pipeline(u, s, label=f"rerun-{job['id']}", paths=int(job["paths"]), as_of=job.get("as_of", "2026-10-23"))
        m = {k: float(v) for k, v in r.metrics.items() if isinstance(v, (int, float))}
        v = (getattr(r, "provenance", None) or {}).get("versions") or {}
        m.update({k: v.get(k) for k in ("code_hash", "data_hash", "run_hash")})
        c = r.country
        names = c["country"] if "country" in c.columns else c.index
        m["pd_default"] = {str(n): float(p) for n, p in zip(names, c["pd_default"])}
        out[job["id"]] = m
    return out


if __name__ == "__main__":
    print(json.dumps(run_jobs(json.loads(Path(sys.argv[1]).read_text()))))
