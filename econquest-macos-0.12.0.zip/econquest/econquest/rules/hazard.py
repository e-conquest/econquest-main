"""Hazard-event and hazard-panel rules (ADR-A-001 first wave, contract C15; moved from
econquest.validation.hazard_events and hazard_panel by EQ-B-0120, code unchanged).

`episodes_in_window` and `redefault_years` (indicator 1.8, indicator-rules.md section 16), the CRAG event rules `RECOMMENDED_RULE`
("crag_v1") and `PLAIN_RULE`, `EventRuleError`, and the panel series lists `WEO_CODES`, `WB_CODES` and the World
Bank aggregate codes `AGGREGATES`. `hazard_events.build_events` / `resolve` read files and stay in validation
(listed lazy calls in C15).

Layering: imports pandas only, never econquest.ingestion, engine, scorecard, validation or presentation.
"""
from __future__ import annotations

import pandas as pd

RECOMMENDED_RULE = {"min_amount_musd": 10.0, "cure_years": 2}   # "crag_v1", docs/validation/hazard-panel-crag.md
PLAIN_RULE = {"min_amount_musd": 0.0, "cure_years": 1}          # the episode file as it is

WEO_CODES = ["GGXWDG_NGDP", "GGXONLB_NGDP", "BCA_NGDPD", "NGDP_RPCH", "PCPIPCH"]
WB_CODES = ["DT.DOD.DSTC.IR.ZS", "FI.RES.TOTL.MO", "PV.EST"]
AGGREGATES = {"WLD", "EMU", "EUQ", "EUR", "EAS", "ECS", "LCN", "MEA", "NAC", "SAS", "SSF", "HIC", "LIC", "LMC", "UMC", "MIC",
              "OED", "ARB", "CEB", "EAP", "ECA", "LAC", "MNA", "SSA", "IBD", "IBT", "IDA", "IDB", "IDX", "LDC", "LMY", "PRE",
              "PST", "FCS", "HPC", "OSS", "SST", "TEA", "TEC", "TLA", "TMN", "TSA", "TSS", "AFE", "AFW", "EAR", "LTE", "INX"}


class EventRuleError(ValueError):
    """The event source or rule cannot be applied (bad setting, missing raw file, provenance mismatch)."""


def episodes_in_window(events: pd.DataFrame, first: int, last: int, rule: str = "overlap") -> pd.DataFrame:
    """Episodes of `apply_cure` output that fall in first..last (indicator 1.8, indicator-rules.md section 16).

    "overlap" tests the years actually in default (`end_spell`), never `end`, which also covers the cure years after
    a spell (not default years). "start" tests the start year only."""
    end = events["end_spell"] if "end_spell" in events.columns else events["end"]
    if rule == "overlap":
        hit = (end >= first) & (events["start"] <= last)
    elif rule == "start":
        hit = events["start"].between(first, last)
    else:
        raise EventRuleError(f"rule must be 'overlap' or 'start', got {rule!r}")
    return events[hit].reset_index(drop=True)


# Rule 16 point 3a (indicator 1.8, EQ-B-0127): a new default inside one crag_v1 episode, dated from CRAG's own annual
# in-scope arrears (bank loans + bonds + LC debt, USD m). A year y counts when, in the same episode,
#   - the year before was still in default (arrears above the crag_v1 floor), so a restart that crag_v1 merged
#     through the cure years is not counted twice;
#   - arrears had first been cut to at most `cut_share` of the episode's running peak (a restructuring or
#     settlement), and
#   - arrears then rose at least `rise_multiple` times year on year, by at least `min_rise_musd`;
#   - and y is more than `merge_years` after the previous counted year (one multi-year build-up is one event).
REDEFAULT_RULE = {"cut_share": 0.5, "rise_multiple": 2.0, "min_rise_musd": 10.0, "merge_years": 2,
                  "floor_musd": RECOMMENDED_RULE["min_amount_musd"]}


def redefault_years(annual: pd.Series, start: int, end_spell: int, first: int, last: int,
                    rule: dict | None = None) -> list[int]:
    """Years in first..last of new defaults inside the episode start..end_spell (REDEFAULT_RULE above). `annual`:
    one country's in-scope CRAG arrears by year (USD m); a missing year is 0. Pure: no file, no clock."""
    r = {**REDEFAULT_RULE, **(rule or {})}
    a = pd.Series(annual, dtype=float).groupby(level=0).sum()
    a.index = a.index.astype(int)
    a = a.reindex(range(int(start), int(end_spell) + 1), fill_value=0.0).fillna(0.0)
    out: list[int] = []
    peak = float(a.loc[int(start)])
    for y in range(int(start) + 1, int(end_spell) + 1):
        prev, cur = float(a.loc[y - 1]), float(a.loc[y])
        if (first <= y <= last and prev > r["floor_musd"] and prev <= r["cut_share"] * peak
                and cur >= r["rise_multiple"] * prev and cur - prev >= r["min_rise_musd"]
                and (not out or y - out[-1] > r["merge_years"])):
            out.append(y)
        peak = max(peak, cur)
    return out

