"""Text stress index rules (EQ-B-0135, PI-13, roadmap 3.5; method: docs/validation/indicator-rules.md section 24).

A transparent dictionary method, no fitted or downloaded model: every number can be recomputed by hand from the
word lists below and the document text.

    tokens(text)                    -> list[str]  lower-case words (letters and digits, apostrophes dropped)
    score_document(text, language)  -> dict       counts and per-1000-word rates for one document (DOC_FIELDS)
    aggregate(scores)               -> dict       one country-date index value from its documents' scores
    signal(level, history, level_3m_ago) -> dict  early-warning state vs the country's own history (THRESHOLDS)
    auc(scores, labels)             -> float | None   Mann-Whitney AUC (ties count one half)
    lead_months(signal_dates, episode_start, horizon)  -> float | None

Lexicon (English only, LEXICON_LANGUAGES): a term is a word, a stem ending in "*" (prefix match) or a phrase of such
words separated by spaces. Tone words (NEGATIVE, POSITIVE) are flipped when one of NEGATORS is among the three words
before them in the same sentence. Phrases and negation never cross a sentence end (. ! ? ; or a line break). Topic
terms (TOPICS) are counted without negation. `distress` is the severe topic: it enters the index
with weight SEVERE_WEIGHT.

    doc stress     = tone_net_pk + SEVERE_WEIGHT * severe_pk
    tone_net_pk    = 1000 * (negative - positive) / words
    severe_pk      = 1000 * distress hits / words
    country index  = mean doc stress over the documents published in the WINDOW_DAYS up to the date (status "value"
                     when at least MIN_DOCS documents scored, else "insufficient")

Layering: numpy only (econquest.rules imports config, numpy and pandas, nothing above). Pure: no file, clock or network.
"""
from __future__ import annotations

import numpy as np

METHOD = "tsi_lex_v1"
LEXICON_LANGUAGES = ("en",)
WINDOW_DAYS = 90            # documents published in (date - 90 days, date] make the index on that date
MIN_TOKENS = 50             # shorter documents are not scored (a title or a one-line notice)
MIN_DOCS = 2                # scored documents needed in the window for an index value
SEVERE_WEIGHT = 2.0
NEGATION_SPAN = 3

NEGATORS = ("not", "no", "never", "without", "nor", "neither")

NEGATIVE = (
    "crisis", "crises", "pressure*", "shortfall*", "sever*", "deteriorat*", "weak*", "vulnerab*", "volatil*",
    "declin*", "slowdown", "shock*", "uncertain*", "downside", "stress*", "strain*", "turmoil", "distress*", "loss",
    "losses", "adverse*", "concern*", "worsen*", "recession*", "depreciat*", "outflow*", "unrest", "protest*",
    "sanction*", "disorderly", "contagion", "fragil*", "difficult*", "challeng*", "imbalance*", "overvalu*",
    "scarcit*", "shortage*", "panic", "plunge*", "slump*", "collapse*", "spillover*", "headwind*",
)
POSITIVE = (
    "stable", "stability", "stabilis*", "stabiliz*", "resilien*", "improv*", "recover*", "strengthen*", "strong",
    "stronger", "robust*", "surplus*", "upgrad*", "confiden*", "favourab*", "favorab*", "rebound*", "buoyant",
    "progress", "success*", "on track", "solid", "comfortabl*", "sound", "healthy", "accumulat*", "anchored",
    "upturn", "expansion",
)
TOPICS = {
    "fiscal": ("deficit*", "debt", "debts", "debt service", "fiscal*", "borrowing*", "financing gap*",
               "financing need*", "primary balance", "amortisation", "amortization", "eurobond*", "budget*",
               "revenue shortfall*", "spending"),
    "external": ("reserve*", "foreign exchange", "exchange rate*", "devalu*", "depreciat*", "balance of payments",
                 "current account", "outflow*", "import cover", "capital flight", "parallel market*", "fx"),
    "banking": ("bank*", "deposit*", "liquidity", "non-performing", "npl*", "capital adequacy", "solvency",
                "recapitali*", "credit growth", "lender of last resort"),
    "inflation": ("inflation*", "price*", "tighten*", "policy rate*", "rate hike*", "monetary"),
    "imf_programme": ("programme*", "program", "programs", "extended fund facility", "extended credit facility",
                      "stand-by arrangement*", "standby arrangement*", "staff-level agreement*", "disbursement*",
                      "waiver*", "rapid financing instrument", "emergency financing", "structural benchmark*",
                      "article iv"),
    "distress": ("default*", "restructur*", "debt relief", "haircut*", "capital control*", "bank run*",
                 "insolven*", "debt distress", "unsustainab*", "missed payment*", "moratori*", "standstill",
                 "hyperinflation*", "currency crisis", "debt crisis", "financial crisis", "arrears", "bailout*",
                 "bail-out*", "suspend* payment*", "debt treatment", "common framework", "grace period"),
}
SEVERE_TOPIC = "distress"

THRESHOLDS = {
    "hist_months": 36,          # own history: month-end index values in the 36 months before the date
    "min_hist": 12,             # fewer valid history points: status "no_history"
    "sd_floor": 0.5,            # per 1000 words; keeps z finite for a country whose texts never change
    "warning_z": 2.0,           # warning: level z >= 2.0, or
    "warning_z_with_rise": 1.0, #          level z >= 1.0 and 3-month rise >= 1.5 sd
    "warning_rise_sd": 1.5,
    "watch_z": 1.0,             # watch: level z >= 1.0 or 3-month rise >= 1.0 sd
    "watch_rise_sd": 1.0,
}
SIGNALS = ("warning", "watch", "normal", "no_history", "insufficient")
DOC_FIELDS = ("words", "negative", "positive", "tone_net_pk", "severe_pk", "doc_stress", "scored", "reason") + \
    tuple(f"topic_{t}_pk" for t in TOPICS)

_KEEP = set("abcdefghijklmnopqrstuvwxyz0123456789-")


def tokens(text: str) -> list[str]:
    """Lower-case words: runs of letters, digits and inner hyphens; every other character splits; apostrophes drop."""
    t = (text or "").lower().replace("'", "").replace("’", "")
    chars = [c if (c in _KEEP or c.isalpha()) else " " for c in t]
    return [w.strip("-") for w in "".join(chars).split() if w.strip("-")]


def _sentences(text: str) -> list[str]:
    """Split at . ! ? ; and line breaks (a full stop between digits, as in 2.5, does not split)."""
    t = text or ""
    out, cur = [], []
    for i, c in enumerate(t):
        if c in "!?;\n" or (c == "." and not (0 < i < len(t) - 1 and t[i - 1].isdigit() and t[i + 1].isdigit())):
            out.append("".join(cur))
            cur = []
        else:
            cur.append(c)
    out.append("".join(cur))
    return out


def _compile(terms) -> list[tuple]:
    return [tuple(term.split()) for term in terms]


def _word_match(pat: str, w: str) -> bool:
    return w.startswith(pat[:-1]) if pat.endswith("*") else w == pat


def _hits(toks: list[str], terms) -> list[int]:
    """Start positions of each term's matches (a phrase matches consecutive words). Overlapping terms each count."""
    out = []
    for pats in _compile(terms):
        n = len(pats)
        for i in range(len(toks) - n + 1):
            if all(_word_match(p, toks[i + k]) for k, p in enumerate(pats)):
                out.append(i)
    return out


def _negated(toks: list[str], i: int) -> bool:
    return any(w in NEGATORS for w in toks[max(0, i - NEGATION_SPAN):i])


def score_document(text: str, language: str = "en") -> dict:
    """One document's counts and rates (DOC_FIELDS). Not scored (scored False, reason given) when the language has
    no lexicon or the text has fewer than MIN_TOKENS words; the rates are then NaN."""
    lang = (language or "").split("-")[0].lower()
    sents = [t for t in (tokens(x) for x in _sentences(text)) if t]
    toks = [w for t in sents for w in t]
    base = {"words": len(toks), "negative": 0, "positive": 0, "scored": False, "reason": ""}
    nan = {k: float("nan") for k in ("tone_net_pk", "severe_pk", "doc_stress")}
    nan.update({f"topic_{t}_pk": float("nan") for t in TOPICS})
    if lang not in LEXICON_LANGUAGES:
        return {**base, **nan, "reason": f"language {lang or '?'}: no lexicon"}
    if len(toks) < MIN_TOKENS:
        return {**base, **nan, "reason": f"{len(toks)} words < {MIN_TOKENS}"}
    neg = pos = 0
    for sent in sents:                                     # phrases and negation never cross a sentence end
        for i in _hits(sent, NEGATIVE):
            if _negated(sent, i):
                pos += 1
            else:
                neg += 1
        for i in _hits(sent, POSITIVE):
            if _negated(sent, i):
                neg += 1
            else:
                pos += 1
    n = float(len(toks))
    topics = {f"topic_{t}_pk": 1000.0 * sum(len(_hits(x, terms)) for x in sents) / n for t, terms in TOPICS.items()}
    tone = 1000.0 * (neg - pos) / n
    severe = topics[f"topic_{SEVERE_TOPIC}_pk"]
    return {**base, "negative": neg, "positive": pos, "tone_net_pk": tone, "severe_pk": severe,
            "doc_stress": tone + SEVERE_WEIGHT * severe, "scored": True, **topics}


AGG_FIELDS = ("n_docs", "n_scored", "n_tokens", "stress_index", "tone_net_pk", "severe_pk") + \
    tuple(f"topic_{t}_pk" for t in TOPICS) + ("status",)


def aggregate(scores: list[dict]) -> dict:
    """Equal-weight mean over the scored documents of one country-date (AGG_FIELDS)."""
    ok = [s for s in scores if s.get("scored")]
    out = {"n_docs": len(scores), "n_scored": len(ok), "n_tokens": int(sum(s["words"] for s in ok))}
    keys = ("doc_stress", "tone_net_pk", "severe_pk") + tuple(f"topic_{t}_pk" for t in TOPICS)
    for k in keys:
        name = "stress_index" if k == "doc_stress" else k
        out[name] = float(np.mean([s[k] for s in ok])) if len(ok) >= MIN_DOCS else float("nan")
    out["status"] = "value" if len(ok) >= MIN_DOCS else "insufficient"
    return out


def signal(level: float, history, level_3m_ago: float | None = None, thresholds: dict | None = None) -> dict:
    """Early-warning state of one index value against the country's own earlier values (THRESHOLDS).

    `history`: index values strictly before the date (the caller passes the hist_months window; NaN dropped here).
    Returns {signal, z_level, delta_3m, dz_3m, hist_n, hist_mean, hist_sd}."""
    th = {**THRESHOLDS, **(thresholds or {})}
    h = np.asarray([x for x in history if x is not None and np.isfinite(x)], dtype=float)
    out = {"z_level": float("nan"), "delta_3m": float("nan"), "dz_3m": float("nan"), "hist_n": int(h.size),
           "hist_mean": float("nan"), "hist_sd": float("nan")}
    if level is None or not np.isfinite(level):
        return {**out, "signal": "insufficient"}
    if h.size < th["min_hist"]:
        return {**out, "signal": "no_history"}
    mu = float(h.mean())
    sd = max(float(h.std(ddof=1)), th["sd_floor"])
    z = (level - mu) / sd
    d = (level - level_3m_ago) if (level_3m_ago is not None and np.isfinite(level_3m_ago)) else float("nan")
    dz = d / sd if np.isfinite(d) else float("nan")
    rise = dz if np.isfinite(dz) else -np.inf
    if z >= th["warning_z"] or (z >= th["warning_z_with_rise"] and rise >= th["warning_rise_sd"]):
        s = "warning"
    elif z >= th["watch_z"] or rise >= th["watch_rise_sd"]:
        s = "watch"
    else:
        s = "normal"
    return {**out, "signal": s, "z_level": float(z), "delta_3m": float(d), "dz_3m": float(dz), "hist_mean": mu,
            "hist_sd": sd}


def auc(scores, labels) -> float | None:
    """Mann-Whitney AUC of `scores` for binary `labels` (ties one half); None without both classes."""
    s = np.asarray(scores, dtype=float)
    y = np.asarray(labels, dtype=int)
    keep = np.isfinite(s)
    s, y = s[keep], y[keep]
    pos, neg = s[y == 1], s[y == 0]
    if pos.size == 0 or neg.size == 0:
        return None
    gt = (pos[:, None] > neg[None, :]).sum()
    eq = (pos[:, None] == neg[None, :]).sum()
    return float((gt + 0.5 * eq) / (pos.size * neg.size))


def lead_months(warning_dates, episode_start, horizon_months: int = 24) -> float | None:
    """Months from the first warning in the `horizon_months` before `episode_start` to episode_start (numpy
    datetime64[D] or ISO strings); None when no warning falls in that window."""
    start = np.datetime64(str(episode_start)[:10], "D")
    lo = start - np.timedelta64(int(round(horizon_months * 30.4375)), "D")
    ds = sorted(np.datetime64(str(d)[:10], "D") for d in warning_dates)
    ds = [d for d in ds if lo <= d < start]
    if not ds:
        return None
    return float(round((start - ds[0]).astype(int) / 30.4375, 1))
