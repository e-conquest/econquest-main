"""Shared pure rules below ingestion and validation (ADR-A-001, contract C15; Team B, EQ-B-0120).

`econquest.rules.research` and `econquest.rules.hazard` hold rule functions and constants that both Team A's pull
(econquest.ingestion) and Team B's validation tools apply, so there is one implementation and no upward import.
`econquest.rules.market` (complete_date) and `econquest.rules.dsa` (ppg_debt_service_detail, the 1.2 rule) were added
for C15 under HO-20261026-A-B-004 (EQ-B-0134), with `rules.research.violence_trend_ratio` (6.9).
`econquest.rules.sovereign` (EQ-B-0136, PI-13) holds the sovereign depth research rules (ARA, GFN by year, maturity wall,
IMF programme model imfprog_v1; indicator-rules.md section 22); it is Team B internal and not part of C15.
`econquest.rules.macro` (EQ-B-0137, PI-13) holds the macro depth rules (REER misalignment, BEER, official-FX REER
proxy, Taylor-type policy path, terms-of-trade shock channel; section 23) and `econquest.rules.text` (EQ-B-0135,
PI-13) the text stress lexicon and scoring rules (tsi_lex_v1; section 24); both are Team B internal and not part of C15.
`econquest.rules.escalation` (EQ-B-0142, PI-14) holds the conflict escalation ladder and its a priori transition
model (esc_ladder_v1; section 25); Team B internal and not part of C15.
This package may import econquest.config, numpy and pandas only. The old names in econquest.validation are
re-exports of the same objects for one release.
"""
