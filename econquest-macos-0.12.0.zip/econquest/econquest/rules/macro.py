"""Macro depth rules (EQ-B-0137, PI-13): FX valuation, policy-rate path and the commodity terms-of-trade channel.

Pure functions on plain series and tables. docs/validation/indicator-rules.md section 23 is the method. Nothing
here feeds the base: the FX and policy views are display only (econquest.validation.macro_depth), and the
terms-of-trade channel runs only inside a research stress scenario (`{"target": "tot"}`, TOT_OIL in
engine.stress.RESEARCH_LIBRARY, expanded by engine.stress.apply_shocks). Every parameter below is a fixed, documented research or judgement value,
not an estimate.

Layering: imports numpy and pandas only (tests/test_rules_package.py ALLOWED_IMPORTS).
"""
from __future__ import annotations


import numpy as np
import pandas as pd

# ---------------------------------------------------------------- 1. FX valuation

REER_WINDOW_MONTHS = 120       # trailing window, the 2.12 BIS rule (feeds.bis_transforms: last vs mean of 120 months)
REER_MIN_MONTHS = 60           # as the 2.12 BIS rule
PROXY_MIN_MONTHS = 24          # official-FX proxy: the price history starts 2023-10, so at most ~36 months exist
MONTHLY_PUBLICATION_LAG_DAYS = 20   # a month is usable from month end + 20 days (BIS EER: mid next month; judgement)
US_INFLATION_PCT = 2.5         # proxy deflator for the US leg: no US CPI in the shared folder (judgement, labelled)

# BEER: fixed elasticities in deviations from the window mean (research values inside published ranges, not fitted)
BEER_COEF = {
    "productivity": (0.5, "% REER per % relative real GDP per person", "Balassa-Samuelson; literature range 0.2-0.7"),
    "nfa": (0.1, "% REER per pp of GDP net foreign assets", "CGER / EBA-type NFA elasticity; range 0.03-0.15"),
    "tot": (0.4, "% REER per % commodity terms of trade", "commodity-currency elasticity; range 0.2-0.6"),
}


def usable_month(period: str, as_of) -> bool:
    """A monthly observation 'YYYY-MM' is usable once month end + MONTHLY_PUBLICATION_LAG_DAYS <= as_of."""
    end = pd.Period(str(period)[:7], freq="M").to_timestamp(how="end").normalize()
    return end + pd.Timedelta(days=MONTHLY_PUBLICATION_LAG_DAYS) <= pd.Timestamp(as_of)


def reer_misalignment(levels: pd.Series, window: int = REER_WINDOW_MONTHS, min_obs: int = REER_MIN_MONTHS) -> dict:
    """Valuation of the last observation of a monthly real exchange rate index against its own trailing history.

    `levels`: index level by month (ascending; already cut to the as_of). Over the last `window` months (latest
    included): gap_pct = last / mean - 1 (in %, the 2.12 formula; + = stronger than average, i.e. overvalued
    against history), z = (ln last - mean ln) / sd ln (ddof 1). Returns {} when fewer than `min_obs` months."""
    x = pd.to_numeric(levels, errors="coerce").dropna()
    x = x[x > 0]
    if len(x) < min_obs:
        return {}
    w = x.iloc[-window:]
    lw = np.log(w.to_numpy(dtype=float))
    sd = float(np.std(lw, ddof=1)) if len(lw) > 1 else float("nan")
    return {"last": float(w.iloc[-1]), "mean": float(w.mean()), "gap_pct": float(w.iloc[-1] / w.mean() * 100 - 100),
            "z": float((lw[-1] - lw.mean()) / sd) if sd > 0 else float("nan"), "months": int(len(w)),
            "first_period": str(w.index[0]), "last_period": str(w.index[-1])}


def monthly_cpi_from_annual(annual_pct: dict[int, float], months: list[str]) -> pd.Series:
    """A monthly price index (first month = 1) from annual average inflation rates: each month of year y grows by
    (1 + pi_y / 100) ** (1/12). A year with no rate gives NaN from then on (no carry-over)."""
    lvl, out = 1.0, {}
    for i, m in enumerate(months):
        if i > 0:
            pi = annual_pct.get(int(str(m)[:4]))
            if pi is None or not np.isfinite(pi):
                lvl = float("nan")
            else:
                lvl *= (1 + pi / 100) ** (1 / 12)
        out[m] = lvl
    return pd.Series(out, dtype=float)


def official_fx_reer_proxy(usd_rate: pd.Series, dom_inflation: dict[int, float], as_of,
                           us_inflation_pct: float = US_INFLATION_PCT) -> pd.Series:
    """PROXY real exchange rate vs the US dollar where no REER is in the shared folder.

    `usd_rate`: daily official FX, units of the currency per USD (prices.csv convention), indexed by date. Monthly
    means of complete usable months, inverted to USD per unit (up = stronger), times domestic / US price levels
    (domestic from annual inflation, US at a fixed `us_inflation_pct`). Bilateral against the USD only: a proxy
    for the effective rate, labelled as such. Rebased so the first usable month is 100 (gap and z do not depend on it)."""
    s = pd.to_numeric(usd_rate, errors="coerce").dropna()
    s = s[s > 0]
    if s.empty:
        return pd.Series(dtype=float)
    s.index = pd.to_datetime(s.index)
    s = s[s.index <= pd.Timestamp(as_of)]
    m = s.groupby(s.index.to_period("M")).mean()
    m.index = m.index.astype(str)
    m = m[[usable_month(p, as_of) for p in m.index]]
    if m.empty:
        return pd.Series(dtype=float)
    months = list(m.index)
    dom = monthly_cpi_from_annual(dom_inflation, months)
    us = monthly_cpi_from_annual({int(p[:4]): us_inflation_pct for p in months}, months)
    out = ((1.0 / m) * dom / us).dropna()
    return out / out.iloc[0] * 100 if len(out) else out          # rebased: first usable month = 100


def cumulative_gap(values: dict[int, float], years: list[int]) -> float:
    """Last minus mean of the running sum of `values` over `years` (deviation of an accumulated stock from its
    window mean). NaN when any year is missing."""
    v = [values.get(y) for y in years]
    if not years or any(x is None or not np.isfinite(x) for x in v):
        return float("nan")
    cum = np.cumsum(np.asarray(v, dtype=float))
    return float(cum[-1] - cum.mean())


def beer_misalignment(reer_gap_pct: float, gap_productivity: float, gap_nfa: float, gap_tot: float,
                      coef: dict | None = None) -> dict:
    """Simple BEER in deviations from the window mean, fixed specification:

        fitted_gap = b_prod * gap_productivity + b_nfa * gap_nfa + b_tot * gap_tot
        misalignment = reer_gap_pct - fitted_gap        (+ = overvalued against fundamentals)

    A missing fundamental counts as 0 only for the ToT term of a non-commodity exporter (the caller passes 0.0);
    any other NaN makes the result NaN."""
    k = {n: v[0] for n, v in (coef or BEER_COEF).items()}
    fitted = k["productivity"] * gap_productivity + k["nfa"] * gap_nfa + k["tot"] * gap_tot
    if not all(np.isfinite(x) for x in (reer_gap_pct, fitted)):
        return {"fitted_gap_pct": float("nan"), "misalignment_pct": float("nan")}
    return {"fitted_gap_pct": float(fitted), "misalignment_pct": float(reer_gap_pct - fitted)}


# ---------------------------------------------------------------- 2. Policy-rate path

POLICY_STALE_DAYS = 30           # BIS daily rule (indicator-rules section 9 / 11)
TAYLOR = {
    "neutral_real_rate": (1.5, "% real neutral rate r* when no own history", "judgement; EM range 0.5-2.5"),
    "neutral_years": (10, "years of own ex-post real policy rate for r* (5 needed)", "own-history r*, research choice"),
    "neutral_bounds": ((0.5, 5.0), "% bounds on the own-history r*", "judgement"),
    "inflation_weight": (0.5, "on (inflation - target)", "Taylor (1993)"),
    "gap_weight": (0.5, "on the output-gap proxy", "Taylor (1993)"),
    "smoothing": (0.75, "quarterly weight on the previous rate", "judgement; partial adjustment, 0.7-0.9 in estimates"),
    "quarters": (4, "quarters of implied path", "display choice"),
    "max_inflation": (100.0, "% inflation above which the rule is not computed", "judgement; very high inflation"),
    "growth_window": (10, "years of trend growth for the output-gap proxy (2020-21 left out)", "as 5.12"),
}
DEFAULT_TARGET = 3.0             # % when the central bank states no point target (judgement, labelled)
# Point inflation targets (mid-point of a band) as publicly stated by each central bank; desk table, verify on use.
INFLATION_TARGETS = {
    "BRA": (3.0, "BCB continuous target 3.0%"), "COL": (3.0, "BanRep 3%"), "IND": (4.0, "RBI 4% (2-6 band)"),
    "PHL": (3.0, "BSP 3% (2-4)"), "KOR": (2.0, "BoK 2%"), "JPN": (2.0, "BoJ 2%"), "CHN": (2.0, "PBoC/State Council CPI goal ~2% (judgement)"),
    "PAK": (6.0, "SBP 5-7% medium term"), "ZMB": (7.0, "BoZ 6-8% band"), "NGA": (7.5, "CBN 6-9% band (judgement)"),
    "VNM": (4.5, "SBV ceiling 4.5% (judgement: ceiling used as target)"),
}
# Regimes where a domestic Taylor rule says nothing (no own instrument, or an exchange-rate instrument).
NOT_APPLICABLE = {
    "SGP": "exchange-rate-centred policy (S$NEER band): no policy rate",
    "BLZ": "hard peg to the USD: no independent policy rate",
    "SEN": "WAEMU currency union (BCEAO): policy set for the union, peg to the euro",
    "ZWE": "multi-currency / dollarised economy: rule not meaningful",
}


def output_gap_proxy(growth: dict[int, float], year: int, window: int | None = None) -> float:
    """Growth-gap proxy for the output gap: real growth in `year` minus the mean of the previous `window` years
    (2020 and 2021 left out, as 5.12). NaN when `year` or fewer than half the window years are missing."""
    window = int(window or TAYLOR["growth_window"][0])
    g = growth.get(year)
    hist = [growth.get(y) for y in range(year - window, year) if y not in (2020, 2021)]
    hist = [h for h in hist if h is not None and np.isfinite(h)]
    if g is None or not np.isfinite(g) or len(hist) < window // 2:
        return float("nan")
    return float(g - np.mean(hist))


def neutral_rate(policy_by_year: dict[int, float], inflation_by_year: dict[int, float], year: int) -> tuple[float, str]:
    """r*: mean ex-post real policy rate (annual mean policy rate minus annual inflation) over the `neutral_years`
    years before `year`, at least 5 present, clipped to `neutral_bounds`; else the fixed neutral_real_rate.
    Returns (r*, basis)."""
    n = int(TAYLOR["neutral_years"][0])
    lo, hi = TAYLOR["neutral_bounds"][0]
    real = [policy_by_year[y] - inflation_by_year[y] for y in range(year - n, year)
            if y in policy_by_year and y in inflation_by_year and np.isfinite(policy_by_year[y] - inflation_by_year[y])]
    if len(real) >= 5:
        return float(np.clip(np.mean(real), lo, hi)), f"own {len(real)}-year mean ex-post real policy rate, clipped to [{lo}, {hi}]"
    return float(TAYLOR["neutral_real_rate"][0]), f"fixed r* {TAYLOR['neutral_real_rate'][0]}% (no own history; judgement)"


def taylor_rate(inflation: float, target: float, gap: float, params: dict | None = None, neutral: float | None = None) -> float:
    """i* = r* + pi + a (pi - pi*) + b gap (all in %). `neutral` overrides the fixed r*."""
    p = {k: v[0] for k, v in (params or TAYLOR).items()}
    r = p["neutral_real_rate"] if neutral is None else float(neutral)
    return float(r + inflation + p["inflation_weight"] * (inflation - target) + p["gap_weight"] * gap)


def policy_path(current: float, target_rate: float, quarters: int | None = None, smoothing: float | None = None) -> list[float]:
    """Implied path by partial adjustment: i_q = rho i_(q-1) + (1 - rho) i*, q = 1..quarters, from the current rate."""
    rho = float(TAYLOR["smoothing"][0] if smoothing is None else smoothing)
    n = int(TAYLOR["quarters"][0] if quarters is None else quarters)
    out, i = [], float(current)
    for _ in range(n):
        i = rho * i + (1 - rho) * float(target_rate)
        out.append(i)
    return out


def rate_changes(daily: pd.Series, as_of) -> dict:
    """Current rate, its date, the changes over 3 and 12 months (pp) and the date of the last change, from a daily
    policy-rate series (date index, values in %), cut to `as_of`."""
    s = pd.to_numeric(daily, errors="coerce").dropna()
    s.index = pd.to_datetime(s.index)
    s = s[s.index <= pd.Timestamp(as_of)].sort_index()
    if s.empty:
        return {}
    last_d, last = s.index[-1], float(s.iloc[-1])

    def at(months):
        x = s[s.index <= last_d - pd.DateOffset(months=months)]
        return float(last - x.iloc[-1]) if len(x) else float("nan")
    chg = s[s.diff().fillna(0) != 0]
    return {"rate": last, "date": str(last_d.date()), "change_3m_pp": at(3), "change_12m_pp": at(12),
            "last_change_date": str(chg.index[-1].date()) if len(chg) else "",
            "stale_days": int((pd.Timestamp(as_of) - last_d).days)}


# ---------------------------------------------------------------- 3. Commodity terms-of-trade channel (stress only)

# Judgement pass-through table for {"target": "tot"} (stress library only). L = terms-of-trade loss in % of GDP.
TOT_COEF = {
    "fx_per_pp": (2.0, "% FX pressure (3-month depreciation) per 1% of GDP ToT loss", "judgement; NGN/COP 2014-15 oil episode"),
    "spread_per_pp": (40.0, "bp per 1% of GDP ToT loss at level beta 1", "judgement; above macro_scenarios s_per_tot_pct (15) because this channel stands alone"),
    "level_ref_bp": (300.0, "bp spread at which the level beta is 1", "as engine.macro_scenarios COEF level_ref_bp"),
    "level_beta_min": (0.25, "floor on the level beta", "as macro_scenarios"),
    "level_beta_max": (2.0, "cap on the level beta", "as macro_scenarios"),
    "max_loss_pp": (10.0, "cap on the ToT loss, % of GDP", "judgement"),
    "max_res_loss_pct": (50.0, "cap on the reserve loss, % of reserves", "judgement"),
}
TOT_PASS_THROUGH = {"Float": 1.0, "Managed": 0.5, "Peg": 0.0}   # share of FX pressure that shows in fx3m (judgement)
TOT_RES_FINANCED = {"Float": 0.25, "Managed": 0.5, "Peg": 0.75}  # share of the ToT loss met from reserves (judgement)
TOT_DEFAULT_WHERE = {"exptype_eq": "Commodity"}                   # net commodity exporters only (one-sided: no gains)
TOT_KEYS = {"target", "commodity", "price_change_pct", "exposure", "where", "note"}


def validate_tot_shock(sh: dict, where: str = "tot shock") -> None:
    """ValueError for a malformed {"target": "tot"} shock."""
    bad = set(sh) - TOT_KEYS
    if bad:
        raise ValueError(f"{where}: unknown keys {sorted(bad)}; allowed {sorted(TOT_KEYS)}")
    v = sh.get("price_change_pct")
    if not isinstance(v, (int, float)) or isinstance(v, bool) or not np.isfinite(v) or v >= 0 or v < -100:
        raise ValueError(f"{where}: price_change_pct must be a number in [-100, 0) (a price fall; the channel is one-sided)")
    if not isinstance(sh.get("exposure", "7.10"), str):
        raise ValueError(f"{where}: exposure must be an indicator id string such as '7.10'")


def tot_channel(countries: pd.DataFrame, exposure_pct: pd.Series, price_change_pct: float, mask: pd.Series | None = None,
                coef: dict | None = None) -> pd.DataFrame:
    """Per-country terms-of-trade loss and its mapping to fx3m, res3m, indicator 2.1 and spread, at scale 1.

    L = min(max_loss, |price change| / 100 * exposure / 100 * exports % GDP)   (countries.csv `exports` is % of GDP)
    fx3m += pass * fx_per_pp * L       (pass by fxregime: Float 1, Managed 0.5, Peg 0)
    d_res = -min(max_res_loss, phi * L / reserves % GDP * 100)   (phi by fxregime: Float 0.25, Managed 0.5, Peg 0.75)
    res3m += d_res;  2.1 *= 1 + d_res / 100
    spread += spread_per_pp * beta * L,  beta = clip(spread / level_ref_bp, min, max)
    Countries outside `mask` (default all) get L = 0. `exposure_pct` is aligned to `countries` (NaN -> 0)."""
    k = {n: v[0] for n, v in (coef or TOT_COEF).items()}
    c = countries.reset_index(drop=True)
    m = pd.Series(True, index=c.index) if mask is None else pd.Series(np.asarray(mask, dtype=bool), index=c.index)
    e = pd.to_numeric(pd.Series(np.asarray(exposure_pct, dtype=object), index=c.index), errors="coerce").fillna(0.0).clip(0, 100)
    x = pd.to_numeric(c["exports"], errors="coerce").fillna(0.0).clip(lower=0)
    loss = (abs(float(price_change_pct)) / 100.0 * e / 100.0 * x).clip(upper=k["max_loss_pp"]).where(m, 0.0)
    pas = c["fxregime"].map(TOT_PASS_THROUGH).fillna(0.5).astype(float)
    pressure = k["fx_per_pp"] * loss
    phi = c["fxregime"].map(TOT_RES_FINANCED).fillna(0.5).astype(float)
    res = pd.to_numeric(c["reserves"], errors="coerce")
    d_res = -(phi * loss / res.where(res > 0) * 100).fillna(0.0).clip(upper=k["max_res_loss_pct"])
    beta = (pd.to_numeric(c["spread"], errors="coerce").fillna(k["level_ref_bp"]) / k["level_ref_bp"]).clip(k["level_beta_min"], k["level_beta_max"])
    return pd.DataFrame({"country": c["country"], "iso": c.get("iso", c["country"]), "in_scope": m,
                         "exposure_pct": e, "exports_pct_gdp": x, "tot_loss_pct_gdp": loss, "pass_through": pas,
                         "d_fx3m": pas * pressure, "d_res3m": d_res,
                         "res_factor_2_1": 1 + d_res / 100,
                         "d_spread_bp": k["spread_per_pp"] * beta * loss})


def tot_shock_list(table: pd.DataFrame, exposure_id: str = "7.10", note: str = "") -> list[dict]:
    """Ordinary stress.py shocks (scale 1) from a `tot_channel` table: one shock per country and channel with a
    non-zero effect, selected by `iso_in`. Severity scaling then applies as for any add / mul shock."""
    out = []
    tag = f"tot via {exposure_id}" + (f": {note}" if note else "")
    for _, r in table.iterrows():
        if not r["in_scope"] or r["tot_loss_pct_gdp"] <= 0:
            continue
        w = {"iso_in": [r["iso"]]}
        if r["d_fx3m"] > 0:
            out.append({"target": "countries", "column": "fx3m", "op": "add", "value": float(r["d_fx3m"]), "where": w, "rule": tag})
        if r["d_res3m"] < 0:
            out.append({"target": "countries", "column": "res3m", "op": "add", "value": float(r["d_res3m"]), "where": w, "rule": tag})
            out.append({"target": "indicators", "id": "2.1", "op": "mul", "value": float(r["res_factor_2_1"]), "where": w, "rule": tag})
        if r["d_spread_bp"] > 0:
            out.append({"target": "countries", "column": "spread", "op": "add", "value": float(r["d_spread_bp"]), "where": w, "rule": tag})
    return out
