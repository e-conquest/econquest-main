"""Sovereign depth rules (EQ-B-0136, PI-13): IMF ARA reserve adequacy, gross financing need by year, external maturity
wall and refinancing risk, and the IMF programme probability research model. Method: docs/validation/indicator-rules.md
section 22. Research views only: nothing here feeds the scorecard, the PDs or the portfolio numbers.

Pure functions (no file, no clock). Layering (ADR-A-001): numpy and pandas only. `validation.depth_views` reads the files
and builds the per-country rows.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

# ---------------------------------------------------------------- 1. IMF ARA (rule 22.1)
# The engine's weights (engine.dsa.ARA_WEIGHTS; a test pins the two equal): (ST debt, other liabilities, broad money,
# exports). IMF (2011, 2013, 2015) "Assessing Reserve Adequacy"; managed regimes take the average of the two sets.
ARA_WEIGHTS = {"fixed": (0.30, 0.20, 0.10, 0.10), "floating": (0.30, 0.15, 0.05, 0.05)}
ARA_COMPONENTS = ("st_debt", "other_liabilities", "broad_money", "exports")
# IMF ARA guidance: 100-150% of the metric is adequate for precautionary purposes. engine.dsa._read uses the same cut-offs.
ARA_BANDS = ((100.0, "below"), (150.0, "adequate"), (np.inf, "ample"))


def ara_weights(regime: str) -> tuple[tuple[float, float, float, float], str]:
    """(weights, name) for an fxregime value of data/countries.csv ("Peg", "Float", anything else = managed)."""
    if regime == "Peg":
        return ARA_WEIGHTS["fixed"], "fixed"
    if regime == "Float":
        return ARA_WEIGHTS["floating"], "floating"
    avg = tuple(0.5 * (a + b) for a, b in zip(ARA_WEIGHTS["fixed"], ARA_WEIGHTS["floating"]))
    return avg, "average of fixed and floating (managed)"


def ara_metric(st_debt: float, other_liabilities: float, broad_money: float, exports: float,
               regime: str) -> dict:
    """The ARA metric in the inputs' unit (US$ bn) and each term's share of it.

    Inputs are levels in one currency unit (broad money and exports already converted from % of GDP)."""
    w, name = ara_weights(str(regime))
    terms = dict(zip(ARA_COMPONENTS, (w[i] * float(x) for i, x in enumerate((st_debt, other_liabilities, broad_money, exports)))))
    total = float(sum(terms.values()))
    shares = {k: (v / total if total > 0 else float("nan")) for k, v in terms.items()}
    return {"metric": total, "weights": name, "terms": terms, "shares": shares}


def ara_band(pct: float | None) -> str:
    """"below" (< 100% of ARA), "adequate" (100-150), "ample" (> 150); "" for a missing value."""
    if pct is None or not np.isfinite(pct):
        return ""
    if pct < ARA_BANDS[0][0]:
        return ARA_BANDS[0][1]
    return ARA_BANDS[1][1] if pct <= ARA_BANDS[1][0] else ARA_BANDS[2][1]


# ---------------------------------------------------------------- scoring convention (indicator-rules common conventions)
SCORE_POINTS = np.array([0.0, 25.0, 50.0, 75.0, 100.0])
# Rulebook thresholds t0..t100 (data/rulebook.csv), read here as display scores only (a test pins them to the file).
THRESHOLDS = {"1.2": (10.0, 25.0, 50.0, 75.0, 100.0),    # FX debt service due in 24 months, % of reserves
              "1.4": (5.0, 10.0, 15.0, 20.0, 25.0),      # gross financing need, % of GDP
              "2.1": (150.0, 125.0, 100.0, 75.0, 50.0)}  # usable reserves, % of ARA (lower is worse)


def interp_score(x: float, thresholds) -> float:
    """Piecewise-linear 0-100 score, as scorecard.scoring.interp_score (a test pins the two equal)."""
    t = np.asarray(thresholds, dtype=float)
    if x is None or not np.isfinite(x) or np.any(np.isnan(t)):
        return float("nan")
    if t[0] <= t[-1]:
        return float(np.interp(x, t, SCORE_POINTS))
    return float(np.interp(x, t[::-1], SCORE_POINTS[::-1]))


# ---------------------------------------------------------------- 2. gross financing need by year (rule 22.2)

def gfn_path(hist: pd.DataFrame, first: int, last: int, maturity_years: float) -> pd.DataFrame:
    """Gross financing need of general government by year, % of GDP, from a debt_history-shaped table (index year;
    columns debt, pb, ob, all % of GDP, WEO definitions GGXWDG_NGDP, GGXONLB_NGDP, GGXCNL_NGDP).

    GFN_t = overall deficit_t + amortisation_t, overall deficit = -ob_t (= primary deficit -pb_t + interest_t) and
    amortisation_t = debt_{t-1} / average maturity (the engine.dsa.dsa_table rule; its gfn_pct_gdp is year0+1 here).
    A year whose overall balance or opening debt is missing gives NaN for the terms it needs."""
    m = float(maturity_years)
    if not np.isfinite(m) or m <= 0:
        raise ValueError(f"average maturity must be a positive number of years, got {maturity_years!r}")
    rows = []
    for y in range(int(first), int(last) + 1):
        ob = float(hist.at[y, "ob"]) if y in hist.index else float("nan")
        pb = float(hist.at[y, "pb"]) if y in hist.index else float("nan")
        d0 = float(hist.at[y - 1, "debt"]) if (y - 1) in hist.index else float("nan")
        amort = d0 / m if np.isfinite(d0) else float("nan")
        overall = -ob if np.isfinite(ob) else float("nan")
        rows.append({"year": y, "primary_deficit": -pb if np.isfinite(pb) else float("nan"),
                     "interest": (pb - ob) if np.isfinite(pb) and np.isfinite(ob) else float("nan"),
                     "overall_deficit": overall, "amortisation": amort,
                     "gfn": overall + amort if np.isfinite(overall) and np.isfinite(amort) else float("nan")})
    return pd.DataFrame(rows, columns=["year", "primary_deficit", "interest", "overall_deficit", "amortisation", "gfn"])


# ---------------------------------------------------------------- 3. maturity wall and refinancing risk (rule 22.3)
# Annual external public (PPG) debt service as % of gross reserves. Judgement bands, set from the 24-month rulebook
# thresholds of 1.2 (10/25/50/75/100 over two years): one year at 12.5 / 25 / 50% of reserves is the 1.2 t25 / t50 / t100
# pace. Level 0 low, 1 moderate, 2 high, 3 very high.
REFI_BANDS = ((12.5, 0, "low"), (25.0, 1, "moderate"), (50.0, 2, "high"), (np.inf, 3, "very high"))


def refinancing_level(pct_reserves: float | None) -> tuple[int | None, str]:
    if pct_reserves is None or not np.isfinite(pct_reserves):
        return None, ""
    for edge, lvl, name in REFI_BANDS:
        if pct_reserves < edge:
            return lvl, name
    return 3, "very high"


def maturity_wall(principal: pd.Series, debt_service: pd.Series, reserves_usd: float, gdp_usd: float) -> pd.DataFrame:
    """One row per projection year: external PPG principal (US$ bn, % GDP, % reserves), debt service % reserves and
    the refinancing level. `principal` / `debt_service`: {year: US$} (IDS DT.AMT.DPPG.CD / DT.TDS.DPPG.CD, one value
    per year); reserves and GDP in US$ (latest point-in-time values, held flat: the ratios are "% of latest")."""
    years = sorted(set(int(y) for y in principal.index) | set(int(y) for y in debt_service.index))
    rows = []
    for y in years:
        p = float(principal.get(y, np.nan)); ds = float(debt_service.get(y, np.nan))
        r_ok = np.isfinite(reserves_usd) and reserves_usd > 0
        g_ok = np.isfinite(gdp_usd) and gdp_usd > 0
        ds_res = ds / reserves_usd * 100 if r_ok and np.isfinite(ds) else float("nan")
        lvl, name = refinancing_level(ds_res)
        rows.append({"year": y, "principal_usd_bn": p / 1e9 if np.isfinite(p) else float("nan"),
                     "principal_pct_gdp": p / gdp_usd * 100 if g_ok and np.isfinite(p) else float("nan"),
                     "principal_pct_reserves": p / reserves_usd * 100 if r_ok and np.isfinite(p) else float("nan"),
                     "debt_service_pct_reserves": ds_res, "refinancing_level": lvl, "refinancing_band": name})
    return pd.DataFrame(rows, columns=["year", "principal_usd_bn", "principal_pct_gdp", "principal_pct_reserves",
                                       "debt_service_pct_reserves", "refinancing_level", "refinancing_band"])


# ---------------------------------------------------------------- 4. IMF programme probability, research model (rule 22.4)
# A scored rule mapped to a probability by a FIXED logistic. Nothing is fitted (there is no programme-episode file in
# the shared data). The components and their direction follow the literature on the determinants of IMF arrangements:
# low reserve cover (reserves in months of imports) and high external debt / debt service raise the chance of a
# programme (Knight and Santaella 1997, J. Dev. Econ. 54; Joyce 1992, Econ. Letters; Bird and Rowlands 2001), past
# default and lost market access do too (Conway 1994, J. Dev. Econ. 45; Reinhart and Rogoff 2009). The cut-offs are
# conventional thresholds, not estimates: 3 months' import cover (IMF rule of thumb), short-term debt above reserves
# (Greenspan-Guidotti), the order of magnitude of the IMF-WB LIC DSF debt-to-exports thresholds, 1,000 bp distress
# spreads and sub-investment-grade ratings. The logistic anchors are a priori judgement: 0 points -> about 3%, half the
# points -> about 38%, all points -> about 92% over 12 months. Citations are for the direction of each effect only.
PROGRAMME_RULE_ID = "imfprog_v1"
PROGRAMME_LOGIT = {"intercept": -3.5, "slope": 0.6, "scale": 10.0}   # logit = a + b * (scale * points / max points)
MIN_PUBLIC_COMPONENTS = 3
# component: cut-offs (ascending) and points - points[i] when value < cuts[i], else the last points value; cuts None for
# a level that is its own points. "public": World Bank / CRAG inputs; the others are the desk profile (internal).
PROGRAMME_COMPONENTS = {
    "reserve_cover_months": {"cuts": (3.0, 6.0), "points": (2, 1, 0), "public": True, "series": "FI.RES.TOTL.MO",
                             "unit": "months of imports (WDI FI.RES.TOTL.MO)"},
    "st_debt_pct_reserves": {"cuts": (50.0, 100.0), "points": (0, 1, 2), "public": True, "series": "DT.DOD.DSTC.IR.ZS",
                             "unit": "% of reserves (WDI DT.DOD.DSTC.IR.ZS)"},
    "ext_debt_service_pct_reserves": {"cuts": (10.0, 25.0, 50.0), "points": (0, 1, 2, 3), "public": True,
                                      "series": "DT.TDS.DPPG.CD", "unit": "% of reserves, first IDS projection year"},
    "ext_debt_pct_exports": {"cuts": (100.0, 200.0), "points": (0, 1, 2), "public": True, "series": "DT.DOD.DECT.EX.ZS",
                             "unit": "% of exports (IDS DT.DOD.DECT.EX.ZS)"},
    "default_record": {"cuts": None, "points": (0, 1, 2, 3), "public": True, "series": "CRAG",
                       "unit": "level 0-3 (3 in default, 2 ended within 5y, 1 within 15y, 0 none in 15y)"},
    "rating_notch": {"cuts": None, "points": (0, 1, 2, 3), "public": False, "series": "rating",
                     "unit": "level 0-3 (0 BBB- or better, 1 BB, 2 B, 3 CCC+ or below)"},
    "spread_bp": {"cuts": (400.0, 700.0, 1000.0), "points": (0, 1, 2, 3), "public": False, "series": "spread",
                  "unit": "bp"},
}


def _cut_points(x: float, cuts, points) -> int:
    for c, p in zip(cuts, points):
        if x < c:
            return int(p)
    return int(points[-1])


def default_record_level(spells: pd.DataFrame, as_of_year: int) -> int:
    """Level 0-3 from one country's crag_v1 episodes (columns start, end_spell): 3 in default in the last complete data
    year (as_of_year - 1) or later, 2 a spell ended within 5 years of it, 1 within 15 years, else 0."""
    last = int(as_of_year) - 1
    if spells is None or spells.empty:
        return 0
    s = spells[spells["start"] <= last]
    if s.empty:
        return 0
    end = int(s["end_spell"].max())
    if end >= last:
        return 3
    if end >= last - 5:
        return 2
    if end >= last - 15:
        return 1
    return 0


_RATING_LEVEL = [("AAA", 0), ("AA", 0), ("A", 0), ("BBB", 0), ("BB", 1), ("B", 2), ("CCC", 3), ("CC", 3), ("C", 3),
                 ("SD", 3), ("RD", 3), ("D", 3)]


def rating_level(rating: str | None) -> int | None:
    """0 investment grade (BBB- or better), 1 BB, 2 B, 3 CCC+ or below / SD / D; None for a blank or unknown text."""
    if rating is None or (isinstance(rating, float) and not np.isfinite(rating)):
        return None
    r = str(rating).strip().upper().rstrip("+-")
    for k, lvl in _RATING_LEVEL:
        if r == k:
            return lvl
    return None


def programme_points(inputs: dict, public_only: bool = True) -> dict:
    """Points per component from `inputs` {component: value or None} (levels for default_record and rating_notch).

    Returns {"points": {component: int}, "missing": [..], "total": int, "max_available": int, "max_full": int}."""
    pts, missing, mx_av, mx_full = {}, [], 0, 0
    for k, spec in PROGRAMME_COMPONENTS.items():
        if public_only and not spec["public"]:
            continue
        mx = int(max(spec["points"]))
        mx_full += mx
        v = inputs.get(k)
        if v is None or (isinstance(v, float) and not np.isfinite(v)):
            missing.append(k)
            continue
        pts[k] = int(min(max(int(v), 0), mx)) if spec["cuts"] is None else _cut_points(float(v), spec["cuts"], spec["points"])
        mx_av += mx
    return {"points": pts, "missing": missing, "total": int(sum(pts.values())), "max_available": mx_av, "max_full": mx_full}


def programme_probability(total: int, max_available: int) -> float:
    """The fixed logistic of PROGRAMME_LOGIT on the points rescaled to 0..scale (missing components drop out of both
    the points and the maximum). NaN when nothing is available."""
    if max_available <= 0:
        return float("nan")
    s = PROGRAMME_LOGIT["scale"] * float(total) / float(max_available)
    return float(1.0 / (1.0 + np.exp(-(PROGRAMME_LOGIT["intercept"] + PROGRAMME_LOGIT["slope"] * s))))


def programme_backtest(scores: pd.DataFrame, episodes: pd.DataFrame, horizon_years: int = 1) -> dict:
    """Score a point-in-time panel of model probabilities against programme starts.

    `scores`: columns iso, year, p (the probability computed with data as of the start of `year`); `episodes`: columns
    iso, start (year a new IMF arrangement was approved). A (iso, year) is a hit when a programme starts in
    year .. year + horizon_years - 1. Country-years already inside a programme are not removed here: the caller passes
    only years at risk. Returns n, positives, base_rate, brier, auc (rank form, ties half) and the hit rate at p >= 0.5."""
    s = scores.dropna(subset=["p"]).copy()
    if s.empty:
        return {"n": 0, "positives": 0, "base_rate": float("nan"), "brier": float("nan"), "auc": float("nan"),
                "hit_rate_at_50": float("nan"), "false_alarm_rate_at_50": float("nan")}
    starts = {(str(i), int(y)) for i, y in zip(episodes["iso"], episodes["start"])}
    s["y"] = [int(any((str(i), int(yr) + k) in starts for k in range(int(horizon_years)))) for i, yr in zip(s["iso"], s["year"])]
    y, p = s["y"].to_numpy(dtype=float), s["p"].to_numpy(dtype=float)
    pos, neg = p[y == 1], p[y == 0]
    if len(pos) and len(neg):
        auc = float(np.mean([(np.sum(q > neg) + 0.5 * np.sum(q == neg)) / len(neg) for q in pos]))
    else:
        auc = float("nan")
    flag = p >= 0.5
    return {"n": int(len(s)), "positives": int(y.sum()), "base_rate": float(y.mean()), "brier": float(np.mean((p - y) ** 2)),
            "auc": auc, "hit_rate_at_50": float(flag[y == 1].mean()) if len(pos) else float("nan"),
            "false_alarm_rate_at_50": float(flag[y == 0].mean()) if len(neg) else float("nan")}
