"""DSA input rules shared by Team A's official feeds and Team B's engine (C15, HO-20261026-A-B-004; Team B,
EQ-B-0134). engine.dsa re-exports the same objects for one release."""
from __future__ import annotations

import numpy as np
import pandas as pd


# EQ-B-0084 / HO-20261024-A-B-012: the IDS series arrives one row per creditor (counterpart area). Keep only the World
# rows when the World Bank frame carries a counterpart column (names and World codes below; Team A's WorldBankFeed fix
# under EQ-A-0062 is to record or filter it); otherwise refuse any year with more than one row rather than guess
# which row is the total (the old "max if >= 60% of sum, else sum" rule could double count or pick one creditor).
COUNTERPART_COLUMNS = ("counterpart", "counterpart_area", "counterpart_code", "counterpart_area_code", "counterpartarea")
WORLD_CODES = {"WLD", "WORLD", "1W", "W00", "W"}


def _counterpart_column(frame: pd.DataFrame) -> str | None:
    cols = {str(c).strip().lower(): c for c in frame.columns}
    for name in COUNTERPART_COLUMNS:
        if name in cols:
            return cols[name]
    return None


def ppg_debt_service_detail(wb: pd.DataFrame | None, iso: str, year0: int) -> tuple[float, str, str]:
    """(two-year total US$, years used "y1-y2", note) for PPG external debt service over the next two complete
    projection years in the World Bank IDS pull (series DT.TDS.DPPG.CD).

    With a counterpart column only the World rows count. Without one, a year with more than one row is per-creditor
    data with no way to tell the total apart: the result is refused (nan, "", reason). Years whose value is under 30%
    of the largest of the next four years are incomplete pulls and are skipped. `note` is "" for a served value."""
    if wb is None:
        return np.nan, "", ""
    x = wb[(wb["iso"] == iso) & (wb["series"] == "DT.TDS.DPPG.CD") & (wb["period"] > year0) & (wb["period"] <= year0 + 4)].dropna(subset=["value"])
    if x.empty:
        return np.nan, "", ""
    cp = _counterpart_column(x)
    if cp is not None:
        x = x[x[cp].astype(str).str.strip().str.upper().isin(WORLD_CODES)]
        if x.empty:
            return np.nan, "", f"refused: DT.TDS.DPPG.CD {iso} has a '{cp}' column but no World rows"
    n = x.groupby("period").size()
    multi = sorted(int(p) for p in n[n > 1].index)
    if multi:
        what = "World row" if cp is not None else "row"
        why = "" if cp is not None else "; no counterpart column, so per-creditor IDS rows and the total cannot be told apart"
        return np.nan, "", (f"refused: DT.TDS.DPPG.CD {iso} has more than one {what} in {len(multi)} year(s), "
                            f"e.g. {multi[0]} ({int(n.loc[multi[0]])} rows){why}")
    agg = x.set_index("period")["value"].astype(float).sort_index()
    ok = agg[agg >= 0.3 * agg.max()]
    if len(ok) < 2:
        return np.nan, "", ""
    use = ok.iloc[:2]
    return float(use.sum()), f"{int(use.index[0])}-{int(use.index[1])}", ""
