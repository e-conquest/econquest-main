"""Market-history date rules (C15, HO-20261026-A-B-004; Team B, EQ-B-0134). validation.record re-exports the same
object for one release."""
from __future__ import annotations

import pandas as pd


def complete_date(px: pd.DataFrame, min_share: float = 0.6) -> pd.Timestamp:
    """Last date on which at least min_share of the series have a price (Google Finance fills the newest day
    gradually, so the very last row is often partial)."""
    share = px.notna().mean(axis=1)
    ok = share[share >= min_share]
    return ok.index.max() if len(ok) else px.index.max()
