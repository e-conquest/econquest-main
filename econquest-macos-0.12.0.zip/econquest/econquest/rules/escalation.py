"""Conflict escalation ladder and a priori transition model (EQ-B-0142, PI-14). Method `esc_ladder_v1`.

Pure rules (numpy and pandas only; the rules-package import rule). Team B internal, not part of contract C15. The
6.9 violence trend ratio and the last complete month come from econquest.rules.research, called by the validation
layer (validation.escalation) and passed in here. Method text: docs/validation/indicator-rules.md section 25; switch-on dossier:
docs/validation/conflict-escalation.md. Nothing here is estimated: every number below is an a priori, documented
choice (Tier 3 research view). A refit would follow the pre-registered split in the dossier, on real data only.

Ladder (one state per country and month, the anchor month = last complete month at as_of):

    state  name               rule (first that holds, top down)                              data it needs
    4      war                UCDP fatalities (armed_conflict + violence_against_civilians)   UCDP
                              in the 12 months to the anchor >= 1000
    3      armed_conflict     the same UCDP fatalities >= 25                                  UCDP
    2      violent_unrest     a GDELT media z >= 2.0 in coercion, armed_conflict or            GDELT categories, or UCDP
                              violence_against_civilians, or UCDP fatalities 1..24
    1      tension            a GDELT media z >= 2.0 in protest or verbal_conflict            GDELT (legacy is enough)
    0      calm               none of the above, on the rungs the data can see

GDELT media z of a category in a month: x = log1p(events per covered day x 30.4375); z = (x - mean) / max(sd, 0.25)
over the up to 24 scored months before it (at least 12). A month with days_covered < 50% of its days is not scored
(a partial GDELT month, HO-20261026-A-B-015 item 3). Sources are never added (item 2): UCDP fatalities are summed
within UCDP only, and each GDELT category is its own z.

Observability: `state_max_observable` is the highest rung the data could have shown (4 with UCDP covering the 12
months; 2 with GDELT category vintages or UCDP; 1 with legacy GDELT only, item 1). The state is a lower bound when the
ladder above it is not observable.

Transitions: a monthly 5 x 5 a priori matrix BASE_P. A country's upward entries are scaled by the hazard multiplier
M = min(M_CAP, exp(BETA_PRESSURE x pressure) x trend) with pressure = max(0, the largest GDELT z at or above the
current rung, capped at Z_CLIP) and trend = sqrt(6.9 violence trend ratio) clipped to TREND_CLIP (1 when UCDP does
not cover the 72-month 6.9 window). Escalation within h months = first passage above the current state in the chain
with the states above it absorbing.
"""
from __future__ import annotations

import numpy as np
import pandas as pd

METHOD = "esc_ladder_v1"
STATES = (0, 1, 2, 3, 4)
STATE_NAMES = {0: "calm", 1: "tension", 2: "violent_unrest", 3: "armed_conflict", 4: "war"}
HORIZONS = (3, 12)
# a priori monthly transition matrix (rows: from, columns: to; each row sums to 1). Judgement, not estimated:
# direct calm-to-armed-conflict entry 0.0015 a month (about 1.8% a year alone; the chain's p_armed_12m from
# calm is 3.4% with the paths through tension and unrest); mean spells: calm 20 months, tension 4, unrest 5,
# armed conflict 14, war 25 (docs/validation/conflict-escalation.md section 3)
_UP = {0: {1: 0.040, 2: 0.008, 3: 0.0015, 4: 0.0002},
       1: {2: 0.050, 3: 0.004, 4: 0.0005},
       2: {3: 0.025, 4: 0.002},
       3: {4: 0.015},
       4: {}}
_DOWN = {0: {}, 1: {0: 0.200}, 2: {1: 0.120, 0: 0.040}, 3: {2: 0.040, 1: 0.010, 0: 0.005}, 4: {3: 0.040}}


def _base_matrix() -> np.ndarray:
    p = np.zeros((5, 5))
    for i in STATES:
        for j, v in {**_UP[i], **_DOWN[i]}.items():
            p[i, j] = v
        p[i, i] = 1.0 - p[i].sum()
    return p


BASE_P = _base_matrix()
THRESHOLDS = {"war_fatalities_12m": 1000.0, "armed_fatalities_12m": 25.0, "z_media": 2.0}
Z_BASE_MONTHS, Z_MIN_BASE, Z_SD_FLOOR, Z_CLIP = 24, 12, 0.25, 4.0
MIN_MONTH_COVERAGE = 0.5
DAYS_PER_MONTH = 30.4375
BETA_PRESSURE = 0.30          # per sd of the pressure z
TREND_CLIP = (0.75, 2.0)
M_CAP = 4.0
MAX_MOVE = 0.98               # a row's moves out of the state never exceed this
GPR_SD_PER_RUNG = 1.0         # display link: one rung up = a one-sd rise of the country's GPR (a priori)
# GDELT categories and the rung they signal; UCDP measures read for the top rungs
MEDIA = {"verbal_conflict": 1, "protest": 1, "coercion": 2, "armed_conflict": 2, "violence_against_civilians": 2}
UCDP_CATEGORIES = ("armed_conflict", "violence_against_civilians")


def media_z(monthly: pd.DataFrame) -> pd.Series:
    """z by month for one GDELT category of one country. `monthly`: rows with period (YYYY-MM-DD month start), value
    and days_covered. Partial months (days_covered < 50% of the month) are dropped before the base is formed; a month
    needs Z_MIN_BASE scored months among the Z_BASE_MONTHS before it. Index: monthly Periods (scored months only)."""
    if monthly is None or not len(monthly):
        return pd.Series(dtype=float)
    m = monthly.copy()
    per = pd.PeriodIndex(pd.to_datetime(m["period"]), freq="M")
    days = pd.to_numeric(m["days_covered"], errors="coerce").to_numpy(dtype=float)
    dim = per.days_in_month.to_numpy(dtype=float)
    days = np.where(np.isfinite(days), days, dim)               # monthly rows without staged days count as full
    keep = days >= MIN_MONTH_COVERAGE * dim
    val = pd.to_numeric(m["value"], errors="coerce").to_numpy(dtype=float)
    x = pd.Series(np.log1p(np.where(keep, val, np.nan) / np.maximum(days, 1.0) * DAYS_PER_MONTH), index=per)
    x = x[keep & np.isfinite(x.to_numpy())].groupby(level=0).last().sort_index()
    if not len(x):
        return pd.Series(dtype=float)
    full = x.reindex(pd.period_range(x.index.min(), x.index.max(), freq="M"))
    base = full.shift(1).rolling(Z_BASE_MONTHS, min_periods=Z_MIN_BASE)
    z = (full - base.mean()) / base.std(ddof=1).clip(lower=Z_SD_FLOOR)
    return z.clip(-Z_CLIP, Z_CLIP)[full.notna()].dropna()


def observable_max(has_ucdp: bool, has_categories: bool, has_media: bool) -> int:
    """The highest rung the data can show: 4 with UCDP covering the 12-month window, 2 with GDELT category vintages
    (coercion, armed_conflict, violence_against_civilians rows), 1 with legacy GDELT only, 0 with nothing scored."""
    return 4 if has_ucdp else (2 if has_categories else (1 if has_media else 0))


def classify(z_at: dict, ucdp_fat12: float | None, observable: int) -> tuple[int | None, str]:
    """(state, basis) for one country and month. z_at: {GDELT category: z} for the scored categories; ucdp_fat12:
    UCDP fatalities (armed_conflict + violence_against_civilians) in the 12 months to the month, None when UCDP does
    not cover them; observable: observable_max(...). None when nothing is scored."""
    zt = THRESHOLDS["z_media"]
    hot = {c: (z is not None and bool(np.isfinite(z)) and z >= zt) for c, z in z_at.items()}
    if ucdp_fat12 is not None:
        if ucdp_fat12 >= THRESHOLDS["war_fatalities_12m"]:
            return 4, f"UCDP fatalities 12m {ucdp_fat12:g} >= {THRESHOLDS['war_fatalities_12m']:g}"
        if ucdp_fat12 >= THRESHOLDS["armed_fatalities_12m"]:
            return 3, f"UCDP fatalities 12m {ucdp_fat12:g} >= {THRESHOLDS['armed_fatalities_12m']:g}"
    r2 = [c for c in ("coercion", "armed_conflict", "violence_against_civilians") if hot.get(c)]
    if r2 or (ucdp_fat12 is not None and ucdp_fat12 > 0):
        why = [f"GDELT {c} z >= {zt:g}" for c in r2] + ([f"UCDP fatalities 12m {ucdp_fat12:g}"] if ucdp_fat12 else [])
        return 2, "; ".join(why)
    r1 = [c for c in ("protest", "verbal_conflict") if hot.get(c)]
    if r1:
        return 1, "; ".join(f"GDELT {c} z >= {zt:g}" for c in r1)
    if not z_at and ucdp_fat12 is None:
        return None, "no scored month"
    return 0, f"calm on the observable ladder (rungs 0..{observable})"


def trend_factor(ratio: float | None, stale: bool = False) -> float:
    """sqrt(6.9 violence trend ratio) clipped to TREND_CLIP; 1 when the ratio is missing (no full 72-month UCDP
    window) or stale. The ratio is rules.research.violence_trend_ratio on UCDP events (armed_conflict +
    violence_against_civilians, within UCDP only)."""
    if ratio is None or stale or not np.isfinite(ratio):
        return 1.0
    return float(min(TREND_CLIP[1], max(TREND_CLIP[0], np.sqrt(float(ratio)))))


def pressure(state: int, z_at: dict) -> float:
    """Largest positive GDELT z among the categories at or above the current rung (0 when none), capped at Z_CLIP."""
    vals = [z for c, z in z_at.items() if MEDIA.get(c, 0) >= max(state, 1) and z is not None and np.isfinite(z)]
    return float(min(Z_CLIP, max([0.0] + vals)))


def hazard_multiplier(press: float, trend: float) -> float:
    return float(min(M_CAP, np.exp(BETA_PRESSURE * press) * trend))


def country_matrix(mult: float, base: np.ndarray | None = None) -> np.ndarray:
    """BASE_P with every upward entry scaled by `mult`; a row whose moves would pass MAX_MOVE has its upward entries
    scaled back to fit. Rows sum to 1."""
    p = (BASE_P if base is None else base).copy()
    for i in STATES:
        up = np.triu(p, 1)[i] * float(mult)
        down = np.tril(p, -1)[i]
        if up.sum() + down.sum() > MAX_MOVE:
            up = up * max(0.0, MAX_MOVE - down.sum()) / up.sum()
        p[i] = up + down
        p[i, i] = 1.0 - p[i].sum()
    return p


def p_reach_above(p: np.ndarray, state: int, horizon: int, target: int | None = None) -> float:
    """P(the chain started at `state` is above it, or at `target` and above, at some month in 1..horizon): first
    passage with the target states absorbing."""
    t = state + 1 if target is None else int(target)
    if t > 4:
        return 0.0
    if state >= t:
        return 1.0
    q = p.copy()
    for j in range(t, 5):
        q[j] = 0.0
        q[j, j] = 1.0
    pw = np.linalg.matrix_power(q, int(horizon))
    return float(pw[state, t:].sum())


def expected_jump(p: np.ndarray, state: int) -> float:
    """Expected rungs gained on a one-month upward move from `state` (0 at the top)."""
    up = np.triu(p, 1)[state]
    if up.sum() <= 0:
        return 0.0
    return float((up * (np.arange(5) - state)).sum() / up.sum())


def brier(p, y) -> float | None:
    p = np.asarray(p, dtype=float); y = np.asarray(y, dtype=float)
    return float(np.mean((p - y) ** 2)) if len(p) else None


def auc(score, label) -> float | None:
    """Mann-Whitney AUC, ties one half; None without both classes."""
    s = np.asarray(score, dtype=float); y = np.asarray(label, dtype=int)
    pos, neg = s[y == 1], s[y == 0]
    if not len(pos) or not len(neg):
        return None
    gt = (pos[:, None] > neg[None, :]).sum() + 0.5 * (pos[:, None] == neg[None, :]).sum()
    return float(gt / (len(pos) * len(neg)))
