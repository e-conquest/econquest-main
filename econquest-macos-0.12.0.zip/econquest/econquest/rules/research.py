"""Research-dataset and WDI indicator rules (ADR-A-001 first wave, contract C15; moved from
econquest.validation.research_effect by EQ-B-0120, code unchanged).

Pure rules that both Team A's pull (econquest.ingestion) and Team B's validation tools apply: point in time
(`point_in_time`, `PUBLISHED_DEFAULT`), the candidate cells (`rule_cells` and its helpers) and 2.11 export
concentration (`export_concentration`, public; formerly `_export_concentration`). Rules in
docs/validation/indicator-rules.md sections 1-5, 7, 13, 15 and 19.

Layering: this package sits on the config level. It imports numpy and pandas only (and may import econquest.config),
never econquest.ingestion, engine, scorecard, validation or presentation (tests/test_rules_package.py).
"""
from __future__ import annotations

import numpy as np
import pandas as pd

LONG_COLUMNS = ["indicator", "iso3", "year", "value", "metric", "kind", "source", "licence", "vintage"]
RULE_IDS = ("2.11", "3.6", "3.7", "4.3", "4.4", "6.7", "6.10", "7.11", "7.12")
EXPORT_GROUPS = ("FUEL", "MMTL", "FOOD", "AGRI", "MANF")
COMMODITY_GROUPS = ("FUEL", "MMTL", "FOOD", "AGRI")
EXPORT_COVERAGE_FLOOR = 75.0       # indicator-rules.md section 15, rule 1
EXPORT_STALE_YEARS = 3             # Team A's gate: hold when the year is more than 3 before the as_of year
AQUEDUCT_40_PUBLISHED = pd.Timestamp("2023-08-31")   # Aqueduct 4.0, August 2023 (exact day UNVERIFIED): month end

# Point in time (indicator-rules.md section 13): a row may be used only once the release holding it is published.
# A `published` column (YYYY-MM-DD), or a YYYY-MM-DD date inside `vintage`, gives that date. Without one, the
# cautious default below (from the data year y) applies.
PUBLISHED_DEFAULT = {
    "3.6": lambda y: pd.Timestamp(y + 1, 3, 31),     # V-Dem: March release with data to the previous year
    "4.3": lambda y: pd.Timestamp(y + 1, 3, 31),
    "3.7": lambda y: pd.Timestamp(y, 12, 31),        # WJP 13.7: 31 Dec of the label's last year; point_in_time reads
                                                     # the edition_last_year row for a two-year label (HO-A-B-018)
    "4.4": lambda y: pd.Timestamp(y, 12, 31),        # coups: year-y events only once year y is over (no month)
    "6.7": lambda y: pd.Timestamp(y, 12, 31),        # GOCI edition y is published in year y
    "7.11": lambda y: pd.Timestamp(y + 1, 12, 31),   # ND-GAIN: lag UNVERIFIED, cautious
    "6.10": lambda y: pd.Timestamp(y + 1, 12, 31),   # EPR: irregular releases, cautious
    "7.12": lambda y: AQUEDUCT_40_PUBLISHED if y <= 2023 else pd.Timestamp.max,   # a newer release needs its date
}
WDI_AVAILABLE = lambda y: pd.Timestamp(y + 1, 6, 30)   # noqa: E731 - WDI annual year y: usable from mid y+1
NO_LEG_RULE = "rule 3.6 v1: no legislature, legislative constraint 0"     # indicator-rules 13.1 (HO-20261025-A-B-012)
BATTLE_DEATH_METRICS = ("fatalities_state_based", "fatalities_non_state")   # section 19.1: UCDP types 1 and 2
STALE_DAYS_61, STALE_DAYS_69 = 183, 92                                         # section 19.1, section 7
FLOOR_69, CAP_69 = 5.0, 10.0                                                    # section 7 (19.2: section 7 wins)
NOT_COMPUTED = {"6.12": "needs the UCDP token and data/panel/neighbours.csv (section 4, 13.5)"}
CELL_COLUMNS = ["id", "iso3", "status", "value", "data_year", "rule", "reason"]


# ---------------------------------------------------------------- helpers

def _published(rows: pd.DataFrame) -> pd.Series:
    """Publication date per row: `published` column, else a YYYY-MM-DD in `vintage`, else NaT."""
    pub = pd.to_datetime(rows["published"], errors="coerce") if "published" in rows else pd.Series(pd.NaT, index=rows.index)
    if "vintage" in rows:
        found = rows["vintage"].astype(str).str.extract(r"(\d{4}-\d{2}-\d{2})")[0]
        pub = pub.fillna(pd.to_datetime(found, errors="coerce"))
    return pub


def point_in_time(rows: pd.DataFrame, as_of: str) -> pd.DataFrame:
    """Only rows whose release is published on or before `as_of` (stated date, else the cautious default)."""
    if rows.empty:
        return rows
    cut = pd.Timestamp(as_of)
    pub = _published(rows)
    years = pd.to_numeric(rows["year"], errors="coerce")
    # 13.7: a WJP edition is usable from 31 December of its label's last year. The adapter's edition_last_year row
    # (same country and data year) gives that year for a two-year label; without it the label is read as single-year.
    ed = rows[(rows["indicator"].astype(str) == "3.7") & (rows["metric"] == "edition_last_year")]
    last = {(c, int(y)): int(v) for c, y, v in zip(ed["iso3"], pd.to_numeric(ed["year"], errors="coerce"),
                                                  pd.to_numeric(ed["value"], errors="coerce")) if pd.notna(y) and pd.notna(v)}

    def default(i, iso, y):
        if i == "3.7" and (iso, int(y)) in last:
            return pd.Timestamp(last[(iso, int(y))], 12, 31)
        return PUBLISHED_DEFAULT[i](int(y)) if i in PUBLISHED_DEFAULT else pd.Timestamp.max
    avail = [p if pd.notna(p) else (default(i, iso, y) if pd.notna(y) else pd.Timestamp.max)
             for p, i, iso, y in zip(pub, rows["indicator"].astype(str), rows["iso3"], years)]
    return rows[pd.Series(avail, index=rows.index) <= cut]


def _series(rows: pd.DataFrame, ind: str, metric: str, iso: str, max_year: int = 9999) -> pd.Series:
    r = rows[(rows["indicator"] == ind) & (rows["metric"] == metric) & (rows["iso3"] == iso)]
    r = r[pd.to_numeric(r["year"], errors="coerce") <= max_year]
    return pd.Series(r["value"].astype(float).to_numpy(), index=r["year"].astype(int).to_numpy()).sort_index()


def _cell(cid, iso, status, value=None, year=None, rule="", reason=""):
    return {"id": cid, "iso3": iso, "status": status, "value": value, "data_year": year, "rule": rule, "reason": reason}


# ---------------------------------------------------------------- rules (indicator-rules.md)

def gini_level(g: float) -> int:
    return 0 if g < 35 else 1 if g < 40 else 2 if g < 47.5 else 3 if g < 55 else 4


def epr_level_interim(excluded: float, discriminated: float | None) -> int:
    """Section 13.4 interim EPR level (no ACD2EPR conflict test). Shares are 0-1 fractions."""
    if discriminated is not None and discriminated >= 0.05:
        return 3
    return 2 if excluded >= 0.10 else 1 if excluded >= 0.01 else 0


def bws_level(score: float) -> int:
    return int(min(4, max(0, np.floor(score))))


def rule_cells(rows: pd.DataFrame, isos: list[str], as_of: str, worldbank: pd.DataFrame | None = None,
               events: pd.DataFrame | None = None) -> pd.DataFrame:
    """Candidate cells for each desk ISO3 and each rule id, at `as_of` (rows filtered by point_in_time). With
    `events` (UCDP monthly rows, events.base.EVENT_COLUMNS) 6.1 and 6.9 cells are added (section 19)."""
    A = pd.Timestamp(as_of).year
    rows = point_in_time(rows, as_of) if len(rows) else pd.DataFrame(columns=LONG_COLUMNS)
    ucdp = _ucdp_monthly(events, as_of) if events is not None else None
    out = []
    for iso in isos:
        out.append(export_concentration(worldbank, iso, as_of))
        out.append(_constraints(rows, iso, A))
        # 3.7 WJP Factor 7 (indicator rows)
        s = _series(rows, "3.7", "factor7_civil_justice", iso)
        if s.empty:
            out.append(_cell("3.7", iso, "blank", reason="no WJP row"))
        else:
            y = int(s.index[-1])
            st = "hold" if y < A - 2 else "value"
            out.append(_cell("3.7", iso, st, float(s.iloc[-1]), y, "13.7", "stale" if st == "hold" else ""))
        out.append(_regime(rows, iso, A))
        out.append(_coups(rows, iso, A))
        for cid, metric, name in (("6.7", "criminal_markets", "GOCI"), ("7.11", "vulnerability", "ND-GAIN")):
            r = rows[(rows["indicator"] == cid) & (rows["iso3"] == iso) & (rows["metric"] == metric)]
            if r.empty:
                out.append(_cell(cid, iso, "blank", reason=f"no {name} row"))
            else:
                r = r.sort_values("year").iloc[-1]
                y = int(r["year"])
                st = "hold" if y < A - 3 else "value"
                out.append(_cell(cid, iso, st, float(r["value"]), y, f"{name} as published",
                                 "stale" if st == "hold" else ""))
        out.append(_inequality(rows, iso, A, worldbank, as_of))
        out.append(_water(rows, iso, A))
        for cid, why in NOT_COMPUTED.items():
            out.append(_cell(cid, iso, "blank", reason=why))
        if ucdp is not None:
            out.append(_armed_conflict(ucdp, iso, as_of))
            out.append(_violence_trend(ucdp, iso, as_of))
    return pd.DataFrame(out, columns=CELL_COLUMNS)


def _constraints(rows, iso, A):
    """3.6: the rulebook mean of v2x_jucon and v2xlg_legcon; 13.1: where V-Dem codes no legislature, the adapter's
    jucon_half_no_legislature row (v2x_jucon / 2) when it is newer than the mean row or there is no mean row. A 13.1
    value is always held (Sam's sign-off at first values); stale when the year < as_of year - 2."""
    s = _series(rows, "3.6", "mean_v2x_jucon_v2xlg_legcon", iso)
    nl = _series(rows, "3.6", "jucon_half_no_legislature", iso)
    if len(nl) and (s.empty or int(nl.index[-1]) > int(s.index[-1])):
        y = int(nl.index[-1])
        why = "13.1 no legislature: sign-off at first values" + ("; stale" if y < A - 2 else "")
        return _cell("3.6", iso, "hold", float(nl.iloc[-1]), y, NO_LEG_RULE, why)
    if s.empty:
        return _cell("3.6", iso, "blank", reason="no V-Dem row (no file, or a part missing)")
    y = int(s.index[-1])
    st = "hold" if y < A - 2 else "value"
    return _cell("3.6", iso, st, float(s.iloc[-1]), y, "rulebook 3.6 mean", "stale" if st == "hold" else "")


def _ucdp_monthly(events: pd.DataFrame, as_of: str) -> pd.DataFrame:
    """UCDP monthly rows known at `as_of`: period <= as_of and, when the column is there, retrieved on or before
    as_of (a later vintage is not used). Several vintages of one (iso, period, metric): the latest retrieved. Returns
    a frame indexed by (iso, period month) with one column per metric."""
    cols = ["iso", "period", "metric", "value"]
    if events is None or not len(events):
        return pd.DataFrame(columns=cols).set_index(["iso", "period"])
    ev = (events[events["source"] == "ucdp"] if "source" in events else events).copy()
    if "freq" in ev:
        ev = ev[ev["freq"] == "M"]
    cut = pd.Timestamp(as_of)
    ev["period"] = pd.to_datetime(ev["period"], errors="coerce").dt.to_period("M")
    ev = ev[ev["period"].dt.end_time.dt.normalize() <= cut]
    if "retrieved_utc" in ev:
        r = pd.to_datetime(ev["retrieved_utc"], utc=True, errors="coerce").dt.tz_convert(None)
        ev = ev[r.isna() | (r < cut + pd.Timedelta(days=1))].assign(_r=r)
        ev = ev.sort_values("_r", kind="stable")
    ev = ev.drop_duplicates(["iso", "period", "metric"], keep="last")
    return ev.pivot_table(index=["iso", "period"], columns="metric", values="value", aggfunc="last")


def _window(ucdp, iso, as_of):
    """(monthly frame for iso, window end month, data-end age in days) or None when the iso has no rows."""
    if ucdp is None or not len(ucdp) or iso not in ucdp.index.get_level_values(0):
        return None
    m = ucdp.xs(iso, level=0).sort_index()
    a = pd.Timestamp(as_of)
    last_complete = a.to_period("M") if a.day == a.days_in_month else a.to_period("M") - 1
    end = min(last_complete, m.index.max())
    age = (pd.Timestamp(as_of) - end.end_time.normalize()).days
    return m, end, age


def _armed_conflict(ucdp, iso, as_of):
    """6.1, section 19.1: battle deaths (UCDP best estimate, state-based plus non-state violence) on the territory in
    the 12 months ending at the window end. 0 none; 1 1-24; 2 25-999; 3 1,000+ written and held for the analyst,
    who confirms 3 (contained) or sets 4 (spreading or territory lost). Every month must be covered."""
    w = _window(ucdp, iso, as_of)
    if w is None:
        return _cell("6.1", iso, "blank", reason="no UCDP rows for the country")
    m, end, age = w
    months = pd.period_range(end - 11, end, freq="M")
    if not set(months) <= set(m.index) or not all(c in m.columns for c in BATTLE_DEATH_METRICS):
        return _cell("6.1", iso, "blank", reason="12-month window not fully covered by UCDP")
    d = float(m.loc[months, list(BATTLE_DEATH_METRICS)].sum().sum())
    lvl = 0 if d <= 0 else 1 if d < 25 else 2 if d < 1000 else 3
    why = [f"{d:,.0f} battle deaths, 12 months to {end}"]
    st = "value"
    if lvl == 3:
        st = "hold"; why.append("1,000+: analyst confirms 3 (contained) or sets 4 (spreading or territory lost)")
    if age > STALE_DAYS_61:
        st = "hold"; why.append(f"stale (data end {age} days before as_of)")
    return _cell("6.1", iso, st, float(lvl), end.year, "section 19.1", "; ".join(why))


def last_complete_month(as_of) -> pd.Period:
    """The as-of month when as_of is its last day, else the month before (C15, HO-20261026-A-B-004)."""
    a = pd.Timestamp(as_of)
    p = a.to_period("M")
    return p if a.day == a.days_in_month else p - 1


def violence_trend_ratio(monthly: pd.Series, as_of) -> tuple[float | None, str, bool]:
    """6.9 by indicator-rules section 7 (section 19.2; C15, HO-20261026-A-B-004). The one implementation for Team B's
    6.9 cell and Team A's events table.

    `monthly`: events per month for one country (index: monthly Periods or dates; NaN means no data for that month).
    Anchor: min(last complete month at as_of, last month with a value), so nothing after as_of is used. N12 = events in
    the 12 months to the anchor; B = events per year over the 60 months before them. B >= 5: N12 / B; B < 5 and
    N12 < 5: 0.8 (no material violence); B < 5 and N12 >= 5: N12 / 5; capped at 10. Window check: every one of the 72
    months must have a value; otherwise (None, basis listing the missing months, False). Returns (value, basis, stale);
    stale means the anchor month ends more than 92 days before as_of (the 6.9 cell is then held)."""
    s = pd.Series(monthly, dtype=float).dropna()
    if not len(s):
        return None, "no months with a value", False
    if not isinstance(s.index, pd.PeriodIndex):
        s.index = pd.PeriodIndex(pd.to_datetime(s.index), freq="M")
    s = s.groupby(level=0).sum()
    anchor = min(last_complete_month(as_of), s.index.max())
    rec = pd.period_range(anchor - 11, anchor, freq="M")
    base = pd.period_range(anchor - 71, anchor - 12, freq="M")
    miss = [p for p in list(base) + list(rec) if p not in s.index]
    if miss:
        return None, (f"insufficient coverage: {len(miss)} of {len(base) + len(rec)} months missing "
                      f"({miss[0]}..{miss[-1]}) for {rec[0]}..{rec[-1]} vs {base[0]}..{base[-1]}"), False
    n12, b = float(s[rec].sum()), float(s[base].sum()) / 5.0
    if b >= FLOOR_69:
        val, case = n12 / b, ""
    elif n12 < FLOOR_69:
        val, case = 0.8, f" (both below {FLOOR_69:g} a year: 0.8, no material violence)"
    else:
        val, case = n12 / FLOOR_69, f" (base below {FLOOR_69:g} a year: N12 / {FLOOR_69:g})"
    capped = val > CAP_69
    val = min(val, CAP_69)
    age = (pd.Timestamp(as_of) - anchor.end_time.normalize()).days
    stale = age > STALE_DAYS_69
    basis = (f"{n12:g} in {rec[0]}..{rec[-1]} vs mean {b:.2f} per year in {base[0]}..{base[-1]}{case}"
             + (f"; capped at {CAP_69:g}" if capped else "")
             + (f"; STALE: data end {age} days before as_of (limit {STALE_DAYS_69}), the cell is held" if stale else "")
             + "; indicator-rules section 7")
    return float(val), basis, stale


def _violence_trend(ucdp, iso, as_of):
    """6.9, section 7 (floor 5 events a year, cap 10; 19.2): violence_trend_ratio on UCDP events (all types).
    Proxy for ACLED."""
    w = _window(ucdp, iso, as_of)
    if w is None:
        return _cell("6.9", iso, "blank", reason="no UCDP rows for the country")
    m = w[0]
    if "events_total" not in m.columns:
        return _cell("6.9", iso, "blank", reason="72-month window not fully covered by UCDP")
    s = m["events_total"].astype(float)
    v, _basis, stale = violence_trend_ratio(s, as_of)
    if v is None:
        return _cell("6.9", iso, "blank", reason="72-month window not fully covered by UCDP")
    end = min(last_complete_month(as_of), s.dropna().index.max())
    ev = s.loc[pd.period_range(end - 71, end, freq="M")]
    n12, b = float(ev.iloc[-12:].sum()), float(ev.iloc[:60].sum()) / 5.0
    why = [f"PROXY (UCDP organised violence): N12 {n12:g}, base {b:g}/year"]
    st = "value"
    if stale:
        age = (pd.Timestamp(as_of) - end.end_time.normalize()).days
        st = "hold"; why.append(f"stale (data end {age} days before as_of)")
    return _cell("6.9", iso, st, float(v), end.year, "section 7 / 19.2", "; ".join(why))


def export_concentration(wb, iso, as_of):
    """2.11, indicator-rules.md section 15: latest year (WDI-published by as_of) with all five groups. Rule 1, the
    coverage floor, runs first (hold, no value); rule 2, manufactures largest: blank; rule 3: commodity max. A year
    more than 3 before the as_of year is held as stale."""
    if wb is None or not len(wb):
        return _cell("2.11", iso, "blank", reason="no World Bank input")
    A = pd.Timestamp(as_of).year
    codes = {f"TX.VAL.{g}.ZS.UN": g for g in EXPORT_GROUPS}
    s = wb[(wb["iso"] == iso) & wb["series"].isin(codes)].dropna(subset=["value"])
    s = s.loc[s["period"].map(lambda y: WDI_AVAILABLE(int(y)) <= pd.Timestamp(as_of)).astype(bool)]
    if s.empty:
        return _cell("2.11", iso, "blank", reason="no export-group year published by as_of")
    w = s.assign(g=s["series"].map(codes)).pivot_table(index="period", columns="g", values="value", aggfunc="last")
    w = w.reindex(columns=list(EXPORT_GROUPS)).dropna()
    if w.empty:
        return _cell("2.11", iso, "blank", reason="no year with all five export groups")
    y = int(w.index.max()); r = w.loc[y]
    total = float(r.sum())
    if total < EXPORT_COVERAGE_FLOOR:
        return _cell("2.11", iso, "hold", None, y, "15 rule 1",
                     f"groups cover {total:.1f}% of exports; gold or unclassified exports not measured")
    if r.idxmax() == "MANF":
        return _cell("2.11", iso, "blank", None, y, "15 rule 2",
                     "manufactures are the largest group; the sector split needs Comtrade HS chapters")
    top = r[list(COMMODITY_GROUPS)]
    v = float(top.max())
    if y < A - EXPORT_STALE_YEARS:
        return _cell("2.11", iso, "hold", v, y, "15 rule 3", f"stale (latest {y})")
    return _cell("2.11", iso, "value", v, y, "15 rule 3", f"largest SITC commodity group {top.idxmax()}")


def _regime(rows, iso, A):
    reg = _series(rows, "4.3", "v2x_regime", iso)
    if reg.empty:
        return _cell("4.3", iso, "blank", reason="no V-Dem row")
    y = int(reg.index[-1]); r = int(reg.iloc[-1])
    if r == 3:
        lvl = 0
    elif r == 0:
        window = reg.loc[y - 4:y]
        lvl = 1 if len(window) == 5 and (window == 0).all() else 2
    else:
        lvl = 2 if r == 1 else 3
    pol = _series(rows, "4.3", "v2cacamps_osp", iso)
    reason, st = [], "value"
    if y in pol.index:
        if pol.loc[y] >= 3.0 and r in (2, 3):
            lvl = 3 if r == 3 else 4
    else:
        st, reason = "hold", ["v2cacamps_osp missing: base level only (13.2)"]
    if y < A - 2:
        st = "hold"; reason.append("stale")
    return _cell("4.3", iso, st, float(lvl), y, "section 1 / 13.2", "; ".join(reason))


def _coups(rows, iso, A):
    att = _series(rows, "4.4", "coup_attempts", iso)
    suc = _series(rows, "4.4", "coup_successes", iso)
    if att.empty:
        return _cell("4.4", iso, "blank", reason="country not in the coups file and no explicit zero rows")
    yrs_att = [int(y) for y, v in att.items() if v > 0]
    yrs_suc = [int(y) for y, v in suc.items() if v > 0]
    if any(y >= A - 5 for y in yrs_suc):
        lvl = 4
    elif any(y >= A - 5 for y in yrs_att):
        lvl = 3
    elif any(y >= A - 20 for y in yrs_att):
        lvl = 2
    elif any(y >= A - 50 for y in yrs_att):
        lvl = 1
    else:
        lvl = 0
    return _cell("4.4", iso, "value", float(lvl), int(att.index[-1]), "13.3 annual fallback",
                 "neighbour coups not checked")


def _inequality(rows, iso, A, wb, as_of):
    g = None
    if wb is not None and len(wb):
        s = wb[(wb["series"] == "SI.POV.GINI") & (wb["iso"] == iso)].dropna(subset=["value"])
        s = s.loc[s["period"].map(lambda y: WDI_AVAILABLE(int(y)) <= pd.Timestamp(as_of)).astype(bool)]
        s = s[s["period"] >= A - 10].sort_values("period")
        if len(s):
            g = (float(s["value"].iloc[-1]), int(s["period"].iloc[-1]))
    exc = _series(rows, "6.10", "excluded_pop_share", iso)
    exc = exc[exc.index >= A - 6]
    dis = _series(rows, "6.10", "discriminated_pop_share", iso)
    if g is None and exc.empty:
        return _cell("6.10", iso, "blank", reason="no Gini within 10 years and no EPR row")
    lv, why, yr = [], [], None
    if g is not None:
        lv.append(gini_level(g[0])); yr = g[1]
    else:
        why.append("Gini missing")
    if not exc.empty:
        e_year = int(exc.index[-1])
        d = float(dis.loc[e_year]) if e_year in dis.index else None
        lv.append(epr_level_interim(float(exc.iloc[-1]), d))
        yr = max(yr or 0, e_year)
        if float(exc.iloc[-1]) > 0.20:
            why.append("excluded share > 0.20: could be 4")
        if d is None:
            why.append("discriminated share not emitted")
    else:
        why.append("EPR missing")
    st = "hold" if (g is None or exc.empty or any("could be 4" in w for w in why)) else "value"
    return _cell("6.10", iso, st, float(max(lv)), yr, "section 3 / 13.4", "; ".join(why))


def _water(rows, iso, A):
    sc = _series(rows, "7.12", "bws_score", iso)
    cat = _series(rows, "7.12", "bws_cat", iso)
    if sc.empty and cat.empty:
        return _cell("7.12", iso, "blank", reason="no Aqueduct row")
    y = int((sc if len(sc) else cat).index[-1])
    c = float(cat.iloc[-1]) if len(cat) else None
    if c == -1:
        return _cell("7.12", iso, "hold", 4.0, y, "section 5 / 13.6", "category -1 (arid, low use): first run held")
    if sc.empty or sc.iloc[-1] < 0:
        return _cell("7.12", iso, "blank", reason="no score (-9999)")
    lvl = bws_level(float(sc.iloc[-1]))
    if c is not None and c != lvl:
        return _cell("7.12", iso, "hold", float(lvl), y, "section 5 / 13.6", f"category {c:g} differs from score band")
    return _cell("7.12", iso, "value", float(lvl), y, "section 5 / 13.6")
