"""Evidence clock view (EQ-C-0068, HO-20261024-B-C-001): formats Team B's calendar-gated evidence monitor
(validation/evidence_monitor.py, read only) for the CLI (`econquest evidence-clock`) and the GUI card
(GET /api/evidence-clock). No model logic here: the monitor computes, this module only resolves the as-of date the
way the other commands do and turns the table into JSON-safe records. Read-only; Tier 3.
"""
from __future__ import annotations
from pathlib import Path
import datetime as dt
import math
import re

import pandas as pd

from ..validation import evidence_monitor as EM

STATUS_TEXT = {"accumulating": "Accumulating", "testable": "Testable", "overdue": "Overdue"}
LABEL = "Calendar-gated validation evidence (Team B evidence monitor, Tier 3): read-only, point in time."


AS_OF_RE = re.compile(r"[0-9]{4}-[0-9]{2}-[0-9]{2}")


def as_of_param(text: str) -> str:
    """The ?as_of= of GET /api/evidence-clock: exactly YYYY-MM-DD (ASCII digits), a real calendar date inside pandas'
    Timestamp range. Raises ValueError otherwise. Stricter than parsing with pd.Timestamp (SEC-C-009): that read
    '0001-01-01' as year 1, which strftime wrote as '1-01-01' and resolve_as_of then took as 2001-01-01, and it
    accepted full-width digits and years the monitor cannot hold (a 200 'invalid' card instead of a 400)."""
    if not isinstance(text, str) or not AS_OF_RE.fullmatch(text):
        raise ValueError("as_of must be YYYY-MM-DD")
    d = dt.date.fromisoformat(text)
    if not (pd.Timestamp.min.year < d.year < pd.Timestamp.max.year):
        raise ValueError("as_of out of range")
    return d.isoformat()


def default_as_of(data_dir, as_of: str | None = None) -> str:
    """--as-of if given, else the settings as_of (data/assumptions.json), else today: the same resolution as `run`
    (engine.pipeline.resolve_as_of). The CLI may read the clock here; the monitor itself never does."""
    from ..engine.pipeline import resolve_as_of
    if as_of:
        return resolve_as_of(as_of)
    settings_as_of = None
    try:
        from ..config import Settings
        settings_as_of = Settings.load(Path(data_dir) / "assumptions.json").get("as_of")
    except (OSError, ValueError, KeyError):
        settings_as_of = None
    return resolve_as_of(settings_as_of)


def _clean(v):
    if v is None:
        return None
    if isinstance(v, float) and math.isnan(v):
        return None
    if hasattr(v, "item"):                       # numpy scalar
        v = v.item()
        if isinstance(v, float) and math.isnan(v):
            return None
    return v


def records(table: pd.DataFrame) -> list[dict]:
    """The monitor table as JSON-safe records (NaN -> None), columns in evidence_monitor.COLUMNS order."""
    return [{c: _clean(r.get(c)) for c in EM.COLUMNS} for r in table.to_dict(orient="records")]


def evidence_clock(data_dir, out_dir, as_of: str | None = None) -> dict:
    """The GUI payload: {as_of, status ("ok" / "invalid"), message, label, statuses, rows}. File names only."""
    a = default_as_of(data_dir, as_of)
    base = {"as_of": a, "label": LABEL, "statuses": list(EM.STATUSES), "status_text": STATUS_TEXT,
            "files": ["forecast_record.csv", "benchmarks.csv", "panel/sovereign_defaults.csv", "idea_log.csv"]}
    try:
        table = EM.evidence_monitor(a, data_dir=data_dir, out_dir=out_dir)
    except Exception as e:                       # noqa: BLE001 - the card shows the error type only, never a path
        return base | {"status": "invalid", "rows": [],
                       "message": f"The evidence monitor could not read its inputs ({type(e).__name__})."}
    rows = records(table)
    counts = {s: sum(1 for r in rows if r["status"] == s) for s in EM.STATUSES}
    msg = f"{len(rows)} calendar-gated tests as of {a}: " + ", ".join(f"{counts[s]} {s}" for s in EM.STATUSES) + "."
    return base | {"status": "ok", "rows": rows, "counts": counts, "message": msg}
