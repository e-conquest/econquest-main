"""GUI side of "Update BoC-BoE defaults" (HO-20261025-A-C-003, EQ-C-0087): Team A's crag_update behind two routes.

    GET  /api/crag-update   {"fetch_available", "fetch_page", "max_bytes", "suffixes"}
    POST /api/crag-update   {"name": "DEBT_2026.csv", "content_b64": "...", "apply": false}            dry run
                            {"name": ..., "content_b64": ..., "apply": true, "dry_run_sha256": "<hex>"}  apply
                            {"fetch": true}   only when crag_update.FETCH_URL_VERIFIED is set (dry run only)

The upload is untrusted. The body is capped before it is read (gui.py), the file name is reduced to a safe basename
with a .csv or .xlsx suffix, the bytes are checked (an xlsx must be a zip, a CSV UTF-8 text without NUL), and the file
is written under <outputs>/crag_uploads/<random>/ and removed after the call: the server never opens a path the
browser sends. crag_update repeats its own checks (size, zip budget, CRC, importer).

Apply is refused unless this server returned a dry run for the same bytes (sha256) while the live CRAG file was
what it is now, so the GUI can never apply a file whose diff it has not shown. The apply also passes that dry run's
live and country-map sha256 to crag_update (expect_*_sha256, "absent" for a missing file), which re-checks them under
its own lock right before the replace (SEC-C-017 R51); status "changed" means run the dry run again. After status "error" (a failed apply
could not restore a live file) apply stays refused until the GUI restarts. One update at a time per GUI. Responses
carry relative names only, never local paths. This is not a GUI job: `crag` is not in gui.ALLOWED_CMDS.
"""
from __future__ import annotations

import base64
import binascii
import hashlib
import re
import secrets
import shutil
import threading
from pathlib import Path

GUI_ZIP_TOTAL_BYTES = 100 * 2**20                 # SEC-C-017 L2: what a 25 MB upload may unpack to in the GUI
GUI_ZIP_MEMBER_BYTES = 60 * 2**20
MAX_UPLOAD_BYTES = 25 * 2**20                     # DEBT_2026.csv is 2.4 MB; crag_update's own cap is 50 MB
MAX_BODY_BYTES = (MAX_UPLOAD_BYTES + 2) // 3 * 4 + 64 * 1024    # base64 plus the JSON around it
SUFFIXES = (".csv", ".xlsx")
UPLOAD_SUBDIR = "crag_uploads"
MAX_DIFF_ROWS = 2000
SHA_RE = re.compile(r"[0-9a-f]{64}")
RETRY_PREFIXES = ("another crag update",)


class Rejected(ValueError):
    """The request is refused before crag_update runs; `code` is the HTTP status."""

    def __init__(self, msg: str, code: int = 400):
        super().__init__(msg)
        self.code = code


def safe_name(name) -> str:
    """The browser's file name reduced to a safe basename with an allowed suffix (only used for the label)."""
    if not isinstance(name, str) or not name.strip() or len(name) > 255:
        raise Rejected("name must be the file's name, at most 255 characters")
    base = re.split(r"[\\/]", name.strip())[-1]
    stem, dot, suf = base.rpartition(".")
    suffix = ("." + suf).lower() if dot else ""
    if suffix not in SUFFIXES:
        raise Rejected("expected a Valet .csv export or a BoC-BoE .xlsx workbook")
    stem = re.sub(r"[^A-Za-z0-9_-]", "_", stem)[:64].strip("_-") or "upload"
    return stem + suffix


def check_content(name: str, data: bytes) -> None:
    if not data:
        raise Rejected("the file is empty")
    if len(data) > MAX_UPLOAD_BYTES:
        raise Rejected(f"the file is {len(data):,} bytes, over the {MAX_UPLOAD_BYTES:,}-byte upload cap", 413)
    if name.endswith(".xlsx"):
        if not data.startswith(b"PK\x03\x04"):
            raise Rejected("not an .xlsx workbook (an .xlsx file is a zip archive)")
        import zipfile
        from ..ingestion.safe_zip import check_zip_file
        try:                                       # SEC-C-017 L2 (EQ-C-0165): a GUI budget under Team A's 500 MB
            check_zip_file(data, max_total=GUI_ZIP_TOTAL_BYTES, max_member=GUI_ZIP_MEMBER_BYTES)
        except zipfile.BadZipFile:
            raise Rejected("not an .xlsx workbook (the zip archive is damaged)") from None
        except ValueError as e:                    # ZipBudgetExceeded: refused before anything decompresses
            raise Rejected(f"the workbook would unpack too large for the GUI ({e}); use the CLI", 413) from None
        return
    if b"\x00" in data:
        raise Rejected("contains NUL bytes: not a CSV text file")
    try:
        data.decode("utf-8-sig")
    except UnicodeDecodeError:
        raise Rejected("not UTF-8 text: not a Valet CSV export") from None


def decode_upload(body: dict) -> tuple[str, bytes]:
    name = safe_name(body.get("name"))
    b64 = body.get("content_b64")
    if not isinstance(b64, str) or not b64:
        raise Rejected("content_b64 must be the file's bytes in base64")
    if len(b64) > MAX_BODY_BYTES:
        raise Rejected("upload over the size cap", 413)
    try:
        data = base64.b64decode(b64, validate=True)
    except (binascii.Error, ValueError):
        raise Rejected("content_b64 is not valid base64") from None
    check_content(name, data)
    return name, data


UPLOAD_DIR_RE = re.compile(r"^[0-9a-f]{16}$")      # the per-call folder name: secrets.token_hex(8)


def sweep_uploads(uploads: Path) -> int:
    """Remove per-call upload folders a killed GUI process left behind; returns how many. Only real folders named like
    secrets.token_hex(8) are removed; a symlinked uploads folder or entry, or any other name, is left alone."""
    n = 0
    try:
        if uploads.is_symlink() or not uploads.is_dir():
            return 0
        for d in uploads.iterdir():
            if UPLOAD_DIR_RE.fullmatch(d.name) and d.is_dir() and not d.is_symlink():
                shutil.rmtree(d, ignore_errors=True)
                n += 1
    except OSError:
        return n
    return n


class CragGUI:
    def __init__(self, data_dir: str | Path, out_dir: str | Path):
        self.data_dir, self.out_dir = Path(data_dir), Path(out_dir)
        self.panel = self.data_dir / "panel"
        self.uploads = self.out_dir / UPLOAD_SUBDIR
        self.lock = threading.Lock()
        self.dry: dict[str, tuple[str | None, str | None]] = {}   # dry-run file sha256 -> (live CRAG, iso map) sha256 it saw
        self.blocked: str | None = None           # message of a status "error": no apply until the GUI restarts
        self.swept = sweep_uploads(self.uploads)  # SEC-C-017 L4 (EQ-C-0165): uploads left by a killed GUI process

    # ------------------------------------------------------------------ helpers
    def _live_sha(self) -> str | None:
        from ..ingestion import crag_update as cu
        from ..ingestion.default_panel import checksum
        live = self.panel / cu.LIVE_NAME
        return checksum(live) if live.is_file() else None

    def _rel(self, text, extra: list[tuple[Path, str]] = ()) -> str:
        """Local paths in a message replaced by relative names (data/..., outputs/..., upload)."""
        s = "" if text is None else str(text)
        roots = [*extra, (self.data_dir, "data"), (self.out_dir, "outputs")]
        pairs = []
        for p, label in roots:
            for form in {str(p.resolve()), *([str(p)] if p.is_absolute() else [])}:   # never a bare relative word
                pairs.append((form, label))
        for form, label in sorted(pairs, key=lambda x: -len(x[0])):
            if len(form) > 1:
                s = s.replace(form, label)
        return s

    def info(self) -> dict:
        from ..ingestion import crag_update as cu
        return {"fetch_available": bool(cu.FETCH_URL_VERIFIED), "fetch_page": cu.FETCH_PAGE,
                "max_bytes": MAX_UPLOAD_BYTES, "suffixes": list(SUFFIXES), "apply_blocked": self.blocked}

    def view(self, res: dict, name: str | None, extra: list[tuple[Path, str]]) -> dict:
        rel = lambda v: self._rel(v, extra) if v else None  # noqa: E731
        msg = rel(res.get("message")) or ""
        rows = res.get("diff_rows") or []
        out = {"status": res.get("status"), "exit_code": res.get("exit_code"), "message": msg,
               "summary_text": rel(res.get("summary_text")) or "", "counts": res.get("counts") or {},
               "diff_rows": rows[:MAX_DIFF_ROWS], "diff_rows_total": len(rows),
               "warnings": [rel(w) for w in res.get("warnings") or []],
               "new_vintage": res.get("new_vintage"), "new_vintage_created": bool(res.get("new_vintage_created")),
               "previous_vintage": res.get("previous_vintage"), "diff_base": rel(res.get("diff_base")),
               "run_folder": rel((res.get("files") or {}).get("run_dir")),
               "input_name": name, "input_sha256": res.get("input_sha256"), "format": res.get("format"),
               "licence_status": (res.get("licence") or {}).get("licence_status"),
               "live_replaced": bool(res.get("live_replaced")), "apply": bool(res.get("apply")), "run_id": res.get("run_id"),
               "memory_list_untouched": bool(res.get("memory_list_untouched", True))}
        out["retry_later"] = out["status"] == "refused" and msg.startswith(RETRY_PREFIXES)
        out["can_apply"] = out["status"] == "dry_run" and bool(name) and self.blocked is None
        out["needs_new_dry_run"] = out["status"] == "changed"     # live file or country map moved after the dry run
        return out

    # ------------------------------------------------------------------ request
    def handle(self, body) -> tuple[int, dict]:
        try:
            if not isinstance(body, dict):
                raise Rejected("body must be a JSON object")
            if not self.lock.acquire(blocking=False):
                raise Rejected("another BoC-BoE update is running in this GUI: wait for it to finish, then retry", 409)
            try:
                return 200, self._run(body)
            finally:
                self.lock.release()
        except Rejected as e:
            return e.code, {"error": str(e)}

    def _run(self, body: dict) -> dict:
        from ..ingestion import crag_update as cu
        apply = body.get("apply") is True
        if body.get("fetch"):
            if not cu.FETCH_URL_VERIFIED:
                raise Rejected("Fetch from Bank of Canada is unavailable: no verified download URL "
                               f"(download the file from {cu.FETCH_PAGE} and upload it)", 409)
            if apply:
                raise Rejected("a fetched file is a dry run only from the GUI: upload the file to apply it")
            res = cu.crag_update(fetch=True, apply=False, panel_dir=self.panel)
            return self.view(res, None, [])
        name, data = decode_upload(body)
        sha = hashlib.sha256(data).hexdigest()
        if apply:
            if self.blocked:
                raise Rejected(f"apply is blocked after an error: {self.blocked}", 409)
            claimed = body.get("dry_run_sha256")
            if not isinstance(claimed, str) or not SHA_RE.fullmatch(claimed) or claimed != sha or sha not in self.dry:
                raise Rejected("run a dry run of this exact file first: Apply sends the file whose diff was shown", 409)
            if self.dry[sha][0] != self._live_sha():
                self.dry.pop(sha, None)
                raise Rejected("the live CRAG file changed since that dry run: run the dry run again", 409)
        self.uploads.mkdir(parents=True, exist_ok=True)
        tmp = self.uploads / secrets.token_hex(8)
        tmp.mkdir()
        try:
            src = tmp / name
            with open(src, "xb") as f:
                f.write(data)
            if apply:                               # SEC-C-017 R51 / HO-20261025-A-C-014: crag_update re-checks both under its lock
                live0, map0 = self.dry[sha]
                res = cu.crag_update(src, apply=True, panel_dir=self.panel,
                                     expect_live_sha256=live0 or cu.ABSENT, expect_iso_map_sha256=map0 or cu.ABSENT)
            else:
                res = cu.crag_update(src, apply=False, panel_dir=self.panel)
        finally:
            shutil.rmtree(tmp, ignore_errors=True)
        extra = [(tmp, "upload")]
        if res.get("status") == "error":
            self.blocked = self._rel(res.get("message"), extra) or "status error"
        if res.get("status") == "dry_run" and res.get("input_sha256") == sha:
            self.dry[sha] = (res.get("live_sha256_before"), res.get("iso_map_sha256"))
        elif apply and res.get("status") in ("applied", "error", "changed"):
            self.dry.pop(sha, None)                 # one apply per dry run; "changed" needs a new dry run
        return self.view(res, name, extra)
