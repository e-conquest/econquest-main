"""Compliance checklist for the editorial flow (EQ-C-0036): what must hold before a research product is published.

Five items, the same for every kind (daily_report, weekly_monitor, country_note, scenario_brief):

1. ``disclaimer``  (automatic) every HTML/Markdown/text file carries report.DISCLAIMER (as since EQ-C-0026).
2. ``sources``     (automatic) every HTML/Markdown/text file names its data sources and the as-of date or data vintage,
   either in a visible Sources section or in the machine-readable stamp (see SOURCES SPEC below).
3. ``conflicts``   (manual) the author declares conflicts of interest: "no conflicts" or a text.
4. ``caveats``     (automatic + manual) when report.input_caveats flags seed, synthetic or placeholder inputs
   (GOV-010, GOV-016, GOV-028, ...), every file shows the Input caveats block with a ``[restriction 6.x]`` marker for
   each restriction in force (automatic), and the reviewer acknowledges each restriction that comes from a seed,
   synthetic or placeholder input (manual; ACK_KEYS below, normally 6.1, 6.2 and 6.3).
5. ``compliance_signoff`` (manual) a compliance approver other than the author (ledger.person_key) signs off once items
   1 to 4 pass. Single-operator mode: the author may self-sign only with an explicit flag and an exception id EXC-nnn
   (as `econquest change approve --self-approved`, EQ-C-0041), recorded in the sign-off row.

The approver configuration is data/compliance.json (EQ-C-0040, SEC-C-004 R1), governed by `econquest change`
(ops/approvals.py: propose, four-eyes approve, apply, drift detection). Sign-off is refused while the file was edited
outside that tool (drift), was deleted after being applied, or, never baselined, differs from the built-in default; and
while the pre-EQ-C-0040 file outputs/editorial/compliance.json still exists with a different content (it is no longer
read; move it with `econquest change`, see legacy_problem). The file is not migrated automatically: copying an
ungoverned file into a governed one would launder an unreviewed edit.

This module holds the pure checks and the approver configuration; editorial.py records the manual items as ledger rows
and refuses publish until ``evaluate`` reports the checklist complete.

SOURCES SPEC (what the generators must write; either form passes, both are recommended):

- Visible section: a heading named "Sources" (also "Data sources", "Sources and vintages"), as ``<h2>Sources</h2>`` in
  HTML or ``## Sources`` in Markdown, followed (before the next heading) by the list of data sources (``<li>`` or ``-``
  items, e.g. "IMF WEO", "World Bank WDI", "BIS", "Yahoo Finance", "seed estimates in data/indicators.csv") and a line
  "As of YYYY-MM-DD" and/or "Vintage YYYY-MM-DD". An "as of" date must equal the run's as-of date (draft meta).
- Stamp: ``<!-- econquest:sources {"as_of": "YYYY-MM-DD", "vintage": "YYYY-MM-DD", "sources": ["IMF WEO", ...]} -->``
  (one JSON object; ``sources`` a non-empty list of names; ``as_of`` or ``vintage`` required; ``as_of`` must equal the
  run's as-of date). Valid in Markdown too (an HTML comment)."""
from __future__ import annotations

import hashlib
import html as _h
import json
import re
from pathlib import Path

from ..ingestion.ledger import clean_person, person_key
from .report import DISCLAIMER, input_caveats

CHECKLIST_VERSION = 1
ITEMS = ("disclaimer", "sources", "conflicts", "caveats", "compliance_signoff")
TEXT_SUFFIXES = (".html", ".htm", ".md", ".txt")
CONFIG_NAME = "compliance.json"
DEFAULT_CONFIG = {"role": "compliance approver", "approvers": [], "allow_self_sign": True}
# input_caveats keys that mean a seed, synthetic or placeholder input: their restrictions need a reviewer acknowledgement
ACK_KEYS = ("seed_inputs", "hand_entered_profile", "feed_missing", "paper_mode", "pm_placeholders", "synthetic_backtest")
NO_CONFLICT_WORDS = ("none", "no", "nil", "n/a", "no conflict", "no conflicts", "no conflicts of interest", "none declared")

_DATE = r"(\d{4}-\d{2}-\d{2})"
_ASOF = re.compile(r"\bas[\s-]+of\b[^0-9\n<]{0,20}" + _DATE, re.I)
_VINTAGE = re.compile(r"\bvintages?\b[^0-9\n<]{0,20}" + _DATE, re.I)
_HTML_HEAD = re.compile(r"<h([1-6])[^>]*>\s*(?:data\s+)?sources(?:\s+and\s+vintages?)?\s*</h\1\s*>", re.I)
_HTML_ANY_HEAD = re.compile(r"<h[1-6][\s>]", re.I)
_MD_HEAD = re.compile(r"^#{1,6}\s+(?:data\s+)?sources(?:\s+and\s+vintages?)?\s*#*\s*$", re.I | re.M)
_MD_ANY_HEAD = re.compile(r"^#{1,6}\s", re.M)
_STAMP = re.compile(r"<!--\s*econquest:sources\s+(\{.*?\})\s*-->", re.S)
_TAG = re.compile(r"<[^>]+>")
_RESTR = re.compile(r"\[restriction\s+(\d+\.\d+)\]", re.I)
_CAV_HTML = re.compile(r"class\s*=\s*['\"][^'\"]*\bcaveats\b", re.I)
_CAV_MD = re.compile(r"^#{1,6}\s+input caveats", re.I | re.M)


class ComplianceError(ValueError):
    """A refused or invalid compliance input (bad config, unknown restriction, wrong person)."""


# ---------------------------------------------------------------- configuration (approver role)
def config_path(data_dir) -> Path:
    """data/compliance.json (EQ-C-0040)."""
    return Path(data_dir) / CONFIG_NAME


def legacy_config_path(outputs_dir) -> Path:
    """Where the config lived before EQ-C-0040 (ungoverned; no longer read)."""
    return Path(outputs_dir) / "editorial" / CONFIG_NAME


def validate_config(data, where="compliance.json") -> dict:
    """{"role", "approvers", "allow_self_sign"} normalised, or ComplianceError (also used by `change propose`)."""
    if not isinstance(data, dict) or set(data) - {"role", "approvers", "allow_self_sign"}:
        raise ComplianceError(f"{where}: expected an object with keys role, approvers, allow_self_sign")
    appr = data.get("approvers", [])
    if not isinstance(appr, list) or not all(isinstance(a, str) and person_key(a) for a in appr):
        raise ComplianceError(f"{where}: approvers must be a list of names")
    self_ok = data.get("allow_self_sign", DEFAULT_CONFIG["allow_self_sign"])
    if not isinstance(self_ok, bool):
        raise ComplianceError(f"{where}: allow_self_sign must be true or false")
    role = str(data.get("role") or DEFAULT_CONFIG["role"]).strip()
    return {"role": role, "approvers": [clean_person(a) for a in appr], "allow_self_sign": self_ok}


def _parse_file(p: Path) -> tuple[dict, bytes]:
    raw = p.read_bytes()
    try:
        data = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise ComplianceError(f"{p}: not valid JSON ({e})") from None
    return validate_config(data, str(p)), raw


def _same(a: dict, b: dict) -> bool:
    return (a["role"], a["allow_self_sign"], sorted(person_key(x) for x in a["approvers"])) == \
        (b["role"], b["allow_self_sign"], sorted(person_key(x) for x in b["approvers"]))


def legacy_problem(data_dir, outputs_dir, current: dict | None) -> str | None:
    """Refusal text while outputs/editorial/compliance.json exists and says something other than the governed config
    (None when absent or equivalent). Never migrates it: that would bypass four-eyes."""
    if outputs_dir is None:
        return None
    old = legacy_config_path(outputs_dir)
    if not old.exists():
        return None
    why = ""
    try:
        legacy, _ = _parse_file(old)
    except ComplianceError as e:
        legacy = None; why = str(e)
    if legacy is not None and current is not None and _same(legacy, current):
        return None
    new = config_path(data_dir)
    how = (f"copy it to {new} and record it with `econquest change baseline compliance.json --actor NAME --reason "
           f"\"moved from outputs/editorial (EQ-C-0040)\"`" if not new.exists() else
           f"propose its content with `econquest change propose compliance.json --replace-file {old} --author NAME "
           f"--reason \"move from outputs/editorial (EQ-C-0040)\"`, approve and apply it")
    return (f"{old} is no longer read (SEC-C-004 R1): the compliance approver config is {new}, changed only through "
            f"`econquest change`. {'It is invalid (' + why + '). ' if legacy is None else 'It differs from ' + new.name + '. '}"
            f"To keep it, {how}; then delete {old}. Compliance sign-off is refused until then")


UNGOVERNED = ("default", "no_baseline")      # config statuses with no data/approvals/ record of compliance.json


def governed_signoff(outputs_dir) -> dict | None:
    """The last compliance sign-off in outputs/editorial/ledger.jsonl made under a governed config (config_status ok: not in
    UNGOVERNED), as {"item_id", "seq", "config_status", "config_change_id"}; None when there is none, or outputs_dir
    is None. Unparseable lines are skipped here (the chain check reports them). Anchors load_config: once a sign-off
    ran under a governed config, deleting data/compliance.json with data/approvals/ must not bring the default back."""
    if outputs_dir is None:
        return None
    lp = Path(outputs_dir) / "editorial" / "ledger.jsonl"
    if not lp.exists():
        return None
    found = None
    with open(lp, encoding="utf-8", errors="replace") as f:
        for line in f:
            try:
                r = json.loads(line)
            except json.JSONDecodeError:
                continue
            so = r.get("compliance_signoff") if isinstance(r, dict) else None
            if isinstance(so, dict) and str(so.get("config_status") or "default") not in UNGOVERNED:
                found = {"item_id": str(r.get("item_id", "")), "seq": r.get("seq"), "config_status": str(so["config_status"]),
                         "config_change_id": str(so.get("config_change_id") or "")}
    return found


def load_config(data_dir, outputs_dir=None) -> dict:
    """The compliance approver configuration from data/compliance.json, else DEFAULT_CONFIG.
    {"role": str, "approvers": [names] (empty = anyone other than the author), "allow_self_sign": bool (default true:
    no compliance approver is named yet, so the single operator may self-sign with the flag and an EXC id)}.
    Refused (ComplianceError) when the approvals log does not verify, when the file drifted from the last
    `econquest change` apply/baseline or was deleted after one, when it was never baselined and is not the default,
    and (outputs_dir given) when the legacy outputs/editorial/compliance.json says something else, or when data/approvals/
    has no record of the file (absent, or present but never baselined) although the editorial ledger has a sign-off under
    a governed config (governed_signoff, EQ-C-0050, SEC-C-007 L1).
    The returned dict carries "source" (path or "default"), "sha256", "status" and "change_id" (last apply), which the
    sign-off row records."""
    from ..ops import approvals as ap
    p = config_path(data_dir)
    st = ap.file_status(data_dir, CONFIG_NAME)
    if not st["chain_ok"]:
        raise ComplianceError("data/approvals/log.jsonl failed verification, so the compliance approver config cannot "
                              "be trusted: " + "; ".join(st["chain_errors"]) + " (econquest change verify)")
    if st["status"] in UNGOVERNED:
        # EQ-C-0050 (SEC-C-005 R1): no silent fall-back to the default. SEC-C-007 L1: also when the file is present with
        # the default content but data/approvals/ has no record of it (status no_baseline), e.g. data/approvals/ deleted
        # and the tightened file overwritten with the default
        prior = governed_signoff(outputs_dir)
        if prior:
            raise ComplianceError(
                (f"{p} is absent and data/approvals/ has no record of it, so the built-in default (anyone may approve, "
                 "self-sign allowed) would apply" if st["status"] == "default" else
                 f"{p} is present but data/approvals/ has no record of it, so it reads as never governed")
                + f", but the editorial ledger has a compliance sign-off made under a governed "
                f"config ({prior['item_id']}, ledger seq {prior['seq']}, config status {prior['config_status']}"
                f"{', change ' + prior['config_change_id'] if prior.get('config_change_id') else ''}): restore "
                f"data/compliance.json and data/approvals/ from the backup")
    if st["status"] == "default":
        cfg = dict(DEFAULT_CONFIG, approvers=[], source="default", sha256=None)
    elif st["status"] == "missing":
        raise ComplianceError(f"{p} was applied through econquest change ({st['last_event']} {st['last_id']}) and is now "
                              "missing; restore it from the backup")
    else:
        data, raw = _parse_file(p)
        if st["status"] == "drift":
            raise ComplianceError(f"{p} was edited outside `econquest change` (sha256 {str(st['current_sha256'])[:12]}..., "
                                  f"approved {str(st['approved_sha256'])[:12]}...): propose the change, or accept it with "
                                  "`econquest change baseline compliance.json` (four-eyes)")
        if st["status"] == "no_baseline" and not _same(data, validate_config(DEFAULT_CONFIG)):
            raise ComplianceError(f"{p} differs from the default but was never recorded by `econquest change`: run "
                                  "`econquest change baseline compliance.json --actor NAME --reason TEXT` first")
        cfg = {**data, "source": str(p), "sha256": hashlib.sha256(raw).hexdigest()}
    cfg.update(status=st["status"], change_id=st["last_id"] if st["status"] == "ok" else "")
    why = legacy_problem(data_dir, outputs_dir, {k: cfg[k] for k in ("role", "approvers", "allow_self_sign")})
    if why:
        raise ComplianceError(why)
    return cfg


def check_signoff(author: str, approver: str, cfg: dict, self_signed: bool, exc_id=None) -> tuple[str, str, str]:
    """(approver as stored, self_signed flag "yes"/"", exc_id) or ComplianceError. Four-eyes on person_key; a configured
    approver list restricts who may sign; self-sign needs self_signed=True, cfg allow_self_sign and an exception id
    EXC-nnn, validated by ops.approvals.check_exc exactly as `change approve --self-approved` (EQ-C-0041)."""
    from ..ops.approvals import ApprovalError, check_exc
    approver, flag = _signer(author, approver, cfg, self_signed)
    try:
        return approver, flag, check_exc(flag, exc_id, "compliance sign-off", kind="compliance self-sign")
    except ApprovalError as e:
        raise ComplianceError(str(e)) from None


def _signer(author: str, approver: str, cfg: dict, self_signed: bool) -> tuple[str, str]:
    approver = clean_person(approver)
    if not person_key(approver):
        raise ComplianceError("compliance sign-off needs the approver's name (--by)")
    if person_key(approver) == person_key(author):
        if not self_signed:
            raise ComplianceError(f"compliance sign-off needs a {cfg['role']} other than the author (four-eyes); pass "
                                  "--self-signed with --exc EXC-nnn for a flagged single-operator self-sign")
        if not cfg.get("allow_self_sign"):
            raise ComplianceError(f"self-sign is disabled ({cfg.get('source')}: allow_self_sign false): a {cfg['role']} "
                                  "other than the author must sign off")
        return clean_person(author), "yes"
    keys = {person_key(a) for a in cfg.get("approvers") or []}
    if keys and person_key(approver) not in keys:
        raise ComplianceError(f"{approver} is not a configured {cfg['role']} ({cfg.get('source')}: "
                              f"{', '.join(cfg['approvers'])})")
    return approver, ""


# ---------------------------------------------------------------- text checks
def _text(path) -> str:
    return Path(path).read_text(encoding="utf-8", errors="replace")


def text_files(files: list[dict]) -> list[dict]:
    return [f for f in files if Path(f["name"]).suffix.lower() in TEXT_SUFFIXES]


def has_disclaimer(text: str) -> bool:
    return DISCLAIMER in text or _h.escape(DISCLAIMER) in text or _h.escape(DISCLAIMER, quote=False) in text


def _section(text: str, is_html: bool) -> str | None:
    """Plain text of the first Sources section (heading to the next heading), or None."""
    head, anyh = (_HTML_HEAD, _HTML_ANY_HEAD) if is_html else (_MD_HEAD, _MD_ANY_HEAD)
    m = head.search(text)
    if not m:
        return None
    rest = text[m.end():]
    n = anyh.search(rest)
    return rest[: n.start()] if n else rest


def _entries(body: str, is_html: bool) -> list[str]:
    if is_html:
        items = [_h.unescape(_TAG.sub(" ", x)).strip() for x in re.findall(r"<li[^>]*>(.*?)</li\s*>", body, re.S | re.I)]
    else:
        items = [ln.strip()[1:].strip() for ln in body.splitlines() if ln.strip()[:1] in ("-", "*", "+")]
    items = [x for x in items if x and not re.fullmatch(r"(?i)\s*(as[\s-]+of|vintages?)\b.*", x)]
    if items:
        return items
    plain = _h.unescape(_TAG.sub(" ", body)) if is_html else body
    plain = _VINTAGE.sub(" ", _ASOF.sub(" ", plain))
    words = [w for w in re.findall(r"[A-Za-z][A-Za-z.&/-]{2,}", plain) if w.lower() not in ("sources", "source", "data")]
    return [" ".join(words)] if words else []


def sources_problems(text: str, name: str, as_of: str | None) -> list[str]:
    """Why one product file fails the sources item (empty = pass). See SOURCES SPEC in the module docstring."""
    want = (as_of or "")[:10] or None
    stamp_issue = None
    m = _STAMP.search(text)
    if m:
        try:
            st = json.loads(m.group(1))
            srcs = st.get("sources") if isinstance(st, dict) else None
            if not isinstance(srcs, list) or not [s for s in srcs if isinstance(s, str) and s.strip()]:
                stamp_issue = "the econquest:sources stamp lists no sources"
            elif not (st.get("as_of") or st.get("vintage")):
                stamp_issue = "the econquest:sources stamp has no as_of or vintage"
            elif want and st.get("as_of") and str(st["as_of"])[:10] != want:
                stamp_issue = f"the econquest:sources stamp says as of {st['as_of']} but the run is as of {want}"
            else:
                return []
        except json.JSONDecodeError:
            stamp_issue = "the econquest:sources stamp is not valid JSON"
    is_html = Path(name).suffix.lower() in (".html", ".htm")
    body = _section(text, is_html)
    if body is None:
        return [f"{name}: {stamp_issue}" if stamp_issue else
                f"{name}: no Sources section (heading 'Sources') and no econquest:sources stamp"]
    plain = _h.unescape(_TAG.sub(" ", body)) if is_html else body
    asof, vint = _ASOF.findall(plain), _VINTAGE.findall(plain)
    out = []
    if not _entries(body, is_html):
        out.append(f"{name}: the Sources section names no data source")
    if not asof and not vint:
        out.append(f"{name}: the Sources section states no as-of date or vintage (\"As of YYYY-MM-DD\" / \"Vintage YYYY-MM-DD\")")
    elif want and asof and want not in asof:
        out.append(f"{name}: the Sources section says as of {', '.join(asof)} but the run is as of {want}")
    return out


def flagged_restrictions(data_dir, run=None) -> dict:
    """{"items": input_caveats items, "shown": sorted restriction codes that must be shown (every item with a
    restriction), "ack": {code: {"keys": [...], "refs": "...", "text": "..."}} for restrictions coming from a seed,
    synthetic or placeholder input (ACK_KEYS)}. Raises ComplianceError when data_dir does not exist (fail loudly: an
    unreadable data folder must not read as "no caveats")."""
    d = Path(data_dir)
    if not d.is_dir():
        raise ComplianceError(f"data folder {d} not found: input caveats cannot be checked (pass --data)")
    cav = input_caveats(d, run)
    items = cav.get("items") or []
    shown = sorted({i["restriction"] for i in items if i.get("restriction")})
    ack: dict[str, dict] = {}
    for i in items:
        if i.get("restriction") and i.get("key") in ACK_KEYS:
            a = ack.setdefault(i["restriction"], {"keys": [], "refs": [], "text": []})
            a["keys"].append(i["key"]); a["refs"] += [r.strip() for r in str(i.get("ref", "")).split(",") if r.strip()]
            a["text"].append(i.get("text", ""))
    ack = {k: {"keys": v["keys"], "refs": ", ".join(dict.fromkeys(v["refs"])), "text": " ".join(v["text"])}
           for k, v in sorted(ack.items())}
    return {"items": [{k: i.get(k) for k in ("key", "restriction", "ref")} for i in items], "shown": shown, "ack": ack}


def normalise_restriction(code) -> str:
    s = str(code or "").strip().lower()
    s = re.sub(r"^(use\s+)?restriction\s*", "", s)
    if not re.fullmatch(r"\d+\.\d+", s):
        raise ComplianceError(f"not a restriction code: {code!r} (expected e.g. 6.1)")
    return s


def automatic_checks(files: list[dict], meta: dict, data_dir, run=None) -> dict:
    """Run items 1, 2 and the automatic half of 4 on the files as they are now. Returns
    {"disclaimer": {...}, "sources": {...}, "caveats": {...}} with "ok" and "problems" each; caveats also carries
    "flags" (flagged_restrictions) or "error"."""
    texts = text_files(files)
    contents = {f["name"]: _text(f["path"]) for f in texts}
    miss = [n for n, t in contents.items() if not has_disclaimer(t)]
    disc = {"ok": bool(texts) and not miss,
            "problems": ([f"report.DISCLAIMER missing from {', '.join(miss)}"] if miss else [])
            + ([] if texts else ["no HTML/Markdown/text file to carry the disclaimer"])}
    sp = [p for n, t in contents.items() for p in sources_problems(t, n, (meta or {}).get("as_of"))]
    src = {"ok": bool(texts) and not sp, "problems": sp or ([] if texts else ["no HTML/Markdown/text file to list sources"])}
    try:
        flags = flagged_restrictions(data_dir, run)
    except ComplianceError as e:
        return {"disclaimer": disc, "sources": src, "caveats": {"ok": False, "error": str(e), "problems": [str(e)]}}
    cp = []
    if flags["items"]:
        for n, t in contents.items():
            block = bool(_CAV_HTML.search(t) or _CAV_MD.search(t))
            if not block:
                cp.append(f"{n}: no Input caveats block although the data files flag {len(flags['items'])} caveat(s)")
                continue
            shown = {x for x in _RESTR.findall(t)}
            lack = [c for c in flags["shown"] if c not in shown]
            if lack:
                cp.append(f"{n}: Input caveats block does not show restriction {', '.join(lack)} (regenerate the product)")
    return {"disclaimer": disc, "sources": src, "caveats": {"ok": not cp, "problems": cp, "flags": flags}}


# ---------------------------------------------------------------- whole checklist
def is_no_conflict(text: str) -> bool:
    return " ".join(str(text or "").casefold().replace(".", " ").split()) in NO_CONFLICT_WORDS


def evaluate(item: dict, auto: dict, for_signoff: bool = False) -> dict:
    """The checklist of one item from its ledger state (item["checklist"]: conflicts, acks, signoff) and `auto`
    (automatic_checks). for_signoff=True evaluates items 1-4 only (what a sign-off needs).
    Returns {"version", "complete", "items": {name: {"ok", "mode", ...}}, "problems": [str]}."""
    cl = item.get("checklist") or {}
    res: dict[str, dict] = {}
    res["disclaimer"] = {"mode": "automatic", **auto["disclaimer"]}
    res["sources"] = {"mode": "automatic", **auto["sources"]}
    conf = cl.get("conflicts")
    res["conflicts"] = ({"mode": "manual", "ok": True, "problems": [], **conf} if conf else
                        {"mode": "manual", "ok": False, "problems": [f"conflicts of interest not declared by the author "
                                                                       f"({item.get('author')}): --conflicts \"no conflicts\" (or the declaration) --by the author"]})
    cav = auto["caveats"]
    acks = cl.get("acknowledged") or {}
    need = sorted((cav.get("flags") or {}).get("ack", {}))
    unacked = [c for c in need if c not in acks]
    cprob = list(cav.get("problems") or [])
    if unacked:
        refs = (cav.get("flags") or {}).get("ack", {})
        cprob.append("reviewer has not acknowledged restriction " + ", ".join(f"{c} ({refs[c]['refs']})" for c in unacked)
                     + ": --acknowledge CODE (repeat per restriction) --by the reviewer")
    res["caveats"] = {"mode": "automatic+manual", "ok": not cprob, "problems": cprob,
                      "flagged": (cav.get("flags") or {}).get("shown", []), "acknowledge_required": need,
                      "acknowledged": {c: acks[c] for c in sorted(acks)}}
    if not for_signoff:
        so = cl.get("signoff")
        if so:
            res["compliance_signoff"] = {"mode": "manual", "ok": True, "problems": [], **so}
        else:
            why = cl.get("signoff_voided")
            res["compliance_signoff"] = {"mode": "manual", "ok": False, "problems": [
                "no compliance sign-off" + (f" (the earlier one was voided by {why})" if why else "")
                + ": --compliance-approve --by a person other than the author, or the author with --self-signed --exc EXC-nnn"]}
    problems = [f"{k}: {p}" for k, v in res.items() for p in v["problems"]]
    return {"version": CHECKLIST_VERSION, "complete": not problems, "items": res, "problems": problems}
