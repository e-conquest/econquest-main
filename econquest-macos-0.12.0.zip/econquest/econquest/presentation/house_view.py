"""House view in the products (HO-20261025-B-C-017, EQ-C-0138): the country note's "House view" block and peer table,
the weekly brief's house-view table and manifest section, and the trade-ideas labels.

Every product SHOWS Team B's house view (<run folder>/house_view.json, schema eq-house-view/1, written by
`python -m econquest.validation.house_view build`; rules in docs/validation/house-view.md). Nothing here derives a
stance, a risk level, a trend or an alignment: each value is the record's own field. The file is used only when its
run_id equals the run the product shows; otherwise the product says the house view is not available.

Formatting only: this module reads the JSON file directly and imports nothing from econquest.validation.
"""
from __future__ import annotations

import json
from pathlib import Path

from .house_style import not_available_plain
from .report import _e, _f, pd_html

FILE = "house_view.json"
SCHEMA = "eq-house-view/1"
NA_SENTENCE = "House view: not available for this run (the house view was not built for it)."


def load(outputs_dir, run_id: str | None) -> dict:
    """{"status": "ok" | "missing" | "invalid" | "other_run", "view": {country: record} | {}, "hv": dict | None,
    "operator": str | None}. Only a file whose run_id is `run_id` is used."""
    p = Path(outputs_dir) / FILE
    if not p.is_file():
        return {"status": "missing", "view": {}, "hv": None, "operator": f"no {FILE} in the run folder."}
    try:
        hv = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"status": "invalid", "view": {}, "hv": None, "operator": f"{FILE} could not be read."}
    if not isinstance(hv, dict) or hv.get("schema") != SCHEMA or not isinstance(hv.get("countries"), list):
        return {"status": "invalid", "view": {}, "hv": None, "operator": f"{FILE} is not schema {SCHEMA}."}
    if run_id is not None and str(hv.get("run_id")) != str(run_id):
        return {"status": "other_run", "view": {}, "hv": None,
                "operator": f"{FILE} is for run {hv.get('run_id')}, not run {run_id}."}
    view = {str(v.get("country")): v for v in hv["countries"] if isinstance(v, dict) and v.get("country")}
    return {"status": "ok", "view": view, "hv": hv, "operator": None}


def not_available_html(hvl: dict) -> str:
    return not_available_plain(NA_SENTENCE, hvl.get("operator"))


def stance(hvl: dict, country: str) -> str | None:
    """The record's stance for `country`, or None (no house view, or the country is not in it)."""
    return (hvl.get("view", {}).get(country) or {}).get("stance")


def note_block_html(hvl: dict, country: str) -> str:
    """The country note's House view section: stance, risk level, trend, the rationale, the warnings and the peer table."""
    v = hvl.get("view", {}).get(country)
    if v is None:
        if hvl.get("status") == "ok":
            return not_available_plain("House view: not available for this country in this run.",
                                       f"{FILE} has no record for {country}.")
        return not_available_html(hvl)
    warn = v.get("warnings") or []
    html = (f"<div class='kpis house-view' data-house-stance='{_e(v.get('stance'))}'>"
            f"<div class='kpi'><div class='v'>{_e(v.get('stance'))}</div><div class='l'>House stance</div></div>"
            f"<div class='kpi'><div class='v'>{_e(v.get('risk_level'))}</div><div class='l'>Risk level</div></div>"
            f"<div class='kpi'><div class='v'>{_e(v.get('trend'))}</div><div class='l'>Trend</div></div></div>"
            f"<p>{_e(v.get('rationale'))}</p>")
    html += ("<p class='note'><b>Warnings:</b> " + "; ".join(_e(w) for w in warn) + ".</p>") if warn else "<p class='note'>No warnings.</p>"
    html += peer_table_html(hvl, country)
    hv = hvl.get("hv") or {}
    html += (f"<p class='note'>The house view is one stance per country for every product, built once for run "
             f"{_e(hv.get('run_id'))}; it is a research label and does not feed any PD, loss or limit.</p>")
    return html


def peer_table_html(hvl: dict, country: str) -> str:
    """The country and its three nearest names by composite (the record's peers), each row from its own record."""
    view = hvl.get("view", {})
    v = view.get(country)
    names = ((v or {}).get("peers") or {}).get("names") or []
    if v is None or not names:
        return "<p class='empty'>No peer comparison in the house view for this country.</p>"
    rows = [(country, v, True)] + [(n, view.get(n) or {}, False) for n in names]
    # EQ-C-0153 (HO-20261026-B-C-010 item 4): a client-safe house view lists the names whose debt / GDP is a withheld
    # placeholder (placeholders.debt_gdp, only with the client-safe marker); their blank cell says why.
    ph = set((((hvl.get("hv") or {}).get("placeholders") or {}).get("debt_gdp") or {}).get("countries") or [])

    def debt(n, r):
        return "withheld: licence" if n in ph and r.get("debt_gdp") is None else _f(r.get("debt_gdp"), 1)
    body = "".join(
        ("<tr class='self'><td><b>" + _e(n) + "</b></td>" if me else "<tr><td>" + _e(n) + "</td>") +
        f"<td class='n'>{pd_html(r.get('pd_default'))}</td><td class='n'>{_f(r.get('composite'), 1)}</td>"
        f"<td class='n'>{_f(r.get('spread_bps'), 0)}</td><td class='n'>{debt(n, r)}</td><td>{_e(r.get('stance') or '')}</td></tr>"
        for n, r, me in rows)
    return ("<h3>Peers: nearest names by composite score</h3><table class='compact peers'><tr><th>Country</th>"
            "<th class='n'>Default PD, 12 months</th><th class='n'>Composite</th><th class='n'>Spread (bp)</th>"
            f"<th class='n'>Debt (% of GDP)</th><th>House stance</th></tr>{body}</table>")


def weekly_rows(hvl: dict, countries: list[str] | None = None) -> list[dict]:
    """Manifest rows (country, stance, risk_level, trend, counter_view_ideas), in the run's country order when given."""
    view = hvl.get("view", {})
    order = [c for c in (countries or list(view)) if c in view]
    return [{"country": c, "stance": view[c].get("stance"), "risk_level": view[c].get("risk_level"), "trend": view[c].get("trend"),
             "counter_view_ideas": list(view[c].get("counter_view_ideas") or [])} for c in order]


def weekly_table_html(hvl: dict, rows: list[dict], tr) -> str:
    """The weekly brief's house-view table; `tr(cells)` stamps each row."""
    if hvl.get("status") != "ok":
        return not_available_html(hvl)
    if not rows:
        return "<p class='empty'>The house view has no country of this run.</p>"
    body = "".join(tr(f"<td>{_e(r['country'])}</td><td>{_e(r['stance'])}</td><td>{_e(r['risk_level'])}</td><td>{_e(r['trend'])}</td>"
                      f"<td>{_e(', '.join(r['counter_view_ideas']) or 'none')}</td>") for r in rows)
    counts = (hvl.get("hv") or {}).get("counts") or {}
    head = ("<p class='note'>One stance per country, shown as built by the house view for this run "
            + "; ".join(f"{_e(k)} {_e(n)}" for k, n in counts.items()) + ". Counter-view ideas run against the house stance "
            "or, under a Neutral stance, both ways.</p>") if counts else ""
    return (head + "<table><tr><th>Country</th><th>House stance</th><th>Risk level</th><th>Trend</th><th>Counter-view ideas</th></tr>"
            f"{body}</table>")


def idea_fields(hvl: dict, country: str, trade: str) -> dict:
    """{"house_stance", "alignment"} for one activation, from the record's `ideas` (None when there is no house view)."""
    v = hvl.get("view", {}).get(country)
    if v is None:
        return {"house_stance": None, "alignment": None}
    i = next((x for x in v.get("ideas") or [] if x.get("trade") == trade), None)
    return {"house_stance": v.get("stance"), "alignment": (i or {}).get("alignment")}


def alignment_label(house_stance: str | None, alignment: str | None) -> str:
    """The visible label of an activation: "Counter-view to house stance X", "Two-way", "Aligned", "Neutral" or ""."""
    if alignment == "counter-view":
        return f"Counter-view to house stance {house_stance}"
    if alignment == "two-way":
        return "Two-way"
    return {"aligned": "Aligned", "neutral": "Neutral"}.get(alignment or "", "")
