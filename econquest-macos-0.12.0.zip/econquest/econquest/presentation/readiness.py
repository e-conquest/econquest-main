"""Desk readiness (EQ-C-0081): the target-state scorecard (presentation.targets.target_scorecard, reused, not forked)
with, for every row that is not met, what it needs in plain English. There are four kinds of need:

  mac_pull      a pull that only Sam's Mac can run: the mac-pull step and its state from the pull pack (EQ-C-0073)
  sam_decision  a decision only Sam can take: which one, and where it is written up or how to record it
  calendar      calendar time: the earliest test date from the evidence clock (Team B's evidence monitor, EQ-C-0068)
  team_work     work a team still has to do: the ticket and its board (team/board/<team>.csv, summary and status)

NEEDS is the one table that maps target ids to needs. It is Team C's (econquest/presentation/*), and
tests/test_readiness.py checks that every target id the scorecard emits has an entry. Read-only: nothing here writes.

    econquest targets --explain [--json]      GET /api/readiness (GUI "Readiness" tab)      open-items kind "readiness"

The payload also carries "calendar_tests": the status of the scheduled calendar-gated formal tests (ops/calendar_jobs.py,
job calendar_tests, EQ-C-0095: "not due, N days left", due, overdue, ran for review, passed, failed), and each calendar
need names its test's job status.

"client_decision" (EQ-C-0105): Sam's client-mode decision (2026-10-25 11:29Z: later, at PI-9 with licensed data) and the
status of its no-regret items (R44, the client-safe rule gap, licence verification), from ops/client_decision.status.

"calendar_rehearsal" (EQ-C-0147): Team B's calendar rehearsal file, read only (presentation/rehearsal_view.rehearsal_page),
labelled "SYNTHETIC REHEARSAL, not a test result". A GET never runs the rehearsal; `econquest calendar-rehearsal` does.
"""
from __future__ import annotations

import csv
import datetime as dt
from pathlib import Path

from . import targets as T

KINDS = ("mac_pull", "sam_decision", "calendar", "team_work")
KIND_TEXT = {"mac_pull": "Mac pull", "sam_decision": "Sam decision", "calendar": "Calendar time", "team_work": "Team work"}

# target id -> needs, in the order they unblock the target. Fields: mac_pull {step}; sam_decision {decision, how};
# calendar {evidence (an evidence-monitor row)}; sam_decision "command" is runnable, "how" is prose; team_work {ticket}.
NEEDS: dict[str, list[dict]] = {
    "COV-1": [{"kind": "mac_pull", "step": "universe"},
              {"kind": "team_work", "ticket": "EQ-A-0061"},
              {"kind": "sam_decision", "decision": "promote the staged 88-country universe into data/ after the landing check",
               "how": "data/universe_proposal.md; Team A applies it on your word"}],
    "COV-2": [{"kind": "mac_pull", "step": "universe"}, {"kind": "mac_pull", "step": "fx"},
              {"kind": "team_work", "ticket": "EQ-A-0062"}],
    "DAT-1": [{"kind": "mac_pull", "step": "fx"}, {"kind": "team_work", "ticket": "EQ-A-0050"},
              {"kind": "team_work", "ticket": "EQ-A-0062"}],
    "DAT-2": [{"kind": "sam_decision", "decision": "attest the hand-entered cells (adjustments, prediction markets)",
               "command": "econquest attest --all-files --dry-run",
               "how": "check the dry run, then the same with --author NAME --self-approved --confirm"},
              {"kind": "mac_pull", "step": "fx"}, {"kind": "team_work", "ticket": "EQ-A-0062"}],
    "DAT-3": [{"kind": "team_work", "ticket": "EQ-A-0065"}],
    "DAT-4": [{"kind": "sam_decision", "decision": "choose the spread source: a licensed vendor export, or the free official "
               "spread history", "how": "docs/runbooks/A-market-data.md (econquest market import)"},
              {"kind": "team_work", "ticket": "EQ-A-0063"}],
    "DAT-5": [{"kind": "sam_decision", "decision": "buy a market-data vendor licence (Bloomberg or LSEG), or stay without one",
               "command": "econquest vendor status", "how": "docs/runbooks/A-licensed-vendors.md section 2"}],
    "MOD-1": [{"kind": "mac_pull", "step": "panel_history"}, {"kind": "mac_pull", "step": "crag"},
              {"kind": "team_work", "ticket": "EQ-B-0079"}],
    "MOD-2": [{"kind": "mac_pull", "step": "panel_history"}, {"kind": "mac_pull", "step": "crag"},
              {"kind": "team_work", "ticket": "EQ-B-0079"},
              {"kind": "sam_decision", "decision": "approve the hazard refit as a Tier 1 change once it passes the gate",
               "command": "econquest change list", "how": "fit-hazard --apply proposes it; approve it with econquest change approve"}],
    "MOD-3": [{"kind": "team_work", "ticket": "EQ-B-0058"}],
    "TRK-1": [{"kind": "calendar", "evidence": "var_record_250d"}],
    "TRK-2": [{"kind": "calendar", "evidence": "idea_quarters_4q"}],
    "RES-1": [{"kind": "team_work", "ticket": "EQ-C-0075"},
              {"kind": "sam_decision", "decision": "sign off the first publication as compliance approver (needs a dedicated "
               "compliance EXC id)", "command": "econquest exc next", "how": "draft the row with econquest exc draft, then the editorial sign-off"}],
    "CTL-1": [{"kind": "mac_pull", "step": "fx"}, {"kind": "team_work", "ticket": "EQ-C-0076"}],
    "CTL-2": [{"kind": "team_work", "ticket": "EQ-B-0083"},
              {"kind": "sam_decision", "decision": "engage the independent validator",
               "how": "the validator engagement pack (EQ-B-0060); hand over the econquest evidence bundle"}],
    "CTL-3": [{"kind": "team_work", "ticket": "EQ-C-0086"}],
}


def _root(data_dir) -> Path:
    return Path(data_dir).resolve().parent


def board_tickets(root: Path) -> dict:
    """ticket -> {"board", "summary", "status"} from team/board/{A,B,C}.csv; {} when the boards are not shipped."""
    out = {}
    for team in ("A", "B", "C"):
        p = Path(root) / "team" / "board" / f"{team}.csv"
        if not p.is_file():
            continue
        with open(p, newline="", encoding="utf-8") as f:
            for r in csv.DictReader(f):
                k = (r.get("key") or "").strip()
                if k:
                    out[k] = {"board": f"team/board/{team}.csv", "summary": " ".join((r.get("summary") or "").split()),
                              "status": (r.get("status") or "").strip()}
    return out


def _pack_state(data_dir):
    try:
        from ..ingestion import pullpack
        return pullpack.status(data_dir)
    except Exception:                                    # noqa: BLE001 - shown as "state unknown"
        return None


def _clock(data_dir, out_dir, as_of):
    try:
        from .evidence_view import evidence_clock
        c = evidence_clock(data_dir, out_dir, as_of)
        return {r["evidence"]: r for r in c.get("rows") or []}, c.get("as_of")
    except Exception:                                    # noqa: BLE001
        return {}, as_of


def _calendar_tests(data_dir, out_dir, as_of) -> dict:
    try:
        from ..ops.calendar_jobs import page_status
        return page_status(data_dir, out_dir, as_of)
    except Exception as e:                               # noqa: BLE001 - shown as unknown
        return {"status": "unknown", "rows": [], "message": f"Calendar tests could not be read ({type(e).__name__})."}


def _interim_backtest(data_dir, out_dir, as_of) -> dict:
    """EQ-C-0118: Team B's INTERIM backtest report (ops/interim_backtest.page), never the formal test. Read only."""
    try:
        from ..ops.interim_backtest import page
        return page(data_dir, out_dir, as_of)
    except Exception as e:                               # noqa: BLE001 - shown as unknown
        return {"kind": "INTERIM", "status": "unknown", "verdicts": [],
                "message": f"INTERIM backtest report could not be read ({type(e).__name__})."}


def _client_decision(data_dir, out_dir, root) -> dict:
    """EQ-C-0105: Sam's client-mode decision (later, PI-9, 2026-10-25 11:29Z) and its no-regret items (ops/client_decision)."""
    try:
        from ..ops.client_decision import status
        return status(data_dir, out_dir, root=root)
    except Exception as e:                               # noqa: BLE001 - shown as unknown
        return {"decision": {}, "no_regret": [], "summary": f"Client-mode decision could not be read ({type(e).__name__})."}


def _mvp(out_dir, root) -> dict:
    """EQ-C-0124: the latest `econquest demo` result per MVP row (ops/mvp_tracker.mvp_status). Read only."""
    try:
        from ..ops.mvp_tracker import mvp_status
        return mvp_status(out_dir, root=root)
    except Exception as e:                               # noqa: BLE001 - shown as unknown
        return {"status": "unknown", "rows": [], "message": f"MVP status could not be read ({type(e).__name__})."}


def _calendar_rehearsal(out_dir) -> dict:
    """EQ-C-0147: the SYNTHETIC calendar rehearsal file (presentation/rehearsal_view). Reads the file; never runs it."""
    from .rehearsal_view import LABEL, rehearsal_page
    try:
        return rehearsal_page(out_dir)
    except Exception as e:                               # noqa: BLE001 - shown as unknown
        return {"kind": "REHEARSAL", "label": LABEL, "status": "unreadable", "job_sequence": [], "findings": [],
                "problems": [], "message": f"{LABEL}. The rehearsal file could not be read ({type(e).__name__})."}


def explain_need(need: dict, ctx: dict) -> dict:
    """One need as {"kind", "kind_text", "text", "command", "ref"}: plain English, the command (or ''), and the id it
    points at (step, decision, evidence or ticket)."""
    k = need["kind"]
    if k == "mac_pull":
        step = need["step"]
        rec = ((ctx["pack"] or {}).get("steps") or {}).get(step) or {}
        state = rec.get("status") or ("state unknown" if ctx["pack"] is None else "pending")
        title = rec.get("title") or step
        why = f" ({rec['reason']})" if rec.get("reason") and state != "done" else ""
        return {"kind": k, "kind_text": KIND_TEXT[k], "ref": step,
                "text": f"Mac pull: step {step}, {title}; pull pack says {state}{why}.",
                "command": f"econquest mac-pull run --steps {step}"}
    if k == "sam_decision":
        return {"kind": k, "kind_text": KIND_TEXT[k], "ref": need["decision"],
                "text": f"Sam decision: {need['decision']}" + (f" ({need['how']})" if need.get("how") else "") + ".",
                "command": need.get("command", "")}
    if k == "calendar":
        r = ctx["clock"].get(need["evidence"]) or {}
        if r:
            days = r.get("days_to_test")
            text = (f"Calendar time: {need['evidence']} has {r.get('progress')} of {r.get('required')} {r.get('unit')}; "
                    f"earliest test date {r.get('earliest_test_date')}"
                    + (f" ({days} days from {ctx['as_of']})" if days is not None else "") + f", {r.get('status')}.")
        else:
            text = f"Calendar time: {need['evidence']} (the evidence clock could not be read)."
        job = next((j for j in (ctx.get("cal_tests") or {}).get("rows") or [] if j.get("evidence") == need["evidence"]), None)
        if job:
            text += f" Scheduled job calendar_tests ({job['test']}): {job['text']}."
        return {"kind": k, "kind_text": KIND_TEXT[k], "ref": need["evidence"], "text": text,
                "command": "econquest evidence-clock" + (f" --as-of {ctx['as_of']}" if ctx["as_of"] else "")}
    t = need["ticket"]
    b = ctx["board"].get(t)
    text = (f"Team work: {t} on {b['board']} ({b['status'] or 'no status'}): {b['summary'][:200]}." if b
            else f"Team work: {t} (board not shipped with this install).")
    return {"kind": k, "kind_text": KIND_TEXT[k], "ref": t, "text": text, "command": ""}


def readiness(data_dir, out_dir, as_of: str | None = None, tests_file=None, root=None) -> dict:
    """The page payload: {"as_of", "counts" {met: n}, "rows": [scorecard row + needs], "not_met"}. Paths are the
    scorecard's repo-relative evidence names; nothing absolute."""
    df = T.target_scorecard(data_dir, out_dir, root=root, tests_file=tests_file)
    clock, a = _clock(data_dir, out_dir, as_of)
    cal = _calendar_tests(data_dir, out_dir, a)
    ctx = {"pack": _pack_state(data_dir), "clock": clock, "as_of": a, "cal_tests": cal,
           "board": board_tickets(Path(root) if root is not None else _root(data_dir))}
    rows = []
    for r in df.to_dict("records"):
        needs = [] if r["met"] == "yes" else [explain_need(n, ctx) for n in NEEDS.get(r["id"], [])]
        if r["met"] != "yes" and not needs:
            needs = [{"kind": "team_work", "kind_text": KIND_TEXT["team_work"], "ref": "", "command": "",
                      "text": f"No need recorded for {r['id']} in presentation/readiness.py NEEDS."}]
        rows.append({k: ("" if r[k] is None else str(r[k])) for k in T.COLUMNS} | {"needs": needs})
    counts = {m: sum(1 for r in rows if r["met"] == m) for m in T.MET}
    return {"as_of": a or dt.date.today().isoformat(), "counts": counts, "rows": rows,
            "not_met": sum(1 for r in rows if r["met"] != "yes"), "calendar_tests": cal,
            "interim_backtest": _interim_backtest(data_dir, out_dir, a),
            "client_decision": _client_decision(data_dir, out_dir, root),
            "mvp": _mvp(out_dir, root),
            "calendar_rehearsal": _calendar_rehearsal(out_dir),
            "message": f"{len(rows)} targets: " + ", ".join(f"{counts[m]} {m}" for m in T.MET) + "."}


def explain_text(rep: dict) -> str:
    L = [f"Desk readiness as of {rep['as_of']}: {rep['message']}", ""]
    for r in rep["rows"]:
        L.append(f"[{r['met']}] {r['id']} {r['target']}")
        L.append(f"    now: {r['current']}")
        for n in r["needs"]:
            L.append(f"    needs: {n['text']}" + (f"  ->  {n['command']}" if n["command"] else ""))
    cd = rep.get("client_decision") or {}
    if cd:
        from ..ops.client_decision import lines
        L += ["", "Client mode (Sam's decision, EQ-C-0104/EQ-C-0105):"] + (["    " + x for x in lines(cd)] if cd.get("decision") else [f"    {cd.get('summary', '')}"])
    cal = rep.get("calendar_tests") or {}
    if cal:
        L += ["", f"Calendar-gated formal tests (scheduled job calendar_tests): {cal.get('message', '')}"]
        for r in cal.get("rows") or []:
            L.append(f"    [{r['status_text']}] {r['test']} (formal from {r['formal_date']}): {r['text']}")
    ib = rep.get("interim_backtest") or {}
    if ib:
        L += ["", f"INTERIM backtest (not the formal test, EQ-C-0118): {ib.get('message', '')}"]
        for v in ib.get("verdicts") or []:
            L.append(f"    [INTERIM] {v['test']} (formal from {v['formal_date']}): {v['reading']}")
        ma = ib.get("monthly_alert") or {}
        if ma.get("month"):
            L.append(f"    monthly interim alert {ma['month']} raised {ma.get('raised_at')}")
        if ib.get("explainer"):                          # EQ-C-0166: Team B's backtest explainer section (C18)
            from .backtest_explainer_view import page_lines
            L += ["    " + x for x in page_lines(ib["explainer"])]
    cr = rep.get("calendar_rehearsal") or {}
    if cr:
        from .rehearsal_view import rehearsal_text
        L += [""] + rehearsal_text(cr).rstrip("\n").split("\n")
    return "\n".join(L) + "\n"
