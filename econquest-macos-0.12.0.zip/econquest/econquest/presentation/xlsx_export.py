"""Local workbook export (EQ-C-0122, MVP row M6): the Risk Desk workbook as an .xlsx file, without Google.

The file is the Sheets publish plan rendered cell for cell: `sheets_publish.full_plan` (the same function behind
`econquest publish --dry-run`) gives the tabs, A1 ranges and values, and this module writes each block at its range.
There is no second layout. Three tabs are added after the plan's tabs, never inside them: "Book Limits" (the run
against data/limits.json), "Licences" (attribution and internal-only labels, as the publish plan's .licences.json
sidecar) and "Export Info" (run id, as-of date, classification).

Licences follow publish: publish_guard refuses the export before anything is written (vendor market data without a
redistribution licence), the internal-only labels of `write_plan_licences` go into the Licences tab and a sidecar, and a
cell the plan withholds (blank) is blank here too. The workbook is INTERNAL to the desk, like the Google workbook.

`check` reads the file back and compares every plan cell (numbers to 1e-9 relative, text and blanks exactly), flags
values the plan does not have, and compares the headline figures (VaR99, ES99, EL, L-VaR99, the per-country PDs and
the book limits) with outputs/run_latest.json. openpyxl is already a pinned dependency (requirements-lock.txt), so no
new wheel is needed; it reads through defusedxml. Output is byte-deterministic for a given run (fixed zip and
document timestamps from the run's as-of date).

Python API (EQ-C-0121 `econquest demo`):
    export(out_dir="outputs", data_dir="data", dest=None, *, result=None, universe=None, settings=None,
           garch=True, econ=True, mc_rows=2000, check=True) -> dict
    check(path, out_dir="outputs", data_dir="data", reference=None) -> dict
Both return {"ok", "path", "mismatches", "checked", "problems"}; export adds "run_id", "as_of", "licences". Neither
raises for a refusal or a missing input: ok is False and the reason is in problems.
"""
from __future__ import annotations

import dataclasses
import io
import json
import math
import os
import re
import zipfile
from pathlib import Path

from ..common_format import escape_formula, sanitize_plan
from .sheets_publish import LAYOUT_VERSION, col_letter, full_plan, parse_a1, save_plan

TICKET = "EQ-C-0122"
LIMITS_TAB, LICENCES_TAB, INFO_TAB = "Book Limits", "Licences", "Export Info"
EXTRA_TABS = (LIMITS_TAB, LICENCES_TAB, INFO_TAB)
CLASSIFICATION = ("INTERNAL - Risk Desk only. Same content as the internal Google workbook; do not send outside the "
                  "desk while the Licences tab lists internal-only content.")
LIMITS_HEADER = ["Measure", "Label", "Run value $mm", "Limit $mm", "Warning level $mm", "Utilisation", "Status"]
REL_TOL = 1e-9
ZIP_DATE = (1980, 1, 1, 0, 0, 0)

# Headline cells of the publish plan (sheets_publish.build_plan) and the run_latest.json value each must equal.
PORTFOLIO_CELLS = (("'Portfolio VaR'!E37", "gross_notional_mm"), ("'Portfolio VaR'!E38", "net_notional_mm"),
                   ("'Portfolio VaR'!E40", "expected_loss_mm"), ("'Portfolio VaR'!E41", "var95_mm"),
                   ("'Portfolio VaR'!E42", "var99_mm"), ("'Portfolio VaR'!E43", "es95_mm"),
                   ("'Portfolio VaR'!E44", "es99_mm"), ("'Portfolio VaR'!E46", "paths"),
                   ("'Portfolio VaR'!I37", "liquidity_cost99_mm"), ("'Portfolio VaR'!I38", "lvar99_mm"),
                   ("'Portfolio VaR'!I39", "les99_mm"), ("'Portfolio VaR'!E47", "es975_frtb_mm"))
# Risk Engine rows (build_plan re_rows, rows 5-37, country columns from E) holding a probability of default
RISK_ENGINE_PD_ROWS = ((12, "pd_model_l1"), (14, "pd_market"), (18, "pd_final"), (19, "pd_default"), (25, "pd_tc"),
                       (26, "pd_ex"), (27, "pd_pv"), (28, "pd_sa"), (29, "pd_any"), (33, "pd_model"),
                       (35, "pd_hazard_l1"), (36, "pd_rating"))
COUNTRY_COL0 = 5                                         # column E


def _result(ok, path=None, mismatches=(), checked=0, problems=(), **kw) -> dict:
    return {"ok": bool(ok), "path": str(path) if path else None, "mismatches": list(mismatches), "checked": int(checked),
            "problems": list(problems), **kw}


def _is_num(x) -> bool:
    return isinstance(x, (int, float)) and not isinstance(x, bool)


def _close(a, b) -> bool:
    return abs(float(a) - float(b)) <= REL_TOL * max(1.0, abs(float(b)))


def _unescape(x):
    """Plan text escaped for Sheets ("'=..."): the text itself, written as a string cell with quotePrefix."""
    if isinstance(x, str) and x.startswith("'") and escape_formula(x[1:]) == x:
        return x[1:], True
    return x, False


def _quote(tab: str) -> str:
    return f"'{tab}'"


def _reference(out_dir, reference) -> tuple[dict | None, str | None]:
    if isinstance(reference, dict):
        return reference, None
    p = Path(reference) if reference else Path(out_dir) / "run_latest.json"
    if not p.is_file():
        return None, f"no reference run {p}: run `econquest run` first"
    try:
        return json.loads(p.read_text(encoding="utf-8")), None
    except (OSError, ValueError) as e:
        return None, f"reference run {p} unreadable: {e}"


def default_path(out_dir, as_of) -> Path:
    return Path(out_dir) / "workbook" / f"econquest-{as_of or 'run'}.xlsx"


def sidecar(path, kind: str) -> Path:
    p = Path(path)
    return p.with_name(p.stem + f".{kind}.json")


# ---------------------------------------------------------------- extra tabs
def limits_rows(metrics: dict, data_dir) -> list[list]:
    from .mc_band import book_limit_verdicts, load_book_limits
    rows = [LIMITS_HEADER]
    for r in book_limit_verdicts(metrics, load_book_limits(data_dir)):
        util = r["utilisation"] if math.isfinite(r["utilisation"]) else "inf"
        rows.append([r["measure"], r["label"], float(r["value"]), float(r["limit"]), float(r["warning_mm"]), util, r["status"]])
    if len(rows) == 1:
        rows.append(["", "No book limits: data/limits.json is missing or unreadable", "", "", "", "", ""])
    return rows


def licence_rows(data_dir) -> tuple[list[list], dict]:
    from . import licences as LIC
    ev = LIC.safe_evaluate(data_dir)
    rows = [["Sources and licences"], [CLASSIFICATION], [""], ["Attribution"]]
    rows += [[a] for a in ev.get("attribution") or []] or [["No licensed source recorded for this product's inputs."]]
    labels = LIC.internal_labels(ev)
    rows += [[""], ["Internal-only content (not for client output)"]] + ([[x] for x in labels] or [["None"]])
    return rows, ev


def info_rows(result, reference_id: str | None, plan_tabs: list[str]) -> list[list]:
    s = result.settings or {}
    return [["EconQuest workbook export", ""], ["Classification", CLASSIFICATION], ["Run id", result.run_id],
            ["Run label", result.label], ["As of", s.get("as_of", "")], ["Reference run (run_latest.json)", reference_id or ""],
            ["Layout version", LAYOUT_VERSION], ["Layout", "Sheets publish plan (sheets_publish.full_plan): same tabs, ranges and values as `econquest publish --dry-run`"],
            ["Plan tabs", ", ".join(plan_tabs)], ["Built by", f"econquest export xlsx ({TICKET}); values only, no formulas"]]


# ---------------------------------------------------------------- write
def _tabs(plan) -> list[str]:
    seen = []
    for b in plan:
        t = parse_a1(b["range"])[0]
        if t not in seen:
            seen.append(t)
    return seen


def render(plan: list[dict], extra: dict[str, list[list]], as_of: str | None) -> bytes:
    """xlsx bytes: every plan block at its A1 range (blank plan cells stay empty), then the extra tabs at A1."""
    from datetime import datetime
    from openpyxl import Workbook
    plan = sanitize_plan(plan)
    tabs = _tabs(plan)
    clash = [t for t in tabs if t in extra]
    if clash:
        raise ValueError(f"plan uses the export's own tab name(s): {clash}")
    wb = Workbook(); wb.remove(wb.active)
    sheets = {t: wb.create_sheet(t) for t in tabs}
    for b in plan:
        tab, r1, c1, _, _ = parse_a1(b["range"])
        ws = sheets[tab]
        for i, row in enumerate(b["values"]):
            for j, v in enumerate(row):
                _put(ws, r1 + i, c1 + j, v)
    for t, rows in extra.items():
        ws = wb.create_sheet(t)
        for i, row in enumerate(rows):
            for j, v in enumerate(row):
                _put(ws, 1 + i, 1 + j, escape_formula(v))
    stamp = datetime.strptime(as_of, "%Y-%m-%d") if as_of and re.fullmatch(r"\d{4}-\d{2}-\d{2}", str(as_of)) else datetime(2000, 1, 1)
    p = wb.properties
    p.creator = p.lastModifiedBy = "econquest"; p.title = "EconQuest Risk Desk workbook"; p.category = "INTERNAL"
    p.created = p.modified = stamp
    buf = io.BytesIO(); wb.save(buf)
    return _deterministic(buf.getvalue(), stamp.strftime("%Y-%m-%dT%H:%M:%SZ"))


def _put(ws, r, c, v):
    if v == "" or v is None:
        return
    v, quoted = _unescape(v)
    cell = ws.cell(row=r, column=c)
    cell.value = v
    if isinstance(v, str):
        cell.data_type = "s"                             # never a formula, whatever the text starts with
        if quoted:
            cell.quotePrefix = True


def _deterministic(data: bytes, stamp: str) -> bytes:
    """Same run, same bytes: fixed zip entry times and fixed document times (openpyxl stamps the save time)."""
    src = zipfile.ZipFile(io.BytesIO(data))
    out = io.BytesIO()
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as dst:
        for info in src.infolist():
            body = src.read(info.filename)
            if info.filename == "docProps/core.xml":
                body = re.sub(rb"(<dcterms:(?:created|modified)[^>]*>)[^<]*(</dcterms:)", rb"\g<1>" + stamp.encode() + rb"\g<2>", body)
            zi = zipfile.ZipInfo(info.filename, date_time=ZIP_DATE)
            zi.compress_type = zipfile.ZIP_DEFLATED; zi.external_attr = 0o644 << 16
            dst.writestr(zi, body)
    return out.getvalue()


def _write_atomic(path: Path, data: bytes | str):
    path.parent.mkdir(parents=True, exist_ok=True)
    tmp = path.with_name(path.name + ".tmp")
    (tmp.write_bytes if isinstance(data, bytes) else tmp.write_text)(data)
    os.replace(tmp, path)


def _load_run(data_dir, as_of):
    from ..config import Settings
    from ..engine import run_pipeline
    from ..ingestion import load_universe
    s = Settings.load(Path(data_dir) / "assumptions.json")
    u = load_universe(str(data_dir))
    return run_pipeline(u, s, label="export", as_of=as_of, market_dir=str(data_dir)), u, s


def restricted_problem(data_dir) -> str | None:
    """The xlsx is a file that can leave the desk, so it is treated like `publish --write` by the restricted-source gate
    (SEC-A-006 M1, EQ-A-0040): applied Yahoo / non-commercial cells refuse the export, with no override, and a check
    that cannot run fails closed. None when the export may go ahead."""
    try:
        from ..ingestion.audit import restricted_source_cells
        cells = restricted_source_cells(data_dir)
    except Exception as e:                               # noqa: BLE001 - cannot tell: fail closed, as a workbook write
        return f"export refused: cannot check {data_dir} for restricted-source cells ({type(e).__name__}: {e})"
    if cells is None or cells.empty:
        return None
    keys = ", ".join(sorted({f"{t} {k}" for t, k in zip(cells["table"], cells["key"])}))[:300]
    return (f"export refused: {len(cells)} applied cell(s) hold values from a restricted source ({keys}); the xlsx can "
            "leave the desk, so it follows `publish --write` and has no override. Replace those cells first.")


def _same_numbers(result, ref: dict | None) -> bool:
    if not ref:
        return False
    m = (ref.get("summary") or {}).get("metrics") or {}
    keys = [k for _, k in PORTFOLIO_CELLS]
    return all(k in m and _is_num(m[k]) and _close(result.metrics[k], m[k]) for k in keys)


def export(out_dir="outputs", data_dir="data", dest=None, *, result=None, universe=None, settings=None, garch: bool = True,
           econ: bool = True, mc_rows: int = 2000, check: bool = True, reference=None) -> dict:
    """Write the workbook xlsx (and <name>.plan.json, <name>.plan.licences.json beside it). Without `result` the
    pipeline runs on data_dir pinned to run_latest.json's as-of date. Returns the check result when check=True."""
    ref, ref_problem = _reference(out_dir, reference)
    why = restricted_problem(data_dir)
    if why:
        return _result(False, problems=[why])
    if result is None or universe is None or settings is None:
        as_of = ((ref or {}).get("summary") or {}).get("as_of")
        try:
            result, universe, settings = _load_run(data_dir, as_of)
        except (OSError, ValueError, KeyError) as e:
            return _result(False, problems=[f"run failed: {e}"])
    from ..engine.layer2_bayesian import publish_guard
    from ..ops.vendor_rehearse import refuse_simulated
    try:
        publish_guard(result.country)                    # as publish: before anything is written
        refuse_simulated(result.country, "xlsx export")  # EQ-C-0146: a SIMULATED value never reaches the workbook
    except ValueError as e:
        return _result(False, problems=[f"export refused: {e}"], run_id=result.run_id)
    if _same_numbers(result, ref) and result.run_id != ref["summary"]["run_id"]:
        # a rerun that reproduces the reference run is that run: name it, so the file is the same on any day
        result = dataclasses.replace(result, run_id=ref["summary"]["run_id"])
    as_of = (result.settings or {}).get("as_of")
    plan = full_plan(result, universe, settings, data_dir, out_dir, mc_rows=mc_rows, garch=garch, econ=econ, stamp=as_of)
    path = Path(dest) if dest else default_path(out_dir, as_of)
    lic_rows, _ = licence_rows(data_dir)
    extra = {LIMITS_TAB: limits_rows(result.metrics, data_dir), LICENCES_TAB: lic_rows,
             INFO_TAB: info_rows(result, (ref or {}).get("summary", {}).get("run_id"), _tabs(plan))}
    _write_atomic(path, render(plan, extra, as_of))
    plan_path = sidecar(path, "plan")
    save_plan(plan, plan_path)
    from .licences import write_plan_licences
    lic = write_plan_licences(data_dir, plan_path)
    info = {"run_id": result.run_id, "as_of": as_of, "licences": lic}
    if not check:
        return _result(True, path, problems=[ref_problem] if ref_problem else [], **info)
    return {**check_file(path, out_dir, data_dir, reference=ref if ref is not None else reference), **info}


# ---------------------------------------------------------------- check
def _read(path) -> dict[str, dict[tuple[int, int], object]]:
    from openpyxl import load_workbook
    wb = load_workbook(path, read_only=True, data_only=False)
    out = {}
    for ws in wb.worksheets:
        cells = {}
        for r, row in enumerate(ws.iter_rows(min_row=1, min_col=1, values_only=True), start=1):
            for c, v in enumerate(row, start=1):
                if v is not None and v != "":
                    cells[(r, c)] = v
        out[ws.title] = cells
    wb.close()
    return out


def _cmp(where, exp, got, mismatches):
    if _is_num(exp):
        ok = _is_num(got) and _close(got, exp)
    elif isinstance(exp, bool):
        ok = isinstance(got, bool) and got == exp
    else:
        ok = got == exp
    if not ok:
        mismatches.append(f"{where}: expected {exp!r}, found {got!r}")


def check(path, out_dir="outputs", data_dir="data", reference=None) -> dict:
    """Read the xlsx back; compare every plan cell, then the headline figures with the reference run
    (default <out_dir>/run_latest.json) and the book limits with data/limits.json. ok only with 0 mismatches."""
    path = Path(path)
    if not path.is_file():
        return _result(False, path, problems=[f"no workbook {path}"])
    try:
        plan = json.loads(sidecar(path, "plan").read_text(encoding="utf-8"))
        book = _read(path)
    except (OSError, ValueError, KeyError, zipfile.BadZipFile) as e:
        return _result(False, path, problems=[f"cannot read {path} or its plan: {e}"])
    mismatches, problems, n = [], [], 0
    expected: dict[str, dict] = {}
    for b in plan:
        tab, r1, c1, _, _ = parse_a1(b["range"])
        e = expected.setdefault(tab, {})
        for i, row in enumerate(b["values"]):
            for j, v in enumerate(row):
                e[(r1 + i, c1 + j)] = _unescape(v)[0]
    for tab, cells in expected.items():
        got = book.get(tab)
        if got is None:
            mismatches.append(f"tab {tab!r} missing"); continue
        for (r, c), v in cells.items():
            where = f"{_quote(tab)}!{col_letter(c)}{r}"
            if v == "":
                if (r, c) in got:
                    mismatches.append(f"{where}: plan leaves it blank, found {got[(r, c)]!r}")
                continue
            n += 1
            _cmp(where, v, got.get((r, c)), mismatches)
        for (r, c), v in got.items():
            if (r, c) not in cells:
                mismatches.append(f"{_quote(tab)}!{col_letter(c)}{r}: not in the publish plan, found {v!r}")
    extra_tabs = [t for t in book if t not in expected and t not in EXTRA_TABS]
    mismatches += [f"tab {t!r} is not in the publish plan" for t in extra_tabs]

    ref, why = _reference(out_dir, reference)
    if ref is None:
        problems.append(why)
    else:
        n += _check_run(book, ref, mismatches, problems)
    n += _check_limits(book, ref, data_dir, mismatches)
    ok = not mismatches and not problems
    return _result(ok, path, mismatches, n, problems)


def _cell(book, a1):
    tab, r, c, _, _ = parse_a1(a1)
    return book.get(tab, {}).get((r, c))


def _check_run(book, ref, mismatches, problems) -> int:
    m = (ref.get("summary") or {}).get("metrics") or {}
    n = 0
    for a1, key in PORTFOLIO_CELLS:
        if key not in m:
            problems.append(f"reference run has no {key}"); continue
        n += 1; _cmp(f"{a1} ({key} vs run_latest.json)", m[key], _cell(book, a1), mismatches)
    for i, rec in enumerate(ref.get("country") or []):
        col = col_letter(COUNTRY_COL0 + i)
        for row, key in RISK_ENGINE_PD_ROWS:
            v = rec.get(key)
            if not _is_num(v) or (isinstance(v, float) and not math.isfinite(v)):
                continue
            n += 1; _cmp(f"'Risk Engine'!{col}{row} ({rec.get('country')} {key} vs run_latest.json)", v,
                         _cell(book, f"'Risk Engine'!{col}{row}"), mismatches)
    return n


def _check_limits(book, ref, data_dir, mismatches) -> int:
    from .mc_band import load_book_limits
    lim = (load_book_limits(data_dir) or {}).get("book") or {}
    m = ((ref or {}).get("summary") or {}).get("metrics") or {}
    rows = book.get(LIMITS_TAB)
    if rows is None:
        mismatches.append(f"tab {LIMITS_TAB!r} missing"); return 0
    n, seen = 0, set()
    r = 2
    while (r, 1) in rows:
        key = rows[(r, 1)]; seen.add(key)
        if key in lim:
            n += 1; _cmp(f"{_quote(LIMITS_TAB)}!D{r} ({key} limit vs limits.json)", float(lim[key]), rows.get((r, 4)), mismatches)
        if key in m:
            n += 1; _cmp(f"{_quote(LIMITS_TAB)}!C{r} ({key} vs run_latest.json)", m[key], rows.get((r, 3)), mismatches)
        r += 1
    for key in lim:
        if key not in seen and key in {"var99_mm", "es99_mm", "lvar99_mm", "expected_loss_mm"}:
            mismatches.append(f"{LIMITS_TAB}: book limit {key} missing")
    return n


check_file = check
