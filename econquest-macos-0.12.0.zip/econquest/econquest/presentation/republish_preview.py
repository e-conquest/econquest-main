"""Republish preview (EQ-C-0027): before `econquest publish --write`, show what the new publish plan would change in the
workbook. Offline: the "live" side is a saved Sheets values:batchGet response that Sam fetches on the Mac (see
batchget_urls), or a previous saved plan (outputs/*plan*.json from an earlier `publish` without --write).

    from econquest.presentation.republish_preview import preview
    s = preview("outputs/publish_plan.json", "live_values.json", "outputs/preview", tolerance=1e-6)
    # -> {"kind": "publish_preview", "paths": [html, cells csv, ranges csv], "totals": {...}, "ranges": [...], "run_id", ...}

Cells are compared one by one (plan blocks and baseline ranges are expanded to sheet/row/column), so the baseline
may be fetched with other range shapes than the plan's. Numbers match when |new - old| <= tolerance * max(1, |old|, |new|);
a change is "large" when the relative change is at least `large` (default 25%), the sign flips, or a non-empty
cell is cleared. Formatted baseline strings ("1,234.5", "12%", "$3.0") are read as numbers; fetch with
valueRenderOption=UNFORMATTED_VALUE to avoid display rounding. Nothing here touches the network or a token.
"""
from __future__ import annotations
import csv
import datetime as dt
import hashlib
import json
import math
import re
import urllib.parse
from pathlib import Path

from ..common_format import escape_formula
from .country_note import NOTE_CSS
from .sheets_publish import col_letter, col_number
from .report import DISCLAIMER, _e

SHEETS_API = "https://sheets.googleapis.com/v4/spreadsheets"
A1_RE = re.compile(r"^\$?([A-Za-z]{0,3})\$?(\d*)$")
NOTE_RUN_RE = re.compile(r"run ([0-9]{8}T[0-9]{6}[-\w]*)")
NOTE_DATE_RE = re.compile(r"on (\d{4}-\d{2}-\d{2})")
MAX_CELL_ROWS_HTML = 400


# ---------------------------------------------------------------- A1 ranges
def _col_num(s: str) -> int:
    """Column letters -> number, via the shared sheets_publish.col_number (EQ-C-0033)."""
    return col_number(s.upper())


def col_letters(n: int) -> str:
    """Column number -> letters (A..Z, AA..ZZZ), via the shared sheets_publish.col_letter (EQ-C-0033)."""
    return col_letter(n)


def parse_range(a1: str) -> tuple[str, int, int, int | None, int | None]:
    """'Sheet Name'!E5:V11 -> (sheet, row0, col0, row1, col1); 1-based, inclusive; None = open-ended (A:A, 5:5)."""
    a1 = str(a1).strip()
    if "!" in a1:
        sheet, cells = a1.rsplit("!", 1)
    else:
        sheet, cells = a1, ""
    sheet = sheet.strip()
    if len(sheet) >= 2 and sheet[0] == sheet[-1] == "'":
        sheet = sheet[1:-1].replace("''", "'")
    if not cells:
        return sheet, 1, 1, None, None
    parts = cells.split(":")
    m0 = A1_RE.match(parts[0]); m1 = A1_RE.match(parts[-1])
    if not m0 or not m1:
        raise ValueError(f"not an A1 range: {a1!r}")
    c0 = _col_num(m0.group(1)) if m0.group(1) else 1
    r0 = int(m0.group(2)) if m0.group(2) else 1
    c1 = _col_num(m1.group(1)) if m1.group(1) else None
    r1 = int(m1.group(2)) if m1.group(2) else None
    if len(parts) == 1:
        c1, r1 = c0, r0
    return sheet, r0, c0, r1, c1


def cell_a1(sheet: str, r: int, c: int) -> str:
    return f"{col_letters(c)}{r}"


def _quote_sheet(sheet: str) -> str:
    return sheet if re.fullmatch(r"[A-Za-z0-9_]+", sheet) else "'" + sheet.replace("'", "''") + "'"


# ---------------------------------------------------------------- loading
def _blocks_of(obj) -> tuple[list[dict], str]:
    """Normalise a plan / baseline JSON into [{"range", "values"}] and name its kind."""
    if isinstance(obj, list):
        return [b for b in obj if isinstance(b, dict) and "range" in b], "plan"
    if isinstance(obj, dict):
        if "valueRanges" in obj:                                   # values:batchGet
            out = []
            for vr in obj["valueRanges"] or []:
                vals = vr.get("values") or []
                if str(vr.get("majorDimension", "ROWS")).upper() == "COLUMNS":
                    w = max((len(c) for c in vals), default=0)
                    vals = [[col[i] if i < len(col) else "" for col in vals] for i in range(w)]
                out.append({"range": vr.get("range"), "values": vals})
            return out, "sheets values:batchGet"
        if "data" in obj and isinstance(obj["data"], list):        # values:batchUpdate body
            return [b for b in obj["data"] if isinstance(b, dict) and "range" in b], "batchUpdate body"
        if "range" in obj and "values" in obj:                     # values:get
            return [obj], "sheets values:get"
    raise ValueError("unrecognised JSON: expected a saved plan (list of {range, values}), a values:batchGet response "
                     "({valueRanges: [...]}), a batchUpdate body ({data: [...]}) or a values:get response")


def load_blocks(paths) -> tuple[list[dict], str, list[str]]:
    paths = [paths] if isinstance(paths, (str, Path)) else list(paths)
    blocks, kinds, hashes = [], [], []
    for p in paths:
        raw = Path(p).read_bytes()
        b, k = _blocks_of(json.loads(raw.decode("utf-8")))
        blocks += b; kinds.append(k); hashes.append(hashlib.sha256(raw).hexdigest()[:16])
    return blocks, " + ".join(dict.fromkeys(kinds)), hashes


def _unescape(v):
    """A saved plan stores text that looks like a formula with a leading quote (common_format.escape_formula); Sheets
    strips that quote, so the workbook holds the text without it."""
    if isinstance(v, str) and v.startswith("'") and escape_formula(v[1:]) == v:
        return v[1:]
    return v


NUM_RE = re.compile(r"^\(?[-+]?[$€£]?\s*[-+]?(\d{1,3}(,\d{3})+|\d+)?(\.\d+)?([eE][-+]?\d+)?\s*%?\)?$")


def as_number(v) -> float | None:
    if isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        return float(v) if math.isfinite(float(v)) else None
    if not isinstance(v, str):
        return None
    t = v.strip()
    if not t or not NUM_RE.match(t) or not re.search(r"\d", t):
        return None
    neg = t.startswith("(") and t.endswith(")")
    pct = t.rstrip(")").endswith("%")
    t = re.sub(r"[()$€£,%\s]", "", t)
    try:
        x = float(t)
    except ValueError:
        return None
    x = -x if neg else x
    return x / 100 if pct else x


def _norm(v):
    v = _unescape(v)
    if v is None:
        return ""
    if isinstance(v, str) and v.upper() in ("TRUE", "FALSE"):
        return v.upper() == "TRUE"
    return v


def expand(blocks: list[dict]) -> tuple[dict, list[tuple[str, int, int, int | None, int | None, str]]]:
    """{(sheet, row, col): value} for every cell the blocks hold, and each block's rectangle. Later blocks win."""
    cells, rects = {}, []
    for b in blocks:
        sheet, r0, c0, r1, c1 = parse_range(b["range"])
        vals = b.get("values") or []
        rects.append((sheet, r0, c0, r1, c1, b["range"]))
        for i, row in enumerate(vals):
            row = row if isinstance(row, (list, tuple)) else [row]
            for j, v in enumerate(row):
                cells[(sheet, r0 + i, c0 + j)] = _norm(v)
    return cells, rects


def _overlap(a, b) -> bool:
    if a[0] != b[0]:
        return False
    big = 10 ** 9
    ar1, ac1 = a[3] or big, a[4] or big; br1, bc1 = b[3] or big, b[4] or big
    return not (ar1 < b[1] or br1 < a[1] or ac1 < b[2] or bc1 < a[2])


# ---------------------------------------------------------------- diff
def compare_values(old, new, tolerance: float, large: float) -> dict | None:
    """None when equal (within tolerance); else {kind, abs_change, rel_change, large}."""
    o_empty = old in ("", None); n_empty = new in ("", None)
    if o_empty and n_empty:
        return None
    if o_empty:
        return {"kind": "filled", "abs_change": None, "rel_change": None, "large": False}
    if n_empty:
        return {"kind": "cleared", "abs_change": None, "rel_change": None, "large": True}
    xo, xn = as_number(old), as_number(new)
    if isinstance(old, bool) or isinstance(new, bool):
        return None if old == new else {"kind": "text", "abs_change": None, "rel_change": None, "large": False}
    if xo is not None and xn is not None:
        d = xn - xo
        if abs(d) <= tolerance * max(1.0, abs(xo), abs(xn)):
            return None
        rel = d / abs(xo) if xo != 0 else None
        big = (rel is None) or abs(rel) >= large or (xo * xn < 0)
        return {"kind": "number", "abs_change": d, "rel_change": rel, "large": bool(big)}
    if str(old) == str(new):
        return None
    if (xo is None) != (xn is None):
        return {"kind": "type", "abs_change": None, "rel_change": None, "large": True}
    return {"kind": "text", "abs_change": None, "rel_change": None, "large": False}


def diff(plan_blocks: list[dict], base_blocks: list[dict], tolerance: float = 1e-6, large: float = 0.25) -> dict:
    new_cells, new_rects = expand(plan_blocks)
    old_cells, old_rects = expand(base_blocks)
    ranges, changes = [], []
    for b, rect in zip(plan_blocks, new_rects):
        sheet, r0, c0, r1, c1, rng = rect
        present = any(_overlap(rect, o) for o in old_rects)
        vals = b.get("values") or []
        n = ch = lg = 0; max_rel = None
        for i, row in enumerate(vals):
            row = row if isinstance(row, (list, tuple)) else [row]
            for j, _ in enumerate(row):
                key = (sheet, r0 + i, c0 + j); n += 1
                new = new_cells.get(key, ""); old = old_cells.get(key, "")
                c = compare_values(old, new, tolerance, large) if present else ({"kind": "new range", "abs_change": None, "rel_change": None, "large": False} if new not in ("", None) else None)
                if c is None:
                    continue
                ch += 1; lg += int(c["large"])
                if c["rel_change"] is not None:
                    max_rel = abs(c["rel_change"]) if max_rel is None else max(max_rel, abs(c["rel_change"]))
                changes.append({"range": rng, "sheet": sheet, "cell": cell_a1(sheet, *key[1:]), "old": old if present else "", "new": new, **c})
        ranges.append({"range": rng, "sheet": sheet, "status": "new" if not present else ("changed" if ch else "unchanged"),
                       "cells": n, "changed": ch, "large": lg, "max_abs_rel_change": max_rel})
    removed = [{"range": o[5], "sheet": o[0], "status": "not in new plan"} for o in old_rects if not any(_overlap(o, p) for p in new_rects)]
    totals = {"ranges": len(ranges), "ranges_changed": sum(r["status"] == "changed" for r in ranges), "ranges_new": sum(r["status"] == "new" for r in ranges),
              "ranges_unchanged": sum(r["status"] == "unchanged" for r in ranges), "ranges_not_in_plan": len(removed),
              "cells": sum(r["cells"] for r in ranges), "cells_changed": len(changes), "cells_large": sum(c["large"] for c in changes)}
    changes.sort(key=lambda c: (not c["large"], -(abs(c["rel_change"]) if c["rel_change"] is not None else (1e18 if c["large"] else 0))))
    return {"ranges": ranges, "removed": removed, "changes": changes, "totals": totals}


# ---------------------------------------------------------------- fetching the live side (Sam, on the Mac)
def batchget_urls(plan_blocks: list[dict], spreadsheet_id: str = "SPREADSHEET_ID", max_len: int = 1800) -> list[str]:
    """values:batchGet URLs covering every plan range, split so no URL is longer than about `max_len`. Fetch each with
    the Sheets token (curl -H "Authorization: Bearer $ECONQUEST_SHEETS_TOKEN" URL > live_N.json) and pass all files as
    the baseline. UNFORMATTED_VALUE avoids display rounding."""
    base = f"{SHEETS_API}/{spreadsheet_id}/values:batchGet?valueRenderOption=UNFORMATTED_VALUE&dateTimeRenderOption=FORMATTED_STRING"
    urls, cur = [], base
    for b in plan_blocks:
        sheet, r0, c0, r1, c1 = parse_range(b["range"])
        rng = f"{_quote_sheet(sheet)}!{col_letters(c0)}{r0}" + (f":{col_letters(c1)}{r1}" if (r1, c1) != (r0, c0) and r1 and c1 else "")
        part = "&ranges=" + urllib.parse.quote(rng, safe="")
        if len(cur) + len(part) > max_len and cur != base:
            urls.append(cur); cur = base
        cur += part
    if cur != base:
        urls.append(cur)
    return urls


# ---------------------------------------------------------------- output
def _plan_stamps(plan_blocks: list[dict]) -> dict:
    for b in plan_blocks:
        for row in b.get("values") or []:
            for v in (row if isinstance(row, (list, tuple)) else [row]):
                if isinstance(v, str) and "EconQuest" in v:
                    m = NOTE_RUN_RE.search(v); d = NOTE_DATE_RE.search(v)
                    if m:
                        return {"run_id": m.group(1), "as_of": d.group(1) if d else None}
    return {"run_id": None, "as_of": None}


def _fmt(v) -> str:
    if isinstance(v, float):
        return f"{v:,.6g}"
    return "" if v is None else str(v)


def _csv_cell(v):
    """Numbers as numbers; text escaped so a spreadsheet opening the CSV does not evaluate it (EQ-C-0007)."""
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return v
    return escape_formula("" if v is None else str(v))


def _rel(v) -> str:
    return "" if v is None else f"{v * 100:+.1f}%"


def render_html(res: dict) -> str:
    t = res["totals"]; st = res["stamps"]
    meta = "".join(f"<span><b>{_e(k)}</b> {_e(v)}</span>" for k, v in (("New plan", res["plan"]), ("Plan run", st.get("run_id") or "not stamped"), ("Plan date", st.get("as_of") or "n/a"),
                   ("Plan sha256", res["plan_hash"]), ("Baseline", ", ".join(res["baseline"])), ("Baseline kind", res["baseline_kind"]),
                   ("Data hash", st.get("data_hash") or "n/a"), ("Tolerance", res["tolerance"]), ("Large move", f"{res['large'] * 100:.0f}%")))
    tiles = [(t["cells_changed"], "Cells changed"), (t["cells_large"], "LARGE moves"), (t["ranges_changed"], "Ranges changed"), (t["ranges_new"], "NEW ranges"),
             (t["ranges_not_in_plan"], "Baseline ranges not in plan"), (t["ranges_unchanged"], "Ranges unchanged"), (t["cells"], "Cells in plan")]
    kpis = "".join(f"<div class='kpi'><div class='v'>{v:,}</div><div class='l'>{_e(lbl)}</div></div>" for v, lbl in tiles)
    order = {"changed": 0, "new": 1, "unchanged": 2}
    rr = sorted(res["ranges"], key=lambda r: (order[r["status"]], -r["large"], -r["changed"]))
    rtab = "".join(f"<tr><td>{_e(r['range'])}</td><td>{'<b>' + _e(r['status'].upper()) + '</b>' if r['status'] != 'unchanged' else 'unchanged'}</td><td class='n'>{r['cells']:,}</td>"
                   f"<td class='n'>{r['changed']:,}</td><td class='n'>{('<b>' + format(r['large'], ',') + ' LARGE</b>') if r['large'] else 0}</td><td class='n'>{_rel(r['max_abs_rel_change'])}</td></tr>" for r in rr)
    ch = res["changes"]
    ctab = "".join(f"<tr><td>{'<span class=' + chr(39) + 'tag fire' + chr(39) + '>LARGE</span>' if c['large'] else ''}</td><td>{_e(c['range'])}</td><td>{_e(c['cell'])}</td><td>{_e(c['kind'])}</td>"
                   f"<td class='n'>{_e(_fmt(c['old'])[:80])}</td><td class='n'>{_e(_fmt(c['new'])[:80])}</td><td class='n'>{_e(_fmt(c['abs_change']))}</td><td class='n'>{_rel(c['rel_change'])}</td></tr>"
                   for c in ch[:MAX_CELL_ROWS_HTML])
    more = f"<p class='note'>{len(ch) - MAX_CELL_ROWS_HTML:,} more changed cells in {_e(Path(res['cells_csv']).name)}.</p>" if len(ch) > MAX_CELL_ROWS_HTML else ""
    rem = ("<table><tr><th>Baseline range</th><th>Status</th></tr>" + "".join(f"<tr><td>{_e(r['range'])}</td><td>not written by the new plan (left as is in the workbook)</td></tr>" for r in res["removed"]) + "</table>"
           if res["removed"] else "<p class='empty'>Every baseline range is covered by the new plan.</p>")
    verdict = ("No cell would change." if not t["cells_changed"] else
               f"{t['cells_changed']:,} cells would change, {t['cells_large']:,} of them by a LARGE move (at least {res['large'] * 100:.0f}%, a sign flip, a cleared cell or a type change).")
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Republish preview {_e(res['generated'][:10])}</title>
<style>{NOTE_CSS}</style></head><body>
<h1>Republish preview</h1>
<div class="sub">What `econquest publish --write` would change in the workbook, against {_e(res['baseline_kind'])}. {_e(verdict)} Review before writing; this page writes nothing.</div>
<div class="meta">{meta}</div>
<div class="disclaimer" role="note"><b>Disclaimer.</b> {_e(DISCLAIMER)}</div>
<h2>Totals</h2><div class="kpis">{kpis}</div>
<h2>Ranges</h2><table class="compact"><tr><th>Range</th><th>Status</th><th class="n">Cells</th><th class="n">Changed</th><th class="n">Large</th><th class="n">Largest relative change</th></tr>{rtab}</table>
<h2>Changed cells (largest first)</h2>
{('<table class="compact"><tr><th>Flag</th><th>Range</th><th>Cell</th><th>Kind</th><th class="n">Old (workbook)</th><th class="n">New (plan)</th><th class="n">Change</th><th class="n">Relative</th></tr>' + ctab + '</table>' + more) if ch else '<p class="empty">No changed cell.</p>'}
<h2>Baseline ranges the new plan does not write</h2>{rem}
<p class="note">Numbers equal within tolerance x max(1, |old|, |new|). Old values from a formatted fetch are parsed ("1,234.5", "12%"); fetch with valueRenderOption=UNFORMATTED_VALUE to avoid display rounding. Generated {_e(res['generated'])} UTC.</p>
<div class="disclaimer" role="note"><b>Disclaimer.</b> {_e(DISCLAIMER)}</div>
</body></html>"""


def preview(plan_path: str | Path, baseline_path, out_dir: str | Path, tolerance: float = 1e-6, large: float = 0.25, data_dir: str | Path | None = None,
            log=print) -> dict:
    """Diff a new publish plan against the workbook's current values (a saved values:batchGet JSON, or several) or a
    previous plan. Writes <out_dir>/publish-preview-<date>.html, publish-preview-cells.csv (every changed cell) and
    publish-preview-ranges.csv (per range), and returns the summary with "paths", "totals", "ranges", "removed" and the
    plan stamps (run_id / as_of from the plan's note cells; data_hash of `data_dir` when given)."""
    plan_path = Path(plan_path); out_dir = Path(out_dir)
    plan_blocks, _, plan_hash = load_blocks(plan_path)
    base_paths = [baseline_path] if isinstance(baseline_path, (str, Path)) else list(baseline_path)
    base_blocks, base_kind, base_hash = load_blocks(base_paths)
    d = diff(plan_blocks, base_blocks, tolerance=tolerance, large=large)
    st = _plan_stamps(plan_blocks)
    if data_dir is not None:
        from ..versioning import data_hash
        st["data_hash"] = data_hash(data_dir)
    out_dir.mkdir(parents=True, exist_ok=True)
    gen = dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M")
    html_p = out_dir / f"publish-preview-{gen[:10]}.html"; cells_p = out_dir / "publish-preview-cells.csv"; ranges_p = out_dir / "publish-preview-ranges.csv"
    with cells_p.open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh); w.writerow(["large", "range", "cell", "kind", "old", "new", "abs_change", "rel_change"])
        for c in d["changes"]:
            w.writerow([int(c["large"]), _csv_cell(c["range"]), _csv_cell(c["cell"]), c["kind"], _csv_cell(c["old"]), _csv_cell(c["new"]),
                        "" if c["abs_change"] is None else c["abs_change"], "" if c["rel_change"] is None else c["rel_change"]])
    with ranges_p.open("w", newline="", encoding="utf-8") as fh:
        w = csv.writer(fh); w.writerow(["range", "status", "cells", "changed", "large", "max_abs_rel_change"])
        for r in d["ranges"]:
            w.writerow([_csv_cell(r["range"]), r["status"], r["cells"], r["changed"], r["large"], "" if r["max_abs_rel_change"] is None else r["max_abs_rel_change"]])
        for r in d["removed"]:
            w.writerow([_csv_cell(r["range"]), r["status"], "", "", "", ""])   # ranges come from the baseline JSON too
    res = {"kind": "publish_preview", "plan": str(plan_path), "plan_hash": plan_hash[0], "baseline": [str(p) for p in base_paths], "baseline_kind": base_kind,
           "baseline_hash": base_hash, "tolerance": tolerance, "large": large, "generated": gen, "stamps": st, "cells_csv": str(cells_p), **d}
    from .csp import harden
    html_p.write_text(harden(render_html(res)), encoding="utf-8")                   # EQ-C-0165 meta CSP
    res.update({"html": str(html_p), "ranges_csv": str(ranges_p), "paths": [str(html_p), str(cells_p), str(ranges_p)],
                "run_id": st.get("run_id"), "as_of": st.get("as_of"), "data_hash": st.get("data_hash"), "run_hash": None})
    t = d["totals"]
    log(f"[preview] {t['cells_changed']:,} cells changed ({t['cells_large']:,} large) in {t['ranges_changed']} of {t['ranges']} ranges; "
        f"{t['ranges_new']} new, {t['ranges_not_in_plan']} baseline ranges not in plan -> {html_p}")
    return res
