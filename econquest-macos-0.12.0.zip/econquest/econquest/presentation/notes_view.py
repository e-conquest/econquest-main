"""Read-only research notes for the GUI (EQ-C-0127, MVP row M7): Team B's MVP research pack (EQ-B-0110,
`python -m econquest.validation.mvp_pack build`) under <outputs>/reports/mvp.

    list_notes(out_dir)          -> {"status", "message", "pack": {stamps}, "notes": [{id, kind, title, state, ...}]}
    get_note(out_dir, note_id)   -> one note as text blocks, its disclaimer and its licence attribution, or None

The index is the pack's own: pack.json "editorial" (kind, id, title), with each id's file taken from the editorial
ledger (<pack>/editorial/ledger.jsonl, presentation/editorial.py) and resolved by file name inside the pack folder for
its kind (the pack may have moved, as in mvp_pack.check_pack). A pack built with --no-register has no editorial ids:
then the manifests (notes/country-notes.json, briefs/scenario-briefs.json, weekly-brief/*.json) name the files and the
id is the file stem. The trade-ideas page comes from pack.json "trade_ideas" when the ledger does not hold it.

Security: a note id is looked up in that index and never used as a path; file names from the index must be a plain
name ending in .html and the resolved file must sit directly in the pack's folder for its kind. A note is returned as
plain text blocks (headings, paragraphs, lists, tables, KPI tiles) parsed with html.parser: no markup, no attribute
and no script/style/svg content reaches the browser, which renders every string through esc().
"""
from __future__ import annotations

import hashlib
import json
import re
from html.parser import HTMLParser
from pathlib import Path

PACK_REL = Path("reports") / "mvp"
# kind -> pack sub-folders its files may sit in (the trade-ideas page is drafted as weekly_brief until editorial has
# a trade_ideas kind, mvp_pack.ideas_kind)
KIND_DIRS = {"country_note": ("notes",), "scenario_brief": ("briefs",), "weekly_brief": ("weekly-brief", "trade-ideas"),
             "trade_ideas": ("trade-ideas",)}
KIND_LABELS = {"country_note": "Country note", "scenario_brief": "Scenario brief", "weekly_brief": "Weekly brief",
               "trade_ideas": "Trade ideas"}
ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,99}$")
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,159}\.html$")
MAX_BYTES = 5_000_000                    # a note larger than this is not parsed
MAX_BLOCKS = 5000
SKIP_TAGS = {"script", "style", "svg", "noscript", "template", "iframe", "object", "embed", "head", "title", "math",
             "canvas", "video", "audio", "select", "textarea", "button", "form"}
VOID_TAGS = {"br", "hr", "img", "meta", "link", "input", "wbr", "col", "source", "area", "base", "param", "track"}


def pack_dir(out_dir) -> Path:
    return Path(out_dir) / PACK_REL


def _load(p: Path):
    try:
        return json.loads(p.read_text(encoding="utf-8")) if p.is_file() else None
    except (OSError, ValueError):
        return None


def _safe_file(pack: Path, kind: str, name) -> Path | None:
    """The pack file `name` for `kind`, or None: a plain .html name directly inside one of the kind's folders."""
    name = str(name or "")
    if not name or not NAME_RE.match(name):
        return None
    root = pack.resolve()
    for sub in KIND_DIRS.get(kind, ()):
        f = (pack / sub / name)
        try:
            r = f.resolve()
        except OSError:
            continue
        if r.parent == (root / sub) and r.is_file():
            return r
    return None


def _ledger_items(pack: Path) -> dict:
    try:
        from .editorial import list_items
        return {i["item_id"]: i for i in list_items(pack)}
    except Exception:                                   # noqa: BLE001 - an unreadable ledger leaves the manifests
        return {}


def _index(out_dir) -> tuple[dict, dict]:
    """({status, message, pack}, {id: entry}) where entry holds the resolved path (server side only)."""
    pack = pack_dir(out_dir)
    pj = _load(pack / "pack.json")
    if pj is None:
        return ({"status": "missing", "message": "No research pack yet: build it with "
                 "python -m econquest.validation.mvp_pack build --as-of YYYY-MM-DD (Team B, EQ-B-0110).", "pack": {}}, {})
    stamps = {k: pj.get(k) for k in ("as_of", "run_id", "data_hash", "run_hash", "ticket")}
    check = _load(pack / "check.json") or {}
    entries: dict[str, dict] = {}
    ledger = _ledger_items(pack)

    def add(nid, kind, title, name, state=None, sha=None):
        nid = str(nid or "")
        if not ID_RE.match(nid) or nid in entries or kind not in KIND_DIRS:
            return
        f = _safe_file(pack, kind, name)
        if f is None:
            return
        if kind == "weekly_brief" and f.parent.name == "trade-ideas":
            kind = "trade_ideas"
        entries[nid] = {"id": nid, "kind": kind, "kind_label": KIND_LABELS.get(kind, kind), "title": str(title or f.stem),
                        "state": state, "file": f.name, "_path": f, "_sha": sha}

    for e in pj.get("editorial") or []:
        if not isinstance(e, dict):
            continue
        it = ledger.get(e.get("id")) or {}
        files = [x for x in it.get("files") or [] if isinstance(x, dict) and str(x.get("name", "")).endswith(".html")]
        if files:
            add(e.get("id"), e.get("kind"), e.get("title"), files[0].get("name"), it.get("state"), files[0].get("sha256"))
    if not entries:                                     # --no-register pack: the manifests are the index
        for kind, sub, man in (("country_note", "notes", "country-notes.json"), ("scenario_brief", "briefs", "scenario-briefs.json")):
            for it in (_load(pack / sub / man) or {}).get("items") or []:
                if isinstance(it, dict) and it.get("html"):
                    add(Path(str(it["html"])).stem, kind, it.get("title"), Path(str(it["html"])).name)
        wj = sorted((pack / "weekly-brief").glob("weekly-brief-*.json")) if (pack / "weekly-brief").is_dir() else []
        if wj:
            add(wj[-1].stem, "weekly_brief", f"Weekly brief {stamps.get('as_of') or ''}".strip(), wj[-1].stem + ".html")
    if pj.get("trade_ideas") and not any(e["kind"] == "trade_ideas" for e in entries.values()):
        name = Path(str(pj["trade_ideas"])).name
        add(Path(name).stem, "trade_ideas", f"Trade ideas {stamps.get('as_of') or ''} (playbook activations)".strip(), name)
    n = len(entries)
    head = {"status": "ok" if n else "empty",
            "message": (f"{n} notes from the research pack of run {stamps.get('run_id')} (as of {stamps.get('as_of')})."
                        if n else "The research pack lists no readable notes."),
            "pack": stamps, "check": {"ok": check.get("ok"), "problems": len(check.get("problems") or []),
                                      "checked": check.get("checked")} if check else None}
    return head, entries


def _public(e: dict) -> dict:
    return {k: v for k, v in e.items() if not k.startswith("_")}


def list_notes(out_dir) -> dict:
    head, entries = _index(out_dir)
    counts: dict[str, int] = {}
    for e in entries.values():
        counts[e["kind"]] = counts.get(e["kind"], 0) + 1
    return {**head, "counts": counts, "notes": [_public(e) for e in entries.values()]}


# ---------------------------------------------------------------- HTML -> text blocks
def _norm(s: str) -> str:
    return re.sub(r"\s+", " ", s).strip()


class _Blocks(HTMLParser):
    """Text-only reading of a pack HTML file. Emits blocks; collects the disclaimer, research marking and the licence
    attribution lists separately. Nothing but text is kept."""
    BLOCK = {"p", "div", "section", "main", "article", "header", "footer", "h1", "h2", "h3", "h4", "h5", "h6", "li",
             "ul", "ol", "table", "tr", "body", "blockquote", "pre", "dl", "dt", "dd", "figure", "figcaption", "nav", "aside"}

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.blocks: list[dict] = []
        self.disclaimer: list[str] = []; self.marking: list[str] = []
        self.attribution: list[str] = []; self.internal_only: list[str] = []
        self.stack: list[tuple[str, set]] = []
        self.skip = 0
        self.buf: list[str] = []
        self.list_items: list[str] | None = None
        self.table: list[list[dict]] | None = None; self.row: list[dict] | None = None; self.cell: list[str] | None = None
        self.cell_head = False
        self.kpi: list[str] | None = None; self.kpi_depth = 0
        self.special: str | None = None; self.special_depth = 0; self.special_buf: list[str] = []
        self.licence_list: str | None = None

    # -- helpers
    def _emit(self, t: str, **kw):
        if len(self.blocks) < MAX_BLOCKS:
            self.blocks.append({"t": t, **kw})

    def _flush(self, tag: str = "p"):
        text = _norm("".join(self.buf)); self.buf = []
        if not text:
            return
        if self.list_items is not None:
            self.list_items.append(text)
        elif tag in ("h1", "h2", "h3", "h4", "h5", "h6"):
            self._emit("h", level=min(int(tag[1]), 4), text=text)
        else:
            self._emit("p", text=text)

    def _classes(self) -> set:
        out: set = set()
        for _t, c in self.stack:
            out |= c
        return out

    # -- parser callbacks
    def handle_starttag(self, tag, attrs):
        if self.skip:
            if tag not in VOID_TAGS:
                self.skip += 1
            return
        if tag in SKIP_TAGS:
            self.skip = 1; return
        if tag in VOID_TAGS:
            if tag == "br":
                (self.cell if self.cell is not None else self.special_buf if self.special else
                 self.kpi if self.kpi is not None else self.buf).append(" ")
            return
        cls = set(str(dict(attrs).get("class") or "").split())
        self.stack.append((tag, cls))
        if self.special:
            self.special_depth += 1
            if self.special == "licence" and tag in ("ul", "ol"):
                self.licence_list = ("attribution" if "licence-attribution" in cls else
                                     "internal_only" if "licence-internal" in cls else None)
            if tag == "li":
                self.special_buf = []
            return
        if "licence-block" in cls or "licence-attribution" in cls or "licence-internal" in cls:
            self._flush()
            self.special = "licence"; self.special_depth = 1; self.special_buf = []
            self.licence_list = ("attribution" if "licence-attribution" in cls else
                                 "internal_only" if "licence-internal" in cls else None)
            return
        if "disclaimer" in cls or "research-block" in cls:
            self._flush()
            self.special = "disclaimer" if "disclaimer" in cls else "marking"
            self.special_depth = 1; self.special_buf = []; return
        if self.kpi is not None:
            self.kpi_depth += 1
            if tag in self.BLOCK or tag == "span":
                self.kpi.append(" | ")
            return
        if "kpi" in cls:
            self._flush(); self.kpi = []; self.kpi_depth = 1; return
        if self.table is not None:
            if tag == "tr":
                self.row = []
            elif tag in ("td", "th") and self.row is not None:
                self.cell = []; self.cell_head = tag == "th"
            return
        if tag == "table":
            self._flush(); self.table = []; return
        if tag in ("ul", "ol"):
            self._flush(); self.list_items = []; return
        if tag in self.BLOCK:
            self._flush()
        elif tag == "span" and self.cell is None:
            self.buf.append(" ")

    def handle_endtag(self, tag):
        if self.skip:
            if tag not in VOID_TAGS:
                self.skip -= 1
            return
        if tag in VOID_TAGS:
            return
        # pop to the matching open tag (tolerates unclosed children)
        idx = next((i for i in range(len(self.stack) - 1, -1, -1) if self.stack[i][0] == tag), None)
        if idx is None:
            return
        depth = len(self.stack) - idx
        del self.stack[idx:]
        if self.special:
            self.special_depth -= depth
            if self.special == "licence" and tag == "li":
                t = _norm("".join(self.special_buf)); self.special_buf = []
                if t and self.licence_list:
                    getattr(self, self.licence_list).append(t)
            elif self.special == "licence" and tag in ("ul", "ol"):
                self.licence_list = None
            if self.special_depth <= 0:
                t = _norm("".join(self.special_buf))
                if t and self.special in ("disclaimer", "marking"):
                    getattr(self, self.special).append(t)
                self.special = None; self.special_buf = []
            return
        if self.kpi is not None:
            self.kpi_depth -= depth
            if self.kpi_depth <= 0:
                parts = [_norm(p) for p in "".join(self.kpi).split(" | ")]
                parts = [p for p in parts if p]
                if parts:
                    self._emit("kpi", parts=parts[:6])
                self.kpi = None
            return
        if self.table is not None:
            if tag in ("td", "th") and self.cell is not None and self.row is not None:
                self.row.append({"text": _norm("".join(self.cell)), "head": self.cell_head}); self.cell = None
            elif tag == "tr" and self.row is not None:
                if any(c["text"] for c in self.row):
                    self.table.append(self.row)
                self.row = None
            elif tag == "table":
                if self.table:
                    self._emit("table", rows=self.table[:400])
                self.table = None
            return
        if tag in ("ul", "ol") and self.list_items is not None:
            self._flush()
            if self.list_items:
                self._emit("list", items=self.list_items[:400])
            self.list_items = None
            return
        if tag in self.BLOCK:
            self._flush(tag)

    def handle_data(self, data):
        if self.skip:
            return
        if self.special:
            self.special_buf.append(data)
        elif self.kpi is not None:
            self.kpi.append(data)
        elif self.table is not None:
            if self.cell is not None:
                self.cell.append(data)
        else:
            self.buf.append(data)

    def close(self):
        super().close()
        self._flush()


def parse_note(text: str) -> dict:
    p = _Blocks()
    p.feed(text); p.close()
    return {"blocks": p.blocks, "disclaimer": " ".join(dict.fromkeys(p.disclaimer)), "marking": " ".join(dict.fromkeys(p.marking)),
            "attribution": list(dict.fromkeys(p.attribution)), "internal_only": list(dict.fromkeys(p.internal_only))}


def get_note(out_dir, note_id) -> dict | None:
    """One note by its index id, or None when the id is not in the pack's index (never a path lookup)."""
    nid = str(note_id or "")
    if not ID_RE.match(nid):
        return None
    head, entries = _index(out_dir)
    e = entries.get(nid)
    if e is None:
        return None
    f: Path = e["_path"]
    data = f.read_bytes()
    if len(data) > MAX_BYTES:
        return {**_public(e), "pack": head["pack"], "error": "note too large to show", "blocks": [], "disclaimer": "",
                "attribution": [], "internal_only": [], "marking": ""}
    changed = bool(e.get("_sha")) and hashlib.sha256(data).hexdigest() != e["_sha"]
    from .report import DISCLAIMER
    body = parse_note(data.decode("utf-8", errors="replace"))
    body["disclaimer_ok"] = DISCLAIMER in body["disclaimer"]
    body["attribution_ok"] = bool(body["attribution"])
    return {**_public(e), "pack": head["pack"], "changed_since_draft": changed, **body}
