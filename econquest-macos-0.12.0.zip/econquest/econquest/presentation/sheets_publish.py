"""Publish a run back into the Geopolitical-Macro Risk Desk workbook as values.

The workbook keeps its tabs and layouts; every cell that used to hold a model formula receives the
Python value instead, so the sheet is the input and presentation layer and Python is the only
calculator. `build_plan` returns a list of {"range", "values"} blocks (A1 notation). `apply_plan`
writes them through the Sheets v4 REST API when a bearer token is available; the plan can also be
saved as JSON and applied by any other Sheets client.

Layout v2 (EQ-C-0033): ranges come from layout_v2(len(countries)), so the plan fits any country count; at 18 countries
it is the v1 plan byte for byte."""
from __future__ import annotations
import json
import re
import urllib.parse
import urllib.request
from datetime import date
from pathlib import Path
import numpy as np
import pandas as pd
from ..validation import backtest_history
# Cell helpers live in the neutral econquest.common_format (EQ-C-0010); re-exported here so existing
# `from ..presentation.sheets_publish import _v` imports keep working.
from ..common_format import _v, cell_value, escape_formula, safe_cell, sanitize_plan  # noqa: F401

SHEETS_API = "https://sheets.googleapis.com/v4/spreadsheets"
SHEET_ID_RE = re.compile(r"[A-Za-z0-9_-]{1,128}")

# Workbook layout v2 (EQ-C-0033, contract C11): every country-by-column block starts at column E and is
# len(countries) wide, so the layout grows with the run instead of assuming 18 countries (E:V). At 18 countries
# every range is the v1 range; data/workbook_reference.json["layout"] documents what moves at N > 18.
LAYOUT_VERSION = 2
COUNTRY_COL0 = 5                     # column E: first country column on the country-by-column tabs
SHEETS_MAX_COLS = 18278              # Google Sheets column limit (ZZZ)
COUNTRY_COLS = "E:V"                 # v1 constant, the 18-country block; use country_cols(n) for a run
ASSET_CLASSES = ["FX", "Local bond", "Eurobond", "Equity", "CDS protection"]


def col_letter(n: int) -> str:
    """1-based column number -> A1 letters: 1 -> A, 26 -> Z, 27 -> AA, 18278 -> ZZZ."""
    n = int(n)
    if not 1 <= n <= SHEETS_MAX_COLS:
        raise ValueError(f"column {n} outside 1..{SHEETS_MAX_COLS} (Google Sheets limit)")
    s = ""
    while n:
        n, r = divmod(n - 1, 26)
        s = chr(65 + r) + s
    return s


def col_number(letters: str) -> int:
    """A1 letters -> 1-based column number (inverse of col_letter)."""
    if not re.fullmatch(r"[A-Z]{1,3}", letters or ""):
        raise ValueError(f"not a column: {letters!r}")
    n = 0
    for ch in letters:
        n = n * 26 + ord(ch) - 64
    return n


def a1(tab: str, c1: int, r1: int, c2: int | None = None, r2: int | None = None) -> str:
    """A1 range from column numbers; `tab` is passed as it appears in the range (quoted when it has spaces)."""
    head = f"{tab}!{col_letter(c1)}{r1}"
    return head if c2 is None else f"{head}:{col_letter(c2)}{r2 if r2 is not None else r1}"


def country_cols(n: int, first: int = COUNTRY_COL0) -> str:
    """Columns of an n-country block: country_cols(18) == 'E:V', country_cols(70) == 'E:BV'."""
    return f"{col_letter(first)}:{col_letter(first + n - 1)}"


def country_range(tab: str, r1: int, r2: int, n: int, first: int = COUNTRY_COL0) -> str:
    """Country-by-column block rows r1..r2: country_range("'Risk Engine'", 5, 37, 18) == "'Risk Engine'!E5:V37"."""
    if n < 1:
        raise ValueError("a country block needs at least one country")
    return a1(tab, first, r1, first + n - 1, r2)


def layout_v2(n: int, *, n_indicators: int = 83, row_410: int = 45, n_regions: int = 3, n_playbook: int = 26,
              n_dashboard_cols: int = 22, mc_rows: int = 2000, n_signals: int = 25) -> dict[str, str]:
    """Ranges of every block whose size depends on the run (countries, indicators, regions, playbook), by block name.

    Single source of truth for build_plan and for data/workbook_reference.json["layout"]. With the defaults and
    n = 18 every range equals the v1 hard-coded range. At n > 18: country blocks widen right from column E;
    'Portfolio VaR' holdings, 'Prediction Markets' country rows and the Dashboard grow down; the 'Portfolio VaR'
    asset-class table moves to row 52 + n (with its own header); the MC loss columns move right of the latent block."""
    cr = lambda tab, r1, r2: country_range(tab, r1, r2, n)  # noqa: E731
    ind_end = 4 + n_indicators
    L = {"inputs_410": cr("Inputs", row_410, row_410),
         "stress_inputs": cr("'Stress Inputs'", 5, ind_end),
         "stress_helpers": cr("'Stress Inputs'", max(90, ind_end + 3), max(92, ind_end + 5)),
         "base_scores": cr("'Base Scores'", 5, ind_end),
         "stress_scores": cr("'Stress Scores'", 5, ind_end),
         "indicator_scores": cr("'Indicator Scores'", 5, ind_end),
         "adj_triggers": cr("Adjustments", 5, 11), "adj_floors": cr("Adjustments", 21, 27),
         "pillar_wavg": cr("'Pillar Scores'", 5, 11), "pillar_worst": cr("'Pillar Scores'", 13, 19),
         "pillar_aggregated": cr("'Pillar Scores'", 21, 27), "pillar_final": cr("'Pillar Scores'", 29, 35),
         "pillar_weights": cr("'Pillar Scores'", 37, 44), "pillar_composite": cr("'Pillar Scores'", 46, 47),
         "risk_engine": cr("'Risk Engine'", 5, 37),
         "signals": cr("Signals", 5, 4 + n_signals),
         "trade_labels": a1("'Trade Activation'", 1, 5, 4, 4 + n_playbook),
         "trade_activation": cr("'Trade Activation'", 5, 4 + n_playbook),
         "pv_holdings": a1("'Portfolio VaR'", 1, 50, 13, 49 + n)}
    ac = max(70, 52 + n)                      # v1 row 70; below the holdings (one blank row, one header row) when n > 18
    if ac != 70:
        L["pv_asset_class_head"] = a1("'Portfolio VaR'", 1, ac - 1, 6, ac - 1)
        L["pv_asset_class_labels"] = a1("'Portfolio VaR'", 1, ac, 1, ac + 4)
    L["pv_asset_class"] = a1("'Portfolio VaR'", 2, ac, 6, ac + 4)
    lat0 = 4 + n_regions                      # MC factor columns: path, global, regions..., chi2, then one per country
    lat1 = 3 + n_regions + n
    loss0 = max(26, lat1 + 2)                 # v1 column Z; one blank column after the latent block
    L.update({"mc_params": a1("MC", lat0, 2, lat1, 5),
              "mc_factors": a1("MC", 1, 7, lat1, 6 + mc_rows),
              "mc_losses": a1("MC", loss0, 7, loss0 + 30, 6 + mc_rows),
              "pm_countries": a1("'Prediction Markets'", 1, 38, 13, 37 + n),
              "gpr_levels": cr("GPR", 5, 13), "gpr_signal": cr("GPR", 15, 22), "gpr_compare": cr("GPR", 25, 35),
              "dashboard": a1("Dashboard", 1, 6, n_dashboard_cols, 5 + n)})
    return L


_RANGE_RE = re.compile(r"^(?:'(?P<qt>[^']+)'|(?P<t>[^'!]+))!(?P<c1>[A-Z]{1,3})(?P<r1>\d+)(?::(?P<c2>[A-Z]{1,3})(?P<r2>\d+))?$")


def parse_a1(rng: str) -> tuple[str, int, int, int, int]:
    """'Tab'!E5:V37 -> (tab, row1, col1, row2, col2), 1-based inclusive."""
    m = _RANGE_RE.match(rng)
    if not m:
        raise ValueError(f"not an A1 range: {rng!r}")
    c1, r1 = col_number(m["c1"]), int(m["r1"])
    c2, r2 = (col_number(m["c2"]), int(m["r2"])) if m["c2"] else (c1, r1)
    return m["qt"] or m["t"], r1, c1, r2, c2


def plan_problems(plan: list[dict], max_cols: int = SHEETS_MAX_COLS) -> list[str]:
    """Layout check of any plan: values fit inside their range, no column past the Sheets limit, and no two blocks
    on the same tab share a cell. Returns readable problems (empty = fine)."""
    out, seen = [], {}
    for b in plan:
        try:
            tab, r1, c1, r2, c2 = parse_a1(b["range"])
        except ValueError as e:
            out.append(str(e)); continue
        if r2 < r1 or c2 < c1:
            out.append(f"{b['range']}: reversed range")
        if c2 > max_cols:
            out.append(f"{b['range']}: column {c2} past the Sheets limit {max_cols}")
        vals = b["values"]; width = max((len(r) for r in vals), default=0)
        if len(vals) > r2 - r1 + 1 or width > c2 - c1 + 1:
            out.append(f"{b['range']}: {len(vals)}x{width} values do not fit")
        for other, (o1, oc1, o2, oc2) in seen.get(tab, []):
            if r1 <= o2 and o1 <= r2 and c1 <= oc2 and oc1 <= c2:
                out.append(f"{b['range']} overlaps {other}")
        seen.setdefault(tab, []).append((b["range"], (r1, c1, r2, c2)))
    return out


def _rows(df: pd.DataFrame) -> list[list]:
    return [[_v(x) for x in row] for row in df.to_numpy().tolist()]


def _block(rng: str, values) -> dict:
    """One plan block; text cells are escaped against formula injection (EQ-C-0007)."""
    return {"range": rng, "values": [[safe_cell(x) for x in row] for row in values]}


def build_plan(result, u, settings, history: pd.DataFrame | None = None, stamp: str | None = None, mc_rows: int = 2000,
               ideas: dict | None = None, rv: dict | None = None) -> list[dict]:
    """The workbook plan. `ideas` (ideas_view.ideas_summary, opt-in with `publish --ideas`) appends the additive
    'Trade Ideas' tab after every v1/v2 block, so without it the plan is unchanged. `rv` (rv_view.rv_summary, opt-in
    with `publish --rv`, EQ-C-0046) appends the additive 'Weekly RV' tab after that."""
    from ..scorecard.scoring import stress_inputs
    stamp = stamp or date.today().isoformat()
    names = u.names; sc = result.scorecard; c = result.country; P = []
    note = f"Values written by the EconQuest Python engine on {stamp} (run {result.run_id}). Model formulas were replaced; rerun `python -m econquest publish` after changing inputs."
    ind_ids = list(u.indicators["id"])
    stress_ids = set(u.rulebook.loc[u.rulebook["stress_path"].astype(str).str.upper() == "Y", "id"])
    reg = result.mc.region_order or []
    L = layout_v2(len(names), n_indicators=len(ind_ids), row_410=ind_ids.index("4.10") + 5 if "4.10" in ind_ids else 45,
                  n_regions=len(reg), n_playbook=len(u.playbook) if u.playbook is not None else 26,
                  n_dashboard_cols=1 + len(result.dashboard.columns) if result.dashboard is not None else 22, mc_rows=mc_rows)

    # Inputs: indicator 4.10 final level from GPR
    if result.gpr_country is not None:
        P.append(_block(L["inputs_410"], [[float(result.gpr_country.at[n, "final_410"]) for n in names]]))

    # Stress Inputs: stressed values on stress-path rows, helper rows 90-92
    st = stress_inputs(u, settings).set_index("id")
    sp = settings["stress_path"]; prof = u.countries.set_index("country")
    rows = []
    for iid in ind_ids:
        rows.append([float(st.at[iid, n]) if iid in stress_ids else "" for n in names])
    P.append(_block(L["stress_inputs"], rows))
    dep = [float(prof.at[n, "stress_depreciation"]) for n in names]
    exp_shock = [abs({"Commodity": sp["commodity_shock"], "Tourism": sp["tourism_shock"]}.get(prof.at[n, "exptype"], sp["manufacturing_shock"])) / 100 * float(prof.at[n, "exports"]) * float(u.indicators.set_index("id").at["2.11", n]) / 100 for n in names]
    P.append(_block(L["stress_helpers"], [dep, exp_shock, [sp["growth_shock"]] * len(names)]))
    P.append(_block("'Stress Inputs'!A2", [[note]]))

    # Scores
    P.append(_block(L["base_scores"], _rows(sc.base_scores.loc[ind_ids])))
    P.append(_block(L["stress_scores"], [[_v(sc.stress_scores.at[iid, n]) if iid in stress_ids else "" for n in names] for iid in ind_ids]))
    P.append(_block(L["indicator_scores"], _rows(sc.indicator_scores.loc[ind_ids])))
    for tab in ("Base Scores", "Stress Scores", "Indicator Scores"):
        P.append(_block(f"'{tab}'!A2", [[note]]))

    # Adjustments: capped triggers and floors
    P.append(_block(L["adj_triggers"], _rows(sc.triggers)))
    P.append(_block(L["adj_floors"], _rows(sc.floors)))

    # Pillar Scores
    P.append(_block(L["pillar_wavg"], _rows(sc.pillar_wavg)))
    P.append(_block(L["pillar_worst"], _rows(sc.pillar_worst)))
    P.append(_block(L["pillar_aggregated"], _rows(sc.pillar_aggregated)))
    P.append(_block(L["pillar_final"], _rows(sc.pillar_final)))
    P.append(_block(L["pillar_weights"], [[int(sc.small_state[n]) for n in names]] + _rows(sc.weights)))
    P.append(_block(L["pillar_composite"], [[float(sc.composite[n]) for n in names], [int(sc.grade[n]) for n in names]]))
    P.append(_block("'Pillar Scores'!A2", [[note]]))

    # Risk Engine rows 5-37
    re_rows = [
        c["composite"], c["grade"], c["regime"], c["regime"], c["pd_mult"], c["lgd_mult"], c["rating"], c["pd_model_l1"], c["spread_bps"], c["pd_market"],
        c["z_tsi"], c["score_dev"], c["logodds_post"], c["pd_final"], c["pd_default"], c["pd_default"] / c["pd_market"],
        c["drv_tc"], c["drv_ex"], c["drv_pv"], c["drv_sa"], c["pd_tc"], c["pd_ex"], c["pd_pv"], c["pd_sa"], c["pd_any"], c["el_default"],
        c["pm_default"], c["pm_gap_pp"], c["pd_model"], c["tau_market"], c["pd_hazard_l1"], c["pd_rating"], c["DD"]]
    P.append(_block(L["risk_engine"], [[_v(x) for x in s.loc[names].tolist()] for s in re_rows]))
    P.append(_block("'Risk Engine'!A12:D12", [["R8", "pd_prior", "Layer 1 prior: hazard model reconciled with the rating-implied PD", "probability"]]))
    P.append(_block("'Risk Engine'!A35:D37", [["R31", "pd_hazard", "Layer 1 hazard model PD (before reconciliation)", "probability"],
                                              ["R32", "pd_rating", "Rating-implied PD (challenger)", "probability"],
                                              ["R33", "merton_dd", "Merton distance to distress (layer 4)", "sigma"]]))
    P.append(_block("'Risk Engine'!A2", [[note + " Default PD follows the paper: layer 1 hazard prior, layer 2 log-odds update with the scorecard, market and text signals, prediction-market blend, layer 3 transition-weighted regime multiplier."]]))

    # Signals, Trade Activation
    if result.signals is not None:
        P.append(_block(L["signals"], _rows(result.signals.loc[list(range(1, 26))])))
        n26 = (" Signal 26 (Debt above IMF benchmark, DSA) is a display-only benchmark test, not a default-risk signal; it is "
               "in the country notes and not on this tab (rows 5-29 are the 25 signals, contract C11)."
               if 26 in result.signals.index else "")                  # EQ-B-0080, HO-20261024-B-C-015
        P.append(_block("Signals!A2", [[note + n26]]))
        pb = u.playbook
        P.append(_block(L["trade_labels"], [[t["id"], t["strategy"], int(t["key"]), t["stance"]] for _, t in pb.iterrows()]))
        P.append(_block(L["trade_activation"], _rows(result.activation.loc[list(pb["id"])])))
        P.append(_block("'Trade Activation'!A2", [[note]]))

    # Portfolio VaR
    pos = result.positions; con = result.mc.contributions; m = result.metrics
    rows = []
    for pid in list(u.portfolio["id"]):
        if pid not in pos.index:
            rows.append([""] * 18); continue
        p = pos.loc[pid]; cn = p["country"]
        rows.append([names.index(cn) + 1, p["sign"], p["regime"], c.at[cn, "rating"], c.at[cn, "spread_bps"], p["pd_default"], p["pd_tc"], p["pd_ex"], p["pd_pv"],
                     p["market_vol_pct"], p["thrA"] if np.isfinite(p["thrA"]) else "none", p["lossA_pct"], p["thrB"] if np.isfinite(p["thrB"]) else "none", p["lossB_pct"],
                     p["carry_mm"], con.at[pid, "expected_loss_mm"], con.at[pid, "tail_contribution_99_mm"], con.at[pid, "share_of_es99"]])
    rows += [[""] * 18] * (30 - len(rows))
    P.append(_block("'Portfolio VaR'!H5:Y34", rows))
    P.append(_block("'Portfolio VaR'!AB5:AB34", [[con.at[pid, "liquidity_cost_99_mm"]] if pid in con.index else [""] for pid in list(u.portfolio["id"])] + [[""]] * (30 - len(u.portfolio))))
    P.append(_block("'Portfolio VaR'!E37:E46", [[m["gross_notional_mm"]], [m["net_notional_mm"]], [float(con["expected_loss_mm"].sum())], [m["expected_loss_mm"]], [m["var95_mm"]], [m["var99_mm"]], [m["es95_mm"]], [m["es99_mm"]], [m["es99_share_of_gross"]], [m["paths"]]]))
    P.append(_block("'Portfolio VaR'!I37:I40", [[m["liquidity_cost99_mm"]], [m["lvar99_mm"]], [m["les99_mm"]], [m["liquidity_cost99_mm"] / m["var99_mm"] if m["var99_mm"] else 0]]))
    P.append(_block("'Portfolio VaR'!C47:E47", [["Expected shortfall 97.5% (FRTB)", "$mm", m["es975_frtb_mm"]]]))
    # Sovereign risk by holding (rows 50-67) and by asset class (rows 70-74)
    gross = m["gross_notional_mm"]; es99 = m["es99_mm"]
    hold = []
    for cn in names:
        pc = pos[pos["country"] == cn]
        g = float(pc["notional_mm"].sum()); netl = float((pc["notional_mm"] * pc["sign"]).sum())
        el = float(con.loc[pc.index, "expected_loss_mm"].sum()) if len(pc) else 0.0
        tail = float(con.loc[pc.index, "tail_contribution_99_mm"].sum()) if len(pc) else 0.0
        sg = g / gross if gross else 0.0; se = tail / es99 if es99 else 0.0
        if g == 0: read = "No holding"
        elif tail < 0: read = "Short or hedge: gains in the tail"
        elif se > 1.5 * sg: read = "Tail risk outweighs holding size"
        elif se < 0.5 * sg: read = "Holding larger than its tail risk"
        else: read = "In proportion"
        hold.append([cn, c.at[cn, "composite"], c.at[cn, "regime"], c.at[cn, "rating"], c.at[cn, "pd_default"], g, netl, el, tail, sg, se, int(len(pc)), read])
    P.append(_block(L["pv_holdings"], hold))
    acls = []
    for ac in ASSET_CLASSES:
        pc = pos[pos["asset_class"] == ac]
        tail = float(con.loc[pc.index, "tail_contribution_99_mm"].sum()) if len(pc) else 0.0
        acls.append([float(pc["notional_mm"].sum()), float(con.loc[pc.index, "expected_loss_mm"].sum()) if len(pc) else 0.0, tail, tail / es99 if es99 else 0.0, int(len(pc))])
    if "pv_asset_class_head" in L:            # v2, n > 18: the table moved below the holdings; write its own labels
        P.append(_block(L["pv_asset_class_head"], [["Asset class", "Gross notional $mm", "Expected loss $mm", "Tail contribution 99% $mm", "Share of ES99", "Positions"]]))
        P.append(_block(L["pv_asset_class_labels"], [[a] for a in ASSET_CLASSES]))
    P.append(_block(L["pv_asset_class"], acls))
    P.append(_block("'Portfolio VaR'!A2", [[note + f" {m['paths']:,} Sobol paths, Student-t copula with {result.mc.df:.0f} degrees of freedom; the MC tab shows the first {mc_rows:,} paths."]]))

    # MC tab: parameters and the first mc_rows paths (2,000 by default; 100 when written cell by cell through the Sheets connector)
    mc = result.mc; k = min(len(mc.sample["global"]), mc_rows)
    pos_by_country = {}
    for _, p in pos.iterrows():
        pos_by_country.setdefault(p["country"], p)
    loads = result.diagnostics.get("loadings")
    P.append(_block(L["mc_params"], [[float(c.at[n, "pd_default"]) for n in names], [c.at[n, "region"] for n in names],
                                 [float(pos_by_country[n]["thrA"]) if n in pos_by_country and np.isfinite(pos_by_country[n]["thrA"]) else "" for n in names],
                                 [float(loads[n]) if loads else "" for n in names]]))
    factor_cols = [[i + 1, float(mc.sample["global"][i])] + [float(mc.sample["regional"][i, j]) for j in range(len(reg))] + [float(mc.sample["chi2"][i])] + [float(x) for x in mc.latent[i]] for i in range(k)]
    _, _, _, _, lat1 = parse_a1(L["mc_factors"]); _, _, loss0, _, loss1 = parse_a1(L["mc_losses"])
    P.append(_block(L["mc_factors"], factor_cols + [[""] * lat1] * (mc_rows - k)))
    pl = mc.position_losses[:k]
    loss_rows = [[float(x) for x in pl[i]] + [""] * (30 - pl.shape[1]) + [float(mc.losses[i])] for i in range(k)]
    P.append(_block(L["mc_losses"], loss_rows + [[""] * 31] * (mc_rows - k)))
    P.append(_block("MC!A1:A2", [[f"MC: first {k:,} of {mc.paths:,} Monte Carlo paths from the Python engine (scrambled Sobol, seed {settings.seed})"],
                                  [note + f" Columns {col_letter(4 + len(reg))}:{col_letter(lat1)} hold each country's latent t variable per path; {col_letter(loss0)}:{col_letter(loss1 - 1)} the loss of each Portfolio VaR position; {col_letter(loss1)} the portfolio loss. Portfolio VaR results use all paths."]]))

    # Prediction Markets
    arb = result.arbitrage.set_index("id") if len(result.arbitrage) else None
    rows = []
    for _, r in u.markets.iterrows():
        a = arb.loc[r["id"]] if arb is not None and r["id"] in arb.index else None
        if a is None:
            rows.append([""] * 16); continue
        src = "Risk Engine" if r["driver"] in ("Sovereign default", "Sanctions") else "Scorecard"
        rows.append([a["months"], names.index(a["country"]) + 1, src, a["model_p12"], a["model_p12"], a["model_p_res"], a["side"], a["net_edge_pp"], a["ev_per_dollar"], a["kelly"],
                     a["stake_k"], a["expected_profit_k"], a["model_minus_market_pp"], a["related_trade"] if isinstance(a["related_trade"], str) else "", a["read"],
                     (1 - (1 - min(0.99, max(0.01, a["yes_price"]))) ** (12 / a["months"])) if r["driver"] == "Sovereign default" else ""])
    rows += [[""] * 16] * (30 - len(rows))
    P.append(_block("'Prediction Markets'!I5:X34", rows))
    cb = []
    for n in names:
        a = result.arbitrage[result.arbitrage["country"] == n] if len(result.arbitrage) else pd.DataFrame()
        cnt = int(len(a)); best = a.loc[a["net_edge_pp"].idxmax()] if cnt else None
        sig = float(result.signals.at[25, n]) if result.signals is not None else ""
        read = "No contract on this country" if cnt == 0 else ("Market and model agree within costs" if best["net_edge_pp"] < settings["prediction_markets"]["min_net_edge_pp"]
                                                                   else ("Model sees more risk than the market" if best["side"] == "Buy Yes" else "Market sees more risk than the model"))
        cb.append([n, cnt, c.at[n, "pm_default"], c.at[n, "pd_model"], c.at[n, "pm_gap_pp"], best["net_edge_pp"] if cnt else "", best.name if cnt else "", best["side"] if cnt else "",
                   best["stake_k"] if cnt else "", sig, read, float(c.at[n, "tau_market"]) * settings["prediction_markets"]["reference_oi_k"] / settings["prediction_markets"]["tau_market_max"] if c.at[n, "tau_market"] else 0, c.at[n, "tau_market"]])
    P.append(_block(L["pm_countries"], cb))
    P.append(_block("'Prediction Markets'!A2", [[note]]))

    # GPR tab
    if result.gpr_country is not None:
        g = result.gpr_country; gg = result.gpr_global
        P.append(_block(L["gpr_levels"], [[g.at[n, "series"] for n in names], ["Yes" if g.at[n, "covered"] else "No" for n in names], [gg["latest_month"]] * len(names),
                                        *[[_v(g.at[n, k]) for n in names] for k in ("recent", "mean5y", "sd5y", "z", "percentile", "momentum")]]))
        P.append(_block(L["gpr_signal"], [[int(g.at[n, "uplift"]) for n in names], [float(g.at[n, "final_410"]) for n in names], [float(g.at[n, "signal"]) for n in names],
                                         [gg["recent"]] * len(names), [gg["percentile"]] * len(names), [gg["z"]] * len(names), [gg["threats_acts_ratio"]] * len(names), [gg["signal"]] * len(names)]))
        d = result.dashboard
        comp_rank = c["composite"].rank(ascending=False, method="min")
        sig_rank = g.loc[g["covered"], "signal"].rank(ascending=False, method="min")
        P.append(_block(L["gpr_compare"], [[round(float(c.at[n, "composite"]), 0) for n in names], [int(c.at[n, "grade"]) for n in names], [float(sc.pillar_final.at[4, n]) for n in names],
                                         [float(sc.indicator_scores.at["4.10", n]) for n in names], [float(g.at[n, "signal"]) for n in names],
                                         [_v(g.at[n, "percentile"]) if g.at[n, "covered"] else "" for n in names],
                                         [_v(d.at[n, "gpr_gap"]) for n in names],
                                         [float(g.at[n, "signal"]) - float(sc.indicator_scores.at["4.10", n]) if g.at[n, "covered"] else "" for n in names],
                                         [int(comp_rank[n]) for n in names], [int(sig_rank[n]) if n in sig_rank.index else "" for n in names],
                                         [d.at[n, "gpr_read"] for n in names]]))
        P.append(_block("GPR!A2", [[note + " Analyst levels on row 14 and the monthly data from row 41 are inputs."]]))

    # Dashboard
    if result.dashboard is not None:
        d = result.dashboard
        hi, lo = d["composite"].idxmax(), d["composite"].idxmin()
        P.append(_block("Dashboard!A2:A3", [[f"Highest composite risk: {hi} ({d.at[hi, 'composite']:.1f}). Lowest: {lo} ({d.at[lo, 'composite']:.1f}). Countries in the crisis regime: {int((d['regime'] == 'Crisis').sum())} of {len(d)}."],
                                             [f"Sample book: ${m['gross_notional_mm']:,.0f}mm exposure, expected loss ${m['expected_loss_mm']:.1f}mm, 99% VaR ${m['var99_mm']:.1f}mm, 99% expected shortfall ${m['es99_mm']:.1f}mm, 97.5% ES (FRTB) ${m['es975_frtb_mm']:.1f}mm, L-VaR 99% ${m['lvar99_mm']:.1f}mm. Scenario override: {settings.scenario_override}. Calculated in Python on {stamp}."]]))
        P.append(_block(L["dashboard"], [[n] + [_v(x) for x in d.loc[n].tolist()] for n in names]))

    # Backtesting
    if history is not None and len(history):
        bt = backtest_history(history, alpha=settings.get("backtest", "confidence", default=0.99))
        k_, ch, z = bt["kupiec"], bt["christoffersen"], bt["acerbi_szekely"]
        conf = bt["alpha"]; per = k_["exceedances"] * 250 / k_["n"]
        zone = "Basel green zone" if per < 5 else ("Basel yellow zone" if per < 10 else "Basel red zone")
        P.append(_block("Backtesting!G5:I12", [
            [k_["exceedances"], k_["expected"], f"{zone} ({per:.1f} exceedances per 250 periods)"],
            [k_["LR_uc"], k_["p_value"], ("Pass: exceedance rate consistent with " if k_["p_value"] >= 0.05 else "Fail: too many exceedances for " if k_["exceedances"] > k_["expected"] else "Fail: too few exceedances for ") + f"{(1-conf)*100:.1f}%"],
            [ch["LR_ind"], ch["p_value_ind"], "Pass: exceedances are not clustered in time" if ch["p_value_ind"] >= 0.05 else "Fail: exceedances cluster in time"],
            [ch["LR_cc"], ch["p_value_cc"], "Pass: coverage and independence hold jointly" if ch["p_value_cc"] >= 0.05 else "Fail: coverage and independence rejected jointly"],
            [z["Z2"], f"Critical {z['critical']:.2f} one-sided at 5%; within [-1.96, 1.96]: {'yes' if abs(z['Z2']) <= 1.96 else 'no'}", "Pass: losses beyond VaR are in line with the ES forecast" if z["pass"] else "Fail: losses beyond VaR run larger than the ES forecast"],
            [f"{ch['n00']} / {ch['n01']} / {ch['n10']} / {ch['n11']}", "", ""],
            [z["es_ratio"], "1.00 means the ES forecast is right on average", "ES forecast covers the realized tail" if z["es_ratio"] <= 1 else f"Realized tail is {(z['es_ratio']-1)*100:.0f}% above the ES forecast"],
            ["", "", "Model passes all three tests" if bt["verdict"] == "Pass" else "Model fails: " + ", ".join(t for t, ok in (("Kupiec", k_["p_value"] >= 0.05), ("Christoffersen", ch["p_value_cc"] >= 0.05), ("Acerbi-Szekely", z["pass"])) if not ok)]]))
        losses = history["loss"].to_numpy(dtype=float); var = history["var"].to_numpy(dtype=float); es = history["es"].to_numpy(dtype=float)
        exc = (losses > var).astype(int)
        rows = []
        for i in range(len(losses)):
            rows.append([i + 1, "", "", "", "", var[i], es[i], int(exc[i]), f"{exc[i-1]}{exc[i]}" if i > 0 else "", float(exc[i] * losses[i] / es[i]), float(losses[i] / var[i])])
        # only the computed columns: A (period), F:K
        P.append(_block(f"Backtesting!F17:K{16 + len(rows)}", [r[5:] for r in rows]))
        P.append(_block(f"Backtesting!A17:A{16 + len(rows)}", [[r[0]] for r in rows]))
        P.append(_block("Backtesting!B12", [[len(rows)]]))
        P.append(_block("Backtesting!B9:B10", [[var[0]], [es[0]]]))

    # Trade Ideas (EQ-C-0047): additive tab, last so no existing range moves
    if ideas is not None:
        P += ideas_plan(ideas, stamp=stamp)
    # Weekly RV (EQ-C-0046): additive tab, after Trade Ideas so neither moves
    if rv is not None:
        P += rv_plan(rv, stamp=stamp)
    return P


# Trade Ideas tab (EQ-C-0047, GOV-032): an additive tab, columns A:G only (inside a new tab's A:Z), so no C11 anchor and no
# layout_v2 block is touched. Notes A1:A3; the quarterly table starts at A5 (header) and grows down one row per quarter,
# with the "All quarters" total as its last row: A5:G(6+Q) for Q quarters, A5:G6 (header + one message row) when empty.
IDEAS_TAB = "'Trade Ideas'"


def ideas_layout(n_quarters: int) -> dict[str, str]:
    """Ranges of the Trade Ideas tab for a log spanning n_quarters quarters."""
    return {"ideas_notes": a1(IDEAS_TAB, 1, 1, 1, 3), "ideas_table": a1(IDEAS_TAB, 1, 5, 7, 6 + max(0, int(n_quarters)))}


def ideas_plan(summary: dict, stamp: str | None = None) -> list[dict]:
    """Plan blocks of the Trade Ideas tab from ideas_view.ideas_summary(out_dir). Hit rate is a fraction (0.62 = 62%),
    P&L in $mm; an empty or missing log writes the header and one message row. Text cells go through _block
    (formula-escaped); values come from the log via Team B's idea_report, never from the escaped idea_report.csv."""
    from .ideas_view import COLUMNS, HEADER
    stamp = stamp or date.today().isoformat()
    qs = list(summary.get("quarters") or [])
    L = ideas_layout(len(qs))
    status = str(summary.get("status") or "missing")
    tail = (f" Open ideas at their latest mark: P&L {summary['pnl_open_mm']:.2f} $mm; all ideas {summary['pnl_total_mm']:.2f} $mm."
            if summary.get("pnl_open_mm") is not None and summary.get("pnl_total_mm") is not None else "")
    notes = [[f"Trade-idea ledger by quarter. {summary.get('label') or 'Illustrative, Tier 3 (GOV-032).'}"],
             [f"[{status.upper()}] {summary.get('message') or ''}" + (f" Newest ideas opened by run {summary['run_id']} (the latest model run can be newer)."
                                                                       if summary.get("run_id") else "")],
             [f"Written by the EconQuest Python engine on {stamp} from outputs/{summary.get('file') or 'idea_log.csv'}.{tail}"]]
    if qs:
        body = [[r.get(c) for c in COLUMNS] for r in qs] + [[(summary.get("total") or {}).get(c) for c in COLUMNS]]
    else:
        body = [[summary.get("message") or "No trade ideas yet.", "", "", "", "", "", ""]]
    return [_block(L["ideas_notes"], notes), _block(L["ideas_table"], [HEADER] + body)]


# Weekly RV tab (EQ-C-0046, HO-20261023-B-C-014): an additive tab, so no C11 anchor and no layout_v2 block is touched.
# Notes A1:A4. Bond RV table (outputs/bond_rv.csv): header row 6, one row per country, A6:R(6+C) (A6:R7 with the status
# message when there are no rows). CDS curve table (outputs/cds_curves.csv): header row 6, one row per curve point,
# T6:AN(6+K) (T6:AN7 with "No CDS curves" when the file is missing or empty). Both grow down only; column S is a gap.
# AN is column 40: the tab must be widened past a new tab's A:Z before the first `publish --rv` (ADR-C-001 item 8).
RV_TAB = "'Weekly RV'"
RV_TABLE_COL0, CURVE_TABLE_COL0, RV_HEAD_ROW = 1, 20, 6


def rv_layout(n_rows: int, n_points: int) -> dict[str, str]:
    """Ranges of the Weekly RV tab for n_rows bond RV rows and n_points curve points (0 = message row)."""
    from .rv_view import CURVE_SHEET_COLS, RV_SHEET_COLS
    r, k = max(1, int(n_rows)), max(1, int(n_points))
    return {"rv_notes": a1(RV_TAB, 1, 1, 1, 4),
            "rv_table": a1(RV_TAB, RV_TABLE_COL0, RV_HEAD_ROW, RV_TABLE_COL0 + len(RV_SHEET_COLS) - 1, RV_HEAD_ROW + r),
            "rv_curves": a1(RV_TAB, CURVE_TABLE_COL0, RV_HEAD_ROW, CURVE_TABLE_COL0 + len(CURVE_SHEET_COLS) - 1, RV_HEAD_ROW + k)}


def rv_plan(summary: dict, stamp: str | None = None) -> list[dict]:
    """Plan blocks of the Weekly RV tab from rv_view.rv_summary(out_dir). Spreads, gaps, EL and premium in bp; pd_12m, lgd,
    survival, cum_pd, fwd_pd and recovery as fractions (0.01 = 1%; format the columns as %); hazards per year. z is blank
    for distressed rows. Every text cell (rv_read, market_source, flags, source, ...) goes through _block -> safe_cell."""
    from .rv_view import CURVE_SHEET_COLS, CURVE_SHEET_HEADER, RV_SHEET_COLS, RV_SHEET_HEADER
    stamp = stamp or date.today().isoformat()
    rv, cur = summary.get("rv") or {}, summary.get("curves") or {}
    rows, pts = list(rv.get("rows") or []), list(cur.get("rows") or [])
    L = rv_layout(len(rows), len(pts))
    syn = summary.get("synthetic_note") or ""
    flagged = "; ".join(f"{f.get('iso3')} {', '.join(f.get('flags') or [])}" for f in summary.get("flagged") or [])
    notes = [[f"Weekly relative value: bond rich/cheap vs model and CDS hazard curves. {summary.get('label') or ''}".strip()],
             [f"[{str(rv.get('status') or 'missing').upper()}] {rv.get('message') or ''} As of {summary.get('as_of') or 'not recorded'}."],
             [f"[{str(cur.get('status') or 'missing').upper()}] {cur.get('message') or ''}" + (f" Curve flags: {flagged}." if flagged else "")
              + (f" {syn}" if syn else "")],
             [f"Written by the EconQuest Python engine on {stamp} from outputs/{rv.get('file') or 'bond_rv.csv'} and outputs/"
              f"{cur.get('file') or 'cds_curves.csv'}. Gap = market - fair (bp, + = cheap vs model); z blank for distressed."]]
    rv_body = ([[r.get(c) for c in RV_SHEET_COLS] for r in rows] if rows
               else [[rv.get("message") or "No bond RV rows."] + [""] * (len(RV_SHEET_COLS) - 1)])
    cur_body = ([[p.get(c) for c in CURVE_SHEET_COLS] for p in pts] if pts
                else [[cur.get("message") or "No CDS curves."] + [""] * (len(CURVE_SHEET_COLS) - 1)])
    return [_block(L["rv_notes"], notes), _block(L["rv_table"], [RV_SHEET_HEADER] + rv_body),
            _block(L["rv_curves"], [CURVE_SHEET_HEADER] + cur_body)]


def full_plan(result, u, settings, data_dir, out_dir, *, mc_rows: int = 2000, ideas: bool = False, rv: bool = False,
              garch: bool = True, econ: bool = True, stamp: str | None = None) -> list[dict]:
    """Every block `econquest publish` writes for one run: build_plan, then the GARCH and Econometrics tabs when price
    history exists. The one plan behind the Sheets publish and the local xlsx export (EQ-C-0122), so both show the same
    tabs and cells. The caller runs publish_guard first. SimulatedDataError (EQ-C-0146) when the country table or the
    CDS curve rows carry a SIMULATED value (Team A's vendor simulator, HO-20261026-A-C-003)."""
    from ..ops.vendor_rehearse import refuse_simulated
    refuse_simulated(getattr(result, "country", None), "Sheets publish (full_plan)")
    hist_path = Path(data_dir) / "backtest_history.csv"
    hist = pd.read_csv(hist_path) if hist_path.exists() else None
    ideas_s = rv_s = None
    if ideas:                                             # opt-in: the 'Trade Ideas' tab must exist in the workbook (EQ-C-0047)
        from .ideas_view import ideas_summary
        ideas_s = ideas_summary(Path(out_dir))
    if rv:                                                # opt-in: the 'Weekly RV' tab must exist, widened to AN (EQ-C-0046)
        from .rv_view import rv_summary
        rv_s = rv_summary(Path(out_dir))
        refuse_simulated(pd.DataFrame(rv_s["curves"].get("rows") or []), "Sheets publish (full_plan, CDS curves)")
    plan = build_plan(result, u, settings, hist, stamp=stamp, mc_rows=mc_rows, ideas=ideas_s, rv=rv_s)
    from ..engine.garch import load_prices, run_garch
    px = load_prices(data_dir)
    if px is not None and garch:
        from .garch_publish import garch_plan
        g = run_garch(u, px, settings, u.gpr)
        plan += garch_plan(g, u)
        if econ:
            from ..engine.econometrics import run_econometrics
            from .econ_publish import econ_plan
            from ..scorecard import score_universe
            plan += econ_plan(run_econometrics(u, px, g, settings, u.gpr, score_universe(u, settings).composite, log=lambda *a: None))[0]
    return plan


def save_plan(plan: list[dict], path: str | Path) -> None:
    """Saved plans are escaped too: other Sheets clients apply them with USER_ENTERED."""
    Path(path).write_text(json.dumps(sanitize_plan(plan), indent=0))


def apply_plan(plan: list[dict], spreadsheet_id: str, token: str) -> dict:
    """Sheets v4 values:batchUpdate with USER_ENTERED parsing (dates and numbers typed as a user would).

    Every plan is sanitized here, whichever module built it (audit, benchmarks, dsa, record...), so a text
    cell starting with = + - @ tab or CR is written as text, never evaluated as a formula."""
    if not SHEET_ID_RE.fullmatch(str(spreadsheet_id)):   # the id is spliced into the URL path: no '/', '?', '#', '..'
        raise ValueError("spreadsheet id must be letters, digits, '-' or '_'")
    url = f"{SHEETS_API}/{spreadsheet_id}/values:batchUpdate"
    body = json.dumps({"valueInputOption": "USER_ENTERED", "data": [{"range": b["range"], "values": b["values"]} for b in sanitize_plan(plan)]}).encode()
    req = urllib.request.Request(url, data=body, method="POST", headers={"Content-Type": "application/json"})
    req.add_unredirected_header("Authorization", f"Bearer {token}")   # urllib copies normal headers to any redirect target
    # Scheme and host are the fixed https constant SHEETS_API and the id is validated above, so B310 (file:/ or custom
    # schemes reaching urlopen) cannot apply. Triage: team/security SEC-C (AGENT-09, EQ-C-0007).
    with urllib.request.urlopen(req, timeout=120) as r:  # nosec B310
        return json.loads(r.read().decode())
