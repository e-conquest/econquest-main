"""Monte Carlo error bands next to VaR99, ES99 and L-VaR99 and the book-limit verdicts (HO-20261023-B-C-016, EQ-C-0055).

Team B's layer 6 (`engine/layer6_montecarlo.mc_error`, VF-004) stores on every run, in $mm: var99_se_mm, es99_se_mm,
lvar99_se_mm and the 95% bands <measure>_ci95_lo_mm / _ci95_hi_mm. This module only formats them. A book-limit
verdict (data/limits.json "book", status from the point estimate exactly as engine/limits.check_book: breach at or
above the limit, warning at or above warning_level x limit) is flagged "within MC error" when the 95% band contains
the warning level or the limit: the verdict could flip on a rerun with another seed or path count. Runs archived
before EQ-B-0054 carry no band; they show none and are never flagged.
"""
from __future__ import annotations

import math
from pathlib import Path

BAND_MEASURES = ("var99_mm", "es99_mm", "lvar99_mm")
BOOK_MEASURES = (("var99_mm", "VaR 99%"), ("es99_mm", "ES 99%"), ("lvar99_mm", "L-VaR 99%"), ("expected_loss_mm", "Expected loss"))


def _num(v) -> float | None:
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    return x if math.isfinite(x) else None


def band(metrics: dict, key: str) -> tuple[float, float] | None:
    """(lo, hi) of the 95% Monte Carlo band of `key` (e.g. "lvar99_mm"), or None when the run has none."""
    if not key.endswith("_mm"):
        return None
    stem = key[:-3]
    lo, hi = _num((metrics or {}).get(f"{stem}_ci95_lo_mm")), _num((metrics or {}).get(f"{stem}_ci95_hi_mm"))
    return (lo, hi) if lo is not None and hi is not None else None


def band_text(metrics: dict, key: str, d: int = 2) -> str:
    """'78.82-80.45' (the 95% MC band, $mm), or '' when the run has none."""
    b = band(metrics, key)
    return f"{b[0]:,.{d}f}-{b[1]:,.{d}f}" if b else ""


def load_book_limits(data_dir) -> dict | None:
    """data/limits.json through engine.limits.load_limits, or None when it is missing or unreadable (the products
    then show no limit table rather than fail)."""
    p = Path(data_dir) / "limits.json"
    if not p.exists():
        return None
    try:
        from ..engine.limits import load_limits
        return load_limits(p)
    except (OSError, ValueError):
        return None


def book_limit_verdicts(metrics: dict, limits: dict | None) -> list[dict]:
    """One row per book limit in `limits` (load_book_limits) for VaR99, ES99, L-VaR99 and expected loss: measure,
    label, value, band_lo, band_hi, limit, warning_mm, utilisation, status (pass / warning / breach), within_mc_error
    (bool), mc_levels ('warning level 80.00', the levels inside the band) and mc_note (the sentence; '' when none)."""
    if not limits:
        return []
    wl = float(limits.get("warning_level", 0.8))
    book = limits.get("book") or {}
    rows = []
    for key, label in BOOK_MEASURES:
        v, lim = _num((metrics or {}).get(key)), _num(book.get(key))
        if v is None or lim is None:
            continue
        util = (math.inf if v > 0 else 0.0) if lim <= 0 else v / lim
        status = "breach" if util >= 1.0 else "warning" if util >= wl else "pass"
        b = band(metrics, key)
        warn = wl * lim
        hits = [f"{name} {lvl:,.2f}" for name, lvl in (("warning level", warn), ("limit", lim)) if b and b[0] <= lvl <= b[1]]
        rows.append({"measure": key, "label": label, "value": v, "band_lo": b[0] if b else None, "band_hi": b[1] if b else None,
                     "limit": lim, "warning_mm": warn, "utilisation": util, "status": status, "within_mc_error": bool(hits),
                     "mc_levels": " and ".join(hits),
                     "mc_note": (f"within MC error of the {' and the '.join(hits)} (95% band {band_text(metrics, key)})" if hits else "")})
    return rows


def headline_band(metrics: dict, key: str) -> str:
    """' (95% MC band 78.82-80.45)' for a terminal line, or ''."""
    t = band_text(metrics, key)
    return f" (95% MC band {t})" if t else ""


def _row_band(r: dict) -> str:
    return "" if r["band_lo"] is None else f"{r['band_lo']:,.2f}-{r['band_hi']:,.2f}"


def _row_flag(r: dict) -> str:
    """'within MC error of the warning level 80.00 (95% band 78.82-80.45)' or ''."""
    return r["mc_note"] if r["within_mc_error"] else ""


def limits_html(rows: list[dict], esc) -> str:
    """The book-limit table with the band and the within-MC-error flag; `esc` is the caller's HTML escape."""
    if not rows:
        return "<p class='empty'>No book limits (data/limits.json) to compare against.</p>"
    cls = {"pass": "pass", "breach": "fail"}
    body = "".join(
        f"<tr><td>{esc(r['label'])}</td><td class='n'>{r['value']:,.2f}</td><td class='n'>{_row_band(r)}</td>"
        f"<td class='n'>{r['warning_mm']:,.2f}</td><td class='n'>{r['limit']:,.2f}</td><td class='n'>{r['utilisation'] * 100:.1f}%</td>"
        f"<td class='{cls.get(r['status'], '')}'>{esc(r['status'])}</td><td>{'<b>' + esc(_row_flag(r)) + '</b>' if r['within_mc_error'] else ''}</td></tr>"
        for r in rows)
    return ("<table><tr><th>Book limit</th><th class='n'>Value $mm</th><th class='n'>95% MC band $mm</th><th class='n'>Warning $mm</th>"
            "<th class='n'>Limit $mm</th><th class='n'>Utilisation</th><th>Verdict</th><th>Monte Carlo error</th></tr>" + body + "</table>"
            "<p class='note'>Verdicts use the point estimate against data/limits.json, as `econquest limits`. A verdict is within MC error when "
            "the 95% Monte Carlo band (batch means, engine VF-004) contains the warning level or the limit, so a rerun could flip it.</p>")


def limits_md(rows: list[dict]) -> list[str]:
    if not rows:
        return ["No book limits (data/limits.json) to compare against."]
    L = ["| Book limit | Value $mm | 95% MC band $mm | Warning $mm | Limit $mm | Utilisation | Verdict | Monte Carlo error |",
         "|---|---:|---:|---:|---:|---:|---|---|"]
    for r in rows:
        L.append(f"| {r['label']} | {r['value']:,.2f} | {_row_band(r)} | {r['warning_mm']:,.2f} | {r['limit']:,.2f} | {r['utilisation'] * 100:.1f}% | "
                 f"{r['status']} | {'**' + _row_flag(r) + '**' if r['within_mc_error'] else ''} |")
    return L
