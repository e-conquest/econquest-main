"""CLI for the research product line (EQ-C-0075), added by ops/commands.register:

    econquest weekly-brief --as-of D [--pdf] [--chrome BIN] [--dest DIR]   outputs/weekly-brief/weekly-brief-D.html (+ .json, .pdf)
    econquest calendar [--as-of D] [--json] [--strict]                      due and overdue research products; mode line
    econquest client-package ITEM --recipient ADDR --date D [--dest DIR]    OFF (client mode only; EQ-C-0082)

The research mode (internal by default; client only with Sam's approved change) is shown by `calendar` and stamped on
every product (research.py)."""
from __future__ import annotations

import datetime as dt
import json
import sys
from pathlib import Path


def _date(v: str) -> dt.date:
    import argparse
    from .research import parse_date
    try:
        return parse_date(v)
    except ValueError as e:
        raise argparse.ArgumentTypeError(str(e)) from None


def cmd_weekly_brief(args) -> None:
    from .weekly_brief import build_weekly_brief
    try:
        r = build_weekly_brief(args.out, args.data, args.dest or Path(args.out) / "weekly-brief", args.as_of, pdf=args.pdf, chrome=args.chrome)
    except FileNotFoundError as e:
        raise SystemExit(f"weekly-brief: {e}") from None
    it = r["items"][0]
    print(f"weekly brief {args.as_of}: {it['html']}" + (f"; PDF {it['pdf'] or it['pdf_status']}" if args.pdf else "")
          + f" (run {r['run_id']}, mode {r['research_mode']}). Register it with `econquest editorial draft --kind weekly_brief --file ...`.")


def cmd_calendar(args) -> None:
    from .research import ResearchConfigError, calendar_status, effective_mode, format_calendar
    as_of = args.as_of or dt.datetime.now(dt.timezone.utc).date()
    try:
        rows = calendar_status(args.data, args.out, as_of)
    except ResearchConfigError as e:
        raise SystemExit(f"calendar: {e}") from None
    state = effective_mode(args.data)
    if args.json:
        print(json.dumps({"as_of": as_of.isoformat(), "research_mode": state["mode"], "requested_mode": state["requested"],
                          "problems": state["problems"], "products": rows}, indent=1, default=str))
    else:
        print(f"Publication calendar as of {as_of}" + ("" if args.as_of else " (today, UTC)"))
        for line in format_calendar(rows, state):
            print(line)
    if args.strict and any(r["status"] == "overdue" for r in rows):
        sys.exit(1)


def cmd_client_package(args) -> None:
    from .client_package import ClientPackageError, package
    try:
        r = package(args.out, args.data, args.item, args.recipient, args.date, dest=args.dest)
    except ClientPackageError as e:
        raise SystemExit(f"client-package: {e}") from None
    print(f"{r['item_id']} for {r['recipient']} ({r['date']}): {len(r['files'])} watermarked file(s) -> {r['dir']}")


def register(sub) -> None:
    wb = sub.add_parser("weekly-brief", help="weekly macro, sovereign and geopolitical brief (HTML, PDF with --pdf) from stored runs only: "
                                             "PD and score movers, regime, VaR/ES vs limits, events, stress highlights, trade ideas with track record")
    wb.add_argument("--as-of", required=True, type=_date, help="YYYY-MM-DD: newest archived base run with a model date on or before it")
    wb.add_argument("--pdf", action="store_true", help="also print a PDF with a local Chrome/Chromium when one is found")
    wb.add_argument("--chrome", help="browser binary for --pdf (default: search; or $ECONQUEST_CHROME)")
    wb.add_argument("--dest", help="output folder (default: <out>/weekly-brief)")
    wb.set_defaults(fn=cmd_weekly_brief)
    ca = sub.add_parser("calendar", help="research publication calendar (data/publication_calendar.json): due and overdue products, "
                                         "and the research mode (internal unless Sam approved client mode)")
    ca.add_argument("--as-of", type=_date, help="YYYY-MM-DD (default: today, UTC)")
    ca.add_argument("--json", action="store_true", help="machine-readable rows (for the open-items view)")
    ca.add_argument("--strict", action="store_true", help="exit 1 when any product is overdue")
    ca.set_defaults(fn=cmd_calendar)
    cp = sub.add_parser("client-package", help="OFF until Sam approves client mode: watermarked copy of a published item for one "
                                               "entitled recipient; refused in internal mode and whenever the product holds IMF data")
    cp.add_argument("item"); cp.add_argument("--recipient", required=True); cp.add_argument("--date", required=True, type=_date)
    cp.add_argument("--dest"); cp.set_defaults(fn=cmd_client_package)
