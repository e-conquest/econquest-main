"""CLI for the research archive (EQ-C-0154, presentation/archive.py), added by ops/commands.register:

    econquest archive add --product K --file F [--file F2] --period D [--country C | --subject S] --by NAME
                          [--title T] [--run-id R --code-hash H] [--conflicts TEXT] [--licence internal-only]
    econquest archive add --from-pack [DIR] --by NAME [--limit N]     every product of the built MVP research pack
    econquest archive correct ID --file F [--file F2] --what TEXT --why TEXT --by NAME
    econquest archive list [--product K] [--country C] [--from D] [--to D] [--latest] [--json]
    econquest archive show ID [--version N] [--json]
    econquest archive search QUERY [--product K] [--country C] [--from D] [--to D] [--latest] [--limit N]
                          [--client] [--backend fts5|inverted] [--json]
    econquest archive verify [--json]                                exit 1 on any problem

Everything is under <out>/archive (the top-level --out). The archive is internal research; --client shows only what a
client path could see (client-safe versions)."""
from __future__ import annotations

import json
import sys
from pathlib import Path


def _stamps(args) -> tuple[str | None, str | None, str | None]:
    """run_id, code_hash, data_hash: the flags, else <out>/run_latest.json (code_hash: the current code's)."""
    run_id, code_hash, data_hash = args.run_id, args.code_hash, None
    if not run_id:
        try:
            s = (json.loads((Path(args.out) / "run_latest.json").read_text(encoding="utf-8")) or {}).get("summary") or {}
        except (OSError, ValueError):
            s = {}
        run_id = s.get("run_id")
        v = s.get("versions") or {}
        code_hash = code_hash or s.get("code_hash") or v.get("code_hash")
        data_hash = s.get("data_hash") or v.get("data_hash")
    if not code_hash:
        from ..versioning import code_hash as current
        code_hash = current()
    return run_id, code_hash, data_hash


def _print_rows(rows: list[dict]) -> None:
    if not rows:
        print("No archived item matches."); return
    for r in rows:
        flag = " CORRECTED" if r["corrected"] else ""
        sup = f" (superseded by v{r['latest_version']})" if r["superseded"] else ""
        print(f"{r['id']:<52} v{r['version']}{flag}{sup}  {r['licence']:<13} {r['title']}")


def cmd_archive(args) -> None:
    from . import archive as A
    out = args.out
    c = args.ar_cmd
    try:
        if c == "add":
            if args.from_pack is not None:
                r = A.add_from_pack(out, args.from_pack or None, by=args.by, limit=args.limit)
                for x in r["results"]:
                    print(f"{x['status']:<9} {x['ref']}  {x['licence']}  {x['title']}")
                print(f"{r['added']} added, {r['unchanged']} unchanged from the pack of run {r['pack_run_id']} ({r['period']}).")
                return
            if not (args.product and args.file and args.period):
                raise A.ArchiveError("add needs --product, --file and --period (or --from-pack)")
            run_id, code_hash, data_hash = _stamps(args)
            r = A.add(out, args.product, args.file, period=args.period, by=args.by, country=args.country,
                      subject=args.subject, title=args.title, run_id=run_id, code_hash=code_hash, data_hash=data_hash,
                      conflicts=args.conflicts, licence=args.licence)
            print(f"{r['status']} {r['ref']} ({r['licence']}): {r['title']}")
        elif c == "correct":
            r = A.correct(out, args.item, args.file, what=args.what, why=args.why, by=args.by, conflicts=args.conflicts,
                          title=args.title, run_id=args.run_id, code_hash=args.code_hash, licence=args.licence)
            print(f"corrected {r['ref']} ({r['licence']}); earlier versions are unchanged.")
        elif c == "list":
            rows = A.list_archive(out, args.product, args.country, args.date_from, args.date_to, args.latest)
            print(json.dumps(rows, indent=1)) if args.json else _print_rows(rows)
        elif c == "show":
            d = A.show(out, args.item, args.version)
            if args.json:
                print(json.dumps(d, indent=1)); return
            print(f"{d['id']} v{d['version']} of {d['latest_version']}{' CORRECTED' if d['corrected'] else ''}: {d['title']}")
            print(f"  product {d['product']} · period {d['period']} · licence {d['licence']} · run {d['run_id']} · code {d['code_hash']}")
            for f in d["manifest_files"]:
                print(f"  file {f['name']}  sha256 {f['sha256'][:16]}  {f['bytes']} bytes")
            if d["correction"]:
                k = d["correction"]
                print(f"  Corrected on {k['utc']} by {k['by']}: {k['what']} Why: {k['why']}")
            disc = d["disclosure"] or {}
            print(f"  Disclosure: {disc.get('internal_research')} Conflicts: {disc.get('conflicts')} "
                  f"Sources: {'; '.join(disc.get('attribution') or [])}")
            for h in d["history"]:
                print(f"  history v{h['version']} {h['event']} {h['utc']} by {h['by']}")
        elif c == "search":
            r = A.search(out, args.query, product=args.product, country=args.country, date_from=args.date_from,
                         date_to=args.date_to, latest_only=args.latest, limit=args.limit,
                         audience="client" if args.client else "internal", backend=args.backend)
            if args.json:
                print(json.dumps(r, indent=1)); return
            print(f"{r['message']} (backend {r['backend']}, audience {r['audience']}; showing {r['count']})")
            for x in r["results"]:
                flag = " CORRECTED" if x["corrected"] else ""
                print(f"{x['id']} v{x['version']}{flag}  {x['licence']}  {x['title']}\n    {x['snippet']}")
        elif c == "verify":
            v = A.verify(out)
            if args.json:
                print(json.dumps(v, indent=1))
            else:
                print(f"archive verify: {'ok' if v['ok'] else 'FAILED'}: {v['rows']} index rows, {v['items']} items, "
                      f"{v['versions']} versions")
                for e in v["errors"]:
                    print(f"  ERROR {e}")
                for w in v["warnings"][:20]:
                    print(f"  warning {w}")
            if not v["ok"]:
                sys.exit(1)
    except A.ArchiveError as e:
        raise SystemExit(f"archive {c}: {e}") from None


def register(sub) -> None:
    from . import archive as A
    ar = sub.add_parser("archive", help="research archive (EQ-C-0154): immutable versions of published notes, briefs and ideas "
                                        "with corrections, disclosures and full-text search (<out>/archive; internal)")
    ars = ar.add_subparsers(dest="ar_cmd", required=True)

    def filters(p):
        p.add_argument("--product", choices=A.PRODUCTS); p.add_argument("--country")
        p.add_argument("--from", dest="date_from", metavar="YYYY-MM-DD"); p.add_argument("--to", dest="date_to", metavar="YYYY-MM-DD")
        p.add_argument("--latest", action="store_true", help="latest version of each item only"); p.add_argument("--json", action="store_true")

    a = ars.add_parser("add", help="archive v1 of a product (the same files again: unchanged; other files: use correct)")
    a.add_argument("--product", choices=A.PRODUCTS); a.add_argument("--file", action="append", help="repeatable")
    a.add_argument("--period", metavar="YYYY-MM-DD", help="the product's as-of date (part of the stable id)")
    a.add_argument("--country"); a.add_argument("--subject", help="id part when not a country (scenario key; default all)")
    a.add_argument("--from-pack", nargs="?", const="", metavar="DIR", help="archive the built MVP research pack (default <out>/reports/mvp)")
    a.add_argument("--limit", type=int, help="with --from-pack: at most N products")
    for p in (a, ars.add_parser("correct", help="new version v<N+1> with a correction note and a 'Corrected on' banner; "
                                                "earlier versions never change")):
        if p is not a:
            p.add_argument("item", help="archive id (econquest archive list)"); p.add_argument("--file", action="append", required=True)
            p.add_argument("--what", required=True, help="what changed"); p.add_argument("--why", required=True, help="why")
        p.add_argument("--by", required=True, help="who (name)"); p.add_argument("--title")
        p.add_argument("--run-id"); p.add_argument("--code-hash")
        p.add_argument("--conflicts", help="conflicts of interest declaration (default: None declared.)")
        p.add_argument("--licence", choices=["internal-only"], help="narrow the label (labels are carried, never raised)")
    li = ars.add_parser("list", help="archived versions (newest period first)"); filters(li)
    sh = ars.add_parser("show", help="one version: files and hashes, disclosure, correction, history")
    sh.add_argument("item"); sh.add_argument("--version", type=int); sh.add_argument("--json", action="store_true")
    se = ars.add_parser("search", help="full-text search (sqlite FTS5, else an inverted index) with filters")
    se.add_argument("query"); filters(se); se.add_argument("--limit", type=int, default=20)
    se.add_argument("--client", action="store_true", help="only what a client path may see (client-safe versions)")
    se.add_argument("--backend", choices=["fts5", "inverted"])
    ve = ars.add_parser("verify", help="hash chain, manifests, file hashes, disclosures, corrections; exit 1 on a problem")
    ve.add_argument("--json", action="store_true")
    ar.set_defaults(fn=cmd_archive)
