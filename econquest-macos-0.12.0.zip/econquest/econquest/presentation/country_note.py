"""Country research notes (EQ-C-0024): one self-contained HTML note per country (inline CSS and SVG, no CDN, prints
to PDF from any browser), with an optional PDF written by a local headless Chrome/Chromium when one is found.

Each note: headline (default PD, regime, composite, exposure), scorecard pillars, PD against its benchmarks
(rating-, spread-, CDS- and prediction-market-implied, from data/benchmarks.csv), the DSA fan (outputs/dsa_fan.csv),
the stress-scenario impact on the country (archived stress-<key> runs), regime detail, the 25 signals (plus the display-only DSA benchmark test, signal 26, when the run has it) and the
playbook trade view, the events section (UCDP / GDELT event heat and week-on-week change from events_view.py,
"no event feed yet" or STALE when the feed is missing or old; EQ-C-0037), the country's input caveats and the standard disclaimer. A relative-value
section (EQ-C-0046) shows bond rich/cheap vs model and the CDS curve from outputs/bond_rv*.csv and outputs/cds_curves.csv
(rv_view.py; "no CDS curves" when absent, SYNTHETIC and flags shown). Every note is stamped with run_id,
as-of date, data_hash, code_hash and run_hash. Formatting only: every number comes from the archived run or an
output file; nothing is re-estimated here.

    from econquest.presentation.country_note import build_country_notes
    notes = build_country_notes("outputs", "data", "outputs/notes", countries=["Argentina"], pdf=True)
    # -> [{"kind": "country_note", "country": "Argentina", "html": ..., "pdf": ... or None, "pdf_status": ...,
    #      "run_id", "as_of", "data_hash", "code_hash", "run_hash", ...}]

The return value (and <out_dir>/country-notes.json) carries the paths and stamps an editorial wrapper needs; this
module writes no draft/reviewed/published state of its own.

Helpers shared with scenario_brief.py: find_chrome, html_to_pdf, run_stamps, stamp_html, load_stress_runs, NOTE_CSS.
"""
from __future__ import annotations
import datetime as dt
import glob
import json
import math
import os
import re
import shutil
import signal
# subprocess runs only a local Chrome binary found on disk, with a fixed argument list and no shell
import subprocess  # nosec B404
import tempfile
import time
from pathlib import Path

import pandas as pd

from .events_view import country_events_html, event_summary, index_heat
from .rv_view import country_rv_html, rv_summary
from .report import (DISCLAIMER, PD_CAP_LABEL, PD_CAP_NOTE, PERIL_COLS, _e, _f, _pct, _signed, at_pd_cap, caveats_html, input_caveats, pd_html, product_sources,
                     run_as_of, run_hash_of, sources_html)
from .risk_monitor import load_latest

from .house_style import NOTE_CSS, not_available_plain  # noqa: E402  (EQ-C-0082 house style; EQ-C-0144 reader text)

PILLAR_NAMES = {1: "Fiscal and debt", 2: "External", 3: "Institutions and governance", 4: "Political and policy",
                5: "Macro and financial", 6: "Security and social", 7: "Climate and disaster"}
BENCH_COLS = (("pd_model", "Model (final)"), ("pd_hazard", "Hazard layer"), ("pd_rating", "Rating-implied"),
              ("pd_spread", "Spread-implied"), ("pd_cds", "CDS-implied"), ("pd_pm", "Prediction market"))
FIRE = "<span class='tag fire'>FIRING</span>"
PILLAR_FINAL_RANGE = "'Pillar Scores'!E29:V35"      # workbook v1 (18 countries); v2 sizes these by country count
COMPOSITE_RANGE = "'Pillar Scores'!E46:V47"


def pillar_plan_ranges(n: int) -> list[tuple[str, str]]:
    """(final pillars, composite) ranges to look for in publish_plan.json for n countries: the workbook v2 layout
    (sheets_publish.layout_v2, EQ-C-0033) first, then the v1 fixed ranges a plan from older code carries."""
    out = []
    try:
        from .sheets_publish import layout_v2
        lay = layout_v2(n)
        out.append((lay["pillar_final"], lay["pillar_composite"]))
    except (ImportError, KeyError, ValueError, TypeError):
        pass
    if (PILLAR_FINAL_RANGE, COMPOSITE_RANGE) not in out:
        out.append((PILLAR_FINAL_RANGE, COMPOSITE_RANGE))
    return out


# ---------------------------------------------------------------- PDF through a local headless Chrome / Chromium
CHROME_CANDIDATES_MAC = ("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome",
                         "/Applications/Chromium.app/Contents/MacOS/Chromium",
                         "/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge",
                         "/Applications/Brave Browser.app/Contents/MacOS/Brave Browser")
CHROME_NAMES = ("google-chrome", "google-chrome-stable", "chromium", "chromium-browser", "chrome", "msedge")
CHROME_GLOBS = ("/opt/pw-browsers/chromium_headless_shell-*/chrome-headless-shell-*/chrome-headless-shell",
                "~/Library/Caches/ms-playwright/chromium_headless_shell-*/chrome-headless-shell-*/chrome-headless-shell",
                "/opt/pw-browsers/chromium-*/chrome-linux*/chrome",
                "~/Library/Caches/ms-playwright/chromium-*/chrome-mac*/Chromium.app/Contents/MacOS/Chromium")


def find_chrome(explicit: str | None = None) -> str | None:
    """Path of a Chrome/Chromium binary able to print to PDF, or None. Order: `explicit`, $ECONQUEST_CHROME, the macOS
    application bundles, PATH, then Playwright's browser folders (headless shell first). Nothing is downloaded."""
    for c in (explicit, os.environ.get("ECONQUEST_CHROME")):
        if c:
            return c if Path(c).is_file() and os.access(c, os.X_OK) else None
    for c in CHROME_CANDIDATES_MAC:
        if Path(c).is_file():
            return c
    for n in CHROME_NAMES:
        p = shutil.which(n)
        if p:
            return p
    for g in CHROME_GLOBS:
        hits = sorted(glob.glob(os.path.expanduser(g)))
        if hits:
            return hits[-1]
    return None


def _kill_tree(proc: subprocess.Popen) -> None:
    try:
        if hasattr(os, "killpg"):
            os.killpg(proc.pid, signal.SIGKILL)       # Chrome forks helpers: kill the whole session, not only the parent
        else:
            proc.kill()
    except (OSError, ProcessLookupError):
        pass


def html_to_pdf(html_path: str | Path, pdf_path: str | Path | None = None, chrome: str | None = None, timeout: int = 60) -> tuple[str | None, str]:
    """Print an HTML file to PDF with headless Chrome (`--headless --print-to-pdf`). Returns (pdf path or None, status).
    Skips cleanly (None, "skipped: ...") when no browser is found; never raises for a render failure, and kills the
    browser (with its helper processes) on timeout. A throwaway profile directory is used so a running Chrome on the
    Mac is neither reused nor touched."""
    html_path = Path(html_path).resolve()
    pdf_path = Path(pdf_path).resolve() if pdf_path else html_path.with_suffix(".pdf")
    exe = find_chrome(chrome)
    if not exe:
        return None, "skipped: no Chrome/Chromium found (set ECONQUEST_CHROME to its binary, or print the HTML from a browser)"
    with tempfile.TemporaryDirectory(prefix="eq-chrome-") as prof:
        cmd = [exe] + ([] if "headless-shell" in Path(exe).name else ["--headless"]) + [
               "--disable-gpu", "--disable-dev-shm-usage", "--no-first-run", "--no-default-browser-check", "--disable-extensions",
               f"--user-data-dir={prof}", "--no-pdf-header-footer", f"--print-to-pdf={pdf_path}", html_path.as_uri()]
        if hasattr(os, "geteuid") and os.geteuid() == 0:
            cmd.insert(1, "--no-sandbox")              # Chrome refuses to run as root with the sandbox (containers only)
        try:
            pdf_path.unlink(missing_ok=True)
            proc = subprocess.Popen(cmd, stdout=subprocess.DEVNULL, stderr=subprocess.PIPE, start_new_session=True)  # nosec B603
        except OSError as e:
            return None, f"failed: {type(e).__name__}: {e}"
        try:
            _, err = proc.communicate(timeout=timeout)
        except subprocess.TimeoutExpired:
            _kill_tree(proc); proc.communicate()
            return None, f"failed: no PDF within {timeout}s ({Path(exe).name}); print the HTML from a browser instead"
        _kill_tree(proc)                                # helpers that outlive the parent
    if pdf_path.exists() and pdf_path.stat().st_size > 0:
        return str(pdf_path), f"ok ({Path(exe).name})"
    lines = (err or b"").decode(errors="replace").strip().splitlines()
    return None, f"failed: exit {proc.returncode}" + (f": {lines[-1][:200]}" if lines else "")


def default_pdf_workers() -> int:
    """Parallel headless browsers for a PDF batch: one per CPU, 2 to 8 (each Chrome is single-threaded for printing)."""
    return max(2, min(8, os.cpu_count() or 4))


def render_pdfs(html_paths: list[Path], chrome: str | None = None, workers: int = 4, timeout: int = 60) -> list[tuple[str | None, str]]:
    """html_to_pdf over several files, a few browsers at a time; results in input order."""
    from concurrent.futures import ThreadPoolExecutor
    if not html_paths:
        return []
    exe = find_chrome(chrome)
    if not exe:
        return [html_to_pdf(html_paths[0], chrome=chrome)] * len(html_paths)
    with ThreadPoolExecutor(max_workers=max(1, workers)) as ex:
        return list(ex.map(lambda p: html_to_pdf(p, chrome=exe, timeout=timeout), html_paths))


# ---------------------------------------------------------------- shared stamps and inputs
def run_stamps(run: dict) -> dict:
    s = run.get("summary", run)
    v = {**{k: x for k, x in ((run.get("provenance") or {}).get("versions") or {}).items() if k != "data_files"}, **(s.get("versions") or {})}
    return {"run_id": s.get("run_id"), "label": s.get("label"), "created_at": s.get("created_at"), "as_of": run_as_of(run),
            "data_hash": v.get("data_hash"), "code_hash": v.get("code_hash"), "code_version": v.get("code_version"), "run_hash": run_hash_of(run)}


def stamp_html(st: dict, extra: tuple = ()) -> str:
    items = (("Run", st.get("run_id")), ("As of", st.get("as_of") or "not recorded"), ("Data hash", st.get("data_hash")),
             ("Code hash", st.get("code_hash")), ("Code version", st.get("code_version"))) + ((("Run hash", st["run_hash"]),) if st.get("run_hash") else ()) + tuple(extra)
    return "".join(f"<span><b>{_e(k)}</b> {_e(v)}</span>" for k, v in items)


def _read(p: Path, **kw) -> pd.DataFrame | None:
    try:
        return pd.read_csv(p, **kw) if p.exists() else None
    except (pd.errors.EmptyDataError, pd.errors.ParserError, OSError):
        return None


def _fnum(v) -> float | None:
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    return x if math.isfinite(x) else None


def slug(text: str) -> str:
    return re.sub(r"[^a-z0-9]+", "-", str(text).lower()).strip("-") or "x"


def load_stress_runs(outputs_dir: str | Path, base: dict) -> tuple[dict[str, dict], str]:
    """{scenario key: archived stress-<key> run} matched to the base run: for each key, the oldest stress run created at
    or after the base run (the `run --stress` batch archives them right after the base run), else the newest one, which
    is then flagged in the note. Returns (runs, note)."""
    out = Path(outputs_dir)
    if not (out / "store" / "econquest.sqlite").exists():
        return {}, "No run archive: per-country stress impact is not available for this note."   # EQ-C-0144: no command
    from ..persistence import Store
    store = Store(out / "store")
    created = (base.get("summary") or {}).get("created_at") or ""
    by_key: dict[str, list[dict]] = {}
    for r in store.runs(limit=2000):                            # newest first
        lab = str(r.get("label") or "")
        if lab.startswith("stress-"):
            by_key.setdefault(lab[len("stress-"):], []).append(r)
    runs, older = {}, []
    for k, rows in by_key.items():
        after = [r for r in rows if r["created_at"] >= created]
        pick = after[-1] if after else rows[0]
        if not after:
            older.append(k)
        try:
            runs[k] = store.load(pick["run_id"])
        except FileNotFoundError:
            continue
    note = "Stress runs matched to this base run (the first stress-<key> archived after it)."
    if older:
        note += f" STALE: no stress run archived after the base run for {', '.join(sorted(older))}; the newest earlier one is shown."
    return runs, note


# ---------------------------------------------------------------- pillars (archived run, else publish plan, else engine recompute)
def _plan_block(plan: list[dict], rng: str) -> list | None:
    for b in plan or []:
        if b.get("range") == rng:
            return b.get("values")
    return None


def load_pillars(run: dict, outputs_dir: Path, data_dir: Path, recompute: bool = True, log=print) -> tuple[pd.DataFrame | None, str, bool]:
    """Final pillar scores (pillar x country) with their source and whether they are consistent with this run (the
    composite they come with equals the run's composite for every country). Sources: run["pillars"] when the run
    carries them; outputs/publish_plan.json ('Pillar Scores' final pillars and composite at the workbook v2 ranges for the country count, sheets_publish.layout_v2; else the v1 E29:V35 / E46:V47); else the engine's
    own scorecard on data/ (run_pipeline at a small path count; the scorecard does not depend on the paths)."""
    comp = {r["country"]: _fnum(r.get("composite")) for r in run.get("country") or []}

    def consistent(composite: dict) -> bool:
        common = [c for c in comp if c in composite and comp[c] is not None and composite[c] is not None]
        return bool(common) and all(abs(comp[c] - composite[c]) <= 1e-6 * max(1.0, abs(comp[c])) for c in common)
    if isinstance(run.get("pillars"), dict):                     # forward-compatible: {country: {pillar: score}}
        df = pd.DataFrame(run["pillars"]); df.index = [int(i) for i in df.index]
        return df, "archived run", True
    names = None
    ind = _read(data_dir / "indicators.csv", nrows=0)
    if ind is not None:
        names = [c for c in ind.columns if c not in ("id", "pillar", "indicator", "unit")]
    pp = outputs_dir / "publish_plan.json"
    if pp.exists() and names:
        try:
            plan = json.loads(pp.read_text())
            vals = cvals = None
            for fr, cr in pillar_plan_ranges(len(names)):
                vals, cvals = _plan_block(plan, fr), _plan_block(plan, cr)
                if vals and cvals:
                    break
            if vals and cvals and len(vals[0]) == len(names):
                df = pd.DataFrame([[_fnum(x) for x in row] for row in vals], index=list(PILLAR_NAMES)[:len(vals)], columns=names)
                if consistent(dict(zip(names, (_fnum(x) for x in cvals[0])))):
                    return df, "outputs/publish_plan.json (Pillar Scores tab; composite matches this run)", True
                plan_df = df
            else:
                plan_df = None
        except (ValueError, OSError, IndexError, TypeError):
            plan_df = None
    else:
        plan_df = None
    if recompute:
        try:
            from ..config import Settings
            from ..engine import run_pipeline
            from ..ingestion import load_universe
            s = Settings.load(data_dir / "assumptions.json")
            r = run_pipeline(load_universe(data_dir), s, label="note-scorecard", paths=2048, as_of=run_as_of(run),
                             market_dir=data_dir)                        # HO-20261025-B-C-006
            df = r.scorecard.pillar_final.copy(); df.index = [int(i) for i in df.index]
            ok = consistent({c: float(r.scorecard.composite[c]) for c in df.columns})
            return df, "engine scorecard on data/ (recomputed; " + ("composite matches this run)" if ok else "composite DIFFERS from this run: data changed since the run)"), ok
        except Exception as e:                                   # noqa: BLE001 - a missing pillar view must not stop the note
            log(f"[notes] pillar recompute failed: {type(e).__name__}: {e}")
    if plan_df is not None:
        return plan_df, "outputs/publish_plan.json (composite DIFFERS from this run: plan built from other inputs)", False
    return None, "not available (no pillar scores in the run, no publish plan, recompute failed)", False


# ---------------------------------------------------------------- SVG charts (inline, no library)
def svg_hbars(items: list[tuple[str, float | None]], vmax: float | None = None, unit: str = "", width: int = 520, row_h: int = 22,
              label_w: int = 170, fmt=lambda v: f"{v:.1f}", highlight: str | None = None, aria: str = "bar chart",
              suffix: dict | None = None) -> str:
    """Horizontal bars. `suffix` maps a bar label to text appended after its value and unit (e.g. the engine-cap label
    on a capped PD, HO-20261025-B-C-014)."""
    suffix = suffix or {}
    rows = [(lbl, v) for lbl, v in items]
    if not rows:
        return ""
    vals = [v for _, v in rows if v is not None]
    mx = vmax or (max(vals) if vals else 1.0) or 1.0
    span = width - label_w - 80; h = row_h * len(rows) + 8; out = ""
    for i, (lbl, v) in enumerate(rows):
        y = 4 + i * row_h; ty = y + row_h * 0.68
        out += f'<text x="{label_w - 8}" y="{ty:.1f}" font-size="11.5" fill="#333" text-anchor="end">{_e(str(lbl)[:30])}</text>'
        if v is None:
            out += f'<text x="{label_w + 4}" y="{ty:.1f}" font-size="11" fill="#888">n/a</text>'
            continue
        w = max(0.0, min(1.0, v / mx)) * span
        col = "#a93226" if highlight and lbl == highlight else "#4a7ab5"
        out += (f'<rect x="{label_w}" y="{y + 4}" width="{w:.1f}" height="{row_h - 8}" fill="{col}"/>'
                f'<text x="{label_w + w + 5:.1f}" y="{ty:.1f}" font-size="11.5" fill="#333">{_e(fmt(v))}{_e(unit)}{_e(suffix.get(lbl, ""))}</text>')
    return f'<svg class="chart" viewBox="0 0 {width} {h}" width="100%" style="max-width:{width}px" role="img" aria-label="{_e(aria)}">{out}</svg>'


def svg_fan(fan: pd.DataFrame, width: int = 520, height: int = 230) -> str:
    """DSA fan: p10-p90 and p25-p75 bands, median line and the WEO baseline (dashed), debt in % of GDP by year."""
    f = fan.sort_values("year")
    if f.empty:
        return ""
    yrs = f["year"].astype(int).tolist()
    cols = [c for c in ("p10", "p25", "p50", "p75", "p90", "baseline_weo") if c in f.columns]
    lo = min(float(f[c].min()) for c in cols); hi = max(float(f[c].max()) for c in cols)
    lo, hi = max(0.0, lo - 5), hi + 5
    x0, x1, y0, y1 = 44, width - 16, 12, height - 32
    X = lambda yr: x0 + (yr - yrs[0]) / max(1, yrs[-1] - yrs[0]) * (x1 - x0)
    Y = lambda v: y1 - (v - lo) / (hi - lo or 1) * (y1 - y0)

    def band(a, b, fill):
        pts = [f"{X(r.year):.1f},{Y(getattr(r, a)):.1f}" for r in f.itertuples()] + [f"{X(r.year):.1f},{Y(getattr(r, b)):.1f}" for r in list(f.itertuples())[::-1]]
        return f'<polygon points="{" ".join(pts)}" fill="{fill}"/>'

    def line(c, stroke, dash=""):
        pts = " ".join(f"{X(r.year):.1f},{Y(getattr(r, c)):.1f}" for r in f.itertuples())
        return f'<polyline points="{pts}" fill="none" stroke="{stroke}" stroke-width="2"{(" stroke-dasharray=" + chr(34) + dash + chr(34)) if dash else ""}/>'
    body = ""
    if {"p10", "p90"} <= set(f.columns):
        body += band("p10", "p90", "#d6e4f2")
    if {"p25", "p75"} <= set(f.columns):
        body += band("p25", "p75", "#9dbbdc")
    if "p50" in f.columns:
        body += line("p50", "#1f4e79")
    if "baseline_weo" in f.columns:
        body += line("baseline_weo", "#333", "5 4")
    ticks = ""
    for k in range(5):
        v = lo + (hi - lo) * k / 4
        ticks += f'<line x1="{x0}" x2="{x1}" y1="{Y(v):.1f}" y2="{Y(v):.1f}" stroke="#eee"/><text x="{x0 - 5}" y="{Y(v) + 4:.1f}" font-size="10" fill="#666" text-anchor="end">{v:.0f}</text>'
    for yr in yrs:
        ticks += f'<text x="{X(yr):.1f}" y="{y1 + 14}" font-size="10" fill="#666" text-anchor="middle">{yr}</text>'
    legend = (f'<text x="{x0}" y="{height - 4}" font-size="10" fill="#333">Bands: 10-90th and 25-75th percentile; solid: median; dashed: WEO baseline. Debt, % of GDP.</text>')
    return (f'<svg class="chart" viewBox="0 0 {width} {height}" width="100%" style="max-width:{width}px" role="img" aria-label="Debt sustainability fan chart, debt in % of GDP">'
            f'{ticks}{body}{legend}</svg>')


# ---------------------------------------------------------------- per-country content
def country_caveats(cav: dict, country: str, data_dir: Path) -> dict:
    """The input caveats that apply to one country: every book-wide item, this country's cell counts, the indicators
    on seed or unverified values for it, and its quality-gate holds."""
    bc = next((r for r in cav.get("by_country") or [] if r["country"] == country), None)
    inds = [r for r in cav.get("by_indicator") or [] if country in r.get("countries", [])]
    holds = []
    rev = _read(data_dir / "live" / "review.csv")
    if rev is not None and {"country", "status"} <= set(rev.columns):
        h = rev[(rev["country"].astype(str) == country) & (rev["status"].astype(str).str.lower() == "hold")]
        holds = [{"table": r.get("table", ""), "key": r.get("key", ""), "reason": r.get("reason", "")} for _, r in h.iterrows()]
    return {"items": cav.get("items") or [], "cells": bc, "indicators": inds, "holds": holds, "source": cav.get("source", "")}


def _caveats_block(cc: dict) -> str:
    li = "".join(f"<li><b>[{_e(('restriction ' + i['restriction']) if i['restriction'] else 'data')}]</b> {_e(i['text'])} <span class='note'>({_e(i['ref'])})</span></li>" for i in cc["items"])
    out = f"<div class='caveats' role='note' aria-label='Input caveats'><ul>{li or '<li>No book-wide caveat found in the data files.</li>'}</ul>"
    c = cc.get("cells")
    if c and c.get("total") and "withheld" in c:                       # EQ-C-0153: client-safe dataset
        nl = c["total"] - c["live"]
        out += (f"<p><span class='tag seed'>SEED</span> This country: {nl} of {c['total']} scorecard input cells ({nl / c['total']:.0%}) are not live "
                f"({c['seed']} seed estimates, {c['unverified']} unverified, {c['withheld']} withheld: licence, "
                f"{c['placeholder']} placeholder (withheld: licence), {c['live']} live).</p>")
    elif c and c.get("total"):
        nl = c["seed"] + c["unverified"]
        out += (f"<p><span class='tag seed'>SEED</span> This country: {nl} of {c['total']} scorecard input cells ({nl / c['total']:.0%}) are not live "
                f"({c['seed']} seed estimates, {c['unverified']} unverified, {c['live']} live).</p>")
    if cc.get("indicators"):
        out += ("<p class='note'>Indicators on seed or unverified values for this country: "
                + "; ".join(f"{_e(r['id'])} {_e(r['indicator'])}" for r in cc["indicators"]) + ".</p>")
    if cc.get("holds"):
        out += "<p>Quality-gate holds for this country (seed value kept): " + "; ".join(f"{_e(h['table'])} {_e(h['key'])} ({_e(h['reason'])})" for h in cc["holds"]) + ".</p>"
    if cc.get("source"):
        out += f"<p class='note'>Source: {_e(cc['source'])}.</p>"
    return out + "</div>"


def _latest_benchmarks(data_dir: Path) -> pd.DataFrame | None:
    b = _read(data_dir / "benchmarks.csv")
    if b is None or "country" not in b.columns:
        return None
    if "date" in b.columns:
        b = b.sort_values("date").groupby("country", as_index=False).tail(1)
    return b.set_index("country")


def _collect_common(outputs_dir: Path, data_dir: Path, run: dict, recompute_pillars: bool, log) -> dict:
    st = run_stamps(run)
    pillars, pillar_src, pillar_ok = load_pillars(run, outputs_dir, data_dir, recompute=recompute_pillars, log=log)
    stress = _read_json(outputs_dir / "stress.json") or {}
    stress_runs, stress_note = load_stress_runs(outputs_dir, run)
    pb = _read(data_dir / "playbook.csv")
    cds = _read(data_dir / "cds_quotes.csv")
    dsa = _read(outputs_dir / "dsa.csv")
    events = event_summary(data_dir, countries=[(r["country"], r.get("iso")) for r in run.get("country") or []], as_of=st.get("as_of"), outputs_dir=outputs_dir)
    return {"rv": rv_summary(outputs_dir), "events": events, "sources": product_sources(data_dir, run, events=events), "stamps": st, "pillars": pillars, "pillar_src": pillar_src, "pillar_ok": pillar_ok, "bench": _latest_benchmarks(data_dir),
            "fan": _read(outputs_dir / "dsa_fan.csv"), "dsa": None if dsa is None or "country" not in dsa.columns else dsa.set_index("country"),
            "stress": stress, "stress_runs": stress_runs, "stress_note": stress_note,
            "playbook": None if pb is None else pb.set_index("id"), "cds": cds, "caveats": input_caveats(data_dir, run),
            "threshold": float(((run.get("settings") or {}).get("signals") or {}).get("threshold", 60) or 60),
            "generated": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M"),
            "v2": _load_v2(outputs_dir, run), "house_view": _load_house_view(outputs_dir, st),
            "client_safe": _client_safe_marker(data_dir)}                                    # EQ-C-0151


def _load_v2(outputs_dir: Path, run: dict) -> dict:
    """EQ-C-0082 v2 inputs (note_v2.load): DSA paths/signal (C13), nowcast, GPR, shadow rating; absent files are None."""
    from . import note_v2
    return note_v2.load(outputs_dir, run)


def _read_json(p: Path):
    try:
        return json.loads(p.read_text()) if p.exists() else None
    except (ValueError, OSError):
        return None


def _by(rows, key="country") -> dict:
    return {r.get(key): r for r in rows or [] if isinstance(r, dict)}


def render_country_note(country: str, run: dict, common: dict, data_dir: Path, v2: bool = True) -> str:
    st = common["stamps"]; crow = _by(run.get("country")).get(country) or {}
    s = run.get("summary") or {}
    exp = _by(run.get("by_country")).get(country) or {}
    dash = _by(run.get("dashboard")).get(country) or {}
    title = f"{country}: country risk note"
    # headline tiles
    tiles = [(pd_html(crow.get("pd_default")), "Default PD, 12 months"), (_e(crow.get("regime")), "Regime"),
             (f"{_f(crow.get('composite'))} / grade {_e(crow.get('grade'))}", "Composite score (0-100)"),
             (f"{_e(crow.get('rating'))}, {_f(crow.get('spread_bps'), 0)} bp", "Rating, spread (hand-entered)"),
             (_pct(crow.get("pd_any")), "Any political peril, 12 months"),
             (f"{_f(exp.get('notional_mm'), 1)}", "Book exposure ($mm)"),
             (f"{_f(exp.get('tail_contribution_99_mm'), 2)}", "99% tail contribution ($mm)"),
             (f"{_f(exp.get('expected_loss_mm'), 2)}", "Expected loss ($mm)")]
    kpis = "".join(f"<div class='kpi'><div class='v'>{v or 'n/a'}</div><div class='l'>{_e(lbl)}</div></div>" for v, lbl in tiles)
    # pillars
    P = common["pillars"]
    if P is not None and country in P.columns:
        items = [(f"{p} {PILLAR_NAMES.get(int(p), '')}", _fnum(P.at[p, country])) for p in P.index]
        worst = max((i for i in items if i[1] is not None), key=lambda i: i[1], default=(None, None))[0]
        mark = "" if common["pillar_ok"] else " <span class='tag stale'>NOT THIS RUN</span>"
        pillars = (svg_hbars(items, vmax=100, width=520, label_w=200, fmt=lambda v: f"{v:.0f}", highlight=worst, aria="Final pillar scores, 0-100")
                   + f"<p class='note'>Final pillar scores, 0 (low risk) to 100 (high risk); the highest pillar is drawn in red and named first in the table. Source: {_e(common['pillar_src'])}.{mark}</p>"
                   + "<table><tr><th>Pillar</th><th class='n'>Score</th></tr>" + "".join(
                       f"<tr><td>{_e(lbl)}{' <b>(highest)</b>' if lbl == worst else ''}</td><td class='n'>{_f(v, 1)}</td></tr>" for lbl, v in items) + "</table>")
    else:
        pillars = f"<p class='empty'>Pillar scores {_e(common['pillar_src'])}.</p>"
    # PD vs benchmarks
    B = common["bench"]; brow = B.loc[country] if B is not None and country in B.index else None
    bench_items = [("Model (this run)", _fnum(crow.get("pd_default")))]
    if brow is not None:
        bench_items += [(lbl, _fnum(brow.get(k))) for k, lbl in BENCH_COLS if k != "pd_model"]
    else:
        bench_items += [("Rating-implied", _fnum(crow.get("pd_rating"))), ("Hazard layer", _fnum(crow.get("pd_hazard_l1"))), ("Market (spread)", _fnum(crow.get("pd_market")))]
    vals = [v for _, v in bench_items if v is not None]
    bench_chart = svg_hbars([(l, None if v is None else v * 100) for l, v in bench_items], vmax=max(vals) * 100 * 1.1 if vals else 1, unit="%",
                            fmt=lambda v: f"{v:.2f}", aria="12-month default PD against benchmarks, %",
                            suffix={"Model (this run)": f" {PD_CAP_LABEL}"} if at_pd_cap(crow.get("pd_default")) else None)
    bnote = []
    if brow is not None:
        bnote.append(f"data/benchmarks.csv row of {_e(brow.get('date', ''))} (data hash {_e(brow.get('data_hash', ''))})"
                     + (" <span class='tag stale'>OTHER DATA</span>" if brow.get("data_hash") and st.get("data_hash") and str(brow.get("data_hash")) != str(st.get("data_hash")) else ""))
        gaps = [(lbl, _fnum(brow.get(k))) for k, lbl in (("model_vs_rating_pp", "rating"), ("model_vs_spread_pp", "spread"), ("model_vs_cds_pp", "CDS"), ("model_vs_pm_pp", "prediction market"))]
        bnote.append("Model minus benchmark: " + ", ".join(f"{lbl} {_signed(v, 2)} pp" for lbl, v in gaps if v is not None))
    else:
        bnote.append("No benchmark file row for this country: the run's own benchmarks are shown")
    cq = common["cds"]
    if cq is not None and "country" in cq.columns and len(cq[cq["country"].astype(str) == country]):
        q = cq[cq["country"].astype(str) == country].tail(1).iloc[0]
        bnote.append(f"Latest CDS quote: {_e(q.get('tenor_y', ''))}y {_e(q.get('spread_bp', ''))} bp on {_e(q.get('date', ''))} ({_e(q.get('source', ''))})")
    elif brow is None or _fnum(brow.get("pd_cds")) is None:
        bnote.append("CDS-implied PD n/a: no quote for this country in data/cds_quotes.csv")
    if crow.get("pm_default") is None and (brow is None or _fnum(brow.get("pd_pm")) is None):
        bnote.append("no prediction-market contract on this country")
    if at_pd_cap(crow.get("pd_default")):
        bnote.append(_e(PD_CAP_NOTE.rstrip(".")))
    bench = bench_chart + "<p class='note'>" + ". ".join(bnote) + ".</p>"
    # DSA fan
    fan = common["fan"]
    f = fan[fan["country"].astype(str) == country] if fan is not None and "country" in fan.columns else None
    if f is not None and len(f):
        dsa_html = svg_fan(f)
        drow = common["dsa"].loc[country] if common["dsa"] is not None and country in common["dsa"].index else None
        if drow is not None:
            dsa_html += (f"<p class='note'>Debt {_f(drow.get('debt_now'))}% of GDP now; 5-year median {_f(drow.get('debt_median_5y'))}% "
                         f"(10-90th {_f(drow.get('debt_p10_5y'))}-{_f(drow.get('debt_p90_5y'))}%); P(debt rising) {_pct(drow.get('p_debt_rising'), 0)}, "
                         f"P(debt above 80%) {_pct(drow.get('p_debt_above_80'), 0)}; reserves {_f(drow.get('reserves_pct_ara'), 0)}% of IMF ARA. Read: {_e(drow.get('read'))}. Source: outputs/dsa.csv.</p>")
    else:
        dsa_html = _no_fan_html(fan)
    # stress
    rows, capped = "", at_pd_cap(crow.get("pd_default"))
    for k, v in (common["stress"] or {}).items():
        sr = common["stress_runs"].get(k)
        sc = _by((sr or {}).get("country")).get(country) or {}
        sb = _by((sr or {}).get("by_country")).get(country) or {}
        pdb, pds = _fnum(crow.get("pd_default")), _fnum(sc.get("pd_default"))
        tb, ts = _fnum(exp.get("tail_contribution_99_mm")), _fnum(sb.get("tail_contribution_99_mm"))
        capped = capped or at_pd_cap(pds)
        rows += (f"<tr><td>{_e(k)}</td><td>{_e(v.get('name'))}</td><td class='n'>{pd_html(pdb)}</td><td class='n'>{pd_html(pds)}</td>"
                 f"<td class='n'>{'' if pdb is None or pds is None else _signed((pds - pdb) * 100, 2, ' pp')}</td>"
                 f"<td>{_e(crow.get('regime'))} &rarr; {_e(sc.get('regime') or 'n/a')}</td>"
                 f"<td class='n'>{_f(tb, 2)}</td><td class='n'>{_f(ts, 2)}</td><td class='n'>{'' if tb is None or ts is None else _signed(ts - tb, 2)}</td></tr>")
    stress_html = ((f"<table class='compact'><tr><th>Key</th><th>Scenario</th><th class='n'>Default PD base</th><th class='n'>Stressed</th><th class='n'>Change</th><th>Regime</th>"
                    f"<th class='n'>Tail contr. base $mm</th><th class='n'>Stressed $mm</th><th class='n'>Change $mm</th></tr>{rows}</table>"
                    f"<p class='note'>{_e(common['stress_note'])} Book-level impact is in the scenario briefs.</p>"
                    + (f"<p class='note pd-cap-note'>{_e(PD_CAP_NOTE)}</p>" if capped else ""))
                   if rows else not_available_plain("Stress results: not available for this run (no stress scenarios were run with it).",
                                                 "no outputs/stress.json."))
    # regime
    reg = (f"<table><tr><th>Regime (blended)</th><th>Rule-based</th><th>HMM</th><th class='n'>P(crisis, 12m)</th><th class='n'>HMM P(crisis)</th><th class='n'>PD multiplier</th><th class='n'>LGD multiplier</th></tr>"
           f"<tr><td class='regime-{_e(crow.get('regime'))}'><b>{_e(crow.get('regime'))}</b></td><td>{_e(crow.get('regime_rule'))}</td><td>{_e(crow.get('regime_hmm') or 'off')}</td>"
           f"<td class='n'>{_pct(crow.get('p_crisis_12m'), 1)}</td><td class='n'>{_pct(crow.get('p_crisis_hmm'), 1)}</td><td class='n'>{_f(crow.get('pd_mult'), 3)}</td><td class='n'>{_f(crow.get('lgd_mult'), 3)}</td></tr></table>"
           f"<p class='note'>Global regime {_e(s.get('global_regime'))}; countries by regime: {_e(', '.join(f'{k} {n}' for k, n in (s.get('regimes') or {}).items()))}. "
           f"Peril PDs: " + ", ".join(f"{lbl} {_pct(crow.get(k))}" for k, lbl in PERIL_COLS) + f"; Merton distance to distress {_f(crow.get('DD'), 2)}.</p>")
    # signals
    from ..engine.signals import SIGNAL_NAMES, OPTIONAL_SIGNAL_NAMES
    thr = common["threshold"]
    sig = _by(run.get("signals"), "key")
    srows = []
    for k, name in SIGNAL_NAMES.items():
        v = _fnum((sig.get(k) or sig.get(str(k)) or {}).get(country))
        srows.append((k, name, v))
    srows.sort(key=lambda r: -(r[2] if r[2] is not None else -1))
    sig_html = ("<table><tr><th class='n'>Key</th><th>Signal</th><th class='n'>Strength (0-100)</th><th>State</th></tr>" + "".join(
        f"<tr><td class='n'>{k}</td><td>{_e(n)}</td><td class='n'>{_f(v, 0)}</td><td>{FIRE if v is not None and v >= thr else ''}</td></tr>" for k, n, v in srows)
        + f"</table><p class='note'>FIRING at {thr:.0f} or above (assumptions.json signals.threshold).</p>") if sig else "<p class='empty'>The run carries no signals.</p>"
    # signal 26 (EQ-B-0080, HO-20261024-B-C-015): DSA benchmark test, display only. Shown apart from the 25 risk signals
    # because it is a debt-benchmark test, not a default-risk signal, and it moves no PD, VaR or ES.
    d26 = sig.get(26) or sig.get("26") if sig else None
    if d26 is not None:
        v26 = _fnum(d26.get(country))
        sig_html += (f"<table><tr><th class='n'>Key</th><th>Benchmark test (display only)</th><th class='n'>Score (0-100)</th></tr>"
                     f"<tr><td class='n'>26</td><td>{_e(OPTIONAL_SIGNAL_NAMES[26])}</td><td class='n'>{_f(v26, 0) if v26 is not None else 'n/a'}</td></tr></table>"
                     "<p class='note'>Signal 26 is a benchmark test: 100 x the larger of P(debt above the IMF debt benchmark at the "
                     "horizon end) and P(gross financing need above its benchmark), from the stochastic DSA. It is not a default "
                     "probability and does not change the PD, VaR or ES. "
                     + _dsa_na(common, data_dir) + "</p>")                      # EQ-C-0151 (HO-B-C-005)
    # trade view
    act = [(a.get("trade"), _fnum(a.get(country))) for a in run.get("activation") or []]
    act = sorted([(t, v) for t, v in act if v is not None], key=lambda x: -x[1])
    PB = common["playbook"]
    if act:
        def pbf(t, c):
            return _e(PB.at[t, c]) if PB is not None and t in PB.index and c in PB.columns and pd.notna(PB.at[t, c]) else ""
        trade_html = ("<table class='compact'><tr><th>Trade</th><th class='n'>Strength</th><th>Strategy</th><th>Stance</th><th>Expression</th><th>Entry / exit</th><th>Horizon</th><th>Risks</th></tr>" + "".join(
            f"<tr><td>{_e(t)}</td><td class='n'>{_f(v, 0)}</td><td>{pbf(t, 'strategy')}</td><td>{pbf(t, 'stance')}</td><td>{pbf(t, 'expression')}</td>"
            f"<td>{pbf(t, 'entry')} / {pbf(t, 'exit')}</td><td>{pbf(t, 'horizon')}</td><td>{pbf(t, 'risks')}</td></tr>" for t, v in act) + "</table>")
    else:
        trade_html = "<p class='empty'>No playbook trade is active for this country in this run.</p>"
    if dash:
        trade_html = _desk_view_html(dash) + trade_html
    pos = [p for p in run.get("positions") or [] if p.get("country") == country]
    con = _by(run.get("contributions"), "id")
    if pos:
        trade_html += ("<h3>Book positions in this country</h3><table><tr><th>ID</th><th>Asset</th><th>Side</th><th class='n'>Notional $mm</th><th class='n'>Expected loss $mm</th><th class='n'>99% tail contr. $mm</th><th class='n'>Share of ES99</th></tr>" + "".join(
            f"<tr><td>{_e(p.get('id'))}</td><td>{_e(p.get('asset_class'))}</td><td>{_e(p.get('direction'))}</td><td class='n'>{_f(p.get('notional_mm'), 1)}</td>"
            f"<td class='n'>{_f((con.get(p.get('id')) or {}).get('expected_loss_mm'), 2)}</td><td class='n'>{_f((con.get(p.get('id')) or {}).get('tail_contribution_99_mm'), 2)}</td>"
            f"<td class='n'>{_pct((con.get(p.get('id')) or {}).get('share_of_es99'), 1)}</td></tr>" for p in pos) + "</table>")
    cc = country_caveats(common["caveats"], country, data_dir)
    sections = (*(_house_sections(country, common) if v2 else ()),                    # HO-20261025-B-C-017 house view
                ("pillars", "Scorecard pillars", pillars), ("pd", "Default PD against benchmarks", bench), ("dsa", "Debt sustainability fan", dsa_html),
                *(_v2_sections(country, crow, common, st) if v2 else ()),               # EQ-C-0082 country notes v2
                ("stress", "Stress scenarios: impact on this country", stress_html), ("regime", "Regime", reg),
                ("events", "Events: conflict and unrest feed", country_events_html(common["events"], country)),
                ("rv", "Relative value: bond vs model and CDS curve", country_rv_html(common["rv"], country, crow.get("iso")) if common.get("rv") else
                 "<p class='empty'>No relative-value view (outputs/bond_rv.csv, outputs/cds_curves.csv).</p>"),
                ("signals", "Signals", sig_html), ("trades", "Trade view (playbook)", "<p class='note'>Decision support, not instructions: no position is opened on a signal alone (use restriction 6.5).</p>" + trade_html),
                ("caveats", "Input caveats for this country", _caveats_block(cc)), ("sources", "Sources", sources_html(common["sources"], heading=False)))
    toc = " | ".join(f"<a href='#{k}'>{_e(t)}</a>" for k, t, _ in sections)
    body = "".join(f"<section id='{k}'><h2>{_e(t)}</h2>{h}</section>" for k, t, h in sections)
    stamp = stamp_html(st)
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>{_e(title)} {_e(st.get('as_of') or '')}</title>
<style>{NOTE_CSS}</style></head><body>
<h1>{_e(country)}</h1>
<div class="sub">Country risk note. Run {_e(st.get('run_id'))}, as of {_e(st.get('as_of') or 'not recorded')}. {_e(crow.get('region') or '')} {('(' + _e(crow.get('iso')) + ')') if crow.get('iso') else ''}</div>
<div class="meta">{stamp}</div>
<div class="disclaimer" role="note"><b>Disclaimer.</b> {_e(DISCLAIMER)}</div>
<p class="toc">{toc}</p>
<h2>Headline</h2><div class="kpis">{kpis}</div>
{body}
<p class="note">Stamped: {_e(' | '.join(f'{k} {v}' for k, v in (('run', st.get('run_id')), ('as of', st.get('as_of')), ('data', st.get('data_hash')), ('code', st.get('code_hash')), ('run hash', st.get('run_hash'))) if v))}. Note generated {_e(common['generated'])} UTC (generation timestamp, not a model date).</p>
<div class="disclaimer" role="note"><b>Disclaimer.</b> {_e(DISCLAIMER)}</div>
</body></html>"""


def _no_fan_html(fan) -> str:
    """Why a note has no DSA fan: the file is missing (run `econquest dsa`), or it exists but the DSA does not cover the
    country (HO-20261025-B-C-011: the hint to run the DSA is wrong once dsa_fan.csv exists)."""
    if fan is None or "country" not in fan.columns:
        return not_available_plain("No DSA fan for this country: the debt sustainability analysis was not available for this run.",
                                   "outputs/dsa_fan.csv is missing or unreadable.")    # EQ-C-0144: no command
    return "<p class='empty'>No DSA fan for this country: the DSA does not cover it (no rows in dsa_fan.csv for this run).</p>"


def _txt(v) -> str | None:
    """A dashboard text cell, or None when it is empty or the engine's placeholder ("None", "None above threshold")."""
    if v is None or (isinstance(v, float) and not math.isfinite(v)):
        return None
    s = str(v).strip()
    return None if not s or s.lower() in ("none", "nan", "none above threshold") else s


def _desk_view_html(dash: dict) -> str:
    """The desk-view sentence from the run's dashboard row, in plain words when a cell is empty (no "None" as text)."""
    best, top = _txt(dash.get("best_trade")), _txt(dash.get("top_signals"))
    parts = [f"best trade <b>{_e(best)}</b> (conviction {_f(dash.get('conviction'), 0)})" if best else "no playbook trade is active",
             f"top signals: {_e(top)}" if top else "no signal is above its trigger threshold"]
    tail = "".join(f" {lbl}: {_e(x)}." for lbl, x in (("GPR", _txt(dash.get("gpr_read"))), ("Prediction markets", _txt(dash.get("pm_read")))) if x)
    return f"<p>Desk view: {'; '.join(parts)}.{tail}</p>"


def _house_stance(common: dict, country: str) -> str | None:
    """The house view record's stance for the manifest (country-notes.json house_stance); None without a house view."""
    from . import house_view
    return house_view.stance(common.get("house_view") or {}, country)


def _load_house_view(outputs_dir, st: dict) -> dict:
    """Team B's house view for this run (HO-20261025-B-C-017): presentation.house_view.load, matched on run_id."""
    from . import house_view
    return house_view.load(outputs_dir, st.get("run_id"))


def _house_sections(country: str, common: dict) -> list:
    """The House view section (stance, risk level, trend, rationale, warnings, peer table), placed first in a v2 note."""
    from . import house_view
    hvl = common.get("house_view")
    return [("house_view", "House view", house_view.note_block_html(hvl, country))] if hvl is not None else []


def _v2_sections(country: str, crow: dict, common: dict, st: dict) -> list:
    from . import note_v2
    v = common.get("v2")
    return note_v2.sections(country, crow.get("iso"), v, st.get("as_of")) if v is not None else []


INDEX_JS = """
(function(){var t=document.getElementById('idx');if(!t)return;var b=t.tBodies[0],rows=[].slice.call(b.rows),q=document.getElementById('q'),
fr=document.getElementById('f-region'),fg=document.getElementById('f-regime'),n=document.getElementById('shown');
function opts(sel,k){if(!sel)return;var v={};rows.forEach(function(r){v[r.dataset[k]||'']=1});Object.keys(v).sort().forEach(function(x){if(!x)return;var o=document.createElement('option');o.value=x;o.textContent=x;sel.appendChild(o)})}
opts(fr,'region');opts(fg,'regime');
function filt(){var s=(q&&q.value||'').toLowerCase(),R=fr?fr.value:'',G=fg?fg.value:'',k=0;rows.forEach(function(r){var on=(!s||r.textContent.toLowerCase().indexOf(s)>=0)&&(!R||r.dataset.region===R)&&(!G||r.dataset.regime===G);r.style.display=on?'':'none';if(on)k++});if(n)n.textContent=k+' of '+rows.length+' shown'}
[q,fr,fg].forEach(function(e){if(e)e.addEventListener('input',filt)});
[].slice.call(t.tHead.rows[0].cells).forEach(function(th,i){th.style.cursor='pointer';th.title='Click to sort';th.addEventListener('click',function(){var a=th.dataset.dir!=='asc';
[].slice.call(t.tHead.rows[0].cells).forEach(function(h){h.removeAttribute('data-dir');h.removeAttribute('aria-sort')});th.dataset.dir=a?'asc':'desc';th.setAttribute('aria-sort',a?'ascending':'descending');
rows.sort(function(x,y){var u=x.cells[i].dataset.v,w=y.cells[i].dataset.v;if(u!==undefined&&w!==undefined&&u!==''&&w!==''){u=+u;w=+w}else{u=x.cells[i].textContent;w=y.cells[i].textContent}
if(u===''||u===undefined)return 1;if(w===''||w===undefined)return -1;return(u>w?1:u<w?-1:0)*(a?1:-1)});rows.forEach(function(r){b.appendChild(r)})})});filt()})();
"""
INDEX_CSS = "th[data-dir=asc]::after{content:' \\25B4'}th[data-dir=desc]::after{content:' \\25BE'}.filters{display:flex;gap:10px;flex-wrap:wrap;align-items:center;margin:8px 0;font-size:12px}"


def _num_td(v, text: str) -> str:
    x = _fnum(v)
    return f"<td class='n' data-v='{'' if x is None else repr(x)}'>{_e(text)}</td>"


def _index_html(title: str, rows: list[dict], st: dict, src: dict | None = None, cav: dict | None = None) -> str:
    """Index of notes or briefs. Rows that carry region / regime / pd_default / composite / heat (country notes) get those
    columns, a text filter, region and regime filters and click-to-sort headers (inline script, no CDN; the table is
    complete without JavaScript)."""
    rich = any("region" in r or "regime" in r for r in rows)
    head = "<th>Item</th>" + ("<th>Region</th><th>Regime</th><th class='n'>Default PD 12m</th><th class='n'>Composite</th><th class='n'>Event heat</th>" if rich else "") + "<th>Title</th><th>PDF</th>"
    li = ""
    for r in rows:
        pdf = ('<a href=' + chr(39) + _e(Path(r['pdf']).name) + chr(39) + '>PDF</a>') if r.get('pdf') else _e(r.get('pdf_status') or '')
        extra = ""
        if rich:
            h, hl = r.get("event_heat"), r.get("event_heat_label") or ""
            extra = (f"<td>{_e(r.get('region') or '')}</td><td class='regime-{_e(r.get('regime') or '')}'>{_e(r.get('regime') or '')}</td>"
                     + _num_td(r.get("pd_default"), _pct(r.get("pd_default")) + (" (engine cap)" if at_pd_cap(r.get("pd_default")) else "")) + _num_td(r.get("composite"), _f(r.get("composite")))
                     + _num_td(h, (f"{h:.2f}x " if h is not None else "") + hl))
        li += (f"<tr data-region='{_e(r.get('region') or '')}' data-regime='{_e(r.get('regime') or '')}'><td><a href='{_e(Path(r['html']).name)}'>{_e(r.get('country') or r.get('scenario'))}</a></td>"
               f"{extra}<td>{_e(r.get('title'))}</td><td>{pdf}</td></tr>")
    filters = ("<div class='filters'><label>Filter <input id='q' type='search' placeholder='country, region, regime' aria-label='Filter rows'></label>"
               "<label>Region <select id='f-region' aria-label='Region'><option value=''>All</option></select></label>"
               "<label>Regime <select id='f-regime' aria-label='Regime'><option value=''>All</option></select></label>"
               f"<span id='shown' class='note'>{len(rows)} items</span></div>") if rich else ""
    return (f"<!doctype html><html lang='en'><head><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>{_e(title)}</title><style>{NOTE_CSS}{INDEX_CSS}</style></head><body><h1>{_e(title)}</h1>"
            f"<div class='meta'>{stamp_html(st)}</div><div class='disclaimer'><b>Disclaimer.</b> {_e(DISCLAIMER)}</div>{filters}"
            f"<table id='idx'><thead><tr>{head}</tr></thead><tbody>{li}</tbody></table>"
            + (f"<h2>Input caveats</h2>{caveats_html(cav)}" if cav else "") + (sources_html(src) if src else "")
            + (f"<script>{INDEX_JS}</script>" if rich else "") + "</body></html>")


def _client_safe_marker(data_dir):
    from .research import client_safe_marker
    return client_safe_marker(data_dir)


def _dsa_na(common: dict, data_dir) -> str:
    """The signal 26 n/a sentence. Built from a client-safe dataset (research.client_safe_marker; common carries it
    when _collect_common read it) it does not name WEO: "DSA not available in the client-safe dataset"."""
    from .research import CLIENT_SAFE_DSA_NA, client_safe_marker
    cs = common["client_safe"] if "client_safe" in common else client_safe_marker(data_dir)
    return f"n/a: {CLIENT_SAFE_DSA_NA}." if cs else "n/a: no WEO debt history for this country."


def result_bundle(kind: str, items: list[dict], st: dict, out_dir: Path, extra_paths: list[Path] = (), **more) -> dict:
    """The return shape shared by the note, brief and preview builders (editorial.files_from_result / meta_from_result):
    {"kind", "paths": [every file written that carries the disclaimer, PDFs included], "items", run_id, as_of, data_hash,
    code_hash, run_hash, code_version, "out_dir", ...}."""
    paths = []
    for it in items:
        paths += [x for x in (it.get("html"), it.get("pdf")) if x]
    paths += [str(p) for p in extra_paths]
    return {"kind": kind, "paths": paths, "items": items, **{k: st.get(k) for k in ("run_id", "as_of", "data_hash", "code_hash", "run_hash", "code_version")},
            "out_dir": str(out_dir), **more}


def build_country_notes(outputs_dir: str | Path, data_dir: str | Path, out_dir: str | Path, countries: list[str] | None = None, pdf: bool = False,
                        run: dict | None = None, chrome: str | None = None, recompute_pillars: bool = True, pdf_workers: int | None = None, log=print) -> dict:
    """Write one HTML note per country (all countries of the run when `countries` is None) to `out_dir`, plus a PDF of
    each when `pdf` and a Chrome/Chromium is found (skipped, with the reason in pdf_status, otherwise; `pdf_workers` browsers in parallel, default
    default_pdf_workers()). Also writes
    <out_dir>/index.html and <out_dir>/country-notes.json (manifest). Returns result_bundle(): "paths", "items" (one
    metadata dict per note: country, html, pdf, pdf_status, stamps) and the run stamps. Raises FileNotFoundError when
    there is no run, ValueError for a country the run does not have."""
    t0 = time.perf_counter()
    pdf_workers = pdf_workers or default_pdf_workers()
    outputs_dir, data_dir, out_dir = Path(outputs_dir), Path(data_dir), Path(out_dir)
    if run is None:
        run = load_latest(outputs_dir)
        if run is None:
            raise FileNotFoundError(f"no archived run in {outputs_dir / 'store'} and no {outputs_dir / 'run_latest.json'}: run `econquest run` first")
    if hasattr(run, "to_dict"):
        run = run.to_dict()
    names = [r["country"] for r in run.get("country") or []]
    if countries:
        lower = {n.lower(): n for n in names}
        bad = [c for c in countries if c.lower() not in lower]
        if bad:
            raise ValueError(f"not in the run: {', '.join(bad)} (countries: {', '.join(names)})")
        names = [lower[c.lower()] for c in countries]
    common = _collect_common(outputs_dir, data_dir, run, recompute_pillars, log)
    st = common["stamps"]
    out_dir.mkdir(parents=True, exist_ok=True)
    tag = st.get("as_of") or (st.get("created_at") or "")[:10] or "undated"
    items, htmls = [], []
    crows, heat = _by(run.get("country")), index_heat(common["events"])
    from .research import apply_block, client_safe_manifest, effective_mode    # EQ-C-0075 research block
    rstate = effective_mode(data_dir)
    for c in names:
        p = out_dir / f"country-note-{slug(c)}-{tag}.html"
        p.write_text(apply_block(render_country_note(c, run, common, data_dir), state=rstate), encoding="utf-8")
        htmls.append(p)
        items.append({"kind": "country_note", "country": c, "title": f"{c}: country risk note", "html": str(p), "pdf": None, "pdf_status": "not requested",
                      **{k: st.get(k) for k in ("run_id", "as_of", "data_hash", "code_hash", "run_hash", "code_version")},
                      "pillar_source": common["pillar_src"], "generated": common["generated"],
                      "region": (crows.get(c) or {}).get("region"), "regime": (crows.get(c) or {}).get("regime"),
                      "house_stance": _house_stance(common, c),
                      "pd_default": _fnum((crows.get(c) or {}).get("pd_default")), "composite": _fnum((crows.get(c) or {}).get("composite")),
                      "event_heat": (heat.get(c) or (None, ""))[0], "event_heat_label": (heat.get(c) or (None, "no feed" if common["events"]["status"] in ("missing", "invalid") else ""))[1]})
    t_html = time.perf_counter() - t0
    if pdf:
        for it, (pp, status) in zip(items, render_pdfs(htmls, chrome=chrome, workers=pdf_workers)):
            it["pdf"], it["pdf_status"] = pp, status
    index = out_dir / "index.html"
    index.write_text(apply_block(_index_html("EconQuest country notes", items, st, common["sources"], common["caveats"]), state=rstate), encoding="utf-8")
    elapsed = round(time.perf_counter() - t0, 2)
    manifest = out_dir / "country-notes.json"
    res = result_bundle("country_notes", items, st, out_dir, [index], manifest=str(manifest), elapsed_s=elapsed, html_s=round(t_html, 2),
                        **client_safe_manifest(rstate),                                     # EQ-C-0151
                        pdf_ok=sum(1 for i in items if i["pdf"]), pillar_source=common["pillar_src"], pdf_workers=pdf_workers if pdf else None,
                        events_status=common["events"]["status"], events_message=common["events"]["message"])
    manifest.write_text(json.dumps(res, indent=1), encoding="utf-8")
    log(f"[notes] {len(items)} notes in {elapsed:.1f}s (HTML {t_html:.1f}s" + (f", PDF {res['pdf_ok']}/{len(items)}: {items[0]['pdf_status'] if items else ''}" if pdf else "") + f") -> {out_dir}")
    return res
