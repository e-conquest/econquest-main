"""Client-mode build path (EQ-C-0107): BUILT AND KEPT OFF. Sam decided on 2026-10-25 at 11:29Z: client mode later, at
PI-9 with licensed data (EQ-C-0104/EQ-C-0105, ops/client_decision.py). This module is the path that turns on once he
applies the one governed change, research.json mode "client" through `econquest change`, and licences allow it:

    econquest client-export --recipient ADDR --date YYYY-MM-DD [--actor NAME]          entitlement-scoped export
    econquest client-export --recipient ADDR --date YYYY-MM-DD --workbook [--plan F]   client-safe workbook variant
    econquest client-export --verify-log                                               check the distribution log

Every path starts with `gate` and refuses unless ALL of these hold (each is the existing control, reused):
1. research.effective_mode is "client": research.json says client, its bytes are the last applied `econquest change`
   approved by Sam (DECISION_OWNER), the approvals chain verifies, no applied cell carries IMF / WEO data, and licence
   enforcement (presentation/licences.evaluate via research.effective_mode) allows every source in use;
2. that change has an approval record (research.client_approval);
3. the licence register is under change control (licences.register_governed; R44, EQ-C-0106).
On today's data every path refuses at 1 (mode internal) and also names 3. Nothing here changes a setting, a licence
or a credential; nothing is sent and nothing is published.

Entitlement-scoped export: every published editorial item whose kind is in the recipient's research.json
entitlements (and nothing else), each through client_package.package (IMF and licence guards, watermark) with a
per-file watermark id, under <out>/client/exports/<recipient-slug>/<date>/. One distribution-log row per item
(ops/client_distribution.py, hash-chained like the delivery log).

Client-safe workbook variant: the Sheets publish plan (<out>/publish_plan.json) rebuilt for a recipient entitled to
"workbook": refused while licence enforcement lists any internal-only cell, text cells escaped (common_format
sanitize_plan), plus a 'Client Notice' block (watermark line and id, client and core disclaimers, attribution lines).
Written to <out>/client/workbook/<slug>/<date>/client_workbook_plan.json as {"never_published": true, ..., "blocks"},
which is not a plan apply_plan takes. This module has no Sheets call and never publishes.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
from pathlib import Path

TICKET = "EQ-C-0107"
WORKBOOK_KIND = "workbook"
NOTICE_TAB = "Client Notice"
MAX_PLAN_BYTES = 50_000_000
OFF_TEXT = ("client mode is off: research.json mode is internal (Sam's decision 2026-10-25 11:29Z: client mode later, at "
            "PI-9 with licensed data; turning it on is Sam's approved `econquest change` on data/research.json)")


class ClientBuildError(ValueError):
    """A refused client build (gate closed, not entitled, nothing to export, unsafe plan)."""


def _sha_file(p: Path) -> str | None:
    try:
        return hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() and not p.is_symlink() else None
    except OSError:
        return None


def gate(data_dir) -> dict:
    """{"ok", "problems", "state"}: ok only with client mode approved and applied, licences allowing client output and
    the register governed. Never raises; any doubt is a problem (fails closed)."""
    from .licences import refusals, register_governed
    from .research import effective_mode
    try:
        st = effective_mode(data_dir)
    except Exception as e:                                   # noqa: BLE001 - cannot tell: closed
        return {"ok": False, "problems": [f"research mode could not be read ({type(e).__name__}); refused"], "state": None}
    probs: list[str] = []
    if st["mode"] != "client":
        probs.append(OFF_TEXT)
        probs += [p for p in st.get("problems") or []][:3]
    if not st.get("approval"):
        probs.append("no applied `econquest change` on research.json approved by Sam")
    lic = st.get("licences") or {}
    if not lic.get("client_ok"):
        probs += ["licence enforcement refuses client output: " + r for r in refusals(lic, limit=3)]
    try:
        governed = register_governed(data_dir)
    except Exception:                                        # noqa: BLE001
        governed = False
    if not governed:
        probs.append("data/licences.csv is not under change control (R44, EQ-C-0106): client_ok rows are not trusted")
    return {"ok": not probs, "problems": probs, "state": st}


def _open(data_dir) -> dict:
    from ..ops.licence_gov import demo_refusal
    if (why := demo_refusal("client build")):            # EQ-C-0123: never on a DEMO licence baseline
        raise ClientBuildError(why)
    g = gate(data_dir)
    if not g["ok"]:
        raise ClientBuildError("client build refused: " + "; ".join(g["problems"][:6]))
    return g["state"]


def _recipient(st: dict, recipient: str) -> tuple[str, list[str]]:
    from ..ops.distribute import DistributionError, check_address
    try:
        rcpt = check_address(recipient, "recipient")
    except DistributionError as e:
        raise ClientBuildError(str(e)) from None
    kinds = (st["config"].get("entitlements") or {}).get(rcpt.casefold(), [])
    return rcpt, list(kinds)


def _slug(rcpt: str) -> str:
    import re
    s = re.sub(r"[^a-z0-9]+", "-", rcpt.casefold())
    return s + "-" + hashlib.sha256(rcpt.casefold().encode("utf-8")).hexdigest()[:8]


def _rel(out: Path, p: Path) -> str:
    try:
        return str(p.resolve().relative_to(out.resolve()))
    except ValueError:
        return p.name


def _common(st: dict, data_dir) -> dict:
    return {"approval_id": (st.get("approval") or {}).get("id", ""), "research_sha256": st["config"].get("sha256") or "",
            "licences_sha256": _sha_file(Path(data_dir) / "licences.csv") or ""}


def _no_simulated(outputs_dir, where: str) -> None:
    """EQ-C-0146 (HO-20261026-A-C-003): refuse when the run the client output is built from (run_latest.json's country
    table) carries a SIMULATED value from Team A's vendor simulator."""
    from ..ingestion.market.vendor_sim_guard import SimulatedDataError
    from ..ops.vendor_rehearse import refuse_simulated_run
    try:
        refuse_simulated_run(outputs_dir, where)
    except SimulatedDataError as e:
        raise ClientBuildError(str(e)) from None


def _require_log(outputs_dir) -> None:
    from ..ops import client_distribution as L
    v = L.verify(outputs_dir)
    if not v["ok"]:
        raise ClientBuildError("client distribution log failed verification, refusing: " + "; ".join(v["errors"][:3]))


def entitled_export(outputs_dir, data_dir, recipient: str, date: dt.date, actor: str = "") -> dict:
    """Package every published item the recipient is entitled to (only those), watermarked with per-file ids, and log
    one distribution row per item. ClientBuildError before anything is written when refused."""
    from ..ops import client_distribution as L
    from ..ops.distribute import DistributionError, _client_item_problems, _published
    from . import editorial as E
    from .client_package import ClientPackageError, package
    st = _open(data_dir)
    rcpt, kinds = _recipient(st, recipient)
    kinds = [k for k in kinds if k in E.KINDS]
    if not kinds:
        raise ClientBuildError(f"{rcpt} has no product entitlement in data/research.json")
    out = Path(outputs_dir)
    items = [i for i in E.list_items(out, state="published") if i["kind"] in kinds]
    if not items:
        raise ClientBuildError(f"no published item of the kinds {rcpt} is entitled to ({', '.join(kinds)})")
    base = out / "client" / "exports" / _slug(rcpt) / date.isoformat()
    if base.exists() or base.is_symlink():
        raise ClientBuildError(f"an export for {rcpt} on {date.isoformat()} already exists (see the distribution log)")
    _require_log(out)
    _no_simulated(out, "client_build export")
    for it in items:                                         # every guard first: all items go, or none is written
        try:
            _published(out, it["item_id"])
        except DistributionError as e:
            raise ClientBuildError(str(e)) from None
        probs = _client_item_problems(out, data_dir, it)
        if probs:
            raise ClientBuildError(f"{it['item_id']}: " + "; ".join(probs[:4]))
    done, rows = [], []
    for it in items:
        try:
            r = package(out, data_dir, it["item_id"], rcpt, date, dest=base / it["item_id"], trace=True)
        except ClientPackageError as e:
            raise ClientBuildError(f"{it['item_id']}: {e} (items already written: {[d['item_id'] for d in done]})") from None
        done.append(r)
        rows.append(L.append(out, "client_export", item_id=it["item_id"], kind=it["kind"], recipient=rcpt, actor=actor,
                             files=r["files"], dir=_rel(out, Path(r["dir"])), **_common(st, data_dir)))
    man = {"ticket": TICKET, "recipient": rcpt, "date": date.isoformat(), "entitled_kinds": kinds,
           "items": [{"item_id": r["item_id"], "kind": r["kind"], "files": r["files"]} for r in done],
           "log_seqs": [x["seq"] for x in rows], **_common(st, data_dir)}
    (base / "export-manifest.json").write_text(json.dumps(man, indent=1), encoding="utf-8")
    return {**man, "dir": str(base), "log_rows": rows}


def _load_plan(p: Path) -> list[dict]:
    if p.is_symlink() or not p.is_file():
        raise ClientBuildError(f"{p.name} is missing or a symlink: run `econquest publish` (dry run) first")
    if p.stat().st_size > MAX_PLAN_BYTES:
        raise ClientBuildError(f"{p.name} is larger than {MAX_PLAN_BYTES} bytes")
    try:
        plan = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        raise ClientBuildError(f"{p.name} is not readable JSON ({type(e).__name__})") from None
    if not isinstance(plan, list) or not all(isinstance(b, dict) and isinstance(b.get("range"), str)
                                             and isinstance(b.get("values"), list) for b in plan):
        raise ClientBuildError(f"{p.name} is not a publish plan (a list of {{range, values}} blocks)")
    return plan


def client_workbook(outputs_dir, data_dir, recipient: str, date: dt.date, plan_path=None, actor: str = "") -> dict:
    """The client-safe variant of the Sheets publish plan for an entitled recipient. Never published (see module doc)."""
    from ..common_format import sanitize_plan
    from ..ops import client_distribution as L
    from .client_package import watermark_id
    from .licences import internal_groups, summary
    from .report import DISCLAIMER
    st = _open(data_dir)
    rcpt, kinds = _recipient(st, recipient)
    if WORKBOOK_KIND not in kinds:
        raise ClientBuildError(f"{rcpt} is not entitled to {WORKBOOK_KIND} (data/research.json entitlements)")
    ev = st["licences"]
    if ev.get("internal_only") or not ev.get("client_ok"):                  # defence in depth: the gate already refused
        n = sum(len(g["countries"]) for g in internal_groups(ev))
        raise ClientBuildError(f"licence enforcement lists {n} internal-only cells: no client workbook")
    out = Path(outputs_dir)
    src = Path(plan_path) if plan_path else out / "publish_plan.json"
    plan = _load_plan(src)
    plan_sha = _sha_file(src) or ""
    if any(b["range"].strip("'").startswith(NOTICE_TAB) for b in plan):
        raise ClientBuildError(f"the plan already writes the '{NOTICE_TAB}' tab")
    _require_log(out)
    _no_simulated(out, "client_build workbook")
    mid = watermark_id(rcpt, date.isoformat(), WORKBOOK_KIND, plan_sha)
    lines = [f"Prepared for {rcpt} on {date.isoformat()}. Not for onward distribution. Copy {mid}.",
             (st["config"].get("disclaimer") or {}).get("client", ""), DISCLAIMER,
             *[f"Source: {a}" for a in ev.get("attribution") or []]]
    notice = {"range": f"'{NOTICE_TAB}'!A1:A{len(lines)}", "values": [[x] for x in lines]}
    blocks = sanitize_plan([notice, *plan])
    dest = out / "client" / "workbook" / _slug(rcpt) / date.isoformat()
    if dest.exists() or dest.is_symlink():
        raise ClientBuildError(f"a client workbook for {rcpt} on {date.isoformat()} already exists (see the distribution log)")
    dest.mkdir(parents=True)
    doc = {"never_published": True, "ticket": TICKET, "recipient": rcpt, "date": date.isoformat(), "watermark_id": mid,
           "source_plan": src.name, "source_plan_sha256": plan_sha, "licences": summary(ev),
           "note": "Client-safe variant of the publish plan. Not a plan for apply_plan; never written to any workbook.",
           "blocks": blocks}
    data = json.dumps(doc, indent=0).encode("utf-8")
    f = dest / "client_workbook_plan.json"
    f.write_bytes(data)
    files = [{"name": f.name, "sha256": hashlib.sha256(data).hexdigest(), "watermark_id": mid}]
    row = L.append(out, "client_workbook", item_id=WORKBOOK_KIND, kind=WORKBOOK_KIND, recipient=rcpt, actor=actor,
                   files=files, dir=_rel(out, dest), note=f"from {src.name} sha256 {plan_sha[:16]}", **_common(st, data_dir))
    return {"dir": str(dest), "file": str(f), "watermark_id": mid, "blocks": len(blocks), "files": files, "log_row": row}


# ---------------------------------------------------------------- CLI
def cmd_client_export(args) -> None:
    from ..ops import client_distribution as L
    if args.verify_log:
        v = L.verify(args.out)
        print(json.dumps(v, indent=1) if args.json else
              (f"client distribution log: {v['rows']} rows, " + ("chain ok" if v["ok"] else "BROKEN: " + "; ".join(v["errors"][:5]))))
        if not v["ok"]:
            raise SystemExit(1)
        return
    if not args.recipient or not args.date:
        raise SystemExit("client-export needs --recipient and --date (or --verify-log)")
    try:
        day = dt.date.fromisoformat(args.date)
        if args.workbook:
            r = client_workbook(args.out, args.data, args.recipient, day, args.plan, args.actor or "")
        else:
            r = entitled_export(args.out, args.data, args.recipient, day, args.actor or "")
    except ValueError as e:                                  # ClientBuildError, ClientPackageError, bad date
        raise SystemExit(f"client-export: {e}") from None
    print(json.dumps({k: v for k, v in r.items() if k not in ("log_rows", "log_row")}, indent=1, default=str) if args.json
          else f"Client build written to {r['dir']}; distribution log updated.")


def register(sub) -> None:
    """client-export, added by cli.main."""
    p = sub.add_parser("client-export", help="client-mode build path, OFF until Sam approves client mode (EQ-C-0107): "
                       "entitlement-scoped watermarked export, or the client-safe workbook variant (never published), each "
                       "logged in a hash-chained client distribution log; refuses while research mode is internal")
    p.add_argument("--recipient", metavar="ADDR")
    p.add_argument("--date", metavar="YYYY-MM-DD")
    p.add_argument("--workbook", action="store_true", help="build the client-safe workbook variant instead of the export")
    p.add_argument("--plan", metavar="FILE", help="publish plan to start from (default: <out>/publish_plan.json)")
    p.add_argument("--actor", metavar="NAME", help="who builds this delivery (logged)")
    p.add_argument("--verify-log", action="store_true", help="check the client distribution log's hash chain; exit 1 on a break")
    p.add_argument("--json", action="store_true")
    p.set_defaults(fn=cmd_client_export)
