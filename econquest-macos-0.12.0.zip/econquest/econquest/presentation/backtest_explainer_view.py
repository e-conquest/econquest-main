"""Backtest explainer section of the INTERIM backtest page (EQ-C-0166, HO-20261026-B-C-018 asks 1-3; contract C18).

Team B's backtest explainer (validation.backtest_explainer, EQ-B-0141, schema eq-backtest-explainer/1) writes
<out>/backtest_explainer/: backtest_explainer.json (label, summary, checks, pnl_summary, gaps), exceptions.csv,
rolling.csv and pnl_attribution.csv. This module only reads those files and formats them; it computes no statistic.

    explainer_page(out_dir) -> dict          read only: the "explainer" part of the INTERIM backtest payload
                                             (ops/interim_backtest.page, GET /api/readiness), never runs the explainer
    section_html(p) / page_document(p)       the same section as escaped HTML (every value through html.escape)
    demo_explainer_page(out_dir, as_of, data_dir=None, step=21) -> {"ok", "problems", "summary", ...}   demo row M22
    econquest backtest-explain --as-of YYYY-MM-DD [--out DIR] [--step N]   Team B's main(argv), then writes the page

What the section shows, per HO-20261026-B-C-018:
  * per exception: the book row (recorded vs reconstructed loss and VaR99), the inputs_status badge, the residual row
    (recorded minus reconstructed) and the top countries and factors by excess over VaR (Team B's rank);
  * rolling: the book's recorded and reconstructed lines, and the country and factor exception counts against the 95%
    binomial band in the longest window (250 = to date), with the rows' label;
  * P&L: recorded vs explained per record day, and the summary (share of variance explained, days reconciled);
  * the gaps list, verbatim.
The record stores the book totals only, so every attribution is a reconstruction on today's inputs. A day whose
reconstruction does not reproduce the record (inputs_status not_recorded_reconstruction_unreconciled) is shown as
"reconstruction, does not explain the recorded loss", with its residual row, and its contributor tables are headed as a
description of the day on today's inputs, never as the explanation of the recorded breach. Everything carries the
INTERIM label. No clock, no network; paths on the payload are relative to the outputs folder.
"""
from __future__ import annotations

import csv
import html
import json
import math
import sys
from pathlib import Path

TICKET = "EQ-C-0166"
HANDOFF = "HO-20261026-B-C-018"
SCHEMA = "eq-backtest-explainer/1"            # contract C18 (team/contracts.md)
SUBDIR = "backtest_explainer"                 # Team B's folder under the outputs folder
FILES = {"json": "backtest_explainer.json", "exceptions": "exceptions.csv", "rolling": "rolling.csv",
         "pnl": "pnl_attribution.csv"}
PAGE_DIR = "backtest_explainer_view"           # the written page (demo row M22, the CLI): never inside Team B's folder
PAGE_FILE = "backtest_explainer.html"
STATUS_RECONCILED = "not_recorded_reconstructed_reconciled"
STATUS_UNRECONCILED = "not_recorded_reconstruction_unreconciled"
STATUS_NO_PRICES = "not_recorded_no_prices"
STATUS_TEXT = {STATUS_RECONCILED: "reconciled: the reconstruction reproduces the recorded loss and VaR99",
               STATUS_UNRECONCILED: "reconstruction, does not explain the recorded loss",
               STATUS_NO_PRICES: "no prices for the day: not reconstructed, does not explain the recorded loss"}
DEFAULT_LABEL = "INTERIM, not the formal test"
COMMAND = "econquest backtest-explain --as-of YYYY-MM-DD"
KNOWN_UNRECONCILED = ("2026-09-23",)           # HO-20261026-B-C-018: the one recorded exception does NOT reconcile
TOP_N = 5
MAX_POINTS = 500
MAX_JSON_BYTES = 20_000_000
EMPTY_TEXT = (f"No backtest explainer output yet, so there is nothing to show; {COMMAND} (about a minute) writes "
              f"{SUBDIR}/ and this section then reads it.")


# ---------------------------------------------------------------- reading
def _num(v):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    return f if math.isfinite(f) else None


def _int(v):
    f = _num(v)
    return None if f is None else int(f)


def _s(v, n: int = 2000) -> str:
    return "" if v is None else str(v)[:n]


def _csv(p: Path) -> list[dict]:
    if not p.is_file():
        return []
    with open(p, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def _fmt(v, nd: int = 4) -> str:
    f = _num(v)
    return "n/a" if f is None else f"{f:.{nd}f}"


def _contrib(r: dict) -> dict:
    return {"item": _s(r.get("item"), 120), "country": _s(r.get("country"), 120), "factor_type": _s(r.get("factor_type"), 40),
            "exposure_mm": _num(r.get("exposure_mm")), "realised_loss_mm": _num(r.get("realised_loss_mm")),
            "forecast_var99_mm": _num(r.get("forecast_var99_mm")), "excess_over_var_mm": _num(r.get("excess_over_var_mm")),
            "rank": _int(r.get("rank"))}


def _top(rows: list[dict], level: str) -> list[dict]:
    xs = [r for r in rows if r.get("level") == level and _int(r.get("rank")) is not None]
    return [_contrib(r) for r in sorted(xs, key=lambda r: _int(r.get("rank")))[:TOP_N]]


def _exception(c: dict, rows: list[dict], label: str) -> dict:
    d = _s(c.get("date"), 10)
    day = [r for r in rows if r.get("date") == d]
    book = next((r for r in day if r.get("level") == "book"), {})
    res = next((r for r in day if r.get("level") == "residual"), None)
    status = _s(book.get("inputs_status") or c.get("status"), 80)
    reconciled = status == STATUS_RECONCILED
    rl, rv = _num(c.get("recorded_loss_mm", book.get("recorded_loss_mm"))), _num(c.get("recorded_var99_mm", book.get("recorded_var99_mm")))
    xl = _num(c.get("reconstructed_loss_mm", book.get("realised_loss_mm")))
    xv = _num(c.get("reconstructed_var99_mm", book.get("forecast_var99_mm")))
    if reconciled:
        headline = (f"{d}: reconciled: the reconstruction reproduces the recorded loss {_fmt(rl)} and VaR99 {_fmt(rv)} $mm, "
                    "so the rows below explain the recorded exception.")
    else:
        headline = (f"{d}: {STATUS_TEXT.get(status, 'not reconciled: does not explain the recorded loss')} "
                    f"(inputs_status {status or 'not given'}). Recorded loss {_fmt(rl)} vs VaR99 {_fmt(rv)} $mm; reconstructed "
                    f"on today's inputs: loss {_fmt(xl)} vs VaR99 {_fmt(xv)} $mm. The rows below describe the day on today's "
                    "inputs, not the recorded breach; the residual row (recorded minus reconstructed) carries the difference.")
    return {"date": d, "prev_date": _s(book.get("prev_date"), 10), "inputs_status": status,
            "status_text": STATUS_TEXT.get(status, status or "not given"), "reconciled": reconciled,
            "explains_recorded_loss": reconciled, "headline": headline, "label": _s(book.get("label") or label, 300),
            "book": {"recorded_loss_mm": rl, "recorded_var99_mm": rv, "reconstructed_loss_mm": xl,
                     "reconstructed_var99_mm": xv, "reconstructed_es99_mm": _num(book.get("forecast_es99_mm")),
                     "exposure_mm": _num(book.get("exposure_mm")), "loss_gap_mm": _num(c.get("loss_gap_mm")),
                     "var_gap_mm": _num(c.get("var_gap_mm")), "basis": _s(book.get("basis"), 400),
                     "note": _s(book.get("note"), 1200)},
            "residual": None if res is None else {
                "item": _s(res.get("item"), 120), "loss_mm": _num(res.get("realised_loss_mm")),
                "var99_mm": _num(res.get("forecast_var99_mm")), "es99_mm": _num(res.get("forecast_es99_mm")),
                "basis": _s(res.get("basis"), 300), "note": _s(res.get("note"), 600)},
            "top_countries": _top(day, "country"), "top_factors": _top(day, "factor"),
            "contributors_heading": ("Top contributors (explain the recorded exception)" if reconciled else
                                     "Top contributors on today's inputs (a reconstruction, NOT the explanation of the "
                                     "recorded breach)")}


def _point(r: dict) -> dict:
    return {"end_date": _s(r.get("end_date"), 10), "n": _int(r.get("n")), "exceptions": _int(r.get("exceptions")),
            "expected": _num(r.get("expected")), "band_low": _int(r.get("band_low")), "band_high": _int(r.get("band_high")),
            "band_status": _s(r.get("band_status"), 40), "exception_rate": _num(r.get("exception_rate")),
            "kupiec_p": _num(r.get("kupiec_p"))}


def _window_text(w: int | None, longest: int | None) -> str:
    return "n/a" if w is None else f"{w} (to date)" if w == longest and w >= 250 else f"{w} days"


def _rolling(rows: list[dict]) -> dict:
    windows = sorted({w for w in (_int(r.get("window")) for r in rows) if w is not None})
    longest = windows[-1] if windows else None
    lines = []
    for w in windows:
        book = [r for r in rows if _int(r.get("window")) == w and r.get("group_type") == "book"]
        lines.append({"window": w, "window_text": _window_text(w, longest),
                      "recorded": [_point(r) for r in book if r.get("group") == "recorded"][-MAX_POINTS:],
                      "reconstructed": [_point(r) for r in book if r.get("group") == "reconstructed"][-MAX_POINTS:]})
    counts = []
    for gt in ("country", "factor"):
        last: dict[str, dict] = {}
        for r in rows:
            if _int(r.get("window")) == longest and r.get("group_type") == gt:
                g = _s(r.get("group"), 120)
                if g not in last or _s(r.get("end_date")) >= _s(last[g].get("end_date")):
                    last[g] = r
        for g in sorted(last):
            r = last[g]
            counts.append({"group_type": gt, "group": g, **_point(r), "label": _s(r.get("label"), 300),
                           "basis": _s(r.get("basis"), 300)})
    labels = sorted({_s(r.get("label"), 300) for r in rows if r.get("label")})
    return {"windows": windows, "count_window": longest, "count_window_text": _window_text(longest, longest),
            "lines": lines, "counts": counts, "labels": labels,
            "above_band": [f"{c['group_type']} {c['group']}" for c in counts if c["band_status"] == "above band"]}


def _pnl(rows: list[dict], summ: dict) -> dict:
    days = [{"date": _s(r.get("date"), 10), "recorded_loss_mm": _num(r.get("recorded_loss_mm")),
             "explained_mm": _num(r.get("explained_mm")), "unexplained_mm": _num(r.get("unexplained_mm")),
             "explained_share": _num(r.get("explained_share"))} for r in rows if r.get("level") == "book"][-MAX_POINTS:]
    s = summ or {}
    text = (f"{_int(s.get('days_explained'))} of {_int(s.get('days'))} days explained on current prices; share of variance "
            f"explained {_fmt(s.get('share_of_variance_explained'), 3)}; correlation recorded vs explained "
            f"{_fmt(s.get('correlation_recorded_explained'), 3)}; largest unexplained {_fmt(s.get('max_abs_unexplained_mm'))} $mm "
            f"on {_s(s.get('max_abs_unexplained_date'), 10) or 'n/a'}; {_int(s.get('days_reconciled'))} days reconciled.")
    labels = sorted({_s(r.get("label"), 300) for r in rows if r.get("label")})
    return {"days": days, "summary": {k: (v if isinstance(v, (int, float, str)) or v is None else str(v))
                                      for k, v in s.items()}, "summary_text": text, "labels": labels}


def explainer_page(out_dir) -> dict:
    """Read-only payload of the section. status ok | missing | unreadable; never raises, never writes."""
    d = Path(out_dir) / SUBDIR
    base = {"kind": "INTERIM", "ticket": TICKET, "schema": SCHEMA, "command": COMMAND, "label": DEFAULT_LABEL,
            "source": f"outputs/{SUBDIR}/{FILES['json']} (Team B, EQ-B-0141)"}
    jp = d / FILES["json"]
    if not jp.is_file():
        return base | {"status": "missing", "exceptions": [], "gaps": [], "message": EMPTY_TEXT}
    try:
        if jp.stat().st_size > MAX_JSON_BYTES:
            raise ValueError(f"{FILES['json']} is larger than {MAX_JSON_BYTES} bytes")
        meta = json.loads(jp.read_text(encoding="utf-8"))
        if not isinstance(meta, dict) or meta.get("schema") != SCHEMA:
            raise ValueError(f"schema {meta.get('schema') if isinstance(meta, dict) else '?'!r} is not {SCHEMA}")
        label = _s(meta.get("label") or DEFAULT_LABEL, 300)
        xrows = _csv(d / FILES["exceptions"])
        exc = [_exception(c, xrows, label) for c in meta.get("checks") or [] if isinstance(c, dict)]
        rolling = _rolling(_csv(d / FILES["rolling"]))
        pnl = _pnl(_csv(d / FILES["pnl"]), meta.get("pnl_summary") or {})
    except (OSError, ValueError, csv.Error) as e:
        return base | {"status": "unreadable", "exceptions": [], "gaps": [],
                       "message": f"The backtest explainer output could not be read ({type(e).__name__}: {_s(e, 200)}); "
                                  f"rerun {COMMAND}."}
    s = meta.get("summary") or {}
    bad = [x for x in exc if not x["reconciled"]]
    msg = (f"{label}: {len(exc)} VaR99 exception(s) in {_int(s.get('clean_days'))} clean days, "
           f"{len(exc) - len(bad)} reconciled")
    msg += (f"; NOT explained: {', '.join(x['date'] for x in bad)} "
            f"({'does' if len(bad) == 1 else 'do'} not reconcile: the reconstruction does not explain the recorded loss)."
            if bad else ".")
    return base | {"status": "ok", "label": label, "as_of": _s(meta.get("as_of"), 10), "summary": {
        k: s.get(k) for k in ("clean_days", "exceptions", "exception_dates", "first_day", "last_day", "step",
                              "reconciled_exceptions") if k in s},
        "exceptions": exc, "unreconciled": [x["date"] for x in bad], "rolling": rolling, "pnl": pnl,
        "gaps": [_s(g, 2000) for g in meta.get("gaps") or []], "problems": [_s(p, 400) for p in meta.get("problems") or []],
        "message": msg}


# ---------------------------------------------------------------- HTML (every value escaped)
def _e(v) -> str:
    return html.escape("" if v is None else str(v), quote=True)


def _td(v, nd: int = 4) -> str:
    return f"<td>{_e(_fmt(v, nd) if isinstance(v, float) or v is None else v)}</td>"


def _table(head: list[str], body: list[list]) -> str:
    h = "".join(f"<th>{_e(x)}</th>" for x in head)
    b = "".join("<tr>" + "".join(_td(c) for c in r) + "</tr>" for r in body)
    return f"<table><thead><tr>{h}</tr></thead><tbody>{b}</tbody></table>"


def section_html(p: dict) -> str:
    """The section as an HTML fragment; every value from the files goes through html.escape."""
    lab = _e(p.get("label") or DEFAULT_LABEL)
    if p.get("status") != "ok":
        return (f'<section class="bx"><h3>Backtest explainer <b>{lab}</b></h3>'
                f'<p class="empty">{_e(p.get("message"))} <code>{_e(p.get("command") or COMMAND)}</code></p></section>')
    L = [f'<section class="bx"><h3>Backtest explainer (as of {_e(p.get("as_of"))}) <b>{lab}</b></h3>',
         f"<p><b>{_e(p.get('message'))}</b> Source <code>{_e(p.get('source'))}</code>. Every attribution is a "
         "reconstruction on today's inputs: the record holds the book totals only.</p>"]
    for x in p.get("exceptions") or []:
        b, r = x["book"], x.get("residual")
        badge = "reconciled" if x["reconciled"] else "NOT RECONCILED"
        L += [f'<h4>Exception {_e(x["date"])} <span class="rd-met {"yes" if x["reconciled"] else "no"}">{_e(badge)}</span> '
              f'<span class="chip">inputs_status: <b>{_e(x["inputs_status"])}</b></span></h4>',
              f"<p><b>{_e(x['headline'])}</b></p>",
              _table(["row", "loss $mm", "VaR99 $mm", "ES99 $mm", "basis"],
                     [["recorded (the record)", b["recorded_loss_mm"], b["recorded_var99_mm"], None, "data/forecast_record.csv"],
                      ["reconstructed (today's inputs)", b["reconstructed_loss_mm"], b["reconstructed_var99_mm"],
                       b["reconstructed_es99_mm"], b["basis"]]]
                     + ([[f"residual: {r['item']}", r["loss_mm"], r["var99_mm"], r["es99_mm"], r["basis"]]] if r else [])),
              f'<p class="note">{_e(x["label"])}. {_e(b["note"])}</p>']
        for title, rows in ((f"{x['contributors_heading']}: countries", x["top_countries"]),
                            (f"{x['contributors_heading']}: factors", x["top_factors"])):
            if rows:
                L += [f"<h5>{_e(title)}</h5>",
                      _table(["rank", "item", "realised loss $mm", "component VaR99 $mm", "excess over VaR $mm"],
                             [[c["rank"], c["item"], c["realised_loss_mm"], c["forecast_var99_mm"], c["excess_over_var_mm"]]
                              for c in rows])]
    ro = p.get("rolling") or {}
    L.append(f"<h4>Rolling backtests <b>{lab}</b></h4>")
    L += [f'<p class="note">Labels: {_e("; ".join(ro.get("labels") or []) or DEFAULT_LABEL)}</p>']
    for ln in ro.get("lines") or []:
        last_rec = (ln.get("recorded") or [{}])[-1]
        last_rx = (ln.get("reconstructed") or [{}])[-1]
        L.append(_table([f"book, window {ln['window_text']}", "end date", "n", "exceptions", "expected", "95% band",
                         "band status"],
                        [[name, q.get("end_date"), q.get("n"), q.get("exceptions"), q.get("expected"),
                          f"{q.get('band_low')}-{q.get('band_high')}", q.get("band_status")]
                         for name, q in (("recorded line (latest)", last_rec), ("reconstructed line (latest)", last_rx)) if q]))
    if ro.get("counts"):
        L += [f"<h5>Exception counts against the band, window {_e(ro.get('count_window_text'))}</h5>",
              _table(["group", "item", "n", "exceptions", "expected", "95% band", "band status", "label"],
                     [[c["group_type"], c["group"], c["n"], c["exceptions"], c["expected"],
                       f"{c['band_low']}-{c['band_high']}", c["band_status"], c["label"]] for c in ro["counts"]])]
    pn = p.get("pnl") or {}
    L += [f"<h4>P&amp;L attribution: recorded vs explained <b>{lab}</b></h4>", f"<p><b>{_e(pn.get('summary_text'))}</b></p>",
          f'<p class="note">Labels: {_e("; ".join(pn.get("labels") or []) or DEFAULT_LABEL)}</p>',
          _table(["date", "recorded loss $mm", "explained $mm", "unexplained $mm", "explained share"],
                 [[q["date"], q["recorded_loss_mm"], q["explained_mm"], q["unexplained_mm"], q["explained_share"]]
                  for q in pn.get("days") or []])]
    L += ["<h4>Gaps (Team B, verbatim)</h4>", "<ul>" + "".join(f"<li>{_e(g)}</li>" for g in p.get("gaps") or []) + "</ul>",
          f"<p class=\"note\">{lab}. Not a formal test result.</p></section>"]
    return "\n".join(L)


def page_document(p: dict) -> str:
    """A standalone page (demo row M22, the CLI) with the meta CSP for its exact content (csp.harden)."""
    from .csp import harden
    doc = ("<!doctype html>\n<html lang=\"en\"><head><meta charset=\"utf-8\"><title>Backtest explainer (INTERIM)</title>"
           "</head><body>\n" + section_html(p) + "\n</body></html>\n")
    return harden(doc)


def write_page(out_dir, p: dict | None = None) -> Path:
    """<out_dir>/backtest_explainer_view/backtest_explainer.html from explainer_page(out_dir) (or p)."""
    p = explainer_page(out_dir) if p is None else p
    dest = Path(out_dir) / PAGE_DIR
    dest.mkdir(parents=True, exist_ok=True)
    f = dest / PAGE_FILE
    tmp = f.with_name("." + f.name + ".tmp")
    tmp.write_text(page_document(p), encoding="utf-8")
    tmp.replace(f)
    return f


def page_lines(p: dict) -> list[str]:
    """Plain-text lines for `econquest targets --explain` and the CLI."""
    if p.get("status") != "ok":
        return [f"Backtest explainer ({DEFAULT_LABEL}): {p.get('message', '')}"]
    L = [f"Backtest explainer: {p.get('message')}"]
    L += [f"    {x['headline']}" for x in p.get("exceptions") or []]
    L.append(f"    P&L: {(p.get('pnl') or {}).get('summary_text', '')}")
    L += [f"    gap: {g}" for g in p.get("gaps") or []]
    return L


# ---------------------------------------------------------------- demo row M22
def demo_explainer_page(out_dir, as_of, data_dir=None, step: int = 21) -> dict:
    """Demo row M22: Team B's demo_backtest_explainer(out_dir, as_of, data_dir, step) (about a minute), then this page
    on its files, written to <out_dir>/backtest_explainer_view/. ok when Team B's run is ok, the page reads, every
    exception shows its inputs_status, each unreconciled day is shown as not explaining the recorded loss, and each
    KNOWN_UNRECONCILED day up to as_of is present and shown unreconciled. Never raises on a failed check."""
    from .csp import inline_problems
    problems: list[str] = []
    try:
        from ..validation.backtest_explainer import demo_backtest_explainer
    except ImportError:
        return {"ok": False, "pending": True, "problems": [],
                "summary": "pending: not landed (econquest.validation.backtest_explainer, Team B EQ-B-0141)"}
    out = Path(out_dir)
    try:
        r = demo_backtest_explainer(out, as_of, data_dir=data_dir, step=step)
    except Exception as e:                                  # noqa: BLE001 - reported, never a silent pass
        r = {"ok": False, "problems": [f"demo_backtest_explainer raised {type(e).__name__}: {_s(e, 300)}"]}
    problems += [f"Team B: {_s(x, 300)}" for x in r.get("problems") or []]
    if not r.get("ok") and not r.get("problems"):
        problems.append("Team B's demo_backtest_explainer did not report ok")
    p = explainer_page(out)
    page = None
    if p["status"] != "ok":
        problems.append(f"page: {p['message']}")
    else:
        page = write_page(out, p)
        text = page.read_text(encoding="utf-8")
        problems += [f"page: {x}" for x in inline_problems(text)]
        for x in p["exceptions"]:
            if not x["inputs_status"]:
                problems.append(f"page: exception {x['date']} has no inputs_status")
            elif _e(x["inputs_status"]) not in text:
                problems.append(f"page: exception {x['date']} inputs_status not shown")
            if not x["reconciled"] and not (_e(STATUS_TEXT.get(x["inputs_status"], "does not explain")) in text
                                            and x["residual"] is not None):
                problems.append(f"page: unreconciled {x['date']} not shown as not explaining the recorded loss with its residual row")
        dates = {x["date"]: x for x in p["exceptions"]}
        for d in KNOWN_UNRECONCILED:
            if str(d) <= str(p.get("as_of") or as_of):
                if d not in dates:
                    problems.append(f"page: the recorded exception {d} is missing")
                elif dates[d]["reconciled"]:
                    problems.append(f"page: {d} shown as reconciled; {HANDOFF} says it does not reconcile")
    exc = p.get("exceptions") or []
    rel = f"{PAGE_DIR}/{PAGE_FILE}"
    summary = (f"M22 backtest explainer ({p.get('label', DEFAULT_LABEL)}): {len(exc)} exception(s)"
               + "".join(f"; {x['date']}: {x['status_text']} (inputs_status {x['inputs_status']}, recorded "
                         f"{_fmt(x['book']['recorded_loss_mm'])} vs VaR99 {_fmt(x['book']['recorded_var99_mm'])}, reconstructed "
                         f"{_fmt(x['book']['reconstructed_loss_mm'])} vs {_fmt(x['book']['reconstructed_var99_mm'])} $mm)"
                         for x in exc)
               + f"; P&L: {(p.get('pnl') or {}).get('summary_text', 'n/a')} {len(p.get('gaps') or [])} gaps; "
               + (f"page {rel}" if page else "no page"))
    return {"ok": not problems, "problems": problems[:30], "summary": summary,
            "exceptions": [{"date": x["date"], "inputs_status": x["inputs_status"], "reconciled": x["reconciled"]} for x in exc],
            "unreconciled": p.get("unreconciled") or [], "gaps": p.get("gaps") or [],
            "paths": {"page": str(page) if page else "", **{k: v for k, v in (r.get("paths") or {}).items()}}}


# ---------------------------------------------------------------- CLI
def cmd_backtest_explain(a) -> int:
    from ..validation.backtest_explainer import main
    out = a.explain_out or a.out
    code = int(main(["--as-of", a.as_of, "--out", str(out), "--step", str(a.step)]) or 0)
    p = explainer_page(out)
    if p["status"] == "ok":
        f = write_page(out, p)
        print("\n".join(page_lines(p)))
        print(f"page: {f}")
    else:
        print(f"backtest-explain: {p['message']}", file=sys.stderr)
        code = code or 1
    return code


def register(sub) -> None:
    p = sub.add_parser("backtest-explain", help="INTERIM backtest explainer (Team B validation.backtest_explainer, EQ-B-0141): "
                                                "exception explainer, rolling backtests by country and factor, P&L attribution "
                                                "on the forecast record; writes <out>/backtest_explainer/ and the page "
                                                f"<out>/{PAGE_DIR}/{PAGE_FILE}; reads the real record in the program's data/ "
                                                "only; about a minute (EQ-C-0166); never on the record job")
    p.add_argument("--as-of", required=True, help="YYYY-MM-DD (required: there is no clock default)")
    p.add_argument("--out", dest="explain_out", metavar="DIR",
                   help="folder under outputs/ or outside the program folder (default: the outputs folder)")
    p.add_argument("--step", type=int, default=21, help="GARCH-DCC refit every N record days (default 21; 1 = each day)")

    def _fn(a):
        code = cmd_backtest_explain(a)
        if code:
            sys.exit(code)
    p.set_defaults(fn=_fn)
