"""Licence enforcement in outputs (EQ-C-0093, PI-8). Reads Team A's per-dataset licence register (EQ-A-0076) and acts
on it for every output: research products, `distribute`, `client-package`, the Sheets publish plan and the evidence
bundle. CLIENT MODE STAYS OFF: this module only ever makes client output harder, never easier.

Register contract (Team A builds it in EQ-A-0076; handoff HO-...-C-A from EQ-C-0093 states it):

    data/licences.csv   one row per source / dataset, UTF-8 CSV, header row, at most MAX_ROWS rows and MAX_BYTES
      source_id    required, unique, [A-Za-z0-9][A-Za-z0-9_.-]{0,63}           e.g. imf_weo
      match        required, Python regex (case-insensitive, <= MAX_MATCH chars) searched in a provenance record's
                   `source`, `series` and `licence` texts                       e.g. \\bimf\\b|imf-reader|\\bweo\\b
      licence      required, the licence or terms as recorded                   e.g. IMF: internal research use only (EXC-003)
      client_ok    required, "yes" or "no": may values of this source go into client output
      attribution  required when client_ok is yes; the line printed on every product that uses the source
      exc_id, licence_class, url, notes   optional, kept as text

    Most restrictive wins: a record matched by any row with client_ok=no is internal-only. A row whose licence text
    names an internal-only term (INTERNAL_ONLY_RE: internal use only, non-commercial, personal, NDA, EXC-003,
    EXC-005) but says client_ok=yes is a contradiction: the whole register is refused.

    SEC-C-016 M2: Team A shipped the register with its own columns (contract C14: match_source / match_licence /
    match_series, licence_text, internal_use, client_output allowed|restricted|barred, attribution_text). A header
    with those columns is read through Team A's validator plus the caps above (_team_a_rows); client_ok is
    client_output=allowed with internal_use=yes. Either schema is accepted; anything else refuses the register.

What counts as internal-only (union, so the register can only add restrictions to Team A's hard-coded rules):
- everything ingestion.audit.client_output_reason bars: IMF / WEO (Sam 2026-10-24 12:38Z, EXC-003), theratesapi.com
  (EXC-005), Yahoo / non-commercial / personal licences, national sources not cleared (EQ-A-0060), hand FX (EQ-A-0072);
- any record matched by a register row with client_ok=no;
- any record no register row matches ("unregistered"), except the desk's own seed estimates and analyst adjustments
  (OWN_SOURCE_RE), which carry no third-party licence.

Fails closed (SEC-C-014 M1 must not repeat): a missing, symlinked, oversized or invalid register, missing provenance
evidence (research.imf_evidence_problem), or any error while evaluating makes `client_ok` False with a problem line.
Internal mode is never blocked: it labels internal-only content and prints attribution for every source used.

client_ok=yes is trusted for client output only when the register is under change control (`econquest change`,
ops.approvals.FILES, EQ-C-0106 / R44) and data/licences.csv is byte-identical to the approved version. Enforcement reads
only the approved register (ops/licence_gov.py): `load_register` reads the approved bytes, `evaluate` runs with Team
A's resolver pointed at them (licence_gov.enforce_approved), and `register_mismatch` is the one resolver behind "which
register": no approved version yet, drift, a broken approvals log, or a Team A register other than the approved one
refuses client output and the evidence build, and only labels internal products. Licences are Sam's call; this code
never changes the register.
"""
from __future__ import annotations

import html as _h
import sys
import types
from pathlib import Path

# EQ-C-0113 (HO-20261025-B-C-007): the rule itself lives in ops/licence_rule.py (below presentation, so
# validation/client_safe.py can import it). Every name it defines is re-exported here as the same object.
from ..ops import licence_rule as _rule
from ..ops.licence_rule import (  # noqa: F401 - re-exported: callers import these from presentation.licences
    _CACHE, _CTRL, AUDIT, CHANGE_CONTROL_NOTE, EVIDENCE_COLUMNS, ID_RE, INTERNAL_ONLY_RE, MAX_BYTES, MAX_MATCH, MAX_ROWS,
    MAX_TEXT, OPTIONAL_COLUMNS, OWN_SOURCE_RE, REGISTER_NAME, REQUIRED_COLUMNS, RULE_NAMES, SUBJECT_CHARS,
    TEAM_A_MATCH, TEAM_A_SIGNATURE, UNREGISTERED, LicenceRegisterError, _clean, _evaluate, _fallback, _records, _stat,
    _team_a_rows, attribution_lines, enforced_register_path, evaluate, failure_state, imf_evidence_problem, load_register,
    match_rows, parse_register, register_governed, register_mismatch, register_path, safe_evaluate,
    D3_SOURCE_ID, PLANNED_FEED, PROVENANCE_TEXT_COLUMNS, PROVENANCE_TEXT_MAX, WEO_CODES_EXTRA, imf_text_hits,
    weo_code_re,  # EQ-C-0151
    redos_problem)  # EQ-C-0165 (SEC-C-015 L1)

LICENCE_MARKER = "<!-- econquest:licence-block -->"
TICKET = "EQ-C-0093"
_FORWARD = frozenset(RULE_NAMES)


class _RuleModule(types.ModuleType):
    """Setting (or deleting) a rule name on this module also sets it on ops.licence_rule, where evaluate looks it up:
    callers and tests that replace presentation.licences.register_mismatch / register_governed / _evaluate keep the
    effect they had before the move. Everything else behaves as a plain module."""

    def __setattr__(self, name, value):
        if name in _FORWARD:
            setattr(_rule, name, value)
        super().__setattr__(name, value)

    def __delattr__(self, name):
        if name in _FORWARD and hasattr(_rule, name):
            delattr(_rule, name)
        super().__delattr__(name)


sys.modules[__name__].__class__ = _RuleModule


# ---------------------------------------------------------------- refusals and labels
def internal_groups(ev: dict) -> list[dict]:
    """internal_only grouped per (source_id, licence, table, key): one group per column of a tab."""
    g: dict[tuple, dict] = {}
    for c in ev.get("internal_only") or []:
        k = (c["source_id"], c["licence"], c["table"], c["key"])
        e = g.setdefault(k, {"source_id": c["source_id"], "licence": c["licence"], "table": c["table"], "key": c["key"],
                             "reason": c["reason"], "countries": []})
        if c["country"] not in e["countries"]:
            e["countries"].append(c["country"])
    return sorted(g.values(), key=lambda e: (e["source_id"], e["table"], e["key"]))


def refusals(ev: dict, limit: int = 8) -> list[str]:
    """Why client output is refused, each naming the cell or column and the licence. [] when client_ok."""
    if ev.get("client_ok"):
        return []
    out = list(ev.get("problems") or [])
    groups = internal_groups(ev)
    for e in groups[:limit]:
        n = len(e["countries"])
        cell = f"{e['table']} {e['key']} {e['countries'][0]}" if n == 1 else \
            f"{e['table']} column {e['key']} ({n} cells, e.g. {', '.join(e['countries'][:3])})"
        out.append(f"{cell}: internal-only, licence {e['licence'][:160]!r} [{e['source_id']}]")
    if len(groups) > limit:
        out.append(f"... and {len(groups) - limit} more columns with internal-only content (econquest client-check)")
    return out or ["licence check incomplete: client output refused (fails closed)"]


# ---------------------------------------------------------------- client-safe file sources (EQ-C-0153)
def client_safe_register(data_dir) -> list[dict] | None:
    """The data folder's licence register rows in Team A's schema (client_output, attribution_text, match_path ...),
    or None when it is missing, a symlink or invalid. Used only to add attribution lines and to remove restricted
    source names in client-safe products: it never allows anything."""
    from ..ingestion import licences as A
    p = Path(data_dir) / REGISTER_NAME
    if p.is_symlink() or not p.is_file():
        return None
    try:
        return A.load_register(p) or None
    except Exception:                                    # noqa: BLE001 - unreadable: no rows
        return None


def with_file_attribution(ev: dict, data_dir) -> dict:
    """ev with the attribution line of every source a client-safe product uses through a data file rather than a
    scorecard cell (HO-20261026-B-C-010 item 1, e.g. gpr_monthly.csv for the Caldara-Iacoviello GPR): Team B's
    client_safe_pack.file_sources_in_use, i.e. register rows whose client_output is allowed, with an attribution text,
    whose file in the folder holds data. Lines already there are not repeated. Only adds lines: client_ok, the
    internal-only labels and the problems are unchanged. ev itself is not modified."""
    if not ev:
        return ev
    reg = client_safe_register(data_dir)
    if not reg:
        return ev
    try:
        from ..validation.client_safe_pack import file_sources_in_use
        rows = file_sources_in_use(data_dir, reg)
    except Exception:                                    # noqa: BLE001 - nothing to add
        return ev
    have = list(ev.get("attribution") or [])
    norm = [" ".join(str(a).split()) for a in have]
    add = []
    for r in rows:
        a = " ".join(str(r.get("attribution_text") or "").split())
        if a and str(r.get("client_output") or "") == "allowed" and not any(a in x for x in norm + add):
            add.append(a)
    return {**ev, "attribution": have + add} if add else ev


def internal_labels(ev: dict) -> list[str]:
    """Labels for internal-mode products: one per source with internal-only content, plus register problems."""
    per: dict[tuple, dict] = {}
    for e in internal_groups(ev):
        k = (e["source_id"], e["licence"])
        p = per.setdefault(k, {"cols": [], "cells": 0})
        p["cols"].append(f"{e['table']} {e['key']}")
        p["cells"] += len(e["countries"])
    probs = ev.get("reader_problems") if ev.get("reader_problems") is not None else ev.get("problems")  # EQ-C-0140
    out = [p for p in (probs or []) if p.startswith(("licence register", "provenance", "licence check"))]
    for (sid, lic), p in sorted(per.items(), key=lambda kv: -kv[1]["cells"]):
        cols = ", ".join(p["cols"][:6]) + (f" and {len(p['cols']) - 6} more" if len(p["cols"]) > 6 else "")
        out.append(f"INTERNAL ONLY: {p['cells']} cells under {lic[:160]} [{sid}] ({cols})")
    return out


def block_html(ev: dict | None) -> str:
    """Visible 'Sources and licences' block: attribution lines, then internal-only labels. All text escaped."""
    if not ev:
        return ""
    attr = "".join(f"<li>{_h.escape(a)}</li>" for a in ev.get("attribution") or []) or \
        "<li>No licensed source recorded for this product's inputs.</li>"
    labels = internal_labels(ev)
    lab = ("<p><b>Internal-only content (not for client output):</b></p><ul class='licence-internal'>"
           + "".join(f"<li>{_h.escape(x)}</li>" for x in labels) + "</ul>") if labels else ""
    return (f"{LICENCE_MARKER}<div class=\"licence-block\" role=\"note\" data-licence-client-ok=\"{str(bool(ev.get('client_ok'))).lower()}\" "
            "style=\"border:1px solid #888;padding:6px 10px;margin:8px 0;font-size:12px\">"
            f"<b>Sources and licences.</b><ul class='licence-attribution'>{attr}</ul>{lab}</div>")


def block_md(ev: dict | None) -> str:
    if not ev:
        return ""
    from .report import md_text
    L = [LICENCE_MARKER, "**Sources and licences.**", ""]
    L += [f"- {md_text(a)}" for a in ev.get("attribution") or []] or ["- No licensed source recorded for this product's inputs."]
    labels = internal_labels(ev)
    if labels:
        L += ["", "**Internal-only content (not for client output):**", ""] + [f"- {md_text(x)}" for x in labels]
    return "\n".join(L)


def summary(ev: dict) -> dict:
    """JSON-safe summary for manifests (evidence bundle, publish plan sidecar)."""
    return {"ticket": TICKET, "register": ev["register"], "client_ok": ev["client_ok"], "complete": ev["complete"],
            "problems": ev["problems"], "attribution": ev["attribution"],
            "sources": [{k: s[k] for k in ("source_id", "licence", "client_ok", "cells")} for s in ev["sources"]],
            "internal_only": [{**{k: e[k] for k in ("source_id", "licence", "table", "key")}, "cells": len(e["countries"])}
                              for e in internal_groups(ev)]}


def write_plan_licences(data_dir, plan_path) -> str:
    """Sheets publish plan (internal desk workbook): write <plan>.licences.json beside the plan with the attribution
    lines and the internal-only labels per tab column, and return a one-line summary for the console. The workbook is
    internal, so nothing is refused here; the sidecar says what in it is internal-only."""
    import json
    ev = safe_evaluate(data_dir)
    p = Path(plan_path)
    side = p.with_name(p.stem + ".licences.json")
    doc = {**summary(ev), "plan": p.name,
           "note": "Risk Desk workbook is internal: internal-only content is labelled here, not withheld. "
                   "Do not share the workbook or the plan outside the desk while internal_only is not empty."}
    side.write_text(json.dumps(doc, indent=1), encoding="utf-8")
    n = sum(e["cells"] for e in doc["internal_only"])
    return (f"Licences: {len(ev['attribution'])} source attribution(s); {n} internal-only cell(s) in "
            f"{len(doc['internal_only'])} column(s)" + ("" if ev["register"]["ok"] else
                                                        f"; {ev['register']['problem']}") + f" -> {side}")
