"""Content-Security-Policy without 'unsafe-inline' for every HTML page econquest serves or writes (EQ-C-0165).

Served pages (the GUI at GET /, the api.py dashboard) get the policy as a response header; written pages (reports,
notes, briefs, heatmap and depth page, archive versions, client sandbox pages) get it as the first element of <head>
(`<meta http-equiv="Content-Security-Policy" ...>`), so a page opened from disk is covered too.

Scripts: a page may only load scripts from a file (`<script src=...>`). The one inline script a written page carries
(the country-note index filter, country_note.INDEX_JS) is allowed by its sha256 only. Inline event handlers
(`on*=`) and `javascript:` URLs are never allowed (script-src-attr 'none'); `harden` refuses a page that has them.

Styles: <style> blocks and style="" attributes are allowed by their sha256 only ('unsafe-hashes' covers the attribute
hashes); 'unsafe-inline' is never used. A style attribute added later (for example by injected markup) has no hash and
is not applied. The GUI's own script sets no style attributes: it uses classes and CSSOM (element.style.x = ...),
which CSP does not restrict.

    policy_for(html, served=True)  -> the header value for this exact body
    harden(html)                   -> the page with a meta CSP for its exact content (idempotent: an older one is
                                      replaced, so a step that changes the page calls it again before writing)
    inline_problems(html)          -> inline scripts without a hash, on* handlers, javascript: URLs (empty when clean)
"""
from __future__ import annotations

import base64
import hashlib
import re
from html.parser import HTMLParser

META_RE = re.compile(r'<meta http-equiv="Content-Security-Policy" content="[^"]*" data-eq-csp="1">')
HEAD_RE = re.compile(r"<head\b[^>]*>", re.I)


def sha256_source(text: str) -> str:
    return "'sha256-" + base64.b64encode(hashlib.sha256(text.encode("utf-8")).digest()).decode("ascii") + "'"


class _Scan(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.style_blocks: list[str] = []
        self.style_attrs: list[str] = []
        self.inline_scripts: list[str] = []
        self.handlers: list[str] = []
        self.js_urls: list[str] = []
        self._raw: str | None = None              # tag whose raw text is being collected ("style" / "script")
        self._buf: list[str] = []

    def handle_starttag(self, tag, attrs):
        for k, v in attrs:
            k = (k or "").lower()
            if k.startswith("on"):
                self.handlers.append(f"{tag} {k}")
            elif k == "style" and v is not None:
                self.style_attrs.append(v)
            if k in ("href", "src", "action", "formaction", "xlink:href") and v and \
                    re.sub(r"[\x00-\x20]", "", v).lower().startswith(("javascript:", "vbscript:")):
                self.js_urls.append(f"{tag} {k}")
        if tag in ("style", "script"):
            self._raw = tag if not (tag == "script" and any(k == "src" for k, _ in attrs)) else "script-src"
            self._buf = []

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag in ("style", "script"):
            self._raw = None

    def handle_data(self, data):
        if self._raw:
            self._buf.append(data)

    def handle_endtag(self, tag):
        if self._raw and tag in ("style", "script"):
            text = "".join(self._buf)
            if self._raw == "style":
                self.style_blocks.append(text)
            elif self._raw == "script":
                self.inline_scripts.append(text)
            self._raw = None


def scan(html: str) -> _Scan:
    p = _Scan()
    p.feed(META_RE.sub("", html or ""))
    p.close()
    return p


# The only style attributes the bundled plotly.js (static/plotly.min.js v4.1.1) sets with setAttribute: an empty one,
# and the pixelated-heatmap image rule (its ML.STYLE). A page that loads Plotly allows exactly these two by hash.
# Plotly's own stylesheet comes from static/plotly-csp.css; its per-plot <style> elements are blocked (cosmetic only).
PLOTLY_STYLE_ATTRS = ("", "image-rendering: optimizeSpeed; image-rendering: -moz-crisp-edges; image-rendering: "
                      "-o-crisp-edges; image-rendering: -webkit-optimize-contrast; image-rendering: optimize-contrast; "
                      "image-rendering: crisp-edges; image-rendering: pixelated; ")
PLOTLY_SRC_RE = re.compile(r"<script\b[^>]*\bsrc=[\"']/static/plotly\.min\.js[\"']", re.I)


def style_sources(html: str, base: str = "'self'") -> str:
    s = scan(html)
    blocks = sorted({sha256_source(b) for b in s.style_blocks})
    extra = list(PLOTLY_STYLE_ATTRS) if PLOTLY_SRC_RE.search(html or "") else []
    attrs = sorted({sha256_source(a) for a in s.style_attrs + extra})
    parts = [base] if base else []
    if attrs:
        parts.append("'unsafe-hashes'")
    return " ".join(parts + blocks + [a for a in attrs if a not in blocks]) or "'none'"


def script_sources(html: str, base: str = "'self'") -> str:
    s = scan(html)
    return " ".join(([base] if base else []) + sorted({sha256_source(t) for t in s.inline_scripts})) or "'none'"


def policy_for(html: str, served: bool = True) -> str:
    """The CSP for this exact page. served=True is the header form (from 'self'); served=False is the meta form for a
    page opened from disk (nothing loads from anywhere; frame-ancestors is not allowed in a meta policy)."""
    if served:
        return ("default-src 'self'; "
                f"script-src {script_sources(html)}; script-src-attr 'none'; "
                f"style-src {style_sources(html)}; "
                "img-src 'self' data: blob:; font-src 'self'; connect-src 'self'; "
                "object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'")
    return ("default-src 'none'; "
            f"script-src {script_sources(html, base='')}; script-src-attr 'none'; "
            f"style-src {style_sources(html, base='')}; "
            "img-src data:; object-src 'none'; base-uri 'none'; form-action 'none'")


def inline_problems(html: str, allow_inline_script: bool = False) -> list[str]:
    s = scan(html)
    out = [f"inline event handler: {h}" for h in s.handlers] + [f"javascript: URL: {u}" for u in s.js_urls]
    if not allow_inline_script:
        out += ["inline <script> block"] * len([t for t in s.inline_scripts if t.strip()])
    return out


def harden(html: str) -> str:
    """The page with a meta CSP (hash-only scripts and styles) as the first element of <head>. Refuses (ValueError) a
    page with inline handlers or javascript: URLs: the policy would block them anyway, so they would silently fail."""
    probs = inline_problems(html, allow_inline_script=True)
    if probs:
        raise ValueError("page has inline code the CSP blocks: " + "; ".join(probs[:5]))
    body = META_RE.sub("", html)
    meta = f'<meta http-equiv="Content-Security-Policy" content="{policy_for(body, served=False)}" data-eq-csp="1">'
    m = HEAD_RE.search(body)
    if m:
        return body[:m.end()] + meta + body[m.end():]
    h = re.search(r"<html\b[^>]*>", body, re.I)
    if h:
        return body[:h.end()] + f"<head>{meta}</head>" + body[h.end():]
    return body                                   # a fragment, not a page: nothing to attach a policy to
