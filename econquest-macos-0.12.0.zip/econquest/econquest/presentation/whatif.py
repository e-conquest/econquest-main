"""What-if trade tool (EQ-C-0133, EQ-C-0139): propose trades, see VaR99 / ES99 / EL / L-VaR99 and limit status before
and after, and each trade's marginal contribution. In memory only: nothing is booked and data/portfolio.csv is never written.

Since EQ-C-0139 (HO-20261025-B-C-018) the numbers come from Team B's engine.portfolio_risk (EQ-B-0114): ONE base run
(contract C5 run_pipeline) and each proposed trade priced on that run's own paths (portfolio_risk.trade_path_loss).
"before" IS the base run, so it equals the plain base run for the same seed, paths and date, and the delta is the
trades' effect with no re-sampling noise. One trade goes straight through portfolio_risk.whatif (verdict, reasons,
first-order estimate, limit usage). Several trades add their base-path losses the same way portfolio_risk.whatif adds
one, and are graded with Team B's check_book; Team B prices every trade with the same fixed severity draws, so two
trades share those draws (noted in the output). The old local re-run marginal (after run minus the trades' columns) is retired.

Modes: full (default) and fast are kept for scripts and the API; both now use the base-path method (one run), so they
give the same numbers. delta_common_paths is kept and equals delta.

Each trade's marginal: after metric minus the after book without that trade (same paths), plus its expected loss, its
Euler component of ES99 (mean loss on the after tail) and Team B's first-order (base-tail) estimate.
"""
from __future__ import annotations
import math
import re
import threading
import time
from pathlib import Path
from types import SimpleNamespace
import numpy as np
import pandas as pd
from ..config import ASSET_CLASSES
from ..engine import limits as LM
from ..engine import portfolio_risk as PR
from ..engine import run_pipeline

SCHEMA = "eq-whatif/1"
NOTE = "what-if only: nothing booked"
MODES = ("full", "fast")              # full is the default (lead review of EQ-C-0133); both price on the base paths since EQ-C-0139
METHOD = "base-paths"
ENGINE = "econquest.engine.portfolio_risk (EQ-B-0114)"
SIDES = {"buy": "Long", "sell": "Short"}
MAX_TRADES = 10
MAX_NOTIONAL_MM = 250.0          # per trade; the largest country limit in data/limits.json is 45
MIN_PATHS, MAX_PATHS, DEFAULT_PATHS = 1000, 200_000, 20_000
METRICS = ("var99_mm", "es99_mm", "expected_loss_mm", "lvar99_mm", "gross_notional_mm")
STATUS_RANK = {"pass": 0, "warning": 1, "breach": 2}
_INSTRUMENTS = {a.lower(): a for a in ASSET_CLASSES}
_INSTRUMENTS.update({"cds": "CDS protection", "localbond": "Local bond", "local": "Local bond"})
_SAFE = re.compile(r"^[A-Za-z0-9 .,'()&/_-]{1,80}$")


def _instrument(text) -> str:
    t = str(text or "").strip()
    if not _SAFE.match(t):
        raise ValueError("instrument must be one of " + ", ".join(ASSET_CLASSES))
    key = re.sub(r"[\s_-]+", " ", t.lower()).strip()
    hit = _INSTRUMENTS.get(key) or _INSTRUMENTS.get(key.replace(" ", ""))
    if hit is None:
        raise ValueError(f"unknown instrument {t!r}; one of {', '.join(ASSET_CLASSES)}")
    return hit


def _country(text, countries) -> str:
    t = str(text or "").strip()
    by = {c.lower(): c for c in countries}
    if not _SAFE.match(t) or t.lower() not in by:
        raise ValueError(f"unknown desk/country {t[:40]!r}; one of the {len(by)} desks in the universe")
    return by[t.lower()]


def _notional(v) -> float:
    if isinstance(v, bool):
        raise ValueError("notional_mm must be a number")
    try:
        n = float(str(v).strip())
    except (TypeError, ValueError):
        raise ValueError("notional_mm must be a number") from None
    if not math.isfinite(n) or n <= 0 or n > MAX_NOTIONAL_MM:
        raise ValueError(f"notional_mm must be above 0 and at most {MAX_NOTIONAL_MM:g}")
    return round(n, 4)


def validate_trade(t: dict, countries) -> dict:
    """{country, instrument, notional_mm, side} -> a clean trade; ValueError on anything unknown or out of bounds."""
    if not isinstance(t, dict):
        raise ValueError("each trade must be an object {country, instrument, notional_mm, side}")
    extra = set(t) - {"country", "instrument", "notional_mm", "side"}
    if extra:
        raise ValueError(f"unknown trade fields {sorted(map(str, extra))[:5]}")
    side = str(t.get("side") or "buy").strip().lower()
    if side not in SIDES:
        raise ValueError("side must be buy or sell")
    return {"country": _country(t.get("country"), countries), "instrument": _instrument(t.get("instrument")),
            "notional_mm": _notional(t.get("notional_mm")), "side": side}


def parse_trade(text: str, countries) -> dict:
    """CLI form "<country> <instrument> <notional_mm> [buy|sell]", e.g. "South Korea Local bond 10 sell"."""
    words = str(text or "").split()
    if len(words) < 3 or len(str(text)) > 160:
        raise ValueError(f"--trade {str(text)[:60]!r}: expected '<country> <instrument> <notional_mm> [buy|sell]'")
    side = "buy"
    if words[-1].lower() in SIDES:
        side = words.pop().lower()
    notional = words.pop()
    by = sorted(countries, key=len, reverse=True)
    rest = " ".join(words)
    c = next((c for c in by if rest.lower() == c.lower() or rest.lower().startswith(c.lower() + " ")), None)
    if c is None:
        raise ValueError(f"--trade {str(text)[:60]!r}: unknown desk/country")
    return validate_trade({"country": c, "instrument": rest[len(c):].strip(), "notional_mm": notional, "side": side}, countries)


def validate_request(trades, paths=None, mode=None, countries=()) -> tuple[list[dict], int, str]:
    if not isinstance(trades, list) or not trades:
        raise ValueError("give at least one trade")
    if len(trades) > MAX_TRADES:
        raise ValueError(f"at most {MAX_TRADES} trades per what-if")
    clean = [validate_trade(t, countries) for t in trades]
    if paths is None or paths == "":
        paths = DEFAULT_PATHS
    if isinstance(paths, bool) or not isinstance(paths, (int, str)) or not str(paths).strip().isdigit():
        raise ValueError("paths must be a whole number")
    paths = int(paths)
    if not MIN_PATHS <= paths <= MAX_PATHS:
        raise ValueError(f"paths must be between {MIN_PATHS} and {MAX_PATHS}")
    if mode is not None and not isinstance(mode, str):
        raise ValueError("mode must be full or fast")
    mode = {"incremental": "fast"}.get(mode, mode) or "full"   # "incremental" kept as an alias of fast
    if mode not in MODES:
        raise ValueError("mode must be full or fast")
    return clean, paths, mode


def _tail(losses: np.ndarray, liq: float, gross: float) -> dict:
    var99 = float(np.quantile(losses, 0.99))
    tail = losses >= var99
    es99 = float(losses[tail].mean()) if tail.any() else var99
    return {"var99_mm": var99, "es99_mm": es99, "expected_loss_mm": float(losses.mean()), "lvar99_mm": var99 + float(liq),
            "gross_notional_mm": float(gross)}


def _limit_rows(before: pd.DataFrame, after: pd.DataFrame) -> list[dict]:
    key = ["scope", "name", "measure"]
    b = before.set_index(key); a = after.set_index(key)
    out = []
    for k in list(b.index) + [k for k in a.index if k not in b.index]:
        rb = b.loc[k] if k in b.index else None; ra = a.loc[k] if k in a.index else None
        sb = rb["status"] if rb is not None else "none"; sa = ra["status"] if ra is not None else "none"
        out.append({"scope": k[0], "name": k[1], "measure": k[2], "limit": float((ra if ra is not None else rb)["limit"]),
                    "value_before": None if rb is None else float(rb["value"]), "value_after": None if ra is None else float(ra["value"]),
                    "utilisation_before": None if rb is None else float(rb["utilisation"]),
                    "utilisation_after": None if ra is None else float(ra["utilisation"]),
                    "status_before": sb, "status_after": sa, "changed": sb != sa})
    return out


def _worst(tab: pd.DataFrame) -> str:
    return max(tab["status"], key=STATUS_RANK.get, default="pass") if len(tab) else "pass"


def _proposal(t: dict) -> dict:
    """A validated trade as Team B's proposal (portfolio_risk.parse_trade fills the duration by asset class)."""
    return PR.parse_trade({"country": t["country"], "asset_class": t["instrument"], "direction": SIDES[t["side"]],
                           "notional_mm": t["notional_mm"]})


def combine(universe, settings, base, limits: dict, props: list[dict], ids: list[str], solo: list[dict]) -> dict:
    """Several trades on the base run's paths, the way portfolio_risk.whatif adds one: after losses = base losses + each
    trade's trade_path_loss; liquidity cost and gross add up; limits graded by check_book on the after book.
    `solo` is portfolio_risk.whatif of each trade alone (its liquidity cost and first-order estimate).
    Returns after metrics, the per-trade path losses, the limit tables and Team B's breaches / warnings."""
    mb = base.mc.metrics
    Ls, rows = [], []
    for p, pid in zip(props, ids):
        L, prow, _legs = PR.trade_path_loss(universe, settings, base, p)
        Ls.append(L)
        rows.append(prow.to_frame().T.set_axis([pid]).assign(notional_mm=p["notional_mm"]))
    new = base.mc.losses + np.sum(Ls, axis=0)
    liq = float(mb["liquidity_cost99_mm"]) + sum(float(x["trade"]["liquidity_cost99_mm"]) for x in solo)
    ma = LM._tail_metrics(new, liq)
    ma["gross_notional_mm"] = float(mb["gross_notional_mm"]) + sum(p["notional_mm"] for p in props)
    tail_a, _ = PR.tail_mask(new)
    Ma = np.column_stack([base.mc.position_losses, *Ls])
    pos_a = pd.concat([base.positions, *rows])
    pos_a["notional_mm"] = pos_a["notional_mm"].astype(float)
    contrib_a = pd.DataFrame({"country": pos_a["country"], "asset_class": pos_a["asset_class"], "notional_mm": pos_a["notional_mm"],
                              "expected_loss_mm": Ma.mean(axis=0), "tail_contribution_99_mm": Ma[tail_a].mean(axis=0)}, index=pos_a.index)
    shim = SimpleNamespace(metrics={**mb, **ma}, positions=pos_a, mc=SimpleNamespace(contributions=contrib_a), country=base.country)
    lim_b = LM.check_book(base, universe, limits)
    lim_a = LM.check_book(shim, universe, limits)
    breaches, warnings = LM._reasons(lim_a, lim_b)
    book = lim_a[lim_a["scope"] == "book"].set_index("measure")
    usage = {k: {"value": float(book.at[k, "value"]), "limit": float(book.at[k, "limit"]),
                 "utilisation": float(book.at[k, "utilisation"]), "status": book.at[k, "status"]}
             for k in LM.BOOK_MEASURES if k in book.index}
    return {"after": ma, "losses": new, "trade_losses": Ls, "tail": tail_a, "limits_before": lim_b, "limits_after": lim_a,
            "breaches": breaches, "warnings": warnings, "limit_usage": usage}


def whatif(universe, settings, limits: dict, trades: list[dict], paths: int = DEFAULT_PATHS, mode: str = "full",
           as_of=None, market_dir=None, base=None) -> dict:
    """Before/after metrics, limit status and per-trade marginals for proposed trades, priced on one base run's paths
    (Team B's engine.portfolio_risk). `base` is a RunResult made with the same paths, else the base run is made here.
    Never writes anything."""
    t0 = time.perf_counter()
    trades, paths, mode = validate_request(trades, paths, mode, universe.names)
    if base is None:
        base = run_pipeline(universe, settings, label="whatif-base", paths=paths, as_of=as_of, market_dir=market_dir)
    props, ids = [], []
    for k, t in enumerate(trades, 1):
        p = _proposal(t)
        props.append(p); ids.append(f"WI{k}")
        t["id"], t["direction"] = ids[-1], p["direction"]
        t["duration_yrs"] = None if (isinstance(p["duration_yrs"], float) and np.isnan(p["duration_yrs"])) else float(p["duration_yrs"])
    solo = [PR.whatif(universe, settings, p, limits, r=base) for p in props]      # Team B's what-if, each trade alone
    mb = base.mc.metrics
    m_before = {k: float(mb[k]) for k in METRICS}
    if len(props) == 1:                                   # exactly Team B's what-if
        res = solo[0]
        lim_b, lim_a = res["limits_before"], res["limits_after"]
        breaches, warnings, usage = res["breaches"], res["warnings"], res["limit_usage"]
        m_after = {k: float(res["after"][k]) for k in METRICS}
        marg_src = [(res["change"]["var99_mm"], res["change"]["es99_mm"], res["change"]["lvar99_mm"],
                     res["trade"]["expected_loss_mm"], res["trade"]["tail_mean_on_new_tail_mm"])]
    else:
        c = combine(universe, settings, base, limits, props, ids, solo)
        lim_b, lim_a, breaches, warnings, usage = c["limits_before"], c["limits_after"], c["breaches"], c["warnings"], c["limit_usage"]
        m_after = {k: float(c["after"][k]) for k in METRICS}
        marg_src = []
        for L, p, sx in zip(c["trade_losses"], props, solo):
            w = _tail(c["losses"] - L, m_after["lvar99_mm"] - m_after["var99_mm"] - float(sx["trade"]["liquidity_cost99_mm"]),
                      m_after["gross_notional_mm"] - p["notional_mm"])
            marg_src.append((m_after["var99_mm"] - w["var99_mm"], m_after["es99_mm"] - w["es99_mm"], m_after["lvar99_mm"] - w["lvar99_mm"],
                             float(L.mean()), float(L[c["tail"]].mean())))
    marg = []
    for t, sx, (mv, me, ml, el, comp) in zip(trades, solo, marg_src):
        fo = sx["first_order_change"]
        marg.append({"id": t["id"], "country": t["country"], "instrument": t["instrument"], "side": t["side"], "notional_mm": t["notional_mm"],
                     "marginal_var99_mm": float(mv), "marginal_es99_mm": float(me), "marginal_lvar99_mm": float(ml),
                     "expected_loss_mm": float(el), "component_es99_mm": float(comp),
                     "share_of_es99": comp / m_after["es99_mm"] if m_after["es99_mm"] else None,
                     "first_order_var99_mm": float(fo["var99_mm"]), "first_order_es99_mm": float(fo["es99_mm"]),
                     "pd_default": float(sx["trade"]["pd_default"]), "liquidity_cost99_mm": float(sx["trade"]["liquidity_cost99_mm"]),
                     "duration_yrs": t["duration_yrs"]})
    first = {k: float(sum(sx["first_order_change"][k] for sx in solo)) for k in ("var99_mm", "es99_mm", "expected_loss_mm", "lvar99_mm")}
    rows = _limit_rows(lim_b, lim_a)
    worse = [r for r in rows if STATUS_RANK.get(r["status_after"], 0) > STATUS_RANK.get(r["status_before"], 0)]
    count = lambda tab: {s: int((tab["status"] == s).sum()) for s in ("pass", "warning", "breach")}
    verdict = "refuse" if breaches else "flag" if warnings else "accept"          # Team B's rule (portfolio_risk.whatif)
    sim_paths = int(base.mc.paths)
    delta = {k: m_after[k] - m_before[k] for k in METRICS}
    out = {
        "schema": SCHEMA, "note": NOTE, "booked": False, "mode": mode,
        "as_of": base.settings.get("as_of"), "seed": int(settings.seed), "paths_requested": paths, "paths": sim_paths,
        "same_paths_note": (f"before is the base run itself and the trades are priced on its {sim_paths} paths (same seed "
                            f"{int(settings.seed)}): the delta is the trades' effect, not Monte Carlo noise"
                            + ("" if len(trades) == 1 else "; Team B prices each trade with the same fixed severity draws")),
        "trades": [{k: t[k] for k in ("id", "country", "instrument", "side", "direction", "notional_mm", "duration_yrs")} for t in trades],
        "metrics": {"before": m_before, "after": m_after, "delta": delta, "delta_common_paths": dict(delta),
                    "first_order_change": first},
        "marginal": marg,
        "limits": {"warning_level": float(limits.get("warning_level", 0.8)), "status_before": _worst(lim_b),
                   "status_after": _worst(lim_a), "counts_before": count(lim_b), "counts_after": count(lim_a),
                   "verdict": verdict, "worsened": worse, "rows": rows,
                   "reasons": breaches + warnings, "breaches": breaches, "warnings": warnings, "limit_usage": usage},
        "method": METHOD, "engine": ENGINE, "run_id": base.run_id,
    }
    out["_runtime_s"] = round(time.perf_counter() - t0, 2)    # dropped from --json and the API (not stable)
    return out

def public(result: dict) -> dict:
    """The stable JSON shape (schema eq-whatif/1): the result without private keys."""
    return {k: v for k, v in result.items() if not k.startswith("_")}


def render_text(r: dict) -> str:
    f = lambda v: "n/a" if v is None else f"{v:,.2f}"
    m = r["metrics"]; L = r["limits"]
    lines = [f"WHAT-IF ONLY: NOTHING BOOKED (data/portfolio.csv unchanged)  mode {r['mode']}"
             + " (base run + trades priced on its paths: before = base run)"
             + f", as of {r['as_of']}",
             r["same_paths_note"], "", "Trades:"]
    lines += [f"  {t['id']}: {t['side']} {t['notional_mm']:g}mm {t['country']} {t['instrument']}" for t in r["trades"]]
    lines += ["", f"  {'metric':<20}{'before':>12}{'after':>12}{'delta':>12}{'same-paths delta':>18}"]
    names = {"var99_mm": "VaR99 $mm", "es99_mm": "ES99 $mm", "expected_loss_mm": "EL $mm", "lvar99_mm": "L-VaR99 $mm",
             "gross_notional_mm": "gross notional $mm"}
    for k, lbl in names.items():
        lines.append(f"  {lbl:<20}{f(m['before'][k]):>12}{f(m['after'][k]):>12}{m['delta'][k]:>+12,.2f}{m['delta_common_paths'][k]:>+18,.2f}")
    lines += ["", "Marginal contribution per trade (same paths):",
              f"  {'id':<6}{'mVaR99':>10}{'mES99':>10}{'mL-VaR99':>10}{'EL':>9}{'ES99 comp':>11}"]
    for x in r["marginal"]:
        lines.append(f"  {x['id']:<6}{x['marginal_var99_mm']:>+10.2f}{x['marginal_es99_mm']:>+10.2f}{x['marginal_lvar99_mm']:>+10.2f}"
                     f"{x['expected_loss_mm']:>9.2f}{x['component_es99_mm']:>11.2f}")
    fo = m.get("first_order_change") or {}
    if fo:
        lines.append(f"  first-order (Euler) estimate of the change: VaR99 {fo['var99_mm']:+,.2f}, ES99 {fo['es99_mm']:+,.2f}")
    lines += ["", f"Limits (warning band from {L['warning_level'] * 100:.0f}% of limit, breach at 100%): "
                  f"worst {L['status_before']} -> {L['status_after']}; verdict {L['verdict'].upper()}"]
    shown = [x for x in L["rows"] if x["changed"] or x["status_after"] != "pass"]
    for x in shown:
        ub = "-" if x["utilisation_before"] is None else f"{x['utilisation_before'] * 100:.0f}%"
        ua = "-" if x["utilisation_after"] is None else f"{x['utilisation_after'] * 100:.0f}%"
        where = x["scope"] if x["name"] == x["scope"] else f"{x['scope']} {x['name']}"
        lines.append(f"  {where} {x['measure']}: {x['status_before']} {ub} -> {x['status_after']} {ua}"
                     + ("  (changed)" if x["changed"] else ""))
    if not shown:
        lines.append("  every limit passes before and after")
    lines += [f"  - {x}" for x in L.get("reasons") or []]
    lines += ["", NOTE]
    return "\n".join(lines)


def load_limits(data_dir) -> dict:
    return LM.load_limits(Path(data_dir) / "limits.json")


# ---------------------------------------------------------------- POST /api/whatif (GUI)
MAX_BODY_BYTES = 16 * 1024
_API_LOCK = threading.Lock()


def handle_api(universe, settings, data_dir, body) -> tuple[int, dict]:
    """POST /api/whatif {"trades": [{country, instrument, notional_mm, side}], "paths": N, "mode": "full"|"fast"} (default full).
    The caller has already applied the write guard (loopback Host, JSON content type, same Origin, session token).
    Runs on the server's loaded universe in memory; never books, never touches the store, the latest run or data/."""
    if not isinstance(body, dict):
        return 400, {"error": "body must be a JSON object"}
    extra = set(body) - {"trades", "paths", "mode"}
    if extra:
        return 400, {"error": f"unknown fields {sorted(map(str, extra))[:5]}"}
    try:
        trades, paths, mode = validate_request(body.get("trades"), body.get("paths"), body.get("mode"), universe.names)
    except ValueError as e:
        return 400, {"error": str(e)}
    if not _API_LOCK.acquire(blocking=False):
        return 409, {"error": "a what-if is already running; try again when it finishes"}
    try:
        res = whatif(universe, settings, load_limits(data_dir), trades, paths=paths, mode=mode, market_dir=str(data_dir))
    finally:
        _API_LOCK.release()
    return 200, public(res)
