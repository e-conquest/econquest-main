"""Research product line settings (EQ-C-0075): internal vs client mode, the standard research disclaimer block, the
internal distribution allow-list, and the publication calendar.

data/research.json (governed by `econquest change`, ops/approvals.py; absent = the built-in default below):

    {"mode": "internal",                                  # "internal" (default) or "client"
     "disclaimer": {"internal": "Internal research, not investment advice, not for distribution.",
                    "client": ""},                         # client text: Sam's decision, empty until then
     "internal_domains": [],                               # e.g. ["desk.example"]: addresses at these domains are internal
     "internal_addresses": []}                             # single internal addresses outside those domains

Mode rules
- Internal is the default and the fail-safe. Client mode is Sam's decision (program board "Internal vs client") and
  stays off: `effective_mode` returns "client" only when research.json says so AND its current sha256 is exactly the one
  written by an applied `econquest change` whose approval was signed by Sam (DECISION_OWNER, ledger.person_key) and the
  approvals chain verifies. A hand edit, a non-Sam approval, a broken chain or anything unreadable gives "internal" plus
  a problem line. ops/approvals.py also refuses to approve or apply such a change unless the approver is Sam.
- IMF data is internal research use only (Sam 2026-10-24, HO-20261024-A-C-011): even an approved client mode falls
  back to internal while any applied cell is flagged by ingestion.audit.client_restricted_cells (IMF, WEO-derived).
- Licences (EQ-C-0093, presentation/licences.py): client mode also needs Team A's licence register (data/licences.csv,
  EQ-A-0076) to allow every source in use; missing, unreadable or any internal-only cell keeps internal. Every product's
  block carries the attribution line of each source used and labels internal-only content.
- While internal, every product carries the INTERNAL RESEARCH banner (block_html / apply_block), and
  ops/distribute.py refuses every recipient outside internal_domains / internal_addresses (an empty allow-list refuses
  everyone: nothing leaves the desk until the list is approved through `econquest change`).

The block is the mode banner plus the configured text. report.DISCLAIMER (use restriction 6.1) stays on every product as
the governed core that the editorial and compliance checks look for; the block sits above it, it does not replace it.

data/publication_calendar.json (Team C, not under change control): products with cadence, owner and next due date;
`calendar_status` derives due / overdue from the editorial ledger (last published item of the product's kind).
"""
from __future__ import annotations

import datetime as dt
import html as _h
import json
import re
from pathlib import Path

import pandas as pd

# EQ-C-0113: moved to the licence rule module (below presentation); re-exported here unchanged
from ..ops.licence_rule import EVIDENCE_COLUMNS, imf_evidence_problem  # noqa: F401

CONFIG_NAME = "research.json"
CALENDAR_NAME = "publication_calendar.json"
MODES = ("internal", "client")
DECISION_OWNER = "Sam"                       # program board: "Internal vs client" is Sam's decision
INTERNAL_TEXT = "Internal research, not investment advice, not for distribution."
DEFAULT_CONFIG = {"mode": "internal", "disclaimer": {"internal": INTERNAL_TEXT, "client": ""},
                  "internal_domains": [], "internal_addresses": [],
                  "entitlements": {}}             # EQ-C-0082 client packaging: recipient -> [product kinds]; used only in client mode
BANNER = {"internal": "INTERNAL RESEARCH", "client": "RESEARCH"}
ENTITLEMENT_EXTRA_KINDS = ("workbook",)          # EQ-C-0107: the client-safe workbook variant (presentation/client_build.py)
MARKER = "<!-- econquest:research-block -->"
MAX_TEXT = 1000
_CTRL = re.compile("[\\x00-\\x1f\\x7f\\x85\\u2028\\u2029]")
_DOMAIN = re.compile(r"(?=.{1,253}$)[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?(?:\.[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?)+")
CADENCES = {"weekly": pd.DateOffset(weeks=1), "fortnightly": pd.DateOffset(weeks=2), "monthly": pd.DateOffset(months=1),
            "quarterly": pd.DateOffset(months=3)}


# EQ-C-0151 (HO-20261026-B-C-005, EQ-B-0130): a data folder holding a client-safe dataset carries this marker
# (validation/client_safe_pack.py MARKER_FILE / MARKER_KIND, Team A's EQ-A-0124 dataset). Every product built from
# it is labelled a client-safe draft; with no marker nothing changes.
CLIENT_SAFE_MARKER = "client_safe.json"
CLIENT_SAFE_KIND = "client_safe_dataset"
CLIENT_SAFE_MAX_BYTES = 5_000_000
CLIENT_SAFE_DSA_NA = "DSA not available in the client-safe dataset"
_SHA = re.compile(r"[0-9a-f]{8,64}")


class ResearchConfigError(ValueError):
    """An invalid data/research.json or data/publication_calendar.json."""


# ---------------------------------------------------------------- research.json
def config_path(data_dir) -> Path:
    return Path(data_dir) / CONFIG_NAME


def _text(v, where: str, allow_empty: bool) -> str:
    if not isinstance(v, str):
        raise ResearchConfigError(f"{where} must be a string")
    s = v.strip()
    if _CTRL.search(s):
        raise ResearchConfigError(f"{where} contains a control character or line break")
    if len(s) > MAX_TEXT:
        raise ResearchConfigError(f"{where} is longer than {MAX_TEXT} characters")
    if not s and not allow_empty:
        raise ResearchConfigError(f"{where} must not be empty")
    return s


def validate_config(doc, where: str = CONFIG_NAME) -> dict:
    """The normalised config, or ResearchConfigError (also run by `change propose` on the proposed text)."""
    if not isinstance(doc, dict) or set(doc) - set(DEFAULT_CONFIG):
        raise ResearchConfigError(f"{where}: expected an object with keys {', '.join(DEFAULT_CONFIG)}")
    mode = doc.get("mode", "internal")
    if mode not in MODES:
        raise ResearchConfigError(f"{where}: mode must be one of {MODES}, got {mode!r}")
    disc = doc.get("disclaimer", DEFAULT_CONFIG["disclaimer"])
    if not isinstance(disc, dict) or set(disc) - set(MODES):
        raise ResearchConfigError(f"{where}: disclaimer must map {', '.join(MODES)} to texts")
    texts = {"internal": _text(disc.get("internal", INTERNAL_TEXT), f"{where}: disclaimer.internal", False),
             "client": _text(disc.get("client", ""), f"{where}: disclaimer.client", mode != "client")}
    doms, addrs = doc.get("internal_domains", []), doc.get("internal_addresses", [])
    if not isinstance(doms, list) or not all(isinstance(d, str) and _DOMAIN.fullmatch(d.strip()) for d in doms):
        raise ResearchConfigError(f"{where}: internal_domains must be a list of plain domain names (no @, no wildcards)")
    from ..ops.distribute import DistributionError, check_address
    if not isinstance(addrs, list):
        raise ResearchConfigError(f"{where}: internal_addresses must be a list of addresses")
    try:
        clean = [check_address(a, f"{where}: internal_addresses entry") for a in addrs]
    except DistributionError as e:
        raise ResearchConfigError(str(e)) from None
    ent = doc.get("entitlements", {})
    if not isinstance(ent, dict):
        raise ResearchConfigError(f"{where}: entitlements must map recipient addresses to lists of product kinds")
    from .editorial import KINDS
    ents = {}
    for a, kinds in ent.items():
        try:
            addr = check_address(a, f"{where}: entitlements key").casefold()
        except DistributionError as e:
            raise ResearchConfigError(str(e)) from None
        allowed = (*KINDS, *ENTITLEMENT_EXTRA_KINDS)
        if not isinstance(kinds, list) or not all(k in allowed for k in kinds):
            raise ResearchConfigError(f"{where}: entitlements[{addr}] must be a list of product kinds ({', '.join(allowed)})")
        ents[addr] = sorted(set(kinds))
    return {"mode": mode, "disclaimer": texts, "internal_domains": [d.strip().lower() for d in doms],
            "internal_addresses": clean, "entitlements": ents}


def load_config(data_dir) -> dict:
    """research.json validated (built-in default when absent), with "sha256" and "source". Raises ResearchConfigError."""
    from ..ops.approvals import sha256_bytes
    p = config_path(data_dir)
    if not p.exists():
        return {**json.loads(json.dumps(DEFAULT_CONFIG)), "sha256": None, "source": "default"}
    raw = p.read_bytes()
    try:
        doc = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise ResearchConfigError(f"{p}: not valid JSON ({e})") from None
    return {**validate_config(doc, str(p)), "sha256": sha256_bytes(raw), "source": str(p)}


def client_approval(data_dir) -> dict | None:
    """The applied change that wrote research.json's current bytes with an approval signed by DECISION_OWNER, as
    {"id", "approver", "self_approved", "exc_id", "applied_utc"}; None when there is none (or the chain is broken)."""
    from ..ingestion.ledger import person_key
    from ..ops import approvals as ap
    cur = ap.file_sha256(config_path(data_dir))
    if cur is None or not ap.verify_chain(data_dir)["ok"]:
        return None
    rows = ap.read_log(data_dir)
    last = ap._last_applied(rows, CONFIG_NAME)
    if not last or last.get("event") != "apply" or last.get("file_sha256") != cur:
        return None
    appr = [r for r in rows if r.get("id") == last.get("id") and r.get("event") == "approve"]
    if not appr or person_key(appr[-1].get("approver")) != person_key(DECISION_OWNER):
        return None
    from ..ops import identity                    # SEC-C-011 L2: with Sam's key enrolled, the row must carry his signature
    try:
        owner = identity.owner_user(data_dir, DECISION_OWNER)
    except identity.IdentityError:
        return None
    if owner and ap.owner_signature_problem(data_dir, owner, row=appr[-1]):
        return None
    try:
        prop = ap.load_proposal(data_dir, last["id"])
    except (ap.ApprovalError, OSError, ValueError):
        return None
    if prop.get("new_sha256") != cur:
        return None
    a = appr[-1]
    return {"id": last["id"], "approver": a.get("approver"), "self_approved": a.get("self_approved"),
            "exc_id": a.get("exc_id"), "applied_utc": last.get("ts_utc")}


def _default_cfg(why: str) -> dict:
    return {**json.loads(json.dumps(DEFAULT_CONFIG)), "sha256": None, "source": f"default ({why})"}


def _ungoverned(data_dir, cfg: dict) -> str | None:
    """None when research.json may be used as it is: absent (built-in default), equal in content to the default, or
    exactly the bytes of the last `econquest change` apply (or a signed-off baseline) with the approvals chain intact.
    Otherwise why not (SEC-C-011 M1: before this, a hand edit of internal_domains widened the distribution
    allow-list with no approval at all)."""
    if cfg.get("sha256") is None:
        return None
    norm = {k: cfg[k] for k in DEFAULT_CONFIG}
    if norm == validate_config(DEFAULT_CONFIG):
        return None
    from ..ops import approvals as ap
    try:
        st = ap.file_status(data_dir, CONFIG_NAME)
        last = ap._last_applied(ap.read_log(data_dir), CONFIG_NAME) if st["chain_ok"] else None
    except Exception as e:                           # noqa: BLE001 - cannot tell: fail closed
        return f"research.json approvals could not be read ({type(e).__name__})"
    if not st["chain_ok"]:
        return "the approvals log does not verify"
    if st["status"] != "ok" or not last:
        return f"research.json is not the version last applied through econquest change ({st['status']}: hand edit?)"
    if last.get("event") == "baseline" and not str(last.get("approver") or "").strip():
        return "research.json was only baselined, without a second sign-off"
    return None


def effective_mode(data_dir) -> dict:
    """{"mode": "internal" | "client", "requested": what research.json says, "approval": client_approval or None,
    "problems": [...], "config": load_config or the default, "licences": licences.safe_evaluate}. Fails closed to
    internal. EQ-C-0093: an approved client mode also falls back to internal unless the licence register allows every
    source in use for client output (presentation/licences.py; a missing or unreadable register refuses)."""
    from .licences import refusals, safe_evaluate
    st = _effective_mode(data_dir)
    lic = safe_evaluate(data_dir)
    st["licences"] = lic
    cs = client_safe_marker(data_dir)                   # EQ-C-0151: only set when the marker is there
    if cs:
        st["client_safe"] = cs
        from .licences import with_file_attribution                  # EQ-C-0153: GPR and other file sources
        st["licences"] = with_file_attribution(lic, data_dir)
    if st["mode"] == "client" and not lic["client_ok"]:
        why = refusals(lic, limit=3)
        st.update(mode="internal", config=_default_cfg("client output refused by licence enforcement"),
                  problems=st["problems"] + ["client mode approved but licence enforcement refuses client output (EQ-C-0093): "
                                             + "; ".join(why) + "; internal mode applies"])
    return st


def _effective_mode(data_dir) -> dict:
    try:
        cfg = load_config(data_dir)
    except ResearchConfigError as e:
        cfg = {**json.loads(json.dumps(DEFAULT_CONFIG)), "sha256": None, "source": "default (unreadable file)"}
        return {"mode": "internal", "requested": "unknown", "approval": None, "config": cfg,
                "problems": [f"{e}; internal mode applies"]}
    if cfg["mode"] != "client":
        why = _ungoverned(data_dir, cfg)          # SEC-C-011 M1: a hand edit of the allow-list or texts has no effect
        if why:
            return {"mode": "internal", "requested": "internal", "approval": None, "config": _default_cfg(why),
                    "problems": [f"{why}; the built-in default (empty allow-list, standard text) applies"]}
        return {"mode": "internal", "requested": "internal", "approval": None, "config": cfg, "problems": []}
    try:
        appr = client_approval(data_dir)
    except Exception as e:                       # noqa: BLE001 - cannot tell: fail closed
        appr = None
        why = f"approvals could not be read ({type(e).__name__})"
    else:
        why = f"no applied `econquest change` approved by {DECISION_OWNER} wrote the current research.json"
    if appr is None:
        return {"mode": "internal", "requested": "client", "approval": None,
                "config": _default_cfg("client mode not approved"),          # never the unapproved allow-list
                "problems": [f"client mode requested in {cfg['source']} but {why}; internal mode applies"]}
    try:                                         # HO-20261024-A-C-011, Sam 2026-10-24: IMF data never goes to clients
        held = len(client_restricted_cells(data_dir))
    except Exception as e:                       # noqa: BLE001 - cannot tell: fail closed
        held = f"unknown ({type(e).__name__})"
    if held:
        return {"mode": "internal", "requested": "client", "approval": appr,
                "config": _default_cfg("client output restricted"),
                "problems": [f"client mode approved but {held} applied cells carry IMF or WEO-derived data (internal research "
                             "use only, Sam 2026-10-24; `python -m econquest.ingestion.audit client`); internal mode applies"]}
    return {"mode": "client", "requested": "client", "approval": appr, "config": cfg, "problems": []}


def client_restricted_cells(data_dir):
    """Applied cells that must stay out of client output (Team A's audit.client_output_reason: IMF licence or source,
    WEO-derived values, and everything restricted_reason bars). Products are built from every applied cell, so one
    such cell keeps the whole product line in internal mode.
    EQ-C-0083 review of EQ-C-0080: the audit check finds IMF cells through the provenance records, so with the records
    gone it would find none and let client mode through. Raises ResearchConfigError (callers fail closed) when cells
    are applied but data/audit_trail.csv is not there to tie them to a source (imf_evidence_problem)."""
    why = imf_evidence_problem(data_dir)
    if why:
        raise ResearchConfigError(why)
    from ..ingestion.audit import client_restricted_cells as cells
    return cells(data_dir)


# ---------------------------------------------------------------- client-safe draft label (EQ-C-0151)
def client_safe_marker(data_dir) -> dict | None:
    """{"variant", "dataset_sha256"} when data_dir holds a client-safe dataset marker, else None. A marker file that
    is there but cannot be read (symlink, too large, not JSON) still labels the products (cautious), as variant
    "unreadable marker"; a JSON file of another kind is not a client-safe marker."""
    if data_dir is None:
        return None
    p = Path(data_dir) / CLIENT_SAFE_MARKER
    if not (p.exists() or p.is_symlink()):
        return None
    try:
        if p.is_symlink() or not p.is_file() or p.stat().st_size > CLIENT_SAFE_MAX_BYTES:
            raise ValueError("not a regular file of a sane size")
        doc = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return {"variant": "unreadable marker", "dataset_sha256": None}
    if not isinstance(doc, dict) or doc.get("kind") != CLIENT_SAFE_KIND:
        return None
    variant = _CTRL.sub(" ", str(doc.get("variant") or "unknown"))[:80]
    sha = str(doc.get("dataset_sha256") or "")
    if not sha:                                  # Team A's own marker: the hash is in ../manifest.json (EQ-A-0124)
        m = Path(data_dir).parent / "manifest.json"
        try:
            if not m.is_symlink() and m.is_file() and m.stat().st_size <= CLIENT_SAFE_MAX_BYTES:
                sha = str((json.loads(m.read_text(encoding="utf-8")) or {}).get("dataset_sha256") or "")
        except (OSError, ValueError, AttributeError):
            sha = ""
    return {"variant": variant, "dataset_sha256": sha if _SHA.fullmatch(sha) else None}


def client_safe_text(cs: dict, mode: str = "internal") -> str:
    """The CLIENT-SAFE DRAFT line (HO-20261026-B-C-005)."""
    sha = (cs.get("dataset_sha256") or "unknown")[:8]
    out = (f"CLIENT-SAFE DRAFT. Built from the client-safe dataset {cs.get('variant') or 'unknown'} ({sha}); restricted "
           "inputs withheld; licence attribution below.")
    if mode != "client":
        out += " Client mode is off: not for distribution until Sam approves client mode."
    return out


def client_safe_manifest(state: dict | None) -> dict:
    """{"client_safe": {"variant", "dataset_sha256"}} for a product manifest when the data is a client-safe dataset,
    else {} (the manifest is unchanged)."""
    cs = (state or {}).get("client_safe")
    return {"client_safe": {"variant": cs.get("variant"), "dataset_sha256": cs.get("dataset_sha256")}} if cs else {}


# ---------------------------------------------------------------- client-safe wording (EQ-C-0153, HO-20261026-B-C-010)
# Only with the client-safe marker (client_safe_marker); a house data folder is never touched. Reader text only: no
# number, stance or licence decision changes here, and nothing here can allow a source.
WITHHELD_TEXT = "withheld: licence"
PLACEHOLDER_TEXT = "placeholder (withheld: licence)"
# Generic labels for rulebook indicators whose name cites a source the register keeps out of client output. Used only
# when the name matches restricted_name_patterns; any other match has the source name removed (client_safe_label).
CLIENT_SAFE_LABELS = {"3.7": "Civil justice and contract enforcement",
                      "6.7": "Illegal economy: criminal markets score",
                      "6.9": "Political violence trend (12m vs 5y average)",
                      "6.11": "Food insecurity: share of population in crisis or worse",
                      "6.13": "Terrorism",
                      "7.11": "Climate vulnerability"}
CLIENT_SAFE_LABEL_FALLBACK = "Indicator (source name withheld: licence)"
CLIENT_SAFE_WITHHELD_FILE = "withheld.csv"


def _alias_patterns() -> list:
    from ..validation.client_safe_pack import SOURCE_NAME_ALIASES
    return [(sid, re.compile("|".join(rf"(?<![\w-]){re.escape(a)}(?![\w-])" for a in names), re.I))
            for sid, names in SOURCE_NAME_ALIASES.items() if names]


def restricted_name_patterns(data_dir) -> list:
    """[(source_id, regex)] of source names a client-safe product must not print: Team B's
    client_safe_pack.restricted_name_patterns on the data folder's licence register (every row that is not allowed,
    plus the short aliases). A register that cannot be read fails closed to every alias. [] without the marker."""
    if not client_safe_marker(data_dir):
        return []
    from ..validation.client_safe_pack import restricted_name_patterns as rnp
    from .licences import client_safe_register
    reg = client_safe_register(data_dir)
    if not reg:
        return _alias_patterns()
    try:
        return rnp(reg) or _alias_patterns()
    except Exception:                            # noqa: BLE001 - cannot tell: fail closed
        return _alias_patterns()


def _tidy_label(s: str) -> str:
    s = re.sub(r"\(\s*[,;:]\s*", "(", s)
    s = re.sub(r"\s*[,;:]\s*\)", ")", s)
    s = re.sub(r"\s*\(\s*\)", "", s)
    return re.sub(r"\s{2,}", " ", s).strip(" ,;:")


def client_safe_label(key, name, patterns) -> str:
    """The indicator name a client-safe product prints: `name` itself when no pattern matches; else the generic label
    (CLIENT_SAFE_LABELS), else the name with the source names removed, else CLIENT_SAFE_LABEL_FALLBACK."""
    name = str(name or "")
    if not patterns:
        return name

    def hit(s):
        return any(rx.search(s) for _, rx in patterns)
    if not hit(name):
        return name
    lab = CLIENT_SAFE_LABELS.get(str(key))
    if lab and not hit(lab):
        return lab
    s = name
    for _, rx in patterns:
        s = rx.sub("", s)
    s = _tidy_label(s)
    return s if s and not hit(s) else CLIENT_SAFE_LABEL_FALLBACK


def _read_marker_doc(data_dir) -> dict | None:
    p = Path(data_dir) / CLIENT_SAFE_MARKER
    try:
        if p.is_symlink() or not p.is_file() or p.stat().st_size > CLIENT_SAFE_MAX_BYTES:
            return None
        doc = json.loads(p.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return doc if isinstance(doc, dict) and doc.get("kind") == CLIENT_SAFE_KIND else None


def client_safe_withheld(data_dir) -> dict | None:
    """{(table, key, country): "withheld" | "placeholder"} of the cells the client-safe dataset withheld (licence), or
    None without the marker. From the variant's withheld.csv (the marker's dataset_dir, else the data folder's parent;
    label "placeholder" reads as a placeholder) and the marker's placeholders. A marker that cannot be read gives {}."""
    if not client_safe_marker(data_dir):
        return None
    doc = _read_marker_doc(data_dir) or {}
    out: dict = {}
    ds = doc.get("dataset_dir")
    root = Path(ds) if isinstance(ds, str) and ds.strip() else Path(data_dir).parent
    f = root / CLIENT_SAFE_WITHHELD_FILE
    try:
        if not f.is_symlink() and f.is_file() and f.stat().st_size <= CLIENT_SAFE_MAX_BYTES:
            import csv
            with open(f, newline="", encoding="utf-8") as fh:
                for r in csv.DictReader(fh):
                    k = (str(r.get("table") or ""), str(r.get("key") or ""), str(r.get("country") or ""))
                    if all(k):
                        out[k] = "placeholder" if str(r.get("label") or "").lower() == "placeholder" else "withheld"
    except (OSError, UnicodeDecodeError, ValueError):
        pass
    tam = doc.get("team_a_marker") if isinstance(doc.get("team_a_marker"), dict) else {}
    for m in (doc, tam):
        for r in m.get("placeholders") or []:
            if isinstance(r, dict):
                k = (str(r.get("table") or ""), str(r.get("key") or ""), str(r.get("country") or ""))
                if all(k):
                    out[k] = "placeholder"
    return out


# ---------------------------------------------------------------- disclaimer block
def block_text(state: dict) -> tuple[str, str]:
    """(banner, text) for the effective mode."""
    mode = state["mode"]
    return BANNER[mode], state["config"]["disclaimer"][mode] or INTERNAL_TEXT


def block_html(state: dict) -> str:
    """The mode banner, then (EQ-C-0093) the licence block: attribution per source and internal-only labels."""
    from .licences import block_html as licence_html
    banner, text = block_text(state)
    return (f"{MARKER}<div class=\"research-block\" role=\"note\" data-research-mode=\"{_h.escape(state['mode'])}\" "
            "style=\"border:2px solid #8a1c1c;background:#fff4f4;color:#4a0d0d;padding:8px 10px;margin:8px 0;font-size:13px\">"
            f"<b>{_h.escape(banner)}.</b> {_h.escape(text)}</div>" + _client_safe_html(state) + licence_html(state.get("licences")))


def _client_safe_html(state: dict) -> str:
    cs = state.get("client_safe")
    if not cs:
        return ""
    return (f"<div class=\"client-safe-draft\" data-client-safe=\"draft\">{_h.escape(client_safe_text(cs, state.get('mode')))}"
            "</div>")


def block_md(state: dict) -> str:
    from .licences import block_md as licence_md
    banner, text = block_text(state)
    lic = licence_md(state.get("licences"))
    cs = state.get("client_safe")
    draft = f"\n\n> {client_safe_text(cs, state.get('mode'))}" if cs else ""        # EQ-C-0151
    return f"> **{banner}.** {text}" + draft + (f"\n\n{lic}" if lic else "")


_BODY = re.compile(r"<body\b[^>]*>", re.I)


def apply_block(html_text: str, data_dir=None, state: dict | None = None) -> str:
    """html_text with the research block right after <body> (or at the start). Idempotent (MARKER)."""
    if MARKER in html_text:
        return html_text
    blk = block_html(state or effective_mode(data_dir))
    m = _BODY.search(html_text)
    if not m:
        return blk + html_text
    from .csp import harden                      # EQ-C-0165: the finished page gets its meta CSP (hash-only styles)
    return harden(html_text[:m.end()] + blk + html_text[m.end():])


def apply_block_md(md_text: str, data_dir=None, state: dict | None = None) -> str:
    """md_text with the research block after the first heading line (or at the start). Idempotent."""
    st = state or effective_mode(data_dir)
    blk = block_md(st)
    if blk in md_text:
        return md_text
    lines = md_text.split("\n")
    i = 1 if lines and lines[0].startswith("#") else 0
    return "\n".join(lines[:i] + ([""] if i else []) + [blk, ""] + lines[i:])


def is_internal_address(addr: str, cfg: dict) -> bool:
    """addr is on the internal allow-list (exact address, or domain equal to an internal domain), casefolded."""
    a = str(addr or "").strip().casefold()
    if a in {x.casefold() for x in cfg.get("internal_addresses") or []}:
        return True
    dom = a.rpartition("@")[2]
    return bool(dom) and dom in {d.casefold() for d in cfg.get("internal_domains") or []}


# ---------------------------------------------------------------- publication calendar
def calendar_path(data_dir) -> Path:
    return Path(data_dir) / CALENDAR_NAME


def load_calendar(data_dir) -> list[dict]:
    """The products of publication_calendar.json: id, title, kind (editorial kind or null), cadence, owner, next_due
    (the anchor date of the schedule), grace_days, command. Raises ResearchConfigError."""
    from .editorial import KINDS
    p = calendar_path(data_dir)
    if not p.exists():
        raise ResearchConfigError(f"{p} not found")
    try:
        doc = json.loads(p.read_text(encoding="utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as e:
        raise ResearchConfigError(f"{p}: not valid JSON ({e})") from None
    prods = doc.get("products") if isinstance(doc, dict) else None
    if not isinstance(prods, list) or not prods:
        raise ResearchConfigError(f"{p}: expected {{\"products\": [...]}} with at least one product")
    out, seen = [], set()
    for i, r in enumerate(prods):
        w = f"{p}: products[{i}]"
        if not isinstance(r, dict):
            raise ResearchConfigError(f"{w} must be an object")
        pid = _text(r.get("id", ""), f"{w}.id", False)
        if not re.fullmatch(r"[a-z0-9_]+", pid) or pid in seen:
            raise ResearchConfigError(f"{w}.id must be unique lower_snake_case, got {pid!r}")
        seen.add(pid)
        cad = r.get("cadence")
        if cad not in CADENCES:
            raise ResearchConfigError(f"{w}.cadence must be one of {', '.join(CADENCES)}, got {cad!r}")
        kind = r.get("kind")
        if kind is not None and kind not in KINDS:
            raise ResearchConfigError(f"{w}.kind must be an editorial kind ({', '.join(KINDS)}) or null, got {kind!r}")
        try:
            due = dt.date.fromisoformat(str(r.get("next_due")))
        except ValueError:
            raise ResearchConfigError(f"{w}.next_due must be YYYY-MM-DD, got {r.get('next_due')!r}") from None
        grace = r.get("grace_days", 0)
        if not isinstance(grace, int) or isinstance(grace, bool) or not 0 <= grace <= 31:
            raise ResearchConfigError(f"{w}.grace_days must be an integer 0-31")
        out.append({"id": pid, "title": _text(r.get("title", pid), f"{w}.title", False), "kind": kind, "cadence": cad,
                    "owner": _text(r.get("owner", ""), f"{w}.owner", False), "next_due": due, "grace_days": grace,
                    "command": _text(r.get("command", ""), f"{w}.command", True)})
    return out


def _published_dates(outputs_dir) -> dict[str, list[dt.date]]:
    """{kind: [publish dates]} of items whose state is published (or corrected: it was published) in the ledger."""
    from .editorial import list_items
    out: dict[str, list[dt.date]] = {}
    try:
        items = list_items(outputs_dir)
    except Exception:                            # noqa: BLE001 - no or unreadable ledger: nothing published
        return out
    for it in items:
        ts = it.get("published_utc") or ""
        if it.get("state") in ("published", "corrected") and ts[:10]:
            try:
                out.setdefault(it["kind"], []).append(dt.date.fromisoformat(ts[:10]))
            except ValueError:
                continue
    return out


def calendar_status(data_dir, outputs_dir, as_of: dt.date) -> list[dict]:
    """One row per calendar product at `as_of`: id, title, kind, cadence, owner, slot_due (the latest scheduled date on
    or before as_of, None before the first), next_due, last_published, status (upcoming | ok | due | overdue | untracked),
    days_overdue. A slot is met by a publish of the kind after the previous slot; status is "due" from the slot date
    through its grace days, then "overdue". A product with no editorial kind cannot be tracked from the ledger
    ("untracked" once a slot has passed)."""
    pubs = _published_dates(outputs_dir)
    rows = []
    for p in load_calendar(data_dir):
        off = CADENCES[p["cadence"]]
        anchor = pd.Timestamp(p["next_due"])
        a = pd.Timestamp(as_of)
        if anchor > a:
            slot, nxt = None, anchor
        else:
            slot = anchor
            while slot + off <= a:
                slot = slot + off
            nxt = slot + off
        dates = sorted(pubs.get(p["kind"], [])) if p["kind"] else []
        last = max([d for d in dates if d <= as_of], default=None)
        row = {k: p[k] for k in ("id", "title", "kind", "cadence", "owner", "grace_days", "command")}
        row.update(slot_due=slot.date() if slot is not None else None, last_published=last, days_overdue=0)
        if slot is None:
            row.update(status="upcoming", next_due=nxt.date())
        elif not p["kind"]:
            row.update(status="untracked", next_due=slot.date())
        else:
            prev = (slot - off).date()
            if last is not None and last > prev:
                row.update(status="ok", next_due=nxt.date())
            else:
                late = (as_of - slot.date()).days
                row.update(status="overdue" if late > p["grace_days"] else "due", next_due=slot.date(),
                           days_overdue=max(0, late - p["grace_days"]) if late > p["grace_days"] else 0)
        rows.append(row)
    order = {"overdue": 0, "due": 1, "untracked": 2, "upcoming": 3, "ok": 4}
    rows.sort(key=lambda r: (order[r["status"]], r["next_due"], r["id"]))
    return rows


def format_calendar(rows: list[dict], state: dict | None = None) -> list[str]:
    L = []
    if state is not None:
        L.append(f"Research mode: {state['mode']}" + (f" (requested {state['requested']})" if state["requested"] != state["mode"] else ""))
        L += [f"  ! {p}" for p in state["problems"]]
    L.append(f"{'status':<10} {'product':<16} {'cadence':<11} {'due':<10} {'last published':<14} owner")
    for r in rows:
        late = f" ({r['days_overdue']}d late)" if r["status"] == "overdue" else ""
        L.append(f"{r['status']:<10} {r['id']:<16} {r['cadence']:<11} {str(r['next_due']):<10} {str(r['last_published'] or '-'):<14} "
                 f"{r['owner']}{late}")
    return L


def parse_date(v) -> dt.date:
    """Strict YYYY-MM-DD (ASCII digits, year >= 1000) or ValueError."""
    s = str(v or "")
    if not re.fullmatch(r"[0-9]{4}-[0-9]{2}-[0-9]{2}", s) or int(s[:4]) < 1000:
        raise ValueError(f"not a date (YYYY-MM-DD): {v!r}")
    return dt.date.fromisoformat(s)
