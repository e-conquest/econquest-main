"""Client packaging (EQ-C-0082): BUILT BUT OFF. Client mode is Sam's decision (program board "Internal vs client").

    econquest client-package ITEM --recipient ADDR --date YYYY-MM-DD [--dest DIR]

What it would do in client mode: take a published editorial item (immutable copy verified against its manifest),
check that the recipient is entitled to the product kind (data/research.json `entitlements`: recipient -> [kinds],
changed only through `econquest change`), refuse when the product contains IMF data, and write a watermarked copy of
each HTML file ("Prepared for <recipient> on <date>", a fixed overlay plus a recipient line) under
<out>/client/<item>/<recipient>/ with a manifest of sha256s.

Refusals, in order (ClientPackageError; nothing is written):
1. research mode is not "client" (research.effective_mode: only Sam's applied change counts): the normal case today;
2. the recipient is not a plain address or not entitled to the item's kind;
3. the item is not published or its published copy does not verify;
4. IMF guard (Sam 2026-10-24 12:38Z, SEC / Team A tag "IMF: internal research use only"): `imf_problems` refuses when
   any applied input cell carries IMF data (ingestion.audit.client_restricted_cells: IMF source or licence tag, or a
   value derived from WEO) or when any product file names IMF / WEO (audit.CLIENT_RESTRICTED_SOURCE_RE, the licence
   terms). A check that cannot run fails closed.
5. licence guard (EQ-C-0093): `licence_problems` refuses while Team A's licence register (data/licences.csv,
   presentation/licences.py) is missing or unreadable, while any cell in use is internal-only (IMF, theratesapi.com
   under EXC-005, non-commercial, unregistered), naming the cell or column and its licence, or when a page has no
   attribution block (built before EQ-C-0093: rebuild it).
ops/distribute.py applies 2, 4 and 5 to every recipient in client mode as well.

EQ-C-0107: presentation/client_build.py (`econquest client-export`, also off) calls package(..., trace=True) for every
item a recipient is entitled to; trace adds a per-file watermark id (watermark_id) to the page head and recipient line.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import html as _h
import json
import re
from pathlib import Path

from .csp import harden
from .house_style import WATERMARK_CSS


class ClientPackageError(ValueError):
    """A refused client package (client mode off, not entitled, unpublished, IMF data)."""


def entitled(cfg: dict, recipient: str, kind: str) -> bool:
    return kind in (cfg.get("entitlements") or {}).get(str(recipient or "").strip().casefold(), [])


def imf_problems(data_dir, texts: dict[str, str] | None = None) -> list[str]:
    """Why this product may not go to a client because of IMF data (empty = none found). Fails closed."""
    from ..ingestion import audit
    from .research import client_restricted_cells        # EQ-C-0083: refuses when the provenance evidence is missing
    out = []
    try:
        cells = client_restricted_cells(data_dir)
        if len(cells):
            out.append(f"{len(cells)} applied input cell(s) carry IMF data ({audit.CLIENT_RESTRICTED_REASON})")
    except Exception as e:                                     # noqa: BLE001 - cannot tell: refuse
        out.append(f"the IMF client-output check could not run ({type(e).__name__}: {e}); refused (fails closed)")
    terms = [re.escape(t) for t in audit.CLIENT_RESTRICTED_LICENCE_TERMS]
    rx = re.compile(audit.CLIENT_RESTRICTED_SOURCE_RE.pattern + "|" + "|".join(terms), re.IGNORECASE)
    for name, text in (texts or {}).items():
        m = rx.search(text)
        if m:
            out.append(f"{name} names IMF data ({m.group(0)!r}): IMF data is internal research use only")
    return out


def licence_problems(data_dir, texts: dict[str, str] | None = None) -> list[str]:
    """Why this product may not go to a client under the licence register (empty = allowed). Fails closed."""
    from .licences import LICENCE_MARKER, refusals, safe_evaluate
    out = [f"licence: {r}" for r in refusals(safe_evaluate(data_dir))]
    for name, text in (texts or {}).items():
        if name.lower().endswith((".html", ".htm")) and LICENCE_MARKER not in text:
            out.append(f"{name} has no attribution block (built before EQ-C-0093): rebuild the product")
    return out


def watermark_id(recipient: str, date: str, item_id: str, name: str) -> str:
    """EQ-C-0107: a per-copy trace id (sha256 of recipient, date, item and file, 16 hex), so a leaked page names its copy."""
    key = "\x1f".join((str(recipient).strip().casefold(), str(date), str(item_id), str(name)))
    return hashlib.sha256(key.encode("utf-8")).hexdigest()[:16]


def watermark_html(html_text: str, recipient: str, date: str, mark_id: str | None = None) -> str:
    """The page with the watermark CSS, a fixed diagonal overlay and a recipient line (all text escaped). With mark_id
    (EQ-C-0107) the head also carries <meta name="eq-watermark-id"> and the recipient line names the id."""
    label = _h.escape(f"Prepared for {recipient} on {date}")
    head = f"<style>{WATERMARK_CSS}</style>"
    if mark_id is not None:
        if not re.fullmatch(r"[0-9a-f]{16}", str(mark_id)):
            raise ClientPackageError("watermark id must be 16 lowercase hex characters")
        head += f"<meta name=\"eq-watermark-id\" content=\"{mark_id}\">"
    mark = (f"<div class='eq-watermark' aria-hidden='true'><span>{label}</span></div>"
            f"<div class='eq-recipient' role='note'>{label}. Not for onward distribution."
            + (f" Copy {mark_id}." if mark_id is not None else "") + "</div>")
    t = html_text.replace("</head>", head + "</head>", 1) if "</head>" in html_text else head + html_text
    m = re.search(r"<body\b[^>]*>", t, re.I)
    return t[:m.end()] + mark + t[m.end():] if m else mark + t


def package(outputs_dir, data_dir, item_id: str, recipient: str, date: dt.date, dest=None, trace: bool = False) -> dict:
    """Write the watermarked client copy of a published item (see the module docstring). Returns
    {"item_id", "kind", "recipient", "date", "dir", "files": [{name, sha256}], "manifest"}. trace=True (EQ-C-0107,
    client_build.entitled_export) adds a per-file watermark id ({name, sha256, watermark_id})."""
    from ..ops.distribute import DistributionError, _published, check_address
    from .research import effective_mode
    st = effective_mode(data_dir)
    if st["mode"] != "client":
        raise ClientPackageError("client packaging is off: research mode is internal (client mode is Sam's decision and needs "
                                 "his approved `econquest change` on data/research.json)" + (f"; {st['problems'][0]}" if st["problems"] else ""))
    try:
        rcpt = check_address(recipient, "recipient")
        it = _published(outputs_dir, item_id)
    except DistributionError as e:
        raise ClientPackageError(str(e)) from None
    if not entitled(st["config"], rcpt, it["kind"]):
        raise ClientPackageError(f"{rcpt} is not entitled to {it['kind']} (data/research.json entitlements)")
    src = Path(outputs_dir) / it["published_dir"]
    pages = {p.name: p.read_text(encoding="utf-8", errors="replace") for p in sorted(src.iterdir()) if p.suffix.lower() in (".html", ".htm")}
    if not pages:
        raise ClientPackageError(f"{item_id} has no HTML file to package")
    probs = imf_problems(data_dir, pages)
    if probs:
        raise ClientPackageError("IMF guard: " + "; ".join(probs[:5]))
    probs = licence_problems(data_dir, pages)
    if probs:
        raise ClientPackageError("licence guard: " + "; ".join(probs[:6]))
    slug = re.sub(r"[^a-z0-9]+", "-", rcpt.casefold())          # SEC-C-014 L2: + a hash, so a.b@x and a-b@x never share
    slug += "-" + hashlib.sha256(rcpt.casefold().encode("utf-8")).hexdigest()[:8]
    out = Path(dest) if dest else Path(outputs_dir) / "client" / item_id / slug
    out.mkdir(parents=True, exist_ok=True)
    files = []
    for name, text in pages.items():
        mid = watermark_id(rcpt, date.isoformat(), item_id, name) if trace else None
        data = harden(watermark_html(text, rcpt, date.isoformat(), mid)).encode("utf-8")     # EQ-C-0165 meta CSP
        (out / name).write_bytes(data)
        files.append({"name": name, "sha256": hashlib.sha256(data).hexdigest(), **({"watermark_id": mid} if trace else {})})
    res = {"item_id": item_id, "kind": it["kind"], "recipient": rcpt, "date": date.isoformat(), "dir": str(out), "files": files,
           "approval": st["approval"]}
    (out / "client-manifest.json").write_text(json.dumps(res, indent=1, default=str), encoding="utf-8")
    return {**res, "manifest": str(out / "client-manifest.json")}
