"""Presentation and API tier (paper Appendix B.5): JSON REST endpoints, Server-Sent Events for live
updates, an interactive pillar-adjustment workbench endpoint and a self-contained dashboard page."""
from .dashboard import render_dashboard  # noqa: F401
from .api import serve  # noqa: F401
