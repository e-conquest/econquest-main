"""Trade-idea ledger view (EQ-C-0047, GOV-032): hit rate and P&L by quarter from Team B's idea log, for the GUI Ideas tab
and the workbook 'Trade Ideas' tab (sheets_publish.ideas_plan). Formatting only: the log is read with
idea_log.load_log (outputs/idea_log.csv) and every hit rate and P&L figure is Team B's idea_log.idea_report run on the
ideas of one quarter; nothing here marks, sizes or closes an idea. The escaped outputs/idea_report.csv is not read.

Quarter rules (calendar quarters, labelled 2026Q4):
    opened        ideas whose entry run as_of falls in the quarter
    closed        ideas whose close_date falls in the quarter
    hit_rate      idea_report "all" hit_rate of the ideas closed in the quarter (closed, marked, return > 0)
    pnl_mm        idea_report "all" pnl_realised_mm of the ideas closed in the quarter ($mm)
    open_end      ideas opened on or before the quarter end and not closed by then
The total row is idea_report's "all" row over the whole log; open P&L at the latest mark is given separately.
Illustrative, Tier 3: no reported, limit-tested or sized number reads the log.

    from econquest.presentation.ideas_view import ideas_summary
    s = ideas_summary("outputs")   # {"status": "ok" | "empty" | "missing" | "invalid", "label", "message", "quarters", "total", ...}
"""
from __future__ import annotations
import math
from pathlib import Path

import pandas as pd

from ..validation import idea_log

LABEL = ("Illustrative, Tier 3 (GOV-032): Playbook activations sized by the dashboard rule and marked on Market History; "
         "no reported, limit-tested or sized number reads this log. P&L excludes carry, financing and costs.")
LOG_FILE = "idea_log.csv"
NO_LOG = "No trade-idea log yet: run `econquest ideas log` (or `econquest run`) to start outputs/idea_log.csv."
EMPTY_LOG = "The trade-idea log has no ideas yet: no Playbook trade has activated since the log started."
COLUMNS = ("quarter", "opened", "closed", "closed_marked", "hit_rate", "pnl_mm", "open_end")
HEADER = ["Quarter", "Ideas opened", "Ideas closed", "Closed and marked", "Hit rate (closed, marked)",
          "P&L realised $mm (closed in quarter)", "Open at quarter end"]


def _num(v):
    """JSON-safe number: NaN / inf -> None."""
    if v is None:
        return None
    v = float(v)
    return None if math.isnan(v) or math.isinf(v) else v


def _all_row(log: pd.DataFrame) -> dict:
    """Team B's 'all' statistics for a set of ideas."""
    return idea_log.idea_report(log).iloc[0].to_dict()


def quarterly(log: pd.DataFrame) -> list[dict]:
    """One row per calendar quarter from the first opened idea to the last open, close or mark date (see module doc)."""
    if not len(log):
        return []
    opened = pd.to_datetime(log["as_of"]); closed = pd.to_datetime(log["close_date"])
    dates = pd.concat([opened, closed, pd.to_datetime(log["mark_date"])]).dropna()
    if dates.empty:
        return []
    q_open, q_close = opened.dt.to_period("Q"), closed.dt.to_period("Q")
    rows = []
    for q in pd.period_range(opened.min().to_period("Q") if opened.notna().any() else dates.min().to_period("Q"), dates.max().to_period("Q"), freq="Q"):
        qend = q.end_time.normalize()
        shut = log[(q_close == q).to_numpy()]
        a = _all_row(shut)
        open_end = int(((opened <= qend) & (closed.isna() | (closed > qend))).sum())
        rows.append({"quarter": f"{q.year}Q{q.quarter}", "opened": int((q_open == q).sum()), "closed": int(len(shut)),
                     "closed_marked": int(a["closed_marked"]), "hit_rate": _num(a["hit_rate"]), "pnl_mm": _num(a["pnl_realised_mm"]),
                     "open_end": open_end})
    return rows


def ideas_summary(out_dir: str | Path) -> dict:
    """The ledger view of <out_dir>/idea_log.csv. status: ok, empty (log with no ideas), missing (no log file), invalid
    (unreadable log). Text is returned raw: the GUI escapes it, the workbook plan formula-escapes it."""
    f = Path(out_dir) / LOG_FILE
    base = {"label": LABEL, "file": LOG_FILE, "as_of": None, "run_id": None, "quarters": [], "total": None,
            "pnl_open_mm": None, "pnl_total_mm": None, "unmarked": None, "unmarked_share": None, "ideas": 0}
    if not f.exists():
        return {**base, "status": "missing", "message": NO_LOG}
    try:
        log = idea_log.load_log(f)
    except (pd.errors.EmptyDataError, pd.errors.ParserError, OSError, UnicodeDecodeError, ValueError, TypeError) as e:
        return {**base, "status": "invalid", "message": f"The trade-idea log {LOG_FILE} could not be read ({type(e).__name__}); rerun `econquest ideas log`."}
    if not len(log):
        return {**base, "status": "empty", "message": EMPTY_LOG}
    a = _all_row(log)
    seen = pd.concat([pd.to_datetime(log[c]) for c in ("as_of", "mark_date", "close_date")]).dropna()
    latest = log.loc[pd.to_datetime(log["as_of"]).idxmax(), "run_id"] if log["as_of"].notna().any() else None
    total = {"quarter": "All quarters", "opened": int(a["ideas"]), "closed": int(a["closed"]), "closed_marked": int(a["closed_marked"]),
             "hit_rate": _num(a["hit_rate"]), "pnl_mm": _num(a["pnl_realised_mm"]), "open_end": int(a["open"])}
    as_of = seen.max().date().isoformat() if len(seen) else None
    msg = (f"{int(a['ideas'])} ideas ({int(a['open'])} open, {int(a['closed'])} closed); {int(a['unmarked'])} unmarked "
           f"(no daily price for the instrument). As of {as_of or 'not recorded'}.")
    return {**base, "status": "ok", "message": msg, "as_of": as_of, "run_id": None if latest is None or pd.isna(latest) else str(latest),
            "quarters": quarterly(log), "total": total, "pnl_open_mm": _num(a["pnl_open_mm"]), "pnl_total_mm": _num(a["pnl_total_mm"]),
            "unmarked": int(a["unmarked"]), "unmarked_share": _num(a["unmarked_share"]), "ideas": int(a["ideas"])}
