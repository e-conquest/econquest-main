"""Event calendar view and alerts (EQ-C-0155, HO-20261026-A-C-010) on Team A's calendar (EQ-A-0132).

Reads only Team A's API, always with an explicit `today`:

    calendar.upcoming(days, today=..., data_dir=..., country=..., kinds=..., min_importance=...)   alert rows
    calendar.events(data_dir, as_of=today)                                                       what is stored, per kind
    calendar.demo_calendar_data(data_dir)                                                        demo row M18 (data side)

Every row shown anywhere (CLI, GET /api/events-calendar, the GUI cards, the morning view, health alerts) carries only
calendar.ALERT_FIELDS plus event_id and days_until (DISPLAY_FIELDS). Author and approver names (QUERY_COLUMNS) never
leave this module (SEC-A-015 C-I3). A client view (client=True: `econquest events --client`, ?client=1) keeps only
rows whose client_output is "allowed"; the internal desk views show every row with its client_output tag.

    econquest events [--days N] [--country C] [--type T ...] [--min-importance 1-3] [--today D] [--client] [--json]
    econquest events --alerts [...]          only the rows at or above the alert threshold (default importance 2,
                                             next ALERT_DAYS days), the same rows `econquest health` alerts on

Event types (--type, ?type=): TYPES below; a Team A kind name (calendar.KINDS) is accepted too. A type with nothing
stored gets a plain-sentence empty state ("No IMF review dates yet; they arrive with the next data pull.").

Today's data: 78 World Bank IDS debt-service rows (annual aggregates, importance 1: shown, never alerted by default);
elections, IMF reviews, rating dates and Eurobonds are empty until their sources land.
"""
from __future__ import annotations

import datetime as dt
import json
import re
import sys
from pathlib import Path

SCHEMA = "econquest-events-calendar/1"
DEFAULT_DAYS = 90               # the view and the morning section
ALERT_DAYS = 30                 # alerts look this far ahead
ALERT_MIN_IMPORTANCE = 2        # Team A's upcoming() default: importance-1 rows (aggregate debt service) never alert
MAX_DAYS = 3660               # ten years: the IDS projections run to 2032
MORNING_ROWS = 10
IMPORTANCE = {1: "low", 2: "medium", 3: "high"}
# type key -> (Team A kinds, label, empty-state sentence for a type with nothing stored; plain words, no commands)
TYPES = {
    "election": (("election",), "elections", "No election dates yet; they arrive with the next data pull."),
    "imf": (("imf_programme", "imf_review"), "IMF programmes and reviews",
            "No IMF review dates yet; they arrive with the next data pull."),
    "eurobond": (("eurobond_maturity", "eurobond_amortisation"), "Eurobond maturities and amortisation",
                 "No Eurobond maturities yet; they arrive once the bond terms are entered and checked."),
    "rating": (("rating_review",), "rating review dates",
               "No rating review dates yet; they arrive with the next data pull."),
    "debt_service": (("external_debt_service",), "external debt service (annual, World Bank projection)",
                     "No external debt-service projections yet; they arrive with the next data pull."),
}
ADAPTER = {"election": "electionguide", "imf": "imf_mona", "rating": "rating_calendar", "eurobond": "manual entry",
           "debt_service": "recorded pull"}         # IDS is read from a recorded pull, not a drop folder
KIND_TYPE = {k: t for t, (kinds, _l, _m) in TYPES.items() for k in kinds}
KIND_LABEL = {"election": "election", "imf_programme": "IMF programme", "imf_review": "IMF review",
              "eurobond_maturity": "Eurobond maturity", "eurobond_amortisation": "Eurobond amortisation",
              "external_debt_service": "external debt service", "rating_review": "rating review"}
_DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_COUNTRY = re.compile(r"^[A-Za-z][A-Za-z .'()-]{1,59}$")


class EventsViewError(ValueError):
    """A bad filter: the message never holds a path or the caller's raw input."""


def display_fields() -> list[str]:
    from ..ingestion import calendar
    return list(calendar.ALERT_FIELDS) + ["event_id", "days_until"]


def _today(today) -> dt.date:
    if today is None:
        return dt.datetime.now(dt.timezone.utc).date()
    if isinstance(today, dt.datetime):
        return today.astimezone(dt.timezone.utc).date() if today.tzinfo else today.date()
    if isinstance(today, dt.date):
        return today
    s = str(today).strip()
    if not _DATE.match(s):
        raise EventsViewError("today must be YYYY-MM-DD")
    try:
        return dt.date.fromisoformat(s)
    except ValueError:
        raise EventsViewError("today must be a real date (YYYY-MM-DD)") from None


def resolve_types(types) -> list[str] | None:
    """--type values (type keys of TYPES or Team A kind names, comma lists allowed) -> Team A kinds, or None (all)."""
    if not types:
        return None
    vals = [types] if isinstance(types, str) else list(types)
    kinds: list[str] = []
    for v in vals:
        for t in str(v).split(","):
            t = t.strip().lower()
            if not t:
                continue
            if t in TYPES:
                kinds += [k for k in TYPES[t][0] if k not in kinds]
            elif t in KIND_TYPE:
                kinds += [t] if t not in kinds else []
            else:
                raise EventsViewError(f"unknown event type; use one of {', '.join(TYPES)}")
    return kinds or None


def _importance(v, default: int) -> int:
    if v is None or v == "":
        return default
    try:
        i = int(v)
    except (TypeError, ValueError):
        raise EventsViewError("min importance must be 1, 2 or 3") from None
    if i not in IMPORTANCE:
        raise EventsViewError("min importance must be 1, 2 or 3")
    return i


def _days(v, default: int) -> int:
    if v is None or v == "":
        return default
    try:
        i = int(v)
    except (TypeError, ValueError):
        raise EventsViewError(f"days must be a whole number from 0 to {MAX_DAYS}") from None
    if not 0 <= i <= MAX_DAYS:
        raise EventsViewError(f"days must be a whole number from 0 to {MAX_DAYS}")
    return i


def _clean(row: dict) -> dict:
    """Only DISPLAY_FIELDS, plain values, plus labels. Never author / approver / provenance."""
    out = {}
    for k in display_fields():
        v = row.get(k)
        if k in ("importance", "days_until"):
            out[k] = int(v) if v is not None else None
        else:
            out[k] = "" if v is None or (isinstance(v, float) and v != v) else str(v)[:500]
    out["type"] = KIND_TYPE.get(out["kind"], "other")
    out["kind_label"] = KIND_LABEL.get(out["kind"], out["kind"])
    out["importance_label"] = IMPORTANCE.get(out["importance"], "")
    return out


def _upcoming(data_dir, today: dt.date, days: int, country, kinds, min_importance: int, client: bool) -> list[dict]:
    from ..ingestion import calendar
    try:
        rows = calendar.upcoming(days, today=today, data_dir=data_dir, country=country, kinds=kinds,
                                 min_importance=min_importance)
    except calendar.CalendarError as e:
        msg = str(e)
        if "country" in msg:
            raise EventsViewError("country must be an ISO3 code or a name in countries.csv") from None
        raise EventsViewError("the calendar refused the filter") from None
    rows = [_clean(r) for r in rows]
    if client:                                           # SEC-A-015 C-I3: a client view shows allowed rows only
        rows = [r for r in rows if r["client_output"] == "allowed"]
    return rows


def _stored_by_type(data_dir, today: dt.date, client: bool) -> dict:
    from ..ingestion import calendar
    df = calendar.events(data_dir, as_of=today)
    if client and len(df):
        df = df[df["client_output"] == "allowed"]
    counts = {t: 0 for t in TYPES}
    for k, n in (df["kind"].value_counts().items() if len(df) else []):
        t = KIND_TYPE.get(k)
        if t:
            counts[t] += int(n)
    return counts


def alert_rows(data_dir=None, today=None, days: int = ALERT_DAYS, min_importance: int = ALERT_MIN_IMPORTANCE,
               country=None, kinds=None, client: bool = False) -> list[dict]:
    """Events at or above `min_importance` whose period overlaps [today, today + days]: what alerts."""
    return _upcoming(data_dir, _today(today), int(days), country, kinds, int(min_importance), client)


def calendar_view(data_dir=None, today=None, days: int | None = None, country=None, types=None,
                  min_importance: int | None = None, client: bool = False, alert_days: int = ALERT_DAYS,
                  alert_min_importance: int = ALERT_MIN_IMPORTANCE) -> dict:
    """The view payload (SCHEMA): rows in the window, one entry per event type (stored count, rows in the window,
    empty-state sentence), and the alerts. Raises EventsViewError on a bad filter."""
    t = _today(today)
    days = _days(days, DEFAULT_DAYS)
    mi = _importance(min_importance, 1)
    kinds = resolve_types(types)
    rows = _upcoming(data_dir, t, days, country, kinds, mi, client)
    aw, ami = min(days, int(alert_days)), max(mi, int(alert_min_importance))
    alerts = _upcoming(data_dir, t, aw, country, kinds, ami, client)
    stored = _stored_by_type(data_dir, t, client)
    wanted = [x for x in TYPES if kinds is None or set(TYPES[x][0]) & set(kinds)]
    by_type = []
    for x in wanted:
        n = sum(1 for r in rows if r["type"] == x)
        label = TYPES[x][1]
        msg = (TYPES[x][2] if not stored[x] else
               "" if n else f"No {label} in the next {days} days.")
        by_type.append({"type": x, "label": label, "stored": stored[x], "in_window": n, "empty": not n,
                        "message": msg, "adapter": ADAPTER[x]})
    total = len(rows)
    msg = (f"{total} event{'s' if total != 1 else ''} in the next {days} days at importance {mi} or above; "
           f"{len(alerts)} alert{'s' if len(alerts) != 1 else ''} (importance {ami} or above, next {aw} days).")
    return {"schema": SCHEMA, "today": t.isoformat(), "days": days, "min_importance": mi,
            "types": wanted, "client": bool(client), "status": "ok" if total else "empty",
            "count": total, "rows": rows, "by_type": by_type,
            "alerts": {"window_days": aw, "min_importance": ami, "count": len(alerts), "items": alerts},
            "message": msg}


# ---------------------------------------------------------------- morning view (ops.morning.collect)
def morning_section(data_dir, today, days: int = DEFAULT_DAYS, rows: int = MORNING_ROWS) -> dict:
    """The morning view's "upcoming events": the next `days` days (all importances) plus the alerts. Never raises."""
    try:
        v = calendar_view(data_dir, today=today, days=days)
    except Exception as e:                               # noqa: BLE001 - error type only, never a path
        return {"status": "unavailable", "today": str(today), "window_days": days, "count": 0, "items": [], "more": 0,
                "alerts": {"window_days": ALERT_DAYS, "min_importance": ALERT_MIN_IMPORTANCE, "count": 0, "items": []},
                "empty_types": [], "message": f"event calendar could not be read ({type(e).__name__})"}
    return {"status": v["status"], "today": v["today"], "window_days": v["days"], "count": v["count"],
            "items": v["rows"][:rows], "more": max(0, v["count"] - rows), "alerts": v["alerts"],
            "empty_types": [{"type": b["type"], "label": b["label"], "message": b["message"]}
                            for b in v["by_type"] if not b["stored"]],
            "message": v["message"]}


def _row_line(r: dict) -> str:
    span = r["date"] if not r["date_end"] or r["date_end"] == r["date"] else f"{r['date']}..{r['date_end']}"
    when = "under way" if r["days_until"] == 0 else f"in {r['days_until']}d"
    return (f"{span:<22} {when:>9}  {r['iso3']}  {r['kind_label']:<22} [{r['importance']} {r['importance_label']}] "
            f"{r['title']} ({r['source_id']}; client {r['client_output']})")


def morning_lines(sec: dict) -> list[str]:
    """Text lines for render_text of ops.morning."""
    L = [f"Upcoming events (next {sec.get('window_days')} days): {sec.get('message')}"]
    for r in sec.get("items") or []:
        L.append("  " + _row_line(r))
    if sec.get("more"):
        L.append(f"  ... {sec['more']} more")
    al = sec.get("alerts") or {}
    L.append(f"  Event alerts (importance {al.get('min_importance')} or above, next {al.get('window_days')} days): "
             + (str(al.get("count")) if al.get("count") else "none"))
    for r in al.get("items") or []:
        L.append("    ALERT " + _row_line(r))
    for e in sec.get("empty_types") or []:
        L.append(f"  {e['message']}")
    return L


def render_text(v: dict, alerts_only: bool = False) -> str:
    L = []
    if alerts_only:
        al = v["alerts"]
        L.append(f"Event alerts, today {v['today']}: importance {al['min_importance']} or above, next {al['window_days']} days"
                 + (" (client view: allowed rows only)" if v["client"] else ""))
        L += ["  " + _row_line(r) for r in al["items"]] or ["  none"]
        return "\n".join(L) + "\n"
    L.append(f"Event calendar, today {v['today']}: {v['message']}" + (" Client view: allowed rows only." if v["client"] else ""))
    L += ["  " + _row_line(r) for r in v["rows"]]
    L.append("By type:")
    for b in v["by_type"]:
        L.append(f"  {b['label']}: {b['stored']} stored, {b['in_window']} in the window" + (f". {b['message']}" if b["message"] else ""))
    al = v["alerts"]
    L.append(f"Alerts (importance {al['min_importance']} or above, next {al['window_days']} days): " + (str(al["count"]) if al["count"] else "none"))
    L += ["  ALERT " + _row_line(r) for r in al["items"]]
    return "\n".join(L) + "\n"


# ---------------------------------------------------------------- GET /api/events-calendar
def _q(qs: dict, k: str) -> str:
    return str((qs.get(k) or [""])[0]).strip()


def api_events_calendar(data_dir, qs: dict) -> tuple[int, dict]:
    """GET /api/events-calendar?days=&country=&type=&min_importance=&today=&client=0|1. (status, body); a bad filter is
    400 {"error"} with a fixed message (never a path or the raw input). Read only."""
    try:
        country = _q(qs, "country") or None
        if country is not None and not _COUNTRY.match(country):
            raise EventsViewError("country must be an ISO3 code or a name in countries.csv")
        client = _q(qs, "client")
        if client not in ("", "0", "1"):
            raise EventsViewError("client must be 0 or 1")
        return 200, calendar_view(data_dir, today=_q(qs, "today") or None, days=_q(qs, "days") or None,
                                  country=country, types=_q(qs, "type") or None,
                                  min_importance=_q(qs, "min_importance") or None, client=client == "1")
    except EventsViewError as e:
        return 400, {"error": str(e)}
    except Exception as e:                               # noqa: BLE001 - error type only
        return 200, {"error": f"event calendar could not be read ({type(e).__name__})", "rows": [], "by_type": []}


# ---------------------------------------------------------------- demo row M18
def demo_events_view(data_dir, out_dir=None, today=None) -> dict:
    """Demo row M18 (view side): Team A's demo_calendar_data passes, the view and the morning section render, every
    empty type has its sentence (an empty type whose adapter answers is "no events yet, adapter ok"), and no row
    carries a field outside DISPLAY_FIELDS. {"ok", "problems", "summary", "types", "evidence"}; never raises."""
    from ..ingestion import calendar
    problems: list[str] = []
    types: dict = {}
    evidence = None
    data = {"ok": False, "counts": {}}
    try:
        data = calendar.demo_calendar_data(data_dir)
        problems += [f"calendar data: {p}" for p in data.get("problems") or []]
        drops = (data.get("counts") or {}).get("drops") or {}
        t = _today(today)
        v = calendar_view(data_dir, today=t, days=365)
        allowed = set(display_fields()) | {"type", "kind_label", "importance_label"}
        for r in v["rows"] + v["alerts"]["items"]:
            extra = set(r) - allowed
            if extra:
                problems.append(f"row carries fields outside ALERT_FIELDS: {sorted(extra)}")
                break
        for b in v["by_type"]:
            if b["stored"]:
                types[b["type"]] = f"{b['stored']} events stored, {b['in_window']} in the next 365 days"
                continue
            ad = ADAPTER[b["type"]]
            ok_ad = ad in ("manual entry", "recorded pull") or drops.get(ad) in ("not dropped", "dropped")
            if not b["message"] or "econquest" in b["message"] or "`" in b["message"]:
                problems.append(f"{b['type']}: empty state is missing or names a command")
            types[b["type"]] = "no events yet, adapter ok" if ok_ad else f"no events yet, adapter {ad} did not answer"
            if not ok_ad:
                problems.append(f"{b['type']}: adapter {ad} did not answer")
        text = render_text(v)
        sec = morning_section(data_dir, t)
        lines = morning_lines(sec)
        if sec["status"] == "unavailable":
            problems.append(f"morning section: {sec['message']}")
        if not text.strip() or not lines:
            problems.append("view or morning section rendered empty")
        if out_dir is not None:
            d = Path(out_dir)
            d.mkdir(parents=True, exist_ok=True)
            (d / "events_view.json").write_text(json.dumps({"view": v, "morning": sec}, indent=1), encoding="utf-8")
            (d / "events_view.txt").write_text(text + "\n" + "\n".join(lines) + "\n", encoding="utf-8")
            evidence = "events_view.json"
    except Exception as e:                               # noqa: BLE001 - reported, never a silent pass
        problems.append(f"{type(e).__name__}: {e}"[:300])
    n = (data.get("counts") or {}).get("events", 0)
    summary = (f"M18 event calendar view: {n} events; " + "; ".join(f"{k}: {s}" for k, s in types.items())
               + (f"; {len(problems)} problems" if problems else ""))
    return {"ok": not problems, "problems": problems, "summary": summary, "types": types, "evidence": evidence}


# ---------------------------------------------------------------- CLI
def cmd_events(args) -> None:
    alerts = bool(args.alerts)
    try:
        v = calendar_view(args.data, today=args.today, days=args.days,
                          country=args.country, types=args.type, min_importance=args.min_importance,
                          client=args.client,
                          alert_days=args.days if alerts and args.days is not None else ALERT_DAYS,
                          alert_min_importance=args.min_importance if alerts and args.min_importance else ALERT_MIN_IMPORTANCE)
    except EventsViewError as e:
        print(f"[events] {e}", file=sys.stderr)
        sys.exit(2)
    if args.json:
        print(json.dumps(v["alerts"] | {"today": v["today"], "client": v["client"]} if alerts else v, indent=1))
    else:
        print(render_text(v, alerts_only=alerts), end="")


def register(sub) -> None:
    ev = sub.add_parser("events", help="event calendar (EQ-C-0155, Team A's EQ-A-0132 data): elections, IMF reviews, Eurobond "
                        "maturities, external debt service and rating dates in the next N days, with the alerts; read only. "
                        "Not `calendar`, which is the research publication calendar",
                        description="Event calendar (read only): upcoming dated events for the desk names and the "
                        "event alerts.")
    from ..cli import _as_of_arg
    ev.add_argument("--days", type=int, help=f"window in days from today (default {DEFAULT_DAYS}; with --alerts {ALERT_DAYS})")
    ev.add_argument("--country", help="ISO3 code or a country name from data/countries.csv")
    ev.add_argument("--type", action="append", help=f"event type, repeatable or comma separated: {', '.join(TYPES)} "
                    "(or a Team A kind name)")
    ev.add_argument("--min-importance", type=int, choices=(1, 2, 3),
                    help=f"lowest importance shown (default 1; with --alerts {ALERT_MIN_IMPORTANCE})")
    ev.add_argument("--today", type=_as_of_arg, help="the day the window starts, YYYY-MM-DD (default: today, UTC)")
    ev.add_argument("--alerts", action="store_true", help="only the events at or above the alert threshold "
                    f"(importance {ALERT_MIN_IMPORTANCE}+, next {ALERT_DAYS} days unless --min-importance / --days)")
    ev.add_argument("--client", action="store_true", help="client view: only rows whose licence allows client output")
    ev.add_argument("--json", action="store_true", help=f"print the payload as JSON ({SCHEMA})")
    ev.set_defaults(fn=cmd_events)
