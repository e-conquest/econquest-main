"""INTERNAL analyst-judgement overlay page and CLI (EQ-C-0161, HO-20261026-B-C-014) over Team B's
econquest.validation.analyst_overlay (EQ-B-0138). Page/row id for Team B's inventory (EQ-B-0139): page
"analyst-overlay", rows OVERLAY_ROW_ID ("overlay-row") keyed by entry_id.

The overlay sits BESIDE the model output, never in its place: every page row keeps model_value, overlay_delta and
overlaid_value as separate columns (PAGE_COLUMNS), next to author, approver, self_approved / exc_id, reason, expires
and the run's run_id / data_hash. Nothing here writes to the run dict, the store, outputs/ or the workbook, and no
client path (client_build, client_outbox, client_pack, publish) imports this module (tests/test_overlay_view.py).
Every view calls Team B's assert_internal before rendering; a client audience is refused.

OFF BY DEFAULT. The page and GET /api/overlay follow the settings switch research.analyst_overlay.enabled (absent from
data/assumptions.json, so off): while off they return {"enabled": false} with no rows and read nothing. The GUI card
is hidden then. The CLI passes enabled=True to Team B's functions only when that switch is on or `--enable` is given
on the command line (recorded in the action log with the rest of the arguments):

    econquest overlay add      --as-of D --author A --country C --pillar 1-7 --notches -2..2 --reason R --expires D [--enable]
    econquest overlay approve  OVL-nnnn --as-of D --approver B [--as USER_ID] [--exc EXC-nnn] [--note N] [--enable]
    econquest overlay withdraw OVL-nnnn --as-of D --actor A --reason R [--enable]
    econquest overlay list     --as-of D [--rows] [--json] [--enable]        entries, or --rows: page rows vs outputs/run_latest.json
    econquest overlay verify   --as-of D [--expect-head SEQ:HASH]            chain and head (read only; no switch needed)

OverlayError -> exit 1 with the message. add / approve / withdraw are logged in the operator action log.
Named users (ops/identity.py scope "overlay"): approve with --as signs the approval into data/approvals/signoffs.jsonl;
under users.json enforcement --as is required, the author must be a registered user and a self-approval is refused
unless --exc names a users.json exception for "overlay" (Team B's module is stricter still and refuses self-approval
outright under enforcement).
"""
from __future__ import annotations

import json
import re
from pathlib import Path

PAGE_ID = "analyst-overlay"
OVERLAY_ROW_ID = "overlay-row"
SCHEMA = "econquest-overlay-page/1"
AUDIENCE = "internal"
BANNER = "INTERNAL - analyst overlay shown beside the model output, never in its place; not for clients"
PAGE_COLUMNS = ("country", "row", "pillar", "pillar_name", "model_value", "overlay_delta", "overlaid_value",
                "overlay_notches", "cap", "entry_id", "author", "approver", "approved_on", "self_approved", "exc_id",
                "reason", "entered_on", "expires", "run_id", "data_hash", "synthetic", "audience")
VALUE_COLUMNS = ("model_value", "overlay_delta", "overlaid_value")      # always three separate columns
WRITE_CMDS = ("add", "approve", "withdraw")
DATE_RE = re.compile(r"\d{4}-\d{2}-\d{2}")
_ABS_PATH_RE = re.compile(r"(?:[A-Za-z]:)?[\\/][^\s'\"]+")


def _ov():
    from ..validation import analyst_overlay
    return analyst_overlay


def switch_on(settings) -> bool:
    """The settings switch research.analyst_overlay.enabled (exactly True); off when absent or unreadable."""
    try:
        return _ov().overlay_enabled(None, settings)
    except Exception:                                  # noqa: BLE001 - an unreadable switch is off
        return False


def root_for(data_dir) -> Path:
    """The folder whose docs/validation/ holds the overlay ledger: the parent of the data folder."""
    return Path(data_dir).resolve().parent


def _stamps(run: dict) -> tuple[str, str]:
    s, p = (run or {}).get("summary") or {}, (run or {}).get("provenance") or {}
    v = p.get("versions") or s.get("versions") or {}
    return str(s.get("run_id") or (run or {}).get("run_id") or ""), str(v.get("data_hash") or "")


def run_as_of(run: dict) -> str:
    """The run's own as-of date (never the wall clock); "" when the run does not record one."""
    s = (run or {}).get("summary") or {}
    for v in (s.get("as_of"), ((run or {}).get("settings") or {}).get("as_of"), (s.get("versions") or {}).get("as_of")):
        if v and DATE_RE.fullmatch(str(v)[:10]):
            return str(v)[:10]
    return ""


def page_rows(rows: list[dict]) -> list[dict]:
    """Team B's OVERLAY_COLUMNS rows projected onto PAGE_COLUMNS (model, delta and overlaid kept apart)."""
    return [{k: r.get(k, "") for k in PAGE_COLUMNS} for r in rows]


def overlay_page(run: dict, root, as_of, enabled: bool = False, audience: str = AUDIENCE) -> dict:
    """The INTERNAL page model. Off (default): {"enabled": False, "rows": []} and nothing is read. On: Team B's
    build_overlay rows, assert_internal checked, projected onto PAGE_COLUMNS. The run dict is never modified."""
    ov = _ov()
    ov.assert_internal([], audience)                   # a client audience is refused before anything is read
    run_id, data_hash = _stamps(run)
    base = {"schema": SCHEMA, "page": PAGE_ID, "row_id": OVERLAY_ROW_ID, "audience": AUDIENCE, "internal": True,
            "banner": BANNER, "columns": list(PAGE_COLUMNS), "run_id": run_id, "data_hash": data_hash}
    if enabled is not True:
        return {**base, "enabled": False, "as_of": "", "rows": [], "entries": [], "verify": None, "info": ov.OFF_INFO}
    b = ov.build_overlay(run, root, as_of, enabled=True)
    ov.assert_internal(b["rows"], audience)
    v = b["verify"] or {}
    return {**base, "enabled": True, "as_of": str(as_of), "label": b.get("label", ov.LABEL), "info": b["info"],
            "rows": page_rows(b["rows"]), "entries": b["entries"],
            "verify": {"ok": bool(v.get("ok")), "rows": v.get("rows", 0), "errors": list(v.get("errors") or [])[:5]}}


def _clean_error(msg: str) -> str:
    return _ABS_PATH_RE.sub("<path>", str(msg))[:400]


def api_overlay(data_dir, run: dict, settings, qs: dict) -> tuple[int, dict]:
    """GET /api/overlay (token + Origin guard in gui.py): read only, INTERNAL. ?as_of=YYYY-MM-DD (default: the run's
    as-of). A client audience (?client=1 or ?audience other than internal) is refused with 403. No absolute path in
    any answer."""
    def q(k):
        return str((qs.get(k) or [""])[0]).strip()
    if q("client") not in ("", "0") or q("audience") not in ("", AUDIENCE):
        return 403, {"error": "the analyst overlay is INTERNAL only; never a client view"}
    if not switch_on(settings):
        return 200, overlay_page(run, None, "", enabled=False)
    as_of = q("as_of") or run_as_of(run)
    if not DATE_RE.fullmatch(as_of):
        return 400, {"error": "as_of must be YYYY-MM-DD (the run records none)"}
    ov = _ov()
    try:
        return 200, overlay_page(run, root_for(data_dir), as_of, enabled=True)
    except ov.OverlayError as e:
        return 409, {"error": "overlay unavailable: " + _clean_error(e), "enabled": True, "rows": []}


# ---------------------------------------------------------------- text rendering (CLI)
def _fmt(v) -> str:
    return f"{v:.4f}" if isinstance(v, float) else str(v)


def render_rows(page: dict) -> str:
    lines = [BANNER, f"run {page.get('run_id') or '-'} · data {page.get('data_hash') or '-'} · as of {page.get('as_of') or '-'}"]
    if not page.get("enabled"):
        return "\n".join(lines + [page.get("info", "")])
    if not page["rows"]:
        return "\n".join(lines + ["No active overlay entry for this run and date."])
    cols = ("country", "row", "pillar", "model_value", "overlay_delta", "overlaid_value", "entry_id", "author",
            "approver", "self_approved", "exc_id", "expires", "reason")
    lines.append(" | ".join(cols))
    lines += [" | ".join(_fmt(r.get(c, "")) for c in cols) for r in page["rows"]]
    return "\n".join(lines)


def render_entries(entries: list[dict]) -> str:
    if not entries:
        return f"{BANNER}\nNo overlay entries."
    cols = ("entry_id", "country", "pillar", "notches", "status", "author", "approver", "self_approved", "exc_id",
            "entered_on", "expires", "reason")
    return "\n".join([BANNER, " | ".join(cols)] + [" | ".join(_fmt(e.get(c, "")) for c in cols) for e in entries])


# ---------------------------------------------------------------- CLI: econquest overlay ...
def _settings(data_dir):
    from ..config import Settings
    try:
        return Settings.load(Path(data_dir) / "assumptions.json")
    except Exception:                                  # noqa: BLE001 - no settings means the switch is off
        return None


def _enabled(args) -> bool:
    return bool(getattr(args, "enable", False)) or switch_on(_settings(args.data))


def _need_on(args) -> None:
    if not _enabled(args):
        raise SystemExit(f"overlay {args.ov_cmd}: {_ov().OFF_INFO}. Pass --enable to act on the overlay ledger "
                         "anyway (recorded in the action log), or switch research.analyst_overlay.enabled on through "
                         "econquest change (Tier 1 card B-0138).")


def _approve(args, ov, root) -> dict:
    from ..ops.identity import IdentityError, Signoff
    entry = next((e for e in ov.overlay_entries(root, args.as_of, enabled=True) if e["entry_id"] == args.entry_id), None)
    if entry is None:
        raise ov.OverlayError(f"{args.entry_id} is not in the overlay ledger")
    self_ok = ov.same_person(args.approver, entry["author"])
    try:                                               # every named-user check runs before anything is written
        so = Signoff(Path(args.data), "overlay", entry["author"], approver=args.approver,
                     approver_id=getattr(args, "approver_id", None), self_approved=self_ok, exc_id=args.exc)
    except IdentityError as e:
        raise ov.OverlayError(f"named users: {e}") from None
    approver = so.approver if (so.active and not self_ok) else args.approver
    row = ov.approve_entry(root, args.as_of, approver, args.entry_id, exc_id=args.exc, note=args.note or "",
                           enabled=True)
    try:
        so.record({"overlay_entry": args.entry_id, "as_of": args.as_of, "row_hash": row["row_hash"]})
    except IdentityError as e:
        raise ov.OverlayError(f"{args.entry_id} approved (row {row['seq']}) but the sign-off was not recorded: {e}") from None
    return row


def cmd_overlay(args) -> None:
    ov = _ov()
    root = root_for(args.data)
    try:
        if args.ov_cmd == "verify":
            v = ov.verify(root, expect_head=args.expect_head)
            print(json.dumps({"ok": v["ok"], "rows": v["rows"], "head": v["head"], "errors": v["errors"]}, indent=1))
            if not v["ok"]:
                raise SystemExit(1)
            return
        _need_on(args)
        if args.ov_cmd == "add":
            row = ov.add_entry(root, args.as_of, args.author, args.country, args.pillar, args.notches, args.reason,
                               args.expires, enabled=True)
            print(f"{row['entry_id']} added (pending, seq {row['seq']}); a second person approves it with "
                  f"`econquest overlay approve {row['entry_id']} --as-of D --approver NAME`")
        elif args.ov_cmd == "approve":
            row = _approve(args, ov, root)
            d = row["data"]
            print(f"{row['entry_id']} approved by {d['approver']} (seq {row['seq']}"
                  + (f", self-approved under {d['exc_id']}" if d.get("self_approved") else "") + ")")
        elif args.ov_cmd == "withdraw":
            row = ov.withdraw_entry(root, args.as_of, args.actor, args.entry_id, args.reason, enabled=True)
            print(f"{row['entry_id']} withdrawn (seq {row['seq']})")
        elif args.ov_cmd == "list":
            if args.rows:
                p = Path(args.out) / "run_latest.json"
                try:
                    run = json.loads(p.read_text(encoding="utf-8"))
                except (OSError, json.JSONDecodeError):
                    raise SystemExit("overlay list --rows: no readable run_latest.json in --out; run `econquest run` first") from None
                page = overlay_page(run, root, args.as_of, enabled=True)
                print(json.dumps(page, indent=1, default=str) if args.json else render_rows(page))
            else:
                entries = ov.overlay_entries(root, args.as_of, enabled=True)
                print(json.dumps({"banner": BANNER, "audience": AUDIENCE, "entries": entries}, indent=1)
                      if args.json else render_entries(entries))
    except ov.OverlayError as e:
        raise SystemExit(f"overlay {args.ov_cmd}: {e}") from None


OVERLAY_HELP = ("INTERNAL analyst-judgement overlay (EQ-B-0138): add, approve (four-eyes), withdraw, list and verify "
                "entries in docs/validation/overlay-log.jsonl; shown beside the model output, never in its place, never "
                "in a client product. Off by default: add, approve, withdraw and list pass enabled=True to Team B's "
                "functions only with --enable or the settings switch research.analyst_overlay.enabled; verify only reads")


def register(sub) -> None:
    from ..cli import _as_of_arg
    ov = _ov()
    p = sub.add_parser("overlay", description=OVERLAY_HELP, help=OVERLAY_HELP)
    s = p.add_subparsers(dest="ov_cmd", required=True)

    def common(x, enable=True):
        x.add_argument("--as-of", required=True, type=_as_of_arg, help="event / view date YYYY-MM-DD (no wall clock)")
        if enable:
            x.add_argument("--enable", action="store_true", help="pass enabled=True to the overlay functions although "
                           "the settings switch is off (recorded in the action log)")
    a = s.add_parser("add", help="log one pending entry (notches -2..+2, 2.5 pillar points each; expires within 92 days)")
    common(a)
    a.add_argument("--author", required=True); a.add_argument("--country", required=True)
    a.add_argument("--pillar", required=True, type=int, choices=range(1, 8), metavar="1-7")
    a.add_argument("--notches", required=True, type=int, choices=list(ov.NOTCHES), metavar="{-2,-1,1,2}")
    a.add_argument("--reason", required=True, help=f"what the model misses and why (at least {ov.MIN_REASON} characters)")
    a.add_argument("--expires", required=True, type=_as_of_arg, help="YYYY-MM-DD, after --as-of and at most 92 days later")
    ap = s.add_parser("approve", help="four-eyes approval by someone other than the author; --exc EXC-nnn only for a "
                                      "self-approval under an issues-log row naming `overlay approve`")
    common(ap)
    ap.add_argument("entry_id", metavar="OVL-nnnn"); ap.add_argument("--approver", required=True)
    ap.add_argument("--as", dest="approver_id", metavar="USER_ID", help="sign as this data/users.json user (scope "
                    "\"overlay\"); required once four-eyes is enforced")
    ap.add_argument("--exc", default=None, help="EXC-nnn for the single-operator self-approval path")
    ap.add_argument("--note", default="")
    w = s.add_parser("withdraw", help="end a pending or active entry early (actor and reason logged)")
    common(w)
    w.add_argument("entry_id", metavar="OVL-nnnn"); w.add_argument("--actor", required=True)
    w.add_argument("--reason", required=True)
    li = s.add_parser("list", help="entries and their status, or --rows: page rows (model_value, overlay_delta, overlaid_value "
                                   "apart) against --out/run_latest.json, read only")
    common(li)
    li.add_argument("--rows", action="store_true"); li.add_argument("--json", action="store_true")
    v = s.add_parser("verify", help="hash chain and head file of the overlay ledger (read only); exit 1 on a break")
    common(v, enable=False)
    v.add_argument("--expect-head", default=None, metavar="SEQ:HASH", help="a head recorded outside the folder")
    p.set_defaults(fn=cmd_overlay)


def action_label(args) -> str | None:
    """Action-log name for cli.action_label: the ledger writes only."""
    return f"overlay {args.ov_cmd}" if getattr(args, "ov_cmd", None) in WRITE_CMDS else None
