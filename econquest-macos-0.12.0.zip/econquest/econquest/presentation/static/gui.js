// econquest GUI script, served as /static/gui.js so the CSP can be script-src 'self' (EQ-C-0131, SEC-C-020).
// Section headers below are scanned by tests (tests/_gui_source.py): keep them exactly as they are.
const $ = s => document.querySelector(s);
const fmt = {
  pct: v => v == null || isNaN(v) ? "" : (v * 100).toFixed(2) + "%",
  pct1: v => v == null || isNaN(v) ? "" : (v * 100).toFixed(1) + "%",
  n: (v, d = 2) => v == null || isNaN(v) ? "" : Number(v).toFixed(d),
  sig: v => { if (v == null || isNaN(v)) return ""; const a = Math.abs(v); return a >= 1e6 ? Number(v).toExponential(2) : a >= 100 ? Number(v).toFixed(0) : a >= 1 ? Number(v).toFixed(2) : a >= 0.01 ? Number(v).toFixed(3) : Number(v).toExponential(2); },
};
const regimeColor = { Calm: "#1e8449", Stressed: "#d68910", Crisis: "#c0392b" };
const palette = ["#2b5fa8","#c0392b","#1e8449","#d68910","#7d3c98","#17a589","#a04000","#5d6d7e","#2e86c1","#af7ac5","#d35400","#148f77","#884ea0","#1f618d","#b03a2e","#239b56","#9a7d0a","#6c3483"];
const layoutBase = { margin: { l: 55, r: 20, t: 10, b: 45 }, paper_bgcolor: "rgba(0,0,0,0)", plot_bgcolor: "rgba(0,0,0,0)", font: { family: "inherit", size: 12, color: "#1d2733" }, hovermode: "closest", legend: { orientation: "h", y: -0.18 } };
const cfg = { displaylogo: false, responsive: true, modeBarButtonsToRemove: ["lasso2d", "select2d"] };
const plot = (id, traces, layout) => Plotly.newPlot(id, traces, Object.assign({}, layoutBase, layout || {}), cfg);
const empty = (id, msg) => { $("#" + id).innerHTML = `<div class="empty">${msg}</div>`; };
const esc = v => String(v ?? "").replace(/[&<>"']/g, ch => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[ch]);
const TOKEN = document.querySelector('meta[name="econquest-token"]').content;
// Every write carries the session token and a JSON content type; the server refuses anything else (api.py _guard).
const post = (url, body) => fetch(url, { method: "POST", headers: { "Content-Type": "application/json", "X-EconQuest-Token": TOKEN }, body: JSON.stringify(body || {}) });
async function getJSON(url) { const r = await fetch(url); if (!r.ok) throw new Error((await r.json()).error || r.statusText); return r.json(); }
async function tryJSON(url) { try { return await getJSON(url); } catch (e) { return null; } }

// ---------- generic sortable table ----------
function table(id, rows, opts = {}) {
  const el = typeof id === "string" ? $("#" + id) : id;
  if (!rows || !rows.length) { el.innerHTML = `<div class="empty">${opts.emptyMsg || "No data yet."}</div>`; return; }
  const cols = opts.cols || Object.keys(rows[0]).filter(c => !(opts.hide || []).includes(c));
  const isNum = c => rows.some(r => typeof r[c] === "number");
  let sortCol = opts.sort || null, asc = opts.asc || false;
  const render = () => {
    let data = rows.slice();
    if (sortCol) data.sort((a, b) => { const x = a[sortCol], y = b[sortCol]; if (x == null) return 1; if (y == null) return -1; return (x > y ? 1 : x < y ? -1 : 0) * (asc ? 1 : -1); });
    if (opts.limit) data = data.slice(0, opts.limit);
    const heat = opts.heat || {};
    const head = cols.map(c => `<th class="${isNum(c) ? "num" : ""} ${c === sortCol ? "sorted" + (asc ? " asc" : "") : ""}" data-c="${esc(c)}">${esc((opts.labels || {})[c] || c.replace(/_/g, " "))}</th>`).join("");
    const body = data.map(r => "<tr>" + cols.map(c => {
      let v = r[c]; const f = (opts.fmt || {})[c];
      let txt = esc(f ? f(v) : typeof v === "number" ? fmt.sig(v) : typeof v === "boolean" ? (v ? "yes" : "") : (v == null ? "" : String(v)));
      let style = "";
      if (heat[c] && typeof v === "number") { const [lo, hi] = heat[c]; const t = Math.max(0, Math.min(1, (v - lo) / (hi - lo))); style = ` heat-${Math.round(t * 11)}`; }
      if (c === "regime" && regimeColor[v]) txt = `<span class="heat regime-${esc(v)}">${esc(v)}</span>`;
      return `<td class="${typeof v === "number" ? "num" : ""}${style}">${txt}</td>`; }).join("") + "</tr>").join("");
    el.innerHTML = `<table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>`;
    el.querySelectorAll("th").forEach(th => th.onclick = () => { const c = th.dataset.c; if (sortCol === c) asc = !asc; else { sortCol = c; asc = !isNum(c); } render(); });
  };
  render();
}

// ---------- state ----------
let RUN = null, STATUS = null, GARCH = {}, ECON = {};
const loaded = {};

async function loadRun() {
  RUN = await getJSON("/api/run/latest");
  const s = RUN.summary, m = s.metrics;
  const ver = s.versions || {};
  const asOf = s.as_of ?? RUN.settings?.as_of ?? ver.as_of ?? null;  // never a browser date: missing means not recorded
  $("#chip-run").innerHTML = `run <b>${esc(s.run_id)}</b> · as of <b>${esc(asOf ?? "not recorded")}</b> · ${m.paths.toLocaleString()} paths${ver.code_hash ? ` · code ${esc(ver.code_hash.slice(0, 8))} · data ${esc(ver.data_hash.slice(0, 8))}` : ""}${ver.run_hash ? ` · run hash ${esc(ver.run_hash.slice(0, 8))}` : ""}`;
  $("#chip-regime").className = "chip " + (s.global_regime === "Calm" ? "ok" : s.global_regime === "Crisis" ? "bad" : "warn");
  $("#chip-regime").innerHTML = `global regime <b>${s.global_regime}</b>`;
}
async function loadStatus() {
  STATUS = await getJSON("/api/status");
  $("#chip-prices").className = "chip " + (STATUS.prices.exists ? "ok" : "warn");
  $("#chip-prices").innerHTML = `market history <b>${STATUS.prices.exists ? STATUS.prices.modified : "missing"}</b>`;
  $("#chip-live").className = "chip " + (STATUS.live.files.length ? "ok" : "warn");
  $("#chip-live").innerHTML = `live feeds <b>${STATUS.live.files.length ? STATUS.live.files.length + " files" : "not fetched"}</b>`;
  $("#foot").textContent = `data: ${STATUS.data_dir}`;
}

// ---------- home (EQ-C-0132): /api/morning (ops.morning.collect, the same function as `econquest morning`), read only,
// every string through esc() and every number through fmt.*; note buttons carry only a note id, looked up by /api/notes.
const HM_LIGHTS = { green: "PASS", amber: "WARN", red: "BREACH" };
const hmLight = l => { const k = Object.prototype.hasOwnProperty.call(HM_LIGHTS, l) ? l : "none"; return `<span class="hm-light ${k}">${esc(HM_LIGHTS[k] || "n/a")}</span>`; };
const hmSigned = (v, d = 2) => v == null || isNaN(v) ? "n/a" : (v >= 0 ? "+" : "") + fmt.n(v, d);
function homeHTML(d) {
  if (!d || d.error || !d.run) return { status: `<div class="empty">Morning view unavailable: ${esc((d && d.error) || "the server did not answer /api/morning")}.</div>`, limits: "", changes: "", alerts: "", notes: "", items: "" };
  const r = d.run, p = d.previous;
  const status = `<p><b>${d.status === "ok" ? "Current" : d.status === "stale" ? "[STALE]" : "[NO RUN]"}</b> run <b>${esc(r.run_id || "none")}</b> as of <b>${esc(r.as_of || "n/a")}</b> (target ${esc(d.as_of)}), created ${esc(r.created_at || "n/a")} · checked ${esc(d.generated_utc)}</p>` +
    ((r.reasons || []).length ? `<p class="note-warn">${esc(r.reasons.join("; "))}. Run <code>econquest morning</code> to refresh it.</p>` : "") +
    (r.code_note ? `<p class="note">${esc(r.code_note)}</p>` : "") + `<p class="note">${esc(d.message)}</p>`;
  const lim = d.limits || {};
  const limits = (lim.rows || []).length ? `<table><thead><tr><th></th><th>Measure</th><th class="num">Value</th><th class="num">Limit</th><th class="num">Used</th><th class="num">Warn at</th><th>95% MC band</th></tr></thead><tbody>` +
    lim.rows.map(x => `<tr><td>${hmLight(x.light)}</td><td>${esc(x.label)}</td><td class="num">${fmt.n(x.value)}</td><td class="num">${fmt.n(x.limit, 1)}</td><td class="num">${fmt.pct1(x.utilisation)}</td><td class="num">${fmt.n(x.warning_mm, 1)}</td><td class="hm-wrap">${x.band_lo == null ? "" : fmt.n(x.band_lo) + "-" + fmt.n(x.band_hi)}${x.within_mc_error ? ` <b>!</b> ${esc(x.mc_note)}` : ""}</td></tr>`).join("") +
    `</tbody></table><p class="note">Warning band from ${fmt.pct1(lim.warning_level)} of each limit (data/limits.json).</p>` : `<div class="empty">No limits to show (no run, or data/limits.json missing).</div>`;
  const ch = d.changes || {};
  let changes;
  if (!p) changes = `<div class="empty">No previous base run to compare with.</div>`;
  else {
    const g = ch.global_regime || {}, dd = ch.data || {}, gh = ch.gate_holds || {};
    const moved = [...(dd.changed || []), ...(dd.added || []).map(x => "+" + x), ...(dd.removed || []).map(x => "-" + x)];
    changes = `<p class="note">Since ${esc(p.run_id)} (as of ${esc(p.as_of)}).</p><table><tbody>` +
      (ch.metrics || []).map(m => `<tr><td>${esc(m.label)}</td><td class="num">${fmt.n(m.current)}</td><td class="num">${hmSigned(m.delta)}</td><td class="num">${m.delta_pct == null ? "" : hmSigned(m.delta_pct, 1) + "%"}</td></tr>`).join("") + `</tbody></table>` +
      `<p>Global regime: <b>${esc(g.previous)}</b> → <b>${esc(g.current)}</b></p>` +
      `<p><b>PD movers</b></p>` + ((ch.pd_movers || []).length ? `<ul>${ch.pd_movers.map(x => `<li>${esc(x.country)}: ${fmt.pct(x.pd_previous)} → ${fmt.pct(x.pd_current)} (${hmSigned(x.delta_pp)} pp)</li>`).join("")}</ul>` : `<p class="note">none</p>`) +
      `<p><b>Regime changes</b></p>` + ((ch.regime_changes || []).length ? `<ul>${ch.regime_changes.map(x => `<li>${esc(x.message)}</li>`).join("")}</ul>` : `<p class="note">none</p>`) +
      `<p><b>Data changes</b> (data_files diff)</p><p class="note">${moved.length ? esc(moved.join(", ")) : dd.compared ? "none" : "not recorded on one of the runs"}</p>` +
      ((dd.on_disk_since_run || []).length ? `<p class="note-warn">Changed on disk since this run: ${esc(dd.on_disk_since_run.join(", "))}</p>` : "") +
      `<p><b>Gate holds</b>: ${esc(gh.held ?? "n/a")} held, ${gh.new_count == null ? "new unknown" : esc(gh.new_count) + " new, " + esc(gh.cleared_count) + " cleared"} <span class="note">(${esc(gh.note)})</span></p>` +
      ((gh.new || []).length ? `<ul>${gh.new.map(c => `<li>${esc(c.table)} ${esc(c.key)} ${esc(c.country)}: ${esc(c.reason)}</li>`).join("")}</ul>` : "");
  }
  const al = d.alerts || {}, ac = al.counts || {};
  const alerts = `<p><b>${esc(ac.critical ?? 0)}</b> critical, <b>${esc(ac.warning ?? 0)}</b> warning, <b>${esc(ac.info ?? 0)}</b> info${al.quality_holds ? ` (${esc(al.quality_holds)} quality holds, under gate holds)` : ""}</p>` +
    ((al.items || []).length ? `<ul>${al.items.map(a => `<li><b>[${esc(String(a.severity).toUpperCase())}]</b> ${esc(a.message)}</li>`).join("")}</ul>` : `<p class="note">No other alert.</p>`) +
    (al.more ? `<p class="note">${esc(al.more)} more: econquest alerts</p>` : "");
  const n = d.notes || {};
  const nl = [n.brief, ...(n.items || [])].filter(Boolean);
  const notesH = `<p class="note">${esc(n.message)}</p>` + (nl.length ? `<ul>${nl.map(x => `<li><button type="button" class="secondary hm-note" data-id="${esc(x.id)}">${esc(x.title)}</button> <span class="note">${esc(x.kind_label)} · ${esc(x.state || "not registered")} · ${esc(x.path || x.file)}</span></li>`).join("")}</ul>` : "");
  const oi = d.open_items || {};
  const items = `<p class="note">${esc(oi.message)} · full list on the Open items tab</p>` + ((oi.items || []).length ? `<ul>${oi.items.map(it => `<li><b>[${esc(String(it.status).toUpperCase())}${it.parked ? " · parked until the MVP" : ""}]</b> ${esc(it.title)}: ${esc(it.summary)}${it.command ? ` <code>${esc(it.command)}</code>` : ""}</li>`).join("")}</ul>` : `<p class="note">Nothing open.</p>`);
  return { status, limits, changes, alerts, notes: notesH, items };
}
async function home() {
  let d;
  try { d = await getAuthJSON("/api/morning"); } catch (e) { d = { error: e.message }; }
  const h = homeHTML(d);
  $("#h-status").innerHTML = h.status; $("#h-limits").innerHTML = h.limits; $("#h-changes").innerHTML = h.changes;
  $("#h-alerts").innerHTML = h.alerts; $("#h-notes").innerHTML = h.notes; $("#h-items").innerHTML = h.items;
  h.events = calendarHomeHTML(d && d.events);                   // EQ-C-0155: defined in the event calendar section
  $("#h-events").innerHTML = h.events;
  assistantHome(d);                                             // EQ-C-0172: defined in the assistant section
}
document.addEventListener("click", async ev => {
  const b = ev.target.closest ? ev.target.closest(".hm-note") : null; if (!b) return;
  const id = b.dataset.id; await show("notes"); showNote(id);
});

// ---------- overview ----------
function kpis(el, m) {
  const items = [["var99_mm", "VaR 99% ($mm)"], ["es99_mm", "ES 99% ($mm)"], ["es975_frtb_mm", "ES 97.5% FRTB ($mm)"], ["lvar99_mm", "Liquidity-adjusted VaR 99%"], ["expected_loss_mm", "Expected loss ($mm)"], ["gross_notional_mm", "Gross notional ($mm)"], ["p_loss_above_10pct_gross", "P(loss > 10% of gross)"]];
  el.innerHTML = items.map(([k, l]) => `<div class="kpi"><div class="v">${k.startsWith("p_") ? fmt.pct1(m[k]) : fmt.n(m[k], 1)}</div><div class="l">${l}</div></div>`).join("");
}
function histogram(id, run) {
  const h = run.loss_histogram, m = run.summary.metrics; const x = h.edges.slice(0, -1).map((e, i) => (e + h.edges[i + 1]) / 2);
  plot(id, [{ type: "bar", x, y: h.counts, marker: { color: x.map(v => v > m.var99_mm ? "#c0392b" : "#4a7ab5") }, hovertemplate: "loss %{x:.1f} $mm<br>%{y} paths<extra></extra>" }],
    { xaxis: { title: { text: "Portfolio loss, $mm (negative = gain)" } }, yaxis: { title: { text: "paths" } }, bargap: 0.05, shapes: [
      { type: "line", x0: m.var99_mm, x1: m.var99_mm, y0: 0, y1: 1, yref: "paper", line: { color: "#c0392b", dash: "dash" } },
      { type: "line", x0: m.es99_mm, x1: m.es99_mm, y0: 0, y1: 1, yref: "paper", line: { color: "#7d3c98", dash: "dash" } }],
      annotations: [{ x: m.var99_mm, y: 1, yref: "paper", text: `VaR99 ${m.var99_mm.toFixed(1)}`, showarrow: false, xanchor: "left", font: { color: "#c0392b" } },
                    { x: m.es99_mm, y: 0.92, yref: "paper", text: `ES99 ${m.es99_mm.toFixed(1)}`, showarrow: false, xanchor: "left", font: { color: "#7d3c98" } }] });
}
function overview() {
  kpis($("#kpis"), RUN.summary.metrics);
  histogram("p-hist", RUN);
  const c = RUN.country.slice().sort((a, b) => a.pd_default - b.pd_default);
  plot("p-pd", [{ type: "bar", orientation: "h", y: c.map(r => r.country), x: c.map(r => r.pd_default * 100), marker: { color: c.map(r => regimeColor[r.regime] || "#5d6d7e") },
    text: c.map(r => r.rating), textposition: "outside", hovertemplate: "%{y}: %{x:.2f}%<br>rating %{text}<extra></extra>" }], { xaxis: { title: { text: "12-month PD, %" } }, margin: { l: 95, r: 40, t: 10, b: 45 } });
  const bc = RUN.by_country.slice().sort((a, b) => b.tail_contribution_99_mm - a.tail_contribution_99_mm);
  plot("p-tail", [{ type: "bar", x: bc.map(r => r.country), y: bc.map(r => r.tail_contribution_99_mm), marker: { color: "#2b5fa8" }, name: "tail contribution" },
                  { type: "bar", x: bc.map(r => r.country), y: bc.map(r => r.expected_loss_mm), marker: { color: "#d68910" }, name: "expected loss" }], { barmode: "group", yaxis: { title: { text: "$mm" } }, xaxis: { tickangle: -40 } });
  getJSON("/api/table/latent_correlation").then(rows => {
    const names = rows.map(r => r.index), z = rows.map(r => names.map(n => r[n]));
    plot("p-corr", [{ type: "heatmap", z, x: names, y: names, zmin: 0, zmax: 1, colorscale: "YlOrRd", hovertemplate: "%{y} / %{x}: %{z:.2f}<extra></extra>" }], { margin: { l: 95, r: 10, t: 10, b: 95 }, xaxis: { tickangle: -45 }, yaxis: { autorange: "reversed" } });
  }).catch(() => empty("p-corr", "Run the model to produce the correlation matrix."));
  const notional = Object.fromEntries(RUN.by_country.map(r => [r.country, r.notional_mm]));
  const regs = [...new Set(RUN.country.map(r => r.regime))];
  plot("p-scatter", regs.map(g => { const rs = RUN.country.filter(r => r.regime === g); return { type: "scatter", mode: "markers+text", name: g, x: rs.map(r => r.composite), y: rs.map(r => r.pd_default * 100), text: rs.map(r => r.country), textposition: "top center", textfont: { size: 10 },
    marker: { size: rs.map(r => 8 + Math.sqrt(notional[r.country] || 1) * 3), color: regimeColor[g], opacity: 0.8 },
    hovertemplate: rs.map(r => `${r.country}<br>composite ${r.composite.toFixed(1)} (grade ${r.grade})<br>PD ${(r.pd_default * 100).toFixed(2)}%<br>debt/GDP ${r.debt_gdp}<br>reserves ${fmt.n(r.reserves_months_imports, 1)} months of imports<br>notional $${notional[r.country] || 0}mm<extra></extra>`) }; }),
    { xaxis: { title: { text: "Composite risk score (0 = safest)" } }, yaxis: { title: { text: "12-month PD, %" } } });
}

// ---------- countries ----------
function countries() {
  const sel = $("#c-select"); if (!sel.options.length) { RUN.country.forEach(r => sel.add(new Option(r.country))); sel.onchange = countryDetail; }
  table("t-countries", RUN.country, { cols: ["country", "region", "rating", "composite", "grade", "regime", "pd_hazard_l1", "pd_rating", "pd_market", "pd_post", "pm_default", "pd_default", "pd_tc", "pd_ex", "pd_pv", "pd_sa", "DD", "debt_gdp", "reserves_months_imports", "pitf_instability"],
    fmt: { pd_hazard_l1: fmt.pct, pd_rating: fmt.pct, pd_market: fmt.pct, pd_post: fmt.pct, pm_default: fmt.pct, pd_default: fmt.pct, pd_tc: fmt.pct, pd_ex: fmt.pct, pd_pv: fmt.pct, pd_sa: fmt.pct, composite: v => fmt.n(v, 1), DD: v => fmt.n(v, 1), reserves_months_imports: v => fmt.n(v, 1) },
    heat: { pd_default: [0, 0.4], pd_hazard_l1: [0, 0.3] }, sort: "pd_default",
    labels: { pd_hazard_l1: "PD hazard", pd_rating: "PD rating", pd_market: "PD market", pd_post: "PD posterior", pm_default: "pred. market", pd_default: "PD final", pd_tc: "transfer/convert.", pd_ex: "expropriation", pd_pv: "political violence", pd_sa: "sanctions", DD: "distance to default", debt_gdp: "debt/GDP", reserves_months_imports: "reserves (months)", pitf_instability: "PITF instability" } });
  countryDetail();
}
function countryDetail() {
  const r = RUN.country.find(x => x.country === $("#c-select").value) || RUN.country[0];
  $("#c-meta").innerHTML = `${esc(r.region)} · rating <b>${esc(r.rating)}</b> · composite <b>${r.composite.toFixed(1)}</b> · <span class="heat regime-${esc(regimeColor[r.regime] ? r.regime : "none")}">${esc(r.regime)}</span>`;
  const comp = [["Hazard model", r.pd_hazard_l1], ["Rating prior", r.pd_rating], ["Market (CDS/FX/stress)", r.pd_market], ["Bayesian posterior", r.pd_post], ["Prediction market", r.pm_default], ["Final PD", r.pd_default], ["Merton PD", r.pd_merton]];
  plot("p-ccomp", [{ type: "bar", x: comp.map(c => c[0]), y: comp.map(c => (c[1] || 0) * 100), marker: { color: comp.map((c, i) => i === 5 ? "#c0392b" : "#2b5fa8") }, hovertemplate: "%{x}: %{y:.2f}%<extra></extra>" }], { yaxis: { title: { text: "%" } }, xaxis: { tickangle: -25 } });
  const sc = [["Default", r.pd_default], ["Transfer & convertibility", r.pd_tc], ["Expropriation", r.pd_ex], ["Political violence", r.pd_pv], ["Sanctions", r.pd_sa], ["Any peril", r.pd_any]];
  plot("p-cscen", [{ type: "bar", x: sc.map(c => c[0]), y: sc.map(c => (c[1] || 0) * 100), marker: { color: "#7d3c98" }, hovertemplate: "%{x}: %{y:.2f}%<extra></extra>" }], { yaxis: { title: { text: "%" } }, xaxis: { tickangle: -25 } });
}

// ---------- portfolio ----------
function portfolio() {
  const con = RUN.contributions.slice().sort((a, b) => b.tail_contribution_99_mm - a.tail_contribution_99_mm);
  const classes = [...new Set(con.map(c => c.asset_class))];
  plot("p-contrib", [{ type: "bar", orientation: "h", y: con.map(c => `${c.id} ${c.country}`), x: con.map(c => c.tail_contribution_99_mm), marker: { color: con.map(c => palette[classes.indexOf(c.asset_class)]) }, hovertemplate: "%{y}<br>%{x:.2f} $mm<extra></extra>" }], { margin: { l: 150, r: 20, t: 10, b: 45 }, xaxis: { title: { text: "$mm" } }, yaxis: { autorange: "reversed" } });
  plot("p-eltail", classes.map((k, i) => { const rs = con.filter(c => c.asset_class === k); return { type: "scatter", mode: "markers+text", name: k, x: rs.map(c => c.expected_loss_mm), y: rs.map(c => c.tail_contribution_99_mm), text: rs.map(c => c.country), textposition: "top center", textfont: { size: 10 }, marker: { size: rs.map(c => 6 + Math.sqrt(c.notional_mm) * 2.5), color: palette[i], opacity: 0.8 } }; }),
    { xaxis: { title: { text: "Expected loss, $mm (negative = carry)" } }, yaxis: { title: { text: "Tail contribution to ES99, $mm" } } });
  table("t-positions", RUN.positions, { hide: ["sign", "thrA", "thrB", "kindA", "kindB", "lgd_mult"], fmt: { pd_default: fmt.pct, pd_tc: fmt.pct, pd_ex: fmt.pct, pd_pv: fmt.pct, pA: fmt.pct, pB: fmt.pct }, sort: "notional_mm" });
  table("t-contrib", RUN.contributions, { fmt: { share_of_es99: fmt.pct1 }, sort: "tail_contribution_99_mm", heat: { tail_contribution_99_mm: [0, 20] } });
}

// ---------- stress & backtests ----------
async function stress() {
  evidenceClock();
  const st = await tryJSON("/api/json/stress"), bt = await tryJSON("/api/json/backtest");
  if (!st) { empty("p-stress", "No stress results yet. Run the model with stress on the Data & jobs tab."); $("#t-stress").innerHTML = ""; }
  else {
    const keys = Object.keys(st), metrics = [["var99_mm", "VaR 99%"], ["es99_mm", "ES 99%"], ["lvar99_mm", "L-VaR 99%"], ["liquidity_cost99_mm", "Liquidity cost 99%"]];
    const base = st[keys[0]].comparison;
    const traces = [{ type: "bar", name: "Base", x: metrics.map(m => m[1]), y: metrics.map(m => base[m[0]].base), marker: { color: "#5d6d7e" } }];
    keys.forEach((k, i) => traces.push({ type: "bar", name: `${k}: ${st[k].name}`, x: metrics.map(m => m[1]), y: metrics.map(m => st[k].comparison[m[0]].stress), marker: { color: palette[i + 1] } }));
    plot("p-stress", traces, { barmode: "group", yaxis: { title: { text: "$mm" } } });
    table("t-stress", keys.map(k => { const c = st[k].comparison; return { scenario: `${k}: ${st[k].name}`, var99_mm: c.var99_mm.stress, es99_mm: c.es99_mm.stress, es99_change: c.es99_mm.change_pct / 100, lvar99_mm: c.lvar99_mm.stress, liquidity_cost_change: c.liquidity_cost99_mm.change_pct / 100, share_to_crisis: c.share_to_crisis, mean_pd_change_pp: c.mean_pd_default_change_pp }; }),
      { fmt: { es99_change: fmt.pct1, liquidity_cost_change: fmt.pct1, share_to_crisis: fmt.pct1 } });
  }
  const rec = await tryJSON("/api/data/forecast_record");
  if (!rec || !rec.length) { empty("p-record", "No forecast record yet. Use Record today or Backfill record on the Data & jobs tab."); $("#t-record").innerHTML = ""; }
  else {
    const r = rec.filter(x => x.var != null && x.loss != null), x = r.map(d => d.date.slice(0, 10));
    const exc = r.filter(d => d.loss > d.var);
    plot("p-record", [
      { type: "bar", name: "realised loss", x, y: r.map(d => d.loss), marker: { color: r.map(d => d.loss > d.var ? "#c0392b" : "#8aa4c2") } },
      { type: "scatter", mode: "lines", name: "VaR99 1d", x, y: r.map(d => d.var), line: { color: "#c0392b", width: 1.5 } },
      { type: "scatter", mode: "lines", name: "ES99 1d", x, y: r.map(d => d.es), line: { color: "#7d3c98", width: 1.2, dash: "dot" } }],
      { yaxis: { title: { text: "$mm (loss positive)" } }, bargap: 0.2 });
    const last = rec[rec.length - 1];
    $("#t-record").innerHTML = `<p class="note">${rec.length} rows, ${r.length} with a forecast, ${exc.length} exceedances (expected ${(r.length * 0.01).toFixed(1)}). Last row ${last.date.slice(0, 10)}: loss ${fmt.n(last.loss, 3)}, next-day VaR99 ${fmt.n(last.var_next, 3)}, 12-month MC VaR99 ${last.var99_12m == null ? "n/a" : fmt.n(last.var99_12m, 1)}; code ${last.code_hash || ""}, data ${last.data_hash || ""}.</p>`;
  }
  if (!bt) { $("#t-backtest").innerHTML = `<div class="empty">No backtest results yet.</div>`; return; }
  const k = bt.kupiec, c = bt.christoffersen, z = bt.acerbi_szekely;
  table("t-backtest", [
    { test: "Kupiec unconditional coverage", statistic: `LR ${k.LR_uc.toFixed(3)} (${k.exceedances} exceedances vs ${k.expected.toFixed(1)} expected)`, p_value: k.p_value, result: k.p_value >= 0.05 ? "pass" : "fail" },
    { test: "Christoffersen independence", statistic: `LR ${c.LR_ind.toFixed(3)}`, p_value: c.p_value_ind, result: c.p_value_ind >= 0.05 ? "pass" : "fail" },
    { test: "Christoffersen conditional coverage", statistic: `LR ${c.LR_cc.toFixed(3)}`, p_value: c.p_value_cc, result: c.p_value_cc >= 0.05 ? "pass" : "fail" },
    { test: "Acerbi-Szekely Z2", statistic: `Z2 ${z.Z2.toFixed(3)} (critical ${z.critical})`, p_value: null, result: z.pass ? "pass" : "fail" },
    { test: "Basel traffic light", statistic: bt.basel_zone, p_value: null, result: bt.verdict }], { fmt: { p_value: v => v == null ? "" : fmt.n(v, 3) } });
}

// ---------- evidence clock (EQ-C-0068): /api/evidence-clock, every string through esc() ----------
const EV_TEXT = { accumulating: "\u25CB Accumulating", testable: "\u2713 Testable", overdue: "! Overdue" };
function evidenceClockHTML(d) {
  if (!d) return { status: `<div class="empty">Evidence clock unavailable (the server did not answer /api/evidence-clock).</div>`, table: "" };
  const col = d.status === "ok" ? "t-ink" : "t-red";
  const status = `<p><b class="${col}">[${esc(d.status === "ok" ? "AS OF " + d.as_of : "UNREADABLE")}]</b> ${esc(d.message)}</p>`;
  const rows = d.rows || [];
  if (!rows.length) return { status, table: `<div class="empty">No evidence rows.</div>` };
  const head = ["evidence", "progress / required", "progress", "first obs", "last obs", "earliest test date", "days to test", "status", "note"];
  const body = rows.map(r => {
    const st = ["accumulating", "testable", "overdue"].includes(r.status) ? r.status : "accumulating";
    const pct = Math.max(0, Math.min(100, Number(r.progress_pct) || 0));
    return `<tr><td><b>${esc(r.evidence)}</b><br><span class="ev-src">${esc(r.source)}</span></td>` +
      `<td class="num">${esc(fmt.n(r.progress, 0))} / ${esc(fmt.n(r.required, 0))} ${esc(r.unit)}</td>` +
      `<td><span class="ev-bar ${st}" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="${esc(fmt.n(pct, 1))}" aria-label="${esc(r.evidence)} progress"><span class="ev-fill" data-w="${esc(fmt.n(pct, 1))}"></span></span>${esc(fmt.n(r.progress_pct, 1))}%</td>` +
      `<td>${esc(r.first_obs)}</td><td>${esc(r.last_obs)}</td><td><b>${esc(r.earliest_test_date)}</b></td>` +
      `<td class="num">${esc(r.days_to_test == null ? "" : fmt.n(r.days_to_test, 0))}</td>` +
      `<td><span class="ev-status ${st}">${esc(EV_TEXT[st] + (st === r.status ? "" : " (" + r.status + ")"))}</span></td>` +
      `<td class="ev-note">${esc(r.note)}</td></tr>`;
  }).join("");
  return { status, table: `<table><thead><tr>${head.map(h => `<th>${esc(h)}</th>`).join("")}</tr></thead><tbody>${body}</tbody></table>` };
}
async function evidenceClock() {
  const h = evidenceClockHTML(await tryJSON("/api/evidence-clock"));
  $("#ev-status").innerHTML = h.status; $("#t-evidence-clock").innerHTML = h.table;
}

// ---------- GARCH ----------
async function vol() {
  if (!GARCH.series) {
    GARCH.series = await tryJSON("/api/table/garch/series"); GARCH.hist = await tryJSON("/api/table/garch/vol_history");
    GARCH.fx = await tryJSON("/api/table/garch/dcc_fx"); GARCH.eq = await tryJSON("/api/table/garch/dcc_eq");
    GARCH.options = await tryJSON("/api/table/garch/options"); GARCH.macro = await tryJSON("/api/table/garch/macro");
  }
  if (!GARCH.series) { ["p-volhist", "p-volbar", "p-dccfx", "p-dcceq"].forEach(id => empty(id, "No GARCH results yet. Run GARCH on the Data & jobs tab (needs data/market_history/prices.csv).")); ["t-garch", "t-options", "t-macro"].forEach(id => table(id, [])); return; }
  const S = GARCH.series;
  const sel = $("#v-select");
  if (!sel.options.length) {
    S.forEach(r => sel.add(new Option(`${r.ticker} (${r.country})`, r.ticker)));
    const pick = kind => { [...sel.options].forEach(o => o.selected = S.find(r => r.ticker === o.value).kind === kind); volHist(); };
    $("#v-fx").onclick = () => pick("FX"); $("#v-eq").onclick = () => pick("Equity"); sel.onchange = volHist; sel.size = Math.min(8, S.length);
    [...sel.options].forEach(o => o.selected = ["USDBRL", "USDJPY", "USDINR", "EEM", "EWZ", "MCHI"].includes(o.value));
    // EQ-B-0077 (HO-20261024-B-C-011): an FX-only prices.csv has no EEM/EWZ/MCHI; top up to six series so the chart stays full
    let nSel = [...sel.options].filter(o => o.selected).length;
    [...sel.options].forEach(o => { if (nSel > 0 && nSel < 6 && !o.selected) { o.selected = true; nSel++; } });
    if (![...sel.options].some(o => o.selected)) [...sel.options].slice(0, 6).forEach(o => o.selected = true);
  }
  volHist();
  const s = S.slice().sort((a, b) => b.cond_vol_pct - a.cond_vol_pct);
  plot("p-volbar", [
    { type: "bar", name: "conditional vol now", x: s.map(r => r.ticker), y: s.map(r => r.cond_vol_pct), marker: { color: "#2b5fa8" } },
    { type: "bar", name: "21-day forecast", x: s.map(r => r.ticker), y: s.map(r => r.fcst_21d_vol_pct), marker: { color: "#7d3c98" } },
    { type: "bar", name: "realised 60-day", x: s.map(r => r.ticker), y: s.map(r => r.realized_60d_vol_pct), marker: { color: "#d68910" } },
    { type: "scatter", mode: "markers", name: "long-run vol", x: s.map(r => r.ticker), y: s.map(r => r.long_run_vol_pct), marker: { color: "#1d2733", symbol: "line-ew-open", size: 14, line: { width: 2 } } }],
    { barmode: "group", yaxis: { title: { text: "annualised %" } }, xaxis: { tickangle: -45 } });
  const heat = (id, rows) => { if (!rows) return empty(id, "No DCC fit (fewer than two series)."); const n = rows.map(r => r.index); plot(id, [{ type: "heatmap", z: rows.map(r => n.map(k => r[k])), x: n, y: n, zmin: -1, zmax: 1, colorscale: "RdBu", reversescale: true, hovertemplate: "%{y} / %{x}: %{z:.2f}<extra></extra>" }], { margin: { l: 80, r: 10, t: 10, b: 80 }, xaxis: { tickangle: -45 }, yaxis: { autorange: "reversed" } }); };
  heat("p-dccfx", GARCH.fx); heat("p-dcceq", GARCH.eq);
  table("t-garch", S, { cols: ["country", "kind", "ticker", "obs", "alpha", "beta", "persistence", "half_life_days", "nu", "long_run_vol_pct", "cond_vol_pct", "fcst_21d_vol_pct", "realized_60d_vol_pct", "vol_ratio", "arch_lm_p_std_resid", "ljung_box_p_sq_std_resid", "var99_1d_pct", "es99_1d_pct", "exposure_mm", "var99_10d_mm", "vol_target_scalar", "scaled_notional_mm", "converged"],
    sort: "var99_10d_mm", heat: { var99_10d_mm: [0, 5], persistence: [0.9, 1] }, labels: { arch_lm_p_std_resid: "ARCH-LM p (std resid)", ljung_box_p_sq_std_resid: "Ljung-Box p (sq resid)", nu: "t df" } });
  table("t-options", GARCH.options, { fmt: { put_diff_pct: v => fmt.n(v, 1) + "%" } });
  table("t-macro", GARCH.macro);
}
function volHist() {
  const picked = [...$("#v-select").selectedOptions].map(o => o.value);
  if (!GARCH.hist) return empty("p-volhist", "Re-run GARCH to produce the volatility history (added in this version).");
  const xk = "date" in GARCH.hist[0] ? "date" : "index"; const x = GARCH.hist.map(r => r[xk]);
  plot("p-volhist", picked.map((t, i) => ({ type: "scatter", mode: "lines", name: t, x, y: GARCH.hist.map(r => r[t]), line: { width: 1.6, color: palette[i % palette.length] }, connectgaps: true })), { yaxis: { title: { text: "annualised %" }, rangemode: "tozero" }, legend: { orientation: "h", y: -0.12 } });
}

// ---------- open items (EQ-C-0074): /api/open-items, read only, every string through esc() ----------
// Copy buttons carry only an index; the command text stays in OI_CMDS and goes to the clipboard, never back into HTML.
const OI_TEXT = { open: "! Open", clear: "✓ Clear", unknown: "? Unreadable" };
let OI_CMDS = [];
function openItemsHTML(d) {
  if (!d || !Array.isArray(d.items)) return { status: `<div class="empty">Open items unavailable (the server did not answer /api/open-items).</div>`, items: "", cmds: [] };
  const cmds = [];
  const status = `<p><b>${esc(d.open)}</b> open, <b>${esc(d.unknown)}</b> unreadable · checked ${esc(d.generated_utc)}</p>`;
  const items = d.items.map(it => {
    const st = Object.prototype.hasOwnProperty.call(OI_TEXT, it.status) ? it.status : "unknown";
    const rows = Array.isArray(it.rows) ? it.rows : [];
    const cols = rows.length ? Object.keys(rows[0]) : [];
    const more = it.rows_total > rows.length ? `<p class="note">${esc(it.rows_total - rows.length)} more: econquest open-items --json</p>` : "";
    const tbl = rows.length ? `<div class="scroll mh240"><table><thead><tr>${cols.map(c => `<th>${esc(c)}</th>`).join("")}</tr></thead><tbody>` +
      rows.map(r => `<tr>${cols.map(c => `<td>${esc(r[c])}</td>`).join("")}</tr>`).join("") + `</tbody></table></div>${more}` : "";
    const cm = (st === "open" && Array.isArray(it.commands) ? it.commands : []).map(c => { cmds.push(String(c)); return `<div class="oi-cmd"><code>${esc(c)}</code> <button type="button" class="secondary oi-copy" data-i="${esc(cmds.length - 1)}">Copy</button></div>`; }).join("");
    return `<div class="oi-item ${esc(st)}"><h4><span class="oi-status ${esc(st)}">${esc(OI_TEXT[st])}</span> ${esc(it.title)}${it.count ? " (" + esc(it.count) + ")" : ""}</h4><p>${esc(it.summary)}</p>${st === "open" ? cm + tbl : ""}</div>`;
  }).join("");
  return { status, items, cmds };
}
async function todo() {
  const h = openItemsHTML(await tryJSON("/api/open-items"));
  OI_CMDS = h.cmds; $("#oi-status").innerHTML = h.status; $("#oi-items").innerHTML = h.items;
}
document.addEventListener("click", async ev => {
  const b = ev.target.closest ? ev.target.closest(".oi-copy") : null; if (!b) return;
  const text = OI_CMDS[Number(b.dataset.i)] ?? "";
  try { await navigator.clipboard.writeText(text); b.textContent = "Copied"; } catch (e) { b.textContent = "Select the text to copy"; }
  setTimeout(() => { b.textContent = "Copy"; }, 1500);
});

// ---------- Mac pass (EQ-C-0092): /api/next, read only, every string through esc() ----------
// As the open-items card: copy buttons carry only an index into NP_CMDS; command text never goes back into HTML raw.
const NP_TEXT = { done: "✓ Done", next: "▶ Next", todo: "○ To do", waiting: "… Waiting", unknown: "? Unreadable" };
const NP_CLASS = { done: "clear", next: "open", todo: "unknown", waiting: "unknown", unknown: "unknown" };
let NP_CMDS = [];
function nextPassHTML(d) {
  if (!d || !Array.isArray(d.steps)) return { status: `<div class="empty">Mac pass unavailable (the server did not answer /api/next).</div>`, steps: "", cmds: [] };
  const cmds = [];
  const status = `<p><b>${esc(d.done)}</b> of <b>${esc(d.total)}</b> done · ${d.next ? "next: step " + esc(d.next) : "no step to run now"} · checked ${esc(d.generated_utc)}</p>` +
    (Array.isArray(d.waiting) && d.waiting.length ? `<p class="note">Waiting: ${d.waiting.map(w => esc(w)).join("; ")}</p>` : "");
  const steps = d.steps.map(s => {
    const st = Object.prototype.hasOwnProperty.call(NP_TEXT, s.state) ? s.state : "unknown";
    const det = (Array.isArray(s.detail) ? s.detail : []).map(x => `<p>${esc(x)}</p>`).join("");
    const cm = (st !== "done" && Array.isArray(s.commands) ? s.commands : []).map(c => { cmds.push(String(c)); return `<div class="oi-cmd"><code>${esc(c)}</code> <button type="button" class="secondary np-copy" data-i="${esc(cmds.length - 1)}">Copy</button></div>`; }).join("");
    const wait = st === "waiting" && s.waiting_on ? ` · waiting on ${esc(s.waiting_on)}` : "";
    return `<div class="oi-item ${esc(st)}"><h4><span class="oi-status ${esc(NP_CLASS[st])}">${esc(NP_TEXT[st])}</span> ${esc(s.n)}. ${esc(s.title)}${wait}</h4>${det}${cm}</div>`;
  }).join("");
  return { status, steps, cmds };
}
async function nextpass() {
  const h = nextPassHTML(await tryJSON("/api/next"));
  NP_CMDS = h.cmds; $("#np-status").innerHTML = h.status; $("#np-steps").innerHTML = h.steps;
}
document.addEventListener("click", async ev => {
  const b = ev.target.closest ? ev.target.closest(".np-copy") : null; if (!b) return;
  const text = NP_CMDS[Number(b.dataset.i)] ?? "";
  try { await navigator.clipboard.writeText(text); b.textContent = "Copied"; } catch (e) { b.textContent = "Select the text to copy"; }
  setTimeout(() => { b.textContent = "Copy"; }, 1500);
});

// ---------- readiness (EQ-C-0081): /api/readiness, read only, every string through esc() ----------
const RD_CLASS = { "yes": "yes", "no": "no", "waiting on Sam": "sam", "no evidence": "none" };
function readinessHTML(d) {
  if (!d || !Array.isArray(d.rows)) return { status: `<div class="empty">Readiness unavailable (the server did not answer /api/readiness).</div>`, table: "" };
  if (d.error) return { status: `<div class="empty">${esc(d.error)}</div>`, table: "" };
  const status = `<p><b>${esc(d.message)}</b> As of ${esc(d.as_of)}.</p>`;
  const body = d.rows.map(r => {
    const cls = Object.prototype.hasOwnProperty.call(RD_CLASS, r.met) ? RD_CLASS[r.met] : "none";
    const needs = (Array.isArray(r.needs) ? r.needs : []).map(n => `<div><span class="rd-kind">${esc(n.kind_text)}</span>: ${esc(n.text)}${n.command ? " <code>" + esc(n.command) + "</code>" : ""}</div>`).join("");
    return `<tr><td><b>${esc(r.id)}</b></td><td>${esc(r.dimension)}</td><td class="rd-wrap">${esc(r.target)}</td><td class="rd-wrap">${esc(r.current)}</td>` +
      `<td><span class="rd-met ${esc(cls)}">${esc(r.met)}</span></td><td class="rd-wrap">${needs}</td><td>${esc(r.evidence)}</td></tr>`;
  }).join("");
  const head = ["id", "dimension", "target", "now", "met", "what it needs", "evidence"].map(h => `<th>${esc(h)}</th>`).join("");
  return { status, table: `<table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>` };
}
// calendar_tests (EQ-C-0095): status word always shown as text; colour only repeats it
const CT_CLASS = { "passed": "yes", "failed": "no", "due": "sam", "overdue": "sam", "review": "sam", "not_due": "none" };
function calendarTestsHTML(c) {
  if (!c || !Array.isArray(c.rows)) return { status: `<div class="empty">Calendar tests unavailable.</div>`, table: "" };
  if (!c.rows.length) return { status: `<div class="empty">${esc(c.message || "Calendar tests could not be read.")}</div>`, table: "" };
  const j = c.last_job || {};
  const status = `<p><b>${esc(c.message)}</b> Last job run: ${esc(j.last_status || "never")}${esc(j.last_end ? ", exit " + j.last_exit + " at " + j.last_end : "")}.</p>`;
  const body = c.rows.map(r => {
    const cls = Object.prototype.hasOwnProperty.call(CT_CLASS, r.status) ? CT_CLASS[r.status] : "none";
    return `<tr><td><b>${esc(r.test)}</b></td><td class="rd-wrap">${esc(r.title)}</td><td>${esc(r.formal_date)}</td><td>${esc(r.days_left)}</td>` +
      `<td>${esc(r.progress_text)}</td><td><span class="rd-met ${esc(cls)}">${esc(r.status_text)}</span></td><td class="rd-wrap">${esc(r.text)}</td></tr>`;
  }).join("");
  const head = ["test", "what", "formal from", "days left", "progress", "status", "detail"].map(h => `<th>${esc(h)}</th>`).join("");
  return { status, table: `<table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>` };
}
// client-mode decision (EQ-C-0105): text always shown; every string through esc()
const CD_CLASS = { "done": "yes", "open": "no", "unknown": "none" };
function clientDecisionHTML(c) {
  if (!c || !c.decision || !Array.isArray(c.no_regret)) return { status: `<div class="empty">${esc((c && c.summary) || "Client-mode decision unavailable.")}</div>`, table: "" };
  const dd = c.decision;
  const status = `<p><b>${esc(dd.text)}</b> Decided by ${esc(dd.by)} on ${esc(dd.decided_utc)} (option ${esc(dd.option)}); recorded in <code>${esc(dd.doc)}</code>${esc(dd.recorded ? "" : " (decision line not found)")}.</p><p>${esc(c.summary)}</p>`;
  const body = c.no_regret.map(r => {
    const cls = Object.prototype.hasOwnProperty.call(CD_CLASS, r.status) ? CD_CLASS[r.status] : "none";
    return `<tr><td><b>${esc(r.id)}</b></td><td class="rd-wrap">${esc(r.what)}</td><td>${esc(r.owner)}</td><td>${esc(r.ref)}</td>` +
      `<td><span class="rd-met ${esc(cls)}">${esc(r.status)}</span></td><td class="rd-wrap">${esc(r.detail)}</td></tr>`;
  }).join("");
  const head = ["item", "what", "owner", "ref", "status", "detail"].map(h => `<th>${esc(h)}</th>`).join("");
  return { status, table: `<table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>` };
}
// INTERIM backtest (EQ-C-0118): every number is Team B's; every string through esc(); INTERIM always in text
function interimBacktestHTML(ib) {
  if (!ib || !Array.isArray(ib.verdicts)) return { status: `<div class="empty">INTERIM backtest report unavailable.</div>`, table: "", months: "" };
  if (ib.status !== "ok") return { status: `<div class="empty">${esc(ib.message || "INTERIM backtest report unavailable.")} <code>${esc(ib.command)}</code></div>`, table: "", months: "" };
  const v = ib.var || {}, ma = ib.monthly_alert || {};
  const kv = (k, x) => `<div class="kpi"><div class="v">${esc(x ?? "n/a")}</div><div class="l">${esc(k)}</div></div>`;
  const status = `<p><b>${esc(ib.message)}</b></p><div class="kpis">` +
    kv("INTERIM VaR99 exceptions so far", v.exceptions) + kv("expected so far", v.expected == null ? null : Number(v.expected).toFixed(2)) +
    kv("INTERIM band (Team B)", v.band) + kv("INTERIM traffic-light zone (scaled to n)", v.zone) +
    kv("clean days collected", String(v.days_collected ?? "n/a") + " of " + String(v.days_required ?? 250)) + kv("days to formal 250-day test", v.days_to_formal) + `</div>` +
    `<p class="note">Report as of ${esc(ib.report_as_of)}${esc(ib.stale_days ? " (" + ib.stale_days + " days old)" : "")}; source <code>${esc(ib.source)}</code>. ` +
    `Zone: ${esc(v.zone_basis)}.` + (Array.isArray(ib.missing_fields) && ib.missing_fields.length ? ` Not in Team B's report: ${esc(ib.missing_fields.join("; "))}.` : "") +
    (ma.month ? ` Monthly interim alert ${esc(ma.month)} raised ${esc(ma.raised_at)}.` : " No monthly interim alert raised yet.") + `</p>`;
  const body = ib.verdicts.map(x => `<tr><td><b>${esc(x.test)}</b></td><td><span class="rd-met none">INTERIM</span></td><td>${esc(x.formal_date)}</td><td>${esc(x.days_to_formal)}</td>` +
    `<td class="rd-wrap">${esc(x.verdict)}</td><td class="rd-wrap">${esc(x.reading)}</td></tr>`).join("");
  const head = ["test", "kind", "formal from", "days to formal", "latest interim verdict", "interim reading"].map(h => `<th>${esc(h)}</th>`).join("");
  const bodyMonths = (Array.isArray(v.months) ? v.months : []).map(m => `<tr><td>${esc(m.month)}</td><td>${esc(m.days)}</td><td>${esc(m.exceptions)}</td></tr>`).join("");
  const headMonths = ["month (INTERIM)", "tested days", "VaR99 exceptions"].map(h => `<th>${esc(h)}</th>`).join("");
  return { status, table: `<table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>`,
           months: bodyMonths ? `<table><thead><tr>${headMonths}</tr></thead><tbody>${bodyMonths}</tbody></table>` : "" };
}
// MVP card (EQ-C-0124): latest econquest demo rows; status word always shown as text; every string through esc()
const MVP_CLASS = { "pass": "yes", "fail": "no", "pending": "sam" };
function mvpHTML(m) {
  if (!m || !Array.isArray(m.rows)) return { status: `<div class="empty">MVP status unavailable.</div>`, table: "" };
  if (!m.rows.length) return { status: `<div class="empty">${esc(m.message || "No econquest demo run yet.")}</div>`, table: "" };
  const status = `<p><b>${esc(m.message)}</b> Results: <code>${esc(m.path)}</code>.</p>`;
  const body = m.rows.map(r => {
    const cls = Object.prototype.hasOwnProperty.call(MVP_CLASS, r.status) ? MVP_CLASS[r.status] : "none";
    return `<tr><td><b>${esc(r.id)}</b></td><td class="rd-wrap">${esc(r.title)}</td><td><span class="rd-met ${esc(cls)}">${esc(r.status)}</span></td>` +
      `<td class="rd-wrap">${esc(r.reason)}</td><td class="rd-wrap">${esc(r.evidence)}</td><td>${esc(r.run_utc)}</td></tr>`;
  }).join("");
  const head = ["#", "criterion", "status", "reason", "evidence", "run (UTC)"].map(h => `<th>${esc(h)}</th>`).join("");
  return { status, table: `<table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>` };
}
async function readiness() {
  const d = await tryJSON("/api/readiness");
  const mv = mvpHTML(d && d.mvp);
  $("#rd-mvp").innerHTML = mv.status; $("#t-rd-mvp").innerHTML = mv.table;
  const mp = mvpPlusHTML(d && d.mvp);
  $("#rd-mvp-plus").innerHTML = mp.status; $("#t-rd-mvp-plus").innerHTML = mp.table;
  const cd = clientDecisionHTML(d && d.client_decision);
  $("#rd-client").innerHTML = cd.status; $("#t-rd-client").innerHTML = cd.table;
  const h = readinessHTML(d);
  $("#rd-status").innerHTML = h.status; $("#t-readiness").innerHTML = h.table;
  const c = calendarTestsHTML(d && d.calendar_tests);
  $("#rd-cal-status").innerHTML = c.status; $("#t-rd-cal").innerHTML = c.table;
  const ib = interimBacktestHTML(d && d.interim_backtest);
  $("#rd-interim-status").innerHTML = ib.status; $("#t-rd-interim").innerHTML = ib.table; $("#t-rd-interim-months").innerHTML = ib.months;
  $("#rd-explainer").innerHTML = backtestExplainerHTML(d && d.interim_backtest && d.interim_backtest.explainer);
  const cr = calendarRehearsalHTML(d && d.calendar_rehearsal);
  $("#rd-rehearsal-status").innerHTML = cr.status; $("#t-rd-rehearsal").innerHTML = cr.table; $("#rd-rehearsal-findings").innerHTML = cr.findings;
}

// ---------- econometrics ----------
async function econ() {
  if (!ECON.workflow) for (const n of ["workflow", "cointegration", "svar", "kalman", "regimes", "premia_fm", "premia_gmm", "evt", "copulas", "forecasts", "forecast_importance", "events"]) ECON[n] = await tryJSON("/api/table/econometrics/" + n);
  if (!ECON.workflow) { ["p-fcst", "p-imp", "p-irf", "p-kalman"].forEach(id => empty(id, "No econometrics results yet. Run Econometrics on the Data & jobs tab.")); return; }
  const F = ECON.forecasts || [];
  if (F.length) plot("p-fcst", [{ type: "bar", x: F.map(r => r.model), y: F.map(r => r.r2_out_of_sample), marker: { color: F.map(r => r.r2_out_of_sample > 0 ? "#2b5fa8" : "#c0392b") }, hovertemplate: "%{x}: R² %{y:.3f}<extra></extra>" }], { yaxis: { title: { text: "out-of-sample R²" } } });
  const I = (ECON.forecast_importance || []).slice();
  if (I.length) { const key = Object.keys(I[0]).find(k => k !== "index" && typeof I[0][k] === "number"); I.sort((a, b) => Math.abs(b[key]) - Math.abs(a[key])); plot("p-imp", [{ type: "bar", orientation: "h", y: I.slice(0, 15).map(r => r.index), x: I.slice(0, 15).map(r => r[key]), marker: { color: "#17a589" } }], { margin: { l: 170, r: 20, t: 10, b: 45 }, xaxis: { title: { text: key.replace(/_/g, " ") } }, yaxis: { autorange: "reversed" } }); }
  const V = ECON.svar || [];
  if (V.length) { const hs = Object.keys(V[0]).filter(k => /^(h\d+|cum_h\d+)$/.test(k)); const shocks = [...new Set(V.map(r => r.shock))];
    plot("p-irf", V.map((r, i) => ({ type: "scatter", mode: "lines+markers", name: `${r.variable} ← ${r.shock}`, x: hs, y: hs.map(k => r[k]), line: { color: palette[i % palette.length], dash: r.shock === shocks[0] ? "solid" : "dot" } })), { xaxis: { title: { text: "horizon (h = impulse response, cum = cumulative)" } }, yaxis: { title: { text: "% response" } }, legend: { orientation: "h", y: -0.25 } }); }
  const K = ECON.kalman || [];
  if (K.length) plot("p-kalman", [{ type: "bar", name: "beta now", x: K.map(r => r.ticker), y: K.map(r => r.beta_now), marker: { color: "#2b5fa8" } }, { type: "bar", name: "one year ago", x: K.map(r => r.ticker), y: K.map(r => r.beta_1y_ago), marker: { color: "#aab7c4" } },
    { type: "scatter", mode: "markers", name: "OLS beta", x: K.map(r => r.ticker), y: K.map(r => r.beta_ols), marker: { color: "#c0392b", symbol: "diamond", size: 8 } }], { barmode: "group", yaxis: { title: { text: "beta to " } + (K[0].factor || "factor") }, xaxis: { tickangle: -45 } });
  table("t-workflow", ECON.workflow, { heat: {}, sort: "country", asc: true });
  table("t-coint", ECON.cointegration); table("t-regimes", ECON.regimes); table("t-evt", ECON.evt); table("t-fm", ECON.premia_fm); table("t-gmm", ECON.premia_gmm); table("t-copulas", ECON.copulas); table("t-events", ECON.events);
}

// ---------- prediction markets ----------
function markets() {
  const a = RUN.arbitrage.slice().sort((x, y) => y.net_edge_pp - x.net_edge_pp);
  plot("p-arb", [{ type: "bar", name: "market Yes price", x: a.map(r => r.id), y: a.map(r => r.yes_price * 100), marker: { color: "#aab7c4" } }, { type: "bar", name: "model probability", x: a.map(r => r.id), y: a.map(r => r.model_p_res * 100), marker: { color: "#2b5fa8" } },
    { type: "scatter", mode: "markers", name: "net edge (pp)", x: a.map(r => r.id), y: a.map(r => r.net_edge_pp), marker: { color: a.map(r => r.divergence_flag ? "#c0392b" : "#d68910"), size: 10 }, hovertemplate: a.map(r => `${r.id} ${r.country}<br>${r.contract}<br>${r.side}, edge ${r.net_edge_pp.toFixed(1)}pp, stake $${r.stake_k.toFixed(0)}k<extra></extra>`) }], { barmode: "group", yaxis: { title: { text: "%" } } });
  table("t-arb", RUN.arbitrage, { cols: ["id", "platform", "country", "driver", "contract", "months", "yes_price", "model_p_res", "side", "net_edge_pp", "ev_per_dollar", "kelly", "stake_k", "expected_profit_k", "divergence_flag", "related_trade"], fmt: { model_p_res: fmt.pct1, yes_price: v => fmt.n(v, 2), kelly: fmt.pct1 }, sort: "net_edge_pp", heat: { net_edge_pp: [0, 40] } });
}

// ---------- workbench ----------
const PILLARS = ["1 Debt & external", "2 Fiscal & monetary", "3 Institutions", "4 Political stability", "5 Growth & inflation", "6 Social & security", "7 Climate & exogenous"];
function workbench() {
  const sel = $("#w-country"); if (!sel.options.length) {
    RUN.country.forEach(r => sel.add(new Option(r.country)));
    $("#w-sliders").innerHTML = PILLARS.map((p, i) => `<div><label>Pillar ${p}<output id="w-o${i + 1}">0</output></label><input type="range" min="-10" max="10" step="1" value="0" id="w-s${i + 1}"></div>`).join("");
    PILLARS.forEach((p, i) => { $(`#w-s${i + 1}`).oninput = ev => { $(`#w-o${i + 1}`).value = ev.target.value; }; });   // no inline handlers under the CSP (EQ-C-0125)
    $("#w-reset").onclick = () => PILLARS.forEach((p, i) => { $(`#w-s${i + 1}`).value = 0; $(`#w-o${i + 1}`).value = 0; });
    $("#w-run").onclick = runWorkbench;
    $("#w-base").onclick = async () => { await post("/api/reload"); await loadRun(); Object.keys(loaded).forEach(k => delete loaded[k]); showResult(RUN); show("overview"); };
  }
  showResult(RUN);
}
function showResult(run) { kpis($("#w-kpis"), run.summary.metrics); histogram("p-whist", run); }
async function runWorkbench() {
  const adj = {}; PILLARS.forEach((p, i) => { const v = +$(`#w-s${i + 1}`).value; if (v) adj[String(i + 1)] = v; });
  const body = { analyst: { [$("#w-country").value]: adj }, paths: +$("#w-paths").value, scenario: $("#w-scenario").value, label: "workbench" };
  const msg = $("#w-msg"); msg.style.display = ""; msg.textContent = "Running Monte Carlo…"; $("#w-run").disabled = true;
  try { await post("/api/workbench", body); await loadRun(); showResult(RUN); Object.keys(loaded).forEach(k => delete loaded[k]); msg.textContent = `Done: ${RUN.summary.run_id}, as of ${RUN.summary.as_of ?? RUN.settings?.as_of ?? RUN.summary.versions?.as_of ?? "not recorded"}. Other tabs now show this scenario.`; }
  catch (e) { msg.textContent = "Failed: " + e.message; } finally { $("#w-run").disabled = false; }
}

// ---------- jobs ----------
let jobTimer = null, currentJob = null;
// ---------- Licensed vendor onboarding (EQ-C-0108): /api/vendor-check, read only, every string through esc() ----------
// As the open-items card: copy buttons carry only an index into VC_CMDS; command text never goes back into HTML raw.
const VC_TEXT = { done: "✓ Done", todo: "○ To do", waiting: "… Waiting", problem: "! Problem", unknown: "? Unreadable" };
const VC_CLASS = { done: "clear", todo: "unknown", waiting: "unknown", problem: "open", unknown: "unknown" };
let VC_CMDS = [];
function vendorCheckHTML(d) {
  if (!d || !Array.isArray(d.steps) || d.error) return { status: `<div class="empty">${esc(d && d.error ? d.error : "Vendor check unavailable (the server did not answer /api/vendor-check).")}</div>`, steps: "", cmds: [] };
  const cmds = [];
  const status = `<p><b>${esc(d.vendor)}</b>: <b>${esc(d.done)}</b> of <b>${esc(d.total)}</b> done · checked ${esc(d.generated_utc)}</p><p class="note">${esc(d.note)}</p>`;
  const steps = d.steps.map(s => {
    const st = Object.prototype.hasOwnProperty.call(VC_TEXT, s.state) ? s.state : "unknown";
    const rows = Array.isArray(s.rows) ? s.rows : [];
    const cols = rows.length ? Object.keys(rows[0]) : [];
    const tbl = rows.length ? `<div class="scroll mh200"><table><thead><tr>${cols.map(c => `<th>${esc(c)}</th>`).join("")}</tr></thead><tbody>` +
      rows.map(r => `<tr>${cols.map(c => `<td>${esc(r[c])}</td>`).join("")}</tr>`).join("") + `</tbody></table></div>` : "";
    const det = (Array.isArray(s.detail) ? s.detail : []).map(x => `<p>${esc(x)}</p>`).join("");
    const cm = (st !== "done" && Array.isArray(s.commands) ? s.commands : []).map(c => { cmds.push(String(c)); return `<div class="oi-cmd"><code>${esc(c)}</code> <button type="button" class="secondary vc-copy" data-i="${esc(cmds.length - 1)}">Copy</button></div>`; }).join("");
    return `<div class="oi-item ${esc(st)}"><h4><span class="oi-status ${esc(VC_CLASS[st])}">${esc(VC_TEXT[st])}</span> ${esc(s.n)}. ${esc(s.title)}</h4>${tbl}${det}${cm}</div>`;
  }).join("");
  return { status, steps, cmds };
}
async function vendorCheck(vendor) {
  $("#vc-status").innerHTML = `<p class="note">Checking…</p>`; $("#vc-steps").innerHTML = "";
  const h = vendorCheckHTML(await tryJSON("/api/vendor-check?vendor=" + encodeURIComponent(vendor)));
  VC_CMDS = h.cmds; $("#vc-status").innerHTML = h.status; $("#vc-steps").innerHTML = h.steps;
}
function vcInit() { $("#vc-bbg").onclick = () => vendorCheck("bloomberg"); $("#vc-lseg").onclick = () => vendorCheck("lseg"); }
document.addEventListener("click", async ev => {
  const b = ev.target.closest ? ev.target.closest(".vc-copy") : null; if (!b) return;
  const text = VC_CMDS[Number(b.dataset.i)] ?? "";
  try { await navigator.clipboard.writeText(text); b.textContent = "Copied"; } catch (e) { b.textContent = "Select the text to copy"; }
  setTimeout(() => { b.textContent = "Copy"; }, 1500);
});

// ---------- Update BoC-BoE defaults (EQ-C-0087, HO-20261025-A-C-003): /api/crag-update, every value through esc() ----------
// Apply re-sends exactly the bytes of the last dry run (kept here), with that dry run's sha256; the server refuses
// any other apply. A new file choice clears the dry run.
let CRAG = { name: null, b64: null, sha: null, max: 25 * 2 ** 20, blocked: null };
const CR_TEXT = { dry_run: "DRY RUN: nothing live changed", applied: "APPLIED", refused: "REFUSED", fetch_unavailable: "FETCH UNAVAILABLE", error: "ERROR" };
const CR_BADGE = { dry_run: "running", applied: "done", refused: "failed", fetch_unavailable: "failed", error: "failed" };
function cragReset() { CRAG.b64 = null; CRAG.sha = null; CRAG.name = null; $("#cr-apply").disabled = true; }
function cragFile() { return new Promise((res, rej) => {
  const f = $("#cr-file").files[0]; if (!f) return rej(new Error("choose a .csv or .xlsx file first"));
  if (!/\.(csv|xlsx)$/i.test(f.name)) return rej(new Error("expected a .csv or .xlsx file"));
  if (f.size === 0 || f.size > CRAG.max) return rej(new Error(`the file must be 1 byte to ${CRAG.max.toLocaleString()} bytes`));
  const r = new FileReader(); r.onerror = () => rej(new Error("the file could not be read"));
  r.onload = () => res({ name: f.name, b64: String(r.result).split(",", 2)[1] || "" }); r.readAsDataURL(f); }); }
function cragDiffHTML(d) {
  const rows = Array.isArray(d.diff_rows) ? d.diff_rows : [];
  if (!rows.length) return d.status === "dry_run" || d.status === "applied" ? `<p class="note">No episode added, removed or changed.</p>` : "";
  const yrs = (a, b) => a == null && b == null ? "" : `${esc(a)}–${esc(b)}`;
  const amt = v => v == null || v === "" ? "" : esc(fmt.n(v, 0));
  const head = `<tr><th>Change</th><th>ISO</th><th>Country</th><th>Old years</th><th>New years</th><th>Old type</th><th>New type</th><th>Old peak $mm</th><th>New peak $mm</th><th>Changed fields</th></tr>`;
  const body = rows.map(r => `<tr><td>${esc(r.status)}</td><td>${esc(r.iso)}</td><td>${esc(r.country)}</td><td>${yrs(r.old_start, r.old_end)}</td><td>${yrs(r.new_start, r.new_end)}</td><td>${esc(r.old_type)}</td><td>${esc(r.new_type)}</td><td>${amt(r.old_amount_usd_m)}</td><td>${amt(r.new_amount_usd_m)}</td><td>${esc(Array.isArray(r.changed_fields) ? r.changed_fields.join(", ") : r.changed_fields)}</td></tr>`).join("");
  const more = d.diff_rows_total > rows.length ? `<p class="note">First ${esc(rows.length)} of ${esc(d.diff_rows_total)} rows; the full diff is crag_update_diff.csv in ${esc(d.run_folder)}.</p>` : "";
  return `<h4>Episodes added, removed or changed</h4><table>${head}${body}</table>${more}`;
}
function cragShow(d) {
  if (d.error) { $("#cr-status").innerHTML = `<p><span class="badge failed">REFUSED</span> ${esc(d.error)}</p>`; return; }
  const st = Object.prototype.hasOwnProperty.call(CR_TEXT, d.status) ? d.status : "error";
  const c = d.counts || {};
  let html = `<p><span class="badge ${esc(CR_BADGE[st])}">${esc(CR_TEXT[st])}</span> ${esc(d.message)}</p>`;
  if (st === "error") html += `<p class="empty t-red tl">Error: ${esc(d.message)}<br>Apply is disabled until this is resolved by hand (see the runbook), then restart the GUI.</p>`;
  if (d.retry_later) html += `<p class="note">Another update is applying the CRAG file. Wait for it to finish, then click Apply again (no automatic retry).</p>`;
  if (st === "dry_run" || st === "applied") html += `<p>${esc(d.input_name)} (${esc(d.format)}, sha256 ${esc(String(d.input_sha256 || "").slice(0, 12))}…) · vintage <b>${esc(d.new_vintage)}</b> ${d.new_vintage_created ? "(new)" : "(already stored)"} · compared with <code>${esc(d.diff_base || "nothing (no previous CRAG file)")}</code><br>` +
    `${esc(c.episodes)} episodes in ${esc(c.countries)} countries (previously ${esc(c.previous_episodes)}): <b>+${esc(c.added)}</b> added, <b>−${esc(c.removed)}</b> removed, <b>${esc(c.changed)}</b> changed, ${esc(c.unchanged)} unchanged · licence ${esc(d.licence_status)}</p>`;
  if (Array.isArray(d.warnings) && d.warnings.length) html += `<p class="note">Warnings: ${d.warnings.map(w => esc(w)).join("; ")}</p>`;
  $("#cr-status").innerHTML = html;
  $("#cr-summary").innerHTML = d.summary_text ? `<pre class="log">${esc(d.summary_text)}</pre>` : "";
  $("#cr-diff").innerHTML = cragDiffHTML(d);
}
async function cragPost(body) {
  const r = await post("/api/crag-update", body); let d;
  try { d = await r.json(); } catch (e) { d = { error: `the server answered ${r.status}` }; }
  return d;
}
async function cragDry() {
  cragReset(); $("#cr-status").innerHTML = `<p class="note">Dry run…</p>`; $("#cr-summary").innerHTML = ""; $("#cr-diff").innerHTML = "";
  let f; try { f = await cragFile(); } catch (e) { return cragShow({ error: e.message }); }
  const d = await cragPost({ name: f.name, content_b64: f.b64, apply: false });
  cragShow(d);
  if (!d.error && d.status === "dry_run" && d.can_apply && d.input_sha256) { CRAG.name = f.name; CRAG.b64 = f.b64; CRAG.sha = d.input_sha256; $("#cr-apply").disabled = false; }
  if (d.status === "error") CRAG.blocked = d.message;
}
async function cragApply() {
  if (!CRAG.b64 || !CRAG.sha || CRAG.blocked) return;
  if (!confirm(`Replace the live data/panel/sovereign_defaults_crag.csv with ${CRAG.name}? The memory list is not changed.`)) return;
  $("#cr-apply").disabled = true; $("#cr-status").innerHTML = `<p class="note">Applying…</p>`;
  const d = await cragPost({ name: CRAG.name, content_b64: CRAG.b64, apply: true, dry_run_sha256: CRAG.sha });
  cragShow(d);
  if (d.status === "error") CRAG.blocked = d.message;
  if (d.retry_later && !CRAG.blocked) $("#cr-apply").disabled = false;       // same dry run; the operator retries
  else if (d.status === "applied" || d.status === "error" || d.error) cragReset();
}
async function cragInit() {
  const d = await tryJSON("/api/crag-update");
  if (d && d.max_bytes) CRAG.max = Number(d.max_bytes);
  if (d && d.apply_blocked) CRAG.blocked = String(d.apply_blocked);
  const page = d ? d.fetch_page : "";
  $("#cr-fetch").innerHTML = d && d.fetch_available
    ? `<button id="cr-fetch-go" type="button" class="secondary" title="Dry run on a file downloaded from the verified Bank of Canada URL; to apply, upload that file">Fetch from Bank of Canada (dry run)</button>`
    : `<button type="button" class="secondary" disabled>Fetch from Bank of Canada</button> <span class="note">unavailable: no verified download URL yet; download the file from ${esc(page)} and choose it above</span>`;
  const g = $("#cr-fetch-go"); if (g) g.onclick = async () => { cragReset(); cragShow(await cragPost({ fetch: true })); };
  $("#cr-file").onchange = cragReset; $("#cr-dry").onclick = cragDry; $("#cr-apply").onclick = cragApply;
}

async function jobs() {
  await loadStatus();
  if (!cragInit.done) { cragInit.done = true; cragInit(); }
  if (!vcInit.done) { vcInit.done = true; vcInit(); }
  const S = STATUS, line = (label, i, cmd) => `<tr><td>${label}</td><td>${i.exists ? `<span class="badge done">present</span> ${i.modified}` : `<span class="badge failed">missing</span>`}</td><td>${cmd}</td></tr>`;
  $("#j-files").innerHTML = `<table><tr><th>Item</th><th>Status</th><th>Produced by</th></tr>` +
    line("Model run (run_latest.json)", S.run, "Run model") + line("Stress scenarios", S.stress, "Run model (with stress)") + line("Backtests", S.backtest, "Run model (with stress & backtests)") +
    line("GARCH tables", S.garch, "GARCH") + line("Econometrics tables", S.econ, "Econometrics") + line("Audit trail (data/audit_trail.csv)", S.audit, "Audit trail") + line("Market history prices (data/market_history/prices.csv)", S.prices, "Export the Market History tab from the workbook") +
    `<tr><td>Live feed files (data/live)</td><td>${S.live.files.length ? `<span class="badge done">${S.live.files.length} files</span> ${S.live.files.slice(0, 6).join(", ")}${S.live.files.length > 6 ? "…" : ""}` : `<span class="badge failed">none</span>`}</td><td>Fetch live data</td></tr></table>
    <p class="note">Data folder: ${S.data_dir}<br>Outputs: ${S.out_dir}</p>`;
  document.querySelectorAll("#jobs button[data-job]").forEach(b => b.onclick = () => startJob(b));
  const ptSel = $("#pt-country"); if (!ptSel.options.length && RUN) RUN.country.forEach(r => ptSel.add(new Option(r.country)));
  $("#pt-go").onclick = startPretrade; pretradeResult(); scenarioTables();
  pollJobs();
  await auditTable();
}
let AUDIT = null;
async function auditTable() {
  if (!AUDIT) AUDIT = await tryJSON("/api/data/audit_trail");
  if (!AUDIT) { table("t-audit", [], { emptyMsg: "No audit trail yet. Click Audit trail above." }); return; }
  const counts = {}; AUDIT.forEach(r => { counts[r.origin] = (counts[r.origin] || 0) + 1; });
  $("#a-summary").textContent = Object.entries(counts).map(([k, v]) => `${v} ${k}`).join(" · ");
  const draw = () => {
    const q = $("#a-filter").value.trim().toLowerCase();
    const rows = q ? AUDIT.filter(r => Object.values(r).some(v => String(v ?? "").toLowerCase().includes(q))) : AUDIT;
    table("t-audit", rows.slice(0, 400), { cols: ["table", "key", "indicator", "country", "value", "origin", "source", "series", "transform", "retrieved", "gate_status", "decision", "robustness_rule"] });
  };
  $("#a-filter").oninput = draw; draw();
}
async function scenarioTables() {
  const lib = await tryJSON("/api/table/scenario_library"), rs = await tryJSON("/api/table/reverse_stress");
  table("t-scenlib", lib || [], { cols: ["scenario", "name", "kind", "var99_mm", "es99_mm", "lvar99_mm", "expected_loss_mm", "var99_mm_pct", "to_crisis", "mean_pd_pp"], sort: "var99_mm", desc: true, emptyMsg: "No scenario run yet. Click Scenario library." });
  table("t-reverse", rs || [], { cols: ["kind", "key", "label", "measure", "breach_size", "unit", "status", "first_breach"], emptyMsg: "No reverse stress yet. Click Reverse stress." });
  const dsa = await tryJSON("/api/table/dsa");
  table("t-dsa", dsa || [], { cols: ["country", "debt_now", "r_minus_g", "pb_gap", "debt_baseline_5y", "debt_median_5y", "debt_p10_5y", "debt_p90_5y", "p_debt_rising", "gfn_pct_gdp", "debt_service_pct_revenue", "fx_debt_service_24m_pct_reserves", "reserves_pct_ara", "read"], sort: "p_debt_rising", emptyMsg: "No DSA yet. Click Debt sustainability and reserves." });
}
async function startPretrade() {
  const n = $("#pt-notional").value.trim(), dur = $("#pt-dur").value.trim(), args = [];
  if (n) { if (!(parseFloat(n) > 0)) { alertMsg("Enter a positive notional in $mm."); return; } args.push("--propose", `${$("#pt-country").value},${$("#pt-class").value},${$("#pt-dir").value},${n}${dur ? "," + dur : ""}`); }
  const r = await post("/api/job", { cmd: "limits", args, secrets: [] });
  const j = await r.json(); if (j.error) { alertMsg(j.error); return; }
  currentJob = j.id; pollJobs();
  const wait = async () => { const full = await getJSON("/api/job/" + j.id); if (full.status === "running") { setTimeout(wait, 1500); return; } await pretradeResult(); };
  setTimeout(wait, 1500);
}
async function pretradeResult() {
  const lim = await tryJSON("/api/table/limits"), pt = await tryJSON("/api/json/pretrade");
  if (pt && pt.verdict) {
    const col = { accept: "t-green", flag: "t-amber", refuse: "t-red" }[pt.verdict] || "t-inherit";
    // EQ-C-0048: the saved result can be from an earlier proposal than the form shows, so say so; verdict and reasons escaped
    $("#pt-verdict").innerHTML = `<p class="note">Last saved check (outputs/pretrade.json), not necessarily the proposal in the form:</p><p><b class="${col}">${esc(String(pt.verdict).toUpperCase())}</b>: ${esc(pt.proposal.country)} ${esc(pt.proposal.asset_class)} ${esc(pt.proposal.direction)} ${esc(pt.proposal.notional_mm)} $mm. VaR99 ${fmt.sig(pt.before_common_paths.var99_mm)} to ${fmt.sig(pt.after.var99_mm)} (marginal ${fmt.sig(pt.marginal_var99_mm)}), ES99 ${fmt.sig(pt.before_common_paths.es99_mm)} to ${fmt.sig(pt.after.es99_mm)} (marginal ${fmt.sig(pt.marginal_es99_mm)}), ${esc(pt.paths)} paths.</p>` +
      ((pt.reasons || []).length ? `<ul>${pt.reasons.map(r => `<li>${esc(r)}</li>`).join("")}</ul>` : `<p class="note">No limit at or above its warning level after the trade.</p>`);
  } else $("#pt-verdict").innerHTML = "";
  table("t-limits", lim || [], { cols: ["scope", "name", "measure", "value", "limit", "utilisation", "status"], sort: "utilisation", emptyMsg: "No limits table yet. Click Check trade." });
}
async function startJob(b) {
  const args = b.dataset.args ? b.dataset.args.split(" ") : []; const body = { cmd: b.dataset.job, args };
  // The token travels in the JSON body; the server hands it to the job as $ECONQUEST_SHEETS_TOKEN, never on its command line.
  if (b.dataset.token) { const t = $("#j-token").value.trim(); if (!t) { alertMsg("Paste a Google Sheets OAuth token first to write the workbook. To build the plan without writing, use Save publish plan (no write)."); return; } body.sheets_token = t; }
  const r = await post("/api/job", body);
  const j = await r.json(); if (j.error) { alertMsg(j.error); return; }
  currentJob = j.id; pollJobs();
}
function alertMsg(t) { $("#j-status").innerHTML = `<p class="note t-red">${esc(t)}</p>`; }
async function pollJobs() {
  clearTimeout(jobTimer);
  const data = await getJSON("/api/jobs"); const js = data.jobs;
  const cur = currentJob ? js.find(j => j.id === currentJob) : js[js.length - 1];
  document.querySelectorAll("#jobs button[data-job]").forEach(b => b.disabled = data.running);
  const chip = $("#chip-job");
  if (data.running && cur) { chip.style.display = ""; chip.className = "chip warn"; chip.innerHTML = `running <b>${esc(cur.cmd)}</b>`; } else chip.style.display = "none";
  if (cur) {
    const full = await getJSON("/api/job/" + cur.id);
    $("#j-badge").innerHTML = `<span class="badge ${full.status}">${full.status}</span> <span class="argv-note">${esc(full.argv)}</span>`;
    const log = $("#j-log"); const atBottom = log.scrollTop + log.clientHeight >= log.scrollHeight - 20;
    log.textContent = full.log.join("\n") || "(no output yet)"; if (atBottom) log.scrollTop = log.scrollHeight;
    if (full.status !== "running" && full.id === currentJob) { currentJob = null; if (["run", "stress", "backtest"].includes(full.cmd) && full.status === "done") { await post("/api/reload"); await loadRun(); } GARCH = {}; ECON = {}; Object.keys(loaded).forEach(k => delete loaded[k]); loadStatus(); }
  }
  $("#j-history").innerHTML = js.length ? `<table><tr><th>#</th><th>Command</th><th>Started</th><th>Finished</th><th>Status</th></tr>` + js.slice().reverse().map(j => `<tr><td>${j.id}</td><td>${esc(j.argv)}</td><td>${j.started}</td><td>${j.finished || ""}</td><td><span class="badge ${j.status}">${j.status}</span></td></tr>`).join("") + "</table>" : `<div class="empty">No jobs run in this session.</div>`;
  if (data.running) jobTimer = setTimeout(pollJobs, 1500);
}

// ---------- research notes (EQ-C-0127): /api/notes. Notes arrive as plain text blocks (the server parses the pack's
// HTML and keeps text only); every string goes through esc(), no markup from a note reaches innerHTML, no inline handlers.
const getAuthJSON = async url => {
  const r = await fetch(url, { headers: { "X-EconQuest-Token": TOKEN } });
  const d = await r.json().catch(() => ({}));
  if (!r.ok) throw new Error(d.error || r.statusText);
  return d;
};
let NOTES = null;
function noteBlock(b) {
  if (b.t === "h") { const l = Math.min(6, Number(b.level || 1) + 2); return `<h${l}>${esc(b.text)}</h${l}>`; }
  if (b.t === "p") return `<p>${esc(b.text)}</p>`;
  if (b.t === "kpi") return `<div class="kpi"><div class="v">${esc((b.parts || [])[0])}</div><div class="l">${esc((b.parts || []).slice(1).join(" · "))}</div></div>`;
  if (b.t === "list") return `<ul>${(b.items || []).map(x => `<li>${esc(x)}</li>`).join("")}</ul>`;
  if (b.t === "table") return `<div class="scroll"><table><tbody>${(b.rows || []).map(r => "<tr>" + r.map(c => c.head ? `<th>${esc(c.text)}</th>` : `<td>${esc(c.text)}</td>`).join("") + "</tr>").join("")}</tbody></table></div>`;
  return "";
}
function noteBody(blocks) {
  let html = "", kpis = "";
  for (const b of blocks || []) {
    if (b.t === "kpi") { kpis += noteBlock(b); continue; }
    if (kpis) { html += `<div class="kpis">${kpis}</div>`; kpis = ""; }
    html += noteBlock(b);
  }
  return html + (kpis ? `<div class="kpis">${kpis}</div>` : "");
}
async function showNote(id) {
  const box = $("#n-note");
  document.querySelectorAll("#n-list button").forEach(b => b.classList.toggle("active", b.dataset.id === id));
  box.innerHTML = `<div class="empty">Loading…</div>`;
  let n;
  try { n = await getAuthJSON("/api/notes/" + encodeURIComponent(id)); } catch (e) { box.innerHTML = `<div class="empty">Note unavailable: ${esc(e.message)}</div>`; return; }
  const pk = n.pack || {};
  const warn = [];
  if (!n.disclaimer_ok) warn.push("the standard disclaimer was not found in this note");
  if (!n.attribution_ok) warn.push("no licence attribution was found in this note");
  if (n.changed_since_draft) warn.push("the file changed after it was drafted in the editorial ledger");
  box.innerHTML = `<h3>${esc(n.title)} <span class="chip"><b>${esc(n.kind_label)}</b></span> <span class="chip">editorial <b>${esc(n.state || "not registered")}</b></span></h3>` +
    `<p class="note">Run ${esc(pk.run_id)} · as of ${esc(pk.as_of)} · data hash ${esc(pk.data_hash)} · file ${esc(n.file)}</p>` +
    (warn.length ? `<p class="note-warn"><b>[CHECK]</b> ${esc(warn.join("; "))}.</p>` : "") +
    `<div class="note-disclaimer" role="note">${n.marking ? `<p><b>${esc(n.marking)}</b></p>` : ""}<p>${esc(n.disclaimer || "No disclaimer found in this note: do not use it.")}</p></div>` +
    (n.error ? `<div class="empty">${esc(n.error)}</div>` : `<div class="note-body">${noteBody(n.blocks)}</div>`) +
    `<div class="note-licence" role="note"><b>Sources and licences</b>${(n.attribution || []).length ? `<ul>${n.attribution.map(x => `<li>${esc(x)}</li>`).join("")}</ul>` : `<p>No licence attribution found in this note.</p>`}` +
    ((n.internal_only || []).length ? `<details><summary>Internal-only content (not for client output): ${n.internal_only.length}</summary><ul>${n.internal_only.map(x => `<li>${esc(x)}</li>`).join("")}</ul></details>` : "") + `</div>`;
}
async function notes() {
  const st = $("#n-status"), list = $("#n-list");
  try { NOTES = await getAuthJSON("/api/notes"); } catch (e) { st.innerHTML = `<div class="empty">Notes unavailable (/api/notes: ${esc(e.message)}).</div>`; list.innerHTML = ""; return; }
  const tag = { ok: "OK", empty: "EMPTY", missing: "NO PACK" }[NOTES.status] || String(NOTES.status).toUpperCase();
  const col = NOTES.status === "ok" ? "t-green" : "t-amber";
  const ck = NOTES.check;
  st.innerHTML = `<p><b class="${col}">[${esc(tag)}]</b> ${esc(NOTES.message)}</p>` +
    (ck ? `<span class="chip ${ck.ok ? "ok" : "warn"}">pack check <b>${ck.ok ? "PASS" : "FAIL · " + esc(ck.problems) + " problems"}</b></span> ` : "") +
    Object.entries(NOTES.counts || {}).map(([k, v]) => `<span class="chip">${esc(k.replace(/_/g, " "))} <b>${esc(v)}</b></span>`).join(" ");
  const kinds = [...new Set((NOTES.notes || []).map(n => n.kind_label))];
  $("#n-kind").innerHTML = `<option value="">All</option>` + kinds.map(k => `<option value="${esc(k)}">${esc(k)}</option>`).join("");
  const draw = () => {
    const k = $("#n-kind").value, q = $("#n-filter").value.toLowerCase();
    const rows = (NOTES.notes || []).filter(n => (!k || n.kind_label === k) && (!q || `${n.title} ${n.kind_label}`.toLowerCase().includes(q)));
    list.innerHTML = rows.length ? rows.map(n => `<button class="secondary" data-id="${esc(n.id)}">${esc(n.title)}<span>${esc(n.kind_label)} · ${esc(n.state || "not registered")}</span></button>`).join("")
      : `<div class="empty">${NOTES.status === "missing" ? "No research pack yet." : "No note matches the filter."}</div>`;
    list.querySelectorAll("button").forEach(b => b.addEventListener("click", () => showNote(b.dataset.id)));
  };
  $("#n-kind").addEventListener("input", draw); $("#n-filter").addEventListener("input", draw);
  draw();
  if ((NOTES.notes || []).length) showNote(NOTES.notes[0].id); else $("#n-note").innerHTML = `<div class="empty">No note to show.</div>`;
}


// ---------- relative value (EQ-C-0046): /api/rv, every string through esc() or table() ----------
let RV = null;
const rvTag = st => ({ ok: "OK", empty: "EMPTY", missing: "NO FILE", invalid: "UNREADABLE" }[st] || String(st).toUpperCase());
const rvCol = st => st === "ok" ? "t-green" : st === "invalid" ? "t-red" : "t-amber";
const SYN_BADGE = `<span class="badge failed">SYNTHETIC</span>`;
async function rv() {
  RV = await tryJSON("/api/rv");
  const st = $("#rv-status"), cs = $("#rv-curve-status");
  if (!RV) { st.innerHTML = `<div class="empty">Relative-value view unavailable (the server did not answer /api/rv).</div>`; cs.innerHTML = ""; empty("p-rv", "No data."); empty("p-rv-par", "No data."); empty("p-rv-haz", "No data."); table("t-rv", []); table("t-rv-pos", []); table("t-rv-curves", []); return; }
  const line = part => `<p><b class="${rvCol(part.status)}">[${esc(rvTag(part.status))}]</b> ${esc(part.file)}: ${esc(part.message)}</p>`;
  const rvSyn = (RV.rv.rows || []).concat(RV.positions.rows || []).some(r => r.synthetic);   // curves carry their own marker below
  st.innerHTML = (rvSyn ? `<p>${SYN_BADGE} <b>${esc(RV.synthetic_note)}</b> Rows with a (SYNTHETIC) market source.</p>` : "") + line(RV.rv) + line(RV.positions) +
    (RV.as_of ? `<p class="note">As of ${esc(RV.as_of)}${(RV.as_of_dates || []).length > 1 ? ` (file holds ${esc(RV.as_of_dates.join(", "))})` : ""}. Reads: ${esc(Object.entries(RV.reads || {}).map(([k, n]) => k + " " + n).join("; "))}.</p>` : "");
  $("#rv-label").textContent = RV.label || "";
  const syn = v => v ? "SYNTHETIC" : "";
  const rows = (RV.rv.rows || []).map(r => ({ country: r.country, iso3: r.iso3, rating: r.rating, tenor_y: r.tenor_y, pd_12m: r.pd_12m, lgd: r.lgd, risk_premium_ratio: r.risk_premium_ratio,
    el_bp: r.el_bp, risk_premium_bp: r.risk_premium_bp, fair_bp: r.fair_bp, market_bp: r.market_bp, gap_bp: r.gap_bp, z: r.distressed ? null : r.z, z_xs: r.z_xs,
    rv_read: r.rv_read, distressed: r.distressed ? "DISTRESSED" : "", market_source: r.market_source, synthetic: syn(r.synthetic), as_of: r.as_of }));
  const bp = v => v == null ? "" : fmt.n(v, 0), gap = v => v == null ? "" : (v > 0 ? "+" : "") + fmt.n(v, 0), zf = v => v == null ? "" : fmt.n(v, 2);
  const rvFmt = { tenor_y: v => fmt.n(v, 0), pd_12m: fmt.pct, lgd: v => fmt.pct1(v), risk_premium_ratio: v => v == null ? "" : fmt.n(v, 2) + "x", el_bp: bp, risk_premium_bp: bp, fair_bp: bp, market_bp: bp, gap_bp: gap, z: zf, z_xs: zf };
  const rvLabels = { iso3: "ISO3", tenor_y: "tenor y", pd_12m: "PD 12m %", lgd: "LGD %", risk_premium_ratio: "risk-premium ratio", el_bp: "EL bp/yr", risk_premium_bp: "risk premium bp/yr", fair_bp: "fair bp", market_bp: "market bp", gap_bp: "gap bp (+ cheap)", z: "z (blank if distressed)", z_xs: "z cross-section", rv_read: "read", market_source: "market source", synthetic: "marker", as_of: "as of" };
  table("t-rv", rows, { sort: "gap_bp", cols: ["country", "rating", "fair_bp", "market_bp", "gap_bp", "z", "rv_read", "distressed", "market_source", "synthetic", "z_xs", "pd_12m", "lgd", "risk_premium_ratio", "el_bp", "risk_premium_bp", "tenor_y", "iso3", "as_of"], fmt: rvFmt, labels: rvLabels, emptyMsg: esc(RV.rv.message) });
  const g = rows.filter(r => r.gap_bp != null).sort((a, b) => b.gap_bp - a.gap_bp);
  if (!g.length) empty("p-rv", esc(RV.rv.message));
  else plot("p-rv", [{ type: "bar", orientation: "h", y: g.map(r => esc(`${r.country}${r.synthetic ? " (SYNTHETIC)" : ""}`)), x: g.map(r => r.gap_bp),
    text: g.map(r => esc(`${gap(r.gap_bp)} bp · ${r.distressed ? "distressed" : r.rv_read}`)), textposition: g.map(r => r.gap_bp < -300 ? "inside" : "outside"), insidetextanchor: "middle", cliponaxis: false,
    marker: { color: g.map(r => r.distressed ? "#7d3c98" : /cheap/.test(r.rv_read) ? "#1e8449" : /rich/.test(r.rv_read) ? "#c0392b" : "#5d6d7e") },
    customdata: g.map(r => [fmt.n(r.fair_bp, 0), fmt.n(r.market_bp, 0), r.z == null ? "blank" : fmt.n(r.z, 2), esc(r.market_source)]),
    hovertemplate: "%{y}<br>gap %{x:.0f} bp<br>fair %{customdata[0]} bp, market %{customdata[1]} bp<br>z %{customdata[2]}<br>%{customdata[3]}<extra></extra>" }],
    { margin: { l: 150, r: 170, t: 10, b: 40 }, yaxis: { autorange: "reversed", dtick: 1, automargin: true }, xaxis: { title: "market - fair, bp (+ = cheap vs model)", zeroline: true } });
  const pos = (RV.positions.rows || []).map(p => ({ id: p.id, country: p.country, asset_class: p.asset_class, direction: p.direction, notional_mm: p.notional_mm, duration_yrs: p.duration_yrs,
    fair_bp: p.fair_bp, market_bp: p.market_bp, gap_bp: p.gap_bp, z: p.distressed ? null : p.z, for_position: p.for_position, rv_read: p.rv_read, market_source: p.market_source, synthetic: syn(p.synthetic) }));
  table("t-rv-pos", pos, { cols: ["id", "country", "asset_class", "direction", "notional_mm", "duration_yrs", "fair_bp", "market_bp", "gap_bp", "z", "for_position", "rv_read", "market_source", "synthetic"], fmt: { notional_mm: v => fmt.n(v, 1), duration_yrs: v => fmt.n(v, 1), fair_bp: bp, market_bp: bp, gap_bp: gap, z: zf },
    labels: { asset_class: "asset", notional_mm: "notional $mm", duration_yrs: "duration y", fair_bp: "fair bp", market_bp: "market bp", gap_bp: "gap bp (+ cheap)", z: "z (blank if distressed)", for_position: "for the position", rv_read: "read", market_source: "market source", synthetic: "marker" },
    emptyMsg: esc(RV.positions.message) });
  // curves
  const C = RV.curves, curves = C.curves || [];
  cs.innerHTML = line(C) + (curves.some(c => c.synthetic) ? `<p>${SYN_BADGE} <b>${esc(curves.find(c => c.synthetic).synthetic_note)}</b> Curves: ${esc(curves.filter(c => c.synthetic).map(c => c.iso3).join(", "))}.</p>` : "") +
    curves.map(c => `<span class="chip ${c.flags.length ? "warn" : "ok"}">${esc(c.iso3)} ${esc(c.snapshot_id)} as of ${esc(c.as_of)}${c.synthetic ? " · <b>SYNTHETIC</b>" : ""} · flags <b>${c.flags.length ? esc(c.flags.join(", ")) : "none"}</b></span>`).join(" ");
  if (!curves.length) { empty("p-rv-par", esc(C.message)); empty("p-rv-haz", esc(C.message)); table("t-rv-curves", [], { emptyMsg: esc(C.message) }); return; }
  const nm = c => esc(`${c.iso3} ${c.snapshot_id}${c.synthetic ? " (SYNTHETIC)" : ""}${c.flags.length ? " [flags]" : ""}`);
  const tr = (c, i, y, extra) => Object.assign({ type: "scatter", mode: "lines+markers", name: nm(c), x: c.points.map(p => p.tenor_y), y: c.points.map(y), line: { color: palette[i % palette.length], dash: c.synthetic ? "dot" : "solid" } }, extra || {});
  plot("p-rv-par", curves.map((c, i) => tr(c, i, p => p.par_spread_bp, { hovertemplate: "%{fullData.name}<br>%{x}y: %{y:.0f} bp<extra></extra>" })), { xaxis: { title: "tenor, years" }, yaxis: { title: "par spread, bp" } });
  plot("p-rv-haz", curves.map((c, i) => tr(c, i, p => p.hazard_fwd == null ? null : p.hazard_fwd * 100, { line: { shape: "hv", color: palette[i % palette.length], dash: c.synthetic ? "dot" : "solid" }, hovertemplate: "%{fullData.name}<br>to %{x}y: %{y:.2f}% / yr<extra></extra>" })), { xaxis: { title: "tenor, years" }, yaxis: { title: "forward hazard, % / yr", rangemode: "tozero" } });
  const pts = curves.flatMap(c => c.points.map(p => ({ iso3: c.iso3, snapshot_id: c.snapshot_id, as_of: c.as_of, tenor_y: p.tenor_y, quote_type: p.quote_type, quote_value: p.quote_value, par_spread_bp: p.par_spread_bp,
    hazard_fwd: p.hazard_fwd, hazard_fwd_raw: p.hazard_fwd_raw, survival: p.survival, cum_pd: p.cum_pd, fwd_pd: p.fwd_pd, reprice_error_bp: p.reprice_error_bp, flags: c.flags.join(", "), synthetic: syn(c.synthetic), source: c.source })));
  table("t-rv-curves", pts, { fmt: { tenor_y: v => fmt.n(v, 1), quote_value: v => fmt.n(v, 2), par_spread_bp: bp, hazard_fwd: fmt.pct, hazard_fwd_raw: fmt.pct, survival: fmt.pct1, cum_pd: fmt.pct1, fwd_pd: fmt.pct1, reprice_error_bp: v => fmt.n(v, 2) },
    labels: { iso3: "ISO3", snapshot_id: "snapshot", as_of: "as of", tenor_y: "tenor y", quote_type: "quote type", quote_value: "quote (bp or points)", par_spread_bp: "par spread bp", hazard_fwd: "fwd hazard %/yr", hazard_fwd_raw: "raw fwd hazard %/yr", survival: "survival %", cum_pd: "cum PD %", fwd_pd: "fwd PD %", reprice_error_bp: "reprice error bp", synthetic: "marker" },
    emptyMsg: esc(C.message) });
}

// ---------- trade ideas (EQ-C-0047): /api/ideas, every string through esc() or table() ----------
let IDEAS = null;
async function ideas() {
  IDEAS = await tryJSON("/api/ideas");
  const st = $("#i-status");
  if (!IDEAS) { st.innerHTML = `<div class="empty">Trade-idea view unavailable (the server did not answer /api/ideas).</div>`; empty("p-ideas", "No data."); table("t-ideas-q", []); return; }
  const tag = { ok: "OK", empty: "EMPTY", missing: "NO LOG", invalid: "UNREADABLE" }[IDEAS.status] || String(IDEAS.status).toUpperCase();
  const col = IDEAS.status === "ok" ? "t-green" : IDEAS.status === "invalid" ? "t-red" : "t-amber";
  st.innerHTML = `<p><b class="${col}">[${esc(tag)}]</b> ${esc(IDEAS.message)}${IDEAS.run_id ? ` Newest ideas opened by run ${esc(IDEAS.run_id)} (the run chip above is the latest model run).` : ""}</p>`;
  $("#i-label").textContent = IDEAS.label || "Illustrative, Tier 3 (GOV-032).";
  $("#i-open-note").textContent = IDEAS.pnl_open_mm != null ? `Open ideas at their latest mark: P&L ${fmt.n(IDEAS.pnl_open_mm, 2)} $mm; all ideas ${fmt.n(IDEAS.pnl_total_mm, 2)} $mm. Unmarked ideas (no daily price): ${IDEAS.unmarked} of ${IDEAS.ideas}.` : "";
  const qs = IDEAS.quarters || [];
  const rows = qs.length ? qs.concat(IDEAS.total ? [IDEAS.total] : []) : [];
  table("t-ideas-q", rows, { cols: ["quarter", "opened", "closed", "closed_marked", "hit_rate", "pnl_mm", "open_end"],
    fmt: { opened: v => fmt.n(v, 0), closed: v => fmt.n(v, 0), closed_marked: v => fmt.n(v, 0), open_end: v => fmt.n(v, 0), hit_rate: v => v == null ? "n/a" : fmt.pct1(v), pnl_mm: v => v == null ? "n/a" : fmt.n(v, 2) },
    labels: { opened: "ideas opened", closed: "ideas closed", closed_marked: "closed and marked", hit_rate: "hit rate", pnl_mm: "P&L realised $mm", open_end: "open at quarter end" },
    emptyMsg: IDEAS.status === "missing" ? "No trade-idea log yet. Data &amp; jobs &gt; Update trade-idea log from the latest run (or econquest ideas log)." : IDEAS.status === "invalid" ? "The trade-idea log could not be read." : "No ideas logged yet." });
  if (!qs.length) { empty("p-ideas", IDEAS.status === "missing" ? "No trade-idea log yet." : "No ideas to chart."); return; }
  const pnl = qs.map(r => r.pnl_mm ?? 0);
  plot("p-ideas", [{ type: "bar", x: qs.map(r => esc(r.quarter)), y: pnl, marker: { color: pnl.map(v => v < 0 ? "#c0392b" : "#1e8449") },
    text: qs.map(r => esc(`${fmt.n(r.pnl_mm ?? 0, 2)} · hit ${r.hit_rate == null ? "n/a" : fmt.pct1(r.hit_rate)}`)), textposition: "outside",
    customdata: qs.map(r => [r.opened, r.closed, r.open_end]), hovertemplate: "%{x}<br>P&L realised %{y:.2f} $mm<br>opened %{customdata[0]}, closed %{customdata[1]}, open at end %{customdata[2]}<extra></extra>" }],
    { yaxis: { title: "$mm (illustrative)", zeroline: true }, margin: { l: 60, r: 20, t: 20, b: 40 } });
}

// ---------- events (EQ-C-0038): /api/events, every string through esc() or table() ----------
let EVENTS = null;
async function events() {
  EVENTS = await tryJSON("/api/events");
  const st = $("#e-status");
  if (!EVENTS) { st.innerHTML = `<div class="empty">Event view unavailable (the server did not answer /api/events).</div>`; empty("p-events", "No data."); table("t-events-heat", []); return; }
  const tag = { missing: "NO FEED", invalid: "NO FEED", stale: "STALE", ok: "OK" }[EVENTS.status] || String(EVENTS.status).toUpperCase();
  const col = EVENTS.status === "ok" ? "t-green" : EVENTS.status === "stale" ? "t-amber" : "t-red";
  st.innerHTML = `<p><b class="${col}">[${esc(tag)}]</b> ${esc(EVENTS.message)} ${EVENTS.reference_date ? `Reference date ${esc(EVENTS.reference_date)} (the as-of date of run ${esc(EVENTS.run_id)}).` : ""}</p>` +
    (EVENTS.sources || []).map(s => `<span class="chip ${s.stale ? "warn" : "ok"}">${esc(s.source)} <b>${esc(s.latest_week || "none")}</b> retrieved ${esc(s.retrieved || "not recorded")}${s.stale ? " · STALE" : ""}</span>`).join(" ");
  $("#e-source-note").textContent = (EVENTS.files || []).length ? "Files: " + EVENTS.files.join(", ") + ". GDELT: cite the GDELT Project (gdeltproject.org); UCDP data CC BY 4.0." : "";
  const regions = {}; (RUN.country || []).forEach(r => regions[r.country] = r.region || "");
  const fill = (sel, vals) => { const el = $(sel); el.innerHTML = `<option value="">All</option>` + [...new Set(vals)].filter(Boolean).sort().map(v => `<option value="${esc(v)}">${esc(v)}</option>`).join(""); };
  fill("#e-source", (EVENTS.rows || []).map(r => r.source)); fill("#e-region", Object.values(regions));
  const draw = () => {
    const src = $("#e-source").value, reg = $("#e-region").value, q = $("#e-filter").value.toLowerCase();
    const rows = (EVENTS.rows || []).filter(r => (!src || r.source === src) && (!reg || regions[r.country] === reg) && (!q || `${r.country} ${r.source} ${r.heat_label}`.toLowerCase().includes(q)))
      .map(r => ({ country: r.country, region: regions[r.country] || "", source: r.source, week_start: r.week_start, events: r.events, events_prev: r.events_prev, wow_change: r.wow_change, wow_pct: r.wow_pct, baseline_mean: r.baseline_mean, heat_ratio: r.heat_ratio, heat_label: r.heat_label, fatalities: r.fatalities, goldstein: r.goldstein, tone: r.tone, top_types: r.top_types, event_stress: r.event_stress, retrieved: r.retrieved, stale: r.stale ? "STALE" : "" }));
    table("t-events-heat", rows, { sort: "heat_ratio", fmt: { wow_pct: v => v == null ? "" : fmt.n(v, 0) + "%", heat_ratio: v => v == null ? "" : fmt.n(v, 2) + "x", baseline_mean: v => fmt.n(v, 1), events: v => fmt.n(v, 0), events_prev: v => fmt.n(v, 0), wow_change: v => v == null ? "" : (v > 0 ? "+" : "") + fmt.n(v, 0), fatalities: v => fmt.n(v, 0) },
      heat: { heat_ratio: [1, 3] }, labels: { week_start: "week of", events_prev: "week before", wow_change: "change", wow_pct: "change %", baseline_mean: "trailing mean", heat_ratio: "heat", heat_label: "heat label", top_types: "top event types", event_stress: "event stress (Team B)" },
      emptyMsg: EVENTS.status === "missing" || EVENTS.status === "invalid" ? "No event feed yet." : "No rows match the filter." });
    const top = rows.filter(r => r.heat_ratio != null).sort((a, b) => b.heat_ratio - a.heat_ratio).slice(0, 25);
    if (!top.length) { empty("p-events", EVENTS.status === "missing" || EVENTS.status === "invalid" ? "No event feed yet: Team A's UCDP / GDELT adapters have not written data/live/events_*.csv." : "No heat ratio to chart (fewer than 4 earlier weeks)."); return; }
    const lbl = top.map(r => esc(`${r.country} · ${r.source}`));   // Plotly reads a subset of HTML in labels: escape
    plot("p-events", [{ type: "bar", orientation: "h", y: lbl, x: top.map(r => r.heat_ratio), text: top.map(r => esc(`${r.heat_label} ${fmt.n(r.heat_ratio, 2)}x`)), textposition: "outside",
      marker: { color: top.map(r => r.heat_label === "HOT" ? "#c0392b" : r.heat_label === "ELEVATED" ? "#d68910" : "#5d6d7e") },
      customdata: top.map(r => [r.events, r.wow_change, esc(r.week_start)]), hovertemplate: "%{y}<br>heat %{x:.2f}x<br>events %{customdata[0]} (change %{customdata[1]})<br>week of %{customdata[2]}<extra></extra>" }],
      { margin: { l: 210, r: 70, t: 10, b: 40 }, yaxis: { autorange: "reversed", dtick: 1, automargin: true, tickfont: { size: 10.5 } }, xaxis: { title: "events / trailing mean (x)" },
        shapes: [{ type: "line", x0: 1, x1: 1, yref: "paper", y0: 0, y1: 1, line: { dash: "dot", color: "#888" } }, { type: "line", x0: 2, x1: 2, yref: "paper", y0: 0, y1: 1, line: { dash: "dash", color: "#c0392b" } }] });
  };
  ["#e-source", "#e-region", "#e-filter"].forEach(id => $(id).oninput = draw);
  draw();
}

// ---------- navigation ----------
const renderers = { home, overview,countries, portfolio, stress, vol, econ, markets, events, ideas, notes, rv, workbench, jobs, todo, nextpass, readiness };
const titles = { home: "Home: this morning's desk view", overview: "Overview",countries: "Countries", portfolio: "Portfolio", stress: "Stress scenarios & backtests", vol: "Volatility: GARCH(1,1)-t and DCC", econ: "Econometrics toolkit", markets: "Prediction-market arbitrage", events: "Event monitor: conflict and unrest feeds", ideas: "Trade-idea ledger (illustrative, Tier 3)", notes: "Research notes (internal research)", rv: "Relative value: bonds vs model and CDS curves (diagnostic)", workbench: "Analyst workbench", jobs: "Data & jobs", todo: "Open items: what is waiting on you", nextpass: "Mac pass: the next step", readiness: "Desk readiness: target-state scorecard" };
async function show(tab) {
  document.querySelectorAll("nav a").forEach(a => a.classList.toggle("active", a.dataset.tab === tab));
  document.querySelectorAll("section").forEach(s => s.classList.toggle("active", s.id === tab));
  $("#title").textContent = titles[tab]; location.hash = tab;
  if (!loaded[tab] || tab === "jobs" || tab === "todo" || tab === "nextpass" || tab === "readiness" || tab === "home") { try { await renderers[tab](); loaded[tab] = true; } catch (e) { console.error(e); } }
  window.dispatchEvent(new Event("resize"));
}
document.querySelectorAll("nav a").forEach(a => a.onclick = () => show(a.dataset.tab));
(async () => {
  if (typeof Plotly === "undefined") { document.body.insertAdjacentHTML("afterbegin", `<div class="plotly-missing">The bundled chart library (static/plotly.min.js) did not load; reinstall the program.</div>`); }
  await loadRun(); await loadStatus();
  const tab = location.hash.replace("#", ""); show(renderers[tab] ? tab : "home");
  setInterval(async () => { const d = await getJSON("/api/jobs"); if (d.running) { $("#chip-job").style.display = ""; $("#chip-job").className = "chip warn"; $("#chip-job").innerHTML = `running <b>${esc(d.jobs[d.jobs.length - 1].cmd)}</b>`; } }, 5000);
})();

// ---------- what-if (EQ-C-0133): POST /api/whatif, what-if only: nothing booked; every value through esc(), table() or fmt.* ----------
const WI_TRADES = [];
function whatifTrades() {
  $("#wi-trades").innerHTML = WI_TRADES.length
    ? `<p class="note">Proposed (not booked): ${WI_TRADES.map((t, i) => `${esc(i + 1)}. ${esc(t.side)} ${esc(fmt.n(t.notional_mm, 1))}mm ${esc(t.country)} ${esc(t.instrument)}`).join(" · ")}</p>`
    : `<p class="note">No trades yet. Add one or more (at most 10), then Run what-if.</p>`;
}
function whatifMsg(t, bad) { $("#wi-status").innerHTML = `<p class="note${bad ? " t-red" : ""}">${esc(t)}</p>`; }
function whatifRender(r) {
  const m = r.metrics, lbl = { var99_mm: "VaR99", es99_mm: "ES99", expected_loss_mm: "Expected loss", lvar99_mm: "L-VaR99", gross_notional_mm: "Gross notional" };
  $("#wi-note").innerHTML = `<p class="note"><b>${esc(r.note)}</b>. Mode ${esc(r.mode)}, as of ${esc(r.as_of)}. ${esc(r.same_paths_note)}. Limits: worst ${esc(r.limits.status_before)} to ${esc(r.limits.status_after)}, verdict ${esc(String(r.limits.verdict).toUpperCase())}.</p>`;
  table("t-wi-metrics", Object.keys(lbl).map(k => ({ metric: lbl[k], before: m.before[k], after: m.after[k], delta: m.delta[k], same_paths_delta: m.delta_common_paths[k] })),
    { fmt: { before: v => fmt.n(v, 2), after: v => fmt.n(v, 2), delta: v => (v > 0 ? "+" : "") + fmt.n(v, 2), same_paths_delta: v => (v > 0 ? "+" : "") + fmt.n(v, 2) } });
  table("t-wi-marginal", r.marginal, { cols: ["id", "country", "instrument", "side", "notional_mm", "marginal_var99_mm", "marginal_es99_mm", "marginal_lvar99_mm", "expected_loss_mm", "component_es99_mm", "share_of_es99"],
    fmt: { notional_mm: v => fmt.n(v, 1), marginal_var99_mm: v => fmt.n(v, 2), marginal_es99_mm: v => fmt.n(v, 2), marginal_lvar99_mm: v => fmt.n(v, 2), expected_loss_mm: v => fmt.n(v, 2), component_es99_mm: v => fmt.n(v, 2), share_of_es99: fmt.pct1 } });
  const rs = r.limits.reasons || [];
  $("#wi-reasons").innerHTML = `<p class="note"><b>${esc(String(r.limits.verdict).toUpperCase())}</b></p>` +
    (rs.length ? "<ul>" + rs.map(x => "<li>" + esc(x) + "</li>").join("") + "</ul>" : `<p class="note">No limit at a warning or breach after the trades.</p>`);
  $("#wi-empty").hidden = true; $("#wi-result").hidden = false;
  const rows = r.limits.rows.filter(x => x.changed || x.status_after !== "pass");
  table("t-wi-limits", rows, { cols: ["scope", "name", "measure", "limit", "value_before", "value_after", "utilisation_before", "utilisation_after", "status_before", "status_after", "changed"], sort: "utilisation_after",
    fmt: { limit: fmt.sig, value_before: fmt.sig, value_after: fmt.sig, utilisation_before: fmt.pct1, utilisation_after: fmt.pct1 }, emptyMsg: "Every limit passes before and after." });
}
async function whatifRun() {
  if (!WI_TRADES.length) { whatifMsg("Add at least one trade first.", true); return; }
  const btn = $("#wi-run"); btn.disabled = true; whatifMsg("Running (what-if only: nothing booked)...");
  try {
    const r = await post("/api/whatif", { trades: WI_TRADES, paths: parseInt($("#wi-paths").value, 10) || 20000, mode: $("#wi-mode").value });
    const j = await r.json();
    if (!r.ok || j.error) { whatifMsg(j.error || r.statusText, true); return; }
    whatifMsg(`Done: ${fmt.n(j.paths, 0)} paths, seed ${fmt.n(j.seed, 0)}. Nothing booked.`); whatifRender(j);
  } catch (e) { whatifMsg(String(e), true); } finally { btn.disabled = false; }
}
async function whatifTab() {
  const sel = $("#wi-country"); if (!sel.options.length && RUN) RUN.country.forEach(r => sel.add(new Option(r.country)));
  $("#wi-add").onclick = () => {
    const n = parseFloat($("#wi-notional").value);
    if (!(n > 0 && n <= 250)) { whatifMsg("Enter a notional above 0 and at most 250 $mm.", true); return; }
    if (WI_TRADES.length >= 10) { whatifMsg("At most 10 trades per what-if.", true); return; }
    WI_TRADES.push({ country: sel.value, instrument: $("#wi-instrument").value, notional_mm: n, side: $("#wi-side").value }); whatifTrades(); whatifMsg("");
  };
  $("#wi-clear").onclick = () => { WI_TRADES.length = 0; whatifTrades(); };
  $("#wi-run").onclick = whatifRun;
  whatifTrades();
}
renderers.whatif = whatifTab;
titles.whatif = "What-if trade (what-if only: nothing booked)";

// ---------- attribution (EQ-C-0139): GET /api/attribution (token, read only), component and marginal VaR99/ES99; every value through esc(), table() or fmt.* ----------
async function attributionRun() {
  const btn = $("#at-run"), st = $("#at-status"), by = $("#at-by").value === "factor" ? "factor" : "country";
  const paths = parseInt($("#at-paths").value, 10) || 20000;
  btn.disabled = true; st.innerHTML = `<p class="note">Running the base model in memory (read only)...</p>`;
  let a;
  try { a = await getAuthJSON(`/api/attribution?by=${encodeURIComponent(by)}&paths=${encodeURIComponent(paths)}`); }
  catch (e) { st.innerHTML = `<div class="empty">Attribution unavailable: ${esc(e.message)}</div>`; btn.disabled = false; return; }
  btn.disabled = false;
  if (a.error) { st.innerHTML = `<div class="empty">${esc(a.error)}</div>`; $("#t-attribution").innerHTML = ""; return; }
  const m = a.metrics || {}, c = a.checks || {};
  st.innerHTML = `<p class="note">Run ${esc(a.run_id)} · as of ${esc(a.as_of)} · ${esc(fmt.n(a.paths, 0))} paths · seed ${esc(a.seed)}. ` +
    `VaR99 ${esc(fmt.n(m.var99_mm, 2))}, ES99 ${esc(fmt.n(m.es99_mm, 2))}, EL ${esc(fmt.n(m.expected_loss_mm, 2))}, L-VaR99 ${esc(fmt.n(m.lvar99_mm, 2))} $mm. ` +
    `Components sum: ES ${esc(fmt.n(c.es_components_sum_mm, 3))}, VaR ${esc(fmt.n(c.var_components_sum_mm, 3))}. ${esc(a.note)}.</p>`;
  const rows = (a.rows || []).map(x => ({ [by]: x.label || x.name, notional_mm: x.notional_mm, expected_loss_mm: x.expected_loss_mm,
    component_var99_mm: x.component_var99_mm, component_es99_mm: x.component_es99_mm, share_of_es99: x.share_of_es99,
    marginal_var99_per_mm: x.marginal_var99_per_mm, marginal_es99_per_mm: x.marginal_es99_per_mm }));
  const n2 = v => fmt.n(v, 2), n3 = v => fmt.n(v, 3);
  table("t-attribution", rows, { sort: "component_es99_mm", emptyMsg: "No positions to attribute.",
    hide: by === "factor" ? ["notional_mm", "marginal_var99_per_mm", "marginal_es99_per_mm"] : [],
    labels: { component_var99_mm: "component VaR99", component_es99_mm: "component ES99", share_of_es99: "share of ES99",
      marginal_var99_per_mm: "marginal VaR99 per $1mm", marginal_es99_per_mm: "marginal ES99 per $1mm" },
    fmt: { notional_mm: v => fmt.n(v, 1), expected_loss_mm: n2, component_var99_mm: n2, component_es99_mm: n2, share_of_es99: fmt.pct1,
      marginal_var99_per_mm: n3, marginal_es99_per_mm: n3 } });
}
$("#at-run").addEventListener("click", attributionRun);

// ---------- calendar rehearsal (EQ-C-0147): /api/readiness calendar_rehearsal, read only (the GET never runs it); SYNTHETIC REHEARSAL label on every part; every string through esc() ----------
const CR_LABEL = "SYNTHETIC REHEARSAL, not a test result";
function calendarRehearsalHTML(c) {
  const chip = `<span class="rd-met none">${esc(CR_LABEL)}</span>`;
  if (!c || typeof c !== "object") return { status: `<div class="empty">${chip} Calendar rehearsal unavailable (the server did not answer).</div>`, table: "", findings: "" };
  if (c.status === "missing" || c.status === "unreadable" || !Array.isArray(c.job_sequence)) {
    return { status: `<div class="empty">${chip} ${esc(c.message || "No calendar rehearsal has been run yet.")} <code>${esc(c.command || "econquest calendar-rehearsal")}</code></div>`, table: "", findings: "" };
  }
  const word = c.ok === true ? "rehearsal ok" : "rehearsal problems";
  const probs = Array.isArray(c.problems) && c.problems.length ? `<ul>${c.problems.map(x => `<li>${esc(CR_LABEL)}: ${esc(x)}</li>`).join("")}</ul>` : "";
  const status = `<p>${chip} <b>${esc(word)}</b>: ${esc(c.counts_text)}; shared record untouched: ${esc(c.shared_untouched)}. File <code>${esc(c.path)}</code> (${esc(c.file_utc)}).</p>` + probs;
  const body = c.job_sequence.map(r => `<tr><td><span class="rd-met none">${esc(CR_LABEL)}</span></td><td>${esc(r.run_date)}</td><td>${esc(r.world)}</td>` +
    `<td>${esc(r.var)}</td><td>${esc(r.benchmark)}</td><td>${esc(r.ideas)}</td><td>${esc(r.exit)}</td><td>${esc(r.new_alerts || "-")}</td>` +
    `<td>${esc(r.ok === true ? "as expected" : "NOT as expected")}</td><td class="rd-wrap">${esc(r.why)}</td></tr>`).join("");
  const head = ["kind", "run date", "world", "VaR (synthetic)", "benchmark (synthetic)", "ideas (synthetic)", "job exit", "new alerts", "vs expected", "why"].map(h => `<th>${esc(h)}</th>`).join("");
  const fl = Array.isArray(c.findings) ? c.findings : [];
  const findings = fl.length ? `<h4>Findings (${esc(CR_LABEL)})</h4><ul>${fl.map(f => `<li><b>${esc(f.id)}</b> (${esc(f.owner)}): ${esc(f.title)}</li>`).join("")}</ul>` : "";
  return { status, table: `<table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>`, findings };
}

// ---------- research archive (EQ-C-0154): GET /api/archive/search (token, read only); version, corrected flag and a relative ref per hit; every value through esc() ----------
function archiveHTML(d) {
  if (!d || typeof d !== "object" || !Array.isArray(d.results)) return { status: `<div class="empty">Archive search unavailable.</div>`, table: "" };
  const status = `<p class="note">${esc(d.message)} · backend ${esc(d.backend)} · showing ${esc(d.count)} of ${esc(d.total)}</p>`;
  if (!d.results.length) return { status, table: `<div class="empty">${esc(d.status === "empty" ? "The archive is empty." : "No archived version matches.")}</div>` };
  const head = ["item", "version", "corrected", "licence", "period", "snippet"].map(h => `<th>${esc(h)}</th>`).join("");
  const body = d.results.map(r => `<tr><td class="rd-wrap"><b>${esc(r.title)}</b><br><span class="note">${esc(r.product_label)} · ${esc(r.ref)}</span></td>` +
    `<td>v${esc(r.version)} of ${esc(r.latest_version)}</td><td>${esc(r.corrected ? "CORRECTED " + String(r.corrected_on || "").slice(0, 10) : "no")}${esc(r.superseded ? " · superseded" : "")}</td>` +
    `<td>${esc(r.licence)}</td><td>${esc(r.period)}</td><td class="rd-wrap">${esc(r.snippet)}</td></tr>`).join("");
  return { status, table: `<table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>` };
}
async function archiveSearch() {
  const ps = new URLSearchParams({ q: $("#ar-q").value, product: $("#ar-product").value, country: $("#ar-country").value,
    from: $("#ar-from").value, to: $("#ar-to").value, latest: $("#ar-latest").checked ? "1" : "0" });
  let d;
  try { d = await getAuthJSON("/api/archive/search?" + ps.toString()); } catch (e) { $("#ar-status").innerHTML = `<div class="empty">Archive search failed: ${esc(e.message)}</div>`; $("#ar-results").innerHTML = ""; return; }
  const h = archiveHTML(d);
  $("#ar-status").innerHTML = h.status; $("#ar-results").innerHTML = h.table;
}
$("#ar-go").addEventListener("click", archiveSearch);
$("#ar-q").addEventListener("keydown", e => { if (e.key === "Enter") archiveSearch(); });

// ---------- event calendar (EQ-C-0155): GET /api/events-calendar (token, read only) and the Home card from /api/morning events; ALERT_FIELDS only; every value through esc() ----------
function calendarRowsHTML(rows, alert) {
  if (!Array.isArray(rows) || !rows.length) return "";
  const head = ["date", "in", "country", "type", "importance", "title", "status", "source", "client use"].map(h => "<th>" + esc(h) + "</th>").join("");
  const body = rows.map(r => "<tr><td>" + esc(r.date) + esc(r.date_end && r.date_end !== r.date ? " to " + r.date_end : "") + "</td>" +
    "<td class=\"num\">" + esc(r.days_until === 0 ? "under way" : r.days_until + " days") + "</td><td>" + esc(r.iso3) + "</td><td>" + esc(r.kind_label) + "</td>" +
    "<td>" + esc(r.importance + " " + r.importance_label) + esc(alert ? " · ALERT" : "") + "</td><td class=\"rd-wrap\">" + esc(r.title) + "</td><td>" + esc(r.status) + "</td>" +
    "<td>" + esc(r.source_id) + "</td><td>" + esc(r.client_output) + "</td></tr>").join("");
  return `<table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>`;
}
function calendarAlertsHTML(al) {
  if (!al || !al.count) return `<p class="note">${esc("No event alert: nothing of importance " + (al && al.min_importance) + " or above in the next " + (al && al.window_days) + " days.")}</p>`;
  const rows = calendarRowsHTML(al.items, true);
  return `<p><b>${esc(al.count + " event alert(s)")}</b> ${esc("(importance " + al.min_importance + " or above, next " + al.window_days + " days)")}</p>${rows}`;
}
function calendarListHTML(msgs) {
  const items = (Array.isArray(msgs) ? msgs : []).filter(Boolean).map(m => "<li>" + esc(m) + "</li>").join("");
  return items ? `<ul>${items}</ul>` : "";
}
function calendarHTML(d) {
  if (!d || typeof d !== "object" || !Array.isArray(d.rows)) return { status: `<div class="empty">${esc((d && d.error) || "Event calendar unavailable.")}</div>`, table: "", types: "" };
  const alerts = calendarAlertsHTML(d.alerts), rows = calendarRowsHTML(d.rows, false);
  const status = `<p class="note">${esc(d.message + " Today " + d.today + ".")}</p>${alerts}`;
  const table = rows || `<div class="empty">${esc("No event in the next " + d.days + " days for this filter.")}</div>`;
  const types = calendarListHTML((d.by_type || []).filter(b => b && b.message).map(b => b.label + ": " + b.message));
  return { status, table, types };
}
function calendarHomeHTML(ev) {
  if (!ev || typeof ev !== "object") return `<div class="empty">${esc("Upcoming events unavailable.")}</div>`;
  const alerts = calendarAlertsHTML(ev.alerts), rows = calendarRowsHTML(ev.items, false);
  const more = ev.more ? `<p class="note">${esc(ev.more + " more on the Events tab.")}</p>` : "";
  const empties = calendarListHTML((ev.empty_types || []).map(e => e && e.message));
  return `<p class="note">${esc(ev.message)}</p>${alerts}${rows}${more}${empties}`;
}
async function calendarLoad() {
  const ps = new URLSearchParams({ days: $("#ec-days").value, type: $("#ec-type").value, min_importance: $("#ec-imp").value, country: $("#ec-country").value.trim() });
  let d;
  try { d = await getAuthJSON("/api/events-calendar?" + ps.toString()); } catch (e) { d = { error: "Event calendar unavailable: " + e.message }; }
  const h = calendarHTML(d);
  $("#ec-status").innerHTML = h.status; $("#ec-table").innerHTML = h.table; $("#ec-types").innerHTML = h.types;
}
$("#ec-go").addEventListener("click", calendarLoad);
const calendarHeatTab = renderers.events;
renderers.events = async () => { try { await calendarLoad(); } finally { await calendarHeatTab(); } };

// ---------- country heatmap (EQ-C-0156): GET /api/heatmap (token, read only; never runs the model); the run's pillar scores unchanged, depth values only for status value, M19 depth panels; every value through esc() or fmt.* ----------
const HM_BANDS = ["low", "moderate", "elevated", "high", "severe"];
const hmBand = b => HM_BANDS.includes(b) ? b : "none";
function hmDepthText(c) {
  if (!c || typeof c !== "object") return "";
  if (c.shown && c.status === "value") return fmt.n(c.value, c.unit === "probability" ? 2 : 1) + (c.internal ? " INTERNAL" : "");
  return String(c.status || "").replace(/_/g, " ");
}
function heatmapHTML(d) {
  if (!d || typeof d !== "object" || !Array.isArray(d.rows)) return { status: `<div class="empty">${esc((d && d.error) || "Heatmap unavailable.")}</div>`, legend: "", table: "", countries: [] };
  const pillars = (d.groups || []).flatMap(g => g.pillars || []);
  const dcols = d.depth_columns || [];
  const g1 = (d.groups || []).map(g => `<th colspan="${esc((g.pillars || []).length)}">${esc(g.label)}</th>`).join("");
  const top = `<tr><th rowspan="2">${esc("country")}</th>${g1}<th colspan="${esc(dcols.length)}">${esc("Depth (research views, display only)")}</th></tr>`;
  const sub = "<tr>" + pillars.map(p => "<th>" + esc(p.id + " " + p.name) + "</th>").join("") + dcols.map(m => "<th>" + esc(m.label) + "</th>").join("") + "</tr>";
  const body = d.rows.map(r => {
    const cells = pillars.map(p => { const b = hmBand((r.bands || {})[p.id]); return `<td class="hm-c hm-${esc(b)}" title="${esc(p.name + ": " + b)}">${esc(fmt.n((r.pillars || {})[p.id], 1))} <small>${esc(b)}</small></td>`; }).join("");
    const deps = dcols.map(m => { const c = (r.depth || {})[m.metric] || {}; return `<td class="num" title="${esc(c.note || "")}">${esc(hmDepthText(c))}</td>`; }).join("");
    return `<tr><th><button type="button" class="secondary" data-hm="${esc(r.country)}">${esc(r.country)}</button></th>${cells}${deps}</tr>`;
  }).join("");
  const legend = (d.legend || []).map(b => `<li><span class="hm-${esc(hmBand(b.band))}"></span> ${esc(b.band + ": " + b.from + " to " + b.to)}</li>`).join("");
  const status = `<p class="note">${esc(d.message)}</p><p class="note">${esc((d.depth || {}).message)}</p>`;
  return { status, legend, table: `<table class="hm"><thead>${top}${sub}</thead><tbody>${body}</tbody></table>`, countries: d.rows.map(r => r.country) };
}
function hmList(items, line, emptyMsg) {
  const li = (Array.isArray(items) ? items : []).map(x => "<li>" + line(x) + "</li>").join("");
  return li ? `<ul>${li}</ul>` : `<p class="note">${esc(emptyMsg)}</p>`;
}
function drillHTML(x) {
  if (!x || typeof x !== "object" || !x.drivers) return `<div class="empty">${esc("Drill-down unavailable.")}</div>`;
  const dr = x.drivers;
  const drivers = hmList(dr.pillars, p => esc(p.id + " " + p.name + ": " + fmt.n(p.score, 1) + " (" + p.band + ")"), "No pillar scores.") +
    (dr.top_signals ? `<p>${esc("Top signals: " + dr.top_signals)}</p>` : "") +
    hmList(dr.layer1_features, f => esc(f.name.replace(/_/g, " ") + ": " + fmt.sig(f.value)), "") + `<p class="note">${esc(dr.note)}</p>`;
  const nt = x.notes || {};
  const notes = hmList(nt.notes, n => `<button type="button" class="secondary" data-note="${esc(n.id)}">${esc(n.title)}</button> ${esc(n.state)}`, "") +
    hmList(nt.archive, a => esc("Archive " + a.ref + ": " + a.title + (a.corrected ? " (corrected)" : "")), nt.message || "");
  const ev = x.events || {};
  const events = `<p class="note">${esc(ev.message)}</p>` + hmList(ev.rows, e => esc(e.date + " · " + e.kind_label + " · " + e.title), "");
  const st = x.statements || {};
  const stmts = hmList(st.items, s => esc(String(s.published_utc || "").slice(0, 10) + " · " + s.source + " · " + s.title + (s.label ? " · " + s.label : "")), st.message || "No recent statements.") + `<p class="note">${esc(st.note || "")}</p>`;
  const depth = (x.depth || []).map(p => `<details><summary>${esc(p.view + " (" + p.kind + "): " + (p.rows || []).length + " rows")}</summary>` +
    hmList(p.rows, c => esc(c.metric + (c.year ? " " + c.year : "") + ": " + hmDepthText(c) + (c.unit ? " " + c.unit : "") + " · " + c.status + (c.label ? " · " + c.label : "") + (c.note ? " · " + c.note : "")), p.message || "") + "</details>").join("") ||
    `<p class="note">${esc(x.depth_message || "No depth rows.")}</p>`;
  return `<h3>${esc(x.country + " (" + x.iso + ")")}</h3><h4>${esc("Drivers")}</h4>${drivers}<h4>${esc("Country note")}</h4>${notes}` +
    `<h4>${esc("Upcoming events")}</h4>${events}<h4>${esc("Recent statements")}</h4>${stmts}<h4>${esc(x.depth_label || "Research views, display only")}</h4>${depth}`;
}
function depthPageHTML(p) {
  if (!p || typeof p !== "object" || !Array.isArray(p.panels)) return `<div class="empty">${esc((p && p.error) || "Depth views unavailable.")}</div>`;
  if (!p.panels.length) return `<div class="empty">${esc(p.message)}</div>`;
  const panels = p.panels.map(v => {
    const counts = Object.entries(v.status_counts || {}).map(([k, n]) => esc(k.replace(/_/g, " ") + " " + n)).join(", ");
    const routes = hmList(v.routes, r => (r.internal ? "<b>INTERNAL</b> " : "") + esc(r.route + " (" + r.rows + " rows)"), "");
    const notes = hmList(v.notes, n => esc(n.status.replace(/_/g, " ") + ": " + n.note + " (" + n.rows + ")"), "");
    const tag = v.internal ? " <b>INTERNAL</b>" : "", cs = counts ? " · " + counts : "";
    return `<div class="card"><h4>${esc(v.view.replace(/_/g, " ") + " · " + v.kind)}${tag}</h4><p>${esc(v.rows + " rows, " + v.countries + " names")}${cs}</p>${routes}${notes}</div>`;
  }).join("");
  return `<p><b>${esc(p.label)}</b> ${esc(p.message)}</p><div class="grid">${panels}</div>`;
}
let HM_LAST = null;
async function heatmapLoad(country) {
  const ps = new URLSearchParams({ client: $("#hm-client").checked ? "1" : "0" });
  if (country) ps.set("country", country);
  let d;
  try { d = await getAuthJSON("/api/heatmap?" + ps.toString()); } catch (e) { d = { error: "Heatmap unavailable: " + e.message }; }
  const h = heatmapHTML(d);
  $("#hm-status").innerHTML = h.status; $("#hm-legend").innerHTML = h.legend; $("#hm-table").innerHTML = h.table;
  const sel = $("#hm-country"), cur = country || sel.value;
  sel.innerHTML = `<option value="">${esc("Choose a country")}</option>` + h.countries.map(c => `<option value="${esc(c)}">${esc(c)}</option>`).join("");
  sel.value = cur || "";
  $("#hm-table").querySelectorAll("button[data-hm]").forEach(b => b.addEventListener("click", () => heatmapLoad(b.dataset.hm)));
  if (country) {
    $("#hm-drill").innerHTML = drillHTML(d && d.drill);
    $("#hm-drill").querySelectorAll("button[data-note]").forEach(b => b.addEventListener("click", async () => { await show("notes"); showNote(b.dataset.note); }));
  }
  HM_LAST = d;
}
async function heatmapTab() {
  await heatmapLoad("");
  let p;
  try { p = await getAuthJSON("/api/heatmap?view=depth&client=" + ($("#hm-client").checked ? "1" : "0")); } catch (e) { p = { error: "Depth views unavailable: " + e.message }; }
  $("#hm-depth").innerHTML = depthPageHTML(p);
}
$("#hm-country").addEventListener("input", () => { const c = $("#hm-country").value; if (c) heatmapLoad(c); });
$("#hm-client").addEventListener("input", () => { loaded.heatmap = false; heatmapTab(); });
renderers.heatmap = heatmapTab;
titles.heatmap = "Country risk heatmap: geopolitical, sovereign and macro pillars";

// ---------- start here (EQ-C-0135): static guided tour, read only; no fetch, no interpolation, buttons only switch tab ----------
function startTab() {
  document.querySelectorAll("#start [data-goto]").forEach(b => { b.onclick = () => { if (renderers[b.dataset.goto]) show(b.dataset.goto); }; });
}
renderers.start = startTab;
titles.start = "Start here: what each tab is for";

// ---------- analyst overlay (EQ-C-0161): GET /api/overlay (token, read only, INTERNAL); model value, overlay delta and overlaid value in separate columns beside the model, never in its place; card hidden while off; every value through esc() or fmt.* ----------
function overlayHTML(d) {
  if (!d || typeof d !== "object" || d.enabled !== true) return null;
  if (d.error || !Array.isArray(d.rows)) return { status: `<div class="empty">${esc(d.error || "Analyst overlay unavailable.")}</div>`, table: "" };
  const v = d.verify || {};
  const status = `<p><b>${esc(d.banner)}</b></p><p class="note">${esc("run " + d.run_id + " · data " + d.data_hash + " · as of " + d.as_of + " · ledger " + (v.ok ? "verifies" : "FAILS verification") + " (" + v.rows + " events) · " + d.info)}</p>`;
  if (!d.rows.length) return { status, table: `<div class="empty">${esc("No active overlay entry for this run and date.")}</div>` };
  const head = ["country", "row", "pillar", "model value", "overlay delta", "overlaid value", "author", "approver", "self-approved / EXC", "reason", "expires", "run / data hash"].map(h => `<th>${esc(h)}</th>`).join("");
  const body = d.rows.map(r => `<tr><td>${esc(r.country)}</td><td>${esc(r.row)}</td><td>${esc(r.pillar_name || r.pillar)}</td>` +
    `<td class="num">${esc(fmt.n(r.model_value, 2))}</td><td class="num">${esc(fmt.n(r.overlay_delta, 2))}</td><td class="num">${esc(fmt.n(r.overlaid_value, 2))}</td>` +
    `<td>${esc(r.author)}</td><td>${esc(r.approver)}</td><td>${esc(r.self_approved ? "yes · " + r.exc_id : "no")}</td><td class="rd-wrap">${esc(r.reason)}</td>` +
    `<td>${esc(r.expires)}</td><td>${esc(r.run_id + " · " + r.data_hash)}</td></tr>`).join("");
  return { status, table: `<table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>` };
}
async function overlayLoad() {
  let d;
  try { d = await getAuthJSON("/api/overlay"); } catch (e) { d = { enabled: true, error: "Analyst overlay unavailable: " + e.message }; }
  const h = overlayHTML(d), card = $("#ov-card");
  if (!h) { card.hidden = true; $("#ov-status").innerHTML = ""; $("#ov-table").innerHTML = ""; return; }
  $("#ov-status").innerHTML = h.status; $("#ov-table").innerHTML = h.table; card.hidden = false;
}
const overlayCountriesTab = renderers.countries;
renderers.countries = async () => { try { await overlayCountriesTab(); } finally { await overlayLoad(); } };

// ---------- backtest explainer (EQ-C-0166, HO-20261026-B-C-018): /api/readiness interim_backtest.explainer, read only (the GET never runs it); INTERIM label on every part; an unreconciled day is never shown as the explanation of the recorded loss; every value through esc() or fmt.* ----------
function bxTable(head, rows) {
  const h = head.map(x => `<th>${esc(x)}</th>`).join("");
  const b = rows.map(r => "<tr>" + r.map(c => `<td>${esc(typeof c === "number" ? fmt.n(c, 4) : (c == null ? "n/a" : c))}</td>`).join("") + "</tr>").join("");
  return `<table><thead><tr>${h}</tr></thead><tbody>${b}</tbody></table>`;
}
function backtestExplainerHTML(x) {
  const chip = `<span class="rd-met none">INTERIM</span>`;
  if (!x || typeof x !== "object") return `<div class="empty">${chip} Backtest explainer unavailable.</div>`;
  if (x.status !== "ok" || !Array.isArray(x.exceptions)) return `<div class="empty">${chip} ${esc(x.message || "No backtest explainer output yet.")} <code>${esc(x.command || "econquest backtest-explain --as-of YYYY-MM-DD")}</code></div>`;
  const lab = esc(x.label || "INTERIM, not the formal test");
  const parts = [`<p>${chip} <b>${esc(x.message)}</b> Source <code>${esc(x.source)}</code>. The record holds the book totals only: every attribution is a reconstruction on today's inputs.</p>`];
  x.exceptions.forEach(e => {
    const b = e.book || {}, r = e.residual;
    const badge = e.reconciled === true ? `<span class="rd-met yes">reconciled</span>` : `<span class="rd-met no">NOT RECONCILED</span>`;
    const rows = [["recorded (the record)", b.recorded_loss_mm, b.recorded_var99_mm, null], ["reconstructed (today's inputs)", b.reconstructed_loss_mm, b.reconstructed_var99_mm, b.reconstructed_es99_mm]];
    if (r) rows.push(["residual: " + String(r.item || ""), r.loss_mm, r.var99_mm, r.es99_mm]);
    parts.push(`<h5>Exception ${esc(e.date)} ${badge} <span class="chip">inputs_status: <b>${esc(e.inputs_status)}</b></span></h5><p><b>${esc(e.headline)}</b></p>` +
      bxTable(["row", "loss $mm", "VaR99 $mm", "ES99 $mm"], rows) + `<p class="note">${esc(e.label)}</p>`);
    [["countries", e.top_countries], ["factors", e.top_factors]].forEach(([k, xs]) => {
      if (Array.isArray(xs) && xs.length) parts.push(`<p><i>${esc(e.contributors_heading)}: ${esc(k)}</i></p>` +
        bxTable(["rank", "item", "realised loss $mm", "component VaR99 $mm", "excess over VaR $mm"], xs.map(c => [c.rank, c.item, c.realised_loss_mm, c.forecast_var99_mm, c.excess_over_var_mm])));
    });
  });
  const ro = x.rolling || {};
  parts.push(`<p><b>Rolling backtests</b> (${lab}). Labels: ${esc((ro.labels || []).join("; "))}</p>`);
  (ro.lines || []).forEach(l => {
    const last = a => (Array.isArray(a) && a.length ? a[a.length - 1] : {});
    const q1 = last(l.recorded), q2 = last(l.reconstructed);
    parts.push(bxTable(["book, window " + String(l.window_text), "end date", "n", "exceptions", "expected", "95% band", "band status"],
      [["recorded line (latest)", q1.end_date, q1.n, q1.exceptions, q1.expected, String(q1.band_low) + "-" + String(q1.band_high), q1.band_status],
       ["reconstructed line (latest)", q2.end_date, q2.n, q2.exceptions, q2.expected, String(q2.band_low) + "-" + String(q2.band_high), q2.band_status]]));
  });
  if (Array.isArray(ro.counts) && ro.counts.length) parts.push(`<p><i>Exception counts against the band, window ${esc(ro.count_window_text)}</i></p>` +
    bxTable(["group", "item", "n", "exceptions", "expected", "95% band", "band status"], ro.counts.map(c => [c.group_type, c.group, c.n, c.exceptions, c.expected, String(c.band_low) + "-" + String(c.band_high), c.band_status])));
  const pn = x.pnl || {};
  parts.push(`<p><b>P&amp;L attribution: recorded vs explained</b> (${lab}): ${esc(pn.summary_text)}</p>` +
    bxTable(["date", "recorded loss $mm", "explained $mm", "unexplained $mm", "explained share"], (pn.days || []).map(q => [q.date, q.recorded_loss_mm, q.explained_mm, q.unexplained_mm, q.explained_share])));
  parts.push(`<p><b>Gaps</b> (Team B, verbatim)</p><ul>${(Array.isArray(x.gaps) ? x.gaps : []).map(g => `<li>${esc(g)}</li>`).join("")}</ul><p class="note">${lab}. Not a formal test result.</p>`);
  return parts.join("");
}

// ---------- assistant (EQ-C-0172): POST /api/assistant/ask and /api/assistant/draft (token + JSON, the write guard of every POST); the Home "In plain words" card from /api/morning plain_words; only the QA gate's text, shown as plain text through esc() (no markdown, URLs never become links); sources as source_id text ----------
const asText = t => String(t ?? "").split("\n").map(l => esc(l)).join("<br>");
function asSourcesHTML(xs) {
  if (!Array.isArray(xs) || !xs.length) return "";
  return `<p class="note"><b>Sources</b></p><ul>${xs.map(s => `<li><code>${esc(s.source_id || s.cite_id)}</code>${s.row ? " " + esc(s.row) : ""}${s.as_of ? " · as of " + esc(s.as_of) : ""}${s.provenance ? ` <span class="note">${esc(s.provenance)}</span>` : ""}</li>`).join("")}</ul>`;
}
function assistantHTML(d) {
  if (!d || typeof d !== "object") return `<div class="empty">${esc("The assistant did not answer.")}</div>`;
  if (d.error) return `<div class="empty">${esc(d.error)}</div>`;
  if (d.enabled === false || d.status === "off") return `<div class="empty">${esc(d.text || "Assistant off.")}</div>`;
  const head = d.ok ? "" : `<p class="note-warn"><b>${esc(d.status === "refused" ? "Withheld by the QA gate" : "Assistant error")}</b></p>`;
  return head + `<p>${asText(d.text)}</p>` + (d.ok ? asSourcesHTML(d.sources) : "") +
    `<p class="note">${esc("backend " + (d.backend || "n/a") + (d.model ? " · model " + d.model : "") + (d.verdict ? " · QA gate " + d.verdict : ""))}</p>`;
}
function plainWordsHTML(pw) {
  if (!pw || typeof pw !== "object") return null;                  // assistant off: the card stays hidden
  return assistantHTML(Object.assign({}, pw, { enabled: true }));
}
let AS_RETRY = null;
async function assistantAsk(retry) {
  const q = $("#as-q").value.trim(); if (!q) return;
  const body = { question: q }; const c = $("#as-country").value.trim(); if (c) body.country = c;
  if (retry && AS_RETRY) body.retry_codes = AS_RETRY;
  $("#as-retry").hidden = true;
  $("#as-out").innerHTML = `<div class="empty">${esc("Working… the whole answer is checked by the QA gate before anything is shown.")}</div>`;
  let d;
  try { const r = await post("/api/assistant/ask", body); d = await r.json(); } catch (e) { d = { error: "Assistant request failed: " + e.message }; }
  $("#as-out").innerHTML = assistantHTML(d);
  AS_RETRY = d && d.retry_allowed && !retry && Array.isArray(d.retry_codes) ? d.retry_codes : null;   // one retry, never more
  $("#as-retry").hidden = !AS_RETRY;
}
$("#as-go").addEventListener("click", () => assistantAsk(false));
$("#as-retry").addEventListener("click", () => assistantAsk(true));
$("#as-q").addEventListener("keydown", e => { if (e.key === "Enter") assistantAsk(false); });
let DR_ID = "";
const drStatus = (msg, warn) => { $("#dr-status").innerHTML = `<p class="${warn ? "note-warn" : "note"}">${esc(msg)}</p>`; };
async function drPost(body) {
  try { const r = await post("/api/assistant/draft", body); return await r.json(); } catch (e) { return { error: "Draft request failed: " + e.message }; }
}
async function drList() {
  const d = await drPost({ action: "list" });
  if (!d || !Array.isArray(d.drafts)) return d;
  $("#dr-list").innerHTML = `<option value="">Open a draft…</option>` + d.drafts.map(x => `<option value="${esc(x.id)}">${esc(x.id + " v" + x.version + " · " + x.state)}</option>`).join("");   // EQ-C-0176: archive DRAFT / SIGNED
  return d;
}
async function drOpen(id) {
  if (!id) return;
  const d = await drPost({ action: "load", id });
  if (!d || d.error) return drStatus((d && d.error) || "Draft not found.", true);
  DR_ID = d.id; $("#dr-text").value = d.text;                      // textarea value: the slot text, never parsed as HTML
  $("#dr-rendered").innerHTML = "";
  drStatus(d.id + " v" + d.version + " · " + d.state + (d.signed ? " · signed by " + d.signed.by + " on " + d.signed.at : "") + " · " + d.label);
}
$("#dr-new").addEventListener("click", async () => {
  const country = $("#dr-country").value.trim(); if (!country) return drStatus("Name a country first.", true);
  drStatus("Drafting… the whole draft is checked by the QA gate before it is saved.");
  const d = await drPost({ action: "create", country, by: $("#dr-by").value.trim() });
  if (!d || d.error) return drStatus((d && d.error) || "Draft failed.", true);
  if (d.enabled === false || !d.ok) return drStatus(d.text || "Draft not saved.", !(d.enabled === false));
  DR_ID = d.id; $("#dr-text").value = d.source || ""; $("#dr-rendered").innerHTML = assistantHTML({ ok: true, status: "saved", text: d.text });
  drStatus(d.message); drList();
});
$("#dr-mark").addEventListener("click", () => {                   // HO-20261027-B-C-005: the analyst-entered marker
  const t = $("#dr-text"), mark = "[[analyst-entered: TEXT | source: CITATION]]", at = t.selectionStart ?? t.value.length;
  t.value = t.value.slice(0, at) + mark + t.value.slice(at);
});
$("#dr-load").addEventListener("click", () => drOpen($("#dr-list").value));
$("#dr-save").addEventListener("click", async () => {
  if (!DR_ID) return drStatus("Open or create a draft first.", true);
  const d = await drPost({ action: "save", id: DR_ID, text: $("#dr-text").value, by: $("#dr-by").value.trim(), reason: $("#dr-reason").value.trim() });
  if (!d || d.error) return drStatus((d && d.error) || "Not saved.", true);
  if (d.text) $("#dr-rendered").innerHTML = assistantHTML({ ok: d.status !== "refused", status: d.status, text: d.text });
  else $("#dr-rendered").innerHTML = "";
  if (d.status === "refused") return drStatus("Not saved: the QA gate refused the edit; your text stays in the editor.", true);
  drStatus(d.status + ": " + d.id + " v" + d.version); drList();
});
$("#dr-sign").addEventListener("click", () => {                   // SEC-C-027: the GUI never signs; the CLI does
  if (!DR_ID) return drStatus("Open or create a draft first.", true);
  drStatus("Sign from the command line (the research QA gate and the archive run there): econquest assistant sign " + DR_ID + " --by NAME");
});
async function assistantHome(d) {
  const pw = plainWordsHTML(d && d.plain_words), card = $("#h-plain-card");
  if (pw === null) { card.hidden = true; $("#h-plain").innerHTML = ""; } else { $("#h-plain").innerHTML = pw; card.hidden = false; }
  const l = await drList();
  if (l && l.enabled === false && !AS_RETRY) $("#as-out").innerHTML = `<div class="empty">${esc(l.message || "Assistant off.")}</div>`;
}

// ---------- MVP+ rows (EQ-C-0136): M11-M13 from /api/readiness mvp.plus, apart from M1-M10; status word as text; every string through esc() ----------
function mvpPlusHTML(m) {
  const p = m && m.plus;
  if (!p || !Array.isArray(p.rows) || !p.rows.length) return { status: `<div class="empty">${esc((p && p.message) || "No MVP+ rows yet.")}</div>`, table: "" };
  const status = `<p><b>${esc(p.message)}</b></p>`;
  const body = p.rows.map(r => {
    const cls = Object.prototype.hasOwnProperty.call(MVP_CLASS, r.status) ? MVP_CLASS[r.status] : "none";
    return `<tr><td><b>${esc(r.id)}</b></td><td class="rd-wrap">${esc(r.title)}</td><td><span class="rd-met ${esc(cls)}">${esc(r.status)}</span></td>` +
      `<td class="rd-wrap">${esc(r.reason)}</td><td class="rd-wrap">${esc(r.evidence)}</td><td>${esc(r.run_utc)}</td></tr>`;
  }).join("");
  const head = ["#", "criterion", "status", "reason", "evidence", "run (UTC)"].map(h => `<th>${esc(h)}</th>`).join("");
  return { status, table: `<table><thead><tr>${head}</tr></thead><tbody>${body}</tbody></table>` };
}

// ---------- CSP styles (EQ-C-0165): no style attributes, so the page's CSP has no 'unsafe-inline' for styles.
// Markup uses classes (gui.html <style>, allowed by its sha256); the only computed sizes go through CSSOM here, which
// CSP does not restrict, and only as clamped numbers: a progress fill's width comes from data-w (0-100).
function cspApplyWidths(root) {
  (root || document).querySelectorAll("[data-w]").forEach(el => {
    const w = Number(el.dataset.w);
    el.style.width = (Number.isFinite(w) ? Math.max(0, Math.min(100, w)) : 0) + "%";
  });
}
["#chip-job", "#w-msg"].forEach(id => { const el = document.querySelector(id); if (el) el.style.display = "none"; });
cspApplyWidths(document);
new MutationObserver(muts => muts.forEach(m => m.addedNodes.forEach(n => { if (n.nodeType === 1) { if (n.dataset && n.dataset.w !== undefined) cspApplyWidths(n.parentNode); else cspApplyWidths(n); } })))
  .observe(document.body, { childList: true, subtree: true });
