"""Calendar rehearsal page (EQ-C-0147, HO-20261026-B-C-007): the readiness view's "SYNTHETIC REHEARSAL, not a test
result" section, built from Team B's rehearsal file (validation.calendar_rehearsal, EQ-B-0131).

    econquest calendar-rehearsal [--out DIR] [--no-scheduled] [--json]   runs Team B's rehearsal, writes the file, prints the page
    GET /api/readiness  "calendar_rehearsal"                              reads <out>/calendar_rehearsal/rehearsal.json only
    demo_calendar_page(out_dir) -> {"ok", "problems", "summary"}          demo row M16 (EQ-C-0148)

The file is `<out>/calendar_rehearsal/rehearsal.json` (schema_version 1, kind "REHEARSAL"). The page shows "rehearsal ok"
or the problems, the hand-check counts, the job sequence and the findings. Everything it returns carries LABEL; the
rehearsal runs on SYNTHETIC data in a temporary home and is never a test result, so no status word here is a verdict.

rehearsal_page() never runs the rehearsal and never writes: a GET only reads the file. When the file is missing the
page is an empty state with one plain sentence. Paths on the page are relative to the outputs folder; nothing absolute.
"""
from __future__ import annotations

import datetime as dt
import json
from pathlib import Path

LABEL = "SYNTHETIC REHEARSAL, not a test result"
KIND = "REHEARSAL"
SCHEMA_VERSION = 1
SUBDIR = "calendar_rehearsal"
FILE = "rehearsal.json"
COMMAND = "econquest calendar-rehearsal"
SEQ_FIELDS = ("run_date", "world", "var", "benchmark", "ideas", "exit", "new_alerts", "expected_var",
              "expected_benchmark", "expected_ideas", "expected_exit", "expected_new_alerts", "ok", "why")
SUMMARY_FIELDS = ("checks", "checks_ok", "sequence", "sequence_ok", "scheduled", "scheduled_ok")
MAX_PROBLEMS, MAX_TEXT = 50, 300
EMPTY_TEXT = (f"No calendar rehearsal has been run yet, so there is nothing to show; {COMMAND} makes one on synthetic "
              f"data and this page then reads its file.")


def rehearsal_path(out_dir) -> Path:
    return Path(out_dir) / SUBDIR / FILE


def _s(v, n=MAX_TEXT) -> str:
    return "" if v is None else str(v)[:n]


def _int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return None


def _base(out_dir) -> dict:
    return {"kind": KIND, "label": LABEL, "command": COMMAND,
            "path": f"{Path(out_dir).name or 'outputs'}/{SUBDIR}/{FILE}", "ok": None, "problems": [], "summary": {},
            "job_sequence": [], "findings": [], "shared_untouched": None, "file_utc": None}


def rehearsal_page(out_dir) -> dict:
    """Read-only payload of the rehearsal section. status: "ok" | "problems" (the rehearsal's own problems) | "missing"
    (no file: empty state) | "unreadable" (bad JSON, wrong kind or schema_version). Never runs the rehearsal."""
    out = _base(out_dir)
    p = rehearsal_path(out_dir)
    if not p.is_file():
        return out | {"status": "missing", "message": f"{LABEL}. {EMPTY_TEXT}"}
    try:
        d = json.loads(p.read_text(encoding="utf-8"))
        out["file_utc"] = dt.datetime.fromtimestamp(p.stat().st_mtime, dt.timezone.utc).isoformat(timespec="seconds")
    except (OSError, ValueError) as e:
        return out | {"status": "unreadable", "message": f"{LABEL}. The rehearsal file could not be read "
                                                         f"({type(e).__name__}); run {COMMAND} again."}
    if not isinstance(d, dict) or d.get("kind") != KIND or d.get("schema_version") != SCHEMA_VERSION:
        got = (d.get("kind"), d.get("schema_version")) if isinstance(d, dict) else (type(d).__name__, None)
        return out | {"status": "unreadable", "message": f"{LABEL}. The rehearsal file is not kind {KIND} schema_version "
                                                         f"{SCHEMA_VERSION} (got {_s(got, 80)}); run {COMMAND} again."}
    summ = d.get("summary") if isinstance(d.get("summary"), dict) else {}
    summary = {k: _int(summ.get(k)) for k in SUMMARY_FIELDS}
    home = str(Path(out_dir).resolve().parent)          # no absolute path on the page
    problems = [_s(x).replace(home, "") for x in (d.get("problems") or []) if x is not None][:MAX_PROBLEMS]
    seq = [{k: (r.get(k) if k in ("ok", "exit", "expected_exit") else _s(r.get(k))) for k in SEQ_FIELDS} | {"kind": LABEL}
           for r in (d.get("job_sequence") or []) if isinstance(r, dict)]
    findings = [{k: _s(f.get(k)) for k in ("id", "owner", "title")} for f in (d.get("findings") or []) if isinstance(f, dict)]
    ok = d.get("ok") is True and not problems
    counts = (f"{summary['checks_ok']} of {summary['checks']} hand checks, {summary['sequence_ok']} of "
              f"{summary['sequence']} job runs, {summary['scheduled_ok']} of {summary['scheduled']} scheduled runs as "
              f"expected")
    word = "rehearsal ok" if ok else f"rehearsal problems ({len(problems)})"
    msg = f"{LABEL}: {word}; {counts}; shared record untouched: {d.get('shared_untouched')}."
    return out | {"status": "ok" if ok else "problems", "ok": ok, "problems": problems, "summary": summary,
                  "counts_text": counts, "job_sequence": seq, "findings": findings,
                  "shared_untouched": d.get("shared_untouched"), "message": msg}


def rehearsal_text(p: dict) -> str:
    L = [f"Calendar rehearsal ({LABEL})", f"  {p.get('message', '')}"]
    if p.get("status") in ("missing", "unreadable"):
        return "\n".join(L) + "\n"
    for x in p.get("problems") or []:
        L.append(f"  problem: {x}")
    L.append(f"  job sequence ({LABEL}): run date, world, VaR / benchmark / ideas, exit, new alerts, as expected")
    for r in p.get("job_sequence") or []:
        L.append(f"    {r['run_date']} {r['world']:<4} {r['var']} / {r['benchmark']} / {r['ideas']}  exit {r['exit']}  "
                 f"alerts {r['new_alerts'] or '-'}  {'as expected' if r['ok'] else 'NOT as expected'}")
    L.append("  findings:")
    L += [f"    {f['id']} ({f['owner']}): {f['title']}" for f in p.get("findings") or []]
    L.append(f"  file: {p.get('path')} ({p.get('file_utc')}). All data SYNTHETIC; {LABEL}.")
    return "\n".join(L) + "\n"


def run_rehearsal(out_dir, scheduled: bool = True) -> dict:
    """The CLI path: run Team B's rehearsal (writes <out>/calendar_rehearsal/), then read the page back from the file."""
    from ..validation.calendar_rehearsal import demo_calendar_rehearsal
    demo_calendar_rehearsal(out_dir, scheduled=scheduled)
    return rehearsal_page(out_dir)


def demo_calendar_page(out_dir, scheduled: bool = True) -> dict:
    """Demo row M16 (EQ-C-0148): run Team B's demo_calendar_rehearsal, then check the page renders from the file it
    wrote. {"ok", "problems", "summary"}; never raises on a failed check."""
    problems: list[str] = []
    try:
        from ..validation.calendar_rehearsal import demo_calendar_rehearsal
        res = demo_calendar_rehearsal(out_dir, scheduled=scheduled)
    except Exception as e:                               # noqa: BLE001 - reported, never a silent pass
        msg = f"demo_calendar_rehearsal raised {type(e).__name__}: {e}"[:MAX_TEXT]
        return {"ok": False, "problems": [msg], "summary": f"{LABEL}: rehearsal did not run ({msg})"}
    problems += [f"rehearsal: {_s(x)}" for x in res.get("problems") or []]
    page = rehearsal_page(out_dir)
    text = rehearsal_text(page)
    if page["status"] not in ("ok", "problems"):
        problems.append(f"page: status {page['status']} ({page['message']})")
    else:
        if page["summary"] != {k: _int((res.get("summary") or {}).get(k)) for k in SUMMARY_FIELDS}:
            problems.append("page: summary differs from the rehearsal's")
        if len(page["job_sequence"]) != len(res.get("job_sequence") or []):
            problems.append("page: job sequence row count differs from the rehearsal's")
        if page["ok"] != bool(res.get("ok")):
            problems.append("page: ok differs from the rehearsal's")
        if not all(r.get("kind") == LABEL for r in page["job_sequence"]):
            problems.append("page: a job sequence row is not labelled")
    if LABEL not in page.get("message", "") or LABEL not in text:
        problems.append(f"page: label {LABEL!r} missing")
    s = page.get("summary") or {}
    summary = (f"{LABEL}: page rendered from {page['path']} ({page['status']}); "
               + (page.get("counts_text") or "no counts") + f"; {len(page.get('findings') or [])} findings"
               + (f"; {len(problems)} problems" if problems else "") + (f" [sequence {s.get('sequence_ok')}/{s.get('sequence')}]" if s else ""))
    return {"ok": not problems, "problems": problems, "summary": summary}
