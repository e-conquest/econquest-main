"""Country notes v2 sections (EQ-C-0082): DSA paths and signal, nowcast, geopolitical risk (GPR) and shadow rating.

Every section reads a stored model output and is skipped cleanly with a house-style "not available" note when the
file is absent (most of these models ship OFF, so absence is the normal case):

    dsa_paths   outputs/dsa_paths.csv + outputs/dsa_signal.csv + outputs/dsa_paths_meta.json   (contract C13, eq-dsa-paths/1)
    nowcast     outputs/nowcast/*.csv (engine.nowcast LOG_COLUMNS: as_of, iso3, target, quarter, method, nowcast, ar_benchmark ...)
    gpr         the run's gpr_global (stored on every run) and, when Team B stores it, per-country event GPR
                (run["gpr_country"] rows or outputs/gpr_country.csv: country, event_score, z_events, percentile_events, gpr_source_used)
    shadow      outputs/shadow_rating.csv (country, iso, as_of, shadow_rating, agency_rating, notch_gap; engine/shadow_ratings.py)

gpr_country.csv and shadow_rating.csv are single files overwritten on each run, so only rows whose as_of equals the run's
as_of are shown; otherwise the section says "not run for this date" (HO-20261025-B-C-003 item 1).

Formatting only: charts reuse country_note.svg_fan / svg_hbars; numbers are printed as stored and every section names
its file and sha256. Text from the files (country, method, rating labels) is escaped.
"""
from __future__ import annotations

import glob
import hashlib
import json
from pathlib import Path

import pandas as pd

from .house_style import not_available, not_available_plain
from .report import _e, _f, _signed

V2_IDS = ("dsa_paths", "nowcast", "gpr", "shadow")
PCTS = (10, 25, 50, 75, 90)


def _sha(p: Path) -> str | None:
    try:
        return hashlib.sha256(p.read_bytes()).hexdigest()
    except OSError:
        return None


def _csv(p: Path) -> pd.DataFrame | None:
    try:
        return pd.read_csv(p) if p.exists() else None
    except (pd.errors.EmptyDataError, pd.errors.ParserError, OSError, UnicodeDecodeError):
        return None


def _src(*files: tuple[str, str | None]) -> str:
    return "<p class='note'>Source: " + "; ".join(f"{_e(n)} sha256 <code>{_e((h or 'n/a')[:16])}</code>" for n, h in files) + ".</p>"


def load(outputs_dir, run: dict) -> dict:
    out = Path(outputs_dir)
    v = {}
    for key, name in (("paths", "dsa_paths.csv"), ("signal", "dsa_signal.csv"), ("shadow", "shadow_rating.csv"), ("gpr_csv", "gpr_country.csv")):
        p = out / name
        v[key], v[key + "_sha"] = _csv(p), _sha(p) if p.exists() else None
    mp = out / "dsa_paths_meta.json"
    try:
        v["meta"] = json.loads(mp.read_text(encoding="utf-8")) if mp.exists() else None
    except (OSError, ValueError):
        v["meta"] = None
    frames, files = [], []
    for f in sorted(glob.glob(str(out / "nowcast" / "*.csv"))):
        df = _csv(Path(f))
        if df is not None and {"as_of", "iso3", "target", "quarter", "nowcast"} <= set(df.columns):
            frames.append(df); files.append((f"nowcast/{Path(f).name}", _sha(Path(f))))
    v["nowcast"], v["nowcast_files"] = (pd.concat(frames, ignore_index=True) if frames else None), files
    v["gpr_global"] = run.get("gpr_global") if isinstance(run.get("gpr_global"), dict) else None
    rows = run.get("gpr_country")
    v["gpr_rows"] = pd.DataFrame(rows) if isinstance(rows, list) and rows else v["gpr_csv"]
    return v


def _rows(df: pd.DataFrame | None, country: str, iso: str | None, iso_col: str = "iso") -> pd.DataFrame | None:
    if df is None:
        return None
    if "country" in df.columns:
        sel = df[df["country"].astype(str) == country]
        if len(sel):
            return sel
    if iso and iso_col in df.columns:
        sel = df[df[iso_col].astype(str).str.upper() == str(iso).upper()]
        if len(sel):
            return sel
    return df.iloc[0:0]


def _for_run_date(rows: pd.DataFrame, run_as_of: str | None) -> tuple[pd.DataFrame | None, str]:
    """HO-20261025-B-C-003 item 1: gpr_country.csv and shadow_rating.csv are single files overwritten on each run, so keep
    only rows whose as_of equals the run's as_of. Returns (rows, why); rows is None when nothing is for this date."""
    if run_as_of is None or not str(run_as_of).strip():
        return rows, ""
    if "as_of" not in rows.columns:
        return None, "the file has no as_of column, so it cannot be matched to this run"
    want = str(run_as_of)[:10]
    sel = rows[rows["as_of"].astype(str).str[:10] == want]
    if len(sel):
        return sel, ""
    seen = ", ".join(sorted({str(x)[:10] for x in rows["as_of"]}))
    return None, f"not run for this date (the run is as of {want}; the stored rows are as of {seen})"


def dsa_paths_html(country: str, iso: str | None, v: dict, run_as_of: str | None) -> str:
    from .country_note import svg_fan, svg_hbars
    f = _rows(v["paths"], country, iso)
    if f is None:
        return not_available_plain("DSA paths: not available for this run (the debt-path output was not produced).",
                                   "no outputs/dsa_paths.csv (eq-dsa-paths/1, contract C13).")
    if not len(f):
        return not_available("DSA paths chart", f"outputs/dsa_paths.csv has no rows for {country}")
    fan = pd.DataFrame({"year": f["year"]})
    for p in PCTS:
        if f"debt_p{p}" in f.columns:
            fan[f"p{p}"] = pd.to_numeric(f[f"debt_p{p}"], errors="coerce")
    if "debt_weo" in f.columns:
        fan["baseline_weo"] = pd.to_numeric(f["debt_weo"], errors="coerce")
    html = svg_fan(fan.dropna())
    gfn = [c for c in ("gfn_p10", "gfn_p50", "gfn_p90") if c in f.columns]
    if gfn:
        html += ("<table class='compact'><tr><th>Year</th>" + "".join(f"<th class='n'>GFN {c[4:]} % GDP</th>" for c in gfn) + "</tr>" + "".join(
            "<tr><td>" + _e(int(r["year"])) + "</td>" + "".join(f"<td class='n'>{_f(r[c])}</td>" for c in gfn) + "</tr>"
            for _, r in f.sort_values("year").iterrows()) + "</table>")
    s = _rows(v["signal"], country, iso)
    if s is not None and len(s):
        r = s.iloc[0]
        html += svg_hbars([("P(debt above threshold)", _num(r.get("p_debt_above_threshold"))), ("P(GFN above threshold)", _num(r.get("p_gfn_above_threshold")))],
                          vmax=1.0, fmt=lambda x: f"{x * 100:.1f}%", aria="DSA signal probabilities")
        html += (f"<p class='note'>DSA signal as of {_e(r.get('as_of'))}: debt {_f(r.get('debt_now'))}% of GDP now, median {_f(r.get('debt_p50_end'))}% and "
                 f"90th percentile {_f(r.get('debt_p90_end'))}% at the horizon (threshold {_f(r.get('debt_threshold'), 0)}%); GFN peak {_f(r.get('gfn_baseline_peak'))}% "
                 f"(90th {_f(r.get('gfn_p90_peak'))}%, threshold {_f(r.get('gfn_threshold'), 0)}%); DSA score {_f(r.get('dsa_score'), 2)}; r-g {_f(r.get('r_minus_g_baseline'), 2)} pp.</p>")
        if run_as_of and str(r.get("as_of"))[:10] != str(run_as_of)[:10]:
            html += f"<p class='note'><span class='tag stale'>STALE</span> DSA paths as of {_e(r.get('as_of'))}, the run is as of {_e(run_as_of)}.</p>"
    else:
        html += not_available("DSA signal", "outputs/dsa_signal.csv is absent or has no row for this country")
    meta = v.get("meta") or {}
    html += (f"<p class='note'>Schema {_e(meta.get('schema', 'n/a'))}, {_e(meta.get('paths', 'n/a'))} paths, seed {_e(meta.get('seed', 'n/a'))}. "
             "Bands 10-90th and 25-75th percentile of simulated debt; dashed line: WEO debt (IMF data, internal research use only).</p>")
    return html + _src(("outputs/dsa_paths.csv", v["paths_sha"]), ("outputs/dsa_signal.csv", v["signal_sha"]))


def _num(x):
    try:
        y = float(x)
    except (TypeError, ValueError):
        return None
    return y if y == y and abs(y) != float("inf") else None


def nowcast_html(country: str, iso: str | None, v: dict, run_as_of: str | None) -> str:
    from .country_note import svg_hbars
    df = v["nowcast"]
    if df is None:
        return not_available_plain("Nowcast: not available for this run (the nowcasting model is off by default).",
                                   "no outputs/nowcast/*.csv.")
    d = df[df["iso3"].astype(str).str.upper() == str(iso or "").upper()].copy()
    if run_as_of:
        d = d[d["as_of"].astype(str).str[:10] <= str(run_as_of)[:10]]
    if not len(d):
        return not_available("Nowcast chart", f"no nowcast for {country} on or before the run's as-of date")
    last = d["as_of"].astype(str).max()
    d = d[d["as_of"].astype(str) == last].sort_values(["target", "quarter"])
    bars = []
    for r in d.itertuples():
        bars.append((f"{r.target} {r.quarter} nowcast", _num(r.nowcast)))
        bars.append((f"{r.target} {r.quarter} AR benchmark", _num(getattr(r, "ar_benchmark", None))))
    vals = [abs(b) for _, b in bars if b is not None]
    html = svg_hbars(bars, vmax=max(vals) if vals else 1.0, unit="%", fmt=lambda x: f"{x:.2f}", aria="Nowcast against AR benchmark")
    html += ("<table class='compact'><tr><th>Target</th><th>Quarter</th><th>Horizon</th><th>Method</th><th class='n'>Nowcast %</th><th class='n'>AR benchmark %</th><th class='n'>Indicators</th></tr>" + "".join(
        f"<tr><td>{_e(r.target)}</td><td>{_e(r.quarter)}</td><td>{_e(getattr(r, 'horizon', ''))}</td><td>{_e(getattr(r, 'method_used', getattr(r, 'method', '')))}</td>"
        f"<td class='n'>{_f(r.nowcast, 2)}</td><td class='n'>{_f(getattr(r, 'ar_benchmark', None), 2)}</td><td class='n'>{_e(getattr(r, 'n_indicators', ''))}</td></tr>"
        for r in d.itertuples()) + "</table>")
    html += f"<p class='note'>Nowcast as of {_e(last)} (research module, does not feed the PDs).</p>"
    return html + _src(*v["nowcast_files"])


def gpr_html(country: str, iso: str | None, v: dict, run_as_of: str | None = None) -> str:
    from .country_note import svg_hbars
    g = v["gpr_global"]
    if not g:
        html = not_available("Global GPR chart", "the run stores no gpr_global (no data/gpr_monthly.csv when it ran)")
    else:
        m, sd = _num(g.get("mean5y")), _num(g.get("sd5y"))
        html = svg_hbars([("GPR recent (3m)", _num(g.get("recent"))), ("5-year mean", m), ("5-year mean + 1 sd", None if m is None or sd is None else m + sd)],
                         fmt=lambda x: f"{x:.0f}", aria="Global geopolitical risk index")
        html += (f"<p class='note'>Global GPR (Caldara-Iacoviello), latest month {_e(g.get('latest_month'))}: z {_f(g.get('z'), 2)}, percentile {_f(g.get('percentile'), 0)}, "
                 f"threats/acts {_f(g.get('threats_acts_ratio'), 2)}, signal {_f(g.get('signal'), 0)}. Source: the archived run (gpr_global).</p>")
    rows = _rows(v["gpr_rows"], country, iso)
    from_csv = v["gpr_csv"] is not None and v["gpr_rows"] is v["gpr_csv"]
    why = ""
    if rows is not None and len(rows) and from_csv:          # rows stored on the run itself are that run's; the CSV may be older
        rows, why = _for_run_date(rows, run_as_of)
    if rows is None and why:
        html += not_available("Country event GPR", f"outputs/gpr_country.csv: {why}")
    elif rows is None:
        html += not_available_plain("Country event GPR: not available for this run (no country event scores were produced).",
                                    "no outputs/gpr_country.csv and the run stores no gpr_country rows.")
    elif not len(rows):
        html += not_available("Country event GPR", f"no event GPR row for {country}")
    else:
        r = rows.iloc[0]
        html += svg_hbars([("Event GPR percentile", _num(r.get("percentile_events")))], vmax=100.0, fmt=lambda x: f"{x:.0f}", aria="Country event GPR percentile")
        html += (f"<p class='note'>Event GPR score {_f(r.get('event_score'), 2)}, z {_f(r.get('z_events'), 2)}; source used {_e(r.get('gpr_source_used'))}.</p>"
                 + (_src(("outputs/gpr_country.csv", v["gpr_csv_sha"])) if v["gpr_csv"] is not None and v["gpr_rows"] is v["gpr_csv"] else ""))
    return html


def shadow_html(country: str, iso: str | None, v: dict, run_as_of: str | None = None) -> str:
    from .country_note import svg_hbars
    rows = _rows(v["shadow"], country, iso)
    if rows is None:
        return not_available_plain("Shadow rating: not available for this run (the shadow-rating model has not produced output yet).",
                                   "no outputs/shadow_rating.csv.")
    if not len(rows):
        return not_available("Shadow rating chart", f"outputs/shadow_rating.csv has no row for {country}")
    rows, why = _for_run_date(rows, run_as_of)
    if rows is None:
        return not_available("Shadow rating chart", f"outputs/shadow_rating.csv: {why}")
    r = rows.iloc[0]
    gap = _num(r.get("notch_gap"))
    html = svg_hbars([("Shadow minus agency (notches)", None if gap is None else abs(gap))], vmax=6.0, fmt=lambda x: f"{x:.0f}", aria="Shadow rating notch gap")
    html += (f"<p class='note'>Shadow rating <b>{_e(r.get('shadow_rating'))}</b> against agency rating <b>{_e(r.get('agency_rating'))}</b>: "
             f"{_signed(gap, 0)} notches (as of {_e(r.get('as_of'))}).</p>")
    return html + _src(("outputs/shadow_rating.csv", v["shadow_sha"]))


def sections(country: str, iso: str | None, v: dict, run_as_of: str | None) -> list[tuple[str, str, str]]:
    return [("dsa_paths", "Debt paths and DSA signal", dsa_paths_html(country, iso, v, run_as_of)),
            ("nowcast", "Nowcast: GDP and CPI", nowcast_html(country, iso, v, run_as_of)),
            ("gpr", "Geopolitical risk (GPR)", gpr_html(country, iso, v, run_as_of)),
            ("shadow", "Shadow rating", shadow_html(country, iso, v, run_as_of))]
