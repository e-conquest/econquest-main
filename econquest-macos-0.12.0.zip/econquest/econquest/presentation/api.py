"""JSON REST + SSE server on the standard library (FastAPI is used automatically when installed).

Endpoints
  GET  /                       dashboard page for the latest run
  GET  /api/runs               run history
  GET  /api/run/latest         full latest run (country table, positions, arbitrage, loss histogram)
  GET  /api/countries          posterior risk table
  GET  /api/portfolio          portfolio metrics and contributions
  GET  /api/arbitrage          arbitrage monitor
  GET  /api/series?metric=var99_mm[&country=Argentina]   time series across runs
  POST /api/workbench          {"analyst": {"Argentina": {"4": 5}}, "paths": 20000, "scenario": "Model"} -> rerun with
                               pillar adjustments (Interactive Pillar Adjustment Workbench) and publish to subscribers
  GET  /events                 Server-Sent Events: a summary on connect and after every workbench run
"""
from __future__ import annotations
import dataclasses
import hmac
import json
import queue
import secrets
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from urllib.parse import urlparse, parse_qs
from ..config import Settings
from ..ingestion import load_universe, Universe
from ..engine import run_pipeline
from ..engine.pipeline import dumps
from ..engine.layer2_bayesian import publish_guard
from ..persistence import Store
from .csp import style_sources
from .dashboard import render_dashboard
from .mc_band import load_book_limits


class Hub:
    def __init__(self):
        self.subs: list[queue.Queue] = []; self.lock = threading.Lock()

    def subscribe(self) -> queue.Queue:
        q = queue.Queue()
        with self.lock:
            self.subs.append(q)
        return q

    def publish(self, event: str, data: dict):
        with self.lock:
            for q in list(self.subs):
                q.put((event, data))


class App:
    def __init__(self, data_dir: str, store_dir: str):
        self.data_dir = data_dir; self.store = Store(store_dir); self.hub = Hub()
        self.token = secrets.token_urlsafe(32)   # per-process; a write request must echo it (see Handler._guard)
        self.settings = Settings.load(Path(data_dir) / "assumptions.json")
        self.universe: Universe = load_universe(data_dir)
        self.latest = self.store.latest("base") or self.store.latest()
        if self.latest is None:
            self.rerun({})

    def rerun(self, body: dict) -> dict:
        u = self.universe
        adj = u.adjustments.copy()
        for country, pillars in (body.get("analyst") or {}).items():
            for pillar, pts in pillars.items():
                mask = (adj["block"] == "Analyst adjustment") & (adj["pillar"].astype(int) == int(pillar))
                adj.loc[mask, country] = float(pts)
        # replace only the adjustments: every other Universe field (weo_raw, prices, ...) must reach the rerun unchanged
        u2 = dataclasses.replace(u, adjustments=adj)
        s = self.settings
        if body.get("scenario"):
            s = s.copy_with(); s.scenario_override = body["scenario"]
        res = run_pipeline(u2, s, label=body.get("label", "workbench" if body else "base"), paths=int(body.get("paths", 20000)) if body else None,
                           market_dir=self.data_dir)                       # HO-20261025-B-C-006
        publish_guard(res.country)       # HO-20261025-B-C-006: ValueError before the run is saved or served
        self.store.save_run(res, keep_paths=False)
        self.latest = res.to_dict()
        self.hub.publish("run", self.latest["summary"])
        return self.latest


def sse_frame(event: str, data) -> bytes:
    """One Server-Sent Events frame. The payload must sit on a single `data:` line: `dumps` indents its JSON, and a
    multi-line payload would reach an EventSource client as just its first line. Raw newlines cannot occur inside a
    JSON string (they are escaped), so joining the lines keeps the document intact."""
    return f"event: {event}\ndata: {''.join(dumps(data).splitlines())}\n\n".encode()


LOCAL_HOSTS = ("127.0.0.1", "localhost", "[::1]")
TOKEN_HEADER = "X-EconQuest-Token"


def content_security_policy(nonce: str | None = None, style: str | None = None) -> str:
    """Strict CSP for every HTML page this server sends (EQ-C-0125, SEC-C-020). Scripts load only from this origin or
    carry the per-response nonce; never 'unsafe-inline' or 'unsafe-eval'. Styles (EQ-C-0165, SEC-C-020 I1): 'self'
    plus the sha256 of each <style> block and style attribute of the exact body sent (`csp.style_sources`), never
    'unsafe-inline'. No framing, plugins, <base> or off-site form posts."""
    script = "'self'" + (f" 'nonce-{nonce}'" if nonce else "")
    return ("default-src 'self'; "
            f"script-src {script}; script-src-attr 'none'; "
            f"style-src {style or chr(39) + 'self' + chr(39)}; "
            "img-src 'self' data: blob:; font-src 'self'; connect-src 'self'; "
            "object-src 'none'; base-uri 'none'; form-action 'self'; frame-ancestors 'none'")


SECURITY_HEADERS = {"X-Content-Type-Options": "nosniff", "X-Frame-Options": "DENY", "Referrer-Policy": "no-referrer"}


def make_handler(app: App):
    class H(BaseHTTPRequestHandler):
        def _security_headers(self, ctype: str, nonce: str | None = None, body: str | None = None):
            for k, v in SECURITY_HEADERS.items():
                self.send_header(k, v)
            if ctype.startswith("text/html"):                  # every HTML response carries the CSP (EQ-C-0125)
                style = style_sources(body) if body is not None else None      # hashes of this body (EQ-C-0165)
                self.send_header("Content-Security-Policy", content_security_policy(nonce, style))

        def _send(self, code: int, body: str, ctype="application/json", nonce: str | None = None):
            # No Access-Control-Allow-Origin: other web pages must not read or drive this local server.
            data = body.encode()
            self.send_response(code); self.send_header("Content-Type", ctype); self.send_header("Content-Length", str(len(data)))
            self._security_headers(ctype, nonce, body)
            self.send_header("Cache-Control", "no-store"); self.end_headers(); self.wfile.write(data)

        def _guard(self, write: bool, token: bool = False) -> bool:
            """Refuse requests that did not come from this app's own page. Every request must name a loopback Host
            (blocks DNS rebinding). A write must also carry a JSON content type (forces a CORS preflight, which this
            server never approves), a same-origin Origin when the browser sends one, and the per-process token that only
            the served page knows. A read with token=True (research notes, EQ-C-0127) needs the same Origin and token
            checks, but no content type. Returns False after sending 403."""
            port = self.server.server_address[1]
            allowed = {f"{h}:{port}" for h in LOCAL_HOSTS}
            reason = None
            if self.headers.get("Host", "") not in allowed:
                reason = "host not allowed"
            elif write or token:
                origin = self.headers.get("Origin")
                if origin is not None and origin.removeprefix("http://") not in allowed:
                    reason = "cross-origin request refused"
                elif write and not self.headers.get("Content-Type", "").startswith("application/json"):
                    reason = "content type must be application/json"
                elif not hmac.compare_digest(self.headers.get(TOKEN_HEADER, ""), app.token):
                    reason = "missing or wrong session token"
            if reason:
                self._send(403, dumps({"error": reason}))
                return False
            return True

        def do_GET(self):
            if not self._guard(write=False):
                return
            p = urlparse(self.path); qs = parse_qs(p.query); L = app.latest
            if p.path == "/":
                return self._send(200, render_dashboard(L, limits=load_book_limits(app.data_dir)), "text/html; charset=utf-8")   # EQ-C-0055
            if p.path == "/api/runs":
                return self._send(200, dumps(app.store.runs()))
            if p.path == "/api/run/latest":
                return self._send(200, dumps(L))
            if p.path == "/api/countries":
                return self._send(200, dumps(L["country"]))
            if p.path == "/api/portfolio":
                return self._send(200, dumps({"metrics": L["summary"]["metrics"], "contributions": L["contributions"], "by_country": L["by_country"], "loss_quantiles": L["loss_quantiles"]}))
            if p.path == "/api/arbitrage":
                return self._send(200, dumps(L["arbitrage"]))
            if p.path == "/api/series":
                df = app.store.series(qs.get("metric", ["var99_mm"])[0], qs.get("country", [None])[0])
                return self._send(200, df.to_json(orient="records"))
            if p.path == "/events":
                self.send_response(200); self.send_header("Content-Type", "text/event-stream"); self._security_headers("text/event-stream"); self.send_header("Cache-Control", "no-cache"); self.end_headers()
                q = app.hub.subscribe()
                self.wfile.write(sse_frame("run", L["summary"])); self.wfile.flush()
                try:
                    while True:
                        try:
                            ev, data = q.get(timeout=15)
                            self.wfile.write(sse_frame(ev, data))
                        except queue.Empty:
                            self.wfile.write(b": keepalive\n\n")
                        self.wfile.flush()
                except (BrokenPipeError, ConnectionResetError):
                    return
            self._send(404, dumps({"error": "not found"}))

        def do_POST(self):
            if not self._guard(write=True):
                return
            p = urlparse(self.path)
            n = int(self.headers.get("Content-Length", 0))
            try:
                body = json.loads(self.rfile.read(n) or b"{}")
            except (ValueError, RecursionError):           # SEC-C-017 L3 (EQ-C-0165): deep nesting is a 400 too
                return self._send(400, dumps({"error": "body is not valid JSON"}))
            if not isinstance(body, dict):
                return self._send(400, dumps({"error": "body must be a JSON object"}))
            if p.path == "/api/workbench":
                try:
                    res = app.rerun(body)
                except ValueError as e:                    # publish_guard refused (HO-20261025-B-C-006): nothing served
                    if not str(e).startswith("refusing to publish"):
                        raise
                    return self._send(409, dumps({"error": str(e)}))
                return self._send(200, dumps(res["summary"]))
            self._send(404, dumps({"error": "not found"}))

        def log_message(self, *a):  # quiet
            pass
    return H


def serve(data_dir: str, store_dir: str, host: str = "127.0.0.1", port: int = 8080):
    app = App(data_dir, store_dir)
    try:
        import fastapi  # noqa: F401
        print("FastAPI is installed; the standard-library server is used here, swap in fastapi_app(app) for ASGI deployment.")
    except ImportError:
        pass
    srv = ThreadingHTTPServer((host, port), make_handler(app))
    print(f"EconQuest API on http://{host}:{port}  (dashboard at /, SSE at /events)")
    print(f"POST requests must send header {TOKEN_HEADER}: {app.token}")
    srv.serve_forever()
