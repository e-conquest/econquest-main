"""Risk attribution view (EQ-C-0139, HO-20261025-B-C-018): component and marginal VaR99 / ES99 of the base run by
country or by risk factor, from Team B's engine.portfolio_risk.attribution (EQ-B-0114, Euler allocation; the
components sum to the run's VaR99 / ES99). Read-only: it runs the base pipeline in memory and never writes the store,
the latest run or data/. `econquest attribution` and GET /api/attribution use the same `collect`.

Schema eq-attribution/1: schema, note, as_of, run_id, seed, paths_requested, paths, by, metrics, rows, checks, method.
Rows (by country): name, notional_mm, expected_loss_mm, component_var99_mm, component_es99_mm, share_of_es99,
marginal_var99_per_mm, marginal_es99_per_mm (Euler: component / notional, $mm per $1mm). By factor the marginal
columns are null (a factor has no notional).
"""
from __future__ import annotations
import math
import threading

from ..engine import portfolio_risk as PR
from ..engine import run_pipeline
from .whatif import DEFAULT_PATHS, MAX_PATHS, MIN_PATHS

SCHEMA = "eq-attribution/1"
NOTE = "risk attribution of the base run: read only, nothing booked; the run store and data/ are never written"
BYS = ("country", "factor")
COLS = ("notional_mm", "expected_loss_mm", "component_var99_mm", "component_es99_mm", "share_of_es99",
        "marginal_var99_per_mm", "marginal_es99_per_mm")
FACTOR_LABELS = {"market": "market move", "default": "sovereign default", "transfer_convertibility": "transfer & convertibility",
                 "expropriation": "expropriation", "political_violence": "political violence", "carry": "carry",
                 "long_cap": "long-loss cap"}       # engine.layer6_montecarlo.LEG_NAMES


def _num(v):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    return f if math.isfinite(f) else None


def validate(by=None, paths=None) -> tuple[str, int]:
    by = by or "country"
    if not isinstance(by, str) or by not in BYS:
        raise ValueError("by must be country or factor")
    if paths is None or paths == "":
        paths = DEFAULT_PATHS
    if isinstance(paths, bool) or not isinstance(paths, (int, str)) or not str(paths).strip().isdigit():
        raise ValueError("paths must be a whole number")
    paths = int(paths)
    if not MIN_PATHS <= paths <= MAX_PATHS:
        raise ValueError(f"paths must be between {MIN_PATHS} and {MAX_PATHS}")
    return by, paths


def _rows(df, by: str) -> list[dict]:
    out = []
    for name, r in df.iterrows():
        row = {"name": str(name)}
        if by == "factor":
            row["label"] = FACTOR_LABELS.get(str(name), str(name))
        for c in COLS:
            row[c] = _num(r[c]) if c in df.columns else None
        out.append(row)
    return out


def collect(universe, settings, by: str = "country", paths: int = DEFAULT_PATHS, as_of=None, market_dir=None, base=None,
            res: dict | None = None) -> dict:
    """The eq-attribution/1 payload. `base` is a RunResult made with the same `paths`; `res` a portfolio_risk.attribution
    result already computed (both optional)."""
    by, paths = validate(by, paths)
    if res is None:
        if base is None:
            base = run_pipeline(universe, settings, label="attribution", paths=paths, as_of=as_of, market_dir=market_dir)
        res = PR.attribution(universe, settings, r=base, paths=paths)
    table = res["by_country"] if by == "country" else res["by_factor"]
    return {"schema": SCHEMA, "note": NOTE, "as_of": res["as_of"], "run_id": res["run_id"], "seed": int(res["seed"]),
            "paths_requested": paths, "paths": int(res["paths"]), "by": by,
            "metrics": {k: _num(v) for k, v in res["metrics"].items()},
            "rows": _rows(table, by),
            "checks": {k: (v if isinstance(v, bool) else _num(v)) for k, v in res["checks"].items()},
            "method": "Euler allocation on the base run's Monte Carlo paths (engine.portfolio_risk, EQ-B-0114)"}


def render_text(r: dict) -> str:
    f = lambda v, d=2: "n/a" if v is None else f"{v:,.{d}f}"
    m, c = r["metrics"], r["checks"]
    lines = [f"RISK ATTRIBUTION by {r['by']} (read only): run {r['run_id']}, as of {r['as_of']}, {r['paths']:,} paths, seed {r['seed']}",
             f"  VaR99 {f(m.get('var99_mm'))}  ES99 {f(m.get('es99_mm'))}  EL {f(m.get('expected_loss_mm'))}  "
             f"L-VaR99 {f(m.get('lvar99_mm'))} $mm", "",
             f"  {r['by']:<26}{'notional':>10}{'EL':>9}{'cVaR99':>10}{'cES99':>10}{'share':>8}{'mVaR99/mm':>11}{'mES99/mm':>10}"]
    for x in r["rows"]:
        share = "n/a" if x["share_of_es99"] is None else f"{x['share_of_es99'] * 100:.1f}%"
        lines.append(f"  {x.get('label', x['name'])[:25]:<26}{f(x['notional_mm'], 1):>10}{f(x['expected_loss_mm']):>9}"
                     f"{f(x['component_var99_mm']):>10}{f(x['component_es99_mm']):>10}{share:>8}"
                     f"{f(x['marginal_var99_per_mm'], 3):>11}{f(x['marginal_es99_per_mm'], 3):>10}")
    lines += ["", f"Checks: ES components sum {f(c.get('es_components_sum_mm'), 4)} vs ES99 {f(c.get('es99_mm'), 4)}; "
                  f"VaR components sum {f(c.get('var_components_sum_mm'), 4)} vs VaR99 {f(c.get('var99_mm'), 4)} "
                  f"(VaR band scale {f(c.get('var_scale'), 3)})", NOTE]
    return "\n".join(lines)


# ---------------------------------------------------------------- GET /api/attribution (GUI)
_API_LOCK = threading.Lock()
_CACHE: dict = {}          # one entry: (id(universe), as_of, paths) -> portfolio_risk.attribution result


def handle_api(universe, settings, data_dir, query: dict) -> tuple[int, dict]:
    """GET /api/attribution?by=country|factor&paths=N&as_of=YYYY-MM-DD. The caller has applied the read guard with the
    session token (as /api/notes). Runs the base pipeline in memory on the server's universe (single flight, the last
    result cached so switching by country / factor does not rerun); never writes."""
    from .evidence_view import as_of_param
    extra = set(query) - {"by", "paths", "as_of"}
    if extra:
        return 400, {"error": f"unknown parameters {sorted(map(str, extra))[:5]}"}
    one = lambda k: (query.get(k) or [None])[0]
    try:
        by, paths = validate(one("by"), one("paths"))
        as_of = one("as_of")
        as_of = as_of_param(as_of.strip()) if as_of else None
    except ValueError as e:
        return 400, {"error": str(e)}
    key = (id(universe), as_of, paths)
    res = _CACHE.get(key)
    if res is None:
        if not _API_LOCK.acquire(blocking=False):
            return 409, {"error": "an attribution is already running; try again when it finishes"}
        try:
            base = run_pipeline(universe, settings, label="attribution", paths=paths, as_of=as_of, market_dir=str(data_dir))
            res = PR.attribution(universe, settings, r=base, paths=paths)
            _CACHE.clear(); _CACHE[key] = res
        except Exception as e:                     # noqa: BLE001 - error type only, never a path or value
            return 200, {"error": f"attribution could not be computed ({type(e).__name__})", "rows": []}
        finally:
            _API_LOCK.release()
    return 200, collect(universe, settings, by=by, paths=paths, res=res)
