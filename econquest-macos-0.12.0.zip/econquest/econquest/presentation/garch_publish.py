"""Value blocks for the GARCH tab of the workbook (same plan format as sheets_publish)."""
from __future__ import annotations

from datetime import date

import numpy as np
import pandas as pd

from .sheets_publish import _block, col_letter

TABLE_A_MIN_ROWS = 30                # v1 Table A was A5:Z34; v2 grows past 30 series and pushes Tables B-F down

SERIES_COLS = ["country", "kind", "ticker", "obs", "last_date", "alpha", "beta", "persistence", "half_life_days", "nu",
               "long_run_vol_pct", "cond_vol_pct", "fcst_1d_vol_pct", "fcst_10d_vol_pct", "fcst_21d_vol_pct", "realized_60d_vol_pct", "vol_ratio",
               "arch_lm_p_returns", "arch_lm_p_std_resid", "ljung_box_p_sq_std_resid",
               "var99_1d_pct", "es99_1d_pct", "var99_10d_pct", "exposure_mm", "var99_10d_mm", "vol_target_scalar"]
SERIES_HEAD = ["Country", "Series", "Ticker", "Obs (days)", "Last price date", "alpha", "beta", "alpha + beta", "Half-life (days)", "Student-t df",
               "Long-run vol % ann", "Conditional vol now % ann", "Forecast vol 1d % ann", "Forecast vol 10d % ann", "Forecast vol 21d % ann", "Realized vol 60d % ann", "Forecast / realized",
               "ARCH-LM p (returns)", "ARCH-LM p (std resid)", "Ljung-Box p (sq std resid)",
               "VaR99 1d % of notional", "ES99 1d % of notional", "VaR99 10d % of notional", "Book exposure $mm", "VaR99 10d $mm", "Vol-target scalar"]


def _r(x, nd=3):
    if x is None:
        return ""
    try:
        if isinstance(x, (bool, np.bool_)):
            return bool(x)
        f = float(x)
    except (TypeError, ValueError):
        return x
    if not np.isfinite(f):
        return "" if np.isnan(f) else ">1000"
    return round(f, nd)


def _equity_fallback(n: dict) -> str:
    """' Equity block not fitted (EQ-B-0077): <country>: <ticker reason>; ...' from notes["equity_fallback"]
    (HO-20261024-B-C-011); '' when every ETF was fitted, so today's text is unchanged."""
    fb = (n or {}).get("equity_fallback") or {}
    return (" Equity block not fitted (EQ-B-0077): " + "; ".join(f"{c}: {r}" for c, r in sorted(fb.items())) + ".") if fb else ""


def garch_plan(g, u, stamp: str | None = None) -> list[dict]:
    stamp = stamp or date.today().isoformat()
    P = []
    n = g.notes
    P.append(_block("GARCH!A1:A2", [
        [f"GARCH volatility layer: GARCH(1,1) with Student-t innovations per FX pair and country ETF, DCC(1,1) correlations, GARCH-DCC portfolio VaR, option fair values and GPR volatility. Computed by the Python program (python -m econquest garch) on {stamp} from Market History prices to {g.as_of}."],
        [f"Method: maximum likelihood with variance targeting (omega = sample variance x (1 - alpha - beta)); VaR and ES at {n['confidence']:.0%} use the fitted Student-t; vol-target scalar = {n['target_vol']:.0%} target / 21-day forecast vol, capped at {n['scalar_cap']:.1f}x; FX quotes are local currency per USD, so a long local-currency or local-bond position loses when the quote rises. Bad one-day quote reversals removed: {n.get('bad_ticks_removed', {}) or 'none'}."]]))
    P.append(_block(f"GARCH!A4:{col_letter(len(SERIES_HEAD))}4", [SERIES_HEAD]))
    rows = []
    for _, s in g.series.iterrows():
        rows.append([s["country"], s["kind"], s["ticker"], int(s["obs"]), s["last_date"]] + [_r(s[c], 4 if c in ("alpha", "beta", "persistence") else 2) for c in SERIES_COLS[5:]])
    while len(rows) < TABLE_A_MIN_ROWS:
        rows.append([""] * len(SERIES_HEAD))
    last = col_letter(len(SERIES_HEAD))
    P.append(_block(f"GARCH!A5:{last}{4 + len(rows)}", rows))

    r0 = 6 + len(rows)                   # 36 with up to 30 series (v1)
    P.append(_block(f"GARCH!A{r0}:A{r0}", [["Table B. DCC(1,1) conditional correlation forecast across FX pairs (one step ahead). " + (f"a = {g.dcc_fx.a:.3f}, b = {g.dcc_fx.b:.3f}, average correlation {g.dcc_fx.avg_corr(g.dcc_fx.R_next):.3f} vs unconditional {g.dcc_fx.avg_corr(g.dcc_fx.R_uncond):.3f}, {g.dcc_fx.n} days." if g.dcc_fx else "not enough series.")]]))
    if g.dcc_fx:
        lab = g.dcc_fx.labels; k = len(lab)
        P.append(_block(f"GARCH!A{r0+1}:{col_letter(k + 1)}{r0+1+k}", [[""] + lab] + [[lab[i]] + [round(float(g.dcc_fx.R_next[i, j]), 3) for j in range(k)] for i in range(k)]))
    r1 = r0 + 2 + (len(g.dcc_fx.labels) if g.dcc_fx else 0) + 1
    P.append(_block(f"GARCH!A{r1}:A{r1}", [["Table C. DCC(1,1) conditional correlation forecast across country ETFs. " + (f"a = {g.dcc_eq.a:.3f}, b = {g.dcc_eq.b:.3f}, average correlation {g.dcc_eq.avg_corr(g.dcc_eq.R_next):.3f} vs unconditional {g.dcc_eq.avg_corr(g.dcc_eq.R_uncond):.3f}, {g.dcc_eq.n} days." if g.dcc_eq else "not enough series.") + _equity_fallback(n)]]))
    if g.dcc_eq:
        lab = g.dcc_eq.labels; k = len(lab)
        P.append(_block(f"GARCH!A{r1+1}:{col_letter(k + 1)}{r1+1+k}", [[""] + lab] + [[lab[i]] + [round(float(g.dcc_eq.R_next[i, j]), 3) for j in range(k)] for i in range(k)]))
    r2 = r1 + 2 + (len(g.dcc_eq.labels) if g.dcc_eq else 0) + 1
    p = g.portfolio
    port_rows = [["Table D. GARCH-DCC portfolio VaR on the book's market exposures ($mm). FX block = FX positions plus unhedged local bonds; equity block = equity positions with an ETF proxy. Eurobonds and CDS are USD instruments and stay with the copula engine on Portfolio VaR."],
                 ["Block", "Positions", "Gross exposure $mm", "VaR99 1-day $mm", "VaR99 10-day $mm", "Undiversified VaR99 1-day $mm", "Diversification benefit %", "Average DCC correlation", "Unconditional correlation", "Student-t df used"]]
    for blk in ("FX", "Equity"):
        b = p.get(blk, {})
        und = b.get("undiversified_var99_1d_mm", 0.0); v1 = b.get("var99_1d_mm", 0.0)
        port_rows.append([blk, int(b.get("positions", 0)), _r(b.get("gross_mm"), 1), _r(v1, 2), _r(b.get("var99_10d_mm"), 2), _r(und, 2), _r((1 - v1 / und) * 100, 1) if und else "", _r(b.get("avg_corr")), _r(b.get("avg_corr_uncond")), _r(b.get("nu"), 1)])
    port_rows.append(["Total (blocks combined as independent)", "", _r(p.get("FX", {}).get("gross_mm", 0) + p.get("Equity", {}).get("gross_mm", 0), 1), _r(p["total_var99_1d_mm"], 2), _r(p["total_var99_10d_mm"], 2), "", "", "", "", ""])
    P.append(_block(f"GARCH!A{r2}:J{r2+len(port_rows)-1}", port_rows))
    r3 = r2 + len(port_rows) + 2
    opt_rows = [[f"Table E. Options check: Black-Scholes fair value of an at-the-money {int(g.options['tenor_days'].iloc[0]) if len(g.options) else 63}-day put on each ETF, priced with the GARCH forecast vol and with 60-day realized vol (risk-free {n['risk_free']:.1%}). Enter market put quotes in column K; the next run of python -m econquest garch reads them back and fills implied vol and the GARCH-minus-implied spread in column N." + _equity_fallback(n)],
                ["Country", "ETF", "Spot", "Strike (ATM)", "Tenor (days)", "GARCH vol % ann", "Realized vol % ann", "Put fair value (GARCH)", "Put fair value (realized)", "GARCH vs realized %", "Market put quote (enter)", "Vega per vol point", "Delta", "Implied vol % ann (from quote)", "GARCH minus implied, vol pts"]]
    for _, o in g.options.iterrows():
        opt_rows.append([o["country"], o["ticker"], _r(o["spot"], 2), _r(o["strike"], 2), int(o["tenor_days"]), _r(o["garch_vol_pct"], 1), _r(o["realized_vol_pct"], 1), _r(o["put_fair_garch"], 3), _r(o["put_fair_realized"], 3), _r(o["put_diff_pct"], 1), _r(o.get("market_quote")) if pd.notna(o.get("market_quote", np.nan)) else "", _r(o["vega_per_vol_pt"], 3), _r(o["delta"], 3), _r(o.get("implied_vol_pct"), 1), _r(o.get("garch_minus_implied"), 1)])
    P.append(_block(f"GARCH!A{r3}:O{r3+len(opt_rows)-1}", opt_rows))
    r4 = r3 + len(opt_rows) + 2
    mac_rows = [["Table F. Macro volatility: GARCH(1,1) on monthly log changes of the Caldara-Iacoviello GPR series (global GPR, threats GPRT, acts GPRA, and country shares GPRC). Conditional vol above long-run vol means geopolitical news flow is currently more volatile than usual."],
                ["Series", "Months", "Last month", "alpha", "beta", "alpha + beta", "Student-t df", "Long-run vol % per month", "Conditional vol now %", "Forecast vol next 3m %", "Now / long-run", "ARCH-LM p (changes)", "Last standardized shock"]]
    for _, m in g.macro.iterrows():
        mac_rows.append([m["series"], int(m["obs"]), m["last_month"], _r(m["alpha"]), _r(m["beta"]), _r(m["persistence"]), _r(m["nu"], 1) if m["nu"] < 1000 else ">1000 (Gaussian)", _r(m["long_run_vol_pct"], 1), _r(m["cond_vol_pct"], 1), _r(m["fcst_3m_vol_pct"], 1), _r(m["vol_ratio"], 2), _r(m["arch_lm_p"], 3), _r(m["last_std_resid"], 2)])
    P.append(_block(f"GARCH!A{r4}:M{r4+len(mac_rows)-1}", mac_rows))
    r5 = r4 + len(mac_rows) + 2
    notes = [["How to read this tab"],
             ["Table A: alpha is the reaction to yesterday's shock, beta the memory; alpha + beta near 1 means volatility shocks fade slowly (half-life in days). Student-t df below 5 means fat tails, so the VaR here is wider than a Gaussian VaR at the same vol."],
             ["Tests: ARCH-LM p (returns) below 0.05 means the raw returns have volatility clustering, so GARCH is warranted. ARCH-LM and Ljung-Box p on the standardized residuals above 0.05 mean the model has absorbed the clustering; below 0.05 means the fit is incomplete for that series."],
             ["Vol-target scalar: multiply a position by it to hold a constant target volatility; below 1 means cut the position because forecast vol is above target, above 1 means it can be larger. Capped so quiet series do not balloon."],
             ["Sizing and VaR use the book on Portfolio VaR (FX and local bonds carry the currency; equity uses the ETF proxy). Rerun: python -m econquest garch (refreshes from the Market History tab export) and publish."]]
    P.append(_block(f"GARCH!A{r5}:A{r5+len(notes)-1}", notes))
    return P


def garch_tables(g) -> dict[str, pd.DataFrame]:
    out = {"series": g.series, "options": g.options, "macro": g.macro}
    if g.dcc_fx:
        out["dcc_fx"] = pd.DataFrame(g.dcc_fx.R_next, index=g.dcc_fx.labels, columns=g.dcc_fx.labels)
    if g.dcc_eq:
        out["dcc_eq"] = pd.DataFrame(g.dcc_eq.R_next, index=g.dcc_eq.labels, columns=g.dcc_eq.labels)
    if g.vol_history is not None:
        out["vol_history"] = g.vol_history.round(3)
    return out
