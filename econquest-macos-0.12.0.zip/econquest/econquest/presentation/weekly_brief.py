"""Weekly macro, sovereign and geopolitical brief (EQ-C-0075): one self-contained HTML document (and a PDF where the
headless-Chrome path of country_note.html_to_pdf works) assembled only from stored run outputs.

    econquest weekly-brief --as-of 2026-10-23 [--pdf] [--dest DIR]

Sections, each stamped with the run_id / data_hash (or file sha256) its numbers come from:
1. Book risk: VaR / ES / L-VaR / expected loss of the newest archived base run with a model date on or before --as-of,
   against the base run about a week earlier (risk_monitor.reference_run), and the book-limit verdicts
   (mc_band.book_limit_verdicts on data/limits.json).
2. Top movers in 12-month default PD and in the composite score (current vs reference run).
3. Regimes: global regime, counts by regime and the regime changes (validation.alerts.regime_alerts).
4. Events: UCDP / GDELT event heat (events_view.event_summary; "no event feed yet" when absent), file sha256 stamped.
5. Stress highlights: the archived stress-<key> runs matched to the base run (country_note.load_stress_runs), each row
   with its own stress run_id and data_hash.
6. Trade ideas and track record: Team B's idea log (outputs/idea_log.csv) restricted to ideas opened on or before
   --as-of, hit rate and P&L by quarter (ideas_view.quarterly, idea_log.idea_report); the log's sha256 is stamped.
Then Input caveats, Sources, the research block (research.py: INTERNAL RESEARCH banner in internal mode) and
report.DISCLAIMER. Every table row that holds numbers carries data-run-id / data-data-hash attributes, and the JSON
manifest next to the HTML repeats every number with its stamp.

Formatting only: no number is estimated here and no text is generated from free text. Labels in the output are fixed
strings; identifiers from the data (country, scenario key, source, regime) are escaped with report._e.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import math
from pathlib import Path

import pandas as pd

from .country_note import html_to_pdf, load_stress_runs, result_bundle, run_stamps
from .events_view import monitor_events_html
from .mc_band import BAND_MEASURES, band_text, book_limit_verdicts, limits_html, load_book_limits
from .report import DISCLAIMER, _e, _f, _pct, caveats_html, input_caveats, product_sources, sources_html
from .research import client_safe_manifest  # EQ-C-0151 (HO-20261026-B-C-005)
from .risk_monitor import MONITOR_KPIS, _model_date, reference_run

TOP_N = 10
STRESS_TOP = 8
KIND = "weekly_brief"
IDEAS_NA = "No trade-idea log yet: the record starts with the first logged run."   # EQ-C-0144: reader text, no command
from .house_style import BRIEF_CSS  # noqa: E402  (EQ-C-0082 house style)


def _sha256(p: Path) -> str | None:
    try:
        return hashlib.sha256(p.read_bytes()).hexdigest()
    except OSError:
        return None


def _num(v) -> float | None:
    try:
        x = float(v)
    except (TypeError, ValueError):
        return None
    return x if math.isfinite(x) else None


def select_run(outputs_dir, as_of: dt.date, label: str = "base") -> dict:
    """The newest archived `label` run whose model date (as_of, else creation date) is on or before `as_of`.
    FileNotFoundError when there is no archive or no such run."""
    out = Path(outputs_dir)
    if not (out / "store" / "econquest.sqlite").exists():
        raise FileNotFoundError(f"no run archive in {out / 'store'}: run `econquest run` first (the brief reads stored runs only)")
    from ..persistence import Store
    store = Store(out / "store")
    for r in store.runs(limit=100000):                     # newest first
        if r["label"] != label:
            continue
        d = _model_date({"summary": r["summary"]}) or pd.Timestamp(r["created_at"][:10])
        if d.date() <= as_of:
            try:
                return store.load(r["run_id"])
            except FileNotFoundError:
                continue
    raise FileNotFoundError(f"no archived '{label}' run with a model date on or before {as_of}")


def _stamp(run: dict | None) -> dict:
    return run_stamps(run) if run else {}


def _movers(cur: dict, ref: dict | None, field: str) -> list[dict]:
    """Countries ordered by the absolute change of `field` (pd_default or composite) between the runs; without a
    reference run, by the current level."""
    prev = {r["country"]: r for r in (ref or {}).get("country") or [] if r.get("country") is not None}
    rows = []
    for r in cur.get("country") or []:
        c = r.get("country")
        if c is None:
            continue
        now = _num(r.get(field)); was = _num((prev.get(c) or {}).get(field)) if ref else None
        rows.append({"country": str(c), "now": now, "prev": was, "change": (now - was) if now is not None and was is not None else None,
                     "regime": r.get("regime"), "regime_prev": (prev.get(c) or {}).get("regime") if ref else None})
    if ref:
        rows.sort(key=lambda m: (-(abs(m["change"]) if m["change"] is not None else -1), m["country"]))
    else:
        rows.sort(key=lambda m: (-(m["now"] or 0), m["country"]))
    return rows[:TOP_N]


def _stress(base: dict, runs: dict[str, dict]) -> list[dict]:
    bm = (base.get("summary") or {}).get("metrics") or {}
    rows = []
    for k, sr in runs.items():
        s = sr.get("summary") or {}; m = s.get("metrics") or {}; st = run_stamps(sr)
        row = {"scenario": str(k), "run_id": st.get("run_id"), "data_hash": st.get("data_hash"), "global_regime": s.get("global_regime")}
        for key in ("var99_mm", "es99_mm", "expected_loss_mm"):
            v, b = _num(m.get(key)), _num(bm.get(key))
            row[key], row[key + "_base"] = v, b
            row[key + "_change"] = v - b if v is not None and b is not None else None
        rows.append(row)
    rows.sort(key=lambda r: (-(r["es99_mm"] if r["es99_mm"] is not None else -math.inf), r["scenario"]))
    return rows[:STRESS_TOP]


def _ideas(outputs_dir: Path, as_of: dt.date) -> dict:
    from ..validation import idea_log
    from .ideas_view import LABEL, LOG_FILE, NO_LOG, _all_row, quarterly
    f = outputs_dir / LOG_FILE
    base = {"status": "missing", "message": NO_LOG, "label": LABEL, "file": LOG_FILE, "sha256": None, "run_id": None,
            "quarters": [], "total": None, "marks_after_as_of": False}
    if not f.exists():
        return base
    base["sha256"] = _sha256(f)
    try:
        log = idea_log.load_log(f)
    except (pd.errors.EmptyDataError, pd.errors.ParserError, OSError, UnicodeDecodeError, ValueError, TypeError) as e:
        return {**base, "status": "invalid", "message": f"The trade-idea log could not be read ({type(e).__name__})."}
    log = log[pd.to_datetime(log["as_of"]) <= pd.Timestamp(as_of)]
    if not len(log):
        return {**base, "status": "empty", "message": f"No trade idea opened on or before {as_of}."}
    a = _all_row(log)
    later = pd.concat([pd.to_datetime(log[c]) for c in ("mark_date", "close_date")]).dropna()
    rid = log.loc[pd.to_datetime(log["as_of"]).idxmax(), "run_id"]
    total = {"quarter": "All quarters", "opened": int(a["ideas"]), "closed": int(a["closed"]), "closed_marked": int(a["closed_marked"]),
             "hit_rate": _num(a["hit_rate"]), "pnl_mm": _num(a["pnl_realised_mm"]), "open_end": int(a["open"])}
    return {**base, "status": "ok", "message": f"{int(a['ideas'])} ideas opened on or before {as_of} ({int(a['open'])} open, {int(a['closed'])} closed).",
            "run_id": None if pd.isna(rid) else str(rid), "quarters": quarterly(log), "total": total,
            "marks_after_as_of": bool(len(later) and later.max().date() > as_of)}


def _event_files(ev: dict, data_dir: Path) -> list[dict]:
    out = []
    for name in ev.get("files") or []:
        p = Path(name) if Path(name).is_absolute() else data_dir / name
        out.append({"file": Path(name).name, "sha256": _sha256(p)})
    return out


def collect(outputs_dir, data_dir, as_of: dt.date) -> dict:
    """Everything the brief shows, from stored outputs only (see the module docstring)."""
    outputs_dir, data_dir = Path(outputs_dir), Path(data_dir)
    run = select_run(outputs_dir, as_of)
    ref, ref_note = reference_run(outputs_dir, run, days=7)
    from ..validation.alerts import normalise_run, regime_alerts
    s = run.get("summary") or {}
    cur_n, ref_n = normalise_run(run), normalise_run(ref)
    from .events_view import event_summary
    st = _stamp(run)
    ev = event_summary(data_dir, countries=[(r.get("country"), r.get("iso")) for r in run.get("country") or [] if r.get("country")],
                       as_of=st.get("as_of"), outputs_dir=outputs_dir)
    stress_runs, stress_note = load_stress_runs(outputs_dir, run)
    from .research import effective_mode
    from . import house_view
    hvl = house_view.load(outputs_dir, st.get("run_id"))             # HO-20261025-B-C-017: Team B's house view, as built
    return {"house_view": hvl, "house_rows": house_view.weekly_rows(hvl, [r.get("country") for r in run.get("country") or []]),
            "as_of_requested": as_of.isoformat(), "run": run, "ref": ref, "stamps": st, "ref_stamps": _stamp(ref), "ref_note": ref_note,
            "metrics": s.get("metrics") or {}, "ref_metrics": ((ref or {}).get("summary") or {}).get("metrics") or {},
            "limits": book_limit_verdicts(s.get("metrics") or {}, load_book_limits(data_dir)),
            "limits_sha256": _sha256(data_dir / "limits.json"),
            "pd_movers": _movers(run, ref, "pd_default"), "score_movers": _movers(run, ref, "composite"),
            "global_regime": cur_n["global_regime"], "global_prev": ref_n["global_regime"] if ref else None,
            "regimes": s.get("regimes") or {}, "regimes_prev": ((ref or {}).get("summary") or {}).get("regimes") or {},
            "regime_changes": regime_alerts(cur_n, ref_n) if ref else [],
            "events": ev, "event_files": _event_files(ev, data_dir),
            "stress": _stress(run, stress_runs), "stress_note": stress_note,
            "ideas": _ideas(outputs_dir, as_of),
            "caveats": input_caveats(data_dir, run), "sources": product_sources(data_dir, run, events=ev),
            "research": effective_mode(data_dir),
            "generated": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M")}


# ---------------------------------------------------------------- rendering
def _src(*parts: tuple[str, object]) -> str:
    """'Source: run X | data hash Y' line; every value escaped."""
    return "<p class='src'>Source: " + " | ".join(f"{_e(k)} <code>{_e(v if v not in (None, '') else 'none')}</code>" for k, v in parts) + "</p>"


def _tr(cells: str, run_id, data_hash) -> str:
    return f"<tr data-run-id=\"{_e(run_id or '')}\" data-data-hash=\"{_e(data_hash or '')}\">{cells}</tr>"


def _stamp_rows(table_html: str, run_id, data_hash) -> str:
    """A shared renderer's table (mc_band.limits_html, events_view.monitor_events_html) with every data row stamped."""
    return table_html.replace("<tr><td", f"<tr data-run-id=\"{_e(run_id or '')}\" data-data-hash=\"{_e(data_hash or '')}\"><td")


def _chg(v, d=1, suffix="") -> str:
    return "" if v is None else f"{v:+,.{d}f}{suffix}"


def render_html(ctx: dict) -> str:
    st, rst = ctx["stamps"], ctx["ref_stamps"]
    rid, dh = st.get("run_id"), st.get("data_hash")
    ref_id = rst.get("run_id")
    pair = (("run", rid), ("data hash", dh), ("reference run", ref_id), ("reference data hash", rst.get("data_hash")))
    m, pm = ctx["metrics"], ctx["ref_metrics"]
    head = "".join(_tr(f"<td>{_e(lbl)}</td><td class='n'>{_f(m.get(k))}</td><td class='n'>{band_text(m, k) if k in BAND_MEASURES else ''}</td>"
                       f"<td class='n'>{_f(pm.get(k))}</td><td class='n'>{_chg(_diff(m.get(k), pm.get(k)))}</td>", rid, dh) for k, lbl in MONITOR_KPIS)

    def movers(rows, pct):
        if not rows:
            return "<p class='empty'>No countries in the run.</p>"
        body = "".join(_tr(f"<td>{_e(r['country'])}</td><td class='n'>{_pct(r['now']) if pct else _f(r['now'])}</td>"
                           f"<td class='n'>{_pct(r['prev']) if pct else _f(r['prev'])}</td>"
                           f"<td class='n'>{_chg(r['change'] * 100 if pct and r['change'] is not None else r['change'], 2 if pct else 1, ' pp' if pct else '')}</td>"
                           f"<td class='regime-{_e(r['regime'])}'>{_e(r['regime'] or '')}</td><td>{_e(r['regime_prev'] or '')}</td>", rid, dh) for r in rows)
        return ("<table><tr><th>Country</th><th class='n'>This run</th><th class='n'>Reference run</th><th class='n'>Change</th>"
                f"<th>Regime</th><th>Reference regime</th></tr>{body}</table>")
    has_ref = bool(ref_id)
    reg_counts = "; ".join(f"{_e(k)} {_e(n)}" + (f" (was {_e(ctx['regimes_prev'].get(k, 0))})" if has_ref else "") for k, n in ctx["regimes"].items())
    changes = ("<table><tr><th>Severity</th><th>Scope</th><th>From</th><th>To</th></tr>" + "".join(
        _tr(f"<td><span class='sev {_e(a['severity'])}'>{_e(a['severity'])}</span></td><td>{_e(a['scope'])}</td><td>{_e(a.get('threshold'))}</td>"
            f"<td>{_e(a.get('value'))}</td>", rid, dh) for a in ctx["regime_changes"]) + "</table>") if ctx["regime_changes"] else \
        f"<p class='empty'>{'No country or global regime changed.' if has_ref else 'No reference run: regime changes cannot be shown.'}</p>"
    ev = ctx["events"]
    ev_src = _src(("run", rid), *[(f"file {f['file']} sha256", f["sha256"]) for f in ctx["event_files"]]) if ctx["event_files"] else _src(("run", rid), ("event files", "none"))
    ev_hash = ",".join(f["sha256"] or "" for f in ctx["event_files"])
    srows = ctx["stress"]
    stress = ("<table><tr><th>Scenario</th><th>Stress run</th><th>Data hash</th><th>Global regime</th><th class='n'>VaR 99% $mm</th><th class='n'>vs base</th>"
              "<th class='n'>ES 99% $mm</th><th class='n'>vs base</th><th class='n'>Expected loss $mm</th></tr>" + "".join(
                  _tr(f"<td>{_e(r['scenario'])}</td><td><code>{_e(r['run_id'])}</code></td><td><code>{_e(r['data_hash'])}</code></td>"
                      f"<td class='regime-{_e(r['global_regime'])}'>{_e(r['global_regime'] or '')}</td><td class='n'>{_f(r['var99_mm'])}</td>"
                      f"<td class='n'>{_chg(r['var99_mm_change'])}</td><td class='n'>{_f(r['es99_mm'])}</td><td class='n'>{_chg(r['es99_mm_change'])}</td>"
                      f"<td class='n'>{_f(r['expected_loss_mm'])}</td>", r["run_id"], r["data_hash"]) for r in srows) + "</table>") if srows else \
        "<p class='empty na' data-na='1'>No archived stress run: stress results are not available for this brief.</p>"
    idea = ctx["ideas"]
    if idea["status"] == "ok":
        qrows = idea["quarters"] + [idea["total"]]
        ideas = ("<table><tr><th>Quarter</th><th class='n'>Opened</th><th class='n'>Closed</th><th class='n'>Closed and marked</th>"
                 "<th class='n'>Hit rate</th><th class='n'>P&amp;L realised $mm</th><th class='n'>Open at quarter end</th></tr>" + "".join(
                     _tr(f"<td>{_e(q['quarter'])}</td><td class='n'>{_e(q['opened'])}</td><td class='n'>{_e(q['closed'])}</td><td class='n'>{_e(q['closed_marked'])}</td>"
                         f"<td class='n'>{_pct(q['hit_rate'], 1)}</td><td class='n'>{_f(q['pnl_mm'], 2)}</td><td class='n'>{_e(q['open_end'])}</td>",
                         idea["run_id"], idea["sha256"]) for q in qrows) + "</table>")
        if idea["marks_after_as_of"]:
            ideas += f"<p class='note'>The log holds marks or closes dated after {_e(ctx['as_of_requested'])}; the hit rate uses the log as stored.</p>"
    else:
        ideas = (f"<p class='empty na' data-na='1'>{_e(IDEAS_NA)}</p>" if idea["status"] == "missing"   # EQ-C-0144
                 else f"<p class='empty'>{_e(idea['message'])}</p>")
    from .research import block_html
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>EconQuest weekly brief {_e(ctx['as_of_requested'])}</title><style>{BRIEF_CSS}</style></head><body>
{block_html(ctx['research'])}
<h1>EconQuest weekly brief: macro, sovereign and geopolitical risk</h1>
<div class="sub">Week to {_e(ctx['as_of_requested'])}. Run {_e(rid)}, as of {_e(st.get('as_of') or 'not recorded')}. {_e(ctx['ref_note'])}</div>
<div class="meta"><span><b>Run</b> {_e(rid)}</span><span><b>As of</b> {_e(st.get('as_of') or 'not recorded')}</span><span><b>Data hash</b> {_e(dh)}</span>
<span><b>Code hash</b> {_e(st.get('code_hash'))}</span><span><b>Run hash</b> {_e(st.get('run_hash'))}</span><span><b>Reference run</b> {_e(ref_id or 'none')}</span></div>
<div class="disclaimer" role="note"><b>Disclaimer.</b> {_e(DISCLAIMER)}</div>
<h2>Book risk against limits ($mm)</h2>{_src(*pair)}
<table><tr><th>Measure</th><th class="n">This run</th><th class="n">95% MC band</th><th class="n">Reference run</th><th class="n">Change</th></tr>{head}</table>
<h3>Book limits</h3>{_src(("run", rid), ("data hash", dh), ("limits.json sha256", ctx['limits_sha256']))}{_stamp_rows(limits_html(ctx['limits'], _e), rid, dh)}
<h2>Top movers: 12-month default PD</h2>{_src(*pair)}{movers(ctx['pd_movers'], True)}
<h2>Top movers: composite score</h2>{_src(*pair)}{movers(ctx['score_movers'], False)}
<h2>House view</h2>{_src(("run", rid), ("house view run", ((ctx.get('house_view') or {}).get('hv') or {}).get('run_id')))}{_house_html(ctx, rid, dh)}
<h2>Regime</h2>{_src(*pair)}
<p>Global regime <b class="regime-{_e(ctx['global_regime'])}">{_e(ctx['global_regime'])}</b>{f" (was {_e(ctx['global_prev'])})" if has_ref and ctx['global_prev'] else ''}. Countries by regime: {reg_counts}.</p>
{changes}
<h2>Geopolitical events (UCDP / GDELT)</h2>{ev_src}{_stamp_rows(monitor_events_html(ev), rid, ev_hash)}
<h2>Stress highlights</h2>{_src(("base run", rid), ("base data hash", dh))}<p class="note">{_e(ctx['stress_note'])} Each row is its own archived stress run.</p>{stress}
<h2>Trade ideas and track record</h2>{_src(("latest idea run", idea['run_id']), (f"{idea['file']} sha256", idea['sha256']))}
<p class="note">{_e(idea['label'])}</p>{ideas}
<h2>Input caveats</h2>{_stamp_rows(caveats_html(ctx['caveats']), rid, dh)}
{sources_html(ctx['sources']) if ctx.get('sources') else ''}
<p class="note">Assembled from stored run outputs only; no figure is estimated in this document. Brief generated {_e(ctx['generated'])} UTC (generation timestamp, not a model date).</p>
<div class="disclaimer" role="note"><b>Disclaimer.</b> {_e(DISCLAIMER)}</div>
</body></html>"""


def _house_html(ctx: dict, rid, dh) -> str:
    from . import house_view
    return house_view.weekly_table_html(ctx.get("house_view") or {}, ctx.get("house_rows") or [], lambda cells: _tr(cells, rid, dh))


def _diff(a, b):
    a, b = _num(a), _num(b)
    return a - b if a is not None and b is not None else None


def _house_section(ctx: dict) -> dict | None:
    """sections.house_view (HO-20261025-B-C-017): the house view's rows, or None when there is none for this run."""
    hvl = ctx.get("house_view") or {}
    if hvl.get("status") != "ok":
        return None
    return {"run_id": (hvl.get("hv") or {}).get("run_id"), "status": "ok",
            "rows": [{k: r[k] for k in ("country", "stance", "risk_level", "trend", "counter_view_ideas")} for r in ctx.get("house_rows") or []]}


def manifest(ctx: dict) -> dict:
    """The numbers of the brief with their stamps (JSON-safe)."""
    st, rst = ctx["stamps"], ctx["ref_stamps"]
    run_src = {"run_id": st.get("run_id"), "data_hash": st.get("data_hash"), "reference_run_id": rst.get("run_id"),
               "reference_data_hash": rst.get("data_hash")}
    return {"kind": KIND, "as_of_requested": ctx["as_of_requested"], "stamps": st, "reference_stamps": rst,
            "research_mode": ctx["research"]["mode"], **client_safe_manifest(ctx["research"]),   # EQ-C-0151
            "sections": {
                "book": {**run_src, "metrics": {k: {"now": _num(ctx["metrics"].get(k)), "reference": _num(ctx["ref_metrics"].get(k))} for k, _ in MONITOR_KPIS}},
                "limits": {**run_src, "limits_sha256": ctx["limits_sha256"], "rows": ctx["limits"]},
                "pd_movers": {**run_src, "rows": ctx["pd_movers"]}, "score_movers": {**run_src, "rows": ctx["score_movers"]},
                "regime": {**run_src, "global": ctx["global_regime"], "global_prev": ctx["global_prev"], "counts": ctx["regimes"],
                           "changes": [{k: a.get(k) for k in ("severity", "scope", "threshold", "value")} for a in ctx["regime_changes"]]},
                "events": {"run_id": st.get("run_id"), "files": ctx["event_files"], "status": ctx["events"]["status"],
                           "rows": [{k: r.get(k) for k in ("country", "source", "week_start", "events", "events_prev", "wow_change", "heat_ratio", "heat_label")}
                                    for r in ctx["events"].get("rows") or [] if r.get("events") is not None][:15]},
                "stress": {"base_run_id": st.get("run_id"), "rows": ctx["stress"]},
                "house_view": _house_section(ctx),
                "ideas": {k: ctx["ideas"][k] for k in ("status", "run_id", "sha256", "file", "quarters", "total", "marks_after_as_of")}}}


def build_weekly_brief(outputs_dir, data_dir, out_dir, as_of: dt.date, pdf: bool = False, chrome: str | None = None, log=print) -> dict:
    """Write <out_dir>/weekly-brief-<as_of>.html, .json (manifest) and, with pdf, .pdf when a browser is found.
    Returns country_note.result_bundle ("paths" for `econquest editorial draft`, "items", run stamps)."""
    outputs_dir, data_dir, out_dir = Path(outputs_dir), Path(data_dir), Path(out_dir)
    ctx = collect(outputs_dir, data_dir, as_of)
    out_dir.mkdir(parents=True, exist_ok=True)
    stem = f"weekly-brief-{as_of.isoformat()}"
    html_path, json_path = out_dir / f"{stem}.html", out_dir / f"{stem}.json"
    from .csp import harden
    html_path.write_text(harden(render_html(ctx)), encoding="utf-8")                # EQ-C-0165 meta CSP
    json_path.write_text(json.dumps(manifest(ctx), indent=1, default=str), encoding="utf-8")
    item = {"kind": KIND, "title": f"Weekly brief {as_of.isoformat()}", "html": str(html_path), "pdf": None, "pdf_status": "not requested",
            **{k: ctx["stamps"].get(k) for k in ("run_id", "as_of", "data_hash", "code_hash", "run_hash", "code_version")}}
    if pdf:
        item["pdf"], item["pdf_status"] = html_to_pdf(html_path, chrome=chrome)
    res = result_bundle(KIND, [item], ctx["stamps"], out_dir, manifest=str(json_path), reference_run_id=ctx["ref_stamps"].get("run_id"),
                        research_mode=ctx["research"]["mode"], events_status=ctx["events"]["status"], ideas_status=ctx["ideas"]["status"],
                        stress_rows=len(ctx["stress"]))
    for p in ctx["research"]["problems"]:
        log(f"[weekly-brief] warning: {p}")
    log(f"[weekly-brief] {html_path} (run {ctx['stamps'].get('run_id')}, reference {ctx['ref_stamps'].get('run_id') or 'none'}, "
        f"mode {ctx['research']['mode']}" + (f", PDF {item['pdf_status']}" if pdf else "") + ")")
    return res
