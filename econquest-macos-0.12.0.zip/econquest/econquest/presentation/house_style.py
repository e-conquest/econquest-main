"""House style (EQ-C-0082): the one CSS and page template module every research product uses.

report.py (daily report, and through it the weekly monitor and the republish preview), country_note.py (country notes,
indexes, scenario briefs) and weekly_brief.py take their CSS from here; the strings are byte-identical to the ones
those modules defined before, so existing products render exactly as before. New sections use `section`,
`not_available` and `page` so every product looks the same.
"""
from __future__ import annotations

import html as _h

CSS = """
body{font-family:-apple-system,Segoe UI,Helvetica,Arial,sans-serif;margin:28px auto;max-width:1100px;padding:0 16px;color:#222;background:#fff;font-size:13px;line-height:1.4}
h1{margin:0 0 4px;font-size:24px}h2{font-size:17px;margin:28px 0 8px;border-bottom:2px solid #e3e3e3;padding-bottom:4px}h3{font-size:14px;margin:16px 0 6px}
.sub{color:#666;margin-bottom:12px}.meta{display:flex;flex-wrap:wrap;gap:6px 18px;color:#555;font-size:12px;margin:8px 0 16px}
.kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin:12px 0}
.kpi{border:1px solid #ddd;border-radius:8px;padding:10px 12px;background:#fafafa}.kpi .v{font-size:21px;font-weight:600}.kpi .l{font-size:11px;color:#666}.kpi .d{font-size:11px;color:#888}
table{border-collapse:collapse;width:100%;font-size:12px;margin:6px 0 14px;page-break-inside:auto}th,td{border:1px solid #e3e3e3;padding:4px 7px;vertical-align:top}
th{background:#f0f0f0;text-align:left}td.n,th.n{text-align:right;white-space:nowrap}tr{page-break-inside:avoid}
.sev{display:inline-block;padding:1px 7px;border-radius:10px;font-size:11px;font-weight:600;color:#fff}.critical{background:#c0392b}.warning{background:#e67e22}.info{background:#2e86c1}
.regime-Calm{color:#1e8449}.regime-Stressed{color:#b9770e;font-weight:600}.regime-Crisis{color:#c0392b;font-weight:700}
.pass{color:#1e8449;font-weight:600}.fail{color:#c0392b;font-weight:700}.zone-Green{color:#1e8449}.zone-Yellow{color:#b9770e}.zone-Red{color:#c0392b}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:20px}.note{color:#666;font-size:11px}.empty{color:#777;font-style:italic}
.disclaimer{border:1px solid #b9770e;background:#fdf6e3;color:#4d3800;padding:8px 12px;border-radius:6px;margin:10px 0;font-size:12px}
.caveats{border-left:4px solid #b9770e;padding:2px 0 2px 12px}.caveats li{margin:3px 0}
@media(max-width:900px){.grid{grid-template-columns:1fr}}
@media print{body{margin:0;max-width:none;font-size:11px}h2{page-break-after:avoid}.kpi{break-inside:avoid}a{color:inherit;text-decoration:none}}
"""

NOTE_CSS = CSS + """
.tag{display:inline-block;border:1px solid currentColor;border-radius:4px;padding:0 5px;font-size:10px;font-weight:700;letter-spacing:.02em}
.tag.seed{color:#8a5a00}.tag.fire{color:#a93226}.tag.stale{color:#a93226}.tag.ok{color:#1e6b3a}
.cols{display:grid;grid-template-columns:1fr 1fr;gap:18px}.chart{margin:6px 0 4px}
table.compact{font-size:10.5px}table.compact td,table.compact th{padding:3px 5px}
.toc{font-size:12px;color:#555}.toc a{color:#2a5a8a}
@media(max-width:900px){.cols{grid-template-columns:1fr}}
@page{size:A4;margin:14mm 12mm}
@media print{.toc{display:none}.cols{grid-template-columns:1fr 1fr}section{break-inside:auto}h2{break-after:avoid}svg{break-inside:avoid}table{break-inside:auto}}
"""

BRIEF_CSS = CSS + ".src{color:#555;font-size:11px;margin:2px 0 8px}.src code{font-size:11px}"

WATERMARK_CSS = (".eq-watermark{position:fixed;inset:0;pointer-events:none;display:flex;align-items:center;justify-content:center;"
                 "z-index:9999}.eq-watermark span{transform:rotate(-30deg);font-size:42px;font-weight:700;color:rgba(138,28,28,.12);"
                 "white-space:nowrap}.eq-recipient{border:1px solid #8a1c1c;color:#4a0d0d;background:#fff4f4;padding:6px 10px;"
                 "margin:8px 0;font-size:12px}@media print{.eq-watermark{position:fixed}}")


def _e(v) -> str:
    return _h.escape("" if v is None else str(v))


def not_available(what: str, why: str) -> str:
    """The standard 'not available' note for a chart or section whose input file is absent (models that ship OFF)."""
    return f"<p class='empty na' data-na='1'>{_e(what)} not available: {_e(why)}.</p>"


def not_available_plain(sentence: str, operator: str | None = None) -> str:
    """A 'not available' note written for the research reader (HO-20261025-B-C-014): one plain sentence, no file names,
    shell commands or placeholders. `operator`, when given, is a separate short operator note (which input was absent)."""
    out = f"<p class='empty na' data-na='1'>{_e(sentence)}</p>"
    if operator:
        out += f"<p class='note operator' data-operator='1'>Operator note: {_e(operator)}</p>"
    return out


def section(key: str, title: str, body_html: str) -> tuple[str, str, str]:
    """A (key, title, html) section tuple in the country-note layout (title escaped by the renderer)."""
    return (key, title, body_html)


def page(title: str, body_html: str, css: str = "") -> str:
    """A self-contained HTML page in the house style (inline CSS, no external assets, prints to PDF)."""
    return (f'<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,'
            f'initial-scale=1"><title>{_e(title)}</title><style>{css or CSS}</style></head><body>\n{body_html}\n</body></html>')
