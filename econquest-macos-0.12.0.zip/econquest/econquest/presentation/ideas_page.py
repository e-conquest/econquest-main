"""Trade-ideas page (HO-20261025-B-C-011, EQ-C-0128): one self-contained HTML page of a stored base run's playbook
activations, with its idea-log line, in the house style of the other research products.

    econquest ideas page --as-of 2026-10-23 [--dest DIR]
    # -> DIR/trade-ideas-<as_of>.html and DIR/trade-ideas.json (default DIR: <out>/trade-ideas)

The run is the one the weekly brief uses for the same --as-of (weekly_brief.select_run: the newest archived base run
with a model date on or before it). The page carries what every product carries: the research and licence block
right after <body> (research.block_html), the run stamps, the disclaimer at the top and the bottom, the input caveats
and sources (report.caveats_html / sources_html) and BRIEF_CSS (house_style). Content: the activation table (trade,
strategy, country, signal strength, the trade's own minimum signal, instrument, stance, horizon; strengths from the run,
labels and minimums from data/playbook.csv), the T17/T01 line when both activate on one country (HO-20261025-B-C-012),
the house stance and alignment of each activation from Team B's house_view.json with a visible "Counter-view to house
stance X" / "Two-way" label (HO-20261025-B-C-017; never derived here), and the idea-log counts from <out>/idea_log.csv.

The JSON manifest is country_note.result_bundle (kind "trade_ideas", "paths", "items", run stamps, "out_dir"), as the
notes, briefs and weekly brief write, plus "activations" (one row per trade and country, with min_strength), "pair_notes", "threshold" and "idea_log".
Formatting only: no number is estimated here; every strength is the run's activation cell.
"""
from __future__ import annotations

import datetime as dt
import json
from pathlib import Path

import pandas as pd

from .country_note import _fnum, _read, result_bundle, run_stamps, stamp_html
from . import house_view
from .house_style import BRIEF_CSS
from .report import DISCLAIMER, _e, _f, caveats_html, input_caveats, product_sources, sources_html
from .research import client_safe_manifest  # EQ-C-0151 (HO-20261026-B-C-005)

KIND = "trade_ideas"
MANIFEST = "trade-ideas.json"
ROW_COLS = ("trade", "strategy", "country", "strength", "min_strength", "instrument", "stance", "horizon", "house_stance", "alignment")

# Trades that can sit on the same name with opposite stances, and why (one line under the table when both activate on
# one country; HO-20261025-B-C-012, wording approved in draft ed-20261025-0064). {t17_entry} is T17's playbook entry rule.
PAIR_NOTES = {("T01", "T17"): ("T17 sells CDS protection (or buys the bonds) because it is a market-PD-versus-model-PD view: "
                               "it activates when the market-implied PD is well above the model PD ({t17_entry}). T01 buys "
                               "protection because the fiscal fundamentals are weak. Both can hold on the same name: T01 says "
                               "the credit is weak, T17 says the spread already prices more than that weakness.")}


def _cell(v):
    """A playbook text cell, or None when empty / NaN."""
    if v is None or (isinstance(v, float) and pd.isna(v)):
        return None
    s = str(v).strip()
    return s or None


def activation_rows(run: dict, playbook: pd.DataFrame | None, hvl: dict | None = None) -> list[dict]:
    """The run's activation table as rows, in the run's order: one per (trade, country) with a numeric strength. Labels (strategy, instrument, stance, horizon) and the trade's own minimum signal (min_strength) from data/playbook.csv, None when not there."""
    pb = playbook.set_index("id") if playbook is not None and "id" in playbook.columns else None
    rows = []
    for a in run.get("activation") or []:
        t = a.get("trade")
        meta = pb.loc[t] if pb is not None and t in pb.index else None
        for c, v in a.items():
            x = _fnum(v)
            if c == "trade" or x is None:
                continue
            rows.append({"trade": t, "country": c, "strength": x, "min_strength": _fnum(meta.get("min_strength")) if meta is not None else None,
                         **{k: (_cell(meta.get(k)) if meta is not None else None) for k in ("strategy", "instrument", "stance", "horizon")},
                         **house_view.idea_fields(hvl or {}, c, t)})     # HO-20261025-B-C-017: the record's own fields
    return [{k: r[k] for k in ROW_COLS} for r in rows]


def pair_notes(rows: list[dict], playbook: pd.DataFrame | None) -> list[str]:
    """One plain line per PAIR_NOTES pair that activates on the same country in `rows`, naming the countries (sorted).
    The second trade's entry rule comes from data/playbook.csv `entry`."""
    entry = {}
    if playbook is not None and {"id", "entry"} <= set(playbook.columns):
        entry = {str(i): _cell(e) for i, e in zip(playbook["id"], playbook["entry"])}
    by: dict[str, set] = {}
    for r in rows:
        by.setdefault(r["trade"], set()).add(r["country"])
    out = []
    for (a, b), text in PAIR_NOTES.items():
        both = sorted(by.get(a, set()) & by.get(b, set()))
        if both:
            rule = (entry.get(b) or "its playbook entry rule").rstrip(".")
            out.append(text.format(t17_entry=rule[0].lower() + rule[1:]) + f" Both activate here for {', '.join(both)}.")
    return out


def idea_log_summary(outputs_dir: Path, run_id: str | None) -> dict:
    """Plain counts from <outputs_dir>/idea_log.csv (written by `econquest run`): status ok / empty / missing / invalid,
    a one-line message, total ideas, open, closed, unmarked, and how many rows this run logged."""
    f = Path(outputs_dir) / "idea_log.csv"
    if not f.is_file():
        return {"status": "missing", "message": "No trade-idea log yet: the record starts with the first logged run.",   # EQ-C-0144: no command
                "total": None}
    try:
        log = pd.read_csv(f, dtype=str, keep_default_na=False)
    except (pd.errors.EmptyDataError, pd.errors.ParserError, OSError, UnicodeDecodeError) as e:
        return {"status": "invalid", "message": f"idea_log.csv could not be read ({type(e).__name__}).", "total": None}
    if not len(log):
        return {"status": "empty", "message": "The trade-idea log has no ideas.", "total": 0}

    def col(c):
        return log[c] if c in log else pd.Series([""] * len(log))
    n = len(log); n_open = int((col("status") == "open").sum()); n_unmarked = int((col("markable").str.lower() != "true").sum())
    n_run = int((col("run_id") == str(run_id)).sum())
    msg = (f"{n} ideas in the log ({n_open} open, {n - n_open} closed); {n_unmarked} unmarked (no daily price for the "
           f"instrument); {n_run} logged by run {run_id}.")
    return {"status": "ok", "message": msg, "total": n, "open": n_open, "closed": n - n_open, "unmarked": n_unmarked, "logged_by_run": n_run}


def _label_cls(r: dict) -> str:
    return " class='counter-view'" if r.get("alignment") in ("counter-view", "two-way") else ""


def render_html(ctx: dict) -> str:
    st, rows, ideas = ctx["stamps"], ctx["rows"], ctx["idea_log"]
    rid, dh = st.get("run_id"), st.get("data_hash")
    body = "".join(
        f"<tr data-run-id=\"{_e(rid or '')}\" data-data-hash=\"{_e(dh or '')}\"><td>{_e(r['trade'])}</td><td>{_e(r['strategy'] or '')}</td>"
        f"<td>{_e(r['country'])}</td><td class='n'>{_f(r['strength'], 0)}</td><td class='n'>{_f(r.get('min_strength'), 0)}</td><td>{_e(r['instrument'] or '')}</td>"
        f"<td>{_e(r['stance'] or '')}</td><td>{_e(r['horizon'] or '')}</td><td>{_e(r.get('house_stance') or '')}</td>"
        f"<td{_label_cls(r)}>{_e(house_view.alignment_label(r.get('house_stance'), r.get('alignment')))}</td></tr>" for r in rows)
    table = ("<table><tr><th>Trade</th><th>Strategy</th><th>Country</th><th class='n'>Signal strength</th><th class='n'>Minimum signal</th><th>Instrument</th>"
             f"<th>Stance</th><th>Horizon</th><th>House stance</th><th>Against the house view</th></tr>{body}</table>") if rows else "<p class='empty'>No playbook trade activates in this run.</p>"
    hvl = ctx.get("house_view") or {}
    hnote = ("<p class='note'>House stance and alignment are the house view's (house_view.json for this run); a counter-view or "
             "two-way idea may still be shown, labelled as such.</p>") if hvl.get("status") == "ok" else house_view.not_available_html(hvl)
    pairs = "".join(f"<p class='note pair'>{_e(x)}</p>" for x in ctx.get("pair_notes") or [])
    n_c = len({r["country"] for r in rows}); n_t = len({r["trade"] for r in rows})
    from .research import block_html
    return f"""<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>EconQuest trade ideas {_e(ctx['as_of_requested'])}</title><style>{BRIEF_CSS}</style></head><body>
{block_html(ctx['research'])}
<h1>Trade ideas: playbook activations</h1>
<div class="sub">Run {_e(rid)}, as of {_e(st.get('as_of') or 'not recorded')}. {len(rows)} activations: {n_t} trades in {n_c} countries.</div>
<div class="meta">{stamp_html(st)}</div>
<div class="disclaimer" role="note"><b>Disclaimer.</b> {_e(DISCLAIMER)}</div>
<h2>Activations</h2>
<p class="note">Decision support, not instructions: no position is opened on a signal alone (use restriction 6.5); sizing and
execution are the desk's. A trade activates when its key signal reaches that trade's own minimum strength in the playbook
(column Minimum signal, data/playbook.csv min_strength, which differs by trade). Strengths are the run's signal scores (0-100).
Sizing and P&amp;L are not shown here.</p>
{hnote}
{table}
{pairs}
<h2>Idea log</h2>
<p class="note">Status {_e(ideas.get('status'))}: {_e(ideas.get('message'))} Illustrative, Tier 3 (GOV-032).</p>
<h2>Input caveats</h2>{caveats_html(ctx['caveats'])}
{sources_html(ctx['sources']) if ctx.get('sources') else ''}
<p class="note">Assembled from the stored run only; no figure is estimated on this page. Page generated {_e(ctx['generated'])} UTC (generation timestamp, not a model date).</p>
<div class="disclaimer" role="note"><b>Disclaimer.</b> {_e(DISCLAIMER)}</div>
</body></html>"""


def collect(outputs_dir, data_dir, as_of: dt.date) -> dict:
    from .research import effective_mode
    from .weekly_brief import select_run
    outputs_dir, data_dir = Path(outputs_dir), Path(data_dir)
    run = select_run(outputs_dir, as_of)
    st = run_stamps(run)
    pb = _read(data_dir / "playbook.csv")
    hvl = house_view.load(outputs_dir, st.get("run_id"))
    rows = activation_rows(run, pb, hvl)
    return {"as_of_requested": as_of.isoformat(), "run": run, "stamps": st, "rows": rows, "house_view": hvl, "pair_notes": pair_notes(rows, pb),
            "threshold": float(((run.get("settings") or {}).get("signals") or {}).get("threshold", 60) or 60),
            "idea_log": idea_log_summary(outputs_dir, st.get("run_id")),
            "caveats": input_caveats(data_dir, run), "sources": product_sources(data_dir, run), "research": effective_mode(data_dir),
            "generated": dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%d %H:%M")}


def build_ideas_page(outputs_dir, data_dir, out_dir, as_of: dt.date, log=print) -> dict:
    """Write <out_dir>/trade-ideas-<as_of>.html and <out_dir>/trade-ideas.json (manifest). Returns the manifest
    (result_bundle). FileNotFoundError when there is no archived base run on or before as_of."""
    out_dir = Path(out_dir)
    ctx = collect(outputs_dir, data_dir, as_of)
    st = ctx["stamps"]
    out_dir.mkdir(parents=True, exist_ok=True)
    html_path, json_path = out_dir / f"trade-ideas-{as_of.isoformat()}.html", out_dir / MANIFEST
    from .csp import harden
    html_path.write_text(harden(render_html(ctx)), encoding="utf-8")                # EQ-C-0165 meta CSP
    item = {"kind": KIND, "title": f"Trade ideas {st.get('as_of') or as_of.isoformat()} (playbook activations)", "html": str(html_path),
            "pdf": None, "pdf_status": "not requested", **{k: st.get(k) for k in ("run_id", "as_of", "data_hash", "code_hash", "run_hash", "code_version")}}
    res = result_bundle(KIND, [item], st, out_dir, manifest=str(json_path), as_of_requested=ctx["as_of_requested"],
                        research_mode=ctx["research"]["mode"], threshold=ctx["threshold"], activations=ctx["rows"], pair_notes=ctx["pair_notes"],
                        idea_log=ctx["idea_log"], **client_safe_manifest(ctx["research"]))   # EQ-C-0151
    json_path.write_text(json.dumps(res, indent=1, default=str), encoding="utf-8")
    for p in ctx["research"]["problems"]:
        log(f"[ideas-page] warning: {p}")
    log(f"[ideas-page] {html_path} ({len(ctx['rows'])} activations, run {st.get('run_id')}, idea log {ctx['idea_log']['status']}, "
        f"mode {ctx['research']['mode']})")
    return res
