"""Country risk heatmap and the M19 depth page (EQ-C-0156, HO-20261026-B-C-013). Read only: nothing here runs the model.

Heatmap. Rows are the run's countries, columns are its seven layer 1 pillars, read as they are from
`outputs/run_latest.json` key `pillars` (= Scorecard.pillar_final, contract C5) or, for a pinned run, from
`persistence.Store.load(run_id)` (C4). Nothing is recomputed: there is no group average, only the run's own numbers
under three group headers (PILLAR_GROUPS, a display grouping of econquest.config.PILLARS):

    geopolitical   4 Political and policy, 6 Security and social
    sovereign      1 Fiscal and debt, 2 External, 3 Institutions and governance
    macro          5 Macro and financial, 7 Climate and disaster

Depth columns (DEPTH_METRICS) come from Team B's eq-depth-views/1 rows (econquest.validation.depth_views, contract C17)
as written by demo_depth_views to <out>/depth_views/depth_views.json; this module never builds them on a GET.
A value is shown only when the row's status is "value"; IMF-sourced rows (EXC-003) are marked INTERNAL; a client view
(client=True) shows only licence_class "allowed" depth values and client_ok, non-synthetic statements.

Drill-down per country: drivers (the run has no per-indicator contribution, so the run's own pillar scores ranked,
its layer 1 feature values and the dashboard's top signals; nothing computed), links to the country note (notes view
id, archive ref), upcoming events (calendar_view, EQ-C-0155), recent statements (Team A's corpus.latest, titles only,
never body text; empty until the corpus is pulled) and the country's depth rows per view.

M19 depth page: one panel per view (status counts, routes, notes), labelled RESEARCH VIEWS, display only.

    econquest heatmap [--country C] [--client] [--run-id ID] [--today D] [--depth] [--build-depth] [--json] [--html OUT]
    GET /api/heatmap?country=&client=0|1&run_id=&today=&view=depth     token + Origin, as /api/notes
    demo_heatmap(out_dir) -> {"ok", "problems", "summary"}        demo_depth_page(out_dir) -> {"ok", "problems", "summary"}
"""
from __future__ import annotations

import datetime as dt
import html
import json
import re
import sys
from pathlib import Path

SCHEMA = "econquest-heatmap/1"
TICKET = "EQ-C-0156"
DEPTH_LABEL = "RESEARCH VIEWS, display only"
INTERNAL = "INTERNAL"
PILLAR_GROUPS = (("geopolitical", "Geopolitical", (4, 6)),
                 ("sovereign", "Sovereign", (1, 2, 3)),
                 ("macro", "Macro", (5, 7)))
DEPTH_METRICS = (("p_programme_12m", "imf_programme", "IMF programme probability, 12m"),
                 ("reserves_pct_ara", "reserve_adequacy", "Reserves, % of ARA"),
                 ("gfn_next_year_pct_gdp", "gross_financing_need", "Gross financing need next year, % of GDP"))
# Score bands for colour; every cell also shows its number and the band name (colour is never the only cue).
BANDS = ((0, 20, "low"), (20, 40, "moderate"), (40, 60, "elevated"), (60, 80, "high"), (80, 100.0001, "severe"))
EVENT_DAYS = 90
STATEMENTS_N = 5
STATEMENTS_EMPTY = "No recent statements yet: the central bank and IMF text corpus is empty until the next data pull."
STATEMENTS_FIELDS = ("title", "source", "family", "published_utc", "client_ok", "synthetic")
DEPTH_FILE = Path("depth_views") / "depth_views.json"
OUT_SUB = "heatmap"
RUN_ID_RE = re.compile(r"^\d{8}T\d{6}-[A-Za-z0-9_-]{1,40}$")
_COUNTRY = re.compile(r"^[A-Za-z][A-Za-z .'()-]{1,59}$")
_DATE = re.compile(r"^\d{4}-\d{2}-\d{2}$")


class HeatmapError(ValueError):
    """A bad request: the message never holds a path or the caller's raw input."""


# ---------------------------------------------------------------- inputs
def pillar_names() -> dict[str, str]:
    from ..config import PILLARS
    return {str(k): v for k, v in PILLARS.items()}


def groups() -> list[dict]:
    names = pillar_names()
    return [{"key": k, "label": lab, "pillars": [{"id": str(p), "name": names[str(p)]} for p in ps]}
            for k, lab, ps in PILLAR_GROUPS]


def band(v) -> str:
    if not isinstance(v, (int, float)) or v != v:
        return ""
    for lo, hi, name in BANDS:
        if lo <= v < hi:
            return name
    return "severe" if v >= 100 else "low"


def load_run(out_dir, run_id: str | None = None) -> dict:
    """The run dict: outputs/run_latest.json, or Store.load(run_id) for a pinned run. Raises HeatmapError."""
    out = Path(out_dir)
    if run_id:
        if not RUN_ID_RE.match(str(run_id)):
            raise HeatmapError("run_id must look like 20261025T235026-base")
        root = out / "store"
        if not (root / "econquest.sqlite").is_file():
            raise HeatmapError("no run store in the outputs folder")
        from ..persistence import Store
        try:
            return Store(root).load(str(run_id))
        except (FileNotFoundError, OSError, ValueError):
            raise HeatmapError("no stored run with that run_id") from None
    f = out / "run_latest.json"
    if not f.is_file():
        raise HeatmapError("no model run yet (run_latest.json is missing)")
    try:
        return json.loads(f.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        raise HeatmapError("run_latest.json could not be read") from None


_DEPTH_CACHE: dict = {}


def load_depth(out_dir) -> dict | None:
    """Team B's depth_views.json (meta plus rows) under <out>/depth_views/, or None when it was never built."""
    f = Path(out_dir) / DEPTH_FILE
    try:
        st = f.stat()
    except OSError:
        return None
    key = (str(f), st.st_mtime_ns, st.st_size)
    if _DEPTH_CACHE.get("key") != key:
        try:
            d = json.loads(f.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            return None
        _DEPTH_CACHE.clear()
        _DEPTH_CACHE.update(key=key, data=d)
    return _DEPTH_CACHE["data"]


def is_imf(row: dict) -> bool:
    """IMF-sourced (EXC-003): WEO pulls, dsa_inputs.csv (IMF Article IV estimates) or a route that says INTERNAL."""
    route, src = str(row.get("route") or ""), str(row.get("source") or "")
    return ("EXC-003" in route or "INTERNAL" in route or "imf-reader" in src or "WEO" in src
            or "dsa_inputs" in src)


def _num(v):
    try:
        f = float(v)
    except (TypeError, ValueError):
        return None
    return f if f == f and f not in (float("inf"), float("-inf")) else None


def depth_cell(row: dict | None, client: bool = False, built: bool = False) -> dict:
    """One depth row for display. `value` only when status == "value" (and, for a client, licence_class allowed)."""
    if row is None:
        return {"value": None, "status": "no_row" if built else "not_built", "shown": False, "unit": "", "year": None, "licence_class": "",
                "internal": False, "route": "", "note": "no depth row for this name"}
    status = str(row.get("status") or "")
    lic = str(row.get("licence_class") or "")
    internal = is_imf(row)
    shown = status == "value" and (not client or lic == "allowed")
    note = str(row.get("note") or "")[:300]
    if status == "value" and not shown:
        note = "withheld from client output (licence " + lic + ")"
    return {"value": _num(row.get("value")) if shown else None, "status": status, "shown": shown,
            "unit": str(row.get("unit") or ""), "year": row.get("year") if isinstance(row.get("year"), int) else None,
            "licence_class": lic, "internal": internal, "label": INTERNAL if internal else "",
            "route": str(row.get("route") or "")[:300], "note": note}


def _depth_index(depth: dict | None) -> dict:
    idx: dict = {}
    for r in (depth or {}).get("rows") or []:
        for metric, view, _l in DEPTH_METRICS:
            if r.get("metric") == metric and r.get("view") == view:
                idx[(r.get("country"), metric)] = r
    return idx


# ---------------------------------------------------------------- heatmap
def heatmap(out_dir, run: dict | None = None, run_id: str | None = None, client: bool = False,
            depth: dict | None = None) -> dict:
    """The heatmap payload (SCHEMA). Pillar values are run['pillars'][country][pid] unchanged."""
    if run is None:
        run = load_run(out_dir, run_id)
    if depth is None:
        depth = load_depth(out_dir)
    pillars = run.get("pillars") or {}
    if not isinstance(pillars, dict) or not pillars:
        raise HeatmapError("the run has no pillar scores")
    summ = run.get("summary") or {}
    cmap = {c.get("country"): c for c in run.get("country") or [] if isinstance(c, dict)}
    idx = _depth_index(depth)
    order = [c.get("country") for c in run.get("country") or [] if c.get("country") in pillars]
    order += [c for c in pillars if c not in order]
    rows = []
    for name in order:
        p = pillars.get(name) or {}
        c = cmap.get(name, {})
        rows.append({
            "country": str(name), "iso": str(c.get("iso") or ""), "composite": _num(c.get("composite")),
            "grade": c.get("grade"), "regime": str(c.get("regime") or ""), "pd_final": _num(c.get("pd_final")),
            "pillars": {str(k): _num(v) for k, v in p.items()},
            "bands": {str(k): band(_num(v)) for k, v in p.items()},
            "depth": {m: depth_cell(idx.get((name, m)), client, built=depth is not None) for m, _v, _l in DEPTH_METRICS},
        })
    n_depth = sum(1 for r in rows for m in r["depth"].values() if m["shown"])
    depth_meta = {"built": depth is not None, "schema": (depth or {}).get("schema"), "as_of": (depth or {}).get("as_of"),
                  "label": DEPTH_LABEL,
                  "message": ("Depth views as of " + str((depth or {}).get("as_of")) + ": " + str(n_depth)
                              + " values shown" + ("; client view: licence allowed values only" if client else "")
                              + ". Research views, display only; IMF-sourced values are INTERNAL.") if depth else
                             "Depth views not built yet; the depth columns stay empty until they are."}
    msg = (f"{len(rows)} countries x {sum(len(g[2]) for g in PILLAR_GROUPS)} pillars from run {summ.get('run_id')} "
           f"(as of {summ.get('as_of')}). Scores 0-100, higher is riskier.")
    return {"schema": SCHEMA, "run_id": summ.get("run_id"), "as_of": summ.get("as_of"), "client": bool(client),
            "groups": groups(), "depth_columns": [{"metric": m, "view": v, "label": lab} for m, v, lab in DEPTH_METRICS],
            "legend": [{"band": n, "from": lo, "to": min(hi, 100)} for lo, hi, n in BANDS],
            "rows": rows, "depth": depth_meta, "message": msg,
            "source": "run_latest.json pillars" if not run_id else "Store.load(run_id) pillars"}


# ---------------------------------------------------------------- drill-down
def _drivers(run: dict, country: str) -> dict:
    names = pillar_names()
    p = (run.get("pillars") or {}).get(country) or {}
    ranked = sorted(((str(k), _num(v)) for k, v in p.items() if _num(v) is not None), key=lambda kv: -kv[1])
    c = next((x for x in run.get("country") or [] if x.get("country") == country), {})
    feats = (run.get("layer1_model") or {}).get("features") or []
    dash = next((x for x in run.get("dashboard") or [] if x.get("country") == country), {})
    return {"pillars": [{"id": k, "name": names.get(k, k), "score": v, "band": band(v)} for k, v in ranked],
            "layer1_features": [{"name": str(f), "value": _num(c.get(f))} for f in feats if f in c],
            "top_signals": str(dash.get("top_signals") or "")[:300], "gpr_read": str(dash.get("gpr_read") or "")[:300],
            "note": "The run output has no per-indicator contribution; shown are the run's own pillar scores ranked, its "
                    "layer 1 feature values and the dashboard's top signals. Nothing here is recomputed."}


def _notes(out_dir, country: str) -> dict:
    out = {"notes": [], "archive": [], "message": ""}
    try:
        from .notes_view import list_notes
        for n in list_notes(out_dir).get("notes") or []:
            t = str(n.get("title") or "")
            if n.get("kind") == "country_note" and t.casefold().startswith(country.casefold()):
                out["notes"].append({"id": str(n.get("id")), "title": t[:200], "state": str(n.get("state") or "")})
    except Exception as e:                                # noqa: BLE001 - error type only, never a path
        out["message"] = f"notes view could not be read ({type(e).__name__})"
    try:
        from .archive import list_archive
        for a in list_archive(out_dir, product="country_note", country=country, latest_only=True)[:3]:
            out["archive"].append({"ref": str(a.get("ref")), "title": str(a.get("title") or "")[:200],
                                   "version": a.get("version"), "corrected": bool(a.get("corrected"))})
    except Exception as e:                                # noqa: BLE001
        out["message"] = (out["message"] + "; " if out["message"] else "") + f"archive could not be read ({type(e).__name__})"
    if not out["notes"] and not out["archive"] and not out["message"]:
        out["message"] = "No country note for this name in the research pack or the archive yet."
    return out


def _events(data_dir, iso: str, country: str, today, client: bool) -> dict:
    try:
        from .calendar_view import calendar_view
        v = calendar_view(data_dir, today=today, days=EVENT_DAYS, country=iso or country, client=client)
        return {"rows": v["rows"][:10], "count": v["count"], "message": v["message"]}
    except Exception as e:                                # noqa: BLE001 - error type only
        return {"rows": [], "count": 0, "message": f"event calendar could not be read ({type(e).__name__})"}


def statements(country: str, as_of, client: bool = False, root=None, n: int = STATEMENTS_N) -> dict:
    """Team A's corpus.latest: titles only (STATEMENTS_FIELDS), never body text. Client: client_ok and not synthetic."""
    try:
        from ..ingestion.text import corpus
        docs = corpus.latest(country, as_of, n, root=root) if root is not None else corpus.latest(country, as_of, n)
    except Exception as e:                                # noqa: BLE001 - an unknown name or no corpus is an empty panel
        return {"items": [], "message": STATEMENTS_EMPTY, "note": f"corpus not read ({type(e).__name__})"}
    items = []
    for d in docs or []:
        it = {k: d.get(k) for k in STATEMENTS_FIELDS}
        it["title"] = str(it["title"] or "")[:200]
        it["client_ok"] = it["client_ok"] is True
        it["synthetic"] = bool(it["synthetic"])
        if client and (not it["client_ok"] or it["synthetic"]):
            continue
        it["label"] = "SYNTHETIC" if it["synthetic"] else ("" if it["client_ok"] else INTERNAL)
        items.append(it)
    return {"items": items, "message": "" if items else STATEMENTS_EMPTY,
            "note": "Titles only; central bank and IMF texts are client-restricted until their terms are read."}


def depth_rows_for(depth: dict | None, country: str, client: bool = False) -> list[dict]:
    """The country's depth rows per view (panels), value only when status == "value"."""
    from ..validation.depth_views import MACRO_VIEWS, SOVEREIGN_VIEWS
    by: dict = {}
    for r in (depth or {}).get("rows") or []:
        if r.get("country") == country:
            c = depth_cell(r, client)
            c["metric"] = str(r.get("metric") or "")
            by.setdefault(str(r.get("view")), []).append(c)
    return [{"view": v, "kind": "sovereign" if v in SOVEREIGN_VIEWS else "macro", "rows": by.get(v, []),
             "message": "" if by.get(v) else "No rows for this name in this view."}
            for v in SOVEREIGN_VIEWS + MACRO_VIEWS]


def drilldown(out_dir, data_dir, country: str, today=None, client: bool = False, run: dict | None = None,
              run_id: str | None = None, depth: dict | None = None, corpus_root=None) -> dict:
    if run is None:
        run = load_run(out_dir, run_id)
    pillars = run.get("pillars") or {}
    match = next((c for c in pillars if c.casefold() == str(country).strip().casefold()), None)
    if match is None:
        cm = {str(c.get("iso") or "").upper(): c.get("country") for c in run.get("country") or []}
        match = cm.get(str(country).strip().upper())
    if match is None:
        raise HeatmapError("country must be a name or ISO3 code in the run")
    if depth is None:
        depth = load_depth(out_dir)
    iso = next((str(c.get("iso") or "") for c in run.get("country") or [] if c.get("country") == match), "")
    t = today or dt.datetime.now(dt.timezone.utc).date().isoformat()
    return {"country": match, "iso": iso, "today": str(t), "drivers": _drivers(run, match),
            "notes": _notes(out_dir, match), "events": _events(data_dir, iso, match, t, client),
            "statements": statements(match, t, client, root=corpus_root),
            "depth_label": DEPTH_LABEL, "depth": depth_rows_for(depth, match, client) if depth else [],
            "depth_message": "" if depth else "Depth views not built yet."}


# ---------------------------------------------------------------- M19 depth page
def depth_page(depth: dict | None, client: bool = False) -> dict:
    """One panel per view: rows, countries, status counts, routes (INTERNAL marked) and distinct notes. No values."""
    from ..validation.depth_views import MACRO_VIEWS, SOVEREIGN_VIEWS
    if not depth:
        return {"label": DEPTH_LABEL, "built": False, "panels": [], "plugins": [],
                "message": "Depth views not built yet.", "as_of": None, "schema": None}
    rows = depth.get("rows") or []
    plugins = [{"module": str(p.get("module")), "installed": p.get("installed") is True, "rows": p.get("rows")}
               for p in ((depth.get("info") or {}).get("plugins") or [])]
    panels = []
    for v in SOVEREIGN_VIEWS + MACRO_VIEWS:
        rs = [r for r in rows if r.get("view") == v]
        if client:
            rs = [r for r in rs if r.get("licence_class") == "allowed"]
        counts: dict = {}
        routes: dict = {}
        notes: dict = {}
        for r in rs:
            s = str(r.get("status"))
            counts[s] = counts.get(s, 0) + 1
            rt = str(r.get("route") or "")[:300]
            if rt not in routes:
                routes[rt] = {"route": rt, "internal": is_imf(r), "label": INTERNAL if is_imf(r) else "", "rows": 0}
            routes[rt]["rows"] += 1
            if s != "value":
                nt = str(r.get("note") or "")[:200]
                notes[(s, nt)] = notes.get((s, nt), 0) + 1
        panels.append({"view": v, "kind": "sovereign" if v in SOVEREIGN_VIEWS else "macro", "present": bool(rs),
                       "rows": len(rs), "countries": len({r.get("country") for r in rs}), "status_counts": counts,
                       "routes": list(routes.values()), "internal": any(x["internal"] for x in routes.values()),
                       "notes": [{"status": s, "note": n, "rows": k} for (s, n), k in
                                 sorted(notes.items(), key=lambda kv: -kv[1])[:6]]})
    return {"label": DEPTH_LABEL, "built": True, "schema": depth.get("schema"), "as_of": depth.get("as_of"),
            "client": bool(client), "panels": panels, "plugins": plugins,
            "message": f"{len(rows)} depth rows, {len({r.get('country') for r in rows})} names, as of "
                       f"{depth.get('as_of')}. Display only: nothing here feeds the scorecard, PDs, Monte Carlo or "
                       "limits. Values appear only where a row's status is value; IMF-sourced rows are INTERNAL."}


# ---------------------------------------------------------------- render
def _f(v, d=1) -> str:
    return "" if v is None else f"{v:.{d}f}"


def _depth_txt(c: dict) -> str:
    if c["shown"]:
        v = c["value"]
        s = f"{v:.2f}" if c["unit"] == "probability" else f"{v:.1f}"
        return s + (" INTERNAL" if c["internal"] else "")
    return c["status"].replace("_", " ")


def render_text(h: dict, drill: dict | None = None, page: dict | None = None) -> str:
    L = [f"Country risk heatmap: {h['message']}"]
    pid = [p["id"] for g in h["groups"] for p in g["pillars"]]
    L.append("Groups: " + "; ".join(f"{g['label']} = " + ", ".join(f"{p['id']} {p['name']}" for p in g["pillars"])
                                    for g in h["groups"]))
    L.append("Legend: " + ", ".join(f"{b['band']} {b['from']}-{b['to']:g}" for b in h["legend"]))
    L.append(f"{'country':<14}" + "".join(f"{'P' + p:>7}" for p in pid) + "".join(f"  {m['metric']:>22}" for m in h["depth_columns"]))
    for r in h["rows"]:
        L.append(f"{r['country'][:14]:<14}" + "".join(f"{_f(r['pillars'].get(p)):>7}" for p in pid)
                 + "".join(f"  {_depth_txt(r['depth'][m['metric']]):>22}" for m in h["depth_columns"]))
    L.append(h["depth"]["message"])
    if drill:
        d = drill
        L.append(f"\n{d['country']} ({d['iso']}): drivers")
        L += [f"  {p['id']} {p['name']}: {_f(p['score'])} ({p['band']})" for p in d["drivers"]["pillars"]]
        if d["drivers"]["top_signals"]:
            L.append(f"  top signals: {d['drivers']['top_signals']}")
        L.append("  " + d["drivers"]["note"])
        L.append("Country note: " + (", ".join(f"{n['title']} [{n['id']}, {n['state']}]" for n in d["notes"]["notes"])
                                     or d["notes"]["message"]))
        L += [f"  archive {a['ref']}: {a['title']}" for a in d["notes"]["archive"]]
        L.append(f"Upcoming events: {d['events']['message']}")
        L += [f"  {e['date']} {e['kind_label']}: {e['title']}" for e in d["events"]["rows"]]
        L.append("Recent statements: " + (d["statements"]["message"] or f"{len(d['statements']['items'])} titles"))
        L += [f"  {s['published_utc']} {s['source']}: {s['title']} {s['label']}".rstrip() for s in d["statements"]["items"]]
        L.append(f"Depth ({d['depth_label']}):" + (f" {d['depth_message']}" if d["depth_message"] else ""))
        for pnl in d["depth"]:
            L.append(f"  {pnl['view']}: " + ("; ".join(f"{c['metric']}{'@' + str(c['year']) if c['year'] else ''}="
                                                       f"{_depth_txt(c)}" for c in pnl["rows"][:12]) or pnl["message"]))
    if page:
        L.append(f"\n{page['label']}: {page['message']}")
        for p in page["panels"]:
            L.append(f"  [{p['kind']}] {p['view']}: {p['rows']} rows, {p['countries']} names, "
                     + ", ".join(f"{k} {v}" for k, v in sorted(p["status_counts"].items()))
                     + (" (INTERNAL rows)" if p["internal"] else ""))
            L += [f"    route{' INTERNAL' if r['internal'] else ''}: {r['route']} ({r['rows']})" for r in p["routes"]]
    return "\n".join(L) + "\n"


def _E(v) -> str:
    return html.escape(str(v))


def render_html(h: dict, drill: dict | None = None, page: dict | None = None) -> str:
    """A standalone page (no script); every value through html.escape; numbers printed in every cell."""
    pid = [p for g in h["groups"] for p in g["pillars"]]
    col = {"low": "#e8f3ec", "moderate": "#fdf3d8", "elevated": "#fbe0c2", "high": "#f5b7a8", "severe": "#d9786a"}
    head1 = "<th rowspan='2'>Country</th>" + "".join(f"<th colspan='{len(g['pillars'])}'>{_E(g['label'])}</th>"
                                                     for g in h["groups"]) + \
            f"<th colspan='{len(h['depth_columns'])}'>Depth ({_E(DEPTH_LABEL)})</th>"
    head2 = "".join(f"<th>{_E(p['id'] + ' ' + p['name'])}</th>" for p in pid) + \
        "".join(f"<th>{_E(m['label'])}</th>" for m in h["depth_columns"])
    body = []
    for r in h["rows"]:
        cells = "".join(f"<td style='background:{col.get(r['bands'].get(p['id']), '#fff')}' "
                        f"title='{_E(r['bands'].get(p['id'], ''))}'>{_E(_f(r['pillars'].get(p['id'])))}"
                        f" <small>{_E(r['bands'].get(p['id'], ''))}</small></td>" for p in pid)
        cells += "".join(f"<td>{_E(_depth_txt(r['depth'][m['metric']]))}</td>" for m in h["depth_columns"])
        body.append(f"<tr><th>{_E(r['country'])}</th>{cells}</tr>")
    legend = "".join(f"<li><span style='background:{col[b['band']]}'>&nbsp;&nbsp;&nbsp;</span> {_E(b['band'])}: "
                     f"{_E(b['from'])} to {_E(b['to'])}</li>" for b in h["legend"])
    parts = ["<!doctype html><html lang='en'><head><meta charset='utf-8'><title>Country risk heatmap</title>"
             "<style>body{font:14px sans-serif;margin:20px}table{border-collapse:collapse}td,th{border:1px solid #ccc;"
             "padding:3px 6px;text-align:right}th{background:#f4f6f9}small{color:#444}</style></head><body>",
             "<h1>Country risk heatmap <small>INTERNAL RESEARCH</small></h1>", f"<p>{_E(h['message'])}</p>",
             f"<table><thead><tr>{head1}</tr><tr>{head2}</tr></thead><tbody>{''.join(body)}</tbody></table>",
             f"<h3>Legend</h3><ul>{legend}</ul><p>{_E(h['depth']['message'])}</p>"]
    if drill:
        d = drill
        parts.append(f"<h2>{_E(d['country'])}</h2><h3>Drivers</h3><ul>"
                     + "".join(f"<li>{_E(p['id'] + ' ' + p['name'])}: {_E(_f(p['score']))} ({_E(p['band'])})</li>"
                               for p in d["drivers"]["pillars"]) + f"</ul><p>{_E(d['drivers']['note'])}</p>")
        parts.append("<h3>Recent statements</h3>" + (f"<p>{_E(d['statements']['message'])}</p>" if not d["statements"]["items"]
                     else "<ul>" + "".join(f"<li>{_E(s['title'])} {_E(s['label'])}</li>" for s in d["statements"]["items"]) + "</ul>"))
    if page:
        parts.append(f"<h2>{_E(page['label'])}</h2><p>{_E(page['message'])}</p>")
        for p in page["panels"]:
            parts.append(f"<h3>{_E(p['view'])} <small>{_E(p['kind'])}</small></h3><p>"
                         + _E(", ".join(f"{k}: {v}" for k, v in sorted(p["status_counts"].items())) or "no rows") + "</p><ul>"
                         + "".join(f"<li>{'<b>INTERNAL</b> ' if r['internal'] else ''}{_E(r['route'])} ({_E(r['rows'])})</li>"
                                   for r in p["routes"]) + "</ul>")
    parts.append("</body></html>")
    from .csp import harden
    return harden("".join(parts))      # meta CSP, hash-only styles (EQ-C-0165)


# ---------------------------------------------------------------- GET /api/heatmap
def _q(qs: dict, k: str) -> str:
    return str((qs.get(k) or [""])[0]).strip()


def api_heatmap(out_dir, data_dir, qs: dict) -> tuple[int, dict]:
    """GET /api/heatmap?country=&client=0|1&run_id=&today=&view=depth. (status, body); a bad parameter is 400
    {"error"} with a fixed message. Read only: never runs the model or builds the depth views."""
    try:
        client = _q(qs, "client")
        if client not in ("", "0", "1"):
            raise HeatmapError("client must be 0 or 1")
        country = _q(qs, "country")
        if country and not _COUNTRY.match(country):
            raise HeatmapError("country must be a name or ISO3 code in the run")
        today = _q(qs, "today")
        if today:
            if not _DATE.match(today):
                raise HeatmapError("today must be YYYY-MM-DD")
            try:
                dt.date.fromisoformat(today)
            except ValueError:
                raise HeatmapError("today must be YYYY-MM-DD") from None
        view = _q(qs, "view")
        if view not in ("", "depth"):
            raise HeatmapError("view must be depth or left out")
        run_id = _q(qs, "run_id") or None
        cl = client == "1"
        depth = load_depth(out_dir)
        if view == "depth":
            return 200, depth_page(depth, cl)
        run = load_run(out_dir, run_id)
        body = heatmap(out_dir, run=run, run_id=run_id, client=cl, depth=depth)
        if country:
            body["drill"] = drilldown(out_dir, data_dir, country, today or None, cl, run=run, depth=depth)
        return 200, body
    except HeatmapError as e:
        return 400, {"error": str(e)}
    except Exception as e:                                # noqa: BLE001 - error type only, never a path
        return 200, {"error": f"heatmap could not be built ({type(e).__name__})", "rows": []}


# ---------------------------------------------------------------- demos
def _abs_path_in(obj, roots: tuple[str, ...]) -> bool:
    s = json.dumps(obj, default=str)
    return any(r and r in s for r in roots) or bool(re.search(r'"(/mnt|/home|/Users|/tmp|[A-Z]:\\\\)', s))


def demo_heatmap(out_dir, data_dir=None, run_id: str | None = None, today=None) -> dict:
    """Heatmap demo on <out_dir> (its run_latest.json or a stored run): pillar values equal the run's `pillars`, each
    pillar sits in exactly one group, every row carries the depth columns, the drill-down renders for every country
    (statements: titles only or the empty-state sentence), no absolute path; writes <out_dir>/heatmap/heatmap.{json,html}.
    {"ok", "problems", "summary"}; never raises."""
    from ..cli import DEFAULT_DATA
    problems: list[str] = []
    summary = "heatmap not built"
    data = Path(data_dir) if data_dir else Path(DEFAULT_DATA)
    try:
        run = load_run(out_dir, run_id)
        depth = load_depth(out_dir)
        h = heatmap(out_dir, run=run, run_id=run_id, depth=depth)
        src = run.get("pillars") or {}
        for r in h["rows"]:
            for k, v in (src.get(r["country"]) or {}).items():
                if r["pillars"].get(str(k)) != _num(v):
                    problems.append(f"{r['country']} pillar {k} differs from the run"); break
            if set(r["depth"]) != {m for m, _v, _l in DEPTH_METRICS}:
                problems.append(f"{r['country']}: depth columns missing")
            for c in r["depth"].values():
                if c["value"] is not None and c["status"] != "value":
                    problems.append(f"{r['country']}: a value shown for status {c['status']}")
        placed = sorted(int(p["id"]) for g in h["groups"] for p in g["pillars"])
        if placed != sorted(int(k) for k in pillar_names()):
            problems.append("pillar grouping does not cover each pillar exactly once")
        drills = []
        for r in h["rows"]:
            d = drilldown(out_dir, data, r["country"], today, run=run, depth=depth)
            st = d["statements"]
            if not st["items"] and st["message"] != STATEMENTS_EMPTY:
                problems.append(f"{r['country']}: statements panel has no empty-state sentence")
            if any(set(i) - set(STATEMENTS_FIELDS) - {"label"} for i in st["items"]):
                problems.append(f"{r['country']}: statement carries a field beyond the title")
            drills.append(d)
        if _abs_path_in({"h": h, "d": drills}, (str(Path(out_dir).resolve()), str(data.resolve()))):
            problems.append("an absolute path reached the payload")
        d0 = drills[0] if drills else None
        text, page = render_text(h, d0), render_html(h, d0)
        d = Path(out_dir) / OUT_SUB
        d.mkdir(parents=True, exist_ok=True)
        (d / "heatmap.json").write_text(json.dumps({"heatmap": h, "drill": drills}, indent=1, default=str), encoding="utf-8")
        (d / "heatmap.html").write_text(page, encoding="utf-8")
        (d / "heatmap.txt").write_text(text, encoding="utf-8")
        shown = sum(1 for r in h["rows"] for c in r["depth"].values() if c["shown"])
        n_st = sum(len(x["statements"]["items"]) for x in drills)
        summary = (f"heatmap: {len(h['rows'])} countries x 7 pillars (geopolitical 2, sovereign 3, macro 2) from run "
                   f"{h['run_id']} (as of {h['as_of']}); depth {'as of ' + str(h['depth']['as_of']) if depth else 'not built'}, "
                   f"{shown} of {3 * len(h['rows'])} depth values shown; statements {n_st or 'empty'}")
    except Exception as e:                                # noqa: BLE001 - reported, never a silent pass
        problems.append(f"{type(e).__name__}: {e}"[:300])
    if problems:
        summary += f"; {len(problems)} problems"
    return {"ok": not problems, "problems": problems, "summary": summary}


def demo_depth_page(out_dir, data_dir=None, as_of: str | None = None, build: bool = True) -> dict:
    """M19: Team B's demo_depth_views(<out_dir>) (when build, else the depth_views.json already there), then the page.
    Passes when ok is true, every SOVEREIGN_VIEWS panel is present, the macro views are present when
    info.plugins[*].installed, no value is shown for a status other than value, and IMF-sourced routes carry INTERNAL.
    Writes <out_dir>/heatmap/depth_page.{json,html}. {"ok", "problems", "summary"}; never raises."""
    from ..validation import depth_views as DV
    problems: list[str] = []
    summary = "M19 depth page not built"
    try:
        if build:
            r = DV.demo_depth_views(out_dir, data_dir, as_of)
            if not r.get("ok"):
                problems += [f"depth views: {p}" for p in (r.get("problems") or ["not ok"])][:20]
        depth = load_depth(out_dir)
        if depth is None:
            raise HeatmapError("depth_views.json is missing")
        page = depth_page(depth)
        present = {p["view"] for p in page["panels"] if p["present"]}
        problems += [f"sovereign view {v} missing" for v in DV.SOVEREIGN_VIEWS if v not in present]
        macro_on = any(p["installed"] for p in page["plugins"])
        if macro_on:
            problems += [f"macro view {v} missing" for v in DV.MACRO_VIEWS if v not in present]
        for p in page["panels"]:
            for rt in p["routes"]:
                if ("EXC-003" in rt["route"]) and rt["label"] != INTERNAL:
                    problems.append(f"{p['view']}: IMF route not marked INTERNAL")
        names = sorted({r.get("country") for r in depth.get("rows") or []})
        for n in names:                                   # every status renders, names with only not_available too
            for pnl in depth_rows_for(depth, n):
                for c in pnl["rows"]:
                    if c["value"] is not None and c["status"] != "value":
                        problems.append(f"{n} {pnl['view']}: value shown for status {c['status']}")
        if _abs_path_in(page, (str(Path(out_dir).resolve()),)):
            problems.append("an absolute path reached the page")
        d = Path(out_dir) / OUT_SUB
        d.mkdir(parents=True, exist_ok=True)
        (d / "depth_page.json").write_text(json.dumps(page, indent=1, default=str), encoding="utf-8")
        h = {"groups": groups(), "depth_columns": [], "rows": [], "legend": [], "message": "", "depth": {"message": ""}}
        (d / "depth_page.html").write_text(render_html(h, None, page), encoding="utf-8")
        summary = (f"M19 depth page: {len(present)} views ({', '.join(v for v in DV.SOVEREIGN_VIEWS + DV.MACRO_VIEWS if v in present)}), "
                   f"{sum(p['rows'] for p in page['panels'])} rows, {len(names)} names, as of {page['as_of']}; "
                   f"macro plug-in {'installed' if macro_on else 'not installed'}")
    except Exception as e:                                # noqa: BLE001
        problems.append(f"{type(e).__name__}: {e}"[:300])
    if problems:
        summary += f"; {len(problems)} problems"
    return {"ok": not problems, "problems": problems, "summary": summary}


# ---------------------------------------------------------------- CLI
def cmd_heatmap(args) -> None:
    out, data = Path(args.out), Path(args.data)
    try:
        if args.build_depth:
            from ..validation.depth_views import demo_depth_views
            r = demo_depth_views(out, data)
            print(f"[heatmap] depth views built: ok {r['ok']}, {r['summary'].get('rows')} rows", file=sys.stderr)
        run = load_run(out, args.run_id)
        depth = load_depth(out)
        h = heatmap(out, run=run, run_id=args.run_id, client=args.client, depth=depth)
        d = drilldown(out, data, args.country, args.today, args.client, run=run, depth=depth) if args.country else None
        page = depth_page(depth, args.client) if args.depth else None
    except HeatmapError as e:
        print(f"[heatmap] {e}", file=sys.stderr)
        sys.exit(2)
    if args.html:
        Path(args.html).write_text(render_html(h, d, page), encoding="utf-8")
        print(f"[heatmap] wrote {Path(args.html).name}", file=sys.stderr)
    if args.json:
        print(json.dumps({**h, **({"drill": d} if d else {}), **({"depth_page": page} if page else {})}, indent=1,
                         default=str))
    elif not args.html:
        print(render_text(h, d, page), end="")


def register(sub) -> None:
    hm = sub.add_parser("heatmap", help="country risk heatmap (EQ-C-0156): the run's seven pillar scores grouped "
                        "geopolitical / sovereign / macro, depth columns from Team B's depth views, drill-down per "
                        "country and the M19 depth page; read only",
                        description="Country risk heatmap (read only): pillar scores from the run, never recomputed.")
    from ..cli import _as_of_arg
    hm.add_argument("--country", help="drill down into one country (name or ISO3 in the run)")
    hm.add_argument("--client", action="store_true", help="client view: only licence-allowed depth values and statements")
    hm.add_argument("--run-id", help="pin a stored run (Store.load) instead of run_latest.json")
    hm.add_argument("--today", type=_as_of_arg, help="date for upcoming events and statements, YYYY-MM-DD (default today, UTC)")
    hm.add_argument("--depth", action="store_true", help=f"add the M19 depth page ({DEPTH_LABEL})")
    hm.add_argument("--build-depth", action="store_true", help="first rebuild <out>/depth_views/ with Team B's "
                    "demo_depth_views (about 20-30 s; never writes data/)")
    hm.add_argument("--json", action="store_true", help=f"print the payload as JSON ({SCHEMA})")
    hm.add_argument("--html", metavar="OUT", help="write a standalone HTML page to OUT")
    hm.set_defaults(fn=cmd_heatmap)
