"""Forecast Record tab plan: the daily record as values, newest first, with a header and the backtest summary."""
from __future__ import annotations
import numpy as np
import pandas as pd
from ..validation.backtests import backtest_history
from ..validation.record import record_for_backtest
from ..common_format import sanitize_plan

COLS = ["date", "loss", "var", "es", "var_next", "es_next", "var99_12m", "es99_12m", "regime", "marked_positions", "marked_notional_mm", "code_hash", "data_hash", "recorded_at"]
HEAD = ["Date", "Realised loss $mm", "VaR99 1d forecast for the day", "ES99 1d forecast for the day", "VaR99 1d for next day", "ES99 1d for next day",
        "VaR99 12m (MC)", "ES99 12m (MC)", "Global regime", "Positions marked", "Notional marked $mm", "Code version", "Data version", "Recorded at"]


def _v(x):
    if isinstance(x, pd.Timestamp):
        return x.date().isoformat()
    if isinstance(x, (float, np.floating)):
        return None if not np.isfinite(x) else round(float(x), 4)
    if x is None or (isinstance(x, float) and np.isnan(x)):
        return None
    return x


def record_plan(rec: pd.DataFrame, sheet: str = "Forecast Record") -> list[dict]:
    rec = rec.sort_values("date", ascending=False)
    bt = record_for_backtest(rec)
    lines = [["Forecast Record: one row per trading day, written by econquest record. Loss is the book marked on Market History prices (FX, local-bond and equity positions); VaR/ES are the one-day 99% GARCH-DCC forecasts made the previous trading day."],
             [f"Rows: {len(rec)}; rows with a forecast to test: {len(bt)}. " + (
                 "Backtests: " + "; ".join(f"{k} {v}" for k, v in _bt_summary(bt).items()) if len(bt) >= 20 else "Backtests start at 20 rows; the Basel zone is meaningful from 250.")]]
    body = [HEAD] + [[_v(r[c]) for c in COLS] for _, r in rec.iterrows()]
    return sanitize_plan([{"range": f"'{sheet}'!A1:A2", "values": lines}, {"range": f"'{sheet}'!A4:N{4 + len(body) - 1}", "values": body}])


def _bt_summary(bt: pd.DataFrame) -> dict:
    r = backtest_history(bt, alpha=0.99)
    return {"Kupiec p": round(r["kupiec"]["p_value"], 3), "Christoffersen p": round(r["christoffersen"]["p_value_cc"], 3),
            "Acerbi-Szekely": "pass" if r["acerbi_szekely"]["pass"] else "fail", "Basel": r["basel_zone"], "verdict": r["verdict"]}
