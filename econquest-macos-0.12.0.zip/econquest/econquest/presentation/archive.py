"""Research archive (EQ-C-0154, PI-13, demo row M20): every published research product version kept immutable, with
corrections, disclosures and a local full-text search. INTERNAL: the archive is the desk's own record.

Layout under <out>/archive/ (outputs/archive/ by default):

    index.jsonl                         append-only, hash-chained index: one row per archived version
    index.head.json                     last seq and row_hash (rows removed from the end are caught)
    index.head.hmac.json                keyed seal, only when ledger_keyed_heads is on (ops/ledger_key.py)
    search.sqlite                       derived full-text index; rebuilt from the archive whenever the chain head moves
    <product>/<id>/v<N>/                one immutable version (files 0444, folder 0555)
        <the product files>             HTML/Markdown/text carry the disclosure block, v2+ also the correction banner
        manifest.json                   eq-archive/1: id, version, product, subject, country, period, title, licence,
                                        run_id, code_hash, files with sha256 (archived and source), disclosure, correction
        DISCLOSURE.txt                  the standard disclosure block as text
        CORRECTION.json                 v2+: what changed, why, who, UTC

Ids are stable per product, subject (the country for a country note, else the scenario or "all") and period
(YYYY-MM-DD): `<product>-<subject>-<period>`, e.g. country_note-argentina-2026-10-23. `add` archives v1 (adding the
same files again is a no-op); a change is `correct`, which writes v<N+1> with a correction note and a visible
"Corrected on ..." banner. A version folder is never rewritten: v1 stays byte-identical after any correction.

Disclosure block (every version): research.INTERNAL_TEXT, report.DISCLAIMER (the governed core the editorial and
compliance checks look for), the conflicts declaration ("None declared." unless given), the licence label and the
licence attribution lines the product itself carries (presentation/licences.py block, parsed with
notes_view.parse_note).

Licence labels are carried, never raised: a version is "client-safe" only when every HTML file is a client-safe draft
(research block data-client-safe="draft") whose licence block says data-licence-client-ok="true" and lists no
internal-only content, and no other text file is present; anything else is "internal-only". A caller may narrow a
label to internal-only, never widen it. search(audience="client") returns client-safe versions only; the GUI route
and the CLI search the internal archive.

Search: sqlite FTS5 (bm25, title weighted 10:1) when the interpreter's sqlite has it, otherwise an in-memory inverted
index with the same AND semantics. Queries are reduced to word tokens (\\w+, optional trailing * for a prefix), quoted
for MATCH, so no FTS operator, column filter or SQL reaches sqlite from user input. Filters: product, country, date
range on the period, latest-only; client audience. Results carry the version, a corrected flag, a relative ref
(<product>/<id>/v<N>) and file names, never an absolute path.

verify(out_dir): the chain (seq, prev_hash, row_hash, head, keyed seal), every indexed version's manifest hash, file
hashes, disclosure, correction note and banner, versions contiguous from v1, and nothing on disk that the index does
not name.

demo_archive(out_dir) -> {"ok", "problems", "summary", ...}: demo row M20 (EQ-C-0158), on a built research pack.

Fail closed (EQ-C-0164): add/correct refuse to append to an index that fails the chain check (a torn or edited line,
a cut tail, a head left behind by a killed write) or whose time would go backwards by more than 10 minutes on the
wall clock; the new version folder is then removed. outputs/archive is in the nightly backup (ops/backup.SOURCES).
"""
from __future__ import annotations

import contextlib
import datetime as dt
import hashlib
import html as _h
import json
import math
import os
import re
import shutil
import sqlite3
import stat
import tempfile
import unicodedata
from pathlib import Path

try:                                    # POSIX only; elsewhere writes are unlocked
    import fcntl
except ImportError:                     # pragma: no cover
    fcntl = None

TICKET = "EQ-C-0154"
SCHEMA = "eq-archive/1"
ARCHIVE_REL = "archive"
INDEX_NAME, HEAD_NAME = "index.jsonl", "index.head.json"
SEAL_NAME = "index.head.hmac.json"               # ops.ledger_key.SEAL_NAMES["archive"]
SEARCH_DB = "search.sqlite"
SEARCH_SCHEMA = "eq-archive-search/1"
SEARCH_DB_VERSION = SEARCH_SCHEMA + ";drafts-signed-only"   # EQ-C-0176: a cache built before the draft filter is rebuilt
DRAFT_TAG = "-assistant-draft-"                     # EQ-B-0148 assistant draft items (validation.assistant_drafts)
LEDGER = "archive"
GENESIS = "0" * 64
PRODUCTS = ("country_note", "scenario_brief", "weekly_brief", "trade_ideas", "daily_report", "weekly_monitor",
            "house_view")
PRODUCT_LABELS = {"country_note": "Country note", "scenario_brief": "Scenario brief", "weekly_brief": "Weekly brief",
                  "trade_ideas": "Trade ideas", "daily_report": "Daily report", "weekly_monitor": "Weekly monitor",
                  "house_view": "House view"}
LICENCES = ("internal-only", "client-safe")
TEXT_SUFFIXES = (".html", ".htm", ".md", ".txt")
SUFFIXES = TEXT_SUFFIXES + (".json", ".csv", ".pdf")
RESERVED = {"manifest.json", "DISCLOSURE.txt", "CORRECTION.json"}
MAX_FILES, MAX_FILE_BYTES, MAX_TEXT, MAX_BODY = 20, 20_000_000, 1000, 2_000_000
MAX_QUERY, MAX_TERMS, MAX_TERM, MAX_LIMIT = 200, 12, 64, 100
NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,159}$")
ID_RE = re.compile(r"^[a-z_]{3,20}-[a-z0-9][a-z0-9-]{0,59}-\d{4}-\d{2}-\d{2}$")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
STAMP_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.:-]{0,79}$")
COUNTRY_RE = re.compile(r"^[\w .'()-]{1,60}$")
VER_RE = re.compile(r"^v([1-9]\d{0,5})$")
_CTRL = re.compile("[\\x00-\\x1f\\x7f\\x85\\u2028\\u2029]")
_BODY = re.compile(r"<body\b[^>]*>", re.I)
_BODY_END = re.compile(r"</body\s*>", re.I)
DISCLOSURE_START, DISCLOSURE_END = "<!-- econquest:archive-disclosure -->", "<!-- /econquest:archive-disclosure -->"
BANNER_START, BANNER_END = "<!-- econquest:archive-correction -->", "<!-- /econquest:archive-correction -->"
NO_SOURCE_LINE = "No licensed source recorded for this product's inputs."
CONFLICTS_NONE = "None declared."


class ArchiveError(ValueError):
    """A refused archive add, correct or lookup."""


# ---------------------------------------------------------------- paths, text, hashing
def archive_root(out_dir) -> Path:
    return Path(out_dir) / ARCHIVE_REL


def _sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def _ts(now: dt.datetime | None = None) -> str:
    now = now or dt.datetime.now(dt.timezone.utc)
    now = now.replace(tzinfo=dt.timezone.utc) if now.tzinfo is None else now.astimezone(dt.timezone.utc)
    return now.strftime("%Y-%m-%dT%H:%M:%SZ")


def _text(v, what: str, required: bool = True, cap: int = MAX_TEXT) -> str:
    s = " ".join(_CTRL.sub(" ", unicodedata.normalize("NFKC", "" if v is None else str(v))).split())
    if required and not s:
        raise ArchiveError(f"{what} is required")
    if len(s) > cap:
        raise ArchiveError(f"{what} is longer than {cap} characters")
    return s


def _person(v, what: str = "--by") -> str:
    from ..ingestion.ledger import clean_person
    s = _text(clean_person(v), what, cap=120)
    return s


def slug(v) -> str:
    s = unicodedata.normalize("NFKD", str(v or "")).encode("ascii", "ignore").decode().casefold()
    return re.sub(r"[^a-z0-9]+", "-", s).strip("-")[:60].strip("-") or "all"


def parse_period(v) -> str:
    s = str(v or "").strip()
    if not DATE_RE.match(s):
        raise ArchiveError("period must be YYYY-MM-DD")
    try:
        dt.date.fromisoformat(s)
    except ValueError:
        raise ArchiveError("period must be a real date (YYYY-MM-DD)") from None
    return s


def make_id(product: str, subject, period) -> str:
    if product not in PRODUCTS:
        raise ArchiveError(f"product must be one of {', '.join(PRODUCTS)}")
    return f"{product}-{slug(subject)}-{parse_period(period)}"


def _check_id(item_id) -> str:
    s = str(item_id or "")
    if not ID_RE.match(s) or s.split("-", 1)[0] not in PRODUCTS:
        raise ArchiveError("not an archive id (<product>-<subject>-<YYYY-MM-DD>)")
    return s


def _stamp(v, what: str) -> str:
    s = str(v or "").strip()
    if not STAMP_RE.match(s):
        raise ArchiveError(f"{what} is required (letters, digits, _ . : -)")
    return s


@contextlib.contextmanager
def _locked(root: Path):
    root.mkdir(parents=True, exist_ok=True)
    with open(root / ".lock", "a") as f:
        if fcntl is not None:
            fcntl.flock(f.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            if fcntl is not None:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)


def _atomic_write(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp, path)
    except BaseException:
        with contextlib.suppress(OSError):
            os.unlink(tmp)
        raise


def _unlock_tree(path: Path) -> None:
    """Make a temp copy of the archive removable again (version folders are 0555)."""
    for d, _dirs, _files in os.walk(path):
        with contextlib.suppress(OSError):
            os.chmod(d, 0o700)


def _rmtree_ro(path: Path) -> None:
    """Remove an unfinished version folder (only ever this module's own temp or just-created folder)."""
    if not path.exists():
        return
    os.chmod(path, 0o700)
    for p in path.iterdir():
        os.chmod(p, 0o600)
    shutil.rmtree(path, ignore_errors=True)


# ---------------------------------------------------------------- index (hash chain)
def _row_hash(prev: str, row: dict) -> str:
    from ..ops.approvals import row_hash
    return row_hash(prev, row)


def read_index(out_dir) -> list[dict]:
    p = archive_root(out_dir) / INDEX_NAME
    rows = []
    if p.is_file():
        for line in p.read_text(encoding="utf-8").splitlines():
            if line.strip():
                try:
                    r = json.loads(line)
                except json.JSONDecodeError:
                    r = {}
                rows.append(r if isinstance(r, dict) else {})
    return rows


def _head(rows: list[dict]) -> tuple[int, str]:
    last = next((r for r in reversed(rows) if r.get("row_hash")), None)
    return (int(last.get("seq") or 0), str(last["row_hash"])) if last else (0, GENESIS)


def _chain_errors(root: Path) -> tuple[list[str], list[dict]]:
    from ..ops import ledger_key
    p = root / INDEX_NAME
    errors, rows, prev = [], [], GENESIS
    lines = p.read_text(encoding="utf-8").splitlines() if p.is_file() else []
    for i, line in enumerate(lines, 1):
        if not line.strip():
            errors.append(f"index line {i}: blank line"); continue
        try:
            r = json.loads(line)
            if not isinstance(r, dict):
                raise ValueError
        except ValueError:
            errors.append(f"index line {i}: not a JSON object"); prev = None; continue
        if r.get("seq") != len(rows) + 1:
            errors.append(f"index line {i}: seq {r.get('seq')} where {len(rows) + 1} expected (row deleted, inserted or moved)")
        if prev is not None and r.get("prev_hash") != prev:
            errors.append(f"index line {i}: prev_hash does not match the previous row (row deleted, inserted or moved)")
        if r.get("row_hash") != _row_hash(str(r.get("prev_hash", "")), r):
            errors.append(f"index line {i}: row_hash does not recompute (row edited)")
        prev = r.get("row_hash")
        rows.append(r)
    hp = root / HEAD_NAME
    tip = rows[-1] if rows else {"seq": 0, "row_hash": GENESIS}
    if hp.is_file():
        try:
            head = json.loads(hp.read_text(encoding="utf-8"))
        except (OSError, ValueError):
            head = None
            errors.append(f"{HEAD_NAME} is not JSON")
        if isinstance(head, dict) and (head.get("seq") != tip.get("seq") or head.get("row_hash") != tip.get("row_hash")):
            errors.append(f"{HEAD_NAME} names seq {head.get('seq')} but the index ends at seq {tip.get('seq')} "
                          "(rows removed from or added to the end)")
    elif rows:
        errors.append(f"{HEAD_NAME} missing")
    errors += ledger_key.check(LEDGER, root / SEAL_NAME, tip.get("seq") or 0, tip.get("row_hash"))
    return errors, rows


CLOCK_SKEW_TOLERANCE = dt.timedelta(minutes=10)


def _require_clean_index(root: Path, ts_utc: str | None) -> list[dict]:
    """EQ-C-0164: never extend a damaged index. Refuses (ArchiveError, nothing appended) when the chain, head or seal
    fail (_chain_errors: a truncated or edited line, a cut tail, a lagging head after a killed write), when the file
    does not end in a newline (a torn last write), or when the new row's time is more than CLOCK_SKEW_TOLERANCE
    before the last row's (the clock went back: versions would be dated out of order)."""
    errors, rows = _chain_errors(root)
    p = root / INDEX_NAME
    if p.is_file() and p.stat().st_size and not p.read_bytes().endswith(b"\n"):
        errors.append(f"{INDEX_NAME} does not end with a newline (a write was cut off)")
    if errors:
        raise ArchiveError("research archive index fails verification, nothing archived: " + "; ".join(errors[:3])
                           + " (econquest archive verify; restore outputs/archive from the backup, "
                           "docs/runbooks/C-chaos-and-perf.md)")
    last = str(rows[-1].get("ts_utc") or "") if rows else ""
    if last and ts_utc:
        try:
            a = dt.datetime.strptime(ts_utc, "%Y-%m-%dT%H:%M:%SZ")
            b = dt.datetime.strptime(last, "%Y-%m-%dT%H:%M:%SZ")
        except ValueError:
            a = b = None
        if a and b and a < b - CLOCK_SKEW_TOLERANCE:
            raise ArchiveError(f"clock skew: this version would be stamped {ts_utc}, before the archive's last entry "
                               f"{last}; nothing archived. Check the system clock (date -u) and retry")
    return rows


def _append(root: Path, row: dict, wall_clock: bool = True) -> dict:
    from ..ops import ledger_key
    rows = _require_clean_index(root, row.get("ts_utc") if wall_clock else None)   # an explicit `now` is the caller's
    seq, prev = _head(rows)
    row = {"seq": len(rows) + 1, **row, "prev_hash": prev}
    row["row_hash"] = _row_hash(prev, row)
    with open(root / INDEX_NAME, "a", encoding="utf-8") as f:
        f.write(json.dumps(row, ensure_ascii=False) + "\n"); f.flush(); os.fsync(f.fileno())
    _atomic_write(root / HEAD_NAME, (json.dumps({"seq": row["seq"], "row_hash": row["row_hash"]}) + "\n").encode())
    ledger_key.seal(LEDGER, root / SEAL_NAME, row["seq"], row["row_hash"])     # no-op unless keyed heads are on
    return row


def items(out_dir) -> dict[str, dict]:
    """{id: {id, product, subject, country, period, title, licence, versions: [index rows in order]}} from the index."""
    out: dict[str, dict] = {}
    for r in read_index(out_dir):
        if not r.get("id"):
            continue
        it = out.setdefault(r["id"], {k: r.get(k) for k in ("id", "product", "subject", "country", "period")} | {"versions": []})
        it["versions"].append(r)
        it["title"], it["licence"] = r.get("title"), r.get("licence")
    return out


# ---------------------------------------------------------------- reading products: text, licence, attribution
def _strip_injected(text: str) -> str:
    for a, b in ((DISCLOSURE_START, DISCLOSURE_END), (BANNER_START, BANNER_END)):
        text = re.sub(re.escape(a) + ".*?" + re.escape(b), " ", text, flags=re.S)
    return text


def _flatten(blocks: list[dict]) -> tuple[str, str]:
    """(first h1 text, body text) from notes_view text blocks."""
    title, parts = "", []
    for b in blocks:
        t = b.get("t")
        if t == "h":
            if not title and b.get("level") == 1:
                title = b.get("text") or ""
            parts.append(b.get("text") or "")
        elif t == "p":
            parts.append(b.get("text") or "")
        elif t == "list":
            parts += [str(x) for x in b.get("items") or []]
        elif t == "kpi":
            parts.append(" ".join(str(x) for x in b.get("parts") or []))
        elif t == "table":
            parts += [" ".join(c.get("text") or "" for c in row) for row in b.get("rows") or []]
    return title, "\n".join(p for p in parts if p)


def read_product(name: str, data: bytes) -> dict:
    """{"title", "body", "attribution", "internal_only", "client_safe"} of one product file (searchable text only)."""
    suffix = Path(name).suffix.lower()
    if suffix not in TEXT_SUFFIXES:
        return {"title": "", "body": "", "attribution": [], "internal_only": [], "client_safe": None}
    text = data.decode("utf-8", errors="replace")
    if suffix in (".html", ".htm"):
        from .notes_view import parse_note
        raw = text
        p = parse_note(_strip_injected(text)[:MAX_BODY * 3])
        title, body = _flatten(p["blocks"])
        body = "\n".join(x for x in (p.get("marking") or "", body) if x)
        ok = re.search(r'data-licence-client-ok="(true|false)"', raw)
        cs = ('data-client-safe="draft"' in raw and bool(ok) and ok.group(1) == "true" and not p["internal_only"])
        return {"title": title, "body": body[:MAX_BODY], "attribution": p["attribution"], "internal_only": p["internal_only"],
                "client_safe": cs}
    text = _strip_injected(text)
    m = re.search(r"^#\s+(.+)$", text, re.M)
    attr, internal, sect = [], [], None
    for line in text.splitlines():                      # licences.block_md: "**Sources and licences.**" then "- line"
        s = line.strip()
        if s.startswith("**Sources and licences"):
            sect = attr
        elif s.startswith("**Internal-only content"):
            sect = internal
        elif sect is not None and s.startswith("- "):
            sect.append(s[2:].strip())
        elif sect is not None and s and not s.startswith("- "):
            sect = None
    return {"title": m.group(1).strip() if m else "", "body": text[:MAX_BODY], "attribution": attr,
            "internal_only": internal, "client_safe": False}


def _licence_of(reads: list[tuple[str, dict]]) -> str:
    """Most restrictive: client-safe only when every text file is an HTML client-safe draft (see module docstring)."""
    text = [(n, r) for n, r in reads if Path(n).suffix.lower() in TEXT_SUFFIXES]
    if text and all(Path(n).suffix.lower() in (".html", ".htm") and r["client_safe"] for n, r in text):
        return "client-safe"
    return "internal-only"


def disclosure(attribution: list[str], licence: str, conflicts: str | None = None, internal_only: list[str] | None = None) -> dict:
    from .report import DISCLAIMER
    from .research import INTERNAL_TEXT
    return {"internal_research": INTERNAL_TEXT, "disclaimer": DISCLAIMER,
            "conflicts": conflicts or CONFLICTS_NONE, "licence": licence,
            "attribution": list(dict.fromkeys(a for a in attribution if a)) or [NO_SOURCE_LINE],
            "internal_only": list(dict.fromkeys(internal_only or []))[:50]}


def disclosure_text(d: dict) -> str:
    L = ["DISCLOSURES", d["internal_research"], d["disclaimer"], f"Conflicts of interest: {d['conflicts']}",
         f"Licence: {d['licence']} (archive: internal research)", "Sources and licences:"]
    L += [f"- {a}" for a in d["attribution"]]
    if d.get("internal_only"):
        L += ["Internal-only content (not for client output):"] + [f"- {x}" for x in d["internal_only"]]
    return "\n".join(L) + "\n"


def disclosure_html(d: dict) -> str:
    e = _h.escape
    attr = "".join(f"<li>{e(a)}</li>" for a in d["attribution"])
    io = ("<p><b>Internal-only content (not for client output):</b></p><ul>" + "".join(f"<li>{e(x)}</li>" for x in d["internal_only"])
          + "</ul>") if d.get("internal_only") else ""
    return (f"{DISCLOSURE_START}<div class=\"archive-disclosure\" role=\"note\" data-archive-licence=\"{e(d['licence'])}\" "
            "style=\"border:1px solid #888;padding:6px 10px;margin:12px 0;font-size:12px\"><b>Disclosures.</b> "
            f"<p>{e(d['internal_research'])}</p><p>{e(d['disclaimer'])}</p><p>Conflicts of interest: {e(d['conflicts'])}</p>"
            f"<p>Licence: {e(d['licence'])} (archive: internal research)</p><p>Sources and licences:</p><ul>{attr}</ul>{io}"
            f"</div>{DISCLOSURE_END}")


def banner_text(c: dict, item_id: str) -> str:
    return (f"Corrected on {c['utc'][:10]} {c['utc'][11:16]} UTC: version {c['version']} of {item_id} replaces version "
            f"{c['version'] - 1} (earlier versions are kept unchanged in the archive). What changed: {c['what']} "
            f"Why: {c['why']} By: {c['by']}.")


def banner_html(c: dict, item_id: str) -> str:
    return (f"{BANNER_START}<div class=\"correction-banner\" role=\"note\" data-archive-corrected=\"v{int(c['version'])}\" "
            "style=\"border:2px solid #b9770e;background:#fdf6e3;color:#4d3800;padding:8px 10px;margin:8px 0;font-size:13px\">"
            f"<b>{_h.escape(banner_text(c, item_id))}</b></div>{BANNER_END}")


def _stamp_file(name: str, data: bytes, disc: dict, corr: dict | None, item_id: str) -> bytes:
    """The archived bytes: HTML gets the banner after <body> and the disclosure before </body>; Markdown and text get
    them as text; other files are kept as they are."""
    suffix = Path(name).suffix.lower()
    if suffix not in TEXT_SUFFIXES:
        return data
    text = _strip_injected(data.decode("utf-8", errors="replace"))
    if suffix in (".html", ".htm"):
        if corr:
            m = _BODY.search(text)
            b = banner_html(corr, item_id)
            text = text[:m.end()] + b + text[m.end():] if m else b + text
        d = disclosure_html(disc)
        ends = list(_BODY_END.finditer(text))
        text = text[:ends[-1].start()] + d + text[ends[-1].start():] if ends else text + d
        from .csp import harden                  # EQ-C-0165: CSP re-hashed for the stamped banner and disclosure
        text = harden(text)
    else:
        top = f"> **{banner_text(corr, item_id)}**\n\n" if corr else ""
        text = (f"{BANNER_START}\n{top}{BANNER_END}\n" if corr else "") + text.rstrip("\n") + \
            f"\n\n{DISCLOSURE_START}\n{disclosure_text(disc)}{DISCLOSURE_END}\n"
    return text.encode("utf-8")


# ---------------------------------------------------------------- add / correct
def _read_sources(files) -> list[tuple[str, bytes]]:
    files = [Path(f) for f in (files or [])]
    if not files:
        raise ArchiveError("at least one --file is required")
    if len(files) > MAX_FILES:
        raise ArchiveError(f"at most {MAX_FILES} files per version")
    out, names = [], set()
    for f in files:
        name = f.name
        if not NAME_RE.match(name) or name in RESERVED or f.suffix.lower() not in SUFFIXES:
            raise ArchiveError(f"file {name[:80]!r}: a plain name ending in {', '.join(SUFFIXES)} is required")
        if name in names:
            raise ArchiveError(f"file {name!r} given twice")
        if f.is_symlink() or not f.is_file():
            raise ArchiveError(f"file {name!r}: not a regular file (symlinks are refused)")
        if f.stat().st_size > MAX_FILE_BYTES:
            raise ArchiveError(f"file {name!r}: larger than {MAX_FILE_BYTES} bytes")
        names.add(name)
        out.append((name, f.read_bytes()))
    return out


def _write_version(root: Path, product: str, item_id: str, version: int, sources: list[tuple[str, bytes]], meta: dict,
                   conflicts: str | None, licence: str | None, corr: dict | None, now) -> tuple[Path, dict]:
    reads = [(n, read_product(n, b)) for n, b in sources]
    derived = _licence_of(reads)
    if licence not in (None, "", *LICENCES):
        raise ArchiveError(f"licence must be one of {', '.join(LICENCES)}")
    if licence == "client-safe" and derived != "client-safe":
        raise ArchiveError("licence labels are carried, never raised: these files are internal-only")
    label = licence or derived
    attribution = [a for _n, r in reads for a in r["attribution"]]
    disc = disclosure(attribution, label, conflicts, [x for _n, r in reads for x in r["internal_only"]])
    title = meta.get("title") or next((r["title"] for _n, r in reads if r["title"]), "") or item_id
    item_dir = root / product / item_id
    item_dir.mkdir(parents=True, exist_ok=True)
    final = item_dir / f"v{version}"
    if final.exists():
        raise ArchiveError(f"{item_id} v{version} already exists (versions are never rewritten)")
    tmp = Path(tempfile.mkdtemp(dir=item_dir, prefix=f".tmp-v{version}-"))
    try:
        files = []
        for name, data in sources:
            b = _stamp_file(name, data, disc, corr, item_id)
            (tmp / name).write_bytes(b)
            files.append({"name": name, "sha256": _sha(b), "bytes": len(b), "source_sha256": _sha(data)})
        (tmp / "DISCLOSURE.txt").write_text(disclosure_text(disc), encoding="utf-8")
        if corr:
            (tmp / "CORRECTION.json").write_text(json.dumps(corr, indent=1, ensure_ascii=False) + "\n", encoding="utf-8")
        manifest = {"schema": SCHEMA, "ticket": TICKET, "id": item_id, "version": version, "product": product,
                    "subject": meta["subject"], "country": meta.get("country"), "period": meta["period"],
                    "title": _text(str(title)[:300], "title", cap=300), "licence": label, "licence_derived": derived,
                    "run_id": meta["run_id"], "code_hash": meta["code_hash"], "data_hash": meta.get("data_hash"),
                    "archived_utc": _ts(now), "archived_by": meta["by"], "files": files,
                    "disclosure": {**disc, "sha256": _sha(disclosure_text(disc).encode("utf-8"))}, "correction": corr}
        mb = (json.dumps(manifest, indent=1, ensure_ascii=False) + "\n").encode("utf-8")
        (tmp / "manifest.json").write_bytes(mb)
        for p in tmp.iterdir():
            os.chmod(p, 0o444)
        os.rename(tmp, final)
        os.chmod(final, 0o555)
    except BaseException:
        _rmtree_ro(tmp)
        raise
    return final, {**manifest, "manifest_sha256": _sha(mb)}


def _index_row(event: str, m: dict) -> dict:
    return {"ts_utc": m["archived_utc"], "event": event, "id": m["id"], "product": m["product"], "subject": m["subject"],
            "country": m.get("country"), "period": m["period"], "version": m["version"], "title": m["title"],
            "licence": m["licence"], "run_id": m["run_id"], "code_hash": m["code_hash"], "by": m["archived_by"],
            "manifest_sha256": m["manifest_sha256"], "files": [{"name": f["name"], "sha256": f["sha256"]} for f in m["files"]],
            "correction": m.get("correction")}


def _commit(root: Path, final: Path, event: str, m: dict, wall_clock: bool = True) -> dict:
    try:
        row = _append(root, _index_row(event, m), wall_clock)
    except BaseException:
        _rmtree_ro(final)                                # never leave a version the index does not name
        raise
    return {"status": "added" if event == "add" else "corrected", "id": m["id"], "version": m["version"],
            "ref": f"{m['product']}/{m['id']}/v{m['version']}", "licence": m["licence"], "title": m["title"],
            "seq": row["seq"], "files": [f["name"] for f in m["files"]]}


def _research_qa(out_dir, product: str, files, sources, run_id, period, data_dir, search_dirs, exclude) -> None:
    """EQ-C-0163: the research QA gate (ops/research_qa.py) on the files to archive, against the cited run and the
    latest archived versions of the other items; ArchiveError naming the failing figures."""
    from ..ops import research_qa as RQ
    dirs = [a for f in files or [] if not isinstance(f, (tuple, list)) for a in list(Path(f).resolve().parents)[:6]]
    dirs += list(search_dirs or ())                    # e.g. the pack folder of a corrected copy kept elsewhere
    peers = RQ.peer_claims(RQ.archive_files(out_dir, exclude=exclude))
    try:
        RQ.gate(sources, outputs_dir=out_dir, data_dir=Path(data_dir) if data_dir else Path(out_dir).resolve().parent / "data",
                run_id=run_id or None, kind=product, as_of=period, peers=peers, search_dirs=dirs)
    except RQ.ResearchQAError as e:
        raise ArchiveError(f"not archived: {e}") from None


def add(out_dir, product: str, files, *, period, by, country=None, subject=None, title=None, run_id=None,
        code_hash=None, data_hash=None, conflicts=None, licence=None, now=None, data_dir=None, search_dirs=(),
        qa: bool = True) -> dict:
    """Archive v1 of a product. The same source files again: {"status": "unchanged"}; different files: refused
    (a change is a correction). EQ-C-0163: a new version passes the research QA gate first (on by default; qa=False
    is for tests of other behaviour only)."""
    item_id = make_id(product, subject or country or "all", period)
    meta = {"subject": slug(subject or country or "all"), "period": parse_period(period),
            "country": _text(country, "country", required=False, cap=60) or None,
            "title": _text(title, "title", required=False, cap=300), "run_id": _stamp(run_id, "run_id"),
            "code_hash": _stamp(code_hash, "code_hash"), "data_hash": _text(data_hash, "data_hash", required=False, cap=80) or None,
            "by": _person(by)}
    conflicts = _text(conflicts, "conflicts", required=False) or None
    sources = _read_sources(files)
    root = archive_root(out_dir)
    with _locked(root):
        it = items(out_dir).get(item_id)
        if it:
            last = it["versions"][-1]
            want = sorted((n, _sha(b)) for n, b in sources)
            for row in reversed(it["versions"]):         # these files are already a version (e.g. a rerun after a correction)
                if sorted((f["name"], f.get("source_sha256")) for f in _manifest(root, row).get("files") or []) == want:
                    return {"status": "unchanged", "id": item_id, "version": row["version"], "latest_version": last["version"],
                            "ref": f"{product}/{item_id}/v{row['version']}", "licence": row.get("licence"), "title": row.get("title")}
            raise ArchiveError(f"{item_id} is already archived (v{last['version']}): a change is a correction "
                               "(econquest archive correct)")
        if qa:
            _research_qa(out_dir, product, files, sources, meta["run_id"], meta["period"], data_dir, search_dirs, (item_id,))
        _require_clean_index(root, _ts() if now is None else None)       # EQ-C-0164: refuse before writing anything
        final, m = _write_version(root, product, item_id, 1, sources, meta, conflicts, licence, None, now)
        return _commit(root, final, "add", m, wall_clock=now is None)


def correct(out_dir, item_id, files, *, what, why, by, conflicts=None, title=None, run_id=None, code_hash=None,
            data_hash=None, licence=None, now=None, data_dir=None, search_dirs=(), qa: bool = True) -> dict:
    """v<N+1> of an archived item with a correction note and banner. Earlier versions are never touched."""
    item_id = _check_id(item_id)
    corr_what, corr_why, who = _text(what, "--what"), _text(why, "--why"), _person(by)
    conflicts = _text(conflicts, "conflicts", required=False) or None
    sources = _read_sources(files)
    root = archive_root(out_dir)
    with _locked(root):
        it = items(out_dir).get(item_id)
        if not it:
            raise ArchiveError(f"{item_id} is not in the archive (econquest archive list)")
        last = it["versions"][-1]
        prev = _manifest(root, last)
        if sorted((f["name"], f.get("source_sha256")) for f in prev.get("files") or []) == sorted((n, _sha(b)) for n, b in sources):
            raise ArchiveError(f"nothing changed: the files equal {item_id} v{last['version']}")
        version = int(last["version"]) + 1
        corr = {"version": version, "replaces": int(last["version"]), "what": corr_what, "why": corr_why, "by": who,
                "utc": _ts(now), "previous_manifest_sha256": last.get("manifest_sha256")}
        meta = {"subject": it["subject"], "period": it["period"], "country": it.get("country"),
                "title": _text(title, "title", required=False, cap=300) or prev.get("title"),
                "run_id": _stamp(run_id or prev.get("run_id"), "run_id"),
                "code_hash": _stamp(code_hash or prev.get("code_hash"), "code_hash"),
                "data_hash": _text(data_hash, "data_hash", required=False, cap=80) or prev.get("data_hash"), "by": who}
        if qa:
            _research_qa(out_dir, it["product"], files, sources, meta["run_id"], meta["period"], data_dir, search_dirs, (item_id,))
        _require_clean_index(root, _ts() if now is None else None)
        final, m = _write_version(root, it["product"], item_id, version, sources, meta, conflicts or
                                  (prev.get("disclosure") or {}).get("conflicts"), licence, corr, now)
        return _commit(root, final, "correct", m, wall_clock=now is None)


def _version_dir(root: Path, row: dict) -> Path | None:
    try:
        product, item_id, v = row["product"], _check_id(row["id"]), int(row["version"])
    except (KeyError, TypeError, ValueError, ArchiveError):
        return None
    if product not in PRODUCTS or not item_id.startswith(product + "-") or v < 1:
        return None
    return root / product / item_id / f"v{v}"


def _manifest(root: Path, row: dict) -> dict:
    d = _version_dir(root, row)
    try:
        m = json.loads((d / "manifest.json").read_text(encoding="utf-8")) if d else {}
    except (OSError, ValueError):
        m = {}
    return m if isinstance(m, dict) else {}


# ---------------------------------------------------------------- list / show
def draft_hidden(root: Path, r: dict) -> bool:
    """EQ-C-0176 (HO-20261027-B-C-005 ask 3b): a version of an assistant draft item (id with -assistant-draft-,
    EQ-B-0148) is listed and searched only when its draft.json says SIGNED; DRAFT versions (and an unreadable
    record) stay out of list, search and the GUI. Other items are never hidden."""
    if DRAFT_TAG not in str(r.get("id") or ""):
        return False
    d = _version_dir(root, r)
    try:
        rec = json.loads((d / "draft.json").read_text(encoding="utf-8")) if d else {}
    except (OSError, ValueError):
        rec = {}
    return not (isinstance(rec, dict) and rec.get("status") == "SIGNED")


def _public_row(r: dict, it: dict) -> dict:
    n = len(it["versions"])
    c = r.get("correction") or {}
    return {"id": r["id"], "product": r["product"], "product_label": PRODUCT_LABELS.get(r["product"], r["product"]),
            "subject": r.get("subject"), "country": r.get("country"), "period": r.get("period"), "version": r["version"],
            "latest_version": n, "latest": r["version"] == n, "corrected": bool(c) or r["version"] > 1,
            "superseded": r["version"] < n, "corrected_on": c.get("utc"), "title": r.get("title"),
            "licence": r.get("licence"), "archived_utc": r.get("ts_utc"), "ref": f"{r['product']}/{r['id']}/v{r['version']}",
            "files": [f.get("name") for f in r.get("files") or []]}


def _filters(product=None, country=None, date_from=None, date_to=None) -> dict:
    f = {}
    if product:
        if product not in PRODUCTS:
            raise ArchiveError(f"product must be one of {', '.join(PRODUCTS)}")
        f["product"] = product
    if country:
        c = _text(country, "country", cap=60)
        if not COUNTRY_RE.match(c):
            raise ArchiveError("country: letters, digits, spaces and . ' ( ) - only")
        f["country"] = c.casefold()
    for k, v in (("date_from", date_from), ("date_to", date_to)):
        if v:
            f[k] = parse_period(v)
    return f


def _keep(d: dict, f: dict, latest_only: bool, audience: str) -> bool:
    if f.get("product") and d["product"] != f["product"]:
        return False
    if f.get("country") and f["country"] != str(d.get("country") or "").casefold() and slug(f["country"]) != d.get("subject"):
        return False
    if f.get("date_from") and str(d.get("period")) < f["date_from"]:
        return False
    if f.get("date_to") and str(d.get("period")) > f["date_to"]:
        return False
    if latest_only and not d["latest"]:
        return False
    return audience != "client" or d.get("licence") == "client-safe"


def list_archive(out_dir, product=None, country=None, date_from=None, date_to=None, latest_only=False,
                 audience: str = "internal") -> list[dict]:
    f = _filters(product, country, date_from, date_to)
    out = []
    root = archive_root(out_dir)
    for it in items(out_dir).values():
        for r in it["versions"]:
            if draft_hidden(root, r):
                continue
            d = _public_row(r, it)
            if _keep(d, f, latest_only, audience):
                out.append(d)
    return sorted(out, key=lambda d: (d["period"] or "", d["id"], d["version"]), reverse=True)


def show(out_dir, item_id, version: int | None = None) -> dict:
    """One version (default the latest): manifest, disclosure, correction and the item's version history."""
    item_id = _check_id(item_id)
    root = archive_root(out_dir)
    it = items(out_dir).get(item_id)
    if not it:
        raise ArchiveError(f"{item_id} is not in the archive")
    rows = {r["version"]: r for r in it["versions"]}
    v = int(version or max(rows))
    if v not in rows:
        raise ArchiveError(f"{item_id} has no version {v} (versions 1-{max(rows)})")
    m = _manifest(root, rows[v])
    hist = [{"version": r["version"], "event": r.get("event"), "utc": r.get("ts_utc"), "by": r.get("by"),
             "correction": r.get("correction")} for r in it["versions"]]
    return {**_public_row(rows[v], it), "run_id": m.get("run_id"), "code_hash": m.get("code_hash"),
            "data_hash": m.get("data_hash"), "disclosure": m.get("disclosure"), "correction": m.get("correction"),
            "manifest_files": [{k: f.get(k) for k in ("name", "sha256", "bytes")} for f in m.get("files") or []],
            "history": hist}


# ---------------------------------------------------------------- verify
def verify(out_dir) -> dict:
    """{"ok", "rows", "items", "versions", "errors", "warnings"}: see the module docstring."""
    from .report import DISCLAIMER
    root = archive_root(out_dir)
    errors, rows = _chain_errors(root)
    warnings: list[str] = []
    seen: dict[str, list[int]] = {}
    named: set[Path] = set()
    for r in rows:
        if not r:
            continue
        d = _version_dir(root, r)
        tag = f"{r.get('id')} v{r.get('version')}"
        if d is None:
            errors.append(f"seq {r.get('seq')}: not a valid id/product/version"); continue
        named.add(d)
        seen.setdefault(r["id"], []).append(int(r["version"]))
        if (r.get("event") == "add") != (int(r["version"]) == 1) or r.get("event") not in ("add", "correct"):
            errors.append(f"{tag}: event {r.get('event')!r} does not fit the version")
        mp = d / "manifest.json"
        if not mp.is_file():
            errors.append(f"{tag}: version folder or manifest missing"); continue
        mb = mp.read_bytes()
        if _sha(mb) != r.get("manifest_sha256"):
            errors.append(f"{tag}: manifest.json changed since it was archived")
        try:
            m = json.loads(mb)
        except ValueError:
            errors.append(f"{tag}: manifest.json is not JSON"); continue
        if m.get("id") != r["id"] or m.get("version") != r["version"]:
            errors.append(f"{tag}: manifest names {m.get('id')} v{m.get('version')}")
        names = {f.get("name") for f in m.get("files") or []}
        for f in m.get("files") or []:
            fp = d / str(f.get("name"))
            if not NAME_RE.match(str(f.get("name"))) or not fp.is_file():
                errors.append(f"{tag}: file {f.get('name')!r} missing"); continue
            b = fp.read_bytes()
            if _sha(b) != f.get("sha256"):
                errors.append(f"{tag}: file {f['name']} changed since it was archived (sha256 differs)")
            if fp.suffix.lower() in TEXT_SUFFIXES:
                t = b.decode("utf-8", errors="replace")
                if DISCLOSURE_START not in t or DISCLAIMER not in t:
                    errors.append(f"{tag}: file {f['name']} lacks the disclosure block")
                if int(r["version"]) > 1 and (BANNER_START not in t or "Corrected on" not in t):
                    errors.append(f"{tag}: file {f['name']} lacks the correction banner")
            if fp.stat().st_mode & (stat.S_IWUSR | stat.S_IWGRP | stat.S_IWOTH):
                warnings.append(f"{tag}: file {f['name']} is writable (archived files are read-only)")
        if sorted(f.get("name") for f in r.get("files") or []) != sorted(names):
            errors.append(f"{tag}: index and manifest list different files")
        dp = d / "DISCLOSURE.txt"
        disc = m.get("disclosure") or {}
        if not dp.is_file() or DISCLAIMER not in dp.read_text(encoding="utf-8", errors="replace"):
            errors.append(f"{tag}: DISCLOSURE.txt missing or without the disclaimer")
        elif _sha(dp.read_bytes()) != disc.get("sha256"):
            errors.append(f"{tag}: DISCLOSURE.txt changed since it was archived")
        if not disc.get("attribution") or not disc.get("conflicts") or disc.get("licence") not in LICENCES:
            errors.append(f"{tag}: disclosure incomplete (attribution, conflicts, licence)")
        if int(r["version"]) > 1:
            cp = d / "CORRECTION.json"
            try:
                c = json.loads(cp.read_text(encoding="utf-8"))
            except (OSError, ValueError):
                c = None
            if not isinstance(c, dict) or c != m.get("correction") or c != r.get("correction") or \
                    not all(c.get(k) for k in ("what", "why", "by", "utc")):
                errors.append(f"{tag}: correction note missing or differs from the index")
        extra = {p.name for p in d.iterdir()} - names - RESERVED
        if extra:
            errors.append(f"{tag}: files not in the manifest: {', '.join(sorted(extra))[:200]}")
    for i, vs in seen.items():
        if vs != list(range(1, len(vs) + 1)):
            errors.append(f"{i}: versions {vs} are not 1..{len(vs)} in order")
    if root.is_dir():
        for prod in sorted(p for p in root.iterdir() if p.is_dir() and not p.name.startswith(".")):
            for item in sorted(p for p in prod.iterdir() if p.is_dir()):
                for v in sorted(p for p in item.iterdir() if p.is_dir()):
                    if v not in named and not v.name.startswith(".tmp-"):
                        errors.append(f"{prod.name}/{item.name}/{v.name}: on disk but not in the index")
    return {"ok": not errors, "rows": len(rows), "items": len(seen), "versions": sum(len(v) for v in seen.values()),
            "errors": errors, "warnings": warnings}


# ---------------------------------------------------------------- search
def _fold(s: str) -> str:
    s = unicodedata.normalize("NFKD", str(s or ""))
    return "".join(ch for ch in s if not unicodedata.combining(ch)).casefold()


def parse_query(q) -> list[tuple[str, bool]]:
    """[(term, prefix)] from user input: word tokens only (letters, digits, underscore), at most MAX_TERMS."""
    s = str(q or "")
    if len(s) > MAX_QUERY:
        raise ArchiveError(f"query is longer than {MAX_QUERY} characters")
    out = []
    for m in re.finditer(r"(\w+)(\*?)", _fold(s)):
        t = m.group(1)[:MAX_TERM]
        if (t, bool(m.group(2))) not in out:
            out.append((t, bool(m.group(2))))
    return out[:MAX_TERMS]


_FTS5: bool | None = None


def fts5_available() -> bool:
    global _FTS5
    if _FTS5 is None:
        try:
            c = sqlite3.connect(":memory:")
            c.execute("CREATE VIRTUAL TABLE t USING fts5(a)")
            c.close()
            _FTS5 = True
        except sqlite3.Error:
            _FTS5 = False
    return _FTS5


def _documents(out_dir) -> list[dict]:
    """One searchable document per archived version (text from the archived files, injected blocks removed)."""
    root = archive_root(out_dir)
    docs = []
    for it in items(out_dir).values():
        for r in it["versions"]:
            if draft_hidden(root, r):                       # EQ-C-0176: unsigned assistant drafts are not searched
                continue
            d = _version_dir(root, r)
            body = []
            for f in r.get("files") or []:
                fp = d / str(f.get("name")) if d else None
                if fp is None or not NAME_RE.match(str(f.get("name"))) or not fp.is_file() or fp.is_symlink():
                    continue
                if fp.stat().st_size > MAX_FILE_BYTES:
                    continue
                body.append(read_product(fp.name, fp.read_bytes())["body"])
            c = r.get("correction") or {}
            if c:
                body.append(f"Corrected: {c.get('what', '')} {c.get('why', '')}")
            docs.append({**_public_row(r, it), "body": "\n".join(body)[:MAX_BODY]})
    return docs


_DOC_COLS = ("id", "product", "product_label", "subject", "country", "period", "version", "latest_version", "latest",
             "corrected", "superseded", "corrected_on", "title", "licence", "archived_utc", "ref", "files")


def _build_sqlite(con: sqlite3.Connection, docs: list[dict], head: str) -> None:
    con.execute("CREATE TABLE meta(k TEXT PRIMARY KEY, v TEXT)")
    con.execute("CREATE TABLE docs(rid INTEGER PRIMARY KEY, " + ", ".join(f"{c}" for c in _DOC_COLS) + ")")
    con.execute("CREATE VIRTUAL TABLE fts USING fts5(title, body, tokenize='unicode61 remove_diacritics 2')")
    for i, d in enumerate(docs, 1):
        con.execute(f"INSERT INTO docs(rid, {', '.join(_DOC_COLS)}) VALUES (?{', ?' * len(_DOC_COLS)})",
                    (i, *[json.dumps(d[c]) if c == "files" else (int(d[c]) if isinstance(d[c], bool) else d[c]) for c in _DOC_COLS]))
        con.execute("INSERT INTO fts(rowid, title, body) VALUES (?, ?, ?)", (i, d.get("title") or "", d["body"]))
    con.executemany("INSERT INTO meta VALUES (?, ?)", [("schema", SEARCH_DB_VERSION), ("head", head)])
    con.commit()


def _sqlite(out_dir, docs_fn) -> sqlite3.Connection:
    """The search db for the current chain head: <archive>/search.sqlite, rebuilt (temp file + replace) when its head
    differs; in memory when the folder cannot hold it."""
    root = archive_root(out_dir)
    _seq, head = _head(read_index(out_dir))
    p = root / SEARCH_DB
    uri = (p.resolve().as_uri() if p.parent.exists() else "") + "?mode=ro"
    if p.is_file() and not p.is_symlink():
        try:
            con = sqlite3.connect(uri, uri=True)
            meta = dict(con.execute("SELECT k, v FROM meta").fetchall())
            if meta.get("schema") == SEARCH_DB_VERSION and meta.get("head") == head:
                return con
            con.close()
        except sqlite3.Error:
            pass
    docs = docs_fn()
    tmp = None
    try:
        root.mkdir(parents=True, exist_ok=True)
        fd, tmp = tempfile.mkstemp(dir=root, prefix=".search.", suffix=".sqlite")
        os.close(fd); os.unlink(tmp)
        con = sqlite3.connect(tmp)
        _build_sqlite(con, docs, head)
        con.close()
        os.replace(tmp, p)
        return sqlite3.connect(p.resolve().as_uri() + "?mode=ro", uri=True)
    except (OSError, sqlite3.Error):
        if tmp:
            with contextlib.suppress(OSError):
                os.unlink(tmp)
        con = sqlite3.connect(":memory:")
        _build_sqlite(con, docs, head)
        return con


def _row_out(row: sqlite3.Row | tuple, cols: list[str]) -> dict:
    d = dict(zip(cols, row))
    for b in ("latest", "corrected", "superseded"):
        d[b] = bool(d[b])
    d["files"] = json.loads(d["files"] or "[]")
    return d


def _search_fts(out_dir, terms, f, latest_only, audience, limit) -> tuple[list[dict], int]:
    con = _sqlite(out_dir, lambda: _documents(out_dir))
    try:
        where, params = [], []
        for k, col in (("product", "product"),):
            if f.get(k):
                where.append(f"d.{col} = ?"); params.append(f[k])
        if f.get("country"):
            where.append("(lower(coalesce(d.country, '')) = ? OR d.subject = ?)"); params += [f["country"], slug(f["country"])]
        if f.get("date_from"):
            where.append("d.period >= ?"); params.append(f["date_from"])
        if f.get("date_to"):
            where.append("d.period <= ?"); params.append(f["date_to"])
        if latest_only:
            where.append("d.latest = 1")
        if audience == "client":
            where.append("d.licence = 'client-safe'")
        cols = list(_DOC_COLS)
        sel = ", ".join(f"d.{c}" for c in cols)
        if terms:
            match = " ".join(f'"{t}"' + ("*" if p else "") for t, p in terms)   # \w-only terms: no operator reaches MATCH
            sql = (f"SELECT {sel}, bm25(fts, 10.0, 1.0) AS r, snippet(fts, 1, '[', ']', ' ... ', 14) FROM fts "
                   f"JOIN docs d ON d.rid = fts.rowid WHERE fts MATCH ?" + "".join(f" AND {w}" for w in where) +
                   " ORDER BY r, d.period DESC, d.version DESC")
            rows = con.execute(sql, [match, *params]).fetchall()
            out = []
            for row in rows:
                d = _row_out(row[:len(cols)], cols)
                d["score"] = round(-float(row[len(cols)]), 6); d["snippet"] = row[len(cols) + 1]
                out.append(d)
        else:
            sql = f"SELECT {sel} FROM docs d" + (" WHERE " + " AND ".join(where) if where else "") + \
                " ORDER BY d.period DESC, d.id, d.version DESC"
            out = [{**_row_out(row, cols), "score": None, "snippet": ""} for row in con.execute(sql, params).fetchall()]
    finally:
        con.close()
    return out[:limit], len(out)


def _tokens(s: str) -> list[str]:
    return re.findall(r"\w+", _fold(s))


def _snippet(body: str, terms) -> str:
    low = _fold(body)
    pos = [m.start() for t, p in terms for m in [re.search(r"\b" + re.escape(t) + (r"\w*" if p else r"\b"), low)] if m]
    if not pos:
        return body[:120]
    i = min(pos)
    a, b = max(0, i - 60), min(len(body), i + 80)
    frag = body[a:b]
    for t, p in terms:
        frag = re.sub(r"(?i)\b(" + re.escape(t) + (r"\w*" if p else "") + r")\b", r"[\1]", frag)
    return ("... " if a else "") + " ".join(frag.split()) + (" ..." if b < len(body) else "")


def _search_inverted(out_dir, terms, f, latest_only, audience, limit) -> tuple[list[dict], int]:
    docs = [d for d in _documents(out_dir) if _keep(d, f, latest_only, audience)]
    if not terms:
        out = [{**{k: d[k] for k in _DOC_COLS}, "score": None, "snippet": ""} for d in docs]
        out.sort(key=lambda d: (d["period"] or "", d["id"], d["version"]), reverse=True)
        return out[:limit], len(out)
    toks = [(_tokens(d.get("title") or ""), _tokens(d["body"])) for d in docs]

    def tf(words, t, p):
        return sum(1 for w in words if (w.startswith(t) if p else w == t))
    n = len(docs)
    out = []
    df = {(t, p): sum(1 for tt, bb in toks if tf(tt, t, p) or tf(bb, t, p)) for t, p in terms}
    for d, (tt, bb) in zip(docs, toks):
        score = 0.0
        for t, p in terms:
            a, b = tf(tt, t, p), tf(bb, t, p)
            if not (a or b):
                score = None; break
            idf = math.log(1 + (n - df[(t, p)] + 0.5) / (df[(t, p)] + 0.5))
            score += idf * (10 * a / (1 + len(tt) / 10) + b / (1 + len(bb) / 1000))
        if score is not None:
            out.append({**{k: d[k] for k in _DOC_COLS}, "score": round(score, 4), "snippet": _snippet(d["body"], terms)})
    out.sort(key=lambda d: (-d["score"], -(int(d["period"].replace("-", "")) if d["period"] else 0), -d["version"]))
    return out[:limit], len(out)


def search(out_dir, q="", product=None, country=None, date_from=None, date_to=None, latest_only=False, limit=20,
           audience: str = "internal", backend: str | None = None) -> dict:
    """Full-text search of the archive (see module docstring). q empty: the filtered list, newest period first."""
    if audience not in ("internal", "client"):
        raise ArchiveError("audience must be internal or client")
    try:
        limit = int(limit)
    except (TypeError, ValueError):
        raise ArchiveError("limit must be a whole number") from None
    if not 1 <= limit <= MAX_LIMIT:
        raise ArchiveError(f"limit must be 1-{MAX_LIMIT}")
    terms = parse_query(q)
    if str(q or "").strip() and not terms:
        raise ArchiveError("the query has no searchable words")
    f = _filters(product, country, date_from, date_to)
    backend = backend or ("fts5" if fts5_available() else "inverted")
    if backend not in ("fts5", "inverted"):
        raise ArchiveError("backend must be fts5 or inverted")
    if backend == "fts5" and not fts5_available():
        raise ArchiveError("this Python's sqlite has no FTS5")
    fn = _search_fts if backend == "fts5" else _search_inverted
    res, total = fn(out_dir, terms, f, bool(latest_only), audience, limit)
    n_items = len(items(out_dir))
    return {"status": "ok" if n_items else "empty", "backend": backend, "audience": audience,
            "query": {"q": " ".join(t + ("*" if p else "") for t, p in terms), "product": f.get("product"),
                      "country": f.get("country"), "date_from": f.get("date_from"), "date_to": f.get("date_to"),
                      "latest_only": bool(latest_only), "limit": limit},
            "count": len(res), "total": total, "results": res,
            "message": (f"{total} match(es) in {n_items} archived item(s)" if n_items else
                        "The research archive is empty: archive products with `econquest archive add` "
                        "(or `econquest archive add --from-pack`).")}


def api_search(out_dir, qs: dict) -> tuple[int, dict]:
    """GET /api/archive/search (gui.py, behind the token + Origin guard). (status, body); errors never carry a path."""
    def one(k, default=""):
        v = qs.get(k) or [default]
        return str(v[0]) if v else default
    latest = one("latest", "0").strip().lower()
    if latest not in ("", "0", "1", "true", "false", "yes", "no"):
        return 400, {"error": "latest must be 0 or 1"}
    try:
        return 200, search(out_dir, q=one("q"), product=one("product").strip() or None, country=one("country").strip() or None,
                           date_from=one("from").strip() or None, date_to=one("to").strip() or None,
                           latest_only=latest in ("1", "true", "yes"), limit=one("limit", "20").strip() or 20)
    except ArchiveError as e:
        return 400, {"error": str(e)}
    except (OSError, sqlite3.Error, ValueError) as e:      # error type only, never a path
        return 500, {"error": f"archive search failed ({type(e).__name__})"}


# ---------------------------------------------------------------- from the research pack
def _pack_items(pack: Path) -> list[dict]:
    """[{product, file, subject, country, title}] from the MVP pack's manifests (files resolved inside the pack by
    name, as notes_view does: the pack may have moved)."""
    from .notes_view import _load, _safe_file
    out = []
    for product, sub, man, key in (("country_note", "notes", "country-notes.json", "country"),
                                   ("scenario_brief", "briefs", "scenario-briefs.json", "scenario")):
        for it in (_load(pack / sub / man) or {}).get("items") or []:
            if isinstance(it, dict) and it.get("html"):
                f = _safe_file(pack, product, Path(str(it["html"])).name)
                if f:
                    out.append({"product": product, "file": f, "subject": it.get(key) or f.stem,
                                "country": it.get("country") if product == "country_note" else None, "title": it.get("title")})
    wb = sorted((pack / "weekly-brief").glob("weekly-brief-*.html")) if (pack / "weekly-brief").is_dir() else []
    if wb and not wb[-1].is_symlink():
        out.append({"product": "weekly_brief", "file": wb[-1], "subject": "all", "country": None, "title": None})
    ti = sorted((pack / "trade-ideas").glob("trade-ideas-*.html")) if (pack / "trade-ideas").is_dir() else []
    if ti and not ti[-1].is_symlink():
        out.append({"product": "trade_ideas", "file": ti[-1], "subject": "all", "country": None, "title": None})
    return out


def _pack_data_dir(rel, out_dir, pack: Path) -> Path | None:
    """pack.json data_dir (relative to the folder the pack was built from) as a folder that exists, else None (the
    default: the data/ beside <out>)."""
    if not rel:
        return None
    p = Path(str(rel))
    cands = [p] if p.is_absolute() else [Path(out_dir).resolve().parent / p, *[a / p for a in pack.resolve().parents], Path.cwd() / p]
    return next((c for c in cands if (c / "countries.csv").is_file()), None)


def add_from_pack(out_dir, pack_dir=None, by="econquest archive", limit: int | None = None, per_product: int | None = None,
                  now=None) -> dict:
    """Archive the products of a built research pack (<out>/reports/mvp by default); stamps from pack.json."""
    from .notes_view import _load, pack_dir as default_pack
    pack = Path(pack_dir) if pack_dir else default_pack(out_dir)
    pj = _load(pack / "pack.json")
    if not isinstance(pj, dict):
        raise ArchiveError("no research pack (pack.json) to archive: build it with python -m econquest.validation.mvp_pack build")
    period = parse_period(pj.get("as_of"))
    chosen, per = [], {}
    for it in _pack_items(pack):
        if per_product and per.get(it["product"], 0) >= per_product:
            continue
        per[it["product"]] = per.get(it["product"], 0) + 1
        chosen.append(it)
    if limit:
        chosen = chosen[:limit]
    results = []
    pdata = _pack_data_dir(pj.get("data_dir"), out_dir, pack)        # EQ-C-0163: the data the pack's run was built from
    for it in chosen:
        results.append(add(out_dir, it["product"], [it["file"]], period=period, by=by, country=it["country"],
                           subject=it["subject"], title=it["title"], run_id=pj.get("run_id"), code_hash=pj.get("code_hash"),
                           data_hash=pj.get("data_hash"), now=now, data_dir=pdata, search_dirs=[pack]))
    return {"pack_run_id": pj.get("run_id"), "period": period, "results": results,
            "added": sum(r["status"] == "added" for r in results), "unchanged": sum(r["status"] == "unchanged" for r in results)}


# ---------------------------------------------------------------- demo row M20 (EQ-C-0158)
def demo_archive(out_dir, pack_dir=None, limit: int = 5) -> dict:
    """Demo row M20: archive a small set from the built research pack (<out_dir>/reports/mvp unless pack_dir), correct
    one item, search, verify, and check that a tampered copy fails verify. Writes only <out_dir>/archive and a temp
    folder; run it on the demo home. {"ok", "problems", "summary", ...}; never raises on a failed check."""
    problems: list[str] = []
    info: dict = {}
    try:
        r = add_from_pack(out_dir, pack_dir, by="econquest demo (M20)", limit=limit, per_product=2)
        info["archived"] = [x["id"] for x in r["results"]]
        if not r["results"]:
            return {"ok": False, "problems": ["the research pack lists no product to archive"],
                    "summary": "M20 research archive: nothing to archive"}
        target = next((x for x in r["results"] if x["id"].startswith("country_note-")), r["results"][0])
        tid = target["id"]
        before = show(out_dir, tid)
        root = archive_root(out_dir)
        v_dirs = {x["version"]: root / before["product"] / tid / f"v{x['version']}" for x in before["history"]}
        snap = {v: {p.name: _sha(p.read_bytes()) for p in d.iterdir()} for v, d in v_dirs.items()}
        src = next(it["file"] for it in _pack_items(Path(pack_dir) if pack_dir else root.parent / "reports" / "mvp")
                   if make_id(it["product"], it["subject"] or it["country"] or "all", r["period"]) == tid)
        stamp = dt.datetime.now(dt.timezone.utc).isoformat()      # microseconds: a rerun always differs
        word = "archivecorrectiondemo"
        with tempfile.TemporaryDirectory() as tmp:
            fixed = Path(tmp) / src.name
            t = src.read_text(encoding="utf-8", errors="replace")
            add_p = f"<p class='demo-correction'>Clarification ({word}, {stamp}): the wording of this note was clarified.</p>"
            ends = list(_BODY_END.finditer(t))
            fixed.write_text(t[:ends[-1].start()] + add_p + t[ends[-1].start():] if ends else t + add_p, encoding="utf-8")
            # the corrected copy sits in a temp folder: the QA gate finds the run in the pack's own store (EQ-C-0163)
            pack = Path(pack_dir) if pack_dir else root.parent / "reports" / "mvp"
            c = correct(out_dir, tid, [fixed], what="Clarified the wording of the summary.",
                        why="M20 demo: exercises the correction path.", by="econquest demo (M20)", search_dirs=[pack])
        info["corrected"] = c["ref"]
        for v, d in v_dirs.items():
            if {p.name: _sha(p.read_bytes()) for p in d.iterdir()} != snap[v]:
                problems.append(f"{tid} v{v} changed after the correction (versions must be immutable)")
        newest = show(out_dir, tid)
        if newest["version"] != c["version"] or not newest["corrected"]:
            problems.append("the corrected version is not the latest or not flagged corrected")
        vdir = root / newest["product"] / tid / f"v{c['version']}"
        html_files = [p for p in vdir.iterdir() if p.suffix.lower() in (".html", ".htm")]
        if not html_files or not all("Corrected on" in p.read_text(encoding="utf-8", errors="replace") for p in html_files):
            problems.append("the corrected version has no 'Corrected on' banner")
        for x in list_archive(out_dir):
            d = show(out_dir, x["id"], x["version"])["disclosure"] or {}
            if not d.get("disclaimer") or not d.get("attribution") or not d.get("conflicts"):
                problems.append(f"{x['ref']}: disclosure incomplete")
        s1 = search(out_dir, word)
        if not s1["results"] or s1["results"][0]["id"] != tid or not s1["results"][0]["corrected"]:
            problems.append(f"search {word!r} did not return the corrected version first")
        s2 = search(out_dir, word, latest_only=True, product=newest["product"])
        if [x["version"] for x in s2["results"]] != [c["version"]]:
            problems.append("latest-only search did not return exactly the corrected version")
        q = (newest.get("country") or newest.get("title") or "").split(":")[0]
        s3 = search(out_dir, q, latest_only=True) if q else {"results": []}
        if q and not any(x["id"] == tid for x in s3["results"]):
            problems.append(f"search {q!r} did not find {tid}")
        s4 = search(out_dir, word, audience="client")
        if any(x["licence"] != "client-safe" for x in s4["results"]):
            problems.append("client-audience search returned internal-only content")
        txt = json.dumps([s1, s2, s3, s4])
        if str(Path(out_dir).resolve()) in txt or str(root) in txt:
            problems.append("search results carry an absolute path")
        v = verify(out_dir)
        problems += [f"verify: {e}" for e in v["errors"][:10]]
        with tempfile.TemporaryDirectory() as tmp:          # tamper on a copy: verify must catch it
            cp = Path(tmp) / "outputs"
            shutil.copytree(root, cp / ARCHIVE_REL, ignore=shutil.ignore_patterns(SEARCH_DB, ".lock"))
            f1 = cp / ARCHIVE_REL / newest["product"] / tid / "v1" / before["files"][0]
            os.chmod(f1.parent, 0o755); os.chmod(f1, 0o644)
            f1.write_bytes(f1.read_bytes().replace(b"</body>", b"<p>edited</p></body>", 1) + b" ")
            tampered = verify(cp)
            _unlock_tree(cp)
        if tampered["ok"]:
            problems.append("verify did not detect an edited v1 file on a tampered copy")
        info.update({"backend": s1["backend"], "search_hits": s1["total"], "verify": {k: v[k] for k in ("ok", "rows", "items", "versions")},
                     "tamper_detected": not tampered["ok"]})
        summary = (f"M20 research archive: {r['added']} added, {r['unchanged']} unchanged, {tid} corrected to "
                   f"v{c['version']}; search ({s1['backend']}) {s1['total']} hit(s), latest-only "
                   f"{len(s2['results'])}; verify {'ok' if v['ok'] else 'FAILED'} ({v['rows']} rows, {v['items']} items); "
                   f"tamper on a copy {'detected' if not tampered['ok'] else 'NOT detected'}"
                   + (f"; {len(problems)} problems" if problems else ""))
    except Exception as e:                                  # noqa: BLE001 - reported, never a silent pass
        problems.append(f"demo_archive raised {type(e).__name__}: {str(e)[:300]}")
        summary = f"M20 research archive: did not complete ({type(e).__name__})"
    return {"ok": not problems, "problems": problems, "summary": summary, **info}
