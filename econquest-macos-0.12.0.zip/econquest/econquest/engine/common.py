from __future__ import annotations
import numpy as np
import pandas as pd

EPS = 1e-6
# The engine caps every 12-month PD (pd_default, pd_model and the peril PDs) at this value: engine/pipeline.py applies
# np.minimum(0.99, ...); tests/test_house_view.py::test_pd_cap_constant_is_the_pipeline_cap keeps the two equal.
# A PD at the cap is labelled "(engine cap)" in research outputs, not read as a model view (EQ-B-0115).
PD_CAP_12M = 0.99


def at_pd_cap(v) -> bool:
    """True when a 12-month PD sits at the engine cap (PD_CAP_12M)."""
    try:
        x = float(v)
    except (TypeError, ValueError):
        return False
    return x == x and x >= PD_CAP_12M - 1e-12


def logit(p):
    p = np.clip(np.asarray(p, dtype=float), EPS, 1 - EPS)
    return np.log(p / (1 - p))


def expit(x):
    return 1.0 / (1.0 + np.exp(-np.asarray(x, dtype=float)))


def logistic_curve(score, base_at_50: float, slope_per_10: float):
    """Peril curve used by the workbook: logistic in the driver score around 50 points."""
    return expit(logit(base_at_50) + slope_per_10 * (np.asarray(score, dtype=float) - 50.0) / 10.0)


def to_horizon(p12, months):
    """Convert a 12-month probability to the probability over `months` (constant hazard)."""
    p12 = np.clip(np.asarray(p12, dtype=float), 0, 0.999999)
    return 1.0 - (1.0 - p12) ** (np.asarray(months, dtype=float) / 12.0)


def to_12m(p, months):
    p = np.clip(np.asarray(p, dtype=float), 0, 0.999999)
    return 1.0 - (1.0 - p) ** (12.0 / np.asarray(months, dtype=float))


def as_of_timestamp(settings=None, as_of=None) -> pd.Timestamp:
    """The run's as-of date as a midnight Timestamp (GOV-012).

    Model math never reads the wall clock: `run_pipeline` resolves the date once and stores it in
    settings["as_of"] (YYYY-MM-DD). An explicit `as_of` wins over the settings value."""
    v = as_of if as_of is not None else (settings.get("as_of") if settings is not None else None)
    if v is None or (isinstance(v, str) and not v.strip()):
        raise ValueError("no as-of date: pass as_of, or set settings['as_of'] (run_pipeline does this once per run)")
    return pd.Timestamp(v).normalize()
