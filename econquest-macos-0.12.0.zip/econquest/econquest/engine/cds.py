"""CDS-implied default probabilities and bond relative value (roadmap item 3.3).

Standard reduced-form (JP Morgan / ISDA-style) model: a piecewise-constant hazard rate lambda_i on the
intervals between quoted tenors, interest rates independent of default, premiums paid at the end of each
accrual period, default assumed mid-period with accrued premium paid, recovery R of par.

* `bootstrap_hazard` solves each lambda_i in turn so the quoted par spread prices the contract to zero.
* `survival`, `cumulative_pd`, `pd_12m` read probabilities off the fitted curve.
* `fair_spread` prices a CDS of any maturity off a hazard curve; `model_fair_spread` takes the engine's own
  12-month PD, converts it to a flat hazard and asks what spread it implies, so a market quote can be read as
  rich or cheap against the model.
* `cds_table` and `eurobond_relative_value` build the country table and the per-position reading.

Quotes come from data/cds_quotes.csv (country, date, tenor_y, spread_bp, recovery, source); the latest date
per country and tenor is used. The file is analyst-maintained until a licensed feed exists; its source column
is carried into the audit trail.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from scipy.optimize import brentq


def _grid(maturity: float, freq: int) -> np.ndarray:
    n = int(round(maturity * freq))
    return np.arange(1, n + 1) / freq


def _discount(t: np.ndarray, rate) -> np.ndarray:
    """Flat continuously-compounded rate, or a callable t -> zero rate."""
    r = rate(t) if callable(rate) else float(rate)
    return np.exp(-np.asarray(r) * t)


def survival(t, knots: np.ndarray, lambdas: np.ndarray) -> np.ndarray:
    """S(t) under piecewise-constant hazards on [0,k1],[k1,k2],...; the last hazard extends beyond the last knot."""
    t = np.atleast_1d(np.asarray(t, dtype=float))
    knots = np.asarray(knots, dtype=float); lambdas = np.asarray(lambdas, dtype=float)
    edges = np.concatenate([[0.0], knots])
    H = np.zeros_like(t)
    for i, lam in enumerate(lambdas):
        lo, hi = edges[i], edges[i + 1] if i + 1 < len(edges) else np.inf
        H += lam * np.clip(t - lo, 0.0, hi - lo if np.isfinite(hi) else None)
    return np.exp(-H)


def _legs(spread_bp: float, maturity: float, knots, lambdas, recovery: float, rate, freq: int) -> tuple[float, float]:
    """PV of premium leg per 1 of notional for spread s, and PV of protection leg."""
    t = _grid(maturity, freq)
    dt = 1.0 / freq
    S = survival(t, knots, lambdas)
    S0 = np.concatenate([[1.0], S[:-1]])
    df = _discount(t, rate)
    df_mid = _discount(t - dt / 2, rate)
    dflt = S0 - S
    premium = spread_bp / 1e4 * dt * np.sum(df * S + 0.5 * df_mid * dflt)
    protection = (1.0 - recovery) * np.sum(df_mid * dflt)
    return float(premium), float(protection)


def bootstrap_hazard(tenors, spreads_bp, recovery: float = 0.4, rate=0.04, freq: int = 4) -> np.ndarray:
    """Piecewise-constant hazards that reprice each quoted tenor; tenors ascending in years, spreads in bp."""
    tenors = np.asarray(tenors, dtype=float); spreads_bp = np.asarray(spreads_bp, dtype=float)
    order = np.argsort(tenors); tenors, spreads_bp = tenors[order], spreads_bp[order]
    lambdas: list[float] = []
    for i, (T, s) in enumerate(zip(tenors, spreads_bp)):
        def f(lam, s=s, T=T, i=i):
            lams = np.array(lambdas + [lam])
            prem, prot = _legs(s, T, tenors[: i + 1], lams, recovery, rate, freq)
            return prem - prot
        lo, hi = 1e-8, 5.0
        if f(lo) * f(hi) > 0:
            lambdas.append(hi if f(lo) > 0 else lo)
        else:
            lambdas.append(float(brentq(f, lo, hi, xtol=1e-10)))
    return np.array(lambdas)


def cumulative_pd(horizon_years, knots, lambdas) -> np.ndarray:
    return 1.0 - survival(horizon_years, knots, lambdas)


def pd_12m(knots, lambdas) -> float:
    return float(cumulative_pd(1.0, knots, lambdas)[0])


def fair_spread(maturity: float, knots, lambdas, recovery: float = 0.4, rate=0.04, freq: int = 4) -> float:
    """Par spread (bp) of a CDS of the given maturity priced off the hazard curve."""
    prem1, prot = _legs(1e4, maturity, knots, lambdas, recovery, rate, freq)   # premium leg at 1 (=10,000bp) spread
    return float(prot / prem1 * 1e4) if prem1 > 0 else float("nan")


def model_fair_spread(pd_12m_model: float, maturity: float = 5.0, recovery: float = 0.4, rate=0.04, freq: int = 4) -> float:
    """Spread implied by a flat hazard consistent with the engine's 12-month PD."""
    p = float(np.clip(pd_12m_model, 1e-6, 0.999))
    lam = -np.log(1.0 - p)
    return fair_spread(maturity, np.array([maturity]), np.array([lam]), recovery, rate, freq)


def latest_quotes(quotes: pd.DataFrame) -> pd.DataFrame:
    """Latest date per country and tenor from the quotes file."""
    q = quotes.copy()
    q["date"] = pd.to_datetime(q["date"], errors="coerce")
    q["tenor_y"] = pd.to_numeric(q["tenor_y"], errors="coerce"); q["spread_bp"] = pd.to_numeric(q["spread_bp"], errors="coerce")
    q = q.dropna(subset=["country", "tenor_y", "spread_bp"])
    q = q.sort_values("date").groupby(["country", "tenor_y"], as_index=False).last()
    return q


def cds_table(quotes: pd.DataFrame, model_pd12: pd.Series, recovery: float = 0.4, rate=0.04, freq: int = 4, tenor_ref: float = 5.0) -> pd.DataFrame:
    """One row per quoted sovereign: market curve, implied PDs, model-fair spread at the reference tenor, rich/cheap."""
    q = latest_quotes(quotes)
    rows = []
    for c, g in q.groupby("country"):
        g = g.sort_values("tenor_y")
        rec = float(g["recovery"].dropna().iloc[-1]) if "recovery" in g and g["recovery"].notna().any() else recovery
        knots = g["tenor_y"].to_numpy(dtype=float); lams = bootstrap_hazard(knots, g["spread_bp"].to_numpy(dtype=float), rec, rate, freq)
        ref = g[g["tenor_y"] == tenor_ref]
        mkt_ref = float(ref["spread_bp"].iloc[0]) if len(ref) else fair_spread(tenor_ref, knots, lams, rec, rate, freq)
        pm = float(model_pd12.get(c, np.nan))
        fair = model_fair_spread(pm, tenor_ref, rec, rate, freq) if np.isfinite(pm) else np.nan
        gap = mkt_ref - fair if np.isfinite(fair) else np.nan
        read = ""
        if np.isfinite(gap):
            rel = gap / max(fair, 1.0)
            read = "market cheap vs model (spread above fair)" if rel > 0.25 else "market rich vs model (spread below fair)" if rel < -0.25 else "in line with model"
        rows.append({"country": c, "as_of": g["date"].max().strftime("%Y-%m-%d") if g["date"].notna().any() else "",
                     "tenors": ",".join(f"{t:g}" for t in knots), "spread_1y_bp": float(g.loc[g["tenor_y"] == 1, "spread_bp"].iloc[0]) if (g["tenor_y"] == 1).any() else np.nan,
                     f"spread_{tenor_ref:g}y_bp": mkt_ref, "recovery": rec,
                     "hazard_1y": float(lams[0]), "cds_pd_12m": pd_12m(knots, lams), f"cds_pd_{tenor_ref:g}y_cum": float(cumulative_pd(tenor_ref, knots, lams)[0]),
                     "model_pd_12m": pm, f"model_fair_{tenor_ref:g}y_bp": fair, "gap_bp": gap, "read": read,
                     "source": "; ".join(sorted(set(g["source"].dropna().astype(str)))) if "source" in g else ""})
    return pd.DataFrame(rows)


def eurobond_relative_value(portfolio: pd.DataFrame, table: pd.DataFrame, tenor_ref: float = 5.0) -> pd.DataFrame:
    """Rich/cheap reading for each Eurobond or CDS position whose sovereign has a quote."""
    if table.empty:
        return pd.DataFrame(columns=["id", "country", "asset_class", "direction", "notional_mm", "market_bp", "fair_bp", "gap_bp", "read"])
    t = table.set_index("country")
    rows = []
    for p in portfolio.itertuples():
        if str(p.asset_class) not in ("Eurobond", "CDS") or p.country not in t.index:
            continue
        r = t.loc[p.country]
        gap = float(r["gap_bp"])
        long_credit = (p.asset_class == "Eurobond" and p.direction == "Long") or (p.asset_class == "CDS" and p.direction == "Short")
        read = ("spread wide of model: favourable for long credit" if gap > 0 else "spread tight of model: unfavourable for long credit") if long_credit else \
               ("spread wide of model: unfavourable for protection buyer" if gap > 0 else "spread tight of model: favourable for protection buyer")
        rows.append({"id": p.id, "country": p.country, "asset_class": p.asset_class, "direction": p.direction, "notional_mm": p.notional_mm,
                     "market_bp": float(r[f"spread_{tenor_ref:g}y_bp"]), "fair_bp": float(r[f"model_fair_{tenor_ref:g}y_bp"]), "gap_bp": gap, "read": read})
    return pd.DataFrame(rows)
