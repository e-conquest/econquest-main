"""Signals (25 keys), Playbook trade activation and the Dashboard summary (workbook Signals,
Trade Activation and Dashboard tabs), computed from the scorecard, Risk Engine, GPR and arbitrage outputs."""
from __future__ import annotations
import numpy as np
import pandas as pd
from ..config import Settings
from ..ingestion import Universe

SIGNAL_NAMES = {1: "Debt payment wall", 2: "Fiscal stress", 3: "External funding stress", 4: "Devaluation pressure", 5: "Inflation pressure",
                6: "Growth slowdown", 7: "Banking stress", 8: "Election event", 9: "Political instability", 10: "Expropriation and contract risk",
                11: "Security and violence", 12: "Commodity dependence", 13: "Climate and disaster", 14: "Sanctions and geopolitics",
                15: "Market complacency", 16: "Distress and restructuring", 17: "Deteriorating momentum", 18: "Official backstop stress",
                19: "Market overpricing risk", 20: "Benign carry", 21: "Low-risk calm market", 22: "Geopolitical risk spike (GPR)",
                23: "Global geopolitical risk-off (GPR)", 24: "GPR headline spike in a low-exposure calm market", 25: "Prediction market gap"}
OPTIONAL_SIGNAL_NAMES = {26: "Debt above IMF benchmark (DSA)"}   # EQ-B-0070: row present only when a DSA table is passed
INSTRUMENT_FIELD = {"CDS": "CDS", "Eurobond": "Eurobond", "FX": "FX", "FX options": "FX options", "Local rates": "Local rates", "Equity": "Equity"}
RULE2_OPS = {"<": np.less, "<=": np.less_equal, ">": np.greater, ">=": np.greater_equal}
DEFAULT_COMPLACENCY_SCALE_LOG2 = 0.4 / np.arctanh(0.4)   # 0.944: 70/30 crossing at ratio 2**0.4 = 1.32x, as in the old linear form


def complacency_signal(ratio: float, scale_log2: float = DEFAULT_COMPLACENCY_SCALE_LOG2) -> float:
    """Signal 15: 50 + 50 tanh(log2(pd_default / pd_market) / scale_log2).

    Continuous and strictly monotone in the PD gap, bounded in (0, 100) without ever reaching either end, so a
    larger gap always means a stronger signal (the old 50 + 50 log2(ratio) clipped to [0, 100] saturated at a 2x
    gap, which put signal 19 at 100 for every country where the market PD was at least twice the model PD).
    With scale_log2 = 0.4 / atanh(0.4) the 70 and 30 crossings stay at a 1.32x gap, so T16/T17 (min_strength 70)
    activate at the same ratios as before. Reference values: 1.32x -> 70, 2x -> 89.3, 2.4x -> 93.4, 4x -> 98.5.
    """
    if not np.isfinite(scale_log2) or scale_log2 <= 0:
        raise ValueError(f"signals.complacency_scale_log2 must be positive, got {scale_log2!r}")
    return float(50.0 + 50.0 * np.tanh(np.log2(ratio) / scale_log2))


def _rule2_op(rule2, trade_id):
    op = str(rule2).strip()
    if op not in RULE2_OPS:
        raise ValueError(f"playbook trade {trade_id}: rule2 {rule2!r} is not one of {sorted(RULE2_OPS)}")
    return RULE2_OPS[op]


def compute_signals(u: Universe, settings: Settings, sc, country: pd.DataFrame, gpr_country: pd.DataFrame, gpr_global: dict,
                    arbitrage: pd.DataFrame, dsa: pd.DataFrame | None = None) -> pd.DataFrame:
    sg = settings["signals"]; pr = settings["probability"]; pm = settings["prediction_markets"]
    cscale = float(settings.get("signals", "complacency_scale_log2", default=DEFAULT_COMPLACENCY_SCALE_LOG2))
    s = sc.indicator_scores; pf = sc.pillar_final
    prof = u.countries.set_index("country").loc[u.names]
    ind = u.indicators.set_index("id")
    out = pd.DataFrame(index=list(SIGNAL_NAMES) + ([26] if dsa is not None else []), columns=u.names, dtype=float)
    dsa_score = None if dsa is None else dsa.set_index("country")["dsa_score"]   # EQ-B-0070 signal 26, 0-100
    best_edge = arbitrage.groupby("country")["net_edge_pp"].max() if len(arbitrage) else pd.Series(dtype=float)
    for c in u.names:
        comp = float(country.at[c, "composite"]); regime = country.at[c, "regime"]
        ratio = float(country.at[c, "pd_default"] / country.at[c, "pd_market"]) if country.at[c, "pd_market"] > 0 else 0.0
        v = {}
        v[1] = max(s.at["1.1", c], s.at["1.2", c]); v[2] = pf.at[1, c]; v[3] = pf.at[2, c]
        v[4] = np.mean([s.at["2.1", c], s.at["2.5", c], s.at["2.12", c]]); v[5] = s.at["5.5", c]; v[6] = s.at["5.6", c]
        v[7] = np.mean([s.at["5.1", c], s.at["5.3", c], s.at["5.10", c]])
        v[8] = max(sg["threshold"], s.at["4.5", c]) if float(prof.at[c, "elmonths"]) <= sg["election_window_months"] else s.at["4.5", c] / 2
        v[9] = pf.at[4, c]; v[10] = pf.at[3, c]; v[11] = pf.at[6, c]
        v[12] = s.at["2.11", c] if prof.at[c, "exptype"] == "Commodity" else 0.0
        v[13] = pf.at[7, c]; v[14] = max(s.at["2.7", c], s.at["4.10", c])
        v[15] = 50.0 if (ratio <= 0 or country.at[c, "pd_market"] < pr["min_market_pd"]) else complacency_signal(ratio, cscale)
        v[16] = 100.0 if (prof.at[c, "default"] or country.at[c, "pd_rating"] >= pr["distress_pd"]) else 0.0
        prior = prof.at[c, "prior"] if "prior" in prof.columns else np.nan
        v[17] = 0.0 if pd.isna(prior) or prior == "" else max(0.0, min(100.0, 50 + sg["momentum_scale"] * (comp - float(prior))))
        v[18] = s.at["2.6", c]; v[19] = 100 - v[15]
        v[20] = (100 - comp) if (regime == "Calm" and float(ind.at["5.13", c]) >= sg["min_carry_real_rate"]) else 0.0
        v[21] = (100 - comp) if regime == "Calm" else 0.0
        v[22] = float(gpr_country.at[c, "signal"]); v[23] = float(gpr_global["signal"])
        v[24] = v[22] if (regime == "Calm" and v[14] < 50) else 0.0
        edge = best_edge.get(c, np.nan)
        v[25] = 0.0 if pd.isna(edge) else min(100.0, max(0.0, 50 + edge * 10 / pm["min_net_edge_pp"]))
        if dsa_score is not None:
            v[26] = float(dsa_score.get(c, np.nan))       # no DSA row (e.g. no WEO debt): NaN, not "no risk"
        for k, val in v.items():
            out.at[k, c] = float(val)
    return out


def trade_activation(u: Universe, playbook: pd.DataFrame, signals: pd.DataFrame) -> pd.DataFrame:
    prof = u.countries.set_index("country").loc[u.names]
    out = pd.DataFrame(np.nan, index=list(playbook["id"]), columns=u.names)
    # second conditions are validated for the whole playbook before anything is activated: an unknown operator raises
    ops = {t["id"]: _rule2_op(t["rule2"], t["id"]) for _, t in playbook.iterrows() if pd.notna(t["key2"]) and str(t["key2"]) != ""}
    for _, t in playbook.iterrows():
        key = int(t["key"]); k2 = t["key2"]
        for c in u.names:
            sv = signals.at[key, c]
            ok2 = True
            if t["id"] in ops:
                sb = signals.at[int(float(k2)), c]
                ok2 = bool(ops[t["id"]](sb, float(t["threshold2"])))
            inst = t["instrument"]
            tradable = True if inst == "Any" else bool(prof.at[c, INSTRUMENT_FIELD[inst]])
            if sv >= float(t["min_strength"]) and ok2 and tradable:
                out.at[t["id"], c] = round(sv, 0)
    return out


def dashboard_table(u: Universe, settings: Settings, country: pd.DataFrame, signals: pd.DataFrame, activation: pd.DataFrame,
                    playbook: pd.DataFrame, gpr_country: pd.DataFrame, arbitrage: pd.DataFrame) -> pd.DataFrame:
    sg = settings["signals"]; pm = settings["prediction_markets"]; thr = settings.get("signals", "gpr_divergence_threshold", default=20)
    names_by_id = dict(zip(playbook["id"], playbook["strategy"]))
    # hedges (political risk insurance, violence cover, cat cover, option tail hedges) are bought as insurance, not sized
    # against the per-country risk budget: notional uses the strongest firing trade whose stance is not unsized
    unsized = set(settings.get("signals", "unsized_stances", default=["Hedge"]))
    sized_ids = set(playbook.loc[~playbook["stance"].isin(unsized), "id"]) if "stance" in playbook.columns else set(playbook["id"])
    rows = []
    for i, c in enumerate(u.names, 1):
        risk_keys = list(range(1, 19)) + [22]
        vals = [(SIGNAL_NAMES[k], signals.at[k, c]) for k in risk_keys if signals.at[k, c] >= sg["threshold"]]
        vals.sort(key=lambda x: -x[1])
        top3 = ", ".join(n for n, _ in vals[:3]) if vals else "None above threshold"
        col = activation[c].dropna()
        firing = int(len(col)); conv = float(col.max()) if firing else 0.0
        best = names_by_id[col.idxmax()] if firing else "None"
        sized = col[col.index.isin(sized_ids)]
        sized_conv = float(sized.max()) if len(sized) else 0.0
        notional = sg["risk_budget_mm"] * sized_conv / 100 * sg["regime_scalar"][country.at[c, "regime"]]
        all_trades = ", ".join(col.index) if firing else ""
        covered = bool(gpr_country.at[c, "covered"]); gsig = float(gpr_country.at[c, "signal"])
        gap = gsig - float(country.at[c, "composite"]) if covered else None
        if not covered:
            gread = "Not in GPR dataset"
        elif gap >= thr:
            gread = "GPR hotter than the composite score: headline risk ahead of fundamentals"
        elif gap <= -thr:
            gread = "Composite score hotter than GPR: fundamentals weaker than the headlines"
        else:
            gread = "Broadly aligned"
        a = arbitrage[arbitrage["country"] == c] if len(arbitrage) else arbitrage
        n_contracts = int(len(a)); best_edge = float(a["net_edge_pp"].max()) if n_contracts else None
        if n_contracts == 0:
            pread = "No contract on this country"
        elif best_edge < pm["min_net_edge_pp"]:
            pread = "Market and model agree within costs"
        else:
            side = a.loc[a["net_edge_pp"].idxmax(), "side"]
            pread = "Model sees more risk than the market" if side == "Buy Yes" else "Market sees more risk than the model"
        rows.append({"country": c, "column": i, "region": country.at[c, "region"], "composite": round(float(country.at[c, "composite"]), 1),
                     "grade": int(country.at[c, "grade"]), "regime": country.at[c, "regime"], "rating": country.at[c, "rating"],
                     "pd_default": float(country.at[c, "pd_default"]), "pd_market": float(country.at[c, "pd_market"]), "pd_any": float(country.at[c, "pd_any"]),
                     "top_signals": top3, "trades_firing": firing, "best_trade": best, "conviction": conv, "notional_mm": round(notional, 2),
                     "all_trades": all_trades, "gpr_signal": gsig, "gpr_gap": None if gap is None else round(gap, 0), "gpr_read": gread,
                     "pm_contracts": n_contracts, "pm_best_edge": None if best_edge is None else round(best_edge, 1), "pm_read": pread})
    return pd.DataFrame(rows).set_index("country")
