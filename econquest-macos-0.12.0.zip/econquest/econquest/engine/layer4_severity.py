"""Layer 4: structural loss severity and contingent-claims analysis (paper 3.4).

* Sovereign restructuring haircuts: Beta distribution with the Cruces-Trebesch mean for the asset
  class (hard-currency vs local), scaled by the regime LGD multiplier, with fixed dispersion.
* Merton CCA: distance-to-distress from a sovereign balance-sheet proxy; a shrinking DD raises the
  expected haircut (`lgd_per_sigma` per sigma below the reference DD).
* EVT: political-violence and expropriation severities drawn from a Generalized Pareto tail with
  shape xi and the scale solved so the mean of the loss share, capped at 100 percent, equals the
  calibrated haircut.
* Sector and location multipliers scale the expropriation and political-violence PDs (equities).
* Haircut fit (GOV-024): `load_haircuts` reads a Cruces-Trebesch style restructuring table,
  `fit_haircuts` fits a Beta per instrument class (and per regime where a regime column exists) by
  method of moments and by maximum likelihood, `fitted_lgd_block` turns the fit into the
  `layer4.fitted_lgd` settings block, and `effective_severity` applies it when
  `layer4.lgd_source` is "fitted". The default "judgement" leaves every number bit-identical.
"""
from __future__ import annotations
from functools import lru_cache
import numpy as np
import pandas as pd
from scipy import stats
from scipy.optimize import brentq
from ..config import Settings
from ..ingestion import Universe


def beta_params(mean: float, sd: float) -> tuple[float, float]:
    mean = float(np.clip(mean, 0.02, 0.98))
    sd = min(sd, np.sqrt(mean * (1 - mean)) * 0.95)
    k = mean * (1 - mean) / sd ** 2 - 1
    a, b = mean * k, (1 - mean) * k
    if min(a, b) < 0.5:          # keep the shape away from the U-shaped region without moving the mean (tighter dispersion instead)
        f = 0.5 / min(a, b); a, b = a * f, b * f
    return a, b


LGD_BOUNDS = (0.05, 0.95)


def expected_lgd(base_lgd: float, lgd_mult: float, lgd_uplift: float = 0.0, cap: float | None = None) -> float:
    """Mean loss given default: base share x regime multiplier + Merton uplift, kept within LGD_BOUNDS (the upper
    bound is `cap` when given: `layer4.lgd_cap`, EQ-B-0097)."""
    hi = LGD_BOUNDS[1] if cap is None else float(cap)
    return float(np.clip(base_lgd * lgd_mult + lgd_uplift, LGD_BOUNDS[0], hi))


def lgd_cap(settings: Settings) -> float:
    """`layer4.lgd_cap`: upper bound on the mean LGD (EQ-B-0097). Absent: LGD_BOUNDS[1] (today). Must be a finite
    number in (LGD_BOUNDS[0], LGD_BOUNDS[1]]; anything else raises ValueError."""
    v = settings.get("layer4", "lgd_cap", default=None)
    if v is None:
        return LGD_BOUNDS[1]
    if isinstance(v, bool) or not isinstance(v, (int, float, np.integer, np.floating)) or not np.isfinite(v) \
            or not (LGD_BOUNDS[0] < float(v) <= LGD_BOUNDS[1]):
        raise ValueError(f"layer4.lgd_cap must be a finite number in ({LGD_BOUNDS[0]}, {LGD_BOUNDS[1]}], got {v!r}")
    return float(v)


def uplift_in_default(settings: Settings) -> bool:
    """`layer4.merton.uplift_in_default` (EQ-B-0097): False drops the Merton LGD uplift for a name already in default.
    Absent: True (today). Must be a JSON boolean; a string such as "false" raises ValueError."""
    v = settings.get("layer4", "merton", "uplift_in_default", default=True)
    if not isinstance(v, (bool, np.bool_)):
        raise ValueError(f"layer4.merton.uplift_in_default must be true or false, got {v!r}")
    return bool(v)


def in_default(flag) -> bool:
    """The universe's `default` column as a boolean (True, "true", 1, "yes")."""
    return str(flag).strip().lower() in ("true", "1", "yes", "1.0")


def applied_uplift(lgd_uplift, defaulted, settings: Settings):
    """The Merton uplift as layer 4 applies it: zero where `defaulted` and `uplift_in_default` is False. Works on a
    scalar or an array (`defaulted` of the same shape); with the key absent it returns `lgd_uplift` unchanged."""
    if uplift_in_default(settings):
        return lgd_uplift
    return np.where(defaulted, 0.0, lgd_uplift) if np.ndim(lgd_uplift) else (0.0 if defaulted else lgd_uplift)


def expected_lgd_hard(base_lgd, lgd_mult, lgd_uplift, settings: Settings):
    """Mean hard-currency LGD with the governed bounds: base x regime multiplier + uplift (already through
    `applied_uplift`), clipped to [LGD_BOUNDS[0], lgd_cap]. The one formula the pipeline's country table and
    layer 6's severity share (EQ-B-0097 review). Vectorised."""
    return np.clip(base_lgd * lgd_mult + lgd_uplift, LGD_BOUNDS[0], lgd_cap(settings))


def haircut_distribution(base_lgd: float, lgd_mult: float, settings: Settings, lgd_uplift: float = 0.0,
                         asset_class: str | None = None) -> tuple[float, float]:
    """Beta(a, b) for the loss given default share, mean `expected_lgd(base_lgd, lgd_mult, lgd_uplift)`.

    The dispersion is `layer4.lgd_sd` unless `layer4.lgd_source` is "fitted", when it is the fitted
    standard deviation of the instrument class (see `effective_severity`)."""
    return beta_params(expected_lgd(base_lgd, lgd_mult, lgd_uplift, lgd_cap(settings)), lgd_sd_for(settings, base_lgd, asset_class))


def sample_haircut(a: float, b: float, u: np.ndarray) -> np.ndarray:
    """Inverse-CDF sampling so the draw can come from a Sobol dimension."""
    return stats.beta.ppf(np.clip(u, 1e-9, 1 - 1e-9), a, b)


def gpd_clipped_mean(sigma: float, xi: float) -> float:
    """E[min(Y, 1)] for Y ~ GPD(xi, sigma) = integral of the survival function over [0, 1] (closed form)."""
    if sigma <= 0:
        return 0.0
    if abs(xi) < 1e-12:
        return sigma * (1.0 - np.exp(-1.0 / sigma))
    if abs(xi - 1.0) < 1e-12:
        return sigma * np.log1p(1.0 / sigma)
    return sigma / (1.0 - xi) * (1.0 - (1.0 + xi / sigma) ** (1.0 - 1.0 / xi))


@lru_cache(maxsize=None)
def gpd_scale(mean_loss: float, xi: float) -> float:
    """Scale sigma such that the GPD loss share capped at 1 has mean `mean_loss` (root-find on the closed form)."""
    target = float(np.clip(mean_loss, 1e-6, 1 - 1e-6))
    return float(brentq(lambda s: gpd_clipped_mean(s, xi) - target, 1e-9, 1e9, xtol=1e-12, rtol=1e-12, maxiter=500))


def gpd_severity(mean_loss: float, u: np.ndarray, settings: Settings) -> np.ndarray:
    """GPD loss share, capped at 100 percent, whose mean (after the cap) equals `mean_loss`."""
    xi = float(settings["layer4"]["gpd_xi"])
    sigma = gpd_scale(round(float(mean_loss), 12), xi)
    y = stats.genpareto.ppf(np.clip(u, 1e-9, 1 - 1e-9), xi, scale=sigma)
    return np.clip(y, 0, 1.0)


def merton_distance_to_distress(u: Universe, settings: Settings, pillar_scores) -> pd.DataFrame:
    """Sovereign DD = [ln(V_A / D_B) + (mu - sigma^2/2) T] / (sigma sqrt T).

    V_A  = reserves + one year of exports (liquid sovereign resources, % of GDP)
    D_B  = short-term external debt + half of foreign-currency government debt (% of GDP)
    sigma= asset volatility base plus the growth-volatility indicator (5.12) in decimal."""
    m = settings["layer4"]["merton"]
    ind = u.indicators.set_index("id")
    prof = u.countries.set_index("country").loc[u.names]
    rows = {}
    for c in u.names:
        reserves, exports = float(prof.at[c, "reserves"]), float(prof.at[c, "exports"])
        debt, fxshare, st_ext = float(ind.at["1.3", c]), float(ind.at["1.5", c]), float(ind.at["2.9", c])
        VA = max(reserves + exports, 1.0)
        DB = max(st_ext / 100 * reserves + 0.5 * debt * fxshare / 100, 1.0)
        sigma = m["asset_vol_base"] + float(ind.at["5.12", c]) / 100
        T = m["horizon_years"]
        dd = (np.log(VA / DB) + (m["drift"] - 0.5 * sigma ** 2) * T) / (sigma * np.sqrt(T))
        rows[c] = {"V_A": VA, "D_B": DB, "sigma_A": sigma, "DD": dd, "pd_merton": float(stats.norm.cdf(-dd)),
                   "lgd_uplift": m["lgd_per_sigma"] * max(0.0, m["dd_reference"] - dd)}
    return pd.DataFrame(rows).T


def position_multipliers(portfolio: pd.DataFrame, settings: Settings) -> pd.DataFrame:
    sec = settings["sector_multipliers"]; loc = settings["location_multipliers"]
    out = portfolio[["id"]].copy()
    out["sector_mult"] = [sec.get(str(s), 1.0) if str(s) != "nan" and s else 1.0 for s in portfolio["sector"]]
    out["location_mult"] = [loc.get(str(s), 1.0) if str(s) != "nan" and s else 1.0 for s in portfolio["location"]]
    return out.set_index("id")


# ---------------------------------------------------------------- haircut fit (GOV-024, EQ-B-0037)

LGD_SOURCES = ("judgement", "fitted")
CLASS_TO_MARKET_KEY = {"hard": "lgd_hard", "local": "lgd_local"}
ASSET_CLASS_TO_INSTRUMENT = {"Eurobond": "hard", "CDS protection": "hard", "Local bond": "local"}

# Column names assumed for the Cruces-Trebesch haircut file (Cruces and Trebesch 2013, "Sovereign
# Defaults: The Price of Haircuts", AEJ: Macro; dataset on Trebesch's site). The published file has
# not been seen in this repository: the aliases below are matched case- and punctuation-
# insensitively, and a file whose headers differ needs one more alias here, not a code change.
HAIRCUT_COLUMNS = {
    "country": ("country", "debtor", "countryname"),
    "year": ("year", "yearofexchange", "exchangeyear", "dateofexchange", "date"),
    "haircut_sz": ("haircutsz", "szhaircut", "haircutpreferredsz", "preferredhaircut", "haircutpreferred", "haircut"),
    "haircut_market": ("haircutmarket", "markethaircut", "haircutmarketmh", "hm", "haircuthm"),
    "debt_restructured_mm": ("debtrestructured", "debtrestructuredusdm", "debtrestructuredusdmn", "debtrestructuredmusd",
                             "debtaffected", "amountrestructured",
                             "debtrestructuredmm"),          # Team A's CT adapter column debt_restructured_mm (HO-20261025-A-B-007)
    # econquest extensions (not in the published file): instrument class and regime at the exchange
    "instrument_class": ("instrumentclass", "class", "instrument"),
    "regime": ("regime",),
}
HAIRCUT_REQUIRED = ("country", "year", "haircut_sz")
HAIRCUT_DOWNLOAD_HINT = ("Download the Cruces-Trebesch haircut dataset (free, Christoph Trebesch's website, 'Sovereign "
                         "Defaults: The Price of Haircuts' data), save it as CSV or XLSX and pass its path.")


def _norm(name: str) -> str:
    return "".join(ch for ch in str(name).lower() if ch.isalnum())


def load_haircuts(path) -> pd.DataFrame:
    """Read a sovereign restructuring haircut table into columns country, year, haircut_sz,
    haircut_market, debt_restructured_mm, instrument_class, regime (haircuts as shares 0-1).

    Refuses a missing file with the download instruction, and a file without the required columns
    with the list of columns it found. Percent haircuts (any value above 1) are divided by 100. Rows
    without a haircut are dropped. instrument_class defaults to "hard" (the dataset covers external
    debt to foreign private creditors); regime is left empty when the file has none."""
    from pathlib import Path
    p = Path(path)
    if not p.is_file():
        raise FileNotFoundError(f"haircut file not found: {p}. {HAIRCUT_DOWNLOAD_HINT} "
                                "The real fit is waiting on this download (GOV-024).")
    raw = pd.read_excel(p) if p.suffix.lower() in (".xlsx", ".xls") else pd.read_csv(p, comment="#")
    found = {_norm(c): c for c in raw.columns}
    cols = {}
    for key, aliases in HAIRCUT_COLUMNS.items():
        for a in aliases:
            if a in found:
                cols[key] = found[a]; break
    missing = [k for k in HAIRCUT_REQUIRED if k not in cols]
    if missing:
        raise ValueError(f"haircut file {p.name} lacks columns {missing} (found {list(raw.columns)}); "
                         "add an alias to layer4_severity.HAIRCUT_COLUMNS")
    out = pd.DataFrame({k: raw[c] for k, c in cols.items()})
    yr = pd.to_numeric(out["year"], errors="coerce")
    if yr.isna().any():                          # a date column ("Date of exchange"): keep its year
        yr = yr.fillna(pd.to_datetime(out["year"], errors="coerce").dt.year)
    out["year"] = yr
    for k in ("haircut_sz", "haircut_market", "debt_restructured_mm"):
        if k in out:
            out[k] = pd.to_numeric(out[k], errors="coerce")
    for k in ("haircut_sz", "haircut_market"):
        if k in out and out[k].max(skipna=True) > 1.0:
            out[k] = out[k] / 100.0
    if "instrument_class" not in out:
        out["instrument_class"] = "hard"
    out["instrument_class"] = out["instrument_class"].fillna("hard").astype(str).str.lower()
    if "regime" not in out:
        out["regime"] = np.nan
    out = out.dropna(subset=["haircut_sz"]).reset_index(drop=True)
    out.attrs["source_file"] = str(p)
    out.attrs["synthetic"] = "synthetic" in p.name.lower()
    return out


def fit_beta_mom(x) -> dict:
    """Beta by the method of moments: a = m k, b = (1 - m) k with k = m (1 - m) / v - 1."""
    x = np.asarray(x, dtype=float)
    m, v = float(x.mean()), float(x.var(ddof=1))
    k = m * (1 - m) / v - 1
    if k <= 0:
        raise ValueError(f"sample variance {v:.4f} too large for a Beta with mean {m:.3f}")
    return {"method": "mom", "a": m * k, "b": (1 - m) * k, "mean": m, "sd": float(np.sqrt(v)), "n": int(x.size)}


def fit_beta_mle(x, eps: float = 1e-4) -> dict:
    """Beta by maximum likelihood on [0, 1] (values clipped to [eps, 1 - eps]), started from the moments."""
    x = np.clip(np.asarray(x, dtype=float), eps, 1 - eps)
    start = fit_beta_mom(x)
    a, b, _, _ = stats.beta.fit(x, start["a"], start["b"], floc=0, fscale=1)
    mean = a / (a + b); sd = float(np.sqrt(a * b / ((a + b) ** 2 * (a + b + 1))))
    return {"method": "mle", "a": float(a), "b": float(b), "mean": float(mean), "sd": sd, "n": int(x.size),
            "loglik": float(stats.beta.logpdf(x, a, b).sum())}


def fit_haircuts(df: pd.DataFrame, column: str = "haircut_sz", min_n: int = 15) -> pd.DataFrame:
    """Beta fits per instrument class, and per (class, regime) where at least `min_n` rows carry
    that regime. One row per group and method, with mean, sd, a, b, n and the debt-weighted mean."""
    rows = []
    groups = [((c, None), g) for c, g in df.groupby("instrument_class")]
    if df["regime"].notna().any():
        groups += [((c, r), g) for (c, r), g in df.dropna(subset=["regime"]).groupby(["instrument_class", "regime"]) if len(g) >= min_n]
    for (cls, regime), g in groups:
        x = g[column].dropna().to_numpy()
        if x.size < min_n:
            continue
        w = g.loc[g[column].notna(), "debt_restructured_mm"] if "debt_restructured_mm" in g else None
        wmean = float(np.average(x, weights=w)) if w is not None and w.notna().all() and w.sum() > 0 else np.nan
        for f in (fit_beta_mom(x), fit_beta_mle(x)):
            rows.append({"instrument_class": cls, "regime": regime or "all", "column": column, "debt_weighted_mean": wmean,
                         "ks_p": float(stats.kstest(np.clip(x, 1e-4, 1 - 1e-4), "beta", args=(f["a"], f["b"])).pvalue), **f})
    return pd.DataFrame(rows)


def fitted_lgd_block(fit: pd.DataFrame, settings: Settings, method: str = "mle", source: str = "") -> dict:
    """The `layer4.fitted_lgd` settings block from a fit table: class-level mean and sd for the chosen
    method, the judgement mean it replaces (`judgement_mean`, percent, read from `settings`), and
    per-regime means as implied multipliers (reported, not applied: the regime LGD multipliers stay
    `regime.*.lgd_mult`)."""
    f = fit[fit["method"] == method]
    block = {"method": method, "source": source, "classes": {}}
    for cls, g in f.groupby("instrument_class"):
        if cls not in CLASS_TO_MARKET_KEY:
            continue
        pooled = g[g["regime"] == "all"].iloc[0]
        entry = {"mean": round(float(pooled["mean"]), 6), "sd": round(float(pooled["sd"]), 6), "n": int(pooled["n"]),
                 "judgement_mean": float(settings["market"][CLASS_TO_MARKET_KEY[cls]])}
        reg = g[g["regime"] != "all"]
        if len(reg):
            entry["implied_lgd_mult"] = {r: round(float(m / pooled["mean"]), 4) for r, m in zip(reg["regime"], reg["mean"])}
        block["classes"][cls] = entry
    return block


def lgd_source(settings: Settings) -> str:
    src = settings.get("layer4", "lgd_source", default="judgement")
    if src not in LGD_SOURCES:
        raise ValueError(f"layer4.lgd_source must be one of {LGD_SOURCES}, got {src!r}")
    return src


def _fitted_classes(settings: Settings) -> dict:
    block = settings.get("layer4", "fitted_lgd", default=None)
    if not block or not block.get("classes"):
        raise ValueError("layer4.lgd_source is 'fitted' but layer4.fitted_lgd has no fitted classes; "
                         "fit the Cruces-Trebesch data first (fit_haircuts -> fitted_lgd_block) or set lgd_source 'judgement'")
    return block["classes"]


def lgd_sd_for(settings: Settings, base_lgd: float | None = None, asset_class: str | None = None) -> float:
    """Beta dispersion for a severity draw: `layer4.lgd_sd` under "judgement" (unchanged); under
    "fitted" the fitted sd of the instrument class, found from `asset_class` or, when the caller does
    not pass it, by matching `base_lgd` to the (already fitted) `market.lgd_hard` / `lgd_local`."""
    if settings.get("layer4", "lgd_source", default="judgement") == "judgement":
        return settings["layer4"]["lgd_sd"]
    classes = _fitted_classes(settings)
    cls = ASSET_CLASS_TO_INSTRUMENT.get(asset_class or "")
    if cls is None and base_lgd is not None:
        for c, key in CLASS_TO_MARKET_KEY.items():
            v = settings.get("market", key)
            if v is not None and abs(float(v) / 100 - float(base_lgd)) < 1e-12:
                cls = c; break
    if cls in classes:
        return float(classes[cls]["sd"])
    return settings["layer4"]["lgd_sd"]


def effective_severity(settings: Settings) -> Settings:
    """Settings with the fitted haircut means in `market.lgd_hard` / `market.lgd_local` (percent)
    when `layer4.lgd_source` is "fitted"; the same object, untouched, under "judgement".

    The fit replaces the judgement baseline, not the value in hand: the new mean is
    `current + 100 * fitted mean - judgement_mean`, so a scenario that has already moved the LGD
    (scenario B's +18 points) keeps its shock on top of the fitted mean; the result is kept within
    [5, 95] percent. A class without a fit (for example local debt, which Cruces-Trebesch does not
    cover) keeps its judgement mean and `layer4.lgd_sd`. Idempotent: the applied settings carry
    `layer4.fitted_lgd_applied` and a second call returns them unchanged."""
    if lgd_source(settings) == "judgement" or settings.get("layer4", "fitted_lgd_applied", default=False):
        return settings
    patches = {"layer4.fitted_lgd_applied": True}
    for cls, entry in _fitted_classes(settings).items():
        key = CLASS_TO_MARKET_KEY.get(cls)
        if key is None:
            continue
        cur = float(settings["market"][key])
        new = cur + 100.0 * float(entry["mean"]) - float(entry.get("judgement_mean", cur))
        patches[f"market.{key}"] = float(np.clip(new, 100 * LGD_BOUNDS[0], 100 * LGD_BOUNDS[1]))
    return settings.copy_with(**patches)
