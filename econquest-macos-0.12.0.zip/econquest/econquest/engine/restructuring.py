"""Restructuring scenarios (EQ-B-0090): haircut model, NPV loss per bond, restructuring path stress.

Off by default. Nothing here is called by `run_pipeline`; the base run is unchanged. The module has three parts.

1. Haircut model. The BoC-BoE (CRAG) default database in data/panel/sovereign_defaults_crag.csv has default
   spells (start and end year), creditor types and the peak amount in default. It has no haircuts. So:
   * the market haircut is fitted on `REFERENCE_RESTRUCTURINGS`, a small table of published bond exchanges typed
     in from the literature (Cruces-Trebesch 2013 and later sources, see docs/validation/restructuring.md). Each
     row carries a low-high range, not a point, plus a confidence flag. The fit uses range midpoints;
   * CRAG calibrates the time in default (delay from default to exchange) for bond defaults (`crag_default_duration`),
     a Kaplan-Meier median that treats spells still open at the as-of year as censored.
   Haircut drivers: government debt (% of GDP, indicator 1.3) and an IMF programme flag are fitted by weighted
   least squares; usable reserves (% of the IMF ARA metric, indicator 2.1) and the rating band enter as judgement
   add-ons (`RESERVES_PP_PER_10`, `RATING_BAND_ADDON`), labelled as such.

   EQ-B-0099: when the Cruces-Trebesch file is present (`CT_DEFAULT_RELPATH` under the data folder, or
   --haircut-file), the fit uses its SZ haircuts settled on or before as_of instead (`haircut_source`), and the
   typed-in table is only the fallback (labelled UNVERIFIED). `compare_with_ct` checks the typed-in rows against it.

2. NPV loss per bond. A bond (coupon, maturity, face 100) goes through a path: default, `delay` years with no
   payments, then an exchange into a new bond with a face haircut, a coupon cut and a maturity extension. Past-due
   coupons (PDI) are capitalised at `pdi_share`. At the exit yield:
     SZ haircut      = 1 - PV(new) / PV(old claim)      (Sturzenegger-Zettelmeyer; old claim = arrears at face
                                                          plus remaining flows, both at the exit yield)
     market haircut  = 1 - PV(new) / 100                (Cruces-Trebesch H_M, against the old face)
     value today     = PV(new) / (1 + y_exit)^delay      (per 100 face, at the default date)
     loss vs par     = 100 - value today;  loss vs market = market price today - value today
   `path_for_haircut` finds the path intensity whose SZ haircut equals a target haircut.

3. Restructuring path stress. `python -m econquest.engine.restructuring --as-of D --names auto|ISO,...` runs the
   base pipeline, takes the riskiest names (top `pd_default`), predicts their haircut, turns it into a path and an
   NPV loss for each Eurobond and CDS protection position, and reports the book loss per name against the model's
   own default loss (notional x Layer 4 expected LGD). It then re-runs Layer 6 with those positions' severity
   replaced by the restructuring loss (same paths, same PDs) and reports VaR/ES/EL next to the base.

No number here reads the wall clock: the as-of date filters CRAG spells and reference episodes.
"""
from __future__ import annotations
import argparse
import dataclasses
import json
import sys
from dataclasses import dataclass
from pathlib import Path
import numpy as np
import pandas as pd
from scipy.optimize import brentq

# ---------------------------------------------------------------- reference table (literature, typed in)

REFERENCE_COLUMNS = ("country", "iso", "year", "settled", "haircut_low", "haircut_high", "face_cut", "debt_gdp", "imf",
                     "delay_yrs", "confidence", "source")

# Bond exchanges with a market (NPV) haircut from published work. Haircuts are shares of the old claim at the exit
# yield the source used (about 10% for the recent cases). These figures are typed in from memory of the papers and
# official exchange documents; they were NOT checked against the sources in this environment (no network). Hence
# ranges, not points. `debt_gdp` is general government debt around the default, rounded to 5 points (approximate).
# `imf`: 1 = IMF programme in place or agreed at the exchange, 0 = none, None = unclear (row left out of the IMF
# term). `delay_yrs`: default (or standstill) to exchange settlement, approximate; 0 = pre-emptive exchange.
# `face_cut`: nominal haircut where a single figure is widely reported, else None. `settled`: settlement month of the
# exchange, APPROXIMATE (from memory, like the haircuts); a row counts from the last day of that month.
# Confidence: "high" = widely cited figure; "medium" = range from several sources; "low" = judgement from partial
# recall. Sources (full references in docs/validation/restructuring.md):
#   CT13   Cruces and Trebesch (2013), Sovereign Defaults: The Price of Haircuts, AEJ: Macroeconomics 5(3)
#   SZ08   Sturzenegger and Zettelmeyer (2008), Haircuts: estimating investor losses in sovereign debt
#          restructurings, 1998-2005, J. Int. Money and Finance 27(5)
#   ZTG13  Zettelmeyer, Trebesch and Gulati (2013), The Greek debt restructuring: an autopsy, Economic Policy 28
#   FST21  Fang, Schumacher and Trebesch (2021), Restructuring sovereign bonds: holdouts, haircuts and the
#          effectiveness of CACs, IMF Economic Review 69
#   MoF    the debtor's finance ministry exchange announcement / offer memorandum
#   IMF    IMF programme review documents (debt sustainability analysis annexes)
REFERENCE_RESTRUCTURINGS: tuple[dict, ...] = (
    {"country": "Argentina", "iso": "ARG", "year": 2020, "settled": "2020-09", "haircut_low": 0.40, "haircut_high": 0.55, "face_cut": 0.02,
     "debt_gdp": 90, "imf": 0, "delay_yrs": 0.4, "confidence": "medium", "source": "FST21; MoF"},
    {"country": "Ecuador", "iso": "ECU", "year": 2020, "settled": "2020-08", "haircut_low": 0.25, "haircut_high": 0.40, "face_cut": 0.09,
     "debt_gdp": 60, "imf": 1, "delay_yrs": 0.2, "confidence": "medium", "source": "FST21; MoF"},
    {"country": "Zambia", "iso": "ZMB", "year": 2024, "settled": "2024-06", "haircut_low": 0.30, "haircut_high": 0.50, "face_cut": 0.18,
     "debt_gdp": 125, "imf": 1, "delay_yrs": 3.6, "confidence": "low", "source": "MoF; IMF"},
    {"country": "Sri Lanka", "iso": "LKA", "year": 2024, "settled": "2024-12", "haircut_low": 0.30, "haircut_high": 0.45, "face_cut": 0.27,
     "debt_gdp": 115, "imf": 1, "delay_yrs": 2.7, "confidence": "medium", "source": "MoF; IMF"},
    {"country": "Ghana", "iso": "GHA", "year": 2024, "settled": "2024-10", "haircut_low": 0.35, "haircut_high": 0.50, "face_cut": 0.37,
     "debt_gdp": 90, "imf": 1, "delay_yrs": 1.8, "confidence": "medium", "source": "MoF; IMF"},
    {"country": "Ukraine", "iso": "UKR", "year": 2024, "settled": "2024-09", "haircut_low": 0.30, "haircut_high": 0.45, "face_cut": 0.37,
     "debt_gdp": 85, "imf": 1, "delay_yrs": 2.1, "confidence": "low", "source": "MoF; IMF"},
    {"country": "Ukraine", "iso": "UKR", "year": 2015, "settled": "2015-11", "haircut_low": 0.20, "haircut_high": 0.30, "face_cut": 0.20,
     "debt_gdp": 70, "imf": 1, "delay_yrs": 0.0, "confidence": "medium", "source": "FST21; MoF"},
    {"country": "Greece", "iso": "GRC", "year": 2012, "settled": "2012-03", "haircut_low": 0.60, "haircut_high": 0.70, "face_cut": 0.535,
     "debt_gdp": 165, "imf": 1, "delay_yrs": 0.0, "confidence": "high", "source": "ZTG13; CT13"},
    {"country": "Argentina", "iso": "ARG", "year": 2005, "settled": "2005-06", "haircut_low": 0.70, "haircut_high": 0.80, "face_cut": None,
     "debt_gdp": 140, "imf": 1, "delay_yrs": 3.3, "confidence": "medium", "source": "SZ08; CT13"},
    {"country": "Ecuador", "iso": "ECU", "year": 2000, "settled": "2000-08", "haircut_low": 0.30, "haircut_high": 0.45, "face_cut": None,
     "debt_gdp": 95, "imf": 1, "delay_yrs": 0.9, "confidence": "medium", "source": "SZ08; CT13"},
    {"country": "Uruguay", "iso": "URY", "year": 2003, "settled": "2003-05", "haircut_low": 0.05, "haircut_high": 0.20, "face_cut": 0.0,
     "debt_gdp": 90, "imf": 1, "delay_yrs": 0.0, "confidence": "medium", "source": "SZ08; CT13"},
    {"country": "Russia", "iso": "RUS", "year": 2000, "settled": "2000-08", "haircut_low": 0.45, "haircut_high": 0.60, "face_cut": None,
     "debt_gdp": 90, "imf": 1, "delay_yrs": 1.5, "confidence": "low", "source": "SZ08; CT13"},
    {"country": "Pakistan", "iso": "PAK", "year": 1999, "settled": "1999-12", "haircut_low": 0.10, "haircut_high": 0.25, "face_cut": 0.0,
     "debt_gdp": 80, "imf": 1, "delay_yrs": 0.3, "confidence": "low", "source": "SZ08; CT13"},
    {"country": "Belize", "iso": "BLZ", "year": 2007, "settled": "2007-02", "haircut_low": 0.20, "haircut_high": 0.30, "face_cut": None,
     "debt_gdp": 90, "imf": 0, "delay_yrs": 0.0, "confidence": "medium", "source": "CT13"},
    {"country": "Belize", "iso": "BLZ", "year": 2021, "settled": "2021-11", "haircut_low": 0.40, "haircut_high": 0.50, "face_cut": 0.45,
     "debt_gdp": 125, "imf": 0, "delay_yrs": 0.3, "confidence": "medium", "source": "MoF (buyback at 55 cents)"},
    {"country": "Jamaica", "iso": "JAM", "year": 2010, "settled": "2010-02", "haircut_low": 0.10, "haircut_high": 0.20, "face_cut": 0.0,
     "debt_gdp": 140, "imf": 1, "delay_yrs": 0.0, "confidence": "medium", "source": "CT13"},
    {"country": "Cote d'Ivoire", "iso": "CIV", "year": 2010, "settled": "2010-04", "haircut_low": 0.50, "haircut_high": 0.60, "face_cut": None,
     "debt_gdp": 65, "imf": 1, "delay_yrs": 10.0, "confidence": "low", "source": "CT13"},
)

CONFIDENCE_WEIGHT = {"high": 1.0, "medium": 0.6, "low": 0.3}       # judgement: WLS weights by confidence
DEBT_CENTRE = 90.0                                                  # debt/GDP centring point of the fit (percent)

# Judgement add-ons (percentage points of haircut), not fitted: the table has too few rows to separate them.
RESERVES_PP_PER_10 = 1.0          # +1 pp per 10 points of usable reserves below 100% of ARA (indicator 2.1) ...
RESERVES_ADDON_CAP = 5.0          # ... capped at +/- 5 pp
RATING_BAND_ADDON = {"SD": 5.0, "D": 5.0, "C": 4.0, "CC": 4.0, "CCC": 2.0, "B": 0.0, "BB": -3.0, "IG": -5.0}
HAIRCUT_BOUNDS = (0.05, 0.95)
MIN_BAND = 0.08                   # low/high scenario half-width: max(weighted residual sd, 8 pp)

# Path and pricing conventions (judgement, recent practice)
EXIT_YIELD = 0.10                 # exit yield at which recent haircuts are quoted (CT13 use 10% for missing cases)
BASE_RATE = 0.04                  # USD risk-free level for coupons and market yields; constant, not market data
ISSUE_SPREAD_CAP_BP = 600.0       # assumed issue coupon = BASE_RATE + min(spread, cap): bonds were issued tighter
MARKET_SPREAD_CAP_BP = 10000.0
PDI_SHARE = 0.5                   # share of past-due interest capitalised into the new claim
DEFAULT_DELAY_YRS = 1.5           # used only when the CRAG file is unavailable
CRAG_SINCE = 2000                 # bond-default spells from the modern bond-exchange era (1990: KM median 2.5y)
PATH_SHAPE = {"face_cut": 0.6, "coupon_cut": 0.7, "extension_yrs": 10.0}   # at intensity 1; scaled linearly
MAX_INTENSITY = 1.5
BOND_CLASSES = ("Eurobond", "CDS protection")


def reference_table(as_of=None) -> pd.DataFrame:
    """The reference episodes as a DataFrame, keeping only exchanges settled on or before as_of. `settled` is a month
    (approximate); the row is known from the last day of that month, so an exchange later in the as-of month or year
    is left out."""
    df = pd.DataFrame(list(REFERENCE_RESTRUCTURINGS), columns=list(REFERENCE_COLUMNS))
    df["haircut_mid"] = (df["haircut_low"] + df["haircut_high"]) / 2
    df["settled_date"] = pd.to_datetime(df["settled"], format="%Y-%m") + pd.offsets.MonthEnd(0)
    if as_of is not None:
        df = df[df["settled_date"] <= pd.Timestamp(as_of)]
    return df.reset_index(drop=True)


# ---------------------------------------------------------------- CRAG calibration: time in default

def kaplan_meier_median(durations, observed) -> float:
    """Median of a right-censored sample by Kaplan-Meier (first time the survival curve drops to 0.5 or below)."""
    d = np.asarray(durations, dtype=float); e = np.asarray(observed, dtype=bool)
    surv = 1.0
    for t in np.unique(d):
        at_risk = (d >= t).sum(); events = ((d == t) & e).sum()
        if at_risk > 0:
            surv *= 1.0 - events / at_risk
        if surv <= 0.5:
            return float(t)
    return float("nan")


def crag_default_duration(path, as_of, since: int = 1990, creditor: str = "bonds") -> dict:
    """Time in default for CRAG spells with `creditor` debt in default that start in [since, as-of year].

    CRAG is annual: a spell start..end is counted as end - start + 0.5 years (0.5 for a one-year spell). A spell whose
    end is at or after the as-of year (or the file's last data year) is censored. Spells after the as-of year are
    dropped, and ends are truncated to the as-of year, so the result never uses data dated after as_of."""
    yr = pd.Timestamp(as_of).year
    df = pd.read_csv(path)
    df = df[df["creditors"].astype(str).str.contains(creditor) & (df["start"] >= since) & (df["start"] <= yr)].copy()
    last = min(yr, int(df["end"].max())) if len(df) else yr
    df["end_obs"] = df["end"].clip(upper=last)
    df["observed"] = df["end"] < last
    df["years"] = df["end_obs"] - df["start"] + 0.5
    done = df[df["observed"]]
    return {"n_spells": int(len(df)), "n_completed": int(len(done)), "n_censored": int((~df["observed"]).sum()),
            "median_completed_yrs": float(done["years"].median()) if len(done) else float("nan"),
            "iqr_completed_yrs": [float(done["years"].quantile(0.25)), float(done["years"].quantile(0.75))] if len(done) else None,
            "km_median_yrs": kaplan_meier_median(df["years"], df["observed"]) if len(df) else float("nan"),
            "since": since, "last_year": last, "creditor": creditor}


# ---------------------------------------------------------------- haircut model

@dataclass
class HaircutModel:
    intercept: float            # haircut at debt = DEBT_CENTRE, no IMF programme
    b_debt: float               # per 10 points of debt/GDP
    b_imf: float                # IMF programme in place
    imf_share: float            # weighted share of IMF rows (used when the flag is unknown)
    resid_sd: float             # weighted residual sd of the midpoints
    n: int
    se: dict

    def predict(self, debt_gdp: float, imf: float | None = None, reserves_ara: float | None = None,
                rating: str | None = None) -> dict:
        """Central, low and high haircut (shares) with each term shown. Unknown IMF flag -> the table's share."""
        imf_v = self.imf_share if imf is None or (isinstance(imf, float) and np.isnan(imf)) else float(imf)
        fitted = self.intercept + self.b_debt * (float(debt_gdp) - DEBT_CENTRE) / 10 + self.b_imf * imf_v
        res = reserves_addon(reserves_ara) / 100
        rat = RATING_BAND_ADDON.get(rating_band(rating), 0.0) / 100
        central = float(np.clip(fitted + res + rat, *HAIRCUT_BOUNDS))
        band = max(self.resid_sd, MIN_BAND)
        return {"haircut": central, "haircut_low": float(np.clip(central - band, *HAIRCUT_BOUNDS)),
                "haircut_high": float(np.clip(central + band, *HAIRCUT_BOUNDS)), "fitted": float(fitted),
                "reserves_addon": res, "rating_addon": rat, "imf_used": imf_v}


def fit_haircut_model(ref: pd.DataFrame | None = None, min_imf_rows: int = 5) -> HaircutModel:
    """WLS of the haircut midpoint on (debt/GDP - 90)/10 and, when the table carries it, the IMF flag. Weights: a
    `weight` column when present (Cruces-Trebesch rows: 1), else by `confidence`. Rows without debt/GDP are dropped.
    The IMF term is fitted only when at least `min_imf_rows` rows carry a flag and both values occur; otherwise it is
    left out (b_imf 0, imf_share 0) and said so in `se`. On the typed-in table the result is unchanged (EQ-B-0090)."""
    ref = reference_table() if ref is None else ref
    d = ref.dropna(subset=["debt_gdp", "haircut_mid"])
    imf = d["imf"] if "imf" in d else pd.Series(np.nan, index=d.index)
    use_imf = bool(imf.notna().sum() >= min_imf_rows and imf.dropna().nunique() > 1)
    if use_imf:
        d = d[imf.notna()]
    if len(d) < 3:
        raise ValueError(f"haircut fit needs at least 3 rows with debt/GDP, got {len(d)}")
    if "weight" in d:
        w = pd.to_numeric(d["weight"], errors="coerce").fillna(1.0).to_numpy(float)
    else:
        w = d["confidence"].map(CONFIDENCE_WEIGHT).fillna(0.3).to_numpy(float)
    cols = [np.ones(len(d)), (d["debt_gdp"].to_numpy(float) - DEBT_CENTRE) / 10]
    if use_imf:
        cols.append(d["imf"].to_numpy(float))
    X = np.column_stack(cols)
    y = d["haircut_mid"].to_numpy(float)
    W = np.diag(w)
    XtWX = X.T @ W @ X
    beta = np.linalg.solve(XtWX, X.T @ W @ y)
    r = y - X @ beta
    dof = max(len(d) - X.shape[1], 1)
    s2 = float((w * r ** 2).sum() / w.sum() * len(d) / dof)
    cov = s2 * np.linalg.inv(XtWX) * w.sum() / len(d)
    se = dict(zip(("intercept", "b_debt", "b_imf"), np.sqrt(np.diag(cov)).round(4).tolist()))
    if not use_imf:
        se["b_imf"] = "not fitted (no IMF flag in the table)"
    b_imf = float(beta[2]) if use_imf else 0.0
    share = float(np.average(d["imf"], weights=w)) if use_imf else 0.0
    return HaircutModel(float(beta[0]), float(beta[1]), b_imf, share, float(np.sqrt(s2)), int(len(d)), se)


# ---------------------------------------------------------------- Cruces-Trebesch file (EQ-B-0099)

# Expected location of Team A's import (EQ-A-0098); the CLI takes --haircut-file to override.
CT_DEFAULT_RELPATH = Path("panel") / "cruces_trebesch_haircuts.csv"
# Extra columns read on top of layer4_severity.HAIRCUT_COLUMNS (matched case- and punctuation-insensitively).
CT_EXTRA_COLUMNS = {
    "iso": ("iso", "iso3", "isocode", "countrycode", "ccode"),
    "settled": ("settled", "settlementdate", "dateofexchange", "exchangedate", "date", "completiondate"),
    "month": ("month", "monthofexchange", "exchangemonth"),
    "debt_gdp": ("debtgdp", "debttogdp", "publicdebtgdp", "govdebtgdp", "debtgdpatdefault"),
    "imf": ("imf", "imfprogram", "imfprogramme", "imfprogram01"),
    "face_cut": ("facevaluereduction", "facecut", "nominalhaircut", "facevalueredn"),
    "case_type": ("type", "debttype", "creditortype", "bondorbank", "instrument"),
    # added to the layer4 aliases (not replacing them): Team A's adapter writes debt_restructured_mm (EQ-A-0098)
    "debt_restructured_mm": ("debtrestructuredmm", "debtrestructuredmusd"),
}


def load_ct_haircuts(path, iso_map: dict | None = None) -> pd.DataFrame:
    """Cruces-Trebesch style haircut table -> iso, country, year, settled_date, haircut_sz, haircut_market,
    debt_restructured_mm, debt_gdp, imf, face_cut, case_type (haircuts as shares).

    Column names follow `layer4_severity.HAIRCUT_COLUMNS` plus `CT_EXTRA_COLUMNS`. Settlement date: a full date column
    when it parses, else year + month, else 31 December of the year (so a row with no month never counts before its
    year has ended). ISO3: an iso column, else `iso_map` on the country name. The file's sha256 and a synthetic flag
    (file name contains "synthetic") go in attrs."""
    import hashlib
    from .layer4_severity import HAIRCUT_COLUMNS, _norm
    p = Path(path)
    if not p.is_file():
        raise FileNotFoundError(f"Cruces-Trebesch haircut file not found: {p} (Team A, EQ-A-0098)")
    raw = pd.read_excel(p) if p.suffix.lower() in (".xlsx", ".xls") else pd.read_csv(p, comment="#")
    found = {_norm(c): c for c in raw.columns}
    cols = {}
    alias_map = {k: tuple(v) for k, v in HAIRCUT_COLUMNS.items()}
    for k, v in CT_EXTRA_COLUMNS.items():
        alias_map[k] = alias_map.get(k, ()) + tuple(a for a in v if a not in alias_map.get(k, ()))
    for key, aliases in alias_map.items():
        for a in aliases:
            if a in found and found[a] not in cols.values():
                cols[key] = found[a]; break
    missing = [k for k in ("country", "haircut_sz") if k not in cols] + ([] if {"year", "settled"} & set(cols) else ["year"])
    if missing:
        raise ValueError(f"haircut file {p.name} lacks columns {missing} (found {list(raw.columns)})")
    out = pd.DataFrame({k: raw[c] for k, c in cols.items()})
    if "settled" not in out and pd.to_numeric(out["year"], errors="coerce").isna().any():
        out = out.rename(columns={"year": "settled"})          # a "Date of exchange" column matched the year alias
    date = pd.to_datetime(out["settled"], errors="coerce") if "settled" in out else pd.Series(pd.NaT, index=out.index)
    year = pd.to_numeric(out["year"], errors="coerce") if "year" in out else date.dt.year
    year = year.fillna(date.dt.year)
    month = pd.to_numeric(out["month"], errors="coerce") if "month" in out else pd.Series(np.nan, index=out.index)
    ym = pd.to_datetime({"year": year.fillna(1900).astype(int), "month": month.fillna(12).clip(1, 12).astype(int), "day": 1},
                        errors="coerce") + pd.offsets.MonthEnd(0)
    out["settled_date"] = date.where(date.notna(), ym.where(year.notna()))
    out["year"] = year
    for k in ("haircut_sz", "haircut_market", "face_cut", "debt_restructured_mm", "debt_gdp", "imf"):
        if k in out:
            out[k] = pd.to_numeric(out[k], errors="coerce")
    for k in ("haircut_sz", "haircut_market", "face_cut"):
        if k in out and out[k].notna().any():
            if out[k].abs().max() > 100.0:
                raise ValueError(f"haircut file {p.name}: {k} outside [-100, 100]: {out.loc[out[k].abs() > 100, k].tolist()[:5]}")
            if out[k].abs().max() > 1.0:
                out[k] = out[k] / 100.0                       # percent
    if "debt_gdp" in out and (out["debt_gdp"] < 5).any():
        bad = out.loc[out["debt_gdp"] < 5, "country"].astype(str).tolist()[:5]
        raise ValueError(f"haircut file {p.name}: debt_gdp below 5 for {bad} (a share, not percent of GDP?)")
    if "iso" not in out:
        out["iso"] = out["country"].map(lambda c: (iso_map or {}).get(str(c).strip()))
    out["iso"] = out["iso"].astype(object).where(out["iso"].notna(), None)
    out["iso"] = [str(x).strip().upper() if x else None for x in out["iso"]]
    for k in ("haircut_market", "debt_restructured_mm", "debt_gdp", "imf", "face_cut", "case_type"):
        if k not in out:
            out[k] = np.nan
    out = out.dropna(subset=["haircut_sz", "settled_date"]).reset_index(drop=True)
    out.attrs.update({"source_file": str(p), "sha256": hashlib.sha256(p.read_bytes()).hexdigest(),
                      "synthetic": "synthetic" in p.name.lower(), "columns_used": cols})
    return out


def iso_name_map(data_dir) -> dict:
    """Country name -> ISO3 from countries.csv, panel/crag_iso_map.csv and panel/universe_proposal.csv (when present)."""
    d = Path(data_dir); m = {}
    for f, name_col, iso_col in ((d / "panel" / "universe_proposal.csv", "country", "iso3"),
                                 (d / "panel" / "crag_iso_map.csv", "country", "iso"), (d / "countries.csv", "country", "iso")):
        if f.is_file():
            t = pd.read_csv(f)
            if name_col in t and iso_col in t:
                m.update({str(a).strip(): str(b).strip().upper() for a, b in zip(t[name_col], t[iso_col]) if pd.notna(a) and pd.notna(b)})
    return m


def ct_reference(ct: pd.DataFrame, as_of, debt_panel: pd.DataFrame | None = None) -> pd.DataFrame:
    """CT rows settled on or before as_of in the reference-table format (haircut_mid = SZ haircut, weight 1).
    Debt/GDP: the file's own column, else `debt_panel` (iso, year, debt_gdp) at the year before the exchange, else the
    exchange year (both on or before as_of). `debt_source` says which; rows with neither keep debt_gdp NaN."""
    d = ct[ct["settled_date"] <= pd.Timestamp(as_of)].copy()
    d["haircut_mid"] = d["haircut_sz"]; d["haircut_low"] = d["haircut_sz"]; d["haircut_high"] = d["haircut_sz"]
    d["weight"] = 1.0
    d["debt_source"] = np.where(d["debt_gdp"].notna(), "ct_file", None)
    if debt_panel is not None and len(debt_panel):
        pan = debt_panel.dropna(subset=["debt_gdp"]).set_index(["iso", "year"])["debt_gdp"]
        pan = pan[~pan.index.duplicated()]
        yr_cap = pd.Timestamp(as_of).year
        for i in d.index[d["debt_gdp"].isna()]:
            iso, y = d.at[i, "iso"], int(d.at[i, "year"])
            for yy in (y - 1, y):
                if iso and yy <= yr_cap and (iso, yy) in pan.index:
                    d.at[i, "debt_gdp"] = float(pan[(iso, yy)]); d.at[i, "debt_source"] = f"panel {yy}"; break
    return d.reset_index(drop=True)


def compare_with_ct(ct: pd.DataFrame, ref: pd.DataFrame | None = None, year_tol: int = 1) -> pd.DataFrame:
    """Each typed-in reference row against the CT file: same ISO3, exchange year within `year_tol` (nearest).
    status: "match" (CT SZ haircut inside the typed range), "mismatch" (outside), "missing" (no CT row)."""
    ref = reference_table() if ref is None else ref
    rows = []
    for _, r in ref.iterrows():
        c = ct[(ct["iso"] == r["iso"]) & ((ct["year"] - r["year"]).abs() <= year_tol)]
        row = {"iso": r["iso"], "year": int(r["year"]), "typed_low": r["haircut_low"], "typed_high": r["haircut_high"],
               "typed_settled": r["settled"], "typed_debt_gdp": r["debt_gdp"], "typed_face_cut": r["face_cut"]}
        if c.empty:
            rows.append({**row, "status": "missing"}); continue
        c = c.iloc[(c["year"] - r["year"]).abs().argsort()].iloc[0]
        hz = float(c["haircut_sz"])
        rows.append({**row, "ct_year": int(c["year"]), "ct_settled": str(pd.Timestamp(c["settled_date"]).date()),
                     "ct_haircut_sz": hz, "ct_haircut_market": c.get("haircut_market"), "ct_face_cut": c.get("face_cut"),
                     "ct_debt_gdp": c.get("debt_gdp"),
                     "status": "match" if r["haircut_low"] - 1e-9 <= hz <= r["haircut_high"] + 1e-9 else "mismatch",
                     "gap_pp": 100 * (hz - min(max(hz, r["haircut_low"]), r["haircut_high"]))})
    return pd.DataFrame(rows)


CT_LICENCE_SOURCE_ID = "cruces_trebesch_haircuts"
MIN_CT_ROWS = 3


def ct_provenance_ok(f: Path, sha256: str) -> tuple[bool, str]:
    """True when a sidecar `<stem>.provenance.json` next to the file carries a key "sha256" (anywhere in the JSON)
    equal to the file's sha256."""
    side = f.with_name(f.stem + ".provenance.json")
    if not side.is_file():
        return False, f"no provenance sidecar {side.name}"
    try:
        doc = json.loads(side.read_text())
    except (OSError, ValueError) as e:
        return False, f"provenance sidecar unreadable: {e}"
    found = []
    def walk(x):
        if isinstance(x, dict):
            for k, v in x.items():
                if k == "sha256" and isinstance(v, str):
                    found.append(v.lower())
                walk(v)
        elif isinstance(x, list):
            for v in x:
                walk(v)
    walk(doc)
    if sha256.lower() in found:
        return True, "provenance sha256 matches"
    return False, "provenance sidecar sha256 does not match the file" if found else "provenance sidecar has no sha256"


def ct_licence_row(f: Path, data_dir: Path, register: list[dict] | None = None) -> dict | None:
    """The licence-register row for the CT file, found by its data-dir relative path, and only when it is the
    Cruces-Trebesch row (`CT_LICENCE_SOURCE_ID`). None for a file outside the data folder or without that row."""
    from ..ingestion import licences
    try:
        rel = f.resolve().relative_to(Path(data_dir).resolve()).as_posix()
    except ValueError:
        return None
    reg = licences.safe_register() if register is None else register
    for row in reg:
        if row.get("source_id") == CT_LICENCE_SOURCE_ID and licences.matches(row, path=rel):
            return {k: v for k, v in row.items() if not str(k).startswith("_")}
    return None


def _fallback(as_of, why: str, **extra) -> dict:
    return {"ref": reference_table(as_of), "source": "typed-in reference table (fallback)", "verified": False,
            "label": f"{UNVERIFIED}; fallback: {why}", "ct_file": None, **extra}


def haircut_source(data_dir, as_of, haircut_file=None, register: list[dict] | None = None) -> dict:
    """Pick the haircut calibration: the CT file when present and usable (rows settled <= as_of, debt/GDP from the file
    or the hazard panel), else the typed-in table with the UNVERIFIED label and the reason.

    Falls back when the file is missing, is rejected by `load_ct_haircuts`, or leaves fewer than MIN_CT_ROWS rows
    with debt/GDP. `verified` is True only when ALL hold: the file name does not say "synthetic"; the licence
    register (data/licences.csv, or `register`) has the Cruces-Trebesch row matching the file's data-dir path with
    internal_use "yes"; a `<stem>.provenance.json` sidecar carries a sha256 equal to the file's. The label states the
    rows dropped for missing debt/GDP and the licence terms status. Verified is about where the figures come from,
    not about client use (the register row says restricted)."""
    d = Path(data_dir)
    f = Path(haircut_file) if haircut_file else d / CT_DEFAULT_RELPATH
    if not f.is_file():
        return _fallback(as_of, f"no Cruces-Trebesch file at {f}", ct_missing=str(f))
    try:
        ct = load_ct_haircuts(f, iso_name_map(d))
    except ValueError as e:
        return _fallback(as_of, f"Cruces-Trebesch file rejected: {e}")
    panel_f = d / "panel" / "hazard_panel.csv"
    panel = pd.read_csv(panel_f, usecols=["iso", "year", "debt_gdp"]) if panel_f.is_file() else None
    ref = ct_reference(ct, as_of, panel)
    used = ref.dropna(subset=["debt_gdp"])
    dropped = int(len(ref) - len(used))
    ct_asof = ct[ct["settled_date"] <= pd.Timestamp(as_of)]
    comparison = compare_with_ct(ct_asof, reference_table(as_of))
    if len(used) < MIN_CT_ROWS:
        return _fallback(as_of, f"Cruces-Trebesch file {f.name} has {len(used)} usable rows settled <= {as_of} "
                         f"(need {MIN_CT_ROWS}; {dropped} dropped for missing debt/GDP)", comparison=comparison)
    synthetic = bool(ct.attrs.get("synthetic"))
    lic = ct_licence_row(f, d, register)
    prov_ok, prov_msg = ct_provenance_ok(f, ct.attrs["sha256"])
    checks = {"not_synthetic": not synthetic, "licence_row": bool(lic and lic.get("internal_use") == "yes"),
              "provenance_sha256": prov_ok}
    verified = all(checks.values())
    tag = "SYNTHETIC Cruces-Trebesch fixture" if synthetic else "Cruces-Trebesch file"
    label = (f"haircuts from {tag} {f.name} (sha256 {ct.attrs['sha256'][:16]}): {len(used)} cases settled <= {as_of} "
             f"used, {dropped} dropped for missing debt/GDP")
    if lic:
        label += f"; licence terms {lic.get('terms_verified', 'UNVERIFIED')}, client output {lic.get('client_output')}"
    if not verified:
        failed = [k for k, v in checks.items() if not v]
        label += f"; NOT a verified calibration (failed: {', '.join(failed)}; {prov_msg})"
    return {"ref": used.reset_index(drop=True), "source": label, "verified": verified, "label": label, "ct_file": str(f),
            "ct_sha256": ct.attrs["sha256"], "comparison": comparison, "ct_rows": int(len(ct)),
            "rows_without_debt": dropped, "checks": checks}


def rating_band(rating) -> str:
    """Rating band for the judgement add-on: SD/D, C/CC, CCC, B, BB, IG (BBB- and above)."""
    r = str(rating or "").strip().upper().rstrip("+-")
    if r in ("SD", "D", "RD"):
        return "SD"
    if r in ("C", "CC"):
        return "CC"
    if r in ("CCC", "B", "BB"):
        return r
    if r in ("BBB", "A", "AA", "AAA"):
        return "IG"
    return "unknown"


def reserves_addon(reserves_ara) -> float:
    """Judgement add-on in pp: +RESERVES_PP_PER_10 per 10 points of usable reserves below 100% of ARA, capped."""
    if reserves_ara is None or not np.isfinite(float(reserves_ara)):
        return 0.0
    return float(np.clip((100.0 - float(reserves_ara)) / 10 * RESERVES_PP_PER_10, -RESERVES_ADDON_CAP, RESERVES_ADDON_CAP))


# ---------------------------------------------------------------- bond arithmetic (face 100, annual compounding)

def cashflows(coupon: float, maturity: float, face: float = 100.0, freq: int = 2, amort_years: float = 0.0):
    """Times (years) and amounts of a fixed-coupon bond from now. Bullet, or equal principal instalments over the
    last `amort_years` (at the coupon dates). A broken first period is paid in full at its date."""
    maturity = float(maturity)
    if maturity <= 0:
        return np.array([0.0]), np.array([face])
    step = 1.0 / freq
    n = int(np.ceil(maturity * freq - 1e-9))
    t = maturity - step * np.arange(n)[::-1]
    out = np.zeros(n); outstanding = face
    amort = t > maturity - amort_years + 1e-9 if amort_years > 0 else np.zeros(n, bool)
    amort[-1] = True
    k = int(amort.sum()); inst = face / k
    for i in range(n):
        out[i] = outstanding * coupon / freq
        if amort[i]:
            out[i] += inst; outstanding -= inst
    return t, out


def pv(times, flows, y: float) -> float:
    return float(np.sum(np.asarray(flows) * (1.0 + y) ** -np.asarray(times)))


def price(coupon: float, maturity: float, y: float, freq: int = 2) -> float:
    t, f = cashflows(coupon, maturity, freq=freq)
    return pv(t, f, y)


def modified_duration(coupon: float, maturity: float, y: float, freq: int = 2) -> float:
    t, f = cashflows(coupon, maturity, freq=freq)
    p = pv(t, f, y)
    return float(np.sum(t * f * (1 + y) ** -t) / p / (1 + y))


def maturity_for_duration(coupon: float, y: float, duration: float, freq: int = 2, max_maturity: float = 40.0) -> float:
    """Maturity whose modified duration at yield y equals `duration`; `max_maturity` if out of reach."""
    if duration <= 0:
        return 0.5
    if modified_duration(coupon, max_maturity, y, freq) <= duration:
        return max_maturity
    return float(brentq(lambda m: modified_duration(coupon, m, y, freq) - duration, 1.0 / freq, max_maturity, xtol=1e-8))


@dataclass
class Bond:
    coupon: float               # annual coupon rate (0.08 = 8%)
    maturity: float             # years from the default date
    freq: int = 2


@dataclass
class RPath:
    face_cut: float = 0.0       # share of (principal + capitalised PDI) written off
    coupon_cut: float = 0.0     # new coupon = old coupon x (1 - coupon_cut)
    extension_yrs: float = 0.0  # new final maturity = remaining old maturity after exit + extension
    delay_yrs: float = 0.0      # default to exchange; no payments in between
    pdi_share: float = PDI_SHARE
    exit_yield: float = EXIT_YIELD
    amort_years: float = 0.0    # 0 = bullet; else equal instalments over the last amort_years of the new bond


def restructuring_npv(bond: Bond, path: RPath, market_price: float | None = None) -> dict:
    """Value of one bond (per 100 face) through a restructuring path; see the module docstring for definitions."""
    y, dl = path.exit_yield, max(float(path.delay_yrs), 0.0)
    t, f = cashflows(bond.coupon, bond.maturity, freq=bond.freq)
    principal = np.zeros_like(f); principal[-1] = 100.0
    coupons = f - principal
    due = t <= dl + 1e-12
    arrears_cpn = float(coupons[due].sum())
    arrears_prin = float(principal[due].sum())
    # old claim at exit: arrears at face plus the remaining contractual flows discounted from the exit date
    pv_old = arrears_cpn + arrears_prin + pv(t[~due] - dl, f[~due], y)
    new_face = (1.0 - path.face_cut) * (100.0 + path.pdi_share * arrears_cpn)
    new_mat = max(bond.maturity - dl, 0.0) + path.extension_yrs
    new_mat = max(new_mat, 1.0)
    nt, nf = cashflows(bond.coupon * (1.0 - path.coupon_cut), new_mat, face=new_face, freq=bond.freq,
                       amort_years=min(path.amort_years, new_mat))
    pv_new = pv(nt, nf, y)
    today = pv_new * (1.0 + y) ** -dl
    out = {"pv_new_at_exit": pv_new, "pv_old_at_exit": pv_old, "sz_haircut": 1.0 - pv_new / pv_old,
           "market_haircut": 1.0 - pv_new / 100.0, "value_today": today, "loss_vs_par_pct": 100.0 - today,
           "new_face": new_face, "new_coupon": bond.coupon * (1.0 - path.coupon_cut), "new_maturity": new_mat,
           "arrears_coupons": arrears_cpn}
    if market_price is not None:
        out["market_price"] = float(market_price)
        out["loss_vs_market_pct"] = float(market_price) - today
    return out


def path_at(intensity: float, delay_yrs: float, exit_yield: float = EXIT_YIELD, pdi_share: float = PDI_SHARE,
            shape: dict | None = None) -> RPath:
    s = shape or PATH_SHAPE
    k = max(float(intensity), 0.0)
    return RPath(face_cut=min(0.95, s["face_cut"] * k), coupon_cut=min(0.95, s["coupon_cut"] * k),
                extension_yrs=s["extension_yrs"] * k, delay_yrs=delay_yrs, pdi_share=pdi_share, exit_yield=exit_yield)


def path_for_haircut(bond: Bond, target_sz: float, delay_yrs: float, exit_yield: float = EXIT_YIELD,
                     pdi_share: float = PDI_SHARE, shape: dict | None = None) -> tuple[RPath, float]:
    """The path along `shape` whose SZ haircut equals `target_sz`; returns (path, intensity). Targets below the
    zero-intensity haircut (arrears not capitalised) give intensity 0; above the MAX_INTENSITY haircut, the cap."""
    f = lambda k: restructuring_npv(bond, path_at(k, delay_yrs, exit_yield, pdi_share, shape))["sz_haircut"] - target_sz
    if f(0.0) >= 0:
        k = 0.0
    elif f(MAX_INTENSITY) <= 0:
        k = MAX_INTENSITY
    else:
        k = float(brentq(f, 0.0, MAX_INTENSITY, xtol=1e-10))
    return path_at(k, delay_yrs, exit_yield, pdi_share, shape), k


def bond_from_position(duration_yrs: float, spread_bp: float, coupon: float | None = None, maturity: float | None = None,
                       base_rate: float = BASE_RATE) -> tuple[Bond, float]:
    """Bond terms for a portfolio row, which has only a duration. Coupon: base rate + min(spread, issue cap); maturity:
    the one whose modified duration at that coupon (a par bond) equals the duration. Returns (bond, market price
    today at base + spread)."""
    c = coupon if coupon is not None else base_rate + min(float(spread_bp), ISSUE_SPREAD_CAP_BP) / 1e4
    m = maturity if maturity is not None else maturity_for_duration(c, c, float(duration_yrs) if duration_yrs else 5.0)
    b = Bond(coupon=c, maturity=m)
    ym = base_rate + min(float(spread_bp), MARKET_SPREAD_CAP_BP) / 1e4
    return b, price(b.coupon, b.maturity, ym, b.freq)


# ---------------------------------------------------------------- restructuring path stress

def _row(df, key, default=None):
    return df[key] if key in df else default


def name_drivers(u, country: pd.DataFrame, name: str) -> dict:
    ind = u.indicators.set_index("id")
    get = lambda i: float(ind.at[i, name]) if i in ind.index and name in ind.columns and pd.notna(ind.at[i, name]) else float("nan")
    return {"debt_gdp": get("1.3"), "reserves_ara": get("2.1"), "rating": str(country.at[name, "rating"])}


def select_names(country: pd.DataFrame, names: str = "auto", top: int = 5, portfolio: pd.DataFrame | None = None) -> list[str]:
    """`auto`: the `top` names by pd_default, counting only names with a Eurobond or CDS position when `portfolio`
    is given (a name with only FX or equity has no bond to restructure); otherwise a comma list of ISO3 codes (or
    country names), kept as given."""
    if names in (None, "", "auto"):
        ranked = country["pd_default"].sort_values(ascending=False, kind="mergesort")
        if portfolio is not None:
            held = set(portfolio.loc[portfolio["asset_class"].isin(BOND_CLASSES), "country"])
            ranked = ranked[[c in held for c in ranked.index]]
        return list(ranked.head(top).index)
    wanted = [x.strip() for x in str(names).split(",") if x.strip()]
    iso = {str(v).upper(): k for k, v in country["iso"].items()}
    out = []
    for w in wanted:
        if w in country.index:
            out.append(w)
        elif w.upper() in iso:
            out.append(iso[w.upper()])
        else:
            raise ValueError(f"unknown name {w!r}: not an ISO3 code or country in the run")
    return out


def restructuring_table(u, country: pd.DataFrame, settings, names: list[str], model: HaircutModel, delay_yrs: float,
                        imf_flags: dict | None = None, exit_yield: float = EXIT_YIELD, base_rate: float = BASE_RATE) -> pd.DataFrame:
    """One row per position of the selected names. Eurobond and CDS protection rows get the restructuring loss
    (central, low, high) next to the model's default loss; other classes are listed with in_scope False."""
    prof = u.countries.set_index("country")
    rows = []
    for name in names:
        drv = name_drivers(u, country, name)
        imf = (imf_flags or {}).get(str(country.at[name, "iso"]).upper())
        hc = model.predict(drv["debt_gdp"], imf, drv["reserves_ara"], drv["rating"])
        spread = float(prof.at[name, "spread"])
        lgd = float(country.at[name, "lgd_hard_expected"])
        pos = u.portfolio[u.portfolio["country"] == name]
        if pos.empty:
            rows.append({"country": name, "iso": country.at[name, "iso"], "id": None, "asset_class": None, "in_scope": False,
                         "pd_default": float(country.at[name, "pd_default"]), "note": "no position"})
            continue
        for _, p in pos.iterrows():
            ac = p["asset_class"]; n = float(p["notional_mm"])
            sign = 1.0 if str(p["direction"]).lower().startswith("long") else -1.0
            r = {"country": name, "iso": country.at[name, "iso"], "id": p["id"], "asset_class": ac, "direction": p["direction"],
                 "notional_mm": n, "pd_default": float(country.at[name, "pd_default"]), "rating": drv["rating"],
                 "debt_gdp": drv["debt_gdp"], "reserves_ara": drv["reserves_ara"], "imf_used": hc["imf_used"],
                 "in_scope": ac in BOND_CLASSES}
            if ac not in BOND_CLASSES:
                r["note"] = "not a hard-currency bond or CDS: model loss unchanged"
                rows.append(r); continue
            dur = float(p["duration_yrs"]) if pd.notna(p["duration_yrs"]) else 5.0
            cpn = pd.to_numeric(_row(p, "coupon_pct"), errors="coerce") if "coupon_pct" in p else np.nan
            mat = pd.to_numeric(_row(p, "maturity_yrs"), errors="coerce") if "maturity_yrs" in p else np.nan
            bond, mkt = bond_from_position(dur, spread, None if pd.isna(cpn) else float(cpn) / 100,
                                           None if pd.isna(mat) else float(mat), base_rate)
            # the model: on a default path, notional x LGD (Eurobond loses, CDS protection gains)
            pos_sign = sign * (1.0 if ac == "Eurobond" else -1.0)
            r.update({"coupon": bond.coupon, "maturity_yrs": bond.maturity, "market_price": mkt, "model_lgd": lgd,
                      "model_default_loss_mm": pos_sign * n * lgd})
            for tag, h in (("", hc["haircut"]), ("_low", hc["haircut_low"]), ("_high", hc["haircut_high"])):
                path, k = path_for_haircut(bond, h, delay_yrs, exit_yield)
                res = restructuring_npv(bond, path, mkt)
                r[f"haircut_sz{tag}"] = res["sz_haircut"]
                r[f"loss_vs_par_pct{tag}"] = res["loss_vs_par_pct"]
                r[f"restructuring_loss_mm{tag}"] = pos_sign * n * res["loss_vs_par_pct"] / 100
                if tag == "":
                    r.update({"intensity": k, "face_cut": path.face_cut, "coupon_cut": path.coupon_cut,
                              "extension_yrs": path.extension_yrs, "market_haircut": res["market_haircut"],
                              "value_today": res["value_today"], "loss_vs_market_pct": res["loss_vs_market_pct"],
                              "restructuring_loss_vs_market_mm": pos_sign * n * res["loss_vs_market_pct"] / 100})
            r["difference_mm"] = r["restructuring_loss_mm"] - r["model_default_loss_mm"]
            rows.append(r)
    return pd.DataFrame(rows)


def stressed_positions(positions: pd.DataFrame, table: pd.DataFrame, column: str = "loss_vs_par_pct") -> pd.DataFrame:
    """Layer 6 positions with the default severity of the in-scope rows replaced by the restructuring loss
    (lossA_pct = +/- loss, regime multiplier 1, Merton uplift 0). PDs and thresholds are unchanged."""
    out = positions.copy()
    for _, r in table[table["in_scope"].astype(bool)].iterrows():
        pid = r["id"]
        if pid not in out.index:
            continue
        sgn = np.sign(out.at[pid, "lossA_pct"]) or 1.0
        out.at[pid, "lossA_pct"] = sgn * float(r[column])
        out.at[pid, "lgd_mult"] = 1.0
        out.at[pid, "lgd_uplift"] = 0.0
    return out


def rerun_layer6(u, run, settings, positions: pd.DataFrame, paths: int):
    """Re-simulate Layer 6 on the base run's inputs with other positions. The GPR uplift on indicator 4.10 is
    re-applied as in run_pipeline, so the loadings are the base run's."""
    from . import layer3_regime as L3, layer6_montecarlo as L6
    s = dataclasses.replace(settings, raw=run.settings)
    if run.gpr_country is not None:
        ind = u.indicators.set_index("id")
        ind.loc["4.10", u.names] = [float(run.gpr_country.at[c, "final_410"]) for c in u.names]
        u = dataclasses.replace(u, indicators=ind.reset_index())
    gweight = run.diagnostics["global_stress_weight"]
    loadings = L3.blended_factor_loadings(u, s, run.country["regime"], gweight)
    return L6.simulate(u, run.country, positions, loadings, s, run.diagnostics["degrees_of_freedom"], paths=paths)


METRIC_KEYS = ("var99_mm", "es99_mm", "expected_loss_mm", "lvar99_mm")
UNVERIFIED = ("reference haircuts typed from memory, UNVERIFIED until the Cruces-Trebesch dataset replaces them "
              "(GOV-024)")


def el_breakdown(mc, positions: pd.DataFrame, names: list[str], exclude: list[str] | None = None) -> dict:
    """Expected loss of a Layer 6 result (a) as simulated, (b) without the spread income (carry) on each position's
    default paths, and (c) with the positions of `exclude` left out. Layer 6 adds a full year of carry on every path,
    default paths included; (b) takes it off the paths where the position's default leg hits. The long-loss cap is
    re-applied: for carry income (bonds) this is exact, since a capped path had an uncapped loss of at least notional;
    for a carry cost (CDS protection) on a capped path it is approximate (such paths are a protection gain, not capped,
    in practice)."""
    col = {c: i for i, c in enumerate(names)}
    pl = mc.position_losses.copy()
    for j, (_pid, p) in enumerate(positions.iterrows()):
        carry = float(p["carry_mm"])
        if carry == 0.0 or p["kindA"] != "beta" or not np.isfinite(p["thrA"]):
            continue
        hit = mc.latent[:, col[p["country"]]] < p["thrA"]
        adj = pl[hit, j] - carry
        pl[hit, j] = np.minimum(adj, p["notional_mm"]) if p["sign"] > 0 else adj
    keep = ~positions["country"].isin(exclude or []).to_numpy()
    return {"el_mm": float(mc.losses.mean()), "el_no_default_carry_mm": float(pl.sum(axis=1).mean()),
            "el_excluding_mm": float(mc.position_losses[:, keep].sum(axis=1).mean()), "excluded": list(exclude or [])}


def run_restructuring_stress(data_dir="data", as_of=None, names: str = "auto", top: int = 5, paths: int = 20000,
                             exit_yield: float = EXIT_YIELD, imf_flags: dict | None = None, rerun_mc: bool = True,
                             haircut_file=None) -> dict:
    from ..config import Settings
    from ..ingestion import load_universe
    from .pipeline import run_pipeline
    data_dir = Path(data_dir)
    u = load_universe(str(data_dir)); s = Settings.load(data_dir / "assumptions.json")
    run = run_pipeline(u, s, paths=paths, as_of=as_of, market_dir=str(data_dir))   # market store read only with market_term on (EQ-B-0129)
    as_of = run.settings["as_of"]
    crag_path = data_dir / "panel" / "sovereign_defaults_crag.csv"
    crag = crag_default_duration(crag_path, as_of, since=CRAG_SINCE) if crag_path.is_file() else None
    delay = crag["km_median_yrs"] if crag and np.isfinite(crag["km_median_yrs"]) else DEFAULT_DELAY_YRS
    src = haircut_source(data_dir, as_of, haircut_file)
    ref = src["ref"]
    model = fit_haircut_model(ref)
    sel = select_names(run.country, names, top, u.portfolio)
    ranked = list(run.country["pd_default"].sort_values(ascending=False, kind="mergesort").index)
    skipped = [c for c in ranked[:ranked.index(sel[-1]) + 1] if c not in sel] if sel and names in (None, "", "auto") else []
    tab = restructuring_table(u, run.country, s, sel, model, delay, imf_flags, exit_yield)
    scope = tab[tab["in_scope"].astype(bool)] if len(tab) else tab
    agg = {}
    if len(scope):
        by = scope.groupby("country")[["notional_mm", "model_default_loss_mm", "restructuring_loss_mm", "restructuring_loss_mm_low",
                                       "restructuring_loss_mm_high", "restructuring_loss_vs_market_mm", "difference_mm"]].sum()
        agg = {"by_name": by.round(4).reset_index().to_dict("records"), "total": by.sum().round(4).to_dict()}
    out = {"as_of": as_of, "label": f"restructuring stress (EQ-B-0090), off by default; not a base number; {src['label']}",
           "haircut_source": {k: v for k, v in src.items() if k not in ("ref", "comparison")},
           "ct_comparison": src["comparison"].to_dict("records") if "comparison" in src else None,
           "names": sel, "skipped_no_bond_exposure": skipped, "exit_yield": exit_yield, "delay_yrs": delay, "crag_duration": crag,
           "model": dataclasses.asdict(model), "reference_rows": int(len(ref)), "positions": tab.to_dict("records"), **agg,
           "base_metrics": {k: float(run.mc.metrics[k]) for k in METRIC_KEYS}, "paths": paths}
    names_order = list(run.country.index)
    top1 = sel[:1]                                  # the highest-PD selected name (Venezuela today)
    out["base_el"] = el_breakdown(run.mc, run.positions, names_order, top1)
    if rerun_mc and len(scope):
        st = stressed_positions(run.positions, tab)
        mc = rerun_layer6(u, run, s, st, paths)
        out["restructuring_metrics"] = {k: float(mc.metrics[k]) for k in METRIC_KEYS}
        out["restructuring_el"] = el_breakdown(mc, st, names_order, top1)
    return out


def _fmt(out: dict) -> str:
    hs = (out.get("haircut_source") or {}).get("label", UNVERIFIED)
    lines = [f"Restructuring stress, as_of {out['as_of']} (off by default; not a base number; {hs})",
             f"exit yield {out['exit_yield']:.1%}, delay {out['delay_yrs']:.2f}y (CRAG KM median), names {', '.join(out['names'])}"
             + (f" (skipped, no bond or CDS: {', '.join(out['skipped_no_bond_exposure'])})" if out.get("skipped_no_bond_exposure") else ""),
             "haircut model: h = {intercept:.3f} + {b_debt:.3f} x (debt-90)/10 + {b_imf:.3f} x IMF; resid sd {resid_sd:.3f}, n {n}".format(**out["model"])]
    pos = pd.DataFrame(out["positions"])
    if len(pos) and "haircut_sz" in pos:
        cols = ["country", "id", "asset_class", "notional_mm", "pd_default", "model_lgd", "haircut_sz", "loss_vs_par_pct",
                "model_default_loss_mm", "restructuring_loss_mm", "restructuring_loss_mm_low", "restructuring_loss_mm_high"]
        lines.append(pos[pos["in_scope"].astype(bool)][cols].round(3).to_string(index=False))
    if out.get("ct_comparison"):
        st = pd.DataFrame(out["ct_comparison"])["status"].value_counts().to_dict()
        lines.append("typed-in table vs CT: " + json.dumps(st))
    if "total" in out:
        lines.append("total: " + json.dumps(out["total"]))
    lines.append("base Layer 6: " + json.dumps({k: round(v, 3) for k, v in out["base_metrics"].items()}))
    if "restructuring_metrics" in out:
        lines.append("restructuring severity: " + json.dumps({k: round(v, 3) for k, v in out["restructuring_metrics"].items()}))
    for tag in ("base_el", "restructuring_el"):
        if tag in out:
            e = out[tag]
            lines.append(f"{tag}: EL {e['el_mm']:.3f}, without spread income on default paths {e['el_no_default_carry_mm']:.3f}, "
                         f"without {', '.join(e['excluded']) or '-'} {e['el_excluding_mm']:.3f}")
    return "\n".join(lines)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.engine.restructuring", description=__doc__.split("\n")[0])
    ap.add_argument("--as-of", required=True)
    ap.add_argument("--names", default="auto", help="auto (top PD) or a comma list of ISO3 codes")
    ap.add_argument("--top", type=int, default=5)
    ap.add_argument("--paths", type=int, default=20000)
    ap.add_argument("--exit-yield", type=float, default=EXIT_YIELD)
    ap.add_argument("--imf", default="", help="ISO3:0|1 pairs, e.g. ARG:1,PAK:1 (unknown -> reference share)")
    ap.add_argument("--data", default="data")
    ap.add_argument("--haircut-file", default=None, help="Cruces-Trebesch CSV/XLSX (default <data>/panel/cruces_trebesch_haircuts.csv; "
                    "missing -> typed-in fallback, labelled UNVERIFIED)")
    ap.add_argument("--no-mc", action="store_true", help="skip the Layer 6 re-run")
    ap.add_argument("--out", default=None, help="folder under outputs/ for restructuring.json (default "
                    "outputs/restructuring/<as_of>); anything outside outputs/ is refused")
    ap.add_argument("--write", action="store_true", help="write restructuring.json (otherwise console only)")
    a = ap.parse_args(argv)
    out_dir = None
    if a.write or a.out:
        from ..validation.activation import resolve_out_dir, OUTPUTS_ROOT
        try:
            out_dir = resolve_out_dir(a.out or str(Path(OUTPUTS_ROOT) / "restructuring" / a.as_of), a.as_of)
        except ValueError as e:
            ap.error(str(e))
    imf = {k.strip().upper(): float(v) for k, v in (x.split(":") for x in a.imf.split(",") if ":" in x)}
    out = run_restructuring_stress(a.data, a.as_of, a.names, a.top, a.paths, a.exit_yield, imf, not a.no_mc, a.haircut_file)
    print(_fmt(out))
    if out_dir is not None:
        out_dir.mkdir(parents=True, exist_ok=True)
        f = out_dir / "restructuring.json"
        f.write_text(json.dumps(out, indent=1, default=float))
        print(f)
    return 0


if __name__ == "__main__":
    sys.exit(main())
