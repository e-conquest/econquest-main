"""Layer 1: base event probability via discrete-time hazard modelling (paper section 3.1).

* `HazardModel` holds a logistic hazard with Firth-style coefficients. The default coefficient
  vector is the paper's panel estimate (section 7.1) applied to standardized predictors; see
  data/assumptions.json -> layer1.note for why the raw-unit coefficients are not usable as printed.
* `fit_firth` estimates the same model from a country-year panel with Firth's (1993) penalized
  likelihood (Jeffreys prior), which keeps rare-event estimates finite and reduces small-sample bias.
* `RatingChallenger` stands in for the LightGBM monotonic challenger: an independent, monotone
  mapping from rating to 12-month PD. The two are reconciled in log-odds space.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np
import pandas as pd
from .common import logit, expit, as_of_timestamp
from ..config import Settings
from ..ingestion import Universe

FEATURES = ["debt_gdp", "stfx_debt_reserves", "reserves_months_imports", "primary_deficit_gap",
            "pitf_instability", "commodity_export_shock"]
# extra predictors a fitted model (validation/hazard_panel.py) may use; produced by build_features as well
PANEL_EXTRA = ["primary_deficit", "current_account", "real_growth", "inflation_log"]


DEFAULT_PREDICTOR_LAG = 1   # hazard_panel.panel_from_long default (EQ-B-0006): row t uses year t-1 values


def resolve_predictor_lag(fitted_block: dict | None) -> tuple[int, str]:
    """Predictor lag the fitted block was trained with, and where the number came from (EQ-B-0013).

    `econquest fit-hazard` stores `predictor_lag` in the block (FitResult.fitted_block). A block written before
    EQ-B-0006 has no such key; it is then taken as DEFAULT_PREDICTOR_LAG and the note says it was assumed, so the
    model metadata shows the alignment is not confirmed by the block itself."""
    lag = (fitted_block or {}).get("predictor_lag")
    if lag is None:
        return DEFAULT_PREDICTOR_LAG, f"assumed {DEFAULT_PREDICTOR_LAG} (no predictor_lag in the fitted block)"
    lag = int(lag)
    if lag < 0:
        raise ValueError(f"layer1_fitted.predictor_lag must be >= 0, got {lag}")
    return lag, "layer1_fitted.predictor_lag"


def weo_panel_features() -> dict[str, tuple[str, str]]:
    """Panel features sourced from the IMF WEO: feature -> (series code, transform), as in hazard_panel.PANEL_FEATURES."""
    from ..validation.hazard_panel import PANEL_FEATURES
    return {f: (code, how) for f, (tab, code, how) in PANEL_FEATURES.items() if tab == "weo"}


# How build_features makes each panel feature at run time when it is NOT taken from the loaded history with the panel's
# definition. A fitted model trained on the panel must not be scored on these (EQ-B-0029).
RUNTIME_DEFINITIONS = {
    "stfx_debt_reserves": "indicator 2.9 from the indicator table",
    "reserves_months_imports": "Country Profile reserves / exports x 12 (exports stand in for imports)",
    "pitf_instability": "pillar 4 aggregate / 25",
}


def unaligned_fitted_features(features) -> dict[str, str]:
    """Fitted-block features that have no run-time source with the panel's definition, each with the reason (EQ-B-0029).

    Only WEO-sourced panel features are aligned at run time (`weo_aligned`, EQ-B-0013). The World Bank-sourced ones
    (hazard_panel.PANEL_FEATURES tab "worldbank": DT.DOD.DSTC.IR.ZS, FI.RES.TOTL.MO, WGI PV.EST) are not loaded into
    the Universe, so build_features would substitute the indicator-table definitions in RUNTIME_DEFINITIONS; features
    that are not panel features at all were never trained by hazard_panel. `run_layer1` refuses a fitted block that
    lists any of them, as GOV-046 refuses missing WEO inputs."""
    from ..validation.hazard_panel import PANEL_FEATURES
    wf = weo_panel_features()
    out = {}
    for f in features:
        if f in wf:
            continue
        if f in PANEL_FEATURES:
            tab, code, how = PANEL_FEATURES[f]
            out[f] = (f"panel uses {tab} {code} ({how}); no {tab} history in the Universe, run time would use "
                      f"{RUNTIME_DEFINITIONS.get(f, 'a different definition')}")
        else:
            out[f] = "not a hazard_panel feature, so no panel definition to align with"
    return out


def build_features(u: Universe, pillar4_aggregated: pd.Series, as_of=None, predictor_lag: int = 0,
                   weo_aligned: list[str] | tuple[str, ...] = ()) -> pd.DataFrame:
    """Macro-fiscal predictors from the indicator table and country profile.

    reserves_months_imports uses exports as the import proxy (imports are not in the snapshot);
    pitf_instability is the pillar 4 aggregate rescaled to the 0-4 PITF range; commodity_export_shock
    is the main export's price gap to its 10-year average in tens of percent (positive = favourable).

    When WEO history is loaded, the primary balance is taken for year `as_of.year - predictor_lag` (the run's
    as-of date, required in that case; never the wall clock, GOV-012). `run_layer1` passes the lag the fitted
    model was trained with (EQ-B-0013); a direct call with the default 0 keeps the calendar year of `as_of`.

    `weo_aligned` names panel features (see `weo_panel_features`) to take from the WEO history for that same year
    with the panel's transform instead of from the indicator table, so a fitted model sees inputs aligned as in
    training. Those columns carry NaN where the WEO history has no value and never fall back to another series
    (GOV-046); `attrs["weo_missing"]` lists the gaps and `run_layer1` refuses the fitted model when any exist."""
    from ..validation.hazard_panel import transform_today
    ind = u.indicators.set_index("id")
    prof = u.countries.set_index("country")
    weo = getattr(u, "weo_raw", None)
    have_weo = weo is not None and len(weo) > 0
    iso_of = prof["iso"].to_dict()
    year = None
    pb_live = {}
    if have_weo:
        year = int(as_of_timestamp(None, as_of).year) - int(predictor_lag)
        pb = weo[(weo["series"] == "GGXONLB_NGDP") & (weo["period"] == year)].dropna(subset=["value"]).set_index("iso")["value"]
        pb_live = {c: float(pb[iso_of[c]]) for c in u.names if iso_of.get(c) in pb.index}
    rows = {}
    for c in u.names:
        exports = max(float(prof.at[c, "exports"]), 1.0)
        rows[c] = {
            # predictors shared with the fitted panel model (same transforms as validation/hazard_panel.py)
            "primary_deficit": -pb_live[c] if c in pb_live else -float(ind.at["1.6", c]),
            "current_account": float(ind.at["2.8", c]),
            "real_growth": float(ind.at["5.6", c]),
            "inflation_log": transform_today("inflation_log", float(ind.at["5.5", c])),
            "debt_gdp": float(ind.at["1.3", c]),
            "stfx_debt_reserves": float(ind.at["2.9", c]),
            "reserves_months_imports": float(prof.at[c, "reserves"]) / exports * 12.0,
            "primary_deficit_gap": -float(ind.at["1.6", c]),
            "pitf_instability": float(pillar4_aggregated[c]) / 25.0,
            "commodity_export_shock": float(prof.at[c, "commgap"] or 0.0) / 10.0,
        }
    out = pd.DataFrame(rows).T[FEATURES + PANEL_EXTRA]
    aligned_src, missing = {}, {}
    if weo_aligned:
        wf = weo_panel_features()
        bad = [f for f in weo_aligned if f not in wf]
        if bad:
            raise ValueError(f"weo_aligned features {bad} are not WEO panel features {sorted(wf)}")
        for f in weo_aligned:
            code, _how = wf[f]
            if have_weo:
                ser = weo[(weo["series"] == code) & (weo["period"] == year)].dropna(subset=["value"]).set_index("iso")["value"]
                ser = ser[~ser.index.duplicated(keep="last")]
            else:
                ser = pd.Series(dtype=float)
            vals = {c: (transform_today(f, float(ser[iso_of[c]])) if iso_of.get(c) in ser.index else np.nan) for c in u.names}
            out[f] = pd.Series(vals, dtype=float)
            aligned_src[f] = f"WEO {code} year {year}" if have_weo else "no WEO history loaded"
            gaps = [c for c in u.names if not np.isfinite(vals[c])]
            if gaps:
                missing[f] = gaps
    if "primary_deficit" in aligned_src:
        out.attrs["primary_deficit_source"] = aligned_src["primary_deficit"] if have_weo else "missing: no WEO history loaded (no gap fallback for a fitted model, GOV-046)"
    else:
        out.attrs["primary_deficit_source"] = f"WEO GGXONLB_NGDP year {year}" if pb_live else "minus the 1.6 primary-balance gap (no WEO history loaded)"
    out.attrs["predictor_year"] = year
    out.attrs["predictor_lag"] = int(predictor_lag)
    out.attrs["weo_aligned"] = aligned_src
    out.attrs["weo_missing"] = missing
    return out


@dataclass
class HazardModel:
    coef: dict[str, float]
    intercept: float
    scale: dict[str, tuple[float, float]] | None = None    # feature -> (centre, spread); None = raw units
    meta: dict = field(default_factory=dict)
    features: list[str] = field(default_factory=lambda: list(FEATURES))

    def linear_index(self, X: pd.DataFrame) -> np.ndarray:
        z = X[self.features].to_numpy(dtype=float).copy()
        if self.scale:
            for j, f in enumerate(self.features):
                m, s = self.scale[f]
                z[:, j] = (z[:, j] - m) / s
        b = np.array([self.coef[f] for f in self.features])
        return self.intercept + z @ b

    def predict(self, X: pd.DataFrame) -> np.ndarray:
        return expit(self.linear_index(X))

    @classmethod
    def from_settings(cls, settings: Settings, X: pd.DataFrame, calibration_target: np.ndarray | None,
                      calibration_mask: np.ndarray | None = None) -> "HazardModel":
        """`calibration_mask` (bool per row of X) limits the countries the rating-prior calibration is fitted on;
        None uses every country in X (the shipped behaviour). See `calibration_mask` below (EQ-B-0034)."""
        cfg = settings["layer1"]
        sel = np.ones(len(X), dtype=bool) if calibration_mask is None else np.asarray(calibration_mask, dtype=bool)
        if cfg.get("mode") == "fitted" and settings.get("layer1_fitted"):
            # coefficients estimated on a real default panel by `econquest fit-hazard --apply` (validation/hazard_panel.py)
            fb = settings["layer1_fitted"]
            m = cls(dict(fb["coef"]), float(fb["intercept"]), {f: tuple(v) for f, v in fb["scale"].items()},
                    {"mode": "fitted", "fitted_on": fb.get("fitted_on"), "panel": fb.get("panel"), "out_of_sample": fb.get("out_of_sample")},
                    list(fb["features"]))
            if calibration_target is not None and cfg.get("fitted_intercept_to_rating_prior", False):
                idx = m.linear_index(X); target = logit(calibration_target); ok = np.isfinite(target) & sel
                m.intercept += float(np.median(target[ok]) - np.median(idx[ok]))
                m.meta["calibration"] = {"intercept": m.intercept}
            return m
        coef = dict(settings["layer1_paper_coefficients"])
        intercept = coef.pop("intercept")
        scale = None
        if cfg.get("mode", "paper_standardized") == "paper_standardized":
            scale = {f: tuple(cfg["feature_scale"][f]) for f in FEATURES}
        m = cls(coef, intercept, scale, {"mode": cfg.get("mode")})
        if calibration_target is not None and cfg.get("calibrate_to") in ("median_rating_prior", "rating_prior_location_scale"):
            idx = m.linear_index(X)
            target = logit(calibration_target)
            ok = np.isfinite(target) & sel
            if calibration_mask is not None and ok.sum() < 2:
                raise ValueError(f"layer 1 calibration needs at least 2 countries with a rating prior, got {int(ok.sum())}")
            if cfg["calibrate_to"] == "rating_prior_location_scale":
                # a + b * index fitted to the rating prior: the paper's coefficients keep their direction and
                # relative weights, the location and spread of the hazard come from the rating prior.
                b, a = np.polyfit(idx[ok], target[ok], 1)
                b = float(max(b, 0.25))   # never flip the paper's signs; keep at least a quarter of the spread
                m.coef = {f: c * b for f, c in m.coef.items()}
                m.intercept = float(a + b * m.intercept)
                m.meta["calibration"] = {"slope": b, "intercept": m.intercept}
            else:
                m.intercept += float(np.median(target[ok]) - np.median(idx[ok]))
                m.meta["calibration"] = {"intercept": m.intercept}
        return m


def fit_firth(X: np.ndarray, y: np.ndarray, max_iter: int = 50, tol: float = 1e-8) -> tuple[np.ndarray, dict]:
    """Firth penalized logistic regression. X without intercept column; returns (beta incl. intercept, info).

    Score equations: U*(b) = X'(y - p + h (1/2 - p)) with h the hat-matrix diagonal."""
    n, k = X.shape
    Xd = np.column_stack([np.ones(n), X])
    b = np.zeros(k + 1)
    for it in range(max_iter):  # noqa: B007 (it is read after the loop)
        eta = Xd @ b
        p = expit(eta)
        W = p * (1 - p)
        XW = Xd * W[:, None]
        I = Xd.T @ XW
        I_inv = np.linalg.pinv(I)
        h = np.einsum("ij,jk,ik->i", Xd, I_inv, XW)
        U = Xd.T @ (y - p + h * (0.5 - p))
        step = I_inv @ U
        b_new = b + step
        if np.max(np.abs(step)) < tol:
            b = b_new
            break
        b = b_new
    eta = Xd @ b
    p = expit(eta)
    ll = np.sum(y * np.log(np.clip(p, 1e-12, 1)) + (1 - y) * np.log(np.clip(1 - p, 1e-12, 1)))
    W = p * (1 - p)
    I = Xd.T @ (Xd * W[:, None])
    pen_ll = ll + 0.5 * np.linalg.slogdet(I)[1]
    se = np.sqrt(np.diag(np.linalg.pinv(I)))
    return b, {"iterations": it + 1, "loglik": float(ll), "penalized_loglik": float(pen_ll), "se": se}


def fit_hazard_from_panel(panel: pd.DataFrame, settings: Settings) -> HazardModel:
    """Fit from a panel with FEATURES columns and a binary `event` column (default within 12 months)."""
    X = panel[FEATURES].to_numpy(dtype=float)
    y = panel["event"].to_numpy(dtype=float)
    b, info = fit_firth(X, y)
    return HazardModel({f: float(b[i + 1]) for i, f in enumerate(FEATURES)}, float(b[0]), None,
                       {"mode": "fitted_firth", **{k: (v.tolist() if hasattr(v, "tolist") else v) for k, v in info.items()}})


class RatingChallenger:
    """Monotone challenger: rating-implied 12-month PD (stand-in for the LightGBM monotonic model)."""

    def __init__(self, settings: Settings):
        self.table = settings["ratings_pd"]

    def predict(self, ratings: pd.Series) -> np.ndarray:
        return np.array([self.table.get(str(r).strip(), np.nan) for r in ratings], dtype=float)


def reconcile(p_hazard: np.ndarray, p_challenger: np.ndarray, hazard_weight: float) -> np.ndarray:
    """Cross-model reconciliation in log-odds space (paper 8.1: 'cross-validation penalization reconciles')."""
    w = float(np.clip(hazard_weight, 0, 1))
    return expit(w * logit(p_hazard) + (1 - w) * logit(p_challenger))


def calibration_mask(u: Universe, settings: Settings) -> tuple[np.ndarray | None, str]:
    """Countries the rating-prior calibration of layer 1 is fitted on (EQ-B-0034).

    The paper_standardized calibration (`calibrate_to`) and the fitted-mode intercept shift fit a location (and
    scale) across the countries of the run, so every country's hazard PD depends on which other countries are in
    the universe: growing the desk universe from 18 to 70+ countries moves all PDs even when no input changes.
    `layer1.calibration_universe` (a list of country names or ISO3 codes) pins the calibration set; it is fitted on
    those countries and applied to all. Absent or null (the code default) means every country in the run,
    the pre-0.3.0 behaviour exactly. Shipped pinned to the 18 desk names since CHG-20261024T122445Z-5753a1."""
    sel = settings.get("layer1", "calibration_universe", default=None)
    if sel is None:
        return None, "all countries in the run"
    want = {str(x).strip() for x in sel}
    prof = u.countries.set_index("country")
    mask = np.array([(c in want) or (str(prof.at[c, "iso"]) in want) for c in u.names], dtype=bool)
    unknown = sorted(want - set(u.names) - set(prof["iso"].astype(str)))
    if unknown:
        raise ValueError(f"layer1.calibration_universe names countries not in the universe: {unknown}")
    return mask, f"layer1.calibration_universe ({int(mask.sum())} countries)"


# ---------------------------------------------------------------- VF-012 missing-input rule (EQ-B-0080), off by default

MISSING_INPUT_RULES = ("paper", "carry_forward_k", "impute_peer")
DEFAULT_MISSING_INPUT_K = 2
MIN_PEERS = 3


def missing_input_settings(settings: Settings) -> tuple[str, int]:
    """`layer1.missing_input_rule` and `layer1.missing_input_k` with their code defaults ("paper", 2).

    "paper" (code default): one missing fitted input sends the whole run to paper_standardized. Shipped settings use
    "carry_forward_k" with k 2 since CHG-20261024T165907Z-d4aff0 (Sam 2026-10-24); inert while layer1.mode is paper."""
    rule = str(settings.get("layer1", "missing_input_rule", default="paper"))
    if rule not in MISSING_INPUT_RULES:
        raise ValueError(f"layer1.missing_input_rule must be one of {MISSING_INPUT_RULES}, got {rule!r}")
    k = int(settings.get("layer1", "missing_input_k", default=DEFAULT_MISSING_INPUT_K))
    if k < 1:
        raise ValueError(f"layer1.missing_input_k must be >= 1, got {k}")
    return rule, k


def point_in_time_weo(settings: Settings, as_of) -> tuple[pd.DataFrame, str]:
    """The WEO the missing-input rule may read: the latest pull dated on or before as_of (`dsa.load_weo_as_of` under
    `layer1.missing_input_data_dir`, default "data"). Never `Universe.weo_raw`, whose pull date is not recorded.
    A frame with a `vintage` column (a vintaged history) keeps only rows released on or before as_of, latest release
    per cell. Raises ValueError when no pull is dated on or before as_of."""
    from .dsa import load_weo_as_of
    weo, src = load_weo_as_of(settings.get("layer1", "missing_input_data_dir", default="data"), as_of)
    ts = as_of_timestamp(None, as_of)
    retrieved = weo.attrs.get("retrieved")
    if retrieved is not None and pd.Timestamp(retrieved).normalize() > ts.normalize():
        raise ValueError(f"WEO pull {retrieved} is after as_of {ts.date()}")
    if "vintage" in weo.columns:
        v = pd.to_datetime(weo["vintage"], errors="coerce")
        weo = weo[v.notna() & (v.dt.normalize() <= ts.normalize())].assign(_v=v)
        weo = weo.sort_values("_v").drop_duplicates(["iso", "series", "period"], keep="last").drop(columns="_v")
        weo.attrs["retrieved"] = retrieved
    return weo, src


def _rating_band(r) -> str:
    """Letter band of a rating for peer groups: AA (AAA to AA-), A, BBB, BB, B, C (CCC+ and below, SD, D)."""
    r = str(r).strip().upper().rstrip("+-")
    if r.startswith("AA"):
        return "AA"
    if r in ("A", "BBB", "BB", "B"):
        return r
    return "C"


def fill_missing_inputs(X: pd.DataFrame, u: Universe, features, rule: str, k: int, weo: pd.DataFrame,
                        predictor_year: int) -> tuple[pd.DataFrame, dict]:
    """Fill the NaN fitted inputs of X under `rule`; return the filled copy and a record (VF-012, EQ-B-0080).

    carry_forward_k: take the same WEO series for the country from year predictor_year - 1, then - 2, ... down to
    predictor_year - k, the first one present, with the panel transform. Only earlier periods are read (never a
    projection for a later year), and `weo` must already be point in time (`point_in_time_weo`).
    impute_peer: the median of the feature over the run's other countries in the same rating band (`_rating_band`)
    that have a value, when at least MIN_PEERS do. Peers and their values are taken from the input X before any
    fill, so a country filled earlier in the loop is never counted as a peer (EQ-B-0080 review).
    A country with any input still missing is listed in `rating_fallback`: run_layer1 gives it the rating-implied PD
    as its hazard PD, for that country only."""
    from ..validation.hazard_panel import transform_today
    wf = weo_panel_features()
    X0 = X                  # the unfilled table: impute_peer reads peers only from here
    X = X.copy()
    iso_of = u.countries.set_index("country")["iso"].to_dict()
    ratings = u.countries.set_index("country")["rating"].to_dict()
    filled: dict[str, dict[str, str]] = {}
    gaps = {f: [c for c in X.index if pd.isna(X.at[c, f])] for f in features if X[f].isna().any()}
    for f, cs in gaps.items():
        for c in cs:
            how = None
            if rule == "carry_forward_k" and f in wf:
                code = wf[f][0]
                ser = weo[(weo["iso"] == iso_of.get(c)) & (weo["series"] == code)].dropna(subset=["value"])
                ser = ser[~ser["period"].duplicated(keep="last")].set_index("period")["value"]
                for j in range(1, k + 1):
                    y = predictor_year - j
                    if y in ser.index:
                        X.at[c, f] = transform_today(f, float(ser[y]))
                        how = f"carried forward from WEO {code} year {y} ({j} year(s) old)"
                        break
            elif rule == "impute_peer":
                band = _rating_band(ratings.get(c))
                peers = [p for p in X0.index if p != c and _rating_band(ratings.get(p)) == band and pd.notna(X0.at[p, f])]
                if len(peers) >= MIN_PEERS:
                    X.at[c, f] = float(np.median([X0.at[p, f] for p in peers]))
                    how = f"median of {len(peers)} {band}-band peers ({', '.join(peers)})"
            if how:
                filled.setdefault(c, {})[f] = how
    still = sorted({c for f in features for c in X.index if pd.isna(X.at[c, f])})
    affected = sorted(set(filled) | set(still))
    n = max(len(X.index), 1)
    rec = {"rule": rule, "k": k if rule == "carry_forward_k" else None, "predictor_year": predictor_year,
           "gaps": gaps, "filled": filled, "rating_fallback": still,
           "share_countries_affected": len(affected) / n, "share_rating_fallback": len(still) / n}
    return X, rec


def model_features_of(settings: Settings, X: pd.DataFrame) -> list[str]:
    """Features the fitted block scores (EQ-B-0080 helper)."""
    return [f for f in settings["layer1_fitted"]["features"] if f in X.columns]


def run_layer1(u: Universe, settings: Settings, pillar4_aggregated: pd.Series, as_of=None) -> pd.DataFrame:
    """Hazard, rating challenger and reconciled pd_model per country.

    Fitted mode (EQ-B-0013, GOV-046): the WEO-sourced predictors are taken for year `as_of.year - predictor_lag`,
    the lag stored in `layer1_fitted` (training alignment of hazard_panel.panel_from_long). If any of them cannot
    be sourced from the WEO history (none loaded, or a country lacks that year), the fitted model is not scored
    on substitute inputs: the run falls back to `paper_standardized` for every country and says so in
    `attrs["model"]["fitted_fallback"]` (and a RuntimeWarning).

    EQ-B-0029: the same refusal applies when the fitted block lists a feature with no run-time source aligned with the
    panel definition (`unaligned_fitted_features`: today every World Bank-sourced feature); the reasons are in
    `attrs["model"]["fitted_unaligned"]`. Paper mode is not affected.

    EQ-B-0080 (VF-012): `layer1.missing_input_rule` "carry_forward_k" or "impute_peer" replaces the whole-run fallback
    for missing WEO inputs with a per-country rule (`fill_missing_inputs`); a country still missing gets the
    rating-implied PD. The record is in `attrs["model"]["missing_inputs"]`. Default "paper" keeps the code path above
    unchanged. The rule never applies to unaligned features (EQ-B-0029) and reads only a WEO pull dated <= as_of."""
    import warnings
    if as_of is None:
        as_of = settings.get("as_of")
    cfg = settings["layer1"]
    fb = settings.get("layer1_fitted") if cfg.get("mode") == "fitted" else None
    lag, lag_source = resolve_predictor_lag(fb if fb else settings.get("layer1_fitted"))
    fallback = None
    missing_rec = None      # EQ-B-0080: record of the missing-input rule when it ran
    unaligned = unaligned_fitted_features(fb["features"]) if fb else {}
    if unaligned:
        # EQ-B-0029: the fitted coefficients were estimated on the panel's definitions; scoring them on substitutes
        # (indicator 2.9, reserves / exports, pillar 4 / 25) is refused for the whole run, like missing WEO inputs
        fallback = ("fitted model refused: features without a run-time source aligned with the panel: "
                    + "; ".join(f"{f}: {why}" for f, why in unaligned.items())
                    + "; ran paper_standardized instead (EQ-B-0029, GOV-046)")
        warnings.warn(fallback, RuntimeWarning, stacklevel=2)
        settings = settings.copy_with(**{"layer1.mode": "paper_standardized"})
        X = build_features(u, pillar4_aggregated, as_of, predictor_lag=lag)
    elif fb:
        wf = weo_panel_features()
        aligned = [f for f in fb["features"] if f in wf]
        X = build_features(u, pillar4_aggregated, as_of, predictor_lag=lag, weo_aligned=aligned)
        if X.attrs["weo_missing"] or X[list(fb["features"])].isna().any().any():
            gaps = X.attrs["weo_missing"] or {f: [c for c in X.index if pd.isna(X.at[c, f])] for f in fb["features"] if X[f].isna().any()}
            rule, k = missing_input_settings(settings)
            rule_note = ""
            if rule != "paper":
                # EQ-B-0080 (VF-012), off by default: fill per country, rating-implied PD for a country still missing
                try:
                    if X.attrs["predictor_year"] is None:
                        # no WEO history on the universe, so no predictor year to carry back from (was a TypeError)
                        raise ValueError("no WEO history loaded, so no predictor year")
                    weo_pit, weo_src = point_in_time_weo(settings, as_of)
                    Xf, rec = fill_missing_inputs(X, u, list(fb["features"]), rule, k, weo_pit, X.attrs["predictor_year"])
                    chal_chk = RatingChallenger(settings).predict(u.countries.set_index("country").loc[rec["rating_fallback"], "rating"])
                    if not np.isfinite(chal_chk).all():
                        raise ValueError(f"no rating-implied PD for {rec['rating_fallback']}")
                    rec["weo_source"] = weo_src
                    missing_rec, X = rec, Xf
                    warnings.warn(f"layer 1 missing-input rule {rule}: filled {rec['filled']}; rating-implied PD for "
                                  f"{rec['rating_fallback'] or 'no country'} (VF-012)", RuntimeWarning, stacklevel=2)
                except ValueError as e:
                    rule_note = f"; missing-input rule {rule} could not run: {e}"
            if missing_rec is None:
                fallback = ("fitted model refused: predictors missing for year "
                            f"{X.attrs['predictor_year']} (as_of minus predictor_lag {lag}): "
                            + "; ".join(f"{f}: {', '.join(cs)}" for f, cs in gaps.items())
                            + rule_note + "; ran paper_standardized instead (GOV-046)")
                warnings.warn(fallback, RuntimeWarning, stacklevel=2)
                settings = settings.copy_with(**{"layer1.mode": "paper_standardized"})
                X = build_features(u, pillar4_aggregated, as_of, predictor_lag=lag)
    else:
        X = build_features(u, pillar4_aggregated, as_of, predictor_lag=lag)
    prof = u.countries.set_index("country")
    chal = RatingChallenger(settings).predict(prof.loc[u.names, "rating"])
    cal_mask, cal_source = calibration_mask(u, settings)
    rf = missing_rec["rating_fallback"] if missing_rec else []
    if rf:
        # EQ-B-0080: countries with an input still missing take the rating-implied PD as hazard PD and are left out
        # of the intercept calibration; their NaN inputs are scored at the scale centre only to keep the array finite
        is_rf = np.isin(np.asarray(X.index), rf)
        cal_mask = (np.ones(len(X), dtype=bool) if cal_mask is None else cal_mask) & ~is_rf
        Xs = X.copy()
        for f in model_features_of(settings, X):
            centre = (settings["layer1_fitted"].get("scale", {}).get(f) or [0.0])[0]
            Xs[f] = Xs[f].fillna(float(centre))
        model = HazardModel.from_settings(settings, Xs, chal, cal_mask)
        p_haz = np.where(is_rf, chal, model.predict(Xs))
    else:
        model = HazardModel.from_settings(settings, X, chal, cal_mask)
        p_haz = model.predict(X)
    p_model = reconcile(p_haz, chal, settings.get("layer1", "hazard_weight", default=0.5))
    out = X.copy()
    out["pd_hazard"] = p_haz
    out["pd_rating"] = chal
    out["pd_model"] = p_model
    out.attrs["model"] = {"coef": model.coef, "intercept": model.intercept, "scale": model.scale, "features": model.features,
                          "primary_deficit_source": X.attrs.get("primary_deficit_source"),
                          "predictor_year": X.attrs.get("predictor_year"), "predictor_lag": lag, "predictor_lag_source": lag_source,
                          "weo_aligned": X.attrs.get("weo_aligned", {}), **model.meta}
    if cal_mask is not None:
        out.attrs["model"]["calibration_universe"] = cal_source
    if fallback:
        out.attrs["model"]["fitted_fallback"] = fallback
    if missing_rec:
        out.attrs["model"]["missing_inputs"] = missing_rec
    if unaligned:
        out.attrs["model"]["fitted_unaligned"] = dict(unaligned)
    return out
