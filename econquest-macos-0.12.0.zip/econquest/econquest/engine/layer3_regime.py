"""Layer 3: regime dynamics (paper 3.3).

Two estimators share one interface:
* `rule_regime` - the operational proxy: spread, 3-month depreciation and reserve-loss thresholds.
* `GaussianHMM` - a 3-state Gaussian hidden Markov model fitted by EM (Baum-Welch) on sovereign
  spreads, depreciation and reserve changes; `decode` returns Viterbi states, `transition_matrix`
  replaces the starting matrix in assumptions.json once enough history is available.
The transition matrix gives expected 12-month PD and LGD multipliers: row(current regime) . multipliers.

Global state (EQ-B-0042, GOV-018): `global_share` is the share of `regime.global_set` countries not Calm
("all" by default); `global_stress_weight` turns it into a Stressed weight, a step at
`monte_carlo.global_stress_share` by default or a logistic ramp with `regime.global_switch` "logistic";
`blended_factor_loadings` / `blended_degrees_of_freedom` give layer 5 inputs for that weight.
"""
from __future__ import annotations
import numpy as np
import pandas as pd
from ..config import Settings, REGIMES
from ..ingestion import Universe


def rule_regime(u: Universe, settings: Settings) -> pd.Series:
    rr = settings["regime_rules"]
    prof = u.countries.set_index("country").loc[u.names]
    out = []
    for _c, r in prof.iterrows():
        sp, fx, res = float(r["spread"]), float(r["fx3m"]), float(r["res3m"])
        if r["default"] or sp >= rr["crisis_spread"] or fx >= rr["crisis_fx3m"]:
            out.append("Crisis")
        elif sp >= rr["stressed_spread"] or fx >= rr["stressed_fx3m"] or res <= rr["stressed_res3m"]:
            out.append("Stressed")
        else:
            out.append("Calm")
    s = pd.Series(out, index=u.names, name="regime_model")
    ov = settings.scenario_override
    if ov == "All crisis":
        return pd.Series("Crisis", index=u.names, name="regime")
    if ov == "All stressed":
        return s.where(s == "Crisis", "Stressed").rename("regime")
    return s.rename("regime")


def transition_matrix(settings: Settings) -> np.ndarray:
    tm = settings["transition_matrix"]
    P = np.array([tm["From Calm"], tm["From Stressed"], tm["From Crisis"]], dtype=float)
    return P / P.sum(axis=1, keepdims=True)


def regime_multipliers(regime: pd.Series, settings: Settings, P: np.ndarray | None = None) -> pd.DataFrame:
    """Expected 12-month PD and LGD multipliers; `P` overrides the assumptions matrix (e.g. the fitted HMM matrix)."""
    reg = settings["regime"]
    pdm = np.array([reg[r]["pd_mult"] for r in REGIMES])
    lgdm = np.array([reg[r]["lgd_mult"] for r in REGIMES])
    P = transition_matrix(settings) if P is None else np.asarray(P, dtype=float) / np.asarray(P, dtype=float).sum(axis=1, keepdims=True)
    use = settings["transition_matrix"].get("use", True)
    rows = {}
    for c, r in regime.items():
        i = REGIMES.index(r)
        if use:
            rows[c] = {"pd_mult": float(P[i] @ pdm), "lgd_mult": float(P[i] @ lgdm)}
        else:
            rows[c] = {"pd_mult": float(pdm[i]), "lgd_mult": float(lgdm[i])}
        rows[c]["p_crisis_12m"] = float(P[i, 2])
    return pd.DataFrame(rows).T


GLOBAL_SWITCHES = ("step", "logistic")
DEFAULT_SWITCH_WIDTH = 0.05


def _proposal_lookup(settings: Settings) -> pd.DataFrame:
    """name -> (iso3, tier) from the approved universe proposal (data/panel/universe_proposal.csv, or
    `regime.global_set_proposal`); only read when `regime.global_set` names ISO codes or tiers."""
    from ..ingestion.universe import DEFAULT_PROPOSAL
    from .tiers import tier_by_name                     # the shared tier reader (EQ-B-0055), also behind stress.country_tiers
    path = settings.get("regime", "global_set_proposal", default=None) or DEFAULT_PROPOSAL
    return tier_by_name(path)


def global_set(regime: pd.Series, settings: Settings) -> list[str]:
    """The countries the global stress share is computed over (EQ-B-0042, GOV-018). `regime.global_set`:
    "all" (default, every country in the run: the behaviour before EQ-B-0042), a list of country names or ISO3
    codes, or {"tiers": [...]} / {"exclude_tiers": [...]} over the universe-proposal tiers (desk_current, EM,
    frontier, DM_anchor). Countries of the list that are not in the run are skipped; an unknown name or an empty
    set raises, so a typo cannot silently turn the switch off."""
    spec = settings.get("regime", "global_set", default="all")
    names = list(regime.index)
    if spec is None or (isinstance(spec, str) and spec.lower() == "all"):
        return names
    if isinstance(spec, (list, tuple)):
        want = [str(x) for x in spec]
        iso = {} if all(w in names for w in want) else _proposal_lookup(settings)["iso3"].to_dict()
        by_iso = {v: k for k, v in iso.items()}
        bad = [w for w in want if w not in names and w not in iso and w not in by_iso]
        if bad:
            raise ValueError(f"regime.global_set: unknown countries {bad}")
        keep = {by_iso.get(w, w) for w in want}
        out = [c for c in names if c in keep]
    elif isinstance(spec, dict) and set(spec) <= {"tiers", "exclude_tiers"} and spec:
        tier = _proposal_lookup(settings)["tier"].reindex(names)
        from .tiers import TIERS
        known = set(TIERS)
        asked = set(spec.get("tiers", [])) | set(spec.get("exclude_tiers", []))
        if asked - known:
            raise ValueError(f"regime.global_set: unknown tiers {sorted(asked - known)}")
        mask = pd.Series(True, index=names)
        if "tiers" in spec:
            mask &= tier.isin(spec["tiers"])
        if "exclude_tiers" in spec:
            mask &= ~tier.isin(spec["exclude_tiers"])       # a country with no proposal row has no tier and stays in
        out = [c for c in names if mask[c]]
    else:
        raise ValueError(f"regime.global_set must be 'all', a list of countries or {{'tiers'|'exclude_tiers': [...]}}, got {spec!r}")
    if not out:
        raise ValueError(f"regime.global_set {spec!r} selects no country of this run")
    return out


def global_share(regime: pd.Series, settings: Settings) -> float:
    """Share of the `global_set` countries that are not Calm."""
    sub = regime.loc[global_set(regime, settings)]
    return float((sub != "Calm").mean())


def global_switch(settings: Settings) -> str:
    sw = str(settings.get("regime", "global_switch", default="step")).lower()
    if sw not in GLOBAL_SWITCHES:
        raise ValueError(f"regime.global_switch must be one of {GLOBAL_SWITCHES}, got {sw!r}")
    return sw


def global_stress_weight(regime: pd.Series, settings: Settings) -> float:
    """Weight of the Stressed global state in [0, 1]. "step" (default): 1 if the share reaches
    `monte_carlo.global_stress_share`, else 0 (the cliff of GOV-018). "logistic": 1 / (1 + exp(-(share -
    threshold) / width)) with `regime.global_switch_width` (default 0.05), so 0.5 at the threshold."""
    share = global_share(regime, settings)
    thr = float(settings["monte_carlo"]["global_stress_share"])
    if global_switch(settings) == "step":
        return 1.0 if share >= thr else 0.0
    width = float(settings.get("regime", "global_switch_width", default=DEFAULT_SWITCH_WIDTH))
    if width <= 0:
        raise ValueError("regime.global_switch_width must be positive")
    return float(1.0 / (1.0 + np.exp(-(share - thr) / width)))


def global_regime(regime: pd.Series, settings: Settings) -> str:
    """The global state label: Stressed when the stress weight is at least one half (for "step" exactly the old
    `share >= global_stress_share` rule, over `regime.global_set`)."""
    return "Stressed" if global_stress_weight(regime, settings) >= 0.5 else "Calm"


def blended_factor_loadings(u: Universe, settings: Settings, regime: pd.Series, weight: float) -> pd.DataFrame:
    """Layer 5 loadings for a global stress weight: the Calm table at 0, the Stressed table at 1 (both exactly
    `layer5_copula.factor_loadings`), and the convex blend in between, which stays under the loading cap."""
    from . import layer5_copula as L5
    if weight <= 0.0:
        return L5.factor_loadings(u, settings, regime, "Calm")
    if weight >= 1.0:
        return L5.factor_loadings(u, settings, regime, "Stressed")
    calm = L5.factor_loadings(u, settings, regime, "Calm")
    st = L5.factor_loadings(u, settings, regime, "Stressed")
    return (1.0 - weight) * calm + weight * st


def blended_degrees_of_freedom(settings: Settings, weight: float, u: Universe | None = None) -> float:
    """Copula nu for a global stress weight: `layer5_copula.degrees_of_freedom` Calm at 0, Stressed at 1, linear between."""
    from . import layer5_copula as L5
    if weight <= 0.0:
        return L5.degrees_of_freedom(settings, "Calm", u)
    if weight >= 1.0:
        return L5.degrees_of_freedom(settings, "Stressed", u)
    return float((1.0 - weight) * L5.degrees_of_freedom(settings, "Calm", u) + weight * L5.degrees_of_freedom(settings, "Stressed", u))


class GaussianHMM:
    """Minimal 3-state Gaussian HMM with diagonal covariances, fitted by EM."""

    def __init__(self, n_states: int = 3, n_iter: int = 200, tol: float = 1e-6, seed: int = 7):
        self.k, self.n_iter, self.tol, self.seed = n_states, n_iter, tol, seed
        self.pi = self.A = self.mu = self.var = None
        self.loglik_ = None

    def _emission(self, X):
        n, d = X.shape
        logp = np.zeros((n, self.k))
        for j in range(self.k):
            logp[:, j] = -0.5 * np.sum(np.log(2 * np.pi * self.var[j]) + (X - self.mu[j]) ** 2 / self.var[j], axis=1)
        return logp

    def fit(self, X: np.ndarray) -> "GaussianHMM":
        X = np.asarray(X, dtype=float)
        n, d = X.shape
        # initialise with k-means on standardized data (quantile seeds along the spread series)
        sd = X.std(axis=0) + 1e-9; Z = (X - X.mean(axis=0)) / sd
        seeds = Z[np.argsort(Z[:, 0])[np.linspace(0, n - 1, self.k + 2).astype(int)[1:-1]]]
        for _ in range(25):
            lab = np.argmin(((Z[:, None, :] - seeds[None, :, :]) ** 2).sum(axis=2), axis=1)
            seeds = np.array([Z[lab == j].mean(axis=0) if np.any(lab == j) else seeds[j] for j in range(self.k)])
        self.mu = np.array([X[lab == j].mean(axis=0) if np.any(lab == j) else X.mean(axis=0) for j in range(self.k)])
        self.var = np.array([X[lab == j].var(axis=0) + 1e-6 if np.sum(lab == j) > 1 else X.var(axis=0) for j in range(self.k)])
        self.A = np.full((self.k, self.k), 0.1 / (self.k - 1)) + np.eye(self.k) * (0.9 - 0.1 / (self.k - 1))
        self.pi = np.full(self.k, 1.0 / self.k)
        prev = -np.inf
        for _ in range(self.n_iter):
            logB = self._emission(X)
            B = np.exp(logB - logB.max(axis=1, keepdims=True))
            alpha = np.zeros((n, self.k)); scale = np.zeros(n)
            alpha[0] = self.pi * B[0]; scale[0] = alpha[0].sum(); alpha[0] /= scale[0]
            for t in range(1, n):
                alpha[t] = (alpha[t - 1] @ self.A) * B[t]
                scale[t] = alpha[t].sum(); alpha[t] /= scale[t]
            beta = np.ones((n, self.k))
            for t in range(n - 2, -1, -1):
                beta[t] = (self.A @ (B[t + 1] * beta[t + 1])) / scale[t + 1]
            gamma = alpha * beta; gamma /= gamma.sum(axis=1, keepdims=True)
            xi = np.zeros((self.k, self.k))
            for t in range(n - 1):
                m = (alpha[t][:, None] * self.A) * (B[t + 1] * beta[t + 1])[None, :]
                xi += m / m.sum()
            self.pi = gamma[0]
            self.A = xi / xi.sum(axis=1, keepdims=True)
            w = gamma.sum(axis=0)
            self.mu = (gamma.T @ X) / w[:, None]
            self.var = np.array([(gamma[:, j][:, None] * (X - self.mu[j]) ** 2).sum(axis=0) / w[j] + 1e-6 for j in range(self.k)])
            ll = float(np.sum(np.log(scale)) + np.sum(logB.max(axis=1)))
            if abs(ll - prev) < self.tol:
                break
            prev = ll
        self.loglik_ = prev
        # relabel so that states are ordered by mean spread: 0 Calm, 1 Stressed, 2 Crisis
        order = np.argsort(self.mu[:, 0])
        self.mu, self.var, self.pi = self.mu[order], self.var[order], self.pi[order]
        self.A = self.A[np.ix_(order, order)]
        return self

    def decode(self, X: np.ndarray) -> np.ndarray:
        X = np.asarray(X, dtype=float)
        logB = self._emission(X)
        n = len(X)
        logA = np.log(self.A + 1e-300)
        delta = np.zeros((n, self.k)); psi = np.zeros((n, self.k), dtype=int)
        delta[0] = np.log(self.pi + 1e-300) + logB[0]
        for t in range(1, n):
            m = delta[t - 1][:, None] + logA
            psi[t] = m.argmax(axis=0)
            delta[t] = m.max(axis=0) + logB[t]
        states = np.zeros(n, dtype=int); states[-1] = delta[-1].argmax()
        for t in range(n - 2, -1, -1):
            states[t] = psi[t + 1, states[t + 1]]
        return states

    def posterior(self, X: np.ndarray) -> np.ndarray:
        """Smoothed state probabilities P(state_t | all observations), n x k, by scaled forward-backward."""
        X = np.asarray(X, dtype=float)
        n = len(X)
        logB = self._emission(X)
        B = np.exp(logB - logB.max(axis=1, keepdims=True))
        pi0 = np.maximum(self.pi, 1e-6); pi0 = pi0 / pi0.sum()   # floor: a one-hot pi from EM would zero out a sequence that starts elsewhere
        alpha = np.zeros((n, self.k)); scale = np.zeros(n)
        alpha[0] = pi0 * B[0]; scale[0] = alpha[0].sum() + 1e-300; alpha[0] /= scale[0]
        for t in range(1, n):
            alpha[t] = (alpha[t - 1] @ self.A) * B[t]
            scale[t] = alpha[t].sum() + 1e-300; alpha[t] /= scale[t]
        beta = np.ones((n, self.k))
        for t in range(n - 2, -1, -1):
            b = self.A @ (B[t + 1] * beta[t + 1])
            beta[t] = b / (b.sum() + 1e-300)              # renormalised each step: only the ratio matters for gamma
        gamma = alpha * beta
        return gamma / (gamma.sum(axis=1, keepdims=True) + 1e-300)

    def transition_matrix_12m(self, step_months: int = 1) -> np.ndarray:
        """Monthly transition matrix raised to the 12-month horizon."""
        return np.linalg.matrix_power(self.A, max(1, 12 // step_months))

    @staticmethod
    def labels(states: np.ndarray) -> list[str]:
        return [REGIMES[int(s)] for s in states]
