"""Layer 5: dependence dynamics, Student-t copula and liquidity-adjusted VaR (paper 3.5).

Correlation is a one-factor-per-block structure: a global factor whose loading rises with the
country's regime (and again when the global regime is stressed), a regional factor (Asia / LatAm /
Africa) and an idiosyncratic residual. The copula is Student-t with nu = 5 in a calm global regime
and nu = 4 when stressed, so joint extremes cluster (Theorem 6.1: lower tail dependence > 0).

`copula.source` (EQ-B-0036, GOV-021): "judgement" (default) uses the loadings and nu above. "estimated" fits the
same structure (one global loading per country, one regional loading per region, nu) by maximum likelihood of a
Student-t copula on weekly market returns from data/market_history (`fit_t_copula`). The estimate replaces the
Calm-level global loading of each country with market data, the regional loading of every region with at least
two such countries, and, only with `copula.nu_source` "estimated" (default "judgement"), nu in a calm global
regime; the regime step-ups (Stressed +0.10, Crisis +0.20 on the
global loading), the 1.5x global-stress multiplier and the nu step to the stressed regime stay judgement.
Countries whose only series is an administered or pegged quote (GOV-034), or with no series, keep the judgement
loadings.

FX-only prices.csv (EQ-B-0077, HO-20261024-A-B-004; Sam 2026-10-24 12:31Z: official BIS/ECB FX, ETF columns dropped).
Decision: the estimated copula keeps fitting, on the FX component only. The country shock already averages the
components that exist, so with no ETF column it is the standardised FX move. A country whose only usable series was
its ETF (Argentina: USDARS is administered) has no shock, is listed in `left_out` and keeps the judgement loadings,
which is the judgement fallback for equity-only loadings. Why not the whole judgement copula: the latent is one
country stress factor per country (it drives FX, bonds and equity alike), not an equity factor, and the FX history
still identifies it for the floating and managed currencies; switching every country to judgement would be a separate
change of `copula.source` (Tier 1, Sam), and remains available as that switch. `CopulaFit.components` says which
series built each country's shock, `etf_missing` lists countries whose ETF is not in the prices, a RuntimeWarning
names them, and `copula_diagnostics` returns all of it for the run diagnostics. With the ETF columns present nothing
changes.
"""
from __future__ import annotations
import warnings
from dataclasses import dataclass, field
import numpy as np
import pandas as pd
from scipy import optimize, special, stats
from ..config import Settings
from ..ingestion import Universe

COPULA_SOURCES = ("judgement", "estimated")
ADMINISTERED = ("USDVES", "USDNGN", "USDARS", "USDPKR", "USDBZD")   # same list as garch.ADMINISTERED (GOV-034)
PEG_REGIMES = ("Peg", "Dollarized")
MIN_WEEKS = 104
NU_BOUNDS = (2.5, 60.0)
_FIT_CACHE: dict = {}


def copula_source(settings: Settings) -> str:
    src = str(settings.get("copula", "source", default="judgement") if isinstance(settings.get("copula"), dict) else "judgement").lower()
    if src not in COPULA_SOURCES:
        raise ValueError(f"copula.source must be one of {COPULA_SOURCES}, got {src!r}")
    return src


def nu_source(settings: Settings) -> str:
    cop = settings.get("copula") if isinstance(settings.get("copula"), dict) else {}
    src = str(cop.get("nu_source", "judgement")).lower()
    if src not in COPULA_SOURCES:
        raise ValueError(f"copula.nu_source must be one of {COPULA_SOURCES}, got {src!r}")
    return src


def country_shocks(prices: pd.DataFrame, countries: pd.DataFrame, names: list[str]) -> tuple[pd.DataFrame, dict]:
    """Weekly (Friday close) country shock per country, sign so that low = bad for the country: the mean of the
    standardised local-currency return (minus the USD<ccy> log change) and the standardised ETF log return, using
    the components that exist. FX is left out for administered quotes and pegged / dollarised regimes. Returns the
    shock frame (complete weeks only) and {country: reason} for countries left out. The frame's attrs carry
    "components" ({country: "FX" | "ETF" | "FX+ETF"}) and "etf_missing" (countries with an ETF in countries.csv and no
    column in prices; EQ-B-0077)."""
    px = prices.copy()
    if "date" in px.columns:
        px = px.set_index("date")
    px.index = pd.to_datetime(px.index)
    px = px.sort_index().apply(pd.to_numeric, errors="coerce")
    px = px[~px.index.duplicated(keep="last")]
    px = px[px.index.dayofweek < 5].ffill(limit=5)
    wk = px.resample("W-FRI").last()
    lr = np.log(wk.where(wk > 0)).diff().iloc[1:]
    prof = countries.set_index("country")
    cols, left_out, comps, etf_missing = {}, {}, {}, []
    for c in names:
        fx = "USD" + str(prof.at[c, "currency"]) if "currency" in prof.columns and pd.notna(prof.at[c, "currency"]) else ""
        etf = prof.at[c, "etf"] if "etf" in prof.columns else None
        etf = str(etf) if isinstance(etf, str) and etf.strip() else ""
        parts, used = [], []
        if fx and fx in lr.columns and fx not in ADMINISTERED and str(prof.at[c, "fxregime"]) not in PEG_REGIMES \
                and lr[fx].notna().mean() >= 0.8 and lr[fx].std() > 0:
            parts.append(-lr[fx] / lr[fx].std()); used.append("FX")
        if etf and etf not in lr.columns:
            etf_missing.append(c)
        if etf and etf in lr.columns and lr[etf].notna().mean() >= 0.8 and lr[etf].std() > 0:
            parts.append(lr[etf] / lr[etf].std()); used.append("ETF")
        if parts:
            cols[c] = sum(parts) / len(parts); comps[c] = "+".join(used)
        else:
            left_out[c] = "no ETF and FX quote administered or pegged (GOV-034)" if fx in lr.columns or (fx and fx in ADMINISTERED) else "no market series"
            if etf and etf not in lr.columns:
                left_out[c] += f"; {etf} not in prices.csv (FX-only price history, EQ-B-0077)"
    X = pd.DataFrame(cols).dropna()
    X.attrs["components"] = {c: comps[c] for c in X.columns}
    X.attrs["etf_missing"] = etf_missing
    return X, left_out


def pseudo_obs(X: np.ndarray) -> np.ndarray:
    X = np.asarray(X, dtype=float)
    return stats.rankdata(X, axis=0) / (X.shape[0] + 1)


def _structured_R(g: np.ndarray, r_by_country: np.ndarray, same: np.ndarray) -> np.ndarray:
    sg, sr = np.sqrt(g), np.sqrt(r_by_country)
    R = np.outer(sg, sg) + same * np.outer(sr, sr)
    np.fill_diagonal(R, 1.0)
    return R


def t_copula_loglik(U: np.ndarray, R: np.ndarray, nu: float) -> float:
    """Log-likelihood of a Student-t copula with correlation R and nu degrees of freedom at pseudo-observations U."""
    T, N = U.shape
    x = stats.t.ppf(U, nu)
    try:
        L = np.linalg.cholesky(R)
    except np.linalg.LinAlgError:
        return -1e12
    z = np.linalg.solve(L, x.T)
    q = np.sum(z * z, axis=0)
    logdet = 2 * np.sum(np.log(np.diag(L)))
    c = special.gammaln((nu + N) / 2) + (N - 1) * special.gammaln(nu / 2) - N * special.gammaln((nu + 1) / 2)
    ll = T * c - 0.5 * T * logdet - (nu + N) / 2 * np.sum(np.log1p(q / nu)) + (nu + 1) / 2 * np.sum(np.log1p(x * x / nu))
    return float(ll)


@dataclass
class CopulaFit:
    nu: float
    global_loading: pd.Series            # Calm-level squared global loading per estimated country
    regional_loading: dict               # region -> squared regional loading (regions with >= 2 estimated countries)
    countries: list
    regions: dict
    n_weeks: int
    loglik: float
    converged: bool
    mean_corr: float                     # mean off-diagonal of the fitted structured correlation
    mean_corr_kendall: float             # mean off-diagonal of sin(pi tau / 2)
    nu_profile: dict = field(default_factory=dict)
    left_out: dict = field(default_factory=dict)
    start: str = ""
    end: str = ""
    components: dict = field(default_factory=dict)   # country -> "FX" | "ETF" | "FX+ETF" (EQ-B-0077)
    etf_missing: list = field(default_factory=list)  # countries with an ETF in countries.csv and none in prices.csv


def fit_t_copula(X: pd.DataFrame, regions: dict, min_region: int = 2) -> CopulaFit:
    """`_fit_t_copula` through the disk fit cache (HO-20261024-C-B-005). The key covers X (values, weeks, columns), the
    region of each column, min_region and this module's source (pseudo_obs, t_copula_loglik, _structured_R, NU_BOUNDS,
    CopulaFit; the fit runs no other econquest code, SEC-C-014 R38)."""
    from ..ops import fitcache
    params = {"regions": {c: regions[c] for c in X.columns}, "min_region": min_region}
    return fitcache.memo("t_copula", {"X": X}, params, lambda: _fit_t_copula(X, regions, min_region), code=(__name__,))


def _fit_t_copula(X: pd.DataFrame, regions: dict, min_region: int = 2) -> CopulaFit:
    """Joint maximum likelihood of (global loading per country, regional loading per region, nu) of the layer-5
    structure R_ij = sqrt(g_i g_j) + 1[same region] sqrt(r_i r_j) on pseudo-observations of X (weeks x countries).
    Start values: least squares of the structure on the Kendall-tau correlation sin(pi tau / 2), nu by profile."""
    names = list(X.columns); N = len(names)
    U = pseudo_obs(X.to_numpy())
    reg = [regions[c] for c in names]
    est_regions = sorted({r for r in reg if reg.count(r) >= min_region})
    ridx = np.array([est_regions.index(r) if r in est_regions else -1 for r in reg])
    same = (np.array(reg)[:, None] == np.array(reg)[None, :]).astype(float) * (ridx[:, None] >= 0)
    off = np.triu_indices(N, 1)
    tau = X.corr(method="kendall").to_numpy()
    Rk = np.sin(np.pi / 2 * tau)

    def unpack(th):
        g = th[:N]; rr = th[N:N + len(est_regions)]
        rc = np.where(ridx >= 0, rr[np.maximum(ridx, 0)], 0.0)
        return g, rc

    def ls(th):
        g, rc = unpack(th)
        return float(np.sum((_structured_R(g, rc, same)[off] - Rk[off]) ** 2))

    bounds = [(0.0, 0.9)] * N + [(0.0, 0.6)] * len(est_regions)
    th0 = np.r_[np.full(N, 0.15), np.full(len(est_regions), 0.1)]
    th_ls = optimize.minimize(ls, th0, method="L-BFGS-B", bounds=bounds).x
    g0, rc0 = unpack(th_ls)
    R0 = _structured_R(g0, rc0, same)
    grid = np.array([3, 4, 5, 6, 8, 10, 15, 20, 30, 45, 60], dtype=float)
    prof = {float(v): t_copula_loglik(U, R0, v) for v in grid}
    nu0 = max(prof, key=prof.get)

    def nll(th):
        g, rc = unpack(th[:-1])
        if np.any(g + rc > 0.95):
            return 1e12
        return -t_copula_loglik(U, _structured_R(g, rc, same), float(th[-1]))

    th0 = np.r_[np.minimum(th_ls, 0.9), nu0]
    th0[:N] = np.minimum(th0[:N], 0.95 - rc0 - 1e-6)
    res = optimize.minimize(nll, th0, method="L-BFGS-B", bounds=bounds + [NU_BOUNDS])
    g, rc = unpack(res.x[:-1]); nu = float(res.x[-1])
    R = _structured_R(g, rc, same)
    return CopulaFit(nu=nu, global_loading=pd.Series(g, index=names), regional_loading={r: float(res.x[N + i]) for i, r in enumerate(est_regions)},
                     countries=names, regions={c: regions[c] for c in names}, n_weeks=int(len(X)), loglik=float(-res.fun),
                     converged=bool(res.success), mean_corr=float(R[off].mean()), mean_corr_kendall=float(Rk[off].mean()), nu_profile=prof,
                     start=str(X.index.min().date()), end=str(X.index.max().date()))


def bootstrap_copula(X: pd.DataFrame, regions: dict, reps: int = 200, block: int = 8, seed: int = 7) -> pd.DataFrame:
    """Moving-block bootstrap (blocks of `block` weeks) of `fit_t_copula`: one row per replicate with nu, the mean
    fitted correlation and every loading, for percentile confidence intervals."""
    rng = np.random.default_rng(seed)
    T = len(X); nb = int(np.ceil(T / block)); rows = []
    for _ in range(reps):
        starts = rng.integers(0, T - block + 1, nb)
        idx = np.concatenate([np.arange(s0, s0 + block) for s0 in starts])[:T]
        Xb = X.iloc[idx].reset_index(drop=True)
        Xb.index = X.index[:T]
        f = fit_t_copula(Xb, regions)
        rows.append({"nu": f.nu, "mean_corr": f.mean_corr, **{f"g:{c}": v for c, v in f.global_loading.items()},
                     **{f"r:{k}": v for k, v in f.regional_loading.items()}})
    return pd.DataFrame(rows)


def estimated_copula(u: Universe, as_of=None) -> CopulaFit:
    """Fit on u.prices up to `as_of`, cached on the price data (stress runs share it)."""
    import hashlib
    from .garch import prices_as_of
    prices = prices_as_of(getattr(u, "prices", None), as_of)
    if prices is None or len(prices) == 0:
        raise ValueError("copula.source 'estimated' needs data/market_history/prices.csv (u.prices is empty)")
    X, left_out = country_shocks(prices, u.countries, list(u.names))
    regions = u.countries.set_index("country")["region"].to_dict()
    # HO-20261024-C-B-005: the regions of the fitted columns are part of the key, so a region change in-process refits
    key = (hashlib.sha1(np.ascontiguousarray(X.to_numpy(dtype=float)).tobytes(), usedforsecurity=False).hexdigest(), tuple(X.columns),
           tuple(str(regions.get(c)) for c in X.columns))
    if key not in _FIT_CACHE:
        if len(X) < MIN_WEEKS or X.shape[1] < 3:
            raise ValueError(f"copula.source 'estimated' needs {MIN_WEEKS} complete weeks for >= 3 countries, got {len(X)} x {X.shape[1]}")
        _FIT_CACHE[key] = fit_t_copula(X, regions)
    fit = _FIT_CACHE[key]
    fit.left_out = left_out
    fit.components = dict(X.attrs.get("components", {}))
    fit.etf_missing = list(X.attrs.get("etf_missing", []))
    if fit.etf_missing:
        warnings.warn(f"copula.source 'estimated': no ETF series for {fit.etf_missing}; the fit uses their FX moves only "
                      f"and keeps the judgement loadings for {sorted(left_out)} (EQ-B-0077)", RuntimeWarning, stacklevel=2)
    return fit


def estimated_copula_or_none(u: Universe, as_of=None) -> CopulaFit | None:
    """`estimated_copula`, or None with a warning when the price history is missing or too short (a fresh install,
    a test fixture, a new country set): the run then uses the judgement loadings and nu for every country."""
    try:
        return estimated_copula(u, as_of)
    except ValueError as e:
        warnings.warn(f"{e}; using the judgement copula", RuntimeWarning, stacklevel=2)
        return None


def copula_diagnostics(u: Universe, settings: Settings) -> dict:
    """What the layer-5 loadings rest on, for the run diagnostics (EQ-B-0077): the source, whether the estimated fit
    ran, the series behind each country's shock, the countries on judgement loadings and why, and the countries whose
    ETF is missing from prices.csv. Reads the cached fit; changes no number."""
    src = copula_source(settings)
    out = {"source": src, "fitted": False, "nu_source": nu_source(settings)}
    if src != "estimated":
        return out
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)       # the run itself already warned
        fit = estimated_copula_or_none(u, settings.get("as_of"))
    if fit is None:
        out["reason"] = "price history missing or too short: judgement copula for every country"
        return out
    out.update({"fitted": True, "n_weeks": fit.n_weeks, "start": fit.start, "end": fit.end, "nu": fit.nu,
                "components": dict(fit.components), "judgement_loadings": dict(fit.left_out),
                "etf_missing": list(fit.etf_missing),
                "fx_only": bool(fit.components) and all(v == "FX" for v in fit.components.values())})
    return out


# The judgement Calm global loading that the estimated loadings replace (shipped `regime.Calm.global_loading` on
# 2026-10-23); `copula.calm_anchor` overrides.
CALM_LOADING_ANCHOR = 0.15


def factor_loadings(u: Universe, settings: Settings, regime: pd.Series, global_state: str) -> pd.DataFrame:
    reg = settings["regime"]
    mult = settings["monte_carlo"]["global_loading_mult"] if global_state == "Stressed" else 1.0
    fit = estimated_copula_or_none(u, settings.get("as_of")) if copula_source(settings) == "estimated" else None
    calm_anchor = float(settings.get("copula", "calm_anchor", default=CALM_LOADING_ANCHOR))
    rows = {}
    for c in u.names:
        if fit is not None and c in fit.global_loading.index:
            # estimated Calm level plus the regime's step over the judgement Calm anchor, then the global-stress
            # multiplier. The anchor is fixed, not reg["Calm"] in hand, so a scenario that raises the Calm loading
            # keeps its shock on top of the fit instead of cancelling it (or turning the loading negative)
            g = max(0.0, (float(fit.global_loading[c]) + reg[regime[c]]["global_loading"] - calm_anchor) * mult)
            r = fit.regional_loading.get(fit.regions[c], reg["regional_loading"])
        else:
            g = reg[regime[c]]["global_loading"] * mult
            r = reg["regional_loading"]
        g = min(g, 1 - r - 0.05)
        rows[c] = {"global": g, "regional": r, "idio": 1 - g - r}
    return pd.DataFrame(rows).T


def correlation_matrix(u: Universe, loadings: pd.DataFrame) -> pd.DataFrame:
    """Implied latent correlation R_ij = sqrt(g_i g_j) + 1{same region} sqrt(r_i r_j)."""
    prof = u.countries.set_index("country").loc[u.names]
    g = np.sqrt(loadings["global"].to_numpy()); r = np.sqrt(loadings["regional"].to_numpy())
    same = (prof["region"].to_numpy()[:, None] == prof["region"].to_numpy()[None, :]).astype(float)
    R = np.outer(g, g) + same * np.outer(r, r)
    np.fill_diagonal(R, 1.0)
    return pd.DataFrame(R, index=u.names, columns=u.names)


def tail_dependence(rho: float, nu: float) -> float:
    """Lower tail dependence of a bivariate t copula: 2 t_{nu+1}(-sqrt((nu+1)(1-rho)/(1+rho)))."""
    return float(2 * stats.t.cdf(-np.sqrt((nu + 1) * (1 - rho) / (1 + rho)), nu + 1))


def degrees_of_freedom(settings: Settings, global_state: str, u: Universe | None = None) -> float:
    """Judgement: df_calm / df_stressed. With `copula.source` "estimated" and `copula.nu_source` "estimated": the
    fitted nu when calm, and nu minus the judgement step (df_calm - df_stressed), floored at 3, when the global
    regime is Stressed; needs `u`. `copula.nu_source` defaults to "judgement" (estimated loadings, judgement nu)."""
    mc = settings["monte_carlo"]
    if copula_source(settings) == "estimated" and nu_source(settings) == "estimated":
        if u is None:
            raise ValueError("copula.source 'estimated' needs the universe: call degrees_of_freedom(settings, gstate, u)")
        fit = estimated_copula_or_none(u, settings.get("as_of"))
        if fit is None:
            return float(mc["df_stressed"] if global_state == "Stressed" else mc["df_calm"])
        nu = fit.nu
        return float(max(3.0, nu - (float(mc["df_calm"]) - float(mc["df_stressed"]))) if global_state == "Stressed" else nu)
    return float(mc["df_stressed"] if global_state == "Stressed" else mc["df_calm"])


def liquidity_cost(positions: pd.DataFrame, regime: pd.Series, settings: Settings, alpha: float = 0.99) -> pd.Series:
    """Per-position liquidation cost at confidence alpha ($mm):
    1/2 * notional * regime multiplier * (mu_spread + z_alpha sigma_spread) * sqrt(T_i / T0) / 100."""
    liq = settings["liquidity"]
    z = stats.norm.ppf(alpha)
    out = {}
    for _, p in positions.iterrows():
        a = liq["by_asset"][p["asset_class"]]
        m = liq["regime_mult"][regime[p["country"]]]
        out[p["id"]] = 0.5 * float(p["notional_mm"]) * m * (a["spread_mean"] + z * a["spread_sd"]) * np.sqrt(a["horizon_days"] / liq["T0_days"]) / 100
    return pd.Series(out, name="liquidity_cost")
