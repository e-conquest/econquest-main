"""Global macro scenario engine (EQ-B-0082): six global drivers -> country shocks -> an ordinary stress.py shock list.

There is no new engine path. A driver scenario is compiled against the universe's countries and indicators
tables into the shock grammar of `engine/stress.py` (countries / indicators / trigger / portfolio / settings /
rates / contagion targets, ops add / mul / notch / set, `where` on `iso_in`), and `stress.apply_shocks` and
`run_pipeline` run it exactly as they run a hand-built scenario from data/scenarios.json. Because the shocks
are computed per country from exposures, the same driver vector covers whatever universe is loaded: the 18
desk names today, the 88-country proposal (data/panel/universe_proposal.csv) once it is promoted.

Drivers (deviations from the base; all zero = no shock):

    us_rate_bp     US policy rate, bp                         usd_pct        USD broad index, % (+ = stronger USD)
    china_gdp_pp   China real GDP growth, pp (- = slowdown)   oil_pct        oil price, %
    conflict       regional conflict intensity, 0 to 1        vix_pts        global risk appetite, VIX points (+ = risk-off)
    conflict_region / conflict_epicentre (ISO3) say where the conflict is.

Channels (per country i, all linear in the drivers, so severity scales cleanly):
  trade      exports to the US / China / EU as % of GDP x partner import elasticity x partner growth change
  financial  spread level beta (spread / 300 bp, clipped), FX share of government debt (indicator 1.5),
             rating risk multiplier, exchange-regime pass-through; BIS common-creditor contagion through the
             existing `contagion` shock target when data/live/raw_bis_cbs.csv exists
  commodity  net oil exports % of GDP and non-oil commodity exports % of GDP (terms of trade), main commodity
             class (oil / metals / ags / gold) for the commodity gap
  conflict   proximity by region (epicentre 1, same region, other regions)
Outputs per country: spread change (bp), FX change (3-month depreciation, %), growth change (pp), commodity gap,
reserves, current account, inflation, FX-debt revaluation of debt/GDP, text stress, trigger add-ons, optional
rating notches. Every coefficient is in COEF (value, unit, source); the exposure table is EXPOSURE_CSV. Nearly all
are "judgement": analyst values anchored to the hand-built scenarios and stylised facts, not estimated. No
bilateral trade, BIS banking or commodity-export data exists in the repo (checked 2026-10-24), so the exposure
table is a labelled judgement table (approximate IMF DOTS / UN Comtrade magnitudes from memory, verify).

Use:
    shocks = compile_shocks(PRESETS["FED_SHOCK"].drivers, u.countries, u.indicators)
    u2, s2 = stress.apply_shocks(u, s, shocks)          # or macro_scenario("FED_SHOCK", u).apply(u, s, scale)
    print(brief_table(PRESETS["FED_SHOCK"].drivers, u.countries, u.indicators))
OFF by default: nothing in the pipeline calls this module; `expand_macro_shocks` is the proposed stress.py hook.
"""
from __future__ import annotations

import dataclasses
import io
import math
import numbers
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

from .stress import RATING_LADDER, Scenario, country_tiers

# ---------------------------------------------------------------- drivers and presets

DRIVERS = {
    "us_rate_bp": "US policy rate change, bp",
    "usd_pct": "USD broad index change, % (+ = stronger dollar)",
    "china_gdp_pp": "China real GDP growth change, pp (- = slowdown)",
    "oil_pct": "oil price change, %",
    "conflict": "regional conflict intensity, 0 (none) to 1 (open war / blockade)",
    "vix_pts": "global risk appetite, change in VIX points (+ = risk-off)",
}

# Plausible input range per driver (inclusive). Generous: several times the largest historical move, so they only
# stop typos and absurd values, never a severe but conceivable scenario. Largest moves (approximate, from memory):
# US policy rate +1,000 bp in a year (1979-81); broad USD about +/-20% a year (1985, 2014-15); China growth about
# -27 pp (1961) and a 2020 quarter of -6.8% y/y; oil +300% (1973-74) and -75% (2008); VIX from about 12 to 82.7 (2020).
DRIVER_BOUNDS = {
    "us_rate_bp": (-2000.0, 2000.0),
    "usd_pct": (-60.0, 60.0),
    "china_gdp_pp": (-40.0, 40.0),
    "oil_pct": (-100.0, 1000.0),     # a price cannot fall more than 100%
    "conflict": (0.0, 1.0),          # an intensity
    "vix_pts": (-100.0, 250.0),
}
SCALED_DRIVER_LIMIT = 10.0           # scaled drivers (drivers x severity scale): |value| <= 10 x the largest bound magnitude


@dataclass(frozen=True)
class Drivers:
    us_rate_bp: float = 0.0
    usd_pct: float = 0.0
    china_gdp_pp: float = 0.0
    oil_pct: float = 0.0
    conflict: float = 0.0
    vix_pts: float = 0.0
    conflict_region: str | None = None          # countries.csv region of the conflict (e.g. "Asia")
    conflict_epicentre: str | None = None       # ISO3 of the country at the centre (e.g. "CHN")

    def scaled(self, k: float) -> "Drivers":
        return dataclasses.replace(self, **{n: getattr(self, n) * float(k) for n in DRIVERS})

    def is_zero(self) -> bool:
        return all(float(getattr(self, n)) == 0.0 for n in DRIVERS)

    def check(self, input_range: bool = True) -> "Drivers":
        """Raise ValueError unless every driver is a finite real number (not a bool or string), the conflict region and
        epicentre are strings or None and, for user input (`input_range`), every driver is inside DRIVER_BOUNDS
        (conflict intensity in [0, 1]). Scaled drivers (severity scale > 1) may go past those bounds, so on them only
        the wider SCALED_DRIVER_LIMIT x the largest bound magnitude is checked (it stops absurd values such as
        oil_pct 1e308, which would give infinite spreads)."""
        for n in DRIVERS:
            v = getattr(self, n)
            if isinstance(v, bool) or not isinstance(v, numbers.Real) or not math.isfinite(float(v)):
                raise ValueError(f"macro driver {n} must be a finite number, got {v!r}")
            lo, hi = DRIVER_BOUNDS[n]
            if input_range and not lo <= float(v) <= hi:
                raise ValueError(f"macro driver {n} must be in [{lo:g}, {hi:g}] (plausible range), got {v!r}")
            lim = SCALED_DRIVER_LIMIT * max(abs(lo), abs(hi))
            if not input_range and abs(float(v)) > lim:
                raise ValueError(f"scaled macro driver {n} must be within +/-{lim:g}, got {v!r}")
        for n in ("conflict_region", "conflict_epicentre"):
            v = getattr(self, n)
            if v is not None and not isinstance(v, str):
                raise ValueError(f"macro driver {n} must be a string or null, got {v!r}")
        return self

    def as_dict(self) -> dict:
        return dataclasses.asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> "Drivers":
        bad = sorted(set(d) - {f.name for f in dataclasses.fields(cls)})
        if bad:
            raise ValueError(f"unknown macro driver(s) {bad}; drivers are {list(DRIVERS)} plus conflict_region, conflict_epicentre")
        return cls(**d).check()


@dataclass(frozen=True)
class Preset:
    key: str
    name: str
    drivers: Drivers
    compare_to: str             # closest hand-built scenario in data/scenarios.json
    source: str


PRESETS = {
    "FED_SHOCK": Preset("FED_SHOCK", "Fed +200 bp with dollar and risk-off",
                        Drivers(us_rate_bp=200, usd_pct=8, vix_pts=12), "A",
                        "Fed +200 bp from paper section 9.1 (scenario A); USD +8% and VIX +12 judgement from 2013 and 2022 "
                        "(DXY about +15% and VIX about +18 at the 2022 peak, for a 425 bp cycle)."),
    "CHINA_SLOWDOWN": Preset("CHINA_SLOWDOWN", "China growth 5% -> 2%",
                             Drivers(china_gdp_pp=-3, usd_pct=3, oil_pct=-20, vix_pts=10), "CHINA_HL",
                             "China -3 pp as in CHINA_HL (growth to 2%); oil -20%, USD +3%, VIX +10 judgement from the "
                             "2015-16 China scare scaled up."),
    "OIL_SPIKE": Preset("OIL_SPIKE", "Oil +60% supply shock",
                        Drivers(oil_pct=60, vix_pts=8, usd_pct=2, us_rate_bp=25, china_gdp_pp=-0.5), "HORMUZ",
                        "Oil +60% as in HORMUZ (IEA/IMF range for a multi-week closure); VIX +8, USD +2%, Fed +25 bp "
                        "and China -0.5 pp judgement."),
    "REGIONAL_WAR": Preset("REGIONAL_WAR", "Regional war in Asia (Taiwan Strait)",
                           Drivers(conflict=1.0, conflict_region="Asia", conflict_epicentre="CHN", vix_pts=15, oil_pct=15,
                                   usd_pct=4, china_gdp_pp=-2), "TAIWAN",
                           "Conflict intensity 1 in Asia with China at the centre, as in TAIWAN; VIX +15, oil +15%, "
                           "USD +4%, China -2 pp judgement."),
}

# ---------------------------------------------------------------- coefficient table

J = "judgement"
COEF: dict[str, tuple[float, str, str]] = {
    # partner growth (pp) per unit of driver
    "g_us_per_100bp": (-0.4, "pp US growth per +100 bp", "judgement; FRB/US-style policy multiplier, 1-2 year horizon"),
    "g_us_per_vix": (-0.03, "pp per VIX point", J),
    "g_us_per_10pct_oil": (-0.1, "pp per +10% oil", "judgement; IMF WEO rule of thumb for an oil-importing large economy"),
    "g_eu_per_100bp": (-0.2, "pp EU growth per +100 bp Fed", J),
    "g_eu_per_vix": (-0.03, "pp per VIX point", J),
    "g_eu_per_10pct_oil": (-0.15, "pp per +10% oil", "judgement; EU is a larger net importer than the US"),
    "g_eu_per_china_pp": (0.15, "pp EU growth per pp China growth", J),
    "g_cn_per_10pct_oil": (-0.05, "pp per +10% oil", J),
    "partner_import_elasticity": (2.0, "% partner imports per 1% partner GDP", "judgement; trade income elasticities 1.5-2.5 in the literature"),
    # commodity prices (%)
    "metals_per_china_pp": (10.0, "% metals price per pp China growth", "judgement; CHINA_HL: China -3 pp ~ commodities -30%"),
    "ags_per_china_pp": (4.0, "% agricultural price per pp China growth", J),
    "commod_per_usd": (-0.5, "% non-oil commodity price per +1% USD", "judgement; dollar-commodity elasticity"),
    "gold_per_vix": (0.6, "% gold price per VIX point", "judgement; safe-haven bid"),
    "commgap_pass": (0.67, "commodity gap points per 1% main-commodity price", "judgement; HORMUZ: oil +60% -> commgap +40"),
    # growth (pp) at home
    "growth_per_tot": (0.25, "pp growth per 1% of GDP terms-of-trade gain", J),
    "home_china": (1.0, "pp China growth per pp driver", "definition"),
    # spreads (bp)
    "level_ref_bp": (300.0, "bp spread at which the level beta is 1", "judgement; spread changes scale with the level"),
    "level_beta_min": (0.25, "floor on the level beta", J),
    "level_beta_max": (2.0, "cap on the level beta", "judgement; keeps defaulted names (VEN 6000 bp) from tripling every shock"),
    "s_per_100bp": (50.0, "bp per +100 bp Fed at beta 1", "judgement; scenario A gives +280 bp to HY at +200 bp with risk-off"),
    "s_per_vix": (6.0, "bp per VIX point at beta 1", "judgement; TAPER13 / FED22 EMBI moves vs VIX"),
    "s_per_usd_at_fxd50": (8.0, "bp per +1% USD at 50% FX debt, beta 1", J),
    "s_per_growth_pp": (40.0, "bp per pp external growth loss at beta 1", J),
    "s_per_tot_pct": (15.0, "bp per 1% of GDP terms-of-trade loss at beta 1", "judgement; HORMUZ importers +150 bp"),
    "s_per_tot_gain": (5.0, "bp tightening per 1% of GDP terms-of-trade gain at beta 1", "judgement; windfalls tighten less than losses widen (HORMUZ exporters still +50 bp)"),
    "s_conflict": (300.0, "bp at conflict 1 and proximity 1", "judgement; TAIWAN: Asia +250 bp"),
    "s_home_china_per_pp": (50.0, "bp China spread per pp slowdown", "judgement; CHINA_HL: China +150 bp for -3 pp"),
    # FX (3-month depreciation, %)
    "fx_per_usd": (1.0, "% per +1% USD", "definition (bilateral vs USD) before regime pass-through"),
    "fx_per_100bp": (1.0, "% per +100 bp Fed at risk multiplier 1", J),
    "fx_per_vix": (0.15, "% per VIX point", J),
    "fx_per_tot_pct": (0.5, "% per 1% of GDP terms-of-trade loss", J),
    "fx_conflict": (10.0, "% at conflict 1, proximity 1", "judgement; TAIWAN: Asian floats -12%"),
    "fx_home_china_per_pp": (5.0, "% CNY per pp slowdown", "judgement; CHINA_HL: CNY -15% for -3 pp"),
    "fx_asia_cny_beta": (0.3, "Asian FX move per 1% CNY move", "judgement; regional CNY beta 0.3-0.5"),
    "res_absorb": (0.5, "res3m % loss per % of unpassed FX pressure", "judgement; pegs and managed floats spend reserves"),
    # indicators
    "ca_conflict": (-4.0, "pp of GDP current account at conflict 1, proximity 1", "judgement; TAIWAN -5, HORMUZ -4"),
    "infl_per_oil_importer": (0.03, "pp inflation per 1% oil, net importers", "judgement; EM headline pass-through 0.02-0.05"),
    "infl_per_oil_exporter": (0.01, "pp inflation per 1% oil, net exporters", J),
    "infl_per_fx": (0.2, "pp inflation per 1% depreciation", "judgement; EM FX pass-through ~0.2"),
    # text stress (z) and triggers (points)
    "t_per_vix": (0.05, "z per VIX point", "judgement; scenario A +1.0"),
    "t_per_100bp": (0.125, "z per +100 bp Fed", "judgement; scenario A +1.0"),
    "t_conflict": (4.0, "z at conflict 1, proximity 1", "judgement; TAIWAN Asia +4"),
    "trig5_conflict": (15.0, "pillar 5 points at conflict 1, proximity 1 (proximity >= 0.5)", "judgement; TAIWAN"),
    "trig6_conflict": (20.0, "pillar 6 points at conflict 1, proximity 1 (proximity >= 0.5)", "judgement; TAIWAN"),
    # settings
    "gl_per_vix": (0.01, "global copula loading per VIX point", "judgement; A +0.25, TAIWAN +0.15"),
    "gl_per_100bp": (0.05, "global loading per +100 bp Fed", J),
    "gl_per_china_pp": (0.03, "global loading per pp China slowdown", "judgement; CHINA_HL +0.2"),
    "gl_per_10pct_oil": (0.01, "global loading per +10% oil (rises only)", "judgement; HORMUZ +0.15"),
    "gl_max": (0.9, "cap on global loading", "as in scenarios.json"),
    "rl_conflict": (0.25, "regional loading at conflict 1", "judgement; TAIWAN +0.25"),
    "rl_max": (0.6, "cap on regional loading", "as in scenarios.json"),
    "liq_per_vix": (0.04, "x liquidity spread_mean per VIX point", "judgement; GFC08 x3 at VIX about +50"),
    "liq_conflict": (0.25, "x liquidity spread_mean at conflict 1", J),
    "eqvol_per_vix": (1.0, "equity vol points per VIX point", J),
    "lrvol_per_100bp": (0.25, "x local rate vol per +100 bp Fed", J),
    "lrvol_per_10pct_oil": (0.1, "x local rate vol per +10% oil (rises only)", "judgement; HORMUZ x2"),
    "hard_rate_per_bp": (0.5, "bp UST level per bp Fed", "judgement; 10y moves about half the policy rate"),
    "local_rate_per_bp": (0.5, "bp EM local yields per bp Fed", "judgement; TAPER13 / FED22"),
    "local_rate_per_10pct_oil": (5.0, "bp local yields per +10% oil (rises only)", J),
    # optional notch rule (off unless notch_rule=True)
    "notch_bp": (200.0, "bp of spread change per notch down", "judgement; DOWNGRADE gives -2 sub-IG in a broad cycle"),
    "notch_max": (3.0, "max notches", J),
    # BIS contagion (only when data/live/raw_bis_cbs.csv exists)
    "bis_china_per_pp": (30.0, "bp to the most exposed common-creditor peer per pp China slowdown", J),
    "bis_conflict": (150.0, "bp to the most exposed peer of the epicentre at conflict 1", J),
}


def c(name: str) -> float:
    return COEF[name][0]


REGIME_FX_BETA = {"Float": 1.0, "Managed": 0.6, "Peg": 0.15, "Dollarized": 0.0}     # judgement: share of FX pressure that shows in the rate
REGIME_FX_BETA_UNKNOWN = 0.6
RATING_RISK = {"IG": 0.8, "BB": 1.0, "B": 1.3, "CCC": 1.5}                        # judgement: FX risk multiplier by rating bucket
TIER_DEFAULTS = {   # judgement: used when a country has no spread / rating / FX-debt share yet (the 70 staged names)
    "DM_anchor": {"spread": 30.0, "risk": 0.0, "fx_debt": 0.0, "em": 0.0},
    "EM": {"spread": 200.0, "risk": 1.0, "fx_debt": 25.0, "em": 1.0},
    "frontier": {"spread": 500.0, "risk": 1.3, "fx_debt": 55.0, "em": 1.0},
    "desk_current": {"spread": 200.0, "risk": 1.0, "fx_debt": 30.0, "em": 1.0},
    "unknown": {"spread": 200.0, "risk": 1.0, "fx_debt": 30.0, "em": 1.0},
}
PROXIMITY = {"epicentre": 1.0, "same_region": 0.6, "other": 0.25, "DM_anchor": 0.0}  # judgement; TAIWAN: Asia +250, others +80

# Exposure table, one row per ISO3 of the 88-country proposal. SOURCE: judgement. Approximate magnitudes from the
# analyst's memory of IMF Direction of Trade Statistics and UN Comtrade (about 2023), rounded; NOT fetched, verify.
# x_us/x_cn/x_eu: goods exports to the US / China / EU-27, % of the exporter's GDP (EU members include intra-EU).
# oil_net: net oil and gas (and coal where large) exports, % of GDP (negative = net importer).
# comm: main non-oil commodity class (metals / ags / gold / none); comm_x: non-oil commodity exports, % of GDP.
EXPOSURE_CSV = """iso3,x_us,x_cn,x_eu,oil_net,comm,comm_x
VNM,25,13,10,-2,none,3
PHL,3.5,3,2.5,-3,none,1
CHN,2.8,0,2.8,-2,none,0
MYS,13,13,8,4,ags,5
SGP,9,13,8,-3,none,0
JPN,3,3.5,1.8,-3,none,0
KOR,6,7,3.5,-5,none,0
IND,2.3,0.5,2,-3.5,none,1
PAK,1.5,0.7,2,-3.5,ags,2
BLZ,4,0.2,2,-5,ags,8
BRA,1.8,4,2,1,ags,6
ARG,1,1.3,2,0.5,ags,8
COL,4.2,1.2,1.5,5,ags,3
VEN,3,4,1,20,none,0
NGA,1.5,0.4,4.5,7,none,0.5
SEN,0.3,1,4,3,gold,5
ZMB,0.2,6,1.5,-4,metals,30
ZWE,0.2,1.5,1,-4,gold,15
USA,0,0.5,1.4,1,none,1
DEU,3.8,2.7,20,-2.5,none,0
GBR,2,0.8,5,-0.5,none,0
FRA,1.6,0.8,12,-2,none,0
ITA,3.3,0.8,13,-2.5,none,0
CAN,21,1.3,1.3,6,metals,3
AUS,1,7,0.8,3,metals,9
IDN,1.8,4.5,1.2,2,metals,3
THA,9,6,4,-5,ags,2
LKA,3.5,0.3,3,-5,ags,2
MNG,0.1,50,0.5,-8,metals,50
PNG,1,6,2,12,metals,10
MDV,0.5,0.3,1.5,-12,none,0
MEX,30,0.5,1.4,-1,none,1
CHL,4,12,2.5,-4,metals,20
PER,3,9,2.5,-1,metals,18
URY,1.5,3,1.5,-3,ags,10
PAN,0.5,0.5,0.5,-5,none,1
DOM,6,0.2,0.6,-4,gold,3
CRI,7,0.3,2.5,-3,ags,4
GTM,4,0.1,0.6,-4,ags,5
PRY,0.4,0.1,1,-4,ags,15
ECU,5.5,4,2.5,5,ags,10
SLV,7,0.1,0.6,-6,none,1
JAM,3,0.5,1,-8,metals,4
BOL,0.5,1.5,0.5,2,metals,12
HND,9,0.2,2,-6,ags,6
TTO,12,0.5,4,25,none,0
SUR,0.5,0.2,2,5,gold,25
TUR,1.5,0.3,9,-4,none,1
POL,2,0.4,37,-3,none,1
HUN,2,0.5,60,-4,none,0
ROU,0.7,0.2,20,-2,none,1
SRB,0.7,0.8,30,-4,metals,3
UKR,0.5,1.3,13,-4,ags,12
KAZ,1,6,12,20,metals,5
UZB,0.2,2,1,0,gold,8
GEO,0.4,1.5,2.5,-5,metals,5
ARM,0.3,1.5,1.5,-4,metals,6
AZE,0.5,0.2,25,30,none,0
MKD,0.5,0.5,40,-5,none,1
MNE,0.1,0.1,3,-6,metals,1
ALB,0.3,0.2,10,0,none,1
TJK,0,1,0.5,-6,metals,10
SAU,2,6,3,25,none,1
ARE,0.5,4,2,15,none,0
QAT,0.8,8,6,40,none,0
KWT,0.5,10,2,40,none,0
OMN,0.6,25,1,25,none,0
BHR,2,0.5,2,10,metals,8
JOR,6,0.5,1,-7,ags,4
IRQ,3,12,5,35,none,0
LBN,0.3,0.2,2,-10,gold,2
ISR,3.5,1,3,-1.5,none,0
ZAF,2.5,2.4,5.5,-4,metals,10
EGY,0.5,0.1,2.5,-1,none,1
MAR,1,0.5,15,-6,ags,5
TUN,0.6,0.1,25,-4,none,2
KEN,0.6,0.1,1,-4,ags,4
GHA,1,3,4,4,gold,15
CIV,1,0.3,8,1,ags,15
AGO,0.7,15,3,25,none,1
ETH,0.2,0.2,0.5,-4,ags,3
CMR,0.5,2,5,3,ags,6
GAB,0.5,10,6,20,metals,8
RWA,0.2,0.5,1,-4,ags,5
NAM,1,4,7,-5,metals,15
MOZ,0.5,3,4,3,metals,6
BEN,0.2,1,1,-4,ags,6
COG,0.5,25,3,35,none,2
"""
EXPOSURE_DEFAULT = {"x_us": 2.0, "x_cn": 2.0, "x_eu": 3.0, "oil_net": -3.0, "comm": "none", "comm_x": 2.0}   # judgement, ISO3 not in the table
MAINEXP_KEYWORDS = (("crude", "oil"), ("oil", "oil"), ("gas", "oil"), ("copper", "metals"), ("iron", "metals"),
                    ("metal", "metals"), ("gold", "gold"), ("soy", "ags"), ("coffee", "ags"), ("cocoa", "ags"))


def exposure_table() -> pd.DataFrame:
    return pd.read_csv(io.StringIO(EXPOSURE_CSV), dtype={"iso3": str, "comm": str}).set_index("iso3")


# ---------------------------------------------------------------- exposures per country

def _rating_bucket(r) -> str | None:
    if not isinstance(r, str) or r not in RATING_LADDER:
        return None
    i = RATING_LADDER.index(r)
    return "IG" if i <= RATING_LADDER.index("BBB-") else "BB" if i <= RATING_LADDER.index("BB-") else \
        "B" if i <= RATING_LADDER.index("B-") else "CCC"


def _indicator_row(indicators: pd.DataFrame | None, iid: str, names) -> pd.Series:
    if indicators is None or "id" not in indicators.columns:
        return pd.Series(np.nan, index=list(names))
    ind = indicators.assign(id=indicators["id"].astype(str)).set_index("id")
    if iid not in ind.index:
        return pd.Series(np.nan, index=list(names))
    row = ind.loc[iid]
    if isinstance(row, pd.DataFrame):
        row = row.iloc[0]
    return pd.to_numeric(row.reindex(list(names)), errors="coerce")


def country_exposures(countries: pd.DataFrame, indicators: pd.DataFrame | None = None, base_dir=None) -> pd.DataFrame:
    """One row per country (index = country name): tier, level beta, risk multiplier, regime FX beta, FX-debt share,
    trade / oil / commodity exposures, main commodity, commodity-exporter flag and `source` of the exposures
    ("table", or "default" for an ISO3 not in EXPOSURE_CSV)."""
    import warnings
    names = list(countries["country"])
    with warnings.catch_warnings():
        warnings.simplefilter("ignore", RuntimeWarning)
        tiers = country_tiers(countries, base_dir)
    tab = exposure_table()
    iso = countries["iso"].astype(str).tolist() if "iso" in countries.columns else [""] * len(names)
    fxd = _indicator_row(indicators, "1.5", names)
    rows = []
    for k, (n, i3, tier) in enumerate(zip(names, iso, tiers)):
        r = countries.iloc[k]
        td = TIER_DEFAULTS.get(tier, TIER_DEFAULTS["unknown"])
        sp = pd.to_numeric(pd.Series([r.get("spread")]), errors="coerce").iloc[0]
        spread0 = float(sp) if pd.notna(sp) else td["spread"]
        bucket = _rating_bucket(r.get("rating"))
        risk = 0.0 if tier == "DM_anchor" else (RATING_RISK[bucket] if bucket else td["risk"])
        regime = r.get("fxregime")
        beta = REGIME_FX_BETA.get(regime, REGIME_FX_BETA_UNKNOWN) if isinstance(regime, str) else REGIME_FX_BETA_UNKNOWN
        if i3 == "USA":
            beta = 0.0                                       # the numeraire
        fx_debt = float(fxd[n]) if pd.notna(fxd[n]) else td["fx_debt"]
        if i3 in tab.index:
            e = tab.loc[i3].to_dict(); src = "table"
        else:
            e = dict(EXPOSURE_DEFAULT); src = "default"
            mx = str(r.get("mainexp") or "").lower()
            for kw, cls in MAINEXP_KEYWORDS:
                if kw in mx:
                    if cls == "oil":
                        e["oil_net"] = max(e["oil_net"], 10.0)
                    else:
                        e["comm"], e["comm_x"] = cls, max(e["comm_x"], 10.0)
                    src = "default+mainexp"; break
        oil_net, comm_x = float(e["oil_net"]), float(e["comm_x"])
        main = "oil" if oil_net > 0 and oil_net >= comm_x else (e["comm"] if e["comm"] != "none" else ("oil" if oil_net > 0 else "none"))
        exptype = r.get("exptype")
        is_comm = (exptype == "Commodity") if isinstance(exptype, str) and exptype else (max(oil_net, comm_x) >= 5.0)
        lb = float(np.clip(spread0 / c("level_ref_bp"), c("level_beta_min"), c("level_beta_max")))
        rows.append({"country": n, "iso": i3, "tier": tier, "region": r.get("region"), "spread0": spread0, "level_beta": lb,
                     "em": td["em"] if tier != "desk_current" else (0.0 if i3 == "USA" else 1.0), "risk": risk, "fx_beta": beta,
                     "regime": regime if isinstance(regime, str) else "unknown", "fx_debt": fx_debt,
                     "x_us": float(e["x_us"]), "x_cn": float(e["x_cn"]), "x_eu": float(e["x_eu"]),
                     "oil_net": oil_net, "comm": e["comm"], "comm_x": comm_x, "main_commodity": main,
                     "commodity_exporter": bool(is_comm), "source": src})
    return pd.DataFrame(rows).set_index("country")


# ---------------------------------------------------------------- propagation

def partner_growth(d: Drivers) -> dict:
    r, oil10, v = d.us_rate_bp / 100.0, d.oil_pct / 10.0, d.vix_pts
    return {"US": c("g_us_per_100bp") * r + c("g_us_per_vix") * v + c("g_us_per_10pct_oil") * oil10,
            "EU": c("g_eu_per_100bp") * r + c("g_eu_per_vix") * v + c("g_eu_per_10pct_oil") * oil10 + c("g_eu_per_china_pp") * d.china_gdp_pp,
            "CN": d.china_gdp_pp + c("g_cn_per_10pct_oil") * oil10}


def commodity_prices(d: Drivers) -> dict:
    usd = c("commod_per_usd") * d.usd_pct
    return {"oil": d.oil_pct, "metals": c("metals_per_china_pp") * d.china_gdp_pp + usd,
            "ags": c("ags_per_china_pp") * d.china_gdp_pp + usd, "gold": c("gold_per_vix") * d.vix_pts + usd, "none": 0.0}


def _proximity(x: pd.Series, d: Drivers) -> float:
    if d.conflict == 0 or x["tier"] == "DM_anchor":
        return 0.0
    if d.conflict_epicentre and x["iso"] == d.conflict_epicentre:
        return PROXIMITY["epicentre"]
    if d.conflict_region and x["region"] == d.conflict_region:
        return PROXIMITY["same_region"]
    return PROXIMITY["other"]


def propagate(drivers: Drivers | dict, countries: pd.DataFrame, indicators: pd.DataFrame | None = None, base_dir=None,
              notch_rule: bool = False) -> pd.DataFrame:
    """Country-level shocks for a driver vector. One row per country with spread change by channel (bp), FX change
    (3-month depreciation, %), growth change (pp), commodity gap, reserves, current account, inflation, debt/GDP
    revaluation factor, text stress, trigger add-ons, notches and the main channel."""
    d = (drivers if isinstance(drivers, Drivers) else Drivers.from_dict(drivers)).check(input_range=False)
    if not isinstance(notch_rule, bool):
        raise ValueError(f"notch_rule must be true or false, got {notch_rule!r}")
    ex = country_exposures(countries, indicators, base_dir)
    g = partner_growth(d); px = commodity_prices(d)
    r100, v = d.us_rate_bp / 100.0, d.vix_pts
    elas = c("partner_import_elasticity")
    # China's own move first (CNY feeds Asian FX)
    cn_home_fx = 0.0
    if "CHN" in set(ex["iso"]):
        cn_beta = float(ex.loc[ex["iso"] == "CHN", "fx_beta"].iloc[0])
        cn_home_fx = cn_beta * -c("fx_home_china_per_pp") * d.china_gdp_pp
    out = []
    for n, x in ex.iterrows():
        prox = _proximity(x, d); conf = d.conflict * prox
        # terms of trade, % of GDP
        tot = x["oil_net"] * px["oil"] / 100.0 + (x["comm_x"] * px[x["comm"]] / 100.0 if x["comm"] != "none" else 0.0)
        g_trade = (x["x_us"] * g["US"] + x["x_cn"] * g["CN"] + x["x_eu"] * g["EU"]) * elas / 100.0
        g_home = d.china_gdp_pp if x["iso"] == "CHN" else (g["US"] if x["iso"] == "USA" else 0.0)
        dg = g_trade + c("growth_per_tot") * tot + g_home
        lb, em = x["level_beta"], x["em"]
        s_fin = em * lb * (c("s_per_100bp") * r100 + c("s_per_vix") * v + c("s_per_usd_at_fxd50") * d.usd_pct * x["fx_debt"] / 50.0)
        s_trade = em * lb * -c("s_per_growth_pp") * g_trade
        s_comm = em * lb * -(c("s_per_tot_pct") if tot < 0 else c("s_per_tot_gain")) * tot
        s_conf = c("s_conflict") * conf
        s_home = -c("s_home_china_per_pp") * d.china_gdp_pp if x["iso"] == "CHN" else 0.0
        ds = s_fin + s_trade + s_comm + s_conf + s_home
        pressure = (c("fx_per_usd") * d.usd_pct + x["risk"] * (c("fx_per_100bp") * r100 + c("fx_per_vix") * v)
                    - c("fx_per_tot_pct") * tot + c("fx_conflict") * conf)
        if x["iso"] == "CHN":
            pressure += -c("fx_home_china_per_pp") * d.china_gdp_pp
        if x["iso"] == "USA":
            pressure = 0.0
        dfx = x["fx_beta"] * pressure
        if x["region"] == "Asia" and x["iso"] != "CHN" and x["tier"] != "DM_anchor":
            dfx += c("fx_asia_cny_beta") * x["fx_beta"] * cn_home_fx
        dres = -c("res_absorb") * (1.0 - x["fx_beta"]) * pressure if x["regime"] in ("Peg", "Managed") else 0.0
        commgap = c("commgap_pass") * px[x["main_commodity"]] if x["commodity_exporter"] else 0.0
        dca = g_trade + tot + c("ca_conflict") * conf
        oil_pass = c("infl_per_oil_importer") if x["oil_net"] <= 0 else c("infl_per_oil_exporter")
        dinfl = oil_pass * d.oil_pct + c("infl_per_fx") * dfx
        debt_mult = 1.0 + x["fx_debt"] / 100.0 * dfx / 100.0
        dtext = c("t_per_vix") * v + c("t_per_100bp") * r100 + c("t_conflict") * conf
        near = prox >= 0.5
        trig5 = c("trig5_conflict") * conf if near else 0.0
        trig6 = c("trig6_conflict") * conf if near else 0.0
        notches = 0
        if notch_rule and isinstance(countries.set_index("country").at[n, "rating"], str) and ds > 0:
            notches = -int(min(c("notch_max"), math.floor(ds / c("notch_bp"))))
        chans = {"financial": s_fin, "trade": s_trade, "commodity": s_comm, "conflict": s_conf, "home": s_home}
        main = max(chans, key=lambda k: abs(chans[k])) if any(abs(v_) > 0.5 for v_ in chans.values()) else "none"
        out.append({"country": n, "iso": x["iso"], "tier": x["tier"], "d_spread_bp": ds, **{f"s_{k}": val for k, val in chans.items()},
                    "d_fx_pct": dfx, "d_growth_pp": dg, "tot_pct_gdp": tot, "d_commgap": commgap, "d_res3m": dres, "d_ca_pp": dca,
                    "d_inflation_pp": dinfl, "debt_mult": debt_mult, "d_textz": dtext, "trigger5": trig5, "trigger6": trig6,
                    "notches": notches, "proximity": prox, "main_channel": main, "exposure_source": x["source"]})
    return pd.DataFrame(out).set_index("country")


# ---------------------------------------------------------------- compiler to stress.py shocks

_ROUND = {"spread": 0, "fx3m": 1, "textz": 2, "commgap": 1, "res3m": 1, "5.6": 2, "2.8": 2, "5.5": 2, "trigger": 1}


def _grouped(df: pd.DataFrame, col: str, digits: int, make, key_col: str = "iso", neutral: float = 0.0) -> list[dict]:
    vals = df[col].astype(float).round(digits)
    out = []
    for v in sorted(set(vals[vals != neutral])):
        sel = sorted(df.loc[vals == v, key_col].astype(str))
        out.append(make(float(v), {f"{key_col}_in": sel}))
    return out


def compile_shocks(drivers: Drivers | dict, countries: pd.DataFrame, indicators: pd.DataFrame | None = None, base_dir=None,
                   notch_rule: bool = False, bis_exposures: str = "live/raw_bis_cbs.csv", notes: list | None = None) -> list[dict]:
    """Compile a driver vector into an ordinary stress.py shock list for this universe. A zero driver vector gives [].
    Country shocks are grouped by equal (rounded) value and filtered with `iso_in` (or `country_in` when the table
    has no iso column). BIS common-creditor contagion is emitted as stress.py `contagion` shocks only when the
    exposure file exists under `base_dir` (default data/); otherwise it is skipped and noted in `notes`."""
    d = (drivers if isinstance(drivers, Drivers) else Drivers.from_dict(drivers)).check(input_range=False)
    if not isinstance(notch_rule, bool):
        raise ValueError(f"notch_rule must be true or false, got {notch_rule!r}")
    notes = notes if notes is not None else []
    if d.is_zero():
        return []
    p = propagate(d, countries, indicators, base_dir, notch_rule).reset_index()
    key = "iso" if "iso" in countries.columns else "country"
    has_ind = indicators is not None and "id" in indicators.columns
    ind_ids = set(indicators["id"].astype(str)) if has_ind else set()
    sh: list[dict] = []
    col = lambda column, op="add": (lambda v, w: {"target": "countries", "column": column, "op": op, "value": v, "where": w})
    sh += _grouped(p, "d_spread_bp", _ROUND["spread"], col("spread"), key)
    sh += _grouped(p, "d_fx_pct", _ROUND["fx3m"], col("fx3m"), key)
    sh += _grouped(p, "d_textz", _ROUND["textz"], col("textz"), key)
    sh += _grouped(p, "d_commgap", _ROUND["commgap"], col("commgap"), key)
    if "res3m" in countries.columns:
        sh += _grouped(p, "d_res3m", _ROUND["res3m"], col("res3m"), key)
    if notch_rule and "rating" in countries.columns:
        sh += _grouped(p, "notches", 0, lambda v, w: {"target": "countries", "column": "rating", "op": "notch", "value": int(v), "where": w}, key)
    ind = lambda iid, op="add": (lambda v, w: {"target": "indicators", "id": iid, "op": op, "value": v, "where": w})
    for iid, colname in (("5.6", "d_growth_pp"), ("2.8", "d_ca_pp"), ("5.5", "d_inflation_pp")):
        if iid in ind_ids:
            sh += _grouped(p, colname, _ROUND[iid], ind(iid), key)
    if "1.3" in ind_ids:
        sh += _grouped(p, "debt_mult", 4, ind("1.3", "mul"), key, neutral=1.0)
    if "2.1" in ind_ids:
        p["res_mult"] = 1.0 + p["d_res3m"] / 100.0
        sh += _grouped(p, "res_mult", 4, ind("2.1", "mul"), key, neutral=1.0)
    for pillar in (5, 6):
        sh += _grouped(p, f"trigger{pillar}", _ROUND["trigger"],
                       lambda v, w, pillar=pillar: {"target": "trigger", "pillar": pillar, "value": v, "where": w,
                                                    "item": f"Macro scenario: regional conflict pillar {pillar}"}, key)
    if d.conflict >= 0.5:
        near = sorted(p.loc[p["proximity"] >= 0.5, key].astype(str))
        if near:
            sh.append({"target": "portfolio", "column": "location", "op": "set", "value": "High activity", "where": {f"{key}_in": near}})
    # settings
    oil_up = max(d.oil_pct, 0.0) / 10.0
    gl = c("gl_per_vix") * d.vix_pts + c("gl_per_100bp") * d.us_rate_bp / 100.0 - c("gl_per_china_pp") * d.china_gdp_pp + c("gl_per_10pct_oil") * oil_up
    if round(gl, 4):
        sh.append({"target": "settings", "key": "regime.*.global_loading", "op": "add", "value": round(gl, 4), "max": c("gl_max")})
    if d.conflict:
        sh.append({"target": "settings", "key": "regime.regional_loading", "op": "add", "value": round(c("rl_conflict") * d.conflict, 4), "max": c("rl_max")})
    liq = c("liq_per_vix") * d.vix_pts + c("liq_conflict") * d.conflict
    if round(liq, 4):
        sh.append({"target": "settings", "key": "liquidity.by_asset.*.spread_mean", "op": "mul", "value": round(1.0 + liq, 4)})
    if round(c("eqvol_per_vix") * d.vix_pts, 2):
        sh.append({"target": "settings", "key": "market.equity_vol", "op": "add", "value": round(c("eqvol_per_vix") * d.vix_pts, 2), "min": 1.0})
    lr = c("lrvol_per_100bp") * d.us_rate_bp / 100.0 + c("lrvol_per_10pct_oil") * oil_up
    if round(lr, 4):
        sh.append({"target": "settings", "key": "market.local_rate_vol", "op": "mul", "value": round(1.0 + lr, 4)})
    hard = c("hard_rate_per_bp") * d.us_rate_bp
    local = c("local_rate_per_bp") * d.us_rate_bp + c("local_rate_per_10pct_oil") * oil_up
    if round(hard, 1):
        sh.append({"target": "rates", "leg": "hard", "op": "add", "value": round(hard, 1)})
    if round(local, 1):
        sh.append({"target": "rates", "leg": "local", "op": "add", "value": round(local, 1)})
    # BIS common-creditor contagion through the existing stress.py target (data-gated)
    names_by_iso = dict(zip(countries.get("iso", countries["country"]), countries["country"]))
    legs = []
    if d.china_gdp_pp < 0 and "CHN" in names_by_iso:
        legs.append(("CHN", -c("bis_china_per_pp") * d.china_gdp_pp))
    if d.conflict and d.conflict_epicentre in names_by_iso:
        legs.append((d.conflict_epicentre, c("bis_conflict") * d.conflict))
    exp_file = Path(base_dir or Path(__file__).resolve().parents[2] / "data") / bis_exposures
    for origin, val in legs:
        if not exp_file.is_file():
            notes.append(f"BIS contagion from {origin} (+{val:.0f} bp to the most exposed peer) skipped: {bis_exposures} not found")
            continue
        sh.append({"target": "contagion", "origin": names_by_iso[origin], "column": "spread", "op": "add", "value": round(val, 1),
                   "exposures": bis_exposures, "normalise": "max"})
    return sh


def macro_scenario(preset_or_drivers: str | Drivers | dict, u=None, base_dir=None, notch_rule: bool = False) -> Scenario:
    """A stress.Scenario holding one {"target": "macro"} shock (kind "hypothetical"). The shock is compiled by the
    stress.py hook against the universe the scenario is applied to, at drivers x severity scale, so the conflict gate,
    the "High activity" flag and the notch rule follow the scale (EQ-B-0082 fix). `u` is kept for compatibility."""
    if isinstance(preset_or_drivers, str):
        sh = {"target": "macro", "preset": preset_or_drivers, "notch_rule": notch_rule}
        drv, notch_rule = validate_macro_shock(sh)
        pr = PRESETS[preset_or_drivers]; key, name, src = pr.key, pr.name, pr.source
    else:
        drv = preset_or_drivers if isinstance(preset_or_drivers, Drivers) else Drivers.from_dict(preset_or_drivers)
        sh = {"target": "macro", "drivers": drv.as_dict(), "notch_rule": notch_rule}
        drv, notch_rule = validate_macro_shock(sh)
        key, name, src = "MACRO", "Macro driver scenario", "macro_scenarios.compile_shocks"
    bd = str(Path(base_dir).resolve()) if base_dir else str(Path(__file__).resolve().parents[2] / "data")
    desc = "Drivers: " + ", ".join(f"{k} {v:+g}" for k, v in drv.as_dict().items() if k in DRIVERS and v)
    return Scenario(key, name, desc, [sh], src, kind="hypothetical", base_dir=bd)


MACRO_SHOCK_KEYS = {"target", "preset", "drivers", "notch_rule"}
PRESCALED = "macro_prescaled"     # tag on compiled macro shocks: already at drivers x scale, apply_shocks uses scale 1


def validate_macro_shock(sh: dict, where: str = "") -> tuple[Drivers, bool]:
    """Check one {"target": "macro"} shock and return its (Drivers, notch_rule). Raises ValueError with a clear message
    for an unknown or null preset, both or neither of preset / drivers, a drivers value that is not an object, a
    driver that is not a finite number (strings, bools, NaN, Infinity), conflict outside [0, 1], an unknown driver
    name, or a notch_rule that is not a real true / false. Called by stress.load_scenarios and at run time."""
    at = f" in {where}" if where else ""
    bad = sorted(set(sh) - MACRO_SHOCK_KEYS)
    if bad:
        raise ValueError(f"macro shock{at}: unknown key(s) {bad}; allowed {sorted(MACRO_SHOCK_KEYS)}")
    has_p, has_d = "preset" in sh, "drivers" in sh
    if has_p == has_d:
        raise ValueError(f"macro shock{at} needs exactly one of 'preset' or 'drivers'")
    nr = sh.get("notch_rule", False)
    if not isinstance(nr, bool):
        raise ValueError(f"macro shock{at}: notch_rule must be true or false (a JSON boolean), got {nr!r}")
    try:
        if has_p:
            p = sh["preset"]
            if not isinstance(p, str) or p not in PRESETS:
                raise ValueError(f"unknown macro preset {p!r}; presets are {list(PRESETS)}")
            return PRESETS[p].drivers.check(), nr
        if not isinstance(sh["drivers"], dict):
            raise ValueError(f"drivers must be an object of driver values, got {sh['drivers']!r}")
        return Drivers.from_dict(sh["drivers"]), nr
    except (TypeError, ValueError) as e:
        raise ValueError(f"macro shock{at}: {e}") from None


def reject_prescaled(shocks: list[dict], where: str = "") -> None:
    """Raise ValueError if a caller-supplied shock carries the internal PRESCALED key. Only expand_macro_shocks sets it;
    a hand-written one would be applied at scale 1 and ignore the severity scale."""
    at = f" in {where}" if where else ""
    for sh in shocks:
        if isinstance(sh, dict) and PRESCALED in sh:
            raise ValueError(f"shock{at} carries the internal key {PRESCALED!r}; it is set only by expand_macro_shocks "
                             f"and is not allowed in scenarios: {sh!r}")


def validate_macro_shocks(shocks: list[dict], where: str = "") -> None:
    """Validate every {"target": "macro"} shock of a scenario and refuse the internal PRESCALED key on any shock
    (stress.load_scenarios calls this)."""
    reject_prescaled(shocks, where)
    for sh in shocks:
        if isinstance(sh, dict) and sh.get("target") == "macro":
            validate_macro_shock(sh, where)


def expand_macro_shocks(shocks: list[dict], u, base_dir=None, scale: float = 1.0) -> list[dict]:
    """stress.py hook: replace each {"target": "macro", "preset": KEY} or {"target": "macro", "drivers": {...},
    "notch_rule": false} shock by its compiled shocks for universe `u`, compiled from the drivers x `scale` and tagged
    PRESCALED so that apply_shocks applies them at scale 1. Scaling the drivers, not the compiled shocks, keeps the
    conflict gate (intensity >= 0.5, "High activity" flag), trigger gates and notch rounding consistent with the
    severity scale. At scale <= 0 macro shocks are dropped. Other shocks pass through unchanged."""
    if not any(sh.get("target") == "macro" for sh in shocks):
        return shocks
    out = []
    for sh in shocks:
        if sh.get("target") != "macro":
            out.append(sh); continue
        drv, notch_rule = validate_macro_shock(sh)
        if scale <= 0:
            continue
        for x in compile_shocks(drv.scaled(scale), u.countries, u.indicators, base_dir, notch_rule):
            out.append({**x, PRESCALED: True})
    return out


def apply_with_prescaled(u, s, shocks: list[dict], scale: float, base_dir=None):
    """Apply a shock list that holds PRESCALED macro shocks: consecutive runs are applied in order, tagged runs at
    scale 1 and the rest at `scale`, each through stress.apply_shocks (so the order of shocks is kept)."""
    from .stress import apply_shocks
    runs: list[tuple[bool, list[dict]]] = []
    for sh in shocks:
        tag = bool(sh.get(PRESCALED))
        x = {k: v for k, v in sh.items() if k != PRESCALED}
        if runs and runs[-1][0] == tag:
            runs[-1][1].append(x)
        else:
            runs.append((tag, [x]))
    for tag, run in runs:
        u, s = apply_shocks(u, s, run, 1.0 if tag else scale, base_dir=base_dir)
    return u, s


# ---------------------------------------------------------------- brief

def brief_table(drivers: Drivers | dict, countries: pd.DataFrame, indicators: pd.DataFrame | None = None, base_dir=None,
                title: str | None = None, top: int | None = None) -> str:
    """Markdown 'what this scenario does to each country' table, worst spread move first."""
    d = drivers if isinstance(drivers, Drivers) else Drivers.from_dict(drivers)
    p = propagate(d, countries, indicators, base_dir).sort_values("d_spread_bp", ascending=False)
    if top:
        p = p.head(top)
    drv = ", ".join(f"{DRIVERS[k].split(',')[0]} {v:+g}" for k, v in d.as_dict().items() if k in DRIVERS and v) or "none"
    where = f" ({d.conflict_region}, centre {d.conflict_epicentre})" if d.conflict else ""
    lines = [f"### {title or 'Macro scenario'}", "", f"Drivers: {drv}{where}.", "",
             "| Country | Spread (bp) | FX (% weaker) | Growth (pp) | Commodity gap | Main channel |", "|---|---:|---:|---:|---:|---|"]
    for n, r in p.iterrows():
        lines.append(f"| {n} | {r['d_spread_bp']:+.0f} | {r['d_fx_pct']:+.1f} | {r['d_growth_pp']:+.2f} | "
                     f"{r['d_commgap']:+.0f} | {r['main_channel']} |")
    lines += ["", "Coefficients are judgement (econquest/engine/macro_scenarios.py COEF); trade and commodity exposures are a "
              "judgement table, not fetched data. See docs/validation/macro-scenarios.md."]
    return "\n".join(lines)
