"""Econometrics toolkit for the desk, run on the Market History prices and the GPR series.

Workflow (per series): stationarity (ADF, KPSS) -> AR mean + GARCH variance baseline -> residual checks
(Ljung-Box, ARCH-LM) -> out-of-sample variance-forecast horse race (GARCH vs EWMA vs rolling vs constant,
Diebold-Mariano with HAC) -> HAC standard errors throughout -> Benjamini-Hochberg correction across series.

Toolkits: Engle-Granger and Johansen cointegration with VECM adjustment (pairs), SVAR impulse responses and
variance decomposition, Kalman-filter time-varying betas, Markov-switching and threshold regimes,
Fama-MacBeth and GMM risk premia, GARCH + EVT (peaks over threshold) tails, t and Clayton copulas,
lasso / ridge / PCA-factor / random-forest forecasts of future volatility, and an event study of equity
ETFs around currency shocks.

numpy, scipy and pandas only, plus scikit-learn for the penalized and tree forecasts when it is installed.

FX-only prices.csv (EQ-B-0077): without the EEM column (the EM equity market) and the country ETF columns, the tables
that need them are skipped with a reason in `notes["skipped"]` ({table: reason}), a log line and a RuntimeWarning:
the SVAR (EEM-first ordering), the Kalman equity betas on EEM, the Fama-MacBeth / GMM premia (ETF test assets and
the EEM factor), the equity copula pairs and the event study. The forecast panel drops its two EEM predictors. The
FX tables (workflow, FX cointegration, FX Kalman betas on the FX basket, regimes, EVT, FX copula pairs, forecasts)
run as before. With EEM and the ETFs present nothing changes.
"""
from __future__ import annotations

import math
import warnings
from dataclasses import dataclass, field

import numpy as np
import pandas as pd
from scipy import optimize, stats

from .garch import garch11_fit, arch_lm_test, ljung_box, t_quantile, _returns, clean_bad_ticks, _business_daily, TRADING_DAYS

try:  # optional
    from sklearn.linear_model import LassoCV, RidgeCV, LinearRegression
    from sklearn.ensemble import RandomForestRegressor
    from sklearn.decomposition import PCA
    HAVE_SKLEARN = True
except Exception:  # pragma: no cover
    HAVE_SKLEARN = False


# ----------------------------------------------------------------------------------------------
# Regression with HAC (Newey-West) standard errors
# ----------------------------------------------------------------------------------------------
def ols_hac(y: np.ndarray, X: np.ndarray, lags: int | None = None) -> dict:
    y = np.asarray(y, float); X = np.asarray(X, float)
    n, k = X.shape
    XtX_inv = np.linalg.pinv(X.T @ X)
    b = XtX_inv @ X.T @ y
    e = y - X @ b
    L = lags if lags is not None else int(math.floor(4 * (n / 100) ** (2 / 9)))
    S = (X * e[:, None]).T @ (X * e[:, None])
    for l in range(1, L + 1):
        w = 1 - l / (L + 1)
        G = (X[l:] * e[l:, None]).T @ (X[:-l] * e[:-l, None])
        S += w * (G + G.T)
    V = XtX_inv @ S @ XtX_inv
    se = np.sqrt(np.maximum(np.diag(V), 0))
    tstat = b / np.where(se > 0, se, np.nan)
    r2 = 1 - e.var() / y.var() if y.var() > 0 else np.nan
    return {"b": b, "se": se, "t": tstat, "p": 2 * (1 - stats.norm.cdf(np.abs(tstat))), "resid": e, "r2": r2, "n": n, "lags": L, "cov": V}


def _lagmat(x: np.ndarray, p: int) -> np.ndarray:
    return np.column_stack([x[p - i - 1:len(x) - i - 1] for i in range(p)])


def newey_west_var(x: np.ndarray, lags: int | None = None) -> float:
    x = np.asarray(x, float); x = x - x.mean(); n = len(x)
    L = lags if lags is not None else int(math.floor(4 * (n / 100) ** (2 / 9)))
    v = np.sum(x ** 2) / n
    for l in range(1, L + 1):
        v += 2 * (1 - l / (L + 1)) * np.sum(x[l:] * x[:-l]) / n
    return float(v)


# ----------------------------------------------------------------------------------------------
# Unit-root and stationarity tests
# ----------------------------------------------------------------------------------------------
_DF_Q = np.array([-3.43, -3.12, -2.86, -2.57, -1.57, -0.44, -0.07, 0.23, 0.60])     # tau_mu asymptotic quantiles
_DF_P = np.array([0.01, 0.025, 0.05, 0.10, 0.50, 0.90, 0.95, 0.975, 0.99])
_EG_Q = np.array([-3.90, -3.59, -3.34, -3.04, -2.00, -0.80, -0.45, -0.15, 0.20])     # Engle-Granger, 2 variables, constant
_KPSS_Q = np.array([0.347, 0.463, 0.574, 0.739]); _KPSS_P = np.array([0.10, 0.05, 0.025, 0.01])


def _interp_p(stat: float, q: np.ndarray, p: np.ndarray) -> float:
    """Approximate p-value by interpolating tabulated quantiles on the probit scale."""
    z = stats.norm.ppf(p)
    return float(stats.norm.cdf(np.interp(stat, q, z, left=z[0] - (q[0] - stat), right=z[-1] + (stat - q[-1]))))


def adf_test(x: np.ndarray, max_lag: int | None = None, table=_DF_Q) -> dict:
    """Augmented Dickey-Fuller with constant; lag by BIC. Returns stat, approximate p, lag, critical values."""
    x = np.asarray(x, float); x = x[np.isfinite(x)]
    n = len(x); max_lag = max_lag if max_lag is not None else int(12 * (n / 100) ** 0.25)
    dx = np.diff(x)
    best = None
    for p in range(0, max_lag + 1):
        y = dx[p:]; X = [np.ones(len(y)), x[p:-1]]
        if p:
            X += [dx[p - i - 1:len(dx) - i - 1] for i in range(p)]
        X = np.column_stack(X)
        b, *_ = np.linalg.lstsq(X, y, rcond=None); e = y - X @ b
        bic = len(y) * math.log(max(e @ e / len(y), 1e-300)) + X.shape[1] * math.log(len(y))
        if best is None or bic < best[0]:
            s2 = e @ e / (len(y) - X.shape[1]); cov = s2 * np.linalg.pinv(X.T @ X)
            best = (bic, p, b[1] / math.sqrt(cov[1, 1]))
    stat = float(best[2])
    return {"stat": stat, "p": _interp_p(stat, table, _DF_P), "lag": best[1], "crit_1pct": table[0], "crit_5pct": table[2], "crit_10pct": table[3]}


def kpss_test(x: np.ndarray) -> dict:
    """KPSS level-stationarity test with Bartlett long-run variance."""
    x = np.asarray(x, float); x = x[np.isfinite(x)]; n = len(x)
    e = x - x.mean(); S = np.cumsum(e)
    L = int(4 * (n / 100) ** 0.25)
    lrv = newey_west_var(e, L)
    stat = float(np.sum(S ** 2) / (n ** 2 * lrv))
    return {"stat": stat, "p": float(1 - _interp_p(stat, _KPSS_Q, 1 - _KPSS_P)), "lag": L, "crit_5pct": 0.463}


def benjamini_hochberg(p: np.ndarray, q: float = 0.05) -> np.ndarray:
    """Boolean mask of discoveries at FDR q."""
    p = np.asarray(p, float); m = np.isfinite(p).sum()
    order = np.argsort(np.where(np.isfinite(p), p, np.inf)); ranked = p[order]
    thresh = q * (np.arange(1, len(p) + 1)) / max(m, 1)
    ok = ranked <= thresh
    k = np.max(np.where(ok)[0]) if ok.any() else -1
    out = np.zeros(len(p), bool)
    if k >= 0:
        out[order[:k + 1]] = True
    return out


# ----------------------------------------------------------------------------------------------
# Workflow: AR baseline, residual checks, out-of-sample variance horse race
# ----------------------------------------------------------------------------------------------
def ar_fit_bic(r: np.ndarray, max_p: int = 5) -> dict:
    r = np.asarray(r, float); best = None
    for p in range(0, max_p + 1):
        y = r[p:]; X = np.ones((len(y), 1)) if p == 0 else np.column_stack([np.ones(len(y)), _lagmat(r, p)])
        res = ols_hac(y, X)
        bic = len(y) * math.log(max(res["resid"] @ res["resid"] / len(y), 1e-300)) + X.shape[1] * math.log(len(y))
        if best is None or bic < best["bic"]:
            best = {"p": p, "bic": bic, "coef": res["b"], "t_hac": res["t"], "resid": res["resid"]}
    return best


def diebold_mariano(loss_a: np.ndarray, loss_b: np.ndarray) -> tuple[float, float]:
    d = np.asarray(loss_a) - np.asarray(loss_b); d = d[np.isfinite(d)]
    if len(d) < 30:
        return np.nan, np.nan
    v = newey_west_var(d) / len(d)
    t = d.mean() / math.sqrt(v) if v > 0 else np.nan
    return float(t), float(2 * (1 - stats.norm.cdf(abs(t)))) if np.isfinite(t) else np.nan


def variance_horse_race(r: pd.Series, test_days: int = 250, refit_every: int = 50) -> dict:
    """One-day-ahead variance forecasts over the last `test_days`: GARCH(1,1)-t refit every `refit_every` days,
    EWMA (lambda 0.94), 60-day rolling variance, constant in-sample variance. Losses: QLIKE and MSE vs r^2."""
    x = r.to_numpy(); n = len(x); start = n - test_days
    fc = {"GARCH": np.full(test_days, np.nan), "EWMA": np.full(test_days, np.nan), "Rolling60": np.full(test_days, np.nan), "Constant": np.full(test_days, np.nan)}
    ewma = np.var(x[:start])
    for i in range(start):
        ewma = 0.94 * ewma + 0.06 * x[i] ** 2
    fit = None
    for j in range(test_days):
        t = start + j
        if j % refit_every == 0:
            fit = garch11_fit(x[:t])
        # one-step GARCH forecast from the fitted parameters, filtered through the data up to t-1
        e = x[:t] - fit.mu; s2 = fit.long_run_var if np.isfinite(fit.long_run_var) else np.var(e)
        for k in range(max(0, t - 500), t):
            s2 = fit.omega + fit.alpha * e[k] ** 2 + fit.beta * s2
        fc["GARCH"][j] = s2
        fc["EWMA"][j] = ewma; ewma = 0.94 * ewma + 0.06 * x[t] ** 2
        fc["Rolling60"][j] = np.var(x[t - 60:t]); fc["Constant"][j] = np.var(x[:start])
    real = x[start:] ** 2
    out = {}
    for k, f in fc.items():
        f = np.maximum(f, 1e-14)
        out[k] = {"qlike": float(np.mean(np.log(f) + real / f)), "mse": float(np.mean((real - f) ** 2))}
    dm_t, dm_p = diebold_mariano(np.log(np.maximum(fc["GARCH"], 1e-14)) + real / np.maximum(fc["GARCH"], 1e-14),
                                 np.log(np.maximum(fc["EWMA"], 1e-14)) + real / np.maximum(fc["EWMA"], 1e-14))
    best = min(out, key=lambda k: out[k]["qlike"])
    return {"losses": out, "best_qlike": best, "dm_garch_vs_ewma_t": dm_t, "dm_p": dm_p}


def workflow_table(returns: dict[str, pd.Series], prices: pd.DataFrame, meta: dict[str, tuple[str, str]]) -> pd.DataFrame:
    rows = []
    for ticker, r in returns.items():
        lp = np.log(prices[ticker].dropna().to_numpy())
        adf_p = adf_test(lp); kp_p = kpss_test(lp); adf_r = adf_test(r.to_numpy()); kp_r = kpss_test(r.to_numpy())
        ar = ar_fit_bic(r.to_numpy())
        lb_mean = ljung_box(ar["resid"], 10); lm = arch_lm_test(ar["resid"])
        g = garch11_fit(ar["resid"])
        lb_sq = ljung_box(g.std_resid ** 2, 10); lm_z = arch_lm_test(g.std_resid)
        hr = variance_horse_race(r)
        country, kind = meta[ticker]
        rows.append({"country": country, "kind": kind, "ticker": ticker, "obs": len(r),
                     "adf_price_stat": adf_p["stat"], "adf_price_p": adf_p["p"], "kpss_price_stat": kp_p["stat"], "kpss_price_p": kp_p["p"],
                     "adf_return_stat": adf_r["stat"], "adf_return_p": adf_r["p"], "kpss_return_p": kp_r["p"],
                     "ar_order": ar["p"], "ar1_coef": ar["coef"][1] if ar["p"] >= 1 else 0.0, "ar1_t_hac": ar["t_hac"][1] if ar["p"] >= 1 else np.nan,
                     "lb_resid_p": lb_mean[1], "arch_lm_resid_p": lm[1], "garch_persistence": g.persistence, "garch_nu": g.nu,
                     "lb_sq_std_resid_p": lb_sq[1], "arch_lm_std_resid_p": lm_z[1],
                     "oos_qlike_garch": hr["losses"]["GARCH"]["qlike"], "oos_qlike_ewma": hr["losses"]["EWMA"]["qlike"], "oos_qlike_rolling": hr["losses"]["Rolling60"]["qlike"], "oos_qlike_constant": hr["losses"]["Constant"]["qlike"],
                     "oos_best": hr["best_qlike"], "dm_garch_vs_ewma_t": hr["dm_garch_vs_ewma_t"], "dm_p": hr["dm_p"]})
    df = pd.DataFrame(rows)
    if len(df):
        df["adf_return_bh_reject"] = benjamini_hochberg(df["adf_return_p"].to_numpy())
        df["arch_bh_reject"] = benjamini_hochberg(df["arch_lm_resid_p"].to_numpy())
        df["bonferroni_arch_p"] = np.minimum(1.0, df["arch_lm_resid_p"] * len(df))
    return df


# ----------------------------------------------------------------------------------------------
# Cointegration: Engle-Granger, Johansen, VECM
# ----------------------------------------------------------------------------------------------
def engle_granger(y: np.ndarray, x: np.ndarray) -> dict:
    X = np.column_stack([np.ones(len(x)), x]); b, *_ = np.linalg.lstsq(X, y, rcond=None)
    resid = y - X @ b
    adf = adf_test(resid, table=_EG_Q)
    rho = float(np.corrcoef(resid[1:], resid[:-1])[0, 1])
    hl = -math.log(2) / math.log(rho) if 0 < rho < 1 else np.nan
    z = float((resid[-1] - resid.mean()) / resid.std(ddof=1))
    return {"beta": float(b[1]), "const": float(b[0]), "adf_stat": adf["stat"], "p": adf["p"], "half_life": hl, "spread_z": z, "resid": resid}


def johansen(Y: np.ndarray, lags: int = 1) -> dict:
    """Johansen trace test (constant in the cointegrating relation and the VAR), k variables, VECM with `lags` lagged differences."""
    Y = np.asarray(Y, float); n, k = Y.shape
    dY = np.diff(Y, axis=0)
    Z0 = dY[lags:]                                                   # dependent
    Z1 = Y[lags:-1]                                                  # lagged level
    Zk = np.column_stack([np.ones(len(Z0))] + [dY[lags - i - 1:len(dY) - i - 1] for i in range(lags)])
    def resid(A):
        B, *_ = np.linalg.lstsq(Zk, A, rcond=None); return A - Zk @ B
    R0, R1 = resid(Z0), resid(Z1)
    T = len(R0)
    S00, S11, S01 = R0.T @ R0 / T, R1.T @ R1 / T, R0.T @ R1 / T
    S11_inv_sqrt = np.linalg.inv(np.linalg.cholesky(S11)).T
    M = S11_inv_sqrt.T @ S01.T @ np.linalg.inv(S00) @ S01 @ S11_inv_sqrt
    ev, V = np.linalg.eigh(M); order = np.argsort(ev)[::-1]; ev = np.clip(ev[order], 0, 1 - 1e-12); V = V[:, order]
    beta = S11_inv_sqrt @ V
    trace = np.array([-T * np.sum(np.log(1 - ev[i:])) for i in range(k)])
    # Osterwald-Lenum 95% critical values, constant case, for k - r = 1..4
    crit95 = {1: 3.84, 2: 15.49, 3: 29.80, 4: 47.86}; crit99 = {1: 6.63, 2: 19.94, 3: 35.46, 4: 54.68}
    rank = 0
    for i in range(k):
        if trace[i] > crit95[k - i]:
            rank = i + 1
        else:
            break
    b1 = beta[:, 0] / beta[0, 0]
    ect = Y[:-1] @ b1
    alpha = np.array([np.linalg.lstsq(np.column_stack([np.ones(len(ect[lags:])), ect[lags:]]), dY[lags:, j], rcond=None)[0][1] for j in range(k)])
    return {"eigenvalues": ev, "trace": trace, "crit95": [crit95[k - i] for i in range(k)], "crit99": [crit99[k - i] for i in range(k)], "rank": rank,
            "beta": b1, "alpha": alpha, "T": T}


def cointegration_table(prices: pd.DataFrame, groups: dict[str, list[str]], nonstationary: set[str] | None = None) -> pd.DataFrame:
    """nonstationary: tickers whose log price fails to reject a unit root (ADF p > 0.05); pairs need both members in it."""
    rows = []
    for gname, tickers in groups.items():
        tickers = [t for t in tickers if t in prices.columns and (nonstationary is None or t in nonstationary)]
        for i in range(len(tickers)):
            for j in range(i + 1, len(tickers)):
                a, b = tickers[i], tickers[j]
                p = prices[[a, b]].dropna(); p = p[(p > 0).all(axis=1)]
                if len(p) < 250:
                    continue
                la, lb = np.log(p[a].to_numpy()), np.log(p[b].to_numpy())
                eg = engle_granger(la, lb)
                jo = johansen(np.column_stack([la, lb]))
                rows.append({"group": gname, "y": a, "x": b, "obs": len(p), "hedge_ratio": eg["beta"], "eg_adf_stat": eg["adf_stat"], "eg_p": eg["p"],
                             "johansen_trace_r0": jo["trace"][0], "johansen_crit95_r0": jo["crit95"][0], "johansen_rank": jo["rank"],
                             "vecm_alpha_y": jo["alpha"][0], "vecm_alpha_x": jo["alpha"][1], "spread_half_life_days": eg["half_life"], "spread_z_now": eg["spread_z"],
                             "corr_returns": float(np.corrcoef(np.diff(la), np.diff(lb))[0, 1])})
    df = pd.DataFrame(rows)
    if len(df):
        df["eg_bh_reject"] = benjamini_hochberg(df["eg_p"].to_numpy())
        df = df.sort_values("eg_p").reset_index(drop=True)
        df["read"] = np.where(df["eg_bh_reject"] & (df["johansen_rank"] >= 1), "Cointegrated (both tests, FDR 5%)",
                     np.where((df["eg_p"] < 0.05) | (df["johansen_rank"] >= 1), "Weak evidence (one test)", "No long-run relationship"))
    return df


# ----------------------------------------------------------------------------------------------
# SVAR with Cholesky identification
# ----------------------------------------------------------------------------------------------
def var_fit(Y: np.ndarray, p: int) -> dict:
    Y = np.asarray(Y, float); n, k = Y.shape
    X = np.column_stack([np.ones(n - p)] + [Y[p - i - 1:n - i - 1] for i in range(p)])
    Yt = Y[p:]
    B, *_ = np.linalg.lstsq(X, Yt, rcond=None)
    E = Yt - X @ B
    Sigma = E.T @ E / (len(Yt) - X.shape[1])
    A = [B[1 + i * k:1 + (i + 1) * k].T for i in range(p)]           # A_i (k x k)
    return {"B": B, "A": A, "Sigma": Sigma, "resid": E, "p": p, "k": k}


def var_select_p(Y: np.ndarray, max_p: int = 5) -> int:
    best = None
    for p in range(1, max_p + 1):
        f = var_fit(Y, p); n = len(f["resid"])
        bic = n * math.log(max(np.linalg.det(f["Sigma"]), 1e-300)) + f["k"] * (1 + p * f["k"]) * math.log(n)
        if best is None or bic < best[0]:
            best = (bic, p)
    return best[1]


def svar_irf(fit: dict, horizon: int = 10) -> tuple[np.ndarray, np.ndarray]:
    """Orthogonalized impulse responses (Cholesky, variable order = identification order) and FEVD at the horizon.
    Returns irf[h, i, j] = response of i at h to a one-SD structural shock j, and fevd[i, j] share."""
    k, p, A = fit["k"], fit["p"], fit["A"]
    P = np.linalg.cholesky(fit["Sigma"])
    Phi = [np.eye(k)]
    for h in range(1, horizon + 1):
        Phi.append(sum(A[i] @ Phi[h - i - 1] for i in range(min(p, h))))
    irf = np.array([Ph @ P for Ph in Phi])
    mse = np.sum(irf ** 2, axis=0)                                    # k x k contributions
    fevd = mse / mse.sum(axis=1, keepdims=True)
    return irf, fevd


def svar_table(returns: pd.DataFrame, order: list[str], horizon: int = 10) -> tuple[pd.DataFrame, dict]:
    R = returns[order].dropna()
    Y = R.to_numpy() * 100
    p = var_select_p(Y, 3)
    fit = var_fit(Y, p)
    irf, fevd = svar_irf(fit, horizon)
    cum = irf.cumsum(axis=0)
    rows = []
    for shock_idx, shock in enumerate(order[:2]):                     # responses to the first two structural shocks
        for i, v in enumerate(order):
            rows.append({"shock": shock, "variable": v, "h0": irf[0, i, shock_idx], "h1": irf[1, i, shock_idx], "h2": irf[2, i, shock_idx],
                         "cum_h5": cum[5, i, shock_idx], f"cum_h{horizon}": cum[horizon, i, shock_idx], f"fevd_share_h{horizon}_pct": fevd[i, shock_idx] * 100})
    return pd.DataFrame(rows), {"lags": p, "obs": len(Y), "order": order, "shock_sd_pct": [float(np.sqrt(fit["Sigma"][i, i])) for i in range(len(order))]}


# ----------------------------------------------------------------------------------------------
# Kalman filter: random-walk beta
# ----------------------------------------------------------------------------------------------
def kalman_beta(y: np.ndarray, x: np.ndarray) -> dict:
    """y_t = a + b_t x_t + e_t, b_t = b_{t-1} + eta_t. Signal-to-noise q = var(eta)/var(e) chosen by maximum likelihood on a grid."""
    y = np.asarray(y, float); x = np.asarray(x, float); n = len(y)
    X = np.column_stack([np.ones(n), x]); b0, *_ = np.linalg.lstsq(X, y, rcond=None)
    a = b0[0]; e0 = y - X @ b0; R = float(e0.var())
    def run(q):
        beta = b0[1]; P = R; ll = 0.0; path = np.empty(n); Q = q * R
        for t in range(n):
            P = P + Q
            F = x[t] ** 2 * P + R
            v = y[t] - a - beta * x[t]
            K = P * x[t] / F
            beta = beta + K * v; P = (1 - K * x[t]) * P
            ll += -0.5 * (math.log(2 * math.pi * F) + v ** 2 / F)
            path[t] = beta
        return ll, path
    best = None
    for q in np.logspace(-7, -2, 26):          # capped at 0.01 so the beta cannot re-fit itself to every day
        ll, path = run(q)
        if best is None or ll > best[0]:
            best = (ll, path, q)
    path = best[1]
    return {"beta_now": float(path[-1]), "beta_1y_ago": float(path[-min(n, TRADING_DAYS)]), "beta_min": float(path.min()), "beta_max": float(path.max()),
            "beta_ols": float(b0[1]), "q": float(best[2]), "path": path}


def kalman_table(returns: dict[str, pd.Series], factor: pd.Series, meta: dict, label: str) -> pd.DataFrame:
    rows = []
    for t, r in returns.items():
        df = pd.concat([r, factor], axis=1, join="inner").dropna()
        if len(df) < 250:
            continue
        kb = kalman_beta(df.iloc[:, 0].to_numpy(), df.iloc[:, 1].to_numpy())
        hac = ols_hac(df.iloc[:, 0].to_numpy(), np.column_stack([np.ones(len(df)), df.iloc[:, 1].to_numpy()]))
        rows.append({"country": meta[t][0], "kind": meta[t][1], "ticker": t, "factor": label, "beta_ols": kb["beta_ols"], "beta_ols_t_hac": hac["t"][1],
                     "beta_now": kb["beta_now"], "beta_1y_ago": kb["beta_1y_ago"], "beta_min": kb["beta_min"], "beta_max": kb["beta_max"],
                     "signal_to_noise_q": kb["q"], "hedge_ratio_now": kb["beta_now"]})
    return pd.DataFrame(rows)


# ----------------------------------------------------------------------------------------------
# Regimes: Markov-switching (2-state) and threshold autoregression
# ----------------------------------------------------------------------------------------------
def markov_switching(r: np.ndarray) -> dict:
    """`_markov_switching` through the disk fit cache (HO-20261024-C-B-005). Code in the key (SEC-C-014 R38): this
    module, layer3_regime (GaussianHMM) and garch (TRADING_DAYS)."""
    from ..ops import fitcache
    return fitcache.memo("markov_switching", {"r": np.asarray(r)}, {}, lambda: _markov_switching(r),
                         code=(__name__, f"{__package__}.layer3_regime", f"{__package__}.garch"))


def _markov_switching(r: np.ndarray) -> dict:
    from .layer3_regime import GaussianHMM
    X = np.asarray(r, float)[:, None]
    m = GaussianHMM(n_states=2, n_iter=300, seed=7).fit(X)
    # order states by variance (0 = calm, 1 = turbulent); GaussianHMM orders by mean, so reorder here
    order = np.argsort(m.var[:, 0]); mu = m.mu[order, 0]; var = m.var[order, 0]; A = m.A[np.ix_(order, order)]; pi = m.pi[order]
    # filtered probabilities
    n = len(X); logB = np.column_stack([stats.norm.logpdf(X[:, 0], mu[j], math.sqrt(var[j])) for j in range(2)])
    B = np.exp(logB - logB.max(axis=1, keepdims=True))
    alpha = pi * B[0]; alpha /= alpha.sum(); probs = np.empty(n); probs[0] = alpha[1]
    for t in range(1, n):
        alpha = (alpha @ A) * B[t]; alpha /= alpha.sum(); probs[t] = alpha[1]
    return {"vol_calm": math.sqrt(var[0]) * math.sqrt(TRADING_DAYS) * 100, "vol_turbulent": math.sqrt(var[1]) * math.sqrt(TRADING_DAYS) * 100,
            "mean_calm_ann": mu[0] * TRADING_DAYS * 100, "mean_turbulent_ann": mu[1] * TRADING_DAYS * 100,
            "p_stay_calm": float(A[0, 0]), "p_stay_turbulent": float(A[1, 1]), "expected_turbulent_days": 1 / max(1 - A[1, 1], 1e-9),
            "p_turbulent_now": float(probs[-1]), "share_turbulent": float((probs > 0.5).mean()), "loglik": m.loglik_}


def threshold_ar(r: np.ndarray) -> dict:
    """Two-regime TAR(1): r_t = c_j + phi_j r_{t-1} + e, regime by |r_{t-1}| above / below a threshold chosen on a grid (SSR)."""
    r = np.asarray(r, float); y = r[1:]; lag = r[:-1]; z = np.abs(lag)
    base = ols_hac(y, np.column_stack([np.ones(len(y)), lag])); ssr0 = base["resid"] @ base["resid"]
    best = None
    for thr in np.quantile(z, np.linspace(0.3, 0.9, 25)):
        hi = z > thr
        X = np.column_stack([~hi, lag * ~hi, hi, lag * hi]).astype(float)
        b, *_ = np.linalg.lstsq(X, y, rcond=None); e = y - X @ b; ssr = e @ e
        if best is None or ssr < best[0]:
            best = (ssr, thr, b, hi.mean())
    ssr, thr, b, share = best
    n = len(y); F = ((ssr0 - ssr) / 2) / (ssr / (n - 4))
    return {"threshold_abs_ret_pct": thr * 100, "phi_calm": b[1], "phi_turbulent": b[3], "share_turbulent": share, "ssr_reduction_pct": (1 - ssr / ssr0) * 100, "sup_f": F, "phi_linear": base["b"][1], "phi_linear_t_hac": base["t"][1]}


def regime_table(returns: dict[str, pd.Series], meta: dict) -> pd.DataFrame:
    rows = []
    for t, r in returns.items():
        ms = markov_switching(r.to_numpy()); tar = threshold_ar(r.to_numpy())
        if (r == 0).mean() > 0.2:                                   # pegged or stale quotes: the threshold model is not identified
            tar = {k: np.nan for k in tar}
        rows.append({"country": meta[t][0], "kind": meta[t][1], "ticker": t, "zero_return_share": float((r == 0).mean()), **{f"ms_{k}": v for k, v in ms.items() if k != "loglik"}, **{f"tar_{k}": v for k, v in tar.items()}})
    return pd.DataFrame(rows)


# ----------------------------------------------------------------------------------------------
# Risk premia: Fama-MacBeth and GMM
# ----------------------------------------------------------------------------------------------
def fama_macbeth(R: pd.DataFrame, F: pd.DataFrame, chars: pd.DataFrame | None = None) -> dict:
    """R: T x N excess returns, F: T x K factors, chars: N x C static characteristics. Two-pass with HAC t-stats; GMM
    (two-step, HAC weighting) estimate of the factor premia from the moment conditions of the linear factor model."""
    R = R.dropna(); F = F.loc[R.index]; T, N = R.shape; K = F.shape[1]
    X = np.column_stack([np.ones(T), F.to_numpy()])
    betas = np.array([np.linalg.lstsq(X, R[c].to_numpy(), rcond=None)[0][1:] for c in R.columns])      # N x K
    Z = betas if chars is None else np.column_stack([betas, chars.loc[R.columns].to_numpy()])
    names = list(F.columns) + ([] if chars is None else list(chars.columns))
    gammas = np.array([np.linalg.lstsq(np.column_stack([np.ones(N), Z]), R.iloc[t].to_numpy(), rcond=None)[0] for t in range(T)])   # T x (1+K+C)
    mean = gammas.mean(axis=0); se = np.array([math.sqrt(newey_west_var(gammas[:, j]) / T) for j in range(gammas.shape[1])])
    fm = pd.DataFrame({"premium_per_period": mean, "se_hac": se, "t": mean / se}, index=["intercept"] + names)
    # Shanken-free sanity: factor sample means
    fm["factor_mean"] = [np.nan] + [F[c].mean() for c in F.columns] + ([np.nan] * (0 if chars is None else chars.shape[1]))
    # GMM: moments g = [ (R_t - a - b F_t) (x) (1, F_t) ; R_t - b lambda ]  -> estimate lambda given first-stage b, with HAC-weighted second step
    Rm = R.to_numpy()
    def moments(lmb):
        return Rm - betas @ lmb                                      # T x N pricing errors
    def obj(lmb, W):
        g = moments(lmb).mean(axis=0); return g @ W @ g
    lmb0 = np.linalg.lstsq(betas, Rm.mean(axis=0), rcond=None)[0]
    g_t = moments(lmb0); S = np.zeros((N, N)); L = int(4 * (T / 100) ** (2 / 9)); gc = g_t - g_t.mean(axis=0)
    S = gc.T @ gc / T
    for l in range(1, L + 1):
        G = gc[l:].T @ gc[:-l] / T; S += (1 - l / (L + 1)) * (G + G.T)
    W = np.linalg.pinv(S + 1e-10 * np.eye(N))
    res = optimize.minimize(obj, lmb0, args=(W,), method="BFGS")
    lmb = res.x
    D = -betas                                                       # d g / d lambda
    V = np.linalg.pinv(D.T @ W @ D) / T
    gmm = pd.DataFrame({"premium_per_period": lmb, "se": np.sqrt(np.diag(V)), "t": lmb / np.sqrt(np.diag(V))}, index=list(F.columns))
    J = T * obj(lmb, W); jp = 1 - stats.chi2.cdf(J, N - K)
    return {"fm": fm, "gmm": gmm, "betas": pd.DataFrame(betas, index=R.columns, columns=F.columns), "J": J, "J_p": jp, "T": T, "N": N,
            "r2_cross_section": float(1 - np.var(Rm.mean(axis=0) - betas @ lmb) / np.var(Rm.mean(axis=0)))}


# ----------------------------------------------------------------------------------------------
# GARCH + EVT (peaks over threshold) and copulas
# ----------------------------------------------------------------------------------------------
def gpd_tail(z_loss: np.ndarray, u_q: float = 0.90) -> dict:
    z = np.asarray(z_loss, float); u = np.quantile(z, u_q); exc = z[z > u] - u
    if len(exc) < 20:
        return {"xi": np.nan, "beta": np.nan, "n_exc": len(exc)}
    xi, loc, beta = stats.genpareto.fit(exc, floc=0)
    n = len(z); nu = len(exc)
    def q(p):
        return u + beta / xi * ((n / nu * (1 - p)) ** (-xi) - 1) if abs(xi) > 1e-6 else u + beta * math.log(n / nu / (1 - p))
    def es(p):
        return (q(p) + beta - xi * u) / (1 - xi) if xi < 1 else np.nan
    return {"xi": float(xi), "beta": float(beta), "u": float(u), "n_exc": nu, "q99": q(0.99), "q999": q(0.999), "es99": es(0.99), "es999": es(0.999)}


def evt_table(fits: dict, series: pd.DataFrame) -> pd.DataFrame:
    rows = []
    for _, s in series.iterrows():
        f = fits[s["ticker"]]
        z_loss = s["loss_sign"] * f.std_resid
        g = gpd_tail(z_loss)
        s1 = math.sqrt(f.forecast_var(1)[0])
        if np.isnan(g["xi"]):
            continue
        rows.append({"country": s["country"], "kind": s["kind"], "ticker": s["ticker"], "threshold_u": g["u"], "exceedances": g["n_exc"], "gpd_xi": g["xi"], "gpd_beta": g["beta"],
                     "tail_index_1_over_xi": 1 / g["xi"] if g["xi"] > 0 else np.inf,
                     "var99_1d_evt_pct": g["q99"] * s1 * 100, "var99_1d_t_pct": t_quantile(0.99, f.nu) * s1 * 100,
                     "var999_1d_evt_pct": g["q999"] * s1 * 100, "var999_1d_t_pct": t_quantile(0.999, f.nu) * s1 * 100,
                     "es99_1d_evt_pct": g["es99"] * s1 * 100 if np.isfinite(g["es99"]) else np.nan, "es999_1d_evt_pct": g["es999"] * s1 * 100 if np.isfinite(g["es999"]) else np.nan,
                     "exposure_mm": s["exposure_mm"], "var999_10d_evt_mm": abs(s["exposure_mm"]) * g["q999"] * math.sqrt(f.cumulative_var(10)) if np.isfinite(g["q999"]) else np.nan})
    return pd.DataFrame(rows)


def _pseudo_obs(x: np.ndarray) -> np.ndarray:
    return (stats.rankdata(x) - 0.5) / len(x)


def t_copula_fit(u: np.ndarray, v: np.ndarray) -> dict:
    tau = stats.kendalltau(u, v)[0]; rho = math.sin(math.pi * tau / 2)
    def nll(nu):
        a = stats.t.ppf(u, nu); b = stats.t.ppf(v, nu)
        det = 1 - rho ** 2
        q = (a ** 2 - 2 * rho * a * b + b ** 2) / det
        ll = (math.lgamma((nu + 2) / 2) + math.lgamma(nu / 2) - 2 * math.lgamma((nu + 1) / 2) - 0.5 * math.log(det)
              - (nu + 2) / 2 * np.log1p(q / nu) + (nu + 1) / 2 * (np.log1p(a ** 2 / nu) + np.log1p(b ** 2 / nu)))
        return -float(ll.sum())
    grid = [2.5, 3, 4, 5, 6, 8, 10, 15, 20, 30, 50, 100]
    nu = min(grid, key=nll); ll = -nll(nu)
    lam = 2 * stats.t.cdf(-math.sqrt((nu + 1) * (1 - rho) / (1 + rho)), nu + 1)
    return {"rho": rho, "nu": nu, "lambda_lower": float(lam), "loglik": ll, "aic": -2 * ll + 4, "tau": tau}


def clayton_fit(u: np.ndarray, v: np.ndarray) -> dict:
    def nll(theta):
        th = theta[0]
        if th <= 0.01:
            return 1e10
        ll = (np.log(1 + th) - (1 + th) * (np.log(u) + np.log(v)) - (2 + 1 / th) * np.log(u ** (-th) + v ** (-th) - 1))
        return -float(ll.sum())
    res = optimize.minimize(nll, [1.0], method="Nelder-Mead")
    th = float(res.x[0]); ll = -res.fun
    return {"theta": th, "lambda_lower": 2 ** (-1 / th) if th > 0 else 0.0, "loglik": ll, "aic": -2 * ll + 2}


def copula_table(std: dict[str, pd.Series], pairs: list[tuple[str, str]], loss_sign: dict[str, float], meta: dict) -> pd.DataFrame:
    rows = []
    for a, b in pairs:
        df = pd.concat([std[a] * loss_sign[a], std[b] * loss_sign[b]], axis=1, join="inner").dropna()      # losses positive
        if len(df) < 250:
            continue
        u = _pseudo_obs(df.iloc[:, 0].to_numpy()); v = _pseudo_obs(df.iloc[:, 1].to_numpy())
        # survival (upper-tail-of-losses) dependence: fit copulas to 1-u, 1-v so lower tail = joint large losses
        uu, vv = 1 - u, 1 - v
        tc = t_copula_fit(uu, vv); cl = clayton_fit(uu, vv)
        emp = float(np.mean((uu < 0.05) & (vv < 0.05)) / 0.05)
        rows.append({"pair": f"{a} / {b}", "countries": f"{meta[a][0]} / {meta[b][0]}", "obs": len(df), "kendall_tau": tc["tau"], "t_rho": tc["rho"], "t_nu": tc["nu"], "t_lambda_joint_loss": tc["lambda_lower"],
                     "clayton_theta": cl["theta"], "clayton_lambda_joint_loss": cl["lambda_lower"], "empirical_lambda_5pct": emp,
                     "better_fit": "Student-t" if tc["aic"] < cl["aic"] else "Clayton", "aic_t": tc["aic"], "aic_clayton": cl["aic"]})
    return pd.DataFrame(rows)


# ----------------------------------------------------------------------------------------------
# Forecasting with many predictors
# ----------------------------------------------------------------------------------------------
def build_vol_panel(returns: dict[str, pd.Series], market: pd.Series, fx_basket: pd.Series, gpr_monthly: pd.Series | None, fits: dict, meta: dict, horizon: int = 21) -> pd.DataFrame:
    frames = []
    ann = math.sqrt(TRADING_DAYS) * 100
    for t, r in returns.items():
        df = pd.DataFrame({"r": r})
        df["rv5"] = np.log(r.rolling(5).std() * ann); df["rv21"] = np.log(r.rolling(21).std() * ann); df["rv63"] = np.log(r.rolling(63).std() * ann)
        df["garch_vol"] = np.log(pd.Series(np.sqrt(fits[t].sigma2), index=r.index) * ann)
        df["absr_mean21"] = r.abs().rolling(21).mean() * 100
        df["mom21"] = r.rolling(21).sum() * 100; df["mom63"] = r.rolling(63).sum() * 100
        if market is not None:                          # EQ-B-0077: no EEM on an FX-only price history
            df["mkt_rv21"] = np.log(market.reindex(r.index).rolling(21).std() * ann)
        df["fx_rv21"] = np.log(fx_basket.reindex(r.index).rolling(21).std() * ann)
        if market is not None:
            df["mkt_mom21"] = market.reindex(r.index).rolling(21).sum() * 100
        if gpr_monthly is not None:
            g = gpr_monthly.copy(); g.index = pd.to_datetime(g.index)
            dg = np.log(g).diff().reindex(r.index, method="ffill")
            df["gpr_chg"] = dg.shift(1)
        df["is_fx"] = 1.0 if meta[t][1] == "FX" else 0.0
        df["target"] = np.log(r[::-1].rolling(horizon).std()[::-1].shift(-1) * ann)      # realized vol over the next `horizon` days
        df["ticker"] = t
        frames.append(df)
    return pd.concat(frames).replace([np.inf, -np.inf], np.nan).dropna()


def forecast_comparison(panel: pd.DataFrame, split_date: str) -> tuple[pd.DataFrame, pd.DataFrame]:
    feats = [c for c in panel.columns if c not in ("r", "target", "ticker")]
    tr = panel[panel.index < split_date]; te = panel[panel.index >= split_date]
    Xtr, ytr, Xte, yte = tr[feats].to_numpy(), tr["target"].to_numpy(), te[feats].to_numpy(), te["target"].to_numpy()
    mu, sd = Xtr.mean(axis=0), Xtr.std(axis=0) + 1e-12
    Ztr, Zte = (Xtr - mu) / sd, (Xte - mu) / sd
    rows = []; imp = {}
    def score(name, pred_tr, pred_te, k):
        rows.append({"model": name, "n_train": len(ytr), "n_test": len(yte), "features": k, "r2_in_sample": 1 - np.mean((ytr - pred_tr) ** 2) / np.var(ytr),
                     "r2_out_of_sample": 1 - np.mean((yte - pred_te) ** 2) / np.var(yte), "rmse_oos_log_vol": math.sqrt(np.mean((yte - pred_te) ** 2))})
    # benchmarks
    score("Naive: last 21-day realized vol", tr["rv21"].to_numpy(), te["rv21"].to_numpy(), 1)
    score("GARCH conditional vol only", tr["garch_vol"].to_numpy(), te["garch_vol"].to_numpy(), 1)
    Xo_tr = np.column_stack([np.ones(len(Ztr)), Ztr]); Xo_te = np.column_stack([np.ones(len(Zte)), Zte])
    b = np.linalg.lstsq(Xo_tr, ytr, rcond=None)[0]; score("OLS, all predictors", Xo_tr @ b, Xo_te @ b, len(feats))
    if HAVE_SKLEARN:
        rg = RidgeCV(alphas=np.logspace(-3, 3, 25)).fit(Ztr, ytr); score(f"Ridge (alpha {rg.alpha_:.3g})", rg.predict(Ztr), rg.predict(Zte), len(feats))
        la = LassoCV(cv=5, random_state=0, max_iter=20000).fit(Ztr, ytr); nz = int((la.coef_ != 0).sum()); score(f"Lasso ({nz} kept)", la.predict(Ztr), la.predict(Zte), nz)
        imp["lasso"] = pd.Series(la.coef_, index=feats)
        pca = PCA(n_components=3).fit(Ztr); Ftr, Fte = pca.transform(Ztr), pca.transform(Zte)
        lr = LinearRegression().fit(Ftr, ytr); score("PCA factor model (3 factors)", lr.predict(Ftr), lr.predict(Fte), 3)
        imp["pca_explained_pct"] = pd.Series(pca.explained_variance_ratio_ * 100, index=["F1", "F2", "F3"])
        rf = RandomForestRegressor(n_estimators=200, min_samples_leaf=20, max_features=0.5, random_state=0, n_jobs=-1).fit(Xtr, ytr)
        score("Random forest (200 trees)", rf.predict(Xtr), rf.predict(Xte), len(feats))
        imp["random_forest"] = pd.Series(rf.feature_importances_, index=feats)
    out = pd.DataFrame(rows)
    imp_df = pd.DataFrame(imp.get("lasso", pd.Series(dtype=float)), columns=["lasso_coef"]).join(pd.DataFrame(imp.get("random_forest", pd.Series(dtype=float)), columns=["rf_importance"]), how="outer")
    return out, imp_df


# ----------------------------------------------------------------------------------------------
# Event study: equity ETF around currency shocks
# ----------------------------------------------------------------------------------------------
def event_study(etf_ret: pd.Series, fx_ret: pd.Series, market: pd.Series, k_sigma: float = 3.0, est_window=(250, 21), windows=((0, 0), (0, 1), (0, 5), (0, 20))) -> dict:
    df = pd.concat([etf_ret.rename("etf"), fx_ret.rename("fx"), market.rename("mkt")], axis=1).dropna()
    scale = 1.4826 * np.median(np.abs(df["fx"] - df["fx"].median()))
    events = df.index[df["fx"] > k_sigma * scale]                       # depreciation shocks
    # keep events at least 21 days apart
    kept = []
    for d in events:
        if not kept or (df.index.get_loc(d) - df.index.get_loc(kept[-1])) > 21:
            kept.append(d)
    cars = {w: [] for w in windows}
    for d in kept:
        i = df.index.get_loc(d)
        if i - est_window[0] < 0 or i + 20 >= len(df):
            continue
        est = df.iloc[i - est_window[0]: i - est_window[1]]
        X = np.column_stack([np.ones(len(est)), est["mkt"]]); b = np.linalg.lstsq(X, est["etf"], rcond=None)[0]
        ar = df["etf"] - (b[0] + b[1] * df["mkt"])
        for w in windows:
            cars[w].append(float(ar.iloc[i + w[0]: i + w[1] + 1].sum()))
    out = {"n_events": len(cars[windows[0]]), "fx_threshold_pct": k_sigma * scale * 100}
    for w in windows:
        v = np.array(cars[w])
        out[f"car_{w[0]}_{w[1]}_pct"] = v.mean() * 100 if len(v) else np.nan
        out[f"t_{w[0]}_{w[1]}"] = v.mean() / (v.std(ddof=1) / math.sqrt(len(v))) if len(v) > 2 and v.std() > 0 else np.nan
    return out


# ----------------------------------------------------------------------------------------------
# Orchestration
# ----------------------------------------------------------------------------------------------
@dataclass
class EconometricsResult:
    workflow: pd.DataFrame
    cointegration: pd.DataFrame
    svar: pd.DataFrame
    svar_meta: dict
    kalman: pd.DataFrame
    regimes: pd.DataFrame
    premia_fm: pd.DataFrame
    premia_gmm: pd.DataFrame
    premia_meta: dict
    evt: pd.DataFrame
    copulas: pd.DataFrame
    forecasts: pd.DataFrame
    forecast_importance: pd.DataFrame
    events: pd.DataFrame
    as_of: str
    notes: dict = field(default_factory=dict)


def run_econometrics(u, prices: pd.DataFrame, garch_result, settings=None, gpr: pd.DataFrame | None = None, composite: pd.Series | None = None, log=print) -> EconometricsResult:
    """composite: optional Randori composite score per country (used as a characteristic in the Fama-MacBeth second pass)."""
    prices = prices.copy(); prices.index = pd.to_datetime(prices.index)
    prices, removed = clean_bad_ticks(prices.sort_index()); prices = _business_daily(prices)
    series = garch_result.series
    meta = {s["ticker"]: (s["country"], s["kind"]) for _, s in series.iterrows()}
    loss_sign = {s["ticker"]: s["loss_sign"] for _, s in series.iterrows()}
    cty = u.countries.set_index("country")
    rets = {t: _returns(prices[t]) for t in meta if t in prices.columns}
    fits = {t: garch11_fit(r) for t, r in rets.items()}
    std = {t: pd.Series(f.std_resid, index=rets[t].index) for t, f in fits.items()}
    market = _returns(prices["EEM"]) if "EEM" in prices.columns else None
    liquid = [t for t in ("USDJPY", "USDKRW", "USDINR", "USDBRL", "USDCOP", "USDMYR", "USDPHP", "USDSGD") if t in rets]
    fx_basket = pd.concat([rets[t] for t in liquid], axis=1).mean(axis=1)
    # EQ-B-0077: tables that need EEM or the country ETFs are skipped, with the reason, on an FX-only price history
    all_etf = [t for t, m in meta.items() if m[1] == "Equity"]
    etfs = [t for t in all_etf if t in rets]
    no_mkt = "no EEM column in prices.csv (FX-only price history, EQ-B-0077)" if market is None else ""
    no_etf = "no country ETF series in prices.csv (FX-only price history, EQ-B-0077)" if not etfs else ""
    skipped = {}
    if no_mkt:
        skipped.update({"svar": no_mkt, "kalman_equity": no_mkt, "event_study": no_mkt, "forecast_market_predictors": no_mkt})
    if no_mkt or no_etf:
        skipped["premia"] = no_mkt or no_etf
    if no_etf:
        skipped.update({"copula_equity_pairs": no_etf, "event_study": skipped.get("event_study") or no_etf})
    if skipped:
        log(f"[econ] skipped (EQ-B-0077): {', '.join(sorted(skipped))}: {no_mkt or no_etf}")
        warnings.warn(f"econometrics: {no_mkt or no_etf}; skipped {sorted(skipped)}", RuntimeWarning, stacklevel=2)

    log("[econ] workflow table (stationarity, AR + GARCH, residual checks, out-of-sample race)")
    wf = workflow_table(rets, prices, meta)

    log("[econ] cointegration")
    groups = {}
    for region, g in cty.groupby("region"):
        fx = [f"USD{c}" for c in g["currency"] if f"USD{c}" in prices.columns]
        et = [e for e in g["etf"].dropna().astype(str) if e in prices.columns]
        if len(fx) > 1:
            groups[f"FX {region}"] = fx
        if len(et) > 1:
            groups[f"Equity {region}"] = et
    groups["Equity all"] = all_etf
    nonstat = set(wf.loc[wf["adf_price_p"] > 0.05, "ticker"])
    coint = cointegration_table(prices, groups, nonstat).drop_duplicates(subset=["y", "x"])

    log("[econ] SVAR")
    if no_mkt:
        order = []
        svar_df, svar_meta = pd.DataFrame(), {"skipped": no_mkt}
    else:
        order = [c for c in ["EEM"] + liquid[:4] + [e for e in ("MCHI", "EWY", "EWZ", "INDA") if e in rets] if c in rets or c == "EEM"]
        R = pd.concat({**{"EEM": market}, **{t: rets[t] for t in order if t != "EEM"}}, axis=1).dropna()
        # FX in the VAR as depreciation (positive = local currency weaker), equities as returns
        svar_df, svar_meta = svar_table(R, order)

    log("[econ] Kalman betas")
    kal_fx = kalman_table({t: r for t, r in rets.items() if meta[t][1] == "FX"}, fx_basket, meta, "USD vs EM FX basket")
    kal = kal_fx.reset_index(drop=True) if no_mkt else pd.concat(
        [kalman_table({t: r for t, r in rets.items() if meta[t][1] == "Equity"}, market, meta, "EEM"), kal_fx], ignore_index=True)

    log("[econ] regimes")
    reg = regime_table(rets, meta)

    log("[econ] risk premia")
    rf = (settings.raw.get("garch", {}).get("risk_free", 0.04) if settings is not None else 0.04)
    wk = lambda s: (1 + s).resample("W-FRI").prod() - 1  # noqa: E731
    if "premia" in skipped:
        prem = {"fm": pd.DataFrame(), "gmm": pd.DataFrame(), "skipped": skipped["premia"]}
    else:
        Rw = pd.concat({t: wk(rets[t]) for t in etfs}, axis=1) - rf / 52
        Fw = pd.DataFrame({"EM market (EEM)": wk(market) - rf / 52, "USD vs EM FX": wk(fx_basket)})
        comp = garch_result.series.set_index("ticker")["country"].to_dict()
        chars = None
        if composite is not None:
            ch = pd.DataFrame({"Randori composite / 10": [float(composite.get(comp[t], np.nan)) / 10 for t in etfs]}, index=etfs)
            chars = ch if ch.notna().all().all() else None
        prem = fama_macbeth(Rw, Fw, chars)

    log("[econ] EVT and copulas")
    evt = evt_table(fits, series)
    top = []
    if etfs:
        corr_eq = pd.concat([std[t] for t in etfs], axis=1, keys=etfs).corr()
        pairs = []
        for i, a in enumerate(etfs):
            for b in etfs[i + 1:]:
                pairs.append((corr_eq.loc[a, b], a, b))
        top = [(a, b) for _, a, b in sorted(pairs, reverse=True)[:8]]
    fx_pairs = [(a, b) for a, b in (("USDKRW", "USDJPY"), ("USDSGD", "USDJPY"), ("USDBRL", "USDCOP"), ("USDINR", "USDPHP"), ("USDCNY", "USDMYR")) if a in std and b in std]
    cop = copula_table(std, top + fx_pairs, loss_sign, meta)

    log("[econ] forecasts with many predictors")
    gpr_m = None
    if gpr is not None and "GPR" in gpr.columns:
        gm = gpr.set_index(pd.PeriodIndex(gpr["month"], freq="M").to_timestamp(how="end").normalize())["GPR"]
        gpr_m = pd.to_numeric(gm, errors="coerce")
    panel = build_vol_panel(rets, market, fx_basket, gpr_m, fits, meta)
    split = (panel.index.max() - pd.Timedelta(days=270)).strftime("%Y-%m-%d")
    fc, imp = forecast_comparison(panel, split)

    log("[econ] event study")
    ev_rows = []
    for country, row in cty.iterrows():
        fxt = f"USD{row['currency']}"; etf = str(row["etf"]) if pd.notna(row["etf"]) else ""
        if fxt in rets and etf in rets and market is not None:
            e = event_study(rets[etf], rets[fxt], market)
            ev_rows.append({"country": country, "etf": etf, "fx": fxt, **e})
    events = pd.DataFrame(ev_rows)
    return EconometricsResult(wf, coint, svar_df, svar_meta, kal, reg, prem["fm"], prem["gmm"], {k: v for k, v in prem.items() if k not in ("fm", "gmm", "betas")},
                              evt, cop, fc, imp, events, prices.index.max().date().isoformat(),
                              notes={"forecast_split": split, "bad_ticks_removed": removed, "fx_basket": liquid, "svar_order": order,
                                     "skipped": skipped})
