"""Universe tier lookup (EQ-B-0055): the one reader of data/panel/universe_proposal.csv used by the engine.

Layer 3's `regime.global_set` (country name -> iso3, tier) and the stress `tier_*` clauses (ISO3 -> tier,
`stress.country_tiers`) both read the proposal through `proposal_tiers`, so they see the same file the same way:
every cell a stripped string (blank = '', Namibia's ISO2 'NA' kept), read once per (path, modification time).
"""
from __future__ import annotations

from pathlib import Path

import pandas as pd

TIERS = ("desk_current", "EM", "frontier", "DM_anchor")      # universe_proposal.csv buckets (EQ-A-0025)
_CACHE: dict = {}


def _read(path: Path) -> pd.DataFrame:
    p = Path(path)
    key = (str(p), p.stat().st_mtime_ns if p.is_file() else None)
    if key not in _CACHE:
        if key[1] is None:
            raise FileNotFoundError(f"universe proposal not found: {p}")
        from ..ingestion.universe import load_universe_proposal
        if len(_CACHE) >= 8:
            _CACHE.clear()
        _CACHE[key] = load_universe_proposal(p)
    return _CACHE[key]


def proposal_tiers(path, by: str = "iso3", missing_ok: bool = False) -> pd.DataFrame:
    """The proposal indexed by `by` ("iso3" or "name"), file order kept: columns tier (by iso3) or iso3, tier (by
    name). Blank cells stay ''. A missing file or column raises (FileNotFoundError / KeyError) unless `missing_ok`,
    which returns an empty frame instead."""
    if by not in ("iso3", "name"):
        raise ValueError(f"by must be 'iso3' or 'name', got {by!r}")
    cols = ["tier"] if by == "iso3" else ["iso3", "tier"]
    try:
        df = _read(path)
        missing = sorted({by, *cols} - set(df.columns))
        if missing:
            raise KeyError(f"universe proposal {path} has no column(s) {missing}")
    except (FileNotFoundError, KeyError):
        if not missing_ok:
            raise
        df = pd.DataFrame(columns=[by, *cols])
    return df.set_index(by)[cols]


def tier_by_iso(path) -> dict:
    """{iso3: tier} for rows with both set (the stress `tier_*` fallback); {} when the file or the columns are missing."""
    t = proposal_tiers(path, by="iso3", missing_ok=True)
    return {i: v for i, v in zip(t.index, t["tier"]) if i and v}


def tier_by_name(path) -> pd.DataFrame:
    """name -> (iso3, tier) for Layer 3's `regime.global_set`; raises when the file is missing."""
    return proposal_tiers(path, by="name")[["iso3", "tier"]]
