"""Shadow sovereign ratings: model-implied rating per country against the agency rating (EQ-B-0081).

Read-only analytics for the country notes. Nothing here feeds a PD, a loss or a limit.

1. PD-implied rating. The 1-year PD (`pd_default`, the PD the Monte Carlo uses, and `pd_model`, the posterior
   before the prediction-market prior; both regime-adjusted) is mapped to the rating scale through the same
   PD-by-rating table the model uses (`settings["ratings_pd"]`, read by layer 1's RatingChallenger). Notch
   boundaries are geometric midpoints of adjacent table PDs: the boundary between notch k and k+1 is
   sqrt(pd_k * pd_k+1). A PD exactly on a boundary takes the worse notch. D duplicates SD in the table
   (both 0.60), so D is dropped and the scale is AAA ... CC, SD (21 notches). A shadow "SD" means a PD at
   default level, not a default event. `pd_hazard_l1` (the hazard alone) is shown too, for information.
   Circularity: pd_model is reconciled 50/50 in log-odds with the rating-implied PD (layer1.hazard_weight)
   and the hazard is calibrated to the rating prior, so the agency rating is partly inside the shadow PD and
   gaps are damped. A 2-notch gap is therefore a strong disagreement, not a weak one.
2. Scorecard-implied rating. Ordinary least squares of the agency notch on the composite score across the desk
   names not rated SD/D (16 of 18 today), predicted leave-one-out (each name's rating is fitted without that
   name), rounded and clipped to AAA ... CC. Two parameters on about 16 points: the fit is a rough ordering
   device; the leave-one-out RMSE in notches is reported with it and should be read before any single name.
3. Gap and flags. gap_notches = shadow notch - agency notch; positive means the shadow rating is worse
   (lower) than the agency rating. gap >= 2: "downgrade_risk"; gap <= -2: "upgrade_candidate".
   Momentum: shadow notch now minus shadow notch in the earliest archived base run inside the look-back
   window (as_of in [D - lookback_days, D]); >= +1 "momentum_down", <= -1 "momentum_up". Archived runs come
   from outputs/store/archive/*-base.json and only runs with as_of <= D are read (validation/monitoring.py
   load_archive; runs without an as_of fall back to their creation date, which is never later than the data).
4. Migration. Count matrices of shadow ratings between consecutive archived runs, and between the last run of
   each distinct as_of date. With a handful of runs over a few days these are code and data revisions, not
   rating migrations; the counts are labelled with the number of runs and dates. A reference long-run agency
   1-year transition matrix (REFERENCE_TRANSITION) is a judgement table, approximate, see its docstring.

Settings (all optional, read with defaults; no assumptions.json key is needed):
shadow_ratings.gap_notches (2), shadow_ratings.momentum_notches (1), shadow_ratings.lookback_days (90).

CLI: `python -m econquest.engine.shadow_ratings --as-of D` writes outputs/shadow_ratings.csv and .md, and the
country-note extract outputs/shadow_rating.csv (NOTE_COLUMNS, HO-20261024-C-B-004 / EQ-C-0082).
"""
from __future__ import annotations
import argparse
import math
from pathlib import Path
import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
OUTPUTS = ROOT / "outputs"            # the CLI writes only under here (--out is checked)
ARCHIVE = OUTPUTS / "store" / "archive"

DEFAULT_GAP, DEFAULT_MOMENTUM, DEFAULT_LOOKBACK = 2, 1, 90
DEFAULT_RATINGS = ("SD", "D")

# Output contract for Team C country notes (column -> meaning). Order is the CSV column order.
COLUMNS = {
    "as_of": "as_of of the run the table is built from (YYYY-MM-DD)",
    "run_id": "archived run id the PDs come from",
    "country": "country name as in the universe",
    "iso": "ISO3 code",
    "agency_rating": "agency rating in the Country Profile (S&P scale)",
    "agency_notch": "agency notch index, 0 = AAA ... 19 = CC, 20 = SD/D",
    "pd_default": "1-year PD used by the Monte Carlo",
    "shadow_rating": "rating implied by pd_default through ratings_pd geometric-midpoint boundaries",
    "shadow_notch": "notch index of shadow_rating",
    "gap_notches": "shadow_notch - agency_notch; positive = shadow worse than agency",
    "pd_model": "1-year posterior PD before the prediction-market prior",
    "shadow_rating_model": "rating implied by pd_model",
    "gap_notches_model": "shadow notch from pd_model - agency_notch",
    "pd_hazard_l1": "layer 1 hazard PD alone (information only)",
    "shadow_rating_hazard": "rating implied by pd_hazard_l1",
    "composite": "scorecard composite (0-100, higher riskier)",
    "scorecard_rating": "leave-one-out OLS rating from the composite (rough, small n)",
    "gap_notches_scorecard": "scorecard notch - agency_notch",
    "flag": "downgrade_risk | upgrade_candidate | none (from gap_notches)",
    "flag_confirmed_by_pd_model": "True when gap_notches_model passes the same threshold in the same direction",
    "momentum_notches": "shadow notch now - shadow notch in the earliest archived run in the look-back window",
    "momentum_flag": "momentum_down | momentum_up | none",
    "momentum_runs": "archived base runs in the look-back window (as_of <= D)",
    "momentum_from_run": "run id the momentum is measured from",
    "momentum_cause": "what differs between that run and this one: none, or settings/data/code (+-joined); a move with code or settings changed is a model revision, not news",
    "agency_in_default": "True when the agency rating is SD or D",
    "note": "plain-language note for the country page",
}

# Country-note extract (HO-20261024-C-B-004): outputs/shadow_rating.csv, read by presentation/note_v2.shadow_html.
# notch_gap = gap_notches (shadow notch - agency notch on pd_default; positive = shadow worse). Blank when either
# rating is unknown.
NOTE_FILE = "shadow_rating.csv"
NOTE_COLUMNS = ("country", "iso", "as_of", "shadow_rating", "agency_rating", "notch_gap", "run_id")


# ----------------------------------------------------------------------------------------------- the scale

def rating_scale(ratings_pd: dict) -> tuple[list[str], np.ndarray, np.ndarray]:
    """(labels, pds, upper_bounds) of the shadow scale from the model's PD-by-rating table.

    Ratings are ordered by PD; a rating whose PD equals the previous one (D after SD) is dropped. Upper bound of
    notch k is the geometric midpoint sqrt(pd_k * pd_k+1); the last notch is open-ended (inf)."""
    items = sorted(((str(k).strip(), float(v)) for k, v in ratings_pd.items()), key=lambda kv: kv[1])
    labels, pds = [], []
    for k, v in items:
        if not (np.isfinite(v) and v > 0):
            raise ValueError(f"ratings_pd[{k!r}] must be a positive PD, got {v}")
        if pds and v <= pds[-1]:
            continue           # tie (D = SD): keep the first, which is the label the scale shows
        labels.append(k); pds.append(v)
    pds = np.array(pds)
    upper = np.append(np.sqrt(pds[:-1] * pds[1:]), np.inf)
    return labels, pds, upper


def boundaries_table(ratings_pd: dict) -> pd.DataFrame:
    """The documented notch boundaries: rating, table PD, lower and upper PD bound of the shadow notch."""
    labels, pds, upper = rating_scale(ratings_pd)
    lower = np.insert(upper[:-1], 0, 0.0)
    return pd.DataFrame({"notch": range(len(labels)), "rating": labels, "table_pd": pds, "pd_from": lower, "pd_below": upper})


def pd_to_notch(pd_values, ratings_pd: dict) -> np.ndarray:
    """Notch index for each PD (NaN for a missing PD). A PD on a boundary goes to the worse notch."""
    _, _, upper = rating_scale(ratings_pd)
    p = np.asarray(pd_values, dtype=float)
    out = np.searchsorted(upper, p, side="right").astype(float)
    out[~np.isfinite(p)] = np.nan
    return out


def notch_label(notch, ratings_pd: dict) -> list:
    labels, _, _ = rating_scale(ratings_pd)
    return [labels[int(n)] if n is not None and np.isfinite(n) else None for n in np.atleast_1d(np.asarray(notch, dtype=float))]


def agency_notch(ratings, ratings_pd: dict) -> np.ndarray:
    """Notch of an agency rating on the same scale; D maps to the SD notch; unknown ratings give NaN."""
    labels, _, _ = rating_scale(ratings_pd)
    idx = {r: i for i, r in enumerate(labels)}
    table = {str(k).strip(): float(v) for k, v in ratings_pd.items()}
    out = []
    for r in ratings:
        r = str(r).strip()
        if r in idx:
            out.append(float(idx[r]))
        elif r in table:   # a dropped tie (D): the notch of the kept label with the same PD
            out.append(float(next(i for i, lab in enumerate(labels) if table[lab] == table[r])))
        else:
            out.append(np.nan)
    return np.array(out)


# ----------------------------------------------------------------------------------------------- scorecard

def scorecard_implied(composite: pd.Series, agency: pd.Series, ratings_pd: dict,
                      exclude=DEFAULT_RATINGS) -> tuple[pd.Series, dict]:
    """Leave-one-out OLS of agency notch on composite; returns (notch per country, fit summary).

    Names rated SD/D are left out of the fit (their composite carries override floors and their rating is an
    event, not a credit grade) and are predicted from the fit on the others."""
    labels, _, _ = rating_scale(ratings_pd)
    top = labels.index("SD") - 1 if "SD" in labels else len(labels) - 1
    y_all = pd.Series(agency_notch(agency, ratings_pd), index=agency.index)
    x_all = composite.reindex(agency.index).astype(float)
    keep = (~agency.astype(str).str.strip().isin(exclude)) & y_all.notna() & x_all.notna()
    x, y = x_all[keep].to_numpy(), y_all[keep].to_numpy()
    n = len(x)
    out = pd.Series(np.nan, index=agency.index)
    info = {"n": int(n), "method": "OLS agency notch ~ composite, leave-one-out, SD/D names excluded from the fit"}
    if n < 4 or np.ptp(x) == 0:
        info["reason"] = f"too few names to fit ({n})"
        return out, info
    b, a = np.polyfit(x, y, 1)
    if b <= 0:
        info.update(slope=float(b), intercept=float(a), reason="slope not positive: composite does not order the ratings")
        return out, info
    names = list(x_all[keep].index)
    loo = []
    for i, c in enumerate(names):
        m = np.ones(n, dtype=bool); m[i] = False
        bi, ai = np.polyfit(x[m], y[m], 1)
        loo.append(ai + bi * x[i]); out[c] = ai + bi * x[i]
    for c in x_all.index[~keep & x_all.notna()]:
        out[c] = a + b * x_all[c]
    resid = y - a - b * x
    loo_resid = y - np.array(loo)
    info.update(slope=float(b), intercept=float(a), r2=float(1 - resid.var() / y.var()) if y.var() > 0 else float("nan"),
                rmse_in_sample=float(np.sqrt(np.mean(resid ** 2))), rmse_loo=float(np.sqrt(np.mean(loo_resid ** 2))))
    return out.round().clip(0, top), info


# ----------------------------------------------------------------------------------------------- archive

def load_runs(archive_dir=ARCHIVE, as_of=None, label: str = "base") -> list[dict]:
    """Archived runs with this label, as_of <= `as_of` only (no look-ahead); runs with no date dropped.

    Ordered by (as_of, created_at, run_id), oldest as_of first (EQ-B-0081 review): a run created later for an
    earlier as_of (a back-fill) sorts before the runs of later dates, so "latest run", momentum's earliest run
    and the migration sequence follow the data date, not the creation time."""
    from ..validation.monitoring import load_archive
    if as_of is None:
        raise ValueError("as_of is required: shadow ratings never read runs dated after the as-of date")
    cut = pd.Timestamp(as_of).strftime("%Y-%m-%d")
    runs = load_archive(archive_dir, label=label, as_of=cut)
    runs = [r for r in runs if r.get("as_of") and str(r["as_of"])[:10] <= cut]
    return sorted(runs, key=_run_order)


def _run_order(r: dict) -> tuple:
    return (str(r.get("as_of") or "")[:10], str(r.get("created_at") or ""), str(r.get("run_id") or ""))


def _run_table(run: dict) -> pd.DataFrame:
    return pd.DataFrame.from_dict(run["country"], orient="index")


def _shadow_series(run: dict, ratings_pd: dict, col: str = "pd_default") -> pd.Series:
    t = _run_table(run)
    if col not in t:
        return pd.Series(dtype=float)
    return pd.Series(pd_to_notch(t[col].astype(float), ratings_pd), index=t.index)


# ----------------------------------------------------------------------------------------------- main table

def shadow_ratings(country: pd.DataFrame, ratings_pd: dict, runs: list[dict] | None = None, as_of=None,
                   settings=None, run_id: str | None = None, run_as_of=None) -> tuple[pd.DataFrame, dict]:
    """Shadow-rating table, one row per country, columns as in COLUMNS; and a dict of fit and window details.

    `country` is the pipeline country table (index = country; needs rating, pd_default, pd_model, composite; iso,
    pd_hazard_l1 optional). `runs` are archived run records (load_runs) already cut at as_of; only runs with
    as_of <= `as_of` are used for momentum, whatever is passed, in as_of order. The `as_of` column is
    `run_as_of` (the as_of of the run the table comes from) when given, else `as_of`."""
    def setting(key, default):
        return settings.get("shadow_ratings", key, default=default) if settings is not None else default
    gap_n = int(setting("gap_notches", DEFAULT_GAP))
    mom_n = int(setting("momentum_notches", DEFAULT_MOMENTUM))
    look = int(setting("lookback_days", DEFAULT_LOOKBACK))
    if as_of is None:
        raise ValueError("as_of is required")
    D = pd.Timestamp(as_of).normalize()
    c = country.copy()
    t = pd.DataFrame(index=c.index)
    t["as_of"] = (pd.Timestamp(str(run_as_of)[:10]) if run_as_of else D).strftime("%Y-%m-%d")
    t["run_id"] = run_id
    t["country"] = c.index
    t["iso"] = c["iso"] if "iso" in c else None
    t["agency_rating"] = c["rating"].astype(str).str.strip()
    t["agency_notch"] = agency_notch(t["agency_rating"], ratings_pd)
    for src, sfx in (("pd_default", ""), ("pd_model", "_model"), ("pd_hazard_l1", "_hazard")):
        if src not in c:
            t[src] = np.nan; t["shadow_rating" + sfx] = None
            continue
        t[src] = c[src].astype(float)
        n = pd_to_notch(t[src], ratings_pd)
        t["shadow_rating" + sfx] = notch_label(n, ratings_pd)
        if sfx == "":
            t["shadow_notch"] = n
            t["gap_notches"] = n - t["agency_notch"]
        elif sfx == "_model":
            t["gap_notches_model"] = n - t["agency_notch"]
    t["composite"] = c["composite"].astype(float) if "composite" in c else np.nan
    sc_notch, sc_info = scorecard_implied(t["composite"], t["agency_rating"], ratings_pd)
    t["scorecard_rating"] = notch_label(sc_notch, ratings_pd)
    t["gap_notches_scorecard"] = sc_notch - t["agency_notch"]
    g, gm = t["gap_notches"], t.get("gap_notches_model", pd.Series(np.nan, index=t.index))
    in_default = t["agency_rating"].isin(DEFAULT_RATINGS)
    t["flag"] = np.where(g >= gap_n, "downgrade_risk", np.where(g <= -gap_n, "upgrade_candidate", "none"))
    t["flag_confirmed_by_pd_model"] = ((g >= gap_n) & (gm >= gap_n)) | ((g <= -gap_n) & (gm <= -gap_n))
    # an SD/D name is a default event: a falling PD is not an upgrade call (EQ-B-0081 review)
    t.loc[in_default, "flag"] = "none"
    t.loc[in_default, "flag_confirmed_by_pd_model"] = False
    # momentum from archived runs, never later than D
    window = sorted((r for r in (runs or []) if r.get("as_of") and pd.Timestamp(str(r["as_of"])[:10]) <= D
                     and pd.Timestamp(str(r["as_of"])[:10]) >= D - pd.Timedelta(days=look)), key=_run_order)
    t["momentum_runs"] = len(window)
    if window:
        first = window[0]
        s0 = _shadow_series(first, ratings_pd).reindex(t.index)
        t["momentum_notches"] = t["shadow_notch"] - s0
        t["momentum_from_run"] = first.get("run_id")
        cur = next((r for r in reversed(window) if r.get("run_id") == run_id), None)
        t["momentum_cause"] = _cause_of(first, cur) if cur is not None else "unknown (current table is not an archived run)"
    else:
        t["momentum_notches"] = np.nan
        t["momentum_from_run"] = None
        t["momentum_cause"] = None
    m = t["momentum_notches"]
    t["momentum_flag"] = np.where(m >= mom_n, "momentum_down", np.where(m <= -mom_n, "momentum_up", "none"))
    t["agency_in_default"] = in_default
    t["note"] = [_note(r, gap_n) for _, r in t.iterrows()]
    info = {"scorecard_fit": sc_info, "gap_notches": gap_n, "momentum_notches": mom_n, "lookback_days": look,
            "momentum_window_runs": [r.get("run_id") for r in window],
            "boundaries": boundaries_table(ratings_pd)}
    return t.reindex(columns=list(COLUMNS)).reset_index(drop=True), info


def _cause_of(a: dict, b: dict) -> str:
    """'none' or the +-joined parts (settings, data, code) whose hashes differ between two archived runs."""
    from ..validation.monitoring import _cause
    return _cause(a, b)["changed"]


def _note(r, gap_n: int) -> str:
    if pd.isna(r["agency_notch"]):
        return f"agency rating {r['agency_rating']} is not on the ratings_pd scale; no gap"
    if pd.isna(r["gap_notches"]):
        return "no PD; no shadow rating"
    g = int(r["gap_notches"])
    base = f"model PD implies {r['shadow_rating']} vs agency {r['agency_rating']} ({g:+d} notches)"
    if r["agency_in_default"]:
        return base + "; agency rating is a default event, the gap is not a credit view"
    if r["flag"] == "downgrade_risk":
        base += f"; at least {gap_n} notches weaker than the agency"
    elif r["flag"] == "upgrade_candidate":
        base += f"; at least {gap_n} notches stronger than the agency"
    if r["momentum_flag"] != "none":
        base += f"; shadow moved {int(r['momentum_notches']):+d} over the archived window"
        cause = str(r.get("momentum_cause") or "")
        if "code" in cause or "settings" in cause:
            base += f" ({cause} changed between the runs: a model revision, not news)"
    return base


# ----------------------------------------------------------------------------------------------- migration

def migration_matrix(runs: list[dict], ratings_pd: dict, per: str = "run", col: str = "pd_default") -> tuple[pd.DataFrame, dict]:
    """Count matrix of shadow ratings from one archived run to the next (rows from, columns to).

    per="run": consecutive runs. per="as_of": the last run of each distinct as_of date. Only ratings that occur
    are shown. The dict says how many runs, dates and country transitions the counts rest on."""
    if per == "as_of":
        last = {}
        for r in runs:
            last[str(r["as_of"])[:10]] = r
        seq = [last[k] for k in sorted(last)]
    elif per == "run":
        seq = list(runs)
    else:
        raise ValueError("per must be 'run' or 'as_of'")
    labels, _, _ = rating_scale(ratings_pd)
    pairs = []
    for a, b in zip(seq, seq[1:]):
        sa, sb = _shadow_series(a, ratings_pd, col), _shadow_series(b, ratings_pd, col)
        for name in sa.index.intersection(sb.index):
            if np.isfinite(sa[name]) and np.isfinite(sb[name]):
                pairs.append((int(sa[name]), int(sb[name])))
    used = sorted({i for p in pairs for i in p})
    m = pd.DataFrame(0, index=[labels[i] for i in used], columns=[labels[i] for i in used], dtype=int)
    for i, j in pairs:
        m.at[labels[i], labels[j]] += 1
    m.index.name = "from \\ to"
    info = {"per": per, "runs": len(seq), "as_of_dates": len({str(r["as_of"])[:10] for r in seq}),
            "transitions": len(pairs), "moved": int(sum(i != j for i, j in pairs)),
            "label": (f"{len(seq)} runs over {len({str(r['as_of'])[:10] for r in seq})} as_of date(s), "
                      f"{len(pairs)} country transitions: counts, not probabilities; run-to-run moves are mostly "
                      "code and data revisions, not 1-year rating migrations")}
    return m, info


REFERENCE_SOURCE = (
    "S&P Global Ratings, 'Default, Transition, and Recovery: 2023 Annual Sovereign Default And Rating Transition "
    "Study' (published 2024), table of sovereign foreign-currency average one-year transition rates since 1975. "
    "APPROXIMATE: the values below are rounded judgement values with the published table's shape (high diagonal, "
    "defaults concentrated in B and CCC/C), not a transcription. Check against the published table before "
    "quoting any number.")

# Reference long-run 1-year agency transition matrix, rating-category level, percent, rows sum to 100,
# withdrawn ratings removed. Judgement table, approximate (see REFERENCE_SOURCE). Not used by any PD.
REFERENCE_TRANSITION = pd.DataFrame(
    [[96.5, 3.4, 0.1, 0.0, 0.0, 0.0, 0.0, 0.0],
     [3.0, 93.5, 3.2, 0.2, 0.1, 0.0, 0.0, 0.0],
     [0.0, 3.5, 91.6, 4.5, 0.3, 0.1, 0.0, 0.0],
     [0.0, 0.1, 5.0, 88.6, 5.6, 0.6, 0.1, 0.0],
     [0.0, 0.0, 0.1, 6.0, 85.9, 7.0, 0.6, 0.4],
     [0.0, 0.0, 0.0, 0.1, 6.5, 86.9, 4.5, 2.0],
     [0.0, 0.0, 0.0, 0.0, 1.0, 25.0, 44.0, 30.0]],
    index=["AAA", "AA", "A", "BBB", "BB", "B", "CCC/C"],
    columns=["AAA", "AA", "A", "BBB", "BB", "B", "CCC/C", "SD/D"])


# ----------------------------------------------------------------------------------------------- outputs

def run_for_as_of(as_of, archive_dir=ARCHIVE) -> tuple[dict, list[dict]]:
    """The latest archived base run with as_of <= D (latest as_of, then latest creation time), and all such runs
    in that order."""
    runs = load_runs(archive_dir, as_of)
    if not runs:
        raise FileNotFoundError(f"no archived base run with as_of <= {as_of} in {archive_dir}")
    return runs[-1], runs


def archived_run_path(archive_dir, run_id) -> Path:
    """<archive_dir>/<run_id>.json for a run_id read from inside an archived JSON (EQ-B-0081 review). The id must be
    a plain name (no path separator, no "..", not absolute) and the path must resolve inside archive_dir; else
    ValueError."""
    rid = str(run_id or "")
    if not rid or "/" in rid or "\\" in rid or ".." in rid or rid != Path(rid).name or Path(rid).is_absolute():
        raise ValueError(f"unsafe archived run_id {rid!r}")
    base = Path(archive_dir).resolve()
    f = (base / f"{rid}.json").resolve()
    if not f.is_relative_to(base):
        raise ValueError(f"archived run_id {rid!r} points outside {base}")
    return f


def build(as_of, archive_dir=ARCHIVE, data_dir=ROOT / "data") -> tuple[pd.DataFrame, dict]:
    """Shadow table for as_of D from the archive. The ratings_pd table is the current run's archived settings
    (else data/assumptions.json), and is used for every archived run so the notches are comparable."""
    import json
    cur, runs = run_for_as_of(as_of, archive_dir)
    f = archived_run_path(archive_dir, cur["run_id"])
    raw = json.loads(f.read_text()) if f.exists() else {}
    ratings_pd = (raw.get("settings") or {}).get("ratings_pd")
    from ..config import Settings
    s = Settings.load(Path(data_dir) / "assumptions.json")
    ratings_pd = ratings_pd or s["ratings_pd"]
    table, info = shadow_ratings(_run_table(cur), ratings_pd, runs=runs, as_of=as_of, settings=s, run_id=cur["run_id"],
                                 run_as_of=cur["as_of"])
    info.update(run_id=cur["run_id"], run_as_of=str(cur["as_of"])[:10], requested_as_of=pd.Timestamp(as_of).strftime("%Y-%m-%d"),
                runs_read=len(runs), ratings_pd=ratings_pd,
                migration_run=migration_matrix(runs, ratings_pd, "run"), migration_as_of=migration_matrix(runs, ratings_pd, "as_of"))
    return table, info


def _md_table(df: pd.DataFrame, index: bool = False) -> list[str]:
    d = df.reset_index() if index else df
    cols = [str(c) for c in d.columns]
    lines = ["| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
    for _, r in d.iterrows():
        lines.append("| " + " | ".join(_fmt(v) for v in r) + " |")
    return lines


def _fmt(v) -> str:
    if v is None or (isinstance(v, float) and math.isnan(v)):
        return ""
    if isinstance(v, (float, np.floating)):
        if float(v).is_integer():
            return str(int(v))
        return f"{v:.4f}" if abs(v) < 1 else f"{v:.1f}"
    return str(v).replace("|", "/")


def markdown(table: pd.DataFrame, info: dict) -> str:
    sc = info["scorecard_fit"]
    flagged = table[table["flag"] != "none"]
    L = [f"# Shadow sovereign ratings, as_of {info.get('requested_as_of') or table['as_of'].iloc[0]}", "",
         f"Run {info.get('run_id')} (as_of {info.get('run_as_of')}); {info.get('runs_read')} archived base runs with as_of <= the date were read. "
         "Analytics only: nothing here feeds a PD. Positive gap = shadow rating worse than the agency.", "",
         f"## Flags (|gap| >= {info['gap_notches']} notches on pd_default)", ""]
    L += (["None."] if flagged.empty else
          [f"- {r.country}: shadow {r.shadow_rating} vs agency {r.agency_rating}, gap {int(r.gap_notches):+d} ({r.flag}; "
           f"pd_model {'confirms' if r.flag_confirmed_by_pd_model else 'does not confirm'})" for r in flagged.itertuples()])
    L += ["", "## Table", ""]
    L += _md_table(table[["country", "agency_rating", "pd_default", "shadow_rating", "gap_notches", "shadow_rating_model",
                          "shadow_rating_hazard", "composite", "scorecard_rating", "flag", "momentum_notches", "momentum_flag",
                          "momentum_cause"]])
    L += ["", "## Scorecard-implied rating", "",
          f"{sc.get('method')}. n = {sc.get('n')}. " + (
              f"Slope {sc['slope']:.3f} notches per composite point, R2 {sc['r2']:.2f}, leave-one-out RMSE {sc['rmse_loo']:.1f} notches. "
              "With this few names the fit is a rough ordering; do not read single-notch differences."
              if "rmse_loo" in sc else f"No fit: {sc.get('reason')}."), "",
          "## Notch boundaries (geometric midpoints of ratings_pd)", ""]
    L += _md_table(info["boundaries"])
    for key in ("migration_run", "migration_as_of"):
        m, mi = info[key]
        L += ["", f"## Shadow migration, {'consecutive runs' if mi['per'] == 'run' else 'last run per as_of date'}", "",
              f"{mi['label']}. Moves off the diagonal: {mi['moved']}.", ""]
        L += _md_table(m, index=True) if len(m) else ["No transitions."]
    L += ["", "## Reference long-run agency 1-year transition matrix (percent)", "", REFERENCE_SOURCE, ""]
    L += _md_table(REFERENCE_TRANSITION.rename_axis("from \\ to"), index=True)
    return "\n".join(L) + "\n"


def note_table(table: pd.DataFrame) -> pd.DataFrame:
    """The country-note extract of a shadow_ratings table: NOTE_COLUMNS, one row per country, notch_gap as a whole
    number (nullable)."""
    t = table.copy()
    t["notch_gap"] = pd.to_numeric(t["gap_notches"], errors="coerce").round().astype("Int64")
    return t.reindex(columns=list(NOTE_COLUMNS)).reset_index(drop=True)


def write_outputs(table: pd.DataFrame, info: dict, out_dir=ROOT / "outputs") -> list[Path]:
    from ..validation.idea_log import _csv_safe
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    p1, p2, p3 = out / "shadow_ratings.csv", out / "shadow_ratings.md", out / NOTE_FILE
    _csv_safe(table).to_csv(p1, index=False)
    p2.write_text(markdown(_csv_safe(table), info))
    _csv_safe(note_table(table)).to_csv(p3, index=False)
    return [p1, p2, p3]


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.engine.shadow_ratings", description=__doc__.split("\n")[0])
    ap.add_argument("--as-of", required=True, help="YYYY-MM-DD; archived runs dated after it are not read")
    ap.add_argument("--archive", default=str(ARCHIVE))
    ap.add_argument("--data", default=str(ROOT / "data"))
    ap.add_argument("--out", default=str(ROOT / "outputs"))
    a = ap.parse_args(argv)
    out = Path(a.out).resolve()
    if not out.is_relative_to(OUTPUTS.resolve()):
        ap.error(f"--out must be inside {OUTPUTS}")       # never write outside the outputs folder (EQ-B-0081 review)
    table, info = build(a.as_of, a.archive, a.data)
    for p in write_outputs(table, info, out):
        print(p)
    print(table[["country", "agency_rating", "shadow_rating", "gap_notches", "scorecard_rating", "flag", "momentum_flag"]].to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
