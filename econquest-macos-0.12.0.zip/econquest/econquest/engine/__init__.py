"""Quantitative Compute Engine (paper Appendix B.2): layers 1-6, stress scenarios and the pipeline."""
from .pipeline import run_pipeline, RunResult  # noqa: F401
