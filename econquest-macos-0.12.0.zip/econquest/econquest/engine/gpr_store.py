"""Per-country event GPR as a stored output: outputs/gpr_country.csv (HO-20261024-C-B-004, EQ-B-0086).

The pipeline computes the per-country GPR table (`gpr.run_gpr`) but RunResult.to_dict() keeps only gpr_global, so
archived runs do not carry it. This module writes the per-country rows to a CSV for the country notes
(presentation/note_v2.gpr_html) without touching pipeline.py or cli.py.

Columns (GPR_COUNTRY_COLUMNS): country, iso, event_score, z_events, percentile_events, gpr_source_used (the six Team
C reads), then as_of and gpr_source (the `gpr.source` setting of the run: ci, events or blend).

- gpr_source_used is what `run_gpr` used for the 4.10 uplift: "ci", "events", "blend" or "none". Under the default
  `gpr.source` "ci" it is "ci" where a Caldara-Iacoviello country series exists, else "none".
- event_score / z_events / percentile_events are the event GPR (UCDP/GDELT, `gpr.event_gpr_scores` and
  `event_gpr_stats`) at as_of. They are computed whatever `gpr.source` is, for information: under "ci" they do not
  move 4.10 or any PD. They are blank when the universe has no event table (data/live/events/events_long.csv) or the
  country's event series is too short.

Same inputs, settings and as_of give the same numbers as the run: `run_gpr` is deterministic and reads no clock.
Nothing here feeds a PD, a loss or a limit, and the base run is unchanged (this module is not called by the pipeline).

CLI: `python -m econquest.engine.gpr_store --as-of YYYY-MM-DD [--data data] [--out outputs]`.
"""
from __future__ import annotations

import argparse
import dataclasses
from pathlib import Path

import numpy as np
import pandas as pd

from ..config import Settings
from ..ingestion import Universe
from .common import as_of_timestamp
from .gpr import event_gpr_scores, event_gpr_stats, gpr_source, run_gpr

ROOT = Path(__file__).resolve().parents[2]
OUTPUTS = ROOT / "outputs"
GPR_COUNTRY_FILE = "gpr_country.csv"
GPR_COUNTRY_COLUMNS = ("country", "iso", "event_score", "z_events", "percentile_events", "gpr_source_used", "as_of",
                       "gpr_source")


def gpr_country_table(u: Universe, settings: Settings, as_of, table: pd.DataFrame | None = None) -> pd.DataFrame:
    """One row per desk country, GPR_COUNTRY_COLUMNS. `table` is a run's gpr_country (RunResult.gpr_country) when
    the caller has it; else `run_gpr` is run on the same inputs. Empty frame (the columns) when the universe has no
    monthly GPR table."""
    as_of = pd.Timestamp(as_of).strftime("%Y-%m-%d")
    s = dataclasses.replace(settings, raw={**settings.raw, "as_of": as_of})
    if table is None:
        if u.gpr is None:
            return pd.DataFrame(columns=list(GPR_COUNTRY_COLUMNS))
        table, _ = run_gpr(u, s, u.gpr)
    src = gpr_source(s)
    prof = u.countries.set_index("country")
    isos = [str(prof.at[c, "iso"]).upper() if c in prof.index else "" for c in table.index]
    out = pd.DataFrame({"country": list(table.index), "iso": isos})
    if "event_score" in table.columns:            # gpr.source events / blend: the run's own event columns
        for col in ("event_score", "z_events", "percentile_events", "gpr_source_used"):
            out[col] = table[col].to_numpy()
    else:                                         # gpr.source ci: event GPR for information only
        events = getattr(u, "events", None)
        if events is not None and len(events):
            summ, series = event_gpr_scores(events, as_of_timestamp(s), s, isos=isos)
            est = event_gpr_stats(summ, series, int(s["gpr"]["window_months"]), s)
            out["event_score"] = [float(summ.at[i, "score"]) if i in summ.index else np.nan for i in isos]
            out["z_events"] = [float(est.at[i, "z"]) if i in est.index else np.nan for i in isos]
            out["percentile_events"] = [float(est.at[i, "percentile"]) if i in est.index else np.nan for i in isos]
        else:
            out["event_score"] = out["z_events"] = out["percentile_events"] = np.nan
        out["gpr_source_used"] = ["ci" if bool(table.at[c, "covered"]) else "none" for c in table.index]
    out["as_of"] = as_of
    out["gpr_source"] = src
    return out.reindex(columns=list(GPR_COUNTRY_COLUMNS)).reset_index(drop=True)


def write_gpr_country(df: pd.DataFrame, out_dir=OUTPUTS) -> Path:
    from ..validation.idea_log import _csv_safe
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    p = out / GPR_COUNTRY_FILE
    _csv_safe(df).to_csv(p, index=False)
    return p


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.engine.gpr_store", description=__doc__.split("\n")[0])
    ap.add_argument("--as-of", required=True, help="YYYY-MM-DD; no data dated after it is read")
    ap.add_argument("--data", default=str(ROOT / "data"))
    ap.add_argument("--out", default=str(OUTPUTS))
    a = ap.parse_args(argv)
    out = Path(a.out).resolve()
    if not out.is_relative_to(OUTPUTS.resolve()):
        ap.error(f"--out must be inside {OUTPUTS}")
    from ..ingestion import load_universe
    u = load_universe(a.data)
    s = Settings.load(Path(a.data) / "assumptions.json")
    df = gpr_country_table(u, s, a.as_of)
    print(write_gpr_country(df, out))
    print(df.to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
