"""Layer 2: Bayesian log-odds update, scorecard prior and prediction-market integration (paper 3.2).

logit(p_post) = logit(p_model) + w_s (S - S_bar) + sum_k w_k z_k
   z_cds : market log-odds gap, logit(physical PD from the CDS or EMBI spread) - logit(p_model); the
           spread-implied (risk-neutral) PD is divided by probability.risk_premium_ratio first (GOV-013).
           Spread source: the Country Profile `spread` (default), or a CDS curve from Team A's market store when
           probability.market_term.source is "cds_curves" (EQ-B-0050/0100, off by default; see below)
   z_fx  : 3-month depreciation in 5-point units (stand-in for the FX implied-vol skew), weighted
           per FX regime by probability.w_fx_regime_scale (GOV-015)
   z_tsi : Text Stress Index z-score: the Country Profile `textz` (0 today; scenarios shock it), plus the
           UCDP/GDELT event stress index when probability.text_index.source is "events" (EQ-B-0033, GOV-014;
           default "none" keeps z_tsi = textz exactly). See engine/event_index.py.
logit(p_final) = (tau_model logit(p_post) + tau_market logit(p_market)) / (tau_model + tau_market)
   tau_market scales with the default contract's open interest up to a reference size.
The arbitrage engine then prices every contract against the model and sizes with fractional Kelly.
"""
from __future__ import annotations
import re
import numpy as np
import pandas as pd
from .common import logit, expit, to_horizon, to_12m, logistic_curve, as_of_timestamp
from .event_index import layer2_text_term
from ..config import Settings
from ..ingestion import Universe

DRIVER_MAP = {   # prediction-market driver -> (kind, key)
    "Sovereign default": ("pd", "pd_model"),
    "Sanctions": ("pd", "pd_sa"),
    "Sanctions and geopolitics": ("indicator", "4.10"),
    "Political instability": ("pillar", 4), "Security and violence": ("pillar", 6),
    "Devaluation pressure": ("pillar", 2),
    "Geopolitical risk spike (GPR)": ("indicator", "4.10"),
    "Official backstop stress": ("indicator", "2.6"),
    "Inflation pressure": ("indicator", "5.5"),
    "Growth slowdown": ("indicator", "5.6"),
    "Climate and disaster": ("pillar", 7),
}


PD_FLOOR, PD_CAP = 1e-4, 0.95


def market_implied_pd(spread_bps: np.ndarray, lgd: float) -> np.ndarray:
    """Hazard-rate approximation: PD_12m = spread / LGD, floored and capped. This is a risk-neutral PD."""
    return np.clip(np.asarray(spread_bps, dtype=float) / 1e4 / lgd, PD_FLOOR, PD_CAP)


def physical_pd(spread_bps: np.ndarray, lgd: float, ratio: float, exempt: np.ndarray | None = None) -> np.ndarray:
    """Risk-premium adjustment (GOV-013): physical PD = (spread / LGD) / ratio, floored and capped.

    `ratio` is the risk-neutral-to-physical default-intensity ratio (>= 1; 1 is no adjustment). The ratio
    divides the uncapped spread/LGD so a cap-bound name is not halved twice. Rows where `exempt` is True
    (rated SD/D: the spread prices recovery on a default that has happened) keep ratio 1."""
    if not np.isfinite(ratio) or ratio < 1.0:
        raise ValueError(f"probability.risk_premium_ratio must be >= 1, got {ratio}")
    rn = np.asarray(spread_bps, dtype=float) / 1e4 / lgd
    r = np.full(rn.shape, float(ratio))
    if exempt is not None:
        r = np.where(np.asarray(exempt, dtype=bool), 1.0, r)
    return np.clip(rn / r, PD_FLOOR, PD_CAP)


def fx_regime_weight(fxregime, scale: dict | None) -> np.ndarray:
    """Per-country multiplier on w_fx from the Country Profile `fxregime` (GOV-015).

    `scale` maps regime -> multiplier (e.g. {"Peg": 0.0, "Dollarized": 0.0}); a regime not listed, or a
    missing scale, gets `scale.get("default", 1.0)`."""
    scale = scale or {}
    dflt = float(scale.get("default", 1.0))
    return np.array([float(scale.get(str(g).strip(), dflt)) for g in fxregime], dtype=float)


# ------------------------------------------------------------------ market term from CDS curves (EQ-B-0050 / EQ-B-0100)
# probability.market_term (not in assumptions.json; these code defaults reproduce today's run exactly):
#   source          "profile" (default): z_cds from the Country Profile `spread`, as before.
#                   "cds_curves": from the CDS curve bootstrapped (engine/cds_curves.py) from Team A's market store
#                   (licensed vendor pulls or CSV exports, saved snapshots only) point in time at the run's as-of.
#   measure         "spread" (default): the curve's par spread at tenor_y goes through the same spread / LGD / k
#                   mapping as the profile spread, so bond_rv.fair_bp stays its exact inverse.
#                   "hazard_1y": the curve's risk-neutral 1-year average hazard -ln S(1) replaces spread / LGD (uses the
#                   quote's own recovery and the curve shape); still divided by risk_premium_ratio k (1 for SD/D).
#   tenor_y         par-spread tenor for measure "spread"; default cds.reference_tenor_y (5).
#   allow_synthetic false (a real bool): a curve with a SYNTHETIC marker in its source, licence, vendor tickers or
#                   snapshot provenance is never used. Tests set true.
#   max_age_days    7 (finite, >= 0): a curve dated more than this many days before the run's as-of is not used.
#   fallback        "profile": a country without a usable curve keeps its profile spread (reported per row);
#                   "error": raise instead.
# Licence allow-list (review fix, EQ-B-0100): a curve is used only when its licence tag has the vendor form
# "<bloomberg|lseg>:<licence_id> (<desk-internal|redistribution>)", its source is that vendor, and the licence register
# (data/licences.csv, Team A) has a matching row whose source_id starts with the vendor slug, with internal_use "yes"
# and terms_verified "yes". No such row exists today, so no curve can be used until Team A adds one.
MARKET_TERM_DEFAULTS = {"source": "profile", "measure": "spread", "tenor_y": None, "allow_synthetic": False,
                        "max_age_days": 7, "fallback": "profile"}
MARKET_TERM_CHOICES = {"source": ("profile", "cds_curves"), "measure": ("spread", "hazard_1y"),
                       "fallback": ("profile", "error")}
MARKET_TERM_COLUMNS = ["iso3", "market_spread_bp", "hazard_1y_rn", "spread_equiv_bp", "market_source", "market_licence",
                       "market_as_of", "market_snapshot_id", "market_term_reason"]
VENDOR_LICENCE_RE = re.compile(r"(bloomberg|lseg):([A-Za-z0-9._/:-]{1,64}) \((desk-internal|redistribution)\)")
SYNTHETIC_RE = re.compile(r"synthetic|fixture|fake|test", re.IGNORECASE)


def _finite_number(v) -> bool:
    return isinstance(v, (int, float)) and not isinstance(v, bool) and np.isfinite(float(v))


def market_term_params(settings: Settings | None) -> dict:
    """probability.market_term merged over MARKET_TERM_DEFAULTS and checked strictly (ValueError on any bad value or
    unknown key). tenor_y None -> cds.reference_tenor_y."""
    cfg = (settings.get("probability", "market_term", default={}) if settings is not None else {}) or {}
    if not isinstance(cfg, dict):
        raise ValueError(f"probability.market_term must be an object, got {type(cfg).__name__}")
    extra = sorted(set(cfg) - set(MARKET_TERM_DEFAULTS))
    if extra:
        raise ValueError(f"probability.market_term: unknown key(s) {extra}; allowed {sorted(MARKET_TERM_DEFAULTS)}")
    p = {**MARKET_TERM_DEFAULTS, **cfg}
    for k, ok in MARKET_TERM_CHOICES.items():
        if not isinstance(p[k], str) or p[k] not in ok:
            raise ValueError(f"probability.market_term.{k} must be one of {list(ok)}, got {p[k]!r}")
    if not isinstance(p["allow_synthetic"], bool):
        raise ValueError(f"probability.market_term.allow_synthetic must be true or false, got {p['allow_synthetic']!r}")
    if not (_finite_number(p["max_age_days"]) and float(p["max_age_days"]) >= 0):
        raise ValueError(f"probability.market_term.max_age_days must be a finite number >= 0, got {p['max_age_days']!r}")
    if p["tenor_y"] is None:
        cds = (settings.get("cds", default={}) if settings is not None else {}) or {}
        p["tenor_y"] = cds.get("reference_tenor_y", 5)
    if not (_finite_number(p["tenor_y"]) and float(p["tenor_y"]) > 0):
        raise ValueError(f"probability.market_term.tenor_y must be a finite number > 0, got {p['tenor_y']!r}")
    p["tenor_y"], p["max_age_days"] = float(p["tenor_y"]), float(p["max_age_days"])
    return p


def licence_approved(source: str, licence: str, register: list[dict] | None = None) -> tuple[bool, str]:
    """(approved, reason) for one curve's source and licence tag, against the licence register allow-list above."""
    lic = str(licence or "").strip()
    m = VENDOR_LICENCE_RE.fullmatch(lic)
    if not m:
        return False, f"licence {lic!r} is not a vendor licence tag '<bloomberg|lseg>:<id> (<scope>)'"
    vendor = m.group(1)
    if str(source or "").strip() != vendor:
        return False, f"source {source!r} does not match licence vendor {vendor!r}"
    from ..ingestion import licences as LIC
    # matched on the licence tag alone (review fix): a row that matches only on source would approve any licence id
    row = LIC.licence_for(licence=lic, register=register)
    if not row or not str(row.get("source_id", "")).startswith(vendor):
        return False, f"no approved {vendor} row in the licence register"
    if row.get("internal_use") != "yes" or row.get("terms_verified") != "yes":
        return False, (f"register row {row.get('source_id')} not approved (internal_use {row.get('internal_use')!r}, "
                       f"terms_verified {row.get('terms_verified')!r})")
    return True, f"register row {row['source_id']}"


def _store_markers(market_dir, cut) -> dict:
    """{market snapshot id: SYNTHETIC-like markers found in its vendor tickers, source, licence or manifest provenance}."""
    from ..ingestion.market.store import market_history, snapshot_root
    import json
    rows = market_history(market_dir, instrument="cds", asof=cut.strftime("%Y-%m-%d"))
    out: dict[str, list[str]] = {}
    for sid, g in rows.groupby("snapshot_id"):
        hits = [f"{col} {v!r}" for col in ("vendor_ticker", "source", "licence")
                for v in sorted(set(g[col].astype(str))) if SYNTHETIC_RE.search(v)]
        try:
            prov = json.loads((snapshot_root(market_dir) / sid / "manifest.json").read_text()).get("provenance", {})
        except (OSError, ValueError):
            prov = None
            hits.append("manifest unreadable")
        if prov is not None and SYNTHETIC_RE.search(json.dumps(prov, default=str)):
            hits.append("manifest provenance")
        out[str(sid)] = hits
    return out


def market_term_from_curves(prof: pd.DataFrame, settings: Settings, market_dir=None, as_of=None) -> pd.DataFrame:
    """Per country (index of `prof`, which needs `iso` and `spread`): the layer-2 market input from CDS curves read by
    cds_curves.curves_from_market(market_dir, as_of, settings) (FileNotFoundError when no snapshot was saved by
    as_of; no silent fallback). A curve is used only when it passes the licence allow-list, has no SYNTHETIC marker
    (unless allow_synthetic), is not stale and fitted. Columns MARKET_TERM_COLUMNS; `spread_equiv_bp` is what layer 2
    feeds to spread / LGD / k (the par spread at tenor_y, or 1e4 x hazard_1y x LGD for measure "hazard_1y"; the
    profile spread where no curve is used). attrs["issues"] carries the curve issues."""
    from . import cds_curves as cc
    p = market_term_params(settings)
    cut = as_of_timestamp(settings, as_of)
    if market_dir is None:
        raise ValueError("probability.market_term.source 'cds_curves' needs a market data folder (run_pipeline "
                         "market_dir); refusing to fall back to profile spreads silently")
    ct, summ, issues = cc.curves_from_market(market_dir, cut, settings)
    markers = _store_markers(market_dir, cut)
    summ = summ.set_index("iso3") if len(summ) else pd.DataFrame()
    lgd = float(settings["probability"]["lgd_market_implied"])
    rows = []
    for c, r in prof.iterrows():
        iso = str(r.get("iso", c)).strip().upper()
        prof_bp = float(r["spread"])
        row = {"iso3": iso, "market_spread_bp": prof_bp, "hazard_1y_rn": np.nan, "spread_equiv_bp": prof_bp,
               "market_source": "profile spread", "market_licence": "", "market_as_of": "", "market_snapshot_id": "",
               "market_term_reason": ""}
        why = ""
        if iso not in summ.index:
            why = "no CDS curve at as_of"
        else:
            s = summ.loc[iso]
            sid = str(s["snapshot_id"])
            mk = list(markers.get(sid.split(":", 1)[0], ["capture not found in the store"]))
            if bool(s["synthetic"]) or SYNTHETIC_RE.search(str(s["source"]) + " " + str(s["licence"])):
                mk.append("curve source/licence")
            ok_lic, lic_why = licence_approved(str(s["source"]), str(s["licence"]))
            age = (cut - pd.Timestamp(s["as_of"])).days
            if mk and not p["allow_synthetic"]:
                why = f"synthetic or unverifiable curve {sid} not used ({'; '.join(mk)})"
            elif not ok_lic:
                why = f"licence not approved: {lic_why}"
            elif age > p["max_age_days"]:
                why = f"curve as of {s['as_of']} older than {p['max_age_days']:g} days"
            elif "no_root" in str(s["flags"]):
                why = f"curve did not fit ({s['flags']})"
            else:
                spr = cc.par_spread_at(ct, iso, p["tenor_y"], settings)
                h1 = float(s["hazard_1y"])
                eq = 1e4 * h1 * lgd if p["measure"] == "hazard_1y" else spr
                if not (np.isfinite(eq) and eq >= 0):
                    why = "curve gave no finite value"
                else:
                    tag = " (SYNTHETIC)" if mk else ""
                    row.update({"market_spread_bp": spr, "hazard_1y_rn": h1, "spread_equiv_bp": eq,
                                "market_source": f"CDS curve {p['measure']}" + (f" {p['tenor_y']:g}y" if p["measure"] == "spread" else "") + tag,
                                "market_licence": str(s["licence"]), "market_as_of": str(s["as_of"]),
                                "market_snapshot_id": sid, "market_term_reason": "curve used"})
        if why:
            row["market_term_reason"] = "profile fallback: " + why
        rows.append(row)
    out = pd.DataFrame(rows, index=prof.index, columns=MARKET_TERM_COLUMNS)
    miss = out["market_term_reason"].str.startswith("profile fallback")
    if p["fallback"] == "error" and miss.any():
        raise ValueError("probability.market_term.fallback 'error': no usable CDS curve for "
                         + "; ".join(f"{c}: {w}" for c, w in out.loc[miss, "market_term_reason"].items()))
    out.attrs["issues"] = list(issues)
    return out


def publish_guard(country: pd.DataFrame, register: list[dict] | None = None) -> None:
    """Refuse (ValueError) a country table that carries vendor market data not cleared for distribution.

    For publish and other client-facing writers (EQ-B-0100 item 6): every non-blank `market_licence` must be a vendor
    tag with scope "(redistribution)" AND the licence register row it matches must say client_output "allowed"
    (today the bloomberg and lseg rows say "barred", so any vendor value is refused). A table without the column
    (switch off) passes."""
    if "market_licence" not in country:
        return
    from ..ingestion import licences as LIC

    def cleared(x: str) -> bool:
        m = VENDOR_LICENCE_RE.fullmatch(x)
        if not m or m.group(3) != "redistribution":
            return False
        row = LIC.licence_for(source=m.group(1), licence=x, register=register)
        return bool(row) and row.get("client_output") == "allowed"

    lic = country["market_licence"].fillna("").astype(str).str.strip()
    bad = lic[(lic != "") & ~lic.map(cleared)]
    if len(bad):
        raise ValueError("refusing to publish: vendor market data without a redistribution licence for "
                         + ", ".join(f"{c} ({v})" for c, v in bad.items())
                         + "; run with probability.market_term.source 'profile' or obtain a redistribution licence")


def vendor_reads(country: pd.DataFrame) -> list[dict]:
    """Vendor CDS curve reads in a layer-2 / country table (HO-20261025-C-B-005), one entry per vendor.

    Counts only rows whose market term actually used a curve ("curve used") and whose `market_licence` is a vendor
    tag (bloomberg:/lseg:). A table without `market_licence` (probability.market_term.source "profile", the
    default) gives []. Pure read: no number changes."""
    if country is None or "market_licence" not in country or "market_term_reason" not in country:
        return []
    by: dict[str, dict] = {}
    for idx, r in country.iterrows():
        if str(r.get("market_term_reason", "")) != "curve used":
            continue
        lic = str(r.get("market_licence", "") or "").strip()
        m = VENDOR_LICENCE_RE.fullmatch(lic)
        if not m:
            continue
        iso = str(r.get("iso3") or r.get("iso") or idx).strip().upper()
        e = by.setdefault(m.group(1), {"vendor": m.group(1), "licences": [], "isos": [], "snapshot_ids": []})
        for k, v in (("licences", lic), ("isos", iso), ("snapshot_ids", str(r.get("market_snapshot_id", "") or ""))):
            if v and v not in e[k]:
                e[k].append(v)
    return [by[v] for v in sorted(by)]


def record_vendor_use(country: pd.DataFrame, out_dir, output: str, actor: str = "", now=None) -> list[dict]:
    """Append one Team C vendor-usage row per vendor read in `country` (vendor_ops.record_use, purpose
    "internal_output"). Call once per run. Returns the rows written: [] when the switch is off or no vendor
    curve was used, so nothing is written."""
    reads = vendor_reads(country)
    if not reads:
        return []
    from ..ops import vendor_ops
    return [vendor_ops.record_use(out_dir, e["vendor"], "CDS curve " + ",".join(e["isos"]), "internal_output",
                                  output=str(output or ""), actor=actor, licence="; ".join(e["licences"]),
                                  detail="layer2 probability.market_term; snapshots " + ",".join(e["snapshot_ids"]),
                                  now=now)
            for e in reads]


def posterior(u: Universe, settings: Settings, p_model: pd.Series, composite: pd.Series, market_dir=None) -> pd.DataFrame:
    """Layer-2 posterior. `market_dir` (a data folder with Team A's market store) is read only when
    probability.market_term.source is "cds_curves" (default "profile": the Country Profile spread, as before)."""
    pr = settings["probability"]
    prof = u.countries.set_index("country").loc[u.names]
    lm = logit(p_model.loc[u.names].to_numpy())
    spread = prof["spread"].to_numpy(dtype=float)
    mt = None
    if market_term_params(settings)["source"] == "cds_curves":
        mt = market_term_from_curves(prof, settings, market_dir)
        spread = mt["spread_equiv_bp"].to_numpy(dtype=float)
    pd_market = market_implied_pd(spread, pr["lgd_market_implied"])          # risk-neutral, kept for benchmarks
    exempt_ratings = {str(x).strip().upper() for x in pr.get("risk_premium_exempt_ratings", ["SD", "D"])}
    exempt = prof["rating"].astype(str).str.strip().str.upper().isin(exempt_ratings).to_numpy()
    pd_market_phys = physical_pd(spread, pr["lgd_market_implied"], float(pr.get("risk_premium_ratio", 1.0)), exempt)
    z_cds = logit(pd_market_phys) - lm
    fx_w = fx_regime_weight(prof["fxregime"] if "fxregime" in prof else [""] * len(prof), pr.get("w_fx_regime_scale"))
    z_fx = prof["fx3m"].to_numpy(dtype=float) / 5.0
    z_tsi, z_event, event_flag = layer2_text_term(prof["textz"].to_numpy(dtype=float), list(prof["iso"] if "iso" in prof else prof.index),
                                                  getattr(u, "events", None), settings)
    dev = composite.loc[u.names].to_numpy() - pr["score_centre"]
    lp = lm + pr["w_s"] * dev + pr["w_m"] * z_cds + pr.get("w_fx", 0.0) * fx_w * z_fx + pr["w_t"] * z_tsi
    out = pd.DataFrame({"pd_model": p_model.loc[u.names].to_numpy(), "pd_market": pd_market,
                        "pd_market_phys": pd_market_phys, "score_dev": dev, "z_cds": z_cds, "z_fx": z_fx,
                        "fx_weight": fx_w, "z_tsi": z_tsi, "z_event": z_event, "event_flag": event_flag,
                        "logodds_post": lp, "pd_post": expit(lp)},
                       index=u.names)
    if mt is not None:     # only when the switch is on: the default frame keeps today's columns
        for k in ("market_spread_bp", "hazard_1y_rn", "spread_equiv_bp", "market_source", "market_licence",
                  "market_as_of", "market_snapshot_id", "market_term_reason"):
            out[k] = mt[k].to_numpy()
        out.attrs["market_term_issues"] = mt.attrs.get("issues", [])
    return out


def default_contract_prior(u: Universe, settings: Settings, as_of=None) -> pd.DataFrame:
    """12-month-equivalent default probability and tau_market from priced sovereign-default contracts.

    Contract horizons run from the run's as-of date (settings["as_of"]), never the wall clock (GOV-012)."""
    pm = settings["prediction_markets"]
    today = as_of_timestamp(settings, as_of)
    m = u.markets
    m = m[(m["driver"] == "Sovereign default") & m["yes_price"].notna()].copy()
    months = ((m["resolution_date"] - today).dt.days / 30.4375).clip(lower=0.5)
    m["p12"] = to_12m(m["yes_price"].clip(0.01, 0.99), months)
    m["tau"] = pm["tau_market_max"] * np.minimum(1.0, m["open_interest_k"] / pm["reference_oi_k"])
    out = pd.DataFrame({"pm_default": np.nan, "tau_market": 0.0, "pm_oi_k": 0.0}, index=u.names)
    for c, g in m.groupby("country"):
        w = g["open_interest_k"].to_numpy(dtype=float)
        out.at[c, "pm_default"] = float(np.average(g["p12"], weights=w) if w.sum() > 0 else g["p12"].mean())
        out.at[c, "pm_oi_k"] = float(w.sum())
        out.at[c, "tau_market"] = float(pm["tau_market_max"] * min(1.0, w.sum() / pm["reference_oi_k"]))
    return out


def blend_with_market(post: pd.DataFrame, prior: pd.DataFrame, settings: Settings) -> pd.Series:
    pm = settings["prediction_markets"]
    lp = post["logodds_post"].to_numpy()
    if not pm.get("use_market_prior", True):
        return pd.Series(expit(lp), index=post.index)
    tau_mkt = prior["tau_market"].fillna(0).to_numpy()
    lk = np.where(prior["pm_default"].notna(), logit(prior["pm_default"].fillna(0.5)), 0.0)
    lf = (pm["tau_model"] * lp + tau_mkt * lk) / (pm["tau_model"] + tau_mkt)
    return pd.Series(expit(lf), index=post.index)


def arbitrage_scan(u: Universe, settings: Settings, country: pd.DataFrame, scorecard, as_of=None) -> pd.DataFrame:
    """Price every contract against the model and size positions (paper 3.2.1 arbitrage engine).
    Horizons run from the run's as-of date (settings["as_of"])."""
    pm = settings["prediction_markets"]
    rows = []
    today = as_of_timestamp(settings, as_of)
    for _, r in u.markets.iterrows():
        c = r["country"]
        months = max(0.5, (r["resolution_date"] - today).days / 30.4375) if pd.notna(r["resolution_date"]) else 12.0
        kind, key = DRIVER_MAP.get(r["driver"], ("pd", "pd_any"))
        if kind == "pd":
            p12 = float(country.at[c, key])
        elif kind == "indicator":
            p12 = float(logistic_curve(scorecard.indicator_scores.at[key, c], pm["signal_base_prob"], pm["signal_slope"]))
        else:
            p12 = float(logistic_curve(scorecard.pillar_final.at[key, c], pm["signal_base_prob"], pm["signal_slope"]))
        p_res = float(to_horizon(p12, months))
        price = float(r["yes_price"])
        oi = float(r["open_interest_k"]) if pd.notna(r["open_interest_k"]) else 0.0
        side = "Buy Yes" if p_res > price else "Buy No"
        gross_edge = abs(p_res - price) * 100
        net_edge = gross_edge - pm["round_trip_cost_pp"]
        if side == "Buy Yes":
            cost, win_prob = price, p_res
        else:
            cost, win_prob = 1 - price, 1 - p_res
        b = (1 - cost) / cost if cost > 0 else 0.0   # net odds per $1 staked
        kelly = max(0.0, (win_prob * b - (1 - win_prob)) / b) if b > 0 else 0.0
        ev = win_prob * b - (1 - win_prob) - pm["round_trip_cost_pp"] / 100 / cost if cost > 0 else 0.0
        stake = 0.0
        if net_edge >= pm["min_net_edge_pp"] and oi >= pm["min_oi_k"]:
            stake = round(min(kelly * pm["kelly_fraction"] * pm["bankroll_k"], pm["max_share_oi"] * oi), 0)
        if net_edge < 0:
            read = "No edge after costs"
        elif p_res > price:
            read = "Model sees more risk than the market: buy Yes and pair with the related trade"
        else:
            read = "Market sees more risk than the model: buy No, or ask what the market knows"
        rows.append({"id": r["id"], "platform": r["platform"], "country": c, "driver": r["driver"], "contract": r["contract"],
                     "months": round(months, 1), "yes_price": price, "open_interest_k": oi, "model_p12": p12, "model_p_res": p_res,
                     "side": side, "net_edge_pp": net_edge, "ev_per_dollar": ev, "kelly": kelly, "stake_k": stake,
                     "expected_profit_k": stake * ev, "model_minus_market_pp": (p_res - price) * 100,
                     "divergence_flag": abs(p_res - price) * 100 >= pm["divergence_flag_pp"], "read": read,
                     "related_trade": r.get("related_trade", "")})
    return pd.DataFrame(rows)
