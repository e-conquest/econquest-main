"""Eurobond relative value against the model (EQ-B-0049). Validation note: docs/validation/cds-curves-and-rv.md.

Model-fair spread (bp/yr) for a sovereign (EQ-B-0049 review fix: an exact inverse of Layer 2):

    fair_bp  = 1e4 * p * LGD * k                   p = run pd_default (annual PD; = the annualised PD over any
                                                   duration D under the engine's constant hazard)
                                                   LGD = probability.lgd_market_implied (0.6), Layer 2's LGD
                                                   k = probability.risk_premium_ratio (0.1.3, GOV-013); 1 for
                                                   ratings in probability.risk_premium_exempt_ratings (SD, D)
    EL_bp    = 1e4 * p * LGD,  risk_premium_bp = fair_bp - EL_bp

so Layer 2's pd_market_phys = clip(spread / 1e4 / LGD / k) evaluated at spread = fair_bp returns p. Options
(documented, not default): bond_rv.lgd_source "layer4" uses lgd_hard_expected (regime and Merton uplift);
bond_rv.fair_form "intensity" uses h = -ln(1 - p) instead of p.

Market spread: the CDS curve from engine/cds_curves.py when the country has one point-in-time (par
spread at D), else the Country Profile `spread` (spread_bps). CDS-bond basis is ignored. `country_rv_pit` reads the
curves from Team A's market store at the run's as-of date (cds_curves.curves_from_market, HO-20261023-A-B-010);
derived (computed, indicative) market rows never reach market_bp or the signals (HO-20261023-A-B-011).

gap_bp = market_bp - fair_bp (> 0: the market pays more than the model needs -> CHEAP; < 0: RICH).
z = gap_bp / (market.spread_vol_rel / 100 * market_bp): the gap in units of the one-year spread move that
Layer 6 itself assumes for that bond. Chosen because no history of model-fair spreads exists (no
time-series dispersion of the gap) and a cross-sectional dispersion mixes model error with genuine value
and moves with the universe; a robust cross-sectional z of log(market/fair) is reported as `z_xs` for
comparison. Distressed names (exempt ratings or pd_12m >= bond_rv.distress_pd) trade on price and
recovery, so their z is left blank and read "distressed".

Nothing here changes a trade, a size or a run by default: `rv_signal` returns an empty frame unless
`bond_rv.enabled` is true (default false, key not yet in assumptions.json).
"""
from __future__ import annotations

import numpy as np
import pandas as pd

from . import cds_curves as cc

DEFAULTS = {"enabled": False, "pd_column": "pd_default", "z_band": 1.0, "distress_pd": 0.5,
            "signal_z_at_70": 1.0, "use_cds_curves": True, "fair_form": "layer2_inverse", "lgd_source": "market_implied"}
RV_COLUMNS = ["country", "iso3", "rating", "tenor_y", "pd_12m", "hazard_phys", "lgd", "risk_premium_ratio", "el_bp",
              "risk_premium_bp", "fair_bp", "market_bp", "market_source", "gap_bp", "z", "z_xs", "distressed", "rv_read"]


def rv_params(settings=None) -> dict:
    cfg = (settings.get("bond_rv", default={}) if settings is not None else {}) or {}
    return {**DEFAULTS, **cfg}


def fair_spread_bp(pd_12m, lgd, ratio, duration_y=5.0, form: str = "layer2_inverse"):
    """Model-fair spread (bp/yr): returns (hazard h, expected loss bp, fair bp), vectorised.

    form "layer2_inverse" (default): fair = 1e4 * p * LGD * k, the exact inverse of Layer 2's
    physical_pd(spread) = spread / 1e4 / LGD / k, which reads spread/LGD/k as an annual PD (so feeding fair_bp
    back through physical_pd with the same LGD and k returns p). The annual PD over a duration D is
    1 - (1 - P_D)^(1/D) with P_D = to_horizon(p, 12 D), which is p itself under the engine's constant hazard.
    form "intensity": fair = 1e4 * h * LGD * k with h = -ln(1 - p) (credit triangle on a continuous hazard);
    larger than the inverse for high PDs (p 0.20: h 0.223, +12%). Not the default: it disagrees with Layer 2."""
    if form not in ("layer2_inverse", "intensity"):
        raise ValueError(f"bond_rv.fair_form must be 'layer2_inverse' or 'intensity', got {form!r}")
    D = np.maximum(np.asarray(duration_y, dtype=float), 1e-6)
    p = np.clip(np.asarray(pd_12m, dtype=float), 0.0, 0.9999)
    p, D = np.broadcast_arrays(p, D)
    h = -np.log1p(-p)
    el = 1e4 * (p if form == "layer2_inverse" else h) * np.asarray(lgd, dtype=float)
    return h, el, el * np.asarray(ratio, dtype=float)


def _ratios(rating, settings) -> np.ndarray:
    pr = (settings.get("probability", default={}) if settings is not None else {}) or {}
    k = float(pr.get("risk_premium_ratio", 1.0))
    exempt = {str(x).strip().upper() for x in pr.get("risk_premium_exempt_ratings", ["SD", "D"])}
    return np.where(pd.Series(rating).astype(str).str.strip().str.upper().isin(exempt).to_numpy(), 1.0, k), exempt


def _robust_z(x: pd.Series) -> pd.Series:
    x = x.astype(float)
    med = x.median()
    mad = 1.4826 * (x - med).abs().median()
    return (x - med) / mad if np.isfinite(mad) and mad > 0 else x * np.nan


def country_rv(country: pd.DataFrame, settings=None, curve_table: pd.DataFrame | None = None,
               tenor_y: float | None = None, durations: pd.Series | None = None) -> pd.DataFrame:
    """RV table, one row per country (index of the run's country table), at `tenor_y` (default cds.reference_tenor_y)
    or per-country `durations` (Series by country name)."""
    p = rv_params(settings)
    mk = (settings.get("market", default={}) if settings is not None else {}) or {}
    vol_rel = float(mk.get("spread_vol_rel", 40.0)) / 100.0
    T = float(tenor_y if tenor_y is not None else cc.cds_params(settings)["reference_tenor_y"])
    c = country
    names = list(c.index)
    D = durations.reindex(names).fillna(T).to_numpy(float) if durations is not None else np.full(len(names), T)
    pdc = p["pd_column"] if p["pd_column"] in c else "pd_default"
    pd12 = c[pdc].to_numpy(float)
    if p["lgd_source"] == "layer4":
        lgd = c["lgd_hard_expected"].to_numpy(float)
    elif p["lgd_source"] == "market_implied":     # Layer 2's LGD, so fair_bp inverts pd_market_phys exactly
        pr = (settings.get("probability", default={}) if settings is not None else {}) or {}
        lgd = np.full(len(c), float(pr.get("lgd_market_implied", 0.6)))
    else:
        raise ValueError(f"bond_rv.lgd_source must be 'market_implied' or 'layer4', got {p['lgd_source']!r}")
    rating = c["rating"] if "rating" in c else pd.Series([""] * len(c), index=c.index)
    k, exempt = _ratios(rating, settings)
    h, el, fair = fair_spread_bp(pd12, lgd, k, D, p["fair_form"])
    iso = c["iso"].astype(str).to_numpy() if "iso" in c else np.array(names)
    market = c["spread_bps"].to_numpy(float).copy()
    src = np.array(["profile spread"] * len(c), dtype=object)
    if p["use_cds_curves"] and curve_table is not None and len(curve_table):
        for i, code in enumerate(iso):
            s = cc.par_spread_at(curve_table, code, D[i], settings)
            if np.isfinite(s):
                g = curve_table[curve_table["iso3"] == code].iloc[0]
                market[i] = s
                src[i] = f"CDS curve {g['snapshot_id']} as of {g['as_of']}" + (" (SYNTHETIC)" if bool(g.get("synthetic", False)) else "")
    gap = market - fair
    distressed = rating.astype(str).str.strip().str.upper().isin(exempt).to_numpy() | (pd12 >= float(p["distress_pd"]))
    z = np.where(distressed | ~(market > 0), np.nan, gap / (vol_rel * np.where(market > 0, market, np.nan)))
    lr = pd.Series(np.log(np.where((market > 0) & (fair > 0), market / np.where(fair > 0, fair, 1.0), np.nan)), index=names)
    z_xs = _robust_z(lr.where(~distressed))
    band = float(p["z_band"])
    read = np.where(distressed, "distressed: price/recovery trade, not spread RV",
                    np.where(z >= band, "cheap vs model", np.where(z <= -band, "rich vs model", "in line")))
    out = pd.DataFrame({"country": names, "iso3": iso, "rating": rating.to_numpy(), "tenor_y": D, "pd_12m": pd12, "hazard_phys": h,
                        "lgd": lgd, "risk_premium_ratio": k, "el_bp": el, "risk_premium_bp": fair - el, "fair_bp": fair,
                        "market_bp": market, "market_source": src, "gap_bp": gap, "z": z, "z_xs": z_xs.to_numpy(),
                        "distressed": distressed, "rv_read": read}, index=names)
    return out[RV_COLUMNS]


def country_rv_pit(country: pd.DataFrame, settings=None, data_dir=None, as_of=None) -> pd.DataFrame:
    """country_rv with CDS curves read point in time from Team A's market store under `data_dir` at `as_of` (default
    settings["as_of"]). data_dir None, or bond_rv.use_cds_curves false: exactly country_rv(country, settings), i.e.
    profile spreads (today's behaviour). A missing store raises FileNotFoundError (no silent fallback to seed spreads).
    The curve issues (excluded derived rows, ignored older captures, ...) are in the result's attrs["issues"]."""
    if data_dir is None or not rv_params(settings)["use_cds_curves"]:
        return country_rv(country, settings)
    ct, _, issues = cc.curves_from_market(data_dir, as_of, settings)
    out = country_rv(country, settings, curve_table=ct)
    out.attrs["issues"] = issues
    return out


def position_rv(portfolio: pd.DataFrame, country: pd.DataFrame, settings=None, curve_table: pd.DataFrame | None = None) -> pd.DataFrame:
    """Per Eurobond / CDS-protection position: RV at the position's duration and whether it favours the holder."""
    cols = ["id", "asset_class", "direction", "notional_mm", "duration_yrs"] + RV_COLUMNS + ["for_position"]
    pf = portfolio[portfolio["asset_class"].astype(str).isin(["Eurobond", "CDS", "CDS protection"]) & portfolio["country"].isin(country.index)]
    if pf.empty:
        return pd.DataFrame(columns=cols)
    T = cc.cds_params(settings)["reference_tenor_y"]
    rows = []
    for pos in pf.itertuples(index=False):
        D = float(pos.duration_yrs) if pd.notna(getattr(pos, "duration_yrs", np.nan)) else T
        r = country_rv(country.loc[[pos.country]], settings, curve_table, tenor_y=D).iloc[0].to_dict()
        r["z_xs"] = np.nan    # cross-sectional z needs the universe: read it from country_rv
        long_credit = (pos.asset_class == "Eurobond") == (pos.direction == "Long")
        if r["distressed"] or not np.isfinite(r["z"]):
            fav = "n/a (distressed)" if r["distressed"] else "n/a"
        elif r["rv_read"] == "in line":
            fav = "neutral"
        else:
            cheap = r["rv_read"].startswith("cheap")
            fav = "favourable" if cheap == long_credit else "unfavourable"
        rows.append({"id": pos.id, "asset_class": pos.asset_class, "direction": pos.direction, "notional_mm": pos.notional_mm,
                     "duration_yrs": D, **r, "for_position": fav})
    return pd.DataFrame(rows)[cols]


def rv_signal(rv: pd.DataFrame, settings=None) -> pd.DataFrame:
    """Proposed signals 26 (cheap vs model) and 27 (rich vs model), 0-100, by country.

    s26 = 50 + 50 tanh(z / c) with c = signal_z_at_70 / atanh(0.4), so |z| = signal_z_at_70 scores 70;
    s27 = 100 - s26; distressed names score 50 (no reading). Empty unless bond_rv.enabled is true."""
    p = rv_params(settings)
    if not p["enabled"]:
        return pd.DataFrame(columns=["s26_bond_cheap", "s27_bond_rich"])
    c = float(p["signal_z_at_70"]) / np.arctanh(0.4)
    z = rv["z"].astype(float).fillna(0.0)
    s26 = 50.0 + 50.0 * np.tanh(z / c)
    return pd.DataFrame({"s26_bond_cheap": s26, "s27_bond_rich": 100.0 - s26}, index=rv.index)
