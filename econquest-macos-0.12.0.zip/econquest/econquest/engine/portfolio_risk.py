"""Portfolio risk analytics (EQ-B-0114): risk attribution by position, country, region, asset class and risk factor;
marginal and component VaR99 / ES99 from the Monte Carlo paths; a what-if for one proposed trade with its limit usage.

    python -m econquest.engine.portfolio_risk attribution --data data --as-of 2026-10-23 [--paths N] [--out DIR]
    python -m econquest.engine.portfolio_risk whatif --data data --as-of 2026-10-23 --country Brazil \\
        --instrument Eurobond --direction Long --size 10 [--duration 5] [--paths N] [--limits FILE] [--out DIR]

`main(argv)` is the entry point Team C can register as `econquest whatif` / `econquest attribution`. Nothing here runs
in `econquest run`, writes data/ or changes a parameter: the base run is the pipeline's own, unchanged.

Method (docs/validation/portfolio-risk.md):
  * Component ES99 of position i = E[L_i | L >= VaR99], the mean of its path loss over the tail paths that define ES99
    (the same set `simulate` uses). The components sum to ES99 exactly, up to float rounding. This is the Euler
    allocation: every position's loss is positively homogeneous in its notional (market move, jump legs, carry and
    the long-loss cap all scale with it), so marginal ES99 = d ES99 / d notional_i = component_i / notional_i.
  * Component VaR99 = E[L_i | L = VaR99], estimated on the paths whose loss rank lies within +-`band` (default 0.1% of
    the paths) of the VaR99 rank (narrowed to stay symmetric near the end of a small sample), then scaled so the components sum to VaR99 exactly. The raw (unscaled) sum and the
    scale factor are reported; a scale far from 1 means the band is too wide or too thin.
  * Factors are risk types: the market move (spread, rates, FX, equity), sovereign default (Eurobond, local bond and
    CDS default legs), transfer and convertibility, expropriation, political violence, carry, and the long-loss cap.
    The split is sequential per path (market move first, then each jump leg's change to the path, then carry, then the
    cap), so it is exact (factors sum to the position loss) but order-dependent where a default settles over the mark.
    It comes from re-simulating the base run with `simulate(legs=True)`: the same draws, checked bit-identical.
  * What-if: the proposed position is priced on the base run's own paths (its country's latent paths; its own
    severity draws from a fixed-seed generator) and added to the base path losses. "Before" is the base run itself, so
    a zero-size trade gives the base numbers exactly and the change is the trade's effect, with no re-sampling noise.
    `limits.pretrade_check` (rerun with the position appended) is kept as it is; its Sobol columns shift, so its
    before/after differences carry simulation noise that this method avoids.
"""
from __future__ import annotations

import argparse
import json
import math
import sys
from dataclasses import replace
from pathlib import Path
from types import SimpleNamespace

import numpy as np
import pandas as pd

from ..config import Settings
from ..ingestion import Universe
from . import layer3_regime as L3, layer4_severity as L4, layer5_copula as L5, layer6_montecarlo as L6
from .limits import ASSET_CLASS_ALIASES, BOOK_MEASURES, check_book, load_limits, parse_proposal, _reasons, _tail_metrics
from .pipeline import RunResult, run_pipeline

ALPHA = 0.99
VAR_BAND_SHARE = 0.001          # half-width of the VaR99 kernel band, as a share of the paths (131 paths at 131,072)
VAR_BAND_MIN = 50               # at least this many paths each side
WHATIF_ID = "WHATIF"
INSTRUMENT_ALIASES = ASSET_CLASS_ALIASES        # one list with limits.parse_proposal (dict and string proposals alike)
WHATIF_SEED_SALT = 114          # the trade's own severity draws: default_rng([settings.seed, 114]), fixed


# ---------------------------------------------------------------- Euler components

def tail_mask(losses: np.ndarray, alpha: float = ALPHA) -> tuple[np.ndarray, float]:
    """The ES tail exactly as simulate() takes it: losses >= np.quantile(losses, alpha)."""
    var = float(np.quantile(losses, alpha))
    return losses >= var, var


def var_band(losses: np.ndarray, alpha: float = ALPHA, share: float = VAR_BAND_SHARE, min_paths: int = VAR_BAND_MIN) -> np.ndarray:
    """Indices of the paths whose loss rank is within +-h of the alpha-quantile rank: h = max(min_paths, share x n),
    narrowed so the band stays symmetric when the quantile sits near the end of a small sample."""
    n = len(losses)
    k = alpha * (n - 1)
    h = min(max(int(min_paths), int(round(share * n))), math.floor(k), n - 1 - math.ceil(k))
    order = np.argsort(losses, kind="stable")
    return order[math.floor(k) - h:math.ceil(k) + h + 1]


def euler_components(matrix: np.ndarray, losses: np.ndarray, alpha: float = ALPHA, share: float = VAR_BAND_SHARE) -> dict:
    """Component VaR and ES of the columns of `matrix` (paths x items, rows summing to `losses`).
    Returns var, es, es_components, var_components (scaled to sum to var), var_raw (unscaled), var_scale, band_paths."""
    tail, var = tail_mask(losses, alpha)
    es = float(losses[tail].mean())
    es_c = matrix[tail].mean(axis=0)
    band = var_band(losses, alpha, share)
    raw = matrix[band].mean(axis=0)
    raw_sum = float(raw.sum())
    scale = var / raw_sum if raw_sum != 0 else float("nan")
    var_c = raw * scale if np.isfinite(scale) else raw
    return {"var": var, "es": es, "es_components": es_c, "var_components": var_c, "var_raw": raw, "var_raw_sum": raw_sum,
            "var_scale": scale, "band_paths": int(len(band)), "tail_paths": int(tail.sum())}


# ---------------------------------------------------------------- base run with the factor split

def factor_run(u: Universe, settings: Settings, r: RunResult, paths: int | None = None) -> L6.MCResult:
    """Re-simulate the base run with legs=True: same country table, positions, loadings, df, seed and path count.
    Raises RuntimeError unless the path losses are bit-identical to the run's."""
    loadings = L3.blended_factor_loadings(u, settings, r.country["regime"], r.diagnostics["global_stress_weight"])
    mc = L6.simulate(u, r.country, r.positions, loadings, settings, r.mc.df, paths=paths, legs=True)
    if not np.array_equal(mc.losses, r.mc.losses):
        raise RuntimeError("factor re-simulation does not reproduce the run's path losses; attribution refused")
    return mc


def _group(df: pd.DataFrame, by: str) -> pd.DataFrame:
    g = df.groupby(by)[["notional_mm", "expected_loss_mm", "component_var99_mm", "component_es99_mm"]].sum()
    g["marginal_var99_per_mm"] = g["component_var99_mm"] / g["notional_mm"].where(g["notional_mm"] != 0)
    g["marginal_es99_per_mm"] = g["component_es99_mm"] / g["notional_mm"].where(g["notional_mm"] != 0)
    g["share_of_es99"] = g["component_es99_mm"] / g["component_es99_mm"].sum()
    return g.sort_values("component_es99_mm", ascending=False)


def attribution(u: Universe, settings: Settings, r: RunResult | None = None, paths: int | None = None, as_of=None,
                alpha: float = ALPHA, band_share: float = VAR_BAND_SHARE, market_dir=None) -> dict:
    """Risk attribution of the base run (run_pipeline(u, settings, paths, as_of) unless `r` is given, made with the
    same `paths`). Returns tables (DataFrames) by position, country, region, asset class, factor and country x factor,
    the run's metrics, and the checks (sums and the factor reproduction)."""
    if r is None:
        r = run_pipeline(u, settings, label="attribution", paths=paths, as_of=as_of, market_dir=market_dir)   # EQ-B-0129
    mc = factor_run(u, settings, r, paths)
    pos = r.positions
    M, losses = mc.position_losses, mc.losses
    ec = euler_components(M, losses, alpha, band_share)
    region = u.countries.set_index("country")["region"] if "region" in u.countries.columns else pd.Series(dtype=object)
    bp = pd.DataFrame({"country": pos["country"], "region": pos["country"].map(region), "asset_class": pos["asset_class"],
                       "direction": pos["direction"], "notional_mm": pos["notional_mm"], "expected_loss_mm": M.mean(axis=0),
                       "component_var99_mm": ec["var_components"], "component_es99_mm": ec["es_components"]}, index=pos.index)
    nz = bp["notional_mm"].where(bp["notional_mm"] != 0)
    bp["marginal_var99_per_mm"] = bp["component_var99_mm"] / nz
    bp["marginal_es99_per_mm"] = bp["component_es99_mm"] / nz
    bp["share_of_es99"] = bp["component_es99_mm"] / ec["es"]
    # factors: each leg's path total over positions; its ES / VaR components on the same tail / band
    tail, _ = tail_mask(losses, alpha)
    band = var_band(losses, alpha, band_share)
    legs = {k: mc.legs[k] for k in L6.LEG_NAMES if k in (mc.legs or {})}
    fac_rows, cxf = [], {}
    for k, A in legs.items():
        tot = A.sum(axis=1)
        fac_rows.append({"factor": k, "expected_loss_mm": float(tot.mean()), "component_var99_mm": float(tot[band].mean()) * ec["var_scale"],
                         "component_es99_mm": float(tot[tail].mean())})
        cxf[k] = pd.Series(A[tail].mean(axis=0), index=pos.index).groupby(pos["country"]).sum()
    bf = pd.DataFrame(fac_rows).set_index("factor")
    bf["share_of_es99"] = bf["component_es99_mm"] / ec["es"]
    country_factor = pd.DataFrame(cxf).fillna(0.0)
    country_factor["total"] = country_factor.sum(axis=1)
    leg_sum = sum(legs.values()) if legs else np.zeros_like(M)
    m = r.mc.metrics
    checks = {
        "es99_mm": m["es99_mm"], "var99_mm": m["var99_mm"],
        "es_components_sum_mm": float(bp["component_es99_mm"].sum()),
        "es_sum_abs_diff_mm": abs(float(bp["component_es99_mm"].sum()) - m["es99_mm"]),
        "var_components_sum_mm": float(bp["component_var99_mm"].sum()),
        "var_sum_abs_diff_mm": abs(float(bp["component_var99_mm"].sum()) - m["var99_mm"]),
        "var_raw_sum_mm": ec["var_raw_sum"], "var_scale": ec["var_scale"], "var_band_paths": ec["band_paths"],
        "es_tail_paths": ec["tail_paths"],
        "factor_es_sum_abs_diff_mm": abs(float(bf["component_es99_mm"].sum()) - m["es99_mm"]),
        "factor_split_max_abs_diff_mm": float(np.max(np.abs(leg_sum - M))) if legs else float("nan"),
        "factor_rerun_bit_identical": True,
    }
    return {"run_id": r.run_id, "as_of": r.settings.get("as_of"), "paths": int(mc.paths), "seed": int(settings.seed),
            "metrics": {k: m[k] for k in ("expected_loss_mm", "var99_mm", "es99_mm", "lvar99_mm", "liquidity_cost99_mm", "gross_notional_mm")},
            "by_position": bp, "by_country": _group(bp, "country"), "by_region": _group(bp, "region"),
            "by_asset_class": _group(bp, "asset_class"), "by_factor": bf, "country_factor_es99": country_factor, "checks": checks}


# ---------------------------------------------------------------- what-if

def parse_trade(proposal: dict | str) -> dict:
    """limits.parse_proposal, except that a size of 0 is allowed (it must give the base back). Keys: country,
    asset_class (alias "instrument"), direction, notional_mm (alias "size"), duration_yrs, sector, location."""
    if isinstance(proposal, dict):
        p = dict(proposal)
        if "instrument" in p and "asset_class" not in p:
            p["asset_class"] = p.pop("instrument")
        p["asset_class"] = INSTRUMENT_ALIASES.get(str(p.get("asset_class", "")).strip().lower(), p.get("asset_class"))
        if "size" in p and "notional_mm" not in p:
            p["notional_mm"] = p.pop("size")
    else:
        p = proposal
    size = float(p["notional_mm"]) if isinstance(p, dict) else float(str(p).split(",")[3])
    if not np.isfinite(size) or size < 0:
        raise ValueError("size (notional_mm) must be a number >= 0")
    if size == 0:
        q = parse_proposal({**p, "notional_mm": 1.0}) if isinstance(p, dict) else parse_proposal(",".join(
            [*str(p).split(",")[:3], "1", *str(p).split(",")[4:]]))
        q["notional_mm"] = 0.0
        return q
    return parse_proposal(p)


def _trade_row(u: Universe, prop: dict) -> pd.DataFrame:
    row = {c: np.nan for c in u.portfolio.columns}
    row.update({"id": WHATIF_ID, "country": prop["country"], "asset_class": prop["asset_class"], "direction": prop["direction"],
                "notional_mm": prop["notional_mm"], "duration_yrs": prop["duration_yrs"], "sector": prop.get("sector", np.nan),
                "location": prop.get("location", np.nan)})
    return pd.DataFrame([row])[list(u.portfolio.columns)]


def draw_seed(settings: Settings, draw: int = 0) -> list[int]:
    """Seed of a proposed trade's own severity draws: [seed, 114] for the first (or only) trade, [seed, 114, k] for
    trade k = 1, 2, ... of a list, so every trade in a what-if has its own independent draws."""
    return [int(settings.seed), WHATIF_SEED_SALT] + ([int(draw)] if draw else [])


def trade_path_loss(u: Universe, settings: Settings, r: RunResult, prop: dict, draw: int = 0) -> tuple[np.ndarray, pd.Series, dict]:
    """The proposed position's loss on each of the base run's paths, its build_positions row, and its factor legs.
    `draw` picks the trade's own severity draws (draw_seed): 0 for a single trade, k for the k-th trade of a list."""
    port = _trade_row(u, prop)
    u1 = replace(u, portfolio=port)
    mults = L4.position_multipliers(port, settings)
    df = r.mc.df
    prow = L6.build_positions(u1, r.country, settings, mults, df).iloc[0]
    j = list(u.names).index(prop["country"])
    x = r.mc.latent[:, j]
    zz = x / np.sqrt(df / (df - 2))
    mm, ov, cod = L6.market_move(settings), L6.default_spread_overlap(settings), L6.carry_on_default(settings)
    zn = L6.normal_score(x, df) if mm != "linear" else None
    uu = np.random.default_rng(draw_seed(settings, draw)).random((len(x), 2))
    L, _Lu, legs = L6.position_path_loss(prow, x, zz, uu[:, 0], uu[:, 1], settings, df, mm, ov, cod, zn, legs=True)
    return L, prow, legs


def whatif(u: Universe, settings: Settings, proposal: dict | str | list, limits: dict, r: RunResult | None = None,
           paths: int | None = None, as_of=None, market_dir=None) -> dict:
    """Base run (or `r`) plus one proposed trade, on the base run's paths. Returns before / after / change for EL,
    VaR95/99, ES95/99, liquidity cost and L-VaR99, the first-order (Euler) estimate of the change, the trade's own
    numbers, the limit tables before and after, and a verdict: accept, flag (a warning level crossed) or refuse.
    A list of proposals goes to whatif_many (combined result plus per-trade marginals)."""
    if isinstance(proposal, (list, tuple)):
        return whatif_many(u, settings, list(proposal), limits, r=r, paths=paths, as_of=as_of, market_dir=market_dir)
    prop = parse_trade(proposal)
    if prop["country"] not in u.names:
        raise ValueError(f"unknown country {prop['country']!r}; one of {list(u.names)}")
    if r is None:
        r = run_pipeline(u, settings, label="whatif-base", paths=paths, as_of=as_of, market_dir=market_dir)
    L, prow, legs = trade_path_loss(u, settings, r, prop)
    base_losses = r.mc.losses
    new_losses = base_losses + L
    mb = r.mc.metrics
    trade_liq = float(L5.liquidity_cost(pd.DataFrame([{"id": WHATIF_ID, "country": prop["country"], "asset_class": prop["asset_class"],
                                                       "notional_mm": prop["notional_mm"]}]), r.country["regime"], settings, ALPHA).iloc[0])
    ma = _tail_metrics(new_losses, mb["liquidity_cost99_mm"] + trade_liq)
    gross_b = float(mb["gross_notional_mm"])
    ma["gross_notional_mm"] = gross_b + prop["notional_mm"]
    keys = ("expected_loss_mm", "var95_mm", "var99_mm", "es95_mm", "es99_mm", "liquidity_cost99_mm", "lvar99_mm", "gross_notional_mm")
    before = {k: float(mb[k]) for k in keys}
    after = {k: float(ma[k]) for k in keys}
    # first-order (Euler) estimate: the trade's mean loss on the base tail / VaR band
    tail_b, _ = tail_mask(base_losses)
    band_b = var_band(base_losses)
    first = {"es99_mm": float(L[tail_b].mean()), "var99_mm": float(L[band_b].mean()), "expected_loss_mm": float(L.mean())}
    first["lvar99_mm"] = first["var99_mm"] + trade_liq
    # limits: the after book as check_book reads it
    tail_a, _ = tail_mask(new_losses)
    Ma = np.column_stack([r.mc.position_losses, L])
    pos_a = pd.concat([r.positions, prow.to_frame().T.assign(notional_mm=prop["notional_mm"])])
    pos_a["notional_mm"] = pos_a["notional_mm"].astype(float)
    contrib_a = pd.DataFrame({"country": pos_a["country"], "asset_class": pos_a["asset_class"], "notional_mm": pos_a["notional_mm"],
                              "expected_loss_mm": Ma.mean(axis=0), "tail_contribution_99_mm": Ma[tail_a].mean(axis=0)}, index=pos_a.index)
    after_run = SimpleNamespace(metrics={**mb, **ma}, positions=pos_a, mc=SimpleNamespace(contributions=contrib_a), country=r.country)
    lim_b = check_book(r, u, limits)
    lim_a = check_book(after_run, u, limits)
    breaches, warnings = _reasons(lim_a, lim_b)
    verdict = "refuse" if breaches else "flag" if warnings else "accept"
    book = lim_a[lim_a["scope"] == "book"].set_index("measure")
    return {"run_id": r.run_id, "as_of": r.settings.get("as_of"), "paths": int(r.mc.paths), "seed": int(settings.seed),
            "proposal": {k: (None if isinstance(v, float) and np.isnan(v) else v) for k, v in prop.items()},
            "trade": {"pd_default": float(prow["pd_default"]), "market_vol_pct": float(prow["market_vol_pct"]),
                      "carry_mm": float(prow["carry_mm"]), "liquidity_cost99_mm": trade_liq,
                      "expected_loss_mm": float(L.mean()), "standalone_var99_mm": float(np.quantile(L, ALPHA)),
                      "tail_mean_on_new_tail_mm": float(L[tail_a].mean()),
                      "legs_es99_on_new_tail_mm": {k: float(v[tail_a].mean()) for k, v in legs.items()}},
            "before": before, "after": after, "change": {k: after[k] - before[k] for k in keys},
            "first_order_change": first,
            "limit_usage": {k: {"value": float(book.at[k, "value"]), "limit": float(book.at[k, "limit"]),
                                "utilisation": float(book.at[k, "utilisation"]), "status": book.at[k, "status"]}
                            for k in BOOK_MEASURES if k in book.index},
            "verdict": verdict, "reasons": breaches + warnings, "breaches": breaches, "warnings": warnings,
            "limits_before": lim_b, "limits_after": lim_a}


def _trade_liq(settings: Settings, r: RunResult, prop: dict, pid: str = WHATIF_ID) -> float:
    return float(L5.liquidity_cost(pd.DataFrame([{"id": pid, "country": prop["country"], "asset_class": prop["asset_class"],
                                                  "notional_mm": prop["notional_mm"]}]), r.country["regime"], settings, ALPHA).iloc[0])


def whatif_many(u: Universe, settings: Settings, proposals: list, limits: dict, r: RunResult | None = None,
                paths: int | None = None, as_of=None, market_dir=None) -> dict:
    """Several proposed trades at once on the base run's paths (HO-20261025-C-B-008). Trade k is priced with its own
    severity draws (draw_seed(settings, k)); the first trade's draws are the single-trade ones, so a one-trade list
    gives the same numbers as whatif(trade). After losses = base losses + the trades' path losses; liquidity cost and
    gross notional add up; limits are graded on the after book.

    Returns the whatif keys for the combined book (before, after, change, first_order_change = sum of the trades'
    first-order estimates, limit_usage, verdict, reasons, breaches, warnings, limits_before, limits_after) plus
    `trades`, one entry per proposal: its proposal and id; marginal_var99_mm / marginal_es99_mm / marginal_lvar99_mm
    (after book minus the after book without this trade, the leave-one-out increment; the book without it is
    rebuilt as base + the other trades, so for one trade the marginal is exactly the change); component_es99_mm
    and component_var99_mm (Euler, on the after book's tail and VaR band; the components of all positions sum to the
    after ES99 / VaR99); share_of_es99; expected_loss_mm; first-order estimates on the base tail; pd_default,
    market_vol_pct, carry_mm, liquidity_cost99_mm and the draw seed. A list of zero-size trades gives the base."""
    props = [parse_trade(p) for p in proposals]
    for p in props:
        if p["country"] not in u.names:
            raise ValueError(f"unknown country {p['country']!r}; one of {list(u.names)}")
    if r is None:
        r = run_pipeline(u, settings, label="whatif-base", paths=paths, as_of=as_of, market_dir=market_dir)
    ids = [WHATIF_ID if k == 0 else f"{WHATIF_ID}{k + 1}" for k in range(len(props))]
    Ls, prows, liqs = [], [], []
    for k, (p, pid) in enumerate(zip(props, ids)):
        L, prow, _legs = trade_path_loss(u, settings, r, p, draw=k)
        Ls.append(L); prows.append(prow); liqs.append(_trade_liq(settings, r, p, pid))
    base_losses = r.mc.losses
    mb = r.mc.metrics

    def book(skip: int | None = None) -> tuple[np.ndarray, float, float]:
        new = base_losses
        for k, L in enumerate(Ls):
            if k != skip:
                new = new + L
        liq = float(mb["liquidity_cost99_mm"]) + sum(x for k, x in enumerate(liqs) if k != skip)
        gross = float(mb["gross_notional_mm"]) + sum(p["notional_mm"] for k, p in enumerate(props) if k != skip)
        return new, liq, gross

    new_losses, liq_a, gross_a = book()
    ma = _tail_metrics(new_losses, liq_a)
    ma["gross_notional_mm"] = gross_a
    keys = ("expected_loss_mm", "var95_mm", "var99_mm", "es95_mm", "es99_mm", "liquidity_cost99_mm", "lvar99_mm", "gross_notional_mm")
    before = {k: float(mb[k]) for k in keys}
    after = {k: float(ma[k]) for k in keys}
    tail_b, _ = tail_mask(base_losses)
    band_b = var_band(base_losses)
    tail_a, _ = tail_mask(new_losses)
    Ma = np.column_stack([r.mc.position_losses, *Ls]) if Ls else r.mc.position_losses
    ec = euler_components(Ma, new_losses) if Ls else None
    P0 = r.mc.position_losses.shape[1]
    rows = [prow.to_frame().T.set_axis([pid]).assign(notional_mm=p["notional_mm"]) for prow, pid, p in zip(prows, ids, props)]
    pos_a = pd.concat([r.positions, *rows]) if rows else r.positions.copy()
    pos_a["notional_mm"] = pos_a["notional_mm"].astype(float)
    contrib_a = pd.DataFrame({"country": pos_a["country"], "asset_class": pos_a["asset_class"], "notional_mm": pos_a["notional_mm"],
                              "expected_loss_mm": Ma.mean(axis=0), "tail_contribution_99_mm": Ma[tail_a].mean(axis=0)}, index=pos_a.index)
    after_run = SimpleNamespace(metrics={**mb, **ma}, positions=pos_a, mc=SimpleNamespace(contributions=contrib_a), country=r.country)
    lim_b = check_book(r, u, limits)
    lim_a = check_book(after_run, u, limits)
    breaches, warnings = _reasons(lim_a, lim_b)
    verdict = "refuse" if breaches else "flag" if warnings else "accept"
    bk = lim_a[lim_a["scope"] == "book"].set_index("measure")
    trades, first = [], {"es99_mm": 0.0, "var99_mm": 0.0, "expected_loss_mm": 0.0, "lvar99_mm": 0.0}
    for k, (p, pid, L, prow, lq) in enumerate(zip(props, ids, Ls, prows, liqs)):
        w_losses, w_liq, _ = book(skip=k)
        w = _tail_metrics(w_losses, w_liq)
        fo = {"es99_mm": float(L[tail_b].mean()), "var99_mm": float(L[band_b].mean()), "expected_loss_mm": float(L.mean())}
        fo["lvar99_mm"] = fo["var99_mm"] + lq
        for kk in first:
            first[kk] += fo[kk]
        comp_es = float(ec["es_components"][P0 + k]); comp_var = float(ec["var_components"][P0 + k])
        trades.append({"id": pid, "proposal": {kk: (None if isinstance(v, float) and np.isnan(v) else v) for kk, v in p.items()},
                       "marginal_var99_mm": after["var99_mm"] - w["var99_mm"], "marginal_es99_mm": after["es99_mm"] - w["es99_mm"],
                       "marginal_lvar99_mm": after["lvar99_mm"] - w["lvar99_mm"],
                       "component_es99_mm": comp_es, "component_var99_mm": comp_var,
                       "share_of_es99": comp_es / after["es99_mm"] if after["es99_mm"] else None,
                       "expected_loss_mm": float(L.mean()), "first_order_change": fo,
                       "pd_default": float(prow["pd_default"]), "market_vol_pct": float(prow["market_vol_pct"]),
                       "carry_mm": float(prow["carry_mm"]), "liquidity_cost99_mm": lq, "draw_seed": draw_seed(settings, k)})
    return {"run_id": r.run_id, "as_of": r.settings.get("as_of"), "paths": int(r.mc.paths), "seed": int(settings.seed),
            "proposals": [t["proposal"] for t in trades], "trades": trades,
            "before": before, "after": after, "change": {k: after[k] - before[k] for k in keys},
            "first_order_change": first,
            "limit_usage": {k: {"value": float(bk.at[k, "value"]), "limit": float(bk.at[k, "limit"]),
                                "utilisation": float(bk.at[k, "utilisation"]), "status": bk.at[k, "status"]}
                            for k in BOOK_MEASURES if k in bk.index},
            "verdict": verdict, "reasons": breaches + warnings, "breaches": breaches, "warnings": warnings,
            "limits_before": lim_b, "limits_after": lim_a}


# ---------------------------------------------------------------- output

def to_jsonable(res: dict) -> dict:
    """JSON-ready copy: DataFrames become record lists (index kept as a column), numpy numbers become floats."""
    def conv(v):
        if isinstance(v, pd.DataFrame):
            return json.loads(v.reset_index().to_json(orient="records"))
        if isinstance(v, pd.Series):
            return json.loads(v.to_json())
        if isinstance(v, dict):
            return {k: conv(x) for k, x in v.items()}
        if isinstance(v, (np.floating, np.integer)):
            return v.item()
        if isinstance(v, np.bool_):
            return bool(v)
        return v
    return conv(res)


def _fmt_table(df: pd.DataFrame, cols: list[str], n: int = 20) -> str:
    return df[cols].head(n).to_string(float_format=lambda x: f"{x:,.3f}")


def _load(data: str):
    from ..ingestion import load_universe
    return load_universe(data), Settings.load(Path(data) / "assumptions.json")


def _write(res: dict, out: str | None, as_of: str, name: str) -> Path | None:
    if not out:
        return None
    from ..validation.activation import resolve_out_dir     # --out must be under outputs/ (same rule as the other runners)
    d = resolve_out_dir(out, as_of)
    d.mkdir(parents=True, exist_ok=True)
    p = d / name
    p.write_text(json.dumps(to_jsonable(res), indent=1, default=str), encoding="utf-8")
    return p


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.engine.portfolio_risk", description="Portfolio risk analytics (EQ-B-0114)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("attribution", "whatif"):
        p = sub.add_parser(name)
        p.add_argument("--data", default="data"); p.add_argument("--as-of", required=True)
        p.add_argument("--paths", type=int, help="Monte Carlo paths (default: assumptions.json, 100,000 -> 131,072 Sobol)")
        p.add_argument("--out", help="folder under outputs/ for the JSON result (attribution.json / whatif.json)")
    w = sub.choices["whatif"]
    w.add_argument("--country", required=True); w.add_argument("--instrument", required=True, help="asset class: FX, Local bond, Eurobond, Equity, CDS protection")
    w.add_argument("--direction", default="Long", choices=["Long", "Short", "long", "short"])
    w.add_argument("--size", type=float, required=True, help="notional, $mm (0 gives the base back)")
    w.add_argument("--duration", type=float, help="years (default 5 for bonds and CDS)")
    w.add_argument("--limits", help="limits file (default: <data>/limits.json)")
    a = ap.parse_args(argv)
    u, s = _load(a.data)
    if a.cmd == "attribution":
        res = attribution(u, s, paths=a.paths, as_of=a.as_of, market_dir=a.data)
        m, c = res["metrics"], res["checks"]
        print(f"run {res['run_id']} as_of {res['as_of']}, {res['paths']:,} paths: VaR99 {m['var99_mm']:.2f}, ES99 {m['es99_mm']:.2f}, "
              f"EL {m['expected_loss_mm']:.2f}, L-VaR99 {m['lvar99_mm']:.2f} $mm")
        cols = ["notional_mm", "expected_loss_mm", "component_var99_mm", "component_es99_mm", "marginal_es99_per_mm", "share_of_es99"]
        print("\nBy country\n" + _fmt_table(res["by_country"], cols))
        print("\nBy factor\n" + _fmt_table(res["by_factor"], ["expected_loss_mm", "component_var99_mm", "component_es99_mm", "share_of_es99"]))
        print(f"\nChecks: ES components sum {c['es_components_sum_mm']:.6f} vs ES99 {c['es99_mm']:.6f}; VaR components sum "
              f"{c['var_components_sum_mm']:.6f} (raw {c['var_raw_sum_mm']:.3f}, scale {c['var_scale']:.4f}, {c['var_band_paths']} paths); "
              f"factor split max diff {c['factor_split_max_abs_diff_mm']:.2e}")
    else:
        lim = load_limits(a.limits or Path(a.data) / "limits.json")
        prop = {"country": a.country, "asset_class": a.instrument, "direction": a.direction.capitalize(), "notional_mm": a.size}
        if a.duration is not None:
            prop["duration_yrs"] = a.duration
        try:
            res = whatif(u, s, prop, lim, paths=a.paths, as_of=a.as_of, market_dir=a.data)
        except ValueError as e:
            ap.error(str(e))
        b, af = res["before"], res["after"]
        print(f"what-if on run {res['run_id']} ({res['paths']:,} paths): {a.direction.capitalize()} {a.size:g} $mm {a.instrument} {a.country}")
        for k in ("expected_loss_mm", "var99_mm", "es99_mm", "lvar99_mm"):
            lu = res["limit_usage"].get(k, {})
            print(f"  {k:<18} {b[k]:9.3f} -> {af[k]:9.3f} ({af[k] - b[k]:+.3f}; first order {res['first_order_change'].get(k, float('nan')):+.3f})"
                  + (f"  limit {lu['limit']:.1f}: {lu['utilisation'] * 100:.0f}% {lu['status']}" if lu else ""))
        print(f"verdict: {res['verdict']}" + "".join(f"\n  - {x}" for x in res["reasons"]))
    try:
        p = _write(res, a.out, a.as_of, f"{a.cmd}.json")
    except ValueError as e:
        ap.error(str(e))
    if p:
        print(f"written {p}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
