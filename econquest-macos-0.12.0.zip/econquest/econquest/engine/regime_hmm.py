"""Layer 3b: fitted hidden-Markov regimes on the market history (roadmap item "HMM regime fitting").

Replaces the rule-based Calm / Stressed / Crisis state with a 3-state Gaussian HMM fitted on weekly
market features pooled across countries, keeping `rule_regime` as the fallback, and reports the fitted
transition matrix against the one in assumptions.json.

Features (weekly, Friday close, from data/market_history/prices.csv):
* `dep_4w`     4-week FX depreciation in percent (USDxxx up = weaker local currency, positive).
* `fxvol_4w`   4-week realised FX volatility, annualised percent, from daily log returns.
* `etf_4w`     4-week ETF total return in percent (NaN when the country has no ETF in countries.csv).
* `etfvol_4w`  4-week realised ETF volatility, annualised percent (NaN when no ETF).

Missing ETF columns are imputed with the pooled cross-sectional mean of that week (the mean over the
countries that do have an ETF), so the emission model keeps one dimension for every country-week and
the ETF columns carry the market-wide equity move for countries without a listed ETF. A country with no
FX series and no ETF (Zimbabwe) gets no features and falls back to the rule regime. Features are
winsorised at the pooled 1st / 99th percentiles before standardisation (Argentina's December 2023
devaluation and a bad USDVES print would otherwise dominate the variances).

States are ordered by the mean of standardised (depreciation + FX volatility): 0 Calm, 1 Stressed,
2 Crisis. The fitted matrix is weekly; the 12-month matrix is its 52nd power.

FX-only prices.csv (EQ-B-0077): when no country has an ETF series (the official BIS/ECB price history has none),
the ETF features cannot be imputed (there is no cross-section to average), so the HMM is fitted on the two FX
features only; `info["features"]` lists the features used, `info["etf_feature"]` says why the ETF ones were
dropped, and a RuntimeWarning is raised when the HMM is in use (regime.method hmm or blend; the shipped method is
rules). With ETF columns present the four-feature model is unchanged.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np
import pandas as pd
from ..config import Settings, REGIMES
from ..ingestion import Universe
from .layer3_regime import GaussianHMM, rule_regime, transition_matrix

FX_FEATURES = ("dep_4w", "fxvol_4w")
ETF_FEATURES = ("etf_4w", "etfvol_4w")
FEATURES = FX_FEATURES + ETF_FEATURES
WINDOW_DAYS = 20          # trading days in the 4-week window
MIN_COVERAGE = 0.5        # a series must be present on at least this share of weeks to count
METHODS = ("rules", "hmm", "blend")


def _realised_vol(px: pd.Series) -> pd.Series:
    r = np.log(px).diff()
    return r.rolling(WINDOW_DAYS, min_periods=int(WINDOW_DAYS * 0.75)).std() * np.sqrt(252) * 100


def weekly_features(prices: pd.DataFrame, countries: pd.DataFrame) -> dict[str, pd.DataFrame]:
    """Weekly (Friday) feature frames per country. Countries without an FX series and without an ETF are omitted."""
    px = prices.copy()
    if "date" in px.columns:
        px = px.set_index("date")
    px.index = pd.to_datetime(px.index)
    px = px.sort_index().apply(pd.to_numeric, errors="coerce")
    px = px[~px.index.duplicated(keep="last")]
    bdays = px.index.dayofweek < 5
    px = px[bdays].ffill(limit=5)                       # weekend rows dropped, gaps of up to a week carried forward
    out: dict[str, pd.DataFrame] = {}
    for _, row in countries.iterrows():
        c = str(row["country"])
        fxcol = "USD" + str(row.get("currency", "") or "").strip()
        etf = str(row.get("etf", "") or "").strip()
        etf = etf if etf and etf.lower() != "nan" else ""
        feats = {}
        if fxcol in px.columns and px[fxcol].notna().mean() >= MIN_COVERAGE:
            fx = px[fxcol]
            feats["dep_4w"] = (fx / fx.shift(WINDOW_DAYS) - 1) * 100
            feats["fxvol_4w"] = _realised_vol(fx)
        if etf and etf in px.columns and px[etf].notna().mean() >= MIN_COVERAGE:
            e = px[etf]
            feats["etf_4w"] = (e / e.shift(WINDOW_DAYS) - 1) * 100
            feats["etfvol_4w"] = _realised_vol(e)
        if not feats:
            continue
        daily = pd.DataFrame(feats)
        weekly = daily.resample("W-FRI").last()
        for f in FEATURES:
            if f not in weekly.columns:
                weekly[f] = np.nan
        weekly = weekly[list(FEATURES)]
        weekly = weekly[weekly[list(FX_FEATURES)].notna().any(axis=1) | weekly[list(ETF_FEATURES)].notna().any(axis=1)]
        weekly = weekly.dropna(how="all")
        if len(weekly) >= 8:
            out[c] = weekly
    return out


@dataclass
class HMMFit:
    model: GaussianHMM
    features: tuple[str, ...]
    means: np.ndarray            # standardisation (original units)
    sds: np.ndarray
    lower: np.ndarray            # winsorisation bounds (original units)
    upper: np.ndarray
    transition_weekly: np.ndarray
    transition_12m: np.ndarray
    state_means: pd.DataFrame    # states x features, original units
    loglik: float
    n_obs: int
    countries: list[str]
    imputed_share: float         # share of country-weeks whose ETF columns were imputed
    weeks: pd.DatetimeIndex = field(default_factory=lambda: pd.DatetimeIndex([]))

    def prepare(self, df: pd.DataFrame, pooled_etf: pd.DataFrame | None = None) -> np.ndarray:
        """Impute, winsorise and standardise one country's feature frame with the fitted parameters."""
        X = df[list(self.features)].copy()
        for f in ETF_FEATURES:
            if f in X.columns and X[f].isna().any():
                fill = pooled_etf[f].reindex(X.index) if pooled_etf is not None and f in pooled_etf else pd.Series(np.nan, index=X.index)
                X[f] = X[f].fillna(fill).fillna(self.means[list(self.features).index(f)])
        X = X.ffill().bfill()
        Z = (X.to_numpy(dtype=float).clip(self.lower, self.upper) - self.means) / self.sds
        return np.nan_to_num(Z)


def _pooled_etf(features: dict[str, pd.DataFrame]) -> pd.DataFrame:
    """Cross-sectional mean of the ETF features by week over the countries that have an ETF."""
    frames = [df[list(ETF_FEATURES)] for df in features.values() if df[list(ETF_FEATURES)].notna().any().any()]
    if not frames:
        return pd.DataFrame(columns=list(ETF_FEATURES))
    return pd.concat(frames).groupby(level=0).mean()


def has_etf_features(features: dict[str, pd.DataFrame]) -> bool:
    """True when at least one country has an ETF feature value (EQ-B-0077: false on an FX-only price history)."""
    return any(df[list(ETF_FEATURES)].notna().any().any() for df in features.values())


def fit_pooled_hmm(features: dict[str, pd.DataFrame], n_states: int = 3, seed: int = 7, n_iter: int = 200) -> HMMFit:
    if not features:
        raise ValueError("no country has usable market features")
    # EQ-B-0077: with no ETF anywhere the ETF columns would be all NaN after imputation; fit on the FX features only
    feats = FEATURES if has_etf_features(features) else FX_FEATURES
    pooled_etf = _pooled_etf(features)
    frames = []
    n_imputed = n_total = 0
    for c, df in features.items():
        X = df[list(feats)].copy()
        for f in (ETF_FEATURES if feats == FEATURES else ()):
            miss = X[f].isna()
            n_imputed += int(miss.sum()); n_total += len(X)
            X[f] = X[f].fillna(pooled_etf[f].reindex(X.index) if f in pooled_etf else np.nan)
        X = X.ffill().bfill()
        X["__country"] = c
        frames.append(X)
    pooled = pd.concat(frames)
    raw = pooled[list(feats)]
    raw = raw.fillna(raw.mean())
    lower, upper = raw.quantile(0.01).to_numpy(), raw.quantile(0.99).to_numpy()
    W = raw.to_numpy(dtype=float).clip(lower, upper)
    means, sds = W.mean(axis=0), W.std(axis=0) + 1e-9
    Z = (W - means) / sds
    m = GaussianHMM(n_states=n_states, n_iter=n_iter, seed=seed).fit(Z)
    # order states by turbulence: mean standardised (depreciation + FX vol) ascending -> 0 Calm, 1 Stressed, 2 Crisis
    turb = m.mu[:, 0] + m.mu[:, 1]
    order = np.argsort(turb)
    m.mu, m.var, m.pi = m.mu[order], m.var[order], m.pi[order]
    m.A = m.A[np.ix_(order, order)]
    A = m.A / m.A.sum(axis=1, keepdims=True)
    # initial distribution for decoding any single country's sequence: the stationary distribution of A (the pooled fit's
    # pi describes only the first week of the first country)
    w, v = np.linalg.eig(A.T)
    stat = np.real(v[:, np.argmin(np.abs(w - 1))]); stat = np.abs(stat) / np.abs(stat).sum()
    m.pi = stat
    state_means = pd.DataFrame(m.mu * sds + means, index=list(REGIMES[:n_states]), columns=list(feats))
    return HMMFit(model=m, features=feats, means=means, sds=sds, lower=lower, upper=upper,
                  transition_weekly=A, transition_12m=np.linalg.matrix_power(A, 52), state_means=state_means,
                  loglik=float(m.loglik_) if m.loglik_ is not None else float("nan"), n_obs=int(len(Z)),
                  countries=list(features), imputed_share=float(n_imputed / max(1, n_total)),
                  weeks=pd.DatetimeIndex(sorted(pooled.index.unique())))


def decode_regimes(fit: HMMFit, features: dict[str, pd.DataFrame]) -> pd.DataFrame:
    """Per country: Viterbi state of the latest week, smoothed posterior for that week, run length, label."""
    pooled_etf = _pooled_etf(features)
    rows = {}
    for c, df in features.items():
        Z = fit.prepare(df, pooled_etf)
        states = fit.model.decode(Z)
        post = fit.model.posterior(Z)[-1]
        cur = int(states[-1])
        run = 1
        while run < len(states) and states[-1 - run] == cur:
            run += 1
        rows[c] = {"state": cur, "regime_hmm": REGIMES[cur], "p_calm": float(post[0]), "p_stressed": float(post[1]),
                   "p_crisis": float(post[2]) if len(post) > 2 else 0.0, "weeks_in_state": run,
                   "as_of": df.index[-1], **{f: float(df[f].iloc[-1]) for f in fit.features}}
    out = pd.DataFrame(rows).T
    for k in ("state", "weeks_in_state"):
        out[k] = out[k].astype(int)
    for k in ("p_calm", "p_stressed", "p_crisis", *fit.features):
        out[k] = out[k].astype(float)
    return out


def _apply_override(s: pd.Series, settings: Settings) -> pd.Series:
    ov = settings.scenario_override
    if ov == "All crisis":
        return pd.Series("Crisis", index=s.index, name="regime")
    if ov == "All stressed":
        return s.where(s == "Crisis", "Stressed").rename("regime")
    return s.rename("regime")


def hmm_regimes(u: Universe, settings: Settings, prices: pd.DataFrame | None = None, method: str | None = None) -> tuple[pd.Series, dict]:
    """Regime series for the pipeline under `regime.method` (rules | hmm | blend) plus a diagnostics dict.

    The HMM is fitted when the method is hmm or blend and prices are available; countries without features
    keep the rule regime (listed in info['fallback']). `scenario_override` is applied after the method."""
    method = (method or settings.get("regime", "method", default="rules") or "rules").lower()
    if method not in METHODS:
        raise ValueError(f"regime.method must be one of {METHODS}, got {method!r}")
    plain = settings.copy_with(); plain.scenario_override = "Model"
    rule = rule_regime(u, plain)                      # unoverridden rule regime
    info: dict = {"method": method, "fitted": False, "fallback": [], "assumptions_12m": transition_matrix(settings).tolist()}
    prices = u.prices if prices is None else prices
    if method == "rules" or prices is None or len(prices) == 0:
        if method != "rules":
            info["fallback"] = list(u.names); info["reason"] = "no market history"
        info["regime_rule"] = rule.to_dict()
        return _apply_override(rule, settings), info
    try:
        feats = weekly_features(prices, u.countries)
        fit = fit_pooled_hmm(feats, seed=int(settings.get("regime", "hmm_seed", default=settings.seed)))
        dec = decode_regimes(fit, feats)
    except Exception as e:                            # a failed fit must never stop the pipeline
        info["fallback"] = list(u.names); info["reason"] = f"fit failed: {e}"
        info["regime_rule"] = rule.to_dict()
        return _apply_override(rule, settings), info
    hmm = pd.Series(index=u.names, dtype=object)
    for c in u.names:
        hmm[c] = dec.at[c, "regime_hmm"] if c in dec.index else None
    fallback = [c for c in u.names if hmm[c] is None]
    chosen = pd.Series([hmm[c] if hmm[c] is not None else rule[c] for c in u.names], index=u.names)
    if method == "blend":
        rank = {r: i for i, r in enumerate(REGIMES)}
        chosen = pd.Series([max(rule[c], chosen[c], key=rank.get) for c in u.names], index=u.names)
    both = [c for c in u.names if hmm[c] is not None]
    agree = float(np.mean([rule[c] == hmm[c] for c in both])) if both else float("nan")
    comparison = pd.DataFrame({"regime_rule": rule, "regime_hmm": hmm, "regime": chosen,
                               "p_calm": dec["p_calm"].reindex(u.names), "p_stressed": dec["p_stressed"].reindex(u.names),
                               "p_crisis": dec["p_crisis"].reindex(u.names), "weeks_in_state": dec["weeks_in_state"].reindex(u.names),
                               "dep_4w": dec["dep_4w"].reindex(u.names), "fxvol_4w": dec["fxvol_4w"].reindex(u.names)})
    etf_note = ("" if fit.features == FEATURES else
                "no ETF series in prices.csv (FX-only price history, EQ-B-0077): HMM fitted on dep_4w and fxvol_4w only")
    if etf_note:
        import warnings
        warnings.warn(f"regime.method {method!r}: {etf_note}", RuntimeWarning, stacklevel=2)
    info.update({"fitted": True, "fallback": fallback, "features": list(fit.features), "etf_feature": etf_note or "used",
                 "reason": {c: ("no FX series and no ETF in prices.csv" if c in fallback else "") for c in fallback},
                 "transition_weekly": fit.transition_weekly.tolist(), "transition_12m": fit.transition_12m.tolist(),
                 "state_means": fit.state_means.round(4).to_dict(orient="index"),
                 "state_counts": {r: int((hmm == r).sum()) for r in REGIMES},
                 "loglik": fit.loglik, "n_country_weeks": fit.n_obs, "n_countries_fitted": len(fit.countries),
                 "imputed_etf_share": fit.imputed_share, "winsor_bounds": {f: [float(lo), float(hi)] for f, lo, hi in zip(fit.features, fit.lower, fit.upper)},
                 "sample": {"start": str(fit.weeks.min().date()), "end": str(fit.weeks.max().date()), "weeks": int(len(fit.weeks))},
                 "agreement_rate": agree, "regime_rule": rule.to_dict(), "regime_hmm": {c: hmm[c] for c in u.names},
                 "probabilities": {c: {"p_calm": float(dec.at[c, "p_calm"]), "p_stressed": float(dec.at[c, "p_stressed"]), "p_crisis": float(dec.at[c, "p_crisis"]),
                                       "weeks_in_state": int(dec.at[c, "weeks_in_state"]), "as_of": str(pd.Timestamp(dec.at[c, "as_of"]).date())} for c in both},
                 "comparison": comparison.reset_index().rename(columns={"index": "country"}).to_dict(orient="records"),
                 "scenario_override": settings.scenario_override})
    return _apply_override(chosen, settings), info


def hmm_report(info: dict, var_table: pd.DataFrame | None = None) -> str:
    """Markdown report of a fitted HMM against the rules (used by `econquest regimes`)."""
    L = ["# Fitted HMM regimes vs the rule regimes", ""]
    L.append(f"Method `{info.get('method')}`; fitted: {info.get('fitted')}; scenario override: {info.get('scenario_override', 'Model')}.")
    if not info.get("fitted"):
        L.append(f"HMM not fitted: {info.get('reason')}. All countries use the rule regime.")
        return "\n".join(L) + "\n"
    s = info["sample"]
    feats = list(info.get("features") or FEATURES)
    etf_txt = (f"ETF columns imputed with the weekly cross-sectional mean for {info['imputed_etf_share']*100:.0f} percent of country-weeks."
               if set(ETF_FEATURES) <= set(feats) else f"ETF features not used: {info.get('etf_feature')}.")
    L.append(f"Sample: {info['n_countries_fitted']} countries, {info['n_country_weeks']} country-weeks, weeks {s['start']} to {s['end']} "
             f"({s['weeks']} weeks); log-likelihood {info['loglik']:.1f}; {etf_txt}")
    L += ["", "## Transition matrices", "", "Fitted weekly matrix (rows: from Calm, Stressed, Crisis):", ""]
    L += _matrix_md(info["transition_weekly"])
    L += ["", "Fitted 12-month matrix (weekly matrix to the 52nd power):", ""]
    L += _matrix_md(info["transition_12m"])
    L += ["", "Assumptions.json 12-month matrix:", ""]
    L += _matrix_md(info["assumptions_12m"])
    L += ["", "## State means (original units)", "", "| State | " + " | ".join(feats) + " |", "|---|" + "---|" * len(feats)]
    for st, row in info["state_means"].items():
        L.append(f"| {st} | " + " | ".join(f"{row[f]:.2f}" for f in feats) + " |")
    L += ["", "## Today's regimes", "", f"Agreement rate rule vs HMM over the fitted countries: {info['agreement_rate']*100:.1f} percent. "
          f"HMM counts: {info['state_counts']}.", "",
          "| Country | Rule | HMM | Chosen | p_calm | p_stressed | p_crisis | weeks in state | dep 4w % | FX vol 4w % |", "|---|---|---|---|---|---|---|---|---|---|"]
    for r in info["comparison"]:
        p = (lambda k, r=r: "" if r.get(k) is None or (isinstance(r.get(k), float) and np.isnan(r[k])) else f"{r[k]:.2f}")
        w = r.get("weeks_in_state"); w = "" if w is None or (isinstance(w, float) and np.isnan(w)) else int(w)
        L.append(f"| {r['country']} | {r['regime_rule']} | {r['regime_hmm'] or 'n/a'} | {r['regime']} | {p('p_calm')} | {p('p_stressed')} | {p('p_crisis')} | {w} | {p('dep_4w')} | {p('fxvol_4w')} |")
    L += ["", "## Fallback to the rule regime", ""]
    if info["fallback"]:
        for c in info["fallback"]:
            L.append(f"- {c}: {info['reason'].get(c, '') if isinstance(info.get('reason'), dict) else info.get('reason')}")
    else:
        L.append("None.")
    if var_table is not None and len(var_table):
        L += ["", "## Book risk by regime method", "", "| Method | VaR99 $mm | ES99 $mm | Global regime | Not calm |", "|---|---|---|---|---|"]
        for m, r in var_table.iterrows():
            L.append(f"| {m} | {r['var99']:.2f} | {r['es99']:.2f} | {r.get('global_regime', '')} | {r.get('share_not_calm', float('nan')):.2f} |")
    return "\n".join(L) + "\n"


def _matrix_md(M) -> list[str]:
    M = np.asarray(M, dtype=float)
    out = ["| From \\ To | Calm | Stressed | Crisis |", "|---|---|---|---|"]
    for i, r in enumerate(REGIMES):
        out.append(f"| {r} | " + " | ".join(f"{M[i, j]:.3f}" for j in range(3)) + " |")
    return out
