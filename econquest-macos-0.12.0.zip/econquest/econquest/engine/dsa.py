"""Debt sustainability analysis and reserve adequacy (roadmap 3.1, 3.2).

`debt_history` rebuilds each country's debt dynamics from the WEO history and projections in
data/live/raw_weo.csv: d_t = d_{t-1} (1+i)/(1+g) - pb_t + sfa_t, with the effective nominal interest
rate i = interest / d_{t-1} (interest = primary minus overall balance), nominal growth g, the primary
balance pb and the stock-flow adjustment sfa as the residual. `stochastic_dsa` runs a fan chart
around the WEO baseline: AR(1) shocks to growth, the primary balance and the interest rate drawn from
the country's own history (winsorised covariance), an iid stock-flow shock, and a currency channel
that revalues the foreign-currency share of the debt (indicator 1.5) with the regime's FX volatility.
`reserve_adequacy` is the IMF ARA metric (fixed: 30% short-term debt + 20% other liabilities + 10%
broad money + 10% exports; floating: 30/15/5/5; managed regimes take the average) from
data/dsa_inputs.csv plus live reserves, GDP and exports. `dsa_table` joins both into one row per
country with the derived scorecard inputs: 1.1 debt service % revenue, 1.2 PPG external debt service
over the next 24 months % reserves (World Bank IDS projections), 2.1 reserves % ARA.

EQ-B-0070 adds, alongside and without changing the above: `simulate_dsa` (correlated AR(1) shocks to growth, the
effective rate, the primary balance and FX depreciation, covariance from the country's own history else its regional
pool else a documented regional default), the gross financing need path, `dsa_signal` (P(debt above threshold),
P(GFN above threshold), a 0-100 score), `write_dsa_paths` (outputs/dsa_paths.csv, dsa_signal.csv, dsa_paths_meta.json)
and two pipeline hooks, `dsa_signal_hook` and `pd_overlay`, that are off unless settings["dsa"] turns them on.
See docs/validation/dsa.md.
"""
from __future__ import annotations
from pathlib import Path
import numpy as np
import pandas as pd
from ..config import Settings
from ..ingestion import Universe
from .common import as_of_timestamp

HORIZON = 5
US_INFLATION = 0.025
ARA_WEIGHTS = {"fixed": (0.30, 0.20, 0.10, 0.10), "floating": (0.30, 0.15, 0.05, 0.05)}
DSA_COLUMNS = ["country", "iso", "year0", "debt_now", "pb_now", "i_eff_now", "g_nom_now", "r_minus_g", "pb_stabilising", "pb_gap",
               "debt_baseline_5y", "debt_median_5y", "debt_p10_5y", "debt_p25_5y", "debt_p75_5y", "debt_p90_5y", "p_debt_rising", "p_debt_above_80",
               "gfn_pct_gdp", "debt_service_pct_revenue", "fx_debt_service_24m_pct_reserves", "fx_debt_service_years", "reserves_usd_bn", "usable_reserves_usd_bn",
               "ara_metric_usd_bn", "reserves_pct_ara", "ara_weights", "read"]


def _weo(long: pd.DataFrame, iso: str, series: str) -> pd.Series:
    s = long[(long["iso"] == iso) & (long["series"] == series)].set_index("period")["value"].astype(float).sort_index()
    return s[~s.index.duplicated(keep="last")]


def debt_history(weo: pd.DataFrame, iso: str) -> pd.DataFrame:
    """Annual table: debt, primary balance, overall balance, interest, effective rate, nominal growth, real growth, sfa."""
    d = _weo(weo, iso, "GGXWDG_NGDP"); pb = _weo(weo, iso, "GGXONLB_NGDP"); ob = _weo(weo, iso, "GGXCNL_NGDP")
    ngdp = _weo(weo, iso, "NGDP"); gr = _weo(weo, iso, "NGDP_RPCH"); rev = _weo(weo, iso, "GGR_NGDP"); usd = _weo(weo, iso, "NGDPD")
    cpi = _weo(weo, iso, "PCPIPCH")
    df = pd.DataFrame({"debt": d, "pb": pb, "ob": ob, "ngdp": ngdp, "g_real": gr, "revenue": rev, "gdp_usd_bn": usd, "inflation": cpi})
    df["interest"] = df["pb"] - df["ob"]
    df["g_nom"] = df["ngdp"].pct_change()
    df["i_eff"] = df["interest"] / df["debt"].shift(1)
    df["sfa"] = df["debt"] - (df["debt"].shift(1) * (1 + df["i_eff"]) / (1 + df["g_nom"]) - df["pb"])
    return df


def _last(series: pd.Series, default: float) -> float:
    s = series.dropna()
    return float(s.iloc[-1]) if len(s) else float(default)


def _shock_params(hist: pd.DataFrame, year0: int, lookback: int = 25) -> dict:
    """Covariance of annual innovations in (g_nom, pb, i_eff) and the sfa distribution from the realised history."""
    h = hist.loc[(hist.index <= year0) & (hist.index > year0 - lookback), ["g_nom", "pb", "i_eff", "sfa"]].dropna()
    if len(h) < 8:
        return {"cov": np.diag([0.04**2, 1.5**2, 0.01**2]), "sfa_sd": 2.0, "n": len(h), "note": "too little history: default volatilities"}
    inn = h[["g_nom", "pb", "i_eff"]].diff().dropna()
    inn = inn.clip(inn.quantile(0.025), inn.quantile(0.975), axis=1)
    cov = np.atleast_2d(np.cov(inn.values.T)) + np.diag([1e-6, 1e-4, 1e-8])
    caps = np.array([0.15, 4.0, 0.03])                       # growth 15 pp, primary balance 4 pp of GDP, effective rate 3 pp
    sd = np.sqrt(np.diag(cov)); scale = np.minimum(1.0, caps / sd)
    cov = cov * np.outer(scale, scale)
    sfa = h["sfa"].clip(h["sfa"].quantile(0.025), h["sfa"].quantile(0.975))
    return {"cov": cov, "sfa_sd": float(min(sfa.std(ddof=1), 6.0)), "n": len(h), "note": ""}


def _baseline_components(hist: pd.DataFrame, year0: int, horizon: int, fx_share: float, i_default: float) -> dict:
    """Deterministic baseline inputs for year0+1 .. year0+horizon (shared by `stochastic_dsa` and `simulate_dsa`).

    WEO projections where present, else the last value carried forward; expected depreciation is the inflation
    differential with the US; the baseline stock-flow adjustment `sfa` is the residual that makes the model path
    follow the WEO debt projection where one exists."""
    years = list(range(year0 + 1, year0 + horizon + 1))
    base = hist.reindex(years)
    # baseline components: WEO projections where present, else carry the last value forward
    def fill(col, fallback):
        s = base[col].copy()
        last = hist[col].dropna()
        s = s.fillna(last.iloc[-1] if len(last) else fallback).fillna(fallback)
        return s.values.astype(float)
    g_b = fill("g_nom", 0.05); pb_b = fill("pb", 0.0); i_b = fill("i_eff", i_default); infl_b = fill("inflation", 3.0)
    exp_dep = np.maximum(infl_b / 100.0 - US_INFLATION, 0.0)              # expected depreciation of the local currency: inflation differential
    d0 = float(hist.loc[year0, "debt"]) if year0 in hist.index and np.isfinite(hist.loc[year0, "debt"]) else _last(hist["debt"], 50.0)
    # baseline stock-flow adjustment: the residual that makes the model baseline follow the WEO debt projection where one exists
    weo_d = base["debt"].values.astype(float); sfa_b = np.zeros(horizon); prev = d0
    for t in range(horizon):
        model_t = prev * (1 + i_b[t]) / (1 + g_b[t]) * (1 + fx_share * exp_dep[t]) - pb_b[t]
        if np.isfinite(weo_d[t]):
            sfa_b[t] = weo_d[t] - model_t; prev = weo_d[t]
        else:
            prev = model_t
    return {"years": years, "base": base, "g": g_b, "pb": pb_b, "r": i_b, "inflation": infl_b, "dep": exp_dep, "d0": d0, "sfa": sfa_b}


def stochastic_dsa(hist: pd.DataFrame, year0: int, horizon: int = HORIZON, paths: int = 10000, seed: int = 7, fx_share: float = 0.0,
                   fx_vol_pct: float = 0.0, rho=(0.5, 0.5, 0.3), i_default: float = 0.04) -> dict:
    """Fan chart of debt/GDP around the WEO baseline for year0+1 .. year0+horizon."""
    rng = np.random.default_rng(seed)
    b = _baseline_components(hist, year0, horizon, fx_share, i_default)
    years, base, g_b, pb_b, i_b, exp_dep, d0, sfa_b = b["years"], b["base"], b["g"], b["pb"], b["r"], b["dep"], b["d0"], b["sfa"]
    prm = _shock_params(hist, year0)
    L = np.linalg.cholesky(prm["cov"])
    d = np.full(paths, d0); out = np.empty((horizon, paths)); eps = np.zeros((paths, 3)); rho = np.asarray(rho)
    for t in range(horizon):
        z = rng.standard_normal((paths, 3)) @ L.T
        eps = rho * eps + np.sqrt(1 - rho**2) * z
        g = g_b[t] + eps[:, 0]; pb = pb_b[t] + eps[:, 1]; i = np.maximum(i_b[t] + eps[:, 2], 0.0)
        sfa = rng.normal(0.0, prm["sfa_sd"], paths)
        dep = exp_dep[t] + (rng.normal(0.0, fx_vol_pct / 100.0, paths) if fx_share > 0 and fx_vol_pct > 0 else 0.0)
        d = d * (1 + i) / (1 + g) * (1 + fx_share * dep) - pb + sfa + sfa_b[t]
        d = np.clip(d, 0.0, 400.0)
        out[t] = d
    # deterministic baseline
    db = d0; base_path = []
    for t in range(horizon):
        db = db * (1 + i_b[t]) / (1 + g_b[t]) * (1 + fx_share * exp_dep[t]) - pb_b[t] + sfa_b[t]; base_path.append(db)
    q = np.percentile(out, [10, 25, 50, 75, 90], axis=1)
    fan = pd.DataFrame({"year": years, "baseline_weo": base["debt"].values, "baseline_model": base_path, "p10": q[0], "p25": q[1], "p50": q[2], "p75": q[3], "p90": q[4]})
    return {"debt_now": d0, "fan": fan, "p_rising": float((out[-1] > d0).mean()), "p_above_80": float((out[-1] > 80).mean()),
            "paths": paths, "baseline_sfa": sfa_b.tolist(), "shock_params": {"sd_g": float(np.sqrt(prm["cov"][0, 0])), "sd_pb": float(np.sqrt(prm["cov"][1, 1])), "sd_i": float(np.sqrt(prm["cov"][2, 2])), "sfa_sd": prm["sfa_sd"], "n_hist": prm["n"], "note": prm["note"]}}


def load_dsa_inputs(path: str | Path) -> pd.DataFrame:
    return pd.read_csv(path).set_index("country")


def reserve_adequacy(country: str, prof: pd.Series, inputs: pd.DataFrame, gdp_usd_bn: float, reserves_usd_bn: float) -> dict:
    """IMF ARA metric in US$ bn and reserves as a percentage of it."""
    row = inputs.loc[country] if country in inputs.index else None
    if row is None or str(row.get("ara_applicable", "yes")).lower() != "yes" or not np.isfinite(gdp_usd_bn):
        return {"ara_metric_usd_bn": np.nan, "reserves_pct_ara": np.nan, "usable_reserves_usd_bn": reserves_usd_bn, "ara_weights": "n/a"}
    regime = str(prof["fxregime"])
    exports = float(prof["exports"]) / 100 * gdp_usd_bn
    bm = float(row["broad_money_pct_gdp"]) / 100 * gdp_usd_bn
    std, oth = float(row["st_external_debt_usd_bn"]), float(row["other_liabilities_usd_bn"])
    def metric(w): return w[0] * std + w[1] * oth + w[2] * bm + w[3] * exports
    if regime == "Peg": ara, wname = metric(ARA_WEIGHTS["fixed"]), "fixed"
    elif regime == "Float": ara, wname = metric(ARA_WEIGHTS["floating"]), "floating"
    else: ara, wname = 0.5 * (metric(ARA_WEIGHTS["fixed"]) + metric(ARA_WEIGHTS["floating"])), "average of fixed and floating (managed)"
    usable = reserves_usd_bn * float(row.get("usable_reserves_share", 1.0))
    return {"ara_metric_usd_bn": ara, "reserves_pct_ara": usable / ara * 100 if ara > 0 else np.nan, "usable_reserves_usd_bn": usable, "ara_weights": wname}


def _wb_latest(wb: pd.DataFrame | None, iso: str, series: str, max_period: int | None = None):
    if wb is None: return np.nan, None
    s = wb[(wb["iso"] == iso) & (wb["series"] == series)].dropna(subset=["value"])
    if max_period is not None: s = s[s["period"] <= max_period]
    if not len(s): return np.nan, None
    r = s.sort_values("period").iloc[-1]
    return float(r["value"]), int(r["period"])


# 1.2 PPG debt-service rule: moved to econquest.rules.dsa (C15, EQ-B-0134); the same objects, re-exported for one release.
from ..rules.dsa import COUNTERPART_COLUMNS, WORLD_CODES, _counterpart_column, ppg_debt_service_detail  # noqa: E402,F401


def ppg_debt_service_24m(wb: pd.DataFrame | None, iso: str, year0: int) -> tuple[float, str]:
    """(two-year total US$, years used) from `ppg_debt_service_detail`, without the note."""
    v, years, _ = ppg_debt_service_detail(wb, iso, year0)
    return v, years


def _read(r: pd.Series) -> str:
    bits = []
    if np.isfinite(r["p_debt_rising"]):
        bits.append("debt likely rising" if r["p_debt_rising"] >= 0.6 else "debt likely falling" if r["p_debt_rising"] <= 0.4 else "debt path balanced")
    if np.isfinite(r["reserves_pct_ara"]):
        bits.append("reserves below ARA floor" if r["reserves_pct_ara"] < 100 else "reserves adequate" if r["reserves_pct_ara"] <= 150 else "reserves ample")
    if np.isfinite(r["debt_service_pct_revenue"]) and r["debt_service_pct_revenue"] >= 30:
        bits.append("debt service heavy")
    return "; ".join(bits)


def resolve_year0(settings: Settings | None = None, year0: int | None = None, as_of=None) -> int:
    """The DSA base year: explicit `year0`, else the year before the as-of date (`as_of`, else settings["as_of"]).

    Only when neither is given does it fall back to the calendar (kept for backward compatibility; callers should
    pass `year0` or `as_of` so a rerun of the same inputs gives the same table)."""
    if year0:
        return int(year0)
    try:
        ts = as_of_timestamp(settings, as_of)
    except ValueError:
        ts = pd.Timestamp.today()                                     # legacy fallback: prefer an explicit year0 / as_of
    return int(ts.year) - 1


# EQ-B-0078 / HO-20261024-A-B-007: input provenance of the derived scorecard cells (1.1, 1.2, 2.1). Each input is a
# (ref, live) pair; ref is "<source>:<series> <period>" and live is True only for a WEO or World Bank series read
# from the data/live pull. Analyst estimates (dsa_inputs.csv), profile seeds (countries.csv) and engine defaults
# are not live.
WEO_SOURCE = "imf-reader WEO"
WB_SOURCE = {"FI.RES.TOTL.CD": "wbgapi WDI", "DT.TDS.DPPG.CD": "wbgapi IDS"}


def _weo_ref(series: str, period) -> tuple[str, bool]:
    return (f"{WEO_SOURCE}:{series} {int(period)}", True)


def _weo_pick(hist: pd.DataFrame, col: str, year: int, series: tuple[str, ...]) -> list[tuple[str, bool]] | None:
    """Refs for hist[col] as dsa_table reads it: the value at `year` when finite, else the last finite value
    (`_last`). None when the column has no finite value (the caller then uses its own fallback)."""
    if year in hist.index and np.isfinite(hist.loc[year, col]):
        p = year
    else:
        s = hist[col].dropna()
        if not len(s):
            return None
        p = int(s.index[-1])
    return [_weo_ref(x, p) for x in series]


def _estimate(ref: str) -> tuple[str, bool]:
    return (ref, False)


def dsa_table(u: Universe, settings: Settings, weo: pd.DataFrame, wb: pd.DataFrame | None, inputs: pd.DataFrame, year0: int | None = None,
              paths: int = 10000, seed: int = 7, as_of=None) -> tuple[pd.DataFrame, pd.DataFrame, dict]:
    """One row per country plus the stacked fan-chart table and per-country shock diagnostics."""
    prof = u.countries.set_index("country"); ind = u.indicators.set_index("id")
    fxv = settings["market"]["fx_vol"]
    year0 = resolve_year0(settings, year0, as_of)
    rows, fans, diag, feed_inputs, ds_notes = [], [], {}, {}, {}
    for c in u.names:
        iso = prof.loc[c, "iso"]
        hist = debt_history(weo, iso)
        if hist["debt"].dropna().empty:
            continue
        y0 = year0 if year0 in hist.index and np.isfinite(hist.loc[year0, "debt"]) else int(hist["debt"].dropna().index.max())
        fx_share = float(ind.loc["1.5", c]) / 100 if "1.5" in ind.index else 0.0
        i_default = 0.04 + float(prof.loc[c, "spread"]) / 10000          # risk-free plus the sovereign spread when WEO has no interest data
        res = stochastic_dsa(hist, y0, paths=paths, seed=seed, fx_share=fx_share, fx_vol_pct=float(fxv.get(str(prof.loc[c, "fxregime"]), 7.0)), i_default=i_default)
        fan = res["fan"].copy(); fan.insert(0, "country", c); fans.append(fan)
        h0 = hist.loc[y0]; h1 = hist.loc[y0 + 1] if (y0 + 1) in hist.index else h0
        i_eff = float(h0["i_eff"]) if np.isfinite(h0["i_eff"]) else _last(hist["i_eff"], i_default)
        g_nom = float(h0["g_nom"]) if np.isfinite(h0["g_nom"]) else _last(hist["g_nom"], 0.05)
        pb_star = res["debt_now"] * (i_eff - g_nom) / (1 + g_nom)
        maturity = float(inputs.loc[c, "avg_maturity_yrs"]) if c in inputs.index else 7.0
        amort = res["debt_now"] / maturity
        gfn = -float(h1["ob"]) + amort if np.isfinite(h1["ob"]) else np.nan
        revenue = float(h1["revenue"]) if np.isfinite(h1["revenue"]) else _last(hist["revenue"], np.nan)
        interest = float(h1["interest"]) if np.isfinite(h1["interest"]) else _last(hist["interest"], i_eff * res["debt_now"])
        dsr = (interest + amort) / revenue * 100 if np.isfinite(revenue) and revenue > 0 else np.nan
        gdp_usd = float(h0["gdp_usd_bn"]) if np.isfinite(h0["gdp_usd_bn"]) else np.nan
        res_usd, res_period = _wb_latest(wb, iso, "FI.RES.TOTL.CD")
        res_usd = res_usd / 1e9 if np.isfinite(res_usd) else float(prof.loc[c, "reserves"]) / 100 * gdp_usd
        ds24, ds_years, ds_note = ppg_debt_service_detail(wb, iso, y0)
        if ds_note:
            ds_notes[c] = ds_note                                     # EQ-B-0084: why 1.2 was refused
        fxds = ds24 / 1e9 / res_usd * 100 if np.isfinite(ds24) and res_usd > 0 else np.nan
        ara = reserve_adequacy(c, prof.loc[c], inputs, gdp_usd, res_usd)
        f5 = res["fan"].iloc[-1]
        pb_now = float(h0["pb"]) if np.isfinite(h0["pb"]) else _last(hist["pb"], np.nan)
        row = {"country": c, "iso": iso, "year0": y0, "debt_now": res["debt_now"], "pb_now": pb_now, "i_eff_now": i_eff * 100, "g_nom_now": g_nom * 100,
               "r_minus_g": (i_eff - g_nom) * 100, "pb_stabilising": pb_star, "pb_gap": pb_now - pb_star,
               "debt_baseline_5y": float(f5["baseline_weo"]) if np.isfinite(f5["baseline_weo"]) else float(f5["baseline_model"]), "debt_median_5y": float(f5["p50"]),
               "debt_p10_5y": float(f5["p10"]), "debt_p25_5y": float(f5["p25"]), "debt_p75_5y": float(f5["p75"]), "debt_p90_5y": float(f5["p90"]),
               "p_debt_rising": res["p_rising"], "p_debt_above_80": res["p_above_80"], "gfn_pct_gdp": gfn, "debt_service_pct_revenue": dsr,
               "fx_debt_service_24m_pct_reserves": fxds, "fx_debt_service_years": ds_years, "reserves_usd_bn": res_usd, **ara}
        row["read"] = _read(pd.Series(row))
        rows.append(row); diag[c] = res["shock_params"] if not ds_note else {**res["shock_params"], "fx_debt_service_note": ds_note}
        feed_inputs[c] = _feed_inputs(c, hist, y0, inputs, wb, iso, res_period, ds_years, gdp_usd)
    table = pd.DataFrame(rows)[DSA_COLUMNS] if rows else pd.DataFrame(columns=DSA_COLUMNS)
    table.attrs["feed_inputs"] = feed_inputs                          # read by scorecard_feeds; not written to dsa.csv
    table.attrs["fx_debt_service_notes"] = ds_notes                   # EQ-B-0084: {country: reason 1.2 was refused}
    if as_of is not None:
        table.attrs["as_of"] = str(as_of_timestamp(None, as_of).date())   # scorecard_feeds' `retrieved` default (EQ-B-0078)
    return table, pd.concat(fans, ignore_index=True) if fans else pd.DataFrame(), diag


def _feed_inputs(c: str, hist: pd.DataFrame, y0: int, inputs: pd.DataFrame, wb, iso: str, res_period, ds_years: str,
                 gdp_usd: float) -> dict:
    """{key: [(ref, live), ...]} for 1.1, 1.2 and 2.1 of one country, following the fallbacks dsa_table takes."""
    y1 = y0 + 1 if (y0 + 1) in hist.index else y0
    dsi = "dsa_inputs.csv"
    have = c in inputs.index
    # 1.1: (interest + debt / maturity) / revenue, year y0+1
    interest = _weo_pick(hist, "interest", y1, ("GGXONLB_NGDP", "GGXCNL_NGDP"))
    if interest is None:                                              # i_eff * debt_now
        interest = _weo_pick(hist, "i_eff", y0, ("GGXONLB_NGDP", "GGXCNL_NGDP", "GGXWDG_NGDP")) \
            or [_estimate("countries.csv:spread (profile seed, i_default)")]
    debt = _weo_pick(hist, "debt", y0, ("GGXWDG_NGDP",)) or []
    mat = [_estimate(f"{dsi}:avg_maturity_yrs (analyst)" if have else "engine default:avg_maturity_yrs=7")]
    revenue = _weo_pick(hist, "revenue", y1, ("GGR_NGDP",)) or []
    k11 = interest + debt + mat + revenue
    # reserves (1.2 and 2.1): WB FI.RES.TOTL.CD latest, else countries.csv reserves % x WEO NGDPD at y0
    if res_period is not None:
        reserves = [(f"{WB_SOURCE['FI.RES.TOTL.CD']}:FI.RES.TOTL.CD {int(res_period)}", True)]
    else:
        reserves = [_estimate("countries.csv:reserves (profile seed)")] + ([_weo_ref("NGDPD", y0)] if np.isfinite(gdp_usd) else [])
    k12 = [(f"{WB_SOURCE['DT.TDS.DPPG.CD']}:DT.TDS.DPPG.CD {ds_years}", True)] + reserves if ds_years else []
    # 2.1: usable reserves / ARA metric (dsa_inputs.csv components, countries.csv exports and fxregime, WEO NGDPD)
    k21 = []
    if have and np.isfinite(gdp_usd):
        k21 = reserves + [_estimate(f"{dsi}:{x} (analyst)") for x in ("usable_reserves_share", "st_external_debt_usd_bn",
                                                                       "other_liabilities_usd_bn", "broad_money_pct_gdp")] \
            + [_estimate("countries.csv:exports (profile seed)"), _estimate("countries.csv:fxregime (profile seed)"), _weo_ref("NGDPD", y0)]
    return {key: list(dict.fromkeys(refs)) for key, refs in (("1.1", k11), ("1.2", k12), ("2.1", k21))}


SCORECARD_FEEDS = {"1.1": ("debt_service_pct_revenue", "WEO interest (GGXONLB-GGXCNL) + debt/avg maturity, % of GGR_NGDP, year t+1"),
                   "1.2": ("fx_debt_service_24m_pct_reserves", "World Bank IDS DT.TDS.DPPG.CD, next two complete projection years / FI.RES.TOTL.CD"),
                   "2.1": ("reserves_pct_ara", "usable reserves / IMF ARA metric (ST debt, other liabilities, broad money, exports; dsa_inputs.csv)")}


FEED_COLUMNS = ["table", "key", "country", "value", "source", "series", "retrieved", "iso", "year0", "dsa_column",
                "derived_from", "inputs", "vintage_id"]
DERIVED_FROM = ("live", "mixed", "estimate")                          # HO-20261024-A-B-007 contract
NO_INPUT_RECORD = "unknown (table has no input record)"
FEEDS_FILE = "dsa_scorecard_feeds.csv"


def derived_from(refs) -> str:
    """'live' when every input is a live WEO/World Bank series, 'estimate' when none is, else 'mixed'.
    No recorded inputs counts as 'estimate' (never claim live without a record)."""
    live = [bool(x[1]) for x in refs]
    return "live" if live and all(live) else "mixed" if any(live) else "estimate"


def scorecard_feeds(table: pd.DataFrame, retrieved: str | None = None, keys=tuple(SCORECARD_FEEDS),
                    vintage_id: str | None = None) -> pd.DataFrame:
    """The derived scorecard inputs as proposed cells, one row per (key, country) with a finite value.

    Pure: reads nothing and writes nothing. The first seven columns are the `data/live/provenance.csv` columns
    (table, key, country, value, source, series, retrieved), so Team A's ingestion gate can compare `value`
    with the seed in indicators.csv, hold or apply it, and append the row to provenance.csv / review.csv inside a
    vintage. `iso`, `year0` (the DSA base year) and `dsa_column` (the dsa.csv column the value came from) are
    extra context. `retrieved` is the as-of date of the DSA run (YYYY-MM-DD): the argument, else table.attrs["as_of"]
    (set by `dsa_table` when it is given as_of); with neither, ValueError. Never the wall clock (EQ-B-0078), so the
    same inputs always give the same file.

    HO-20261024-A-B-007 (EQ-B-0078) adds three columns at the end:
    - `derived_from`: `live` (every input is a WEO / World Bank series from the data/live pull), `mixed` (some
      inputs are analyst estimates in data/dsa_inputs.csv, profile seeds in countries.csv or engine defaults),
      `estimate` (no live input, or no input record on `table`).
    - `inputs`: "<source>:<series> <period>; ..." in the order the formula uses them, from table.attrs["feed_inputs"]
      (set by dsa_table). Non-live inputs carry a note in brackets, e.g. "dsa_inputs.csv:avg_maturity_yrs (analyst)".
    - `vintage_id`: the data/live/vintages/<id> whose raw_weo.csv and raw_worldbank.csv equal the files the DSA read
      (see `dsa_vintage_id`); `vintage_id` argument, else table.attrs["vintage_id"], else "" (not replayable)."""
    unknown = [k for k in keys if k not in SCORECARD_FEEDS]
    if unknown:
        raise ValueError(f"unknown DSA scorecard keys {unknown}; known: {sorted(SCORECARD_FEEDS)}")
    retrieved = retrieved or table.attrs.get("as_of")                  # EQ-B-0078: never the wall clock
    if not retrieved:
        raise ValueError("scorecard_feeds needs retrieved= (the DSA as_of, YYYY-MM-DD) or a table built by dsa_table(as_of=...)")
    retrieved = str(pd.Timestamp(retrieved).date())
    rec = table.attrs.get("feed_inputs") or {}
    vid = vintage_id if vintage_id is not None else table.attrs.get("vintage_id", "")
    rows = []
    for _, r in table.iterrows():
        for key in keys:
            col, series = SCORECARD_FEEDS[key]
            v = r[col]
            if v is None or not np.isfinite(float(v)):
                continue
            refs = (rec.get(r["country"]) or {}).get(str(key)) or []
            rows.append({"table": "Inputs", "key": str(key), "country": r["country"], "value": round(float(v), 4), "source": "econquest dsa",
                         "series": series, "retrieved": retrieved, "iso": r.get("iso", ""), "year0": int(r["year0"]) if "year0" in r else None,
                         "dsa_column": col, "derived_from": derived_from(refs),
                         "inputs": "; ".join(x[0] for x in refs) if refs else NO_INPUT_RECORD, "vintage_id": vid or ""})
    return pd.DataFrame(rows, columns=FEED_COLUMNS)


def _sheet_safe(df: pd.DataFrame) -> pd.DataFrame:
    """Copy of df with every text cell passed through common_format.escape_formula (EQ-B-0078): the shared rule,
    which also catches tab/CR/leading-blank prefixes that idea_log._csv_safe misses. Numeric columns unchanged."""
    from ..common_format import escape_formula
    out = df.copy()
    for c in out.columns:
        if not pd.api.types.is_numeric_dtype(out[c]):
            out[c] = out[c].map(escape_formula)
    return out


def write_scorecard_feeds(feeds: pd.DataFrame, out_dir: str | Path) -> Path:
    """Write the proposed cells to `<out_dir>/dsa_scorecard_feeds.csv` (an engine output; never into data/)."""
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    path = out / FEEDS_FILE
    _sheet_safe(feeds[FEED_COLUMNS]).to_csv(path, index=False)        # text cells never start a spreadsheet formula
    return path


def dsa_vintage_id(data_dir: str | Path, as_of, files=("raw_weo.csv", "raw_worldbank.csv")) -> str:
    """The newest data/live/vintages/<id> dated on or before `as_of` whose `files` are byte-identical to
    data/live/<files> (the files `econquest dsa` reads), so a DSA value can be replayed from that vintage. "" when
    no vintage matches (Team A then treats the row as not replayable and holds it). Reads only; no clock."""
    import hashlib
    d = Path(data_dir) / "live"; ts = as_of_timestamp(None, as_of)
    def digest(p: Path):
        return hashlib.sha256(p.read_bytes()).hexdigest() if p.is_file() else None
    want = [digest(d / f) for f in files]
    if None in want or not (d / "vintages").is_dir():
        return ""
    for v in sorted((p for p in (d / "vintages").iterdir() if p.is_dir() and p.name[:4].isdigit()), key=lambda p: p.name, reverse=True):
        try:
            if pd.Timestamp(v.name[:10]).normalize() > ts:
                continue
        except ValueError:
            continue
        if [digest(v / f) for f in files] == want:
            return v.name
    return ""


def apply_to_inputs(table: pd.DataFrame, data_dir: str | Path, retrieved: str | None = None, keys=tuple(SCORECARD_FEEDS), max_rel_change: float = 0.5, force: bool = False) -> dict:
    """Removed (EQ-B-0010, HO-20261023-A-B-001): the engine no longer writes indicators.csv, provenance.csv or review.csv.

    Use `scorecard_feeds(table, retrieved=as_of)` and `write_scorecard_feeds(feeds, outputs_dir)`; Team A's ingestion
    applies `outputs/dsa_scorecard_feeds.csv` through its quality gate inside a vintage."""
    raise RuntimeError("econquest.engine.dsa.apply_to_inputs no longer writes data/indicators.csv or data/live/*: call "
                       "dsa.scorecard_feeds(table, retrieved=as_of) and dsa.write_scorecard_feeds(feeds, out_dir), then apply "
                       "outputs/dsa_scorecard_feeds.csv through the ingestion gate (EQ-B-0010, HO-20261023-A-B-001)")


def dsa_plan(table: pd.DataFrame, fans: pd.DataFrame, as_of: str, sheet: str = "Debt Sustainability") -> list[dict]:
    """Workbook ranges for the Debt Sustainability tab."""
    def v(x):
        if isinstance(x, (float, np.floating)):
            return "" if not np.isfinite(x) else round(float(x), 4)
        return x
    head = ["Country", "Debt/GDP now", "Primary balance", "Effective rate %", "Nominal growth %", "r-g (pp)", "Debt-stabilising PB", "PB gap", "WEO baseline 5y", "Median 5y", "P10", "P25", "P75", "P90",
            "P(debt rising)", "P(debt > 80)", "GFN % GDP", "Debt service % revenue (1.1)", "FX debt service 24m % reserves (1.2)", "Reserves $bn", "Usable reserves $bn", "ARA metric $bn", "Reserves % ARA (2.1)", "ARA weights", "Read"]
    cols = ["country", "debt_now", "pb_now", "i_eff_now", "g_nom_now", "r_minus_g", "pb_stabilising", "pb_gap", "debt_baseline_5y", "debt_median_5y", "debt_p10_5y", "debt_p25_5y", "debt_p75_5y", "debt_p90_5y",
            "p_debt_rising", "p_debt_above_80", "gfn_pct_gdp", "debt_service_pct_revenue", "fx_debt_service_24m_pct_reserves", "reserves_usd_bn", "usable_reserves_usd_bn", "ara_metric_usd_bn", "reserves_pct_ara", "ara_weights", "read"]
    body = [[v(r[c]) for c in cols] for _, r in table.iterrows()]
    n = len(body)
    plan = [{"range": f"'{sheet}'!A1:A2", "values": [["Debt sustainability and reserve adequacy: stochastic DSA fan charts around the IMF WEO baseline and the IMF ARA reserve metric"],
             [f"Written by `python -m econquest dsa` on {as_of}. Debt dynamics d(t) = d(t-1)(1+i)/(1+g) - pb + sfa with AR(1) shocks to growth, primary balance and the effective rate from each country's own history, a stock-flow shock and a currency revaluation of the FX share of debt; 10,000 paths, five years. ARA: 30% short-term debt + 20%/15% other liabilities + 10%/5% broad money + 10%/5% exports (fixed/floating; managed takes the average); inputs in data/dsa_inputs.csv are analyst estimates until live pulls exist. Columns marked (1.1), (1.2), (2.1) are written to outputs/dsa_scorecard_feeds.csv and feed the scorecard through the ingestion quality gate."]]},
            {"range": f"'{sheet}'!A4:Y4", "values": [head]}]
    if n:
        plan.append({"range": f"'{sheet}'!A5:Y{4 + n}", "values": body})
    r0 = 7 + n
    plan.append({"range": f"'{sheet}'!A{r0}:H{r0}", "values": [["Fan chart (debt/GDP by year)", "Year", "WEO baseline", "Model baseline", "P10", "P25", "P50", "P75"]]})
    fan_rows = [[r["country"], int(r["year"]), v(r["baseline_weo"]), v(r["baseline_model"]), v(r["p10"]), v(r["p25"]), v(r["p50"]), v(r["p75"])] for _, r in fans.iterrows()]
    if fan_rows:
        plan.append({"range": f"'{sheet}'!A{r0 + 1}:H{r0 + len(fan_rows)}", "values": fan_rows})
    return plan


# ---------------------------------------------------------------- EQ-B-0070: correlated-shock DSA, GFN path, DSA signal
# Everything below is new and off the pipeline path: `dsa_table` and `stochastic_dsa` above are unchanged and still
# write outputs/dsa.csv and dsa_fan.csv. The signal reaches signals/PDs only through `dsa_signal_hook` and
# `pd_overlay`, both gated by settings["dsa"] keys that default to off (see docs/validation/dsa.md).
SHOCK_VARS = ("g", "r", "pb", "fx")                  # nominal growth, effective nominal rate, primary balance (% GDP), depreciation
SHOCK_CAPS = np.array([0.15, 0.03, 4.0, 0.35])       # sd caps: growth 15 pp, rate 3 pp, primary balance 4 pp of GDP, depreciation 35%
SHOCK_RHO = (0.5, 0.5, 0.5, 0.0)                     # AR(1) persistence of the shocks; depreciation shocks are iid
MIN_OWN_OBS = 8                                      # years of complete history needed to use a country's own covariance
LOOKBACK = 25
# Regional default shock sizes (sd of g, r, pb, fx) when neither the country nor its region has enough history.
# Analyst judgement, set near the median of the own-history estimates in the 2026-10-23 WEO vintage; not fitted.
REGION_DEFAULT_SD = {"Asia": (0.04, 0.008, 1.5, 0.06), "LatAm": (0.08, 0.015, 2.0, 0.15),
                     "Africa": (0.08, 0.015, 2.0, 0.15), "other": (0.06, 0.012, 1.8, 0.10)}
# Default correlation (order g, r, pb, fx): growth and the primary balance move together; depreciation comes with
# weaker growth and higher rates. Judgement, documented in docs/validation/dsa.md.
DEFAULT_CORR = np.array([[1.0, -0.1, 0.3, -0.3],
                         [-0.1, 1.0, 0.0, 0.3],
                         [0.3, 0.0, 1.0, -0.1],
                         [-0.3, 0.3, -0.1, 1.0]])
# Thresholds: IMF MAC DSA (2013) high-scrutiny benchmarks, emerging markets 70% debt / 15% GFN, advanced economies 85% / 20%.
DSA_DEFAULTS = {"signal_enabled": False, "pd_overlay_enabled": False, "pd_logit_weight": 0.0, "debt_threshold": 70.0,
                "gfn_threshold": 15.0, "debt_threshold_advanced": 85.0, "gfn_threshold_advanced": 20.0,
                "advanced_economies": ["Japan", "Singapore", "South Korea"], "paths": 10000, "seed": 7, "horizon": HORIZON,
                "default_maturity_yrs": 7.0, "inputs_path": None, "data_dir": "data",
                "overlay_exclude": [], "overlay_raise_only": False}   # EQ-B-0080 overlay options, off by default
DSA_SIGNAL_ID = 26
DSA_SIGNAL_NAME = "Debt above IMF benchmark (DSA)"
PCTS = (10, 25, 50, 75, 90)
PATHS_FILE = "dsa_paths.csv"
SIGNAL_FILE = "dsa_signal.csv"
META_FILE = "dsa_paths_meta.json"
PATH_COLUMNS = (["country", "iso", "year", "debt_weo", "debt_baseline"] + [f"debt_p{p}" for p in PCTS] + ["gfn_baseline"]
                + [f"gfn_p{p}" for p in PCTS] + ["g_baseline", "r_baseline", "pb_baseline", "fx_dep_baseline", "sfa_baseline"])
SIGNAL_COLUMNS = ["country", "iso", "as_of", "year0", "debt_now", "debt_p50_end", "debt_p90_end", "debt_threshold", "p_debt_above_threshold",
                  "gfn_baseline_peak", "gfn_p90_peak", "gfn_threshold", "p_gfn_above_threshold", "dsa_score", "r_minus_g_baseline",
                  "fx_share", "cov_source", "n_hist"]


def dsa_setting(settings: Settings | None, key: str):
    """settings["dsa"][key], else the documented default in DSA_DEFAULTS (the key need not exist in assumptions.json)."""
    return DSA_DEFAULTS[key] if settings is None else settings.get("dsa", key, default=DSA_DEFAULTS[key])


def load_weo_as_of(data_dir: str | Path, as_of) -> tuple[pd.DataFrame, str]:
    """The WEO pull to use at `as_of`: the latest data/live/vintages/<id>/raw_weo.csv dated <= as_of, else
    data/live/raw_weo.csv when data/live/feeds.json says it was retrieved on or before as_of. Never a later pull.

    EQ-B-0080: the vintage date is the leading YYYY-MM-DD of the folder name, so both the old `YYYY-MM-DD` names and
    Team A's `YYYY-MM-DDTHHMMSSZ-hash8` names are read. Among vintages of the same date the latest name wins (the
    time stamp sorts in the name). A folder whose name does not start with a date is skipped with a warning."""
    import json
    import warnings
    d = Path(data_dir); ts = as_of_timestamp(None, as_of)
    vdir = d / "live" / "vintages"
    if vdir.is_dir():
        dated = []
        for p in vdir.iterdir():
            if not p.is_dir():
                continue
            vd = _vintage_date(p.name)
            if vd is None:
                warnings.warn(f"WEO vintage folder {p.name!r} does not start with a YYYY-MM-DD date; skipped", stacklevel=2)
                continue
            if vd <= ts and (p / "raw_weo.csv").exists():
                dated.append((vd, p.name, p))
        if dated:
            vd, _, vp = max(dated); p = vp / "raw_weo.csv"
            return _tag(pd.read_csv(p, dtype={"iso": str, "series": str}), vd), str(p.relative_to(d))
    p = d / "live" / "raw_weo.csv"; f = d / "live" / "feeds.json"
    if p.exists() and f.exists():
        retrieved = json.loads(f.read_text()).get("retrieved")
        if retrieved and pd.Timestamp(retrieved).normalize() <= ts:
            return _tag(pd.read_csv(p, dtype={"iso": str, "series": str}), pd.Timestamp(retrieved)), str(p.relative_to(d))
    raise ValueError(f"no WEO pull dated on or before {ts.date()} under {d / 'live'}")


def _vintage_date(name: str):
    """The date of a vintage folder name (its first 10 characters, YYYY-MM-DD), else None."""
    import re
    if not re.fullmatch(r"\d{4}-\d{2}-\d{2}", name[:10]):
        return None
    try:
        return pd.Timestamp(name[:10]).normalize()
    except ValueError:
        return None


def _tag(weo: pd.DataFrame, retrieved) -> pd.DataFrame:
    """Record the pull date on the frame (weo.attrs["retrieved"], YYYY-MM-DD) so `run_dsa_paths` can refuse a later pull."""
    weo.attrs["retrieved"] = str(pd.Timestamp(retrieved).date())
    return weo


def fx_depreciation(hist: pd.DataFrame) -> pd.Series:
    """Annual depreciation of the local currency against the US$ implied by WEO: NGDP (local) / NGDPD (US$), % change."""
    ratio = hist["ngdp"] / hist["gdp_usd_bn"]
    return ratio / ratio.shift(1) - 1


def shock_history(hist: pd.DataFrame, year0: int, lookback: int = LOOKBACK) -> pd.DataFrame:
    """Annual shocks over (year0 - lookback, year0]: first differences of nominal growth, effective rate and primary
    balance (as `_shock_params`), and depreciation less its window mean; winsorised at 2.5/97.5%. Uses no year after year0."""
    fx = fx_depreciation(hist)
    h = hist.loc[(hist.index <= year0) & (hist.index > year0 - lookback)]
    x = pd.DataFrame({"g": h["g_nom"], "r": h["i_eff"], "pb": h["pb"], "fx": fx.reindex(h.index)}).dropna()
    inn = pd.DataFrame({"g": x["g"].diff(), "r": x["r"].diff(), "pb": x["pb"].diff(), "fx": x["fx"] - x["fx"].mean()}).dropna()
    if len(inn) >= 3:
        inn = inn.clip(inn.quantile(0.025), inn.quantile(0.975), axis=1)
    return inn[list(SHOCK_VARS)]


def default_cov(region: str) -> np.ndarray:
    sd = np.array(REGION_DEFAULT_SD.get(region, REGION_DEFAULT_SD["other"]))
    return DEFAULT_CORR * np.outer(sd, sd)


def shock_covariance(innov: pd.DataFrame, region: str, pooled: pd.DataFrame | None = None, min_obs: int = MIN_OWN_OBS) -> dict:
    """Covariance of (g, r, pb, fx) shocks: the country's own history when it has `min_obs` years, else the pooled
    history of its region (at least 2*min_obs country-years), else the documented regional default. Each sd is capped
    at SHOCK_CAPS (correlations kept) and the matrix is made positive semi-definite."""
    if len(innov) >= min_obs:
        cov, src, n = np.cov(innov.values.T, ddof=1), "own history", len(innov)
    elif pooled is not None and len(pooled) >= 2 * min_obs:
        cov, src, n = np.cov(pooled[list(SHOCK_VARS)].values.T, ddof=1), f"regional pool ({region})", len(pooled)
    else:
        cov, src, n = default_cov(region), f"regional default ({region if region in REGION_DEFAULT_SD else 'other'})", len(innov)
    cov = np.atleast_2d(cov) + np.diag([1e-6, 1e-8, 1e-4, 1e-6])
    sd = np.sqrt(np.diag(cov)); scale = np.minimum(1.0, SHOCK_CAPS / sd)
    cov = cov * np.outer(scale, scale)
    w, V = np.linalg.eigh((cov + cov.T) / 2)
    cov = (V * np.clip(w, 0.0, None)) @ V.T
    return {"cov": cov, "source": src, "n": int(n)}


def _factor(cov: np.ndarray) -> np.ndarray:
    """A matrix L with L @ L.T == cov for a positive semi-definite cov (a zero matrix gives zero shocks)."""
    w, V = np.linalg.eigh((cov + cov.T) / 2)
    return V * np.sqrt(np.clip(w, 0.0, None))


def debt_step(d, r, g, pb, fx_share=0.0, dep=0.0, sfa=0.0):
    """One year of debt dynamics in % of GDP: d' = d (1 + fx_share dep)(1 + r)/(1 + g) - pb + sfa.

    The FX share of the stock is revalued by the depreciation `dep`, the whole stock earns the effective nominal rate
    r and is scaled by nominal growth g; the primary surplus pb (% of GDP) pays it down; sfa is the stock-flow adjustment.
    With r = g, pb = 0, dep = 0 and sfa = 0 the ratio is unchanged."""
    reval = d * (1 + fx_share * dep) / (1 + g)
    return reval * (1 + r) - pb + sfa


def gfn_step(d, r, g, pb, fx_share=0.0, dep=0.0, maturity=7.0):
    """Gross financing need in % of GDP for the year: interest + amortisation - primary balance.

    Interest is r times the opening stock (revalued for the FX share), which is how `debt_history` defines the
    effective rate (interest_t / d_{t-1}); amortisation is the opening stock over the average maturity, as in
    `dsa_table`. `g` is accepted for symmetry with `debt_step` and not used."""
    reval = d * (1 + fx_share * dep)
    return reval * r + reval / maturity - pb


def simulate_dsa(hist: pd.DataFrame, year0: int, cov: np.ndarray, horizon: int = HORIZON, paths: int = 10000, seed: int = 7,
                 fx_share: float = 0.0, maturity: float = 7.0, i_default: float = 0.04, rho=SHOCK_RHO, debt_cap: float = 400.0) -> dict:
    """Debt and GFN paths (horizon x paths) under correlated AR(1) shocks to (g, r, pb, fx) around the WEO baseline.

    Baseline as `stochastic_dsa` (`_baseline_components`, including the stock-flow residual that tracks the WEO
    debt projection). Shocks are drawn with covariance `cov`; r is floored at 0, g and dep at -50%. Seeded."""
    b = _baseline_components(hist, year0, horizon, fx_share, i_default)
    rng = np.random.default_rng(seed); L = _factor(np.asarray(cov, dtype=float)); rho = np.asarray(rho, dtype=float)
    d = np.full(paths, b["d0"]); eps = np.zeros((paths, 4))
    debt = np.empty((horizon, paths)); gfn = np.empty((horizon, paths))
    for t in range(horizon):
        z = rng.standard_normal((paths, 4)) @ L.T
        eps = rho * eps + np.sqrt(1 - rho**2) * z
        g = np.maximum(b["g"][t] + eps[:, 0], -0.5); r = np.maximum(b["r"][t] + eps[:, 1], 0.0)
        pb = b["pb"][t] + eps[:, 2]; dep = np.maximum(b["dep"][t] + eps[:, 3], -0.5)
        gfn[t] = gfn_step(d, r, g, pb, fx_share, dep, maturity)
        d = np.clip(debt_step(d, r, g, pb, fx_share, dep, b["sfa"][t]), 0.0, debt_cap)
        debt[t] = d
    db = b["d0"]; bd, bg = [], []
    for t in range(horizon):
        bg.append(float(gfn_step(db, b["r"][t], b["g"][t], b["pb"][t], fx_share, b["dep"][t], maturity)))
        db = float(debt_step(db, b["r"][t], b["g"][t], b["pb"][t], fx_share, b["dep"][t], b["sfa"][t])); bd.append(db)
    base = pd.DataFrame({"year": b["years"], "debt_weo": b["base"]["debt"].values.astype(float), "debt_baseline": bd, "gfn_baseline": bg,
                         "g_baseline": b["g"] * 100, "r_baseline": b["r"] * 100, "pb_baseline": b["pb"], "fx_dep_baseline": b["dep"] * 100,
                         "sfa_baseline": b["sfa"]})
    return {"year0": year0, "d0": b["d0"], "years": b["years"], "debt": debt, "gfn": gfn, "baseline": base, "paths": paths, "seed": seed}


def _country_seed(seed: int, iso: str) -> int:
    import zlib
    return int(seed) + zlib.crc32(str(iso).encode()) % 100000


def run_dsa_paths(u: Universe, settings: Settings | None, weo: pd.DataFrame, inputs: pd.DataFrame | None = None, as_of=None,
                  year0: int | None = None, paths: int | None = None, seed: int | None = None, horizon: int | None = None) -> dict:
    """Per-country debt and GFN fans with correlated shocks, as of `as_of` (required, or settings["as_of"]).

    year0 is the year before as_of; a country's starting debt is its latest WEO value in or before year0, and its shock
    covariance uses only years up to then. `weo` should come from `load_weo_as_of`. Returns {"fan", "sims", "meta"}."""
    ts = as_of_timestamp(settings, as_of)
    retrieved = weo.attrs.get("retrieved")
    if retrieved and pd.Timestamp(retrieved).normalize() > ts:      # EQ-B-0070 review: a later pull carries later outturns
        raise ValueError(f"WEO pull retrieved {retrieved} is after as_of {ts.date()}: use load_weo_as_of(data_dir, as_of)")
    if not retrieved:
        import warnings
        warnings.warn("WEO frame has no pull date (weo.attrs['retrieved']); load it with load_weo_as_of so a pull "
                      "dated after as_of is refused", stacklevel=2)
    year0 = int(year0) if year0 else int(ts.year) - 1
    paths = int(paths or dsa_setting(settings, "paths")); seed = int(dsa_setting(settings, "seed") if seed is None else seed)
    horizon = int(horizon or dsa_setting(settings, "horizon")); mat_default = float(dsa_setting(settings, "default_maturity_yrs"))
    prof = u.countries.set_index("country"); ind = u.indicators.set_index("id")
    hists, innov = {}, {}
    for c in u.names:
        h = debt_history(weo, prof.loc[c, "iso"])
        known = h["debt"].dropna(); known = known[known.index <= year0]
        if known.empty:
            continue
        y0 = int(known.index.max()); hists[c] = (h, y0); innov[c] = shock_history(h, y0)
    region = {c: str(prof.loc[c, "region"]) if "region" in prof.columns else "other" for c in hists}
    pools = {}
    for c, inn in innov.items():
        if len(inn) >= MIN_OWN_OBS:
            pools.setdefault(region[c], []).append(inn)
    pools = {k: pd.concat(v, ignore_index=True) for k, v in pools.items()}
    fans, sims = [], {}
    for c, (h, y0) in hists.items():
        iso = prof.loc[c, "iso"]
        sc = shock_covariance(innov[c], region[c], pools.get(region[c]))
        fx_share = float(ind.loc["1.5", c]) / 100 if "1.5" in ind.index and np.isfinite(float(ind.loc["1.5", c])) else 0.0
        i_default = 0.04 + float(prof.loc[c, "spread"]) / 10000
        mat = float(inputs.loc[c, "avg_maturity_yrs"]) if inputs is not None and c in inputs.index else mat_default
        sim = simulate_dsa(h, y0, sc["cov"], horizon=horizon, paths=paths, seed=_country_seed(seed, iso), fx_share=fx_share,
                           maturity=mat, i_default=i_default)
        sim.update(country=c, iso=iso, fx_share=fx_share, maturity=mat, cov_source=sc["source"], n_hist=sc["n"],
                   shock_sd={k: float(np.sqrt(sc["cov"][i, i])) for i, k in enumerate(SHOCK_VARS)})
        f = sim["baseline"].copy()
        qd = np.percentile(sim["debt"], PCTS, axis=1); qg = np.percentile(sim["gfn"], PCTS, axis=1)
        for j, p in enumerate(PCTS):
            f[f"debt_p{p}"] = qd[j]; f[f"gfn_p{p}"] = qg[j]
        f.insert(0, "iso", iso); f.insert(0, "country", c)
        fans.append(f[PATH_COLUMNS]); sims[c] = sim
    fan = pd.concat(fans, ignore_index=True) if fans else pd.DataFrame(columns=PATH_COLUMNS)
    meta = {"as_of": str(ts.date()), "year0": year0, "horizon": horizon, "paths": paths, "seed": seed, "percentiles": list(PCTS),
            "shock_vars": list(SHOCK_VARS), "rho": list(SHOCK_RHO), "countries_without_weo_debt": sorted(set(u.names) - set(hists)),
            "per_country": {c: {"year0": s["year0"], "cov_source": s["cov_source"], "n_hist": s["n_hist"], "fx_share": s["fx_share"],
                                "maturity": s["maturity"], "shock_sd": s["shock_sd"]} for c, s in sims.items()}}
    return {"fan": fan, "sims": sims, "meta": meta}


def dsa_signal(run: dict, settings: Settings | None = None) -> pd.DataFrame:
    """Per-country DSA signal from `run_dsa_paths`: P(debt above debt_threshold in the final year), P(GFN above
    gfn_threshold in any year of the horizon) and dsa_score = 100 x the larger of the two (0-100, higher = worse).
    Countries in `advanced_economies` use the advanced-economy thresholds."""
    adv = set(dsa_setting(settings, "advanced_economies") or [])
    rows = []
    for c, s in run["sims"].items():
        sfx = "_advanced" if c in adv else ""
        dthr = float(dsa_setting(settings, "debt_threshold" + sfx)); gthr = float(dsa_setting(settings, "gfn_threshold" + sfx))
        p_d = float((s["debt"][-1] > dthr).mean()); p_g = float((s["gfn"] > gthr).any(axis=0).mean())
        b = s["baseline"]
        rows.append({"country": c, "iso": s["iso"], "as_of": run["meta"]["as_of"], "year0": s["year0"], "debt_now": s["d0"],
                     "debt_p50_end": float(np.percentile(s["debt"][-1], 50)), "debt_p90_end": float(np.percentile(s["debt"][-1], 90)),
                     "debt_threshold": dthr, "p_debt_above_threshold": p_d, "gfn_baseline_peak": float(b["gfn_baseline"].max()),
                     "gfn_p90_peak": float(np.percentile(s["gfn"].max(axis=0), 90)), "gfn_threshold": gthr, "p_gfn_above_threshold": p_g,
                     "dsa_score": 100.0 * max(p_d, p_g), "r_minus_g_baseline": float((b["r_baseline"] - b["g_baseline"]).mean()),
                     "fx_share": s["fx_share"], "cov_source": s["cov_source"], "n_hist": s["n_hist"]})
    return pd.DataFrame(rows, columns=SIGNAL_COLUMNS)


def dsa_signal_table(u: Universe, settings: Settings | None, weo: pd.DataFrame, inputs: pd.DataFrame | None = None, as_of=None, **kw) -> pd.DataFrame:
    """The per-country DSA signal table in one call (runs `run_dsa_paths` then `dsa_signal`)."""
    return dsa_signal(run_dsa_paths(u, settings, weo, inputs=inputs, as_of=as_of, **kw), settings)


def dsa_signal_hook(u: Universe, settings: Settings, inputs: pd.DataFrame | None = None) -> pd.DataFrame | None:
    """Pipeline hook: the signal table when settings["dsa"]["signal_enabled"] or ["pd_overlay_enabled"] is true and
    the universe carries WEO history, else None. Reads settings["as_of"] (set by run_pipeline); never the clock.
    Average maturities come from `inputs`, else from settings["dsa"]["inputs_path"] (e.g. "data/dsa_inputs.csv"),
    else default_maturity_yrs for every country.

    The WEO comes from `load_weo_as_of(settings["dsa"]["data_dir"], as_of)` (default "data"), never from
    `Universe.weo_raw`, whose pull date is not recorded: when no pull is dated on or before as_of the hook warns and
    returns None (no signal, PDs unchanged)."""
    if not (dsa_setting(settings, "signal_enabled") or dsa_setting(settings, "pd_overlay_enabled")):
        return None
    import warnings
    try:
        weo, _ = load_weo_as_of(dsa_setting(settings, "data_dir"), settings.get("as_of"))
    except (ValueError, OSError) as e:
        warnings.warn(f"DSA signal skipped: {e}", stacklevel=2)
        return None
    if not len(weo):
        return None
    if inputs is None and dsa_setting(settings, "inputs_path"):
        inputs = load_dsa_inputs(dsa_setting(settings, "inputs_path"))
    return dsa_signal_table(u, settings, weo, inputs=inputs, as_of=settings.get("as_of"))


def pd_overlay(pd_default: pd.Series, signal: pd.DataFrame | None, settings: Settings | None) -> pd.Series:
    """Optional PD channel: logit(pd) + pd_logit_weight * (dsa_score - 50) / 50, capped at 0.99.

    Returns `pd_default` itself (same object, bit-identical) unless settings["dsa"]["pd_overlay_enabled"] is true and
    a signal table is given; countries without a DSA row, with a score of exactly 50 or with a PD of 0 keep their PD.

    EQ-B-0080, both off by default: `dsa.overlay_exclude` (country names) are treated as having no row, so their PD is
    unchanged (meant for Japan and Singapore, whose score of 100 comes from debt level alone); `dsa.overlay_raise_only`
    treats a score below 50 as 50, so the overlay can raise a PD but never lower one."""
    w = float(dsa_setting(settings, "pd_logit_weight"))
    if signal is None or not dsa_setting(settings, "pd_overlay_enabled") or w == 0.0:
        return pd_default
    score = signal.set_index("country")["dsa_score"].reindex(pd_default.index)
    excl = _exclude_names(dsa_setting(settings, "overlay_exclude"))
    if excl:
        score = score.where(~score.index.isin(excl))          # excluded countries: no row, PD unchanged
    if dsa_setting(settings, "overlay_raise_only"):
        score = score.clip(lower=50.0)                        # a score below 50 never lowers a PD (NaN stays NaN)
    p = pd_default.clip(1e-6, 0.99)
    lo = np.log(p / (1 - p)) + w * (score.fillna(50.0) - 50.0) / 50.0
    adj = pd.Series(np.minimum(0.99, 1 / (1 + np.exp(-lo))), index=pd_default.index)
    keep = score.isna() | (score == 50.0) | (pd_default <= 0.0)     # no row, neutral score or a zero PD: unchanged
    return adj.where(~keep, pd_default)


def _exclude_names(v) -> set:
    """dsa.overlay_exclude as a set of country names: a string is one name; a list/tuple/set of strings as given;
    anything else is a ValueError (EQ-B-0078: a bare string must not be read as its characters)."""
    if v is None:
        return set()
    if isinstance(v, str):
        return {v} if v else set()
    if isinstance(v, (list, tuple, set, frozenset)) and all(isinstance(x, str) for x in v):
        return set(v)
    raise ValueError(f"dsa.overlay_exclude must be a country name or a list of names, got {v!r}")


def write_dsa_paths(run: dict, signal: pd.DataFrame, out_dir: str | Path) -> dict:
    """Write outputs/dsa_paths.csv (fan per country-year), dsa_signal.csv and dsa_paths_meta.json; never into data/."""
    import json
    out = Path(out_dir); out.mkdir(parents=True, exist_ok=True)
    p1 = out / PATHS_FILE; p2 = out / SIGNAL_FILE; p3 = out / META_FILE
    _sheet_safe(run["fan"][PATH_COLUMNS]).to_csv(p1, index=False)      # text cells never start a spreadsheet formula
    _sheet_safe(signal[SIGNAL_COLUMNS]).to_csv(p2, index=False)
    p3.write_text(json.dumps({**run["meta"], "schema": "eq-dsa-paths/1", "path_columns": PATH_COLUMNS, "signal_columns": SIGNAL_COLUMNS}, indent=1, default=float))
    return {"paths": p1, "signal": p2, "meta": p3}
