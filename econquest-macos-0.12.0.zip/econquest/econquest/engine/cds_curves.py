"""CDS term structure from quote snapshots (EQ-B-0048).

Bootstraps a piecewise-constant, risk-neutral hazard curve per country from a point-in-time CDS quote
snapshot (par spreads, or upfront + running coupon), reusing the reduced-form leg pricer of
`engine/cds.py` (roadmap 3.3). Validation note: docs/validation/cds-curves-and-rv.md.

ISDA-style simplifications (stated, not hidden):
* premiums paid quarterly (`cds.frequency`, 4) on a regular grid from t=0, no stub, no IMM dates,
  ACT/360 not modelled (year fractions are 1/freq);
* default assumed mid-period, accrued premium paid on default (half a period on average);
* flat continuously-compounded discount rate `cds.risk_free` (0.04), or a supplied zero curve
  (`discount_curve`: callable t -> zero rate, or a DataFrame/dict of (t, zero rate) points, linearly
  interpolated, flat beyond the ends);
* recovery: the quote row's `recovery` when present, else `cds.recovery` (0.40, the market convention
  for sovereign CDS, which equals 1 - market.lgd_hard/100 today). Layer 4's expected LGD is a physical
  loss forecast, not a pricing convention, so it is not used to strip quotes. The source is reported.

Hazards are risk-neutral (they price the spread including the default risk premium). The forward hazard
on each tenor interval is solved unconstrained; a negative solution (an inverted curve steep enough to
need survival to rise) is flagged `negative_forward_hazard`, floored at 0 for the curve that is used, and
the repricing error that the floor causes is reported. Nothing raises on a bad curve.

Inputs (HO-20261023-A-B-010). The curve frame is SNAPSHOT_COLUMNS, pinned to Team A's CDS_SNAPSHOT_COLUMNS
(econquest/ingestion/market/schema.py). Two ways in, both point in time at the run's as-of date D:
* `curves_from_market(data_dir, D)`: Team A's market store (econquest.ingestion.market, MARKET_COLUMNS rows) read
  with `market_history(data_dir, "cds", asof=D)` (snapshots saved by end of D, quotes dated <= D, later snapshot wins
  per KEY) and converted by `to_cds_snapshots` (one capture = one source/doc clause, CR14 and vendors preferred). No
  snapshot -> FileNotFoundError, never a fallback to seed spreads. `derived` rows are excluded (HO-20261023-A-B-011:
  derived values are indicative, never dealer quotes) and reported. `latest_market` is not used: it keeps each tenor's
  newest date separately, so one curve could mix market dates.
* `curves(frame, D)`: a SNAPSHOT_COLUMNS frame, e.g. data/market/cds_snapshots.csv (Team A's gated export).
Per (iso3, as_of) the newest capture is authoritative (HO-20261023-A-B-012): store snapshot ids
("<YYYY-MM-DDTHHMMSSZ>-<hash8>:...") rank by their save time; an older capture of the same date is ignored whole and
reported. Other ids rank by vintage, then id. Point in time on a frame: vintage (retrieved date) <= D and, for store
ids, saved by the end of D (the same cut as market_history on the store path).
"""
from __future__ import annotations

from typing import Callable

import numpy as np
import pandas as pd
from scipy.optimize import brentq

from econquest.ingestion.market.schema import SNAPSHOT_ID_RE, to_cds_snapshots
from econquest.ingestion.market.store import market_history

from . import cds as _cds
from .common import as_of_timestamp

# Curve snapshot contract (HO-20261023-B-A-009, = Team A's CDS_SNAPSHOT_COLUMNS). One row per quote.
SNAPSHOT_COLUMNS = {
    "snapshot_id": "str: id of one consistent curve capture (all tenors of one country at one time)",
    "as_of": "date: market date the quotes refer to (YYYY-MM-DD)",
    "iso3": "str: ISO 3166-1 alpha-3 of the reference entity (sovereign)",
    "instrument": "str: 'CDS' (other rows are ignored)",
    "tenor_y": "float: contract maturity in years (1, 2, 3, 5, 7, 10 ...)",
    "quote_type": "str: 'par_spread' (value in bp) or 'upfront' (value in points = % of notional, buyer pays)",
    "value": "float: the quote, units per quote_type",
    "running_bp": "float: running coupon in bp for 'upfront' quotes (100 / 500 standard); blank for par",
    "currency": "str: contract currency (USD, EUR)",
    "doc_clause": "str: ISDA documentation clause (CR14, MR14, ...)",
    "recovery": "float 0-1: recovery used by the quote source; blank -> cds.recovery",
    "source": "str: vendor / analyst / 'SYNTHETIC ...' for fixtures",
    "licence": "str: licence tag under which the quote may be used",
    "vintage": "date: when the row was captured/loaded (point-in-time guard); blank -> as_of",
}
REQUIRED = ("snapshot_id", "as_of", "iso3", "instrument", "tenor_y", "quote_type", "value")
QUOTE_TYPES = ("par_spread", "upfront")
HAZARD_BRACKET = (-2.0, 25.0)


def cds_params(settings=None) -> dict:
    """The `cds` block with today's code defaults (identical to cli.cmd_cds)."""
    cfg = (settings.get("cds", default={}) if settings is not None else {}) or {}
    return {"recovery": float(cfg.get("recovery", 0.4)), "risk_free": float(cfg.get("risk_free", 0.04)),
            "frequency": int(cfg.get("frequency", 4)), "reference_tenor_y": float(cfg.get("reference_tenor_y", 5))}


def make_discount(rate=0.04, discount_curve=None) -> float | Callable:
    """Flat rate, or a callable t -> zero rate built from a supplied curve."""
    if discount_curve is None:
        return float(rate)
    if callable(discount_curve):
        return discount_curve
    if isinstance(discount_curve, dict):
        pts = sorted((float(k), float(v)) for k, v in discount_curve.items())
    else:
        df = pd.DataFrame(discount_curve)
        pts = sorted(zip(df.iloc[:, 0].astype(float), df.iloc[:, 1].astype(float)))
    ts, zs = np.array([p[0] for p in pts]), np.array([p[1] for p in pts])
    return lambda t: np.interp(np.asarray(t, dtype=float), ts, zs)


def validate_snapshots(df: pd.DataFrame) -> tuple[pd.DataFrame, list[str]]:
    """Coerce types and drop unusable rows; returns (clean frame, list of issues). Missing required columns raise."""
    missing = [c for c in REQUIRED if c not in df.columns]
    if missing:
        raise ValueError(f"CDS snapshot is missing required columns {missing}; schema: {list(SNAPSHOT_COLUMNS)}")
    q = df.copy()
    for c in SNAPSHOT_COLUMNS:
        if c not in q.columns:
            q[c] = np.nan
    issues: list[str] = []
    q["as_of"] = pd.to_datetime(q["as_of"], errors="coerce")
    q["vintage"] = pd.to_datetime(q["vintage"], errors="coerce")
    for c in ("tenor_y", "value", "running_bp", "recovery"):
        q[c] = pd.to_numeric(q[c], errors="coerce")
    q["iso3"] = q["iso3"].astype(str).str.strip().str.upper()
    q["quote_type"] = q["quote_type"].astype(str).str.strip().str.lower()
    q["instrument"] = q["instrument"].astype(str).str.strip().str.upper()
    bad = (q["instrument"] != "CDS")
    bad_rows = {
        "not instrument CDS": bad,
        "unknown quote_type": ~q["quote_type"].isin(QUOTE_TYPES),
        "bad as_of": q["as_of"].isna(),
        "tenor_y missing or <= 0": ~(q["tenor_y"] > 0),
        "value missing": q["value"].isna(),
        "upfront without running_bp": (q["quote_type"] == "upfront") & q["running_bp"].isna(),
        "recovery outside [0, 1)": q["recovery"].notna() & ~q["recovery"].between(0, 0.999),
    }
    drop = pd.Series(False, index=q.index)
    for why, m in bad_rows.items():
        m = m.fillna(True) if m.dtype == object else m
        if m.any():
            issues.append(f"dropped {int(m.sum())} row(s): {why}")
        drop |= m
    return q[~drop].copy(), issues


def saved_at(snapshot_id: pd.Series) -> pd.Series:
    """Save time of Team A store captures, parsed from the id prefix "<YYYY-MM-DDTHHMMSSZ>-<hash8>"; NaT for other ids."""
    ids = snapshot_id.astype(str)
    head = ids.str.split(":", n=1).str[0]
    ok = head.str.fullmatch(SNAPSHOT_ID_RE.pattern)
    return pd.to_datetime(head.where(ok).str[:18], format="%Y-%m-%dT%H%M%SZ", errors="coerce")


def snapshot_as_of(df: pd.DataFrame, as_of, issues: list[str] | None = None) -> pd.DataFrame:
    """Point-in-time selection: per country, the latest snapshot with as_of <= cut, read from rows with vintage <= cut.

    The snapshot is the latest market date, then the newest store save time (HO-20261023-A-B-012: the newest
    snapshot_id per (iso3, as_of) is authoritative), then the latest vintage seen in it, then snapshot_id, so one
    curve comes from one capture; older captures of the same date are reported. Within that snapshot each tenor keeps its latest-vintage row (ties: last in file order), so a
    snapshot whose rows were loaded at different vintages keeps all its tenors. Superseded rows, and tenors of the
    chosen snapshot visible only at a vintage after the cut, are reported in `issues`. Rows after the cut are never read;
    for store ids "after the cut" also means saved after the end of D (save time from the id prefix)."""
    cut = pd.Timestamp(as_of).normalize()
    issues = issues if issues is not None else []
    dated = df["as_of"] <= cut
    saved = saved_at(df["snapshot_id"])
    # review fix (AGENT-08): a store capture saved after the end of D is never read, whatever its vintage
    known = (df["vintage"].isna() | (df["vintage"] <= cut)) & (saved.isna() | (saved.dt.normalize() <= cut))
    q = df[dated & known]
    if q.empty:
        return q
    q = q.assign(_v=q["vintage"].fillna(q["as_of"]), _row=np.arange(len(q)), _s=saved[dated & known].fillna(pd.Timestamp.min))
    snaps = (q.groupby(["iso3", "snapshot_id", "as_of"], as_index=False).agg(_s=("_s", "max"), _v=("_v", "max"))
             .sort_values(["iso3", "as_of", "_s", "_v", "snapshot_id"], kind="mergesort"))
    pick = snaps.groupby("iso3").tail(1)[["iso3", "snapshot_id", "as_of"]]
    older = snaps.merge(pick[["iso3", "as_of"]], on=["iso3", "as_of"]).merge(pick, how="left", indicator=True)
    older = older[older["_merge"] == "left_only"]
    if len(older):
        issues.append("older capture(s) of the same as_of ignored, newest is authoritative: "
                      + ", ".join(f"{r.iso3} {r.snapshot_id}" for r in older.itertuples()))
    out = q.merge(pick, on=["iso3", "snapshot_id", "as_of"]).sort_values(["iso3", "tenor_y", "_v", "_row"], kind="mergesort")
    dup = out.duplicated(["iso3", "tenor_y"], keep="last")
    if dup.any():
        d = out[dup]
        issues.append(f"superseded {int(dup.sum())} row(s) by a later vintage of the same snapshot and tenor: "
                      + ", ".join(f"{r.iso3} {r.snapshot_id} {r.tenor_y:g}y" for r in d.itertuples()))
        out = out[~dup]
    late = df[dated & ~known].merge(pick, on=["iso3", "snapshot_id", "as_of"])
    if len(late):
        have = set(zip(out["iso3"], out["tenor_y"]))
        miss = sorted({(r.iso3, r.snapshot_id, float(r.tenor_y)) for r in late.itertuples() if (r.iso3, r.tenor_y) not in have})
        if miss:
            issues.append("tenor(s) excluded, vintage after as_of: " + ", ".join(f"{i} {s} {tn:g}y" for i, s, tn in miss))
    return out.drop(columns=["_v", "_row", "_s"]).sort_values(["iso3", "tenor_y"], kind="mergesort").reset_index(drop=True)


def _price_gap(quote_type: str, value: float, running_bp: float, T: float, knots, lams, recovery, rate, freq) -> float:
    """Premium-leg PV minus protection-leg PV (plus upfront paid by the buyer); zero at the fitted hazard."""
    if quote_type == "par_spread":
        prem, prot = _cds._legs(value, T, knots, lams, recovery, rate, freq)
        return prem - prot
    prem, prot = _cds._legs(running_bp, T, knots, lams, recovery, rate, freq)
    return value / 100.0 + prem - prot


def bootstrap_curve(quotes: pd.DataFrame, recovery: float, rate=0.04, freq: int = 4) -> dict:
    """Fit one country's curve from its snapshot rows (columns tenor_y, quote_type, value, running_bp).

    Returns knots, raw and used hazards, per-tenor repricing errors and flags. Never raises on market data."""
    g = quotes.sort_values("tenor_y", kind="mergesort")      # stable: keep="last" below means last in input order
    flags: list[str] = []
    if g["tenor_y"].duplicated().any():
        flags.append("duplicate_tenor")
        g = g.drop_duplicates("tenor_y", keep="last")
    knots = g["tenor_y"].to_numpy(dtype=float)
    qtypes, vals = g["quote_type"].tolist(), g["value"].to_numpy(dtype=float)
    runs = g["running_bp"].to_numpy(dtype=float)
    raw: list[float] = []
    used: list[float] = []
    for i, T in enumerate(knots):
        def f(lam, i=i, T=T):
            return _price_gap(qtypes[i], vals[i], runs[i], T, knots[: i + 1], np.array(used + [lam]), recovery, rate, freq)
        lo, hi = HAZARD_BRACKET
        flo, fhi = f(lo), f(hi)
        if flo * fhi > 0:
            lam = lo if abs(flo) < abs(fhi) else hi
            flags.append(f"no_root_{T:g}y")
        else:
            lam = float(brentq(f, lo, hi, xtol=1e-12))
        raw.append(lam)
        if lam < 0:
            flags.append(f"negative_forward_hazard_{T:g}y")
        used.append(max(lam, 0.0))
    used_a = np.array(used)
    par_fit, err = [], []
    for i, T in enumerate(knots):
        s_fit = _cds.fair_spread(T, knots, used_a, recovery, rate, freq)
        par_fit.append(s_fit)
        if qtypes[i] == "par_spread":
            err.append(s_fit - vals[i])
        else:   # upfront: error expressed in points of upfront
            prem, prot = _cds._legs(runs[i], T, knots, used_a, recovery, rate, freq)
            err.append(((prot - prem) * 100.0 - vals[i]) * 100.0)   # in bp of notional
    par_q = [v if q == "par_spread" else np.nan for q, v in zip(qtypes, vals)]
    pq = np.array([p for p in par_fit])
    if len(knots) > 1 and np.any(np.diff(pq) < -1e-6):
        flags.append("inverted_curve")
    if len(knots) == 1:
        flags.append("single_tenor_flat_curve")
    if "upfront" in qtypes:
        flags.append("upfront_converted")
    return {"knots": knots, "hazard_raw": np.array(raw), "hazard": used_a, "par_quoted_bp": np.array(par_q, dtype=float),
            "par_fit_bp": np.array(par_fit), "reprice_error_bp": np.array(err), "quote_type": qtypes, "value": vals,
            "flags": flags}


def _recovery_for(g: pd.DataFrame, default: float) -> tuple[float, str]:
    r = g["recovery"].dropna() if "recovery" in g else pd.Series(dtype=float)
    if len(r):
        return float(r.iloc[-1]), "quote"
    return float(default), "cds.recovery"


def curves(snapshots: pd.DataFrame, as_of=None, settings=None, discount_curve=None) -> tuple[pd.DataFrame, pd.DataFrame, list[str]]:
    """Point-in-time curves for every country in the snapshot file.

    Returns (curve_table, summary, issues):
    * curve_table: grain iso3 x tenor_y (one as_of per iso3) with forward hazard, survival, PDs, fitted par
      spread and repricing error - the proposed outputs/cds_curves.csv;
    * summary: one row per iso3 with risk-neutral 1y and 5y cumulative PD, hazards, reference-tenor spread,
      flags and whether the source is synthetic."""
    p = cds_params(settings)
    cut = as_of_timestamp(settings, as_of)
    rate = make_discount(p["risk_free"], discount_curve)
    clean, issues = validate_snapshots(snapshots)
    snap = snapshot_as_of(clean, cut, issues)
    rows, summ = [], []
    for iso, g in snap.groupby("iso3"):
        rec, rec_src = _recovery_for(g, p["recovery"])
        fit = bootstrap_curve(g, rec, rate, p["frequency"])
        knots, lam = fit["knots"], fit["hazard"]
        S = _cds.survival(knots, knots, lam)
        prev = np.concatenate([[0.0], knots[:-1]])
        S_prev = _cds.survival(prev, knots, lam)
        src = "; ".join(sorted(set(g["source"].dropna().astype(str))))
        lic = "; ".join(sorted(set(g["licence"].dropna().astype(str))))
        synthetic = "synthetic" in (src + lic).lower()
        flag_s = ",".join(fit["flags"])
        meta = {"iso3": iso, "as_of": g["as_of"].max().strftime("%Y-%m-%d"), "snapshot_id": str(g["snapshot_id"].iloc[0]),
                "recovery": rec, "recovery_source": rec_src, "currency": ",".join(sorted(set(g["currency"].dropna().astype(str)))),
                "doc_clause": ",".join(sorted(set(g["doc_clause"].dropna().astype(str)))), "source": src, "licence": lic,
                "synthetic": synthetic}
        for i, T in enumerate(knots):
            rows.append({**meta, "tenor_y": float(T), "quote_type": fit["quote_type"][i], "quote_value": float(fit["value"][i]),
                         "par_spread_bp": float(fit["par_fit_bp"][i]), "hazard_fwd": float(lam[i]), "hazard_fwd_raw": float(fit["hazard_raw"][i]),
                         "survival": float(S[i]), "cum_pd": float(1 - S[i]), "fwd_pd": float(1 - S[i] / S_prev[i]) if S_prev[i] > 0 else np.nan,
                         "reprice_error_bp": float(fit["reprice_error_bp"][i]), "flags": flag_s})
        ref = p["reference_tenor_y"]
        S1, S5 = _cds.survival([1.0, 5.0], knots, lam)
        summ.append({**meta, "tenors": ",".join(f"{t:g}" for t in knots), "hazard_1y": float(-np.log(S1)),
                     "hazard_5y_avg": float(-np.log(S5) / 5.0), "pd_1y_rn": float(1 - S1), "pd_5y_cum_rn": float(1 - S5),
                     f"spread_{ref:g}y_bp": float(_cds.fair_spread(ref, knots, lam, rec, rate, p["frequency"])),
                     "max_abs_reprice_error_bp": float(np.nanmax(np.abs(fit["reprice_error_bp"]))), "flags": flag_s})
    return pd.DataFrame(rows), pd.DataFrame(summ), issues


def par_spread_at(curve_table: pd.DataFrame, iso3: str, maturity: float, settings=None, discount_curve=None) -> float:
    """Par spread (bp) at any maturity off a fitted curve from `curves()`; NaN if the country has no curve."""
    g = curve_table[curve_table["iso3"] == iso3].sort_values("tenor_y") if len(curve_table) else curve_table
    if g is None or g.empty:
        return float("nan")
    p = cds_params(settings)
    return float(_cds.fair_spread(float(maturity), g["tenor_y"].to_numpy(float), g["hazard_fwd"].to_numpy(float),
                                  float(g["recovery"].iloc[0]), make_discount(p["risk_free"], discount_curve), p["frequency"]))


def market_snapshots(market: pd.DataFrame, currency: str | None = "USD", issues: list[str] | None = None) -> pd.DataFrame:
    """SNAPSHOT_COLUMNS frame from saved MARKET_COLUMNS rows (Team A's to_cds_snapshots). Rows with derived=True are
    dropped first and reported (HO-20261023-A-B-011: computed values are indicative, never treated as dealer quotes)."""
    issues = issues if issues is not None else []
    m = market[market["instrument"] == "cds"] if "instrument" in market else market
    der = m["derived"].astype(bool) if "derived" in m else pd.Series(False, index=m.index)
    if der.any():
        issues.append(f"excluded {int(der.sum())} derived cds row(s) (indicative, not dealer quotes): "
                      + ", ".join(sorted({f"{r.iso} {r.source} {r.tenor_y:g}y {r.field}" for r in m[der].itertuples()})))
    return to_cds_snapshots(m[~der], currency=currency)


def gated_cds_history(data_dir, asof: str, issues: list[str] | None = None) -> pd.DataFrame:
    """CDS rows known at `asof` that the market gate did not hold (HO-20261025-A-B-015).

    Uses Team A's `store.gated_market_history(data_dir, instrument="cds", asof=...)` when it exists. Until then:
    market_history minus every series (SERIES: the key without the date) whose latest quote at `asof` is held by
    cds_export.market_gate_review, which replays only gate-passed history (SEC-A-003 L5). A held series is dropped
    whole, never replaced by an older quote of the same series, and each drop is reported in `issues`.
    Two hold kinds are left to the existing layer-2 rules, so their behaviour and messages do not change: a hold
    whose only reason is "stale" (the run's staleness rule is probability.market_term.max_age_days, not the gate's
    3 business days) and derived rows (excluded and reported by market_snapshots)."""
    from econquest.ingestion.market import store as _store
    helper = getattr(_store, "gated_market_history", None)
    if helper is not None:
        out = helper(data_dir, instrument="cds", asof=asof)
        if issues is not None:
            issues.extend(out.attrs.get("issues", []))
        return out
    from econquest.ingestion.market.cds_export import market_gate_review
    from econquest.ingestion.market.gate import series_key
    from econquest.ingestion.market.schema import SERIES
    rows = market_history(data_dir, instrument="cds", asof=asof)
    review, cur = market_gate_review(data_dir, as_of=asof)
    held = review[review["status"] == "hold"]
    if held.empty or rows.empty:
        return rows
    why = {}
    for k, c, reason in zip(held["key"], held["country"], held["reason"]):
        hard = [x for x in str(reason).split("; ") if x and not x.startswith(("stale:", "flag:"))]
        if hard:
            why[(k, c)] = "; ".join(hard)
    drop = {}
    cds = cur[cur["instrument"] == "cds"]
    if "derived" in cds:
        cds = cds[~cds["derived"].astype(str).str.lower().isin(["true", "1"])]
    for _, r in cds.iterrows():
        w = why.get((series_key(r), r["iso"]))
        if w is not None:
            drop[tuple(str(r[c]) for c in SERIES)] = (r, w)
    if not drop:
        return rows
    sid = rows[SERIES].astype(str).apply(tuple, axis=1)
    if issues is not None:
        for r, w in drop.values():
            issues.append(f"market gate holds {r['iso']} {r['source']} {float(r['tenor_y']):g}y {r['field']} "
                          f"(quote {r['asof']}): {w}; series not used")
    return rows[~sid.isin(set(drop))].reset_index(drop=True)


def curves_from_market(data_dir, as_of=None, settings=None, discount_curve=None,
                       currency: str | None = "USD") -> tuple[pd.DataFrame, pd.DataFrame, list[str]]:
    """`curves()` on Team A's market store at the run's as-of date (HO-20261023-A-B-010): market_history(data_dir,
    "cds", asof=D) without the series the market gate holds (gated_cds_history, HO-20261025-A-B-015) ->
    market_snapshots -> curves. FileNotFoundError when no snapshot was saved by D (no fallback).
    Reads only <data_dir>/live/market/snapshots (Team A's store); ALFRED replay dirs (data/replay/...) are separate
    data dirs and are never read from here unless passed explicitly as data_dir."""
    cut = as_of_timestamp(settings, as_of)
    issues: list[str] = []
    snaps = market_snapshots(gated_cds_history(data_dir, cut.strftime("%Y-%m-%d"), issues), currency, issues)
    ct, sm, more = curves(snaps, cut, settings, discount_curve)
    return ct, sm, issues + more
