"""The compute pipeline: scorecard -> L1 hazard -> L2 posterior -> L3 regime -> L4 severity ->
L5 dependence -> L6 Monte Carlo, plus the arbitrage scan. One call, one `RunResult`."""
from __future__ import annotations
import dataclasses
import time
import warnings
from dataclasses import dataclass, field
from datetime import datetime, timezone
import numpy as np
import pandas as pd
from ..config import Settings
from ..versioning import with_as_of, with_replay
from ..persistence.jsonio import dumps  # noqa: F401  (re-exported: cli, api, gui import it from here; EQ-B-0016)
from ..ingestion import Universe
from ..scorecard import score_universe, Scorecard
from .common import logistic_curve
from .gpr import run_gpr
from .signals import SIGNAL_NAMES, OPTIONAL_SIGNAL_NAMES, compute_signals, trade_activation, dashboard_table
from . import layer1_hazard as L1, layer2_bayesian as L2, layer3_regime as L3, layer4_severity as L4, layer5_copula as L5, layer6_montecarlo as L6
from . import regime_hmm as RH
from . import bond_rv as BRV
from . import dsa as DSA


@dataclass
class RunResult:
    run_id: str
    created_at: str
    settings: dict
    provenance: dict
    scorecard: Scorecard
    country: pd.DataFrame
    positions: pd.DataFrame
    mc: L6.MCResult
    arbitrage: pd.DataFrame
    correlation: pd.DataFrame
    diagnostics: dict
    layer1_model: dict
    timings: dict = field(default_factory=dict)
    label: str = "base"
    gpr_country: pd.DataFrame | None = None
    gpr_global: dict | None = None
    signals: pd.DataFrame | None = None
    activation: pd.DataFrame | None = None
    dashboard: pd.DataFrame | None = None

    @property
    def metrics(self) -> dict:
        return self.mc.metrics

    def summary(self) -> dict:
        c = self.country
        return {"run_id": self.run_id, "label": self.label, "created_at": self.created_at, "as_of": self.settings.get("as_of"), "metrics": self.metrics,
                "global_regime": self.diagnostics["global_regime"], "regimes": c["regime"].value_counts().to_dict(),
                "top_default_pd": c["pd_default"].sort_values(ascending=False).head(5).round(4).to_dict(),
                "arbitrage_flags": int(self.arbitrage["divergence_flag"].sum()) if len(self.arbitrage) else 0,
                "timings": self.timings, "versions": {k: v for k, v in (self.provenance.get("versions") or {}).items() if k != "data_files"}}

    def to_dict(self) -> dict:
        return {"summary": self.summary(), "settings": self.settings, "provenance": self.provenance,
                "country": self.country.reset_index().rename(columns={"index": "country"}).to_dict(orient="records"),
                "positions": self.positions.reset_index().to_dict(orient="records"),
                "contributions": self.mc.contributions.reset_index().to_dict(orient="records"),
                "by_country": self.mc.by_country.reset_index().to_dict(orient="records"),
                "arbitrage": self.arbitrage.to_dict(orient="records"),
                "loss_histogram": L6.loss_histogram(self.mc.losses),
                "loss_quantiles": {str(q): float(np.quantile(self.mc.losses, q)) for q in (0.5, 0.9, 0.95, 0.975, 0.99, 0.995, 0.999)},
                "diagnostics": self.diagnostics, "layer1_model": self.layer1_model,
                "signals": None if self.signals is None else self.signals.reset_index().rename(columns={"index": "key"}).to_dict(orient="records"),
                "activation": None if self.activation is None else self.activation.reset_index().rename(columns={"index": "trade"}).to_dict(orient="records"),
                "dashboard": None if self.dashboard is None else self.dashboard.reset_index().to_dict(orient="records"),
                "gpr_global": self.gpr_global,
                # additive (contract C5, EQ-B-0030): names for the store's signals table, pillar scores for country notes
                "signal_names": None if self.signals is None else {int(k): SIGNAL_NAMES.get(int(k)) or OPTIONAL_SIGNAL_NAMES.get(int(k), f"signal {k}") for k in self.signals.index},
                "pillars": self.scorecard.pillar_final.to_dict()}                      # {country: {pillar: score}}


def resolve_as_of(as_of=None) -> str:
    """The run's as-of date as YYYY-MM-DD. None means today: the only wall-clock read in the model
    path, made once at the pipeline entry (GOV-012). Accepts a str, date, datetime or Timestamp."""
    ts = pd.Timestamp.today() if as_of is None or (isinstance(as_of, str) and not as_of.strip()) else pd.Timestamp(as_of)
    return ts.strftime("%Y-%m-%d")


def run_pipeline(u: Universe, settings: Settings, label: str = "base", paths: int | None = None, as_of=None,
                 market_dir=None) -> RunResult:
    """Run every layer once. `as_of` (YYYY-MM-DD) fixes the model date; if omitted, settings["as_of"] is
    used, else today. The resolved date is stored as settings["as_of"] in the run (the caller's Settings is
    not modified), so two runs with the same inputs and as_of give the same numbers on any calendar day."""
    t0 = time.perf_counter(); timings = {}
    as_of = resolve_as_of(as_of if as_of is not None else settings.get("as_of"))
    settings = dataclasses.replace(settings, raw={**settings.raw, "as_of": as_of})
    settings = L4.effective_severity(settings)   # layer4.lgd_source "fitted" -> fitted haircut means (EQ-B-0037); same object otherwise
    # GPR uplift on indicator 4.10 (runs before the scorecard because it changes an input)
    gpr_country = gpr_global = None
    if u.gpr is not None:
        gpr_country, gpr_global = run_gpr(u, settings, u.gpr)
        ind = u.indicators.set_index("id")
        ind.loc["4.10", u.names] = [float(gpr_country.at[c, "final_410"]) for c in u.names]
        u = dataclasses.replace(u, indicators=ind.reset_index())   # keeps weo_raw and prices (the old rebuild dropped weo_raw)
    timings["gpr"] = time.perf_counter() - t0
    # Scorecard (Appendix A)
    sc = score_universe(u, settings); timings["scorecard"] = time.perf_counter() - t0; t = time.perf_counter()
    names = u.names
    prof = u.countries.set_index("country").loc[names]
    # Layer 1
    l1 = L1.run_layer1(u, settings, sc.pillar_aggregated.loc[4]); timings["layer1"] = time.perf_counter() - t; t = time.perf_counter()
    # Layer 3 (regime first: multipliers feed the PDs)
    regime, hmm_info = RH.hmm_regimes(u, settings)          # regime.method: rules (default) | hmm | blend
    P_fit = np.array(hmm_info["transition_12m"]) if (hmm_info.get("fitted") and settings.get("transition_matrix", "source", default="assumptions") == "hmm") else None
    mult = L3.regime_multipliers(regime, settings, P=P_fit)
    gstate = L3.global_regime(regime, settings)
    gweight = L3.global_stress_weight(regime, settings)       # 0/1 under the default step switch (EQ-B-0042)
    df = L3.blended_degrees_of_freedom(settings, gweight, u)  # u only read when copula.nu_source is "estimated" (EQ-B-0036)
    # Layer 2
    post = L2.posterior(u, settings, l1["pd_model"], sc.composite, market_dir=market_dir)  # market_dir read only with probability.market_term (EQ-B-0100)
    prior = L2.default_contract_prior(u, settings)
    p_final = L2.blend_with_market(post, prior, settings)
    timings["layers2_3"] = time.perf_counter() - t; t = time.perf_counter()
    # Country table
    drv = sc.drivers()
    per = settings["perils"]
    country = pd.DataFrame(index=names)
    country["iso"] = prof["iso"]; country["region"] = prof["region"]; country["rating"] = prof["rating"]; country["spread_bps"] = prof["spread"]
    country["composite"] = sc.composite; country["grade"] = sc.grade
    country["regime"] = regime; country["pd_mult"] = mult["pd_mult"]; country["lgd_mult"] = mult["lgd_mult"]; country["p_crisis_12m"] = mult["p_crisis_12m"]
    country["regime_rule"] = pd.Series(hmm_info["regime_rule"]).reindex(names)
    country["regime_hmm"] = pd.Series(hmm_info.get("regime_hmm") or {}, dtype=object).reindex(names)
    country["p_crisis_hmm"] = pd.Series({c: v["p_crisis"] for c, v in (hmm_info.get("probabilities") or {}).items()}, dtype=float).reindex(names)
    for f in L1.FEATURES:
        country[f] = l1[f]
    country["pd_hazard_l1"] = l1["pd_hazard"]; country["pd_rating"] = l1["pd_rating"]; country["pd_model_l1"] = l1["pd_model"]
    for k in ("pd_market", "pd_market_phys", "fx_weight", "score_dev", "z_cds", "z_fx", "z_tsi", "z_event", "event_flag", "logodds_post", "pd_post"):
        country[k] = post[k]
    country["pm_default"] = prior["pm_default"]; country["tau_market"] = prior["tau_market"]
    for k in ("market_spread_bp", "spread_equiv_bp", "hazard_1y_rn", "market_source", "market_licence", "market_as_of",
              "market_snapshot_id", "market_term_reason"):
        if k in post:                                          # only when probability.market_term is on (EQ-B-0100)
            country[k] = post[k]
    market_term_diag = None
    if "market_term_reason" in post:                           # EQ-B-0100: keep the curve issues and fallback count
        n_fb = int(post["market_term_reason"].astype(str).str.startswith("profile fallback").sum())
        market_term_diag = {"issues": list(post.attrs.get("market_term_issues", [])), "fallback_count": n_fb,
                            "countries": int(len(post))}
        if n_fb:
            warnings.warn(f"probability.market_term: {n_fb} of {len(post)} countries fell back to the profile spread "
                          "(see country.market_term_reason)", RuntimeWarning, stacklevel=2)
    country["pd_final"] = p_final
    country["pd_default"] = np.minimum(0.99, p_final * mult["pd_mult"])
    # EQ-B-0070, off by default: DSA signal table (dsa.signal_enabled) and optional PD overlay (dsa.pd_overlay_enabled,
    # dsa.pd_logit_weight); pd_overlay returns the same Series when off
    dsa_sig = DSA.dsa_signal_hook(u, settings)
    country["pd_default"] = DSA.pd_overlay(country["pd_default"], dsa_sig, settings)
    country["pd_model"] = np.minimum(0.99, post["pd_post"] * mult["pd_mult"])          # before the market prior, regime-adjusted
    country["pm_gap_pp"] = (country["pd_model"] - country["pm_default"]) * 100
    for peril, key in (("Transfer and convertibility", "pd_tc"), ("Expropriation", "pd_ex"), ("Political violence", "pd_pv"), ("Sanctions", "pd_sa")):
        country[key] = np.minimum(0.99, mult["pd_mult"] * logistic_curve(drv.loc[peril], per[peril]["base"], per[peril]["slope"]))
        country["drv_" + key[3:]] = drv.loc[peril]
    country["pd_any"] = 1 - (1 - country["pd_default"]) * (1 - country["pd_tc"]) * (1 - country["pd_ex"]) * (1 - country["pd_pv"]) * (1 - country["pd_sa"])
    # Layer 4
    merton = L4.merton_distance_to_distress(u, settings, sc)
    for k in ("DD", "pd_merton", "lgd_uplift"):
        country[k] = merton[k]
    base_lgd = settings["market"]["lgd_hard"] / 100
    apply_uplift = bool(settings.get("layer4", "merton", "apply_uplift", default=False))
    # one formula with layer 6 (EQ-B-0097 review): layer4.lgd_cap and layer4.merton.uplift_in_default apply to both
    dflt = (u.countries.set_index("country")["default"].reindex(country.index).map(L4.in_default).fillna(False).to_numpy(bool)
            if "default" in u.countries.columns else np.zeros(len(country), bool))
    country["lgd_hard_expected"] = L4.expected_lgd_hard(base_lgd, mult["lgd_mult"],
                                                        L4.applied_uplift(country["lgd_uplift"] * apply_uplift, dflt, settings), settings)
    country["el_default"] = country["pd_default"] * country["lgd_hard_expected"]
    mults = L4.position_multipliers(u.portfolio, settings)
    timings["layer4"] = time.perf_counter() - t; t = time.perf_counter()
    # Layer 5
    loadings = L3.blended_factor_loadings(u, settings, regime, gweight)
    corr = L5.correlation_matrix(u, loadings)
    timings["layer5"] = time.perf_counter() - t; t = time.perf_counter()
    # Layer 6
    positions = L6.build_positions(u, country, settings, mults, df)
    mc = L6.simulate(u, country, positions, loadings, settings, df, paths=paths)
    timings["layer6"] = time.perf_counter() - t; t = time.perf_counter()
    # Arbitrage engine
    arb = L2.arbitrage_scan(u, settings, country, sc)
    # EQ-B-0049/0056, off by default; with `market_dir` (a data folder) the market spreads come from Team A's market
    # store point in time at as_of, else from the Country Profile
    bond_rv_tbl = (BRV.country_rv_pit(country, settings, data_dir=market_dir, as_of=settings.get("as_of"))
                   if settings.get("bond_rv", "enabled", default=False) else None)
    timings["arbitrage"] = time.perf_counter() - t; t = time.perf_counter()
    # Signals, playbook activation, dashboard
    signals = activation = dash = None
    if gpr_country is not None and u.playbook is not None:
        signals = compute_signals(u, settings, sc, country, gpr_country, gpr_global, arb,
                                  dsa=dsa_sig if settings.get("dsa", "signal_enabled", default=False) else None)
        activation = trade_activation(u, u.playbook, signals)
        dash = dashboard_table(u, settings, country, signals, activation, u.playbook, gpr_country, arb)
    timings["signals"] = time.perf_counter() - t
    timings["total"] = time.perf_counter() - t0
    off = np.triu_indices(len(names), 1)
    diagnostics = {"global_regime": gstate, "degrees_of_freedom": df, "share_not_calm": float((regime != "Calm").mean()),
                   "global_stress_weight": gweight, "global_share": L3.global_share(regime, settings),
                   "bond_rv": None if bond_rv_tbl is None else bond_rv_tbl.to_dict("records"),
                   "copula": L5.copula_diagnostics(u, settings),                 # EQ-B-0077: what the loadings rest on
                   "dsa_signal": None if dsa_sig is None else dsa_sig.to_dict("records"),
                   "mean_latent_correlation": float(corr.to_numpy()[off].mean()),
                   "tail_dependence_at_mean_corr": L5.tail_dependence(float(corr.to_numpy()[off].mean()), df),
                   "tail_dependence_gaussian_equivalent": 0.0, "scenario_override": settings.scenario_override,
                   "sobol": settings.use_sobol, "validation": u.validate(),
                   "loadings": {n: float(loadings.at[n, "global"]) for n in names},
                   "regime_hmm": {"method": hmm_info["method"], "fitted": hmm_info.get("fitted", False), "agreement_rate": hmm_info.get("agreement_rate"),
                                  "transition_12m": hmm_info.get("transition_12m"), "transition_weekly": hmm_info.get("transition_weekly"),
                                  "assumptions_12m": hmm_info["assumptions_12m"], "transition_source": "hmm" if P_fit is not None else "assumptions",
                                  "fallback": hmm_info.get("fallback", []), "reason": hmm_info.get("reason"), "state_means": hmm_info.get("state_means"),
                                  "n_country_weeks": hmm_info.get("n_country_weeks"),
                                  "features": hmm_info.get("features"), "etf_feature": hmm_info.get("etf_feature")}}
    if market_term_diag is not None:                           # key present only when the switch is on (EQ-B-0100)
        diagnostics["market_term"] = market_term_diag
    run_id = datetime.now(timezone.utc).strftime("%Y%m%dT%H%M%S") + f"-{label}"
    # run versions carry the resolved as_of and any replay ids, with run_hash recomputed (EQ-B-0017, contract C5);
    # a copy, because stress runs share u.provenance
    versions = with_replay(with_as_of(u.provenance.get("versions") or {}, as_of), u.provenance.get("replay"))
    provenance = {**u.provenance, "versions": versions}
    return RunResult(run_id, datetime.now(timezone.utc).isoformat(), settings.raw, provenance, sc, country, positions, mc, arb, corr,
                     diagnostics, l1.attrs.get("model", {}), timings, label, gpr_country, gpr_global, signals, activation, dash)
