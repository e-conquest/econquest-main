"""Event stress index for the layer-2 text term (EQ-B-0033, GOV-014).

A per-country, point-in-time stress z-score built from UCDP (organised-violence events and fatalities) and
GDELT (media event counts, Goldstein scale, tone). Each component is standardised against the country's own
trailing history, signed so that more stress is positive, and the components are combined with fixed weights.

Input contract (HO-20261023-B-A-004, Team A adapters EQ-A-0022 / EQ-A-0023): a long table with columns
    iso, source, series, freq, period, value, vintage   (+ optional provenance)
  source  ucdp_ged | ucdp_candidate | gdelt
  series  events | fatalities | goldstein_mean | tone_mean
  freq    D | M | A;   period = period start;   vintage = date the row became available to the desk.
A covered country-period carries explicit zero counts; a missing row is "not covered", never "calm".

Point in time: at `as_of` only rows with vintage <= as_of and period end <= as_of are used, and for a
revised row the latest vintage on or before as_of wins. Final GED rows take precedence over candidate rows
for the same month.

Method (defaults in DEFAULTS; overridable under settings["probability"]["text_index"]):
  windows   non-overlapping blocks of `window_days` ending on the component's data edge for that country (the
            last day its point-in-time rows cover; k = 0 current, 1..history_windows trailing). A component
            whose edge is more than `max_staleness_days` before as_of is not scored
  counts    rate per 30.4375 days over the covered days of the window, then log1p
  means     event-weighted mean (GDELT daily event count as the weight when present)
  coverage  a window needs at least `min_window_coverage` of its days covered, else it is missing
  z         (x_0 - mean(x_1..K)) / max(sd(x_1..K), std_floor), times the component sign, clipped at +-clip;
            needs >= min_history trailing windows
  index     sum_i w_i z_i / sum_i w_i over the components present; 0 with flag 'insufficient' when the
            present weight is below min_coverage, 0 with flag 'missing' when the country has no rows.
The module never reads the wall clock and draws no random numbers (CLAUDE.md, determinism rule).
"""
from __future__ import annotations
import numpy as np
import pandas as pd

EVENT_COLUMNS = ["iso", "source", "series", "freq", "period", "value", "vintage"]
SOURCES = ("ucdp_ged", "ucdp_candidate", "gdelt")
SERIES = ("events", "fatalities", "goldstein_mean", "tone_mean")
FREQS = ("D", "M", "A")
DAYS_PER_MONTH = 30.4375

# component -> (sources in priority order, series, sign, kind)
COMPONENTS = {
    "fatalities":      (("ucdp_ged", "ucdp_candidate"), "fatalities", 1.0, "count"),
    "conflict_events": (("ucdp_ged", "ucdp_candidate"), "events", 1.0, "count"),
    "media_events":    (("gdelt",), "events", 1.0, "count"),
    "goldstein":       (("gdelt",), "goldstein_mean", -1.0, "mean"),   # Goldstein -10 conflict .. +10 cooperation
    "tone":            (("gdelt",), "tone_mean", -1.0, "mean"),        # more negative tone = more stress
}

DEFAULTS = {
    "source": "none",               # none: z_tsi = textz (today's behaviour); events: z_tsi = textz + event index
    "window_days": 91,
    "history_windows": 20,          # 20 x 91 days ~ 5 years of trailing base
    "min_history": 8,               # ~2 years of trailing windows before a component is scored
    "min_window_coverage": 0.5,
    "max_staleness_days": 92,       # a component whose newest row ends more than this before as_of is not scored
    "std_floor": 0.25,
    "clip": 4.0,
    "min_coverage": 0.3,            # share of total weight that must be present
    "weights": {"fatalities": 0.35, "conflict_events": 0.15, "media_events": 0.10, "goldstein": 0.20, "tone": 0.20},
}
FLAGS = ("off", "ok", "partial", "insufficient", "missing")


def index_settings(settings=None) -> dict:
    """DEFAULTS overlaid with settings['probability']['text_index'] (absent key -> DEFAULTS, i.e. source 'none')."""
    cfg = {**DEFAULTS, "weights": dict(DEFAULTS["weights"])}
    if settings is None:
        user = {}
    elif isinstance(settings, dict):                     # a raw assumptions dict
        user = (settings.get("probability") or {}).get("text_index") or {}
    else:                                                # Settings
        user = settings.get("probability", "text_index", default=None) or {}
    for k, v in user.items():
        if k == "weights":
            cfg["weights"].update({str(a): float(b) for a, b in (v or {}).items()})
        else:
            cfg[k] = v
    unknown = set(cfg["weights"]) - set(COMPONENTS)
    if unknown:
        raise ValueError(f"probability.text_index.weights has unknown components {sorted(unknown)}")
    if str(cfg["source"]) not in ("none", "events"):
        raise ValueError(f"probability.text_index.source must be 'none' or 'events', got {cfg['source']!r}")
    return cfg


def _cfg(settings) -> dict:
    """A resolved config (a dict carrying 'window_days', e.g. from index_settings) or anything index_settings takes."""
    if isinstance(settings, dict) and "window_days" in settings:
        return {**DEFAULTS, **settings}
    return index_settings(settings)


def normalize_events(df: pd.DataFrame) -> pd.DataFrame:
    """Validate the contract and coerce types. Raises ValueError on a missing column or an unknown code."""
    missing = [c for c in EVENT_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"event table lacks columns {missing} (contract HO-20261023-B-A-004)")
    e = df.copy()
    e["iso"] = e["iso"].astype(str).str.strip().str.upper()
    for c in ("source", "series", "freq"):
        e[c] = e[c].astype(str).str.strip()
    e["freq"] = e["freq"].str.upper()
    for c, allowed in (("source", SOURCES), ("series", SERIES), ("freq", FREQS)):
        bad = sorted(set(e[c]) - set(allowed))
        if bad:
            raise ValueError(f"event table: unknown {c} values {bad}; allowed {list(allowed)}")
    e["period"] = pd.to_datetime(e["period"]).dt.normalize()
    e["vintage"] = pd.to_datetime(e["vintage"]).dt.normalize()
    e["value"] = pd.to_numeric(e["value"], errors="coerce")
    return e[e["value"].notna()].reset_index(drop=True)


def _period_end(period: pd.Series, freq: pd.Series) -> pd.Series:
    end = period.copy()
    m = freq == "M"
    end[m] = period[m] + pd.offsets.MonthEnd(0)
    a = freq == "A"
    end[a] = period[a] + pd.offsets.YearEnd(0)
    return end


def point_in_time(events: pd.DataFrame, as_of) -> pd.DataFrame:
    """Rows knowable at as_of: vintage <= as_of, period ended on or before as_of, latest vintage per key."""
    t = pd.Timestamp(as_of).normalize()
    e = events[(events["vintage"] <= t)]
    e = e[_period_end(e["period"], e["freq"]) <= t]
    e = e.sort_values("vintage", kind="mergesort")
    return e.drop_duplicates(["iso", "source", "series", "freq", "period"], keep="last")


def _to_units(e: pd.DataFrame) -> pd.DataFrame:
    """Daily rows stay daily; annual rows split into 12 monthly rows (counts / 12, means kept). Adds `days`."""
    a = e[e["freq"] == "A"]
    rest = e[e["freq"] != "A"]
    if len(a):
        reps = a.loc[a.index.repeat(12)].copy()
        offs = np.tile(np.arange(12), len(a))
        reps["period"] = [p + pd.DateOffset(months=int(k)) for p, k in zip(reps["period"], offs)]
        cnt = reps["series"].isin(("events", "fatalities"))
        reps.loc[cnt, "value"] = reps.loc[cnt, "value"] / 12.0
        reps["freq"] = "M"
        rest = pd.concat([rest, reps], ignore_index=True)
    out = rest.copy()
    out["days"] = np.where(out["freq"] == "D", 1, out["period"].dt.days_in_month).astype(float)
    return out


def _component_frame(u: pd.DataFrame, comp: str) -> pd.DataFrame:
    sources, series, _, _ = COMPONENTS[comp]
    rows = u[(u["series"] == series) & u["source"].isin(sources)].copy()
    if not len(rows):
        return rows
    rank = {s: i for i, s in enumerate(sources)}
    rows["_rank"] = rows["source"].map(rank)
    # source precedence per (iso, month), not per row period, so a daily candidate row cannot sit next to the final
    # monthly GED row of the same month (EQ-B-0047); the same rows as before when every source is monthly
    month = rows["period"].dt.to_period("M")
    rows = rows[rows["_rank"].to_numpy() == rows.groupby([rows["iso"], month])["_rank"].transform("min").to_numpy()]
    month = rows["period"].dt.to_period("M")
    nfreq = rows.groupby([rows["iso"], month])["freq"].transform("nunique")
    if (nfreq > 1).any():
        bad = rows.loc[nfreq > 1, ["iso", "source"]].assign(month=month[nfreq > 1].astype(str)).drop_duplicates().head(5)
        raise ValueError(f"event table: component {comp!r} has daily and monthly rows for the same country-month "
                         f"(they would be counted twice): {bad.values.tolist()}; send one frequency per source and month")
    rows = rows.sort_values(["_rank"], kind="mergesort").drop_duplicates(["iso", "period"], keep="first")
    return rows.drop(columns="_rank")


def _window_values(rows: pd.DataFrame, comp: str, t: pd.Timestamp, cfg: dict, weights_rows: pd.DataFrame | None) -> pd.DataFrame:
    """Per (iso, k) window value x for one component; rows outside windows 0..K dropped."""
    W = int(cfg["window_days"]); K = int(cfg["history_windows"])
    kind = COMPONENTS[comp][3]
    # each country's data edge: the last day its rows cover (UCDP candidate runs about a month behind GDELT)
    p_end = rows["period"] + pd.to_timedelta(rows["days"] - 1, unit="D")
    edge = p_end.groupby(rows["iso"]).transform("max")
    fresh = (t - edge).dt.days <= int(cfg["max_staleness_days"])
    end_excl = edge + pd.Timedelta(days=1)
    mid = rows["period"] + pd.to_timedelta((rows["days"] - 1) / 2.0, unit="D")
    k = np.floor((end_excl - mid).dt.total_seconds() / 86400.0 / W).astype(int)
    r = rows.assign(k=k.to_numpy())[fresh.to_numpy()]
    r = r[(r["k"] >= 0) & (r["k"] <= K)]
    if not len(r):
        return pd.DataFrame(columns=["iso", "k", "x"])
    if kind == "count":
        g = r.groupby(["iso", "k"]).agg(total=("value", "sum"), days=("days", "sum")).reset_index()
        g["x"] = np.log1p(g["total"] / g["days"] * DAYS_PER_MONTH)
    else:
        if weights_rows is not None and len(weights_rows):
            w = weights_rows[["iso", "period", "value"]].rename(columns={"value": "w"})
            r = r.merge(w, on=["iso", "period"], how="left")
            r["w"] = r["w"].where(r["w"] > 0, 1.0).fillna(1.0)
        else:
            r = r.assign(w=1.0)
        r = r.assign(wv=r["w"] * r["value"])
        g = r.groupby(["iso", "k"]).agg(wv=("wv", "sum"), w=("w", "sum"), days=("days", "sum")).reset_index()
        g["x"] = g["wv"] / g["w"]
    g = g[g["days"] >= float(cfg["min_window_coverage"]) * W]
    return g[["iso", "k", "x"]]


def event_stress_index(events: pd.DataFrame | None, as_of, settings=None, isos=None, normalized: bool = False) -> pd.DataFrame:
    """Per-country event stress index at `as_of` (index ISO3).

    Columns: event_index, flag (ok / partial / insufficient / missing), coverage (present weight share),
    z_<component> (NaN when not scored). `isos` fixes the output rows; countries without data get 0 and
    flag 'missing'."""
    cfg = _cfg(settings)
    t = pd.Timestamp(as_of).normalize()
    comps = [c for c in COMPONENTS if float(cfg["weights"].get(c, 0.0)) > 0]
    zcols = [f"z_{c}" for c in COMPONENTS]
    if events is None or not len(events):
        idx = pd.Index(sorted(set(isos or [])), name="iso")
        out = pd.DataFrame({"event_index": 0.0, "flag": "missing", "coverage": 0.0}, index=idx)
        for zc in zcols:
            out[zc] = np.nan
        return out
    e = events if normalized else normalize_events(events)
    e = _to_units(point_in_time(e, t))
    present = set(e["iso"])
    all_isos = sorted(set(isos) if isos is not None else present)
    z = pd.DataFrame(np.nan, index=pd.Index(all_isos, name="iso"), columns=zcols)
    gd_events = _component_frame(e, "media_events")
    for comp in comps:
        rows = _component_frame(e, comp)
        if not len(rows):
            continue
        wv = _window_values(rows, comp, t, cfg, gd_events if COMPONENTS[comp][3] == "mean" else None)
        if not len(wv):
            continue
        piv = wv.pivot(index="iso", columns="k", values="x")
        if 0 not in piv.columns:
            continue
        hist = piv.drop(columns=0)
        n = hist.notna().sum(axis=1)
        mu = hist.mean(axis=1)
        sd = hist.std(axis=1, ddof=1).fillna(0.0).clip(lower=float(cfg["std_floor"]))
        zz = (piv[0] - mu) / sd * COMPONENTS[comp][2]
        zz = zz.where(n >= int(cfg["min_history"])).clip(-float(cfg["clip"]), float(cfg["clip"]))
        z.loc[z.index.intersection(zz.index), f"z_{comp}"] = zz.reindex(z.index.intersection(zz.index))
    w = pd.Series({f"z_{c}": float(cfg["weights"].get(c, 0.0)) for c in COMPONENTS})
    wtot = float(w.sum())
    have = z.notna()
    wsum = have.mul(w, axis=1).sum(axis=1)
    num = z.fillna(0.0).mul(w, axis=1).sum(axis=1)
    coverage = wsum / wtot if wtot > 0 else wsum * 0
    ok = coverage >= float(cfg["min_coverage"])
    index = (num / wsum.where(wsum > 0)).where(ok, 0.0).fillna(0.0)
    flag = np.where(~z.index.isin(list(present)), "missing",
                    np.where(~ok, "insufficient", np.where(coverage >= 1 - 1e-12, "ok", "partial")))
    out = pd.DataFrame({"event_index": index.astype(float), "flag": flag, "coverage": coverage.astype(float)}, index=z.index)
    return out.join(z)


def layer2_text_term(textz: np.ndarray, iso: list[str], events: pd.DataFrame | None, settings, as_of=None):
    """The text term layer 2 adds with weight w_t. Returns (z_tsi, z_event, flag) arrays aligned with `iso`.

    source 'none' (default): z_tsi = textz exactly (today's behaviour), z_event 0, flag 'off'.
    source 'events'        : z_tsi = textz + event index; scenario shocks to textz (stress.py) still add on top.
    """
    cfg = index_settings(settings)
    base = np.asarray(textz, dtype=float)
    if cfg["source"] == "none":
        return base, np.zeros(len(base)), np.array(["off"] * len(base), dtype=object)
    if as_of is None:
        from .common import as_of_timestamp
        as_of = as_of_timestamp(settings)
    idx = event_stress_index(events, as_of, settings, isos=list(iso))
    ze = idx["event_index"].reindex(list(iso)).fillna(0.0).to_numpy(dtype=float)
    fl = idx["flag"].reindex(list(iso)).fillna("missing").to_numpy(dtype=object)
    return base + ze, ze, fl


# ---------------------------------------------------------------- backtest harness

def auc(y, s) -> float:
    """Mann-Whitney AUC with ties counted half (same estimator as validation.hazard_panel.auc)."""
    y = np.asarray(y, dtype=float); s = np.asarray(s, dtype=float)
    pos = s[y == 1]; neg = s[y == 0]
    if len(pos) == 0 or len(neg) == 0:
        return float("nan")
    r = pd.Series(np.concatenate([pos, neg])).rank(method="average").to_numpy()
    return float((r[: len(pos)].sum() - len(pos) * (len(pos) + 1) / 2) / (len(pos) * len(neg)))


def index_history(events: pd.DataFrame, dates, settings=None, isos=None) -> pd.DataFrame:
    """Index at each as-of date, point in time per date. Long frame: date, iso, event_index, flag, coverage."""
    e = normalize_events(events)
    out = []
    for d in dates:
        r = event_stress_index(e, d, settings, isos=isos, normalized=True)[["event_index", "flag", "coverage"]]
        out.append(r.reset_index().assign(date=pd.Timestamp(d).normalize()))
    return pd.concat(out, ignore_index=True)[["date", "iso", "event_index", "flag", "coverage"]]


def default_starts(defaults: pd.DataFrame) -> pd.DataFrame:
    """Spells (iso, start_date, end_date) from sovereign_defaults.csv (iso, start, end) or a hazard panel
    (iso, year, event). Year-only starts are dated 1 July (the benchmarks convention); end is inclusive to
    31 December of the end year; an open spell (no end) runs to the far future."""
    d = defaults.copy()
    if "start" in d.columns:
        s = pd.to_datetime(d["start_date"]) if "start_date" in d.columns else pd.to_datetime(d["start"].astype(int).astype(str) + "-07-01")
        end = pd.to_numeric(d["end"], errors="coerce") if "end" in d.columns else pd.Series(np.nan, index=d.index)
        e = pd.to_datetime(end.fillna(2262).astype(int).astype(str) + "-12-31", errors="coerce").fillna(pd.Timestamp.max)
    else:
        d = d[pd.to_numeric(d["event"], errors="coerce").fillna(0) > 0]
        s = pd.to_datetime(d["year"].astype(int).astype(str) + "-07-01")
        e = s
    return pd.DataFrame({"iso": d["iso"].astype(str).str.upper().to_numpy(), "start_date": s.to_numpy(), "end_date": pd.Series(e).to_numpy()})


def default_lead_auc(hist: pd.DataFrame, defaults: pd.DataFrame, windows_months=((0, 6), (6, 12), (0, 12), (12, 24)),
                     lag_window_months: int = 12) -> pd.DataFrame:
    """Does the index lead default starts? For each window (a, b] months after the as-of date, outcome 1 when a
    default starts in (d + a, d + b]. Country-dates already inside a spell are excluded, as are rows with flag
    missing/insufficient. The 'lagging' row scores starts in (d - lag_window, d]: a leading signal should
    score higher ahead than behind. Returns window, n, events, auc."""
    sp = default_starts(defaults)
    h = hist[hist["flag"].isin(("ok", "partial"))].copy()
    by_iso = {iso: g for iso, g in sp.groupby("iso")}
    in_spell = []
    for r in h.itertuples(index=False):
        g = by_iso.get(r.iso)
        in_spell.append(bool(g is not None and ((g["start_date"] <= r.date) & (g["end_date"] >= r.date)).any()))
    h = h[~np.array(in_spell, dtype=bool)] if len(h) else h

    def hit(row, lo, hi):
        g = by_iso.get(row.iso)
        return float(g is not None and ((g["start_date"] > lo) & (g["start_date"] <= hi)).any())

    rows = []
    for a, b in windows_months:
        y = [hit(r, r.date + pd.DateOffset(months=a), r.date + pd.DateOffset(months=b)) for r in h.itertuples(index=False)]
        rows.append({"window": f"+{a}..+{b}m", "n": len(y), "events": int(np.sum(y)), "auc": auc(y, h["event_index"])})
    y = [hit(r, r.date - pd.DateOffset(months=lag_window_months), r.date) for r in h.itertuples(index=False)]
    rows.append({"window": f"-{lag_window_months}..0m (lagging)", "n": len(y), "events": int(np.sum(y)), "auc": auc(y, h["event_index"])})
    return pd.DataFrame(rows)


def spread_lead_lag(hist: pd.DataFrame, spreads: pd.DataFrame, horizons_days=(-91, -30, 30, 91, 182),
                    widen_bps: float = 50.0) -> pd.DataFrame:
    """Lead-lag of the index against a spread (or any level) history: long frame iso, date, value.

    For h > 0: change from d to d + h (does the index lead widening?). For h < 0: change from d + h to d
    (did the index follow it?). Levels are taken as the last observation on or before each date. Returns
    horizon_days, n, corr (Pearson of index vs change), auc_widen (index vs change >= widen_bps), widenings."""
    s = spreads.copy()
    s["iso"] = s["iso"].astype(str).str.upper()
    s["date"] = pd.to_datetime(s["date"]).dt.normalize()
    s = s.dropna(subset=["value"]).sort_values("date")
    series = {iso: g.set_index("date")["value"] for iso, g in s.groupby("iso")}
    h = hist[hist["flag"].isin(("ok", "partial"))]

    def level(iso, d):
        g = series.get(iso)
        if g is None:
            return np.nan
        g = g[g.index <= d]
        return float(g.iloc[-1]) if len(g) else np.nan

    rows = []
    for hz in horizons_days:
        x, dv = [], []
        for r in h.itertuples(index=False):
            d0, d1 = (r.date, r.date + pd.Timedelta(days=hz)) if hz > 0 else (r.date + pd.Timedelta(days=hz), r.date)
            a, b = level(r.iso, d0), level(r.iso, d1)
            if np.isfinite(a) and np.isfinite(b):
                x.append(r.event_index); dv.append(b - a)
        x = np.asarray(x); dv = np.asarray(dv)
        corr = float(np.corrcoef(x, dv)[0, 1]) if len(x) > 2 and x.std() > 0 and dv.std() > 0 else float("nan")
        yw = (dv >= widen_bps).astype(float)
        rows.append({"horizon_days": hz, "n": len(x), "corr": corr, "auc_widen": auc(yw, x), "widenings": int(yw.sum())})
    return pd.DataFrame(rows)
