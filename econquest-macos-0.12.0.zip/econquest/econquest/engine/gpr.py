"""Caldara-Iacoviello Geopolitical Risk index: country uplift on indicator 4.10 and the GPR signals
(workbook GPR tab). Inputs: monthly GPR table (month, GPR, GPRT, GPRA, GPRC_xxx columns).

EQ-B-0072 adds an event-based country GPR score from UCDP (events, fatalities) and GDELT (conflict-event
volume, tone), the option `gpr.source` ("ci" default | "events" | "blend") that feeds it into the 4.10 uplift,
the elasticity of spreads and PDs to a GPR shock (estimated on a history) as a stress-shock expansion, and an
episode backtest. See docs/validation/gpr-events.md. Nothing here reads the wall clock or draws random numbers."""
from __future__ import annotations
import json
import warnings
from pathlib import Path
import numpy as np
import pandas as pd
from ..config import Settings
from ..ingestion import Universe
from . import event_index as EI
from .common import as_of_timestamp


def _stats(series: np.ndarray, window: int) -> dict:
    s = np.asarray(series, dtype=float)
    recent = s[-window:].mean()
    last60 = s[-60:]; last120 = s[-120:]
    sd = last60.std(ddof=1)
    z = (recent - last60.mean()) / sd if sd > 0 else 0.0
    pct = float(np.mean(last120 <= recent) * 100)
    prev12 = s[-12 - window:-window].mean()
    return {"recent": float(recent), "mean5y": float(last60.mean()), "sd5y": float(sd), "z": float(z), "percentile": pct,
            "momentum": float(recent / prev12) if prev12 else np.nan}


def run_gpr(u: Universe, settings: Settings, gpr: pd.DataFrame) -> tuple[pd.DataFrame, dict]:
    g = settings["gpr"]; w = g["signal_weight_percentile"]; n = int(g["window_months"])
    prof = u.countries.set_index("country").loc[u.names]
    ind = u.indicators.set_index("id")
    rows = {}
    for c in u.names:
        series = prof.at[c, "gpr_series"]
        analyst = pd.to_numeric(prof.at[c, "gpr_analyst_410"], errors="coerce")
        if pd.isna(analyst) and "4.10" in ind.index and c in ind.columns:
            # a profile row without the analyst 4.10 level (a newly added country, EQ-B-0034) takes the indicator
            # table's 4.10; min(4.0, nan) would otherwise have returned 4.0, the worst level, without a word
            analyst = pd.to_numeric(ind.at["4.10", c], errors="coerce")
        analyst = float(analyst)
        covered = isinstance(series, str) and series in gpr.columns
        if covered:
            st = _stats(gpr[series].to_numpy(dtype=float), n)
            uplift = 0
            if g["use_uplift"]:
                if st["percentile"] >= g["uplift2_percentile"] and st["z"] >= g["uplift2_z"]:
                    uplift = 2
                elif st["percentile"] >= g["uplift1_percentile"] or st["z"] >= g["uplift1_z"]:
                    uplift = 1
            signal = round(w * st["percentile"] + (1 - w) * max(0.0, min(100.0, 50 + 25 * st["z"])), 0)
        else:
            st = {k: np.nan for k in ("recent", "mean5y", "sd5y", "z", "percentile", "momentum")}
            uplift, signal = 0, 0.0
        rows[c] = {"series": series if covered else "", "covered": covered, **st, "analyst_410": analyst, "uplift": uplift,
                   "final_410": min(4.0, analyst + uplift) if np.isfinite(analyst) else np.nan, "signal": float(signal)}
    glob = _stats(gpr["GPR"].to_numpy(dtype=float), n)
    threats = gpr["GPRT"].to_numpy(dtype=float)[-n:].mean() / gpr["GPRA"].to_numpy(dtype=float)[-n:].mean()
    glob_signal = round(w * glob["percentile"] + (1 - w) * max(0.0, min(100.0, 50 + 25 * glob["z"])), 0)
    global_block = {**glob, "threats_acts_ratio": float(threats), "signal": float(glob_signal), "latest_month": str(gpr["month"].iloc[-1])}
    table = pd.DataFrame(rows).T
    source = gpr_source(settings)
    if source != "ci":
        # EQ-B-0072: event-based country GPR (UCDP/GDELT) replaces or blends with the Caldara-Iacoviello country
        # series. Off by default (gpr.source absent -> "ci"), so the default path above is untouched.
        table = _apply_event_source(table, u, settings, source)
    return table, global_block


# ================================================================ EQ-B-0072: event-based country GPR
#
# A country GPR score from UCDP (organised-violence events, fatalities) and GDELT (material-conflict event volume,
# tone), in the Team A long-table contract of event_index (HO-20261023-B-A-004). Monthly, per country, each
# component standardised against the country's own trailing history, point in time: only rows with
# vintage <= as_of and period end <= as_of are used (event_index.point_in_time). Off by default.

GPR_SOURCES = ("ci", "events", "blend")
STAT_KEYS = ("recent", "mean5y", "sd5y", "z", "percentile", "momentum")
EVENT_GPR_DEFAULTS = {
    # component weights (event_index.COMPONENTS names); goldstein available but off: the ticket asks for tone/volume
    "weights": {"fatalities": 0.30, "conflict_events": 0.20, "media_events": 0.20, "tone": 0.30, "goldstein": 0.0},
    "base_months": 60,             # trailing base for the per-country z of each month (5 years)
    "min_base_months": 24,         # a month is scored once 2 years of base exist
    "std_floor": 0.25,
    "clip": 4.0,
    "min_month_coverage": 0.5,     # share of a calendar month's days covered (a GDELT month counts from mid-month)
    "max_staleness_months": 3,     # a component whose newest month is older than this (vs the as-of month) is not scored
    "min_coverage": 0.5,           # share of component weight present for a month to have a score (UCDP or GDELT alone)
    "history_months": 120,         # months of score history kept (the uplift percentile uses 120)
    "min_series_months": 24,       # months of score needed before z / percentile / uplift are computed
    "align": "calendar",           # calendar: month k = as-of month - k for every component (a month UCDP has not yet
                                   # released is missing, GDELT carries it); edge: k = 0 is each component's newest month
}


def _node(settings, *keys, default=None):
    if settings is None:
        return default
    if isinstance(settings, dict):
        node = settings
        for k in keys:
            if not isinstance(node, dict) or k not in node:
                return default
            node = node[k]
        return node
    return settings.get(*keys, default=default)


def gpr_source(settings) -> str:
    """gpr.source: "ci" (Caldara-Iacoviello country series, today's behaviour; the default when absent),
    "events" (event score replaces CI; CI kept where a country has no usable event score) or "blend"."""
    v = str(_node(settings, "gpr", "source", default="ci") or "ci").strip().lower()
    if v not in GPR_SOURCES:
        raise ValueError(f"gpr.source must be one of {list(GPR_SOURCES)}, got {v!r}")
    return v


def event_gpr_settings(settings=None) -> dict:
    """EVENT_GPR_DEFAULTS overlaid with settings['gpr']['events'] (a resolved dict passes through)."""
    if isinstance(settings, dict) and "base_months" in settings and "weights" in settings:
        return {**EVENT_GPR_DEFAULTS, **settings, "weights": {**EVENT_GPR_DEFAULTS["weights"], **settings["weights"]}}
    cfg = {**EVENT_GPR_DEFAULTS, "weights": dict(EVENT_GPR_DEFAULTS["weights"])}
    for k, v in (_node(settings, "gpr", "events", default=None) or {}).items():
        if k == "weights":
            cfg["weights"].update({str(a): float(b) for a, b in (v or {}).items()})
        else:
            cfg[k] = v
    if cfg["align"] not in ("calendar", "edge"):
        raise ValueError(f"gpr.events.align must be calendar or edge, got {cfg['align']!r}")
    unknown = set(cfg["weights"]) - set(EI.COMPONENTS)
    if unknown:
        raise ValueError(f"gpr.events.weights has unknown components {sorted(unknown)}; allowed {list(EI.COMPONENTS)}")
    if sum(float(w) for w in cfg["weights"].values()) <= 0:
        raise ValueError("gpr.events.weights must have a positive total")
    return cfg


def _monthly_component(e: pd.DataFrame, comp: str, cfg: dict, gd_events: pd.DataFrame | None) -> pd.DataFrame:
    """Monthly value x per (iso, month) for one component; months below min_month_coverage dropped."""
    rows = EI._component_frame(e, comp)
    if not len(rows):
        return pd.DataFrame(columns=["iso", "month", "x"])
    kind = EI.COMPONENTS[comp][3]
    rows = rows.assign(month=rows["period"].dt.to_period("M"))
    if kind == "count":
        g = rows.groupby(["iso", "month"]).agg(total=("value", "sum"), days=("days", "sum")).reset_index()
        g["x"] = np.log1p(g["total"] / g["days"] * EI.DAYS_PER_MONTH)
    else:
        if gd_events is not None and len(gd_events):
            w = gd_events[["iso", "period", "value"]].rename(columns={"value": "w"})
            rows = rows.merge(w, on=["iso", "period"], how="left")
            rows["w"] = rows["w"].where(rows["w"] > 0, 1.0).fillna(1.0)
        else:
            rows = rows.assign(w=1.0)
        rows = rows.assign(wv=rows["w"] * rows["value"])
        g = rows.groupby(["iso", "month"]).agg(wv=("wv", "sum"), w=("w", "sum"), days=("days", "sum")).reset_index()
        g["x"] = g["wv"] / g["w"]
    dim = g["month"].dt.days_in_month.astype(float)
    return g[g["days"] >= float(cfg["min_month_coverage"]) * dim][["iso", "month", "x"]]


def event_gpr_scores(events: pd.DataFrame | None, as_of, settings=None, isos=None, normalized: bool = False):
    """Event GPR score per country at `as_of`. Returns (summary, series).

    summary (index iso): score (latest scored month, in trailing-sd units), flag (ok / partial / insufficient /
    missing), coverage (present weight share in that month), months (scored months), edge (that month),
    z_<component> (that month). series: {iso: np.ndarray of monthly scores, oldest first, gaps dropped}.

    align "calendar" (default): month k is the as-of month minus k for every component, so a month UCDP has not
    yet released is scored on GDELT alone (if its weight share reaches min_coverage) and revised once UCDP
    arrives. align "edge": k = 0 is each component's own newest covered month, as in event_index. The latest
    scored month must lie within max_staleness_months of the as-of month; a component whose newest row is
    older than that is not scored at all."""
    cfg = event_gpr_settings(settings)
    t = pd.Timestamp(as_of).normalize(); tm = t.to_period("M")
    comps = [c for c in EI.COMPONENTS if float(cfg["weights"].get(c, 0.0)) > 0]
    zcols = [f"z_{c}" for c in comps]
    cols = ["score", "flag", "coverage", "months", "edge", *zcols]
    want = sorted({str(i).upper() for i in isos}) if isos is not None else None
    if events is None or not len(events):
        out = pd.DataFrame({"score": np.nan, "flag": "missing", "coverage": 0.0, "months": 0, "edge": ""},
                           index=pd.Index(want or [], name="iso"))
        for zc in zcols:
            out[zc] = np.nan
        return out[cols], {}
    e = events if normalized else EI.normalize_events(events)
    e = EI._to_units(EI.point_in_time(e, t))
    present = set(e["iso"])
    all_isos = want if want is not None else sorted(present)
    H = int(cfg["history_months"]); B = int(cfg["base_months"]); floor = float(cfg["std_floor"]); clip = float(cfg["clip"])
    gd = EI._component_frame(e, "media_events")
    parts = []
    for comp in comps:
        m = _monthly_component(e, comp, cfg, gd if EI.COMPONENTS[comp][3] == "mean" else None)
        sign = EI.COMPONENTS[comp][2]
        for iso, g in m.groupby("iso"):
            s = g.set_index("month")["x"].sort_index()
            edge = s.index.max()
            if (tm - edge).n > int(cfg["max_staleness_months"]):
                continue
            s = s.reindex(pd.period_range(s.index.min(), edge, freq="M"))
            base = s.shift(1).rolling(B, min_periods=int(cfg["min_base_months"]))
            mu = base.mean(); sd = base.std(ddof=1).clip(lower=floor)
            z = (sign * (s - mu) / sd).clip(-clip, clip)
            top = tm if cfg["align"] == "calendar" else edge
            kk = np.array([(top - m).n for m in z.index])
            keep = (kk >= 0) & (kk <= H)
            parts.append(pd.DataFrame({"iso": iso, "k": kk[keep], "comp": comp, "z": z.to_numpy(dtype=float)[keep]}))
    w = pd.Series({c: float(cfg["weights"][c]) for c in comps}); wtot = float(w.sum())
    out = pd.DataFrame({"score": np.nan, "flag": "missing", "coverage": 0.0, "months": 0, "edge": ""}, index=pd.Index(all_isos, name="iso"))
    for zc in zcols:
        out[zc] = np.nan
    out.loc[out.index.isin(list(present)), "flag"] = "insufficient"
    series: dict[str, np.ndarray] = {}
    if parts:
        z = pd.concat(parts, ignore_index=True).pivot_table(index=["iso", "k"], columns="comp", values="z", aggfunc="first")
        z = z.reindex(columns=comps)
        have = z.notna()
        wsum = have.mul(w, axis=1).sum(axis=1)
        cov = wsum / wtot
        score = (z.fillna(0.0).mul(w, axis=1).sum(axis=1) / wsum.where(wsum > 0)).where(cov >= float(cfg["min_coverage"]))
        for iso in all_isos:
            if iso not in z.index.get_level_values(0):
                continue
            sc = score.loc[iso].sort_index(ascending=False)          # oldest first
            series[iso] = sc.dropna().to_numpy(dtype=float)
            out.at[iso, "months"] = int(sc.notna().sum())
            fin = sc.dropna()
            if len(fin) and int(fin.index.min()) <= int(cfg["max_staleness_months"]):
                k0 = int(fin.index.min())
                top = tm if cfg["align"] == "calendar" else None
                out.at[iso, "edge"] = str(top - k0) if top is not None else f"k={k0}"
                out.at[iso, "coverage"] = float(cov.loc[(iso, k0)])
                for c in comps:
                    out.at[iso, f"z_{c}"] = float(z.at[(iso, k0), c])
                out.at[iso, "score"] = float(fin.loc[k0])
                out.at[iso, "flag"] = "ok" if cov.loc[(iso, k0)] >= 1 - 1e-12 else "partial"
    return out[cols], series


def event_gpr_stats(summary: pd.DataFrame, series: dict, window_months: int = 3, settings=None) -> pd.DataFrame:
    """The CI statistics (_stats: recent, mean5y, sd5y, z, percentile, momentum) on each country's event score
    series, so the same uplift thresholds apply. NaN unless the flag is ok/partial and the series has at least
    min_series_months scored months."""
    cfg = event_gpr_settings(settings)
    need = max(int(cfg["min_series_months"]), int(window_months) + 13)
    rows = {}
    for iso, r in summary.iterrows():
        s = series.get(iso)
        if r["flag"] in ("ok", "partial") and s is not None and len(s) >= need:
            with np.errstate(divide="ignore", invalid="ignore"):
                rows[iso] = {**_stats(s, int(window_months)), "momentum": np.nan}   # a ratio of z-score means means nothing
        else:
            rows[iso] = {k: np.nan for k in STAT_KEYS}
    return pd.DataFrame(rows).T.reindex(summary.index)


def _uplift_signal(st: dict, g: dict, w: float) -> tuple[int, float]:
    """The run_gpr uplift (0/1/2) and 0-100 signal rules, on a stats dict."""
    uplift = 0
    if g["use_uplift"]:
        if st["percentile"] >= g["uplift2_percentile"] and st["z"] >= g["uplift2_z"]:
            uplift = 2
        elif st["percentile"] >= g["uplift1_percentile"] or st["z"] >= g["uplift1_z"]:
            uplift = 1
    signal = round(w * st["percentile"] + (1 - w) * max(0.0, min(100.0, 50 + 25 * st["z"])), 0)
    return uplift, float(signal)


def _apply_event_source(table: pd.DataFrame, u: Universe, settings, source: str) -> pd.DataFrame:
    """gpr.source "events" / "blend": recompute z, percentile, uplift, final_410 and signal per country.

    events: the event score's stats replace the CI ones; a country without a usable event score keeps CI.
    blend : z and percentile = (1 - b) CI + b events (b = gpr.blend_weight_events, default 0.5) where both
            exist; either alone where only one exists. recent/mean5y/sd5y/momentum stay CI's under a blend.
    Countries with no CI series but an event score (Pakistan, Nigeria, Zambia...) become covered."""
    g = settings["gpr"]; w = g["signal_weight_percentile"]; n = int(g["window_months"])
    bw = float(_node(settings, "gpr", "blend_weight_events", default=0.5))
    if not 0.0 <= bw <= 1.0:
        raise ValueError(f"gpr.blend_weight_events must be in [0, 1], got {bw}")
    prof = u.countries.set_index("country").loc[u.names]
    isos = [str(prof.at[c, "iso"]).upper() for c in u.names]
    events = getattr(u, "events", None)
    if events is None or not len(events):
        warnings.warn(f"gpr.source is {source!r} but the universe has no event table (data/live/events/events_long.csv); "
                      "the Caldara-Iacoviello series is used where it exists", RuntimeWarning, stacklevel=3)
    summ, series = event_gpr_scores(events, as_of_timestamp(settings), settings, isos=isos)
    est = event_gpr_stats(summ, series, n, settings)
    out = table.copy()
    for col in ("z_ci", "percentile_ci", "event_score", "z_events", "percentile_events", "event_coverage"):
        out[col] = np.nan
    out["event_flag"] = ""; out["gpr_source_used"] = ""
    for c, iso in zip(u.names, isos):
        ci = bool(out.at[c, "covered"])
        ev = est.loc[iso]; ev_ok = bool(np.isfinite(ev["z"]))
        out.at[c, "z_ci"] = out.at[c, "z"]; out.at[c, "percentile_ci"] = out.at[c, "percentile"]
        out.at[c, "event_score"] = summ.at[iso, "score"]; out.at[c, "event_flag"] = summ.at[iso, "flag"]
        out.at[c, "event_coverage"] = summ.at[iso, "coverage"]
        out.at[c, "z_events"] = ev["z"]; out.at[c, "percentile_events"] = ev["percentile"]
        if source == "blend" and ev_ok and ci:
            use = "blend"
            st = {k: out.at[c, k] for k in STAT_KEYS}
            st["z"] = (1 - bw) * float(out.at[c, "z"]) + bw * float(ev["z"])
            st["percentile"] = (1 - bw) * float(out.at[c, "percentile"]) + bw * float(ev["percentile"])
        elif ev_ok:
            use = "events"
            st = {k: float(ev[k]) for k in STAT_KEYS}
        else:
            out.at[c, "gpr_source_used"] = "ci" if ci else "none"
            continue
        uplift, signal = _uplift_signal(st, g, w)
        analyst = float(out.at[c, "analyst_410"])
        for k in STAT_KEYS:
            out.at[c, k] = st[k]
        out.at[c, "series"] = "events" if use == "events" else f"{out.at[c, 'series']}+events"
        out.at[c, "covered"] = True; out.at[c, "uplift"] = uplift; out.at[c, "signal"] = signal
        out.at[c, "final_410"] = min(4.0, analyst + uplift) if np.isfinite(analyst) else np.nan
        out.at[c, "gpr_source_used"] = use
    return out


# ---------------------------------------------------------------- histories (point in time per date)

def gpr_event_history(events: pd.DataFrame, dates, settings=None, isos=None, window_months: int = 3) -> pd.DataFrame:
    """Event GPR at each as-of date, rebuilt point in time per date. Long frame: date, iso, score, z,
    percentile, flag, coverage (z and percentile are the _stats values that drive the uplift)."""
    cfg = event_gpr_settings(settings)
    e = EI.normalize_events(events)
    out = []
    for d in dates:
        summ, ser = event_gpr_scores(e, d, cfg, isos=isos, normalized=True)
        st = event_gpr_stats(summ, ser, window_months, cfg)
        out.append(pd.DataFrame({"date": pd.Timestamp(d).normalize(), "iso": summ.index, "score": summ["score"].to_numpy(),
                                 "z": st["z"].to_numpy(dtype=float), "percentile": st["percentile"].to_numpy(dtype=float),
                                 "flag": summ["flag"].to_numpy(), "coverage": summ["coverage"].to_numpy()}))
    return pd.concat(out, ignore_index=True)


def ci_gpr_history(gpr: pd.DataFrame, window_months: int = 3, available_day: int = 1) -> pd.DataFrame:
    """The Caldara-Iacoviello country series as the same long frame (date, iso, score, z, percentile, flag,
    coverage), month m dated on `available_day` of month m+1. score = z = the run_gpr z on the series up to m.
    Not strictly point in time: the file carries no vintages (see gpr-and-prediction-markets.md)."""
    g = gpr.copy()
    months = pd.PeriodIndex(g["month"].astype(str), freq="M")
    rows = []
    for col in [c for c in g.columns if str(c).startswith("GPRC_")]:
        s = pd.to_numeric(g[col], errors="coerce").to_numpy(dtype=float)
        for j in range(int(window_months) + 72, len(s)):
            st = _stats(s[: j + 1], int(window_months))
            d = (months[j] + 1).to_timestamp() + pd.Timedelta(days=int(available_day) - 1)
            rows.append({"date": d, "iso": col[5:], "score": st["z"], "z": st["z"], "percentile": st["percentile"],
                         "flag": "ok", "coverage": 1.0})
    return pd.DataFrame(rows)


# ---------------------------------------------------------------- elasticity of spreads and PDs to a GPR shock

def _levels_on(levels: pd.DataFrame, dates: pd.DatetimeIndex) -> pd.DataFrame:
    """Level (last observation on or before each date) per iso: frame dates x iso."""
    s = levels.copy()
    s["iso"] = s["iso"].astype(str).str.upper(); s["date"] = pd.to_datetime(s["date"]).dt.normalize()
    s = s.dropna(subset=["value"]).sort_values("date")
    out = {}
    for iso, g in s.groupby("iso"):
        ser = g.drop_duplicates("date", keep="last").set_index("date")["value"].astype(float)
        out[iso] = ser.reindex(ser.index.union(dates)).ffill().reindex(dates)
    return pd.DataFrame(out, index=dates)


def _fe_ols(x: np.ndarray, y: np.ndarray, grp: np.ndarray) -> dict:
    """y = b x + country effect: within-country demeaned OLS with plain and country-clustered standard errors."""
    ok = np.isfinite(x) & np.isfinite(y)
    x, y, grp = x[ok], y[ok], grp[ok]
    nan = {"beta": np.nan, "se": np.nan, "se_cluster": np.nan, "t": np.nan, "n": int(len(x)), "countries": int(len(set(grp))), "r2": np.nan}
    if len(x) < 8 or len(set(grp)) < 2:
        return nan
    xd = x - pd.Series(x).groupby(grp).transform("mean").to_numpy()
    yd = y - pd.Series(y).groupby(grp).transform("mean").to_numpy()
    sxx = float(xd @ xd)
    if sxx <= 0:
        return nan
    b = float(xd @ yd) / sxx
    e = yd - b * xd
    G = len(set(grp)); n = len(x)
    se = float(np.sqrt(e @ e / max(n - 1 - G, 1) / sxx))
    score = pd.Series(xd * e).groupby(grp).sum().to_numpy()
    se_c = float(np.sqrt(G / (G - 1) * (score @ score)) / sxx)
    r2 = 1.0 - float(e @ e) / float(yd @ yd) if float(yd @ yd) > 0 else np.nan
    return {"beta": b, "se": se, "se_cluster": se_c, "t": b / se_c if se_c > 0 else np.nan, "n": n, "countries": G, "r2": r2}


def estimate_gpr_elasticity(hist: pd.DataFrame, levels: pd.DataFrame, transform: str = "log", horizon_steps: int = 3,
                            value_col: str = "score", lgd: float = 0.6, risk_premium_ratio: float = 1.0,
                            as_of=None) -> dict:
    """Response of a level series to a change in the GPR score, on a regular date grid (e.g. monthly).

    Contemporaneous: Delta f(level) over h steps on Delta score over the same h steps. Lead: Delta f(level)
    over the next h steps on the Delta score over the past h steps. Non-overlapping samples (stride h),
    country fixed effects, country-clustered standard errors. transform: "log" (spreads, so beta is the
    log change per 1 sd of score), "bp" (level change), "logit_pd" (spreads in bp turned into the layer-2
    physical PD, PD = spread / 1e4 / lgd / ratio, then logit). Rows flagged missing/insufficient are dropped.

    as_of: score rows and level observations dated after it are dropped before anything is computed, so an
    estimate for a replay at an earlier date never sees later data (lead changes then stop at as_of).
    The result carries `data_end`, the last date of any score or level row used."""
    h = hist[hist["flag"].isin(("ok", "partial"))]
    if as_of is not None:
        cut = pd.Timestamp(as_of).normalize()
        h = h[pd.to_datetime(h["date"]) <= cut]
        levels = levels[pd.to_datetime(levels["date"]) <= cut]
    data_end = max(pd.to_datetime(h["date"]).max(), pd.to_datetime(levels.dropna(subset=["value"])["date"]).max())
    S = h.pivot_table(index="date", columns="iso", values=value_col, aggfunc="first").sort_index()
    dates = pd.DatetimeIndex(S.index)
    L = _levels_on(levels, dates).reindex(columns=S.columns)
    if transform == "log":
        F = np.log(L.where(L > 0))
    elif transform == "bp":
        F = L
    elif transform == "logit_pd":
        from .layer2_bayesian import physical_pd
        from .common import logit
        F = pd.DataFrame(logit(physical_pd(L.to_numpy(dtype=float), lgd, risk_premium_ratio)), index=L.index, columns=L.columns).where(L.notna())
    else:
        raise ValueError(f"transform must be log, bp or logit_pd, got {transform!r}")
    k = int(horizon_steps)
    dS = S - S.shift(k); dF = F - F.shift(k); lead = F.shift(-k) - F
    pos = np.arange(len(dates)); keep = (pos >= k) & ((pos - k) % k == 0)
    def stack(a, b):
        A = a.iloc[keep].stack(future_stack=True); Bv = b.iloc[keep].stack(future_stack=True).reindex(A.index)
        return A.to_numpy(dtype=float), Bv.to_numpy(dtype=float), A.index.get_level_values(1).to_numpy()
    x, y, grp = stack(dS, dF)
    x2, y2, grp2 = stack(dS, lead)
    return {"transform": transform, "horizon_steps": k, "data_end": str(pd.Timestamp(data_end).date()) if pd.notna(data_end) else None,
            "contemporaneous": _fe_ols(x, y, grp), "lead": _fe_ols(x2, y2, grp2)}


def estimate_gpr_elasticities(hist: pd.DataFrame, spreads: pd.DataFrame, horizon_steps: int = 3, lgd: float = 0.6,
                              risk_premium_ratio: float = 1.0, as_of=None) -> dict:
    """Spread (log and bp) and PD (logit of the layer-2 physical PD implied by the spread) elasticities.
    `as_of` drops data dated after it (see estimate_gpr_elasticity)."""
    out = {t: estimate_gpr_elasticity(hist, spreads, t, horizon_steps, lgd=lgd, risk_premium_ratio=risk_premium_ratio, as_of=as_of)
           for t in ("log", "bp", "logit_pd")}
    return {"spread_log": out["log"], "spread_bp": out["bp"], "pd_logit": out["logit_pd"], "horizon_steps": int(horizon_steps),
            "data_end": out["log"]["data_end"]}


def elasticity_record(est: dict, as_of, data_label: str, synthetic: bool) -> dict:
    """The JSON record a gpr stress shock reads (contemporaneous betas per 1 sd of event GPR score).
    Refuses an `as_of` earlier than the last date of data the estimate used (`data_end`)."""
    end = est.get("data_end")
    if end is not None and pd.Timestamp(end) > pd.Timestamp(as_of):
        raise ValueError(f"elasticity estimate uses data to {end}, after the record's as_of {pd.Timestamp(as_of).date()}; "
                         "re-estimate with as_of=")
    c = {k: est[k]["contemporaneous"] for k in ("spread_log", "spread_bp", "pd_logit")}
    return {"ticket": "EQ-B-0072", "as_of": str(pd.Timestamp(as_of).date()), "data": str(data_label), "synthetic": bool(synthetic),
            "horizon_steps": int(est["horizon_steps"]),
            "spread_log_beta": c["spread_log"]["beta"], "spread_log_se": c["spread_log"]["se_cluster"],
            "spread_bp_beta": c["spread_bp"]["beta"], "spread_bp_se": c["spread_bp"]["se_cluster"],
            "pd_logit_beta": c["pd_logit"]["beta"], "pd_logit_se": c["pd_logit"]["se_cluster"],
            "n": c["spread_log"]["n"], "countries": c["spread_log"]["countries"], "data_end": end}


def write_gpr_elasticity(path, record: dict) -> Path:
    p = Path(path); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(record, indent=2, sort_keys=True) + "\n")
    return p


ELASTICITY_KEYS = ("spread_log_beta", "spread_bp_beta", "pd_logit_beta")


def _check_record_as_of(rec: dict, as_of, what: str) -> None:
    """A record fitted on data after the run's as-of date must not be used (replays stay point in time)."""
    if as_of is None:
        return
    t = pd.Timestamp(as_of).normalize()
    if not rec.get("as_of"):
        raise ValueError(f"{what} has no as_of; it cannot be checked against the run's as_of {t.date()}")
    if pd.Timestamp(rec["as_of"]).normalize() > t:
        raise ValueError(f"{what} was fitted as of {rec['as_of']}, after the run's as_of {t.date()}; "
                         "use an elasticity estimated with as_of on or before the run date")


def load_gpr_elasticity(path, as_of=None) -> dict:
    """Read and validate an elasticity record. With `as_of`, refuse a record whose as_of is later (or absent)."""
    rec = json.loads(Path(path).read_text())
    missing = [k for k in ELASTICITY_KEYS if k not in rec or not np.isfinite(float(rec[k]))]
    if missing:
        raise ValueError(f"GPR elasticity file {Path(path).name} lacks finite {missing}")
    _check_record_as_of(rec, as_of, f"GPR elasticity file {Path(path).name}")
    return rec


# ---------------------------------------------------------------- stress-shock expansion

def gpr_shock_ops(shock_sd: float, elasticity: dict, where: dict | None = None, w_t: float = 0.25, w_m: float = 0.5,
                  pd_channel: str = "market", spread_mode: str = "mul") -> list[dict]:
    """Standard stress.py shocks for a GPR shock of `shock_sd` trailing standard deviations.

    spread_mode "mul": spread x exp(spread_log_beta * shock_sd) (scales with the level, the default);
                "add": spread + spread_bp_beta * shock_sd bp.
    pd_channel  "market": no extra term; layer 2 moves the PD through the spread (w_m * Delta logit market PD).
                "full"  : also textz + (1 - w_m) * pd_logit_beta * shock_sd / w_t, so the layer-2 log-odds move by
                          about pd_logit_beta * shock_sd in total (the market-implied PD response).
    Scenario severity `scale` is applied afterwards by apply_shocks as for any add/mul shock."""
    if spread_mode not in ("mul", "add"):
        raise ValueError(f"gpr spread_mode must be mul or add, got {spread_mode!r}")
    if pd_channel not in ("market", "full"):
        raise ValueError(f"gpr pd_channel must be market or full, got {pd_channel!r}")
    k = float(shock_sd)
    wh = {"where": where} if where else {}
    if spread_mode == "mul":
        ops = [{"target": "countries", "column": "spread", "op": "mul", "value": float(np.exp(float(elasticity["spread_log_beta"]) * k)), **wh}]
    else:
        ops = [{"target": "countries", "column": "spread", "op": "add", "value": float(elasticity["spread_bp_beta"]) * k, **wh}]
    if pd_channel == "full":
        if w_t <= 0:
            raise ValueError("probability.w_t must be positive for pd_channel 'full'")
        ops.append({"target": "countries", "column": "textz", "op": "add",
                    "value": (1.0 - float(w_m)) * float(elasticity["pd_logit_beta"]) * k / float(w_t), **wh})
    return ops


def _default_data_dir() -> Path:
    return Path(__file__).resolve().parents[2] / "data"


def gpr_elasticity_path(sh: dict, base_dir=None) -> Path:
    """`elasticity_file` relative to the scenarios folder; absolute paths and paths leaving it are refused."""
    root = Path(base_dir or _default_data_dir()).resolve()
    p = Path(str(sh.get("elasticity_file", "live/gpr_elasticity.json")))
    if p.is_absolute():
        raise ValueError(f"gpr elasticity_file must be relative to the data folder, got an absolute path ({p.name})")
    full = (root / p).resolve()
    if not full.is_relative_to(root):
        raise ValueError(f"gpr elasticity_file leaves the data folder: {sh.get('elasticity_file')!r}")
    return full


def gpr_missing_data(shocks: list[dict], base_dir=None, as_of=None) -> list[str]:
    """Elasticity files that gpr shocks (without an inline `elasticity`) need and that are not on disk; with
    `as_of`, also files fitted after it (or without an as_of), listed as "<path> (fitted as of ..., after <as_of>)"."""
    need = [str(gpr_elasticity_path(sh, base_dir)) for sh in shocks if sh.get("target") == "gpr" and "elasticity" not in sh]
    out = []
    for f in dict.fromkeys(need):
        if not Path(f).is_file():
            out.append(f); continue
        if as_of is not None:
            try:
                load_gpr_elasticity(f, as_of)
            except ValueError as exc:
                out.append(f"{f} ({exc})")
    return out


def expand_gpr_shocks(shocks: list[dict], settings, base_dir=None, as_of=None) -> list[dict]:
    """Replace each {"target": "gpr", "shock_sd": k, ...} shock by its standard shocks (gpr_shock_ops); other
    shocks pass through unchanged. Keys: shock_sd (required), where, pd_channel, spread_mode, and either an
    inline `elasticity` dict or `elasticity_file` (default live/gpr_elasticity.json under the data folder).

    Point in time: the run date is `as_of`, else settings["as_of"]. A file record fitted after it is refused,
    and a file record cannot be used at all when no run date is known (a replay would otherwise pick up an
    elasticity fitted on later data). An inline elasticity carrying `as_of` is checked the same way; one
    without is analyst judgement and passes."""
    run_as_of = as_of if as_of is not None else _node(settings, "as_of", default=None)
    out = []
    for sh in shocks:
        if sh.get("target") != "gpr":
            out.append(sh); continue
        if "elasticity" in sh:
            el = sh["elasticity"]
            if el.get("as_of"):
                _check_record_as_of(el, run_as_of, "inline GPR elasticity")
        else:
            path = gpr_elasticity_path(sh, base_dir)
            if run_as_of is None or (isinstance(run_as_of, str) and not run_as_of.strip()):
                raise ValueError(f"gpr shock reads {path.name} but no run as_of is known: pass as_of or set "
                                 "settings['as_of'] before applying the scenario")
            el = load_gpr_elasticity(path, run_as_of)
        out.extend(gpr_shock_ops(float(sh["shock_sd"]), el, sh.get("where"),
                                 w_t=float(_node(settings, "probability", "w_t", default=0.25)),
                                 w_m=float(_node(settings, "probability", "w_m", default=0.5)),
                                 pd_channel=sh.get("pd_channel", "market"), spread_mode=sh.get("spread_mode", "mul")))
    return out


# ---------------------------------------------------------------- episode backtest

def episode_backtest(hist: pd.DataFrame, levels: pd.DataFrame, episodes, threshold: float = 1.5, widen: float = 100.0,
                     before_months: int = 6, after_months: int = 6, value_col: str = "score", transform: str = "bp") -> pd.DataFrame:
    """Did the GPR score cross `threshold` before the level series moved by `widen`?

    episodes: rows with iso, name, date. Window (date - before, date + after]. Baseline level: last observation
    on or before the window start. widen is in level units for transform "bp" (spreads, bp) and in percent for
    "pct" (100 x log change, e.g. FX depreciation). lead_days = widen_date - alert_date (> 0: the score first).
    verdict: led (lead >= 31 days), coincident (|lead| < 31), lagged, no alert, no move."""
    ep = pd.DataFrame(episodes)
    h = hist[hist["flag"].isin(("ok", "partial"))].copy()
    h["date"] = pd.to_datetime(h["date"]); h["iso"] = h["iso"].astype(str).str.upper()
    lv = levels.copy(); lv["iso"] = lv["iso"].astype(str).str.upper(); lv["date"] = pd.to_datetime(lv["date"]).dt.normalize()
    lv = lv.dropna(subset=["value"]).sort_values("date")
    rows = []
    for r in ep.itertuples(index=False):
        iso = str(r.iso).upper(); d = pd.Timestamp(r.date)
        a = d - pd.DateOffset(months=int(before_months)); b = d + pd.DateOffset(months=int(after_months))
        hs = h[(h["iso"] == iso) & (h["date"] > a) & (h["date"] <= b)].sort_values("date")
        al = hs[hs[value_col] >= threshold]
        alert = al["date"].iloc[0] if len(al) else pd.NaT
        ls = lv[lv["iso"] == iso]
        base = ls[ls["date"] <= a]["value"]
        win = ls[(ls["date"] > a) & (ls["date"] <= b)]
        move_date = pd.NaT; max_move = np.nan
        if len(base) and len(win):
            b0 = float(base.iloc[-1])
            mv = (win["value"] - b0) if transform == "bp" else 100 * np.log(win["value"] / b0)
            max_move = float(mv.max())
            hit = win[mv.to_numpy() >= widen]
            move_date = hit["date"].iloc[0] if len(hit) else pd.NaT
        lead = (move_date - alert).days if pd.notna(alert) and pd.notna(move_date) else np.nan
        if pd.isna(alert):
            verdict = "no alert"
        elif pd.isna(move_date):
            verdict = "no move"
        else:
            verdict = "led" if lead >= 31 else "lagged" if lead <= -31 else "coincident"
        rows.append({"name": getattr(r, "name", iso), "iso": iso, "event_date": d.date(), "alert_date": alert, "move_date": move_date,
                     "lead_days": lead, "peak_score": float(hs[value_col].max()) if len(hs) else np.nan,
                     "max_move": max_move, "verdict": verdict})
    return pd.DataFrame(rows)


def lead_lag(hist: pd.DataFrame, levels: pd.DataFrame, value_col: str = "score", **kw) -> pd.DataFrame:
    """event_index.spread_lead_lag on the GPR score (horizons in days; widen_bps in level units)."""
    return EI.spread_lead_lag(hist.rename(columns={value_col: "event_index"})[["date", "iso", "event_index", "flag"]], levels, **kw)
