"""Macro nowcasting: monthly official indicators to quarterly real GDP growth and CPI inflation (EQ-B-0071).

Research module. Nothing here feeds the PDs, the scorecard or the Monte Carlo, and `pipeline.py` does not import it.

Method (bridge equations with a ragged edge):
1. Point in time. `pit_view(inputs, as_of)` keeps only rows with release_date <= as_of and, for each
   (iso3, series, period), the latest such release. No function in this module reads the wall clock.
2. Ragged edge. Each monthly indicator is extended to the last month of the target quarter by an AR(p)
   forecast (p <= 3 chosen by BIC, `econometrics.ar_fit_bic`) fitted on its own point-in-time history.
3. Aggregation. Months are averaged to quarters (the inputs are year-on-year rates or levels, see the contract).
4. Bridge. Per country and target, OLS of the quarterly target on a constant, its own first lag and either
   (method "bridge") the quarterly indicator means, or (method "pca") the first k principal components of the
   standardised monthly panel averaged to quarters. With too few quarters for the full bridge, the "bridge"
   method falls back to the average of single-indicator bridges ("bridge_pooled").
5. Benchmark. A naive AR(p <= 2, BIC) on the target's own point-in-time quarterly history.

Targets: "GDP" is the quarterly series GDP_YOY. "CPI" is the quarterly mean of monthly CPI_YOY; its first
release is the mean of the three months' first releases and is dated at the last of those three releases.

Error tracking: `append_log` stores each nowcast with its as_of (existing keys are never overwritten);
`score_log` fills in the first release once its release date is <= the scoring as_of; `error_summary` reports
RMSE against the AR benchmark. The CSV log lives at outputs/nowcast/nowcast_log.csv by default.

The input contract (one long CSV, monthly and quarterly rows with release dates) is described in
docs/validation/nowcast.md and enforced by `validate_inputs`. All tests run on SYNTHETIC data.

Command line:
    python -m econquest.engine.nowcast names    [--data D] [--n 25]
    python -m econquest.engine.nowcast validate --inputs CSV
    python -m econquest.engine.nowcast run      --inputs CSV --as-of YYYY-MM-DD [--method bridge|pca] [--names top|all|ISO,ISO] [--log CSV]
    python -m econquest.engine.nowcast score    --inputs CSV --as-of YYYY-MM-DD [--log CSV]
    python -m econquest.engine.nowcast summary  [--log CSV]
"""
from __future__ import annotations

import argparse
import hashlib
import re
from pathlib import Path

import numpy as np
import pandas as pd

from ..validation.idea_log import _csv_safe
from .econometrics import ar_fit_bic, diebold_mariano

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_INPUTS = ROOT / "data" / "live" / "nowcast_inputs.csv"
DEFAULT_LOG = ROOT / "outputs" / "nowcast" / "nowcast_log.csv"

INPUT_COLUMNS = ["iso3", "series", "freq", "period", "value", "release_date", "source"]
OPTIONAL_COLUMNS = ["release_date_basis", "unit", "notes"]
RELEASE_DATE_BASIS = {"official", "fetched", "estimated_lag"}

# Controlled vocabulary: code -> (freq, block, unit, description). Blocks decide which target uses a series.
SERIES = {
    "GDP_YOY": ("Q", "target", "pct_yoy", "Real GDP, % change on the same quarter a year earlier"),
    "CPI_YOY": ("M", "prices", "pct_yoy", "Headline CPI, % change on the same month a year earlier"),
    "CORE_CPI_YOY": ("M", "prices", "pct_yoy", "Core CPI (ex food and energy, national definition), % y/y"),
    "PPI_YOY": ("M", "prices", "pct_yoy", "Producer or wholesale prices, % y/y"),
    "IP_YOY": ("M", "activity", "pct_yoy", "Industrial production (or manufacturing output) volume, % y/y"),
    "RETAIL_YOY": ("M", "activity", "pct_yoy", "Retail sales volume, % y/y"),
    "PMI_MFG": ("M", "activity", "index", "Manufacturing PMI, diffusion index (50 = no change)"),
    "UNEMP": ("M", "activity", "pct", "Unemployment rate, % of labour force"),
    "EXP_YOY": ("M", "external", "pct_yoy", "Merchandise exports in USD, % y/y"),
    "IMP_YOY": ("M", "external", "pct_yoy", "Merchandise imports in USD, % y/y"),
    "CREDIT_YOY": ("M", "financial", "pct_yoy", "Bank credit to the private sector, % y/y"),
}
TARGET_BLOCKS = {"GDP": ("activity", "external", "financial"), "CPI": ("prices",)}
TARGETS = ("GDP", "CPI")
METHODS = ("bridge", "pca")

MIN_TRAIN = 12            # quarters of target history needed to fit a bridge
MIN_MONTHS = 36           # months of history needed to use an indicator
MAX_STALE_MONTHS = 6      # drop an indicator whose last observation is this far before the first target quarter
MAX_TARGET_QUARTERS = 3   # at most the current quarter and two backcasts
AR_MAX_P_MONTHLY = 3
AR_MAX_P_QUARTERLY = 2

LOG_KEY = ["as_of", "iso3", "target", "quarter", "method"]
LOG_COLUMNS = LOG_KEY + ["country", "horizon", "method_used", "nowcast", "ar_benchmark", "indicators", "n_indicators",
                         "months_observed", "n_train", "inputs_hash", "first_release", "first_release_date",
                         "error", "ar_error", "scored_on", "score_note"]
ISO3_RE = re.compile(r"^[A-Z]{3}$")
SERIES_RE = re.compile(r"^[A-Z][A-Z0-9_]{0,31}$")

_PERIOD_RE = {"M": re.compile(r"^\d{4}-(0[1-9]|1[0-2])$"), "Q": re.compile(r"^\d{4}-Q[1-4]$")}


# ----------------------------------------------------------------------------------------------
# Names: top-n from the book plus the universe
# ----------------------------------------------------------------------------------------------
def top_names(data_dir: str | Path = ROOT / "data", n: int = 25, as_of=None, weo: pd.DataFrame | None = None) -> pd.DataFrame:
    """The nowcast coverage list.

    Rule: (1) every country in data/portfolio.csv, ranked by gross notional (sum of |notional_mm| over its
    positions), ties by name; (2) filled up to n from data/panel/universe_proposal.csv rows with tier "EM" and
    embi_member "Y" that are not in the book, ranked by WEO nominal GDP in USD (NGDPD, latest year before
    as_of's year) where it is available, then in proposal file order.

    `weo` defaults to the WEO pull as of the run date: data/live/vintages/<date>/raw_weo.csv for the latest
    <date> <= as_of. With no such vintage the fill is in proposal order (no WEO ranking). Only with as_of=None
    is the current pull data/live/raw_weo.csv used. The `basis` column names the WEO file used."""
    from ..ingestion.universe import load_universe_proposal
    data_dir = Path(data_dir)
    book = pd.read_csv(data_dir / "portfolio.csv")
    desk = pd.read_csv(data_dir / "countries.csv", usecols=["country", "iso"])
    iso_of = dict(zip(desk["country"], desk["iso"]))
    g = book.assign(gross=book["notional_mm"].abs()).groupby("country")["gross"].sum().reset_index()
    g = g.sort_values(["gross", "country"], ascending=[False, True])
    rows = [{"country": c, "iso3": iso_of.get(c, ""), "gross_notional_mm": float(v), "basis": "book"}
            for c, v in zip(g["country"], g["gross"])]
    have = {r["iso3"] for r in rows}
    prop = load_universe_proposal(data_dir / "panel" / "universe_proposal.csv")
    cand = prop[(prop["tier"] == "EM") & (prop["embi_member"] == "Y") & ~prop["iso3"].isin(have)].copy()
    cand["order"] = range(len(cand))
    weo_label = "given"
    if weo is None:
        weo, weo_label = _weo_as_of(data_dir, as_of)
    size = {}
    if weo is not None and len(weo):
        w = weo[weo["series"] == "NGDPD"].copy()
        w["period"] = pd.to_numeric(w["period"], errors="coerce")
        if as_of is not None:
            w = w[w["period"] < pd.Timestamp(as_of).year]
        w = w.dropna(subset=["period", "value"]).sort_values("period")
        size = w.groupby("iso")["value"].last().to_dict()
    cand["ngdpd"] = cand["iso3"].map(size)
    cand = cand.sort_values(["ngdpd", "order"], ascending=[False, True], na_position="last")
    for _, r in cand.iterrows():
        if len(rows) >= n:
            break
        basis = f"universe fill (NGDPD, WEO {weo_label})" if pd.notna(r["ngdpd"]) else \
            f"universe fill (proposal order; WEO {weo_label})"
        rows.append({"country": r["name"], "iso3": r["iso3"], "gross_notional_mm": 0.0, "basis": basis})
    out = pd.DataFrame(rows[:n])
    out.insert(0, "rank", range(1, len(out) + 1))
    return out


def _weo_as_of(data_dir: Path, as_of) -> tuple[pd.DataFrame | None, str]:
    live = data_dir / "live"
    if as_of is None:
        f = live / "raw_weo.csv"
        return (pd.read_csv(f), "current pull") if f.exists() else (None, "none")
    cut = pd.Timestamp(as_of).normalize()
    vint = []
    for d in (live / "vintages").glob("*/raw_weo.csv"):
        try:
            t = pd.Timestamp(d.parent.name[:10])
        except ValueError:
            continue
        if t <= cut:
            vint.append((t, d))
    if not vint:
        return None, f"none: no vintage on or before {cut.date()}"
    t, f = max(vint)
    return pd.read_csv(f), f"vintage {t.date()}"


# ----------------------------------------------------------------------------------------------
# Input contract and point-in-time views
# ----------------------------------------------------------------------------------------------
def _period(p: str, freq: str) -> pd.Period:
    return pd.Period(p, freq="M" if freq == "M" else "Q")


def validate_inputs(df: pd.DataFrame) -> list[str]:
    """Problems with an input file under the contract in docs/validation/nowcast.md (empty list = valid)."""
    miss = [c for c in INPUT_COLUMNS if c not in df.columns]
    if miss:
        return [f"missing columns: {', '.join(miss)}"]
    probs: list[str] = []
    d = df.copy()
    bad_iso = ~d["iso3"].astype(str).str.match(ISO3_RE)
    if bad_iso.any():
        probs.append(f"{int(bad_iso.sum())} rows with iso3 not three capital letters")
    bad_code = ~d["series"].astype(str).str.match(SERIES_RE)
    if bad_code.any():
        probs.append(f"{int(bad_code.sum())} rows with a series code not matching {SERIES_RE.pattern}")
    bad_freq = ~d["freq"].isin(["M", "Q"])
    if bad_freq.any():
        probs.append(f"{int(bad_freq.sum())} rows with freq not in M/Q")
    unknown = sorted(set(d.loc[~bad_code, "series"]) - set(SERIES))
    if unknown:
        probs.append(f"unknown series codes: {', '.join(map(str, unknown))}")
    for code in set(d["series"]) & set(SERIES):
        wrong = (d["series"] == code) & (d["freq"] != SERIES[code][0])
        if wrong.any():
            probs.append(f"{code}: freq must be {SERIES[code][0]} ({int(wrong.sum())} rows)")
    okp = d.apply(lambda r: bool(_PERIOD_RE.get(r["freq"], re.compile("$^")).match(str(r["period"]))), axis=1)
    if (~okp).any():
        probs.append(f"{int((~okp).sum())} rows with a period not in YYYY-MM (M) or YYYY-Qn (Q) form")
    rd = pd.to_datetime(d["release_date"], format="%Y-%m-%d", errors="coerce")
    if rd.isna().any():
        probs.append(f"{int(rd.isna().sum())} rows with release_date not YYYY-MM-DD")
    val = pd.to_numeric(d["value"], errors="coerce")
    if (~np.isfinite(val)).any():
        probs.append(f"{int((~np.isfinite(val)).sum())} rows with a non-numeric value")
    good = okp & rd.notna() & ~bad_freq
    if good.any():
        ends = [_period(p, f).end_time.normalize() for p, f in zip(d.loc[good, "period"], d.loc[good, "freq"])]
        early = rd[good].to_numpy() <= np.array(ends, dtype="datetime64[ns]")
        if early.any():
            probs.append(f"{int(early.sum())} rows released on or before the end of their own period (look-ahead)")
    dup = d.assign(_v=val).groupby(["iso3", "series", "period", "release_date"])["_v"].nunique()
    if (dup > 1).any():
        probs.append(f"{int((dup > 1).sum())} (iso3, series, period, release_date) keys with conflicting values")
    if "release_date_basis" in d.columns:
        bad = ~d["release_date_basis"].fillna("").isin(RELEASE_DATE_BASIS)
        if bad.any():
            probs.append(f"{int(bad.sum())} rows with release_date_basis not in {sorted(RELEASE_DATE_BASIS)}")
    if d["source"].astype(str).str.strip().eq("").any() or d["source"].isna().any():
        probs.append("blank source on some rows")
    return probs


def read_inputs(path: str | Path, strict: bool = True) -> pd.DataFrame:
    df = pd.read_csv(path, dtype={"period": str, "release_date": str, "iso3": str, "series": str, "freq": str, "source": str})
    probs = validate_inputs(df)
    if probs and strict:
        raise ValueError(f"{path}: " + "; ".join(probs))
    return _prepare(df)


def _prepare(df: pd.DataFrame) -> pd.DataFrame:
    d = df.copy()
    d["value"] = pd.to_numeric(d["value"], errors="coerce")
    d["release_date"] = pd.to_datetime(d["release_date"]).dt.normalize()
    return d


def pit_view(inputs: pd.DataFrame, as_of) -> pd.DataFrame:
    """Rows released on or before as_of; for each (iso3, series, period) the latest such release."""
    d = inputs if pd.api.types.is_datetime64_any_dtype(inputs["release_date"]) else _prepare(inputs)
    d = d[d["release_date"] <= pd.Timestamp(as_of).normalize()]
    return d.sort_values("release_date").drop_duplicates(["iso3", "series", "period"], keep="last")


def first_releases(inputs: pd.DataFrame) -> pd.DataFrame:
    """For each (iso3, series, period), the earliest release."""
    d = inputs if pd.api.types.is_datetime64_any_dtype(inputs["release_date"]) else _prepare(inputs)
    return d.sort_values("release_date").drop_duplicates(["iso3", "series", "period"], keep="first")


def _monthly(view: pd.DataFrame, iso: str, code: str) -> pd.Series:
    s = view[(view["iso3"] == iso) & (view["series"] == code)]
    if s.empty:
        return pd.Series(dtype=float)
    out = pd.Series(s["value"].to_numpy(float), index=pd.PeriodIndex(s["period"], freq="M")).sort_index()
    return out.reindex(pd.period_range(out.index.min(), out.index.max(), freq="M"))


def target_series(view: pd.DataFrame, iso: str, target: str) -> pd.Series:
    """Quarterly target history from a view (point-in-time or first-release)."""
    if target == "GDP":
        s = view[(view["iso3"] == iso) & (view["series"] == "GDP_YOY")]
        if s.empty:
            return pd.Series(dtype=float)
        return pd.Series(s["value"].to_numpy(float), index=pd.PeriodIndex(s["period"], freq="Q")).sort_index()
    m = _monthly(view, iso, "CPI_YOY").dropna()
    if m.empty:
        return pd.Series(dtype=float)
    q = m.groupby(m.index.asfreq("Q")).agg(["mean", "count"])
    return q.loc[q["count"] == 3, "mean"].sort_index()


def first_release_table(inputs: pd.DataFrame, iso: str, target: str) -> pd.DataFrame:
    """Quarter -> first-release value and date for a target."""
    fr = first_releases(inputs)
    fr = fr[fr["iso3"] == iso]
    if target == "GDP":
        s = fr[fr["series"] == "GDP_YOY"]
        return pd.DataFrame({"quarter": pd.PeriodIndex(s["period"], freq="Q").astype(str),
                             "first_release": s["value"].to_numpy(float), "first_release_date": s["release_date"].to_numpy()})
    s = fr[fr["series"] == "CPI_YOY"].copy()
    if s.empty:
        return pd.DataFrame(columns=["quarter", "first_release", "first_release_date"])
    s["quarter"] = pd.PeriodIndex(s["period"], freq="M").asfreq("Q").astype(str)
    g = s.groupby("quarter").agg(first_release=("value", "mean"), n=("value", "size"), first_release_date=("release_date", "max"))
    return g[g["n"] == 3].drop(columns="n").reset_index()


# ----------------------------------------------------------------------------------------------
# Model pieces
# ----------------------------------------------------------------------------------------------
def _ar_forecast(x: np.ndarray, steps: int, max_p: int) -> np.ndarray:
    x = np.asarray(x, float)
    if steps <= 0:
        return np.empty(0)
    max_p = int(min(max_p, max(0, (len(x) - 4) // 3)))
    fit = ar_fit_bic(x, max_p=max_p)
    c, phi = fit["coef"][0], np.asarray(fit["coef"][1:], float)
    hist = list(x); out = []
    for _ in range(steps):
        f = c + sum(phi[i] * hist[-1 - i] for i in range(len(phi)))
        hist.append(f); out.append(f)
    return np.array(out)


def fill_ragged_edge(s: pd.Series, end: pd.Period, max_p: int = AR_MAX_P_MONTHLY) -> tuple[pd.Series, pd.Series]:
    """Interior gaps interpolated linearly; months after the last observation up to `end` filled by an AR(p)
    forecast. Returns (filled series, observed flag)."""
    obs = s.notna()                       # real releases only; interpolated months are not observed
    s = s.interpolate(limit_area="inside")
    last = s.last_valid_index()
    idx = pd.period_range(s.index.min(), max(end, s.index.max()), freq="M")
    s = s.reindex(idx); obs = obs.reindex(idx, fill_value=False)
    steps = (end - last).n if end > last else 0
    if steps:
        s.loc[last + 1:end] = _ar_forecast(s.loc[:last].dropna().to_numpy(), steps, max_p)
    return s, obs


def _ols(y: np.ndarray, X: np.ndarray) -> np.ndarray:
    return np.linalg.lstsq(X, y, rcond=None)[0]


def _pca_factors(panel: pd.DataFrame, k: int) -> pd.DataFrame:
    """First k principal components of the standardised monthly panel (complete rows only), sign fixed so the
    first indicator loads positively on each factor."""
    z = panel.dropna()
    mu, sd = z.mean(), z.std(ddof=0).replace(0, 1.0)
    zs = (z - mu) / sd
    _, _, vt = np.linalg.svd(zs.to_numpy(), full_matrices=False)
    k = min(k, vt.shape[0])
    w = vt[:k].T
    w = w * np.where(w[0] < 0, -1.0, 1.0)
    return pd.DataFrame(zs.to_numpy() @ w, index=z.index, columns=[f"f{i + 1}" for i in range(k)])


def _lag(y: pd.Series) -> pd.Series:
    out = y.copy()
    out.index = y.index + 1
    return out


def _bridge_predict(y: pd.Series, X: pd.DataFrame, targets: list[pd.Period]) -> tuple[list[float], int]:
    """OLS of y_t on [1, y_{t-1}, X_t] over complete quarters, then recursive prediction for `targets`."""
    D = pd.concat([y.rename("y"), _lag(y).rename("ylag"), X], axis=1).dropna()
    if len(D) < MIN_TRAIN:
        return [np.nan] * len(targets), len(D)
    A = np.column_stack([np.ones(len(D)), D["ylag"].to_numpy(), D[X.columns].to_numpy()])
    b = _ols(D["y"].to_numpy(), A)
    known = y.copy(); out = []
    for q in targets:
        prev = known.get(q - 1, np.nan)
        f = float(b[0] + b[1] * prev + X.loc[q].to_numpy() @ b[2:]) if q in X.index else np.nan
        known.loc[q] = f; out.append(f)
    return out, len(D)


def _ar_benchmark(y: pd.Series, targets: list[pd.Period]) -> list[float]:
    last = y.index.max()
    steps = (max(targets) - last).n
    fc = _ar_forecast(y.to_numpy(), steps, AR_MAX_P_QUARTERLY)
    return [float(fc[(q - last).n - 1]) for q in targets]


def nowcast_country(inputs: pd.DataFrame, iso: str, target: str, as_of, method: str = "bridge",
                    n_factors: int = 1) -> tuple[list[dict], str | None]:
    """Nowcasts for one country and target at as_of. Returns (rows, reason_if_none)."""
    if target not in TARGETS or method not in METHODS:
        raise ValueError(f"target must be one of {TARGETS} and method one of {METHODS}")
    if not isinstance(iso, str) or not ISO3_RE.match(iso):
        raise ValueError(f"iso3 must be three capital letters, got {iso!r}")
    as_of = pd.Timestamp(as_of).normalize()
    view = pit_view(inputs, as_of)
    view = view[view["iso3"] == iso]
    y = target_series(view, iso, target)
    if len(y) < MIN_TRAIN + 1:
        return [], f"target history {len(y)} quarters (< {MIN_TRAIN + 1})"
    y = y.reindex(pd.period_range(y.index.min(), y.index.max(), freq="Q")).interpolate(limit_area="inside")
    cur = as_of.to_period("Q")
    first = y.index.max() + 1
    targets = [q for q in pd.period_range(max(first, cur - (MAX_TARGET_QUARTERS - 1)), cur, freq="Q")]
    if not targets:
        return [], "no unreleased quarter at as_of"
    end_m = targets[-1].asfreq("M", how="end")
    start_m = targets[0].asfreq("M", how="start")
    codes = [c for c, spec in SERIES.items() if spec[0] == "M" and spec[1] in TARGET_BLOCKS[target]]
    filled, observed, used = {}, {}, []
    for c in codes:
        s = _monthly(view, iso, c)
        if s.notna().sum() < MIN_MONTHS or (start_m - s.last_valid_index()).n > MAX_STALE_MONTHS:
            continue
        f, o = fill_ragged_edge(s, end_m)
        filled[c], observed[c] = f, o; used.append(c)
    if not used:
        return [], "no usable monthly indicator"
    panel = pd.DataFrame(filled)
    obs = pd.DataFrame(observed).reindex(panel.index, fill_value=False)
    if method == "pca":
        F = _pca_factors(panel, n_factors)
        Xq = F.groupby(F.index.asfreq("Q")).mean().where(F.groupby(F.index.asfreq("Q")).count() == 3)
        pred, n_train = _bridge_predict(y, Xq, targets)
        method_used = f"pca{min(n_factors, len(used))}"
    else:
        cnt = panel.groupby(panel.index.asfreq("Q")).count()
        Xq = panel.groupby(panel.index.asfreq("Q")).mean().where(cnt == 3)
        k = len(used) + 2
        n_avail = len(pd.concat([y, _lag(y), Xq], axis=1).dropna())
        if n_avail >= 4 * k:
            pred, n_train = _bridge_predict(y, Xq, targets)
            method_used = "bridge"
        else:
            preds = [_bridge_predict(y, Xq[[c]], targets) for c in used]
            ok = [p for p in preds if np.isfinite(p[0]).all()]
            if not ok:
                return [], "too few quarters for any bridge"
            pred = list(np.mean([p[0] for p in ok], axis=0)); n_train = int(min(p[1] for p in ok))
            method_used = "bridge_pooled"
    if not np.isfinite(pred).all():
        return [], f"bridge training sample {n_train} quarters (< {MIN_TRAIN})"
    ar = _ar_benchmark(y.dropna(), targets)
    h = hashlib.sha256(view.sort_values(["series", "period", "release_date"])[["series", "period", "value", "release_date"]]
                       .to_csv(index=False).encode()).hexdigest()[:12]
    rows = []
    for q, p, a in zip(targets, pred, ar):
        months = obs.loc[q.asfreq("M", how="start"):q.asfreq("M", how="end")]
        rows.append({"as_of": as_of.strftime("%Y-%m-%d"), "iso3": iso, "target": target, "quarter": str(q), "method": method,
                     "horizon": "nowcast" if q == cur else f"backcast{(cur - q).n}", "method_used": method_used,
                     "nowcast": round(float(p), 6), "ar_benchmark": round(float(a), 6), "indicators": ";".join(used),
                     "n_indicators": len(used), "months_observed": round(float(months.sum().mean()), 3),
                     "n_train": int(n_train), "inputs_hash": h})
    return rows, None


def run_nowcasts(inputs: pd.DataFrame, as_of, names: list[str], method: str = "bridge", targets=TARGETS,
                 country_names: dict | None = None, n_factors: int = 1) -> tuple[pd.DataFrame, pd.DataFrame]:
    """All names x targets. Returns (nowcast rows in LOG_COLUMNS order, skipped table with reasons)."""
    rows, skipped = [], []
    for iso in names:
        for t in targets:
            r, why = nowcast_country(inputs, iso, t, as_of, method=method, n_factors=n_factors)
            rows += r
            if why:
                skipped.append({"iso3": iso, "target": t, "reason": why})
    out = pd.DataFrame(rows).reindex(columns=LOG_COLUMNS)
    out["country"] = out["iso3"].map(country_names or {}).fillna("")
    return out, pd.DataFrame(skipped, columns=["iso3", "target", "reason"])


# ----------------------------------------------------------------------------------------------
# Error tracking
# ----------------------------------------------------------------------------------------------
def read_log(path: str | Path = DEFAULT_LOG) -> pd.DataFrame:
    p = Path(path)
    if not p.exists():
        return pd.DataFrame(columns=LOG_COLUMNS)
    return pd.read_csv(p, dtype={"as_of": str, "quarter": str, "first_release_date": str, "scored_on": str,
                                 "score_note": str}).reindex(columns=LOG_COLUMNS)


def write_log(log: pd.DataFrame, path: str | Path = DEFAULT_LOG) -> None:
    """Write the log with text cells made formula-safe (a leading = + - @ gets an apostrophe)."""
    Path(path).parent.mkdir(parents=True, exist_ok=True)
    _csv_safe(log.reindex(columns=LOG_COLUMNS)).to_csv(path, index=False)


def append_log(new: pd.DataFrame, path: str | Path = DEFAULT_LOG) -> pd.DataFrame:
    """Append nowcasts to the CSV log. A stored (as_of, iso3, target, quarter, method) row is never overwritten:
    the log is a record of what was said on the day."""
    log = read_log(path)
    if len(log):
        k_old = set(map(tuple, log[LOG_KEY].astype(str).to_numpy()))
        new = new[[tuple(r) not in k_old for r in new[LOG_KEY].astype(str).to_numpy()]]
    out = pd.concat([log, new[LOG_COLUMNS]], ignore_index=True) if len(log) else new[LOG_COLUMNS].copy()
    write_log(out, path)
    return out


def score_log(log: pd.DataFrame, inputs: pd.DataFrame, as_of) -> pd.DataFrame:
    """Fill first_release, error (nowcast - first release) and ar_error for unscored rows whose first release is
    dated on or before as_of. A first release dated on or before the nowcast's own as_of is not used (it would
    mean the nowcast could have seen it)."""
    as_of = pd.Timestamp(as_of).normalize()
    log = log.reindex(columns=LOG_COLUMNS).copy()
    for c in ("first_release", "error", "ar_error"):
        log[c] = pd.to_numeric(log[c], errors="coerce")
    for c in ("first_release_date", "scored_on", "score_note"):
        log[c] = log[c].astype(object)
    cache: dict = {}
    for i, r in log[log["first_release"].isna()].iterrows():
        key = (r["iso3"], r["target"])
        if key not in cache:
            cache[key] = first_release_table(inputs, *key).set_index("quarter")
        t = cache[key]
        if r["quarter"] not in t.index:
            continue
        fr, frd = t.loc[r["quarter"], "first_release"], pd.Timestamp(t.loc[r["quarter"], "first_release_date"])
        if frd > as_of:
            continue
        if frd <= pd.Timestamp(r["as_of"]):
            log.loc[i, "score_note"] = (f"not scored: first release {frd.date()} is on or before the nowcast as_of "
                                        f"{r['as_of']}, so the nowcast could have seen it")
            continue
        log.loc[i, ["first_release", "error", "ar_error"]] = [fr, float(r["nowcast"]) - fr, float(r["ar_benchmark"]) - fr]
        log.loc[i, "first_release_date"] = frd.strftime("%Y-%m-%d")
        log.loc[i, "scored_on"] = as_of.strftime("%Y-%m-%d")
    return log


def error_summary(log: pd.DataFrame, by=("target", "horizon", "method")) -> pd.DataFrame:
    """RMSE of the nowcast and of the AR benchmark against first releases, on scored rows."""
    s = log.dropna(subset=["error", "ar_error"]).copy()
    if s.empty:
        return pd.DataFrame(columns=list(by) + ["n", "rmse", "rmse_ar", "rel_rmse", "mae", "bias", "dm_t", "dm_p"])
    s["error"] = s["error"].astype(float); s["ar_error"] = s["ar_error"].astype(float)
    out = []
    for k, g in s.groupby(list(by)):
        e, a = g["error"].to_numpy(), g["ar_error"].to_numpy()
        rm, ra = float(np.sqrt(np.mean(e ** 2))), float(np.sqrt(np.mean(a ** 2)))
        t, p = diebold_mariano(e ** 2, a ** 2)
        out.append(dict(zip(by, k if isinstance(k, tuple) else (k,))) | {
            "n": len(g), "rmse": rm, "rmse_ar": ra, "rel_rmse": rm / ra if ra > 0 else np.nan,
            "mae": float(np.mean(np.abs(e))), "bias": float(np.mean(e)), "dm_t": t, "dm_p": p})
    return pd.DataFrame(out)


def pseudo_real_time(inputs: pd.DataFrame, names: list[str], as_of_dates, method: str = "bridge", targets=TARGETS,
                     score_as_of=None, n_factors: int = 1) -> pd.DataFrame:
    """Run the nowcaster at each as_of in turn (each run sees only its own point-in-time view) and score every
    row against first releases dated on or before score_as_of (default: the last as_of)."""
    parts = [run_nowcasts(inputs, d, names, method=method, targets=targets, n_factors=n_factors)[0] for d in as_of_dates]
    log = pd.concat(parts, ignore_index=True)
    return score_log(log, inputs, score_as_of if score_as_of is not None else max(pd.Timestamp(d) for d in as_of_dates))


# ----------------------------------------------------------------------------------------------
# Command line
# ----------------------------------------------------------------------------------------------
def _names_arg(arg: str, data_dir: Path, inputs: pd.DataFrame, as_of) -> tuple[list[str], dict]:
    t = top_names(data_dir, as_of=as_of)
    cn = dict(zip(t["iso3"], t["country"]))
    if arg == "top":
        return list(t["iso3"]), cn
    if arg == "all":
        return sorted(inputs["iso3"].unique()), cn
    return [x.strip().upper() for x in arg.split(",") if x.strip()], cn


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.engine.nowcast", description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    a = sub.add_parser("names"); a.add_argument("--data", default=str(ROOT / "data")); a.add_argument("--n", type=int, default=25)
    a.add_argument("--as-of", default=None)
    v = sub.add_parser("validate"); v.add_argument("--inputs", default=str(DEFAULT_INPUTS))
    r = sub.add_parser("run"); r.add_argument("--inputs", default=str(DEFAULT_INPUTS)); r.add_argument("--as-of", required=True)
    r.add_argument("--method", choices=METHODS, default="bridge"); r.add_argument("--names", default="top")
    r.add_argument("--factors", type=int, default=1); r.add_argument("--log", default=str(DEFAULT_LOG))
    r.add_argument("--data", default=str(ROOT / "data"))
    s = sub.add_parser("score"); s.add_argument("--inputs", default=str(DEFAULT_INPUTS)); s.add_argument("--as-of", required=True)
    s.add_argument("--log", default=str(DEFAULT_LOG))
    m = sub.add_parser("summary"); m.add_argument("--log", default=str(DEFAULT_LOG))
    args = ap.parse_args(argv)
    if args.cmd == "names":
        print(top_names(args.data, n=args.n, as_of=args.as_of).to_string(index=False))
        return 0
    if args.cmd == "validate":
        probs = validate_inputs(pd.read_csv(args.inputs, dtype=str))
        print("valid" if not probs else "\n".join(probs))
        return 1 if probs else 0
    if args.cmd == "summary":
        print(error_summary(read_log(args.log)).to_string(index=False))
        return 0
    inputs = read_inputs(args.inputs)
    if args.cmd == "run":
        names, cn = _names_arg(args.names, Path(args.data), inputs, args.as_of)
        rows, skipped = run_nowcasts(inputs, args.as_of, names, method=args.method, country_names=cn, n_factors=args.factors)
        append_log(rows, args.log)
        print(rows[["iso3", "target", "quarter", "horizon", "method_used", "nowcast", "ar_benchmark", "months_observed"]].to_string(index=False))
        if len(skipped):
            print("\nskipped:\n" + skipped.to_string(index=False))
        return 0
    log = score_log(read_log(args.log), inputs, args.as_of)
    write_log(log, args.log)
    print(error_summary(log).to_string(index=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
