"""Country readiness: the Country Profile and indicator fields a country must have before it is scored (EQ-B-0045).

The engine reads many profile fields with `float(...)`; a blank cell becomes NaN and, depending on where it lands,
either turns the country's PD, EL and every downstream number into NaN or quietly changes the answer (a blank
spread is a Calm regime, a blank `fxregime` takes the peg depreciation in the stress path, a blank `parallel` drops
the pillar 2 floor, a blank exports or reserves drops the stress-path score). With 70 sovereigns onboarding with
blank seed rows (HO-20261023-A-B-008) those failures must be loud and complete, so `check_readiness` collects every
missing required field for every country in one pass and `require_ready` raises one error that lists them all.
`score_universe` calls `require_ready` first, so `run_pipeline`, stress runs and the pre-trade check all stop there.

Three tiers, documented in docs/validation/scorecard.md ("Country readiness"):
* blocking (`REQUIRED_PROFILE`, `REQUIRED_INDICATORS`, every pillar with at least one scored indicator, and
  `POSITION_PROFILE` for a country that has positions): the run stops;
* fallback, documented and safe: a country with no column in adjustments.csv (or a blank cell) gets no analyst
  adjustment and no trigger input (0), which is what an empty adjustment means;
* advisory (`ADVISORY_PROFILE`, `ADVISORY_INDICATORS`, pillar weight coverage below 100%): reported on the
  `Readiness` object, never stops a run.

Yes/No flags are turned into booleans by the loader, so a blank flag reads as "No" and cannot be seen here. When
the loader records the blank cells as `u.provenance["blank_yes_no"]` ({country: [column, ...]}, requested from
Team A in the EQ-B-0045 handoff) they are blocking too. Checks only read; nothing here changes a number.
"""
from __future__ import annotations
from dataclasses import dataclass, field
import numpy as np
import pandas as pd
from ..config import Settings, PILLARS
from ..ingestion import Universe

# field -> why the engine needs it (the "why" column of the readiness table in docs/validation/scorecard.md)
REQUIRED_PROFILE = {
    "iso": "ISO3 code: layer 1 WEO join, event index, outputs",
    "region": "layer 5/6 regional factor and scenario region filters",
    "fxregime": "stress-path depreciation (blank takes the peg shock), layer 2 FX weight, layer 6 FX vol",
    "rating": "layer 1 RatingChallenger and calibration target, layer 2 exempt ratings, stress rating ladder",
    "spread": "layer 2 market-implied PD, layer 3 rule regime (blank reads Calm), layer 6 credit vol and carry",
    "fx3m": "layer 2 FX term, layer 3 rule regime",
    "res3m": "layer 3 rule regime (reserve-loss test)",
    "textz": "layer 2 text term (0 means no text signal)",
    "pop": "small-state weight set",
    "exports": "layer 1 reserves cover, layer 4 Merton DD, stress-path export shock",
    "reserves": "layer 1 reserves cover, layer 4 Merton DD, stress-path reserve erosion",
    "exptype": "stress-path export shock type, commodity scenarios, signal 12",
    "commgap": "layer 1 commodity export shock, pillar 3 boom trigger",
    "parallel": "pillar 2 override floor (parallel-market premium)",
}
# Yes/No flags: override floors, the Crisis regime (default) and signal 16. Blocking when the loader reports blanks.
REQUIRED_FLAGS = ("default", "extarrears", "exprop", "coup", "nopay", "bankcrisis", "emergency", "disaster")
# only for a country with at least one position in the book
POSITION_PROFILE = {"stress_depreciation": "layer 6 FX and local-bond loss on a transfer-and-convertibility event"}
ADVISORY_PROFILE = {
    "elmonths": "signal 8 election window (blank reads as outside the window)",
    "gpr_series": "GPR uplift on 4.10 (blank: analyst level only)",
    "gpr_analyst_410": "GPR 4.10 level (blank: the indicator table's 4.10)",
    "etf": "HMM regimes, GARCH vols, estimated copula, only while prices.csv has ETF columns (blank, or an FX-only "
           "prices.csv: equity on judgement, EQ-B-0077)",
    "currency": "FX price history for HMM, GARCH and the estimated copula",
}
REQUIRED_INDICATORS = {
    "1.3": "layer 1 debt_gdp, layer 4 Merton DD, stress path",
    "1.4": "stress path (gross financing need)",
    "1.5": "layer 4 Merton DD, stress-path FX revaluation of debt",
    "1.6": "layer 1 primary deficit, stress path",
    "1.7": "stress path (debt change)",
    "2.1": "stress path (reserves erosion)",
    "2.7": "pillar 2 override floor, sanctions peril",
    "2.8": "layer 1 current account, stress path",
    "2.9": "layer 1 short-term FX debt / reserves, layer 4 Merton DD",
    "2.11": "stress-path export shock",
    "4.10": "sanctions peril, GPR (or fill gpr_analyst_410)",
    "5.5": "layer 1 inflation, pillar 5 hyperinflation floor, stress path",
    "5.6": "layer 1 real growth, stress path",
    "5.12": "layer 4 Merton DD asset volatility",
    "6.1": "pillar 6 war floor",
    "7.2": "small-state test (tail loss)",
}
ADVISORY_INDICATORS = ("1.1", "1.2", "2.5", "2.6", "2.12", "4.5", "5.1", "5.3", "5.10", "5.13")   # dashboard signals only


class UniverseNotReady(ValueError):
    """Raised by `require_ready`; `.readiness` holds the full report."""

    def __init__(self, message: str, readiness: "Readiness"):
        super().__init__(message)
        self.readiness = readiness


@dataclass
class Readiness:
    missing: dict = field(default_factory=dict)     # country -> [blocking field, ...] in a stable order
    advisory: dict = field(default_factory=dict)    # country -> [advisory field, ...]
    fallbacks: dict = field(default_factory=dict)   # country -> [fallback applied, ...]
    coverage: pd.DataFrame | None = None            # pillar x country: share of pillar weight with a value

    @property
    def ok(self) -> bool:
        return not self.missing

    def to_frame(self) -> pd.DataFrame:
        """One row per (country, field): kind (profile / indicator / pillar / flag / position / adjustments) and
        blocking True/False, the shape Team A's cells_to_fill.csv needs."""
        rows = []
        for blocking, src in ((True, self.missing), (False, self.advisory), (False, self.fallbacks)):
            for c, items in src.items():
                for it in items:
                    rows.append({"country": c, "field": it, "kind": _kind(it), "blocking": blocking})
        return pd.DataFrame(rows, columns=["country", "field", "kind", "blocking"])

    def message(self, n_countries: int | None = None) -> str:
        tot = f" of {n_countries}" if n_countries else ""
        counts = pd.Series([f for v in self.missing.values() for f in v]).value_counts()
        top = ", ".join(f"{k} ({v})" for k, v in counts.head(8).items())
        lines = [f"universe not ready: {len(self.missing)}{tot} countries are missing required fields "
                 f"(most often: {top}). Fill them in countries.csv / indicators.csv before scoring; "
                 "see docs/validation/scorecard.md, Country readiness."]
        lines += [f"  {c}: {', '.join(_compact(v))}" for c, v in self.missing.items()]
        return "\n".join(lines)


def _compact(items: list) -> list:
    """For the message only: a country with every pillar empty is one item, not seven pillars and every indicator."""
    empty = [i for i in items if i.startswith("pillar ")]
    if len(empty) < len(PILLARS):
        return items
    n_ind = sum(i.startswith("indicator ") for i in items)
    rest = [i for i in items if not (i.startswith("pillar ") or i.startswith("indicator "))]
    return rest + [f"no indicator values (pillars 1-{len(PILLARS)} have no scored indicator; {n_ind} required indicators blank)"]


def _kind(item: str) -> str:
    if item.startswith("pillar "):
        return "pillar"
    if item.startswith("adjustments"):
        return "adjustments"
    if item.startswith("indicator "):
        return "indicator"
    if item.startswith("flag "):
        return "flag"
    if item in POSITION_PROFILE:
        return "position"
    return "profile"


def _blank(v) -> bool:
    return v is None or (isinstance(v, str) and v.strip() == "") or (not isinstance(v, str) and pd.isna(v))


def _not_number(v) -> bool:
    if _blank(v):
        return True
    try:
        return not np.isfinite(float(v))
    except (TypeError, ValueError):
        return True


def check_readiness(u: Universe, settings: Settings | None = None) -> Readiness:
    """Every missing required field for every country in `u` (see the module docstring). Reads only."""
    names = u.names
    prof = u.countries.set_index("country")
    ind = u.indicators.set_index("id")
    rb = u.rulebook.set_index("id")
    ratings = set((settings["ratings_pd"] if settings is not None else {}) or {})
    regimes = set(((settings["market"] or {}).get("fx_vol") or {}) if settings is not None else {}) | {"Peg", "Dollarized"}
    positioned = set(u.portfolio["country"]) if u.portfolio is not None and len(u.portfolio) else set()
    blank_flags = (u.provenance or {}).get("blank_yes_no") or {}
    adj_cols = set(u.adjustments.columns) if u.adjustments is not None else set()
    # pillar weight coverage on the raw values (an indicator scores only when its raw value is a number)
    raw = ind.reindex(columns=names)
    num = raw.apply(lambda col: pd.to_numeric(col.map(lambda v: np.nan if _blank(v) else v), errors="coerce"))
    have = pd.DataFrame(np.isfinite(num.to_numpy(dtype=float)), index=raw.index, columns=names)
    hv = have.reindex(rb.index, fill_value=False).to_numpy(dtype=float)
    W = np.array([np.where(rb["pillar"].to_numpy() == p, rb["weight"].to_numpy(dtype=float), 0.0) for p in PILLARS])
    coverage = pd.DataFrame((W @ hv) / W.sum(axis=1, keepdims=True), index=list(PILLARS), columns=names)
    out = Readiness(coverage=coverage)
    for c in names:
        r = prof.loc[c]
        miss, adv, fb = [], [], []
        for f in REQUIRED_PROFILE:
            v = r.get(f, np.nan)
            if f in ("iso", "region", "fxregime", "rating", "exptype"):
                if _blank(v):
                    miss.append(f)
                elif f == "rating" and ratings and str(v).strip() not in ratings:
                    miss.append(f"rating (unknown '{v}')")
                elif f == "fxregime" and settings is not None and str(v).strip() not in regimes:
                    miss.append(f"fxregime (unknown '{v}')")
            elif _not_number(v):
                miss.append(f)
        miss += [f"flag {f}" for f in REQUIRED_FLAGS if f in (blank_flags.get(c) or [])]
        if c in positioned:
            miss += [f for f in POSITION_PROFILE if _not_number(r.get(f, np.nan))]
        miss += [f"pillar {p} (no scored indicator)" for p in PILLARS if coverage.at[p, c] == 0]
        for iid in REQUIRED_INDICATORS:
            if iid in ind.index and not bool(have.at[iid, c]):
                miss.append(f"indicator {iid}")
        adv += [f for f in ADVISORY_PROFILE if _blank(r.get(f, np.nan))]
        adv += [f"indicator {i}" for i in ADVISORY_INDICATORS if i in ind.index and not bool(have.at[i, c])]
        adv += [f"pillar {p} coverage {coverage.at[p, c]:.0%}" for p in PILLARS if 0 < coverage.at[p, c] < 1 - 1e-9]
        if c not in adj_cols:
            fb.append("adjustments.csv column (none: analyst adjustments and trigger inputs 0)")
        elif u.adjustments[c].map(_blank).any():
            fb.append("adjustments.csv blank cells (read as 0)")
        if miss:
            out.missing[c] = miss
        if adv:
            out.advisory[c] = adv
        if fb:
            out.fallbacks[c] = fb
    return out


def require_ready(u: Universe, settings: Settings | None = None) -> Readiness:
    """`check_readiness`, raising `UniverseNotReady` (a ValueError) with one consolidated list when any country is
    missing a blocking field."""
    r = check_readiness(u, settings)
    if not r.ok:
        raise UniverseNotReady(r.message(len(u.names)), r)
    return r
