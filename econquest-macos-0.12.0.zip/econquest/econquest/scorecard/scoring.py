"""Scorecard: indicator scores -> pillar aggregates -> final pillars -> composite.

Rules (paper Appendix A and the methodology rulebook):
* numeric indicators score 0-100 by straight-line interpolation between five threshold points;
  direction is carried by the ordering of the thresholds; two-sided indicators (5.13) take the
  higher of the high-side and low-side scores;
* level indicators (0-4) map to 0, 25, 50, 75, 100;
* a pillar aggregate blends the weighted average with the worst indicator (fix 1): only indicators
  whose weight is at least `min_weight_worst` count for the worst-indicator term;
* final pillar = aggregate + capped trigger add-ons + analyst adjustment, never below the override
  floor implied by the country's flags, clamped to 0-100;
* composite = weighted final pillars; small states use the small-state weight set;
* grade = min(10, int(score / 10) + 1).
"""
from __future__ import annotations
from dataclasses import dataclass
import numpy as np
import pandas as pd
from ..config import Settings, PILLARS
from ..ingestion import Universe
from .readiness import require_ready

SCORE_POINTS = np.array([0.0, 25.0, 50.0, 75.0, 100.0])


def interp_score(x: float, thresholds: np.ndarray) -> float:
    """Piecewise-linear score; thresholds may be increasing or decreasing."""
    t = np.asarray(thresholds, dtype=float)
    if np.any(np.isnan(t)):
        return np.nan
    if t[0] <= t[-1]:
        return float(np.interp(x, t, SCORE_POINTS))
    return float(np.interp(x, t[::-1], SCORE_POINTS[::-1]))


@dataclass
class Scorecard:
    indicator_scores: pd.DataFrame     # id x country, worse of baseline and stress-path score
    base_scores: pd.DataFrame
    stress_scores: pd.DataFrame
    pillar_wavg: pd.DataFrame          # pillar x country
    pillar_worst: pd.DataFrame
    pillar_aggregated: pd.DataFrame
    pillar_final: pd.DataFrame
    triggers: pd.DataFrame
    floors: pd.DataFrame
    weights: pd.DataFrame              # pillar x country (standard or small-state)
    composite: pd.Series
    grade: pd.Series
    small_state: pd.Series

    def drivers(self) -> pd.DataFrame:
        """Peril drivers used by the Risk Engine (points, 0-100)."""
        s = self.indicator_scores
        return pd.DataFrame({
            "Transfer and convertibility": self.pillar_final.loc[2],
            "Expropriation": self.pillar_final.loc[3],
            "Political violence": (self.pillar_final.loc[4] + self.pillar_final.loc[6]) / 2,
            "Sanctions": (s.loc["2.7"] + s.loc["4.10"]) / 2,
        }).T


def stress_inputs(u: Universe, settings: Settings) -> pd.DataFrame:
    """Combined stress shock on the eight stress-path indicators (methodology stress path).
    Returns a copy of the raw indicator table with the stressed values substituted."""
    sp = settings["stress_path"]
    ind = u.indicators.set_index("id").copy()
    prof = u.countries.set_index("country")
    for c in u.names:
        r = prof.loc[c]
        dep = {"Float": sp["dep_float"], "Managed": sp["dep_managed"]}.get(r["fxregime"], sp["dep_peg"])
        shock = {"Commodity": sp["commodity_shock"], "Tourism": sp["tourism_shock"]}.get(r["exptype"], sp["manufacturing_shock"])
        exp_shock = abs(shock) / 100 * float(r["exports"]) * float(ind.at["2.11", c]) / 100   # % of GDP
        g = sp["growth_shock"]
        debt, fxshare = float(ind.at["1.3", c]), float(ind.at["1.5", c])
        debt_s = debt * (1 + fxshare / 100 * dep / 100) / (1 + g / 100) + sp["pb_loss_per_pp"] * abs(g)
        ind.at["1.3", c] = debt_s
        ind.at["1.4", c] = float(ind.at["1.4", c]) + sp["pb_loss_per_pp"] * abs(g) + debt * sp["rate_shock"] * sp["repricing_share"] / 100
        ind.at["1.6", c] = float(ind.at["1.6", c]) - sp["pb_loss_per_pp"] * abs(g) - debt / 100 * (sp["rate_shock"] * sp["repricing_share"] + abs(g))
        ind.at["1.7", c] = float(ind.at["1.7", c]) + (debt_s - debt)
        if r["fxregime"] in ("Peg", "Dollarized"):
            ind.at["2.1", c] = float(ind.at["2.1", c]) * max(0.0, 1 - exp_shock / float(r["reserves"]))
        ind.at["2.8", c] = float(ind.at["2.8", c]) - exp_shock
        ind.at["5.5", c] = float(ind.at["5.5", c]) + sp["inflation_passthrough"] * dep
        ind.at["5.6", c] = float(ind.at["5.6", c]) + g
    return ind.reset_index()


def _interp_scores(x: np.ndarray, thresholds: np.ndarray) -> np.ndarray:
    """`interp_score` over an array of values (the same np.interp call, so the same numbers element by element)."""
    t = np.asarray(thresholds, dtype=float)
    if np.any(np.isnan(t)):
        return np.full(np.shape(x), np.nan)
    if t[0] <= t[-1]:
        return np.interp(x, t, SCORE_POINTS)
    return np.interp(x, t[::-1], SCORE_POINTS[::-1])


def _as_float(row: pd.Series) -> np.ndarray:
    """Raw indicator values as floats; "" and NaN become NaN (any other non-number raises, as float(x) did)."""
    return np.array([np.nan if (isinstance(x, str) and x == "") or pd.isna(x) else float(x) for x in row], dtype=float)


def score_indicators(u: Universe, indicators: pd.DataFrame | None = None) -> pd.DataFrame:
    """Indicator scores, id x country. Vectorised across countries (EQ-B-0034): the same numbers as the former
    per-cell loop, at a cost that grows with the number of indicators rather than indicators x countries."""
    rb = u.rulebook.set_index("id")
    ind = (indicators if indicators is not None else u.indicators).set_index("id")
    names = u.names
    raw = ind[names]
    out = pd.DataFrame(np.nan, index=ind.index, columns=names, dtype=float)
    for iid, row in rb.iterrows():
        hi = row[["t0", "t25", "t50", "t75", "t100"]].to_numpy(dtype=float)
        lo = row[["low0", "low25", "low50", "low75", "low100"]].to_numpy(dtype=float)
        two_sided = not np.any(np.isnan(lo))
        is_level = str(row["type"]).lower().startswith("level")
        x = _as_float(raw.loc[iid])
        if is_level:
            s = np.clip(x, 0, 4) * 25.0
        else:
            s = _interp_scores(x, hi)
            if two_sided:
                s_lo = _interp_scores(x, lo)
                s = np.where(s_lo > s, s_lo, s)          # Python max(s, s_lo): s unless s_lo is strictly larger
        out.loc[iid] = np.where(np.isnan(x), np.nan, s)
    return out


def override_floors(u: Universe, ind_raw: pd.DataFrame, settings: Settings) -> pd.DataFrame:
    """Floors from the Country Profile flags (methodology rulebook)."""
    f = settings["floors"]
    c = u.countries.set_index("country")
    floors = pd.DataFrame(0.0, index=list(PILLARS), columns=u.names)
    for n in u.names:
        r = c.loc[n]
        if r["default"]:
            floors.at[1, n] = f["p1_default"]
        if r["extarrears"] or float(r["parallel"] or 0) >= f["p2_parallel_threshold"] or float(ind_raw.at["2.7", n]) >= 4:
            floors.at[2, n] = f["p2_external"]
        if r["exprop"]:
            floors.at[3, n] = f["p3_exprop"]
        if r["coup"]:
            floors.at[4, n] = max(floors.at[4, n], f["p4_coup"])
        if r["nopay"]:
            floors.at[4, n] = max(floors.at[4, n], f["p4_nopay"])
        if float(ind_raw.at["5.5", n]) >= f["p5_hyperinflation_threshold"]:
            floors.at[5, n] = max(floors.at[5, n], f["p5_hyperinflation"])
        if r["bankcrisis"]:
            floors.at[5, n] = max(floors.at[5, n], f["p5_bankcrisis"])
        if float(ind_raw.at["6.1", n]) >= 3:
            floors.at[6, n] = max(floors.at[6, n], f["p6_war"])
        if r["emergency"]:
            floors.at[6, n] = max(floors.at[6, n], f["p6_emergency"])
        if r["disaster"]:
            floors.at[7, n] = f["p7_disaster"]
    return floors


def _adj_value(r: pd.Series, c: str) -> float:
    """An adjustments.csv cell; a country without a column, or a blank cell, has no adjustment (0) (EQ-B-0045)."""
    v = r.get(c, 0.0)
    return 0.0 if v is None or (isinstance(v, str) and not v.strip()) or (not isinstance(v, str) and pd.isna(v)) else float(v or 0)


def score_universe(u: Universe, settings: Settings) -> Scorecard:
    require_ready(u, settings)          # one consolidated list of missing required fields, before any NaN spreads (EQ-B-0045)
    sc = settings["scorecard"]
    rb = u.rulebook.set_index("id")
    ind_raw = u.indicators.set_index("id")
    base = score_indicators(u)
    stressed = score_indicators(u, stress_inputs(u, settings))
    scores = pd.DataFrame(np.fmax(base.to_numpy(dtype=float), stressed.to_numpy(dtype=float)), index=base.index, columns=base.columns)
    pillars = list(PILLARS)
    wavg = pd.DataFrame(index=pillars, columns=u.names, dtype=float)
    worst = wavg.copy()
    S = scores.to_numpy(dtype=float)
    empty = []
    for p in pillars:
        ids = rb.index[rb["pillar"] == p]
        rows = scores.index.get_indexer(ids)              # rulebook order, as before (same summation order)
        w = rb.loc[ids, "weight"].to_numpy(dtype=float)
        elig_w = w >= sc["min_weight_worst"] - 1e-12
        for j, c in enumerate(u.names):
            s = S[rows, j]
            ok = ~np.isnan(s)
            if not ok.any():
                empty.append(f"{c} pillar {p}")
                continue
            wavg.at[p, c] = float(np.sum(w[ok] * s[ok]) / np.sum(w[ok]))
            elig = ok & elig_w
            worst.at[p, c] = float(np.max(s[elig])) if elig.any() else float(np.max(s[ok]))
    if empty:
        # a country onboarded before its inputs are filled (EQ-B-0034): say which, instead of numpy's zero-size max error
        raise ValueError(f"scorecard: no scored indicator in {len(empty)} pillar(s), fill the inputs first: {', '.join(empty[:20])}"
                         + (" ..." if len(empty) > 20 else ""))
    aggregated = (1 - sc["worst_blend"]) * wavg + sc["worst_blend"] * worst

    # trigger add-ons: boom trigger on pillar 3 (both conditions, fix 5) plus any analyst trigger inputs
    adj = u.adjustments
    trig = pd.DataFrame(0.0, index=pillars, columns=u.names)
    boom = settings.get("boom_trigger", default={"price_above_avg": 25, "pillar1_at_least": 60, "points": 10})
    prof = u.countries.set_index("country")
    for c in u.names:
        if float(prof.at[c, "commgap"] or 0) >= boom["price_above_avg"] and aggregated.at[1, c] >= boom["pillar1_at_least"]:
            trig.at[3, c] += boom["points"]
    extra = adj[adj["block"].str.startswith("Trigger inputs")]
    for _, r in extra.iterrows():
        for c in u.names:
            trig.at[int(r["pillar"]), c] += _adj_value(r, c)
    caps = pd.Series({p: (sc["trigger_cap_p7"] if p == 7 else sc["trigger_cap"]) for p in pillars})
    trig = trig.clip(upper=caps.to_numpy()[:, None], axis=0)

    analyst = pd.DataFrame(0.0, index=pillars, columns=u.names)
    for _, r in adj[adj["block"] == "Analyst adjustment"].iterrows():
        for c in u.names:
            analyst.at[int(r["pillar"]), c] = float(np.clip(_adj_value(r, c), -sc["max_analyst_adj"], sc["max_analyst_adj"]))

    floors = override_floors(u, ind_raw, settings)
    final = (aggregated + trig + analyst).clip(lower=0, upper=100)
    final = pd.DataFrame(np.maximum(final.to_numpy(), floors.to_numpy()), index=pillars, columns=u.names)

    small = pd.Series(False, index=u.names)
    for c in u.names:
        small[c] = (float(prof.at[c, "pop"]) < sc["small_state_pop_below"]) or (float(ind_raw.at["7.2", c]) >= sc["small_state_tail_loss_at_least"])
    std_w = pd.Series({p: sc["pillar_weights"][str(p)] for p in pillars})
    small_w = pd.Series({p: sc["small_state_weights"][str(p)] for p in pillars})
    weights = pd.DataFrame({c: (small_w if small[c] else std_w) for c in u.names})
    composite = (final * weights).sum(axis=0)
    grade = composite.apply(lambda s: min(10, int(s // 10) + 1))
    return Scorecard(scores, base, stressed, wavg, worst, aggregated, final, trig, floors, weights, composite, grade, small)
