"""Command line: python -m econquest <command> [options]"""
from __future__ import annotations
import argparse
import os
import json
import sys
from pathlib import Path
import numpy as np
import pandas as pd
from .config import Settings
from .ingestion import load_universe
from .engine import run_pipeline
from .engine.pipeline import dumps, resolve_as_of
from .engine.stress import load_scenarios, compare, reverse_stress, single_factor_reverse, SINGLE_FACTORS, summarise_shocks
from .validation import backtest_history
from .validation.backtests import synthetic_history
from .persistence import Store
from .presentation import render_dashboard, serve

HERE = Path(__file__).resolve().parent.parent
# ECONQUEST_HOME points at the folder holding data/ and outputs/ when the package is installed
# outside that folder (the macOS installer sets it); otherwise the source checkout is used.
HOME_DIR = Path(os.environ.get("ECONQUEST_HOME", HERE))
DEFAULT_DATA = HOME_DIR / "data"
DEFAULT_OUT = HOME_DIR / "outputs"


TOKEN_ENV = "ECONQUEST_SHEETS_TOKEN"
KEYCHAIN_SERVICE = "econquest-sheets"


TOKEN_REMOVED_MSG = (f"--token was removed (it put the token in the process list and shell history). Use --write with "
                     f"${TOKEN_ENV} or the macOS Keychain item '{KEYCHAIN_SERVICE}' (security add-generic-password -s "
                     f"{KEYCHAIN_SERVICE} -a \"$USER\" -w), or --token-file PATH")


class _RemovedToken(argparse.Action):
    """Refuses the removed `--token VALUE` / `--token=VALUE` (EQ-C-0076). The value is never echoed."""

    def __call__(self, parser, namespace, values, option_string=None):
        parser.error(TOKEN_REMOVED_MSG)


def _token_args(p):
    """Sheets credential options for a subcommand that can write the workbook (EQ-C-0002)."""
    p.add_argument("--write", action="store_true", help=f"write the tab(s) to the live workbook, with the token from ${TOKEN_ENV} or the macOS Keychain item '{KEYCHAIN_SERVICE}' (or --token-file). Without --write, or an explicit --token-file, the plan is only saved")
    p.add_argument("--token-file", help="file holding the Google Sheets OAuth token; giving it means write (it wins over the env var and Keychain)")
    # --token VALUE was removed in 0.3 (EQ-C-0076, threat model T1). It stays declared, hidden, only to be refused with a
    # pointer to the safe options: undeclared, argparse would take `--token X` as a prefix of --token-file and try to
    # open a file named after the token (and print that name in the error).
    p.add_argument("--token", dest="removed_token", nargs="?", action=_RemovedToken,
                   default=argparse.SUPPRESS, help=argparse.SUPPRESS)
    p.add_argument("--dry-run", action="store_true", help="save the plan JSON only: never look up a token or call Sheets, even with --write or --token-file")


def _keychain_token() -> str | None:
    """macOS Keychain: `security find-generic-password -s econquest-sheets -w`. Any failure means no token."""
    import shutil
    import subprocess
    exe = shutil.which("security")
    if not exe:
        return None
    try:
        r = subprocess.run([exe, "find-generic-password", "-s", KEYCHAIN_SERVICE, "-w"], capture_output=True, text=True, timeout=10)
    except (OSError, subprocess.SubprocessError):
        return None
    tok = (r.stdout or "").strip()
    return tok if r.returncode == 0 and tok else None


def _read_token_file(path: str) -> str:
    try:
        tok = Path(path).expanduser().read_text(encoding="utf-8").strip()
    except OSError as e:
        raise SystemExit(f"cannot read --token-file {path}: {e.strerror}") from None
    if not tok:
        raise SystemExit(f"--token-file {path} is empty")
    return tok


def resolve_token(args) -> str | None:
    """The Sheets OAuth token, or None (the command then only saves its plan). Ambient credentials never cause a
    live write on their own: the user must ask for it.
      1. --token-file PATH (explicit: means write; beats the env var and Keychain)
      2. --write: $ECONQUEST_SHEETS_TOKEN, then the macOS Keychain item 'econquest-sheets'; none found is an error
      3. otherwise None, and neither the env var nor the Keychain is looked at.
    The old `--token VALUE` is refused by the parser (EQ-C-0076)."""
    path = getattr(args, "token_file", None)
    if path:
        return _read_token_file(path)
    if not getattr(args, "write", False):
        return None
    tok = os.environ.get(TOKEN_ENV, "").strip() or _keychain_token()
    if not tok:
        raise SystemExit(f"--write needs a Sheets token: set ${TOKEN_ENV}, add the Keychain item "
                         f"(security add-generic-password -s {KEYCHAIN_SERVICE} -a \"$USER\" -w) or pass --token-file")
    return tok


def _load(args):
    s = Settings.load(Path(args.data) / "assumptions.json", paths=getattr(args, "paths", None), seed=getattr(args, "seed", None),
                      scenario_override=getattr(args, "override", None))
    if getattr(args, "no_sobol", False):
        s.use_sobol = False
    vintage = getattr(args, "vintage", None)
    if vintage and getattr(args, "live_markets", False):
        raise SystemExit("--vintage replays frozen inputs; it cannot be combined with --live-markets")
    if vintage:
        u = load_universe(args.data, live_markets=False, vintage=vintage)
        rp = (getattr(u, "provenance", None) or {}).get("replay") or {}
        print(f"Replaying vintage {rp.get('vintage_id', vintage)} (inputs_hash {rp.get('inputs_hash', '?')})")
        if rp.get("drift"):
            print(f"warning: files not frozen with the vintage changed since it was applied, so this is not an exact replay: {', '.join(map(str, rp['drift']))}", file=sys.stderr)
    else:
        u = load_universe(args.data, live_markets=getattr(args, "live_markets", False))
    return u, s


NO_PRICES_MSG = ("No price history: build data/market_history/prices.csv from official FX (BIS/ECB) first: "
                 "`econquest prices --start 2023-10-18`, then `--apply` (docs/runbooks/A-official-fx.md; EQ-A-0054).")


def _stamp_as_of(s: Settings, as_of=None) -> Settings:
    """Settings carrying the run date as settings["as_of"] (HO-20261024-B-C-009), so a scenario's file-based GPR shock
    (gpr.expand_gpr_shocks) knows the date when Scenario.apply runs, before run_pipeline stamps it. Same rule as
    run_pipeline: --as-of, else settings["as_of"], else today; the numbers of the other scenarios do not change."""
    return s.copy_with(as_of=resolve_as_of(as_of if as_of is not None else s.get("as_of")))


def _as_of_arg(text: str) -> str:
    """argparse type for --as-of: a YYYY-MM-DD date, normalised. A year before 1000 is refused: strftime writes it
    with fewer than four digits ("1-01-01"), which resolve_as_of then read as 2001-01-01 (SEC-C-009)."""
    try:
        out = pd.Timestamp(text).strftime("%Y-%m-%d")
    except (ValueError, TypeError):
        out = ""
    if len(out) != 10 or not out[:4].isdigit():
        raise argparse.ArgumentTypeError(f"not a date (YYYY-MM-DD): {text!r}") from None
    return out


def _vintage_date(u) -> str | None:
    """The date of the replayed vintage (vintage ids start YYYY-MM-DD), or None when the universe is not a replay."""
    vid = str(((getattr(u, "provenance", None) or {}).get("replay") or {}).get("vintage_id") or "")
    try:
        return _as_of_arg(vid[:10]) if len(vid) >= 10 and vid[4] == "-" and vid[7] == "-" else None
    except argparse.ArgumentTypeError:
        return None


def _layer2_vendor_usage(res, out_dir, output: str) -> None:
    """HO-20261025-C-B-005 (EQ-C-0131): one vendor usage-log row per vendor whose CDS curve layer 2 used in this run
    (layer2_bayesian.record_vendor_use; nothing is written on the default "profile" source or when every curve fell
    back). A log failure is printed, never hidden, and never stops the run."""
    from .engine import layer2_bayesian as L2
    try:
        for row in L2.record_vendor_use(res.country, Path(out_dir), output):
            print(f"vendor usage: {row.get('vendor')} {row.get('dataset')} logged ({row.get('purpose')})")
    except Exception as e:                            # noqa: BLE001 - the run happened; say the log row is missing
        print(f"vendor usage: WARNING usage log row not written ({type(e).__name__})", file=sys.stderr)


def cmd_run(args):
    u, s = _load(args)
    as_of = getattr(args, "as_of", None)
    res = run_pipeline(u, s, label=args.label, as_of=as_of, market_dir=args.data)   # HO-20261024-B-C-002
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    store = Store(out / "store"); store.save_rulebook(u.rulebook); store.save_run(res, keep_paths=not args.no_paths)
    res.country.to_csv(out / "country_risk.csv"); res.positions.to_csv(out / "positions.csv")
    res.mc.contributions.to_csv(out / "contributions.csv"); res.arbitrage.to_csv(out / "arbitrage.csv", index=False)
    res.correlation.round(4).to_csv(out / "latent_correlation.csv")
    (out / "run_latest.json").write_text(dumps(res.to_dict()))
    _layer2_vendor_usage(res, out, f"run {res.run_id}")          # HO-20261025-C-B-005: once per run, base only
    # trade-idea log (HO-20261023-B-C-010): base run only; a --vintage replay is a past date and the log only moves forward
    if not str(args.label).startswith("stress-") and not getattr(args, "vintage", None):
        from .engine.garch import load_prices
        from .validation import idea_log
        px = u.prices if getattr(u, "prices", None) is not None else load_prices(args.data)
        _idea_hook("run", idea_log.log_run, res, u, s, px, out)
    stress = None; bt = None
    if args.stress:
        stress = {}
        s = _stamp_as_of(s, as_of)                        # HO-20261024-B-C-009: GPR file shocks need the run date
        scen = load_scenarios(Path(args.data) / "scenarios.json")
        keys = [k.upper() for k in args.scenario] if getattr(args, "scenario", None) else [k for k, sc in scen.items() if sc.kind != "historical"]
        for k in keys:
            sc = scen[k]
            u2, s2 = sc.apply(u, s)
            r2 = run_pipeline(u2, s2, label=f"stress-{k}", paths=args.stress_paths, as_of=as_of, market_dir=args.data)
            store.save_run(r2, keep_paths=False)
            stress[k] = {"name": sc.name, "description": sc.description, "comparison": compare(res, r2)}
        (out / "stress.json").write_text(dumps(stress))
    if args.backtest:
        hist = pd.read_csv(Path(args.data) / "backtest_history.csv") if (Path(args.data) / "backtest_history.csv").exists() else \
            synthetic_history(res.mc.losses, res.metrics["var99_mm"], res.metrics["es99_mm"], as_of=res.settings.get("as_of"))   # VF-006: replayable dates
        bt = backtest_history(hist, alpha=0.99); (out / "backtest.json").write_text(dumps(bt))
    from .presentation.mc_band import load_book_limits    # EQ-C-0055: limit verdicts with the MC band on the dashboard
    limits = load_book_limits(args.data)
    (out / "dashboard.html").write_text(render_dashboard(res.to_dict(), stress, bt, limits=limits))
    print(dumps(res.summary()))
    if stress:
        for k, v in stress.items():
            c = v["comparison"]
            print(f"Scenario {k} {v['name']}: ES99 {c['es99_mm']['base']:.1f} -> {c['es99_mm']['stress']:.1f} ({c['es99_mm']['change_pct']:+.1f}%), "
                  f"L-VaR99 {c['lvar99_mm']['stress']:.1f}, liquidity cost {c['liquidity_cost99_mm']['change_pct']:+.1f}%, moved to Crisis {c['share_to_crisis']*100:.0f}%")
    if bt:
        print(f"Backtest: {bt['verdict']} (Kupiec p={bt['kupiec']['p_value']:.3f}, Christoffersen cc p={bt['christoffersen']['p_value_cc']:.3f}, Z2={bt['acerbi_szekely']['Z2']:.3f}, zone {bt['basel_zone']})")
    print(f"Outputs in {out}")
    from .presentation.dashboard import run_headline   # EQ-C-0048: the decision numbers, with units, as the last line
    print(run_headline(res.summary(), limits=limits))


def cmd_stress(args):
    u, s = _load(args)
    as_of = getattr(args, "as_of", None)                  # HO-20261025-B-C-010 (EQ-C-0126): --as-of, as cmd_run
    s = _stamp_as_of(s, as_of)                            # HO-20261024-B-C-009
    scen = load_scenarios(Path(args.data) / "scenarios.json")
    base = run_pipeline(u, s, label="base", paths=args.paths, as_of=as_of, market_dir=args.data)   # HO-20261024-B-C-002
    rows = []
    for k in (args.scenario or list(scen)):
        sc = scen[k.upper()]
        u2, s2 = sc.apply(u, s, scale=args.scale)
        r2 = run_pipeline(u2, s2, label=f"stress-{k}", paths=args.paths, as_of=as_of, market_dir=args.data)
        cmp_ = compare(base, r2)
        rows.append({"scenario": sc.key, "name": sc.name, "kind": sc.kind, "scale": args.scale, **{m: cmp_[m]["stress"] for m in ("var99_mm", "es99_mm", "lvar99_mm", "expected_loss_mm")},
                     **{m + "_pct": cmp_[m]["change_pct"] for m in ("var99_mm", "es99_mm")}, "to_crisis": cmp_["share_to_crisis"], "mean_pd_pp": cmp_["mean_pd_default_change_pp"]})
        print(f"\n== Scenario {sc.key}: {sc.name} ({sc.kind}, scale {args.scale})\n{sc.description}")
        print(dumps(cmp_))
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    table = pd.DataFrame(rows); table.to_csv(out / "scenario_library.csv", index=False)
    pd.set_option("display.width", 220)
    print(f"\nBase VaR99 {base.metrics['var99_mm']:.1f}, ES99 {base.metrics['es99_mm']:.1f} $mm ({base.metrics['paths']} paths)")
    print(table.round(3).to_string(index=False)); print(f"Written {out / 'scenario_library.csv'}")


def cmd_scenarios(args):
    """List the scenario library (data/scenarios.json) with its shocks."""
    scen = load_scenarios(Path(args.data) / "scenarios.json")
    for sc in scen.values():
        print(f"{sc.key:10s} {sc.name} [{sc.kind}]\n    {sc.description}\n    source: {sc.source or 'n/a'}")
        if args.shocks:
            for line in summarise_shocks(sc.shocks): print(f"      - {line}")


RS_MEASURES = ("var99_mm", "es99_mm", "lvar99_mm")   # HO-20261025-B-C-005 (EQ-B-0097): every book measure with a tail limit


def _rs_no_breach_up_to(kind: str, r: dict, scale_max: float) -> str:
    """'no breach up to <max>' in the unit the user reads: scale of the scenario, or the factor's own unit."""
    if kind == "scenario":
        return f"no breach up to scale {scale_max:g}"
    f = SINGLE_FACTORS.get(r.get("factor"), {})
    top = f.get("max", scale_max)
    if f.get("shocks") and f["shocks"][0]["op"] == "mul":
        top = 1 + (f["shocks"][0]["value"] - 1) * top
    return f"no breach up to {top:g} {f.get('unit', r.get('unit', ''))}".rstrip()


def _rs_first(recs: list[dict]) -> tuple[list[str], float | None]:
    """The measure(s) that breach first among one scenario's or factor's records (smallest breach scale; ties all
    named), and that scale. ([], None) when none breaches."""
    hit = [(float(r["breach_scale"]), r["measure"]) for r in recs if r.get("breach_scale") is not None]
    if not hit:
        return [], None
    lo = min(sc for sc, _ in hit)
    return [m for sc, m in hit if sc <= lo + 1e-12], lo


def cmd_reverse_stress(args):
    """Reverse stress (roadmap 3.4): the smallest severity of each scenario, and of each single factor, that breaches a book limit.
    HO-20261025-B-C-005 (EQ-B-0097): by default every tail measure (var99_mm, es99_mm, lvar99_mm) against its own book
    limit, with the first measure to breach flagged per scenario and factor, because VaR99 alone can read "no breach"
    while ES99 and L-VaR99 break. --measure runs a single one."""
    from .engine import limits as LM
    u, s = _load(args)
    s = _stamp_as_of(s, getattr(args, "as_of", None))     # HO-20261024-B-C-009: reverse_stress applies scenarios with s
    lim = LM.load_limits(Path(args.data) / "limits.json")
    scen = load_scenarios(Path(args.data) / "scenarios.json")
    paths = args.paths or 20000
    measures = [args.measure] if args.measure else list(RS_MEASURES)
    base = run_pipeline(u, s, label="rs-base", paths=paths, market_dir=args.data)   # HO-20261025-B-C-006: market_dir
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    limits = {m: float(lim["book"][m]) for m in measures}
    bases = {m: float(base.metrics[m]) for m in measures}
    # "measure"/"limit"/"base" keep the single-measure shape (first measure) for older readers; "measures", "limits",
    # "bases" and "summary" carry all of them. Every scenario / factor record names its own "measure".
    results = {"measure": measures[0], "limit": limits[measures[0]], "paths": paths, "base": bases[measures[0]],
               "measures": measures, "limits": limits, "bases": bases, "scenarios": [], "factors": [], "summary": []}
    print(f"Reverse stress on {', '.join(measures)} ({paths} paths): "
          + "; ".join(f"{m} base {bases[m]:.2f} vs limit {limits[m]:.2f} $mm" for m in measures))

    def report(kind: str, key: str, label: str, recs: list[dict], scale_max: float, unit: str):
        for m, r in zip(measures, recs):
            r.setdefault("measure", m)
            if r["breach_scale"] is not None:
                where = (f"scale {r['breach_scale']:.3f} of the scenario" if kind == "scenario"
                         else f"{r.get('breach_size', r['breach_scale']):.3g} {r.get('unit', unit)}")
                print(f"  -> {m} (limit {limits[m]:.1f}): breaches at {where} ({m} {r.get('value_at_breach', r.get('base', float('nan'))):.1f})")
                if kind == "scenario":
                    for line in r.get("shocks_at_breach") or []: print(f"       {line}")
            else:
                print(f"  -> {m} (limit {limits[m]:.1f}): {_rs_no_breach_up_to(kind, r, scale_max)} "
                      f"({m} {r.get('value_at_max', float('nan')):.1f} at the largest move searched)")
        first, at = _rs_first(recs)
        for r in recs:
            r["first_breach"] = r["measure"] in first
        if first:
            how = f"scale {at:.3f}" if kind == "scenario" else f"{next(r for r in recs if r['measure'] in first).get('breach_size', at):.3g} {unit}"
            print(f"  => first to breach: {' and '.join(first)} at {how}")
        else:
            print(f"  => no measure breaches: {_rs_no_breach_up_to(kind, recs[0] if recs else {}, scale_max)}")
        results["summary"].append({"kind": kind, "key": key, "label": label, "first_breach": first, "first_scale": at,
                                   "measures": {r["measure"]: (r["status"] if r["breach_scale"] is not None
                                                               else _rs_no_breach_up_to(kind, r, scale_max)) for r in recs}})

    keys = [k.upper() for k in args.scenario] if args.scenario else list(scen)
    if not args.factors_only:
        for k in keys:
            print(f"\n== Scenario {k}: {scen[k].name}")
            recs = [reverse_stress(u, s, scen[k], lim, m, paths, scale_max=args.scale_max, base=base, log=print, market_dir=args.data)
                    for m in measures]
            results["scenarios"].extend(recs)
            report("scenario", k, scen[k].name, recs, args.scale_max, "x scenario")
    if not args.scenarios_only:
        for f in (args.factor or list(SINGLE_FACTORS)):
            print(f"\n== Factor {f}: {SINGLE_FACTORS[f]['label']}")
            recs = [single_factor_reverse(u, s, lim, f, m, paths, base=base, log=print, market_dir=args.data) for m in measures]
            results["factors"].extend(recs)
            report("factor", f, SINGLE_FACTORS[f]["label"], recs, SINGLE_FACTORS[f]["max"], SINGLE_FACTORS[f]["unit"])
    (out / "reverse_stress.json").write_text(dumps(results))
    rows = [{"kind": "scenario", "key": r["scenario"], "label": r.get("scenario_name", r["scenario"]), "measure": r["measure"], "breach_scale": r["breach_scale"], "breach_size": r["breach_scale"], "unit": "x scenario",
             "status": r["status"] if r["breach_scale"] is not None else _rs_no_breach_up_to("scenario", r, args.scale_max), "first_breach": r["first_breach"]} for r in results["scenarios"]] + \
           [{"kind": "factor", "key": r["factor"], "label": r["label"], "measure": r["measure"], "breach_scale": r["breach_scale"], "breach_size": r.get("breach_size"), "unit": r["unit"],
             "status": r["status"] if r["breach_scale"] is not None else _rs_no_breach_up_to("factor", r, 0), "first_breach": r["first_breach"]} for r in results["factors"]]
    pd.DataFrame(rows).to_csv(out / "reverse_stress.csv", index=False)
    print(f"\nWritten {out / 'reverse_stress.json'} and reverse_stress.csv")


def cmd_arbitrage(args):
    u, s = _load(args)
    res = run_pipeline(u, s, paths=20000, market_dir=args.data)
    cols = ["id", "platform", "country", "side", "yes_price", "model_p_res", "net_edge_pp", "kelly", "stake_k", "expected_profit_k", "divergence_flag"]
    pd.set_option("display.width", 200)
    print(res.arbitrage.sort_values("net_edge_pp", ascending=False)[cols].round(3).to_string(index=False))


def cmd_backtest(args):
    hist = pd.read_csv(args.history)
    if "var_next" in hist.columns:                      # a forecast record: use the rows that had a forecast for the day
        from .validation.record import record_for_backtest
        hist = record_for_backtest(hist)
    hist = hist.dropna(subset=["loss", "var", "es"])
    if len(hist) < 20:
        raise SystemExit(f"Only {len(hist)} periods with a realised loss and a forecast; the tests need at least 20 (250 for a meaningful Basel zone).")
    print(dumps(backtest_history(hist, alpha=args.alpha)))


def cmd_record(args):
    """Append today's row to data/forecast_record.csv: realised loss of the book, next-day GARCH-DCC VaR/ES, 12-month MC VaR/ES."""
    import warnings
    from .engine.garch import load_prices
    from .validation.record import take_record, load_record, record_for_backtest
    warnings.filterwarnings("ignore", category=RuntimeWarning)
    u, s = _load(args)
    px = load_prices(args.data)
    if px is None:
        raise SystemExit(NO_PRICES_MSG)
    if args.backfill:
        from .validation.record import backfill_record
        backfill_record(u, s, px, Path(args.data), days=args.backfill, step=args.step)
    else:
        row = take_record(u, s, px, Path(args.data), run_mc=not args.no_mc)
        from .validation import idea_log                  # mark open ideas to the record date; not on --backfill (point in time)
        _idea_hook("record", idea_log.mark_log, Path(args.out or "outputs"), px, row["date"], s)
    rec = load_record(Path(args.data) / "forecast_record.csv")
    bt = record_for_backtest(rec)
    print(f"Record: {len(rec)} rows -> {Path(args.data) / 'forecast_record.csv'}")
    if len(bt) >= 20:
        print(dumps(backtest_history(bt, alpha=0.99)))
    else:
        print(f"{len(bt)} rows with a forecast to test; the backtests start at 20 rows and the Basel zone is meaningful from 250.")
    if args.token:
        from .presentation.sheets_publish import apply_plan
        from .presentation.record_publish import record_plan
        r = apply_plan(record_plan(rec), args.spreadsheet_id, args.token)
        print(f"Wrote {r.get('totalUpdatedCells')} cells to the Forecast Record tab")


def _idea_hook(job: str, fn, *a) -> None:
    """Trade-idea log from a daily job (HO-20261023-B-C-010). Tier 3, illustrative: a failure warns, never fails the job."""
    try:
        fn(*a)
    except Exception as e:                             # noqa: BLE001
        print(f"warning: trade-idea log not updated by {job}: {type(e).__name__}: {e}", file=sys.stderr)


def cmd_ideas(args):
    """Trade-idea log (EQ-B-0038, GOV-032; Tier 3): `log` advances outputs/idea_log.csv by an archived base run, `mark`
    marks open ideas to a trading day, `report` prints outputs/idea_report.md, `page` writes the trade-ideas page."""
    if args.ideas_cmd == "page":                       # HO-20261025-B-C-011: presentation only, no engine load
        import datetime as _dt
        from .presentation.ideas_page import build_ideas_page
        try:
            r = build_ideas_page(args.out, args.data, args.dest or Path(args.out) / "trade-ideas", _dt.date.fromisoformat(args.as_of))
        except FileNotFoundError as e:
            raise SystemExit(f"ideas page: {e}") from None
        print(f"trade ideas {args.as_of}: {r['items'][0]['html']} ({len(r['activations'])} activations, run {r['run_id']}, "
              f"manifest {r['manifest']}). Register it with `econquest editorial draft --kind trade_ideas --file ...`.")
        return
    import re
    from .engine.garch import load_prices
    from .validation import idea_log
    out = Path(args.out)
    if args.ideas_cmd == "report":
        md = out / "idea_report.md"
        if not (out / "idea_log.csv").exists() or not md.exists():
            raise SystemExit(f"No trade-idea log in {out}: run `econquest ideas log` (or `econquest run`) first.")
        print(md.read_text(encoding="utf-8"))
        return
    u, s = _load(args)
    px = load_prices(args.data)
    if args.ideas_cmd == "mark":
        if px is None:
            raise SystemExit(NO_PRICES_MSG)
        from .validation.record import complete_date, _weekdays
        as_of = args.as_of or complete_date(_weekdays(px))      # the trading day the forecast record uses
        idea_log.mark_log(out, px, as_of, s)
        return
    store = Store(out / "store")
    if args.run_id and not re.fullmatch(r"[A-Za-z0-9][A-Za-z0-9_.-]*", args.run_id):    # a file name in store/archive, no path
        raise SystemExit(f"not a run id: {args.run_id!r}")
    try:
        d = store.load(args.run_id) if args.run_id else store.latest("base")
    except FileNotFoundError:
        raise SystemExit(f"Run {args.run_id} is not archived in {out / 'store'} (econquest runs lists them).") from None
    if d is None:
        raise SystemExit(f"No base run archived in {out / 'store'}: run `econquest run` first.")
    label = str(d["summary"].get("label") or "")
    if label.startswith("stress-"):
        raise SystemExit(f"Run {d['summary']['run_id']} is a stress run ({label}); the trade-idea log takes base runs only.")
    idea_log.log_run(d, u, s, px, out)


def cmd_prices(args):
    """Official FX history for data/market_history/prices.csv (EQ-A-0054, HO-20261024-A-C-009): pull BIS WS_XRU / ECB EXR,
    save the raw vintage and stage the build; --apply installs it (only once Team B has accepted HO-20261024-A-B-004).
    The GOOGLEFINANCE import (--sheet-json, Sheets API values of the Market History tab) is retired: it is refused
    unless ECONQUEST_ALLOW_GOOGLEFINANCE=1, and then writes only the research copy, never prices.csv."""
    from .ingestion import market_history as MH
    if args.sheet_json:
        if os.environ.get(MH.GOOGLEFINANCE_OPT_IN_ENV) != "1":
            raise SystemExit("econquest prices --sheet-json is retired (GOOGLEFINANCE data is not for trading or professional use; "
                             "Sam 2026-10-24, EQ-A-0054). Run `econquest prices --start 2023-10-18` for the official FX history. "
                             f"Research-only import: set {MH.GOOGLEFINANCE_OPT_IN_ENV}=1 (writes the research copy, never prices.csv).")
        out, summary = MH.update_prices_from_sheet_json(args.sheet_json, args.data)
        print(f"{out}: {summary}")
        return
    res = MH.build_official_fx_history(args.data, args.start, args.end, apply=args.apply)
    print(dumps({k: v for k, v in res.items() if not isinstance(v, dict)}))
    if not args.apply:
        print("Staged only: prices.csv unchanged. Install with --apply once Team B has accepted HO-20261024-A-B-004.")


CRAG_VALUE_FLAGS = ("file", "panel_dir", "source_vintage", "iso_map",     # crag_update.main's flags (HO-20261025-A-C-003)
                    "expect_live_sha256", "expect_iso_map_sha256")      # bind --apply to a dry run (HO-20261025-A-C-014, SEC-C-017 R51)
CRAG_SWITCHES = ("apply", "fetch", "json")


def crag_argv(args) -> list[str]:
    """The argv for crag_update.main, rebuilt from the same flags parsed here (argparse REMAINDER cannot start with an
    option, so `crag update` declares Team A's flags itself and passes each one straight through unchanged)."""
    out: list[str] = []
    for k in CRAG_VALUE_FLAGS:                          # SEC-C-017 L5 (EQ-C-0165): --flag=value, so a value that
        if getattr(args, k, None) is not None:          # starts with "-" stays a value for Team A's parser
            out.append(f"--{k.replace('_', '-')}={getattr(args, k)}")
    return out + [f"--{k}" for k in CRAG_SWITCHES if getattr(args, k, False)]


def cmd_crag(args):
    """`econquest crag update ...`: Team A's crag_update.main with the flags passed straight through
    (HO-20261025-A-C-003). Exit 0 done, 1 refused, 2 --fetch unavailable."""
    from .ingestion.crag_update import main as crag_main
    if getattr(args, "panel_dir", None) is None and getattr(args, "data", None):   # SEC-C-017 L5 (EQ-C-0165): the
        args.panel_dir = str(Path(args.data) / "panel")                            # same panel the GUI shows
    rc = crag_main(crag_argv(args))
    if rc:
        raise SystemExit(rc)


def cmd_runs(args):
    """List archived runs with their code and data versions."""
    store = Store(Path(args.out) / "store")
    rows = []
    for r in store.runs(limit=args.limit):
        s = r["summary"]; m = s.get("metrics", {}); v = s.get("versions", {})
        rows.append({"run_id": r["run_id"], "label": r["label"], "created": r["created_at"][:19], "var99": m.get("var99_mm"), "es99": m.get("es99_mm"),
                     "regime": s.get("global_regime"), "code": v.get("code_hash", ""), "data": v.get("data_hash", ""),
                     "vintage": v.get("vintage_id") or "", "inputs": v.get("inputs_hash") or ""})
    print(pd.DataFrame(rows).round(2).to_string(index=False) if rows else "No runs archived yet.")


def _wb_series_rows(wbh: pd.DataFrame, code: str) -> int:
    """Rows of `code` in worldbank_history.csv with a value (HO-20261025-A-C-010)."""
    if "series" not in wbh.columns:
        return 0
    m = wbh["series"].astype(str) == code
    if "value" in wbh.columns:
        m &= pd.to_numeric(wbh["value"], errors="coerce").notna()
    return int(m.sum())


def cmd_fit_hazard(args):
    """Recalibrate the layer-1 hazard model on a sovereign default panel (roadmap 2.3).

    --panel <csv>        a ready country-year panel with the feature columns and `event`
    --build-panel        build it from WEO (and World Bank) history + the default episode table
    --fetch              pull every WEO release and World Bank series first (ingestion.panel_history: staged, resumable,
                         point in time; needs network); an incomplete pull exits 1 and leaves the history files untouched
    --resume RUN_ID      with --fetch: resume that staged run, refetching only the units still missing
    --defaults <file>    an episode CSV (default data/panel/sovereign_defaults.csv, including import_crag output) or the
                         CRAG workbook / Valet CSV (2026 long layout)
    --apply              propose (econquest change) the fitted coefficients for assumptions.json (layer1_fitted) and the switch
                         of layer1.mode to "fitted" when hazard_panel.gate_check clears (OOS AUC >= --min-auc, >= --min-events
                         events, Brier strictly below the trailing base rate); needs --author, and the change lands only after
                         approve + apply"""
    from .validation import hazard_panel as hp
    if args.apply and not args.author:
        raise SystemExit("fit-hazard --apply proposes a Tier 1 change and needs --author NAME")
    if (args.resume or args.weo_vintages) and not args.fetch:
        raise SystemExit("--resume and --weo-vintages only apply with --fetch")
    data = Path(args.data); out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    features = [f.strip() for f in args.features.split(",")] if args.features else None
    source = {}
    if args.panel and not args.build_panel:
        panel = pd.read_csv(args.panel, dtype={"iso": str})
        source["panel_file"] = str(args.panel)
    else:
        dfile = Path(args.defaults) if args.defaults else data / "panel" / "sovereign_defaults.csv"
        events = hp.load_events(dfile)
        end = args.end if args.end is not None else int(max(events["end"].max(), events["start"].max())) - 1
        source["default_episodes"] = f"{dfile.name} ({len(events)} spells, {events['iso'].nunique()} countries)"
        hist = data / "panel"
        hist.mkdir(parents=True, exist_ok=True)
        if args.fetch:
            from .ingestion import panel_history as ph
            try:
                vint = ph._parse_vintage_arg(args.weo_vintages) if args.weo_vintages else None
                m = ph.fetch_history(hist, weo_vintages=vint, run_id=args.resume, log=print)
            except ph.IncompleteFetchError as e:
                print(f"INCOMPLETE: {e}", file=sys.stderr)
                for unit in e.missing:
                    print(f"  {unit}: {e.manifest['units'][unit].get('error', '')}", file=sys.stderr)
                raise SystemExit(1) from None
            except (ValueError, FileNotFoundError) as e:
                raise SystemExit(f"fit-hazard --fetch: {e}") from None
            fin = m.get("final", {})
            source["panel_history"] = (f"run {m.get('run_id')}, panel vintage {m.get('panel_vintage', '(not saved)')}; "
                                       + ", ".join(f"{k} sha256 {v['sha256'][:16]}" for k, v in fin.items()))
        weo_path = hist / "weo_history.csv" if (hist / "weo_history.csv").exists() else data / "live" / "raw_weo.csv"
        if not weo_path.exists():
            raise SystemExit("no WEO history: run with --fetch on a machine that reaches api.imf.org, or run `econquest fetch` first")
        weo = pd.read_csv(weo_path, dtype={"iso": str, "series": str, "vintage": str})
        wbh = pd.read_csv(hist / "worldbank_history.csv", dtype={"iso": str, "series": str}) if (hist / "worldbank_history.csv").exists() else None
        source["weo_history"] = f"{weo_path.name} ({weo['iso'].nunique()} economies, {int(weo['period'].min())}-{int(weo['period'].max())})"
        source["worldbank_history"] = f"worldbank_history.csv ({wbh['iso'].nunique()} economies)" if wbh is not None else "none (World Bank features not available)"
        if features is None:
            # HO-20261025-A-C-010 (EQ-C-0103): a World Bank predictor joins only when its series has rows; a history without
            # PV.EST gave an all-NaN pitf_instability and panel_from_long dropped every row (RCA-A-003).
            wb_feats = [f for f in ("stfx_debt_reserves", "reserves_months_imports", "pitf_instability")
                        if wbh is not None and _wb_series_rows(wbh, hp.PANEL_FEATURES[f][1])]
            features = list(hp.DEFAULT_FEATURES) + wb_feats
            left = [f for f in ("stfx_debt_reserves", "reserves_months_imports", "pitf_instability") if f not in wb_feats]
            if wbh is not None and left:
                print("fit-hazard: World Bank predictors left out (no rows in worldbank_history.csv): "
                      + ", ".join(f"{f} ({hp.PANEL_FEATURES[f][1]})" for f in left))
                source["worldbank_features_left_out"] = ", ".join(left)
        panel = hp.panel_from_long(weo, wbh, events, features=features, start=args.start, end=end, forecast_cutoff=end)
        panel.to_csv(hist / "hazard_panel.csv", index=False)
        print(f"panel: {len(panel):,} country-years at risk, {int(panel['event'].sum())} default starts, {panel['iso'].nunique()} countries -> {hist / 'hazard_panel.csv'}")
    res = hp.fit_and_validate(panel, features=features, oos_start=args.oos_start)
    res.panel_source = source
    gate = hp.gate_check(res, args.min_auc, args.min_events); ok = gate["cleared"]
    rep = hp.write_report(res, args.report or (data.parent / "docs" / "validation" / "hazard-fit-report.md"), panel=panel, gate=gate,
                          notes=["Pilot panels built from the 18-country live vintage are too thin for production use; the full panel needs `--fetch`."] if panel["iso"].nunique() < 40 else None)
    (out / "hazard_fit.json").write_text(dumps(res.fitted_block()))
    o = res.out_of_sample
    print(dumps({"coef": res.coef, "intercept": res.intercept, "in_sample_auc": res.in_sample["auc"], "out_of_sample": o}))
    print(f"report: {rep}")
    print(f"gate: {hp.gate_summary(gate)}")
    if args.apply:
        # A layer-1 recalibration is a Tier 1 change: --apply proposes it through `econquest change` (EQ-C-0023)
        # instead of writing assumptions.json, so it needs an approver (or a self-approval under an EXC) before it lands.
        from .ops import approvals as ap
        patch = {"/layer1_fitted": res.fitted_block()}
        if ok:
            patch["/layer1/mode"] = "fitted"
        else:
            print(f"NOT proposing the switch to fitted: gate {hp.gate_summary(gate)}; proposing the coefficients under layer1_fitted only")
        try:
            prop = ap.propose(data, "assumptions.json", json.loads(dumps(patch)), args.author,
                              f"fit-hazard: OOS AUC {o.get('auc', float('nan')):.3f}, {res.events} events", allow_new_keys=True,
                              allow_type_change=True)   # the fitted block is regenerated wholesale
        except ap.ApprovalError as e:
            raise SystemExit(f"fit-hazard --apply: {e}") from None
        print(f"proposed {prop['id']} (tier {prop['tier']}): approve with `econquest change approve {prop['id']} --approver NAME` "
              f"(or --self-approved --exc EXC-nnn), then `econquest change apply {prop['id']}`")


def cmd_cds(args):
    """CDS-implied PD term structure and bond relative value from data/cds_quotes.csv (roadmap 3.3)."""
    from .engine import cds
    from .engine.pipeline import run_pipeline
    u, s = _load(args)
    qpath = Path(args.data) / "cds_quotes.csv"
    quotes = pd.read_csv(qpath) if qpath.exists() else pd.DataFrame(columns=["country", "date", "tenor_y", "spread_bp", "recovery", "source"])
    if quotes.empty:
        print(f"no CDS quotes in {qpath}: add rows (country,date,tenor_y,spread_bp,recovery,source) and rerun")
        return
    cfg = s.get("cds", default={}) or {}
    r = run_pipeline(u, s, paths=min(s.paths, 20000), market_dir=args.data)
    pd12 = r.country["pd_default"]          # indexed by country name
    table = cds.cds_table(quotes, pd12, recovery=cfg.get("recovery", 0.4), rate=cfg.get("risk_free", 0.04), freq=int(cfg.get("frequency", 4)))
    rv = cds.eurobond_relative_value(u.portfolio, table)
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    table.to_csv(out / "cds_implied.csv", index=False); rv.to_csv(out / "cds_relative_value.csv", index=False)
    print(table.round(4).to_string(index=False)); print(); print(rv.round(1).to_string(index=False) if len(rv) else "no Eurobond or CDS positions with quotes")


def cmd_benchmark(args):
    """PD benchmarks (roadmap 2.6): model PD beside rating, spread, CDS and prediction-market probabilities; dated history and scoring."""
    from .validation import benchmarks as bm
    from .validation.hazard_panel import load_default_events
    from .engine import cds
    from .presentation.sheets_publish import save_plan, apply_plan
    u, s = _load(args)
    data = Path(args.data); out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    r = run_pipeline(u, s, paths=args.paths or min(s.paths, 20000), market_dir=args.data)
    cds_table = None
    qpath = data / "cds_quotes.csv"
    if qpath.exists():
        quotes = pd.read_csv(qpath)
        if len(quotes):
            cfg = s.get("cds", default={}) or {}
            cds_table = cds.cds_table(quotes, r.country["pd_default"], recovery=cfg.get("recovery", 0.4), rate=cfg.get("risk_free", 0.04), freq=int(cfg.get("frequency", 4)))
    versions = (r.summary() if callable(getattr(r, "summary", None)) else {}).get("versions", {}) if hasattr(r, "summary") else {}
    snap = bm.benchmark_snapshot(r.country, cds_table, as_of=args.as_of, versions=versions or u.provenance.get("versions", {}))
    hist = bm.append_history(data / "benchmarks.csv", snap)
    epath = data / "panel" / "sovereign_defaults.csv"
    events = load_default_events(epath) if epath.exists() else pd.DataFrame(columns=["iso", "start", "end"])
    as_of = snap["date"].iloc[0]                                   # the snapshot's as-of (from --as-of, else today once)
    scores = bm.score_sources(bm.outcomes(hist, events, as_of=as_of))      # VF-006 (HO-20261023-B-C-016): same date as today= before
    try:
        horizons = {h.strip(): int(h.strip()[:-1]) for h in args.horizons.split(",") if h.strip()}
    except ValueError:
        raise SystemExit(f"--horizons: expected a comma list like 12m,6m,3m, got {args.horizons!r}") from None
    full = bm.score_benchmarks(hist, events, as_of=as_of, horizons=horizons)
    paths = bm.write_benchmark_scores(full, out)
    print(f"benchmark scoring as of {as_of}: " + "; ".join(f"{k} {v}" for k, v in full.status.items()) + f" ({paths['scores']})")
    dis = bm.disagreement_table(snap)
    print(dis.round(4).to_string(index=False)); print()
    scored = int(scores["rows"].max()) if len(scores) else 0
    print(scores.round(4).to_string(index=False) if scored else f"no snapshot is 12 months old yet ({len(hist)} rows in data/benchmarks.csv); scoring starts then")
    plan = bm.benchmarks_plan(snap, scores, len(hist))
    save_plan(plan, out / "benchmarks_plan.json"); dis.to_csv(out / "benchmarks_snapshot.csv", index=False); scores.to_csv(out / "benchmarks_scores.csv", index=False)
    if args.token:
        print("Written:", apply_plan(plan, args.spreadsheet_id, args.token))


def cmd_hmm(args):
    from .engine.layer3_regime import GaussianHMM
    if args.series:
        X = pd.read_csv(args.series).select_dtypes(include=[np.number]).to_numpy()
    else:
        rng = np.random.default_rng(3)                       # demo: synthetic calm / stressed / crisis monthly data
        states = [0]
        P = np.array([[0.95, 0.04, 0.01], [0.10, 0.85, 0.05], [0.05, 0.20, 0.75]])
        for _ in range(239):
            states.append(rng.choice(3, p=P[states[-1]]))
        mu = np.array([[150, 0.5, 0.5], [500, 4, -3], [1500, 15, -10]]); sd = np.array([[60, 1.5, 2], [150, 3, 4], [500, 8, 6]])
        X = np.array([rng.normal(mu[s_], sd[s_]) for s_ in states])
    m = GaussianHMM().fit(X)
    st = m.decode(X)
    print(dumps({"means (spread bps, fx 3m %, reserves 3m %)": m.mu.round(2), "monthly_transition": m.A.round(3), "twelve_month_transition": m.transition_matrix_12m().round(3),
                 "last_state": GaussianHMM.labels(st[-1:])[0], "state_counts": {str(int(k)): int(v) for k, v in zip(*np.unique(st, return_counts=True))}}))


def _publish_guard(country) -> None:
    """HO-20261025-B-C-006 (EQ-B-0100): refuse (exit non-zero with Team B's message) a country table that carries vendor
    market data without a redistribution licence the register allows for client output. No-op while
    probability.market_term is off (no market_licence column)."""
    from .engine.layer2_bayesian import publish_guard
    from .ops.vendor_rehearse import refuse_simulated
    try:
        publish_guard(country)
        refuse_simulated(country, "Sheets publish")       # EQ-C-0146 (HO-20261026-A-C-003): SIMULATED never leaves
    except ValueError as e:
        raise SystemExit(f"publish refused: {e}") from None


def cmd_publish(args):
    """Run the pipeline and write every model output into the workbook as values (or save the plan)."""
    from .presentation.sheets_publish import full_plan, save_plan, apply_plan
    u, s = _load(args)
    res = run_pipeline(u, s, label="publish", market_dir=args.data)
    _publish_guard(res.country)                           # HO-20261025-B-C-006: before anything is written or sent
    # EQ-C-0122: the plan is built in one place (sheets_publish.full_plan), shared with `econquest export xlsx`
    plan = full_plan(res, u, s, args.data, args.out, mc_rows=args.mc_rows, ideas=getattr(args, "ideas", False),
                     rv=getattr(args, "rv", False), garch=not args.no_garch, econ=not args.no_econ)
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    save_plan(plan, out / "publish_plan.json")
    _layer2_vendor_usage(res, out, f"publish {getattr(res, 'run_id', '?')} -> {out / 'publish_plan.json'}")   # HO-20261025-C-B-005
    cells = sum(len(b["values"]) * max(len(r) for r in b["values"]) for b in plan)
    print(f"Publish plan: {len(plan)} ranges, about {cells:,} cells -> {out / 'publish_plan.json'}")
    from .presentation.licences import write_plan_licences       # EQ-C-0093: attribution + internal-only labels sidecar
    print(write_plan_licences(args.data, out / "publish_plan.json"))
    if args.token:
        r = apply_plan(plan, args.spreadsheet_id, args.token)
        print(f"Wrote {r.get('totalUpdatedCells')} cells to {args.spreadsheet_id}")
    else:
        # with --dry-run the command wrapper prints its own "Dry run: ..." line, so say it once (EQ-C-0048)
        print(("Plan saved" if getattr(args, "dry_run", False) else "No --write given: plan saved only (pass --write to write the workbook)") + ". Apply it with any Sheets client (values:batchUpdate, USER_ENTERED), or preview it first with `econquest publish-preview`.")


def cmd_export(args):
    """EQ-C-0122 (MVP M6): `econquest export xlsx` writes the workbook locally in the Sheets publish layout; offline, no
    token. --check reads it back and compares every cell with the plan and the headline figures with run_latest.json
    (exit 1 on any mismatch); --verify PATH checks an existing file without writing."""
    from .presentation import xlsx_export as X
    if args.verify:
        r = X.check(args.verify, out_dir=args.out, data_dir=args.data)
    else:
        r = X.export(args.out, args.data, args.dest, garch=not args.no_garch, econ=not args.no_econ, mc_rows=args.mc_rows,
                     check=args.check)
        if r.get("path"):
            print(f"Workbook: {r['path']} (run {r.get('run_id')}, as of {r.get('as_of')})")
        if r.get("licences"):
            print(r["licences"])
    for p in r["problems"]:
        print(f"problem: {p}", file=sys.stderr)
    for m in r["mismatches"][:20]:
        print(f"mismatch: {m}", file=sys.stderr)
    if len(r["mismatches"]) > 20:
        print(f"... and {len(r['mismatches']) - 20} more mismatches", file=sys.stderr)
    if args.check or args.verify:
        print(f"Numbers match check: {'ok' if r['ok'] else 'FAILED'} ({r['checked']:,} cells checked, {len(r['mismatches'])} mismatch(es))")
    if not r["ok"]:
        raise SystemExit(1)


def _ledger_guard(name: str):
    """HO-20261025-A-C-024 (EQ-A-0103): a review-ledger refusal (LedgerMissingError: the ledger is missing while vintages
    exist; LedgerChainError: its hash chain is broken, nothing appended) ends the command with one line and exit 1,
    never a traceback."""
    import functools

    def wrap(fn):
        @functools.wraps(fn)
        def inner(args):
            from .ingestion.ledger import LedgerChainError, LedgerMissingError
            try:
                return fn(args)
            except LedgerMissingError as e:
                hint = (" If this really is a first install: econquest fetch --first-install." if name == "fetch" else "")
                raise SystemExit(f"{name}: review ledger missing: {' '.join(str(e).split())}.{hint}") from None
            except LedgerChainError as e:
                raise SystemExit(f"{name}: review ledger hash chain broken, nothing written: {' '.join(str(e).split())} "
                                 "(econquest review verify)") from None
        return inner
    return wrap


@_ledger_guard("fetch")
def cmd_fetch(args):
    """Pull live inputs from IMF WEO, World Bank and BIS, with FX from BIS WS_XRU and the ECB euro reference rates (EXR);
    save under data/live; optionally apply. Yahoo Finance is not a desk feed (EQ-A-0040): `--only yahoo` exits with
    feeds.fetch_all's one-line refusal before any request (HO-20261024-A-C-002)."""
    from .ingestion.feeds import fetch_all, diff_against_seed, save_report, apply_report, quality_gate, save_vintage
    from .ingestion.ledger import write_review, check_approval
    if args.apply and args.force:                         # fail before any network call (four-eyes, SEC-A-001)
        try:
            check_approval(args.author, args.approver, args.self_approved)
        except ValueError as e:
            raise SystemExit(f"fetch --apply --force: {e}. Pass --author NAME and --approver OTHER, or --author NAME --self-approved (single-operator mode, recorded as self_approved=yes).") from None
    u, _ = _load(args)
    only = [x.strip() for x in args.only.split(",")] if args.only else None
    wv = tuple(args.weo_version.split(",")) if args.weo_version else None
    if wv:
        wv = (wv[0], int(wv[1]))
    try:
        rep = fetch_all(u, only=only, year=args.year, weo_version=wv, data_dir=Path(args.data))   # HO-20261024-A-C-017
    except ValueError as e:                               # e.g. --only yahoo: refused before any request (EQ-A-0040)
        raise SystemExit(f"fetch: {' '.join(str(e).split())}") from None
    diff = diff_against_seed(u, rep)
    live = save_report(rep, Path(args.data), diff)
    # data_dir enables the vintage-to-vintage check (HO-20261023-A-C-009); before save_vintage so the latest saved
    # vintage is the previous pull
    review = quality_gate(u, rep, diff, max_rel_change=args.max_change, year=args.year, data_dir=Path(args.data))
    review = write_review(Path(args.data), review,        # atomic; keeps ledger decisions (EQ-A-0006)
                          first_install=getattr(args, "first_install", False))   # HO-20261025-A-C-024
    vintage = save_vintage(Path(args.data), rep, review)
    ok = [k for k, v in rep.feeds.items() if v.startswith("ok")]
    print("Feeds: " + "; ".join(f"{k}: {v}" for k, v in rep.feeds.items()))
    filled = int(rep.indicators.notna().sum().sum()) + int(rep.profile.notna().sum().sum())
    print(f"Live cells: {filled} ({len(diff)} compared with seed) -> {live}; vintage kept in {vintage}")
    if len(diff):
        big = diff.loc[diff["change"].abs().sort_values(ascending=False).index].head(args.top)
        print(big.to_string(index=False))
    held = review[review["status"] == "hold"]; missing = review[review["status"] == "missing"]
    print(f"Quality gate: {int((review['status'] == 'ok').sum())} ok, {len(held)} held for review, {len(missing)} missing (details in {live / 'review.csv'})")
    if len(held):
        print(held[["table", "key", "country", "seed", "live", "reason"]].head(args.top).to_string(index=False))
    _missing_cells(Path(args.data))
    if args.apply:
        if not ok:
            print("Nothing applied: no feed succeeded.")
        else:
            try:
                res = apply_report(rep, Path(args.data), review=review, force=args.force, vintage_id=vintage.name,
                                   author=args.author, approver=args.approver, self_approved=args.self_approved)
            except ValueError as e:
                raise SystemExit(f"Nothing applied: {e}") from None
            print("Applied:", res)
            if len(held) and not args.force:
                print(f"{len(held)} held cells were not applied; check review.csv and rerun with --force to apply them too.")


def _missing_cells(data_dir: Path) -> None:
    """Missing-country report on every pull (HO-20261023-A-C-014, epic A6): summary, countries below the live target and
    <data>/live/missing_cells.csv. A report that cannot be built warns; the fetch carries on."""
    try:
        from .ingestion.universe import missing_cell_report
        rep = missing_cell_report(data_dir)
        path = data_dir / "live" / "missing_cells.csv"
        rep.cells.to_csv(path, index=False)
        if rep.summary.get("measured") is False:
            # HO-20261025-A-C-004 (EQ-C-0103): a partial fetch (e.g. --only fx) is not measured; one line, no '0 of 0'.
            print(f"Missing cells: {rep.summary.get('note') or 'coverage not measured'}")
            return
        low = rep.countries[~rep.countries["meets_target"].astype(bool)]
        below = ", ".join(f"{r.country} {r.pct_live_eligible:.0%}" for r in low.itertuples(index=False))   # HO-20261024-A-C-010
    except Exception as e:                             # noqa: BLE001 - the pull and the gate matter more than the report
        print(f"warning: missing-cell report not written: {type(e).__name__}: {e}", file=sys.stderr)
        return
    print("Missing cells: " + json.dumps(rep.summary, default=str))
    denom = rep.summary.get("denominator")
    print(f"Countries below the {float(rep.summary.get('target', 0)):.0%} live target: {len(low)} of {len(rep.countries)}"
          + (f" ({denom})" if denom else "") + (f": {below}" if below else "") + f" (cells in {path})")


def _market_gate(d: Path, as_of: str | None):
    """(review, latest market) for `market gate` and `market cds-quotes` (HO-20261023-A-C-015): Team A's
    cds_export.market_gate_review, which seeds the gate only from earlier rows that passed it and the attestation check,
    so a re-saved held quote is held again (SEC-A-003 L5, HO-20261023-A-C-019)."""
    from .ingestion.market.cds_export import market_gate_review
    try:
        return market_gate_review(d, as_of)
    except FileNotFoundError as e:
        raise SystemExit(f"market: {e}") from None


def _atomic_csv_write(df: pd.DataFrame, path: Path) -> None:
    """Write df to path through a temp file in the same folder and os.replace, so a reader never sees half a file."""
    import tempfile
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(prefix=f".{path.name}.", suffix=".tmp", dir=path.parent)
    try:
        with os.fdopen(fd, "w", newline="", encoding="utf-8") as f:
            df.to_csv(f, index=False)
        os.chmod(tmp, 0o644); os.replace(tmp, path)
    except BaseException:
        Path(tmp).unlink(missing_ok=True)
        raise


def cmd_market(args):
    """Market data (HO-20261023-A-C-015, Team A's econquest/ingestion/market/): import a vendor CSV export, enter attested
    hand-typed quotes, run the market quality gate, and write data/cds_quotes.csv from the latest snapshot minus held series.
    Runbook: docs/runbooks/A-market-data.md."""
    from .ingestion.market import MarketDataError
    d = Path(args.data)
    try:
        if args.market_cmd == "import":
            from .ingestion.market.importers import ensure_ticker_map, import_and_save
            if args.init_map:
                print(f"Ticker map: {ensure_ticker_map(d)} (created from the template if missing, never overwritten). "
                      "Check each row against a real export and set status=verified.")
                return
            if not (args.file and args.profile and args.licence):
                raise SystemExit("market import: needs --profile bloomberg|lseg, --licence TEXT and the CSV file (or --init-map)")
            folder = import_and_save(d, args.file, args.profile, args.licence, mapping=args.map)
            man = json.loads((folder / "manifest.json").read_text(encoding="utf-8"))
            print(f"Saved snapshot {folder.name}: {man['rows']} quotes ({', '.join(man['instruments'])}), as of {man['asof_min']} to "
                  f"{man['asof_max']}, {man['provenance'].get('skipped_missing', 0)} missing values skipped -> {folder}")
        elif args.market_cmd == "enter":
            from .ingestion.market.manual import enter_quotes
            try:
                rows = pd.read_csv(args.file, dtype=str, keep_default_na=False)
            except (OSError, pd.errors.ParserError, pd.errors.EmptyDataError) as e:
                raise SystemExit(f"market enter: cannot read {args.file}: {e}") from None
            r = enter_quotes(d, rows, args.author, approver=args.approver, self_approved=args.self_approved, note=args.note or "")
            q = r["rows"]
            print(f"Entered {len(q)} quotes as {r['entry_id']} (author {q['author'].iloc[0]}, approver {q['approver'].iloc[0]}"
                  + (", self-approved" if q["self_approved"].iloc[0] == "yes" else "") + f"); {len(r['attestations'])} attestations; "
                  f"snapshot {Path(r['snapshot']).name}")
        elif args.market_cmd == "cds-snapshots":          # HO-20261023-A-C-017: gated export to data/market/cds_snapshots.csv
            from .ingestion.market.store import export_cds_snapshots
            try:
                rep = export_cds_snapshots(d, [args.snapshot] if args.snapshot else None, dry_run=args.dry_run)
            except FileNotFoundError as e:
                raise SystemExit(f"market cds-snapshots: {e}") from None
            print(rep.summary())
            if len(rep.dropped):
                print(rep.dropped.head(args.top).to_string(index=False))
        else:                                   # gate, cds-quotes
            from .ingestion.market.gate import series_key
            review, cur = _market_gate(d, args.asof)
            held = review[review["status"] == "hold"]
            flags = review[(review["status"] != "hold") & review["reason"].str.contains("flag:", regex=False)]
            print(f"Market gate{' as of ' + args.asof if args.asof else ''}: {int((review['status'] == 'ok').sum())} ok, {len(held)} held, "
                  f"{len(flags)} flagged ({len(review)} series)")
            if len(held) or len(flags):
                print(pd.concat([held, flags])[["key", "country", "seed", "live", "status", "reason"]].head(args.top).to_string(index=False))
            if args.market_cmd == "gate":
                out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
                review.to_csv(out / "market_gate.csv", index=False)
                print(f"Review table -> {out / 'market_gate.csv'}")
                if args.strict and len(held):
                    raise SystemExit(1)
                return
            from .ingestion.market import to_cds_quotes
            hold = set(zip(held["key"], held["country"]))
            is_held = pd.Series([(series_key(r), r["iso"]) in hold for _, r in cur.iterrows()], index=cur.index, dtype=bool)
            dropped = int((is_held & (cur["instrument"] == "cds")).sum())
            cds = to_cds_quotes(cur[~is_held], country_names=d / "countries.csv")
            dest = Path(args.dest) if args.dest else d / "cds_quotes.csv"
            if cds.empty:
                raise SystemExit(f"market cds-quotes: no CDS spread quotes left after excluding {dropped} held cds series; {dest} not changed")
            if args.dry_run:
                print(cds.to_string(index=False))
                print(f"Dry run: {len(cds)} rows not written to {dest} ({dropped} held cds series excluded)")
                return
            _atomic_csv_write(cds, dest)
            print(f"Wrote {len(cds)} rows ({cds['country'].nunique()} countries) to {dest}; {dropped} held cds series excluded")
    except (MarketDataError, ValueError, OSError) as e:      # OSError (FileExistsError, a directory as file/--dest): AGENT-09 SEC-C-006 L2
        raise SystemExit(f"market {args.market_cmd}: {e}") from None


VENDOR_EXIT = 2
VENDOR_STATUS_COLUMNS = ["vendor", "package_ok", "licence", "licence_id", "scope", "expiry", "usable"]


def _vendor_usage(args, adapter, res, purpose: str, output: str) -> None:
    """EQ-C-0117: one vendor usage-log row per vendor test / pull. A log failure is printed, never hidden."""
    from .ops.vendor_ops import record_use
    try:
        st = adapter.licence_state()
        record_use(Path(args.out), adapter.name, f"vendor {args.vendor_cmd} ({len(args.ticker or [])} tickers, as of "
                   f"{args.asof or 'latest'})", purpose, output, licence=st.entitlement.tag if st.entitlement else "",
                   detail=res.summary())
    except Exception as e:                            # noqa: BLE001 - the pull happened; say the log row is missing
        print(f"vendor {args.vendor_cmd}: WARNING usage log row not written ({type(e).__name__})", file=sys.stderr)


GOLIVE_CMDS = ("verify", "capture", "register-patch", "schedule", "layer2-preview")
GOLIVE_TAKES_DATA = ("verify", "capture", "register-patch", "layer2-preview")


def golive_argv(args) -> list[str]:
    """argv for golive.main (HO-20261025-A-C-023): the subcommand and its flags unchanged; the top-level --data is added
    when the subcommand takes one and none was given."""
    rest = list(getattr(args, "golive_args", None) or [])
    if args.golive_cmd in GOLIVE_TAKES_DATA and not any(a == "--data" or a.startswith("--data=") for a in rest):
        rest += ["--data", str(args.data)]
    return [args.golive_cmd, *rest]


def vendor_golive(args) -> int:
    """`econquest vendor golive <verify|capture|register-patch|schedule|layer2-preview> ...`: Team A's licensed go-live kit
    (econquest.ingestion.market.vendors.golive, EQ-A-0107; runbook docs/runbooks/A-licensed-go-live.md). PAID ROADMAP
    FEATURE, OFF BY DEFAULT. Exit codes are golive's: capture 2 = nothing passed the gates, 1 = refused."""
    from .ingestion.market.vendors.golive import main as golive_main
    return golive_main(golive_argv(args))


def cmd_vendor(args):
    """Licensed vendor adapters (HO-20261023-A-C-021, Team A's econquest/ingestion/market/vendors/, EQ-A-0033): ROADMAP,
    PAID FEATURE, OFF BY DEFAULT. status shows the licence gate without opening a session; test pulls and gates in memory
    (saves nothing); pull saves a snapshot, gates it and runs the gated CDS export. Every refusal (not licensed, bad
    request, session error) prints its message and exits VENDOR_EXIT. No credential is ever an argument: they come only
    from the environment or the OS keychain. Runbook: docs/runbooks/A-licensed-vendors.md."""
    from .ingestion.market import MarketDataError
    from .ingestion.market.vendors import VendorConnectionError, VendorNotLicensed, VendorRequestError, get_adapter, vendor_status
    d = Path(args.data)
    if args.vendor_cmd == "check":                    # EQ-C-0108: onboarding wizard; dry run only, presence-only credentials
        from .ops.vendor_check import run_from_args
        rc = run_from_args(args)
        if rc:
            raise SystemExit(rc)
        return
    if args.vendor_cmd in ("audit", "usage", "snapshots", "rehearse"):   # EQ-C-0117 (+ EQ-C-0146 SIMULATED rehearsal)
        from .ops.vendor_ops import run_cli
        rc = run_cli(args)
        if rc:
            raise SystemExit(rc)
        return
    if args.vendor_cmd == "golive":                   # HO-20261025-A-C-023: Team A's go-live kit, flags passed straight through
        rc = vendor_golive(args)
        if rc:
            raise SystemExit(rc)
        return
    if args.vendor_cmd == "status":
        st = vendor_status(d)
        print("Licensed vendor adapters: paid roadmap feature, off by default (runbook docs/runbooks/A-licensed-vendors.md); no session opened")
        print(st[VENDOR_STATUS_COLUMNS].to_string(index=False))
        for r in st.itertuples(index=False):
            if r.problems:
                print(f"{r.vendor}: {r.problems}")
        return
    if args.vendor_cmd == "pull" and args.asof and (args.start or args.end):
        print("vendor pull: --as-of cannot be combined with --start/--end", file=sys.stderr)
        raise SystemExit(VENDOR_EXIT)
    if args.vendor_cmd == "pull" and bool(args.start) != bool(args.end):
        print("vendor pull: --start and --end go together", file=sys.stderr)
        raise SystemExit(VENDOR_EXIT)
    from .ingestion.market.vendors.pipeline import pull_to_store
    try:
        adapter = get_adapter(args.vendor, data_dir=d)          # a fresh adapter per invocation: an adapter connects only once
        if args.vendor_cmd == "test":
            res = pull_to_store(adapter, d, args.ticker, as_of=args.asof, dry_run=True)
            _vendor_usage(args, adapter, res, "dry_run", "(dry run: nothing saved)")
            print(res.summary())
            print(res.rows.to_string(index=False) if len(res.rows) else "No quotes returned.")
            if len(res.review):
                print(res.review.to_string(index=False))
            return
        res = pull_to_store(adapter, d, args.ticker, args.field or None, start=args.start, end=args.end, as_of=args.asof,
                            dry_run=False, export_cds=not args.no_export)
        _vendor_usage(args, adapter, res, "snapshot", str(res.snapshot) if res.snapshot is not None else "")
        print(res.summary())
        if res.cds_export is not None and len(res.cds_export.dropped):
            print(res.cds_export.dropped.to_string(index=False))
    except (VendorNotLicensed, VendorRequestError, VendorConnectionError, MarketDataError, OSError) as e:   # OSError: as market (SEC-C-006 L2)
        print(f"vendor {args.vendor_cmd}: {e}", file=sys.stderr)
        raise SystemExit(VENDOR_EXIT) from None


def cmd_targets(args):
    """Target-state scorecard (EQ-C-0061, PI-5): re-scores the plan's target-state table and gate criteria from evidence
    (presentation/targets.py) and writes targets.md and targets.csv. Read-only on data/; nothing is scored by hand."""
    from .presentation import targets as T
    if getattr(args, "explain", False):                  # EQ-C-0081: what each unmet target needs; read-only
        from .presentation.readiness import explain_text, readiness
        rep = readiness(args.data, args.out, tests_file=args.tests)
        print(json.dumps(rep, indent=1, default=str) if args.json else explain_text(rep), end="\n" if args.json else "")
        return
    df = T.target_scorecard(args.data, args.out, tests_file=args.tests)
    md, csv = T.write_scorecard(df, Path(args.dest) if args.dest else Path(args.out) / "targets")
    counts = df["met"].value_counts().to_dict()
    print(df[["id", "target", "current", "met"]].to_string(index=False))
    print("Target-state scorecard: " + ", ".join(f"{counts.get(m, 0)} {m}" for m in T.MET) + f" (of {len(df)}) -> {md}, {csv}")


def cmd_calendar_rehearsal(args):
    """EQ-C-0147 (HO-20261026-B-C-007): `calendar-rehearsal` runs Team B's calendar rehearsal on SYNTHETIC data in a temp
    home (validation.calendar_rehearsal), writes <out>/calendar_rehearsal/ and prints the readiness page section read
    back from the file. SYNTHETIC REHEARSAL, not a test result. Exit 0 rehearsal ok, 1 problems or error."""
    from .presentation import rehearsal_view as RV
    try:
        p = RV.run_rehearsal(Path(args.out), scheduled=not args.no_scheduled)
    except (OSError, ValueError) as e:
        print(f"calendar rehearsal: error: {type(e).__name__}: {e}", file=sys.stderr)
        raise SystemExit(1) from None
    print(json.dumps(p, indent=1, default=str) if args.json else RV.rehearsal_text(p), end="\n" if args.json else "")
    if p.get("status") != "ok":
        raise SystemExit(1)


def cmd_evidence_clock(args):
    """Evidence clock (EQ-C-0068, HO-20261024-B-C-001): Team B's calendar-gated evidence monitor (250-day forecast record,
    12-month benchmark scoring, trade-idea quarters) as of --as-of (default: settings as_of, else today). Read-only;
    --write saves <out>/evidence_monitor.csv and .md. Named evidence-clock: `evidence` is the EQ-C-0060 bundle."""
    from .presentation.evidence_view import default_as_of
    from .validation.evidence_monitor import evidence_monitor, monitor_markdown, write_monitor
    as_of = default_as_of(args.data, args.as_of)
    table = evidence_monitor(as_of, data_dir=args.data, out_dir=args.out)
    print(monitor_markdown(table), end="")
    if args.write:
        csv, md = write_monitor(table, args.out)
        print(f"Evidence clock written: {csv}, {md}")


def cmd_attest(args):
    """Attest hand-entered cells (adjustments, cds_quotes, prediction_markets) in the review ledger (EQ-A-0018), or --list
    the cells whose current content is not attested. Four-eyes: --approver OTHER, or --self-approved."""
    from .ingestion.ledger import attest_cells, unattested_cells
    d = Path(args.data)
    if _attest_is_batch(args):                            # EQ-C-0074
        return _attest_batch(args, d)
    if args.list:
        try:
            cells = unattested_cells(d, [args.file] if args.file else None)
        except ValueError as e:
            raise SystemExit(f"attest: {e}") from None
        if not cells:
            print("All hand-entered cells are attested." if not args.file else f"All cells of {args.file} are attested.")
            return
        print(pd.DataFrame(cells)[["table", "key", "country", "value"]].to_string(index=False))
        print(f"{len(cells)} unattested hand-entered cells")
        return
    if not args.file or not args.author:
        raise SystemExit("attest: --file and --author are required (or use --list)")
    from .ops.identity import cli_signoff
    so = cli_signoff(d, args, "attest")                   # EQ-C-0109: named users when four-eyes is enforced
    try:
        rows = attest_cells(d, args.file, args.author, approver=so.approver, self_approved=args.self_approved,
                            note=args.note or "", all_cells=args.all)
    except ValueError as e:
        raise SystemExit(f"attest: {e}") from None
    so.record(rows)
    print(f"Attested {len(rows)} cells of {args.file}.csv (author {args.author}, approver {rows[0]['approver'] if rows else args.approver or '-'})")


BATCH_FLAGS = ("country", "group", "pillar", "key")


def _named_user_args(p, exc: bool = True) -> None:
    """--as (and --exc) for a four-eyes sign-off by data/users.json named users (EQ-C-0109, ops/identity.py)."""
    p.add_argument("--as", dest="approver_id", metavar="USER_ID", help="sign as this data/users.json user with their key; "
                   "required once four-eyes is enforced (econquest users list)")
    if exc:
        p.add_argument("--exc", help="with --self-approved under enforced four-eyes: a named, unexpired exception "
                       "(users.json self_approval_exceptions)")


def _attest_is_batch(args) -> bool:
    """attest with any EQ-C-0074 batch flag: a selection by sheet/country/group, --all-files, --dry-run or --confirm."""
    return bool(getattr(args, "dry_run", False) or getattr(args, "confirm", False) or getattr(args, "all_files", False)
                or getattr(args, "expect", None) is not None or getattr(args, "expect_digest", None) is not None or any(getattr(args, k, None) is not None for k in BATCH_FLAGS))


def _attest_batch(args, d: Path) -> None:
    """Batch attestation (EQ-C-0074): never automatic. --dry-run (or --list) prints the selection and writes nothing;
    --confirm with --author and --approver/--self-approved writes it through ops.open_items.attest_batch (all or
    nothing; --expect N refuses if the selection changed since the dry run). cli.main logs 'attest batch'."""
    from .ops import open_items as OI
    if args.all and not args.list:
        raise SystemExit("attest: --all (re-attest every cell) is for the single-file form, not a batch")
    if args.file and args.all_files:
        raise SystemExit("attest: give --file or --all-files, not both")
    if not (args.file or args.all_files or any(getattr(args, k) is not None for k in BATCH_FLAGS)):
        raise SystemExit("attest: a batch needs a selection: --file, --all-files, --country, --group, --pillar or --key")
    if args.dry_run and args.confirm:
        raise SystemExit("attest: --dry-run and --confirm together; run the dry run first, then --confirm")
    files = [args.file] if args.file else None
    sel = {"files": files or [], "all_files": args.all_files and not files, **{k: getattr(args, k) for k in BATCH_FLAGS}}
    try:
        cells = OI.select_unattested(d, files, args.country, args.group, args.pillar, args.key)
    except ValueError as e:
        raise SystemExit(f"attest: {e}") from None
    if args.list or args.dry_run or not args.confirm:
        s = OI.batch_summary(cells)
        if cells:
            print(pd.DataFrame(cells)[["table", "key", "country", "value"]].head(200).to_string(index=False))
            if len(cells) > 200:
                print(f"... and {len(cells) - 200} more")
        print(f"{s['total']} unattested cell(s) selected: " + (", ".join(f"{k} {v}" for k, v in s["by_group"].items()) or "none"))
        if not args.confirm and not args.list and not args.dry_run:
            raise SystemExit("attest: a batch writes only with --confirm (and --author NAME, --approver OTHER or --self-approved); "
                             "nothing was written. Check it first with --dry-run.")
        if cells:
            print("Dry run: nothing written. To attest exactly these cells:" if args.dry_run else "To attest these cells:")
            print("  " + OI.batch_command(sel | {"expect": len(cells), "digest": OI.selection_digest(cells)}, True)
                  .replace("NAME", "YOUR_NAME"))
        return
    if not args.author:
        raise SystemExit("attest: a batch needs --author NAME (and --approver OTHER or --self-approved)")
    from .ops.identity import cli_signoff
    so = cli_signoff(d, args, "attest")                   # EQ-C-0109
    try:
        rows = OI.attest_batch(d, args.author, approver=so.approver, self_approved=args.self_approved, note=args.note or "",
                               files=files, country=args.country, group=args.group, pillar=args.pillar, key=args.key,
                               expect=args.expect, digest=getattr(args, "expect_digest", None))
    except ValueError as e:
        raise SystemExit(f"attest: {e}") from None
    if rows:
        so.record(rows)
    if not rows:
        print("Nothing to attest: the selection has no unattested cells.")
        return
    s = OI.batch_summary(rows)
    print(f"Attested {len(rows)} cells ({', '.join(f'{k} {v}' for k, v in s['by_group'].items())}); author {rows[0]['author']}, "
          f"approver {rows[0]['approver']}{' (self-approved)' if rows[0]['self_approved'] == 'yes' else ''}. Recorded in the action log.")


def cmd_audit(args):
    """Audit trail: one row per Inputs / Country Profile cell with origin, source, series, transform, vintage and gate decision."""
    from .ingestion.audit import build_audit_trail, audit_summary, audit_plan
    from .presentation.sheets_publish import save_plan, apply_plan
    df = build_audit_trail(args.data)
    out_csv = Path(args.data) / "audit_trail.csv"
    df.to_csv(out_csv, index=False)
    plan = audit_plan(df)
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    save_plan(plan, out / "audit_plan.json")
    print(f"Audit trail: {len(df)} cells -> {out_csv}; workbook plan -> {out / 'audit_plan.json'}")
    print(audit_summary(df).to_string(index=False))
    if "attested" in df.columns:
        n = int((df["attested"].astype(str) == "no").sum())
        if n:
            print(f"{n} hand-entered cells are not attested: see `econquest attest --list`")
    if args.token:
        print("Written:", apply_plan(plan, args.spreadsheet_id, args.token))


def cmd_garch(args):
    """GARCH(1,1)-t per FX pair and ETF, DCC correlations, GARCH-DCC portfolio VaR, option fair values, GPR volatility."""
    from .engine.garch import run_garch, load_prices
    from .presentation.garch_publish import garch_plan, garch_tables
    from .presentation.sheets_publish import save_plan, apply_plan
    u, s = _load(args)
    px = load_prices(args.data)
    if px is None:
        raise SystemExit(NO_PRICES_MSG)
    quotes = None
    if args.quotes:
        q = pd.read_csv(args.quotes); quotes = dict(zip(q.iloc[:, 0].astype(str), pd.to_numeric(q.iloc[:, 1], errors="coerce")))
    # VF-007 (HO-20261023-B-C-016): fit no price after --as-of; a --vintage replay defaults to the vintage's date; neither
    # given -> run_garch falls back to settings as_of, else every row (unchanged)
    as_of = getattr(args, "as_of", None) or (_vintage_date(u) if getattr(args, "vintage", None) else None)
    if as_of:
        print(f"GARCH fitted on prices dated on or before {as_of}")
    g = run_garch(u, px, s, u.gpr, quotes=quotes, as_of=as_of)
    out = Path(args.out) / "garch"; out.mkdir(parents=True, exist_ok=True)
    for name, df in garch_tables(g).items():
        df.to_csv(out / f"{name}.csv", index=name.startswith("dcc") or name == "vol_history")
    plan = garch_plan(g, u)
    save_plan(plan, out / "garch_plan.json")
    cols = ["country", "kind", "ticker", "persistence", "nu", "cond_vol_pct", "fcst_21d_vol_pct", "realized_60d_vol_pct", "var99_1d_pct", "exposure_mm", "var99_10d_mm", "vol_target_scalar"]
    print(g.series[cols].round(3).to_string(index=False))
    p = g.portfolio
    print(f"\nGARCH-DCC book VaR99 ($mm): FX 1d {p['FX']['var99_1d_mm']:.2f} / 10d {p['FX']['var99_10d_mm']:.2f}; equity 1d {p['Equity']['var99_1d_mm']:.2f} / 10d {p['Equity']['var99_10d_mm']:.2f}; total 1d {p['total_var99_1d_mm']:.2f} / 10d {p['total_var99_10d_mm']:.2f}")
    if g.dcc_fx:
        print(f"DCC FX: a={g.dcc_fx.a:.3f} b={g.dcc_fx.b:.3f} avg corr {g.dcc_fx.avg_corr(g.dcc_fx.R_next):.3f}")
    if g.dcc_eq:
        print(f"DCC equity: a={g.dcc_eq.a:.3f} b={g.dcc_eq.b:.3f} avg corr {g.dcc_eq.avg_corr(g.dcc_eq.R_next):.3f}")
    print(f"Tables -> {out}; GARCH tab plan ({len(plan)} ranges) -> {out / 'garch_plan.json'}")
    if args.token:
        r = apply_plan(plan, args.spreadsheet_id, args.token)
        print(f"Wrote {r.get('totalUpdatedCells')} cells to the GARCH tab")


def cmd_econ(args):
    """Econometrics toolkit on the Market History prices: workflow tests, cointegration, SVAR, Kalman betas, regimes, premia, EVT, copulas, forecasts, event study."""
    import warnings
    from .engine.garch import run_garch, load_prices
    from .engine.econometrics import run_econometrics
    from .presentation.econ_publish import econ_plan
    from .presentation.sheets_publish import save_plan, apply_plan
    from .scorecard import score_universe
    warnings.filterwarnings("ignore", category=RuntimeWarning)
    u, s = _load(args)
    px = load_prices(args.data)
    if px is None:
        raise SystemExit(NO_PRICES_MSG)
    g = run_garch(u, px, s, u.gpr)
    e = run_econometrics(u, px, g, s, u.gpr, score_universe(u, s).composite)
    out = Path(args.out) / "econometrics"; out.mkdir(parents=True, exist_ok=True)
    for name in ("workflow", "cointegration", "svar", "kalman", "regimes", "premia_fm", "premia_gmm", "evt", "copulas", "forecasts", "forecast_importance", "events"):
        getattr(e, name).to_csv(out / f"{name}.csv", index=name.startswith("premia") or name == "forecast_importance")
    plan, _ = econ_plan(e)
    save_plan(plan, out / "econ_plan.json")
    wf = e.workflow
    print(f"Series: {len(wf)}; returns stationary (ADF, FDR 5%): {int(wf['adf_return_bh_reject'].sum())}; ARCH effects (FDR 5%): {int(wf['arch_bh_reject'].sum())}; out-of-sample best: {wf['oos_best'].value_counts().to_dict()}")
    print(f"Cointegration: {e.cointegration['read'].value_counts().to_dict()}")
    print("Forecasts (R2 out of sample): " + "; ".join(f"{r.model}: {r.r2_out_of_sample:.3f}" for r in e.forecasts.itertuples()))
    print(f"Premia (weekly, Fama-MacBeth):\n{e.premia_fm.round(5).to_string()}")
    print(f"Tables -> {out}; Econometrics tab plan ({len(plan)} ranges) -> {out / 'econ_plan.json'}")
    if args.token:
        r = apply_plan(plan, args.spreadsheet_id, args.token)
        print(f"Wrote {r.get('totalUpdatedCells')} cells to the Econometrics tab")


def _loopback_host(host: str, cmd: str) -> str:
    """gui/serve bind only to loopback (SEC-C-007 O1): the Host-header guard does not check who connects, so another
    machine on the network could read the session token and start jobs."""
    import ipaddress
    h = str(host).strip().strip("[]")
    try:
        ok = h.lower() == "localhost" or ipaddress.ip_address(h).is_loopback
    except ValueError:
        ok = False
    if not ok:
        raise SystemExit(f"{cmd}: --host {host!r} is not a loopback address; the {cmd} is for this machine only (use 127.0.0.1)")
    return h


def cmd_serve(args):
    _loopback_host(args.host, "serve")
    serve(args.data, str(Path(args.out) / "store"), host=args.host, port=args.port)


def cmd_gui(args):
    """Local browser app with charts and buttons for every command."""
    from .presentation.gui import gui
    _loopback_host(args.host, "gui")
    gui(args.data, args.out, host=args.host, port=args.port, open_browser=not args.no_browser)


def cmd_monitor(args):
    """Weekly risk monitor (EQ-C-0009): latest archived run vs the run about --days earlier; outputs/reports/risk-monitor-<as_of>.html, .md and latest-monitor.html."""
    from .presentation.risk_monitor import build_monitor
    r = build_monitor(args.out, args.data, Path(args.out) / "reports", days=args.days)
    print(f"Monitor: {r['html']} (markdown {r['md']}; latest {r['latest']}); run {r['run_id']} as of {r['as_of'] or 'not recorded'} vs {r['reference_run_id'] or 'none'}; {r['caveats']} input caveats")


def cmd_report(args):
    """Daily risk report (roadmap 4.2) from the latest archived run (or a fresh run when none is archived): outputs/reports/risk-report-<date>.html, .md and latest.html."""
    from .presentation.report import build_report
    from .validation.alerts import deliver_alerts
    r = build_report(args.data, args.out, paths=args.paths)
    s = Settings.load(Path(args.data) / "assumptions.json")
    deliver_alerts(r["alerts"], s, os.environ, out_dir=args.out, webhook=not args.no_deliver, email=not args.no_deliver, run_id=r["run_id"], html=r["html_text"])
    print(f"Report: {r['html']} (markdown {r['md']}; latest {r['latest']}); run {r['run_id']} vs previous {r['previous_run_id'] or 'none'}; {len(r['alerts'])} alerts")


def cmd_alerts(args):
    """Alerts (roadmap 4.3): compare the latest archived run with the previous one (or --previous <run id>), test the forecast record, check the data layer; write outputs/alerts.json and deliver."""
    from .validation.alerts import detect_alerts, deliver_alerts, load_data_issues
    from .validation.record import load_record
    from .presentation.report import latest_run, previous_run
    store = Store(Path(args.out) / "store")
    cur = latest_run(store)
    if cur is None:
        raise SystemExit("No archived run: run `econquest run` first.")
    prev = store.load(args.previous) if args.previous else previous_run(store, cur)
    s = Settings.load(Path(args.data) / "assumptions.json")
    review, feeds = load_data_issues(args.data)
    rec_path = Path(args.data) / "forecast_record.csv"
    alerts = detect_alerts(cur, prev, load_record(rec_path) if rec_path.exists() else None, s, review=review, feeds=feeds)
    st = deliver_alerts(alerts, s, os.environ, out_dir=args.out, webhook=args.webhook, email=args.email, run_id=cur["summary"]["run_id"])
    print(f"Run {cur['summary']['run_id']} vs {prev['summary']['run_id'] if prev else 'no previous run'}: {len(alerts)} alerts -> {st['written']}; webhook {st['webhook']}; email {st['email']}")


def cmd_limits(args):
    """Limits table for the current book and, with --propose, the pre-trade check (roadmap 4.1)."""
    from .engine import limits as LM
    u, s = _load(args)
    lim = LM.load_limits(Path(args.data) / "limits.json")
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    paths = args.paths or 20000
    pd.set_option("display.width", 200)
    if args.propose:
        res = LM.pretrade_check(u, s, lim, args.propose, paths=paths, market_dir=args.data)   # HO-20261026-B-C-006
        table = res["limits_after"]
        table.to_csv(out / "limits.csv", index=False)
        (out / "pretrade.json").write_text(dumps(LM.pretrade_to_dict(res)))
        b, a = res["before_common_paths"], res["after"]
        print(f"Proposed: {res['proposal']}  ({paths} paths, seed {res['seed']})")
        print(f"VaR99 {b['var99_mm']:.1f} -> {a['var99_mm']:.1f} (marginal {res['marginal_var99_mm']:+.2f}), ES99 {b['es99_mm']:.1f} -> {a['es99_mm']:.1f} (marginal {res['marginal_es99_mm']:+.2f}), "
              f"L-VaR99 {b['lvar99_mm']:.1f} -> {a['lvar99_mm']:.1f}, gross {res['before']['gross_notional_mm']:.0f} -> {a['gross_notional_mm']:.0f}")
        print(f"VERDICT: {res['verdict'].upper()}")
        for r in res["reasons"]:
            print("  " + r)
        if not res["reasons"]:
            print("  no limit at or above its warning level after the trade")
    else:
        r = run_pipeline(u, s, paths=paths, market_dir=args.data)
        table = LM.check_book(r, u, lim)
        table.to_csv(out / "limits.csv", index=False)
    shown = table.sort_values("utilisation", ascending=False)
    print(); print(shown.round(4).to_string(index=False))
    n = table["status"].value_counts()
    print(f"\n{int(n.get('pass', 0))} pass, {int(n.get('warning', 0))} warning, {int(n.get('breach', 0))} breach. Written {out / 'limits.csv'}" + (f" and {out / 'pretrade.json'}" if args.propose else ""))


def cmd_whatif(args):
    """What-if trades on the current book (EQ-C-0133): before/after VaR99, ES99, EL, L-VaR99, limit status and each
    trade's marginal contribution. In memory only: nothing is booked and data/portfolio.csv is never written."""
    from .presentation import whatif as WI
    u, s = _load(args)
    try:
        trades = [WI.parse_trade(t, u.names) for t in (args.trade or [])]
        if args.fast and args.full:
            raise ValueError("give --fast or --full, not both")
        trades, paths, mode = WI.validate_request(trades, args.paths, "fast" if args.fast else "full", u.names)
    except ValueError as e:
        raise SystemExit(f"whatif: {e}") from None
    res = WI.whatif(u, s, WI.load_limits(args.data), trades, paths=paths, mode=mode, as_of=args.as_of, market_dir=args.data)
    if args.json:
        print(dumps(WI.public(res)))
        print(f"whatif runtime {res['_runtime_s']}s", file=sys.stderr)
    else:
        print(WI.render_text(res))
        print(f"runtime {res['_runtime_s']}s")


def cmd_attribution(args):
    """Risk attribution of the base run (EQ-C-0139, HO-20261025-B-C-018): component and marginal VaR99 / ES99 by country
    or by risk factor, from Team B's engine.portfolio_risk.attribution. Writes only <out>/attribution.json."""
    from .presentation import attribution as AT
    try:
        by, paths = AT.validate(args.by, args.paths)
    except ValueError as e:
        raise SystemExit(f"attribution: {e}") from None
    u, s = _load(args)
    res = AT.collect(u, s, by=by, paths=paths, as_of=args.as_of, market_dir=args.data)
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    (out / "attribution.json").write_text(dumps(res), encoding="utf-8")
    if args.json:
        print(dumps(res))
    else:
        print(AT.render_text(res))
        print(f"written {out / 'attribution.json'}")


def cmd_replicate(args):
    """Independent replication of the reported numbers (HO-20261023-B-C-015, EQ-B-0051): a pass-through to
    econquest.validation.replicate.main with the same flags and its exit code (1 on any FAIL). Maintenance change: no
    logic here, no model number moves."""
    from .validation import replicate as R
    argv = ["--data", str(args.data), "--out", str(args.rep_out or Path(args.out) / "replication")]
    argv += (["--quick"] if args.quick else []) + (["--only", args.only] if args.only else [])
    code = R.main(argv)
    if code:
        raise SystemExit(code)


def cmd_replicate_archive(args):
    """Second-line replication of the release notes 0.1.1-0.1.5 against the archived runs, the kept zip and (--rerun) a
    rerun of the 0.1.5 zip's engine (HO-20261024-B-C-003 part 1, EQ-B-0058): a pass-through to
    econquest.validation.replicate_archive.main with the same flags and its exit code (1 = a mismatch without a
    findings-register row, or a cited run missing). Read-only on the archive and the store; writes only to --out."""
    import zipfile
    from .validation import replicate_archive as RA

    def opt(flag, val):                                # SEC-C-009: a value starting with '-' stays the flag's value
        return [f"{flag}={val}"] if str(val).startswith("-") else [flag, str(val)]
    if args.zip is not None and args.zip != "none" and not Path(args.zip).is_file():
        raise SystemExit(f"replicate-archive: --zip {args.zip} is not a file (pass --zip none to skip the zip checks)")
    argv = opt("--out", args.ra_out or Path(args.out) / "replication-archive")
    for flag, val in (("--archive", args.archive), ("--db", args.db), ("--zip", args.zip)):
        if val is not None:
            argv += opt(flag, val)
    argv += ["--rerun"] if args.rerun else []
    try:
        code = RA.main(argv)
    except (ValueError, OSError, zipfile.BadZipFile) as e:   # e.g. --out inside the archive, a damaged or wrong zip
        raise SystemExit(f"replicate-archive: {' '.join(str(e).split())}") from None
    if code:
        raise SystemExit(code)


def cmd_governance(args):
    """Governance pack: regenerate docs/governance/change-log.md from the run archive and print the inventory status."""
    from .validation.governance import change_log, write_change_log, inventory_status
    store = Store(Path(args.out) / "store")
    df = change_log(store, limit=args.limit)
    docs = Path(args.docs) if args.docs else HOME_DIR / "docs" / "governance"
    path = write_change_log(df, docs / "change-log.md")
    print(f"Change log: {len(df)} runs -> {path}")
    if len(df):
        print(df[["run_id", "label", "code_hash", "data_hash", "var99_mm", "es99_mm", "code_changed", "data_changed", "settings_changed"]].round(2).to_string(index=False))
    status = inventory_status(args.data, args.out)
    (Path(args.out) / "governance_status.json").write_text(dumps(status))
    print(dumps(status))


def cmd_editorial(args):
    """Editorial states (EQ-C-0026): draft -> reviewed -> published; correct, withdraw, list, verify (outputs/editorial/ledger.jsonl, outputs/published/)."""
    from .presentation import editorial as E
    from .presentation.report import latest_run
    out = Path(args.out)
    try:
        if args.ed_cmd in ("draft", "correct"):
            run = Store(out / "store").load(args.run_id) if args.run_id else latest_run(Store(out / "store"))
            meta = E.meta_from_run(run) if (run is not None or args.ed_cmd == "draft") else None
            it = (E.register_draft(out, args.kind, args.file, meta, args.author) if args.ed_cmd == "draft"
                  else E.correct(out, args.item, args.file, args.author, args.reason, meta=meta if args.run_id else None))
        elif args.ed_cmd == "review":
            it = E.review(out, args.item, args.reviewer, args.note or "", self_reviewed=args.self_reviewed, data_dir=args.data)
        elif args.ed_cmd == "checklist":
            if args.show:
                st = E.checklist_status(out, args.item, data_dir=args.data)
            else:
                if not args.by:
                    raise E.EditorialError("checklist needs --by (or --show)")
                it = E.checklist(out, args.item, args.by, conflicts=args.conflicts, acknowledge=args.acknowledge or [],
                                 compliance_approve=(args.note or True) if args.compliance_approve else False,
                                 self_signed=args.self_signed, data_dir=args.data, exc_id=args.exc)
                st = it["checklist_status"] or E.checklist_status(out, args.item, data_dir=args.data)
            for name, v in st["items"].items():
                extra = (f" (by {v.get('approver') or v.get('by')}{', SELF-SIGNED exception ' + str(v.get('exc_id') or '') if v.get('self_signed') else ''})"
                         if v["ok"] and v.get("mode") == "manual" else "")
                print(f"  [{'x' if v['ok'] else ' '}] {name:<19} {v['mode']}{extra}")
                for p in v["problems"]:
                    print(f"        - {p}")
            print(f"{args.item}: checklist {'complete' if st['complete'] else 'INCOMPLETE'}")
            if args.show and not st["complete"]:
                raise SystemExit(1)
            return
        elif args.ed_cmd == "publish":
            it = E.publish(out, args.item, args.publisher, data_dir=args.data)
            try:                                # EQ-C-0045: queue only; `econquest distribute send --send` delivers
                from .ops import distribute as D
                if D.queue(out, it["item_id"], actor=args.publisher, data_dir=args.data)["queued"]:
                    print(f"{it['item_id']}: queued for distribution (econquest distribute send; dry run unless --send)")
            except Exception as e:              # noqa: BLE001 - publishing stands; queue later by hand
                print(f"warning: not queued for distribution ({e}); run `econquest distribute queue {it['item_id']}`", file=sys.stderr)
        elif args.ed_cmd == "withdraw":
            it = E.withdraw(out, args.item, args.by, args.reason)
        elif args.ed_cmd == "list":
            items = E.list_items(out, state=args.state, kind=args.kind)
            for i in items[-args.limit:]:
                print(f"{i['item_id']}  {i['kind']:<15} {i['state']:<10} run {i['meta']['run_id']}  as_of {i['meta']['as_of']}  "
                      f"author {i['author']}  reviewer {i.get('reviewer', '-')}{' (self)' if i.get('self_reviewed') else ''}"
                      f"{'  correction_of ' + i['correction_of'] if i.get('correction_of') else ''}  {i.get('published_dir', '')}")
            if not items:
                print("No editorial items.")
            return
        else:  # verify
            r = E.verify_published(out)
            print(f"verify: {r['checked']} published item(s), {len(r['problems'])} problem(s)")
            for p in r["problems"]:
                print("  " + p)
            if not r["ok"]:
                raise SystemExit(1)
            return
    except E.EditorialError as e:
        raise SystemExit(f"editorial {args.ed_cmd}: {e}") from None
    print(f"{it['item_id']} ({it['kind']}): {it['state']}" + (f" -> {it['published_dir']}" if it.get("published_dir") else ""))


def cmd_change(args):
    """Change approvals for data/assumptions.json, data/limits.json and data/compliance.json (EQ-C-0023, EQ-C-0040):
    propose, approve, reject, apply, list, show, verify (hash chain + drift), baseline."""
    from .ops import approvals as ap
    d = Path(args.data)
    try:
        if args.change_cmd == "propose":
            if args.replace_file:
                patch, replace = Path(args.replace_file).read_text(encoding="utf-8"), True
            else:
                patch, replace = {}, False
                if args.patch_file:
                    patch.update(json.loads(Path(args.patch_file).read_text(encoding="utf-8")))
                for kv in args.set or []:
                    path, sep, raw = kv.partition("=")
                    if not sep:
                        raise SystemExit(f"change propose: --set needs /json/pointer=VALUE, got {kv!r}")
                    try:
                        patch[path] = json.loads(raw)
                    except json.JSONDecodeError:
                        raise SystemExit(f"change propose: value for {path} must be JSON (quote strings: '\"text\"'), got {raw!r}") from None
            p = ap.propose(d, args.file, patch, args.author, args.reason, tier=args.tier, replace=replace,
                           allow_new_keys=args.allow_new_keys, allow_type_change=args.allow_type_change)
            print(f"Proposed {p['id']} ({p['file']}, tier {p['tier']}{', validator needed' if p['needs_validator'] else ''}):")
            for c in p["diff"]:
                print(f"  {c['op']:6} {c['path']}: {json.dumps(c['old'])} -> {json.dumps(c['new'])}")
        elif args.change_cmd == "approve":
            r = ap.approve(d, args.id, approver=args.approver, self_approved=args.self_approved, exc_id=args.exc, note=args.note or "",
                           approver_id=getattr(args, "approver_id", None))
            print(f"Approved {args.id} by {r['approver']}" + (f" (self-approved under {r['exc_id']})" if r["self_approved"] else "") + (f" [signed as {r['approver_id']}]" if r.get("approver_id") else "") + (f" {r['note']}" if r["note"] else ""))
        elif args.change_cmd == "reject":
            ap.reject(d, args.id, args.by, args.reason or "")
            print(f"Rejected {args.id}")
        elif args.change_cmd == "apply":
            r = ap.apply(d, args.id, actor=args.actor)
            print(f"Applied {args.id}: {r['file']} sha256 {r['file_sha256']}")
        elif args.change_cmd == "list":
            rows = ap.list_changes(d, status=args.status)
            print(pd.DataFrame(rows).tail(args.limit).to_string(index=False) if rows else "No changes recorded.")
        elif args.change_cmd == "show":
            print(dumps(ap.show(d, args.id)))
        elif args.change_cmd == "baseline":
            r = ap.baseline(d, args.file, args.actor, args.reason, approver=args.approver, self_approved=args.self_approved, exc_id=args.exc,
                            approver_id=getattr(args, "approver_id", None))      # EQ-C-0109
            print(f"Baselined {r['file']} at sha256 {r['file_sha256']}")
        else:                                   # verify
            v, drift = ap.verify_chain(d), ap.detect_unapproved(d)
            print(f"Chain: {'ok' if v['ok'] else 'BROKEN'} ({v['rows']} rows)")
            for e in v["errors"]:
                print("  " + e)
            for f in drift["files"]:
                print(f"{f['file']}: {f['status']}" + (f" (current {str(f['current_sha256'])[:12]}, approved {str(f['approved_sha256'])[:12]})" if f["status"] == "drift" else ""))
            from .ops.licence_gov import verify_lines         # EQ-C-0106 (R44): the approved licence register
            for line in verify_lines(d):
                print(line)
            from .ops.identity import verify_signatures      # EQ-C-0078: signed rows and four-eyes by named users
            sig = verify_signatures(d) if v["ok"] else {"ok": True, "signed": 0}
            if sig["signed"] or not sig["ok"]:
                print(f"Signatures: {'ok' if sig['ok'] else 'PROBLEMS'} ({sig['signed']} signed, {sig.get('checked', 0)} checked here)")
                for e in sig.get("errors", []):
                    print("  " + e)
            if not drift["ok"] or not sig["ok"]:
                raise SystemExit(1)
    except ap.ApprovalError as e:
        raise SystemExit(f"change {args.change_cmd}: {e}") from None


def cmd_notes(args):
    """Country notes (EQ-C-0024): one HTML note per country, PDF with --pdf when Chrome/Chromium is found."""
    from .presentation.country_note import build_country_notes
    r = build_country_notes(args.out, args.data, args.dest or Path(args.out) / "notes", countries=args.country, pdf=args.pdf, chrome=args.chrome)
    print(f"{len(r['items'])} notes, {r['pdf_ok']} PDFs, {r['elapsed_s']}s -> {r['out_dir']} (pillars: {r['pillar_source']})")


def cmd_briefs(args):
    """Scenario briefs (EQ-C-0025) from stress.json, archived stress runs and reverse_stress.json."""
    from .presentation.scenario_brief import build_scenario_briefs
    r = build_scenario_briefs(args.out, args.data, args.dest or Path(args.out) / "briefs", scenarios=args.scenario, pdf=args.pdf, chrome=args.chrome)
    print(f"{len(r['items'])} briefs -> {r['out_dir']}")


def cmd_publish_preview(args):
    """Republish preview (EQ-C-0027): diff the saved publish plan against a values:batchGet JSON or a previous plan."""
    from .presentation.republish_preview import preview, batchget_urls, load_blocks
    plan = args.plan or Path(args.out) / "publish_plan.json"
    if args.urls:
        for u in batchget_urls(load_blocks(plan)[0], args.spreadsheet_id or "SPREADSHEET_ID"):
            print(u)
        return
    if not args.baseline:
        raise SystemExit("--baseline FILE required (or --urls to print the batchGet URLs to fetch)")
    s = preview(plan, args.baseline, args.dest or Path(args.out) / "preview", tolerance=args.tolerance, large=args.large, data_dir=args.data)
    print(s["html"])


def _review_legacy_reset(d: Path, args) -> None:
    """`econquest review legacy-reset`: straight pass-through to `python -m econquest.ingestion.ledger legacy-reset`
    (same flags, output and exit code; HO-20261025-A-C-018). Appends holds only, so no approver or sign-off is needed."""
    from .ingestion.ledger import main as ledger_main
    argv = ["legacy-reset", "--data", str(d), "--author", args.author]
    argv += ["--approver", args.approver] if args.approver else []
    argv += ["--self-approved"] if args.self_approved else []
    argv += ["--dry-run"] if args.dry_run else []
    rc = ledger_main(argv)
    if rc:
        raise SystemExit(rc)


@_ledger_guard("review")
def cmd_review(args):
    """Review ledger (EQ-A-0006): `review decide` appends one decision row; `review list` prints the latest decision per cell;
    `review approve` / `review apply` decide and apply against a saved vintage (HO-20261023-A-C-016)."""
    from .ingestion.ledger import record_decision, load_decisions, check_approval
    d = Path(args.data)
    if args.review_cmd == "approve":                                  # HO-20261023-A-C-016: decide against a saved vintage
        return _review_approve(d, args)
    if args.review_cmd == "apply":
        return _review_apply(d, args)
    if args.review_cmd == "legacy-reset":                             # HO-20261025-A-C-018 (EQ-A-0101): Team A's entry point as is
        return _review_legacy_reset(d, args)
    if args.review_cmd == "verify":                                   # HO-20261025-A-C-024: Team A's ledger verify as is
        from .ingestion.ledger import main as ledger_main
        rc = ledger_main(["verify", "--data", str(d)] + (["--json"] if args.json else []))
        if rc:
            raise SystemExit(rc)
        return
    so = None
    if args.review_cmd == "decide" and args.decision == "apply":     # EQ-C-0109: named users when four-eyes is enforced
        from .ops.identity import cli_signoff
        so = cli_signoff(d, args, "review")
        args.approver = so.approver
    if args.review_cmd == "decide" and _review_is_batch(args):        # EQ-C-0052 (U06): several held cells at once
        cells = _decide_cells(d, args)

        def decide_one(c):
            row = record_decision(d, c["table"], c["key"], c["country"], args.decision, args.author, approver=args.approver,
                                  note=args.note or "", vintage_id=args.vintage or "", live=c["live"],
                                  gate_status=c["gate_status"], self_approved=args.self_approved)
            so and so.record([row])
            return row

        def precheck(c):                                # every batch cell is gate-held: four-eyes before anything is written
            if args.decision == "apply":
                try:
                    check_approval(args.author, args.approver, args.self_approved)
                except ValueError as e:
                    raise ValueError(f"applying held cell ({c['table']}, {c['key']}, {c['country']}) "
                                     + str(e).replace("self_approved=True", "--self-approved")) from None
        _review_batch(args, "review decide", cells, decide_one, precheck)
        return
    if args.review_cmd == "decide":
        if not (args.table and args.key and args.country):
            raise SystemExit("review decide: give --table, --key and --country for one cell, or --cell TABLE KEY COUNTRY "
                             "(repeat) or --all-pending for several")
        try:
            row = record_decision(d, args.table, args.key, args.country, args.decision, args.author, approver=args.approver,
                                  note=args.note or "", vintage_id=args.vintage or "", live=args.live, gate_status=args.gate_status or "",
                                  self_approved=args.self_approved)
        except ValueError as e:
            raise SystemExit(f"review decide: {e}") from None
        so and so.record([row])
        print("Recorded:", ", ".join(f"{k}={v}" for k, v in row.items() if v not in ("", None)))
    else:
        dec = load_decisions(d)
        if args.country:
            dec = dec[dec["country"] == args.country]
        if args.table:
            dec = dec[dec["table"] == args.table]
        if getattr(args, "vintage", None) and not getattr(args, "pending", False):
            raise SystemExit("review list: --vintage needs --pending (review list --pending --vintage ID)")
        if getattr(args, "pending", False):
            if args.vintage:
                return _review_pending_vintage(d, args)
            dec = _review_pending(d, dec, args)
            print(dec.tail(args.limit).to_string(index=False) if len(dec) else "No held cells waiting for a decision.")
            if len(dec):
                print(APPROVE_HINT)
                print("Decide several: econquest review decide --all-pending (or --cell TABLE KEY COUNTRY, repeated) "
                      "--decision apply|hold|reject --author NAME (--approver OTHER, or --self-approved)")
            return
        print(dec.tail(args.limit).to_string(index=False) if len(dec) else "No review decisions recorded.")
        n = len(_review_pending(d, load_decisions(d), args))        # EQ-C-0048: say what is still waiting, not only what was decided
        if n:
            print(f"{n} cell(s) held by the quality gate have no decision yet (data/live/review.csv): econquest review list --pending")


def _read_review_csv(f: Path) -> pd.DataFrame:
    """data/live/review.csv as text, or a clean refusal when it is empty, unparseable or lacks the cell columns
    (AGENT-09 SEC-C-007 L2: a KeyError traceback before)."""
    try:
        rv = pd.read_csv(f, dtype=str, keep_default_na=False)
    except (pd.errors.EmptyDataError, pd.errors.ParserError, UnicodeDecodeError) as e:
        raise SystemExit(f"review: cannot read {f}: {e} (rerun econquest fetch)") from None
    missing = [c for c in ("table", "key", "country") if c not in rv.columns]
    if missing:
        raise SystemExit(f"review: {f} lacks the column(s) {', '.join(missing)} (rerun econquest fetch)")
    return rv


def _review_pending(d: Path, dec: pd.DataFrame, args) -> pd.DataFrame:
    """Cells the last fetch held (data/live/review.csv status hold) with no decision in the ledger yet."""
    f = d / "live" / "review.csv"
    if not f.exists():
        return pd.DataFrame(columns=["table", "key", "country", "seed", "live", "reason"])
    rv = _read_review_csv(f)
    rv = rv[rv.get("status", pd.Series(dtype=str)).eq("hold")] if "status" in rv.columns else rv.iloc[0:0]
    done = set(zip(dec["table"].astype(str), dec["key"].astype(str), dec["country"].astype(str))) if len(dec) else set()
    rv = rv[[(t, k, c) not in done for t, k, c in zip(rv["table"], rv["key"], rv["country"])]]
    if getattr(args, "country", None):
        rv = rv[rv["country"] == args.country]
    if getattr(args, "table", None):
        rv = rv[rv["table"] == args.table]
    return rv[[c for c in ("table", "key", "country", "seed", "live", "reason") if c in rv.columns]]


def _review_is_batch(args) -> bool:
    return bool(getattr(args, "cell", None) or getattr(args, "all_pending", False))


def _decide_cells(d: Path, args) -> list[dict]:
    """The cells of a batch `review decide` (EQ-C-0052, U06), each {"table", "key", "country", "live", "gate_status"}.
    Live value and gate status come from data/live/review.csv, so nothing is copied by hand: --all-pending takes the held
    cells with no decision yet (as `review list --pending`, --table/--country filter); --cell takes named cells, each of
    which must be held in review.csv."""
    from .ingestion.ledger import load_decisions
    if args.cell and args.all_pending:
        raise SystemExit("review decide: give --cell or --all-pending, not both")
    if args.live is not None or args.gate_status or args.key or (args.cell and (args.table or args.country)):
        raise SystemExit("review decide: with --cell/--all-pending the cells, live values and gate status come from "
                         "data/live/review.csv (--table/--country only filter --all-pending)")
    f = d / "live" / "review.csv"
    rv = _read_review_csv(f) if f.exists() else pd.DataFrame(columns=["table", "key", "country"])
    held = rv[rv["status"].eq("hold")] if "status" in rv.columns else rv.iloc[0:0]
    if args.all_pending:
        rows = _review_pending(d, load_decisions(d), args)
    else:
        want = [tuple(c) for c in args.cell]
        have = {(r["table"], r["key"], r["country"]): r for r in held.to_dict("records")}
        missing = [c for c in want if c not in have]
        if missing:
            raise SystemExit("review decide: not a held cell in data/live/review.csv: "
                             + "; ".join(" ".join(c) for c in missing) + " (econquest review list --pending)")
        rows = pd.DataFrame([have[c] for c in dict.fromkeys(want)])

    def live(v):
        try:
            return float(v)
        except (TypeError, ValueError):
            return None
    return [{"table": r["table"], "key": r["key"], "country": r["country"], "live": live(r.get("live")), "gate_status": "hold"}
            for r in rows.to_dict("records")]


def _review_batch(args, command: str, cells: list[dict], write_one=None, precheck=None, write_all=None, show=None) -> list[dict]:
    """Write one ledger decision per cell with write_one(cell) -> row, and one action-log row per cell (EQ-C-0052, U06).
    precheck(cell) runs on every cell first (raise ValueError to refuse), so a four-eyes refusal writes nothing; a refusal
    by write_one stops the batch there and says how many were recorded. Shared by every multi-cell review command.
    write_all(cells) -> rows replaces write_one with one call that checks every cell before writing any
    (feeds.record_vintage_decisions for `review approve`, HO-20261023-A-C-016): its refusal (ValueError, OSError) is
    one error row in the action log and nothing is recorded. show(row) -> the line printed per row written."""
    secrets = [os.environ.get(k, "") for k in (TOKEN_ENV, "ECONQUEST_SMTP_PASSWORD", "ECONQUEST_ALERT_WEBHOOK")]

    def log(c, code, err, i):
        a = {k: v for k, v in vars(args).items() if k not in ("fn", "cell", "all_pending", "cells")}
        a.update({k: c.get(k) for k in ("table", "key", "country", "live", "gate_status")}, batch=f"{i}/{len(cells)}")
        _record_action(args, command, code, err, secrets, extra_args=a)
    if not cells:
        print("No held cells waiting for a decision.")
        return []
    try:
        for c in cells:
            precheck and precheck(c)
    except ValueError as e:
        msg = f"{command}: {e} (nothing recorded for the {len(cells)} cell(s))"
        _record_action(args, command, 1, msg, secrets, extra_args={k: v for k, v in vars(args).items() if k != "fn"})
        raise SystemExit(msg) from None
    if write_all is not None:
        try:
            rows = write_all(cells)
        except (ValueError, OSError) as e:             # FileNotFoundError: no such vintage
            msg = f"{command}: {e}"
            _record_action(args, command, 1, msg, secrets, extra_args={k: v for k, v in vars(args).items() if k != "fn"})
            raise SystemExit(msg) from None
        for i, r in enumerate(rows, 1):
            log(r, 0, "", i)
            print(show(r) if show else "Recorded: " + ", ".join(f"{k}={v}" for k, v in r.items() if v not in ("", None)))
        print(f"{len(rows)} decision(s) recorded.")
        return rows
    rows = []
    for i, c in enumerate(cells, 1):
        try:
            rows.append(write_one(c))
        except ValueError as e:
            msg = f"{command}: {e} ({len(rows)} of {len(cells)} cell(s) recorded before this one)"
            log(c, 1, msg, i)
            raise SystemExit(msg) from None
        log(c, 0, "", i)
        print("Recorded:", ", ".join(f"{k}={v}" for k, v in rows[-1].items() if v not in ("", None)))
    print(f"{len(rows)} decision(s) recorded.")
    return rows


# ---------------------------------------------------------------- review against a saved vintage (HO-20261023-A-C-016)
# Thin wrappers over Team A's feeds.vintage_review / record_vintage_decisions / apply_vintage (EQ-A-0035): offline, the
# decision binds to the vintage id and the live value Sam reviewed, and `review apply` re-applies that same vintage.
REVIEW_TABLES = ("Inputs", "Country Profile")
APPROVE_HINT = ("Decide one: econquest review approve TABLE KEY COUNTRY [TABLE KEY COUNTRY ...] --author NAME "
                "(--approver OTHER, or --self-approved) [--decision hold|reject] [--vintage ID] [--note TEXT]")


def _approve_cells(args) -> list[dict]:
    """The positional cells of `review approve` as {"table", "key", "country"}, in order, duplicates dropped."""
    v = [str(x).strip() for x in args.cells]
    if len(v) % 3:
        raise SystemExit(f"review approve: give cells as TABLE KEY COUNTRY triples, e.g. \"Country Profile\" fx3m Brazil "
                         f"(got {len(v)} value(s), not a multiple of 3)")
    cells = list(dict.fromkeys(tuple(v[i:i + 3]) for i in range(0, len(v), 3)))
    bad = [c for c in cells if c[0] not in REVIEW_TABLES]
    if bad:
        raise SystemExit("review approve: the table of a cell is Inputs or \"Country Profile\", got "
                         + "; ".join(" ".join(c) for c in bad))
    return [{"table": t, "key": k, "country": c} for t, k, c in cells]


def _review_approve(d: Path, args) -> list[dict]:
    """`review approve`: feeds.record_vintage_decisions over every cell at once (it checks the vintage hash, that each
    cell is in the vintage's review, and four-eyes over all cells before writing any), one action-log row per row."""
    from .ingestion.feeds import record_vintage_decisions
    from .ops.identity import cli_signoff
    cells = _approve_cells(args)
    so = cli_signoff(d, args, "review") if args.decision == "apply" else None      # EQ-C-0109

    def write_all(cs):
        try:
            rows = record_vintage_decisions(d, [(c["table"], c["key"], c["country"]) for c in cs], args.author,
                                            approver=so.approver if so else args.approver, self_approved=args.self_approved,
                                            vintage_id=args.vintage, decision=args.decision, note=args.note or "")
        except ValueError as e:
            raise ValueError(str(e).replace("self_approved=True", "--self-approved")) from None
        so and rows and so.record(rows)
        return rows

    def show(r):
        return (f"Recorded: {r['table']} {r['key']} {r['country']}  decision={r['decision']} vintage_id={r['vintage_id']} "
                f"live={r['live']} approver={r.get('approver') or '-'} self_approved={r.get('self_approved') or 'no'}")
    rows = _review_batch(args, "review approve", cells, precheck=None, write_all=write_all, show=show)
    if rows and args.decision == "apply":
        print(f"Apply them (offline, no refetch): econquest review apply --vintage {rows[0]['vintage_id']}")
    return rows


def _vintage_label(vid: str, latest: str) -> str:
    return f"vintage {vid} (latest)" if vid == latest else f"vintage {vid} (not the latest; latest is {latest})"


def _review_pending_vintage(d: Path, args) -> None:
    """`review list --pending --vintage ID`: the gate-held cells of that saved vintage with feeds.vintage_review's
    `effective` column (released = an approved apply binds to this vintage or its live value; held = stays on seed)."""
    from .ingestion.feeds import latest_vintage, vintage_review
    try:
        r = vintage_review(d, args.vintage)
        latest = latest_vintage(d)
    except (ValueError, OSError) as e:
        raise SystemExit(f"review list: {e}") from None
    vid = str(r["vintage_id"].iloc[0]) if len(r) else str(args.vintage)
    held = r[r["status"] == "hold"]
    if args.country:
        held = held[held["country"] == args.country]
    if args.table:
        held = held[held["table"] == args.table]
    if not len(held):
        print(f"No held cells in {_vintage_label(vid, latest)}.")
        return
    waiting = int((held["effective"] == "held").sum())
    print(f"{_vintage_label(vid, latest)}: {len(held)} held cell(s), {waiting} with no approved apply bound to it (effective held)")
    cols = [c for c in ("table", "key", "country", "seed", "live", "reason", "decision", "approver", "decision_vintage", "effective")
            if c in held.columns]
    print(held[cols].tail(args.limit).to_string(index=False))
    if waiting:
        print(APPROVE_HINT.replace("[--vintage ID]", f"--vintage {vid}"))
    print(f"Then apply (offline, no refetch): econquest review apply --vintage {vid}")


def _review_apply(d: Path, args) -> None:
    """`review apply [--vintage ID] [--dry-run]`: feeds.apply_vintage (verifies the vintage, applies its ok cells and the
    held cells released by an approved decision bound to it; never forces). --dry-run prints feeds.vintage_review's
    effective counts and writes nothing. An older vintage is refused by apply_vintage itself (OlderVintageError,
    SEC-A-004 L2, on the resolved id, so a date id of the latest vintage passes) unless --allow-older; the rollback
    it then records (res["rollback"], rollback.json in the pre-apply snapshot) is printed (HO-20261024-A-C-003)."""
    from .ingestion.feeds import OlderVintageError, apply_vintage, latest_vintage, vintage_review
    try:
        if args.dry_run:
            r = vintage_review(d, args.vintage)
            latest = latest_vintage(d)
        else:
            res = apply_vintage(d, vintage_id=args.vintage, allow_older=args.allow_older)
    except OlderVintageError as e:                     # one line, nothing written (apply_vintage checks before any write)
        raise SystemExit(f"review apply: {' '.join(str(e).split())}; --dry-run shows it first") from None
    except (ValueError, OSError) as e:
        raise SystemExit(f"review apply: {e}") from None
    if args.dry_run:
        vid = str(r["vintage_id"].iloc[0]) if len(r) else str(args.vintage)
        counts = r["effective"].value_counts()
        print(f"Dry run: {_vintage_label(vid, latest)}: "
              + (", ".join(f"{int(n)} {k}" for k, n in counts.items()) or "no cells") + "; nothing written")
        held = r[r["status"] == "hold"]
        if len(held):
            print(held[["table", "key", "country", "seed", "live", "decision", "effective"]].to_string(index=False))
    else:
        vid, latest = res["vintage_id"], res["latest_vintage"]
        print("Applied:", res)
        live = {}
        try:                                           # the live value of each held cell, for the lines below (read-only)
            rv = vintage_review(d, vid)
            live = {(t, str(k), c): v for t, k, c, v in zip(rv["table"], rv["key"], rv["country"], rv["live"])}
        except (ValueError, OSError):
            pass
        for name in ("released", "still_held"):
            print(f"{name} ({len(res[name])}):")
            for c in res[name]:
                print("  " + " ".join(map(str, c)) + (f"  live={live[tuple(c)]}" if tuple(c) in live else ""))
        rb = res.get("rollback")
        if rb:                                         # SEC-A-004 I4: the rollback apply_vintage recorded
            print(f"rollback: {rb.get('vintage_id')} re-applied over latest {rb.get('latest_vintage')} at {rb.get('ts_utc')}"
                  + (f" by {rb['author']}" if rb.get("author") else "") + f"; recorded in {rb.get('record')}")
    if vid != latest:
        print(f"warning: {vid} is not the latest vintage ({latest}): re-applying an older vintage also re-applies its ok "
              "cells over newer values", file=sys.stderr)


def cmd_dsa(args):
    """Debt sustainability and reserve adequacy (roadmap 3.1, 3.2): fan charts around the WEO baseline, the IMF ARA metric, and the derived scorecard inputs 1.1, 1.2, 2.1."""
    from .engine import dsa as D
    from .presentation.sheets_publish import save_plan, apply_plan
    u, s = _load(args)
    d = Path(args.data); live = d / "live"
    weo_p = live / "raw_weo.csv"
    if not weo_p.exists():
        raise SystemExit("No data/live/raw_weo.csv: run `econquest fetch` first (needs api.imf.org).")
    weo = pd.read_csv(weo_p); wb = pd.read_csv(live / "raw_worldbank.csv") if (live / "raw_worldbank.csv").exists() else None
    inputs = D.load_dsa_inputs(d / "dsa_inputs.csv")
    as_of = args.as_of or pd.Timestamp.today().strftime("%Y-%m-%d")
    table, fans, diag = D.dsa_table(u, s, weo, wb, inputs, year0=args.year, paths=args.paths or 10000, as_of=as_of)
    out = Path(args.out); out.mkdir(parents=True, exist_ok=True)
    table.to_csv(out / "dsa.csv", index=False); fans.to_csv(out / "dsa_fan.csv", index=False)
    (out / "dsa_diagnostics.json").write_text(dumps(diag))
    plan = D.dsa_plan(table, fans, as_of); save_plan(plan, out / "dsa_plan.json")
    pd.set_option("display.width", 260)
    cols = ["country", "debt_now", "r_minus_g", "pb_gap", "debt_baseline_5y", "debt_median_5y", "debt_p10_5y", "debt_p90_5y", "p_debt_rising", "gfn_pct_gdp", "debt_service_pct_revenue", "fx_debt_service_24m_pct_reserves", "reserves_pct_ara", "read"]
    print(table[cols].round(2).to_string(index=False))
    missing = sorted(set(u.names) - set(table["country"]))
    if missing:
        print(f"No WEO debt history for: {', '.join(missing)}")
    print(f"Written {out / 'dsa.csv'}, dsa_fan.csv, dsa_plan.json")
    # EQ-B-0010 / HO-20261023-B-C-004: the DSA never writes data/; its scorecard inputs are an engine output that
    # Team A's ingestion gate applies.
    feeds = D.scorecard_feeds(table, retrieved=as_of, keys=tuple(args.keys),
                              vintage_id=D.dsa_vintage_id(d, as_of))     # HO-20261024-B-C-013: replayable rows for Team A's gate
    path = D.write_scorecard_feeds(feeds, out)
    print(f"Written {path}: {len(feeds)} proposed cells for {', '.join(args.keys)}; apply through the ingestion gate")
    if args.apply or args.force:
        print("--apply/--force no longer change data/ here: the ingestion quality gate applies outputs/dsa_scorecard_feeds.csv "
              "(Team A, HO-20261023-A-B-001). Nothing under data/ was changed.")
    # EQ-B-0070 / HO-20261024-B-C-008 (contract C13 eq-dsa-paths/1): correlated-shock debt and GFN fans and the DSA
    # signal, from the latest WEO pull dated on or before as_of (never a later one).
    try:
        weo_pit, weo_src = D.load_weo_as_of(d, as_of)
    except ValueError as e:
        print(f"dsa_paths.csv not written: {e}")
    else:
        run = D.run_dsa_paths(u, s, weo_pit, inputs=inputs, as_of=as_of, paths=args.paths)
        written = D.write_dsa_paths(run, D.dsa_signal(run, s), out)
        print(f"Written {written['paths']}, {written['signal'].name}, {written['meta'].name} (WEO {weo_src})")
    if args.token:
        print("Written:", apply_plan(plan, args.spreadsheet_id, args.token))


def cmd_log(args):
    """Operator action log (EQ-C-0035): `log verify` checks the hash chain (exit 1 when broken); `log tail` prints rows."""
    from .ops import actionlog as AL
    out = action_out(args)
    if args.log_cmd == "verify":
        v = AL.verify(out)
        print(f"Action log {v['path']}: {'ok' if v['ok'] else 'BROKEN'} ({v['rows']} rows)")
        for e in v["errors"]:
            print("  " + e)
        if not v["ok"]:
            raise SystemExit(1)
        return
    rows = AL.tail(out, args.n)
    if args.json:
        for r in rows:
            print(json.dumps(r, ensure_ascii=False))
    elif rows:
        for r in rows:
            print(AL.format_row(r))
    else:
        print(f"No operator actions logged in {AL.log_path(out)}.")


def _keyed_ledgers(args) -> list[tuple]:
    """(name, seal path, verify() -> errors, last row, lock) for every Team C hash-chained ledger (EQ-C-0076)."""
    from .ops import actionlog as AL, approvals as AP, client_distribution as CD, distribute as D
    from .presentation import editorial as E
    act, out = action_out(args), Path(args.out)

    def last(rows):
        rows = [r for r in rows if isinstance(r, dict) and r]
        return rows[-1] if rows else {"seq": 0, "row_hash": AP.GENESIS}
    return [("approvals", AP.seal_path(args.data), lambda: AP.verify_chain(args.data)["errors"], lambda: last(AP.read_log(args.data)),
             lambda: AP._locked(args.data)),
            ("actions", AL.seal_path(act), lambda: AL.verify(act)["errors"], lambda: last(AL.read(act)), lambda: AL._locked(act)),
            ("deliveries", D.seal_path(out), lambda: D.verify(out)["errors"], lambda: last(D.read_log(out)), lambda: D._locked(out)),
            ("editorial", E.seal_path(out), lambda: E.verify_chain(out), lambda: last(E.read_ledger(out)), lambda: E._locked(out)),
            ("client_deliveries", CD.seal_path(out), lambda: CD.verify(out)["errors"], lambda: last(CD.read_log(out)),
             lambda: CD.locked(out))]                    # EQ-C-0107 (SEC-C-018)


def cmd_ledger_key(args):
    """Keyed ledger heads, OFF by default (EQ-C-0076, D4): `status` shows the switch, the key source and each ledger's
    seal; `init` prints the commands Sam runs (it never generates or stores a key); `seal` seals the current heads of
    ledgers whose chain verifies (needed once after switching the option on)."""
    from .ops import ledger_key as LK
    if args.lk_cmd == "init":
        print(LK.init_instructions())
        return
    if args.lk_cmd in ("drill", "escrow-check"):          # EQ-C-0084, team/runbooks/C-ledger-key.md
        from .ops import ledger_key_drill as LD
        if args.lk_cmd == "drill":
            ok = LD.drill(args.data, args.out, act_dir=action_out(args), keep=args.keep)["ok"]
        else:
            ok = LD.escrow_check(args, LD.read_backup_key()) == 0
        if not ok:
            raise SystemExit(1)
        return
    on, where = LK.config_state()
    try:
        key, src = LK.key_source()
        kdesc = f"from {src}, key id {LK.key_id(key)}" if key else "none ($" + LK.ENV + f" unset, no Keychain item '{LK.SERVICE}')"
    except LK.LedgerKeyError as e:
        key, kdesc = None, f"unusable: {e}"
    if args.lk_cmd == "status":
        print(f"Keyed ledger heads: {'ON' if on else 'off'} ({where})")
        print(f"Key: {kdesc}")
        for name, sp, verify, tip, _lock in _keyed_ledgers(args):
            t = tip()
            errs = [e for e in verify() if e.startswith(LK.PREFIX)] if on else []
            seal = "present" if sp.exists() else "absent"
            print(f"  {name:<11} seq {t.get('seq')}  seal {seal}  " + ("; ".join(e[len(LK.PREFIX):] for e in errs) if errs else ("ok" if on else "-")))
        return
    # seal
    if not on:
        raise SystemExit(f"ledger-key seal: keyed heads are off ({where}); see econquest ledger-key init")
    if key is None:
        raise SystemExit(f"ledger-key seal: no usable key ({kdesc}); see econquest ledger-key init")
    bad = 0
    for name, sp, verify, tip, lock in _keyed_ledgers(args):
        with lock():                                      # no append can slip in between the verify and the seal
            errs = verify(); chain = [e for e in errs if not e.startswith(LK.PREFIX)]
            seal_errs = [e for e in errs if e.startswith(LK.PREFIX)]
            t = tip()
            if chain:
                bad += 1; print(f"  {name}: chain does not verify, not sealed: {chain[0]}"); continue
            if not seal_errs:
                print(f"  {name}: {'sealed already' if sp.exists() else 'empty, nothing to seal'}"); continue
            if sp.exists() and not args.reseal:
                bad += 1; print(f"  {name}: existing seal fails ({seal_errs[0][len(LK.PREFIX):]}); not resealed. Find out "
                                "why first; --reseal overwrites it"); continue
            LK.write_seal(name, sp, t.get("seq") or 0, t.get("row_hash"), key)
            print(f"  {name}: sealed at seq {t.get('seq')}")
    if bad:
        raise SystemExit(1)


# ---------------------------------------------------------------- run gate for unattested hand-entered cells (EQ-C-0034)
# The one place the policy lives. Values: warn (print counts and the fix, carry on), block (exit 3 before the command
# runs, so before any Sheets call), off. Keys are command names; "sheets_write" is every invocation that would write the
# workbook (publish --write and every writer with --write/--token-file, never --dry-run), and "<cmd>:write" overrides it
# for one writer. Sam has not chosen yet (EQ-C-0034): these are the recommended defaults. Overrides, later wins:
#   <home>/ops.json  {"run_gate": "warn"}  or  {"run_gate": {"publish:write": "warn", "run": "block"}}
#   $ECONQUEST_RUN_GATE  "warn" | "block" | "off"  or  "run=block,sheets_write=warn"
# A plain value sets every key. --allow-unattested on one invocation proceeds past a block and is recorded in the action log.
RUN_GATE_ENV = "ECONQUEST_RUN_GATE"
RUN_GATE_MODES = ("warn", "block", "off")
RUN_GATE_DEFAULT = {
    "run": "warn", "stress": "warn", "record": "warn", "report": "warn", "monitor": "warn", "notes": "warn", "briefs": "warn",
    "cds": "warn", "arbitrage": "warn",                                        # read cds_quotes / prediction_markets directly
    "publish": "warn", "benchmark": "warn", "garch": "warn", "econ": "warn", "dsa": "warn",   # writers saving a plan only
    "audit": "off",                                                            # reports the unattested count itself
    "sheets_write": "block",
}
RUN_GATE_EXIT = 3


class RunGateBlocked(SystemExit):
    """Exit RUN_GATE_EXIT; the action log records the reason."""
    reason = "run gate: blocked on unattested hand-entered cells"
WRITER_COMMANDS = ("publish", "benchmark", "record", "audit", "garch", "econ", "dsa")


def _home_of(args) -> Path:
    out = getattr(args, "out", None)
    return Path(out).expanduser().resolve().parent if out else HOME_DIR


def _gate_entries(spec, where: str) -> dict:
    if isinstance(spec, str) and "=" not in spec:
        spec = spec.strip().lower()
        if spec not in RUN_GATE_MODES:
            raise SystemExit(f"run gate: {where} must be one of {', '.join(RUN_GATE_MODES)}, got {spec!r}")
        return {k: spec for k in RUN_GATE_DEFAULT} | {"*": spec}
    if isinstance(spec, str):
        spec = dict(p.split("=", 1) for p in spec.split(",") if "=" in p)
    if not isinstance(spec, dict):
        raise SystemExit(f"run gate: {where} must be a mode or a mapping of command to mode")
    out = {}
    for k, v in spec.items():
        v = str(v).strip().lower()
        if v not in RUN_GATE_MODES:
            raise SystemExit(f"run gate: {where} {k!r} must be one of {', '.join(RUN_GATE_MODES)}, got {v!r}")
        out[str(k).strip()] = v
    return out


def run_gate_policy(home=None, env=None) -> dict:
    """Effective policy: RUN_GATE_DEFAULT, then <home>/ops.json "run_gate", then $ECONQUEST_RUN_GATE."""
    pol = dict(RUN_GATE_DEFAULT)
    p = Path(home or HOME_DIR) / "ops.json"
    if p.exists():
        try:
            cfg = json.loads(p.read_text(encoding="utf-8"))
        except (OSError, json.JSONDecodeError) as e:
            raise SystemExit(f"run gate: cannot read {p}: {e}") from None
        if isinstance(cfg, dict) and cfg.get("run_gate") is not None:
            pol.update(_gate_entries(cfg["run_gate"], f"{p} run_gate"))
    raw = (os.environ if env is None else env).get(RUN_GATE_ENV, "").strip()
    if raw:
        pol.update(_gate_entries(raw, f"${RUN_GATE_ENV}"))
    return pol


def gate_mode(policy: dict, cmd: str, writes: bool) -> tuple[str, str]:
    """(mode, the policy key that decided it) for one invocation."""
    if writes:
        for k in (f"{cmd}:write", "sheets_write"):
            if k in policy:
                return policy[k], k
    if cmd in policy:
        return policy[cmd], cmd
    return policy.get("*", "off"), "*"


def _unattested_counts(data_dir) -> dict[str, int]:
    from collections import Counter
    from .ingestion.ledger import unattested_cells
    return dict(sorted(Counter(c["table"] for c in unattested_cells(Path(data_dir))).items()))


def _gate_text(counts: dict, mode: str, key: str, label: str) -> str:
    n = sum(counts.values())
    per = ", ".join(f"{f}.csv {c}" for f, c in counts.items())
    first = next(iter(counts), "adjustments")
    return (f"{n} hand-entered cell(s) are not attested ({per}).\n"
            f"  list them:  econquest attest --list [--file {first}]\n"
            f"  attest:     econquest attest --file {first} --author NAME --approver OTHER   (or --self-approved)\n"
            f"  policy:     run gate '{mode}' for {label} (key '{key}'; set in ops.json run_gate or ${RUN_GATE_ENV}); "
            f"--allow-unattested proceeds once and is recorded in the action log")


def _gate_warning(counts: dict, label: str) -> str:
    """The warn-mode message: one line (usability U02, EQ-C-0063). A block keeps the full _gate_text."""
    return (f"warning: {sum(counts.values())} hand-entered cell(s) not attested; {label} continues (run gate 'warn'). "
            f"List and fix: econquest attest --list")


def run_gate(args, writes: bool, log_override=None) -> dict | None:
    """Warn or block (SystemExit RUN_GATE_EXIT) when hand-entered cells are unattested. Returns what it found."""
    cmd = getattr(args, "cmd", "")
    if not hasattr(args, "allow_unattested"):
        return None
    mode, key = gate_mode(run_gate_policy(_home_of(args)), cmd, writes)
    if mode == "off":
        return None
    label = f"{cmd} --write" if writes else cmd
    try:
        counts = _unattested_counts(args.data)
    except (ValueError, OSError) as e:                 # cannot tell: a block fails closed, a warning says so
        if mode == "block" and not args.allow_unattested:
            print(f"run gate: blocked {label}: cannot check attestations in {args.data}: {e}. Nothing was sent to Sheets.", file=sys.stderr)
            raise RunGateBlocked(RUN_GATE_EXIT) from None
        print(f"warning: run gate could not check attestations in {args.data}: {e}", file=sys.stderr)
        return None
    if not counts:
        return {"mode": mode, "key": key, "counts": {}}
    found = {"mode": mode, "key": key, "counts": counts, "total": sum(counts.values()), "command": label}
    if args.allow_unattested:
        print(f"run gate: --allow-unattested: proceeding with {found['total']} unattested hand-entered cell(s) "
              f"({', '.join(f'{f} {c}' for f, c in counts.items())}); policy was '{mode}'; recorded in the action log", file=sys.stderr)
        if log_override:
            log_override(found)
        return found
    if mode == "block":
        print(f"run gate: blocked {label}: " + _gate_text(counts, mode, key, label) + "\nNothing was sent to Sheets.", file=sys.stderr)
        raise RunGateBlocked(RUN_GATE_EXIT)
    print(_gate_warning(counts, label), file=sys.stderr)
    return found


def _gated(name: str) -> bool:
    return name in RUN_GATE_DEFAULT or name in WRITER_COMMANDS


# ---------------------------------------------------------------- restricted-source gate (SEC-A-006 M1, HO-20261024-A-C-007)
# Applied cells whose value came from Yahoo / yfinance or a non-commercial / personal licence (Team A's
# audit.restricted_source_cells) must not reach a publish. `run`, `publish` without a write and `publish-preview`
# print restricted_warning(cells) on stderr and carry on; every invocation that would write the workbook (publish
# --write / --token-file, and any other writer with --write) is refused before the token lookup, so nothing is sent
# to Sheets. A check that raises fails closed on a write. No override flag: Sam's 2026-10-23 decision (EQ-A-0040)
# gives no basis for one. Scheduled jobs (ops/jobs.py) and GUI jobs run `econquest ...` through main(), so they
# hit the same refusal.
RESTRICTED_WARN_COMMANDS = ("run", "publish", "publish-preview")


class RestrictedSourceBlocked(RunGateBlocked):
    """Exit RUN_GATE_EXIT; the action log records the reason."""
    reason = "restricted-source gate: blocked on Yahoo / non-commercial cells (SEC-A-006 M1)"


def _restricted_cells(data_dir):
    from .ingestion.audit import restricted_source_cells
    return restricted_source_cells(data_dir)


def restricted_gate(args, writes: bool) -> int | None:
    """Warn (run, publish, publish-preview) or refuse (any workbook write) while restricted-source cells are applied.
    Returns the number of cells found, or None when the command is not gated or the check could not run (warn only)."""
    cmd = getattr(args, "cmd", "")
    if not writes and cmd not in RESTRICTED_WARN_COMMANDS:
        return None
    label = f"{cmd} --write" if writes else cmd
    try:
        cells = _restricted_cells(args.data)
    except Exception as e:                             # noqa: BLE001 - cannot tell: a write fails closed
        if writes:
            print(f"restricted-source gate: blocked {label}: cannot check {args.data} for restricted-source cells "
                  f"({type(e).__name__}: {e}). Nothing was sent to Sheets.", file=sys.stderr)
            raise RestrictedSourceBlocked(RUN_GATE_EXIT) from None
        print(f"warning: restricted-source gate could not check {args.data}: {type(e).__name__}: {e}", file=sys.stderr)
        return None
    if cells is None or cells.empty:
        return 0
    from .ingestion.audit import restricted_warning
    print(restricted_warning(cells), file=sys.stderr)
    if writes:
        print(f"restricted-source gate: blocked {label}: {len(cells)} applied cell(s) hold values from a restricted "
              f"source. Nothing was sent to Sheets. There is no override: replace them first "
              f"(econquest fetch --only fx --apply on the Mac).", file=sys.stderr)
        raise RestrictedSourceBlocked(RUN_GATE_EXIT)
    return len(cells)


# ---------------------------------------------------------------- operator action log (EQ-C-0035)
ACTOR_FLAGS = ("author", "reviewer", "publisher", "by", "approver", "actor")


def _will_write(args) -> bool:
    """The invocation would write the workbook (decided from the flags, before any token lookup)."""
    return (hasattr(args, "token_file") and not getattr(args, "dry_run", False)
            and bool(getattr(args, "token_file", None) or getattr(args, "write", False)))


def action_label(args, writes: bool) -> str | None:
    """The action-log name of this invocation, or None when it is not an operator action that is logged."""
    cmd = getattr(args, "cmd", "")
    if cmd == "review":
        if args.review_cmd == "apply":                 # HO-20261023-A-C-016: writes indicators.csv/countries.csv
            return None if args.dry_run else "review apply"
        if args.review_cmd == "legacy-reset":          # HO-20261025-A-C-018: appends ledger hold rows
            return None if args.dry_run else "review legacy-reset"
        # review approve and a batch decide log one row per cell themselves (_review_batch)
        return "review decide" if args.review_cmd == "decide" and not _review_is_batch(args) else None
    if cmd == "attest":                                # EQ-C-0074: a dry run writes nothing, not even this log
        if args.list or getattr(args, "dry_run", False):
            return None
        return "attest batch" if _attest_is_batch(args) else "attest"
    if cmd == "change":
        return f"change {args.change_cmd}" if args.change_cmd in ("propose", "approve", "reject", "apply", "baseline") else None
    if cmd == "editorial":
        return f"editorial {args.ed_cmd}"
    if cmd == "archive":                               # EQ-C-0154: only the commands that write the archive
        return f"archive {args.ar_cmd}" if args.ar_cmd in ("add", "correct") else None
    if cmd == "distribute":
        return {"queue": "distribute queue", "send": "distribute send --send" if getattr(args, "send", False) else None}.get(args.dist_cmd)
    if cmd == "next":                                  # EQ-C-0092: only --run does anything
        return ("next --run" + (" --apply-fx" if args.apply_fx else "") + (" --apply-prices" if args.apply_prices else "")
                if args.run else None)
    if cmd == "fetch":
        return "fetch --apply" if (args.apply or args.force) else None
    if cmd == "schedule":
        return f"schedule {args.action}" if args.action in ("install", "uninstall") else None
    if cmd == "fit-hazard":
        return "fit-hazard --apply" if args.apply else None
    if cmd == "market":                                # HO-20261023-A-C-015: the commands that write data/
        if args.market_cmd == "gate" or (args.market_cmd == "import" and args.init_map) or getattr(args, "dry_run", False):
            return None
        return f"market {args.market_cmd}"
    if cmd == "mac-pull":                              # EQ-C-0073: run pulls and writes data/; plan/status/report do not
        return "mac-pull run" if args.mp_cmd == "run" else None
    if cmd == "crag":                                  # HO-20261025-A-C-003: only --apply changes live files
        return "crag update --apply" if args.apply else None
    if cmd == "vendor":                                # HO-20261023-A-C-021: only pull saves a snapshot; status and test write nothing
        if args.vendor_cmd == "snapshots" and args.save:   # EQ-C-0117
            return "vendor snapshots --save"
        if args.vendor_cmd == "usage" and args.record:
            return "vendor usage --record"
        if args.vendor_cmd == "golive":                # HO-20261025-A-C-023: capture saves a snapshot; the rest write files only
            return "vendor golive capture" if args.golive_cmd == "capture" else None
        return "vendor pull" if args.vendor_cmd == "pull" else None
    if cmd == "client-export":                         # EQ-C-0107 (SEC-C-018): every build attempt is logged; --verify-log reads only
        return None if args.verify_log else ("client-export --workbook" if args.workbook else "client-export")
    if cmd == "overlay":                               # EQ-C-0161: add/approve/withdraw append to the overlay ledger
        from .presentation.overlay_view import action_label as overlay_label
        return overlay_label(args)
    if cmd == "client-outbox":                         # EQ-C-0145: build/send/reset write the local sandbox outbox; verify reads only
        return None if args.outbox_cmd == "verify" else f"client-outbox {args.outbox_cmd}" + (" --sandbox" if args.sandbox else "")
    if writes:
        return f"{cmd} --write"
    return None


def _actor(args) -> tuple[str, str]:
    for k in ACTOR_FLAGS:
        v = getattr(args, k, None)
        if isinstance(v, str) and v.strip():
            return v.strip(), "flag"
    import getpass
    try:
        return os.environ.get("USER") or getpass.getuser(), "os"
    except Exception:                                  # noqa: BLE001 - no user name is not an error
        return "", "os"


def _versions(args) -> dict:
    from . import __version__
    v = {"code_version": __version__}
    try:
        from .versioning import code_hash
        v["code_hash"] = code_hash()
    except Exception:                                  # noqa: BLE001 - the log row matters more than the hash
        pass
    rid = getattr(args, "run_id", None)
    if rid:
        v["run_id"] = rid
    return v


def action_out(args) -> Path:
    """The outputs/ folder whose store/ holds the action log: --out when given, else the outputs/ beside a --data
    folder that was given (so the log stays with the install the command acted on), else the default outputs/."""
    out, data = str(getattr(args, "out", DEFAULT_OUT)), str(getattr(args, "data", DEFAULT_DATA))
    if out == str(DEFAULT_OUT) and data != str(DEFAULT_DATA):
        return Path(data).parent / "outputs"
    return Path(out)


def _record_action(args, command: str, code: int, error: str, secrets, extra_args: dict | None = None, strict: bool = False) -> None:
    """Append to the action log; a failure to log is reported on stderr and never changes the command's outcome, except
    with strict=True (the run-gate override): an override that cannot be recorded is refused (AGENT-09, SEC-C-004)."""
    from .ops import actionlog as AL
    try:
        actor, src = _actor(args)
        a = dict(vars(args)) if extra_args is None else extra_args
        AL.append(action_out(args), command, a, actor=actor, actor_source=src, outcome="ok" if code == 0 else "error",
                  exit_code=code, error=error, versions=_versions(args), secrets=secrets)
    except Exception as e:                             # noqa: BLE001
        if strict:
            print(f"run gate: --allow-unattested refused: the override could not be recorded in {AL.log_path(action_out(args))}: {e}", file=sys.stderr)
            raise RunGateBlocked(RUN_GATE_EXIT) from None
        print(f"warning: could not write the action log {AL.log_path(action_out(args))}: {e}", file=sys.stderr)


def _exit_code(e: SystemExit) -> tuple[int, str]:
    if isinstance(e, RunGateBlocked):
        return RUN_GATE_EXIT, e.reason
    if e.code is None:
        return 0, ""
    if isinstance(e.code, int):
        return e.code, ""
    return 1, str(e.code)


def main(argv=None):
    ap = argparse.ArgumentParser(prog="econquest", description="EconQuest sovereign tail-risk engine")
    ap.add_argument("--data", default=str(DEFAULT_DATA), help="input folder (default: %(default)s)")
    ap.add_argument("--out", default=str(DEFAULT_OUT), help="outputs folder (default: %(default)s)")
    from . import __version__ as _ver                      # EQ-C-0048: which release is installed
    ap.add_argument("--version", action="version", version=f"econquest {_ver}")
    sub = ap.add_subparsers(dest="cmd", required=True)
    r = sub.add_parser("run", help="full pipeline on the snapshot; writes outputs and the dashboard")
    r.add_argument("--paths", type=int); r.add_argument("--seed", type=int); r.add_argument("--override", choices=["Model", "All stressed", "All crisis"])
    r.add_argument("--label", default="base"); r.add_argument("--stress", action="store_true"); r.add_argument("--stress-paths", type=int, default=None); r.add_argument("--scenario", nargs="*", help="scenario keys for --stress (default: all non-historical)")
    r.add_argument("--backtest", action="store_true"); r.add_argument("--live-markets", action="store_true"); r.add_argument("--no-sobol", action="store_true")
    r.add_argument("--no-paths", action="store_true", help="do not archive simulation paths")
    r.add_argument("--as-of", type=_as_of_arg, help="model date YYYY-MM-DD (default: settings as_of, else today); fixes the run so a replay gives the same numbers")
    r.add_argument("--vintage", help="replay the inputs frozen with this fetch vintage (id, or a date for that day's latest); not with --live-markets"); r.set_defaults(fn=cmd_run)
    st = sub.add_parser("stress", help="run the scenario library (data/scenarios.json): the paper's A, B, C plus historical episodes; writes outputs/scenario_library.csv"); st.add_argument("--scenario", nargs="*", help="scenario keys (default: all)"); st.add_argument("--paths", type=int); st.add_argument("--scale", type=float, default=1.0, help="severity scale applied to every shock (1 = as defined)")
    st.add_argument("--as-of", type=_as_of_arg, help="model date YYYY-MM-DD (default: settings as_of, else today); fixes the runs so a replay gives the same numbers"); st.set_defaults(fn=cmd_stress)
    sl = sub.add_parser("scenarios", help="list the scenario library"); sl.add_argument("--shocks", action="store_true", help="print each scenario's shocks"); sl.set_defaults(fn=cmd_scenarios)
    rs = sub.add_parser("reverse-stress", help="smallest severity of each scenario and single factor (spreads, FX, LGD, PD multiplier, loading, downgrades) that breaches a book limit in data/limits.json; writes outputs/reverse_stress.json and .csv")
    rs.add_argument("--measure", default=None, choices=["var99_mm", "es99_mm", "lvar99_mm", "expected_loss_mm"], help="run one measure only (default: var99_mm, es99_mm and lvar99_mm, each against its own book limit, first to breach flagged)"); rs.add_argument("--scenario", nargs="*", help="scenario keys (default: all)"); rs.add_argument("--factor", nargs="*", choices=list(SINGLE_FACTORS))
    rs.add_argument("--paths", type=int, help="Monte Carlo paths per run (default 20000)"); rs.add_argument("--scale-max", type=float, default=4.0, help="largest scenario scale searched"); rs.add_argument("--scenarios-only", action="store_true"); rs.add_argument("--factors-only", action="store_true")
    rs.add_argument("--as-of", type=_as_of_arg, help="model date YYYY-MM-DD (default: settings as_of, else today); fixes the runs so a replay gives the same numbers"); rs.set_defaults(fn=cmd_reverse_stress)
    a = sub.add_parser("arbitrage", help="prediction-market arbitrage monitor"); a.add_argument("--live-markets", action="store_true"); a.set_defaults(fn=cmd_arbitrage)
    b = sub.add_parser("backtest", help="Kupiec, Christoffersen, Acerbi-Szekely on a history CSV (loss, var, es)")
    b.add_argument("--history", default=str(DEFAULT_DATA / "backtest_history.csv")); b.add_argument("--alpha", type=float, default=0.99); b.set_defaults(fn=cmd_backtest)
    f = sub.add_parser("fit-hazard", help="recalibrate the hazard model on a sovereign default panel (Firth logit, out-of-sample test, report)")
    f.add_argument("--panel"); f.add_argument("--build-panel", action="store_true"); f.add_argument("--fetch", action="store_true"); f.add_argument("--defaults")
    f.add_argument("--features"); f.add_argument("--start", type=int, default=1980); f.add_argument("--end", type=int, default=None, help="last row year t (default: last episode year - 1)")
    f.add_argument("--oos-start", type=int); f.add_argument("--report"); f.add_argument("--apply", action="store_true", help="propose the fit as a change (see econquest change)")
    f.add_argument("--author", help="who proposes the change (required with --apply)")
    cd = sub.add_parser("cds", help="CDS-implied PDs and model-fair spreads from data/cds_quotes.csv"); cd.set_defaults(fn=cmd_cds)
    bmk = sub.add_parser("benchmark", help="PD benchmarks: model vs rating, spread, CDS and prediction-market PDs, with a dated history and scoring")
    bmk.add_argument("--paths", type=int); bmk.add_argument("--as-of"); bmk.add_argument("--horizons", default="12m", help="comma list of 12m,6m,3m"); _token_args(bmk); bmk.add_argument("--spreadsheet-id", default="1w4OLCkv4EvDFgaO6MBOipAuY2fjAlCQJ-OjtmHJshQY"); bmk.set_defaults(fn=cmd_benchmark)
    f.add_argument("--resume", metavar="RUN_ID", help="with --fetch: resume a staged panel_history run (data/panel/staging/RUN_ID)")
    f.add_argument("--weo-vintages", help="with --fetch: WEO releases, '2007-10:2026-10' or a comma list (default Oct 2007 to the latest)")
    f.add_argument("--min-auc", type=float, default=0.75); f.add_argument("--min-events", type=int, default=30); f.set_defaults(fn=cmd_fit_hazard)
    h = sub.add_parser("hmm", help="fit the 3-state Gaussian HMM on a series CSV (spread, fx 3m, reserves 3m) or a demo"); h.add_argument("--series"); h.set_defaults(fn=cmd_hmm)
    pub = sub.add_parser("publish", help="write the run into the workbook as values (needs --write or --token-file) or save the plan")
    pub.add_argument("--paths", type=int); pub.add_argument("--seed", type=int); pub.add_argument("--mc-rows", type=int, default=2000, help="MC paths shown on the MC tab (use 100 when applying through the Sheets connector)"); _token_args(pub)
    pub.add_argument("--no-garch", action="store_true", help="skip the GARCH and Econometrics tabs"); pub.add_argument("--no-econ", action="store_true", help="skip the Econometrics tab")
    pub.add_argument("--ideas", action="store_true", help="also write the 'Trade Ideas' tab: hit rate and P&L by quarter from outputs/idea_log.csv (illustrative, Tier 3; create the tab first)")
    pub.add_argument("--rv", action="store_true", help="also write the 'Weekly RV' tab: bond rich/cheap vs model and CDS curves from outputs/bond_rv.csv and outputs/cds_curves.csv (diagnostic; create the tab with columns to AN first)"); pub.add_argument("--spreadsheet-id", default="1w4OLCkv4EvDFgaO6MBOipAuY2fjAlCQJ-OjtmHJshQY"); pub.set_defaults(fn=cmd_publish)
    exp = sub.add_parser("export", help="local copies of the desk outputs without Google (EQ-C-0122)")   # MVP M6
    exps = exp.add_subparsers(dest="export_cmd", required=True)
    xl = exps.add_parser("xlsx", help="write the workbook as .xlsx in the Sheets publish layout (same tabs, cells and numbers as `publish --dry-run`); offline, no token")
    xl.add_argument("--out", dest="dest", help="xlsx path (default <out>/workbook/econquest-<as_of>.xlsx)")
    xl.add_argument("--check", action="store_true", help="read the file back and compare every cell with the plan and the headline figures with run_latest.json; exit 1 on any mismatch")
    xl.add_argument("--verify", metavar="PATH", help="only check an existing export (needs its .plan.json beside it)")
    xl.add_argument("--no-garch", action="store_true", help="skip the GARCH and Econometrics tabs (faster)"); xl.add_argument("--no-econ", action="store_true", help="skip the Econometrics tab")
    xl.add_argument("--mc-rows", type=int, default=2000, help="MC paths shown on the MC tab"); xl.set_defaults(fn=cmd_export)
    gu = sub.add_parser("gui", help="local browser app: charts, tables, analyst workbench and buttons for fetch/run/garch/econ/publish")
    gu.add_argument("--host", default="127.0.0.1"); gu.add_argument("--port", type=int, default=8765); gu.add_argument("--no-browser", action="store_true"); gu.set_defaults(fn=cmd_gui)
    fe = sub.add_parser("fetch", help="pull live inputs (IMF WEO via imf-reader/weo, World Bank via wbgapi, BIS SDMX; FX from BIS WS_XRU and the ECB euro reference rates) into data/live")
    fe.add_argument("--only", help="comma list of feeds: weo,worldbank,bis,fx,imf (default all five; fx = BIS WS_XRU and ECB EXR reference rates; bis also pulls bis_xru; imf = IMF SDMX, internal research use only, never in client output); named only, not in the default: oecd, eurostat, cb (cb = central banks / national statistics, unverified, held by the gate; docs/runbooks/A-central-bank-adapters.md); single feeds: bis_xru, ecb_exr, bis_cbs, worldbank_history, imf_sdmx. Yahoo Finance is not a desk feed"); fe.add_argument("--year", type=int); fe.add_argument("--weo-version", help="e.g. October,2026")
    fe.add_argument("--apply", action="store_true", help="overwrite seed values in indicators.csv / countries.csv with live values that pass the quality gate"); fe.add_argument("--top", type=int, default=25)
    fe.add_argument("--max-change", type=float, default=0.5, help="hold a value whose change vs seed exceeds this fraction (default 0.5)"); fe.add_argument("--force", action="store_true", help="apply held values too (needs --author and --approver, or --self-approved)")
    fe.add_argument("--author", help="who applies the values (recorded in data/live/review_ledger.csv; required with --force)")
    fe.add_argument("--approver", help="second person approving forced cells (four-eyes; must differ from --author)")
    fe.add_argument("--self-approved", action="store_true", help="single-operator mode: the author approves their own forced cells, recorded as self_approved=yes")
    fe.add_argument("--first-install", action="store_true", help="genuine first install: import review.csv decisions into a new review ledger although vintages exist (otherwise a missing ledger stops the fetch; EQ-A-0103)"); fe.set_defaults(fn=cmd_fetch)
    mk = sub.add_parser("market", help="market data (CDS, curves, EMBI, FX) snapshots under data/live/market: import a vendor CSV export, enter attested hand-typed quotes, run the market gate, write data/cds_quotes.csv (runbook docs/runbooks/A-market-data.md)")
    mks = mk.add_subparsers(dest="market_cmd", required=True)
    m = mks.add_parser("import", help="import a Bloomberg or LSEG CSV export through the ticker map (data/live/market/ticker_map.csv, verified rows only) and save a snapshot")
    m.add_argument("file", nargs="?", help="the exported CSV"); m.add_argument("--profile", choices=["bloomberg", "lseg"]); m.add_argument("--licence", help="licence the data is used under (required; recorded on every quote)")
    m.add_argument("--map", help="ticker map CSV (default data/live/market/ticker_map.csv)"); m.add_argument("--init-map", action="store_true", help="create data/live/market/ticker_map.csv from the template (never overwrites) and stop")
    m = mks.add_parser("enter", help="enter hand-typed quotes from a CSV (asof, instrument, iso, currency, tenor_y, field, value[, unit, doc_clause, vendor_ticker]) with four-eyes attestation, and save a snapshot")
    m.add_argument("file"); m.add_argument("--author", required=True, help="who typed the quotes")
    m.add_argument("--approver", help="second person who checked them (four-eyes; must differ from --author)")
    m.add_argument("--self-approved", action="store_true", help="single-operator mode: the author approves their own quotes, recorded as self_approved=yes (as fetch --self-approved)"); m.add_argument("--note")
    m = mks.add_parser("gate", help="market quality gate on the latest quotes vs the previous snapshot (stale, range, curve, CIP, jump, basis); prints holds, writes outputs/market_gate.csv")
    m.add_argument("--as-of", "--asof", dest="asof", type=_as_of_arg, help="only snapshots saved and quotes dated on or before YYYY-MM-DD (default: everything, latest quote date)")
    m.add_argument("--strict", action="store_true", help="exit 1 when any series is held"); m.add_argument("--top", type=int, default=50)
    m = mks.add_parser("cds-quotes", help="write data/cds_quotes.csv (atomically) from the latest CDS quotes, leaving out every series the market gate holds")
    m.add_argument("--as-of", "--asof", dest="asof", type=_as_of_arg, help="point-in-time: only snapshots saved and quotes dated on or before YYYY-MM-DD")
    m.add_argument("--dest", help="file to write (default <data>/cds_quotes.csv)"); m.add_argument("--dry-run", action="store_true", help="print the rows, write nothing"); m.add_argument("--top", type=int, default=50)
    m = mks.add_parser("cds-snapshots", help="gated export of the stored CDS quotes to data/market/cds_snapshots.csv (Team B's CDS curves): appends rows that passed the market gate and the attestation check, reports each dropped row")
    m.add_argument("--snapshot", help="export only this snapshot id (default: every stored snapshot; rerunning is safe)")
    m.add_argument("--dry-run", action="store_true", help="report what would be appended, write nothing"); m.add_argument("--top", type=int, default=50)
    mk.set_defaults(fn=cmd_market)
    vd = sub.add_parser("vendor", help="licensed vendor adapters (Bloomberg BLPAPI, LSEG Data Library): PAID ROADMAP FEATURE, OFF BY DEFAULT; status of the licence gate, a dry-run test pull, or a pull that saves a snapshot (runbook docs/runbooks/A-licensed-vendors.md)")
    vds = vd.add_subparsers(dest="vendor_cmd", required=True)
    v = vds.add_parser("check", help="onboarding wizard for the day a licence arrives (EQ-C-0108): 1 credentials by presence only and the licence entitlement, 2 the licence scope row in data/licences.csv via econquest change, 3 ticker verification (map + fixture, no session), 4 a first gated snapshot, dry run only; exit 0 when all four are done")
    v.add_argument("vendor", choices=["bloomberg", "lseg"]); v.add_argument("--ticker", action="append", help="identifier to resolve through the ticker map (repeat)")
    v.add_argument("--fixture", help="CSV of what the terminal showed: vendor_ticker plus any of instrument, iso, currency, tenor_y, doc_clause, unit")
    v.add_argument("--as-of", "--asof", dest="asof", type=_as_of_arg, help="daily close for the dry run (YYYY-MM-DD)")
    v.add_argument("--dry-run-pull", action="store_true", help="step 4: open a session, pull and gate in memory; saves nothing")
    v.add_argument("--propose-row", action="store_true", help="step 2: record the tight register row as a change proposal (needs --author; changes nothing until approved and applied)")
    v.add_argument("--author", help="who proposes the register row"); v.add_argument("--json", action="store_true")
    v.add_argument("--data", default=argparse.SUPPRESS, help="input folder (same as the top-level --data)")
    v = vds.add_parser("status", help="one row per adapter: package, licence (ok / expired / not configured), licence id, scope, expiry, usable, problems; opens no session")
    v.add_argument("--data", default=argparse.SUPPRESS, help="input folder (same as the top-level --data)")
    v = vds.add_parser("test", help="dry run: pull through the adapter and run the market gate in memory; saves nothing")
    v.add_argument("vendor", choices=["bloomberg", "lseg"]); v.add_argument("--ticker", action="append", required=True, help="vendor identifier with a verified ticker map row (repeat)")
    v.add_argument("--as-of", "--asof", dest="asof", type=_as_of_arg, help="the daily close of YYYY-MM-DD (default: the vendor's current value)")
    v.add_argument("--data", default=argparse.SUPPRESS, help="input folder (same as the top-level --data)")
    v = vds.add_parser("pull", help="pull, save a snapshot under data/live/market, gate it and append the CDS rows that pass to data/market/cds_snapshots.csv")
    v.add_argument("vendor", choices=["bloomberg", "lseg"]); v.add_argument("--ticker", action="append", required=True, help="vendor identifier with a verified ticker map row (repeat)")
    v.add_argument("--field", action="append", help="vendor field (repeat; default: the ticker map's vendor_field)")
    v.add_argument("--as-of", "--asof", dest="asof", type=_as_of_arg, help="the daily close of YYYY-MM-DD (default: the vendor's current value)")
    v.add_argument("--start", type=_as_of_arg, help="daily closes from YYYY-MM-DD (with --end)"); v.add_argument("--end", type=_as_of_arg, help="daily closes to YYYY-MM-DD (with --start)")
    v.add_argument("--no-export", action="store_true", help="save and gate only; skip the gated CDS export")
    v.add_argument("--data", default=argparse.SUPPRESS, help="input folder (same as the top-level --data)")
    v = vds.add_parser("golive", help="licensed go-live kit (EQ-A-0107, runbook docs/runbooks/A-licensed-go-live.md; paid roadmap feature, off by default): verify | capture | register-patch | schedule | layer2-preview, each with python -m econquest.ingestion.market.vendors.golive's own flags passed straight through (econquest vendor golive capture -- --help lists them)")
    v.add_argument("golive_cmd", choices=GOLIVE_CMDS, help="golive subcommand")
    v.add_argument("golive_args", nargs=argparse.REMAINDER, help="its flags, unchanged (--data defaults to the top-level --data)")
    from .ops.vendor_ops import add_cli as _vendor_ops_cli   # EQ-C-0117: audit, usage, snapshots
    _vendor_ops_cli(vds)
    vd.set_defaults(fn=cmd_vendor)
    tg = sub.add_parser("targets", help="target-state scorecard: re-score the plan's target table (coverage, data, models, track record, research, controls) from evidence; writes outputs/targets/targets.md and .csv")
    tg.add_argument("--tests", help="saved pytest output to score the test suite from (default: the latest release note's full-suite result)")
    tg.add_argument("--dest", help="folder for targets.md and targets.csv (default <out>/targets)"); tg.set_defaults(fn=cmd_targets)
    tg.add_argument("--explain", action="store_true", help="say what each unmet target needs (Mac pull, Sam decision, calendar time or team work); writes nothing")
    tg.add_argument("--json", action="store_true", help="with --explain: print the readiness payload as JSON")
    ec = sub.add_parser("evidence-clock", help="calendar-gated evidence monitor (250-day forecast record, 12-month benchmark scoring, trade-idea quarters): progress and earliest test date; read-only, --write saves outputs/evidence_monitor.csv and .md")
    ec.add_argument("--as-of", type=_as_of_arg, help="as-of date YYYY-MM-DD (default: settings as_of, else today); only data stored on or before it counts")
    ec.add_argument("--write", action="store_true", help="also write <out>/evidence_monitor.csv and evidence_monitor.md"); ec.set_defaults(fn=cmd_evidence_clock)
    c = sub.add_parser("calendar-rehearsal", help="run Team B's SYNTHETIC rehearsal of the 2027 calendar-gated tests (about 8 s, temp home, shared record untouched), write <out>/calendar_rehearsal/ and print the readiness page section read back from rehearsal.json; SYNTHETIC REHEARSAL, not a test result; exit 0 ok, 1 problems (EQ-C-0147)")
    c.add_argument("--out", default=argparse.SUPPRESS, help="outputs folder (same as the top-level --out); files go to <out>/calendar_rehearsal/")
    c.add_argument("--no-scheduled", action="store_true", help="skip the subprocess run of the scheduled job (a little faster)")
    c.add_argument("--json", action="store_true"); c.set_defaults(fn=cmd_calendar_rehearsal)
    rc = sub.add_parser("record", help="append today's row to the forecast record (realised book loss, next-day VaR/ES, 12m MC VaR/ES) and run the backtests on it")
    rc.add_argument("--no-mc", action="store_true", help="skip the 12-month Monte Carlo"); rc.add_argument("--backfill", type=int, help="build the record for the last N trading days (GARCH refitted every --step days, no look-ahead)"); rc.add_argument("--step", type=int, default=21); _token_args(rc); rc.add_argument("--spreadsheet-id", default="1w4OLCkv4EvDFgaO6MBOipAuY2fjAlCQJ-OjtmHJshQY"); rc.set_defaults(fn=cmd_record)
    pr = sub.add_parser("prices", help="official FX history (BIS WS_XRU / ECB EXR) for data/market_history/prices.csv: pulls, saves the raw vintage and stages the build; --apply installs it (EQ-A-0054)")
    pr.add_argument("--start", help="first date YYYY-MM-DD (the scheduled record job uses 2023-10-18)"); pr.add_argument("--end", help="last date (default today)")
    pr.add_argument("--apply", action="store_true", help="install the build as prices.csv (only after Team B accepted HO-20261024-A-B-004)")
    pr.add_argument("--sheet-json", help="RETIRED GOOGLEFINANCE import; refused unless ECONQUEST_ALLOW_GOOGLEFINANCE=1 (research copy only)"); pr.set_defaults(fn=cmd_prices)
    rp = sub.add_parser("report", help="daily risk report (HTML + Markdown) from the latest archived run: outputs/reports/risk-report-<date>.html and latest.html; also writes outputs/alerts.json and delivers alerts if a webhook or SMTP is configured")
    rp.add_argument("--paths", type=int, help="Monte Carlo paths if no run is archived and the pipeline has to run"); rp.add_argument("--no-deliver", action="store_true", help="write alerts.json only, no webhook or email"); rp.set_defaults(fn=cmd_report)
    mo = sub.add_parser("monitor", help="weekly risk monitor (HTML + Markdown) from the latest archived run vs the run about a week earlier: outputs/reports/risk-monitor-<as_of>.html and latest-monitor.html")
    mo.add_argument("--days", type=int, default=7, help="look-back in days for the reference run (default 7)"); mo.set_defaults(fn=cmd_monitor)
    al = sub.add_parser("alerts", help="regime flips, PD and VaR moves, signal crossings, backtest failures and data issues since the previous archived run; writes outputs/alerts.json")
    al.add_argument("--webhook", action="store_true", help="post to ECONQUEST_ALERT_WEBHOOK (Slack or Teams incoming webhook)"); al.add_argument("--email", action="store_true", help="send via SMTP (ECONQUEST_SMTP_HOST, _PORT, _USER, _PASSWORD, _FROM, _TO)"); al.add_argument("--previous", help="run id to compare against instead of the previous archived run"); al.set_defaults(fn=cmd_alerts)
    li = sub.add_parser("limits", help="limits table for the book (data/limits.json) and, with --propose, the pre-trade check")
    li.add_argument("--propose", help='proposed position "country,asset_class,direction,notional_mm[,duration_yrs]", e.g. "Argentina,Eurobond,Long,10,6"')
    li.add_argument("--paths", type=int, help="Monte Carlo paths for the before and after runs (default 20000)"); li.set_defaults(fn=cmd_limits)
    wi = sub.add_parser("whatif", help="what-if trades: VaR99/ES99/EL/L-VaR99 and limit status before and after, marginal per trade; in memory only, nothing booked (EQ-C-0133)")
    wi.add_argument("--trade", action="append", required=True, help='"<country> <instrument> <notional_mm> [buy|sell]", e.g. "Brazil Local bond 10 buy"; repeat for several (at most 10)')
    wi.add_argument("--paths", type=int, help="Monte Carlo paths requested (default 20000, 1000-200000); the same seed and paths before and after")
    wi.add_argument("--as-of", type=_as_of_arg, help="model date YYYY-MM-DD (default: settings as_of, else today)")
    wi.add_argument("--fast", action="store_true", help="kept for scripts: since EQ-C-0139 both modes price the trades on the base run's own paths (Team B's engine.portfolio_risk), so before equals the base run and --fast gives the same numbers")
    wi.add_argument("--full", action="store_true", help="the default (one base run, trades priced on its paths: before = base run); kept for scripts")
    wi.add_argument("--json", action="store_true", help="print the stable eq-whatif/1 JSON"); wi.set_defaults(fn=cmd_whatif)
    at = sub.add_parser("attribution", help="risk attribution of the base run: component and marginal VaR99/ES99 by country or factor (Team B engine.portfolio_risk); writes <out>/attribution.json (EQ-C-0139)")
    at.add_argument("--by", choices=["country", "factor"], default="country", help="group by country (default) or risk factor")
    at.add_argument("--as-of", type=_as_of_arg, help="model date YYYY-MM-DD (default: settings as_of, else today)")
    at.add_argument("--paths", type=int, help="Monte Carlo paths requested (default 20000, 1000-200000)")
    at.add_argument("--json", action="store_true", help="print the eq-attribution/1 JSON"); at.set_defaults(fn=cmd_attribution)
    gv = sub.add_parser("governance", help="governance pack: rebuild docs/governance/change-log.md from the run archive and print the model inventory status (layer1 mode, hashes, evidence sizes)")
    gv.add_argument("--limit", type=int, default=200); gv.add_argument("--docs", help="governance folder (default <home>/docs/governance)"); gv.set_defaults(fn=cmd_governance)
    rep = sub.add_parser("replicate", help="independent replication of the release-note and validation numbers from stored inputs (econquest.validation.replicate); writes replication.csv and replication.md; exit 1 on any FAIL")
    rep.add_argument("--out", dest="rep_out", metavar="DIR", help="folder for replication.csv and replication.md (default <out>/replication)")
    rep.add_argument("--quick", action="store_true", help="20,000 requested paths, loose tolerance; skips the GARCH refit")
    rep.add_argument("--only", help="comma list of groups: release,docs,backtest,hazard,scorecard,garch"); rep.set_defaults(fn=cmd_replicate)
    rpa_help = ("second-line replication: every number in the release notes 0.1.1-0.1.5 against the archived runs (read-only), the kept release zip and, with --rerun, a rerun of the 0.1.5 zip's engine (econquest.validation.replicate_archive); writes archive-replication.csv and .md; exit 1 on a mismatch without a findings-register row or a cited run missing")
    rpa = sub.add_parser("replicate-archive", help=rpa_help, description=rpa_help + " (HO-20261024-B-C-003)")
    rpa.add_argument("--out", dest="ra_out", metavar="DIR", help="folder for archive-replication.csv and .md (default <out>/replication-archive)")
    rpa.add_argument("--archive", metavar="DIR", help="run archive folder, read-only (default outputs/store/archive)")
    rpa.add_argument("--db", metavar="PATH", help="SQLite store, opened read-only; 'none' skips the cross-check (default outputs/store/econquest.sqlite)")
    rpa.add_argument("--zip", metavar="PATH", help="kept release zip; 'none' to skip (default: the kept 0.1.5 zip when present)")
    rpa.add_argument("--rerun", action="store_true", help="rerun the 0.1.5 zip's engine on frozen inputs (about a minute)")
    rpa.set_defaults(fn=cmd_replicate_archive)
    ds = sub.add_parser("dsa", help="debt sustainability fan charts (WEO baseline, stochastic shocks) and IMF ARA reserve adequacy; writes outputs/dsa.csv, dsa_fan.csv, dsa_plan.json, dsa_paths.csv, dsa_signal.csv, dsa_paths_meta.json; --apply feeds indicators 1.1, 1.2, 2.1 through the quality gate; --write writes the Debt Sustainability tab")
    ds.add_argument("--paths", type=int, help="simulation paths per country (default 10000)"); ds.add_argument("--year", type=int, help="base year (default: from --as-of)"); ds.add_argument("--as-of", help="as-of date YYYY-MM-DD (default today); sets the base year and the retrieved date"); ds.add_argument("--apply", action="store_true"); ds.add_argument("--force", action="store_true", help="apply values the quality gate would hold")
    ds.add_argument("--keys", nargs="*", default=["1.1", "1.2", "2.1"], help="indicator ids written to dsa_scorecard_feeds.csv"); _token_args(ds); ds.add_argument("--spreadsheet-id", default="1w4OLCkv4EvDFgaO6MBOipAuY2fjAlCQJ-OjtmHJshQY"); ds.set_defaults(fn=cmd_dsa)
    ed = sub.add_parser("editorial", help="editorial states for research products: draft, review (four-eyes), publish (read-only copy + manifest), correct, withdraw, list, verify")
    eds = ed.add_subparsers(dest="ed_cmd", required=True)
    kinds = ["daily_report", "weekly_monitor", "country_note", "scenario_brief", "weekly_brief", "trade_ideas"]   # weekly_brief: EQ-C-0075; trade_ideas: HO-20261025-B-C-011
    e1 = eds.add_parser("draft", help="register product files as a draft, stamped with the latest (or --run-id) run")
    e1.add_argument("--kind", required=True, choices=kinds); e1.add_argument("--file", action="append", required=True, help="product file (repeat)")
    e1.add_argument("--author", required=True); e1.add_argument("--run-id", help="archived run the files were built from (default latest)")
    e2 = eds.add_parser("review", help="mark a draft reviewed; reviewer must differ from author unless --self-reviewed")
    e2.add_argument("item"); e2.add_argument("--reviewer", required=True); e2.add_argument("--note")
    e2.add_argument("--self-reviewed", action="store_true", help="single-operator self-review (recorded as self_reviewed=yes)")
    e3 = eds.add_parser("publish", help="publish a reviewed item to outputs/published/<kind>/<date>-<id>/ (read-only)"); e3.add_argument("item"); e3.add_argument("--publisher", required=True)
    e4 = eds.add_parser("correct", help="register corrected files as a new draft linked to a published item")
    e4.add_argument("item"); e4.add_argument("--file", action="append", required=True); e4.add_argument("--author", required=True)
    e4.add_argument("--reason", required=True); e4.add_argument("--run-id", help="run of the corrected files (default: the original's stamps)")
    e5 = eds.add_parser("withdraw", help="mark a published item withdrawn (kept on disk, listed in outputs/published/WITHDRAWN.jsonl)")
    e5.add_argument("item"); e5.add_argument("--by", required=True); e5.add_argument("--reason", required=True)
    e6 = eds.add_parser("list", help="editorial items"); e6.add_argument("--state", choices=["draft", "reviewed", "published", "withdrawn", "corrected"])
    e6.add_argument("--kind", choices=kinds); e6.add_argument("--limit", type=int, default=50)
    e7 = eds.add_parser("checklist", help="compliance checklist (EQ-C-0036): author's conflicts, reviewer's acknowledgement of flagged "
                        "restrictions, compliance sign-off; --show prints it (exit 1 if incomplete). publish refuses until complete")
    e7.add_argument("item"); e7.add_argument("--by", help="who records it: the author for --conflicts, the reviewer for --acknowledge, the approver for --compliance-approve")
    e7.add_argument("--conflicts", help='author\'s declaration: "no conflicts" or the text')
    e7.add_argument("--acknowledge", action="append", metavar="RESTRICTION", help="flagged use restriction the reviewer acknowledges, e.g. 6.1 (repeat)")
    e7.add_argument("--compliance-approve", action="store_true", help="compliance sign-off by a person other than the author")
    e7.add_argument("--self-signed", action="store_true", help="single-operator self-sign by the author, recorded as an exception (needs --exc)")
    e7.add_argument("--exc", help="exception id EXC-nnn from docs/governance/issues-log.md (required with --self-signed, as change approve)")
    e7.add_argument("--note", help="sign-off note"); e7.add_argument("--show", action="store_true", help="print the checklist evaluated now")
    eds.add_parser("verify", help="check the ledger chain and every published copy against its manifest; exit 1 on any problem")
    ed.set_defaults(fn=cmd_editorial)
    rv = sub.add_parser("review", help="review ledger for gate-held input cells (data/live/review_ledger.csv): decide, list, approve or apply against a saved vintage")
    rvs = rv.add_subparsers(dest="review_cmd", required=True)
    rd = rvs.add_parser("decide", help="append one decision per cell (apply, hold or reject): one cell (--table --key --country), or several held cells (--cell repeated, --all-pending); applying a held cell needs --approver or --self-approved")
    rd.add_argument("--table", choices=["Inputs", "Country Profile"], help="one cell's table (with --all-pending: only this table)"); rd.add_argument("--key", help="indicator id (e.g. 1.1) or profile field")
    rd.add_argument("--country", help="one cell's country (with --all-pending: only this country)"); rd.add_argument("--decision", required=True, choices=["apply", "hold", "reject"])
    rd.add_argument("--cell", nargs=3, action="append", metavar=("TABLE", "KEY", "COUNTRY"), help="a held cell from data/live/review.csv (repeat for several); live value and gate status are taken from it")
    rd.add_argument("--all-pending", action="store_true", help="every held cell with no decision yet (as `review list --pending`); one ledger row and one action-log row per cell")
    rd.add_argument("--author", required=True); rd.add_argument("--approver"); rd.add_argument("--self-approved", action="store_true", help="single-operator self-approval (recorded as self_approved=yes)")
    _named_user_args(rd)
    rd.add_argument("--note"); rd.add_argument("--vintage", help="vintage id the decision applies to"); rd.add_argument("--live", type=float, help="live value the decision applies to")
    rd.add_argument("--gate-status", choices=["ok", "hold", "missing"], help="gate status of the cell (hold => four-eyes)")
    rl = rvs.add_parser("list", help="latest decision per cell; --pending lists the held cells still waiting for one"); rl.add_argument("--country"); rl.add_argument("--table"); rl.add_argument("--limit", type=int, default=200)
    rl.add_argument("--pending", action="store_true", help="cells the last fetch held (data/live/review.csv) that have no decision yet")
    rl.add_argument("--vintage", metavar="ID", help="with --pending: the held cells of this saved vintage (data/live/vintages/ID) and their effective "
                    "status (released: an approved apply binds to this vintage or its live value; held: stays on seed)")
    ra = rvs.add_parser("approve", help="decide held cells against a saved vintage (default: the latest), offline: each ledger row carries the vintage id and the cell's live value from it; applying a held cell needs --approver or --self-approved; then `review apply`")
    ra.add_argument("cells", nargs="+", metavar="TABLE KEY COUNTRY", help='one or more cells as triples, e.g. "Country Profile" fx3m Brazil Inputs 1.3 Vietnam (table: Inputs or "Country Profile")')
    ra.add_argument("--author", required=True); ra.add_argument("--approver", help="second person (four-eyes); must differ from --author")
    ra.add_argument("--self-approved", action="store_true", help="single-operator self-approval (recorded as self_approved=yes)")
    _named_user_args(ra)
    ra.add_argument("--decision", choices=["apply", "hold", "reject"], default="apply", help="default apply; hold or reject keeps the cells on seed (no approver needed)")
    ra.add_argument("--vintage", metavar="ID", help="saved vintage the decisions bind to (default: the latest under data/live/vintages/)"); ra.add_argument("--note")
    rp = rvs.add_parser("apply", help="apply a saved vintage to indicators.csv and countries.csv offline (no refetch): its ok cells plus the held cells approved for it; never forces")
    rp.add_argument("--vintage", metavar="ID", help="saved vintage to apply (default: the latest); an older one also re-applies its ok cells over newer values")
    rp.add_argument("--dry-run", action="store_true", help="print what an apply would do (effective status per cell) and write nothing")
    rp.add_argument("--allow-older", action="store_true", help="apply a --vintage that is not the latest (its ok cells overwrite newer values)")
    rr = rvs.add_parser("legacy-reset", help="append one 'hold' per gate-held or missing cell whose latest decision was imported from the hand-edited review.csv (author 'unknown (imported ...)'): those cells then need a named decision; gate-ok cells are left alone (EQ-A-0101); offline, append-only; same as python -m econquest.ingestion.ledger legacy-reset")
    rr.add_argument("--author", required=True); rr.add_argument("--approver")
    rr.add_argument("--self-approved", action="store_true", help="single-operator mode (recorded as self_approved=yes)")
    rr.add_argument("--dry-run", action="store_true", help="list the cells and write nothing")
    rvv = rvs.add_parser("verify", help="recompute the review ledger's hash chain (EQ-A-0103): exit 1 on a break, 0 when intact; legacy rows written before 0.6.0 are reported as unchained, not as tampered; same as python -m econquest.ingestion.ledger verify")
    rvv.add_argument("--json", action="store_true", help="print the result as JSON")
    rv.set_defaults(fn=cmd_review)
    ch = sub.add_parser("change", help="change approvals for data/assumptions.json, data/limits.json and data/compliance.json: propose, approve, reject, apply, list, show, verify, baseline (data/approvals/)")
    chs = ch.add_subparsers(dest="change_cmd", required=True)
    c = chs.add_parser("propose", help="record a proposed change (the file is not touched)")
    from .ops.approvals import FILES as _GOVERNED      # assumptions, limits, compliance, research, users (EQ-C-0078)
    c.add_argument("file", choices=list(_GOVERNED))
    c.add_argument("--set", action="append", metavar="/POINTER=JSON", help="e.g. --set /layer4/lgd_sd=0.12 (repeatable; strings quoted)")
    c.add_argument("--patch-file", help="JSON file {pointer: value}"); c.add_argument("--replace-file", help="whole new file")
    c.add_argument("--author", required=True); c.add_argument("--reason", required=True)
    c.add_argument("--tier", choices=["limit", "1", "2", "3", "run"], help="default: inferred; may raise, never lower")
    c.add_argument("--allow-new-keys", action="store_true"); c.add_argument("--allow-type-change", action="store_true")
    c = chs.add_parser("approve", help="four-eyes approval (approver other than the author), or --self-approved with --exc EXC-nnn")
    c.add_argument("id"); c.add_argument("--approver"); c.add_argument("--self-approved", action="store_true")
    c.add_argument("--as", dest="approver_id", metavar="USER_ID", help="sign as this data/users.json user with their key ($ECONQUEST_SIGNING_KEY_<ID> or Keychain econquest-signing); required once four-eyes is enforced (EQ-C-0078)")
    c.add_argument("--exc", help="exception id EXC-nnn from docs/governance/issues-log.md (required with --self-approved)"); c.add_argument("--note")
    c = chs.add_parser("reject", help="reject or withdraw a change not yet applied"); c.add_argument("id"); c.add_argument("--by", required=True); c.add_argument("--reason")
    c = chs.add_parser("apply", help="write an approved change (refused if the file changed since the proposal)"); c.add_argument("id"); c.add_argument("--actor")
    c = chs.add_parser("list", help="proposals and their status"); c.add_argument("--status", choices=["proposed", "approved", "rejected", "applied"]); c.add_argument("--limit", type=int, default=50)
    c = chs.add_parser("show", help="one proposal with its diff and events"); c.add_argument("id")
    chs.add_parser("verify", help="verify the hash-chained log and report drift (hand edits outside the tool); exit 1 on failure")
    c = chs.add_parser("baseline", help="record a file's current sha256 as accepted (first use, or accepting reported drift with four-eyes)")
    c.add_argument("file", choices=list(_GOVERNED)); c.add_argument("--actor", required=True); c.add_argument("--reason", required=True)
    c.add_argument("--approver"); c.add_argument("--self-approved", action="store_true"); c.add_argument("--exc")
    _named_user_args(c, exc=False)
    ch.set_defaults(fn=cmd_change)
    cg = sub.add_parser("crag", help="BoC-BoE sovereign default database (CRAG): update imports a new Valet .csv or BoC-BoE .xlsx, diffs it and with --apply replaces data/panel/sovereign_defaults_crag.csv (runbook docs/runbooks/A-crag-update.md)")
    cgs = cg.add_subparsers(dest="crag_cmd", required=True)
    cgu = cgs.add_parser("update", help="Team A's crag_update (python -m econquest.ingestion.crag_update) with the same flags passed straight through; dry run unless --apply; exit 0 done, 1 refused, 2 --fetch unavailable (HO-20261025-A-C-003)")
    cgu.add_argument("--file", help="Valet .csv export or BoC-BoE .xlsx workbook")
    cgu.add_argument("--fetch", action="store_true", help="download from the Bank of Canada (UNVERIFIED: prints the page and exits 2)")
    cgu.add_argument("--apply", action="store_true", help="replace the live CRAG file after the diff (default: dry run); never changes sovereign_defaults.csv")
    cgu.add_argument("--panel-dir", help="panel folder (default data/panel)")
    cgu.add_argument("--source-vintage", help="edition or download date for source_vintage (default: current YYYY-MM)")
    cgu.add_argument("--iso-map", help="country,iso map CSV (default <panel>/crag_iso_map.csv)")
    cgu.add_argument("--expect-live-sha256", metavar="HEX|absent", help="with --apply: sha256 of the live CRAG file the dry run saw (its live_sha256_before; 'absent' = no live file); a mismatch exits 1, status changed, nothing replaced (HO-20261025-A-C-014)")
    cgu.add_argument("--expect-iso-map-sha256", metavar="HEX|absent", help="with --apply: sha256 of the country map the dry run saw (its iso_map_sha256; 'absent' = no map); a mismatch exits 1, status changed")
    cgu.add_argument("--json", action="store_true", help="print the result as JSON instead of the text summary")
    cg.set_defaults(fn=cmd_crag)
    ru = sub.add_parser("runs", help="list archived runs with code and data versions"); ru.add_argument("--limit", type=int, default=20); ru.set_defaults(fn=cmd_runs)
    from .ingestion.ledger import HAND_ENTERED as _hand    # every hand-entered file Team A's ledger knows (EQ-C-0089)
    at = sub.add_parser("attest", help="attest hand-entered cells (" + ", ".join(sorted(f[:-4] for f in _hand)) + ") in the review ledger, or --list the unattested ones")
    at.add_argument("--file", choices=sorted(f[:-4] for f in _hand)); at.add_argument("--author"); at.add_argument("--approver", help="second person (four-eyes; must differ from --author)")
    at.add_argument("--self-approved", action="store_true", help="single-operator self-attestation, recorded as self_approved=yes"); at.add_argument("--note")
    _named_user_args(at)
    at.add_argument("--all", action="store_true", help="re-attest every cell, not only those not yet attested"); at.add_argument("--list", action="store_true", help="print the unattested cells")
    # EQ-C-0074 batch attestation: select by sheet, country, indicator group; --dry-run first, then --confirm with a name
    at.add_argument("--country", help="batch: only this country's cells"); at.add_argument("--group", help="batch: adjustments block (indicator group), e.g. 'Override floor'")
    at.add_argument("--pillar", help="batch: adjustments pillar number 1-7"); at.add_argument("--key", help="batch: one exact ledger key, e.g. PM03")
    at.add_argument("--all-files", action="store_true", help="batch: every hand-entered file (instead of --file)")
    at.add_argument("--dry-run", action="store_true", help="batch: show what would be attested and write nothing (not even the action log)")
    at.add_argument("--confirm", action="store_true", help="batch: write the attestations (needs --author and --approver or --self-approved; recorded in the action log)")
    at.add_argument("--expect", type=int, help="batch: refuse unless exactly N cells are selected (the count the dry run printed)")
    at.add_argument("--expect-digest", help="batch: refuse unless the selection is exactly the cells (and contents) the dry run showed (SEC-C-011 L1)")
    at.set_defaults(fn=cmd_attest)
    au = sub.add_parser("audit", help="audit trail: provenance, transform, vintage and gate decision for every Inputs and Country Profile cell (data/audit_trail.csv, Audit Trail tab)")
    _token_args(au); au.add_argument("--spreadsheet-id", default="1w4OLCkv4EvDFgaO6MBOipAuY2fjAlCQJ-OjtmHJshQY"); au.set_defaults(fn=cmd_audit)
    ga = sub.add_parser("garch", help="GARCH(1,1)-t and DCC-GARCH volatility layer from data/market_history; writes outputs/garch and the GARCH tab plan")
    ga.add_argument("--quotes", help="CSV of ticker, market price of the ATM 63-day put (for implied vol)"); _token_args(ga)
    ga.add_argument("--as-of", type=_as_of_arg, help="fit only prices dated on or before YYYY-MM-DD (default: settings as_of, else every row)")
    ga.add_argument("--vintage", help="replay the inputs frozen with this fetch vintage; --as-of defaults to the vintage date")
    ga.add_argument("--spreadsheet-id", default="1w4OLCkv4EvDFgaO6MBOipAuY2fjAlCQJ-OjtmHJshQY"); ga.set_defaults(fn=cmd_garch)
    ec = sub.add_parser("econ", help="econometrics toolkit (stationarity, AR+GARCH, cointegration, SVAR, Kalman, regimes, premia, EVT, copulas, forecasts, event study) from data/market_history")
    _token_args(ec); ec.add_argument("--spreadsheet-id", default="1w4OLCkv4EvDFgaO6MBOipAuY2fjAlCQJ-OjtmHJshQY"); ec.set_defaults(fn=cmd_econ)
    ide = sub.add_parser("ideas", help="trade-idea log (illustrative, Tier 3, GOV-032): log an archived base run's Playbook ideas, mark them against Market History, "
                                       "report hit rate and P&L (outputs/idea_log.csv, idea_report.md/.csv); run and record update it too")
    ids = ide.add_subparsers(dest="ideas_cmd", required=True)
    i1 = ids.add_parser("log", help="advance the log by an archived run (default: the latest base run; stress runs refused)"); i1.add_argument("--run-id")
    i2 = ids.add_parser("mark", help="mark open ideas to a trading day (default: the last complete day in Market History, as record uses)")
    i2.add_argument("--as-of", type=_as_of_arg, help="mark date YYYY-MM-DD; only prices on or before it are used")
    ids.add_parser("report", help="print outputs/idea_report.md"); ide.set_defaults(fn=cmd_ideas)
    i4 = ids.add_parser("page", help="trade-ideas page (HTML + trade-ideas.json manifest) of the base run the weekly brief uses for --as-of: "
                                     "playbook activations, signal threshold, idea-log counts (HO-20261025-B-C-011)")
    i4.add_argument("--as-of", required=True, type=_as_of_arg, help="YYYY-MM-DD: newest archived base run with a model date on or before it")
    i4.add_argument("--dest", help="output folder (default: <out>/trade-ideas)")
    sv = sub.add_parser("serve", help="JSON API, SSE and dashboard"); sv.add_argument("--host", default="127.0.0.1"); sv.add_argument("--port", type=int, default=8080); sv.set_defaults(fn=cmd_serve)
    n = sub.add_parser("notes", help="country notes (HTML, PDF with --pdf when Chrome/Chromium is found): outputs/notes/")
    n.add_argument("--country", nargs="*"); n.add_argument("--pdf", action="store_true"); n.add_argument("--chrome", help="browser binary for --pdf (default: search; or $ECONQUEST_CHROME)"); n.add_argument("--dest"); n.set_defaults(fn=cmd_notes)
    b = sub.add_parser("briefs", help="scenario briefs from stress.json, archived stress runs and reverse_stress.json: outputs/briefs/")
    b.add_argument("--scenario", nargs="*"); b.add_argument("--pdf", action="store_true"); b.add_argument("--chrome"); b.add_argument("--dest"); b.set_defaults(fn=cmd_briefs)
    pp = sub.add_parser("publish-preview", help="diff the saved publish plan against a values:batchGet JSON or a previous plan before publish --write (no network)")
    pp.add_argument("--baseline", nargs="+", metavar="FILE", help="what the workbook holds now: values:batchGet JSON file(s) saved from the --urls, or a previous publish_plan.json")
    pp.add_argument("--plan", metavar="FILE", help="the new plan to check (default: <out>/publish_plan.json)")
    pp.add_argument("--tolerance", type=float, default=1e-6, help="numbers within tolerance x max(1, |old|, |new|) count as unchanged (default 1e-6)")
    pp.add_argument("--large", type=float, default=0.25, help="relative change flagged as large (default 0.25 = 25%%); sign flips and cleared cells are always large")
    pp.add_argument("--dest", metavar="DIR", help="folder for the HTML and CSV report (default: <out>/preview)"); pp.add_argument("--urls", action="store_true", help="print the batchGet URLs to fetch the live values")
    pp.add_argument("--spreadsheet-id", default="1w4OLCkv4EvDFgaO6MBOipAuY2fjAlCQJ-OjtmHJshQY", help="workbook the --urls point at (default: the Risk Desk workbook)"); pp.set_defaults(fn=cmd_publish_preview)
    from .ops.commands import register as register_ops
    register_ops(sub, HOME_DIR)   # schedule install|uninstall|show, health, backup [--verify], restore-drill (EQ-C-0021/0022)
    from .ops.open_items import register as register_open_items
    register_open_items(sub)      # open-items (alias todo), exc next|draft (EQ-C-0074)
    from .ops.client_check import register as register_client_check
    register_client_check(sub)    # client-check: client-readiness checklist, reads only, exit 1 while anything is missing (EQ-C-0083)
    from .ops.client_pack import register as register_client_pack
    register_client_pack(sub)     # client-pack: INTERNAL client-readiness pack under <out>/client_pack/; never switches client mode on (EQ-C-0094)
    from .presentation.client_build import register as register_client_export
    register_client_export(sub)   # client-export: client-mode build path, refuses unless Sam's client mode and licences allow it (EQ-C-0107)
    from .ops.client_outbox import register as register_client_outbox
    register_client_outbox(sub)   # client-outbox build|send|verify|reset --sandbox: test outbox, synthetic clients, never email (EQ-C-0145)
    from .ops.macpull import register as register_mac_pull
    register_mac_pull(sub)        # mac-pull plan|run|status|report over Team A's pull pack (EQ-C-0073, HO-20261024-A-C-008)
    from .ops.next_steps import register as register_next
    register_next(sub)            # next [--run [--apply-fx|--apply-prices]]: the 0.4.2 Mac pass in order, resumable (EQ-C-0092)
    from .ops.first_pass import register as register_first_pass
    register_first_pass(sub)      # first-pass [--status|--next|--check N|bundle]: team/first-mac-pass.md with checks (EQ-C-0134)
    from .ops.morning import register as register_morning
    register_morning(sub)         # morning [--as-of D] [--run|--no-run] [--json]: the daily desk view, same as GUI Home (EQ-C-0132)
    from .ops.perf_budget import register as register_perf_budget
    register_perf_budget(sub)     # perf-budget [--json] [--measure]: the daily cycle on data/mvp against per-step budgets (EQ-C-0164)
    from .ops.errors import register as register_explain
    register_explain(sub)         # explain [<id>]: plain-English failure map, next command, docs link (EQ-C-0135)
    from .ops.demo import register as register_demo
    register_demo(sub)            # demo: MVP acceptance run M1-M10 in a temp home, offline (EQ-C-0121, team/mvp-checklist.md)
    lg = sub.add_parser("log", help="operator action log (outputs/store/actions.jsonl, hash-chained): verify the chain or tail it")
    lgs = lg.add_subparsers(dest="log_cmd", required=True)
    lgs.add_parser("verify", help="check seq, prev_hash, row_hash and the head; exit 1 on any break")
    lt = lgs.add_parser("tail", help="print the last rows"); lt.add_argument("-n", type=int, default=20); lt.add_argument("--json", action="store_true")
    lg.set_defaults(fn=cmd_log)
    lk = sub.add_parser("ledger-key", help="keyed ledger heads (HMAC over the chain heads, OFF by default; decision D4): status, init, seal, escrow-check, drill")
    lks = lk.add_subparsers(dest="lk_cmd", required=True)
    lks.add_parser("status", help="the switch (ops.json ledger_keyed_heads), the key source and each ledger's seal")
    lks.add_parser("init", help="print the Keychain and ops.json steps for Sam; never generates or stores a key")
    lkseal = lks.add_parser("seal", help="seal the current heads of the ledgers that verify (once, after switching it on)")
    lkseal.add_argument("--reseal", action="store_true", help="overwrite a seal that fails (only after finding out why)")
    lks.add_parser("escrow-check", help="check the BACKUP copy of the key (hidden prompt or stdin, never argv): same key id as the live key, and every existing seal validates with it; prints key ids only (EQ-C-0084)")
    lkd = lks.add_parser("drill", help="run the whole D4 switch path (key, backup, escrow check, switch on, seal, verify, tamper, key loss, recovery, roll back) on a temp copy with a temp key; never touches ops.json, the Keychain or the real ledgers (EQ-C-0084)")
    lkd.add_argument("--keep", action="store_true", help="keep the temp copy (path printed)")
    lk.set_defaults(fn=cmd_ledger_key)
    for name, p in sub.choices.items():                   # EQ-C-0034: per-invocation override of the run gate
        if _gated(name):
            p.add_argument("--allow-unattested", action="store_true",
                           help="proceed even if the run gate would block on unattested hand-entered cells (recorded in the action log)")
    args = ap.parse_args(argv)
    from .ops.install_check import unzipped_release_problem   # SEC-C-018: an unzipped release has release-data/, no data/
    if (_unzipped := unzipped_release_problem(args.data, HERE)):
        _unz = SystemExit(f"econquest: {_unzipped}")
        from .ops.errors import hint_for_exit             # EQ-C-0135: plain-English line above the refusal
        hint_for_exit(_unz)
        raise _unz
    from .ops import fitcache                              # EQ-C-0085: disk cache for deterministic fits (PERF-C-001);
    fitcache.configure(Path(args.out) / "cache" / "fits", prune_days=fitcache.PRUNE_DAYS)   # used once the engine adopts it
    writer = hasattr(args, "token_file")                  # a subcommand that can write the workbook
    writes = _will_write(args)
    label = action_label(args, writes)
    secrets = [os.environ.get(k, "") for k in (TOKEN_ENV, "ECONQUEST_SMTP_PASSWORD", "ECONQUEST_ALERT_WEBHOOK")]
    code, err = 0, ""

    def log_override(found):
        _record_action(args, "run-gate override", 0, "", secrets,
                       extra_args={"command": found["command"], "policy": found["mode"], "policy_key": found["key"],
                                   "unattested": found["counts"], "total": found["total"]}, strict=True)
    try:
        if writes:                                        # EQ-C-0123: no workbook write while a DEMO licence profile is open
            from .ops.licence_gov import demo_refusal
            if (_demo_why := demo_refusal(f"{getattr(args, 'cmd', '')} --write")):
                raise SystemExit(f"econquest: {_demo_why}. Nothing was sent to Sheets.")
        restricted_gate(args, writes)                     # HO-20261024-A-C-007: before the run gate and any override
        run_gate(args, writes, log_override=log_override)
        if writer:
            args.token = None if args.dry_run else resolve_token(args)
            secrets.append(args.token or "")
        args.fn(args)
        if writer and args.dry_run:
            print("Dry run: plan saved only; no token looked up and nothing sent to Sheets.", file=sys.stderr)
        elif writer and not args.token and args.cmd != "publish":     # publish prints its own hint
            print("Workbook not written: plan saved only. Pass --write to write it (token from $ECONQUEST_SHEETS_TOKEN or the Keychain) or --token-file PATH.", file=sys.stderr)
    except SystemExit as e:
        code, err = _exit_code(e)
        from .ops.errors import hint_for_exit             # EQ-C-0135: plain-English block on stderr; e is unchanged
        hint_for_exit(e)
        raise
    except KeyboardInterrupt:                             # EQ-C-0168 (HO-20261026-A-C-016): one line, exit 130, no
        try:                                              # traceback; the command saved its own state (mac-pull
            from .ingestion.pullpack import EXIT_INTERRUPTED as _intr     # state.json, review apply puts files back)
        except ImportError:
            _intr = 130
        code, err = _intr, "interrupted"
        print(f"econquest: interrupted (Ctrl-C) during `{getattr(args, 'cmd', '')}`; rerun the same command to resume "
              "or start again", file=sys.stderr)
        raise SystemExit(code) from None
    except BaseException as e:
        code, err = 1, f"{type(e).__name__}: {e}"
        if argv is None:                                  # EQ-C-0135: a real command line gets plain English, not a
            from .ops.errors import friendly_exception    # traceback, for a mapped failure (exit 1 as before)
            friendly_exception(e)
        raise
    finally:
        if label:
            _record_action(args, label, code, err, secrets)


if __name__ == "__main__":
    main()
