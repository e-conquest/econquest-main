"""Shared base for the research-dataset adapters (EQ-A-0067, Sam 2026-10-24 17:21Z "Add them, licence-checked").

Every adapter turns ONE local file (or the bytes of one verified direct download) into long rows, LONG_COLUMNS:

    indicator   indicators.csv id the row serves ("3.6", "6.10", ...)
    iso3        ISO 3166-1 alpha-3, mapped through the repo's ISO helpers (default_panel.default_iso_lookup)
    year        int, the data year the value describes
    value       float, finite
    metric      what the number is: the indicator itself (kind "indicator") or a named input (kind "input")
    kind        "indicator": already in the indicator's unit (indicators.csv), no judgement applied
                "input":     a raw input that still needs a Team B rule (scaling, banding, inverting) before it is the
                             indicator; never written into indicators.csv by this package
    source      fixed text naming the dataset and its version
    licence     the dataset's licence tag (see LICENCE TAGS below)
    vintage     point-in-time stamp: "<dataset version>; sha256:<16 hex>; <file name>"

Files come from the drop-in folder data/panel/research/<dataset>/ (manual downloads on Sam's Mac, like the WEO
manual list) or, only for datasets whose terms page shows a plain file link (fetch_mode "direct"), from `download`:
https only, host on the dataset's allow-list, redirects refused, body capped, final URL checked
(events.base.http_fetch, SEC-A-002). This package never runs a network call at import and tests never touch the
network.

Unknown layouts are refused loudly (LayoutError naming the columns or sheets that were found); nothing is guessed.
Country names / codes that the ISO helpers do not know are dropped and listed in ResearchResult.unmapped, never
guessed.

LICENCE TAGS. A tag never contains a desk-barred term (market.gate.DESK_BARRED_LICENCE_TERMS: "non-commercial",
"personal"), so audit.restricted_reason never bars these values from desk numbers. A dataset whose licence is
non-commercial or not confirmed carries "internal research use only" in its tag, which audit.client_output_reason
recognises (CLIENT_RESTRICTED_LICENCE_TERMS), so the value stays out of client output: the same split as the IMF
under EXC-003. Only a confirmed licence that allows commercial use (CC BY 4.0, CC BY-SA 4.0) carries an open tag.
"""
from __future__ import annotations

import hashlib
import io
import math
import re
import urllib.parse
import zipfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Iterable

import pandas as pd

from econquest.ingestion.safe_zip import ZipBudgetExceeded, check_zip_budget, check_zip_file

LONG_COLUMNS = ["indicator", "iso3", "year", "value", "metric", "kind", "source", "licence", "vintage"]
PUBLISHED_COLUMN = "published"   # ARCH-A-PI9 D1 (EQ-A-0108): optional column after LONG_COLUMNS, YYYY-MM-DD or ""
KINDS = ("indicator", "input")
FETCH_MODES = ("manual", "direct", "api", "api_token")
INTERNAL_TAG = "internal research use only"                 # audit.CLIENT_RESTRICTED_LICENCE_TERMS[0]
DROP_ROOT = Path("panel") / "research"                       # relative to data_dir (data/)
DEFAULT_MAX_BYTES = 100 * 1024 * 1024
MAX_ZIP_MEMBER_BYTES = 200 * 1024 * 1024                     # uncompressed cap for one member read from a zip
YEAR_MIN, YEAR_MAX = 1900, 2100
ISO3_RE = re.compile(r"^[A-Z]{3}$")
KEY_RE = re.compile(r"^[a-z][a-z0-9_]{1,31}$")
REPO_DATA = Path(__file__).resolve().parents[3] / "data"


class LayoutError(ValueError):
    """The file does not have the layout the parser was written for. Never repaired or guessed."""


class FetchRefused(ValueError):
    """A download that the dataset's spec does not allow (mode, scheme, host)."""


@dataclass(frozen=True)
class DatasetSpec:
    key: str                      # registry key and drop-in folder name
    name: str
    indicators: tuple             # indicators.csv ids served (directly or as an input)
    licence: str                  # the tag written on every row
    client_ok: bool               # False: internal research use only (tag carries INTERNAL_TAG)
    fetch_mode: str               # manual | direct | api | api_token
    terms_url: str
    attribution: str
    file_globs: tuple = ()        # file names accepted in the drop-in folder
    url: str = ""                 # direct download (fetch_mode "direct" / "api")
    hosts: tuple = ()             # https host allow-list for `download`
    max_bytes: int = DEFAULT_MAX_BYTES
    layout_verified: bool = False # False: parser written from the codebook / docs, not from a downloaded file
    notes: str = ""

    def __post_init__(self):
        if not KEY_RE.fullmatch(self.key):
            raise ValueError(f"bad dataset key {self.key!r}")
        if self.fetch_mode not in FETCH_MODES:
            raise ValueError(f"{self.key}: fetch_mode {self.fetch_mode!r} not in {FETCH_MODES}")
        if self.client_ok == (INTERNAL_TAG in self.licence.casefold()):
            raise ValueError(f"{self.key}: client_ok={self.client_ok} contradicts licence tag {self.licence!r}")
        from econquest.ingestion.events.base import licence_problem
        from econquest.ingestion.market.gate import DESK_BARRED_LICENCE_TERMS
        why = licence_problem(self.licence)
        if why:
            raise ValueError(f"{self.key}: licence tag {why}")
        hit = [t for t in DESK_BARRED_LICENCE_TERMS if t in self.licence.casefold()]
        if hit:
            raise ValueError(f"{self.key}: licence tag carries desk-barred term(s) {hit}; write the restriction as "
                             f"'{INTERNAL_TAG}' instead (EQ-A-0067)")


MAX_TEXT = 200
_CTRL = re.compile(r"[\x00-\x1f\x7f]+")


def safe_text(v) -> str:
    """Text from a dataset file (a country name, a sheet name) made safe for CSV and Sheets (SEC-A-010 I3): control
    characters (newlines included) become one space, length is capped at MAX_TEXT, and a value starting with
    = + - @ (or TAB / CR before the replacement) gets a leading apostrophe (ledger._neutralise), so a spreadsheet never
    evaluates it."""
    from econquest.ingestion.ledger import _neutralise
    raw = str(v)
    lead = raw[:1]
    t = _CTRL.sub(" ", raw)[:MAX_TEXT]
    if lead in ("\t", "\r"):                              # neutralise judges the original first character
        return "'" + t
    return _neutralise(t)


@dataclass
class ResearchResult:
    rows: pd.DataFrame
    vintage: str
    unmapped: list = field(default_factory=list)       # names / codes not mapped to ISO3 (dropped, never guessed)
    notes: list = field(default_factory=list)

    def __post_init__(self):                           # SEC-A-010 I3: file text never reaches CSV / Sheets raw
        self.unmapped = [safe_text(u) for u in self.unmapped]
        self.notes = [safe_text(n) for n in self.notes]


# ------------------------------------------------------------------------------------------------- files

def drop_folder(data_dir: str | Path, key: str) -> Path:
    if not KEY_RE.fullmatch(key):
        raise ValueError(f"bad dataset key {key!r}")
    return Path(data_dir) / DROP_ROOT / key


def find_local(data_dir: str | Path, spec: DatasetSpec) -> Path | None:
    """The one file in data/panel/research/<key>/ matching spec.file_globs, or None. Two or more matches are refused
    (keep one release in the folder, or pass the path explicitly) so a run never picks a vintage silently."""
    folder = drop_folder(data_dir, spec.key)
    if not folder.is_dir():
        return None
    # SEC-A-014 P4-L2: a linked drop folder (or a link above it) would read a file from outside the data folder
    if folder.is_symlink() or not folder.resolve().is_relative_to(Path(data_dir).resolve()):
        raise LayoutError(f"{folder}: the drop-in folder is a link or leaves the data folder; put the file itself "
                          "into a plain folder")
    hits = sorted({p for g in spec.file_globs for p in folder.glob(g)
                   if p.is_file() and not p.is_symlink() and not p.name.startswith(".")})
    if len(hits) > 1:
        raise LayoutError(f"{folder}: {len(hits)} files match {list(spec.file_globs)} ({[p.name for p in hits]}); "
                          f"keep one or pass the file explicitly")
    return hits[0] if hits else None


def sha256(body: bytes) -> str:
    return hashlib.sha256(body).hexdigest()


def vintage_of(version: str, body: bytes, name: str) -> str:
    v = re.sub(r"[\r\n;]", " ", str(version or "version unknown")).strip()
    return f"{v}; sha256:{sha256(body)[:16]}; {Path(name).name}"


def read_bytes(path: str | Path, max_bytes: int = DEFAULT_MAX_BYTES) -> bytes:
    p = Path(path)
    if p.is_symlink() or not p.is_file():
        raise FileNotFoundError(f"{p}: not a regular file")
    if p.stat().st_size > max_bytes:
        raise LayoutError(f"{p}: {p.stat().st_size} bytes exceeds the {max_bytes}-byte cap")
    return p.read_bytes()


def download(spec: DatasetSpec, url: str | None = None, fetcher: Callable | None = None,
             headers: dict | None = None) -> bytes:
    """Bytes of a verified direct download: spec.fetch_mode 'direct' or 'api', https, host in spec.hosts, no redirect,
    capped at spec.max_bytes. `fetcher(url, headers, data=None, max_bytes=...)` is injectable (tests); the default is
    events.base.http_fetch. Live use runs on Sam's Mac (the cloud cannot reach these hosts)."""
    url = url or spec.url
    if spec.fetch_mode not in ("direct", "api"):
        raise FetchRefused(f"{spec.key}: fetch_mode {spec.fetch_mode!r}: download by hand into "
                           f"data/panel/research/{spec.key}/ (see docs/runbooks/A-research-datasets.md)")
    parts = urllib.parse.urlsplit(url or "")
    if parts.scheme != "https" or not parts.hostname:
        raise FetchRefused(f"{spec.key}: refusing non-https URL {parts.scheme}://{parts.hostname}{parts.path}")
    if parts.hostname not in spec.hosts:
        raise FetchRefused(f"{spec.key}: host {parts.hostname} not on the allow-list {list(spec.hosts)}")
    if parts.username or parts.password or parts.port:
        raise FetchRefused(f"{spec.key}: URL with credentials or a port refused")
    if fetcher is None:
        from econquest.ingestion.events.base import http_fetch
        return http_fetch(url, headers or {"User-Agent": "econquest/0.4"}, max_bytes=spec.max_bytes)
    body = fetcher(url, headers or {"User-Agent": "econquest/0.4"}, None, max_bytes=spec.max_bytes)
    if len(body) > spec.max_bytes:
        raise FetchRefused(f"{spec.key}: response exceeds the {spec.max_bytes}-byte cap")
    return body


def zip_member(body: bytes, suffixes: Iterable[str], max_bytes: int = MAX_ZIP_MEMBER_BYTES) -> tuple[str, bytes]:
    """(name, bytes) of the single zip member whose path ends with one of `suffixes` (case-insensitive). Read in
    memory, never extracted to disk; uncompressed size capped. None or several matches: LayoutError."""
    try:
        zf = zipfile.ZipFile(io.BytesIO(body))
        check_zip_budget(zf)                                     # SEC-A-010 L1: declared sizes, before any read
    except zipfile.BadZipFile as e:
        raise LayoutError(f"not a zip file: {e}") from None
    except ZipBudgetExceeded as e:
        raise LayoutError(f"zip refused before unpacking: {e}") from None
    suf = tuple(s.lower() for s in suffixes)
    names = [i for i in zf.infolist() if not i.is_dir() and i.filename.lower().endswith(suf)]
    if len(names) != 1:
        raise LayoutError(f"zip: expected one member ending {list(suffixes)}, found {[i.filename for i in names]} "
                          f"among {len(zf.infolist())} members")
    info = names[0]
    if info.file_size > max_bytes:
        raise LayoutError(f"zip member {info.filename}: {info.file_size} bytes uncompressed exceeds {max_bytes}")
    with zf.open(info) as f:
        data = f.read(max_bytes + 1)
    if len(data) > max_bytes:
        raise LayoutError(f"zip member {info.filename} exceeds {max_bytes} bytes")
    return info.filename, data


def read_csv_bytes(body: bytes, what: str, sep: str | None = ",") -> pd.DataFrame:
    try:
        return pd.read_csv(io.BytesIO(body), dtype=str, keep_default_na=False, sep=sep,
                           engine="python" if sep is None else "c", encoding="utf-8-sig")
    except (UnicodeDecodeError, pd.errors.ParserError, ValueError) as e:
        raise LayoutError(f"{what}: not a readable CSV ({type(e).__name__}: {str(e)[:200]})") from None


def read_excel_sheets(body: bytes, what: str) -> dict[str, pd.DataFrame]:
    """Every sheet as strings, header on the first row. Macro-enabled workbooks are read as values only (openpyxl
    never runs macros). The workbook's zip container is checked against safe_zip's unpacked-size, per-member and
    compression-ratio budget before pandas decompresses anything (SEC-A-010 L1)."""
    try:
        check_zip_file(io.BytesIO(body))
    except zipfile.BadZipFile as e:
        raise LayoutError(f"{what}: not a readable .xlsx workbook (BadZipFile: {str(e)[:200]})") from None
    except ZipBudgetExceeded as e:
        raise LayoutError(f"{what}: workbook refused before unpacking: {e}") from None
    try:
        return pd.read_excel(io.BytesIO(body), sheet_name=None, dtype=str, engine="openpyxl")
    except Exception as e:                                       # zipfile / openpyxl / xml errors: one refusal
        raise LayoutError(f"{what}: not a readable .xlsx workbook ({type(e).__name__}: {str(e)[:200]})") from None


def norm_col(c) -> str:
    return re.sub(r"\s+", " ", str(c)).strip().casefold()


def require_columns(df: pd.DataFrame, needed: Iterable[str], what: str) -> dict[str, str]:
    """{wanted (casefolded): actual column name}; LayoutError naming the missing ones and the columns found."""
    have = {norm_col(c): c for c in df.columns}
    miss = [n for n in needed if norm_col(n) not in have]
    if miss:
        found = [str(c) for c in df.columns][:40]
        raise LayoutError(f"{what}: missing column(s) {miss}; found {found} (layout UNVERIFIED or changed: "
                          f"refused, see docs/runbooks/A-research-datasets.md)")
    return {norm_col(n): have[norm_col(n)] for n in needed}


def to_float(x) -> float | None:
    s = str(x).strip().replace(",", "") if x is not None else ""
    if s in ("", "-", "..", "NA", "N/A", "nan", "NaN", "None", "null"):
        return None
    try:
        v = float(s)
    except ValueError:
        return None
    return v if math.isfinite(v) else None


# ------------------------------------------------------------------------------------------------- countries

def iso_lookup(extra: dict | None = None) -> dict[str, str]:
    """Normalised country name -> ISO3 from default_panel.default_iso_lookup (repo tables over its reference list)."""
    from econquest.ingestion.default_panel import default_iso_lookup
    return default_iso_lookup(extra)


def name_key(name: str) -> str:
    from econquest.ingestion.default_panel import _name_key
    return _name_key(name)


class CountryMapper:
    """ISO3 for a (code, name) pair: a code that is a known ISO3 wins, else the name through iso_lookup. A miss is
    recorded in `unmapped` and returns None; a code/name conflict returns None and is recorded too."""

    def __init__(self, extra: dict | None = None):
        self.look = iso_lookup(extra)
        self.known = set(self.look.values())
        self.unmapped: set = set()

    def __call__(self, code=None, name=None) -> str | None:
        c = str(code or "").strip().upper()
        by_code = c if ISO3_RE.fullmatch(c) and c in self.known else None
        by_name = self.look.get(name_key(name)) if name and str(name).strip() else None
        if by_code and by_name and by_code != by_name:
            self.unmapped.add(f"{name} [{c}] (code and name disagree: {by_code} vs {by_name})")
            return None
        iso = by_code or by_name
        if not iso:
            self.unmapped.add(f"{name or ''} [{c}]" if c else str(name))
        return iso


# ------------------------------------------------------------------------------------------------- rows

def indicator_ids(data_dir: str | Path | None = None) -> set[str]:
    p = Path(data_dir or REPO_DATA) / "indicators.csv"
    return set(pd.read_csv(p, dtype=str, usecols=["id"])["id"].str.strip())


def make_rows(records: list[dict], spec: DatasetSpec, source: str, vintage: str) -> pd.DataFrame:
    """records: dicts with indicator, iso3, year, value, metric, kind. Adds source/licence/vintage and validates."""
    df = pd.DataFrame(records, columns=["indicator", "iso3", "year", "value", "metric", "kind"])
    df["source"], df["licence"], df["vintage"] = source, spec.licence, vintage
    return validate_rows(df[LONG_COLUMNS], spec)


def validate_rows(df: pd.DataFrame, spec: DatasetSpec, data_dir: str | Path | None = None) -> pd.DataFrame:
    if list(df.columns) != LONG_COLUMNS:
        raise LayoutError(f"{spec.key}: rows must have columns {LONG_COLUMNS}, got {list(df.columns)}")
    if df.empty:
        return df.reset_index(drop=True)
    problems = []
    ids = indicator_ids(data_dir)
    bad = sorted(set(df["indicator"]) - ids)
    if bad:
        problems.append(f"indicator ids not in indicators.csv: {bad}")
    if sorted(set(df["indicator"]) - set(spec.indicators)):
        problems.append(f"indicator ids not registered for {spec.key}: {sorted(set(df['indicator']) - set(spec.indicators))}")
    if (~df["iso3"].astype(str).str.fullmatch(ISO3_RE.pattern)).any():
        problems.append("iso3 not three letters A-Z")
    yrs = pd.to_numeric(df["year"], errors="coerce")
    if yrs.isna().any() or (yrs % 1 != 0).any() or (yrs < YEAR_MIN).any() or (yrs > YEAR_MAX).any():
        problems.append(f"year outside {YEAR_MIN}-{YEAR_MAX} or not whole")
    vals = pd.to_numeric(df["value"], errors="coerce")
    if vals.isna().any() or (~vals.map(math.isfinite)).any():
        problems.append("value missing or not finite")
    if (~df["kind"].isin(KINDS)).any():
        problems.append(f"kind not in {KINDS}")
    dup = df.duplicated(["indicator", "iso3", "year", "metric"])
    if dup.any():
        problems.append(f"{int(dup.sum())} duplicate (indicator, iso3, year, metric) rows")
    if problems:
        raise LayoutError(f"{spec.key}: " + "; ".join(problems))
    out = df.copy()
    out["year"], out["value"] = yrs.astype(int), vals.astype(float)
    return out.sort_values(["indicator", "metric", "iso3", "year"]).reset_index(drop=True)


def with_published(rows: pd.DataFrame, dates) -> pd.DataFrame:
    """ARCH-A-PI9 D1 (EQ-A-0108): `rows` plus the `published` column that Team B's research_effect._published reads
    (indicator-rules 13: a row is usable only from its release's publication date). `dates` is one YYYY-MM-DD for
    every row or one per row; "" means no recorded date, so Team B's cautious PUBLISHED_DEFAULT applies. Dates are
    checked, never guessed."""
    out = rows.copy()
    vals = [dates] * len(out) if isinstance(dates, str) else [str(d) for d in dates]
    if len(vals) != len(out):
        raise ValueError(f"published: {len(vals)} dates for {len(out)} rows")
    bad = sorted({d for d in vals if d and not re.fullmatch(r"\d{4}-\d{2}-\d{2}", d)})
    if bad or any(d and pd.isna(pd.to_datetime(d, errors="coerce")) for d in vals):
        raise ValueError(f"published dates must be YYYY-MM-DD or empty, got {bad[:3]}")
    out[PUBLISHED_COLUMN] = vals
    return out


def check_range(df: pd.DataFrame, metric: str, lo: float, hi: float, what: str) -> None:
    """Values of `metric` outside [lo, hi] mean the scale is not the one the parser expects: refused, not rescaled."""
    v = df.loc[df["metric"] == metric, "value"]
    out = v[(v < lo) | (v > hi)]
    if len(out):
        raise LayoutError(f"{what}: {len(out)} value(s) of {metric} outside [{lo}, {hi}] (e.g. {out.iloc[0]}); the "
                          f"scale differs from the codebook: refused, not rescaled")


# ------------------------------------------------------------------------------------------------- load

_HOW = {"manual": "download by hand: ", "direct": "pass fetch=True on the Mac",
        "api": "call the module's fetch() on the Mac",
        "api_token": "use the token adapter on the Mac"}  # nosec B105


def load(spec: DatasetSpec, parser: Callable[..., ResearchResult], data_dir: str | Path, path: str | Path | None = None,
         *, fetch: bool = False, fetcher: Callable | None = None, version: str | None = None) -> ResearchResult:
    """Parse `path`, else the one file in the drop-in folder, else (fetch=True and fetch_mode 'direct' only) download
    spec.url and keep the bytes in the drop-in folder under the URL's file name (written once, read-only, so the run is
    reproducible from the folder). Nothing found: FileNotFoundError naming the folder to fill by hand."""
    if path is None:
        path = find_local(data_dir, spec)
    if path is not None:
        body = read_bytes(path, spec.max_bytes)
        return parser(body, Path(path).name, version=version)
    if not fetch or spec.fetch_mode != "direct":
        raise FileNotFoundError(f"{spec.key}: no file in {drop_folder(data_dir, spec.key)} matching "
                                f"{list(spec.file_globs)}; fetch mode {spec.fetch_mode} "
                                f"({_HOW[spec.fetch_mode]}{spec.terms_url if spec.fetch_mode == 'manual' else ''})")
    body = download(spec, fetcher=fetcher)
    name = Path(urllib.parse.urlsplit(spec.url).path).name
    folder = drop_folder(data_dir, spec.key)
    folder.mkdir(parents=True, exist_ok=True)
    dest = folder / name
    with open(dest, "xb") as f:                                   # never overwrite a kept release
        f.write(body)
    dest.chmod(0o444)
    return parser(body, name, version=version)
