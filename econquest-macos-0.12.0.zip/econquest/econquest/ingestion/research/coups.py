"""Powell-Thyne coups dataset -> 4.4 Coup and irregular transfer of power (inputs). EQ-A-0067.

Source (read 2026-10-25): https://www.uky.edu/~clthyn2/coup_data/home.htm links "Dataset 2 (Final, purged and updated
dataset)" as http://www.uky.edu/~clthyn2/coup_data/powell_thyne_coups_final.txt and asks for the citation Powell &
Thyne (2011), Journal of Peace Research 48(2): 249-259. No licence or terms of use on the page or in the codebook
(https://www.uky.edu/~clthyn2/coup_data/Codebook.pdf). Licence UNVERIFIED -> internal research use only.

Fetch: direct, https on the same host. The page links http://; https serving the same file is UNVERIFIED (a redirect
is refused by the downloader, which then fails loudly; then download by hand into data/panel/research/coups/).

Layout (codebook): country, ccode (Gleditsch-Ward), year, month, day, coup (1 = unsuccessful, 2 = successful).
Delimiter not stated in the codebook (Stata `insheet`): tab or comma accepted, anything else refused. UNVERIFIED.

Output (inputs; the 0-4 level is Team B's rule): per country-year with at least one attempt, coup_attempts and
coup_successes. With `isos`, the countries in `isos` also get explicit zero rows for every year the file covers
(zero attempts is a valid value), from the first to the last year in the file, but only when every country name
in the file mapped to ISO3: an unmapped name could be one of `isos`, and a zero would hide its coups.
"""
from __future__ import annotations

from .base import (CountryMapper, DatasetSpec, LayoutError, ResearchResult, load as _load, make_rows, read_csv_bytes,
                   require_columns, to_float, vintage_of)

SPEC = DatasetSpec(
    key="coups", name="Powell-Thyne coups dataset", indicators=("4.4",),
    licence="internal research use only: Powell-Thyne coups data, licence UNVERIFIED (no terms stated; cite Powell and Thyne 2011)",
    client_ok=False, fetch_mode="direct",
    terms_url="https://www.uky.edu/~clthyn2/coup_data/home.htm",
    attribution=("Powell, Jonathan M., and Clayton L. Thyne (2011). Global Instances of Coups from 1950 to 2010: A New "
                 "Dataset. Journal of Peace Research 48(2): 249-259."),
    file_globs=("powell_thyne_coups_final*.txt", "powell_thyne_coups_final*.csv"),
    url="https://www.uky.edu/~clthyn2/coup_data/powell_thyne_coups_final.txt",
    hosts=("www.uky.edu",), max_bytes=5 * 1024 * 1024)

COLS = ["country", "ccode", "year", "month", "day", "coup"]


def _table(body: bytes, name: str):
    first = body[:4096].decode("utf-8", "replace").splitlines()[0] if body else ""
    sep = "\t" if "\t" in first else ","
    df = read_csv_bytes(body, f"Powell-Thyne {name}", sep=sep)
    return df, require_columns(df, COLS, f"Powell-Thyne {name}")


def parse(body: bytes, name: str, version: str | None = None, isos=None) -> ResearchResult:
    df, c = _table(body, name)
    cm = CountryMapper()
    counts: dict = {}
    years = []
    for _, r in df.iterrows():
        y, k = to_float(r[c["year"]]), to_float(r[c["coup"]])
        if y is None:
            raise LayoutError(f"Powell-Thyne {name}: row without a year: {dict(r)}")
        if k not in (1.0, 2.0):
            raise LayoutError(f"Powell-Thyne {name}: coup={r[c['coup']]!r}; the codebook allows 1 or 2 only")
        years.append(int(y))
        iso = cm(None, r[c["country"]])
        if iso is None:
            continue
        a, s = counts.get((iso, int(y)), (0, 0))
        counts[(iso, int(y))] = (a + 1, s + (k == 2.0))
    if not years:
        raise LayoutError(f"Powell-Thyne {name}: no rows")
    notes = ["inputs only: 4.4 level (count/recency to 0-4) is Team B's rule"]
    if isos and cm.unmapped:
        # An unmapped country name may be one of `isos`: a zero row would then hide its coups (AGENT-05 review).
        notes.append(f"no zero rows written: {len(cm.unmapped)} country name(s) not mapped {sorted(cm.unmapped)}; "
                     f"map them (extra names) to get zero rows")
    else:
        for iso in isos or ():
            for y in range(min(years), max(years) + 1):
                counts.setdefault((iso, y), (0, 0))
        notes.append("zero rows only for the isos passed; other countries have rows only in attempt years")
    recs = []
    for (iso, y), (a, s) in counts.items():
        recs.append(dict(indicator="4.4", iso3=iso, year=y, value=float(a), metric="coup_attempts", kind="input"))
        recs.append(dict(indicator="4.4", iso3=iso, year=y, value=float(s), metric="coup_successes", kind="input"))
    version = version or f"Powell-Thyne coups (events {min(years)}-{max(years)})"
    vintage = vintage_of(version, body, name)
    rows = make_rows(recs, SPEC, f"Powell-Thyne coups ({version})", vintage)
    return ResearchResult(rows, vintage, sorted(cm.unmapped), notes)


def load(data_dir, path=None, isos=None, **kw) -> ResearchResult:
    return _load(SPEC, lambda b, n, version=None: parse(b, n, version, isos), data_dir, path, **kw)
