"""Neighbour list for 6.12 from the Correlates of War Direct Contiguity data (EQ-A-0118, coverage part 6).

Team B's rule for 6.12 (docs/validation/indicator-rules.md section 4) needs `data/panel/neighbours.csv` with columns
iso3, neighbour_iso3, basis, source, which Team A builds:
- Land or sea: COW Direct Contiguity v3.2, latest year in the file, `conttype` 1 (land) to 5 (up to 400 miles of
  water; the maritime-border proxy).
- Unions: members of the same monetary union (euro area, WAEMU, CEMAC, ECCU) or customs union (EU, EAEU, SACU, GCC,
  Mercosur, EAC). Free-trade areas and wider blocs do not count.
- Symmetric: if A lists B, B lists A.

Inputs (drop-in folder data/panel/research/cow/; manual downloads, nothing fetched here):
- `contdird.csv`: the directed-dyad file. Codebook columns: dyad, state1no, state1ab, state2no, state2ab, year,
  conttype, version. Only state1no, state2no, year and conttype are read (all required).
- `states2016.csv` (COW State System Membership): stateabb, ccode, statenme. It maps a COW code to a country NAME,
  and the repo's ISO helpers (research.base.CountryMapper) map the name to ISO3. COW codes are never mapped from
  memory; a name the helpers do not know is listed as unmapped and dropped.
- `unions.csv` (optional; columns union, kind, iso3, source): membership as the operator records it from each union's
  official member list. NOT supplied here: no membership is invented. Without it, union neighbours are left out and
  the result says so (notes).
UNVERIFIED (Mac probe list): the exact file names and headers of v3.2 and of the states file. Licence: COW data are
free with citation; terms UNVERIFIED (indicator-rules section "Licence clearance": Sam).

OFF BY DEFAULT: `build` only prints a summary; `build --write` writes data/panel/neighbours.csv (a Sam-gated step,
docs/runbooks/A-coverage-60.md section 12). Nothing fills 6.12: Team B's rule_cells marks it NOT_COMPUTED until the
UCDP inputs (research/ucdp_ged.py or the token API) and this list exist.
"""
from __future__ import annotations

import argparse
import io
import sys
from pathlib import Path

import pandas as pd

from .base import CountryMapper, LayoutError, drop_folder, read_bytes, safe_text

KEY = "cow"
OUT_COLUMNS = ["iso3", "neighbour_iso3", "basis", "source"]
CONT_COLUMNS = ["state1no", "state2no", "year", "conttype"]
STATE_COLUMNS = ["ccode", "statenme"]
UNION_COLUMNS = ["union", "kind", "iso3", "source"]
CONTTYPE = {1: "land", 2: "sea <=12 miles", 3: "sea <=24 miles", 4: "sea <=150 miles", 5: "sea <=400 miles"}
UNIONS = {"monetary": ("euro area", "WAEMU", "CEMAC", "ECCU"),
          "customs": ("EU", "EAEU", "SACU", "GCC", "Mercosur", "EAC")}
SOURCE = "COW Direct Contiguity (v3.2)"
OUT_PATH = Path("panel") / "neighbours.csv"


def _csv(body: bytes, what: str, need) -> pd.DataFrame:
    try:
        df = pd.read_csv(io.BytesIO(body), dtype=str, keep_default_na=False)
    except (ValueError, pd.errors.ParserError) as e:
        raise LayoutError(f"{what}: not a CSV ({str(e)[:120]})") from None
    cols = {str(c).strip().lower(): c for c in df.columns}
    miss = [c for c in need if c not in cols]
    if miss:
        raise LayoutError(f"{what}: columns {miss} missing (layout UNVERIFIED; refused). Found: {list(df.columns)[:12]}")
    out = df[[cols[c] for c in need]].copy()
    out.columns = list(need)
    return out


def ccode_to_iso(states: pd.DataFrame) -> tuple[dict[int, str], list[str]]:
    """COW ccode -> ISO3 through the state NAME (CountryMapper); unmapped names are returned, never guessed."""
    cm = CountryMapper()
    out = {}
    for c, name in zip(states["ccode"], states["statenme"]):
        if not str(c).strip().isdigit():
            raise LayoutError(f"COW states: ccode {c!r} is not a number")
        iso = cm(None, name)
        if iso:
            prev = out.get(int(c))
            if prev and prev != iso:
                raise LayoutError(f"COW states: ccode {c} maps to {prev} and {iso}")
            out[int(c)] = iso
    return out, sorted(cm.unmapped)


def build(contdird: pd.DataFrame, states: pd.DataFrame, unions: pd.DataFrame | None = None,
          max_conttype: int = 5) -> tuple[pd.DataFrame, list[str]]:
    """(neighbours frame OUT_COLUMNS, notes). Contiguity from the latest year in the file; unions within each union."""
    for c in ("year", "conttype", "state1no", "state2no"):
        if (~contdird[c].str.strip().str.fullmatch(r"\d+")).any():
            raise LayoutError(f"COW contiguity: {c} is not a whole number in every row")
    d = contdird.astype({c: int for c in CONT_COLUMNS})
    if (~d["conttype"].isin(CONTTYPE)).any():
        raise LayoutError(f"COW contiguity: conttype outside 1-5: {sorted(set(d['conttype']) - set(CONTTYPE))}")
    year = int(d["year"].max())
    d = d[(d["year"] == year) & (d["conttype"] <= max_conttype)]
    iso, unmapped = ccode_to_iso(states)
    notes = [f"contiguity year {year}, conttype 1-{max_conttype}"]
    miss = sorted({int(c) for c in pd.concat([d["state1no"], d["state2no"]]) if int(c) not in iso})
    if miss:
        notes.append(f"COW codes without an ISO3 (dropped): {miss[:20]}")
    if unmapped:
        notes.append(f"COW state names the ISO helpers do not know (dropped): {unmapped[:20]}")
    rows = {}
    for a, b, t in zip(d["state1no"], d["state2no"], d["conttype"]):
        ia, ib = iso.get(a), iso.get(b)
        if not ia or not ib or ia == ib:
            continue
        for x, y in ((ia, ib), (ib, ia)):                      # symmetric whatever the file holds
            k = (x, y)
            basis = CONTTYPE[t]
            if k not in rows or t < rows[k][1]:                # the closest contiguity type wins
                rows[k] = (f"contiguity {basis} ({year})", t, SOURCE)
    if unions is None or not len(unions):
        notes.append("unions not applied: no unions.csv (membership is never invented; indicator-rules section 4)")
    else:
        u = unions.copy()
        u["iso3"] = u["iso3"].str.strip().str.upper()
        bad_kind = sorted({(n, k) for n, k in zip(u["union"], u["kind"]) if n not in UNIONS.get(k, ())})
        if bad_kind:
            raise LayoutError(f"unions.csv: unions not counted by indicator-rules section 4: {bad_kind}")
        if (~u["iso3"].str.fullmatch(r"[A-Z]{3}")).any() or (u["source"].str.strip() == "").any():
            raise LayoutError("unions.csv: every row needs an ISO3 and a source")
        for name, grp in u.groupby("union"):
            mem = sorted(set(grp["iso3"]))
            src = "; ".join(sorted({safe_text(x) for x in grp["source"]}))   # SEC-A-013 L2: typed text
            for x in mem:
                for y in mem:
                    if x != y and (x, y) not in rows:
                        rows[(x, y)] = (f"union {name}", 9, src)
    out = pd.DataFrame([(x, y, b, s) for (x, y), (b, _, s) in sorted(rows.items())], columns=OUT_COLUMNS)
    return out, notes


def load(data_dir: str | Path, max_conttype: int = 5) -> tuple[pd.DataFrame, list[str]]:
    folder = drop_folder(data_dir, KEY)
    need = {"contdird.csv": None, "states2016.csv": None}
    for n in need:
        p = folder / n
        if not p.is_file():
            raise FileNotFoundError(f"{KEY}: {p} missing (COW Direct Contiguity v3.2 and State System files, by hand)")
        need[n] = read_bytes(p)
    cont = _csv(need["contdird.csv"], "COW contdird.csv", CONT_COLUMNS)
    states = _csv(need["states2016.csv"], "COW states2016.csv", STATE_COLUMNS)
    up = folder / "unions.csv"
    unions = _csv(read_bytes(up), "unions.csv", UNION_COLUMNS) if up.is_file() else None
    return build(cont, states, unions, max_conttype)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.research.cow_contiguity",
                                 description="6.12 neighbour list from COW Direct Contiguity (off by default)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("build")
    p.add_argument("--data", default="data")
    p.add_argument("--write", action="store_true", help="write data/panel/neighbours.csv (refuses to overwrite)")
    a = ap.parse_args(argv)
    try:
        nb, notes = load(a.data)
    except (FileNotFoundError, LayoutError) as e:
        print(f"refused: {e}")
        return 1
    print(f"{len(nb)} directed neighbour pairs for {nb['iso3'].nunique()} countries; " + "; ".join(notes))
    if a.write:
        out = Path(a.data) / OUT_PATH
        if out.exists():
            print(f"refused: {out} exists; move it aside first")
            return 1
        nb.to_csv(out, index=False)
        print(f"wrote {out}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
