"""Research datasets in the pull (EQ-A-0095): research.REGISTRY -> feed `research` in feeds.fetch_all.

fetch(data_dir)
    Loads every BUILT adapter in REGISTRY from its drop-in folder data/panel/research/<key>/ (local files only, never
    the network: fetch=False). Per dataset: "ok" with rows and vintage, "not dropped" (no file: a normal state, never
    a failure; attrs["messages"] keeps the adapter's text naming the folder to fill, EQ-A-0089), or "refused" (LayoutError / unreadable: listed in the table's attrs["failures"], so save_report puts
    it in feed_failures.csv). Licence-blocked or deferred entries (GTI, UNDRR, IPC, CIESIN) are never loaded; UCDP
    stays on its own events path. Returns the adapters' long rows (research.base.LONG_COLUMNS, licence column kept)
    with attrs status / failures / source.

cells(rows, iso, year, worldbank=None)
    Candidate Inputs cells for one country through Team B's rules (validation.research_effect.rule_cells,
    docs/validation/indicator-rules.md sections 1-5 and 13), plus the 13.1 no-legislature value (until Team B adds
    13.1 to rule_cells: done by Team B, the override was removed in EQ-A-0118). Point in time is Team B's research_effect.point_in_time
    on the adapters' `published` column (ARCH-A-PI9 D1). Yields
    (key, value, source, series, licence) for every cell with a value, and (key, reason) blanks separately.
    `series` starts with SERIES_PREFIX and carries the rule and Team B's hold reason, so the gate can find the cell.

gate_checks(report)
    crosscheck.CHECK_COLUMNS rows: EVERY research cell is held (check 'research'), reason 'unverified: research
    dataset, held until the first gate review (EQ-A-0095)', plus Team B's hold reason, plus 'Sam sign-off at first
    values' for 3.6, 4.4, 6.10, 7.12 (indicator-rules 13). Nothing from this feed is applied without a review decision.
    EQ-A-0126: the 'unverified' reason is dropped only for cells whose datasets are all in LAYOUT_VERIFIED (empty
    today); a cell left with no reason gets no row, so the quality gate's other checks decide it.

wants_cells(rows, events, worldbank)
    EQ-A-0126: also True when the World Bank rows carry SI.POV.GINI, so 6.10's Gini part is computed with no EPR file.

Licence: each cell's `licence` is the "; "-joined licence tags of the rows it was computed from (and the World Bank
text for a Gini part); feeds.fetch_all writes it into provenance.csv's licence column, which audit.restricted_reason /
client_output_reason read (an "internal research use only" tag keeps the value out of client output).
"""
from __future__ import annotations

import datetime as dt
from pathlib import Path

import pandas as pd

from econquest.rules.research import NO_LEG_RULE  # noqa: F401 - Team B's rule text (C15), not a copy (EQ-A-0089)

from . import REGISTRY, module
from .base import LONG_COLUMNS, LayoutError

FEED = "research"
SERIES_PREFIX = "research "
SIGNOFF_IDS = frozenset({"3.6", "4.4", "6.10", "7.12"})       # indicator-rules 13: Sam's sign-off at first values
UNVERIFIED_REASON = "unverified: research dataset, held until the first gate review (EQ-A-0095)"
SIGNOFF_REASON = "Sam sign-off at first values (indicator-rules 13)"
WB_GINI_SOURCE = "World Bank WDI SI.POV.GINI (wbgapi)"
NOT_RESEARCH_IDS = frozenset({"2.11"})     # rule_cells computes it, but the World Bank path serves it (EQ-A-0102)
# EQ-A-0126 (indicator-rules 13: "held `unverified` until the file layout is checked on Sam's Mac"): the dataset keys
# whose file layout the first Mac pass confirmed. Empty until AGENT-08 records that evidence; a key here drops only
# UNVERIFIED_REASON for cells made from that dataset alone. Team B's rule holds and Sam's sign-off ids stay held.
LAYOUT_VERIFIED: frozenset = frozenset()


def wants_cells(rows: pd.DataFrame | None, events: pd.DataFrame | None = None,
                worldbank: pd.DataFrame | None = None) -> bool:
    """EQ-A-0126: whether feeds.fetch_all should call cells() for a country. Research rows or UCDP events as before,
    and also World Bank rows carrying SI.POV.GINI, so 6.10's Gini part (section 3) is computed when no EPR file is
    dropped (Team B's rule then holds the cell, 'EPR missing')."""
    if rows is not None and len(rows):
        return True
    if events is not None:
        return True
    return bool(worldbank is not None and len(worldbank) and "series" in worldbank.columns
                and (worldbank["series"].astype(str) == "SI.POV.GINI").any())


def research_keys(licence: str) -> set[str]:
    """The built dataset keys whose licence tag is in a cell's joined licence text (EQ-A-0126)."""
    text = str(licence or "")
    return {k for k in loadable() if module(k).SPEC.licence in text}


def loadable() -> list[str]:
    """Registry keys this feed loads: built adapters only (blocked / deferred / existing are left out)."""
    return [k for k, e in REGISTRY.items() if e.status == "built"]


def fetch(data_dir: str | Path | None) -> pd.DataFrame:
    status, failures, parts, messages = {}, [], [], {}
    if data_dir is None:              # feeds.fetch_all without a data folder (tests): nothing is read
        rows = pd.DataFrame(columns=LONG_COLUMNS)
        rows.attrs.update(status={}, failures=[], messages={}, source="research: no data folder given",
                          note="no data folder given")
        return rows
    for k in loadable():
        try:
            res = module(k).load(data_dir)                    # local drop-in folder only (fetch=False)
        except FileNotFoundError as e:
            status[k] = "not dropped"
            messages[k] = " ".join(str(e).split())[:400]      # EQ-A-0089: which folder and how to fill it (a skip)
            continue
        except LayoutError as e:
            status[k] = f"refused: {str(e)[:200]}"
            failures.append(f"{k}: refused: {str(e)[:300]}")
            continue
        except Exception as e:  # noqa: BLE001 - one dataset's bug never stops the others
            status[k] = f"refused: {type(e).__name__}: {str(e)[:200]}"
            failures.append(f"{k}: {type(e).__name__}: {str(e)[:300]}")
            continue
        parts.append(res.rows)
        status[k] = f"ok ({len(res.rows)} rows; {res.vintage})"
    rows = pd.concat(parts, ignore_index=True) if parts else pd.DataFrame(columns=LONG_COLUMNS)
    rows.attrs.update(status=status, failures=failures, messages=messages,
                      source="research drop-in folders (data/panel/research)")
    return rows


def status_text(rows: pd.DataFrame) -> str:
    """One feeds.json line: 'ok (N rows; dropped: ...; not dropped: ...; refused: ...)'. Never a failure status."""
    st = rows.attrs.get("status", {})
    parts = [f"{len(rows)} rows"] + ([rows.attrs["note"]] if rows.attrs.get("note") else [])
    for label, test in (("dropped", lambda v: v.startswith("ok")), ("not dropped", lambda v: v == "not dropped"),
                        ("refused", lambda v: v.startswith("refused"))):
        ks = [k for k, v in st.items() if test(v)]
        if ks:
            parts.append(f"{label}: {', '.join(ks)}")
    return f"ok ({'; '.join(parts)})"


def as_of_for(year: int, today: dt.date | None = None) -> str:
    """Today, capped at 31 December of `year`: the same point in time as 2.11 (one implementation, EQ-A-0102)."""
    from ..official.worldbank import default_as_of
    return default_as_of(year, today)


def _point_in_time(rows: pd.DataFrame, as_of: str) -> pd.DataFrame:
    """ARCH-A-PI9 D1 (EQ-A-0108): Team B's point-in-time rule, one implementation. The adapters write each row's
    release date in the `published` column (Aqueduct 13.6, WJP editions 13.7); rows without one fall back to Team B's
    cautious PUBLISHED_DEFAULT. rule_cells applies the same filter again; it is idempotent. Applied here as well so the
    local 13.1 override below reads the same rows as Team B."""
    from econquest.rules.research import point_in_time
    return point_in_time(rows, as_of)


def _wb_frame(worldbank: pd.DataFrame | None) -> pd.DataFrame | None:
    if worldbank is None or not len(worldbank):
        return None
    wb = worldbank[["iso", "series", "period", "value"]].copy()
    wb["period"] = pd.to_numeric(wb["period"], errors="coerce")
    wb["value"] = pd.to_numeric(wb["value"], errors="coerce")
    return wb.dropna(subset=["period"])


def _origin(rows: pd.DataFrame, cid: str, iso: str, year) -> tuple[str, str]:
    """(source, licence) of the rows a cell came from: the same indicator, country and data year."""
    r = rows[(rows["indicator"] == cid) & (rows["iso3"] == iso)]
    if year is not None and len(r[r["year"] == int(year)]):
        r = r[r["year"] == int(year)]
    src = list(dict.fromkeys(r["source"].astype(str)))
    lic = list(dict.fromkeys(r["licence"].astype(str)))
    return "; ".join(src), "; ".join(lic)


UCDP_IDS = frozenset({"6.1", "6.9"})            # section 19: from UCDP monthly event rows, not research rows
UCDP_SOURCE = "UCDP GED and Candidate events (Uppsala University)"


def ucdp_events(data_dir: str | Path | None) -> pd.DataFrame | None:
    """Stored UCDP event rows (API or research/ucdp_ged.py vintages; events.indicators.stored_events), or None when
    there is none. Local files only. EQ-A-0118: the input Team B's rule_cells takes for 6.1 and 6.9 (section 19)."""
    if data_dir is None:
        return None
    from econquest.ingestion.events.indicators import stored_events
    try:
        ev = stored_events(Path(data_dir))
    except (FileNotFoundError, ValueError):
        return None
    ev = ev[ev["source"] == "ucdp"] if len(ev) else ev
    return ev if len(ev) else None


def cells(rows: pd.DataFrame, iso: str, year: int, worldbank: pd.DataFrame | None = None,
          as_of: str | None = None, events: pd.DataFrame | None = None) -> tuple[list[tuple], list[tuple]]:
    """([(key, value, source, series, licence)], [(key, reason)]) for one country (module docstring).
    Every rule is Team B's rule_cells, including 13.1 (HO-20261025-A-B-012, EQ-A-0118: the local override is gone)
    and, when `events` (UCDP monthly rows, ucdp_events) is given, 6.1 and 6.9 (section 19, HO-20261025-A-B-013)."""
    from econquest.rules.research import rule_cells          # Team B's rules (EQ-B-0101; C15, ADR-A-001)
    as_of = as_of or as_of_for(year)
    rows = _point_in_time(rows, as_of) if len(rows) else rows
    wb = _wb_frame(worldbank)
    got, blank = [], []
    for c in rule_cells(rows, [iso], as_of, wb, events=events).itertuples(index=False):
        if c.id in NOT_RESEARCH_IDS:
            continue
        value, status, reason, rule, dyear = c.value, c.status, c.reason, c.rule, c.data_year
        if value is None or pd.isna(value):
            blank.append((c.id, f"research: {reason or 'no value'}"))
            continue
        if c.id in UCDP_IDS:
            from econquest.ingestion.events.ucdp import LICENCE as UCDP_LICENCE
            src, lic = UCDP_SOURCE, f"{UCDP_LICENCE} (UCDP, Uppsala University)"
        else:
            src, lic = _origin(rows, c.id, iso, dyear)
        if c.id == "6.10" and "Gini missing" not in str(reason):
            src = "; ".join(x for x in (src, WB_GINI_SOURCE) if x)
            lic = "; ".join(x for x in (lic, "World Bank WDI (CC BY 4.0)") if x)
        if not src:                                    # Gini-only 6.10
            src, lic = WB_GINI_SOURCE, "World Bank WDI (CC BY 4.0)"
        series = f"{SERIES_PREFIX}{c.id}: {rule}; data year {dyear}; rule status {status}" + (f" ({reason})" if reason else "")
        got.append((c.id, float(value), src, series, lic))
    return got, blank


def gate_checks(report) -> pd.DataFrame:
    """Hold every research cell (module docstring). CHECK_COLUMNS rows."""
    from ..crosscheck import CHECK_COLUMNS
    prov = getattr(report, "provenance", None)
    out = []
    if prov is None or not len(prov) or "series" not in prov.columns:
        return pd.DataFrame(out, columns=CHECK_COLUMNS)
    mine = prov[(prov["table"] == "Inputs") & prov["series"].astype(str).str.startswith(SERIES_PREFIX)]
    lic_col = "licence" in mine.columns
    for r in mine.itertuples(index=False):
        keys = research_keys(r.licence) if lic_col else set()
        reasons = [] if keys and keys <= LAYOUT_VERIFIED else [UNVERIFIED_REASON]       # EQ-A-0126
        s = str(r.series)
        if "rule status hold" in s:
            why = s.split("rule status hold", 1)[1].strip(" ()")
            reasons.append(f"Team B rule hold: {why or 'hold'}")
        if str(r.key) in SIGNOFF_IDS:
            reasons.append(SIGNOFF_REASON)
        if not reasons:                    # layout verified, Team B's rule gave a value, no sign-off: the other checks decide
            continue
        out.append({"table": "Inputs", "key": str(r.key), "country": r.country, "check": "research", "status": "hold",
                    "reason": "; ".join(reasons), "live": r.value, "basis": s[:200]})
    return pd.DataFrame(out, columns=CHECK_COLUMNS)
