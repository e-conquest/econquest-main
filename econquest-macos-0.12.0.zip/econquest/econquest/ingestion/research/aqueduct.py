"""WRI Aqueduct 4.0 country rankings -> 7.12 Water stress (inputs). EQ-A-0067.

Licence (read 2026-10-25): https://www.wri.org/aqueduct says the datasets are "available for use under the Creative
Commons Attribution International 4.0 License" (link to CC BY 4.0). The dataset page
https://www.wri.org/data/aqueduct-40-country-rankings says only "Creative Commons" and shows a form (email, name,
organisation, use) next to the link https://files.wri.org/aqueduct/aqueduct-4-0-country-rankings.zip. Licence CC BY
4.0 (commercial use allowed, attribution). Whether the form is required before the link works is UNVERIFIED, so the
fetch mode is manual: download on the Mac into data/panel/research/aqueduct/ (zip or the xlsx inside it).

Layout UNVERIFIED (zip not opened here): a sheet with columns gid_0 (ISO3), name_0, indicator_name, weight, score,
cat, label. Rows with indicator_name "bws" (baseline water stress) and weight "Tot" (all sectors) are read; one row per
country, else refused. Baseline is static. Year stamp (Team B, indicator-rules 13.6, EQ-A-0095): the row's year is
the last year the baseline describes, DATA_YEAR = 2019 (Aqueduct 4.0 baseline 1979-2019 per Team B; Team A could not
read the period in the technical note doi 10.46830/writn.23.00061 on 2026-10-25: UNVERIFIED). The release is usable
only from its publication date, PUBLISHED = "2023-08" (month per Team B; exact day UNVERIFIED; the zip member name
seen in the layout description carries Y2023M07D05, a file stamp, not a publication date). 7.12 is static: the gate
applies no year staleness to it.

Output (inputs; the 0-4 level is Team B's rule): bws_score (Aqueduct 0-5 scale) and bws_cat (Aqueduct category, -1
arid and low water use, 0 low .. 4 extremely high). Using bws_cat directly as the 0-4 level, and what to do with -1, is
a Team B call (flagged), not done here.
"""
from __future__ import annotations

import pandas as pd

from .base import (CountryMapper, DatasetSpec, LayoutError, ResearchResult, check_range, load as _load, make_rows,
                   norm_col, read_excel_sheets, to_float, vintage_of, with_published, zip_member)

SPEC = DatasetSpec(
    key="aqueduct", name="WRI Aqueduct 4.0 country rankings", indicators=("7.12",),
    licence="CC BY 4.0 (World Resources Institute, Aqueduct 4.0)",
    client_ok=True, fetch_mode="manual",
    terms_url="https://www.wri.org/aqueduct",
    attribution=("World Resources Institute, Aqueduct 4.0 Current and Future Country Rankings (2023), CC BY 4.0. "
                 "Methodology: https://doi.org/10.46830/writn.23.00061"),
    file_globs=("aqueduct-4-0-country-rankings*.zip", "Aqueduct40*rankings*.xlsx", "aqueduct*.xlsx"),
    url="https://files.wri.org/aqueduct/aqueduct-4-0-country-rankings.zip",
    hosts=("files.wri.org",), max_bytes=100 * 1024 * 1024)

COLS = ["gid_0", "name_0", "indicator_name", "weight", "score", "cat"]
DATA_YEAR = 2019                    # 13.6: last baseline year, not the 2023 release year (rejected by Team B)
PUBLISHED = "2023-08"               # usable from (month; exact day UNVERIFIED)


def parse(body: bytes, name: str, version: str | None = None) -> ResearchResult:
    raw, member = body, name
    if name.lower().endswith(".zip"):
        member, body = zip_member(body, (".xlsx",))
    sheets = read_excel_sheets(body, f"Aqueduct {member}")
    hits = [(s, d) for s, d in sheets.items() if all(norm_col(x) in {norm_col(c) for c in d.columns} for x in COLS)
            and (d[[c for c in d.columns if norm_col(c) == "indicator_name"][0]].str.strip().str.lower() == "bws").any()]
    if len(hits) != 1:
        raise LayoutError(f"Aqueduct {member}: expected one sheet with {COLS} and bws rows, found "
                          f"{[s for s, _ in hits]} among {[(s, list(d.columns)[:8]) for s, d in sheets.items()]} "
                          f"(layout UNVERIFIED; refused)")
    sname, df = hits[0]
    cols = {norm_col(c): c for c in df.columns}
    sel = df[(df[cols["indicator_name"]].str.strip().str.lower() == "bws")
             & (df[cols["weight"]].str.strip().str.lower() == "tot")]
    if sel.empty:
        raise LayoutError(f"Aqueduct {member}: sheet {sname!r} has no bws rows with weight 'Tot'")
    cm = CountryMapper()
    recs = []
    for _, r in sel.iterrows():
        iso = cm(r[cols["gid_0"]], r[cols["name_0"]])
        if iso is None:
            continue
        for metric, col in (("bws_score", "score"), ("bws_cat", "cat")):
            v = to_float(r[cols[col]])
            if v is not None:
                recs.append(dict(indicator="7.12", iso3=iso, year=DATA_YEAR, value=v, metric=metric, kind="input"))
    version = version or "Aqueduct 4.0 (2023) baseline"
    vintage = vintage_of(version, raw, name)
    rows = make_rows(recs, SPEC, f"WRI Aqueduct ({version})", vintage)   # a second bws/Tot row per country refused
    check_range(rows, "bws_score", 0.0, 5.0, f"Aqueduct {member}")
    check_range(rows, "bws_cat", -1.0, 4.0, f"Aqueduct {member}")
    rows = with_published(rows, published_date())                      # ARCH-A-PI9 D1 (EQ-A-0108)
    return ResearchResult(rows, vintage, sorted(cm.unmapped),
                          [f"sheet read: {sname}", "inputs only: bws to 0-4 level is Team B's rule",
                           f"static baseline stamped data year {DATA_YEAR}; release usable from {PUBLISHED} "
                           f"(day UNVERIFIED)"])


def published_date() -> str:
    """13.6: the release is usable from the end of its publication month (PUBLISHED; exact day UNVERIFIED)."""
    return (pd.Timestamp(PUBLISHED) + pd.offsets.MonthEnd(0)).strftime("%Y-%m-%d")


def load(data_dir, path=None, **kw) -> ResearchResult:
    return _load(SPEC, parse, data_dir, path, **kw)
