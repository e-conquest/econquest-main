"""V-Dem country-year dataset -> 3.6 (indicator) and 4.3 (inputs). EQ-A-0067.

Licence (read 2026-10-25, https://www.v-dem.net/data/the-v-dem-dataset/): "published under a Creative Commons
Attribution-ShareAlike (CC BY-SA) 4.0 license"; the FAQ allows use including commercial use with attribution, and
adapted data must be shared under the same licence. Version v16 (March 2026), DOI https://doi.org/10.23696/vdemds26.

Fetch: manual. The download page is a form (email, format, privacy-consent checkbox), so the file is a Mac-side
download into data/panel/research/vdem/ (Core or Full+Others, CSV format, unzipped).

Layout: written against the codebook variable names (country_name, country_text_id, year, v2x_jucon, v2xlg_legcon,
v2x_regime, v2cacamps). Layout UNVERIFIED: no v16 file was opened here. Missing columns are refused.

Transforms:
  3.6  value = mean(v2x_jucon, v2xlg_legcon), both 0-1 (rule from data/rulebook.csv api column and
       coverage_source_map.csv). A country-year missing either index gets NO 3.6 value (v2xlg_legcon is missing where
       there is no legislature): whether to fall back to v2x_jucon alone is a Team B call (flagged), not done here.
  4.3  inputs only: v2x_regime (0 closed autocracy .. 3 liberal democracy), v2cacamps (political polarisation,
       V-Dem measurement-model scale) and v2cacamps_osp (the same on the original 0-4 scale). Team B's rule
       (indicator-rules.md 1 / 13.2) cuts v2cacamps_osp >= 3.0; it is the polarisation input (EQ-A-0095).
  3.6 / 13.1 (EQ-A-0095): v2lgbicam (legislature chambers, 0 = no legislature) is emitted as a 3.6 input, and where
       v2lgbicam = 0, v2x_jucon is known and v2xlg_legcon is missing, a 3.6 indicator row `jucon_half_no_legislature`
       = v2x_jucon / 2 (rule 3.6 v1: no legislature, legislative constraint 0). Kept apart from the mean metric so
       the provenance says which rule made it; it needs Sam's sign-off at first values (held by the gate).
  v2cacamps_osp and v2lgbicam are OPTIONAL columns (Core and Full+Others files differ; UNVERIFIED which carries
  them): absent -> not emitted, and ResearchResult.notes says so. A present column out of range is refused.
"""
from __future__ import annotations

import re

from .base import (CountryMapper, DatasetSpec, LayoutError, ResearchResult, check_range, load as _load,
                   make_rows, read_csv_bytes, require_columns, to_float, vintage_of, zip_member)

SPEC = DatasetSpec(
    key="vdem", name="V-Dem Country-Year dataset", indicators=("3.6", "4.3"),
    licence="CC BY-SA 4.0 (V-Dem Institute, V-Dem dataset; attribution, share-alike on adapted data)",
    client_ok=True, fetch_mode="manual",
    terms_url="https://www.v-dem.net/data/the-v-dem-dataset/",
    attribution=("Coppedge, Michael, John Gerring, Carl Henrik Knutsen, Staffan I. Lindberg, Jan Teorell, David "
                 "Altman, et al. 2026. V-Dem [Country-Year] Dataset v16. Varieties of Democracy (V-Dem) Project. "
                 "https://doi.org/10.23696/vdemds26"),
    file_globs=("V-Dem-CY-*.csv", "V-Dem-CY-*.zip", "vdem*.csv"),
    notes="ShareAlike: whether a scored indicator shown to a client is 'adapted material' is a licence call for Sam")

COLS = ["country_name", "country_text_id", "year", "v2x_jucon", "v2xlg_legcon", "v2x_regime", "v2cacamps"]
OPTIONAL = ["v2cacamps_osp", "v2lgbicam"]                 # EQ-A-0095 (indicator-rules 13.1, 13.2)
VERSION_RE = re.compile(r"v(\d{1,2}(?:\.\d)?)", re.I)


def parse(body: bytes, name: str, version: str | None = None) -> ResearchResult:
    if name.lower().endswith(".zip"):
        name_in, body = zip_member(body, (".csv",))
    df = read_csv_bytes(body, f"V-Dem {name}")
    c = require_columns(df, COLS, f"V-Dem {name}")
    opt = require_columns(df, [o for o in OPTIONAL if o.casefold() in {str(x).strip().casefold() for x in df.columns}],
                          f"V-Dem {name}")
    m = VERSION_RE.search(name)
    version = version or (f"V-Dem v{m.group(1)}" if m else "V-Dem version unknown")
    vintage = vintage_of(version, body, name)
    cm = CountryMapper()
    recs = []
    for _, r in df.iterrows():
        iso = cm(r[c["country_text_id"]], r[c["country_name"]])
        y = to_float(r[c["year"]])
        if iso is None or y is None:
            continue
        y = int(y)
        jud, leg = to_float(r[c["v2x_jucon"]]), to_float(r[c["v2xlg_legcon"]])
        for metric, v in (("v2x_jucon", jud), ("v2xlg_legcon", leg)):
            if v is not None:
                recs.append(dict(indicator="3.6", iso3=iso, year=y, value=v, metric=metric, kind="input"))
        if jud is not None and leg is not None:
            recs.append(dict(indicator="3.6", iso3=iso, year=y, value=(jud + leg) / 2.0,
                             metric="mean_v2x_jucon_v2xlg_legcon", kind="indicator"))
        bicam = to_float(r[opt["v2lgbicam"]]) if "v2lgbicam" in opt else None
        if bicam is not None:
            recs.append(dict(indicator="3.6", iso3=iso, year=y, value=bicam, metric="v2lgbicam", kind="input"))
            if bicam == 0 and jud is not None and leg is None:       # 13.1: no legislature -> legislative part 0
                recs.append(dict(indicator="3.6", iso3=iso, year=y, value=jud / 2.0,
                                 metric="jucon_half_no_legislature", kind="indicator"))
        for metric in ("v2x_regime", "v2cacamps", "v2cacamps_osp"):
            if metric not in c and metric not in opt:
                continue
            v = to_float(r[c.get(metric) or opt[metric]])
            if v is not None:
                recs.append(dict(indicator="4.3", iso3=iso, year=y, value=v, metric=metric, kind="input"))
    rows = make_rows(recs, SPEC, f"V-Dem ({version})", vintage)
    for metric in ("v2x_jucon", "v2xlg_legcon", "mean_v2x_jucon_v2xlg_legcon", "jucon_half_no_legislature"):
        check_range(rows, metric, 0.0, 1.0, f"V-Dem {name}")
    check_range(rows, "v2x_regime", 0.0, 3.0, f"V-Dem {name}")
    check_range(rows, "v2cacamps_osp", 0.0, 4.0, f"V-Dem {name}")
    check_range(rows, "v2lgbicam", 0.0, 2.0, f"V-Dem {name}")
    for metric, what in (("v2x_regime", "a whole class 0-3"), ("v2lgbicam", "a whole chamber count 0-2")):
        bad = rows.loc[rows["metric"] == metric, "value"] % 1
        if (bad != 0).any():
            raise LayoutError(f"V-Dem {name}: {metric} is not {what}")
    notes = ["3.6 mean blank where v2xlg_legcon or v2x_jucon is missing; no-legislature years (v2lgbicam 0) get "
             "jucon_half_no_legislature (rule 3.6 v1, indicator-rules 13.1, Sam's sign-off at first values)",
             "4.3 inputs only: level mapping is Team B's (section 1 / 13.2 on v2cacamps_osp)"]
    notes += [f"column {o} absent from this file: not emitted" for o in OPTIONAL if o not in opt]
    return ResearchResult(rows, vintage, sorted(cm.unmapped), notes)


def load(data_dir, path=None, **kw) -> ResearchResult:
    return _load(SPEC, parse, data_dir, path, **kw)
