"""UCDP GED from the CSV download: token-free UCDP input for 6.1, 6.9 and 6.12 (EQ-A-0108, coverage part 5).

Why. The UCDP API adapter (events/ucdp.py) needs the UCDP access token, which Sam has not received. The research
REGISTRY entry "ucdp" already names the token-free route: the GED CSV download (CC BY 4.0). This module reads that
CSV (and, optionally, a GED Candidate CSV for the months after the annual release) from a drop-in folder and turns it
into the SAME monthly rows as the API adapter (events.base.EVENT_COLUMNS, source "ucdp", metrics events_* and
fatalities_*), by calling events/ucdp.py's own map_countries and aggregate_monthly. Downstream (events.indicators,
events.export, Team B's long table) needs no change.

OFF BY DEFAULT. Nothing calls this module: it is not in research.REGISTRY's built list, not in feeds.fetch_all and
not in the pull pack. `summary` only reads and prints. `save` writes an append-only event vintage, and only when it is
run by hand (a Sam-gated step, listed in docs/runbooks/A-coverage-60.md section 11). No cell is filled by it: 6.1 and
6.9 levels are Team B's rules (handoff under EQ-A-0108), and every research cell is held at the gate anyway.

Source facts (UNVERIFIED unless stated; nothing was downloaded from the cloud):
- File: https://ucdp.uu.se/downloads/ged/ged261-csv.zip (name as recorded in research.REGISTRY["ucdp"]; UNVERIFIED).
  Candidate events: a monthly CSV from https://ucdp.uu.se/downloads/ (file name UNVERIFIED).
- Columns: the GED codebook field names, the same names the API returns. Only these are read and all are required:
  id, country, country_id (Gleditsch-Ward), type_of_violence (1, 2, 3), best, date_start. The exact CSV header of
  the 26.1 file is UNVERIFIED (Mac probe list); a missing column is refused, never guessed.
- Coverage: GED <yy>.1 ends 31 December 20<yy-1> (events/ucdp.ged_year_end). Months inside a file's coverage with no
  event are zero (an absent month means no fatal event); nothing outside coverage is filled.
- Licence: CC BY 4.0, cite UCDP (events/ucdp.LICENCE, CITATION).

Point in time. A GED release is published after its last covered month (GED 26.1 in 2026; exact date UNVERIFIED).
The rows carry period = event month and retrieved_utc = when the file was read; events.indicators(as_of_retrieval=True)
reproduces what a vintage held then. Staleness (indicator-rules 7: data end <= 92 days for 6.9; 4: 183 days for 6.12)
means an annual GED file alone is stale for most of the following year: the Candidate file is what keeps 6.9 live.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import io
import re
from pathlib import Path

import pandas as pd

from econquest.ingestion.events import ucdp as U
from econquest.ingestion.events.base import EventDataError, save_event_vintage, utc_stamp, validate_events

from .base import LayoutError, drop_folder, read_bytes, zip_member

KEY = "ucdp_ged"
REQUIRED = ["id", "country", "country_id", "type_of_violence", "best", "date_start"]
FILE_GLOBS = ("ged*.csv", "ged*-csv.zip", "GEDEvent*.csv", "GEDEvent*.zip")
MAX_BYTES = 400 * 1024 * 1024                    # GED global CSV is a few hundred MB unzipped (size UNVERIFIED)
URL = "https://ucdp.uu.se/downloads/ged/ged261-csv.zip"   # UNVERIFIED file name (REGISTRY["ucdp"].why)
MODE = "GED CSV (token-free; EQ-A-0108)"
# "ged261-csv.zip" -> 26.1 ; "GEDEvent_v26_1.csv" -> 26.1 ; "GEDEvent_v26_0_9.csv" -> 26.0.9 (Candidate)
_NAME_RE = re.compile(r"(?i)(?:gedevent_v|ged)(\d{2})[_.]?(\d{1,2})(?:[_.](\d{1,2}))?")


def version_of(name: str) -> str | None:
    """Dataset version from a file name, or None. Three parts (26.0.9) is a Candidate release, two (26.1) annual."""
    m = _NAME_RE.search(Path(name).name)
    if not m:
        return None
    return ".".join(p for p in m.groups() if p is not None)


def is_candidate(version: str) -> bool:
    return version.count(".") == 2


def read_events(body: bytes, name: str) -> pd.DataFrame:
    """The REQUIRED columns of a GED / Candidate CSV (or the one .csv inside a zip), as text. Refuses a layout
    without every REQUIRED column (names found are listed)."""
    if name.lower().endswith(".zip"):
        name, body = zip_member(body, (".csv",), max_bytes=MAX_BYTES)
    try:
        head = pd.read_csv(io.BytesIO(body), nrows=0)
    except (ValueError, pd.errors.ParserError) as e:
        raise LayoutError(f"UCDP GED {name}: not a CSV ({str(e)[:120]})") from None
    cols = {str(c).strip().lower(): c for c in head.columns}
    missing = [c for c in REQUIRED if c not in cols]
    if missing:
        raise LayoutError(f"UCDP GED {name}: columns {missing} missing (layout UNVERIFIED; refused). "
                          f"Found: {list(head.columns)[:20]}")
    df = pd.read_csv(io.BytesIO(body), usecols=[cols[c] for c in REQUIRED], dtype=str, keep_default_na=False)
    df = df[[cols[c] for c in REQUIRED]]                 # usecols keeps file order: put them in REQUIRED order
    df.columns = REQUIRED
    if (df["date_start"].str.strip() == "").any():
        raise LayoutError(f"UCDP GED {name}: events without date_start")
    return df


def _requested(df: pd.DataFrame, isos: list[str], by_id: dict, by_name: dict) -> pd.DataFrame:
    """Events whose country id or name maps to a requested ISO3 (the API filters by country server-side; the CSV is
    global, so other countries are skipped here, not treated as unmapped)."""
    want = set(isos)
    ids = {str(g) for g, i in by_id.items() if i in want}
    names = {n for n, i in by_name.items() if i in want}
    keep = df["country_id"].str.strip().isin(ids) | df["country"].str.strip().str.lower().isin(names)
    return df[keep]


def monthly(files: list[tuple[pd.DataFrame, str]], isos: list[str], retrieved_utc: str,
            country_map_csv: Path | None = None, start: dt.date | None = None) -> tuple[pd.DataFrame, dict]:
    """[(events frame from read_events, version)] -> (EVENT_COLUMNS monthly rows, provenance). At most one annual
    GED file and one Candidate file. Coverage: GED from `start` (default: January of its first event year) to
    ged_year_end(version); Candidate from the day after the GED end (or January of its first event year) to the end
    of its latest event month. Candidate events dated inside the GED coverage are dropped (GED is final)."""
    isos = sorted({str(i).upper() for i in isos})
    ged = [(d, v) for d, v in files if not is_candidate(v)]
    cand = [(d, v) for d, v in files if is_candidate(v)]
    if len(ged) > 1 or len(cand) > 1 or not files:
        raise LayoutError(f"UCDP GED: need one annual file and at most one Candidate file, got {[v for _, v in files]}")
    by_id, by_name = U.load_country_map(country_map_csv)
    events, coverage, prov = [], [], {"mode": MODE, "citation": U.CITATION, "licence": U.LICENCE, "isos": isos,
                                      "datasets": []}
    g_end = None
    for df, v in ged:
        if not U.VERSION_RE.fullmatch(v):
            raise LayoutError(f"bad UCDP GED version {v!r}")
        g_end = U.ged_year_end(v)
        dates = pd.to_datetime(df["date_start"].str.strip().str[:10], format="%Y-%m-%d", errors="coerce")
        if dates.isna().any():
            raise LayoutError("UCDP GED: date_start not YYYY-MM-DD")
        if dates.max().date() > g_end:
            raise LayoutError(f"UCDP GED {v}: events after {g_end}: not an annual GED {v} file")
        lo = start or dt.date(int(dates.min().year), 1, 1)
        sub = _requested(df[dates.dt.date >= lo], isos, by_id, by_name)
        events += sub.to_dict("records")
        coverage.append((lo, g_end))
        prov["datasets"].append({"dataset": "GED", "version": v, "start": lo.isoformat(), "end": g_end.isoformat(),
                                 "events_requested": len(sub), "events_in_file": len(df)})
    for df, v in cand:
        dates = pd.to_datetime(df["date_start"].str.strip().str[:10], format="%Y-%m-%d", errors="coerce")
        if dates.isna().any():
            raise LayoutError("UCDP Candidate: date_start not YYYY-MM-DD")
        lo = g_end + dt.timedelta(days=1) if g_end else dt.date(int(dates.min().year), 1, 1)
        hi = (dates.max() + pd.offsets.MonthEnd(0)).date()
        sub = _requested(df[dates.dt.date >= lo], isos, by_id, by_name)
        events += sub.to_dict("records")
        if hi >= lo:
            coverage.append((lo, hi))
        prov["datasets"].append({"dataset": "Candidate", "version": v, "start": lo.isoformat(), "end": hi.isoformat(),
                                 "events_requested": len(sub), "events_in_file": len(df)})
    for e, iso in zip(events, U.map_countries(events, by_id, by_name)):
        e["iso"] = iso
    try:
        out = U.aggregate_monthly(events, isos, coverage, retrieved_utc)
    except EventDataError as e:
        raise LayoutError(f"UCDP GED: {e}") from None
    prov["coverage"] = [[a.isoformat(), b.isoformat()] for a, b in coverage]
    return validate_events(out, source="ucdp"), prov


def local_files(data_dir: str | Path) -> list[Path]:
    folder = drop_folder(data_dir, KEY)
    found = sorted({p for g in FILE_GLOBS for p in folder.glob(g) if p.is_file()}) if folder.is_dir() else []
    return found


def load(data_dir: str | Path, isos: list[str] | None = None, versions: dict | None = None,
         now: dt.datetime | None = None, start: dt.date | None = None) -> tuple[pd.DataFrame, dict]:
    """Read every file in data/panel/research/ucdp_ged/ (local only; never the network). `versions` maps a file
    name to its version where the name does not carry one. FileNotFoundError when the folder has no file."""
    paths = local_files(data_dir)
    if not paths:
        raise FileNotFoundError(f"{KEY}: no file in {drop_folder(data_dir, KEY)} matching {list(FILE_GLOBS)}; "
                                f"download {URL} by hand (UNVERIFIED name) and drop it there")
    isos = isos or U.desk_isos(Path(data_dir))
    files, hashes = [], {}
    for p in paths:
        v = (versions or {}).get(p.name) or version_of(p.name)
        if not v:
            raise LayoutError(f"{KEY}: no version in file name {p.name!r}; pass it (--version NAME=26.1)")
        body = read_bytes(p, MAX_BYTES)
        hashes[p.name] = hashlib.sha256(body).hexdigest()
        files.append((read_events(body, p.name), v))
    rows, prov = monthly(files, isos, utc_stamp(now), start=start)
    prov["files"] = hashes
    return rows, prov


def save(data_dir: str | Path, rows: pd.DataFrame, prov: dict, now: dt.datetime | None = None) -> Path:
    """Append-only UCDP event vintage (events.base.save_event_vintage), the same store the API adapter writes."""
    return save_event_vintage(Path(data_dir), rows, "ucdp", now=now, provenance=prov)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.research.ucdp_ged",
                                 description="UCDP GED CSV (token-free) -> monthly UCDP event rows. Off by default.")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name, hlp in (("summary", "read the drop-in folder and print coverage and counts; writes nothing"),
                      ("save", "also save an append-only UCDP event vintage (Sam-gated)")):
        p = sub.add_parser(name, help=hlp)
        p.add_argument("--data-dir", default="data")
        p.add_argument("--isos", default="", help="comma-separated ISO3; default data/countries.csv")
        p.add_argument("--version", action="append", default=[], help="FILE=VERSION when the name has none")
        p.add_argument("--start", default="", help="YYYY-MM-DD, first month kept from the annual file")
    a = ap.parse_args(argv)
    versions = dict(x.split("=", 1) for x in a.version)
    isos = [i.strip().upper() for i in a.isos.split(",") if i.strip()] or None
    start = dt.date.fromisoformat(a.start) if a.start else None
    try:
        rows, prov = load(a.data_dir, isos, versions, start=start)
    except (FileNotFoundError, LayoutError, U.UnmappedCountryError) as e:
        print(f"refused: {e}")
        return 1
    print(f"{len(rows)} rows; coverage {prov['coverage']}; datasets {prov['datasets']}")
    tot = rows[rows["metric"] == "fatalities_best"].groupby("iso")["value"].sum()
    for iso, v in tot.items():
        print(f"  {iso}: fatalities_best {v:g} over the coverage")
    if a.cmd == "save":
        print(f"saved {save(a.data_dir, rows, prov)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
