"""UNHCR refugee statistics -> 6.12 Spillover from neighbors (inputs: displacement hosted). EQ-A-0067.

Source (read 2026-10-25): https://www.unhcr.org/refugee-statistics/insights/explainers/forcibly-displaced-api.html:
the API "is open to all and requires no special credentials" and returns JSON. Endpoint used here (from the
open-source refugees R package / UNHCR API clients, UNVERIFIED against UNHCR's own reference page):
    GET https://api.unhcr.org/population/v1/population/?cf_type=ISO&coa_all=true&yearFrom=YYYY&yearTo=YYYY&limit=..&page=..
Licence: the World Bank lists the UNHCR-derived series SM.POP.RHCR.EA as "License : CC BY-4.0"
(https://data.worldbank.org/indicator/SM.POP.RHCR.EA), and the refugees R package (UNHCR copyright holder) is CC BY
4.0. UNHCR's own data terms were not found: licence UNVERIFIED at source -> internal research use only until checked.

Layout UNVERIFIED: a page {"items": [...], "page": k, "maxPages": n}; each item has year, coa_iso and the counts
refugees, asylum_seekers (codebook names from the refugees package: year, coo_iso, coa_iso, refugees, asylum_seekers,
idps, ...). Counts "-" or empty are missing. A page without "items", or items without those fields, is refused.

Output (inputs; neighbour list and 0-4 level are Team B's rule): per country of asylum and year, refugees_hosted and
asylum_seekers_hosted (persons). Origin breakdowns (refugees FROM neighbours) need coo_all and the neighbour list:
wave 2 with Team B's rule.
UCDP (the other 6.12 input) is served by econquest.ingestion.events.ucdp (token), see research.REGISTRY["ucdp"].
"""
from __future__ import annotations

import json
import urllib.parse

from .base import (CountryMapper, DatasetSpec, LayoutError, ResearchResult, download, make_rows, to_float,
                   vintage_of)

SPEC = DatasetSpec(
    key="unhcr", name="UNHCR Refugee Population Statistics (API)", indicators=("6.12",),
    licence="internal research use only: UNHCR refugee statistics, licence UNVERIFIED at source (World Bank lists CC BY 4.0)",
    client_ok=False, fetch_mode="api",
    terms_url="https://www.unhcr.org/refugee-statistics/",
    attribution="UNHCR Refugee Population Statistics Database, https://www.unhcr.org/refugee-statistics/",
    file_globs=("unhcr_population*.json",),
    url="https://api.unhcr.org/population/v1/population/",
    hosts=("api.unhcr.org",), max_bytes=20 * 1024 * 1024)

PAGE_LIMIT = 1000
MAX_PAGES = 50
METRICS = (("refugees", "refugees_hosted"), ("asylum_seekers", "asylum_seekers_hosted"))


def page_url(year_from: int, year_to: int, page: int) -> str:
    q = {"cf_type": "ISO", "coa_all": "true", "yearFrom": int(year_from), "yearTo": int(year_to),
         "limit": PAGE_LIMIT, "page": int(page)}
    return SPEC.url + "?" + urllib.parse.urlencode(q)


def _page(body: bytes, what: str) -> dict:
    try:
        obj = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError, RecursionError) as e:
        raise LayoutError(f"UNHCR {what}: not JSON ({type(e).__name__})") from None
    if not isinstance(obj, dict) or not isinstance(obj.get("items"), list):
        raise LayoutError(f"UNHCR {what}: no 'items' list (keys {list(obj)[:10] if isinstance(obj, dict) else type(obj)}); "
                          f"layout UNVERIFIED: refused")
    return obj


def parse_pages(bodies: list[bytes], name: str = "api", version: str | None = None,
                raw: bytes | None = None) -> ResearchResult:
    """`raw`: the bytes of the saved file the pages came from, so the vintage sha256 is the file's (default: the
    pages joined by newlines, i.e. the API answers as received)."""
    cm = CountryMapper()
    recs, years = [], set()
    for i, body in enumerate(bodies):
        for it in _page(body, f"{name} page {i + 1}")["items"]:
            if not isinstance(it, dict) or not {"year", "coa_iso"} <= set(it) or not any(k in it for k, _ in METRICS):
                raise LayoutError(f"UNHCR {name}: item without year/coa_iso/refugees: {str(it)[:200]}")
            y = to_float(it["year"])
            iso = cm(it.get("coa_iso"), it.get("coa_name"))
            if y is None or iso is None:
                continue
            years.add(int(y))
            for k, metric in METRICS:
                v = to_float(it.get(k))
                if v is not None:
                    recs.append(dict(indicator="6.12", iso3=iso, year=int(y), value=v, metric=metric, kind="input"))
    joined = raw if raw is not None else b"\n".join(bodies)
    version = version or (f"UNHCR population {min(years)}-{max(years)}" if years else "UNHCR population (empty)")
    vintage = vintage_of(version, joined, name)
    rows = make_rows(recs, SPEC, f"UNHCR Refugee Population Statistics ({version})", vintage)
    if (rows["value"] < 0).any():
        raise LayoutError(f"UNHCR {name}: negative counts")
    return ResearchResult(rows, vintage, sorted(cm.unmapped),
                          ["inputs only: neighbour list and 0-4 level are Team B's rule"])


def parse(body: bytes, name: str, version: str | None = None) -> ResearchResult:
    """A saved API answer (one page, or a JSON list of pages) dropped in data/panel/research/unhcr/."""
    try:
        obj = json.loads(body.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError, RecursionError) as e:
        raise LayoutError(f"UNHCR {name}: not JSON ({type(e).__name__})") from None
    pages = obj if isinstance(obj, list) else [obj]
    return parse_pages([json.dumps(p).encode() for p in pages], name, version, raw=body)


def fetch(year_from: int, year_to: int, fetcher=None) -> ResearchResult:
    """All pages for coa_all over the years (Mac only; the cloud cannot reach api.unhcr.org)."""
    bodies, page = [], 1
    while True:
        b = download(SPEC, page_url(year_from, year_to, page), fetcher=fetcher)
        bodies.append(b)
        maxp = _page(b, f"page {page}").get("maxPages", 1)
        if not isinstance(maxp, int) or page >= maxp:
            break
        page += 1
        if page > MAX_PAGES:
            raise LayoutError(f"UNHCR: more than {MAX_PAGES} pages: refused (raise PAGE_LIMIT or narrow the years)")
    return parse_pages(bodies, f"api {year_from}-{year_to}")


def load(data_dir, path=None, **kw) -> ResearchResult:
    from .base import load as _load
    return _load(SPEC, parse, data_dir, path, **kw)
