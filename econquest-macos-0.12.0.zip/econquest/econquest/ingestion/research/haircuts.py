"""Cruces-Trebesch sovereign haircut dataset -> data/panel/cruces_trebesch_haircuts.csv (EQ-A-0098).

Replaces, once Team B refits (PI9-B2, EQ-B-0099 loader `restructuring.load_ct_haircuts`), the 17 exchanges typed from
memory in engine/restructuring.py REFERENCE_RESTRUCTURINGS. This module never edits the engine.

Source (read 2026-10-25, docs/runbooks/A-haircuts.md):
  * data page https://sites.google.com/site/christophtrebesch/data lists "Haircut dataset, 1970-2013" ("2014 update of
    haircut dataset", 187 restructurings with foreign banks/bondholders), link
    https://docs.google.com/spreadsheets/d/1yUUMPAEF9uKbYV6bG3dLZ6dzDQnkJqcS/export?format=xlsx
    (served as Cruces-Trebesch-Haircuts-2014-update.xlsx). The page states NO licence and no terms of use.
  * AEA replication package https://doi.org/10.3886/E114278V1 (openICPSR 114278 V1): no licence shown; "This material
    is distributed exactly as it arrived from the data depositor."
  Licence UNVERIFIED -> internal research use only (kept out of client output); redistribution not granted, so the
  workbook is NOT committed by Team A: Sam drops it on his Mac (fetch_mode manual; the cloud cannot reach the host and
  the Google link answers with a redirect, which the downloader refuses).

Layout (verified 2026-10-25 against the real 2014-update xlsx, sha256 50c5ab90..., 67,502 bytes, so
layout_verified=True): four sheets, "2014 Version (new)" (title "... 1970-2013"), "2014 Update Comments",
"README (2012 version)" and the superseded "2012 version (old)" (title "... 1970-2010", "Debt Affected" in place of
"Debt Restructured"). When several sheets carry an HSZ / HM header row, the one whose title row ends latest is used
(then "new" in the name, then the highest year in the name; a tie is refused) and the choice goes in provenance. The
table: a title block, then one header row (a leading empty column and "New Case?") holding "Case", "Country / Case",
"Code", "Date", "Debt Restructured (m US$)", "Preferred Haircut HSZ", "Market Haircut HM", "Face Value Reduction
(in %)", "Bond Exchange", ..., "Data Quality Index"; a units row "(1)".."(15)"; one row per case with an integer
"Case"; footnote rows after. Date is an Excel date cell (year and month used) or "MM / YYYY" text in a CSV export.
Bond Exchange is 0/1. Any other layout (a missing column, an unknown Date or Bond Exchange code, a percent value above
100%, a locale-formatted number) raises LayoutError. The 200-year dataset (Meyer, Reinhart, Trebesch 2025) has a
different, unseen layout and is refused until a parser is written from the file.

Output (Team B contract via AGENT-08, 2026-10-25), one row per exchange, haircuts as shares (0.768 = 76.8%):
  country, iso3, year, month, date_of_exchange (YYYY-MM-DD only when the source gives a day; CT gives month only,
  so it is blank and year + month carry the date), haircut_sz, haircut_market, debt_restructured_mm,
  face_value_reduction, debt_type (bond | bank, from Bond Exchange 1 | 0), debt_gdp, debt_gdp_year, debt_gdp_source,
  imf_program, imf_program_source, case_id, data_quality, blank_reasons, licence, source, vintage.
A blank is never filled: blank_reasons names each blank field and why.

debt_gdp: CT carries none. `debt_table` (iso3, year, debt_gdp in percent) from a named source fills it at the year
before the exchange year (the debt stock going into the exchange; same first choice as restructuring.ct_reference),
else blank. The only table in the repo is data/panel/hazard_panel.csv (IMF WEO GGXWDG_NGDP): rows filled from it carry
the imf_derived tag (EXC-003, internal use only) in `licence`. imf_program: no sourced programme table yet -> blank.

Vintages: every build is stored append-only under data/panel/research/haircuts/vintages/<id>/ (haircuts.csv,
provenance.json, files written once and made read-only, identical output not stored twice) and listed in
vintages/index.csv. `promote` copies a stored vintage to data/panel/cruces_trebesch_haircuts.csv plus
cruces_trebesch_haircuts.provenance.json (input sha256, output sha256, licence, sources).

CLI (Sam's Mac):  python -m econquest.ingestion.research.haircuts [--data-dir data] [--file PATH]
                  [--debt-gdp hazard_panel] [--promote]
"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import io
import json
import re
import sys
import zipfile
from pathlib import Path

import pandas as pd

from econquest.ingestion.safe_zip import ZipBudgetExceeded, check_zip_file

from .base import (INTERNAL_TAG, CountryMapper, DatasetSpec, LayoutError, drop_folder, find_local, read_bytes,
                   safe_text, sha256)

SPEC = DatasetSpec(
    key="haircuts", name="Cruces-Trebesch sovereign haircuts (2014 update)", indicators=(),
    licence=(f"{INTERNAL_TAG}: Cruces-Trebesch haircut dataset, licence UNVERIFIED (no terms on the data page; "
             "cite Cruces and Trebesch 2013)"),
    client_ok=False, fetch_mode="manual",
    terms_url="https://sites.google.com/site/christophtrebesch/data",
    attribution=("Cruces, Juan J., and Christoph Trebesch (2013). Sovereign Defaults: The Price of Haircuts. American "
                 "Economic Journal: Macroeconomics 5(3): 85-117. Data: 2014 update, christophtrebesch data page."),
    file_globs=("Cruces-Trebesch-Haircuts*.xlsx", "Cruces-Trebesch-Haircuts*.csv"),
    url="https://docs.google.com/spreadsheets/d/1yUUMPAEF9uKbYV6bG3dLZ6dzDQnkJqcS/export?format=xlsx",
    max_bytes=20 * 1024 * 1024, layout_verified=True,
    notes="event-level table, not indicator rows: not in research.REGISTRY; read by engine/restructuring (Team B)")

SOURCE = "Cruces-Trebesch haircut dataset, 2014 update (sites.google.com/site/christophtrebesch/data)"
OUT_NAME = "cruces_trebesch_haircuts.csv"            # == engine.restructuring.CT_DEFAULT_RELPATH under data/panel/
PROV_NAME = "cruces_trebesch_haircuts.provenance.json"
OUT_COLUMNS = ["country", "iso3", "year", "month", "date_of_exchange", "haircut_sz", "haircut_market",
               "debt_restructured_mm", "face_value_reduction", "debt_type", "debt_gdp", "debt_gdp_year",
               "debt_gdp_source", "imf_program", "imf_program_source", "case_id", "data_quality", "blank_reasons",
               "licence", "source", "vintage"]

# header (whitespace-collapsed, casefolded) -> internal name; all required
HEADERS = {
    "case": "case", "country / case": "country", "code": "code", "date": "date",
    "debt restructured (m us$)": "debt_mm", "preferred haircut hsz": "hsz", "market haircut hm": "hm",
    "face value reduction (in %)": "face", "bond exchange": "bond", "data quality index": "dq",
}
UNITS_RE = re.compile(r"\(\d{1,2}\)")
DATE_RE = re.compile(r"^\s*(\d{1,2})\s*/\s*(\d{4})\s*$")
LOCALE_NUM_RE = re.compile(r"^-?\d{1,3}(\.\d{3})+$|,")      # "9.900" or "30,3": European formatting, ambiguous
HAIRCUT_SHARE_RANGE = (-1.0, 1.0)                           # CT has small negative haircuts (Ukraine ING loan 1999)
IMF_DERIVED_TAG = "debt_gdp imf_derived (EXC-003, internal use only)"
DEBT_SOURCES = {"hazard_panel": ("panel/hazard_panel.csv", "iso", "year", "debt_gdp",
                                 "IMF WEO GGXWDG_NGDP via data/panel/hazard_panel.csv (imf_derived, EXC-003)", True)}


def _norm(c) -> str:
    return re.sub(r"\s+", " ", str(c)).strip().casefold()


# ------------------------------------------------------------------------------------------------- read

def _frames(body: bytes, name: str) -> dict[str, pd.DataFrame]:
    if name.lower().endswith(".csv"):
        try:
            return {"csv": pd.read_csv(io.BytesIO(body), header=None, dtype=str, keep_default_na=False,
                                       encoding="utf-8-sig")}
        except (UnicodeDecodeError, pd.errors.ParserError, ValueError) as e:
            raise LayoutError(f"{name}: not a readable CSV ({type(e).__name__}: {str(e)[:200]})") from None
    if not name.lower().endswith(".xlsx"):
        raise LayoutError(f"{name}: expected .xlsx or .csv")
    try:
        check_zip_file(io.BytesIO(body))                         # SEC-A-010 L1 before anything decompresses
    except zipfile.BadZipFile as e:
        raise LayoutError(f"{name}: not a readable .xlsx workbook (BadZipFile: {str(e)[:200]})") from None
    except ZipBudgetExceeded as e:
        raise LayoutError(f"{name}: workbook refused before unpacking: {e}") from None
    try:
        return pd.read_excel(io.BytesIO(body), sheet_name=None, header=None, dtype=object, engine="openpyxl")
    except Exception as e:                                       # openpyxl / xml errors: one refusal
        raise LayoutError(f"{name}: not a readable .xlsx workbook ({type(e).__name__}: {str(e)[:200]})") from None


TITLE_RANGE_RE = re.compile(r"\b(1[89]\d\d|20\d\d)\s*[-\u2013\u2014]\s*(1[89]\d\d|20\d\d)\b")
NAME_YEAR_RE = re.compile(r"(?<!\d)(1[89]\d\d|20\d\d)(?!\d)")


def _title_end_year(df: pd.DataFrame, header_row: int) -> int | None:
    """End year of the "YYYY-YYYY" range in the sheet's title row (the first non-blank row above the header), e.g.
    "Sovereign Debt Restructurings and Haircuts 1970-2013" -> 2013. None when the title has no range."""
    for i in range(header_row):
        filled = [str(v) for v in df.iloc[i].tolist() if not _blank(v)]
        if filled:
            ends = [int(m.group(2)) for m in TITLE_RANGE_RE.finditer(" ".join(filled))]
            return max(ends) if ends else None
    return None


def _sheet_rank(sheet, df: pd.DataFrame, i: int) -> tuple[int, int, int]:
    """(title end year, name says "new", highest year in the name); -1 / 0 when absent. Larger wins."""
    nm = str(sheet).casefold()
    end = _title_end_year(df, i)
    years = [int(y) for y in NAME_YEAR_RE.findall(nm)]
    return (end if end is not None else -1, int(bool(re.search(r"\bnew\b", nm))), max(years) if years else -1)


def _find_table(frames: dict[str, pd.DataFrame], name: str) -> tuple[str, pd.DataFrame, dict[str, int], list[str]]:
    """(sheet, frame below the header, {internal name: column index}, notes) for the haircut table.

    A candidate is a sheet with a header row holding "Preferred Haircut HSZ" and "Market Haircut HM". The real 2014
    workbook has two: "2014 Version (new)" (title "... 1970-2013") and the superseded "2012 version (old)" (title
    "... 1970-2010"). Several candidates are ranked by the end year of the title's year range, then by "new" in the
    sheet name, then by the highest year in the name; a tie at the top is refused, never guessed. The chosen sheet must
    then hold every HEADERS column."""
    hits = []
    for sheet, df in frames.items():
        for i in range(min(len(df), 60)):
            cells = {_norm(v): j for j, v in enumerate(df.iloc[i].tolist()) if not _blank(v)}
            if {"preferred haircut hsz", "market haircut hm"} <= set(cells):
                hits.append((sheet, df, i, cells, _sheet_rank(sheet, df, i)))
                break
    if not hits:
        raise LayoutError(f"{name}: no sheet with a 'Preferred Haircut HSZ' / 'Market Haircut HM' header row among "
                          f"sheets {[str(s)[:40] for s in frames]} (layout changed: refused)")
    hits.sort(key=lambda h: h[4], reverse=True)
    if len(hits) > 1 and hits[0][4] == hits[1][4]:
        tied = [str(h[0])[:40] for h in hits if h[4] == hits[0][4]]
        raise LayoutError(f"{name}: {len(hits)} sheets have a haircut header row and {tied} tie on (title end year, "
                          f"'new' in name, year in name) = {hits[0][4]}: refused, not guessed")
    sheet, df, i, cells, rank = hits[0]
    miss = [h for h in HEADERS if h not in cells]
    if miss:
        raise LayoutError(f"{name}: sheet {sheet!r} header row {i + 1} lacks {miss}; found {sorted(cells)[:30]}")
    notes = []
    if len(hits) > 1:
        notes.append(f"sheet chosen: {safe_text(str(sheet))[:60]!r} (title end year {rank[0]}) over "
                     + ", ".join(f"{safe_text(str(h[0]))[:60]!r} (title end year {h[4][0]})" for h in hits[1:]))
    return str(sheet), df.iloc[i + 1:].reset_index(drop=True), {HEADERS[h]: cells[h] for h in HEADERS}, notes


def _blank(v) -> bool:
    return v is None or (isinstance(v, float) and v != v) or str(v).strip() in ("", "nan", "NaT")


def _num(v, what: str, *, share: bool = False) -> float | None:
    """A number from a cell. share=True: '76.8%' -> 0.768, a bare number is already a share. Locale-formatted text
    ("9.900", "30,3%") is ambiguous and refused, never guessed."""
    if _blank(v):
        return None
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return float(v)
    s = str(v).strip()
    pct = s.endswith("%")
    core = s[:-1].strip() if pct else s
    if LOCALE_NUM_RE.search(core):
        raise LayoutError(f"{what}: {s!r} is locale-formatted (thousands dots / decimal commas): save the original "
                          f".xlsx in the drop-in folder instead of a regional CSV export")
    try:
        x = float(core)
    except ValueError:
        raise LayoutError(f"{what}: {s!r} is not a number") from None
    if pct and not share:
        raise LayoutError(f"{what}: {s!r} is a percent in a non-share column")
    return x / 100.0 if pct else x


def _date(v, what: str) -> tuple[int, int]:
    if isinstance(v, (dt.datetime, dt.date, pd.Timestamp)):
        return int(v.year), int(v.month)                         # an Excel date cell: the day shown is not data
    m = DATE_RE.match(str(v))
    if not m or not 1 <= int(m.group(1)) <= 12:
        raise LayoutError(f"{what}: Date {str(v)[:40]!r} is not 'MM / YYYY'")
    return int(m.group(2)), int(m.group(1))


# ------------------------------------------------------------------------------------------------- parse

def parse(body: bytes, name: str, *, debt_table: pd.DataFrame | None = None, debt_source: str = "",
          debt_imf_derived: bool = False, version: str | None = None) -> dict:
    """{"rows": DataFrame[OUT_COLUMNS], "unmapped": [...], "notes": [...], "input_sha256", "sheet", "sheet_choice"}.

    debt_table: iso3, year, debt_gdp (percent of GDP) from the named `debt_source`; debt_imf_derived tags the rows it
    fills with IMF_DERIVED_TAG."""
    sheet, df, c, choice = _find_table(_frames(body, name), name)
    cm = CountryMapper()
    vintage = f"{version or 'CT 2014 update'}; sha256:{sha256(body)[:16]}; {Path(name).name}"
    debt = {}
    if debt_table is not None:
        if not debt_source:
            raise ValueError("debt_table needs a named debt_source")
        t = debt_table.dropna(subset=["debt_gdp"])
        debt = {(str(i).upper(), int(y)): float(v) for i, y, v in zip(t["iso3"], t["year"], t["debt_gdp"])}
    recs, seen, notes = [], set(), []
    for k, r in df.iterrows():
        cells = r.tolist()
        filled = [str(v).strip() for v in cells if not _blank(v)]
        if not filled or all(UNITS_RE.fullmatch(v) for v in filled):   # blank row or the units row "(1)".."(15)"
            continue
        case, country = cells[c["case"]], cells[c["country"]]
        if _blank(case):
            if any(not _blank(cells[c[x]]) for x in ("hsz", "hm", "date")):
                raise LayoutError(f"{name}: row {k + 1} below the header has data but no Case number")
            notes.append(f"footnote: {safe_text(' '.join(filled))}")
            continue
        if not re.fullmatch(r"\d+(\.0+)?", str(case).strip()):
            raise LayoutError(f"{name}: Case {str(case)[:20]!r} is not an integer")
        cid = float(str(case).strip())
        cid = int(cid)
        if cid in seen:
            raise LayoutError(f"{name}: Case {cid} appears twice")
        seen.add(cid)
        what = f"{name} case {cid}"
        if _blank(country):
            raise LayoutError(f"{what}: no country")
        year, month = _date(cells[c["date"]], what)
        hsz = _num(cells[c["hsz"]], f"{what} HSZ", share=True)
        hm = _num(cells[c["hm"]], f"{what} HM", share=True)
        face = _num(cells[c["face"]], f"{what} face value reduction", share=True)
        for lab, x in (("HSZ", hsz), ("HM", hm), ("face value reduction", face)):
            if x is not None and not HAIRCUT_SHARE_RANGE[0] <= x <= HAIRCUT_SHARE_RANGE[1]:
                raise LayoutError(f"{what}: {lab} {x} outside {HAIRCUT_SHARE_RANGE} as a share: scale differs, refused")
        bond = _num(cells[c["bond"]], f"{what} Bond Exchange")
        if bond not in (0.0, 1.0):
            raise LayoutError(f"{what}: Bond Exchange {cells[c['bond']]!r}; expected 0 or 1")
        name_check = re.sub(r"\(.*?\)|\*", "", str(country)).strip()
        iso = cm(cells[c["code"]], name_check)
        if iso is None:
            continue                                             # listed in unmapped, never guessed
        blanks = ["date_of_exchange: source gives month and year only"]
        if hsz is None:
            blanks.append("haircut_sz: blank in source")
        if hm is None:
            blanks.append("haircut_market: blank in source")
        if face is None:
            blanks.append("face_value_reduction: blank in source")
        debt_mm = _num(cells[c["debt_mm"]], f"{what} debt restructured")
        if debt_mm is None:
            blanks.append("debt_restructured_mm: blank in source")
        dgdp, dyear, dsrc = None, None, ""
        if debt:
            v = debt.get((iso, year - 1))
            if v is None:
                blanks.append(f"debt_gdp: no value for {iso} {year - 1} in {debt_source}")
            else:
                dgdp, dyear, dsrc = v, year - 1, debt_source
        else:
            blanks.append("debt_gdp: no debt/GDP source passed (CT carries none)")
        blanks.append("imf_program: no sourced IMF programme table")
        lic = SPEC.licence + (f"; {IMF_DERIVED_TAG}" if dgdp is not None and debt_imf_derived else "")
        recs.append({"country": safe_text(str(country).strip()), "iso3": iso, "year": year, "month": month,
                     "date_of_exchange": "", "haircut_sz": hsz, "haircut_market": hm,
                     "debt_restructured_mm": debt_mm, "face_value_reduction": face,
                     "debt_type": "bond" if bond == 1.0 else "bank", "debt_gdp": dgdp, "debt_gdp_year": dyear,
                     "debt_gdp_source": dsrc, "imf_program": None, "imf_program_source": "",
                     "case_id": cid, "data_quality": _num(cells[c["dq"]], f"{what} data quality"),
                     "blank_reasons": "; ".join(blanks), "licence": lic, "source": SOURCE, "vintage": vintage})
    if not recs:
        raise LayoutError(f"{name}: no case rows under the header in sheet {sheet!r}")
    rows = pd.DataFrame(recs, columns=OUT_COLUMNS).sort_values(["iso3", "year", "month", "case_id"])
    rows = rows.reset_index(drop=True)
    for col in ("year", "month", "case_id", "debt_gdp_year", "imf_program"):
        rows[col] = rows[col].astype("Int64")
    return {"rows": rows, "unmapped": sorted(safe_text(u) for u in cm.unmapped), "notes": notes,
            "input_sha256": sha256(body), "input_name": Path(name).name, "sheet": safe_text(sheet),
            "sheet_choice": choice[0] if choice else "only sheet with a haircut header row", "cases": len(seen)}


def debt_table_from(data_dir: str | Path, key: str) -> tuple[pd.DataFrame, str, bool]:
    """(iso3, year, debt_gdp) table, source text, imf_derived flag for a DEBT_SOURCES key."""
    rel, iso_c, yr_c, v_c, text, imf = DEBT_SOURCES[key]
    p = Path(data_dir) / rel
    if not p.is_file():
        raise FileNotFoundError(f"debt/GDP source {key}: {p} not found")
    t = pd.read_csv(p, usecols=[iso_c, yr_c, v_c]).rename(columns={iso_c: "iso3", yr_c: "year", v_c: "debt_gdp"})
    return t, f"{text}, file sha256:{hashlib.sha256(p.read_bytes()).hexdigest()[:16]}", imf


# ------------------------------------------------------------------------------------------------- vintages

def _csv_bytes(rows: pd.DataFrame) -> bytes:
    return rows.to_csv(index=False, lineterminator="\n", quoting=csv.QUOTE_MINIMAL).encode()


def _write_once(p: Path, body: bytes) -> None:
    with open(p, "xb") as f:
        f.write(body)
    p.chmod(0o444)


def vintage_root(data_dir: str | Path) -> Path:
    return drop_folder(data_dir, SPEC.key) / "vintages"


def store_vintage(data_dir: str | Path, res: dict, now: dt.datetime | None = None) -> tuple[str, bool]:
    """(vintage id, created). Append-only: identical output (same sha256) is not stored again."""
    out = _csv_bytes(res["rows"])
    out_sha = sha256(out)
    root = vintage_root(data_dir)
    root.mkdir(parents=True, exist_ok=True)
    index = root / "index.csv"
    if index.is_file():
        for r in csv.DictReader(index.open()):
            if r["output_sha256"] == out_sha and (root / r["vintage_id"] / "haircuts.csv").is_file():
                return r["vintage_id"], False
    now = now or dt.datetime.now(dt.timezone.utc)
    vid = f"{now.strftime('%Y%m%dT%H%M%SZ')}-{out_sha[:8]}"
    d = root / vid
    d.mkdir()
    prov = provenance(res, out_sha, vid)
    _write_once(d / "haircuts.csv", out)
    _write_once(d / "provenance.json", json.dumps(prov, indent=2, sort_keys=True).encode())
    new = not index.is_file()
    with index.open("a", newline="") as f:
        w = csv.writer(f, lineterminator="\n")
        if new:
            w.writerow(["vintage_id", "created_utc", "input_name", "input_sha256", "output_sha256", "rows"])
        w.writerow([vid, now.strftime("%Y-%m-%dT%H:%M:%SZ"), res["input_name"], res["input_sha256"], out_sha,
                    len(res["rows"])])
    return vid, True


def provenance(res: dict, out_sha: str, vid: str) -> dict:
    rows = res["rows"]
    return {"ticket": "EQ-A-0098", "vintage_id": vid, "dataset": SPEC.name, "source": SOURCE,
            "terms_url": SPEC.terms_url, "download_url": SPEC.url, "attribution": SPEC.attribution,
            "licence": SPEC.licence, "licence_status": "UNVERIFIED (no terms stated; read 2026-10-25)",
            "client_ok": SPEC.client_ok, "input_name": res["input_name"], "input_sha256": res["input_sha256"],
            "sheet": res["sheet"], "sheet_choice": res.get("sheet_choice", ""), "sha256": out_sha,
            "output_sha256": out_sha, "rows": int(len(rows)), "cases_in_file": res["cases"],
            "unmapped_dropped": res["unmapped"], "footnotes": res["notes"],
            "debt_gdp_sources": sorted(set(rows["debt_gdp_source"]) - {""}),
            "debt_gdp_filled": int(rows["debt_gdp"].notna().sum()),
            "imf_program_source": "none (blank in every row)", "layout_verified": SPEC.layout_verified,
            "haircut_units": "shares (0.768 = 76.8%)"}


def promote(data_dir: str | Path, vid: str) -> Path:
    """Copy a stored vintage to data/panel/cruces_trebesch_haircuts.csv + provenance sidecar (atomic replace)."""
    src = vintage_root(data_dir) / vid
    if not re.fullmatch(r"\d{8}T\d{6}Z-[0-9a-f]{8}", vid) or not (src / "haircuts.csv").is_file():
        raise ValueError(f"no stored haircut vintage {vid!r}")
    # SEC-A-011 L2: the bytes promoted are the bytes stored (output sha256 in the id, index.csv and provenance.json)
    body = {"haircuts.csv": (src / "haircuts.csv").read_bytes(), "provenance.json": (src / "provenance.json").read_bytes()}
    got = sha256(body["haircuts.csv"])
    index = vintage_root(data_dir) / "index.csv"
    listed = ({r.get("output_sha256") for r in csv.DictReader(index.open()) if r.get("vintage_id") == vid}
              if index.is_file() else set())
    try:
        prov_sha = json.loads(body["provenance.json"]).get("output_sha256")
    except (ValueError, AttributeError):
        prov_sha = None
    if not (vid.endswith(got[:8]) and listed == {got} and prov_sha == got):
        raise ValueError(f"haircut vintage {vid!r} does not match its recorded sha256 (index.csv / provenance.json): "
                         "not promoted")
    panel = Path(data_dir) / "panel"
    for name, dest in (("haircuts.csv", OUT_NAME), ("provenance.json", PROV_NAME)):
        tmp = panel / f".{dest}.{vid}.tmp"
        tmp.write_bytes(body[name])
        tmp.replace(panel / dest)
    return panel / OUT_NAME


def build(data_dir: str | Path, path: str | Path | None = None, debt_gdp: str | None = None,
          do_promote: bool = False) -> dict:
    path = path or find_local(data_dir, SPEC)
    if path is None:
        raise FileNotFoundError(f"no file in {drop_folder(data_dir, SPEC.key)} matching {list(SPEC.file_globs)}: "
                                f"download {SPEC.url} (saves as Cruces-Trebesch-Haircuts-2014-update.xlsx) by hand")
    body = read_bytes(path, SPEC.max_bytes)
    kw = {}
    if debt_gdp:
        t, src, imf = debt_table_from(data_dir, debt_gdp)
        kw = {"debt_table": t, "debt_source": src, "debt_imf_derived": imf}
    res = parse(body, Path(path).name, **kw)
    vid, created = store_vintage(data_dir, res)
    res.update(vintage_id=vid, vintage_created=created)
    if do_promote:
        res["promoted"] = str(promote(data_dir, vid))
    return res


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.research.haircuts", description=__doc__.split("\n")[0])
    ap.add_argument("--data-dir", default="data")
    ap.add_argument("--file")
    ap.add_argument("--debt-gdp", choices=sorted(DEBT_SOURCES))
    ap.add_argument("--promote", action="store_true", help=f"write data/panel/{OUT_NAME} from the vintage")
    a = ap.parse_args(argv)
    try:
        res = build(a.data_dir, a.file, a.debt_gdp, a.promote)
    except (LayoutError, FileNotFoundError) as e:
        print(f"refused: {e}", file=sys.stderr)
        return 2
    r = res["rows"]
    print(f"{len(r)} exchanges ({r['iso3'].nunique()} countries) from {res['input_name']} sha256 "
          f"{res['input_sha256'][:16]}; vintage {res['vintage_id']} ({'created' if res['vintage_created'] else 'already stored'})"
          f"; debt_gdp filled {int(r['debt_gdp'].notna().sum())}; unmapped {res['unmapped'] or 'none'}"
          + (f"; promoted {res['promoted']}" if res.get("promoted") else ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())
