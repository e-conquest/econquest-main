"""WJP Rule of Law Index -> 3.7 Civil justice and contract enforcement (Factor 7 score, 0-1). EQ-A-0067.

Licence: UNVERIFIED. Read 2026-10-25: the index page (https://worldjusticeproject.org/rule-of-law-index/), the data
page (https://worldjusticeproject.org/our-work/research-and-data/wjp-rule-law-index-2020/current-historical-data),
the Terms of Service (https://worldjusticeproject.org/terms-service: "These Terms apply only to use of the Community
Forum") and the Copyright Policy (https://worldjusticeproject.org/resources/copyright-policy) state no licence for
the data; the only rights text is "(c) World Justice Project 2008-2025". So: all rights reserved by default, commercial
use unconfirmed -> tagged internal research use only (kept out of client output) until WJP confirms terms.

Fetch: direct. The data page links the file directly (no form seen):
https://worldjusticeproject.org/sites/default/files/documents/FINAL_2021_wjp_rule_of_law_index_HISTORICAL_DATA_FILE.xlsx
That is the 2021 file; the URL of the current (2025/2026) historical file is UNVERIFIED, so a newer file goes into
data/panel/research/wjp/ by hand.

Layout UNVERIFIED (no file opened here): a sheet with columns Country, Year and "Factor 7: Civil Justice" (and
optionally "Country Code"). Any other layout (older transposed files: indicators in rows) is refused.
Year (Team B, indicator-rules 13.7, EQ-A-0095): WJP labels some editions with two years ("2017-2018"); the row's
year is the FIRST year of the label (data collected then; the last year was rejected). Single-year labels keep their
year. Every edition also gets an input row `edition_last_year` (the label's last year) so the gate can apply the
point-in-time rule: an edition is usable from its publication date in PUBLISHED (edition label -> YYYY-MM-DD), else
from 31 December of the label's last year (the cautious default). PUBLISHED is empty: no WJP release-note date was
read here (UNVERIFIED), so every edition uses the default.
"""
from __future__ import annotations

import re

from .base import (CountryMapper, DatasetSpec, LayoutError, ResearchResult, check_range, load as _load, make_rows,
                   norm_col, read_excel_sheets, to_float, vintage_of, with_published)

SPEC = DatasetSpec(
    key="wjp", name="WJP Rule of Law Index", indicators=("3.7",),
    licence="internal research use only: WJP Rule of Law Index, licence UNVERIFIED (no terms stated; (c) World Justice Project)",
    client_ok=False, fetch_mode="direct",
    terms_url="https://worldjusticeproject.org/resources/copyright-policy",
    attribution="World Justice Project. WJP Rule of Law Index. https://worldjusticeproject.org/rule-of-law-index/",
    file_globs=("*wjp*rule*of*law*.xlsx", "*WJP*.xlsx", "wjp*.xlsx"),
    url="https://worldjusticeproject.org/sites/default/files/documents/FINAL_2021_wjp_rule_of_law_index_HISTORICAL_DATA_FILE.xlsx",
    hosts=("worldjusticeproject.org",), max_bytes=30 * 1024 * 1024)

FACTOR7 = re.compile(r"^factor 7\s*:\s*civil justice$")
PUBLISHED: dict[str, str] = {}      # edition label -> publication date (WJP release notes); none recorded yet
YEAR_LABEL = re.compile(r"^(\d{4})(?:\s*[-/]\s*(\d{4}))?$")


def _sheet(sheets):
    found = []
    for sname, df in sheets.items():
        cols = {norm_col(c): c for c in df.columns}
        f7 = [c for k, c in cols.items() if FACTOR7.fullmatch(k)]
        found.append(f"{sname}: {list(df.columns)[:12]}")
        if "country" in cols and "year" in cols and len(f7) == 1:
            return sname, df, cols["country"], cols["year"], f7[0], cols.get("country code")
    raise LayoutError("WJP: no sheet with columns Country, Year and 'Factor 7: Civil Justice' (layout UNVERIFIED; "
                      "refused). Sheets found: " + " | ".join(found))


def parse(body: bytes, name: str, version: str | None = None) -> ResearchResult:
    sname, df, ccol, ycol, fcol, codecol = _sheet(read_excel_sheets(body, f"WJP {name}"))
    cm = CountryMapper()
    recs, years, labels = [], set(), set()
    for _, r in df.iterrows():
        lab = str(r[ycol]).strip()
        if lab.endswith(".0"):
            lab = lab[:-2]
        m = YEAR_LABEL.fullmatch(lab)
        v = to_float(r[fcol])
        if not m or v is None:
            continue
        iso = cm(r[codecol] if codecol else None, r[ccol])
        if iso is None:
            continue
        y, last = int(m.group(1)), int(m.group(2) or m.group(1))     # 13.7: first year of a two-year label
        years.add(y)
        if m.group(2):
            labels.add(lab)
        recs.append(dict(indicator="3.7", iso3=iso, year=y, value=v, metric="factor7_civil_justice", kind="indicator"))
        recs.append(dict(indicator="3.7", iso3=iso, year=y, value=float(last), metric="edition_last_year",
                         kind="input"))
    if not recs:
        raise LayoutError(f"WJP {name}: sheet {sname!r} has no usable Factor 7 rows")
    version = version or f"WJP Rule of Law Index (latest year in file {max(years)})"
    vintage = vintage_of(version, body, name)
    rows = make_rows(recs, SPEC, f"WJP Rule of Law Index ({version})", vintage)     # duplicates refused there
    check_range(rows, "factor7_civil_justice", 0.0, 1.0, f"WJP {name}")
    rows = with_published(rows, published_dates(rows))                 # ARCH-A-PI9 D1 (EQ-A-0108)
    notes = [f"two-year edition labels {sorted(labels)} mapped to their first year (indicator-rules 13.7)"] if labels else []
    notes.append("publication dates: none recorded (PUBLISHED empty); usable from 31 December of the label's last year "
                 "(written in the `published` column)")
    return ResearchResult(rows, vintage, sorted(cm.unmapped), notes)


def published_dates(rows) -> list[str]:
    """13.7 per row: the edition's recorded date (PUBLISHED, by label), else 31 December of the label's last year.
    The label is rebuilt from the row's year and its edition_last_year row (same country and year)."""
    ed = rows[rows["metric"] == "edition_last_year"]
    last = {(i, int(y)): int(v) for i, y, v in zip(ed["iso3"], ed["year"], ed["value"])}
    out = []
    for i, y in zip(rows["iso3"], rows["year"]):
        y = int(y)
        lst = last.get((i, y), y)
        label = str(y) if lst == y else f"{y}-{lst}"
        out.append(PUBLISHED.get(label, f"{lst}-12-31"))
    return out


def load(data_dir, path=None, **kw) -> ResearchResult:
    return _load(SPEC, parse, data_dir, path, **kw)
