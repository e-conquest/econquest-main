"""Research-dataset adapters (EQ-A-0067). Wired into feeds.fetch_all as feed `research` by research/wiring.py
(EQ-A-0095): built adapters read their drop-in folders; every cell they produce is held at the gate.

REGISTRY maps a dataset key to an Entry:
    module       dotted module path ("" when no adapter is built yet)
    indicators   indicators.csv ids it serves (as the indicator itself or as an input for a Team B rule)
    licence      licence tag written on its rows (see base.py LICENCE TAGS)
    client_ok    False: internal research use only (kept out of client output, like the IMF under EXC-003)
    fetch_mode   manual (drop-in folder data/panel/research/<key>/, Mac download) | direct | api | api_token
    status       built | existing (adapter elsewhere in the repo) | deferred | blocked
    why          for deferred / blocked: the reason, for AGENT-08 and Sam

Each built module exposes SPEC (base.DatasetSpec), parse(body, name, version=None) and load(data_dir, path=None,
fetch=False, ...). Licence checks, quotes and URLs: docs/runbooks/A-research-datasets.md.

Importing the package imports the built adapter modules to read their SPECs; that does no file or network I/O.
"""
from __future__ import annotations

import importlib
from dataclasses import dataclass


@dataclass(frozen=True)
class Entry:
    module: str
    indicators: tuple
    licence: str
    client_ok: bool
    fetch_mode: str
    status: str
    why: str = ""


_P = "econquest.ingestion.research."


def _built(key: str) -> Entry:
    spec = importlib.import_module(_P + key).SPEC
    return Entry(_P + key, spec.indicators, spec.licence, spec.client_ok, spec.fetch_mode, "built")


REGISTRY: dict[str, Entry] = {k: _built(k) for k in ("vdem", "wjp", "coups", "goci", "ndgain", "epr", "aqueduct", "unhcr")}

REGISTRY["ucdp"] = Entry(
    "econquest.ingestion.events.ucdp", ("6.1", "6.9", "6.12"), "CC BY 4.0 (UCDP, Uppsala University)", True,
    "api_token", "existing",
    "GED API adapter already in events/ucdp.py (token UCDP_API_TOKEN, requested by Sam); 6.1 level via "
    "events/indicators.py; 6.12 also needs Team B's neighbour rule. Token-free alternative: the GED CSV "
    "(https://ucdp.uu.se/downloads/ged/ged261-csv.zip, CC BY 4.0) - built in research/ucdp_ged.py (EQ-A-0108): same "
    "monthly rows as the API adapter, off by default, run by hand only (file name and header UNVERIFIED)")
REGISTRY["undrr"] = Entry(
    "", ("7.1", "7.2"), "", False, "manual", "blocked",
    "no current country AAL/PML file located (GAR pages list none; GIRI successor is GeoTIFF, (c) CDRI all rights "
    "reserved); undrr.org terms allow 'personal, non-commercial use' without redistribution or derivative works: "
    "licence decision for Sam")
REGISTRY["gti"] = Entry(
    "", ("6.13",), "", False, "manual", "blocked",
    "IEP data is CC BY-NC-SA 4.0 and 'Commercial organisations using IEP data must purchase a Commercial Licence "
    "before downloading any datasets' (economicsandpeace.org/consulting/data-licensing); the request form asks the "
    "licence type: Sam decides (buy, or skip)")
REGISTRY["ipc"] = Entry(
    "", ("6.11",), "", False, "api_token", "deferred",
    "IPC API needs a key issued after a request form; API terms not read (linked page); '(c) IPC. All rights "
    "reserved.' Credential + licence decision for Sam; covers about 20 of 88 countries")
REGISTRY["ciesin"] = Entry(
    "", ("7.8",), "", False, "manual", "deferred",
    "LECZ v3 is CC BY 4.0 but ships as a macro-enabled pivot workbook (.xlsm) via NASA Earthdata (login UNVERIFIED); "
    "instead: World Bank WDI EN.POP.EL5M.ZS (population below 5 m, from CIESIN LECZ v3; code present in WDI metadata, "
    "read 2026-10-25; data UNVERIFIED) is fetched raw-only by the World Bank feed (EQ-A-0095) and is on the Mac probe "
    "list; no 7.8 cell until Team B chooses 5 m vs 10 m")


def module(key: str):
    """The adapter module for `key` (ImportError for entries without one)."""
    e = REGISTRY[key]
    if not e.module:
        raise ImportError(f"research dataset {key!r} has no adapter ({e.status}): {e.why}")
    return importlib.import_module(e.module)


def built() -> list[str]:
    return [k for k, e in REGISTRY.items() if e.status == "built"]
