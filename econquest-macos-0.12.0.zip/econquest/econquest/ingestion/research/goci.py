"""GI-TOC Global Organized Crime Index -> 6.7 Illegal economy: criminal markets score (1-10). EQ-A-0067.

Source (read 2026-10-25): https://ocindex.net/downloads lists the dataset as a direct XLSX,
https://ocindex.net/assets/downloads/global_oc_index.xlsx, with no form (feedback survey and mailing list optional).
Editions 2021, 2023, 2025. No licence, Creative Commons or terms-of-use text on ocindex.net or /downloads; the only
rights text is the page's copyright metadata "Global Initiative Against Transnational Organized Crime". Licence
UNVERIFIED -> internal research use only.

Layout UNVERIFIED (no file opened here): every sheet that has a Country column and a "Criminal markets" column is read;
the year comes from a Year column if present, else from a four-digit year (2019-2039) in the sheet name, else the
sheet is refused. Values must lie in 1-10 (the index scale), else refused. No transform: the indicator is the score.
The file name carries no edition, so the vintage records the editions found plus the file hash.
"""
from __future__ import annotations

import re

from .base import (CountryMapper, DatasetSpec, LayoutError, ResearchResult, check_range, load as _load, make_rows,
                   norm_col, read_excel_sheets, to_float, vintage_of)

SPEC = DatasetSpec(
    key="goci", name="Global Organized Crime Index (GI-TOC)", indicators=("6.7",),
    licence="internal research use only: GI-TOC Global Organized Crime Index, licence UNVERIFIED (no terms stated)",
    client_ok=False, fetch_mode="direct",
    terms_url="https://ocindex.net/downloads",
    attribution="Global Initiative Against Transnational Organized Crime, Global Organized Crime Index. https://ocindex.net",
    file_globs=("global_oc_index*.xlsx", "*ocindex*.xlsx"),
    url="https://ocindex.net/assets/downloads/global_oc_index.xlsx",
    hosts=("ocindex.net",), max_bytes=30 * 1024 * 1024)

SHEET_YEAR = re.compile(r"(?<!\d)(20[1-3]\d)(?!\d)")


def parse(body: bytes, name: str, version: str | None = None) -> ResearchResult:
    sheets = read_excel_sheets(body, f"GOCI {name}")
    cm = CountryMapper()
    recs, used, seen = [], [], []
    for sname, df in sheets.items():
        cols = {norm_col(c): c for c in df.columns}
        seen.append(f"{sname}: {list(df.columns)[:10]}")
        if "country" not in cols or "criminal markets" not in cols:
            continue
        ycol = cols.get("year")
        m = SHEET_YEAR.search(str(sname))
        if ycol is None and not m:
            raise LayoutError(f"GOCI {name}: sheet {sname!r} has Country and Criminal markets but no Year column and "
                              f"no year in its name: refused")
        used.append(sname)
        for _, r in df.iterrows():
            v = to_float(r[cols["criminal markets"]])
            y = to_float(r[ycol]) if ycol else float(m.group(1))
            if v is None or y is None:
                continue
            iso = cm(r[cols["iso3"]] if "iso3" in cols else None, r[cols["country"]])
            if iso:
                recs.append(dict(indicator="6.7", iso3=iso, year=int(y), value=v, metric="criminal_markets",
                                 kind="indicator"))
    if not recs:
        raise LayoutError(f"GOCI {name}: no sheet with columns Country and 'Criminal markets' (layout UNVERIFIED; "
                          f"refused). Sheets: " + " | ".join(seen))
    years = sorted({r["year"] for r in recs})
    version = version or f"GOCI editions {','.join(map(str, years))}"
    vintage = vintage_of(version, body, name)
    rows = make_rows(recs, SPEC, f"Global Organized Crime Index ({version})", vintage)
    check_range(rows, "criminal_markets", 1.0, 10.0, f"GOCI {name}")
    return ResearchResult(rows, vintage, sorted(cm.unmapped), [f"sheets read: {used}"])


def load(data_dir, path=None, **kw) -> ResearchResult:
    return _load(SPEC, parse, data_dir, path, **kw)
