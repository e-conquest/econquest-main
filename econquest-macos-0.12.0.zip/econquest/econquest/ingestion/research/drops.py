"""Research file drops through the gate, offline (EQ-A-0089): what the pull pack's step 7 runs on Sam's Mac.

    python -m econquest.ingestion.research.drops check  [--data data] [--as-of YYYY-MM-DD] [--write]
    python -m econquest.ingestion.research.drops verify [--data data]

Sam downloads a research file (V-Dem, WJP, Powell-Thyne, GOCI, ND-GAIN, EPR, Aqueduct, a saved UNHCR answer) into its
drop-in folder data/panel/research/<key>/. `check` then runs the same path as `econquest fetch` (feed `research`):

1. wiring.fetch: every BUILT research.REGISTRY adapter reads its folder (local files only, never the network).
   A source with no file is skipped with the adapter's message naming the folder and how to fill it; it is never a
   failure. A file whose layout the adapter refuses is listed as refused (a layout to report, not a crash).
2. wiring.cells for every desk country: Team B's rules from econquest.rules (C15, indicator-rules sections 1-5, 13,
   19), nothing copied here. Point in time from the adapters' `published` column. World Bank Gini (6.10) from
   live/raw_worldbank.csv and UCDP events (6.1, 6.9) from the stored event vintages, when present.
3. wiring.gate_checks: every research cell is held ("unverified: research dataset ..."); 3.6, 4.4, 6.10 and 7.12 also
   carry "Sam sign-off at first values" and are listed as parked. Nothing is applied: this module writes only its
   own report under live/pullpack/research/ and never touches indicators.csv, countries.csv or a vintage.
4. Licence: each source must resolve to its row in the licence register (data/licences.csv) by its licence tag, its
   drop folder and its source text, and the three must agree. Each cell's client-output status is
   audit.client_output_reason (register first): restricted rows (WJP, Powell-Thyne, GOCI, ND-GAIN, EPR, UNHCR) are
   withheld from client output; V-Dem and Aqueduct are allowed by their register rows.

`verify` re-reads the report and re-checks it against the register and the drop files (the pack's verify and the
landing check both call it).
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import io
import json
import sys
from pathlib import Path
from types import SimpleNamespace

import pandas as pd

from . import module
from . import wiring
from .base import LayoutError, drop_folder, find_local

TICKET = "EQ-A-0089"
SCHEMA = "econquest.research_drops/1"
OUT_DIR = Path("live") / "pullpack" / "research"          # under data_dir, beside the pack's state.json
SUMMARY_FILE, CELLS_FILE = "research_drops.json", "research_cells.csv"
CELL_COLUMNS = ["key", "iso", "country", "value", "seed", "gate_status", "gate_reason", "signoff",
                "register_row", "client_output", "client_reason", "source", "licence", "series"]
# Drop folders read on the research path outside REGISTRY's built adapters: checked for a register row too.
EXTRA_FOLDERS = {"ucdp_ged": "research/ucdp_ged.py (6.1, 6.9 via events)", "cow": "research/cow_contiguity.py (6.12)"}
RUNBOOK = "docs/runbooks/A-research-datasets.md"
RELEASED = "not held by the research check"     # wiring.LAYOUT_VERIFIED (EQ-A-0126); the quality gate's other checks decide


class DropsError(ValueError):
    """The report cannot be read (missing, unreadable or another schema)."""


def out_dir(data_dir: str | Path) -> Path:
    return Path(data_dir) / OUT_DIR


def _sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def _file_sha(p: Path) -> str:
    """SEC-A-014 P4-L1: sha256 of a drop file in 1 MiB chunks (an oversized drop the adapter refuses is never read
    into memory whole); '' for a link or a missing file."""
    if p.is_symlink() or not p.is_file():
        return ""
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


# ------------------------------------------------------------------------------------------------ what is dropped

def dropped(data_dir: str | Path) -> dict:
    """{key: file name | None | 'ambiguous: ...'} for every built adapter. Reads folder listings only."""
    out = {}
    for k in wiring.loadable():
        try:
            p = find_local(data_dir, module(k).SPEC)
        except LayoutError as e:
            out[k] = f"ambiguous: {' '.join(str(e).split())[:300]}"
            continue
        out[k] = p.name if p is not None else None
    return out


def skip_reason(data_dir: str | Path) -> str | None:
    """None when at least one research file is in its drop-in folder, else the clean skip message."""
    if any(v is not None for v in dropped(data_dir).values()):
        return None
    keys = ", ".join(wiring.loadable())
    return (f"no research file dropped: put a download into {Path(data_dir) / 'panel' / 'research'}/KEY/ for any of "
            f"{keys} ({RUNBOOK}); nothing to check, nothing changed")


# ------------------------------------------------------------------------------------------------ licence register

def licence_checks(rows: pd.DataFrame | None = None, register: list[dict] | None = None) -> list[dict]:
    """One dict per built adapter: the register rows found by licence tag, drop folder and source text, whether they
    agree, the register's client_output, and the problem (empty when fine). Plus EXTRA_FOLDERS by path only."""
    from ..licences import licence_for
    out = []
    for k in wiring.loadable():
        spec = module(k).SPEC
        by_tag = licence_for(licence=spec.licence, register=register)
        by_path = licence_for(path=f"panel/research/{k}/", register=register)
        srcs = []
        if rows is not None and len(rows):
            srcs = sorted(set(rows.loc[rows["licence"] == spec.licence, "source"].astype(str)))
        by_src = [licence_for(source=s, register=register) for s in srcs]
        ids = {r["source_id"] if r else None for r in [by_tag, by_path, *by_src]}
        problem = []
        if None in ids:
            miss = [n for n, r in (("licence tag", by_tag), ("drop folder", by_path)) if r is None]
            miss += [f"source {s!r}" for s, r in zip(srcs, by_src) if r is None]
            problem.append("no register row for " + ", ".join(miss))
        if len(ids - {None}) > 1:
            problem.append(f"register rows disagree: {sorted(ids - {None})}")
        client = (by_path or by_tag or {}).get("client_output", "")
        if not spec.client_ok and client == "allowed":
            problem.append("adapter says internal only but the register allows client output")
        out.append({"key": k, "register_row": (by_path or by_tag or {}).get("source_id", ""), "client_output": client,
                    "internal_use": (by_path or by_tag or {}).get("internal_use", ""),
                    "terms_verified": (by_path or by_tag or {}).get("terms_verified", ""),
                    "adapter_client_ok": bool(spec.client_ok), "ok": not problem, "problem": "; ".join(problem)})
    for k, what in EXTRA_FOLDERS.items():
        row = licence_for(path=f"panel/research/{k}/", register=register)
        out.append({"key": k, "register_row": (row or {}).get("source_id", ""),
                    "client_output": (row or {}).get("client_output", ""),
                    "internal_use": (row or {}).get("internal_use", ""),
                    "terms_verified": (row or {}).get("terms_verified", ""), "adapter_client_ok": None,
                    "ok": row is not None, "extra": what,
                    "problem": "" if row else f"no register row matches the drop folder panel/research/{k}/"})
    return out


# ------------------------------------------------------------------------------------------------ the check

def _desk(data_dir: Path) -> list[tuple[str, str]]:
    from ..sources import read_csv_keep_na_code
    c = read_csv_keep_na_code(data_dir / "countries.csv", dtype=str)
    return list(zip(c["iso"].str.upper(), c["country"]))


def _indicators(data_dir: Path) -> pd.DataFrame | None:
    p = data_dir / "indicators.csv"
    if not p.is_file():
        return None
    df = pd.read_csv(p, dtype={"id": str, "pillar": str})
    return df.set_index("id")


def _worldbank(data_dir: Path) -> tuple[pd.DataFrame | None, str]:
    p = data_dir / "live" / "raw_worldbank.csv"
    if not p.is_file():
        return None, "none (no live/raw_worldbank.csv: 6.10 without its Gini part)"
    return pd.read_csv(p, dtype={"iso": str, "series": str}), "live/raw_worldbank.csv"


def check(data_dir: str | Path, as_of: str | None = None, *, worldbank: pd.DataFrame | None = None,
          events: pd.DataFrame | None = None, register: list[dict] | None = None) -> dict:
    """The drop check (module docstring). Returns a dict: schema, as_of, sources, licence, cells (DataFrame,
    CELL_COLUMNS), blanks, counts, parked (sign-off cells), notes. Reads only."""
    d = Path(data_dir)
    as_of = as_of or dt.date.today().isoformat()
    year = int(as_of[:4])
    rows = wiring.fetch(d)
    st, msgs = rows.attrs.get("status", {}), rows.attrs.get("messages", {})
    files = dropped(d)
    sources = {}
    for k in wiring.loadable():
        s = st.get(k, "not dropped")
        rec = {"status": "dropped" if s.startswith("ok") else ("not dropped" if s == "not dropped" else "refused"),
               "detail": s if s != "not dropped" else msgs.get(k, "no file"), "file": "", "sha256": "", "rows": 0,
               "vintage": ""}
        f = files.get(k)
        if f and not f.startswith("ambiguous"):
            rec.update(file=f, sha256=_file_sha(drop_folder(d, k) / f))
        mine = rows[rows["licence"] == module(k).SPEC.licence] if len(rows) else rows
        if rec["status"] == "dropped":
            rec.update(rows=int(len(mine)), vintage="; ".join(sorted(set(mine["vintage"].astype(str)))))
        sources[k] = rec
    if worldbank is None:
        worldbank, wb_note = _worldbank(d)
    else:
        wb_note = "given"
    if events is None:
        events = wiring.ucdp_events(d)
    ind = _indicators(d)
    from .. import audit
    from ..licences import cell_licence
    recs, blanks = [], []
    if wiring.wants_cells(rows, events, worldbank):      # the same condition as feeds.fetch_all (EQ-A-0126)
        for iso, name in _desk(d):
            got, blank = wiring.cells(rows, iso, year, worldbank, as_of=as_of, events=events)
            for k, v, src, series, lic in got:
                seed = None                      # the desk value the review compares with (batch effect for Sam)
                if ind is not None and k in ind.index and name in ind.columns:
                    seed = pd.to_numeric(ind.at[k, name], errors="coerce")
                    seed = None if pd.isna(seed) else float(seed)
                reg = cell_licence({"source": src, "licence": lic, "series": series}, register=register)
                why = audit.client_output_reason(src, lic, series)
                recs.append({"key": k, "iso": iso, "country": name, "value": v, "seed": seed,
                             "register_row": (reg or {}).get("source_id", ""),
                             "client_output": "withheld" if why else "allowed", "client_reason": why or "",
                             "source": src, "licence": lic, "series": series})
            blanks += [{"key": k, "iso": iso, "reason": r} for k, r in blank]
    cells = pd.DataFrame(recs, columns=[c for c in CELL_COLUMNS if c not in ("gate_status", "gate_reason", "signoff")])
    pairs = _gate_decisions(cells)
    cells["gate_status"] = [p[0] for p in pairs]
    cells["gate_reason"] = [p[1] for p in pairs]
    cells["signoff"] = cells["key"].isin(wiring.SIGNOFF_IDS)
    cells = cells[CELL_COLUMNS].sort_values(["key", "iso"], key=lambda s: s.astype(str)).reset_index(drop=True)
    parked = [f"{r.key} {r.country}: held for Sam's sign-off at the first gate review (indicator-rules 13); not applied"
              for r in cells[cells["signoff"]].itertuples(index=False)]
    lic = licence_checks(rows, register)
    counts = {"sources_dropped": sum(v["status"] == "dropped" for v in sources.values()),
              "sources_not_dropped": sum(v["status"] == "not dropped" for v in sources.values()),
              "sources_refused": sum(v["status"] == "refused" for v in sources.values()),
              "rows": int(len(rows)), "cells": int(len(cells)), "cells_held": int((cells["gate_status"] == "hold").sum()),
              "cells_signoff_parked": len(parked), "cells_differ_from_seed": _differ(cells),
              "cells_client_withheld": int((cells["client_output"] == "withheld").sum()),
              "cells_client_allowed": int((cells["client_output"] == "allowed").sum()), "blanks": len(blanks)}
    by_key = {str(k): int(n) for k, n in cells.groupby("key").size().items()} if len(cells) else {}
    return {"schema": SCHEMA, "ticket": TICKET, "as_of": as_of, "sources": sources, "licence": lic, "cells": cells,
            "blanks": blanks, "counts": counts, "cells_by_key": by_key, "parked": parked,
            "inputs": {"worldbank": wb_note, "ucdp_events": "stored UCDP vintages" if events is not None else "none"},
            "notes": ["every research cell is held at the gate; nothing here applies a value",
                      "3.6, 4.4, 6.10, 7.12: Sam's sign-off at the first gate review (indicator-rules 13); parked",
                      "client output: withheld cells stay out of client builds (audit.client_output_reason)"]}


def _gate_decisions(cells: pd.DataFrame) -> list[tuple[str, str]]:
    """(gate_status, gate_reason) per cell row from wiring.gate_checks, the one research gate rule: 'hold' with its
    reasons, or RELEASED when the gate leaves the cell to the quality gate's other checks (wiring.LAYOUT_VERIFIED).
    check() writes these; verify() recomputes them (ARCH-A-PI12)."""
    prov = pd.DataFrame({"table": "Inputs", "key": cells["key"], "country": cells["country"], "value": cells["value"],
                         "series": cells["series"], "licence": cells["licence"]})
    gate = wiring.gate_checks(SimpleNamespace(provenance=prov))
    g = {(str(r.key), r.country): (r.status, r.reason) for r in gate.itertuples(index=False)}
    return [g.get((str(k), c), (RELEASED, "")) for k, c in zip(cells["key"], cells["country"])]


def _differ(cells: pd.DataFrame) -> int:
    if not len(cells):
        return 0
    v, s = pd.to_numeric(cells["value"], errors="coerce"), pd.to_numeric(cells["seed"], errors="coerce")
    return int((s.isna() | ((v - s).abs() > 1e-9)).sum())


def _cells_csv(cells: pd.DataFrame) -> bytes:
    from ..ledger import _neutralise                     # SEC-A-007 I1: no formula text reaches a spreadsheet
    out = cells.copy()
    for c in ("country", "source", "licence", "series", "gate_reason", "client_reason"):
        out[c] = out[c].astype(str).map(_neutralise)
    buf = io.StringIO()
    out.to_csv(buf, index=False, lineterminator="\n")
    return buf.getvalue().encode("utf-8")


def write(result: dict, data_dir: str | Path, now: dt.datetime | None = None) -> dict:
    """Write research_cells.csv and research_drops.json under live/pullpack/research/ (only there). Returns paths and
    shas."""
    o = out_dir(data_dir)
    o.mkdir(parents=True, exist_ok=True)
    body = _cells_csv(result["cells"])
    (o / CELLS_FILE).write_bytes(body)
    summ = {k: v for k, v in result.items() if k != "cells"}
    summ["created_utc"] = (now or dt.datetime.now(dt.timezone.utc)).strftime("%Y-%m-%dT%H:%M:%SZ")
    summ["cells_file"], summ["cells_sha256"] = CELLS_FILE, _sha(body)
    text = json.dumps(summ, indent=1, sort_keys=True, default=str) + "\n"
    tmp = o / (SUMMARY_FILE + ".tmp")
    tmp.write_text(text, encoding="utf-8")
    tmp.replace(o / SUMMARY_FILE)
    return {"summary": str(o / SUMMARY_FILE), "cells": str(o / CELLS_FILE), "cells_sha256": summ["cells_sha256"],
            "summary_sha256": _sha(text.encode("utf-8"))}


def read(data_dir: str | Path) -> tuple[dict, pd.DataFrame]:
    o = out_dir(data_dir)
    try:
        summ = json.loads((o / SUMMARY_FILE).read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        raise DropsError(f"{o / SUMMARY_FILE}: {type(e).__name__}: {e}") from None
    if not isinstance(summ, dict) or summ.get("schema") != SCHEMA:
        raise DropsError(f"{o / SUMMARY_FILE}: schema is not {SCHEMA}")
    try:
        cells = pd.read_csv(o / CELLS_FILE, dtype=str, keep_default_na=False)
    except (OSError, ValueError) as e:
        raise DropsError(f"{o / CELLS_FILE}: {type(e).__name__}: {e}") from None
    return summ, cells


def _c(name: str, ok: bool, detail: str = "", required: bool = True) -> dict:
    return {"name": name, "ok": bool(ok), "detail": detail, "required": required}


def verify(data_dir: str | Path, register: list[dict] | None = None) -> list[dict]:
    """Checks (pullpack._check shape) on the written report, re-done against the register and the drop files."""
    d = Path(data_dir)
    try:
        summ, cells = read(d)
    except DropsError as e:
        return [_c("research drop report readable", False, str(e)[:300])]
    checks = [_c("research drop report readable", True, f"{len(cells)} cells, as of {summ.get('as_of')}")]
    sha = _sha((out_dir(d) / CELLS_FILE).read_bytes())
    checks.append(_c("research_cells.csv at the report's sha256", sha == summ.get("cells_sha256"), sha[:16]))
    # EQ-A-0126 / ARCH-A-PI12: the gate decision is recomputed with wiring.gate_checks itself (one rule, no copy), so a
    # cell may read RELEASED only where the gate releases it today (layout verified, no Team B rule hold, no sign-off)
    want = [s for s, _ in _gate_decisions(cells)]
    held = pd.Series([str(s) == w for s, w in zip(cells["gate_status"], want)], index=cells.index, dtype=bool)
    checks.append(_c("every research cell held at the gate", bool(held.all()),
                     f"{int(held.sum())} of {len(cells)} held" + ("" if held.all() else ": " + ", ".join(
                         f"{r.key} {r.iso}" for r in cells[~held].head(10).itertuples(index=False)))))
    so = cells[cells["key"].isin(wiring.SIGNOFF_IDS)]
    so_ok = so["gate_reason"].str.contains(wiring.SIGNOFF_REASON, regex=False) & so["gate_status"].eq("hold")
    checks.append(_c("3.6, 4.4, 6.10, 7.12 held for Sam's sign-off (parked, not applied)", bool(so_ok.all()),
                     f"{len(so)} cells"))
    from .. import audit
    leak = [f"{r.key} {r.iso}" for r in cells.itertuples(index=False)
            if r.client_output == "allowed" and audit.client_output_reason(r.source, r.licence, r.series)]
    checks.append(_c("no restricted research value marked for client output (register, recomputed)", not leak,
                     ", ".join(leak[:10]) or f"{int((cells['client_output'] == 'withheld').sum())} withheld"))
    lic = {r["key"]: r for r in licence_checks(register=register)}
    src = summ.get("sources") or {}
    bad = [f"{k}: {lic[k]['problem']}" for k, v in src.items()
           if v.get("status") == "dropped" and (k not in lic or not lic[k]["ok"])]
    checks.append(_c("every dropped source has its licence register row", not bad, "; ".join(bad) or
                     ", ".join(f"{k} -> {lic[k]['register_row']} ({lic[k]['client_output']})"
                               for k, v in src.items() if v.get("status") == "dropped") or "none dropped"))
    moved, gone = [], []
    for k, v in src.items():
        if not v.get("file"):
            continue
        p = drop_folder(d, k) / v["file"]
        if not p.is_file():
            gone.append(f"{k}/{v['file']}")
        elif _file_sha(p) != v.get("sha256"):
            moved.append(f"{k}/{v['file']}")
    checks.append(_c("drop files unchanged since the check (sha256)", not moved, ", ".join(moved) or "unchanged"))
    if gone:
        checks.append(_c("drop files present", False, "not here (not uploaded): " + ", ".join(gone), required=False))
    refused = [f"{k}: {v.get('detail', '')[:200]}" for k, v in src.items() if v.get("status") == "refused"]
    checks.append(_c("no dropped file refused by its adapter", not refused, "; ".join(refused) or "none",
                     required=False))
    extra = [r for r in lic.values() if r.get("extra") and not r["ok"]]
    checks.append(_c("register rows for the other research drop folders (ucdp_ged, cow)", not extra,
                     "; ".join(r["problem"] for r in extra) or "present", required=False))
    return checks


# ------------------------------------------------------------------------------------------------ CLI

def summary_lines(res: dict) -> list[str]:
    out = []
    for k, v in res["sources"].items():
        out.append(f"{k:9s} {v['status']}: " + (f"{v['rows']} rows, {v['vintage']}" if v["status"] == "dropped"
                                                 else v["detail"]))
    c = res["counts"]
    out.append(f"cells {c['cells']} (held {c['cells_held']}, Sam sign-off parked {c['cells_signoff_parked']}, differ "
               f"from the desk value {c['cells_differ_from_seed']}; client withheld {c['cells_client_withheld']}, allowed "
               f"{c['cells_client_allowed']}); nothing applied")
    for r in res["licence"]:
        if not r["ok"]:
            out.append(f"licence register: {r['key']}: {r['problem']}")
    return out


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.research.drops",
                                 description="research file drops through Team B's rules and the gate (offline)")
    ap.add_argument("cmd", choices=("check", "verify"))
    ap.add_argument("--data", default="data")
    ap.add_argument("--as-of", default=None)
    ap.add_argument("--write", action="store_true", help="write the report under live/pullpack/research/")
    a = ap.parse_args(argv)
    if a.cmd == "verify":
        checks = verify(a.data)
        for c in checks:
            print(f"[{'ok' if c['ok'] else ('FAIL' if c['required'] else 'note')}] {c['name']}: {c['detail']}")
        return 0 if all(c["ok"] for c in checks if c["required"]) else 1
    why = skip_reason(a.data)
    if why:
        print(f"skipped: {why}")
        return 0
    res = check(a.data, a.as_of)
    print("\n".join(summary_lines(res)))
    if a.write:
        print(f"written: {write(res, a.data)['summary']}")
    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
