"""ND-GAIN Country Index -> 7.11 Climate vulnerability (vulnerability score 0-1). EQ-A-0067.

Source (read 2026-10-25): https://gain.nd.edu/our-work/country-index/download-data/ links
https://gain.nd.edu/assets/647440/ndgain_countryindex_2026.zip, "No registration" (an optional questionnaire), updated
annually, "separate CSV files in a single compressed file". No licence or terms-of-use text; only "Copyright (c) 2026
University of Notre Dame". Suggested citation: "Notre Dame Global Adaptation Initiative Country Index (ND-GAIN).
(Current Year). University of Notre Dame." Licence UNVERIFIED -> internal research use only.

Layout UNVERIFIED (zip not opened here): the zip member ending "vulnerability/vulnerability.csv" (or a lone
vulnerability.csv dropped by hand), wide: ISO3, Name, then one column per year (e.g. 1995 .. 2024). Values 0-1 (higher =
more vulnerable, same direction as the indicator). No transform.
"""
from __future__ import annotations

import re

from .base import (CountryMapper, DatasetSpec, LayoutError, ResearchResult, check_range, load as _load, make_rows,
                   read_csv_bytes, require_columns, to_float, vintage_of, zip_member)

SPEC = DatasetSpec(
    key="ndgain", name="ND-GAIN Country Index", indicators=("7.11",),
    licence="internal research use only: ND-GAIN Country Index, licence UNVERIFIED (no terms stated; (c) University of Notre Dame)",
    client_ok=False, fetch_mode="direct",
    terms_url="https://gain.nd.edu/our-work/country-index/download-data/",
    attribution="Notre Dame Global Adaptation Initiative Country Index (ND-GAIN). (2026). University of Notre Dame.",
    file_globs=("ndgain_countryindex_*.zip", "vulnerability.csv"),
    url="https://gain.nd.edu/assets/647440/ndgain_countryindex_2026.zip",
    hosts=("gain.nd.edu",), max_bytes=50 * 1024 * 1024)

YEAR_COL = re.compile(r"^(19|20)\d{2}$")
RELEASE_RE = re.compile(r"countryindex_(\d{4})")


def parse(body: bytes, name: str, version: str | None = None) -> ResearchResult:
    raw = body
    member = name
    if name.lower().endswith(".zip"):
        member, body = zip_member(body, ("vulnerability/vulnerability.csv",))
    df = read_csv_bytes(body, f"ND-GAIN {member}")
    c = require_columns(df, ["ISO3", "Name"], f"ND-GAIN {member}")
    ycols = [col for col in df.columns if YEAR_COL.fullmatch(str(col).strip())]
    if not ycols:
        raise LayoutError(f"ND-GAIN {member}: no year columns; found {list(df.columns)[:12]}")
    cm = CountryMapper()
    recs = []
    for _, r in df.iterrows():
        iso = cm(r[c["iso3"]], r[c["name"]])
        if iso is None:
            continue
        for col in ycols:
            v = to_float(r[col])
            if v is not None:
                recs.append(dict(indicator="7.11", iso3=iso, year=int(str(col).strip()), value=v,
                                 metric="vulnerability", kind="indicator"))
    m = RELEASE_RE.search(name)
    version = version or (f"ND-GAIN {m.group(1)} release" if m else "ND-GAIN release unknown")
    vintage = vintage_of(version, raw, name)
    rows = make_rows(recs, SPEC, f"ND-GAIN Country Index ({version})", vintage)
    check_range(rows, "vulnerability", 0.0, 1.0, f"ND-GAIN {member}")
    return ResearchResult(rows, vintage, sorted(cm.unmapped), [f"member read: {member}"])


def load(data_dir, path=None, **kw) -> ResearchResult:
    return _load(SPEC, parse, data_dir, path, **kw)
