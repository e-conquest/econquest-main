"""ETH Ethnic Power Relations (EPR Core) -> 6.10 Inequality and excluded groups (input). EQ-A-0067.

Source (read 2026-10-25): https://icr.ethz.ch/data/epr/ cites "the latest version (2021, released on June 8, 2021)",
coverage 1946-2021, direct CSV https://icr.ethz.ch/data/epr/core/EPR-2021.csv (UTF-8), no registration mentioned.
Citation requested: Vogt, Bormann, Ruegger, Cederman, Hunziker and Girardin (2015), "Integrating Data on Ethnicity,
Geography, and Conflict: The Ethnic Power Relations Data Set Family", Journal of Conflict Resolution 59(7): 1327-42.
No licence or terms of use on the page. Licence UNVERIFIED -> internal research use only.

Layout (EPR Core codebook names; file not opened here, UNVERIFIED): gwid, statename, from, to, group, groupid,
gwgroupid, umbrella, size, status, reg_aut. One row per group and spell [from, to]; size is the group's share of the
country population (0-1).

Output (input; the 0-4 level combining Gini and exclusion is Team B's rule): for each country and year, the summed
size of groups whose status is POWERLESS, DISCRIMINATED or SELF-EXCLUSION (the codebook's "excluded" categories), as a
fraction 0-1 (never a percent: Team B, indicator-rules 13.4). EQ-A-0095 (13.4):
  * discriminated_pop_share: the summed size of DISCRIMINATED groups (0-1), for every country-year that gets an
    excluded share (0.0 when none is discriminated), for section 3's level 3 test;
  * a country-year whose groups are ALL IRRELEVANT gets 0.0 for both shares ("no politically relevant groups" is
    level 0, section 3), not a skipped row;
  * a country-year with any STATE COLLAPSE group stays skipped (blank).
Unknown status values are refused.
"""
from __future__ import annotations

from .base import (CountryMapper, DatasetSpec, LayoutError, ResearchResult, check_range, load as _load, make_rows,
                   read_csv_bytes, require_columns, to_float, vintage_of)

SPEC = DatasetSpec(
    key="epr", name="Ethnic Power Relations (EPR Core)", indicators=("6.10",),
    licence="internal research use only: ETH Zurich EPR Core, licence UNVERIFIED (no terms stated; cite Vogt et al. 2015)",
    client_ok=False, fetch_mode="direct",
    terms_url="https://icr.ethz.ch/data/epr/",
    attribution=("Vogt, Manuel, Nils-Christian Bormann, Seraina Ruegger, Lars-Erik Cederman, Philipp Hunziker, and Luc "
                 "Girardin (2015). Integrating Data on Ethnicity, Geography, and Conflict: The Ethnic Power Relations "
                 "Data Set Family. Journal of Conflict Resolution 59(7): 1327-42."),
    file_globs=("EPR-*.csv",),
    url="https://icr.ethz.ch/data/epr/core/EPR-2021.csv",
    hosts=("icr.ethz.ch",), max_bytes=10 * 1024 * 1024)

COLS = ["gwid", "statename", "from", "to", "group", "size", "status"]
EXCLUDED = {"POWERLESS", "DISCRIMINATED", "SELF-EXCLUSION"}
INCLUDED = {"MONOPOLY", "DOMINANT", "SENIOR PARTNER", "JUNIOR PARTNER"}
UNDEFINED = {"IRRELEVANT", "STATE COLLAPSE"}


def parse(body: bytes, name: str, version: str | None = None) -> ResearchResult:
    df = read_csv_bytes(body, f"EPR {name}")
    c = require_columns(df, COLS, f"EPR {name}")
    cm = CountryMapper()
    share: dict = {}
    disc: dict = {}
    relevant: set = set()
    irrelevant: set = set()
    collapse: set = set()
    last = 0
    for _, r in df.iterrows():
        st = str(r[c["status"]]).strip().upper()
        if st not in EXCLUDED | INCLUDED | UNDEFINED:
            raise LayoutError(f"EPR {name}: status {st!r} not in the codebook list: refused")
        a, b, s = to_float(r[c["from"]]), to_float(r[c["to"]]), to_float(r[c["size"]])
        if a is None or b is None or b < a:
            raise LayoutError(f"EPR {name}: bad spell from={r[c['from']]!r} to={r[c['to']]!r}")
        last = max(last, int(b))
        iso = cm(None, r[c["statename"]])
        if iso is None:
            continue
        for y in range(int(a), int(b) + 1):
            if st in UNDEFINED:
                (collapse if st == "STATE COLLAPSE" else irrelevant).add((iso, y))
                continue
            if s is None:
                raise LayoutError(f"EPR {name}: politically relevant group without size ({r[c['group']]!r})")
            relevant.add((iso, y))
            if st in EXCLUDED:
                share[(iso, y)] = share.get((iso, y), 0.0) + s
            if st == "DISCRIMINATED":
                disc[(iso, y)] = disc.get((iso, y), 0.0) + s
    keep = sorted((relevant | irrelevant) - collapse)           # all-IRRELEVANT years -> 0.0; collapse years blank
    recs = []
    for (iso, y) in keep:
        recs.append(dict(indicator="6.10", iso3=iso, year=y, value=share.get((iso, y), 0.0),
                         metric="excluded_pop_share", kind="input"))
        recs.append(dict(indicator="6.10", iso3=iso, year=y, value=disc.get((iso, y), 0.0),
                         metric="discriminated_pop_share", kind="input"))
    version = version or f"EPR Core (spells to {last})"
    vintage = vintage_of(version, body, name)
    rows = make_rows(recs, SPEC, f"Ethnic Power Relations ({version})", vintage)
    check_range(rows, "excluded_pop_share", 0.0, 1.0 + 1e-6, f"EPR {name}")
    check_range(rows, "discriminated_pop_share", 0.0, 1.0 + 1e-6, f"EPR {name}")
    n0 = len((irrelevant - relevant) - collapse)
    return ResearchResult(rows, vintage, sorted(cm.unmapped),
                          ["input only: fractions 0-1; level mapping with Gini is Team B's rule (13.4 interim)",
                           f"{n0} all-IRRELEVANT country-years written as 0.0; STATE COLLAPSE years left blank"])


def load(data_dir, path=None, **kw) -> ResearchResult:
    return _load(SPEC, parse, data_dir, path, **kw)
