"""Data Ingestion Tier (paper Appendix B.3).

In production this tier is a set of asynchronous microservices feeding a message bus (Kafka /
Redpanda) from IMF, World Bank, ACLED, GDELT, CDS term structures and prediction-market order
books. Here the same contract is met by `Source` objects that each return tidy tables, plus an
ETL step (`load_universe`) that assembles them into a `Universe`. Swapping the snapshot sources
for live ones changes nothing downstream."""
from .loaders import Universe, load_universe  # noqa: F401
from .sources import CsvSource, JsonSource, PolymarketSource, KalshiSource, GoogleSheetsSource  # noqa: F401
from .feeds import (  # noqa: F401
    FeedError, FetchReport, WeoFeed, WorldBankFeed, BisFeed, EcbExrFeed, YahooFeed,
    official_fx_plan, official_fx_transforms, ecb_per_usd, fx3m, fx_usd_series,
    fetch_all, diff_against_seed, save_report, apply_report, quality_gate, save_vintage,
    list_vintages, vintage_path, verify_vintage,
    latest_vintage, load_vintage, vintage_review, record_vintage_decisions, apply_vintage, VintageContentError,
)
from .ledger import (  # noqa: F401
    record_decision, load_decisions, read_ledger, write_review, effective_holds, ledger_path,
)
from .replay import (  # noqa: F401
    freeze_inputs, materialize_vintage, snapshot_path, verify_snapshot, VintageIntegrityError,
)
from .market_history import parse_sheet_values, update_prices_from_sheet_json  # noqa: F401
