"""Data limitations register (GOV-010): build the Markdown register from the data folder, read-only (EQ-A-0044).

Moved from the EQ-A-0042 staging script build_register.py into the package. The output format is unchanged: the
hand-written narrative header (title, which data, summary, top 5, what not to rely on), the two generated register
tables (Inputs indicators, Country Profile fields) and the hand-written footer (column notes, cross-cutting
limitations X1..X16, how to refresh).

    build_register(data_dir, out_path, as_of=None) -> dict      # writes out_path, returns the computed totals
    python -m econquest.ingestion.limitations --data data --out /tmp/data-limitations.md [--as-of 2026-10-23]

HEADER, FOOTER, ISSUES and SEV_OVERRIDE are hand-written (AGENT-02, 2026-10-24, from the 2026-10-23 pull). They are
NOT recomputed: re-check them by hand against the generated tables, team/board/A.csv and team/logs/A.jsonl on every
refresh, and edit them here. Only the two tables are generated.

Reads only (nothing in data_dir is written, nothing is fetched):
  data_dir/indicators.csv, countries.csv, rulebook.csv, audit_trail.csv
  the live tables: live_inputs.csv, live_profile.csv, review.csv, raw_worldbank.csv, raw_bis.csv and, when present,
  raw_yahoo.csv (optional: Yahoo was removed by EQ-A-0040), raw_bis_xru.csv, unserved.csv, feed_failures.csv,
  missing_cells.csv. They come from data_dir/live, or, with as_of, from the newest pull at or before the end of that
  day: data_dir/live when its feeds.json `retrieved` is not after the cutoff, else the newest live vintage
  (data/live/vintages/<id>/) whose id time is not after it; ValueError when there is none.
With as_of, audit_trail.csv rows retrieved after the cutoff are dropped (rows with no retrieved date are kept, as in
the data room). indicators.csv, countries.csv and rulebook.csv are undated working copies and are read as they are.
The output is deterministic for the same inputs (no build time, no file times in the Markdown)."""
from __future__ import annotations

import argparse
import io
import json
import sys
from pathlib import Path

import pandas as pd

from .feeds import (BIS_SOURCE_SERIES, BIS_STALE_SERIES, NO_OFFICIAL_SOURCE, WB_SOURCE_SERIES, WB_STALE_SERIES,
                    WEO_SOURCE_SERIES, XRU_SERIES_SUFFIX)

N = 18          # desk countries the register was written for (coverage and seed share are "of 18")

# ---- source maps: from econquest/ingestion/feeds.py, so they cannot drift from the feeds
WEO = dict(WEO_SOURCE_SERIES)
WB = dict(WB_SOURCE_SERIES)
BIS = {**BIS_SOURCE_SERIES, "policy": "WS_CBPOL D"}
YAHOO = {"fx3m": "yfinance <CCY>=X daily close, 91-day change", "equity_vol": "yfinance country ETF, 60-day realised vol"}
DSA = {"1.1": "econquest dsa: WEO interest (GGXONLB-GGXCNL) + debt/avg maturity, % of GGR_NGDP, t+1 (avg maturity from data/dsa_inputs.csv)",
       "1.2": "econquest dsa: World Bank IDS DT.TDS.DPPG.CD next two projection years / FI.RES.TOTL.CD",
       "2.1": "econquest dsa: usable reserves / IMF ARA metric (inputs from data/dsa_inputs.csv)"}
WB_RAW = dict(WB_STALE_SERIES)
BIS_RAW = dict(BIS_STALE_SERIES)
OFFICIAL_FX = "BIS WS_XRU daily reference rates (ECB EXR fallback and cross-check), 91-day change (EQ-A-0040)"

# ---- engine use: copied from econquest/scorecard/readiness.py (EQ-B-0045); tests/test_limitations.py checks they agree
REQ_IND = {"1.3", "1.4", "1.5", "1.6", "1.7", "2.1", "2.7", "2.8", "2.9", "2.11", "4.10", "5.5", "5.6", "5.12", "6.1", "7.2"}
REQ_PROF = {"iso", "region", "fxregime", "rating", "spread", "fx3m", "res3m", "textz", "pop", "exports", "reserves", "exptype", "commgap", "parallel"}
REQ_FLAGS = {"default", "extarrears", "exprop", "coup", "nopay", "bankcrisis", "emergency", "disaster"}
ADV_PROF = {"elmonths", "gpr_series", "gpr_analyst_410", "etf", "currency"}
POS_PROF = {"stress_depreciation"}
STATIC = {"iso", "iso2", "currency", "region", "tier", "gpr_series", "mainexp"}

# ---- HAND-WRITTEN: verified known issues per key (AGENT-02, 2026-10-24). Re-check by hand on every refresh.
ISSUES = {
    "1.1": "DSA-derived from Claude-estimated avg maturity (data/dsa_inputs.csv source column). Every gate hold is open (no decision in review.csv), incl. Singapore 2 -> 140 (+6906%) and China 12 -> 62.4.",
    "1.2": "DSA-derived; IDS projections. Every gate hold is open (e.g. Senegal 80 -> 248, Zimbabwe 150 -> 364).",
    "2.1": "DSA-derived from Claude-estimated ARA inputs (data/dsa_inputs.csv). Every gate hold is open. Engine-required (stress path).",
    "1.8": "Default history from data/panel/sovereign_defaults.csv, which is memory-compiled (data/panel/README.md line 1) until the BoC-BoE/CRAG import (EQ-A-0008/0016 Blocked on Sam's Mac).",
    "2.9": "Dead series: World Bank returned no row for any of the 18 (review.csv: 18 missing). Code now asks WDI then IDS (EQ-A-0027) but no pull since. Engine-required (layer 1, Merton DD).",
    "3.4": "No WGI row in this folder's raw_worldbank.csv. Before EQ-A-0036 (Done, in 0.1.5 code) Sam's 0.1.4 fetch read GOV_WGI_*.SC 0-100 scores as percentile ranks (wrong scale). The all-economy cross-section rank is unverified on a live pull.",
    "3.5": "As 3.4: wrong scale before EQ-A-0036; cross-section rank (WGI_XS_MIN 100 economies) unverified live; 0/18 live here.",
    "6.2": "8 cells accepted on review although the gate flagged them stale (latest period Vietnam 2011, Senegal 2015, Zambia 2015, China 2020, India/Belize/Venezuela/Zimbabwe 2022).",
    "5.10": "Singapore accepted on review with latest period 2019 (gate flagged stale).",
    "5.13": "BIS policy rate for Argentina last observation 2025-07-10 (raw_bis.csv); no staleness check on BIS series (WB_STALE_SERIES covers World Bank only). 10 countries missing.",
    "policy": "Same stale Argentina rate (2025-07-10). BIS has no policy rate for 10 of 18; countries.csv blank for 2.",
    "2.12": "BIS REER missing for 8 of 18.",
    "5.9": "BIS credit gap missing for 9 of 18.",
    "exports": "Nigeria World Bank latest period 1960 (hold kept, seed used). 1 hold.",
    "reserves": "Venezuela World Bank reserves latest period 2017 (hold kept, seed used).",
    "fx3m": "Sole feed is Yahoo, being removed (Sam 2026-10-23, EQ-A-0040 In Progress: BIS XRU / ECB EXR replacement). Zimbabwe unquoted (NO_FX_QUOTE ZWL). Layer 2/3 required.",
    "equity_vol": "Yahoo-only, 10/18 with an ETF; not written to countries.csv (PROFILE_APPLY_KEYS excludes it). No official free substitute (EQ-A-0040 scope). Not a countries.csv column.",
    "spread": "Hand-entered; no licensed CDS or EMBI feed (docs/runbooks/A-market-data.md); data/cds_quotes.csv is header-only; vendor framework off (EQ-A-0033).",
    "rating": "Hand-entered; no vintage for the rating table (docs/governance/model-inventory.md).",
    "textz": "Constant 0.0 for all 18 (no text signal); ACLED off, UCDP/GDELT not pulled.",
    "prior": "Blank for all 18 (signals.py reads it when present).",
    "commgap": "Hand-entered; 60 for Senegal and Zimbabwe under review (GOV-008, docs/governance/issues-log.md).",
    "etf": "Blank for 8 of 18. ETF prices come from Yahoo (being removed) and the workbook GOOGLEFINANCE Market History tab (market_history.py).",
    "gpr_series": "Blank for 7 of 18.",
    "4.1": "Planned ACLED (off pending licence) or GDELT (no vintage yet). Candidates only; level stays analyst-set (events/indicators.py).",
    "6.4": "ACLED only (off pending licence); UCDP/GDELT cannot support it (events/indicators.py).",
    "6.9": "Planned ACLED (off) else UCDP proxy (no vintage yet).",
    "6.1": "Planned UCDP GED (no vintage in this folder: data/live/events absent).",
    "6.12": "Planned UCDP + UNHCR (no vintage).",
    "7.9": "Planned ACLED (off pending licence) + SPEI.",
    "7.3": "Planned EM-DAT is licensed (rulebook api).",
    "4.10": "Analyst level plus GPR uplift (data/gpr_monthly.csv); engine-required.",
}
SEV_OVERRIDE = {"2.9": "high", "3.4": "high", "3.5": "high", "2.1": "high", "fx3m": "high", "spread": "high", "1.8": "high",
                "exports": "high", "reserves": "high", "1.1": "medium", "1.2": "medium", "6.2": "medium", "5.13": "medium",
                "policy": "medium", "equity_vol": "medium", "textz": "medium", "prior": "low", "commgap": "high",
                "exptype": "medium", "fxregime": "medium"}
UNITS = {"pop": "million", "exports": "% of GDP", "reserves": "% of GDP", "fx3m": "% change vs USD, 3m (+ = weaker)", "policy": "% p.a.",
         "spread": "bp", "res3m": "% change, 3m", "commgap": "% vs average", "parallel": "% premium", "elmonths": "months",
         "stress_depreciation": "%", "textz": "z-score", "gpr_analyst_410": "level 0-4", "equity_vol": "% annualised"}
COLS = ["id", "name", "unit", "use", "source", "coverage", "seed", "gate", "latest", "issues", "severity", "owner"]
HDR = ["id", "name", "unit", "engine use", "source", "coverage (live vs 18)", "seed share", "gate holds (review.csv)",
       "latest period / staleness", "known issues", "severity", "owner"]
LIVE_FILES = ("live_inputs.csv", "live_profile.csv", "review.csv", "raw_worldbank.csv", "raw_bis.csv")
OPTIONAL_FILES = ("raw_yahoo.csv", "raw_bis_xru.csv", "unserved.csv", "feed_failures.csv", "missing_cells.csv")

# ---- HAND-WRITTEN narrative (AGENT-02, EQ-A-0042, 2026-10-24, describing the 2026-10-23 pull). Kept verbatim from
# staging/EQ-A-0042/data-limitations.md (How to refresh updated for this module). NOT regenerated: re-check by hand.
HEADER = """# Data limitations register (GOV-010)

Ticket EQ-A-0042, Team A, AGENT-02. Written 2026-10-24 for the independent validator. Read-only audit: no source,
test or data file was changed to produce it.

**Which data this describes.** The econquest folder as uploaded to the cloud, which may be older than Sam's Mac.
File modification times used (UTC): `data/live/feeds.json`, `raw_worldbank.csv`, `live_profile.csv` 2026-10-23 04:31
(the only vintage here is `data/live/vintages/2026-10-23/`); `data/live/live_inputs.csv` 09:03; `data/live/review.csv`
and `data/indicators.csv` 12:20; `data/audit_trail.csv` 17:14; `data/countries.csv` 21:13; `data/rulebook.csv`
2026-10-20 02:43. Evidence that the Mac is ahead: EQ-A-0036 (team/board/A.csv line 37) describes WGI rows from
"Sam's 0.1.4 fetch", but this folder's `raw_worldbank.csv` holds no WGI row at all; and the pull here predates the
feed changes of EQ-A-0027 (19:14Z) and EQ-A-0036 (22:03Z) in team/logs/A.jsonl. `data/live/unserved.csv`,
`feed_failures.csv` and `missing_cells.csv` do not exist in this folder (that pull predates the code that writes
them), so "missing" below comes from `review.csv` status `missing`.

## Summary

**Rows: 124** (83 Inputs indicators from `data/indicators.csv`; 40 Country Profile columns from `data/countries.csv`
plus `equity_vol`, which the feed computes but never writes to countries.csv).

| Severity | Inputs | Country Profile | Total |
|---|---|---|---|
| high | 12 | 8 | **20** |
| medium | 70 | 25 | **95** |
| low | 1 | 8 | **9** |

Severity rule (applied by `build_register.py`, then the overrides named in the table): **high** when the engine
requires the field (`econquest/scorecard/readiness.py` REQUIRED_PROFILE / REQUIRED_INDICATORS) and half or more of
the 18 values are seed estimates or a gate hold is undecided, or when a specific defect is known (2.9, 3.4, 3.5, 1.8,
fx3m, spread, exports, reserves, commgap); **medium** for scored or required fields mostly on seed or with values the
gate flagged; **low** for identifiers and static text, and for fields that are live, fresh and unflagged.

Sources of the 83 indicators: 8 IMF WEO, 7 World Bank, 3 BIS, 3 computed by `econquest dsa`, 35 manual, 27
planned_api (rulebook `api` column names an API nobody has built). Of the Country Profile, 3 fields come from the
World Bank, 1 from BIS, 2 from Yahoo; the other 35 are hand-entered.

**Top 5 limitations**

1. **Most Inputs cells are seed estimates.** `data/audit_trail.csv`: 245 of 1,494 Inputs cells (16.4%) are
   `live feed`; 1,249 (83.6%) are seed (1,125 seed estimate, 100 feed returned no value, 24 held by the gate).
   `data/live/live_inputs.csv` has 224 of 1,494 cells (15.0%) filled by a feed. The acceptance target is 60% of
   **feed-eligible** cells (Sam 2026-10-24 12:41Z, EQ-A-0055): only the 50 indicators per country whose
   `candidate_source` in `data/panel/coverage_source_map.csv` is not `manual-only` count, so the target is 30 of 50
   cells per country. On that measure 224 of 900 cells (24.9%) are live and 0 of 18 countries meet it (best 15 of 50:
   China, India, Brazil, Argentina, Colombia; lowest Senegal 4 of 50). All 224 live cells are feed-eligible.
   (`python -m econquest.ingestion.universe missing --data data`; target first set in
   docs/runbooks/A-universe-expansion.md line 4; EQ-A-0026 Blocked.)
2. **Engine-required inputs with no live value**: 2.9 (0/18; World Bank returned nothing), 1.4, 1.5, 2.7, 2.11,
   4.10, 6.1, 7.2 (all 18/18 seed), plus `spread`, `rating`, `res3m`, `parallel`, `commgap` (hand-entered).
3. **Market data**: no licensed CDS or EMBI source (docs/runbooks/A-market-data.md line 10-13);
   `data/cds_quotes.csv` is header-only; the Bloomberg/LSEG framework is off and untested against a terminal
   (EQ-A-0033, docs/runbooks/A-licensed-vendors.md); `fx3m` and `equity_vol` come only from Yahoo, which Sam
   ordered removed (EQ-A-0040, In Progress).
4. **Default history is memory-compiled**: `data/panel/sovereign_defaults.csv` line 1 says "compiled by Claude on
   2026-10-23 from memory"; the BoC-BoE/CRAG import (EQ-A-0008, EQ-A-0016) is Blocked on Sam's Mac. The
   point-in-time WEO panel can start only in 2007 (docs/runbooks/A-full-panel-fetch.md lines 111, 176).
5. **Review state is unfinished and partly unattested**: 24 gate holds on DSA cells (1.1, 1.2, 2.1) have no
   decision; 72 cells the gate flagged were accepted as `ok` on review (stale World Bank periods back to 2011
   included); 396 hand-entered cells (adjustments 378, prediction_markets 18) are `UNATTESTED` in the audit trail,
   and no `data/live/review_ledger.csv` exists in this folder to attest them.

**What the validator should not rely on**

- Any score, PD or limit that uses a high-severity row below as if it were observed data.
- WGI indicators 3.4 and 3.5 from any pull before EQ-A-0036, and the post-fix cross-section rank until a live pull
  shows the all-economy call returned at least `WGI_XS_MIN` (100) economies.
- The layer 1 hazard fit's default labels (memory-compiled panel) and any point-in-time claim for years before 2007.
- `fx3m`, `equity_vol` and ETF price history as licensed or official data (Yahoo / GOOGLEFINANCE).
- Event-based indicators (4.1, 6.1, 6.4, 6.9, 6.12, 7.9): no ACLED, UCDP or GDELT vintage exists here.
- Any number for the 70 approved new sovereigns: `data/countries.csv` still has the 18 `desk_current` rows.
- The headline "14% live" figure as a measured number from this folder (see the cross-cutting table).

> Hand-written narrative: everything above, the column notes and the cross-cutting table below were written for
> the 2026-10-24 register (EQ-A-0042) from the 2026-10-23 pull and are not regenerated. Only the two Register
> tables are computed (`econquest.ingestion.limitations`); re-check the narrative by hand against them.

"""
FOOTER = """
Column notes. *coverage*: "feed" = countries with a finite value in `data/live/live_inputs.csv` / `live_profile.csv`;
"applied" = rows with origin `live feed` in `data/audit_trail.csv`. *seed share* = audit-trail rows whose origin
starts with `seed`; Country Profile fields the audit trail does not track are marked manual, untracked. *gate holds*
= `review.csv` status `hold` (open = no decision), "flagged then accepted" = status `ok` with a gate reason
(the reviewer accepted it), "missing" = status `missing`. *source* for feed rows is copied from
`econquest/ingestion/feeds.py` WEO_SOURCE_SERIES / WB_SOURCE_SERIES / BIS_SOURCE_SERIES; for other rows it is the
rulebook `api` column. *engine use* is from `econquest/scorecard/readiness.py`.

## Cross-cutting limitations (each checked in the code, data or logs)

| # | Limitation | Status verified | Evidence | Severity | Owner |
|---|---|---|---|---|---|
| X1 | WGI 3.4/3.5 on the wrong scale before the fix: GOV_WGI_*.SC are 0-100 scores, not percentile ranks | Verified. Fixed in code by EQ-A-0036 (Done 2026-10-23 22:03Z; package `__version__` is 0.1.5). The 0.1.5 release note does not list it. The all-economy cross-section rank has never run on a live pull: no WGI row in this folder | `feeds.py` lines 327-333 and `wgi_percentile_rank`; team/board/A.csv line 37; team/logs/A.jsonl line 221; `econquest/__init__.py` line 16 | high | A/AGENT-06 |
| X2 | Nigeria exports World Bank latest period 1960; Venezuela reserves stop in 2017 | Verified. Both held, seed kept | `review.csv` rows exports/Nigeria and reserves/Venezuela; `raw_worldbank.csv` NE.EXP.GNFS.ZS NGA max period 1960, FI.RES.TOTL.CD VEN 2017; docs/validation/data-pipeline.md lines 198-199 | high | A/AGENT-06 |
| X3 | Point-in-time panel starts in 2007 | Verified: WEO releases are available from October 2007, so earlier rows cannot be point in time unless Team B sets a pre-2007 rule (HO-20261023-A-B-007). World Bank features are never point in time | docs/runbooks/A-full-panel-fetch.md lines 106-111, 176-181; team/logs/A.jsonl line 121 | high | A/AGENT-06; rule B/AGENT-05 |
| X4 | Default panel memory-compiled until the BoC-BoE import | Verified. EQ-A-0008 and EQ-A-0016 Blocked; the cloud proxy refuses bankofcanada.ca | `data/panel/README.md` lines 1, 5; team/board/A.csv lines 9, 17; team/logs/A.jsonl lines 37, 121 | high | A/AGENT-06 (Sam to run on Mac) |
| X5 | ACLED off pending a licence; UCDP and GDELT pending first pulls | Verified. ACLED refuses unless `enabled` is JSON true and a licence string is set; default `{"enabled": false, "licence": "none"}`. No `data/live/events/` folder exists, so no event vintage | `events/acled.py` lines 1-11, 78-88; docs/runbooks/A-event-feeds.md; `events/indicators.py` docstring | medium | A/AGENT-06; licence Sam |
| X6 | Yahoo being removed; equity ETF prices/vol have no official free substitute | Verified on the board: EQ-A-0040 In Progress (team/board/A.csv line 41: "Sam 2026-10-23: replace with free official sources ... flag series with no official substitute (equity ETF prices/vols)"). team/logs/A.jsonl has no EQ-A-0040 entry yet, so its progress could not be read from the log. Yahoo today feeds `fx3m` (17/18) and `equity_vol` (10/18); ETF prices in `data/market_history/prices.csv` come from the workbook's GOOGLEFINANCE tab | `feeds.py` YahooFeed, `yahoo_transforms`; `ingestion/market_history.py` docstring | high | A/AGENT-06 |
| X7 | No licensed CDS; vendor framework off; manual quotes need attestation | Verified. `data/cds_quotes.csv` has a header and no rows; vendor adapters refuse with VendorNotLicensed; manual entry requires four-eyes attestation in `data/live/review_ledger.csv` (table `market_manual`), which does not exist here | docs/runbooks/A-market-data.md lines 10-13, 23; docs/runbooks/A-licensed-vendors.md lines 10-18; `market/manual.py` docstring; team/board/A.csv line 34 | high | A/AGENT-06; licence Sam |
| X8 | 88-country universe approved but `data/countries.csv` has the 18 desk rows | Verified. `data/panel/universe_proposal.csv` has 88 rows; `data/countries.csv` has 18, all tier `desk_current`. EQ-A-0026 Blocked on the Mac fetch | team/logs/A.jsonl lines 151-154; team/board/A.csv line 27 | medium | A/AGENT-06 |
| X9 | Live coverage 14% vs the 60% target on Sam's 2026-10-23 pull | Partly verified. The 60% target is in docs/runbooks/A-universe-expansion.md line 4; since Sam's decision of 2026-10-24 12:41Z (EQ-A-0055) it is 60% of the 50 feed-eligible cells per country (900 for the 18), measured 224/900 = 24.9%, 0 of 18 countries at 30 of 50 (`universe missing`, column pct_live_eligible). The 14% figure was not found as a measurement of Sam's pull in this folder: the nearest is "expected live 14.5% overall (ceiling 19.1%) vs 60% target" for the 88-country proposal (team/logs/A.jsonl line 151). Measured here for the 18: 224/1,494 = 15.0% feed-filled (`live_inputs.csv`), 245/1,494 = 16.4% applied live (`audit_trail.csv`). Sam's Mac may hold a later pull. EQ-A-0062 (part 3): even with every built and configured adapter verified, the 18 reach 348/900 = 38.7% and 0 of 18 reach 30 of 50 (best 21 of 50; Senegal 13, Venezuela 14); with the IMF / OECD transforms that still lack codes and the 6.10 mapping, 477/900 = 53.0% and still 0 of 18. The target needs the research datasets (Sam's decision) | `python -m econquest.ingestion.coverage_gaps build --data data`; `data/panel/coverage_gaps_part3.csv`; docs/runbooks/A-coverage-plan.md section 10 | high | A/AGENT-06 |
| X10 | 396 hand-entered cells unattested at 0.1.4 | Verified, and still 396 in this folder's audit trail (adjustments 378, prediction_markets 18); `publish --write` is blocked until they are attested | docs/governance/releases/0.1.4-2026-10-23-package.md line 28; `data/audit_trail.csv` origin column; docs/usability/usability-pass-PI4.md U02 | high | A/AGENT-06; attestation Sam |
| X11 | Gate flags overridden on review | New finding. 72 `review.csv` rows have status `ok` with a gate reason, including 8 stale homicide rates (6.2, back to 2011) and Singapore NPLs (5.10, 2019) | `data/live/review.csv` | medium | A/AGENT-06 |
| X12 | No staleness check on BIS series | New finding. `WB_STALE_SERIES` covers World Bank only. Argentina's BIS policy rate ends 2025-07-10 and feeds 5.13 and `policy` | `feeds.py` line 1225; `raw_bis.csv` POLICY_RATE ARG | medium | A/AGENT-06 |
| X13 | DSA-derived 1.1, 1.2, 2.1 rest on Claude estimates and have 24 undecided holds | New finding | `data/dsa_inputs.csv` source column ("Claude estimate 2024-25"); `review.csv` holds with empty decision | high | B/AGENT-05 (dsa), A/AGENT-06 (gate) |
| X14 | BIS CBS basis and bank-type codes unverified | Verified in code comment: "UNVERIFIED ... The first Mac pull must confirm both" | `feeds.py` lines 502-510 | low | A/AGENT-06 |
| X15 | World Bank history is not point in time | Verified: wbgapi serves only the current database | `feeds.py` lines 415-417; docs/runbooks/A-full-panel-fetch.md line 181 | medium | A/AGENT-06 |
| X16 | IDS US$ series arrive one row per creditor with the counterpart dimension dropped | Found under EQ-A-0062 on the 2026-10-23 pull: `raw_worldbank.csv` has up to 35 rows per country and year for DT.TDS.DPPG.CD (3,808 rows for 13 countries), so the World total cannot be told apart; the 0.4.0 staged pull (2026-10-24) refused 2.2 for 60 of 88 countries on DT.DOD.DSTC.CD for the same reason. The 2.2 transform refuses (no value) rather than keep an arbitrary row. Fix built in EQ-A-0068 (0.4.2): `WorldBankFeed` asks IDS (source 6) for the World counterpart only (`official/worldbank.py` `fetch_ids`, counterpart code `WLD` UNVERIFIED) and refuses records that carry other counterparts. Open until the 0.4.2 Mac rerun shows one World row per country and year; `econquest dsa` still picks 1.2's aggregate by a max/sum heuristic on data pulled before the fix | `raw_worldbank.csv` DT.TDS.DPPG.CD, DT.DOD.DSTC.CD; `official/worldbank.py` `fetch_ids`, `_by_year`; `engine/dsa.py` `ppg_debt_service_24m` | high | A/AGENT-06 (feeds.py); B/AGENT-05 (dsa) |

## How to refresh

1. Pull and review on Sam's Mac (docs/runbooks/A-fetch-on-mac.md), so `data/live/` holds the new vintage, plus
   `unserved.csv` and `feed_failures.csv`, which the current code writes (`feeds.save_report`).
2. Regenerate the register, read-only:
   `python -m econquest.ingestion.limitations --data data --out /tmp/data-limitations.md [--as-of YYYY-MM-DD]`
   (`build_register(data_dir, out_path, as_of=None)` in Python; `dataroom build` writes it into each room as
   `limitations/data-limitations.md`). It reads the files listed in its docstring, recomputes coverage, seed share,
   gate holds, latest periods and severities, writes only the output file and prints the totals. The feed source
   maps are imported from `feeds.py`, so they cannot drift. `raw_yahoo.csv` is optional (Yahoo removed, EQ-A-0040).
3. The narrative (this header, the Summary totals and top 5, the column notes, the X rows, and ISSUES and
   SEV_OVERRIDE in `econquest/ingestion/limitations.py`) is hand-written and not regenerated: recheck it by hand
   against the new tables, team/board/A.csv and team/logs/A.jsonl (EQ-A-0008, 0016, 0026, 0040 and the ACLED
   licence), and edit the constants in the module.
4. Close an X row only with the file or log line that proves it is fixed.
"""


def _rd(p: Path, **k) -> pd.DataFrame:
    return pd.read_csv(p, dtype=str, keep_default_na=False, **k)


def _live_source(d: Path, as_of) -> tuple[Path, str, str]:
    """(folder holding the live tables, its label, as_of label). Without as_of: data_dir/live."""
    live = d / "live"
    if as_of is None:
        return live, "data/live", ""
    from .dataroom import cutoff_of, id_ts, parse_ts
    label, cut = cutoff_of(as_of)
    fj = live / "feeds.json"
    if fj.is_file():
        try:
            t = parse_ts(json.loads(fj.read_text(encoding="utf-8")).get("retrieved"))
        except (OSError, ValueError, AttributeError):
            t = None
        if t is not None and t <= cut and all((live / f).is_file() for f in LIVE_FILES):
            return live, "data/live", label
    root = live / "vintages"
    cands = []
    if root.is_dir():
        for p in root.iterdir():
            t = id_ts(p.name) if p.is_dir() and not p.is_symlink() else None
            if t is not None and t <= cut and all((p / f).is_file() for f in LIVE_FILES):
                cands.append((t, p.name, p))
    if not cands:
        raise ValueError(f"no pull at or before {label}: data/live/feeds.json is later or missing and no live vintage "
                         f"under {root} with {', '.join(LIVE_FILES)} is dated at or before it")
    _, name, p = max(cands)
    return p, f"data/live/vintages/{name}", label


def build_register(data_dir, out_path, as_of=None) -> dict:
    """Write the data limitations register (Markdown, the format of docs/validation/data-limitations.md) for the data
    in `data_dir` to `out_path` and return the computed totals: {"rows", "severity", "by_table", "live_source",
    "as_of", "optional", "li_cells", "li_share", "inputs_live", "inputs_live_share", "origin", "review_status",
    "open_holds", "flagged_ok", "high"}. Read-only on data_dir; see the module docstring for the files and as_of."""
    d = Path(data_dir)
    live, live_label, as_of_label = _live_source(d, as_of)
    ind = _rd(d / "indicators.csv"); rb = _rd(d / "rulebook.csv").set_index("id")
    ctry = _rd(d / "countries.csv")
    aud = _rd(d / "audit_trail.csv")
    if as_of is not None and "retrieved" in aud.columns:
        from .dataroom import cutoff_of, parse_ts
        cut = cutoff_of(as_of)[1]
        aud = aud[[(t is None or t <= cut) for t in (parse_ts(v) for v in aud["retrieved"])]].reset_index(drop=True)
    rev = _rd(live / "review.csv")
    for c in ("decision", "reason"):
        if c not in rev.columns:                 # a vintage review.csv written before the decision columns existed
            rev[c] = ""
    li = _rd(live / "live_inputs.csv")             # ids as text: 2.10 must not collapse onto 2.1 (HO-20261024-C-A-002)
    li = li.set_index(li.columns[0]); li.index = li.index.astype(str).str.strip()
    li = li.apply(lambda c: pd.to_numeric(c.replace("", float("nan")), errors="coerce"))
    lp = pd.read_csv(live / "live_profile.csv", index_col=0)
    wb = pd.read_csv(live / "raw_worldbank.csv", dtype={"period": str}); bis = _rd(live / "raw_bis.csv")
    yh = _rd(live / "raw_yahoo.csv") if (live / "raw_yahoo.csv").is_file() else None      # optional since EQ-A-0040
    xru = _rd(live / "raw_bis_xru.csv") if (live / "raw_bis_xru.csv").is_file() else None
    optional = {f: (live / f).exists() for f in ("unserved.csv", "feed_failures.csv", "missing_cells.csv")}

    def src_ind(k):
        api = rb.at[k, "api"] if k in rb.index else ""
        if k in WEO: return f"IMF WEO (imf-reader): {WEO[k]}"  # noqa: E701
        if k in WB: return f"World Bank (wbgapi): {WB[k]}"  # noqa: E701
        if k in BIS: return f"BIS SDMX: {BIS[k]}"  # noqa: E701
        if k in DSA: return DSA[k]  # noqa: E701
        low = api.lower()
        tag = "manual" if ("manual" in low or "analyst" in low) else "planned_api"
        return f"{tag}: {api}"

    def wb_latest(s):
        x = wb[wb["series"] == s]
        if x.empty: return "no row in raw_worldbank.csv"  # noqa: E701
        lat = pd.to_numeric(x.groupby("iso")["period"].max(), errors="coerce")
        return f"WB {int(lat.min())}-{int(lat.max())} ({len(lat)} countries)"

    def bis_latest(s):
        x = bis[bis["series"] == s]
        if x.empty: return "no row"  # noqa: E701
        lat = x.groupby("iso")["period"].max()
        return f"BIS {lat.min()} to {lat.max()} ({len(lat)} countries)"

    def latest_ind(k):
        if k in WEO:
            return {"5.6": "WEO 2027 projection (t+1)", "1.7": "WEO 2026 vs 2021", "5.12": "WEO 2012-2026 ex 2020-21"}.get(k, "WEO 2026 (current-year estimate)")
        if k in ("3.4", "3.5"): return "no WGI row in raw_worldbank.csv"  # noqa: E701
        if k in WB_RAW: return wb_latest(WB_RAW[k])  # noqa: E701
        if k in BIS_RAW: return bis_latest(BIS_RAW[k])  # noqa: E701
        if k in DSA: return "WEO t+1 / IDS projections; dsa_inputs.csv estimates 2024-25"  # noqa: E701
        return "seed (audit_trail: 'seed estimate (analyst/Claude, Oct 2026)')"

    def counts(table, key):
        a = aud[(aud["table"] == table) & (aud["key"] == key)]
        o = a["origin"]
        r = rev[(rev["table"] == table) & (rev["key"] == key)]
        hold = r[r["status"] == "hold"]
        return dict(live=int((o == "live feed").sum()), seed=int(o.str.startswith("seed").sum()),
                    hand=int(o.str.startswith("hand").sum()), nrows=len(a), hold=len(hold),
                    open=int((hold["decision"].str.strip() == "").sum()),
                    flagged_ok=int(((r["status"] == "ok") & (r["reason"].str.strip() != "")).sum()),
                    miss=int((r["status"] == "missing").sum()))

    def severity(k, c, required, kind):
        if k in SEV_OVERRIDE: return SEV_OVERRIDE[k]  # noqa: E701
        if kind == "static": return "low"  # noqa: E701
        share = c["seed"] / N if c["nrows"] else 1.0
        if required and kind == "flag": return "medium"  # noqa: E701
        if required and (share >= 0.5 or c["open"]): return "high"  # noqa: E701
        if required: return "medium"  # noqa: E701
        if share >= 0.5 or c["open"] or c["flagged_ok"]: return "medium"  # noqa: E701
        return "low"

    def fx_source(k):
        """Source and latest-period text of a Yahoo-era field (fx3m, equity_vol); raw_yahoo.csv is optional."""
        if yh is not None:
            series = "FX_USD" if k == "fx3m" else "ETF"
            return f"Yahoo: {YAHOO[k]}", f"Yahoo to {yh[yh['series'] == series]['period'].max()}"
        if k == "fx3m":
            if xru is not None and len(xru):
                x = xru[xru["series"].astype(str).str.endswith(XRU_SERIES_SUFFIX)] if "series" in xru.columns else xru
                return f"BIS/ECB: {OFFICIAL_FX}", f"BIS XRU to {x['period'].max()}"
            return f"BIS/ECB: {OFFICIAL_FX}", "no raw_yahoo.csv (Yahoo removed, EQ-A-0040) and no raw_bis_xru.csv"
        return f"unserved: {NO_OFFICIAL_SOURCE}", "not served (EQ-A-0040)"

    rows = []
    for r in ind.itertuples(index=False):
        k = r.id
        c = counts("Inputs", k)
        feed = int(li.loc[k].notna().sum()) if k in li.index else 0
        required = k in REQ_IND
        gate = f"{c['hold']} hold ({c['open']} open)" if c["hold"] else "0"
        if c["flagged_ok"]:
            gate += f"; {c['flagged_ok']} flagged then accepted"
        if c["miss"]:
            gate += f"; {c['miss']} missing"
        issue = ISSUES.get(k, "Seed estimate, no feed mapped yet." if c["live"] == 0 else "")
        owner = ("B/AGENT-05 (dsa) + A/AGENT-06 (apply)" if k in DSA else
                 ("A/AGENT-06 (feed)" if (k in WEO or k in WB or k in BIS) else "A/AGENT-06 file; value analyst (Sam)"))
        rows.append(dict(table="Inputs", id=k, name=r.indicator, unit=r.unit, use=("required" if required else "scored"),
                         source=src_ind(k), coverage=f"{feed}/18 feed; {c['live']}/18 applied", seed=f"{c['seed']}/18",
                         gate=gate, latest=latest_ind(k), issues=issue, severity=severity(k, c, required, "ind"), owner=owner))

    for k in list(ctry.columns[1:]) + ["equity_vol"]:
        fed = k in WB or k in BIS or k in YAHOO
        c = counts("Country Profile", k)
        feed = int(lp[k].notna().sum()) if k in lp.columns else 0
        kind = "static" if k in STATIC else ("flag" if k in REQ_FLAGS or k in {"CDS", "Eurobond", "FX", "FX options", "Local rates", "Equity", "default"} else "num")
        required = k in REQ_PROF or k in REQ_FLAGS
        use = "required" if required else ("position" if k in POS_PROF else ("advisory" if k in ADV_PROF else "other"))
        if fed:
            cov = f"{feed}/18 feed; {c['live']}/18 applied" if c["nrows"] else f"{feed}/18 feed; not applied"
            seed = f"{c['seed']}/18" if c["nrows"] else "n/a (not in countries.csv)"
            if k in WB:
                src, latest = f"World Bank (wbgapi): {WB[k]}", wb_latest(WB_RAW[k])
            elif k in BIS:
                src, latest = f"BIS SDMX: {BIS[k]}", bis_latest(BIS_RAW[k])
            else:
                src, latest = fx_source(k)
            if k == "reserves":
                latest += "; NY.GDP.MKTP.CD 2025"
        else:
            src = "manual (countries.csv, hand-entered; not in audit_trail)"
            cov = "0/18 feed"; seed = "18/18 (manual, untracked)"; latest = "seed Oct 2026 (no as-of date in file)"
            c = dict(c, seed=N)
        gate = f"{c['hold']} hold ({c['open']} open)" if c["hold"] else "0"
        if c["miss"]:
            gate += f"; {c['miss']} missing"
        rows.append(dict(table="Country Profile", id=k, name=k, unit=UNITS.get(k, "text/flag" if kind != "num" else "see engine"),
                         use=use, source=src, coverage=cov, seed=seed, gate=gate, latest=latest, issues=ISSUES.get(k, ""),
                         severity=severity(k, c, required, kind),
                         owner="A/AGENT-06 (feed)" if fed else "A/AGENT-06 file; value analyst (Sam)"))

    df = pd.DataFrame(rows)

    def md(t):
        out = ["| " + " | ".join(HDR) + " |", "|" + "---|" * len(HDR)]
        for r in t[COLS].itertuples(index=False):
            out.append("| " + " | ".join(str(v).replace("|", "/").replace("\n", " ") for v in r) + " |")
        return "\n".join(out)

    src_note = f"source: {live_label}" + (f"; as of {as_of_label}" if as_of_label else "")
    tables = (f"<!-- generated tables: econquest.ingestion.limitations.build_register ({src_note}) -->\n\n"
              f"## Register: Inputs indicators (data/indicators.csv, {len(ind)} rows)\n\n"
              + md(df[df.table == "Inputs"])
              + f"\n\n## Register: Country Profile fields (data/countries.csv, {len(ctry.columns) - 1} columns, plus equity_vol)\n\n"
              + md(df[df.table == "Country Profile"]) + "\n")
    out = Path(out_path)
    out.parent.mkdir(parents=True, exist_ok=True)
    out.write_text(HEADER + tables + FOOTER + "\n", encoding="utf-8")

    li_cells = int(li.notna().sum().sum())
    # EQ-A-0055 (Sam 2026-10-24 12:41Z): the 60% target counts feed-eligible cells (universe.feed_eligible_ids). The
    # tables do not depend on it, so a folder whose ids the map cannot classify still gets its register, with the
    # reason in the totals instead of the share.
    elig_stats: dict = {}
    try:
        from .universe import LIVE_TARGET, _eligible_for, target_denominator
        elig, _ = _eligible_for(Path(d), ind["id"])
        elig &= set(ind["id"].str.strip())
        li_e = li[li.index.isin(elig)]
        n_cells = len(elig) * li.shape[1]
        elig_stats = {"n_feed_eligible": len(elig), "li_eligible_cells": int(li_e.notna().sum().sum()),
                      "li_eligible_share": int(li_e.notna().sum().sum()) / n_cells if n_cells else 0.0,
                      "target_denominator": target_denominator(LIVE_TARGET, len(elig))}
    except (ValueError, FileNotFoundError) as e:
        elig_stats = {"feed_eligible_error": str(e)}
    inputs_live = int(((aud["table"] == "Inputs") & (aud["origin"] == "live feed")).sum())
    return {"rows": len(df), "severity": df["severity"].value_counts().to_dict(),
            "by_table": {t: g["severity"].value_counts().to_dict() for t, g in df.groupby("table")},
            "live_source": live_label, "as_of": as_of_label or None, "optional": optional,
            "raw_yahoo": yh is not None, "li_cells": li_cells, "li_share": li_cells / li.size if li.size else 0.0,
            **elig_stats,
            "inputs_live": inputs_live, "inputs_live_share": inputs_live / (len(ind) * N) if len(ind) else 0.0,
            "origin": aud["origin"].value_counts().to_dict(), "review_status": rev["status"].value_counts().to_dict(),
            "open_holds": int(((rev["status"] == "hold") & (rev["decision"].str.strip() == "")).sum()),
            "flagged_ok": int(((rev["status"] == "ok") & (rev["reason"].str.strip() != "")).sum()),
            "high": [(t, i) for t, i in df[df.severity == "high"][["table", "id"]].itertuples(index=False)]}


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.limitations",
                                 description="Data limitations register (GOV-010, EQ-A-0044): read-only, writes one Markdown file")
    ap.add_argument("--data", default=None, help="econquest data folder (default: <ECONQUEST_HOME or checkout>/data)")
    ap.add_argument("--out", required=True, help="Markdown file to write")
    ap.add_argument("--as-of", default=None, help="YYYY-MM-DD: use the newest pull at or before the end of that UTC day")
    a = ap.parse_args(argv)
    if a.data is None:
        from .dataroom import home_dir
        a.data = str(home_dir() / "data")
    try:
        stats = build_register(a.data, a.out, as_of=a.as_of)
    except (ValueError, FileNotFoundError, KeyError) as e:
        print(f"limitations: {e}", file=sys.stderr)
        return 2
    buf = io.StringIO()
    json.dump(stats, buf, indent=1, sort_keys=True, default=str)
    print(f"wrote {a.out}\n{buf.getvalue()}\nThe header, footer, ISSUES and SEV_OVERRIDE are hand-written: re-check them by hand.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
