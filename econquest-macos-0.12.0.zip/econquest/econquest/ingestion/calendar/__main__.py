"""python -m econquest.ingestion.calendar ids|drop|demo (see adapters.main)."""
from econquest.ingestion.calendar.adapters import main

if __name__ == "__main__":
    raise SystemExit(main())
