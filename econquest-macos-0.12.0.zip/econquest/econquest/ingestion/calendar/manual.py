"""Hand-entered calendar events (EQ-A-0132) through the existing attestation path (ledger, as market/manual.py).

enter_events(data_dir, rows, author, approver=None, self_approved=False, note="", now=None):
  1. four-eyes check (ledger.check_approval) before anything is written: an approver other than the author, or
     self_approved=True (Sam's single-operator mode, stored approver = author, flagged);
  2. every row must cite its source: source_url (https) or document (a named record, e.g. a prospectus with page),
     plus retrieved_utc (when the analyst read it). Rows take origin 'manual', author and approver;
  3. rows go to data/calendar/events.csv through store.record_events (point in time, revisions, never edited);
  4. one ledger attestation per written row (ledger.attest_rows, table TABLE, key "<event_id>|<revision>",
     country = iso3, value = date, content_sha256 of the stored row).
A correction is a new entry for the same event_id: it becomes the next revision; the old one stays.

unattested_manual(data_dir) lists manual rows with no approved attestation of their current content (never
attested, edited after entry, or withdrawn by a later hold/reject). query.events leaves those rows out by default.
"""
from __future__ import annotations

from econquest.ingestion import ledger
from econquest.ingestion.calendar.schema import CalendarError, content_sha256, text_problem
from econquest.ingestion.calendar.store import read_events, record_events

TABLE = "calendar_manual"
ENTRY_FIELDS = ["event_id", "kind", "iso3", "date", "precision", "importance", "status", "title", "amount_usd",
                "source_id", "licence_id", "source_url", "document", "retrieved_utc", "provenance", "note"]
MAX_ROWS_PER_ENTRY = 2000


def cell_key(r) -> str:
    return f"{r['event_id']}|{r['revision']}"


def enter_events(data_dir, rows, author: str, approver: str | None = None, self_approved: bool = False,
                 note: str = "", now=None) -> dict:
    """Validate, record and attest hand-entered events; returns {'written', 'unchanged', 'attestations'}."""
    author, approver, _flag = ledger.check_approval(author, approver, self_approved)
    for role, who in (("author", author), ("approver", approver)):
        if text_problem(who):
            raise CalendarError(f"{role} refused: {text_problem(who)}")
    note = "" if note is None else str(note)
    if note and text_problem(note):
        raise CalendarError(f"note refused: {text_problem(note)}")
    rows = list(rows)
    if not rows:
        raise CalendarError("no rows to enter")
    if len(rows) > MAX_ROWS_PER_ENTRY:
        raise CalendarError(f"more than {MAX_ROWS_PER_ENTRY} rows in one entry")
    probs = []
    for i, r in enumerate(rows, start=1):
        extra = sorted(set(r) - set(ENTRY_FIELDS) - {"date_end"})
        if extra:
            probs.append(f"row {i}: unexpected columns {extra}")
        if not (str(r.get("source_url", "")).strip() or str(r.get("document", "")).strip()):
            probs.append(f"row {i}: a hand-entered event needs a cited source (source_url or document)")
        if str(r.get("synthetic", "false")).lower() == "true":
            probs.append(f"row {i}: synthetic rows are never hand-entered")
    if probs:
        raise CalendarError("; ".join(probs))
    full = [{**r, "origin": "manual", "author": author, "approver": approver, "synthetic": "false"} for r in rows]
    rec = record_events(data_dir, full, now=now)
    cells = [{"key": cell_key(r), "country": r["iso3"], "value": r["date"], "content_sha256": r["content_sha256"]}
             for r in rec["written"]]
    att = ledger.attest_rows(data_dir, TABLE, cells, author, approver, self_approved,
                             note=note or "attested hand-entered calendar event", now=now) if cells else []
    return {"written": rec["written"], "unchanged": rec["unchanged"], "attestations": att}


def unattested_manual(data_dir) -> list[dict]:
    """Manual rows whose content (recomputed, not trusted from the row) has no approved attestation."""
    df = read_events(data_dir)
    if df.empty:
        return []
    m = df[df["origin"] == "manual"]
    if m.empty:
        return []
    best = ledger.attested_content(data_dir, TABLE)
    out = []
    for r in m.to_dict("records"):
        h = content_sha256(r)
        reason = ""
        if h != r["content_sha256"]:
            reason = "row edited after entry (content hash differs)"
        elif h not in best.get((cell_key(r), r["iso3"]), {}):
            reason = "no approved attestation for this content (or withdrawn by a later hold/reject)"
        if reason:
            out.append({"event_id": r["event_id"], "revision": r["revision"], "iso3": r["iso3"], "reason": reason})
    return out
