"""Calendar query interface (EQ-A-0132), read by Team C's GUI alerts and morning view (EQ-C-0155) and Team B.

Stable API (changes need a handoff):

    events(data_dir=None, country=None, kinds=None, start=None, end=None, as_of=None, min_importance=None,
           include_hidden=False, include_unattested=False) -> pandas.DataFrame, columns QUERY_COLUMNS
    upcoming(days, today=None, data_dir=None, country=None, kinds=None, min_importance=2, as_of=None) -> list[dict]
           alert rows (schema.ALERT_FIELDS + days_until + event_id), soonest first
    demo_calendar_data(data_dir=None) -> {"ok", "problems", "summary", "counts"}  (demo row M18)

Rules:
  * point in time: as_of (date = end of that UTC day, or YYYY-MM-DDTHH:MM:SSZ) sees only revisions recorded by then
    (store.view); default as_of None = everything recorded;
  * an event matches [start, end] when its period overlaps it (date <= end and date_end >= start);
  * held, cancelled and withdrawn events are left out unless include_hidden; a row edited after storage (content
    hash differs) is always left out; a manual row with no approved attestation is left out unless
    include_unattested;
  * client_output comes from the data/licences.csv row named by licence_id ('restricted' when the register has no
    such row: never looser than the register).
"""
from __future__ import annotations

import datetime as dt
from pathlib import Path

import pandas as pd

from econquest.ingestion.calendar.adapters import DROP_ADAPTERS, find_drop
from econquest.ingestion.calendar.schema import (ALERT_FIELDS, EVENT_COLUMNS, HIDDEN_STATUSES, KINDS, CalendarError,
                                                 as_of_stamp, parse_date, utc_stamp)
from econquest.ingestion.calendar.store import REPO_DATA, events_path, read_events, view

QUERY_COLUMNS = EVENT_COLUMNS + ["client_output", "attested"]
LABEL = "M18 event calendar"


def _data_dir(data_dir) -> Path:
    return Path(data_dir) if data_dir is not None else REPO_DATA


def _register_tags(data_dir: Path) -> dict:
    from econquest.ingestion import licences
    try:
        reg = licences.load_register(licences.data_dir_register(data_dir) or None)
    except Exception:                                   # noqa: BLE001 - an unreadable register restricts everything
        return {}
    return {r["source_id"]: r.get("client_output", "restricted") for r in reg}


def _countries(country, data_dir: Path) -> set[str] | None:
    if country is None:
        return None
    vals = [country] if isinstance(country, str) else list(country)
    out = set()
    names = {}
    try:
        c = pd.read_csv(data_dir / "countries.csv", dtype=str, keep_default_na=False, usecols=["country", "iso"])
        names = {a.strip().lower(): b for a, b in zip(c["country"], c["iso"])}
    except (OSError, ValueError):
        pass
    for v in vals:
        s = str(v).strip()
        if len(s) == 3 and s.isalpha() and s.isupper():
            out.add(s)
        elif s.lower() in names:
            out.add(names[s.lower()])
        else:
            raise CalendarError(f"country {s!r} is neither ISO3 nor a name in countries.csv")
    return out


def _dates(start, end) -> tuple[str | None, str | None]:
    def one(x):
        if x is None:
            return None
        if isinstance(x, dt.datetime):                   # a datetime counts as its UTC day (ARCH-A-PI13 C-1)
            return utc_stamp(x)[:10]
        return (x if isinstance(x, dt.date) else parse_date(x)).isoformat()
    return one(start), one(end)


def events(data_dir=None, country=None, kinds=None, start=None, end=None, as_of=None, min_importance=None,
           include_hidden: bool = False, include_unattested: bool = False) -> pd.DataFrame:
    """Events visible as of `as_of`, filtered; sorted by date, country, kind. See the module docstring."""
    d = _data_dir(data_dir)
    if kinds is not None:
        kinds = [kinds] if isinstance(kinds, str) else list(kinds)
        bad = [k for k in kinds if k not in KINDS]
        if bad:
            raise CalendarError(f"kinds {bad} not in {sorted(KINDS)}")
    isos = _countries(country, d)
    s, e = _dates(start, end)
    as_of_stamp(as_of)                                   # validates
    df = view(d, as_of)
    if df.empty:
        return pd.DataFrame(columns=QUERY_COLUMNS)
    df = df[~df["edited"]]
    if not include_hidden:
        df = df[~df["status"].isin(HIDDEN_STATUSES)]
    if isos is not None:
        df = df[df["iso3"].isin(isos)]
    if kinds is not None:
        df = df[df["kind"].isin(kinds)]
    if s:
        df = df[df["date_end"] >= s]
    if e:
        df = df[df["date"] <= e]
    if min_importance is not None:
        df = df[df["importance"].astype(int) >= int(min_importance)]
    df = df.copy()
    manual = df["origin"] == "manual"
    df["attested"] = True
    if manual.any():
        from econquest.ingestion.calendar.manual import unattested_manual
        bad = {(u["event_id"], u["revision"]) for u in unattested_manual(d)}
        df.loc[manual, "attested"] = [(a, b) not in bad for a, b in zip(df.loc[manual, "event_id"],
                                                                        df.loc[manual, "revision"])]
        if not include_unattested:
            df = df[df["attested"]]
    tags = _register_tags(d)
    df["client_output"] = [tags.get(x, "restricted") for x in df["licence_id"]]
    return df[QUERY_COLUMNS].reset_index(drop=True)


def upcoming(days: int, today=None, data_dir=None, country=None, kinds=None, min_importance: int | None = 2,
             as_of=None) -> list[dict]:
    """Alert rows for events whose period overlaps [today, today + days]; as_of defaults to today (point in time).
    today may be a date, 'YYYY-MM-DD' or a datetime: a datetime counts as its UTC day for the window and is itself the
    default as_of (only what was recorded by that instant). days_until = days from today to the event's first day
    (0 when the period has started)."""
    if int(days) < 0:
        raise CalendarError("days must be >= 0")
    pit = today
    if isinstance(today, dt.datetime):                   # ARCH-A-PI13 C-1: date - datetime raised TypeError
        today = dt.date.fromisoformat(utc_stamp(today)[:10])
    t = today if isinstance(today, dt.date) else (parse_date(today) if today else dt.datetime.now(dt.timezone.utc).date())
    df = events(data_dir, country=country, kinds=kinds, start=t, end=t + dt.timedelta(days=int(days)),
                as_of=as_of if as_of is not None else (pit if isinstance(pit, dt.datetime) else t),
                min_importance=min_importance)
    out = []
    for r in df.to_dict("records"):
        row = {k: r[k] for k in ALERT_FIELDS}
        row["importance"] = int(row["importance"])
        row["event_id"] = r["event_id"]
        row["days_until"] = max(0, (dt.date.fromisoformat(r["date"]) - t).days)
        out.append(row)
    return sorted(out, key=lambda x: (x["days_until"], -x["importance"], x["iso3"], x["kind"]))


def demo_calendar_data(data_dir=None) -> dict:
    """Demo row M18 (data side): the store is readable and point in time, holds no synthetic or edited rows, every
    row has a licence row and a source, manual rows are attested, the query and alert helpers run, and every drop
    adapter answers. {"ok", "problems", "summary", "counts"}; never raises on a failed check."""
    d = _data_dir(data_dir)
    problems: list[str] = []
    counts: dict = {}
    try:
        raw = read_events(d)
        counts["revisions"] = int(len(raw))
        if raw.empty:
            problems.append(f"no events stored in {events_path(d)}")
        else:
            if raw["edited"].any():
                problems.append(f"{int(raw['edited'].sum())} rows edited after storage (content hash differs)")
            if (raw["synthetic"] == "true").any():
                problems.append(f"{int((raw['synthetic'] == 'true').sum())} SYNTHETIC rows in the store")
            nosrc = raw[(raw["source_url"] == "") & (raw["document"] == "")]
            if len(nosrc):
                problems.append(f"{len(nosrc)} rows without a source")
            tags = _register_tags(d)
            missing = sorted(set(raw["licence_id"]) - set(tags))
            if missing:
                problems.append(f"licence rows missing in data/licences.csv: {missing}")
            first = raw["recorded_utc"].min()
            before = (dt.datetime.strptime(first, "%Y-%m-%dT%H:%M:%SZ") - dt.timedelta(seconds=1)).strftime(
                "%Y-%m-%dT%H:%M:%SZ")
            if not view(d, before).empty:
                problems.append("point-in-time view before the first recording is not empty")
            from econquest.ingestion.calendar.manual import unattested_manual
            un = unattested_manual(d)
            if un:
                problems.append(f"{len(un)} manual rows without an approved attestation")
        ev = events(d)
        counts["events"] = int(len(ev))
        counts["by_kind"] = {k: int(v) for k, v in ev["kind"].value_counts().items()} if len(ev) else {}
        counts["countries"] = int(ev["iso3"].nunique()) if len(ev) else 0
        counts["upcoming_365d"] = len(upcoming(365, data_dir=d, min_importance=1, as_of=None))
        counts["drops"] = {s: ("dropped" if find_drop(d, s) else "not dropped") for s in DROP_ADAPTERS}
    except Exception as e:                               # noqa: BLE001 - reported, never a silent pass
        problems.append(f"{type(e).__name__}: {e}"[:300])
    summary = (f"{LABEL}: {counts.get('events', 0)} events ({counts.get('by_kind', {})}) over "
               f"{counts.get('countries', 0)} countries; {counts.get('upcoming_365d', 0)} in the next 365 days; "
               f"drops {counts.get('drops', {})}" + (f"; {len(problems)} problems" if problems else ""))
    return {"ok": not problems, "problems": problems, "summary": summary, "counts": counts}
