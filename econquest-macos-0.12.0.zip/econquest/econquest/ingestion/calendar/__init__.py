"""Event calendar (EQ-A-0132): elections, IMF programmes and reviews, Eurobond maturities and amortisation, aggregate
external debt service, and sovereign rating review dates for the desk names, stored point in time.

    from econquest.ingestion import calendar
    calendar.events(country="ARG", kinds=["imf_review"], start="2026-11-01", end="2027-06-30", as_of="2026-10-26")
    calendar.upcoming(30, today="2026-10-26")            # alert rows
    calendar.demo_calendar_data()                         # demo row M18 check

Store: data/calendar/events.csv (store.py). Schema: schema.py. Adapters: adapters.py. Hand entry: manual.py.
Runbook: docs/runbooks/A-calendar.md.
"""
from econquest.ingestion.calendar.query import QUERY_COLUMNS, demo_calendar_data, events, upcoming
from econquest.ingestion.calendar.schema import (ALERT_FIELDS, DEFAULT_IMPORTANCE, EVENT_COLUMNS, KINDS, SOURCES,
                                                 CalendarError)

__all__ = ["ALERT_FIELDS", "DEFAULT_IMPORTANCE", "EVENT_COLUMNS", "KINDS", "QUERY_COLUMNS", "SOURCES", "CalendarError",
           "demo_calendar_data", "events", "upcoming"]
