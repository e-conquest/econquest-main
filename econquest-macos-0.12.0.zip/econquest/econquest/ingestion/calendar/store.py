"""Point-in-time event store (EQ-A-0132): data/calendar/events.csv, append-only.

record_events(data_dir, rows, now=None, allow_synthetic=False) validates rows (schema.validate_rows), stamps
recorded_utc, gives each a revision and appends it under an exclusive lock (ledger.locked_append). It is idempotent:
a row whose substance (SAME_FIELDS) equals the latest revision of its event_id is skipped, so re-running an adapter on
the same file writes nothing. A changed row becomes revision n+1; old revisions are never edited or removed.

Synthetic content never enters the repo's data/: a row with synthetic=true is refused when data_dir is the repo's
data/ folder (or inside it, such as data/mvp), and refused everywhere unless allow_synthetic=True (tests on tmp dirs).

view(data_dir, as_of) is the point-in-time read: revisions with recorded_utc <= as_of, the highest revision per
event_id. `edited` is true on a row whose stored content_sha256 no longer matches its content.
"""
from __future__ import annotations

import csv
from pathlib import Path

import pandas as pd

from econquest.ingestion import ledger
from econquest.ingestion.calendar.schema import (CONTENT_FIELDS, EVENT_COLUMNS, CalendarError, as_of_stamp,
                                                 content_sha256, utc_stamp, validate_rows)

STORE_DIR = "calendar"
EVENTS_FILE = "events.csv"
DROP_DIR = "drop"
REPO_DATA = Path(__file__).resolve().parents[3] / "data"
SAME_FIELDS = [c for c in CONTENT_FIELDS if c not in ("revision", "recorded_utc", "retrieved_utc", "provenance",
                                                      "document")]
MAX_ROWS_PER_CALL = 20000


def store_dir(data_dir) -> Path:
    return Path(data_dir) / STORE_DIR


def events_path(data_dir) -> Path:
    return store_dir(data_dir) / EVENTS_FILE


def drop_dir(data_dir, source_id: str) -> Path:
    return store_dir(data_dir) / DROP_DIR / source_id


def _is_repo_data(data_dir) -> bool:
    """True when data_dir, or the store folder or file below it (followed through any link), is in the repo's data/
    (SEC-A-015 C-L1: a linked <tmp>/calendar -> data/calendar must not carry synthetic rows into data/)."""
    try:
        repo = REPO_DATA.resolve()
        for q in (Path(data_dir), store_dir(data_dir), events_path(data_dir)):
            p = q.resolve()
            if p == repo or repo in p.parents:
                return True
        return False
    except OSError:
        return True


def read_events(data_dir) -> pd.DataFrame:
    """Every stored revision (str columns) plus `edited` (bool). Missing file: empty frame."""
    p = events_path(data_dir)
    if not p.exists():
        return pd.DataFrame(columns=EVENT_COLUMNS + ["edited"])
    df = pd.read_csv(p, dtype=str, keep_default_na=False)
    missing = [c for c in EVENT_COLUMNS if c not in df.columns]
    if missing:
        raise CalendarError(f"{p}: columns {missing} missing")
    df = df[EVENT_COLUMNS].copy()
    df["edited"] = [content_sha256(r) != r["content_sha256"] for r in df.to_dict("records")]
    return df


def _latest(rows: list[dict]) -> dict:
    out: dict = {}
    for r in rows:
        k = r["event_id"]
        if k not in out or int(r["revision"]) > int(out[k]["revision"]):
            out[k] = r
    return out


def record_events(data_dir, rows, now=None, allow_synthetic: bool = False) -> dict:
    """Validate and append rows; returns {'written': [rows], 'unchanged': n, 'path': str}. Raises CalendarError
    (nothing written) on any invalid row or a synthetic row where it is not allowed."""
    rows = list(rows.to_dict("records") if isinstance(rows, pd.DataFrame) else rows)
    if len(rows) > MAX_ROWS_PER_CALL:
        raise CalendarError(f"more than {MAX_ROWS_PER_CALL} rows in one call")
    stamp = utc_stamp(now)
    rows = [{**r, "recorded_utc": stamp} for r in rows]
    clean = validate_rows(rows)
    syn = [r["event_id"] for r in clean if r["synthetic"] == "true"]
    if syn and (_is_repo_data(data_dir) or not allow_synthetic):
        raise CalendarError(f"{len(syn)} SYNTHETIC rows refused for {data_dir} (synthetic content never enters "
                            f"the repo's data/): {syn[:3]}")
    ids = [r["event_id"] for r in clean]
    if len(set(ids)) != len(ids):
        raise CalendarError("an event_id appears twice in one call")
    written, unchanged = [], 0
    with ledger.locked_append(events_path(data_dir), EVENT_COLUMNS) as (w, f, new):
        existing = []
        if not new:
            with open(events_path(data_dir), newline="", encoding="utf-8") as fr:
                existing = list(csv.DictReader(fr))
        latest = _latest(existing)
        last = max((str(e.get("recorded_utc", "")) for e in existing), default="")
        if last and stamp < last:
            raise CalendarError(f"recorded_utc {stamp} is earlier than the latest stored recording {last}: a "
                                f"back-dated write would show in earlier as-of views (SEC-A-015 C-L3)")
        if new:
            w.writeheader()
        for r in clean:
            prev = latest.get(r["event_id"])
            if prev is not None and all(str(prev.get(c, "")) == r[c] for c in SAME_FIELDS):
                unchanged += 1
                continue
            r["revision"] = str(int(prev["revision"]) + 1 if prev is not None else 1)
            r["content_sha256"] = content_sha256(r)
            w.writerow(r)
            written.append(r)
    return {"written": written, "unchanged": unchanged, "path": str(events_path(data_dir))}


def view(data_dir, as_of=None) -> pd.DataFrame:
    """Point-in-time view: per event_id the highest revision recorded at or before as_of."""
    df = read_events(data_dir)
    if df.empty:
        return df
    df = df[df["recorded_utc"] <= as_of_stamp(as_of)].copy()
    if df.empty:
        return df
    df["_rev"] = df["revision"].astype(int)
    df = df.sort_values(["event_id", "_rev"]).groupby("event_id", as_index=False).tail(1)
    return df.drop(columns="_rev").sort_values(["date", "iso3", "kind", "event_id"]).reset_index(drop=True)
