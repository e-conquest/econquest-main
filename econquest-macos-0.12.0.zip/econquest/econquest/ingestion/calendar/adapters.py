"""Event calendar adapters, one per public source (EQ-A-0132).

The cloud cannot reach these publishers, so no adapter runs a network call. Each turns ONE recorded file into event
rows (schema.EVENT_COLUMNS) and refuses an unknown layout loudly (CalendarError naming the columns found). Country
names map to ISO3 through default_panel.default_iso_lookup; unknown names are listed in `unmapped`, never guessed.

| source_id      | file (drop folder data/calendar/drop/<source_id>/, one file)  | layout (UNVERIFIED until a real file lands)  |
|----------------|----------------------------------------------------------------|----------------------------------------------|
| worldbank_ids  | raw_worldbank.csv from a Mac pull (read in place, not dropped) | iso,series,period,value,source[,counterpart] |
| electionguide  | IFES ElectionGuide upcoming-elections table saved as CSV       | Country, Election For, Date, Status          |
| imf_mona       | IMF MONA arrangement reviews report saved as CSV               | Arrangement Number, Country Name,            |
|                |                                                                | Arrangement Type, Review Sequence,           |
|                |                                                                | Original Schedule Date[, Board Action Date]  |
| rating_calendar| agency EU sovereign rating calendars (CRA Regulation art. 8a)  | Agency, Country, Date, Source URL            |
|                | transcribed to CSV                                             |                                              |
| prospectus     | Eurobond terms transcribed from a prospectus: HAND ENTRY ONLY  | see eurobond_rows; goes through manual.py    |

The layouts above follow each publisher's published table headings as documented in docs/runbooks/A-calendar.md;
none has been checked against a real download from this cloud. The first real file on the Mac confirms or refuses
the layout (refusal is loud, nothing is written).

SYNTHETIC: a file whose leading comment lines (lines starting '#', which no publisher file has) include the word
SYNTHETIC yields rows with synthetic=true. store.record_events refuses those rows for the repo's data/.

Only worldbank_ids has a recorded real source today (team/inbox/pull-20261025T013150Z/raw_worldbank.csv): aggregate
annual external PPG debt service projections, World counterpart only, not bond-level. The other adapters ship empty
and working; the live pulls are parked for the Mac pass (docs/runbooks/A-sam-ready.md).
"""
from __future__ import annotations

import datetime as dt
import hashlib
import io
import os
from dataclasses import dataclass, field
from pathlib import Path

import pandas as pd

from econquest.ingestion.calendar.schema import SOURCES, CalendarError, period_bounds, text_problem, utc_stamp
from econquest.ingestion.calendar.store import drop_dir, record_events

REPO_ROOT = Path(__file__).resolve().parents[3]
MAX_FILE_BYTES = 20 * 1024 * 1024
IDS_SERIES = "DT.TDS.DPPG.CD"
WORLD_CODES = {"WLD", "WORLD", "1W", "W00", "W"}
COUNTERPART_COLUMNS = ("counterpart", "counterpart_area", "counterpart_code", "counterpart_area_code",
                       "counterpartarea")
URLS = {
    "worldbank_ids": "https://datacatalog.worldbank.org/search/dataset/0038015",
    "electionguide": "https://www.electionguide.org/elections/upcoming/",
    "imf_mona": "https://www.imf.org/external/np/pdr/mona/index.aspx",
}
LAYOUTS = {
    "electionguide": (["Country", "Election For", "Date", "Status"], []),
    "imf_mona": (["Arrangement Number", "Country Name", "Arrangement Type", "Review Sequence", "Original Schedule Date"],
                 ["Board Action Date", "Review Type"]),
    "rating_calendar": (["Agency", "Country", "Date", "Source URL"], []),
}
DATE_FORMATS = (("%Y-%m-%d", "day"), ("%d %B %Y", "day"), ("%d %b %Y", "day"), ("%B %d, %Y", "day"),
                ("%b %d, %Y", "day"), ("%B %Y", "month"), ("%b %Y", "month"), ("%Y-%m", "month"), ("%Y", "year"))
ELECTION_STATUS = {"confirmed": "confirmed", "tentative": "tentative", "scheduled": "scheduled",
                   "postponed": "tentative", "cancelled": "cancelled"}


@dataclass
class AdapterResult:
    source_id: str
    rows: list[dict] = field(default_factory=list)
    unmapped: list[str] = field(default_factory=list)
    skipped: list[str] = field(default_factory=list)
    file: str = ""
    sha256: str = ""
    synthetic: bool = False
    status: str = "ok"               # ok | not dropped


def parse_when(text) -> tuple[str, str]:
    """('YYYY-MM-DD' first day, precision) for a publisher date text; CalendarError when no known format fits."""
    s = " ".join(str(text).replace(" ", " ").split())
    for fmt, prec in DATE_FORMATS:
        try:
            d = dt.datetime.strptime(s, fmt).date()
        except ValueError:
            continue
        return period_bounds(prec, d)[0].isoformat(), prec
    raise CalendarError(f"date {s[:40]!r} matches no known format")


def _sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def _rel(path: Path) -> str:
    try:
        return Path(path).resolve().relative_to(REPO_ROOT.resolve()).as_posix()
    except ValueError:
        return Path(path).name


def _read_table(path: Path, required: list[str], optional: list[str]) -> tuple[pd.DataFrame, bool, bytes]:
    """(frame, synthetic, raw bytes). Leading '#' lines are comments; SYNTHETIC in them marks the file."""
    path = Path(path)
    if path.stat().st_size > MAX_FILE_BYTES:
        raise CalendarError(f"{path.name}: larger than {MAX_FILE_BYTES} bytes")
    raw = path.read_bytes()
    try:
        text = raw.decode("utf-8-sig")
    except UnicodeDecodeError as e:
        raise CalendarError(f"{path.name}: not UTF-8 text ({e.reason} at byte {e.start})") from None
    lines = text.splitlines(keepends=True)
    head = []
    while lines and lines[0].lstrip().startswith("#"):
        head.append(lines.pop(0))
    synthetic = any("SYNTHETIC" in h.upper() for h in head)
    df = pd.read_csv(io.StringIO("".join(lines)), dtype=str, keep_default_na=False)
    df.columns = [str(c).strip() for c in df.columns]
    missing = [c for c in required if c not in df.columns]
    if missing:
        raise CalendarError(f"{path.name}: layout not recognised: columns {missing} missing; found {list(df.columns)}")
    return df[[c for c in required + optional if c in df.columns]], synthetic, raw


def _iso_lookup() -> tuple[dict, callable]:
    from econquest.ingestion.default_panel import _name_key, default_iso_lookup
    return default_iso_lookup(), _name_key


def find_drop(data_dir, source_id: str) -> Path | None:
    """The one file in data/calendar/drop/<source_id>/ (None when empty or missing); two files are refused."""
    d = drop_dir(data_dir, source_id)
    if not d.is_dir():
        return None
    # SEC-A-015 C-L2: a linked drop folder (or a link anywhere on the way to it) or a linked file would read a file
    # from outside the data folder into the store; both are refused, as research/base.find_local does (SEC-A-014 P4-L2)
    try:
        inside = Path(data_dir).resolve() in d.resolve().parents
    except OSError:
        inside = False
    if any(q.is_symlink() for q in (d, d.parent, d.parent.parent)) or not inside:
        raise CalendarError(f"{d}: the drop folder is a link or resolves outside the data folder; refused")
    links = sorted(p.name for p in d.iterdir() if p.is_symlink())
    if links:
        raise CalendarError(f"{d}: linked files refused: {links}")
    files = sorted(p for p in d.iterdir() if p.is_file() and not p.name.startswith("."))
    if len(files) > 1:
        raise CalendarError(f"{d}: {len(files)} files; keep exactly one release file")
    return files[0] if files else None


def _base(source_id: str, kind: str, iso3: str, key: str, retrieved: str, document: str, url: str,
          synthetic: bool, provenance: str) -> dict:
    return {"event_id": f"{kind}:{iso3}:{source_id}:{key}", "kind": kind, "iso3": iso3, "source_id": source_id,
            "licence_id": SOURCES[source_id], "source_url": url, "document": document, "retrieved_utc": retrieved,
            "origin": "adapter", "synthetic": "true" if synthetic else "false", "provenance": provenance}


def _key(*parts) -> str:
    s = "/".join("".join(ch if ch.isalnum() or ch in "._-" else "-" for ch in str(p).strip()) for p in parts)
    return s[:80]


def _cycle_keys(rows: list[dict], always: bool) -> list[dict]:
    """ARCH-A-PI13 F-1: an event's key is its body (or agency) plus its cycle, never its date, so a date that moves
    is a new revision of the same event, not a second event. The cycle is the year; several events with the same
    body and year are numbered by date ("-1", "-2", ...; with always=False the first keeps the bare key)."""
    groups: dict = {}
    for r in rows:
        groups.setdefault(r["event_id"], []).append(r)
    for eid, g in groups.items():
        if len(g) == 1 and not always:
            continue
        for n, r in enumerate(sorted(g, key=lambda x: (x["date"], x["title"])), start=1):
            if n > 1 or always:
                r["event_id"] = f"{eid}-{n}"
    return rows


def _retrieved(path: Path, retrieved_utc: str | None) -> str:
    if retrieved_utc:
        return retrieved_utc
    return utc_stamp(dt.datetime.fromtimestamp(os.stat(path).st_mtime, tz=dt.timezone.utc))


# ---- World Bank IDS: aggregate annual external PPG debt service (real, recorded) ------------------------------------

def ids_debt_service(raw_csv, desk_iso3: set[str] | None, retrieved_utc: str, pull_folder: str,
                     first_year: int | None = None) -> AdapterResult:
    """Annual external PPG debt service events from a recorded raw_worldbank.csv (series DT.TDS.DPPG.CD).

    Selection only, values unchanged: with a counterpart column only World rows count; without one, a country-year
    with more than one row is per-creditor data that cannot be told apart from the total, so that country is skipped
    (listed in `skipped`). Years before `first_year` (default: the retrieval year) are left out: the calendar is
    forward-looking. One event per country-year, precision 'year', amount_usd = the value as published."""
    path = Path(raw_csv)
    raw = path.read_bytes()
    sha = _sha(raw)
    df = pd.read_csv(io.BytesIO(raw), dtype=str, keep_default_na=False)
    need = ["iso", "series", "period", "value", "source"]
    if [c for c in need if c not in df.columns]:
        raise CalendarError(f"{path.name}: layout not recognised: need {need}; found {list(df.columns)}")
    synthetic = "SYNTHETIC" in " ".join(df["source"].unique()).upper()
    res = AdapterResult("worldbank_ids", file=_rel(path), sha256=sha, synthetic=synthetic)
    x = df[df["series"] == IDS_SERIES].copy()
    cp = next((c for c in df.columns if c.strip().lower() in COUNTERPART_COLUMNS), None)
    if cp:
        x = x[x[cp].str.strip().str.upper().isin(WORLD_CODES)]
    x = x[x["value"].str.strip() != ""]
    if desk_iso3 is not None:
        x = x[x["iso"].isin(desk_iso3)]
    y0 = first_year if first_year is not None else int(retrieved_utc[:4])
    x = x[pd.to_numeric(x["period"], errors="coerce") >= y0]
    dup = x.groupby(["iso", "period"]).size()
    bad = sorted({i for (i, _p), n in dup.items() if n > 1})
    res.skipped = [f"{i}: more than one {IDS_SERIES} row per year and no counterpart column" for i in bad]
    doc = f"{_rel(path)} sha256:{sha}"
    for r in x[~x["iso"].isin(bad)].itertuples(index=False):
        yr = int(r.period)
        prov = (f"pull {pull_folder}; file {_rel(path)} sha256:{sha}; series {IDS_SERIES} period {yr}; "
                f"source text {r.source!r}; World counterpart" + (f" ({cp} column)" if cp else
                " (one row per country-year: the pull asked IDS for the World counterpart only, EQ-A-0068)")
                + "; value as published; licence row worldbank_ids")
        row = _base("worldbank_ids", "external_debt_service", r.iso, _key(IDS_SERIES, yr), retrieved_utc, doc,
                    URLS["worldbank_ids"], synthetic, prov)
        row.update({"date": f"{yr}-01-01", "precision": "year", "status": "scheduled", "amount_usd": r.value,
                    "title": f"External PPG debt service due in {yr} (World Bank IDS projection, aggregate annual, "
                             f"all creditors; not bond-level)",
                    "note": "IDS projections cover debt outstanding and disbursed at the reference date; new "
                            "borrowing is not included"})
        res.rows.append(row)
    return res


# ---- IFES ElectionGuide -----------------------------------------------------------------------------------------

def electionguide(path, retrieved_utc: str | None = None, desk_iso3: set[str] | None = None) -> AdapterResult:
    """Elections from an ElectionGuide upcoming-elections table saved as CSV (LAYOUTS['electionguide'])."""
    req, opt = LAYOUTS["electionguide"]
    df, syn, raw = _read_table(Path(path), req, opt)
    sha, look_key = _sha(raw), _iso_lookup()
    look, keyf = look_key
    res = AdapterResult("electionguide", file=_rel(path), sha256=sha, synthetic=syn)
    got = _retrieved(Path(path), retrieved_utc)
    for r in df.to_dict("records"):
        iso = look.get(keyf(r["Country"]))
        if not iso:
            res.unmapped.append(r["Country"])
            continue
        if desk_iso3 is not None and iso not in desk_iso3:
            continue
        date, prec = parse_when(r["Date"])
        body = r["Election For"].strip()
        row = _base("electionguide", "election", iso, _key(body, date[:4]), got, f"{_rel(path)} sha256:{sha}",
                    URLS["electionguide"], syn, f"ElectionGuide table row: {r['Country']} / {body} / {r['Date']}")
        row.update({"date": date, "precision": prec, "title": f"Election: {body}"[:200],
                    "status": ELECTION_STATUS.get(r["Status"].strip().lower(), "tentative")})
        res.rows.append(row)
    res.rows = _cycle_keys(res.rows, always=False)
    return res


# ---- IMF MONA reviews -------------------------------------------------------------------------------------------

def imf_mona(path, retrieved_utc: str | None = None, desk_iso3: set[str] | None = None) -> AdapterResult:
    """IMF programme reviews from a MONA reviews report saved as CSV (LAYOUTS['imf_mona']). A review with a Board
    Action Date is dated on it (status confirmed); otherwise on the Original Schedule Date (status scheduled)."""
    req, opt = LAYOUTS["imf_mona"]
    df, syn, raw = _read_table(Path(path), req, opt)
    sha = _sha(raw)
    look, keyf = _iso_lookup()
    res = AdapterResult("imf_mona", file=_rel(path), sha256=sha, synthetic=syn)
    got = _retrieved(Path(path), retrieved_utc)
    for r in df.to_dict("records"):
        iso = look.get(keyf(r["Country Name"]))
        if not iso:
            res.unmapped.append(r["Country Name"])
            continue
        if desk_iso3 is not None and iso not in desk_iso3:
            continue
        board = r.get("Board Action Date", "").strip()
        date, prec = parse_when(board or r["Original Schedule Date"])
        seq = r["Review Sequence"].strip()
        row = _base("imf_mona", "imf_review", iso, _key(r["Arrangement Number"], seq), got,
                    f"{_rel(path)} sha256:{sha}", URLS["imf_mona"], syn,
                    f"MONA review: arrangement {r['Arrangement Number']} ({r['Arrangement Type']}), review {seq}, "
                    + ("Board Action Date" if board else "Original Schedule Date"))
        row.update({"date": date, "precision": prec, "status": "confirmed" if board else "scheduled",
                    "title": f"IMF {r['Arrangement Type'].strip()} review {seq}"[:200]})
        res.rows.append(row)
    return res


# ---- agency sovereign rating calendars --------------------------------------------------------------------------

def rating_calendar(path, retrieved_utc: str | None = None, desk_iso3: set[str] | None = None) -> AdapterResult:
    """Scheduled sovereign rating review dates transcribed from the agencies' EU CRA Regulation calendars
    (LAYOUTS['rating_calendar']); Source URL must be the agency's https page for that calendar."""
    req, opt = LAYOUTS["rating_calendar"]
    df, syn, raw = _read_table(Path(path), req, opt)
    sha = _sha(raw)
    look, keyf = _iso_lookup()
    res = AdapterResult("rating_calendar", file=_rel(path), sha256=sha, synthetic=syn)
    got = _retrieved(Path(path), retrieved_utc)
    for r in df.to_dict("records"):
        iso = look.get(keyf(r["Country"]))
        if not iso:
            res.unmapped.append(r["Country"])
            continue
        if desk_iso3 is not None and iso not in desk_iso3:
            continue
        agency = r["Agency"].strip()
        if text_problem(agency):
            raise CalendarError(f"{Path(path).name}: agency {agency[:30]!r}: {text_problem(agency)}")
        date, prec = parse_when(r["Date"])
        row = _base("rating_calendar", "rating_review", iso, _key(agency, date[:4]), got, f"{_rel(path)} sha256:{sha}",
                    r["Source URL"].strip(), syn, f"{agency} sovereign rating calendar")
        row.update({"date": date, "precision": prec, "status": "scheduled",
                    "title": f"{agency} scheduled sovereign rating review"[:200]})
        res.rows.append(row)
    res.rows = _cycle_keys(res.rows, always=True)
    return res


# ---- Eurobond terms from a prospectus (hand entry only) ---------------------------------------------------------

EUROBOND_COLUMNS = ["isin", "iso3", "maturity_date", "amount_usd", "amortisation", "prospectus_url", "document"]


def eurobond_rows(terms: list[dict]) -> list[dict]:
    """Event rows (maturity plus each amortisation instalment) for bonds whose terms an analyst transcribed from the
    prospectus. `amortisation` is '' (bullet) or 'YYYY-MM-DD:amount_usd;...'. The rows carry no author: they enter
    only through manual.enter_events, which attests them under the four-eyes rule."""
    out = []
    for t in terms:
        miss = [c for c in EUROBOND_COLUMNS if c not in t]
        if miss:
            raise CalendarError(f"eurobond terms need {EUROBOND_COLUMNS}; missing {miss}")
        isin, iso = str(t["isin"]).strip(), str(t["iso3"]).strip()
        src = {"kind": "eurobond_maturity", "iso3": iso, "source_id": "prospectus", "licence_id": SOURCES["prospectus"],
               "source_url": str(t["prospectus_url"]).strip(), "document": str(t["document"]).strip(),
               "precision": "day", "status": "scheduled"}
        out.append({**src, "event_id": f"eurobond_maturity:{iso}:prospectus:{_key(isin)}",
                    "date": str(t["maturity_date"]).strip(), "amount_usd": t["amount_usd"],
                    "title": f"Eurobond {isin} final maturity"})
        for part in [p for p in str(t["amortisation"] or "").split(";") if p.strip()]:
            d, _, amt = part.partition(":")
            out.append({**src, "kind": "eurobond_amortisation",
                        "event_id": f"eurobond_amortisation:{iso}:prospectus:{_key(isin, d)}", "date": d.strip(),
                        "amount_usd": amt.strip(), "title": f"Eurobond {isin} amortisation instalment"})
    return out


# ---- run one adapter on its drop folder -------------------------------------------------------------------------

DROP_ADAPTERS = {"electionguide": electionguide, "imf_mona": imf_mona, "rating_calendar": rating_calendar}


def pull_drop(data_dir, source_id: str, desk_iso3: set[str] | None = None, now=None,
              allow_synthetic: bool = False) -> dict:
    """Parse the drop file for `source_id` and record its events. Empty drop folder: status 'not dropped', nothing
    written (the adapter ships empty and working until the Mac pass saves a file)."""
    if source_id not in DROP_ADAPTERS:
        raise CalendarError(f"no drop adapter {source_id!r}; known {sorted(DROP_ADAPTERS)}")
    f = find_drop(data_dir, source_id)
    if f is None:
        return {"source_id": source_id, "status": "not dropped", "written": 0, "unchanged": 0, "unmapped": []}
    res = DROP_ADAPTERS[source_id](f, desk_iso3=desk_iso3)
    rows = res.rows + withdrawn_rows(data_dir, source_id, {r["event_id"] for r in res.rows}, res,
                                     retrieved_utc=res.rows[0]["retrieved_utc"] if res.rows else _retrieved(f, None))
    rec = record_events(data_dir, rows, now=now, allow_synthetic=allow_synthetic)
    n_wd = sum(1 for r in rec["written"] if r["status"] == "withdrawn")
    return {"source_id": source_id, "status": "ok", "file": res.file, "sha256": res.sha256,
            "written": len(rec["written"]) - n_wd, "withdrawn": n_wd, "unchanged": rec["unchanged"],
            "unmapped": res.unmapped}


def withdrawn_rows(data_dir, source_id: str, keep_ids: set[str], res: AdapterResult, retrieved_utc: str) -> list[dict]:
    """ARCH-A-PI13 F-1: a 'withdrawn' revision for each event this source recorded earlier (adapter rows, latest
    revision not already withdrawn) that the source's new file no longer lists. The old revisions stay."""
    from econquest.ingestion.calendar.schema import EVENT_COLUMNS
    from econquest.ingestion.calendar.store import view
    cur = view(data_dir)
    if cur.empty:
        return []
    cur = cur[(cur["source_id"] == source_id) & (cur["origin"] == "adapter") & (cur["status"] != "withdrawn")
              & ~cur["edited"] & ~cur["event_id"].isin(keep_ids)]
    out = []
    for r in cur.to_dict("records"):
        row = {c: r[c] for c in EVENT_COLUMNS if c not in ("revision", "recorded_utc", "content_sha256")}
        row.update({"status": "withdrawn", "retrieved_utc": max(retrieved_utc, r["retrieved_utc"]),
                    "document": f"{res.file} sha256:{res.sha256}",
                    "note": f"not in the source's newer file {res.file} sha256:{res.sha256[:16]}",
                    "synthetic": "true" if res.synthetic or r["synthetic"] == "true" else "false"})
        out.append(row)
    return out


def desk_iso3(data_dir) -> set[str]:
    """ISO3 of the desk names (data/countries.csv)."""
    return set(pd.read_csv(Path(data_dir) / "countries.csv", dtype=str, keep_default_na=False)["iso"])


def main(argv=None) -> int:
    """python -m econquest.ingestion.calendar ids --raw PATH --pull NAME --retrieved UTC [--data data]
       python -m econquest.ingestion.calendar drop SOURCE [--data data]
       python -m econquest.ingestion.calendar demo [--data data]"""
    import argparse
    import json
    ap = argparse.ArgumentParser(prog="econquest.ingestion.calendar.adapters")
    ap.add_argument("cmd", choices=["ids", "drop", "demo"])
    ap.add_argument("source", nargs="?")
    ap.add_argument("--data", default=str(REPO_ROOT / "data"))
    ap.add_argument("--raw")
    ap.add_argument("--pull")
    ap.add_argument("--retrieved")
    a = ap.parse_args(argv)
    if a.cmd == "ids":
        if not (a.raw and a.pull and a.retrieved):
            ap.error("ids needs --raw, --pull and --retrieved")
        res = ids_debt_service(a.raw, desk_iso3(a.data), a.retrieved, a.pull)
        rec = record_events(a.data, res.rows)
        out = {"file": res.file, "sha256": res.sha256, "events": len(res.rows), "written": len(rec["written"]),
               "unchanged": rec["unchanged"], "skipped": res.skipped}
    elif a.cmd == "drop":
        out = pull_drop(a.data, a.source or "", desk_iso3=desk_iso3(a.data))
    else:
        from econquest.ingestion.calendar.query import demo_calendar_data
        out = demo_calendar_data(a.data)
    print(json.dumps(out, indent=1, default=str))
    return 0 if out.get("ok", True) else 1


if __name__ == "__main__":
    raise SystemExit(main())
