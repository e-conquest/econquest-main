"""Event calendar schema (EQ-A-0132): one row per revision of a dated event.

EVENT_COLUMNS (data/calendar/events.csv, append-only, written only by calendar.store.record_events):

    event_id       stable id of the event: "<kind>:<iso3>:<source_id>:<source key>" (sha-free, readable)
    revision       1, 2, ... per event_id; a correction or cancellation is a new revision, never an edit
    kind           one of KINDS (below)
    iso3           ISO 3166-1 alpha-3 of the country the event concerns
    date           first day the event can fall on, YYYY-MM-DD
    date_end       last day (equal to date for precision 'day'; end of month/quarter/year otherwise)
    precision      day | month | quarter | year
    importance     1 (low) | 2 (medium) | 3 (high); drives alerts (DEFAULT_IMPORTANCE per kind unless given)
    status         scheduled | confirmed | tentative | held | cancelled | withdrawn
                   (held: recorded but kept out of alerts and default views, with the reason in note)
    title          short description, plain text (text_problem-checked)
    amount_usd     US$ amount for debt events, '' otherwise
    source_id      the adapter / source that produced the row (SOURCES)
    source_url     URL of the publisher page or dataset ('' only when `document` names the record)
    document       the recorded file or document: path relative to the repo plus "sha256:<hex>", or a citation
    retrieved_utc  when the source was read (YYYY-MM-DDTHH:MM:SSZ)
    recorded_utc   when econquest stored this revision; the as-of filter (point in time)
    licence_id     data/licences.csv source_id that governs the row
    provenance     free text: pull folder, series, selection rule, entry id
    origin         adapter | manual
    author         hand entries: author ('' for adapters)
    approver       hand entries: approver ('' for adapters)
    synthetic      true | false; always false in the repo's data/ (store.record_events refuses true there)
    note           free text
    content_sha256 sha256 of CONTENT_FIELDS (canonical JSON), recomputed on read to detect edits

Point in time: an as-of view sees only revisions with recorded_utc <= as_of and, per event_id, the highest such
revision. A later recording never leaks into an earlier view. A date-only as_of means the end of that UTC day.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import json
import math
import re

EVENT_COLUMNS = ["event_id", "revision", "kind", "iso3", "date", "date_end", "precision", "importance", "status",
                 "title", "amount_usd", "source_id", "source_url", "document", "retrieved_utc", "recorded_utc",
                 "licence_id", "provenance", "origin", "author", "approver", "synthetic", "note", "content_sha256"]
CONTENT_FIELDS = ["event_id", "revision", "kind", "iso3", "date", "date_end", "precision", "importance", "status",
                  "title", "amount_usd", "source_id", "source_url", "document", "retrieved_utc", "recorded_utc",
                  "licence_id", "provenance", "origin", "author", "approver", "synthetic", "note"]

KINDS = {
    "election": "national election (general, presidential, legislative, referendum)",
    "imf_programme": "IMF arrangement milestone: Board approval, augmentation, expiry",
    "imf_review": "IMF programme review (Board date or scheduled review availability date)",
    "eurobond_maturity": "final maturity of a sovereign Eurobond (bond-level)",
    "eurobond_amortisation": "scheduled amortisation instalment of a sovereign Eurobond (bond-level)",
    "external_debt_service": "aggregate annual external PPG debt service (World Bank IDS projections; not bond-level)",
    "rating_review": "scheduled sovereign rating review date (EU CRA Regulation calendar)",
}
DEFAULT_IMPORTANCE = {"election": 3, "imf_programme": 3, "imf_review": 2, "eurobond_maturity": 3,
                      "eurobond_amortisation": 2, "external_debt_service": 1, "rating_review": 2}
PRECISIONS = ("day", "month", "quarter", "year")
STATUSES = ("scheduled", "confirmed", "tentative", "held", "cancelled", "withdrawn")
HIDDEN_STATUSES = ("held", "cancelled", "withdrawn")      # never alert; kept out of default views
ORIGINS = ("adapter", "manual")
SOURCES = {          # source_id -> licence_id (data/licences.csv)
    "worldbank_ids": "worldbank_ids",
    "electionguide": "calendar_electionguide",
    "national_electoral": "calendar_national_electoral",
    "imf_mona": "calendar_imf_programmes",
    "imf_country_page": "calendar_imf_programmes",
    "prospectus": "calendar_prospectus",
    "rating_calendar": "calendar_rating_agencies",
}
ALERT_FIELDS = ["date", "date_end", "precision", "iso3", "kind", "importance", "status", "title", "source_id",
                "source_url", "licence_id", "client_output"]   # what Team C's alerts read (EQ-C-0155)

ISO3_RE = re.compile(r"^[A-Z]{3}$")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
UTC_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$")
EVENT_ID_RE = re.compile(r"^[a-z_]+:[A-Z]{3}:[a-z_]+:[A-Za-z0-9._/-]{1,100}$")
FORMULA_LEAD = ("=", "+", "-", "@", "\t", "\r")
MAX_TEXT = 500


class CalendarError(ValueError):
    """A calendar row, file or request that is refused; the message names every problem."""


def text_problem(v) -> str:
    """'' when a text cell is safe to store and open in a spreadsheet, else the reason (same rule as market.schema)."""
    if not isinstance(v, str):
        return "not text"
    if v.lstrip().startswith(FORMULA_LEAD) and v.strip():
        return "starts with a formula character"
    if any(ord(c) < 32 or ord(c) == 127 for c in v):
        return "contains control characters"
    if len(v) > MAX_TEXT:
        return f"longer than {MAX_TEXT} characters"
    return ""


def utc_stamp(now: dt.datetime | None = None) -> str:
    now = now or dt.datetime.now(dt.timezone.utc)
    if now.tzinfo is None:
        now = now.replace(tzinfo=dt.timezone.utc)
    return now.astimezone(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def parse_date(s) -> dt.date:
    s = str(s).strip()
    if not DATE_RE.match(s):
        raise CalendarError(f"date {s!r} is not YYYY-MM-DD")
    return dt.date.fromisoformat(s)


def period_bounds(precision: str, d: dt.date) -> tuple[dt.date, dt.date]:
    """(first, last) day of the period containing d at `precision`."""
    if precision == "day":
        return d, d
    if precision == "month":
        nxt = dt.date(d.year + (d.month == 12), d.month % 12 + 1, 1)
        return d.replace(day=1), nxt - dt.timedelta(days=1)
    if precision == "quarter":
        q0 = 3 * ((d.month - 1) // 3) + 1
        first = dt.date(d.year, q0, 1)
        nxt = dt.date(d.year + (q0 == 10), (q0 + 3 - 1) % 12 + 1, 1)
        return first, nxt - dt.timedelta(days=1)
    if precision == "year":
        return dt.date(d.year, 1, 1), dt.date(d.year, 12, 31)
    raise CalendarError(f"precision {precision!r} not one of {PRECISIONS}")


def as_of_stamp(as_of) -> str:
    """as_of (None, date, datetime or text) -> UTC stamp compared with recorded_utc. A date means end of that day."""
    if as_of is None:
        return "9999-12-31T23:59:59Z"
    if isinstance(as_of, dt.datetime):
        return utc_stamp(as_of)
    if isinstance(as_of, dt.date):
        return f"{as_of.isoformat()}T23:59:59Z"
    s = str(as_of).strip()
    if DATE_RE.match(s):
        return f"{s}T23:59:59Z"
    if UTC_RE.match(s):
        return s
    raise CalendarError(f"as_of {s!r} is not YYYY-MM-DD or YYYY-MM-DDTHH:MM:SSZ")


def content_sha256(row: dict) -> str:
    blob = {c: str(row.get(c, "")) for c in CONTENT_FIELDS}
    return hashlib.sha256(json.dumps(blob, sort_keys=True, ensure_ascii=False).encode("utf-8")).hexdigest()


def _truthy(v) -> bool:
    return str(v).strip().lower() in ("true", "1", "yes")


def normalise(row: dict) -> dict:
    """Fill defaults (date_end from precision, importance from kind, empty text) and return a str-valued row with
    EVENT_COLUMNS minus content_sha256. Validation is separate (validate_row)."""
    r = {c: ("" if row.get(c) is None else row.get(c)) for c in EVENT_COLUMNS if c != "content_sha256"}
    r["precision"] = str(r["precision"] or "day")
    if r["date"] and not r["date_end"]:
        try:
            first, last = period_bounds(r["precision"], parse_date(r["date"]))
            r["date"], r["date_end"] = first.isoformat(), last.isoformat()
        except CalendarError:
            pass
    if r["importance"] in ("", None):
        r["importance"] = DEFAULT_IMPORTANCE.get(str(r["kind"]), 2)
    r["importance"] = str(r["importance"])
    r["revision"] = str(r["revision"] or 1)
    r["status"] = str(r["status"] or "scheduled")
    r["synthetic"] = "true" if _truthy(r["synthetic"]) else "false"
    r["amount_usd"] = str(r["amount_usd"]).strip()     # kept exactly as the source wrote it (row_problems checks it)
    return {k: str(v) for k, v in r.items()}


def row_problems(r: dict) -> list[str]:
    """Every problem with one normalised row ([] when it is acceptable)."""
    p = []
    if not EVENT_ID_RE.match(r["event_id"]):
        p.append(f"event_id {r['event_id'][:90]!r} is not <kind>:<ISO3>:<source_id>:<key>")
    elif r["event_id"].split(":")[0] != r["kind"] or r["event_id"].split(":")[1] != r["iso3"]:
        p.append("event_id does not start with the row's kind and iso3")
    if not r["revision"].isdigit() or int(r["revision"]) < 1:
        p.append(f"revision {r['revision']!r} is not a positive integer")
    if r["kind"] not in KINDS:
        p.append(f"kind {r['kind']!r} not one of {sorted(KINDS)}")
    if not ISO3_RE.match(r["iso3"]):
        p.append(f"iso3 {r['iso3']!r} is not ISO 3166-1 alpha-3")
    if r["precision"] not in PRECISIONS:
        p.append(f"precision {r['precision']!r} not one of {PRECISIONS}")
    try:
        d0, d1 = parse_date(r["date"]), parse_date(r["date_end"])
        if d1 < d0:
            p.append("date_end before date")
        elif r["precision"] in PRECISIONS and (d0, d1) != period_bounds(r["precision"], d0):
            p.append(f"date..date_end {d0}..{d1} is not one {r['precision']}")
    except CalendarError as e:
        p.append(str(e))
    if r["importance"] not in ("1", "2", "3"):
        p.append(f"importance {r['importance']!r} not 1, 2 or 3")
    if r["status"] not in STATUSES:
        p.append(f"status {r['status']!r} not one of {STATUSES}")
    if r["origin"] not in ORIGINS:
        p.append(f"origin {r['origin']!r} not one of {ORIGINS}")
    if r["source_id"] not in SOURCES:
        p.append(f"source_id {r['source_id']!r} not one of {sorted(SOURCES)}")
    elif r["licence_id"] != SOURCES[r["source_id"]]:
        p.append(f"licence_id {r['licence_id']!r} is not {SOURCES[r['source_id']]!r} for source {r['source_id']}")
    if not r["source_url"] and not r["document"]:
        p.append("no source: a row needs source_url or document")
    if r["source_url"] and not r["source_url"].startswith("https://"):
        p.append("source_url is not https://")
    for c in ("retrieved_utc", "recorded_utc"):
        if not UTC_RE.match(r[c]):
            p.append(f"{c} {r[c]!r} is not YYYY-MM-DDTHH:MM:SSZ")
    if UTC_RE.match(r["retrieved_utc"]) and UTC_RE.match(r["recorded_utc"]) and r["retrieved_utc"] > r["recorded_utc"]:
        p.append("retrieved_utc after recorded_utc")
    if r["amount_usd"]:
        try:
            if not math.isfinite(float(r["amount_usd"])) or float(r["amount_usd"]) < 0:
                p.append("amount_usd is not a finite non-negative number")
        except ValueError:
            p.append("amount_usd is not a number")
    if r["origin"] == "manual" and not (r["author"] and r["approver"]):
        p.append("a manual row needs author and approver")
    for c in ("title", "provenance", "note", "document", "source_url", "author", "approver"):
        why = text_problem(r[c]) if r[c] else ""
        if why:
            p.append(f"{c}: {why}")
    if not r["title"]:
        p.append("title is empty")
    return p


def validate_rows(rows: list[dict]) -> list[dict]:
    """Normalise and validate; raises CalendarError naming every problem (row numbers from 1)."""
    out, probs = [], []
    for i, row in enumerate(rows, start=1):
        try:
            r = normalise(row)
        except (TypeError, ValueError) as e:
            probs.append(f"row {i}: {e}")
            continue
        probs += [f"row {i} ({r['event_id'][:60]}): {x}" for x in row_problems(r)]
        out.append(r)
    if probs:
        raise CalendarError("; ".join(probs[:40]) + (f"; ... {len(probs) - 40} more" if len(probs) > 40 else ""))
    return out
