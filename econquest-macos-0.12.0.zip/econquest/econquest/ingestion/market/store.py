"""Point-in-time market snapshot store (EQ-A-0029).

save_market_snapshot writes data/live/market/snapshots/<YYYY-MM-DDTHHMMSSZ>-<hash8>/quotes.csv plus manifest.json,
both read-only (0444), in a folder created with exist_ok=False (never overwritten), and appends one row to
data/live/market/snapshots/index.csv under ledger.locked_append. hash8 is the first 8 hex digits of the SHA-256 of
quotes.csv written with an empty snapshot_id column.

SIMULATED rows (EQ-A-0123, vendor_sim_guard): save_market_snapshot and _append_cds_snapshots refuse
(SimulatedDataError) any row or provenance labelled SIMULATED unless data_dir is a sandbox data folder.

Reads are point-in-time: market_history / latest_market(asof=D) use only snapshots saved at or before D (end of
day D UTC when D is a date) and only quotes dated on or before D. When two snapshots carry the same KEY, the later
snapshot wins (a correction supersedes, the original stays on disk). No snapshot -> FileNotFoundError, never a
silent fallback.

CDS curve snapshots for Team B (HO-20261023-B-A-009): saving a snapshot does NOT write data/market/cds_snapshots.csv
(SEC-A-003 M1). The file is written only by the explicit, gated export step cds_export.export_gated_cds_snapshots
(export_cds_snapshots below is the same call): each snapshot's cds rows go through gate.market_gate and the
market_manual attestations first, and the dropped rows are reported. _append_cds_snapshots is the low-level writer:
rows already in the file are skipped, existing rows are never rewritten, and a row whose capture/tenor/quote type is
already there with different content raises.

Integrity (SEC-A-003 L4): read_market_snapshot(verify=True) checks quotes.csv against three anchors that do not live
in the manifest's own sha256 alone: the content hash (quotes.csv with snapshot_id blanked) must start with the id's
hash8 and equal manifest content_hash, and the body sha256 must equal both the manifest sha256 and the sha256 of the
snapshot's row in the append-only index.csv.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import io
import json
import os
from pathlib import Path

import pandas as pd

from econquest.ingestion.ledger import locked_append
from econquest.ingestion.market import vendor_sim_guard
from econquest.ingestion.market.schema import (CDS_SNAPSHOT_COLUMNS, KEY, MARKET_COLUMNS, SERIES, SNAPSHOT_ID_RE,
                                               MarketDataError, empty_market, to_cds_snapshots, validate_market)

INDEX_COLUMNS = ["snapshot_id", "saved_utc", "sha256", "rows", "sources", "licences", "instruments", "asof_min",
                 "asof_max"]


def market_root(data_dir: Path) -> Path:
    return Path(data_dir) / "live" / "market"


def snapshot_root(data_dir: Path) -> Path:
    return market_root(data_dir) / "snapshots"


def _utc(now: dt.datetime | None) -> dt.datetime:
    now = now or dt.datetime.now(dt.timezone.utc)
    return now.astimezone(dt.timezone.utc) if now.tzinfo else now.replace(tzinfo=dt.timezone.utc)


def utc_stamp(now: dt.datetime | None = None) -> str:
    return _utc(now).strftime("%Y-%m-%dT%H:%M:%SZ")


def _csv_bytes(df: pd.DataFrame) -> bytes:
    out = df.copy()
    out["derived"] = out["derived"].map(lambda b: "true" if b else "false")
    return out[MARKET_COLUMNS].to_csv(index=False, float_format="%.10g").encode()


def save_market_snapshot(data_dir: Path, df: pd.DataFrame, now: dt.datetime | None = None, *,
                         provenance: dict | None = None) -> Path:
    """Validate `df` (validate_market), fill blank retrieved_utc with `now`, and write an append-only snapshot.
    Returns the snapshot folder. Raises MarketDataError on contract problems or an empty frame, FileExistsError if
    the same content is saved twice in the same second."""
    now = _utc(now)
    m = validate_market(df)
    if m.empty:
        raise MarketDataError("refusing to save an empty market snapshot")
    # EQ-A-0123: SIMULATED rows are saved only into a sandbox data folder, never into desk data
    vendor_sim_guard.guard_save(data_dir, m, provenance, "market snapshot")
    m.loc[m["retrieved_utc"] == "", "retrieved_utc"] = utc_stamp(now)
    if (m["retrieved_utc"] > utc_stamp(now)).any():
        raise MarketDataError("retrieved_utc after the save time")
    m = validate_market(m)                              # re-check asof <= retrieved_utc with the filled stamps
    m["snapshot_id"] = ""
    digest = hashlib.sha256(_csv_bytes(m)).hexdigest()
    root = snapshot_root(data_dir)
    root.mkdir(parents=True, exist_ok=True)
    sid = f"{now.strftime('%Y-%m-%dT%H%M%SZ')}-{digest[:8]}"
    folder = root / sid
    folder.mkdir(exist_ok=False)
    m["snapshot_id"] = sid
    body = _csv_bytes(m)
    sources, licences = sorted(set(m["source"])), sorted(set(m["licence"]))
    manifest = {"snapshot_id": sid, "saved_utc": utc_stamp(now), "rows": int(len(m)),
                "sha256": hashlib.sha256(body).hexdigest(), "content_hash": digest, "sources": sources,
                "licences": licences, "instruments": sorted(set(m["instrument"])),
                "asof_min": str(m["asof"].min()), "asof_max": str(m["asof"].max()),
                "retrieved_utc": sorted(set(m["retrieved_utc"])), "provenance": provenance or {}}
    for name, data in (("quotes.csv", body),
                       ("manifest.json", json.dumps(manifest, indent=1, sort_keys=True, default=str).encode())):
        (folder / name).write_bytes(data)
        os.chmod(folder / name, 0o444)
    with locked_append(root / "index.csv", INDEX_COLUMNS) as (w, _f, new):
        if new:
            w.writeheader()
        w.writerow({"snapshot_id": sid, "saved_utc": manifest["saved_utc"], "sha256": manifest["sha256"],
                    "rows": len(m), "sources": "|".join(sources), "licences": "|".join(licences),
                    "instruments": "|".join(manifest["instruments"]), "asof_min": manifest["asof_min"],
                    "asof_max": manifest["asof_max"]})
    # No cds_snapshots.csv append here (SEC-A-003 M1): run cds_export.export_gated_cds_snapshots after the gate.
    return folder


CDS_SNAPSHOT_KEY = ["snapshot_id", "as_of", "iso3", "tenor_y", "quote_type"]


def cds_snapshots_path(data_dir: Path) -> Path:
    """data/market/cds_snapshots.csv: Team B's CDS curve snapshot file (engine/cds_curves.py)."""
    return Path(data_dir) / "market" / "cds_snapshots.csv"


def _fmt(v) -> str:
    if isinstance(v, float):
        return "" if v != v else format(v, ".10g")
    return "" if v is None else str(v)


def _rows_to_append(path: Path, recs: list[dict], old: pd.DataFrame | None) -> list[dict]:
    have: dict = {}
    if old is not None:
        if list(old.columns) != CDS_SNAPSHOT_COLUMNS:
            raise MarketDataError(f"{path} header {list(old.columns)} is not {CDS_SNAPSHOT_COLUMNS}; not appending")
        have = {tuple(r[c] for c in CDS_SNAPSHOT_KEY): r for r in old.to_dict("records")}
    out = []
    for r in recs:
        k = tuple(r[c] for c in CDS_SNAPSHOT_KEY)
        if k in have:
            if have[k] != r:
                raise MarketDataError(f"{path} already holds {k} with other content; existing rows are never rewritten")
            continue
        have[k] = r
        out.append(r)
    return out


def _append_cds_snapshots(data_dir: Path, market_rows: pd.DataFrame, *, dry_run: bool = False, **convert) -> int:
    """Low-level writer, no gate: only cds_export calls it, with rows that passed the gate and the attestation
    check. Convert saved market rows (schema.to_cds_snapshots, `convert` passed through) and append them to
    data/market/cds_snapshots.csv under ledger.locked_append. Returns the number of rows appended (dry_run: that
    would be appended; nothing is written). Identical rows already in the file are skipped; existing rows are never
    rewritten; a row whose CDS_SNAPSHOT_KEY is already in the file with other content, or a file whose header is not
    CDS_SNAPSHOT_COLUMNS, raises MarketDataError."""
    vendor_sim_guard.guard_save(data_dir, market_rows, None, "cds_snapshots.csv export")    # EQ-A-0123
    new = to_cds_snapshots(market_rows, **convert)
    if new.empty:
        return 0
    recs = [{c: _fmt(v) for c, v in r.items()} for r in new[CDS_SNAPSHOT_COLUMNS].to_dict("records")]
    path = cds_snapshots_path(data_dir)
    if dry_run:
        old = pd.read_csv(path, dtype=str, keep_default_na=False) if path.exists() else None
        return len(_rows_to_append(path, recs, old))
    with locked_append(path, CDS_SNAPSHOT_COLUMNS) as (w, _f, is_new):
        old = None if is_new else pd.read_csv(path, dtype=str, keep_default_na=False)
        out = _rows_to_append(path, recs, old)
        if is_new:
            w.writeheader()
        for r in out:
            w.writerow(r)
    return len(out)


def export_cds_snapshots(data_dir: Path, snapshot_ids=None, *, dry_run: bool = False, params=None, **convert):
    """The gated CDS snapshot export (SEC-A-003 M1): cds_export.export_gated_cds_snapshots. Appends the gate-passed,
    attested cds rows of every stored snapshot (or of `snapshot_ids`) to data/market/cds_snapshots.csv; rerunning
    is safe. Returns a CdsExportReport (appended count, dropped rows with reasons). FileNotFoundError when no
    snapshot."""
    from econquest.ingestion.market.cds_export import export_gated_cds_snapshots
    return export_gated_cds_snapshots(data_dir, snapshot_ids, dry_run=dry_run, params=params, **convert)


def list_market_snapshots(data_dir: Path) -> pd.DataFrame:
    """index.csv rows (save order) whose folder exists; empty frame with INDEX_COLUMNS when none."""
    idx = snapshot_root(data_dir) / "index.csv"
    if not idx.exists():
        return pd.DataFrame(columns=INDEX_COLUMNS)
    ix = pd.read_csv(idx, dtype=str, keep_default_na=False)
    ok = ix["snapshot_id"].str.fullmatch(SNAPSHOT_ID_RE) & ix["snapshot_id"].map(
        lambda s: (snapshot_root(data_dir) / s / "quotes.csv").exists())
    return ix[ok].reset_index(drop=True)


def _content_hash(body: bytes) -> str:
    """SHA-256 of quotes.csv bytes with the snapshot_id column blanked (the hash8 in the id and manifest content_hash).
    Every cell is read and rewritten as text, so the bytes are those save_market_snapshot hashed."""
    raw = pd.read_csv(io.BytesIO(body), dtype=str, keep_default_na=False)
    if list(raw.columns) != MARKET_COLUMNS:
        raise MarketDataError(f"quotes.csv header {list(raw.columns)} is not {MARKET_COLUMNS}")
    raw["snapshot_id"] = ""
    return hashlib.sha256(raw.to_csv(index=False).encode()).hexdigest()


def _verify_snapshot(data_dir: Path, snapshot_id: str, folder: Path, body: bytes) -> None:
    def bad(why):
        raise MarketDataError(f"snapshot {snapshot_id}: {why}")
    man = json.loads((folder / "manifest.json").read_text())
    sha = hashlib.sha256(body).hexdigest()
    if sha != man.get("sha256"):
        bad("quotes.csv does not match its manifest sha256")
    if man.get("snapshot_id") != snapshot_id:
        bad(f"manifest snapshot_id {man.get('snapshot_id')!r} is not the folder name")
    content = _content_hash(body)
    if content != man.get("content_hash"):
        bad("content hash of quotes.csv (snapshot_id blanked) does not match manifest content_hash")
    if not snapshot_id.endswith("-" + content[:8]):
        bad(f"content hash {content[:8]} does not match the hash8 in the snapshot id")
    idx = snapshot_root(data_dir) / "index.csv"
    rows = pd.read_csv(idx, dtype=str, keep_default_na=False) if idx.exists() else pd.DataFrame(columns=INDEX_COLUMNS)
    rows = rows[rows["snapshot_id"] == snapshot_id]
    if rows.empty:
        bad("not listed in index.csv")
    if set(rows["sha256"]) != {sha}:
        bad("quotes.csv sha256 does not match the index.csv row")


def read_market_snapshot(data_dir: Path, snapshot_id: str, verify: bool = True) -> pd.DataFrame:
    """One snapshot's rows (validate_market). verify=True (default) checks the body against the manifest sha256,
    the content hash in the id and manifest, and the index.csv sha256 (MarketDataError on any mismatch)."""
    if not SNAPSHOT_ID_RE.fullmatch(str(snapshot_id)):
        raise ValueError(f"bad snapshot id {snapshot_id!r}")
    folder = snapshot_root(data_dir) / snapshot_id
    body = (folder / "quotes.csv").read_bytes()
    if verify:
        _verify_snapshot(data_dir, snapshot_id, folder, body)
    df = pd.read_csv(io.BytesIO(body), dtype={c: str for c in MARKET_COLUMNS if c not in ("tenor_y", "value")},
                     keep_default_na=False)
    return validate_market(df)


def _cutoff(asof) -> str | None:
    """Upper bound on saved_utc as 'YYYY-MM-DDTHH:MM:SSZ' (end of day for a date)."""
    if asof is None:
        return None
    if isinstance(asof, dt.datetime):
        return utc_stamp(asof)
    if isinstance(asof, dt.date):
        return asof.strftime("%Y-%m-%d") + "T23:59:59Z"
    s = str(asof)
    if len(s) == 10:
        dt.date.fromisoformat(s)
        return s + "T23:59:59Z"
    return utc_stamp(dt.datetime.fromisoformat(s.replace("Z", "+00:00")))


def market_history(data_dir: Path, instrument: str | None = None, asof=None) -> pd.DataFrame:
    """Every quote known at `asof` (None = now): snapshots saved at or before the cutoff, quotes dated on or before
    it, one row per KEY (later snapshot wins). Raises FileNotFoundError when no snapshot qualifies."""
    ix = list_market_snapshots(data_dir)
    cut = _cutoff(asof)
    if cut is not None:
        ix = ix[ix["saved_utc"] <= cut]
    if ix.empty:
        raise FileNotFoundError(f"no market snapshot under {snapshot_root(data_dir)}"
                                + (f" saved on or before {cut}" if cut else "")
                                + "; import one (docs/runbooks/A-market-data.md)")
    frames = []
    for order, sid in enumerate(ix.sort_values("saved_utc", kind="mergesort")["snapshot_id"]):
        f = read_market_snapshot(data_dir, sid)
        if instrument:
            f = f[f["instrument"] == instrument]
        f = f.assign(_order=order)
        frames.append(f)
    out = pd.concat(frames, ignore_index=True) if frames else empty_market()
    if cut is not None:
        out = out[out["asof"] <= cut[:10]]
    out = out.sort_values("_order", kind="mergesort").drop_duplicates(KEY, keep="last")
    return out.drop(columns="_order").sort_values(KEY, kind="mergesort").reset_index(drop=True)


def _hard_hold(reason: str, ignore_stale: bool) -> bool:
    """True when a gate hold reason has a part other than flags (and, with ignore_stale, other than stale)."""
    skip = ("flag:", "stale:") if ignore_stale else ("flag:",)
    return any(x and not x.startswith(skip) for x in str(reason).split("; "))


def gated_market_history(data_dir: Path, instrument: str | None = None, asof=None, *, ignore_stale: bool = True,
                         params=None) -> pd.DataFrame:
    """market_history(data_dir, instrument, asof) without the rows the market gate held or the manual attestation
    check dropped (EQ-A-0121, HO-20261025-A-B-015 / HO-20261025-B-A-005; Team B's cds_curves.gated_cds_history calls
    it with instrument="cds").

    Every snapshot saved by `asof` is replayed through cds_export.gated_history (gate seeded only from rows that
    passed, SEC-A-003 L5). Then, on the same point-in-time view as market_history (later snapshot wins per KEY):
      - a series (SERIES, the key without the date) whose newest quote is held or unattested is dropped WHOLE: no
        back-fill from an older quote of that series;
      - any other held or unattested row is dropped on its own.
    Kept on purpose, for layer 2 to judge: holds whose only reasons are "stale:" (with ignore_stale, the default;
    layer 2's staleness rule is probability.market_term.max_age_days) and derived rows whatever the gate says (layer 2
    excludes and reports them), except a licence hold (SEC-A-013 P2-L1) or a SIMULATED hold (SEC-A-014 L3), which drops a derived row too. Flags never drop a row. FileNotFoundError when no snapshot qualifies, as
    market_history. attrs["issues"]: one line per drop, "market gate holds <iso> <source> <tenor>y <field> (quote
    <date>): <reason>; series not used" (the wording of Team B's interim cds_curves.gated_cds_history)."""
    from econquest.ingestion.market import cds_export
    ix = list_market_snapshots(data_dir)
    cut = _cutoff(asof)
    if cut is not None:
        ix = ix[ix["saved_utc"] <= cut]
    if ix.empty:
        raise FileNotFoundError(f"no market snapshot under {snapshot_root(data_dir)}"
                                + (f" saved on or before {cut}" if cut else "")
                                + "; import one (docs/runbooks/A-market-data.md)")
    frames = []
    for order, g in enumerate(cds_export.gated_history(data_dir, params=params, cutoff=cut)):
        f = g.rows.copy()
        der = f["derived"].astype(str).str.lower().isin(["true", "1"]) if "derived" in f else False
        hard = g.held.map(lambda r: bool(r) and _hard_hold(r, ignore_stale))
        # SEC-A-013 P2-L1: a licence hold (non-commercial / Yahoo) drops the row even when it is derived;
        # SEC-A-014 L3: so does a SIMULATED hold (vendor_sim_guard): no derived SIMULATED row outside a sandbox
        lic = g.held.map(lambda r: any(x.startswith(("licence:", "simulated:")) for x in str(r).split("; ")))
        f["_bad"] = (g.unattested != "") | (hard & ~der) | lic
        f["_why"] = [f"unattested: {u}" if u else "; ".join(x for x in str(h).split("; ") if x and not x.startswith(
            ("flag:", "stale:") if ignore_stale else ("flag:",))) for u, h in zip(g.unattested, g.held)]
        f["_order"] = order
        if instrument:
            f = f[f["instrument"] == instrument]
        frames.append(f)
    out = pd.concat(frames, ignore_index=True) if frames else empty_market().assign(_bad=False, _why="", _order=0)
    if cut is not None:
        out = out[out["asof"] <= cut[:10]]
    out = out.sort_values("_order", kind="mergesort").drop_duplicates(KEY, keep="last")
    issues: list[str] = []
    if len(out):
        newest = out.sort_values("asof", kind="mergesort").groupby(SERIES, sort=False).tail(1)
        dead = {tuple(r) for r in newest.loc[newest["_bad"], SERIES].astype(str).itertuples(index=False)}
        for _, r in newest[newest["_bad"]].sort_values(KEY, kind="mergesort").iterrows():
            issues.append(f"market gate holds {r['iso']} {r['source']} {float(r['tenor_y']):g}y {r['field']} "
                          f"(quote {r['asof']}): {r['_why']}; series not used")
        sid = out[SERIES].astype(str).apply(tuple, axis=1)
        older = out["_bad"] & ~sid.isin(dead)
        for _, r in out[older].sort_values(KEY, kind="mergesort").iterrows():
            issues.append(f"market gate holds {r['iso']} {r['source']} {float(r['tenor_y']):g}y {r['field']} "
                          f"(quote {r['asof']}): {r['_why']}; quote not used")
        out = out[~out["_bad"] & ~sid.isin(dead)]
    out = out.drop(columns=["_bad", "_why", "_order"]).sort_values(KEY, kind="mergesort").reset_index(drop=True)
    out.attrs["issues"] = issues
    return out


def latest_market(data_dir: Path, instrument: str | None = None, asof=None) -> pd.DataFrame:
    """The latest quote per series (KEY without asof) known at `asof`: market_history reduced to the newest quote
    date of each series. Point-in-time: a snapshot saved after `asof` is never used."""
    h = market_history(data_dir, instrument=instrument, asof=asof)
    if h.empty:
        return h
    return (h.sort_values("asof", kind="mergesort").groupby(SERIES, as_index=False, sort=False).last()[MARKET_COLUMNS]
            .sort_values(KEY, kind="mergesort").reset_index(drop=True))
