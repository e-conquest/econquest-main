"""Vendor-neutral market data contract (EQ-A-0029, epic A7; contract change to Team B, EQ-B-0048/0049).

One long table, one row per quote, exactly MARKET_COLUMNS:

    asof           quote date "YYYY-MM-DD" (the market close the value belongs to, not when it was pulled)
    instrument     cds | govt_yield | embi_spread | fx_spot | fx_forward | policy_rate | ois | swap
    iso            ISO 3166-1 alpha-3 of the sovereign; blank only for currency-level quotes (ois, swap, fx, policy
                   rate of a currency union). Required for cds, govt_yield and embi_spread.
    currency       ISO 4217 code: CDS contract currency, bond/curve currency, or for FX the non-USD currency
    tenor_y        float years, 0 for spot (fx_spot, policy_rate must be 0; cds/govt_yield/fx_forward/ois/swap > 0
                   except a cds recovery row, which may be 0)
    field          spread_bp | yield_pct | outright | points | recovery | upfront_pct | price (allowed per instrument:
                   INSTRUMENT_FIELDS)
    value          finite float (recovery a fraction in [0, 1])
    unit           FIELD_UNITS: bp, pct, fraction, pct_of_par; FX outright and points "CCY/USD" = units of CCY per 1
                   USD. Points are stored as forward minus spot in outright units (importers apply the vendor scale).
    doc_clause     CDS documentation clause, e.g. CR14 / MR14 / MM14 / XR14; blank allowed for cds when unknown,
                   always blank for other instruments
    source         lowercase vendor or public source slug: bloomberg, lseg, markit, manual, ...
    vendor_ticker  the vendor's identifier (Bloomberg ticker, RIC) or blank
    licence        licence under which the value may be used; required, not a placeholder (none/pending/...);
                   "n/a (hand-entered)" only with source "manual"
    derived        bool: true when computed by econquest rather than quoted (e.g. points from two outrights)
    snapshot_id    the snapshot folder the row was saved in ("" before save_market_snapshot)
    retrieved_utc  "YYYY-MM-DDTHH:MM:SSZ" when the value was pulled or typed ("" before save: filled with save time)

Key (no duplicates): KEY = (asof, instrument, iso, currency, tenor_y, field, doc_clause, source).
Text cells are refused, not escaped, when they start with = + - @ TAB CR (after any leading whitespace) or carry
control characters.
Storage and point-in-time reads: market/store.py. The engine adapters: to_cds_quotes (data/cds_quotes.csv, engine/cds.py)
and to_cds_snapshots (data/market/cds_snapshots.csv, engine/cds_curves.py, HO-20261023-B-A-009) below.
"""
from __future__ import annotations

import math
import re
from pathlib import Path

import pandas as pd

MARKET_COLUMNS = ["asof", "instrument", "iso", "currency", "tenor_y", "field", "value", "unit", "doc_clause", "source",
                  "vendor_ticker", "licence", "derived", "snapshot_id", "retrieved_utc"]
KEY = ["asof", "instrument", "iso", "currency", "tenor_y", "field", "doc_clause", "source"]
SERIES = [c for c in KEY if c != "asof"]                 # one time series = the key without the date
INSTRUMENTS = ("cds", "govt_yield", "embi_spread", "fx_spot", "fx_forward", "policy_rate", "ois", "swap")
FIELDS = ("spread_bp", "yield_pct", "outright", "points", "recovery", "upfront_pct", "price")
INSTRUMENT_FIELDS = {
    "cds": ("spread_bp", "recovery", "upfront_pct"),
    "govt_yield": ("yield_pct", "price", "spread_bp"),     # spread_bp: vendor spread vs the benchmark (UST/Bund)
    "embi_spread": ("spread_bp", "yield_pct"),
    "fx_spot": ("outright",),
    "fx_forward": ("outright", "points"),
    "policy_rate": ("yield_pct",),
    "ois": ("yield_pct",),
    "swap": ("yield_pct",),
}
FIELD_UNITS = {"spread_bp": "bp", "yield_pct": "pct", "recovery": "fraction", "upfront_pct": "pct",
               "price": "pct_of_par"}                    # outright / points: FX_UNIT_RE
ISO_REQUIRED = ("cds", "govt_yield", "embi_spread")
SPOT_ONLY = ("fx_spot", "policy_rate")
TENOR_REQUIRED = ("cds", "govt_yield", "fx_forward", "ois", "swap")
MANUAL_SOURCE, MANUAL_LICENCE = "manual", "n/a (hand-entered)"
CDS_QUOTES_COLUMNS = ["country", "date", "tenor_y", "spread_bp", "recovery", "source"]   # engine/cds.py reads these

ISO3_RE = re.compile(r"[A-Z]{3}")
CCY_RE = re.compile(r"[A-Z]{3}")
FX_UNIT_RE = re.compile(r"[A-Z]{3}/[A-Z]{3}")
DATE_RE = re.compile(r"\d{4}-\d{2}-\d{2}")
DOC_CLAUSE_RE = re.compile(r"[A-Z]{2}\d{2}")
SOURCE_RE = re.compile(r"[a-z][a-z0-9_]{0,31}")
SNAPSHOT_ID_RE = re.compile(r"\d{4}-\d{2}-\d{2}T\d{6}Z-[0-9a-f]{8}")
RETRIEVED_RE = re.compile(r"\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z")
FORMULA_LEAD = ("=", "+", "-", "@", "\t", "\r")
LICENCE_PLACEHOLDERS = {"", "none", "pending", "tbd", "todo", "unknown", "null", "nan", "?", "n/a", "na", "-",
                        "verify", "licence", "license"}
MAX_TEXT = 128
TEXT_COLUMNS = ("asof", "instrument", "iso", "currency", "unit", "doc_clause", "source", "vendor_ticker", "licence",
                "snapshot_id", "retrieved_utc")
_TRUE, _FALSE = {"true", "1", "yes", "y", "t"}, {"false", "0", "no", "n", "f", ""}


class MarketDataError(ValueError):
    """A market table breaks the contract. The message lists every problem found."""


def text_problem(v) -> str:
    """'' when a text cell is safe to store and to open in a spreadsheet, else the reason."""
    if not isinstance(v, str):
        return "not text"
    if v.startswith(FORMULA_LEAD) or v.lstrip().startswith(FORMULA_LEAD):   # SEC-A-003 L2: " =1+1" too
        return "starts with a formula character (= + - @ TAB CR), leading whitespace ignored"
    if any(ord(c) < 32 or ord(c) == 127 for c in v):
        return "contains control characters"
    if len(v) > MAX_TEXT:
        return f"longer than {MAX_TEXT} characters"
    return ""


def licence_problem(lic, source: str = "") -> str:
    """'' when `lic` is an acceptable licence string for `source`, else the reason."""
    why = text_problem(lic)
    if why:
        return why
    s = lic.strip().casefold()
    if s in LICENCE_PLACEHOLDERS or s.startswith(("pending", "none", "tbd", "todo")):
        return f"licence {lic!r} is empty or a placeholder"
    if s.startswith("n/a") and source != MANUAL_SOURCE:
        return f"licence {lic!r} is only allowed for source {MANUAL_SOURCE!r}"
    return ""


def _bool(v):
    if isinstance(v, bool):
        return v
    if v is None or (isinstance(v, float) and math.isnan(v)):
        return False
    s = str(v).strip().casefold()
    if s in _TRUE:
        return True
    if s in _FALSE:
        return False
    return None


def validate_market(df: pd.DataFrame) -> pd.DataFrame:
    """Check the contract and return df[MARKET_COLUMNS] normalised (text as str, tenor_y and value float, derived
    bool), sorted by KEY. Raises MarketDataError listing every problem (first few examples of each)."""
    if not isinstance(df, pd.DataFrame):
        raise MarketDataError("market data must be a pandas DataFrame")
    missing = [c for c in MARKET_COLUMNS if c not in df.columns]
    if missing:
        raise MarketDataError(f"missing columns: {missing}")
    out = df[MARKET_COLUMNS].copy().reset_index(drop=True)
    problems: list[str] = []

    def bad(mask, what, cols):
        if mask.any():
            problems.append(f"{what}: {out.loc[mask, cols].drop_duplicates().head(5).values.tolist()}")

    for c in TEXT_COLUMNS:
        out[c] = out[c].map(lambda v: "" if v is None or (isinstance(v, float) and math.isnan(v)) else str(v))
        out[c] = out[c].str.strip() if c != "licence" else out[c]
        tp = out[c].map(text_problem)
        bad(tp != "", f"{c} unsafe text", [c])
    dates = pd.to_datetime(out["asof"], format="%Y-%m-%d", errors="coerce")
    bad(~out["asof"].str.fullmatch(DATE_RE) | dates.isna(), "asof not a YYYY-MM-DD date", ["asof"])
    bad(~out["instrument"].isin(INSTRUMENTS), f"instrument not in {INSTRUMENTS}", ["instrument"])
    out["field"] = out["field"].map(lambda v: "" if v is None or (isinstance(v, float) and math.isnan(v)) else str(v).strip())
    bad(~out["field"].isin(FIELDS), f"field not in {FIELDS}", ["field"])
    combo = [f in INSTRUMENT_FIELDS.get(i, ()) for i, f in zip(out["instrument"], out["field"])]
    bad(~pd.Series(combo, dtype=bool) & out["instrument"].isin(INSTRUMENTS) & out["field"].isin(FIELDS),
        "field not allowed for instrument (INSTRUMENT_FIELDS)", ["instrument", "field"])
    iso_ok = out["iso"].str.fullmatch(ISO3_RE) | (out["iso"] == "")
    bad(~iso_ok, "iso not ISO3 (or blank)", ["iso"])
    bad(out["instrument"].isin(ISO_REQUIRED) & (out["iso"] == ""), f"iso required for {ISO_REQUIRED}", ["instrument"])
    bad(~out["currency"].str.fullmatch(CCY_RE), "currency not ISO 4217", ["currency"])
    tenor = pd.to_numeric(out["tenor_y"], errors="coerce").astype(float)
    t_ok = tenor.map(lambda x: math.isfinite(x) and 0 <= x <= 100).astype(bool)
    bad(~t_ok, "tenor_y not a number in [0, 100]", ["tenor_y"])
    tenor = tenor.where(t_ok, 0.0).astype(float)
    bad(out["instrument"].isin(SPOT_ONLY) & (tenor != 0), f"tenor_y must be 0 for {SPOT_ONLY}", ["instrument", "tenor_y"])
    need = out["instrument"].isin(TENOR_REQUIRED) & ~((out["instrument"] == "cds") & (out["field"] == "recovery"))
    bad(need & (tenor <= 0), f"tenor_y must be > 0 for {TENOR_REQUIRED}", ["instrument", "field", "tenor_y"])
    out["tenor_y"] = tenor
    vals = pd.to_numeric(out["value"], errors="coerce").astype(float)
    v_ok = vals.map(math.isfinite).astype(bool)
    bad(~v_ok, "value missing, non-numeric or non-finite", ["instrument", "iso", "field", "value"])
    vals = vals.where(v_ok, 0.0).astype(float)
    bad((out["field"] == "recovery") & ((vals < 0) | (vals > 1)), "recovery must be a fraction in [0, 1]", ["iso", "value"])
    out["value"] = vals
    exp = out["field"].map(FIELD_UNITS)
    fx = out["field"].isin(("outright", "points"))
    bad(~fx & exp.notna() & (out["unit"] != exp), f"unit does not match field ({FIELD_UNITS})", ["field", "unit"])
    bad(fx & ~out["unit"].str.fullmatch(FX_UNIT_RE), "FX unit must be 'CCY/USD' style", ["field", "unit"])
    dc_ok = (out["doc_clause"] == "") | ((out["instrument"] == "cds") & out["doc_clause"].str.fullmatch(DOC_CLAUSE_RE))
    bad(~dc_ok, "doc_clause must be like CR14 and only on cds rows", ["instrument", "doc_clause"])
    bad(~out["source"].str.fullmatch(SOURCE_RE), "source not a lowercase slug", ["source"])
    lp = pd.Series([licence_problem(lic, s) for lic, s in zip(out["licence"], out["source"])], dtype=str)
    bad(lp != "", "licence missing, placeholder or unsafe", ["source", "licence"])
    der = out["derived"].map(_bool)
    bad(der.isna(), "derived not a boolean", ["derived"])
    out["derived"] = der.fillna(False).astype(bool)
    bad((out["snapshot_id"] != "") & ~out["snapshot_id"].str.fullmatch(SNAPSHOT_ID_RE), "snapshot_id malformed",
        ["snapshot_id"])
    bad((out["retrieved_utc"] != "") & ~out["retrieved_utc"].str.fullmatch(RETRIEVED_RE),
        "retrieved_utc not YYYY-MM-DDTHH:MM:SSZ", ["retrieved_utc"])
    late = (out["retrieved_utc"] != "") & out["retrieved_utc"].str.fullmatch(RETRIEVED_RE) & dates.notna()
    late &= out["asof"] > out["retrieved_utc"].str[:10]
    bad(late, "asof after retrieved_utc (a quote from the future)", ["asof", "retrieved_utc"])
    dup = out.duplicated(KEY, keep=False)
    bad(dup, f"duplicate key {KEY}", KEY)
    if problems:
        raise MarketDataError("; ".join(problems))
    return out.sort_values(KEY, kind="mergesort").reset_index(drop=True)


def empty_market() -> pd.DataFrame:
    return pd.DataFrame({c: pd.Series(dtype=float if c in ("tenor_y", "value") else bool if c == "derived" else str)
                         for c in MARKET_COLUMNS})


def _country_names(country_names) -> dict:
    if country_names is None:
        from econquest.ingestion.universe import load_universe_proposal
        u = load_universe_proposal()
        return dict(zip(u["iso3"], u["name"]))
    if isinstance(country_names, (str, Path)):
        c = pd.read_csv(country_names, dtype=str, keep_default_na=False)
        return dict(zip(c["iso"], c["country"]))
    if isinstance(country_names, pd.DataFrame):
        return dict(zip(country_names["iso"], country_names["country"]))
    return dict(country_names)


DEFAULT_DOC_CLAUSES = ("CR14", "CR", "MR14", "MM14", "XR14", "")
DEFAULT_SOURCE_ORDER = ("bloomberg", "lseg", "markit")


def to_cds_quotes(df: pd.DataFrame, country_names=None, currency: str | None = "USD",
                  doc_clauses=DEFAULT_DOC_CLAUSES, source_order=DEFAULT_SOURCE_ORDER) -> pd.DataFrame:
    """The engine's data/cds_quotes.csv frame (CDS_QUOTES_COLUMNS: country, date, tenor_y, spread_bp, recovery,
    source) from market rows, so engine/cds.py reads vendor or manual quotes unchanged.

    country is the desk country name (data/countries.csv `country`; ISO3 -> name from `country_names`: dict, a
    countries.csv path or frame, default data/panel/universe_proposal.csv). An ISO with no name raises
    MarketDataError, never guessed. One row per (country, date, tenor): contract currency `currency` (None = any),
    the first doc clause available in `doc_clauses`, then the first source in `source_order` (sources not listed
    come after, alphabetically, and 'manual' last unless listed). recovery is the cds 'recovery' row of the same iso/date/source/doc clause (tenor
    equal or 0), blank when none (the engine then uses its default). source reads "<source> <snapshot_id>
    [<vendor_ticker>]" so the audit trail names the snapshot."""
    m = validate_market(df)
    m = m[(m["instrument"] == "cds")]
    if currency:
        m = m[m["currency"] == currency]
    spreads, rec = m[m["field"] == "spread_bp"].copy(), m[m["field"] == "recovery"]
    if spreads.empty:
        return pd.DataFrame(columns=CDS_QUOTES_COLUMNS)
    names = _country_names(country_names)
    unknown = sorted(set(spreads["iso"]) - set(names))
    if unknown:
        raise MarketDataError(f"no country name for ISO3 {unknown}: add them to countries.csv / the universe list")
    dc_rank = {d: i for i, d in enumerate(doc_clauses)}
    src_rank = {s: i for i, s in enumerate(source_order)}
    spreads["_dc"] = spreads["doc_clause"].map(lambda d: dc_rank.get(d, len(dc_rank)))
    spreads["_src"] = spreads["source"].map(lambda s: src_rank.get(s, len(src_rank) + (s == MANUAL_SOURCE)))
    spreads = spreads.sort_values(["iso", "asof", "tenor_y", "_dc", "_src", "source"], kind="mergesort")
    best = spreads.groupby(["iso", "asof", "tenor_y"], as_index=False, sort=True).first()
    rows = []
    for r in best.itertuples(index=False):
        rr = rec[(rec["iso"] == r.iso) & (rec["asof"] == r.asof) & (rec["source"] == r.source)
                 & (rec["doc_clause"] == r.doc_clause) & rec["tenor_y"].isin([r.tenor_y, 0.0])]
        recovery = float(rr.sort_values("tenor_y", ascending=False)["value"].iloc[0]) if len(rr) else float("nan")
        src = " ".join(x for x in (r.source, r.snapshot_id, f"[{r.vendor_ticker}]" if r.vendor_ticker else "") if x)
        rows.append({"country": names[r.iso], "date": r.asof, "tenor_y": float(r.tenor_y), "spread_bp": float(r.value),
                     "recovery": recovery, "source": src})
    return pd.DataFrame(rows, columns=CDS_QUOTES_COLUMNS)


# HO-20261023-B-A-009 / EQ-A-0034: Team B's CDS curve snapshot contract (engine/cds_curves.py SNAPSHOT_COLUMNS, pinned
# by tests/test_market_schema.py). Written append-only to data/market/cds_snapshots.csv only by the gated export
# (cds_export.export_gated_cds_snapshots, SEC-A-003 M1).
CDS_SNAPSHOT_COLUMNS = ["snapshot_id", "as_of", "iso3", "instrument", "tenor_y", "quote_type", "value", "running_bp",
                        "currency", "doc_clause", "recovery", "source", "licence", "vintage"]
CDS_QUOTE_TYPES = {"spread_bp": "par_spread", "upfront_pct": "upfront"}


def to_cds_snapshots(df: pd.DataFrame, currency: str | None = "USD", doc_clauses=DEFAULT_DOC_CLAUSES,
                     source_order=DEFAULT_SOURCE_ORDER) -> pd.DataFrame:
    """Team B's CDS curve snapshot frame (CDS_SNAPSHOT_COLUMNS, one row per quote) from saved market rows.

    Only `cds` rows with field spread_bp (quote_type par_spread, value in bp) or upfront_pct (quote_type upfront,
    value in points = % of notional as stored, positive = paid by the protection buyer) are used, in contract
    currency `currency` (None = any). Rows must come from a saved snapshot (non-blank snapshot_id; raises
    MarketDataError otherwise), so every output row is point-in-time.

    One capture = one curve: per (market snapshot, iso, asof) the (doc clause, source) pair ranked first by
    `doc_clauses` then `source_order` (as to_cds_quotes; 'manual' last unless listed) is kept whole, so a curve never
    mixes sources or clauses. Its snapshot_id is "<market snapshot_id>:<iso>:<asof>:<source>:<currency>:<doc_clause or ->",
    which sorts by save time, so a later market snapshot supersedes an earlier one of the same as_of in
    cds_curves.snapshot_as_of. When a tenor has both a par spread and an upfront quote, the par spread is kept.

    Fields with no source in MARKET_COLUMNS are left blank, never invented: running_bp (MARKET_COLUMNS has no running
    coupon, so an upfront row reaches cds_curves without one and is reported there). recovery is the cds recovery row
    of the same capture (tenor equal or 0), blank when none. source is the market source slug, licence as stored,
    vintage the date of retrieved_utc (when the value was pulled or typed)."""
    m = validate_market(df)
    m = m[(m["instrument"] == "cds") & m["field"].isin(list(CDS_QUOTE_TYPES) + ["recovery"])]
    if currency:
        m = m[m["currency"] == currency]
    if (m["snapshot_id"] == "").any():
        raise MarketDataError("cds rows without snapshot_id: save them with store.save_market_snapshot first "
                              "(cds_snapshots.csv only carries point-in-time, saved quotes)")
    quotes, rec = m[m["field"].isin(list(CDS_QUOTE_TYPES))].copy(), m[m["field"] == "recovery"]
    if quotes.empty:
        return pd.DataFrame(columns=CDS_SNAPSHOT_COLUMNS)
    dc_rank = {d: i for i, d in enumerate(doc_clauses)}
    src_rank = {s: i for i, s in enumerate(source_order)}
    cap = ["snapshot_id", "iso", "asof"]
    caps = quotes[cap + ["currency", "doc_clause", "source"]].drop_duplicates()
    caps = caps.assign(_dc=caps["doc_clause"].map(lambda d: dc_rank.get(d, len(dc_rank))),
                       _src=caps["source"].map(lambda s: src_rank.get(s, len(src_rank) + (s == MANUAL_SOURCE))))
    best = (caps.sort_values(cap + ["_dc", "_src", "source", "doc_clause", "currency"], kind="mergesort")
            .groupby(cap, as_index=False, sort=True).first())
    rows = []
    for c in best.itertuples(index=False):
        sel = ((quotes["snapshot_id"] == c.snapshot_id) & (quotes["iso"] == c.iso) & (quotes["asof"] == c.asof)
               & (quotes["currency"] == c.currency) & (quotes["doc_clause"] == c.doc_clause) & (quotes["source"] == c.source))
        g = quotes[sel].assign(_par=lambda x: (x["field"] == "spread_bp").astype(int))
        g = g.sort_values(["tenor_y", "_par"], kind="mergesort").drop_duplicates("tenor_y", keep="last")
        rr = rec[(rec["snapshot_id"] == c.snapshot_id) & (rec["iso"] == c.iso) & (rec["asof"] == c.asof)
                 & (rec["currency"] == c.currency) & (rec["doc_clause"] == c.doc_clause) & (rec["source"] == c.source)]
        sid = f"{c.snapshot_id}:{c.iso}:{c.asof}:{c.source}:{c.currency}:{c.doc_clause or '-'}"
        for r in g.itertuples(index=False):
            rt = rr[rr["tenor_y"].isin([r.tenor_y, 0.0])].sort_values("tenor_y", ascending=False)
            rows.append({"snapshot_id": sid, "as_of": r.asof, "iso3": r.iso, "instrument": "CDS", "tenor_y": float(r.tenor_y),
                         "quote_type": CDS_QUOTE_TYPES[r.field], "value": float(r.value), "running_bp": float("nan"),
                         "currency": r.currency, "doc_clause": r.doc_clause,
                         "recovery": float(rt["value"].iloc[0]) if len(rt) else float("nan"), "source": r.source,
                         "licence": r.licence, "vintage": r.retrieved_utc[:10]})
    return pd.DataFrame(rows, columns=CDS_SNAPSHOT_COLUMNS)
