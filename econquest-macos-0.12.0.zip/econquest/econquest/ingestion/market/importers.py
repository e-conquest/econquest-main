"""Vendor CSV importers (EQ-A-0029): Bloomberg and LSEG/Refinitiv exports -> MARKET_COLUMNS rows.

No vendor API is called: an analyst exports a sheet on a licensed terminal, saves it as CSV and runs
`import_vendor_csv(path, profile, licence)`; `import_and_save` also writes a snapshot (store.save_market_snapshot).

Layouts recognised (header row found within the first HEADER_SCAN rows, so a few title lines above it are fine):
  long   one row per (identifier, date[, field]) with a value column. Identifier column: Bloomberg 'Ticker' /
         'Security'; LSEG 'RIC' / 'Instrument' / 'Identifier'. Value column: the mapping's vendor_field when that
         column exists, else the profile's first default value column present (Bloomberg PX_LAST, PX_MID, Value;
         LSEG CLOSE, Close Price, TRDPRC_1, MID_PRICE, Value). A 'Field' column, when present, names the field.
  wide   'Date' in the first column, one column per ticker/RIC (value field = profile default, e.g. PX_LAST).
  bdh    Bloomberg BDH side-by-side blocks: a row of tickers above a row of (Date, <FIELD>) column pairs.

Mapping: every identifier is looked up in an editable mapping CSV (MAP_COLUMNS; default data/live/market/
ticker_map.csv, created from ticker_map_template.csv by ensure_ticker_map) by (source, vendor_ticker,
vendor_field), with a blank vendor_field matching any field. An identifier with no mapping row, or whose row is not
status 'verified', raises MarketDataError listing them all: never guessed. `scale` multiplies the vendor number
(e.g. 0.0001 for FX points quoted in pips).

Safety: file size cap (max_bytes), row cap, any cell starting with = + @ (or - when not a number) refused, licence
required and recorded on every row, dates parsed with the profile's explicit formats only (no dd/mm guessing).
Vendor missing-value markers (#N/A ..., N.A., blank) are skipped and counted in result.attrs['skipped'].
"""
from __future__ import annotations

import csv
import datetime as dt
import io
import math
import re
import shutil
from pathlib import Path

import pandas as pd

from econquest.ingestion.market.schema import FORMULA_LEAD, MARKET_COLUMNS, MarketDataError, licence_problem, validate_market
from econquest.ingestion.market.store import market_root, save_market_snapshot, utc_stamp

MAP_COLUMNS = ["source", "vendor_ticker", "vendor_field", "instrument", "iso", "currency", "tenor_y", "field", "unit",
               "doc_clause", "scale", "status", "note"]
TEMPLATE = Path(__file__).with_name("ticker_map_template.csv")
DEFAULT_MAX_BYTES = 20 * 1024 * 1024
MAX_ROWS = 500_000
HEADER_SCAN = 25
MISSING = re.compile(r"(#N/?A.*|N\.?A\.?|NaN|null|--|)", re.IGNORECASE)
PROFILES = {
    "bloomberg": {"source": "bloomberg", "id_cols": ("ticker", "security", "security name", "bbg ticker"),
                  "date_cols": ("date", "dates"), "field_cols": ("field", "fields"),
                  "value_cols": ("PX_LAST", "PX_MID", "Value", "Last Price"),
                  "date_formats": ("%Y-%m-%d", "%m/%d/%Y", "%m/%d/%y", "%Y%m%d")},
    "lseg": {"source": "lseg", "id_cols": ("ric", "instrument", "identifier", "universe"),
             "date_cols": ("date", "date time", "timestamp"), "field_cols": ("field",),
             "value_cols": ("CLOSE", "Close Price", "TRDPRC_1", "MID_PRICE", "PRIMACT_1", "Value"),
             "date_formats": ("%Y-%m-%d", "%Y-%m-%dT%H:%M:%SZ", "%Y-%m-%d %H:%M:%S", "%d-%b-%Y", "%d-%b-%y",
                              "%Y%m%d")},
}


def ensure_ticker_map(data_dir: Path) -> Path:
    """Copy the template to data/live/market/ticker_map.csv when it does not exist yet; never overwrites."""
    p = market_root(data_dir) / "ticker_map.csv"
    if not p.exists():
        p.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(TEMPLATE, p)
    return p


def _norm_id(s: str) -> str:
    return " ".join(str(s).split()).casefold()


def load_ticker_map(mapping) -> pd.DataFrame:
    """The mapping as a frame with MAP_COLUMNS (str). `mapping` is a path or a DataFrame."""
    m = mapping if isinstance(mapping, pd.DataFrame) else pd.read_csv(mapping, dtype=str, keep_default_na=False)
    missing = [c for c in MAP_COLUMNS if c not in m.columns]
    if missing:
        raise MarketDataError(f"ticker map missing columns {missing}")
    m = m[MAP_COLUMNS].fillna("").astype(str).apply(lambda c: c.str.strip())
    dup = m.assign(_id=m["vendor_ticker"].map(_norm_id), _f=m["vendor_field"].str.casefold()).duplicated(
        ["source", "_id", "_f"], keep=False)
    if dup.any():
        raise MarketDataError(f"ticker map has duplicate rows: {m.loc[dup, ['source', 'vendor_ticker', 'vendor_field']].values.tolist()[:5]}")
    return m


def _read_rows(path: Path, max_bytes: int) -> list[list[str]]:
    path = Path(path)
    size = path.stat().st_size
    if size > max_bytes:
        raise MarketDataError(f"{path.name}: {size} bytes exceeds the cap of {max_bytes}")
    raw = path.read_bytes()
    for enc in ("utf-8-sig", "cp1252"):
        try:
            text = raw.decode(enc)
            break
        except UnicodeDecodeError:
            continue
    else:                                                # pragma: no cover - cp1252 decodes almost anything
        raise MarketDataError(f"{path.name}: not UTF-8 or Windows-1252 text")
    try:
        rows = list(csv.reader(io.StringIO(text)))
    except csv.Error as e:
        raise MarketDataError(f"{path.name}: not a CSV file ({e})") from None
    if len(rows) > MAX_ROWS:
        raise MarketDataError(f"{path.name}: more than {MAX_ROWS} rows")
    return [[c.strip() for c in r] for r in rows]


def _is_num(s: str) -> bool:
    try:
        return math.isfinite(float(s.replace(",", "")))
    except ValueError:
        return False


def _guard_cells(rows: list[list[str]], name: str) -> None:
    """Refuse the file when any cell looks like a spreadsheet formula (= + - @ TAB CR lead and not a number) or holds
    control characters: such a cell would reach the snapshot, the ledger or Sheets."""
    bad = [(i + 1, c[:40]) for i, r in enumerate(rows) for c in r
           if c and not _is_num(c) and (c.startswith(FORMULA_LEAD) or any(ord(ch) < 32 or ord(ch) == 127 for ch in c))]
    if bad:
        raise MarketDataError(f"{name}: formula-like or control-character cells refused (row, cell): {bad[:10]}")


def _parse_date(s: str, formats) -> str | None:
    for f in formats:
        try:
            return dt.datetime.strptime(s, f).strftime("%Y-%m-%d")
        except ValueError:
            continue
    return None


def _parse_value(s: str) -> float | None:
    if MISSING.fullmatch(s.strip()):
        return None
    try:
        v = float(s.replace(",", ""))
    except ValueError:
        raise MarketDataError(f"value {s[:40]!r} is not a number") from None
    if not math.isfinite(v):
        raise MarketDataError(f"value {s[:40]!r} is not finite")
    return v


def _records(rows: list[list[str]], prof: dict, fields: set, name: str) -> list[tuple[str, str, str, str]]:
    """(identifier, field, raw date, raw value) from any recognised layout. `fields` are the casefolded value-column
    names to read (profile defaults, the ticker map's vendor_field values, 'value')."""
    lower = [[c.casefold() for c in r] for r in rows]
    for h, hdr in enumerate(lower[:HEADER_SCAN]):
        if h > 0 and len(hdr) >= 2 and hdr[0] in prof["date_cols"] and hdr[1] in fields and rows[h - 1][:1] \
                and rows[h - 1][0]:                      # bdh: tickers above (Date, FIELD) pairs
            above, out = rows[h - 1], []
            for i in range(0, len(hdr) - 1, 2):
                tick = above[i] if i < len(above) else ""
                if not tick or hdr[i] not in prof["date_cols"]:
                    continue
                out += [(tick, rows[h][i + 1], r[i], r[i + 1]) for r in rows[h + 1:] if i + 1 < len(r) and r[i]]
            return out
        ids = [i for i, c in enumerate(hdr) if c in prof["id_cols"]]
        dts = [i for i, c in enumerate(hdr) if c in prof["date_cols"]]
        if ids and dts:                                  # long
            fld = [i for i, c in enumerate(hdr) if c in prof["field_cols"]]
            vals = [i for i, c in enumerate(hdr) if c in fields and i not in ids + dts + fld]
            if not vals:
                raise MarketDataError(f"{name}: no value column among {sorted(fields)}")
            out = []
            for r in rows[h + 1:]:
                if not any(r):
                    continue
                r = r + [""] * (len(hdr) - len(r))
                for v in vals:
                    field = r[fld[0]] if fld and hdr[v] in ("value", "values") else rows[h][v]
                    out.append((r[ids[0]], field, r[dts[0]], r[v]))
            return out
        if dts == [0] and len(hdr) >= 2 and not ids:     # wide: Date + one column per identifier
            field = prof["value_cols"][0]
            return [(rows[h][i], field, r[0], r[i]) for r in rows[h + 1:] for i in range(1, min(len(r), len(hdr)))
                    if rows[h][i] and r[0]]
    raise MarketDataError(f"{name}: no recognisable {prof['source']} header (identifier + date columns, a Date + "
                          f"ticker header, or BDH ticker/Date pairs) in the first {HEADER_SCAN} rows")


def import_vendor_csv(path, profile: str, licence: str, now: dt.datetime | None = None, *, mapping=None,
                      data_dir: Path | None = None, max_bytes: int = DEFAULT_MAX_BYTES) -> pd.DataFrame:
    """Parse one vendor export into validated MARKET_COLUMNS rows (snapshot_id blank, retrieved_utc = now).
    `profile` is 'bloomberg' or 'lseg'; `licence` is the licence the data is used under (required, recorded on
    every row). `mapping` is a ticker map path or frame; default data_dir/live/market/ticker_map.csv."""
    if profile not in PROFILES:
        raise MarketDataError(f"profile must be one of {sorted(PROFILES)}, got {profile!r}")
    prof = PROFILES[profile]
    why = licence_problem(licence, prof["source"])
    if why:
        raise MarketDataError(f"licence refused: {why}")
    if mapping is None:
        if data_dir is None:
            raise MarketDataError("pass mapping= or data_dir= (ticker map data/live/market/ticker_map.csv)")
        mapping = market_root(data_dir) / "ticker_map.csv"
        if not mapping.exists():
            raise MarketDataError(f"no ticker map at {mapping}; run ensure_ticker_map(data_dir) and verify it")
    tmap = load_ticker_map(mapping)
    tmap = tmap[tmap["source"] == prof["source"]]
    name = Path(path).name
    rows = _read_rows(Path(path), max_bytes)
    _guard_cells(rows, name)
    fields = {c.casefold() for c in prof["value_cols"]} | {f.casefold() for f in tmap["vendor_field"] if f} | {"value"}
    recs = _records(rows, prof, fields, name)
    by_id: dict = {}
    for r in tmap.itertuples(index=False):
        by_id.setdefault(_norm_id(r.vendor_ticker), {})[r.vendor_field.casefold()] = r
    unmapped, unverified, bad_dates, bad_vals, out = set(), set(), set(), [], []
    skipped = 0
    stamp = utc_stamp(now)
    for ident, field, d, v in recs:
        cand = by_id.get(_norm_id(ident), {})
        m = cand.get(field.casefold()) or cand.get("")
        if m is None:
            unmapped.add(f"{ident} [{field}]" if field else ident)
            continue
        if m.status.casefold() != "verified":
            unverified.add(f"{ident} (status {m.status or 'blank'})")
            continue
        asof = _parse_date(d, prof["date_formats"])
        if asof is None:
            if MISSING.fullmatch(d):
                skipped += 1
                continue
            bad_dates.add(d[:20])
            continue
        try:
            val = _parse_value(v)
        except MarketDataError as e:
            bad_vals.append(f"{ident} {d}: {e}")
            continue
        if val is None:
            skipped += 1
            continue
        scale = float(m.scale) if m.scale else 1.0
        out.append({"asof": asof, "instrument": m.instrument, "iso": m.iso, "currency": m.currency,
                    "tenor_y": m.tenor_y, "field": m.field, "value": val * scale, "unit": m.unit,
                    "doc_clause": m.doc_clause, "source": prof["source"], "vendor_ticker": ident, "licence": licence,
                    "derived": False, "snapshot_id": "",
                    "retrieved_utc": stamp})
    problems = []
    if unmapped:
        problems.append(f"unmapped {profile} identifiers (add them to the ticker map, status verified): "
                        f"{sorted(unmapped)}")
    if unverified:
        problems.append(f"ticker map rows not verified (check against the export and set status=verified): "
                        f"{sorted(unverified)}")
    if bad_dates:
        problems.append(f"dates not in the {profile} formats {prof['date_formats']}: {sorted(bad_dates)[:10]}")
    if bad_vals:
        problems.append(f"bad values: {bad_vals[:10]}")
    if problems:
        raise MarketDataError(f"{name}: " + "; ".join(problems))
    if not out:
        raise MarketDataError(f"{name}: no quotes found")
    df = validate_market(pd.DataFrame(out, columns=MARKET_COLUMNS))
    df.attrs.update({"skipped": skipped, "file": name, "profile": profile})
    return df


def import_and_save(data_dir: Path, path, profile: str, licence: str, now: dt.datetime | None = None, *,
                    mapping=None, max_bytes: int = DEFAULT_MAX_BYTES) -> Path:
    """import_vendor_csv + save_market_snapshot; the manifest records the file name, profile and skipped count."""
    df = import_vendor_csv(path, profile, licence, now, mapping=mapping, data_dir=data_dir, max_bytes=max_bytes)
    prov = {"importer": f"{profile} csv", "file": Path(path).name, "skipped_missing": df.attrs.get("skipped", 0)}
    return save_market_snapshot(data_dir, df, now=now, provenance=prov)
