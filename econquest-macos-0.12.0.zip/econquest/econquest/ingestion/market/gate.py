"""Market data quality gate (EQ-A-0031).

market_gate(df, previous=None, asof=None, params=None) returns a review table with the same columns as
feeds.quality_gate: table ('market'), key, country (ISO3, blank for currency-level quotes), seed (previous value
of the series, NaN when none), live (new value), status ('ok' or 'hold'), reason ('; '-joined). A finding that
should be looked at but not block the value (an inverted CDS curve) keeps status 'ok' with a reason starting
'flag:'. One review row per series (schema.SERIES): the latest quote of each series in `df`.

Checks (every tolerance is a field of GateParams, documented there):
  stale     quote date older than stale_bdays[instrument] business days before `asof` (default: the newest asof
            in df) -> hold
  range     value outside plausible[(instrument, field)] -> hold (negative spreads, absurd yields, FX <= 0)
  curve     CDS term structure per (iso, asof, currency, doc_clause, source): non-monotone (moves both up and down
            by more than curve_tol_bp between adjacent tenors) -> hold on every tenor of the curve; monotone but
            inverted (short end above long end) by more than curve_inversion_flag_bp -> flag (not held)
  arbitrage fx_forward vs spot and the two currencies' rates at the forward tenor (ois, else swap; USD for the
            dollar leg): F_implied = S * ((1 + r_ccy) / (1 + r_usd)) ** T. |F - F_implied| / S > cip_tol -> hold.
            Skipped (no reason) when either rate is missing. Points rows are converted with the same-day spot.
  jump      vs the previous value of the same series (latest in `previous`): |live - seed| above both
            jump[(instrument, field)] = (relative, absolute floor) -> hold
  licence   the row's licence carries a restriction that bars desk use (non-commercial, personal) -> hold, so a
            row from an opt-in research source (Yahoo, EQ-A-0040) can never reach a publish; a row whose source
            is Yahoo (DESK_BARRED_SOURCES) is held whatever its licence says (SEC-A-006 L6)
  simulated a row labelled SIMULATED (vendor simulator, EQ-A-0123) -> hold, unless market_gate's data_dir is a sandbox
            data folder (vendor_sim_guard): simulated values never pass the gate of a desk store
  basis     5y USD CDS vs embi_spread spread_bp, or vs (USD govt_yield 5y - UST 5y) x 100, same iso and asof:
            |difference| > max(basis_abs_bp, basis_rel x CDS) -> hold on both rows
"""
from __future__ import annotations

import dataclasses
import math

import numpy as np
import pandas as pd

from econquest.ingestion.market import vendor_sim_guard
from econquest.ingestion.market.schema import SERIES, validate_market

REVIEW_COLUMNS = ["table", "key", "country", "seed", "live", "status", "reason"]
TABLE = "market"
# EQ-A-0040 (Sam 2026-10-23): licence terms that bar a value from desk numbers and from a publish. A row carrying one
# is held whatever its value: Yahoo rows (YAHOO_LICENCE, only produced behind the explicit opt-in) always carry them.
# 'unverified' is not here: most free official licences are unverified and only need Sam's confirmation.
DESK_BARRED_LICENCE_TERMS = ("non-commercial", "noncommercial", "non commercial", "personal")
# SEC-A-006 L6: sources whose terms are personal and non-commercial whatever licence text a row carries (case-folded)
DESK_BARRED_SOURCES = ("yahoo", "yfinance", "yahoo finance", "yfinance (yahoo finance)")


@dataclasses.dataclass
class GateParams:
    # business days a quote may lag the gate as-of before it is stale (policy rates move rarely)
    stale_bdays: dict = dataclasses.field(default_factory=lambda: {
        "cds": 3, "govt_yield": 3, "embi_spread": 3, "fx_spot": 2, "fx_forward": 3, "ois": 3, "swap": 3,
        "policy_rate": 45})
    # plausible (low, high) per (instrument, field); outside -> hold. Wide on purpose: distressed sovereigns
    # (ARG, VEN, ZMB, ZWE) quote spreads in the thousands of bp and local yields far above 50%.
    plausible: dict = dataclasses.field(default_factory=lambda: {
        ("cds", "spread_bp"): (0.0, 50_000.0), ("cds", "upfront_pct"): (-20.0, 100.0), ("cds", "recovery"): (0.0, 1.0),
        ("embi_spread", "spread_bp"): (-50.0, 50_000.0), ("embi_spread", "yield_pct"): (-1.0, 300.0),
        ("govt_yield", "yield_pct"): (-2.0, 300.0), ("govt_yield", "price"): (1.0, 200.0),
        ("govt_yield", "spread_bp"): (-300.0, 50_000.0),
        ("fx_spot", "outright"): (1e-9, math.inf), ("fx_forward", "outright"): (1e-9, math.inf),
        ("fx_forward", "points"): (-math.inf, math.inf),
        ("policy_rate", "yield_pct"): (-2.0, 300.0), ("ois", "yield_pct"): (-2.0, 300.0),
        ("swap", "yield_pct"): (-2.0, 300.0)})
    curve_tol_bp: float = 5.0                  # adjacent-tenor moves smaller than this are noise for the shape test
    curve_inversion_flag_bp: float = 25.0      # short end above long end by more than this -> flag
    cip_tol: float = 0.02                      # |F - F_implied| / spot; generous for NDF / onshore-offshore basis
    # (relative, absolute floor) per (instrument, field); hold when |change| exceeds BOTH
    jump: dict = dataclasses.field(default_factory=lambda: {
        ("cds", "spread_bp"): (0.30, 30.0), ("cds", "recovery"): (0.0, 0.05), ("cds", "upfront_pct"): (0.5, 5.0),
        ("embi_spread", "spread_bp"): (0.30, 30.0), ("embi_spread", "yield_pct"): (0.20, 0.5),
        ("govt_yield", "yield_pct"): (0.20, 0.5), ("govt_yield", "price"): (0.10, 5.0),
        ("govt_yield", "spread_bp"): (0.30, 30.0),
        ("fx_spot", "outright"): (0.05, 0.0), ("fx_forward", "outright"): (0.05, 0.0),
        ("fx_forward", "points"): (1.0, 0.0),
        ("policy_rate", "yield_pct"): (0.25, 1.0), ("ois", "yield_pct"): (0.30, 0.5), ("swap", "yield_pct"): (0.30, 0.5)})
    basis_abs_bp: float = 150.0
    basis_rel: float = 0.5
    basis_tenor: float = 5.0


def series_key(r) -> str:
    return "|".join([str(r["instrument"]), str(r["currency"]), f"{float(r['tenor_y']):g}", str(r["field"]),
                     str(r["doc_clause"]), str(r["source"]), str(r["asof"])])


def _latest(df: pd.DataFrame) -> pd.DataFrame:
    return (df.sort_values("asof", kind="mergesort").groupby(SERIES, as_index=False, sort=False).last()
            .reset_index(drop=True))


def market_gate(df: pd.DataFrame, previous: pd.DataFrame | None = None, asof=None,
                params: GateParams | None = None, *, data_dir=None) -> pd.DataFrame:
    """See the module docstring. data_dir: the data folder the rows belong to; SIMULATED rows are held unless it
    is a sandbox data folder (vendor_sim_guard, EQ-A-0123). With no data_dir every SIMULATED row is held."""
    p = params or GateParams()
    m = validate_market(df)
    if m.empty:
        return pd.DataFrame(columns=REVIEW_COLUMNS)
    cur = _latest(m)
    gate_day = str(pd.Timestamp(asof).date()) if asof is not None else str(m["asof"].max())
    reasons: list[list[str]] = [[] for _ in range(len(cur))]
    hold = np.zeros(len(cur), dtype=bool)

    def add(i, text, is_hold=True):
        reasons[i].append(text if is_hold else f"flag: {text}")
        hold[i] |= is_hold

    # seed = previous value of the same series
    seed = np.full(len(cur), np.nan)
    if previous is not None and len(previous):
        prev = _latest(validate_market(previous))
        pmap = {tuple(r[c] for c in SERIES): r["value"] for _, r in prev.iterrows()}
        seed = np.array([pmap.get(tuple(r[c] for c in SERIES), np.nan) for _, r in cur.iterrows()], dtype=float)

    for i, r in cur.iterrows():
        # stale
        lim = p.stale_bdays.get(r["instrument"])
        if lim is not None:
            lag = int(np.busday_count(r["asof"], gate_day)) if r["asof"] < gate_day else 0
            if lag > lim:
                add(i, f"stale: quote of {r['asof']} is {lag} business days before {gate_day} (limit {lim})")
        # range
        lo, hi = p.plausible.get((r["instrument"], r["field"]), (-math.inf, math.inf))
        if not lo <= r["value"] <= hi:
            add(i, f"range: {r['value']:.6g} outside [{lo:g}, {hi:g}] for {r['instrument']} {r['field']}")
        # jump
        s = seed[i]
        if np.isfinite(s):
            rel, floor = p.jump.get((r["instrument"], r["field"]), (math.inf, math.inf))
            d = abs(r["value"] - s)
            if d > rel * abs(s) and d > floor:
                add(i, f"jump: {s:.6g} -> {r['value']:.6g} ({(r['value'] - s) / max(abs(s), 1e-12) * 100:+.0f}%, "
                       f"limits {rel:.0%} and {floor:g})")

    for i, r in cur.iterrows():
        lic = str(r["licence"]).casefold()
        hits = [t for t in DESK_BARRED_LICENCE_TERMS if t in lic]
        if hits:
            add(i, f"licence: {', '.join(hits)} use only ({r['licence']}): not allowed in desk numbers or a publish")
        elif str(r.get("source", "")).strip().casefold() in DESK_BARRED_SOURCES:
            # SEC-A-006 L6: a Yahoo row is held whatever licence text it carries (a caller or an import could relabel it)
            add(i, f"licence: source {r['source']!r} is personal, non-commercial data (Sam 2026-10-23, EQ-A-0040): "
                   "not allowed in desk numbers or a publish, whatever the row's licence says")

    sim = vendor_sim_guard.simulated_mask(cur)
    if sim.any():
        why = vendor_sim_guard.gate_reason(data_dir)
        if why:
            for i in cur.index[sim]:
                add(i, why)

    _curve_checks(cur, p, add)
    _cip_checks(cur, p, add)
    _basis_checks(cur, p, add)
    return pd.DataFrame({"table": TABLE, "key": [series_key(r) for _, r in cur.iterrows()], "country": cur["iso"],
                         "seed": seed, "live": cur["value"].astype(float),
                         "status": np.where(hold, "hold", "ok"), "reason": ["; ".join(x) for x in reasons]},
                        columns=REVIEW_COLUMNS)


def _curve_checks(cur, p: GateParams, add) -> None:
    cds = cur[(cur["instrument"] == "cds") & (cur["field"] == "spread_bp")]
    for _, g in cds.groupby(["iso", "asof", "currency", "doc_clause", "source"]):
        g = g.sort_values("tenor_y")
        if len(g) < 2:
            continue
        v = g["value"].to_numpy(dtype=float)
        d = np.diff(v)
        sig = d[np.abs(d) > p.curve_tol_bp]
        curve = ", ".join(f"{t:g}y {x:g}" for t, x in zip(g["tenor_y"], v))
        if (sig > 0).any() and (sig < 0).any():
            for i in g.index:
                add(i, f"curve: CDS term structure non-monotone beyond {p.curve_tol_bp:g}bp ({curve})")
        elif v[0] - v[-1] > p.curve_inversion_flag_bp:
            for i in g.index:
                add(i, f"curve inverted by {v[0] - v[-1]:.0f}bp ({curve})", is_hold=False)


def _rate(cur, ccy: str, asof: str, tenor: float) -> float | None:
    for inst in ("ois", "swap"):
        r = cur[(cur["instrument"] == inst) & (cur["currency"] == ccy) & (cur["asof"] == asof)
                & (cur["tenor_y"] == tenor) & (cur["field"] == "yield_pct")]
        if len(r):
            return float(r["value"].iloc[0]) / 100.0
    return None


def _cip_checks(cur, p: GateParams, add) -> None:
    fwd = cur[cur["instrument"] == "fx_forward"]
    for i, f in fwd.iterrows():
        spot = cur[(cur["instrument"] == "fx_spot") & (cur["currency"] == f["currency"]) & (cur["asof"] == f["asof"])
                   & (cur["field"] == "outright")]
        if spot.empty:
            continue
        s = float(spot["value"].iloc[0])
        r_c, r_u = _rate(cur, f["currency"], f["asof"], f["tenor_y"]), _rate(cur, "USD", f["asof"], f["tenor_y"])
        if r_c is None or r_u is None or s <= 0 or r_u <= -1 or r_c <= -1:
            continue
        mkt = f["value"] if f["field"] == "outright" else s + f["value"]
        implied = s * ((1 + r_c) / (1 + r_u)) ** float(f["tenor_y"])
        dev = abs(mkt - implied) / s
        if dev > p.cip_tol:
            add(i, f"arbitrage: {f['currency']} {f['tenor_y']:g}y forward {mkt:.6g} vs covered-parity "
                   f"{implied:.6g} (spot {s:g}, rates {r_c:.2%}/{r_u:.2%}): {dev:.1%} > {p.cip_tol:.0%}")


def _basis_checks(cur, p: GateParams, add) -> None:
    t = p.basis_tenor
    cds = cur[(cur["instrument"] == "cds") & (cur["field"] == "spread_bp") & (cur["tenor_y"] == t)
              & (cur["currency"] == "USD")]
    for i, c in cds.iterrows():
        same = (cur["iso"] == c["iso"]) & (cur["asof"] == c["asof"])
        comps = []
        for j, e in cur[same & (cur["instrument"] == "embi_spread") & (cur["field"] == "spread_bp")].iterrows():
            comps.append((j, float(e["value"]), "EMBI spread"))
        gy = cur[same & (cur["instrument"] == "govt_yield") & (cur["field"] == "yield_pct") & (cur["currency"] == "USD")
                 & (cur["tenor_y"] == t)]
        ust = cur[(cur["iso"] == "USA") & (cur["asof"] == c["asof"]) & (cur["instrument"] == "govt_yield")
                  & (cur["field"] == "yield_pct") & (cur["currency"] == "USD") & (cur["tenor_y"] == t)]
        if len(gy) and len(ust) and c["iso"] != "USA":
            comps.append((gy.index[0], (float(gy["value"].iloc[0]) - float(ust["value"].iloc[0])) * 100,
                          f"USD {t:g}y bond yield minus UST"))
        tol = max(p.basis_abs_bp, p.basis_rel * float(c["value"]))
        for j, v, what in comps:
            if abs(float(c["value"]) - v) > tol:
                msg = (f"basis: {t:g}y CDS {c['value']:.0f}bp vs {what} {v:.0f}bp, difference "
                       f"{c['value'] - v:+.0f}bp beyond {tol:.0f}bp")
                add(i, msg)
                add(j, msg)
