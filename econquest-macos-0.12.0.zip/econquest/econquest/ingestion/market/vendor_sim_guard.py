"""SIMULATED market data guard (EQ-A-0123). Simulated values are confined to a sandbox data folder.

The vendor simulator (vendors/vendor_sim.py) makes synthetic CDS curves, bond yields, OIS and FX forwards and serves
them through the real Bloomberg and LSEG adapters. Every row it produces carries the label SIMULATED:
    licence        "<vendor>:SIMULATED-SYNTHETIC-<VENDOR>-A123 (desk-internal)"  (the entitlement's licence id)
    vendor_ticker  "SIMULATED ..." (Bloomberg) / "SIMULATED...=SIM" (LSEG)
    manifest       provenance {"label": "SIMULATED", ...} on every snapshot it saves
"SYNTHETIC" is in the licence id as well, so Team B's layer 2 (layer2_bayesian.SYNTHETIC_RE) refuses the curves by
default too.

The rule enforced here, in code, by the store and the gate:
  - store.save_market_snapshot and store._append_cds_snapshots (the only writer of market/cds_snapshots.csv) raise
    SimulatedDataError when a row (or the snapshot provenance) is SIMULATED and the data folder is not a sandbox;
  - gate.market_gate(..., data_dir=...) holds every SIMULATED row unless data_dir is a sandbox, so a SIMULATED row
    that reached a desk store some other way is never passed by the gate, gated_history, gated_market_history or the
    gated CDS export.
Desk data (data/, data/mvp, data/live/vintages/*, the market store layer 2 and the release read) is therefore never a
place a SIMULATED row can be saved or pass the gate.

A sandbox data folder is one that:
  1. holds SANDBOX_MARKER (SIMULATED_SANDBOX.json, label "SIMULATED"), written by make_sandbox();
  2. is not inside the econquest folder (so not data/, data/mvp, outputs/, a vintage or a release folder);
  3. has no desk data file (countries.csv, assumptions.json, indicators.csv, licences.csv) in itself or any parent;
  4. holds no symbolic link anywhere inside it (SEC-A-014 M1: a link would carry writes out of the sandbox).
There is no switch, environment variable or setting that widens this.
"""
from __future__ import annotations

import datetime as dt
import json
import os
from pathlib import Path

import pandas as pd

from econquest.ingestion.market.schema import MarketDataError

LABEL = "SIMULATED"
TICKET = "EQ-A-0123"
SANDBOX_MARKER = "SIMULATED_SANDBOX.json"
REPO_ROOT = Path(__file__).resolve().parents[3]
DESK_FILES = ("countries.csv", "assumptions.json", "indicators.csv", "licences.csv")
ROW_COLUMNS = ("licence", "vendor_ticker", "source")


class SimulatedDataError(MarketDataError):
    """A SIMULATED value would be saved or exported outside a sandbox data folder."""


def is_simulated_text(v) -> bool:
    return LABEL.casefold() in str(v if v is not None else "").casefold()


def simulated_mask(df: pd.DataFrame) -> pd.Series:
    """True for every row whose licence, vendor_ticker or source carries the SIMULATED label."""
    m = pd.Series(False, index=df.index, dtype=bool)
    for c in ROW_COLUMNS:
        if c in df.columns:
            m |= df[c].astype(str).str.casefold().str.contains(LABEL.casefold(), regex=False)
    return m


def provenance_is_simulated(provenance) -> bool:
    return bool(provenance) and is_simulated_text(json.dumps(provenance, default=str))


def _inside(p: Path, root: Path) -> bool:
    try:
        p.relative_to(root)
        return True
    except ValueError:
        return False


def location_problem(data_dir) -> str:
    """'' when `data_dir` may be a sandbox by location (rules 2 and 3 of the module docstring), else why not."""
    if data_dir is None:
        return "no data folder given"
    p = Path(data_dir).expanduser().resolve()
    if _inside(p, REPO_ROOT.resolve()):
        return f"{p} is inside the econquest folder {REPO_ROOT} (desk data, data/mvp, vintages, outputs, releases)"
    for d in (p, *p.parents):
        hit = [f for f in DESK_FILES if (d / f).is_file()]
        if hit:
            return f"{d} holds desk data files {hit}"
    return ""


def sandbox_problem(data_dir) -> str:
    """'' when `data_dir` is a sandbox data folder (module docstring), else why not."""
    why = location_problem(data_dir)
    if why:
        return why
    p = Path(data_dir).expanduser().resolve()
    marker = p / SANDBOX_MARKER
    if not marker.is_file():
        return f"{p} has no {SANDBOX_MARKER} (create the sandbox with vendor_sim_guard.make_sandbox)"
    try:
        doc = json.loads(marker.read_text(encoding="utf-8"))
    except (OSError, UnicodeDecodeError, json.JSONDecodeError):
        return f"{marker} is not readable JSON"
    if not isinstance(doc, dict) or doc.get("label") != LABEL:
        return f"{marker} does not carry label {LABEL!r}"
    link = _first_link(p)
    if link:
        return f"{link} is a link inside the sandbox: writes through it could leave the sandbox (SEC-A-014 M1)"
    return ""


def _first_link(root: Path) -> str:
    """The first symbolic link (or junction) under `root`, '' when none. SEC-A-014 M1: the store writes to
    <root>/live/market/... and <root>/market/...; a link there would carry SIMULATED rows into a desk folder."""
    for d, dirs, files in os.walk(root, followlinks=False):
        for n in (*dirs, *files):
            q = Path(d) / n
            if q.is_symlink() or (hasattr(q, "is_junction") and q.is_junction()):
                return str(q)
    return ""


def is_sandbox(data_dir) -> bool:
    return sandbox_problem(data_dir) == ""


def make_sandbox(path, *, seed: int | None = None, now: dt.datetime | None = None) -> Path:
    """Create (or reuse) a sandbox data folder and write its marker. Refuses, before creating anything, a folder that
    cannot be a sandbox or that already holds files without the marker."""
    p = Path(path).expanduser()
    why = location_problem(p)
    if why:
        raise SimulatedDataError(f"not a sandbox data folder: {why}")
    if p.is_dir() and not (p / SANDBOX_MARKER).exists() and any(p.iterdir()):
        raise SimulatedDataError(f"{p} is not empty and has no {SANDBOX_MARKER}: give a new or empty folder")
    p.mkdir(parents=True, exist_ok=True)
    marker = p / SANDBOX_MARKER
    if not marker.exists():
        now = now or dt.datetime.now(dt.timezone.utc)
        marker.write_text(json.dumps({"label": LABEL, "ticket": TICKET, "seed": seed,
                                      "created_utc": now.strftime("%Y-%m-%dT%H:%M:%SZ"),
                                      "note": "SIMULATED vendor data sandbox: every value here is synthetic, not "
                                              "market data; never copy it into desk data"}, indent=1) + "\n",
                          encoding="utf-8")
    why = sandbox_problem(p)
    if why:
        raise SimulatedDataError(f"not a sandbox data folder: {why}")
    return p


def guard_save(data_dir, df: pd.DataFrame, provenance=None, what: str = "market snapshot") -> None:
    """Raise SimulatedDataError when SIMULATED rows (or provenance) would be written outside a sandbox."""
    n = int(simulated_mask(df).sum()) if len(df) else 0
    if not n and not provenance_is_simulated(provenance):
        return
    why = sandbox_problem(data_dir)
    if why:
        raise SimulatedDataError(f"refusing to write a {what} with {n} {LABEL} rows to {data_dir}: {why}. "
                                 f"{LABEL} values live only in a sandbox data folder ({TICKET})")


def gate_reason(data_dir) -> str:
    """The gate hold reason for a SIMULATED row in `data_dir` ('' when data_dir is a sandbox)."""
    why = sandbox_problem(data_dir)
    return "" if not why else (f"simulated: {LABEL} value outside a sandbox data folder ({why}); "
                               "never desk data")


def assert_no_simulated(df: pd.DataFrame, where: str) -> None:
    """For publish, release and client-output paths: raise when any row carries the SIMULATED label."""
    n = int(simulated_mask(df).sum()) if len(df) else 0
    if n:
        raise SimulatedDataError(f"{where}: {n} {LABEL} rows; simulated values never reach {where} ({TICKET})")
