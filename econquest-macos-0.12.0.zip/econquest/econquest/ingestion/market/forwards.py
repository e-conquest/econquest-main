"""FX forwards derived by covered interest parity (EQ-A-0030). Not quotes: every row is derived=True.

    F(T) = S * exp((z_ccy - z_usd) * T)

S        fx_spot outright, units CCY/USD (units of CCY per 1 USD), same quote date as the rates
z_ccy    the currency's rate at tenor T converted to a continuously compounded zero rate
z_usd    the USD rate at tenor T, converted the same way
T        tenor in years: 1M = 1/12, 3M = 0.25, 6M = 0.5, 12M = 1.0. Year fraction is the tenor itself (ACT/365F
         approximation). Spot settlement lag (T+2), holiday calendars and the money-market day count of each
         currency (ACT/360 for USD and EUR) are ignored: the derived forward is an indication, not a dealable price.

Compounding of the inputs, by source slug (COMPOUNDING): fred / alfred = semiannual (Treasury par yields are bond-
equivalent), ecb_yc_aaa / ecb_yc_all = continuous (SV_C_YM), bis = simple (policy rate). Conversions to continuous:
    annual       z = ln(1 + r)
    semiannual   z = 2 ln(1 + r/2)
    continuous   z = r
    simple       z = ln(1 + r T) / T
A source with no known convention is refused unless the caller passes compounding={source: ...}: never assumed.

Rate choice per (currency, quote date, tenor): instruments in RATE_INSTRUMENTS order (ois, swap, govt_yield), the
tenor matched exactly (|dT| < 1e-6, no interpolation), govt_yield only from the currency's benchmark issuer
(ISSUERS: USD -> USA, EUR -> EMU), sources in SOURCE_ORDER then alphabetical. Policy rates (tenor 0) are not used.
If either rate is missing the forward is refused, listed in attrs['refused'] with the reason, never guessed.

Output rows: instrument fx_forward, iso blank (currency-level), field outright and points (F - S), unit CCY/USD,
source 'derived_cip' (the schema needs a slug; the human label 'derived (CIP)' is in vendor_ticker and the licence),
vendor_ticker naming the inputs, derived True. The licence carries the input licences (derived_licence: every
input licence verbatim when it fits 128 characters, else every restrictive marker such as non-commercial, personal,
unverified or synthetic as written there; a forward whose restrictions cannot be carried is refused; SEC-A-003 L3).
attrs['provenance'] lists each forward's spot and rate inputs with
their source, snapshot, ticker, value, licence and convention; save_forwards writes it into the snapshot manifest.

Spot source (EQ-A-0040, Sam 2026-10-23 "Replace with free official"): `--spot bis` (default) reads
data/live/raw_bis_xru.csv, `--spot ecb` data/live/raw_ecb_exr.csv converted to per-USD through the same date's
EUR/USD, `--spot snapshot` the market snapshots. `--spot yahoo` is refused unless ECONQUEST_ALLOW_YAHOO=1 is set
(non-commercial opt-in): the rows it makes carry YAHOO_LICENCE, which the publish gate refuses.

CLI (Sam's Mac or offline from snapshots):
    python -m econquest.ingestion.market.forwards --data-dir data --asof 2026-10-22 --spot bis
"""
from __future__ import annotations

import argparse
import datetime as dt
import math
import re
import sys
from pathlib import Path

import pandas as pd

from econquest.ingestion.market.schema import MARKET_COLUMNS, MAX_TEXT, MarketDataError, validate_market
from econquest.ingestion.market.store import market_history, save_market_snapshot

TENORS = {"1M": 1 / 12, "3M": 0.25, "6M": 0.5, "12M": 1.0}
SOURCE = "derived_cip"
LABEL = "derived (CIP)"
COMPOUNDING = {"fred": "semiannual", "alfred": "semiannual", "ecb_yc_aaa": "continuous", "ecb_yc_all": "continuous",
               "bis": "simple"}
CONVENTIONS = ("annual", "semiannual", "continuous", "simple")
RATE_INSTRUMENTS = ("ois", "swap", "govt_yield")
ISSUERS = {"USD": "USA", "EUR": "EMU"}
SOURCE_ORDER = ("fred", "alfred", "ecb_yc_aaa", "ecb_yc_all")
TENOR_TOL = 1e-6
FORMULA = "F = S * exp((z_ccy - z_usd) * T); z = continuously compounded zero rate; T = tenor years (ACT/365F approx)"
YAHOO_LICENCE = "Yahoo Finance via yfinance: Yahoo terms of service, personal non-commercial use (unverified)"
# EQ-A-0040: official spot sources. The licence strings are the ones public.py already uses for the same providers.
BIS_SPOT_SOURCE = "bis_xru"
ECB_SPOT_SOURCE = "ecb_exr"
BIS_SPOT_LICENCE = "BIS statistics: free reuse with attribution to the BIS per bis.org terms of use (unverified)"
ECB_SPOT_LICENCE = "ECB statistics: reuse free of charge with the source (ECB Data Portal) acknowledged (unverified)"
YAHOO_OPT_IN_ENV = "ECONQUEST_ALLOW_YAHOO"       # "1": allow the non-commercial Yahoo spot; publishing still refuses it
SPOT_SOURCES = ("bis", "ecb", "snapshot", "yahoo")
# Terms in an input licence that restrict use; carried into a derived row's licence as written (SEC-A-003 L3).
RESTRICTIVE_MARKERS = ("non-commercial", "noncommercial", "non commercial", "personal", "unverified", "synthetic",
                       "research only", "internal use", "internal only", "evaluation", "trial", "not for redistribution",
                       "no redistribution", "redistribution prohibited", "delayed", "restricted", "confidential",
                       "proprietary", "simulated")    # SEC-A-014 L4: a SIMULATED input stays labelled


def to_continuous(rate_pct: float, compounding: str, t: float) -> float:
    """Percent rate in `compounding` -> continuously compounded decimal rate over t years."""
    r = float(rate_pct) / 100.0
    if compounding == "continuous":
        return r
    if compounding == "annual":
        base = 1 + r
        z = math.log(base) if base > 0 else math.nan
    elif compounding == "semiannual":
        base = 1 + r / 2
        z = 2 * math.log(base) if base > 0 else math.nan
    elif compounding == "simple":
        base = 1 + r * t
        z = math.log(base) / t if base > 0 and t > 0 else math.nan
    else:
        raise ValueError(f"unknown compounding {compounding!r}; one of {CONVENTIONS}")
    if not math.isfinite(z):
        raise ValueError(f"rate {rate_pct}% cannot be converted from {compounding} compounding")
    return z


def cip_forward(spot: float, z_ccy: float, z_usd: float, t: float) -> float:
    """Forward outright (CCY per USD) by covered interest parity with continuous rates."""
    if not (spot > 0 and t > 0):
        raise ValueError("spot and tenor must be positive")
    return spot * math.exp((z_ccy - z_usd) * t)


def _pick_rate(rates: pd.DataFrame, ccy: str, asof: str, t: float, comp: dict):
    """(row, compounding) of the rate to use, or (None, reason)."""
    cand = rates[(rates["currency"] == ccy) & (rates["asof"] == asof) & (rates["field"] == "yield_pct")
                 & ((rates["tenor_y"] - t).abs() < TENOR_TOL) & rates["instrument"].isin(RATE_INSTRUMENTS)]
    issuer = ISSUERS.get(ccy)
    cand = cand[(cand["instrument"] != "govt_yield") | ((cand["iso"] == issuer) if issuer else False)]
    if cand.empty:
        where = f"{'/'.join(RATE_INSTRUMENTS)}" + (f" (govt_yield of {issuer})" if issuer else
                                                   " (no benchmark issuer for govt_yield)")
        return None, f"no {ccy} {where} rate at {t:g}y on {asof}"
    src_rank = {s: i for i, s in enumerate(SOURCE_ORDER)}
    cand = cand.assign(_i=cand["instrument"].map(RATE_INSTRUMENTS.index),
                       _s=cand["source"].map(lambda s: src_rank.get(s, len(src_rank))))
    cand = cand.sort_values(["_i", "_s", "source"], kind="mergesort")
    unknown = []
    for _, r in cand.iterrows():
        c = comp.get(r["source"])
        if c in CONVENTIONS:
            return r, c
        unknown.append(r["source"])
    return None, f"{ccy} rate at {t:g}y on {asof}: compounding unknown for source(s) {sorted(set(unknown))}"


def restrictive_markers(licence: str) -> list[str]:
    """The restrictive terms in a licence string, as written there (case kept), in RESTRICTIVE_MARKERS order."""
    out = []
    for m in RESTRICTIVE_MARKERS:
        hit = re.search(rf"(?<![a-z]){m}(?![a-z])", licence, flags=re.IGNORECASE)
        if hit and hit.group(0).casefold() not in {x.casefold() for x in out}:
            out.append(hit.group(0))
    return out


def derived_licence(inputs) -> tuple[str | None, str]:
    """Licence of a CIP-derived row from its input rows (SEC-A-003 L3): restrictions are never laundered.
    1. '<LABEL> from s+c+u; inputs: <licence> | <licence>' with every distinct input licence verbatim, if it fits
       the MAX_TEXT cell limit;
    2. else '<LABEL> from s+c+u; input restrictions: <markers>; input licences apply' where markers are every
       RESTRICTIVE_MARKERS term found in any input licence, as written there (the full strings are in the
       provenance), dropping the source list if needed to fit;
    3. else (None, reason): the row is refused rather than stored with a licence that loses a restriction."""
    srcs = "+".join(str(r["source"]) for r in inputs)
    lics = list(dict.fromkeys(str(r["licence"]) for r in inputs))
    full = f"{LABEL} from {srcs}; inputs: {' | '.join(lics)}"
    if len(full) <= MAX_TEXT:
        return full, ""
    marks = list(dict.fromkeys(m for lic in lics for m in restrictive_markers(lic)))
    rest = f"input restrictions: {', '.join(marks)}; " if marks else ""
    for lic in (f"{LABEL} from {srcs}; {rest}input licences apply", f"{LABEL}; {rest}input licences apply (see provenance)",
                f"{LABEL}; {rest}see provenance"):
        if len(lic) <= MAX_TEXT:
            return lic, ""
    return None, f"derived licence cannot carry the input restrictions {marks} within {MAX_TEXT} characters"


def _input(r: pd.Series, compounding: str | None = None) -> dict:
    d = {"instrument": r["instrument"], "source": r["source"], "snapshot_id": r.get("snapshot_id", ""),
         "vendor_ticker": r["vendor_ticker"], "asof": r["asof"], "value": float(r["value"]), "unit": r["unit"],
         "licence": r["licence"]}
    if compounding:
        d["compounding"] = compounding
    return d


def derive_cip_forwards(spot: pd.DataFrame, rates: pd.DataFrame, tenors=tuple(TENORS), *,
                        compounding: dict | None = None, strict: bool = False) -> pd.DataFrame:
    """fx_forward rows (outright and points, derived=True) for every fx_spot row in `spot` (non-USD currency, unit
    CCY/USD) and each tenor in `tenors` (keys of TENORS) where both rates exist on the spot's quote date.
    attrs['refused'] lists (currency, asof, tenor, reason) for the rest; strict=True raises MarketDataError instead,
    and so does a call that derives nothing."""
    s = validate_market(spot)
    s = s[(s["instrument"] == "fx_spot") & (s["field"] == "outright") & (s["currency"] != "USD")]
    rt = validate_market(rates) if len(rates) else validate_market(pd.DataFrame(columns=MARKET_COLUMNS))
    comp = {**COMPOUNDING, **(compounding or {})}
    bad = [t for t in tenors if t not in TENORS]
    if bad:
        raise ValueError(f"unknown tenors {bad}; use {list(TENORS)}")
    if s.empty:
        raise MarketDataError("no fx_spot outright rows to derive forwards from")
    rows, prov, refused = [], [], []
    for _, sp in s.iterrows():
        ccy, asof, sv = sp["currency"], sp["asof"], float(sp["value"])
        if sp["unit"] != f"{ccy}/USD":
            refused.append((ccy, asof, "*", f"spot unit {sp['unit']!r} is not {ccy}/USD"))
            continue
        for name in tenors:
            t = TENORS[name]
            rc, why_c = _pick_rate(rt, ccy, asof, t, comp)
            ru, why_u = _pick_rate(rt, "USD", asof, t, comp)
            if rc is None or ru is None:
                refused.append((ccy, asof, name, "; ".join(w for w, r in ((why_c, rc), (why_u, ru)) if r is None)))
                continue
            try:
                zc, zu = to_continuous(rc["value"], why_c, t), to_continuous(ru["value"], why_u, t)
                fwd = cip_forward(sv, zc, zu, t)
            except ValueError as e:
                refused.append((ccy, asof, name, str(e)))
                continue
            ticker = (f"{LABEL} {name}: S={sp['source']} {ccy}={rc['source']}:{rc['vendor_ticker'] or rc['instrument']}"
                      f" USD={ru['source']}:{ru['vendor_ticker'] or ru['instrument']}")[:128]
            lic, why = derived_licence([sp, rc, ru])
            if lic is None:
                refused.append((ccy, asof, name, why))
                continue
            base = {"asof": asof, "instrument": "fx_forward", "iso": "", "currency": ccy, "tenor_y": t,
                    "unit": f"{ccy}/USD", "doc_clause": "", "source": SOURCE, "vendor_ticker": ticker,
                    "licence": lic, "derived": True, "snapshot_id": "", "retrieved_utc": ""}
            rows.append({**base, "field": "outright", "value": fwd})
            rows.append({**base, "field": "points", "value": fwd - sv})
            prov.append({"currency": ccy, "asof": asof, "tenor": name, "tenor_y": t, "forward": fwd,
                         "spot": _input(sp), "rate_ccy": {**_input(rc, why_c), "z_cont": zc},
                         "rate_usd": {**_input(ru, why_u), "z_cont": zu}})
    if refused and strict:
        raise MarketDataError("CIP forwards refused: " + "; ".join(f"{c} {a} {t}: {w}" for c, a, t, w in refused[:10]))
    if not rows:
        raise MarketDataError("no CIP forward could be derived: "
                              + "; ".join(f"{c} {a} {t}: {w}" for c, a, t, w in refused[:10]))
    out = validate_market(pd.DataFrame(rows, columns=MARKET_COLUMNS))
    out.attrs["refused"] = refused
    out.attrs["provenance"] = {"method": LABEL, "formula": FORMULA, "compounding_by_source": comp,
                               "year_fraction": "tenor years (ACT/365F approx); settlement lag and holidays ignored",
                               "forwards": prov,
                               "refused": [{"currency": c, "asof": a, "tenor": t, "reason": w}
                                           for c, a, t, w in refused]}
    return out


def _fx_spot_rows(per_usd: pd.DataFrame, source: str, licence: str, ticker_of, retrieved_utc: str = "") -> pd.DataFrame:
    """fx_spot outright rows (CCY/USD) from a long table of '<CCY>_PER_USD' rows (feeds._long_keyed shape)."""
    from econquest.ingestion.feeds import FX_PER_USD_SUFFIX
    rows = []
    for r in per_usd.itertuples(index=False):
        series = str(r.series)
        if not series.endswith(FX_PER_USD_SUFFIX):
            continue
        ccy = series[:-len(FX_PER_USD_SUFFIX)]
        if ccy == "USD":
            continue
        value = float(r.value)
        if not (value > 0):
            raise MarketDataError(f"{source}: {ccy}/USD on {r.period} is {value}, not a positive rate")
        rows.append({"asof": str(r.period), "instrument": "fx_spot", "iso": "", "currency": ccy, "tenor_y": 0.0,
                     "field": "outright", "value": value, "unit": f"{ccy}/USD", "doc_clause": "", "source": source,
                     "vendor_ticker": str(ticker_of(r))[:128], "licence": licence, "derived": False,
                     "snapshot_id": "", "retrieved_utc": retrieved_utc})
    if not rows:
        raise MarketDataError(f"{source}: no '<CCY>_PER_USD' row to make an fx_spot from")
    out = pd.DataFrame(rows, columns=MARKET_COLUMNS).drop_duplicates(["asof", "currency"])
    return validate_market(out)


def spot_from_bis_xru(raw_bis_xru: pd.DataFrame, *, retrieved_utc: str = "",
                      licence: str = BIS_SPOT_LICENCE) -> pd.DataFrame:
    """fx_spot rows from feeds.BisFeed.fetch_xru's long table (data/live/raw_bis_xru.csv, series '<CCY>_PER_USD',
    units of the currency per USD as BIS publishes them). The vendor_ticker is the SDMX key of the series."""
    df = raw_bis_xru.copy()
    df["value"] = pd.to_numeric(df["value"], errors="coerce")
    df = df.dropna(subset=["value"])
    return _fx_spot_rows(df, BIS_SPOT_SOURCE, licence, lambda r: getattr(r, "sdmx_key", "") or "BIS WS_XRU",
                         retrieved_utc)


def spot_from_ecb_exr(raw_ecb_exr: pd.DataFrame, *, retrieved_utc: str = "",
                      licence: str = ECB_SPOT_LICENCE) -> pd.DataFrame:
    """fx_spot rows from feeds.EcbExrFeed's long table (data/live/raw_ecb_exr.csv, '<CCY>_PER_EUR' reference rates),
    converted to units of the currency per USD through the EUR/USD reference rate of the same date
    (feeds.ecb_per_usd): no rate is carried over from another date."""
    from econquest.ingestion.feeds import ecb_per_usd
    per_usd = ecb_per_usd(raw_ecb_exr)
    return _fx_spot_rows(per_usd, ECB_SPOT_SOURCE, licence, lambda r: getattr(r, "sdmx_key", "") or "ECB EXR",
                         retrieved_utc)


def yahoo_opt_in(env: dict | None = None) -> bool:
    """True when the non-commercial Yahoo spot is explicitly opted in (ECONQUEST_ALLOW_YAHOO=1). Desk and publish
    paths never set it: a Yahoo-sourced row keeps YAHOO_LICENCE, whose restrictions the derived licence carries."""
    import os as _os
    return str((env if env is not None else _os.environ).get(YAHOO_OPT_IN_ENV, "")).strip() == "1"


def spot_from_yahoo_raw(raw_yahoo: pd.DataFrame, currencies: dict, *, retrieved_utc: str = "") -> pd.DataFrame:
    """fx_spot rows from feeds.YahooFeed's long table (data/live/raw_yahoo.csv, series FX_USD = CCY per USD close).
    Countries sharing a currency collapse to one row per (currency, date); if they disagree, MarketDataError.
    Every row carries YAHOO_LICENCE: the caller cannot choose the licence (SEC-A-006 L6), so the market gate holds them."""
    fx = raw_yahoo[raw_yahoo["series"].astype(str) == "FX_USD"].copy()
    fx["value"] = pd.to_numeric(fx["value"], errors="coerce")
    fx = fx.dropna(subset=["value"])
    fx["period"] = fx["period"].astype(str)
    unknown = sorted(set(fx["iso"]) - {k for k, v in currencies.items() if isinstance(v, str) and v})
    if unknown:
        raise MarketDataError(f"no currency for {unknown} in countries.csv")
    fx["currency"] = fx["iso"].map(currencies)
    fx = fx[fx["currency"] != "USD"]
    spread = fx.groupby(["currency", "period"])["value"].agg(lambda v: v.max() - v.min())
    if (spread > 1e-9 * fx["value"].abs().max()).any():
        raise MarketDataError(f"Yahoo spot disagrees within a currency: {spread[spread > 0].head(5).to_dict()}")
    fx = fx.drop_duplicates(["currency", "period"])
    rows = [{"asof": r.period, "instrument": "fx_spot", "iso": "", "currency": r.currency, "tenor_y": 0.0,
             "field": "outright", "value": float(r.value), "unit": f"{r.currency}/USD", "doc_clause": "",
             "source": "yahoo", "vendor_ticker": f"{r.currency}=X", "licence": YAHOO_LICENCE, "derived": False,
             "snapshot_id": "", "retrieved_utc": retrieved_utc} for r in fx.itertuples(index=False)]
    return validate_market(pd.DataFrame(rows, columns=MARKET_COLUMNS))


def _spot_from_live(data_dir: Path, source: str) -> pd.DataFrame:
    """fx_spot rows from the raw table of a live FX pull (`econquest fetch --only fx`). Raises FileNotFoundError when
    the raw file is not there (a stale snapshot is never used instead), and refuses the Yahoo source unless the
    non-commercial opt-in is set."""
    files = {"bis": ("raw_bis_xru.csv", spot_from_bis_xru), "ecb": ("raw_ecb_exr.csv", spot_from_ecb_exr),
             "yahoo": ("raw_yahoo.csv", None)}
    if source not in files:
        raise ValueError(f"unknown spot source {source!r}; one of {SPOT_SOURCES}")
    name, builder = files[source]
    raw = Path(data_dir) / "live" / name
    if not raw.exists():
        raise FileNotFoundError(f"{raw} not found: run `econquest fetch --only fx` on the Mac first")
    mtime = dt.datetime.fromtimestamp(raw.stat().st_mtime, dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    df = pd.read_csv(raw, dtype=str, keep_default_na=False)
    if source == "yahoo":
        if not yahoo_opt_in():
            raise MarketDataError(
                "--spot yahoo is refused: Yahoo Finance is personal, non-commercial use (Sam 2026-10-23, EQ-A-0040). "
                f"Use --spot bis or --spot ecb; for research only, set {YAHOO_OPT_IN_ENV}=1, and never publish the "
                "rows it produces.")
        c = pd.read_csv(Path(data_dir) / "countries.csv", dtype=str, keep_default_na=False)
        return spot_from_yahoo_raw(df, dict(zip(c["iso"], c["currency"])), retrieved_utc=mtime)
    return builder(df, retrieved_utc=mtime)


def save_forwards(data_dir, forwards: pd.DataFrame, spot: pd.DataFrame | None = None,
                  now: dt.datetime | None = None) -> Path:
    """Snapshot of the derived forwards (plus `spot` rows when the spot did not come from a snapshot already), with
    the CIP provenance in the manifest."""
    frames = [forwards] + ([spot] if spot is not None and len(spot) else [])
    df = pd.concat(frames, ignore_index=True)
    return save_market_snapshot(Path(data_dir), df, now=now, provenance=forwards.attrs.get("provenance", {}))


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.market.forwards",
                                 description="Derive FX forwards by covered interest parity from spot and the rate "
                                             "curves in the market snapshots; save them as derived rows.")
    ap.add_argument("--data-dir", default="data")
    ap.add_argument("--asof", required=True, help="quote date YYYY-MM-DD (spot and rates must both be on it)")
    ap.add_argument("--spot", choices=SPOT_SOURCES, default="bis",
                    help="fx_spot source: bis (data/live/raw_bis_xru.csv, default), ecb (data/live/raw_ecb_exr.csv "
                         "through EUR/USD), snapshot (market snapshots), or yahoo (refused unless "
                         f"{YAHOO_OPT_IN_ENV}=1; non-commercial, never for publishing). Spot that did not come from "
                         "a snapshot is saved with the forwards.")
    ap.add_argument("--tenors", default=",".join(TENORS))
    ap.add_argument("--dry-run", action="store_true")
    a = ap.parse_args(argv)
    d = Path(a.data_dir)
    try:
        asof = dt.date.fromisoformat(a.asof).isoformat()
        rates = market_history(d)                     # everything known now, quoted on the as-of date
        rates = rates[rates["asof"] == asof]
        save_spot = None
        if a.spot == "snapshot":
            spot = market_history(d, "fx_spot")
            spot = spot[spot["asof"] == asof]
        else:
            sp = _spot_from_live(d, a.spot)
            spot = save_spot = sp[sp["asof"] == asof]
            if spot.empty:
                raise MarketDataError(f"{a.spot}: no fx_spot on {asof} in data/live (pull the official FX feeds on "
                                      f"the Mac: econquest fetch --only fx)")
        fwd = derive_cip_forwards(spot, rates, tuple(a.tenors.split(",")))
    except (MarketDataError, FileNotFoundError, ValueError) as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    print(f"{len(fwd) // 2} forwards derived for {asof}; {len(fwd.attrs['refused'])} refused")
    for c, _day, t, why in fwd.attrs["refused"][:30]:
        print(f"  refused {c} {t}: {why}")
    if not a.dry_run:
        print(f"saved {save_forwards(d, fwd, save_spot)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
