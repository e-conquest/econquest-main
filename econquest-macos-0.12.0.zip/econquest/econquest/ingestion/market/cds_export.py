"""Gated export of CDS quotes to Team B's data/market/cds_snapshots.csv (EQ-A-0038, SEC-A-003 M1).

Saving a market snapshot no longer touches cds_snapshots.csv. This module is the only writer, and it writes only
rows that pass two checks:

  1. Market gate (gated_history). For each stored snapshot S (save order) and each quote date `a` of its cds rows,
     gate.market_gate runs as cli._market_gate does for `market cds-quotes`, with one difference (SEC-A-003 L5):
     previous = only the rows that PASSED, from the snapshots saved before S plus S's own earlier quote dates,
     dated on or before `a`; current = those plus S's rows dated `a` (later snapshot wins per KEY); gate as-of =
     `a`. A held value is therefore never the seed of a later jump check, so re-saving a held 45000 is held again.
     A cds row of S dated `a` whose series is held (matched on (gate.series_key, iso) as in cli) is dropped. The
     result depends only on snapshots saved up to S, so a later backfill gives the same answer.
     market_gate_review(data_dir, as_of) is the same seed rule for the CLI's latest-market review.
  2. Attestation. A row with source 'manual' is kept (and used as a gate seed) only when its content (manual.content_sha256 of the row,
     recomputed) is in ledger.attested_content(data_dir, "market_manual") for its (manual.cell_key, iso). That drops
     rows never attested (saved through save_market_snapshot directly, or edited), and rows whose attestation a
     later ledger hold or reject withdrew.

What is left goes through schema.to_cds_snapshots and store._append_cds_snapshots (append-only, rows already there
are skipped, existing rows never rewritten). Rows already in the file before a check failed (for example a ledger
reject after an earlier export) stay there: the file is append-only, and a later capture supersedes them. The report
marks such rows already_in_file=True and the summary warns.

Run it after a save (import, manual entry, public pull) and the gate review:
    python -m econquest.ingestion.market.cds_export --data data [--snapshot ID ...] [--dry-run]
or store.export_cds_snapshots(data_dir) / export_gated_cds_snapshots(data_dir). The report lists every dropped row
and why. Runbook: docs/runbooks/A-market-data.md section 6.
"""
from __future__ import annotations

import argparse
import dataclasses
import sys
from pathlib import Path

import pandas as pd

from econquest.ingestion import ledger
from econquest.ingestion.market import manual
from econquest.ingestion.market.gate import market_gate, series_key
from econquest.ingestion.market.schema import (CDS_QUOTE_TYPES, KEY, MANUAL_SOURCE, MARKET_COLUMNS, SERIES,
                                               MarketDataError)
from econquest.ingestion.market.store import (_append_cds_snapshots, _cutoff, _fmt, cds_snapshots_path, latest_market,
                                              list_market_snapshots, read_market_snapshot, snapshot_root)

DROPPED_COLUMNS = ["snapshot_id", "asof", "iso", "currency", "tenor_y", "field", "doc_clause", "source", "value",
                   "check", "reason", "already_in_file"]


@dataclasses.dataclass
class CdsExportReport:
    appended: int                      # rows appended to cds_snapshots.csv (dry run: rows that would be)
    kept: int                          # cds market rows that passed the gate and the attestation check
    dropped: pd.DataFrame              # DROPPED_COLUMNS, one row per cds market row left out
    snapshots: list                    # snapshot ids examined that hold cds rows
    dry_run: bool = False
    path: Path | None = None

    def summary(self) -> str:
        by = self.dropped["check"].value_counts().to_dict() if len(self.dropped) else {}
        stuck = int(self.dropped["already_in_file"].sum()) if len(self.dropped) else 0
        verb = "would append" if self.dry_run else "appended"
        return (f"CDS snapshot export: {len(self.snapshots)} snapshots with cds rows, {self.kept} rows passed, "
                f"{len(self.dropped)} dropped (gate hold {by.get('gate', 0)}, attestation {by.get('attestation', 0)}); "
                f"{verb} {self.appended} rows to {self.path}"
                + (f"; WARNING {stuck} dropped rows were already in the file from an earlier export (append-only: "
                   "supersede them with a corrected capture)" if stuck else ""))


def _concat(frames) -> pd.DataFrame:
    frames = [f for f in frames if len(f)]
    return pd.concat(frames, ignore_index=True) if frames else pd.DataFrame(columns=MARKET_COLUMNS)


@dataclasses.dataclass
class GatedSnapshot:
    """One stored snapshot replayed through the gate: `held` and `unattested` are '' or the reason, aligned with
    `rows`. A row passed when both are ''."""
    snapshot_id: str
    rows: pd.DataFrame
    held: pd.Series
    unattested: pd.Series

    @property
    def passed(self) -> pd.Series:
        return (self.held == "") & (self.unattested == "")


def _holds(cur: pd.DataFrame, prev: pd.DataFrame, asof: str, params, data_dir=None) -> dict:
    """{(series_key, iso): reason} held by market_gate for quote date `asof` (data_dir: the SIMULATED rule)."""
    review = market_gate(cur, previous=prev if len(prev) else None, asof=asof, params=params, data_dir=data_dir)
    held = review[review["status"] == "hold"]
    return {(k, c): r for k, c, r in zip(held["key"], held["country"], held["reason"])}


def gated_history(data_dir: Path, *, params=None, cutoff: str | None = None) -> list[GatedSnapshot]:
    """Replay every stored snapshot (save order; only those saved at or before `cutoff`, 'YYYY-MM-DDTHH:MM:SSZ')
    through gate.market_gate and the market_manual attestation check.

    SEC-A-003 L5: the gate's current and previous views are built only from rows that PASSED (earlier snapshots,
    plus the same snapshot's earlier quote dates), so a held or unattested value never becomes the seed of a later
    jump check: saving 150, 45000 (held), 45000 again holds both 45000s. A snapshot is gated at each quote date of
    its cds rows and at the newest quote date of each of its series; its other (older, non-cds) rows are not
    reviewed and count as passed. Deterministic: the answer for snapshot S depends only on snapshots saved up to S."""
    ix = list_market_snapshots(data_dir)
    if cutoff is not None:
        ix = ix[ix["saved_utc"] <= cutoff]
    best = ledger.attested_content(data_dir, manual.TABLE)
    withdrawn = _withdrawn_cells(data_dir)
    out: list[GatedSnapshot] = []
    passed: list[pd.DataFrame] = []
    for sid in ix.sort_values("saved_utc", kind="mergesort")["snapshot_id"]:
        snap = read_market_snapshot(data_dir, sid)
        held = pd.Series("", index=snap.index, dtype=object)
        una = pd.Series([_attestation_problem(r, best, withdrawn) if r["source"] == MANUAL_SOURCE else ""
                         for _, r in snap.iterrows()], index=snap.index, dtype=object)
        ok_hist = _concat(passed)
        dates = set(snap.loc[snap["instrument"] == "cds", "asof"])
        if len(snap):
            dates |= set(snap.groupby(SERIES, sort=False)["asof"].max())
        for a in sorted(dates):
            mine = snap[(snap["asof"] < a) & (held == "") & (una == "")]
            base = _concat([ok_hist[ok_hist["asof"] <= a], mine])
            cur = _concat([base, snap[snap["asof"] == a]]).drop_duplicates(KEY, keep="last")
            holds = _holds(cur, base.drop_duplicates(KEY, keep="last"), a, params, data_dir)
            for i in snap.index[snap["asof"] == a]:
                why = holds.get((series_key(snap.loc[i]), snap.at[i, "iso"]))
                if why is not None:
                    held[i] = why
        g = GatedSnapshot(sid, snap, held, una)
        out.append(g)
        passed.append(snap[g.passed])
    return out


def market_gate_review(data_dir: Path, as_of: str | None = None, params=None) -> tuple[pd.DataFrame, pd.DataFrame]:
    """(review, latest market) like cli._market_gate, with the L5 fix: market_gate on latest_market(as of) against
    the rows of every snapshot saved before the latest one that PASSED the gate and the attestation check
    (gated_history), dated on or before `as_of`. A held value is never a seed. Raises FileNotFoundError when no
    snapshot qualifies. Intended for cli `market gate` / `market cds-quotes` (handoff to Team C)."""
    cur = latest_market(data_dir, asof=as_of)
    hist = gated_history(data_dir, params=params, cutoff=_cutoff(as_of))
    prev = _concat([g.rows[g.passed] for g in hist[:-1]])
    if as_of and len(prev):
        prev = prev[prev["asof"] <= str(as_of)[:10]]
    prev = prev.drop_duplicates(KEY, keep="last")
    return market_gate(cur, previous=prev if len(prev) else None, asof=as_of, params=params, data_dir=data_dir), cur


def _exported_keys(data_dir: Path) -> set:
    """(capture prefix, tenor text, quote_type) of rows already in cds_snapshots.csv."""
    p = cds_snapshots_path(data_dir)
    if not p.exists() or p.stat().st_size == 0:
        return set()
    f = pd.read_csv(p, dtype=str, keep_default_na=False)
    return {(sid, t, q) for sid, t, q in zip(f["snapshot_id"], f["tenor_y"], f["quote_type"])}


def _in_file(r, exported: set) -> bool:
    qt = CDS_QUOTE_TYPES.get(r["field"])
    cap = f"{r['snapshot_id']}:{r['iso']}:{r['asof']}:{r['source']}:{r['currency']}:{r['doc_clause'] or '-'}"
    return qt is not None and (cap, _fmt(float(r["tenor_y"])), qt) in exported


def _withdrawn_cells(data_dir: Path) -> set:
    """(key, country) cells of table market_manual with any hold or reject decision in the ledger."""
    led = ledger.read_ledger(data_dir)
    if led.empty:
        return set()
    led = led[(led["table"] == manual.TABLE) & led["decision"].isin(["hold", "reject"])]
    return set(zip(led["key"], led["country"]))


def _attestation_problem(r, best: dict, withdrawn: set) -> str:
    try:
        k, h = manual.cell_key(r), manual.content_sha256(r)
    except (KeyError, ValueError):
        return "manual row unreadable for the attestation check"
    if h in best.get((k, r["iso"]), {}):
        return ""
    if (k, r["iso"]) in withdrawn:
        return "manual quote: attestation withdrawn by a ledger hold/reject (or this content never attested)"
    return "manual quote: no approved market_manual attestation for this content"


def export_gated_cds_snapshots(data_dir: Path, snapshot_ids=None, *, dry_run: bool = False, params=None,
                               **convert) -> CdsExportReport:
    """Append the gate-passed, attested cds rows of every stored snapshot (or only of `snapshot_ids`; every snapshot
    is still replayed as gate history, gated_history) to data/market/cds_snapshots.csv. `params` is a
    gate.GateParams; `convert` goes to schema.to_cds_snapshots (currency, doc_clauses, source_order). Raises
    FileNotFoundError when no snapshot exists and ValueError for an unknown snapshot id."""
    data_dir = Path(data_dir)
    ix = list_market_snapshots(data_dir)
    if ix.empty:
        raise FileNotFoundError(f"no market snapshot under {snapshot_root(data_dir)}; import one (docs/runbooks/A-market-data.md)")
    wanted = set(ix["snapshot_id"]) if snapshot_ids is None else {str(s) for s in snapshot_ids}
    unknown = sorted(wanted - set(ix["snapshot_id"]))
    if unknown:
        raise ValueError(f"unknown snapshot ids {unknown}")
    exported = _exported_keys(data_dir)
    dropped, examined, kept, appended = [], [], 0, 0
    for g in gated_history(data_dir, params=params):
        cds = g.rows["instrument"] == "cds"
        if g.snapshot_id not in wanted or not cds.any():
            continue
        examined.append(g.snapshot_id)
        for i in g.rows.index[cds & ~g.passed]:
            r = g.rows.loc[i]
            check, why = ("gate", f"gate hold: {g.held[i]}") if g.held[i] else ("attestation", g.unattested[i])
            dropped.append({**{c: r[c] for c in DROPPED_COLUMNS[:9]}, "check": check, "reason": why,
                            "already_in_file": _in_file(r, exported)})
        ok = g.rows[cds & g.passed]
        kept += len(ok)
        if len(ok):
            appended += _append_cds_snapshots(data_dir, ok, dry_run=dry_run, **convert)
    return CdsExportReport(appended=appended, kept=kept, dropped=pd.DataFrame(dropped, columns=DROPPED_COLUMNS),
                           snapshots=examined, dry_run=dry_run, path=cds_snapshots_path(data_dir))


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.market.cds_export",
                                 description="Gated export of saved CDS quotes to data/market/cds_snapshots.csv "
                                             "(market gate + manual-quote attestation; SEC-A-003 M1).")
    ap.add_argument("--data", default="data", help="data directory (default: data)")
    ap.add_argument("--snapshot", action="append", help="export only this snapshot id (repeatable; default: all)")
    ap.add_argument("--dry-run", action="store_true", help="report only, write nothing")
    ap.add_argument("--top", type=int, default=50, help="dropped rows to print (default 50)")
    a = ap.parse_args(argv)
    try:
        rep = export_gated_cds_snapshots(Path(a.data), a.snapshot, dry_run=a.dry_run)
    except (FileNotFoundError, ValueError, MarketDataError) as e:
        print(f"cds_export: {e}", file=sys.stderr)
        return 2
    print(rep.summary())
    if len(rep.dropped):
        print(rep.dropped.head(a.top).to_string(index=False))
    return 0


if __name__ == "__main__":
    sys.exit(main())
