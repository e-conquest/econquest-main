"""Market data (epic A7): vendor-neutral schema, point-in-time snapshots, vendor CSV importers, attested manual
entry, the market quality gate, free public sources (public.py: FRED/ALFRED, ECB YC, BIS policy rates) and
CIP-derived FX forwards (forwards.py, spot from BIS WS_XRU or the ECB reference rates since EQ-A-0040). See econquest/ingestion/market/schema.py for the contract and
docs/runbooks/A-market-data.md for operation."""
from econquest.ingestion.market.schema import (CDS_QUOTES_COLUMNS, FIELDS, INSTRUMENTS, KEY, MARKET_COLUMNS,
                                               MarketDataError, to_cds_quotes, validate_market)
from econquest.ingestion.market.store import (export_cds_snapshots, latest_market, list_market_snapshots,
                                              market_history, read_market_snapshot, save_market_snapshot)

# public.py and forwards.py are CLIs (python -m ...): exported lazily so running them does not import them twice
_LAZY = {"fetch_ecb": "public", "fetch_fred": "public", "bis_policy_rows": "public", "save_public": "public",
         "derive_cip_forwards": "forwards", "spot_from_bis_xru": "forwards", "spot_from_ecb_exr": "forwards",
         "spot_from_yahoo_raw": "forwards"}


def __getattr__(name):
    if name in _LAZY:
        import importlib
        return getattr(importlib.import_module(f"{__name__}.{_LAZY[name]}"), name)
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")

__all__ = ["CDS_QUOTES_COLUMNS", "FIELDS", "INSTRUMENTS", "KEY", "MARKET_COLUMNS", "MarketDataError", "to_cds_quotes",
           "validate_market", "latest_market", "list_market_snapshots", "market_history", "read_market_snapshot",
           "save_market_snapshot", "export_cds_snapshots", "fetch_ecb", "fetch_fred", "bis_policy_rows", "save_public", "derive_cip_forwards",
           "spot_from_bis_xru", "spot_from_ecb_exr", "spot_from_yahoo_raw"]
