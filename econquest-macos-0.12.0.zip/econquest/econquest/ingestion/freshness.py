"""Freshness SLA per series (EQ-A-0052): how old each live series may be, and a checker that reports breaches.

The SLA table is data/live/freshness_sla.csv (SLA_COLUMNS), one row per series id (an Inputs indicator id such as
"2.12" or a Country Profile key such as "policy"). It is generated, never hand-edited: `derive_sla` builds it from the
staleness rules that already exist in the code, and `python -m econquest.ingestion.freshness sla --write` writes it.
`sla --check` exits 1 when the file on disk differs from what the rules give (a rule changed and the file was not
regenerated, or someone edited it).

Where each limit comes from (column `basis`):
  BIS        feeds.BIS_STALE_DAYS, the quality gate's EQ-A-0044 rule by frequency: daily 30, monthly 92, quarterly
             275 days between the end of the last observation period and the reference date (2.12 EER monthly,
             5.9 credit gap quarterly, 5.13 / policy policy rate daily).
  World Bank the gate's rule `stale_years=3` (feeds.quality_gate): a latest annual period more than 3 years before the
             reference year is stale. As days from the end of the last period that is 1096 (31 Dec of year t-3 to
             31 Dec of year t across one leap day; within a day of the gate's calendar-year rule otherwise).
             Applied to the WB_STALE_SERIES ids and, by frequency (annual), to the WGI ids 3.4 / 3.5, which the gate
             does not check.
  Official FX fx3m is a daily BIS WS_XRU (else ECB EXR) series: the BIS daily rule, 30 days, by frequency.
  IMF WEO    annual periods that run into projection years, so an observation age means nothing. The SLA is on the
             pull instead (measure `retrieval`): WEO is released twice a year (Apr/Oct, data/panel/
             coverage_source_map.csv frequency "semi-annual"), so a pull older than one release cycle (183 days) plus
             a 31-day release margin (214 days) has very likely missed a WEO. No gate rule exists for this: it is a
             Team A operating parameter, set by AGENT-08 2026-10-24.
Severity: high when coverage_source_map.csv notes the id as engine-required, medium for any other Inputs id, low for
Country Profile fields.

The checker reads the current pull (data/live/provenance.csv and the raw_<feed>.csv beside it) or, with --vintage, a
saved vintage folder, and never writes anything. For each live cell with an SLA row:
  observation  age = reference date - end of the last observation period of the cell's raw series for its country
               (periods YYYY, YYYY-MM, YYYY-Qn, YYYY-MM-DD; fx3m by currency, since BIS and ECB rows are not keyed by
               ISO3)
  retrieval    age = reference date - the cell's provenance `retrieved` date
  fx3m         EQ-A-0119: when the pull folder holds no raw_bis_xru / raw_ecb_exr row for the currency and the cell's
               provenance series says it was computed from data/market_history/prices.csv build <id> (the official FX
               history, EQ-A-0054 / EQ-A-0112), the last observation is the last priced date of column USD<ccy> in
               that file, but only while prices.provenance.json still names the same build (otherwise unknown).
status ok, breach (age > max_age_days) or unknown (no raw observation or no date to measure); gate_status is the
pull's review.csv status for the cell (a breach on a cell the gate already holds is not applied, but still reported). The reference date is
--as-of, default today (UTC): the question is how stale the data is now, not at pull time (the gate answers that).

    python -m econquest.ingestion.freshness check [--json] [--all] [--min-severity high] [--strict] [--as-of D]
                                                  [--vintage ID] [--data data]
    python -m econquest.ingestion.freshness sla [--write | --check]
    python -m econquest.ingestion.freshness prices [--json] [--as-of D] [--data data]

`prices` (EQ-A-0119) is the data-side check of the daily record's input, data/market_history/prices.csv: each USD<ccy>
column's last priced date against the fx3m SLA row (BIS daily rule, 30 days), plus the date `econquest record` will
mark (rules.market.complete_date: the last weekday with at least 60% of columns priced) and how many weekdays it
trails the reference date. It reads only and is not part of `check`, so the data_ops job's exit code is unchanged.

Exit codes of `check`: 0 no breach, 2 breaches (unknown counts as a breach only with --strict), 1 bad input
(no provenance.csv, unreadable SLA file).
"""
from __future__ import annotations

import argparse
import datetime as dt
import io
import json
import re
import sys
from pathlib import Path

import pandas as pd

from .feeds import BIS_STALE_DAYS, BIS_STALE_SERIES, WB_STALE_SERIES, WEO_SOURCE_SERIES, WGI_FAMILIES, _period_end
from .sources import read_csv_keep_na_code

SLA_PATH = Path("live") / "freshness_sla.csv"            # relative to the data folder
SLA_COLUMNS = ["series_id", "table", "source", "series", "frequency", "measure", "max_age_days", "severity",
               "raw_file", "raw_series", "basis"]
CHECK_COLUMNS = ["table", "key", "country", "iso", "source", "series", "frequency", "measure", "last_date",
                 "ref_date", "age_days", "max_age_days", "severity", "status", "detail", "gate_status"]
SEVERITIES = ("high", "medium", "low")
MEASURES = ("observation", "retrieval")
STATUSES = ("ok", "breach", "unknown")
EXIT_OK, EXIT_ERROR, EXIT_BREACH = 0, 1, 2

PROFILE_KEYS = ("pop", "exports", "reserves", "fx3m", "policy", "equity_vol")
FREQ_NAME = {"D": "daily", "M": "monthly", "Q": "quarterly", "A": "annual"}
BIS_SERIES_FREQ = {"POLICY_RATE": "D", "EER_REAL_BROAD": "M", "CREDIT_GAP": "Q"}   # feeds EQ-A-0044 comment
GATE_STALE_YEARS = 3                                     # feeds.quality_gate(stale_years=3)
WB_ANNUAL_MAX_DAYS = 1096                                # 31 Dec t-3 -> 31 Dec t (see module docstring)
WEO_CYCLE_DAYS = 183                                     # semi-annual release (Apr/Oct)
WEO_RELEASE_MARGIN_DAYS = 31
WEO_MAX_DAYS = WEO_CYCLE_DAYS + WEO_RELEASE_MARGIN_DAYS
WGI_IDS = ("3.4", "3.5")
FX_KEY = "fx3m"
PRICES_PATH = Path("market_history") / "prices.csv"     # relative to the data folder (EQ-A-0054 official FX history)
PRICES_SIDECAR = Path("market_history") / "prices.provenance.json"
_PRICES_BUILD = re.compile(r"market_history/prices\.csv build (\S+?-[0-9a-f]{8})\b")
PRICE_COLUMNS = ["column", "last_date", "ref_date", "age_days", "max_age_days", "status"]
CCY = "{ccy}"                                            # placeholder in raw_series: the country's currency


# ------------------------------------------------------------------------------------------------ the SLA table

def _engine_required(data_dir: Path) -> set[str]:
    p = Path(data_dir) / "panel" / "coverage_source_map.csv"
    if not p.is_file():
        return set()
    m = pd.read_csv(p, dtype=str, keep_default_na=False)
    if not {"id", "notes"} <= set(m.columns):
        return set()
    return set(m.loc[m["notes"].str.contains("engine-required", case=False, regex=False), "id"])


def _table_of(series_id: str) -> str:
    return "Country Profile" if series_id in PROFILE_KEYS else "Inputs"


def _severity(series_id: str, engine: set[str]) -> str:
    if _table_of(series_id) == "Country Profile":
        return "low"
    return "high" if series_id in engine else "medium"


def derive_sla(data_dir: str | Path = "data") -> pd.DataFrame:
    """The SLA table (SLA_COLUMNS) from the existing staleness rules; see the module docstring for each limit."""
    d = Path(data_dir)
    engine = _engine_required(d)
    rows = []

    def add(sid, source, series, freq, measure, max_days, raw_file, raw_series, basis):
        rows.append({"series_id": sid, "table": _table_of(sid), "source": source, "series": series,
                     "frequency": FREQ_NAME.get(freq, freq), "measure": measure, "max_age_days": int(max_days),
                     "severity": _severity(sid, engine), "raw_file": raw_file, "raw_series": raw_series,
                     "basis": basis})

    for sid, series in WEO_SOURCE_SERIES.items():
        add(sid, "IMF WEO", series, "semi-annual", "retrieval", WEO_MAX_DAYS, "", "",
            f"Team A operating parameter, set by AGENT-08 2026-10-24 (no gate rule): WEO released Apr/Oct "
            f"(coverage_source_map frequency semi-annual); one release cycle {WEO_CYCLE_DAYS} days + "
            f"{WEO_RELEASE_MARGIN_DAYS} days margin since the pull")
    for sid, series in WB_STALE_SERIES.items():
        add(sid, "World Bank", series, "A", "observation", WB_ANNUAL_MAX_DAYS, "worldbank", series,
            f"quality gate stale_years={GATE_STALE_YEARS} (feeds.WB_STALE_SERIES) as days from the end of the last "
            f"annual period")
    wgi = "|".join(s for fam in WGI_FAMILIES for s in fam)
    for sid in WGI_IDS:
        add(sid, "World Bank WGI", wgi, "A", "observation", WB_ANNUAL_MAX_DAYS, "worldbank", wgi,
            f"World Bank annual rule (stale_years={GATE_STALE_YEARS}) applied by frequency; not gate-checked today")
    for sid, series in BIS_STALE_SERIES.items():
        f = BIS_SERIES_FREQ[series]
        add(sid, "BIS", series, f, "observation", BIS_STALE_DAYS[f], "bis", series,
            f"quality gate BIS rule EQ-A-0044 (feeds.BIS_STALE_DAYS {f}={BIS_STALE_DAYS[f]})")
    add(FX_KEY, "BIS WS_XRU, else ECB EXR", f"{CCY}_PER_USD (BIS) | {CCY}_PER_EUR (ECB)", "D", "observation",
        BIS_STALE_DAYS["D"], "bis_xru|ecb_exr", f"{CCY}_PER_USD|{CCY}_PER_EUR",
        f"BIS daily rule (feeds.BIS_STALE_DAYS D={BIS_STALE_DAYS['D']}) applied by frequency to the official FX series")
    out = pd.DataFrame(rows, columns=SLA_COLUMNS)
    return out.sort_values(["table", "series_id"], key=lambda s: s.map(_idkey) if s.name == "series_id" else s,
                           ignore_index=True)


def _idkey(i):
    parts = str(i).split(".")
    return tuple((0, int(p)) if p.isdigit() else (1, p) for p in parts)


def sla_csv(df: pd.DataFrame) -> str:
    return df[SLA_COLUMNS].to_csv(index=False, lineterminator="\n")


def validate_sla(df: pd.DataFrame) -> pd.DataFrame:
    """Check an SLA table and return it typed. ValueError listing every problem."""
    missing = [c for c in SLA_COLUMNS if c not in df.columns]
    if missing:
        raise ValueError(f"freshness SLA lacks column(s) {missing}")
    out = df[SLA_COLUMNS].copy()
    problems = []
    days = pd.to_numeric(out["max_age_days"], errors="coerce")
    if days.isna().any() or (days <= 0).any():
        problems.append("max_age_days must be a positive whole number of days")
    for col, allowed in (("severity", SEVERITIES), ("measure", MEASURES)):
        bad = sorted(set(out[col]) - set(allowed))
        if bad:
            problems.append(f"{col} not in {allowed}: {bad}")
    if out.duplicated(["series_id", "measure"]).any():
        problems.append("duplicate (series_id, measure) rows")
    obs = out["measure"] == "observation"
    if (out.loc[obs, "raw_file"].str.strip() == "").any() or (out.loc[obs, "raw_series"].str.strip() == "").any():
        problems.append("an observation row needs raw_file and raw_series")
    if problems:
        raise ValueError("freshness SLA: " + "; ".join(problems))
    out["max_age_days"] = days.astype(int)
    return out


def load_sla(data_dir: str | Path = "data") -> pd.DataFrame:
    """data/live/freshness_sla.csv, validated. FileNotFoundError when it is missing (run `sla --write`)."""
    p = Path(data_dir) / SLA_PATH
    if not p.is_file():
        raise FileNotFoundError(f"{p} not found: run `python -m econquest.ingestion.freshness sla --write`")
    return validate_sla(pd.read_csv(p, dtype=str, keep_default_na=False))


def write_sla(data_dir: str | Path = "data") -> Path:
    p = Path(data_dir) / SLA_PATH
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(sla_csv(derive_sla(data_dir)))
    return p


def sla_drift(data_dir: str | Path = "data") -> str:
    """'' when data/live/freshness_sla.csv equals derive_sla, else a short description of the difference."""
    p = Path(data_dir) / SLA_PATH
    want = sla_csv(derive_sla(data_dir))
    if not p.is_file():
        return f"{p} missing"
    have = p.read_text()
    if have == want:
        return ""
    a = pd.read_csv(io.StringIO(have), dtype=str, keep_default_na=False)
    b = pd.read_csv(io.StringIO(want), dtype=str, keep_default_na=False)
    ids = sorted(set(a.get("series_id", [])) ^ set(b["series_id"])) if "series_id" in a.columns else []
    return f"{p} differs from the rules" + (f" (ids added/removed: {ids})" if ids else " (values or columns changed)")


# ------------------------------------------------------------------------------------------------ the checker

def period_end(period) -> dt.date | None:
    """Last day of a period 'YYYY', 'YYYY-MM', 'YYYY-Qn' or 'YYYY-MM-DD' (also 2024.0 from a numeric column)."""
    s = str(period).strip()
    m = re.fullmatch(r"(\d{4})(?:\.0+)?", s)
    if m:
        return dt.date(int(m[1]), 12, 31)
    e = _period_end(s)
    return e[0] if e else None


class _Source:
    """The files of one pull: data/live (current) or a vintage folder. Raw tables are read once, lazily."""

    def __init__(self, folder: Path, data_dir: Path | None = None):
        self.folder = folder
        self.data_dir = data_dir
        self._raw: dict[str, pd.DataFrame | None] = {}
        self._prices: tuple | None = None

    def provenance(self) -> pd.DataFrame:
        p = self.folder / "provenance.csv"
        if not p.is_file():
            raise FileNotFoundError(f"{p} not found: no live pull to check")
        return pd.read_csv(p, dtype=str, keep_default_na=False)

    def gate(self) -> dict:
        """(table, key, country) -> the gate status in the pull's review.csv ('' when there is none)."""
        p = self.folder / "review.csv"
        if not p.is_file():
            return {}
        r = pd.read_csv(p, dtype=str, keep_default_na=False)
        if not {"table", "key", "country", "status"} <= set(r.columns):
            return {}
        return {(t, k, c): s for t, k, c, s in zip(r["table"], r["key"], r["country"], r["status"])}

    def raw(self, name: str) -> pd.DataFrame | None:
        if name not in self._raw:
            p = self.folder / f"raw_{name}.csv"
            self._raw[name] = (pd.read_csv(p, dtype=str, keep_default_na=False, usecols=lambda c: c in ("iso", "series", "period"))
                               if p.is_file() else None)
        return self._raw[name]


def load_prices_history(data_dir: Path) -> tuple[pd.DataFrame | None, str]:
    """(data/market_history/prices.csv indexed by date, the sidecar's vintage_id) or (None, why not)."""
    p = Path(data_dir) / PRICES_PATH
    if not p.is_file():
        return None, f"no {PRICES_PATH.as_posix()}"
    px = pd.read_csv(p, index_col=0)
    px.index = pd.to_datetime(px.index, errors="coerce")
    px = px[px.index.notna()].sort_index()
    build = ""
    side = Path(data_dir) / PRICES_SIDECAR
    if side.is_file():
        try:
            build = str(json.loads(side.read_text()).get("vintage_id", ""))
        except (ValueError, OSError):
            build = ""
    return px, build


def _prices_observation(src: _Source, series_text: str, ccy: str) -> tuple[dt.date | None, str]:
    """fx3m computed from the official FX history (EQ-A-0119): last priced date of USD<ccy> in the build the
    provenance names. (None, why) when the cell does not name a build, or the installed prices.csv is another build."""
    m = _PRICES_BUILD.search(series_text or "")
    if not m or not ccy or src.data_dir is None:
        return None, ""
    if src._prices is None:
        src._prices = load_prices_history(src.data_dir)
    px, build = src._prices
    if px is None:
        return None, build
    if build != m[1]:
        return None, (f"provenance names prices.csv build {m[1]}, the installed build is {build or 'unknown'}: "
                      f"age not measurable")
    col = f"USD{ccy}"
    if col not in px.columns:
        return None, f"no column {col} in {PRICES_PATH.as_posix()}"
    last = pd.to_numeric(px[col], errors="coerce").dropna()
    if last.empty:
        return None, f"column {col} in {PRICES_PATH.as_posix()} has no price"
    return last.index.max().date(), f"{PRICES_PATH.as_posix()} {col} (build {build})"


def _last_observation(src: _Source, sla: dict, iso: str, ccy: str) -> tuple[dt.date | None, str]:
    """(end of the last observation period, where it was found) for one cell, or (None, why not)."""
    files = [f for f in sla["raw_file"].split("|") if f]
    pats = [s for s in sla["raw_series"].split("|") if s]
    best, where, looked = None, "", []
    for f in files:
        raw = src.raw(f)
        looked.append(f"raw_{f}.csv")
        if raw is None or raw.empty:
            continue
        for pat in pats:
            if CCY in pat:
                if not ccy:
                    continue
                rows = raw[raw["series"] == pat.replace(CCY, ccy)]       # FX rows are keyed by currency, not ISO3
            else:
                rows = raw[(raw["iso"] == iso) & (raw["series"] == pat)]
            for p in rows["period"].unique():
                e = period_end(p)
                if e is not None and (best is None or e > best):
                    best, where = e, f"raw_{f}.csv {pat.replace(CCY, ccy)} {p}"
    return (best, where) if best else (None, f"no observation for {iso or ccy} in {', '.join(looked)}")


def _date(s) -> dt.date | None:
    t = pd.to_datetime(str(s or "").strip() or None, errors="coerce", utc=True)
    return None if pd.isna(t) else t.date()


def check_freshness(data_dir: str | Path = "data", as_of=None, vintage: str | None = None,
                    sla: pd.DataFrame | None = None) -> pd.DataFrame:
    """One row per (live cell, SLA row) with CHECK_COLUMNS. Reads data/live (or the vintage folder); writes nothing.
    `sla` defaults to load_sla(data_dir)."""
    d = Path(data_dir)
    if vintage:
        from .feeds import vintage_path
        folder = vintage_path(d, vintage)
    else:
        folder = d / "live"
    ref = pd.Timestamp(as_of).date() if as_of is not None else dt.datetime.now(dt.timezone.utc).date()
    sla = validate_sla(sla) if sla is not None else load_sla(d)
    src = _Source(folder, d)
    prov = src.provenance()
    gate = src.gate()
    cty = read_csv_keep_na_code(d / "countries.csv", dtype=str)
    iso_of = dict(zip(cty["country"], cty["iso"]))
    ccy_of = dict(zip(cty["country"], cty["currency"])) if "currency" in cty.columns else {}
    by_id: dict[str, list[dict]] = {}
    for r in sla.to_dict("records"):
        by_id.setdefault(r["series_id"], []).append(r)
    rows = []
    for c in prov.to_dict("records"):
        key = str(c.get("key", ""))
        for s in by_id.get(key, []):
            if s["table"] != c.get("table"):
                continue
            iso = iso_of.get(c.get("country"), "")
            row = {"table": c["table"], "key": key, "country": c.get("country", ""), "iso": iso,
                   "source": c.get("source", ""), "series": c.get("series", ""), "frequency": s["frequency"],
                   "measure": s["measure"], "ref_date": ref.isoformat(), "max_age_days": int(s["max_age_days"]),
                   "severity": s["severity"], "gate_status": gate.get((c["table"], key, c.get("country", "")), "")}
            if s["measure"] == "retrieval":
                last = _date(c.get("retrieved"))
                where = "provenance retrieved" if last else "no retrieved date in provenance"
            else:
                ccy = ccy_of.get(c.get("country"), "")
                last, where = _last_observation(src, s, iso, ccy)
                if last is None and key == FX_KEY:
                    plast, pwhere = _prices_observation(src, c.get("series", ""), ccy)
                    if plast is not None:
                        last, where = plast, pwhere
                    elif pwhere:
                        where = f"{where}; {pwhere}"
            if last is None:
                row.update(last_date="", age_days=None, status="unknown", detail=where)
            else:
                age = (ref - last).days
                breach = age > int(s["max_age_days"])
                row.update(last_date=last.isoformat(), age_days=age, status="breach" if breach else "ok",
                           detail=(f"{where}: {age} days old, limit {s['max_age_days']} ({s['frequency']})"
                                   if breach else where))
            rows.append(row)
    out = pd.DataFrame(rows, columns=CHECK_COLUMNS)
    out["age_days"] = pd.to_numeric(out["age_days"], errors="coerce").astype("Int64")
    out.attrs.update(ref_date=ref.isoformat(), folder=str(folder))
    return out


def breaches(result: pd.DataFrame, min_severity: str = "low", strict: bool = False) -> pd.DataFrame:
    """Rows that fail: status breach (and unknown with strict) at or above min_severity."""
    rank = {s: i for i, s in enumerate(SEVERITIES)}               # high 0 .. low 2
    sev_ok = result["severity"].map(rank) <= rank[min_severity]
    bad = result["status"].isin(("breach", "unknown") if strict else ("breach",))
    return result[sev_ok & bad]


def summary(result: pd.DataFrame, failing: pd.DataFrame) -> dict:
    by_status = {k: int(v) for k, v in result["status"].value_counts().items()}
    by_series = (failing.groupby(["table", "key", "severity"]).size().rename("cells").reset_index()
                 .to_dict("records") if len(failing) else [])
    return {"ref_date": result.attrs.get("ref_date", ""), "folder": result.attrs.get("folder", ""),
            "cells_checked": int(len(result)), "by_status": by_status, "failing": int(len(failing)),
            "failing_by_series": by_series}


def check_prices(data_dir: str | Path = "data", as_of=None, sla: pd.DataFrame | None = None) -> pd.DataFrame:
    """EQ-A-0119: freshness of the daily record's input, data/market_history/prices.csv. One row per column
    (PRICE_COLUMNS) against the fx3m SLA row's max_age_days. attrs: ref_date, build, record_date (the date
    `econquest record` marks, rules.market.complete_date on weekdays) and record_lag_weekdays."""
    from econquest.rules.market import complete_date          # C15 (HO-20261026-A-B-004, EQ-A-0129)
    d = Path(data_dir)
    ref = pd.Timestamp(as_of).date() if as_of is not None else dt.datetime.now(dt.timezone.utc).date()
    sla = validate_sla(sla) if sla is not None else load_sla(d)
    fx = sla[sla["series_id"] == FX_KEY]
    if fx.empty:
        raise ValueError(f"no {FX_KEY} row in {SLA_PATH.as_posix()}")
    limit = int(fx["max_age_days"].iloc[0])
    px, build = load_prices_history(d)
    if px is None:
        raise FileNotFoundError(f"{d / PRICES_PATH}: {build}")
    px = px.apply(pd.to_numeric, errors="coerce")
    px = px[px.index.date <= ref]
    rows = []
    for col in px.columns:
        s = px[col].dropna()
        if s.empty:
            rows.append({"column": col, "last_date": "", "ref_date": ref.isoformat(), "age_days": None,
                         "max_age_days": limit, "status": "unknown"})
            continue
        last = s.index.max().date()
        age = (ref - last).days
        rows.append({"column": col, "last_date": last.isoformat(), "ref_date": ref.isoformat(), "age_days": age,
                     "max_age_days": limit, "status": "breach" if age > limit else "ok"})
    out = pd.DataFrame(rows, columns=PRICE_COLUMNS)
    out["age_days"] = pd.to_numeric(out["age_days"], errors="coerce").astype("Int64")
    wd = px[px.index.dayofweek < 5]
    rec = complete_date(wd).date() if len(wd) else None
    lag = int(len(pd.bdate_range(rec, ref)) - 1) if rec else None
    out.attrs.update(ref_date=ref.isoformat(), build=build, record_date=rec.isoformat() if rec else "",
                     record_lag_weekdays=lag)
    return out


# ------------------------------------------------------------------------------------------------ CLI

def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.freshness",
                                 description="Freshness SLA per series (EQ-A-0052): check live data against "
                                             "data/live/freshness_sla.csv, or regenerate that table")
    sub = ap.add_subparsers(dest="cmd", required=True)
    c = sub.add_parser("check", help="report cells whose series is older than its SLA; exit 0 clear, 2 breaches")
    c.add_argument("--data", default="data", help="econquest data folder (default: data)")
    c.add_argument("--vintage", default=None, help="check a saved vintage instead of data/live")
    c.add_argument("--as-of", default=None, help="reference date YYYY-MM-DD (default: today UTC)")
    c.add_argument("--json", action="store_true", help="print a JSON summary plus the failing cells")
    c.add_argument("--all", action="store_true", help="list every checked cell, not only the failing ones")
    c.add_argument("--min-severity", choices=SEVERITIES, default="low", help="fail only at or above this severity")
    c.add_argument("--strict", action="store_true", help="a cell that cannot be measured (unknown) also fails")
    s = sub.add_parser("sla", help="print the SLA table derived from the staleness rules")
    g = s.add_mutually_exclusive_group()
    g.add_argument("--write", action="store_true", help="(re)write data/live/freshness_sla.csv")
    g.add_argument("--check", action="store_true", help="exit 1 when data/live/freshness_sla.csv differs from the rules")
    s.add_argument("--data", default="data", help="econquest data folder (default: data)")
    pr = sub.add_parser("prices", help="freshness of the daily record's input data/market_history/prices.csv; "
                                       "exit 0 clear, 2 breaches")
    pr.add_argument("--data", default="data", help="econquest data folder (default: data)")
    pr.add_argument("--as-of", default=None, help="reference date YYYY-MM-DD (default: today UTC)")
    pr.add_argument("--json", action="store_true", help="print JSON")
    a = ap.parse_args(argv)

    if a.cmd == "prices":
        try:
            res = check_prices(a.data, as_of=a.as_of)
        except (FileNotFoundError, ValueError) as e:
            print(f"freshness prices: {e}", file=sys.stderr)
            return EXIT_ERROR
        bad = res[res["status"] == "breach"]
        if a.json:
            print(json.dumps({**res.attrs, "breaches": int(len(bad)),
                              "columns": json.loads(res.to_json(orient="records"))}, indent=1))
        else:
            at = res.attrs
            print(f"prices.csv at {at['ref_date']} (build {at['build'] or 'unknown'}): {len(res)} columns, "
                  f"{len(bad)} breach(es); `econquest record` would mark {at['record_date'] or '-'} "
                  f"({at['record_lag_weekdays']} weekday(s) before the reference date)")
            for r in res.itertuples(index=False):
                age = "" if pd.isna(r.age_days) else f"{int(r.age_days)}d"
                print(f"  [{r.status}] {r.column}: last {r.last_date or '-'} {age} (limit {r.max_age_days}d)")
        return EXIT_BREACH if len(bad) else EXIT_OK

    if a.cmd == "sla":
        if a.write:
            print(f"wrote {write_sla(a.data)}")
            return EXIT_OK
        if a.check:
            why = sla_drift(a.data)
            print(why or f"{Path(a.data) / SLA_PATH} matches the staleness rules")
            return EXIT_ERROR if why else EXIT_OK
        sys.stdout.write(sla_csv(derive_sla(a.data)))
        return EXIT_OK

    try:
        res = check_freshness(a.data, as_of=a.as_of, vintage=a.vintage)
    except (FileNotFoundError, ValueError) as e:
        print(f"freshness check: {e}", file=sys.stderr)
        return EXIT_ERROR
    fail = breaches(res, a.min_severity, a.strict)
    shown = res if a.all else fail
    summ = summary(res, fail)
    if a.json:
        rows = json.loads(shown.to_json(orient="records"))
        print(json.dumps({**summ, "cells": rows}, indent=1))
    else:
        st = ", ".join(f"{k} {v}" for k, v in sorted(summ["by_status"].items())) or "none"
        print(f"freshness at {summ['ref_date']} ({summ['folder']}): {summ['cells_checked']} cells checked ({st}); "
              f"{summ['failing']} failing (min severity {a.min_severity}{', strict' if a.strict else ''})")
        for r in shown.itertuples(index=False):
            age = "" if pd.isna(r.age_days) else f"{int(r.age_days)}d"
            print(f"  [{r.status}] {r.severity:6} {r.table} {r.key} {r.country}: last {r.last_date or '-'} {age} "
                  f"(limit {r.max_age_days}d, {r.measure}) {r.detail}")
    return EXIT_BREACH if len(fail) else EXIT_OK


if __name__ == "__main__":
    sys.exit(main())
