"""The live pull of the text corpus (EQ-A-0131). Runs on Sam's Mac only (runbook docs/runbooks/A-text-corpus.md);
this cloud cannot reach any publisher, and the tests drive it with an injected fetcher on SYNTHETIC fixtures.

For each source in the registry:
    manual       nothing is requested; reported as parked with the registry note
    rss          the feed is read (parse.parse_feed)
    html_index   the listing page is read (parse.parse_html_index with the source's link_re)
then for each entry, in feed order, up to max_docs per source:
    - IMF press releases keep only entries whose title or summary names a desk name (registry.countries_named)
    - entries dated outside [since, until] are skipped; undated entries are kept until the article gives a date
    - a date-only publication stamp (23:59:59 in the publisher's zone) later than the read is capped at the read
    - URLs already stored are skipped (refresh=True re-reads them: a changed text becomes a new version)
    - PDF links are skipped (no PDF text extraction in this ticket; counted as pdf)
    - links to a host outside the source's allow-list are skipped without a request (off-site host)
    - the article page is read through the same polite fetcher (host allow-list, robots.txt, rate limit) and parsed
      (parse.parse_article); the document is stored with retrieved_utc = the time of that read
dry_run=True reads indexes only (no article requests, nothing stored): the first Mac step, to check layouts.

Each run appends one line to <root>/pulls.jsonl: start/end time, arguments, per-source counts and errors (no
credentials exist for these sources; URLs are logged without query strings).
"""
from __future__ import annotations

import json
import urllib.parse
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Callable, Iterable

from econquest.ingestion.events.base import FetchError, TransientFetchError

from . import parse as P
from .fetch import PoliteFetcher, RequestCapReached
from .registry import LANG_RE, SOURCES, TextSource, countries_named
from .store import CorpusError, CorpusStore, utc_now

DEFAULT_MAX_DOCS = 50
PULL_LOG = "pulls.jsonl"


@dataclass
class SourceReport:
    source: str
    status: str = "ok"             # ok | parked | error
    listed: int = 0
    in_scope: int = 0
    stored: int = 0
    skipped: dict = field(default_factory=dict)
    error: str = ""

    def skip(self, why: str):
        self.skipped[why] = self.skipped.get(why, 0) + 1


@dataclass
class PullReport:
    started_utc: str
    finished_utc: str = ""
    dry_run: bool = False
    root: str = ""
    sources: list = field(default_factory=list)

    @property
    def stored(self) -> int:
        return sum(s.stored for s in self.sources)

    def format(self) -> str:
        lines = [f"text corpus pull {'(dry run) ' if self.dry_run else ''}{self.started_utc} -> {self.finished_utc}",
                 f"{'source':<18}{'status':<8}{'listed':>7}{'scope':>7}{'stored':>7}  skipped / error"]
        for s in self.sources:
            extra = s.error or ", ".join(f"{k} {v}" for k, v in sorted(s.skipped.items()))
            lines.append(f"{s.source:<18}{s.status:<8}{s.listed:>7}{s.in_scope:>7}{s.stored:>7}  {extra}")
        lines.append(f"stored {self.stored} document version(s) in {self.root}")
        return "\n".join(lines)


def _is_pdf(url: str) -> bool:
    return urllib.parse.urlsplit(url).path.lower().endswith(".pdf")


def _within(stamp: str | None, lo: str | None, hi: str | None) -> bool:
    if stamp is None:
        return True
    return (lo is None or stamp >= lo) and (hi is None or stamp <= hi)


def _bound(v, end: bool) -> str | None:
    from .corpus import _stamp
    return _stamp(v, end)


def pull(root, *, sources: Iterable[str] | None = None, since=None, until=None, fetcher=None,
         polite: PoliteFetcher | None = None, now: Callable[[], str] = utc_now, max_docs: int = DEFAULT_MAX_DOCS,
         dry_run: bool = False, refresh: bool = False, synthetic: bool = False,
         licence_ids: set | None = None) -> PullReport:
    keys = list(sources) if sources is not None else list(SOURCES)
    unknown = [k for k in keys if k not in SOURCES]
    if unknown:
        raise ValueError(f"unknown sources {unknown}")
    polite = polite or PoliteFetcher(fetcher)
    lo, hi = _bound(since, False), _bound(until, True)
    store = None if dry_run else _LazyStore(root, synthetic, licence_ids)
    rep = PullReport(started_utc=now(), dry_run=dry_run, root=str(root))
    for k in keys:
        src = SOURCES[k]
        sr = SourceReport(k)
        rep.sources.append(sr)
        if src.index_format == "manual":
            sr.status, sr.error = "parked", f"manual source: {src.notes}"
            continue
        try:
            _pull_source(src, sr, polite, store, lo, hi, now, max_docs, dry_run, refresh, synthetic)
        except RequestCapReached as e:
            sr.status, sr.error = "error", str(e)
            break
        except (FetchError, TransientFetchError, P.ParseError) as e:
            sr.status, sr.error = "error", f"{type(e).__name__}: {e}"
    rep.finished_utc = now()
    if store is not None and store.opened:
        with open(Path(root) / PULL_LOG, "a", encoding="utf-8") as fh:
            fh.write(json.dumps({**{k: v for k, v in asdict(rep).items() if k != "sources"},
                                 "since": lo, "until": hi, "max_docs": max_docs, "refresh": refresh,
                                 "sources": [asdict(s) for s in rep.sources],
                                 "requests": [list(x) for x in polite.log]}) + "\n")
    return rep


class _LazyStore:
    """SEC-A-015 T-L2: the corpus folder (default data/corpus/) is created on the first stored document, not before
    the first request, so a run where nothing answers (this cloud, where every publisher is refused) writes nothing
    into data/. An existing store is opened (and checked) at once; a synthetic store inside the repo's data/ is still
    refused before any request."""

    def __init__(self, root, synthetic: bool, licence_ids):
        from .store import REPO_DATA, _inside
        self._root, self._synthetic, self._ids = root, synthetic, licence_ids
        self._s = None
        if CorpusStore.exists(root):
            self._s = CorpusStore(root, synthetic=synthetic, licence_ids=licence_ids)
        elif synthetic and _inside(Path(root), REPO_DATA):
            raise CorpusError(f"a synthetic corpus may not live under {REPO_DATA} (synthetic text never enters data/)")

    @property
    def opened(self) -> bool:
        return self._s is not None

    def rows(self) -> list[dict]:
        return self._s.rows() if self._s is not None else []

    def known_urls(self, source=None) -> set:
        return self._s.known_urls(source) if self._s is not None else set()

    def add(self, **kw) -> dict:
        if self._s is None:
            self._s = CorpusStore(self._root, synthetic=self._synthetic, create=True, licence_ids=self._ids)
        return self._s.add(**kw)


def _pull_source(src: TextSource, sr: SourceReport, polite: PoliteFetcher, store: CorpusStore | None, lo, hi, now,
                 max_docs, dry_run, refresh, synthetic) -> None:
    body = polite.get(src.index_url, src.hosts)
    if src.index_format == "rss":
        entries = P.parse_feed(body, src.index_url)
    else:
        entries = P.parse_html_index(body, src.index_url, src.link_re)
    sr.listed = len(entries)
    # IMF press releases and country pages link the same articles: an IMF URL stored by either is not read again
    known = set() if store is None else (
        {r["url"] for r in store.rows() if r["family"] == "imf"} if src.family == "imf" else store.known_urls(src.key))
    for e in entries:
        if src.iso3:
            iso3s = (src.iso3,)
        else:
            iso3s = countries_named(f"{e.title} {e.summary}")
            if not iso3s:
                sr.skip("not a desk name")
                continue
        stamp = P.to_utc(e.published, src.tz)
        if not _within(stamp[0] if stamp else None, lo, hi):
            sr.skip("outside window")
            continue
        if _is_pdf(e.url):
            sr.skip("pdf")
            continue
        if (urllib.parse.urlsplit(e.url).hostname or "").lower() not in src.hosts:
            sr.skip("off-site host")                     # never requested (PoliteFetcher would refuse it too)
            continue
        if e.url in known and not refresh:
            sr.skip("already stored")
            continue
        if sr.in_scope >= max_docs:
            sr.skip("over max_docs")
            continue
        sr.in_scope += 1
        if dry_run:
            continue
        try:
            page = polite.get(e.url, src.hosts)
        except RequestCapReached:
            raise
        except (FetchError, TransientFetchError) as err:
            sr.skip(f"article {type(err).__name__}")
            continue
        retrieved = now()
        try:
            art = P.parse_article(page, src.content)
        except P.ParseError:
            sr.skip("article layout")
            continue
        if stamp is None:
            stamp = P.to_utc(art.published, src.tz)
            if stamp is None:
                sr.skip("undated")
                continue
            if not _within(stamp[0], lo, hi):
                sr.skip("outside window")
                continue
        if stamp[1] == "date" and stamp[0] > retrieved:
            # ARCH-A-PI13 C-2: a date-only release read on its publication day is stamped 23:59:59 local, which is
            # after the read; the store refused it. It was published by the time we read it, so the read is the
            # upper bound (still the same day, so date-level as-of views are unchanged).
            stamp = (retrieved, "date")
        lang = next((x for x in (art.language, e.language.split("-")[0] if e.language else "", src.language)
                     if x and LANG_RE.fullmatch(x)), src.language)
        try:
            row = store.add(source=src.key, family=src.family, iso3s=iso3s, url=e.url, title=e.title or art.title,
                      published_utc=stamp[0], published_precision=stamp[1], retrieved_utc=retrieved, language=lang,
                      text=art.text, licence_id=src.licence_id, licence_tag=src.licence_tag, synthetic=synthetic,
                      layout_verified=src.layout_verified)
        except CorpusError as err:
            sr.skip(f"refused: {str(err)[:60]}")
            continue
        if row["retrieved_utc"] != retrieved:              # same text already stored (a refresh with no change)
            sr.skip("unchanged")
            continue
        sr.stored += 1
