"""Command line for the text corpus (EQ-A-0131). No cli.py change: run as a module.

    python -m econquest.ingestion.text sources                          # the registry: format, index URL, licence row
    python -m econquest.ingestion.text pull --dry-run [--only K,K]      # read indexes only (layout check), store nothing
    python -m econquest.ingestion.text pull --since 2015-01-01 [--until D] [--only K,K] [--max-docs N] [--refresh]
    python -m econquest.ingestion.text status [--as-of D]               # documents per desk name and family
    python -m econquest.ingestion.text verify                           # every text file against its sha256

--root defaults to data/corpus/ (the approved store). The pull needs the publishers' sites: Sam's Mac only.
"""
from __future__ import annotations

import argparse
import sys

from . import corpus
from .registry import SOURCES


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.text")
    ap.add_argument("--root", default=str(corpus.DEFAULT_ROOT))
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("sources")
    p = sub.add_parser("pull")
    p.add_argument("--only", default="", help="comma-separated source keys (default: all)")
    p.add_argument("--since")
    p.add_argument("--until")
    p.add_argument("--max-docs", type=int, default=50)
    p.add_argument("--min-interval", type=float, default=5.0, help="seconds between requests to one host (min 2)")
    p.add_argument("--dry-run", action="store_true")
    p.add_argument("--refresh", action="store_true")
    s = sub.add_parser("status")
    s.add_argument("--as-of")
    sub.add_parser("verify")
    a = ap.parse_args(argv)

    if a.cmd == "sources":
        print(f"{'key':<18}{'iso3':<6}{'format':<12}{'licence row':<18}index / note")
        for k, src in SOURCES.items():
            print(f"{k:<18}{src.iso3 or 'all':<6}{src.index_format:<12}{src.licence_id:<18}"
                  f"{src.index_url or src.notes}")
        print("layout_verified: none yet (UNVERIFIED until the Mac dry run)")
        return 0
    if a.cmd == "pull":
        from .fetch import PoliteFetcher
        from .pull import pull
        if a.min_interval < 2:
            print("--min-interval below 2 s is refused (politeness)", file=sys.stderr)
            return 2
        keys = [k.strip() for k in a.only.split(",") if k.strip()] or None
        rep = pull(a.root, sources=keys, since=a.since, until=a.until, max_docs=a.max_docs, dry_run=a.dry_run,
                   refresh=a.refresh, polite=PoliteFetcher(min_interval=a.min_interval))
        print(rep.format())
        return 0 if all(s.status != "error" for s in rep.sources) else 1
    if a.cmd == "status":
        if not corpus.available(a.root):
            print(f"no corpus at {a.root} (the Mac pull creates it)")
            return 0
        print(corpus.coverage(a.as_of, root=a.root).to_string(index=False))
        return 0
    if a.cmd == "verify":
        if not corpus.available(a.root):
            print(f"no corpus at {a.root}")
            return 0
        st = corpus._store(a.root)
        probs = st.verify()
        print("\n".join(probs) if probs else f"ok: {len(st.rows())} document version(s), all sha256 match")
        return 1 if probs else 0
    return 2


if __name__ == "__main__":
    sys.exit(main())
