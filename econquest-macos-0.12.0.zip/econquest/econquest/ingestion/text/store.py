"""Point-in-time text corpus store (EQ-A-0131).

Layout under a root folder (the real corpus: data/corpus/, approved by A/AGENT-08 2026-10-26; built only by the Mac
pull, never in the cloud):

    CORPUS.json                     {"schema": 1, "synthetic": false, "created_utc": ...}
    index.jsonl                     append-only: one JSON object per document version (INDEX_FIELDS)
    text/<sha[:2]>/<sha256>.txt     the extracted text, UTF-8; the file name is the sha256 of its bytes

A document is identified by doc_id = sha256("<source>|<url>")[:16]. Re-reading the same URL with the same text adds
nothing; with different text (a corrected release) it adds version n+1 with its own sha256 and retrieval time, and
the earlier version stays. Rows are never edited or removed.

Every row carries: source, family, iso3s, url, title, published_utc (+ precision), retrieved_utc, language, sha256 of
the text, n_chars, licence_id (data/licences.csv row) and licence tag, synthetic flag, layout_verified flag.

Refused (CorpusError) at add():
  - published_utc missing or after retrieved_utc (a document cannot be published after we read it);
  - retrieved_utc earlier than the newest retrieval already in the index (append-only in knowledge time);
  - a licence_id that has no row in the licence register;
  - a synthetic document in a non-synthetic store or the reverse; a synthetic store inside the repo's data/ folder;
  - non-https URLs, empty text, iso3 codes that are not desk names, bad language codes.
Reads verify each text file's sha256 against its row (CorpusIntegrityError on a mismatch).
"""
from __future__ import annotations

import contextlib
import datetime as dt
import hashlib
import json
import os
import re
from pathlib import Path

from .registry import DESK_COUNTRIES, LANG_RE

SCHEMA = 1
MARKER = "CORPUS.json"
INDEX = "index.jsonl"
TEXT_DIR = "text"
STAMP_RE = re.compile(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$")
SHA_RE = re.compile(r"^[0-9a-f]{64}$")
PRECISIONS = ("datetime", "date")
MAX_TEXT_CHARS = 2_000_000
REPO_DATA = Path(__file__).resolve().parents[3] / "data"
INDEX_FIELDS = ["doc_id", "version", "source", "family", "iso3s", "url", "title", "published_utc",
                "published_precision", "retrieved_utc", "language", "sha256", "n_chars", "licence_id", "licence_tag",
                "synthetic", "layout_verified"]


class CorpusError(ValueError):
    """A document the store refuses."""


class CorpusIntegrityError(RuntimeError):
    """A stored text file does not match the sha256 in its index row, or the index is malformed."""


def doc_id(source: str, url: str) -> str:
    return hashlib.sha256(f"{source}|{url}".encode()).hexdigest()[:16]


def text_sha256(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def utc_now() -> str:
    return dt.datetime.now(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


@contextlib.contextmanager
def _locked(path: Path):
    try:
        import fcntl
    except ImportError:                           # pragma: no cover (Windows)
        yield
        return
    with open(path, "a+") as fh:
        fcntl.flock(fh, fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(fh, fcntl.LOCK_UN)


def _inside(p: Path, parent: Path) -> bool:
    try:
        p.resolve().relative_to(parent.resolve())
        return True
    except ValueError:
        return False


class CorpusStore:
    """Open (create=True: create) a corpus folder. `synthetic` must match the folder's marker."""

    def __init__(self, root: str | Path, *, synthetic: bool = False, create: bool = False,
                 licence_ids: set | None = None):
        self.root = Path(root)
        self.synthetic = bool(synthetic)
        self._licence_ids = licence_ids
        if self.synthetic and _inside(self.root, REPO_DATA):
            raise CorpusError(f"a synthetic corpus may not live under {REPO_DATA} (synthetic text never enters data/)")
        marker = self.root / MARKER
        if marker.exists():
            meta = json.loads(marker.read_text())
            if meta.get("schema") != SCHEMA:
                raise CorpusIntegrityError(f"{marker}: schema {meta.get('schema')!r}, expected {SCHEMA}")
            if bool(meta.get("synthetic")) != self.synthetic:
                raise CorpusError(f"{self.root}: store synthetic={meta.get('synthetic')} but opened with "
                                  f"synthetic={self.synthetic}")
        elif create:
            self.root.mkdir(parents=True, exist_ok=True)
            tmp = marker.with_suffix(".tmp")
            tmp.write_text(json.dumps({"schema": SCHEMA, "synthetic": self.synthetic, "created_utc": utc_now(),
                                       "ticket": "EQ-A-0131"}, indent=1) + "\n")
            os.replace(tmp, marker)
        else:
            raise FileNotFoundError(f"no corpus at {self.root} (missing {MARKER}); the live pull creates it")

    @staticmethod
    def exists(root: str | Path) -> bool:
        return (Path(root) / MARKER).is_file()

    # -- reading -----------------------------------------------------------------------------------------------------
    def rows(self) -> list[dict]:
        p = self.root / INDEX
        if not p.exists():
            return []
        out = []
        for n, line in enumerate(p.read_text(encoding="utf-8").splitlines(), start=1):
            if not line.strip():
                continue
            try:
                r = json.loads(line)
            except json.JSONDecodeError as e:
                raise CorpusIntegrityError(f"{p} line {n}: not JSON ({e})") from None
            if set(r) != set(INDEX_FIELDS):
                raise CorpusIntegrityError(f"{p} line {n}: fields {sorted(set(r) ^ set(INDEX_FIELDS))} differ")
            r["iso3s"] = tuple(r["iso3s"])
            out.append(r)
        return out

    def text_path(self, sha: str) -> Path:
        if not SHA_RE.fullmatch(sha):
            raise CorpusIntegrityError(f"bad sha256 {sha!r}")
        return self.root / TEXT_DIR / sha[:2] / f"{sha}.txt"

    def text(self, sha: str) -> str:
        p = self.text_path(sha)
        try:
            raw = p.read_bytes()
        except FileNotFoundError:
            raise CorpusIntegrityError(f"text file missing for sha256 {sha[:12]}...") from None
        if hashlib.sha256(raw).hexdigest() != sha:
            raise CorpusIntegrityError(f"{p}: content does not match its sha256")
        return raw.decode("utf-8")

    def verify(self) -> list[str]:
        """Problems ([] = clean): index rows readable, every text file present and matching its sha256, retrieval
        times non-decreasing, published <= retrieved."""
        problems = []
        try:
            rows = self.rows()
        except CorpusIntegrityError as e:
            return [str(e)]
        last = ""
        for r in rows:
            try:
                self.text(r["sha256"])
            except CorpusIntegrityError as e:
                problems.append(f"{r['doc_id']} v{r['version']}: {e}")
            if r["retrieved_utc"] < last:
                problems.append(f"{r['doc_id']} v{r['version']}: retrieved_utc goes back in time")
            last = max(last, r["retrieved_utc"])
            if r["published_utc"] > r["retrieved_utc"]:
                problems.append(f"{r['doc_id']} v{r['version']}: published after retrieved")
        return problems

    def known_urls(self, source: str | None = None) -> set:
        return {r["url"] for r in self.rows() if source is None or r["source"] == source}

    # -- writing -----------------------------------------------------------------------------------------------------
    def _check_licence(self, licence_id: str) -> None:
        ids = self._licence_ids
        if ids is None:
            from econquest.ingestion.licences import load_register
            ids = {r["source_id"] for r in load_register()}
            self._licence_ids = ids
        if licence_id not in ids:
            raise CorpusError(f"licence_id {licence_id!r} has no row in the licence register (data/licences.csv)")

    def add(self, *, source: str, family: str, iso3s, url: str, title: str, published_utc: str,
            published_precision: str, retrieved_utc: str, language: str, text: str, licence_id: str,
            licence_tag: str, synthetic: bool, layout_verified: bool = False) -> dict:
        """Store one document version; returns its index row (the existing row when the same text is already
        stored for this source and URL)."""
        from econquest.ingestion.research.base import safe_text
        if bool(synthetic) != self.synthetic:
            raise CorpusError(f"synthetic={synthetic} document refused by a synthetic={self.synthetic} store")
        if not url.startswith("https://"):
            raise CorpusError(f"url must be https: {url[:80]!r}")
        iso3s = tuple(iso3s)
        if not iso3s or any(i not in DESK_COUNTRIES for i in iso3s):
            raise CorpusError(f"iso3s {iso3s!r}: need one or more desk names")
        if not language or not LANG_RE.fullmatch(language):
            raise CorpusError(f"language {language!r}")
        if published_precision not in PRECISIONS:
            raise CorpusError(f"published_precision {published_precision!r}")
        for name, v in (("published_utc", published_utc), ("retrieved_utc", retrieved_utc)):
            if not isinstance(v, str) or not STAMP_RE.fullmatch(v):
                raise CorpusError(f"{name} {v!r} is not YYYY-MM-DDTHH:MM:SSZ")
        if published_utc > retrieved_utc:
            raise CorpusError(f"published_utc {published_utc} is after retrieved_utc {retrieved_utc}")
        if not text or not text.strip():
            raise CorpusError("empty text")
        if len(text) > MAX_TEXT_CHARS:
            raise CorpusError(f"text over {MAX_TEXT_CHARS} characters")
        self._check_licence(licence_id)
        sha = text_sha256(text)
        did = doc_id(source, url)
        idx = self.root / INDEX
        with _locked(idx):
            rows = self.rows()
            same = [r for r in rows if r["doc_id"] == did]
            for r in same:
                if r["sha256"] == sha:
                    return r
            newest = max((r["retrieved_utc"] for r in rows), default="")
            if retrieved_utc < newest:
                raise CorpusError(f"retrieved_utc {retrieved_utc} is before the newest stored retrieval {newest} "
                                  f"(the index is append-only in knowledge time)")
            tp = self.text_path(sha)
            if self.synthetic and (_inside(tp, REPO_DATA) or _inside(idx, REPO_DATA)):
                raise CorpusError(f"a synthetic corpus may not write under {REPO_DATA} through a link (SEC-A-015 T-L5)")
            if not tp.exists():
                tp.parent.mkdir(parents=True, exist_ok=True)
                tmp = tp.with_suffix(".tmp")
                tmp.write_bytes(text.encode("utf-8"))
                os.replace(tmp, tp)
            row = {"doc_id": did, "version": len(same) + 1, "source": source, "family": family,
                   "iso3s": list(iso3s), "url": url, "title": safe_text(title) if title else "",
                   "published_utc": published_utc, "published_precision": published_precision,
                   "retrieved_utc": retrieved_utc, "language": language, "sha256": sha, "n_chars": len(text),
                   "licence_id": licence_id, "licence_tag": licence_tag, "synthetic": bool(synthetic),
                   "layout_verified": bool(layout_verified)}
            with open(idx, "a", encoding="utf-8") as fh:
                fh.write(json.dumps(row, ensure_ascii=False, sort_keys=False) + "\n")
                fh.flush()
                os.fsync(fh.fileno())
        row["iso3s"] = tuple(row["iso3s"])
        return row
