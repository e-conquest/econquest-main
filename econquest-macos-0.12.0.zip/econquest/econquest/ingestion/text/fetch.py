"""Polite HTTP for the text corpus (EQ-A-0131): one request at a time, per-host rate limit, robots.txt respected,
host allow-list, a descriptive user agent, retries only for transient errors.

Transport is events.base.http_fetch (https only, redirects refused, body capped, final URL checked: SEC-A-002), or an
injected `fetcher(url, headers) -> bytes` in tests. This module never runs a network call at import, and the tests
never touch the network.

Politeness rules (PoliteFetcher):
  - user agent USER_AGENT on every request, including robots.txt;
  - at least `min_interval` seconds (default 5) between two requests to the same host, raised to the host's robots.txt
    Crawl-delay when that is longer (capped at MAX_CRAWL_DELAY);
  - robots.txt is read once per host; a path it disallows for our agent is not requested (RobotsRefused).
    A 404 for robots.txt means no rules. Any other failure (a redirect, 403, connection error) means the host is not
    crawled in this run: conservative, because we could not read the rules;
  - a host that is not on the source's allow-list is refused before any request (HostRefused);
  - transient errors (HTTP 429/5xx, timeouts) are retried twice with a growing pause; after MAX_HOST_FAILURES transient
    failures the host is dropped for the run (HostDown);
  - `max_requests` caps the whole run.
"""
from __future__ import annotations

import time
import urllib.parse
import urllib.robotparser
from typing import Callable

from econquest.ingestion.events.base import FetchError, TransientFetchError, http_fetch

USER_AGENT = "econquest-corpus/0.1 (sovereign research text archive; one request per 5 s per host; robots.txt respected)"
ROBOTS_AGENT = "econquest-corpus"
DEFAULT_MIN_INTERVAL = 5.0
MAX_CRAWL_DELAY = 60.0
MAX_HOST_FAILURES = 3
RETRIES = 2
DEFAULT_MAX_BYTES = 5 * 1024 * 1024
ROBOTS_MAX_BYTES = 512 * 1024
DEFAULT_MAX_REQUESTS = 500

Fetcher = Callable[[str, dict, int], bytes]     # fetcher(url, headers, max_bytes) -> body


class HostRefused(FetchError):
    """The URL's host is not on the source's allow-list, or the URL is not https."""


class RobotsRefused(FetchError):
    """robots.txt disallows the path for our agent, or could not be read."""


class HostDown(FetchError):
    """The host failed MAX_HOST_FAILURES times in this run."""


class RequestCapReached(FetchError):
    """max_requests reached."""


def _default_fetcher(url: str, headers: dict, max_bytes: int = DEFAULT_MAX_BYTES) -> bytes:
    return http_fetch(url, headers, max_bytes=max_bytes, timeout=60)


class PoliteFetcher:
    def __init__(self, fetcher: Fetcher | None = None, *, min_interval: float = DEFAULT_MIN_INTERVAL,
                 max_requests: int = DEFAULT_MAX_REQUESTS, respect_robots: bool = True,
                 clock: Callable[[], float] = time.monotonic, sleep: Callable[[float], None] = time.sleep):
        self._fetch = fetcher or _default_fetcher
        self.min_interval = float(min_interval)
        self.max_requests = int(max_requests)
        self.respect_robots = respect_robots
        self._clock, self._sleep = clock, sleep
        self._last: dict[str, float] = {}
        self._delay: dict[str, float] = {}
        self._robots: dict[str, urllib.robotparser.RobotFileParser | str] = {}
        self._failures: dict[str, int] = {}
        self.requests = 0
        self.log: list[tuple[str, str]] = []           # (url without query, outcome) for the pull report

    # -- internals ---------------------------------------------------------------------------------------------------
    def _wait(self, host: str) -> None:
        last = self._last.get(host)
        gap = max(self.min_interval, self._delay.get(host, 0.0))
        if last is not None:
            due = last + gap - self._clock()
            if due > 0:
                self._sleep(due)
        self._last[host] = self._clock()

    def _raw(self, url: str, host: str, max_bytes: int) -> bytes:
        if self.requests >= self.max_requests:
            raise RequestCapReached(f"request cap {self.max_requests} reached")
        if self._failures.get(host, 0) >= MAX_HOST_FAILURES:
            raise HostDown(f"{host}: {MAX_HOST_FAILURES} transient failures in this run; host skipped")
        headers = {"User-Agent": USER_AGENT, "Accept": "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.5"}
        for attempt in range(RETRIES + 1):
            self._wait(host)
            self.requests += 1
            try:
                body = self._fetch(url, headers, max_bytes)
                self.log.append((_safe(url), "ok"))
                return body
            except TransientFetchError as e:
                self._failures[host] = self._failures.get(host, 0) + 1
                self.log.append((_safe(url), f"transient: {e}"))
                if attempt == RETRIES or self._failures[host] >= MAX_HOST_FAILURES:
                    raise
                self._sleep(self.min_interval * (attempt + 2))
            except FetchError as e:
                self.log.append((_safe(url), f"error: {e}"))
                raise
        raise AssertionError("unreachable")

    def _robots_for(self, host: str):
        if host in self._robots:
            return self._robots[host]
        try:
            body = self._raw(f"https://{host}/robots.txt", host, ROBOTS_MAX_BYTES)
            rp = urllib.robotparser.RobotFileParser()
            rp.parse(body.decode("utf-8", "replace").splitlines())
            delay = rp.crawl_delay(ROBOTS_AGENT)
            if delay:
                self._delay[host] = min(float(delay), MAX_CRAWL_DELAY)
            self._robots[host] = rp
        except FetchError as e:
            if "HTTP 404" in str(e):
                rp = urllib.robotparser.RobotFileParser()
                rp.parse([])
                self._robots[host] = rp
            else:
                self._robots[host] = f"robots.txt unreadable ({e}); host not crawled in this run"
        except TransientFetchError as e:
            self._robots[host] = f"robots.txt unreadable ({e}); host not crawled in this run"
        return self._robots[host]

    # -- public ------------------------------------------------------------------------------------------------------
    def get(self, url: str, allowed_hosts, max_bytes: int = DEFAULT_MAX_BYTES) -> bytes:
        parts = urllib.parse.urlsplit(url)
        host = (parts.hostname or "").lower()
        if parts.scheme != "https" or not host:
            raise HostRefused(f"not an https URL: {_safe(url)}")
        if host not in {h.lower() for h in allowed_hosts}:
            raise HostRefused(f"host {host} is not on the source's allow-list")
        try:
            port = parts.port
        except ValueError:
            port = -1
        if port not in (None, 443) or parts.username is not None or parts.password is not None:
            raise HostRefused(f"{host}: only the default https port and no user info (SEC-A-015 T-L4)")
        if self.respect_robots:
            rp = self._robots_for(host)
            if isinstance(rp, str):
                raise RobotsRefused(rp)
            if not rp.can_fetch(ROBOTS_AGENT, url):
                raise RobotsRefused(f"robots.txt disallows {parts.path} for {ROBOTS_AGENT}")
        return self._raw(url, host, max_bytes)


def _safe(url: str) -> str:
    p = urllib.parse.urlsplit(url)
    return f"{p.scheme}://{p.hostname}{p.path}"
