"""Parsers for the text corpus (EQ-A-0131): feeds, HTML listing pages, article pages and publication timestamps.

parse_feed         RSS 2.0 (<item><link><pubDate>), RSS 1.0 / RDF (<item><link><dc:date>) and Atom 1.0
                   (<entry><link href><published|updated>), as their published specifications define them. XML is parsed
                   with defusedxml (no entity expansion, no external entities).
parse_html_index   links whose href matches the source's link_re, each dated by the first date found in its enclosing
                   list item / table row / article / paragraph block (ISO 2025-03-05, 5 March 2025, March 5, 2025,
                   Mar 5 2025; numeric dd/mm vs mm/dd forms are ambiguous and ignored)
parse_article      the body text of an article page: the configured container (id:..., class:..., or a tag), else
                   <article>, else <main>, else <body>; script, style, nav, header, footer, aside, form and noscript
                   are dropped. Also the page's <html lang> and its own publication date (meta article:published_time,
                   meta name=date / DC.date, or the first <time datetime>)
to_utc             a timestamp text -> ('YYYY-MM-DDTHH:MM:SSZ', precision). Precision 'datetime' when the text has a
                   time; 'date' when it has a date only, stamped at 23:59:59 local (the source's zone), so an as-of
                   query on the morning of the publication day never sees a release published later that day.
                   Naive times are read in the source's IANA zone.

Nothing here is guessed: an entry without a link is dropped, an undated entry keeps published=None and the article's
own date is used; a document with no date at all is not stored (store.py refuses it).
"""
from __future__ import annotations

import datetime as dt
import email.utils
import html
import re
import urllib.parse
from dataclasses import dataclass
from html.parser import HTMLParser
from zoneinfo import ZoneInfo

from defusedxml import DefusedXmlException
from defusedxml import ElementTree as ET

MAX_TITLE = 300


class ParseError(ValueError):
    """The document does not have the layout the parser was written for. Never repaired or guessed."""


@dataclass
class Entry:
    url: str
    title: str = ""
    published: str | None = None     # the raw date text from the index (to_utc converts it)
    summary: str = ""
    language: str = ""


@dataclass
class Article:
    text: str
    title: str = ""
    language: str = ""
    published: str | None = None


# -- timestamps ------------------------------------------------------------------------------------------------------
MONTHS = {m: i for i, m in enumerate(
    ["january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november",
     "december"], start=1)}
MONTHS.update({k[:3]: v for k, v in list(MONTHS.items())})
MONTHS["sept"] = 9
_MON = r"(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|june?|july?|aug(?:ust)?|sept?(?:ember)?|oct(?:ober)?" \
       r"|nov(?:ember)?|dec(?:ember)?)\.?"
DATE_PATTERNS = (
    (re.compile(r"\b(\d{4})-(\d{2})-(\d{2})\b"), ("y", "m", "d")),
    (re.compile(r"\b(\d{1,2})(?:st|nd|rd|th)?\s+" + _MON + r",?\s+(\d{4})\b", re.I), ("d", "M", "y")),
    (re.compile(r"\b" + _MON + r"\s+(\d{1,2})(?:st|nd|rd|th)?,?\s+(\d{4})\b", re.I), ("M", "d", "y")),
)
ISO_DT_RE = re.compile(r"^\d{4}-\d{2}-\d{2}[T ]\d{2}:\d{2}(:\d{2}(\.\d+)?)?(Z|[+-]\d{2}:?\d{2})?$")
STAMP_FMT = "%Y-%m-%dT%H:%M:%SZ"


def find_date(text: str) -> dt.date | None:
    """The first unambiguous calendar date in `text`, or None."""
    best = None
    for rx, order in DATE_PATTERNS:
        m = rx.search(text or "")
        if not m:
            continue
        parts = dict(zip(order, m.groups()))
        try:
            month = int(parts["m"]) if "m" in parts else MONTHS[parts["M"].lower().rstrip(".")]
            d = dt.date(int(parts["y"]), month, int(parts["d"]))
        except (ValueError, KeyError):
            continue
        if best is None or m.start() < best[0]:
            best = (m.start(), d)
    return best[1] if best else None


def to_utc(value: str | None, tz: str) -> tuple[str, str] | None:
    """('YYYY-MM-DDTHH:MM:SSZ', 'datetime' | 'date') or None when no date can be read."""
    if not value or not str(value).strip():
        return None
    v = str(value).strip()
    zone = ZoneInfo(tz)
    stamp = None
    if ISO_DT_RE.match(v):
        s = v.replace(" ", "T").replace("Z", "+00:00")
        s = re.sub(r"([+-]\d{2})(\d{2})$", r"\1:\2", s)
        stamp = dt.datetime.fromisoformat(s)
    else:
        try:
            stamp = email.utils.parsedate_to_datetime(v)          # RFC 822 / 2822 (RSS 2.0 pubDate)
        except (TypeError, ValueError, IndexError):
            stamp = None
    if stamp is not None:
        if stamp.tzinfo is None:
            stamp = stamp.replace(tzinfo=zone)
        return stamp.astimezone(dt.timezone.utc).strftime(STAMP_FMT), "datetime"
    d = find_date(v)
    if d is None:
        return None
    end = dt.datetime.combine(d, dt.time(23, 59, 59), tzinfo=zone)
    return end.astimezone(dt.timezone.utc).strftime(STAMP_FMT), "date"


# -- feeds -----------------------------------------------------------------------------------------------------------
NS = {"atom": "http://www.w3.org/2005/Atom", "rss1": "http://purl.org/rss/1.0/",
      "rdf": "http://www.w3.org/1999/02/22-rdf-syntax-ns#", "dc": "http://purl.org/dc/elements/1.1/",
      "content": "http://purl.org/rss/1.0/modules/content/"}


def _t(el) -> str:
    return " ".join("".join(el.itertext()).split()) if el is not None else ""


def _clean(s: str, cap: int = MAX_TITLE) -> str:
    return " ".join(html.unescape(_strip_tags(s)).split())[:cap]


def _strip_tags(s: str) -> str:
    return re.sub(r"<[^>]+>", " ", s or "")


def parse_feed(body: bytes, base_url: str) -> list[Entry]:
    try:
        root = ET.fromstring(body)
    except ET.ParseError as e:
        raise ParseError(f"feed is not well-formed XML: {e}") from None
    except DefusedXmlException as e:                  # SEC-A-015 T-L1: entity / DTD tricks refuse this feed only
        raise ParseError(f"feed refused by defusedxml: {type(e).__name__}") from None
    tag = root.tag.split("}")[-1]
    out: list[Entry] = []
    if tag == "rss":
        ch = root.find("channel")
        if ch is None:
            raise ParseError("RSS 2.0 feed without <channel>")
        lang = _t(ch.find("language")).lower()
        for it in ch.findall("item"):
            link = _t(it.find("link")) or _t(it.find("guid"))
            if not link:
                continue
            pub = _t(it.find("pubDate")) or _t(it.find("dc:date", NS)) or None
            out.append(Entry(urllib.parse.urljoin(base_url, link), _clean(_t(it.find("title"))), pub,
                             _clean(_t(it.find("description")), 2000), lang))
    elif tag == "RDF":
        ch = root.find("rss1:channel", NS)
        lang = _t(ch.find("dc:language", NS)).lower() if ch is not None else ""
        for it in root.findall("rss1:item", NS):
            link = _t(it.find("rss1:link", NS))
            if not link:
                continue
            pub = _t(it.find("dc:date", NS)) or None
            out.append(Entry(urllib.parse.urljoin(base_url, link), _clean(_t(it.find("rss1:title", NS))), pub,
                             _clean(_t(it.find("rss1:description", NS)), 2000), lang))
    elif tag == "feed":
        lang = (root.get("{http://www.w3.org/XML/1998/namespace}lang") or "").lower()
        for it in root.findall("atom:entry", NS):
            links = it.findall("atom:link", NS)
            link = next((l.get("href") for l in links if l.get("rel", "alternate") == "alternate" and l.get("href")),
                        None)
            if not link:
                continue
            pub = _t(it.find("atom:published", NS)) or _t(it.find("atom:updated", NS)) or None
            out.append(Entry(urllib.parse.urljoin(base_url, link), _clean(_t(it.find("atom:title", NS))), pub,
                             _clean(_t(it.find("atom:summary", NS)), 2000), lang))
    else:
        raise ParseError(f"unknown feed root <{tag}> (expected rss, rdf:RDF or atom feed)")
    return out


# -- HTML ------------------------------------------------------------------------------------------------------------
BLOCK_TAGS = {"li", "tr", "article", "p", "dd", "dt", "section"}
DROP_TAGS = {"script", "style", "nav", "header", "footer", "aside", "form", "noscript", "template", "svg", "iframe"}
BREAK_TAGS = {"p", "div", "br", "li", "tr", "h1", "h2", "h3", "h4", "h5", "h6", "section", "article", "table",
              "blockquote", "dd", "dt", "ul", "ol"}
VOID_TAGS = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta", "param", "source", "track",
             "wbr"}


class _IndexParser(HTMLParser):
    # SEC-A-015 T-L3: a block's text is the slice of one shared parts list from its start to its end (or to the end of
    # the page when it is never closed), so deep nesting costs linear time instead of copying parts up every level
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.parts: list[str] = []          # every text chunk seen inside any block, in page order
        self.blocks: list[dict] = []        # open blocks: {start, end}
        self.links: list[dict] = []         # {href, text parts, block (dict) or None}
        self._a: dict | None = None
        self.title_parts: list[str] = []
        self._in_title = False

    def handle_starttag(self, tag, attrs):
        if tag in BLOCK_TAGS:
            self.blocks.append({"start": len(self.parts), "end": None})
        elif tag == "a":
            href = dict(attrs).get("href")
            if href:
                self._a = {"href": href, "text": [], "block": self.blocks[-1] if self.blocks else None}
                self.links.append(self._a)
        elif tag == "title":
            self._in_title = True

    def handle_endtag(self, tag):
        if tag in BLOCK_TAGS and self.blocks:
            self.blocks.pop()["end"] = len(self.parts)
        elif tag == "a":
            self._a = None
        elif tag == "title":
            self._in_title = False

    def block_text(self, block: dict) -> str:
        return "".join(self.parts[block["start"]:block["end"]])

    def handle_data(self, data):
        if self.blocks:
            self.parts.append(data)
        if self._a is not None:
            self._a["text"].append(data)
        if self._in_title:
            self.title_parts.append(data)


def parse_html_index(body: bytes, base_url: str, link_re: str) -> list[Entry]:
    p = _IndexParser()
    p.feed(_decode(body))
    p.close()
    rx = re.compile(link_re)
    seen, out = set(), []
    for a in p.links:
        href = a["href"].strip()
        if not rx.search(href):
            continue
        url = urllib.parse.urljoin(base_url, href)
        if url in seen:
            continue
        seen.add(url)
        block_text = " ".join(p.block_text(a["block"]).split()) if a["block"] is not None else ""
        d = find_date(block_text)
        out.append(Entry(url, _clean("".join(a["text"])), d.isoformat() if d else None))
    return out


def _decode(body: bytes) -> str:
    head = body[:2048].decode("ascii", "replace")
    m = re.search(r"charset=[\"']?([A-Za-z0-9_-]+)", head)
    enc = m.group(1) if m else "utf-8"
    try:
        return body.decode(enc, "replace")
    except LookupError:
        return body.decode("utf-8", "replace")


class _ArticleParser(HTMLParser):
    def __init__(self, content: str):
        super().__init__(convert_charrefs=True)
        kind, _, val = content.partition(":") if ":" in content else ("tag", "", content)
        self.c_kind, self.c_val = (kind, val) if content else ("", "")
        self.stack: list[tuple[str, set]] = []        # (tag, flags) for every open element
        self.buckets = {"container": [], "article": [], "main": [], "body": []}
        self.lang = ""
        self.meta_date: str | None = None
        self.time_date: str | None = None
        self.title_parts: list[str] = []
        self.h1_parts: list[str] = []
        self._flag_n: dict[str, int] = {}             # SEC-A-015 T-L3: open elements carrying each flag
        self._open_n: dict[str, int] = {}             # open elements per tag name

    def _flags(self) -> set:
        return {k for k, n in self._flag_n.items() if n > 0}

    def _push(self, tag: str, fl: set) -> None:
        self.stack.append((tag, fl))
        self._open_n[tag] = self._open_n.get(tag, 0) + 1
        for k in fl:
            self._flag_n[k] = self._flag_n.get(k, 0) + 1

    def _pop_to(self, i: int) -> None:
        for tag, fl in self.stack[i:]:
            self._open_n[tag] -= 1
            for k in fl:
                self._flag_n[k] -= 1
        del self.stack[i:]

    def _matches(self, tag, a) -> bool:
        if self.c_kind == "id":
            return a.get("id") == self.c_val
        if self.c_kind == "class":
            return self.c_val in (a.get("class") or "").split()
        if self.c_kind == "tag":
            return tag == self.c_val
        return False

    def handle_starttag(self, tag, attrs):
        a = {k: (v or "") for k, v in attrs}
        if tag == "html" and a.get("lang"):
            self.lang = a["lang"].strip()
        if tag == "meta":
            key = (a.get("property") or a.get("name") or a.get("itemprop") or "").lower()
            if key in ("article:published_time", "date", "dc.date", "dcterms.issued", "datepublished") \
                    and a.get("content") and self.meta_date is None:
                self.meta_date = a["content"].strip()
        if tag == "time" and a.get("datetime") and self.time_date is None:
            self.time_date = a["datetime"].strip()
        if tag in VOID_TAGS:
            if tag == "br":
                self._emit("\n")
            return
        fl = set()
        if tag in DROP_TAGS:
            fl.add("drop")
        if self._matches(tag, a):
            fl.add("container")
        if tag in ("article", "main", "body", "title", "h1"):
            fl.add(tag)
        self._push(tag, fl)
        if tag in BREAK_TAGS:
            self._emit("\n")

    def handle_endtag(self, tag):
        if tag in VOID_TAGS:
            return
        if self._open_n.get(tag, 0) > 0:                    # an end tag with no open element costs nothing
            for i in range(len(self.stack) - 1, -1, -1):    # tolerate unclosed inner tags
                if self.stack[i][0] == tag:
                    self._pop_to(i)
                    break
        if tag in BREAK_TAGS:
            self._emit("\n")

    def _emit(self, s):
        f = self._flags()
        if "drop" in f:
            return
        for b in ("container", "article", "main", "body"):
            if b in f:
                self.buckets[b].append(s)

    def handle_data(self, data):
        f = self._flags()
        if "title" in f:
            self.title_parts.append(data)
        if "h1" in f and "drop" not in f:
            self.h1_parts.append(data)
        self._emit(data)


def _norm_text(parts: list[str]) -> str:
    lines = [" ".join(l.split()) for l in "".join(parts).split("\n")]
    out, blank = [], False
    for l in lines:
        if l:
            out.append(l)
            blank = False
        elif not blank and out:
            out.append("")
            blank = True
    return "\n".join(out).strip()


def parse_article(body: bytes, content: str = "") -> Article:
    p = _ArticleParser(content)
    p.feed(_decode(body))
    p.close()
    order = (["container"] if content else []) + ["article", "main", "body"]
    text = ""
    for b in order:
        text = _norm_text(p.buckets[b])
        if text:
            break
    if not text:
        raise ParseError("no body text found (container, article, main and body all empty)")
    title = _clean("".join(p.h1_parts)) or _clean("".join(p.title_parts))
    lang = p.lang.split("-")[0].lower() if p.lang else ""
    return Article(text=text, title=title, language=lang, published=p.meta_date or p.time_date)
