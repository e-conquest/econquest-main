"""Text corpus (EQ-A-0131): central bank statements and IMF press releases for the 18 desk names, stored
point-in-time for the text stress index (Team B, EQ-B-0135) and the GUI (Team C, EQ-C-0155).

    registry.py   the sources (one central bank per desk name, IMF press releases, IMF country pages), all UNVERIFIED
    fetch.py      polite HTTP: user agent, per-host rate limit, robots.txt, host allow-list, retries
    parse.py      RSS / RDF / Atom feeds, HTML listing pages, article text, publication timestamps
    store.py      the point-in-time store (data/corpus/: index.jsonl + text files named by sha256)
    pull.py       the live pull (Sam's Mac only; runbook docs/runbooks/A-text-corpus.md)
    corpus.py     THE READ INTERFACE other teams call: documents(), documents_frame(), latest(), coverage()

    python -m econquest.ingestion.text sources | pull | status | verify

No network call at import; the tests run on SYNTHETIC fixtures (tests/fixtures/text_corpus/).
"""
from .corpus import Document, available, coverage, documents, documents_frame, latest

__all__ = ["Document", "available", "coverage", "documents", "documents_frame", "latest"]
