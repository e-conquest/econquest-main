"""Public read interface of the text corpus (EQ-A-0131). Stable for Team B (EQ-B-0135 text stress index) and Team C
(EQ-C-0155 GUI / morning view). Changing a signature or a field here needs a handoff to both teams.

    from econquest.ingestion.text import corpus

    corpus.documents(country, since=None, as_of=None, *, sources=None, family=None, basis="published",
                     with_text=True, root=None) -> list[Document]
    corpus.documents_frame(...same arguments...) -> pandas.DataFrame (DOCUMENT_COLUMNS, plus `text` if with_text)
    corpus.latest(country, as_of=None, n=5, root=None) -> list[dict]      # GUI-safe: no body text, Sheets-safe title
    corpus.coverage(as_of=None, basis="published", root=None) -> pandas.DataFrame   # documents per desk name/family
    corpus.available(root=None) -> bool                                  # False until the Mac pull has run

Arguments
    country   a desk-name ISO3 (any case) or its name ("Argentina"); ValueError for anything else. None: all names.
    since     date / datetime / ISO text: documents published at or after it (a date means 00:00:00 UTC that day)
    as_of     date / datetime / ISO text: the point in time. Never returns a document published after it. A date
              means the END of that day (23:59:59 UTC). None: no cap (everything stored).
    basis     "published" (default, for backtests over past episodes): the document's publication time <= as_of; the
                  FIRST stored version of each document is returned (closest to the text as published).
              "knowledge": strict knowledge time, for replaying what the corpus held on a date: publication AND
                  retrieval time <= as_of; the LATEST version retrieved by as_of is returned.
    sources   iterable of registry keys (registry.SOURCES), e.g. ("cb_arg", "imf_press")
    family    "central_bank" | "imf"

Ordering: published_utc ascending, then source, then url. One Document per (source, url).
An IMF press release that names two desk names is returned for each of them (iso3s holds both).

Where the corpus lives: DEFAULT_ROOT = data/corpus/ (built only by the Mac pull). When it does not exist every query
returns [] / an empty frame: callers must handle an empty corpus, which is the state until the first Mac pull.

Licence: every document carries licence_id and client_ok. client_ok is True only when both the document's register
row and the corpus store row (text_corpus_store) allow client output. Today every row is internal use, client
restricted: nothing from the corpus may go into client output (audit / client-safe routes) until Sam reads the terms.
"""
from __future__ import annotations

import datetime as dt
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Iterable

import pandas as pd

from .registry import FAMILIES, SOURCES, norm_iso3
from .store import REPO_DATA, CorpusStore

DEFAULT_ROOT = REPO_DATA / "corpus"
BASES = ("published", "knowledge")
STORE_LICENCE_ID = "text_corpus_store"
DOCUMENT_COLUMNS = ["doc_id", "version", "source", "family", "iso3s", "url", "title", "published_utc",
                    "published_precision", "retrieved_utc", "language", "sha256", "n_chars", "licence_id",
                    "client_ok", "synthetic", "layout_verified"]


@dataclass(frozen=True)
class Document:
    doc_id: str
    version: int
    source: str
    family: str
    iso3s: tuple
    url: str
    title: str
    published_utc: str          # YYYY-MM-DDTHH:MM:SSZ
    published_precision: str    # datetime | date (date-only: 23:59:59 in the publisher's zone, capped at retrieval)
    retrieved_utc: str          # YYYY-MM-DDTHH:MM:SSZ
    language: str
    sha256: str                 # of the UTF-8 text
    n_chars: int
    licence_id: str             # data/licences.csv source_id
    client_ok: bool
    synthetic: bool
    layout_verified: bool
    text: str | None = None


def _stamp(v, end_of_day: bool) -> str | None:
    if v is None or v == "":
        return None
    if isinstance(v, str):
        s = v.strip()
        if len(s) == 10:
            v = dt.date.fromisoformat(s)
        else:
            v = dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
    if isinstance(v, pd.Timestamp):
        v = v.to_pydatetime()
    if isinstance(v, dt.datetime):
        if v.tzinfo is None:
            v = v.replace(tzinfo=dt.timezone.utc)
        return v.astimezone(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    if isinstance(v, dt.date):
        return v.isoformat() + ("T23:59:59Z" if end_of_day else "T00:00:00Z")
    raise TypeError(f"not a date or timestamp: {v!r}")


def _client_ok_map() -> dict:
    try:
        from econquest.ingestion.licences import load_register
        reg = {r["source_id"]: r["client_output"] for r in load_register()}
    except Exception:                              # no register: nothing is client-safe
        return {}
    store_ok = reg.get(STORE_LICENCE_ID) == "allowed"
    return {k: (v == "allowed" and store_ok) for k, v in reg.items()}


def _store(root) -> CorpusStore | None:
    r = Path(root) if root is not None else DEFAULT_ROOT
    if not CorpusStore.exists(r):
        return None
    from .store import MARKER
    import json
    synthetic = bool(json.loads((r / MARKER).read_text()).get("synthetic"))
    return CorpusStore(r, synthetic=synthetic)


def available(root=None) -> bool:
    return _store(root) is not None


def documents(country=None, since=None, as_of=None, *, sources: Iterable[str] | None = None, family: str | None = None,
              basis: str = "published", with_text: bool = True, root=None) -> list[Document]:
    if basis not in BASES:
        raise ValueError(f"basis {basis!r} not in {BASES}")
    if family is not None and family not in FAMILIES:
        raise ValueError(f"family {family!r} not in {FAMILIES}")
    iso = norm_iso3(country) if country is not None else None
    src = None
    if sources is not None:
        src = set(sources)
        bad = src - set(SOURCES)
        if bad:
            raise ValueError(f"unknown sources {sorted(bad)}")
    lo, hi = _stamp(since, False), _stamp(as_of, True)
    st = _store(root)
    if st is None:
        return []
    chosen: dict[str, dict] = {}
    for r in st.rows():                                    # index order = retrieval order
        if iso and iso not in r["iso3s"]:
            continue
        if src is not None and r["source"] not in src:
            continue
        if family and r["family"] != family:
            continue
        if hi is not None and r["published_utc"] > hi:
            continue
        if lo is not None and r["published_utc"] < lo:
            continue
        if basis == "knowledge":
            if hi is not None and r["retrieved_utc"] > hi:
                continue
            chosen[r["doc_id"]] = r                        # later versions replace earlier ones
        else:
            chosen.setdefault(r["doc_id"], r)              # first version wins
    ok = _client_ok_map()
    out = []
    for r in sorted(chosen.values(), key=lambda r: (r["published_utc"], r["source"], r["url"])):
        out.append(Document(
            doc_id=r["doc_id"], version=r["version"], source=r["source"], family=r["family"], iso3s=tuple(r["iso3s"]),
            url=r["url"], title=r["title"], published_utc=r["published_utc"],
            published_precision=r["published_precision"], retrieved_utc=r["retrieved_utc"], language=r["language"],
            sha256=r["sha256"], n_chars=r["n_chars"], licence_id=r["licence_id"],
            client_ok=bool(ok.get(r["licence_id"], False)), synthetic=r["synthetic"],
            layout_verified=r["layout_verified"], text=st.text(r["sha256"]) if with_text else None))
    return out


def documents_frame(country=None, since=None, as_of=None, **kw) -> pd.DataFrame:
    docs = documents(country, since, as_of, **kw)
    cols = DOCUMENT_COLUMNS + (["text"] if kw.get("with_text", True) else [])
    if not docs:
        return pd.DataFrame(columns=cols)
    return pd.DataFrame([{k: v for k, v in asdict(d).items() if k in cols} for d in docs], columns=cols)


def latest(country, as_of=None, n: int = 5, root=None) -> list[dict]:
    """The n most recent documents for a desk name, newest first, as plain dicts for a GUI or Sheets cell: no body
    text; title made Sheets-safe at store time (research.base.safe_text). Check client_ok before any client view."""
    docs = documents(country, None, as_of, with_text=False, root=root)
    keep = ("doc_id", "source", "family", "url", "title", "published_utc", "published_precision", "language",
            "licence_id", "client_ok", "synthetic")
    return [{k: getattr(d, k) for k in keep} for d in reversed(docs[-n:])] if n > 0 else []


def coverage(as_of=None, basis: str = "published", root=None) -> pd.DataFrame:
    """Documents per desk name and family as of a date: iso3, family, documents, first_published, last_published."""
    cols = ["iso3", "family", "documents", "first_published", "last_published"]
    rows = []
    for d in documents(None, None, as_of, basis=basis, with_text=False, root=root):
        for i in d.iso3s:
            rows.append((i, d.family, d.published_utc))
    if not rows:
        return pd.DataFrame(columns=cols)
    df = pd.DataFrame(rows, columns=["iso3", "family", "published_utc"])
    g = df.groupby(["iso3", "family"])["published_utc"]
    return pd.DataFrame({"documents": g.size(), "first_published": g.min(), "last_published": g.max()}) \
        .reset_index()[cols]
