"""Text corpus source registry (EQ-A-0131): one entry per publisher feeding the corpus.

Two source families:
    central_bank   one entry per desk name (data/countries.csv, 18 names): the central bank's press release /
                   statement feed or listing page. BCEAO serves Senegal (WAEMU).
    imf            IMF press releases (one feed for every country; a release is attached to the desk names its title
                   or summary names) and the IMF country pages (one listing page per desk name).

Index formats:
    rss            RSS 2.0, RSS 1.0 (RDF) or Atom 1.0: the formats' published specs, parsed by parse.parse_feed
    html_index     an HTML listing page: links whose href matches `link_re`, dated by a date in the same list item /
                   row (parse.parse_html_index), else by the article page's own date metadata
    manual         no machine-readable listing is known here; nothing is requested. The live pull lists it as
                   parked with `notes` (runbook A-text-corpus.md, section 4)

EVERYTHING HERE IS UNVERIFIED (layout_verified=False on every entry). This cloud cannot reach these hosts. The index
URLs, link patterns and content containers are written from the publishers' public site structure as remembered, not
from a live answer. The first Mac pull (`python -m econquest.ingestion.text pull --dry-run`) reports which index URLs
answer and how many entries each parser finds; an entry is only marked verified after that check (runbook step 3).

Licence: every entry names a tighten-only row in data/licences.csv (`licence_id`, rows text_cb_<iso3>, text_imf):
internal use yes, client output restricted, validator room UNVERIFIED, until Sam reads the publisher's terms.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

FAMILIES = ("central_bank", "imf")
INDEX_FORMATS = ("rss", "html_index", "manual")
ISO3_RE = re.compile(r"^[A-Z]{3}$")
KEY_RE = re.compile(r"^[a-z][a-z0-9_]{1,31}$")
LANG_RE = re.compile(r"^[a-z]{2,3}(-[A-Za-z0-9]{2,8})?$")
TICKET = "EQ-A-0131"

# The 18 desk names (data/countries.csv, tier desk_current) and the names a press release uses for each. Aliases are
# matched on word boundaries, case-insensitive, in the title and summary of an IMF press release.
DESK_COUNTRIES = {
    "VNM": ("Vietnam", "Viet Nam"),
    "PHL": ("Philippines",),
    "CHN": ("China", "People's Republic of China"),
    "MYS": ("Malaysia",),
    "SGP": ("Singapore",),
    "JPN": ("Japan",),
    "KOR": ("Korea", "Republic of Korea", "South Korea"),
    "IND": ("India",),
    "PAK": ("Pakistan",),
    "BLZ": ("Belize",),
    "BRA": ("Brazil",),
    "ARG": ("Argentina",),
    "COL": ("Colombia",),
    "VEN": ("Venezuela",),
    "NGA": ("Nigeria",),
    "SEN": ("Senegal",),
    "ZMB": ("Zambia",),
    "ZWE": ("Zimbabwe",),
}
# 'Korea' must not match 'Democratic People's Republic of Korea'; 'China' must not match 'Hong Kong SAR, China' or
# 'Taiwan Province of China'
ALIAS_EXCLUDE = {"KOR": re.compile(r"democratic people'?s republic of korea|north korea", re.I),
                 "CHN": re.compile(r"hong kong sar,? china|macao sar,? china|taiwan province of china", re.I)}


@dataclass(frozen=True)
class TextSource:
    key: str                      # stable id, written on every document (source)
    family: str                   # central_bank | imf
    iso3: str                     # the desk name served; "" for a source covering every country (IMF press releases)
    publisher: str
    hosts: tuple                  # https hosts the adapter may request (index and articles); anything else is skipped
    index_url: str                # "" for manual
    index_format: str             # rss | html_index | manual
    language: str                 # default language of the documents (BCP 47 primary tag); the page's lang wins
    tz: str                       # IANA zone for timestamps that carry no offset
    licence_id: str               # data/licences.csv source_id
    link_re: str = ""             # html_index: regex the href of a document link must match
    content: str = ""             # article body container: "id:<id>", "class:<class>" or a tag name; "" = auto
    layout_verified: bool = False # False: written from the site structure as remembered, not from a live response
    notes: str = ""

    def __post_init__(self):
        if not KEY_RE.fullmatch(self.key):
            raise ValueError(f"bad source key {self.key!r}")
        if self.family not in FAMILIES:
            raise ValueError(f"{self.key}: family {self.family!r} not in {FAMILIES}")
        if self.index_format not in INDEX_FORMATS:
            raise ValueError(f"{self.key}: index_format {self.index_format!r} not in {INDEX_FORMATS}")
        if self.iso3 and self.iso3 not in DESK_COUNTRIES:
            raise ValueError(f"{self.key}: {self.iso3!r} is not a desk name")
        if not LANG_RE.fullmatch(self.language):
            raise ValueError(f"{self.key}: language {self.language!r}")
        if self.index_format == "manual":
            if self.index_url:
                raise ValueError(f"{self.key}: a manual source has no index_url")
        else:
            if not self.index_url.startswith("https://"):
                raise ValueError(f"{self.key}: index_url must be https")
            host = self.index_url.split("/")[2]
            if host not in self.hosts:
                raise ValueError(f"{self.key}: index host {host} not in hosts {self.hosts}")
        if self.index_format == "html_index":
            re.compile(self.link_re)
            if not self.link_re:
                raise ValueError(f"{self.key}: html_index needs link_re")

    @property
    def licence_tag(self) -> str:
        """The licence text written on every document of this source; data/licences.csv rows match it
        (match_licence '^text corpus <key>:')."""
        return (f"text corpus {self.key}: {self.publisher}; terms UNVERIFIED; internal research use only until Sam "
                f"reads them ({TICKET} tighten-only default)")


def _cb(iso3, publisher, hosts, index_url, fmt, lang, tz, link_re="", content="", notes=""):
    return TextSource(key=f"cb_{iso3.lower()}", family="central_bank", iso3=iso3, publisher=publisher,
                      hosts=tuple(hosts), index_url=index_url, index_format=fmt, language=lang, tz=tz,
                      licence_id=f"text_cb_{iso3.lower()}", link_re=link_re, content=content, notes=notes)


CENTRAL_BANKS = (
    _cb("VNM", "State Bank of Vietnam", ["www.sbv.gov.vn"], "", "manual", "vi", "Asia/Ho_Chi_Minh",
        notes="portal pages are script-rendered; no listing feed known here. Parked: Sam saves releases by hand or a "
              "feed is found on the Mac pass"),
    _cb("PHL", "Bangko Sentral ng Pilipinas", ["www.bsp.gov.ph"],
        "https://www.bsp.gov.ph/SitePages/MediaAndResearch/MediaReleases.aspx", "html_index", "en", "Asia/Manila",
        link_re=r"/SitePages/MediaAndResearch/MediaDisp\.aspx\?ItemId=\d+", content="id:mediaContent"),
    _cb("CHN", "People's Bank of China", ["www.pbc.gov.cn"],
        "https://www.pbc.gov.cn/en/3688110/3688172/index.html", "html_index", "en", "Asia/Shanghai",
        link_re=r"^/en/3688110/3688172/\d+/\d+/index\.html$"),
    _cb("MYS", "Bank Negara Malaysia", ["www.bnm.gov.my"], "https://www.bnm.gov.my/rss/press", "rss", "en",
        "Asia/Kuala_Lumpur"),
    _cb("SGP", "Monetary Authority of Singapore", ["www.mas.gov.sg"], "https://www.mas.gov.sg/news", "html_index",
        "en", "Asia/Singapore", link_re=r"^/news/(media-releases|monetary-policy-statements)/\d{4}/[a-z0-9-]+$"),
    _cb("JPN", "Bank of Japan", ["www.boj.or.jp"], "https://www.boj.or.jp/en/rss/whatsnew.xml", "rss", "en",
        "Asia/Tokyo", content="id:contents", notes="RSS 1.0 (RDF) 'What's New' feed"),
    _cb("KOR", "Bank of Korea", ["www.bok.or.kr"], "https://www.bok.or.kr/eng/bbs/E0000634/list.do?menuNo=400069",
        "html_index", "en", "Asia/Seoul", link_re=r"/eng/bbs/E0000634/view\.do\?nttId=\d+"),
    _cb("IND", "Reserve Bank of India", ["www.rbi.org.in", "rbi.org.in"], "https://www.rbi.org.in/pressreleases_rss.xml",
        "rss", "en", "Asia/Kolkata", content="class:tablebg"),
    _cb("PAK", "State Bank of Pakistan", ["www.sbp.org.pk"], "https://www.sbp.org.pk/press/index.htm", "html_index",
        "en", "Asia/Karachi", link_re=r"^/press/\d{4}/[A-Za-z0-9_-]+\.(htm|pdf)$",
        notes="many releases are PDF; PDFs are listed and skipped (no PDF text extraction in this ticket)"),
    _cb("BLZ", "Central Bank of Belize", ["www.centralbank.org.bz"], "", "manual", "en", "America/Belize",
        notes="no listing feed known here. Parked for the Mac pass"),
    _cb("BRA", "Banco Central do Brasil", ["www.bcb.gov.br"], "https://www.bcb.gov.br/api/feed/sitebcb/sitefeeds/notas",
        "rss", "pt", "America/Sao_Paulo"),
    _cb("ARG", "Banco Central de la Republica Argentina", ["www.bcra.gob.ar"],
        "https://www.bcra.gob.ar/Noticias/Noticias.asp", "html_index", "es", "America/Argentina/Buenos_Aires",
        link_re=r"^/Noticias/[A-Za-z0-9_-]+\.asp$"),
    _cb("COL", "Banco de la Republica (Colombia)", ["www.banrep.gov.co"], "https://www.banrep.gov.co/es/rss.xml",
        "rss", "es", "America/Bogota"),
    _cb("VEN", "Banco Central de Venezuela", ["www.bcv.org.ve"], "", "manual", "es", "America/Caracas",
        notes="site availability from abroad is irregular; no listing feed known here. Parked for the Mac pass"),
    _cb("NGA", "Central Bank of Nigeria", ["www.cbn.gov.ng"], "https://www.cbn.gov.ng/Out/PressRelease.html",
        "html_index", "en", "Africa/Lagos", link_re=r"^/Out/\d{4}/[A-Za-z0-9_/-]+\.(html?|pdf)$",
        notes="many releases are PDF; PDFs are listed and skipped"),
    _cb("SEN", "Banque Centrale des Etats de l'Afrique de l'Ouest (BCEAO, WAEMU)", ["www.bceao.int"],
        "https://www.bceao.int/fr/communiques-presse", "html_index", "fr", "Africa/Dakar",
        link_re=r"^/fr/communique-presse/[a-z0-9-]+$", notes="regional central bank: statements cover all WAEMU states"),
    _cb("ZMB", "Bank of Zambia", ["www.boz.zm"], "https://www.boz.zm/media-releases.htm", "html_index", "en",
        "Africa/Lusaka", link_re=r"\.(htm|pdf)$", notes="many releases are PDF; PDFs are listed and skipped"),
    _cb("ZWE", "Reserve Bank of Zimbabwe", ["www.rbz.co.zw"], "https://www.rbz.co.zw/index.php/publications-notices/press-releases",
        "html_index", "en", "Africa/Harare", link_re=r"/index\.php/publications-notices/press-releases/\d+-[a-z0-9-]+"),
)

IMF_PRESS = TextSource(
    key="imf_press", family="imf", iso3="", publisher="International Monetary Fund, press releases",
    hosts=("www.imf.org",), index_url="https://www.imf.org/en/News/RSS?language=eng&series=Press%20Release",
    index_format="rss", language="en", tz="America/New_York", licence_id="text_imf", content="class:article-content",
    notes="one feed for every country: a release is kept only when its title or summary names a desk name")


def _imf_country(iso3: str) -> TextSource:
    return TextSource(
        key=f"imf_country_{iso3.lower()}", family="imf", iso3=iso3,
        publisher="International Monetary Fund, country page", hosts=("www.imf.org",),
        index_url=f"https://www.imf.org/en/Countries/{iso3}", index_format="html_index", language="en",
        tz="America/New_York", licence_id="text_imf", content="class:article-content",
        link_re=r"^(https://www\.imf\.org)?/en/News/Articles/\d{4}/\d{2}/\d{2}/[A-Za-z0-9-]+$",
        notes="press releases, statements and mission concluding statements linked from the country page")


IMF_COUNTRY_PAGES = tuple(_imf_country(i) for i in DESK_COUNTRIES)
SOURCES: dict[str, TextSource] = {s.key: s for s in (*CENTRAL_BANKS, IMF_PRESS, *IMF_COUNTRY_PAGES)}
LICENCE_IDS = tuple(sorted({s.licence_id for s in SOURCES.values()}))


def source(key: str) -> TextSource:
    try:
        return SOURCES[key]
    except KeyError:
        raise KeyError(f"unknown text source {key!r}; known: {', '.join(sorted(SOURCES))}") from None


def norm_iso3(country: str) -> str:
    """ISO3 (any case) or a desk-name alias -> the desk ISO3; ValueError for anything else."""
    c = str(country).strip()
    if c.upper() in DESK_COUNTRIES:
        return c.upper()
    for iso, names in DESK_COUNTRIES.items():
        if any(c.casefold() == n.casefold() for n in names):
            return iso
    raise ValueError(f"{country!r} is not one of the 18 desk names ({', '.join(DESK_COUNTRIES)})")


_ALIAS_RE = {iso: re.compile(r"\b(" + "|".join(re.escape(n) for n in names) + r")\b", re.I)
             for iso, names in DESK_COUNTRIES.items()}


def countries_named(text: str) -> tuple:
    """Desk ISO3s whose names appear in `text` (word boundaries, case-insensitive), in DESK_COUNTRIES order."""
    out = []
    for iso, rx in _ALIAS_RE.items():
        t = ALIAS_EXCLUDE[iso].sub(" ", text) if iso in ALIAS_EXCLUDE else text
        if rx.search(t):
            out.append(iso)
    return tuple(out)
