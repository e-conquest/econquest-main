"""Gate v2 (EQ-A-0017, GOV-037, gap criterion 1d): cross-source and vintage-to-vintage checks for the quality gate.

`feeds.quality_gate` compares a pull with the seed values only. This module adds two checks whose rows are folded
into the same review frame by `merge_into_review`:

- `cross_source_checks`: for concepts that both IMF WEO and the World Bank publish with the same definition
  (`CROSS_PAIRS`), compare the two sources for the latest period both have (at or before the pull year) and hold
  every live cell derived from that concept when they disagree beyond the pair's tolerance.
- `feeds.fx_cross_checks` (EQ-A-0040) uses the same CHECK_COLUMNS shape for BIS WS_XRU against the ECB
  reference rates and is merged the same way.
- `vintage_checks`: compare the live values with the previous vintage's live_inputs.csv / live_profile.csv and hold
  jumps (relative change and absolute floor, the same rule as the gate's seed `change` check) and cells that
  appeared or disappeared since then.

Both return rows `table, key, country, check, status ('ok' | 'hold'), reason` plus the informative columns `live`
and `basis`. Nothing here writes files; vintages are only read."""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Callable

import numpy as np
import pandas as pd

from .feeds import FetchReport, list_vintages, vintage_path

CHECK_COLUMNS = ["table", "key", "country", "check", "status", "reason", "live", "basis"]
REVIEW_COLUMNS = ["table", "key", "country", "seed", "live", "status", "reason"]
CHECK_PREFIX = {"cross_source": "cross", "vintage": "vintage", "fx_cross_source": "fx cross"}
INPUTS, PROFILE = "Inputs", "Country Profile"


# ----------------------------------------------------------------------------------------------
# Cross-source pairs
# ----------------------------------------------------------------------------------------------
@dataclass(frozen=True)
class CrossPair:
    """One concept both sources publish with the same definition.

    weo_series / wb_series: the raw series needed on each side (all must exist for a period to be comparable).
    transform: how each side is put into common units (text, shown in reasons and docs); weo_value / wb_value do it,
      taking {series: value} for one country and period.
    tolerance: (abs_tol, rel_tol). The sources disagree when |WEO - WB| > abs_tol AND
      |WEO - WB| > rel_tol x max(|WEO|, |WB|). abs_tol 0 makes a purely relative test (levels); rel_tol 0 a purely
      absolute one. Rates carry both so a 1-point gap on 200% inflation is not a disagreement.
    keys: the live cells (table, key) whose value is derived from this concept (from either source)."""
    concept: str
    weo_series: tuple[str, ...]
    wb_series: tuple[str, ...]
    transform: str
    tolerance: tuple[float, float]
    keys: tuple[tuple[str, str], ...]
    weo_value: Callable[[dict], float]
    wb_value: Callable[[dict], float]
    note: str = ""


def _one(series: str) -> Callable[[dict], float]:
    return lambda v: v[series]


def _ratio(num: str, den: str, scale: float = 1.0) -> Callable[[dict], float]:
    return lambda v: v[num] / v[den] * scale if v[den] else np.nan


CROSS_PAIRS: list[CrossPair] = [
    # Levels: active with the series feeds.py fetches today (WEO_CODES and WB_SERIES).
    CrossPair(
        "gdp_usd", ("NGDPD",), ("NY.GDP.MKTP.CD",),
        "WEO NGDPD is US$ billions; WB NY.GDP.MKTP.CD is US$, divided by 1e9. Both: GDP at current prices converted "
        "at the period-average market rate.", (0.0, 0.10),
        ((PROFILE, "reserves"),),                              # reserves % GDP uses NY.GDP.MKTP.CD as denominator
        _one("NGDPD"), lambda v: v["NY.GDP.MKTP.CD"] / 1e9,
        "10%: exchange-rate and rebasing revisions between vintages stay below it (2025: all but ZWE within 4%)."),
    CrossPair(
        "gdp_per_capita_usd", ("NGDPDPC",), ("NY.GDP.MKTP.CD", "SP.POP.TOTL"),
        "WEO NGDPDPC is US$ per person; WB side is NY.GDP.MKTP.CD / SP.POP.TOTL (US$ per person). WB does publish "
        "NY.GDP.PCAP.CD but feeds.py does not fetch it; the ratio is its definition.", (0.0, 0.10),
        ((INPUTS, "5.14"),),
        _one("NGDPDPC"), _ratio("NY.GDP.MKTP.CD", "SP.POP.TOTL"),
        "10%: WEO uses national population estimates, WB the UN WPP; they differ by up to ~6% (MYS, PAK)."),
    CrossPair(
        "population", ("NGDPD", "NGDPDPC"), ("SP.POP.TOTL",),
        "WEO population is implied as NGDPD x 1e9 / NGDPDPC (persons; WEO's LP is not fetched); WB SP.POP.TOTL is "
        "persons (midyear).", (0.0, 0.10),
        ((PROFILE, "pop"),),
        _ratio("NGDPD", "NGDPDPC", 1e9), _one("SP.POP.TOTL"),
        "10%, same reason as per capita GDP: the two population sources differ by definition by up to ~6%."),
    # Rates: same definition, but the WB series are not in feeds.WB_SERIES yet, so these pairs are inactive (they
    # produce no rows) until NY.GDP.MKTP.KD.ZG, FP.CPI.TOTL.ZG and BN.CAB.XOKA.GD.ZS are added to the WB pull.
    CrossPair(
        "real_gdp_growth", ("NGDP_RPCH",), ("NY.GDP.MKTP.KD.ZG",),
        "Both annual % change of GDP at constant prices; no conversion.", (1.0, 0.25),
        ((INPUTS, "5.6"), (INPUTS, "5.12")),
        _one("NGDP_RPCH"), _one("NY.GDP.MKTP.KD.ZG"),
        "Compares the latest actual year: 5.6 is a t+1 WEO projection with no WB counterpart, so this checks the "
        "history it is built on."),
    CrossPair(
        "cpi_inflation", ("PCPIPCH",), ("FP.CPI.TOTL.ZG",),
        "Both annual % change of the period-average consumer price index; no conversion.", (1.0, 0.10),
        ((INPUTS, "5.5"), (INPUTS, "5.13")),                   # 5.13 = BIS policy rate minus WEO PCPIPCH
        _one("PCPIPCH"), _one("FP.CPI.TOTL.ZG")),
    CrossPair(
        "current_account_pct_gdp", ("BCA_NGDPD",), ("BN.CAB.XOKA.GD.ZS",),
        "Both current account balance (BPM6) in % of GDP; no conversion.", (1.5, 0.25),
        ((INPUTS, "2.8"),),
        _one("BCA_NGDPD"), _one("BN.CAB.XOKA.GD.ZS")),
]
"""Excluded on purpose: gross debt (WEO GGXWDG_NGDP is general government; WB GC.DOD.TOTL.GD.ZS is central government
only), fiscal balances (WB GC.* are central government, cash basis), exports % GDP and reserves (WEO publishes neither
in the codes fetched), IDS/WGI series (no WEO counterpart)."""


def _raw_of(report_or_raw) -> dict:
    return report_or_raw.raw if isinstance(report_or_raw, FetchReport) else dict(report_or_raw or {})


def _by_period(long: pd.DataFrame | None, iso: str, series: tuple[str, ...]) -> dict[int, dict]:
    """{period: {series: value}} for the periods where every one of `series` has a finite value."""
    if long is None or long.empty:
        return {}
    s = long[(long["iso"].astype(str) == iso) & long["series"].isin(series)].copy()
    s["period"] = pd.to_numeric(s["period"], errors="coerce")
    s["value"] = pd.to_numeric(s["value"], errors="coerce")
    s = s.dropna(subset=["period", "value"])
    out: dict[int, dict] = {}
    for (p, ser), v in s.groupby(["period", "series"])["value"].last().items():
        out.setdefault(int(p), {})[ser] = float(v)
    return {p: d for p, d in out.items() if all(x in d for x in series)}


def _live_value(report, table: str, key: str, country: str) -> float:
    if not isinstance(report, FetchReport):
        return np.nan
    frame = report.indicators if table == INPUTS else report.profile
    try:
        v = frame.at[key, country] if table == INPUTS else frame.at[country, key]
    except KeyError:
        return np.nan
    v = pd.to_numeric(v, errors="coerce")
    return float(v) if pd.notna(v) else np.nan


def cross_source_checks(report_or_raw, u, year: int, pairs: list[CrossPair] | None = None, max_lag: int = 5) -> pd.DataFrame:
    """Compare WEO with the World Bank for each pair in `pairs` (default CROSS_PAIRS) and each country of `u`.

    report_or_raw: a FetchReport (its `raw`; only cells with a finite live value get rows) or a {feed: long table}
    dict (rows for every pair key and country). The comparison period is the latest period at or before `year` for
    which both sides have every series they need, and not older than `year - max_lag`; the reason names it. A pair
    with no comparable period for a country gives no row. Returns CHECK_COLUMNS with check = 'cross_source'."""
    pairs = CROSS_PAIRS if pairs is None else pairs
    raw = _raw_of(report_or_raw)
    weo, wb = raw.get("weo"), raw.get("worldbank")
    rows = []
    if weo is None or wb is None:
        return pd.DataFrame(rows, columns=CHECK_COLUMNS)
    iso_of = dict(zip(u.names, u.countries["iso"].astype(str)))
    for pair in pairs:
        abs_tol, rel_tol = pair.tolerance
        for country in u.names:
            iso = iso_of.get(country)
            a, b = _by_period(weo, iso, pair.weo_series), _by_period(wb, iso, pair.wb_series)
            common = sorted(p for p in set(a) & set(b) if year - max_lag <= p <= year)
            if not common:
                continue
            p = common[-1]
            w, k = pair.weo_value(a[p]), pair.wb_value(b[p])
            if not (np.isfinite(w) and np.isfinite(k)):
                continue
            d = w - k
            scale = max(abs(w), abs(k), 1e-12)
            bad = abs(d) > abs_tol and abs(d) > rel_tol * scale
            tol = " and ".join(t for t in ([f"{abs_tol:g}"] if abs_tol else []) + ([f"{rel_tol:.0%}"] if rel_tol else []))
            basis = f"WEO {'+'.join(pair.weo_series)} vs WB {'+'.join(pair.wb_series)}, period {p}"
            reason = (f"{pair.concept} {p}: WEO {w:.4g} vs WB {k:.4g} (diff {d:+.4g}, {d / scale:+.2%} of the larger; tolerance {tol})"
                      + ("" if bad else " within tolerance"))
            for table, key in pair.keys:
                live = _live_value(report_or_raw, table, key, country)
                if isinstance(report_or_raw, FetchReport) and not np.isfinite(live):
                    continue
                rows.append({"table": table, "key": key, "country": country, "check": "cross_source",
                             "status": "hold" if bad else "ok", "reason": reason, "live": live, "basis": basis})
    return pd.DataFrame(rows, columns=CHECK_COLUMNS)


# ----------------------------------------------------------------------------------------------
# Vintage-to-vintage
# ----------------------------------------------------------------------------------------------
def _read_vintage_table(path: Path) -> pd.DataFrame | None:
    """A vintage live_inputs.csv / live_profile.csv as floats. Read as text first so ids such as 2.10 and 2.1 stay
    distinct; the first column is the index whatever its header ('', 'Unnamed: 0')."""
    if not path.exists():
        return None
    df = pd.read_csv(path, dtype=str, keep_default_na=False)
    df = df.set_index(df.columns[0])
    df.index = df.index.astype(str).str.strip()
    return df.apply(lambda c: pd.to_numeric(c.replace("", np.nan), errors="coerce"))


def _span(u, key: str) -> float | None:
    rb = getattr(u, "rulebook", None)
    if rb is None or "id" not in rb.columns:
        return None
    r = rb[rb["id"].astype(str) == key]
    if r.empty:
        return None
    th = pd.to_numeric(r.iloc[0][["t0", "t25", "t50", "t75", "t100"]], errors="coerce").dropna()
    return float(th.max() - th.min()) if len(th) >= 2 else None


def vintage_checks(data_dir, report: FetchReport, previous_vintage_id: str | None = None, max_rel_change: float = 0.5,
                   u=None, span_frac: float = 0.25, min_abs_change: float = 0.0, current_vintage_id: str | None = None,
                   appearance_status: str = "hold") -> pd.DataFrame:
    """Compare `report`'s live values with a previous vintage (default: the latest in list_vintages other than
    `current_vintage_id`; call before save_vintage, or pass the new id). No previous vintage gives an empty frame.

    Rule, mirroring quality_gate's `change` check: a cell is held when |new - prev| > max_rel_change x |prev| AND
    |new - prev| exceeds a floor: span_frac x the rulebook threshold span for Inputs keys when `u` has a rulebook,
    otherwise `min_abs_change`. A cell with a value in the previous vintage and none now is 'disappeared'; one with
    none then and a value now is 'reappeared'; both get `appearance_status` ('hold' by default, 'ok' to only list
    them). Exception (EQ-A-0036): when the key had no finite value for any country in the previous vintage, the key
    is new coverage (e.g. a series an older install never fetched), not a reappearance: its cells are listed as 'ok'
    with reason 'new series: not in <vid>' and still face quality_gate's seed-based range/change checks.
    Keys or countries absent from either vintage are not compared (universe changes are not jumps).
    Returns CHECK_COLUMNS with check = 'vintage' and basis = the previous vintage id."""
    rows: list[dict] = []
    if previous_vintage_id is None:
        ids = [v for v in list_vintages(Path(data_dir)) if v != current_vintage_id]
        if not ids:
            return pd.DataFrame(rows, columns=CHECK_COLUMNS)
        previous_vintage_id = ids[-1]
    vdir = vintage_path(Path(data_dir), previous_vintage_id)
    vid = vdir.name
    for table, fname, new in ((INPUTS, "live_inputs.csv", report.indicators), (PROFILE, "live_profile.csv", report.profile)):
        prev = _read_vintage_table(vdir / fname)
        if prev is None or new is None or new.empty:
            continue
        new = new.copy()
        new.index = new.index.astype(str)
        if table == INPUTS:                              # rows = key, columns = country
            prev_m, new_m = prev, new
        else:                                            # rows = country, columns = key
            prev_m, new_m = prev.T, new.T
        keys = [k for k in new_m.index if k in prev_m.index]
        countries = [c for c in new_m.columns if c in prev_m.columns]
        for key in keys:
            span = _span(u, key) if table == INPUTS else None
            floor = span_frac * span if span is not None else min_abs_change
            new_key = not np.isfinite(np.asarray(prev_m.loc[key], dtype=float)).any()   # no country had it then
            for c in countries:
                a = pd.to_numeric(prev_m.at[key, c], errors="coerce")
                b = pd.to_numeric(new_m.at[key, c], errors="coerce")
                fa, fb = bool(np.isfinite(a)), bool(np.isfinite(b))
                if not fa and not fb:
                    continue
                if fa and not fb:
                    status, reason = appearance_status, f"disappeared: {a:.4g} in {vid}, no live value now"
                elif fb and not fa and new_key:
                    status, reason = "ok", f"new series: not in {vid}, now {b:.4g}"
                elif fb and not fa:
                    status, reason = appearance_status, f"reappeared: no value in {vid}, now {b:.4g}"
                else:
                    d = float(b - a)
                    rel = d / max(abs(float(a)), 1e-9)
                    jump = abs(d) > max_rel_change * max(abs(float(a)), 1e-9) and abs(d) > floor
                    status = "hold" if jump else "ok"
                    reason = f"{vid}: {a:.4g} -> {b:.4g} ({rel * 100:+.0f}%, floor {floor:.4g})"
                rows.append({"table": table, "key": str(key), "country": c, "check": "vintage", "status": status,
                             "reason": reason, "live": float(b) if fb else np.nan, "basis": vid})
    return pd.DataFrame(rows, columns=CHECK_COLUMNS)


# ----------------------------------------------------------------------------------------------
# Merge into the gate's review frame
# ----------------------------------------------------------------------------------------------
def merge_into_review(review: pd.DataFrame, extra: pd.DataFrame | None) -> pd.DataFrame:
    """Fold check rows (CHECK_COLUMNS) into a quality_gate review frame and return a new frame with the same columns.

    Only 'hold' rows of `extra` act. For a cell already in `review`: an 'ok' becomes 'hold'; 'hold' and 'missing'
    keep their status (a hold is never downgraded; a missing cell has nothing to apply); the reason gets
    '<cross|vintage>: <reason>' appended with '; '. A held cell not in `review` (e.g. a value that disappeared while
    its feed failed) is added with status 'hold' if it carries a live value, else 'missing'. Other columns of new
    rows are left empty (NaN for seed, '' for decision text columns)."""
    out = review.copy()
    if extra is None or extra.empty:
        return out
    holds = extra[extra["status"] == "hold"]
    if holds.empty:
        return out
    out["key"] = out["key"].astype(str)
    out["reason"] = out["reason"].fillna("").astype(str)
    index = {(t, k, c): i for i, (t, k, c) in enumerate(zip(out["table"], out["key"], out["country"]))}
    new_rows: dict[tuple, dict] = {}
    for r in holds.itertuples(index=False):
        cell = (r.table, str(r.key), r.country)
        text = f"{CHECK_PREFIX.get(r.check, r.check)}: {r.reason}"
        if cell in index:
            i = out.index[index[cell]]
            if out.at[i, "status"] == "ok":
                out.at[i, "status"] = "hold"
            if text not in out.at[i, "reason"]:
                out.at[i, "reason"] = "; ".join(x for x in (out.at[i, "reason"], text) if x)
        elif cell in new_rows:
            if text not in new_rows[cell]["reason"]:
                new_rows[cell]["reason"] += "; " + text
        else:
            live = getattr(r, "live", np.nan)
            live = float(live) if pd.notna(live) else np.nan
            new_rows[cell] = {"table": cell[0], "key": cell[1], "country": cell[2], "seed": np.nan, "live": live,
                              "status": "hold" if np.isfinite(live) else "missing", "reason": text}
    if new_rows:
        add = pd.DataFrame(list(new_rows.values()))
        for c in out.columns:
            if c not in add.columns:
                add[c] = np.nan if pd.api.types.is_numeric_dtype(out[c]) else ""
        out = pd.concat([out, add[list(out.columns)]], ignore_index=True)
    return out
