"""Free official sovereign spread history (EQ-A-0063): local-currency and hard-currency yields minus the US Treasury.

For every desk country (data/countries.csv) the registry SPREAD_REGISTRY lists the candidate free sources for
    local   a 10-year (or the nearest benchmark) local-currency government bond yield: OECD MEI long-term rates on
            FRED (IRLTLT01<ISO2>M156N, monthly) for OECD members, a central-bank API where one is known (BoK ECOS),
            else the institution that publishes it by hand (manual) or nothing (none);
    hard    a hard-currency (US$) sovereign bond yield. No free official series is known for any desk name: secondary
            prices of US$ Eurobonds come from licensed vendors (J.P. Morgan EMBI, Bloomberg, ICE, LSEG). Each entry
            says so with the reason. The build supports a hard leg as soon as one is registered and verified;
plus one USD benchmark: the 10-year Treasury constant-maturity yield, FRED DGS10 (daily).

Spreads (basis points):
    local_minus_ust  (local yield - UST 10y) x 100. NOT a credit spread: it carries the expected depreciation of the
                     currency against the dollar (FX premium) and the inflation differential as well as default risk.
                     It can be negative (JPY). Every row says so (includes_fx_inflation_premium = True).
    hard_minus_ust   (US$ sovereign yield - UST 10y) x 100: a credit spread (tenor mismatch possible). None served today.

EVERYTHING HERE IS UNVERIFIED. This cloud cannot reach FRED or ECOS. Series codes follow the providers' documented
patterns as remembered, not a live answer. Each entry ships verified="no"; a series counts as verified only when
data/market_history/spreads/series_verified.csv has a row with the SAME (iso3, leg, series_key) and verified=yes, set
after the check on Sam's Mac (docs/runbooks/A-spread-history.md). Every output row carries `verified`.

Licences: DGS10 is US government data (public domain, FRED terms apply). The OECD long-term rates on FRED are
third-party data that FRED shows as copyrighted by the OECD: RESTRICTED (internal research, no client output or data
room) until Sam / AGENT-09 confirm the terms. BoK ECOS: the bank's own terms, UNVERIFIED: RESTRICTED until Sam clears it.
`restricted` is on every row: the registry flag OR the licence register (data/licences.csv via licences.licence_for,
see is_restricted); the register can add a restriction, never lift one.

Point in time, mirroring market_history (EQ-A-0054):
1. the parsed pulls are saved first into an append-only vintage data/market_history/spreads/vintages/<ts>-<hash8>/
   (raw_fred.csv, raw_ecos.csv, request.json; files 0444; row in vintages/index.csv);
2. the spreads are built from that vintage read back from disk into data/market_history/spreads/builds/<vintage_id>/
   (spreads_daily.csv, spreads_monthly.csv, coverage.csv, spreads.provenance.json; files 0444);
3. there is NO apply: nothing in the engine reads these files. Team B decides (handoff under EQ-A-0063) whether layer 2
   or the GPR elasticities use them; wiring waits for that answer and Sam's sign-off.
Everything lives under data/market_history/spreads/, never at the top level of data/market_history/ (garch.load_prices
merges every top-level CSV there into the price history).

No forward fill: a daily spread exists only on a date both the local series and DGS10 published. Monthly rows are
calendar-month means, dated at the month end (the average is only known then); a daily series contributes a month
only with at least MIN_DAYS_MONTH observations, and an incomplete last month is dropped. One source per country and
leg, never mixed across dates: the first registry entry (in order) that returned data.

Transport: sources.https_get only (https, redirects refused, body capped), feeds._with_retries for transient errors.
Fail-fast: DGS10 is pulled first and any failure raises before anything is written (no benchmark, no spread); a proxy
refusal or DNS failure stops every further request to that host. Credentials: FRED_API_KEY (environment only,
market.public.fred_api_key), ECOS_API_KEY (environment or keychain); redacted from every message, never written.

Command line (Sam's Mac):
    python -m econquest.ingestion.spreads plan [--write]             # registry + planned coverage, no network
    python -m econquest.ingestion.spreads build [--start 2016-01-01] [--end 2026-10-23] [--asof YYYY-MM-DD]
    python -m econquest.ingestion.spreads status                     # vintages (hash-checked), latest build coverage
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import sys
import tempfile
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable, Iterable, Mapping

import numpy as np
import pandas as pd

TICKET = "EQ-A-0063"
SCHEMA = "econquest.spreads.provenance/1"
LEGS = ("local", "hard")
USD_ISO = "USA"
UST_SERIES = "DGS10"
MANUAL = "manual"
NONE = "none"
MACHINE_APIS = ("fred", "bok_ecos")
MIN_DAYS_MONTH = 10
HISTORY_YEARS = 10
MAX_BYTES = 20 * 1024 * 1024

SPREADS_DIR = Path("market_history") / "spreads"
REGISTRY_NAME = "registry.csv"
COVERAGE_NAME = "coverage.csv"
VERIFIED_NAME = "series_verified.csv"
DAILY_NAME = "spreads_daily.csv"
MONTHLY_NAME = "spreads_monthly.csv"
SIDECAR_NAME = "spreads.provenance.json"
RAW_FRED_NAME = "raw_fred.csv"
RAW_ECOS_NAME = "raw_ecos.csv"
REQUEST_NAME = "request.json"

RAW_COLUMNS = ["iso3", "leg", "api", "series_key", "date", "value", "freq", "tenor_y", "unit", "realtime_start",
               "realtime_end"]
SPREAD_COLUMNS = ["date", "period", "iso", "country", "leg", "spread_type", "freq", "tenor_y", "yield_pct", "ust_pct",
                  "spread_bp", "n_days", "yield_source", "yield_series", "ust_series", "includes_fx_inflation_premium",
                  "restricted", "verified"]
COVERAGE_COLUMNS = ["iso", "country", "currency", "local_status", "local_source", "local_series", "local_freq",
                    "hard_status", "hard_source", "hard_series", "usable_spread", "n_daily", "n_monthly", "first",
                    "last", "restricted", "verified", "reason"]
VERIFIED_COLUMNS = ["iso3", "leg", "source", "series_key", "verified", "checked_on", "checked_by", "evidence"]
VINTAGE_INDEX_COLUMNS = ["vintage_id", "retrieved_utc", "hash", "n_files"]
SPREAD_TYPE = {"local": "local_minus_ust", "hard": "hard_minus_ust"}
SPREAD_NOTE = {
    "local": ("local-currency yield minus UST 10y: includes the FX (expected depreciation) and inflation premium as well "
              "as default risk; not a credit spread; can be negative"),
    "hard": "US$ sovereign yield minus UST 10y: credit spread (tenor may differ from 10y)",
}
EURO_AREA_NOTE = ("ECB YC / long-term interest rates (convergence) cover euro-area and EU sovereigns only: no desk country "
                  "is in the euro area. XOF is pegged to the euro but WAEMU sovereigns (Senegal) are not in ECB data.")
UST_MONTHLY_RULE = ("UST monthly = calendar-month mean of DGS10 business-day values (as the FRED GS10 definition; "
                    "computed here from the same vintage, GS10 is not pulled)")

# ------------------------------------------------------------------------------------------------ licences
FRED_TERMS_URL = "https://fred.stlouisfed.org/legal/"
DGS10_LICENCE = ("US Treasury 10y constant maturity via Federal Reserve H.15 on FRED: US government data, public domain; "
                 "cite FRED, Federal Reserve Bank of St. Louis; FRED terms apply (UNVERIFIED)")
OECD_FRED_LICENCE = ("OECD Main Economic Indicators long-term interest rate via FRED: THIRD-PARTY series; FRED shows it as "
                     "copyright OECD, reprinted with permission, and its terms send reuse questions to the copyright "
                     "owner (UNVERIFIED). RESTRICTED: internal research only, no client output, no data room, until "
                     "Sam / AGENT-09 confirm the OECD terms (the OECD's own data portal may license it CC BY 4.0, "
                     "UNVERIFIED)")
ECOS_LICENCE = "Bank of Korea ECOS Open API: free registered key; BoK terms of use (UNVERIFIED)"
ECOS_TERMS_URL = "https://ecos.bok.or.kr/api/"
NO_HARD = ("no free official hard-currency (US$) sovereign yield series known: Eurobond secondary prices and yields come "
           "from licensed vendors (J.P. Morgan EMBI, Bloomberg, ICE, LSEG) and the issuer publishes none (UNVERIFIED)")


@dataclass(frozen=True)
class SpreadSeries:
    """One candidate series. `api`: fred, bok_ecos (machine), manual (published by hand, not pulled) or none. `series_key`
    is the code in that API ('' when not known here). `freq` D or M; `tenor_y` the maturity in years; `unit` pct."""
    iso3: str
    leg: str
    source: str
    api: str
    series_key: str = ""
    freq: str = ""
    tenor_y: float = 10.0
    licence: str = ""
    terms_url: str = ""
    restricted: bool = False
    verified: str = "no"
    note: str = ""

    @property
    def machine(self) -> bool:
        return self.api in MACHINE_APIS and bool(self.series_key)


def is_restricted(s: SpreadSeries, register: list[dict] | None = None) -> bool:
    """Whether rows from `s` are restricted (no client output): the registry flag `s.restricted` OR the licence
    register (data/licences.csv via licences.licence_for on the series' source and licence text; EQ-A-0076) saying
    anything but client_output=allowed. The register can only add a restriction, never lift one the code sets
    (SEC-A-010 L5): clearing ECOS (Sam's decision) takes both the register row and the ECOS registry flag."""
    from . import licences
    row = licences.licence_for(source=s.source, licence=s.licence, register=register)
    reg_restricted = row is not None and str(row.get("client_output", "")).strip().lower() != "allowed"
    return bool(s.restricted) or reg_restricted


def _oecd(iso3: str, iso2: str, note: str) -> SpreadSeries:
    return SpreadSeries(iso3, "local", "OECD MEI via FRED", "fred", f"IRLTLT01{iso2}M156N", "M", 10.0, OECD_FRED_LICENCE,
                        FRED_TERMS_URL, True, "no", "long-term government bond yield (around 10y), monthly, % p.a.; "
                        "FRED code from the documented IRLTLT01<ISO2>M156N pattern, UNVERIFIED; " + note)


def _manual(iso3: str, leg: str, source: str, note: str) -> SpreadSeries:
    return SpreadSeries(iso3, leg, source, MANUAL, note=note)


def _none(iso3: str, leg: str, note: str) -> SpreadSeries:
    return SpreadSeries(iso3, leg, "", NONE, note=note)


_NO_API = "no documented machine API known here (UNVERIFIED); not pulled"
UST_ENTRY = SpreadSeries(USD_ISO, "usd", "Federal Reserve H.15 via FRED", "fred", UST_SERIES, "D", 10.0, DGS10_LICENCE,
                         FRED_TERMS_URL, False, "no", "10-year Treasury constant maturity, daily, % p.a. (bond-equivalent); "
                         "'.' (no value) skipped, never filled; already in market.public.FRED_SERIES")
_ENTRIES: list[SpreadSeries] = [
    # Asia
    _manual("VNM", "local", "HNX / VBMA / State Bank of Vietnam", "government bond yields on web pages; " + _NO_API),
    _none("VNM", "hard", NO_HARD),
    _manual("PHL", "local", "Bureau of the Treasury / BSP", "PH BVAL reference rates are calculated by Bloomberg "
            "(licensed, UNVERIFIED); " + _NO_API),
    _none("PHL", "hard", NO_HARD),
    _manual("CHN", "local", "ChinaBond (CCDC) / PBoC", "ChinaBond curves are on its website under terms that limit "
            "reuse (UNVERIFIED); no OECD MEI long-term rate for China known on FRED (UNVERIFIED); " + _NO_API),
    _none("CHN", "hard", NO_HARD),
    _manual("MYS", "local", "Bank Negara Malaysia / BPAM", "BNM Open API yield endpoint not confirmed (UNVERIFIED); "
            "BPAM curves are licensed (UNVERIFIED); " + _NO_API),
    _none("MYS", "hard", NO_HARD),
    _manual("SGP", "local", "Monetary Authority of Singapore", "SGS benchmark yields on the MAS website; MAS API resource "
            "ids not known here (UNVERIFIED); " + _NO_API),
    _none("SGP", "hard", "not applicable: no foreign-currency sovereign bonds known (UNVERIFIED)"),
    _oecd("JPN", "JP", "OECD member"),
    _manual("JPN", "local", "Ministry of Finance Japan", "daily JGB benchmark yields CSV on mof.go.jp (jgbcme); layout "
            "and URL not confirmed here (UNVERIFIED); a parser is a follow-up once confirmed"),
    _none("JPN", "hard", "not applicable: no US$ sovereign bonds known (UNVERIFIED)"),
    SpreadSeries("KOR", "local", "BoK ECOS", "bok_ecos", "817Y002/D/010210000", "D", 10.0, ECOS_LICENCE, ECOS_TERMS_URL,
                 True, "no", "Treasury bonds 10-year market yield, daily, % p.a.; ECOS STAT_CODE/FREQ/ITEM_CODE1 "
                 "UNVERIFIED (check with the ECOS StatisticItemList function)"),
    _oecd("KOR", "KR", "OECD member; used only when ECOS returns nothing"),
    _none("KOR", "hard", "occasional US$ foreign exchange stabilisation bonds (UNVERIFIED); " + NO_HARD),
    _oecd("IND", "IN", "India is not an OECD member: MEI partner coverage, existence and currency of the FRED series "
          "UNVERIFIED"),
    _manual("IND", "local", "RBI / FBIL", "FBIL G-sec benchmark valuations and RBI DBIE: " + _NO_API),
    _none("IND", "hard", "not applicable: no US$ sovereign bonds known (UNVERIFIED)"),
    _manual("PAK", "local", "State Bank of Pakistan (EasyData)", "EasyData has a keyed API (UNVERIFIED) but PIB yield "
            "series codes are not known here; not pulled"),
    _none("PAK", "hard", NO_HARD),
    # Latin America
    _none("BLZ", "local", "no domestic long-term government bond market with a published yield history known "
          "(UNVERIFIED)"),
    _none("BLZ", "hard", NO_HARD),
    _manual("BRA", "local", "Tesouro Nacional (Tesouro Transparente)", "daily NTN-F/LTN prices and yields as CSV; URL "
            "and layout not confirmed here (UNVERIFIED); ANBIMA curves are licensed; no BCB SGS 10y yield series "
            "known; no OECD MEI series for Brazil known on FRED (UNVERIFIED)"),
    _none("BRA", "hard", NO_HARD),
    _manual("ARG", "local", "BCRA / Secretaria de Finanzas", "the peso curve is mostly CER-linked and short: no free 10y "
            "nominal benchmark known (UNVERIFIED); " + _NO_API),
    _none("ARG", "hard", NO_HARD),
    _oecd("COL", "CO", "OECD member since 2020"),
    _manual("COL", "local", "Banco de la Republica (TES)", "TES yields on the BanRep website; " + _NO_API),
    _none("COL", "hard", NO_HARD),
    _none("VEN", "local", "no functioning local-currency government bond market with published yields (UNVERIFIED)"),
    _none("VEN", "hard", "bonds in default since 2017 trade on recovery value, quoted by licensed vendors only; "
          "a yield spread is not meaningful"),
    # Africa
    _manual("NGA", "local", "Debt Management Office / CBN", "FGN bond yields in PDF / HTML releases; " + _NO_API),
    _none("NGA", "hard", NO_HARD),
    _manual("SEN", "local", "UMOA-Titres / BCEAO (WAEMU)", "regional auction results only; no secondary-market yield "
            "history API known (UNVERIFIED)"),
    _none("SEN", "hard", NO_HARD),
    _manual("ZMB", "local", "Bank of Zambia", "government bond auction yields on the BoZ website; " + _NO_API),
    _none("ZMB", "hard", "Eurobonds restructured 2024 (UNVERIFIED); " + NO_HARD),
    _none("ZWE", "local", "no local-currency government bond market with published yields (UNVERIFIED)"),
    _none("ZWE", "hard", "in arrears on external debt; no traded US$ sovereign bond with a yield (UNVERIFIED)"),
]


def registry_entries() -> list[SpreadSeries]:
    """Every entry, the USD benchmark first."""
    return [UST_ENTRY, *_ENTRIES]


def entries_for(iso3: str, leg: str, registry: Iterable[SpreadSeries] | None = None) -> list[SpreadSeries]:
    return [s for s in (registry if registry is not None else _ENTRIES) if s.iso3 == iso3 and s.leg == leg]


def registry_frame(registry: Iterable[SpreadSeries] | None = None) -> pd.DataFrame:
    rows = [{**asdict(s), "machine": s.machine} for s in (registry if registry is not None else registry_entries())]
    return pd.DataFrame(rows, columns=[*SpreadSeries.__dataclass_fields__, "machine"])


class SpreadError(RuntimeError):
    """The spread history could not be pulled or built (nothing is half-written)."""


# ------------------------------------------------------------------------------------------------ desk and verification
def _sp(data_dir) -> Path:
    return Path(data_dir) / SPREADS_DIR


def desk_countries(data_dir) -> pd.DataFrame:
    """iso, country, currency, iso2 of data/countries.csv (the desk list), in file order."""
    from .sources import read_csv_keep_na_code
    c = read_csv_keep_na_code(Path(data_dir) / "countries.csv", dtype=str)
    need = {"iso", "country", "currency", "iso2"}
    if not need <= set(c.columns):
        raise SpreadError(f"countries.csv lacks {sorted(need - set(c.columns))}")
    return c[["iso", "country", "currency", "iso2"]].fillna("").reset_index(drop=True)


def load_verified(data_dir) -> set[tuple[str, str, str]]:
    """{(iso3, leg, series_key)} marked verified=yes in spreads/series_verified.csv (empty when absent). A row counts
    only for the series_key it names, so changing a code in the registry drops its verification."""
    try:
        m = pd.read_csv(_sp(data_dir) / VERIFIED_NAME, dtype=str, keep_default_na=False)
    except (OSError, ValueError):
        return set()
    if not {"iso3", "leg", "series_key", "verified"} <= set(m.columns):
        return set()
    m = m[m["verified"].str.strip().str.lower() == "yes"]
    return {(a.strip(), b.strip(), c.strip()) for a, b, c in zip(m["iso3"], m["leg"], m["series_key"])}


def verified_template(registry: Iterable[SpreadSeries] | None = None) -> pd.DataFrame:
    rows = [{"iso3": s.iso3, "leg": s.leg, "source": s.source, "series_key": s.series_key, "verified": "no",
             "checked_on": "", "checked_by": "", "evidence": ""}
            for s in (registry if registry is not None else registry_entries()) if s.machine]
    return pd.DataFrame(rows, columns=VERIFIED_COLUMNS)


def plan_coverage(desk: pd.DataFrame, registry: Iterable[SpreadSeries] | None = None) -> pd.DataFrame:
    """Planned coverage before any pull: per desk country, the first machine candidate per leg (status 'candidate
    (UNVERIFIED)'), else the manual source or 'none', with the reasons."""
    reg = list(registry if registry is not None else _ENTRIES)
    rows = []
    for d in desk.itertuples(index=False):
        out = {"iso": d.iso, "country": d.country, "currency": d.currency, "n_daily": 0, "n_monthly": 0, "first": "",
               "last": "", "verified": "no"}
        reasons, restricted = [], False
        for leg in LEGS:
            es = entries_for(d.iso, leg, reg)
            mach = [s for s in es if s.machine]
            if mach:
                s = mach[0]
                st, src, ser, fq = "candidate (UNVERIFIED)", s.source, s.series_key, s.freq
                restricted = restricted or is_restricted(s)
            elif es:
                s = es[0]
                st, src, ser, fq = (MANUAL if s.api == MANUAL else NONE), s.source, "", ""
                reasons.append(f"{leg}: {s.note}")
            else:
                st, src, ser, fq = NONE, "", "", ""
                reasons.append(f"{leg}: not in the spread registry")
            out.update({f"{leg}_status": st, f"{leg}_source": src, f"{leg}_series": ser})
            if leg == "local":
                out["local_freq"] = fq
        out["usable_spread"] = ("candidate (UNVERIFIED)" if out["local_status"].startswith("candidate")
                                or out["hard_status"].startswith("candidate") else "no")
        out["restricted"] = restricted
        out["reason"] = " | ".join(reasons)
        rows.append(out)
    return pd.DataFrame(rows, columns=COVERAGE_COLUMNS)


# ------------------------------------------------------------------------------------------------ fetch
@dataclass
class SpreadFetcher:
    """Pulls every machine series of the registry for the desk countries, DGS10 first (module docstring). `env` maps
    credential names (tests); the default is the environment (FRED) and environment then keychain (ECOS)."""
    timeout: float = 30.0
    retries: int = 2
    backoff: float = 2.0
    sleep: Callable[[float], None] | None = None
    max_bytes: int = MAX_BYTES
    env: Mapping | None = None

    def _env(self, name: str) -> str:
        if self.env is not None:
            return str(self.env.get(name, "") or "").strip()
        if name == "FRED_API_KEY":
            return os.environ.get(name, "").strip()          # FRED: environment only (market.public)
        from .market.vendors.base import secret
        return secret(name, keyring_service="econquest")

    def _get(self, url: str, accept: str = "application/json") -> bytes:
        from . import feeds as F
        from .sources import https_get
        return F._with_retries(lambda: https_get(url, {"User-Agent": "econquest/0.2", "Accept": accept},
                                                 timeout=self.timeout, max_bytes=self.max_bytes),
                               retries=self.retries, backoff=self.backoff, sleep=self.sleep)

    def _fred(self, s: SpreadSeries, start: str, end: str, key: str, asof: str | None) -> list[dict]:
        from .market.public import fred_url, parse_fred_json
        body = self._get(fred_url(s.series_key, start, end, key, asof))
        obs = parse_fred_json(body, s.series_key, asof=asof)
        return [{"iso3": s.iso3, "leg": s.leg, "api": s.api, "series_key": s.series_key, "date": r.date,
                 "value": float(r.value), "freq": s.freq, "tenor_y": s.tenor_y, "unit": "pct",
                 "realtime_start": r.realtime_start, "realtime_end": r.realtime_end}
                for r in obs.itertuples(index=False) if start <= r.date <= end]

    def _ecos(self, s: SpreadSeries, start: dt.date, end: dt.date, key: str) -> list[dict]:
        from .official.central_banks import APIS, CbSeries
        api = APIS["bok_ecos"]
        cb = CbSeries(s.iso3, "yield_10y", api.label, "bok_ecos", s.series_key, s.freq, "pct_pa")
        out = []
        y = start.year
        while y <= end.year:                         # one request per calendar year: ECOS returns at most 1000 rows
            a, b = max(start, dt.date(y, 1, 1)), min(end, dt.date(y, 12, 31))
            for p, v in api.parse(self._get(api.url(cb, a, b, {"ECOS_API_KEY": key})), cb):
                out.append({"iso3": s.iso3, "leg": s.leg, "api": s.api, "series_key": s.series_key, "date": p,
                            "value": float(v), "freq": s.freq, "tenor_y": s.tenor_y, "unit": "pct",
                            "realtime_start": "", "realtime_end": ""})
            y += 1
        return out

    def fetch(self, isos: Iterable[str], start: dt.date, end: dt.date, asof: str | None = None,
              registry: Iterable[SpreadSeries] | None = None) -> tuple[pd.DataFrame, pd.DataFrame, list[str]]:
        """(raw FRED rows, raw ECOS rows, failures). DGS10 first: a missing FRED key, an unreachable FRED or an empty
        DGS10 raise (FeedUnreachable / SpreadError) before anything else is requested."""
        from . import feeds as F
        from .market.public import PublicSourceError, fred_api_key
        from .official.central_banks import _redact
        reg = list(registry if registry is not None else _ENTRIES)
        s0, s1 = start.isoformat(), end.isoformat()
        try:
            fred_key = fred_api_key(self._env("FRED_API_KEY"))
        except PublicSourceError as e:
            raise SpreadError(f"{e}; DGS10 is required, nothing pulled") from None
        hosts = {"fred": "api.stlouisfed.org", "bok_ecos": "ecos.bok.or.kr"}
        failures: list[str] = []
        msg = None
        try:
            ust = self._fred(UST_ENTRY, s0, s1, fred_key, asof)
        except Exception as e:  # noqa: BLE001 - classified, text redacted before use
            why = F._stop_reason(e, hosts["fred"])
            if why:
                raise F.FeedUnreachable(_redact(why, [fred_key])) from None
            msg = _redact(F._one_line(f"{type(e).__name__}: {e}", 200), [fred_key])
        if msg is not None:                           # raised outside the except block: no __context__ with the key
            raise SpreadError(f"FRED {UST_SERIES}: {msg}; no benchmark, nothing written")
        if not ust:
            raise SpreadError(f"FRED {UST_SERIES}: no observation in {s0}..{s1}; nothing written")
        fred_rows, ecos_rows = list(ust), []
        dead: dict[str, str] = {}
        want = list(dict.fromkeys(isos))
        not_pulled = [f"{s.iso3} {s.leg} ({s.api})" for s in reg if s.iso3 in want and not s.machine]
        if not_pulled:
            failures.append("not requested (manual or none): " + ", ".join(not_pulled))
        for s in (s for s in reg if s.iso3 in want and s.machine):
            host = hosts[s.api]
            if host in dead:
                failures.append(f"{s.iso3} {s.leg} {s.series_key}: not requested ({dead[host]})")
                continue
            key = fred_key if s.api == "fred" else self._env("ECOS_API_KEY")
            if not key:
                failures.append(f"{s.iso3} {s.leg} {s.series_key}: ECOS_API_KEY not in the environment or keychain; "
                                "not requested")
                continue
            try:
                rows = self._fred(s, s0, s1, key, asof) if s.api == "fred" else self._ecos(s, start, end, key)
            except Exception as e:  # noqa: BLE001 - classified, text redacted before it is kept
                why = F._stop_reason(e, host)
                if why:
                    dead[host] = _redact(why, [key])
                    failures.append(f"{host}: unreachable ({dead[host]}); no further request to {host}")
                else:
                    failures.append(f"{s.iso3} {s.leg} {s.api} {s.series_key}: "
                                    + _redact(F._one_line(f"{type(e).__name__}: {e}", 200), [key, fred_key]))
                continue
            if not rows:
                failures.append(f"{s.iso3} {s.leg} {s.api} {s.series_key}: no observation in {s0}..{s1}")
            (fred_rows if s.api == "fred" else ecos_rows).extend(rows)
        return (pd.DataFrame(fred_rows, columns=RAW_COLUMNS), pd.DataFrame(ecos_rows, columns=RAW_COLUMNS), failures)


# ------------------------------------------------------------------------------------------------ build (pure)
def _series(raw: pd.DataFrame, iso3: str, leg: str, key: str) -> pd.Series:
    empty = pd.Series(dtype=float, index=pd.DatetimeIndex([]))
    if raw is None or not len(raw):
        return empty
    r = raw[(raw["iso3"].astype(str) == iso3) & (raw["leg"].astype(str) == leg) & (raw["series_key"].astype(str) == key)]
    if not len(r):
        return empty
    v = pd.to_numeric(r["value"], errors="coerce")
    s = pd.Series(v.to_numpy(dtype=float), index=pd.DatetimeIndex(pd.to_datetime(r["date"].astype(str), errors="coerce")))
    s = s[s.index.notna() & np.isfinite(s.to_numpy())]
    return s[~s.index.duplicated(keep="last")].sort_index()


def monthly_mean(daily: pd.Series, end: dt.date, min_days: int = MIN_DAYS_MONTH) -> tuple[pd.Series, pd.Series]:
    """(mean, count) per calendar month of a daily series, dated at the month end; months with fewer than `min_days`
    observations, and a month whose end is after `end` (incomplete), are dropped."""
    if not len(daily):
        return pd.Series(dtype=float), pd.Series(dtype=int)
    g = daily.groupby(daily.index.to_period("M"))
    m, n = g.mean(), g.count()
    idx = m.index.to_timestamp(how="end").normalize()
    m, n = pd.Series(m.to_numpy(), index=idx), pd.Series(n.to_numpy(), index=idx)
    keep = (n >= min_days) & (m.index <= pd.Timestamp(end))
    return m[keep], n[keep]


def _month_end(s: pd.Series, end: dt.date) -> pd.Series:
    """A native monthly series (FRED dates months by their first day) dated at the month end; months ending after
    `end` dropped."""
    if not len(s):
        return s
    out = pd.Series(s.to_numpy(), index=s.index.to_period("M").to_timestamp(how="end").normalize())
    out = out[~out.index.duplicated(keep="last")]
    return out[out.index <= pd.Timestamp(end)]


def _rows(iso, country, leg, freq, s: SpreadSeries, y: pd.Series, ust: pd.Series, n: pd.Series | None,
          verified: bool) -> list[dict]:
    common = y.index.intersection(ust.index)
    restricted = bool(is_restricted(s) or is_restricted(UST_ENTRY))      # once per series, not per row
    out = []
    for d in common:
        out.append({"date": d.date().isoformat(), "period": d.strftime("%Y-%m") if freq == "M" else d.date().isoformat(),
                    "iso": iso, "country": country, "leg": leg, "spread_type": SPREAD_TYPE[leg], "freq": freq,
                    "tenor_y": s.tenor_y, "yield_pct": float(y[d]), "ust_pct": float(ust[d]),
                    "spread_bp": round((float(y[d]) - float(ust[d])) * 100.0, 6),
                    "n_days": int(n[d]) if n is not None and d in n.index else "",
                    "yield_source": f"{s.source} ({s.api})", "yield_series": s.series_key, "ust_series": UST_SERIES,
                    "includes_fx_inflation_premium": leg == "local", "restricted": restricted,
                    "verified": "yes" if verified else "no"})
    return out


def build_spreads(raw_fred: pd.DataFrame | None, raw_ecos: pd.DataFrame | None, desk: pd.DataFrame, start: dt.date,
                  end: dt.date, verified: set | None = None, registry: Iterable[SpreadSeries] | None = None,
                  retrieved_utc: str = "", failures: list[str] | None = None
                  ) -> tuple[pd.DataFrame, pd.DataFrame, pd.DataFrame, dict]:
    """(daily, monthly, coverage, sidecar) from the raw tables. Pure: no I/O. Columns SPREAD_COLUMNS / COVERAGE_COLUMNS."""
    reg = list(registry if registry is not None else _ENTRIES)
    verified = verified or set()
    raw = pd.concat([r for r in (raw_fred, raw_ecos) if r is not None and len(r)], ignore_index=True) \
        if any(r is not None and len(r) for r in (raw_fred, raw_ecos)) else pd.DataFrame(columns=RAW_COLUMNS)
    lo, hi = pd.Timestamp(start), pd.Timestamp(end)
    ust_d = _series(raw, USD_ISO, "usd", UST_SERIES)
    ust_d = ust_d[(ust_d.index >= lo) & (ust_d.index <= hi)]
    if not len(ust_d):
        raise SpreadError(f"no {UST_SERIES} observation in {start}..{end}: no benchmark, no spread")
    ust_m, ust_n = monthly_mean(ust_d, end)
    ust_ok = (USD_ISO, "usd", UST_SERIES) in verified
    daily, monthly, cov, meta = [], [], [], {}
    for d in desk.itertuples(index=False):
        c = {"iso": d.iso, "country": d.country, "currency": d.currency, "local_freq": "", "n_daily": 0, "n_monthly": 0,
             "first": "", "last": "", "restricted": False, "verified": "no"}
        reasons, leg_ok = [], []
        for leg in LEGS:
            es = entries_for(d.iso, leg, reg)
            chosen, tried = None, []
            for s in (s for s in es if s.machine):
                y = _series(raw, d.iso, leg, s.series_key)
                y = y[(y.index >= lo) & (y.index <= hi)]
                if len(y):
                    chosen = (s, y)
                    break
                tried.append(f"{s.api} {s.series_key}: no data in this vintage")
            if chosen is None:
                manual = [s for s in es if not s.machine]
                why = "; ".join(tried + [s.note for s in manual][:1]) or "not in the spread registry"
                c.update({f"{leg}_status": "no data" if tried else (manual[0].api if manual else NONE),
                          f"{leg}_source": (manual[0].source if manual else ""), f"{leg}_series": ""})
                reasons.append(f"{leg}: {why}")
                continue
            s, y = chosen
            if tried:
                reasons.append(f"{leg}: served by {s.api} {s.series_key}; earlier source without data: {'; '.join(tried)}")
            ok = ust_ok and (d.iso, leg, s.series_key) in verified
            if s.freq == "D":
                rows_d = _rows(d.iso, d.country, leg, "D", s, y, ust_d, None, ok)
                ym, yn = monthly_mean(y, end)
                rows_m = _rows(d.iso, d.country, leg, "M", s, ym, ust_m, yn, ok)
            else:
                rows_d = []
                rows_m = _rows(d.iso, d.country, leg, "M", s, _month_end(y, end), ust_m, None, ok)
            daily += rows_d
            monthly += rows_m
            n_used = len(rows_m) + len(rows_d)
            c.update({f"{leg}_status": "served" if n_used else "no overlap with DGS10", f"{leg}_source": s.source,
                      f"{leg}_series": s.series_key})
            if leg == "local":
                c["local_freq"] = s.freq
            if not n_used:
                reasons.append(f"{leg}: {s.series_key} has no date or month in common with {UST_SERIES}")
            c["restricted"] = c["restricted"] or is_restricted(s)
            leg_ok.append(ok)
            meta[f"{d.iso}.{leg}"] = {"source": s.source, "api": s.api, "series_key": s.series_key, "freq": s.freq,
                                      "tenor_y": s.tenor_y, "licence": s.licence, "terms": s.terms_url,
                                      "restricted": is_restricted(s), "verified": ok, "note": s.note,
                                      "spread": SPREAD_NOTE[leg], "n_raw": int(len(y)),
                                      "n_daily": len(rows_d), "n_monthly": len(rows_m),
                                      "first": str(y.index.min().date()), "last": str(y.index.max().date())}
        served = [r for r in daily + monthly if r["iso"] == d.iso]
        c["n_daily"] = sum(1 for r in served if r["freq"] == "D")
        c["n_monthly"] = sum(1 for r in served if r["freq"] == "M")
        if served:
            c["first"], c["last"] = min(r["date"] for r in served), max(r["date"] for r in served)
        c["verified"] = "yes" if leg_ok and all(leg_ok) else ("partial" if any(leg_ok) else "no")
        c["usable_spread"] = ("yes" if c["n_monthly"] or c["n_daily"] else "no")
        c["reason"] = " | ".join(reasons)
        cov.append(c)
    daily_df = pd.DataFrame(daily, columns=SPREAD_COLUMNS).sort_values(["iso", "leg", "date"]).reset_index(drop=True)
    monthly_df = pd.DataFrame(monthly, columns=SPREAD_COLUMNS).sort_values(["iso", "leg", "date"]).reset_index(drop=True)
    cov_df = pd.DataFrame(cov, columns=COVERAGE_COLUMNS)
    side = {"schema": SCHEMA, "ticket": TICKET, "start": start.isoformat(), "end": end.isoformat(),
            "retrieved_utc": retrieved_utc, "units": "spread_bp = (yield_pct - ust_pct) x 100; yields in % p.a.",
            "benchmark": {"series": UST_SERIES, "source": UST_ENTRY.source, "licence": UST_ENTRY.licence,
                          "terms": UST_ENTRY.terms_url, "verified": ust_ok, "n_daily": int(len(ust_d)),
                          "n_monthly": int(len(ust_m)), "monthly_rule": UST_MONTHLY_RULE},
            "fill": "none: a date or month either side did not publish has no row",
            "monthly_rule": (f"calendar-month mean of a daily series with at least {MIN_DAYS_MONTH} observations, "
                             "dated at the month end; native monthly series re-dated from the month start to the month "
                             "end; months ending after `end` dropped"),
            "spread_types": SPREAD_NOTE, "euro_area": EURO_AREA_NOTE, "series": meta,
            "engine": "not an engine input: no apply step; Team B decides use (handoff under EQ-A-0063)",
            "usable": sorted(cov_df.loc[cov_df["usable_spread"] == "yes", "iso"].tolist()),
            "unusable": sorted(cov_df.loc[cov_df["usable_spread"] != "yes", "iso"].tolist()),
            "restricted_rows": int(sum(bool(r["restricted"]) for r in daily + monthly)),
            "failures": list(failures or [])}
    return daily_df, monthly_df, cov_df, side


# ------------------------------------------------------------------------------------------------ vintages and builds
def _sha(b: bytes) -> str:
    import hashlib
    return hashlib.sha256(b).hexdigest()


def _write_ro(path: Path, body: bytes) -> None:
    path.write_bytes(body)
    os.chmod(path, 0o444)


def check_vintage_id(vintage_id) -> str:
    from .market_history import VINTAGE_ID_RE
    if not isinstance(vintage_id, str) or not VINTAGE_ID_RE.fullmatch(vintage_id):
        raise SpreadError(f"not a spread vintage id: {str(vintage_id)[:80]!r} (expected YYYY-MM-DDTHHMMSSZ-hash8)")
    return vintage_id


def list_vintages(data_dir) -> list[str]:
    root = _sp(data_dir) / "vintages"
    return sorted(p.name for p in root.iterdir() if p.is_dir() and p.name[:4].isdigit()) if root.exists() else []


def save_vintage(data_dir, files: dict[str, bytes], now: dt.datetime | None = None) -> Path:
    """Append-only: spreads/vintages/<ts>-<hash8>/ created with exist_ok=False, files 0444, row in index.csv."""
    from .feeds import _content_hash, _utc
    from .ledger import locked_append
    now = _utc(now)
    digest = _content_hash(files)
    root = _sp(data_dir) / "vintages"
    root.mkdir(parents=True, exist_ok=True)
    v = root / f"{now.strftime('%Y-%m-%dT%H%M%SZ')}-{digest[:8]}"
    v.mkdir(exist_ok=False)
    for name in sorted(files):
        _write_ro(v / name, files[name])
    with locked_append(root / "index.csv", VINTAGE_INDEX_COLUMNS) as (w, _f, new):
        if new:
            w.writeheader()
        w.writerow({"vintage_id": v.name, "retrieved_utc": now.strftime("%Y-%m-%dT%H:%M:%SZ"), "hash": digest,
                    "n_files": len(files)})
    return v


def verify_vintage(data_dir, vintage_id: str) -> dict:
    """Recompute the vintage's content hash against its first index.csv row and the hash8 in its name."""
    import csv
    from .feeds import _content_hash
    check_vintage_id(vintage_id)
    v = _sp(data_dir) / "vintages" / vintage_id
    if not v.is_dir():
        raise SpreadError(f"no spread vintage {vintage_id!r}")
    files = {q.name: q.read_bytes() for q in v.iterdir() if q.is_file()}
    digest = _content_hash(files)
    idx = v.parent / "index.csv"
    rows = []
    if idx.exists():
        with open(idx, newline="") as f:
            rows = [r for r in csv.DictReader(f) if r.get("vintage_id") == vintage_id]
    if not rows:
        raise SpreadError(f"spread vintage {vintage_id} has no row in {idx}")
    problems = []
    if rows[0].get("hash") != digest:
        problems.append(f"hash {digest[:16]} != index {str(rows[0].get('hash'))[:16]}")
    if str(rows[0].get("n_files")) != str(len(files)):
        problems.append(f"{len(files)} files != index {rows[0].get('n_files')}")
    if not vintage_id.endswith(digest[:8]):
        problems.append(f"folder hash8 != content hash {digest[:8]}")
    if problems:
        raise SpreadError(f"spread vintage {vintage_id} failed verification: " + "; ".join(problems))
    return {"vintage_id": vintage_id, "hash": digest, "n_files": len(files), "retrieved_utc": rows[0].get("retrieved_utc")}


def _read_raw(path: Path) -> pd.DataFrame | None:
    if not path.is_file():
        return None
    return pd.read_csv(path, dtype={"iso3": str, "leg": str, "series_key": str, "date": str}, keep_default_na=False,
                       na_values=[""])


def build_from_vintage(data_dir, vintage_id: str) -> dict:
    """Build the spreads from a verified vintage into spreads/builds/<vintage_id>/ (files 0444). Idempotent: an
    existing build must be byte-identical (series_verified.csv is read at build time and recorded in the sidecar)."""
    info = verify_vintage(data_dir, vintage_id)
    v = _sp(data_dir) / "vintages" / vintage_id
    req = json.loads((v / REQUEST_NAME).read_text())
    start, end = dt.date.fromisoformat(req["start"]), dt.date.fromisoformat(req["end"])
    desk = pd.DataFrame(req["desk"], columns=["iso", "country", "currency", "iso2"])
    daily, monthly, cov, side = build_spreads(_read_raw(v / RAW_FRED_NAME), _read_raw(v / RAW_ECOS_NAME), desk, start,
                                              end, load_verified(data_dir), retrieved_utc=req.get("retrieved_utc", ""),
                                              failures=req.get("failures"))
    bodies = {DAILY_NAME: daily.to_csv(index=False).encode(), MONTHLY_NAME: monthly.to_csv(index=False).encode(),
              COVERAGE_NAME: cov.to_csv(index=False).encode()}
    side.update(vintage_id=vintage_id, vintage_hash=info["hash"], asof=req.get("asof"),
                raw_files={n: _sha((v / n).read_bytes()) for n in (RAW_FRED_NAME, RAW_ECOS_NAME) if (v / n).is_file()},
                files={n: _sha(b) for n, b in bodies.items()})
    bodies[SIDECAR_NAME] = json.dumps(side, indent=1, sort_keys=True, default=str).encode()
    out = _sp(data_dir) / "builds" / vintage_id
    if out.exists():
        diff = [n for n, b in bodies.items() if not (out / n).is_file() or (out / n).read_bytes() != b]
        if diff:
            raise SpreadError(f"build {out} exists and differs in {diff}; builds are not overwritten (a changed "
                              "series_verified.csv needs a new pull)")
    else:
        out.parent.mkdir(parents=True, exist_ok=True)
        tmp = Path(tempfile.mkdtemp(dir=out.parent, prefix=".build-"))
        for n, b in bodies.items():
            _write_ro(tmp / n, b)
        os.replace(tmp, out)
    return {"build": str(out), "vintage": vintage_id, "daily_rows": int(len(daily)), "monthly_rows": int(len(monthly)),
            "usable": side["usable"], "unusable": side["unusable"], "restricted_rows": side["restricted_rows"],
            "failures": side["failures"]}


def _default_range(start, end, now: dt.datetime) -> tuple[dt.date, dt.date]:
    end = pd.Timestamp(end).date() if end is not None else now.date()
    if start is not None:
        start = pd.Timestamp(start).date()
    else:
        start = dt.date(end.year - HISTORY_YEARS, 1, 1)
    if start >= end:
        raise SpreadError(f"start {start} must be before end {end}")
    return start, end


def build_spread_history(data_dir, start=None, end=None, *, asof: str | None = None, fetcher: SpreadFetcher | None = None,
                         now: dt.datetime | None = None, log: Callable[[str], None] = print) -> dict:
    """Pull (SpreadFetcher), save the raw vintage, build from it. No apply. Defaults: end today UTC (recorded in
    request.json), start 1 January HISTORY_YEARS years earlier. `asof` (ALFRED): FRED values as known on that date."""
    from .feeds import _utc
    now = _utc(now)
    start, end = _default_range(start, end, now)
    if asof is not None:
        asof = dt.date.fromisoformat(str(asof)).isoformat()
        end = min(end, dt.date.fromisoformat(asof))
    desk = desk_countries(data_dir)
    fetcher = fetcher or SpreadFetcher()
    log(f"spread history {start} .. {end}: {UST_SERIES} + {sum(s.machine for s in _ENTRIES)} candidate series for "
        f"{len(desk)} desk countries" + (f", ALFRED as of {asof}" if asof else ""))
    raw_fred, raw_ecos, failures = fetcher.fetch(desk["iso"].tolist(), start, end, asof)   # raises: nothing written
    files = {RAW_FRED_NAME: raw_fred.to_csv(index=False).encode()}
    if len(raw_ecos):
        files[RAW_ECOS_NAME] = raw_ecos.to_csv(index=False).encode()
    files[REQUEST_NAME] = json.dumps({
        "ticket": TICKET, "start": start.isoformat(), "end": end.isoformat(), "asof": asof,
        "retrieved_utc": now.strftime("%Y-%m-%dT%H:%M:%SZ"), "desk": desk.values.tolist(),
        "registry": [asdict(s) for s in registry_entries() if s.machine], "failures": failures},
        indent=1, sort_keys=True).encode()
    v = save_vintage(data_dir, files, now=now)
    log(f"  raw pulls saved: {v}")
    res = build_from_vintage(data_dir, v.name)
    log(f"  built {res['build']}: {res['monthly_rows']} monthly and {res['daily_rows']} daily rows; usable: "
        f"{', '.join(res['usable']) or 'none'}")
    for f in failures:
        log(f"  failure: {f}")
    log("  staged only: not an engine input (no apply step; Team B decides use)")
    return res


def status(data_dir) -> dict:
    """Vintages with their hash check, and the latest build's coverage summary. latest_build names the vintage it was
    built from and that vintage's hash check (vintage_check 'ok' or 'FAILED: ...'), so a build over a tampered or
    incomplete vintage is visible (AGENT-05 review, EQ-A-0078)."""
    out = {"vintages": [], "latest_build": None}
    for vid in list_vintages(data_dir):
        try:
            verify_vintage(data_dir, vid)
            ok = "ok"
        except SpreadError as e:
            ok = f"FAILED: {e}"
        b = _sp(data_dir) / "builds" / vid
        out["vintages"].append({"vintage_id": vid, "check": ok, "built": b.is_dir()})
    built = [v for v in out["vintages"] if v["built"]]
    if built:
        b = _sp(data_dir) / "builds" / built[-1]["vintage_id"]
        side = json.loads((b / SIDECAR_NAME).read_text())
        out["latest_build"] = {"build": str(b), "vintage_id": built[-1]["vintage_id"], "vintage_check": built[-1]["check"],
                               "start": side["start"], "end": side["end"], "usable": side["usable"],
                               "unusable": side["unusable"], "restricted_rows": side["restricted_rows"],
                               "benchmark_verified": side["benchmark"]["verified"], "failures": len(side["failures"])}
    return out


def write_plan(data_dir) -> list[Path]:
    """registry.csv and coverage.csv (regenerated) and series_verified.csv (only when absent: verification marks are
    never overwritten) under data/market_history/spreads/."""
    d = _sp(data_dir)
    d.mkdir(parents=True, exist_ok=True)
    out = []
    for name, df in ((REGISTRY_NAME, registry_frame()), (COVERAGE_NAME, plan_coverage(desk_countries(data_dir)))):
        (d / name).write_text(df.to_csv(index=False))
        out.append(d / name)
    if not (d / VERIFIED_NAME).exists():
        (d / VERIFIED_NAME).write_text(verified_template().to_csv(index=False))
        out.append(d / VERIFIED_NAME)
    return out


# ------------------------------------------------------------------------------------------------ command line
def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.spreads",
                                 description="Free official sovereign spread history (EQ-A-0063)")
    ap.add_argument("--data", default="data")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("plan", help="registry and planned coverage per desk country (no network)")
    p.add_argument("--write", action="store_true", help="write registry.csv, coverage.csv (and series_verified.csv "
                                                        "if absent) under data/market_history/spreads/")
    b = sub.add_parser("build", help="pull DGS10 and the candidate yields, save the raw vintage, build the spreads")
    b.add_argument("--start"); b.add_argument("--end")
    b.add_argument("--asof", help="ALFRED: FRED values as known on this date (end is capped at it)")
    b.add_argument("--vintage", help="rebuild from an existing vintage instead of pulling")
    sub.add_parser("status", help="vintages (hash-checked) and the latest build's coverage")
    a = ap.parse_args(argv)
    if a.cmd == "plan":
        cov = plan_coverage(desk_countries(a.data))
        print(f"{len(cov)} desk countries; candidate local spread (UNVERIFIED): "
              f"{', '.join(cov.loc[cov['usable_spread'] != 'no', 'iso']) or 'none'}; hard-currency candidates: "
              f"{', '.join(cov.loc[cov['hard_status'].str.startswith('candidate'), 'iso']) or 'none'}")
        for r in cov.itertuples(index=False):
            print(f"  {r.iso}  local {r.local_status:<24} {r.local_series or r.local_source:<28} hard {r.hard_status}")
        print(f"  benchmark: FRED {UST_SERIES} (daily). {EURO_AREA_NOTE}")
        if a.write:
            for f in write_plan(a.data):
                print(f"wrote {f}")
        return 0
    if a.cmd == "build":
        from .feeds import FeedError
        try:
            if a.vintage:
                res = build_from_vintage(a.data, check_vintage_id(a.vintage))
            else:
                res = build_spread_history(a.data, a.start, a.end, asof=a.asof)
        except (SpreadError, FeedError) as e:
            print(f"error: {e}", file=sys.stderr)
            return 2
        print(json.dumps(res, indent=1, default=str))
        return 0
    st = status(a.data)
    print(json.dumps(st, indent=1, default=str))
    return 1 if any(v["check"] != "ok" for v in st["vintages"]) else 0


if __name__ == "__main__":
    sys.exit(main())
