"""Resumable, staged, point-in-time predictor history for the hazard panel (EQ-A-0010, EQ-A-0015).

Run on Sam's Mac (the cloud sessions cannot reach the IMF or the World Bank):

    python -m econquest.ingestion.panel_history --out data/panel            # new run
    python -m econquest.ingestion.panel_history --out data/panel --resume <run_id>
    python -m econquest.ingestion.panel_history --list-vintages              # what would be pulled, no network
    python -m econquest.ingestion.panel_history --manual-list                # missing releases: file name, folder, page
    python -m econquest.ingestion.panel_history --probe-weo-api              # IMF API WEO dataflows -> outputs/weo_api_probe
    python -m econquest.ingestion.panel_history --probe-wb PV.EST            # WB request shapes for one WGI series -> outputs/wb_probe
    python -m econquest.ingestion.panel_history --probe-wb panel             # EQ-A-0094: PV.EST, RL.EST and the WB-only panel set
    python -m econquest.ingestion.panel_history --out data/panel --wb-set interim   # WB-only panel 2000-2025 -> data/panel/wb_interim

What it does
* Work is split into units: one per WEO release (``weo/<YYYY-MM>``, e.g. ``weo/2019-04``) and one per World Bank
  series (``worldbank/<code>``). Each unit is fetched with retries and exponential backoff and written through a
  temp file + ``os.replace`` to ``<out>/staging/<run_id>/<source>/<unit>.csv``. ``manifest.json`` next to them
  records status, rows, sha256, attempts, error and the source string per unit, and is rewritten atomically after
  every unit, so an interrupted run loses at most the unit in flight.
* Resume (``run_id=`` / ``--resume``) skips every unit whose status is ``ok`` and whose staged file still has the
  recorded sha256; everything else is fetched again.
* Fail loudly: if any unit is still missing at the end, ``IncompleteFetchError`` is raised (``main`` exits 1) and
  the final files are not touched. Only when every unit is ``ok`` are ``<out>/weo_history.csv`` (columns
  ``iso, series, period, value, source, vintage``) and ``<out>/worldbank_history.csv`` (``iso, series, period,
  value, source``) written, through temp files and ``os.replace``. That is the long format
  ``validation.hazard_panel.panel_from_long`` reads; the WEO ``vintage`` column (``YYYY-MM`` of the release) makes
  the WEO features point in time. The World Bank file has no vintage column on purpose: wbgapi serves only the
  current database, and a made-up vintage would claim a point-in-time property the data does not have.
* The universe is every economy the sources return (``isos=None``); nothing is filtered to the desk countries, so
  never-defaulted countries enter the panel as zeros. Aggregates are left in; ``panel_from_long`` drops them.
* After success the final files and the manifest are copied to an append-only panel vintage,
  ``<out>/vintages/<YYYY-MM-DD>T<HHMMSS>Z-<hash8>/`` (files 0444, folder 0555), indexed in ``<out>/vintages/index.csv``
  (``save_panel_vintage``, also used by ``default_panel.import_crag``).

WEO releases and how each is reached (documentation reading on 2026-10-23; nothing was downloaded from the cloud;
route order and diagnostics changed after Sam's Mac pull of 2026-10-24, EQ-A-0068 / RCA-A-002)
Every route is tried in this order for every release; a route that is refused (HTTP 403, a body that is not a WEO
file, no dataflow for the release) falls through to the next one, and the unit fails only when all of them did.
1. ``local file``: ``<cache_dir>/weo_<YYYY-MM>.(xls|csv|tsv|txt)``, a tab-delimited "all countries" file saved by hand
   (``--manual-list`` prints the exact name and folder for every missing release) or cached by route 4.
2. ``imf-api``: the release's dataflow in the IMF SDMX 3.0 API (official/imf_weo.py: ``WEO_<YYYY>_<MON>_VINTAGE``
   under ``IMF.RES``, or the bare ``WEO`` flow when its PUBLICATION_DATE is the release). api.imf.org answered on the
   Mac on 2026-10-24; which releases exist as dataflows is UNVERIFIED (imf-reader documents October 2025 onwards):
   ``--probe-weo-api`` lists them. A release without a dataflow is refused cleanly.
3. ``imf-reader`` 2.2.0 (``imf_reader.weo.fetch_data(("April", 2019))``): bulk SDMX archive for April 2019 to April
   2025 on www.imf.org media URLs (HTTP 403 on 2026-10-24 for 2019-04 .. 2024-10); April 2021 and October 2023 are
   corrupt in the IMF's own archive (imf-reader's ``KNOWN_CORRUPT_RELEASES``); October 2025 onwards imf-reader reads
   the API itself.
4. ``weo`` package 0.8.4 (``weo.download(year, release)``): the tab-delimited "all countries" file of every release
   from October 2007 (September 2011 is the 2011 autumn release) via www.imf.org media URLs (on 2026-10-24 the body
   was not a WEO file for every release). econquest makes the request itself (``fetch=``: https, redirects refused,
   status and content-type kept), so a refused download says what the IMF served.
A download that is not a WEO file is never cached as one: the body is kept at ``<cache_dir>/rejected/`` and its
status, content-type, size, sha256 and first 512 bytes (sanitised) go into the unit's error and into
``<cache_dir>/weo_route_diagnostics.jsonl``. A unit whose every route failed for a reason a retry cannot change
(403/404, not a WEO file, no dataflow) is not retried within the run.
Earlier releases (1999-2007): the IMF website has WEO database archive pages, but no package wraps them and the
URLs were not verified: drop the file in by hand (route 1).
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import re
import shutil
import stat
import sys
import tempfile
import time
import urllib.error
import urllib.request
from pathlib import Path
from typing import Callable, Iterable

import pandas as pd

from ..common_format import escape_formula
# Series codes are hazard_panel's (Team B owns that module; imported read-only so the two cannot drift apart).
from ..rules.hazard import WB_CODES, WEO_CODES   # C15 (ADR-A-001): no longer loads validation / engine at import

RUN_ID_RE = re.compile(r"\d{8}T\d{6}Z(-\d+)?")
# manifest unit keys (SEC review S1); '_' since EQ-A-0094 for the 2024+ WGI codes (GOV_WGI_RL.SC)
UNIT_RE = re.compile(r"weo/\d{4}-\d{2}|worldbank/[A-Z0-9._]+")
WB_CODE_RE = re.compile(r"[A-Z][A-Z0-9_]{0,15}(\.[A-Z0-9_]{1,12}){1,6}")      # a World Bank series code (EQ-A-0094)
PANEL_VINTAGE_RE = re.compile(r"\d{4}-\d{2}-\d{2}T\d{6}Z-[0-9a-f]{8}")
MAX_WEO_BYTES = 200 * 2**20

LONG_COLUMNS = ["iso", "series", "period", "value", "source"]
WEO_COLUMNS = LONG_COLUMNS + ["vintage"]
SOURCES = ("weo", "worldbank")
FIRST_WEO_PACKAGE = "2007-10"     # weo package: first release it knows
LAST_WEO_BULK = "2025-04"         # IMF stopped publishing bulk files after April 2025
FIRST_IMF_READER = "2019-04"      # imf-reader bulk SDMX archive starts here
IMF_READER_CORRUPT = {"2021-04", "2023-10"}
WEO_DIAG_FILE = "weo_route_diagnostics.jsonl"    # in the cache folder: one JSON line per refused download (EQ-A-0068)
WEO_REJECTED_DIR = "rejected"                   # bodies that were not WEO files, kept for inspection
WEO_DIAG_HEAD = 512                             # bytes of a refused body quoted (sanitised) in the error and the file
WEO_DIAG_MAX_BYTES = 5 * 2**20                  # diagnostics file rotated to <name>.1 above this (SEC-A-009 I4)
WEO_HTTP_HOSTS = ("www.imf.org", "imf.org")     # the only hosts _http_fetch requests (SEC-A-009 I3)
ROUTE_ERROR_CHARS = 1100                        # per route in a unit's error (it carries the 512-byte head)
UNIT_ERROR_CHARS = 2400                         # a unit's error in the manifest (three routes)
PANEL_VINTAGE_INDEX = ["vintage_id", "created_utc", "hash", "n_files", "label", "files"]
_MONTHS = {"jan": 1, "feb": 2, "mar": 3, "apr": 4, "may": 5, "jun": 6, "jul": 7, "aug": 8, "sep": 9, "oct": 10, "nov": 11, "dec": 12}


class IncompleteFetchError(RuntimeError):
    """Raised when units are still missing after the retries. `.manifest` holds the manifest; `.missing` the units."""

    def __init__(self, msg: str, manifest: dict, missing: list[str]):
        super().__init__(msg)
        self.manifest, self.missing = manifest, missing


class FetchUnitError(RuntimeError):
    """A single unit could not be fetched (no route, empty result, bad columns). `permanent` True: a retry in the
    same run cannot change the answer (HTTP 403/404, not a WEO file, no dataflow), so fetch_history does not retry."""

    def __init__(self, msg: str = "", permanent: bool = False):
        super().__init__(msg)
        self.permanent = permanent


# ------------------------------------------------------------------------------------------ small utilities

def _utc(now: dt.datetime | None = None) -> dt.datetime:
    now = now or dt.datetime.now(dt.timezone.utc)
    return now.replace(tzinfo=dt.timezone.utc) if now.tzinfo is None else now.astimezone(dt.timezone.utc)


def _stamp(now: dt.datetime) -> str:
    return now.strftime("%Y-%m-%dT%H:%M:%SZ")


def sha256_file(path: str | Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()


def _atomic_write_bytes(path: Path, data: bytes, mode: int = 0o644) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        os.chmod(tmp, mode)
        os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def _csv_bytes(df: pd.DataFrame) -> bytes:
    return df.to_csv(index=False, lineterminator="\n").encode()


def normalise_vintage(v) -> str:
    """'2019-04', '2019-4', 'Apr 2019', '2019-Apr', ('April', 2019), 'October 2011' -> 'YYYY-MM'.
    The autumn 2011 release is September ('2011-09'); 'Oct 2011' is mapped to it."""
    if isinstance(v, (tuple, list)) and len(v) == 2:
        v = f"{v[0]} {v[1]}"
    s = str(v).strip()
    m = re.fullmatch(r"(\d{4})-(\d{1,2})", s)
    if m:
        year, month = int(m.group(1)), int(m.group(2))
    else:
        y = re.search(r"(\d{4})", s)
        mo = re.search(r"([A-Za-z]{3})", s)
        if not y or not mo or mo.group(1).lower() not in _MONTHS:
            raise ValueError(f"cannot read WEO release {v!r}: use YYYY-MM, e.g. 2019-04")
        year, month = int(y.group(1)), _MONTHS[mo.group(1).lower()]
    if year == 2011 and month == 10:
        month = 9
    if not 1 <= month <= 12 or not 1990 <= year <= 2100:
        raise ValueError(f"bad WEO release {v!r}")
    return f"{year:04d}-{month:02d}"


def default_weo_vintages(today: dt.date | None = None, first: str = FIRST_WEO_PACKAGE) -> list[str]:
    """April and October releases from `first` (default October 2007, the first the weo package serves) to the
    latest one assumed published by `today` (April from the 20th of April, October from the 20th of October)."""
    today = today or dt.date.today()
    out = []
    for year in range(int(first[:4]), today.year + 1):
        for month in (4, 10):
            v = normalise_vintage(f"{year}-{month:02d}")
            if v < first or dt.date(year, month, 20) > today:
                continue
            out.append(v)
    return out


def _parse_vintage_arg(text: str) -> list[str]:
    """'2007-10:2026-10' (range of April/October releases) or a comma list."""
    out: list[str] = []
    for part in [p.strip() for p in text.split(",") if p.strip()]:
        if ":" in part:
            a, b = (normalise_vintage(x) for x in part.split(":", 1))
            for year in range(int(a[:4]), int(b[:4]) + 1):
                for month in (4, 10):
                    v = normalise_vintage(f"{year}-{month:02d}")
                    if a <= v <= b:
                        out.append(v)
        else:
            out.append(normalise_vintage(part))
    return sorted(set(out))


# ------------------------------------------------------------------------------------------ WEO fetcher adapter

def _num(x):
    if isinstance(x, str):
        x = x.replace(",", "").strip()
        if x in ("", "n/a", "--", "NA", "N/A", "..."):
            return float("nan")
    try:
        return float(x)
    except (TypeError, ValueError):
        return float("nan")


def parse_weo_tab(path: str | Path, codes: Iterable[str] | None, isos: Iterable[str] | None = None) -> pd.DataFrame:
    """Read one WEO 'all countries' file (tab-delimited despite the .xls name; UTF-16 from October 2020, Latin-1
    before) into long rows iso, series, period, value. Columns are found by name ('ISO', 'WEO Subject Code', year
    columns); a file without them raises FetchUnitError. codes=None keeps every subject code (weo_vintages, EQ-A-0064)."""
    if Path(path).stat().st_size > MAX_WEO_BYTES:                    # refuse oversized downloads before parsing (S2)
        raise FetchUnitError(f"{path}: larger than {MAX_WEO_BYTES // 2**20} MB, not a WEO release file")
    raw = Path(path).read_bytes()
    encodings = ("utf-16",) if raw[:2] in (b"\xff\xfe", b"\xfe\xff") else ("utf-8-sig", "utf-16-le", "iso-8859-1")
    df, last = None, None
    import io
    for enc in encodings:
        try:
            t = pd.read_csv(io.BytesIO(raw), sep="\t", encoding=enc, dtype=str, on_bad_lines="skip")
        except (UnicodeError, ValueError, pd.errors.ParserError) as e:
            last = e
            continue
        cols = {str(c).strip().lower(): c for c in t.columns}
        if "iso" in cols and "weo subject code" in cols:
            df = t.rename(columns={cols["iso"]: "ISO", cols["weo subject code"]: "CODE"})
            break
    if df is None:
        raise FetchUnitError(f"{Path(path).name}: not a WEO tab-delimited file (no ISO / WEO Subject Code columns; {last})")
    years = [c for c in df.columns if re.fullmatch(r"\d{4}", str(c).strip())]
    if not years:
        raise FetchUnitError(f"{Path(path).name}: no year columns")
    sub = df[df["CODE"].notna()] if codes is None else df[df["CODE"].astype(str).str.strip().isin(set(codes))]
    if isos is not None:
        sub = sub[sub["ISO"].astype(str).str.strip().isin(set(isos))]
    long = sub.melt(id_vars=["ISO", "CODE"], value_vars=years, var_name="period", value_name="value")
    long["value"] = long["value"].map(_num)
    long = long.dropna(subset=["value"])
    return pd.DataFrame({"iso": long["ISO"].astype(str).str.strip(), "series": long["CODE"].astype(str).str.strip(),
                         "period": long["period"].astype(str).str.strip().astype(int), "value": long["value"].astype(float)})


_MONTH_NAMES = {4: "April", 9: "September", 10: "October"}


def _release_name(vintage: str) -> str:
    """'2019-04' -> 'April 2019'."""
    m = int(vintage[5:])
    return f"{_MONTH_NAMES.get(m, dt.date(2000, m, 1).strftime('%B'))} {vintage[:4]}"


def _is_permanent(e: BaseException) -> bool:
    """A failure that a retry in the same run cannot change: a FetchUnitError/WeoApiError marked permanent, or an
    HTTP 3xx/401/403/404/410 (urllib HTTPError, or imf-reader's ConnectionError text '403 Client Error')."""
    if getattr(e, "permanent", False) or type(e).__name__ in ("VersionNotAvailableError", "WeoApiAbsent"):
        return True
    if isinstance(e, urllib.error.HTTPError):
        return e.code in (301, 302, 303, 307, 308, 401, 403, 404, 410)
    return isinstance(e, ConnectionError) and bool(re.search(r"\b(401|403|404|410) Client Error", str(e)))


class WeoVintageFetcher:
    """Fetch one WEO release (``vintage`` 'YYYY-MM') for the given codes. Routes, in this order (EQ-A-0068); a route
    that fails falls through to the next, and the unit fails only when every route did:

    1. ``local file``: ``<cache_dir>/weo_<vintage>.(xls|csv|tsv|txt)`` (manual downloads, and the cache of route 4);
    2. ``imf-api``: the release's dataflow in the IMF SDMX 3.0 API (official.imf_weo.WeoApi), every release; refused
       cleanly when the API has no dataflow for it;
    3. ``imf-reader``: ``imf_reader.weo.fetch_data((month, year))`` for 2019-04 onwards, except the two releases that are
       corrupt in the IMF's bulk archive (2021-04, 2023-10);
    4. ``weo-package``: ``weo.download(year, release)`` for 2007-10 .. 2025-04, the request made by econquest
       (``_http_fetch``) so status and content-type are kept.
    A download that is not a WEO file is moved to ``<cache_dir>/rejected/`` and described (status, content-type,
    sha256, first 512 bytes sanitised) in the error and in ``<cache_dir>/weo_route_diagnostics.jsonl``.

    `imf_reader_fetch`, `weo_download`, `imf_api` (an object with ``fetch(vintage, codes, isos)``; False turns the
    route off) and `http_open` (urllib-style opener used by `_http_fetch`) are injectable for tests."""

    ROUTE_ORDER = ("local file", "imf-api", "imf-reader", "weo-package")

    def __init__(self, cache_dir: str | Path, imf_reader_fetch: Callable | None = None, weo_download: Callable | None = None,
                 imf_api=None, http_open: Callable | None = None):
        self.cache_dir = Path(cache_dir)
        self._imf = imf_reader_fetch
        self._dl = weo_download
        self._api = imf_api
        self._open = http_open
        self._meta: dict = {}

    def local_file(self, vintage: str) -> Path | None:
        for ext in (".xls", ".csv", ".tsv", ".txt"):
            p = self.cache_dir / f"weo_{vintage}{ext}"
            if p.is_file() and p.stat().st_size > 0:
                return p
        return None

    @staticmethod
    def routes(vintage: str) -> list[str]:
        """Network routes that apply to `vintage`, in the order they are tried (the local file comes first)."""
        r = ["imf-api"]
        if vintage >= FIRST_IMF_READER and vintage not in IMF_READER_CORRUPT:
            r.append("imf-reader")
        if FIRST_WEO_PACKAGE <= vintage <= LAST_WEO_BULK:
            r.append("weo-package")
        return r

    # ------------------------------------------------------------------ diagnostics
    def diagnostics_file(self) -> Path:
        return self.cache_dir / WEO_DIAG_FILE

    def _diagnose(self, vintage: str, route: str, part: Path | None, err: BaseException) -> str:
        """Keep the refused body (moved to <cache>/rejected/), append a JSON line to the diagnostics file and return
        the text that goes into the unit's error: status, content-type, size, sha256, sniffed kind, first 512 bytes."""
        from .official.imf_weo import sanitise_head, sniff
        meta = dict(self._meta)
        for k in ("content_type", "location"):            # server-sent header values: sanitised (SEC-A-009 L5)
            meta[k] = sanitise_head(str(meta.get(k) or "").encode("latin-1", "replace"), 300)
        rec = {"utc": _stamp(_utc()), "vintage": vintage, "route": route, "url": meta.get("url", ""),
               "status": meta.get("status"), "content_type": meta.get("content_type", ""),
               "location": meta.get("location", ""), "error": f"{type(err).__name__}: {' '.join(str(err).split())[:400]}"}
        kept = ""
        if part is not None and part.is_file():
            body = part.read_bytes()[:WEO_DIAG_HEAD]
            rec.update(bytes=part.stat().st_size, sha256=sha256_file(part), kind=sniff(body),
                       head=sanitise_head(body, WEO_DIAG_HEAD))
            rej = self.cache_dir / WEO_REJECTED_DIR
            rej.mkdir(parents=True, exist_ok=True)
            dest = rej / f"weo_{vintage}.{route}.body"
            os.replace(part, dest)
            kept = str(dest)
            rec["kept_at"] = kept
        else:
            rec.update(bytes=0, kind="no body")
        try:
            df = self.diagnostics_file()
            if df.is_file() and df.stat().st_size > WEO_DIAG_MAX_BYTES:     # one rotation kept (SEC-A-009 I4)
                os.replace(df, df.with_name(df.name + ".1"))
            with open(df, "a", encoding="utf-8") as f:
                f.write(json.dumps(rec, sort_keys=True) + "\n")
        except OSError:
            pass
        ct = rec["content_type"] or ("no content-type" if rec["status"] is not None
                                     else "content-type unknown: download not made by econquest")
        parts = [f"served HTTP {rec['status'] if rec['status'] is not None else '?'}", ct,
                 f"{rec.get('bytes', 0)} bytes ({rec.get('kind')})"]
        if rec["location"]:
            parts.append(f"redirect to {rec['location'][:160]} (not followed)")
        if rec.get("sha256"):
            parts.append(f"sha256 {rec['sha256'][:16]}")
        if kept:
            parts.append(f"kept at {kept}")
        text = "; ".join(parts) + f"; first {WEO_DIAG_HEAD} bytes: {rec.get('head', '')!r}"
        return text + f"; see {self.diagnostics_file()}"

    def _http_fetch(self, path: str, url: str) -> str:
        """The download the weo package asks for, made here: https only, redirects refused, body capped, status and
        content-type recorded in self._meta. An HTTP error writes its body (first 512 bytes) to `path` and raises."""
        from .sources import open_url_no_redirect
        opener = self._open or open_url_no_redirect
        self._meta = {"url": url, "status": None, "content_type": "", "location": ""}
        if not str(url).startswith("https://"):
            raise FetchUnitError(f"refusing non-https URL {url!r}", permanent=True)
        from urllib.parse import urlsplit
        if (urlsplit(str(url)).hostname or "").lower() not in WEO_HTTP_HOSTS:     # SEC-A-009 I3
            raise FetchUnitError(f"refusing URL outside {WEO_HTTP_HOSTS}: {url!r}", permanent=True)
        req = urllib.request.Request(url, headers={"User-Agent": "econquest/0.4"})
        try:
            with opener(req, 120) as r:
                self._meta.update(status=getattr(r, "status", None) or getattr(r, "code", None) or 200,
                                  content_type=(r.headers.get("Content-Type", "") if getattr(r, "headers", None) else ""))
                body = r.read(MAX_WEO_BYTES + 1)
        except urllib.error.HTTPError as e:
            hdrs = e.headers or {}
            self._meta.update(status=e.code, content_type=hdrs.get("Content-Type", "") or "",
                              location=hdrs.get("Location", "") or "")
            try:
                head = e.read(WEO_DIAG_HEAD) or b""
            except Exception:  # noqa: BLE001 - no body to keep
                head = b""
            Path(path).write_bytes(head)
            raise
        Path(path).write_bytes(body[:MAX_WEO_BYTES + 1])
        return path

    # ------------------------------------------------------------------ routes
    def _imf_api(self, vintage: str, codes, isos) -> pd.DataFrame:
        api = self._api
        if api is None:
            from .official.imf_weo import WeoApi
            api = self._api = WeoApi()
        return api.fetch(vintage, codes, isos)

    def _imf_reader(self, vintage: str, codes, isos) -> pd.DataFrame:
        fetch = self._imf
        if fetch is None:
            from imf_reader import weo as imf_weo  # optional dependency, Mac only
            fetch = imf_weo.fetch_data
        month = "April" if int(vintage[5:]) < 7 else "October"
        df = fetch((month, int(vintage[:4])))
        got = getattr(fetch, "last_version_fetched", None)
        if got is not None and tuple(got) != (month, int(vintage[:4])):
            raise FetchUnitError(f"imf-reader served {got}, not {month} {vintage[:4]}", permanent=True)
        sub = df[df["CONCEPT_CODE"].astype(str).isin(set(codes))]
        if isos is not None:
            sub = sub[sub["REF_AREA_CODE"].astype(str).isin(set(isos))]
        out = pd.DataFrame({"iso": sub["REF_AREA_CODE"].astype(str), "series": sub["CONCEPT_CODE"].astype(str),
                            "period": pd.to_numeric(sub["TIME_PERIOD"], errors="coerce"),
                            "value": pd.to_numeric(sub["OBS_VALUE"], errors="coerce")}).dropna(subset=["period", "value"])
        out["period"] = out["period"].astype(int)
        out["source"] = f"IMF WEO {month} {vintage[:4]} via imf-reader"
        return out

    def _weo_package(self, vintage: str, codes, isos) -> pd.DataFrame:
        import inspect
        dl = self._dl
        if dl is None:
            import weo  # optional dependency, Mac only
            dl = weo.download
        try:
            takes_fetch = self._dl is None or "fetch" in inspect.signature(dl).parameters
        except (TypeError, ValueError):
            takes_fetch = False
        self.cache_dir.mkdir(parents=True, exist_ok=True)
        name = f"weo_{vintage}.xls"
        part = self.cache_dir / f".{name}.part"
        if part.exists():                                    # left by an interrupted run: kept, never parsed
            (self.cache_dir / WEO_REJECTED_DIR).mkdir(parents=True, exist_ok=True)
            os.replace(part, self.cache_dir / WEO_REJECTED_DIR / f"weo_{vintage}.stale.part")
        self._meta = {}
        try:
            kw = {"fetch": self._http_fetch} if takes_fetch else {}
            res = dl(int(vintage[:4]), "Apr" if int(vintage[5:]) < 7 else "Oct", filename=part.name,
                     directory=str(self.cache_dir), **kw)
            url = res[1] if isinstance(res, (tuple, list)) and len(res) > 1 else ""
            if url and not self._meta.get("url"):
                self._meta["url"] = url
            if not part.is_file() or part.stat().st_size == 0:     # Mac 2026-10-24 20:16Z: '0.0Mb' for 2007-10..2024-10
                raise FetchUnitError(f"{part.name}: empty download (0 bytes), not a WEO file", permanent=True)
            out = parse_weo_tab(part, codes, isos)  # parse before caching: a bot-check page never becomes a WEO file
        except Exception as e:  # noqa: BLE001 - described, body kept, re-raised as one FetchUnitError
            permanent = _is_permanent(e) or (isinstance(e, FetchUnitError) and "not a WEO" in str(e))
            raise FetchUnitError(f"{type(e).__name__}: {' '.join(str(e).split())[:300]}; "
                                 f"{self._diagnose(vintage, 'weo-package', part, e)}", permanent=permanent) from e
        os.replace(part, self.cache_dir / name)
        out["source"] = f"IMF WEO {vintage} via weo package" + (f" ({url})" if url else "")
        return out

    def _local(self, vintage: str, codes, isos) -> pd.DataFrame:
        p = self.local_file(vintage)
        try:
            out = parse_weo_tab(p, codes, isos)
        except FetchUnitError as e:
            raise FetchUnitError(f"{p}: {e} (save the tab-delimited file; Excel workbooks are not read)", permanent=True) from e
        out["source"] = f"IMF WEO {vintage} local file {p.name} sha256:{sha256_file(p)[:16]}"
        return out

    def __call__(self, vintage: str, codes: Iterable[str], isos: Iterable[str] | None = None) -> pd.DataFrame:
        vintage = normalise_vintage(vintage)
        codes = list(codes)
        routes = (["local file"] if self.local_file(vintage) is not None else []) + [
            r for r in self.routes(vintage) if not (r == "imf-api" and self._api is False)]
        call = {"local file": self._local, "imf-api": self._imf_api, "imf-reader": self._imf_reader,
                "weo-package": self._weo_package}
        errors, permanent = [], []
        for route in routes:
            try:
                return call[route](vintage, codes, isos)
            except Exception as e:  # noqa: BLE001 - a 403 or a non-WEO body falls through; all reported at the end
                errors.append(f"{route}: {type(e).__name__}: {' '.join(str(e).split())[:ROUTE_ERROR_CHARS]}")
                permanent.append(_is_permanent(e))
        drop = f"save the release's tab-delimited 'all countries' file as {self.cache_dir / f'weo_{vintage}.xls'} and resume"
        if not errors:
            raise FetchUnitError(f"no download route for WEO {vintage}: {drop}", permanent=True)
        raise FetchUnitError(f"WEO {vintage}: " + " | ".join(errors) + f" | manual: {drop} (--manual-list)",
                             permanent=all(permanent))


def wb_time_arg(wb, start: int, end: int, db: int | None = None):
    """The years of start..end that World Bank database `db` has, for wbgapi's `time=` (EQ-A-0068).

    wbgapi turns each year into the database's time key ('YR1996') only when the database lists that year and passes
    any other year through unchanged; the World Bank API then answers a mixed list ('1995;YR1996;1997') with a
    non-JSON error page (APIResponseError 'JSON decoding error', PV.EST on 2026-10-24: WGI starts in 1996 and has no
    1997, 1999 or 2001). So only listed years are asked for. A stand-in or older wbgapi without `time.periods`
    gets range(start, end + 1) as before. Raises FetchUnitError when the database lists none of the years."""
    try:
        known = wb.time.periods(db)
    except AttributeError:
        return range(start, end + 1)
    years = [y for y in range(start, end + 1) if str(y) in known]
    if not years:
        raise FetchUnitError(f"World Bank database {db or 'default'} lists no year in {start}..{end}", permanent=True)
    return years


# ---- WGI route chain (EQ-A-0079, RCA-A-003). Sam's 0.4.2 pull (2026-10-25) still got "JSON decoding error" for PV.EST
# on database 3 although the year list was clean (YR1996;YR1998;...;YR2025, every key from WGI's own time dimension), so
# the year list was not the whole cause. wbgapi 1.0.14 (_queryAPI) raises APIResponseError "JSON decoding error" when the
# API answers HTTP 200 with a body that is not JSON (its own docstring: "the API sometimes returns XML even when JSON is
# requested"), and keeps no part of the body. Which request shape the API accepts is UNVERIFIED from the cloud, so the
# fetcher tries each shape in turn, logs every fallback, and `--probe-wb` tries each once and prints the API's answer.
WGI_DB = 3
WGI_SUFFIXES = (".EST", ".PER.RNK")
WGI_CODE_PREFIX = "GOV_WGI_"      # 2024+ WGI database names (GOV_WGI_RL.SC served on 2026-10-23); GOV_WGI_<code> UNVERIFIED
WB_ROUTES = ("list", "range", "drop-latest", "per-year", "wgi-code")
WB_SOURCE = "World Bank API via wbgapi"
WGI_EST_BOUNDS = (-5.0, 5.0)      # WGI estimates lie in about -2.5..2.5; a 0-100 score (GOV_WGI_*.SC) is refused as PV.EST
WB_BODY_HEAD = 300                # characters of a refused API answer quoted in the error and by the probe
WB_BODY_CAP = 65536


def _short(e: BaseException, n: int = 300) -> str:
    return f"{type(e).__name__}: {str(e)[:n]}"


def _is_wgi(code: str) -> bool:
    return code.endswith(WGI_SUFFIXES) or code.startswith(WGI_CODE_PREFIX)


def _wb_kw(db: int | None) -> dict:
    kw = dict(labels=False, skipAggs=True, numericTimeKeys=True)
    if db is not None:
        kw["db"] = db
    return kw


def _wb_keys(wb, db: int | None) -> dict:
    try:
        return dict(wb.time.periods(db))
    except AttributeError:
        return {}


def _wb_wide(wb, code: str, economy, db: int | None, years) -> pd.DataFrame:
    """Route 'list' (the request shape up to 0.4.2): wb.data.DataFrame, economy x year, the years as a ;-list."""
    df = wb.data.DataFrame(code, economy, time=years, **_wb_kw(db))
    long = df.reset_index().melt(id_vars=df.index.name or "economy", var_name="period", value_name="value")
    long.columns = ["iso", "period", "value"]
    return long


def _wb_records(wb, code: str, economy, db: int | None, time) -> pd.DataFrame:
    """wb.data.fetch rows as (iso, period, value). Every route but 'list' uses this: wb.data.DataFrame treats a range
    string ('YR1996:YR2024') or a single year as one time value, drops the time axis and keeps only the first row per
    economy (wbgapi 1.0.14 data.DataFrame, is_single), which would lose years without an error."""
    fetch = getattr(getattr(wb, "data", None), "fetch", None)
    if fetch is None:
        raise FetchUnitError("this wbgapi has no data.fetch")
    rows = [(r.get("economy"), r.get("time"), r.get("value"))
            for r in fetch(code, economy, time=time, **_wb_kw(db)) if not r.get("aggregate")]
    return pd.DataFrame(rows, columns=["iso", "period", "value"])


def _wb_clean(long: pd.DataFrame, start: int, end: int) -> pd.DataFrame:
    d = long.copy()
    d["period"] = pd.to_numeric(d["period"].astype(str).str.replace("YR", "", regex=False), errors="coerce")
    d["value"] = pd.to_numeric(d["value"], errors="coerce")
    d = d.dropna(subset=["period", "value"])
    d = d[(d["period"] >= start) & (d["period"] <= end)].copy()
    d["period"] = d["period"].astype(int)
    d["iso"] = d["iso"].astype(str)
    return d.drop_duplicates(["iso", "period"], keep="first")      # as wb.data.DataFrame: the first row wins


def _wb_out(d: pd.DataFrame, code: str, source: str = WB_SOURCE) -> pd.DataFrame:
    return pd.DataFrame({"iso": d["iso"].astype(str), "series": code, "period": d["period"].astype(int),
                         "value": d["value"].astype(float), "source": source})


def _wb_route(wb, route: str, code: str, economy, db: int | None, years: list[int], keys: dict, start: int, end: int,
              log: Callable[[str], None] = print, unit: str = "") -> tuple[pd.DataFrame, str]:
    """One request shape. Returns (rows iso/period/value, the series code actually served); raises when refused."""
    key = lambda y: keys.get(str(y), f"YR{y}")              # noqa: E731
    if route == "list":
        return _wb_clean(_wb_wide(wb, code, economy, db, years), start, end), code
    if route == "range":
        return _wb_clean(_wb_records(wb, code, economy, db, f"{key(years[0])}:{key(years[-1])}"), start, end), code
    if route == "drop-latest":
        if len(years) < 2:
            raise FetchUnitError("only one year listed; nothing to drop")
        if years[-1] < _utc().year - 2:
            raise FetchUnitError(f"latest listed year {years[-1]} is not recent; not dropped")
        return _wb_clean(_wb_records(wb, code, economy, db, years[:-1]), start, end), code
    if route == "per-year":
        got, failed = [], []
        for y in years:
            try:
                d = _wb_clean(_wb_records(wb, code, economy, db, [y]), start, end)
            except Exception as e:  # noqa: BLE001 - collected; the decision is made over all years below
                failed.append((y, e))
                continue
            if not d.empty:
                got.append(d)
        if not got:
            y, e = failed[0] if failed else (years[0], FetchUnitError("no rows"))
            raise FetchUnitError(f"no year served ({len(failed)} of {len(years)} refused; {y}: {_short(e, 200)})")
        d = pd.concat(got, ignore_index=True)
        bad, last = [y for y, _ in failed], int(d["period"].max())
        inside = [y for y in bad if y < last]
        if inside:
            raise FetchUnitError(f"years {inside} refused inside the served span (up to {last}): a gap is not filled "
                                 f"({inside[0]}: {_short(dict(failed)[inside[0]], 200)})")
        if bad:
            log(f"  {unit}: per-year: years {bad} refused after the last served year {last} (not yet published?): "
                f"left out, not filled")
        return d, code
    if route == "wgi-code":
        if code.startswith(WGI_CODE_PREFIX):
            raise FetchUnitError("already a GOV_WGI_ code")
        alt = WGI_CODE_PREFIX + code
        try:
            d = _wb_clean(_wb_records(wb, alt, economy, db, years), start, end)
        except Exception as e:  # noqa: BLE001 - the same code as a range, then give up
            log(f"  {unit}: wgi-code {alt} as a year list refused ({_short(e, 160)}); trying it as a range")
            d = _wb_clean(_wb_records(wb, alt, economy, db, f"{key(years[0])}:{key(years[-1])}"), start, end)
        if code.endswith(".EST") and len(d):
            lo, hi = float(d["value"].min()), float(d["value"].max())
            if lo < WGI_EST_BOUNDS[0] or hi > WGI_EST_BOUNDS[1]:
                raise FetchUnitError(f"{alt} served values {lo:g}..{hi:g}, not a WGI estimate scale "
                                     f"{WGI_EST_BOUNDS}: refused as {code}")
        return d, alt
    raise ValueError(f"unknown World Bank route {route!r}")


def _wb_url(e: BaseException) -> str | None:
    url = getattr(e, "url", None)
    if not url:
        m = re.search(r"\((https://api\.worldbank\.org/[^)\s]+)\)", str(e))
        url = m.group(1) if m else None
    return url if isinstance(url, str) and url.startswith("https://api.worldbank.org/") else None


def _wb_body(url: str, timeout: float = 20.0) -> dict:
    """GET one World Bank API URL and describe the answer (status, content-type, bytes, sanitised head). wbgapi keeps
    none of a non-JSON body, so this is the only way to see what the API said. https://api.worldbank.org only, and
    redirects are refused (EQ-A-0090: sources.open_url_no_redirect; a redirect is described as its 3xx answer, never
    followed off the host)."""
    from .sources import open_url_no_redirect
    if not url.startswith("https://api.worldbank.org/"):
        raise ValueError(f"refusing {url!r}")
    req = urllib.request.Request(url, headers={"User-Agent": "econquest-panel-history"})
    try:
        with open_url_no_redirect(req, timeout) as r:                 # https host checked above; no redirect
            status, ctype, body = r.status, r.headers.get("Content-Type", ""), r.read(WB_BODY_CAP)
    except urllib.error.HTTPError as e:
        status, ctype, body = e.code, e.headers.get("Content-Type", "") if e.headers else "", e.read(WB_BODY_CAP)
    head = re.sub(r"\s+", " ", re.sub(r"[^\x20-\x7e]", " ", body[:2048].decode("utf-8", "replace"))).strip()
    return {"url": url, "status": status, "content_type": ctype, "bytes": len(body), "head": head[:WB_BODY_HEAD]}


def _wb_answer(errors: list[tuple[str, BaseException]], body: Callable[[str], dict] | None = None) -> str:
    """'; API answer to <route>: HTTP 200 text/xml, 312 bytes: <head>' for the first refused route with a URL."""
    body = body or _wb_body
    for route, e in errors:
        url = _wb_url(e)
        if url:
            try:
                b = body(url)
            except Exception as x:  # noqa: BLE001 - a diagnostic only
                return f"; API answer to {route} not read ({_short(x, 120)})"
            return (f"; API answer to {route}: HTTP {b['status']} {b['content_type'] or '(no content-type)'}, "
                    f"{b['bytes']} bytes: {b['head']!r}")
    return ""


def _transient(e: BaseException) -> bool:
    n, s = type(e).__name__, str(e)
    return (isinstance(e, (OSError, TimeoutError)) or "Connection" in n or "Timeout" in n
            or re.search(r"APIError: \[5\d\d\]", s) is not None or "timed out" in s)


def wgi_series_fetch(wb, code: str, start: int, end: int, economy="all", routes: Iterable[str] = WB_ROUTES,
                     log: Callable[[str], None] = print) -> pd.DataFrame:
    """A WGI series from database 3, trying each route of `routes` in order and logging every fallback:
    list (the years WGI lists, as before), range ('YR1996:YR2024'), drop-latest (the list without the latest listed
    year), per-year (one request per year; only trailing years may be missing), wgi-code (GOV_WGI_<code>, values on the
    estimate scale only). Nothing is filled in: a year no route serves is absent. Raises FetchUnitError naming every
    route's refusal and the API's answer; `permanent` when no refusal looked transient. attrs: wb_route, wb_code."""
    unit = f"worldbank/{code}"
    routes = list(routes)
    years = list(wb_time_arg(wb, start, end, WGI_DB))
    keys = _wb_keys(wb, WGI_DB)
    errors: list[tuple[str, BaseException]] = []
    for i, route in enumerate(routes):
        nxt = routes[i + 1] if i + 1 < len(routes) else None
        try:
            d, served = _wb_route(wb, route, code, economy, WGI_DB, years, keys, start, end, log=log, unit=unit)
            if d.empty:
                raise FetchUnitError("no rows")
        except Exception as e:  # noqa: BLE001 - every refusal is logged and the next route tried
            errors.append((route, e))
            log(f"  {unit}: WGI route {route} refused: {_short(e, 200)}" + (f"; falling back to {nxt}" if nxt else ""))
            continue
        src = WB_SOURCE if route == "list" else (f"{WB_SOURCE} (WGI database {WGI_DB}, route {route}"
                                                + (f", code {served}, presumed same estimate as {code}, UNVERIFIED"
                                                   if served != code else "") + ")")     # EQ-A-0090
        if route != "list":
            log(f"  {unit}: served by WGI route {route}{' as ' + served if served != code else ''}: {len(d):,} rows, "
                f"years {int(d['period'].min())}-{int(d['period'].max())}")
        out = _wb_out(d, code, src)
        out.attrs.update(wb_route=route, wb_code=served)
        return out
    msg = " | ".join(f"{r}: {_short(e, 260)}" for r, e in errors)
    raise FetchUnitError(f"{unit}: every WGI route refused: {msg}{_wb_answer(errors)}",
                         permanent=not any(_transient(e) for _, e in errors))


def _wb_ids(wb, code: str, economy, start: int, end: int) -> tuple[pd.DataFrame, list[str]]:
    """One IDS (database 6) series for the World counterpart only (official.worldbank.fetch_ids), the years IDS lists.
    More than one row per economy-year (per-creditor rows) is refused, never reduced to the first row."""
    from .official.worldbank import IDS_DB, fetch_ids
    years = list(wb_time_arg(wb, start, end, IDS_DB))
    recs, notes = fetch_ids(wb, code, economy, db=IDS_DB, time=years, skipBlanks=True, skipAggs=True, numericTimeKeys=True)
    raw = pd.DataFrame([(r.get("economy"), r.get("time"), r.get("value")) for r in recs if not r.get("aggregate")],
                       columns=["iso", "period", "value"])
    raw["period"] = pd.to_numeric(raw["period"].astype(str).str.replace("YR", "", regex=False), errors="coerce")
    raw = raw.dropna(subset=["period", "value"])
    dup = raw.duplicated(["iso", "period"], keep=False)
    if dup.any():
        raise FetchUnitError(f"IDS {code}: {int(dup.sum())} rows share an economy-year (per-creditor rows?); refused, "
                             f"not reduced to one row ({'; '.join(notes)[:200]})", permanent=True)
    return _wb_clean(raw, start, end), notes


def worldbank_series_fetcher(code: str, start: int, end: int, isos: Iterable[str] | None = None,
                             log: Callable[[str], None] | None = None) -> pd.DataFrame:
    """One World Bank series for every economy (aggregates skipped) through wbgapi; raises on failure (no silent
    skip). Only years the database lists are requested (wb_time_arg). PV.EST and other WGI series that the default
    database refuses go to database 3 through wgi_series_fetch's route chain (EQ-A-0079).

    EQ-A-0094: a code whose database is known (WB_PANEL_SERIES, else feeds.WB_SERIES; `wb_database`) goes there first:
    database 3 (WGI) straight to the WGI route chain, database 6 (IDS) through official.worldbank.fetch_ids for the
    World counterpart, then the default database as a second chance (source says so). Any other code: as before."""
    import wbgapi as wb  # optional dependency, Mac only
    log = log or print
    economy = list(isos) if isos is not None else "all"
    db = wb_database(code)
    if db == WGI_DB:
        return wgi_series_fetch(wb, code, start, end, economy, log=log)
    if db == 6:
        try:
            d, notes = _wb_ids(wb, code, economy, start, end)
            if d.empty:
                raise FetchUnitError("no rows")
            for n in notes:
                log(f"  worldbank/{code}: {n}")
            return _wb_out(d, code, f"{WB_SOURCE} (IDS database 6, World counterpart)")
        except Exception as e:  # noqa: BLE001 - second chance on the default database (WDI carries many DT. series)
            log(f"  worldbank/{code}: IDS database 6 refused ({_short(e, 200)}); trying the default database")
        d = _wb_clean(_wb_wide(wb, code, economy, None, wb_time_arg(wb, start, end)), start, end)
        return _wb_out(d, code, f"{WB_SOURCE} (default database; IDS database 6 refused)")
    try:
        return _wb_out(_wb_clean(_wb_wide(wb, code, economy, None, wb_time_arg(wb, start, end)), start, end), code)
    except Exception as e:  # noqa: BLE001 - second chance on the WGI database, then let it raise
        if not _is_wgi(code):
            raise
        log(f"  worldbank/{code}: default database refused ({_short(e, 200)}); trying the WGI database {WGI_DB}")
    return wgi_series_fetch(wb, code, start, end, economy, log=log)


worldbank_series_fetcher.accepts_log = True


# ---- World Bank-only panel for Team B's interim hazard refit (EQ-A-0094, EQ-B-0098) --------------------------------
# Why the shared World Bank data held only 2020-2025: it is raw_worldbank.csv from feeds.WorldBankFeed (the desk fetch
# and pull pack step 4, universe), which asks for mrnev=6 (the six most recent non-empty values per economy) for the
# 88 universe economies. The panel history (step 2) asks every economy for wb_start..wb_end (1980..this year), but
# for hazard_panel.WB_CODES only (DT.DOD.DSTC.IR.ZS, FI.RES.TOTL.MO, PV.EST), none of Team B's interim features, and
# on 0.4.2 (run 20261025T013201Z) PV.EST and 36 WEO units failed, so no final file was written at all.
# This set is its own history run in <panel>/wb_interim/ (pullpack step 2w, `--wb-set interim`): one resumable unit
# per series, 2000-2025, every economy, so a failing code elsewhere (PV.EST) cannot hold it up.
# code -> (database, what, evidence). "confirmed": in feeds.WB_SERIES with that database AND served by Sam's 0.4.2
# pull (team/inbox/pull-20261025T013150Z/raw_worldbank.csv, economies shown). Anything else is UNVERIFIED and goes
# to the probe first (`--probe-wb panel`), never into the default set.
WB_PANEL_DIR = "wb_interim"
WB_PANEL_START, WB_PANEL_END = 2000, 2025
WB_PANEL_SERIES: dict[str, tuple[int, str, str]] = {
    "BN.CAB.XOKA.GD.ZS": (2, "current account % GDP", "confirmed: WB_SERIES db 2; 0.4.2 pull 88/88 economies"),
    "NY.GDP.MKTP.KD.ZG": (2, "real GDP growth %", "confirmed: WB_SERIES db 2; 0.4.2 pull 88/88"),
    "FP.CPI.TOTL.ZG": (2, "CPI inflation %", "confirmed: WB_SERIES db 2; 0.4.2 pull 88/88"),
    "GOV_WGI_RL.SC": (3, "WGI rule of law, 0-100 score (hazard_refit.WB_INTERIM_FEATURES reads this code)",
                      "confirmed: WB_SERIES db 3; 0.4.2 pull 216 economies (all-economy cross-section)"),
    "DT.DOD.DECT.EX.ZS": (6, "IDS external debt stocks % exports", "confirmed: WB_SERIES db 6 (World counterpart); 0.4.2 pull 60/88"),
    "DT.DOD.DSTC.IR.ZS": (2, "short-term external debt % reserves", "confirmed: WB_SERIES db 2; 0.4.2 pull 57/88; "
                          "panel unit ok 113 economies on run 20261025T013201Z"),
}
WB_PANEL_CODES = tuple(WB_PANEL_SERIES)
# Candidates not confirmed: probed (`--probe-wb panel`), opt-in only (`--wb-codes`), and listed in the handoff to Team B.
WB_PANEL_UNVERIFIED: dict[str, tuple[int, str, str]] = {
    "RL.EST": (3, "WGI rule of law, estimate (-2.5..2.5)", "UNVERIFIED: not in WB_SERIES; same family as PV.EST, which "
               "database 3 refused on 0.4.2 ('JSON decoding error'); the WGI route chain applies"),
    # Team B follow-up (EQ-A-0094): a non-IMF input for 2.1. Not in feeds.WB_SERIES and not in any pull in the repo
    # (0.4.2 raw_worldbank.csv, data/live/raw_worldbank.csv), so it stays out of the default set until the probe serves
    # it: an unknown code in the default set would leave the whole run without a final file.
    "FM.LBL.BMNY.GD.ZS": (2, "broad money % GDP (2.1, non-IMF)", "UNVERIFIED: not in WB_SERIES; never pulled; WDI code "
                          "as Team B gave it"),
}
WB_PROBE_PANEL = ("PV.EST", *WB_PANEL_UNVERIFIED, *WB_PANEL_CODES)     # `--probe-wb panel`; PV.EST first (probe.json)
# IDS families that carry projected (scheduled) years after the last actual year; the API does not flag which years
# are projections (EQ-A-0090 review), so they are refused from the panel rather than cut at a guessed year.
WB_PROJECTION_PREFIXES = ("DT.AMT.", "DT.INT.", "DT.TDS.")


def wb_database(code: str) -> int | None:
    """The World Bank database a code is known to live in: WB_PANEL_SERIES / WB_PANEL_UNVERIFIED, else feeds.WB_SERIES
    (read only; feeds.py is not changed here), else None (default database first, as before EQ-A-0094)."""
    for table in (WB_PANEL_SERIES, WB_PANEL_UNVERIFIED):
        if code in table:
            return table[code][0]
    try:
        from .feeds import WB_SERIES
    except Exception:  # noqa: BLE001 - no table: the default database first
        return None
    return WB_SERIES.get(code, (None,))[0]


def parse_wb_codes(text: str | Iterable[str] | None) -> list[str]:
    """'A.B,C.D' or a list -> validated, upper-case, de-duplicated codes. Raises ValueError on a bad code."""
    if text is None:
        return []
    items = text.split(",") if isinstance(text, str) else list(text)
    out = []
    for c in (str(x).strip().upper() for x in items):
        if not c:
            continue
        if not WB_CODE_RE.fullmatch(c):
            raise ValueError(f"bad World Bank series code {c[:40]!r}")
        if c not in out:
            out.append(c)
    return out


def wb_panel_request(codes: Iterable[str] | None = None, start: int | None = None, end: int | None = None,
                     today: dt.date | None = None) -> dict:
    """The World Bank-only panel request: {"wb_codes", "wb_start", "wb_end"}. Defaults WB_PANEL_CODES, 2000, 2025.
    Projection years are never kept: `end` must be before the current year (a year still running is not an outturn)
    and the IDS families of WB_PROJECTION_PREFIXES are refused. Raises ValueError."""
    today = today or _utc().date()
    codes = parse_wb_codes(codes) if codes is not None else list(WB_PANEL_CODES)
    start, end = int(start or WB_PANEL_START), int(end or min(WB_PANEL_END, today.year - 1))
    if not codes:
        raise ValueError("no World Bank series to fetch")
    proj = [c for c in codes if c.startswith(WB_PROJECTION_PREFIXES)]
    if proj:
        raise ValueError(f"{', '.join(proj)}: IDS projects these beyond the last actual year and the API does not flag "
                         f"which years are projections; not in the World Bank-only panel")
    if end >= today.year:
        raise ValueError(f"end year {end}: {today.year} is not over; projection or partial years are not kept "
                         f"(use {today.year - 1} or earlier)")
    if not 1960 <= start <= end:
        raise ValueError(f"bad year range {start}..{end}")
    return {"wb_codes": codes, "wb_start": start, "wb_end": end}


# Planning helper only: no CLI or pullpack step calls it (tests/test_wb_panel_a094.py pins it). It is the arithmetic
# behind the step 2w size estimate in docs/runbooks/A-mac-pull-pack.md; keep the two in step (EQ-A-0105 N2).
def wb_panel_estimate(codes: Iterable[str] = WB_PANEL_CODES, start: int = WB_PANEL_START, end: int = WB_PANEL_END,
                      per_page: int = 1000) -> dict:
    """Requests, pages and rows for a World Bank-only panel run, from the economies each database answers for 'all'
    (wbgapi asks country/all and drops aggregates after the call): about 266 in WDI (217 economies + 49 aggregates),
    about 214 in WGI and about 125 in IDS (estimates from the 0.4.2 pull and the WDI country list, not measured).
    One metadata request per database (time.periods; IDS adds one for its concepts). Fallback routes not counted."""
    econ = {2: 266, 3: 214, 6: 125}
    years = end - start + 1
    rows, pages, dbs = 0, 0, set()
    per = {}
    for c in codes:
        db = wb_database(c) or 2
        dbs.add(db)
        n = econ.get(db, 266) * years
        p = -(-n // per_page)
        per[c] = {"database": db, "rows_max": n, "pages": p}
        rows, pages = rows + n, pages + p
    meta = len(dbs) + (1 if 6 in dbs else 0)
    return {"series": per, "rows_max": rows, "pages": pages, "metadata_requests": meta, "requests": pages + meta}


def _probe_plain(wb, code: str, db: int | None, start: int, end: int) -> list[tuple]:
    """Trials for a code outside WGI: (route, callable) pairs returning a frame iso/period/value."""
    trials = [("default-db", lambda: _wb_clean(_wb_wide(wb, code, "all", None, list(wb_time_arg(wb, start, end))), start, end))]
    if db == 6:
        trials.insert(0, ("ids", lambda: _wb_ids(wb, code, "all", start, end)[0]))
    return trials


def probe_wb(code: str, out_dir: str | Path = "outputs/wb_probe", start: int = 1980, end: int | None = None,
             wb=None, body: Callable[[str], dict] | None = None, file=None) -> int:
    """Try every World Bank request shape for `code` once and print which works (network; Sam's Mac). Writes
    <out_dir>/probe.json. Exit 0 when at least one route served rows, 1 otherwise."""
    file = file or sys.stdout
    say = lambda s: print(s, file=file)                       # noqa: E731
    if wb is None:
        import wbgapi as wb  # optional dependency, Mac only
    body = body or _wb_body
    end = int(end or _utc().year)
    try:
        from importlib.metadata import version
        wbv = version("wbgapi")
    except Exception:  # noqa: BLE001
        wbv = str(getattr(wb, "__version__", "unknown"))
    res: dict = {"code": code, "utc": _stamp(_utc()), "wbgapi": wbv, "start": start, "end": end, "routes": [], "works": []}
    say(f"World Bank probe for {code} (wbgapi {wbv}), years {start}..{end}")
    db = wb_database(code)
    if not _is_wgi(code) and db != WGI_DB:                   # EQ-A-0094: WDI / IDS codes get their own trials
        res["database"] = db
        for route, call in _probe_plain(wb, code, db, start, end):
            rec = {"route": route}
            try:
                d = call()
                if d.empty:
                    raise FetchUnitError("no rows")
                rec.update(ok=True, rows=len(d), economies=int(d["iso"].nunique()), first=int(d["period"].min()),
                           last=int(d["period"].max()))
                res["works"].append(route)
                say(f"  route {route:<12} OK    {len(d):,} rows, {d['iso'].nunique()} economies, years "
                    f"{rec['first']}-{rec['last']}")
            except Exception as e:  # noqa: BLE001 - recorded and printed
                rec.update(ok=False, error=_short(e, 600))
                say(f"  route {route:<12} FAIL  {_short(e, 240)}")
                url = _wb_url(e)
                if url:
                    try:
                        rec["answer"] = b = body(url)
                        say(f"    API answered HTTP {b['status']} {b['content_type'] or '(no content-type)'}, {b['bytes']} bytes: {b['head']!r}")
                    except Exception as x:  # noqa: BLE001
                        say(f"    API answer not read: {_short(x, 200)}")
            res["routes"].append(rec)
        out = Path(out_dir)
        out.mkdir(parents=True, exist_ok=True)
        _atomic_write_bytes(out / "probe.json", json.dumps(res, indent=1, default=str).encode())
        say(f"WORKS: {', '.join(res['works'])}" if res["works"] else "NO ROUTE WORKS")
        say(f"wrote {out / 'probe.json'}")
        return 0 if res["works"] else 1
    try:
        years = list(wb_time_arg(wb, start, end, WGI_DB))
        res["wgi_years"] = years
        say(f"  WGI database {WGI_DB} lists {len(years)} years: {years[0]}..{years[-1]}"
            f" ({end - 1} {'listed' if end - 1 in years else 'not listed'}, {end} {'listed' if end in years else 'not listed'})")
    except Exception as e:  # noqa: BLE001
        say(f"  WGI time dimension: FAIL {_short(e, 300)}")
        res["wgi_years_error"] = _short(e, 600)
        years = []
    try:
        ids = {str(s.get("id")) for s in wb.series.list(db=WGI_DB)}
        stem = code.split(".")[0]
        near = sorted(i for i in ids if stem in i)[:12]
        res["series"] = {"listed": code in ids, "gov_wgi_listed": (WGI_CODE_PREFIX + code) in ids, "n": len(ids), "near": near}
        say(f"  WGI series list: {len(ids)} series; {code} {'listed' if code in ids else 'NOT listed'}; "
            f"{WGI_CODE_PREFIX + code} {'listed' if (WGI_CODE_PREFIX + code) in ids else 'not listed'}; "
            f"codes with {stem!r}: {', '.join(near) or 'none'}")
    except Exception as e:  # noqa: BLE001
        say(f"  WGI series list: FAIL {_short(e, 300)}")
        res["series_error"] = _short(e, 600)
    keys = _wb_keys(wb, WGI_DB) if years else {}
    trials: list[tuple[str, int | None, list[int]]] = [("default-db", None, list(wb_time_arg(wb, start, end)) if years else [])]
    trials += [(r, WGI_DB, years if r != "per-year" else sorted({years[0], years[-1]}) if years else []) for r in WB_ROUTES]
    bodies = 0
    for route, db, yrs in trials:
        rec = {"route": route}
        try:
            if not yrs:
                raise FetchUnitError("no years to ask for")
            r = "list" if route == "default-db" else route
            d, served = _wb_route(wb, r, code, "all", db, yrs, keys if db else {}, start, end, log=say, unit=code)
            if d.empty:
                raise FetchUnitError("no rows")
            rec.update(ok=True, rows=len(d), economies=int(d["iso"].nunique()), first=int(d["period"].min()),
                       last=int(d["period"].max()), code=served)
            if served != code:
                rec.update(value_min=float(d["value"].min()), value_max=float(d["value"].max()))
            res["works"].append(route)
            say(f"  route {route:<12} OK    {len(d):,} rows, {d['iso'].nunique()} economies, years "
                f"{rec['first']}-{rec['last']}{' (code ' + served + ')' if served != code else ''}")
        except Exception as e:  # noqa: BLE001 - recorded and printed
            rec.update(ok=False, error=_short(e, 600))
            say(f"  route {route:<12} FAIL  {_short(e, 240)}")
            url = _wb_url(e)
            if url and bodies < 3:
                bodies += 1
                try:
                    b = body(url)
                    rec["answer"] = b
                    say(f"    API answered HTTP {b['status']} {b['content_type'] or '(no content-type)'}, {b['bytes']} bytes: {b['head']!r}")
                except Exception as x:  # noqa: BLE001
                    say(f"    API answer not read: {_short(x, 200)}")
        res["routes"].append(rec)
    out = Path(out_dir)
    out.mkdir(parents=True, exist_ok=True)
    _atomic_write_bytes(out / "probe.json", json.dumps(res, indent=1, default=str).encode())
    wgi_ok = [r for r in res["works"] if r != "default-db"]
    say(f"WORKS: {', '.join(res['works'])}" if res["works"] else "NO ROUTE WORKS")
    if wgi_ok:
        say(f"The fetcher uses the first of: {', '.join(WB_ROUTES)} -> {wgi_ok[0]}")
    say(f"wrote {out / 'probe.json'}")
    return 0 if res["works"] else 1


def probe_wb_many(codes: Iterable[str], out_dir: str | Path = "outputs/wb_probe", start: int = WB_PANEL_START,
                  end: int | None = None, wb=None, body: Callable[[str], dict] | None = None, file=None) -> int:
    """probe_wb for several codes (EQ-A-0094). Each code's result goes to <out_dir>/codes/<code>/probe.json;
    <out_dir>/probe.json is the first code's (the shape readers of the single-code probe expect, PV.EST first in
    `--probe-wb panel`), and <out_dir>/probes.json lists every code: works, rows, economies, years, verified or not.
    Exit 0 when every code has a working route, 1 otherwise."""
    file = file or sys.stdout
    codes = parse_wb_codes(codes)
    if wb is None:
        import wbgapi as wb  # optional dependency, Mac only
    out = Path(out_dir)
    end = int(end or min(WB_PANEL_END, _utc().year - 1))
    summary: dict = {"utc": _stamp(_utc()), "start": start, "end": end, "codes": codes, "results": {}}
    first = None
    for code in codes:
        sub = out / "codes" / code
        rc = probe_wb(code, sub, start=start, end=end, wb=wb, body=body, file=file)
        res = json.loads((sub / "probe.json").read_text())
        first = first or res
        ok = [r for r in res.get("routes", []) if r.get("ok")]
        best = ok[0] if ok else {}
        status = (WB_PANEL_SERIES.get(code) or WB_PANEL_UNVERIFIED.get(code) or (None, "", "not in the panel list"))[2]
        summary["results"][code] = {"exit": rc, "works": res.get("works", []), "rows": best.get("rows"),
                                    "economies": best.get("economies"), "first": best.get("first"),
                                    "last": best.get("last"), "database": wb_database(code), "evidence": status}
        print("", file=file)
    _atomic_write_bytes(out / "probe.json", json.dumps(first, indent=1, default=str).encode())
    _atomic_write_bytes(out / "probes.json", json.dumps(summary, indent=1, default=str).encode())
    print("SUMMARY", file=file)
    for code, r in summary["results"].items():
        print(f"  {code:<20} {'OK  ' if r['works'] else 'FAIL'} {', '.join(r['works']) or 'no route'}"
              + (f"; {r['economies']} economies, {r['first']}-{r['last']}" if r["works"] else ""), file=file)
    print(f"wrote {out / 'probes.json'} and {out / 'probe.json'} ({codes[0]})", file=file)
    return 0 if all(r["works"] for r in summary["results"].values()) else 1


# ------------------------------------------------------------------------------------------ panel vintages

def _content_hash(files: dict[str, bytes]) -> str:
    h = hashlib.sha256()
    for name in sorted(files):
        h.update(name.encode() + b"\0" + files[name] + b"\0")
    return h.hexdigest()


def list_panel_vintages(panel_dir: str | Path) -> list[str]:
    root = Path(panel_dir) / "vintages"
    return sorted(p.name for p in root.iterdir() if p.is_dir() and p.name[:4].isdigit()) if root.exists() else []


def save_panel_vintage(panel_dir: str | Path, files: dict[str, str | Path | bytes], label: str = "",
                       now: dt.datetime | None = None) -> Path:
    """Append-only copy of `files` ({published name: path or bytes}) to <panel_dir>/vintages/<UTC ts>-<hash8>/.

    The folder is created with exist_ok=False (never overwritten), files are 0444 and the folder 0555; a row is
    appended to vintages/index.csv under an exclusive lock. If the newest indexed vintage has the same content
    hash, it is returned instead of making a duplicate."""
    from .ledger import locked_append
    now = _utc(now)
    blobs = {}
    for name, src in files.items():
        if "/" in name or "\\" in name or name.startswith("."):
            raise ValueError(f"bad file name for a panel vintage: {name!r}")
        blobs[name] = src if isinstance(src, bytes) else Path(src).read_bytes()
    digest = _content_hash(blobs)
    root = Path(panel_dir) / "vintages"
    root.mkdir(parents=True, exist_ok=True)
    idx = root / "index.csv"
    if idx.exists():
        prev = pd.read_csv(idx, dtype=str)
        same = prev[prev["hash"] == digest]
        if len(same) and (root / same.iloc[-1]["vintage_id"]).is_dir():
            return root / same.iloc[-1]["vintage_id"]
    v = root / f"{now.strftime('%Y-%m-%dT%H%M%SZ')}-{digest[:8]}"
    v.mkdir(exist_ok=False)
    for name in sorted(blobs):
        (v / name).write_bytes(blobs[name])
        os.chmod(v / name, 0o444)
    # a directory needs the x bit to be listed; no write bit anywhere, so the vintage is read-only
    os.chmod(v, 0o555)  # nosec B103
    with locked_append(idx, PANEL_VINTAGE_INDEX) as (w, f, new):
        if new:
            w.writeheader()
        w.writerow({"vintage_id": v.name, "created_utc": _stamp(now), "hash": digest, "n_files": len(blobs),
                    "label": escape_formula(str(label)), "files": ";".join(sorted(blobs))})
    return v


def remove_panel_vintage(path: str | Path) -> None:
    """Delete one panel vintage folder (``<panel>/vintages/<YYYY-MM-DD>T<HHMMSS>Z-<hash8>``) for clean-up.

    Vintages are written read-only (files 0444, folder 0555), so a plain ``rm -r`` fails for a normal user; this
    restores the owner's write bit first (the ``chmod -R u+w`` of the runbook) and then removes the folder. Only a
    folder named like a vintage directly inside a ``vintages`` folder is accepted. The row in vintages/index.csv is
    kept (the index is append-only); ``save_panel_vintage`` ignores rows whose folder no longer exists."""
    v = Path(path)
    if v.is_symlink() or not v.is_dir() or v.parent.name != "vintages" or not PANEL_VINTAGE_RE.fullmatch(v.name):
        raise ValueError(f"not a panel vintage folder: {v}")
    os.chmod(v, stat.S_IRWXU | stat.S_IRGRP | stat.S_IXGRP)
    for child in v.iterdir():
        if not child.is_symlink():
            os.chmod(child, child.stat().st_mode | stat.S_IWUSR)
    shutil.rmtree(v)


# ------------------------------------------------------------------------------------------ staged fetch

def _units(sources, weo_vintages, wb_codes) -> list[str]:
    u = []
    if "weo" in sources:
        u += [f"weo/{v}" for v in weo_vintages]
    if "worldbank" in sources:
        u += [f"worldbank/{c}" for c in wb_codes]
    return u


def _check_units(units: Iterable[str], params: dict) -> None:
    """Every unit key must match UNIT_RE and the set of units must be exactly the one the params describe, so a
    hand-edited manifest cannot point the fetch or the final assembly at other files (SEC review S1)."""
    units = list(units)
    bad = [u for u in units if not isinstance(u, str) or not UNIT_RE.fullmatch(u)]
    if bad:
        raise ValueError(f"bad unit key(s) in manifest: {bad[:5]}")
    want = set(_units(params.get("sources", []), params.get("weo_vintages", []), params.get("wb_codes", [])))
    if set(units) != want:
        raise ValueError(f"manifest units do not match its params: extra {sorted(set(units) - want)[:5]}, "
                         f"missing {sorted(want - set(units))[:5]}")


def _staged_path(stage: Path, src: str, key: str) -> Path:
    """<stage>/<src>/<key>.csv, refused if it resolves outside the stage folder."""
    f = stage / src / f"{key}.csv"
    root = stage.resolve()
    if not f.resolve().is_relative_to(root):
        raise ValueError(f"staged file {f} resolves outside {root}")
    return f


def _write_manifest(stage: Path, manifest: dict) -> None:
    _atomic_write_bytes(stage / "manifest.json", json.dumps(manifest, indent=1, sort_keys=True).encode())


def _validated(df: pd.DataFrame, unit: str, vintage: str | None) -> pd.DataFrame:
    if df is None or not isinstance(df, pd.DataFrame):
        raise FetchUnitError(f"{unit}: fetcher returned {type(df).__name__}, not a DataFrame")
    miss = [c for c in LONG_COLUMNS if c not in df.columns]
    if miss:
        raise FetchUnitError(f"{unit}: missing columns {miss}")
    d = df[LONG_COLUMNS].copy()
    d["iso"] = d["iso"].astype(str).str.strip().str.upper()
    d["series"] = d["series"].astype(str).str.strip()
    d["period"] = pd.to_numeric(d["period"], errors="coerce")
    d["value"] = pd.to_numeric(d["value"], errors="coerce")
    d = d.dropna(subset=["period", "value"])
    d = d[d["iso"].str.fullmatch(r"[A-Z0-9]{3}")]
    d["period"] = d["period"].astype(int)
    if d.empty:
        raise FetchUnitError(f"{unit}: no rows")
    if vintage is not None:
        d["vintage"] = vintage
    return d.sort_values(["iso", "series", "period"]).reset_index(drop=True)


def fetch_history(out_dir: str | Path, sources: Iterable[str] = SOURCES, weo_vintages: Iterable[str] | None = None,
                  isos: Iterable[str] | None = None, retries: int = 3, backoff: float = 2.0, fetchers: dict | None = None, *,
                  run_id: str | None = None, wb_codes: Iterable[str] | None = None, weo_codes: Iterable[str] | None = None,
                  wb_start: int = 1980, wb_end: int | None = None, cache_dir: str | Path | None = None,
                  save_vintage: bool = True, now: dt.datetime | None = None, sleep: Callable[[float], None] = time.sleep,
                  log: Callable[[str], None] = print) -> dict:
    """Staged, resumable pull of every economy's WEO (one unit per release) and World Bank (one unit per series)
    history. Returns the manifest (dict) when every unit is ok and the final files are written; raises
    IncompleteFetchError (final files untouched) otherwise.

    run_id: None starts a new run (UTC timestamp id); an existing id resumes it with the parameters stored in its
    manifest (sources, vintages, codes, isos, years), skipping units already ok with a matching sha256.
    fetchers: {"weo": f(vintage, codes, isos) -> DataFrame, "worldbank": f(code, start, end, isos) -> DataFrame},
    each returning columns iso, series, period, value, source; defaults are WeoVintageFetcher and
    worldbank_series_fetcher. retries: extra attempts per unit after the first; the wait before retry k is
    backoff * 2**(k-1) seconds."""
    out = Path(out_dir)
    now = _utc(now)
    staging = out / "staging"
    if run_id:
        if not RUN_ID_RE.fullmatch(str(run_id)):                     # --resume value: no path parts (SEC review S1)
            raise ValueError(f"bad run id {run_id!r}: expected YYYYMMDDTHHMMSSZ[-n]")
        stage = staging / run_id
        mpath = stage / "manifest.json"
        if not mpath.is_file():
            raise FileNotFoundError(f"no run {run_id!r}: {mpath} does not exist")
        manifest = json.loads(mpath.read_text())
        params = manifest["params"]
        _check_units(manifest["units"], params)
        log(f"resuming run {run_id}: {sum(u['status'] == 'ok' for u in manifest['units'].values())}/{len(manifest['units'])} units ok")
    else:
        run_id = now.strftime("%Y%m%dT%H%M%SZ")
        stage = staging / run_id
        n = 0
        while stage.exists():
            n += 1
            stage = staging / f"{run_id}-{n}"
        run_id = stage.name
        sources = [s for s in sources]
        bad = [s for s in sources if s not in SOURCES]
        if bad or not sources:
            raise ValueError(f"sources must be a non-empty subset of {SOURCES}, got {sources}")
        vint = sorted({normalise_vintage(v) for v in weo_vintages}) if weo_vintages is not None else default_weo_vintages(now.date())
        params = {"sources": sources, "weo_vintages": vint if "weo" in sources else [],
                  "weo_codes": list(weo_codes or WEO_CODES), "wb_codes": list(wb_codes or WB_CODES) if "worldbank" in sources else [],
                  "isos": sorted(set(isos)) if isos is not None else None,
                  "wb_start": int(wb_start), "wb_end": int(wb_end or now.year)}
        manifest = {"run_id": run_id, "created_utc": _stamp(now), "params": params, "status": "running",
                    "units": {u: {"status": "pending", "rows": 0, "sha256": "", "file": "", "attempts": 0, "error": ""}
                              for u in _units(params["sources"], params["weo_vintages"], params["wb_codes"])}}
        _check_units(manifest["units"], params)
        stage.mkdir(parents=True, exist_ok=False)
        _write_manifest(stage, manifest)
        log(f"new run {run_id}: {len(manifest['units'])} units -> {stage}")
    if not manifest["units"]:
        raise ValueError("nothing to fetch (no WEO releases and no World Bank series)")

    fetchers = dict(fetchers or {})
    if "weo" not in fetchers:
        fetchers["weo"] = WeoVintageFetcher(cache_dir or (staging / "weo_cache"))
    if "worldbank" not in fetchers:
        wbf = worldbank_series_fetcher                      # the module attribute, so a test's stand-in is used as is
        fetchers["worldbank"] = ((lambda *a, **k: wbf(*a, log=log, **k)) if getattr(wbf, "accepts_log", False) else wbf)
    p = params
    for unit, rec in manifest["units"].items():
        src, key = unit.split("/", 1)
        f = _staged_path(stage, src, key)
        if rec["status"] == "ok" and f.is_file() and sha256_file(f) == rec["sha256"]:
            continue
        rec.update(status="pending", error="")
        for attempt in range(1, retries + 2):
            rec["attempts"] = int(rec.get("attempts", 0)) + 1
            try:
                if src == "weo":
                    df = _validated(fetchers["weo"](key, p["weo_codes"], p["isos"]), unit, key)
                else:
                    raw = fetchers["worldbank"](key, p["wb_start"], p["wb_end"], p["isos"])
                    wb_route = getattr(raw, "attrs", {}).get("wb_route") if isinstance(raw, pd.DataFrame) else None
                    df = _validated(raw, unit, None)
                    if wb_route:                             # EQ-A-0079: which WGI request shape served the unit
                        rec["wb_route"] = wb_route
                        rec["wb_code"] = raw.attrs.get("wb_code", key)
                data = _csv_bytes(df)
                _atomic_write_bytes(f, data)
                rec.update(status="ok", rows=len(df), sha256=hashlib.sha256(data).hexdigest(), file=f"{src}/{key}.csv",
                           error="", fetched_utc=_stamp(_utc()), n_economies=int(df["iso"].nunique()),
                           source=str(df["source"].iloc[0]),
                           codes_missing=sorted(set(p["weo_codes"]) - set(df["series"])) if src == "weo" else [])
                log(f"  {unit}: ok, {len(df):,} rows, {df['iso'].nunique()} economies")
                break
            except Exception as e:  # noqa: BLE001 - any failure is recorded and retried, then reported
                rec.update(status="failed", error=f"{type(e).__name__}: {str(e)[:UNIT_ERROR_CHARS]}")
                log(f"  {unit}: attempt {attempt} failed: {rec['error']}")
                if getattr(e, "permanent", False):          # 403 / not a WEO file / no dataflow: a retry repeats it
                    log(f"  {unit}: not retried (every route refused for a reason a retry cannot change)")
                    break
                if attempt <= retries:
                    sleep(backoff * 2 ** (attempt - 1))
        _write_manifest(stage, manifest)

    missing = [u for u, r in manifest["units"].items() if r["status"] != "ok"]
    if missing:
        manifest["status"] = "incomplete"
        _write_manifest(stage, manifest)
        raise IncompleteFetchError(f"{len(missing)} of {len(manifest['units'])} units missing after retries: {missing[:10]}. "
                                   f"Final files not written. Resume with --resume {run_id}", manifest, missing)

    # every unit ok: assemble, then replace the final files
    finals: dict[str, bytes] = {}
    if "weo" in p["sources"]:
        weo = pd.concat([pd.read_csv(_staged_path(stage, "weo", v), dtype={"iso": str, "series": str, "vintage": str})
                         for v in p["weo_vintages"]], ignore_index=True)
        finals["weo_history.csv"] = _csv_bytes(weo[WEO_COLUMNS].sort_values(["vintage", "iso", "series", "period"], kind="stable"))
    if "worldbank" in p["sources"]:
        wbh = pd.concat([pd.read_csv(_staged_path(stage, "worldbank", c), dtype={"iso": str, "series": str})
                         for c in p["wb_codes"]], ignore_index=True)
        finals["worldbank_history.csv"] = _csv_bytes(wbh[LONG_COLUMNS].sort_values(["series", "iso", "period"], kind="stable"))
    tmp = {}
    try:
        for name, data in finals.items():
            fd, t = tempfile.mkstemp(dir=out, prefix=f".{name}.", suffix=".tmp")
            with os.fdopen(fd, "wb") as fh:
                fh.write(data)
            os.chmod(t, 0o644)
            tmp[name] = t
        for name, t in tmp.items():
            os.replace(t, out / name)
    finally:
        for t in tmp.values():
            if os.path.exists(t):
                os.unlink(t)
    manifest["status"] = "complete"
    manifest["final"] = {name: {"sha256": hashlib.sha256(d).hexdigest(), "bytes": len(d)} for name, d in finals.items()}
    manifest["completed_utc"] = _stamp(_utc())
    if save_vintage:
        files = {name: out / name for name in finals}
        files["manifest.json"] = json.dumps(manifest, indent=1, sort_keys=True).encode()
        v = save_panel_vintage(out, files, label=f"history run {run_id}", now=now)
        manifest["panel_vintage"] = v.name
        log(f"panel vintage {v}")
    _write_manifest(stage, manifest)
    for name in finals:
        log(f"wrote {out / name} (sha256 {manifest['final'][name]['sha256'][:16]})")
    return manifest


# ------------------------------------------------------------------------------------------ manual drop-in list

def _latest_incomplete_run(out: Path) -> str | None:
    stage = out / "staging"
    if not stage.is_dir():
        return None
    for d in sorted((p for p in stage.iterdir() if p.is_dir() and RUN_ID_RE.fullmatch(p.name)), reverse=True):
        try:
            m = json.loads((d / "manifest.json").read_text())
        except (OSError, ValueError):
            continue
        if m.get("status") != "complete":
            return d.name
    return None


def manual_drop_list(out: str | Path, cache_dir: str | Path | None = None, run_id: str | None = None,
                     vintages: Iterable[str] | None = None) -> tuple[list[dict], str]:
    """Releases still missing, each with the exact file name and folder to save a browser download as (route 1).

    Which releases: those not ok in run `run_id`; else `vintages`; else the newest incomplete run under
    <out>/staging; else every default release. Releases that already have a local file are left out. No network.
    The page is named, not linked: no WEO archive page URL is verified in this repository."""
    out = Path(out)
    cache = Path(cache_dir) if cache_dir else out / "staging" / "weo_cache"
    ctx = ""
    if run_id is None and vintages is None:
        run_id = _latest_incomplete_run(out)
    if run_id is not None:
        if not RUN_ID_RE.fullmatch(str(run_id)):
            raise ValueError(f"bad run id {run_id!r}: expected YYYYMMDDTHHMMSSZ[-n]")
        m = json.loads((out / "staging" / run_id / "manifest.json").read_text())
        want = [u.split("/", 1)[1] for u, r in m["units"].items() if u.startswith("weo/") and r.get("status") != "ok"]
        ctx = f"run {run_id}"
    elif vintages is not None:
        want = [normalise_vintage(v) for v in vintages]
        ctx = "releases asked for"
    else:
        want = default_weo_vintages()
        ctx = "every default release (no incomplete run found)"
    fx = WeoVintageFetcher(cache, imf_api=False)
    rows = []
    for v in sorted(set(want)):
        if fx.local_file(v) is not None:
            continue
        mon = "Sep" if v == "2011-09" else ("Apr" if int(v[5:]) < 7 else "Oct")
        rows.append({"release": v, "save_as": f"weo_{v}.xls", "folder": str(cache),
                     "page": f"WEO database archive page for {_release_name(v)}",
                     "file": f"WEO{mon}{v[:4]}all.xls"})        # the name weo 0.8.4 requests (weo/dates.py create_url)
    return rows, ctx


def print_manual_list(rows: list[dict], ctx: str, file=None) -> None:
    file = file or sys.stdout
    if not rows:
        print(f"No WEO release missing ({ctx}): nothing to download by hand.", file=file)
        return
    print(f"{len(rows)} WEO release(s) to download by hand ({ctx}). In a browser on imf.org, open the page named below,\n"
          f"download the release's tab-delimited 'all countries' file (not an Excel .xlsx workbook), save it under the\n"
          f"exact name in this folder, then rerun `python -m econquest.ingestion.pullpack run` (the run resumes and reads\n"
          f"local files first):\n  folder: {rows[0]['folder']}", file=file)
    for r in rows:
        print(f"  {r['release']}  save as {r['save_as']:<18} from: {r['page']} (file named like {r['file']})", file=file)


# ------------------------------------------------------------------------------------------ command line

def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.panel_history",
                                 description="Staged, resumable WEO (all releases) and World Bank history pull for the hazard panel.")
    ap.add_argument("--out", default="data/panel", help="panel folder (default data/panel)")
    ap.add_argument("--resume", metavar="RUN_ID", help="resume a run under <out>/staging/RUN_ID with its stored parameters")
    ap.add_argument("--sources", default="weo,worldbank", help="comma list of weo, worldbank")
    ap.add_argument("--weo-vintages", help="WEO releases: '2007-10:2026-10' or a comma list (default: Oct 2007 to the latest)")
    ap.add_argument("--isos", help="comma list of ISO3 codes (default: every economy)")
    ap.add_argument("--retries", type=int, default=3)
    ap.add_argument("--backoff", type=float, default=2.0)
    ap.add_argument("--wb-start", type=int, help="first year (default 1980; 2000 with --wb-set interim)")
    ap.add_argument("--wb-end", type=int, help="last year (default this year; 2025 with --wb-set interim)")
    ap.add_argument("--wb-set", choices=("hazard", "interim"), default="hazard",
                    help="World Bank series: hazard (hazard_panel.WB_CODES, default) or interim (EQ-A-0094: Team B's "
                         "World Bank-only panel, 2000-2025, World Bank only, into <out>/wb_interim)")
    ap.add_argument("--wb-codes", help="comma list of World Bank codes in place of the set's (e.g. add RL.EST after "
                                       "the probe served it)")
    ap.add_argument("--cache-dir", help="WEO file cache and drop folder for manual downloads (default <out>/staging/weo_cache)")
    ap.add_argument("--no-vintage", action="store_true", help="do not save a panel vintage after success")
    ap.add_argument("--list-vintages", action="store_true", help="print the WEO releases and download route of each, then exit")
    ap.add_argument("--manual-list", action="store_true",
                    help="print, for every missing release, the file name and folder to save a browser download as (no network)")
    ap.add_argument("--probe-weo-api", action="store_true",
                    help="list the WEO dataflows of the IMF SDMX 3.0 API and try one sample request (network); exit 1 on failure")
    ap.add_argument("--probe-out", default="outputs/weo_api_probe", help="folder for --probe-weo-api (default outputs/weo_api_probe)")
    ap.add_argument("--probe-wb", metavar="CODES",
                    help="try every World Bank request shape for a series once and print which works (network): one "
                         "code (PV.EST), a comma list, or 'panel' (PV.EST, the UNVERIFIED candidates and the "
                         "World Bank-only panel set, 2000-2025)")
    ap.add_argument("--probe-wb-out", default="outputs/wb_probe", help="folder for --probe-wb (default outputs/wb_probe)")
    a = ap.parse_args(argv)
    try:
        vint = _parse_vintage_arg(a.weo_vintages) if a.weo_vintages else None
    except ValueError as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    out = Path(a.out)
    if a.probe_wb:
        if a.probe_wb.strip().lower() == "panel":
            return probe_wb_many(WB_PROBE_PANEL, a.probe_wb_out, start=a.wb_start or WB_PANEL_START, end=a.wb_end)
        if "," in a.probe_wb:
            try:
                codes = parse_wb_codes(a.probe_wb)
            except ValueError as e:
                print(f"error: {e}", file=sys.stderr)
                return 2
            return probe_wb_many(codes, a.probe_wb_out, start=a.wb_start or WB_PANEL_START, end=a.wb_end)
        if not re.fullmatch(r"[A-Za-z0-9._]{1,40}", a.probe_wb):
            print(f"error: bad series code {a.probe_wb!r}", file=sys.stderr)
            return 2
        return probe_wb(a.probe_wb, a.probe_wb_out, start=a.wb_start or 1980, end=a.wb_end)
    if a.probe_weo_api:
        from .official.imf_weo import probe
        return probe(a.probe_out)
    if a.manual_list:
        try:
            rows, ctx = manual_drop_list(out, a.cache_dir, a.resume, vint)
        except (ValueError, OSError) as e:
            print(f"error: {e}", file=sys.stderr)
            return 2
        print_manual_list(rows, ctx)
        return 0
    if a.list_vintages:
        cache = Path(a.cache_dir) if a.cache_dir else out / "staging" / "weo_cache"
        fx = WeoVintageFetcher(cache, imf_api=False)
        for v in vint or default_weo_vintages():
            r = (["local file"] if fx.local_file(v) else []) + fx.routes(v)
            print(f"{v}  {', '.join(r) if r else 'NO ROUTE: drop weo_' + v + '.xls in ' + str(cache)}")
        return 0
    if not out.is_dir():
        print(f"error: {out} is not a folder (run from the econquest folder)", file=sys.stderr)
        return 2
    sources = [s.strip() for s in a.sources.split(",") if s.strip()]
    wb_kw: dict = {"wb_start": a.wb_start or 1980, "wb_end": a.wb_end}
    try:
        if a.wb_set == "interim":                        # EQ-A-0094: its own run folder, World Bank only
            wb_kw = wb_panel_request(a.wb_codes.split(",") if a.wb_codes else None, a.wb_start, a.wb_end)
            sources, out = ["worldbank"], out / WB_PANEL_DIR
            out.mkdir(exist_ok=True)
        elif a.wb_codes:
            wb_kw["wb_codes"] = parse_wb_codes(a.wb_codes)
    except ValueError as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    try:
        m = fetch_history(out, sources=sources, weo_vintages=vint,
                          isos=[s.strip().upper() for s in a.isos.split(",")] if a.isos else None, retries=a.retries,
                          backoff=a.backoff, run_id=a.resume, cache_dir=a.cache_dir, save_vintage=not a.no_vintage,
                          **wb_kw)
    except IncompleteFetchError as e:
        print(f"INCOMPLETE: {e}", file=sys.stderr)
        for u in e.missing:
            print(f"  {u}: {e.manifest['units'][u]['error']}", file=sys.stderr)
        return 1
    except (ValueError, FileNotFoundError) as e:
        print(f"error: {e}", file=sys.stderr)
        return 2
    n = {u: r for u, r in m["units"].items()}
    print(f"complete: run {m['run_id']}, {len(n)} units, panel vintage {m.get('panel_vintage', '(not saved)')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
