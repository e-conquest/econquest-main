"""Indicator 1.8 from the CRAG episode file: count of default episodes in a window (EQ-A-0083, folded into EQ-A-0092).

Rulebook 1.8 (data/rulebook.csv): "Default record: restructurings or defaults, past 20 years", unit count, scored
0 / 0.5 / 1 / 2 / 3 at the 0-100 thresholds, source "BoC-BoE sovereign default database", api "Bank of Canada CRAG
database (annual file)". The live episode file is data/panel/sovereign_defaults_crag.csv (one row per CRAG spell:
iso, country, start, end, creditors, note, source, source_vintage; written by crag_update / default_panel.import_crag)
and its coverage file sovereign_defaults_crag_universe.csv (iso, first_year, last_year, has_spell).

RULE (Team B, docs/validation/indicator-rules.md section 16, answer to HO-20261025-A-B-006, EQ-B-0104):
1. window: 20 calendar years ending in the as-of year minus 1, both ends included (as_of 2026-10-25 -> 2006-2025);
   if the CRAG file ends earlier, the count uses what it has and carries crag_last_year (the window never moves back);
2. overlap: an episode counts if any of its default years is in the window;
3. episodes follow the hazard event rule crag_v1 (validation/hazard_events.py RECOMMENDED_RULE: USD 10m floor, cure
   2 years, overlapping and adjacent spells merged, point in time): one merged spell is one episode;
4. all CRAG creditor classes count;
5. countries outside the CRAG coverage file (JPN, KOR, SGP) or whose coverage starts after the window start are not
   served: the seed stays, labelled, never a 0;
3a. new defaults inside one episode count too (EQ-A-0130, HO-20261026-B-A-004): the years
   ``rules.hazard.redefault_years`` dates from CRAG's own annual in-scope arrears (``annual_in_scope``, the raw
   BoC-BoE file the crag_v1 episodes were rebuilt from), within the window, are added to the episode count and named
   in the cell text, e.g. "2001-2025 (+ new defaults 2014, 2019, 2023)". Parity with Team B's reference
   ``validation.crag_redefaults.desk_table`` is tested for the 18 desk names (tests/test_crag_count_a083.py);
6. the first values are a Tier 1 data batch: they go through the gate HELD with the reason TIER1_HOLD (Sam's sign-off
   is parked on the when-Sam-is-ready list) and into the MVP dataset as held cells (``mvp_held_cells``). Nothing here
   writes data/indicators.csv.

``CragWindow`` / ``count_episodes`` stay parameterised (window_years, end_year, rule; no defaults);
``approved_window(as_of)`` is the section 16 window and ``rule16_cells`` the section 16 count for a list of countries.
The transform never fills a gap: a country without coverage gets no value (None) and a reason, never a 0.
"""
from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path

import csv
import io

import pandas as pd

INDICATOR = "1.8"
RULES = ("overlap", "start")        # overlap: a spell with any year in the window; start: a spell that starts in it
RULE_SOURCE = "indicator-rules.md section 16 incl. 3a (HO-20261025-A-B-006, EQ-B-0104; HO-20261026-B-A-004)"
RULE16 = {"window_years": 20, "end_offset": 1, "rule": "overlap", "episodes": "crag_v1"}
TIER1_HOLD = "Tier 1: Sam sign-off (parked)"


class CragCountError(ValueError):
    """Bad parameters or an unusable episode file."""


@dataclass(frozen=True)
class CragWindow:
    """The counting window: years end_year - window_years + 1 .. end_year (both included), and the rule that says
    which spells are in it. No field has a default (Team B decides them)."""
    window_years: int
    end_year: int
    rule: str

    def __post_init__(self):
        if isinstance(self.window_years, bool) or not isinstance(self.window_years, int) or self.window_years < 1:
            raise CragCountError(f"window_years must be a positive integer, got {self.window_years!r}")
        if isinstance(self.end_year, bool) or not isinstance(self.end_year, int) or not 1800 <= self.end_year <= 2200:
            raise CragCountError(f"end_year must be a calendar year, got {self.end_year!r}")
        if self.rule not in RULES:
            raise CragCountError(f"rule must be one of {RULES}, got {self.rule!r}")

    @property
    def first_year(self) -> int:
        return self.end_year - self.window_years + 1

    def text(self) -> str:
        what = "overlapping" if self.rule == "overlap" else "starting in"
        return f"CRAG spells {what} {self.first_year}-{self.end_year} ({self.window_years} years)"


def load_episodes(path: str | Path) -> pd.DataFrame:
    """The CRAG episode file with iso (upper), start and end as int; refuses a missing column or end < start."""
    d = pd.read_csv(path, comment="#", dtype={"iso": str})
    missing = {"iso", "start", "end"} - set(d.columns)
    if missing:
        raise CragCountError(f"{Path(path).name}: missing column(s) {sorted(missing)}")
    d = d.dropna(subset=["iso"]).copy()
    d["iso"] = d["iso"].str.upper().str.strip()
    try:
        d["start"] = d["start"].astype(int)
        d["end"] = d["end"].astype(int)
    except (ValueError, TypeError) as e:
        raise CragCountError(f"{Path(path).name}: start/end must be whole years ({e})") from None
    bad = d[d["end"] < d["start"]]
    if len(bad):
        raise CragCountError(f"{Path(path).name}: {len(bad)} spell(s) end before they start, e.g. {bad.iloc[0]['iso']}")
    return d


def load_coverage(path: str | Path) -> dict[str, tuple[int, int]]:
    """iso -> (first_year, last_year) from the CRAG universe file (rows without an ISO code are skipped)."""
    u = pd.read_csv(path, comment="#", dtype={"iso": str})
    missing = {"iso", "first_year", "last_year"} - set(u.columns)
    if missing:
        raise CragCountError(f"{Path(path).name}: missing column(s) {sorted(missing)}")
    u = u.dropna(subset=["iso"])
    return {str(i).upper().strip(): (int(a), int(b)) for i, a, b in zip(u["iso"], u["first_year"], u["last_year"])}


def annual_in_scope(raw_csv: str | Path) -> pd.DataFrame:
    """(iso, year, amt): CRAG's annual in-scope arrears per country (USD m) from the raw BoC-BoE Valet CSV, the sum of
    the ``default_panel.IN_SCOPE`` categories (the amounts the crag_v1 spells are built from). Country rows only (Valet
    key ``XXX_YYYY``). Same result as ``validation.crag_redefaults.annual_in_scope`` (parity tested); kept here so
    ingestion imports nothing above it (ADR-A-001)."""
    from .default_panel import IN_SCOPE, VALET_KEY_RE, VALET_MARKER, canonical_category
    lines = Path(raw_csv).read_text(encoding="utf-8-sig").splitlines()
    try:
        i = next(k for k, ln in enumerate(lines) if ln.strip().strip('"') == VALET_MARKER)
    except StopIteration:
        raise CragCountError(f"{raw_csv}: no {VALET_MARKER} line (not a Valet export)") from None
    df = pd.read_csv(io.StringIO("\n".join(lines[i + 1:])), dtype=str, quoting=csv.QUOTE_MINIMAL)
    kcol = next(c for c in df.columns if c.strip().lower() == "k")
    ycol = next(c for c in df.columns if c.strip().upper().endswith("YEAR"))
    cats = [c for c in df.columns if canonical_category(c) in IN_SCOPE]
    if not cats:
        raise CragCountError(f"{raw_csv}: none of the in-scope categories {sorted(IN_SCOPE)} found")
    df = df[df[kcol].astype(str).str.match(VALET_KEY_RE)]
    amt = df[cats].apply(pd.to_numeric, errors="coerce").fillna(0.0).sum(axis=1)
    out = pd.DataFrame({"iso": df[kcol].str[:3].str.upper(), "year": pd.to_numeric(df[ycol], errors="coerce"), "amt": amt})
    return out.dropna(subset=["year"]).astype({"year": int}).reset_index(drop=True)


def count_episodes(episodes: pd.DataFrame, iso: str, window: CragWindow,
                   coverage: dict[str, tuple[int, int]], *, short_end: str = "refuse",
                   label: str = "rule 1.8 CRAG count (UNAPPROVED)",
                   annual: pd.DataFrame | None = None) -> tuple[float | None, str]:
    """(count, text) for one country. None with the reason when CRAG does not cover the window for it.

    ``short_end``: "refuse" (None when coverage ends before the window end) or "count" (section 16 point 1: count
    what the file has; the text names the last CRAG year). A spell's last default year is ``end_spell`` when the
    episodes are crag_v1 (``apply_cure`` puts the cure years in ``end``), else ``end``: the selection is Team B's
    ``validation.hazard_events.episodes_in_window`` (section 16 point 7), never re-implemented here.

    ``annual`` (``annual_in_scope``; point 3a): when given, the new-default years ``rules.hazard.redefault_years``
    finds inside each counted episode, within the window, are added to the count and listed in the text."""
    if not isinstance(window, CragWindow):
        raise CragCountError("window must be a CragWindow (window_years, end_year, rule; no defaults)")
    if short_end not in ("refuse", "count"):
        raise CragCountError(f"short_end must be 'refuse' or 'count', got {short_end!r}")
    iso = str(iso).upper().strip()
    cov = coverage.get(iso)
    if cov is None:
        return None, f"1.8 not served: {iso} is not in the CRAG coverage file"
    if cov[0] > window.first_year or (cov[1] < window.end_year and short_end == "refuse"):
        return None, (f"1.8 not served: CRAG covers {iso} {cov[0]}-{cov[1]}, "
                      f"not the whole window {window.first_year}-{window.end_year}")
    from ..rules.hazard import episodes_in_window     # Team B's selection (indicator-rules 16 point 7; C15, ADR-A-001)
    g = episodes[episodes["iso"] == iso].reset_index(drop=True)
    spells = episodes_in_window(g, window.first_year, window.end_year, rule=window.rule).sort_values("start")
    ends = spells["end_spell"] if "end_spell" in spells.columns else spells["end"]
    listed = ", ".join(f"{s}" if s == e else f"{s}-{e}" for s, e in zip(spells["start"], ends)) or "none"
    years: list[int] = []
    if annual is not None:
        from ..rules.hazard import redefault_years     # Team B's pure rule 16.3a (C15)
        a = annual[(annual["iso"] == iso) & (annual["year"] <= window.end_year)].set_index("year")["amt"]
        for s, e in zip(spells["start"], ends):
            years += redefault_years(a, int(s), int(e), window.first_year, window.end_year)
        if years:
            listed += f" (+ new defaults {', '.join(map(str, years))})"
    short = f"; crag_last_year {cov[1]} (file ends before the window)" if cov[1] < window.end_year else ""
    n = len(spells) + len(years)
    return float(n), f"{label}: {n} {window.text()}: {listed}{short}"


def approved_window(as_of) -> CragWindow:
    """The section 16 window for an as-of date: 20 years ending in the as-of year minus 1, overlap rule."""
    y = pd.Timestamp(as_of).year
    return CragWindow(window_years=RULE16["window_years"], end_year=y - RULE16["end_offset"], rule=RULE16["rule"])


def crag_v1_episodes(data_dir: str | Path, as_of) -> tuple[pd.DataFrame, dict]:
    """CRAG episodes under Team B's hazard event rule crag_v1 at as_of (validation.hazard_events.build_events with
    RECOMMENDED_RULE): spells rebuilt from the raw BoC-BoE file with the USD 10m floor (the raw file must be the one
    the episode file names), merged, cured, point in time. Delegated, not re-implemented, so 1.8 and the hazard events
    count the same episodes."""
    from ..rules.hazard import RECOMMENDED_RULE
    from ..validation.hazard_events import build_events, resolve   # C15: listed lazy calls (they read files)
    rule = resolve(data_dir, source="crag", min_amount_musd=RECOMMENDED_RULE["min_amount_musd"],
                   cure_years=RECOMMENDED_RULE["cure_years"])
    ev, info = build_events(data_dir, pd.Timestamp(as_of).strftime("%Y-%m-%d"), rule)
    ev = ev.copy()
    ev["iso"] = ev["iso"].astype(str).str.upper().str.strip()
    return ev, info


def rule16_cells(data_dir: str | Path, as_of, countries: list[tuple[str, str]]) -> list[dict]:
    """Section 16 values for [(country, iso), ...]: one dict per country with value (None when not served), text,
    window, crag_last_year and the episode file's provenance. Never writes anything."""
    d = Path(data_dir)
    panel = d / "panel"
    window = approved_window(as_of)
    eps, info = crag_v1_episodes(d, as_of)
    if not info.get("raw"):
        raise CragCountError("rule 16.3a needs the raw BoC-BoE file the crag_v1 episodes were rebuilt from")
    annual = annual_in_scope(info["raw"])
    cov = load_coverage(panel / "sovereign_defaults_crag_universe.csv")
    src = pd.read_csv(panel / "sovereign_defaults_crag.csv", usecols=["source", "source_vintage"])
    sv = ";".join(sorted(set(src["source_vintage"].dropna().astype(str))))
    raw = ";".join(sorted(set(src["source"].dropna().astype(str))))
    out = []
    for country, iso in countries:
        v, text = count_episodes(eps, iso, window, cov, short_end="count", label=f"rule 1.8 CRAG count ({RULE_SOURCE})",
                                  annual=annual)
        c = cov.get(str(iso).upper())
        out.append({"country": country, "iso": str(iso).upper(), "value": v, "text": text,
                    "window": f"{window.first_year}-{window.end_year}", "crag_last_year": c[1] if c else None,
                    "source": raw, "source_vintage": sv, "episodes_rule": info.get("rule"),
                    "raw_sha256": info.get("raw_sha256_actual")})
    return out


def mvp_held_cells(data_dir: str | Path, as_of) -> list[dict]:
    """The 1.8 cells for the MVP dataset (EQ-A-0110): served values held with TIER1_HOLD (the seed stays), countries
    outside coverage as 'missing' with the not-served reason. Seeds from data/indicators.csv row 1.8. ``as_of`` is
    required (ARCH-A-PI10 N4: crag_count never depends on mvp_dataset)."""
    if as_of is None:
        raise CragCountError("as_of is required (the MVP vintage's as-of date)")
    d = Path(data_dir)
    ind = pd.read_csv(d / "indicators.csv", dtype=str, keep_default_na=False)
    seed_row = ind[ind["id"] == INDICATOR]
    seeds = seed_row.iloc[0].to_dict() if len(seed_row) else {}
    cty = pd.read_csv(d / "countries.csv", dtype=str, keep_default_na=False)
    rows = []
    for r in rule16_cells(d, as_of, list(zip(cty["country"], cty["iso"]))):
        cell = {"table": "Inputs", "key": INDICATOR, "country": r["country"], "seed": seeds.get(r["country"], "")}
        if r["value"] is None:
            rows.append({**cell, "value": None, "outcome": "missing", "reason": f"{r['text']}; seed stays (indicator-rules 16 point 5)"})
        else:
            rows.append({**cell, "value": r["value"], "outcome": "held",
                         "reason": f"{TIER1_HOLD}: {r['text']}; source {r['source']} (vintage {r['source_vintage']})"})
    return rows
