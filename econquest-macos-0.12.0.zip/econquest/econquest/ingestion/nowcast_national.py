"""National nowcast sources: free official monthly / quarterly series from central banks and statistics offices
(EQ-A-0119), for the nowcast series map (nowcast_feed, data/live/nowcast_series_map.csv).

Why: the map's 17 rows are IMF, OECD and BIS only; IMF data is internal research use only, and GDP, IP and credit
have no code at all. These adapters add single-country sources that publish without a key:

    source     serves  publisher / API                                   response
    bcb_sgs    BRA     Banco Central do Brasil, SGS (api.bcb.gov.br)      JSON [{"data": "dd/MM/yyyy", "valor": "x"}]
    bcrp       PER     Banco Central de Reserva del Peru, BCRPData        JSON {"periods": [{"name": "Ago.2026",
                       (estadisticas.bcrp.gob.pe)                              "values": ["x"]}]}
    datos_ar   ARG     Argentina series API, datos.gob.ar                 JSON {"data": [["YYYY-MM-DD", x]],
                       (apis.datos.gob.ar; INDEC and other publishers)        "meta": [{...}, {"field": {"id": ...}}]}
    dosm       MYS     Department of Statistics Malaysia, OpenDOSM        JSON [{"date": "YYYY-MM-DD", <dims>, <value>}]
                       (api.data.gov.my data catalogue)

bcb_sgs and bcrp reuse the URL builders and parsers of official.central_banks (APIS), so a fix there fixes both.
Not here, and why: ECB (euro area series only; none of the 25 names is in the euro area), Banxico / BCCh / BoK ECOS
(need a registered key or user: possible later through the keychain, as official.central_banks does), INEGI, e-Stat,
BPS (keyed), and every name with no documented machine API (official.central_banks._MANUAL_ONLY).

Map rows (source = a key of NATIONAL): `key` is empty; `filters` carries the codes, so a blank `filters` still means
"not configured, never requested":
    bcb_sgs, bcrp, datos_ar   SERIES=<series code>
    dosm                      DATASET=<catalogue id>;VALUE=<value field>[;<dimension>=<code> ...]
`flow` is a label only (the publisher's dataset name). Every code is UNVERIFIED (written from the publishers' API
documentation as remembered; this cloud cannot reach any of these hosts) and every row ships verified=no, so nothing
reaches nowcast_inputs.csv until the Mac probe and `map-set ... --verified yes`.

Answers are refused, never guessed: an answer that names another series (datos_ar meta id, dosm dimension values), two
values for one period, an unreadable date or a period of another frequency raise FeedError for that request. Empty or
non-numeric values are skipped, never filled. Transport is sources.https_get (https only, redirects refused, body
capped) with the feeds retry and fail-fast rules, as the SDMX adapters.

Licences: every raw row carries the source's LICENCE text, which starts "national nowcast <source>:" and says
"internal research use only" (tighten-only default until Sam reads the terms; the register rows nowcast_<source> in
data/licences.csv match it). The provenance source starts "national: ", so audit.client_output_reason also keeps it
out of client output through the national rule."""
from __future__ import annotations

import datetime as dt
import urllib.error
import urllib.parse
from dataclasses import dataclass, field
from typing import Callable, Iterable

import pandas as pd

from . import feeds as F
from .official import central_banks as CB
from .official.sdmx import RAW_COLUMNS, SeriesSpec
from .sources import https_get

NATIONAL_MAX_BYTES = 20 * 1024 * 1024
HISTORY_YEARS = 7                     # 36 months of y/y need 48 months of levels; 7 years leaves room for revisions
_TERMS = "terms UNVERIFIED; internal research use only until Sam reads them (EQ-A-0119 tighten-only default)"


@dataclass(frozen=True)
class NationalSource:
    name: str
    iso3: str
    label: str
    host: str
    licence: str
    api: str = ""                    # official.central_banks.APIS entry reused for URL and parser ('' = own parser)
    endpoint: str = ""              # documented pattern, placeholders only


NATIONAL = {s.name: s for s in (
    NationalSource("bcb_sgs", "BRA", "BCB SGS", "api.bcb.gov.br",
                   f"national nowcast bcb_sgs: Banco Central do Brasil open data (dadosabertos.bcb.gov.br); {_TERMS}",
                   api="bcb_sgs", endpoint=CB.ENDPOINTS["bcb_sgs"]),
    NationalSource("bcrp", "PER", "BCRPData", "estadisticas.bcrp.gob.pe",
                   f"national nowcast bcrp: Banco Central de Reserva del Peru, BCRPData API; {_TERMS}",
                   api="bcrp", endpoint=CB.ENDPOINTS["bcrp"]),
    NationalSource("datos_ar", "ARG", "datos.gob.ar series API", "apis.datos.gob.ar",
                   f"national nowcast datos_ar: Argentina open data series API (datos.gob.ar; the publisher of each "
                   f"series, e.g. INDEC, is named in its metadata); {_TERMS}",
                   endpoint="https://apis.datos.gob.ar/series/api/series/?ids={id}&format=json&start_date={start}"
                            "&limit=1000"),
    NationalSource("dosm", "MYS", "OpenDOSM", "api.data.gov.my",
                   f"national nowcast dosm: Department of Statistics Malaysia, OpenDOSM / data.gov.my API; {_TERMS}",
                   endpoint="https://api.data.gov.my/data-catalogue?id={dataset}&filter={code}@{dimension}"),
)}
HOSTS = {n: s.host for n, s in NATIONAL.items()}
LICENCES = {n: s.licence for n, s in NATIONAL.items()}
SOURCE_PREFIX = CB.SOURCE_PREFIX                     # "national: "
DOSM_RESERVED = ("DATASET", "VALUE")


def source_text(name: str) -> str:
    s = NATIONAL[name]
    return f"{SOURCE_PREFIX}{s.label} ({s.host})"


# ---------------------------------------------------------------------------------------------- map rows
def check_row(r: dict) -> list[str]:
    """Problems with one map row of a national source (empty = usable). Blank filters = not configured: fine."""
    mid, src = r.get("map_id", "?"), r.get("source", "")
    probs = []
    if str(r.get("key", "")).strip():
        probs.append(f"{mid}: {src} rows take no key (the codes go in filters)")
    text = str(r.get("filters", "")).strip()
    if not text:
        return probs
    dims = dict(p.split("=", 1) for p in text.split(";") if "=" in p)
    if src == "dosm":
        miss = [d for d in DOSM_RESERVED if not dims.get(d, "").strip()]
        if miss:
            probs.append(f"{mid}: dosm filters need {' and '.join(miss)}")
    elif set(dims) != {"SERIES"}:
        probs.append(f"{mid}: {src} filters must be exactly SERIES=<code>")
    return probs


def _dims(spec: SeriesSpec) -> dict:
    return {d: c for d, c in (spec.filters or ())}


# ---------------------------------------------------------------------------------------------- parsers
def _period(d: dt.date, freq: str) -> str:
    return CB._period(d, freq)


def _check_freq(rows: list[tuple[str, float]], freq: str, label: str) -> list[tuple[str, float]]:
    import re
    pat = {"M": r"\d{4}-(0[1-9]|1[0-2])", "Q": r"\d{4}-Q[1-4]"}[freq]
    bad = [p for p, _ in rows if not re.fullmatch(pat, p)]
    if bad:
        raise F.FeedError(f"{label}: period {bad[0]!r} is not {freq}; answer refused")
    return rows


def parse_datos_ar(body: bytes, code: str, freq: str) -> list[tuple[str, float]]:
    """datos.gob.ar series API JSON for one id: data [[date, value]], meta[1].field.id must be the id asked."""
    lab = f"datos.gob.ar {code}"
    data = CB._json(body, lab)
    if not isinstance(data, dict) or not isinstance(data.get("data"), list):
        raise F.FeedError(f"{lab}: no data list ({str(data)[:120]})")
    meta = data.get("meta")
    ids = [m.get("field", {}).get("id") for m in meta[1:]] if isinstance(meta, list) else []
    if ids != [code]:
        raise F.FeedError(f"{lab}: answer names series {ids!r}, asked {code!r}; refused")
    out = []
    for row in data["data"]:
        if not isinstance(row, list) or len(row) != 2:
            raise F.FeedError(f"{lab}: row {str(row)[:60]} is not [date, value] (one series asked); refused")
        try:
            d = dt.date.fromisoformat(str(row[0])[:10])
        except ValueError as e:
            raise F.FeedError(f"{lab}: unreadable date {row[0]!r}") from e
        v = CB._num(row[1])
        if v is not None:
            out.append((_period(d, freq), v))
    return CB._obs(out, lab)


def parse_dosm(body: bytes, dims: dict, freq: str) -> list[tuple[str, float]]:
    """OpenDOSM data-catalogue JSON: a list of records with 'date', the value field dims['VALUE'] and dimension
    fields. Every record must carry every requested dimension with the requested code."""
    lab = f"OpenDOSM {dims.get('DATASET')}"
    data = CB._json(body, lab)
    if isinstance(data, dict):
        raise F.FeedError(f"{lab}: error answer {str(data)[:120]}")
    if not isinstance(data, list):
        raise F.FeedError(f"{lab}: not a list of records")
    want = {d: c for d, c in dims.items() if d not in DOSM_RESERVED}
    value = dims["VALUE"]
    out = []
    for r in data:
        if not isinstance(r, dict):
            raise F.FeedError(f"{lab}: record {str(r)[:60]} is not an object")
        for d, c in want.items():
            if str(r.get(d, "")).strip() != c:
                raise F.FeedError(f"{lab}: record with {d}={r.get(d)!r} (asked {c!r}); answer refused")
        if value not in r:
            raise F.FeedError(f"{lab}: no field {value!r} in the records; answer refused")
        try:
            d = dt.date.fromisoformat(str(r.get("date", ""))[:10])
        except ValueError as e:
            raise F.FeedError(f"{lab}: unreadable date {r.get('date')!r}") from e
        v = CB._num(r[value])
        if v is not None:
            out.append((_period(d, freq), v))
    return CB._obs(out, lab)


def parse(source: str, body: bytes, spec: SeriesSpec) -> list[tuple[str, float]]:
    """(period, value) rows of one answer for one map row of `source`."""
    s, dims = NATIONAL[source], _dims(spec)
    if s.api:
        cbs = CB.CbSeries(s.iso3, "nowcast", s.label, s.api, dims["SERIES"], spec.freq, "", s.endpoint, s.licence)
        rows = CB.APIS[s.api].parse(body, cbs)
    elif source == "datos_ar":
        rows = parse_datos_ar(body, dims["SERIES"], spec.freq)
    else:
        rows = parse_dosm(body, dims, spec.freq)
    return _check_freq(rows, spec.freq, f"{s.label} {spec.describe()}")


def url(source: str, spec: SeriesSpec, start: dt.date, end: dt.date) -> str:
    s, dims = NATIONAL[source], _dims(spec)
    if s.api:
        cbs = CB.CbSeries(s.iso3, "nowcast", s.label, s.api, dims["SERIES"], spec.freq, "", s.endpoint, s.licence)
        return CB.APIS[s.api].url(cbs, start, end, {})
    if source == "datos_ar":
        return ("https://apis.datos.gob.ar/series/api/series/?" + urllib.parse.urlencode(
            {"ids": dims["SERIES"], "format": "json", "start_date": start.isoformat(), "limit": 1000}))
    filt = ",".join(f"{c}@{d}" for d, c in dims.items() if d not in DOSM_RESERVED)
    q = {"id": dims["DATASET"], **({"filter": filt} if filt else {})}
    return "https://api.data.gov.my/data-catalogue?" + urllib.parse.urlencode(q)


# ---------------------------------------------------------------------------------------------- the feed
@dataclass
class NationalNowcastFeed:
    """One national source for nowcast_feed.fetch: the same interface as official.sdmx.SdmxFeed (fetch(isos) ->
    RAW_COLUMNS frame with attrs failures / unconfigured). Serves only NATIONAL[source].iso3."""
    source: str
    registry: dict = field(default_factory=dict)
    timeout: float = 30.0
    retries: int = 3
    backoff: float = 2.0
    sleep: Callable[[float], None] | None = None
    max_bytes: int = NATIONAL_MAX_BYTES
    today: dt.date | None = None
    get: Callable[[str], bytes] | None = None        # tests: a recorded-fixture transport

    @property
    def label(self) -> str:
        return NATIONAL[self.source].label

    def host(self) -> str:
        return NATIONAL[self.source].host

    def _get(self, u: str) -> bytes:
        if not u.startswith(f"https://{self.host()}/"):
            raise ValueError(f"{self.label}: refusing a request outside https://{self.host()}/")
        if self.get is not None:
            return self.get(u)
        return https_get(u, {"User-Agent": "econquest/0.2", "Accept": "application/json"}, timeout=self.timeout,
                         max_bytes=self.max_bytes)

    def _get_retry(self, u: str) -> bytes:
        try:
            return F._with_retries(lambda: self._get(u), retries=self.retries, backoff=self.backoff, sleep=self.sleep)
        except Exception as e:  # noqa: BLE001 - classified, then re-raised as it was
            F._stop_if_unreachable(e, self.host())
            raise

    def fetch(self, isos: Iterable[str]) -> pd.DataFrame:
        s = NATIONAL[self.source]
        failures: list[str] = []
        unconfigured = sorted(n for n, sp in self.registry.items() if not sp.configured)
        if unconfigured:
            failures.append(f"{self.label}: not configured (codes unknown, not requested): {', '.join(unconfigured)}")
        rows: list[dict] = []
        if s.iso3 in set(isos):
            end = self.today or dt.datetime.now(dt.timezone.utc).date()
            start = dt.date(end.year - HISTORY_YEARS, 1, 1)
            for spec in (sp for sp in self.registry.values() if sp.configured):
                u = url(self.source, spec, start, end)
                try:
                    body = self._get_retry(u)
                except F.FeedUnreachable:
                    raise
                except urllib.error.HTTPError as e:
                    failures.append(f"{self.label} {spec.name}: HTTP {e.code}")
                    continue
                except Exception as e:  # noqa: BLE001
                    failures.append(f"{self.label} {spec.name}: {type(e).__name__}: {str(e)[:100]}")
                    continue
                try:
                    obs = parse(self.source, body, spec)
                except F.FeedError as e:
                    failures.append(F._one_line(e, 200))
                    continue
                for p, v in obs:
                    rows.append({"iso": s.iso3, "series": spec.name, "period": p, "value": float(v),
                                 "source": source_text(self.source), "sdmx_key": f"{s.label} {spec.describe()}",
                                 "unit_mult": 0, "licence": s.licence})
        else:
            failures.append(f"{self.label}: serves {s.iso3} only, not among the names asked")
        out = pd.DataFrame(rows, columns=RAW_COLUMNS)
        if out.empty:
            raise F.FeedError(f"{self.label}: no rows: " + "; ".join(failures[:3]))
        out.attrs.update(failures=failures, unconfigured=unconfigured)
        return out.reset_index(drop=True)
