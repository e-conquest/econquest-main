"""ETL: assemble the snapshot (or live) tables into one validated `Universe`."""
from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
import pandas as pd
from .sources import CsvSource, PolymarketSource, KalshiSource

YES_NO = ("default", "extarrears", "exprop", "coup", "nopay", "bankcrisis", "emergency", "disaster",
          "CDS", "Eurobond", "FX", "FX options", "Local rates", "Equity")


@dataclass
class Universe:
    countries: pd.DataFrame          # one row per country (Country Profile + stress helpers)
    indicators: pd.DataFrame         # 83 rows x countries, raw indicator values
    rulebook: pd.DataFrame           # 83 rows: weights, thresholds, directions
    adjustments: pd.DataFrame        # trigger add-ons, analyst adjustments, override floors
    portfolio: pd.DataFrame          # positions
    markets: pd.DataFrame            # prediction-market contracts
    provenance: dict = field(default_factory=dict)
    gpr: pd.DataFrame | None = None          # monthly GPR table (optional)
    playbook: pd.DataFrame | None = None     # trading strategies and their signal rules (optional)
    weo_raw: pd.DataFrame | None = None      # data/live/raw_weo.csv when a live pull exists (history for the hazard predictors)
    prices: pd.DataFrame | None = None       # data/market_history/prices.csv (daily FX and ETF closes) when present; feeds the HMM regimes
    wb_raw: pd.DataFrame | None = None       # data/live/raw_worldbank_history.csv (iso, series, period, value, source): WB history from 1996 for layer 1 (HO-20261023-B-A-006); current WB database, not point in time
    events: pd.DataFrame | None = None       # data/live/events/events_long.csv via events.export.load_events_long (HO-20261023-B-A-004)

    @property
    def names(self) -> list[str]:
        return list(self.countries["country"])

    def validate(self) -> list[str]:
        problems = []
        names = self.names
        if len(names) != len(set(names)):
            problems.append("duplicate country names")
        missing = [c for c in names if c not in self.indicators.columns]
        if missing:
            problems.append(f"indicator table lacks columns for {missing}")
        if set(self.rulebook["id"]) != set(self.indicators["id"]):
            problems.append("rulebook and indicator ids differ")
        bad = self.portfolio[~self.portfolio["country"].isin(names)]
        if len(bad):
            problems.append(f"positions on unknown countries: {list(bad['id'])}")
        w = self.rulebook.groupby("pillar")["weight"].sum()
        off = w[(w - 1).abs() > 1e-6]
        if len(off):
            problems.append(f"pillar weights do not sum to 1: {off.to_dict()}")
        return problems


def _blank_yes_no(df: pd.DataFrame) -> dict[str, list[str]]:
    """{country: [YES_NO column, ...]} for the Yes/No cells that are blank (NaN or only spaces) before `_yes_no`
    turns them into False (HO-20261023-B-A-007). Only countries with at least one blank."""
    cols = [c for c in YES_NO if c in df.columns]
    out = {}
    for r in df.to_dict("records"):
        blank = [c for c in cols if r[c] is None or (isinstance(r[c], float) and r[c] != r[c]) or (isinstance(r[c], str) and not r[c].strip())]
        if blank:
            out[str(r.get("country"))] = blank
    return out


def _yes_no(df: pd.DataFrame) -> pd.DataFrame:
    for c in YES_NO:
        if c in df.columns:
            df[c] = df[c].astype(str).str.strip().str.lower().eq("yes")
    return df


def load_universe(data_dir: str | Path, live_markets: bool = False, vintage: str | None = None) -> Universe:
    """Load and validate the inputs under data_dir. With `vintage` (a vintage id, or a date for that day's latest),
    the Team A inputs frozen when that vintage was applied are verified and materialized into a temporary data
    directory (`replay.materialize_vintage`) and the universe is loaded from there; provenance["replay"] records the
    vintage id, inputs_hash and any drift in other teams' files. Raises FileNotFoundError when the vintage has no
    frozen inputs and replay.VintageIntegrityError when the snapshot fails verification (never falls back)."""
    if vintage is not None:
        import tempfile
        from .replay import materialize_vintage
        with tempfile.TemporaryDirectory(prefix="econquest-replay-") as td:
            rm = materialize_vintage(data_dir, vintage, Path(td) / "data")
            u = load_universe(Path(td) / "data", live_markets=live_markets)
        u.provenance["replay"] = {k: rm[k] for k in ("vintage_id", "snapshot", "inputs_hash", "frozen_data_hash", "drift", "drift_in_data_hash")}
        u.provenance["replay"]["source_data_dir"] = str(Path(data_dir))
        from ..versioning import with_replay
        u.provenance["versions"] = with_replay(u.provenance.get("versions"), u.provenance["replay"])  # HO-20261023-C-A-003
        return u
    d = Path(data_dir)
    countries = CsvSource(d / "countries.csv").fetch()
    blank_yes_no = _blank_yes_no(countries)          # before _yes_no reads a blank as "No" (HO-20261023-B-A-007)
    countries = _yes_no(countries)
    indicators = CsvSource(d / "indicators.csv").fetch()
    indicators["id"] = indicators["id"].astype(str)
    rulebook = CsvSource(d / "rulebook.csv").fetch()
    rulebook["id"] = rulebook["id"].astype(str)
    adjustments = CsvSource(d / "adjustments.csv").fetch()
    portfolio = CsvSource(d / "portfolio.csv").fetch()
    markets = CsvSource(d / "prediction_markets.csv").fetch()
    prov = {k: v.attrs.get("source") for k, v in dict(countries=countries, indicators=indicators, rulebook=rulebook,
                                                         adjustments=adjustments, portfolio=portfolio, markets=markets).items()}
    prov["blank_yes_no"] = blank_yes_no
    if live_markets:
        poly = PolymarketSource(markets[markets["platform"].str.lower() == "polymarket"]).fetch()
        kal = KalshiSource(markets[markets["platform"].str.lower() == "kalshi"]).fetch()
        markets = pd.concat([poly, kal]).sort_index()
        prov["markets"] = f"{poly.attrs['source']}; {kal.attrs['source']}"
    for c in ("yes_price", "open_interest_k"):
        markets[c] = pd.to_numeric(markets[c], errors="coerce")
    markets["resolution_date"] = pd.to_datetime(markets["resolution_date"], errors="coerce")
    gpr = CsvSource(d / "gpr_monthly.csv").fetch() if (d / "gpr_monthly.csv").exists() else None
    playbook = None
    if (d / "playbook.csv").exists():
        playbook = pd.read_csv(d / "playbook.csv", dtype={"id": str, "rule2": str, "instrument": str})
        prov["playbook"] = "csv:playbook.csv"
    if gpr is not None:
        prov["gpr"] = "csv:gpr_monthly.csv"
    from ..versioning import stamp
    prov["versions"] = stamp(d)
    weo_raw = None
    if (d / "live" / "raw_weo.csv").exists():
        weo_raw = pd.read_csv(d / "live" / "raw_weo.csv", dtype={"iso": str, "series": str})
        weo_raw["period"] = pd.to_numeric(weo_raw["period"], errors="coerce")
        prov["weo_raw"] = "csv:live/raw_weo.csv"
    prices = None
    if (d / "market_history" / "prices.csv").exists():
        prices = pd.read_csv(d / "market_history" / "prices.csv", parse_dates=["date"], index_col="date")
        prov["prices"] = "csv:market_history/prices.csv"
    wb_raw = None
    if (d / "live" / "raw_worldbank_history.csv").exists():
        wb_raw = pd.read_csv(d / "live" / "raw_worldbank_history.csv", dtype={"iso": str, "series": str}, keep_default_na=False, na_values=[""])
        wb_raw["period"] = pd.to_numeric(wb_raw["period"], errors="coerce")
        wb_raw["value"] = pd.to_numeric(wb_raw["value"], errors="coerce")
        prov["wb_raw"] = "csv:live/raw_worldbank_history.csv"
    from .events.export import load_events_long      # lazy: the events package imports ingestion.ledger
    events = load_events_long(d)
    if events is not None:
        prov["events"] = "csv:live/events/events_long.csv"
    u = Universe(countries, indicators, rulebook, adjustments, portfolio, markets, prov, gpr, playbook, weo_raw, prices, wb_raw, events)
    problems = u.validate()
    if problems:
        raise ValueError("universe failed validation: " + "; ".join(problems))
    return u
