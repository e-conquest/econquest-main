"""Client-safe dataset (EQ-A-0124): a variant of data/mvp with every client-restricted cell withheld, built once per
answer to Sam's IMF-WDI question (D3), side by side, without changing data/, data/mvp or the imf_via_wdi row.

    python -m econquest.ingestion.client_safe_dataset build --d3 both
    python -m econquest.ingestion.client_safe_dataset verify --d3 both
    python -m econquest.ingestion.client_safe_dataset compare

How a variant is built (nothing is fetched, nothing is invented):
1. data/mvp is verified (mvp_dataset.verify) and its data directory copied to a private work folder.
2. D3 is simulated on the COPY of the register only: client_safe_route.d3_patch(answer) is applied to the copy's
   licences.csv ("yes": client_output allowed; "no": match_series widened to D3_STRICT_SERIES). data/licences.csv is
   never written. While the variant is built, every licence hook reads that copy ($ECONQUEST_LICENCE_REGISTER and
   licences.use_register, restored afterwards).
3. Withheld cells: Team B's one rule, validation.client_safe.withheld_cells (ops.licence_rule.evaluate internal_only,
   Team C's enforcement), through Team B's own build_client_safe_copy, which also leaves out restricted files and
   EXC-005 price columns. The same withheld set is checked cell by cell against Team B's plan.
4. Replacements: Team B's fallbacks (plan_replacements, route off), then Team A's route (client_safe_route.apply_route
   on client_safe_values). Under "yes" the route's conditional steps (IMF-compiled WDI) count, as d3_report computes
   them; under "no" only cleared steps do. A cell with no cleared value keeps Team B's labelled placeholder (rulebook
   midpoint t50 for a required input, reserves 15% of GDP, HO-20261026-A-B-001) or is blank, with the reason.
5. Checks, all required (the build refuses otherwise and says which cells):
   - 0 restricted rows in shipped raw files (e.g. live/raw_worldbank.csv), judged row by row on source / series
     (SEC-A-014 P2-M1; Team B's file_decision is path-only, so such rows are dropped here first);
   - 0 restricted cells: audit.restricted_source_cells and audit.client_restricted_cells (client_output_reason) on
     the variant's values, against every record data/mvp has (audit_trail.csv, live/provenance.csv) plus the route's
     own records, under the simulated register; and every cell Team A's audit restricts in data/mvp is in the
     withheld set (Team A's rule and Team B / C's rule agree);
   - quality gate: gate_report.json recounted, 0 unexplained (every held, missing, withheld and blank cell has a
     reason), and ops.demo.probe_gate on the variant with its gate review: 0 unexplained;
   - the variant loads (load_universe) and passes scorecard readiness. If it does not (e.g. D3 "no" with no reserves
     fallback), the build stops and names the fields and the withheld cells behind them.

Output, one folder per answer under --out-root (default outputs/client_safe_dataset, never inside data/)::

    d3_<answer>/data/              the client-safe data directory (Team B's copy plus route values, raw-file rows
                                   filtered by series), read-only
    d3_<answer>/data/client_safe.json  INTERNAL marker: internal_only (true until Sam's approved register carries the
                                   D3 answer), the notice, the placeholder cells; travels with a copied data/
    d3_<answer>/provenance.csv     one row per indicators.csv / countries.csv cell: value, label, source, reason
    d3_<answer>/withheld.csv       the withheld cells: register row, component, reason, fallback, replacement, new
                                   value (never the restricted value)
    d3_<answer>/replacements.csv  one record per replacement value (route, recomputed, official, placeholder): label,
                                   source, series, as_of; what ties each new value to its non-IMF origin
    d3_<answer>/gate_review.csv    data/mvp's gate review without the withheld cells (what probe_gate reads)
    d3_<answer>/gate_report.json   every review, withheld and blank cell with its outcome and reason
    d3_<answer>/licences_d3_<answer>.csv  the simulated register (a copy; INTERNAL, not data/licences.csv)
    d3_<answer>/manifest.json      sha256 per file, dataset_sha256, data/mvp's sha, counts, check results, caveats
    comparison.md / comparison_cells.csv   the two answers side by side (compare)

INTERNAL: the register has no approved version yet (no_baseline), so these variants do not clear any output for
clients; real client output still needs Sam's baseline and D3 answer through `econquest change`.
"""
from __future__ import annotations

import argparse
import contextlib
import csv
import datetime as dt
import hashlib
import io
import json
import math
import os
import shutil
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
TICKET = "EQ-A-0124"
SCHEMA = "econquest-client-safe-dataset/1"
ANSWERS = ("yes", "no")
OUT_ROOT = Path("outputs/client_safe_dataset")
INTERNAL_NOTICE = ("INTERNAL: simulated D3 answer on a copy of the licence register (no approved register yet); "
                   "not cleared for client output until Sam baselines the register and answers D3 (econquest change)")
LABELS = ("live", "seed", "route", "recomputed", "official", "placeholder", "blank")
PROV_FIELDS = ["table", "key", "country", "value", "label", "source", "register_id", "reason"]
WITHHELD_FIELDS = ["table", "key", "country", "register_id", "component", "reason", "fallback", "label", "new_value",
                   "replacement"]
ROUTE_PROV_FIELDS = ["table", "key", "country", "value", "source", "series", "retrieved"]
REPL_FIELDS = ROUTE_PROV_FIELDS + ["label"]
PLACEHOLDER_SOURCE = "econquest client-safe placeholder (EQ-A-0124, Team B fallback): "
TABLE_FILE = {"Inputs": "indicators.csv", "Country Profile": "countries.csv"}
MARKER = "client_safe.json"
FX3M_PLACEHOLDER_FALLBACK = "judgement placeholder: fx3m (stressed)"     # Team B FALLBACK_KINDS, HO-20261026-B-A-006


class ClientSafeError(RuntimeError):
    """A variant cannot be built or does not verify. The message names the cells."""


# ------------------------------------------------------------------------------------------------ small helpers

def _sha(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


def _csv_text(fields: list[str], rows: list[dict]) -> str:
    buf = io.StringIO()
    w = csv.DictWriter(buf, fieldnames=fields, lineterminator="\n", extrasaction="ignore")
    w.writeheader()
    w.writerows(rows)
    return buf.getvalue()


def _read_csv(p: Path) -> tuple[list[str], list[dict]]:
    with open(p, newline="", encoding="utf-8") as f:
        r = csv.DictReader(f)
        return list(r.fieldnames or []), list(r)


def _num(v) -> float:
    try:
        x = float(str(v).strip())
    except (TypeError, ValueError):
        return float("nan")
    return x if math.isfinite(x) else float("nan")


def _fmt(v) -> str:
    x = _num(v)
    return "" if not math.isfinite(x) else repr(x)


def label_of(fallback: str) -> str:
    """Provenance label of a withheld cell from Team B's fallback kind (validation.client_safe.FALLBACK_KINDS) or the
    route's (client_safe_route.ROUTE_FALLBACK)."""
    from .official.client_safe_route import ROUTE_FALLBACK
    f = str(fallback or "")
    if f == ROUTE_FALLBACK:
        return "route"
    if f.startswith("recomputed") or f.startswith("World Bank"):
        return "recomputed"
    if f.startswith("official"):
        return "official"
    if f == "blank":
        return "blank"
    if f.startswith("judgement placeholder") or f.startswith("0.0") or f == "judgement equity vol":
        return "placeholder"
    if f.startswith("analyst seed"):
        return "seed"
    return ""


def default_out_root(root: Path = ROOT) -> Path:
    return Path(root) / OUT_ROOT


def _check_out_root(out_root: Path, root: Path) -> Path:
    o = Path(out_root).resolve()
    # SEC-A-014 P2-L2: the real data/ of this econquest folder too, whatever --root says
    for data in {(Path(root) / "data").resolve(), (ROOT / "data").resolve()}:
        if o == data or data in o.parents:
            raise ClientSafeError(f"--out-root {out_root} is inside data/: client-safe variants go in their own "
                                  "folder (data/ and data/mvp must not move; default outputs/client_safe_dataset)")
    return o


def _rmtree(p: Path) -> None:
    # SEC-A-014 P2-L3: a link planted at d3_<answer> or .old-* is removed itself; its target is never touched
    # (mvp_dataset._rmtree would chmod the whole target tree, e.g. data/mvp, writable before failing on the link)
    if Path(p).is_symlink():
        Path(p).unlink()
        return
    from .mvp_dataset import _rmtree as rm
    rm(p)


# ------------------------------------------------------------------------------------------------ the register copy

def patch_register(path: Path, answer: str) -> dict:
    """Apply client_safe_route.d3_patch(answer) to the register file at `path` (a COPY; never data/licences.csv).
    Returns the patch. Only the named cells change."""
    from .official.client_safe_route import D3_ROW, d3_patch
    p = Path(path)
    if p.resolve() == (ROOT / "data" / "licences.csv").resolve():
        raise ClientSafeError("refusing to patch data/licences.csv: D3 is simulated on a copy of the register only")
    patch = d3_patch(answer)
    fields, rows = _read_csv(p)
    hit = [r for r in rows if r.get("source_id") == D3_ROW]
    if len(hit) != 1:
        raise ClientSafeError(f"register copy has {len(hit)} {D3_ROW} rows: the D3 switch (EQ-A-0117) is not installed")
    for ptr, value in patch.items():
        _, row_id, col = ptr.split("/")
        if col not in fields:
            raise ClientSafeError(f"register has no column {col}")
        hit[0][col] = value
    p.write_text(_csv_text(fields, rows), encoding="utf-8")
    return patch


@contextlib.contextmanager
def simulated_register(path: Path):
    """Every licence hook reads `path` inside the block: Team A's resolver (licences.use_register) and Team C's
    enforcement, which reads $ECONQUEST_LICENCE_REGISTER while the data folder has no approved version. Both restored
    on exit."""
    from . import licences as LIC
    name = LIC.REGISTER_ENV
    before = os.environ.get(name)
    os.environ[name] = str(Path(path).resolve())
    try:
        with LIC.use_register(path=path):
            yield Path(path)
    finally:
        if before is None:
            os.environ.pop(name, None)
        else:
            os.environ[name] = before


# ------------------------------------------------------------------------------------------------ checks

def _cells_of(df) -> set:
    return {(r.table, str(r.key), r.country) for r in df.itertuples(index=False)}


def _evidence_dir(tmp: Path, data: Path, mvp_data: Path, route_rows: list[dict], name: str = "evidence") -> Path:
    """A folder for audit.restricted_source_cells / client_restricted_cells: the variant's tables and every record
    data/mvp holds (audit_trail.csv, live/provenance.csv), plus the route's own records."""
    e = tmp / name
    (e / "live").mkdir(parents=True)
    for rel in ("indicators.csv", "countries.csv"):
        shutil.copyfile(data / rel, e / rel)
    shutil.copyfile(mvp_data / "audit_trail.csv", e / "audit_trail.csv")
    if (mvp_data / "panel" / "cb_series_verified.csv").is_file():
        (e / "panel").mkdir()
        shutil.copyfile(mvp_data / "panel" / "cb_series_verified.csv", e / "panel" / "cb_series_verified.csv")
    fields, prov = _read_csv(mvp_data / "live" / "provenance.csv")
    (e / "live" / "provenance.csv").write_text(_csv_text(fields or ROUTE_PROV_FIELDS,
                                                         prov + [{k: r[k] for k in ROUTE_PROV_FIELDS} for r in route_rows]),
                                               encoding="utf-8")
    return e


def _gate_dir(tmp: Path, data: Path, review_rows: list[dict], review_fields: list[str], prov_rows: list[dict]) -> Path:
    """The variant's data with its gate review and live provenance, for ops.demo.probe_gate."""
    g = tmp / "gate"
    shutil.copytree(data, g)
    for p in g.rglob("*"):
        os.chmod(p, 0o755 if p.is_dir() else 0o644)
    (g / "live").mkdir(exist_ok=True)
    (g / "live" / "review.csv").write_text(_csv_text(review_fields, review_rows), encoding="utf-8")
    (g / "live" / "provenance.csv").write_text(_csv_text(ROUTE_PROV_FIELDS, prov_rows), encoding="utf-8")
    return g


def readiness(data: Path) -> tuple[bool, str, dict]:
    """(ok, message, {country: [missing fields]}) of scorecard readiness on the variant's data directory."""
    from ..config import Settings
    from ..scorecard.readiness import check_readiness
    from .loaders import load_universe
    u = load_universe(Path(data))                      # no chdir: the cwd is process-wide (ARCH-A-PI12)
    r = check_readiness(u, Settings.load(Path(data) / "assumptions.json"))
    return bool(r.ok), (r.message(len(u.names)) if not r.ok else "ready"), dict(r.missing)


def _series_files(data: Path) -> list[Path]:
    """Shipped CSV files with a `series` column (raw long files such as live/raw_worldbank.csv)."""
    out = []
    for p in sorted(Path(data).rglob("*.csv")):
        if p.is_symlink() or not p.is_file():
            continue
        with open(p, newline="", encoding="utf-8") as f:
            head = next(csv.reader(f), [])
        if "series" in head:
            out.append(p)
    return out


def restricted_raw_rows(data: Path) -> dict:
    """SEC-A-014 P2-M1: rows of shipped raw files whose own source / series the register in force keeps out of client
    output (audit.client_output_reason, row by row; a path-level register row can clear a file whose rows are
    IMF-compiled, e.g. FI.RES.TOTL.CD under D3 "no"). Call inside simulated_register. {rel path: {series: rows}}."""
    from .audit import client_output_reason
    out, memo = {}, {}
    for p in _series_files(data):
        _, rows = _read_csv(p)
        for r in rows:
            k = (r.get("source", ""), r.get("series", ""))
            if k not in memo:
                memo[k] = client_output_reason(source=k[0], series=k[1]) is not None
            if memo[k]:
                d = out.setdefault(p.relative_to(data).as_posix(), {})
                d[k[1]] = d.get(k[1], 0) + 1
    return out


def drop_restricted_raw_rows(data: Path) -> dict:
    """Remove the rows restricted_raw_rows finds (call inside simulated_register). Returns what was dropped."""
    bad = restricted_raw_rows(data)
    from .audit import client_output_reason
    for rel in bad:
        p = Path(data) / rel
        fields, rows = _read_csv(p)
        keep = [r for r in rows if client_output_reason(source=r.get("source", ""), series=r.get("series", "")) is None]
        os.chmod(p, 0o644)
        p.write_text(_csv_text(fields, keep), encoding="utf-8")
    return bad


def write_marker(data: Path, answer: str, as_of: str, mvp_sha: str, internal_only: bool, register_status: str,
                 withheld: list[dict]) -> dict:
    """SEC-A-014 P2-L4 / HO-20261026-B-A-002: data/client_safe.json, so a copied data/ keeps the INTERNAL notice and the
    placeholder labels. internal_only stays true until the data folder's approved register itself carries the D3
    answer (Sam: `econquest change`); never false on a simulated or unapproved register. The variant's
    dataset_sha256 is in ../manifest.json (it covers this file, so it cannot be inside it)."""
    ph = [{"table": w["table"], "key": w["key"], "country": w["country"], "value": w["new_value"],
           "fallback": w["fallback"]} for w in withheld if w["label"] == "placeholder"]
    marker = {"kind": "client_safe_dataset", "ticket": TICKET, "variant": f"d3-{answer}", "d3": answer, "as_of": as_of,
              "source_dataset_sha256": mvp_sha, "internal_only": bool(internal_only), "notice": INTERNAL_NOTICE,
              "register_status": register_status, "manifest": "../manifest.json (dataset_sha256)",
              "labels": "../provenance.csv (every cell), ../withheld.csv (withheld cells)",
              "placeholder_cells": len(ph), "placeholders": ph}
    (Path(data) / MARKER).write_text(json.dumps(marker, indent=1, sort_keys=True) + "\n", encoding="utf-8")
    return marker


def run_checks(data: Path, mvp_data: Path, register: Path, withheld: list[dict], route_rows: list[dict],
               review_rows: list[dict], review_fields: list[str], gate_prov: list[dict]) -> dict:
    """The checks a variant must pass (see the module docstring). Returns a dict; `problems` lists every failure."""
    from ..ops.demo import probe_gate
    from .audit import client_restricted_cells, restricted_source_cells
    held = {(w["table"], str(w["key"]), w["country"]) for w in withheld}
    out: dict = {"problems": []}
    with tempfile.TemporaryDirectory(prefix="eq-a-0124-check-") as td, simulated_register(register):
        t = Path(td)
        raw = restricted_raw_rows(data)                    # SEC-A-014 P2-M1: raw rows, not only table cells
        out["restricted_raw_rows"] = sum(n for d in raw.values() for n in d.values())
        if raw:
            out["problems"].append(f"restricted rows in shipped raw files: {raw}")
        ev = _evidence_dir(t, data, mvp_data, route_rows)
        desk = restricted_source_cells(ev)
        client = client_restricted_cells(ev)
        out["restricted_source_cells"] = int(len(desk))
        out["client_restricted_cells"] = int(len(client))
        for name, df in (("restricted_source_cells", desk), ("client_restricted_cells", client)):
            if len(df):
                out["problems"].append(f"{name}: {len(df)} cells, e.g. " + "; ".join(
                    f"{r.table} {r.key} {r.country} ({str(r.reason)[:80]})" for r in df.head(5).itertuples()))
        # Team A's audit on data/mvp's own values and records only: every cell it restricts must be withheld
        ev0 = _evidence_dir(t, mvp_data, mvp_data, [], name="mvp_evidence")
        a0 = client_restricted_cells(ev0)
        missed = sorted(_cells_of(a0) - held) if len(a0) else []
        out["audit_restricted_in_mvp"] = int(len(a0))
        out["audit_restricted_not_withheld"] = len(missed)
        if missed:
            out["problems"].append(f"Team A's audit restricts {len(missed)} data/mvp cells that the withheld set "
                                   f"misses: {missed[:10]}")
        g = _gate_dir(t, data, review_rows, review_fields, gate_prov)
        pg = probe_gate(str(g))
        out["probe_gate"] = {k: pg.get(k) for k in ("ok", "review_rows", "holds", "missing", "checked", "unexplained",
                                                    "reason")}
        if not pg.get("ok") or pg.get("unexplained"):
            out["problems"].append(f"probe_gate: {pg.get('reason')}")
    ok, msg, missing = readiness(data)
    out["readiness"] = {"ok": ok, "message": msg}
    if not ok:
        behind = sorted(f"{w['table']} {w['key']} {w['country']} ({w['fallback']})" for w in withheld
                        if w["country"] in missing and (w["key"] in missing[w["country"]]
                                                        or f"indicator {w['key']}" in missing[w["country"]]))
        out["problems"].append(f"readiness refuses the variant: {msg}; withheld cells behind it: "
                               + ("; ".join(behind) or "none (a field missing in data/mvp too)"))
        out["readiness"]["withheld_cells_behind"] = behind
    return out


def gate_report(mvp_report: dict, withheld: list[dict], prov: list[dict], answer: str) -> dict:
    """data/mvp's gate report with each withheld cell's outcome 'withheld' (and its reason), and every blank cell of
    the variant with its reason. `unexplained` counts non-live cells without a reason (must be 0)."""
    from collections import Counter
    wh = {(w["table"], str(w["key"]), w["country"]): w for w in withheld}
    cells = []
    for g in mvp_report.get("cells", []):
        g = dict(g)
        w = wh.get((g["table"], str(g["key"]), g["country"]))
        if w is not None:
            g["mvp_outcome"] = g.get("outcome", "")
            g["live"] = ""                                     # never the restricted value
            g["outcome"] = "withheld"
            g["reason"] = (f"withheld for client output under D3 {answer} ({w['register_id']}): {w['reason']} | "
                           f"{w['label']}: {w['replacement']}")
        cells.append(g)
    blanks = [{"table": r["table"], "key": r["key"], "country": r["country"],
               "outcome": "withheld_blank" if r["label"] == "blank" else "blank_seed", "reason": r["reason"]}
              for r in prov if not str(r["value"]).strip()]
    unexplained = [g for g in cells + blanks if g["outcome"] != "live" and not str(g.get("reason", "")).strip()]
    summary = {"review_cells": len(cells), "outcomes": dict(sorted(Counter(g["outcome"] for g in cells).items())),
               "blank_cells": len(blanks), "withheld_cells": len(withheld), "unexplained": len(unexplained)}
    return {"summary": summary, "cells": cells, "blank": blanks, "notice": INTERNAL_NOTICE}


# ------------------------------------------------------------------------------------------------ build

def _gate_prov(prows: list[dict], withheld: set, repl: list[dict]) -> list[dict]:
    """live/provenance.csv for probe_gate: data/mvp's records of the cells kept, plus the route values (feed values);
    placeholders stay seed (no record)."""
    keep = [{k: r.get(k, "") for k in ROUTE_PROV_FIELDS} for r in prows
            if (r["table"], str(r["key"]), r["country"]) not in withheld]
    return keep + [{k: r[k] for k in ROUTE_PROV_FIELDS} for r in repl if r.get("label") in ("route", "recomputed")]


def _mvp_label_rows(mvp: Path) -> dict:
    _, rows = _read_csv(mvp / "provenance.csv")
    return {("Inputs" if r["table"] == "indicators.csv" else "Country Profile", str(r["key"]), r["country"]): r
            for r in rows}


def _table_values(data: Path) -> dict:
    from .sources import read_csv_keep_na_code
    import pandas as pd
    out = {}
    ind = pd.read_csv(data / "indicators.csv", dtype=str, keep_default_na=False)
    for r in ind.to_dict("records"):
        for c, v in r.items():
            if c not in ("id", "pillar", "indicator", "unit"):
                out[("Inputs", str(r["id"]), c)] = v
    cty = read_csv_keep_na_code(data / "countries.csv", dtype=str).fillna("")
    for r in cty.to_dict("records"):
        for k, v in r.items():
            if k != "country":
                out[("Country Profile", k, r["country"])] = v
    return out


def restamp_transforms(trail: Path) -> dict:
    """In the PRIVATE work copy only: give each audit_trail.csv row that build_audit_trail stamped with a derivation
    text today's text for its key (audit.TRANSFORMS), as a rebuild would, so a derivation whose IMF inputs were named
    only later (1.6, EQ-A-0124) is seen by every licence check, Team B's / C's and Team A's. Values are not touched;
    data/ and data/mvp are never written. Returns {key: rows re-stamped}."""
    from .audit import PLANNED_FEED_PREFIX, TRANSFORMS
    data = (ROOT / "data").resolve()
    if data == Path(trail).resolve() or data in Path(trail).resolve().parents:
        raise ClientSafeError(f"refusing to re-stamp {trail}: only the build's private work copy is re-stamped")
    fields, rows = _read_csv(trail)
    if "transform" not in fields:
        return {}
    done: dict = {}
    for r in rows:
        t, cur = str(r.get("transform") or ""), TRANSFORMS.get(str(r.get("key", "")))
        if t and cur and cur not in t and not t.strip().casefold().startswith(PLANNED_FEED_PREFIX):
            r["transform"] = f"{t} | {cur}"
            done[r["key"]] = done.get(r["key"], 0) + 1
    if done:
        trail.write_text(_csv_text(fields, rows), encoding="utf-8")
    return done


GENERIC_SOURCE_PREFIX = "econquest full fetch"         # mvp_dataset's label for a vintage cell (names no feed)
RESTAMP_FIELDS = ["table", "key", "country", "value", "status", "generic_source", "source", "series", "evidence"]
# A generic record with no feed-specific vintage record of the same cell and value: its real source cannot be
# established, so it fails closed. The label matches no register row (the generic text matches econquest_derived,
# client_ok=yes), so the licence rule withholds the cell as unregistered (coordinator, 2026-10-26).
UNMATCHED_SOURCE = ("unestablished source: no feed-specific vintage record of this cell and value (EQ-A-0124 fails "
                    "closed); data/mvp said: ")


def _vintage_records(data_root: Path) -> dict:
    """{(table, key, country): [record]} of the feed-specific provenance in the shared data folder (read only):
    data/live/provenance.csv and every data/live/vintages/*/provenance.csv."""
    root = Path(data_root)
    files = [root / "live" / "provenance.csv"] + sorted((root / "live" / "vintages").glob("*/provenance.csv"))
    out: dict = {}
    for f in files:
        if not f.is_file() or f.is_symlink():
            continue
        for r in _read_csv(f)[1]:
            if str(r.get("source", "")).startswith(GENERIC_SOURCE_PREFIX):
                continue
            out.setdefault((r["table"], str(r["key"]), r["country"]), []).append(
                dict(r, evidence=f.relative_to(root.parent).as_posix() if root.parent in f.parents else str(f)))
    return out


def _same_value(a, b) -> bool:
    x, y = _num(a), _num(b)
    return math.isfinite(x) and math.isfinite(y) and abs(x - y) <= 1e-3 * max(1.0, abs(x))


def source_restamp(records_dir: Path, data_root: Path) -> list[dict]:
    """ARCH-A-PI10 R4 / HO-20261026-B-A-005 follow-up: data/mvp's vintage cells name the vintage ("econquest full
    fetch ... vintage ...") but not the feed, so a licence rule keyed on the source never matches (theratesapi fx3m,
    EXC-005). For every such record in records_dir (live/provenance.csv, audit_trail.csv), the feed-specific records of
    the SAME cell and value in the shared folder's live provenance and vintages. One row per (cell, specific source);
    a cell with none gets one 'unmatched' row whose source is UNMATCHED_SOURCE (fails closed: withheld as unregistered).
    data/ and data/mvp are only read."""
    cands = _vintage_records(data_root)
    out, seen = [], set()
    d = Path(records_dir)
    gen = [r for r in _read_csv(d / "live" / "provenance.csv")[1] if r["source"].startswith(GENERIC_SOURCE_PREFIX)]
    gen += [r for r in _read_csv(d / "audit_trail.csv")[1] if str(r.get("source", "")).startswith(GENERIC_SOURCE_PREFIX)
            and r.get("table") in ("Inputs", "Country Profile")]
    unmatched = {}
    for r in gen:
        cell = (r["table"], str(r["key"]), r["country"])
        hit = False
        for c in cands.get(cell, []):
            if not _same_value(c.get("value"), r.get("value")):
                continue
            hit = True
            k = (*cell, c["source"], c.get("series", ""))
            if k in seen:
                continue
            seen.add(k)
            out.append({"table": cell[0], "key": cell[1], "country": cell[2], "value": r["value"], "status": "matched",
                        "generic_source": r["source"], "source": c["source"], "series": c.get("series", ""),
                        "evidence": c["evidence"]})
        if not hit and not any(u[:3] == cell and _same_value(u[3], r["value"]) for u in unmatched):
            unmatched[(*cell, r["value"])] = r
    matched_cells = {(x["table"], x["key"], x["country"], x["value"]) for x in out}
    for (t, k, c, v), r in unmatched.items():
        if any(m[:3] == (t, k, c) and _same_value(m[3], v) for m in matched_cells):
            continue                                          # the same cell and value matched in the other file
        out.append({"table": t, "key": k, "country": c, "value": v, "status": "unmatched", "generic_source": r["source"],
                    "source": UNMATCHED_SOURCE + r["source"][len(GENERIC_SOURCE_PREFIX):].strip(" ,"),
                    "series": "", "evidence": ""})
    return sorted(out, key=lambda x: (x["table"], x["key"], x["country"], x["source"]))


def _unmatched_not_withheld(restamp: list[dict], withheld: list[dict]) -> list[tuple]:
    """'unmatched' re-stamp cells (no established source) missing from the withheld set: must be none."""
    wh = {(w["table"], str(w["key"]), w["country"]) for w in withheld}
    return sorted({(x["table"], x["key"], x["country"]) for x in restamp if x.get("status") == "unmatched"} - wh)


def apply_source_restamp(records_dir: Path, restamp: list[dict]) -> dict:
    """Write the specific sources into records_dir's live/provenance.csv (one record per source, the generic one
    replaced) and audit_trail.csv (source / series joined). Refuses the shared data folder. {key: cells}."""
    d = Path(records_dir).resolve()
    shared = (ROOT / "data").resolve()
    if d == shared or shared in d.parents:
        raise ClientSafeError(f"refusing to re-stamp {records_dir}: only the build's private work copy is re-stamped")
    by: dict = {}
    for x in restamp:
        by.setdefault((x["table"], x["key"], x["country"]), []).append(x)
    pf, prows = _read_csv(d / "live" / "provenance.csv")
    newp = []
    for r in prows:
        hits = [x for x in by.get((r["table"], str(r["key"]), r["country"]), []) if _same_value(x["value"], r["value"])]
        if r["source"].startswith(GENERIC_SOURCE_PREFIX) and hits:
            newp += [dict(r, source=x["source"], series=x["series"]) for x in hits]
        else:
            newp.append(r)
    (d / "live" / "provenance.csv").write_text(_csv_text(pf, newp), encoding="utf-8")
    af, arows = _read_csv(d / "audit_trail.csv")
    for r in arows:
        hits = [x for x in by.get((r.get("table"), str(r.get("key")), r.get("country")), [])
                if _same_value(x["value"], r.get("value"))]
        if str(r.get("source", "")).startswith(GENERIC_SOURCE_PREFIX) and hits:
            r["source"] = " | ".join(dict.fromkeys(x["source"] for x in hits))
            r["series"] = " | ".join(dict.fromkeys(x["series"] for x in hits if x["series"])) or r.get("series", "")
    (d / "audit_trail.csv").write_text(_csv_text(af, arows), encoding="utf-8")
    from collections import Counter
    return dict(sorted(Counter(k[1] for k in by).items()))


def _records_dir(tmp: Path, mvp_data: Path, restamp: list[dict]) -> Path:
    """data/mvp's records (tables, audit_trail.csv, live/provenance.csv, cb_series_verified.csv) in a private folder,
    with the 1.6 transform and the source re-stamps applied: what the build's work copy held."""
    r = tmp / "records"
    (r / "live").mkdir(parents=True)
    for rel in ("indicators.csv", "countries.csv", "audit_trail.csv", "live/provenance.csv",
                "panel/cb_series_verified.csv"):
        if (mvp_data / rel).is_file():
            (r / rel).parent.mkdir(parents=True, exist_ok=True)
            shutil.copyfile(mvp_data / rel, r / rel)
    for p in r.rglob("*"):
        os.chmod(p, 0o755 if p.is_dir() else 0o644)
    restamp_transforms(r / "audit_trail.csv")
    apply_source_restamp(r, restamp)
    return r


def build_variant(answer: str, root: Path = ROOT, mvp: Path | None = None, out_root: Path | None = None,
                  route_wb: Path | None = None, now: dt.datetime | None = None) -> dict:
    """Build <out_root>/d3_<answer>. Writes a temporary sibling and renames it, so a failure leaves the previous
    variant in place. Returns the manifest. ClientSafeError names the cells when a check fails."""
    import pandas as pd
    from ..validation import client_safe as C
    from . import mvp_dataset as M
    from .official import client_safe_route as R
    if answer not in ANSWERS:
        raise ClientSafeError(f"--d3 must be yes or no, not {answer!r}")
    root = Path(root)
    mvp = Path(mvp) if mvp else root / "data" / "mvp"
    out_root = _check_out_root(out_root or default_out_root(root), root)
    try:
        M.verify(mvp, load=False)
    except M.MvpError as e:
        raise ClientSafeError(f"data/mvp does not verify, nothing built: {e}") from e
    mman = json.loads((mvp / "manifest.json").read_text())
    as_of = mman["as_of"]
    yes = answer == "yes"
    out_root.mkdir(parents=True, exist_ok=True)
    final = out_root / f"d3_{answer}"
    tmp = Path(tempfile.mkdtemp(prefix=f".build-d3_{answer}-", dir=out_root))
    try:
        # private work folder on local temp storage, not on the shared mount (a network mount can refuse to remove
        # a folder while a handle is open, which aborted a build after its checks had passed)
        work = Path(tempfile.mkdtemp(prefix=f"eq-a-0124-work-d3_{answer}-"))
        src = work / "src"
        shutil.copytree(mvp / "data", src)
        for p in src.rglob("*"):
            os.chmod(p, 0o755 if p.is_dir() else 0o644)
        restamped = restamp_transforms(src / "audit_trail.csv")
        restamp = source_restamp(src, root / "data")          # ARCH-A-PI10 R4: name each vintage cell's feed
        restamp_keys = apply_source_restamp(src, restamp)
        reg = src / "licences.csv"
        reg_sha_before = _sha(reg)
        from ..ops import licence_gov as G
        from .official.client_safe_route import D3_ROW
        reg_status = G.state(mvp / "data")["status"]
        row_before = next(r for r in _read_csv(reg)[1] if r.get("source_id") == D3_ROW)
        patch = patch_register(reg, answer)
        row_after = next(r for r in _read_csv(reg)[1] if r.get("source_id") == D3_ROW)
        # client use only when the approved register already carries this answer (no simulation): not the case today
        internal_only = not (reg_status in G.TRUSTED and row_before == row_after)
        wb = Path(route_wb).resolve() if route_wb else None
        wb_label = (wb.relative_to(root.resolve()).as_posix() if wb and wb.is_relative_to(root.resolve()) else
                    (str(wb) if wb else "data/mvp/data/live/raw_worldbank.csv"))
        wb_sha = _sha(wb) if wb else _sha(mvp / "data" / "live" / "raw_worldbank.csv")
        with simulated_register(reg):
            wh = C.withheld_cells(src, allow_unapproved=True)
            plan0 = C.plan_replacements(src, as_of, allow_unapproved=True, route=False)
            values = R.client_safe_values(src, as_of, wb_path=wb, include_conditional=yes)
            plan = R.apply_route(plan0, values, d3=yes)
            # EQ-B-0130 (c), Team B's contract for route=False callers: after the route, every cell still on the t50
            # marker takes the rulebook worst score t100 (validation.client_safe.stress_placeholders)
            plan = C.stress_placeholders(plan, src)
            copy, bman = C.build_client_safe_copy(src, as_of, work / "teamb", allow_unapproved=True, route_wb=wb)
            bplan = bman.pop("plan")
            d3_state = R.d3_yes(C.load_licence_register(src, allow_unapproved=True))
            raw_dropped = drop_restricted_raw_rows(copy)   # SEC-A-014 P2-M1: Team B's file_decision is path-only
        # Team B consistency: one withheld set, cell for cell
        mine = {(r.table, str(r.key), r.country) for r in plan.itertuples() if r.component}
        theirs = {(r.table, str(r.key), r.country) for r in bplan.itertuples() if r.component}
        rule = {(r.table, str(r.key), r.country) for r in wh.itertuples()}
        if not (mine == theirs == rule):
            raise ClientSafeError(f"withheld set differs from Team B's: only here {sorted(mine - theirs)[:10]}, only "
                                  f"Team B {sorted(theirs - mine)[:10]}, not in withheld_cells {sorted(mine - rule)[:10]}")
        if d3_state != yes:
            raise ClientSafeError(f"the simulated register reads D3 yes={d3_state}, expected {yes}")
        # route values Team B's plan does not carry (conditional steps under "yes"): write them into the copy
        bi = bplan.set_index(["table", "key", "country"])
        extra = []
        for r in plan[plan["component"] != ""].to_dict("records"):
            b = bi.loc[(r["table"], r["key"], r["country"])]
            a_v, b_v = _num(r["new_value"]), _num(b["new_value"])
            if (math.isfinite(a_v) or math.isfinite(b_v)) and not (a_v == b_v):
                if r["fallback"] != R.ROUTE_FALLBACK or b["fallback"] not in R.REPLACEABLE:
                    raise ClientSafeError(f"{r['table']} {r['key']} {r['country']}: value differs from Team B's plan "
                                          f"outside the route ({r['fallback']} vs {b['fallback']})")
                extra.append(r)
        if extra:
            ind = pd.read_csv(copy / "indicators.csv", dtype=str, keep_default_na=False)
            for r in extra:
                ind.loc[ind["id"] == r["key"], r["country"]] = repr(float(r["new_value"]))
            ind.to_csv(copy / "indicators.csv", index=False)
        data = tmp / "data"
        shutil.move(str(copy), data)
        # withheld list, route records, provenance
        withheld, route_rows = [], []
        vals = {(r["key"], r["country"]): r for r in values.to_dict("records")}
        for r in plan[plan["component"] != ""].to_dict("records"):
            lab = label_of(r["fallback"])
            withheld.append({"table": r["table"], "key": str(r["key"]), "country": r["country"],
                             "register_id": r["register_id"], "component": r["component"], "reason": r["reason"],
                             "fallback": r["fallback"], "label": lab, "new_value": _fmt(r["new_value"]),
                             "replacement": r["replacement"]})
            if math.isfinite(_num(r["new_value"])):
                v = vals.get((str(r["key"]), r["country"]))
                if lab == "route" and v:
                    srce = v["source"]
                elif lab == "recomputed":
                    srce = R.WB_SOURCE
                else:                   # placeholder / official / seed: Team B's labelled fallback, not a feed value
                    srce = PLACEHOLDER_SOURCE + r["fallback"]
                # the series names the value's own origin only (a placeholder's text is its fallback kind, not the
                # replacement note, which names the IMF source it replaces)
                ser = (v["series"] if lab == "route" and v else
                       r["replacement"] if lab == "recomputed" else r["fallback"])
                route_rows.append({"table": r["table"], "key": str(r["key"]), "country": r["country"],
                                   "value": _fmt(r["new_value"]), "source": srce, "series": ser,
                                   "retrieved": as_of, "label": lab})
        # HO-20261026-B-A-006: a withheld fx3m cell takes a cleared official value or Team B's stressed placeholder
        # (validation.client_safe.FX3M_PLACEHOLDER_PCT); never blank, 0 or the analyst seed, which can read safer
        fx_bad = [w for w in withheld if w["key"] == "fx3m" and not (
            w["label"] == "official" or (w["fallback"] == FX3M_PLACEHOLDER_FALLBACK
                                         and _num(w["new_value"]) == C.FX3M_PLACEHOLDER_PCT))]
        if fx_bad:
            raise ClientSafeError("withheld fx3m cells without an official value or Team B's stressed placeholder: "
                                  + ", ".join(f"{w['country']} ({w['fallback']}, {w['new_value'] or 'blank'})"
                                              for w in fx_bad))
        open_unmatched = _unmatched_not_withheld(restamp, withheld)
        if open_unmatched:
            raise ClientSafeError(f"{len(open_unmatched)} cells whose source could not be established are not "
                                  f"withheld (fail closed): {open_unmatched[:10]}")
        fx_placeholder = sorted(w["country"] for w in withheld
                                if w["key"] == "fx3m" and w["fallback"] == FX3M_PLACEHOLDER_FALLBACK)
        whi = {(w["table"], w["key"], w["country"]): w for w in withheld}
        if any(not w["label"] for w in withheld):
            bad = [w for w in withheld if not w["label"]]
            raise ClientSafeError(f"{len(bad)} withheld cells with an unknown fallback kind, e.g. {bad[0]}")
        mlab = _mvp_label_rows(mvp)
        tv = _table_values(data)
        prov = []
        for cell, mr in mlab.items():
            w = whi.get(cell)
            v = tv.get(cell, "")
            if w is None:
                prov.append({"table": mr["table"], "key": cell[1], "country": cell[2], "value": v, "label": mr["label"],
                             "source": mr["source"], "register_id": "",
                             "reason": mr["reason"] or ("" if str(v).strip() else mr["source"])})
            else:
                why = (f"withheld for client output under D3 {answer} ({w['register_id']}): {w['reason']}"
                       + (" | no cleared fallback (blank)" if w["label"] == "blank" else ""))
                prov.append({"table": mr["table"], "key": cell[1], "country": cell[2], "value": v, "label": w["label"],
                             "source": w["replacement"], "register_id": w["register_id"], "reason": why})
        # gate review without the withheld cells (they are decided by licence, not by the gate)
        rfields, rrows = _read_csv(mvp / "data" / "live" / "review.csv")
        grows = [r for r in rrows if (r["table"], str(r["key"]), r["country"]) not in whi]
        pf, prows = _read_csv(mvp / "data" / "live" / "provenance.csv")
        gprov = _gate_prov(prows, whi, route_rows)
        shutil.copyfile(reg, tmp / f"licences_d3_{answer}.csv")
        checks = run_checks(data, src, tmp / f"licences_d3_{answer}.csv", withheld, route_rows, grows, rfields,
                            gprov)
        rep = gate_report(json.loads((mvp / "gate_report.json").read_text()), withheld, prov, answer)
        if rep["summary"]["unexplained"]:
            checks["problems"].append(f"gate report: {rep['summary']['unexplained']} unexplained cells")
        if checks["problems"]:
            raise ClientSafeError(f"D3 {answer}: the client-safe variant fails its checks, nothing written: "
                                  + " || ".join(checks["problems"]))
        shutil.rmtree(work, ignore_errors=True)
        write_marker(data, answer, as_of, mman["dataset_sha256"], internal_only, reg_status, withheld)
        (tmp / "provenance.csv").write_text(_csv_text(PROV_FIELDS, prov), encoding="utf-8")
        (tmp / "withheld.csv").write_text(_csv_text(WITHHELD_FIELDS, withheld), encoding="utf-8")
        (tmp / "replacements.csv").write_text(_csv_text(REPL_FIELDS, route_rows), encoding="utf-8")
        (tmp / "source_restamp.csv").write_text(_csv_text(RESTAMP_FIELDS, restamp), encoding="utf-8")
        (tmp / "gate_review.csv").write_text(_csv_text(rfields, grows), encoding="utf-8")
        (tmp / "gate_report.json").write_text(json.dumps(rep, indent=1, sort_keys=True) + "\n", encoding="utf-8")
        files = {p.relative_to(tmp).as_posix(): _sha(p) for p in sorted(tmp.rglob("*")) if p.is_file()}
        from collections import Counter
        counts = {"cells": len(prov), "labels": dict(sorted(Counter(r["label"] for r in prov).items())),
                  "withheld": len(withheld),
                  "withheld_by_label": dict(sorted(Counter(w["label"] for w in withheld).items())),
                  "withheld_by_component": dict(sorted(Counter(w["component"] for w in withheld).items())),
                  "blank_cells": sum(1 for r in prov if not str(r["value"]).strip()),
                  "real_values": sum(1 for r in prov if str(r["value"]).strip() and r["label"] != "placeholder")}
        caveats = [INTERNAL_NOTICE,
                   "D3 simulated on a copy of the register; data/licences.csv keeps imf_via_wdi undecided",
                   "conditional route values (IMF-compiled WDI) fill withheld cells under yes; Team B's "
                   "plan_replacements passes them too since 05:54Z (include_conditional=d3_yes), so route_values_added "
                   "is 0" if yes else
                   "Country Profile reserves withheld by D3 'no' take Team B's judgement placeholder "
                   f"{C.RESERVES_PLACEHOLDER_PCT_GDP:g}% of GDP (HO-20261026-A-B-001), the same for every name",
                   "withheld fx3m cells with no cleared BIS / ECB / parity value take Team B's stressed placeholder "
                   f"FX3M_PLACEHOLDER_PCT {C.FX3M_PLACEHOLDER_PCT:g}% (HO-20261026-B-A-006): "
                   + (", ".join(fx_placeholder) or "none"),
                   "work-copy provenance re-stamped from each cell's vintage record before the licence rule runs "
                   "(data/mvp names only 'econquest full fetch'; ARCH-A-PI10 R4, mvp_dataset fix in the PI-13 rebuild); a cell "
                   "with no such record fails closed (status unmatched in source_restamp.csv, withheld as "
                   "unregistered)",
                   "files left out of data/ follow Team B's file_decision (register rows not client-allowed); rows of "
                   "shipped raw files are filtered too, by their own series (SEC-A-014 P2-M1): "
                   + (json.dumps(raw_dropped, sort_keys=True) if raw_dropped else "none dropped"),
                   f"data/{MARKER} carries internal_only={str(internal_only).lower()} and the placeholder cells"]
        manifest = {
            "schema": SCHEMA, "ticket": TICKET, "d3": answer, "as_of": as_of, "notice": INTERNAL_NOTICE,
            "built_utc": (now or dt.datetime.now(dt.timezone.utc)).strftime("%Y-%m-%dT%H:%M:%SZ"),
            "mvp": {"path": "data/mvp", "dataset_sha256": mman["dataset_sha256"], "vintage_id": mman["vintage_id"]},
            "register": {"patch": patch, "base_sha256": reg_sha_before,
                         "simulated_sha256": files[f"licences_d3_{answer}.csv"],
                         "file": f"licences_d3_{answer}.csv", "data_licences_csv_untouched": True},
            "route_wb": {"path": wb_label, "sha256": wb_sha, "conditional_steps": yes},
            "internal_only": internal_only, "register_status": reg_status, "raw_rows_dropped": raw_dropped,
            "audit_transform_restamped": restamped,
            "fx3m_placeholder": {"constant": "validation.client_safe.FX3M_PLACEHOLDER_PCT",
                                 "value": C.FX3M_PLACEHOLDER_PCT, "countries": fx_placeholder,
                                 "handoff": "HO-20261026-B-A-006"},
            "source_restamped": {"records": len(restamp), "cells_by_key": restamp_keys,
                                 "matched": sum(1 for x in restamp if x["status"] == "matched"),
                                 "unmatched": sum(1 for x in restamp if x["status"] == "unmatched"),
                                 "unmatched_by_key": dict(sorted(Counter(x["key"] for x in restamp
                                                                         if x["status"] == "unmatched").items())),
                                 "file": "source_restamp.csv", "from": "data/live/provenance.csv, "
                                 "data/live/vintages/*/provenance.csv (same cell and value)"},
            "team_b": {"rule": "validation.client_safe.withheld_cells (ops.licence_rule.evaluate internal_only)",
                       "withheld_same": True, "withheld_cells": len(mine), "route_values_added": len(extra),
                       "files_left_out": bman["files_left_out"], "price_columns_dropped": bman["price_columns_dropped"],
                       "series_rows_dropped": bman.get("series_rows_dropped", {}),
                       # the exact rule code this variant was built with (HO-20261026-B-A-007)
                       "client_safe_py_sha256": _sha(Path(C.__file__)),
                       "client_safe_route_py_sha256": _sha(Path(R.__file__))},
            "counts": counts, "gate": rep["summary"],
            "checks": {k: v for k, v in checks.items() if k != "problems"}, "caveats": caveats, "files": files,
            "dataset_sha256": hashlib.sha256("".join(f"{k}\0{v}\n" for k, v in files.items()).encode()).hexdigest(),
        }
        (tmp / "manifest.json").write_text(json.dumps(manifest, indent=1, sort_keys=True) + "\n", encoding="utf-8")
        for p in tmp.rglob("*"):
            if p.is_file():
                os.chmod(p, 0o444)
        if final.exists():
            old = out_root / f".old-d3_{answer}-{os.getpid()}"
            _rmtree(old)
            final.rename(old)
            tmp.rename(final)
            _rmtree(old)
        else:
            tmp.rename(final)
    except BaseException:
        _rmtree(tmp)
        raise
    finally:
        if "work" in locals() and Path(work).exists():
            shutil.rmtree(work, ignore_errors=True)
    return manifest


# ------------------------------------------------------------------------------------------------ verify

def verify_variant(variant: Path, root: Path = ROOT, mvp: Path | None = None) -> dict:
    """Hashes (no missing or extra file), labels, gate report recount, and the checks re-run: 0 restricted cells,
    probe_gate 0 unexplained, readiness. data/mvp must still be the dataset the variant was built from."""
    variant = Path(variant)
    mpath = variant / "manifest.json"
    if not mpath.is_file():
        raise ClientSafeError(f"no client-safe variant at {variant} (python -m econquest.ingestion.client_safe_dataset "
                              "build)")
    m = json.loads(mpath.read_text())
    if m.get("schema") != SCHEMA:
        raise ClientSafeError(f"unknown manifest schema {m.get('schema')!r}")
    problems = []
    present = {p.relative_to(variant).as_posix() for p in variant.rglob("*") if p.is_file()} - {"manifest.json"}
    for rel, sha in m["files"].items():
        if rel not in present:
            problems.append(f"missing file {rel}")
        elif _sha(variant / rel) != sha:
            problems.append(f"sha256 mismatch {rel}")
    problems += [f"file not in manifest {rel}" for rel in sorted(present - set(m["files"])) if "__pycache__" not in rel]
    if problems:
        raise ClientSafeError(f"{variant.name} failed verification: " + "; ".join(problems[:20]))
    mvp = Path(mvp) if mvp else Path(root) / "data" / "mvp"
    mman = json.loads((mvp / "manifest.json").read_text())
    if mman["dataset_sha256"] != m["mvp"]["dataset_sha256"]:
        raise ClientSafeError(f"data/mvp moved ({mman['dataset_sha256'][:16]} != built from "
                              f"{m['mvp']['dataset_sha256'][:16]}): rebuild the variant")
    _, prov = _read_csv(variant / "provenance.csv")
    bad = [r for r in prov if r["label"] not in LABELS or not r["source"].strip()]
    if bad:
        raise ClientSafeError(f"{len(bad)} provenance rows without a valid label/source, e.g. {bad[0]}")
    _, withheld = _read_csv(variant / "withheld.csv")
    mk = variant / "data" / MARKER
    if not mk.is_file():
        raise ClientSafeError(f"{variant.name}: no data/{MARKER} (INTERNAL marker, SEC-A-014 P2-L4)")
    marker = json.loads(mk.read_text())
    if marker.get("internal_only") is not True and m.get("internal_only", True):
        raise ClientSafeError(f"{variant.name}: data/{MARKER} must say internal_only true on a simulated or unapproved "
                              "register")
    from ..validation.client_safe import FX3M_PLACEHOLDER_PCT
    fx_bad = [w["country"] for w in withheld if w["key"] == "fx3m" and not (
        w["label"] == "official" or (w["fallback"] == FX3M_PLACEHOLDER_FALLBACK
                                     and _num(w["new_value"]) == FX3M_PLACEHOLDER_PCT))]
    if fx_bad:
        raise ClientSafeError(f"{variant.name}: withheld fx3m without an official value or Team B's "
                              f"FX3M_PLACEHOLDER_PCT: {fx_bad}")
    ph = {(w["table"], w["key"], w["country"]) for w in withheld if w["label"] == "placeholder"}
    if {(x["table"], x["key"], x["country"]) for x in marker.get("placeholders", [])} != ph:
        raise ClientSafeError(f"{variant.name}: data/{MARKER} does not list the placeholder cells of withheld.csv")
    rep = json.loads((variant / "gate_report.json").read_text())
    unexplained = [g for g in rep.get("cells", []) + rep.get("blank", [])
                   if g.get("outcome") != "live" and not str(g.get("reason", "")).strip()]
    if rep["summary"]["unexplained"] or unexplained:
        raise ClientSafeError(f"gate report has {max(rep['summary']['unexplained'], len(unexplained))} unexplained cells")
    _, route_rows = _read_csv(variant / "replacements.csv")
    rfields, grows = _read_csv(variant / "gate_review.csv")
    whi = {(w["table"], w["key"], w["country"]) for w in withheld}
    _, prows = _read_csv(mvp / "data" / "live" / "provenance.csv")
    gprov = _gate_prov(prows, whi, route_rows)
    stored = _read_csv(variant / "source_restamp.csv")[1]
    now = source_restamp(mvp / "data", Path(root) / "data")
    key = lambda x: (x["table"], x["key"], x["country"], x["source"], x["series"])      # noqa: E731
    missing = sorted({key(x) for x in now} - {key(x) for x in stored})
    if missing:
        raise ClientSafeError(f"{variant.name}: {len(missing)} cells have a work-copy record less specific than their "
                              f"vintage record (rebuild): {[k[:4] for k in missing[:8]]}")
    open_unmatched = _unmatched_not_withheld(stored, withheld)
    if open_unmatched:
        raise ClientSafeError(f"{variant.name}: {len(open_unmatched)} cells whose source could not be established are "
                              f"not withheld (fail closed): {open_unmatched[:8]}")
    with tempfile.TemporaryDirectory(prefix="eq-a-0124-verify-") as td:
        rec = _records_dir(Path(td), mvp / "data", stored)
        checks = run_checks(variant / "data", rec, variant / m["register"]["file"], withheld, route_rows, grows,
                            rfields, gprov)
    if checks["problems"]:
        raise ClientSafeError(f"{variant.name} failed its checks: " + " || ".join(checks["problems"]))
    return {"ok": True, "d3": m["d3"], "dataset_sha256": m["dataset_sha256"], "files": len(m["files"]),
            "counts": m["counts"], "gate": rep["summary"], "restricted_source_cells": checks["restricted_source_cells"],
            "client_restricted_cells": checks["client_restricted_cells"],
            "probe_gate_unexplained": checks["probe_gate"]["unexplained"], "readiness": checks["readiness"]["ok"],
            "restricted_raw_rows": checks["restricted_raw_rows"], "internal_only": marker["internal_only"],
            "client_safe_py_sha256": m.get("team_b", {}).get("client_safe_py_sha256", ""),
            "client_safe_py_current": m.get("team_b", {}).get("client_safe_py_sha256", "") == _sha(
                Path(__file__).resolve().parents[1] / "validation" / "client_safe.py")}


# ------------------------------------------------------------------------------------------------ compare

def compare(out_root: Path) -> dict:
    """comparison.md and comparison_cells.csv under out_root: per indicator, withheld / route / recomputed /
    placeholder / blank for each answer, and every cell whose value or label differs between the two."""
    out_root = Path(out_root)
    prov, man = {}, {}
    for a in ANSWERS:
        v = out_root / f"d3_{a}"
        if not (v / "manifest.json").is_file():
            raise ClientSafeError(f"no d3_{a} variant under {out_root}: build --d3 both first")
        man[a] = json.loads((v / "manifest.json").read_text())
        prov[a] = {(r["table"], r["key"], r["country"]): r for r in _read_csv(v / "provenance.csv")[1]}
    kinds = ("route", "recomputed", "official", "placeholder", "blank")
    per: dict = {}
    for a in ANSWERS:
        for (t, k, _c), r in prov[a].items():
            if not r["register_id"]:
                continue
            d = per.setdefault((t, k), {x: {"withheld": 0, **{q: 0 for q in kinds}} for x in ANSWERS})
            d[a]["withheld"] += 1
            if r["label"] in kinds:
                d[a][r["label"]] += 1
    diff = []
    for cell in sorted(set(prov["yes"]) | set(prov["no"])):
        y, n = prov["yes"].get(cell, {}), prov["no"].get(cell, {})
        if (y.get("value"), y.get("label")) != (n.get("value"), n.get("label")):
            diff.append({"table": cell[0], "key": cell[1], "country": cell[2], "label_yes": y.get("label", ""),
                         "value_yes": y.get("value", ""), "label_no": n.get("label", ""), "value_no": n.get("value", ""),
                         "source_yes": y.get("source", ""), "source_no": n.get("source", "")})
    fields = ["table", "key", "country", "label_yes", "value_yes", "label_no", "value_no", "source_yes", "source_no"]
    (out_root / "comparison_cells.csv").write_text(_csv_text(fields, diff), encoding="utf-8")
    L = [f"**{INTERNAL_NOTICE}**", "", f"# Client-safe dataset: D3 yes vs D3 no ({TICKET})", "",
         f"Both variants are built from data/mvp (dataset sha256 {man['yes']['mvp']['dataset_sha256'][:16]}..., as_of "
         f"{man['yes']['as_of']}). The World Bank file read by the route is {man['yes']['route_wb']['path']} (sha256 "
         f"{man['yes']['route_wb']['sha256'][:16]}...). Generated by "
         "`python -m econquest.ingestion.client_safe_dataset compare`.", "",
         "| | D3 yes | D3 no |", "|---|---|---|"]
    for lab, f in (("dataset_sha256", lambda m: f"`{m['dataset_sha256'][:16]}`"),
                   ("Cells (indicators.csv + countries.csv)", lambda m: m["counts"]["cells"]),
                   ("Withheld", lambda m: m["counts"]["withheld"]),
                   ("Cells with a real value (not a placeholder, not blank)", lambda m: m["counts"]["real_values"]),
                   ("Blank cells", lambda m: m["counts"]["blank_cells"]),
                   ("Restricted cells left (desk / client audit)",
                    lambda m: f"{m['checks']['restricted_source_cells']} / {m['checks']['client_restricted_cells']}"),
                   ("Gate report unexplained", lambda m: m["gate"]["unexplained"]),
                   ("probe_gate unexplained", lambda m: m["checks"]["probe_gate"]["unexplained"]),
                   ("Readiness", lambda m: "ok" if m["checks"]["readiness"]["ok"] else "REFUSED"),
                   ("Same withheld set as Team B", lambda m: m["team_b"]["withheld_same"])):
        L.append(f"| {lab} | {f(man['yes'])} | {f(man['no'])} |")
    L += ["", "## Withheld cells per indicator", "",
          "| Table | Key | Withheld yes | route | recomputed | placeholder | blank | Withheld no | route | recomputed | "
          "placeholder | blank |", "|---|---|" + "---:|" * 10]

    def sk(tk):
        t, k = tk
        try:
            return (t, tuple(int(x) for x in k.split(".")), k)
        except ValueError:
            return (t, (999,), k)
    for (t, k) in sorted(per, key=sk):
        y, n = per[(t, k)]["yes"], per[(t, k)]["no"]
        L.append(f"| {t} | {k} | {y['withheld']} | {y['route']} | {y['recomputed']} | {y['placeholder']} | {y['blank']} "
                 f"| {n['withheld']} | {n['route']} | {n['recomputed']} | {n['placeholder']} | {n['blank']} |")
    L += ["", f"## Cells that differ ({len(diff)})", "", "Full list: comparison_cells.csv.", "",
          "| Table | Key | Country | yes | no |", "|---|---|---|---|---|"]
    L += [f"| {d['table']} | {d['key']} | {d['country']} | {d['label_yes']} {d['value_yes']} | {d['label_no']} "
          f"{d['value_no']} |" for d in diff[:200]]
    L += ["", "## Caveats", ""] + [f"- D3 {a}: {c}" for a in ANSWERS for c in man[a]["caveats"][1:]]
    (out_root / "comparison.md").write_text("\n".join(L) + "\n", encoding="utf-8")
    return {"cells_differ": len(diff), "per_indicator": len(per), "md": str(out_root / "comparison.md"),
            "csv": str(out_root / "comparison_cells.csv")}


# ------------------------------------------------------------------------------------------------ CLI

def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.client_safe_dataset",
                                 description=__doc__.split("\n")[0])
    ap.add_argument("--root", default=str(ROOT), help="econquest folder (default: %(default)s)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("build", "verify"):
        s = sub.add_parser(name)
        s.add_argument("--d3", choices=("yes", "no", "both"), default="both")
        s.add_argument("--out-root", help="folder for d3_yes / d3_no (default outputs/client_safe_dataset)")
        if name == "build":
            s.add_argument("--route-wb", help="a recorded raw_worldbank*.csv for the route instead of data/mvp's own "
                           "(e.g. team/inbox/pull-20261025T013150Z/raw_worldbank.csv)")
    c = sub.add_parser("compare")
    c.add_argument("--out-root")
    a = ap.parse_args(argv)
    root = Path(a.root)
    out_root = Path(a.out_root) if getattr(a, "out_root", None) else default_out_root(root)
    answers = ANSWERS if getattr(a, "d3", "both") == "both" else (a.d3,)
    try:
        if a.cmd == "build":
            for ans in answers:
                m = build_variant(ans, root, out_root=out_root, route_wb=Path(a.route_wb) if a.route_wb else None)
                print(json.dumps({"d3": ans, "path": str(out_root / f"d3_{ans}"), "dataset_sha256": m["dataset_sha256"],
                                  "counts": m["counts"], "gate": m["gate"],
                                  "checks": {k: m["checks"][k] for k in ("restricted_source_cells",
                                                                         "client_restricted_cells", "readiness")},
                                  "probe_gate_unexplained": m["checks"]["probe_gate"]["unexplained"]}, indent=1))
            if len(answers) == 2:
                print(json.dumps(compare(out_root), indent=1))
        elif a.cmd == "verify":
            for ans in answers:
                print(json.dumps(verify_variant(out_root / f"d3_{ans}", root), indent=1))
        else:
            print(json.dumps(compare(out_root), indent=1))
    except ClientSafeError as e:
        print(f"error: {e}", file=sys.stderr)
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
