"""Monthly data quality report (EQ-A-0065): gate holds and releases, staleness, incidents, coverage trend and
attestation status for one calendar month, from records that already exist. Offline and read-only: it writes only
the two report files.

    python -m econquest.ingestion.dq_report build [--data data] [--month YYYY-MM | --as-of YYYY-MM-DD]
                                                  [--out DIR] [--json] [--trend-months 12]

--month defaults to the month before --as-of (default: today in America/New_York), so the scheduled run on the 1st
reports the month that just ended. The month window is [first day 00:00Z, first day of next month 00:00Z) in UTC.
Output: <out>/dq_report.md and dq_report.json; <out> defaults to <data>/../outputs/dq/<YYYY-MM>/ and may not be
inside the data folder.

Sections (each has status "ok", "no record" (the input does not exist; never reported as zero) or "error"):
  gate         vintage store (data/live/vintages/*/review.csv, feeds.json) and the review ledger
               (data/live/review_ledger.csv, ledger.py). Gate holds seen in the month's vintages by indicator,
               country and reason category (text before ':' in each ';'-separated part of the reason; a cell with two
               reasons counts under both), new holds (not held in the vintage before), releases (approved 'apply' rows
               written in the month on a gate-held cell; ledger._approved, attestation rows excluded) with
               time-to-release from the retrieval of the first vintage of the hold's run, analyst hold/reject rows
               written in the month, and gate holds still outstanding at month end (ledger.effective_holds with the
               ledger as it stood at month end, on the last vintage of the month).
  staleness    freshness.check_freshness (EQ-A-0052) on the last vintage retrieved by month end, as of month end;
               new and cleared breaches against the same check at the previous month end.
  incidents    feed failures (feeds.json of the month's vintages; data/live/feed_failures.csv when the current pull
               was retrieved in the month), restricted-source cells (audit.restricted_source_cells), client-output
               restricted cells (audit.client_restricted_cells, by licence: informational), pull pack step failures
               (data/live/pullpack/state.json; it keeps only each step's latest record), events mapping-QA breaches
               (data/live/events/<source>/incremental_log.csv, qa_breach) and nowcast merge stops (the pull pack's
               'nowcast' step failed with MergeStopped; nowcast_feed itself keeps no record of a stop).
               Restricted-cell audits are of the data as it is when the report is built, not at month end.
  coverage     EQ-A-0055 metric per vintage over the trailing --trend-months months: live cells (finite in the
               vintage's live_inputs.csv and not held in its review.csv) among the feed-eligible ids
               (universe.feed_eligible_ids), per country and desk total; target universe.LIVE_TARGET (60%).
               Same counting as universe.missing_cell_report.
  attestation  ledger.attestation_status: attested vs unattested hand-entered cells (current content).

Findings (exit 2): no vintage retrieved in the month ("no pull this month", AGENT-08 2026-10-24: a missed pull is
what the monthly report must catch); staleness breaches at month end; any incident except client-output restricted cells; desk
feed-eligible live share below target at month end. Informational only: gate holds (the gate working), unattested
cells (blocking on them is Sam's policy decision, ledger.unattested_cells), client-output restricted cells. A
section with no record is not a finding by itself; the month without any vintage is.
Exit codes: 0 no finding; 2 findings; 1 error (bad arguments, data folder missing, or a section could not be read;
the report is still written when possible).
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import math
import os
import re
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path

import pandas as pd

SCHEMA = "econquest.dq_report/1"
TICKET = "EQ-A-0065"
NO_RECORD = "no record"
EXIT_OK, EXIT_ERROR, EXIT_FINDINGS = 0, 1, 2
EXIT_MEANING = {EXIT_OK: "no findings", EXIT_ERROR: "error", EXIT_FINDINGS: "findings"}
DEFAULT_TZ = "America/New_York"
DEFAULT_TREND_MONTHS = 12
META_COLUMNS = ("id", "pillar", "indicator", "unit")       # indicators.csv columns that are not countries
_MONTH_RE = re.compile(r"^\d{4}-(0[1-9]|1[0-2])$")
_VID_TS_RE = re.compile(r"^(\d{4}-\d{2}-\d{2})T(\d{2})(\d{2})(\d{2})Z")
_TRUE = {"true", "1", "yes", "y"}


# ---------------------------------------------------------------------------------------------- month and time
def month_bounds(month: str) -> tuple[pd.Timestamp, pd.Timestamp]:
    """[start, end) of a YYYY-MM month in UTC. ValueError for anything else."""
    if not _MONTH_RE.match(str(month or "")):
        raise ValueError(f"--month must be YYYY-MM, got {month!r}")
    start = pd.Timestamp(f"{month}-01", tz="UTC")
    return start, start + pd.offsets.MonthBegin(1)


def previous_month(day: dt.date) -> str:
    first = day.replace(day=1)
    return (first - dt.timedelta(days=1)).strftime("%Y-%m")


def _today(tz: str = DEFAULT_TZ) -> dt.date:
    try:
        from zoneinfo import ZoneInfo
        return dt.datetime.now(ZoneInfo(tz)).date()
    except Exception:  # noqa: BLE001 - no tz database: UTC date
        return dt.datetime.now(dt.timezone.utc).date()


def _ts(value) -> pd.Timestamp | None:
    s = str(value or "").strip()
    if not s:
        return None
    m = _VID_TS_RE.match(s)
    if m:
        s = f"{m.group(1)}T{m.group(2)}:{m.group(3)}:{m.group(4)}Z"
    t = pd.to_datetime(s, utc=True, errors="coerce")
    return None if pd.isna(t) else t


def _iso(t: pd.Timestamp | None) -> str:
    return t.strftime("%Y-%m-%dT%H:%M:%SZ") if t is not None else ""


def _in(t: pd.Timestamp | None, start: pd.Timestamp, end: pd.Timestamp) -> bool:
    return t is not None and start <= t < end


def _section(status: str = "ok", **kw) -> dict:
    return {"status": status, **kw}


def _no_record(why: str, **kw) -> dict:
    return _section(NO_RECORD, detail=why, **kw)


def _error(e: BaseException, **kw) -> dict:
    return _section("error", detail=f"{type(e).__name__}: {' '.join(str(e).split())[:400]}", **kw)


def _counts(items, key) -> dict:
    out: dict = {}
    for it in items:
        k = key(it)
        out[k] = out.get(k, 0) + 1
    return dict(sorted(out.items(), key=lambda kv: (-kv[1], str(kv[0]))))


def _read_str(p: Path) -> pd.DataFrame:
    return pd.read_csv(p, dtype=str, keep_default_na=False)


# ---------------------------------------------------------------------------------------------- vintage store
@dataclass
class Vintage:
    id: str
    path: Path
    retrieved: pd.Timestamp | None

    def review(self) -> pd.DataFrame | None:
        p = self.path / "review.csv"
        if not p.is_file():
            return None
        r = _read_str(p)
        return r if {"table", "key", "country", "status"} <= set(r.columns) else None

    def feeds(self) -> dict | None:
        p = self.path / "feeds.json"
        if not p.is_file():
            return None
        return json.loads(p.read_text()).get("feeds") or {}


def load_vintages(data_dir: Path) -> list[Vintage]:
    """Every vintage under data/live/vintages, ordered by retrieval time (then id). Retrieval time: the first row of
    vintages/index.csv for the id, else feeds.json 'retrieved', else the id's own timestamp or date."""
    from .feeds import list_vintages
    root = Path(data_dir) / "live" / "vintages"
    index: dict[str, str] = {}
    if (root / "index.csv").is_file():
        for r in _read_str(root / "index.csv").to_dict("records"):
            index.setdefault(r.get("vintage_id", ""), r.get("retrieved_utc", ""))
    out = []
    for vid in list_vintages(Path(data_dir)):
        p = root / vid
        t = _ts(index.get(vid))
        if t is None and (p / "feeds.json").is_file():
            try:
                t = _ts(json.loads((p / "feeds.json").read_text()).get("retrieved"))
            except ValueError:
                t = None
        out.append(Vintage(vid, p, t or _ts(vid)))
    return sorted(out, key=lambda v: (v.retrieved or pd.Timestamp.min.tz_localize("UTC"), v.id))


def _last_by(vints: list[Vintage], end: pd.Timestamp, need: str | None = None) -> Vintage | None:
    """The last vintage retrieved before `end` (exclusive), optionally one that has file `need`."""
    c = [v for v in vints if v.retrieved is not None and v.retrieved < end and (need is None or (v.path / need).is_file())]
    return c[-1] if c else None


def _cell(r) -> tuple[str, str, str]:
    return (str(r["table"]), str(r["key"]), str(r["country"]))


def _reason_categories(reason: str) -> list[str]:
    cats = []
    for part in str(reason or "").split(";"):
        part = part.strip()
        if part:
            cats.append(part.split(":", 1)[0].strip() or part)
    return cats or ["(no reason given)"]


# ---------------------------------------------------------------------------------------------- gate holds
def gate_section(data_dir: Path, vints: list[Vintage], start: pd.Timestamp, end: pd.Timestamp) -> dict:
    from . import ledger as L
    d = Path(data_dir)
    upto = [v for v in vints if v.retrieved is not None and v.retrieved < end]
    held: dict[str, dict] = {}          # vintage id -> {cell: reason}
    run_start: dict[str, dict] = {}     # vintage id -> {cell: retrieval of the first vintage of the hold's run}
    current: dict = {}
    for v in upto:
        rv = v.review()
        if rv is None:
            continue
        h = {_cell(r): r.get("reason", "") for r in rv.to_dict("records") if r["status"] == "hold"}
        current = {c: current.get(c, v.retrieved) for c in h}
        held[v.id], run_start[v.id] = h, dict(current)
    month_v = [v for v in upto if v.retrieved >= start and v.id in held]
    led_path = L.ledger_path(d)
    ledger = L.read_ledger(d) if led_path.is_file() else None
    out = {"vintages_in_month": [v.id for v in upto if v.retrieved >= start],
           "vintages_with_review_in_month": len(month_v)}

    # holds seen in the month
    if not month_v:
        out["holds"] = _no_record("no vintage with a review.csv was retrieved in the month (no gate output)")
    else:
        prev_ids = [v.id for v in upto if v.id in held]
        seen: dict = {}
        new = set()
        for v in month_v:
            i = prev_ids.index(v.id)
            before = held[prev_ids[i - 1]] if i > 0 else {}
            for c, why in held[v.id].items():
                seen.setdefault(c, why)
                if c not in before:
                    new.add(c)
        cells = [{"table": c[0], "key": c[1], "country": c[2], "reason": seen[c], "new_in_month": c in new}
                 for c in sorted(seen)]
        out["holds"] = _section(
            cells=len(cells), new_in_month=len(new),
            by_indicator=_counts(cells, lambda x: f"{x['table']} {x['key']}"),
            by_country=_counts(cells, lambda x: x["country"]),
            by_reason=_counts([c for x in cells for c in _reason_categories(x["reason"])], lambda c: c),
            items=cells)

    # releases and analyst decisions written in the month
    if ledger is None:
        out["releases"] = _no_record(f"{led_path.relative_to(d)} does not exist (no review decision recorded)")
        out["analyst_holds"] = _no_record(f"{led_path.relative_to(d)} does not exist")
    else:
        rel, ah = [], []
        by_id = {v.id: v for v in upto}
        for r in ledger.itertuples(index=False):
            t = _ts(r.ts_utc)
            if not _in(t, start, end):
                continue
            cell = (r.table, str(r.key), r.country)
            if r.decision in ("hold", "reject"):
                ah.append({"table": r.table, "key": r.key, "country": r.country, "decision": r.decision,
                           "author": r.author, "ts_utc": r.ts_utc, "note": r.note})
                continue
            if r.decision != "apply" or r.content_sha256 or not L._approved(r):
                continue
            vid = Path(str(r.vintage_id or "")).name
            in_store = vid in held and cell in held[vid]
            if r.gate_status != "hold" and not in_store:
                continue
            if in_store:
                hs = run_start[vid].get(cell)
            else:
                cand = [v for v in upto if v.id in held and cell in held[v.id] and v.retrieved <= t]
                hs = run_start[cand[-1].id].get(cell) if cand else None
            ttr = round((t - hs).total_seconds() / 86400, 2) if hs is not None else None
            rel.append({"table": r.table, "key": r.key, "country": r.country, "released_utc": _iso(t),
                        "vintage_id": vid if vid in by_id else (vid or ""), "hold_start_utc": _iso(hs),
                        "days_to_release": ttr if ttr is not None else NO_RECORD,
                        "author": r.author, "approver": r.approver, "self_approved": r.self_approved})
        days = sorted(x["days_to_release"] for x in rel if x["days_to_release"] != NO_RECORD)
        out["releases"] = _section(
            count=len(rel), by_indicator=_counts(rel, lambda x: f"{x['table']} {x['key']}"),
            by_country=_counts(rel, lambda x: x["country"]),
            self_approved=sum(1 for x in rel if str(x["self_approved"]).lower() == "yes"),
            days_to_release={"measured": len(days),
                             "median": round(float(pd.Series(days).median()), 2) if days else NO_RECORD,
                             "max": days[-1] if days else NO_RECORD,
                             "unmeasured": len(rel) - len(days)},
            items=rel)
        out["analyst_holds"] = _section(count=len(ah), by_decision=_counts(ah, lambda x: x["decision"]), items=ah)

    # gate holds outstanding at month end
    last = next((v for v in reversed(upto) if v.id in held), None)
    if last is None:
        out["outstanding_at_month_end"] = _no_record("no vintage with a review.csv retrieved by month end")
    else:
        rv = last.review()
        upto_led = None
        if ledger is not None:
            ts = ledger["ts_utc"].map(_ts)
            upto_led = ledger[[t is not None and t < end for t in ts]]
        eff = L.effective_holds(rv, upto_led, vintage_id=last.id)
        still = sorted(c for c in held[last.id] if c in eff)
        out["outstanding_at_month_end"] = _section(
            vintage_id=last.id, count=len(still), ledger=("read" if ledger is not None else NO_RECORD),
            items=[{"table": c[0], "key": c[1], "country": c[2], "reason": held[last.id][c],
                    "held_since_utc": _iso(run_start[last.id].get(c))} for c in still])
    return out


# ---------------------------------------------------------------------------------------------- staleness
def _breach_rows(res: pd.DataFrame) -> dict:
    from .freshness import breaches
    b = breaches(res)
    return {(r["table"], str(r["key"]), r["country"], r["measure"]): r for r in b.to_dict("records")}


def staleness_section(data_dir: Path, vints: list[Vintage], start: pd.Timestamp, end: pd.Timestamp) -> dict:
    from .freshness import check_freshness, load_sla
    d = Path(data_dir)
    month_end = (end - pd.Timedelta(days=1)).date()
    prev_end = (start - pd.Timedelta(days=1)).date()
    cur_v = _last_by(vints, end, "provenance.csv")
    if cur_v is None:
        return _no_record("no vintage with a provenance.csv was retrieved by month end")
    try:
        sla = load_sla(d)
    except FileNotFoundError as e:
        return _no_record(str(e))
    cur = check_freshness(d, as_of=month_end, vintage=cur_v.id, sla=sla)
    cb = _breach_rows(cur)
    items = [{k: (None if (isinstance(v, float) and math.isnan(v)) or v is pd.NA else v) for k, v in r.items()
              if k in ("table", "key", "country", "measure", "severity", "last_date", "age_days", "max_age_days",
                       "detail")} for r in cb.values()]
    for it in items:
        it["age_days"] = int(it["age_days"]) if it["age_days"] is not None else None
    out = _section(as_of=month_end.isoformat(), vintage_id=cur_v.id, cells_checked=int(len(cur)),
                   by_status={k: int(v) for k, v in cur["status"].value_counts().items()},
                   breaches=len(cb), by_severity=_counts(cb.values(), lambda r: r["severity"]),
                   by_series=_counts(cb.values(), lambda r: f"{r['table']} {r['key']} ({r['measure']})"),
                   items=sorted(items, key=lambda x: (x["severity"], x["table"], x["key"], x["country"])))
    prev_v = _last_by(vints, start, "provenance.csv")
    if prev_v is None:
        out.update(previous=_no_record(f"no vintage retrieved by the previous month end {prev_end}"),
                   new=NO_RECORD, cleared=NO_RECORD)
        return out
    prev = check_freshness(d, as_of=prev_end, vintage=prev_v.id, sla=sla)
    pb = _breach_rows(prev)
    new = sorted(set(cb) - set(pb))
    cleared = sorted(set(pb) - set(cb))
    out.update(previous={"status": "ok", "as_of": prev_end.isoformat(), "vintage_id": prev_v.id, "breaches": len(pb)},
               new=len(new), cleared=len(cleared),
               new_items=[dict(zip(("table", "key", "country", "measure"), k)) for k in new],
               cleared_items=[dict(zip(("table", "key", "country", "measure"), k)) for k in cleared])
    return out


# ---------------------------------------------------------------------------------------------- incidents
def _feed_failures(d: Path, vints: list[Vintage], start, end) -> dict:
    items, sources = [], []
    seen = set()
    for v in vints:
        if not _in(v.retrieved, start, end):
            continue
        feeds = v.feeds()
        if feeds is None:
            continue
        sources.append(f"live/vintages/{v.id}/feeds.json")
        for feed, status in feeds.items():
            s = str(status)
            if s.startswith(("ok", "skipped")):
                continue
            key = (v.retrieved.date().isoformat(), feed, " ".join(s.split()))
            if key not in seen:
                seen.add(key)
                items.append({"pull": v.id, "retrieved_utc": _iso(v.retrieved), "feed": feed, "failure": s})
    live = d / "live"
    if (live / "feed_failures.csv").is_file() and (live / "feeds.json").is_file():
        t = _ts(json.loads((live / "feeds.json").read_text()).get("retrieved"))
        if _in(t, start, end):
            sources.append("live/feed_failures.csv")
            for r in _read_str(live / "feed_failures.csv").to_dict("records"):
                key = (t.date().isoformat(), r.get("feed", ""), " ".join(str(r.get("failure", "")).split()))
                if key not in seen:
                    seen.add(key)
                    items.append({"pull": "live (current pull)", "retrieved_utc": _iso(t), "feed": r.get("feed", ""),
                                  "failure": r.get("failure", "")})
    if not sources:
        return _no_record("no pull (vintage feeds.json or live/feed_failures.csv) retrieved in the month")
    return _section(count=len(items), sources=sources, by_feed=_counts(items, lambda x: x["feed"]), items=items)


def _restricted(d: Path, which: str) -> dict:
    applied = [f for f in ("indicators.csv", "countries.csv") if (d / f).is_file()]
    records = (d / "live" / "provenance.csv").is_file() or (d / "audit_trail.csv").is_file() or any(
        (d / "live" / "vintages").glob("*/provenance.csv"))
    if not applied or not records:
        return _no_record("no applied input files or no provenance / audit_trail.csv record to audit")
    from . import audit
    cells = getattr(audit, which)(d)
    reason = cells["reason"].map(lambda s: str(s).split(";")[0].split(" (")[0]) if len(cells) else pd.Series(dtype=str)
    return _section(count=int(len(cells)), audited="at report build time (current applied values)",
                    by_reason={k: int(v) for k, v in reason.value_counts().items()},
                    by_table={k: int(v) for k, v in cells["table"].value_counts().items()} if len(cells) else {},
                    items=[{k: str(v) for k, v in r.items() if k in ("table", "key", "country", "source", "series")}
                           for r in cells.head(200).to_dict("records")])


def _pullpack_state(d: Path) -> dict | None:
    p = d / "live" / "pullpack" / "state.json"
    if not p.is_file():
        return None
    st = json.loads(p.read_text())
    if not isinstance(st.get("steps"), dict):
        raise ValueError(f"{p}: no 'steps' object")
    return st


def _pullpack(st: dict | None, start, end, merge_stops: bool) -> dict:
    if st is None:
        return _no_record("live/pullpack/state.json does not exist (the pull pack has not run)")
    items = []
    for sid, rec in st["steps"].items():
        if rec.get("status") != "failed":
            continue
        t = _ts(rec.get("finished_utc")) or _ts(rec.get("started_utc"))
        if not _in(t, start, end):
            continue
        is_stop = sid == "nowcast" and str(rec.get("reason", "")).startswith("MergeStopped")
        if is_stop == merge_stops:
            items.append({"step": sid, "finished_utc": _iso(t), "reason": rec.get("reason", "")})
    return _section(count=len(items), note="state.json keeps only each step's latest record", items=items)


def _mapping_qa(d: Path, start, end) -> dict:
    logs = sorted((d / "live" / "events").glob("*/incremental_log.csv"))
    if not logs:
        return _no_record("no live/events/<source>/incremental_log.csv (no incremental event pull has run)")
    items, runs = [], 0
    for p in logs:
        for r in _read_str(p).to_dict("records"):
            if not _in(_ts(r.get("run_utc")), start, end):
                continue
            runs += 1
            if str(r.get("qa_breach", "")).strip().lower() in _TRUE:
                items.append({"source": r.get("source") or p.parent.name, "run_utc": r.get("run_utc", ""),
                              "status": r.get("status", ""), "unmapped_share": r.get("unmapped_share", ""),
                              "message": r.get("message", "")})
    return _section(count=len(items), runs_in_month=runs, by_source=_counts(items, lambda x: x["source"]),
                    items=items)


def incidents_section(data_dir: Path, vints: list[Vintage], start, end) -> dict:
    d = Path(data_dir)
    out = {}

    def guard(name, fn):
        try:
            out[name] = fn()
        except Exception as e:  # noqa: BLE001 - one unreadable input must not hide the others
            out[name] = _error(e)

    guard("feed_failures", lambda: _feed_failures(d, vints, start, end))
    guard("restricted_source_cells", lambda: _restricted(d, "restricted_source_cells"))
    guard("client_restricted_cells", lambda: _restricted(d, "client_restricted_cells"))
    try:
        st = _pullpack_state(d)
        out["pullpack_failures"] = _pullpack(st, start, end, merge_stops=False)
        out["nowcast_merge_stops"] = _pullpack(st, start, end, merge_stops=True)
    except Exception as e:  # noqa: BLE001
        out["pullpack_failures"] = out["nowcast_merge_stops"] = _error(e)
    guard("mapping_qa_breaches", lambda: _mapping_qa(d, start, end))
    return out


# ---------------------------------------------------------------------------------------------- coverage
def vintage_coverage(v: Vintage, ids: list[str], countries: list[str], eligible: set[str]) -> dict | None:
    """EQ-A-0055 metric on one vintage (counting as universe.missing_cell_report): None without live_inputs.csv."""
    p = v.path / "live_inputs.csv"
    if not p.is_file():
        return None
    live = _read_str(p)
    live = live.set_index(live.columns[0]).apply(pd.to_numeric, errors="coerce")
    rv = v.review()
    held = set()
    if rv is not None:
        held = {(str(r["key"]), r["country"]) for r in rv.to_dict("records")
                if r["table"] == "Inputs" and r["status"] == "hold"}
    elig = [i for i in ids if i in eligible]
    per = {}
    for n in countries:
        k = 0
        for i in elig:
            x = live.at[i, n] if (i in live.index and n in live.columns) else float("nan")
            k += bool(pd.notna(x) and (i, n) not in held)
        per[n] = {"live_eligible": k, "n_eligible": len(elig),
                  "pct_live_eligible": round(k / len(elig), 4) if elig else None}
    tot_live = sum(c["live_eligible"] for c in per.values())
    tot = len(elig) * len(countries)
    return {"vintage_id": v.id, "retrieved_utc": _iso(v.retrieved), "live_eligible": tot_live, "n_eligible_cells": tot,
            "pct_live_eligible": round(tot_live / tot, 4) if tot else None, "countries": per}


def coverage_section(data_dir: Path, vints: list[Vintage], start, end,
                     trend_months: int = DEFAULT_TREND_MONTHS) -> dict:
    from .universe import COVERAGE_MAP, LIVE_TARGET, feed_eligible_ids, target_denominator
    d = Path(data_dir)
    if not (d / COVERAGE_MAP).is_file() or not (d / "indicators.csv").is_file():
        return _no_record(f"{COVERAGE_MAP} or indicators.csv missing in {d} (the feed-eligible set is undefined)")
    eligible = feed_eligible_ids(d)
    ind = _read_str(d / "indicators.csv")
    ids = [str(i).strip() for i in ind["id"]]
    countries = [c for c in ind.columns if c not in META_COLUMNS]
    since = start - pd.DateOffset(months=max(trend_months, 1) - 1)
    trend = []
    for v in vints:
        if v.retrieved is None or not (since <= v.retrieved < end):
            continue
        c = vintage_coverage(v, ids, countries, eligible)
        if c is not None:
            c["in_month"] = bool(v.retrieved >= start)
            trend.append(c)
    n_elig = len(eligible & set(ids))
    base = {"target": LIVE_TARGET, "denominator": target_denominator(LIVE_TARGET, n_elig),
            "window_from": since.strftime("%Y-%m")}
    if n_elig == 0:
        return _no_record(f"no feed-eligible indicator in {COVERAGE_MAP}", **base)
    if not trend:
        return _no_record(f"no vintage with live_inputs.csv retrieved between {since.date()} and month end", **base)
    last = trend[-1]
    prev = [t for t in trend if not t["in_month"]]
    below = sorted(n for n, c in last["countries"].items()
                   if c["pct_live_eligible"] is None or c["pct_live_eligible"] < LIVE_TARGET - 1e-12)
    return _section(**base, latest_vintage=last["vintage_id"], desk_pct_live_eligible=last["pct_live_eligible"],
                    desk_meets_target=bool(last["pct_live_eligible"] is not None
                                           and last["pct_live_eligible"] >= LIVE_TARGET - 1e-12),
                    change_vs_previous_month_pp=(round(100 * (last["pct_live_eligible"] - prev[-1]["pct_live_eligible"]), 2)
                                                 if prev and last["in_month"] else NO_RECORD),
                    countries_meeting_target=len(countries) - len(below), countries_below_target=below,
                    vintages=len(trend), trend=trend)


# ---------------------------------------------------------------------------------------------- attestation
def attestation_section(data_dir: Path) -> dict:
    from .ledger import HAND_ENTERED, attestation_status
    d = Path(data_dir)
    if not any((d / f).is_file() for f in HAND_ENTERED):
        return _no_record(f"none of {', '.join(sorted(HAND_ENTERED))} exists")
    cells = attestation_status(d)
    by_table: dict = {}
    for c in cells:
        t = by_table.setdefault(c["table"], {"attested": 0, "unattested": 0, "self_approved": 0})
        t["attested" if c["attested"] == "yes" else "unattested"] += 1
        t["self_approved"] += c["attested"] == "yes" and str(c["self_approved"]).lower() == "yes"
    att = sum(t["attested"] for t in by_table.values())
    return _section(cells=len(cells), attested=att, unattested=len(cells) - att,
                    self_approved=sum(t["self_approved"] for t in by_table.values()), by_table=by_table,
                    status_at="report build time (current content of the hand-entered files)")


# ---------------------------------------------------------------------------------------------- build
def _findings(rep: dict) -> list[str]:
    out = []
    if not rep["vintages_in_month"]:
        out.append(f"no pull this month: no vintage retrieved in {rep['month']} (data/live/vintages)")
    st = rep["staleness"]
    if st["status"] == "ok" and st["breaches"]:
        out.append(f"staleness: {st['breaches']} freshness SLA breach(es) at month end")
    for name, s in rep["incidents"].items():
        if name != "client_restricted_cells" and s["status"] == "ok" and s.get("count"):
            out.append(f"incident: {s['count']} {name.replace('_', ' ')}")
    cov = rep["coverage"]
    if cov["status"] == "ok" and not cov["desk_meets_target"]:
        out.append(f"coverage: desk feed-eligible live share {cov['desk_pct_live_eligible']:.1%} below target "
                   f"{cov['target']:.0%} ({cov['latest_vintage']})")
    return out


def _errors(rep: dict) -> list[str]:
    out = []

    def walk(name, s):
        if isinstance(s, dict):
            if s.get("status") == "error":
                out.append(f"{name}: {s.get('detail', '')}")
            for k, v in s.items():
                if isinstance(v, dict):
                    walk(f"{name}.{k}", v)
    for k in ("gate", "staleness", "incidents", "coverage", "attestation"):
        walk(k, rep.get(k))
    return out


def _no_records(rep: dict) -> list[str]:
    out = []

    def walk(name, s):
        if isinstance(s, dict):
            if s.get("status") == NO_RECORD:
                out.append(name)
            for k, v in s.items():
                if isinstance(v, dict):
                    walk(f"{name}.{k}", v)
    for k in ("gate", "staleness", "incidents", "coverage", "attestation"):
        walk(k, rep.get(k))
    return out


def build(data_dir: str | Path = "data", month: str | None = None, now: dt.datetime | None = None,
          trend_months: int = DEFAULT_TREND_MONTHS) -> dict:
    """The report as a dict (SCHEMA). Reads only. Raises FileNotFoundError when data_dir is not a folder."""
    d = Path(data_dir)
    if not d.is_dir():
        raise FileNotFoundError(f"data folder {d} not found")
    month = month or previous_month(_today())
    start, end = month_bounds(month)
    now = now or dt.datetime.now(dt.timezone.utc)
    vints = load_vintages(d)
    rep = {"schema": SCHEMA, "ticket": TICKET, "month": month, "window_utc": [_iso(start), _iso(end)],
           "generated_utc": now.astimezone(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ"),
           "data_dir": str(d), "vintages_total": len(vints),
           "vintages_in_month": [v.id for v in vints if _in(v.retrieved, start, end)]}

    def guard(fn, *a):
        try:
            return fn(*a)
        except Exception as e:  # noqa: BLE001 - a section that cannot be read is reported, the rest still runs
            return _error(e)

    rep["gate"] = guard(gate_section, d, vints, start, end)
    rep["staleness"] = guard(staleness_section, d, vints, start, end)
    rep["incidents"] = incidents_section(d, vints, start, end)
    rep["coverage"] = guard(coverage_section, d, vints, start, end, trend_months)
    rep["attestation"] = guard(attestation_section, d)
    rep["findings"] = _findings(rep)
    rep["errors"] = _errors(rep)
    rep["no_record"] = _no_records(rep)
    rep["exit_code"] = EXIT_ERROR if rep["errors"] else (EXIT_FINDINGS if rep["findings"] else EXIT_OK)
    return rep


# ---------------------------------------------------------------------------------------------- markdown
def _one(v) -> str:
    """One line of text (SEC-A-008 L3): CR, LF and other whitespace runs collapse to one space, so a value read from the
    data folder (a gate reason, a feed name, an error text) cannot start a heading or list item of its own."""
    return " ".join(str(v if v is not None else "").split())


def _md_cell(v) -> str:
    s = _one(v).replace("|", "\\|")
    return "'" + s if s[:1] in ("=", "+", "-", "@") and not re.match(r"^-?\d", s) else s


def _table(rows: list[dict], cols: list[str], limit: int = 50) -> list[str]:
    if not rows:
        return ["(none)", ""]
    out = ["| " + " | ".join(cols) + " |", "|" + "---|" * len(cols)]
    out += ["| " + " | ".join(_md_cell(r.get(c, "")) for c in cols) + " |" for r in rows[:limit]]
    if len(rows) > limit:
        out.append(f"\n... {len(rows) - limit} more in dq_report.json")
    return out + [""]


def _counts_line(d: dict) -> str:
    return ", ".join(f"{_one(k)} {_one(v)}" for k, v in d.items()) if d else "(none)"


def _status_line(s: dict) -> str | None:
    if s.get("status") == NO_RECORD:
        return f"**No record**: {_one(s.get('detail', ''))}"
    if s.get("status") == "error":
        return f"**Error**: {_one(s.get('detail', ''))}"
    return None


def render_markdown(rep: dict) -> str:
    L = [f"# Data quality report {rep['month']}", "",
         f"Generated {rep['generated_utc']} by `python -m econquest.ingestion.dq_report build` ({rep['ticket']}). "
         f"Window {rep['window_utc'][0]} to {rep['window_utc'][1]} (UTC, end exclusive). Data folder `{rep['data_dir']}`, "
         f"{rep['vintages_total']} vintage(s) in the store. Read-only; missing inputs are shown as \"no record\", "
         "never as zero.", "",
         f"**Exit code {rep['exit_code']}** ({EXIT_MEANING[rep['exit_code']]}).", ""]
    if rep["findings"]:
        L += ["## Findings", ""] + [f"- {_one(f)}" for f in rep["findings"]] + [""]
    if rep["errors"]:
        L += ["## Errors", ""] + [f"- {_one(e)}" for e in rep["errors"]] + [""]
    if rep["no_record"]:
        L += ["No record for: " + ", ".join(rep["no_record"]) + ".", ""]

    g = rep["gate"]
    L += ["## 1. Gate holds and releases", ""]
    if (m := _status_line(g)):
        L += [m, ""]
    else:
        L += [f"Vintages retrieved in the month: {len(g['vintages_in_month'])} "
              f"({', '.join(g['vintages_in_month']) or 'none'}).", ""]
        h = g["holds"]
        L += ["### Holds seen in the month", ""]
        if (m := _status_line(h)):
            L += [m, ""]
        else:
            L += [f"{h['cells']} cell(s) held, {h['new_in_month']} new in the month.", "",
                  f"- By reason: {_counts_line(h['by_reason'])}", f"- By indicator: {_counts_line(h['by_indicator'])}",
                  f"- By country: {_counts_line(h['by_country'])}", ""]
        r = g["releases"]
        L += ["### Releases (approved apply on a gate-held cell)", ""]
        if (m := _status_line(r)):
            L += [m, ""]
        else:
            t = r["days_to_release"]
            L += [f"{r['count']} release(s), {r['self_approved']} self-approved. Days to release: median {t['median']}, "
                  f"max {t['max']} ({t['measured']} measured, {t['unmeasured']} without a hold in the vintage store).", ""]
            L += _table(r["items"], ["table", "key", "country", "hold_start_utc", "released_utc", "days_to_release",
                                     "author", "approver"])
        a = g["analyst_holds"]
        L += ["### Analyst hold / reject decisions written in the month", ""]
        L += [m, ""] if (m := _status_line(a)) else [f"{a['count']} ({_counts_line(a['by_decision'])}).", ""]
        o = g["outstanding_at_month_end"]
        L += ["### Gate holds outstanding at month end", ""]
        if (m := _status_line(o)):
            L += [m, ""]
        else:
            L += [f"{o['count']} cell(s) still held in vintage {o['vintage_id']} (ledger: {o['ledger']}).", ""]
            L += _table(o["items"], ["table", "key", "country", "held_since_utc", "reason"])

    s = rep["staleness"]
    L += ["## 2. Staleness (freshness SLA, EQ-A-0052)", ""]
    if (m := _status_line(s)):
        L += [m, ""]
    else:
        L += [f"As of {s['as_of']} on vintage {s['vintage_id']}: {s['cells_checked']} cell checks, "
              f"{s['breaches']} breach(es) ({_counts_line(s['by_severity'])}); status {_counts_line(s['by_status'])}.",
              "", f"New since the previous month end: {s['new']}; cleared: {s['cleared']}"
              + (f" (previous: {s['previous']['breaches']} breach(es) on {s['previous']['vintage_id']} "
                 f"as of {s['previous']['as_of']})." if s["previous"].get("status") == "ok"
                 else f" ({s['previous'].get('detail', '')})."), ""]
        L += _table(s["items"], ["severity", "table", "key", "country", "measure", "age_days", "max_age_days"])

    L += ["## 3. Incidents", ""]
    names = {"feed_failures": "Feed failures", "restricted_source_cells": "Restricted-source cells (finding)",
             "client_restricted_cells": "Client-output restricted cells (by licence, informational)",
             "pullpack_failures": "Pull pack step failures", "mapping_qa_breaches": "Event mapping-QA breaches",
             "nowcast_merge_stops": "Nowcast merge stops"}
    rows = []
    for k, label in names.items():
        x = rep["incidents"].get(k, {})
        val = x.get("count") if x.get("status") == "ok" else (NO_RECORD if x.get("status") == NO_RECORD else "error")
        extra = x.get("detail", "") if x.get("status") != "ok" else _counts_line(
            x.get("by_feed") or x.get("by_reason") or x.get("by_source") or {})
        rows.append({"incident": label, "count": val, "detail": extra})
    L += _table(rows, ["incident", "count", "detail"])
    for k in ("feed_failures", "pullpack_failures", "nowcast_merge_stops", "mapping_qa_breaches"):
        x = rep["incidents"].get(k, {})
        if x.get("status") == "ok" and x.get("items"):
            L += [f"### {names[k]}", ""] + _table(x["items"], list(x["items"][0].keys()))

    c = rep["coverage"]
    L += ["## 4. Coverage trend (EQ-A-0055)", ""]
    if (m := _status_line(c)):
        L += [m, ""]
    else:
        L += [f"Target: {c['denominator']}. Latest vintage {c['latest_vintage']}: desk "
              f"{c['desk_pct_live_eligible']:.1%} ({'meets' if c['desk_meets_target'] else 'below'} target); change vs "
              f"previous month: {c['change_vs_previous_month_pp']} pp; {c['countries_meeting_target']} countr(ies) "
              f"meet the target.", ""]
        L += _table([{"vintage": t["vintage_id"], "retrieved_utc": t["retrieved_utc"],
                      "in_month": "yes" if t["in_month"] else "", "live_eligible": t["live_eligible"],
                      "n_eligible_cells": t["n_eligible_cells"],
                      "desk_pct": f"{t['pct_live_eligible']:.1%}" if t["pct_live_eligible"] is not None else ""}
                     for t in c["trend"]], ["vintage", "retrieved_utc", "in_month", "live_eligible",
                                            "n_eligible_cells", "desk_pct"])
        last = c["trend"][-1]["countries"]
        L += ["Per country (latest vintage, trend in dq_report.json):", ""]
        L += _table([{"country": n, "live_eligible": v["live_eligible"], "n_eligible": v["n_eligible"],
                      "pct": f"{v['pct_live_eligible']:.1%}" if v["pct_live_eligible"] is not None else ""}
                     for n, v in last.items()], ["country", "live_eligible", "n_eligible", "pct"], limit=200)

    a = rep["attestation"]
    L += ["## 5. Attestation of hand-entered cells", ""]
    if (m := _status_line(a)):
        L += [m, ""]
    else:
        L += [f"{a['attested']} attested, {a['unattested']} unattested of {a['cells']} cell(s) "
              f"({a['self_approved']} attested by flagged self-approval); {a['status_at']}.", ""]
        L += _table([{"table": k, **v} for k, v in a["by_table"].items()],
                    ["table", "attested", "unattested", "self_approved"])
    return "\n".join(L).rstrip() + "\n"


# ---------------------------------------------------------------------------------------------- output
def _jsonable(o):
    if isinstance(o, dict):
        return {str(k): _jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [_jsonable(v) for v in o]
    if hasattr(o, "item") and not isinstance(o, (str, bytes)):
        try:
            return o.item()
        except (ValueError, AttributeError):
            return str(o)
    if o is pd.NA or (isinstance(o, float) and math.isnan(o)):
        return None
    return o


def _atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "w") as f:
            f.write(text)
        os.chmod(tmp, 0o644)
        os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def default_out(data_dir: Path, month: str) -> Path:
    return Path(data_dir).resolve().parent / "outputs" / "dq" / month


def write_report(rep: dict, out_dir: Path, data_dir: Path) -> tuple[Path, Path]:
    out_dir, d = Path(out_dir).resolve(), Path(data_dir).resolve()
    if out_dir == d or d in out_dir.parents:
        raise ValueError(f"--out {out_dir} is inside the data folder {d}: the report never writes there")
    md, js = out_dir / "dq_report.md", out_dir / "dq_report.json"
    _atomic_write(js, json.dumps(_jsonable(rep), indent=1, sort_keys=False, default=str) + "\n")
    _atomic_write(md, render_markdown(rep))
    return md, js


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.dq_report",
                                 description="Monthly data quality report (EQ-A-0065); exit 0 clean, 2 findings, 1 error")
    sub = ap.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("build", help="build the report for one month")
    b.add_argument("--data", default="data", help="econquest data folder (default: data)")
    g = b.add_mutually_exclusive_group()
    g.add_argument("--month", help="YYYY-MM (default: the month before --as-of)")
    g.add_argument("--as-of", help="run date YYYY-MM-DD; the report covers the month before it "
                                   f"(default: today in {DEFAULT_TZ})")
    b.add_argument("--out", help="output folder (default: <data>/../outputs/dq/<YYYY-MM>)")
    b.add_argument("--json", action="store_true", help="print the JSON report to stdout")
    b.add_argument("--trend-months", type=int, default=DEFAULT_TREND_MONTHS,
                   help=f"coverage trend window in months (default {DEFAULT_TREND_MONTHS})")
    a = ap.parse_args(argv)
    try:
        if a.as_of:
            month = previous_month(dt.date.fromisoformat(a.as_of))
        else:
            month = a.month or previous_month(_today())
        month_bounds(month)
        d = Path(a.data)
        rep = build(d, month, trend_months=a.trend_months)
        md, js = write_report(rep, Path(a.out) if a.out else default_out(d, month), d)
    except (ValueError, FileNotFoundError, OSError) as e:
        print(f"[dq_report] error: {e}", file=sys.stderr)
        return EXIT_ERROR
    if a.json:
        print(json.dumps(_jsonable(rep), indent=1, default=str))
    else:
        print(f"[dq_report] {month}: exit {rep['exit_code']}; {len(rep['findings'])} finding(s), "
              f"{len(rep['errors'])} error(s), no record: {', '.join(rep['no_record']) or 'none'}")
        for f in rep["findings"] + [f"ERROR {e}" for e in rep["errors"]]:
            print(f"  - {f}")
        print(f"[dq_report] wrote {md} and {js}")
    return rep["exit_code"]


if __name__ == "__main__":
    sys.exit(main())
