"""Real-data day rehearsal (EQ-A-0138): every way the first real Mac pass can go wrong, played against copies, each
ending in one plain message and a safe state. Demo row M21 (C-0166). Runbook: docs/runbooks/A-real-data-day.md.

    python -m econquest.ingestion.rehearsal run [--data data] [--inbox team/inbox] [--zips DIR] [--current ZIP]
                                                [--quick] [--keep] [--json]

Everything runs in a private temporary folder: data/ is copied there first, and neither data/ nor data/mvp is ever
written (the last row re-hashes them to prove it). No network: the UCDP row unsets the token variable for its run.

Rows
    R  replay     each recorded pull in team/inbox/pull-*: the landing check (report.json/state.json) and the Mac-pass
                  landing check (review.csv, report.json, pullpack.log) against the copy
    S  SYNTHETIC  fixtures made from the newest recorded pull, labelled SYNTHETIC (a SYNTHETIC.txt file in the folder and
                  "synthetic" in report.json; values are the recorded ones, only the pack's metadata is changed):
                  first pass (dry run), partial pull, stale feed, corrupt vintage, missing UCDP token, wrong folder
                  (the ~/Downloads release-data/ copy), interrupted landing, interrupted apply, interrupted pull
    U  upgrade    (--zips DIR) each shipped econquest-macos-<v>.zip since 0.4.2 installed into a temporary HOME with its
                  own install.sh (file copy only), used (review ledger, outputs), then upgraded with the current tree's
                  release zip (built with scripts/build_release.py, or --current): data/ backed up, nothing lost, review
                  ledger byte-identical and verifying; a shipped version without a zip is listed as missing

Each row is ok when the outcome is the expected one, the message is plain (no Python traceback) and the state is safe
(the copy's data files and data/mvp unchanged, no half-built candidate or old copy left). Exit 0 every row ok, 1 not.
--quick leaves out the rows that rebuild data/mvp (about 25 s each).
"""
from __future__ import annotations

import argparse
import contextlib
import datetime as dt
import hashlib
import io
import json
import os
import re
import shlex
import shutil
import subprocess
import sys
import tempfile
import traceback
import zipfile
from pathlib import Path

from .. import __version__

TICKET = "EQ-A-0138"
ROOT = Path(__file__).resolve().parents[2]
SYNTHETIC = "SYNTHETIC rehearsal fixture (EQ-A-0138): recorded values, pack metadata changed; never a real upload"
# shipped macOS zips since 0.4.2 (team/board/C.csv: EQ-C-0090 0.4.2, EQ-C-0096 0.5.0, then 0.6.0 ... 0.10.0)
SHIPPED = ("0.4.2", "0.5.0", "0.6.0", "0.7.0", "0.8.0", "0.9.0", "0.10.0")
SAFE_FILES = ("indicators.csv", "countries.csv", "audit_trail.csv", "live/review.csv", "live/provenance.csv",
              "mvp/manifest.json", "mvp/provenance.csv", "mvp/gate_report.json")
MANAGED = ("assumptions.json", "limits.json", "scenarios.json", "rulebook.csv", "playbook.csv", "compliance.json")
UCDP_ENV = "UCDP_API_TOKEN"


class Row(dict):
    """id, kind, name, expect, got, message, ok."""


def _sha(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def fingerprint(data_dir: Path) -> dict:
    """sha256 of the files a landing or apply must never half-change, plus leftovers of a stopped mvp swap."""
    d = Path(data_dir)
    fp = {rel: (_sha(d / rel) if (d / rel).is_file() else None) for rel in SAFE_FILES}
    fp["_leftovers"] = sorted(p.name for p in d.glob(".mvp-*")) if d.is_dir() else []
    return fp


def _flat(s, n: int = 220) -> str:
    return " ".join(str(s).split())[:n]


def _first_line(*texts) -> str:
    for t in texts:
        for line in str(t or "").splitlines():
            if line.strip() and not line.startswith(("  ", "\t")):
                return _flat(line)
    return ""


@contextlib.contextmanager
def _env(**kv):
    """Set (value) or unset (None) environment variables for one call."""
    old = {k: os.environ.get(k) for k in kv}
    try:
        for k, v in kv.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v
        yield
    finally:
        for k, v in old.items():
            if v is None:
                os.environ.pop(k, None)
            else:
                os.environ[k] = v


@contextlib.contextmanager
def _patched(obj, name, value):
    old = getattr(obj, name)
    setattr(obj, name, value)
    try:
        yield
    finally:
        setattr(obj, name, old)


def call(fn, *args, **kw) -> dict:
    """Run fn in-process with stdout/stderr captured. {code, out, err, exc, traceback}: `traceback` is true when an
    exception escaped (what Sam would see as a Python traceback) or one was printed."""
    out, err = io.StringIO(), io.StringIO()
    code, exc, tb = None, None, False
    with contextlib.redirect_stdout(out), contextlib.redirect_stderr(err):
        try:
            code = fn(*args, **kw)
        except SystemExit as e:
            code = e.code if isinstance(e.code, int) else (0 if e.code is None else 1)
        except BaseException as e:  # noqa: BLE001 - recorded: the row fails on it
            exc, tb = e, True
            err.write(traceback.format_exc())
    o, e2 = out.getvalue(), err.getvalue()
    return {"code": code, "out": o, "err": e2, "exc": exc, "traceback": tb or "Traceback (most recent call last)" in o + e2}


# ------------------------------------------------------------------------------------------------ fixtures

def _ignore(dirpath, names):
    """Leave out a stopped swap's leftovers, caches, and hidden folders (another session's build-aside folders, which
    come and go while the copy runs)."""
    return [n for n in names if n == "__pycache__" or n.startswith((".mvp-candidate-", ".mvp-old-"))
            or (n.startswith(".") and (Path(dirpath) / n).is_dir())]


class LinkedSource(ValueError):
    """The source data folder holds a symbolic link (AGENT-09 R-L1): the rehearsal copies only real files."""


def _links(src: Path) -> list[str]:
    out = []
    for root, dirs, files in os.walk(src):            # os.walk does not follow directory links
        for n in dirs + files:
            p = Path(root) / n
            if p.is_symlink():
                out.append(p.relative_to(src).as_posix())
    return out


def stage_data(src: Path, dest: Path, tries: int = 3) -> Path:
    """Copy a data folder (read only on src). Refuses (LinkedSource) a source that holds any symbolic link, so the
    chmod below and the tamper rows can only touch the copy (R-L1; the same rule as mvp_dataset's frozen files). Other
    sessions write data/ at the same time: a file that vanishes while it is copied is retried, then left out
    (FileNotFoundError only; any other copy error is raised)."""
    links = _links(src)
    if links:
        raise LinkedSource(f"{src} holds symbolic links ({', '.join(links[:5])}): the rehearsal copies only real files; "
                           "replace the links with the files themselves")
    for attempt in range(tries):
        try:
            shutil.copytree(src, dest, symlinks=True, ignore=_ignore, dirs_exist_ok=attempt > 0)
            break
        except shutil.Error as e:
            gone = [x for x in e.args[0] if not Path(x[0]).exists()]
            if len(gone) != len(e.args[0]):
                raise
            if attempt == tries - 1:
                break                                    # only vanished files left: the copy is what exists now
    for p in dest.rglob("*"):                            # vintages and snapshots are 0o444: the copy may be tampered
        if p.is_symlink():                               # never chmod through a link (R-L1)
            continue
        with contextlib.suppress(OSError):
            os.chmod(p, 0o755 if p.is_dir() else 0o644)
    return dest


def recorded_pulls(inbox_root: Path) -> list[Path]:
    return sorted(p for p in Path(inbox_root).glob("pull-*") if p.is_dir())


def _vintage_id(t: dt.datetime) -> str:
    stamp = t.strftime("%Y-%m-%dT%H%M%SZ")
    return f"{stamp}-{hashlib.sha256(('SYNTHETIC' + stamp).encode()).hexdigest()[:8]}"


def synthetic_base(pulls: list[Path], dest: Path, now: dt.datetime) -> tuple[Path, str] | None:
    """A SYNTHETIC Mac-pass upload from the newest recorded pull with review.csv and report.json: the recorded review and
    log, report.json re-stamped as a finished pack of this econquest version generated now, and a SYNTHETIC.txt
    label. Returns (folder, vintage id one minute before now), or None when no recorded pull has both files."""
    src = next((p for p in reversed(pulls) if (p / "review.csv").is_file() and (p / "report.json").is_file()), None)
    if src is None:
        return None
    dest.mkdir(parents=True)
    shutil.copyfile(src / "review.csv", dest / "review.csv")
    if (src / "pullpack.log").is_file():
        shutil.copyfile(src / "pullpack.log", dest / "pullpack.log")
    else:
        (dest / "pullpack.log").write_text(f"{SYNTHETIC}\n", encoding="utf-8")
    rep = json.loads((src / "report.json").read_text(encoding="utf-8"))
    rep.update(econquest_version=__version__, generated_utc=now.strftime("%Y-%m-%dT%H:%M:%SZ"), synthetic=SYNTHETIC,
               synthetic_from=src.name)
    (dest / "report.json").write_text(json.dumps(rep, indent=1) + "\n", encoding="utf-8")
    (dest / "SYNTHETIC.txt").write_text(f"{SYNTHETIC}\nfrom team/inbox/{src.name}\n", encoding="utf-8")
    return dest, _vintage_id(now - dt.timedelta(minutes=1))


def variant(base: Path, dest: Path, edit) -> Path:
    shutil.copytree(base, dest)
    edit(dest)
    return dest


def _edit_report(fn):
    def edit(d: Path):
        p = d / "report.json"
        rep = json.loads(p.read_text(encoding="utf-8"))
        fn(rep)
        p.write_text(json.dumps(rep, indent=1) + "\n", encoding="utf-8")
    return edit


def _truncate_review(d: Path) -> None:
    lines = (d / "review.csv").read_text(encoding="utf-8").splitlines(True)
    (d / "review.csv").write_text("".join(lines[: max(2, len(lines) // 2)]), encoding="utf-8")


def _set_step_status(status: str):
    def f(rep):
        steps = rep.get("steps") or []
        if steps:
            steps[0]["status"] = status
    return f


# ------------------------------------------------------------------------------------------------ the rehearsal

class Rehearsal:
    def __init__(self, data: Path, inbox: Path, work: Path, now: dt.datetime, out=print):
        self.src, self.inbox, self.work, self.now, self.out = Path(data), Path(inbox), Path(work), now, out
        self.rows: list[Row] = []
        self.root = self.work / "root"
        self.data = self.root / "data"
        self.pristine = self.work / "pristine" / "data"           # one copy of data/; every other copy is made from it

    def row(self, rid, kind, name, expect, got, message, ok) -> Row:
        r = Row(id=rid, kind=kind, name=name, expect=expect, got=got, message=_flat(message, 600), ok=bool(ok))
        self.rows.append(r)
        self.out(f"{rid:<4} {'ok ' if r['ok'] else 'BAD'} {kind:<9} {name:<46} {got:<22} {r['message'][:400]}")
        return r

    def safe(self, before: dict, data: Path | None = None) -> tuple[bool, str]:
        after = fingerprint(data or self.data)
        if after == before:
            return True, ""
        changed = [k for k in before if before.get(k) != after.get(k)]
        return False, f"STATE CHANGED: {', '.join(changed)}"

    def judged(self, rid, kind, name, expect_codes, needle, r, before, data=None):
        """A CLI row: expected exit code, the needle in the message, no traceback, safe state."""
        msg = _first_line(r["err"], r["out"]) if r["code"] not in (0,) else _first_line(r["out"], r["err"])
        ok_safe, why = self.safe(before, data)
        found = (needle is None) or (needle.lower() in (r["out"] + r["err"]).lower())
        ok = (r["code"] in expect_codes) and found and not r["traceback"] and ok_safe
        got = "TRACEBACK" if r["traceback"] else f"exit {r['code']}"
        return self.row(rid, kind, name, "exit " + "/".join(map(str, expect_codes)), got,
                        (why + " " if why else "") + (msg or "(no message)") + ("" if found else f" [expected '{needle}']"), ok)

    # ---------------------------------------------------------------------------------------- R rows
    def replay(self, pulls: list[Path]) -> None:
        from . import landing as LC, macpass_landing as MP
        n = 0
        for p in pulls:
            rep, st = p / "report.json", p / "state.json"
            if rep.is_file() or st.is_file():
                n += 1
                before = fingerprint(self.data)
                args = ["check", "--data", str(self.data), "--out", str(self.work / "landing" / p.name)]
                args += ["--report", str(rep)] if rep.is_file() else ["--state", str(st)]
                r = call(LC.main, args)
                summ = ""
                lr = self.work / "landing" / p.name / LC.REPORT_JSON
                if lr.is_file():
                    s = json.loads(lr.read_text())["summary"]
                    summ = "steps: " + ", ".join(f"{k} {v}" for k, v in s.items() if v)
                r["out"] = (summ + "\n" + r["out"]) if summ else r["out"]
                self.judged(f"R{n}", "replay", f"{p.name} landing check", (0, 2), None, r, before)
            n += 1
            before = fingerprint(self.data)
            r = call(MP.main, ["check", "--inbox", str(p), "--root", str(self.root), "--out", str(self.work / "macpass" / p.name)])
            self.judged(f"R{n}", "replay", f"{p.name} Mac-pass check", (0, 2, 1), None, r, before)
        if not pulls:
            self.row("R0", "replay", "recorded pulls", "at least one", "none", f"no pull-* folder under {self.inbox}", True)

    # ---------------------------------------------------------------------------------------- S rows
    def synthetic(self, pulls: list[Path], quick: bool) -> None:
        from . import macpass_landing as MP
        syn = self.work / "synthetic"
        made = synthetic_base(pulls, syn / "base", self.now)
        root = str(self.root)

        def mp(rid, name, folder, codes, needle, cmd="check", extra=()):
            before = fingerprint(self.data)
            r = call(MP.main, [cmd, "--inbox", str(folder), "--root", root, "--out", str(self.work / "macpass" / folder.name),
                               "--vintage-id", vid, *extra])
            return self.judged(rid, "SYNTHETIC", name, codes, needle, r, before)

        if made is None:
            self.row("S0", "SYNTHETIC", "fixtures", "a recorded pull with review.csv", "none",
                     "no recorded pull has review.csv and report.json: Mac-pass rows not run", True)
        else:
            base, vid = made
            if not quick:
                mp("S1", "first pass, dry run (data/mvp kept)", base, (0,), "dry run", cmd="run", extra=("--dry-run",))
            mp("S2", "partial pull: pullpack.log missing", variant(base, syn / "s2", lambda d: (d / "pullpack.log").unlink()),
               (2,), "partial upload")
            mp("S3", "partial pull: a step still running", variant(base, syn / "s3", _edit_report(_set_step_status("running"))),
               (2,), "had not finished")
            mp("S4", "partial pull: review.csv cut in half", variant(base, syn / "s4", _truncate_review), (2,), "partial upload")
            mp("S5", "stale feed: pack from econquest 0.4.2",
               variant(base, syn / "s5", _edit_report(lambda r: r.update(econquest_version="0.4.2"))), (2,), "stale upload")
            cur = json.loads((self.data / "mvp" / "manifest.json").read_text()).get("vintage_id", "") \
                if (self.data / "mvp" / "manifest.json").is_file() else ""
            if cur:
                before = fingerprint(self.data)
                old = re.sub(r"-[0-9a-f]{8}$", "-00000000", cur)
                r = call(MP.main, ["check", "--inbox", str(base), "--root", root, "--out", str(self.work / "macpass" / "s6"),
                                   "--vintage-id", old])
                self.judged("S6", "SYNTHETIC", "stale feed: vintage not newer than data/mvp", (2,), "not newer", r, before)
            mp("S7", "corrupt upload: report.json cut short",
               variant(base, syn / "s7", lambda d: (d / "report.json").write_bytes((d / "report.json").read_bytes()[:150])),
               (1,), "not readable json")
            mp("S8", "corrupt upload: SHA256SUMS mismatch",
               variant(base, syn / "s8", lambda d: (d / "SHA256SUMS").write_text("0" * 64 + "  review.csv\n")), (1,),
               "hash mismatch")
            mp("S9", "corrupt upload: report.json steps damaged",
               variant(base, syn / "s9", _edit_report(lambda r: r.update(steps="damaged"))), (1,), "damaged")
            if not quick:
                self.interrupted_landing(base, vid)
        self.corrupt_vintage()
        self.landing_partial(pulls)
        self.missing_token()
        self.interrupted_pull()
        self.wrong_folder()
        self.interrupted_apply()

    def interrupted_landing(self, base: Path, vid: str) -> None:
        from . import macpass_landing as MP
        before = fingerprint(self.data)

        def boom(src, dst):
            if Path(dst).name == "mvp":                      # the candidate -> data/mvp rename
                raise KeyboardInterrupt
            os.rename(src, dst)
        with _patched(MP, "_rename", boom):
            r = call(MP.main, ["run", "--inbox", str(base), "--root", str(self.root), "--out",
                               str(self.work / "macpass" / "s10"), "--vintage-id", vid])
        self.judged("S10", "SYNTHETIC", "interrupted landing (Ctrl-C at the swap)", (1,), "interrupted", r, before)
        # a hard kill between the two renames: data/mvp moved aside, never put in place
        before = fingerprint(self.data)
        mvp = self.data / "mvp"
        os.rename(mvp, self.data / f".mvp-old-{vid}")
        r = call(MP.recover_interrupted_swap, self.data, mvp)
        r["out"] = str(r["code"])
        ok_safe, why = self.safe(before)
        self.row("S11", "SYNTHETIC", "landing killed between renames, next start", "data/mvp put back",
                 "TRACEBACK" if r["traceback"] else ("recovered" if r["code"] else "not recovered"),
                 why or r["code"] or "data/mvp left missing", bool(r["code"]) and ok_safe and not r["traceback"])

    def corrupt_vintage(self) -> None:
        """A fetch vintage and a frozen input snapshot with one byte changed, in a separate copy."""
        from . import feeds as F, replay as RP
        d = stage_data(self.pristine, self.work / "corrupt" / "data")
        vids = F.list_vintages(d)
        if not vids:
            self.row("S12", "SYNTHETIC", "corrupt vintage", "refused", "no vintage", f"no fetch vintage under {d}", True)
        else:
            v = F.vintage_path(d, vids[-1])
            f = sorted(q for q in v.iterdir() if q.is_file() and not q.is_symlink())[0]
            f.write_bytes(f.read_bytes() + b"\n")
            before = fingerprint(d)
            r = call(F.apply_vintage, d, vids[-1], author="SYNTHETIC rehearsal")
            plain = isinstance(r["exc"], ValueError) and "failed verification" in str(r["exc"])
            ok_safe, why = self.safe(before, d)
            self.row("S12", "SYNTHETIC", "corrupt vintage: apply refuses", "refused, nothing applied",
                     "refused" if plain else ("TRACEBACK" if r["exc"] else f"exit {r['code']}"),
                     why or _flat(r["exc"]), plain and ok_safe)
        try:
            snap = RP.snapshot_path(d, RP._read_index(d)[-1]["vintage_id"]) if RP._read_index(d) else None
        except (FileNotFoundError, ValueError):
            snap = None
        if snap is None:
            self.row("S13", "SYNTHETIC", "corrupt frozen snapshot", "refused", "no snapshot", "no frozen input snapshot", True)
            return
        f = sorted(q for q in snap.rglob("*") if q.is_file() and not q.is_symlink() and q.name != RP.MANIFEST)[0]
        f.write_bytes(f.read_bytes() + b"\n")
        out = self.work / "corrupt" / "replay-out"
        r = call(RP.materialize_vintage, d, RP._read_index(d)[-1]["vintage_id"], out)
        plain = isinstance(r["exc"], RP.VintageIntegrityError)
        self.row("S13", "SYNTHETIC", "corrupt frozen snapshot: replay refuses", "refused, no replay folder",
                 "refused" if plain else ("TRACEBACK" if r["exc"] else "built"),
                 _flat(r["exc"]) + ("" if not out.exists() else " [partial replay folder left]"), plain and not out.exists())

    def landing_partial(self, pulls: list[Path]) -> None:
        """A state.json where nothing finished (the pack stopped at its first step), and one cut short."""
        from . import landing as LC
        src = next((p / "state.json" for p in reversed(pulls) if (p / "state.json").is_file()), None)
        if src is None:
            self.row("S14", "SYNTHETIC", "partial pull: landing check", "partial", "no state.json", "no recorded state.json", True)
            return
        st = json.loads(src.read_text(encoding="utf-8"))
        for rec in (st.get("steps") or {}).values():
            if isinstance(rec, dict):
                rec.update(status="pending", artifacts={}, reason="")
        st["synthetic"] = SYNTHETIC
        d = self.work / "synthetic" / "s14"; d.mkdir(parents=True)
        (d / "state.json").write_text(json.dumps(st, indent=1), encoding="utf-8")
        before = fingerprint(self.data)
        r = call(LC.main, ["check", "--data", str(self.data), "--state", str(d / "state.json"), "--out", str(d / "out")])
        self.judged("S14", "SYNTHETIC", "partial pull: nothing finished (landing)", (2,), "not landed", r, before)
        d = self.work / "synthetic" / "s15"; d.mkdir(parents=True)
        (d / "state.json").write_bytes(src.read_bytes()[:200])
        r = call(LC.main, ["check", "--data", str(self.data), "--state", str(d / "state.json"), "--out", str(d / "out")])
        self.judged("S15", "SYNTHETIC", "corrupt pack: state.json cut short (landing)", (1,), "cannot be read", r, before)

    def missing_token(self) -> None:
        from . import pullpack as PP
        d = stage_data(self.pristine, self.work / "token" / "data")
        before = fingerprint(d)
        with _env(**{UCDP_ENV: None}):
            r = call(PP.main, ["run", "--data", str(d), "--steps", "ucdp"])
        self.judged("S16", "SYNTHETIC", "missing token: UCDP (Keychain not exported)", (2,), f"{UCDP_ENV} is not set", r,
                    before, d)
        (PP.pack_dir(d) / PP.STATE_FILE).write_text('{"version": ', encoding="utf-8")
        r = call(PP.main, ["status", "--data", str(d)])
        self.judged("S17", "SYNTHETIC", "corrupt pack: state.json damaged (pullpack)", (1,), "cannot be read", r, before, d)

    def interrupted_pull(self) -> None:
        from . import pullpack as PP
        d = self.work / "token" / "data"
        (PP.pack_dir(d) / PP.STATE_FILE).unlink(missing_ok=True)     # S17 left it damaged on purpose
        before = fingerprint(d)

        def stop(ctx):
            raise KeyboardInterrupt
        steps = [PP.Step("ucdp", "5a", "UCDP first pull (SYNTHETIC: stopped with Ctrl-C)", "1 s", run=stop)]
        with _patched(PP, "default_steps", lambda: steps):
            r = call(PP.main, ["run", "--data", str(d), "--steps", "ucdp", "--redo", "ucdp"])
        st = json.loads((PP.pack_dir(d) / PP.STATE_FILE).read_text())
        saved = "interrupted" in str(st["steps"].get("ucdp", {}).get("reason", ""))
        r["out"] += "" if saved else "\n[state.json does not record the interruption]"
        self.judged("S18", "SYNTHETIC", "interrupted pull (Ctrl-C): state saved", (PP.EXIT_INTERRUPTED,),
                    "rerun the same command to resume" if saved else "state.json records", r, before, d)

    def wrong_folder(self) -> None:
        from . import landing as LC, macpass_landing as MP, pullpack as PP
        dl = self.work / "Downloads" / "econquest"
        (dl / "release-data").mkdir(parents=True)
        shutil.copyfile(self.src / "countries.csv", dl / "release-data" / "countries.csv")
        (dl / "econquest").mkdir()
        before = fingerprint(self.data)
        r = call(LC.main, ["check", "--data", str(dl / "data"), "--out", str(self.work / "landing" / "dl")])
        self.judged("S19", "SYNTHETIC", "wrong folder: landing check in ~/Downloads copy", (1,), "release-data", r, before)
        r = call(PP.main, ["plan", "--data", str(dl / "data")])
        self.judged("S20", "SYNTHETIC", "wrong folder: pull pack in ~/Downloads copy", (1,), "release-data", r, before)
        inbox = next((p for p in sorted((self.work / "synthetic").glob("base"))), None) or self.inbox
        r = call(MP.main, ["check", "--inbox", str(inbox), "--root", str(dl), "--out", str(self.work / "macpass" / "dl")])
        self.judged("S21", "SYNTHETIC", "wrong folder: Mac-pass landing --root Downloads", (2,), "release-data", r, before)

    def interrupted_apply(self) -> None:
        """apply_vintage of the latest vintage, stopped (Ctrl-C) after indicators.csv and before countries.csv."""
        from . import feeds as F
        d = stage_data(self.pristine, self.work / "apply" / "data")
        if not F.list_vintages(d):
            self.row("S22", "SYNTHETIC", "interrupted apply", "both or neither", "no vintage", "no fetch vintage", True)
            return
        before = fingerprint(d)
        real = F._atomic_csv

        def stop(df, path):
            if Path(path).name == "countries.csv":
                raise KeyboardInterrupt
            real(df, path)
        with _patched(F, "_atomic_csv", stop):
            r = call(F.apply_vintage, d, None, author="SYNTHETIC rehearsal")
        ok_safe, why = self.safe(before, d)
        said = "put back from" in r["err"]
        stopped = isinstance(r["exc"], KeyboardInterrupt)
        self.row("S22", "SYNTHETIC", "interrupted apply (Ctrl-C between the 2 files)", "both files as before",
                 "restored" if ok_safe and said else "HALF-APPLIED" if not ok_safe else "no message",
                 why or _first_line(*[ln for ln in r["err"].splitlines() if "put back" in ln]) or _flat(r["exc"]),
                 stopped and said and ok_safe)

    # ---------------------------------------------------------------------------------------- U rows
    def upgrades(self, zips: Path, current: Path | None) -> dict:
        found, missing = {}, []
        for v in SHIPPED:
            z = zips / f"econquest-macos-{v}.zip"
            if not z.is_file() and v == __version__ and (zips / "econquest-macos.zip").is_file() \
                    and _zip_version(zips / "econquest-macos.zip") == v:
                z = zips / "econquest-macos.zip"
            if z.is_file():
                found[v] = z
            else:
                missing.append(v)
        cur = current or self.build_current()
        if cur is None:
            self.row("U0", "upgrade", "current tree release zip", "built", "not built",
                     "scripts/build_release.py not found: pass --current ZIP", False)
            return {"found": list(found), "missing": missing}
        cur_dir = self.extract(cur, self.work / "zips" / "current")
        for i, (v, z) in enumerate(found.items(), 1):
            self.upgrade_one(f"U{i}", v, z, cur_dir)
        for v in missing:
            self.row("U-", "upgrade", f"{v} -> {__version__}", "zip present", "missing",
                     f"econquest-macos-{v}.zip not in {zips}: shipped (team/board/C.csv) but not available to rehearse", True)
        return {"found": list(found), "missing": missing}

    def build_current(self) -> Path | None:
        script = ROOT / "scripts" / "build_release.py"
        if not script.is_file():
            return None
        out = self.work / "zips" / f"econquest-macos-{__version__}-current.zip"
        out.parent.mkdir(parents=True, exist_ok=True)
        subprocess.run([sys.executable, "-I", str(script), str(out), "--source", str(ROOT), "--force"], check=True,
                       capture_output=True, text=True, timeout=900)
        return out

    def extract(self, z: Path, dest: Path) -> Path:
        """Unpack a release zip (budget-checked, every member confined to dest) and return its econquest/ folder."""
        from .safe_zip import check_zip_budget
        sidecar = z.with_name(z.name + ".sha256")
        if sidecar.is_file():
            want = sidecar.read_text().split()[0]
            if want != _sha(z):
                raise ValueError(f"{z.name}: sha256 differs from {sidecar.name}")
        dest.mkdir(parents=True)
        with zipfile.ZipFile(z) as zf:
            check_zip_budget(zf, max_total=2 * 2**30)
            for info in zf.infolist():
                target = (dest / info.filename).resolve()
                if dest.resolve() not in target.parents and target != dest.resolve():
                    raise ValueError(f"{z.name}: member {info.filename!r} leaves the folder")
            zf.extractall(dest)
        top = dest / "econquest"
        for p in top.rglob("*"):
            if p.suffix in (".sh", ".command"):
                # B103: install.sh / install.command from a verified release zip must be executable to run; they sit in
                # the rehearsal's private temporary folder (owner rwx, others r-x, as the release ships them)
                os.chmod(p, 0o755)  # nosec B103
        return top

    def upgrade_one(self, rid: str, v: str, z: Path, cur_dir: Path) -> None:
        """Install zip v, use it with v's own code (review ledger decisions on held cells), upgrade to the current
        release, then check: backup complete, nothing lost or overwritten, ledger byte-identical and verifying with the
        current code, no held cell released by the upgrade, outputs kept, marker updated. data/mvp may be kept (installer
        before EQ-C-0168) or refreshed from the release with the old copy in the backup (EQ-C-0168); both pass."""
        from . import ledger as LG
        name = f"{v} -> {__version__}"
        home = self.work / "homes" / v
        home.mkdir(parents=True)
        try:
            old_dir = self.extract(z, self.work / "zips" / v)
        except (ValueError, zipfile.BadZipFile, OSError) as e:
            self.row(rid, "upgrade", name, "kept", "bad zip", _flat(e), False)
            return
        r1 = _install(old_dir, home)
        target = home / "econquest"
        if r1.returncode != 0 or not (target / "data").is_dir():
            self.row(rid, "upgrade", name, "kept", f"install {v} failed", _flat(r1.stderr or r1.stdout), False)
            return
        # Sam uses it with the installed version's own code: decisions on two held cells (one kept on hold, one released
        # four-eyes against its live value) and one off-review cell; an output; a file of his own (labelled SYNTHETIC)
        d = target / "data"
        used = subprocess.run([sys.executable, "-I", "-c", _USE_OLD, str(target), str(d), SYNTHETIC], capture_output=True,
                              text=True, timeout=300, cwd=str(target))
        if used.returncode != 0:
            self.row(rid, "upgrade", name, "kept", f"{v} code failed", _first_line(*reversed(used.stderr.splitlines()))
                     or "the installed version could not record a review decision", False)
            return
        holds_before = {tuple(x) for x in json.loads(used.stdout.strip().splitlines()[-1])}
        (target / "outputs").mkdir(exist_ok=True)
        (target / "outputs" / "SYNTHETIC-run.json").write_text(json.dumps({"synthetic": SYNTHETIC}) + "\n")
        (d / "live" / "SYNTHETIC-note.txt").write_text(SYNTHETIC + "\n")
        pre = {p.relative_to(d).as_posix(): _sha(p) for p in d.rglob("*") if p.is_file()}
        ledger_sha = _sha(LG.ledger_path(d))
        rlog = self.work / "homes" / f"{v}.rsync.log"
        r2 = _install(cur_dir, home, rsync_shim(self.work), rlog)
        backups = sorted(p for p in (home / "econquest-backups").glob("2*") if p.is_dir()) \
            if (home / "econquest-backups").is_dir() else []
        b = backups[-1] / "data" if backups else None
        in_backup = sum(1 for rel, h in pre.items() if b is not None and (b / rel).is_file() and _sha(b / rel) == h)
        mvp_mode = _mvp_mode(pre, d, cur_dir / "release-data" / "mvp")
        lost = [rel for rel in pre if not (d / rel).is_file() and not (rel.startswith("mvp/") and mvp_mode == "refreshed")]
        changed = [rel for rel, h in pre.items() if (d / rel).is_file() and _sha(d / rel) != h]
        by_design = [rel for rel in changed if rel in MANAGED or rel.startswith("approvals/")
                     or (rel.startswith("mvp/") and mvp_mode == "refreshed")]
        overwritten = [rel for rel in changed if rel not in by_design]
        verify = LG.verify_ledger(d) if LG.ledger_path(d).is_file() else {}
        ledger_ok = LG.ledger_path(d).is_file() and _sha(LG.ledger_path(d)) == ledger_sha and bool(verify.get("ok"))
        holds_after = _holds(d)
        released = sorted(holds_before - holds_after)
        out_ok = (target / "outputs" / "SYNTHETIC-run.json").is_file()
        marker = (target / ".econquest-installed").read_text() if (target / ".econquest-installed").is_file() else ""
        ver_ok = f"version={__version__}\n" in marker
        ok = (r2.returncode == 0 and b is not None and in_backup == len(pre) and not lost and not overwritten
              and ledger_ok and not released and out_ok and ver_ok and mvp_mode != "changed")
        legacy = int(verify.get("legacy_unchained") or 0)
        msg = (f"backup {backups[-1].name if backups else 'MISSING'} holds {in_backup}/{len(pre)} files; kept "
               f"{len(pre) - len(lost) - len(changed)}, updated by design {len(by_design)} (in the backup), "
               f"lost {len(lost)}, overwritten {len(overwritten)}; review ledger "
               + (f"kept, verifies ({legacy} pre-chain rows, anchored at the next decision)" if ledger_ok and legacy
                  else "kept, verifies" if ledger_ok else "CHANGED OR FAILS VERIFY")
               + f"; held cells {len(holds_after)} ({len(released)} released by the upgrade"
               + (f", {len(holds_after - holds_before)} more held from the review.csv or rules the release brings"
                  if holds_after - holds_before else "")
               + f"); outputs {'kept' if out_ok else 'LOST'}; marker {'version=' + __version__ if ver_ok else 'NOT UPDATED'}"
               + {"kept": f"; data/mvp kept (the {v} dataset; refreshed once EQ-C-0168 lands)",
                  "refreshed": "; data/mvp refreshed from the release, old copy in the backup",
                  "none": "", "same": "",
                  "changed": "; data/mvp CHANGED but is neither the old nor the release dataset"}[mvp_mode])
        if lost or overwritten or released:
            msg += f" ({', '.join((lost + overwritten + ['|'.join(c) for c in released])[:5])})"
        if r2.returncode != 0:
            msg = f"upgrade install failed: {_flat(r2.stderr or r2.stdout)}"
        self.row(rid, "upgrade", name, "kept", "kept" if ok else "NOT KEPT", msg, ok)
        self.code_row(f"{rid}c", v, target, cur_dir, rlog, r2.returncode == 0)

    def code_row(self, rid: str, v: str, target: Path, release: Path, rlog: Path, installed: bool) -> None:
        """After an upgrade the installed program files must be the release's, byte for byte (EQ-C-0168: rsync -a skips
        a same-size file with the zip's fixed mtime; --checksum fixes it). A release file missing or different is a
        FAIL naming the files; files of the old version the release no longer has are left in place by install.sh
        (it never deletes) and are listed, not failed."""
        rel, got = code_tree(release), code_tree(target)
        bad = sorted(k for k, h in rel.items() if got.get(k) != h)
        extra = sorted(set(got) - set(rel))
        calls = rlog.read_text().splitlines() if rlog.is_file() else []
        prog = [c for c in calls if "--exclude /data" in c or "--exclude /outputs" in c]
        how = ("tar (no rsync on this machine)" if shutil.which("rsync") is None
               else f"rsync{' --checksum' if prog and all('--checksum' in c for c in prog) else ' WITHOUT --checksum'}"
               if prog else "tar (install.sh did not call rsync for the program files)")
        ok = installed and not bad
        msg = (f"{len(rel) - len(bad)}/{len(rel)} release program files match, copied with {how}"
               + (f"; DIFFER: {', '.join(bad[:8])}" + (" ..." if len(bad) > 8 else "") if bad else "")
               + (f"; {len(extra)} file(s) of {v} left in place (install.sh never deletes): {', '.join(extra[:4])}"
                  + (" ..." if len(extra) > 4 else "") if extra else ""))
        self.row(rid, "code", f"{v} -> {__version__} program files", "release tree",
                 "match" if ok else "MISMATCH", msg, ok)

    # ---------------------------------------------------------------------------------------- run
    def run(self, zips: Path | None = None, current: Path | None = None, quick: bool = False) -> dict:
        src_before = tree(self.src)                     # F-3 / AGENT-08: every file of data/, data/mvp included
        self.out(f"[rehearsal] econquest {__version__} real-data day rehearsal ({TICKET}); copies in {self.work}; "
                 f"{self.src} and its mvp/ are read only")
        stage_data(self.src, self.pristine)
        stage_data(self.pristine, self.data)
        pulls = recorded_pulls(self.inbox)
        self.replay(pulls)
        self.synthetic(pulls, quick)
        up = self.upgrades(zips, current) if zips else None
        src_after = tree(self.src)
        diff = sorted(k for k in set(src_before) | set(src_after) if src_before.get(k) != src_after.get(k))
        ok_safe = not diff
        n_mvp = sum(1 for k in src_after if k.startswith("mvp/"))
        self.row("Z1", "safety", f"{self.src.name}/ and {self.src.name}/mvp untouched", "unchanged",
                 "unchanged" if ok_safe else "CHANGED",
                 f"re-hashed after the rehearsal: all {len(src_after)} files of {self.src.name}/ ({n_mvp} under mvp/)"
                 if ok_safe else f"{len(diff)} file(s) differ: {', '.join(diff[:5])} (another session writing "
                 f"{self.src.name}/? check `teamctl tail`; the rehearsal writes only copies)", ok_safe)
        modes = [r for r in self.rows if r["kind"] not in ("upgrade", "code")]
        ups = [r for r in self.rows if r["kind"] == "upgrade" and r["got"] != "missing"]
        codes = [r for r in self.rows if r["kind"] == "code"]
        passed = all(r["ok"] for r in self.rows)
        line = (f"[rehearsal] M21 {'PASS' if passed else 'FAIL'}: {sum(r['ok'] for r in modes)}/{len(modes)} replay and "
                f"failure-mode rows ended in a plain message and a safe state")
        if up is not None:
            line += (f"; upgrades {sum(r['ok'] for r in ups)}/{len(ups)} kept data/, backup and review ledger "
                     f"({', '.join(up['found']) or 'none'} -> {__version__}); program files {sum(r['ok'] for r in codes)}/"
                     f"{len(codes)} match the release ({'rsync' if shutil.which('rsync') else 'tar'}); "
                     f"zips missing: {', '.join(up['missing']) or 'none'}")
        else:
            line += "; upgrades not run (pass --zips DIR)"
        self.out(line)
        return {"ticket": TICKET, "version": __version__, "passed": passed, "rows": self.rows, "upgrades": up,
                "summary": line, "work": str(self.work)}


# Run with the installed (old) version's code: record SYNTHETIC review decisions, print the held cells as JSON.
_USE_OLD = r"""
import json, sys
sys.path.insert(0, sys.argv[1])
from pathlib import Path
import pandas as pd
from econquest.ingestion.ledger import effective_holds, load_decisions, record_decision
d, note = Path(sys.argv[2]), sys.argv[3]
p = d / "live" / "review.csv"
rv = pd.read_csv(p, dtype={"key": str}) if p.is_file() else None
held = rv[rv["status"] == "hold"] if rv is not None else rv
if held is not None and len(held) >= 1:
    h = held.iloc[0]
    record_decision(d, h["table"], h["key"], h["country"], "hold", "SYNTHETIC Sam", note=note, gate_status="hold")
if held is not None and len(held) >= 2:
    h = held.iloc[1]
    record_decision(d, h["table"], h["key"], h["country"], "apply", "SYNTHETIC Sam", approver="SYNTHETIC approver",
                    note=note, gate_status="hold", live=float(h["live"]))
record_decision(d, "Inputs", "1.1", "SYNTHETIC", "hold", "SYNTHETIC Sam", note=note)
print(json.dumps(sorted([str(x) for x in c] for c in effective_holds(rv, load_decisions(d)))))
"""


def _holds(d: Path) -> set:
    """Held cells (table, key, country) under the current code: review.csv gate holds plus ledger decisions."""
    import pandas as pd
    from .ledger import effective_holds, load_decisions
    p = d / "live" / "review.csv"
    rv = pd.read_csv(p, dtype={"key": str}) if p.is_file() else None      # 0.6.0 shipped no review.csv
    return {tuple(str(x) for x in c) for c in effective_holds(rv, load_decisions(d))}


def _mvp_mode(pre: dict, d: Path, release_mvp: Path) -> str:
    """none (no data/mvp before); same / kept (every old mvp file unchanged; files the installer adds from the release
    are fine; same when the result equals the release's mvp); refreshed (now exactly the release's mvp, EQ-C-0168);
    changed (anything else)."""
    old = {rel[4:]: h for rel, h in pre.items() if rel.startswith("mvp/")}
    now = {p.relative_to(d / "mvp").as_posix(): _sha(p) for p in (d / "mvp").rglob("*") if p.is_file()} \
        if (d / "mvp").is_dir() else {}
    rel = {p.relative_to(release_mvp).as_posix(): _sha(p) for p in release_mvp.rglob("*") if p.is_file()} \
        if release_mvp.is_dir() else {}
    if not old:
        return "none"
    if all(now.get(k) == h for k, h in old.items()):
        return "same" if now == rel else "kept"
    return "refreshed" if rel and now == rel else "changed"


def tree(d: Path) -> dict:
    """{relative path: sha256} of every file below d, hidden entries and caches left out (another session's
    build-aside folders). Z1 compares the whole data/ tree, data/mvp included, before and after."""
    out = {}
    if not d.is_dir():
        return out
    for root, dirs, files in os.walk(d):
        dirs[:] = [n for n in dirs if not n.startswith(".") and n != "__pycache__"]
        for n in files:
            if not n.startswith("."):
                p = Path(root) / n
                with contextlib.suppress(OSError):
                    out[p.relative_to(d).as_posix()] = _sha(p)
    return out


def _zip_version(z: Path) -> str:
    try:
        with zipfile.ZipFile(z) as zf:
            text = zf.read("econquest/econquest/__init__.py").decode("utf-8", "replace")
    except (KeyError, OSError, zipfile.BadZipFile):
        return ""
    m = re.search(r"__version__\s*=\s*['\"]([^'\"]+)", text)
    return m.group(1) if m else ""


def rsync_shim(work: Path) -> Path | None:
    """A folder holding an `rsync` that logs its arguments to $ECONQUEST_REHEARSAL_RSYNC_LOG and runs the real one, so
    an upgrade row can prove which copy path install.sh took. None when this machine has no rsync (install.sh then
    uses tar, and the rows say so)."""
    real = shutil.which("rsync")
    if not real:
        return None
    shim = work / "shim"
    shim.mkdir(parents=True, exist_ok=True)
    f = shim / "rsync"
    f.write_text('#!/bin/sh\nprintf "%s\\n" "$*" >> "${ECONQUEST_REHEARSAL_RSYNC_LOG:-/dev/null}"\n'
                 f'exec {shlex.quote(real)} "$@"\n')
    os.chmod(f, 0o700)
    return shim


def code_tree(top: Path) -> dict:
    """{path: sha256} of an install's (or a release's) program files: everything except the top-level data/ and
    outputs/, the install marker and log, the venv, .git and caches. release-data/ is included on both sides (install.sh
    copies it with the program)."""
    skip_top = {"data", "outputs", ".venv", ".econquest-installed", ".install.log", ".git"}
    out = {}
    for root, dirs, files in os.walk(top):
        rel_root = Path(root).relative_to(top)
        if rel_root == Path("."):
            dirs[:] = [n for n in dirs if n not in skip_top]
            files = [n for n in files if n not in skip_top]
        dirs[:] = [n for n in dirs if n != "__pycache__"]
        for n in files:
            if n.endswith((".pyc", ".pyo")) or n == ".DS_Store":
                continue
            p = Path(root) / n
            out[(rel_root / n).as_posix()] = _sha(p)
    return out


def _install(src: Path, home: Path, shim: Path | None = None, log: Path | None = None) -> subprocess.CompletedProcess:
    """The release's own install.sh into a temporary HOME, files only (no venv, pip, launcher, profile or prompt).
    With `shim`, rsync calls are logged to `log`."""
    path = os.environ.get("PATH", "/usr/bin:/bin")
    env = {"HOME": str(home), "PATH": f"{shim}:{path}" if shim else path, "ECONQUEST_INSTALL_SKIP_VENV": "1",
           "ECONQUEST_NO_PROFILE": "1", "ECONQUEST_INSTALL_NO_PROMPT": "1", "LANG": "C"}
    if log is not None:
        env["ECONQUEST_REHEARSAL_RSYNC_LOG"] = str(log)
    return subprocess.run(["bash", str(src / "install.sh")], env=env, capture_output=True, text=True, timeout=600,
                          stdin=subprocess.DEVNULL)


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.rehearsal", description=__doc__.split("\n\n")[0])
    ap.add_argument("command", choices=("run",))
    ap.add_argument("--data", default=str(ROOT / "data"), help="data folder to copy (read only; default %(default)s)")
    ap.add_argument("--inbox", default=str(ROOT / "team" / "inbox"), help="folder holding the recorded pull-* uploads")
    ap.add_argument("--zips", help="folder with the shipped econquest-macos-<v>.zip files: run the upgrade rows")
    ap.add_argument("--current", help="release zip of the current tree (default: build one with scripts/build_release.py)")
    ap.add_argument("--quick", action="store_true", help="leave out the two rows that rebuild data/mvp")
    ap.add_argument("--keep", action="store_true", help="keep the temporary folder (its path is printed)")
    ap.add_argument("--json", action="store_true", help="print the rows as JSON at the end")
    ap.add_argument("--out", help="also write rehearsal.json and rehearsal.md here (econquest rehearse: "
                                  "outputs/rehearsal/<UTC>/, EQ-C-0168); never inside the data folder")
    a = ap.parse_args(argv)
    from .pullpack import data_folder_problem
    problem = data_folder_problem(a.data)
    if problem:
        print(f"error: {problem}", file=sys.stderr)
        return 1
    out_dir = Path(a.out).expanduser().resolve() if a.out else None
    if out_dir is not None and (out_dir == Path(a.data).resolve() or Path(a.data).resolve() in out_dir.parents):
        print(f"error: --out {out_dir} is inside the data folder; the rehearsal never writes there", file=sys.stderr)
        return 1
    work = Path(tempfile.mkdtemp(prefix="econquest-rehearsal-"))
    try:
        res = Rehearsal(Path(a.data), Path(a.inbox), work, dt.datetime.now(dt.timezone.utc)).run(
            Path(a.zips).expanduser() if a.zips else None, Path(a.current).expanduser() if a.current else None, a.quick)
    except KeyboardInterrupt:
        print(f"interrupted: the rehearsal works on copies only; nothing in {a.data} changed", file=sys.stderr)
        return 1
    except Exception as e:  # noqa: BLE001 - the rehearsal itself ends in one plain line too
        print(f"error: the rehearsal could not finish ({type(e).__name__}: {_flat(e)}); it works on copies only, "
              f"nothing in {a.data} changed. Rerun with --keep to look at {work}", file=sys.stderr)
        return 1
    finally:
        if not a.keep:
            shutil.rmtree(work, ignore_errors=True)
    if out_dir is not None:
        try:
            write_report(res, out_dir)
            print(f"[rehearsal] report: {out_dir / 'rehearsal.md'}")
        except OSError as e:
            print(f"error: could not write the report to {out_dir} ({type(e).__name__}: {_flat(e)}); the rehearsal "
                  f"result above stands", file=sys.stderr)
            return 1
    if a.json:
        print(json.dumps(res, indent=1, default=str))
    return 0 if res["passed"] else 1


def write_report(res: dict, out_dir: Path) -> None:
    """rehearsal.json (every row) and rehearsal.md (a table and the M21 line) in out_dir. The temporary work folder is
    gone by now, so its path is kept only as text."""
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "rehearsal.json").write_text(json.dumps(res, indent=1, default=str) + "\n", encoding="utf-8")
    from .pullpack import md_text
    L = [f"# Real-data day rehearsal (M21, {TICKET})", "", f"econquest {res['version']}. {md_text(res['summary'])}", "",
         "| Row | OK | Kind | Case | Outcome | Message |", "|---|---|---|---|---|---|"]
    L += [f"| {r['id']} | {'ok' if r['ok'] else 'BAD'} | {r['kind']} | {md_text(r['name'])} | {md_text(r['got'])} | "
          f"{md_text(r['message'])} |" for r in res["rows"]]
    (out_dir / "rehearsal.md").write_text("\n".join(L) + "\n", encoding="utf-8")


if __name__ == "__main__":
    raise SystemExit(main())
