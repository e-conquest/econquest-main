"""Live coverage measure after the Mac pass (EQ-A-0118, coverage part 6), called by AGENT-06's landing kit (EQ-A-0116).

Measures how many feed-eligible Inputs cells are LIVE in an uploaded review.csv, for the desk and the universe,
against Sam's target (60% of the feed-eligible ids per country; universe.LIVE_TARGET, universe.feed_eligible_ids).
It reads files only and never writes data/.

Definitions (the same as docs/runbooks/A-coverage-60.md sections 10 and 11):
    eligible ids  universe.feed_eligible_ids(data_dir): coverage_source_map.csv ids not `manual-only` (50 today)
    cells         every country in the review x every eligible id; an id absent from the review counts as missing
    live          gate status `ok` on an Inputs row. Review decisions are NOT counted: `named_applies` (apply by a named
                  author, not the legacy importer) is reported beside it, because an apply changes indicators.csv
                  only through `review apply` and the next review.csv shows it as ok.
    at target     live / eligible ids >= target, per country
    scope         "desk" when every country is a data/countries.csv name, else "universe"

Python: measure(...) -> dict (SCHEMA). CLI:
    python -m econquest.ingestion.coverage_live measure --data data --review PATH
        [--universe-review PATH] [--report PATH] [--baseline JSON] [--json OUT] [--md OUT]
Exit 0 measured; 2 an input is unreadable or invalid (missing column, duplicate cell, unknown desk country).
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

import pandas as pd

from . import universe as U

SCHEMA = "econquest.coverage_live/1"
REVIEW_COLUMNS = ("table", "key", "country", "status")
LEGACY_AUTHOR_PREFIX = "unknown"           # ledger.LEGACY_AUTHOR: "unknown (imported from hand-edited review.csv)"


class CoverageError(ValueError):
    """The one exception measure() raises for input it cannot measure (the CLI exits 2; the landing kit turns it into
    a refusal). Missing or unreadable files, bad columns, duplicates, a partial desk, a bad baseline, a data folder
    without countries.csv or coverage_source_map.csv all become this type."""


InputError = CoverageError                  # earlier name, kept for callers written against the first draft


def _read_review(review) -> pd.DataFrame:
    if isinstance(review, pd.DataFrame):
        df = review.copy()
    else:
        p = Path(review)
        if not p.is_file():
            raise CoverageError(f"review file not found: {p}")
        try:
            df = pd.read_csv(p, dtype=str, keep_default_na=False)
        except (ValueError, pd.errors.ParserError) as e:
            raise CoverageError(f"{p.name}: not a CSV ({str(e)[:120]})") from None
    missing = [c for c in REVIEW_COLUMNS if c not in df.columns]
    if missing:
        raise CoverageError(f"review is missing columns {missing}")
    for c in ("decision", "author"):
        if c not in df.columns:
            df[c] = ""
    df = df.fillna("")
    dup = df.duplicated(["table", "key", "country"])
    if dup.any():
        first = df[dup].iloc[0]
        raise CoverageError(f"review has {int(dup.sum())} duplicate cells (e.g. {first['key']} {first['country']})")
    return df


def desk_names(data_dir) -> list[str]:
    return sorted(pd.read_csv(Path(data_dir) / "countries.csv", dtype=str)["country"].str.strip())


def measure_review(review, data_dir="data", target: float = U.LIVE_TARGET) -> dict:
    """One review.csv -> {scope, countries, eligible_ids, eligible_cells, live, share, countries_at_target,
    per_country, named_applies, live_cells}."""
    df = _read_review(review)
    elig = sorted(U.feed_eligible_ids(data_dir), key=U._idkey)
    countries = sorted({c.strip() for c in df["country"] if c.strip()})
    if not countries:
        raise CoverageError("review has no countries")
    desk = set(desk_names(data_dir))
    scope = "desk" if set(countries) <= desk else "universe"
    if scope == "desk" and set(countries) != desk:
        raise CoverageError(f"desk review lacks {sorted(desk - set(countries))}: a partial desk review is not measured")
    inp = df[(df["table"] == "Inputs") & df["key"].isin(elig)]
    ok = inp[inp["status"] == "ok"]
    named = inp[(inp["status"] != "ok") & (inp["decision"] == "apply")
                & (inp["author"].str.strip() != "") & ~inp["author"].str.startswith(LEGACY_AUTHOR_PREFIX)]
    per = {c: int((ok["country"] == c).sum()) for c in countries}
    n = len(elig)
    live = sum(per.values())
    return {
        "scope": scope, "countries": len(countries), "eligible_ids": n, "eligible_cells": n * len(countries),
        "live": live, "share": round(live / (n * len(countries)), 4) if n else 0.0,
        "target": target, "target_text": U.target_denominator(target, n),
        "countries_at_target": sum(U._meets(v, n, target) for v in per.values()),
        "best": max(per.values()), "per_country": per, "named_applies": int(len(named)),
        "ids_absent_from_review": sorted(set(elig) - set(df["key"]), key=U._idkey),
        "live_cells": sorted(f"{k}|{c}" for k, c in zip(ok["key"], ok["country"])),
    }


def report_universe(report) -> dict | None:
    """The pull report.json universe step's own counts (a cross-check; None when the step is absent)."""
    try:
        d = json.loads(Path(report).read_text())
    except (OSError, ValueError) as e:
        raise CoverageError(f"report.json unreadable: {str(e)[:120]}") from None
    for s in d.get("steps", []) if isinstance(d, dict) else []:
        if s.get("id") == "universe":
            c = s.get("counts", {}) or {}
            return {"status": s.get("status"), "econquest_version": d.get("econquest_version"),
                    "generated_utc": d.get("generated_utc"),
                    **{k: c.get(k) for k in ("n_countries", "pct_live_eligible_overall", "countries_meeting_target",
                                             "pct_live_overall")}}
    return None


def delta(now: dict | None, before: dict | None) -> dict | None:
    if not now or not before:
        return None
    a, b = set(now["live_cells"]), set(before["live_cells"])
    return {"live": now["live"] - before["live"], "share_pp": round(100 * (now["share"] - before["share"]), 2),
            "countries_at_target": now["countries_at_target"] - before["countries_at_target"],
            "per_country": {c: now["per_country"].get(c, 0) - before["per_country"].get(c, 0)
                            for c in sorted(set(now["per_country"]) | set(before["per_country"]))
                            if now["per_country"].get(c, 0) != before["per_country"].get(c, 0)},
            "gained": sorted(a - b), "lost": sorted(b - a)}


def measure(review=None, data_dir="data", universe_review=None, report=None, baseline=None,
            target: float = U.LIVE_TARGET) -> dict:
    """Desk and universe measures from the uploads; `baseline` is a previous measure() dict or its JSON path.
    Raises CoverageError only (any OSError / ValueError underneath is wrapped)."""
    try:
        return _measure(review, data_dir, universe_review, report, baseline, target)
    except CoverageError:
        raise
    except (OSError, ValueError, KeyError) as e:
        raise CoverageError(f"{type(e).__name__}: {str(e)[:200]}") from e


def _measure(review, data_dir, universe_review, report, baseline, target) -> dict:
    out = {"schema": SCHEMA, "desk": None, "universe": None, "report_universe": None, "delta": {}}
    for f in (review, universe_review):
        if f is None:
            continue
        m = measure_review(f, data_dir, target)
        if out[m["scope"]] is not None:
            raise CoverageError(f"two {m['scope']} reviews given")
        out[m["scope"]] = m
    if report is not None:
        out["report_universe"] = report_universe(report)
    if baseline is not None:
        base = baseline if isinstance(baseline, dict) else json.loads(Path(baseline).read_text())
        if base.get("schema") != SCHEMA:
            raise CoverageError(f"baseline schema {base.get('schema')!r}, expected {SCHEMA}")
        out["delta"] = {s: delta(out[s], base.get(s)) for s in ("desk", "universe")}
        out["baseline_label"] = base.get("label", "")
    return out


def markdown(m: dict) -> str:
    lines = ["| Scope | Live | Cells | Share | At target | Best | Change vs baseline |", "|---|---|---|---|---|---|---|"]
    for s in ("desk", "universe"):
        r = m.get(s)
        if not r:
            continue
        d = (m.get("delta") or {}).get(s)
        ch = f"{d['live']:+d} cells ({d['share_pp']:+.1f} pp), {len(d['gained'])} gained, {len(d['lost'])} lost" if d else ""
        lines.append(f"| {s} ({r['countries']}) | {r['live']} | {r['eligible_cells']} | {r['share']:.1%} | "
                     f"{r['countries_at_target']} | {r['best']} | {ch} |")
    ru = m.get("report_universe")
    if ru:
        lines.append(f"\nreport.json universe step ({ru.get('econquest_version')}): pct_live_eligible_overall "
                     f"{ru.get('pct_live_eligible_overall')}, countries_meeting_target {ru.get('countries_meeting_target')}")
    lines.append(f"\nLive = gate status ok on feed-eligible Inputs ids; {U.target_denominator(U.LIVE_TARGET, (m.get('desk') or m.get('universe') or {}).get('eligible_ids', 0))}.")
    return "\n".join(lines) + "\n"


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.coverage_live",
                                 description="Live coverage from an uploaded review.csv (EQ-A-0118); reads only")
    sub = ap.add_subparsers(dest="cmd", required=True)
    p = sub.add_parser("measure")
    p.add_argument("--data", default="data")
    p.add_argument("--review", help="desk (or universe) review.csv")
    p.add_argument("--universe-review", help="universe review.csv")
    p.add_argument("--report", help="pull report.json (universe step cross-check)")
    p.add_argument("--baseline", help="a previous measure JSON (schema econquest.coverage_live/1)")
    p.add_argument("--label", default="", help="label stored in the JSON (e.g. the upload name)")
    p.add_argument("--json", help="write the measure as JSON here")
    p.add_argument("--md", help="write a markdown table here")
    a = ap.parse_args(argv)
    if not (a.review or a.universe_review):
        print("refused: give --review and/or --universe-review", file=sys.stderr)
        return 2
    try:
        m = measure(a.review, a.data, a.universe_review, a.report, a.baseline)
    except CoverageError as e:
        print(f"refused: {e}", file=sys.stderr)
        return 2
    m["label"] = a.label
    if a.json:
        Path(a.json).write_text(json.dumps(m, indent=1, sort_keys=True) + "\n")
    md = markdown(m)
    if a.md:
        Path(a.md).write_text(md)
    print(md, end="")
    return 0


if __name__ == "__main__":
    sys.exit(main())
