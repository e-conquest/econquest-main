"""Validator data room, data side (EQ-A-0041, PI-5 independent validation).

`build_data_room(data_dir, as_of, out_dir)` exports, for one as-of date, every Team A data record that existed at
that date into a self-contained, read-only folder an external validator can verify and replay without econquest:

    <out_dir>/
        MANIFEST.json        every file: path, size, sha256, source, kind, as-of rule; top hash; code version
        README.md            for the validator: folders, how to verify, known limitations
        verify.py            standard-library verifier (a copy of econquest/ingestion/dataroom_verify.py)
        data/...             point-in-time copies, at the same relative paths as in data_dir
        derived/four_eyes.csv  one row per review-ledger decision with its four-eyes / self-approval / attestation flags

Point in time (the cutoff is the end of the as-of day in UTC, or the exact instant when as_of carries a time):
* vintages, snapshots and archives by the UTC timestamp in their folder id (`<YYYY-MM-DD>T<HHMMSS>Z-<hash8>`; a legacy
  date-only id counts as the end of that day): live vintages, panel vintages, market snapshots, event vintages, event
  export archives, pre-apply snapshots. Their index.csv files keep only the rows of selected folders whose own
  timestamp column is not after the cutoff.
* frozen replay inputs (replay.freeze_inputs, TEAM_A_RUN_INPUTS) by the snapshots/index.csv row's frozen_utc.
* append-only row files by each row's timestamp: review_ledger.csv (ts_utc, which also carries every attestation),
  market/manual_quotes.csv (entered_utc), market/cds_snapshots.csv (snapshot id time and as_of), approvals/log.jsonl
  (ts_utc) and approvals/proposals by the time in the change id. A row without a readable timestamp is dropped.
* audit_trail.csv: rows retrieved after the cutoff are dropped; rows with no retrieved date (seed and hand-entered
  values) are kept, because the file is regenerated per run and those rows carry no date.
* the current pull (data/live/*.csv, *.json one level: transform_log, unserved, feed_failures, provenance ...) as a
  whole, dated by data/live/feeds.json `retrieved`.
* anything else is an undated working copy (indicators.csv, countries.csv, other teams' files ...): left out and
  listed under build.excluded, unless include_current=True, which is refused when any dated record is after the
  cutoff (then the working copies may already hold later data).

Never exported: data/vendor_licences.json, credential-named files (.env, *.pem, *secret*, *token* ...), JSON files
with credential keys and files whose text matches a credential pattern; hidden, lock and temporary files; symlinks.
Licence tags inside data (licence columns, manifest licences) are kept.

Licence-restricted files (EQ-A-0044) are withheld by default (include_restricted=False): raw_yahoo.csv anywhere
(Yahoo's terms are personal, non-commercial use and do not allow passing the data to an external validator; Sam
replaced Yahoo on 2026-10-23, EQ-A-0040) and any CSV whose licence column says non-commercial or personal
(market.gate.DESK_BARRED_LICENCE_TERMS). Each is listed under build.excluded with its reason and, because it would
otherwise be in the room, under the hashed `withheld` list with its path, size and sha256, so verify.py does not
report it missing. This covers the frozen 2026-10-23 live vintage, which holds raw_yahoo.csv.

Yahoo-derived values are blanked in the room copies (SEC-A-006 M2, EQ-A-0045; data_dir is never changed). Sam
replaced Yahoo because its terms are personal and non-commercial, and that covers values computed from Yahoo data,
not only raw_yahoo.csv. Unless include_restricted=True, in every CSV copied into the room:
* a row whose own `source` (or licence column) is Yahoo / yfinance or carries a non-commercial or personal licence
  (audit.restricted_reason) has its value columns (RESTRICTED_VALUE_COLUMNS: value, live, live_value, change,
  gate_reason, reason ...) blanked: provenance.csv (current pull and vintages), audit_trail.csv, market quotes. A CSV
  with such rows but none of those columns is withheld instead, since its data columns cannot be told apart;
* a long file without a source column (review.csv, diff_vs_seed.csv, the review ledger ...: columns table, key,
  country and live / value) has those columns blanked on rows whose value equals a value that a provenance record
  or the audit trail attributes to a restricted source for that cell (restricted_value_index);
* a wide table (live_profile.csv, live_inputs.csv, countries.csv, indicators.csv, in the current pull, vintages and
  snapshots) has each such cell blanked.
Each changed file is listed under the hashed `redactions` list with `restricted_rows`, `restricted_cells` and the
original sha256 and size, so a vintage holding one is reported `altered` by verify.py (as for a withheld file).

E-mail addresses are redacted at source (EQ-A-0044, for SEC-C-008 R6): in every text file copied into the room,
each match of EMAIL_RE (the same pattern as Team C's evidence bundle) and of its %40-encoded form (EMAIL_PCT_RE) is
replaced by `[redacted-email]` before the file is hashed. UTF-8 files and UTF-16/32 files with a byte-order mark are
scanned (secrets and e-mails, SEC-A-006 L4); any other file that is not UTF-8 text (binary, BOM-less UTF-16: NUL
bytes) cannot be scanned reliably and is withheld with that reason. The hashed `redactions` list names each file with
its replacement count and its original sha256 and size. data_dir is never changed.

A live or panel vintage's content hash covers the original bytes of every file in the folder, so a vintage with a
withheld or redacted file cannot be re-verified from the room. The build verifies the source folder against
vintages/index.csv and records the result in the hashed `altered_anchors`. verify.py then reports the folder as
`altered` (a warning) when the room's index row matches what was verified and the file count adds up, and `failed`
otherwise. Anchors that compare a sha256 (market and event manifests, replay manifests) use the recorded original.

The data limitations register (econquest.ingestion.limitations.build_register) is generated for the as-of into
limitations/data-limitations.md (EQ-A-0044). The manifest's `limitations` entry says whether it was generated, from
which pull and, if not, why.

Nothing in data_dir is written: files are read, and the room is built in a temporary sibling of out_dir and renamed
into place (files 0444). Deterministic: the same data and code give the same MANIFEST.json except its `build`
section (build time, source path, exclusions), which is outside both hashes. Selection uses only records dated at
or before the cutoff, so a room rebuilt later for the same as-of date has the same hash while the append-only
stores are unchanged (current-pull files and audit_trail.csv are working copies and may move it; README says so).

`verify_data_room(path)` runs dataroom_verify.verify_room, the same code as the room's verify.py.
Command line: python -m econquest.ingestion.dataroom build --as-of 2026-10-23      # -> outputs/dataroom/2026-10-23
              python -m econquest.ingestion.dataroom build --data data --as-of 2026-10-23 --out /tmp/room
              python -m econquest.ingestion.dataroom verify /tmp/room"""
from __future__ import annotations

import argparse
import csv
import datetime as dt
import hashlib
import io
import json
import os
import platform
import re
import shutil
import sys
import tempfile
from collections import Counter
from pathlib import Path

from .dataroom_verify import MANIFEST_NAME, SCHEMA, _anchor_checks, altered_map, content_hash, manifest_hash, verify_room

VERIFY_SOURCE = Path(__file__).with_name("dataroom_verify.py")
LIMITATIONS_DOC = "docs/validation/data-limitations.md"
LIMITATIONS_PATH = "limitations/data-limitations.md"
REDACTED_EMAIL = "[redacted-email]"
# The same pattern as Team C's evidence bundle (econquest/ops/evidence.py EMAIL_RE, SEC-C-008 R6), so nothing in the
# room is left for the bundle to redact; tests/test_dataroom.py checks that the two agree.
EMAIL_RE = re.compile(r"[A-Za-z0-9.!#$%&'*+/=?^_`{|}~-]+@[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?(?:\.[A-Za-z0-9-]+)+")
# SEC-A-006 L4: the same address URL-encoded (sam%40example.com); EMAIL_RE itself stays Team C's pattern
EMAIL_PCT_RE = re.compile(r"[A-Za-z0-9.!#$&'*+/=?^_`{|}~-]+%40[A-Za-z0-9](?:[A-Za-z0-9-]*[A-Za-z0-9])?(?:\.[A-Za-z0-9-]+)+",
                          re.IGNORECASE)
YAHOO_FILE_REASON = ("licence: Yahoo Finance data, personal non-commercial use only; may not be passed to an "
                     "external validator (Yahoo replaced by Sam 2026-10-23, EQ-A-0040)")
RESTRICTED_FILES = {"raw_yahoo.csv": YAHOO_FILE_REASON}       # matched case-insensitively, as is any *yahoo* name
UNSCANNABLE_REASON = ("unscannable: not UTF-8 text and no UTF-16/32 byte-order mark (binary, or text with NUL bytes), "
                      "so secrets and e-mail addresses cannot be checked; withheld rather than exported unscanned "
                      "(SEC-A-006 L4)")
# SEC-A-006 M2: columns blanked on a row tied to a restricted source (Yahoo, non-commercial / personal licence)
RESTRICTED_VALUE_COLUMNS = ("value", "live", "live_value", "change", "change_pct", "pct_change", "rel_change",
                            "gate_reason", "reason", "close", "adj_close", "price", "open", "high", "low")
RESTRICTED_NO_VALUE_COLUMNS = ("licence: rows from a restricted source (Yahoo / non-commercial / personal) in a CSV with "
                               "none of the known value columns, so they cannot be blanked; withheld (SEC-A-006 M2)")
LICENCE_COLUMNS = ("licence", "license", "licences", "licenses")
DERIVED_FOUR_EYES = "derived/four_eyes.csv"
FOUR_EYES_COLUMNS = ["ts_utc", "vintage_id", "table", "key", "country", "gate_status", "decision", "author", "approver",
                     "self_approved", "four_eyes", "attestation", "content_sha256", "note"]

RULES = {
    "live_vintage": "folder id timestamp (UTC; legacy date id = end of that day) <= cutoff",
    "live_vintage_index": "rows of selected live vintages whose retrieved_utc <= cutoff",
    "panel_vintage": "folder id timestamp (UTC) <= cutoff",
    "panel_vintage_index": "rows of selected panel vintages whose created_utc <= cutoff",
    "weo_vintage": ("WEO release folder (id = release month, not a time) whose first index.csv row has imported_utc "
                    "<= cutoff"),
    "weo_vintage_index": "rows of selected WEO releases whose imported_utc <= cutoff",
    "market_snapshot": "snapshot id timestamp (save time, UTC) <= cutoff",
    "market_snapshot_index": "rows of selected market snapshots whose saved_utc <= cutoff",
    "cds_snapshots": "rows whose snapshot_id timestamp <= cutoff and as_of <= cutoff",
    "manual_quotes": "rows whose entered_utc <= cutoff (rows without a timestamp dropped)",
    "event_vintage": "folder id timestamp (save time, UTC) <= cutoff",
    "event_vintage_index": "rows of selected event vintages whose retrieved_utc (save time) <= cutoff",
    "event_export": "export id timestamp (created_utc) <= cutoff",
    "event_export_index": "rows of selected event exports whose created_utc <= cutoff",
    "replay_snapshot": "named by a kept snapshots/index.csv row (frozen_utc <= cutoff, its vintage selected)",
    "replay_snapshot_index": "rows whose frozen_utc <= cutoff and whose live vintage is selected",
    "pre_apply_snapshot": "folder id timestamp (UTC) <= cutoff",
    "review_ledger": "rows whose ts_utc <= cutoff (rows without a timestamp dropped)",
    "approvals_log": "rows whose ts_utc <= cutoff (a prefix of the hash chain)",
    "approvals_proposal": "change id timestamp (CHG-<YYYYMMDD>T<HHMMSS>Z) <= cutoff",
    "audit_trail": "rows whose retrieved date <= cutoff; rows with no retrieved date (seed, hand-entered) kept",
    "current_pull": "data/live/feeds.json retrieved date (end of day) <= cutoff; whole files",
    "current_working_copy": "undated working copy, included only with include_current and no dated record after cutoff",
    "derived": "generated from the kept review_ledger rows",
    "verify_script": "standard-library verifier copied from econquest/ingestion/dataroom_verify.py",
    "limitations": ("generated by econquest.ingestion.limitations.build_register from the newest pull at or before the "
                    "cutoff (audit_trail rows by retrieved date); its narrative is hand-written (EQ-A-0042) "
                    "and indicators/countries/rulebook are read as working copies"),
    "readme": "generated for the validator",
    # EQ-A-0125: opt-in kinds (licence_baseline / include_mvp), so a default room is unchanged
    "licence_register": ("the licence register that governed this build (data/licences.csv, whole file): every "
                         "withholding and label in the room was decided by it; a working copy, recorded with its "
                         "sha256 under licence_baseline"),
    "mvp_dataset": ("frozen MVP dataset (data/mvp, econquest-mvp-dataset/1), whole, when its manifest.json built_utc "
                    "<= cutoff; anchored by its manifest.json files and dataset_sha256"),
}
LICENCE_BASELINES = ("demo",)                      # EQ-A-0125: the only label until Sam approves a real baseline
DEMO_LABEL = "DEMO"
MVP_ROOT = "mvp"
MVP_SCHEMA = "econquest-mvp-dataset/1"
# EQ-A-0125: the room's two sections. Content from client-restricted sources is only ever in the internal one.
INTERNAL_SECTION = ("data/", "derived/", "limitations/")
OUTER_FILES = ("MANIFEST.json", "README.md", "verify.py")
# EQ-A-0125: the register rows added in PI-11 (EQ-A-0117 D3, EQ-A-0119 national nowcast, HO-20261026-A-A-001 COW),
# reported row by row in a labelled room; their status is read from the register, never set here
PI11_SOURCES = ("nowcast_bcb_sgs", "nowcast_bcrp", "nowcast_datos_ar", "nowcast_dosm", "cow_contiguity", "imf_via_wdi")

SECRET_FILES = {"vendor_licences.json", "vendor_licenses.json", ".netrc", ".pgpass", "credentials", "credentials.json"}
SECRET_NAME_RE = re.compile(
    r"(^\.env|(^|[._-])(secrets?|credentials?|passwords?|passwd|tokens?|api[_-]?keys?|app[_-]?keys?|private[_-]?key)"
    r"([._-]|$)|\.(pem|key|p12|pfx|jks|keystore|kdbx)$|^id_(rsa|dsa|ecdsa|ed25519))", re.IGNORECASE)
SECRET_KEY_RE = re.compile(r"(password|passwd|pass|pwd|pw|secret|client_secret|api_?key|app_?key|access_?token|"
                           r"refresh_?token|auth|auth_?token|authorization|bearer|token|credentials?|private_?key|"
                           r"keychain)", re.IGNORECASE)
SECRET_TEXT_RE = re.compile(
    r"(-----BEGIN [A-Z ]*PRIVATE KEY-----|\bAKIA[0-9A-Z]{16}\b|\bgh[pousr]_[A-Za-z0-9]{30,}|\bgithub_pat_[A-Za-z0-9_]{30,}"
    r"|\bxox[abprs]-[A-Za-z0-9-]{10,}|\bsk-(ant-)?[A-Za-z0-9_-]{24,}"
    r"|\bBearer\s+[A-Za-z0-9._~+/-]{16,}|\beyJ[\w-]{8,}\.[\w-]{8,}\."                      # SEC-A-006 L4: bearer, JWT
    r"|\b(password|passwd|pass|pwd|api[_-]?key|app[_-]?key|client[_-]?secret|access[_-]?token|auth[_-]?token)\b"
    r"\s*[:=]\s*[\"']?[A-Za-z0-9_\-./+]{8,})", re.IGNORECASE)

_ID_RE = re.compile(r"(\d{4}-\d{2}-\d{2})(?:T(\d{2})(\d{2})(\d{2})Z)?(?=$|-)")
_CHG_RE = re.compile(r"CHG-(\d{4})(\d{2})(\d{2})T(\d{2})(\d{2})(\d{2})Z")
_DATE_RE = re.compile(r"\d{4}-\d{2}-\d{2}")


# ------------------------------------------------------------------------------------------------ time

def _end_of_day(day: str) -> dt.datetime:
    return dt.datetime.combine(dt.date.fromisoformat(day), dt.time.max, tzinfo=dt.timezone.utc)


def parse_ts(value) -> dt.datetime | None:
    """A UTC instant from a stored timestamp: ISO date (taken as the end of that day, so it is never earlier than the
    event it dates), ISO date-time (Z, offset or naive = UTC, any fraction) or the compact id form YYYY-MM-DDTHHMMSSZ.
    None when blank or unreadable."""
    s = str(value if value is not None else "").strip().lstrip("'")
    if not s or s.lower() == "nan":
        return None
    try:
        if _DATE_RE.fullmatch(s):
            return _end_of_day(s)
        m = re.fullmatch(r"(\d{4}-\d{2}-\d{2})T(\d{2})(\d{2})(\d{2})Z", s)
        if m:
            return dt.datetime.fromisoformat(f"{m[1]}T{m[2]}:{m[3]}:{m[4]}+00:00")
        t = dt.datetime.fromisoformat(s.replace("Z", "+00:00"))
    except ValueError:
        return None
    return t.replace(tzinfo=dt.timezone.utc) if t.tzinfo is None else t.astimezone(dt.timezone.utc)


def id_ts(name: str) -> dt.datetime | None:
    """Timestamp at the start of a folder or record id: `<YYYY-MM-DD>T<HHMMSS>Z...`, a legacy `<YYYY-MM-DD>...`
    (end of that day) or a change id `CHG-<YYYYMMDD>T<HHMMSS>Z-...`."""
    name = str(name or "")
    m = _CHG_RE.match(name)
    if m:
        return dt.datetime(*(int(x) for x in m.groups()), tzinfo=dt.timezone.utc)
    m = _ID_RE.match(name)
    if not m:
        return None
    try:
        if m[2] is None:
            return _end_of_day(m[1])
        return dt.datetime.fromisoformat(f"{m[1]}T{m[2]}:{m[3]}:{m[4]}+00:00")
    except ValueError:
        return None


def cutoff_of(as_of) -> tuple[str, dt.datetime]:
    """(as_of label, cutoff instant). A date (or 'YYYY-MM-DD') means the end of that UTC day; a datetime or ISO
    date-time string is used as given (naive = UTC)."""
    if isinstance(as_of, dt.datetime):
        t = as_of.replace(tzinfo=dt.timezone.utc) if as_of.tzinfo is None else as_of.astimezone(dt.timezone.utc)
        return t.strftime("%Y-%m-%dT%H:%M:%SZ") if not t.microsecond else t.isoformat(), t
    if isinstance(as_of, dt.date):
        return as_of.isoformat(), _end_of_day(as_of.isoformat())
    s = str(as_of).strip()
    if _DATE_RE.fullmatch(s):
        return s, _end_of_day(s)
    t = parse_ts(s)
    if t is None:
        raise ValueError(f"as_of {as_of!r} is not a date (YYYY-MM-DD) or an ISO date-time")
    return cutoff_of(t)


def _iso(t: dt.datetime) -> str:
    return t.strftime("%Y-%m-%dT%H:%M:%S.%fZ")


# ------------------------------------------------------------------------------------------------ secrets

def _json_secret_keys(doc, path="") -> list[str]:
    out = []
    if isinstance(doc, dict):
        for k, v in doc.items():
            p = f"{path}.{k}" if path else str(k)
            if SECRET_KEY_RE.fullmatch(str(k)):
                out.append(p)
            out += _json_secret_keys(v, p)
    elif isinstance(doc, list):
        for i, v in enumerate(doc):
            out += _json_secret_keys(v, f"{path}[{i}]")
    return out


_BOMS = ((b"\xff\xfe\x00\x00", "utf-32-le"), (b"\x00\x00\xfe\xff", "utf-32-be"), (b"\xff\xfe", "utf-16-le"),
         (b"\xfe\xff", "utf-16-be"))


def decode_text(body: bytes) -> tuple[str, str, bytes] | None:
    """(text, codec, bom) for a file that can be scanned reliably: UTF-8 (an optional BOM kept as text) or UTF-16/32
    with a byte-order mark. None for anything else, and for text with NUL bytes (BOM-less UTF-16, binary):
    SEC-A-006 L4."""
    for bom, codec in _BOMS:
        if body.startswith(bom):
            try:
                text = body[len(bom):].decode(codec)
            except UnicodeDecodeError:
                return None
            return (text, codec, bom) if "\0" not in text else None
    try:
        text = body.decode("utf-8")
    except UnicodeDecodeError:
        return None
    return (text, "utf-8", b"") if "\0" not in text else None


def secret_reason(rel: str, body: bytes) -> str | None:
    """Why a file must not leave data_dir (credential or licence file with credentials), or None."""
    name = rel.rsplit("/", 1)[-1]
    if name.lower() in SECRET_FILES:
        return "secret: licence or credential file (never exported)"
    if SECRET_NAME_RE.search(name):
        return "secret: credential-like file name"
    dec = decode_text(body)
    text = dec[0] if dec else body.decode("utf-8", errors="ignore")
    if name.lower().endswith(".json"):
        try:
            keys = _json_secret_keys(json.loads(text))
        except ValueError:
            keys = []
        if keys:
            return f"secret: JSON with credential-like keys ({len(keys)})"
    if SECRET_TEXT_RE.search(text):
        return "secret: text matches a credential pattern"
    return None


def restricted_reason(rel: str, body: bytes) -> str | None:
    """Why a file's licence bars it from the room (EQ-A-0044), or None: raw_yahoo.csv, a GOOGLEFINANCE market-history
    file (EQ-A-0054, market_history.market_restricted_reason: the archive, research copies, and any market_history CSV
    with country ETF columns, including frozen replay copies), or a CSV (not an index.csv, which only lists licences
    as anchor metadata) with a licence column that carries a desk-barred term (non-commercial, personal).

    EQ-A-0076: the licence register (data/licences.csv) is consulted first, by path (licences.file_licence) and, for
    a CSV other than index.csv, by the values of its licence column(s). A row with validator_nda=barred withholds
    the file; the reason is the existing rule's text when that rule also withholds it (unchanged wording), else the
    register's. A row saying allowed, or no row, falls back to the rules below. A register file that exists but is
    invalid withholds every file (fail closed); build_data_room refuses outright (require_register)."""
    from .licences import invalid_reason
    bad = invalid_reason()                  # register present but invalid: withhold everything (AGENT-05 review)
    if bad:
        return bad
    row = _register_room_row(rel, body)
    if row is not None and row["validator_nda"] in ("barred", "UNVERIFIED"):     # UNVERIFIED: withheld until Sam decides
        from .licences import register_reason
        return _restricted_reason_rules(rel, body) or register_reason(row, "validator")
    return _restricted_reason_rules(rel, body)


def _register_room_row(rel: str, body: bytes) -> dict | None:
    """Most restrictive register row for a file: its path, plus each distinct licence-column value of a CSV."""
    from .licences import file_licence, licence_for, most_restrictive
    rows = [file_licence(rel)]
    name = rel.rsplit("/", 1)[-1]
    if name.lower().endswith(".csv") and name != "index.csv":
        dec = decode_text(body)
        if dec is not None:
            reader = csv.reader(io.StringIO(dec[0], newline=""))
            header = next(reader, None) or []
            cols = [i for i, h in enumerate(header) if h.strip().lower() in LICENCE_COLUMNS]
            if cols:
                values = {row[i].strip() for row in reader for i in cols if i < len(row) and row[i].strip()}
                rows += [licence_for(licence=v) for v in sorted(values)]
    return most_restrictive([r for r in rows if r is not None])


RESEARCH_DIR_RE = re.compile(r"(?:^|/)panel/research/([^/]+)/")
RESEARCH_FALLBACK_REASON = ("licence: research dataset file (data/panel/research/{key}/) whose dataset is not cleared "
                            "for sharing (research.REGISTRY client_ok is not True, or unknown dataset); withheld "
                            "(SEC-A-010 L3: holds even when the licence register is missing or invalid)")


def _research_reason(rel: str) -> str | None:
    """Code rule kept on the old-rules path (SEC-A-010 L3): a file under panel/research/<key>/ is withheld unless the
    research REGISTRY entry for <key> says client_ok=True (V-Dem, Aqueduct, UCDP); an unknown key is withheld too."""
    m = RESEARCH_DIR_RE.search(rel.replace("\\", "/"))
    if not m:
        return None
    try:
        from .research import REGISTRY
        ok = REGISTRY.get(m.group(1))
        cleared = bool(ok and ok.client_ok)
    except Exception:                                  # noqa: BLE001 - cannot tell: withhold
        cleared = False
    return None if cleared else RESEARCH_FALLBACK_REASON.format(key=m.group(1))


def _restricted_reason_rules(rel: str, body: bytes) -> str | None:
    """The pre-register rules of restricted_reason (see there)."""
    why = _research_reason(rel)
    if why:
        return why
    name = rel.rsplit("/", 1)[-1]
    if name.lower() in RESTRICTED_FILES:                  # SEC-A-006 L4: case-insensitive, and any *yahoo* file
        return RESTRICTED_FILES[name.lower()]
    if "yahoo" in name.lower():
        return YAHOO_FILE_REASON
    from .market_history import market_restricted_reason      # EQ-A-0054: GOOGLEFINANCE market history
    why = market_restricted_reason(rel)
    if why:
        return why
    if not name.lower().endswith(".csv") or name == "index.csv":
        return None
    dec = decode_text(body)
    if dec is None:
        return None
    text = dec[0]
    reader = csv.reader(io.StringIO(text, newline=""))
    header = next(reader, None) or []
    why = market_restricted_reason(rel, header)
    if why:
        return why
    cols = [i for i, h in enumerate(header) if h.strip().lower() in LICENCE_COLUMNS]
    if not cols:
        return None
    from .market.gate import DESK_BARRED_LICENCE_TERMS
    hits: dict[str, int] = {}
    for row in reader:
        for i in cols:
            v = row[i].casefold() if i < len(row) else ""
            term = next((t for t in DESK_BARRED_LICENCE_TERMS if t in v), None)
            if term:
                hits[term] = hits.get(term, 0) + 1
                break
    if not hits:
        return None
    return ("licence: rows licensed " + ", ".join(f"{t!r} ({n})" for t, n in sorted(hits.items()))
            + "; not for an external validator (market.gate.DESK_BARRED_LICENCE_TERMS)")


def redact_emails(body: bytes) -> tuple[bytes, int]:
    """(body with every EMAIL_RE and EMAIL_PCT_RE match replaced by REDACTED_EMAIL, replacements). UTF-8 and
    BOM-marked UTF-16/32 text is scanned and written back in its own encoding; other bytes are returned as they are
    (the build withholds them, SEC-A-006 L4)."""
    dec = decode_text(body)
    if dec is None:
        return body, 0
    text, codec, bom = dec
    new, n = EMAIL_RE.subn(REDACTED_EMAIL, text)
    new, n2 = EMAIL_PCT_RE.subn(REDACTED_EMAIL, new)
    return (bom + new.encode(codec), n + n2) if n + n2 else (body, 0)


# ------------------------------------------------------------------------------------------------ restricted values

def restricted_value_index(d: Path) -> dict:
    """{(table, key, country): [values]} that a record attributes to a restricted source (Yahoo / yfinance, or a
    non-commercial / personal licence): the current pull's live/provenance.csv, every live vintage's provenance.csv
    and audit_trail.csv (audit.restricted_reason). Read from data_dir whatever the cutoff, only to recognise values."""
    from .audit import _records, restricted_reason as source_reason
    recs = _records(d / "live" / "provenance.csv", "live/provenance.csv", "value")
    root = d / "live" / "vintages"
    if root.is_dir() and not root.is_symlink():
        for v in sorted(p for p in root.iterdir() if p.is_dir() and not p.is_symlink()):
            recs += _records(v / "provenance.csv", v.name, "value")
    recs += _records(d / "audit_trail.csv", "audit_trail.csv", "value")
    out: dict = {}
    for r in recs:
        if source_reason(r["source"], r["licence"]) and r["value"] == r["value"]:      # not NaN
            out.setdefault((r["table"], str(r["key"]), r["country"]), []).append(float(r["value"]))
    return out


def _num(v) -> float | None:
    try:
        x = float(str(v).strip().lstrip("'"))
    except ValueError:
        return None
    return x if x == x else None


def _restricted_value(index: dict, cell: tuple, v) -> bool:
    from .audit import _same
    x = _num(v)
    return x is not None and any(_same(x, y) for y in index.get(cell, ()))


# wide tables: file name -> (table, id column or None for the first column, rows are 'countries' or 'keys')
WIDE_TABLES = {"live_profile.csv": ("Country Profile", None, "countries"), "live_inputs.csv": ("Inputs", None, "keys"),
               "countries.csv": ("Country Profile", "country", "countries"), "indicators.csv": ("Inputs", "id", "keys")}


def blank_restricted(rel: str, body: bytes, index: dict) -> tuple[bytes, dict | None, str | None]:
    """SEC-A-006 M2: (body with Yahoo-derived values blanked, {"restricted_rows", "restricted_cells", "rule"} or None
    when nothing changed, a withhold reason or None). See the module docstring for the three rules. index.csv
    files (anchor metadata) and non-CSV files are returned unchanged."""
    from .audit import LICENCE_COLUMNS as LIC, restricted_reason as source_reason
    name = rel.rsplit("/", 1)[-1]
    if not name.lower().endswith(".csv") or name == "index.csv":
        return body, None, None
    dec = decode_text(body)
    if dec is None:
        return body, None, None
    text, codec, bom = dec
    rows = list(csv.reader(io.StringIO(text, newline="")))
    if len(rows) < 2:
        return body, None, None
    header = rows[0]
    low = [h.strip().lower() for h in header]
    vals = [i for i, h in enumerate(low) if h in RESTRICTED_VALUE_COLUMNS]
    src = low.index("source") if "source" in low else None
    lic = next((i for i, h in enumerate(low) if h in LIC), None)
    n_rows = n_cells = 0

    def cell(r, i):
        return r[i] if i < len(r) else ""

    def blank(r, idx):
        nonlocal n_cells
        for i in idx:
            if i < len(r) and r[i] != "":
                r[i] = ""
                n_cells += 1

    long_ = {"table", "key", "country"} <= set(low)
    t, k, c = (low.index("table"), low.index("key"), low.index("country")) if long_ else (0, 0, 0)
    probe = [low.index(x) for x in ("live", "value", "live_value") if x in low]

    def by_value(r):
        return long_ and any(_restricted_value(index, (cell(r, t), cell(r, k), cell(r, c)), cell(r, i)) for i in probe)

    if src is not None or lic is not None:                                     # rule 1: the row's own source
        rule = "source"
        hits = [r for r in rows[1:] if source_reason(cell(r, src) if src is not None else "",
                                                     cell(r, lic) if lic is not None else "") or by_value(r)]
        if hits and not vals:
            return body, None, RESTRICTED_NO_VALUE_COLUMNS
        for r in hits:
            n_rows += 1
            blank(r, vals)
    elif long_ and vals:                                                        # rule 2: long file, by value
        rule = "value"
        for r in rows[1:]:
            if by_value(r):
                n_rows += 1
                blank(r, vals)
    elif name.lower() in WIDE_TABLES:                                           # rule 3: wide table, by value
        rule = "value"
        table, id_col, rows_are = WIDE_TABLES[name.lower()]
        ic = low.index(id_col) if id_col and id_col in low else 0
        for r in rows[1:]:
            hit = False
            for i, h in enumerate(header):
                if i == ic or i >= len(r):
                    continue
                key = (table, h, r[ic]) if rows_are == "countries" else (table, r[ic], h)
                if r[i] != "" and _restricted_value(index, key, r[i]):
                    r[i] = ""
                    n_cells += 1
                    hit = True
            n_rows += hit
    else:
        return body, None, None
    if not n_cells:
        return body, None, None
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\r\n" if text.split("\n", 1)[0].endswith("\r") else "\n")
    w.writerows(rows)
    return bom + buf.getvalue().encode(codec), {"restricted_rows": n_rows, "restricted_cells": n_cells, "rule": rule}, None


# ------------------------------------------------------------------------------------------------ row filters

def _lineterminator(body: bytes) -> str:
    first = body.split(b"\n", 1)[0]
    return "\r\n" if first.endswith(b"\r") else "\n"


def filter_csv(body: bytes, keep) -> tuple[bytes, dict]:
    """Keep the header and the rows for which keep(row_dict) is True; keep may return None for 'undated' (dropped).
    Rows are re-serialised with the csv module and the source's line terminator (values unchanged)."""
    text = body.decode("utf-8")
    rows = list(csv.reader(io.StringIO(text, newline="")))
    st = {"rows_kept": 0, "rows_dropped": 0, "rows_undated": 0}
    if not rows:
        return body, st
    header, buf = rows[0], io.StringIO()
    w = csv.writer(buf, lineterminator=_lineterminator(body))
    w.writerow(header)
    for r in rows[1:]:
        k = keep(dict(zip(header, r)))
        if k:
            w.writerow(r)
            st["rows_kept"] += 1
        else:
            st["rows_undated" if k is None else "rows_dropped"] += 1
    return buf.getvalue().encode("utf-8"), st


def _ts_keep(col: str, cut: dt.datetime, seen: list, undated=None):
    def keep(row):
        t = parse_ts(row.get(col))
        if t is None:
            return undated
        seen.append(t)
        return t <= cut
    return keep


def filter_jsonl(body: bytes, cut: dt.datetime, seen: list) -> tuple[bytes, dict]:
    out, st = [], {"rows_kept": 0, "rows_dropped": 0, "rows_undated": 0}
    for line in body.decode("utf-8").splitlines(keepends=True):
        if not line.strip():
            continue
        try:
            t = parse_ts(json.loads(line).get("ts_utc"))
        except (ValueError, AttributeError):
            t = None
        if t is None:
            st["rows_undated"] += 1
            continue
        seen.append(t)
        if t <= cut:
            out.append(line if line.endswith("\n") else line + "\n")
            st["rows_kept"] += 1
        else:
            st["rows_dropped"] += 1
    return "".join(out).encode("utf-8"), st


# ------------------------------------------------------------------------------------------------ selection

# (path prefix parts, kind, index timestamp column, index id column)
WEO_ROOT = ("panel", "weo_vintages")
FOLDER_STORES = (
    (("live", "vintages"), "live_vintage", "retrieved_utc", "vintage_id"),
    (("panel", "vintages"), "panel_vintage", "created_utc", "vintage_id"),
    # EQ-A-0064 WEO archive (IMF, EXC-003: validator under NDA). Folders are selected from index.csv, not by id
    # (SEC-A-008 M2: no longer reaches the room through replay snapshot copies)
    (WEO_ROOT, "weo_vintage", "imported_utc", "release"),
    (("live", "market", "snapshots"), "market_snapshot", "saved_utc", "snapshot_id"),
    (("live", "events", "exports"), "event_export", "created_utc", "export_id"),
)


def _store_of(parts: tuple) -> tuple | None:
    """(store root parts, kind, ts column, id column) for a path inside a folder store, else None."""
    for root, kind, tcol, icol in FOLDER_STORES:
        if parts[:len(root)] == root:
            return root, kind, tcol, icol
    if len(parts) >= 4 and parts[:2] == ("live", "events") and parts[3] == "vintages":
        return parts[:4], "event_vintage", "retrieved_utc", "vintage_id"
    if parts[:2] == ("live", "snapshots"):
        return ("live", "snapshots"), "snapshot", "frozen_utc", "snapshot"
    return None


def _all_files(d: Path) -> list[str]:
    return sorted(p.relative_to(d).as_posix() for p in d.rglob("*") if p.is_file() or p.is_symlink())


def _mvp_built(d: Path) -> dt.datetime | None:
    """built_utc of data/mvp/manifest.json (EQ-A-0125), or None when there is no readable MVP manifest."""
    mp = d / MVP_ROOT / "manifest.json"
    if not mp.is_file() or mp.is_symlink():
        return None
    try:
        m = json.loads(mp.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None
    return parse_ts(m.get("built_utc")) if isinstance(m, dict) and m.get("schema") == MVP_SCHEMA else None


def _plan(d: Path, cut: dt.datetime, include_current: bool, include_restricted: bool = False,
          include_register: bool = False, include_mvp: bool = False
          ) -> tuple[list[dict], list[dict], list[dict], list, list[dict]]:
    """Classify every file under d: (entries to write, excluded, filter stats, timestamps seen, withheld).
    include_register adds data/licences.csv (kind licence_register) and include_mvp the frozen MVP dataset data/mvp
    (kind mvp_dataset) when it was built at or before the cutoff (EQ-A-0125); both pass the same licence, secret and
    e-mail rules as every other file."""
    entries, excluded, filtered, seen, withheld = [], [], [], [], []
    mvp_t = _mvp_built(d) if include_mvp else None
    if mvp_t is not None:
        seen.append(mvp_t)
    rels = _all_files(d)
    index = {} if include_restricted else restricted_value_index(d)

    def skip(rel, reason):
        excluded.append({"source": rel, "reason": reason})

    def add(rel, kind, body, stats=None):
        why = None if include_restricted else restricted_reason(rel, body)
        if why is None and decode_text(body) is None:   # SEC-A-006 L4: cannot be scanned for secrets or e-mails
            why = UNSCANNABLE_REASON
        info = None
        if why is None and not include_restricted:       # SEC-A-006 M2: blank Yahoo-derived values
            new, info, why = blank_restricted(rel, body, index)
        if why:                                # would be in the room: withheld, and listed in the hashed manifest
            skip(rel, why)
            withheld.append({"path": f"data/{rel}", "source": rel, "size": len(body),
                             "sha256": hashlib.sha256(body).hexdigest(), "reason": why})
            return
        e = {"path": f"data/{rel}", "source": rel, "kind": kind, "body": body}
        if info:
            e.update(body=new, original=body, restricted=info)
        if stats is not None:
            e["filter"] = {"rows_kept": stats["rows_kept"]}
            filtered.append({"source": rel, **stats})
        entries.append(e)

    # pass 1: which folders of each store are selected (by the timestamp in their id)
    selected: dict[tuple, set] = {}
    for rel in rels:
        parts = tuple(rel.split("/"))
        st = _store_of(parts)
        if st is None or len(parts) < len(st[0]) + 2 or any(p.startswith(".") for p in parts):
            continue
        folder = parts[len(st[0])]
        t = id_ts(folder)
        if t is not None:
            seen.append(t)
        if t is not None and t <= cut and st[1] != "snapshot":
            selected.setdefault(st[0], set()).add(folder)
    # SEC-A-008 M2 (EQ-A-0066): a WEO release folder is named after the release (YYYY-MM), so it is selected by its first
    # index.csv row: imported at or before the cutoff
    widx = d.joinpath(*WEO_ROOT, "index.csv")
    if widx.is_file() and not widx.is_symlink():
        first: dict = {}
        with open(widx, newline="", encoding="utf-8") as f:
            for r in csv.DictReader(f):
                first.setdefault(r.get("release"), r)
        for release, r in first.items():
            t = parse_ts(r.get("imported_utc"))
            if t is not None:
                seen.append(t)
            if t is not None and t <= cut and release and not release.startswith(".") and "/" not in release:
                selected.setdefault(WEO_ROOT, set()).add(release)
    live_sel = selected.get(("live", "vintages"), set())
    snap_rows: set = set()
    idx = d / "live" / "snapshots" / "index.csv"
    if idx.is_file() and not idx.is_symlink():
        with open(idx, newline="", encoding="utf-8") as f:
            for r in csv.DictReader(f):
                t = parse_ts(r.get("frozen_utc"))
                if t is not None:
                    seen.append(t)
                if t is not None and t <= cut and r.get("vintage_id") in live_sel:
                    snap_rows.add(r.get("snapshot"))
    snaps = set(snap_rows)
    for rel in rels:
        parts = tuple(rel.split("/"))
        if parts[:2] == ("live", "snapshots") and len(parts) >= 4 and "-pre-apply" in parts[2]:
            t = id_ts(parts[2])
            if t is not None and t <= cut:
                snaps.add(parts[2])
    selected[("live", "snapshots")] = snaps

    feeds_t = None
    fj = d / "live" / "feeds.json"
    if fj.is_file() and not fj.is_symlink():
        try:
            feeds_t = parse_ts(json.loads(fj.read_text(encoding="utf-8")).get("retrieved"))
        except (OSError, ValueError, AttributeError):
            feeds_t = None
    if feeds_t is not None:
        seen.append(feeds_t)

    undated = []
    for rel in rels:
        parts = tuple(rel.split("/"))
        p = d / rel
        if any(x.startswith(".") for x in parts):
            skip(rel, "hidden, lock or temporary file")
            continue
        if p.is_symlink():
            skip(rel, "symlink (never followed)")
            continue
        body = p.read_bytes()
        why = secret_reason(rel, body)
        if why:
            skip(rel, why)
            continue
        if include_register and rel == "licences.csv":          # EQ-A-0125
            add(rel, "licence_register", body)
            continue
        if include_mvp and parts[0] == MVP_ROOT:                  # EQ-A-0125: whole frozen dataset, or none of it
            if mvp_t is None:
                skip(rel, "MVP dataset without a readable manifest.json (schema econquest-mvp-dataset/1, built_utc)")
            elif mvp_t > cut:
                skip(rel, f"MVP dataset built after the cutoff ({_iso(mvp_t)})")
            else:
                add(rel, "mvp_dataset", body)
            continue
        st = _store_of(parts)
        if st is not None:
            root, kind, tcol, icol = st
            n = len(root)
            if len(parts) == n + 1 and parts[-1] == "index.csv":
                sel = selected.get(root, set())
                if kind == "snapshot":
                    kind_i = "replay_snapshot_index"
                    keep_rows = snap_rows

                    def keep(r, _k=keep_rows):
                        t = parse_ts(r.get("frozen_utc"))
                        return None if t is None else (r.get("snapshot") in _k and t <= cut)
                else:
                    kind_i = f"{kind}_index"

                    def keep(r, _sel=sel, _t=tcol, _i=icol):
                        t = parse_ts(r.get(_t))
                        return None if t is None else (r.get(_i) in _sel and t <= cut)
                out, stats = filter_csv(body, keep)
                add(rel, kind_i, out, stats)
                continue
            if len(parts) >= n + 2:
                folder = parts[n]
                if folder in selected.get(root, set()):
                    k = kind if kind != "snapshot" else ("pre_apply_snapshot" if "-pre-apply" in folder else "replay_snapshot")
                    add(rel, k, body)
                # folders after the cutoff (or not selected) are simply not part of this as-of room
                continue
            undated.append((rel, body))
            continue
        if rel == "live/review_ledger.csv":
            out, stats = filter_csv(body, _ts_keep("ts_utc", cut, seen))
            add(rel, "review_ledger", out, stats)
        elif rel == "live/market/manual_quotes.csv":
            out, stats = filter_csv(body, _ts_keep("entered_utc", cut, seen))
            add(rel, "manual_quotes", out, stats)
        elif rel == "market/cds_snapshots.csv":
            def keep_cds(r):
                t, a = id_ts(r.get("snapshot_id")), parse_ts(r.get("as_of"))
                if t is None or a is None:
                    return None
                seen.append(t)
                return t <= cut and a <= cut
            out, stats = filter_csv(body, keep_cds)
            add(rel, "cds_snapshots", out, stats)
        elif rel == "approvals/log.jsonl":
            out, stats = filter_jsonl(body, cut, seen)
            add(rel, "approvals_log", out, stats)
        elif parts[:2] == ("approvals", "proposals") and len(parts) == 3:
            t = id_ts(Path(parts[2]).stem)
            if t is not None:
                seen.append(t)
            if t is not None and t <= cut:
                add(rel, "approvals_proposal", body)
            elif t is None:
                skip(rel, "approval proposal without a change-id timestamp")
        elif rel == "approvals/head.json":
            skip(rel, "current hash-chain head: the kept log prefix is verified from genesis by verify.py instead")
        elif rel == "audit_trail.csv":
            out, stats = filter_csv(body, _ts_keep("retrieved", cut, seen, undated=True))
            stats["rows_undated_kept"] = stats["rows_kept"] - sum(
                1 for r in csv.DictReader(io.StringIO(out.decode("utf-8"))) if parse_ts(r.get("retrieved")))
            add(rel, "audit_trail", out, stats)
        elif (len(parts) == 2 and parts[0] == "live" and p.suffix in (".csv", ".json")
              and parts[1] not in ("events_weekly.csv",)):
            if feeds_t is not None and feeds_t <= cut:
                add(rel, "current_pull", body)
            elif feeds_t is None:
                undated.append((rel, body))
            # a current pull retrieved after the cutoff is not part of this as-of room
        else:
            undated.append((rel, body))

    for rel, body in undated:
        if include_current:
            add(rel, "current_working_copy", body)
        else:
            skip(rel, "undated working copy: no point-in-time record (see README; include_current to add)")
    return entries, excluded, filtered, seen, withheld


def _altered_anchors(d: Path, altered: dict) -> dict:
    """What the build verified on the source for each live/panel vintage folder and approvals log it altered
    (withheld or redacted files): {room path: {...,"verified_at_build": "ok" | problem}} (EQ-A-0044)."""
    from .dataroom_verify import _last_row, _rows, _vintage_row, folder_content_hash
    out = {}
    folders = set()
    for path in altered:
        parts = path.split("/")
        if parts[:3] in (["data", "live", "vintages"], ["data", "panel", "vintages"]) and len(parts) == 5:
            folders.add("/".join(parts[:4]))
    for room in sorted(folders):
        src = d / room[len("data/"):]
        digest, n = folder_content_hash(src)
        idx = src.parent / "index.csv"
        rows = _rows(idx) if idx.is_file() else []
        if room.startswith("data/live/"):
            row, agree = _vintage_row(rows, src.name)
        else:
            row, agree = _last_row(rows, "vintage_id", src.name), True
        if row is None:
            ver = "unanchored: no row in index.csv"
        elif not agree:
            ver = "failed: index.csv rows for this id disagree"
        elif row.get("hash") != digest or str(row.get("n_files")) != str(n):
            ver = f"failed: source content hash {digest[:12]} / {n} files != index.csv"
        else:
            ver = "ok"
        out[room] = {"index_hash": row.get("hash") if row else None, "n_files": n, "source_content_hash": digest,
                     "verified_at_build": ver}
    return out


def _four_eyes(ledger_body: bytes) -> bytes:
    from .ledger import person_key
    rows = list(csv.DictReader(io.StringIO(ledger_body.decode("utf-8"), newline="")))
    buf = io.StringIO()
    w = csv.DictWriter(buf, FOUR_EYES_COLUMNS, lineterminator="\n", extrasaction="ignore")
    w.writeheader()
    for r in rows:
        author, approver = r.get("author", ""), r.get("approver", "")
        selfa = str(r.get("self_approved", "")).strip().lstrip("'").lower() == "yes"
        if selfa:
            fe = "self-approved"
        elif approver.strip() and person_key(approver) != person_key(author):
            fe = "yes"
        elif approver.strip():
            fe = "no (approver is the author, not flagged)"
        else:
            fe = "no approver"
        w.writerow({**{c: r.get(c, "") for c in FOUR_EYES_COLUMNS}, "four_eyes": fe,
                    "attestation": "yes" if str(r.get("content_sha256", "")).strip() else "no"})
    return buf.getvalue().encode("utf-8")


def _code_version() -> dict:
    try:
        from .. import __version__
        from ..versioning import code_hash
        return {"version": __version__, "code_hash": code_hash()}
    except Exception as e:  # noqa: BLE001 - recorded, never blocks the export
        return {"version": None, "code_hash": None, "error": type(e).__name__}


# ------------------------------------------------------------------------------------------------ README

def _readme(as_of: str, cut: dt.datetime, files: list[dict], counts: dict, checks: list[dict], options: dict,
            code: dict, withheld: list | None = None, redactions: list | None = None, lim: dict | None = None,
            labels: dict | None = None, baseline: dict | None = None, mvp: dict | None = None) -> str:
    withheld, redactions, lim = withheld or [], redactions or [], lim or {}
    altered_checks = [c for c in checks if c["status"] == "altered"]
    kinds = sorted(counts)
    unanchored = [c for c in checks if c["status"] == "unanchored"]
    failed = [c for c in checks if c["status"] == "failed"]
    has_replay = counts.get("replay_snapshot", {}).get("files", 0) > 0
    L = [f"# econquest data room, as of {as_of}" + (f" ({baseline['label']})" if baseline else ""), ""]
    if baseline:                                             # EQ-A-0125: first thing a reader sees
        L += [f"> **{baseline['banner']}.** Every licence decision in this room (what is withheld, blanked or labelled) "
              f"comes from a DEMO baseline of the licence register (`{baseline['register']}`, sha256 "
              f"`{baseline['register_sha256'][:16]}`, {baseline['register_rows']} rows, approver "
              f"\"{baseline['approver']}\"). Sam has not approved a licence register baseline yet; until he does, this "
              "room is shared-data evidence only and is not cleared for any client use.", ""]
    L += ["Point-in-time export of the data inputs econquest held at the cutoff below, for independent validation "
         "(PI-5). Built by `econquest.ingestion.dataroom` (EQ-A-0041). Everything here is a byte copy of a file in the "
         "econquest data folder, or a row subset of an append-only file, selected by the as-of rule recorded for that "
         "file in MANIFEST.json. Nothing dated after the cutoff is included.", "",
         f"- as-of: `{as_of}`; cutoff (UTC, inclusive): `{_iso(cut)}`",
         f"- code: econquest {code.get('version')} (code hash `{code.get('code_hash')}`)",
         f"- files listed in MANIFEST.json: {len(files)} (this README and verify.py included)",
         f"- include_current: {options['include_current']}; include_restricted: {options.get('include_restricted', False)}",
         "",
         "## How to verify", "",
         "```", "python -I verify.py            # standard library only; exit 0 = VERIFIED", "python -I verify.py --json",
         "python -I verify.py --expect-manifest-sha256 HEX   # HEX = the manifest_sha256 sent to you separately",
         "```", "",
         "Give `--expect-manifest-sha256` the value received separately: without it, a room edited and fully "
         "re-hashed (for example with a label removed) still verifies against itself (SEC-A-014 P3-L1).", "",
         "verify.py recomputes the sha256 and size of every file in MANIFEST.json, reports missing, extra and changed "
         "files, recomputes `manifest_sha256` (SHA-256 of the canonical JSON of MANIFEST.json without "
         "`manifest_sha256` and `build`) and `content_sha256` (SHA-256 of `path=sha256;` over all files in path order), "
         "and re-runs the integrity anchors of each store: vintage content hashes against index.csv, snapshot and "
         "export manifests against their index.csv rows, frozen replay inputs against snapshots/index.csv, and the "
         "change-approval log's hash chain from genesis. Compare `manifest_sha256` with the value recorded in the "
         "evidence bundle or sent to you separately: a matching recomputed hash proves the room is the one exported.", "",
         "With econquest installed, `python -m econquest.ingestion.dataroom verify <room>` runs the same code.", "",
         "## Folders", "",
         "| path | what it is | as-of rule |", "|---|---|---|"]
    guide = [
        ("data/live/vintages/<id>/", "live pull vintages: what each IMF/World Bank/BIS/market pull returned (raw_*, live_inputs, provenance, review, unserved, feeds.json)", "live_vintage"),
        ("data/live/vintages/index.csv", "content hash and file count per vintage (the anchor)", "live_vintage_index"),
        ("data/panel/vintages/<id>/", "hazard panel and default-episode vintages", "panel_vintage"),
        ("data/panel/weo_vintages/<YYYY-MM>/", "IMF WEO releases as archived (raw file, weo_long.csv, manifest.json "
         "with licence); IMF terms, validator under NDA (EXC-003)", "weo_vintage"),
        ("data/live/market/snapshots/<id>/", "market quote snapshots (quotes.csv with licence column, manifest.json)", "market_snapshot"),
        ("data/market/cds_snapshots.csv", "gated CDS curve rows exported for the models", "cds_snapshots"),
        ("data/live/market/manual_quotes.csv", "hand-typed market quotes with author, approver and content hash", "manual_quotes"),
        ("data/live/events/<source>/vintages/<id>/", "event feed vintages (UCDP, GDELT, ACLED)", "event_vintage"),
        ("data/live/events/exports/<id>/", "archived event feed exports (events_long, events_weekly) as consumed", "event_export"),
        ("data/live/snapshots/<vintage>-inputs/", "frozen run inputs of an applied vintage (replay.freeze_inputs), with manifest.json", "replay_snapshot"),
        ("data/live/snapshots/<ts>-pre-apply/", "indicators/countries before an apply, forced_cells.csv", "pre_apply_snapshot"),
        ("data/live/review_ledger.csv", "review ledger: every gate decision and attestation with author, approver, self_approved", "review_ledger"),
        ("derived/four_eyes.csv", "the ledger rows with four-eyes / self-approval / attestation flags spelled out", "derived"),
        ("data/approvals/", "change-approval log (hash chained) and proposals for assumptions and limits", "approvals_log"),
        ("data/audit_trail.csv", "per-cell provenance of the run inputs (origin, source, series, transform, decision)", "audit_trail"),
        ("data/live/*.csv, *.json", "the current pull: transform_log, unserved, feed_failures, provenance, diff_vs_seed, review", "current_pull"),
        (LIMITATIONS_PATH, "data limitations register (GOV-010): per indicator source, coverage, seed share, gate holds, known issues", "limitations"),
    ]
    if "licence_register" in counts:
        guide.append(("data/licences.csv", "the per-dataset licence register (EQ-A-0076) that governed this build",
                      "licence_register"))
    if "mvp_dataset" in counts:
        guide.append(("data/mvp/", "the frozen MVP dataset the desk base runs on (data/, provenance.csv, gate_report.json, "
                      "manifest.json)", "mvp_dataset"))
    for path, what, kind in guide:
        L.append(f"| `{path}` | {what} | {RULES[kind]} |")
    L += ["", "## Contents by kind (this README not counted)", "", "| kind | files | bytes |", "|---|---:|---:|"]
    L += [f"| {k} | {counts[k]['files']} | {counts[k]['bytes']} |" for k in kinds]
    if lim.get("generated"):
        reg = (f"The data limitations register (per indicator source, coverage, seed share, gate holds, known issues) is "
               f"`{LIMITATIONS_PATH}`, generated for this as-of from `{lim.get('live_source')}`. Its two Register tables "
               "are computed; its narrative (summary, column notes, cross-cutting table) was written by hand "
               "(EQ-A-0042), may postdate the cutoff and is the one exception to the cutoff rule.")
    else:
        reg = (f"The data limitations register was not generated for this as-of ({lim.get('reason', 'not requested')}); "
               f"see `{LIMITATIONS_DOC}` in the econquest repository.")
    L += ["", "## Known limitations", "", reg, "",
          "- IMF data (WEO, IMF SDMX and values derived from them) is licensed for internal research use only. It is "
          "provided to the validator under NDA for validating this model only (owner decision, EQ-A-0059); do not reuse, "
          "republish or pass it on. Rows carry the tag `IMF: internal research use only`; the WEO release archive "
          "(`data/panel/weo_vintages/`, EQ-A-0064) carries it in each manifest.json (EXC-003).",
          # EQ-A-0073 / SEC-A-009 M2 (owner decision): the mirror's rates go to the validator under NDA, raw answers do not
          "- theratesapi.com exchange rates (Banca d'Italia/ECB via a third-party mirror; VES, NGN, PKR, VND, ZMW) are "
          "internal research data under EXC-005, provided to the validator under NDA for validating this model only; "
          "do not reuse, republish or pass them on.",
          "- Legacy date-only vintage ids (`YYYY-MM-DD`) carry no time: they count as the end of that UTC day, "
          "so they enter a room only when the cutoff is at or after the end of that day.",
          "- `audit_trail.csv` is regenerated by every run. Rows retrieved after the cutoff are dropped, rows with no "
          "retrieved date (seed estimates, hand-entered values) are kept, and the remaining columns show the view of "
          "the run that last wrote the file, which can be later than the cutoff. The vintages and the ledger are the "
          "point-in-time record.",
          "- Current-pull files (`data/live/*.csv`, `*.json`) are dated as a whole by `live/feeds.json` `retrieved`, a "
          "date only. They are replaced by the next pull, so a room rebuilt later for the same as-of date may no longer "
          "contain them; the vintage folders hold what each pull returned.",
          "- Filtered row files (index.csv files, the ledger, approvals log, cds_snapshots, manual_quotes, audit_trail) "
          "are row subsets re-written with the csv module; values are unchanged, but when rows were dropped the file "
          "hash differs from the source file. Each such entry has `filter.rows_kept` in MANIFEST.json.",
          "- `approvals/head.json` is not exported: it names the current chain head. verify.py checks the exported "
          "prefix of the chain from genesis instead.",
          "- Secrets are never exported (`vendor_licences.json`, credential-named files, JSON with credential keys, "
          "text matching credential patterns). Licence tags inside the data are kept. Exclusions are listed under "
          "`build.excluded` in MANIFEST.json, outside the hash."]
    if withheld:
        L.append(f"- {len(withheld)} file(s) withheld because their licence does not allow passing them to an external "
                 "validator, or because they could not be scanned for secrets (listed under `withheld` in "
                 "MANIFEST.json with size, sha256 and reason; verify.py does not report them missing): "
                 + ", ".join(f"`{w['path']}`" for w in withheld[:10]) + (" ..." if len(withheld) > 10 else ""))
    restricted = [r for r in redactions if r.get("restricted_cells")]
    if restricted:
        L.append(f"- Values derived from Yahoo Finance data (personal, non-commercial terms; replaced by official "
                 f"sources on 2026-10-23) are blank in {len(restricted)} file(s), "
                 f"{sum(r['restricted_cells'] for r in restricted)} cell(s) in "
                 f"{sum(r['restricted_rows'] for r in restricted)} row(s); the source labels are kept, so each blank "
                 "is traceable (listed under `redactions` in MANIFEST.json with the original sha256 and size): "
                 + ", ".join(f"`{r['path']}`" for r in restricted[:10]) + (" ..." if len(restricted) > 10 else ""))
    emails = [r for r in redactions if r.get("replacements")]
    if emails:
        L.append(f"- E-mail addresses were replaced by `{REDACTED_EMAIL}` in {len(emails)} file(s), "
                 f"{sum(r['replacements'] for r in emails)} replacement(s) (listed under `redactions` in "
                 "MANIFEST.json with the original sha256 and size).")
    if altered_checks:
        L.append(f"- {len(altered_checks)} anchor(s) are `altered`: a vintage content hash (or the approvals chain) covers "
                 "the original bytes of a withheld or redacted file, so verify.py checks the index row against what the "
                 "build verified on the source (`altered_anchors` in MANIFEST.json) instead of recomputing it: "
                 + ", ".join(f"`{c['path']}`" for c in altered_checks[:10]))
    if not has_replay:
        L.append("- No frozen replay-input snapshot (`replay.freeze_inputs`) exists at or before the cutoff, so the "
                 "applied working files a run reads (indicators.csv, countries.csv, market_history, panel CSVs, "
                 "hand-entered CSVs) are not in this room: they are undated working copies. Rebuild from the vintages, "
                 "or build with include_current when the as-of date is the latest record.")
    if options["include_current"]:
        L.append("- include_current was set: files of kind `current_working_copy` are copied as they were at build "
                 "time. That was allowed because no dated record in the data is after the cutoff; they are not "
                 "anchored by any vintage.")
    if unanchored:
        L.append(f"- {len(unanchored)} folder(s) have no index row to anchor them (reported as `unanchored` by "
                 "verify.py): " + ", ".join(f"`{c['path']}`" for c in unanchored[:10]) + (" ..." if len(unanchored) > 10 else ""))
    if failed:
        L.append(f"- {len(failed)} integrity anchor(s) FAILED at build time (source data inconsistent): "
                 + ", ".join(f"`{c['path']}`" for c in failed[:10]))
    if mvp:
        L += ["", "## MVP dataset", "",
              f"`data/mvp/` is the frozen MVP dataset as shipped: dataset_sha256 `{mvp['dataset_sha256']}` "
              f"(`{str(mvp['dataset_sha256'])[:16]}`), as of {mvp['as_of']}, vintage `{mvp['vintage_id']}`, built "
              f"{mvp['built_utc']}, {mvp['files']} files in its manifest.json. The build checked it against its own "
              f"manifest: {mvp['verified_at_build']}. verify.py re-checks every file against that manifest (the original "
              "sha256 for a withheld or redacted file) and recomputes dataset_sha256."]
    if baseline:
        L += _baseline_readme(baseline)
    L += _licence_readme(labels)
    return "\n".join(L) + "\n"


def _baseline_record(d: Path, label: str, reg_path: Path) -> dict:
    """The hashed `licence_baseline` record of a labelled room (EQ-A-0125). Only "demo" exists: it is refused when
    the data folder's register is not in the state the DEMO profile applies to (no approved version, licence_gov
    status no_baseline), when the register in force is not data/licences.csv, or when the register is invalid. The
    register's own rows give every status line; nothing is decided here."""
    if label not in LICENCE_BASELINES:
        raise ValueError(f"licence_baseline {label!r} is not one of {LICENCE_BASELINES}")
    from ..ops import demo_baseline as DB
    from ..ops import licence_gov as G
    from .licences import load_register
    st = G.state(d)
    if st["status"] != "no_baseline":
        raise ValueError(f"DEMO label refused: the licence register's state is {st['status']!r} (the DEMO label only "
                         "applies while there is no approved baseline, licence_gov no_baseline)")
    own = d / "licences.csv"
    raw = own.read_bytes()
    if Path(reg_path).resolve() != own.resolve():
        raise ValueError(f"DEMO label refused: the register in force ({reg_path}) is not {own}")
    rows = load_register(own)
    count = lambda col: dict(sorted(Counter(r[col] for r in rows).items()))       # noqa: E731
    try:
        from .official.client_safe_route import D3_STRICT_SERIES, d3_row, d3_yes
        d3 = d3_row(rows)
        d3_state = (None if d3 is None else "yes" if d3_yes(rows)
                    else "no" if d3.get("match_series") == D3_STRICT_SERIES else "undecided")
    except Exception as e:                                       # noqa: BLE001 - recorded, never invented
        d3_state = f"unknown ({type(e).__name__})"
    try:                                         # QEDS has no row of its own: its values match the row its label hits
        from .licences import cell_licence
        from .official.qeds import QEDS_LABEL
        hit = cell_licence({"source": QEDS_LABEL, "series": "", "licence": ""}, register=rows)
        qeds = hit["source_id"] if hit else "no register row matches"
    except Exception as e:                                       # noqa: BLE001
        qeds = f"unknown ({type(e).__name__})"
    by_id = {r["source_id"]: r for r in rows}
    pi11 = [{"source_id": s, **({k: by_id[s][k] for k in ("client_output", "validator_nda")} if s in by_id
                                else {"client_output": "no row", "validator_nda": "no row"})} for s in PI11_SOURCES]
    keep = ("source_id", "name", "client_output", "validator_nda", "exc_id", "terms_verified", "internal_use",
            "commercial")
    return {"label": DEMO_LABEL, "profile": DB.PROFILE, "banner": G.DEMO_BANNER, "approver": DB.APPROVER,
            "ticket": "EQ-A-0125", "register": "data/licences.csv", "register_sha256": hashlib.sha256(raw).hexdigest(),
            "register_rows": len(rows), "register_state": st["status"], "approvals_chain_ok": bool(st["chain_ok"]),
            "counts": {"client_output": count("client_output"), "validator_nda": count("validator_nda")},
            "d3_imf_via_wdi": d3_state, "pi11_sources": pi11, "qeds_register_row": qeds,
            "rows": [{k: r.get(k, "") for k in keep} for r in rows],
            "note": ("Sam has not approved a licence register baseline; the approval is parked (docs/runbooks/"
                     "A-sam-ready.md). A DEMO label is never Sam's approval and never clears a client path.")}


def _baseline_readme(b: dict) -> list[str]:
    """README sections of a labelled room (EQ-A-0125): the two room sections, then the register row by row."""
    rows = b["rows"]
    imf = [r for r in rows if r["source_id"].startswith("imf_")]
    withheld = [r for r in rows if r["validator_nda"] != "allowed"]
    L = ["", "## Room sections", "",
         "- **Internal section, under NDA:** " + ", ".join(f"`{p}`" for p in INTERNAL_SECTION) + ". Every value from a "
         "source whose register row says client output restricted or barred (IMF included) is here and only here, for "
         "validating this model only; do not reuse, republish or pass it on.",
         "- **Outer files:** " + ", ".join(f"`{p}`" for p in OUTER_FILES) + ". Paths, sizes, hashes, counts and "
         "register text only, no data values: MANIFEST.json is what the evidence bundle carries, and its "
         "`manifest_sha256` is what is sent separately.",
         "", f"## Licence baseline ({b['label']})", "",
         f"{b['banner']}. Register `{b['register']}` (in this room), sha256 `{b['register_sha256']}`, "
         f"{b['register_rows']} rows; governance state `{b['register_state']}` (no approved version), approvals chain "
         f"{'ok' if b['approvals_chain_ok'] else 'NOT ok'}. Client output: "
         + ", ".join(f"{k} {v}" for k, v in b["counts"]["client_output"].items()) + ". Validator room: "
         + ", ".join(f"{k} {v}" for k, v in b["counts"]["validator_nda"].items())
         + " (a row not `allowed` keeps its files out of this room).", "",
         "- IMF: " + "; ".join(f"`{r['source_id']}` client output {r['client_output']}, validator {r['validator_nda']}"
                               f"{', ' + r['exc_id'] if r['exc_id'] else ''}, internal use {r['internal_use'] or '?'}, "
                               f"commercial {r['commercial'] or '?'}" for r in imf)
         + ". IMF material is internal research use only and is in this room under NDA only (owner decision, "
           "EQ-A-0059).",
         f"- `imf_via_wdi` (D3, IMF-compiled series republished in WDI): {b['d3_imf_via_wdi']}.",
         "- PI-11 sources: " + "; ".join(f"`{r['source_id']}` client output {r['client_output']}, validator "
                                         f"{r['validator_nda']}" for r in b["pi11_sources"])
         + f"; QEDS (no row of its own) is matched by `{b['qeds_register_row']}` through its source label.",
         f"- {len(withheld)} register row(s) keep their files out of this room (validator not `allowed`): "
         + ", ".join(f"`{r['source_id']}` ({r['validator_nda']})" for r in withheld) + ".",
         "", "| source_id | client output | validator room | EXC | terms verified |", "|---|---|---|---|---|"]
    L += [f"| `{r['source_id']}` | {r['client_output']} | {r['validator_nda']} | {r['exc_id'] or ''} | "
          f"{r['terms_verified']} |" for r in rows]
    return L


# ------------------------------------------------------------------------------------------------ licence labels
LABEL_MAX_ROWS = 200_000          # rows scanned per CSV for source / licence values (the room's CSVs are far smaller)


def _file_sources(rel: str, body: bytes, src: Path | None = None) -> tuple[set, dict]:
    """(register source_ids found in one exported file, {column: source_id} for client-restricted columns) from Team
    A's licence register (EQ-A-0091, HO-20261025-C-A-001 item 3): the file's path row (licences.file_licence), plus
    for a CSV each distinct licence-column value and each distinct (source, series, licence) record of a provenance-
    like file (licences.cell_licence), plus the column tags of a CSV with a provenance sidecar (column_licences, read
    next to `src`, the file in the data dir). `rel` is relative to the data dir."""
    from .licences import cell_licence, column_licences, file_licence, licence_for
    found: set = set()
    cols: dict = {}
    row = file_licence(rel)
    if row is not None:
        found.add(row["source_id"])
    name = rel.rsplit("/", 1)[-1]
    if not name.lower().endswith(".csv"):
        return found, cols
    dec = decode_text(body)
    if dec is None:
        return found, cols
    reader = csv.reader(io.StringIO(dec[0], newline=""))
    header = [h.strip() for h in (next(reader, None) or [])]
    low = [h.lower() for h in header]
    lic_i = [i for i, h in enumerate(low) if h in LICENCE_COLUMNS]
    # a `source` column labels values only when the file has a value column (provenance, audit trail, quotes); in
    # metadata tables (cb_series_verified, freshness_sla, series maps) it names a source no value is exported from
    src_i = low.index("source") if "source" in low and set(low) & set(RESTRICTED_VALUE_COLUMNS) else None
    ser_i = low.index("series") if "series" in low else None
    if lic_i or src_i is not None:
        seen: set = set()
        for n, r in enumerate(reader):
            if n >= LABEL_MAX_ROWS:
                break
            get = (lambda i, r=r: r[i].strip() if i is not None and i < len(r) else "")
            lic = next((get(i) for i in lic_i if get(i)), "")
            key = (get(src_i), get(ser_i), lic)
            if key in seen or not any(key):
                continue
            seen.add(key)
            hit = cell_licence({"source": key[0], "series": key[1], "licence": key[2]}) if key[0] or key[1] \
                else licence_for(licence=key[2])
            if hit is not None:
                found.add(hit["source_id"])
    if src is not None:
        if src.is_file() and not src.is_symlink():
            for c, crow in column_licences(src).items():
                if crow is not None:
                    found.add(crow["source_id"])
                    if crow["client_output"] != "allowed":
                        cols[c] = crow["source_id"]
    return found, cols


def licence_labels(entries: list[dict], d: Path | None = None) -> dict:
    """Licence labels for the room (EQ-A-0091): {"sources": [{source_id, name, client_output, exc_id, attribution}]
    for every register source present in an exported file, "client_restricted_files": [{path, sources, columns}] for
    every exported file holding content whose register row says client_output restricted or barred}. Read from Team A's
    register directly (econquest.ingestion.licences), never from presentation."""
    from .licences import safe_register
    reg = {r["source_id"]: r for r in safe_register()}
    present: set = set()
    files = []
    for e in entries:
        rel = e["path"]
        if not rel.startswith("data/"):
            continue
        found, cols = _file_sources(rel[5:], e["body"], d / rel[5:] if d is not None else None)
        present |= found
        restricted = sorted(s for s in found if reg.get(s, {}).get("client_output", "allowed") != "allowed")
        if restricted or cols:
            files.append({"path": rel, "sources": restricted, "columns": dict(sorted(cols.items()))})
    sources = []
    for sid in sorted(present, key=lambda x: list(reg).index(x) if x in reg else 10 ** 6):
        r = reg.get(sid)
        if r is None:
            continue
        sources.append({"source_id": sid, "name": r["name"], "client_output": r["client_output"],
                        "exc_id": r["exc_id"], "attribution": r["attribution_text"]})
    return {"register": "data/licences.csv (EQ-A-0076)", "sources": sources, "client_restricted_files": files}


def _md(text: str) -> str:
    """Register text for a Markdown table cell or list line: pipes escaped, line breaks flattened."""
    return " ".join(str(text).split()).replace("|", "\\|")


def _licence_readme(lab: dict | None) -> list[str]:
    if not lab:
        return []
    L = ["", "## Licences and attribution", "",
         f"From Team A's licence register ({lab['register']}), one line per source present in this room. A source "
         "marked restricted or barred is internal research data: it is here for validating this model only, under "
         "NDA; do not reuse, republish or pass it on.", ""]
    for s in lab["sources"]:
        att = s["attribution"] or "no attribution text recorded in the register"
        exc = f", {s['exc_id']}" if s["exc_id"] else ""
        L.append(f"- `{s['source_id']}` ({_md(s['name'])}; client output {s['client_output']}{exc}): {_md(att)}")
    files = lab["client_restricted_files"]
    L += ["", "## Files holding client-restricted content", ""]
    if not files:
        L.append("None: no exported file holds content whose register row restricts client output.")
        return L
    L += [f"{len(files)} exported file(s) hold content whose register row says client output restricted or barred "
          "(also under `licence_labels` in MANIFEST.json):", "", "| file | restricted sources | restricted columns |",
          "|---|---|---|"]
    for f in files:
        cols = ", ".join(f"{c} ({sid})" for c, sid in f["columns"].items()) or "whole file / rows"
        L.append(f"| `{f['path']}` | {', '.join(f['sources'])} | {_md(cols)} |")
    return L


# ------------------------------------------------------------------------------------------------ build / verify

def _limitations_entry(d: Path, as_of) -> tuple[dict | None, dict]:
    """(room entry for limitations/data-limitations.md or None, the manifest's `limitations` record)."""
    from .limitations import build_register
    try:
        with tempfile.TemporaryDirectory() as td:
            p = Path(td) / "data-limitations.md"
            stats = build_register(d, p, as_of=as_of)
            body = p.read_bytes()
    except (ValueError, FileNotFoundError, KeyError) as e:   # pandas parse errors are ValueErrors
        reason = str(e).replace(str(d.resolve()), "<data>").replace(str(d), "<data>")
        return None, {"generated": False, "reason": f"{type(e).__name__}: {reason}"}
    return ({"path": LIMITATIONS_PATH, "source": "econquest/ingestion/limitations.py", "kind": "limitations", "body": body},
            {"generated": True, "path": LIMITATIONS_PATH, "live_source": stats["live_source"],
             "narrative": "header, column notes and cross-cutting table hand-written (EQ-A-0042); "
                          "the two Register tables computed for this as-of"})


def _mvp_record(d: Path) -> dict:
    """The hashed `mvp` record of a room holding data/mvp (EQ-A-0125): its manifest's identity and what
    mvp_dataset.verify (load=False: files, labels, gate report, restricted cells) said about the source."""
    m = json.loads((d / MVP_ROOT / "manifest.json").read_text(encoding="utf-8"))
    try:
        from .mvp_dataset import verify as mvp_verify
        mvp_verify(d / MVP_ROOT, load=False)
        ver = "ok"
    except Exception as e:                                       # noqa: BLE001 - recorded; verify.py fails the anchor
        ver = f"failed: {type(e).__name__}: {str(e)[:200]}"
    return {"path": f"data/{MVP_ROOT}", "schema": m.get("schema"), "dataset_sha256": m.get("dataset_sha256"),
            "as_of": m.get("as_of"), "vintage_id": m.get("vintage_id"), "built_utc": m.get("built_utc"),
            "files": len(m.get("files") or {}), "verified_at_build": ver}


def build_data_room(data_dir, as_of, out_dir, *, include_current: bool = False, now: dt.datetime | None = None,
                    include_restricted: bool = False, limitations: bool = True, include_mvp: bool = False,
                    licence_baseline: str | None = None) -> dict:
    """See _build_data_room. EQ-A-0125: licence_baseline="demo" labels the room DEMO (the register's DEMO baseline,
    never Sam's approval), adds data/licences.csv and records the register under the hashed `licence_baseline`;
    the build then reads the data folder's own register (licences.use_register). include_mvp adds the frozen MVP
    dataset data/mvp (hashed `mvp` record, anchored by verify.py). Both default off: a default room is unchanged."""
    if licence_baseline is None:
        return _build_data_room(data_dir, as_of, out_dir, include_current=include_current, now=now,
                                include_restricted=include_restricted, limitations=limitations, include_mvp=include_mvp)
    if licence_baseline not in LICENCE_BASELINES:
        raise ValueError(f"licence_baseline {licence_baseline!r} is not one of {LICENCE_BASELINES}")
    from .licences import use_register
    d = Path(data_dir)
    if not (d / "licences.csv").is_file() or (d / "licences.csv").is_symlink():
        raise ValueError(f"DEMO label refused: {d / 'licences.csv'} is not a regular file")
    with use_register(data_dir=d) as reg:
        return _build_data_room(data_dir, as_of, out_dir, include_current=include_current, now=now,
                                include_restricted=include_restricted, limitations=limitations,
                                include_mvp=include_mvp, baseline=_baseline_record(d, licence_baseline, reg))


def _build_data_room(data_dir, as_of, out_dir, *, include_current: bool = False, now: dt.datetime | None = None,
                     include_restricted: bool = False, limitations: bool = True, include_mvp: bool = False,
                     baseline: dict | None = None) -> dict:
    """Export the point-in-time data room for `as_of` from `data_dir` into `out_dir` (must not exist or be empty, and
    must not lie inside data_dir). Returns the manifest written to out_dir/MANIFEST.json. `now` fixes the build time
    (tests). Raises ValueError for a bad as_of, an out_dir inside data_dir, or include_current with a dated record
    after the cutoff; FileExistsError when out_dir is not empty; FileNotFoundError when data_dir is missing.
    include_restricted=True keeps licence-restricted files (raw_yahoo.csv, non-commercial/personal licence columns),
    which are withheld by default, and the Yahoo-derived values that are otherwise blanked (SEC-A-006 M2); limitations=False skips the generated data limitations register. E-mail addresses
    are always redacted in the copies (module docstring)."""
    d = Path(data_dir)
    if not d.is_dir():
        raise FileNotFoundError(f"data_dir {d} is not a folder")
    out = Path(out_dir)
    dr, outr = d.resolve(), out.resolve()
    if outr == dr or dr in outr.parents:
        raise ValueError(f"out_dir {out} must not be inside data_dir {d}")
    if out.exists() and (not out.is_dir() or any(out.iterdir())):
        raise FileExistsError(f"{out} is not empty")
    from .licences import require_register
    require_register()        # SEC-A-010 L3: a present but invalid licence register refuses the build (RegisterError)
    label, cut = cutoff_of(as_of)
    entries, excluded, filtered, seen, withheld = _plan(d, cut, include_current, include_restricted,
                                                        include_register=baseline is not None, include_mvp=include_mvp)
    mvp = _mvp_record(d) if any(e["kind"] == "mvp_dataset" for e in entries) else None
    if include_current:
        later = [t for t in seen if t > cut]
        if later:
            raise ValueError(f"include_current refused: the data holds records dated after the cutoff {_iso(cut)} "
                             f"(latest {_iso(max(later))}), so its working copies may already contain later data")
    ledger = [e for e in entries if e["kind"] == "review_ledger"]
    if ledger:
        entries.append({"path": DERIVED_FOUR_EYES, "source": "live/review_ledger.csv", "kind": "derived",
                        "body": _four_eyes(ledger[0]["body"])})
    entries.append({"path": "verify.py", "source": "econquest/ingestion/dataroom_verify.py", "kind": "verify_script",
                    "body": VERIFY_SOURCE.read_bytes()})
    lim = {"generated": False, "reason": "not requested (limitations=False)"}
    if limitations:
        e, lim = _limitations_entry(d, as_of)
        if e is not None:
            entries.append(e)
    # e-mail addresses redacted at source, before hashing (SEC-C-008 R6), after the Yahoo-derived values were blanked
    # (SEC-A-006 M2, in _plan); the original sha256 (before either change) is recorded
    redactions = []
    for e in entries:
        body, n = redact_emails(e["body"])
        if n or e.get("restricted"):
            orig = e.get("original", e["body"])
            r = {"path": e["path"], "replacements": n, "original_sha256": hashlib.sha256(orig).hexdigest(),
                 "original_size": len(orig)}
            if e.get("restricted"):
                r.update(restricted_rows=e["restricted"]["restricted_rows"],
                         restricted_cells=e["restricted"]["restricted_cells"],
                         restricted_rule=e["restricted"]["rule"],
                         reason="restricted source: Yahoo-derived (or non-commercial / personal licence) values blanked "
                                "(SEC-A-006 M2)")
            redactions.append(r)
            e["body"] = body
    redactions.sort(key=lambda r: r["path"])
    withheld.sort(key=lambda r: r["path"])
    altered = altered_map({"withheld": withheld, "redactions": redactions})
    altered_anchors = _altered_anchors(d, altered)
    if "data/approvals/log.jsonl" in altered:              # chain verified on the original (kept-rows) bytes
        from .dataroom_verify import chain_problem
        prob, n = chain_problem(filter_jsonl((d / "approvals" / "log.jsonl").read_bytes(), cut, [])[0].decode("utf-8"))
        altered_anchors["data/approvals/log.jsonl"] = {"verified_at_build": prob or "ok", "rows": n}
    code = _code_version()
    options = {"include_current": bool(include_current), "include_restricted": bool(include_restricted),
               "limitations": bool(limitations)}
    if include_mvp or baseline is not None:                # EQ-A-0125: only in the options of a room that uses them
        options.update(include_mvp=bool(include_mvp), licence_baseline=baseline["label"] if baseline else None)

    out.parent.mkdir(parents=True, exist_ok=True)
    tmp = Path(tempfile.mkdtemp(dir=out.parent, prefix=f".{out.name}.dataroom."))
    try:
        def write(e):
            p = tmp / e["path"]
            p.parent.mkdir(parents=True, exist_ok=True)
            p.write_bytes(e["body"])

        for e in entries:
            write(e)
        # integrity anchors on the room's own copies (same code as verify.py); recorded in the hashed manifest
        checks = _anchor_checks(tmp, altered, altered_anchors, mvp)

        def entry(e):
            r = {"path": e["path"], "size": len(e["body"]), "sha256": hashlib.sha256(e["body"]).hexdigest(),
                 "source": e["source"], "kind": e["kind"], "as_of_rule": RULES[e["kind"]]}
            if "filter" in e:
                r["filter"] = e["filter"]
            return r

        files = [entry(e) for e in entries]
        counts: dict = {}
        for f in files:
            c = counts.setdefault(f["kind"], {"files": 0, "bytes": 0})
            c["files"] += 1; c["bytes"] += f["size"]
        labels = licence_labels(entries, d)          # EQ-A-0091: attribution lines and client-restricted file labels
        readme = {"path": "README.md", "source": None, "kind": "readme",
                  "body": _readme(label, cut, files + [{"path": "README.md"}], counts, checks, options, code,
                                  withheld, redactions, lim, labels, baseline, mvp).encode("utf-8")}
        write(readme)
        files.append(entry(readme))
        c = counts.setdefault("readme", {"files": 0, "bytes": 0})
        c["files"] += 1; c["bytes"] += files[-1]["size"]
        files.sort(key=lambda f: f["path"])
        manifest = {"schema": SCHEMA, "as_of": label, "cutoff_utc": _iso(cut), "code": code, "options": options,
                    "rules": {k: RULES[k] for k in sorted({f["kind"] for f in files})},
                    "counts": dict(sorted(counts.items())),
                    "totals": {"files": len(files), "bytes": sum(f["size"] for f in files)},
                    "files": files, "checks": checks, "withheld": [{k: w[k] for k in ("path", "size", "sha256", "reason")}
                                                                   for w in withheld],
                    "redactions": redactions, "altered_anchors": altered_anchors, "limitations": lim,
                    "licence_labels": labels,
                    "content_sha256": content_hash(files)}
        if baseline is not None:                         # EQ-A-0125: inside manifest_sha256, so it cannot be stripped
            manifest["licence_baseline"] = baseline
        if mvp is not None:
            manifest["mvp"] = mvp
        manifest["manifest_sha256"] = manifest_hash(manifest)
        built = (now or dt.datetime.now(dt.timezone.utc))
        built = built.replace(tzinfo=dt.timezone.utc) if built.tzinfo is None else built.astimezone(dt.timezone.utc)
        manifest["build"] = {"built_utc": built.strftime("%Y-%m-%dT%H:%M:%SZ"), "source_data_dir": dr.name,     # basename only: the manifest ships in the evidence bundle
                             "python": platform.python_version(), "builder": "econquest.ingestion.dataroom",
                             "ticket": "EQ-A-0041", "excluded": excluded, "filtered": filtered,
                             "note": "build is outside manifest_sha256 and content_sha256"}
        (tmp / MANIFEST_NAME).write_text(json.dumps(manifest, indent=1, sort_keys=True) + "\n", encoding="utf-8")
        for p in tmp.rglob("*"):
            if p.is_file():
                os.chmod(p, 0o444)
        # B103: the room folder is 0o755 (owner rwx, others r-x), like the replay snapshots; every file is 0o444
        os.chmod(tmp, 0o755)  # nosec B103
        if out.exists():
            out.rmdir()                               # empty (checked above); fails if a racer filled it
        os.rename(tmp, out)
    except BaseException:
        shutil.rmtree(tmp, ignore_errors=True)
        raise
    return manifest


def home_dir() -> Path:
    """The folder holding data/ and outputs/, resolved as econquest/cli.py does: $ECONQUEST_HOME, else the checkout."""
    return Path(os.environ.get("ECONQUEST_HOME", Path(__file__).resolve().parent.parent.parent))


def default_room_dir(as_of, outputs_dir=None, licence_baseline: str | None = None) -> Path:
    """Where `dataroom build` writes by default and where `econquest evidence --as-of` (EQ-C-0060) looks:
    <outputs>/dataroom/<as_of>, <outputs> being outputs_dir or <home>/outputs. A date-time as_of drops its colons.
    A DEMO-labelled room (EQ-A-0125) goes to <as_of>-DEMO, so it is never taken for the plain room of that date."""
    label = cutoff_of(as_of)[0].replace(":", "")
    if licence_baseline is not None:
        label += f"-{DEMO_LABEL}"
    return Path(outputs_dir if outputs_dir is not None else home_dir() / "outputs") / "dataroom" / label


def verify_data_room(path, expect_manifest_sha256: str | None = None) -> dict:
    """Recompute every file hash, the size, manifest_sha256 and content_sha256, list missing / extra / changed files
    and re-run the integrity anchors (dataroom_verify.verify_room, the code the room's verify.py runs). `ok` is True
    only when nothing is missing, extra or changed, both hashes match and no anchor failed, and (when given) the
    recomputed manifest_sha256 equals expect_manifest_sha256 (SEC-A-014 P3-L1)."""
    return verify_room(path, expect_manifest_sha256)


def main(argv=None) -> int:
    from .dataroom_verify import format_report
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.dataroom",
                                 description="Validator data room (EQ-A-0041): point-in-time export and verification")
    sub = ap.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("build", help="export the data room for one as-of date")
    b.add_argument("--data", default=None, help="econquest data folder (default: <ECONQUEST_HOME or checkout>/data)")
    b.add_argument("--as-of", required=True, help="YYYY-MM-DD (end of that UTC day) or an ISO date-time")
    b.add_argument("--out", default=None, help="room folder (must not exist or be empty; not inside --data; "
                                                "default <outputs>/dataroom/<as_of>)")
    b.add_argument("--outputs", default=None, help="outputs folder for the default --out (default <home>/outputs)")
    b.add_argument("--include-current", action="store_true",
                   help="also copy undated working copies (refused when any record is dated after the cutoff)")
    b.add_argument("--include-restricted", action="store_true",
                   help="keep licence-restricted files (raw_yahoo.csv, non-commercial/personal licence columns) and "
                        "Yahoo-derived values (blanked by default); only when Sam confirms the licence allows passing "
                        "them on")
    b.add_argument("--no-limitations", action="store_true", help="do not generate limitations/data-limitations.md")
    b.add_argument("--demo-baseline", action="store_true",
                   help="EQ-A-0125: label the room DEMO (the licence register's DEMO baseline, never Sam's approval; "
                        "refused once a real baseline exists), add data/licences.csv; default out <as_of>-DEMO")
    b.add_argument("--mvp", action="store_true",
                   help="EQ-A-0125: add the frozen MVP dataset data/mvp (when built at or before the cutoff)")
    b.add_argument("--json", action="store_true", help="print the manifest summary as JSON")
    v = sub.add_parser("verify", help="verify a data room (same checks as its verify.py)")
    v.add_argument("room"); v.add_argument("--json", action="store_true")
    v.add_argument("--expect-manifest-sha256", default=None,
                   help="the manifest_sha256 received separately; the room fails unless it matches (SEC-A-014 P3-L1)")
    a = ap.parse_args(argv)
    if a.cmd == "build":
        try:
            a.data = a.data or str(home_dir() / "data")
            base = "demo" if a.demo_baseline else None
            a.out = a.out or str(default_room_dir(a.as_of, a.outputs, base))
            m = build_data_room(a.data, a.as_of, a.out, include_current=a.include_current,
                                include_restricted=a.include_restricted, limitations=not a.no_limitations,
                                include_mvp=a.mvp, licence_baseline=base)
        except (ValueError, FileExistsError, FileNotFoundError) as e:
            print(f"dataroom build: {e}", file=sys.stderr)
            return 2
        summary = {"out": str(a.out), "as_of": m["as_of"], "cutoff_utc": m["cutoff_utc"], "files": m["totals"]["files"],
                   "bytes": m["totals"]["bytes"], "manifest_sha256": m["manifest_sha256"],
                   "content_sha256": m["content_sha256"], "counts": m["counts"], "excluded": len(m["build"]["excluded"]),
                   "withheld": len(m["withheld"]), "redacted_files": len(m["redactions"]),
                   "limitations": m["limitations"]["generated"],
                   "anchors_failed": sum(c["status"] == "failed" for c in m["checks"]),
                   "anchors_unanchored": sum(c["status"] == "unanchored" for c in m["checks"]),
                   "licence_baseline": (m.get("licence_baseline") or {}).get("label"),
                   "mvp_dataset_sha256": (m.get("mvp") or {}).get("dataset_sha256")}
        if a.json:
            print(json.dumps(summary, indent=1, sort_keys=True))
        else:
            print(f"data room {a.out}: as of {m['as_of']} (cutoff {m['cutoff_utc']}), {summary['files']} files, "
                  f"{summary['bytes']} bytes, {summary['excluded']} source files excluded\n"
                  f"manifest_sha256 {m['manifest_sha256']}\n"
                  + (f"licence baseline: {m['licence_baseline']['banner']}\n" if m.get("licence_baseline") else "")
                  + (f"mvp dataset_sha256 {m['mvp']['dataset_sha256']}\n" if m.get("mvp") else "")
                  + "\n".join(f"  {k}: {c['files']} files, {c['bytes']} bytes" for k, c in m["counts"].items()))
        return 0
    rep = verify_data_room(a.room, a.expect_manifest_sha256)
    print(json.dumps(rep, indent=1, sort_keys=True) if a.json else format_report(rep))
    return 0 if rep["ok"] else 1


if __name__ == "__main__":
    sys.exit(main())
