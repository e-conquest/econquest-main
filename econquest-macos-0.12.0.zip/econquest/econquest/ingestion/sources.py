"""Source adapters. Each `fetch()` returns a pandas DataFrame with a documented schema.

Live adapters (Polymarket, Kalshi, Google Sheets) are implemented against the public endpoints
but fall back to the snapshot when the network is unavailable, so a run never silently mixes
stale and live data: every frame carries a `source` attribute saying where it came from."""
from __future__ import annotations
import json
import re
import urllib.error
import urllib.parse
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Optional
import pandas as pd


class Source:
    name = "source"

    def fetch(self) -> pd.DataFrame:  # pragma: no cover - interface
        raise NotImplementedError


# pandas' default missing-value markers without "NA": "NA" is Namibia's ISO 3166 alpha-2 code and must survive any
# read of countries / universe tables (EQ-A-0027). Blank cells and the other markers still read as NaN.
NA_VALUES = ["", "#N/A", "#N/A N/A", "#NA", "-1.#IND", "-1.#QNAN", "-NaN", "-nan", "1.#IND", "1.#QNAN", "<NA>", "N/A",
             "NULL", "NaN", "None", "n/a", "nan", "null"]


def read_csv_keep_na_code(path, **kwargs) -> pd.DataFrame:
    """pd.read_csv with keep_default_na=False and na_values=NA_VALUES, so the text 'NA' stays 'NA' (Namibia)."""
    kwargs.setdefault("keep_default_na", False)
    kwargs.setdefault("na_values", NA_VALUES)
    return pd.read_csv(path, **kwargs)


@dataclass
class CsvSource(Source):
    path: Path
    name: str = "csv"

    def fetch(self) -> pd.DataFrame:
        with open(self.path) as f:
            header = f.readline()
        df = read_csv_keep_na_code(self.path, dtype={"id": str, "pillar": str} if "id" in header else None)
        if "pillar" in df.columns:
            try:
                df["pillar"] = df["pillar"].astype(int)
            except (ValueError, TypeError):
                pass
        df.attrs["source"] = f"csv:{self.path.name}"
        return df


@dataclass
class JsonSource(Source):
    path: Path
    name: str = "json"

    def fetch(self) -> dict:
        return json.loads(Path(self.path).read_text())


# ------------------------------------------------------------------------------------------------ https without redirects
# SEC-A-006 L1: every live fetch in this package (BIS, ECB EXR, Polymarket, Kalshi, Google Sheets) goes through
# https_get: https only, redirects refused (urllib's default handler follows 301/302/303/307/308 to any host and to
# plain http), body read with a byte cap. HTTPError / URLError are raised as urllib raised them, so feeds' retry and
# fail-fast classification (feeds._is_transient, feeds._stop_reason, EQ-A-0037) sees the same exceptions as before.
JSON_MAX_BYTES = 10 * 1024 * 1024               # Polymarket / Kalshi / Sheets answers are a few kB


class RedirectRefused(urllib.error.HTTPError):
    """A 3xx answer: not followed (SEC-A-006 L1). An HTTPError with the 3xx code, so it is final (not retried), and
    its message names the host and path only (no query string)."""

    def __init__(self, url: str, code: int, msg, hdrs, fp):
        parts = urllib.parse.urlsplit(url)
        super().__init__(url, code, f"HTTP {code} redirect from {parts.hostname}{parts.path}; not followed", hdrs, fp)

    def __str__(self) -> str:
        return self.msg


class ResponseTooLarge(ValueError):
    """The body is larger than the caller's cap (SEC-A-006 L1). Final: not retried."""


class _RefuseRedirect(urllib.request.HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        raise RedirectRefused(req.full_url, code, msg, headers, fp)


def open_url_no_redirect(req: urllib.request.Request, timeout: float):
    """Open `req` with an opener that refuses redirects (raises RedirectRefused). The one place a live request is
    opened, so tests replace this function instead of urllib.request.urlopen."""
    # B310: callers pass https URLs only (https_get checks the scheme before calling)
    return urllib.request.build_opener(_RefuseRedirect).open(req, timeout=timeout)  # nosec B310


def https_get(url: str, headers: dict | None = None, *, timeout: float, max_bytes: int,
              unredirected: dict | None = None) -> bytes:
    """GET `url` (https only, else ValueError), redirects refused (RedirectRefused, an HTTPError), body capped at
    `max_bytes` (ResponseTooLarge). `unredirected` headers (credentials) are never copied anywhere."""
    parts = urllib.parse.urlsplit(url)
    if parts.scheme != "https" or not parts.hostname:
        raise ValueError(f"refusing non-https URL: {parts.scheme}://{parts.hostname}{parts.path}")
    req = urllib.request.Request(url, headers=headers or {})
    for k, v in (unredirected or {}).items():
        req.add_unredirected_header(k, v)
    with open_url_no_redirect(req, timeout) as r:
        body = r.read(max_bytes + 1)
    if len(body) > max_bytes:
        raise ResponseTooLarge(f"response from {parts.hostname}{parts.path} exceeds the {max_bytes}-byte cap")
    return body


def _http_json(url: str, timeout: float = 10.0, max_bytes: int = JSON_MAX_BYTES) -> Optional[dict | list]:
    if urllib.parse.urlsplit(url).scheme != "https":
        return None
    try:
        # bases are the Polymarket/Kalshi https constants (SEC-C-002); no redirect, capped body (SEC-A-006 L1)
        return json.loads(https_get(url, {"User-Agent": "econquest/0.1"}, timeout=timeout, max_bytes=max_bytes).decode())
    except Exception:
        return None


@dataclass
class PolymarketSource(Source):
    """Polymarket Gamma API (public, no key). Maps `slug` or `condition_id` to a Yes price and
    open interest. Falls back to `snapshot` rows for the contract when offline."""
    snapshot: pd.DataFrame
    name: str = "polymarket"
    base: str = "https://gamma-api.polymarket.com/markets"

    def fetch(self) -> pd.DataFrame:
        df = self.snapshot.copy()
        live = 0
        for i, row in df.iterrows():
            slug = row.get("slug")
            if not isinstance(slug, str) or not slug:
                continue
            data = _http_json(f"{self.base}?slug={urllib.parse.quote(str(slug), safe='')}")
            if data:
                m = data[0] if isinstance(data, list) else data
                try:
                    prices = json.loads(m.get("outcomePrices", "[]"))
                    df.at[i, "yes_price"] = float(prices[0])
                    df.at[i, "open_interest_k"] = float(m.get("liquidity", 0)) / 1000.0
                    live += 1
                except Exception:
                    pass
        df.attrs["source"] = f"polymarket:live={live}/{len(df)}"
        return df


@dataclass
class KalshiSource(Source):
    """Kalshi Trade API v2 (public market data). Uses `ticker` when present."""
    snapshot: pd.DataFrame
    name: str = "kalshi"
    base: str = "https://api.elections.kalshi.com/trade-api/v2/markets"

    def fetch(self) -> pd.DataFrame:
        df = self.snapshot.copy()
        live = 0
        for i, row in df.iterrows():
            ticker = row.get("ticker")
            if not isinstance(ticker, str) or not ticker:
                continue
            data = _http_json(f"{self.base}/{urllib.parse.quote(str(ticker), safe='')}")
            if data and "market" in data:
                m = data["market"]
                try:
                    df.at[i, "yes_price"] = float(m.get("last_price", 0)) / 100.0
                    df.at[i, "open_interest_k"] = float(m.get("open_interest", 0)) / 1000.0
                    live += 1
                except Exception:
                    pass
        df.attrs["source"] = f"kalshi:live={live}/{len(df)}"
        return df


@dataclass
class GoogleSheetsSource(Source):
    """Reads a tab of the Geopolitical-Macro Risk Desk workbook through the Sheets v4 REST API.
    Needs an OAuth bearer token or API key in `token`; without one it raises so the caller can
    fall back to the CSV snapshot exported from the same tab."""
    spreadsheet_id: str
    range_a1: str
    token: Optional[str] = None
    name: str = "google_sheets"

    def fetch(self) -> pd.DataFrame:
        if not self.token:
            raise RuntimeError("GoogleSheetsSource needs a token; use the CSV snapshot instead")
        if not re.fullmatch(r"[A-Za-z0-9_-]{1,128}", str(self.spreadsheet_id)):
            raise ValueError("spreadsheet id must be letters, digits, '-' or '_'")
        url = f"https://sheets.googleapis.com/v4/spreadsheets/{self.spreadsheet_id}/values/{urllib.parse.quote(self.range_a1, safe='')}"
        # fixed https://sheets.googleapis.com URL, id validated above (SEC-C-002); the token is an unredirected header
        # and redirects are refused, with a capped body (SEC-A-006 L1)
        body = https_get(url, timeout=20, max_bytes=JSON_MAX_BYTES,
                         unredirected={"Authorization": f"Bearer {self.token}"})
        values = json.loads(body.decode()).get("values", [])
        df = pd.DataFrame(values[1:], columns=values[0])
        df.attrs["source"] = f"sheets:{self.range_a1}"
        return df
