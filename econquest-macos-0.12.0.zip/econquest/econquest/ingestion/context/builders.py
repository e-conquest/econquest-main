"""Assistant context builders (EQ-A-0143, PI-15): read-only, citable chunks of what the desk already knows.

    from econquest.ingestion.context import build_context, Chunk
    chunks = build_context("data", kinds=None, country=None, as_of=None, scope="internal", limit=None)

Contract: docs/runbooks/A-PI15-agent-brief.md, "Shared contract: the context chunk". The assistant (Team C, EQ-C-0170
/ 0172) and the tool contracts (Team B, EQ-B-0145) read these chunks; they never compute a risk number from them.

Kinds and where each one reads (paths relative to the data folder, or to the outputs folder for run outputs and the
research archive; outputs defaults to <data_dir>/../outputs):

    run_output  outputs/store/econquest.sqlite (the run store, econquest.persistence.store schema) picks the latest
                "base" run recorded by as_of; its archive outputs/store/archive/<run_id>.json gives the portfolio
                summary (EL, VaR, ES, LVaR), per-country drivers, attribution and signals. Stress: the latest
                "stress-<KEY>" run per scenario recorded by as_of, named from data/scenarios.json.
    archive     Team C's research archive (EQ-C-0154, econquest.presentation.archive): outputs/archive/, the latest
                version of each item archived by as_of.
    audit       data/audit_trail.csv, one chunk per (table, country), split at line boundaries.
    calendar    data/calendar/events.csv through the calendar query API (calendar.query.events, point in time).
    ledger      data/live/review_ledger.csv (ledger.read_ledger), the decision history of each cell.
    corpus      data/corpus/ (EQ-A-0131) through text.corpus.documents(basis="knowledge").
    events      data/live/events/<source>/vintages (EQ-A-0139) through events.unified.unified_events
                (monthly, primary source per category), the newest EVENT_PERIODS months per country.
    dataset     data/mvp/provenance.csv + manifest.json (EQ-A-0110): every input cell with its label and source.

Rules (all enforced here, tested in tests/test_context_builders.py):
  * read-only: nothing is written anywhere (the run store is opened with sqlite mode=ro); no network, no model call;
  * point in time: as_of (a date = end of that UTC day, or an ISO timestamp) drops anything recorded after it. Each
    source is cut at its own record time (run created_at, ledger ts_utc, calendar recorded_utc, corpus retrieval,
    event vintage saved_utc, archive ts_utc). A snapshot file with no per-row record time (audit trail, MVP dataset)
    is used only when the snapshot itself is no later than as_of (audit trail: the newest of its retrieval dates, the
    review-ledger decisions and the live/snapshots apply stamps; dataset:
    manifest built_utc); otherwise that kind returns nothing rather than a later state. A final guard drops any chunk
    whose published_utc or retrieved_utc is after as_of;
  * deterministic: same inputs -> same chunks, same order (kinds in KINDS order, then each builder's order);
  * bounded: every chunk's text is capped at TEXT_CAP characters (before fencing); `limit` caps the count (taken
    round-robin across kinds so that one large kind cannot crowd out the others); MAX_CHUNKS caps it when limit is
    None;
  * licence: licence_ids are register source_ids (data/licences.csv of data_dir, licences.use_register) of every
    underlying cell, from licences.cell_licence / licence_for / file_licence. A cell no register row matches adds
    licences.UNMATCHED, so the chunk can never be client_ok (fail closed). scope comes from
    context.scope.chunk_scope (A-0144, AGENT-04) when it exists, else a stub that always says "internal";
  * trust: "econquest" for the desk's own outputs and records (run outputs, audit trail, ledger, dataset);
    "ingested" for third-party text and data (calendar, corpus, events) and for the research archive (SEC-A-017 H-3,
    AGENT-08: archived notes can quote outside text and our sentences cannot be told apart from quoted ones). Every ingested chunk's text goes through
    context.hygiene.fence (A-0145, AGENT-02) when it exists, else a stub fence; it is never raw.

published_utc / retrieved_utc: for third-party items, the publisher's time and our retrieval time. For the desk's own
records (runs, ledger rows, archive versions, the MVP build) published_utc is the time the record was written; blank
when unknown.
"""
from __future__ import annotations

import contextlib
import contextvars
import csv
import datetime as dt
import hashlib
import json
import logging
import re
import sqlite3
from dataclasses import dataclass
from pathlib import Path
from typing import Callable, Iterable
from urllib.parse import quote

from econquest.ingestion import licences as LIC

_LOG = logging.getLogger(__name__)

TICKET = "EQ-A-0143"
KINDS = ("run_output", "archive", "audit", "calendar", "ledger", "corpus", "events", "dataset")
TRUSTS = ("econquest", "ingested")
CHUNK_SCOPES = ("internal", "client_ok")
REQUEST_SCOPES = ("internal", "client")
TEXT_CAP = 4000                 # characters of chunk text before fencing
LINE_CAP = 600                  # characters of one record line inside a packed chunk
MAX_CHUNKS = 5000               # hard bound on one call when limit is None
EVENT_PERIODS = 12              # newest monthly periods per country for the events kind
MAX_FILE_BYTES = 20_000_000     # largest JSON / text file read (run archives are ~130 KB)
UNMATCHED = LIC.UNMATCHED       # "(no register row)": never a register id, so chunk_scope keeps the chunk internal
DATA_PREFIX, OUTPUTS_PREFIX = "data", "outputs"     # logical roots of source_id paths (stable across copies)

_DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
_CTRL_RE = re.compile("[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")
_LICENCE_COLUMNS = ("licence", "license", "licences", "licenses")   # as licences.cell_licence
_RUN_ID_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_.-]{0,159}$")


@dataclass(frozen=True)
class Chunk:
    """One citable piece of context (shared contract, A-PI15 brief)."""
    chunk_id: str                   # sha256(source_id + text)[:16]
    kind: str                       # one of KINDS
    source_id: str                  # path plus row / key / document id
    country: str                    # ISO3 or ""
    as_of: str                      # the date the fact is true for (YYYY-MM-DD)
    published_utc: str              # may be blank
    retrieved_utc: str              # may be blank
    text: str                       # plain; fenced when trust == "ingested"
    licence_ids: tuple              # register source_ids (UNMATCHED for a cell no row matches)
    scope: str                      # "internal" | "client_ok"
    trust: str                      # "econquest" | "ingested"
    provenance: str                 # one line, human-readable


# ------------------------------------------------------------------------------------------------ time
def _utc(d: dt.datetime) -> str:
    if d.tzinfo is None:
        d = d.replace(tzinfo=dt.timezone.utc)
    return d.astimezone(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def cutoff_stamp(as_of) -> str | None:
    """as_of (None, date, datetime, 'YYYY-MM-DD' or an ISO timestamp) -> UTC stamp; a date means the end of that day."""
    if as_of is None:
        return None
    if isinstance(as_of, dt.datetime):
        return _utc(as_of)
    if isinstance(as_of, dt.date):
        return f"{as_of.isoformat()}T23:59:59Z"
    s = str(as_of).strip()
    if _DATE_RE.match(s):
        return f"{s}T23:59:59Z"
    try:
        return _utc(dt.datetime.fromisoformat(s.replace("Z", "+00:00")))
    except ValueError:
        raise ValueError(f"as_of {as_of!r} is not a date (YYYY-MM-DD) or an ISO timestamp") from None


def norm_ts(v) -> str:
    """A recorded time as 'YYYY-MM-DDTHH:MM:SSZ', a bare date kept as 'YYYY-MM-DD', '' for blank; text that is
    neither is returned stripped (and counts as after any cutoff, see _after)."""
    s = "" if v is None else str(v).strip()
    if not s or s.lower() in ("nan", "none", "nat"):
        return ""
    if _DATE_RE.match(s):
        return s
    try:
        return _utc(dt.datetime.fromisoformat(s.replace("Z", "+00:00")))
    except ValueError:
        return s


def _after(ts: str, cut: str | None) -> bool:
    """True when a recorded time is after the cutoff. A bare date counts as the end of that day; unparseable text
    counts as after (fail closed)."""
    if not cut or not ts:
        return False
    if _DATE_RE.match(ts):
        return f"{ts}T23:59:59Z" > cut
    if not re.match(r"^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}Z$", ts):
        return True
    return ts > cut


def _date(ts: str) -> str:
    return ts[:10] if ts and _DATE_RE.match(ts[:10]) else ""


# ------------------------------------------------------------------------------------------------ text helpers
def _clean(v) -> str:
    s = "" if v is None else str(v)
    if s.lower() in ("nan", "none"):
        return ""
    return _CTRL_RE.sub(" ", s).strip()


def cap_text(text: str, cap: int = TEXT_CAP) -> str:
    """Text cut to `cap` characters with a visible marker (deterministic)."""
    if len(text) <= cap:
        return text
    mark = f"\n[truncated: {len(text)} characters in full]"
    return text[:max(0, cap - len(mark))].rstrip() + mark


def _n(v) -> str:
    """A stored number as text, unchanged in value (6 significant digits); 'n/a' for a missing one."""
    if v is None or v == "":
        return "n/a"
    if isinstance(v, bool):
        return "yes" if v else "no"
    if isinstance(v, int):
        return str(v)
    try:
        f = float(v)
    except (TypeError, ValueError):
        return _clean(v)
    if f != f:
        return "n/a"
    return format(f, ".6g")


def _pack(header: str, lines: list[str], cap: int = TEXT_CAP) -> list[list[int]]:
    """Indices of `lines` grouped so that header + group fits in `cap` (each line pre-capped at LINE_CAP)."""
    groups, cur, size = [], [], len(header)
    for i, line in enumerate(lines):
        n = min(len(line), LINE_CAP) + 1
        if cur and size + n > cap:
            groups.append(cur)
            cur, size = [], len(header)
        cur.append(i)
        size += n
    if cur:
        groups.append(cur)
    return groups


def _read_csv(path: Path) -> list[dict]:
    if not path.is_file() or path.is_symlink():
        return []
    with open(path, newline="", encoding="utf-8") as f:
        return [{k: (v or "") for k, v in r.items() if k is not None} for r in csv.DictReader(f)]


def _read_json(path: Path):
    if not path.is_file() or path.is_symlink() or path.stat().st_size > MAX_FILE_BYTES:
        return None
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError):
        return None


# ------------------------------------------------------------------------------------------------ licence / scope / fence
class _Licences:
    """Register lookups for one call (the register of data_dir, cached by record)."""

    def __init__(self):
        self.rows = LIC.safe_register()
        self.ids = {r["source_id"] for r in self.rows}
        self._cache: dict = {}

    def _get(self, key, fn) -> str | None:
        if key not in self._cache:
            row = fn()
            self._cache[key] = row["source_id"] if row else None
        return self._cache[key]

    def cell(self, source="", series="", licence="", transform="") -> frozenset:
        """Register ids of one cell record. Uses context.scope.cell_licence_ids (A-0144: also catches IMF / WEO codes,
        theratesapi and D3 series) when importable, else licences.cell_licence; UNMATCHED when no row matches."""
        k = ("cell", source, series, licence, transform)
        if k not in self._cache:
            ids = None
            fn = _scope_attr("cell_licence_ids")     # raises when scope.py is broken (S-1); None only under stub_hooks
            if fn is not None:
                try:
                    ids = frozenset(str(x) for x in fn(source=source, series=series, licence=licence,
                                                       transform=transform) if x)
                except Exception:                       # noqa: BLE001 - ARCH-A-PI15 S-2: a failing hook fails closed
                    ids = frozenset({UNMATCHED})        # (the plain register lookup misses IMF/WEO/D3/theratesapi)
            if not ids:
                row = LIC.cell_licence({"source": source, "series": series, "licence": licence}, register=self.rows)
                ids = frozenset({row["source_id"] if row else UNMATCHED})
            self._cache[k] = ids
        return self._cache[k]

    def path(self, rel: str) -> str | None:
        """Register id of a data-dir relative file path, None when no path row matches (adds nothing)."""
        return self._get(("path", rel), lambda: LIC.file_licence(rel, register=self.rows))

    def source(self, text: str) -> str:
        return self._get(("source", text), lambda: LIC.licence_for(source=text, register=self.rows)) or UNMATCHED

    def known(self, source_id: str) -> str:
        return source_id if source_id in self.ids else UNMATCHED


def _stub_scope(licence_ids) -> tuple[str, str]:
    return "internal", "scope stub (A-0144 context.scope.chunk_scope not available): internal only"


def _stub_fence(text: str, source_id: str) -> str:
    body = text.replace("<<", "< <").replace(">>", "> >")
    return f"<<ingested source={source_id}>>\n{body}\n<<end ingested>>"


# ARCH-A-PI15 S-1 (AGENT-08): scope.py (A-0144) and hygiene.py (A-0145) have landed, so they are imported directly and
# any failure (absent module, syntax or runtime error) RAISES: a bug can never silently swap in a stub, change the
# fence format and every ingested chunk_id, or loosen scope. The stubs are reachable only through the explicit test
# hook stub_hooks(). hooks_in_use() says which ones a call uses.
_STUB_HOOKS: contextvars.ContextVar = contextvars.ContextVar("econquest_context_stub_hooks", default=False)


@contextlib.contextmanager
def stub_hooks():
    """TEST HOOK ONLY: within the block, scope is the always-internal stub and fencing is the stub fence."""
    token = _STUB_HOOKS.set(True)
    try:
        yield
    finally:
        _STUB_HOOKS.reset(token)


def _scope_attr(name: str):
    if _STUB_HOOKS.get():
        return None
    from econquest.ingestion.context import scope as _scope
    return getattr(_scope, name)


def scope_function() -> Callable:
    """context.scope.chunk_scope (A-0144); the always-internal stub only inside stub_hooks()."""
    if _STUB_HOOKS.get():
        return _stub_scope
    from econquest.ingestion.context.scope import chunk_scope
    return chunk_scope


def fence_function() -> Callable:
    """context.hygiene.fence (A-0145); the stub fence only inside stub_hooks()."""
    if _STUB_HOOKS.get():
        return _stub_fence
    from econquest.ingestion.context.hygiene import fence
    return fence


def hooks_in_use() -> dict:
    """{"scope": "context.scope.chunk_scope" | "stub", "fence": "context.hygiene.fence" | "stub"}."""
    stub = _STUB_HOOKS.get()
    return {"scope": "stub" if stub else "context.scope.chunk_scope", "fence": "stub" if stub else "context.hygiene.fence"}


# ------------------------------------------------------------------------------------------------ call context
class _Ctx:
    def __init__(self, data_dir: Path, outputs_dir: Path, cut: str | None):
        self.data = data_dir
        self.out = outputs_dir
        self.cut = cut
        self.lic = _Licences()
        self.iso = self._iso_map()
        self._audit = None
        self._country_lic = None

    def _iso_map(self) -> dict:
        m = {}
        for r in _read_csv(self.data / "countries.csv"):
            name, iso = _clean(r.get("country")), _clean(r.get("iso")).upper()
            if name and iso:
                m[name.casefold()] = iso
        return m

    def iso_of(self, name) -> str:
        s = _clean(name)
        if not s:
            return ""
        if s.upper() in self.iso.values():
            return s.upper()
        return self.iso.get(s.casefold(), "")

    def audit_rows(self) -> list[dict]:
        if self._audit is None:
            self._audit = _read_csv(self.data / "audit_trail.csv")
        return self._audit

    def cell_licence(self, r: dict) -> frozenset:
        return self.lic.cell(_clean(r.get("source")), _clean(r.get("series")),
                             next((_clean(r.get(k)) for k in _LICENCE_COLUMNS if _clean(r.get(k))), ""),
                             _clean(r.get("transform")))

    def audit_index(self) -> dict:
        return {(_clean(r.get("table")), _clean(r.get("key")), _clean(r.get("country"))): r for r in self.audit_rows()}

    def country_licences(self) -> dict:
        """{country name: set of register ids of its audit-trail cells}; key '' holds the union."""
        if self._country_lic is None:
            out: dict = {"": set()}
            for r in self.audit_rows():
                ids = self.cell_licence(r)
                out.setdefault(_clean(r.get("country")), set()).update(ids)
                out[""].update(ids)
            self._country_lic = out
        return self._country_lic


def _draft(kind, source_id, country, as_of, text, licence_ids, trust, provenance, published="", retrieved="") -> dict:
    return {"kind": kind, "source_id": source_id, "country": country or "", "as_of": as_of or "",
            "published_utc": norm_ts(published), "retrieved_utc": norm_ts(retrieved), "text": text,
            "licence_ids": licence_ids, "trust": trust, "provenance": _clean(provenance)[:LINE_CAP]}


def _finish(d: dict, scope_fn: Callable, fence_fn: Callable) -> Chunk:
    text = cap_text(_CTRL_RE.sub(" ", d["text"]).strip())
    if d["trust"] == "ingested":
        text = fence_fn(text, d["source_id"])
    ids = tuple(sorted({str(x) for x in d["licence_ids"] if x}))
    scope = "internal"
    if ids:
        try:
            got = scope_fn(ids)
            scope = got[0] if isinstance(got, tuple) else got
        except Exception:                               # noqa: BLE001 - any failure fails closed
            scope = "internal"
        if scope not in CHUNK_SCOPES:
            scope = "internal"
    cid = hashlib.sha256((d["source_id"] + text).encode("utf-8")).hexdigest()[:16]
    return Chunk(chunk_id=cid, kind=d["kind"], source_id=d["source_id"], country=d["country"], as_of=d["as_of"],
                 published_utc=d["published_utc"], retrieved_utc=d["retrieved_utc"], text=text, licence_ids=ids,
                 scope=scope, trust=d["trust"], provenance=d["provenance"])


# ------------------------------------------------------------------------------------------------ run outputs
SUMMARY_METRICS = ("expected_loss_mm", "var95_mm", "var99_mm", "es95_mm", "es99_mm", "es975_frtb_mm", "lvar99_mm",
                   "les99_mm", "liquidity_cost99_mm", "es99_share_of_gross", "p_loss_above_10pct_gross",
                   "gross_notional_mm", "net_notional_mm", "es99_ci95_lo_mm", "es99_ci95_hi_mm", "var99_ci95_lo_mm",
                   "var99_ci95_hi_mm", "paths", "paths_requested")
DRIVER_FIELDS = ("rating", "spread_bps", "composite", "grade", "regime", "regime_rule", "p_crisis_12m", "pd_default",
                 "pd_market", "pd_rating", "pd_hazard_l1", "pd_model_l1", "pd_any", "pd_tc", "drv_tc", "pd_ex",
                 "drv_ex", "pd_pv", "drv_pv", "pd_sa", "drv_sa", "z_cds", "z_fx", "z_tsi", "z_event", "event_flag",
                 "pd_mult", "lgd_mult", "lgd_hard_expected", "el_default", "debt_gdp", "stfx_debt_reserves",
                 "reserves_months_imports", "primary_deficit_gap", "pitf_instability", "commodity_export_shock")
STRESS_METRICS = ("expected_loss_mm", "var99_mm", "es99_mm", "es975_frtb_mm", "lvar99_mm", "liquidity_cost99_mm")


def _runs(ctx: _Ctx) -> list[tuple[str, str, str]]:
    """(run_id, created stamp, label) of every run recorded by the cutoff, from the run store opened read-only."""
    db = ctx.out / "store" / "econquest.sqlite"
    if not db.is_file() or db.is_symlink():
        return []
    con = sqlite3.connect(f"file:{quote(str(db.resolve()))}?mode=ro", uri=True)
    try:
        rows = con.execute("SELECT run_id, created_at, label FROM runs").fetchall()
    except sqlite3.DatabaseError:
        rows = []
    finally:
        con.close()
    out = []
    for run_id, created, label in rows:
        ts = norm_ts(created)
        if run_id and _RUN_ID_RE.match(str(run_id)) and not _after(ts, ctx.cut):
            out.append((str(run_id), ts, str(label or "")))
    return sorted(out, key=lambda r: (r[1], r[0]))


def _load_run(ctx: _Ctx, run_id: str) -> tuple[dict | None, str]:
    rel = f"store/archive/{run_id}.json"
    d = _read_json(ctx.out / rel)
    if isinstance(d, dict) and (d.get("summary") or {}).get("run_id") == run_id:
        return d, f"{OUTPUTS_PREFIX}/{rel}"
    latest = _read_json(ctx.out / "run_latest.json")
    if isinstance(latest, dict) and (latest.get("summary") or {}).get("run_id") == run_id:
        return latest, f"{OUTPUTS_PREFIX}/run_latest.json"
    return None, ""


def _run_label(d: dict, src: str) -> str:
    s, v = d.get("summary") or {}, (d.get("provenance") or {}).get("versions") or {}
    return (f"econquest run {s.get('run_id')} (label {s.get('label')}, as_of {s.get('as_of')}, recorded "
            f"{norm_ts(s.get('created_at'))}; code {v.get('code_version', '?')} {v.get('code_hash', '?')}, data "
            f"{v.get('data_hash', '?')}) from the run store, {src}")


def build_run_output(ctx: _Ctx) -> list[dict]:
    runs = _runs(ctx)
    base = [r for r in runs if r[2] == "base"]
    if not base:
        return []
    run_id, created, _ = base[-1]
    d, src = _load_run(ctx, run_id)
    if d is None:
        return []
    s = d.get("summary") or {}
    as_of = _clean(s.get("as_of") or (d.get("settings") or {}).get("as_of"))
    prov = _run_label(d, src)
    clic = ctx.country_licences()
    derived = ctx.lic.source("econquest run outputs")
    # SEC-A-017 F3: no input ids from the audit trail means the inputs are unknown: fail closed
    all_lic = sorted(clic[""] | {derived} | (set() if clic[""] else {UNMATCHED}))
    out = []

    def add(key, country_iso, text, lic):
        out.append(_draft("run_output", f"{src}#{key}", country_iso, as_of, text, lic, "econquest", prov,
                          published=created))

    m = s.get("metrics") or {}
    lines = [f"Portfolio risk, run {run_id} (as of {as_of}). Computed by econquest; values as stored, units in names "
             f"(_mm = USD millions)."]
    lines += [f"{k}: {_n(m.get(k))}" for k in SUMMARY_METRICS if k in m]
    lines.append(f"global_regime: {_clean(s.get('global_regime'))}")
    lines.append("regimes: " + ", ".join(f"{k} {_n(v)}" for k, v in sorted((s.get("regimes") or {}).items())))
    lines.append("top_default_pd: " + ", ".join(f"{k} {_n(v)}" for k, v in (s.get("top_default_pd") or {}).items()))
    lines.append(f"arbitrage_flags: {_n(s.get('arbitrage_flags'))}")
    add("summary", "", "\n".join(lines), all_lic)

    by_country = {r.get("country"): r for r in d.get("by_country") or []}
    rows = sorted(by_country.values(), key=lambda r: (-(r.get("tail_contribution_99_mm") or 0), str(r.get("country"))))
    lines = [f"Attribution by country, run {run_id} (as of {as_of}): notional, expected loss and contribution to the "
             f"99% tail (USD millions), largest tail contribution first."]
    lines += [f"{_clean(r.get('country'))}: notional {_n(r.get('notional_mm'))}, expected_loss {_n(r.get('expected_loss_mm'))}"
              f", tail_contribution_99 {_n(r.get('tail_contribution_99_mm'))}" for r in rows]
    add("attribution", "", "\n".join(lines), all_lic)

    contrib: dict = {}
    for r in d.get("contributions") or []:
        contrib.setdefault(r.get("country"), []).append(r)
    signals = d.get("signals") or []
    names = {str(k): v for k, v in (d.get("signal_names") or {}).items()}
    trades = {r.get("id"): _clean(r.get("strategy")) for r in _read_csv(ctx.data / "playbook.csv")}
    dash = {r.get("country"): r for r in d.get("dashboard") or []}
    pillars = d.get("pillars") or {}
    for c in d.get("country") or []:
        name = _clean(c.get("country"))
        iso = _clean(c.get("iso")).upper() or ctx.iso_of(name)
        lic = sorted(clic.get(name, {UNMATCHED}) | {derived})
        lines = [f"{name} ({iso}) risk drivers, run {run_id} (as of {as_of}). Computed by econquest; values as stored."]
        lines += [f"{k}: {_n(c.get(k))}" for k in DRIVER_FIELDS if k in c]
        if name in pillars:
            lines.append("pillar scores: " + ", ".join(f"{k} {_n(v)}" for k, v in sorted(pillars[name].items())))
        add(f"country={name}", iso, "\n".join(lines), lic)

        lines = [f"{name} ({iso}) attribution, run {run_id} (as of {as_of}), USD millions."]
        b = by_country.get(name)
        if b:
            lines.append(f"country total: notional {_n(b.get('notional_mm'))}, expected_loss {_n(b.get('expected_loss_mm'))}"
                         f", tail_contribution_99 {_n(b.get('tail_contribution_99_mm'))}")
        for p in sorted(contrib.get(name, []), key=lambda p: str(p.get("id"))):
            lines.append(f"position {_clean(p.get('id'))} {_clean(p.get('asset_class'))}: notional {_n(p.get('notional_mm'))}"
                         f", expected_loss {_n(p.get('expected_loss_mm'))}, tail_contribution_99 "
                         f"{_n(p.get('tail_contribution_99_mm'))}, liquidity_cost_99 {_n(p.get('liquidity_cost_99_mm'))}"
                         f", share_of_es99 {_n(p.get('share_of_es99'))}")
        if len(lines) > 1:
            add(f"attribution/country={name}", iso, "\n".join(lines), lic)

        sig = [(int(r["key"]), r.get(name)) for r in signals if "key" in r and r.get(name) is not None]
        sig = sorted([x for x in sig if (x[1] or 0) > 0], key=lambda x: (-x[1], x[0]))[:10]
        fired = sorted((str(r.get("trade")), r.get(name)) for r in d.get("activation") or []
                       if r.get(name) is not None)
        lines = [f"{name} ({iso}) signals, run {run_id} (as of {as_of}): strongest signal strengths (0-100) and the "
                 f"playbook trades that fired."]
        lines += [f"signal {k} {names.get(str(k), '')}: {_n(v)}" for k, v in sig]
        lines += [f"trade {t} {trades.get(t, '')}: fired, strength {_n(v)}" for t, v in fired]
        db = dash.get(name) or {}
        for k in ("top_signals", "best_trade", "conviction", "gpr_signal", "gpr_read", "pm_read"):
            if db.get(k) not in (None, ""):
                lines.append(f"{k}: {_n(db.get(k)) if isinstance(db.get(k), (int, float)) else _clean(db.get(k))}")
        add(f"signals/country={name}", iso, "\n".join(lines), lic)

    scen = _read_json(ctx.data / "scenarios.json")
    scen = {str(x.get("key")): x for x in (scen.get("scenarios") or [])} if isinstance(scen, dict) else {}
    latest_stress: dict = {}
    for rid, ts, label in runs:
        if label.startswith("stress-"):
            latest_stress[label] = (rid, ts)
    for label in sorted(latest_stress):
        rid, ts = latest_stress[label]
        sd, ssrc = _load_run(ctx, rid)
        if sd is None:
            continue
        key = label[len("stress-"):]
        sc = scen.get(key, {})
        sm = (sd.get("summary") or {}).get("metrics") or {}
        ss = sd.get("summary") or {}
        lines = [f"Stress scenario {key}: {_clean(sc.get('name')) or 'not in data/scenarios.json'}"
                 f" ({_clean(sc.get('kind'))}; {_clean(sc.get('source'))}).",
                 f"description: {_clean(sc.get('description'))}",
                 f"stress run {rid} (as of {_clean(ss.get('as_of'))}, recorded {ts}); latest base run {run_id}."]
        lines += [f"{k}: stress {_n(sm.get(k))}, base {_n(m.get(k))}" for k in STRESS_METRICS if k in sm]
        lines.append("regimes under stress: " + ", ".join(f"{k} {_n(v)}" for k, v in sorted((ss.get("regimes") or {}).items())))
        out.append(_draft("run_output", f"{ssrc}#stress={key}", "", _clean(ss.get("as_of")) or as_of, "\n".join(lines),
                          all_lic, "econquest", _run_label(sd, ssrc), published=ts))
    return out


# ------------------------------------------------------------------------------------------------ research archive
def build_archive(ctx: _Ctx) -> list[dict]:
    from econquest.presentation import archive as A
    root = A.archive_root(ctx.out)
    if not (root / A.INDEX_NAME).is_file():
        return []
    out = []
    for item_id, it in sorted(A.items(ctx.out).items()):
        vers = [r for r in it["versions"] if not _after(norm_ts(r.get("ts_utc")), ctx.cut)]
        if not vers:
            continue
        r = vers[-1]
        try:
            v = int(r.get("version"))
        except (TypeError, ValueError):
            continue
        product = _clean(r.get("product"))
        if product not in A.PRODUCTS or not A.ID_RE.match(item_id) or not item_id.startswith(product + "-"):
            continue
        vdir = root / product / item_id / f"v{v}"
        bodies, attribution, client_safe = [], [], []
        for f in r.get("files") or []:
            name = str(f.get("name") or "")
            fp = vdir / name
            if (not A.NAME_RE.match(name) or Path(name).suffix.lower() not in A.TEXT_SUFFIXES or not fp.is_file()
                    or fp.is_symlink() or fp.stat().st_size > MAX_FILE_BYTES):
                continue
            p = A.read_product(name, fp.read_bytes())
            bodies.append(p["body"])
            attribution += p.get("attribution") or []
            client_safe.append(bool(p.get("client_safe")))
        if not bodies:
            continue
        corr = r.get("correction") or {}
        title = _clean(r.get("title") or it.get("title"))
        head = f"{A.PRODUCT_LABELS.get(product, product)}: {title} (period {_clean(r.get('period'))}, version {v})"
        if corr:
            head += f"\nCorrected: {_clean(corr.get('what'))} {_clean(corr.get('why'))}"
        # SEC-A-017 F4: every row an attribution line names, plus the audit / D3 rules (not only the strictest row)
        lic = set().union(*(ctx.lic.cell(_clean(a)) for a in attribution)) if attribution else set()
        if r.get("licence") != "client-safe" or not attribution or not all(client_safe):
            lic.add(UNMATCHED)
        country = ctx.iso_of(r.get("country"))
        prov = (f"research archive (EQ-C-0154) {product}/{item_id}/v{v}, archived {norm_ts(r.get('ts_utc'))}, "
                f"label {r.get('licence')}, run {r.get('run_id') or 'n/a'}")
        out.append(_draft("archive", f"{OUTPUTS_PREFIX}/{A.ARCHIVE_REL}/{product}/{item_id}/v{v}#id={item_id};version={v}", country,
                          _clean(r.get("period")), head + "\n" + "\n".join(bodies), sorted(lic),
                          "ingested", prov,                     # SEC-A-017 H-3: fenced, may quote outside text
                          published=r.get("ts_utc")))
    return out


# ------------------------------------------------------------------------------------------------ audit trail
def _key_range(keys: list[str]) -> str:
    return keys[0] if len(keys) == 1 or keys[0] == keys[-1] else f"{keys[0]}..{keys[-1]}"


_SNAPSHOT_DIR_RE = re.compile(r"^(\d{4}-\d{2}-\d{2})T(\d{2})(\d{2})(\d{2})Z")


def _audit_snapshot(ctx: _Ctx) -> str:
    """When data/audit_trail.csv may last have been rewritten: the newest of its retrieval times, the review ledger's
    decision times (an apply rewrites decision / author / approver / gate rows without moving `retrieved`) and the
    apply snapshots under live/snapshots/<YYYY-MM-DDTHHMMSSZ>-... (ARCH-A-PI15 P-1). A lower bound, never later than
    the truth."""
    stamps = [norm_ts(r.get("retrieved")) for r in ctx.audit_rows()]
    from econquest.ingestion import ledger
    led = ledger.read_ledger(ctx.data)
    stamps += [norm_ts(x) for x in led["ts_utc"]] if not led.empty else []
    snap = ctx.data / "live" / "snapshots"
    if snap.is_dir():
        for p in snap.iterdir():
            m = _SNAPSHOT_DIR_RE.match(p.name)
            if m and p.is_dir():
                stamps.append(f"{m.group(1)}T{m.group(2)}:{m.group(3)}:{m.group(4)}Z")
    return max((s for s in stamps if s), key=lambda s: s if "T" in s else f"{s}T23:59:59Z", default="")


def _row_time(r: dict, decided: dict) -> str:
    """A trail row's own time: the later of its retrieval and the latest ledger decision on its cell; '' if neither."""
    ts = [t for t in (norm_ts(r.get("retrieved")),
                      decided.get((_clean(r.get("table")), _clean(r.get("key")), _clean(r.get("country"))), "")) if t]
    return max(ts, key=lambda s: s if "T" in s else f"{s}T23:59:59Z", default="")


def build_audit(ctx: _Ctx) -> list[dict]:
    rows = ctx.audit_rows()
    if not rows:
        return []
    snapshot = _audit_snapshot(ctx)
    if ctx.cut and (not snapshot or _after(snapshot, ctx.cut)):
        return []                                       # a later state of the trail: not point-in-time for as_of
    from econquest.ingestion import ledger
    decided: dict = {}
    led = ledger.read_ledger(ctx.data)
    for r in ([] if led.empty else led.to_dict("records")):
        k = (_clean(r.get("table")), _clean(r.get("key")), _clean(r.get("country")))
        decided[k] = max(decided.get(k, ""), norm_ts(r.get("ts_utc")))
    file_lic = ctx.lic.path("audit_trail.csv")
    groups: dict = {}
    for r in rows:
        t = _row_time(r, decided)
        if ctx.cut and (not t or _after(t, ctx.cut)):
            continue                                    # P-1: no time of its own, or decided after as_of: fail closed
        groups.setdefault((_clean(r.get("table")), _clean(r.get("country"))), []).append((r, t))
    out = []
    for (table, country), pairs in groups.items():
        grp = [r for r, _ in pairs]
        iso = ctx.iso_of(country)
        lines = []
        for r in grp:
            g = lambda k, r=r: _clean(r.get(k))   # noqa: E731
            parts = [f"{g('key')} {g('indicator')}: value {g('value')}", f"origin {g('origin')}", f"source {g('source')}"]
            parts += [f"{k} {g(k)}" for k in ("series", "transform", "retrieved", "gate_status", "gate_reason",
                                               "decision", "seed_value", "live_value", "author", "approver",
                                               "self_approved", "attested") if g(k)]
            lines.append("; ".join(parts)[:LINE_CAP])
        header = f"Audit trail, table {table}, {country or 'all'} (snapshot of data/audit_trail.csv, last changed no earlier than {snapshot or 'n/a'})."
        for idx in _pack(header, lines):
            sub = [grp[i] for i in idx]
            keys = [_clean(r.get("key")) for r in sub]
            lic = set().union(*(ctx.cell_licence(r) for r in sub)) | {file_lic or UNMATCHED}   # SEC-A-017 F1
            ret = max((norm_ts(r.get("retrieved")) for r in sub if norm_ts(r.get("retrieved"))), default="")
            dec = max((decided.get((table, _clean(r.get("key")), country), "") for r in sub), default="")
            out.append(_draft("audit", f"{DATA_PREFIX}/audit_trail.csv#table={table};country={country};keys={_key_range(keys)}",
                              iso, _date(snapshot), header + "\n" + "\n".join(lines[i] for i in idx), sorted(lic),
                              "econquest", f"econquest audit trail data/audit_trail.csv, {len(sub)} cells, table {table}",
                              published=dec, retrieved=ret))
    return out


# ------------------------------------------------------------------------------------------------ event calendar
def build_calendar(ctx: _Ctx) -> list[dict]:
    from econquest.ingestion.calendar import query
    df = query.events(ctx.data, as_of=ctx.cut)
    if df is None or df.empty:
        return []
    file_lic = ctx.lic.path("calendar/events.csv")
    out = []
    for r in df.to_dict("records"):
        g = lambda k, r=r: _clean(r.get(k))   # noqa: E731
        when = g("date") if g("date") == g("date_end") or not g("date_end") else f"{g('date')} to {g('date_end')}"
        lines = [f"{g('title')}", f"kind {g('kind')}; country {g('iso3')}; when {when} (precision {g('precision')}); "
                 f"status {g('status')}; importance {g('importance')}"]
        if g("amount_usd"):
            lines.append(f"amount_usd {g('amount_usd')}")
        if g("note"):
            lines.append(f"note: {g('note')}")
        if g("source_url"):
            lines.append(f"source {g('source_id')} {g('source_url')}")
        lic = {ctx.lic.known(g("licence_id")) if g("licence_id") else UNMATCHED} | {file_lic or UNMATCHED}  # SEC-A-017 F1
        syn = " SYNTHETIC" if g("synthetic").lower() == "true" else ""
        prov = (f"event calendar data/calendar/events.csv{syn}: {g('origin')} row from {g('source_id')}, recorded "
                f"{g('recorded_utc')}, retrieved {g('retrieved_utc')}")
        out.append(_draft("calendar", f"{DATA_PREFIX}/calendar/events.csv#event_id={g('event_id')};revision={g('revision')}",
                          g("iso3").upper(), g("date"), "\n".join(lines), sorted(lic), "ingested", prov,
                          retrieved=g("retrieved_utc")))
    return out


# ------------------------------------------------------------------------------------------------ review ledger
def build_ledger(ctx: _Ctx) -> list[dict]:
    from econquest.ingestion import ledger
    df = ledger.read_ledger(ctx.data)
    if df.empty:
        return []
    file_lic = ctx.lic.path("live/review_ledger.csv")
    audit = ctx.audit_index()
    groups: dict = {}
    for r in df.to_dict("records"):
        if _after(norm_ts(r.get("ts_utc")), ctx.cut):
            continue
        groups.setdefault((_clean(r.get("table")), _clean(r.get("key")), _clean(r.get("country"))), []).append(r)
    out = []
    for (table, key, country), grp in groups.items():
        lines = []
        for r in grp:
            g = lambda k, r=r: _clean(r.get(k))   # noqa: E731
            parts = [f"{g('ts_utc')} decision {g('decision')} (gate {g('gate_status')}, live {g('live')}, vintage "
                     f"{g('vintage_id') or 'n/a'})", f"author {g('author')}"]
            parts += [f"{k} {g(k)}" for k in ("approver", "self_approved", "note") if g(k)]
            lines.append("; ".join(parts)[:LINE_CAP])
        header = (f"Review ledger decisions for {table} {key}, {country or 'n/a'} (oldest first). Internal desk record; "
                  f"author and approver names are self-asserted (unkeyed ledger, EXC-draft-A16-1).")
        a = audit.get((table, key, country))
        cell = ctx.cell_licence(a) if a else frozenset({UNMATCHED})
        for idx in _pack(header, lines):
            sub = [grp[i] for i in idx]
            last = norm_ts(sub[-1].get("ts_utc"))
            lic = set(cell) | {file_lic or UNMATCHED}       # SEC-A-017 F1: no register row for the ledger file
            sid = f"{DATA_PREFIX}/live/review_ledger.csv#table={table};key={key};country={country}"
            if len(idx) < len(grp):
                sid += f";rows={idx[0] + 1}..{idx[-1] + 1}"
            out.append(_draft("ledger", sid, ctx.iso_of(country), _date(last), header + "\n" + "\n".join(lines[i] for i in idx),
                              sorted(lic), "econquest", f"review ledger data/live/review_ledger.csv, {len(sub)} decisions",
                              published=last))
    return out


# ------------------------------------------------------------------------------------------------ text corpus
def build_corpus(ctx: _Ctx) -> list[dict]:
    from econquest.ingestion.text import corpus
    root = ctx.data / "corpus"
    if not corpus.available(root):
        return []
    store_lic = ctx.lic.known(corpus.STORE_LICENCE_ID)
    out = []
    for doc in corpus.documents(None, as_of=ctx.cut, basis="knowledge", root=root):
        text = f"{_clean(doc.title)}\n{doc.text or ''}"
        lic = sorted({ctx.lic.known(doc.licence_id), store_lic})
        syn = " SYNTHETIC" if doc.synthetic else ""
        prov = (f"text corpus{syn} (EQ-A-0131) {doc.source}, {doc.url}, published {doc.published_utc}, retrieved "
                f"{doc.retrieved_utc}, version {doc.version}, sha256 {doc.sha256[:16]}")
        for iso in (doc.iso3s or ("",)):
            sid = f"{DATA_PREFIX}/corpus#doc_id={doc.doc_id};version={doc.version}" + (f";iso={iso}" if iso else "")
            out.append(_draft("corpus", sid, iso, _date(norm_ts(doc.published_utc)), text, lic, "ingested", prov,
                              published=doc.published_utc, retrieved=doc.retrieved_utc))
    return out


# ------------------------------------------------------------------------------------------------ unified events
def build_events(ctx: _Ctx) -> list[dict]:
    from econquest.ingestion.events import unified
    df = unified.unified_events(ctx.data, as_of=ctx.cut, freq="M", combine="primary")
    if df.empty:
        return []
    out = []
    df = df.sort_values(["iso", "period", "category", "measure", "source"], kind="mergesort")
    for iso, g in df.groupby("iso", sort=True):
        periods = sorted(g["period"].unique())[-EVENT_PERIODS:]
        for period in periods:
            rows = g[g["period"] == period].to_dict("records")
            lines = [f"Event counts for {iso}, month starting {period} (stored vintages, primary source per category)."]
            lic, prov = set(), set()
            for r in rows:
                lines.append(f"{_clean(r['category'])} {_clean(r['measure'])}: {_n(r['value'])} (source {_clean(r['source'])}"
                             + (f", days covered {_n(r['days_covered'])}" if _clean(r.get("days_covered")) else "")
                             + f", vintage {_clean(r['vintage_id'])})")
                lic.add(ctx.lic.source(_clean(r["provenance"])))
                pl = ctx.lic.path(f"live/events/{_clean(r['source'])}/")
                if pl:
                    lic.add(pl)
                prov.add(_clean(r["provenance"]))
            avail = max(norm_ts(r.get("available_utc")) for r in rows)
            out.append(_draft("events", f"{DATA_PREFIX}/live/events#iso={iso};period={period};freq=M", _clean(iso).upper(),
                              _clean(period), "\n".join(lines), sorted(lic), "ingested",
                              "unified events (EQ-A-0139): " + " | ".join(sorted(prov)), retrieved=avail))
    return out


# ------------------------------------------------------------------------------------------------ MVP dataset cells
def build_dataset(ctx: _Ctx) -> list[dict]:
    mvp = ctx.data / "mvp"
    man = _read_json(mvp / "manifest.json")
    rows = _read_csv(mvp / "provenance.csv")
    if not isinstance(man, dict) or not rows:
        return []
    built = norm_ts(man.get("built_utc"))
    if ctx.cut and (not built or _after(built, ctx.cut)):
        return []                                       # built after as_of: not point-in-time
    as_of = _clean(man.get("as_of"))
    names = {}
    for r in _read_csv(mvp / "data" / "indicators.csv"):
        names[_clean(r.get("id"))] = f"{_clean(r.get('indicator'))} ({_clean(r.get('unit'))})"
    audit = {(_clean(r.get("key")), _clean(r.get("country"))): r for r in _read_csv(mvp / "data" / "audit_trail.csv")}
    sha = _clean(man.get("dataset_sha256"))[:16]
    groups: dict = {}
    for r in rows:
        groups.setdefault((_clean(r.get("table")), _clean(r.get("country"))), []).append(r)
    out = []
    for (table, country), rows_tc in groups.items():
        # one licence group per chunk (AGENT-08): cells with the same register ids together, so that one restricted
        # cell never makes its client-safe neighbours internal; groups in order of first appearance
        by_lic: dict = {}
        for r in rows_tc:
            a = audit.get((_clean(r.get("key")), _clean(r.get("country"))))
            ids = ctx.cell_licence(a) if a else ctx.lic.cell(_clean(r.get("source")))
            by_lic.setdefault(tuple(sorted(ids)), []).append(r)
        for ids, grp in by_lic.items():
            lines = []
            for r in grp:
                g = lambda k, r=r: _clean(r.get(k))   # noqa: E731
                label = names.get(g("key"), g("key")) if table == "indicators.csv" else g("key")
                extra = "; ".join(f"{k} {g(k)}" for k in ("vintage", "gate_status", "reason") if g(k))
                lines.append(f"{g('key')} {label} = {g('value')} [{g('label')}; source {g('source')}"
                             + (f"; {extra}" if extra else "") + "]")
            header = (f"MVP dataset {table}, {country} (data/mvp, as of {as_of}, dataset sha256 {sha}), cells licensed "
                      f"{', '.join(ids)}: value [label; source].")
            for idx in _pack(header, lines):
                keys = ",".join(_clean(grp[i].get("key")) for i in idx)
                out.append(_draft("dataset", f"{DATA_PREFIX}/mvp/provenance.csv#table={table};country={country};keys={keys}",
                                  ctx.iso_of(country), as_of, header + "\n" + "\n".join(lines[i] for i in idx),
                                  list(ids), "econquest",
                                  f"MVP shared dataset data/mvp (EQ-A-0110), built {built}, vintage {_clean(man.get('vintage_id'))}",
                                  published=built))
    return out


BUILDERS: dict[str, Callable[[_Ctx], list[dict]]] = {
    "run_output": build_run_output, "archive": build_archive, "audit": build_audit, "calendar": build_calendar,
    "ledger": build_ledger, "corpus": build_corpus, "events": build_events, "dataset": build_dataset,
}


# ------------------------------------------------------------------------------------------------ public entry point
def _round_robin(by_kind: list[list[Chunk]], n: int) -> list[Chunk]:
    """First n chunks taken one per kind in turn, returned in canonical order (kind, then position)."""
    picked, i = [], 0
    while len(picked) < n and any(i < len(c) for c in by_kind):
        for k, c in enumerate(by_kind):
            if i < len(c) and len(picked) < n:
                picked.append((k, i))
        i += 1
    return [by_kind[k][j] for k, j in sorted(picked)]


def build_context(data_dir, *, kinds: Iterable[str] | str | None = None, country: str | None = None, as_of=None,
                  scope: str = "internal", limit: int | None = None, outputs_dir=None) -> list[Chunk]:
    """Read-only, citable context chunks (see the module docstring).

    data_dir     the data folder (data/ or a copy of it)
    kinds        subset of KINDS (default all)
    country      ISO3 or a desk country name (countries.csv of data_dir); only chunks of that country
    as_of        point in time: date (end of that UTC day) or ISO timestamp; None = everything recorded
    scope        "internal" (everything) | "client" (only chunks whose scope is client_ok)
    limit        most chunks returned (round-robin across kinds); None = MAX_CHUNKS
    outputs_dir  run outputs and research archive folder (default <data_dir>/../outputs)
    """
    data = Path(data_dir)
    if not data.is_dir():
        raise FileNotFoundError(f"data folder {data} not found")
    if kinds is None:
        want = list(KINDS)
    else:
        want = [kinds] if isinstance(kinds, str) else list(kinds)
        bad = [k for k in want if k not in KINDS]
        if bad:
            raise ValueError(f"kinds {bad} not in {list(KINDS)}")
    if scope not in REQUEST_SCOPES:
        raise ValueError(f"scope {scope!r} not in {REQUEST_SCOPES}")
    if limit is not None and (isinstance(limit, bool) or not isinstance(limit, int) or limit < 0):
        raise ValueError("limit must be a non-negative integer or None")
    cut = cutoff_stamp(as_of)
    out_dir = Path(outputs_dir) if outputs_dir is not None else data.resolve().parent / OUTPUTS_PREFIX
    scope_fn, fence_fn = scope_function(), fence_function()
    _LOG.debug("context hooks in use: %s", hooks_in_use())
    with LIC.use_register(data_dir=data):
        ctx = _Ctx(data, out_dir, cut)
        iso = None
        if country is not None:
            iso = ctx.iso_of(country)
            if not iso:
                raise ValueError(f"country {country!r} is not an ISO3 code or name in {data / 'countries.csv'}")
        by_kind = []
        for kind in KINDS:
            if kind not in want:
                continue
            chunks = []
            for d in BUILDERS[kind](ctx):
                if iso is not None and d["country"] != iso:
                    continue
                if _after(d["published_utc"], cut) or _after(d["retrieved_utc"], cut):
                    continue
                c = _finish(d, scope_fn, fence_fn)
                if scope == "client" and c.scope != "client_ok":
                    continue
                chunks.append(c)
            by_kind.append(chunks)
    return _round_robin(by_kind, MAX_CHUNKS if limit is None else min(limit, MAX_CHUNKS))
