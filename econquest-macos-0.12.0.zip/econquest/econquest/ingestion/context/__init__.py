"""Assistant context (PI-15, EQ-A-0143..0145): read-only, citable chunks for the LLM assistant.

    from econquest.ingestion.context import build_context, Chunk
    chunks = build_context(data_dir, *, kinds=None, country=None, as_of=None, scope="internal", limit=None)

builders.py (A-0143, AGENT-06) builds the chunks; scope.py (A-0144, AGENT-04) decides client_ok vs internal from the
licence ids; hygiene.py (A-0145, AGENT-02) fences ingested text. Contract: docs/runbooks/A-PI15-agent-brief.md.
"""
from .builders import KINDS, MAX_CHUNKS, TEXT_CAP, Chunk, build_context

__all__ = ["build_context", "Chunk", "KINDS", "TEXT_CAP", "MAX_CHUNKS"]
