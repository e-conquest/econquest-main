"""What the assistant may read for a client-facing answer (EQ-A-0144).

Every context chunk carries `licence_ids`, the register rows (data/licences.csv) that cover its text. This module
decides, from those ids alone, whether the chunk may reach a client-facing answer ("client_ok") or stays "internal".
It adds no licence rules of its own. A cell's ids come from the existing hooks:
  * licences.matches / the register rows (every row that matches, not only the strictest one),
  * audit.client_output_reason (IMF / WEO codes in series or transform, theratesapi EXC-005, national sources,
    hand-entered FX, Yahoo, desk-barred licence terms, unestablished sources), mapped back to the row it names,
  * client_safe_route.D3_STRICT_SERIES (IMF-compiled WDI codes and the [imf_via_wdi] tag -> the D3 row imf_via_wdi).

Public API (read-only: no writes, no network, no model calls):

    chunk_scope(licence_ids, *, register=None) -> ("client_ok" | "internal", reason)
    cell_licence_ids(source="", series="", licence="", transform="", path=None, *, register=None, data_dir=None)
        -> tuple[str, ...]
    derived_licence_ids(*input_ids) -> tuple[str, ...]
    filter_for_client(chunks, *, register=None) -> (kept_chunks, {reason: count})
    crosscheck_variant(variant_dir, mvp_data) -> dict      (the refusal test's cross-check against the builder)

Fail closed. A chunk is "internal" when:
  * it has no licence ids;
  * an id is not a register row (unknown, or the UNMATCHED / RULE_RESTRICTED markers below);
  * the register exists but is invalid, or cannot be found;
  * any row has client_output other than "allowed" (restricted / barred: IMF, theratesapi EXC-005, ACLED and other
    non-commercial rows, licensed vendors, unestablished_source, hazard_panel_wide, econquest_assistant, ...);
  * any row is not verified for client use: terms_verified other than "yes", commercial other than "yes", or
    internal_use other than "yes".
Values econquest derives from inputs carry their inputs' ids (derived_licence_ids), so a derived row inherits
"internal" from any internal input.

Known conservative difference from the client-safe dataset (EQ-A-0124): that builder releases cells whose rows say
client_output=allowed even when terms_verified is UNVERIFIED (for example the peg row, seed estimates, econquest_derived,
and imf_via_wdi under a simulated D3 "yes"), and national sources cleared by licence_ok=yes. The assistant does not:
"unverified" is internal here (A-PI15 brief). crosscheck_variant reports each such cell.
"""
from __future__ import annotations

import csv
import re
from collections import Counter
from pathlib import Path
from typing import Iterable, Mapping

TICKET = "EQ-A-0144"
CLIENT_OK = "client_ok"
INTERNAL = "internal"
UNMATCHED = "(no register row)"                 # licences.UNMATCHED: a source no register row matches
RULE_RESTRICTED = "(restricted by audit rule)"  # client_output_reason restricted it but names no register row
REGISTER_INVALID = "(licence register invalid)"
DERIVED_ROW = "econquest_derived"
ASSISTANT_ROW = "econquest_assistant"           # model output itself (tighten-only register row, EQ-A-0144)
# Q-1 (SEC-A-017, AGENT-08 2026-10-27): WDI reserve ratios whose denominator (total reserves) WDI compiles from IMF IFS.
# Whether they count as IMF-derived for client output is Sam's question (docs/runbooks/A-sam-ready.md item 22). Until he
# answers, the ASSISTANT scope alone treats them as internal (fail closed). client_safe_route.D3_CODES is deliberately
# NOT changed: that would move the client-safe dataset, which stays as built until Sam approves.
RESERVE_RATIO_CODES = ("DT.DOD.DSTC.IR.ZS",        # short-term external debt, % of total reserves (Inputs 2.9)
                       "FI.RES.TOTL.DT.ZS",        # total reserves, % of total external debt
                       "FI.RES.XGLD.CD")           # total reserves minus gold (IMF IFS)
RESERVE_RATIO = "(reserve ratio: IMF-compiled denominator, Sam Q-1 open)"
_RESERVE_RATIO_RE = re.compile(r"\b(" + "|".join(re.escape(c) for c in RESERVE_RATIO_CODES) + r")\b", re.IGNORECASE)
MARKERS = (UNMATCHED, RULE_RESTRICTED, REGISTER_INVALID, RESERVE_RATIO)
_REGISTER_ID_RE = re.compile(r"^licence register ([a-z0-9_]{1,40}):")


# ------------------------------------------------------------------------------------------------ register access
def _rows(register: list[dict] | None) -> tuple[list[dict], str | None]:
    """(rows, problem). register=None: the register in force (licences.use_register / $ECONQUEST_LICENCE_REGISTER /
    data/licences.csv). A missing or invalid register gives no rows and a problem text: every chunk is internal."""
    from .. import licences
    if register is not None:
        return list(register), None
    why = licences.register_problem()
    if why:
        return [], f"licence register {why[:200]}: every chunk is internal (fail closed)"
    return licences.safe_register(), None


# ------------------------------------------------------------------------------------------------ the decision
def _row_problem(row: Mapping) -> str | None:
    from ..licences import register_reason
    sid = row.get("source_id", "")
    if row.get("client_output") != "allowed":
        return register_reason(row, "client")
    unverified = [f"{c}={row.get(c)!r}" for c, ok in (("terms_verified", "yes"), ("commercial", "yes"),
                                                      ("internal_use", "yes")) if row.get(c) != ok]
    if unverified:
        return (f"licence register {sid}: not verified for client output ({', '.join(unverified)}); "
                f"unverified rows stay internal (fail closed, {TICKET})")
    return None


def chunk_scope(licence_ids: Iterable[str], *, register: list[dict] | None = None) -> tuple[str, str]:
    """("client_ok", reason) only when every id is a register row cleared for client output; else ("internal",
    reason naming the first id, in sorted order, that keeps it internal)."""
    ids = sorted({str(i) for i in (licence_ids or ()) if i is not None})
    if not ids:
        return INTERNAL, f"no licence ids: internal (fail closed, {TICKET})"
    rows, problem = _rows(register)
    if problem:
        return INTERNAL, problem
    by_id = {r.get("source_id"): r for r in rows}
    for sid in ids:
        row = by_id.get(sid)
        if row is None:
            what = {UNMATCHED: "no register row matches the source",
                    RULE_RESTRICTED: "an audit rule restricts it for client output and names no register row",
                    REGISTER_INVALID: "the licence register was invalid when the chunk was tagged",
                    RESERVE_RATIO: "WDI reserve ratio with an IMF-compiled denominator (Q-1, open for Sam)"}.get(sid)
            return INTERNAL, f"{what or f'unknown licence id {sid!r}'}: internal (fail closed, {TICKET})"
        why = _row_problem(row)
        if why:
            return INTERNAL, why
    return CLIENT_OK, f"all licence rows cleared for client output: {', '.join(ids)}"


# ------------------------------------------------------------------------------------------------ cell / source -> ids
def _reason_ids(reason: str) -> set[str]:
    """Register ids behind a client_output_reason text (audit's own constants; no new rules)."""
    from .. import audit
    if reason.startswith("licence register invalid"):
        return {REGISTER_INVALID}
    m = _REGISTER_ID_RE.match(reason)
    if m:
        return {m.group(1)}
    if reason.startswith(audit.CLIENT_RESTRICTED_REASON):
        return {"imf_derived"}            # IMF / WEO named in source, licence, series or provenance (EXC-003 rows)
    known = {audit.CLIENT_THERATES_REASON: "theratesapi", audit.CLIENT_NATIONAL_REASON: "cb_registry",
             audit.CLIENT_HAND_FX_REASON: "fx_manual", audit.RESTRICTED_SOURCE_REASON: "yahoo"}
    return {known[reason]} if reason in known else {RULE_RESTRICTED}


def cell_licence_ids(source="", series="", licence="", transform="", path=None, *,
                     register: list[dict] | None = None, data_dir=None) -> tuple[str, ...]:
    """Register source_ids covering one cell, record or file: every matching row, plus the rows behind
    audit.client_output_reason and the D3 row for IMF-compiled WDI codes. UNMATCHED when nothing names a row.
    With `register` given, client_output_reason still reads the register in force (wrap the call in
    licences.use_register to point both at the same file)."""
    from .. import audit, licences
    from ..official.client_safe_route import D3_ROW, D3_STRICT_SERIES
    txt = audit._text
    rows, problem = _rows(register)
    if problem:
        return (REGISTER_INVALID,)
    ids = {r["source_id"] for r in rows
           if licences.matches(r, source=txt(source) or None, licence=txt(licence) or None,
                               series=txt(series) or None, path=path)}
    # SEC-A-017 F2: an IMF-compiled WDI code anywhere in the record's text (a provenance source text often names the
    # series code, and the dataset fallback passes source only) adds the D3 row; tighten-only.
    if re.search(D3_STRICT_SERIES, " ".join(txt(v) for v in (source, series, licence, transform)), re.IGNORECASE):
        ids.add(D3_ROW)
    if _RESERVE_RATIO_RE.search(" ".join(txt(v) for v in (source, series, licence, transform))):
        ids.add(RESERVE_RATIO)                 # Q-1: assistant scope only, internal until Sam answers
    if any(txt(v) for v in (source, series, licence, transform)):
        why = audit.client_output_reason(source=txt(source), licence=txt(licence), series=txt(series),
                                         data_dir=data_dir, transform=txt(transform))
        if why:
            ids |= _reason_ids(why)
    return tuple(sorted(ids)) if ids else (UNMATCHED,)


def record_licence_ids(record: Mapping, *, register: list[dict] | None = None, data_dir=None) -> tuple[str, ...]:
    """cell_licence_ids for a provenance / audit-trail row (keys source, series, transform, licence / license)."""
    get = record.get
    lic = next((get(k) for k in ("licence", "license", "licences", "licenses") if get(k) not in (None, "")), "")
    return cell_licence_ids(source=get("source", ""), series=get("series", ""), licence=lic,
                            transform=get("transform", ""), path=get("path"), register=register, data_dir=data_dir)


def derived_licence_ids(*input_ids: Iterable[str]) -> tuple[str, ...]:
    """Ids for a value econquest computes from inputs: econquest_derived plus every input's ids, so the derived row
    inherits internal from any internal input. No inputs at all gives UNMATCHED too (inputs unknown: fail closed)."""
    ids = {DERIVED_ROW}
    for group in input_ids:
        ids |= {str(i) for i in (group or ()) if i is not None}
    if len(ids) == 1:
        ids.add(UNMATCHED)
    return tuple(sorted(ids))


# ------------------------------------------------------------------------------------------------ client filter
def _field(chunk, name):
    return chunk.get(name) if isinstance(chunk, Mapping) else getattr(chunk, name, None)


def filter_for_client(chunks: Iterable, *, register: list[dict] | None = None) -> tuple[list, dict]:
    """Chunks a client-facing answer may read, and {reason: count} for every chunk dropped (plus "client_ok": kept).
    The scope is recomputed from licence_ids; a chunk already marked internal stays out even if its ids pass."""
    kept, counts = [], Counter()
    for c in chunks:
        scope, why = chunk_scope(_field(c, "licence_ids") or (), register=register)
        if scope == CLIENT_OK and _field(c, "scope") not in (None, CLIENT_OK):
            scope, why = INTERNAL, f"chunk marked {_field(c, 'scope')!r} by its builder"
        if scope == CLIENT_OK:
            kept.append(c)
            counts[CLIENT_OK] += 1
        else:
            counts[why] += 1
    return kept, dict(counts)


# ------------------------------------------------------------------------------------------------ builder cross-check
def _csv(p: Path) -> list[dict]:
    if not p.exists():
        return []
    with p.open(newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def crosscheck_variant(variant_dir, mvp_data) -> dict:
    """Compare chunk_scope with a client-safe dataset variant (outputs/client_safe_dataset/d3_<answer>), read-only.
    Universe: the variant's live cells (released by the builder with their original value) and its withheld cells.
    Each cell's ids come from its data/mvp record (audit_trail.csv, else live/provenance.csv), judged under the
    variant's own simulated register. Returns counts and every disagreement."""
    from .. import licences
    from ..client_safe_dataset import TABLE_FILE
    variant, mvp_data = Path(variant_dir), Path(mvp_data)
    reg_path = next(iter(sorted(variant.glob("licences_d3_*.csv"))), None)
    if reg_path is None:
        raise FileNotFoundError(f"{variant}: no simulated register licences_d3_*.csv")
    file_table = {v: k for k, v in TABLE_FILE.items()}
    records: dict = {}
    for p in (mvp_data / "live" / "provenance.csv", mvp_data / "audit_trail.csv"):     # audit trail wins
        for r in _csv(p):
            records[(file_table.get(r.get("table", ""), r.get("table", "")), r.get("key", ""), r.get("country", ""))] = r
    cells = [((file_table.get(r["table"], r["table"]), r["key"], r["country"]), True)
             for r in _csv(variant / "provenance.csv") if r.get("label") == "live"]
    cells += [((r["table"], r["key"], r["country"]), False) for r in _csv(variant / "withheld.csv")]
    out = {"variant": str(variant), "register": reg_path.name, "cells": len(cells), "released": 0, "withheld": 0,
           "client_ok": 0, "internal": 0, "agree": 0, "disagree": [], "internal_by_reason": Counter()}
    with licences.use_register(reg_path):
        reg = licences.load_register(reg_path)
        for key, released in cells:
            rec = records.get(key)
            ids = record_licence_ids(rec, data_dir=mvp_data) if rec else (UNMATCHED,)
            scope, why = chunk_scope(ids, register=reg)
            out["released" if released else "withheld"] += 1
            out[scope] += 1
            if scope == INTERNAL:
                out["internal_by_reason"][why] += 1
            if (scope == CLIENT_OK) == released:
                out["agree"] += 1
            else:
                out["disagree"].append({"table": key[0], "key": key[1], "country": key[2], "released": released,
                                        "scope": scope, "licence_ids": ids, "reason": why})
    out["internal_by_reason"] = dict(out["internal_by_reason"])
    return out
