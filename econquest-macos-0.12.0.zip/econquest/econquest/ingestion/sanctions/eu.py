"""EU consolidated financial sanctions list adapter, Financial Sanctions Files XML 1.1 (EQ-A-0133).

Layout (FSF XML 1.1 documentation, UNVERIFIED against a downloaded file): root `export` with attribute generationDate
(ISO 8601); one `sanctionEntity` per entry with attributes logicalId and euReferenceNumber; children
`regulation` (attributes programme, publicationDate, entryIntoForceDate), `subjectType` (code person | enterprise),
`nameAlias` (wholeName), `citizenship`, `address` and `birthdate` (countryIso2Code, countryDescription), and
`remark`. The entry id is euReferenceNumber, or logicalId when that is empty. The listing date is the earliest
regulation publicationDate on the entry (the first act that listed it). The publication date is generationDate's
calendar date.
"""
from __future__ import annotations

from .base import (LIST_SPECS, Countries, Entry, LayoutError, ParseResult, check_size, children, finish, flags,
                   iso_date, iso_timestamp_date, local, parse_xml, sha256)

SUBJECT_TYPES = {"person": "individual", "enterprise": "entity"}


def parse(body: bytes, name: str = "xmlFullSanctionsList_1_1.xml", data_dir=None) -> ParseResult:
    spec = LIST_SPECS["eu_fsf"]
    check_size(body, spec, name)
    root = parse_xml(body, name)
    if local(root.tag) != "export":
        raise LayoutError(f"{name}: root element {local(root.tag)!r}, expected export (FSF XML 1.1)")
    published = iso_timestamp_date(root.get("generationDate"), f"{name} generationDate")
    cs = Countries(data_dir)
    entries, notes = [], []
    for e in children(root, "sanctionEntity"):
        eid = (e.get("euReferenceNumber") or "").strip() or (e.get("logicalId") or "").strip()
        st = children(e, "subjectType")
        code = (st[0].get("code") or "").strip().casefold() if st else ""
        etype = SUBJECT_TYPES.get(code)
        if etype is None:
            raise LayoutError(f"{name}: entry {eid}: subjectType code {code!r} not in {sorted(SUBJECT_TYPES)}")
        aliases = children(e, "nameAlias")
        strong = [a for a in aliases if (a.get("strong") or "").casefold() == "true"] or aliases
        nm = (strong[0].get("wholeName") or "").strip() if strong else ""
        regs = children(e, "regulation")
        progs = tuple((r.get("programme") or "").strip() for r in regs if (r.get("programme") or "").strip())
        dates = sorted(iso_date(r.get("publicationDate"), "%Y-%m-%d", f"{name} {eid} regulation publicationDate")
                       for r in regs if (r.get("publicationDate") or "").strip())
        links = []
        for lt, tag in (("citizenship", "citizenship"), ("address", "address"), ("birth", "birthdate")):
            for el in children(e, tag):
                code2, desc = (el.get("countryIso2Code") or "").strip(), (el.get("countryDescription") or "").strip()
                if code2 in ("", "00") and desc.upper() in ("", "UNKNOWN"):
                    continue
                links.append((lt, cs.code2(code2, desc), desc or code2))
        for p in progs:
            iso = cs.programme(p)
            if iso:
                links.append(("programme", iso, p))
            else:
                notes.append(f"programme {p} names no country (no programme link)")
        remark = " ".join((r.text or "") for r in children(e, "remark"))
        cb, so = flags(nm, etype, remark)
        entries.append(Entry("eu_fsf", eid, etype, nm, progs, dates[0] if dates else "", links, cb, so))
    return finish("eu_fsf", published, entries, {name: sha256(body)}, cs, sorted(set(notes)))
