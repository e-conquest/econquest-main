"""Shared base for the public sanctions-list adapters (EQ-A-0133, PI-13 geopolitical depth).

Lists (LIST_SPECS):
    ofac_sdn     OFAC Specially Designated Nationals list (SDN.XML, or SDN.CSV + ADD.CSV)
    ofac_cons    OFAC Consolidated (non-SDN) list (CONSOLIDATED.XML, same schema as SDN.XML)
    eu_fsf       EU consolidated list of financial sanctions (Financial Sanctions Files, XML 1.1)
    uk_ofsi      UK OFSI Consolidated List of financial sanctions targets (ConList.csv)
    un_sc        UN Security Council consolidated list (consolidated.xml)

Each adapter turns the bytes of one published file (two for the OFAC CSV pair) into a ParseResult: the list's own
publication date as printed in the file, and one Entry per listed person, entity, vessel or aircraft with the list's
entry id, entity type, programmes or regimes, country links and the listing date where the file gives one.

Rules (A-PI13 brief):
- No network at import, and tests never touch the network. `fetch_bytes` runs on Sam's Mac only. It allows https
  only, checks the host against the list's allow-list, refuses redirects and caps the body (events.base.http_fetch).
- Layouts follow each publisher's documentation and are UNVERIFIED against a downloaded file (layout_verified False).
  An unknown layout is refused loudly with LayoutError and never guessed.
- Countries map through the repo's ISO tables (research.base.CountryMapper; EU ISO2 codes through data/countries.csv
  and data/panel/universe_proposal.csv). A miss is listed in ParseResult.unmapped and never guessed. A programme
  links to a country only through PROGRAMME_ALIASES or when its name is a country name the tables know.
- Text from a list file goes through research.base.safe_text before it reaches a CSV.
- central_bank and state_owned are text flags, not classifications. central_bank is set when the name matches
  CENTRAL_BANK_RE. state_owned is set when the list's own remark text matches STATE_OWNED_RE. Counts built on them
  are lower bounds.
"""
from __future__ import annotations

import datetime as dt
import hashlib
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable

from econquest.ingestion.research.base import CountryMapper, LayoutError, safe_text  # noqa: F401 (re-exported)

TICKET = "EQ-A-0133"
ENTITY_TYPES = ("individual", "entity", "vessel", "aircraft", "unknown")
LINK_TYPES = ("nationality", "citizenship", "address", "birth", "flag", "programme")
DATE_RE = re.compile(r"^\d{4}-\d{2}-\d{2}$")
ISO2_RE = re.compile(r"^[A-Z]{2}$")
DEFAULT_MAX_BYTES = 200 * 1024 * 1024
CENTRAL_BANK_RE = re.compile(r"\bcentral bank\b|\bbanco central\b|\bbanque centrale\b|\bbank markazi\b", re.I)
STATE_OWNED_RE = re.compile(r"\bstate[- ]owned\b|\bgovernment[- ]owned\b|\bowned (?:or controlled )?by the government\b",
                            re.I)
LICENCE_TAG = "public sanctions list; terms UNVERIFIED; internal research use only"
# Programme / regime tags that name a country but are not a country name the ISO tables know. Each one is
# read off the tag itself. Anything else is unmapped (listed in notes, never guessed).
PROGRAMME_ALIASES = {"DPRK": "PRK", "NORTH KOREA": "PRK", "BURMA": "MMR", "DRC": "COD", "CAR": "CAF",
                     "DEMOCRATIC REPUBLIC OF THE CONGO": "COD", "CENTRAL AFRICAN REPUBLIC": "CAF"}


@dataclass(frozen=True)
class ListSpec:
    key: str
    name: str
    publisher: str
    formats: tuple                 # parser formats accepted ("xml", "csv")
    urls: dict                     # format -> documented download URL (UNVERIFIED from the cloud)
    hosts: tuple                   # https host allow-list for fetch_bytes
    fetch_mode: str                # "direct" (plain file URL) or "manual" (download by hand into the drop folder)
    terms_url: str
    licence_source_id: str         # data/licences.csv row
    max_bytes: int = DEFAULT_MAX_BYTES
    layout_verified: bool = False
    notes: str = ""


LIST_SPECS = {
    "ofac_sdn": ListSpec(
        "ofac_sdn", "OFAC Specially Designated Nationals and Blocked Persons List (SDN)", "US Treasury OFAC",
        ("xml", "csv"),
        {"xml": "https://sanctionslistservice.ofac.treas.gov/api/PublicationPreview/exports/SDN.XML",
         "csv": "https://sanctionslistservice.ofac.treas.gov/api/PublicationPreview/exports/SDN.CSV",
         "csv_add": "https://sanctionslistservice.ofac.treas.gov/api/PublicationPreview/exports/ADD.CSV"},
        ("sanctionslistservice.ofac.treas.gov",), "direct",
        "https://ofac.treasury.gov/sanctions-list-service", "ofac_sanctions",
        notes="SDN.CSV carries no nationality and no publication date: prefer SDN.XML; the CSV needs --published"),
    "ofac_cons": ListSpec(
        "ofac_cons", "OFAC Consolidated Sanctions List (non-SDN lists)", "US Treasury OFAC", ("xml",),
        {"xml": "https://sanctionslistservice.ofac.treas.gov/api/PublicationPreview/exports/CONSOLIDATED.XML"},
        ("sanctionslistservice.ofac.treas.gov",), "direct",
        "https://ofac.treasury.gov/sanctions-list-service", "ofac_sanctions"),
    "eu_fsf": ListSpec(
        "eu_fsf", "EU consolidated list of persons, groups and entities subject to EU financial sanctions",
        "European Commission (FISMA / FPI), Financial Sanctions Files", ("xml",),
        {"xml": "https://webgate.ec.europa.eu/fsd/fsf/public/files/xmlFullSanctionsList_1_1/content"},
        ("webgate.ec.europa.eu",), "manual",
        "https://webgate.ec.europa.eu/fsd/fsf", "eu_sanctions",
        notes="the public file link carries a token shown on the FSF page: download by hand into the drop folder"),
    "uk_ofsi": ListSpec(
        "uk_ofsi", "UK OFSI Consolidated List of financial sanctions targets", "HM Treasury OFSI", ("csv",),
        {"csv": "https://ofsistorage.blob.core.windows.net/publishlive/2022format/ConList.csv"},
        ("ofsistorage.blob.core.windows.net",), "direct",
        "https://www.gov.uk/government/publications/financial-sanctions-consolidated-list-of-targets",
        "uk_ofsi_sanctions",
        notes="UNVERIFIED: OFSI announced moving to the FCDO UK Sanctions List as the single source; check on the Mac "
              "that ConList.csv is still published before relying on it (docs/runbooks/A-sanctions.md)"),
    "un_sc": ListSpec(
        "un_sc", "UN Security Council Consolidated List", "United Nations Security Council", ("xml",),
        {"xml": "https://scsanctions.un.org/resources/xml/en/consolidated.xml"},
        ("scsanctions.un.org",), "direct",
        "https://main.un.org/securitycouncil/en/content/un-sc-consolidated-list", "un_sanctions"),
}
LIST_KEYS = tuple(LIST_SPECS)


@dataclass
class Entry:
    list: str
    entry_id: str
    entity_type: str
    name: str
    programmes: tuple = ()
    listing_date: str = ""                     # YYYY-MM-DD or "" (not given by the list)
    links: list = field(default_factory=list)  # (link_type, iso3 or "", country_text)
    central_bank: bool = False
    state_owned: bool = False


@dataclass
class ParseResult:
    list: str
    publication_date: str                      # YYYY-MM-DD, as printed in the file (or given for the OFAC CSV)
    entries: list
    source_files: dict                         # file name -> sha256
    unmapped: list = field(default_factory=list)
    notes: list = field(default_factory=list)

    @property
    def sha256(self) -> str:
        """One hash over the source files (name and sha256, sorted): the snapshot's identity."""
        h = hashlib.sha256()
        for n, s in sorted(self.source_files.items()):
            h.update(f"{n}\0{s}\n".encode())
        return h.hexdigest()


def sha256(body: bytes) -> str:
    return hashlib.sha256(body).hexdigest()


def check_size(body: bytes, spec: ListSpec, what: str) -> None:
    if len(body) > spec.max_bytes:
        raise LayoutError(f"{what}: {len(body)} bytes exceeds the {spec.max_bytes}-byte cap")


def iso_date(text: str, fmt: str, what: str) -> str:
    """YYYY-MM-DD from `text` in strptime format `fmt`; LayoutError when it does not parse (never guessed)."""
    t = str(text or "").strip()
    try:
        return dt.datetime.strptime(t, fmt).date().isoformat()
    except ValueError:
        raise LayoutError(f"{what}: date {t[:40]!r} is not in the documented format {fmt}") from None


def iso_timestamp_date(text: str, what: str) -> str:
    """The calendar date of an ISO 8601 timestamp as printed (its own offset, not converted)."""
    t = str(text or "").strip()
    m = re.match(r"^(\d{4}-\d{2}-\d{2})(?:[T ].*)?$", t)
    if not m:
        raise LayoutError(f"{what}: timestamp {t[:40]!r} is not ISO 8601")
    return iso_date(m.group(1), "%Y-%m-%d", what)


def local(tag: str) -> str:
    """Element name without its XML namespace."""
    return tag.rsplit("}", 1)[-1]


def parse_xml(body: bytes, what: str):
    """Root element through defusedxml (no entity expansion, no external entities); LayoutError when unreadable."""
    from defusedxml import ElementTree as ET
    from defusedxml.common import DefusedXmlException
    try:
        return ET.fromstring(body)
    except DefusedXmlException as e:
        raise LayoutError(f"{what}: XML refused ({type(e).__name__})") from None
    except Exception as e:                                            # ParseError and friends: one refusal
        raise LayoutError(f"{what}: not readable XML ({type(e).__name__}: {str(e)[:200]})") from None


def children(el, name: str) -> list:
    return [c for c in list(el) if local(c.tag) == name]


def child(el, name: str):
    for c in list(el):
        if local(c.tag) == name:
            return c
    return None


def text_of(el, name: str) -> str:
    c = child(el, name)
    return (c.text or "").strip() if c is not None and c.text else ""


def descend(el, *path: str) -> list:
    """Every element reached through the namespace-free `path` of child names."""
    cur = [el]
    for p in path:
        cur = [c for e in cur for c in children(e, p)]
    return cur


# ------------------------------------------------------------------------------------------------- countries

class Countries:
    """Country text or ISO2 -> ISO3 through the repo tables. Misses are recorded, never guessed."""

    def __init__(self, data_dir: str | Path | None = None):
        self.mapper = CountryMapper()
        self.iso2 = iso2_to_iso3(data_dir)
        self.unmapped: set = set()

    def name(self, text: str) -> str:
        t = str(text or "").strip()
        if not t:
            return ""
        iso = self.mapper(None, t)
        if not iso:
            self.unmapped.add(safe_text(t))
        return iso or ""

    def code2(self, code: str, text: str = "") -> str:
        c = str(code or "").strip().upper()
        if ISO2_RE.fullmatch(c) and c in self.iso2:
            return self.iso2[c]
        return self.name(text) if text and str(text).strip().upper() not in ("UNKNOWN", "") else ""

    def programme(self, tag: str) -> str:
        """ISO3 for a programme / regime tag that names a country, else "". The tag's suffixes are stripped: an
        executive-order suffix (-EO13850), trailing digits (DPRK3), a parenthesised qualifier ("Iran (Nuclear)")."""
        t = str(tag or "").strip()
        if not t:
            return ""
        base = re.sub(r"\s*\(.*?\)\s*", " ", t)
        base = re.sub(r"-EO\d+.*$", "", base, flags=re.I)
        base = re.sub(r"[-_ ]?\d+$", "", base).strip()
        up = base.upper()
        if up in PROGRAMME_ALIASES:
            return PROGRAMME_ALIASES[up]
        if re.fullmatch(r"[A-Z]{3}", t) and t in self.mapper.known:      # EU programme codes are ISO3 (VEN, ZWE)
            return t
        from econquest.ingestion.research.base import name_key
        return self.mapper.look.get(name_key(base), "")


def iso2_to_iso3(data_dir: str | Path | None = None) -> dict:
    """ISO2 -> ISO3 from data/countries.csv and data/panel/universe_proposal.csv (the repo's own tables)."""
    from econquest.ingestion.nowcast_feed import iso2_map
    from econquest.ingestion.research.base import REPO_DATA
    out = {}
    for iso3, iso2 in iso2_map(data_dir or REPO_DATA).items():
        if ISO2_RE.fullmatch(iso2.upper()):
            out.setdefault(iso2.upper(), iso3.upper())
    return out


def flags(name: str, entity_type: str, remark_text: str) -> tuple[bool, bool]:
    cb = entity_type == "entity" and bool(CENTRAL_BANK_RE.search(name or ""))
    so = entity_type == "entity" and bool(STATE_OWNED_RE.search(remark_text or ""))
    return cb, so


def finish(list_key: str, publication_date: str, entries: list, files: dict, countries: Countries,
           notes: list | None = None) -> ParseResult:
    """Validate and wrap: unique entry ids, known entity and link types, clean dates; text through safe_text."""
    if not DATE_RE.fullmatch(publication_date or ""):
        raise LayoutError(f"{list_key}: publication date {publication_date!r} is not YYYY-MM-DD")
    seen, problems = set(), []
    for e in entries:
        if not e.entry_id:
            problems.append("an entry has no id")
        if e.entry_id in seen:
            problems.append(f"duplicate entry id {e.entry_id}")
        seen.add(e.entry_id)
        if e.entity_type not in ENTITY_TYPES:
            problems.append(f"{e.entry_id}: entity type {e.entity_type!r}")
        if e.listing_date and not DATE_RE.fullmatch(e.listing_date):
            problems.append(f"{e.entry_id}: listing date {e.listing_date!r}")
        bad = [lk for lk in e.links if lk[0] not in LINK_TYPES]
        if bad:
            problems.append(f"{e.entry_id}: link types {bad}")
        e.entry_id = safe_text(e.entry_id)
        e.name = safe_text(e.name)
        e.programmes = tuple(sorted({safe_text(p) for p in e.programmes if p}))
        e.links = sorted({(lt, iso, safe_text(txt)) for lt, iso, txt in e.links})
    if problems:
        raise LayoutError(f"{list_key}: " + "; ".join(problems[:10]))
    return ParseResult(list_key, publication_date, entries, files, sorted(countries.unmapped), list(notes or []))


# ------------------------------------------------------------------------------------------------- fetch (Mac only)

class FetchRefused(ValueError):
    """A download that the list's spec does not allow (mode, scheme, host)."""


def fetch_bytes(spec: ListSpec, fmt: str, fetcher: Callable | None = None) -> bytes:
    """Bytes of one documented list file. Runs on Sam's Mac only (the cloud cannot reach the hosts). `fetcher(url,
    headers, data, max_bytes=...)` is injectable for tests; the default is events.base.http_fetch (https only, no
    redirects, body capped)."""
    import urllib.parse
    if spec.fetch_mode != "direct":
        raise FetchRefused(f"{spec.key}: fetch_mode {spec.fetch_mode!r}: download by hand into "
                           f"data/sanctions/drop/{spec.key}/ (docs/runbooks/A-sanctions.md)")
    url = spec.urls.get(fmt, "")
    parts = urllib.parse.urlsplit(url)
    if parts.scheme != "https" or not parts.hostname:
        raise FetchRefused(f"{spec.key}: no https URL for format {fmt!r}")
    if parts.hostname not in spec.hosts:
        raise FetchRefused(f"{spec.key}: host {parts.hostname} not on the allow-list {list(spec.hosts)}")
    if parts.username or parts.password or parts.port or parts.query:
        raise FetchRefused(f"{spec.key}: URL with credentials, a port or a query refused")
    headers = {"User-Agent": "econquest/0.10 (sanctions list pull)"}
    if fetcher is None:
        from econquest.ingestion.events.base import http_fetch
        return http_fetch(url, headers, max_bytes=spec.max_bytes)
    body = fetcher(url, headers, None, max_bytes=spec.max_bytes)
    if len(body) > spec.max_bytes:
        raise FetchRefused(f"{spec.key}: response exceeds the {spec.max_bytes}-byte cap")
    return body
