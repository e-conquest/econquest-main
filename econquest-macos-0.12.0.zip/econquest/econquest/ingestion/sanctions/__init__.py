"""Public sanctions lists (EQ-A-0133): OFAC SDN and Consolidated, EU FSF, UK OFSI, UN SC.

Adapters (ofac, eu, uk, un) parse each publisher's documented file layout into entries with country links. `store`
keeps them point-in-time under data/sanctions/, and `exposure` counts them per desk country and per programme.
There is no network at import. Live pulls run on Sam's Mac (docs/runbooks/A-sanctions.md).
"""
from .base import LIST_KEYS, LIST_SPECS  # noqa: F401
