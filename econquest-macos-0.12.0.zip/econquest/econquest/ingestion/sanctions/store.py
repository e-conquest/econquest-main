"""Point-in-time store for the sanctions lists (EQ-A-0133). The store path, data/sanctions/, was approved by
A/AGENT-08 on 2026-10-26.

    data/sanctions/drop/<list>/                                 a file downloaded by hand on the Mac (manual lists)
    data/sanctions/snapshots/<list>/<publication_date>_<sha16>/
        source_<file name>   the published bytes, written once and read-only
        entries.csv          ENTRY_COLUMNS, one row per listed entry
        links.csv            LINK_COLUMNS, one row per (entry, link type, country)
        meta.json            list, publication_date, retrieved_utc, sha256, source files, url, licence, counts, notes

The store sits outside data/live on purpose. Real list snapshots carry personal names, so they must never be frozen
into data/mvp (mvp_dataset.EXCLUDE_DIRS, asked of AGENT-06 for EQ-A-0130) or enter versioning.data_hash (DATA_GLOBS
covers no sanctions/ path).

As-of rule: `snapshot_as_of(data_dir, list, as_of)` returns the snapshot with the latest publication_date on or before
as_of. On a tie (two files published the same day) it takes the later retrieved_utc. A list published after as_of is
never seen. Snapshots are write-once: the same bytes are a no-op, and a folder never changes.
"""
from __future__ import annotations

import csv
import datetime as dt
import io
import json
import os
import re
import shutil
import tempfile
from pathlib import Path

from .base import DATE_RE, LICENCE_TAG, LIST_SPECS, TICKET, LayoutError, ParseResult

ROOT = "sanctions"
SCHEMA = "econquest-sanctions-snapshot/1"
ENTRY_COLUMNS = ["list", "entry_id", "entity_type", "name", "programmes", "listing_date", "central_bank", "state_owned"]
LINK_COLUMNS = ["list", "entry_id", "link_type", "iso3", "country_text"]
SNAP_RE = re.compile(r"^(\d{4}-\d{2}-\d{2})_([0-9a-f]{16})$")
_SAFE_NAME = re.compile(r"[^A-Za-z0-9._-]+")
REPO_DATA = Path(__file__).resolve().parents[3] / "data"
SYNTHETIC_MARK = b"synthetic fixture"          # every tests/fixtures/sanctions file carries it (README there)


class StoreError(ValueError):
    pass


def _key(key: str) -> str:
    if key not in LIST_SPECS:
        raise StoreError(f"unknown list {key!r}; lists are {', '.join(LIST_SPECS)}")
    return key


def _check_dir(data_dir: str | Path) -> Path:
    d = Path(data_dir)
    if "mvp" in d.resolve().parts:
        raise StoreError(f"{d}: the sanctions store never writes inside data/mvp")
    return d


def _in_repo_data(d: Path) -> bool:
    try:
        p, r = d.resolve(), REPO_DATA.resolve()
    except OSError:
        return True
    return p == r or r in p.parents


def store_root(data_dir: str | Path) -> Path:
    return Path(data_dir) / ROOT


def drop_folder(data_dir: str | Path, key: str) -> Path:
    return store_root(data_dir) / "drop" / _key(key)


def snapshots_folder(data_dir: str | Path, key: str) -> Path:
    return store_root(data_dir) / "snapshots" / _key(key)


def _csv(cols: list[str], rows: list[list]) -> str:
    buf = io.StringIO()
    w = csv.writer(buf, lineterminator="\n")
    w.writerow(cols)
    w.writerows(rows)
    return buf.getvalue()


def _stamp(t: dt.datetime | None) -> str:
    t = t or dt.datetime.now(dt.timezone.utc)
    return t.astimezone(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def write_snapshot(result: ParseResult, sources: dict, data_dir: str | Path, *, retrieved: dt.datetime | None = None,
                   url: str = "") -> Path:
    """Write one parsed list into its snapshot folder (write-once). `sources` maps each file name in
    result.source_files to its bytes. Returns the folder. The same bytes a second time return the existing folder."""
    d = _check_dir(data_dir)
    key = _key(result.list)
    if set(sources) != set(result.source_files):
        raise StoreError(f"{key}: sources {sorted(sources)} do not match the parsed files {sorted(result.source_files)}")
    import hashlib
    for n, b in sources.items():
        if hashlib.sha256(b).hexdigest() != result.source_files[n]:
            raise StoreError(f"{key}: {n}: bytes differ from the parsed file")
    if not DATE_RE.fullmatch(result.publication_date):
        raise StoreError(f"{key}: bad publication date {result.publication_date!r}")
    if _in_repo_data(d) and any(SYNTHETIC_MARK in b.lower() for b in sources.values()):
        # ARCH-A-PI13 S-1: synthetic text never enters data/ (A-PI13 brief); the calendar and corpus stores refuse it
        # in code as well
        raise StoreError(f"{key}: a SYNTHETIC fixture file is refused for the repo's data/ (tests use a tmp folder)")
    base = snapshots_folder(d, key)
    for p in (store_root(d), base.parent, base):
        if p.is_symlink():
            raise StoreError(f"{p} is a link: the store writes only into plain folders")
    final = base / f"{result.publication_date}_{result.sha256[:16]}"
    if final.exists():
        return final
    base.mkdir(parents=True, exist_ok=True)
    tmp = Path(tempfile.mkdtemp(prefix=".tmp-", dir=base))
    try:
        for n, b in sources.items():
            p = tmp / ("source_" + _SAFE_NAME.sub("_", Path(n).name))
            p.write_bytes(b)
            os.chmod(p, 0o444)
        er = [[e.list, e.entry_id, e.entity_type, e.name, "; ".join(e.programmes), e.listing_date,
               int(e.central_bank), int(e.state_owned)] for e in sorted(result.entries, key=lambda e: e.entry_id)]
        lr = [[e.list, e.entry_id, lt, iso, txt] for e in sorted(result.entries, key=lambda e: e.entry_id)
              for lt, iso, txt in e.links]
        (tmp / "entries.csv").write_text(_csv(ENTRY_COLUMNS, er), encoding="utf-8")
        (tmp / "links.csv").write_text(_csv(LINK_COLUMNS, lr), encoding="utf-8")
        spec = LIST_SPECS[key]
        meta = {"schema": SCHEMA, "ticket": TICKET, "list": key, "list_name": spec.name, "publisher": spec.publisher,
                "publication_date": result.publication_date, "retrieved_utc": _stamp(retrieved),
                "sha256": result.sha256, "source_files": dict(sorted(result.source_files.items())), "url": url,
                "licence_source_id": spec.licence_source_id, "licence": LICENCE_TAG,
                "layout_verified": spec.layout_verified, "entries": len(er), "links": len(lr),
                "unmapped": result.unmapped, "notes": result.notes}
        (tmp / "meta.json").write_text(json.dumps(meta, indent=1, sort_keys=True) + "\n", encoding="utf-8")
        os.rename(tmp, final)
    except BaseException:
        shutil.rmtree(tmp, ignore_errors=True)
        raise
    return final


def list_snapshots(data_dir: str | Path, key: str) -> list[dict]:
    """meta.json of every snapshot of `key`, oldest first, each with its "path". A folder whose name does not match
    its meta (date or hash) is refused, not skipped."""
    base = snapshots_folder(data_dir, key)
    if not base.is_dir():
        return []
    out = []
    for p in sorted(base.iterdir()):
        if p.name.startswith(".") or not p.is_dir():
            continue
        m = SNAP_RE.fullmatch(p.name)
        if not m or p.is_symlink():
            raise StoreError(f"{p}: not a snapshot folder (expected <YYYY-MM-DD>_<sha16>, not a link)")
        meta = json.loads((p / "meta.json").read_text(encoding="utf-8"))
        if meta.get("publication_date") != m.group(1) or not str(meta.get("sha256", "")).startswith(m.group(2)) \
                or meta.get("list") != key:
            raise StoreError(f"{p}: meta.json does not match the folder name")
        meta["path"] = str(p)
        out.append(meta)
    return sorted(out, key=lambda m: (m["publication_date"], m.get("retrieved_utc", "")))


def snapshot_as_of(data_dir: str | Path, key: str, as_of: str) -> dict | None:
    if not DATE_RE.fullmatch(str(as_of)):
        raise StoreError(f"as_of {as_of!r} is not YYYY-MM-DD")
    seen = [m for m in list_snapshots(data_dir, key) if m["publication_date"] <= as_of]
    return seen[-1] if seen else None


def read_snapshot(meta_or_path) -> tuple[list[dict], list[dict]]:
    p = Path(meta_or_path["path"] if isinstance(meta_or_path, dict) else meta_or_path)
    with open(p / "entries.csv", encoding="utf-8", newline="") as f:
        entries = list(csv.DictReader(f))
    with open(p / "links.csv", encoding="utf-8", newline="") as f:
        links = list(csv.DictReader(f))
    if entries and list(entries[0]) != ENTRY_COLUMNS or links and list(links[0]) != LINK_COLUMNS:
        raise StoreError(f"{p}: entries.csv / links.csv columns changed")
    return entries, links


# ------------------------------------------------------------------------------------------------- parse dispatch

def parse_files(key: str, files: dict, *, published: str | None = None, data_dir=None) -> ParseResult:
    """Parse one list from {file name: bytes}. The format comes from the file name's extension; the OFAC CSV pair is
    recognised by SDN / ADD in the names."""
    from . import eu, ofac, uk, un
    _key(key)
    names = sorted(files)
    exts = {Path(n).suffix.lower() for n in names}
    if key in ("ofac_sdn", "ofac_cons") and exts == {".xml"} and len(names) == 1:
        return ofac.parse_xml_list(files[names[0]], key, names[0], data_dir)
    if key == "ofac_sdn" and exts == {".csv"}:
        sdn = [n for n in names if "add" not in Path(n).stem.lower()]
        add = [n for n in names if "add" in Path(n).stem.lower()]
        if len(sdn) != 1 or len(add) > 1:
            raise LayoutError(f"ofac_sdn CSV: expected SDN.CSV and optionally ADD.CSV, got {names}")
        return ofac.parse_csv_pair(files[sdn[0]], files[add[0]] if add else None, published or "", data_dir,
                                   (sdn[0], add[0] if add else "ADD.CSV"))
    if key == "eu_fsf" and exts == {".xml"} and len(names) == 1:
        return eu.parse(files[names[0]], names[0], data_dir)
    if key == "uk_ofsi" and exts == {".csv"} and len(names) == 1:
        return uk.parse(files[names[0]], names[0], data_dir)
    if key == "un_sc" and exts == {".xml"} and len(names) == 1:
        return un.parse(files[names[0]], names[0], data_dir)
    raise LayoutError(f"{key}: no parser for files {names} (formats {list(LIST_SPECS[key].formats)})")


def read_drop(data_dir: str | Path, key: str) -> dict:
    """{file name: bytes} of the files in data/sanctions/drop/<list>/ (plain files only, no links, hidden skipped)."""
    folder = drop_folder(data_dir, key)
    if not folder.is_dir():
        raise FileNotFoundError(f"{folder}: no drop folder; download the list by hand into it "
                                f"(docs/runbooks/A-sanctions.md)")
    if folder.is_symlink() or not folder.resolve().is_relative_to(Path(data_dir).resolve()):
        raise LayoutError(f"{folder}: the drop folder is a link or leaves the data folder")
    spec = LIST_SPECS[key]
    out = {}
    for p in sorted(folder.iterdir()):
        if p.name.startswith(".") or not p.is_file() or p.is_symlink():
            continue
        if p.stat().st_size > spec.max_bytes:
            raise LayoutError(f"{p}: exceeds the {spec.max_bytes}-byte cap")
        out[p.name] = p.read_bytes()
    if not out:
        raise FileNotFoundError(f"{folder}: empty")
    return out


def ingest(data_dir: str | Path, key: str, files: dict | None = None, *, published: str | None = None,
           retrieved: dt.datetime | None = None, url: str = "") -> tuple[ParseResult, Path]:
    """Parse `files` (default: the drop folder) and write the snapshot."""
    files = files if files is not None else read_drop(data_dir, key)
    res = parse_files(key, files, published=published, data_dir=None)
    return res, write_snapshot(res, files, data_dir, retrieved=retrieved, url=url)
