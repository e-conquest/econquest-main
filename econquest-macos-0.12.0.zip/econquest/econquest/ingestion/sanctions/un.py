"""UN Security Council Consolidated List adapter, consolidated.xml (EQ-A-0133).

Layout (scsanctions.un.org XML, sc-sanctions.xsd, UNVERIFIED against a downloaded file): root CONSOLIDATED_LIST with
attribute dateGenerated (ISO 8601); INDIVIDUALS/INDIVIDUAL and ENTITIES/ENTITY with DATAID, FIRST_NAME to
FOURTH_NAME, UN_LIST_TYPE (the sanctions regime), REFERENCE_NUMBER (e.g. "KPi.001"), LISTED_ON (YYYY-MM-DD) and
COMMENTS1. Individuals have NATIONALITY/VALUE, INDIVIDUAL_ADDRESS/COUNTRY and INDIVIDUAL_PLACE_OF_BIRTH/COUNTRY;
entities have ENTITY_ADDRESS/COUNTRY. The entry id is REFERENCE_NUMBER, or DATAID when that is empty.
"""
from __future__ import annotations

from .base import (LIST_SPECS, Countries, Entry, LayoutError, ParseResult, check_size, children, descend, finish,
                   flags, iso_date, iso_timestamp_date, local, parse_xml, sha256, text_of)

NAME_PARTS = ("FIRST_NAME", "SECOND_NAME", "THIRD_NAME", "FOURTH_NAME")


def parse(body: bytes, name: str = "consolidated.xml", data_dir=None) -> ParseResult:
    spec = LIST_SPECS["un_sc"]
    check_size(body, spec, name)
    root = parse_xml(body, name)
    if local(root.tag) != "CONSOLIDATED_LIST":
        raise LayoutError(f"{name}: root element {local(root.tag)!r}, expected CONSOLIDATED_LIST")
    published = iso_timestamp_date(root.get("dateGenerated"), f"{name} dateGenerated")
    if not children(root, "INDIVIDUALS") and not children(root, "ENTITIES"):
        raise LayoutError(f"{name}: neither INDIVIDUALS nor ENTITIES found")
    cs = Countries(data_dir)
    entries, notes = [], []
    for group, item, etype, paths in (
            ("INDIVIDUALS", "INDIVIDUAL", "individual",
             (("nationality", ("NATIONALITY", "VALUE")), ("address", ("INDIVIDUAL_ADDRESS", "COUNTRY")),
              ("birth", ("INDIVIDUAL_PLACE_OF_BIRTH", "COUNTRY")))),
            ("ENTITIES", "ENTITY", "entity", (("address", ("ENTITY_ADDRESS", "COUNTRY")),))):
        for e in descend(root, group, item):
            eid = text_of(e, "REFERENCE_NUMBER") or text_of(e, "DATAID")
            nm = " ".join(p for p in (text_of(e, n) for n in NAME_PARTS) if p)
            prog = text_of(e, "UN_LIST_TYPE")
            progs = (prog,) if prog else ()
            listed = text_of(e, "LISTED_ON")
            listed = iso_date(listed[:10], "%Y-%m-%d", f"{name} {eid} LISTED_ON") if listed else ""
            links = []
            for lt, path in paths:
                for el in descend(e, *path):
                    t = (el.text or "").strip()
                    if t:
                        links.append((lt, cs.name(t), t))
            for p in progs:
                iso = cs.programme(p)
                if iso:
                    links.append(("programme", iso, p))
                else:
                    notes.append(f"regime {p} names no country (no programme link)")
            cb, so = flags(nm, etype, text_of(e, "COMMENTS1"))
            entries.append(Entry("un_sc", eid, etype, nm, progs, listed, links, cb, so))
    return finish("un_sc", published, entries, {name: sha256(body)}, cs, sorted(set(notes)))
