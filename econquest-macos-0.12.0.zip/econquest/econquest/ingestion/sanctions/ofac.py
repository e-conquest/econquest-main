"""OFAC SDN and Consolidated (non-SDN) list adapters (EQ-A-0133).

Formats (OFAC Sanctions List Service exports, layout UNVERIFIED against a downloaded file):
- SDN.XML / CONSOLIDATED.XML: root sdnList, publshInformation/Publish_Date (MM/DD/YYYY), one sdnEntry per entry with
  uid, firstName, lastName, sdnType (Individual, Entity, Vessel, Aircraft), programList/program,
  nationalityList/nationality/country, citizenshipList/citizenship/country, addressList/address/country,
  vesselInfo/vesselFlag and remarks. The namespace is ignored, so both the older tempuri.org and the current Sanctions
  List Service namespace parse. The legacy XML gives no designation date, so listing_date stays "".
- SDN.CSV + ADD.CSV: no header row and "-0-" for empty. SDN.CSV columns are ent_num, SDN_Name, SDN_Type, Program,
  Title, Call_Sign, Vess_type, Tonnage, GRT, Vess_flag, Vess_owner, Remarks; several programmes are joined as
  "A] [B". ADD.CSV columns are ent_num, Add_num, Address, City/State/Postal, Country, Add_remarks. The CSV pair has
  no publication date and no nationality field, so the caller must pass `published`, and nationality links come
  only from the XML.
"""
from __future__ import annotations

import csv
import io

from .base import (LIST_SPECS, Countries, Entry, LayoutError, ParseResult, check_size, child, children, descend,
                   finish, flags, iso_date, local, parse_xml, sha256, text_of)

SDN_TYPES = {"individual": "individual", "entity": "entity", "vessel": "vessel", "aircraft": "aircraft"}
SDN_CSV_COLUMNS = ["ent_num", "SDN_Name", "SDN_Type", "Program", "Title", "Call_Sign", "Vess_type", "Tonnage", "GRT",
                   "Vess_flag", "Vess_owner", "Remarks"]
ADD_CSV_COLUMNS = ["ent_num", "Add_num", "Address", "City_State_Postal", "Country", "Add_remarks"]
EMPTY = "-0-"


def parse_xml_list(body: bytes, list_key: str = "ofac_sdn", name: str = "SDN.XML",
                   data_dir=None) -> ParseResult:
    spec = LIST_SPECS[list_key]
    if list_key not in ("ofac_sdn", "ofac_cons"):
        raise ValueError(f"not an OFAC list: {list_key}")
    check_size(body, spec, name)
    root = parse_xml(body, name)
    if local(root.tag) != "sdnList":
        raise LayoutError(f"{name}: root element {local(root.tag)!r}, expected sdnList")
    pub = descend(root, "publshInformation", "Publish_Date")
    if len(pub) != 1 or not (pub[0].text or "").strip():
        raise LayoutError(f"{name}: publshInformation/Publish_Date missing")
    published = iso_date(pub[0].text, "%m/%d/%Y", name)
    cs = Countries(data_dir)
    entries, notes = [], []
    for e in children(root, "sdnEntry"):
        uid = text_of(e, "uid")
        raw_type = text_of(e, "sdnType")
        etype = SDN_TYPES.get(raw_type.casefold())
        if etype is None:
            raise LayoutError(f"{name}: entry {uid}: sdnType {raw_type!r} not in {sorted(SDN_TYPES)}")
        nm = " ".join(p for p in (text_of(e, "firstName"), text_of(e, "lastName")) if p)
        progs = tuple(p.text.strip() for p in descend(e, "programList", "program") if p.text and p.text.strip())
        links = []
        for lt, path in (("nationality", ("nationalityList", "nationality")),
                         ("citizenship", ("citizenshipList", "citizenship")),
                         ("address", ("addressList", "address"))):
            for el in descend(e, *path):
                txt = text_of(el, "country")
                if txt:
                    links.append((lt, cs.name(txt), txt))
        vi = child(e, "vesselInfo")
        if vi is not None and text_of(vi, "vesselFlag"):
            links.append(("flag", cs.name(text_of(vi, "vesselFlag")), text_of(vi, "vesselFlag")))
        links += _programme_links(progs, cs, notes)
        cb, so = flags(nm, etype, text_of(e, "remarks"))
        entries.append(Entry(list_key, uid, etype, nm, progs, "", links, cb, so))
    rc = descend(root, "publshInformation", "Record_Count")
    if rc and (rc[0].text or "").strip().isdigit() and int(rc[0].text) != len(entries):
        notes.append(f"Record_Count {rc[0].text.strip()} but {len(entries)} sdnEntry elements")
    return finish(list_key, published, entries, {name: sha256(body)}, cs, sorted(set(notes)))


def _programme_links(progs, cs: Countries, notes: list) -> list:
    out = []
    for p in progs:
        iso = cs.programme(p)
        if iso:
            out.append(("programme", iso, p))
        else:
            notes.append(f"programme {p} names no country (no programme link)")
    return out


def _rows(body: bytes, ncols: int, what: str) -> list[list[str]]:
    try:
        text = body.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = body.decode("latin-1")            # OFAC CSVs have been published in Windows-1252 / Latin-1
    text = text.replace("\x1a", "")              # DOS end-of-file marker at the end of the OFAC CSVs
    out = []
    try:
        for i, r in enumerate(csv.reader(io.StringIO(text))):
            if not r or all(not c.strip() for c in r):
                continue
            if len(r) != ncols:
                raise LayoutError(f"{what}: line {i + 1} has {len(r)} fields, the documented layout has {ncols}")
            out.append([("" if c.strip() == EMPTY else c.strip()) for c in r])
    except csv.Error as e:                       # SEC-A-015 S-I1: e.g. a field over the csv module's 128 KiB limit
        raise LayoutError(f"{what}: not readable CSV ({str(e)[:120]})") from None
    return out


def parse_csv_pair(sdn_body: bytes, add_body: bytes | None, published: str, data_dir=None,
                   names=("SDN.CSV", "ADD.CSV")) -> ParseResult:
    """SDN.CSV (+ ADD.CSV for address countries). `published` (YYYY-MM-DD) is required: the files carry no date."""
    spec = LIST_SPECS["ofac_sdn"]
    if not published:
        raise LayoutError("SDN.CSV carries no publication date: pass published=YYYY-MM-DD (the date OFAC shows for "
                          "the file), or use SDN.XML")
    published = iso_date(published, "%Y-%m-%d", "published")
    check_size(sdn_body, spec, names[0])
    cs = Countries(data_dir)
    notes: list = ["SDN.CSV has no nationality field: nationality and citizenship links come only from SDN.XML"]
    addr: dict = {}
    files = {names[0]: sha256(sdn_body)}
    if add_body is not None:
        check_size(add_body, spec, names[1])
        files[names[1]] = sha256(add_body)
        for r in _rows(add_body, len(ADD_CSV_COLUMNS), names[1]):
            if r[4]:
                addr.setdefault(r[0], []).append(r[4])
    entries = []
    for r in _rows(sdn_body, len(SDN_CSV_COLUMNS), names[0]):
        uid, nm, raw_type, prog, vflag, remarks = r[0], r[1], r[2], r[3], r[9], r[11]
        etype = "entity" if not raw_type else SDN_TYPES.get(raw_type.casefold())
        if etype is None:
            raise LayoutError(f"{names[0]}: entry {uid}: SDN_Type {raw_type!r} not in {sorted(SDN_TYPES)}")
        progs = tuple(p.strip() for p in prog.split("] [") if p.strip()) if prog else ()
        links = [("address", cs.name(c), c) for c in addr.get(uid, [])]
        if vflag:
            links.append(("flag", cs.name(vflag), vflag))
        links += _programme_links(progs, cs, notes)
        cb, so = flags(nm, etype, remarks)
        entries.append(Entry("ofac_sdn", uid, etype, nm, progs, "", links, cb, so))
    return finish("ofac_sdn", published, entries, files, cs, sorted(set(notes)))
