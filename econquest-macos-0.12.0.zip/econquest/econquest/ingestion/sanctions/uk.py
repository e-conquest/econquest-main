"""UK OFSI Consolidated List adapter, ConList.csv (EQ-A-0133).

Layout (OFSI "2022 format" CSV, UNVERIFIED against a downloaded file): the first line is "Last Updated,DD/MM/YYYY", the
second is the header, and every following row is one name of one designation. Rows are grouped by "Group ID", which
is the entry id. Columns used: Name 6 (surname or entity name), Name 1 to Name 5, Group Type (Individual, Entity,
Ship), Regime, Listed On (DD/MM/YYYY, the listing date), Nationality (may hold several, "(1) X (2) Y"), Country of
Birth, Country (address) and Other Information. The publication date is the "Last Updated" date.

UNVERIFIED: OFSI announced that the FCDO UK Sanctions List becomes the single source of UK designations. Before
relying on this list, check on the Mac whether ConList.csv is still published (docs/runbooks/A-sanctions.md). That
list's format is different and needs its own parser.
"""
from __future__ import annotations

import csv
import io
import re

from .base import LIST_SPECS, Countries, Entry, LayoutError, ParseResult, check_size, finish, flags, iso_date, sha256

GROUP_TYPES = {"individual": "individual", "entity": "entity", "ship": "vessel"}
NEEDED = ["Name 6", "Group Type", "Regime", "Listed On", "Nationality", "Country of Birth", "Country",
          "Other Information", "Alias Type", "Group ID"]
_MULTI = re.compile(r"\(\d+\)")


def _split(v: str) -> list[str]:
    parts = [p.strip(" ,;") for p in _MULTI.split(v or "")]
    return [p for p in parts if p]


def parse(body: bytes, name: str = "ConList.csv", data_dir=None) -> ParseResult:
    spec = LIST_SPECS["uk_ofsi"]
    check_size(body, spec, name)
    try:
        text = body.decode("utf-8-sig")
    except UnicodeDecodeError:
        text = body.decode("latin-1")
    try:
        rows = list(csv.reader(io.StringIO(text)))
    except csv.Error as e:                       # SEC-A-015 S-I1: e.g. a field over the csv module's 128 KiB limit
        raise LayoutError(f"{name}: not readable CSV ({str(e)[:120]})") from None
    if len(rows) < 2 or not rows[0] or rows[0][0].strip().casefold() != "last updated":
        raise LayoutError(f"{name}: first line is not 'Last Updated,DD/MM/YYYY' (OFSI 2022 format)")
    published = iso_date(rows[0][1] if len(rows[0]) > 1 else "", "%d/%m/%Y", f"{name} Last Updated")
    header = [h.strip() for h in rows[1]]
    miss = [c for c in NEEDED if c not in header]
    if miss:
        raise LayoutError(f"{name}: missing column(s) {miss}; found {header[:40]}")
    ix = {c: header.index(c) for c in header}
    cs = Countries(data_dir)
    groups: dict = {}
    for n, r in enumerate(rows[2:], start=3):
        if not r or all(not c.strip() for c in r):
            continue
        if len(r) != len(header):
            raise LayoutError(f"{name}: line {n} has {len(r)} fields, header has {len(header)}")
        groups.setdefault(r[ix["Group ID"]].strip(), []).append({c: r[i].strip() for c, i in ix.items()})
    entries, notes = [], []
    for gid, rs in groups.items():
        prim = [x for x in rs if x["Alias Type"].casefold().startswith("primary")] or rs
        p = prim[0]
        gt = p["Group Type"].casefold()
        etype = GROUP_TYPES.get(gt)
        if etype is None:
            raise LayoutError(f"{name}: group {gid}: Group Type {p['Group Type']!r} not in {sorted(GROUP_TYPES)}")
        names = [p.get(f"Name {i}", "") for i in (1, 2, 3, 4, 5)] + [p["Name 6"]]
        nm = " ".join(x for x in names if x)
        regimes = tuple(sorted({x["Regime"] for x in rs if x["Regime"]}))
        listed = sorted({iso_date(x["Listed On"], "%d/%m/%Y", f"{name} group {gid} Listed On")
                         for x in rs if x["Listed On"]})
        links = set()
        for x in rs:
            for c in _split(x["Nationality"]):
                links.add(("nationality", cs.name(c), c))
            if x["Country of Birth"]:
                links.add(("birth", cs.name(x["Country of Birth"]), x["Country of Birth"]))
            if x["Country"]:
                links.add(("address", cs.name(x["Country"]), x["Country"]))
        for reg in regimes:
            iso = cs.programme(reg)
            if iso:
                links.add(("programme", iso, reg))
            else:
                notes.append(f"regime {reg} names no country (no programme link)")
        cb, so = flags(nm, etype, " ".join(x["Other Information"] for x in rs))
        entries.append(Entry("uk_ofsi", gid, etype, nm, regimes, listed[0] if listed else "", sorted(links), cb, so))
    return finish("uk_ofsi", published, entries, {name: sha256(body)}, cs, sorted(set(notes)))
