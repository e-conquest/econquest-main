"""Command line for the sanctions store (EQ-A-0133). Offline except `fetch`, which runs on Sam's Mac.

    python -m econquest.ingestion.sanctions lists
    python -m econquest.ingestion.sanctions ingest LIST [FILE ...] [--published YYYY-MM-DD] [--data data]
    python -m econquest.ingestion.sanctions fetch LIST [--format xml|csv] [--data data]          # Mac only
    python -m econquest.ingestion.sanctions snapshots LIST [--data data]
    python -m econquest.ingestion.sanctions exposure --as-of YYYY-MM-DD [--data data] [--programmes]

`ingest` with no FILE reads data/sanctions/drop/LIST/. `exposure` prints CSV to stdout and writes nothing.
"""
from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

from . import exposure as exp
from . import store
from .base import LIST_SPECS, fetch_bytes


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.sanctions")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("lists")
    p = sub.add_parser("ingest")
    p.add_argument("list", choices=sorted(LIST_SPECS))
    p.add_argument("files", nargs="*")
    p.add_argument("--published", help="publication date for the OFAC CSV pair (the files carry none)")
    p.add_argument("--data", default="data")
    p = sub.add_parser("fetch")
    p.add_argument("list", choices=sorted(LIST_SPECS))
    p.add_argument("--format", default="xml", choices=("xml", "csv"))
    p.add_argument("--published", help="needed with --format csv for ofac_sdn")
    p.add_argument("--data", default="data")
    p = sub.add_parser("snapshots")
    p.add_argument("list", choices=sorted(LIST_SPECS))
    p.add_argument("--data", default="data")
    p = sub.add_parser("exposure")
    p.add_argument("--as-of", required=True)
    p.add_argument("--data", default="data")
    p.add_argument("--programmes", action="store_true", help="print the per-programme table instead of the counts")
    a = ap.parse_args(argv)

    if a.cmd == "lists":
        for k, s in LIST_SPECS.items():
            print(f"{k:10s} {s.fetch_mode:7s} {', '.join(s.formats):8s} {s.name}")
        return 0
    if a.cmd == "ingest":
        files = {Path(f).name: Path(f).read_bytes() for f in a.files} if a.files else None
        res, path = store.ingest(a.data, a.list, files, published=a.published)
        print(json.dumps({"snapshot": str(path), "entries": len(res.entries), "unmapped": res.unmapped[:20],
                          "notes": res.notes[:20]}, indent=1))
        return 0
    if a.cmd == "fetch":
        spec = LIST_SPECS[a.list]
        files = {Path(spec.urls[a.format]).name: fetch_bytes(spec, a.format)}
        if a.list == "ofac_sdn" and a.format == "csv":
            files[Path(spec.urls["csv_add"]).name] = fetch_bytes(spec, "csv_add")
        res, path = store.ingest(a.data, a.list, files, published=a.published, url=spec.urls[a.format])
        print(json.dumps({"snapshot": str(path), "entries": len(res.entries), "unmapped": res.unmapped[:20]},
                         indent=1))
        return 0
    if a.cmd == "snapshots":
        for m in store.list_snapshots(a.data, a.list):
            print(f"{m['publication_date']}  {m['sha256'][:16]}  entries {m['entries']}  retrieved {m['retrieved_utc']}")
        return 0
    if a.cmd == "exposure":
        out = exp.exposure(a.data, a.as_of)
        for k, v in out["lists"].items():
            print(f"# {k}: {v}", file=sys.stderr)
        (out["programmes"] if a.programmes else out["counts"]).to_csv(sys.stdout, index=False)
        return 0
    return 2


if __name__ == "__main__":
    sys.exit(main())
