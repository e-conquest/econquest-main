"""Sanctions exposure counts per desk country and per programme (EQ-A-0133), computed on demand from the store.

For each list, the snapshot in force on as_of (store.snapshot_as_of) is counted per desk country (ISO3):

    entries_linked        distinct entries with any link to the country (nationality, citizenship, address, birth,
                          flag or programme)
    linked_<type>         distinct entries by link type: nationality (nationality or citizenship), address, birth,
                          flag, programme
    individuals_linked, entities_linked, vessels_linked (vessels and aircraft)
    central_bank_linked   linked entities whose name matches base.CENTRAL_BANK_RE (a text flag, lower bound)
    state_owned_linked    linked entities whose list remark matches base.STATE_OWNED_RE (a text flag, lower bound)
    listed_12m            linked entries whose listing date falls in the 365 days up to as_of (lists that give a date)

A list with no snapshot on or before as_of gives NO rows for any country. It is reported as missing, never as 0.
A country with no link on a list that has a snapshot gives 0, read from that list.

Indicator candidate: `candidate_rows` emits these counts as research long rows with kind "input" (research.base
LONG_COLUMNS), proposed for 4.10 (geopolitical position and outside pressure) and, for OFAC, 2.7 (access to the
dollar banking system). Inputs never reach indicators.csv: a desk cell needs a Team B level rule first (handoff
proposed under EQ-A-0133). Until that rule exists the cells are held.
"""
from __future__ import annotations

import datetime as dt
from pathlib import Path

import pandas as pd

from . import store
from .base import LICENCE_TAG, LIST_KEYS, LIST_SPECS

METRICS = ("entries_linked", "linked_nationality", "linked_address", "linked_birth", "linked_flag",
           "linked_programme", "individuals_linked", "entities_linked", "vessels_linked", "central_bank_linked",
           "state_owned_linked", "listed_12m")
COUNT_COLUMNS = ["as_of", "list", "publication_date", "snapshot_sha256", "iso3", "metric", "value"]
PROGRAMME_COLUMNS = ["as_of", "list", "publication_date", "iso3", "programme", "entries"]
CANDIDATE_METRICS = ("entries_linked", "entities_linked", "central_bank_linked", "state_owned_linked")
CANDIDATE_INDICATORS = {"ofac_sdn": ("2.7", "4.10"), "ofac_cons": ("2.7", "4.10"), "eu_fsf": ("4.10",),
                        "uk_ofsi": ("4.10",), "un_sc": ("4.10",)}


def desk_countries(data_dir: str | Path | None = None) -> list[str]:
    from econquest.ingestion.research.base import REPO_DATA
    p = Path(data_dir) / "countries.csv" if data_dir and (Path(data_dir) / "countries.csv").is_file() \
        else REPO_DATA / "countries.csv"
    return sorted(pd.read_csv(p, dtype=str, usecols=["iso"])["iso"].str.strip().str.upper())


def exposure(data_dir: str | Path, as_of: str, countries: list[str] | None = None,
             lists: tuple = LIST_KEYS) -> dict:
    """{"counts": DataFrame COUNT_COLUMNS, "programmes": DataFrame PROGRAMME_COLUMNS, "lists": {list: status}}."""
    isos = countries or desk_countries(data_dir)
    start = (dt.date.fromisoformat(as_of) - dt.timedelta(days=365)).isoformat()
    counts, progs, status = [], [], {}
    for key in lists:
        meta = store.snapshot_as_of(data_dir, key, as_of)
        if meta is None:
            status[key] = "missing: no snapshot published on or before as_of"
            continue
        status[key] = f"snapshot {meta['publication_date']} ({meta['sha256'][:16]})"
        entries, links = store.read_snapshot(meta)
        ent = {e["entry_id"]: e for e in entries}
        by_iso: dict = {}
        for lk in links:
            if lk["iso3"]:
                by_iso.setdefault(lk["iso3"], []).append(lk)
        for iso in isos:
            lks = by_iso.get(iso, [])
            ids = {lk["entry_id"] for lk in lks}

            def n_type(*types, lks=lks):
                return len({lk["entry_id"] for lk in lks if lk["link_type"] in types})

            linked = [ent[i] for i in ids if i in ent]
            vals = {
                "entries_linked": len(ids),
                "linked_nationality": n_type("nationality", "citizenship"),
                "linked_address": n_type("address"), "linked_birth": n_type("birth"), "linked_flag": n_type("flag"),
                "linked_programme": n_type("programme"),
                "individuals_linked": sum(e["entity_type"] == "individual" for e in linked),
                "entities_linked": sum(e["entity_type"] == "entity" for e in linked),
                "vessels_linked": sum(e["entity_type"] in ("vessel", "aircraft") for e in linked),
                "central_bank_linked": sum(e["central_bank"] == "1" for e in linked),
                "state_owned_linked": sum(e["state_owned"] == "1" for e in linked),
                "listed_12m": sum(bool(e["listing_date"]) and start < e["listing_date"] <= as_of for e in linked),
            }
            for m in METRICS:
                counts.append([as_of, key, meta["publication_date"], meta["sha256"], iso, m, int(vals[m])])
            per: dict = {}
            for e in linked:
                for p in [x for x in e["programmes"].split("; ") if x]:
                    per[p] = per.get(p, 0) + 1
            for p, n in sorted(per.items()):
                progs.append([as_of, key, meta["publication_date"], iso, p, n])
    return {"counts": pd.DataFrame(counts, columns=COUNT_COLUMNS),
            "programmes": pd.DataFrame(progs, columns=PROGRAMME_COLUMNS), "lists": status}


def candidate_spec():
    from econquest.ingestion.research.base import DatasetSpec
    inds = tuple(sorted({i for v in CANDIDATE_INDICATORS.values() for i in v}))
    return DatasetSpec(key="sanctions_exposure", name="Sanctions exposure counts (OFAC, EU, UK, UN public lists)",
                       indicators=inds, licence=LICENCE_TAG, client_ok=False, fetch_mode="manual",
                       terms_url=LIST_SPECS["ofac_sdn"].terms_url, attribution="OFAC; EU FSF; UK OFSI; UN SC",
                       notes="EQ-A-0133 indicator candidate: kind input only; needs a Team B level rule")


def candidate_rows(counts: pd.DataFrame) -> pd.DataFrame:
    """Research long rows (kind "input") for Team B's proposed level rule. year = the snapshot's publication year;
    vintage names the list, publication date and snapshot hash. Never written into indicators.csv."""
    from econquest.ingestion.research.base import make_rows
    spec = candidate_spec()
    recs, vint = [], []
    for r in counts.itertuples(index=False):
        if r.metric not in CANDIDATE_METRICS:
            continue
        for ind in CANDIDATE_INDICATORS[r.list]:
            recs.append({"indicator": ind, "iso3": r.iso3, "year": int(r.publication_date[:4]), "value": float(r.value),
                         "metric": f"sanctions_{r.list}_{r.metric}", "kind": "input"})
            vint.append(f"{r.list} {r.publication_date}; sha256:{r.snapshot_sha256[:16]}")
    if not recs:
        return make_rows([], spec, "", "")
    vintage = " | ".join(sorted(set(vint)))
    return make_rows(recs, spec, "public sanctions lists via econquest.ingestion.sanctions (EQ-A-0133)", vintage)
