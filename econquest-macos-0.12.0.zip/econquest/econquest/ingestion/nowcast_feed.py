"""Nowcast inputs feed (EQ-A-0057, answers HO-20261024-B-A-001 from Team B / EQ-B-0071).

Writes data/live/nowcast_inputs.csv to the input contract in docs/validation/nowcast.md (section "Input contract"):
one long CSV, one row per country, series, period and release, never overwritten. Runs on Sam's Mac; this cloud cannot
reach the publishers, and no value is ever written here except from a real pull.

Pieces (each offline-testable):
    series map     data/live/nowcast_series_map.csv: one row per (source, nowcast series) with the SDMX flow, key and
                   dimension filters, the transform, a precedence rank, the publisher's usual release lag (days after
                   period end, used only for `estimated_lag` history) and `verified`. Every code starts UNVERIFIED
                   (verified=no). Written from DEFAULT_MAP by `plan --write-map`; changed only with `map-set`.
    adapters       IMF SDMX 3.0 (official.imf.ImfSdmxFeed), OECD Data Explorer SDMX (official.oecd.OecdFeed) and BIS
                   SDMX (BisNowcastFeed below, an official.sdmx.SdmxFeed). EQ-A-0119: national sources with no key
                   (nowcast_national: bcb_sgs BRA, bcrp PER, datos_ar ARG, dosm MYS), one country each. Same transport (sources.https_get: https
                   only, no redirects, byte cap), retry and fail-fast rules, and the same SDMX-CSV parser that refuses
                   any row whose dimensions differ from the ones asked for.
    transform      levels -> % y/y from the same vintage (month t over t-12, quarter t over t-4, both > 0); UNEMP as a
                   level; `yoy_published` (EQ-A-0119) keeps a series the publisher already gives as % y/y. Rounded to
                   4 decimals.
    vintages       every fetch is archived read-only under data/live/nowcast_vintages/<UTC ts>-<hash8>/ (raw tables
                   with the licence tag, the transformed table, fetch.json), never overwritten.
    release dates  replayed from the archive in fetch order (`replay`): a value seen for the first time in the first
                   fetch of its (country, series) is history from a latest-vintage-only source, dated period end + the
                   usual lag and marked `estimated_lag` (or the fetch date, `fetched`, when that estimate would not be
                   earlier than the fetch); a new period or a changed value in a later fetch gets the fetch date
                   (`fetched`). An unchanged value adds no row. `official` is used only when a raw table carries a
                   publisher release date (none of the SDMX adapters does today). Two fetches on the same UTC date:
                   the later one is that day's view.
    merge          append-only into nowcast_inputs.csv: existing rows are kept as they are; a new row whose (iso3,
                   series, period, release_date) already exists with the same value is skipped; with a different value
                   the merge stops and writes nothing. The result must pass Team B's validator (`python -m
                   econquest.engine.nowcast validate`, run as its own command: ingestion does not import engine)
                   on a staged copy before it replaces the file.
    eligibility    only series whose map row is verified=yes are merged into data/live/nowcast_inputs.csv. A trial
                   file with unverified codes can be written elsewhere (`merge --include-unverified --out PATH`).

Coverage: the 25 names of engine.nowcast.top_names. Required GDP_YOY (Q), CPI_YOY, IP_YOY, EXP_YOY, IMP_YOY,
CREDIT_YOY; optional RETAIL_YOY, UNEMP, PPI_YOY, CORE_CPI_YOY. VEN, ZWE, BLZ, ZMB and SEN get CPI and trade only.
PMI_MFG is licensed and not licensed here: the map refuses it.

Licences: IMF rows carry official.IMF_LICENCE ("IMF: internal research use only", Sam 2026-10-24) in the `licence`
column of the raw vintage tables and of nowcast_inputs.csv, so audit.client_output_reason keeps them out of client
output. The nowcast module is internal research (off by default), so the data stays internal.

Command line:
    python -m econquest.ingestion.nowcast_feed plan    [--data D] [--write-map] [--add-defaults]
    python -m econquest.ingestion.nowcast_feed fetch   [--data D] [--sources imf,oecd,bis] [--names top|ISO,ISO]
    python -m econquest.ingestion.nowcast_feed merge   [--data D] [--include-unverified --out PATH]
    python -m econquest.ingestion.nowcast_feed status  [--data D]
    python -m econquest.ingestion.nowcast_feed map-set MAP_ID [--flow F] [--key K] [--filters D=C;D=C] [--lag-days N]
                                                       [--priority N] [--verified yes|no --by NAME --evidence TEXT]
`fetch` probes every source host first and stops, writing nothing, when none answers (offline)."""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import os
import re
import subprocess  # nosec B404 - runs this interpreter on Team B's own CLI, fixed arguments
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Iterable

import numpy as np
import pandas as pd

from . import feeds as F
from .official import IMF_LICENCE, OECD_LICENCE
from .official.imf import IMF_SPECS, ImfSdmxFeed
from .official.oecd import OecdFeed
from .official.sdmx import RAW_COLUMNS, SdmxFeed, SeriesSpec, scaled
from . import nowcast_national as NN
from .sources import read_csv_keep_na_code

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_DATA = ROOT / "data"
INPUTS_NAME = "nowcast_inputs.csv"
MAP_NAME = "nowcast_series_map.csv"
VINTAGE_DIR = "nowcast_vintages"

REQUIRED_SERIES = ("GDP_YOY", "CPI_YOY", "IP_YOY", "EXP_YOY", "IMP_YOY", "CREDIT_YOY")
OPTIONAL_SERIES = ("RETAIL_YOY", "UNEMP", "PPI_YOY", "CORE_CPI_YOY")
UNLICENSED_SERIES = ("PMI_MFG",)             # licensed indicator; no licence held (Team B handoff: only if licensed)
CPI_TRADE_ONLY = frozenset({"VEN", "ZWE", "BLZ", "ZMB", "SEN"})
CPI_TRADE_SERIES = ("CPI_YOY", "EXP_YOY", "IMP_YOY")
MIN_MONTHS = 36                              # contract "History": 36 months per monthly series
MIN_QUARTERS = 13                            # and 13 quarters of GDP

# The contract, copied from engine/nowcast.py (Team B, docs/validation/nowcast.md). Ingestion is a lower layer and must
# not import engine (EQ-A-0001, tests/test_ingestion_layering.py), so the codes are repeated here and
# tests/test_nowcast_feed.py fails if they drift from nowcast.SERIES / INPUT_COLUMNS. Team B's validator itself is run
# as its own command (`python -m econquest.engine.nowcast validate`) on every file before it is written.
CONTRACT_COLUMNS = ["iso3", "series", "freq", "period", "value", "release_date", "source"]
CONTRACT_OPTIONAL_COLUMNS = ["release_date_basis", "unit", "notes"]       # nowcast.OPTIONAL_COLUMNS
CONTRACT_SERIES = {"GDP_YOY": ("Q", "pct_yoy"), "CPI_YOY": ("M", "pct_yoy"), "CORE_CPI_YOY": ("M", "pct_yoy"),
                   "PPI_YOY": ("M", "pct_yoy"), "IP_YOY": ("M", "pct_yoy"), "RETAIL_YOY": ("M", "pct_yoy"),
                   "PMI_MFG": ("M", "index"), "UNEMP": ("M", "pct"), "EXP_YOY": ("M", "pct_yoy"),
                   "IMP_YOY": ("M", "pct_yoy"), "CREDIT_YOY": ("M", "pct_yoy")}
_PERIOD_RE = {"M": re.compile(r"^\d{4}-(0[1-9]|1[0-2])$"), "Q": re.compile(r"^\d{4}-Q[1-4]$")}
NOWCAST_MODULE = "econquest.engine.nowcast"
DECIMALS = 4

BIS_LICENCE = "BIS terms: free reuse with attribution (unverified) https://www.bis.org/terms_conditions.htm"
LICENCES = {"imf": IMF_LICENCE, "oecd": OECD_LICENCE, "bis": BIS_LICENCE, **NN.LICENCES}
HOSTS = {"imf": "api.imf.org", "oecd": "sdmx.oecd.org", "bis": "stats.bis.org", **NN.HOSTS}
SOURCES = tuple(HOSTS)
TRANSFORMS = ("yoy", "yoy_published", "level")
RELEASE_BASES = ("official", "fetched", "estimated_lag")

INPUT_ORDER = [*CONTRACT_COLUMNS, *CONTRACT_OPTIONAL_COLUMNS, "licence", "map_id"]
TRANSFORMED_COLUMNS = ["iso3", "series", "freq", "period", "value", "source", "map_id", "licence", "sdmx_key",
                       "official_release_date"]
MAP_COLUMNS = ["map_id", "series", "source", "flow", "key", "filters", "freq", "transform", "priority",
               "est_lag_days", "verified", "verified_by", "verified_on", "evidence", "candidate"]

# ---------------------------------------------------------------------------------------------- default series map
# Every flow, key and code below is UNVERIFIED: written from the publishers' API pages as remembered, never checked
# against a live answer (this cloud cannot reach api.imf.org, sdmx.oecd.org or stats.bis.org). A blank `filters`
# means the codes are not known at all: the row is never requested until `map-set` fills it after a structure check
# on the Mac. est_lag_days is the publisher's usual lag after period end, an assumption on the long side (a longer lag
# can only make estimated_lag history later, never earlier than the real release); it is used only for history the
# first fetch finds, and the runbook asks for it to be checked against the publishers' calendars.
_LAG = {"CPI_YOY": 30, "CORE_CPI_YOY": 30, "PPI_YOY": 30, "IP_YOY": 50, "RETAIL_YOY": 50, "UNEMP": 50,
        "EXP_YOY": 50, "IMP_YOY": 50, "CREDIT_YOY": 50, "GDP_YOY": 75}
_IMF_CPI_FILTERS = IMF_SPECS["cpi_index"].filters      # official.imf: CPI, all items, index, monthly (UNVERIFIED)
_OECD_PRICES = "OECD.SDD.TPS,DSD_PRICES@DF_PRICES_ALL,1.0"


def _f(*pairs) -> str:
    return ";".join(f"{d}={c}" for d, c in pairs)


def _row(map_id, series, source, flow, key, filters, transform, priority, candidate):
    return {"map_id": map_id, "series": series, "source": source, "flow": flow, "key": key or "", "filters": filters,
            "freq": CONTRACT_SERIES[series][0], "transform": transform, "priority": priority, "est_lag_days": _LAG[series],
            "verified": "no", "verified_by": "", "verified_on": "", "evidence": "", "candidate": candidate}


DEFAULT_MAP = [
    # CPI: BIS long series first (index levels, long history), then OECD, then IMF
    _row("bis_cpi", "CPI_YOY", "bis", "WS_LONG_CPI", "M.{area}.628", _f(("FREQ", "M"), ("UNIT_MEASURE", "628")), "yoy", 1,
         "BIS long CPI series, unit 628 = index 2010=100 (771 would be y/y %); ISO2 areas; UNVERIFIED"),
    _row("oecd_cpi", "CPI_YOY", "oecd", _OECD_PRICES, "{area}.M.N.CPI.IX._T.N._Z",
         _f(("FREQ", "M"), ("METHODOLOGY", "N"), ("MEASURE", "CPI"), ("UNIT_MEASURE", "IX"), ("EXPENDITURE", "_T"),
            ("ADJUSTMENT", "N"), ("TRANSFORMATION", "_Z")), "yoy", 2,
         "OECD Data Explorer prices dataflow (successor of MEI), CPI all items index, not SA; UNVERIFIED"),
    _row("imf_cpi", "CPI_YOY", "imf", "CPI", "", _f(*_IMF_CPI_FILTERS), "yoy", 3,
         "same spec as official.imf cpi_index (new-portal CPI dataflow); UNVERIFIED"),
    _row("oecd_core_cpi", "CORE_CPI_YOY", "oecd", _OECD_PRICES, "{area}.M.N.CPI.IX._TXCP01_NRG.N._Z",
         _f(("FREQ", "M"), ("METHODOLOGY", "N"), ("MEASURE", "CPI"), ("UNIT_MEASURE", "IX"),
            ("EXPENDITURE", "_TXCP01_NRG"), ("ADJUSTMENT", "N"), ("TRANSFORMATION", "_Z")), "yoy", 1,
         "OECD prices dataflow, all items less food and energy; national core definitions differ; UNVERIFIED"),
    _row("imf_core_cpi", "CORE_CPI_YOY", "imf", "CPI", "", "", "yoy", 2,
         "new-portal CPI dataflow; core index code unknown"),
    # trade: IMF IMTS (merchandise trade, USD, world counterpart)
    _row("imf_exp", "EXP_YOY", "imf", "IMTS", "",
         _f(("INDICATOR", "XG_FOB_USD"), ("COUNTERPART_COUNTRY", "G001"), ("FREQUENCY", "M")), "yoy", 1,
         "IMTS exports FOB USD to the world; legacy DOTS code TXG_FOB_USD, counterpart W00; UNVERIFIED"),
    _row("imf_imp", "IMP_YOY", "imf", "IMTS", "",
         _f(("INDICATOR", "MG_CIF_USD"), ("COUNTERPART_COUNTRY", "G001"), ("FREQUENCY", "M")), "yoy", 1,
         "IMTS imports CIF USD from the world; legacy DOTS code TMG_CIF_USD, counterpart W00; UNVERIFIED"),
    # codes not known from here: never requested until map-set fills them after a structure check on the Mac
    _row("oecd_gdp", "GDP_YOY", "oecd", "", "", "", "yoy", 1,
         "OECD quarterly national accounts, GDP chain-linked volume (DF_QNA); dataflow and key unknown"),
    _row("imf_gdp", "GDP_YOY", "imf", "QNEA", "", "", "yoy", 2,
         "new-portal QNEA real GDP volume; legacy IFS NGDP_R_XDC; codes unknown"),
    _row("oecd_ip", "IP_YOY", "oecd", "", "", "", "yoy", 1,
         "OECD short-term indicators, production volume index, industry (DF_INDSERV); key unknown"),
    _row("imf_ip", "IP_YOY", "imf", "", "", "", "yoy", 2,
         "legacy IFS AIP_IX (industrial production index); new-portal dataflow unknown"),
    _row("imf_credit", "CREDIT_YOY", "imf", "", "", "", "yoy", 1,
         "MFS depository corporations survey, claims on private sector (national currency); legacy IFS "
         "FDSAOP_XDC; dataflow and code unknown"),
    _row("oecd_retail", "RETAIL_YOY", "oecd", "", "", "", "yoy", 1,
         "OECD short-term indicators, retail trade volume; key unknown"),
    _row("oecd_unemp", "UNEMP", "oecd", "", "", "", "level", 1,
         "OECD monthly unemployment rate (DF_IALFS_UNE_M); key unknown"),
    _row("imf_unemp", "UNEMP", "imf", "", "", "", "level", 2, "legacy IFS LUR_PT; new-portal dataflow unknown"),
    _row("oecd_ppi", "PPI_YOY", "oecd", "", "", "", "yoy", 1, "OECD producer prices (DF_PRICES_PPI?); key unknown"),
    _row("imf_ppi", "PPI_YOY", "imf", "PPI", "", "", "yoy", 2, "new-portal PPI dataflow; legacy IFS PPPI_IX; codes unknown"),
    # EQ-A-0119: national sources (nowcast_national), one country each, no key. Codes as remembered from the
    # publishers' catalogues, UNVERIFIED; blank filters = code not known here, never requested. Priority after the
    # existing rows of the same series, so a national row fills a gap and never displaces BIS / OECD / IMF until
    # someone changes the priority with map-set (a precedence choice, not made here).
    _row("bcb_cpi", "CPI_YOY", "bcb_sgs", "SGS IPCA", "", _f(("SERIES", "13522")), "yoy_published", 4,
         "BCB SGS 13522 IPCA 12-month change %, same code as official.central_banks BRA cpi; UNVERIFIED"),
    _row("bcb_ip", "IP_YOY", "bcb_sgs", "SGS PIM-PF", "", _f(("SERIES", "21859")), "yoy", 3,
         "BCB SGS 21859 industrial production, general industry, index (IBGE PIM-PF, not SA) as remembered; "
         "UNVERIFIED code and base"),
    _row("bcb_credit", "CREDIT_YOY", "bcb_sgs", "SGS credit", "", _f(("SERIES", "20539")), "yoy", 2,
         "BCB SGS 20539 credit operations outstanding, total, R$ mn (households + firms; not only private) as "
         "remembered; UNVERIFIED code and coverage"),
    _row("bcb_unemp", "UNEMP", "bcb_sgs", "SGS PNADC", "", _f(("SERIES", "24369")), "level", 3,
         "BCB SGS 24369 unemployment rate, PNAD Continua rolling quarter, % as remembered; UNVERIFIED code"),
    _row("bcb_gdp", "GDP_YOY", "bcb_sgs", "SGS GDP", "", "", "yoy", 3,
         "BCB SGS quarterly real GDP index (IBGE QNA): code not known here"),
    _row("bcrp_cpi", "CPI_YOY", "bcrp", "BCRPData CPI", "", _f(("SERIES", "PN01273PM")), "yoy_published", 4,
         "BCRP PN01273PM CPI Lima Metropolitana 12-month change %, same code as official.central_banks PER cpi; "
         "UNVERIFIED"),
    _row("bcrp_credit", "CREDIT_YOY", "bcrp", "BCRPData credit", "", "", "yoy", 2,
         "BCRP credit to the private sector (depository corporations), monthly: code not known here"),
    _row("bcrp_ip", "IP_YOY", "bcrp", "BCRPData production", "", "", "yoy", 3,
         "BCRP / INEI manufacturing or national production index, monthly: code not known here"),
    _row("ar_cpi", "CPI_YOY", "datos_ar", "INDEC IPC", "", _f(("SERIES", "148.3_INIVELNAL_DICI_M_26")), "yoy", 4,
         "datos.gob.ar 148.3_INIVELNAL_DICI_M_26 INDEC CPI national level, index Dec-2016=100 as remembered; "
         "UNVERIFIED id"),
    _row("ar_ip", "IP_YOY", "datos_ar", "INDEC IPI", "", "", "yoy", 3,
         "datos.gob.ar INDEC IPI manufacturero index: id not known here"),
    _row("ar_gdp", "GDP_YOY", "datos_ar", "INDEC QNA", "", "", "yoy", 3,
         "datos.gob.ar INDEC quarterly GDP at constant prices: id not known here"),
    _row("dosm_cpi", "CPI_YOY", "dosm", "OpenDOSM cpi_headline", "",
         _f(("DATASET", "cpi_headline"), ("VALUE", "index"), ("division", "overall")), "yoy", 4,
         "OpenDOSM data catalogue cpi_headline, division overall, field index (2010=100) as remembered; "
         "UNVERIFIED dataset id and field names"),
    _row("dosm_ip", "IP_YOY", "dosm", "OpenDOSM ipi", "", "", "yoy", 3,
         "OpenDOSM industrial production index dataset: id and fields not known here"),
    _row("dosm_unemp", "UNEMP", "dosm", "OpenDOSM lfs_month", "", _f(("DATASET", "lfs_month"), ("VALUE", "u_rate")),
         "level", 3, "OpenDOSM lfs_month monthly labour force survey, field u_rate % as remembered; UNVERIFIED"),
]


class FeedRefused(RuntimeError):
    """fetch / merge stopped before writing (offline, no rows, merge conflict, contract failure, bad map)."""


class MergeStopped(FeedRefused):
    """fetch archived its vintage, but the merge into nowcast_inputs.csv stopped (a failure to look at, not a skip)."""


# ---------------------------------------------------------------------------------------------- paths and map
def paths(data_dir: str | Path) -> dict:
    live = Path(data_dir) / "live"
    return {"live": live, "inputs": live / INPUTS_NAME, "map": live / MAP_NAME, "vintages": live / VINTAGE_DIR}


def default_map() -> pd.DataFrame:
    return pd.DataFrame(DEFAULT_MAP, columns=MAP_COLUMNS)


def parse_filters(text: str) -> tuple | None:
    """'DIM=CODE;DIM=CODE' -> ((DIM, CODE), ...); blank -> None (not configured)."""
    text = str(text or "").strip()
    if not text:
        return None
    out = []
    for part in text.split(";"):
        d, sep, c = part.partition("=")
        if not sep or not d.strip() or not c.strip():
            raise ValueError(f"filter {part!r} is not DIM=CODE")
        out.append((d.strip(), c.strip()))
    return tuple(out)


def check_map(m: pd.DataFrame) -> list[str]:
    """Problems with a series map (empty = usable)."""
    miss = [c for c in MAP_COLUMNS if c not in m.columns]
    if miss:
        return [f"series map lacks columns {miss}"]
    probs = []
    if m["map_id"].duplicated().any():
        probs.append(f"duplicate map_id {sorted(m.loc[m['map_id'].duplicated(), 'map_id'])}")
    for r in m.to_dict("records"):
        mid, s = r["map_id"], r["series"]
        if s in UNLICENSED_SERIES:
            probs.append(f"{mid}: {s} is a licensed series and no licence is held; remove the row")
        elif s not in CONTRACT_SERIES:
            probs.append(f"{mid}: unknown series {s!r}")
        else:
            if r["freq"] != CONTRACT_SERIES[s][0]:
                probs.append(f"{mid}: freq {r['freq']} but {s} is {CONTRACT_SERIES[s][0]}")
            want = ("yoy", "yoy_published") if s.endswith("_YOY") else ("level",)
            if r["transform"] not in want:
                probs.append(f"{mid}: transform {r['transform']!r}, {s} needs {' or '.join(repr(w) for w in want)}")
        if r["source"] not in SOURCES:
            probs.append(f"{mid}: source {r['source']!r} not in {SOURCES}")
        try:
            filt = parse_filters(r["filters"])
        except ValueError as e:
            probs.append(f"{mid}: {e}")
            filt = None
        if filt is not None and not str(r["flow"]).strip():
            probs.append(f"{mid}: filters set but no flow")
        if filt is not None and r["source"] in ("oecd", "bis") and "{area}" not in str(r["key"]):
            probs.append(f"{mid}: {r['source']} needs a key with {{area}}")
        if r["source"] in NN.NATIONAL:
            probs += NN.check_row(r)
        if str(r["verified"]) not in ("yes", "no"):
            probs.append(f"{mid}: verified must be yes or no")
        if str(r["verified"]) == "yes" and filt is None:
            probs.append(f"{mid}: verified=yes but no codes configured")
        try:
            if int(r["est_lag_days"]) < 1 or int(r["priority"]) < 1:
                probs.append(f"{mid}: est_lag_days and priority must be >= 1")
        except (TypeError, ValueError):
            probs.append(f"{mid}: est_lag_days and priority must be whole numbers")
    return probs


def load_map(data_dir: str | Path) -> pd.DataFrame:
    """The series map from data/live; the default map (all UNVERIFIED) when the file does not exist yet."""
    p = paths(data_dir)["map"]
    m = read_csv_keep_na_code(p, dtype=str).fillna("") if p.exists() else default_map().astype(str)
    probs = check_map(m)
    if probs:
        raise FeedRefused(f"{p}: " + "; ".join(probs))
    return m


def write_map(m: pd.DataFrame, data_dir: str | Path) -> Path:
    probs = check_map(m.astype(str))
    if probs:
        raise FeedRefused("series map refused: " + "; ".join(probs))
    p = paths(data_dir)["map"]
    p.parent.mkdir(parents=True, exist_ok=True)
    F._atomic_csv(m[MAP_COLUMNS], p)
    return p


def add_default_rows(data_dir: str | Path) -> list[str]:
    """Append the DEFAULT_MAP rows whose map_id the map file lacks (EQ-A-0119: new sources), every one verified=no.
    Existing rows are never changed. Returns the map_ids added ([] when none; the file is then not rewritten)."""
    m = load_map(data_dir)
    new = default_map().astype(str)
    new = new[~new["map_id"].isin(set(m["map_id"]))]
    if new.empty:
        return []
    write_map(pd.concat([m, new], ignore_index=True), data_dir)
    return list(new["map_id"])


def map_set(data_dir: str | Path, map_id: str, *, flow=None, key=None, filters=None, lag_days=None, priority=None,
            verified=None, by="", evidence="", today: dt.date | None = None) -> pd.Series:
    """Change one map row. Changing flow, key or filters resets verified to no. verified=yes needs `by` and
    `evidence` (what was checked, e.g. the structure file and a sample series)."""
    m = load_map(data_dir).copy()
    hit = m.index[m["map_id"] == map_id]
    if not len(hit):
        raise FeedRefused(f"unknown map_id {map_id!r}; known: {', '.join(m['map_id'])}")
    i = hit[0]
    codes = {"flow": flow, "key": key, "filters": filters}
    for c, v in codes.items():
        if v is not None:
            m.loc[i, c] = v
    if any(v is not None for v in codes.values()):
        m.loc[i, ["verified", "verified_by", "verified_on", "evidence"]] = ["no", "", "", ""]
    if lag_days is not None:
        m.loc[i, "est_lag_days"] = str(int(lag_days))
    if priority is not None:
        m.loc[i, "priority"] = str(int(priority))
    if verified is not None:
        if verified == "yes" and (not str(by).strip() or not str(evidence).strip()):
            raise FeedRefused("verified=yes needs --by and --evidence")
        m.loc[i, ["verified", "verified_by", "verified_on", "evidence"]] = (
            [verified, by, (today or dt.date.today()).isoformat(), evidence] if verified == "yes" else ["no", "", "", ""])
    write_map(m, data_dir)
    return m.loc[i]


def specs_from_map(m: pd.DataFrame, source: str) -> dict:
    """{map_id: SeriesSpec} for the configured rows of one source (SeriesSpec.name = map_id)."""
    out = {}
    for r in m[m["source"] == source].to_dict("records"):
        out[r["map_id"]] = SeriesSpec(r["map_id"], r["flow"], parse_filters(r["filters"]), r["freq"],
                                      f"{r['series']} via {r['map_id']}", key=r["key"] or None,
                                      candidate=r["candidate"])
    return out


# ---------------------------------------------------------------------------------------------- adapters
@dataclass
class BisNowcastFeed(SdmxFeed):
    """BIS SDMX REST (v1, CSV), for WS_LONG_CPI. ISO2 areas (`iso2` maps ISO3 -> BIS area code)."""
    base: str = "https://stats.bis.org/api/v1/data"
    accept: str = "text/csv"
    label: str = "BIS SDMX"
    licence: str = BIS_LICENCE
    area_dim: str = "REF_AREA"
    iso2: dict = field(default_factory=dict)

    def area_code(self, iso3: str) -> str | None:
        return self.iso2.get(iso3) or None

    def url(self, spec: SeriesSpec, areas: list[str]) -> str:
        return f"{self.base}/{spec.flow}/{(spec.key or '{area}').format(area='+'.join(areas))}/all?format=csv"

    def source(self) -> str:
        return f"BIS SDMX REST ({HOSTS['bis']})"


def iso2_map(data_dir: str | Path) -> dict:
    """ISO3 -> ISO2 from data/countries.csv and data/panel/universe_proposal.csv (bis_iso2 first)."""
    d = Path(data_dir)
    out = {}
    up = d / "panel" / "universe_proposal.csv"
    if up.exists():
        u = read_csv_keep_na_code(up, dtype=str).fillna("")
        for r in u.to_dict("records"):
            out[r["iso3"]] = (r.get("bis_iso2") or r.get("iso2") or "").strip()
    cp = d / "countries.csv"
    if cp.exists():
        c = read_csv_keep_na_code(cp, dtype=str).fillna("")
        for r in c.to_dict("records"):
            out.setdefault(r["iso"], (r.get("iso2") or "").strip())
    return {k: v for k, v in out.items() if k and v}


def make_feed(source: str, registry: dict, iso2: dict | None = None, sleep=None) -> SdmxFeed:
    if source == "imf":
        return ImfSdmxFeed(registry=registry, sleep=sleep)
    if source == "oecd":
        return OecdFeed(registry=registry, sleep=sleep)
    if source == "bis":
        return BisNowcastFeed(registry=registry, iso2=dict(iso2 or {}), sleep=sleep)
    if source in NN.NATIONAL:
        return NN.NationalNowcastFeed(source, registry=registry, sleep=sleep)
    raise ValueError(f"unknown source {source!r}")


# ---------------------------------------------------------------------------------------------- transforms
def allowed_series(iso3: str) -> tuple:
    return CPI_TRADE_SERIES if iso3 in CPI_TRADE_ONLY else REQUIRED_SERIES + OPTIONAL_SERIES


def yoy(levels: pd.Series, freq: str) -> pd.Series:
    """% change on the same period a year earlier, from levels indexed by 'YYYY-MM' (freq M) or 'YYYY-Qn' (Q).
    Needs both values and both > 0; nothing is interpolated or carried."""
    if levels is None or not len(levels):
        return pd.Series(dtype=float)
    idx = pd.PeriodIndex(list(levels.index), freq="M" if freq == "M" else "Q")
    s = pd.Series(levels.to_numpy(dtype=float), index=idx)
    s = s[~s.index.duplicated(keep="last")].sort_index()
    back = s.reindex(s.index - (12 if freq == "M" else 4)).to_numpy()
    ok = (s.to_numpy() > 0) & (back > 0) & np.isfinite(back)
    lab = [str(p) if freq == "M" else f"{p.year}-Q{p.quarter}" for p in s.index[ok]]
    out = pd.Series(s.to_numpy()[ok] / back[ok] * 100 - 100, index=lab)
    return out.round(DECIMALS)


def _period_ok(p: str, freq: str) -> bool:
    return bool(_PERIOD_RE[freq].match(str(p)))


def transform(raws: dict, m: pd.DataFrame, names: Iterable[str]) -> tuple[pd.DataFrame, list[str]]:
    """Raw tables ({source: RAW_COLUMNS frame}) -> TRANSFORMED_COLUMNS rows for every map row and name (all sources
    kept: precedence is chosen at replay). Rows with a period of another frequency are dropped and reported."""
    rows, notes = [], []
    names = list(dict.fromkeys(names))
    for r in m.to_dict("records"):
        raw = raws.get(r["source"])
        if raw is None or not len(raw):
            continue
        for iso in names:
            if r["series"] not in allowed_series(iso):
                continue
            lv = scaled(raw, iso, r["map_id"])
            if not len(lv):
                continue
            bad = [p for p in lv.index if not _period_ok(p, r["freq"])]
            if bad:
                notes.append(f"{r['map_id']} {iso}: {len(bad)} periods not {r['freq']} (e.g. {bad[0]}); dropped")
                lv = lv[[p for p in lv.index if p not in bad]]
            vals = yoy(lv, r["freq"]) if r["transform"] == "yoy" else lv.round(DECIMALS)   # level / yoy_published
            sub = raw[(raw["iso"] == iso) & (raw["series"] == r["map_id"])]
            src, lic = str(sub["source"].iloc[0]), str(sub["licence"].iloc[0])
            key = str(sub["sdmx_key"].iloc[0])
            # a publisher release date per observation, when an adapter delivers one (none of the SDMX ones does)
            rel = dict(zip(sub["period"].astype(str), sub["release_date"].fillna("").astype(str))) \
                if "release_date" in sub.columns else {}
            for p, v in vals.items():
                if np.isfinite(v):
                    rows.append({"iso3": iso, "series": r["series"], "freq": r["freq"], "period": p, "value": float(v),
                                 "source": f"{src} {r['flow']}", "map_id": r["map_id"], "licence": lic,
                                 "sdmx_key": key, "official_release_date": rel.get(p, "")})
    return pd.DataFrame(rows, columns=TRANSFORMED_COLUMNS), notes


# ---------------------------------------------------------------------------------------------- vintages
def _utc(now: dt.datetime | None) -> dt.datetime:
    n = now or dt.datetime.now(dt.timezone.utc)
    return n.astimezone(dt.timezone.utc) if n.tzinfo else n.replace(tzinfo=dt.timezone.utc)


def write_vintage(data_dir: str | Path, raws: dict, transformed: pd.DataFrame, meta: dict,
                  now: dt.datetime | None = None) -> Path:
    """Archive one fetch, append-only: nowcast_vintages/<YYYY-MM-DDTHHMMSSZ>-<hash8>/ with raw_<source>.csv,
    transformed.csv and fetch.json, every file read-only; the folder is created with exist_ok=False (never
    overwritten) and listed in index.csv."""
    now = _utc(now)
    meta = {**meta, "fetched_utc": now.strftime("%Y-%m-%dT%H:%M:%SZ"), "fetch_date": now.date().isoformat()}
    files = {f"raw_{s}.csv": df[[*RAW_COLUMNS, *[c for c in df.columns if c not in RAW_COLUMNS]]].to_csv(index=False).encode()
             for s, df in sorted(raws.items())}
    files["transformed.csv"] = transformed[TRANSFORMED_COLUMNS].to_csv(index=False).encode()
    files["fetch.json"] = json.dumps(meta, indent=1, sort_keys=True).encode()
    digest = vintage_digest(files)
    root = paths(data_dir)["vintages"]
    root.mkdir(parents=True, exist_ok=True)
    v = root / f"{now.strftime('%Y-%m-%dT%H%M%SZ')}-{digest[:8]}"
    v.mkdir(exist_ok=False)
    for n in sorted(files):
        (v / n).write_bytes(files[n]); os.chmod(v / n, 0o444)
    from .ledger import locked_append               # SEC-A-007 L6: concurrent fetches never interleave index rows
    with locked_append(root / "index.csv", ["vintage_id", "fetched_utc", "hash", "rows"]) as (w, _f, new):
        if new:
            w.writeheader()
        w.writerow({"vintage_id": v.name, "fetched_utc": meta["fetched_utc"], "hash": digest, "rows": len(transformed)})
    return v


def vintage_digest(files: dict) -> str:
    """Content hash of a vintage: sha256 over (name, sha256(bytes)) of every file, names sorted."""
    h = hashlib.sha256()
    for n in sorted(files):
        h.update(n.encode()); h.update(hashlib.sha256(files[n]).digest())
    return h.hexdigest()


def read_vintages(data_dir: str | Path) -> list[tuple[str, dt.date, pd.DataFrame]]:
    """[(vintage_id, fetch date, transformed rows)] in fetch order."""
    root = paths(data_dir)["vintages"]
    out = []
    for v in sorted(p for p in root.glob("*") if p.is_dir()) if root.exists() else []:
        got = vintage_digest({q.name: q.read_bytes() for q in v.iterdir() if q.is_file()})
        if not v.name.endswith("-" + got[:8]):      # SEC-A-007 L6: an edited or half-written vintage is never replayed
            raise FeedRefused(f"nowcast vintage {v.name}: content hash {got[:8]} does not match its folder name; "
                             "refusing to replay it")
        meta = json.loads((v / "fetch.json").read_text())
        t = read_csv_keep_na_code(v / "transformed.csv", dtype=str).fillna("").reindex(columns=TRANSFORMED_COLUMNS)
        t = t.fillna("")
        t["value"] = pd.to_numeric(t["value"], errors="coerce")
        out.append((v.name, dt.date.fromisoformat(meta["fetch_date"]), t))
    return out


# ---------------------------------------------------------------------------------------------- release dates
def period_end(p: str, freq: str) -> dt.date:
    return pd.Period(p, freq="M" if freq == "M" else "Q").end_time.date()


def _official(text, end: dt.date, day: dt.date) -> dt.date | None:
    """A publisher release date usable as-is: a real date after the period end and not after the fetch."""
    try:
        d = dt.date.fromisoformat(str(text).strip()[:10])
    except ValueError:
        return None
    return d if end < d <= day else None


def replay(vintages: list[tuple[str, dt.date, pd.DataFrame]], m: pd.DataFrame, eligible: set[str] | None = None,
           prefer: dict | None = None) -> pd.DataFrame:
    """Contract rows (INPUT_ORDER) from the archived vintages, in fetch order (rules in the module docstring).
    `eligible` limits the map rows used (None = all); `prefer` maps (iso3, series) to the map_id already in
    nowcast_inputs.csv, so a merge keeps the source a series started with (else the lowest priority number)."""
    mm = m.set_index("map_id")
    prio = mm["priority"].astype(int).to_dict()
    lag = mm["est_lag_days"].astype(int).to_dict()
    unit = {c: u for c, (_, u) in CONTRACT_SERIES.items()}
    prefer = dict(prefer or {})
    by_date: dict = {}
    for vid, day, t in vintages:                        # same UTC date: the later fetch is the day's view
        by_date[day] = (vid, t)
    last: dict = {}
    tracked: set = set()
    rows = []
    for day in sorted(by_date):
        vid, t = by_date[day]
        if eligible is not None:
            t = t[t["map_id"].isin(eligible)]
        t = t[t["map_id"].isin(prio.keys()) & t["value"].notna()]
        t = t[pd.Series([s in allowed_series(i) for i, s in zip(t["iso3"], t["series"])], index=t.index, dtype=bool)]
        seen_now = set()
        for (iso, ser), g in t.groupby(["iso3", "series"], sort=True):
            have = set(g["map_id"])
            pick = prefer.get((iso, ser))
            if pick not in have:
                pick = min(have, key=lambda k: (prio[k], k))
            switched = (iso, ser) in prefer and prefer[(iso, ser)] != pick
            prefer[(iso, ser)] = pick
            seen_now.add((iso, ser))
            first_fetch = (iso, ser) not in tracked
            for r in g[g["map_id"] == pick].sort_values("period").to_dict("records"):
                end = period_end(r["period"], r["freq"])
                if end >= day:
                    continue                            # not over yet on the fetch date: cannot have been released
                k = (iso, ser, r["period"])
                v = round(float(r["value"]), DECIMALS)
                if k in last and last[k] == v:
                    continue
                off = _official(r.get("official_release_date", ""), end, day)
                if off is not None:
                    rel, basis, note = off, "official", f"publisher release date, fetch {vid}"
                elif k not in last and first_fetch:
                    est = end + dt.timedelta(days=lag[pick])
                    if est < day:
                        rel, basis = est, "estimated_lag"
                        note = f"history in first fetch {vid}: period end + {lag[pick]} days (usual lag, assumption)"
                    else:
                        rel, basis, note = day, "fetched", f"first seen in fetch {vid}"
                else:
                    rel, basis = day, "fetched"
                    note = (f"revised in fetch {vid}" if k in last else f"first seen in fetch {vid}") + \
                        ("; source switched" if switched else "")
                last[k] = v
                rows.append({"iso3": iso, "series": ser, "freq": r["freq"], "period": r["period"], "value": v,
                             "release_date": rel.isoformat(), "source": r["source"], "release_date_basis": basis,
                             "unit": unit[ser], "notes": note, "licence": r["licence"], "map_id": pick})
        tracked |= seen_now
    return pd.DataFrame(rows, columns=INPUT_ORDER)


# ---------------------------------------------------------------------------------------------- Team B's CLI
def _nowcast_cli(*args: str) -> subprocess.CompletedProcess:
    """Run `python -m econquest.engine.nowcast ARGS` with this interpreter (fixed module, no shell)."""
    return subprocess.run([sys.executable, "-m", NOWCAST_MODULE, *args], capture_output=True, text=True,  # nosec B603
                          cwd=str(ROOT), timeout=300, check=False)


def validate_file(path: str | Path) -> tuple[bool, str]:
    """Team B's validator on a file: (valid, its output)."""
    r = _nowcast_cli("validate", "--inputs", str(Path(path).resolve()))
    out = (r.stdout + r.stderr).strip()
    return r.returncode == 0 and out.endswith("valid") and "Traceback" not in out, out


_NAMES_ROW = re.compile(r"^\s*(\d+)\s+.*?\s([A-Z]{3})\s+-?\d+(?:\.\d+)?\s")


def parse_names(text: str) -> list[str]:
    """ISO3 codes, in rank order, from the table `nowcast names` prints (rank, country, iso3, gross, basis)."""
    rows = [(int(m[1]), m[2]) for m in map(_NAMES_ROW.match, text.splitlines()) if m]
    return [iso for _, iso in sorted(rows)]


def top_names(data_dir: str | Path, n: int = 25) -> list[str]:
    """The nowcast coverage list from Team B's `nowcast names` (engine.nowcast.top_names)."""
    r = _nowcast_cli("names", "--data", str(Path(data_dir).resolve()), "--n", str(n))
    names = parse_names(r.stdout)
    if r.returncode != 0 or not names:
        raise FeedRefused(f"`python -m {NOWCAST_MODULE} names` gave no names: {(r.stderr or r.stdout)[-300:]}")
    return names


def _validated_write(df: pd.DataFrame, target: Path) -> None:
    """Write df to a temp file next to target, run Team B's validator on it, and only then replace target."""
    fd, tmp = tempfile.mkstemp(dir=target.parent, prefix=f".{target.name}.", suffix=".csv")
    try:
        with os.fdopen(fd, "w", newline="") as f:
            df.to_csv(f, index=False)
        ok, out = validate_file(tmp)
        if not ok:
            raise FeedRefused(f"merged file fails the nowcast contract; nothing written: {out[-500:]}")
        os.chmod(tmp, 0o644); os.replace(tmp, target)
    finally:
        if os.path.exists(tmp):
            os.unlink(tmp)


# ---------------------------------------------------------------------------------------------- merge
def read_inputs_file(path: str | Path) -> pd.DataFrame | None:
    p = Path(path)
    if not p.exists():
        return None
    d = read_csv_keep_na_code(p, dtype=str).fillna("")
    return d.reindex(columns=list(dict.fromkeys([*INPUT_ORDER, *d.columns]))).fillna("")


def prefer_from(existing: pd.DataFrame | None) -> dict:
    """(iso3, series) -> the map_id each series STARTED with (its earliest row), as replay() expects. Seeding with the
    latest map_id instead re-picks a fallback source on the first fetch and conflicts with the file (EQ-A-0060 M1)."""
    if existing is None or not len(existing) or "map_id" not in existing.columns:
        return {}
    e = existing[existing["map_id"] != ""].sort_values("release_date", kind="stable")
    e = e.drop_duplicates(["iso3", "series"], keep="first")
    return {(i, s): mid for i, s, mid in zip(e["iso3"], e["series"], e["map_id"])}


def merge_inputs(existing: pd.DataFrame | None, new: pd.DataFrame) -> tuple[pd.DataFrame, int]:
    """Append-only merge on (iso3, series, period, release_date). Returns (merged, rows added). Raises FeedRefused
    when a key already holds a different value. A new row dated before the first release already in the file for its
    (iso3, series, period) would rewrite history (e.g. a shorter est_lag_days): it is skipped, and the count is in
    merged.attrs["skipped_retroactive"] (EQ-A-0060 L2)."""
    key = ["iso3", "series", "period", "release_date"]
    n = new.astype({"value": float}).copy()
    if existing is None or not len(existing):
        e = pd.DataFrame(columns=INPUT_ORDER)
    else:
        e = existing.copy()
    ev = pd.to_numeric(e["value"], errors="coerce").round(DECIMALS)
    held = {tuple(k): v for k, v in zip(e[key].astype(str).itertuples(index=False, name=None), ev)}
    first: dict = {}
    for k in held:
        first[k[:3]] = min(first.get(k[:3], k[3]), k[3])
    add, conflicts, skipped = [], [], 0
    for r in n.to_dict("records"):
        k = tuple(str(r[c]) for c in key)
        if k[:3] in first and k[3] < first[k[:3]]:
            skipped += 1
            continue
        if k in held:
            if not (np.isclose(held[k], r["value"], rtol=0, atol=10 ** -DECIMALS / 2)):
                conflicts.append(f"{'/'.join(k)}: file {held[k]} vs new {r['value']}")
            continue
        held[k] = r["value"]
        add.append(r)
    if conflicts:
        raise FeedRefused(f"{len(conflicts)} key(s) already hold a different value; nothing written: "
                          + "; ".join(conflicts[:5]))
    a = pd.DataFrame(add, columns=INPUT_ORDER)
    a["value"] = a["value"].map(lambda x: f"{x:.{DECIMALS}f}")
    cols = list(dict.fromkeys([*INPUT_ORDER, *e.columns]))
    merged = pd.concat([e.reindex(columns=cols), a.reindex(columns=cols)], ignore_index=True).fillna("")
    merged = merged.sort_values(key, kind="stable").reset_index(drop=True)
    merged.attrs["skipped_retroactive"] = skipped
    return merged, len(a)


def merge(data_dir: str | Path = DEFAULT_DATA, include_unverified: bool = False, out: str | Path | None = None,
          log: Callable[[str], None] = print) -> dict:
    """Replay every archived vintage and merge the result into nowcast_inputs.csv (or `out`). Only verified map rows
    unless include_unverified, which needs an `out` other than data/live/nowcast_inputs.csv. The merged file must
    pass engine.nowcast.validate_inputs; otherwise nothing is written."""
    p = paths(data_dir)
    target = Path(out) if out else p["inputs"]
    if include_unverified and target.resolve() == p["inputs"].resolve():
        raise FeedRefused("--include-unverified writes only to a trial file (--out), never to "
                          f"{p['inputs']}: unverified codes would stay in the append-only file for good")
    m = load_map(data_dir)
    eligible = None if include_unverified else set(m.loc[m["verified"] == "yes", "map_id"])
    vint = read_vintages(data_dir)
    if not vint:
        raise FeedRefused(f"no vintage under {p['vintages']}: run fetch on the Mac first")
    existing = read_inputs_file(target)
    rows = replay(vint, m, eligible, prefer_from(existing))
    if not len(rows):
        log(f"[nowcast_feed] no rows eligible ({len(eligible or [])} verified map rows): {target} left as it is; "
            "verify codes with map-set, then run merge")
        return {"target": str(target), "added": 0, "rows": 0 if existing is None else len(existing), "written": False}
    merged, added = merge_inputs(existing, rows)
    skipped = merged.attrs.get("skipped_retroactive", 0)
    if added:
        target.parent.mkdir(parents=True, exist_ok=True)
        _validated_write(merged, target)
    log(f"[nowcast_feed] {target}: {added} rows added, {len(merged)} rows; contract valid"
        + (f"; {skipped} rows skipped (dated before the first release already in the file)" if skipped else ""))
    return {"target": str(target), "added": added, "rows": len(merged), "written": bool(added),
            "skipped_retroactive": skipped}


# ---------------------------------------------------------------------------------------------- fetch
def resolve_names(data_dir: str | Path, names: str | Iterable[str] | None = None) -> list[str]:
    if names is None or names == "top":
        return top_names(data_dir)
    if isinstance(names, str):
        names = names.split(",")
    return [x.strip().upper() for x in names if x and x.strip()]


def fetch(data_dir: str | Path = DEFAULT_DATA, names: str | Iterable[str] | None = None,
          sources: Iterable[str] | None = None, now: dt.datetime | None = None,
          probe: Callable[[str], str | None] | None = None, iso2: dict | None = None, sleep=None,
          log: Callable[[str], None] = print) -> dict:
    """One live pull: probe the hosts, fetch every configured map row from each reachable source, transform, archive
    the vintage, then merge verified rows into nowcast_inputs.csv. Raises FeedRefused, with nothing written, when no
    host answers or no source returned a row."""
    m = load_map(data_dir)
    isos = resolve_names(data_dir, names)
    srcs = list(dict.fromkeys(sources or SOURCES))
    bad = [s for s in srcs if s not in SOURCES]
    if bad:
        raise FeedRefused(f"unknown source(s) {bad}; sources are {', '.join(SOURCES)}")
    regs = {s: {k: v for k, v in specs_from_map(m, s).items() if v.configured} for s in srcs}
    srcs = [s for s in srcs if regs[s]]
    if not srcs:
        raise FeedRefused("no configured map row for the selected sources; nothing requested")
    probe = probe or F.probe_host
    down = {s: why for s in srcs if (why := probe(HOSTS[s]))}
    up = [s for s in srcs if s not in down]
    for s, why in down.items():
        log(f"[nowcast_feed] {s}: skipped, {why}")
    if not up:
        raise FeedRefused("offline: no source host answered (" + "; ".join(f"{s}: {w}" for s, w in down.items())
                          + "); nothing written")
    raws, failures = {}, {f"{s} (host)": [why] for s, why in down.items()}
    if "bis" in up and iso2 is None:
        iso2 = iso2_map(data_dir)
    for s in up:
        log(f"[nowcast_feed] {s}: {len(regs[s])} series x {len(isos)} names from {HOSTS[s]}")
        feed = make_feed(s, regs[s], iso2, sleep)
        try:
            raw = feed.fetch(isos)
        except F.FeedUnreachable as e:
            failures[s] = [f"unreachable: {e.reason}"]
            continue
        except F.FeedError as e:
            failures[s] = [F._one_line(e, 300)]
            continue
        raws[s] = raw
        failures[s] = list(raw.attrs.get("failures", []))
    if not raws:
        raise FeedRefused("no source returned a row; nothing written: "
                          + "; ".join(f"{s}: {(v or ['?'])[0]}" for s, v in failures.items()))
    transformed, notes = transform(raws, m, isos)
    meta = {"ticket": "EQ-A-0057", "names": isos, "sources": sorted(raws), "skipped_hosts": down,
            "failures": failures, "transform_notes": notes,
            "map_sha256": hashlib.sha256(m[MAP_COLUMNS].to_csv(index=False).encode()).hexdigest()}
    v = write_vintage(data_dir, raws, transformed, meta, now=now)
    log(f"[nowcast_feed] vintage {v} ({len(transformed)} transformed rows)")
    try:
        res = merge(data_dir, log=log)
    except FeedRefused as e:
        raise MergeStopped(f"vintage {v.name} archived, but the merge into {INPUTS_NAME} stopped: {e}") from e
    return {"vintage": str(v), "transformed_rows": len(transformed), "sources": sorted(raws), "failures": failures,
            **res}


# ---------------------------------------------------------------------------------------------- plan and status
def expected(iso3: str) -> dict:
    """{series: 'required' | 'optional'} for one name."""
    if iso3 in CPI_TRADE_ONLY:
        return {s: "required" for s in CPI_TRADE_SERIES}
    return {**{s: "required" for s in REQUIRED_SERIES}, **{s: "optional" for s in OPTIONAL_SERIES}}


def coverage(inputs: pd.DataFrame | None, names: list[str], latest: pd.DataFrame | None, m: pd.DataFrame) -> pd.DataFrame:
    """One row per name and expected series: periods in nowcast_inputs.csv, last period, whether the history rule
    holds (36 months / 13 quarters), release_date_basis counts, and what the latest vintage holds (verified or not)."""
    ver = set(m.loc[m["verified"] == "yes", "map_id"])
    rows = []
    for iso in names:
        for ser, need in expected(iso).items():
            g = inputs[(inputs["iso3"] == iso) & (inputs["series"] == ser)] if inputs is not None and len(inputs) else None
            n = 0 if g is None else g["period"].nunique()
            mins = MIN_QUARTERS if CONTRACT_SERIES[ser][0] == "Q" else MIN_MONTHS
            lv = latest[(latest["iso3"] == iso) & (latest["series"] == ser)] if latest is not None and len(latest) else None
            vids = sorted(set(lv["map_id"])) if lv is not None else []
            rows.append({"iso3": iso, "series": ser, "need": need, "periods": n,
                         "last": "" if not n else max(g["period"]), "meets_history": n >= mins,
                         "basis": "" if not n else ",".join(f"{k}:{v}" for k, v in g["release_date_basis"].value_counts().sort_index().items()),
                         "latest_vintage": ",".join(f"{v}{'' if v in ver else '(unverified)'}" for v in vids),
                         "configured": ",".join(sorted(m.loc[(m["series"] == ser) & (m["filters"] != ""), "map_id"])) or "none"})
    return pd.DataFrame(rows)


def plan(data_dir: str | Path = DEFAULT_DATA, names=None, write_map_file: bool = False,
         log: Callable[[str], None] = print, add_defaults: bool = False) -> dict:
    p = paths(data_dir)
    if write_map_file and not p["map"].exists():
        write_map(default_map(), data_dir)
        log(f"[nowcast_feed] wrote {p['map']} (every code UNVERIFIED, verified=no)")
    if add_defaults:
        added = add_default_rows(data_dir)
        log(f"[nowcast_feed] added {len(added)} default row(s) to {p['map']} (verified=no): {', '.join(added) or 'none'}")
    m = load_map(data_dir)
    isos = resolve_names(data_dir, names)
    log(f"names ({len(isos)}): {' '.join(isos)}")
    log(f"CPI and trade only: {' '.join(sorted(CPI_TRADE_ONLY & set(isos)))}; PMI_MFG left out (not licensed)")
    log(f"sources and hosts: {', '.join(f'{s}={h}' for s, h in HOSTS.items())}")
    show = m.assign(configured=np.where(m["filters"] != "", "yes", "no"))
    log(show[["map_id", "series", "source", "flow", "configured", "verified", "priority", "est_lag_days"]].to_string(index=False))
    unserved = [s for s in REQUIRED_SERIES if not ((m["series"] == s) & (m["filters"] != "")).any()]
    if unserved:
        log(f"required series with no configured code (never requested until map-set): {', '.join(unserved)}")
    log(f"writes: {p['vintages']}/<ts>-<hash>/ (every fetch), {p['inputs']} (verified rows only, append-only)")
    return {"names": isos, "map_rows": len(m), "configured": int((m["filters"] != "").sum()),
            "verified": int((m["verified"] == "yes").sum()), "unserved_required": unserved}


def status(data_dir: str | Path = DEFAULT_DATA, names=None, log: Callable[[str], None] = print) -> pd.DataFrame:
    p = paths(data_dir)
    m = load_map(data_dir)
    isos = resolve_names(data_dir, names)
    inputs = read_inputs_file(p["inputs"])
    vint = read_vintages(data_dir)
    latest = vint[-1][2] if vint else None
    log(f"series map: {p['map'] if p['map'].exists() else 'not written yet (defaults)'}; "
        f"{int((m['filters'] != '').sum())} of {len(m)} rows configured, {int((m['verified'] == 'yes').sum())} verified")
    log(f"vintages: {len(vint)}" + (f", latest {vint[-1][0]}" if vint else ""))
    if inputs is None:
        log(f"{p['inputs']}: not written yet")
    else:
        ok, out = validate_file(p["inputs"])
        log(f"{p['inputs']}: {len(inputs)} rows, {inputs['iso3'].nunique()} names; "
            + ("contract valid (engine.nowcast validate)" if ok else "CONTRACT PROBLEMS: " + out))
    cov = coverage(inputs, isos, latest, m)
    req = cov[cov["need"] == "required"]
    log(f"required cells meeting the history rule: {int(req['meets_history'].sum())} of {len(req)}")
    log(cov.to_string(index=False))
    return cov


# ---------------------------------------------------------------------------------------------- command line
def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.nowcast_feed", description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    for name in ("plan", "fetch", "merge", "status", "map-set"):
        s = sub.add_parser(name)
        s.add_argument("--data", default=str(DEFAULT_DATA))
        if name in ("plan", "fetch", "status"):
            s.add_argument("--names", default="top", help="top (the 25 names) or ISO,ISO")
    sub.choices["plan"].add_argument("--write-map", action="store_true", help="write the default map if missing")
    sub.choices["plan"].add_argument("--add-defaults", action="store_true",
                                     help="append default rows the map lacks (new sources); existing rows unchanged")
    sub.choices["fetch"].add_argument("--sources", default=",".join(SOURCES))
    mg = sub.choices["merge"]
    mg.add_argument("--include-unverified", action="store_true"); mg.add_argument("--out", default=None)
    ms = sub.choices["map-set"]
    ms.add_argument("map_id")
    for a in ("--flow", "--key", "--filters", "--by", "--evidence"):
        ms.add_argument(a, default=None)
    ms.add_argument("--lag-days", type=int, default=None); ms.add_argument("--priority", type=int, default=None)
    ms.add_argument("--verified", choices=("yes", "no"), default=None)
    a = ap.parse_args(argv)
    try:
        if a.cmd == "plan":
            plan(a.data, a.names, write_map_file=a.write_map, add_defaults=a.add_defaults)
        elif a.cmd == "fetch":
            r = fetch(a.data, a.names, sources=[s.strip() for s in a.sources.split(",") if s.strip()])
            for s, f in r["failures"].items():
                for x in f[:5]:
                    print(f"  {s}: {x}")
        elif a.cmd == "merge":
            merge(a.data, include_unverified=a.include_unverified, out=a.out)
        elif a.cmd == "status":
            status(a.data, a.names)
        else:
            r = map_set(a.data, a.map_id, flow=a.flow, key=a.key, filters=a.filters, lag_days=a.lag_days,
                        priority=a.priority, verified=a.verified, by=a.by or "", evidence=a.evidence or "")
            print(r.to_string())
    except FeedRefused as e:
        print(f"[nowcast_feed] refused: {e}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
