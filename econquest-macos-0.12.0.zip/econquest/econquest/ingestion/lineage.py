"""Lineage per cell (EQ-A-0052): where the value in one Inputs / Country Profile cell came from, and who let it in.

For a cell (country or ISO3, indicator id or profile key) `cell_lineage` returns one dict (LINEAGE_COLUMNS):

  value, origin       the value in indicators.csv / countries.csv now and how it got there (audit.build_audit_trail;
                      "live feed" whenever a vintage or the current pull holds the value)
  source, series      the feed and series of the vintage the value came from (its provenance.csv row)
  vintage_id          that vintage; vintage_basis says how it was found:
                        "apply record"   an apply of that vintage is recorded (data/live/snapshots/index.csv, written
                                         by apply_report -> replay.freeze_inputs) and its live value equals the cell
                        "value match"    no apply record, but that vintage's live value equals the cell (newest wins)
                        "current pull"   only data/live (the pull not saved as a vintage) holds the value
                        ""               no pull holds the value (seed, analyst entry)
  fetched_utc         retrieval time of that vintage (vintages/index.csv retrieved_utc, else its feeds.json
                      "retrieved"); retrieved = the provenance row's date
  applied_utc         frozen_utc of the latest apply record of that vintage ('' when none)
  gate_status/reason  the quality gate's row for the cell in that vintage's review.csv
  gate_decision       applied           value in use, gate ok
                      released          value in use, gate held it and an approved apply bound to that vintage or value
                                        released it (ledger.effective_holds)
                      applied (forced)  value in use, applied with apply_report(force=True) (forced_cells.csv)
                      applied (now held) value in use, but the cell is held now (a later hold/reject in the ledger)
                      applied (hold not released in the ledger)  value in use although the gate held it and the
                                        ledger has no approved release (e.g. applied on a hand-typed review.csv
                                        decision before the ledger existed: see decision_source)
                      held              value not in use: the newest vintage's gate held it and nothing released it
                      released (not applied) the newest vintage's hold is released but no apply has written it yet
                      missing           the newest vintage has no live value for the cell (gate status missing)
                      not applied       the newest vintage has an ok live value that is not in the cell
                      seed              no vintage or pull has a row for the cell
                      attested / unattested  hand-entered cells (ledger.attestation_status)
  decision ...        the latest ledger decision on the cell: decision, author, approver, self_approved, decided_utc,
                      decision_vintage; decision_source "ledger", or "review.csv (legacy)" when the ledger has no row
                      and data/live/review.csv still carries a hand-typed decision
  latest_vintage_id   the newest vintage with a row for the cell, with its live value and gate status, so a newer
                      pull that is held or not yet applied shows next to the value in use

Read-only: nothing on disk is written or changed (vintage integrity is not re-verified here; `econquest vintage verify`
does that). Built from the vintage store (feeds.list_vintages), the review ledger (ledger.load_decisions,
effective_holds, attestation_status), the apply records (snapshots/index.csv, *-pre-apply/forced_cells.csv) and the
audit trail (audit.build_audit_trail).

    python -m econquest.ingestion.lineage show VNM 1.3 [--json] [--data data]
    python -m econquest.ingestion.lineage export [--out lineage.csv] [--no-hand-entered] [--data data]
"""
from __future__ import annotations

import argparse
import csv
import json
import sys
from pathlib import Path

import numpy as np
import pandas as pd

from .audit import _same, build_audit_trail
from .sources import read_csv_keep_na_code

LINEAGE_COLUMNS = ["table", "key", "indicator", "country", "iso3", "value", "origin", "source", "series", "vintage_id",
                   "vintage_basis", "fetched_utc", "retrieved", "applied_utc", "gate_status", "gate_reason",
                   "gate_decision", "decision", "author", "approver", "self_approved", "decided_utc",
                   "decision_vintage", "decision_source", "attested", "latest_vintage_id", "latest_live",
                   "latest_gate_status"]
CURRENT = "current pull (data/live)"


def _str_csv(p: Path) -> pd.DataFrame | None:
    if not p.is_file():
        return None
    try:
        return pd.read_csv(p, dtype=str, keep_default_na=False)
    except (ValueError, OSError):
        return None


def _num(v) -> float:
    x = pd.to_numeric(v, errors="coerce")
    return float(x) if pd.notna(x) else np.nan


class _Pull:
    """One pull: a vintage folder or data/live. Holds its provenance and review rows per cell."""

    def __init__(self, vid: str, folder: Path, fetched: str):
        self.vid, self.folder, self.fetched = vid, folder, fetched
        self.prov: dict = {}
        self.review: dict = {}
        self.review_df: pd.DataFrame | None = None
        p = _str_csv(folder / "provenance.csv")
        if p is not None and {"table", "key", "country"} <= set(p.columns):
            for r in p.to_dict("records"):
                self.prov[(r["table"], str(r["key"]), r["country"])] = r
        rv = _str_csv(folder / "review.csv")
        if rv is not None and {"table", "key", "country", "status"} <= set(rv.columns):
            for r in rv.to_dict("records"):
                self.review[(r["table"], str(r["key"]), r["country"])] = r
            df = rv.copy()
            df["live"] = pd.to_numeric(df["live"], errors="coerce") if "live" in df.columns else np.nan
            self.review_df = df

    def live(self, cell) -> float:
        r = self.prov.get(cell)
        if r is not None:
            return _num(r.get("value"))
        rv = self.review.get(cell)
        return _num(rv.get("live")) if rv is not None else np.nan

    def has(self, cell) -> bool:
        return cell in self.prov or cell in self.review


class LineageStore:
    """Everything cell_lineage needs, read once from a data folder (export reads ~1,600 cells from one store)."""

    def __init__(self, data_dir: str | Path = "data"):
        from .feeds import list_vintages
        from .ledger import load_decisions
        self.d = d = Path(data_dir)
        self.decisions = load_decisions(d)
        self.latest_dec = {(r.table, str(r.key), r.country): r for r in self.decisions.itertuples(index=False)}
        idx = _str_csv(d / "live" / "vintages" / "index.csv")
        retrieved = {}
        if idx is not None and {"vintage_id", "retrieved_utc"} <= set(idx.columns):
            retrieved = dict(zip(idx["vintage_id"], idx["retrieved_utc"]))     # last row wins (append-only)
        self.pulls: list[_Pull] = []                       # newest first
        for vid in reversed(list_vintages(d)):
            folder = d / "live" / "vintages" / vid
            self.pulls.append(_Pull(vid, folder, retrieved.get(vid) or self._feeds_retrieved(folder)))
        self.current = _Pull("", d / "live", self._feeds_retrieved(d / "live"))
        snaps = _str_csv(d / "live" / "snapshots" / "index.csv")
        self.applied: dict[str, str] = {}                  # vintage id -> latest frozen_utc
        if snaps is not None and {"vintage_id", "frozen_utc"} <= set(snaps.columns):
            for vid, ts in zip(snaps["vintage_id"], snaps["frozen_utc"]):
                self.applied[vid] = max(ts, self.applied.get(vid, ""))
        self.forced: dict = {}                             # cell -> forced_cells.csv row (latest snapshot wins)
        root = d / "live" / "snapshots"
        if root.is_dir():
            for f in sorted(root.glob("*-pre-apply*/forced_cells.csv")):
                fc = _str_csv(f)
                if fc is None or not {"table", "key", "country"} <= set(fc.columns):
                    continue
                for r in fc.to_dict("records"):
                    self.forced[(r["table"], str(r["key"]), r["country"])] = r
        self._holds: dict[str, set] = {}
        legacy = _str_csv(d / "live" / "review.csv")
        self.legacy_decision = {}
        if legacy is not None and {"table", "key", "country", "decision"} <= set(legacy.columns):
            for r in legacy.to_dict("records"):
                if str(r.get("decision", "")).strip():
                    self.legacy_decision[(r["table"], str(r["key"]), r["country"])] = r
        cty = read_csv_keep_na_code(d / "countries.csv", dtype=str)
        self.iso_of = dict(zip(cty["country"], cty["iso"].str.upper()))
        self.country_of = {v: k for k, v in self.iso_of.items()}
        self._audit: pd.DataFrame | None = None

    @staticmethod
    def _feeds_retrieved(folder: Path) -> str:
        p = folder / "feeds.json"
        try:
            return str(json.loads(p.read_text()).get("retrieved", "")) if p.is_file() else ""
        except (ValueError, OSError):
            return ""

    def audit(self, hand_entered: bool = True) -> pd.DataFrame:
        if self._audit is None or (hand_entered and not self._audit.attrs.get("hand_entered")):
            self._audit = build_audit_trail(self.d, hand_entered=hand_entered)
            self._audit.attrs["hand_entered"] = hand_entered
        return self._audit

    def holds(self, pull: _Pull) -> set:
        """ledger.effective_holds for one pull's review (cached)."""
        from .ledger import effective_holds
        if pull.vid not in self._holds:
            self._holds[pull.vid] = effective_holds(pull.review_df, self.decisions, vintage_id=pull.vid or None)
        return self._holds[pull.vid]

    def resolve_country(self, who: str) -> str:
        """Country name for an ISO3 code or a name (case-insensitive). KeyError when unknown."""
        w = str(who).strip()
        if w.upper() in self.country_of:
            return self.country_of[w.upper()]
        for name in self.iso_of:
            if name.casefold() == w.casefold():
                return name
        raise KeyError(f"unknown country {who!r}: give an ISO3 code or a name from data/countries.csv")


def _source_pull(store: LineageStore, cell, value: float) -> tuple[_Pull | None, str]:
    """The pull the cell's value came from and how it was found (see vintage_basis in the module docstring)."""
    if not np.isfinite(value):
        return None, ""
    matching = [p for p in store.pulls if np.isfinite(p.live(cell)) and _same(value, p.live(cell))]
    for p in matching:
        if p.vid in store.applied:
            return p, "apply record"
    if matching:
        return matching[0], "value match"
    cur = store.current.live(cell)
    if np.isfinite(cur) and _same(value, cur):
        return store.current, "current pull"
    return None, ""


def _gate_decision(store: LineageStore, cell, src: _Pull | None, newest: _Pull | None) -> str:
    if src is not None:
        rv = src.review.get(cell)
        held = cell in store.holds(src)
        if cell in store.forced:
            return "applied (forced)"
        dec = store.latest_dec.get(cell)
        objected = dec is not None and dec.decision in ("hold", "reject")
        if rv is not None and rv.get("status") == "hold":
            if not held:
                return "released"
            return "applied (now held)" if objected else "applied (hold not released in the ledger)"
        return "applied (now held)" if held else "applied"
    if newest is None:
        return "seed"
    rv = newest.review.get(cell)
    status = (rv or {}).get("status", "")
    if status == "hold":
        return "held" if cell in store.holds(newest) else "released (not applied)"
    if status == "missing" or not np.isfinite(newest.live(cell)):
        return "missing"
    return "held" if cell in store.holds(newest) else "not applied"


def _text(v) -> str:
    return "" if v is None or (isinstance(v, float) and not np.isfinite(v)) else str(v)


def _lineage_row(store: LineageStore, a: dict) -> dict:
    cell = (a["table"], str(a["key"]), a["country"])
    value = _num(a.get("value"))
    row = {c: "" for c in LINEAGE_COLUMNS}
    row.update(table=a["table"], key=str(a["key"]), indicator=a.get("indicator", ""), country=a["country"],
               iso3=store.iso_of.get(a["country"], ""), value=value, origin=a.get("origin", ""),
               attested=_text(a.get("attested")))
    if a.get("origin", "").startswith("hand-entered"):
        row.update(source=a.get("source", ""), gate_decision="attested" if a.get("attested") == "yes" else "unattested",
                   author=_text(a.get("author")), approver=_text(a.get("approver")),
                   self_approved=_text(a.get("self_approved")), decided_utc=_text(a.get("retrieved")),
                   decision="attested" if a.get("attested") == "yes" else "", decision_source="ledger")
        return row
    pulls = store.pulls + [store.current]
    newest = next((p for p in pulls if p.has(cell)), None)
    src, basis = _source_pull(store, cell, value)
    if src is not None:
        pr = src.prov.get(cell, {})
        rv = src.review.get(cell, {})
        row.update(source=pr.get("source", ""), series=pr.get("series", ""), retrieved=pr.get("retrieved", ""),
                   vintage_id=src.vid, fetched_utc=src.fetched, applied_utc=store.applied.get(src.vid, ""),
                   gate_status=rv.get("status", ""), gate_reason=rv.get("reason", ""))
        row["vintage_basis"] = basis
        row["origin"] = "live feed"            # the audit trail sees only data/live; the value is a pull's live value
    elif newest is not None:
        rv = newest.review.get(cell, {})
        row.update(gate_status=rv.get("status", ""), gate_reason=rv.get("reason", ""))
    if src is None:
        row.update(source=a.get("source", ""), series=a.get("series", ""))
    row["gate_decision"] = _gate_decision(store, cell, src, newest)
    if newest is not None:
        row.update(latest_vintage_id=newest.vid or CURRENT, latest_live=newest.live(cell),
                   latest_gate_status=newest.review.get(cell, {}).get("status", ""))
    dec = store.latest_dec.get(cell)
    if dec is not None:
        row.update(decision=dec.decision, author=dec.author, approver=dec.approver, self_approved=dec.self_approved,
                   decided_utc=dec.ts_utc, decision_vintage=dec.vintage_id, decision_source="ledger")
    elif cell in store.legacy_decision:
        lg = store.legacy_decision[cell]
        row.update(decision=lg.get("decision", ""), author=lg.get("author", ""), approver=lg.get("approver", ""),
                   self_approved=lg.get("self_approved", ""), decision_source="review.csv (legacy)")
    if cell in store.forced:
        f = store.forced[cell]
        row.update(author=f.get("author", row["author"]), approver=f.get("approver", row["approver"]),
                   self_approved=f.get("self_approved", row["self_approved"]))
    return row


def lineage_table(data_dir: str | Path = "data", hand_entered: bool = True, store: LineageStore | None = None) -> pd.DataFrame:
    """Lineage of every cell (LINEAGE_COLUMNS): Inputs, Country Profile and, with hand_entered, the hand-entered files."""
    store = store or LineageStore(data_dir)
    audit = store.audit(hand_entered)
    if not hand_entered:
        audit = audit[~audit["origin"].str.startswith("hand-entered")]
    rows = [_lineage_row(store, a) for a in audit.to_dict("records")]
    return pd.DataFrame(rows, columns=LINEAGE_COLUMNS)


def cell_lineage(data_dir: str | Path, country: str, key: str, table: str | None = None,
                 store: LineageStore | None = None) -> list[dict]:
    """Lineage of one cell: `country` is an ISO3 code or a country name, `key` an indicator id ('1.3') or a profile
    key ('policy'). Returns one dict per matching table (usually one; `table` narrows it). KeyError when the country
    or the cell is unknown."""
    store = store or LineageStore(data_dir)
    name = store.resolve_country(country)
    audit = store.audit(hand_entered=True)
    m = (audit["country"] == name) & (audit["key"].astype(str) == str(key).strip())
    if table:
        m &= audit["table"] == table
    hits = audit[m]
    if hits.empty:
        raise KeyError(f"no cell {key!r} for {name} in indicators.csv, countries.csv or the hand-entered files")
    return [_lineage_row(store, a) for a in hits.to_dict("records")]


# ------------------------------------------------------------------------------------------------ CLI

def _fmt(v) -> str:
    if isinstance(v, float):
        return "" if not np.isfinite(v) else f"{v:g}"
    return str(v)


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.lineage",
                                 description="Lineage per cell (EQ-A-0052): source, series, vintage, fetch time, gate "
                                             "decision and approval of a workbook input cell. Read-only.")
    sub = ap.add_subparsers(dest="cmd", required=True)
    s = sub.add_parser("show", help="lineage of one cell")
    s.add_argument("country", help="ISO3 code or country name")
    s.add_argument("indicator", help="indicator id (e.g. 1.3) or Country Profile key (e.g. policy)")
    s.add_argument("--table", default=None, help="Inputs, Country Profile or a hand-entered table, when ambiguous")
    s.add_argument("--json", action="store_true")
    s.add_argument("--data", default="data", help="econquest data folder (default: data)")
    e = sub.add_parser("export", help="CSV of the lineage of every cell")
    e.add_argument("--out", default="-", help="output CSV path (default: stdout)")
    e.add_argument("--no-hand-entered", action="store_true", help="leave out the hand-entered files")
    e.add_argument("--data", default="data", help="econquest data folder (default: data)")
    a = ap.parse_args(argv)
    if a.cmd == "show":
        try:
            rows = cell_lineage(a.data, a.country, a.indicator, a.table)
        except KeyError as err:
            print(f"lineage: {err.args[0]}", file=sys.stderr)
            return 1
        if a.json:
            print(json.dumps([{k: (None if isinstance(v, float) and not np.isfinite(v) else v) for k, v in r.items()}
                              for r in rows], indent=1))
        else:
            for r in rows:
                print(f"{r['table']} {r['key']} {r['indicator']} | {r['country']} ({r['iso3']})")
                for k in LINEAGE_COLUMNS[5:]:
                    print(f"  {k:18} {_fmt(r[k])}")
        return 0
    from .ledger import _neutralise
    df = lineage_table(a.data, hand_entered=not a.no_hand_entered)
    for c in df.columns:                       # free text (reasons, names) is guarded against formula injection
        if df[c].dtype == object:
            df[c] = df[c].map(_neutralise)
    if a.out == "-":
        df.to_csv(sys.stdout, index=False, quoting=csv.QUOTE_MINIMAL)
    else:
        Path(a.out).parent.mkdir(parents=True, exist_ok=True)
        df.to_csv(a.out, index=False)
        print(f"wrote {a.out} ({len(df)} cells)")
    return 0


if __name__ == "__main__":
    sys.exit(main())
