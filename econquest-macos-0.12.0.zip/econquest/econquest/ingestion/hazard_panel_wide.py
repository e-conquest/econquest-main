"""Wide hazard predictor panel from recorded, shared, non-WEO data, and its missing-predictor map (EQ-A-0140).

Feeds Team B's EQ-B-0140 refit rehearsal. Nothing is fetched and no value is invented: every predictor column is
read from a file already on disk (a recorded Mac pull, a recorded data/live vintage, data/gpr_monthly.csv or the
CRAG import). The only changes are documented transforms (Team B's layer-1 transforms) and calendar aggregation of
monthly, quarterly or daily series to years.

    python -m econquest.ingestion.hazard_panel_wide build                    # non-WEO panel + missing map
    python -m econquest.ingestion.hazard_panel_wide build --refit            # once WEO history lands: + Team B refit
    python -m econquest.ingestion.hazard_panel_wide sources                  # which inputs are on disk (no writes)

Rows: one per (iso, year t) at risk (not inside a crag_v1 default spell), for every economy with an ISO3 code in
the CRAG universe, years 1980 to the last labelled year at --as-of. Label: `event` = 1 when a crag_v1 spell starts
in t+1, built by Team B's own hazard_events.build_events, so the label is identical to the refit's. Predictors on
row t are the observations for period t-1 (lag 1, hazard_refit.PREDICTOR_LAG); CRAG history features use only
spells that started by year t.

Output folder data/panel/hazard_panel_wide/ (ownership row approved by AGENT-08; internal only, licence row
`hazard_panel_wide`, restricted; kept out of data/mvp by mvp_dataset.EXCLUDE_DIRS and out of release zips):
* panel.csv: iso, year, predictors, event, ever_defaulted, n_present
* columns.csv: one row per predictor: source file + sha256, series, transform, aggregation, licence rows,
  client_output, point_in_time, coverage
* missing_map.csv: per country-year: present / missing predictors, which source fills each missing one, and the
  WEO-fillable ones
* manifest.json: as_of, event rule, counts, input hashes, the command

WEO: when a vintaged WEO history is found (--weo-history, data/panel/weo_history.csv, the weo_vintages archive, or
hand-saved release files in data/panel/staging/weo_cache/weo_<YYYY-MM>.xls), the five WEO features are added point
in time through hazard_panel.panel_from_long (Team B's code, same transforms) and `--refit` runs
`python -m econquest.validation.hazard_refit --events crag` on it. Without WEO, those five columns are empty and
every row lists them as WEO-fillable.
"""
from __future__ import annotations

import argparse
import hashlib
import io
import json
import os
import re
import shutil
import sys
import tempfile
from dataclasses import dataclass
from pathlib import Path

import numpy as np
import pandas as pd

ROOT = Path(__file__).resolve().parents[2]
OUT_REL = Path("panel") / "hazard_panel_wide"          # under the data folder
SCHEMA = "econquest-hazard-panel-wide/1"
AS_OF = "2026-10-23"                                    # Team B's base as_of (A-PI14 brief)
START = 1980
LAG = 1
LICENCE_ROW = "hazard_panel_wide"
SYNTHETIC_TAG = "SYNTHETIC"

# recorded inputs (paths relative to the econquest folder); never fetched
WB_HISTORY = "team/inbox/pull-20261025T121034Z/worldbank_history.csv"   # Sam's 0.5.0 panel history, 216 economies
WB_UNIVERSE = "team/inbox/pull-20261025T013150Z/raw_worldbank.csv"     # pull pack step 4, universe, 2020-2025 mostly
BIS_VINTAGE = "data/live/vintages/2026-10-25T170547Z-67dffc57/raw_bis.csv"  # recorded BIS vintage (desk subset)
GPR = "data/gpr_monthly.csv"
CRAG_EPISODES = "data/panel/sovereign_defaults_crag.csv"
CRAG_UNIVERSE = "data/panel/sovereign_defaults_crag_universe.csv"
CT_HAIRCUTS = "data/panel/cruces_trebesch_haircuts.csv"                 # not dropped yet (EQ-A-0098)

from .mvp_dataset import PANEL_WIDE_WORK_PREFIXES                      # noqa: E402 - stdlib-only module
from .official.client_safe_route import D3_CODES                        # noqa: E402 - the IMF-compiled WDI codes
IMF_VIA_WDI = re.compile(rf"\b({D3_CODES})\b")      # such columns must also carry imf_via_wdi (checked in column_licences)
WORK_TMP, WORK_OLD = (Path(p).name for p in PANEL_WIDE_WORK_PREFIXES)   # "hazard_panel_wide.tmp-", ".old-"
EXIT = {"OK": 0, "INPUT_ERROR": 2, "NO_WEO": 4}       # with --refit, any other code is hazard_refit's own (0-3)


@dataclass(frozen=True)
class Predictor:
    name: str
    source: str            # key of SOURCE_FILES, "crag" or "weo"
    series: str
    transform: str = "level"   # hazard_panel._transform names, plus pct_change
    agg: str = "annual"        # annual | mean | last
    licences: tuple = ()
    weo_fill: str = ""         # WEO code that measures the same thing (WEO-fillable), "" when none
    fill_note: str = ""        # what would fill a gap besides WEO
    note: str = ""


SOURCE_FILES = {"wb_history": WB_HISTORY, "wb_universe": WB_UNIVERSE, "bis": BIS_VINTAGE, "gpr": GPR}
WB_FULL = "World Bank full-history pull (panel_history --wb-set interim, 2000-2025, every economy)"

PREDICTORS: tuple[Predictor, ...] = (
    # WEO features (hazard_panel.DEFAULT_FEATURES): empty until a vintaged WEO history lands
    Predictor("debt_gdp", "weo", "GGXWDG_NGDP", "level", licences=("imf_weo",), weo_fill="GGXWDG_NGDP"),
    Predictor("primary_deficit", "weo", "GGXONLB_NGDP", "negate", licences=("imf_weo",), weo_fill="GGXONLB_NGDP"),
    Predictor("current_account", "weo", "BCA_NGDPD", "level", licences=("imf_weo",), weo_fill="BCA_NGDPD"),
    Predictor("real_growth", "weo", "NGDP_RPCH", "level", licences=("imf_weo",), weo_fill="NGDP_RPCH"),
    Predictor("inflation_log", "weo", "PCPIPCH", "log1p_pct", licences=("imf_weo",), weo_fill="PCPIPCH"),
    # World Bank panel history (hazard_panel.PANEL_FEATURES names and transforms)
    Predictor("stfx_debt_reserves", "wb_history", "DT.DOD.DSTC.IR.ZS", licences=("worldbank_ids",),
              fill_note="IDS covers low and middle income only; no source on disk for other economies"),
    Predictor("reserves_months_imports", "wb_history", "FI.RES.TOTL.MO", licences=("worldbank_wdi", "imf_via_wdi"),
              fill_note=WB_FULL),
    Predictor("pitf_instability", "wb_history", "PV.EST", "wgi_to_pitf", licences=("worldbank_wgi",),
              fill_note="WGI has no 1997/1999 and nothing before 1996"),
    # World Bank universe pull (hazard_refit.WB_INTERIM_FEATURES names and transforms, plus the rest of the pull)
    Predictor("wb_current_account", "wb_universe", "BN.CAB.XOKA.GD.ZS", licences=("worldbank_wdi", "imf_via_wdi"),
              weo_fill="BCA_NGDPD", fill_note=WB_FULL),
    Predictor("wb_real_growth", "wb_universe", "NY.GDP.MKTP.KD.ZG", licences=("worldbank_wdi",),
              weo_fill="NGDP_RPCH", fill_note=WB_FULL),
    Predictor("wb_inflation_log", "wb_universe", "FP.CPI.TOTL.ZG", "log1p_pct", licences=("worldbank_wdi", "imf_via_wdi"),
              weo_fill="PCPIPCH", fill_note=WB_FULL),
    Predictor("wb_rule_of_law", "wb_universe", "GOV_WGI_RL.SC", licences=("worldbank_wgi",), fill_note=WB_FULL),
    Predictor("wb_control_corruption", "wb_universe", "GOV_WGI_CC.SC", licences=("worldbank_wgi",), fill_note=WB_FULL),
    Predictor("wb_regulatory_quality", "wb_universe", "GOV_WGI_RQ.SC", licences=("worldbank_wgi",), fill_note=WB_FULL),
    Predictor("ext_debt_exports", "wb_universe", "DT.DOD.DECT.EX.ZS", licences=("worldbank_ids",), fill_note=WB_FULL),
    Predictor("exports_gdp", "wb_universe", "NE.EXP.GNFS.ZS", licences=("worldbank_wdi",), fill_note=WB_FULL),
    Predictor("fuel_exports_share", "wb_universe", "TX.VAL.FUEL.ZS.UN", licences=("worldbank_wdi",), fill_note=WB_FULL),
    Predictor("metals_exports_share", "wb_universe", "TX.VAL.MMTL.ZS.UN", licences=("worldbank_wdi",), fill_note=WB_FULL),
    Predictor("npl_ratio", "wb_universe", "FB.AST.NPER.ZS", licences=("worldbank_wdi", "imf_via_wdi"), fill_note=WB_FULL),
    Predictor("youth_unemployment", "wb_universe", "SL.UEM.1524.ZS", licences=("worldbank_wdi",), fill_note=WB_FULL),
    # BIS recorded vintage (desk economies only)
    Predictor("bis_credit_gap", "bis", "CREDIT_GAP", agg="last", licences=("bis",),
              fill_note="wider BIS pull (credit-to-GDP gap is published for about 44 economies)"),
    Predictor("bis_reer_change", "bis", "EER_REAL_BROAD", "pct_change", agg="mean", licences=("bis",),
              fill_note="wider BIS pull (broad REER, about 64 economies)"),
    Predictor("bis_policy_rate", "bis", "POLICY_RATE", agg="mean", licences=("bis",),
              fill_note="wider BIS pull (policy rates, about 40 economies)"),
    # Caldara-Iacoviello country GPR (data/gpr_monthly.csv, 11 economies)
    Predictor("gpr_country", "gpr", "GPRC_<iso>", agg="mean", licences=("gpr",),
              fill_note="the GPR country file covers 44 economies; only 11 are recorded here"),
    # CRAG default history (only spells started by year t)
    Predictor("crag_prior_spells", "crag", "crag_v1 spells started by t", licences=("crag",)),
    Predictor("crag_years_since_default", "crag", "t - last end_spell", licences=("crag",),
              note="empty when the economy has no earlier spell (not a gap: listed as n/a in the map)"),
)
WEO_FEATURES = [p.name for p in PREDICTORS if p.source == "weo"]
NON_WEO = [p.name for p in PREDICTORS if p.source != "weo"]
BY_NAME = {p.name: p for p in PREDICTORS}


class PanelInputError(ValueError):
    """A required input is missing or not what this module expects."""


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest()


# ------------------------------------------------------------------------------------------------ licences

def column_licences(register: list[dict] | None = None) -> dict[str, dict]:
    """Per predictor: its licence rows, the most restrictive client_output, internal_only. Raises PanelInputError
    when a row is missing from data/licences.csv (ask AGENT-04 for it; never assume)."""
    from .licences import safe_register
    reg = {r["source_id"]: r for r in (safe_register() if register is None else register)}
    rank = {"allowed": 0, "restricted": 1, "barred": 2}
    out, missing = {}, {}
    for p in PREDICTORS:
        if p.source != "weo" and IMF_VIA_WDI.search(p.series) and "imf_via_wdi" not in p.licences:
            missing[p.name] = [f"imf_via_wdi (series {p.series} is IMF-compiled, client_safe_route.D3_CODES)"]
            continue
        rows = [reg.get(s) for s in p.licences]
        lost = [s for s, r in zip(p.licences, rows) if r is None]
        if lost:
            missing[p.name] = lost
            continue
        worst = max((str(r.get("client_output") or "restricted") for r in rows), key=lambda v: rank.get(v, 1))
        out[p.name] = {"licences": ";".join(p.licences), "client_output": worst, "internal_only": worst != "allowed"}
    if missing:
        raise PanelInputError(f"licence rows missing from the register: {missing}; ask AGENT-04 (tighten-only)")
    if LICENCE_ROW not in reg:
        raise PanelInputError(f"no '{LICENCE_ROW}' row in the licence register: the output folder needs it first "
                              "(AGENT-04, restricted, match_path (^|/)panel/hazard_panel_wide/)")
    return out


# ------------------------------------------------------------------------------------------------ readers

def read_once(path: Path, what: str = "input") -> tuple[bytes, str]:
    """The file's bytes and their sha256, from ONE read: the recorded hash is always the hash of the bytes parsed
    (SEC-A-016 H-L1; team/inbox files are writable by every session)."""
    path = Path(path)
    if not path.is_file():
        raise PanelInputError(f"{what} not found: {path}")
    body = path.read_bytes()
    return body, hashlib.sha256(body).hexdigest()


def _csv(body: bytes, **kw) -> pd.DataFrame:
    return pd.read_csv(io.BytesIO(body), **kw)


def _long(path: Path, what: str) -> tuple[pd.DataFrame, str]:
    body, sh = read_once(path, what)
    d = _csv(body, dtype={"iso": str, "series": str, "period": str})
    need = {"iso", "series", "period", "value"}
    if not need.issubset(d.columns):
        raise PanelInputError(f"{path}: needs {sorted(need)}, found {list(d.columns)}")
    return d, sh


def _annual(d: pd.DataFrame, how: str) -> pd.DataFrame:
    """(iso, period-string, value) -> (iso, year, value). annual: period is a year; mean / last: calendar-year mean
    or last observation of monthly, quarterly or daily periods."""
    d = d.copy()
    d["year"] = pd.to_numeric(d["period"].astype(str).str[:4], errors="coerce")
    d["value"] = pd.to_numeric(d["value"], errors="coerce")
    d = d.dropna(subset=["year", "value"])
    d["year"] = d["year"].astype(int)
    if how == "annual":
        return d.drop_duplicates(["iso", "year"], keep="first")[["iso", "year", "value"]]
    d = d.sort_values(["iso", "period"], kind="stable")
    g = d.groupby(["iso", "year"])["value"]
    return (g.mean() if how == "mean" else g.last()).reset_index()


def _transform(s: pd.DataFrame, how: str) -> pd.DataFrame:
    from ..validation.hazard_panel import _transform as tr      # Team B's layer-1 transforms (lazy: layering)
    s = s.sort_values(["iso", "year"]).copy()
    if how == "pct_change":
        prev = s.groupby("iso")["value"].shift(1)
        gap = s["year"] - s.groupby("iso")["year"].shift(1)
        s["value"] = np.where(gap.eq(1), 100.0 * (s["value"] / prev - 1.0), np.nan)
        return s.dropna(subset=["value"])
    s["value"] = tr(s["value"].astype(float), how).to_numpy()
    return s


def observations(paths: dict[str, Path], as_of: str) -> tuple[dict[str, pd.DataFrame], dict[str, dict]]:
    """Per non-WEO, non-CRAG predictor: (iso, year, value) observations dated before as_of's year (transformed).
    Also returns per source: path, sha256, rows read."""
    from ..rules.hazard import AGGREGATES
    y_as_of = pd.Timestamp(as_of).year
    frames, info = {}, {}
    cache: dict[str, pd.DataFrame] = {}
    for key in ("wb_history", "wb_universe", "bis"):
        cache[key], sh = _long(paths[key], key)
        info[key] = {"path": str(paths[key]), "sha256": sh, "rows": int(len(cache[key])),
                     "source_labels": sorted(cache[key]["source"].astype(str).unique())[:4] if "source" in cache[key] else []}
    body, sh = read_once(paths["gpr"], "GPR file")
    g = _csv(body)
    info["gpr"] = {"path": str(paths["gpr"]), "sha256": sh, "rows": int(len(g))}
    gl = g.melt(id_vars=["month"], value_vars=[c for c in g.columns if c.startswith("GPRC_")], var_name="series")
    gl = gl.assign(iso=gl["series"].str[5:], period=gl["month"].astype(str))
    cache["gpr"] = gl[["iso", "series", "period", "value"]]
    for k, d in cache.items():
        if "source" in d.columns and d["source"].astype(str).str.contains(SYNTHETIC_TAG).any():
            info[k]["synthetic"] = True
    for p in PREDICTORS:
        if p.source in ("weo", "crag"):
            continue
        d = cache[p.source]
        d = d[d["series"].str.startswith("GPRC_")] if p.source == "gpr" else d[d["series"] == p.series]
        d = d[~d["iso"].isin(AGGREGATES)]
        a = _annual(d, p.agg)
        a = a[a["year"] < y_as_of]                      # nothing dated in or after the as_of year
        frames[p.name] = _transform(a, p.transform)[["iso", "year", "value"]]
    return frames, info


def crag_features(events: pd.DataFrame, rows: pd.DataFrame) -> pd.DataFrame:
    """crag_prior_spells (spells started by year t, the row's own spell excluded since rows at risk are outside
    spells) and crag_years_since_default (t - last end_spell of a spell that ended before t; empty when none)."""
    out = rows[["iso", "year"]].copy()
    prior, since = [], []
    by = {iso: g for iso, g in events.groupby("iso")}
    for iso, t in zip(out["iso"], out["year"]):
        g = by.get(iso)
        if g is None:
            prior.append(0); since.append(np.nan); continue
        endsp = g["end_spell"] if "end_spell" in g else g["end"]
        done = endsp[(g["start"] <= t) & (endsp < t)]
        prior.append(int((g["start"] <= t).sum()))
        since.append(float(t - done.max()) if len(done) else np.nan)
    out["crag_prior_spells"] = prior
    out["crag_years_since_default"] = since
    return out


# ------------------------------------------------------------------------------------------------ WEO

def find_weo(data_dir: Path, weo_history: str | Path | None = None) -> tuple[pd.DataFrame | None, dict]:
    """Vintaged WEO long table (iso, series, period, value, vintage) from, in order: --weo-history, data/panel/
    weo_history.csv, the weo_vintages archive (data/panel/weo_vintages/<YYYY-MM>/weo_long.csv), hand-saved release
    files data/panel/staging/weo_cache/weo_<YYYY-MM>.(xls|csv|tsv|txt). Local files only, never the network.
    (None, info) when none is there."""
    from ..rules.hazard import WEO_CODES
    panel = data_dir / "panel"
    cand = [Path(weo_history)] if weo_history else [panel / "weo_history.csv"]
    for p in cand:
        if p.is_file():
            body, sh = read_once(p, "WEO history")
            d = _csv(body, dtype={"iso": str, "series": str, "vintage": str})
            if "vintage" not in d.columns:
                raise PanelInputError(f"{p}: no vintage column; a WEO history must be vintaged (point in time)")
            return d, {"route": "weo_history", "path": str(p), "sha256": sh}
    if weo_history:
        raise PanelInputError(f"WEO history not found: {weo_history}")
    arch = sorted((panel / "weo_vintages").glob("*/weo_long.csv"))
    if arch:
        parts, shas = [], {}
        for p in arch:
            body, shas[p.parent.name] = read_once(p, "WEO vintage")
            d = _csv(body, dtype={"iso3": str, "indicator": str, "vintage": str})
            d = d.rename(columns={"iso3": "iso", "indicator": "series", "year": "period"})
            parts.append(d[d["series"].isin(WEO_CODES)][["iso", "series", "period", "value", "vintage"]])
        return pd.concat(parts, ignore_index=True), {"route": "weo_vintages", "releases": [p.parent.name for p in arch],
                                                     "files": shas}
    from .panel_history import normalise_vintage, parse_weo_tab
    files = sorted(f for f in (panel / "staging" / "weo_cache").glob("weo_*.*")
                   if re.fullmatch(r"weo_\d{4}-\d{2}\.(xls|csv|tsv|txt)", f.name) and f.stat().st_size > 0)
    if files:
        parts, shas = [], {}
        with tempfile.TemporaryDirectory() as tmp:
            for f in files:
                body, shas[f.name] = read_once(f, "WEO release file")
                copy = Path(tmp) / f.name                  # parse exactly the bytes hashed (H-L1)
                copy.write_bytes(body)
                v = normalise_vintage(f.name[4:11])
                parts.append(parse_weo_tab(copy, WEO_CODES).assign(
                    vintage=v, source=f"local file {f.name} sha256:{shas[f.name][:16]}"))
        return (pd.concat(parts, ignore_index=True),
                {"route": "weo_cache", "releases": [f.name[4:11] for f in files], "files": shas})
    return None, {"route": None, "looked_in": [str(c) for c in cand] + [str(panel / "weo_vintages"),
                                                                         str(panel / "staging" / "weo_cache")]}


def weo_features(weo: pd.DataFrame, events: pd.DataFrame, end: int, as_of: str) -> pd.DataFrame:
    """The five WEO features, point in time, through Team B's panel_from_long (one feature at a time, so a row
    missing one feature keeps the others)."""
    from ..validation import hazard_panel as hp
    weo = weo.copy()
    weo["period"] = pd.to_numeric(weo["period"], errors="coerce")
    weo = weo.dropna(subset=["period"])
    vd = hp._vintage_date(weo["vintage"])
    weo = weo[vd.notna() & (vd <= pd.Timestamp(as_of))]             # nothing published after as_of
    out = None
    for f in WEO_FEATURES:
        if not (weo["series"] == hp.PANEL_FEATURES[f][1]).any():
            continue
        x = hp.panel_from_long(weo, None, events, features=[f], start=START, end=end, lag=LAG, as_of=as_of)[["iso", "year", f]]
        out = x if out is None else out.merge(x, on=["iso", "year"], how="outer")
    return out if out is not None else pd.DataFrame(columns=["iso", "year"])


# ------------------------------------------------------------------------------------------------ build

def build(root: str | Path = ROOT, data_dir: str | Path | None = None, as_of: str = AS_OF, *,
          weo_history: str | Path | None = None, paths: dict | None = None, register: list[dict] | None = None,
          write: bool = True) -> dict:
    """Build the panel, columns table, missing map and manifest. Returns {"panel", "columns", "missing_map",
    "manifest"} (DataFrames and dict); writes them under <data>/panel/hazard_panel_wide/ when write."""
    from ..validation import hazard_events as he
    from ..validation.hazard_refit import default_end
    root = Path(root)
    data = Path(data_dir) if data_dir else root / "data"
    as_of = pd.Timestamp(as_of).strftime("%Y-%m-%d")
    src = {k: root / v for k, v in SOURCE_FILES.items()}
    src.update({k: Path(v) for k, v in (paths or {}).items()})
    lic = column_licences(register)

    rule = he.resolve(data, "crag")
    events, ev_info = he.build_events(data, as_of, rule)
    end = default_end(events, as_of)
    uni_p = data / "panel" / "sovereign_defaults_crag_universe.csv"
    uni_body, uni_sha = read_once(uni_p, "CRAG universe")
    uni = _csv(uni_body, dtype={"iso": str})
    uni = uni[uni["iso"].fillna("").str.fullmatch(r"[A-Z]{3}")]
    grid = pd.DataFrame([(r.iso, y) for r in uni.itertuples() for y in range(max(START, int(r.first_year)),
                                                                              min(end, int(r.last_year)) + 1)],
                        columns=["iso", "year"])
    from ..validation.hazard_panel import default_status
    st = default_status(events, range(START, end + 2))
    nxt = st.rename(columns={"starts": "event"})[["iso", "year", "event"]].assign(year=lambda d: d["year"] - 1)
    rows = grid.merge(st[["iso", "year", "in_default"]], on=["iso", "year"], how="left").merge(nxt, on=["iso", "year"], how="left")
    rows = rows[~rows["in_default"].eq(True)].drop(columns="in_default")
    rows["event"] = rows["event"].eq(True).astype(int)
    rows["ever_defaulted"] = rows["iso"].isin(set(events["iso"]))
    rows = rows.sort_values(["iso", "year"]).reset_index(drop=True)

    obs, src_info = observations(src, as_of)
    panel = rows[["iso", "year"]].copy()
    for name, o in obs.items():                                   # row t takes period t - LAG
        o = o.assign(year=o["year"] + LAG).rename(columns={"value": name})
        panel = panel.merge(o, on=["iso", "year"], how="left")
    panel = panel.merge(crag_features(events, rows), on=["iso", "year"], how="left")
    weo, weo_info = find_weo(data, weo_history)
    if weo is not None:
        wf = weo_features(weo, events, end, as_of)
        panel = panel.merge(wf, on=["iso", "year"], how="left")
    for f in WEO_FEATURES:
        if f not in panel.columns:
            panel[f] = np.nan
    names = [p.name for p in PREDICTORS]
    panel = panel[["iso", "year", *names]].merge(rows, on=["iso", "year"])
    countable = [n for n in names if n != "crag_years_since_default"]
    panel["n_present"] = panel[countable].notna().sum(axis=1).astype(int)

    columns = columns_table(panel, lic, src_info, weo_info)
    mm = missing_map(panel)
    non_weo_cells = panel[[n for n in NON_WEO if n != "crag_years_since_default"]]
    manifest = {
        "schema": SCHEMA, "ticket": "EQ-A-0140", "as_of": as_of, "lag": LAG, "start": START, "end": int(end),
        "rows": int(len(panel)), "countries": int(panel["iso"].nunique()),
        "years": [int(panel["year"].min()), int(panel["year"].max())], "events": int(panel["event"].sum()),
        "events_per_label_year": {int(k) + 1: int(v) for k, v in panel.groupby("year")["event"].sum().items() if v},
        "ever_defaulted_share": round(float(panel.drop_duplicates("iso")["ever_defaulted"].mean()), 4),
        "predictors": len(names), "predictors_non_weo": len(NON_WEO), "weo_present": weo is not None,
        "coverage_non_weo_cells": round(float(non_weo_cells.notna().to_numpy().mean()), 4),
        "coverage_all_cells": round(float(panel[countable].notna().to_numpy().mean()), 4),
        "event_rule": {k: v for k, v in ev_info.items() if k != "path"} | {"path": _rel(ev_info.get("path"), root)},
        "event_definition": "event = 1 when a crag_v1 default spell (BoC-BoE CRAG, FC bank loans + FC bonds + LC debt "
                            "above USD 10m, 2-year cure) starts in year+1; rows inside a spell are not at risk",
        "inputs": {k: {**v, "path": _rel(v["path"], root)} for k, v in src_info.items()},
        "crag": {"episodes": _rel(str(data / "panel" / "sovereign_defaults_crag.csv"), root),
                 "episodes_sha256": sha256(data / "panel" / "sovereign_defaults_crag.csv"),
                 "universe": _rel(str(uni_p), root), "universe_sha256": uni_sha,
                 "episodes_note": "episodes are read by hazard_events.build_events (Team B); their raw CRAG file is "
                                  "checked there against the sha256 named in the episode file"},
        "weo": weo_info if weo is None else {k: v for k, v in weo_info.items() if k != "path"} | {"path": _rel(weo_info.get("path"), root)},
        "not_on_disk": {"cruces_trebesch_haircuts": f"{CT_HAIRCUTS} not dropped (EQ-A-0098); no predictor taken",
                        "weo_history": None if weo is not None else "deferred by Sam (EQ-A-0087)"},
        "licence": {"folder_row": LICENCE_ROW, "client_output": "restricted", "internal_only": True},
        "synthetic": any(v.get("synthetic") for v in src_info.values()),
        "command": f"python -m econquest.ingestion.hazard_panel_wide build --as-of {as_of}",
    }
    if write:
        out = output_dir(data)
        manifest["out"] = str(out)
        write_folder(out, {"panel.csv": panel.to_csv(index=False, float_format="%.10g"),
                           "columns.csv": columns.to_csv(index=False), "missing_map.csv": mm.to_csv(index=False),
                           "manifest.json": json.dumps({k: v for k, v in manifest.items() if k != "out"},
                                                       indent=1, default=str) + "\n"})
    return {"panel": panel, "columns": columns, "missing_map": mm, "manifest": manifest}


def output_dir(data: Path) -> Path:
    """<data>/panel/hazard_panel_wide, refused when it or panel/ is a link or resolves outside data/ (SEC-A-016 H-L2)."""
    out = Path(data) / OUT_REL
    for p in (out.parent, out):
        if p.is_symlink():
            raise PanelInputError(f"{p} is a link: refusing to write through it")
    base = Path(data).resolve()
    if not str(out.resolve()).startswith(str(base) + os.sep):
        raise PanelInputError(f"{out} resolves outside {base}")
    return out


def write_folder(out: Path, files: dict[str, str]) -> None:
    """Write all files into a temp sibling, then swap it into place: an interrupted build never leaves a mixed set
    (SEC-A-016 H-L2, as mvp_dataset.build does)."""
    out.parent.mkdir(parents=True, exist_ok=True)
    # work folders are named <name>.tmp-* / <name>.old-*: mvp_dataset never freezes them (a SIGKILL can leave one)
    if out.name != OUT_REL.name:
        raise PanelInputError(f"write_folder writes {OUT_REL.name} only (work-folder names are excluded by that name)")
    tmp = Path(tempfile.mkdtemp(prefix=WORK_TMP, dir=out.parent))
    old = out.parent / f"{WORK_OLD}{os.getpid()}"
    try:
        for name, text in files.items():
            (tmp / name).write_text(text, encoding="utf-8")
        # a folder needs x to be listed: 0755 is the normal data/ folder mode (mkdtemp creates 0700)
        os.chmod(tmp, 0o755)  # nosec B103
        if old.exists():
            shutil.rmtree(old)
        if out.exists():
            out.rename(old)
        tmp.rename(out)
        if old.exists():
            shutil.rmtree(old)
    except BaseException:
        if not out.exists() and old.exists():
            old.rename(out)                                   # put the previous complete set back
        shutil.rmtree(tmp, ignore_errors=True)
        raise


ASSEMBLED = "weo_history_assembled.csv"


def record_assembled(out: Path, body: bytes) -> str:
    """Write weo_history_assembled.csv (temp + os.replace) and record it in manifest.json ("weo_assembled": file,
    sha256, bytes), the manifest also replaced atomically. Returns the sha256."""
    sh = hashlib.sha256(body).hexdigest()
    for name, data in ((ASSEMBLED, body), ("manifest.json", None)):
        if data is None:
            man = json.loads((out / "manifest.json").read_text(encoding="utf-8"))
            man["weo_assembled"] = {"file": ASSEMBLED, "sha256": sh, "bytes": len(body)}
            data = (json.dumps(man, indent=1, default=str) + "\n").encode("utf-8")
        fd, tmp = tempfile.mkstemp(prefix=f".{name}.", dir=out)
        with os.fdopen(fd, "wb") as f:
            f.write(data)
        os.chmod(tmp, 0o644)
        os.replace(tmp, out / name)
    return sh


def _rel(p, root: Path):
    if p is None:
        return None
    try:
        return str(Path(p).resolve().relative_to(root.resolve()))
    except ValueError:
        return str(p)


def columns_table(panel: pd.DataFrame, lic: dict, src_info: dict, weo_info: dict) -> pd.DataFrame:
    rows = []
    for p in PREDICTORS:
        v = panel[p.name]
        if p.source == "weo":
            f, sh = weo_info.get("path") or weo_info.get("route") or "not landed", weo_info.get("sha256", "")
        elif p.source == "crag":
            f, sh = CRAG_EPISODES, ""
        else:
            f, sh = SOURCE_FILES[p.source], src_info[p.source]["sha256"]
        rows.append({"column": p.name, "source": p.source, "source_file": f, "source_sha256": sh, "series": p.series,
                     "transform": p.transform, "aggregation": p.agg, "lag": LAG if p.source != "crag" else 0,
                     **lic[p.name],
                     "point_in_time": ("yes (WEO vintages)" if p.source == "weo" else
                                       "yes (spells known by t)" if p.source == "crag" else "no (latest published values)"),
                     "weo_fill": p.weo_fill, "fill_group": fill_group(p), "fill_source": fill_source(p), "note": p.note,
                     "economies": int(panel.loc[v.notna(), "iso"].nunique()),
                     "first_year": int(panel.loc[v.notna(), "year"].min()) if v.notna().any() else None,
                     "last_year": int(panel.loc[v.notna(), "year"].max()) if v.notna().any() else None,
                     "rows_present": int(v.notna().sum()), "coverage": round(float(v.notna().mean()), 4),
                     "events_covered": int(panel.loc[v.notna(), "event"].sum())})
    return pd.DataFrame(rows)


FILL_GROUPS = ("weo", "wb_pull", "bis_pull", "gpr_file", "no_source")   # missing_map columns, in this order


def fill_group(p: Predictor) -> str:
    """Which source would fill a gap in this predictor: WEO first (the deferred history), then a wider World Bank
    pull, a wider BIS pull, the full GPR country file, or nothing known."""
    if p.weo_fill:
        return "weo"
    if p.fill_note == WB_FULL:
        return "wb_pull"
    return {"bis": "bis_pull", "gpr": "gpr_file"}.get(p.source, "no_source")


def fill_source(p: Predictor) -> str:
    if p.source == "weo":
        return f"WEO {p.weo_fill} (vintaged WEO history; deferred, EQ-A-0087)"
    if p.weo_fill:
        return f"WEO {p.weo_fill}; or {p.fill_note}"
    return p.fill_note or "no other source on disk"


def missing_map(panel: pd.DataFrame) -> pd.DataFrame:
    """One row per country-year: counts, present predictors, and the missing ones split by the source that would
    fill them (fill_<group>; the text of each source is fill_source in columns.csv). crag_years_since_default is
    not_applicable, not missing, for an economy with no earlier spell."""
    names = [p.name for p in PREDICTORS]
    pres = panel[names].notna().to_numpy()
    grp = {p.name: fill_group(p) for p in PREDICTORS}
    out = []
    for i, (iso, y) in enumerate(zip(panel["iso"], panel["year"])):
        present = [n for n, ok in zip(names, pres[i]) if ok]
        na = [n for n, ok in zip(names, pres[i]) if not ok and n == "crag_years_since_default"]
        miss = [n for n, ok in zip(names, pres[i]) if not ok and n not in na]
        r = {"iso": iso, "year": int(y), "event": int(panel["event"].iat[i]), "n_present": len(present),
             "n_missing": len(miss), "n_weo_fillable": sum(grp[n] == "weo" for n in miss), "present": ";".join(present),
             "not_applicable": ";".join(na)}
        r.update({f"fill_{g}": ";".join(n for n in miss if grp[n] == g) for g in FILL_GROUPS})
        out.append(r)
    return pd.DataFrame(out)


# ------------------------------------------------------------------------------------------------ CLI

def refit_argv(manifest: dict, data_dir: Path, out: str | None = None, author: str | None = None) -> list[str]:
    weo = manifest["weo"]
    path = weo.get("path") if weo.get("route") == "weo_history" else None
    if path is None:
        path = str(data_dir / OUT_REL / "weo_history_assembled.csv")
    argv = ["--data", str(data_dir), "--as-of", manifest["as_of"], "--events", "crag", "--weo-history", path]
    return argv + (["--out", out] if out else []) + (["--author", author] if author else [])


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.hazard_panel_wide", description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("build", help="build panel.csv, columns.csv, missing_map.csv, manifest.json (no network)")
    b.add_argument("--data", default="data"); b.add_argument("--as-of", default=AS_OF)
    b.add_argument("--weo-history", help="vintaged WEO long CSV (default: data/panel/weo_history.csv, then the "
                                         "weo_vintages archive, then staging/weo_cache/weo_<YYYY-MM>.xls)")
    b.add_argument("--refit", action="store_true", help="then run Team B's hazard_refit --events crag on the WEO history "
                                                         "(only when WEO is present)")
    b.add_argument("--refit-out", help="--out for the refit (default: hazard_refit's own)")
    b.add_argument("--author", help="passed to hazard_refit --author (the name in its drafted propose command)")
    sub.add_parser("sources", help="list inputs and whether each is on disk")
    a = ap.parse_args(argv)
    if a.cmd == "sources":
        for k, v in {**SOURCE_FILES, "crag": CRAG_EPISODES, "crag_universe": CRAG_UNIVERSE, "cruces_trebesch": CT_HAIRCUTS,
                     "weo_history": "data/panel/weo_history.csv", "weo_cache": "data/panel/staging/weo_cache"}.items():
            print(f"{k:16s} {'on disk' if (ROOT / v).exists() else 'MISSING':8s} {v}")
        return 0
    data = Path(a.data)
    try:
        r = build(ROOT, data, a.as_of, weo_history=a.weo_history)
    except PanelInputError as e:
        print(f"INPUT ERROR: {e}", file=sys.stderr)
        return EXIT["INPUT_ERROR"]
    m = r["manifest"]
    print(f"panel: {m['rows']:,} rows, {m['countries']} countries, {m['years'][0]}-{m['years'][1]}, {m['events']} events, "
          f"{m['predictors']} predictors ({m['predictors_non_weo']} non-WEO), non-WEO cell coverage "
          f"{100 * m['coverage_non_weo_cells']:.1f}%, WEO {'present' if m['weo_present'] else 'not landed'} -> {m.get('out')}")
    if not a.refit:
        return 0
    if not m["weo_present"]:
        print("REFIT NOT RUN: no WEO history found (see manifest.json 'weo.looked_in'); drop the files first", file=sys.stderr)
        return EXIT["NO_WEO"]
    if m["weo"]["route"] != "weo_history":                  # hazard_refit reads one long CSV: write the assembled one
        weo, _ = find_weo(data)
        record_assembled(output_dir(data), weo.to_csv(index=False).encode("utf-8"))
    from ..validation import hazard_refit
    argv2 = refit_argv(m, data, a.refit_out, a.author)
    print("refit: python -m econquest.validation.hazard_refit " + " ".join(argv2))
    return hazard_refit.main(argv2)


if __name__ == "__main__":
    raise SystemExit(main())
