"""`crag update`: refresh the BoC-BoE sovereign default database (CRAG) from a new file (EQ-A-0069).

Sam asked on 2026-10-24 18:57Z to update the BoC-BoE database from the GUI and the CLI. This module is the one
implementation both use; Team C wires `econquest crag update` and the GUI button to `crag_update()`.

    python -m econquest.ingestion.crag_update --file ~/Downloads/DEBT_2026.csv            # dry run
    python -m econquest.ingestion.crag_update --file ~/Downloads/DEBT_2026.csv --apply    # replace the live CRAG file
    python -m econquest.ingestion.crag_update --fetch                                     # UNVERIFIED: prints the page, exit 2

Steps (runbook: docs/runbooks/A-crag-update.md):

1. Check the input: `.csv` (Bank of Canada Valet export) or `.xlsx`/`.xlsm` (the BoC-BoE workbook), not empty,
   at most MAX_INPUT_BYTES, an xlsx must be a real zip workbook, a CSV must be UTF-8 text without NUL bytes.
2. Import it with `default_panel.import_crag` (the EQ-A-0008 parsers, not a copy) into a new run folder
   `<panel>/staging/crag/updates/<UTC run id>/`, then, only if it has at least one episode, save it as an
   append-only panel vintage (`default_panel.save_crag_vintage`; identical content is not stored twice). The vintage's
   crag_import.json carries `licence_status` (UNVERIFIED) and `licence_basis`.
3. Diff against what --apply would replace (`diff_base`): the newest other CRAG vintage holding exactly the live
   sovereign_defaults_crag.csv, or the live file itself when no vintage holds it; only with no live file, the newest
   other CRAG vintage (which may be an unapplied dry run). Episodes added, removed and changed (country, start/end year, type = creditor categories, amount =
   the CRAG peak in USD millions and its year, parsed from the note). Writes `crag_update_diff.csv`,
   `crag_update_summary.md`, `crag_update.json` and the comparison with the memory list to the run folder and
   returns a one-screen text summary.
4. Only with `apply=True`, and only after the diff, replace `<panel>/sovereign_defaults_crag.csv` and its
   `_universe.csv` and refresh `<panel>/crag_comparison.csv` as one step (`_replace_all`: backups to the run folder,
   temp copies, os.replace each; on a failure the files already replaced are restored). Refused if the live file
   changed since the run started. Without it nothing outside the run folder and the vintage store changes.
   Optional `expect_live_sha256` / `expect_iso_map_sha256` (HO-20261025-C-A-003, SEC-C-017 R51) bind the apply to a
   dry run: under the apply lock, if the live CRAG file or the country map is not the one the caller's dry run saw,
   nothing is replaced and the status is 'changed' (exit 1). Pass the dry run's `live_sha256_before` and
   `iso_map_sha256`; "absent" means that file must not exist.
   `sovereign_defaults.csv` (the memory list the model uses) is never written: swapping it is a Tier 1 decision for
   Sam and Team B. Its hash is checked before and after.

`--fetch` downloads through `sources.https_get` (https only, redirects refused, size cap) from an allow-listed host,
but only from a URL recorded as verified in FETCH_URL_VERIFIED. No BoC endpoint has been verified from this repo (the
cloud proxy refuses bankofcanada.ca), so it is None and `--fetch` prints the page to download from and exits 2.

Exit codes: 0 done (dry run or applied), 1 refused or changed (bad or corrupt file, unmapped countries, bad arguments,
live file or country map not the one the dry run saw),
2 fetch not available (download by hand from the printed page).
"""
from __future__ import annotations

import argparse
import datetime as dt
import json
import os
import re
import shutil
import sys
import tempfile
import urllib.error
import urllib.parse
import zipfile
from pathlib import Path

import pandas as pd

from ..common_format import escape_formula
from . import default_panel as dp
from .panel_history import list_panel_vintages
from .safe_zip import ZipBudgetExceeded, check_zip_budget
from .sources import https_get

PANEL_DIR = dp.REPO_DATA / "panel"
LIVE_NAME = "sovereign_defaults_crag.csv"
UNIVERSE_NAME = "sovereign_defaults_crag_universe.csv"
MEMORY_NAME = "sovereign_defaults.csv"          # the memory list the model uses: never written here
IMPORT_META = "crag_import.json"
ISO_MAP_NAME = "crag_iso_map.csv"
COMPARISON_NAME = "crag_comparison.csv"
RUNS_SUBDIR = Path("staging") / "crag" / "updates"
FETCH_SUBDIR = Path("staging") / "crag" / "fetched"

ALLOWED_SUFFIXES = {".csv": "csv", ".xlsx": "xlsx", ".xlsm": "xlsx"}
MAX_INPUT_BYTES = 50 * 2**20                    # DEBT_2026.csv is 2.4 MB

# --fetch (UNVERIFIED). Hosts and candidate URLs are from data/panel/README.md (documentation reading); none was
# fetched from this repo's environments. Set FETCH_URL_VERIFIED only after a successful download on Sam's Mac is
# recorded (runbook "Turning on --fetch").
FETCH_HOSTS = frozenset({"www.bankofcanada.ca"})
FETCH_PAGE = "https://www.bankofcanada.ca/2026/10/staff-analytical-paper-2026-48/"
FETCH_CANDIDATES = ("https://www.bankofcanada.ca/valet/observations/group/DEBT_2026/csv",
                    "https://www.bankofcanada.ca/wp-content/uploads/2026/10/BoC-BoE-Database-2026.xlsx")
FETCH_URL_VERIFIED: str | None = None
FETCH_MAX_BYTES = MAX_INPUT_BYTES
FETCH_TIMEOUT = 60.0

# Licence (point 6 of the ticket): no repo document records the BoC-BoE terms. The Valet export names the Bank of
# Canada terms page, which was not read from this environment.
LICENCE_STATUS = "UNVERIFIED"
TERMS_URL = "https://www.bankofcanada.ca/terms/"
LICENCE_BASIS = (f"BoC-BoE terms of use not recorded in the repo; the Valet export names {TERMS_URL} (not read). "
                 "Sam or AGENT-09 to confirm internal use and data-room redistribution.")

EXIT_OK, EXIT_REFUSED, EXIT_FETCH = 0, 1, 2
DIFF_COLS = ["status", "iso", "country", "old_start", "old_end", "new_start", "new_end", "old_type", "new_type",
             "old_amount_usd_m", "new_amount_usd_m", "old_peak_year", "new_peak_year", "changed_fields"]
PEAK_RE = re.compile(r"CRAG peak ([\d,]+(?:\.\d+)?) in (\d{4})")
SCREEN_ROWS = 12


class Refused(ValueError):
    """The input or the request is refused; nothing live was changed."""


class Changed(Refused):
    """--apply with expect_live_sha256 / expect_iso_map_sha256: the live CRAG file or the country map is not the one
    the caller's dry run saw (HO-20261025-C-A-003). Status 'changed', exit 1; nothing live was changed."""


ABSENT = "absent"                                   # expect_*_sha256 value: the file must not exist
SHA256_RE = re.compile(r"[0-9a-f]{64}")


def _sha_or_absent(path: Path) -> str:
    return dp.checksum(path) if path.is_file() else ABSENT


def _check_expect(name: str, value: str | None) -> str | None:
    if value is None:
        return None
    if not isinstance(value, str) or not (value == ABSENT or SHA256_RE.fullmatch(value)):
        raise Refused(f"{name} must be a lowercase 64-hex sha256 or '{ABSENT}'")
    return value


class FetchUnavailable(RuntimeError):
    """--fetch cannot run (no verified URL, or the download failed): download by hand from FETCH_PAGE."""


# ---------------------------------------------------------------------------------------------------- input checks

def check_input(path: str | Path) -> str:
    """Return 'csv' or 'xlsx' for a usable file, else raise Refused (point 7: a corrupt file is refused)."""
    p = Path(path)
    if not p.is_file():
        raise Refused(f"file not found: {p}")
    fmt = ALLOWED_SUFFIXES.get(p.suffix.lower())
    if fmt is None:
        raise Refused(f"{p.name}: expected a Valet .csv or a BoC-BoE .xlsx workbook, got '{p.suffix}'")
    size = p.stat().st_size
    if size == 0:
        raise Refused(f"{p.name} is empty")
    if size > MAX_INPUT_BYTES:
        raise Refused(f"{p.name} is {size:,} bytes, over the {MAX_INPUT_BYTES:,}-byte cap")
    if fmt == "xlsx":
        try:
            with zipfile.ZipFile(p) as z:
                if "xl/workbook.xml" not in z.namelist():
                    raise Refused(f"{p.name} is a zip file but not an Excel workbook (no xl/workbook.xml)")
                try:
                    check_zip_budget(z)                                # SEC-A-010 L1: before testzip decompresses
                except ZipBudgetExceeded as e:
                    raise Refused(f"{p.name} refused: {e}") from None
                bad = z.testzip()
        except zipfile.BadZipFile as e:
            raise Refused(f"{p.name} is not a valid xlsx workbook (corrupt or truncated zip: {e})") from None
        if bad:
            raise Refused(f"{p.name} is corrupt: member {bad} fails its CRC check")
    else:
        data = p.read_bytes()
        if b"\x00" in data:
            raise Refused(f"{p.name} contains NUL bytes: not a CSV text file (binary or corrupt)")
        try:
            data.decode("utf-8-sig")
        except UnicodeDecodeError as e:
            raise Refused(f"{p.name} is not UTF-8 text (byte {e.start}): not a Valet CSV export") from None
    return fmt


# ---------------------------------------------------------------------------------------------------- vintages

def crag_vintages(panel_dir: str | Path) -> list[str]:
    """Panel vintages (oldest first) that hold a CRAG import (sovereign_defaults_crag.csv and crag_import.json)."""
    root = Path(panel_dir) / "vintages"
    return [v for v in list_panel_vintages(panel_dir) if (root / v / LIVE_NAME).is_file() and (root / v / IMPORT_META).is_file()]


def _previous(vintages: list[str], new_id: str) -> str | None:
    older = [v for v in vintages if v != new_id]
    return older[-1] if older else None


def diff_base(panel_dir: str | Path, new_id: str, live_sha: str | None, warnings: list[str]) -> tuple[str | None, Path | None]:
    """(previous vintage id, file to diff against). The diff must describe what --apply would replace, so with a
    live CRAG file the base is the newest other vintage holding exactly the live file, or the live file itself
    when no vintage holds it (edited by hand). Only without a live file is it the newest other CRAG vintage, which
    may be a dry run that was never applied (AGENT-05 review of EQ-A-0069)."""
    panel = Path(panel_dir)
    root, live = panel / "vintages", panel / LIVE_NAME
    vints = crag_vintages(panel)
    if live_sha is None:
        prev = _previous(vints, new_id)
        return prev, (root / prev / LIVE_NAME if prev else None)
    if new_id in vints and dp.checksum(root / new_id / LIVE_NAME) == live_sha:
        return new_id, live                                          # re-import of the live content: nothing to apply
    match = [v for v in vints if v != new_id and dp.checksum(root / v / LIVE_NAME) == live_sha]
    if match:
        return match[-1], root / match[-1] / LIVE_NAME
    newest = _previous(vints, new_id)
    warnings.append(f"the live {LIVE_NAME} matches no stored CRAG vintage (edited by hand?): compared with the live file"
                    + (f"; newest other vintage is {newest}" if newest else ""))
    return None, live


# ---------------------------------------------------------------------------------------------------- diff

def load_episodes(path: str | Path | None) -> pd.DataFrame:
    """Episodes of a CRAG episode file with type (creditors) and amount (CRAG peak, USD millions) columns."""
    cols = ["iso", "country", "start", "end", "type", "amount_usd_m", "peak_year"]
    if path is None:
        return pd.DataFrame(columns=cols)
    d = pd.read_csv(path, comment="#", dtype={"iso": str, "country": str, "creditors": str, "note": str})
    d["iso"] = d["iso"].astype(str).str.upper().str.strip()
    d["start"] = d["start"].astype(int)
    d["end"] = d["end"].astype(int)
    d["country"] = d["country"].fillna("") if "country" in d else ""
    d["type"] = d["creditors"].fillna("").astype(str).str.strip() if "creditors" in d else ""
    peak = d["note"].fillna("").astype(str).str.extract(PEAK_RE) if "note" in d else pd.DataFrame(index=d.index, columns=[0, 1])
    d["amount_usd_m"] = pd.to_numeric(peak[0].str.replace(",", "", regex=False), errors="coerce")
    d["peak_year"] = pd.to_numeric(peak[1], errors="coerce").astype("Int64")
    return d[cols].sort_values(["iso", "start", "end"]).reset_index(drop=True)


def _row(status, iso, a, b, fields=()):
    return {"status": status, "iso": iso, "country": (b or a)["country"],
            "old_start": a["start"] if a else None, "old_end": a["end"] if a else None,
            "new_start": b["start"] if b else None, "new_end": b["end"] if b else None,
            "old_type": a["type"] if a else None, "new_type": b["type"] if b else None,
            "old_amount_usd_m": a["amount_usd_m"] if a else None, "new_amount_usd_m": b["amount_usd_m"] if b else None,
            "old_peak_year": a["peak_year"] if a else None, "new_peak_year": b["peak_year"] if b else None,
            "changed_fields": ";".join(fields)}


def _changes(a: dict, b: dict) -> list[str]:
    f = [k for k in ("start", "end", "type") if a[k] != b[k]]
    am, bm = a["amount_usd_m"], b["amount_usd_m"]
    if (pd.isna(am) != pd.isna(bm)) or (not pd.isna(am) and round(float(am)) != round(float(bm))):
        f.append("amount")
    return f


def diff_episodes(old: pd.DataFrame, new: pd.DataFrame, tolerance: int = 1) -> tuple[pd.DataFrame, int]:
    """(differences, unchanged count). Spells of one ISO3 code pair first on identical years, then on overlapping
    years or years within `tolerance` (default_panel's pairing rule), closest first. A pair whose years, type or
    amount differ is 'changed'; an unpaired old spell is 'removed', an unpaired new spell 'added'."""
    rows, same = [], 0
    for iso in sorted(set(old["iso"]) | set(new["iso"])):
        o = old[old["iso"] == iso].to_dict("records")
        n = new[new["iso"] == iso].to_dict("records")
        pairs, used_o, used_n = [], set(), set()
        for i, a in enumerate(o):                                   # identical years first
            j = next((j for j, b in enumerate(n) if j not in used_n and (b["start"], b["end"]) == (a["start"], a["end"])), None)
            if j is not None:
                pairs.append((i, j)); used_o.add(i); used_n.add(j)
        cand = sorted((abs(a["start"] - b["start"]) + abs(a["end"] - b["end"]), i, j)
                      for i, a in enumerate(o) if i not in used_o for j, b in enumerate(n)
                      if j not in used_n and dp._overlap((a["start"], a["end"]), (b["start"], b["end"]), tolerance))
        for _, i, j in cand:                                        # then overlapping, closest first
            if i not in used_o and j not in used_n:
                pairs.append((i, j)); used_o.add(i); used_n.add(j)
        for i, j in pairs:
            f = _changes(o[i], n[j])
            if f:
                rows.append(_row("changed", iso, o[i], n[j], f))
            else:
                same += 1
        rows += [_row("removed", iso, a, None) for i, a in enumerate(o) if i not in used_o]
        rows += [_row("added", iso, None, b) for j, b in enumerate(n) if j not in used_n]
    order = {"removed": 0, "changed": 1, "added": 2}
    df = pd.DataFrame(rows, columns=DIFF_COLS)
    if len(df):
        df = df.assign(_o=df["status"].map(order), _s=df["new_start"].fillna(df["old_start"]))
        df = df.sort_values(["iso", "_s", "_o"], kind="stable").drop(columns=["_o", "_s"]).reset_index(drop=True)
    return df, same


def _records(df: pd.DataFrame) -> list[dict]:
    out = []
    for r in df.to_dict("records"):
        rec = {}
        for k, v in r.items():
            if v is None or (not isinstance(v, str) and pd.isna(v)):
                rec[k] = None
            elif hasattr(v, "item"):
                rec[k] = v.item()
            else:
                rec[k] = v
        for k in ("old_start", "old_end", "new_start", "new_end", "old_peak_year", "new_peak_year"):
            if rec.get(k) is not None:
                rec[k] = int(rec[k])
        out.append(rec)
    return out


# ---------------------------------------------------------------------------------------------------- fetch

def fetch_latest(dest_dir: str | Path, url: str | None = None) -> Path:
    """Download the BoC-BoE file to a new file in dest_dir and return its path. Only from a verified URL
    (`url` or FETCH_URL_VERIFIED) on an allow-listed host, through sources.https_get (https, no redirects, size
    cap). Raises FetchUnavailable when no URL is verified or the download fails; never overwrites a file."""
    url = url or FETCH_URL_VERIFIED
    if not url:
        raise FetchUnavailable("no verified Bank of Canada download URL is recorded (FETCH_URL_VERIFIED is unset)")
    parts = urllib.parse.urlsplit(url)
    if parts.scheme != "https":
        raise FetchUnavailable(f"refusing non-https URL ({parts.scheme}://{parts.hostname})")
    if parts.port or parts.username or parts.password:
        raise FetchUnavailable("refusing a URL with a port or user info")
    if parts.hostname not in FETCH_HOSTS:
        raise FetchUnavailable(f"host {parts.hostname!r} is not on the allow-list {sorted(FETCH_HOSTS)}")
    segs = [s for s in parts.path.split("/") if s]
    name = segs[-1] if segs else ""
    if name.lower() == "csv" and len(segs) >= 2:                  # Valet: .../group/<GROUP>/csv
        name = f"{segs[-2]}.csv"
    name = re.sub(r"[^A-Za-z0-9_.-]", "_", name).lstrip(".")
    if Path(name).suffix.lower() not in ALLOWED_SUFFIXES:
        raise FetchUnavailable(f"URL does not name a .csv or .xlsx file: {parts.path}")
    try:
        body = https_get(url, headers={"User-Agent": "econquest-crag-update"}, timeout=FETCH_TIMEOUT,
                         max_bytes=FETCH_MAX_BYTES)
    except (urllib.error.URLError, OSError, ValueError) as e:     # HTTPError/RedirectRefused are URLError; cap is ValueError
        raise FetchUnavailable(f"download from {parts.hostname}{parts.path} failed: {type(e).__name__}: {e}") from None
    dest = Path(dest_dir)
    dest.mkdir(parents=True, exist_ok=True)
    target = dest / name
    with open(target, "xb") as f:                                  # never overwrite
        f.write(body)
    return target


def fetch_help() -> str:
    cands = "\n".join(f"  {u}" for u in FETCH_CANDIDATES)
    return (f"--fetch is not available: no Bank of Canada download URL has been verified (licence {LICENCE_STATUS}).\n"
            f"Download the file by hand from:\n  {FETCH_PAGE}\n"
            f"Candidate files named in data/panel/README.md (UNVERIFIED):\n{cands}\n"
            "then run: python -m econquest.ingestion.crag_update --file <downloaded file>")


# ---------------------------------------------------------------------------------------------------- summaries

def _rel(p, base: Path) -> str:
    try:
        return str(Path(p).resolve().relative_to(base.resolve()))
    except ValueError:
        return str(p)


def _years(r, side):
    s, e = r[f"{side}_start"], r[f"{side}_end"]
    return f"{s}" if s == e else f"{s}-{e}"


def _amount(v) -> str:
    return "" if v is None or pd.isna(v) else f"{float(v):,.0f}"


def _line(r: dict) -> str:
    if r["status"] == "added":
        return f"  + {r['iso']} {r['country']} {_years(r, 'new')} {r['new_type']} {_amount(r['new_amount_usd_m'])}".rstrip()
    if r["status"] == "removed":
        return f"  - {r['iso']} {r['country']} {_years(r, 'old')} {r['old_type']} {_amount(r['old_amount_usd_m'])}".rstrip()
    return (f"  ~ {r['iso']} {r['country']} {_years(r, 'old')} -> {_years(r, 'new')} [{r['changed_fields']}]"
            + (f" {r['old_type']} -> {r['new_type']}" if "type" in r["changed_fields"] else "")
            + (f" {_amount(r['old_amount_usd_m'])} -> {_amount(r['new_amount_usd_m'])}" if "amount" in r["changed_fields"] else ""))


def summary_text(res: dict) -> str:
    """One-screen summary (about 25 lines) for the CLI and the GUI."""
    base = dp.REPO_DATA.parent
    if res["status"] in ("refused", "changed", "fetch_unavailable", "error"):
        return f"crag update (EQ-A-0069): {res['status'].upper()}\n{res['message']}\nLive files not changed."
    c = res["counts"]
    head = "APPLIED - live CRAG file replaced" if res["status"] == "applied" else "DRY RUN - live file not changed"
    lines = [f"crag update (EQ-A-0069): {head}",
             f"input     {Path(res['input']).name} ({res['format']}, sha256 {res['input_sha256'][:12]})",
             f"vintage   new {res['new_vintage']} ({'created' if res['new_vintage_created'] else 'already stored'})"
             f" | previous {res['previous_vintage'] or 'none'}",
             f"episodes  {c['episodes']} in {c['countries']} countries (previous {c['previous_episodes']})",
             f"changes   +{c['added']} added  -{c['removed']} removed  ~{c['changed']} changed  {c['unchanged']} unchanged",
             f"licence   BoC-BoE terms {res['licence']['licence_status']} ({TERMS_URL} not read)"]
    rows = res.get("diff_rows", [])
    lines += [_line(r) for r in rows[:SCREEN_ROWS]]
    if len(rows) > SCREEN_ROWS:
        lines.append(f"  ... and {len(rows) - SCREEN_ROWS} more (see the diff CSV)")
    lines += [f"warning   {w}" for w in res.get("warnings", [])]
    lines += [f"diff      {_rel(res['files']['diff_csv'], base)}", f"summary   {_rel(res['files']['summary_md'], base)}"]
    if res["status"] == "applied":
        lines.append(f"live      {_rel(res['live_file'], base)} sha256 {res['live_sha256_after'][:12]} "
                     f"(was {(res['live_sha256_before'] or 'absent')[:12]})")
    else:
        lines.append(f"next      review the diff, then rerun with --apply to replace {_rel(res['live_file'], base)}")
    lines.append(f"memory    {MEMORY_NAME} unchanged (swapping it is Tier 1: Sam and Team B)")
    return "\n".join(lines)


def summary_markdown(res: dict, diff: pd.DataFrame) -> str:
    c = res["counts"]
    base = dp.REPO_DATA.parent
    md = [f"# CRAG update {res['run_id']}", "",
          f"EQ-A-0069 `crag_update`, {res['status'].replace('_', ' ')}. Generated from the two vintages below; no number typed by hand.", "",
          f"- Input: `{Path(res['input']).name}` ({res['format']}), sha256 `{res['input_sha256']}`.",
          f"- New vintage: `{res['new_vintage']}` ({'created' if res['new_vintage_created'] else 'identical content already stored'}).",
          f"- Previous CRAG vintage: `{res['previous_vintage'] or 'none'}`.",
          f"- Licence: BoC-BoE terms **{res['licence']['licence_status']}**. {res['licence']['licence_basis']}",
          f"- Live file `{_rel(res['live_file'], base)}`: "
          + ("replaced (`--apply`)." if res["status"] == "applied" else "not changed (dry run)."),
          f"- `{MEMORY_NAME}` (memory list used by the model): not changed; swapping it is a Tier 1 decision.", "",
          "| | count |", "|---|---|",
          f"| previous episodes | {c['previous_episodes']} |", f"| new episodes | {c['episodes']} in {c['countries']} countries |",
          f"| added | {c['added']} |", f"| removed | {c['removed']} |", f"| changed | {c['changed']} |",
          f"| unchanged | {c['unchanged']} |", ""]
    if res.get("warnings"):
        md += ["## Warnings", ""] + [f"- {w}" for w in res["warnings"]] + [""]
    if len(diff):
        md += ["## Differences", "", "Type = creditor categories in default; amount = CRAG peak in USD millions (year).", "",
               "| status | iso | country | old years | new years | old type | new type | old amount | new amount | changed |",
               "|---|---|---|---|---|---|---|---|---|---|"]
        for r in _records(diff)[:200]:
            oy = _years(r, "old") if r["old_start"] is not None else ""
            ny = _years(r, "new") if r["new_start"] is not None else ""
            oa = f"{_amount(r['old_amount_usd_m'])} ({r['old_peak_year']})" if r["old_amount_usd_m"] is not None else ""
            na = f"{_amount(r['new_amount_usd_m'])} ({r['new_peak_year']})" if r["new_amount_usd_m"] is not None else ""
            cells = [r["status"], r["iso"], r["country"], oy, ny, r["old_type"] or "", r["new_type"] or "", oa, na, r["changed_fields"]]
            md.append("| " + " | ".join(str(x).replace("|", "/") for x in cells) + " |")
        if len(diff) > 200:
            md.append(f"\n{len(diff) - 200} more rows in `crag_update_diff.csv`.")
    else:
        md.append("No differences.")
    return "\n".join(md) + "\n"


# ---------------------------------------------------------------------------------------------------- main entry

LOCK_NAME = ".crag_update.lock"


class Locked(Refused):
    """Another crag update holds the apply lock."""


class _ApplyLock:
    """Exclusive lock file <panel>/.crag_update.lock (O_CREAT|O_EXCL) around the live-sha check and the replace
    (SEC-A-010 L2). Holds pid, run id and UTC time; removed on exit. A second --apply while it exists is refused."""

    def __init__(self, panel: Path, run_id: str):
        self.path, self.run_id = panel / LOCK_NAME, run_id

    def __enter__(self):
        try:
            fd = os.open(self.path, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        except FileExistsError:
            try:
                holder = self.path.read_text(encoding="utf-8", errors="replace").strip()[:200]
            except OSError:
                holder = "unreadable"
            raise Locked(f"another crag update is applying (lock {self.path}: {holder or 'empty'}); retry. If no update "
                         f"is running, the lock is stale: delete {self.path} (runbook A-crag-update.md)") from None
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(f"pid={os.getpid()} run={self.run_id} utc={dt.datetime.now(dt.timezone.utc):%Y-%m-%dT%H:%M:%SZ}\n")
        return self

    def __exit__(self, *exc):
        self.path.unlink(missing_ok=True)
        return False


def _temp_copy(src: Path, dest: Path, run_id: str) -> Path:
    """Copy src to a new temp file beside dest, named for this run (.<dest>.<run id>.<random>.tmp), fsynced."""
    fd, name = tempfile.mkstemp(dir=dest.parent, prefix=f".{dest.name}.{run_id}.", suffix=".tmp")
    tmp = Path(name)
    try:
        with os.fdopen(fd, "wb") as out, open(src, "rb") as inp:
            shutil.copyfileobj(inp, out)
            out.flush()
            os.fsync(out.fileno())
    except BaseException:
        tmp.unlink(missing_ok=True)
        raise
    return tmp


def _replace_atomic(src: Path, dest: Path, run_id: str) -> None:
    os.replace(_temp_copy(src, dest, run_id), dest)


class RestoreFailed(RuntimeError):
    """--apply failed and a live file could not be put back: restore it by hand from the run folder."""


def _replace_all(pairs: list[tuple[Path, Path]], backup_dir: Path, run_id: str) -> None:
    """Replace every dest with its src as one step: back up the current dests to backup_dir
    (live_before_apply_<name>), copy every src to a per-run temp file beside its dest (the step that can run out of
    space; names carry run_id, so cleanup never deletes another run's temp files),
    then os.replace them in turn. If any step fails, the dests already replaced are put back from the backups (or
    removed if they did not exist) and the temp files deleted, so a failed --apply leaves the live set as it was."""
    backups = {}
    for _src, dest in pairs:
        if dest.is_file():
            backups[dest] = backup_dir / f"live_before_apply_{dest.name}"
            shutil.copyfile(dest, backups[dest])
    tmps, done = [], []
    try:
        for src, dest in pairs:
            tmps.append(_temp_copy(src, dest, run_id))
        for tmp, (_src, dest) in zip(tmps, pairs):
            os.replace(tmp, dest)
            done.append(dest)
    except BaseException:
        try:
            for dest in done:
                if dest in backups:
                    _replace_atomic(backups[dest], dest, run_id)
                else:
                    dest.unlink(missing_ok=True)
        except OSError as e:
            raise RestoreFailed(f"--apply failed and {dest.name} could not be restored ({e}): copy "
                                f"{backups.get(dest, '(no backup: delete it)')} back by hand") from e
        finally:
            for tmp in tmps:
                tmp.unlink(missing_ok=True)
        raise


def _portable(res: dict, panel: Path) -> dict:
    """The result as written to crag_update.json (SEC-A-010 I1): the input by basename (with its sha256), every other
    path relative to the panel folder, never an absolute path such as /Users/<name>/Downloads/... The returned dict
    keeps full paths for the caller."""
    def rel(v):
        if not v:
            return v
        try:
            return Path(v).resolve().relative_to(panel.resolve()).as_posix()
        except ValueError:
            return Path(v).name
    out = dict(res)
    out["input"] = Path(res["input"]).name if res.get("input") else None
    out["panel_dir"] = panel.name
    for k in ("live_file", "memory_list", "diff_base", "iso_map_file"):
        if k in out:
            out[k] = rel(out[k])
    out["files"] = {k: rel(v) for k, v in res.get("files", {}).items()}
    return out


def crag_update(file: str | Path | None = None, *, apply: bool = False, fetch: bool = False,
                panel_dir: str | Path | None = None, source_vintage: str | None = None, source_label: str | None = None,
                iso_map_csv: str | Path | None = None, now: dt.datetime | None = None,
                expect_live_sha256: str | None = None, expect_iso_map_sha256: str | None = None) -> dict:
    """Import a BoC-BoE file into a new panel vintage, diff it against the previous CRAG vintage and, with
    apply=True, replace the live CRAG episode file. Never raises for a bad input: returns status 'refused' (exit 1)
    or 'fetch_unavailable' (exit 2). Result keys are listed in docs/runbooks/A-crag-update.md.

    expect_live_sha256 / expect_iso_map_sha256 (apply=True only; HO-20261025-C-A-003): the sha256 of the live
    sovereign_defaults_crag.csv and of the country map (crag_iso_map.csv or iso_map_csv) that the caller's dry run
    saw, i.e. its result's `live_sha256_before` and `iso_map_sha256`; "absent" when that file did not exist. Checked
    under the apply lock, right before the replace: a mismatch (or a map that changed between the import and the
    check) returns status 'changed', exit 1, nothing live replaced. None skips that check."""
    panel = Path(panel_dir) if panel_dir else PANEL_DIR
    now = (now or dt.datetime.now(dt.timezone.utc)).astimezone(dt.timezone.utc)
    run_id = now.strftime("%Y-%m-%dT%H%M%SZ")
    live, live_uni, memory = panel / LIVE_NAME, panel / UNIVERSE_NAME, panel / MEMORY_NAME
    mem_sha = dp.checksum(memory) if memory.is_file() else None
    res = {"status": "", "exit_code": EXIT_OK, "message": "", "run_id": run_id, "panel_dir": str(panel),
           "apply": bool(apply), "input": None, "format": None, "input_sha256": None,
           "new_vintage": None, "new_vintage_created": False, "previous_vintage": None,
           "counts": {}, "diff_rows": [], "files": {}, "warnings": [],
           "licence": {"licence_status": LICENCE_STATUS, "licence_terms_url": TERMS_URL, "licence_basis": LICENCE_BASIS},
           "live_file": str(live), "live_replaced": False,
           "live_sha256_before": dp.checksum(live) if live.is_file() else None, "live_sha256_after": None,
           "memory_list": str(memory), "memory_list_sha256": mem_sha, "memory_list_untouched": True,
           "iso_map_file": None, "iso_map_sha256": None,
           "expect_live_sha256": expect_live_sha256, "expect_iso_map_sha256": expect_iso_map_sha256}
    try:
        _check_expect("expect_live_sha256", expect_live_sha256)
        _check_expect("expect_iso_map_sha256", expect_iso_map_sha256)
        if not apply and (expect_live_sha256 is not None or expect_iso_map_sha256 is not None):
            raise Refused("expect_live_sha256 / expect_iso_map_sha256 bind an --apply to a dry run: pass them only with apply")
        if fetch and file:
            raise Refused("pass either --file or --fetch, not both")
        if fetch:
            try:
                file = fetch_latest(panel / FETCH_SUBDIR / run_id)
            except FileExistsError as e:
                raise FetchUnavailable(f"download target already exists: {e.filename}") from None
            res["fetched_from"] = FETCH_URL_VERIFIED
        if not file:
            raise Refused("no input: pass --file PATH (Valet .csv or BoC-BoE .xlsx)")
        src = Path(file).expanduser()
        res["input"] = str(src)
        res["format"] = check_input(src)
        res["input_sha256"] = dp.checksum(src)
        before = crag_vintages(panel)
        run_dir = panel / RUNS_SUBDIR / run_id
        try:
            run_dir.mkdir(parents=True, exist_ok=False)
        except FileExistsError:
            raise Refused(f"run folder {run_dir} already exists (two updates in the same second); retry") from None
        staged = run_dir / LIVE_NAME
        edition = re.search(r"(?<!\d)(20\d\d)(?!\d)", src.name)
        label = source_label or f"BoC-BoE Sovereign Default Database{' ' + edition.group(1) if edition else ''} ({src.name})"
        sv = source_vintage or now.strftime("%Y-%m")
        iso_map = Path(iso_map_csv) if iso_map_csv else panel / ISO_MAP_NAME
        res["iso_map_file"] = str(iso_map)
        res["iso_map_sha256"] = _sha_or_absent(iso_map)             # the map the import below reads (HO-20261025-C-A-003)
        if res["iso_map_sha256"] == ABSENT:
            res["iso_map_sha256"] = None
        try:
            s = dp.import_crag(src, staged, label, sv, iso_map_csv=iso_map if iso_map.is_file() else None,
                               save_vintage=False, extra_meta={k: v for k, v in res["licence"].items()})
        except ValueError as e:
            raise Refused(f"{src.name} refused by the importer: {e}") from None
        except Exception as e:  # noqa: BLE001 - a corrupt workbook can fail anywhere in pandas/openpyxl
            raise Refused(f"{src.name} could not be read ({type(e).__name__}: {e})") from None
        if s["episodes"] == 0:
            raise Refused(f"{src.name} gives 0 default episodes: not a usable BoC-BoE file; no vintage saved")
        v = dp.save_crag_vintage(s, panel, label=f"default episodes: {label} ({sv}) [licence {LICENCE_STATUS}] crag_update",
                                 now=now)
        res.update(new_vintage=v.name, new_vintage_created=v.name not in before, format=s["format"])
        prev, prev_csv = diff_base(panel, v.name, res["live_sha256_before"], res["warnings"])
        res["previous_vintage"] = prev
        res["diff_base"] = str(prev_csv) if prev_csv else None
        old_eps, new_eps = load_episodes(prev_csv), load_episodes(staged)
        diff, same = diff_episodes(old_eps, new_eps)
        if len(old_eps) and (diff["status"] == "removed").sum() > 0.25 * len(old_eps):
            res["warnings"].append(f"{int((diff['status'] == 'removed').sum())} of {len(old_eps)} previous episodes removed: check the file is complete before --apply")
        for w in s.get("unmapped_skipped") or []:
            res["warnings"].append(f"unmapped country skipped: {w}")
        res["counts"] = {"episodes": int(s["episodes"]), "countries": int(s["countries"]), "previous_episodes": int(len(old_eps)),
                         "added": int((diff["status"] == "added").sum()), "removed": int((diff["status"] == "removed").sum()),
                         "changed": int((diff["status"] == "changed").sum()), "unchanged": int(same)}
        res["diff_rows"] = _records(diff)
        files = {"run_dir": run_dir, "staged_csv": staged, "staged_universe": Path(s["universe"]),
                 "diff_csv": run_dir / "crag_update_diff.csv", "summary_md": run_dir / "crag_update_summary.md",
                 "result_json": run_dir / "crag_update.json"}
        diff.assign(country=diff["country"].map(escape_formula)).to_csv(files["diff_csv"], index=False)
        if memory.is_file():
            files["vs_memory_csv"] = run_dir / COMPARISON_NAME
            dp.comparison_table(dp.compare_panels(memory, staged)).to_csv(files["vs_memory_csv"], index=False)
        res["files"] = {k: str(p) for k, p in files.items()}

        if apply:                                                   # only after the diff, only on request
            if live.name != LIVE_NAME or live.resolve() == memory.resolve():   # never the memory list
                raise Refused(f"refusing to write {live}: only {LIVE_NAME} may be replaced")
            with _ApplyLock(panel, run_id):                         # SEC-A-010 L2: check and replace under one lock
                if expect_live_sha256 is not None:                  # HO-20261025-C-A-003: bound to the caller's dry run
                    now_live = _sha_or_absent(live)
                    if now_live != expect_live_sha256:
                        raise Changed(f"{LIVE_NAME} is not the file the dry run saw (expected {expect_live_sha256[:12]}, "
                                      f"now {now_live[:12]}); run the dry run again")
                if expect_iso_map_sha256 is not None:
                    used, now_map = res["iso_map_sha256"] or ABSENT, _sha_or_absent(iso_map)
                    if not (used == now_map == expect_iso_map_sha256):
                        raise Changed(f"{iso_map.name} is not the map the dry run saw (expected {expect_iso_map_sha256[:12]}, "
                                      f"used by this import {used[:12]}, now {now_map[:12]}); run the dry run again")
                if (dp.checksum(live) if live.is_file() else None) != res["live_sha256_before"]:
                    raise Refused(f"{LIVE_NAME} changed while this update ran; rerun to diff against the new live file")
                pairs = [(staged, live), (Path(s["universe"]), live_uni)]
                if "vs_memory_csv" in files:
                    pairs.append((files["vs_memory_csv"], panel / COMPARISON_NAME))
                try:
                    _replace_all(pairs, run_dir, run_id)
                except OSError as e:
                    raise Refused(f"--apply failed ({type(e).__name__}: {e}); the live files were restored") from None
            res.update(status="applied", live_replaced=True, live_sha256_after=dp.checksum(live),
                       message=f"applied vintage {v.name} to {LIVE_NAME}")
        else:
            res.update(status="dry_run", live_sha256_after=res["live_sha256_before"],
                       message=f"dry run: vintage {v.name} saved, {LIVE_NAME} not changed; rerun with --apply to replace it")
        files["summary_md"].write_text(summary_markdown(res, diff), encoding="utf-8")
    except Changed as e:
        res.update(status="changed", exit_code=EXIT_REFUSED, message=str(e))
    except Refused as e:
        res.update(status="refused", exit_code=EXIT_REFUSED, message=str(e))
    except FetchUnavailable as e:
        res.update(status="fetch_unavailable", exit_code=EXIT_FETCH, message=f"{e}\n{fetch_help()}")
    except RestoreFailed as e:
        res.update(status="error", exit_code=EXIT_REFUSED, message=str(e))
    finally:
        after = dp.checksum(memory) if memory.is_file() else None
        if after != mem_sha:                                        # never expected: this module never opens it for writing
            res.update(memory_list_untouched=False, status="error", exit_code=EXIT_REFUSED,
                       message=f"{MEMORY_NAME} changed during the update; investigate before any use")
    if res["files"].get("result_json"):
        Path(res["files"]["result_json"]).write_text(json.dumps(_portable(res, panel), indent=1, default=str), encoding="utf-8")
    res["summary_text"] = summary_text(res)
    return res


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.crag_update",
                                 description="Update the BoC-BoE sovereign default database (CRAG): import a new file into "
                                             "a new panel vintage, show what changed, and with --apply replace "
                                             "data/panel/sovereign_defaults_crag.csv. Never changes sovereign_defaults.csv.")
    ap.add_argument("--file", help="Valet .csv export or BoC-BoE .xlsx workbook")
    ap.add_argument("--fetch", action="store_true", help="download from the Bank of Canada (UNVERIFIED: prints the page and exits 2)")
    ap.add_argument("--apply", action="store_true", help="replace the live CRAG file after the diff (default: dry run)")
    ap.add_argument("--panel-dir", help="panel folder (default data/panel)")
    ap.add_argument("--source-vintage", help="edition or download date for source_vintage (default: current YYYY-MM)")
    ap.add_argument("--iso-map", help="country,iso map CSV (default <panel>/crag_iso_map.csv)")
    ap.add_argument("--expect-live-sha256", help="with --apply: sha256 of the live CRAG file the dry run saw "
                    "(its live_sha256_before, or 'absent'); refused with status 'changed' if it differs")
    ap.add_argument("--expect-iso-map-sha256", help="with --apply: sha256 of the country map the dry run saw "
                    "(its iso_map_sha256, or 'absent'); refused with status 'changed' if it differs")
    ap.add_argument("--json", action="store_true", help="print the result as JSON instead of the text summary")
    a = ap.parse_args(argv)
    res = crag_update(a.file, apply=a.apply, fetch=a.fetch, panel_dir=a.panel_dir, source_vintage=a.source_vintage,
                      iso_map_csv=a.iso_map, expect_live_sha256=a.expect_live_sha256,
                      expect_iso_map_sha256=a.expect_iso_map_sha256)
    print(json.dumps(res, indent=1, default=str) if a.json else res["summary_text"])
    return int(res["exit_code"])


if __name__ == "__main__":
    sys.exit(main())
