"""Pull landing check (EQ-A-0061): what came back from Sam's Mac pull pack, re-verified from what is on disk.

    python -m econquest.ingestion.landing check [--data data] [--report path/to/report.json] [--state path/to/state.json]
                                                [--stage-dir PATH] [--out DIR] [--json]

`econquest mac-pull run` (Team C's wrapper around pullpack.py) leaves data/live/pullpack/state.json, report.md,
report.json and pullpack.log. This check reads report.json and state.json for what each step says it produced (vintage
ids, run ids, file paths), then re-verifies every step from the files themselves; the report's own verdicts are never
taken as evidence. Runbook: docs/runbooks/A-landing-check.md.

Per step (pullpack.STEP_IDS):
    fx             vintage hash (feeds.verify_vintage), feeds ok, raw BIS/ECB kept, BIS-vs-ECB cross-check
                   (pullpack._fx_verify), and audit.restricted_source_cells == 0 (no Yahoo or other restricted cell left)
    fx_history     build sha256 == provenance sidecar (pullpack._fxh_verify), columns exactly the 17 official FX
                   names (market_history.PRICE_FX_COLUMNS), no ETF column, raw vintage verifies and is the sidecar's
    panel_history  history run complete and every final file at the run's sha256 (pullpack._ph_verify), panel vintage
                   hash, WEO vintage column, row and country counts
    wb_panel       World Bank-only panel run (EQ-A-0094) in data/panel/wb_interim: run complete and final file at the
                   run's sha256 (pullpack._wbp_verify), panel vintage hash, file contract (pullpack.wb_panel_checks:
                   columns, every requested series, years within the request, one row per series-economy-year)
    crag           episode file at the import's sha256 and in its panel vintage, every episode with an ISO3 code and a
                   source, no CRAG name left without an ISO code, compare_panels and panel_coverage ran (their outputs
                   exist) and agree with a fresh run
    universe       staged vintage verifies (feeds.verify_vintage on the staged folder), the pack's missing-cell report
                   exists, a fresh universe.missing_cell_report covers every staged country
    ucdp / gdelt   event vintage indexed and at its manifest sha256 (pullpack._events_verify); mapping QA
                   (events.mapping_qa: GDELT share of unmapped events at or below the threshold; UCDP events all in
                   the universe)
    nowcast        vintage present and at its content hash (nowcast_feed.vintage_digest, index.csv);
                   data/live/nowcast_inputs.csv, if present, passes Team B's validator (nowcast_feed.validate_file)
    research       (EQ-A-0089) live/pullpack/research/research_drops.json at the recorded sha256, then
                   research.drops.verify: every research cell held, 3.6/4.4/6.10/7.12 parked, licence register rows,
                   no restricted value marked for client output, drop files unchanged
    macro          (EQ-A-0134) live/macro/vintages/<id>/ at the recorded manifest sha256, then official.macro.verify_vintage:
                   files at their manifest sha256, every value gated, no unverified or method-held value ok

Writes data/live/landing/ (or --out): landing_report.json, landing_report.md, the missing-cell report on feed-eligible
cells (universe.missing_cell_report, EQ-A-0055 metric: missing_cells_feed_eligible.csv, missing_cells_by_country.csv)
and the fresh crag comparison / GDELT mapping QA tables when those ran. For each Blocked Team A ticket
(pullpack.BLOCKED_TICKETS: EQ-A-0008, 0015, 0016, 0026) it says whether the evidence unblocks it, quoting the checks.
It never moves a ticket and never changes a data file outside the landing folder.

Exit: 0 every step re-verified; 2 partial (a step not landed, missing or failing re-verification); 1 error (no
report or state to read, an unreadable or unknown-schema file, or the report says a step is done and verified while
the files on disk fail re-verification: report and disk disagree, so treat the landing as tampered or incomplete).
"""
from __future__ import annotations

import csv
import datetime as dt
import hashlib
import io
import json
import os
import re
import sys
from pathlib import Path

import pandas as pd

from . import pullpack as pp

SCHEMA = "econquest.landing.report/1"
TICKET = "EQ-A-0061"
LANDING_DIR = Path("live") / "landing"                      # under data_dir
REPORT_JSON, REPORT_MD = "landing_report.json", "landing_report.md"
MISSING_ELIGIBLE, MISSING_BY_COUNTRY = "missing_cells_feed_eligible.csv", "missing_cells_by_country.csv"
EXIT_PASS, EXIT_ERROR, EXIT_PARTIAL = 0, 1, 2
PASS, FAIL, NOT_LANDED, MISSING = "pass", "fail", "not landed", "missing"
NOT_UPLOADED = "not uploaded"
_PATH_KEYS = ("prices", "provenance", "inputs", "vintage", "stage_dir")
_ID_KEYS = ("vintage_id", "run_id", "staged_vintage")
_ID_RE = re.compile(r"^[A-Za-z0-9_.-]{6,80}$")
_FIXED_OUTPUTS = {"crag": (Path("panel") / "sovereign_defaults_crag.csv", "output_sha256"),
                  "research": (pp.PACK_DIR / "research" / "research_drops.json", "summary_sha256")}   # EQ-A-0089
MIN_PANEL_COUNTRIES = 60          # EQ-A-0016 board summary: "Default panel to 60+ countries from 1980"
ROOT = Path(__file__).resolve().parents[2]
TEAM_DIR = ROOT / "team"
ISO3 = re.compile(r"[A-Z]{3}")
# SEC-A-008 (EQ-A-0066): report.json / state.json come from Sam's Mac by mail or upload and are untrusted input.
MAX_PACK_JSON_BYTES = 16 * 2 ** 20          # a real state.json is a few hundred KB
RUN_ID_RE = re.compile(r"\d{8}T\d{6}Z(-\d+)?")                      # panel_history.RUN_ID_RE
PANEL_VINTAGE_RE = re.compile(r"\d{4}-\d{2}-\d{2}T\d{6}Z-[0-9a-f]{8}")   # panel_history.save_panel_vintage folder names

# What each Blocked ticket needs from the landing, beyond its steps passing (pullpack.BLOCKED_TICKETS lists the steps).
TICKET_NEEDS = {
    "EQ-A-0008": "CRAG imported from the BoC-BoE workbook, compared with the memory-compiled panel, every episode "
                 "with an ISO3 code and a source",
    "EQ-A-0015": "point-in-time weo_history.csv / worldbank_history.csv from a complete history run, with the WEO "
                 "vintage column, saved as a panel vintage",
    "EQ-A-0016": f"panel history and CRAG both verified, coverage run, at least {MIN_PANEL_COUNTRIES} countries, "
                 "every episode sourced, saved as a panel vintage",
    "EQ-A-0026": "staged 88-country fetch verified (staged vintage) and the missing-cell report on feed-eligible cells",
}


class LandingError(RuntimeError):
    """Nothing to check, or an input that cannot be read (exit 1)."""


_check = pp._check


def _passed(checks: list[dict]) -> bool:
    return all(c["ok"] for c in checks if c["required"])


def _sha(path: Path) -> str:
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def _noop(_msg: str) -> None:
    return None


# ------------------------------------------------------------------------------------------------ inputs

def _read_json(path: Path, what: str) -> dict | None:
    if not path.is_file():
        return None
    try:
        size = path.stat().st_size
        if size > MAX_PACK_JSON_BYTES:                   # SEC-A-008 L1: bounded before parsing
            raise LandingError(f"{what} {path} is {size} bytes, more than {MAX_PACK_JSON_BYTES}: not a pull pack file")
        obj = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, ValueError, RecursionError) as e:  # RecursionError: nesting deeper than the parser allows
        raise LandingError(f"{what} {path} cannot be read: {type(e).__name__}: {str(e)[:200]}") from None
    if not isinstance(obj, dict):
        raise LandingError(f"{what} {path} is not a JSON object")
    return obj


def load_pack(data_dir: str | Path, report: str | Path | None = None, state: str | Path | None = None) -> dict:
    """{"report", "state", "records", "paths", "notes"} from report.json and state.json. Defaults: data/live/pullpack/;
    with --report only, state.json (and pullpack.log) are looked for next to it first. records: step id -> the state's
    record (else the report's step entry). LandingError when neither file exists or one has an unknown schema."""
    pk = pp.pack_dir(data_dir)
    rp = Path(report) if report else pk / pp.REPORT_JSON
    if state:
        sp = Path(state)
    else:
        sp = rp.parent / pp.STATE_FILE if (rp.parent / pp.STATE_FILE).is_file() else pk / pp.STATE_FILE
    lp = rp.parent / pp.LOG_FILE if (rp.parent / pp.LOG_FILE).is_file() else pk / pp.LOG_FILE
    rep, st = _read_json(rp, "report"), _read_json(sp, "state")
    if rep is None and st is None:
        raise LandingError(f"no pull has landed: neither {rp} nor {sp} exists (Sam sends report.json and state.json "
                           "after `econquest mac-pull run`; docs/runbooks/A-landing-check.md)")
    if rep is not None and rep.get("schema") != pp.REPORT_SCHEMA:
        raise LandingError(f"{rp}: schema {rep.get('schema')!r} is not {pp.REPORT_SCHEMA!r}")
    if st is not None and (st.get("version") != pp.STATE_VERSION or not isinstance(st.get("steps"), dict)):
        raise LandingError(f"{sp}: state version {st.get('version')!r} is not {pp.STATE_VERSION} or has no steps")
    steps_list = (rep or {}).get("steps", [])
    # EQ-A-0138: a step entry whose id is not text (a damaged or hand-edited report) is ignored, never a crash
    rsteps = {s.get("id"): s for s in (steps_list if isinstance(steps_list, list) else [])
              if isinstance(s, dict) and isinstance(s.get("id"), str)}
    ssteps = (st or {}).get("steps", {})
    notes = []
    for sid, rec in list(rsteps.items()) + list(ssteps.items()):
        if isinstance(rec, dict):
            for k in ("status", "reason", "number", "title"):
                if k in rec and not isinstance(rec[k], str):     # EQ-A-0138: a non-text status reads as damaged
                    notes.append(f"{sid}: {k} is not text in the pack files (damaged?): read as 'damaged'")
                    rec[k] = "damaged"
    bad = sorted(str(k) for k, v in ssteps.items() if not isinstance(v, dict))
    if bad:                                              # SEC-A-008 L1: a step record must be a JSON object
        notes.append(f"state.json step records that are not JSON objects were ignored: {bad[:10]}")
        ssteps = {k: v for k, v in ssteps.items() if isinstance(v, dict)}
    if rep is None:
        notes.append(f"report.json not found at {rp}: working from state.json only")
    if st is None:
        notes.append(f"state.json not found at {sp}: working from report.json only")
    for sid in sorted(set(rsteps) & set(ssteps)):
        a, b = rsteps[sid].get("status"), ssteps[sid].get("status")
        if a != b:
            notes.append(f"{sid}: report.json says {a}, state.json says {b} (report older than the state? rerun "
                         "`econquest mac-pull report`)")
    records = {sid: ssteps.get(sid) or rsteps.get(sid) for sid in set(rsteps) | set(ssteps)}
    log_info = {"path": str(lp), "present": lp.is_file(), "bytes": lp.stat().st_size if lp.is_file() else 0}
    if not lp.is_file():
        notes.append(f"pullpack.log not found at {lp}")
    return {"report": rep, "state": st, "records": records, "notes": notes,
            "paths": {"report": str(rp) if rep is not None else "", "state": str(sp) if st is not None else "",
                      "log": log_info}}


def _inside(p: Path, root: Path) -> bool:
    """True when p, with every symlink resolved, is root or below it."""
    r = Path(p).resolve()
    return r == root or root in r.parents


def locate(path: str | Path | None, data_dir: str | Path, *, outside_dir_ok: bool = False) -> Path | None:
    """A path recorded on Sam's Mac (absolute, or relative to his econquest folder) found under `data_dir`: the
    longest tail of at least two parts that exists under data_dir (data/market_history/builds/<v>/prices.csv ->
    <data_dir>/market_history/builds/<v>/prices.csv). Falls back to the path itself when it exists inside data_dir (a
    check run on the Mac), else None.

    Confined to data_dir (SEC-A-008 M1: report.json and state.json are untrusted): a recorded path with a '..' part is
    refused, and a candidate whose resolved path (symlinks followed) leaves data_dir is never returned. Only with
    outside_dir_ok (the universe step's staged folder, which pullpack writes beside the data folder) may the recorded
    path itself be used outside data_dir, and then only when it is a real directory holding countries.csv."""
    if not path or not isinstance(path, (str, Path)):
        return None
    q = Path(str(path)).expanduser()
    parts = [p for p in q.parts if p not in ("/", "\\") and not p.endswith(":\\")]
    if ".." in parts:
        return None
    d = Path(data_dir)
    root = d.resolve()
    for i in range(0, max(len(parts) - 1, 0)):
        c = d.joinpath(*parts[i:])
        if c.exists() or c.is_symlink():
            return c if _inside(c, root) else None
    if not q.exists():
        return None
    if _inside(q, root):
        return q
    if outside_dir_ok and q.is_dir() and not q.is_symlink() and (q / "countries.csv").is_file():
        return q
    return None


def _ctx(data_dir: Path, rec: dict, artifacts: dict) -> pp.Context:
    """A pullpack Context for reusing a step's verify: a fresh record holding only the artifacts the check located (the
    report's counts and verdicts are not passed on)."""
    r = pp._new_record(pp.Step(rec.get("id", ""), rec.get("number", ""), rec.get("title", ""), ""))
    r["artifacts"] = dict(artifacts)
    return pp.Context(Path(data_dir), pp.PackOptions(), r, {}, False, _noop, _noop, pp._utcnow)


# ------------------------------------------------------------------------------------------------ per-step checks

def _v_fx(d: Path, rec: dict, opts: dict) -> tuple[list[dict], dict]:
    from .audit import restricted_source_cells
    vid = (rec.get("artifacts") or {}).get("vintage_id")
    if not vid:
        return [_check("fx vintage id recorded", False, "no vintage_id in the step's artifacts")], {}
    ctx = _ctx(d, rec, {"vintage_id": vid})
    checks = list(pp._fx_verify(ctx)["checks"])
    counts = dict(ctx.rec.get("counts") or {})
    r = restricted_source_cells(d)
    n_yahoo = int(r["reason"].astype(str).str.contains("yahoo", case=False).sum()) if len(r) and "reason" in r else 0
    cells = ", ".join(f"{x.key} {x.country}" for x in r.head(10).itertuples(index=False)) if len(r) else ""
    checks.append(_check("audit.restricted_source_cells is 0 (no Yahoo or other restricted cell applied)", len(r) == 0,
                         f"{len(r)} cells ({n_yahoo} Yahoo)" + (f": {cells}" + (" ..." if len(r) > 10 else "") if cells else "")))
    counts.update(restricted_source_cells=int(len(r)), restricted_yahoo=n_yahoo)
    return checks, {"vintage_id": vid, "counts": counts, "cross_check": ctx.rec.get("cross_check", [])}


def _v_fx_history(d: Path, rec: dict, opts: dict) -> tuple[list[dict], dict]:
    from .market_history import (LEGACY_ETF_COLUMNS, PRICE_FX_COLUMNS, FxHistoryError, list_fx_history_vintages,
                                 verify_fx_history_vintage)
    a = rec.get("artifacts") or {}
    prices, side = locate(a.get("prices"), d), locate(a.get("provenance"), d)
    if prices is None:
        return [_check("built prices.csv on disk", False, f"{a.get('prices') or 'no path recorded'} not found under {d}")], {}
    ctx = _ctx(d, rec, {"prices": str(prices), "provenance": str(side) if side else ""})
    checks = list(pp._fxh_verify(ctx)["checks"])
    cols = [c for c in pd.read_csv(prices, nrows=0).columns if c.lower() not in ("date", "period")]
    extra = [c for c in cols if c not in PRICE_FX_COLUMNS]
    lacking = [c for c in PRICE_FX_COLUMNS if c not in cols]
    checks.append(_check(f"columns are the {len(PRICE_FX_COLUMNS)} official FX names", not extra and not lacking
                         and len(cols) == len(PRICE_FX_COLUMNS),
                         f"{len(cols)} columns" + (f"; extra {extra[:10]}" if extra else "")
                         + (f"; lacking {lacking}" if lacking else "")))
    etf = [c for c in cols if c in LEGACY_ETF_COLUMNS]
    checks.append(_check("no ETF column", not etf, ", ".join(etf) or "none"))
    ev = {"prices": str(prices), "columns": len(cols), "counts": {"dates": int(len(pd.read_csv(prices, usecols=[0])))}}
    meta = json.loads(side.read_text()) if side is not None and side.is_file() else {}
    checks += _fx_history_sidecar_checks(prices, side, meta)        # EQ-A-0077
    vid = meta.get("vintage_id", "")
    try:
        info = verify_fx_history_vintage(d, vid)
        checks.append(_check("raw BIS/ECB vintage verifies and is the one the build names",
                             info["hash"] == meta.get("vintage_hash"), f"{vid} hash {info['hash'][:16]}"))
    except (FxHistoryError, OSError) as e:
        checks.append(_check("raw BIS/ECB vintage verifies and is the one the build names", False,
                             f"{vid or 'no vintage_id in the sidecar'}: {e}"))
    live = d / "market_history" / "prices.csv"
    want = meta.get("sha256", "")
    checks.append(_check("installed data/market_history/prices.csv is this build", live.is_file() and _sha(live) == want,
                         "yes" if live.is_file() and _sha(live) == want
                         else "no: staged only (install with `python -m econquest.ingestion.market_history apply`)",
                         required=False))
    ev.update(vintage_id=vid, vintages=list_fx_history_vintages(d)[-3:], sha256=want,
              unserved=meta.get("unserved", []), disagreement_rows=(meta.get("disagreements") or {}).get("rows"))
    return checks, ev


def _fx_history_sidecar_checks(prices: Path, side: Path | None, meta: dict) -> list[dict]:
    """EQ-A-0077: the build's columns against its sidecar.
    - every column has values, unless the sidecar lists it unserved with a reason (series.<col>.reason)
    - every theratesapi.com column (fallback theratesapi, or the source names it) carries the EXC-005 tag
      (series.<col>.exception and exceptions.EXC-005.columns)
    - disagreements.rows is 0, or every row is listed: disagreements.csv next to the sidecar has that many rows and
      disagreements.columns names their columns
    - a build made with the EQ-A-0077 checks has no open hold (review.open 0)"""
    from .market_history import DISAGREEMENTS_NAME, THERATES_EXCEPTION
    series = meta.get("series") or {}
    px = pd.read_csv(prices, index_col=0)
    unserved = set(meta.get("unserved") or [])
    empty = [c for c in px.columns if px[c].isna().all()]
    bad = [c for c in empty if not (c in unserved and str((series.get(c) or {}).get("reason", "")).strip())]
    out = [_check("every column has values, or is listed unserved with a reason", not bad,
                  (f"empty without a reason: {', '.join(bad)}" if bad else
                   f"{len(px.columns) - len(empty)} served" + (f"; unserved with a reason: {', '.join(empty)}" if empty else "")))]
    rates = sorted(c for c, m in series.items() if isinstance(m, dict) and int(m.get("n_obs") or 0)
                   and (m.get("fallback") == "theratesapi" or "theratesapi" in str(m.get("source", "")).lower()))
    tagged = set(((meta.get("exceptions") or {}).get(THERATES_EXCEPTION) or {}).get("columns") or [])
    untagged = [c for c in rates if series[c].get("exception") != THERATES_EXCEPTION or c not in tagged]
    out.append(_check(f"theratesapi.com columns carry the {THERATES_EXCEPTION} tag in the sidecar", not untagged,
                      f"untagged: {', '.join(untagged)}" if untagged else (", ".join(rates) or "no theratesapi.com column")))
    dis = meta.get("disagreements") or {}
    n = dis.get("rows")
    if n == 0:
        out.append(_check("disagreements.rows is 0, or listed", True, "0 rows"))
    else:
        f = side.with_name(dis.get("file") or DISAGREEMENTS_NAME) if side is not None else None
        got = len(pd.read_csv(f)) if f is not None and f.is_file() else None
        ok = isinstance(n, int) and got == n and bool(dis.get("columns"))
        out.append(_check("disagreements.rows is 0, or listed", ok,
                          f"{n} rows in the sidecar; {'no disagreements.csv next to it' if got is None else f'{got} in {f.name}'}"
                          + (f"; columns {', '.join(dis.get('columns') or [])}" if dis.get("columns") else "; no columns listed")))
    rv = meta.get("review")
    if isinstance(rv, dict):
        out.append(_check("no open EQ-A-0077 hold (staleness, peg, outlier)", int(rv.get("open") or 0) == 0,
                          f"{len(rv.get('released') or [])} outlier date(s) released, dropped: "
                          f"{', '.join(sorted(rv.get('dropped') or {})) or 'none'}"))
    return out


def _panel_vintage_ok(panel_dir: Path, vid: str) -> tuple[bool, str]:
    """Recompute a panel vintage's content hash (panel_history._content_hash) against its first index.csv row."""
    from .panel_history import _content_hash
    if not isinstance(vid, str) or not PANEL_VINTAGE_RE.fullmatch(vid):     # SEC-A-008 M1: no path from the pack
        return False, f"{str(vid)[:80]!r}: not a panel vintage id (YYYY-MM-DDTHHMMSSZ-hash8)"
    v = panel_dir / "vintages" / str(vid)
    idx = panel_dir / "vintages" / "index.csv"
    if not v.is_dir() or not idx.is_file():
        return False, f"{vid or 'no vintage id'}: folder or index.csv missing"
    with open(idx, newline="", encoding="utf-8") as f:
        rows = [r for r in csv.DictReader(f) if r.get("vintage_id") == vid]
    if not rows:
        return False, f"{vid}: no row in {idx}"
    got = _content_hash({q.name: q.read_bytes() for q in v.iterdir() if q.is_file()})
    ok = got == rows[0].get("hash") and vid.endswith(got[:8])
    return ok, f"{vid} hash {got[:16]}" + ("" if ok else f" != index {str(rows[0].get('hash'))[:16]}")


def _v_panel_history(d: Path, rec: dict, opts: dict) -> tuple[list[dict], dict]:
    rid = (rec.get("artifacts") or {}).get("run_id")
    if not rid:
        return [_check("history run id recorded", False, "no run_id in the step's artifacts")], {}
    if not isinstance(rid, str) or not RUN_ID_RE.fullmatch(rid):          # SEC-A-008 M1: no path from the pack
        return [_check("history run id recorded", False, f"{str(rid)[:80]!r} is not a run id (YYYYMMDDTHHMMSSZ[-n])")], {}
    ctx = _ctx(d, rec, {"run_id": rid})
    checks = list(pp._ph_verify(ctx)["checks"])
    counts = dict(ctx.rec.get("counts") or {})
    pv = (ctx.rec.get("vintages") or {}).get("panel_vintage", "")
    if pv:
        ok, detail = _panel_vintage_ok(d / "panel", pv)
        checks.append(_check("panel vintage content hash matches its index row", ok, detail))
    w = d / "panel" / "weo_history.csv"
    has_vintage = w.is_file() and "vintage" in pd.read_csv(w, nrows=0).columns
    deferred = "; ".join(f"{s.upper()} {counts[s]}" for s in pp.PANEL_DEFERRED      # set by pullpack._ph_verify from
                         if str(counts.get(s, "")).startswith("deferred"))          # the run's own manifest params
    # EQ-A-0079: with WEO deferred (EQ-A-0087) the step lands its World Bank part; the WEO check is then a caveat, and
    # ticket_verdicts keeps EQ-A-0015 / EQ-A-0016 waiting on the WEO history.
    checks.append(_check("weo_history.csv has the WEO vintage column (point in time)", has_vintage,
                         (str(w.relative_to(d)) if w.is_file() else "weo_history.csv absent")
                         + (f"; {deferred}" if deferred else ""), required=not deferred))
    return checks, {"run_id": rid, "panel_vintage": pv, "counts": counts} | ({"deferred": deferred} if deferred else {})


def _v_wb_panel(d: Path, rec: dict, opts: dict) -> tuple[list[dict], dict]:
    """EQ-A-0094: step 2w, the World Bank-only panel history in data/panel/wb_interim."""
    from .panel_history import WB_PANEL_DIR
    rid = (rec.get("artifacts") or {}).get("run_id")
    if not isinstance(rid, str) or not RUN_ID_RE.fullmatch(rid):          # SEC-A-008 M1: no path from the pack
        return [_check("wb_panel run id recorded", False, f"{str(rid)[:80]!r} is not a run id (YYYYMMDDTHHMMSSZ[-n])")], {}
    ctx = _ctx(d, rec, {"run_id": rid})
    checks = list(pp._wbp_verify(ctx)["checks"])
    pv = (ctx.rec.get("vintages") or {}).get("panel_vintage", "")
    if pv:
        ok, detail = _panel_vintage_ok(d / "panel" / WB_PANEL_DIR, pv)
        checks.append(_check("panel vintage content hash matches its index row", ok, detail))
    return checks, {"run_id": rid, "panel_vintage": pv, "counts": dict(ctx.rec.get("counts") or {})}


def _table_sha(df: pd.DataFrame) -> str:
    """sha256 of a table's content as CSV text (every cell as text, as read back with dtype=str), so a file written
    earlier and a fresh in-memory table compare by content, not row count (EQ-A-0080, AGENT-05 finding 1)."""
    buf = io.StringIO()
    df.to_csv(buf, index=False)
    back = pd.read_csv(io.StringIO(buf.getvalue()), dtype=str, keep_default_na=False)
    return hashlib.sha256(back.to_csv(index=False).encode("utf-8")).hexdigest()


def _v_crag(d: Path, rec: dict, opts: dict, out_dir: Path) -> tuple[list[dict], dict]:
    from .default_panel import compare_panels, comparison_table, panel_coverage
    pdir = d / "panel"
    a = rec.get("artifacts") or {}
    out = pdir / "sovereign_defaults_crag.csv"
    if not out.is_file():
        return [_check("CRAG episode file on disk", False, f"{out} not found")], {}
    ep = pd.read_csv(out, dtype=str, keep_default_na=False, comment="#")
    no_iso = ep.loc[~ep["iso"].str.fullmatch(ISO3), "country"].tolist()
    unsourced = int((ep.get("source", pd.Series("", index=ep.index)).str.strip().eq("")
                     | ep.get("source_vintage", pd.Series("", index=ep.index)).str.strip().eq("")).sum())
    checks = [_check("episode file has episodes", len(ep) > 0, f"{len(ep)} episodes, {ep['iso'].nunique()} countries"),
              _check("episode file matches the import's sha256", a.get("output_sha256") == _sha(out),
                     f"import {str(a.get('output_sha256'))[:16]}, file {_sha(out)[:16]}"),
              _check("every episode has an ISO3 code", not no_iso, ", ".join(no_iso[:10]) or "all"),
              _check("every episode sourced (source and source_vintage)", unsourced == 0, f"{unsourced} without")]
    tpl, iso_map = pdir / "sovereign_defaults_crag_unmapped.csv", pdir / "crag_iso_map.csv"
    left = []
    if tpl.is_file():
        names = pd.read_csv(tpl, dtype=str, keep_default_na=False)["country"].tolist()
        mapped = {}
        if iso_map.is_file():
            m = pd.read_csv(iso_map, dtype=str, keep_default_na=False)
            mapped = {r.country: r.iso for r in m.itertuples(index=False) if ISO3.fullmatch(str(r.iso).strip().upper())}
        left = [n for n in names if n not in mapped]
    checks.append(_check("no CRAG name with a spell left without an ISO code", not left,
                         (", ".join(left[:10]) + (" ..." if len(left) > 10 else "")) if left
                         else ("none (unmapped template filled in crag_iso_map.csv)" if tpl.is_file() else "none")))
    uni = out.with_name(out.stem + "_universe.csv")
    uni_blank = []
    if uni.is_file():
        u = pd.read_csv(uni, dtype=str, keep_default_na=False)
        uni_blank = u.loc[u["iso"].str.strip() == "", "country"].tolist()
    checks.append(_check("CRAG countries without a spell all have an ISO code", not uni_blank,
                         f"{len(uni_blank)} without: {', '.join(uni_blank[:10])}" if uni_blank else "all",
                         required=False))
    pv = a.get("panel_vintage", "")
    ok, detail = _panel_vintage_ok(pdir, pv)
    in_v = ok and (pdir / "vintages" / pv / out.name).is_file() and _sha(pdir / "vintages" / pv / out.name) == _sha(out)
    checks.append(_check("episode file saved in its panel vintage (hash verified)", in_v, detail))
    ev: dict = {"panel_vintage": pv, "counts": {"episodes": int(len(ep)), "countries": int(ep["iso"].nunique()),
                                                "universe_countries_without_iso": len(uni_blank)}}
    old, cmp_file = pdir / "sovereign_defaults.csv", pdir / "crag_comparison.csv"
    if old.is_file():
        r = compare_panels(old, out)
        fresh = comparison_table(r)
        fresh.to_csv(out_dir / "crag_comparison.csv", index=False)
        ran = cmp_file.is_file()
        same = ran and _table_sha(pd.read_csv(cmp_file, dtype=str, keep_default_na=False)) == _table_sha(fresh)
        checks.append(_check("compare_panels ran (data/panel/crag_comparison.csv) and matches a fresh run", same,
                             f"{'present' if ran else 'absent'}; fresh: " + ", ".join(
                                 f"{k} {int(r['summary'][k])}" for k in ("added", "removed", "changed", "unchanged"))))
        ev["counts"].update({f"vs_memory_{k}": int(r["summary"][k]) for k in ("added", "removed", "changed", "unchanged")})
    else:
        checks.append(_check("compare_panels ran", False, "data/panel/sovereign_defaults.csv absent: nothing to compare"))
    hist, cov_file = pdir / "weo_history.csv", pp.pack_dir(d) / "panel_coverage.json"
    if hist.is_file():
        cov = panel_coverage(out, hist, universe_csv=uni if uni.is_file() else None)
        saved = json.loads(cov_file.read_text()) if cov_file.is_file() else None
        same = saved is not None and saved.get("n_countries") == cov["n_countries"] \
            and saved.get("n_ever_defaulted") == cov["n_ever_defaulted"]
        checks.append(_check("panel_coverage ran (live/pullpack/panel_coverage.json) and matches a fresh run", same,
                             f"{'present' if saved is not None else 'absent'}; fresh: {cov['n_countries']} countries, "
                             f"{cov['n_ever_defaulted']} ever defaulted (share {cov['ever_defaulted_share']})"))
        ev["counts"].update(n_countries=cov["n_countries"], n_ever_defaulted=cov["n_ever_defaulted"],
                            ever_defaulted_share=cov["ever_defaulted_share"],
                            defaults_missing_from_history=len(cov["defaults_missing_from_history"]),
                            zeros_not_covered_by_crag=len(cov["zeros_not_covered_by_crag"] or []))
        ev["coverage_checks"] = cov["checks"]
    else:
        checks.append(_check("panel_coverage ran", False, "data/panel/weo_history.csv absent (panel history not landed)"))
    return checks, ev


def _stage_dir(d: Path, rec: dict, opts: dict) -> Path | None:
    if opts.get("stage_dir"):
        p = Path(opts["stage_dir"]).expanduser()
        return p if p.is_dir() else None
    p = locate((rec.get("artifacts") or {}).get("stage_dir"), d, outside_dir_ok=True)
    return p if p is not None and p.is_dir() else None


def _v_universe(d: Path, rec: dict, opts: dict) -> tuple[list[dict], dict]:
    from .feeds import verify_vintage
    from .universe import missing_cell_report
    a = rec.get("artifacts") or {}
    pk = pp.pack_dir(d)
    checks = [_check("pack's missing-cell report exists (live/pullpack/universe_missing_cells.csv)",
                     (pk / "universe_missing_cells.csv").is_file(), "live/pullpack/universe_missing_cells.csv")]
    stage = _stage_dir(d, rec, opts)
    if stage is None:
        checks.append(_check("staged data folder on disk", False,
                             f"{opts.get('stage_dir') or a.get('stage_dir') or 'no stage_dir recorded'} not found: send "
                             "the staged folder with the backup, or pass --stage-dir"))
        return checks, {"stage_dir": a.get("stage_dir", "")}
    vid = a.get("staged_vintage", "")
    try:
        info = verify_vintage(stage, vid)
        checks.append(_check("staged vintage verifies", True, f"{info['vintage_id']} hash {info['hash'][:16]}"))
    except (ValueError, OSError) as e:
        checks.append(_check("staged vintage verifies", False, f"{vid or 'no staged_vintage recorded'}: {e}"))
    mr = missing_cell_report(stage)
    want = len(pd.read_csv(stage / "countries.csv", dtype=str, keep_default_na=False))
    if mr.summary.get("measured") is False:                 # EQ-A-0080: a partial (--only) staged pull is not measured
        checks.append(_check("fresh missing-cell report measured (full staged pull)", False, mr.summary.get("note", ""),
                             required=False))
        return checks, {"stage_dir": str(stage), "staged_vintage": vid, "counts": {"measured": False}}
    checks.append(_check("every staged country in a fresh missing-cell report", mr.summary["n_countries"] == want,
                         f"{mr.summary['n_countries']} of {want}"))
    elig, target = mr.summary["pct_live_eligible_overall"], mr.summary["target"]
    checks.append(_check(f"at least {target:.0%} of feed-eligible cells live", elig >= target,
                         f"{elig:.1%}; {mr.summary['countries_meeting_target']} of {mr.summary['n_countries']} "
                         f"countries meet it ({mr.summary['denominator']})", required=False))
    ev = {"stage_dir": str(stage), "staged_vintage": vid,
          "counts": {k: mr.summary[k] for k in ("n_countries", "n_feed_eligible", "pct_live_eligible_overall",
                                                "pct_live_overall", "countries_meeting_target", "target")}}
    return checks, ev


def _v_events(d: Path, rec: dict, opts: dict, source: str, out_dir: Path) -> tuple[list[dict], dict]:
    from .events import mapping_qa
    from .events.base import read_event_vintage
    a = rec.get("artifacts") or {}
    vid = a.get("vintage_id")
    if not vid:
        return [_check(f"{source} vintage id recorded", False, "no vintage_id in the step's artifacts")], {}
    ctx = _ctx(d, rec, {"vintage_id": vid})
    checks = list(pp._events_verify(ctx, source)["checks"])
    ev = {"vintage_id": vid, "counts": dict(ctx.rec.get("counts") or {})}
    if source == "gdelt":
        stage = d / mapping_qa.GDELT_STAGE
        if (stage / "manifest.json").is_file():
            rep, table = mapping_qa.gdelt_qa(d, a.get("start"), a.get("end"))
            table.to_csv(out_dir / "gdelt_mapping_qa.csv", index=False)
            checks.append(_check("GDELT mapping QA: unmapped share at or below the threshold", not rep["breach"],
                                 f"{rep['events_unmapped']} unmapped of {rep['events_mapped'] + rep['events_unmapped']}"
                                 f" in scope (share {rep['unmapped_share']:.2%}, threshold {rep['threshold']:.0%})"
                                 + (f"; WARN {rep['warn'][0][:160]}" if rep["warn"] else "")))
            ev["mapping_qa"] = {k: rep[k] for k in ("events_mapped", "events_unmapped", "events_outside_universe",
                                                    "events_outside_known_map", "unmapped_share", "breach",
                                                    "threshold", "warn", "notes")}
        else:
            checks.append(_check("GDELT mapping QA", False, f"{stage}/manifest.json absent: QA cannot run here",
                                 required=False))
    else:
        try:
            evs = read_event_vintage(d, source, vid, verify=True)
            universe, usrc = mapping_qa.universe_isos(d)
            outside = sorted(set(evs["iso"]) - universe)
            checks.append(_check("UCDP mapping QA: every event country is in the universe", not outside,
                                 (", ".join(outside[:10]) if outside else f"all {evs['iso'].nunique()} countries")
                                 + f" (universe {len(universe)} from {usrc}; the adapter refuses unmapped events)"))
            ev["mapping_qa"] = {"countries": int(evs["iso"].nunique()), "outside_universe": outside}
        except Exception as e:  # noqa: BLE001 - reported as a failed check (the vintage check above failed too)
            checks.append(_check("UCDP mapping QA", False, f"{type(e).__name__}: {e}"))
    return checks, ev


def _v_nowcast(d: Path, rec: dict, opts: dict) -> tuple[list[dict], dict]:
    from .nowcast_feed import paths, validate_file, vintage_digest
    a = rec.get("artifacts") or {}
    v = locate(a.get("vintage"), d)
    if v is None or not v.is_dir():
        return [_check("nowcast vintage on disk", False, f"{a.get('vintage') or 'no vintage recorded'} not found")], {}
    files = {q.name: q.read_bytes() for q in v.iterdir() if q.is_file()}
    got = vintage_digest(files)
    rows = []
    idx = v.parent / "index.csv"
    if idx.is_file():
        with open(idx, newline="", encoding="utf-8") as f:
            rows = [r for r in csv.DictReader(f) if r.get("vintage_id") == v.name]
    checks = [_check("nowcast vintage has transformed.csv", "transformed.csv" in files, v.name),
              _check("nowcast vintage at its content hash (folder name and index.csv)",
                     v.name.endswith("-" + got[:8]) and bool(rows) and rows[0].get("hash") == got,
                     f"{got[:16]}" + ("" if rows else "; no index.csv row"))]
    inputs = paths(d)["inputs"]
    ev: dict = {"vintage": v.name, "counts": {}}
    if inputs.is_file():
        ok, out = validate_file(inputs)
        checks.append(_check("nowcast_inputs.csv passes Team B's validator (engine.nowcast validate)", ok, out[-200:]))
        ev["counts"]["input_rows"] = int(len(pd.read_csv(inputs, usecols=[0])))
    else:
        checks.append(_check("nowcast_inputs.csv present", False, "absent (no verified map row merged yet)",
                             required=False))
    return checks, ev


def _artifacts(rec) -> dict:
    a = rec.get("artifacts") if isinstance(rec, dict) else None
    return a if isinstance(a, dict) else {}


def _recorded_paths(rec: dict) -> list[tuple[str, str]]:
    a = _artifacts(rec)
    return [(k, a[k]) for k in _PATH_KEYS if isinstance(a.get(k), str) and a[k]]


def _path_found(d: Path, key: str, path: str, rec: dict, opts: dict) -> bool:
    if key == "stage_dir":
        return _stage_dir(d, rec, opts) is not None
    return locate(path, d) is not None


def _name_under(d: Path, ident: str) -> bool:
    """A file or folder under d whose name contains the recorded id (vintage, run). Names are compared, never joined
    into a path, so an id from the untrusted report cannot reach outside d."""
    if not _ID_RE.match(ident):
        return False
    for _root, dirs, files in os.walk(d):
        if any(ident in n for n in dirs) or any(ident in n for n in files):
            return True
    return False


def _same_install(path: str, d: Path) -> bool:
    """The recorded path lies under the folder that holds this data folder (string comparison only, SEC-A-009 L4: no
    filesystem probe of a path taken from the untrusted report)."""
    q = Path(str(path)).expanduser()
    root = Path(d).resolve().parent
    return q.is_absolute() and (q == root or root in q.parents)


def off_mac(d: Path, records: dict, opts: dict) -> bool:
    """True when the pack recorded output paths and none of them is found under d: the check runs away from the Mac
    (Sam sent report.json/state.json without the data folder). Steps whose files are absent are then 'not uploaded',
    not failures (EQ-A-0070)."""
    seen = False
    for rec in records.values():
        for k, p in _recorded_paths(rec):
            seen = True
            if _path_found(d, k, p, rec, opts) or ".." in Path(p).parts or _same_install(p, d):
                return False                          # on this machine (or a refused path): check, don't excuse
    return seen


def _absent_outputs(d: Path, rec: dict, opts: dict) -> list[str]:
    """The step's recorded outputs when none of them is under d; [] when one is, or when nothing was recorded."""
    a = _artifacts(rec)
    fixed = _FIXED_OUTPUTS.get(rec.get("id", ""))
    if fixed and a.get(fixed[1]):                      # a step that writes a fixed file: present when its hash matches
        f = d / fixed[0]
        # EQ-A-0080 (AGENT-05 finding 3): a file that is present is checked (a different hash fails the step), never
        # excused as 'not uploaded'
        return [] if f.is_file() else [str(fixed[0])]
    paths = _recorded_paths(rec)
    ids = [a[k] for k in _ID_KEYS if isinstance(a.get(k), str) and a[k]]
    if not paths and not ids:
        return []
    if any(_path_found(d, k, p, rec, opts) for k, p in paths) or any(_name_under(d, i) for i in ids):
        return []
    return [p for _, p in paths] + ids


def _v_dsa_regate(d: Path, rec: dict, opts: dict) -> tuple[list[dict], dict]:
    """EQ-A-0096: the pack's own verify of the derived vintage, rerun on the landed files."""
    a = rec.get("artifacts") or {}
    if not a.get("vintage_id"):
        return [_check("dsa_regate vintage id recorded", False, "no vintage_id in the step's artifacts")], {}
    keep = {k: a.get(k) for k in ("vintage_id", "base_vintage", "dsa_sha256")}
    f = locate(a.get("dsa_file"), d)
    keep["dsa_file"] = str(f) if f else str(a.get("dsa_file") or "")
    ctx = _ctx(d, rec, keep)
    checks = list(pp._dsa_verify(ctx)["checks"])
    return checks, {"vintage_id": a["vintage_id"], "base_vintage": a.get("base_vintage"), "held": ctx.rec.get("held", [])}


def _v_research(d: Path, rec: dict, opts: dict) -> tuple[list[dict], dict]:
    """EQ-A-0089: the research drop report at the sha256 the pack recorded, then research.drops.verify on the landed
    files (every cell held, sign-off ids parked, licence register rows, no restricted value marked for clients)."""
    from .research import drops
    a = rec.get("artifacts") or {}
    f = d / pp.PACK_DIR / "research" / drops.SUMMARY_FILE
    if not f.is_file():
        return [_check("research drop report on disk", False, f"{f.relative_to(d)} not found")], {}
    checks = [_check("research drop report at the sha256 the pack recorded", _sha(f) == a.get("summary_sha256"),
                     _sha(f)[:16])]
    checks += drops.verify(d)
    try:
        summ, _cells = drops.read(d)
    except drops.DropsError:
        summ = {}
    return checks, {"counts": summ.get("counts", {}), "as_of": summ.get("as_of"),
                    "sources": {k: v.get("status") for k, v in (summ.get("sources") or {}).items()}}


def _v_macro(d: Path, rec: dict, opts: dict) -> tuple[list[dict], dict]:
    """EQ-A-0134: the macro vintage the pack recorded, at its manifest sha256, re-verified (official.macro)."""
    from .official import macro as M
    a = rec.get("artifacts") or {}
    vid = str(a.get("vintage_id") or "")
    if not _ID_RE.match(vid):
        return [_check("macro vintage id recorded", False, vid[:80] or "no vintage_id in the step's artifacts")], {}
    v = d / M.MACRO_DIR / "vintages" / vid
    if not v.is_dir():
        return [_check("macro vintage on disk", False, f"{v.relative_to(d)} not found")], {}
    checks = [_check("macro manifest at the sha256 the pack recorded", _sha(v / "manifest.json") == a.get("manifest_sha256"),
                     _sha(v / "manifest.json")[:16])]
    checks += M.verify_vintage(v)
    return checks, {"vintage_id": vid, "counts": rec.get("counts") or {}}


def _verifiers(out_dir: Path) -> dict:
    return {"dsa_regate": _v_dsa_regate, "fx": _v_fx, "fx_history": _v_fx_history, "panel_history": _v_panel_history, "wb_panel": _v_wb_panel,
            "crag": lambda d, r, o: _v_crag(d, r, o, out_dir), "universe": _v_universe,
            "ucdp": lambda d, r, o: _v_events(d, r, o, "ucdp", out_dir),
            "gdelt": lambda d, r, o: _v_events(d, r, o, "gdelt", out_dir), "nowcast": _v_nowcast,
            "research": _v_research,                                                           # EQ-A-0089
            "macro": _v_macro}                                                                 # EQ-A-0134


def _held_without_output(rec: dict) -> bool:
    """A held step that recorded no output path, no vintage/run id and no fixed-output hash."""
    a = _artifacts(rec)
    fixed = _FIXED_OUTPUTS.get(rec.get("id", ""))
    if fixed and a.get(fixed[1]):
        return False
    return not _recorded_paths(rec) and not any(isinstance(a.get(k), str) and a[k] for k in _ID_KEYS)


def check_step(sid: str, rec: dict | None, data_dir: Path, opts: dict, out_dir: Path, *, away: bool = False) -> dict:
    """One step's landing verdict: pass | fail (re-verification failed) | not landed (the pack did not produce it)
    | not uploaded (away from the Mac, the step's outputs were not sent) | missing (not in report.json or state.json). `contradiction` is true when the report says done and verified
    but the files fail."""
    base = {"id": sid, "status_reported": "", "reason_reported": "", "verdict": MISSING, "checks": [], "evidence": {},
            "contradiction": False, "unblocks": []}
    if rec is None:
        base["note"] = "step not in report.json or state.json (an older pack, or the files were cut)"
        return base
    ver = rec.get("verify")
    reported_ok = rec.get("status") == "done" and isinstance(ver, dict) and bool(ver.get("passed"))
    ub = rec.get("unblocks")
    base.update(status_reported=rec.get("status", ""), reason_reported=rec.get("reason", ""),
                unblocks=[str(x) for x in ub] if isinstance(ub, list) else [], number=rec.get("number", ""),
                title=rec.get("title", ""))
    if rec.get("status") in ("pending", "skipped", "running") and not rec.get("artifacts"):
        base["verdict"] = NOT_LANDED
        base["note"] = f"{rec.get('status')}: {rec.get('reason') or 'not run'}"
        return base
    if away and rec.get("status") in ("done", "held"):
        absent = _absent_outputs(data_dir, rec, opts)
        if absent:
            base["verdict"] = NOT_UPLOADED
            base["note"] = (f"{rec.get('status')} on the Mac; its files are not in {data_dir} (upload them, "
                            f"A-landing-check.md): " + ", ".join(_flat(x) for x in absent[:3]))
            return base
    if rec.get("status") == "held" and _held_without_output(rec):
        # EQ-A-0138: a step held on the Mac before it built anything (e.g. fx_history with open EQ-A-0077 holds and an
        # empty prices path) has nothing to re-verify: not landed, with the Mac's reason, not a failed check
        base["verdict"] = NOT_LANDED
        base["note"] = f"held on the Mac, nothing built to check: {_flat(rec.get('reason')) or 'no reason recorded'}"
        return base
    try:
        checks, ev = _verifiers(out_dir)[sid](data_dir, rec, opts)
    except Exception as e:  # noqa: BLE001 - a re-verification that cannot run is a failed check
        checks, ev = [_check("re-verification ran", False, f"{type(e).__name__}: {' '.join(str(e).split())[:300]}")], {}
    ok = _passed(checks)
    base.update(checks=checks, evidence=ev, verdict=PASS if ok else FAIL, contradiction=reported_ok and not ok)
    return base


# ------------------------------------------------------------------------------------------------ missing-cell report

def missing_cells(data_dir: Path, steps: dict, opts: dict, out_dir: Path) -> dict:
    """The missing-cell report on feed-eligible cells (universe.missing_cell_report, EQ-A-0055 metric) written to the
    landing folder. Source, in order: a fresh report on the staged universe folder; else the pack's own CSVs
    (live/pullpack/universe_missing_*.csv, filtered here to feed-eligible ids); else the desk data folder's last
    fetch. Returns the summary (scope says which)."""
    from .universe import _eligible_for, missing_cell_report
    found = ((steps.get("universe") or {}).get("evidence") or {}).get("stage_dir")
    stage = Path(found) if found and Path(found).is_dir() else None
    pk = pp.pack_dir(data_dir)
    summary: dict
    if stage is not None and (stage / "live" / "live_inputs.csv").is_file():
        mr = missing_cell_report(stage)
        eligible, _m = _eligible_for(stage, pd.read_csv(stage / "indicators.csv", dtype={"id": str})["id"])
        cells, cty, summary = mr.cells, mr.countries, dict(mr.summary)
        summary["scope"] = f"staged universe folder {stage} (fresh universe.missing_cell_report)"
    elif (pk / "universe_missing_cells.csv").is_file() and (pk / "universe_missing_countries.csv").is_file():
        cells = pd.read_csv(pk / "universe_missing_cells.csv", dtype=str, keep_default_na=False)
        cty = pd.read_csv(pk / "universe_missing_countries.csv", dtype={"country": str})
        eligible, _m = _eligible_for(data_dir, cells["key"])
        summary = {"n_countries": int(len(cty)), "scope": "the pack's live/pullpack/universe_missing_*.csv (staged "
                   "folder not on disk here: not recomputed)"}
        if {"live_eligible", "n_eligible"} <= set(cty.columns) and cty["n_eligible"].sum():
            summary["pct_live_eligible_overall"] = round(float(cty["live_eligible"].sum() / cty["n_eligible"].sum()), 4)
        if "meets_target" in cty.columns:
            summary["countries_meeting_target"] = int(cty["meets_target"].astype(str).str.lower().eq("true").sum())
    elif (data_dir / "live" / "live_inputs.csv").is_file():
        mr = missing_cell_report(data_dir)
        eligible, _m = _eligible_for(data_dir, pd.read_csv(data_dir / "indicators.csv", dtype={"id": str})["id"])
        cells, cty, summary = mr.cells, mr.countries, dict(mr.summary)
        summary["scope"] = f"desk data folder {data_dir} (no staged universe landed; not the 88-country fetch)"
    else:
        return {"written": False, "scope": "nothing to report: no staged folder, pack CSVs or live_inputs.csv"}
    elig_cells = cells[cells["key"].astype(str).isin(eligible)].reset_index(drop=True)
    elig_cells.to_csv(out_dir / MISSING_ELIGIBLE, index=False)
    cty.to_csv(out_dir / MISSING_BY_COUNTRY, index=False)
    summary.update(written=True, feed_eligible_missing_cells=int(len(elig_cells)),
                   feed_eligible_by_reason=elig_cells["reason"].value_counts().to_dict(),
                   files=[str(out_dir / MISSING_ELIGIBLE), str(out_dir / MISSING_BY_COUNTRY)])
    return {k: v for k, v in summary.items() if k != "by_reason"}


# ------------------------------------------------------------------------------------------------ Blocked tickets

def _board_rows(team_dir: Path | None) -> dict:
    p = Path(team_dir) / "board" / "A.csv" if team_dir else None
    if p is None or not p.is_file():
        return {}
    with open(p, newline="", encoding="utf-8") as f:
        return {r["key"]: r for r in csv.DictReader(f)}


def _blocked_reasons(team_dir: Path | None) -> dict:
    """The latest `blocked` log line per ticket from team/logs/A.jsonl (what `teamctl tail | grep` shows)."""
    p = Path(team_dir) / "logs" / "A.jsonl" if team_dir else None
    out: dict = {}
    if p is None or not p.is_file():
        return out
    for line in p.read_text(encoding="utf-8").splitlines():
        try:
            e = json.loads(line)
        except ValueError:
            continue
        if e.get("action") == "blocked" and e.get("ticket") in pp.BLOCKED_TICKETS:
            out[e["ticket"]] = {"ts": e.get("ts", ""), "agent": e.get("agent", ""), "msg": e.get("msg", "")}
    return out


def _quote(sid: str, c: dict) -> str:
    return f"{sid}: [{'x' if c['ok'] else ' '}] {c['name']}" + (f": {c['detail']}" if c.get("detail") else "")


def ticket_verdicts(steps: dict, team_dir: Path | None = TEAM_DIR) -> dict:
    """For each Blocked ticket in pullpack.BLOCKED_TICKETS: does the landed evidence unblock it, quoting the checks.
    Never moves a ticket (AGENT-08 does, when real evidence arrives)."""
    board, reasons = _board_rows(team_dir), _blocked_reasons(team_dir)
    out = {}
    for t, need in pp.BLOCKED_TICKETS.items():
        evidence, waiting, caveats = [], [], []
        for sid in need:
            s = steps.get(sid) or {"verdict": MISSING, "checks": []}
            if s["verdict"] in (NOT_LANDED, NOT_UPLOADED, MISSING):
                waiting.append(f"{sid}: {s['verdict']}" + (f" ({s.get('note')})" if s.get("note") else ""))
            for c in s.get("checks", []):
                if c["ok"]:
                    evidence.append(_quote(sid, c))
                elif c["required"]:
                    waiting.append(_quote(sid, c))
                else:
                    caveats.append(_quote(sid, c))
        ph_deferred = ((steps.get("panel_history") or {}).get("evidence") or {}).get("deferred")
        if t in pp.PANEL_NEEDS_WEO and ph_deferred and "panel_history" in need:
            waiting.append(f"panel_history: {ph_deferred}; this ticket needs the WEO history")      # EQ-A-0079
        if t == "EQ-A-0016":
            n = ((steps.get("crag") or {}).get("evidence") or {}).get("counts", {}).get("n_countries")
            ok = isinstance(n, int) and n >= MIN_PANEL_COUNTRIES
            (evidence if ok else waiting).append(f"coverage: [{'x' if ok else ' '}] at least {MIN_PANEL_COUNTRIES} "
                                                 f"countries in the panel history: {n if n is not None else 'not measured'}")
        unblocked = all((steps.get(s) or {}).get("verdict") == PASS for s in need) and not waiting
        row = board.get(t, {})
        done = row.get("status") == "Done"
        if done:          # EQ-A-0080 (AGENT-05 finding 4): a Done ticket waits on nothing; open checks stay as caveats
            caveats, waiting = caveats + [f"(ticket already Done) {w}" for w in waiting], []
        out[t] = {"steps": list(need), "needs": TICKET_NEEDS.get(t, ""), "unblocked": unblocked,
                  "verdict": "already Done on the board" if done else
                             "evidence unblocks it" if unblocked else "still blocked",
                  "evidence": evidence, "waiting_on": waiting, "caveats": caveats,
                  "board": {k: row.get(k, "") for k in ("status", "summary", "updated")} if row else {},
                  "blocked_reason": reasons.get(t, {}),
                  "action": "AGENT-08 moves the ticket; this check does not"}
    return out


# ------------------------------------------------------------------------------------------------ report

def _exit(steps: dict) -> int:
    if any(s["contradiction"] for s in steps.values()):
        return EXIT_ERROR
    return EXIT_PASS if all(s["verdict"] == PASS for s in steps.values()) else EXIT_PARTIAL


def _flat(v) -> str:
    """One line of plain text (whitespace runs, CR and LF collapse to one space); for notes stored in the JSON report."""
    return " ".join(str(v if v is not None else "").split())


def _one(v) -> str:
    """One line of inert Markdown from a value that may come from the pack (SEC-A-008 L2, SEC-A-009 L5 in EQ-A-0138):
    pullpack.md_text collapses whitespace, so a reason or detail cannot open a heading, list item or check line of its
    own, and turns &, <, >, backtick, | and [ ] into HTML entities, so no tag, code span, cell or link renders."""
    return pp.md_text(v)


def _cell(v) -> str:
    """A table cell: `|` reads as `/` (SEC-A-008 L2), then _one."""
    return _one(str(v if v is not None else "").replace("|", "/"))


def _md(rep: dict) -> str:
    L = ["# Pull landing check", "",
         f"Generated {rep['generated_utc']} ({TICKET}). Exit code {rep['exit_code']} (0 every step re-verified, "
         "2 partial, 1 error or report contradicts disk). Runbook: docs/runbooks/A-landing-check.md.", "",
         f"Inputs: report {_one(rep['inputs']['report']) or '-'}; state {_one(rep['inputs']['state']) or '-'}; log "
         f"{_one(rep['inputs']['log']['path']) if rep['inputs']['log']['present'] else 'absent'}.", "",
         "| Step | Reported | Landing verdict | Note |", "|---|---|---|---|"]
    for s in rep["steps"]:
        note = "REPORT SAYS DONE, DISK FAILS" if s["contradiction"] else (s.get("note") or "")
        L.append(f"| {_cell(s.get('number', ''))} {_cell(s['id'])} | {_cell(s['status_reported']) or '-'} | "
                 f"{s['verdict']} | {_cell(note)} |")
    L += ["", "## Blocked tickets", "", "The check does not move tickets; AGENT-08 moves them when real evidence arrives.",
          ""]
    for t, x in rep["tickets"].items():
        L += [f"### {t}: {x['verdict']}", "", f"Needs: {x['needs']}."]
        if x["board"]:
            L.append(f"Board: {_one(x['board']['status'])} - {_one(x['board']['summary'])}")
        if x["blocked_reason"]:
            L.append(f"Blocked ({_one(x['blocked_reason']['ts'])}, {_one(x['blocked_reason']['agent'])}): "
                     f"{_one(x['blocked_reason']['msg'])}")
        L += ["", "Evidence:"] + ([f"- {_one(e)}" for e in x["evidence"]] or ["- none"])
        if x["waiting_on"]:
            L += ["", "Waiting on:"] + [f"- {_one(w)}" for w in x["waiting_on"]]
        if x["caveats"]:
            L += ["", "Not blocking, still open (information checks):"] + [f"- {_one(w)}" for w in x["caveats"]]
        L.append("")
    m = rep["missing_cells"]
    L += ["## Missing-cell report (feed-eligible cells, EQ-A-0055 metric)", "", f"Scope: {_one(m.get('scope', '-'))}."]
    if m.get("written"):
        L += [f"Feed-eligible cells not live: {m['feed_eligible_missing_cells']}"
              + (f"; share live {m['pct_live_eligible_overall']:.1%}" if m.get("pct_live_eligible_overall") is not None
                 else ("; coverage not measured (partial fetch)" if m.get("measured") is False else ""))
              + (f"; countries meeting the target {m['countries_meeting_target']} of {m.get('n_countries')}"
                 if m.get("countries_meeting_target") is not None else "") + ".",
              "By reason: " + ("; ".join(f"{_one(k)} {v}" for k, v in m["feed_eligible_by_reason"].items()) or "none")
              + ".", "Files: " + ", ".join(_one(f) for f in m["files"]) + "."]
    for s in rep["steps"]:
        if not s["checks"]:
            continue
        L += ["", f"## {_one(s.get('number', ''))} {_one(s['id'])}", "",
              f"Reported **{_one(s['status_reported'])}**" + (f": {_one(s['reason_reported'])}" if s["reason_reported"]
                                                               else "")
              + f". Landing verdict **{s['verdict']}**."]
        L += [f"- [{'x' if c['ok'] else ' '}] {_one(c['name'])}" + ("" if c["required"] else " (information)")
              + (f": {_one(c['detail'])}" if c["detail"] else "") for c in s["checks"]]
    if rep["notes"]:
        L += ["", "## Notes", ""] + [f"- {_one(n)}" for n in rep["notes"]]
    return "\n".join(L) + "\n"


def check(data_dir: str | Path = "data", report: str | Path | None = None, state: str | Path | None = None, *,
          stage_dir: str | Path | None = None, out_dir: str | Path | None = None,
          team_dir: str | Path | None = TEAM_DIR, now: dt.datetime | None = None) -> dict:
    """Run the landing check; write landing_report.json/.md (and the missing-cell CSVs) to out_dir (default
    <data>/live/landing). Returns the report dict (exit_code inside). LandingError when nothing can be read."""
    d = Path(data_dir)
    pack = load_pack(d, report, state)
    out = Path(out_dir) if out_dir else d / LANDING_DIR
    out.mkdir(parents=True, exist_ok=True)
    opts = {"stage_dir": str(stage_dir) if stage_dir else ""}
    away = off_mac(d, pack["records"], opts)
    steps = {sid: check_step(sid, pack["records"].get(sid), d, opts, out, away=away) for sid in pp.STEP_IDS}
    notes = list(pack["notes"])
    if away:
        notes.append(f"checked away from the Mac: none of the pack's recorded files is under {d}; steps reported done "
                     "are 'not uploaded' until their files are sent (docs/runbooks/A-landing-check.md)")
    extra = sorted(set(pack["records"]) - set(pp.STEP_IDS))
    if extra:
        notes.append(f"steps in the pack this check does not know: {extra}")
    try:
        mc = missing_cells(d, steps, opts, out)
    except Exception as e:  # noqa: BLE001 - reported, the rest of the landing report still stands
        mc = {"written": False, "scope": f"failed: {type(e).__name__}: {e}"}
    rep = {"schema": SCHEMA, "ticket": TICKET, "generated_utc": pp._stamp(now or pp._utcnow()), "data_dir": str(d),
           "inputs": pack["paths"], "exit_code": _exit(steps),
           "summary": {v: sum(1 for s in steps.values() if s["verdict"] == v)
                       for v in (PASS, FAIL, NOT_LANDED, NOT_UPLOADED, MISSING)},
           "away_from_mac": away,
           "contradictions": [s["id"] for s in steps.values() if s["contradiction"]],
           "steps": [steps[s] for s in pp.STEP_IDS], "tickets": ticket_verdicts(steps, Path(team_dir) if team_dir else None),
           "missing_cells": mc, "notes": notes,
           "pack_exit_code": (pack["report"] or {}).get("exit_code")}
    pp._atomic_write(out / REPORT_JSON, json.dumps(rep, indent=1, default=str) + "\n")
    pp._atomic_write(out / REPORT_MD, _md(rep))
    rep["files"] = {"json": str(out / REPORT_JSON), "md": str(out / REPORT_MD)}
    return rep


# ------------------------------------------------------------------------------------------------ command line

def main(argv: list[str] | None = None) -> int:
    ap = pp._Parser(prog="python -m econquest.ingestion.landing", description=__doc__.split("\n\n")[0])
    ap.add_argument("command", choices=("check",))
    ap.add_argument("--data", default="data", help="econquest data folder (default data)")
    ap.add_argument("--report", help="report.json Sam sent (default <data>/live/pullpack/report.json)")
    ap.add_argument("--state", help="state.json (default: next to --report, else <data>/live/pullpack/state.json)")
    ap.add_argument("--stage-dir", help="the staged universe folder, when it is not where state.json says")
    ap.add_argument("--out", help="output folder (default <data>/live/landing)")
    ap.add_argument("--json", action="store_true", help="print the landing report as JSON")
    a = ap.parse_args(argv)
    d = Path(a.data)
    problem = pp.data_folder_problem(d)                 # EQ-A-0138: names the ~/Downloads release-data/ gotcha
    if problem:
        print(f"error: {problem}", file=sys.stderr)
        return EXIT_ERROR
    try:
        rep = check(d, a.report, a.state, stage_dir=a.stage_dir, out_dir=a.out)
    except LandingError as e:
        print(f"error: {e}", file=sys.stderr)
        return EXIT_ERROR
    except KeyboardInterrupt:
        print("interrupted: the landing check changes no data file; rerun it", file=sys.stderr)
        return EXIT_ERROR
    except Exception as e:  # noqa: BLE001 - EQ-A-0138: a damaged pack ends in one plain line, never a traceback
        print(f"error: the landing check could not finish ({type(e).__name__}: {' '.join(str(e).split())[:200]}). It "
              "changes no data file outside the landing folder; check that report.json and state.json are the files "
              "`econquest mac-pull run` wrote, then rerun", file=sys.stderr)
        return EXIT_ERROR
    if a.json:
        print(json.dumps(rep, indent=1, default=str))
    else:
        for s in rep["steps"]:
            bad = [c["name"] for c in s["checks"] if c["required"] and not c["ok"]]
            print(f"{s.get('number', ''):>2} {s['id']:<14} reported {s['status_reported'] or '-':<8} landing "
                  f"{s['verdict']:<10}" + (" REPORT SAYS DONE, DISK FAILS" if s["contradiction"] else "")
                  + (f" failing: {'; '.join(bad)[:200]}" if bad else (f" {s.get('note', '')}" if s.get("note") else "")))
        for t, x in rep["tickets"].items():
            print(f"{t}: {x['verdict']}" + (f" (waiting on {len(x['waiting_on'])})" if x["waiting_on"] else ""))
        print(f"missing cells: {rep['missing_cells'].get('scope')}")
        print(f"[landing] exit {rep['exit_code']}; report: {rep['files']['md']}")
    return rep["exit_code"]


if __name__ == "__main__":
    raise SystemExit(main())
