"""data/market_history/prices.csv: daily FX history for the GARCH, copula, HMM and econometrics layers.

Official build (EQ-A-0054, Sam 2026-10-24 12:31Z "Rebuild from official FX only"). prices.csv is rebuilt from the
BIS daily exchange rates (WS_XRU, primary) with the ECB euro reference rates (EXR) as the cross-check and as the
fallback for a currency BIS does not serve, through the EQ-A-0040 clients in feeds.py (batching, https_get with
redirects refused and a size cap, retries, FeedUnreachable fail-fast). Same FX column names (PRICE_FX_COLUMNS) and
the same quote convention as before: units of the currency per 1 US dollar. The country ETF columns
(LEGACY_ETF_COLUMNS) are dropped: they came from the workbook's GOOGLEFINANCE formulas and have no official source.

    build_official_fx_history(data_dir, start, end)          # pull pack step 1b; stages, does not touch prices.csv
    build_official_fx_history(data_dir, start, end, apply=True)
    apply_official_fx_history(data_dir, vintage_id=None)       # archive the GOOGLEFINANCE files, install the build

Point in time, in this order:
1. the raw pulls are saved first, as delivered, into an append-only vintage
   data/market_history/vintages/<YYYY-MM-DD>T<HHMMSS>Z-<hash8>/ (raw_bis_xru_history.csv, raw_ecb_exr_history.csv,
   request.json; files 0444, folder never overwritten, row appended to vintages/index.csv: the feeds.save_vintage
   pattern);
2. prices.csv is built from that vintage's files read back from disk (so the build is reproducible from the record)
   into data/market_history/builds/<vintage_id>/ with prices.provenance.json (source, series key, retrieved time and
   licence per column, sha256 of prices.csv) and disagreements.csv;
3. only `apply` replaces data/market_history/prices.csv (+ prices.provenance.json next to it). It is kept separate
   because the prices.csv contract change (ETF columns dropped) waits for Team B (handoff under EQ-A-0054).

No forward fill and no carry-over: a date a source did not publish stays empty. One source per column, never mixed:
BIS when it serves the currency, else the ECB rate converted through the same date's EUR/USD (feeds.ecb_per_usd).
BIS and ECB disagreeing by more than `tol` on a date is written to disagreements.csv and counted in the sidecar,
not resolved. Administered and pegged rates (ARS, VES, NGN, PKR, XOF, BZD) are kept as published, with a note
(FX_HISTORY_NOTES); the XOF/EUR and BZD/USD pegs are checked, never written as data. A column no source serves stays
in prices.csv, empty, with the reason in the sidecar.

Lowest-priority fallback (EQ-A-0073, Sam 2026-10-24 20:37Z; AGENT-08 brief for Team B's empty columns): a column
BIS and the ECB both leave empty is filled, in this order and one source per column, (1) for a currency pegged to the
euro (feeds.HARD_PEGS, anchor EUR: XOF) from its legal parity times the ECB EUR per USD of the same date, (2) else
from theratesapi.com (official/theratesapi.py: a mirror of Banca d'Italia / ECB reference rates; per-USD rates
computed by the mirror), one request per business date for all such currencies, throttled to
THERATES_REQUESTS_PER_SECOND, deduplicated on the returned date (a holiday repeats the previous working day; never
forward-filled). The answers are cached under data/market_history/.cache/theratesapi/<date>.json so an interrupted
pull resumes, and every response used is saved in the vintage (raw_theratesapi_history.csv as rows,
raw_theratesapi_responses.csv as bodies with sha256). theratesapi.com values are internal research only (EXC-005):
the sidecar names the source and licence per column and lists them under `exceptions`; client output must leave
them out. The fallbacks run only for a vintage whose request.json lists them (`fallbacks`), so a vintage saved before
EQ-A-0073 rebuilds byte for byte as before. `--no-theratesapi` turns the mirror off.

Holds (EQ-A-0077, vintages whose request.json has "checks": CHECKS_VERSION): the mirror's rates are cross-checked
daily against BIS / ECB where they also quote the currency (disagreements.csv, theratesapi_vs_bis / _vs_ecb); a USDBZD
peg breach, a mirror column whose last observation is more than STALE_BUSINESS_DAYS business days before the end,
and a mirror one-day move above OUTLIER_THRESHOLDS hold the build: it is not staged (FxHistoryHeld; review in
data/market_history/reviews/<vintage_id>/) until each outlier date is released through the review ledger
(`release`) or the column is dropped with a recorded reason (`drop`); values are never changed. Runbook:
docs/runbooks/A-official-fx.md, "Price-history holds".

GOOGLEFINANCE (Google's terms: informational only, not for trading or professional use; historical data is not to be
accessed via the Sheets API). The previous prices.csv is kept as a read-only, restricted-licence archive under
data/market_history/archive/ for audit only: load_prices reads top-level *.csv only and replay does not freeze
archive/, and the data room withholds it (dataroom.restricted_reason). `update_prices_from_sheet_json` (the Sheets
export import behind `econquest prices --sheet-json`) refuses unless ECONQUEST_ALLOW_GOOGLEFINANCE=1, and then
writes only a restricted research file, never prices.csv.

Command line (Sam's Mac; this cloud cannot reach BIS or the ECB):
    python -m econquest.ingestion.market_history build [--start 2023-10-18] [--end 2026-10-24] [--apply] [--no-theratesapi]
    python -m econquest.ingestion.market_history apply [--vintage <id>]
    python -m econquest.ingestion.market_history restricted     # exit 1 while the engine can read GOOGLEFINANCE data
    python -m econquest.ingestion.market_history stage --vintage <id> | review [--build <folder>]
    python -m econquest.ingestion.market_history release --column C --date D --author A (--approver B | --self-approved)
    python -m econquest.ingestion.market_history drop --column C --reason TEXT --author A
"""
from __future__ import annotations

import argparse
import contextlib
import csv
import datetime as dt
import hashlib
import json
import os
import re
import sys
import tempfile
from pathlib import Path
from typing import Callable

import numpy as np
import pandas as pd

# ------------------------------------------------------------------------------------------------ columns and sources
PRICE_FX_COLUMNS = ("USDVND", "USDPHP", "USDCNY", "USDMYR", "USDSGD", "USDJPY", "USDKRW", "USDINR", "USDPKR", "USDBZD",
                    "USDBRL", "USDARS", "USDCOP", "USDVES", "USDNGN", "USDXOF", "USDZMW")
LEGACY_ETF_COLUMNS = ("VNM", "EPHE", "MCHI", "EWM", "EWS", "EWJ", "EWY", "INDA", "EWZ", "ARGT", "GXG", "EEM")
ETF_DROPPED_REASON = ("dropped (Sam 2026-10-24 12:31Z, EQ-A-0054): GOOGLEFINANCE country ETF close, no official free "
                      "source; equity factors fall back to judgement in the engine (Team B)")
QUOTE_CONVENTION = "units of the currency per 1 US dollar (CCY per USD), as BIS WS_XRU publishes them"
FILL_RULE = "none: a date a source did not publish stays empty (no forward fill, no carry-over)"
EUR_XOF_PEG = 655.957          # XOF per EUR, fixed parity
USD_BZD_PEG = 2.0              # BZD per USD, fixed parity
FX_HISTORY_TOL = 0.01          # |BIS - ECB| / BIS on a date: above this the date is reported (as feeds.FX_CROSS_TOL)
FX_HISTORY_YEARS = 3
SCHEMA = "econquest.market_history.provenance/1"
TICKET = "EQ-A-0054"

# Notes kept with administered or pegged series: the published rate is kept as it is, never adjusted.
FX_HISTORY_NOTES = {
    "USDARS": "administered: official rate as published; parallel and other market rates differ and are not used",
    "USDVES": "administered: official rate as published; parallel market rates differ and are not used",
    "USDNGN": "managed: official rate as published, including the 2023-24 regime changes; not smoothed",
    "USDPKR": "managed float: official rate as published",
    "USDXOF": (f"peg: XOF is fixed to the euro at {EUR_XOF_PEG} XOF per EUR, so XOF per USD moves with EUR/USD; kept "
               "as published, checked against the parity times the ECB EUR per USD of the same date"),
    "USDBZD": (f"hard peg: {USD_BZD_PEG:.2f} BZD per USD; kept as published only if BIS WS_XRU serves it; the ECB does "
               "not publish BZD; the parity is never written as data"),
}

GOOGLEFINANCE_LICENCE = ("GOOGLEFINANCE via Google Sheets: Google's terms say informational only, not for trading or "
                         "professional use, historical data not to be accessed via the Sheets API; restricted: "
                         "personal non-commercial research only, never desk numbers or a publish (Sam 2026-10-24, "
                         "EQ-A-0054)")
GOOGLEFINANCE_FILE_REASON = ("licence: GOOGLEFINANCE-derived market history (Google terms: not for trading or "
                             "professional use, no Sheets API access to historical data); restricted archive for audit "
                             "only, may not be passed to an external validator (EQ-A-0054)")
SPREADS_RESTRICTED_REASON = ("spread history (EQ-A-0063): unverified series; OECD-on-FRED third-party data "
                             "restricted")
GOOGLEFINANCE_OPT_IN_ENV = "ECONQUEST_ALLOW_GOOGLEFINANCE"
GOOGLEFINANCE_REFUSED = (
    "GOOGLEFINANCE prices are not a desk source (Sam 2026-10-24 12:31Z: rebuild prices.csv from official FX only). "
    "Build the history from BIS/ECB instead:  python -m econquest.ingestion.market_history build --apply . "
    f"For non-desk research only, set {GOOGLEFINANCE_OPT_IN_ENV}=1: the import then writes a restricted research file "
    "under data/market_history/research/, never prices.csv.")

PRICES_NAME = "prices.csv"
SIDECAR_NAME = "prices.provenance.json"
DISAGREEMENTS_NAME = "disagreements.csv"
RAW_BIS_NAME = "raw_bis_xru_history.csv"
RAW_ECB_NAME = "raw_ecb_exr_history.csv"
REQUEST_NAME = "request.json"
THERATES_RAW_NAME = "raw_theratesapi_history.csv"            # EQ-A-0073: rows used (one per currency and date)
THERATES_RESPONSES_NAME = "raw_theratesapi_responses.csv"    # EQ-A-0073: every response body, with its sha256
THERATES_CACHE = (".cache", "theratesapi")   # data/market_history/.cache/theratesapi/<date>.json (dot: replay skips it)
from .official.theratesapi import THERATES_REQUESTS_PER_SECOND  # noqa: E402  (SEC-A-009 L2: one constant, 4 a second)
THERATES_EXCEPTION = "EXC-005"
# SEC-A-009 M2 (owner decision): the rates in prices.csv and the fx3m cells go to the validator under NDA (EXC-005,
# README line in dataroom); the raw mirror answers and the answer cache stay out of the room.
THERATES_ROOM_REASON = ("licence: raw theratesapi.com answers (mirror of Banca d'Italia rates, internal research use "
                        "only, EXC-005, EQ-A-0073); the rates themselves reach the validator under NDA through "
                        "prices.csv and provenance, the raw answers are withheld")
REVIEWS_ROOM_REASON = ("review state (EQ-A-0077): data/market_history/reviews/ holds the price-history holds of builds "
                       "that were not staged, with theratesapi.com values (EXC-005); the staged build carries its own "
                       "fx_review.csv")
# Sub-folders of data/market_history that are never engine inputs (load_prices reads top-level *.csv only) and that
# replay.freeze_inputs skips.
NON_INPUT_DIRS = ("vintages", "builds", "archive", "research", ".cache", "reviews")
# SEC-A-007 M1: the only market_history sub-folders whose files may go to an external validator (official BIS/ECB raw
# pulls and the builds made from them). Every other sub-folder (archive, research, repairs, anything added later) is
# withheld from the data room: fail closed, because GOOGLEFINANCE-era copies land in ad-hoc folders.
ROOM_SAFE_DIRS = ("vintages", "builds")
VINTAGE_ID_RE = re.compile(r"\d{4}-\d{2}-\d{2}T\d{6}Z-[0-9a-f]{8}")    # save_fx_history_vintage folder names
DISAGREEMENT_COLUMNS = ["date", "column", "currency", "check", "primary", "primary_source", "other", "other_source",
                        "rel_diff", "tolerance", "note"]
VINTAGE_INDEX_COLUMNS = ["vintage_id", "retrieved_utc", "hash", "n_files"]


class GoogleFinanceRefused(SystemExit):
    """The GOOGLEFINANCE / Sheets import was asked for without the research opt-in (EQ-A-0054)."""


class FxHistoryError(RuntimeError):
    """The official FX history could not be built or applied (nothing is half-written)."""


class FxHistoryHeld(FxHistoryError):
    """EQ-A-0077: the build has open holds (stale or off-peg column, unreleased one-day outlier) and was not staged.
    `holds` is the review table (FX_REVIEW_COLUMNS), `review` the folder holding fx_review.csv and holds.json."""

    def __init__(self, msg: str, holds: pd.DataFrame, review: Path | None = None, vintage_id: str = ""):
        super().__init__(msg)
        self.holds, self.review, self.vintage_id = holds, review, vintage_id


# ------------------------------------------------------------------------------------------------ EQ-A-0077 checks
# The checks below run for a vintage whose request.json says "checks": CHECKS_VERSION (every vintage saved by this
# code); a vintage saved before EQ-A-0077 (Sam's 2026-10-25T000005Z-d1f504f1) rebuilds byte for byte as before, and
# `python -m econquest.ingestion.market_history review --build <folder>` shows what the checks say about it.
CHECKS_VERSION = "EQ-A-0077"
# Columns whose source is theratesapi.com (fallback 'theratesapi') get the staleness and outlier holds. BIS and ECB
# columns do not: BIS WS_XRU is published weekly with a lag (in Sam's 2026-10-25 build USDARS ended 2026-10-14, 7
# business days before the end, right at the limit, and USDCOP 5), so a 7-day rule would hold an official build run a
# day later; and an official one-day move (ARS +118% in December 2023) is the published rate, with no better source to
# review it against. The BIS-vs-ECB cross-check covers the official columns the ECB quotes (not ARS or COP).
HOLD_SOURCES = ("theratesapi",)
STALE_BUSINESS_DAYS = 7        # Mon-Fri after the last observation up to the build end (no holiday calendar)
# One-day move |x_t / x_prev - 1| between consecutive observations above which a date is flagged for review. Kept
# here as the settings table; change a value only with a note in docs/runbooks/A-official-fx.md.
OUTLIER_DEFAULT = 0.15
OUTLIER_THRESHOLDS = {
    "VND": 0.05,   # managed: the State Bank of Vietnam trading band is +-5% around its central rate
    "BZD": 0.01,   # hard peg 2.00 per USD: any move above the 1% peg tolerance is suspect (the peg check holds too)
    "NGN": 0.15,   # managed, regime jumps (about 34% on 2024-01-31): deliberately NOT raised, so a jump is flagged and
    "VES": 0.15,   #   released by review (ledger 'apply'), never passed silently and never dropped by the check
}
PEG_HOLD_COLUMNS = ("USDBZD",)                 # a peg_check breach in these columns holds the build
THERATES_CROSS_CHECK = ("VND", "PKR", "BZD", "VES", "NGN", "ZMW")   # asked of the mirror whenever it is called
HOLD_TABLE = "market_history.prices"           # ledger table of the price-history holds (data/live/review_ledger.csv)
COLUMN_CELL = "(column)"                       # ledger 'country' of a whole-column decision (drop = reject + reason)
REVIEWS_DIR = "reviews"                        # data/market_history/reviews/<vintage_id>/ (mutable review state)
FX_REVIEW_NAME = "fx_review.csv"
HOLDS_NAME = "holds.json"
FX_REVIEW_COLUMNS = ["table", "key", "country", "check", "status", "live", "previous", "rel_move", "threshold",
                     "reason", "vintage_id", "decided_by"]


def _mh(data_dir) -> Path:
    return Path(data_dir) / "market_history"


def _sha(b: bytes) -> str:
    return hashlib.sha256(b).hexdigest()


def _write_ro(path: Path, body: bytes) -> None:
    path.write_bytes(body)
    os.chmod(path, 0o444)


def _atomic_bytes(path: Path, body: bytes, mode: int = 0o644) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "wb") as f:
            f.write(body)
        os.chmod(tmp, mode); os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def bis_areas() -> dict[str, str]:
    """Currency -> BIS WS_XRU reference area for every PRICE_FX_COLUMNS currency: the country's ISO2, or the shared
    area of feeds.SHARED_FX_AREA (XOF -> SN). UNVERIFIED with the rest of the XRU key until the first Mac pull."""
    from .feeds import SHARED_FX_AREA
    own = {"VND": "VN", "PHP": "PH", "CNY": "CN", "MYR": "MY", "SGD": "SG", "JPY": "JP", "KRW": "KR", "INR": "IN",
           "PKR": "PK", "BZD": "BZ", "BRL": "BR", "ARS": "AR", "COP": "CO", "VES": "VE", "NGN": "NG", "ZMW": "ZM"}
    return {c[3:]: SHARED_FX_AREA.get(c[3:], own.get(c[3:], "")) for c in PRICE_FX_COLUMNS}


# ------------------------------------------------------------------------------------------------ GOOGLEFINANCE import
def parse_sheet_values(values: list[list], headings: list[str] | None = None) -> pd.DataFrame:
    """values: rows of the Market History tab starting at row 2 (the heading row). Returns a wide DataFrame
    indexed by date with one column per ticker (the last word of each heading)."""
    if not values:
        return pd.DataFrame()
    head = headings or [str(h) for h in values[0]]
    body = values[1:]
    series = {}
    for col in range(0, len(head), 2):
        h = str(head[col]).strip()
        if not h:
            continue
        ticker = h.split()[-1]
        dates, px = [], []
        for r in body:
            if len(r) <= col + 1 or r[col] in ("", None) or r[col + 1] in ("", None):
                continue
            d = pd.to_datetime(str(r[col]), errors="coerce")
            if pd.isna(d):
                continue                                   # header rows such as "Date"/"Close"
            try:
                v = float(str(r[col + 1]).replace(",", ""))
            except ValueError:
                continue
            dates.append(d.normalize()); px.append(v)
        if dates:
            s = pd.Series(px, index=pd.DatetimeIndex(dates))
            series[ticker] = s[~s.index.duplicated(keep="last")].sort_index()
    df = pd.DataFrame(series).sort_index()
    df.index.name = "date"
    return df


def merge_prices(existing: pd.DataFrame | None, new: pd.DataFrame) -> pd.DataFrame:
    """Keep every date already stored (point-in-time: a price once recorded is not rewritten) and add new dates
    and columns. Where both have a value for the same date, the new one wins only if the old one is missing."""
    if existing is None or existing.empty:
        return new
    out = existing.combine_first(new)
    out.index.name = "date"
    return out.sort_index()


def googlefinance_opt_in(env: dict | None = None) -> bool:
    """True only when ECONQUEST_ALLOW_GOOGLEFINANCE=1 (non-desk research). Same pattern as ECONQUEST_ALLOW_YAHOO."""
    return str((env if env is not None else os.environ).get(GOOGLEFINANCE_OPT_IN_ENV, "")).strip() == "1"


def update_prices_from_sheet_json(json_path: str | Path, data_dir: str | Path, headings: list[str] | None = None,
                                  env: dict | None = None) -> tuple[Path, dict]:
    """The Market History tab's GOOGLEFINANCE values (saved Sheets API values.get results). Refused
    (GoogleFinanceRefused, nothing read or written) unless ECONQUEST_ALLOW_GOOGLEFINANCE=1. With the opt-in, the
    values are merged into data/market_history/research/prices-googlefinance-research.csv, tagged restricted in a
    .licence.json next to it: never data/market_history/prices.csv, which only the official build writes."""
    if not googlefinance_opt_in(env):
        raise GoogleFinanceRefused(GOOGLEFINANCE_REFUSED)
    raw = json.loads(Path(json_path).read_text())
    blobs = raw if isinstance(raw, list) and raw and isinstance(raw[0], dict) else [raw]
    rows: list[list] = []
    for b in blobs:
        rows += b["values"] if isinstance(b, dict) else b
    new = parse_sheet_values(rows, headings)
    out = _mh(data_dir) / "research" / "prices-googlefinance-research.csv"
    old = pd.read_csv(out, index_col=0, parse_dates=True) if out.exists() else None
    merged = merge_prices(old, new)
    body = merged.to_csv().encode()
    _atomic_bytes(out, body)
    _atomic_bytes(out.with_suffix(".licence.json"), json.dumps(
        {"file": out.name, "sha256": _sha(body), "source": "GOOGLEFINANCE (workbook Market History tab, Sheets API export)",
         "licence": GOOGLEFINANCE_LICENCE, "restricted": True, "ticket": TICKET,
         "engine": "never read: research/ is outside load_prices and replay"}, indent=1).encode())
    summary = {"series": int(merged.shape[1]), "dates": int(len(merged)), "first": str(merged.index.min().date()) if len(merged) else None,
               "last": str(merged.index.max().date()) if len(merged) else None,
               "new_dates": int(len(new.index.difference(old.index))) if old is not None and len(new) else int(len(new)),
               "licence": "restricted (GOOGLEFINANCE, research only)", "desk": False}
    return out, summary


# ------------------------------------------------------------------------------------------------ vintages (raw pulls)
def _vintage_root(data_dir) -> Path:
    return _mh(data_dir) / "vintages"


def list_fx_history_vintages(data_dir) -> list[str]:
    root = _vintage_root(data_dir)
    return sorted(p.name for p in root.iterdir() if p.is_dir() and p.name[:4].isdigit()) if root.exists() else []


def save_fx_history_vintage(data_dir, files: dict[str, bytes], now: dt.datetime | None = None) -> Path:
    """Append-only vintage of the raw pulls (feeds.save_vintage pattern): folder <ts>-<hash8>, created with
    exist_ok=False, files 0444, one row appended to vintages/index.csv under a lock."""
    from .feeds import _content_hash, _utc
    from .ledger import locked_append
    now = _utc(now)
    digest = _content_hash(files)
    root = _vintage_root(data_dir); root.mkdir(parents=True, exist_ok=True)
    v = root / f"{now.strftime('%Y-%m-%dT%H%M%SZ')}-{digest[:8]}"
    v.mkdir(exist_ok=False)
    for name in sorted(files):
        _write_ro(v / name, files[name])
    with locked_append(root / "index.csv", VINTAGE_INDEX_COLUMNS) as (w, _f, new):
        if new:
            w.writeheader()
        w.writerow({"vintage_id": v.name, "retrieved_utc": now.strftime("%Y-%m-%dT%H:%M:%SZ"), "hash": digest,
                    "n_files": len(files)})
    return v


def check_vintage_id(vintage_id) -> str:
    """vintage_id if it has the save_fx_history_vintage form, else FxHistoryError (SEC-A-007 L3: an id from the
    command line is joined to data paths, so '../x' or an absolute path is refused before any path is built)."""
    if not isinstance(vintage_id, str) or not VINTAGE_ID_RE.fullmatch(vintage_id):
        raise FxHistoryError(f"not an FX history vintage id: {str(vintage_id)[:80]!r} (expected YYYY-MM-DDTHHMMSSZ-hash8)")
    return vintage_id


def verify_fx_history_vintage(data_dir, vintage_id: str) -> dict:
    """Recompute the vintage's content hash against the first vintages/index.csv row for it (and the hash8 in the
    folder name). Raises FxHistoryError on any mismatch or a missing row."""
    from .feeds import _content_hash
    check_vintage_id(vintage_id)
    v = _vintage_root(data_dir) / vintage_id
    if not v.is_dir():
        raise FxHistoryError(f"no FX history vintage {vintage_id!r} under {_vintage_root(data_dir)}")
    files = {q.name: q.read_bytes() for q in v.iterdir() if q.is_file()}
    digest = _content_hash(files)
    idx = _vintage_root(data_dir) / "index.csv"
    rows = []
    if idx.exists():
        with open(idx, newline="") as f:
            rows = [r for r in csv.DictReader(f) if r.get("vintage_id") == vintage_id]
    if not rows:
        raise FxHistoryError(f"FX history vintage {vintage_id} has no row in {idx}")
    want = rows[0]
    problems = []
    if want.get("hash") != digest:
        problems.append(f"hash {digest[:16]} != index {str(want.get('hash'))[:16]}")
    if str(want.get("n_files")) != str(len(files)):
        problems.append(f"{len(files)} files != index {want.get('n_files')}")
    if not vintage_id.endswith(digest[:8]):
        problems.append(f"folder hash8 != content hash {digest[:8]}")
    if problems:
        raise FxHistoryError(f"FX history vintage {vintage_id} failed verification: " + "; ".join(problems))
    return {"vintage_id": vintage_id, "hash": digest, "n_files": len(files), "retrieved_utc": want.get("retrieved_utc")}


def _read_raw(path: Path) -> pd.DataFrame | None:
    from .sources import read_csv_keep_na_code
    if not path.is_file():
        return None
    df = read_csv_keep_na_code(path, dtype={"period": str, "series": str, "iso": str, "sdmx_key": str})
    df["value"] = pd.to_numeric(df["value"], errors="coerce")
    return df


# ------------------------------------------------------------------------------------------------ build
def _series_in_range(s: pd.Series, start: dt.date, end: dt.date) -> pd.Series:
    if not len(s):
        return pd.Series(dtype=float)
    idx = pd.to_datetime(pd.Index(s.index), errors="coerce")
    out = pd.Series(s.to_numpy(dtype=float), index=idx)
    out = out[out.index.notna() & np.isfinite(out.to_numpy())]
    out = out[(out.index >= pd.Timestamp(start)) & (out.index <= pd.Timestamp(end))]
    return out[~out.index.duplicated(keep="last")].sort_index()


def _keys(raw: pd.DataFrame | None, series: str) -> str:
    if raw is None or "sdmx_key" not in raw.columns:
        return ""
    k = raw.loc[raw["series"].astype(str) == series, "sdmx_key"].dropna().astype(str).unique()
    return "; ".join(sorted(k))


def build_prices(raw_bis: pd.DataFrame | None, raw_ecb: pd.DataFrame | None, start: dt.date, end: dt.date,
                 retrieved_utc: str = "", tol: float = FX_HISTORY_TOL, failures: list[str] | None = None,
                 raw_therates: pd.DataFrame | None = None, fallbacks: dict | None = None, checks: bool = False
                 ) -> tuple[pd.DataFrame, dict, pd.DataFrame]:
    """(prices, sidecar dict without file hashes, disagreements) from the raw official tables. Pure: no I/O.
    prices: index `date`, columns PRICE_FX_COLUMNS in order, CCY per USD, missing where no source published.
    `fallbacks` (EQ-A-0073, from request.json; None = none, the pre-EQ-A-0073 build): {"peg": [currencies],
    "theratesapi": [currencies]} for columns BIS and the ECB leave empty: the EUR peg times the ECB EUR per USD,
    else the theratesapi.com rows in `raw_therates`.
    checks (EQ-A-0077, request.json "checks"): every theratesapi.com rate in `raw_therates` is also compared, date by
    date, with BIS and with the ECB wherever they quote the same currency on that date; a difference above `tol` is a
    disagreements.csv row (check theratesapi_vs_bis / theratesapi_vs_ecb), reported, never resolved."""
    from .feeds import (EXR_FLOW, EXR_KEY, EXR_USD, FX_PER_USD_SUFFIX, XRU_FLOW, XRU_SOURCE, ecb_per_usd,
                        fx_usd_series)
    from .market.forwards import BIS_SPOT_LICENCE, ECB_SPOT_LICENCE
    from .feeds import HARD_PEGS, peg_source
    from .official.theratesapi import THERATES_LICENCE, THERATES_SOURCE
    ecb_src = "ECB Data Portal SDMX REST EXR (data-api.ecb.europa.eu), converted to per-USD through EUR/USD of the same date"
    peg_ccys = set((fallbacks or {}).get("peg") or ())
    rates_ccys = set((fallbacks or {}).get("theratesapi") or ())
    rates_used: list[str] = []
    conv = ecb_per_usd(raw_ecb) if raw_ecb is not None and len(raw_ecb) else None
    eur_per_usd = _series_in_range(fx_usd_series(conv, "EUR"), start, end)
    areas = bis_areas()
    cols: dict[str, pd.Series] = {}
    meta: dict[str, dict] = {}
    dis: list[dict] = []
    for col in PRICE_FX_COLUMNS:
        ccy = col[3:]
        b = _series_in_range(fx_usd_series(raw_bis, ccy), start, end)
        e = _series_in_range(fx_usd_series(conv, ccy), start, end)
        m: dict = {"currency": ccy, "quote": f"{ccy} per USD"}
        if len(b):
            s = b
            m.update(source=XRU_SOURCE, sdmx_key=_keys(raw_bis, f"{ccy}{FX_PER_USD_SUFFIX}") or
                     f"{XRU_FLOW} D.{areas.get(ccy, '?')}.{ccy}.A", licence=BIS_SPOT_LICENCE)
        elif len(e):
            s = e
            m.update(source=ecb_src, sdmx_key=f"{EXR_FLOW} {EXR_KEY.format(ccy=ccy)} / {EXR_KEY.format(ccy=EXR_USD)}",
                     licence=ECB_SPOT_LICENCE)
        elif ccy in peg_ccys and len(eur_per_usd):           # EQ-A-0073: legal parity x ECB EUR per USD, same date
            s = HARD_PEGS[ccy].parity * eur_per_usd
            m.update(source=peg_source(ccy, HARD_PEGS[ccy], ecb_src),
                     sdmx_key=f"{HARD_PEGS[ccy].parity:g} x {EXR_FLOW} 1 / {EXR_KEY.format(ccy=EXR_USD)}",
                     licence=ECB_SPOT_LICENCE, fallback="peg")
        elif ccy in rates_ccys and len(t := _series_in_range(fx_usd_series(raw_therates, ccy), start, end)):
            s = t                                             # EQ-A-0073: lowest priority, internal research only
            m.update(source=THERATES_SOURCE, sdmx_key=f"theratesapi.com /api/<date>?base=USD&symbols={ccy}",
                     licence=THERATES_LICENCE, exception=THERATES_EXCEPTION, client_output="restricted (EXC-005)",
                     fallback="theratesapi")
            rates_used.append(col)
        else:
            s = pd.Series(dtype=float)
            m.update(source="", sdmx_key="", licence="",
                     reason=(f"no official daily rate: BIS {XRU_FLOW} returned no series for {ccy} "
                             f"(area {areas.get(ccy, '?')}) and the ECB reference rates do not quote it"
                             + ("; theratesapi.com returned no rate for it either" if ccy in rates_ccys else "")
                             + "; left empty, never estimated or filled"))
        m.update(retrieved_utc=retrieved_utc, n_obs=int(len(s)),
                 first=str(s.index.min().date()) if len(s) else None, last=str(s.index.max().date()) if len(s) else None)
        if col in FX_HISTORY_NOTES:
            m["note"] = FX_HISTORY_NOTES[col]
        # cross-check: BIS against ECB on every date both publish, reported, never resolved
        if len(b) and len(e):
            common = b.index.intersection(e.index)
            rel = (b[common] - e[common]).abs() / b[common].abs().clip(lower=1e-12)
            over = rel[rel > tol]
            m["cross_check"] = {"other": "ECB EXR via EUR/USD", "common_dates": int(len(common)),
                                "over_tolerance": int(len(over)), "max_rel_diff": float(rel.max()) if len(rel) else None,
                                "tolerance": tol}
            for d, r in over.items():
                dis.append({"date": d.date().isoformat(), "column": col, "currency": ccy, "check": "bis_vs_ecb",
                            "primary": float(b[d]), "primary_source": f"BIS {XRU_FLOW}", "other": float(e[d]),
                            "other_source": f"ECB {EXR_FLOW} via EUR/USD", "rel_diff": float(r), "tolerance": tol,
                            "note": "reported, not resolved: prices.csv keeps the BIS value"})
        elif len(s):
            m["cross_check"] = {"other": None, "common_dates": 0, "over_tolerance": 0, "max_rel_diff": None,
                                "tolerance": tol, "note": "only one official source quotes this currency"}
        if checks and raw_therates is not None and len(raw_therates):     # EQ-A-0077: mirror vs BIS / ECB, daily
            t_all = _series_in_range(fx_usd_series(raw_therates, ccy), start, end)
            xc = {}
            for name, off, off_src in (("bis", b, f"BIS {XRU_FLOW}"), ("ecb", e, f"ECB {EXR_FLOW} via EUR/USD")):
                common = t_all.index.intersection(off.index) if len(t_all) and len(off) else pd.DatetimeIndex([])
                rel = (t_all[common] - off[common]).abs() / off[common].abs().clip(lower=1e-12)
                over = rel[rel > tol]
                xc[name] = {"common_dates": int(len(common)), "over_tolerance": int(len(over)),
                            "max_rel_diff": float(rel.max()) if len(rel) else None}
                for d, r in over.items():
                    dis.append({"date": d.date().isoformat(), "column": col, "currency": ccy,
                                "check": f"theratesapi_vs_{name}", "primary": float(off[d]), "primary_source": off_src,
                                "other": float(t_all[d]), "other_source": "theratesapi.com", "rel_diff": float(r),
                                "tolerance": tol, "note": "reported, not resolved: BIS / ECB rank above theratesapi.com"})
            if len(t_all):
                m["theratesapi_cross_check"] = {**xc, "tolerance": tol}
        # pegs: checked against the parity, never written as data
        peg = None
        if m.get("fallback") == "peg":
            peg = None                                        # the column is the parity itself: nothing to check
        elif ccy == "XOF" and len(s) and len(eur_per_usd):
            common = s.index.intersection(eur_per_usd.index)
            peg = (s[common], EUR_XOF_PEG * eur_per_usd[common], f"{EUR_XOF_PEG} x ECB EUR per USD")
        elif ccy == "BZD" and len(s):
            peg = (s, pd.Series(USD_BZD_PEG, index=s.index), f"parity {USD_BZD_PEG:.2f}")
        if peg is not None and len(peg[0]):
            got, want, what = peg
            rel = (got - want).abs() / want.abs()
            over = rel[rel > tol]
            m["peg_check"] = {"against": what, "dates": int(len(rel)), "over_tolerance": int(len(over)),
                              "max_rel_diff": float(rel.max()), "tolerance": tol}
            for d, r in over.items():
                dis.append({"date": d.date().isoformat(), "column": col, "currency": ccy, "check": "peg",
                            "primary": float(got[d]), "primary_source": m["source"], "other": float(want[d]),
                            "other_source": what, "rel_diff": float(r), "tolerance": tol,
                            "note": "published rate kept; off the parity by more than the tolerance"})
        cols[col] = s
        meta[col] = m
    idx = pd.DatetimeIndex(sorted(set().union(*[set(s.index) for s in cols.values()])), name="date")
    prices = pd.DataFrame({c: s.reindex(idx) for c, s in cols.items()}, index=idx)[list(PRICE_FX_COLUMNS)]
    prices.index.name = "date"
    disagreements = pd.DataFrame(dis, columns=DISAGREEMENT_COLUMNS).sort_values(["column", "date", "check"]).reset_index(drop=True)
    side = {"schema": SCHEMA, "ticket": TICKET, "decision": "Sam 2026-10-24 12:31Z: rebuild from official FX only",
            "start": start.isoformat(), "end": end.isoformat(), "retrieved_utc": retrieved_utc,
            "quote_convention": QUOTE_CONVENTION, "fill": FILL_RULE,
            "columns": list(PRICE_FX_COLUMNS), "series": meta,
            "dropped_columns": {c: ETF_DROPPED_REASON for c in LEGACY_ETF_COLUMNS},
            "disagreements": {"file": DISAGREEMENTS_NAME, "rows": int(len(disagreements)), "tolerance": tol,
                              "columns": sorted(disagreements["column"].unique().tolist())},
            "unserved": sorted(c for c, m in meta.items() if not m["n_obs"]),
            "failures": list(failures or [])}
    if fallbacks is not None:                                 # EQ-A-0073; absent for a pre-EQ-A-0073 vintage
        side["fallbacks"] = {"order": "BIS WS_XRU, ECB EXR, EUR peg x ECB EUR per USD, theratesapi.com (lowest)",
                             "peg": sorted(peg_ccys), "theratesapi": sorted(rates_ccys)}
        side["exceptions"] = {THERATES_EXCEPTION: {"columns": rates_used, "licence": THERATES_LICENCE,
                                                   "use": "internal research only; not for client output"}} if rates_used else {}
    return prices, side, disagreements


def _bdays_after(last: dt.date, end: dt.date) -> int:
    """Business days (Mon-Fri) after `last` up to and including `end`."""
    return int(np.busday_count(last + dt.timedelta(days=1), end + dt.timedelta(days=1))) if end > last else 0


def fx_history_holds(prices: pd.DataFrame, side: dict, end, vintage_id: str = "", *,
                     thresholds: dict | None = None, stale_days: int = STALE_BUSINESS_DAYS) -> pd.DataFrame:
    """EQ-A-0077 review rows (FX_REVIEW_COLUMNS, status 'hold') of a build. Pure: no I/O, values never changed.
      stale    a HOLD_SOURCES column whose last observation is more than `stale_days` business days before `end`
      peg      a PEG_HOLD_COLUMNS column whose peg_check has a date off the parity by more than its tolerance
      outlier  a HOLD_SOURCES column's one-day move |x_t / x_prev - 1| (consecutive observations) above the
               currency's OUTLIER_THRESHOLDS value (default OUTLIER_DEFAULT): one row per date, key column, country
               the date, live the value
    stale and peg rows are whole-column holds (country COLUMN_CELL)."""
    end = pd.Timestamp(end).date()
    th = {**OUTLIER_THRESHOLDS, **(thresholds or {})}
    rows = []

    def row(col, cell, check, live, reason, previous=np.nan, rel=np.nan, threshold=np.nan):
        rows.append({"table": HOLD_TABLE, "key": col, "country": cell, "check": check, "status": "hold", "live": live,
                     "previous": previous, "rel_move": rel, "threshold": threshold, "reason": reason,
                     "vintage_id": vintage_id, "decided_by": ""})
    for col, m in (side.get("series") or {}).items():
        if col not in prices.columns:
            continue
        s = prices[col].dropna()
        if m.get("fallback") in HOLD_SOURCES and len(s):
            last = s.index.max().date()
            age = _bdays_after(last, end)
            if age > stale_days:
                row(col, COLUMN_CELL, "stale", float(s.iloc[-1]),
                    f"stale: last observation {last.isoformat()}, {age} business days before the build end "
                    f"{end.isoformat()} (limit {stale_days})")
            lim = float(th.get(m.get("currency", col[3:]), OUTLIER_DEFAULT))
            move = (s / s.shift(1) - 1).dropna()
            for d, r in move[move.abs() > lim].items():
                prev = float(s.shift(1)[d])
                row(col, d.date().isoformat(), "outlier", float(s[d]),
                    f"outlier: one-day move {r:+.1%} ({prev:.6g} -> {float(s[d]):.6g}) above {lim:.0%}; value kept, "
                    "release with `market_history release` or drop the column", prev, float(r), lim)
        pc = m.get("peg_check") or {}
        if col in PEG_HOLD_COLUMNS and int(pc.get("over_tolerance") or 0) > 0:
            row(col, COLUMN_CELL, "peg", np.nan,
                f"peg: {pc['over_tolerance']} of {pc.get('dates')} dates off {pc.get('against')} by more than "
                f"{float(pc.get('tolerance', FX_HISTORY_TOL)):.0%} (max {float(pc.get('max_rel_diff') or 0):.2%})")
    return pd.DataFrame(rows, columns=FX_REVIEW_COLUMNS)


def _hold_decisions(data_dir) -> pd.DataFrame:
    """Latest ledger decision per HOLD_TABLE cell (ledger.load_decisions), as strings."""
    from .ledger import load_decisions
    dec = load_decisions(Path(data_dir))
    return dec[dec["table"] == HOLD_TABLE].reset_index(drop=True) if len(dec) else dec


def resolve_fx_holds(holds: pd.DataFrame, decisions: pd.DataFrame | None, vintage_id: str = "") -> tuple[pd.DataFrame, dict]:
    """(review with status hold | released | dropped, record for the sidecar). How a hold ends (EQ-A-0077):
    - a whole column is dropped (emptied in prices.csv, listed unserved with the reason) when it has a hold in this
      build and its latest ledger decision on (HOLD_TABLE, column, COLUMN_CELL) is 'reject' with a non-empty note (the
      recorded reason); this is the only way past a stale or peg hold, and it also ends that column's outlier holds.
      A drop never touches a column that is not held;
    - an outlier date is released when ledger.effective_holds no longer holds it: an approved 'apply' (four-eyes or
      flagged self-approval) bound to the flagged value, exactly as quality-gate holds are released. The value is
      never changed either way.
    Anything else stays 'hold', and a build with a 'hold' row is not staged."""
    from .ledger import effective_holds
    dec = decisions if decisions is not None else pd.DataFrame()
    dropped: dict[str, dict] = {}
    used = []
    for r in (dec.itertuples(index=False) if len(dec) else ()):
        if r.table != HOLD_TABLE:
            continue
        if r.country == COLUMN_CELL and r.decision == "reject" and str(r.note).strip() and r.key in set(holds["key"]):
            dropped[r.key] = {"reason": str(r.note).strip(), "author": r.author, "ts_utc": r.ts_utc}
    out = holds.copy()
    outl = out[out["check"] == "outlier"]
    still = effective_holds(outl, dec if len(dec) else None, vintage_id) if len(outl) else set()
    by = {(r.key, r.country): r for r in dec.itertuples(index=False)} if len(dec) else {}
    for i, r in out.iterrows():
        if r["key"] in dropped:
            out.at[i, "status"] = "dropped"
            out.at[i, "decided_by"] = dropped[r["key"]]["author"]
        elif r["check"] == "outlier" and (HOLD_TABLE, r["key"], r["country"]) not in still:
            out.at[i, "status"] = "released"
            d = by.get((r["key"], r["country"]))
            flag = " (self-approved)" if d is not None and str(getattr(d, "self_approved", "")).strip().lower() == "yes" else ""
            out.at[i, "decided_by"] = f"{d.author} / {d.approver}{flag}" if d is not None else ""
    keys = {(r.key, r.country) for r in out.itertuples(index=False)} | {(k, COLUMN_CELL) for k in dropped}
    if len(dec):
        cols = [c for c in dec.columns if c != "live"] + ["live"]
        used = [{c: str(getattr(r, c)) for c in cols} for r in dec.itertuples(index=False) if (r.key, r.country) in keys]
    rec = {"released": sorted(f"{r.key} {r.country}" for r in out.itertuples(index=False) if r.status == "released"),
           "dropped": dropped, "open": int((out["status"] == "hold").sum()), "decisions": used}
    return out, rec


_DECISION_ID = ("ts_utc", "table", "key", "country", "decision", "author", "approver", "self_approved")


def recorded_decisions_missing(data_dir, side: dict) -> list[str]:
    """EQ-A-0090: the review.decisions rows of a build's sidecar that data/live/review_ledger.csv does not hold (matched
    on time, cell, decision, author, approver and self_approved). The ledger is append-only, so a recorded release or
    drop that is not there means the sidecar or the ledger was edited: apply refuses. [] for a build without a review."""
    from .ledger import read_ledger
    rows = list(((side or {}).get("review") or {}).get("decisions") or [])
    if not rows:
        return []
    led = read_ledger(Path(data_dir))
    have = {tuple(str(r.get(c, "")) for c in _DECISION_ID) for r in led.to_dict("records")}
    return [f"{r.get('key')} {r.get('country')} {r.get('decision')} by {r.get('author')} at {r.get('ts_utc')}"
            for r in rows if tuple(str(r.get(c, "")) for c in _DECISION_ID) not in have]


def _decisions_from_record(rec: dict | None) -> pd.DataFrame:
    """The ledger rows a build recorded in its sidecar (review.decisions), so a rebuild of that build reproduces it
    byte for byte whatever the ledger says now."""
    rows = list((rec or {}).get("decisions") or [])
    return pd.DataFrame(rows, dtype=str) if rows else pd.DataFrame()


def _default_range(start, end) -> tuple[dt.date, dt.date]:
    end = pd.Timestamp(end).date() if end is not None else dt.datetime.now(dt.timezone.utc).date()
    if start is not None:
        start = pd.Timestamp(start).date()
    else:
        try:
            start = end.replace(year=end.year - FX_HISTORY_YEARS)
        except ValueError:                                   # 29 February
            start = end.replace(year=end.year - FX_HISTORY_YEARS, day=28)
    if start >= end:
        raise FxHistoryError(f"start {start} must be before end {end}")
    return start, end


def _build_files(data_dir, vintage_id: str, tol: float = FX_HISTORY_TOL, decisions: pd.DataFrame | None = None,
                 review_out: list | None = None) -> tuple[dict, pd.DataFrame, dict, pd.DataFrame]:
    """The bytes of a build of a verified vintage (deterministic): ({name: bytes}, prices, sidecar, disagreements).
    EQ-A-0077 (vintage request.json "checks"): the holds are resolved with `decisions` (None: the ledger now, else
    the rows a build recorded, _decisions_from_record); the review table is appended to `review_out`; open holds
    raise FxHistoryHeld (nothing returned, nothing written here)."""
    info = verify_fx_history_vintage(data_dir, vintage_id)
    v = _vintage_root(data_dir) / vintage_id
    req = json.loads((v / REQUEST_NAME).read_text())
    start, end = dt.date.fromisoformat(req["start"]), dt.date.fromisoformat(req["end"])
    checks = req.get("checks") == CHECKS_VERSION
    prices, side, dis = build_prices(_read_raw(v / RAW_BIS_NAME), _read_raw(v / RAW_ECB_NAME), start, end,
                                     req.get("retrieved_utc", ""), tol, req.get("failures"),
                                     raw_therates=_read_raw(v / THERATES_RAW_NAME), fallbacks=req.get("fallbacks"),
                                     checks=checks)
    review = None
    if checks:
        holds = fx_history_holds(prices, side, end, vintage_id)
        review, rec = resolve_fx_holds(holds, _hold_decisions(data_dir) if decisions is None else decisions, vintage_id)
        if review_out is not None:
            review_out.append(review)
        if rec["open"]:
            raise FxHistoryHeld(_held_message(vintage_id, review), review, vintage_id=vintage_id)
        for col, d in sorted(rec["dropped"].items()):             # dropped: emptied, unserved, reason recorded
            prices[col] = np.nan
            m = side["series"][col]
            m.update(dropped={"reason": d["reason"], "by": d["author"], "ts_utc": d["ts_utc"],
                              "held_for": sorted(set(review.loc[review["key"] == col, "check"]))},
                     reason=f"dropped after an EQ-A-0077 hold: {d['reason']}", n_obs=0, first=None, last=None)
        prices = prices.dropna(how="all")
        side["unserved"] = sorted(c for c, m in side["series"].items() if not m["n_obs"])
        for col in rec["dropped"]:
            if THERATES_EXCEPTION in (side.get("exceptions") or {}) and col in side["exceptions"][THERATES_EXCEPTION]["columns"]:
                side["exceptions"][THERATES_EXCEPTION]["columns"].remove(col)
        side["review"] = {"checks": CHECKS_VERSION, "file": FX_REVIEW_NAME, "rows": int(len(review)),
                          "policy": {"hold_sources": list(HOLD_SOURCES), "stale_business_days": STALE_BUSINESS_DAYS,
                                     "outlier_default": OUTLIER_DEFAULT, "outlier_thresholds": dict(OUTLIER_THRESHOLDS),
                                     "peg_hold_columns": list(PEG_HOLD_COLUMNS),
                                     "held_means": "the build is not staged until every hold is released (outlier "
                                                   "dates) or its column dropped with a recorded reason"},
                          **rec}
    body = prices.to_csv(date_format="%Y-%m-%d").encode()
    side.update(vintage_id=vintage_id, vintage_hash=info["hash"],
                raw_files={n: _sha((v / n).read_bytes()) for n in (RAW_BIS_NAME, RAW_ECB_NAME, THERATES_RAW_NAME,
                                                                    THERATES_RESPONSES_NAME) if (v / n).is_file()},
                sha256=_sha(body), files={PRICES_NAME: _sha(body)})
    files = {PRICES_NAME: body, SIDECAR_NAME: json.dumps(side, indent=1, sort_keys=True).encode(),
             DISAGREEMENTS_NAME: dis.to_csv(index=False).encode()}
    if review is not None:
        files[FX_REVIEW_NAME] = review.to_csv(index=False).encode()
    return files, prices, side, dis


def _held_message(vintage_id: str, review: pd.DataFrame) -> str:
    h = review[review["status"] == "hold"]
    lines = "; ".join(f"{r.key} {r.country}: {r.reason}" for r in h.head(8).itertuples(index=False))
    return (f"FX history build of {vintage_id} held, not staged: {len(h)} open hold(s): {lines}"
            + (" ..." if len(h) > 8 else "") + ". Review data/market_history/reviews/" + vintage_id + "/" + FX_REVIEW_NAME
            + "; release an outlier date with `python -m econquest.ingestion.market_history release --column C --date D "
            "--author NAME (--approver OTHER | --self-approved)`, or drop a column with `... drop --column C --reason "
            "TEXT --author NAME`, then `... stage --vintage " + vintage_id + "`")


def _write_review(data_dir, vintage_id: str, review: pd.DataFrame) -> Path:
    """data/market_history/reviews/<vintage_id>/fx_review.csv and holds.json (mutable review state, rewritten on every
    build attempt; reviews/ is outside load_prices and replay, and withheld from the data room)."""
    out = _mh(data_dir) / REVIEWS_DIR / check_vintage_id(vintage_id)
    _atomic_bytes(out / FX_REVIEW_NAME, review.to_csv(index=False).encode())
    summary = {"vintage_id": vintage_id, "checks": CHECKS_VERSION, "rows": int(len(review)),
               "by_status": {k: int(v) for k, v in review["status"].value_counts().items()},
               "open": [f"{r.key} {r.country} ({r.check})" for r in review.itertuples(index=False) if r.status == "hold"]}
    _atomic_bytes(out / HOLDS_NAME, json.dumps(summary, indent=1, sort_keys=True).encode())
    return out


def _build_diff(out: Path, files: dict) -> list[str]:
    return [n for n, b in files.items() if not (out / n).is_file() or (out / n).read_bytes() != b]


def build_from_vintage(data_dir, vintage_id: str, tol: float = FX_HISTORY_TOL) -> dict:
    """Build prices.csv, prices.provenance.json and disagreements.csv from a verified vintage's raw files into
    data/market_history/builds/<vintage_id>/ (files 0444). Idempotent: an existing build must be byte-identical."""
    out = _mh(data_dir) / "builds" / check_vintage_id(vintage_id)     # before any path is read (SEC-A-007 L3)
    recorded = None
    if out.exists() and (out / SIDECAR_NAME).is_file():      # EQ-A-0077: reproduce it with the decisions it recorded
        with contextlib.suppress(OSError, ValueError, AttributeError):
            recorded = _decisions_from_record(json.loads((out / SIDECAR_NAME).read_text()).get("review"))
    review: list = []
    try:
        files, prices, side, dis = _build_files(data_dir, vintage_id, tol, decisions=recorded, review_out=review)
    except FxHistoryHeld as e:
        e.review = _write_review(data_dir, vintage_id, e.holds)
        raise
    if review:
        _write_review(data_dir, vintage_id, review[0])
    if out.exists():
        diff = _build_diff(out, files)
        if diff:
            raise FxHistoryError(f"build {out} exists and differs in {diff}; builds are not overwritten")
    else:
        tmp = Path(tempfile.mkdtemp(dir=_mkdir(out.parent), prefix=".build-"))
        for n, b in files.items():
            _write_ro(tmp / n, b)
        os.replace(tmp, out)
    return {"prices": str(out / PRICES_NAME), "provenance": str(out / SIDECAR_NAME),
            "disagreements": str(out / DISAGREEMENTS_NAME), "vintage": vintage_id, "build": str(out),
            "columns": len(PRICE_FX_COLUMNS), "dates": int(len(prices)), "served": len(PRICE_FX_COLUMNS) - len(side["unserved"]),
            "unserved": side["unserved"], "disagreement_rows": int(len(dis)), "sha256": side["sha256"],
            **({"review": str(out / FX_REVIEW_NAME), "released": len(side["review"]["released"]),
                "dropped": sorted(side["review"]["dropped"])} if "review" in side else {})}


def _mkdir(p: Path) -> Path:
    p.mkdir(parents=True, exist_ok=True)
    return p


def build_official_fx_history(data_dir, start=None, end=None, *, bis=None, ecb=None, apply: bool = False,
                              tol: float = FX_HISTORY_TOL, now: dt.datetime | None = None,
                              log: Callable[[str], None] = print, theratesapi=None,
                              rates_per_second: float = THERATES_REQUESTS_PER_SECOND) -> dict:
    """Pull the daily BIS WS_XRU history (and the ECB EXR reference rates) for PRICE_FX_COLUMNS from `start` to `end`
    (dates; defaults: the last FX_HISTORY_YEARS years to today UTC), save the raw pulls as a vintage, build prices.csv
    from it (build_from_vintage) and, with apply=True, install it (apply_official_fx_history). Returns a dict with
    `prices`, `provenance`, `vintage`, counts and, when applied, `applied` and `archived`.

    Fails loudly: FeedUnreachable (proxy, DNS) and a BIS pull that returns nothing raise before anything is written.
    An ECB failure is recorded in request.json and the sidecar `failures`; the ECB-only columns then stay empty.

    EQ-A-0073: columns BIS and the ECB leave empty fall to the EUR peg (XOF) and then to theratesapi.com
    (`theratesapi`: a TheRatesApiFeed, None = the default one, False = off), see the module docstring. A
    theratesapi.com failure, including an unreachable host part-way, is recorded in `failures` and its columns stay
    empty; the cache keeps every answer already received, so the next build resumes where this one stopped."""
    from .feeds import BisFeed, EcbExrFeed, FeedError, FeedUnreachable, _utc
    start, end = _default_range(start, end)
    now = _utc(now)
    retrieved = now.strftime("%Y-%m-%dT%H:%M:%SZ")
    days = (end - start).days
    bis = bis or BisFeed()
    ecb = ecb or EcbExrFeed(batch=6)                 # smaller batches: 3 years of csvdata per currency is ~0.5 MB
    areas = bis_areas()
    log(f"official FX history {start} .. {end}: BIS WS_XRU for {len(areas)} currencies, ECB EXR cross-check")
    raw_bis = bis.fetch_xru(areas, days=days, today=end)          # FeedError / FeedUnreachable propagate: nothing written
    failures = list(raw_bis.attrs.get("failures", []))
    raw_ecb = None
    try:
        raw_ecb = ecb.fetch(list(areas), days=days, today=end)
        failures += list(raw_ecb.attrs.get("failures", []))
    except FeedUnreachable:
        raise
    except FeedError as e:
        failures.append(f"ECB EXR: {str(e)[:200]} (no cross-check; ECB-only currencies stay empty)")
    files = {RAW_BIS_NAME: raw_bis.to_csv(index=False).encode()}
    if raw_ecb is not None:
        files[RAW_ECB_NAME] = raw_ecb.to_csv(index=False).encode()
    fallbacks, rates_req = _fallbacks(data_dir, raw_bis, raw_ecb, start, end, theratesapi, rates_per_second, failures,
                                      files, log)
    files[REQUEST_NAME] = json.dumps({
        "ticket": TICKET, "start": start.isoformat(), "end": end.isoformat(), "retrieved_utc": retrieved,
        "bis": {"flow": "WS_XRU", "areas": areas, "base": getattr(bis, "base", ""),
                "missing": list(raw_bis.attrs.get("missing", []))},
        "ecb": {"flow": "EXR", "currencies": list(areas), "base": getattr(ecb, "base", ""),
                "missing": list(raw_ecb.attrs.get("missing", [])) if raw_ecb is not None else None},
        "fallbacks": fallbacks, "theratesapi": rates_req, "checks": CHECKS_VERSION,     # EQ-A-0077
        "failures": failures}, indent=1, sort_keys=True).encode()
    v = save_fx_history_vintage(data_dir, files, now=now)
    log(f"  raw pulls saved: {v}")
    res = build_from_vintage(data_dir, v.name, tol=tol)
    log(f"  built {res['prices']}: {res['dates']} dates, {res['served']}/{res['columns']} columns served"
        + (f"; empty: {', '.join(res['unserved'])}" if res["unserved"] else ""))
    if res["disagreement_rows"]:
        log(f"  WARNING: {res['disagreement_rows']} date(s) where BIS and ECB (or a peg) disagree by more than "
            f"{tol:.0%}: {res['disagreements']} (reported, not resolved)")
    for f in failures:
        log(f"  failure: {f}")
    if apply:
        res.update(apply_official_fx_history(data_dir, v.name, now=now, log=log))
    else:
        log("  staged only (prices.csv unchanged). Install with:  python -m econquest.ingestion.market_history apply "
            f"--vintage {v.name}")
    return res


def _fallbacks(data_dir, raw_bis, raw_ecb, start: dt.date, end: dt.date, theratesapi, rates_per_second: float,
               failures: list, files: dict, log) -> tuple[dict, dict | None]:
    """EQ-A-0073: decide which empty columns fall to the EUR peg and which to theratesapi.com, pull the latter
    (adding its raw files to `files`), and return (fallbacks for request.json, theratesapi request record)."""
    from .feeds import HARD_PEGS, FeedError, FeedUnreachable, ecb_per_usd, fx_usd_series
    from .official.theratesapi import THERATES_BASE, THERATES_LICENCE, TheRatesApiFeed, responses_frame
    conv = ecb_per_usd(raw_ecb) if raw_ecb is not None and len(raw_ecb) else None
    has_eur = bool(len(_series_in_range(fx_usd_series(conv, "EUR"), start, end)))
    empty = [c[3:] for c in PRICE_FX_COLUMNS
             if not len(_series_in_range(fx_usd_series(raw_bis, c[3:]), start, end))
             and not len(_series_in_range(fx_usd_series(conv, c[3:]), start, end))]
    peg = [c for c in empty if c in HARD_PEGS and HARD_PEGS[c].anchor == "EUR" and has_eur]
    want = [c for c in empty if c not in peg]
    fallbacks = {"peg": peg, "theratesapi": [] if theratesapi is False else want}
    if theratesapi is False or not want:
        return fallbacks, None
    feed = theratesapi or TheRatesApiFeed()
    dates = [start + dt.timedelta(days=i) for i in range((end - start).days + 1)
             if (start + dt.timedelta(days=i)).weekday() < 5]
    cache = _mh(data_dir).joinpath(*THERATES_CACHE)
    # EQ-A-0077: the request for the empty columns also asks for the other mirror currencies BIS / ECB now serve,
    # so the daily cross-check has the mirror's rate (one request per date either way; never used as data)
    extra = [c for c in THERATES_CROSS_CHECK if c not in want and c in {x[3:] for x in PRICE_FX_COLUMNS}]
    ask = want + extra
    log(f"  theratesapi.com for {', '.join(want)} (BIS and ECB have no series)"
        + (f", and {', '.join(extra)} for the cross-check only" if extra else "")
        + f": {len(dates)} business dates, at most {rates_per_second:g} requests a second, cache {cache}")
    rec = {"base": getattr(feed, "base", THERATES_BASE), "currencies": want, "dates": len(dates),
           "licence": THERATES_LICENCE, "requests": 0, "cached": 0, "missing": want}
    if extra:
        rec["cross_check_only"] = extra
    try:
        raw = feed.fetch_dates(dates, ask, cache_dir=cache, min_interval=1.0 / rates_per_second if rates_per_second > 0 else 0.0,
                               log=log)
    except Exception as e:  # noqa: BLE001 - SEC-A-009 M1: the lowest-priority source never stops the BIS/ECB build
        failures.append(f"theratesapi.com: {'' if isinstance(e, (FeedUnreachable, FeedError)) else type(e).__name__ + ': '}"
                        f"{str(e)[:200]} (columns {', '.join(want)} stay empty; answers already "
                        f"received are cached in {cache}: rerun to resume)")
        fallbacks["theratesapi"] = []
        return fallbacks, rec
    failures += list(raw.attrs.get("failures", []))[:50]
    rec.update(requests=int(raw.attrs.get("requests", 0)), cached=int(raw.attrs.get("cached", 0)),
               missing=[c for c in raw.attrs.get("missing", []) if c in want])
    files[THERATES_RAW_NAME] = raw.to_csv(index=False).encode()
    files[THERATES_RESPONSES_NAME] = responses_frame(raw).to_csv(index=False).encode()
    log(f"  theratesapi.com: {rec['requests']} requests, {rec['cached']} answers from the cache, "
        f"{raw['period'].nunique()} business days" + (f"; no rate for {', '.join(rec['missing'])}" if rec["missing"] else ""))
    return fallbacks, rec


# ------------------------------------------------------------------------------------------------ archive and apply
def _header(path: Path) -> list[str]:
    try:
        with open(path, newline="", encoding="utf-8") as f:
            return next(csv.reader(f), []) or []
    except (OSError, UnicodeDecodeError):
        return []


def _official_sidecar(mh: Path) -> dict | None:
    p = mh / SIDECAR_NAME
    try:
        meta = json.loads(p.read_text())
    except (OSError, ValueError):
        return None
    return meta if isinstance(meta, dict) and meta.get("schema") == SCHEMA else None


def _build_shas(mh: Path) -> set[str]:
    """sha256 of every official build's prices.csv under builds/ whose own sidecar matches it (provenance hash)."""
    out = set()
    for side_p in sorted((mh / "builds").glob(f"*/{SIDECAR_NAME}")):
        try:
            meta = json.loads(side_p.read_text())
            h = _sha((side_p.parent / PRICES_NAME).read_bytes())
        except (OSError, ValueError):
            continue
        if isinstance(meta, dict) and meta.get("schema") == SCHEMA and meta.get("sha256") == h:
            out.add(h)
    return out


def _is_official_prices(mh: Path) -> bool:
    """data/market_history/prices.csv carries an official build and no ETF column: its sha256 matches the live sidecar
    or, after an apply interrupted between its two replaces (EQ-A-0060), the provenance hash of a build under builds/."""
    f = mh / PRICES_NAME
    if not f.is_file() or set(_header(f)) & set(LEGACY_ETF_COLUMNS):
        return False
    h = _sha(f.read_bytes())
    meta = _official_sidecar(mh)
    return (meta is not None and meta.get("sha256") == h) or h in _build_shas(mh)


def restricted_market_files(data_dir) -> pd.DataFrame:
    """Files the engine can read (top-level data/market_history/*.csv, garch.load_prices) that are not an official
    build: the GOOGLEFINANCE prices.csv (ETF columns, or no matching official sidecar) and extra series files such as
    inda.csv. Columns path, reason. Empty once the official build is applied."""
    mh = _mh(data_dir)
    rows = []
    if mh.is_dir():
        for p in sorted(mh.glob("*.csv")):
            if p.name == PRICES_NAME:
                if _is_official_prices(mh):
                    continue
                etf = [c for c in _header(p) if c in LEGACY_ETF_COLUMNS]
                why = (f"GOOGLEFINANCE prices (ETF columns {', '.join(etf)})" if etf
                       else "no official build sidecar matching this file (prices.provenance.json)")
            else:
                why = "extra series merged by garch.load_prices, not from the official build (GOOGLEFINANCE era)"
            rows.append({"path": p.relative_to(Path(data_dir)).as_posix(), "reason": why})
    return pd.DataFrame(rows, columns=["path", "reason"])


def archive_legacy_file(src: Path, data_dir, *, move: bool = False, now: dt.datetime | None = None,
                        reason: str = "pre-EQ-A-0054 market history (GOOGLEFINANCE)") -> Path:
    """Copy (or move) a GOOGLEFINANCE-era file to data/market_history/archive/<stem>-googlefinance-<date>.csv, 0444,
    with a .licence.json tag (restricted). An archive with the same name and content is reused; another content gets
    a time suffix; if that name too holds other content, FxHistoryError before anything is written or deleted.
    Never overwrites."""
    from .feeds import _utc
    now = _utc(now)
    src = Path(src)
    body = src.read_bytes()
    arch = _mkdir(_mh(data_dir) / "archive")
    stem = f"{src.stem}-googlefinance-{now.strftime('%Y-%m-%d')}"
    dest = arch / f"{stem}.csv"
    if dest.exists() and dest.read_bytes() != body:
        stem = f"{stem}T{now.strftime('%H%M%S')}Z"
        dest = arch / f"{stem}.csv"
        if dest.exists() and dest.read_bytes() != body:          # EQ-A-0060: never delete a source not archived
            raise FxHistoryError(f"{src}: archive names {dest.name} and the date-only name already hold other content; "
                                 "nothing archived, source left in place")
    if not dest.exists():
        _write_ro(dest, body)
        _write_ro(arch / f"{stem}.licence.json", json.dumps({
            "file": dest.name, "sha256": _sha(body), "size": len(body), "archived_from": f"market_history/{src.name}",
            "archived_utc": now.strftime("%Y-%m-%dT%H:%M:%SZ"), "ticket": TICKET, "reason": reason,
            "source": "GOOGLEFINANCE formulas of the workbook Market History tab, exported through the Sheets API "
                      "(econquest prices --sheet-json)",
            "licence": GOOGLEFINANCE_LICENCE, "restricted": True,
            "use": "audit only; not read by the engine (archive/ is outside load_prices and replay) and withheld from "
                   "the data room"}, indent=1, sort_keys=True).encode())
    if move:
        src.unlink()
    return dest


def apply_official_fx_history(data_dir, vintage_id: str | None = None, *, now: dt.datetime | None = None,
                              log: Callable[[str], None] = print) -> dict:
    """Install a verified official build as data/market_history/prices.csv (+ prices.provenance.json). Before that,
    every engine-readable GOOGLEFINANCE-era file (restricted_market_files) is archived read-only: prices.csv is copied
    there and then replaced, extra top-level series files (inda.csv) are moved there. Atomic replace (sidecar, then
    prices.csv); the vintage hash, the build's sha256 and an existing build against a rebuild from the vintage are
    checked first (FxHistoryError, nothing changed)."""
    from .feeds import _utc
    now = _utc(now)
    ids = list_fx_history_vintages(data_dir)
    vid = vintage_id or (ids[-1] if ids else None)
    if not vid:
        raise FxHistoryError("no FX history vintage to apply: run  python -m econquest.ingestion.market_history build")
    check_vintage_id(vid)
    b = _mh(data_dir) / "builds" / vid
    existed = b.exists()
    res = build_from_vintage(data_dir, vid) if not existed else {"prices": str(b / PRICES_NAME)}
    info = verify_fx_history_vintage(data_dir, vid)
    body = (b / PRICES_NAME).read_bytes()
    side = json.loads((b / SIDECAR_NAME).read_text())
    if side.get("sha256") != _sha(body):
        raise FxHistoryError(f"build {b}: prices.csv sha256 does not match its sidecar")
    if side.get("vintage_id") != vid or side.get("vintage_hash") != info["hash"]:     # SEC-A-007 L3
        raise FxHistoryError(f"build {b}: sidecar vintage {side.get('vintage_id')!r} / hash "
                             f"{str(side.get('vintage_hash'))[:16]} does not match the verified vintage {vid}")
    bad = [c for c in _header(b / PRICES_NAME) if c in LEGACY_ETF_COLUMNS]
    if bad:
        raise FxHistoryError(f"build {b} holds ETF columns {bad}")
    missing = recorded_decisions_missing(data_dir, side)      # EQ-A-0090: the releases / drops are in the ledger
    if missing:
        raise FxHistoryError(f"build {b}: {len(missing)} decision(s) recorded in its sidecar are not in "
                             f"{Path(data_dir) / 'live' / 'review_ledger.csv'} (append-only): "
                             + "; ".join(missing[:5]) + "; refused, nothing changed")
    if existed:                     # EQ-A-0060: an existing build must equal a deterministic rebuild from the vintage
        tol = (side.get("disagreements") or {}).get("tolerance", FX_HISTORY_TOL)
        diff = _build_diff(b, _build_files(data_dir, vid, float(tol),
                                           decisions=_decisions_from_record(side.get("review")))[0])
        if diff:
            raise FxHistoryError(f"build {b}: {diff} differ (sha256) from a deterministic rebuild of vintage {vid}; "
                                 "refused, nothing changed")
    mh = _mh(data_dir)
    archived = []
    for r in restricted_market_files(data_dir).itertuples():
        p = Path(data_dir) / r.path
        archived.append(str(archive_legacy_file(p, data_dir, move=p.name != PRICES_NAME, now=now, reason=r.reason)))
    side["applied_utc"] = now.strftime("%Y-%m-%dT%H:%M:%SZ")
    # sidecar first (EQ-A-0060): a crash between the two replaces leaves the old prices.csv with the new sidecar, never
    # an official prices.csv without one; _is_official_prices also knows builds' hashes, so it is never archived.
    _atomic_bytes(mh / SIDECAR_NAME, json.dumps(side, indent=1, sort_keys=True).encode())
    _atomic_bytes(mh / PRICES_NAME, body)
    log(f"  applied {vid}: {mh / PRICES_NAME}" + (f"; archived (restricted): {', '.join(archived)}" if archived else ""))
    return {**res, "prices": str(mh / PRICES_NAME), "provenance": str(mh / SIDECAR_NAME), "vintage": vid,
            "applied": True, "archived": archived}


# ------------------------------------------------------------------------------------------------ EQ-A-0077 decisions
def _held_review(data_dir, vintage_id: str | None) -> tuple[str, pd.DataFrame]:
    vid = vintage_id or (list_fx_history_vintages(data_dir) or [None])[-1]
    if not vid:
        raise FxHistoryError("no FX history vintage")
    p = _mh(data_dir) / REVIEWS_DIR / check_vintage_id(vid) / FX_REVIEW_NAME
    if not p.is_file():
        raise FxHistoryError(f"no review for {vid} ({p}): run `market_history stage --vintage {vid}` first")
    return vid, pd.read_csv(p, dtype={"country": str, "key": str})


def release_outlier(data_dir, column: str, date: str, author: str, *, approver: str | None = None,
                    self_approved: bool = False, note: str = "", vintage_id: str | None = None) -> dict:
    """Release one flagged outlier date (EQ-A-0077): a ledger 'apply' on (HOLD_TABLE, column, date) with the flagged
    value, under the four-eyes rule of record_decision (gate_status 'hold'). The value in prices.csv is unchanged."""
    from .ledger import record_decision
    vid, rv = _held_review(data_dir, vintage_id)
    hit = rv[(rv["key"] == column) & (rv["country"] == str(date)) & (rv["check"] == "outlier")]
    if hit.empty:
        raise FxHistoryError(f"{column} {date} is not a flagged outlier of {vid}")
    return record_decision(Path(data_dir), HOLD_TABLE, column, str(date), "apply", author, approver,
                           note=note or "EQ-A-0077 outlier released: value checked and kept", vintage_id=vid,
                           live=float(hit["live"].iloc[0]), gate_status="hold", self_approved=self_approved)


def drop_column(data_dir, column: str, reason: str, author: str, *, vintage_id: str | None = None) -> dict:
    """Drop a held column from the build (EQ-A-0077): a ledger 'reject' on (HOLD_TABLE, column, COLUMN_CELL) whose
    note is the reason. The next stage empties the column, lists it unserved and records the reason in the sidecar.
    The ledger row stays, but it acts only while the column is held: a later vintage whose column passes every check
    keeps the column; if it is held again, the standing drop applies again (EQ-A-0090)."""
    from .ledger import record_decision
    if not str(reason).strip():
        raise FxHistoryError("drop needs a reason")
    vid, rv = _held_review(data_dir, vintage_id)
    if column not in set(rv["key"]):
        raise FxHistoryError(f"{column} has no hold in {vid}: only a held column is dropped")
    return record_decision(Path(data_dir), HOLD_TABLE, column, COLUMN_CELL, "reject", author, note=str(reason).strip(),
                           vintage_id=vid, gate_status="hold")


def review_build(folder: Path, data_dir=None) -> pd.DataFrame:
    """Read only: the EQ-A-0077 holds of a build folder (prices.csv + prices.provenance.json), resolved against the
    ledger of `data_dir` (default: the folder's data dir). Works on a build made before EQ-A-0077 too, from its
    files alone (the raw vintage may be on the Mac), so the installed history can be checked."""
    folder = Path(folder)
    side = json.loads((folder / SIDECAR_NAME).read_text())
    prices = pd.read_csv(folder / PRICES_NAME, index_col="date", parse_dates=True)
    holds = fx_history_holds(prices, side, side.get("end") or prices.index.max(), side.get("vintage_id", ""))
    d = Path(data_dir) if data_dir else folder.parents[1] if folder.parent.name == "builds" else folder.parent
    review, _rec = resolve_fx_holds(holds, _hold_decisions(d), side.get("vintage_id", ""))
    return review


# ------------------------------------------------------------------------------------------------ data room rule
def _release_inputs(parts: list[str]) -> bool:
    return any(parts[i] == "releases" and parts[i + 1] == "inputs" for i in range(len(parts) - 1))


def market_restricted_reason(rel: str, header: list[str] | None = None) -> str | None:
    """Why a data-dir file is GOOGLEFINANCE-restricted (EQ-A-0054), or None: a name containing 'googlefinance';
    anything in a market_history sub-folder other than ROOM_SAFE_DIRS (archive/, research/, repairs/ ..., also inside
    a replay snapshot; SEC-A-007 M1); a CSV under a market_history folder whose header holds an ETF ticker, alone or
    as a token of a column name such as bad_INDA (the GOOGLEFINANCE prices.csv, inda.csv, repair tables, and their
    frozen copies). data/market_history/spreads/ (EQ-A-0063) is withheld too, with its own reason (EQ-A-0060)."""
    parts = rel.replace("\\", "/").split("/")
    name = parts[-1].lower()
    if "googlefinance" in name:
        return GOOGLEFINANCE_FILE_REASON
    if "theratesapi" in name or "theratesapi" in parts:       # EQ-A-0073: raw mirror pulls and the answer cache
        return THERATES_ROOM_REASON
    if "market_history" in parts:
        sub = parts[parts.index("market_history") + 1:]
        if len(sub) > 1 and sub[0] == "spreads":
            return SPREADS_RESTRICTED_REASON
        if len(sub) > 1 and sub[0] == REVIEWS_DIR:              # EQ-A-0077: mutable review state, mirror values
            return REVIEWS_ROOM_REASON
        if len(sub) > 1 and sub[0] not in ROOM_SAFE_DIRS:
            return GOOGLEFINANCE_FILE_REASON
    if "market_history" in parts or _release_inputs(parts):   # EQ-A-0082: frozen release inputs (releases/inputs/<v>/)
        etf = set(LEGACY_ETF_COLUMNS)
        if name.endswith(".csv") and header and any(
                h.strip() in etf or etf & set(re.split(r"[^A-Za-z0-9]+", h.strip())) for h in header):
            return GOOGLEFINANCE_FILE_REASON
    return None


# ------------------------------------------------------------------------------------------------ command line
def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.market_history",
                                 description="Official FX history for data/market_history/prices.csv (EQ-A-0054)")
    ap.add_argument("--data", default="data")
    sub = ap.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("build", help="pull BIS/ECB history, save the raw vintage, build (and with --apply install)")
    b.add_argument("--start"); b.add_argument("--end")
    b.add_argument("--apply", action="store_true", help="install the build as prices.csv (after Team B accepted)")
    b.add_argument("--tol", type=float, default=FX_HISTORY_TOL)
    b.add_argument("--no-theratesapi", action="store_true",
                   help="do not fill BIS/ECB-empty columns from theratesapi.com (EQ-A-0073, EXC-005)")
    a = sub.add_parser("apply", help="install a built vintage as prices.csv, archiving the GOOGLEFINANCE files")
    a.add_argument("--vintage")
    sub.add_parser("restricted", help="list engine-readable GOOGLEFINANCE-era files; exit 1 when any")
    # EQ-A-0077: holds
    st = sub.add_parser("stage", help="build a saved vintage into builds/<id> (after releasing or dropping holds)")
    st.add_argument("--vintage", required=True)
    rv = sub.add_parser("review", help="show the EQ-A-0077 holds of a build folder or of the installed prices.csv "
                                       "(read only; exit 1 while any is open)")
    rv.add_argument("--build", help="a builds/<id> folder (default: data/market_history)")
    rl = sub.add_parser("release", help="release one flagged outlier date (ledger 'apply', four-eyes or flagged "
                                        "self-approval, bound to the flagged value)")
    dr = sub.add_parser("drop", help="drop a held column from the build with a recorded reason (ledger 'reject')")
    for q in (rl, dr):
        q.add_argument("--column", required=True)
        q.add_argument("--author", required=True)
        q.add_argument("--vintage", help="the held vintage (default: the latest)")
    rl.add_argument("--date", required=True)
    rl.add_argument("--approver"); rl.add_argument("--self-approved", action="store_true"); rl.add_argument("--note", default="")
    dr.add_argument("--reason", required=True)
    args = ap.parse_args(argv)
    try:
        return _run(args)
    except FxHistoryHeld as e:
        print(f"HELD: {e}", file=sys.stderr)
        return 3
    except FxHistoryError as e:            # refused (bad vintage id, not held, no review, ...): a message, not a traceback
        print(f"refused: {e}", file=sys.stderr)
        return 2


def _run(args) -> int:
    if args.cmd == "build":
        res = build_official_fx_history(args.data, args.start, args.end, apply=args.apply, tol=args.tol,
                                        theratesapi=False if args.no_theratesapi else None)
        print(json.dumps({k: v for k, v in res.items() if not isinstance(v, (dict,))}, indent=1, default=str))
        return 0
    if args.cmd == "stage":
        print(json.dumps(build_from_vintage(args.data, check_vintage_id(args.vintage)), indent=1, default=str))
        return 0
    if args.cmd == "review":
        rep = review_build(Path(args.build) if args.build else _mh(args.data), args.data)
        print(rep.to_string(index=False) if len(rep) else "no EQ-A-0077 holds")
        return 1 if (rep["status"] == "hold").any() else 0
    if args.cmd in ("release", "drop"):
        try:
            row = (release_outlier(args.data, args.column, args.date, args.author, approver=args.approver,
                                   self_approved=args.self_approved, note=args.note, vintage_id=args.vintage)
                   if args.cmd == "release" else
                   drop_column(args.data, args.column, args.reason, args.author, vintage_id=args.vintage))
        except ValueError as e:            # ledger.record_decision: four-eyes or a missing author; nothing written
            print(f"refused: {e}", file=sys.stderr)
            return 2
        print(json.dumps(row, indent=1, default=str))
        return 0
    if args.cmd == "apply":
        res = apply_official_fx_history(args.data, args.vintage)
        print(json.dumps(res, indent=1, default=str))
        return 0
    bad = restricted_market_files(args.data)
    print(f"{len(bad)} engine-readable GOOGLEFINANCE-era file(s) in {_mh(args.data)}")
    for r in bad.itertuples():
        print(f"  {r.path}: {r.reason}")
    return 1 if len(bad) else 0


if __name__ == "__main__":
    sys.exit(main())
