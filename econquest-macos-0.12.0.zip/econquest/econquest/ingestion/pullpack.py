"""Mac pull pack (EQ-A-0048): one resumable sequence for every pull that only Sam's Mac can run.

    python -m econquest.ingestion.pullpack plan              # what would run, disk needed, what is missing (no network)
    python -m econquest.ingestion.pullpack run               # run every step not yet done; rerun to resume
    python -m econquest.ingestion.pullpack run --apply-fx    # also apply the verified official FX vintage
    python -m econquest.ingestion.pullpack run --redo panel_history
    python -m econquest.ingestion.pullpack status            # one line per step from the state file
    python -m econquest.ingestion.pullpack report            # data/live/pullpack/report.md + report.json

Steps, in order (runbook docs/runbooks/A-mac-pull-pack.md):

0  dsa_regate     after the full `econquest fetch` (EQ-A-0096): `econquest dsa` on that fetch, then
                  official.dsa_regate gates its 1.2 / 1.1 / 2.1 rows offline for the latest vintage only and saves a
                  derived vintage (nothing applied; the F8 dsa_reseed guard holds Pakistan / Argentina 1.2 for Sam).
                  First because step 1 saves a newer fx-only vintage; skipped with the reason when there is no
                  vintage or the latest one is not a full pull
1  fx             official FX (BIS WS_XRU + ECB EXR): fetch without apply, checklist and BIS-vs-ECB cross-check;
                  applied (feeds.apply_vintage, never forced) only with --apply-fx after the verify passed; then
                  audit.restricted_source_cells must be 0
1b fx_history     data/market_history/prices.csv from official FX (EQ-A-0054 `build_official_fx_history`; skipped
                  with "pending EQ-A-0054" until it exists), verified against its provenance sidecar
2  panel_history  panel_history.fetch_history, every WEO release and World Bank series; resumes its own run id
2w wb_panel       panel_history.fetch_history, World Bank only, panel_history.WB_PANEL_CODES for 2000-2025, every
                  economy, into data/panel/wb_interim/ (EQ-A-0094, Team B's interim refit EQ-B-0098); own run id
3  crag           default_panel.import_crag of the BoC-BoE workbook (skipped with a download message when absent),
                  verified with compare_panels and panel_coverage
4  universe       universe.expand_countries -> stage_data_dir -> no-apply fetch into the staged folder ->
                  missing_cell_report (data/countries.csv and data/indicators.csv are never touched)
5a ucdp           events.ucdp.pull_and_save (skipped with the reason when the token variable is not set)
5b gdelt          events.gdelt.GdeltAdapter over a bounded date range, after a disk check
6  nowcast        nowcast_feed.fetch (EQ-A-0057): IMF / OECD / BIS monthly series archived as a vintage, verified map
                  rows merged into data/live/nowcast_inputs.csv (skipped when the feed refuses: offline or no rows)
7  research       research file drops (EQ-A-0089), offline: every built research.REGISTRY adapter reads its drop-in
                  folder data/panel/research/KEY/, Team B's rules (econquest.rules) make the cells, the gate holds them
                  all (3.6/4.4/6.10/7.12 parked for Sam's sign-off) and the licence register decides client output;
                  report in live/pullpack/research/ only (research.drops). Skipped with the reason when no file is
                  dropped; a source without a file is listed as not dropped, never a failure
8  macro          macro inputs (EQ-A-0134, official.macro): BIS WS_EER real/nominal broad/narrow through feeds.BisFeed
                  (BIS optional: an unreachable BIS is reported, the step still runs), the World Bank Pink Sheet file
                  CMO-Historical-Data-Monthly.xlsx from ~/Downloads (or --cmo-xlsx; never fetched), and WDI TX.VAL export
                  shares from the latest vintage that has them, gated (official.macro.macro_gate) into one vintage
                  under live/macro/vintages/. Research inputs only: no desk cell, nothing applied. Skipped with the
                  download message when neither BIS nor the file gives a value

Each step has a preflight (step-specific conditions, free disk against its estimate with shutil.disk_usage, one probe
per host with feeds.probe_host so an unreachable host skips the step with a reason instead of hanging), a run, a
verify and a record in data/live/pullpack/state.json (written atomically after every change). A rerun skips steps
that are done and verified, unless named with --redo. Held cells stay held: nothing here forces an apply.

Exit codes of run, status and report: 0 every selected step done; 2 some step skipped, held or not yet run;
1 a step failed (or a usage error).
"""
from __future__ import annotations

import argparse
import contextlib
import datetime as dt
import json
import os
import shutil
import sys
import tempfile
import time
import traceback
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Callable, Iterable

try:                                   # POSIX; elsewhere runs are not locked (as ledger.locked_append)
    import fcntl
except ImportError:  # pragma: no cover
    fcntl = None

STATE_VERSION = 1
REPORT_SCHEMA = "econquest.pullpack.report/1"
PACK_DIR = Path("live") / "pullpack"                      # under data_dir
STATE_FILE, REPORT_MD, REPORT_JSON, LOG_FILE = "state.json", "report.md", "report.json", "pullpack.log"
LOCK_FILE = "run.lock"                                    # SEC-A-007 L1: one `pullpack run` per data folder
STATUSES = ("pending", "running", "done", "held", "skipped", "failed")
EXIT_DONE, EXIT_FAILED, EXIT_INCOMPLETE = 0, 1, 2
EXIT_INTERRUPTED = 130                    # EQ-A-0138: Ctrl-C (the shell's 128 + SIGINT)
MB, GB = 1024 ** 2, 1024 ** 3
DISK_MARGIN = 1.10                                         # need estimate x 1.1 free before a step starts

CRAG_FILE = "BoC-BoE-Database-2026.xlsx"
CRAG_URL = "https://www.bankofcanada.ca/wp-content/uploads/2026/10/BoC-BoE-Database-2026.xlsx"
CRAG_VINTAGE = "2026-10"
UCDP_KEYCHAIN = 'security find-generic-password -s econquest-ucdp -w'
GDELT_BYTES_PER_DAY = int(15 * GB / 365)                   # upper end of the runbook's 5-15 GB a year (estimate)
GDELT_INDEX_BYTES = 250 * MB                               # masterfilelist.txt, ~100-200 MB (estimate)

# Step 2's panel_history sources (EQ-A-0079). Sam deferred the WEO history (EQ-A-0087, Backlog), so by default step 2
# runs only the World Bank series and reports WEO as deferred, not failed. `--panel-sources weo,worldbank` restores the
# full run. A deferred source never unblocks a ticket that needs it (EQ-A-0015 / EQ-A-0016 need the WEO history).
PANEL_SOURCES_ALL = ("weo", "worldbank")
PANEL_DEFERRED = {"weo": "EQ-A-0087"}
PANEL_SOURCES_DEFAULT = tuple(s for s in PANEL_SOURCES_ALL if s not in PANEL_DEFERRED)
PANEL_NEEDS_WEO = ("EQ-A-0015", "EQ-A-0016")

# The Team A tickets that are Blocked on the Mac pulls, and the steps each one waits for.
BLOCKED_TICKETS = {
    "EQ-A-0008": ("crag",),
    "EQ-A-0015": ("panel_history",),
    "EQ-A-0016": ("panel_history", "crag"),
    "EQ-A-0026": ("universe",),
}


class UsageError(ValueError):
    """Bad step name or option (exit 1)."""


class PackBusy(UsageError):
    """Another `pullpack run` holds data/live/pullpack/run.lock (exit 1, nothing run or written)."""


@dataclass
class PackOptions:
    """Options of one invocation. Paths default to Sam's Mac layout (runbooks)."""
    apply_fx: bool = False
    crag_xlsx: str | None = None          # default ~/Downloads/BoC-BoE-Database-2026.xlsx
    weo_vintages: list[str] | None = None  # panel_history releases (default: Oct 2007 to the latest)
    panel_sources: tuple = PANEL_SOURCES_DEFAULT   # step 2 sources (EQ-A-0079: WEO deferred under EQ-A-0087)
    wb_panel_codes: tuple | None = None   # step 2w series (EQ-A-0094); None = panel_history.WB_PANEL_CODES
    universe_dest: str | None = None      # staged data folder; default ~/econquest-universe-<UTC stamp>
    ucdp_start: str = "2019-01-01"
    ucdp_end: str | None = None           # default today (UTC)
    gdelt_start: str | None = None        # default gdelt_end minus (gdelt_days - 1)
    gdelt_end: str | None = None          # default yesterday (UTC): the last complete day of files
    gdelt_days: int = 7
    gdelt_max_days: int = 366             # a longer range is refused (a year is ~35,000 files, hours)
    gdelt_allow_http: bool = False
    fx_history_start: str | None = None   # EQ-A-0054 builder range; None = the builder's default
    fx_history_end: str | None = None
    cmo_xlsx: str | None = None           # EQ-A-0134: default ~/Downloads/CMO-Historical-Data-Monthly.xlsx
    cmo_retrieved: str | None = None      # when Sam downloaded it (UTC); default the file's modification time

    def crag_path(self) -> Path:
        return Path(self.crag_xlsx).expanduser() if self.crag_xlsx else Path.home() / "Downloads" / CRAG_FILE

    def gdelt_range(self, today: dt.date) -> tuple[dt.date, dt.date]:
        end = dt.date.fromisoformat(self.gdelt_end) if self.gdelt_end else today - dt.timedelta(days=1)
        start = (dt.date.fromisoformat(self.gdelt_start) if self.gdelt_start
                 else end - dt.timedelta(days=max(int(self.gdelt_days), 1) - 1))
        return start, end


@dataclass
class Context:
    """What a step's functions get. `rec` is the step's state record; steps write counts, artifacts, vintages, held
    and next into it (it is saved even when the step raises, so a resume finds the run id or staged folder)."""
    data_dir: Path
    opts: PackOptions
    rec: dict
    prev: dict
    redo: bool
    detail: Callable[[str], None]
    out: Callable[[str], None]
    now: Callable[[], dt.datetime]


@dataclass(frozen=True)
class Step:
    id: str
    number: str
    title: str
    expected_time: str
    hosts: tuple = ()                                      # groups: every group needs one answering host
    # EQ-A-0073: groups probed with the others but not required; an unreachable one is reported, the step still runs
    optional_hosts: tuple = ()
    estimate: Callable[[Context], int] = lambda ctx: 0     # bytes of free disk the step needs
    preflight: Callable[[Context], str | None] = lambda ctx: None    # skip reason, or None
    run: Callable[[Context], tuple | None] = lambda ctx: None        # raises on failure; (status, reason) to stop early
    verify: Callable[[Context], dict] = lambda ctx: {"passed": True, "checks": []}
    finish: Callable[[Context], tuple | None] | None = None          # after a passed verify: (status, reason) or None
    unblocks: tuple = ()
    disk_path: Callable[[Context], Path] | None = None


# ------------------------------------------------------------------------------------------------ small helpers

def _utcnow() -> dt.datetime:
    return dt.datetime.now(dt.timezone.utc)


def _stamp(t: dt.datetime) -> str:
    return t.astimezone(dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")


def pack_dir(data_dir: str | Path) -> Path:
    return Path(data_dir) / PACK_DIR


def data_folder_problem(data_dir: str | Path) -> str | None:
    """EQ-A-0138: None when data_dir is an econquest data folder (it has countries.csv); else one plain sentence saying
    what the folder is instead. The real-data-day gotcha is the unzipped release in ~/Downloads: it ships its seed data
    as release-data/ and has no data/ folder, so `--data data` run there must point Sam at his install, not at a
    missing file. Reads only."""
    d = Path(data_dir).expanduser()
    if (d / "countries.csv").is_file():
        return None
    rel = d.parent / "release-data" if d.name != "release-data" else d
    if rel.is_dir():
        return (f"{d} is not an econquest data folder: {rel.parent} is an unzipped econquest release (the copy in "
                "Downloads), which ships its seed data as release-data/ and has no data/ of yours. Run the command from "
                "your install instead (cd ~/econquest, or use the `econquest` command), or pass --data ~/econquest/data. "
                "Nothing was changed.")
    if not d.exists():
        return f"{d} does not exist: pass --data with your econquest data folder (~/econquest/data). Nothing was changed."
    return (f"{d} is not an econquest data folder (no countries.csv): run from the econquest folder or pass --data "
            "~/econquest/data. Nothing was changed.")


def _atomic_write(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd, tmp = tempfile.mkstemp(dir=path.parent, prefix=f".{path.name}.", suffix=".tmp")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(text)
        os.chmod(tmp, 0o644)
        os.replace(tmp, path)
    except BaseException:
        if os.path.exists(tmp):
            os.unlink(tmp)
        raise


def _human(n: float) -> str:
    n = float(n)
    for unit in ("B", "KB", "MB", "GB", "TB"):
        if abs(n) < 1024 or unit == "TB":
            return f"{n:.0f} {unit}" if unit in ("B", "KB") else f"{n:.1f} {unit}"
        n /= 1024
    return f"{n:.1f} TB"


def _elapsed(s: float) -> str:
    s = int(round(s))
    return f"{s // 3600}h{s % 3600 // 60:02d}m" if s >= 3600 else (f"{s // 60}m{s % 60:02d}s" if s >= 60 else f"{s}s")


def _dir_size(p: Path) -> int:
    total = 0
    for root, _dirs, files in os.walk(p):
        for f in files:
            try:
                total += os.lstat(os.path.join(root, f)).st_size
            except OSError:
                pass
    return total


def check_disk(path: str | Path, need: int, disk_usage: Callable = shutil.disk_usage) -> str | None:
    """None when the file system holding `path` (its nearest existing parent) has need x DISK_MARGIN free, else the
    refusal reason."""
    p = Path(path)
    while not p.exists() and p.parent != p:
        p = p.parent
    free = int(disk_usage(str(p)).free)
    want = int(need * DISK_MARGIN)
    if need and free < want:
        return f"not enough free disk on {p}: {_human(free)} free, the step needs about {_human(want)} (estimate {_human(need)} + 10%)"
    return None


def _check(name: str, ok: bool, detail: str = "", required: bool = True) -> dict:
    return {"name": name, "ok": bool(ok), "detail": detail, "required": required}


def _verdict(checks: list[dict]) -> dict:
    return {"passed": all(c["ok"] for c in checks if c["required"]), "checks": checks}


def _vintage_ok(fn: Callable[[], object], name: str) -> dict:
    try:
        r = fn()
        return _check(name, True, str(r.get("vintage_id", r)) if isinstance(r, dict) else "ok")
    except Exception as e:  # noqa: BLE001 - reported as a failed check
        return _check(name, False, f"{type(e).__name__}: {e}")


# ------------------------------------------------------------------------------------------------ step 1: fx

def _fx_run(ctx: Context):
    from .feeds import fetch_and_save
    from .loaders import load_universe
    p = ctx.prev
    pa = p.get("artifacts", {})
    if (not ctx.redo and p.get("status") == "held" and pa.get("apply_pending") and pa.get("vintage_id")
            and (p.get("verify") or {}).get("passed")):
        ctx.rec["artifacts"] = dict(pa, reused=True)        # verified earlier and held only for --apply-fx: no refetch
        ctx.detail(f"fx: reusing verified vintage {pa['vintage_id']} (no refetch)")
        return None
    u = load_universe(ctx.data_dir)
    rep, _diff, _review, v = fetch_and_save(u, ctx.data_dir, only=["fx"], log=ctx.detail)
    ctx.rec["artifacts"] = {"vintage_id": v.name, "feeds": {k: rep.feeds[k] for k in ("bis_xru", "ecb_exr", "theratesapi_fx")
                                                            if k in rep.feeds}}
    return None


def _read_vintage_raw(data_dir: Path, vid: str, name: str):
    import pandas as pd
    from .feeds import vintage_path
    f = vintage_path(data_dir, vid) / f"raw_{name}.csv"
    if not f.is_file():
        return None
    return pd.read_csv(f, dtype={"iso": str, "series": str, "period": str, "sdmx_key": str}, keep_default_na=False)


def _fx_verify(ctx: Context) -> dict:
    import numpy as np
    from .audit import restricted_source_cells
    from .feeds import fx_cross_checks, load_vintage, official_fx_plan, verify_vintage
    from .loaders import load_universe
    d, vid = ctx.data_dir, ctx.rec.get("artifacts", {}).get("vintage_id")
    checks = [_vintage_ok(lambda: verify_vintage(d, vid), "vintage hash matches vintages/index.csv")]
    if not checks[0]["ok"]:
        return _verdict(checks)
    _vid, rep, review = load_vintage(d, vid)
    for f in ("bis_xru", "ecb_exr"):
        st = str(rep.feeds.get(f, "not run"))
        checks.append(_check(f"feed {f} ok", st.startswith("ok"), st))
    raw = {}
    for f in ("bis_xru", "ecb_exr"):
        raw[f] = _read_vintage_raw(d, vid, f)
        ok = raw[f] is not None and "sdmx_key" in raw[f].columns and len(raw[f]) > 0
        checks.append(_check(f"raw_{f}.csv in the vintage with an sdmx_key column", ok,
                             f"{0 if raw[f] is None else len(raw[f])} rows"))
    u = load_universe(d)
    cross = fx_cross_checks({k: v for k, v in raw.items() if v is not None}, official_fx_plan(u.countries), u)
    n_ccy = cross["reason"].str.split(" ", n=1).str[0].nunique() if len(cross) else 0
    held_cross = cross[cross["status"] == "hold"]
    checks.append(_check("BIS-vs-ECB cross-check compared at least one currency", n_ccy > 0,
                         f"{n_ccy} currencies compared, {held_cross['reason'].nunique() if len(held_cross) else 0} "
                         f"more than 1% apart ({len(held_cross)} fx3m cells held)"))
    fx_rows = review[review["key"].astype(str) == "fx3m"]
    n_live = int(np.isfinite(rep.profile["fx3m"]).sum()) if "fx3m" in rep.profile.columns else 0
    failures = _csv_rows(d / "live" / "feed_failures.csv")
    restricted = restricted_source_cells(d)
    prov = rep.provenance
    n_rates = (int(((prov["key"].astype(str) == "fx3m") & prov["source"].astype(str).str.startswith("theratesapi.com")).sum())
               if len(prov) and {"key", "source"} <= set(prov.columns) else 0)
    ctx.rec["counts"] = {"fx3m_live": n_live, "fx3m_theratesapi": n_rates, "fx3m_ok": int((fx_rows["status"] == "ok").sum()),
                         "fx3m_held": int((fx_rows["status"] == "hold").sum()),
                         "fx3m_missing": int((fx_rows["status"] == "missing").sum()),
                         "cross_currencies_compared": int(n_ccy), "cross_cells_held": int(len(held_cross)),
                         "feed_failures": failures, "restricted_source_cells": int(len(restricted))}
    ctx.rec["vintages"] = {"live_vintage": vid}
    ctx.rec["held"] = [f"Country Profile fx3m {r.country}: {r.reason}" for r in fx_rows.itertuples(index=False)
                       if r.status == "hold"]
    ctx.rec["cross_check"] = sorted(set(cross["reason"])) if len(cross) else []
    ctx.rec["checklist"] = [
        f"[{'x' if all(c['ok'] for c in checks[1:3]) else ' '}] Feeds: bis_xru {rep.feeds.get('bis_xru', '-')}; ecb_exr {rep.feeds.get('ecb_exr', '-')}",
        f"[{'x' if all(c['ok'] for c in checks[3:5]) else ' '}] raw_bis_xru.csv and raw_ecb_exr.csv kept in vintage {vid} with sdmx_key",
        f"[ ] data/live/feed_failures.csv: {failures} row(s); every currency neither source served is listed there",
        f"[{'x' if n_ccy else ' '}] BIS vs ECB: {n_ccy} currencies compared, {len(held_cross)} fx3m cells held above 1%",
        (f"[{'x' if str(rep.feeds.get('theratesapi_fx', '')).startswith('ok') else ' '}] theratesapi_fx (EQ-A-0073, "
         f"EXC-005 internal research only; not required): {rep.feeds.get('theratesapi_fx', 'not run')}; fx3m from it for "
         f"{n_rates} countries (VES/NGN/PKR/VND/ZMW; `audit client` lists them)"),
        "[ ] Sam: spot-check one rate (e.g. BRL/USD) against the central bank's own page before --apply-fx",
        "[ ] Sam: fx3m in data/live/live_profile.csv close to the 2026-10-23 (Yahoo-era) vintage for the same country",
        f"[{'x' if len(restricted) == 0 else ' '}] audit.restricted_source_cells = {len(restricted)} (must be 0 after the apply)",
    ]
    return _verdict(checks)


def _csv_rows(path: Path) -> int:
    """Data rows of a CSV (0 when absent)."""
    if not path.is_file():
        return 0
    with open(path, encoding="utf-8") as f:
        return max(sum(1 for _ in f) - 1, 0)


def _fx_finish(ctx: Context):
    from .audit import restricted_source_cells
    from .feeds import VintageContentError, apply_vintage
    vid = ctx.rec["artifacts"]["vintage_id"]
    if not ctx.opts.apply_fx:
        ctx.rec["artifacts"]["apply_pending"] = True
        ctx.rec["next"] = (f"Check the fx checklist in report.md, spot-check one rate, then rerun with --apply-fx "
                           f"to apply vintage {vid} (held cells stay held)")
        return "held", f"fetched and verified; not applied (vintage {vid}): rerun with --apply-fx to apply"
    try:
        res = apply_vintage(ctx.data_dir, vid)                     # never forced: gate holds and ledger holds stay
    except (VintageContentError, ValueError, FileNotFoundError) as e:
        ctx.rec["next"] = "Send report.md to Team A; rerun with --redo fx for a fresh pull"
        return "held", f"apply refused: {type(e).__name__}: {e}"
    ctx.rec["artifacts"]["apply_pending"] = False
    ctx.rec["artifacts"]["applied"] = {k: res.get(k) for k in ("profile_cells", "indicator_cells", "held_for_review",
                                                               "snapshot", "inputs_snapshot")}
    restricted = restricted_source_cells(ctx.data_dir)
    ctx.rec["counts"].update(applied_profile_cells=int(res.get("profile_cells", 0)),
                             held_for_review=int(res.get("held_for_review", 0)),
                             restricted_source_cells=int(len(restricted)))
    ctx.rec["verify"]["checks"].append(_check("audit.restricted_source_cells is 0 after the apply", len(restricted) == 0,
                                              f"{len(restricted)} cells", required=False))
    if res.get("still_held"):
        ctx.rec["held"] = [f"{t} {k} {c}: held by the gate, not applied" for t, k, c in res["still_held"]]
    if len(restricted):
        cells = ", ".join(f"{r.key} {r.country}" for r in restricted.head(20).itertuples(index=False))
        ctx.rec["next"] = ("Review and apply the held fx3m cells (docs/runbooks/A-daily-record.md) or send the list to "
                           "Team A; then `python -m econquest.ingestion.audit restricted` must print 0")
        return "held", f"applied; {len(restricted)} restricted-source cells remain ({cells})"
    ctx.rec["next"] = "Run `econquest audit` to rewrite data/audit_trail.csv"
    return None


# ------------------------------------------------------------------------------------------------ step 1b: fx history

# EQ-A-0054 (Sam 2026-10-24 12:31Z): data/market_history/prices.csv rebuilt from official FX only. The builder is written
# under that ticket; until it exists this step is skipped with FX_HISTORY_PENDING. Looked up by name, never imported
# eagerly, so the pack works before and after it lands.
FX_HISTORY_FUNC = "build_official_fx_history"
FX_HISTORY_MODULES = ("econquest.ingestion.market_history", "econquest.ingestion.official_fx_history",
                      "econquest.ingestion.fx_history", "econquest.ingestion.market.official_fx_history")
FX_HISTORY_PENDING = "pending EQ-A-0054"
FX_HISTORY_SIDECARS = ("prices.provenance.json", "prices.csv.provenance.json", "prices_provenance.json", "provenance.json")


def find_fx_history_builder() -> Callable | None:
    """`build_official_fx_history(data_dir, start, end)` from the first module of FX_HISTORY_MODULES that has it."""
    import importlib
    for m in FX_HISTORY_MODULES:
        try:
            mod = importlib.import_module(m)
        except ImportError:
            continue
        f = getattr(mod, FX_HISTORY_FUNC, None)
        if callable(f):
            return f
    return None


def _fxh_preflight(ctx: Context) -> str | None:
    if find_fx_history_builder() is None:
        ctx.rec["next"] = "Nothing to do yet: the official FX history builder comes with EQ-A-0054"
        return FX_HISTORY_PENDING
    return None


def _fxh_paths(ctx: Context, res) -> tuple[Path, Path | None]:
    """(prices.csv, provenance sidecar) from the builder's result (a dict naming them, or a path) or the defaults."""
    mh = ctx.data_dir / "market_history"
    out, side = mh / "prices.csv", None
    if isinstance(res, dict):
        for k in ("prices", "out", "output", "path", "csv"):
            if res.get(k):
                out = Path(res[k]); break
        for k in ("provenance", "sidecar", "provenance_path"):
            if isinstance(res.get(k), (str, Path)) and res.get(k):
                side = Path(res[k]); break
    elif isinstance(res, (str, Path)):
        out = Path(res)
    if side is None:
        side = next((out.parent / n for n in FX_HISTORY_SIDECARS if (out.parent / n).is_file()), None)
    return out, side


def _fxh_run(ctx: Context):
    f = find_fx_history_builder()
    start, end = ctx.opts.fx_history_start, ctx.opts.fx_history_end      # None = the builder's own default
    try:
        res = f(ctx.data_dir, start, end)
    except Exception as e:
        if type(e).__name__ != "FxHistoryHeld":       # EQ-A-0077: a held build is 'held', not a failure
            raise
        h = e.holds[e.holds["status"] == "hold"]
        ctx.rec["artifacts"] = {"prices": "", "provenance": "", "start": start, "end": end,
                                "review": str(getattr(e, "review", "") or ""), "held_vintage": e.vintage_id,
                                "builder": f"{f.__module__}.{f.__name__}"}
        ctx.rec["held"] = [f"{r.key} {r.country}: {r.reason}" for r in h.itertuples(index=False)][:50]
        ctx.rec["next"] = ("Review " + ctx.rec["artifacts"]["review"] + "/fx_review.csv; release outlier dates or drop "
                           "held columns (python -m econquest.ingestion.market_history release|drop), then "
                           f"`market_history stage --vintage {e.vintage_id}` (docs/runbooks/A-official-fx.md)")
        return "held", f"FX history build held, not staged: {len(h)} open hold(s) (EQ-A-0077)"
    out, side = _fxh_paths(ctx, res)
    ctx.rec["artifacts"] = {"prices": str(out), "provenance": str(side) if side else "", "start": start, "end": end,
                            "builder": f"{f.__module__}.{f.__name__}"}
    if isinstance(res, dict):
        ctx.rec["counts"] = {k: v for k, v in res.items() if isinstance(v, (int, float)) and not isinstance(v, bool)}
        for k in ("vintage", "vintage_id", "panel_vintage"):
            if res.get(k):
                ctx.rec["vintages"] = {"fx_history_vintage": Path(str(res[k])).name}
    return None


def _sidecar_sha(meta: dict, name: str) -> str | None:
    for k in ("sha256", "output_sha256", "prices_sha256"):
        if isinstance(meta.get(k), str):
            return meta[k]
    files = meta.get("files")
    if isinstance(files, dict) and name in files:
        v = files[name]
        return v.get("sha256") if isinstance(v, dict) else v
    return None


def _fxh_verify(ctx: Context) -> dict:
    import hashlib
    import pandas as pd
    a = ctx.rec.get("artifacts", {})
    out, side = Path(a.get("prices", "")), Path(a["provenance"]) if a.get("provenance") else None
    checks = [_check("prices.csv written", out.is_file(), str(out))]
    if side is None or not side.is_file():
        return _verdict(checks + [_check("provenance sidecar present", False, "no sidecar next to prices.csv")])
    meta = json.loads(side.read_text())
    want = _sidecar_sha(meta, out.name)
    got = hashlib.sha256(out.read_bytes()).hexdigest() if out.is_file() else ""
    checks.append(_check("prices.csv sha256 matches the provenance sidecar", bool(want) and want == got,
                         f"sidecar {str(want)[:16]}, file {got[:16]}"))
    if out.is_file():
        cols = [c for c in pd.read_csv(out, nrows=0).columns if c.lower() not in ("date", "period")]
        series = meta.get("series") or meta.get("columns")
        if isinstance(series, (list, dict)):
            listed = set(series if isinstance(series, list) else series.keys())
            unlisted = [c for c in cols if c not in listed]
            checks.append(_check("every price column has a provenance entry", not unlisted,
                                 ", ".join(unlisted[:10]) or f"{len(cols)} columns"))
        ctx.rec.setdefault("counts", {}).update(columns=len(cols))
        bad = [c for c in cols if "yahoo" in c.lower() or "googlefinance" in c.lower()]
        checks.append(_check("no Yahoo or GOOGLEFINANCE column", not bad, ", ".join(bad) or "none"))
    ctx.rec["next"] = "Send report.md; Team B is told of the prices.csv contract change under EQ-A-0054"
    return _verdict(checks)


# ------------------------------------------------------------------------------------------------ step 2: panel history

def _panel_dir(ctx: Context) -> Path:
    return ctx.data_dir / "panel"


def panel_deferred(sources) -> dict:
    """{source: ticket} for the panel sources a run leaves out because they are deferred (EQ-A-0079)."""
    return {s: t for s, t in PANEL_DEFERRED.items() if s not in set(sources or ())}


def _ph_deferred_note(deferred: dict) -> str:
    return "; ".join(f"{s.upper()} deferred ({t})" for s, t in deferred.items())


def _ph_run(ctx: Context):
    from .panel_history import IncompleteFetchError, fetch_history
    out = _panel_dir(ctx)
    sources = [s for s in PANEL_SOURCES_ALL if s in set(ctx.opts.panel_sources)]
    old = ctx.prev.get("artifacts", {}).get("run_id")
    resume = None
    if old and not ctx.redo and (out / "staging" / old / "manifest.json").is_file():
        m = json.loads((out / "staging" / old / "manifest.json").read_text())
        had = (m.get("params") or {}).get("sources")
        same = had is None or sorted(had) == sorted(sources)       # a manifest without params: resumed as before
        resume = old if m.get("status") != "complete" and same else None
        if m.get("status") != "complete" and not same:
            ctx.detail(f"history run {old} has sources {(m.get('params') or {}).get('sources')}; step 2 asks for "
                       f"{sources}: a new run is started (run {old} is kept as it is)")
    deferred = panel_deferred(sources)
    base = {"sources": sources} | ({"deferred": deferred} if deferred else {})
    ctx.rec["artifacts"] = base | ({"run_id": resume} if resume else {})
    if deferred:
        ctx.detail(f"panel_history: {_ph_deferred_note(deferred)}; not fetched and not counted as missing")
    try:
        m = fetch_history(out, sources=sources, weo_vintages=ctx.opts.weo_vintages, run_id=resume, log=ctx.detail)
    except IncompleteFetchError as e:
        rid = e.manifest.get("run_id") if isinstance(getattr(e, "manifest", None), dict) else resume
        ctx.rec["artifacts"]["run_id"] = rid
        ctx.rec["held"] = [f"{u}: {e.manifest['units'][u]['error']}" for u in getattr(e, "missing", [])][:50]
        ctx.rec["next"] = (f"Rerun `pullpack run`: it resumes history run {rid} (only the missing units are fetched). "
                           + ("World Bank part only, " + _ph_deferred_note(deferred) + "; if PV.EST is missing run "
                              "`python -m econquest.ingestion.panel_history --probe-wb PV.EST` and send "
                              "outputs/wb_probe/probe.json (EQ-A-0079)" if deferred else
                              "WEO releases still missing: `python -m econquest.ingestion.panel_history --out data/panel "
                              "--manual-list` names the file to save for each (EQ-A-0068); send "
                              "data/panel/staging/weo_cache/weo_route_diagnostics.jsonl"))
        raise
    ctx.rec["artifacts"] = base | {"run_id": m["run_id"], "panel_vintage": m.get("panel_vintage", "")}
    return None


def _ph_verify(ctx: Context) -> dict:
    return _history_verify(ctx, _panel_dir(ctx))


def _history_verify(ctx: Context, out: Path, weo_note: bool = True) -> dict:
    """Verify a panel_history run under `out` (step 2: data/panel; step 2w: data/panel/wb_interim, weo_note False)."""
    import pandas as pd
    from .panel_history import list_panel_vintages, sha256_file
    a = ctx.rec.get("artifacts", {})
    mp = out / "staging" / str(a.get("run_id")) / "manifest.json"
    if not mp.is_file():
        return _verdict([_check("history run manifest exists", False, str(mp))])
    m = json.loads(mp.read_text())
    units = m.get("units", {})
    bad = [u for u, r in units.items() if r.get("status") != "ok"]
    checks = [_check("run complete, every unit ok", m.get("status") == "complete" and not bad,
                     f"{len(units) - len(bad)}/{len(units)} units ok")]
    for name, meta in (m.get("final") or {}).items():
        if not isinstance(name, str) or Path(name).name != name or name in (".", "..") or not isinstance(meta, dict):
            # SEC-A-008 M1 (EQ-A-0066): the landing check runs this on a manifest that came with the pack
            checks.append(_check("final file names are plain names in data/panel", False, str(name)[:80]))
            continue
        f = out / name
        checks.append(_check(f"{name} matches the run's sha256", f.is_file() and sha256_file(f) == meta.get("sha256"),
                             str(meta.get("sha256", ""))[:16]))
    pv = m.get("panel_vintage", "")
    checks.append(_check("panel vintage saved", bool(pv) and pv in list_panel_vintages(out), pv))
    counts = {"units": len(units), "units_ok": len(units) - len(bad)}
    if (out / "weo_history.csv").is_file():
        w = pd.read_csv(out / "weo_history.csv", usecols=["iso", "series", "vintage"], dtype=str)
        counts.update(weo_rows=int(len(w)), weo_releases=int(w["vintage"].nunique()), weo_economies=int(w["iso"].nunique()),
                      weo_series=int(w["series"].nunique()))
    if (out / "worldbank_history.csv").is_file():
        b = pd.read_csv(out / "worldbank_history.csv", usecols=["iso", "series"], dtype=str)
        counts.update(wb_rows=int(len(b)), wb_series=int(b["series"].nunique()), wb_economies=int(b["iso"].nunique()))
    missing = {u: r.get("codes_missing") for u, r in units.items() if r.get("codes_missing")}
    if missing:
        checks.append(_check("every WEO release has every series", False,
                             f"{len(missing)} releases lack a series (codes_missing in the manifest)", required=False))
    srcs = (m.get("params") or {}).get("sources")
    deferred = panel_deferred(srcs) if isinstance(srcs, list) and weo_note else {}   # no params: none known deferred
    if deferred:                       # EQ-A-0079: a note, not a failure; the tickets that need it stay blocked
        counts.update({s: f"deferred ({t})" for s, t in deferred.items()})    # report: "weo deferred (EQ-A-0087)"
        checks.append(_check("WEO history in this run", False, f"{_ph_deferred_note(deferred)}: not fetched; "
                             f"{', '.join(PANEL_NEEDS_WEO)} stay blocked", required=False))
    ctx.rec["counts"] = counts
    ctx.rec["vintages"] = {"panel_vintage": pv, "history_run": m.get("run_id", "")}
    ctx.rec["next"] = ("Upload data/panel (without staging/weo_cache) with report.md; Team B reviews coverage"
                       + (f". {_ph_deferred_note(deferred)}: World Bank part only" if deferred else ""))
    return _verdict(checks)


# ------------------------------------------------------------------------------------------------ step 2w: WB-only panel
# EQ-A-0094: Team B's interim hazard refit (EQ-B-0098) needs World Bank history 2000-2025 for about 190 economies; the
# shared pulls hold 2020-2025 only (raw_worldbank.csv, mrnev=6, 88 economies). This step is its own history run in
# data/panel/wb_interim/, so a series that fails in step 2 (PV.EST on 0.4.2) cannot hold it up, and it never
# touches data/panel/worldbank_history.csv.

def _wbp_dir(ctx: Context) -> Path:
    from .panel_history import WB_PANEL_DIR
    return _panel_dir(ctx) / WB_PANEL_DIR


def _wbp_run(ctx: Context):
    from .panel_history import IncompleteFetchError, fetch_history, wb_panel_request
    out = _wbp_dir(ctx)
    out.mkdir(parents=True, exist_ok=True)
    req = wb_panel_request(ctx.opts.wb_panel_codes, today=ctx.now().date())
    old = ctx.prev.get("artifacts", {}).get("run_id")
    resume = None
    if old and not ctx.redo and (out / "staging" / str(old) / "manifest.json").is_file():
        m = json.loads((out / "staging" / str(old) / "manifest.json").read_text())
        p = m.get("params") or {}
        same = (p.get("wb_codes") == req["wb_codes"] and p.get("wb_start") == req["wb_start"]
                and p.get("wb_end") == req["wb_end"])
        resume = old if m.get("status") != "complete" and same else None
        if m.get("status") != "complete" and not same:
            ctx.detail(f"wb_panel run {old} asked other series or years; a new run is started (run {old} is kept)")
    base = {"codes": req["wb_codes"], "years": f"{req['wb_start']}-{req['wb_end']}", "folder": "panel/wb_interim"}
    ctx.rec["artifacts"] = base | ({"run_id": resume} if resume else {})
    try:
        m = fetch_history(out, sources=["worldbank"], run_id=resume, log=ctx.detail, **req)
    except IncompleteFetchError as e:
        rid = e.manifest.get("run_id") if isinstance(getattr(e, "manifest", None), dict) else resume
        ctx.rec["artifacts"]["run_id"] = rid
        ctx.rec["held"] = [f"{u}: {e.manifest['units'][u]['error']}" for u in getattr(e, "missing", [])][:50]
        ctx.rec["next"] = (f"Rerun `pullpack run --steps wb_panel`: it resumes run {rid} (only the missing series). If a "
                           "series still fails, run `python -m econquest.ingestion.panel_history --probe-wb panel` and "
                           "send outputs/wb_probe/probes.json and the codes/ folder (EQ-A-0094)")
        raise
    ctx.rec["artifacts"] = base | {"run_id": m["run_id"], "panel_vintage": m.get("panel_vintage", "")}
    return None


def wb_panel_checks(path: Path, codes: list[str], start: int, end: int) -> tuple[list[dict], dict]:
    """Checks of a World Bank-only panel file against its contract (EQ-A-0094, the handoff to Team B): columns exactly
    iso, series, period, value, source; every requested series present; periods within start..end (no projection
    year); ISO3 codes; one row per series-economy-year. Counts per series: economies and years. Also used by landing."""
    import pandas as pd
    from .panel_history import LONG_COLUMNS
    if not path.is_file():
        return [_check("worldbank_history.csv present", False, str(path))], {}
    b = pd.read_csv(path, dtype={"iso": str, "series": str})
    per = {c: {"rows": int((b["series"] == c).sum()), "economies": int(b.loc[b["series"] == c, "iso"].nunique()),
               "first": int(b.loc[b["series"] == c, "period"].min()) if (b["series"] == c).any() else None,
               "last": int(b.loc[b["series"] == c, "period"].max()) if (b["series"] == c).any() else None}
           for c in codes}
    period = pd.to_numeric(b["period"], errors="coerce")
    missing = [c for c in codes if not per[c]["rows"]]
    thin = [f"{c} {v['economies']}" for c, v in per.items() if v["rows"] and v["economies"] < 100]
    checks = [_check("columns are iso, series, period, value, source", list(b.columns) == LONG_COLUMNS, ",".join(b.columns)),
              _check("every requested series has rows", not missing, f"missing: {', '.join(missing) or 'none'}"),
              _check(f"periods within {start}-{end} (no projection year)",
                     bool(period.notna().all() and period.between(start, end).all()),
                     f"{int(period.min()) if len(b) else '-'}-{int(period.max()) if len(b) else '-'}"),
              _check("ISO3 economy codes", bool(b["iso"].astype(str).str.fullmatch(r"[A-Z0-9]{3}").all()), ""),
              _check("one row per series, economy and year", not b.duplicated(["series", "iso", "period"]).any(), ""),
              _check("each series covers 100+ economies", not thin, "; ".join(thin) or "ok", required=False)]
    return checks, {"rows": int(len(b)), "series": per}


def _wbp_verify(ctx: Context) -> dict:
    out = _wbp_dir(ctx)
    v = _history_verify(ctx, out, weo_note=False)
    a = ctx.rec.get("artifacts", {})
    mp = out / "staging" / str(a.get("run_id")) / "manifest.json"
    p = (json.loads(mp.read_text()).get("params") or {}) if mp.is_file() else {}
    if p:
        checks, counts = wb_panel_checks(out / "worldbank_history.csv", list(p.get("wb_codes") or []),
                                         int(p.get("wb_start", 0)), int(p.get("wb_end", 0)))
        v = _verdict(v["checks"] + checks)
        ctx.rec.setdefault("counts", {}).update({f"{c}_economies": s["economies"] for c, s in counts.get("series", {}).items()})
    ctx.rec["next"] = ("Upload data/panel/wb_interim/worldbank_history.csv and its staging/<run>/manifest.json with "
                       "report.md; Team B reruns `hazard_refit --wb-interim` on it (EQ-B-0098)")
    return v


# ------------------------------------------------------------------------------------------------ step 3: CRAG

def _crag_out(ctx: Context) -> Path:
    return _panel_dir(ctx) / "sovereign_defaults_crag.csv"


def _crag_preflight(ctx: Context) -> str | None:
    x = ctx.opts.crag_path()
    if not x.is_file():
        ctx.rec["next"] = f"Download {CRAG_FILE} from {CRAG_URL} to {x}, then rerun `pullpack run`"
        return f"{CRAG_FILE} not found: download it from {CRAG_URL} to {x} (or pass --crag-xlsx PATH)"
    return None


def _crag_run(ctx: Context):
    from .default_panel import import_crag
    x = ctx.opts.crag_path()
    iso_map = _panel_dir(ctx) / "crag_iso_map.csv"
    label = f"BoC-BoE Sovereign Default Database 2026 ({x.name})"
    try:
        s = import_crag(x, _crag_out(ctx), label, CRAG_VINTAGE, iso_map_csv=iso_map if iso_map.is_file() else None,
                        panel_dir=_panel_dir(ctx))
    except ValueError as e:
        if "no ISO3 code" not in str(e):
            raise
        tpl = _panel_dir(ctx) / "sovereign_defaults_crag_unmapped.csv"
        ctx.rec["next"] = (f"Fill the iso column of {tpl} (never guess; Team B decides historical states), save it as "
                           f"{iso_map}, then rerun `pullpack run`")
        return "held", f"CRAG import stopped: {e}"
    ctx.rec["artifacts"] = {"input": x.name, "input_sha256": s["input_sha256"], "output_sha256": s["output_sha256"],
                            "panel_vintage": Path(s.get("panel_vintage", "")).name}
    ctx.rec["counts"] = {"episodes": int(s["episodes"]), "countries": int(s["countries"]),
                         "universe_countries": int(s["universe_countries"]),
                         "universe_unmapped": len(s.get("universe_unmapped", []))}
    return None


def _crag_verify(ctx: Context) -> dict:
    from .default_panel import compare_panels, comparison_table, panel_coverage
    from .panel_history import list_panel_vintages
    out, pdir = _crag_out(ctx), _panel_dir(ctx)
    a = ctx.rec.get("artifacts", {})
    checks = [_check("episode file written", out.is_file() and ctx.rec.get("counts", {}).get("episodes", 0) > 0,
                     f"{ctx.rec.get('counts', {}).get('episodes', 0)} episodes"),
              _check("panel vintage saved", a.get("panel_vintage", "") in list_panel_vintages(pdir), a.get("panel_vintage", ""))]
    old = pdir / "sovereign_defaults.csv"
    if old.is_file():
        r = compare_panels(old, out)
        comparison_table(r).to_csv(pdir / "crag_comparison.csv", index=False)
        ctx.rec["counts"].update({f"vs_memory_{k}": int(r["summary"][k]) for k in ("added", "removed", "changed", "unchanged")})
    hist = pdir / "weo_history.csv"
    uni = out.with_name(out.stem + "_universe.csv")
    if hist.is_file():
        cov = panel_coverage(out, hist, universe_csv=uni if uni.is_file() else None)
        _atomic_write(pack_dir(ctx.data_dir) / "panel_coverage.json", json.dumps(cov, indent=1, default=str))
        c = cov["checks"]
        checks += [_check("every episode sourced", c["every_episode_sourced"], f"{cov['defaults_without_source']} without source"),
                   _check("history has at least 100 countries", c["at_least_100_countries"], str(cov["n_countries"]), required=False),
                   _check("ever-defaulted share below 55%", c["share_below_55pct"], str(cov["ever_defaulted_share"]), required=False)]
        ctx.rec["counts"].update(n_countries=cov["n_countries"], n_ever_defaulted=cov["n_ever_defaulted"],
                                 ever_defaulted_share=cov["ever_defaulted_share"],
                                 zeros_not_covered_by_crag=len(cov["zeros_not_covered_by_crag"] or []),
                                 defaults_missing_from_history=len(cov["defaults_missing_from_history"]))
        ctx.rec["artifacts"]["coverage"] = "live/pullpack/panel_coverage.json"
    else:
        checks.append(_check("coverage against weo_history.csv", False, "weo_history.csv absent (step 2 not done)", required=False))
    ctx.rec["vintages"] = {"panel_vintage": a.get("panel_vintage", "")}
    return _verdict(checks)


def _crag_finish(ctx: Context):
    if not (_panel_dir(ctx) / "weo_history.csv").is_file():
        ctx.rec["next"] = "Finish step 2 (panel history), then rerun with --redo crag for the coverage check"
        return "held", "imported and saved as a panel vintage; coverage check waits for weo_history.csv (step 2)"
    ctx.rec["next"] = ("Team B and Sam review data/panel/crag_comparison.csv and the coverage in report.json; the file "
                       "swap (EQ-A-0008 part 2) and any refit are separate, Tier 1 for the refit")
    return None


# ------------------------------------------------------------------------------------------------ step 4: universe

def _uni_dest(ctx: Context) -> Path:
    a = ctx.prev.get("artifacts", {})
    if not ctx.redo and a.get("stage_dir"):
        return Path(a["stage_dir"])
    if ctx.opts.universe_dest:
        return Path(ctx.opts.universe_dest).expanduser()
    return Path.home() / f"econquest-universe-{ctx.now().strftime('%Y%m%d-%H%M')}"


def _uni_preflight(ctx: Context) -> str | None:
    from .universe import DEFAULT_PROPOSAL, load_universe_proposal, validate_universe
    p = ctx.data_dir / "panel" / DEFAULT_PROPOSAL.name
    if not p.is_file():
        return f"{p} not found (the reviewed 88-country proposal, docs/runbooks/A-universe-expansion.md part 1)"
    problems = validate_universe(load_universe_proposal(p), data_dir=ctx.data_dir)
    if problems:
        ctx.rec["next"] = "Fix the proposal (python -m econquest.ingestion.universe validate) and rerun"
        return f"proposal fails validation: {'; '.join(problems[:5])}"
    return None


def _uni_estimate(ctx: Context) -> int:
    a = ctx.prev.get("artifacts", {})
    if not ctx.redo and a.get("stage_dir") and Path(a["stage_dir"]).is_dir():
        return 300 * MB                                         # the staged copy exists: only the pull
    return _dir_size(ctx.data_dir) + 500 * MB


def _uni_run(ctx: Context):
    from .feeds import fetch_and_save
    from .loaders import load_universe
    from .universe import DEFAULT_PROPOSAL, expand_countries, missing_cell_report, stage_data_dir
    d = ctx.data_dir
    dest = _uni_dest(ctx)
    ctx.rec["artifacts"] = {"stage_dir": str(dest)}
    if not dest.is_dir():
        res = expand_countries(d / "panel" / DEFAULT_PROPOSAL.name, d, d / "panel" / "universe_staging", now=ctx.now())
        ctx.rec["artifacts"]["expected_countries"] = int(res["n_total"])
        stage_data_dir(d / "panel" / "universe_staging", dest, d)
        ctx.detail(f"universe: staged data folder {dest}")
    else:
        ctx.rec["artifacts"]["expected_countries"] = ctx.prev.get("artifacts", {}).get("expected_countries")
    u = load_universe(dest)
    rep, _diff, _review, v = fetch_and_save(u, dest, log=ctx.detail)
    ctx.rec["artifacts"]["staged_vintage"] = v.name
    ctx.rec["artifacts"]["feeds"] = dict(rep.feeds)
    mr = missing_cell_report(dest)
    pk = pack_dir(d)
    pk.mkdir(parents=True, exist_ok=True)
    mr.cells.to_csv(pk / "universe_missing_cells.csv", index=False)
    mr.countries.to_csv(pk / "universe_missing_countries.csv", index=False)
    ctx.rec["counts"] = {k: mr.summary[k] for k in ("n_countries", "pct_live_overall", "pct_live_eligible_overall", "target",
                                                     "countries_meeting_target",
                                                     "cells_without_any_value")}
    ctx.rec["counts"]["by_reason"] = mr.summary.get("by_reason", {})
    if mr.summary.get("measured") is False:                # EQ-A-0080: partial staged pull, coverage not measured
        ctx.rec["counts"].update(measured=False, note=mr.summary.get("note", ""))
    return None


def _uni_verify(ctx: Context) -> dict:
    from .feeds import verify_vintage
    a, c = ctx.rec.get("artifacts", {}), ctx.rec.get("counts", {})
    dest = Path(a.get("stage_dir", ""))
    checks = [_vintage_ok(lambda: verify_vintage(dest, a.get("staged_vintage", "")), "staged vintage verifies")]
    pk = pack_dir(ctx.data_dir)
    checks.append(_check("missing-cell report written", (pk / "universe_missing_cells.csv").is_file(),
                         "live/pullpack/universe_missing_cells.csv"))
    exp = a.get("expected_countries")
    checks.append(_check("every staged country in the report", exp is None or c.get("n_countries") == exp,
                         f"{c.get('n_countries')} of {exp}"))
    elig = c.get("pct_live_eligible_overall", c.get("pct_live_overall", 0))   # Sam 2026-10-24: 60% of feed-eligible cells
    if elig is None or c.get("measured") is False:     # EQ-A-0080: a partial pull is not measured, never compared
        checks.append(_check("at least 60% of feed-eligible cells live", False,
                             f"not measured: {c.get('note') or 'partial fetch'}", required=False))
    else:
        checks.append(_check("at least 60% of feed-eligible cells live", elig >= c.get("target", 0.6), f"{elig}",
                             required=False))
    ok_feeds = [k for k, v in (a.get("feeds") or {}).items() if str(v).startswith("ok")]
    checks.append(_check("feeds ok", bool(ok_feeds), ", ".join(f"{k}: {v}" for k, v in (a.get("feeds") or {}).items()),
                         required=False))
    ctx.rec["vintages"] = {"staged_vintage": a.get("staged_vintage", "")}
    ctx.rec["next"] = (f"Review {dest}/live/review.csv and live/pullpack/universe_missing_cells.csv; fill "
                       "data/panel/universe_staging/cells_to_fill.csv. Nothing was copied into data/ (a separate ticket)")
    return _verdict(checks)


# ------------------------------------------------------------------------------------------------ step 5: events

def _ucdp_env(ctx: Context) -> tuple[bool, str]:
    from .events.base import check_env_name, is_enabled, load_event_config
    cfg = load_event_config(ctx.data_dir).get("ucdp", {})
    return is_enabled(cfg, default=True), check_env_name(cfg.get("token_env", "UCDP_API_TOKEN"), "ucdp.token_env", "UCDP_")


def _ucdp_preflight(ctx: Context) -> str | None:
    from .events.base import env_secret
    enabled, env = _ucdp_env(ctx)
    if not enabled:
        return "ucdp is disabled in data/live/events/feeds.json"
    if not env_secret(env):                                    # the value is never read into the state or the report
        ctx.rec["next"] = (f"Request the free UCDP API token by email (3-5 working days), store it in the Keychain, then "
                           f"`export {env}=\"$({UCDP_KEYCHAIN})\"` before `pullpack run`")
        return f"{env} is not set: UCDP needs its free API token in that environment variable (never on the command line)"
    return None


def _ucdp_run(ctx: Context):
    from .events.export import write_event_exports
    from .events.ucdp import pull_and_save
    end = ctx.opts.ucdp_end or ctx.now().date().isoformat()
    v = pull_and_save(ctx.data_dir, ctx.opts.ucdp_start, end)
    ctx.rec["artifacts"] = {"vintage_id": v.name, "start": ctx.opts.ucdp_start, "end": end}
    ex = write_event_exports(ctx.data_dir)
    ctx.rec["artifacts"]["exports"] = {k: ex.get(k) for k in ("long_rows", "weekly_rows")}
    return None


def _events_verify(ctx: Context, source: str) -> dict:
    from .events.base import list_event_vintages, read_event_vintage
    vid = ctx.rec.get("artifacts", {}).get("vintage_id", "")
    checks = [_check("vintage indexed", vid in list_event_vintages(ctx.data_dir, source), vid)]
    try:
        ev = read_event_vintage(ctx.data_dir, source, vid, verify=True)
        checks.append(_check("events.csv matches its manifest sha256 and has rows", len(ev) > 0, f"{len(ev)} rows"))
    except Exception as e:  # noqa: BLE001 - reported as a failed check
        return _verdict(checks + [_check("events.csv matches its manifest sha256", False, f"{type(e).__name__}: {e}")])
    import pandas as pd
    desk = set(pd.read_csv(ctx.data_dir / "countries.csv", dtype=str, keep_default_na=False)["iso"].str.upper())
    absent = sorted(desk - set(ev["iso"]))
    checks.append(_check("every desk country present", not absent, ", ".join(absent) or "all", required=False))
    ctx.rec.setdefault("counts", {}).update(rows=int(len(ev)), countries=int(ev["iso"].nunique()),
                                            metrics=int(ev["metric"].nunique()),
                                            first_period=str(ev["period"].min()), last_period=str(ev["period"].max()))
    ctx.rec["vintages"] = {f"{source}_vintage": vid}
    ctx.rec["next"] = "Send the vintage id and report.md to AGENT-08 (indicator table: docs/runbooks/A-event-feeds.md section 5)"
    return _verdict(checks)


def _nowcast_run(ctx: Context):
    from .nowcast_feed import FeedRefused, MergeStopped, fetch
    try:
        r = fetch(ctx.data_dir, log=ctx.detail)
    except MergeStopped:                    # vintage written, merge stopped: a failure to look at, not a skip
        raise
    except FeedRefused as e:
        return "skipped", " ".join(str(e).split())[:400]
    ctx.rec["artifacts"] = {"vintage": r["vintage"], "inputs": r["target"]}
    ctx.rec["counts"].update(transformed_rows=r["transformed_rows"], added=r["added"], rows=r["rows"],
                             skipped_retroactive=r.get("skipped_retroactive", 0))
    return None


def _nowcast_verify(ctx: Context) -> dict:
    from .nowcast_feed import validate_file
    v = Path(ctx.rec.get("artifacts", {}).get("vintage", ""))
    checks = [_check("new vintage archived", v.name != "" and (v / "transformed.csv").exists(), v.name)]
    f = Path(ctx.rec["artifacts"].get("inputs", ""))
    if f.name and f.exists():
        ok, out = validate_file(f)
        checks.append(_check("nowcast_inputs.csv passes engine.nowcast validate", ok, out[-200:]))
    ctx.rec["next"] = "Verify map rows (docs/runbooks/A-nowcast-feed.md steps 4-5), then send the status output"
    return _verdict(checks)


def _gdelt_preflight(ctx: Context) -> str | None:
    from .events.base import is_enabled, load_event_config
    if not is_enabled(load_event_config(ctx.data_dir).get("gdelt", {}), default=True):
        return "gdelt is disabled in data/live/events/feeds.json"
    start, end = ctx.opts.gdelt_range(ctx.now().date())
    n = (end - start).days + 1
    if n < 1:
        return f"empty GDELT range {start}..{end}"
    if n > ctx.opts.gdelt_max_days:
        return (f"GDELT range {start}..{end} is {n} days, over --gdelt-max-days {ctx.opts.gdelt_max_days}: "
                f"pull it in bounded pieces (each rerun resumes the staging)")
    return None


def _gdelt_estimate(ctx: Context) -> int:
    start, end = ctx.opts.gdelt_range(ctx.now().date())
    return max((end - start).days + 1, 0) * GDELT_BYTES_PER_DAY + GDELT_INDEX_BYTES


def _gdelt_run(ctx: Context):
    from .events.base import save_event_vintage
    from .events.export import write_event_exports
    from .events.gdelt import GdeltAdapter, IncompleteFetchError, _desk_isos
    start, end = ctx.opts.gdelt_range(ctx.now().date())
    ctx.rec["artifacts"] = {"start": start.isoformat(), "end": end.isoformat()}
    # categories=True (EQ-A-0138, AGENT-08 for A-0139): every pull-pack vintage carries the cat_<category> counts of
    # the shared GDELT/UCDP taxonomy (docs/runbooks/A-event-taxonomy.md)
    ad = GdeltAdapter(ctx.data_dir / "live" / "events" / "gdelt" / "staging", allow_http=ctx.opts.gdelt_allow_http,
                      log=ctx.detail, categories=True)
    try:
        df = ad.fetch(_desk_isos(ctx.data_dir), start, end)
    except IncompleteFetchError as e:
        ctx.rec["held"] = [f"day {d} not staged" for d in sorted((getattr(e, "report", None) or {}).get("failed", []))][:50]
        ctx.rec["next"] = "Rerun `pullpack run`: GDELT staging resumes and fetches only the missing days"
        raise
    v = save_event_vintage(ctx.data_dir, df, "gdelt", provenance=ad.provenance())
    ctx.rec["artifacts"]["vintage_id"] = v.name
    r = ad.report
    ctx.rec["counts"] = {"days_staged": len(r.get("staged", [])), "days_skipped": len(r.get("skipped", [])),
                         "unmapped_total": int(r.get("unmapped_total", 0))}
    ex = write_event_exports(ctx.data_dir)
    ctx.rec["artifacts"]["exports"] = {k: ex.get(k) for k in ("long_rows", "weekly_rows")}
    return None


# ------------------------------------------------------------------------------------------------ step 0: dsa_regate

def _dsa_out(ctx: Context) -> Path:
    return pack_dir(ctx.data_dir) / "dsa"


DSA_TIMEOUT_S = 3600                        # `econquest dsa` takes 1-10 min (estimate); an hour means it hung


def run_econquest_dsa(data_dir: Path, out: Path, as_of: str, log: Callable[[str], None]) -> Path:
    """`econquest dsa --as-of <as_of>` as a subprocess (Team C's CLI, not imported here) writing into `out`; returns
    the dsa_scorecard_feeds.csv path. RuntimeError with the tail of its output when it fails. Reads data/live only."""
    import subprocess
    from .official.dsa_feed import DSA_FILE
    cmd = [sys.executable, "-m", "econquest", "--data", str(data_dir), "--out", str(out), "dsa", "--as-of", as_of]
    log("dsa_regate: " + " ".join(cmd))
    try:                                    # argv list, no shell; bounded so a hung child never hangs the pack (SEC-A-011 L4)
        r = subprocess.run(cmd, capture_output=True, text=True, check=False, timeout=DSA_TIMEOUT_S)  # nosec B603
    except subprocess.TimeoutExpired:
        raise RuntimeError(f"econquest dsa did not finish within {DSA_TIMEOUT_S} s: stopped") from None
    for line in (r.stdout + r.stderr).splitlines()[-40:]:
        log(f"dsa_regate: | {line}")
    if r.returncode != 0:
        raise RuntimeError(f"econquest dsa exited {r.returncode}: {' '.join((r.stderr or r.stdout).split())[-300:]}")
    return out / DSA_FILE


def _dsa_preflight(ctx: Context) -> str | None:
    from .official.dsa_regate import RegateRefused, check_base
    try:
        check_base(ctx.data_dir)
    except RegateRefused as e:
        return str(e)
    return None


def _dsa_run(ctx: Context):
    from .official.dsa_regate import regate
    out = _dsa_out(ctx)
    path = run_econquest_dsa(ctx.data_dir, out, ctx.now().date().isoformat(), ctx.detail)
    res = regate(ctx.data_dir, path, now=ctx.now(), log=ctx.detail)
    ctx.rec["artifacts"] = {"vintage_id": res["vintage_id"], "base_vintage": res["base_vintage"],
                            "dsa_file": str(path), "dsa_sha256": res["dsa_sha256"]}
    ctx.rec["counts"].update({k: res[k] for k in ("served", "ok", "held", "reseed", "unserved")})
    ctx.rec["held"] = res["held_cells"]
    return None


def _dsa_verify(ctx: Context) -> dict:
    from .feeds import list_vintages, load_vintage, verify_vintage
    import pandas as pd
    from .official.dsa_feed import DSA_KEYS, read_dsa_feeds
    d, a = ctx.data_dir, ctx.rec.get("artifacts", {})
    vid = a.get("vintage_id")
    checks = [_vintage_ok(lambda: verify_vintage(d, vid), "derived vintage hash matches vintages/index.csv")]
    if not checks[0]["ok"]:
        return _verdict(checks)
    ids = list_vintages(d)
    checks.append(_check("derived vintage is the latest (a later pull may follow it)", bool(ids) and ids[-1] == vid,
                         ids[-1] if ids else "none", required=False))
    _vid, rep, review = load_vintage(d, vid)
    st = str(rep.feeds.get("dsa", ""))
    checks.append(_check("feeds.json names the base vintage and the dsa file sha256",
                         st.startswith("ok") and str(a.get("base_vintage")) in st and str(a.get("dsa_sha256")) in st, st[:200]))
    dsa = read_dsa_feeds(Path(a.get("dsa_file", "")))
    rv = review[(review["table"] == "Inputs") & review["key"].astype(str).isin(DSA_KEYS)]
    in_review = {(str(k), c) for k, c in zip(rv["key"], rv["country"])}
    us = rep.unserved
    in_unserved = ({(str(k), c) for t, k, c in zip(us["table"], us["key"], us["country"]) if t == "Inputs"}
                   if len(us) else set())
    rows = {(str(k), c) for t, k, c in zip(dsa["table"], dsa["key"], dsa["country"]) if t == "Inputs"}
    ind = rep.indicators
    kept = {(k, c) for k, c in rows if k in ind.index and c in ind.columns and pd.notna(ind.at[k, c])}
    lost = sorted(rows - in_review - in_unserved - kept)
    checks.append(_check("every dsa row is in the review, listed unserved or behind an earlier source's value", not lost,
                         ", ".join(f"{k} {c}" for k, c in lost[:10]) or f"{len(rows)} rows"))
    replay = rv[rv["reason"].astype(str).str.contains("replay:", regex=False)]
    checks.append(_check("no dsa cell held for replay (the rows are from this vintage)", replay.empty,
                         ", ".join(f"{r.key} {r.country}" for r in replay.itertuples(index=False)[:10]) if len(replay) else "0"))
    ok12 = rv[(rv["key"].astype(str) == "1.2") & (rv["status"] == "ok")]
    reseed = rv[rv["reason"].astype(str).str.contains("dsa_reseed:", regex=False)]
    ctx.rec["vintages"] = {"base_vintage": a.get("base_vintage"), "dsa_vintage": vid}
    ctx.rec["next"] = (f"Review the dsa cells held in vintage {vid} (`econquest review`); Pakistan / Argentina 1.2 "
                       "(dsa_reseed, F8) need Sam's decision. Nothing was applied: apply only the vintage id you checked")
    ctx.rec["checklist"] = [
        f"[x] econquest dsa read vintage {a.get('base_vintage')}; derived vintage {vid} saved (raw_dsa.csv)",
        f"[ ] 1.2 gate ok in {len(ok12)} countries: {', '.join(ok12['country'].head(20)) or 'none'}",
        f"[ ] dsa_reseed holds (seed written by the old `dsa --apply`, move above 25%): "
        f"{', '.join(f'{r.key} {r.country}' for r in reseed.itertuples(index=False)) or 'none'}",
        "[ ] Sam: no apply until the held cells are reviewed; held cells stay held",
    ]
    return _verdict(checks)


# ------------------------------------------------------------------------------------------------ step 7: research

def _research_preflight(ctx: Context) -> str | None:
    """EQ-A-0089: skipped cleanly (never failed) when no research file is in any drop-in folder."""
    from .research.drops import skip_reason
    why = skip_reason(ctx.data_dir)
    if why:
        ctx.rec["next"] = ("Optional: download a research file into data/panel/research/KEY/ "
                           "(docs/runbooks/A-research-datasets.md), then `pullpack run --redo research`")
    return why


def _research_run(ctx: Context):
    """Research drops through Team B's rules and the gate, offline (research.drops); writes only its report under
    live/pullpack/research/. Nothing is applied: every cell is held, 3.6/4.4/6.10/7.12 parked for Sam's sign-off."""
    from .research import drops
    res = drops.check(ctx.data_dir, ctx.now().date().isoformat())
    paths = drops.write(res, ctx.data_dir, ctx.now())
    ctx.rec["artifacts"] = {"summary_sha256": paths["summary_sha256"], "cells_sha256": paths["cells_sha256"],
                            "as_of": res["as_of"]}
    ctx.rec["counts"].update(res["counts"])
    ctx.rec["held"] = res["parked"][:50]
    for k, v in res["sources"].items():
        line = f"research {k}: {v['status']}" + (f" ({v['detail'][:200]})" if v["status"] != "dropped" else "")
        ctx.detail(line)
    return None


def _research_verify(ctx: Context) -> dict:
    from .research import drops
    checks = drops.verify(ctx.data_dir)
    try:
        summ, _cells = drops.read(ctx.data_dir)
    except drops.DropsError:
        summ = {}
    src = summ.get("sources") or {}
    ctx.rec["vintages"] = {f"research_{k}": v.get("vintage", "") for k, v in src.items() if v.get("status") == "dropped"}
    ctx.rec["next"] = ("Send live/pullpack/research/research_drops.json and research_cells.csv with report.md to "
                       "AGENT-08; every research cell is held for the first gate review (nothing applied)")
    c = summ.get("counts") or {}
    ctx.rec["checklist"] = [
        f"[x] dropped: {', '.join(k for k, v in src.items() if v.get('status') == 'dropped') or 'none'}",
        f"[x] not dropped (skipped, not a failure): "
        f"{', '.join(k for k, v in src.items() if v.get('status') == 'not dropped') or 'none'}",
        f"[ ] refused (layout to report): {', '.join(k for k, v in src.items() if v.get('status') == 'refused') or 'none'}",
        f"[x] {c.get('cells', 0)} research cells, all held; {c.get('cells_signoff_parked', 0)} parked for Sam's sign-off "
        f"(3.6, 4.4, 6.10, 7.12)",
        f"[x] client output: {c.get('cells_client_withheld', 0)} withheld by the licence register, "
        f"{c.get('cells_client_allowed', 0)} allowed",
    ]
    return _verdict(checks)


# ------------------------------------------------------------------------------------------------ step 8: macro

def _cmo_path(ctx: Context) -> Path:
    from .official.macro import CMO_FILE
    return Path(ctx.opts.cmo_xlsx).expanduser() if ctx.opts.cmo_xlsx else Path.home() / "Downloads" / CMO_FILE


def _macro_shares(d: Path, as_of: str):
    """WDI TX.VAL shares from the newest data/live vintage retrieved on or before as_of whose raw_worldbank.csv holds
    them (official.macro.recorded_vintage_rows: the same point-in-time search as recorded_eer), else None."""
    from .official import macro as M
    rows, prov = M.recorded_vintage_rows(d, as_of, "raw_worldbank.csv", M.SHARE_SERIES)
    return (rows, prov) if len(rows) else None


def _macro_run(ctx: Context):
    """EQ-A-0134: BIS WS_EER live (optional), the Pink Sheet file (optional), recorded WDI shares; gated into one
    vintage under live/macro/vintages/. Nothing is applied and no desk cell is written."""
    from . import feeds as F
    from .official import macro as M
    d = ctx.data_dir
    now = ctx.now()
    stamp = now.strftime("%Y-%m-%dT%H:%M:%SZ")
    notes = []
    eer = None
    try:
        e = M.fetch_eer(M.desk_iso2(d))
        eer = (e, {"retrieved_utc": stamp, "vintage": "live", "failures": list(e.attrs.get("failures", []))[:20]})
        ctx.detail(f"macro eer: {len(e)} rows, {e['iso'].nunique()} names, {e['series'].nunique()} series")
    except F.FeedError as e:
        notes.append(f"BIS WS_EER: {' '.join(str(e).split())[:200]}")
        ctx.detail(f"macro eer: {notes[-1]}")
    x = _cmo_path(ctx)
    cmo = None
    if x.is_file():
        cmo = M.cmo_input(x, ctx.opts.cmo_retrieved)            # MacroError (layout) fails the step loudly
    else:
        notes.append(f"{M.CMO_FILE} not found at {x}")
    if eer is None and cmo is None:
        ctx.rec["next"] = (f"Download {M.CMO_FILE} from {M.CMO_PAGE} to {x} (or pass --cmo-xlsx PATH), then "
                           "`pullpack run --redo macro`")
        return "skipped", "; ".join(notes) + f"; download {M.CMO_FILE} from {M.CMO_PAGE}"
    shares = _macro_shares(d, now.date().isoformat())
    if shares is None:
        notes.append("no data/live vintage holds TX.VAL export shares: tot not built")
    res = M.build(d, now.date().isoformat(), eer=eer if eer is not None else (None, {"note": notes[0]}), cmo=cmo,
                  shares=shares if shares is not None else (None, {"note": notes[-1]}))
    v = M.write_vintage(d / M.MACRO_DIR, res, now=now)
    ctx.rec["artifacts"] = {"vintage_id": v.name, "vintage": str(v),
                            "manifest_sha256": M._sha(v / "manifest.json")}
    ctx.rec["vintages"] = {"macro_vintage": v.name}
    ctx.rec["counts"].update(res["provenance"]["counts"])
    held = res["checks"][res["checks"]["status"] == "hold"]
    ctx.rec["held"] = [f"{r.key} {r.country} {r.check}: {r.reason}"[:200] for r in held.head(50).itertuples(index=False)]
    for n in notes:
        ctx.detail(f"macro: {n}")
    return None


def _macro_verify(ctx: Context) -> dict:
    from .official import macro as M
    a = ctx.rec.get("artifacts") or {}
    v = ctx.data_dir / M.MACRO_DIR / "vintages" / str(a.get("vintage_id", ""))
    checks = [_check("macro vintage written", bool(a.get("vintage_id")) and v.is_dir(), str(a.get("vintage_id", "")))]
    if v.is_dir():
        checks.append(_check("manifest.json at the recorded sha256", M._sha(v / "manifest.json") == a.get("manifest_sha256")))
        checks += M.verify_vintage(v)
    ctx.rec["next"] = (f"Send live/macro/vintages/{a.get('vintage_id', '<id>')}/manifest.json and checks.csv with "
                       "report.md to AGENT-08; confirm the WS_EER keys and the Pink Sheet layout "
                       "(docs/runbooks/A-macro-inputs.md); nothing is applied")
    c = ctx.rec.get("counts") or {}
    ctx.rec["checklist"] = [
        f"[x] {c.get('values', 0)} values gated: {c.get('ok', 0)} ok, {c.get('held', 0)} held",
        f"[ ] eer series {c.get('eer_series', 0)}: check M.N.B / M.R.N / M.N.N answered (EER_VERIFIED)",
        f"[ ] commodity series {c.get('cmo_index_series', 0) + c.get('cmo_price_series', 0)}: check the Pink Sheet "
        "layout parsed as documented (CMO_VERIFIED)",
        f"[x] tot series {c.get('tot_series', 0)} (held for Team B: method)",
    ]
    return _verdict(checks)


# ------------------------------------------------------------------------------------------------ registry

def default_steps() -> list[Step]:
    """The twelve steps in run order (2w wb_panel since EQ-A-0094; 0 dsa_regate since EQ-A-0096; 7 research since
    EQ-A-0089; 8 macro since EQ-A-0134). Tests pass their own list to run()."""
    from .feeds import FEED_HOSTS
    imf = FEED_HOSTS["weo"]
    wb = FEED_HOSTS["worldbank"]
    return [
        # EQ-A-0096: offline (no host); first, because step 1 saves a newer fx-only vintage
        Step("dsa_regate", "0", "dsa re-gate of the full fetch's vintage (offline, no apply)", "1-10 min (estimate)",
             estimate=lambda ctx: 50 * MB, preflight=_dsa_preflight, run=_dsa_run, verify=_dsa_verify),
        Step("fx", "1", "official FX (BIS + ECB; theratesapi.com for 5 currencies)", "1-5 min",
             hosts=(FEED_HOSTS["bis_xru"], FEED_HOSTS["ecb_exr"]), optional_hosts=(FEED_HOSTS["theratesapi_fx"],),
             estimate=lambda ctx: 100 * MB, run=_fx_run, verify=_fx_verify, finish=_fx_finish),
        Step("fx_history", "1b", "official FX history for prices.csv (EQ-A-0054)", "5-20 min (estimate)",
             hosts=(FEED_HOSTS["bis_xru"], FEED_HOSTS["ecb_exr"]), estimate=lambda ctx: 200 * MB,
             preflight=_fxh_preflight, run=_fxh_run, verify=_fxh_verify, unblocks=("EQ-A-0054",)),
        Step("panel_history", "2", "panel history (WEO releases + World Bank)", "30-120 min", hosts=(imf, wb),
             estimate=lambda ctx: 2 * GB, run=_ph_run, verify=_ph_verify,
             unblocks=("EQ-A-0015", "EQ-A-0016")),
        Step("wb_panel", "2w", "World Bank-only panel history 2000-2025 (EQ-A-0094)", "2-10 min (estimate)", hosts=(wb,),
             estimate=lambda ctx: 100 * MB, run=_wbp_run, verify=_wbp_verify),
        Step("crag", "3", "BoC-BoE default database import", "under 1 min", estimate=lambda ctx: 100 * MB,
             preflight=_crag_preflight, run=_crag_run, verify=_crag_verify, finish=_crag_finish,
             unblocks=("EQ-A-0008", "EQ-A-0016")),
        Step("universe", "4", "88-country staged fetch", "10-40 min", hosts=(imf, wb, FEED_HOSTS["bis"]),
             estimate=_uni_estimate, preflight=_uni_preflight, run=_uni_run, verify=_uni_verify,
             unblocks=("EQ-A-0026",), disk_path=lambda ctx: _uni_dest(ctx).parent),
        Step("ucdp", "5a", "UCDP first pull", "1-5 min", hosts=(("ucdpapi.pcr.uu.se",),), estimate=lambda ctx: 50 * MB,
             preflight=_ucdp_preflight, run=_ucdp_run, verify=lambda ctx: _events_verify(ctx, "ucdp")),
        Step("gdelt", "5b", "GDELT first pull (bounded range)", "1-3 min per day (estimate)",
             hosts=(("data.gdeltproject.org",),), estimate=_gdelt_estimate, preflight=_gdelt_preflight,
             run=_gdelt_run, verify=lambda ctx: _events_verify(ctx, "gdelt")),
        # one host group: the feed needs any one of its three sources (each skipped source is recorded by the feed)
        Step("nowcast", "6", "nowcast inputs feed (EQ-A-0057)", "1-5 min (estimate)",
             hosts=(("api.imf.org", "sdmx.oecd.org", "stats.bis.org"),), estimate=lambda ctx: 50 * MB,
             run=_nowcast_run, verify=_nowcast_verify, unblocks=("EQ-A-0057",)),
        # EQ-A-0089: offline (no host); research drop-in folders through Team B's rules and the gate, nothing applied
        Step("research", "7", "research file drops through the gate (offline, nothing applied)", "under 1 min",
             estimate=lambda ctx: 10 * MB, preflight=_research_preflight, run=_research_run, verify=_research_verify),
        # EQ-A-0134: BIS optional (reported when unreachable); the Pink Sheet file is read from disk, never fetched
        Step("macro", "8", "macro inputs: BIS EER, Pink Sheet commodities, export-share ToT (EQ-A-0134)",
             "1-5 min (estimate)", optional_hosts=(FEED_HOSTS["bis"],), estimate=lambda ctx: 50 * MB,
             run=_macro_run, verify=_macro_verify),
    ]


# Every step id, in default_steps order ("nowcast", step 6, EQ-A-0057, joined after HO-20261024-A-C-015; "research",
# step 7, EQ-A-0089).
STEP_IDS = ("dsa_regate", "fx", "fx_history", "panel_history", "wb_panel", "crag", "universe", "ucdp", "gdelt", "nowcast",
            "research",                                       # EQ-A-0089: step 7, offline
            "macro")                                          # EQ-A-0134: step 8


def _select(steps: Iterable[str] | None, registry: list[Step]) -> list[Step]:
    ids = [s.id for s in registry]
    if not steps:
        return list(registry)
    want = [s.strip() for s in steps if s and s.strip()]
    bad = [s for s in want if s not in ids]
    if bad:
        raise UsageError(f"unknown step(s) {bad}; steps are {', '.join(ids)}")
    return [s for s in registry if s.id in want]


# ------------------------------------------------------------------------------------------------ state

def _new_record(step: Step) -> dict:
    return {"id": step.id, "number": step.number, "title": step.title, "status": "pending", "reason": "",
            "started_utc": "", "finished_utc": "", "elapsed_s": 0.0, "attempts": 0, "counts": {}, "vintages": {},
            "verify": {}, "held": [], "next": "", "artifacts": {}, "unblocks": list(step.unblocks),
            "expected_time": step.expected_time}


def load_state(data_dir: str | Path, registry: list[Step] | None = None) -> dict:
    """The state file, or a fresh state with every step pending. Steps unknown to the registry are kept."""
    registry = registry if registry is not None else default_steps()
    p = pack_dir(data_dir) / STATE_FILE
    try:                                                 # EQ-A-0138: a damaged state.json is a plain refusal (UsageError
        st = json.loads(p.read_text(encoding="utf-8")) if p.is_file() else {}       # is a ValueError, as before)
    except (OSError, ValueError, RecursionError) as e:
        raise UsageError(f"{p} cannot be read ({type(e).__name__}); nothing was run. Move it aside (in {p.parent}: "
                         f"mv {p.name} {p.name}.damaged) and rerun: every step then starts as pending") from None
    if not isinstance(st, dict) or not isinstance(st.get("steps", {}), dict):
        raise UsageError(f"{p} is not a pull pack state file (no steps object); nothing was run. Move it aside and rerun")
    if st.get("version") not in (None, STATE_VERSION):
        raise UsageError(f"{p}: state version {st.get('version')} is not {STATE_VERSION}; nothing was run")
    st.setdefault("version", STATE_VERSION)
    st.setdefault("created_utc", "")
    st.setdefault("steps", {})
    for s in registry:
        st["steps"].setdefault(s.id, _new_record(s))
    st["order"] = [s.id for s in registry]
    return st


def save_state(data_dir: str | Path, state: dict, now: dt.datetime | None = None) -> Path:
    state["updated_utc"] = _stamp(now or _utcnow())
    p = pack_dir(data_dir) / STATE_FILE
    _atomic_write(p, json.dumps(state, indent=1, sort_keys=True, default=str) + "\n")
    return p


def exit_code(state: dict, steps: Iterable[str] | None = None) -> int:
    """0 every selected step done; 1 any failed; 2 any skipped, held, pending or running."""
    ids = list(steps) if steps else list(state.get("order") or state.get("steps", {}))
    sts = [state["steps"].get(i, {}).get("status", "pending") for i in ids]
    if "failed" in sts:
        return EXIT_FAILED
    return EXIT_DONE if all(s == "done" for s in sts) else EXIT_INCOMPLETE


def _is_done(rec: dict) -> bool:
    return rec.get("status") == "done" and bool((rec.get("verify") or {}).get("passed"))


# ------------------------------------------------------------------------------------------------ public entry points

def plan(data_dir: str | Path = "data", opts: PackOptions | None = None, steps: Iterable[str] | None = None,
         redo: Iterable[str] = (), *, registry: list[Step] | None = None, disk_usage: Callable = shutil.disk_usage,
         now: Callable[[], dt.datetime] = _utcnow) -> list[dict]:
    """What `run` would do, without network: per step id, number, title, expected_time, estimate_bytes, free_bytes,
    disk_ok, preflight (skip reason or ''), hosts, state status, and action ('run', 'resume', 'skip: done',
    'skip: <reason>'). Writes nothing."""
    d, opts = Path(data_dir), opts or PackOptions()
    registry = registry if registry is not None else default_steps()
    state = load_state(d, registry)
    redo_set = _redo_set(redo, registry)
    rows = []
    for s in _select(steps, registry):
        prev = state["steps"][s.id]
        ctx = Context(d, opts, _new_record(s), prev, s.id in redo_set, lambda m: None, lambda m: None, now)
        why = s.preflight(ctx) or ""
        need = int(s.estimate(ctx))
        dp = s.disk_path(ctx) if s.disk_path else d
        disk = check_disk(dp, need, disk_usage)
        q = Path(dp)
        while not q.exists() and q.parent != q:
            q = q.parent
        free = int(disk_usage(str(q)).free)
        if _is_done(prev) and s.id not in redo_set:
            action = "skip: done (use --redo to rerun)"
        elif why or disk:
            action = f"skip: {why or disk}"
        elif prev.get("status") in ("failed", "running", "held") and prev.get("artifacts"):
            action = "resume"
        else:
            action = "run"
        rows.append({"id": s.id, "number": s.number, "title": s.title, "expected_time": s.expected_time,
                     "estimate_bytes": need, "free_bytes": free, "disk_ok": disk is None, "preflight": why,
                     "hosts": [list(g) for g in s.hosts], "optional_hosts": [list(g) for g in s.optional_hosts],
                     "status": prev.get("status", "pending"), "action": action,
                     "unblocks": list(s.unblocks)})
    return rows


def _redo_set(redo: Iterable[str], registry: list[Step]) -> set[str]:
    ids = {s.id for s in registry}
    out = set()
    for r in redo or ():
        for x in str(r).split(","):
            x = x.strip()
            if not x:
                continue
            if x == "all":
                out |= ids
            elif x not in ids:
                raise UsageError(f"--redo {x!r}: unknown step; steps are {', '.join(s.id for s in registry)}")
            else:
                out.add(x)
    return out


@contextlib.contextmanager
def run_lock(data_dir: str | Path):
    """Exclusive non-blocking flock on data/live/pullpack/run.lock for one run (SEC-A-007 L1): two concurrent runs
    would fetch and apply the same steps and overwrite each other's state.json. Released when the process ends, so a
    crash leaves no stale lock. PackBusy when another run holds it."""
    pk = pack_dir(data_dir)
    pk.mkdir(parents=True, exist_ok=True)
    p = pk / LOCK_FILE
    with open(p, "a") as f:
        if fcntl is not None:
            try:
                fcntl.flock(f.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            except OSError:
                raise PackBusy(f"another `pullpack run` holds {p}; wait for it to finish") from None
        try:
            yield p
        finally:
            if fcntl is not None:
                fcntl.flock(f.fileno(), fcntl.LOCK_UN)


def run(data_dir: str | Path = "data", opts: PackOptions | None = None, steps: Iterable[str] | None = None,
        redo: Iterable[str] = (), *, registry: list[Step] | None = None,
        probe: Callable[[str], str | None] | None = None, disk_usage: Callable = shutil.disk_usage,
        now: Callable[[], dt.datetime] = _utcnow, out: Callable[[str], None] = print,
        clock: Callable[[], float] = time.monotonic) -> dict:
    """Under run_lock (PackBusy when another run holds it): see _run_unlocked."""
    with run_lock(data_dir):
        return _run_unlocked(data_dir, opts, steps, redo, registry=registry, probe=probe, disk_usage=disk_usage,
                             now=now, out=out, clock=clock)


def _run_unlocked(data_dir: str | Path = "data", opts: PackOptions | None = None, steps: Iterable[str] | None = None,
                  redo: Iterable[str] = (), *, registry: list[Step] | None = None,
                  probe: Callable[[str], str | None] | None = None, disk_usage: Callable = shutil.disk_usage,
                  now: Callable[[], dt.datetime] = _utcnow, out: Callable[[str], None] = print,
                  clock: Callable[[], float] = time.monotonic) -> dict:
    """Run the selected steps in order and return the state dict (also in data/live/pullpack/state.json). A step that
    is done with a passed verify is skipped unless named in `redo` ('all' = every step). Each step: preflight (step
    conditions, free disk, host probes; any failing -> 'skipped' with the reason), run (exception -> 'failed' with the
    reason; the record keeps run ids and staged folders so the next run resumes), verify (not passed -> 'failed'),
    finish (may leave the step 'held'). Never raises for a step failure; raises UsageError for unknown step names.
    KeyboardInterrupt marks the step failed ('interrupted'), saves the state and is re-raised."""
    d, opts = Path(data_dir), opts or PackOptions()
    registry = registry if registry is not None else default_steps()
    chosen = _select(steps, registry)
    redo_set = _redo_set(redo, registry)
    if probe is None:
        from .feeds import probe_host
        probe = probe_host
    state = load_state(d, registry)
    state["created_utc"] = state["created_utc"] or _stamp(now())
    state["last_run"] = {"started_utc": _stamp(now()), "steps": [s.id for s in chosen], "redo": sorted(redo_set),
                         "options": asdict(opts)}
    pk = pack_dir(d)
    pk.mkdir(parents=True, exist_ok=True)
    logf = pk / LOG_FILE

    def detail(msg: str) -> None:
        with open(logf, "a", encoding="utf-8") as f:
            f.write(f"{_stamp(now())} {msg}\n")

    probed: dict[str, str | None] = {}

    def unreachable(groups) -> str | None:
        for g in groups:
            reasons = []
            for h in g:
                if h not in probed:
                    probed[h] = probe(h)
                if probed[h] is None:
                    break
                reasons.append(probed[h])
            else:
                if reasons:
                    return "; ".join(reasons)
        return None

    total = len(chosen)
    for i, s in enumerate(chosen, 1):
        prev = state["steps"].get(s.id) or _new_record(s)
        tag = f"[pullpack] {i}/{total} {s.number} {s.id}"
        if _is_done(prev) and s.id not in redo_set:
            out(f"{tag}: already done and verified ({prev.get('finished_utc')}); skipped (--redo {s.id} to run again)")
            continue
        rec = _new_record(s)
        rec["attempts"] = int(prev.get("attempts", 0))
        if s.id not in redo_set:                     # keep what a resume needs (run id, staged folder, fx vintage)
            rec["artifacts"] = dict(prev.get("artifacts") or {})
        ctx = Context(d, opts, rec, {} if s.id in redo_set else prev, s.id in redo_set, detail, out, now)
        t0 = clock()
        rec["started_utc"] = _stamp(now())

        def close(status: str, reason: str = "", rec=rec, t0=t0, s=s, tag=tag) -> None:
            rec["status"], rec["reason"] = status, reason
            rec["finished_utc"] = _stamp(now())
            rec["elapsed_s"] = round(clock() - t0, 1)
            state["steps"][s.id] = rec
            save_state(d, state, now())
            line = f"{tag}: {status} ({_elapsed(rec['elapsed_s'])})" + (f" - {reason}" if reason else "")
            out(line)
            detail(line)

        why = s.preflight(ctx)
        if not why:
            need = int(s.estimate(ctx))
            why = check_disk(s.disk_path(ctx) if s.disk_path else d, need, disk_usage)
            rec["counts"]["disk_estimate_bytes"] = need
        if not why and s.hosts:
            bad = unreachable(s.hosts)
            why = f"unreachable ({bad})" if bad else None
        if not why and s.optional_hosts:                     # EQ-A-0073: reported, never a reason to skip
            for g in s.optional_hosts:
                bad = unreachable((g,))
                if bad:
                    note = f"optional host unreachable ({bad}): its feed is skipped, the step runs without it"
                    rec.setdefault("warnings", []).append(note)
                    out(f"{tag}: {note}")
                    detail(f"{tag}: {note}")
        if why:
            close("skipped", why)
            continue
        rec["status"], rec["attempts"] = "running", rec["attempts"] + 1
        state["steps"][s.id] = rec
        save_state(d, state, now())
        out(f"{tag}: running (expected {s.expected_time}; details in {logf})")
        try:
            early = s.run(ctx)
        except KeyboardInterrupt:
            close("failed", "interrupted (Ctrl-C); rerun to resume")
            raise
        except (Exception, SystemExit) as e:  # noqa: BLE001 - any step failure is recorded, the pack goes on
            detail(traceback.format_exc())
            close("failed", f"{type(e).__name__}: {' '.join(str(e).split())[:400]}")
            continue
        if early:
            close(*early)
            continue
        try:
            rec["verify"] = s.verify(ctx)
        except Exception as e:  # noqa: BLE001
            detail(traceback.format_exc())
            rec["verify"] = _verdict([_check("verify ran", False, f"{type(e).__name__}: {e}")])
        if not rec["verify"].get("passed"):
            failed = [f"{c['name']} ({c['detail']})" for c in rec["verify"].get("checks", []) if c["required"] and not c["ok"]]
            close("failed", "verify failed: " + "; ".join(failed))
            continue
        try:
            fin = s.finish(ctx) if s.finish else None
        except Exception as e:  # noqa: BLE001
            detail(traceback.format_exc())
            close("failed", f"{type(e).__name__}: {' '.join(str(e).split())[:400]}")
            continue
        close(*(fin or ("done", "")))
        if rec.get("checklist"):
            for line in rec["checklist"]:
                out(f"    {line}")
            for line in rec.get("cross_check", [])[:40]:
                out(f"    cross-check: {line}")
    state["last_run"]["finished_utc"] = _stamp(now())
    state["last_run"]["exit_code"] = exit_code(state, [s.id for s in chosen])
    save_state(d, state, now())
    return state


def status(data_dir: str | Path = "data", *, registry: list[Step] | None = None) -> dict:
    """The state (every step pending when the pack never ran). Reads only."""
    return load_state(data_dir, registry)


def _next_actions(state: dict) -> list[str]:
    acts = []
    for sid in state["order"]:
        r = state["steps"][sid]
        if r["status"] == "done" and not r.get("next"):
            continue
        if r["status"] == "pending":
            acts.append(f"{r['number']} {sid}: not run yet: `python -m econquest.ingestion.pullpack run`")
        elif r["status"] == "running":
            acts.append(f"{r['number']} {sid}: was interrupted; rerun `pullpack run` to resume")
        elif r.get("next"):
            acts.append(f"{r['number']} {sid}: {r['next']}")
        elif r["status"] in ("skipped", "failed"):
            acts.append(f"{r['number']} {sid}: {r['reason']}; fix it and rerun `pullpack run`")
    return acts


def build_report(state: dict, now: dt.datetime | None = None) -> dict:
    """The report.json content (REPORT_SCHEMA) from a state dict."""
    from .. import __version__
    steps = []
    for sid in state["order"]:
        r = state["steps"][sid]
        steps.append({k: r.get(k) for k in ("id", "number", "title", "status", "reason", "started_utc", "finished_utc",
                                            "elapsed_s", "attempts", "counts", "vintages", "verify", "held", "next",
                                            "unblocks", "expected_time")}
                     | {"checklist": r.get("checklist", []), "cross_check": r.get("cross_check", []),
                        "artifacts": {k: v for k, v in (r.get("artifacts") or {}).items() if k != "feeds"}
                        | ({"feeds": r["artifacts"]["feeds"]} if (r.get("artifacts") or {}).get("feeds") else {})})
    tickets = {}
    ph_deferred = (state["steps"].get("panel_history", {}).get("artifacts") or {}).get("deferred") or {}
    for t, need in BLOCKED_TICKETS.items():
        st = {s: state["steps"].get(s, {}).get("status", "pending") for s in need}
        waiting = [s for s, v in st.items() if v != "done"]
        if t in PANEL_NEEDS_WEO and isinstance(ph_deferred, dict) and "weo" in ph_deferred:
            waiting.append(f"panel_history WEO deferred ({ph_deferred['weo']})")        # EQ-A-0079
        tickets[t] = {"steps": list(need), "step_status": st, "unblocked": not waiting, "waiting_on": waiting}
    return {"schema": REPORT_SCHEMA, "generated_utc": _stamp(now or _utcnow()), "econquest_version": __version__,
            "exit_code": exit_code(state), "summary": {s: sum(1 for x in steps if x["status"] == s) for s in STATUSES},
            "steps": steps, "blocked_tickets": tickets, "sam_next": _next_actions(state),
            "held": [{"step": x["id"], "reason": x["reason"], "cells": x["held"]} for x in steps
                     if x["status"] == "held" or x["held"]],
            "not_in_pack": {"acled": "off: needs a corporate licence (docs/runbooks/A-event-feeds.md section 3)"},
            "send_back": "data/live/pullpack/report.md and report.json (plus the uploads named in each step's next action)"}


_MD_ESCAPES = (("&", "&amp;"), ("<", "&lt;"), (">", "&gt;"), ("`", "&#96;"), ("|", "&#124;"), ("[", "&#91;"),
               ("]", "&#93;"))


def md_text(v) -> str:
    """SEC-A-009 L5 (EQ-A-0138): one line of inert Markdown from free text that may come from a served page or from
    report.json/state.json (a WEO bot-check head, a Content-Type, a Location, a reason). Whitespace runs, CR and LF
    collapse to one space, so the text cannot open a heading, list item or table row; &, <, >, backtick, | and [ ]
    become HTML entities, so no tag, code span, table cell or link renders in a Markdown preview."""
    t = " ".join(str(v if v is not None else "").split())
    for a, b in _MD_ESCAPES:
        t = t.replace(a, b)
    return t


def _md(rep: dict) -> str:
    e = md_text
    L = ["# Mac pull pack report", "",
         f"Generated {e(rep['generated_utc'])} by econquest {e(rep['econquest_version'])}. Exit code {rep['exit_code']} "
         f"(0 all done, 2 something skipped or held, 1 a failure). Runbook: docs/runbooks/A-mac-pull-pack.md.", "",
         "| Step | Status | Time | Vintages | Reason |", "|---|---|---|---|---|"]
    for s in rep["steps"]:
        v = ", ".join(f"{k} {x}" for k, x in (s["vintages"] or {}).items() if x) or "-"
        L.append(f"| {e(s['number'])} {e(s['id'])} | {e(s['status'])} | {_elapsed(s['elapsed_s'] or 0)} | {e(v)} | "
                 f"{e(s['reason'] or '')} |")
    L += ["", "## Blocked tickets", "", "| Ticket | Waits for | Unblocked |", "|---|---|---|"]
    for t, x in rep["blocked_tickets"].items():
        waits = ", ".join(f"{s} ({x['step_status'][s]})" for s in x["steps"])
        L.append(f"| {e(t)} | {e(waits)} | {'yes' if x['unblocked'] else 'no'} |")
    L += ["", "## What Sam does next", ""] + ([f"- {e(a)}" for a in rep["sam_next"]] or ["- Nothing: every step is done."])
    for s in rep["steps"]:
        L += ["", f"## {e(s['number'])} {e(s['id'])}: {e(s['title'])}", "", f"Status **{e(s['status'])}**"
              + (f": {e(s['reason'])}" if s["reason"] else "") + f". Expected time {e(s['expected_time'])}."
              + (f" Unblocks {e(', '.join(map(str, s['unblocks'])))}." if s["unblocks"] else "")]
        if s["counts"]:
            L += ["", "Counts: " + e("; ".join(f"{k} {json.dumps(v, default=str) if isinstance(v, dict) else v}"
                                               for k, v in s["counts"].items()))]
        checks = (s["verify"] or {}).get("checks", [])
        if checks:
            L += ["", "Verify " + ("passed" if s["verify"].get("passed") else "FAILED") + ":"]
            L += [f"- [{'x' if c['ok'] else ' '}] {e(c['name'])}" + ("" if c["required"] else " (information)")
                  + (f": {e(c['detail'])}" if c["detail"] else "") for c in checks]
        if s["checklist"]:
            L += ["", "Checklist:"] + [f"- {e(c)}" for c in s["checklist"]]
        if s["cross_check"]:
            L += ["", "BIS vs ECB cross-check:"] + [f"- {e(c)}" for c in s["cross_check"]]
        if s["held"]:
            L += ["", f"Held ({len(s['held'])}):"] + [f"- {e(h)}" for h in s["held"][:50]]
            if len(s["held"]) > 50:
                L.append(f"- ... and {len(s['held']) - 50} more (report.json)")
        if s["next"]:
            L += ["", f"Next: {e(s['next'])}"]
    L += ["", "## Not in the pack", "", f"- ACLED: {e(rep['not_in_pack']['acled'])}", "",
          f"Send back: {e(rep['send_back'])}.", ""]
    return "\n".join(L)


def report(data_dir: str | Path = "data", *, registry: list[Step] | None = None,
           now: dt.datetime | None = None) -> dict:
    """Write data/live/pullpack/report.md and report.json from the state; returns {"json": path, "md": path,
    "report": dict, "exit_code": int}."""
    st = load_state(data_dir, registry)
    rep = build_report(st, now)
    pk = pack_dir(data_dir)
    _atomic_write(pk / REPORT_JSON, json.dumps(rep, indent=1, default=str) + "\n")
    _atomic_write(pk / REPORT_MD, _md(rep))
    return {"json": str(pk / REPORT_JSON), "md": str(pk / REPORT_MD), "report": rep, "exit_code": rep["exit_code"]}


# ------------------------------------------------------------------------------------------------ command line

class _Parser(argparse.ArgumentParser):
    def error(self, message):                                 # usage errors exit 1, not argparse's 2 (2 = held)
        self.print_usage(sys.stderr)
        print(f"{self.prog}: error: {message}", file=sys.stderr)
        raise SystemExit(EXIT_FAILED)


def _options(a) -> PackOptions:
    return PackOptions(apply_fx=a.apply_fx, crag_xlsx=a.crag_xlsx,
                       weo_vintages=_vintages(a.weo_vintages) if a.weo_vintages else None,
                       panel_sources=_panel_sources(a.panel_sources),
                       wb_panel_codes=_wb_panel_codes(a.wb_panel_codes),
                       universe_dest=a.universe_dest, ucdp_start=a.ucdp_start, ucdp_end=a.ucdp_end,
                       gdelt_start=a.gdelt_start, gdelt_end=a.gdelt_end, gdelt_days=a.gdelt_days,
                       gdelt_max_days=a.gdelt_max_days, gdelt_allow_http=a.gdelt_allow_http,
                       fx_history_start=a.fx_history_start, fx_history_end=a.fx_history_end,
                       cmo_xlsx=getattr(a, "cmo_xlsx", None), cmo_retrieved=getattr(a, "cmo_retrieved", None))


def _panel_sources(text: str) -> tuple:
    got = [s.strip() for s in str(text or "").split(",") if s.strip()]
    bad = [s for s in got if s not in PANEL_SOURCES_ALL]
    if bad or not got:
        raise UsageError(f"--panel-sources: {bad or 'empty'}; choose from {', '.join(PANEL_SOURCES_ALL)}")
    return tuple(s for s in PANEL_SOURCES_ALL if s in got)


def _wb_panel_codes(text: str | None) -> tuple | None:
    if not text:
        return None
    from .panel_history import wb_panel_request
    try:
        return tuple(wb_panel_request(text.split(","))["wb_codes"])
    except ValueError as e:
        raise UsageError(f"--wb-panel-codes: {e}") from None


def _vintages(text: str) -> list[str]:
    from .panel_history import _parse_vintage_arg
    return _parse_vintage_arg(text)


def main(argv: list[str] | None = None) -> int:
    ap = _Parser(prog="python -m econquest.ingestion.pullpack", description=__doc__.split("\n\n")[0])
    ap.add_argument("command", choices=("plan", "run", "status", "report"))
    ap.add_argument("--data", default="data", help="econquest data folder (default data)")
    ap.add_argument("--steps", help=f"comma list of steps (default all: {','.join(STEP_IDS)})")
    ap.add_argument("--redo", action="append", default=[], metavar="STEP", help="run STEP again although done (or 'all')")
    ap.add_argument("--apply-fx", action="store_true", help="apply the official FX vintage after its verify passes")
    ap.add_argument("--crag-xlsx", help=f"BoC-BoE workbook (default ~/Downloads/{CRAG_FILE})")
    ap.add_argument("--cmo-xlsx", help="step 8: World Bank Pink Sheet CMO-Historical-Data-Monthly.xlsx (default ~/Downloads)")
    ap.add_argument("--cmo-retrieved", help="step 8: when the Pink Sheet file was downloaded (UTC; default its mtime)")
    ap.add_argument("--weo-vintages", help="panel history WEO releases, e.g. 2007-10:2026-10")
    ap.add_argument("--panel-sources", default=",".join(PANEL_SOURCES_DEFAULT),
                    help=f"step 2 sources, comma list of {','.join(PANEL_SOURCES_ALL)} (default "
                         f"{','.join(PANEL_SOURCES_DEFAULT)}: WEO deferred under {PANEL_DEFERRED.get('weo', '-')})")
    ap.add_argument("--wb-panel-codes", help="step 2w World Bank codes, comma list, in place of "
                                             "panel_history.WB_PANEL_CODES (e.g. add RL.EST after the probe served it)")
    ap.add_argument("--universe-dest", help="staged data folder for the 88-country fetch (default ~/econquest-universe-<ts>)")
    ap.add_argument("--ucdp-start", default="2019-01-01")
    ap.add_argument("--ucdp-end")
    ap.add_argument("--gdelt-start", help="first day YYYY-MM-DD (default: --gdelt-days before --gdelt-end)")
    ap.add_argument("--gdelt-end", help="last day YYYY-MM-DD (default yesterday UTC)")
    ap.add_argument("--gdelt-days", type=int, default=7, help="days pulled when --gdelt-start is not given (default 7)")
    ap.add_argument("--gdelt-max-days", type=int, default=366, help="refuse a longer GDELT range (default 366)")
    ap.add_argument("--gdelt-allow-http", action="store_true", help="only if https to data.gdeltproject.org fails")
    ap.add_argument("--fx-history-start", help="fx_history step: first day (default: the EQ-A-0054 builder's)")
    ap.add_argument("--fx-history-end", help="fx_history step: last day (default: the builder's)")
    ap.add_argument("--json", action="store_true", help="plan/status: print JSON")
    a = ap.parse_args(argv)
    d = Path(a.data)
    problem = data_folder_problem(d)                     # EQ-A-0138: names the ~/Downloads release-data/ gotcha
    if problem:
        print(f"error: {problem}", file=sys.stderr)
        return EXIT_FAILED
    steps = [s for s in a.steps.split(",")] if a.steps else None
    try:
        opts = _options(a)
        if a.command == "plan":
            rows = plan(d, opts, steps, a.redo)
            if a.json:
                print(json.dumps(rows, indent=1))
            else:
                for r in rows:
                    print(f"{r['number']:>2} {r['id']:<14} {r['status']:<8} {r['expected_time']:<26} "
                          f"disk {_human(r['estimate_bytes'])} of {_human(r['free_bytes'])} free  -> {r['action']}")
            return EXIT_DONE
        if a.command == "run":
            st = run(d, opts, steps, a.redo)
            r = report(d)
            code = exit_code(st, [s.id for s in _select(steps, default_steps())])
            print(f"[pullpack] exit {code}; report: {r['md']} (send it back with report.json)")
            return code
        if a.command == "status":
            st = status(d)
            if a.json:
                print(json.dumps(st, indent=1, default=str))
            else:
                for sid in st["order"]:
                    x = st["steps"][sid]
                    print(f"{x['number']:>2} {sid:<14} {x['status']:<8} {_elapsed(x.get('elapsed_s') or 0):>7}  "
                          f"{x.get('finished_utc') or '-':<20} {x.get('reason', '')}")
            return exit_code(st, steps)
        r = report(d)
        print(f"wrote {r['md']} and {r['json']}")
        return r["exit_code"]
    except UsageError as e:
        print(f"error: {e}", file=sys.stderr)
        return EXIT_FAILED
    except KeyboardInterrupt:                            # EQ-A-0138: run() already saved the step as 'interrupted'
        print(f"interrupted: the step that was running is recorded as failed (interrupted) in "
              f"{pack_dir(d) / STATE_FILE}; finished steps are kept. Rerun the same command to resume.", file=sys.stderr)
        return EXIT_INTERRUPTED


if __name__ == "__main__":
    raise SystemExit(main())
