"""World Bank additions (EQ-A-0049): transforms for the series added to feeds.WB_SERIES on the existing wbgapi host.

    2.11  export concentration, indicator-rules section 15 (Sam approved 2026-10-25 13:19Z, EQ-A-0102): computed by
          Team B's reference rule validation.research_effect._export_concentration on the five WDI merchandise
          export groups (latest year with all five, WDI year y usable from 30 June y+1). Groups summing to < 75% of
          exports: held (unserved 'held: ...', seed stays); manufactures largest: blank (seed stays); else the
          largest of FUEL / MMTL / FOOD / AGRI. A year more than 3 before the as_of year: held as stale (seed stays).
    7.10  fossil-fuel exports, % of merchandise exports: TX.VAL.FUEL.ZS.UN (revenue variant is manual)
    2.2   external financing need, % of reserves, IMF GEFN convention (a current-account surplus offsets):
          (-CA + short-term external debt + PPG and PNG amortization) / total reserves x 100, every component for the
          same year Y; CA = WEO BCA_NGDPD x NGDPD (US$ bn). Amortization paid in Y is the proxy for the next 12 months.
    6.10  Gini (SI.POV.GINI) is fetched into raw_worldbank.csv only: 6.10 is a 0-4 level whose mapping Team B sets
          (served through research.wiring, EQ-A-0095, with the EPR part).
    7.8   EN.POP.EL5M.ZS is fetched into raw_worldbank.csv only (EQ-A-0095; WB_NOT_SERVED says why).

All codes are WDI / IDS codes from the coverage map (verified=no there): the quality gate holds the cells until the
map is set to verified=yes after a Mac pull. This module imports nothing from feeds at import time (feeds.py imports
it lazily)."""
from __future__ import annotations

import datetime as dt
from collections import Counter

import numpy as np
import pandas as pd

EXPORT_GROUPS = {"TX.VAL.FUEL.ZS.UN": "fuel", "TX.VAL.MMTL.ZS.UN": "ores and metals", "TX.VAL.FOOD.ZS.UN": "food",
                 "TX.VAL.AGRI.ZS.UN": "agricultural raw materials", "TX.VAL.MANF.ZS.UN": "manufactures"}
EFN_WB = ("DT.DOD.DSTC.CD", "DT.AMT.DPPG.CD", "DT.AMT.PNGB.CD", "FI.RES.TOTL.CD")
EFN_WEO = ("BCA_NGDPD", "NGDPD")
GINI = "SI.POV.GINI"
# 2.2 when DT.AMT.PNGB.CD is missing (docs/validation/indicator-rules.md section 14, EQ-B-0103; EQ-A-0100):
# 1. actual PNGB for year t; 2. else an actual PNGB from t-1 or t-2, carried ("PNGB carried from <year>");
# 3. else 0 when IDS has no actual PNG debt stock DT.DOD.DPNG.CD above 0 in t-5..t ("PNGB 0: no PNG debt reported");
# 4. else missing, reason "PNGB missing". t is the latest year every other component has, which is never after the
# last actual DT.DOD.DSTC.CD year, so no projected value enters any branch.
PNGB = "DT.AMT.PNGB.CD"
PNG_STOCK = "DT.DOD.DPNG.CD"           # PNG debt stock: fetched for the rule 3 test only, used nowhere else
PNGB_CARRY_YEARS = 2                   # k = 2, as layer1.missing_input_rule
PNG_STOCK_YEARS = 5                    # t-5..t
EFN_CORE = tuple(c for c in EFN_WB if c != PNGB)
# series each new id is computed from (feeds.WB_SERIES must carry all of them; official.gate staleness). For 2.2 the
# staleness check reads the core components only: PNGB's age is bounded by the section 14 rule (t-2 at most, t never
# after the last DT.DOD.DSTC.CD year), and a rule-3 zero would otherwise be held for an old, unrelated PNGB row.
WB_EXTRA_COMPONENTS = {"2.11": tuple(EXPORT_GROUPS), "7.10": ("TX.VAL.FUEL.ZS.UN",), "2.2": EFN_CORE}
WB_EXTRA_IDS = frozenset(WB_EXTRA_COMPONENTS)
WB_NOT_SERVED = {"6.10": (f"held, research: {GINI} is fetched into raw_worldbank.csv; the 0-4 level (indicator-rules "
                          "sections 3 and 13.4: max of the Gini level and the EPR level) is built by the research feed "
                          "(EQ-A-0095) and held for review until Sam's sign-off at first values"),   # EQ-A-0096
                 # EQ-A-0095: the WDI code exists (api.worldbank.org/v2/indicator/EN.POP.EL5M.ZS, source 2, read
                 # 2026-10-25); its data are UNVERIFIED until a Mac pull, and 7.8 (rulebook: CIESIN LECZ, low-lying
                 # coast) needs Team B to choose 5 m (this series) vs 10 m (LECZ) before any cell is served
                 "7.8": ("EN.POP.EL5M.ZS (WDI, from CIESIN LECZ v3) is fetched into raw_worldbank.csv only: data "
                         "UNVERIFIED until a Mac pull; 5 m vs 10 m for 7.8 is Team B's choice (EQ-A-0095)")}


# ---------------------------------------------------------------------------------------------- IDS counterpart (EQ-A-0068)
# IDS (World Bank source 6) has a counterpart-area (creditor) dimension. A wbgapi call without it returns one row per
# creditor per country-year (DT.DOD.DSTC.CD: several rows for 77 countries on 2026-10-24), and the World total cannot be
# told apart. fetch_ids asks for the World counterpart and keeps only rows that carry it.
IDS_DB = 6
IDS_WORLD_COUNTERPART = "WLD"        # UNVERIFIED: the IDS counterpart-area code of "World"; the Mac pull confirms it


def ids_counterpart_dim(wb, db: int = IDS_DB) -> str | None:
    """The wbgapi dimension id of the IDS counterpart (e.g. 'counterpart_area', as wbgapi names concepts), from
    wb.source.concepts(db); None when it cannot be identified (no such concept, or a wbgapi without source.concepts)."""
    try:
        concepts = wb.source.concepts(db)
    except Exception:  # noqa: BLE001 - unknown: the caller keeps the refusal downstream
        return None
    hits = [k for k in concepts if "counterpart" in str(k).lower()]
    return hits[0] if len(hits) == 1 else None


def fetch_ids(wb, series, economy, *, db: int = IDS_DB, counterpart: str = IDS_WORLD_COUNTERPART,
              **kw) -> tuple[list[dict], list[str]]:
    """wbgapi records of IDS `series` for the World counterpart only -> (records, notes).

    1. counterpart dimension identified: ask for it (`**{dim: counterpart}`); if wbgapi or the API refuses that, ask
       without it. Either way keep only the records whose counterpart is `counterpart`. Records that carry other
       counterparts but none equal to it raise ValueError naming the codes served (so the code can be corrected).
    2. dimension not identified: records are returned as served, with a note; the per-year duplicate refusal in
       _by_year (and WorldBankFeed's duplicate check) then still stops a per-creditor series from being used."""
    dim = ids_counterpart_dim(wb, db)
    notes: list[str] = []
    if dim is None:
        recs = list(wb.data.fetch(series, economy, db=db, **kw))
        dim = next((k for r in recs[:50] for k in r if "counterpart" in str(k).lower()), None)
        if dim is None:
            notes.append(f"IDS {series}: counterpart dimension not identified; rows kept as served (duplicates refused downstream)")
            return recs, notes
    else:
        try:
            recs = list(wb.data.fetch(series, economy, db=db, **kw, **{dim: counterpart}))
        except Exception as e:  # noqa: BLE001 - retried without the dimension, then filtered here
            notes.append(f"IDS {series}: request with {dim}={counterpart} refused ({type(e).__name__}: {str(e)[:100]}); "
                         "filtered after a request without it")
            recs = list(wb.data.fetch(series, economy, db=db, **kw))
    if recs and not any(dim in r for r in recs):
        notes.append(f"IDS {series}: rows carry no {dim} field; kept as served (duplicates refused downstream)")
        return recs, notes
    kept = [r for r in recs if str(r.get(dim, "")) == counterpart]
    if recs and not kept:
        seen = Counter(str(r.get(dim, "")) for r in recs).most_common(8)
        raise ValueError(f"IDS {series}: no row with {dim}={counterpart} among {len(recs)} rows (counterparts served: "
                         f"{', '.join(f'{c} x{n}' for c, n in seen)}); set official.worldbank.IDS_WORLD_COUNTERPART")
    return kept, notes


def _by_year(long: pd.DataFrame | None, iso: str, series: str) -> pd.Series:
    if long is None or not len(long):
        return pd.Series(dtype=float)
    s = long[(long["iso"] == iso) & (long["series"] == series)]
    out = pd.Series(pd.to_numeric(s["value"], errors="coerce").to_numpy(),
                    index=pd.to_numeric(s["period"], errors="coerce").to_numpy())
    out = out[np.isfinite(out.index.to_numpy(dtype=float))].dropna()
    out.index = out.index.astype(int)
    dup = sorted(set(out.index[out.index.duplicated()]))
    if dup:
        # EQ-A-0062: IDS US$ series (DT.TDS.DPPG.CD on the 2026-10-23 pull: up to 35 rows a year) come back one row
        # per creditor; WorldBankFeed drops the counterpart dimension, so the World total cannot be told apart.
        # Refuse rather than keep an arbitrary creditor's row (the old keep="last" did).
        raise ValueError(f"{series} {iso}: {len(dup)} year(s) with more than one row (e.g. {dup[-1]}); "
                         "per-creditor IDS rows without the counterpart dimension")
    return out.sort_index()


def _has_series(df: pd.DataFrame | None, series: str) -> bool:
    return df is not None and not df.empty and bool((df["series"] == series).any())


def pngb_term(pngb: pd.Series, stock: pd.Series, t: int, stock_fetched: bool = True) -> tuple[float | None, str, str]:
    """The PNGB term of 2.2 for year t under indicator-rules section 14 -> (value or None, cell note, reason missing).
    `pngb` and `stock` are one country's DT.AMT.PNGB.CD and DT.DOD.DPNG.CD by year. Only years <= t are read.
    `stock_fetched` False (the pull had no DT.DOD.DPNG.CD row for any economy): rule 3 cannot be shown, so rule 4."""
    if t in pngb.index:
        return float(pngb[t]), "", ""
    for k in range(1, PNGB_CARRY_YEARS + 1):
        if t - k in pngb.index:
            return float(pngb[t - k]), f"PNGB carried from {t - k}", ""
    lo = t - PNG_STOCK_YEARS
    if stock_fetched:
        recent = stock[(stock.index >= lo) & (stock.index <= t)]
        if not (recent > 0).any():
            return 0.0, "PNGB 0: no PNG debt reported", ""
        why = (f"PNGB missing: no actual {PNGB} in {t - PNGB_CARRY_YEARS}..{t} and IDS reports PNG debt "
               f"({PNG_STOCK} > 0 in {lo}..{t})")
    else:
        why = (f"PNGB missing: no actual {PNGB} in {t - PNGB_CARRY_YEARS}..{t}, and {PNG_STOCK} is not in this pull, "
               "so 'no PNG debt' cannot be shown")
    return None, "", why


def export_concentration(wb: pd.DataFrame | None, iso: str, as_of) -> tuple[float | None, str, str]:
    """2.11 under indicator-rules section 15 -> (value or None, series text, reason not served). Delegates to Team B's
    reference `validation.research_effect._export_concentration` (one implementation, so the two cannot drift).
    Only status 'value' yields a value; 'hold' (coverage floor, stale) is a reason starting 'held: ' and 'blank' a
    reason, so the seed stays in both cases."""
    from econquest.rules.research import export_concentration as _export_concentration   # C15 (ADR-A-001)
    frame = None
    if wb is not None and len(wb):
        frame = wb[wb["series"].isin(EXPORT_GROUPS)][["iso", "series", "period", "value"]].copy()
        frame["period"] = pd.to_numeric(frame["period"], errors="coerce")
        frame["value"] = pd.to_numeric(frame["value"], errors="coerce")
        frame = frame.dropna(subset=["period"])
        frame["period"] = frame["period"].astype(int)
    c = _export_concentration(frame, iso, as_of)
    if c["status"] == "value":
        code = f"TX.VAL.{c['reason'].split()[-1]}.ZS.UN"           # reason 'largest SITC commodity group FOOD'
        return (float(c["value"]), f"rule 2.11 WDI v1: largest SITC commodity group {code} "
                f"({EXPORT_GROUPS.get(code, '?')}) in {c['data_year']}, % of merchandise exports; a group is broader "
                f"than one commodity (indicator-rules 15)", "")
    if c["status"] == "hold":
        return None, "", f"held: 2.11 {c['rule']}: {c['reason']} (year {c['data_year']}; seed stays)"
    return None, "", f"2.11: {c['reason']}" + (f" (year {c['data_year']}; seed stays)" if c["data_year"] else "")


def default_as_of(year: int | None, today: dt.date | None = None) -> str:
    """The as_of a pull for `year` reads WDI at: today, capped at 31 December of `year`."""
    today = today or dt.date.today()
    return (min(today, dt.date(int(year), 12, 31)) if year is not None else today).isoformat()


def wb_extra_transforms(wb: pd.DataFrame | None, weo: pd.DataFrame | None, iso: str,
                        year: int | None = None, as_of=None) -> tuple[dict, dict, dict]:
    """({id: value}, {id: series text}, {id: reason not served}) for 2.11, 7.10, 2.2 (and 6.10's reason).
    `as_of` (default: default_as_of(year)) is the point-in-time date of 2.11 (EQ-A-0102)."""
    ind, used, why = {}, {}, dict(WB_NOT_SERVED)
    try:
        groups = {c: _by_year(wb, iso, c) for c in EXPORT_GROUPS}
    except ValueError as e:
        groups = {c: pd.Series(dtype=float) for c in EXPORT_GROUPS}
        why["2.11"] = why["7.10"] = f"refused: {e}"
    if "2.11" not in why:                                       # duplicates refused above; else section 15
        v, text, reason = export_concentration(wb, iso, as_of or default_as_of(year))
        if v is not None:
            ind["2.11"], used["2.11"] = v, text
        else:
            why["2.11"] = reason
    fuel = groups["TX.VAL.FUEL.ZS.UN"]
    if len(fuel):
        ind["7.10"] = float(fuel.iloc[-1])
        used["7.10"] = f"TX.VAL.FUEL.ZS.UN {int(fuel.index[-1])} (% of merchandise exports)"
    else:
        why.setdefault("7.10", "no TX.VAL.FUEL.ZS.UN value")
    try:
        comp = {c: _by_year(wb, iso, c) for c in EFN_CORE}
        comp.update({c: _by_year(weo, iso, c) for c in EFN_WEO})
        pngb, stock = _by_year(wb, iso, PNGB), _by_year(wb, iso, PNG_STOCK)
    except ValueError as e:
        why["2.2"] = f"refused: {e}"
        for k in ind:
            why.pop(k, None)
        return ind, used, why
    years = set.intersection(*(set(s.index) for s in comp.values()))
    if year is not None:
        years = {y for y in years if y <= year}
    if years:
        y = max(years)
        res = comp["FI.RES.TOTL.CD"][y]
        png, png_note, png_why = pngb_term(pngb, stock, y, stock_fetched=_has_series(wb, PNG_STOCK))
        if png is None:
            why["2.2"] = png_why
        elif res > 0:
            ca_usd = comp["BCA_NGDPD"][y] / 100 * comp["NGDPD"][y] * 1e9
            need = -ca_usd + comp["DT.DOD.DSTC.CD"][y] + comp["DT.AMT.DPPG.CD"][y] + png
            ind["2.2"] = float(need / res * 100)
            used["2.2"] = (f"(-WEO BCA_NGDPD x NGDPD + IDS DT.DOD.DSTC.CD + DT.AMT.DPPG.CD + DT.AMT.PNGB.CD) / "
                           f"WDI FI.RES.TOTL.CD x 100, all {y} (amortization paid in {y} as next-12m proxy)"
                           + (f"; {png_note}" if png_note else ""))
        else:
            why["2.2"] = f"FI.RES.TOTL.CD not positive in {y}"
    else:
        lacking = [c for c, s in comp.items() if not len(s)]
        why["2.2"] = ("no year with every component" + (f" (none for {', '.join(lacking)})" if lacking else "")
                      + "; IDS covers low- and middle-income economies only")
    for k in ind:
        why.pop(k, None)
    return ind, used, why
