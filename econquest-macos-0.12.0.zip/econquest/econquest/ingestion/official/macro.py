"""Macro inputs (EQ-A-0134, PI-13): BIS effective exchange rates, World Bank Pink Sheet commodity prices and an
export-share commodity terms-of-trade index for each desk name. These are research inputs. They fill no desk cell and
write no Inputs row, no indicators.csv value and nothing in data/mvp. Team B has no level rule for REER misalignment
beyond 2.12 or for terms of trade, so any new cell waits for the Team B handoff under EQ-A-0134.

Sources
    eer          BIS effective exchange rates, dataflow WS_EER, monthly, through the existing feeds.BisFeed client
                 (EER_FLOWS: real and nominal, broad and narrow baskets). Key layout FREQ.EER_TYPE.EER_BASKET.REF_AREA.
                 Real broad (M.R.B) is the 2.12 series and is confirmed by the recorded responses in
                 data/live/vintages/*/raw_bis.csv. The other three keys (M.N.B, M.R.N, M.N.N) are UNVERIFIED: they were
                 written from the BIS key layout and no live response has confirmed them. The narrow basket covers
                 about 27 economies, so most desk names are expected to have no narrow series.
    commodities  World Bank Commodity Price Data (the Pink Sheet), CMO-Historical-Data-Monthly.xlsx: sheets "Monthly
                 Prices" and "Monthly Indices", periods written 'YYYYMmm'. The layout is UNVERIFIED: it was written from
                 the publisher's file as remembered, and no copy of the file has been read here. read_cmo_workbook
                 refuses a sheet whose layout it cannot find, and CMO_VERIFIED holds every value until a real file has
                 been parsed on the Mac. Preferred over IMF PCPS because IMF data is internal only (EXC-003).
    shares       WDI merchandise export structure TX.VAL.{FUEL,FOOD,AGRI,MMTL,MANF}.ZS.UN (% of merchandise exports;
                 UN Comtrade via WITS), as already recorded: team/inbox/pull-20261025T013150Z/raw_worldbank.csv for all
                 18 desk names, or any data/live vintage whose raw_worldbank.csv holds those series.

Terms-of-trade index (tot_index). A fixed-weight, export-side commodity price index:
    idx_t = 100 * exp( sum_g  w_g * ln( P_g,t / mean(P_g, base year) ) ),   w_g = share_g / 100
with g in TOT_GROUPS (fuel -> Energy, food -> Food, agricultural raw materials -> Raw Materials, ores and metals ->
Metals & Minerals), shares from the latest year that has all four groups, and P the Pink Sheet group index in nominal
US dollars. The manufactures and other share is held at a constant price. There is no import side, because no import
shares are on disk, and there is no deflator. This is a method choice that Team B owns (METHOD_APPROVED is empty, so
`method` holds every value).

Point in time. Every input carries the time it was retrieved. An input retrieved after `as_of` is never read, and an
observation whose period ends after `as_of` is dropped. A date-only retrieval stamp counts as the end of that day.

Gate (macro_gate). This reuses official.gate (OFFICIAL_STALE_DAYS, the period parsing in gate._age, the World Bank
stale-years rule) and gives every value a status. Values are `ok` only when no check holds them. Checks are
crosscheck.CHECK_COLUMNS rows with table "Macro":
    unverified  the series code or file layout is not confirmed by a recorded response (EER_VERIFIED, CMO_VERIFIED)
    range       the value is outside MACRO_RANGES (per value; the series row counts them)
    stale       the last observation is older than OFFICIAL_STALE_DAYS for its frequency, or the share year is more than
                `stale_years` before the as-of year
    method      tot: Team B has not approved the index (METHOD_APPROVED)
    pit         an input was retrieved after as_of, so it is not used (recorded so the gap is visible)

The live pull is parked as pull-pack step 8 `macro` (pullpack.py), which runs on Sam's Mac. Outputs go to
data/live/macro/vintages/<id>/ (MACRO_DIR). The pull-pack step writes them there. Nothing in this cloud writes them.

    python -m econquest.ingestion.official.macro build --data data --as-of 2026-10-26 --out <dir> [--cmo-xlsx F] [--shares F]
    python -m econquest.ingestion.official.macro verify <vintage dir>
Runbook: docs/runbooks/A-macro-inputs.md.
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import json
import math
import os
import re
import sys
import tempfile
from pathlib import Path

import numpy as np
import pandas as pd

from .. import feeds as F

TICKET = "EQ-A-0134"
MACRO_FEED = "macro"
MACRO_DIR = Path("live") / "macro"                    # under data_dir; vintages/<id>/ (pull-pack step 8 only)
ROOT = Path(__file__).resolve().parents[3]

# ------------------------------------------------------------------------------------------------ BIS WS_EER
EER_FLOWS = {
    "EER_REAL_BROAD": F.BIS_FLOWS["EER_REAL_BROAD"],  # ("WS_EER", "M.R.B.{iso2}"): the 2.12 series, same key
    "EER_NOMINAL_BROAD": ("WS_EER", "M.N.B.{iso2}"),  # UNVERIFIED
    "EER_REAL_NARROW": ("WS_EER", "M.R.N.{iso2}"),    # UNVERIFIED
    "EER_NOMINAL_NARROW": ("WS_EER", "M.N.N.{iso2}"),  # UNVERIFIED
}
EER_VERIFIED = frozenset({"EER_REAL_BROAD"})          # confirmed by data/live/vintages/*/raw_bis.csv (recorded)
EER_SOURCE = "BIS SDMX REST WS_EER (stats.bis.org)"

# ------------------------------------------------------------------------------------------------ Pink Sheet (CMO)
CMO_FILE = "CMO-Historical-Data-Monthly.xlsx"
# UNVERIFIED: the World Bank's download link as remembered (the document id in the path changes between releases).
# The pull pack never fetches it. Sam downloads the file from the commodity-markets page.
CMO_PAGE = "https://www.worldbank.org/en/research/commodity-markets"
CMO_URL = ("https://thedocs.worldbank.org/en/doc/5d903e848db1d1b83e0ec8f744e55570-0350012021/related/"
           "CMO-Historical-Data-Monthly.xlsx")
CMO_INDEX_SHEET, CMO_PRICE_SHEET = "Monthly Indices", "Monthly Prices"
CMO_VERIFIED = False                                  # set True only after a real file has been parsed (runbook)
CMO_SOURCE = "World Bank Pink Sheet (Commodity Price Data, CMO-Historical-Data-Monthly.xlsx)"
CMO_LICENCE = ("World Bank Pink Sheet: terms not read (UNVERIFIED); internal research only until read "
               "[official.macro.CMO_LICENCE]")
CMO_PERIOD_RE = re.compile(r"^\s*(\d{4})\s*M\s*(\d{1,2})\s*$")
CMO_MISSING = {"", "..", "...", "…", "n.a.", "na", "-", "–"}
CMO_MAX_ROWS = 5000                                   # 1960M01 to today is under 900 rows

# ------------------------------------------------------------------------------------------------ export shares
SHARE_SERIES = ("TX.VAL.FUEL.ZS.UN", "TX.VAL.FOOD.ZS.UN", "TX.VAL.AGRI.ZS.UN", "TX.VAL.MMTL.ZS.UN", "TX.VAL.MANF.ZS.UN")
TOT_GROUPS = {                                        # WDI share -> Pink Sheet "Monthly Indices" column (normalised)
    "TX.VAL.FUEL.ZS.UN": "energy",
    "TX.VAL.FOOD.ZS.UN": "food",
    "TX.VAL.AGRI.ZS.UN": "raw materials",
    "TX.VAL.MMTL.ZS.UN": "metals & minerals",
}
RECORDED_SHARES = Path("team") / "inbox" / "pull-20261025T013150Z" / "raw_worldbank.csv"   # under ROOT
TOT_SERIES = "TOT_COMMODITY_EXPORT"
TOT_TAG = "[macro_tot]"                               # in the series text, matched by the macro_tot_derived licence row
TOT_SOURCE = "econquest macro tot (official.macro, EQ-A-0134)"
TOT_BASE_YEAR = 2010
METHOD_APPROVED: frozenset = frozenset()              # Team B (handoff under EQ-A-0134)

# eer: index 2020=100; the recorded ARG real broad series reaches 500 in 1999, so the bound is wide (plausibility only)
MACRO_RANGES = {"eer": (5.0, 2000.0), "cmo_index": (1.0, 2000.0), "cmo_price": (1e-6, 1e6), "share": (0.0, 100.0),
                "tot": (1.0, 2000.0)}
STALE_YEARS = 3
VALUE_COLUMNS = ["kind", "iso", "series", "period", "value", "unit", "source", "vintage", "retrieved_utc", "status",
                 "reason"]
FILES = ("values.csv", "weights.csv", "checks.csv")


class MacroError(ValueError):
    """An input could not be read in the documented layout (refused, never guessed)."""


# ------------------------------------------------------------------------------------------------ point in time

def _ts(s) -> pd.Timestamp | None:
    """A retrieval stamp as UTC. A date-only stamp is the end of that day, because the retrieval time within the day
    is unknown."""
    s = str(s or "").strip()
    if not s:
        return None
    try:
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", s):
            return pd.Timestamp(s, tz="UTC") + pd.Timedelta(days=1) - pd.Timedelta(seconds=1)
        t = pd.Timestamp(s)
    except ValueError:
        return None
    return t.tz_localize("UTC") if t.tzinfo is None else t.tz_convert("UTC")


def _as_of_ts(as_of) -> pd.Timestamp:
    t = _ts(as_of if not isinstance(as_of, (dt.date, dt.datetime)) else as_of.isoformat())
    if t is None:
        raise MacroError(f"as_of not readable: {as_of!r}")
    return t


def usable(retrieved_utc, as_of) -> bool:
    """True when an input retrieved at `retrieved_utc` may be read at `as_of` (never a later document)."""
    r = _ts(retrieved_utc)
    return r is not None and r <= _as_of_ts(as_of)


def period_end(period) -> dt.date | None:
    """Last day of 'YYYY-MM', 'YYYY-Qn', 'YYYY-MM-DD' (feeds._period_end) or 'YYYY' (31 December)."""
    s = str(period).strip()
    if re.fullmatch(r"\d{4}", s):
        return dt.date(int(s), 12, 31)
    e = F._period_end(s)
    return e[0] if e else None


def drop_future_periods(df: pd.DataFrame, as_of) -> pd.DataFrame:
    """Rows whose period ends on or before the as-of date (a value for a month not yet over is never served)."""
    if df is None or not len(df):
        return df
    cut = _as_of_ts(as_of).date()
    ends = df["period"].map(period_end)
    return df[ends.notna() & (ends.map(lambda e: e is not None and e <= cut))].reset_index(drop=True)


# ------------------------------------------------------------------------------------------------ inputs

def desk_iso2(data_dir) -> dict[str, str]:
    """ISO3 -> ISO2 of the desk names in data_dir/countries.csv."""
    c = pd.read_csv(Path(data_dir) / "countries.csv", dtype=str, keep_default_na=False)
    return {r.iso: r.iso2 for r in c.itertuples(index=False) if r.iso and r.iso2}


def fetch_eer(iso2s: dict[str, str], feed: F.BisFeed | None = None) -> pd.DataFrame:
    """Live WS_EER pull through the existing BIS client (feeds.BisFeed.fetch with EER_FLOWS). Mac only: this cloud
    cannot reach stats.bis.org. Raises feeds.FeedError (FeedUnreachable) as BisFeed does."""
    out = (feed or F.BisFeed()).fetch(iso2s, flows=EER_FLOWS)
    out["source"] = EER_SOURCE
    return out


def recorded_vintage_rows(data_dir, as_of, file: str, series) -> tuple[pd.DataFrame, dict]:
    """Rows of `series` from `file` (e.g. raw_bis.csv) in the newest recorded vintage (data_dir/live/vintages/index.csv)
    retrieved on or before as_of whose file holds any of them. Vintages retrieved after as_of are never read (point in
    time). Returns (LONG_COLUMNS frame, {vintage, retrieved_utc, path}); empty with a note when none. Shared by
    recorded_eer and the pull-pack step 8 share search (pullpack._macro_shares)."""
    d = Path(data_dir) / "live" / "vintages"
    empty = pd.DataFrame(columns=F.LONG_COLUMNS)
    try:
        idx = pd.read_csv(d / "index.csv", dtype=str, keep_default_na=False)
    except (OSError, ValueError):
        return empty, {"note": "no vintage index"}
    idx = idx[[usable(r, as_of) for r in idx["retrieved_utc"]]]
    want = set(series)
    for r in idx.assign(_t=idx["retrieved_utc"].map(_ts)).sort_values("_t", ascending=False).itertuples(index=False):
        p = d / r.vintage_id / file
        if not p.is_file():
            continue
        raw = F.read_csv_keep_na_code(p, dtype={"period": str})
        raw = raw[raw["series"].isin(want)].copy()
        raw["value"] = pd.to_numeric(raw["value"], errors="coerce")
        raw = raw.dropna(subset=["value"])
        if len(raw):
            return raw[F.LONG_COLUMNS].reset_index(drop=True), {"vintage": r.vintage_id, "retrieved_utc": r.retrieved_utc,
                                                                "path": str(p)}
    return empty, {"note": f"no vintage retrieved on or before {as_of} holds {file} rows of {', '.join(sorted(want))[:120]}"}


def recorded_eer(data_dir, as_of) -> tuple[pd.DataFrame, dict]:
    """EER rows from the newest recorded vintage retrieved on or before as_of whose raw_bis.csv holds an EER series."""
    return recorded_vintage_rows(data_dir, as_of, "raw_bis.csv", EER_FLOWS)


def recorded_shares(path=None, as_of=None) -> tuple[pd.DataFrame, dict]:
    """WDI TX.VAL export shares from a recorded raw_worldbank.csv (default RECORDED_SHARES). The retrieval time is the
    `generated_utc` of the pull report next to it (report.json), the time the pull finished, which is the later and so
    the safer bound. Without a readable time the file is refused (never treated as point in time)."""
    p = Path(path) if path else ROOT / RECORDED_SHARES
    if not p.is_file():
        return pd.DataFrame(columns=F.LONG_COLUMNS), {"note": f"{p} not found"}
    rep = p.parent / "report.json"
    try:
        retrieved = json.loads(rep.read_text(encoding="utf-8")).get("generated_utc", "")
    except (OSError, ValueError):
        retrieved = ""
    if not _ts(retrieved):
        raise MacroError(f"{p}: no retrieval time (report.json generated_utc) next to it; not point in time")
    if as_of is not None and not usable(retrieved, as_of):
        return pd.DataFrame(columns=F.LONG_COLUMNS), {"note": f"retrieved {retrieved}, after as_of {as_of}",
                                                      "pit_refused": str(p)}
    raw = pd.read_csv(p, dtype={"period": str}, keep_default_na=False)
    raw = raw[raw["series"].isin(SHARE_SERIES)].copy()
    raw["value"] = pd.to_numeric(raw["value"], errors="coerce")
    return raw.dropna(subset=["value"])[F.LONG_COLUMNS].reset_index(drop=True), {"path": str(p), "retrieved_utc": retrieved}


def _norm_label(s) -> str:
    """'Metals & Minerals **' -> 'metals & minerals'; footnote markers and spacing dropped."""
    s = re.sub(r"[*†‡]+|\(\d+\)|\s+\d+$", " ", str(s or ""))
    return " ".join(s.split()).strip().lower()


def _cell(v) -> float:
    if v is None:
        return float("nan")
    if isinstance(v, (int, float)) and not isinstance(v, bool):
        return float(v)
    s = str(v).strip()
    if s.lower() in CMO_MISSING:
        return float("nan")
    try:
        return float(s.replace(",", ""))
    except ValueError:
        return float("nan")


def parse_cmo_rows(rows: list[tuple], sheet: str) -> pd.DataFrame:
    """One Pink Sheet sheet (rows of cell values) -> long rows: series (normalised label), period 'YYYY-MM', value,
    unit. The header is the last row above the first 'YYYYMmm' row with text labels that is not a units row (cells
    '($/bbl)'). Raises MacroError when no period row or no header is found."""
    first = next((i for i, r in enumerate(rows) if r and CMO_PERIOD_RE.match(str(r[0] or ""))), None)
    if first is None:
        raise MacroError(f"{sheet}: no 'YYYYMmm' period row (layout UNVERIFIED; see docs/runbooks/A-macro-inputs.md)")
    header, units = None, None
    for r in reversed(rows[:first]):
        texts = [str(c).strip() for c in r[1:] if c is not None and str(c).strip()]
        if not texts:
            continue
        if all(t.startswith("(") for t in texts):
            units = units or r
            continue
        header = r
        break
    if header is None:
        raise MacroError(f"{sheet}: no header row above the first period row")
    from ..research.base import safe_text            # SEC-A-015 M-L1: header text from the file goes to values.csv
    labels = [safe_text(_norm_label(c)) if _norm_label(c) else "" for c in header]
    unit_of = [safe_text(str(units[j]).strip()) if units is not None and j < len(units) and units[j] is not None
               else "" for j in range(len(labels))]
    out = []
    for r in rows[first:first + CMO_MAX_ROWS]:
        m = CMO_PERIOD_RE.match(str(r[0] or "")) if r else None
        if not m:
            continue
        y, mo = int(m[1]), int(m[2])
        if not 1 <= mo <= 12:
            continue
        for j in range(1, min(len(r), len(labels))):
            if not labels[j]:
                continue
            v = _cell(r[j])
            if math.isfinite(v):
                out.append({"series": labels[j], "period": f"{y:04d}-{mo:02d}", "value": v, "unit": unit_of[j]})
    if not out:
        raise MacroError(f"{sheet}: header found but no numeric values")
    return pd.DataFrame(out)


def read_cmo_workbook(path) -> dict[str, pd.DataFrame]:
    """{'cmo_index': ..., 'cmo_price': ...} from CMO-Historical-Data-Monthly.xlsx. Zip budget checked first
    (safe_zip, SEC-A-010); openpyxl read-only, values only (defusedxml is installed, so entity expansion is off)."""
    import openpyxl

    from ..safe_zip import check_zip_file
    p = Path(path)
    check_zip_file(p)
    wb = openpyxl.load_workbook(p, read_only=True, data_only=True)
    try:
        out = {}
        for kind, sheet in (("cmo_index", CMO_INDEX_SHEET), ("cmo_price", CMO_PRICE_SHEET)):
            if sheet not in wb.sheetnames:
                raise MacroError(f"{p.name}: sheet {sheet!r} not found (sheets: {', '.join(wb.sheetnames[:10])})")
            rows = [tuple(r) for r in wb[sheet].iter_rows(max_row=CMO_MAX_ROWS + 50, values_only=True)]
            out[kind] = parse_cmo_rows(rows, sheet)
        return out
    finally:
        wb.close()


def _sha(p: Path) -> str:
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for b in iter(lambda: f.read(1 << 20), b""):
            h.update(b)
    return h.hexdigest()


def cmo_input(path, retrieved_utc: str | None = None) -> tuple[dict[str, pd.DataFrame], dict]:
    """The Pink Sheet file with its provenance. `retrieved_utc` is when Sam downloaded it. Without one, the file's
    modification time (UTC) is used and recorded as such."""
    p = Path(path)
    got = read_cmo_workbook(p)
    when = retrieved_utc or dt.datetime.fromtimestamp(p.stat().st_mtime, dt.timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    return got, {"path": str(p), "sha256": _sha(p), "retrieved_utc": when,
                 "retrieved_basis": "given" if retrieved_utc else "file modification time"}


# ------------------------------------------------------------------------------------------------ transforms

def export_weights(shares: pd.DataFrame, iso: str, as_of_year: int | None = None) -> tuple[dict[str, float], int | None]:
    """Commodity export weights (share / 100) for TOT_GROUPS from the latest year (<= as_of_year) that has all four;
    ({}, None) when no year has them."""
    s = shares[shares["iso"] == iso]
    if not len(s):
        return {}, None
    s = s.assign(y=pd.to_numeric(s["period"], errors="coerce")).dropna(subset=["y"])
    if as_of_year is not None:
        s = s[s["y"] <= as_of_year]
    for y in sorted(s["y"].unique(), reverse=True):
        row = s[s["y"] == y].set_index("series")["value"]
        if all(g in row.index and np.isfinite(row[g]) for g in TOT_GROUPS):
            return {g: float(row[g]) / 100.0 for g in TOT_GROUPS}, int(y)
    return {}, None


def tot_index(cmo_index: pd.DataFrame, weights: dict[str, float], base_year: int = TOT_BASE_YEAR) -> pd.DataFrame:
    """Monthly export-side commodity price index (module docstring) -> period, value. Months missing any group
    index are left out; empty when a group has no base-year observation."""
    if not weights or cmo_index is None or not len(cmo_index):
        return pd.DataFrame(columns=["period", "value"])
    wide = cmo_index.pivot_table(index="period", columns="series", values="value", aggfunc="last")
    cols = {g: TOT_GROUPS[g] for g in weights}
    if any(c not in wide.columns for c in cols.values()):
        return pd.DataFrame(columns=["period", "value"])
    base = wide[wide.index.str.startswith(f"{base_year}-")]
    logs = []
    for g, c in cols.items():
        b = base[c].mean()
        if not (np.isfinite(b) and b > 0):
            return pd.DataFrame(columns=["period", "value"])
        logs.append(weights[g] * np.log(wide[c] / b))
    idx = 100.0 * np.exp(pd.concat(logs, axis=1).sum(axis=1, min_count=len(logs)))
    idx = idx.dropna()
    return pd.DataFrame({"period": idx.index.astype(str), "value": idx.to_numpy(dtype=float)})


# ------------------------------------------------------------------------------------------------ gate

def _check(key, iso, check, status, reason, live, basis) -> dict:
    return {"table": "Macro", "key": key, "country": iso, "check": check, "status": status, "reason": reason,
            "live": live, "basis": basis}


def macro_gate(values: pd.DataFrame, as_of, stale_years: int = STALE_YEARS) -> tuple[pd.DataFrame, pd.DataFrame]:
    """Gate every value (module docstring). Returns (values with status/reason, CHECK_COLUMNS rows). A series is
    checked once for unverified / stale / method; range is checked per value. A value is `ok` only when neither its
    series nor the value itself is held."""
    from ..crosscheck import CHECK_COLUMNS
    from .gate import OFFICIAL_STALE_DAYS, _age
    ref = _as_of_ts(as_of).date()
    v = values.copy()
    v["status"], v["reason"] = "ok", ""
    rows = []
    for (kind, series, iso), g in v.groupby(["kind", "series", "iso"], sort=True):
        ends = [period_end(x) or dt.date.min for x in g["period"]]
        latest = g.iloc[max(range(len(ends)), key=ends.__getitem__)]
        basis = f"{kind} {series} {latest['period']}"
        holds = []
        if kind == "eer" and series not in EER_VERIFIED:
            holds.append(("unverified", f"BIS {EER_FLOWS.get(series, ('WS_EER', '?'))[1]} not confirmed by a "
                                        f"recorded response (EER_VERIFIED)"))
        if kind in ("cmo_index", "cmo_price", "tot") and not CMO_VERIFIED:
            holds.append(("unverified", "Pink Sheet layout not confirmed on a real file (CMO_VERIFIED)"))
        if kind == "tot" and TOT_SERIES not in METHOD_APPROVED:
            holds.append(("method", "export-side commodity ToT index not approved by Team B (METHOD_APPROVED)"))
        if kind == "share":
            last = int(str(latest["period"])[:4])
            if last < ref.year - stale_years:
                holds.append(("stale", f"World Bank {series} latest period {last} (limit {stale_years} years before "
                                       f"{ref.year})"))
        else:
            a = _age(g.assign(iso=iso, series=series), iso, series, ref)
            if a is not None:
                age, last, freq = a
                limit = OFFICIAL_STALE_DAYS.get(freq, 275)
                if age > limit:
                    holds.append(("stale", f"{series} last observation {last}, {age} days before {ref} (limit {limit} days)"))
        lo, hi = MACRO_RANGES[kind]
        bad = ~g["value"].between(lo, hi)
        if bad.any():
            first = g[bad].iloc[0]
            holds.append(("range", f"{int(bad.sum())} value(s) outside [{lo:g}, {hi:g}], first {first['period']} "
                                   f"{first['value']:.4g}"))
            v.loc[g[bad].index, ["status", "reason"]] = ["hold", f"range: outside [{lo:g}, {hi:g}]"]
        for check, why in holds:
            rows.append(_check(series, iso, check, "hold", why, float(latest["value"]), basis))
        series_holds = [f"{c}: {w}" for c, w in holds if c != "range"]
        if series_holds:
            ok = g.index[v.loc[g.index, "status"] == "ok"]
            v.loc[ok, ["status", "reason"]] = ["hold", "; ".join(series_holds)]
        if not holds:
            rows.append(_check(series, iso, "gate", "ok", "", float(latest["value"]), basis))
    return v, pd.DataFrame(rows, columns=CHECK_COLUMNS)


# ------------------------------------------------------------------------------------------------ build

def _frame(df, kind, source, vintage, retrieved, unit="") -> pd.DataFrame:
    if df is None or not len(df):
        return pd.DataFrame(columns=VALUE_COLUMNS[:-2])
    out = pd.DataFrame({"kind": kind, "iso": df["iso"] if "iso" in df.columns else "", "series": df["series"],
                        "period": df["period"].astype(str), "value": pd.to_numeric(df["value"], errors="coerce"),
                        "unit": df["unit"] if "unit" in df.columns else unit, "source": source, "vintage": vintage,
                        "retrieved_utc": retrieved})
    return out.dropna(subset=["value"])


def build(data_dir, as_of, *, eer: tuple[pd.DataFrame, dict] | None = None,
          cmo: tuple[dict, dict] | None = None, shares: tuple[pd.DataFrame, dict] | None = None,
          isos: list[str] | None = None, stale_years: int = STALE_YEARS) -> dict:
    """Gate and assemble the macro inputs at `as_of`. Each input is (data, provenance with retrieved_utc). Inputs not
    passed are read from what is recorded: EER from data_dir/live/vintages (recorded_eer), shares from RECORDED_SHARES.
    Pink Sheet prices exist only when a file is passed (none is recorded). Returns {"values", "weights", "checks",
    "provenance"}. Writes nothing."""
    isos = isos or list(desk_iso2(data_dir))
    prov: dict = {"as_of": str(as_of), "ticket": TICKET, "desk_names": len(isos), "inputs": {}}
    pit_rows = []
    frames = []

    e, ep = eer if eer is not None else recorded_eer(data_dir, as_of)
    if e is not None and len(e) and eer is not None and not usable(ep.get("retrieved_utc"), as_of):
        pit_rows.append(("eer", f"retrieved {ep.get('retrieved_utc')}, after as_of")); e = None
    if e is not None and len(e):
        e = drop_future_periods(e[e["iso"].isin(isos) & e["series"].isin(EER_FLOWS)], as_of)
        frames.append(_frame(e, "eer", EER_SOURCE, ep.get("vintage", ""), ep.get("retrieved_utc", ""), "index"))
    prov["inputs"]["eer"] = ep

    cmo_idx = None
    if cmo is not None:
        got, cp = cmo
        prov["inputs"]["commodities"] = cp
        if usable(cp.get("retrieved_utc"), as_of):
            for kind in ("cmo_index", "cmo_price"):
                x = drop_future_periods(got.get(kind), as_of)
                if x is not None and len(x):
                    frames.append(_frame(x.assign(iso="WLD"), kind, CMO_SOURCE, cp.get("sha256", "")[:16],
                                         cp.get("retrieved_utc", "")))
                    if kind == "cmo_index":
                        cmo_idx = x
        else:
            pit_rows.append(("commodities", f"retrieved {cp.get('retrieved_utc')}, after as_of"))
    else:
        prov["inputs"]["commodities"] = {"note": "no Pink Sheet file recorded; parked for pull-pack step 8"}

    s, sp = shares if shares is not None else recorded_shares(None, as_of)
    if s is not None and len(s) and shares is not None and not usable(sp.get("retrieved_utc"), as_of):
        pit_rows.append(("shares", f"retrieved {sp.get('retrieved_utc')}, after as_of")); s = None
    if sp.get("pit_refused"):
        pit_rows.append(("shares", sp["note"]))
    weights = []
    if s is not None and len(s):
        s = drop_future_periods(s[s["iso"].isin(isos)], as_of)
        frames.append(_frame(s, "share", "wbgapi World Bank API v2 (WDI, UN Comtrade via WITS)",
                             Path(sp.get("path", "")).parent.name, sp.get("retrieved_utc", ""), "% of merchandise exports"))
        for iso in isos:
            w, year = export_weights(s, iso, _as_of_ts(as_of).year)
            if not w:
                continue
            weights.append({"iso": iso, "share_year": year, **{TOT_GROUPS[g]: round(x, 6) for g, x in w.items()},
                            "commodity_weight": round(sum(w.values()), 6)})
            t = tot_index(cmo_idx, w) if cmo_idx is not None else None
            if t is not None and len(t):
                frames.append(_frame(t.assign(iso=iso, series=TOT_SERIES), "tot", TOT_SOURCE,
                                     f"shares {year}", prov["inputs"]["commodities"].get("retrieved_utc", ""),
                                     f"index {TOT_BASE_YEAR}=100 {TOT_TAG}"))
    prov["inputs"]["shares"] = sp

    values = pd.concat([f for f in frames if len(f)], ignore_index=True) if any(len(f) for f in frames) \
        else pd.DataFrame(columns=VALUE_COLUMNS[:-2])
    if len(values):
        values, checks = macro_gate(values, as_of, stale_years)
    else:
        from ..crosscheck import CHECK_COLUMNS
        values = values.assign(status=pd.Series(dtype=str), reason=pd.Series(dtype=str))
        checks = pd.DataFrame(columns=CHECK_COLUMNS)
    if pit_rows:
        checks = pd.concat([checks, pd.DataFrame([_check(k, "", "pit", "hold", why, float("nan"), "point in time")
                                                  for k, why in pit_rows])], ignore_index=True)
    values = values[VALUE_COLUMNS].sort_values(["kind", "series", "iso", "period"]).reset_index(drop=True)
    prov["counts"] = {"values": int(len(values)), "ok": int((values["status"] == "ok").sum()),
                      "held": int((values["status"] == "hold").sum()),
                      **{f"{k}_series": int(values.loc[values["kind"] == k, ["series", "iso"]].drop_duplicates().shape[0])
                         for k in ("eer", "cmo_index", "cmo_price", "share", "tot")},
                      "weights": len(weights), "pit_refused": len(pit_rows)}
    return {"values": values, "weights": pd.DataFrame(weights), "checks": checks, "provenance": prov}


# ------------------------------------------------------------------------------------------------ vintages

def write_vintage(out_root, result: dict, now: dt.datetime | None = None) -> Path:
    """out_root/vintages/<UTC stamp>-<sha8>/ with values.csv, weights.csv, checks.csv and manifest.json (sha256 of each
    file and the provenance), written to a temporary folder and renamed, then a row in out_root/vintages/index.csv."""
    now = now or dt.datetime.now(dt.timezone.utc)
    base = Path(out_root) / "vintages"
    base.mkdir(parents=True, exist_ok=True)
    tmp = Path(tempfile.mkdtemp(prefix=".macro-", dir=base))
    shas = {}
    for name, key in zip(FILES, ("values", "weights", "checks")):
        result[key].to_csv(tmp / name, index=False)
        shas[name] = _sha(tmp / name)
    digest = hashlib.sha256("".join(shas[n] for n in FILES).encode()).hexdigest()
    vid = f"{now.strftime('%Y-%m-%dT%H%M%SZ')}-{digest[:8]}"
    manifest = {"vintage_id": vid, "created_utc": now.strftime("%Y-%m-%dT%H:%M:%SZ"), "ticket": TICKET,
                "files": shas, "provenance": result["provenance"]}
    (tmp / "manifest.json").write_text(json.dumps(manifest, indent=1, sort_keys=True, default=str) + "\n", encoding="utf-8")
    dest = base / vid
    if dest.exists():
        raise MacroError(f"vintage {vid} already exists")
    os.replace(tmp, dest)
    idx = base / "index.csv"
    new = not idx.exists()
    with open(idx, "a", encoding="utf-8") as f:
        if new:
            f.write("vintage_id,created_utc,as_of,manifest_sha256\n")
        f.write(f"{vid},{manifest['created_utc']},{result['provenance'].get('as_of', '')},{_sha(dest / 'manifest.json')}\n")
    return dest


def verify_vintage(path) -> list[dict]:
    """Checks (name, ok, detail, required) of one written vintage: files at their manifest sha256, every value has a
    status, no value of an unverified / method-held series is ok."""
    p = Path(path)
    out = []

    def chk(name, ok, detail=""):
        out.append({"name": name, "ok": bool(ok), "detail": str(detail)[:300], "required": True})
    try:
        m = json.loads((p / "manifest.json").read_text(encoding="utf-8"))
    except (OSError, ValueError) as e:
        chk("manifest.json readable", False, e)
        return out
    for n, sha in (m.get("files") or {}).items():
        f = p / n
        chk(f"{n} at its manifest sha256", f.is_file() and _sha(f) == sha, n)
    try:
        v = pd.read_csv(p / "values.csv", dtype=str, keep_default_na=False)
    except (OSError, ValueError) as e:
        chk("values.csv readable", False, e)
        return out
    chk("every value has a gate status", v["status"].isin(["ok", "hold"]).all() if len(v) else True, len(v))
    bad = v[(v["status"] == "ok") & (((v["kind"] == "eer") & ~v["series"].isin(EER_VERIFIED))
                                     | (v["kind"].isin(["cmo_index", "cmo_price", "tot"]) & (not CMO_VERIFIED))
                                     | ((v["kind"] == "tot") & (TOT_SERIES not in METHOD_APPROVED)))]
    chk("no unverified or method-held value is ok", bad.empty, f"{len(bad)} rows")
    return out


# ------------------------------------------------------------------------------------------------ CLI

def _summary(res: dict) -> str:
    c = res["provenance"]["counts"]
    return (f"[macro] as_of {res['provenance']['as_of']}: {c['values']} values ({c['ok']} ok, {c['held']} held); "
            f"eer series {c['eer_series']}, commodity series {c['cmo_index_series'] + c['cmo_price_series']}, "
            f"share series {c['share_series']}, weights {c['weights']}, tot series {c['tot_series']}; "
            f"pit refused {c['pit_refused']}")


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.official.macro", description=__doc__.split("\n")[0])
    sub = ap.add_subparsers(dest="cmd", required=True)
    b = sub.add_parser("build", help="gate the recorded macro inputs (offline) and write one vintage under --out")
    b.add_argument("--data", default="data")
    b.add_argument("--as-of", required=True)
    b.add_argument("--out", required=True, help="output root (vintages/<id>/ is created under it); never data/mvp")
    b.add_argument("--cmo-xlsx", help=f"a downloaded {CMO_FILE}")
    b.add_argument("--cmo-retrieved", help="when the Pink Sheet file was downloaded (UTC); default: file mtime")
    b.add_argument("--shares", help="a recorded raw_worldbank.csv with TX.VAL rows (default: the 2026-10-25 pull)")
    v = sub.add_parser("verify", help="re-verify a written vintage")
    v.add_argument("path")
    a = ap.parse_args(argv)
    if a.cmd == "verify":
        checks = verify_vintage(a.path)
        for c in checks:
            print(("ok   " if c["ok"] else "FAIL ") + c["name"] + (f" ({c['detail']})" if c["detail"] else ""))
        return 0 if all(c["ok"] for c in checks) else 1
    out = Path(a.out).resolve()
    if "mvp" in out.parts:
        print("refused: --out must not be under data/mvp", file=sys.stderr)
        return 1
    try:
        cmo = cmo_input(a.cmo_xlsx, a.cmo_retrieved) if a.cmo_xlsx else None
        shares = recorded_shares(a.shares, a.as_of) if a.shares else None
        res = build(a.data, a.as_of, cmo=cmo, shares=shares)
    except MacroError as e:
        print(f"refused: {e}", file=sys.stderr)
        return 1
    dest = write_vintage(out, res)
    print(_summary(res))
    print(f"[macro] vintage {dest}")
    return 0


if __name__ == "__main__":  # pragma: no cover
    sys.exit(main())
