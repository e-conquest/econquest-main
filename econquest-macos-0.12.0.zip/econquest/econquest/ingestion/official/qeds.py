"""2.2, 2.9 and 2.10 for the SDDS desk names that IDS does not cover (MYS, SGP, JPN, KOR), from the World Bank Quarterly
External Debt Statistics (QEDS). EQ-A-0108, coverage part 5. AGENT-02 agreed 2026-10-25 (no overlap with EQ-A-0106).

Why. IDS covers low- and middle-income economies only, so the World Bank feed returns no 2.9 / 2.10 value for
Malaysia, Singapore, Japan and South Korea (fullfetch review 2026-10-25: "worldbank returned no value"). These
four report gross external debt to QEDS under the SDDS (QEDS coverage of the four is UNVERIFIED).

    2.9  = QEDS short-term gross external debt, all sectors, end of year Y (Q4 stock, US$)
           / WDI FI.RES.TOTL.CD (total reserves incl. gold, US$, year Y) x 100
    2.10 = QEDS gross external debt, all sectors, all maturities, end of year Y (Q4 stock, US$)
           / WDI BX.GSR.TOTL.CD (exports of goods, services and primary income, US$, year Y) x 100
           (indicator-rules 20, EQ-A-0118: the IDS basis; no goods-and-services fallback, held without it)
    Names: indicator-rules 20 applies the proxy to MYS and KOR only (QEDS_ISOS). SGP and JPN are held for the analyst
    with their seeds kept (ANALYST_HELD, as section 17). 2.9 is approved as built; METHOD_APPROVED stays empty
    because adding ids there is a Tier 1 change. The 2.2 proxy (HO-20261025-A-B-017) is not answered yet and follows
    the same two names.
    2.2  = (-WDI BN.CAB.XOKA.GD.ZS / 100 x NY.GDP.MKTP.CD + QEDS short-term debt by REMAINING maturity, Q4 of Y)
           / WDI FI.RES.TOTL.CD x 100 (EQ-A-0118, part 6: 2.2 weight 0.03 is missing for the same four names)
    Y    = the latest year <= the as_of year with the Q4 stock and every denominator (a stock is never paired with an
           older or newer denominator). Denominators come from the World Bank feed's raw rows; all three are in
           raw_worldbank.csv on the 0.4.2 pull for the four names.

A proxy, held for Team B (`method`): IDS DT.DOD.DECT.EX.ZS divides by exports of goods, services AND primary income,
and DT.DOD.DSTC.IR.ZS by total reserves; QEDS is a residence-based gross external debt position, IDS a debtor
reporting system. The two are close, not equal.

UNVERIFIED (Mac probe list, `python -m econquest.ingestion.official.qeds probe`):
- QEDS_DB = 20 is the wbgapi database id of "Quarterly External Debt Statistics SDDS" (from memory).
- QEDS_SERIES codes: not read from the API metadata here. The probe searches the database for the two concepts and
  prints the codes it finds; whoever runs it replaces the placeholders and sets QEDS_VERIFIED.
- The time key format of quarterly wbgapi records ("2025Q4" or "YR2025Q4"); both are accepted, anything else refused.

Licence: QEDS is a joint World Bank / IMF database built from countries' SDDS reports. Its rows may count as
IMF-upstream (the rule Team B applies to WDI series compiled from IMF data, HO-20261024-A-B-011 item 3), so the source
label names the IMF and audit.client_output_reason restricts every value until AGENT-09 or Sam rules (AGENT-02 note).
WDI FI.RES.TOTL.CD is itself compiled from IMF IFS.

OFF BY DEFAULT: wired by EQ-A-0117 (HO-20261025-A-A-002) as a NAMED feed only (`--only qeds`, like oecd, eurostat
and cb): it is in feeds.FEED_HOSTS and official.wiring.fetch_plan, but in no FEED_ALIASES entry, so no default fetch
and no pull pack step runs it until AGENT-08 enables it. qeds_cells fills a cell only where the World Bank left it
empty; official.gate holds every cell (`unverified`, `method`) until the probe, Team B and the licence ruling.
Nothing here writes data/.
"""
from __future__ import annotations

import argparse
import re
import sys
from dataclasses import dataclass
from typing import Callable, Iterable

import numpy as np
import pandas as pd

QEDS_FEED = "qeds"
QEDS_LABEL = "World Bank QEDS (World Bank/IMF, SDDS reports) via wbgapi (EQ-A-0108)"
QEDS_DB = 20                                         # UNVERIFIED wbgapi id of QEDS SDDS
QEDS_SERIES = {                                      # UNVERIFIED placeholders: set from the probe, then QEDS_VERIFIED
    "total": "DT.DOD.DECT.CD.TL.US",                 # gross external debt, all sectors, all maturities, US$
    "short": "DT.DOD.DECT.CD.ST.US",                 # gross external debt, all sectors, short-term, US$
    # EQ-A-0118 (2.2): short-term on a REMAINING maturity basis (original short-term + long-term due within 12
    # months), the QEDS memorandum item; placeholder, UNVERIFIED like the two above
    "short_remaining": "DT.DOD.DECT.CD.SR.US",
}
PROBE_TERMS = {"total": ("gross external debt", "all sectors", "all maturities"),
               "short": ("gross external debt", "all sectors", "short-term"),
               "short_remaining": ("gross external debt", "short-term", "remaining maturity")}
QEDS_VERIFIED: frozenset = frozenset()               # {"2.9", "2.10"} only after the Mac probe
METHOD_APPROVED: frozenset = frozenset()             # Team B (handoff under EQ-A-0108); a Tier 1 change for Sam
QEDS_ISOS = ("MYS", "KOR")                           # indicator-rules 20: the proxy applies to these two only
ANALYST_HELD = {                                     # indicator-rules 20 / 17: held for the analyst, seeds kept
    "SGP": "financial centre: gross external debt is mostly bank liabilities matched by external assets",
    "JPN": "external debt mainly in its own reserve currency",
}
RESERVES, GDP_USD = "FI.RES.TOTL.CD", "NY.GDP.MKTP.CD"
EXPORTS_PCT = "NE.EXP.GNFS.ZS"                       # no longer used for 2.10 (section 20); kept for existing callers
EXPORTS_GSPI = "BX.GSR.TOTL.CD"                      # 2.10 denominator (indicator-rules 20): exports of goods, services
                                                     # and primary income, the IDS DT.DOD.DECT.EX.ZS basis; UNVERIFIED
CA_PCT = "BN.CAB.XOKA.GD.ZS"                         # WDI current account, % of GDP (IMF BoP via WDI: restricted)
KEYS = ("2.2", "2.9", "2.10")
QEDS_YEARS = 6
QEDS_STALE_YEARS = 3                                 # as official.gate's World Bank rule
RANGE = {"2.2": (-500.0, 2000.0), "2.9": (0.0, 1000.0), "2.10": (0.0, 2000.0)}
_TIME = re.compile(r"^(?:YR)?(\d{4})[-\s]?Q([1-4])$")


def parse_records(records: Iterable[dict], code: str) -> pd.DataFrame:
    """wbgapi data.fetch records (economy, time, value) -> iso, series, year, quarter, value. Blank values skipped; a
    time key that is not a quarter is refused (ValueError), never guessed."""
    rows = []
    for r in records:
        v = r.get("value")
        if v is None or (isinstance(v, float) and np.isnan(v)):
            continue
        m = _TIME.fullmatch(str(r.get("time", "")).strip())
        if not m:
            raise ValueError(f"QEDS {code}: time key {r.get('time')!r} is not a quarter (YYYYQn)")
        rows.append({"iso": str(r.get("economy", "")).upper(), "series": code, "year": int(m.group(1)),
                     "quarter": int(m.group(2)), "value": float(v)})
    df = pd.DataFrame(rows, columns=["iso", "series", "year", "quarter", "value"])
    if df.duplicated(["iso", "series", "year", "quarter"]).any():
        raise ValueError(f"QEDS {code}: more than one value for a country-quarter")
    return df


def _wbgapi_fetch(code: str, isos: list[str], start: int, end: int) -> list[dict]:
    import wbgapi as wb  # optional dependency, Mac only
    return list(wb.data.fetch(code, isos, db=QEDS_DB, skipBlanks=True))


@dataclass
class QedsFeed:
    """Both QEDS_SERIES for `isos` (default QEDS_ISOS). Returns iso, series, year, quarter, value with
    attrs["failures"]; raises RuntimeError when nothing came back. `fetcher(code, isos, start, end) -> records`."""
    end: int
    fetcher: Callable | None = None

    def fetch(self, isos: Iterable[str] = QEDS_ISOS) -> pd.DataFrame:
        isos = [i for i in dict.fromkeys(isos) if isinstance(i, str) and i]
        get = self.fetcher or _wbgapi_fetch
        parts, failures = [], []
        for code in QEDS_SERIES.values():
            try:
                df = parse_records(get(code, isos, self.end - QEDS_YEARS + 1, self.end), code)
            except Exception as e:  # noqa: BLE001 - one series failing is reported, the other still used
                failures.append(f"{code}: {type(e).__name__}: {str(e)[:160]}")
                continue
            parts.append(df[df["iso"].isin(isos) & (df["year"] <= self.end)])
        out = pd.concat(parts, ignore_index=True) if parts else pd.DataFrame()
        if out.empty:
            raise RuntimeError("QEDS: no rows (" + "; ".join(failures) + ")")
        out.attrs["failures"] = failures
        return out


def _q4(qeds: pd.DataFrame | None, iso: str, code: str) -> pd.Series:
    if qeds is None or not len(qeds):
        return pd.Series(dtype=float)
    s = qeds[(qeds["iso"] == iso) & (qeds["series"] == code) & (qeds["quarter"] == 4)]
    return pd.Series(s["value"].to_numpy(dtype=float), index=s["year"].astype(int).to_numpy()).sort_index()


def _annual(wb: pd.DataFrame | None, iso: str, series: str) -> pd.Series:
    """Year -> value from raw_worldbank rows; ValueError on two rows for one year (never summed or picked)."""
    if wb is None or not len(wb):
        return pd.Series(dtype=float)
    s = wb[(wb["iso"] == iso) & (wb["series"] == series)]
    yr = pd.to_numeric(s["period"].astype(str).str[:4], errors="coerce")
    v = pd.Series(pd.to_numeric(s["value"], errors="coerce").to_numpy(), index=yr.to_numpy()).dropna()
    v = v[~pd.isna(v.index)]
    v.index = v.index.astype(int)
    if v.index.duplicated().any():
        raise ValueError(f"{series} {iso}: more than one row for a year")
    return v.sort_index()


def qeds_transform(key: str, qeds: pd.DataFrame | None, wb: pd.DataFrame | None, iso: str,
                   year: int) -> tuple[float | None, str, str, int | None]:
    """(value, series text, reason not served, year used) for 2.2, 2.9 or 2.10, data years <= `year` only.
    2.2 (EQ-A-0118) = (-CA + QEDS short-term debt by remaining maturity, Q4) / reserves x 100: the rulebook's "CA
    deficit + external debt due in 12m"; remaining maturity already includes long-term debt due within a year, so no
    separate amortisation term is added (IDS names use DSTC + DPPG + PNGB amortisation, section 14)."""
    if key not in KEYS:
        raise ValueError(key)
    if iso in ANALYST_HELD:
        return None, "", f"held for the analyst (indicator-rules 20 / 17): {ANALYST_HELD[iso]}; seed kept", None
    code = QEDS_SERIES[{"2.2": "short_remaining", "2.9": "short", "2.10": "total"}[key]]
    try:
        stock = _q4(qeds, iso, code)
        if key == "2.2":
            ca = (_annual(wb, iso, CA_PCT) / 100.0 * _annual(wb, iso, GDP_USD)).dropna()
            res = _annual(wb, iso, RESERVES)
            stock = (stock - ca.reindex(stock.index)).dropna()            # -CA + debt due in 12m
            den = res
            den_text = f"WDI {RESERVES}, with -WDI {CA_PCT} x {GDP_USD} in the numerator"
        elif key == "2.9":
            den = _annual(wb, iso, RESERVES)
            den_text = f"WDI {RESERVES}"
        else:
            den = _annual(wb, iso, EXPORTS_GSPI)            # no goods-and-services fallback (section 20)
            den_text = f"WDI {EXPORTS_GSPI}"
    except ValueError as e:
        return None, "", f"refused: {e}", None
    stock = stock[stock.index <= year]
    if not len(stock):
        extra = f" paired with WDI {CA_PCT} x {GDP_USD}" if key == "2.2" else ""
        return None, "", f"no QEDS {code} Q4 value{extra}", None
    common = sorted(set(stock.index) & set(den.index))
    if not common:
        return None, "", f"no year with QEDS {code} Q4 and {den_text} together", None
    y = common[-1]
    if not den[y] > 0:
        return None, "", f"{den_text} not positive in {y}", None
    v = float(stock[y] / den[y] * 100.0)
    head = f"(-CA + QEDS {code} Q4)" if key == "2.2" else f"QEDS {code} Q4"
    return v, f"rule {key} QEDS v1 (proxy): {head} / {den_text}, {y}", "", y


def qeds_cells(raw: dict, country: str, iso: str, filled: set, have: pd.Series, year: int,
               tlog: list, unserved: list) -> list[tuple]:
    """(kind, key, value, source, series) for 2.2, 2.9 and 2.10 of a QEDS_ISOS name, only where no earlier feed (the
    World Bank) filled the cell. A filled cell drops the earlier unserved row for it; an unfilled one adds a reason."""
    if QEDS_FEED not in raw or iso not in QEDS_ISOS:
        return []
    puts = []
    for key in KEYS:
        cur = pd.to_numeric(have.get(key, np.nan), errors="coerce")
        if key in filled or (cur is not None and np.isfinite(cur)):
            continue
        v, text, why, _ = qeds_transform(key, raw[QEDS_FEED], raw.get("worldbank"), iso, year)
        if v is None:
            unserved.append({"table": "Inputs", "key": key, "country": country, "iso": iso, "feed": QEDS_FEED,
                             "reason": why})
            continue
        note = f"precedence worldbank > {QEDS_FEED}: {QEDS_FEED} used as fallback (IDS does not cover {iso})"
        tlog.append({"iso": iso, "series": key, "year": year, "value": v, "fallback": np.nan, "jump": np.nan,
                     "sd_changes": np.nan, "rule": note, "country": country})
        unserved[:] = [u for u in unserved if not (u.get("table") == "Inputs" and u.get("key") == key
                                                   and u.get("country") == country)]
        puts.append(("indicator", key, v, QEDS_LABEL, f"{text} ({note})"))
    return puts


def data_year_of(series: str) -> int | None:
    """The year qeds_transform wrote into a cell's series text (", YYYY" before the precedence note)."""
    m = re.search(r", (\d{4})(?: \(|$)", str(series))
    return int(m.group(1)) if m else None


def qeds_gate_rows(key: str, country: str, value: float, series: str, data_year: int | None, year: int) -> list[dict]:
    """Hold rows for one cell this feed filled: unverified, method, range, stale."""
    rows = []

    def hold(check, reason):
        rows.append({"table": "Inputs", "key": key, "country": country, "check": check, "status": "hold",
                     "reason": reason, "live": value, "basis": series})

    if key not in QEDS_VERIFIED:
        hold("unverified", f"{key} from {QEDS_FEED}: database {QEDS_DB} and codes not yet confirmed (Mac probe)")
    if key not in METHOD_APPROVED:
        hold("method", f"{key} from {QEDS_FEED}: QEDS proxy awaits Team B (handoff under EQ-A-0108)")
    lo, hi = RANGE[key]
    if not (lo <= value <= hi):
        hold("range", f"{key} {value:.1f} outside [{lo:g}, {hi:g}]")
    if data_year is None or data_year < year - QEDS_STALE_YEARS:
        hold("stale", f"{key} data year {data_year} more than {QEDS_STALE_YEARS} years before {year}")
    return rows


def probe(search: Callable | None = None, wdi_lookup: Callable | None = None) -> int:
    """Mac: list QEDS series whose names match PROBE_TERMS and look up WDI BX.GSR.TOTL.CD (indicator-rules 20); exit
    0 when each QEDS concept has exactly one match and the WDI code exists."""
    if search is None:
        import wbgapi as wb  # optional dependency, Mac only
        search = lambda: [(s["id"], s["value"]) for s in wb.series.list(db=QEDS_DB)]  # noqa: E731
    found = {k: [] for k in PROBE_TERMS}
    for sid, name in search():
        low = str(name).lower()
        for k, terms in PROBE_TERMS.items():
            if k != "short_remaining" and "remaining" in low:
                continue                                     # original-maturity concepts only
            if all(t in low for t in terms) and ("us$" in low or "usd" in low or "current" in low):
                found[k].append((sid, name))
    ok = True
    for k, hits in found.items():
        print(f"{k}: {len(hits)} match(es); placeholder {QEDS_SERIES[k]}")
        for sid, name in hits[:10]:
            print(f"  {sid}  {name}")
        ok &= len(hits) == 1
    wdi = wdi_lookup() if wdi_lookup is not None else _wdi_lookup()
    print(f"WDI {EXPORTS_GSPI} (2.10 denominator): {wdi or 'NOT FOUND'}")
    ok &= bool(wdi)
    return 0 if ok else 1


def _wdi_lookup() -> str | None:
    import wbgapi as wb  # optional dependency, Mac only
    try:
        s = wb.series.get(EXPORTS_GSPI, db=2)
    except Exception:  # noqa: BLE001 - a missing code is the probe's answer
        return None
    return str(s.get("value")) if s else None


def main(argv: list[str] | None = None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.official.qeds",
                                 description="QEDS 2.9 / 2.10 for the SDDS desk names (off by default)")
    sub = ap.add_subparsers(dest="cmd", required=True)
    sub.add_parser("probe", help="Mac: confirm database 20 and the two series codes")
    a = ap.parse_args(argv)
    if a.cmd == "probe":
        return probe()
    return 2


if __name__ == "__main__":
    sys.exit(main())
