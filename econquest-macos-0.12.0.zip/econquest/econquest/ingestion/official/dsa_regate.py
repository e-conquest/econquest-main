"""Offline dsa re-gate of one saved vintage (EQ-A-0096; AGENT-08 decision 2, design approved 2026-10-25).

`econquest dsa` reads the raw files a fetch saved, so its scorecard rows (outputs/dsa_scorecard_feeds.csv, contract
HO-20261024-A-B-007) can only exist after the fetch: dsa is never a fetch_all feed. This module gates them for that
vintage only:

    1. refuse unless a vintage exists, `vintage_id` is the latest one, it is a full pull (raw_weo.csv and
       raw_worldbank.csv) and not already a re-gate (raw_dsa.csv), and every dsa row's vintage_id is that vintage
    2. load the vintage (hash checked: feeds.load_vintage) and its raw_*.csv tables as saved (text, so ids such as
       '2.10' and the bytes are kept)
    3. dsa_cells for every desk country, only where the vintage left the cell empty (an IMF IRFCL value stays:
       dsa_feed.PRECEDENCE_12); estimate rows are listed unserved
    4. gate only those cells: feeds.quality_gate on a report holding just them, with dsa_vintage=<vintage>, plus the
       F8 guard dsa_feed.dsa_reseed_rows (seed written by the old `dsa --apply`, move above 25%: held for Sam)
    5. merge into the vintage's review (the dsa rows replace that cell's 'missing' row), ledger.write_review, then
       feeds.save_vintage writes a derived vintage: the same raw files plus raw_dsa.csv, the dsa cells in
       live_inputs.csv / provenance.csv, and feeds.json 'dsa' naming the base vintage and the dsa file's sha256

Nothing is applied: apply goes through feeds.apply_vintage, where held cells need an approved ledger decision
(Pakistan and Argentina 1.2 always reach Sam's review, F8). The base vintage is never changed (vintages are
append-only). data/live/review.csv is rewritten by write_review; the other data/live files are left as the fetch
wrote them, so a rerun of `econquest dsa` still finds the same raw_weo / raw_worldbank bytes.

    python -m econquest.ingestion.official.dsa_regate --data data --dsa data/live/pullpack/dsa/dsa_scorecard_feeds.csv
"""
from __future__ import annotations

import argparse
import datetime as dt
import hashlib
import io
import sys
from pathlib import Path
from typing import Callable

import numpy as np
import pandas as pd

from .dsa_feed import DSA_FEED, DSA_KEYS, dsa_cells, dsa_reseed_rows, read_dsa_feeds

FULL_PULL_FILES = ("raw_weo.csv", "raw_worldbank.csv")      # what `econquest dsa` reads (engine.dsa.dsa_vintage_id)


class RegateRefused(ValueError):
    """The re-gate would not be point in time (nothing was written)."""


def _text_csv(b: bytes) -> pd.DataFrame:
    return pd.read_csv(io.BytesIO(b), dtype=str, keep_default_na=False) if b.strip() else pd.DataFrame()


def check_base(data_dir: str | Path, vintage_id: str | None = None) -> str:
    """The vintage to re-gate (default: the latest), or RegateRefused with the reason. Assumes no older vintage."""
    from ..feeds import list_vintages, vintage_path
    d = Path(data_dir)
    ids = list_vintages(d)
    if not ids:
        raise RegateRefused(f"no vintage under {d / 'live' / 'vintages'}: run the full `econquest fetch` first")
    try:
        vid = vintage_path(d, vintage_id).name if vintage_id else ids[-1]
    except FileNotFoundError as e:
        raise RegateRefused(str(e)) from e
    if vid != ids[-1]:
        raise RegateRefused(f"vintage {vid} is not the latest ({ids[-1]}): a re-gate of an older pull would shadow "
                            "the newer one; rerun `econquest dsa` on the latest full fetch")
    v = vintage_path(d, vid)
    if (v / f"raw_{DSA_FEED}.csv").exists():
        raise RegateRefused(f"vintage {vid} is already a dsa re-gate: run a new full `econquest fetch` first")
    lacking = [f for f in FULL_PULL_FILES if not (v / f).is_file()]
    if lacking:
        raise RegateRefused(f"vintage {vid} has no {', '.join(lacking)} (a partial pull, e.g. pullpack fx): run the "
                            "full `econquest fetch`, then `econquest dsa`, then this re-gate")
    return vid


def regate(data_dir: str | Path, dsa_file: str | Path, vintage_id: str | None = None, u=None, year: int | None = None,
           now: dt.datetime | None = None, log: Callable[[str], None] = print) -> dict:
    """Steps 1-5 of the module docstring. Returns {base_vintage, vintage_id, dsa_sha256, served, ok, held, reseed,
    unserved, held_cells, review_rows}. RegateRefused (nothing written) for every refusal."""
    from ..crosscheck import CHECK_COLUMNS, merge_into_review
    from ..feeds import (UNSERVED_COLUMNS, FetchReport, _wide_from_bytes, diff_against_seed, load_vintage,
                         quality_gate, save_vintage, vintage_path)
    from ..ledger import write_review
    from ..loaders import load_universe
    d = Path(data_dir)
    vid = check_base(d, vintage_id)
    blob = Path(dsa_file).read_bytes() if Path(dsa_file).is_file() else None
    if blob is None:
        raise RegateRefused(f"{dsa_file} not found: run `econquest dsa --as-of <date>` after the fetch")
    try:
        dsa = read_dsa_feeds(io.BytesIO(blob))                 # SEC-A-011 L3: parse the bytes whose sha256 is recorded
    except ValueError as e:                                    # name the file, not the in-memory buffer
        raise RegateRefused(f"{dsa_file}: {str(e).split(': ', 1)[-1]}") from e
    if not len(dsa):
        raise RegateRefused(f"{dsa_file} has no rows")
    found = sorted(set(dsa["vintage_id"].astype(str).str.strip()))
    if found != [vid]:
        raise RegateRefused(f"{dsa_file} rows are from vintage {', '.join(repr(x) for x in found)}, not {vid}: rerun "
                            "`econquest dsa` on this fetch (a blank id means data/live no longer matches any vintage)")
    sha = hashlib.sha256(blob).hexdigest()
    _vid, rep, review = load_vintage(d, vid)                  # hash-checked against vintages/index.csv
    folder = vintage_path(d, vid)
    files = {q.name: q.read_bytes() for q in folder.iterdir() if q.is_file()}
    raw = {n[4:-4]: _text_csv(b) for n, b in sorted(files.items()) if n.startswith("raw_") and n.endswith(".csv")}
    ind = _wide_from_bytes(files["live_inputs.csv"])
    prof = _wide_from_bytes(files["live_profile.csv"])
    prov = _text_csv(files.get("provenance.csv", b""))
    unserved = _text_csv(files["unserved.csv"]) if "unserved.csv" in files else pd.DataFrame(columns=UNSERVED_COLUMNS)
    u = u if u is not None else load_universe(d)
    year = year or (now or dt.datetime.now(dt.timezone.utc)).year
    retrieved = (now or dt.datetime.now(dt.timezone.utc)).date().isoformat()
    sub = pd.DataFrame(np.nan, index=ind.index, columns=ind.columns)
    new_prov, new_unserved, tlog = [], [], []
    for n, iso in zip(u.names, u.countries["iso"]):
        if n not in ind.columns:
            continue
        for _kind, key, v, src, series in dsa_cells(dsa, n, iso, ind[n], set(), vid, year, tlog, new_unserved):
            if key not in ind.index:
                new_unserved.append({"table": "Inputs", "key": key, "country": n, "iso": iso, "feed": DSA_FEED,
                                     "reason": f"{key} is not a row of live_inputs.csv in vintage {vid}"})
                continue
            sub.at[key, n] = v
            new_prov.append({"table": "Inputs", "key": key, "country": n, "value": v, "source": src, "series": series,
                             "retrieved": retrieved})
    new_unserved = [r for r in new_unserved if r["key"] in DSA_KEYS]
    part = FetchReport(sub, prof.iloc[0:0], pd.DataFrame(new_prov, columns=["table", "key", "country", "value", "source",
                                                                           "series", "retrieved"]),
                       {DSA_FEED: f"ok ({len(new_prov)} cells)"}, {DSA_FEED: dsa},
                       unserved=pd.DataFrame(new_unserved, columns=UNSERVED_COLUMNS))
    got = quality_gate(u, part, diff_against_seed(u, part), year=year, data_dir=None, dsa_vintage=vid)
    got = got[(got["table"] == "Inputs") & got["key"].astype(str).isin(DSA_KEYS)].copy()
    served = got[got["status"].isin(["ok", "hold"])]
    reseed = dsa_reseed_rows(d, [(r.key, r.country, r.seed, r.live) for r in served.itertuples(index=False)])
    got = merge_into_review(got, pd.DataFrame(reseed, columns=CHECK_COLUMNS) if reseed else None)
    # merge into the vintage's review: a served dsa cell replaces that cell's row; a dsa 'missing' row adds its reason
    review = review.copy()
    review["key"] = review["key"].astype(str)
    review["reason"] = review["reason"].fillna("").astype(str)
    at = {(t, k, c): i for i, t, k, c in zip(review.index, review["table"], review["key"], review["country"])}
    drop, add = [], []
    for r in got.to_dict("records"):
        cell = (r["table"], str(r["key"]), r["country"])
        if cell in at and r["status"] == "missing":
            i = at[cell]
            if r["reason"] and r["reason"] not in review.at[i, "reason"]:
                review.at[i, "reason"] = "; ".join(x for x in (review.at[i, "reason"], r["reason"]) if x)
            continue
        if cell in at:
            drop.append(at[cell])
        add.append(r)
    review = pd.concat([review.drop(index=drop), pd.DataFrame(add).reindex(columns=review.columns)], ignore_index=True)
    served_cells = {(str(r.key), r.country) for r in served.itertuples(index=False)}
    if len(unserved):
        keep = [not (t == "Inputs" and (str(k), c) in served_cells)
                for t, k, c in zip(unserved["table"], unserved["key"], unserved["country"])]
        unserved = unserved[keep]
    unserved = pd.concat([unserved, pd.DataFrame(new_unserved, columns=UNSERVED_COLUMNS).astype(str)], ignore_index=True)
    for key, n in served_cells:
        ind.at[key, n] = sub.at[key, n]
    prov = pd.concat([prov, pd.DataFrame(new_prov).astype(str)], ignore_index=True) if new_prov else prov
    feeds = dict(rep.feeds)
    feeds[DSA_FEED] = (f"ok ({len(served_cells)} cells; offline re-gate of vintage {vid}; dsa file sha256 {sha}; "
                       "EQ-A-0096)")
    out = FetchReport(ind, prof, prov, feeds, {**raw, DSA_FEED: dsa}, unserved=unserved)
    review = write_review(d, review, now)
    v = save_vintage(d, out, review, now=now)
    held = got[got["status"] == "hold"]
    res = {"base_vintage": vid, "vintage_id": v.name, "dsa_sha256": sha, "served": len(served_cells),
           "ok": int((got["status"] == "ok").sum()), "held": int(len(held)), "reseed": len(reseed),
           "unserved": len(new_unserved),
           "held_cells": [f"Inputs {r.key} {r.country}: {r.reason}" for r in held.itertuples(index=False)],
           "review_rows": int(len(got))}
    log(f"[dsa_regate] vintage {vid} -> {v.name}: {res['served']} dsa cells served ({res['ok']} ok, {res['held']} "
        f"held, {res['reseed']} by dsa_reseed), {res['unserved']} unserved; nothing applied")
    return res


def main(argv=None) -> int:
    ap = argparse.ArgumentParser(prog="python -m econquest.ingestion.official.dsa_regate",
                                 description="Gate econquest dsa rows for the vintage they were built from (no apply)")
    ap.add_argument("--data", default="data")
    ap.add_argument("--dsa", required=True, help="dsa_scorecard_feeds.csv written by `econquest dsa` on this fetch")
    ap.add_argument("--vintage", help="vintage id (default: the latest; any other is refused)")
    a = ap.parse_args(argv)
    try:
        res = regate(a.data, a.dsa, a.vintage)
    except RegateRefused as e:
        print(f"dsa_regate: refused: {e}", file=sys.stderr)
        return 2
    for line in res["held_cells"]:
        print(f"  held: {line}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
