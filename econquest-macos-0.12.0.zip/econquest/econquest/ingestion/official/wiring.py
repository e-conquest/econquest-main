"""What feeds.fetch_all calls for the official adapters (EQ-A-0049). feeds.py imports this module inside fetch_all
(lazily), because the adapters import feeds."""
from __future__ import annotations

import datetime as dt
from typing import Callable, Iterable

import numpy as np
import pandas as pd

from . import EUROSTAT_FEED, IMF_FEED, OECD_FEED
from .central_banks import CB_FEED, CentralBankFeed
from .eurostat import EurostatFeed, eurostat_transforms
from .imf import IMF_COMPONENTS, IMF_NOT_SERVED, ImfSdmxFeed, imf_transforms, unserved_reason
from .oecd import OecdFeed, oecd_transforms
from .precedence import PRECEDENCE, choose
from .dsa_feed import DSA_FEED, dsa_cells
from .ids_fc_debt import IDS_FC_FEED, IdsFcDebtFeed, ids_fc_cells
from .qeds import QEDS_FEED, QEDS_ISOS, QedsFeed, qeds_cells
from .wdi_extra import WDI_EXTRA_FEED, WdiExtraFeed, wdi_extra_cells
from .worldbank import WB_EXTRA_IDS, WB_NOT_SERVED, wb_extra_transforms

WB_SOURCE = "wbgapi World Bank API v2"
# 1.5: Eurostat (general government, quarterly) before OECD (central government), for EU members that are in both
FC_DEBT_ORDER = (EUROSTAT_FEED, OECD_FEED)


def fetch_plan(isos: Iterable[str], countries: pd.DataFrame,
               year: int | None = None) -> dict[str, Callable[[], pd.DataFrame]]:
    """fetch_all plan entries: feed name -> zero-argument fetch. `year`: the fetch year (QEDS end year)."""
    isos = list(isos)
    year = year or dt.date.today().year
    iso2 = dict(zip(countries["iso"], countries["iso2"])) if "iso2" in countries.columns else {}
    return {IMF_FEED: lambda: ImfSdmxFeed().fetch(isos),
            OECD_FEED: lambda: OecdFeed().fetch(isos),
            EUROSTAT_FEED: lambda: EurostatFeed(iso2={k: v for k, v in iso2.items() if isinstance(v, str)}).fetch(isos),
            CB_FEED: lambda: CentralBankFeed().fetch(isos),       # EQ-A-0050: named feed only (`--only cb`)
            WDI_EXTRA_FEED: lambda: WdiExtraFeed().fetch(isos),   # EQ-A-0062: in the `worldbank` alias
            IDS_FC_FEED: lambda: IdsFcDebtFeed().fetch(isos),     # EQ-A-0096: 1.5 IDS proxy, `worldbank` alias
            # EQ-A-0117 (HO-20261025-A-A-002): 2.2 / 2.9 / 2.10 for the SDDS names IDS lacks; named feed only (`--only qeds`)
            QEDS_FEED: lambda: QedsFeed(end=year).fetch([i for i in isos if i in QEDS_ISOS])}
# EQ-A-0096: `dsa` is never a fetch_all feed. econquest dsa reads the vintage a fetch saved, so its rows are applied by
# the offline re-gate (official.dsa_regate, pullpack step after fetch) for that vintage only.


def _src(raw: dict, feed: str) -> str:
    df = raw[feed]
    return str(df["source"].iloc[0]) if len(df) else feed


def country_cells(raw: dict, country: str, iso: str, cpi: float | None, have: pd.Series, year: int,
                  tlog: list, unserved: list, dsa_vintage: str | None = None) -> list[tuple]:
    """Cells the official adapters and World Bank additions fill for one country, as
    (kind, key, value, source, series) tuples for fetch_all's `put`. `have` is the country's Inputs column after the
    WEO / World Bank / BIS transforms (precedence reads the BIS values there). Precedence decisions are appended to
    `tlog`; cells left empty, with the reason, to `unserved` (UNSERVED_COLUMNS rows). `dsa_vintage`: the vintage the
    econquest dsa rows must come from (None accepts the file's own; the gate still holds a row without one)."""
    puts: list[tuple] = []
    filled: set[str] = set()

    def gone(key: str, feed: str, reason: str) -> None:
        unserved.append({"table": "Inputs", "key": key, "country": country, "iso": iso, "feed": feed, "reason": reason})

    def log(key: str, value, fallback, rule: str) -> None:
        tlog.append({"iso": iso, "series": key, "year": year, "value": value, "fallback": fallback, "jump": np.nan,
                     "sd_changes": np.nan, "rule": rule, "country": country})

    # World Bank additions
    if "worldbank" in raw:
        i, used, why = wb_extra_transforms(raw["worldbank"], raw.get("weo"), iso, year)
        for k, v in i.items():
            puts.append(("indicator", k, v, _src(raw, "worldbank") or WB_SOURCE, used[k])); filled.add(k)
        for k, r in why.items():
            if k in WB_EXTRA_IDS | set(WB_NOT_SERVED):
                gone(k, "worldbank", r)
    # IMF SDMX, with BIS-first precedence for 2.12 / 5.9 / 5.13
    if IMF_FEED in raw:
        i, used = imf_transforms(raw[IMF_FEED], iso, cpi)
        for k in IMF_COMPONENTS:
            bis = have.get(k, np.nan) if k in PRECEDENCE else np.nan
            if k in PRECEDENCE:
                feed, v, note = choose(k, {"bis": bis, IMF_FEED: i.get(k, np.nan)})
                if feed == "bis":
                    if k in i:
                        log(k, float(bis), float(i[k]), note)
                    continue
                if feed == IMF_FEED:
                    puts.append(("indicator", k, v, _src(raw, IMF_FEED), f"{used[k]} ({note})")); filled.add(k)
                    log(k, v, np.nan, note)
                    continue
            elif k in i:
                puts.append(("indicator", k, i[k], _src(raw, IMF_FEED), used[k])); filled.add(k)
                continue
            gone(k, IMF_FEED, unserved_reason(raw[IMF_FEED], iso, k, cpi))
        for k, r in IMF_NOT_SERVED.items():
            gone(k, IMF_FEED, r)
    # EQ-A-0062: WDI annual history, third after BIS and IMF for 2.12 / 5.9 (only cells both left empty)
    puts += wdi_extra_cells(raw, country, iso, have, filled, year, tlog, unserved)
    filled |= {p[1] for p in puts}
    # EQ-A-0096: econquest dsa rows (1.2 live; 1.1 / 2.1 mixed, held), after the IMF cells
    if DSA_FEED in raw:
        puts += dsa_cells(raw[DSA_FEED], country, iso, have, filled, dsa_vintage, year, tlog, unserved)
        filled |= {p[1] for p in puts}
    # 1.5: Eurostat, then OECD
    cands = {}
    for feed, fn in ((EUROSTAT_FEED, eurostat_transforms), (OECD_FEED, oecd_transforms)):
        if feed in raw:
            i, used = fn(raw[feed], iso)
            if "1.5" in i:
                cands[feed] = (i["1.5"], used["1.5"])
    if cands:
        feed = next(f for f in FC_DEBT_ORDER if f in cands)
        v, text = cands[feed]
        note = f"precedence {' > '.join(FC_DEBT_ORDER)}: {feed} used"
        puts.append(("indicator", "1.5", v, _src(raw, feed), f"{text} ({note})")); filled.add("1.5")
        if len(cands) > 1:
            log("1.5", v, next(c[0] for f, c in cands.items() if f != feed), note)
    elif EUROSTAT_FEED in raw or OECD_FEED in raw:
        ran = [f for f in FC_DEBT_ORDER if f in raw]
        gone("1.5", ran[0], f"{' and '.join(ran)} returned no debt-by-currency pair for this country")
    # EQ-A-0096: 1.5 IDS proxy, after Eurostat and OECD (ids_fc_cells removes their unserved row when it fills)
    puts += ids_fc_cells(raw, country, iso, filled, have, year, tlog, unserved)
    filled |= {p[1] for p in puts}
    # EQ-A-0117 (HO-20261025-A-A-002): QEDS for MYS / SGP / JPN / KOR, only where the World Bank left 2.2 / 2.9 / 2.10 empty
    puts += qeds_cells(raw, country, iso, filled, have, year, tlog, unserved)
    return puts
